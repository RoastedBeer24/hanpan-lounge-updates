/* 거점 수호전 — 3D 화면(three.js r170 공용) · 조작 · HUD · 보급소 창 · 소리 · 온라인.
   - 시뮬(sim.js)은 초당 30걸음, 화면은 걸음 사이를 보간해서 그림(카메라 포함). 프레임마다 무작위로 흔드는 연출 없음.
   - 섬 · 분대원 · 물건 · 결은 모두 코드로 만든 형상과 캔버스 결.
   - 온라인: 호스트가 세계를 돌려 hostSend(10Hz), 손님은 자기 분대원 이동 · 발판을 먼저 그리고 publish. */
(function () {
  'use strict';
  const V = {};
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  /* ===== 클릭 없는 마우스 시점(숨바꼭질과 같은 규약) ===== */
  function mkFreeLook(o) {
    const el = o.el, root = o.root || el, doc = document, now = () => performance.now();
    let locked = false, self = false, lastReq = -1e9, fails = 0, retry = 0, wantWas = false, off = false;
    let mx = null, my = 0, tgt = null, focused = true, focusT = -1e9, outT = 0, outDir = 0;
    let skipT = 0, skip1 = false, curHid = false, freed = false;
    const want = () => { try { return !off && !freed && !!o.want(); } catch (e) { return false; } };
    function req(force) {
      if (locked || !el.requestPointerLock || !want()) return;
      const t = now(); if (!force && t - lastReq < (fails > 4 ? 1500 : 250)) return; lastReq = t;
      try { const r = el.requestPointerLock(); if (r && r.catch) r.catch(() => { fails++; }); } catch (e) { fails++; }
    }
    function kick() { freed = false; req(true); clearInterval(retry); let n = 0; retry = setInterval(() => { if (locked || !want() || ++n > 6) { clearInterval(retry); retry = 0; return; } req(true); }, 400); }
    function exit() { clearInterval(retry); retry = 0; try { if (doc.pointerLockElement === el) { self = true; doc.exitPointerLock(); } } catch (e) {} }
    const onPL = () => { const was = locked; locked = doc.pointerLockElement === el; if (locked) { fails = 0; clearInterval(retry); retry = 0; skipT = now() + 150; skip1 = true; } mx = null; outDir = 0; const byUser = was && !locked && !self; self = false; if (byUser) freed = true; if (was !== locked && o.onLock) { try { o.onLock(locked, byUser); } catch (e) {} } };
    const onPM = (e) => {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      if (locked) { const dx = e.movementX || 0, dy = e.movementY || 0; if (skip1 || now() < skipT) { skip1 = false; return; } if (Math.abs(dx) > 400 || Math.abs(dy) > 400) return; if (want()) o.turn(dx, dy, true, false); return; }
      outDir = 0; tgt = e.target;
      if (!want()) { mx = null; return; }
      if (mx != null) { const dx = e.clientX - mx, dy = e.clientY - my; if (Math.abs(dx) < 400 && Math.abs(dy) < 400 && (dx || dy)) o.turn(dx, dy, false, false); }
      mx = e.clientX; my = e.clientY;
    };
    const onKey = (e) => { if (e.code === 'Escape' || e.repeat || e.altKey || e.metaKey) return; freed = false; req(false); };
    const onPD = (e) => { if (e.pointerType === 'mouse' && root.contains(e.target)) { freed = false; req(false); } };
    const onWh = () => req(false);
    const onFocus = () => { focused = true; focusT = now(); mx = null; }, onBlur = () => { focused = false; mx = null; outDir = 0; };
    const onLeave = (e) => { if (locked || mx == null) return; const r = root.getBoundingClientRect(), zx = Math.max(28, r.width * 0.07), x = (e.clientX != null ? e.clientX : mx) - r.left; outDir = x < zx ? -1 : x > r.width - zx ? 1 : 0; outT = now(); if (!outDir) mx = null; };
    doc.addEventListener('pointerlockchange', onPL); doc.addEventListener('pointermove', onPM, true); doc.addEventListener('keydown', onKey, true); doc.addEventListener('pointerdown', onPD, true);
    root.addEventListener('wheel', onWh, { passive: true }); window.addEventListener('focus', onFocus); window.addEventListener('blur', onBlur); doc.documentElement.addEventListener('mouseleave', onLeave);
    return {
      get locked() { return locked; },
      focusClick() { return now() - focusT < 300; },
      kick, exit,
      tick(dt) {
        const w = want(); if (w && !wantWas) kick(); else if (!w && wantWas) { exit(); mx = null; outDir = 0; } wantWas = w;
        { const hide = w && !locked; if (hide !== curHid) { curHid = hide; try { root.style.cursor = hide ? 'none' : ''; } catch (e) {} } }
        if (!w || locked || !focused || mx == null) return;
        const r = root.getBoundingClientRect(), zx = Math.max(28, r.width * 0.07), zy = Math.max(18, r.height * 0.05);
        let ex = 0, ey = 0;
        if (outDir) { if (now() - outT > 4000) { outDir = 0; mx = null; return; } ex = outDir; }
        else {
          if (tgt && tgt.closest && tgt.closest('button,a,input,select,[data-action]')) return;
          const x = mx - r.left, y = my - r.top; if (x < -2 || y < -2 || x > r.width + 2 || y > r.height + 2) return;
          if (x < zx) ex = -(1 - Math.max(0, x) / zx); else if (x > r.width - zx) ex = 1 - Math.max(0, r.width - x) / zx;
          if (y < zy) ey = -(1 - Math.max(0, y) / zy); else if (y > r.height - zy) ey = 1 - Math.max(0, r.height - y) / zy;
        }
        if (ex || ey) { const d = Math.min(0.1, dt > 0 ? dt : 0.016); o.turn(ex * 950 * d, ey * 520 * d, false, true); }
      },
      dbg() { return { locked, fails, mx, outDir, focused, want: want() }; },
      destroy() { off = true; exit(); try { root.style.cursor = ''; } catch (e) {} doc.removeEventListener('pointerlockchange', onPL); doc.removeEventListener('pointermove', onPM, true); doc.removeEventListener('keydown', onKey, true); doc.removeEventListener('pointerdown', onPD, true);
        root.removeEventListener('wheel', onWh); window.removeEventListener('focus', onFocus); window.removeEventListener('blur', onBlur); doc.documentElement.removeEventListener('mouseleave', onLeave); },
    };
  }

  const CSS = `
.bw-wrap{position:absolute;inset:0;overflow:hidden;background:#0d1220;touch-action:none;user-select:none;-webkit-user-select:none}
.bw-wrap canvas.bw-gl{position:absolute;inset:0;width:100%;height:100%;display:block}
.bw-hud{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body,"IBM Plex Sans KR",sans-serif);color:#f2e9d8;font-size:13px;line-height:1.25;word-break:keep-all}
.bw-top{position:absolute;top:6px;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:4px;max-width:calc(100% - 250px)}
.bw-teams{display:flex;gap:5px;flex-wrap:wrap;justify-content:center}
.bw-team{display:flex;align-items:center;gap:5px;background:rgba(14,16,26,.62);border:1.5px solid rgba(255,255,255,.14);border-radius:8px;padding:3px 8px;font-size:13px;white-space:nowrap}
.bw-team.me{border-color:#e3ae45}.bw-team.out{opacity:.45}
.bw-team i{width:11px;height:11px;transform:rotate(45deg);display:inline-block;border-radius:2px}
.bw-team b{font-family:var(--f-mono,monospace);font-weight:600}
.bw-team.hit{animation:bwhit .5s ease-in-out infinite alternate}
@keyframes bwhit{from{background:rgba(14,16,26,.62)}to{background:rgba(170,50,40,.75)}}
.bw-phase{background:rgba(14,16,26,.55);border-radius:8px;padding:2px 10px;font-size:12px;white-space:nowrap}
.bw-phase b{font-family:var(--f-mono,monospace);color:#e3ae45;font-weight:600}
.bw-map{position:absolute;left:8px;top:8px;border-radius:10px;background:rgba(14,16,26,.55);border:1px solid rgba(255,255,255,.14)}
.bw-feed{position:absolute;right:8px;top:54px;display:flex;flex-direction:column;align-items:flex-end;gap:3px;font-size:12px}
.bw-feed div{background:rgba(14,16,26,.55);border-radius:6px;padding:2px 7px;transition:opacity .4s}
.bw-bot{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:5px;max-width:calc(100% - 16px)}
.bw-res{display:flex;gap:6px;align-items:center}
.bw-chip{display:flex;align-items:center;gap:4px;background:rgba(14,16,26,.62);border-radius:8px;padding:2px 8px;font-size:13px}
.bw-chip i{width:10px;height:10px;border-radius:2px;display:inline-block;transform:rotate(45deg)}
.bw-chip b{font-family:var(--f-mono,monospace);font-weight:600;font-size:14px}
.bw-hp{width:170px;height:14px;border-radius:6px;background:rgba(14,16,26,.7);border:1px solid rgba(255,255,255,.2);overflow:hidden;position:relative}
.bw-hp div{height:100%;background:#c8493c;transition:width .15s}
.bw-hp span{position:absolute;inset:0;text-align:center;font-size:12px;line-height:13px;font-family:var(--f-mono,monospace)}
.bw-bar{display:flex;gap:4px;pointer-events:auto;max-width:100%;overflow-x:auto;scrollbar-width:none}
.bw-slot{position:relative;flex:0 0 auto;width:46px;height:46px;border-radius:8px;border:1.5px solid rgba(255,255,255,.2);background:rgba(14,16,26,.62);padding:5px;box-sizing:border-box;color:#f2e9d8;cursor:pointer}
.bw-slot.on{border-color:#e3ae45;background:rgba(60,48,20,.72)}
.bw-slot.off{opacity:.4}
.bw-slot svg{display:block;width:100%;height:100%}
.bw-slot em{position:absolute;right:3px;bottom:1px;font-style:normal;font-family:var(--f-mono,monospace);font-size:12px;font-weight:600;text-shadow:0 0 3px #000,0 0 3px #000}
.bw-slot kbd{position:absolute;left:3px;top:1px;font-family:var(--f-mono,monospace);font-size:12px;color:#e3ae45;text-shadow:0 0 3px #000}
.bw-note{position:absolute;left:50%;bottom:118px;transform:translateX(-50%);background:rgba(14,16,26,.6);border-radius:8px;padding:4px 12px;font-size:13px;transition:opacity .25s;opacity:0;white-space:nowrap}
.bw-note.warn{background:rgba(120,40,30,.7)}.bw-note.good{background:rgba(30,80,60,.7)}
.bw-tip{position:absolute;left:50%;bottom:150px;transform:translateX(-50%);background:rgba(14,16,26,.5);border-radius:8px;padding:3px 10px;font-size:12px;white-space:nowrap;color:#e9dfc8}
.bw-tip kbd,.bw-keys kbd{font-family:var(--f-mono,monospace);background:rgba(255,255,255,.14);border-radius:4px;padding:0 4px;color:#fff}
.bw-keys{position:absolute;left:8px;bottom:8px;font-size:12px;background:rgba(14,16,26,.45);border-radius:8px;padding:4px 8px;line-height:1.6;color:#d9cfba}
.bw-cross{position:absolute;left:50%;top:50%;width:22px;height:22px;margin:-11px 0 0 -11px}
.bw-dead{position:absolute;left:50%;top:22%;transform:translateX(-50%);background:rgba(14,16,26,.66);border-radius:10px;padding:6px 16px;font-size:15px;text-align:center}
.bw-dead small{display:block;font-size:12px;color:#c9bfa8;margin-top:2px}
.bw-score{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);background:rgba(16,18,28,.9);border:1px solid rgba(255,255,255,.16);border-radius:12px;padding:10px 14px;font-size:13px;max-width:94%;max-height:86%;overflow:auto}
.bw-score table{border-collapse:collapse}.bw-score td,.bw-score th{padding:3px 9px;text-align:right;white-space:nowrap}.bw-score td:first-child,.bw-score th:first-child{text-align:left}
.bw-score th{font-weight:500;color:#ab9fb8;font-size:12px}
.bw-shop{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(760px,96%);max-height:94%;display:flex;flex-direction:column;background:rgba(20,22,34,.95);border:1px solid rgba(255,255,255,.18);border-radius:12px;pointer-events:auto;box-shadow:0 10px 40px rgba(0,0,0,.5)}
.bw-shop header{display:flex;align-items:center;gap:8px;padding:6px 8px 4px 12px}
.bw-shop header strong{font-family:var(--f-display,sans-serif);font-size:17px;font-weight:400;letter-spacing:1px}
.bw-shop header .sp{flex:1}
.bw-tight .bw-shop header{padding-right:56px}
.bw-x{width:44px;height:44px;border-radius:10px;border:0;background:rgba(255,255,255,.08);color:#f2e9d8;font-size:18px;cursor:pointer}
.bw-tabs{display:flex;gap:4px;padding:0 8px;overflow-x:auto;scrollbar-width:none}
.bw-tab{flex:0 0 auto;min-height:44px;padding:0 13px;border-radius:9px 9px 0 0;border:0;background:rgba(255,255,255,.06);color:#d9cfba;font-size:14px;font-family:inherit;cursor:pointer}
.bw-tab.on{background:rgba(227,174,69,.22);color:#fff}
.bw-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:6px;padding:8px;overflow-y:auto;min-height:60px;border-top:1px solid rgba(255,255,255,.12)}
.bw-card{display:flex;align-items:center;gap:8px;min-height:52px;padding:5px 8px;border-radius:9px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.05);color:#f2e9d8;font-family:inherit;text-align:left;cursor:pointer}
.bw-card{border-color:rgba(227,174,69,.55);background:rgba(227,174,69,.1)}.bw-card:hover{background:rgba(227,174,69,.2)}
.bw-card.no{border:1px dashed rgba(255,255,255,.2);background:rgba(0,0,0,.22)}.bw-card.no:hover{background:rgba(255,255,255,.06)}.bw-card.no .ic{opacity:.5}.bw-card.no .nm{color:#ddd3c0}.bw-card.no .pr{color:#ff9d8c}.bw-card.own .pr{color:#9fd6a8}
.bw-card .ic{flex:0 0 38px;width:38px;height:38px}
.bw-card .nm{font-size:13px;line-height:1.2}.bw-card .pr{font-size:13px;font-family:var(--f-mono,monospace);margin-top:2px;display:flex;gap:6px;flex-wrap:wrap}
.bw-card .pr i{width:8px;height:8px;display:inline-block;transform:rotate(45deg);margin-right:4px;border-radius:1px}
.bw-card .lv{font-size:12px;color:#e3ae45}
.bw-foot{padding:5px 12px 8px;font-size:12px;color:#d0c6b0;min-height:32px;border-top:1px solid rgba(255,255,255,.1)}
.bw-ctl{position:absolute;inset:0;pointer-events:none}
.bw-btn{position:absolute;border-radius:50%;border:2px solid rgba(255,255,255,.35);background:rgba(20,22,34,.42);color:#fff;font-size:13px;font-family:inherit;pointer-events:auto;display:flex;align-items:center;justify-content:center;touch-action:none}
.bw-btn.on{background:rgba(227,174,69,.5)}
.bw-stick{position:absolute;width:104px;height:104px;margin:-52px 0 0 -52px;border-radius:50%;border:2px solid rgba(255,255,255,.3);background:rgba(20,22,34,.25);display:none}
.bw-stick i{position:absolute;left:50%;top:50%;width:44px;height:44px;margin:-22px 0 0 -22px;border-radius:50%;background:rgba(255,255,255,.4)}
.bw-vig{position:absolute;inset:0;box-shadow:inset 0 0 90px 30px rgba(170,30,20,.0);transition:box-shadow .2s}
`;
  function css() { if (document.getElementById('bw-css')) return; const s = document.createElement('style'); s.id = 'bw-css'; s.textContent = CSS; document.head.appendChild(s); }

  V.mount = function (root, api, D, hooks) {
    const T = window.THREE, S = D.sim, L = window.Lounge, h = L.h;
    const TIER = D.TIERS.find((t) => t.id === D.gfxTier()) || D.TIERS[0];
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const { NX, NZ, NY, CS, G0, GY, C0 } = S, LY = NX * NZ;
    let st = null, W = null, wkey = '', dead = false, paused = false, raf = 0, last = 0, acc = 0, ready = false, sentOver = false, wallT = 0;
    let touch = D.touchOnly(), touchUI = touch;
    const sens = +D.store.get('sens', 1) || 1;
    css();
    const wrap = h('div', { class: 'bw-wrap' }); root.append(wrap);

    /* ======================= 렌더러 · 하늘 · 빛 ======================= */
    const R = new T.WebGLRenderer({ antialias: !!TIER.aa, powerPreference: 'high-performance' });
    R.domElement.className = 'bw-gl'; wrap.append(R.domElement);
    R.outputColorSpace = T.SRGBColorSpace; R.toneMapping = T.ACESFilmicToneMapping; R.toneMappingExposure = 1.05;
    if (TIER.shadow) { R.shadowMap.enabled = true; R.shadowMap.type = T.PCFSoftShadowMap; }
    const scene = new T.Scene(); const HORIZON = new T.Color('#c7b7a2');
    scene.fog = new T.Fog(HORIZON, 110, 420);
    const cam = new T.PerspectiveCamera(66, 1, 0.15, 1400);
    const sunDir = new T.Vector3(0.48, 0.74, 0.36).normalize();
    const sky = new T.Mesh(new T.SphereGeometry(1000, 24, 16), new T.ShaderMaterial({ side: T.BackSide, depthWrite: false, fog: false,
      uniforms: { sun: { value: sunDir } },
      vertexShader: 'varying vec3 d; void main(){ d = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: 'varying vec3 d; uniform vec3 sun; void main(){ vec3 n = normalize(d); float y = n.y; vec3 top = vec3(0.13,0.24,0.47), mid = vec3(0.47,0.60,0.78), hor = vec3(0.80,0.73,0.64), low = vec3(0.62,0.60,0.62);' +
        'vec3 c = y > 0.0 ? mix(hor, mix(mid, top, smoothstep(0.25,0.9,y)), smoothstep(0.0,0.3,y)) : mix(hor, low, smoothstep(0.0,-0.5,y));' +
        'float s = max(dot(n, sun), 0.0); c += vec3(1.0,0.85,0.6) * (pow(s, 600.0) * 2.5 + pow(s, 12.0) * 0.22); gl_FragColor = vec4(c, 1.0); }' }));
    sky.frustumCulled = false; scene.add(sky);
    const hemi = new T.HemisphereLight(0xbcd0ee, 0x8a7a66, 1.05); scene.add(hemi);
    const sun = new T.DirectionalLight(0xfff0d8, 2.3); scene.add(sun); scene.add(sun.target);
    const SH_R = 46;
    if (TIER.shadow) { sun.castShadow = true; sun.shadow.mapSize.set(TIER.shadow, TIER.shadow); const sc = sun.shadow.camera; sc.left = -SH_R; sc.right = SH_R; sc.top = SH_R; sc.bottom = -SH_R; sc.near = 10; sc.far = 260; sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.04; }

    /* ======================= 결(캔버스) ======================= */
    function rnd(seed) { return S.prng(seed); }
    function tex(sz, draw, rep) { const c = document.createElement('canvas'); c.width = c.height = sz; const g = c.getContext('2d'); draw(g, sz); const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; t.wrapS = t.wrapT = T.RepeatWrapping; t.anisotropy = 4; if (rep) t.repeat.set(rep, rep); return t; }
    function speck(g, sz, r, n, a, dark) { for (let i = 0; i < n; i++) { g.fillStyle = (dark ? 'rgba(0,0,0,' : 'rgba(255,255,255,') + (r() * a) + ')'; const s = 1 + r() * 3; g.fillRect(r() * sz, r() * sz, s, s); } }
    const TX = {
      pave: tex(256, (g, z) => { const r = rnd(11); g.fillStyle = '#d9d2c4'; g.fillRect(0, 0, z, z); for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) { const v = 205 + Math.floor(r() * 30); g.fillStyle = 'rgb(' + v + ',' + (v - 5) + ',' + (v - 14) + ')'; g.fillRect(x * 128 + 3, y * 128 + 3, 122, 122); } speck(g, z, r, 500, 0.1, true); speck(g, z, r, 300, 0.12, false); g.strokeStyle = 'rgba(40,36,30,.55)'; g.lineWidth = 4; g.strokeRect(0, 0, z, z); g.lineWidth = 3; g.beginPath(); g.moveTo(128, 0); g.lineTo(128, z); g.moveTo(0, 128); g.lineTo(z, 128); g.stroke(); }),
      rock: tex(256, (g, z) => { const r = rnd(12); g.fillStyle = '#b3aaa0'; g.fillRect(0, 0, z, z); for (let i = 0; i < 60; i++) { g.fillStyle = 'rgba(' + (r() < 0.5 ? '40,34,30' : '230,220,205') + ',' + (0.05 + r() * 0.1) + ')'; g.beginPath(); g.ellipse(r() * z, r() * z, 10 + r() * 40, 4 + r() * 12, r() * 0.6 - 0.3, 0, TAU); g.fill(); } speck(g, z, r, 900, 0.14, true); }),
      canvas: tex(128, (g, z) => { const r = rnd(13); g.fillStyle = '#d6c69c'; g.fillRect(0, 0, z, z); g.strokeStyle = 'rgba(90,70,40,.16)'; g.lineWidth = 1; for (let i = 0; i < z; i += 4) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i, z); g.moveTo(0, i); g.lineTo(z, i); g.stroke(); } speck(g, z, r, 200, 0.1, true); g.strokeStyle = '#7a5a34'; g.lineWidth = 12; g.strokeRect(0, 0, z, z); g.strokeStyle = 'rgba(60,44,24,.5)'; g.lineWidth = 2; g.strokeRect(8, 8, z - 16, z - 16); }),
      plank: tex(128, (g, z) => { const r = rnd(14); for (let i = 0; i < 4; i++) { const v = 150 + Math.floor(r() * 30); g.fillStyle = 'rgb(' + v + ',' + Math.floor(v * 0.68) + ',' + Math.floor(v * 0.4) + ')'; g.fillRect(0, i * 32, z, 32); g.strokeStyle = 'rgba(50,30,14,.25)'; g.lineWidth = 1; for (let k = 0; k < 5; k++) { const y = i * 32 + 4 + r() * 24; g.beginPath(); g.moveTo(0, y); g.bezierCurveTo(40, y + r() * 4 - 2, 90, y + r() * 4 - 2, z, y); g.stroke(); } g.fillStyle = 'rgba(40,24,10,.7)'; g.fillRect(0, i * 32, z, 2); g.fillStyle = '#4a3a2a'; g.fillRect(8, i * 32 + 14, 4, 4); g.fillRect(z - 12, i * 32 + 14, 4, 4); } }),
      stone: tex(128, (g, z) => { const r = rnd(15); g.fillStyle = '#5c5e64'; g.fillRect(0, 0, z, z); for (let y = 0; y < 2; y++) for (let x = 0; x < 2; x++) { const v = 150 + Math.floor(r() * 26); g.fillStyle = 'rgb(' + v + ',' + (v + 2) + ',' + (v + 8) + ')'; g.fillRect(x * 64 + (y ? 3 : 35) - 32, y * 64 + 3, 58, 58); g.fillRect(x * 64 + (y ? 3 : 35) + 96, y * 64 + 3, 58, 58); } speck(g, z, r, 300, 0.14, true); }),
      steel: tex(128, (g, z) => { const r = rnd(16); const gr = g.createLinearGradient(0, 0, z, z); gr.addColorStop(0, '#9aa8b6'); gr.addColorStop(1, '#748292'); g.fillStyle = gr; g.fillRect(0, 0, z, z); g.strokeStyle = 'rgba(255,255,255,.07)'; for (let i = 0; i < 40; i++) { const y = r() * z; g.beginPath(); g.moveTo(0, y); g.lineTo(z, y); g.stroke(); } g.strokeStyle = '#4c5866'; g.lineWidth = 6; g.strokeRect(3, 3, z - 6, z - 6); g.lineWidth = 3; g.beginPath(); g.moveTo(6, 6); g.lineTo(z - 6, z - 6); g.moveTo(z - 6, 6); g.lineTo(6, z - 6); g.stroke(); g.fillStyle = '#39424e'; for (const p of [[14, 14], [114, 14], [14, 114], [114, 114], [64, 14], [64, 114], [14, 64], [114, 64]]) { g.beginPath(); g.arc(p[0], p[1], 4, 0, TAU); g.fill(); } }),
      glass: tex(128, (g, z) => { g.fillStyle = '#bfe6e8'; g.fillRect(0, 0, z, z); g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 5; g.beginPath(); g.moveTo(20, 100); g.lineTo(100, 20); g.moveTo(50, 110); g.lineTo(110, 50); g.stroke(); g.strokeStyle = '#6fa3a8'; g.lineWidth = 8; g.strokeRect(0, 0, z, z); }),
      obsid: tex(128, (g, z) => { const r = rnd(17); g.fillStyle = '#2c2238'; g.fillRect(0, 0, z, z); for (let i = 0; i < 14; i++) { g.strokeStyle = 'rgba(170,140,230,' + (0.06 + r() * 0.12) + ')'; g.lineWidth = 1 + r() * 3; g.beginPath(); const x = r() * z, y = r() * z; g.moveTo(x, y); g.lineTo(x + r() * 60 - 30, y + r() * 60 - 30); g.stroke(); } g.strokeStyle = '#15101c'; g.lineWidth = 6; g.strokeRect(0, 0, z, z); }),
      cloud: tex(256, (g, z) => { const r = rnd(18); g.clearRect(0, 0, z, z); for (let i = 0; i < 46; i++) { const x = r() * z, y = r() * z, rr = 18 + r() * 44; for (const ox of [-z, 0, z]) for (const oy of [-z, 0, z]) { const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, rr); gr.addColorStop(0, 'rgba(255,255,255,.5)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(x + ox - rr, y + oy - rr, rr * 2, rr * 2); } } }, 5),
    };
    const MAT = {
      pave: new T.MeshStandardMaterial({ map: TX.pave, vertexColors: true, roughness: 0.92 }),
      rock: new T.MeshStandardMaterial({ map: TX.rock, vertexColors: true, roughness: 1, flatShading: true }),
      ashlar: new T.MeshStandardMaterial({ map: TX.pave, color: '#d6cebf', roughness: 0.9 }),
      column: new T.MeshStandardMaterial({ map: TX.rock, color: '#e6dccb', roughness: 0.85 }),
      blk: [null,
        new T.MeshStandardMaterial({ map: TX.canvas, roughness: 0.95 }),
        new T.MeshStandardMaterial({ map: TX.plank, roughness: 0.85 }),
        new T.MeshStandardMaterial({ map: TX.stone, roughness: 0.9 }),
        new T.MeshStandardMaterial({ map: TX.steel, roughness: 0.42, metalness: 0.65 }),
        new T.MeshStandardMaterial({ map: TX.glass, roughness: 0.15, transparent: true, opacity: 0.55 }),
        new T.MeshStandardMaterial({ map: TX.obsid, roughness: 0.22, metalness: 0.2 })],
    };
    const cmat = {}; const colMat = (c, o) => cmat[c + (o ? JSON.stringify(o) : '')] || (cmat[c + (o ? JSON.stringify(o) : '')] = new T.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.8 }, o)));
    /* 구름 바다 · 먼 바위 */
    const cloudM = new T.MeshBasicMaterial({ map: TX.cloud, transparent: true, opacity: 0.85, depthWrite: false, fog: true });
    const cloud = new T.Mesh(new T.PlaneGeometry(2400, 2400), cloudM); cloud.rotation.x = -Math.PI / 2; cloud.position.y = -46; scene.add(cloud);
    const cloud2M = cloudM.clone(); cloud2M.map = TX.cloud.clone(); cloud2M.map.repeat.set(3, 3); cloud2M.opacity = 0.5;
    const cloud2 = new T.Mesh(new T.PlaneGeometry(2400, 2400), cloud2M); cloud2.rotation.x = -Math.PI / 2; cloud2.position.y = -70; scene.add(cloud2);
    const under = new T.Mesh(new T.PlaneGeometry(3000, 3000), new T.MeshBasicMaterial({ color: 0x8f8d96, fog: true })); under.rotation.x = -Math.PI / 2; under.position.y = -90; scene.add(under);

    const worldG = new T.Group(); scene.add(worldG);
    const boxG = new T.BoxGeometry(CS, 1, CS);
    const tmpM = new T.Matrix4(), tmpV = new T.Vector3(), tmpV2 = new T.Vector3(), tmpQ = new T.Quaternion(), tmpS = new T.Vector3(1, 1, 1), tmpC = new T.Color();
    const hashP = (x, z) => { const s = Math.sin(x * 127.1 + z * 311.7) * 43758.5453; return s - Math.floor(s); };

    /* ======================= 세계 짓기 ======================= */
    let inst = [], cellSlot = new Map(), cores = [], genFx = [], chars = [], stormM = null, mapCv = null, ghost = null, crack = null, hl = null;
    function shadowOn(m, cast, recv) { m.castShadow = !!cast && !!TIER.shadow; m.receiveShadow = !!recv && !!TIER.shadow; return m; }
    function buildWorld() {
      while (worldG.children.length) { const o = worldG.children[0]; worldG.remove(o); o.traverse((q) => { if (q.geometry && q.geometry !== boxG) q.geometry.dispose(); }); }
      const M = W.M, isP = new Uint8Array(NX * NZ), kind = new Int8Array(NX * NZ).fill(-1), dist = new Int16Array(NX * NZ).fill(99);
      for (const p of M.plats) { isP[p[1] * NX + p[0]] = 1; kind[p[1] * NX + p[0]] = p[2]; }
      let q = [];
      for (const p of M.plats) { const x = p[0], z = p[1]; if (!isP[z * NX + x - 1] || !isP[z * NX + x + 1] || !isP[(z - 1) * NX + x] || !isP[(z + 1) * NX + x]) { dist[z * NX + x] = 0; q.push(z * NX + x); } }
      while (q.length) { const n = []; for (const i of q) for (const d of [-1, 1, -NX, NX]) if (isP[i + d] && dist[i + d] > dist[i] + 1) { dist[i + d] = dist[i] + 1; n.push(i + d); } q = n; }
      const depth = (cx, cz) => { let m = 99, all = true; for (const o of [[-1, -1], [0, -1], [-1, 0], [0, 0]]) { const i = (cz + o[1]) * NX + cx + o[0]; if (!isP[i]) all = false; else m = Math.min(m, dist[i]); } return all ? 2.2 + m * 2.6 + hashP(cx, cz) * 2.2 : 1.0 + hashP(cx, cz) * 0.7; };
      const tint = {}; const tintOf = (cx, cz) => tint[cz * NX + cx];
      const mix = (a, b, f) => new T.Color(a).lerp(new T.Color(b), f);
      const KC = ['#cfc3ad', '#b9c6c6', '#bdb3cc', '#b2bca2'];
      for (const b of M.bases) { if (b.t < 0) continue; const col = D.TEAMS[b.t].col; for (let dx = -1; dx <= 1; dx++) for (let dz = -1; dz <= 1; dz++) tint[(b.core[1] + dz) * NX + b.core[0] + dx] = mix(KC[0], col, 0.5); tint[b.sp[1] * NX + b.sp[0]] = mix(KC[0], col, 0.3); }
      for (const g of M.gens) tint[g.cz * NX + g.cx] = mix('#8c8c8c', D.RES[g.k].col, 0.55);
      const P1 = [], C1 = [], U1 = [], P2 = [], C2 = [], U2 = [];
      const tri = (P, C, U, a, b, c, ca, cb, cc, ua, ub, uc) => { P.push(a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]); C.push(ca.r, ca.g, ca.b, cb.r, cb.g, cb.b, cc.r, cc.g, cc.b); U.push(ua[0], ua[1], ub[0], ub[1], uc[0], uc[1]); };
      const rockTop = new T.Color('#b9b0a2'), rockLow = new T.Color('#6f6a70');
      const rc = (y) => rockTop.clone().lerp(rockLow, clamp(-y / 9, 0, 1));
      for (const p of M.plats) {
        const cx = p[0], cz = p[1], x0 = (cx - C0) * CS, z0 = (cz - C0) * CS, x1 = x0 + CS, z1 = z0 + CS;
        const tc = tintOf(cx, cz) || new T.Color(KC[p[2]]).multiplyScalar(0.94 + hashP(cx + 9, cz) * 0.1);
        tri(P1, C1, U1, [x0, 0, z0], [x0, 0, z1], [x1, 0, z1], tc, tc, tc, [0, 0], [0, 1], [1, 1]); tri(P1, C1, U1, [x0, 0, z0], [x1, 0, z1], [x1, 0, z0], tc, tc, tc, [0, 0], [1, 1], [1, 0]);
        const d00 = -depth(cx, cz), d10 = -depth(cx + 1, cz), d11 = -depth(cx + 1, cz + 1), d01 = -depth(cx, cz + 1);
        const a = [x0, d00, z0], b = [x1, d10, z0], c = [x1, d11, z1], d = [x0, d01, z1];
        tri(P2, C2, U2, a, b, c, rc(d00), rc(d10), rc(d11), [x0 / 6, z0 / 6], [x1 / 6, z0 / 6], [x1 / 6, z1 / 6]); tri(P2, C2, U2, a, c, d, rc(d00), rc(d11), rc(d01), [x0 / 6, z0 / 6], [x1 / 6, z1 / 6], [x0 / 6, z1 / 6]);
        const wall = (ax, az, bx, bz, da, db) => { const t0 = rc(0.6), A = [ax, 0, az], B = [bx, 0, bz], A2 = [ax, da, az], B2 = [bx, db, bz], u0 = (ax + az) / 6, u1 = (bx + bz) / 6; tri(P2, C2, U2, A, A2, B2, t0, rc(da), rc(db), [u0, 0], [u0, -da / 6], [u1, -db / 6]); tri(P2, C2, U2, A, B2, B, t0, rc(db), t0, [u0, 0], [u1, -db / 6], [u1, 0]); };
        if (!isP[cz * NX + cx - 1]) wall(x0, z0, x0, z1, d00, d01);
        if (!isP[cz * NX + cx + 1]) wall(x1, z1, x1, z0, d11, d10);
        if (!isP[(cz - 1) * NX + cx]) wall(x1, z0, x0, z0, d10, d00);
        if (!isP[(cz + 1) * NX + cx]) wall(x0, z1, x1, z1, d01, d11);
      }
      const mk = (P, C, U, mat) => { const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(P, 3)); g.setAttribute('color', new T.Float32BufferAttribute(C, 3)); g.setAttribute('uv', new T.Float32BufferAttribute(U, 2)); g.computeVertexNormals(); const m = new T.Mesh(g, mat); worldG.add(m); return m; };
      shadowOn(mk(P1, C1, U1, MAT.pave), false, true); shadowOn(mk(P2, C2, U2, MAT.rock), true, false);
      /* 석조(고정 칸) · 기둥 · 보급소 */
      const shopAt = new Set(); for (const b of M.bases) if (b.t >= 0) shopAt.add(b.shop[1] * NX + b.shop[0]);
      const rs = M.raised.filter((r) => r[3] === 10 && !shopAt.has(r[2] * NX + r[0]));
      if (rs.length) { const im = shadowOn(new T.InstancedMesh(boxG, MAT.ashlar, rs.length), true, true); rs.forEach((r, i) => { tmpM.compose(tmpV.set(S.wX(r[0]), r[1] - G0 + 0.5, S.wX(r[2])), tmpQ.identity(), tmpS.set(1, 1, 1)); im.setMatrixAt(i, tmpM); }); worldG.add(im); }
      const pilH = new Map(); for (const r of M.raised) if (r[3] === 11) pilH.set(r[2] * NX + r[0], Math.max(pilH.get(r[2] * NX + r[0]) || 0, r[1] - G0 + 1));
      if (pilH.size) {
        const n = pilH.size, shaft = shadowOn(new T.InstancedMesh(new T.CylinderGeometry(0.72, 0.8, 1, 10), MAT.column, n), true, true), cap = shadowOn(new T.InstancedMesh(new T.BoxGeometry(1.96, 0.26, 1.96), MAT.column, n * 2), true, true);
        let k = 0;
        for (const [q, hh] of pilH) {
          const x = S.wX(q % NX), z = S.wX(Math.floor(q / NX));
          tmpM.compose(tmpV.set(x, hh / 2, z), tmpQ.identity(), tmpS.set(1, hh - 0.5, 1)); shaft.setMatrixAt(k, tmpM);
          tmpM.compose(tmpV.set(x, 0.13, z), tmpQ.identity(), tmpS.set(1, 1, 1)); cap.setMatrixAt(k * 2, tmpM);
          tmpM.compose(tmpV.set(x, hh - 0.13, z), tmpQ.identity(), tmpS.set(1, 1, 1)); cap.setMatrixAt(k * 2 + 1, tmpM);
          for (const b of M.bases) if (b.t >= 0 && Math.hypot(b.x - x, b.z - z) < 13) {   // 거점 기둥에는 분대 깃발
            const fl = shadowOn(new T.Mesh(new T.BoxGeometry(0.06, 1.5, 1.0), colMat(D.TEAMS[b.t].col, { roughness: 0.95 })), true, false);
            fl.position.set(x + b.dir[0] * 0.86, hh - 1.15, z + b.dir[1] * 0.86); if (b.dir[1]) fl.rotation.y = Math.PI / 2; worldG.add(fl);
          }
          k++;
        }
        worldG.add(shaft, cap);
      }
      /* 풀 · 덤불(지나갈 수 있는 꾸밈) */
      {
        const skip = new Set(); for (const g of M.gens) skip.add(g.cz * NX + g.cx); for (const b of M.bases) { skip.add(b.sp[1] * NX + b.sp[0]); skip.add(b.core[1] * NX + b.core[0]); }
        const gg = new T.BufferGeometry(), gp = [];
        for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3, cx = Math.cos(a) * 0.16, cz = Math.sin(a) * 0.16; gp.push(-cx, 0, -cz, cx, 0, cz, cx * 0.2, 0.55, cz * 0.2 + 0.05, -cx * 1.7, 0, -cz * 1.7, -cx * 0.7, 0, -cz * 0.7, -cx * 1.5, 0.38, -cz * 1.5); }
        gg.setAttribute('position', new T.Float32BufferAttribute(gp, 3)); gg.computeVertexNormals();
        const spots = [], bush = [];
        for (const p of M.plats) {
          const q = p[1] * NX + p[0]; if (skip.has(q) || W.g[S.idx(p[0], G0, p[1])]) continue;
          const hv = hashP(p[0] * 3.1, p[1] * 1.7), dens = p[2] === 0 ? (dist[q] === 0 ? 0.5 : 0.12) : p[2] === 2 ? 0.3 : 0.7;
          if (hv > dens) continue;
          const n = 1 + Math.floor(hashP(p[0], p[1] * 5.3) * (TIER.id === 'low' ? 2 : 4));
          for (let k = 0; k < n; k++) spots.push([S.wX(p[0]) + (hashP(p[0] + k * 7.7, p[1]) - 0.5) * 1.7, S.wX(p[1]) + (hashP(p[0], p[1] + k * 3.3) - 0.5) * 1.7, hashP(p[0] * 9 + k, p[1] * 4)]);
          if (p[2] !== 0 && hashP(p[0] * 2.3, p[1] * 8.1) < 0.16) bush.push([S.wX(p[0]) + (hv - 0.3), S.wX(p[1]) + (hashP(p[1], p[0]) - 0.5), hv]);
        }
        if (spots.length) { const im = new T.InstancedMesh(gg, new T.MeshStandardMaterial({ color: '#ffffff', roughness: 1, side: T.DoubleSide }), spots.length); im.receiveShadow = !!TIER.shadow; spots.forEach((sp, i) => { const sc = 0.45 + sp[2] * 0.5; tmpM.compose(tmpV.set(sp[0], 0, sp[1]), tmpQ.setFromAxisAngle(tmpV2.set(0, 1, 0), sp[2] * 6.28), tmpS.set(sc, sc, sc)); im.setMatrixAt(i, tmpM); im.setColorAt(i, tmpC.setHSL(0.22 + sp[2] * 0.08, 0.34, 0.4 + sp[2] * 0.16)); }); worldG.add(im); }
        if (bush.length) { const im = shadowOn(new T.InstancedMesh(new T.IcosahedronGeometry(0.42, 0), new T.MeshStandardMaterial({ color: '#ffffff', roughness: 1, flatShading: true }), bush.length), true, true); bush.forEach((sp, i) => { tmpM.compose(tmpV.set(sp[0], 0.2, sp[1]), tmpQ.setFromAxisAngle(tmpV2.set(0, 1, 0), sp[2] * 9), tmpS.set(1 + sp[2], 0.7 + sp[2] * 0.5, 1 + sp[2] * 0.6)); im.setMatrixAt(i, tmpM); im.setColorAt(i, tmpC.setHSL(0.27 + sp[2] * 0.06, 0.3, 0.24 + sp[2] * 0.1)); }); worldG.add(im); }
      }
      /* 놓는 칸(인스턴싱) */
      inst = [null]; cellSlot = new Map();
      for (let m = 1; m <= 6; m++) { const cap = m <= 2 ? 3000 : 1200, im = shadowOn(new T.InstancedMesh(boxG, MAT.blk[m], cap), m !== 5, true); im.count = 0; im.frustumCulled = false; worldG.add(im); inst.push({ im, cells: new Int32Array(cap), n: 0, cap }); }
      /* 핵 · 보급소 · 생성기 */
      cores = []; genFx = [];
      const octa = new T.OctahedronGeometry(0.62, 0);
      for (const tm of W.tm) {
        const b = tm.b, col = D.TEAMS[tm.t].col, g = new T.Group(); g.position.set(b.cx, 0, b.cz);
        const ped = shadowOn(new T.Mesh(new T.CylinderGeometry(0.75, 0.92, 0.5, 8), colMat('#6b6570', { roughness: 0.7 })), true, true); ped.position.y = 0.25; g.add(ped);
        const ring = new T.Mesh(new T.TorusGeometry(0.8, 0.07, 6, 20), colMat(col, { emissive: col, emissiveIntensity: 0.6 })); ring.rotation.x = Math.PI / 2; ring.position.y = 0.52; g.add(ring);
        const cry = shadowOn(new T.Mesh(octa, new T.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.85, roughness: 0.25, flatShading: true })), true, false); cry.scale.set(1, 1.35, 1); cry.position.y = 1.3; g.add(cry);
        const shd = new T.Mesh(new T.SphereGeometry(1.75, 20, 14), new T.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.2, depthWrite: false })); shd.position.y = 1.1; g.add(shd);
        worldG.add(g); cores.push({ tm, g, cry, ring, shd, on: true });
        const sx = S.wX(b.shop[0]), sz = S.wX(b.shop[1]), sg = new T.Group(); sg.position.set(sx, 2, sz);
        const aw = shadowOn(new T.Mesh(new T.BoxGeometry(2.7, 0.14, 2.7), colMat(col, { roughness: 0.9 })), true, false); aw.position.y = 0.45; aw.rotation.z = 0.14; sg.add(aw);
        const cnt = shadowOn(new T.Mesh(new T.BoxGeometry(1.96, 1.0, 1.96), MAT.blk[2]), true, true); cnt.position.y = -1.5; sg.add(cnt);
        const top = shadowOn(new T.Mesh(new T.BoxGeometry(2.1, 0.1, 2.1), colMat('#5a4630')), true, true); top.position.y = -0.96; sg.add(top);
        const bk = new T.Mesh(new T.BoxGeometry(1.96, 1.0, 0.12), colMat('#4a3a2a')); bk.position.set(-b.dir[0] * 0.92, -0.45, -b.dir[1] * 0.92); if (b.dir[0]) bk.rotation.y = Math.PI / 2; sg.add(bk);
        for (let q = 0; q < 3; q++) { const it = new T.Mesh(new T.BoxGeometry(0.34, 0.26, 0.34), q === 0 ? MAT.blk[1] : q === 1 ? MAT.blk[3] : MAT.blk[4]); it.position.set((q - 1) * 0.55 * Math.abs(b.dir[1]) , -0.78, (q - 1) * 0.55 * Math.abs(b.dir[0])); sg.add(it); }
        for (const o of [[-0.92, -0.92], [0.92, -0.92], [-0.92, 0.92], [0.92, 0.92]]) { const po = new T.Mesh(new T.BoxGeometry(0.1, 1.4, 0.1), colMat('#6a5234')); po.position.set(o[0], -0.28, o[1]); sg.add(po); }
        const cr = new T.Mesh(new T.BoxGeometry(0.7, 0.5, 0.7), MAT.blk[2]); cr.position.set(-b.dir[1] * 1.45 - b.dir[0] * 0.4, -1.75, b.dir[0] * 1.45 - b.dir[1] * 0.4); sg.add(shadowOn(cr, true, true));
        worldG.add(sg);
      }
      W.gens.forEach((gn) => {
        const g = new T.Group(); g.position.set(gn.x, 0, gn.z); const col = D.RES[gn.k].col;
        const pad = shadowOn(new T.Mesh(new T.CylinderGeometry(0.85, 0.95, 0.12, 12), colMat('#4c4a52', { metalness: 0.5, roughness: 0.5 })), false, true); pad.position.y = 0.06; g.add(pad);
        const rg = new T.Mesh(new T.TorusGeometry(0.7, 0.05, 6, 20), colMat(col, { emissive: col, emissiveIntensity: 0.7 })); rg.rotation.x = Math.PI / 2; rg.position.y = 0.13; g.add(rg);
        const item = new T.Mesh(gn.k === 0 ? new T.BoxGeometry(0.5, 0.18, 0.26) : gn.k === 1 ? new T.OctahedronGeometry(0.3, 0) : new T.IcosahedronGeometry(0.3, 0), new T.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: gn.k ? 0.6 : 0.15, roughness: 0.35, metalness: gn.k ? 0 : 0.7, flatShading: true })); item.position.y = 0.9; g.add(item);
        const cv = document.createElement('canvas'); cv.width = 128; cv.height = 64; const tx = new T.CanvasTexture(cv); tx.colorSpace = T.SRGBColorSpace;
        const sp = new T.Sprite(new T.SpriteMaterial({ map: tx, transparent: true, depthWrite: false })); sp.scale.set(1.6, 0.8, 1); sp.position.y = 1.75; g.add(sp);
        worldG.add(g); genFx.push({ gn, g, item, cv, tx, sp, shown: -1 });
      });
      /* 소멸의 고리 */
      stormM = new T.Mesh(new T.CylinderGeometry(1, 1, 60, 64, 1, true), new T.ShaderMaterial({ transparent: true, side: T.DoubleSide, depthWrite: false, fog: false, uniforms: { t: { value: 0 } },
        vertexShader: 'varying vec2 u; void main(){ u = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
        fragmentShader: 'varying vec2 u; uniform float t; void main(){ float w = 0.5 + 0.5 * sin(u.x * 80.0 + u.y * 9.0 - t * 0.9); float a = (0.16 + 0.14 * w) * smoothstep(0.0, 0.25, u.y) * smoothstep(1.0, 0.55, u.y); gl_FragColor = vec4(0.82, 0.28, 0.42, a); }' }));
      stormM.position.y = 8; stormM.visible = false; stormM.frustumCulled = false; worldG.add(stormM);
      /* 놓을 자리 · 부수는 칸 표시 */
      ghost = new T.Mesh(boxG, new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.28, depthWrite: false })); ghost.visible = false; worldG.add(ghost);
      hl = new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(CS + 0.04, 1.04, CS + 0.04)), new T.LineBasicMaterial({ color: 0xffe2a0, transparent: true, opacity: 0.9 })); hl.visible = false; worldG.add(hl);
      crack = new T.Mesh(new T.BoxGeometry(CS + 0.03, 1.03, CS + 0.03), new T.MeshBasicMaterial({ color: 0x100c0a, transparent: true, opacity: 0, depthWrite: false })); crack.visible = false; worldG.add(crack);
      /* 먼 바위 */
      { const r = rnd(W.st.seed + 5), n = 16, im = new T.InstancedMesh(new T.IcosahedronGeometry(1, 0), MAT.rock, n); for (let i = 0; i < n; i++) { const a = r() * TAU, d = 260 + r() * 260, s = 8 + r() * 22; tmpM.compose(tmpV.set(Math.cos(a) * d, -20 + r() * 70, Math.sin(a) * d), tmpQ.setFromEuler(new T.Euler(r(), r() * 6, r())), tmpS.set(s, s * (0.5 + r() * 0.5), s)); im.setMatrixAt(i, tmpM); im.setColorAt(i, tmpC.set('#cfc6ba')); } worldG.add(im); }
      /* 분대원 */
      for (const c of chars) scene.remove(c.root);
      chars = W.chars.map((c) => mkChar(c));
      /* 작은 지도 바탕 */
      mapCv = document.createElement('canvas'); mapCv.width = mapCv.height = 144; { const g = mapCv.getContext('2d'); for (const p of M.plats) { g.fillStyle = ['#b5aa94', '#8fa6aa', '#a595c2', '#93a082'][p[2]]; g.fillRect(p[0] * 2, p[1] * 2, 2, 2); } }
      for (const i of W.touched) updateCell(i);
      W.chg.length = 0;
    }
    function cellMatrix(i, m) {
      const thin = m <= 2 && !W.g[i - LY] && !W.g[i + LY], y = S.iY(i) - G0;
      tmpM.compose(tmpV.set(S.wX(S.iX(i)), thin ? y + 0.8 : y + 0.5, S.wX(S.iZ(i))), tmpQ.identity(), tmpS.set(1, thin ? 0.4 : 1, 1));
      return tmpM;
    }
    function updateCell(i, noNb) {
      const cur = cellSlot.get(i), id = W.g[i], m = id >= 1 && id <= 6 ? id : 0;
      if (cur && cur[0] !== m) {
        const I = inst[cur[0]], lastI = I.n - 1, sl = cur[1];
        if (sl !== lastI) { const lc = I.cells[lastI]; I.im.getMatrixAt(lastI, tmpM); I.im.setMatrixAt(sl, tmpM); I.cells[sl] = lc; cellSlot.set(lc, [cur[0], sl]); }
        I.n--; I.im.count = I.n; I.im.instanceMatrix.needsUpdate = true; cellSlot.delete(i);
      }
      if (m) {
        const I = inst[m]; let sl;
        if (cur && cur[0] === m) sl = cur[1]; else { if (I.n >= I.cap) return; sl = I.n++; I.cells[sl] = i; cellSlot.set(i, [m, sl]); I.im.count = I.n; }
        I.im.setMatrixAt(sl, cellMatrix(i, m)); I.im.instanceMatrix.needsUpdate = true;
      }
      if (!noNb) { if (i - LY >= 0 && cellSlot.has(i - LY)) updateCell(i - LY, true); if (i + LY < S.NC && cellSlot.has(i + LY)) updateCell(i + LY, true); }
    }

    /* ======================= 분대원 모형 ======================= */
    const ARC = ['#000', '#b9b2a2', '#c9cdd4', '#7fe0e8'];
    function mkChar(c) {
      const col = D.TEAMS[c.t].col, root = new T.Group(), body = new T.Group(); root.add(body);
      const cloth = new T.MeshStandardMaterial({ color: col, roughness: 0.85 }), dark = new T.MeshStandardMaterial({ color: '#2b2a33', roughness: 0.8 }), skin = new T.MeshStandardMaterial({ color: '#d9c2a6', roughness: 0.8 }), arm = new T.MeshStandardMaterial({ color: '#8a8f99', roughness: 0.5, metalness: 0.5 });
      const mats = [cloth, dark, skin, arm];
      const box = (w, hh, d, m, x, y, z, par) => { const o = shadowOn(new T.Mesh(new T.BoxGeometry(w, hh, d), m), true, false); o.position.set(x, y, z); (par || body).add(o); return o; };
      box(0.56, 0.6, 0.32, cloth, 0, 1.08, 0); box(0.5, 0.2, 0.3, dark, 0, 0.74, 0); box(0.6, 0.1, 0.36, dark, 0, 0.86, 0);
      const head = box(0.34, 0.34, 0.34, skin, 0, 1.58, 0); box(0.4, 0.2, 0.4, cloth, 0, 0.14, 0, head); box(0.36, 0.08, 0.06, dark, 0, 0.02, 0.19, head);
      box(0.36, 0.42, 0.16, dark, 0, 1.1, -0.24);
      const pads = [box(0.24, 0.12, 0.34, arm, -0.37, 1.4, 0), box(0.24, 0.12, 0.34, arm, 0.37, 1.4, 0), box(0.5, 0.36, 0.06, arm, 0, 1.14, 0.18)];
      const limb = (x, y, w, hh, d, m) => { const g = new T.Group(); g.position.set(x, y, 0); body.add(g); box(w, hh, d, m, 0, -hh / 2, 0, g); return g; };
      const aL = limb(-0.37, 1.34, 0.16, 0.6, 0.16, cloth), aR = limb(0.37, 1.34, 0.16, 0.6, 0.16, cloth), lL = limb(-0.14, 0.72, 0.2, 0.72, 0.22, dark), lR = limb(0.14, 0.72, 0.2, 0.72, 0.22, dark);
      const hand = new T.Group(); hand.position.set(0, -0.58, 0.06); aR.add(hand);
      const blade = new T.MeshStandardMaterial({ color: '#c9cdd4', roughness: 0.3, metalness: 0.8 });
      const sword = new T.Group(); box(0.07, 0.9, 0.03, blade, 0, 0.5, 0, sword); box(0.26, 0.05, 0.07, dark, 0, 0.05, 0, sword); sword.rotation.x = Math.PI / 2; hand.add(sword);
      const pick = new T.Group(); box(0.05, 0.8, 0.05, colMat('#7a5a34'), 0, 0.4, 0, pick); box(0.6, 0.07, 0.07, blade, 0, 0.78, 0, pick); pick.rotation.x = Math.PI / 2; hand.add(pick);
      const bow = new T.Group(); box(0.08, 0.08, 0.7, colMat('#7a5a34'), 0, 0, 0.3, bow); box(0.7, 0.05, 0.06, blade, 0, 0, 0.56, bow); hand.add(bow);
      const blk = box(0.34, 0.17, 0.34, MAT.blk[1], 0, 0, 0.26, hand);
      const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64; const tx = new T.CanvasTexture(cv); tx.colorSpace = T.SRGBColorSpace;
      const tag = new T.Sprite(new T.SpriteMaterial({ map: tx, transparent: true, depthWrite: false })); tag.scale.set(2.6, 0.65, 1); tag.position.y = 2.25; root.add(tag);
      scene.add(root);
      return { c, root, body, head, aL, aR, lL, lR, sword, pick, bow, blk, blade, pads, arm, mats, tag, cv, tx, tagKey: '', ph: 0, swN: c.swN, swT: 9, px: c.x, py: c.y, pz: c.z, lx: c.x, lz: c.z, spd: 0, op: 1 };
    }
    function drawTag(o, me) {
      const c = o.c, key = Math.round(c.hp / 4) + '|' + (c.fx.mark > W.t ? 1 : 0) + '|' + me; if (key === o.tagKey) return; o.tagKey = key;
      const g = o.cv.getContext('2d'), col = D.TEAMS[c.t].col; g.clearRect(0, 0, 256, 64);
      g.font = '600 26px "IBM Plex Sans KR",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = 5; g.strokeStyle = 'rgba(10,10,16,.85)'; const nm = nmOf(c.s); g.strokeText(nm, 128, 20); g.fillStyle = c.fx.mark > W.t ? '#ffb070' : '#fff'; g.fillText(nm, 128, 20);
      g.fillStyle = 'rgba(10,10,16,.75)'; g.fillRect(48, 42, 160, 12); g.fillStyle = col; g.fillRect(50, 44, 156 * clamp(c.hp / 100, 0, 1), 8);
      o.tx.needsUpdate = true;
    }
    function tickChar(o, a, rdt, me) {
      const c = o.c, mine = c.s === me;
      let x, y, z;
      if (c.here2) { x = c.ox + (c.x - c.ox) * a; y = c.oy + (c.y - c.oy) * a; z = c.oz + (c.z - c.oz) * a; } else { x = c.x; y = c.y; z = c.z; }
      o.px = x; o.py = y; o.pz = z;
      const vis = c.al && !(mine && camClose);
      o.root.visible = !!vis; if (!vis) return;
      o.root.position.set(x, y, z);
      const sp = Math.hypot(x - o.lx, z - o.lz) / Math.max(1e-3, rdt * SPD()); o.lx = x; o.lz = z; o.spd += (Math.min(8, sp) - o.spd) * Math.min(1, rdt * 10);
      o.body.rotation.y = mine && meHum() ? yaw : c.yaw;
      o.ph += o.spd * rdt * SPD() * 1.9;
      const sw = Math.sin(o.ph) * 0.75 * Math.min(1, o.spd / 4.5), air = c.gr ? 0 : 0.35;
      o.lL.rotation.x = sw + air; o.lR.rotation.x = -sw - air * 0.5; o.aL.rotation.x = -sw * 0.8;
      if (c.swN !== o.swN) { o.swN = c.swN; o.swT = 0; }
      o.swT += rdt * SPD();
      const k = o.swT < 0.3 ? o.swT / 0.3 : 1, rg = c.hand === 1 && c.rg > 0, brk = c.atk && c.bkI >= 0;
      let ax = sw * 0.8;
      if (rg) ax = -1.45 - (mine ? pit : c.pit) * 0.8; else if (c.bld) ax = -1.1; else if (k < 1) ax = -2.3 + 2.6 * k * (2 - k); else if (c.atk) ax = -0.6;
      o.aR.rotation.x = ax;
      o.bow.visible = rg; o.blk.visible = !rg && !!c.bld; o.pick.visible = !rg && !c.bld && !!brk && c.pk > 0; o.sword.visible = !rg && !c.bld && !o.pick.visible;
      if (c.fx.cloak > W.t && me >= 0 && c.t !== W.chars[me].t) o.bow.visible = o.blk.visible = o.pick.visible = o.sword.visible = false;
      if (o.blk.visible && o.blk.material !== MAT.blk[c.sb]) o.blk.material = MAT.blk[c.sb] || MAT.blk[1];
      const bc = c.ml === 4 ? '#8f8a80' : ['#b08a5a', '#c9cdd4', '#e0c66a', '#7fe0e8'][c.ml] || '#c9cdd4'; if (o.bladeC !== bc) { o.bladeC = bc; o.blade.color.set(bc); }
      if (o.arT !== c.ar) { o.arT = c.ar; for (const p of o.pads) p.visible = c.ar > 0; if (c.ar) o.arm.color.set(ARC[c.ar]); }
      const myT = me >= 0 ? W.chars[me].t : -1, cl = c.fx.cloak > W.t, op = cl ? (c.t === myT ? 0.4 : 0.07) : c.inv > W.t ? 0.6 + 0.25 * Math.sin(wallT * 9) : 1;
      if (op !== o.op) { o.op = op; for (const m of o.mats) { m.transparent = op < 1; m.opacity = op; } o.blade.transparent = op < 1; o.blade.opacity = op; }
      o.tag.visible = !mine && !(cl && c.t !== myT);
      if (o.tag.visible) { const dd = Math.hypot(x - cam.position.x, y - cam.position.y, z - cam.position.z); if (dd < 3.2) o.tag.visible = false; else { const sc = clamp(dd * 0.085, 0.5, 6); o.tag.scale.set(sc, sc * 0.25, 1); drawTag(o, me); o.tag.material.depthTest = !(c.fx.mark > W.t && c.t !== myT); } }
    }

    /* ======================= 효과(조각 · 번쩍임 · 투사체) ======================= */
    const NP = 220, pim = new T.InstancedMesh(new T.BoxGeometry(0.2, 0.2, 0.2), new T.MeshStandardMaterial({ roughness: 0.9 }), NP); pim.frustumCulled = false; pim.count = NP; scene.add(pim);
    const PT = []; for (let i = 0; i < NP; i++) { PT.push({ l: 0, x: 0, y: -999, z: 0, vx: 0, vy: 0, vz: 0, s: 1 }); pim.setColorAt(i, tmpC.set('#fff')); }
    let pn = 0;
    function burst(x, y, z, col, n, sp, up) {
      for (let i = 0; i < n; i++) { const p = PT[pn]; const a = Math.random() * TAU, u = Math.random(); p.x = x + (Math.random() - 0.5) * 0.8; p.y = y + (Math.random() - 0.5) * 0.5; p.z = z + (Math.random() - 0.5) * 0.8; p.vx = Math.cos(a) * sp * u; p.vz = Math.sin(a) * sp * u; p.vy = up * (0.4 + Math.random() * 0.8); p.l = 0.5 + Math.random() * 0.5; p.s = 0.6 + Math.random() * 0.9; pim.setColorAt(pn, tmpC.set(col)); pn = (pn + 1) % NP; }
      pim.instanceColor.needsUpdate = true;
    }
    function pTick(dt) {
      for (let i = 0; i < NP; i++) { const p = PT[i]; if (p.l <= 0) { if (p.y > -900) { p.y = -999; tmpM.makeScale(0, 0, 0); pim.setMatrixAt(i, tmpM); } continue; } p.l -= dt; p.vy -= 18 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; const s = p.s * Math.min(1, p.l * 3); tmpM.compose(tmpV.set(p.x, p.y, p.z), tmpQ.identity(), tmpS.set(s, s, s)); pim.setMatrixAt(i, tmpM); }
      pim.instanceMatrix.needsUpdate = true;
    }
    const flashes = []; for (let i = 0; i < 5; i++) { const m = new T.Mesh(new T.SphereGeometry(1, 16, 10), new T.MeshBasicMaterial({ color: 0xffc070, transparent: true, opacity: 0, depthWrite: false, blending: T.AdditiveBlending, fog: false })); m.visible = false; scene.add(m); flashes.push({ m, t: 9, r: 1 }); }
    function flash(x, y, z, r) { const f = flashes.sort((a, b) => b.t - a.t)[0]; f.t = 0; f.r = r; f.m.position.set(x, y, z); f.m.visible = true; }
    function flashTick(dt) { const fx = L.fx ? L.fx() : 1; for (const f of flashes) { if (!f.m.visible) continue; f.t += dt; const k = f.t / 0.45; if (k >= 1) { f.m.visible = false; continue; } const s = f.r * (0.3 + 0.7 * Math.sqrt(k)); f.m.scale.set(s, s, s); f.m.material.opacity = (1 - k) * 0.75 * (0.35 + 0.65 * fx); } }
    const PJG = [new T.BoxGeometry(0.06, 0.06, 0.8), new T.SphereGeometry(0.22, 10, 8), new T.CylinderGeometry(0.22, 0.22, 0.42, 10), new T.SphereGeometry(0.28, 10, 8), new T.OctahedronGeometry(0.22, 0), new T.BoxGeometry(0.3, 0.3, 0.3)];
    const PJM = [colMat('#e8e2d0'), colMat('#9fb6d0', { emissive: '#3a5a80' }), colMat('#b5553f'), new T.MeshBasicMaterial({ color: 0xffa040 }), colMat('#7fd0d8', { emissive: '#3a8088' }), colMat('#c9b58a')];
    const pjPool = [];
    function pjTick(rdt) {
      let n = 0; const list = W.pj, tn = W.tnt;
      const get = (k) => { let o = pjPool[n]; if (!o) { o = new T.Mesh(PJG[0], PJM[0]); scene.add(o); pjPool.push(o); } n++; const gi = k <= 2 ? 0 : k === 3 ? 1 : k === 10 ? 2 : k === 11 ? 3 : k === 12 ? 4 : 5; if (o.geometry !== PJG[gi]) { o.geometry = PJG[gi]; o.material = PJM[gi]; } o.visible = true; o.scale.set(1, 1, 1); return o; };
      for (const p of list) { if (!isHost()) { p.vy -= (p.g || 0) * rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.z += p.vz * rdt; } const o = get(p.k); o.position.set(p.x, p.y, p.z); if (p.k <= 2) o.lookAt(p.x + p.vx, p.y + p.vy, p.z + p.vz); else o.rotation.set(0, 0, 0); }
      for (const q of tn) { const o = get(10); o.position.set(q.x, q.y, q.z); const left = Math.max(0, q.t - W.t), s = 1 + 0.18 * Math.sin((2.4 - left) * (2.4 - left) * 9); o.scale.set(s, s, s); o.rotation.set(0, 0, 0); }
      for (let i = n; i < pjPool.length; i++) pjPool[i].visible = false;
    }

    /* ======================= 소리(합성) ======================= */
    let AC = null, noiseBuf = null;
    function ac() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); const n = AC.sampleRate * 0.6; noiseBuf = AC.createBuffer(1, n, AC.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; } catch (e) { AC = null; } } return AC; }
    function snd(kind, x, y, z, vv) {
      const base = L.audio && L.audio.sfx ? L.audio.sfx() : 1; if (!base || SPD() > 2) return;
      const a = ac(); if (!a) return; if (a.state !== 'running') { a.resume().catch(() => {}); return; }
      let vol = base * (vv || 1); if (x != null) { const d = Math.hypot(x - cam.position.x, y - cam.position.y, z - cam.position.z); if (d > 70) return; vol *= 1 / (1 + d / 9); }
      const t = a.currentTime, out = a.createGain(); out.connect(a.destination);
      const tone = (f0, f1, dur, type, v) => { const o = a.createOscillator(), g = a.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur); g.gain.setValueAtTime(v * vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur); o.connect(g); g.connect(out); o.start(t); o.stop(t + dur + 0.02); };
      const noise = (dur, f, v, q) => { const s = a.createBufferSource(), g = a.createGain(), fl = a.createBiquadFilter(); s.buffer = noiseBuf; fl.type = q ? 'bandpass' : 'lowpass'; fl.frequency.setValueAtTime(f, t); if (!q) fl.frequency.exponentialRampToValueAtTime(Math.max(60, f * 0.25), t + dur); g.gain.setValueAtTime(v * vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur); s.connect(fl); fl.connect(g); g.connect(out); s.start(t); s.stop(t + dur + 0.02); };
      if (kind === 'pl') { tone(220, 150, 0.07, 'triangle', 0.35); noise(0.05, 1800, 0.18); }
      else if (kind === 'bk') { noise(0.16, 1400, 0.45); tone(140, 70, 0.12, 'square', 0.12); }
      else if (kind === 'dig') noise(0.05, 900, 0.16);
      else if (kind === 'sw') noise(0.12, 2600, 0.14, true);
      else if (kind === 'hit') { tone(190, 80, 0.12, 'sawtooth', 0.3); noise(0.08, 700, 0.3); }
      else if (kind === 'shot') { tone(520, 180, 0.12, 'triangle', 0.3); noise(0.05, 3000, 0.12, true); }
      else if (kind === 'boom') { noise(0.55, 900, 0.9); tone(90, 30, 0.5, 'sine', 0.7); }
      else if (kind === 'buy') { tone(660, 660, 0.07, 'sine', 0.25); tone(990, 990, 0.14, 'sine', 0.2); }
      else if (kind === 'get') tone(880, 1320, 0.07, 'sine', 0.14);
      else if (kind === 'core') { tone(330, 300, 0.25, 'triangle', 0.4); tone(660, 600, 0.2, 'sine', 0.15); }
      else if (kind === 'coreX') { tone(110, 40, 1.1, 'sawtooth', 0.5); noise(0.9, 500, 0.6); }
      else if (kind === 'warn') { tone(440, 440, 0.12, 'square', 0.16); }
      else if (kind === 'no') tone(160, 120, 0.12, 'square', 0.14);
      else if (kind === 'die') { tone(260, 60, 0.4, 'sawtooth', 0.25); }
      else if (kind === 'ph') { tone(392, 392, 0.2, 'sine', 0.2); tone(523, 523, 0.35, 'sine', 0.18); }
    }

    /* ======================= HUD ======================= */
    const hud = h('div', { class: 'bw-hud' }); wrap.append(hud);
    const vig = h('div', { class: 'bw-vig' }), topEl = h('div', { class: 'bw-top' }), teamsEl = h('div', { class: 'bw-teams' }), phaseEl = h('div', { class: 'bw-phase' });
    topEl.append(teamsEl, phaseEl);
    const mapEl = h('canvas', { class: 'bw-map' }), feedEl = h('div', { class: 'bw-feed' }), noteEl = h('div', { class: 'bw-note' }), tipEl = h('div', { class: 'bw-tip', style: { display: 'none' } }), keysEl = h('div', { class: 'bw-keys' });
    const botEl = h('div', { class: 'bw-bot' }), resEl = h('div', { class: 'bw-res' }), hpEl = h('div', { class: 'bw-hp' }, h('div'), h('span')), barEl = h('div', { class: 'bw-bar' });
    botEl.append(resEl, barEl);
    const crossEl = h('div', { class: 'bw-cross' }); crossEl.innerHTML = '<svg viewBox="0 0 22 22" width="22" height="22"><circle cx="11" cy="11" r="1.6" fill="#fff"/><circle cx="11" cy="11" r="7.5" fill="none" stroke="rgba(255,255,255,.55)" stroke-width="1.2"/><circle class="pg" cx="11" cy="11" r="9.5" fill="none" stroke="#e3ae45" stroke-width="2.4" stroke-dasharray="0 60" transform="rotate(-90 11 11)"/></svg>';
    const pgEl = crossEl.querySelector('.pg');
    const deadEl = h('div', { class: 'bw-dead', style: { display: 'none' } }), scoreEl = h('div', { class: 'bw-score', style: { display: 'none' } });
    const ctlEl = h('div', { class: 'bw-ctl' }), stick = h('div', { class: 'bw-stick' }, h('i'));
    hud.append(vig, mapEl, topEl, feedEl, crossEl, tipEl, noteEl, keysEl, botEl, deadEl, scoreEl, ctlEl, stick);
    let noteT = 0;
    function note(t, cls) { noteEl.textContent = t; noteEl.className = 'bw-note' + (cls ? ' ' + cls : ''); noteEl.style.opacity = '1'; noteT = 1.5; }
    const nmOf = (s) => String((api.players[s] && api.players[s].name) || (st && st.nm && st.nm[s]) || (s + 1) + '번').slice(0, 10);
    const tspan = (s) => '<span style="color:' + D.TEAMS[W.chars[s].t].col + '">' + nmOf(s).replace(/[<&]/g, '') + '</span>';
    function feed(html) { const d = h('div'); d.innerHTML = html; feedEl.append(d); while (feedEl.children.length > 4) feedEl.firstChild.remove(); setTimeout(() => { d.style.opacity = '0'; setTimeout(() => d.remove(), 450); }, 4200); }

    /* 물건 줄 */
    let barKey = '', slots = [];
    function slotList(c) {
      const o = [{ k: 'h1', ic: c.ml === 4 ? D.IC.club('#9aa0aa') : D.IC.sword(['#b08a5a', '#c9cdd4', '#e0c66a', '#7fe0e8'][c.ml]), on: c.hand === 0, tip: D.MELEE[c.ml].nm, key: 'h1' }];
      if (c.rg) o.push({ k: 'h2', ic: c.rg === 3 ? D.IC.cannon('#8f9aa8') : D.IC.xbow(c.rg === 2 ? '#7fe0e8' : '#c9cdd4'), n: c.am, on: c.hand === 1, tip: D.RANGED[c.rg].nm, key: 'h2', off: c.am < D.RANGED[c.rg].use });
      const nb = S.blocks(c);
      o.push({ k: 'mat', ic: D.IC.slab(D.BLK[nb ? S.pickMat(c) : c.sb].col), n: c.b[c.sb] || 0, tip: D.BLK[c.sb].nm + (nb ? '' : ' 없음'), key: 'mat', off: !nb });
      let q = 0;
      c.it.forEach((n, ci) => { if (n > 0) { const cc = D.CONS[ci], e = D.SHOP[D.SI['c_' + cc.id]]; o.push({ k: 'use', ci, ic: D.entryIcon(e), n, tip: cc.nm, key: q < 8 ? 'i' + ((q + 3) % 10) : '' }); q++; } });
      return o;
    }
    function drawBar(c) {
      slots = slotList(c);
      const key = slots.map((s) => s.k + (s.ci != null ? s.ci : '') + ':' + (s.n != null ? s.n : '') + (s.on ? 'o' : '') + (s.off ? 'x' : '') + s.ic.length + c.sb + c.ml).join('|') + touchUI;
      if (key === barKey) return; barKey = key;
      barEl.innerHTML = '';
      slots.forEach((s) => {
        const b = h('button', { class: 'bw-slot' + (s.on ? ' on' : '') + (s.off ? ' off' : ''), title: s.tip });
        b.innerHTML = D.svgW(s.ic) + (s.n != null ? '<em>' + s.n + '</em>' : '') + (!touchUI && s.key ? '<kbd>' + ((L.ui && L.ui.keyLabel && L.ui.keyLabel('bedwar', s.key)) || '') + '</kbd>' : '');
        b.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); slotAct(s); });
        barEl.append(b);
      });
    }
    function slotAct(s) { if (s.k === 'h1') inp.hand = 0; else if (s.k === 'h2') inp.hand = 1; else if (s.k === 'mat') inp.mat = 1; else if (s.k === 'use') inp.use = s.ci; }
    function useSlot(q) { const u = slots.filter((s) => s.k === 'use'); if (u[q]) inp.use = u[q].ci; else note('그 칸에 물건 없음'); }

    /* 보급소 창 */
    let shopEl = null, shopTab = 'build', shopT = 0, shopFoot = null;
    function shopOpen() {
      const me = ME(), c = me >= 0 ? W.chars[me] : null; if (!c || !humanHere(me)) return;
      if (shopEl) { shopClose(); return; }
      if (!c.al) { note('쓰러진 동안에는 열 수 없음'); return; }
      const b = W.tm[c.t].b; if (Math.hypot(c.x - b.x, c.z - b.z) > S.BASE_R + 2) { note('보급소는 자기 섬 안에서만 열림', 'warn'); return; }
      shopEl = h('div', { class: 'bw-shop' }); shopEl.style.zoom = uiK; hud.append(shopEl); FL.exit(); shopDraw(true);
    }
    function shopClose() { if (shopEl) { shopEl.remove(); shopEl = null; FL.kick(); } }
    function priceHTML(cost) { let s = ''; for (let i = 0; i < 3; i++) if (cost[i]) s += '<span><i style="background:' + D.RES[i].col + '"></i>' + D.RES[i].nm + ' ' + cost[i] + '</span>'; return s; }
    function shopDraw(full) {
      const me = ME(), c = W.chars[me]; if (!shopEl || !c) return;
      if (full) {
        shopEl.innerHTML = '';
        const head = h('header', {}, h('strong', { text: '보급소' }), h('div', { class: 'bw-res sh-res' }), h('div', { class: 'sp' }), h('button', { class: 'bw-x', 'aria-label': '닫기', text: '✕', onclick: shopClose }));
        const tabs = h('div', { class: 'bw-tabs' });
        for (const t of D.TABS) tabs.append(h('button', { class: 'bw-tab' + (t[0] === shopTab ? ' on' : ''), text: t[1], onclick() { shopTab = t[0]; shopDraw(true); } }));
        const grid = h('div', { class: 'bw-grid' });
        shopFoot = h('div', { class: 'bw-foot', text: shopTab === 'team' ? '분대 강화는 결정으로 삽니다. 분대 전원에게 적용됩니다.' : '물건을 누르면 바로 삽니다. 흐린 물건은 누르면 까닭이 보입니다.' });
        for (const e of D.SHOP) {
          if (e.tab !== shopTab) continue;
          const card = h('button', { class: 'bw-card' }); card._e = e;
          card.innerHTML = '<div class="ic">' + D.svgW(D.entryIcon(e)) + '</div><div><div class="nm"></div><div class="pr"></div></div>';
          card.addEventListener('pointerenter', () => { shopFoot.textContent = e.nm + ' — ' + descOf(e, c); });
          card.addEventListener('click', () => { const why = S.whyNot(W, c, e); if (why) { shopFoot.textContent = e.nm + ': ' + why; note(why, 'warn'); snd('no'); } else { inp.buy = e.id; shopFoot.textContent = e.nm + ' — ' + descOf(e, c); shopT = 0.12; } });
          grid.append(card);
        }
        shopEl.append(head, tabs, grid, shopFoot);
      }
      const rr = shopEl.querySelector('.sh-res'); rr.innerHTML = D.RES.map((r, i) => '<div class="bw-chip"><i style="background:' + r.col + '"></i>' + r.nm + ' <b>' + c.r[i] + '</b></div>').join('');
      shopEl.querySelectorAll('.bw-card').forEach((card) => {
        const e = card._e, why = S.whyNot(W, c, e), cost = S.priceOf(W, c, e) || e.cost, tm = W.tm[c.t];
        card.classList.toggle('no', !!why);
        let nm = e.nm; if (e.k === 'upg') { const u = D.UPG[e.u]; if (!u.rep && u.cost.length > 1) nm += ' <span class="lv">' + tm.up[e.u] + '/' + u.cost.length + '</span>'; else if (!u.rep && tm.up[e.u]) nm += ' <span class="lv">완료</span>'; }
        if (e.k === 'con' && c.it[e.c]) nm += ' <span class="lv">×' + c.it[e.c] + '</span>'; if (e.k === 'blk' && c.b[e.b]) nm += ' <span class="lv">보유 ' + c.b[e.b] + '</span>';
        const own = why === '이미 지님' || why.indexOf('이미') === 0 || why === '끝까지 강화함';
        card.classList.toggle('own', own); const k = nm + '|' + cost.join(',') + own; if (card._k !== k) { card._k = k; card.querySelector('.nm').innerHTML = nm; card.querySelector('.pr').innerHTML = own ? '<span>' + why + '</span>' : priceHTML(cost); }
      });
    }
    function descOf(e, c) { if (e.k === 'upg') { const u = D.UPG[e.u], lv = Math.min(u.d.length - 1, u.rep ? 0 : W.tm[c.t].up[e.u]); return u.d[lv]; } return e.d; }

    /* 현황판 · 위쪽 */
    function drawScore() {
      let s = '<table><tr><th>분대원</th><th>처치</th><th>쓰러짐</th><th>부순 핵</th><th>상태</th></tr>';
      for (const tm of W.tm) { s += '<tr><td colspan="5" style="color:' + D.TEAMS[tm.t].col + ';padding-top:6px">' + D.TEAMS[tm.t].nm + ' · 핵 ' + (tm.core > 0 ? Math.ceil(tm.core) + '%' : '없음') + (tm.up.some((x) => x) ? ' · 강화 ' + D.UPG.map((u, i) => (tm.up[i] ? u.nm + (u.cost.length > 1 ? ' ' + tm.up[i] : '') : '')).filter(Boolean).join(', ') : '') + '</td></tr>';
        for (const c of W.chars) if (c.t === tm.t) s += '<tr><td>' + nmOf(c.s).replace(/[<&]/g, '') + (api.players[c.s] && api.players[c.s].ai ? ' <span style="color:#ab9fb8;font-size:12px">AI</span>' : '') + '</td><td>' + c.st.k + '</td><td>' + c.st.d + '</td><td>' + c.st.c + '</td><td>' + (c.out ? '탈락' : c.al ? '생존' : '부활 대기') + '</td></tr>'; }
      scoreEl.innerHTML = s + '</table>';
    }
    let teamKey = '';
    function drawTop(me) {
      const myT = me >= 0 ? W.chars[me].t : -1;
      const key = W.tm.map((tm) => Math.ceil(tm.core) + ':' + W.chars.filter((c) => c.t === tm.t && !c.out).length + (W.t - tm.hitT < 2 ? 'h' : '')).join('|') + myT;
      if (key !== teamKey) { teamKey = key; teamsEl.innerHTML = W.tm.map((tm) => { const n = W.chars.filter((c) => c.t === tm.t && !c.out).length; return '<div class="bw-team' + (tm.t === myT ? ' me' : '') + (n ? '' : ' out') + (W.t - tm.hitT < 2 && tm.core > 0 ? ' hit' : '') + '"><i style="background:' + D.TEAMS[tm.t].col + (tm.core > 0 ? '' : ';opacity:.3') + '"></i>' + (tm.core > 0 ? '<b>' + Math.ceil(tm.core) + '</b>' : '핵 없음') + ' · ' + n + '명</div>'; }).join(''); }
      const p = D.PHASES[W.ph], ft = (s) => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
      phaseEl.innerHTML = p ? '다음: ' + p.nm + ' <b>' + ft(Math.max(0, p.f * W.T - W.t)) + '</b>' : '최종 소멸 <b>' + ft(Math.max(0, W.T + 75 - W.t)) + '</b>';
    }
    function drawMap(me) {
      const sz = touchUI && vh < 420 ? 96 : 132, dpr = Math.min(2, window.devicePixelRatio || 1);
      if (mapEl.width !== sz * dpr) { mapEl.width = mapEl.height = sz * dpr; mapEl.style.width = mapEl.style.height = sz + 'px'; }
      const g = mapEl.getContext('2d'), k = sz * dpr / 144; g.setTransform(k, 0, 0, k, 0, 0); g.clearRect(0, 0, 144, 144); g.drawImage(mapCv, 0, 0);
      for (const i of W.touched) { const id = W.g[i]; if (id >= 1 && id <= 6) { g.fillStyle = id <= 2 ? '#d9c79c' : '#9aa2ac'; g.fillRect(S.iX(i) * 2, S.iZ(i) * 2, 2, 2); } }
      const P = (x) => (x / CS + C0) * 2;
      for (const gn of W.gens) { g.fillStyle = D.RES[gn.k].col; g.fillRect(P(gn.x) - 2, P(gn.z) - 2, 4, 4); }
      for (const tm of W.tm) { g.fillStyle = D.TEAMS[tm.t].col; g.globalAlpha = tm.core > 0 ? 1 : 0.3; g.save(); g.translate(P(tm.b.cx), P(tm.b.cz)); g.rotate(Math.PI / 4); g.fillRect(-3.5, -3.5, 7, 7); g.restore(); g.globalAlpha = 1; }
      if (W.t > 0.8 * W.T - 30) { g.strokeStyle = 'rgba(230,90,120,.9)'; g.lineWidth = 1.5; g.beginPath(); g.arc(72, 72, Math.max(1, W.stormR / CS * 2), 0, TAU); g.stroke(); }
      const myT = me >= 0 ? W.chars[me].t : -1, mc = me >= 0 ? W.chars[me] : null;
      for (const c of W.chars) { if (!c.al) continue; const mate = myT < 0 || c.t === myT; if (!mate && !(c.fx.mark > W.t) && !(mc && Math.hypot(c.x - mc.x, c.z - mc.z) < 26 && c.fx.cloak <= W.t)) continue; g.fillStyle = D.TEAMS[c.t].col; g.strokeStyle = c.s === me ? '#fff' : 'rgba(0,0,0,.6)'; g.lineWidth = c.s === me ? 1.6 : 1; g.beginPath(); g.arc(P(c.x), P(c.z), c.s === me ? 3.4 : 2.6, 0, TAU); g.fill(); g.stroke(); }
      if (mc) { g.strokeStyle = '#fff'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(P(mc.x), P(mc.z)); g.lineTo(P(mc.x) + Math.sin(yaw) * 9, P(mc.z) + Math.cos(yaw) * 9); g.stroke(); }
    }
    let resKey = '';
    function hudTick() {
      const me = ME(), fc = focusChar(), c = me >= 0 ? W.chars[me] : null, hum = c && humanHere(me);
      drawTop(me); drawMap(fc ? fc.s : me);
      const sc = fc || c;
      if (sc) {
        const k = sc.r.join(',') + '|' + Math.ceil(sc.hp);
        if (k !== resKey) { resKey = k; resEl.innerHTML = ''; hpEl.firstChild.style.width = clamp(sc.hp, 0, 100) + '%'; hpEl.lastChild.textContent = Math.ceil(Math.max(0, sc.hp)); resEl.append(hpEl); D.RES.forEach((r, i) => { const d = h('div', { class: 'bw-chip' }); d.innerHTML = '<i style="background:' + r.col + '"></i>' + r.nm + ' <b>' + sc.r[i] + '</b>'; resEl.append(d); }); }
        drawBar(sc);
      }
      botEl.style.display = sc ? '' : 'none';
      const live = hum && c.al;
      crossEl.style.display = live && !shopEl ? '' : 'none';
      if (c && hum && !c.al) { deadEl.style.display = ''; deadEl.style.top = ''; deadEl.innerHTML = c.out ? '탈락 — 관전 중<small>' + (touchUI ? '화면을 누르면 다른 분대원' : 'V: 다른 분대원 보기') + '</small>' : '쓰러짐<small>' + Math.max(0, Math.ceil(c.rsT - W.t)) + '초 뒤 부활</small>'; if (shopEl) shopClose(); }
      else if (me < 0 || !hum) { deadEl.style.display = fc ? '' : 'none'; if (fc) deadEl.innerHTML = '<span style="color:' + D.TEAMS[fc.t].col + '">' + nmOf(fc.s).replace(/[<&]/g, '') + '</span> 관전 중'; deadEl.style.top = '14%'; }
      else deadEl.style.display = 'none';
      if (shopEl) { if (!live) shopClose(); else shopDraw(false); }
      const showScore = api.input.held('score') || scoreHold; scoreEl.style.display = showScore ? '' : 'none'; if (showScore) drawScore();
      /* 상황 안내(한 줄) */
      let tip = '';
      if (live && !shopEl) {
        const nb = S.blocks(c), b = W.tm[c.t].b, home = Math.hypot(c.x - b.x, c.z - b.z) < S.BASE_R, kk = (id, d) => '<kbd>' + ((L.ui && L.ui.keyLabel && L.ui.keyLabel('bedwar', id)) || d) + '</kbd>';
        if (W.t < 14 && !nb && c.r[0] < 4) tip = '뒤쪽 제련로에 서면 주괴가 모임';
        else if (home && !nb && c.r[0] >= 4) tip = touchUI ? '「보급」을 눌러 발판을 삼' : kk('shop', 'B') + ' 보급소 — 발판을 사서 다리를 놓음';
        else if (nb && ghostKind === 1 && !inp.bWas && W.t < 150) tip = touchUI ? '「놓기」를 누른 채 걸으면 다리가 깔림' : '<kbd>오른쪽 클릭</kbd>을 누른 채 걸으면 다리가 깔림';
        else if (Math.hypot(c.x, c.z) > W.stormR - 6 && W.t >= 0.8 * W.T) tip = '고리 밖 — 가운데로 이동';
      }
      if (tip !== tipEl._t) { tipEl._t = tip; tipEl.innerHTML = tip; tipEl.style.display = tip ? '' : 'none'; }
      const pc = live && !touchUI && W.t < 40 && !shopEl;
      keysEl.style.display = pc ? '' : 'none';
      if (pc && !keysEl._d) { keysEl._d = 1; const kk = (id, d) => '<kbd>' + ((L.ui && L.ui.keyLabel && L.ui.keyLabel('bedwar', id)) || d) + '</kbd>'; keysEl.innerHTML = '<kbd>마우스</kbd> 시점 · ' + kk('up', 'W') + kk('left', 'A') + kk('down', 'S') + kk('right', 'D') + ' 이동 · ' + kk('jump', 'Space') + ' 점프<br><kbd>왼쪽 클릭</kbd> 공격 · 부수기 · <kbd>오른쪽 클릭</kbd> 놓기 · ' + kk('mat', 'Q') + ' 자재 · ' + kk('shop', 'B') + ' 보급소 · ' + kk('score', 'Tab') + ' 현황'; }
      ctlEl.style.display = live && touchUI ? '' : 'none';
      vig.style.boxShadow = sc && sc.al && (Math.hypot(sc.x, sc.z) > W.stormR || W.t > W.T + 50) ? 'inset 0 0 90px 30px rgba(190,40,70,.45)' : sc && sc.al && sc.hp < 30 ? 'inset 0 0 90px 30px rgba(170,30,20,.35)' : 'inset 0 0 90px 30px rgba(170,30,20,0)';
      for (const gf of genFx) { const n = gf.gn.stock; if (n !== gf.shown) { gf.shown = n; const g = gf.cv.getContext('2d'); g.clearRect(0, 0, 128, 64); if (n > 0) { g.font = '600 30px "IBM Plex Mono",monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = 6; g.strokeStyle = 'rgba(10,10,16,.85)'; g.strokeText('×' + n, 64, 32); g.fillStyle = D.RES[gf.gn.k].col; g.fillText('×' + n, 64, 32); } gf.tx.needsUpdate = true; } }
    }

    /* ======================= 조작 ======================= */
    const testBot = () => !!(L.debug && (L.debug.autoplay || (L.debug.noTut && api.online)));
    const ME = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const isHost = () => !api.online || api.isHost;
    function controlledHere(seat) { const p = api.players[seat]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !!p.local && !p.ai; }
    const humanHere = (seat) => { const p = api.players[seat]; return !!p && !p.ai && (!api.online || !!p.local) && !testBot(); };
    const meHum = () => { const me = ME(); return me >= 0 && humanHere(me); };
    let yaw = 0, pit = -0.25, camClose = false, focus = -1, scoreHold = false, ghostKind = 0;
    const inp = { jx: 0, jy: 0, stickId: null, sx: 0, sy: 0, atk: 0, build: 0, jump: 0, atkE: 0, buildE: 0, pcE: 0, bT: 0, bWas: 0, bPl: 0, use: -1, buy: '', mat: 0, hand: -1, mAtk: 0, mBuild: 0, tAtk: 0, tBuild: 0, tJump: 0 };
    const aim = { i: -1, pi: -1, x: 0, y: 0, z: 0, ox: 0, oy: 0, oz: 0 };
    function focusChar() { const me = ME(); if (me >= 0 && W.chars[me].al && humanHere(me)) return W.chars[me]; if (me >= 0 && humanHere(me) && !W.chars[me].out) return W.chars[me]; let c = W.chars[focus]; if (!c || !c.al) { const myT = me >= 0 ? W.chars[me].t : -1; c = W.chars.find((q) => q.al && q.t === myT) || W.chars.find((q) => q.al) || W.chars[Math.max(0, me)]; focus = c ? c.s : -1; } return c; }
    function cycleFocus() { const n = W.chars.length; for (let k = 1; k <= n; k++) { const c = W.chars[(Math.max(0, focus) + k) % n]; if (c.al) { focus = c.s; return; } } }
    function lookBy(dx, dy) { yaw -= dx; pit = clamp(pit - dy, -1.35, 1.15); }
    let vw = 1, vh = 1, uiK = 1, camLift = 0;
    const mkBtn = (txt, fn) => { const b = h('button', { class: 'bw-btn', text: txt }); let id = null, lx = 0, ly = 0; b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); id = e.pointerId; lx = e.clientX; ly = e.clientY; try { b.setPointerCapture(id); } catch (x) {} b.classList.add('on'); fn(true); }); b.addEventListener('pointermove', (e) => { if (e.pointerId !== id) return; lookBy((e.clientX - lx) * 0.0055 * sens, (e.clientY - ly) * 0.0045 * sens); lx = e.clientX; ly = e.clientY; }); const up = (e) => { if (e.pointerId !== id) return; id = null; b.classList.remove('on'); fn(false); }; b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); ctlEl.append(b); return b; };
    const bAtk = mkBtn('공격', (on) => { inp.tAtk = on ? 1 : 0; if (on) inp.atkE = 1; }), bBuild = mkBtn('놓기', (on) => { inp.tBuild = on ? 1 : 0; if (on) inp.buildE = 1; }), bJump = mkBtn('점프', (on) => { inp.tJump = on ? 1 : 0; if (on) inp.jump = 1; }), bShop = mkBtn('보급', (on) => { if (on) shopOpen(); }), bScore = mkBtn('현황', (on) => { scoreHold = on; });
    function layout() {
      const r = wrap.getBoundingClientRect(); vw = Math.max(1, r.width); vh = Math.max(1, r.height);
      const k = (L.ui && L.ui.ctlScale ? L.ui.ctlScale() : 1) * clamp(Math.min(vw, vh) / 380, 0.92, 1.25);
      const B = Math.round(78 * k), M2 = Math.round(66 * k), Sm = Math.round(54 * k), m = Math.round(14 * k);
      const put = (el, w, right, bottom) => Object.assign(el.style, { width: w + 'px', height: w + 'px', right: right + 'px', bottom: bottom + 'px' });
      put(bAtk, B, m, m + Math.round(8 * k)); put(bBuild, M2, m + B + Math.round(10 * k), m); put(bJump, M2, m + Math.round(4 * k), m + B + Math.round(18 * k)); put(bShop, Sm, m + B + Math.round(16 * k), m + M2 + Math.round(12 * k)); put(bScore, 44, 56, 6); bScore.style.bottom = ''; bScore.style.top = '6px'; bScore.style.fontSize = '12px';
      const narrow = touchUI && vw < 760;
      { const rw = m + B + M2 + 26, free = vw - rw - 8; botEl.style.maxWidth = touchUI ? Math.max(200, free - 8) + 'px' : ''; botEl.style.left = touchUI && vw < 900 ? Math.round(8 + free / 2) + 'px' : '50%'; }
      hpEl.style.width = narrow ? '110px' : '170px'; wrap.classList.toggle('bw-tight', vh < 470);
      /* 큰 화면에서는 HUD · 보급소 · 물건 줄 · 작은 지도를 함께 키움(1280×720에서 가장 작은 글씨 13px 이상) */
      uiK = touchUI && vw < 900 ? 1 : clamp(Math.min(vw / 1100, vh / 620), 1, 2);
      for (const el of [topEl, mapEl, feedEl, botEl, noteEl, tipEl, keysEl, deadEl, scoreEl]) el.style.zoom = uiK; if (shopEl) shopEl.style.zoom = uiK;
      camLift = touchUI && vh < 470 ? 0.75 : 0;
      topEl.style.maxWidth = 'calc(100% - ' + (narrow ? 230 : 300) + 'px)';
      noteEl.style.bottom = (narrow ? 104 : 118) + 'px'; tipEl.style.bottom = (narrow ? 132 : 150) + 'px';
      R.setPixelRatio(Math.min(window.devicePixelRatio || 1, TIER.pr)); R.setSize(vw, vh, false);
      cam.aspect = vw / vh; cam.fov = vw < vh ? 80 : 64; cam.updateProjectionMatrix();
    }
    function onDown(e) {
      if ((e.pointerType === 'touch' || e.pointerType === 'pen') && !touchUI) { touch = true; touchUI = true; FL.exit(); barKey = ''; layout(); }
      if (shopEl) return;
      const me = ME(), c = me >= 0 && W ? W.chars[me] : null, live = c && c.al && humanHere(me);
      if (e.pointerType === 'mouse') {
        if (FL.focusClick()) return;
        if (live) { if (e.button === 0) { inp.mAtk = 1; inp.atkE = 1; } else if (e.button === 2) { inp.mBuild = 1; inp.buildE = 1; } }
        else if (W && e.button === 0) cycleFocus();
        return;
      }
      const r = wrap.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      if (live && x < vw * 0.42 && y > vh * 0.28 && inp.stickId == null) { inp.stickId = e.pointerId; inp.sx = x; inp.sy = y; inp.jx = inp.jy = 0; stick.style.display = 'block'; stick.style.left = x + 'px'; stick.style.top = y + 'px'; stick.firstChild.style.transform = ''; try { wrap.setPointerCapture(e.pointerId); } catch (x2) {} return; }
      if (drag.id == null) { drag.id = e.pointerId; drag.x = e.clientX; drag.y = e.clientY; drag.moved = 0; try { wrap.setPointerCapture(e.pointerId); } catch (x2) {} }
    }
    const drag = { id: null, x: 0, y: 0, moved: 0 };
    function onMove(e) {
      if (e.pointerType === 'mouse') return;
      if (e.pointerId === inp.stickId) {
        const r = wrap.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; let dx = x - inp.sx, dy = y - inp.sy; const d = Math.hypot(dx, dy), mx = 46;
        if (d > mx) { inp.sx += dx * (1 - mx / d) * 0.6; inp.sy += dy * (1 - mx / d) * 0.6; dx = x - inp.sx; dy = y - inp.sy; }
        const dd = Math.min(mx, Math.hypot(dx, dy)), a = Math.atan2(dy, dx), mg = clamp((dd - 5) / (mx * 0.72 - 5), 0, 1);
        inp.jx = Math.cos(a) * mg; inp.jy = -Math.sin(a) * mg;
        stick.style.left = inp.sx + 'px'; stick.style.top = inp.sy + 'px'; stick.firstChild.style.transform = 'translate(' + (Math.cos(a) * dd) + 'px,' + (Math.sin(a) * dd) + 'px)';
        return;
      }
      if (e.pointerId === drag.id) { const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY; drag.moved += Math.abs(dx) + Math.abs(dy); lookBy(dx * 0.0055 * sens, dy * 0.0045 * sens); }
    }
    function onUp(e) {
      if (e.pointerId === inp.stickId) { inp.stickId = null; inp.jx = inp.jy = 0; stick.style.display = 'none'; }
      if (e.pointerId === drag.id) { drag.id = null; const me = ME(), c = me >= 0 && W ? W.chars[me] : null; if (drag.moved < 8 && W && !(c && c.al && humanHere(me))) cycleFocus(); }
      if (e.pointerType === 'mouse') { if (e.button === 0) inp.mAtk = 0; else if (e.button === 2) inp.mBuild = 0; }
    }
    const onWheel = (e) => { if (shopEl || !meHum()) return; inp.mat = e.deltaY > 0 ? 1 : -1; };
    const onCtx = (e) => e.preventDefault();
    const onKeyCap = (e) => { if (e.code === 'Escape' && shopEl) { e.preventDefault(); e.stopPropagation(); shopClose(); } else if (e.code === 'Tab' && W) e.preventDefault(); };
    wrap.addEventListener('pointerdown', onDown); wrap.addEventListener('pointermove', onMove); wrap.addEventListener('pointerup', onUp); wrap.addEventListener('pointercancel', onUp); wrap.addEventListener('wheel', onWheel, { passive: true }); wrap.addEventListener('contextmenu', onCtx); document.addEventListener('keydown', onKeyCap, true);
    const FL = mkFreeLook({ el: R.domElement, root: wrap,
      want: () => !touchUI && !paused && !shopEl && !!st && st.ph === 'play' && !!W && meHum(),
      turn: (dx, dy) => lookBy(dx * 0.0024 * sens, dy * 0.0024 * sens),
      onLock: (on, byUser) => { if (!on) { inp.mAtk = 0; inp.mBuild = 0; } if (!on && byUser && st && st.ph === 'play' && !shopEl) { try { if (api.canPause && api.canPause() && !(api.paused && api.paused())) api.pause(); } catch (e) {} } } });
    const offs = [];
    offs.push(api.input.on((type, id) => {
      if (type !== 'down' || !W) return;
      if (touchUI && !touch) { touchUI = false; barKey = ''; layout(); }
      if (id === 'shop') shopOpen(); else if (shopEl) return;
      else if (id === 'jump') inp.jump = 1; else if (id === 'mat') inp.mat = 1; else if (id === 'h1') inp.hand = 0; else if (id === 'h2') inp.hand = 1;
      else if (id === 'atk') inp.atkE = 1; else if (id === 'build') inp.buildE = 1; else if (id === 'spec') cycleFocus();
      else if (/^i\d$/.test(id)) useSlot((+id[1] + 7) % 10);
    }));
    let lastMx = 0, lastMz = 0;
    function readInput(c, first) {
      let ix = api.input.axis('left', 'right') + inp.jx, iy = api.input.axis('down', 'up') + inp.jy;
      const m = Math.hypot(ix, iy); if (m > 1) { ix /= m; iy /= m; }
      const fx = Math.sin(yaw), fz = Math.cos(yaw), open = !!shopEl;
      const build = !open && (inp.mBuild || inp.tBuild || api.input.held('build')), atk = !open && (inp.mAtk || inp.tAtk || api.input.held('atk'));
      const o = { mx: open ? 0 : fx * iy - fz * ix, mz: open ? 0 : fz * iy + fx * ix, yaw, pit, jump: !open && first && (inp.jump || api.input.held('jump') || inp.tJump) ? 1 : 0, build: build ? 1 : 0, buildE: first && inp.buildE ? 1 : 0, atk: atk ? 1 : 0, atkE: first && inp.atkE ? 1 : 0, careful: build ? 1 : 0, pc: -1, pcE: 0, bc: aim.i, use: -1, buy: '', hand: null, sb: 0 };
      /* 놓기: 누르고 있으면 다리, 짧게(0.28초 안에 떼기) 누르면 조준한 면에 한 칸 */
      if (build) { if (!inp.bWas) { inp.bWas = 1; inp.bT = 0; inp.bPl = 0; } inp.bT += S.DT; if (W.placedBy === c.s) inp.bPl = 1; }
      else if (inp.bWas) { inp.bWas = 0; if (inp.bT < 0.28 && !inp.bPl && W.placedBy !== c.s) o.pcE = 1; }
      W.placedBy = -1;
      lastMx = o.mx; lastMz = o.mz;
      if (aim.pi >= 0) o.pc = aim.pi;
      const dx = aim.x - c.x, dy = aim.y - (c.y + 1.4), dz = aim.z - c.z, dl = Math.hypot(dx, dy, dz) || 1; o.ad = [dx / dl, dy / dl, dz / dl];
      if (first) {
        if (inp.use >= 0) o.use = inp.use; if (inp.buy) o.buy = inp.buy;
        if (inp.hand >= 0) { if (inp.hand === 1 && !c.rg) note('원거리 무기 없음'); else o.hand = inp.hand; }
        if (inp.mat) { if (S.blocks(c) > 0) { o.sb = S.nextMat(c); note(D.BLK[o.sb].nm + ' ' + c.b[o.sb] + '개'); } else note('자재 없음'); }
        inp.use = -1; inp.buy = ''; inp.hand = -1; inp.mat = 0; inp.jump = 0; inp.atkE = 0; inp.buildE = 0;
      }
      return o;
    }
    function guestBot(c) { const t = W.t, a = t * 0.5 + c.s; return { mx: Math.sin(a) * 0.6, mz: Math.cos(a) * 0.6, yaw: a, pit: 0, jump: Math.sin(t * 2) > 0.95 ? 1 : 0, build: 0, atk: Math.sin(t * 3) > 0 ? 1 : 0, careful: 1, pc: -1, bc: -1, use: -1, buy: Math.floor(t) % 9 === 3 && c.r[0] >= 4 ? 'b1' : '', hand: null, sb: 0 }; }

    /* 조준: 화면 가운데 광선 → 칸 */
    const camDir = new T.Vector3();
    function aimTick() {
      aim.i = -1; aim.pi = -1; ghostKind = 0;
      const me = ME(), c = me >= 0 ? W.chars[me] : null;
      if (!c || !c.al || !humanHere(me)) { ghost.visible = false; hl.visible = false; crack.visible = false; pgEl.setAttribute('stroke-dasharray', '0 60'); return; }
      cam.getWorldDirection(camDir);
      const hx = chars[me].px, hy = chars[me].py + S.EYE, hz = chars[me].pz;
      const sk = Math.max(0, (hx - cam.position.x) * camDir.x + (hy - cam.position.y) * camDir.y + (hz - cam.position.z) * camDir.z);
      const ox = cam.position.x + camDir.x * sk, oy = cam.position.y + camDir.y * sk, oz = cam.position.z + camDir.z * sk;
      const hit = S.ray(W, ox, oy, oz, camDir.x, camDir.y, camDir.z, 70);
      const d = hit ? hit.d : 60; aim.x = ox + camDir.x * d; aim.y = oy + camDir.y * d; aim.z = oz + camDir.z * d;
      if (hit && hit.d <= S.REACH) { const id = W.g[hit.i]; if (id >= 1 && id <= 6) aim.i = hit.i; if (hit.pi >= 0 && S.canPlace(W, hit.pi, false)) aim.pi = hit.pi; }
      const nb = S.blocks(c);
      let gi = -1;
      if (nb && !shopEl) { gi = S.bridgeCell(W, c, { mx: lastMx, mz: lastMz }); if (gi >= 0) ghostKind = 1; else if (aim.pi >= 0 && ((inp.bWas && inp.bT < 0.28) || chars[me].spd < 0.6)) { gi = aim.pi; ghostKind = 2; } }
      ghost.visible = gi >= 0; if (gi >= 0) { ghost.position.set(S.wX(S.iX(gi)), S.iY(gi) - G0 + 0.5, S.wX(S.iZ(gi))); ghost.material.color.set(D.BLK[S.pickMat(c) || 1].col); ghost.material.opacity = ghostKind === 2 ? (inp.bWas ? 0.38 : 0.14) : inp.bWas ? 0.42 : 0.22; }
      hl.visible = aim.i >= 0; if (aim.i >= 0) hl.position.set(S.wX(S.iX(aim.i)), S.iY(aim.i) - G0 + 0.5, S.wX(S.iZ(aim.i)));
      const pr = c.bkI >= 0 ? clamp(c.bkP, 0, 1) : 0;
      crack.visible = pr > 0; if (pr > 0) { crack.position.set(S.wX(S.iX(c.bkI)), S.iY(c.bkI) - G0 + 0.5, S.wX(S.iZ(c.bkI))); crack.material.opacity = pr * 0.55; }
      pgEl.setAttribute('stroke-dasharray', (pr * 59.7).toFixed(1) + ' 60');
    }

    /* 카메라(보간한 위치를 따라감) */
    const camT = new T.Vector3();
    let shX = 0, shZ = 0;
    function camTick() {
      const fc = focusChar(); if (!fc) return;
      const o = chars[fc.s], me = ME(), mine = fc.s === me && humanHere(me);
      let cy = yaw, cp = pit;
      if (!mine) { cy = yaw = yaw + S.angD(fc.yaw, yaw) * 0.06; cp = -0.42; }
      const hx = o.px, hy = o.py + 1.62, hz = o.pz;
      const dx = Math.sin(cy) * Math.cos(cp), dy = Math.sin(cp), dz = Math.cos(cy) * Math.cos(cp);
      const rx = -Math.cos(cy), rz = Math.sin(cy), side = mine ? 0.62 : 0, want = mine ? (vw < vh ? 6.2 : 5.0) : 9;
      let bx = -dx, by = -dy, bz = -dz; bx += rx * side / want; bz += rz * side / want; const bl = Math.hypot(bx, by, bz); bx /= bl; by /= bl; bz /= bl;
      const hit = S.ray(W, hx, hy, hz, bx, by, bz, want + 0.4);
      const d = hit ? Math.max(0.35, hit.d - 0.35) : want;
      cam.position.set(hx + bx * d, hy + by * d + 0.15, hz + bz * d);
      camT.set(hx + rx * side * 0.6 + dx * 8, hy + 0.15 + dy * 8 - camLift * 2.2, hz + rz * side * 0.6 + dz * 8); cam.lookAt(camT);
      camClose = mine && d < 1.3;
      if (TIER.shadow) { const tex2 = (SH_R * 2) / TIER.shadow, lx = Math.round(hx / tex2 / 8) * tex2 * 8, lz = Math.round(hz / tex2 / 8) * tex2 * 8; if (lx !== shX || lz !== shZ || !sun.userData.ok) { shX = lx; shZ = lz; sun.userData.ok = 1; sun.target.position.set(lx, 0, lz); sun.position.set(lx + sunDir.x * 120, sunDir.y * 120, lz + sunDir.z * 120); sun.target.updateMatrixWorld(); } }
      else if (!sun.userData.ok) { sun.userData.ok = 1; sun.position.copy(sunDir).multiplyScalar(120); }
      sky.position.copy(cam.position);
    }

    /* ======================= 사건(소리 · 조각 · 알림) ======================= */
    let evSeen = 0, coreWarnT = -9, noT = -9;
    const cellPos = (i) => [S.wX(S.iX(i)), S.iY(i) - G0 + 0.5, S.wX(S.iZ(i))];
    const HOW = ['쓰러뜨림', '낙사', '소멸'];
    function onEv(e) {
      const k = e[1], me = ME(), myT = me >= 0 ? W.chars[me].t : -1;
      if (k === 'pl') { const p = cellPos(e[2]); snd('pl', p[0], p[1], p[2]); }
      else if (k === 'bk') { const p = cellPos(e[2]); snd('bk', p[0], p[1], p[2]); burst(p[0], p[1], p[2], D.BLK[e[3]].col, 9, 3.5, 4); }
      else if (k === 'hit') { const c = W.chars[e[2]]; snd('hit', c.x, c.y + 1, c.z); burst(c.x, c.y + 1.1, c.z, '#e8e0d0', 4, 3, 3); if (e[2] === me && L.haptic) L.haptic('hit', 30); }
      else if (k === 'die') { const c = W.chars[e[2]]; snd('die', c.x, c.y, c.z); burst(c.x, Math.max(-6, c.y) + 1, c.z, D.TEAMS[c.t].col, 16, 5, 6); feed((e[3] >= 0 ? tspan(e[3]) + ' → ' : '') + tspan(e[2]) + ' ' + HOW[e[4]] + (e[5] ? ' · 탈락' : '')); }
      else if (k === 'shot') { const c = W.chars[e[2]]; snd('shot', c.x, c.y + 1, c.z); }
      else if (k === 'boom') { const x = e[2] / 10, y = e[3] / 10, z = e[4] / 10, r = e[5] / 10; snd('boom', x, y, z); flash(x, y, z, r); burst(x, y, z, '#5a5048', 26, 9, 9); for (const i of W.chg) void i; }
      else if (k === 'puff') { burst(e[2] / 10, e[3] / 10, e[4] / 10, '#9fb6d0', 10, 6, 4); snd('hit', e[2] / 10, e[3] / 10, e[4] / 10); }
      else if (k === 'tick') snd('dig', e[2] / 10, e[3] / 10, e[4] / 10);
      else if (k === 'core') { const tm = W.tm[e[2]], b = tm.b; snd('core', b.cx, 1, b.cz); burst(b.cx, 1.3, b.cz, D.TEAMS[tm.t].col, 5, 4, 4); if (e[2] === myT && wallT - coreWarnT > 3) { coreWarnT = wallT; note('거점 핵이 공격받는 중', 'warn'); snd('warn'); } }
      else if (k === 'coreX') { const tm = W.tm[e[2]], b = tm.b; snd('coreX'); flash(b.cx, 1.2, b.cz, 5); burst(b.cx, 1.3, b.cz, D.TEAMS[tm.t].col, 40, 8, 9); feed('<span style="color:' + D.TEAMS[tm.t].col + '">' + D.TEAMS[tm.t].nm + '</span> 핵 파괴' + (e[3] >= 0 ? ' — ' + tspan(e[3]) : '')); if (e[2] === myT && e[4] !== 1) try { api.banner('거점 핵 파괴', { sub: '더는 부활할 수 없음', small: true, ms: 1500, color: '#c8493c' }); } catch (x) {} }
      else if (k === 'ph') { const p = D.PHASES[e[2]]; snd('ph'); try { api.banner(p.nm, { sub: p.d, small: true, ms: 1500 }); } catch (x) {} }
      else if (k === 'buy') { if (e[2] === me) snd('buy'); }
      else if (k === 'get') { if (e[2] === me) { snd('get'); if (e[3] > 0) note('+ ' + D.RES[e[3]].nm, 'good'); } }
      else if (k === 'no') { if (e[2] === me && wallT - noT > 1.2) { noT = wallT; note(String(e[3]), 'warn'); snd('no'); } }
      else if (k === 'upg') { if (e[2] === myT) note('분대 강화: ' + (e[3] >= 100 ? '함정 ' + D.TRAP[e[3] - 100].nm : D.UPG[e[3]].nm), 'good'); }
      else if (k === 'trap') { if (e[2] === myT) { note('함정 발동: ' + D.TRAP[e[3]].nm, 'warn'); snd('warn'); } else if (e[4] === me) note('함정에 걸림: ' + D.TRAP[e[3]].nm, 'warn'); }
      else if (k === 'use') { const c = W.chars[e[2]]; if (e[3] === D.CI.heal) burst(c.x, c.y + 1, c.z, '#d05a5a', 6, 2, 4); }
      else if (k === 'warp') { const c = W.chars[e[2]]; burst(c.x, c.y + 1, c.z, '#7fd0d8', 14, 4, 5); }
      else if (k === 'rsp' && e[2] === me) { yaw = W.chars[me].yaw; pit = -0.25; }
      else if (k === 'T' && e[2] === me && !isHost()) { if (W.chars[me].tpYaw != null && !W.chars[me].al) yaw = W.chars[me].tpYaw; }
    }
    function drainEv() { for (const e of W.ev) { if (e[0] <= evSeen) continue; evSeen = e[0]; onEv(e); } }
    let swSeen = [];
    function swingSnd() { for (const c of W.chars) { if (swSeen[c.s] !== c.swN) { if (swSeen[c.s] != null && c.al) snd('sw', c.x, c.y + 1, c.z); swSeen[c.s] = c.swN; } } }

    /* ======================= 온라인 ======================= */
    let pubT = 0, evSeq = 1, evKeep = [], syncT = 0, seenEv = {}, lastHsQ = -1, hsT = null;
    const key = () => st.rid;
    function pollNet() {
      if (!api.online || !W) return;
      const now = performance.now();
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) {}
        if (rem) for (const kk in rem) {
          const o = rem[kk], s = +kk; if (!o || o.k !== key() || controlledHere(s)) continue;
          if (o.c) S.ingest(W, s, o.c, now);
          if (o.rs) syncT = W.t + 1.2;
          if (Array.isArray(o.ev)) for (const q of o.ev) { if (!Array.isArray(q) || seenEv[s + ':' + q[0]]) continue; seenEv[s + ':' + q[0]] = 1; S.remoteEvent(W, W.chars[s], q); }
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) {}
        if (hs && hs.k === key() && hs.t !== hsT) { hsT = hs.t; const evs = S.applyHost(W, hs, ME(), now); for (const e of evs) onEv(e); }
      }
    }
    function publish(dt) {
      if (!api.online || !W) return;
      pubT -= dt; if (pubT > 0) return; pubT = 0.1;
      try {
        if (api.isHost) { const o = S.packHost(W, W.t < syncT); o.k = key(); api.net.hostSend(o); }
        else {
          const me = ME(), c = me >= 0 ? W.chars[me] : null;
          for (const e of W.evOut) { e.unshift(evSeq++); e.push(W.t); evKeep.push(e); } W.evOut.length = 0;
          evKeep = evKeep.filter((e) => W.t - e[e.length - 1] < 1.3);
          const o = { k: key() }; if (c) o.c = S.packChar(c); if (evKeep.length) o.ev = evKeep.map((e) => e.slice(0, -1)); if (W.needSync) o.rs = 1;
          api.net.publish(o);
        }
      } catch (e) {}
    }

    /* ======================= 판 진행 ======================= */
    function ensureWorld() {
      if (!st || !ready) return;
      const k = st.rid + '_' + st.seed;
      if (k === wkey && W) return;
      W = S.makeWorld(Object.assign({}, st), { host: isHost() }); wkey = k; sentOver = false; evSeen = 0; swSeen = []; acc = 0; barKey = ''; teamKey = ''; resKey = '';
      buildWorld();
      const me = ME(), c = me >= 0 ? W.chars[me] : null;
      if (c) { yaw = c.yaw; pit = -0.25; } focus = me >= 0 ? me : 0;
    }
    function simTick(dt) {
      if (!W || st.ph !== 'play') return;
      acc += dt;
      const maxSteps = Math.ceil(0.4 * SPD() / S.DT) + 4;
      let steps = Math.floor(acc / S.DT); if (steps > maxSteps) { steps = maxSteps; acc = 0; } else acc -= steps * S.DT;
      const me = ME(), hum = meHum(), host = isHost();
      for (let i = 0; i < steps; i++) {
        const myIn = hum ? readInput(W.chars[me], i === 0) : null;
        if (host) S.worldStep(W, S.DT, (s, c) => { if (!controlledHere(s)) return undefined; if (s === me && hum) return myIn; return S.aiInput(W, c, S.DT); });
        else S.guestStep(W, S.DT, me >= 0 ? W.chars[me] : null, me >= 0 ? (hum ? myIn : guestBot(W.chars[me])) : null);
        if (W.note) { note(W.note, 'warn'); W.note = null; }
        if (host && W.over && !sentOver) { sentOver = true; api.setState(Object.assign({}, st, { ph: 'done', seq: st.seq + 1, res: W.over })); break; }
      }
      if (host) drainEv();
    }
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      const rdt = Math.min(0.1 * Math.max(1, SPD()), (now - (last || now)) / 1000); last = now;
      if (!ready || !st || !W) return;
      FL.tick(Math.min(0.1, rdt));
      const kx = api.input.axis('camL', 'camR'), ky = api.input.axis('camD', 'camU');
      if (!shopEl && (Math.abs(kx) > 0.05 || Math.abs(ky) > 0.05)) lookBy(kx * 2.6 * rdt * sens, -ky * 1.7 * rdt * sens);
      const dt = rdt * SPD();
      if (!paused) {
        if (st.ph === 'play') simTick(dt);
        pollNet();
        for (const c of W.chars) { c.here2 = controlledHere(c.s); if (!c.here2) S.smooth(W, c, rdt, performance.now()); }
        publish(rdt);
        if (shopT > 0) { shopT -= rdt; if (shopT <= 0 && shopEl) shopDraw(false); }
      }
      wallT += rdt;
      for (const i of W.chg) updateCell(i); W.chg.length = 0;
      swingSnd();
      const a = st.ph === 'play' && !paused ? clamp(acc / S.DT, 0, 1) : 1, me = ME();
      const fc = focusChar();
      for (const o of chars) { const c = o.c; if (fc && c.s === fc.s) { o.px = c.here2 ? c.ox + (c.x - c.ox) * a : c.x; o.py = c.here2 ? c.oy + (c.y - c.oy) * a : c.y; o.pz = c.here2 ? c.oz + (c.z - c.oz) * a : c.z; } }
      camTick();
      for (const o of chars) tickChar(o, a, rdt, me);
      aimTick();
      pjTick(dt); pTick(rdt); flashTick(rdt);
      for (const cr of cores) { const on = cr.tm.core > 0, sh = on && W.t < 0.1 * W.T; if (cr.shd.visible !== sh) cr.shd.visible = sh; if (sh) cr.shd.material.opacity = 0.16 + 0.06 * Math.sin(wallT * 2.2); if (on !== cr.on) { cr.on = on; cr.cry.visible = on; cr.ring.visible = on; } if (on) { cr.cry.rotation.y = wallT * 0.8; cr.cry.position.y = 1.3 + Math.sin(wallT * 1.3 + cr.tm.t) * 0.06; cr.cry.material.emissiveIntensity = wallT - cr.hitW < 0.25 ? 2 : 0.6 + 0.25 * Math.sin(wallT * 2); if (W.t - cr.tm.hitT < 0.15) cr.hitW = wallT; } }
      for (const gf of genFx) { gf.item.rotation.y = wallT * 1.1; gf.item.position.y = 0.9 + Math.sin(wallT * 1.6 + gf.gn.x) * 0.08; }
      cloudM.map.offset.set(wallT * 0.0016, wallT * 0.0009); cloud2M.map.offset.set(-wallT * 0.001, wallT * 0.0013);
      const showStorm = W.t > 0.8 * W.T - 20; stormM.visible = showStorm; if (showStorm) { const r = Math.max(0.5, W.stormR); stormM.scale.set(r, 1, r); stormM.material.uniforms.t.value = wallT; }
      hudTk -= rdt; if (hudTk <= 0) { hudTk = 1 / 8; hudTick(); }
      if (noteT > 0) { noteT -= rdt; if (noteT <= 0) noteEl.style.opacity = '0'; }
      R.render(scene, cam);
    }
    let hudTk = 0;

    const onResize = () => layout();
    window.addEventListener('resize', onResize);
    layout();
    function start() {
      if (ready) return;
      ready = true; ensureWorld(); camTick();
      try { R.compile(scene, cam); } catch (e) {}
      hooks.ready();
      const me = ME();
      if (!L.debug.noTut && me >= 0 && humanHere(me) && D.store.get('tip', '') !== '1') { D.store.set('tip', '1'); note(touch ? '왼쪽 끌기 이동 · 오른쪽 끌기 시점' : '마우스: 시점 · WASD 이동 · Esc: 마우스 풀기'); }
    }
    raf = requestAnimationFrame(frame);
    return {
      update(s) { if (!s) return; st = s; if (!ready) { start(); return; } ensureWorld(); if (st.ph === 'done') { FL.exit(); shopClose(); } },
      pause() { paused = true; FL.exit(); if (AC) AC.suspend().catch(() => {}); }, resume() { paused = false; last = 0; FL.kick(); if (AC) AC.resume().catch(() => {}); },
      destroy() {
        dead = true; cancelAnimationFrame(raf);
        window.removeEventListener('resize', onResize); document.removeEventListener('keydown', onKeyCap, true); FL.destroy();
        for (const f of offs) try { f(); } catch (e) {}
        try { if (document.pointerLockElement) document.exitPointerLock(); } catch (e) {}
        try { if (AC) AC.close(); } catch (e) {}
        try { scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); for (const k in TX) TX[k].dispose(); R.dispose(); R.forceContextLoss(); } catch (e) {}
        wrap.remove(); try { delete window.BW_DBG; } catch (e) {}
      },
    };
  };
  window.BEDWAR_VIEW = V;
})();
