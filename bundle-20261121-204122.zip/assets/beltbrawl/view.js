/* 잿빛 가도 — 화면(캔버스 2D) · 조작 · HUD · 직업/능력 고르기 · 소리 · 온라인.
   시뮬(sim.js)은 고정 걸음(1/60초). 화면은 걸음 직전 자리(ox,oz,oy)와 지금 자리를 acc/DT로 보간해 그림(카메라도 보간한 자리를 봄).
   싸우는 캐릭터 · 적은 모두 코드로 그린 관절 인형/도형. 프레임마다 Math.random으로 흔드는 연출 없음(흔들림은 시간에 대한 부드러운 함수 × L.fx()). */
(function () {
  'use strict';
  const G = window, L = G.Lounge;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;
  const sgn = (v) => (v < 0 ? -1 : 1);
  const hash = (n) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
  const ease = (t) => t * t * (3 - 2 * t);
  const INK = '#17131c', RED = '#ff5040';

  /* ======================= 자세(관절 각도) =======================
     각도: 0 = 아래, π/2 = 앞, π = 위. a 앞팔[위팔, 아래팔] · b 뒷팔 · f 앞발[x, 들기] · k 뒷발 · w 무기 각 · l 몸 기울기 · y 몸 낮추기 */
  const BASE = {
    gsword: { l: 0.1, a: [0.75, 1.45], b: [0.55, 1.35], f: [8, 0], k: [-8, 0], w: 2.55, y: 0 },
    fist: { l: 0.16, a: [1.0, 2.5], b: [0.6, 2.35], f: [9, 0], k: [-9, 0], w: 0, y: 2 },
    guns: { l: 0.05, a: [0.95, 1.55], b: [0.5, 1.3], f: [7, 0], k: [-7, 0], w: 1.57, y: 0 },
    staff: { l: 0.04, a: [0.7, 1.6], b: [0.2, 0.5], f: [6, 0], k: [-6, 0], w: 3.05, y: 0 },
    spear: { l: 0.12, a: [0.5, 1.3], b: [1.0, 1.5], f: [10, 0], k: [-10, 0], w: 1.9, y: 1 },
    foe: { l: 0.12, a: [0.6, 1.3], b: [-0.2, 0.3], f: [8, 0], k: [-8, 0], w: 2.4, y: 0 },
    foeS: { l: 0.1, a: [0.6, 1.3], b: [1.0, 1.9], f: [8, 0], k: [-8, 0], w: 2.4, y: 1 },
    bow: { l: 0.05, a: [1.2, 1.5], b: [0.4, 0.9], f: [7, 0], k: [-7, 0], w: 3.14, y: 0 },
    pike: { l: 0.12, a: [0.5, 1.3], b: [1.0, 1.5], f: [9, 0], k: [-9, 0], w: 1.9, y: 1 },
    none: { l: 0.1, a: [0.3, 0.6], b: [-0.2, 0.2], f: [8, 0], k: [-8, 0], w: 0, y: 0 },
  };
  const LUNGE = { f: [17, 0], k: [-16, 0] };
  const AN = {
    sw1: [[0, { l: -0.15, a: [2.6, 3.3], b: [2.2, 2.8], w: 4.1 }], [0.13, { l: -0.2, a: [2.8, 3.5], b: [2.4, 3.0], w: 4.3 }], [0.22, { l: 0.4, a: [1.5, 1.4], b: [1.2, 1.3], w: 1.1, f: [16, 0], k: [-14, 0] }], [0.5, { l: 0.25, a: [0.5, 0.8], b: [0.4, 0.9], w: 0.3 }]],
    sw2: [[0, { l: 0.3, a: [0.3, 0.5], b: [0.2, 0.6], w: -0.2 }], [0.13, { l: 0.35, a: [0.1, 0.3], b: [0.1, 0.5], w: -0.6 }], [0.24, { l: -0.05, a: [1.9, 2.2], b: [1.6, 2.0], w: 2.3, f: [15, 0] }], [0.52, { l: -0.1, a: [2.5, 3.0], b: [2.2, 2.7], w: 3.4 }]],
    ovh: [[0, { l: -0.1, a: [2.6, 3.2], b: [2.4, 3.0], w: 3.6 }], [0.26, { l: -0.3, a: [3.0, 3.6], b: [2.8, 3.4], w: 4.4, y: -2 }], [0.36, { l: 0.55, a: [1.3, 1.2], b: [1.1, 1.1], w: 0.9, y: 7, f: [18, 0], k: [-15, 0] }], [0.74, { l: 0.4, a: [1.0, 1.0], b: [0.9, 1.0], w: 0.8, y: 5 }]],
    up: [[0, { l: 0.35, a: [0.3, 0.4], b: [0.3, 0.5], w: 0.2, y: 8 }], [0.13, { l: 0.4, a: [0.2, 0.3], b: [0.2, 0.4], w: -0.1, y: 9 }], [0.24, { l: -0.15, a: [2.6, 3.0], b: [2.3, 2.8], w: 3.1, y: -3 }], [0.6, { l: -0.1, a: [2.7, 3.2], b: [2.4, 2.9], w: 3.5 }]],
    spin: [[0, { l: 0.1, a: [1.5, 1.57], b: [1.4, 1.5], w: 1.57, y: 3, f: [12, 0], k: [-12, 0] }]],
    leap: [[0, { l: 0.2, y: 8, a: [0.5, 0.8], w: 1.0 }], [0.1, { l: -0.2, a: [2.9, 3.5], b: [2.7, 3.3], w: 4.2, y: -2, f: [10, 8], k: [-4, 12] }], [0.5, { l: -0.25, a: [3.0, 3.6], b: [2.8, 3.4], w: 4.3, y: -2, f: [10, 8], k: [-4, 12] }], [0.62, { l: 0.6, a: [1.2, 1.0], b: [1.0, 1.0], w: 0.8, y: 9, f: [18, 0], k: [-16, 0] }], [0.95, { l: 0.4, y: 6, a: [1.0, 1.0], w: 0.8 }]],
    guard: [[0, { l: -0.05, a: [1.3, 2.6], b: [1.5, 2.2], w: 3.3, y: 3, f: [12, 0], k: [-12, 0] }]],
    jab1: [[0, { l: 0.1 }], [0.1, { l: 0.3, a: [1.6, 1.6], b: [0.3, 2.2], f: [13, 0] }], [0.26, { l: 0.18 }]],
    jab2: [[0, { l: 0.2 }], [0.1, { l: 0.38, b: [1.65, 1.6], a: [0.2, 2.0], f: [14, 0], k: [-12, 0] }], [0.26, { l: 0.18 }]],
    hook: [[0, { l: -0.1, a: [-0.3, 1.2] }], [0.13, { l: 0.42, a: [1.5, 2.3], b: [0.2, 2.0], f: [13, 0] }], [0.32, {}]],
    kick: [[0, { l: -0.1 }], [0.14, { l: -0.35, f: [24, 24], a: [-0.4, 0.4], b: [0.6, 1.8], k: [-3, 0] }], [0.34, {}]],
    fin: [[0, { l: -0.25, a: [-0.6, 0.9], y: 3 }], [0.16, { l: -0.3, a: [-0.8, 0.7], y: 4 }], [0.24, { l: 0.55, a: [1.6, 1.6], b: [-0.5, 0.6], y: 4, f: [18, 0], k: [-16, 0] }], [0.52, { l: 0.3 }]],
    upper: [[0, { l: 0.4, y: 10, a: [0.2, 1.3], b: [0.6, 2.2] }], [0.1, { l: 0.45, y: 11, a: [0.1, 1.2] }], [0.18, { l: -0.2, y: -4, a: [2.9, 3.1], b: [0.3, 1.5], f: [6, 6], k: [-6, 10] }], [0.4, { l: -0.1, a: [2.2, 2.6], y: -2, f: [6, 6], k: [-6, 8] }], [0.6, {}]],
    grab: [[0, { l: 0.3, a: [1.5, 1.6], b: [1.4, 1.6] }], [0.12, { l: 0.35, a: [1.6, 1.7], b: [1.5, 1.7] }], [0.36, { l: -0.25, a: [2.6, 2.9], b: [2.5, 2.8], y: -2 }], [0.5, { l: 0.65, a: [0.7, 0.5], b: [0.6, 0.5], y: 9, f: [17, 0], k: [-15, 0] }], [0.72, { l: 0.4, y: 6 }]],
    dashp: [[0, { l: 0.6, a: [1.6, 1.6], b: [-0.6, -0.1], f: [18, 0], k: [-18, 4], y: 4 }]],
    step: [[0, { l: 0.4, y: 6, f: [16, 0], k: [-16, 5], a: [0.8, 2.2], b: [0.5, 2.0] }]],
    shA: [[0, { l: 0.05, a: [1.5, 1.57], w: 1.57, b: [0.9, 1.9] }], [0.07, { l: -0.02, a: [1.65, 1.9], w: 1.9, b: [0.9, 1.9] }], [0.24, { a: [1.5, 1.57], w: 1.57, b: [0.9, 1.9] }]],
    shB: [[0, { l: 0.05, b: [1.5, 1.57], a: [0.9, 1.9], w: 1.9 }], [0.07, { l: -0.02, b: [1.65, 1.9], a: [0.9, 1.9], w: 1.9 }], [0.24, { b: [1.5, 1.57], a: [0.9, 1.9], w: 1.9 }]],
    shD: [[0, { a: [1.5, 1.57], b: [1.45, 1.57], w: 1.57 }], [0.1, { a: [1.5, 1.57], b: [1.45, 1.57], w: 1.57 }], [0.14, { l: -0.1, a: [1.7, 2.0], b: [1.65, 2.0], w: 2.0 }], [0.4, {}]],
    burst: [[0, { l: 0.1, a: [1.5, 1.57], b: [1.45, 1.57], w: 1.57, y: 3, f: [13, 0], k: [-13, 0] }]],
    backshot: [[0, { l: -0.3, a: [1.5, 1.57], b: [1.4, 1.57], w: 1.57, f: [14, 6], k: [2, 0], y: 2 }]],
    lob: [[0, { l: -0.2, a: [-0.5, -0.9], w: -0.5 }], [0.2, { l: -0.25, a: [-0.8, -1.2], w: -0.8 }], [0.26, { l: 0.3, a: [2.2, 2.4], w: 2.4 }], [0.5, {}]],
    roll: [[0, { l: 0.9, y: 14, a: [1.2, 2.4], b: [1.0, 2.2], f: [6, 8], k: [-2, 10] }]],
    cast: [[0, { l: -0.05, a: [0.4, 1.2], w: 2.8 }], [0.12, { l: -0.1, a: [0.2, 1.0], w: 2.6 }], [0.18, { l: 0.2, a: [1.5, 1.6], w: 2.0, f: [12, 0] }], [0.42, {}]],
    cast2: [[0, { a: [2.6, 3.0], w: 3.14, l: -0.15 }], [0.2, { a: [2.8, 3.2], w: 3.3, l: -0.2 }], [0.26, { l: 0.3, a: [1.4, 1.5], w: 1.8, f: [13, 0] }], [0.56, {}]],
    castD: [[0, { a: [2.4, 2.8], w: 3.14 }], [0.16, { a: [2.6, 3.0], w: 3.14, y: -2 }], [0.22, { l: 0.3, a: [1.0, 1.2], w: 3.0, y: 6 }], [0.5, { l: 0.2, y: 4, a: [1.0, 1.2], w: 3.0 }]],
    castU: [[0, { a: [1.0, 1.4], w: 3.0, y: 4 }], [0.12, { l: -0.1, a: [2.8, 3.1], b: [2.6, 3.0], w: 3.14, y: -3 }], [0.5, { l: -0.1, a: [2.8, 3.1], b: [2.6, 3.0], w: 3.14, y: -3 }], [0.6, {}]],
    blink: [[0, { l: 0.3, y: 5, a: [1.0, 1.6], w: 2.6 }]],
    th1: [[0, { l: -0.1, a: [-0.2, 0.7], b: [0.6, 1.3], w: 1.6 }], [0.08, { l: -0.15, a: [-0.4, 0.5], w: 1.6 }], [0.15, { l: 0.45, a: [1.5, 1.57], b: [1.0, 1.5], w: 1.57, f: [17, 0], k: [-16, 0] }], [0.36, {}]],
    th2: [[0, { l: -0.1, a: [-0.2, 0.9], b: [0.6, 1.3], w: 1.7 }], [0.09, { l: -0.15, a: [-0.4, 0.7], w: 1.7 }], [0.16, { l: 0.45, a: [1.55, 1.7], b: [1.0, 1.5], w: 1.66, f: [17, 0], k: [-16, 0] }], [0.38, {}]],
    th3: [[0, { l: -0.1, a: [-0.3, 0.6], w: 1.6 }], [0.14, { l: 0.4, a: [1.5, 1.57], w: 1.57, f: [16, 0], k: [-15, 0] }], [0.19, { l: 0.1, a: [0.2, 1.0], w: 1.6, f: [16, 0], k: [-15, 0] }], [0.24, { l: 0.4, a: [1.5, 1.6], w: 1.6, f: [16, 0], k: [-15, 0] }], [0.3, { l: 0.1, a: [0.2, 1.0], w: 1.55, f: [16, 0], k: [-15, 0] }], [0.36, { l: 0.5, a: [1.55, 1.57], w: 1.57, f: [18, 0], k: [-16, 0] }], [0.62, {}]],
    lunge: [[0, { l: 0.6, a: [1.5, 1.57], b: [1.1, 1.5], w: 1.57, f: [18, 0], k: [-18, 4], y: 4 }]],
    sweep: [[0, { l: -0.2, a: [2.2, 2.6], b: [1.8, 2.2], w: 3.6 }], [0.18, { l: -0.25, a: [2.4, 2.8], w: 3.9 }], [0.26, { l: 0.35, a: [1.3, 1.3], b: [1.0, 1.2], w: 1.0, y: 5, f: [15, 0], k: [-14, 0] }], [0.62, { l: 0.2, a: [0.6, 0.9], w: 0.2 }]],
    hurl: [[0, { l: -0.25, a: [2.4, 3.4], w: 1.4, b: [1.3, 1.5] }], [0.22, { l: -0.35, a: [2.6, 3.7], w: 1.3 }], [0.28, { l: 0.45, a: [1.6, 1.5], w: 1.2, f: [16, 0], k: [-15, 0] }], [0.56, {}]],
    hop: [[0, { l: -0.3, y: 0, f: [10, 6], k: [2, 4] }]],
  };
  /* 적(사람꼴): 예고 자세 → 내려치는 자세 */
  const EAN = {
    e_sw: [{ l: -0.2, a: [2.6, 3.3], w: 4.0 }, Object.assign({ l: 0.4, a: [1.5, 1.4], w: 1.1 }, LUNGE)],
    e_th: [{ l: -0.15, a: [-0.4, 0.5], w: 1.6 }, Object.assign({ l: 0.45, a: [1.5, 1.57], w: 1.57 }, LUNGE)],
    e_sh: [{ l: -0.05, a: [1.5, 1.57], b: [1.2, 2.2], w: 3.14 }, { l: 0.02, a: [1.5, 1.57], b: [1.3, 1.6], w: 3.14 }],
    e_bash: [{ l: -0.2, b: [0.2, 1.2], a: [0.2, 0.9] }, Object.assign({ l: 0.5, b: [1.5, 1.57] }, LUNGE)],
    e_slam: [{ l: -0.3, a: [3.0, 3.6], b: [2.8, 3.4], w: 4.3, y: -2 }, Object.assign({ l: 0.6, a: [1.2, 1.1], b: [1.0, 1.0], w: 0.8, y: 8 }, LUNGE)],
    e_cast: [{ a: [2.8, 3.1], b: [2.6, 3.0], w: 3.14, y: -2 }, { a: [1.6, 1.7], b: [1.5, 1.6], w: 2.2, l: 0.15 }],
    e_whip: [{ l: -0.25, a: [2.8, 3.6], w: 4.2 }, Object.assign({ l: 0.4, a: [1.5, 1.5], w: 1.5 }, LUNGE)],
    e_fuse: [{ l: 0.3, a: [1.4, 1.8], b: [1.3, 1.7], y: 3 }, { l: 0.3, a: [1.4, 1.8], b: [1.3, 1.7], y: 3 }],
    e_charge: [{ l: 0.3, y: 6, a: [0.8, 1.3], w: 1.57 }, { l: 0.6, a: [1.5, 1.57], w: 1.57, f: [18, 0], k: [-18, 4], y: 4 }],
    e_combo: [{ l: -0.2, a: [2.6, 3.3], b: [2.2, 2.9], w: 4.0 }, Object.assign({ l: 0.45, a: [1.4, 1.3], b: [1.1, 1.2], w: 1.0 }, LUNGE)],
  };
  const P_HIT = { l: -0.35, a: [-0.4, 0.2], b: [-0.8, -0.3], h: -0.3 };
  const P_AIR = { l: -0.2, a: [2.2, 2.6], b: [1.8, 2.4], f: [8, 10], k: [-2, 6], h: -0.2 };
  const P_KNEEL = { l: 0.5, y: 12, a: [0.3, 0.2], b: [0.1, 0.1], f: [10, 0], k: [-12, 0], h: 0.5, w: 0.4 };
  const mix = (A, B, t) => {
    const o = {}; for (const k of ['l', 'w', 'y', 'h']) o[k] = lerp(A[k] || 0, B[k] != null ? B[k] : A[k] || 0, t);
    for (const k of ['a', 'b', 'f', 'k']) { const x = A[k], y = B[k] || x; o[k] = [lerp(x[0], y[0], t), lerp(x[1], y[1], t)]; }
    return o;
  };
  const full = (base, p) => ({ l: p.l != null ? p.l : base.l, w: p.w != null ? p.w : base.w, y: p.y != null ? p.y : base.y, h: p.h || 0, a: p.a || base.a, b: p.b || base.b, f: p.f || base.f, k: p.k || base.k });
  function animPose(base, kf, t) {
    if (kf.length === 1 || t <= kf[0][0]) return full(base, kf[0][1]);
    for (let i = 1; i < kf.length; i++) if (t < kf[i][0]) { const u = (t - kf[i - 1][0]) / (kf[i][0] - kf[i - 1][0]); return mix(full(base, kf[i - 1][1]), full(base, kf[i][1]), ease(u)); }
    return full(base, kf[kf.length - 1][1]);
  }

  /* ======================= 관절 인형 ======================= */
  const TH = 13, SH = 13, TO = 20, UA = 10, FA = 10, HR0 = 7.6;
  function limb(g, x0, y0, x1, y1, x2, y2, w, col, ol) {
    g.lineCap = 'round'; g.lineJoin = 'round';
    g.strokeStyle = ol; g.lineWidth = w + 2.6; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.lineTo(x2, y2); g.stroke();
    g.strokeStyle = col; g.lineWidth = w; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.lineTo(x2, y2); g.stroke();
  }
  function leg(g, hx, hy, fx, fy, col, ol, w) {
    let dx = fx - hx, dy = fy - hy, d = Math.hypot(dx, dy); const mx = TH + SH - 0.5;
    if (d > mx) { dx *= mx / d; dy *= mx / d; d = mx; fx = hx + dx; fy = hy + dy; }
    const a = Math.atan2(dy, dx), b = Math.acos(clamp(d / (TH + SH), 0, 1));
    const kx = hx + Math.cos(a - b) * TH, ky = hy + Math.sin(a - b) * TH;
    limb(g, hx, hy, kx, ky, fx, fy, w, col, ol);
    g.fillStyle = ol; g.beginPath(); g.ellipse(fx + 2.5, fy - 0.5, 5, 2.6, 0, 0, 7); g.fill();
  }
  function weapon(g, kind, hx, hy, ang, S, ol, off) {
    const c = Math.sin(ang), s = Math.cos(ang), wc = S.wcol || '#d8dce4';   // 방향 벡터(앞 = +x, 위 = −y)
    g.save(); g.translate(hx, hy); g.rotate(Math.atan2(s, c));
    g.lineJoin = 'round';
    const poly = (pts, fill) => { g.beginPath(); g.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.closePath(); g.fillStyle = fill; g.fill(); g.strokeStyle = ol; g.lineWidth = 1.6; g.stroke(); };
    switch (kind) {
      case 'gsword': poly([-9, -1.6, 4, -1.6, 4, 1.6, -9, 1.6], '#6a5038'); poly([3, -6, 6, -6, 6, 6, 3, 6], '#c8a858'); poly([6, -4.2, 44, -3.4, 51, 0, 44, 3.4, 6, 4.2], wc); g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1; g.beginPath(); g.moveTo(8, -1.5); g.lineTo(44, -1); g.stroke(); break;
      case 'blade': poly([-5, -1.4, 3, -1.4, 3, 1.4, -5, 1.4], '#5a4030'); poly([3, -2.4, 26, -1.8, 30, 0, 26, 1.8, 3, 2.4], wc); break;
      case 'axe': poly([-8, -1.5, 30, -1.5, 30, 1.5, -8, 1.5], '#5a4030'); poly([20, -1.5, 24, -13, 34, -11, 36, -1.5], wc); poly([20, 1.5, 24, 9, 32, 8, 34, 1.5], wc); break;
      case 'club': poly([-5, -1.5, 14, -1.5, 14, 1.5, -5, 1.5], '#5a4030'); poly([12, -3.6, 24, -4.4, 26, 0, 24, 4.4, 12, 3.6], '#7a6a5a'); break;
      case 'spear': case 'pike': poly([-22, -1.2, 46, -1.2, 46, 1.2, -22, 1.2], '#7a6040'); poly([44, -3.6, 58, 0, 44, 3.6], wc); break;
      case 'staff': poly([-14, -1.3, 32, -1.3, 32, 1.3, -14, 1.3], '#6a5038'); g.fillStyle = S.glow || '#c8a0ff'; g.beginPath(); g.arc(35, 0, 4.6, 0, 7); g.fill(); g.strokeStyle = ol; g.lineWidth = 1.4; g.stroke(); g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.arc(34, -1.4, 1.5, 0, 7); g.fill(); break;
      case 'guns': poly([-2, -2.2, 13, -2.2, 13, 1, 3, 1, 2, 5, -2, 5], off ? '#8a8f98' : wc); break;
      case 'bow': g.strokeStyle = ol; g.lineWidth = 4.4; g.beginPath(); g.arc(-8, 0, 17, -1.1, 1.1); g.stroke(); g.strokeStyle = '#8a6a42'; g.lineWidth = 2.2; g.beginPath(); g.arc(-8, 0, 17, -1.1, 1.1); g.stroke(); g.strokeStyle = '#ddd6c6'; g.lineWidth = 0.8; g.beginPath(); g.moveTo(-0.3, -15); g.lineTo(-0.3, 15); g.stroke(); break;
      case 'whip': g.strokeStyle = ol; g.lineWidth = 3.4; g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(18, -10, 34, 2); g.stroke(); g.strokeStyle = '#8a5a3a'; g.lineWidth = 1.6; g.stroke(); break;
      case 'hook': poly([-4, -1.2, 18, -1.2, 18, 1.2, -4, 1.2], '#6a5038'); g.strokeStyle = ol; g.lineWidth = 4; g.beginPath(); g.arc(20, 5, 5, -1.6, 1.8); g.stroke(); g.strokeStyle = wc; g.lineWidth = 2; g.stroke(); break;
      case 'bomb': g.fillStyle = '#4a3a34'; g.beginPath(); g.arc(8, 0, 7, 0, 7); g.fill(); g.strokeStyle = ol; g.lineWidth = 1.6; g.stroke(); g.fillStyle = '#ffb040'; g.beginPath(); g.arc(15, -3, 2, 0, 7); g.fill(); break;
      case 'anchor': poly([-10, -1.8, 34, -1.8, 34, 1.8, -10, 1.8], '#5a4a40'); g.strokeStyle = ol; g.lineWidth = 7; g.beginPath(); g.arc(30, 0, 12, -1.5, 1.5); g.stroke(); g.strokeStyle = wc; g.lineWidth = 4; g.stroke(); break;
    }
    g.restore();
  }
  /* S: { skin, hair, top, pants, wpn, off, head, wcol, glow, cape, thick } · fl = 맞아서 번쩍, ol = 외곽선 색 */
  function rig(g, P, S, fl, ol, hideW) {
    const C = (c) => (fl ? '#fff' : c);
    const tw = S.thick ? 14 : S.fem ? 9 : 10.5, lw = S.thick ? 8 : S.fem ? 5 : 5.6, aw = S.thick ? 7 : S.fem ? 4 : 4.8, HR = S.hr || HR0;
    const hx = 0, hy = -(TH + SH) + 1 + P.y;
    const sl = Math.sin(P.l), cl = Math.cos(P.l);
    const nx = hx + sl * TO, ny = hy - cl * TO;
    const hdx = nx + Math.sin(P.l + (P.h || 0)) * (HR + 1), hdy = ny - Math.cos(P.l + (P.h || 0)) * (HR + 1);
    const shx = nx - sl * 3, shy = ny + cl * 3;
    const arm = (q) => { const ex = shx + Math.sin(q[0]) * UA, ey = shy + Math.cos(q[0]) * UA; return [ex, ey, ex + Math.sin(q[1]) * FA, ey + Math.cos(q[1]) * FA]; };
    const A = arm(P.a), B = arm(P.b);
    if (S.cape) { g.fillStyle = C(S.cape); g.strokeStyle = ol; g.lineWidth = 1.6; g.beginPath(); g.moveTo(nx - 2, ny + 1); g.quadraticCurveTo(nx - 13 - sl * 8, hy - 4, hx - 12 - sl * 14, hy + 9); g.lineTo(hx - 3, hy + 3); g.closePath(); g.fill(); g.stroke(); }
    /* 뒷팔 · 뒷손 물건 */
    limb(g, shx, shy, B[0], B[1], B[2], B[3], aw, C(S.arm2 || S.top2 || S.top), ol);
    if (S.wpn === 'guns' && !hideW) weapon(g, 'guns', B[2], B[3], P.b[1], S, ol, 1);
    if (S.wpn === 'fist') { g.fillStyle = C(S.wcol || '#c8ccd4'); g.beginPath(); g.arc(B[2], B[3], 4.4, 0, 7); g.fill(); g.strokeStyle = ol; g.lineWidth = 1.4; g.stroke(); }
    leg(g, hx - 1.5, hy, hx + P.k[0], -P.k[1], C(S.pants2 || S.pants), ol, lw);
    /* 몸통 */
    g.lineCap = 'round'; g.strokeStyle = ol; g.lineWidth = tw + 2.8; g.beginPath(); g.moveTo(hx, hy); g.lineTo(nx, ny); g.stroke();
    g.strokeStyle = C(S.top); g.lineWidth = tw; g.beginPath(); g.moveTo(hx, hy); g.lineTo(nx, ny); g.stroke();
    if (S.trim && !fl) { g.strokeStyle = S.trim; g.lineWidth = 2.4; g.beginPath(); g.moveTo(hx + cl * 1.5 + sl * 3, hy + sl * 1.5 - cl * 3); g.lineTo(nx + cl * 1.5 - sl * 4, ny + sl * 1.5 + cl * 4); g.stroke(); }
    leg(g, hx + 1.5, hy, hx + P.f[0], -P.f[1], C(S.pants), ol, lw);
    if (S.skirt) { g.save(); g.translate(hx, hy); g.rotate(P.l * 0.5); g.fillStyle = C(S.skirt); g.strokeStyle = ol; g.lineWidth = 1.6; g.beginPath(); g.moveTo(-5, -4); g.lineTo(5.5, -4); g.lineTo(8 + P.f[0] * 0.25, S.skl || 8); g.lineTo(-8 + P.k[0] * 0.25, S.skl || 8); g.closePath(); g.fill(); g.stroke(); g.restore(); }
    if (S.off === 'shield') { const sx = B[2] + 3, sy = B[3]; g.fillStyle = C(S.scol || '#8a8f9a'); g.strokeStyle = ol; g.lineWidth = 1.8; g.beginPath(); g.ellipse(sx, sy, 5.5 * (S.big ? 1.3 : 1), 12 * (S.big ? 1.3 : 1), 0.1, 0, 7); g.fill(); g.stroke(); if (!fl) { g.fillStyle = 'rgba(255,255,255,.3)'; g.beginPath(); g.ellipse(sx + 1, sy - 2, 2, 6, 0.1, 0, 7); g.fill(); } }
    /* 머리 */
    const ha = P.l + (P.h || 0);
    g.save(); g.translate(hdx, hdy); g.rotate(ha * 0.6);
    if (S.hair && S.hstyle && S.hstyle !== 'spike') {
      g.fillStyle = C(S.hair2 || S.hair); g.strokeStyle = ol; g.lineWidth = 1.5; const hs = S.hstyle;
      const blob = (pts) => { g.beginPath(); g.moveTo(pts[0], pts[1]); for (let q = 2; q < pts.length; q += 4) g.quadraticCurveTo(pts[q], pts[q + 1], pts[q + 2], pts[q + 3]); g.closePath(); g.fill(); g.stroke(); };
      if (hs === 'tail') blob([-4, -5, -19, -4, -16, 17, -10, 8, -5, 2]);
      else if (hs === 'long') blob([-2, -7, -13, -3, -10, 19, -5, 12, -2, 6]);
      else if (hs === 'bob') blob([-2, -7, -11, -4, -8, 8, -4, 7, -1, 5]);
      else if (hs === 'twin') { blob([-3, -5, -17, -8, -18, 12, -12, 4, -5, 0]); blob([-1, -3, -9, 2, -8, 18, -4, 10, -1, 4]); }
      else if (hs === 'braid') { blob([-4, -4, -11, -2, -9, 6, -6, 4, -4, 1]); for (let q = 0; q < 3; q++) { g.beginPath(); g.ellipse(-9 - q * 0.6, 8 + q * 5, 2.6 - q * 0.3, 3, 0.2, 0, 7); g.fill(); g.stroke(); } }
    }
    g.fillStyle = C(S.skin || '#f0cfb0'); g.strokeStyle = ol; g.lineWidth = 1.8; g.beginPath(); g.arc(0, 0, HR, 0, 7); g.fill(); g.stroke();
    if (!fl) {
      switch (S.head) {
        case 'helm': g.fillStyle = S.hcol || '#8a8f9a'; g.beginPath(); g.arc(0, 0, HR, Math.PI * 0.95, Math.PI * 2.15); g.lineTo(HR * 0.9, 1.5); g.lineTo(-HR, 1.5); g.closePath(); g.fill(); g.stroke(); g.fillStyle = INK; g.fillRect(1.5, -1.6, 5.5, 2); break;
        case 'skull': g.fillStyle = INK; g.beginPath(); g.arc(3, -0.5, 2.1, 0, 7); g.fill(); g.fillRect(1, 3.4, 5, 1.2); break;
        case 'hood': g.fillStyle = S.hcol || S.top; g.beginPath(); g.moveTo(-HR - 1, 4); g.quadraticCurveTo(-HR - 2, -HR - 4, 2, -HR - 1); g.quadraticCurveTo(HR, -HR + 2, HR - 1, -1); g.quadraticCurveTo(0, -3, -1, 5); g.closePath(); g.fill(); g.stroke(); g.fillStyle = S.eye || '#f0e0a0'; g.fillRect(3, -0.8, 2.6, 1.6); break;
        case 'hat': g.fillStyle = S.hcol || '#3a3038'; g.beginPath(); g.ellipse(0, -HR + 2, HR + 5, 2.6, 0, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.arc(0, -HR + 2, HR - 1.5, Math.PI, Math.PI * 2); g.closePath(); g.fill(); g.stroke(); g.fillStyle = INK; g.fillRect(3, -0.6, 2, 2); break;
        case 'band': g.fillStyle = S.hair || '#3a2a28'; g.beginPath(); g.arc(0, 0, HR, Math.PI * 1.0, Math.PI * 1.95); g.closePath(); g.fill(); g.strokeStyle = S.hcol || '#b04a3a'; g.lineWidth = 2.2; g.beginPath(); g.moveTo(-HR, -1.8); g.lineTo(HR, -2.4); g.stroke(); g.fillStyle = INK; g.fillRect(3, -0.4, 2, 2); break;
        default:
          if (S.hair) { g.fillStyle = S.hair; g.strokeStyle = ol; g.lineWidth = 1.5; g.beginPath(); g.arc(0, 0, HR + 0.6, Math.PI * 0.82, Math.PI * 1.98); g.quadraticCurveTo(4, -2.5, 2, 0.5); g.quadraticCurveTo(-1, -3, -4.6, -0.6); g.closePath(); g.fill(); g.stroke(); if (S.hstyle === 'spike') { g.beginPath(); g.moveTo(-2, -HR); g.lineTo(2, -HR - 5); g.lineTo(4, -HR + 1); g.closePath(); g.fill(); g.stroke(); } }
          g.fillStyle = S.eye || INK; g.beginPath(); g.ellipse(HR * 0.5, 0.6, 1.1, S.fem ? 1.9 : 1.7, 0, 0, 7); g.fill(); if (S.fem) { g.strokeStyle = INK; g.lineWidth = 0.8; g.beginPath(); g.moveTo(HR * 0.5 - 1.6, -1.2); g.lineTo(HR * 0.5 + 1.8, -1.6); g.stroke(); }
      }
    }
    g.restore();
    /* 앞팔 · 무기 */
    if (S.wpn && S.wpn !== 'fist' && S.wpn !== 'none' && !hideW) weapon(g, S.wpn, A[2], A[3], P.w, S, ol, 0);
    limb(g, shx, shy, A[0], A[1], A[2], A[3], aw, C(S.arm || S.top), ol);
    if (S.wpn === 'fist') { g.fillStyle = C(S.wcol || '#c8ccd4'); g.beginPath(); g.arc(A[2], A[3], 4.8, 0, 7); g.fill(); g.strokeStyle = ol; g.lineWidth = 1.4; g.stroke(); }
    else { g.fillStyle = C(S.skin || '#f0cfb0'); g.beginPath(); g.arc(A[2], A[3], 2.6, 0, 7); g.fill(); }
    return { hx: A[2], hy: A[3], headY: hdy - HR };
  }
  /* 직업 다섯 모두 성인 여성: 머리는 작게(hr), 몸은 가늘고 길게(그릴 때 세로로 조금 늘림), 머리 모양 · 색 · 무기로 구분 */
  const PSTY = [
    { fem: 1, hr: 6.3, skin: '#f2d2b4', hair: '#e8e0d8', hstyle: 'tail', top: '#b8433a', trim: '#f0d9a0', pants: '#3a3340', pants2: '#2e2834', wpn: 'gsword', wcol: '#d8dee8', cape: '#7a2a2a', eye: '#b03030', skirt: '#8a3030', skl: 9 },
    { fem: 1, hr: 6.3, skin: '#f0cdb0', hair: '#4a3028', hstyle: 'bob', top: '#d88a2e', trim: '#fff0c0', pants: '#40363a', pants2: '#332b30', wpn: 'fist', wcol: '#d0d4dc', eye: '#7a4a10', skirt: '#5a4038', skl: 6 },
    { fem: 1, hr: 6.3, skin: '#f4d6bc', hair: '#3f5f9a', hstyle: 'twin', top: '#3f84c0', trim: '#e8f0ff', pants: '#2e3444', pants2: '#252a38', wpn: 'guns', wcol: '#e0e4ea', cape: '#28466e', eye: '#2a5a9a', skirt: '#2c4a78', skl: 7 },
    { fem: 1, hr: 6.3, skin: '#f0d0c0', hair: '#5a3a8a', hstyle: 'long', top: '#7c50c0', trim: '#e8d0ff', pants: '#2f2840', pants2: '#262034', wpn: 'staff', glow: '#d0a8ff', cape: '#4a2e7a', eye: '#8a4ad0', skirt: '#5a3a9a', skl: 15 },
    { fem: 1, hr: 6.3, skin: '#eccba8', hair: '#2a4a3c', hstyle: 'braid', top: '#3f9a76', trim: '#e0ffe8', pants: '#2c3a34', pants2: '#24302b', wpn: 'spear', wcol: '#dfe6ea', eye: '#1a6a4a', skirt: '#2c6a54', skl: 8 },
  ];
  function foeStyle(K) {
    if (K._s) return K._s;
    const c = K.col, dark = shade(c, -0.3);
    const bone = K.head === 'skull';
    K._s = { skin: bone ? '#d8d0b8' : K.head === 'hood' ? '#2a2430' : '#c8a888', top: c, top2: dark, pants: shade(c, -0.45), pants2: shade(c, -0.55), arm: bone ? '#d8d0b8' : c, arm2: bone ? '#b8b0a0' : dark, wpn: K.wpn || 'none', off: K.off, head: K.head, hcol: K.head === 'helm' ? shade(c, 0.25) : K.head === 'hood' ? dark : undefined, wcol: '#c0c4cc', glow: '#b080ff', thick: K.sh === 'golem' || K.id === 'heads' || K.id === 'anchor', big: K.id === 'tower' || K.boss, scol: shade(c, 0.15), eye: K.zone === 2 ? '#a0e0ff' : '#f0e0a0', cape: K.boss && K.wpn ? shade(c, -0.2) : undefined };
    return K._s;
  }
  function shade(hex, f) { const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255; if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')'; }

  /* ======================= 짐승 · 기계 · 정령(도형) =======================
     원점 = 발밑, 오른쪽을 봄. u = 예고 진행(0~1), s = 친 직후(1 → 0), ph = 걸음 위상, tm = 시각 */
  const CRE = {
    rat(g, K, c, ol, u, s, ph) { const cr = 1 - u * 0.2; g.fillStyle = c; g.strokeStyle = ol; g.lineWidth = 1.6; g.beginPath(); g.moveTo(-12, -8); g.quadraticCurveTo(-24, -14, -22, -3); g.stroke(); g.beginPath(); g.ellipse(0, -8 * cr, 12, 7 * cr, 0, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.ellipse(11 + s * 4, -9 * cr, 6, 4.6, 0.2, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.arc(8, -14 * cr, 2.6, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#ff8060'; g.beginPath(); g.arc(13, -10 * cr, 1.2, 0, 7); g.fill(); g.strokeStyle = ol; g.lineWidth = 2; for (let i = 0; i < 2; i++) { const o = Math.sin(ph + i * 3) * 3; g.beginPath(); g.moveTo(-5 + i * 10, -3); g.lineTo(-5 + i * 10 + o, 0); g.stroke(); } },
    slime(g, K, c, ol, u, s, ph, tm) { const sy = 1 - u * 0.28 + s * 0.2 + Math.sin(tm * 3) * 0.03, sx = 1 + u * 0.2 - s * 0.1; const w = 20 * sx, h = 30 * sy; g.fillStyle = c; g.strokeStyle = ol; g.lineWidth = 2; g.beginPath(); g.moveTo(-w, 0); g.bezierCurveTo(-w * 1.1, -h * 0.9, -w * 0.5, -h, 0, -h); g.bezierCurveTo(w * 0.5, -h, w * 1.1, -h * 0.9, w, 0); g.closePath(); g.fill(); g.stroke(); g.fillStyle = 'rgba(255,255,255,.28)'; g.beginPath(); g.ellipse(-w * 0.35, -h * 0.68, w * 0.22, h * 0.12, -0.5, 0, 7); g.fill(); g.fillStyle = INK; g.beginPath(); g.ellipse(w * 0.3, -h * 0.5, 2.2, 3.4, 0, 0, 7); g.ellipse(w * 0.68, -h * 0.46, 1.8, 3, 0, 0, 7); g.fill(); if (K.boss) { g.beginPath(); g.ellipse(w * 0.5, -h * 0.24, w * 0.3, 2 + u * 5, 0, 0, 7); g.fill(); } },
    bug(g, K, c, ol, u, s, ph, tm) { const fl = Math.sin(tm * 34) * 0.5; g.fillStyle = 'rgba(220,235,255,.5)'; g.strokeStyle = ol; g.lineWidth = 1; g.beginPath(); g.ellipse(-3, -24, 11, 4, -0.5 + fl, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.ellipse(-3, -22, 11, 4, 0.3 - fl, 0, 7); g.fill(); g.stroke(); g.fillStyle = c; g.lineWidth = 1.8; g.beginPath(); g.ellipse(-5, -12, 9, 6.5, -0.3, 0, 7); g.fill(); g.stroke(); g.fillStyle = INK; g.fillRect(-9, -15, 2, 7); g.fillRect(-4, -17, 2, 8); g.fillStyle = c; g.beginPath(); g.arc(6, -15, 5.5, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#ff5040'; g.beginPath(); g.arc(8, -16, 1.6, 0, 7); g.fill(); g.strokeStyle = ol; g.lineWidth = 2; g.beginPath(); g.moveTo(-13, -9); g.lineTo(-20 - u * 3, -4); g.stroke(); if (u > 0.3) { g.fillStyle = '#9fd05a'; g.beginPath(); g.arc(11, -12, 2 + u * 3, 0, 7); g.fill(); } },
    bloat(g, K, c, ol, u, s, ph) { const k = 1 + u * 0.35; g.strokeStyle = ol; g.lineWidth = 2.4; for (let i = 0; i < 2; i++) { const o = Math.sin(ph + i * 3) * 3; g.beginPath(); g.moveTo(-6 + i * 12, -8); g.lineTo(-6 + i * 12 + o, 0); g.stroke(); } g.fillStyle = u > 0.05 ? shade('#d05a58', -0.1 + u * 0.3) : c; g.lineWidth = 2; g.beginPath(); g.ellipse(0, -22 * k, 16 * k, 17 * k, 0, 0, 7); g.fill(); g.stroke(); g.fillStyle = 'rgba(255,255,255,.22)'; g.beginPath(); g.ellipse(-5 * k, -30 * k, 5 * k, 3 * k, -0.5, 0, 7); g.fill(); g.fillStyle = INK; g.beginPath(); g.arc(7, -24 * k, 2, 0, 7); g.arc(12, -21 * k, 1.6, 0, 7); g.fill(); g.strokeStyle = shade(c, -0.35); g.lineWidth = 1.2; g.beginPath(); g.moveTo(-10 * k, -14 * k); g.quadraticCurveTo(0, -8 * k, 10 * k, -15 * k); g.stroke(); },
    crab(g, K, c, ol, u, s, ph) { const up = u * 10 - s * 4; g.strokeStyle = ol; g.lineWidth = 2.6; for (let i = 0; i < 3; i++) { const o = Math.sin(ph + i * 2) * 2.5; g.beginPath(); g.moveTo(-10 + i * 9, -8); g.lineTo(-16 + i * 12 + o, 0); g.stroke(); } g.fillStyle = c; g.lineWidth = 2; g.beginPath(); g.ellipse(0, -15, 22, 13, 0, Math.PI, 0); g.lineTo(22, -9); g.lineTo(-22, -9); g.closePath(); g.fill(); g.stroke(); g.fillStyle = shade(c, 0.28); g.beginPath(); g.ellipse(8, -19, 9, 5, -0.3, 0, 7); g.fill(); g.fillStyle = c; g.beginPath(); g.ellipse(24 + s * 8, -18 - up, 8, 6, -0.4, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.ellipse(-20, -14 - up * 0.5, 6, 4.5, 0.4, 0, 7); g.fill(); g.stroke(); g.strokeStyle = ol; g.lineWidth = 1.4; g.beginPath(); g.moveTo(8, -26); g.lineTo(9, -31); g.moveTo(14, -25); g.lineTo(16, -30); g.stroke(); g.fillStyle = INK; g.beginPath(); g.arc(9, -32, 1.6, 0, 7); g.arc(16, -31, 1.6, 0, 7); g.fill(); },
    vine(g, K, c, ol, u, s, ph, tm) { const sw = Math.sin(tm * 1.6) * 3, bk = -u * 16, fw = s * 26; const tx = 6 + sw + bk + fw, ty = -50 + u * 6 + s * 16; g.strokeStyle = ol; g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.bezierCurveTo(-12, -18, 12 + bk, -32, tx, ty); g.stroke(); g.strokeStyle = c; g.lineWidth = 6; g.stroke(); g.fillStyle = shade(c, -0.25); g.strokeStyle = ol; g.lineWidth = 1.6; g.beginPath(); g.ellipse(-10, -3, 9, 4, 0.3, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.ellipse(9, -3, 8, 3.6, -0.3, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#b04858'; g.lineWidth = 2; g.beginPath(); g.ellipse(tx + 5, ty, 11, 8, 0, 0.5 + u * 0.4, Math.PI * 2 - 0.5 - u * 0.4); g.lineTo(tx + 5, ty); g.closePath(); g.fill(); g.stroke(); },
    wolf(g, K, c, ol, u, s, ph) { const cr = u * 5, st = s * 5; g.strokeStyle = ol; g.lineWidth = 3.4; g.lineCap = 'round'; for (let i = 0; i < 4; i++) { const o = Math.sin(ph + i * 1.6) * 4, bx = [-13, -8, 9, 13][i]; g.beginPath(); g.moveTo(bx, -12 + cr); g.lineTo(bx + o + (i > 1 ? st : -st), 0); g.stroke(); } g.fillStyle = c; g.lineWidth = 2; g.beginPath(); g.moveTo(-15, -20 + cr); g.quadraticCurveTo(-28, -30 + cr, -27, -14 + cr); g.quadraticCurveTo(-21, -18 + cr, -14, -15 + cr); g.closePath(); g.fill(); g.stroke(); g.beginPath(); g.ellipse(0, -18 + cr, 17, 8.5, -0.06, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.moveTo(11, -26 + cr); g.lineTo(13, -34 + cr); g.lineTo(18, -28 + cr); g.lineTo(28 + st, -22 + cr * 1.4); g.lineTo(26 + st, -17 + cr * 1.4); g.lineTo(13, -15 + cr); g.closePath(); g.fill(); g.stroke(); g.fillStyle = '#ffd060'; g.beginPath(); g.arc(19, -24 + cr, 1.5, 0, 7); g.fill(); if (u > 0.4 || s > 0.2) { g.fillStyle = '#fff'; g.beginPath(); g.moveTo(22 + st, -18 + cr * 1.4); g.lineTo(24 + st, -14 + cr * 1.4); g.lineTo(26 + st, -18 + cr * 1.4); g.fill(); } },
    boar(g, K, c, ol, u, s, ph) { const bk = -u * 5; g.strokeStyle = ol; g.lineWidth = 4; g.lineCap = 'round'; for (let i = 0; i < 4; i++) { const o = Math.sin(ph + i * 1.6) * 3.5 + (i === 2 ? -u * 4 * Math.sin(ph * 3 + u * 20) : 0), bx = [-15, -9, 9, 14][i]; g.beginPath(); g.moveTo(bx + bk, -10); g.lineTo(bx + bk + o, 0); g.stroke(); } g.fillStyle = c; g.lineWidth = 2; g.beginPath(); g.ellipse(bk, -19, 22, 13, 0, 0, 7); g.fill(); g.stroke(); g.fillStyle = shade(c, -0.25); g.beginPath(); g.moveTo(-14 + bk, -30); g.lineTo(-4 + bk, -36); g.lineTo(8 + bk, -31); g.closePath(); g.fill(); g.fillStyle = shade(c, 0.12); g.beginPath(); g.ellipse(20 + bk + s * 5, -15, 10, 8.5, 0.2, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#f0e8d0'; g.beginPath(); g.moveTo(24 + bk, -11); g.lineTo(33 + bk + s * 5, -19); g.lineTo(27 + bk, -14); g.closePath(); g.fill(); g.stroke(); g.fillStyle = '#ff6040'; g.beginPath(); g.arc(21 + bk, -19, 1.6, 0, 7); g.fill(); },
    plant(g, K, c, ol, u, s, ph, tm) { const sw = Math.sin(tm * 1.8) * 2, tx = 2 + sw - u * 9 + s * 10, ty = -36; g.strokeStyle = ol; g.lineWidth = 7; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.quadraticCurveTo(-8, -18, tx, ty); g.stroke(); g.strokeStyle = shade(c, -0.2); g.lineWidth = 4.4; g.stroke(); g.fillStyle = shade(c, -0.3); g.strokeStyle = ol; g.lineWidth = 1.6; g.beginPath(); g.ellipse(-9, -2, 9, 3.6, 0.2, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.ellipse(9, -2, 8, 3.2, -0.2, 0, 7); g.fill(); g.stroke(); g.fillStyle = c; g.lineWidth = 2; g.beginPath(); g.arc(tx, ty, 9.5, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#e8d870'; for (let i = 0; i < 5; i++) { const a = -0.9 + i * 0.45; g.beginPath(); g.moveTo(tx + Math.cos(a) * 8, ty + Math.sin(a) * 8); g.lineTo(tx + Math.cos(a) * (14 + u * 3), ty + Math.sin(a) * (14 + u * 3)); g.lineTo(tx + Math.cos(a + 0.25) * 8, ty + Math.sin(a + 0.25) * 8); g.fill(); } g.fillStyle = INK; g.beginPath(); g.arc(tx + 4, ty - 1, 1.7, 0, 7); g.fill(); },
    wisp(g, K, c, ol, u, s, ph, tm) { const r = 10 + u * 6 + Math.sin(tm * 4) * 0.8, y = -16; const gr = g.createRadialGradient(0, y, 1, 0, y, r * 1.9); gr.addColorStop(0, '#fff6d0'); gr.addColorStop(0.35, u > 0.3 ? '#ff6040' : c); gr.addColorStop(1, 'rgba(255,120,40,0)'); g.fillStyle = gr; g.beginPath(); g.arc(0, y, r * 1.9, 0, 7); g.fill(); g.fillStyle = u > 0.3 ? '#ff7050' : c; g.strokeStyle = ol; g.lineWidth = 1.6; g.beginPath(); g.moveTo(-r * 0.8, y + 2); g.quadraticCurveTo(-r * 1.2 + Math.sin(tm * 5) * 2, y - r * 1.5, 0, y - r * 1.7 - Math.sin(tm * 6) * 2); g.quadraticCurveTo(r * 1.1, y - r * 1.2, r * 0.8, y + 2); g.arc(0, y + 1, r * 0.8, 0, Math.PI); g.closePath(); g.fill(); g.stroke(); g.fillStyle = INK; g.beginPath(); g.ellipse(3, y, 1.4, 2.4, 0, 0, 7); g.ellipse(7, y, 1.2, 2.2, 0, 0, 7); g.fill(); },
    crow(g, K, c, ol, u, s, ph, tm) { const fl = Math.sin(tm * 9) * (0.6 - u * 0.3); g.fillStyle = shade(c, -0.2); g.strokeStyle = ol; g.lineWidth = 1.8; g.beginPath(); g.moveTo(-4, -16); g.quadraticCurveTo(-22, -30 - fl * 22, -30, -16 - fl * 26); g.quadraticCurveTo(-16, -14, -6, -10); g.closePath(); g.fill(); g.stroke(); g.fillStyle = c; g.beginPath(); g.ellipse(0, -13, 11, 7.5, -0.25, 0, 7); g.fill(); g.stroke(); g.beginPath(); g.moveTo(-9, -10); g.lineTo(-19, -5); g.lineTo(-8, -7); g.closePath(); g.fill(); g.stroke(); g.beginPath(); g.arc(9, -19, 6, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#e8c060'; g.beginPath(); g.moveTo(14, -20); g.lineTo(22, -17); g.lineTo(14, -16); g.closePath(); g.fill(); g.stroke(); g.fillStyle = u > 0.2 ? '#c070ff' : '#f0e0a0'; g.beginPath(); g.arc(11, -20, 1.6 + u, 0, 7); g.fill(); g.fillStyle = shade(c, -0.2); g.beginPath(); g.moveTo(2, -17); g.quadraticCurveTo(-12, -32 + fl * 20, -22, -22 + fl * 24); g.quadraticCurveTo(-10, -14, 0, -10); g.closePath(); g.fill(); g.stroke(); },
    cart(g, K, c, ol, u, s, ph, tm) { g.fillStyle = shade(c, -0.35); g.strokeStyle = ol; g.lineWidth = 2.4; g.beginPath(); g.rect(-40, -44, 76, 30); g.fill(); g.stroke(); g.fillStyle = c; g.beginPath(); g.moveTo(-44, -40); g.lineTo(30, -40); g.lineTo(44, -22); g.lineTo(44, -12); g.lineTo(-44, -12); g.closePath(); g.fill(); g.stroke(); g.strokeStyle = shade(c, -0.3); g.lineWidth = 1.4; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(-30 + i * 18, -40); g.lineTo(-30 + i * 18, -12); g.stroke(); } g.strokeStyle = ol; g.lineWidth = 2.4; g.fillStyle = '#8a8f9a'; g.beginPath(); g.moveTo(34, -44); g.lineTo(48, -30); g.lineTo(48, -8); g.lineTo(38, -8); g.closePath(); g.fill(); g.stroke(); g.fillStyle = '#3a3a44'; g.save(); g.translate(0, -52); g.rotate(-0.25 - u * 0.25); g.beginPath(); g.rect(-6, -7, 44 - s * 6, 14); g.fill(); g.stroke(); g.fillStyle = u > 0.2 ? '#ff9050' : '#17131c'; g.beginPath(); g.ellipse(38 - s * 6, 0, 3, 6, 0, 0, 7); g.fill(); g.restore(); g.fillStyle = '#4a3a30'; for (const wx of [-26, 22]) { g.beginPath(); g.arc(wx, -11, 11, 0, 7); g.fill(); g.stroke(); g.save(); g.translate(wx, -11); g.rotate(ph * 0.5); g.strokeStyle = '#8a7a60'; g.lineWidth = 1.6; for (let i = 0; i < 3; i++) { g.rotate(Math.PI / 3); g.beginPath(); g.moveTo(-10, 0); g.lineTo(10, 0); g.stroke(); } g.restore(); g.strokeStyle = ol; g.lineWidth = 2.4; } g.fillStyle = '#5a4a48'; g.beginPath(); g.arc(-18, -58, 7, 0, 7); g.fill(); g.stroke(); g.fillStyle = '#f0e0a0'; g.fillRect(-15, -59, 3, 2); void tm; },
    tree(g, K, c, ol, u, s, ph, tm) { const sw = Math.sin(tm * 0.9) * 0.03, up = u * 1.2 - s * 0.9; g.fillStyle = shade(c, -0.2); g.strokeStyle = ol; g.lineWidth = 2.4; g.beginPath(); g.moveTo(-26, 0); g.lineTo(-40, 2); g.lineTo(-22, -10); g.lineTo(-10, 0); g.lineTo(8, -6); g.lineTo(30, 3); g.lineTo(22, -12); g.closePath(); g.fill(); g.stroke(); g.fillStyle = c; g.beginPath(); g.moveTo(-24, -6); g.bezierCurveTo(-30, -50, -24, -84, -18, -104); g.lineTo(-30, -124); g.lineTo(-12, -112); g.lineTo(-4, -132); g.lineTo(4, -112); g.lineTo(22, -128); g.lineTo(16, -104); g.bezierCurveTo(26, -80, 28, -44, 22, -6); g.closePath(); g.fill(); g.stroke(); const armF = (bx, by, dir, a) => { g.save(); g.translate(bx, by); g.rotate(a); g.strokeStyle = ol; g.lineWidth = 15; g.lineCap = 'round'; g.beginPath(); g.moveTo(0, 0); g.lineTo(dir * 30, 14); g.lineTo(dir * 44, 44); g.stroke(); g.strokeStyle = shade(c, 0.08); g.lineWidth = 11; g.stroke(); g.restore(); }; armF(-20, -78, -1, sw + up * 0.5); armF(18, -80, 1, -sw - up); g.fillStyle = '#ffb050'; g.beginPath(); g.moveTo(-2, -76); g.lineTo(6, -72); g.lineTo(-1, -68); g.closePath(); g.fill(); g.beginPath(); g.moveTo(10, -78); g.lineTo(18, -74); g.lineTo(11, -70); g.closePath(); g.fill(); g.fillStyle = INK; g.beginPath(); g.moveTo(-2, -56); g.quadraticCurveTo(8, -50 + u * 6, 18, -58); g.quadraticCurveTo(8, -60, -2, -56); g.fill(); },
  };
  const CBASE = { rat: 22, slime: 34, bug: 26, bloat: 40, crab: 32, vine: 56, wolf: 30, boar: 34, plant: 44, wisp: 26, crow: 26, cart: 70, tree: 110 };

  /* ======================= 배경(코드로 그린 기본 배경 — 그림이 있으면 그 위 층을 대신함) ======================= */
  const TILE = 720;
  function paintLayer(zid, layer, K, hpx, Z) {
    const cv = document.createElement('canvas'); cv.width = Math.ceil(TILE * K); cv.height = Math.ceil(hpx);
    const g = cv.getContext('2d'); g.scale(K, K); const H = hpx / K; let n = zid * 97 + layer * 13;
    const R = () => hash(n++);
    const far = layer === 0, col = far ? Z.far : shade(Z.far.length === 7 ? Z.far : '#333333', -0.35);
    g.fillStyle = col;
    if (zid === 0) {   // 항만: 기중기 · 돛대 / 창고 · 상자
      if (far) { for (let i = 0; i < 5; i++) { const x = i * 150 + R() * 60, h = 90 + R() * 70; g.fillRect(x, H - h, 7, h); g.fillRect(x - 30, H - h, 70, 5); g.fillRect(x + 34, H - h, 2, 40 + R() * 30); g.beginPath(); g.moveTo(x + 3, H - h - 24); g.lineTo(x - 30, H - h); g.lineTo(x + 40, H - h); g.fill(); } g.fillRect(0, H - 26, TILE, 26); for (let i = 0; i < 6; i++) { const x = i * 124 + R() * 40; g.fillRect(x, H - 60 - R() * 20, 3, 60); g.beginPath(); g.moveTo(x + 3, H - 74); g.lineTo(x + 30, H - 40); g.lineTo(x + 3, H - 40); g.fill(); } }
      else { for (let i = 0; i < 4; i++) { const x = i * 180 + R() * 30, w = 110 + R() * 50, h = 70 + R() * 50; g.fillStyle = col; g.fillRect(x, H - h, w, h); g.beginPath(); g.moveTo(x - 6, H - h); g.lineTo(x + w / 2, H - h - 22); g.lineTo(x + w + 6, H - h); g.fill(); g.fillStyle = 'rgba(255,190,110,.22)'; for (let j = 0; j < 3; j++) if (R() > 0.4) g.fillRect(x + 14 + j * 30, H - h + 18, 12, 14); g.fillStyle = shade(Z.floor[1], -0.2); g.fillRect(x + w - 26, H - 22, 22, 22); g.fillRect(x + w - 44, H - 14, 16, 14); } }
    } else if (zid === 1) {   // 수로: 아치 · 관
      if (far) { g.fillRect(0, 0, TILE, H); g.fillStyle = shade(Z.sky[1], -0.15); for (let i = 0; i < 4; i++) { const x = i * 180 + 30; g.beginPath(); g.moveTo(x, H); g.lineTo(x, H * 0.45); g.quadraticCurveTo(x + 60, H * 0.12, x + 120, H * 0.45); g.lineTo(x + 120, H); g.fill(); } }
      else { g.fillRect(0, H - 54, TILE, 54); g.fillStyle = shade(Z.floor[1], -0.3); for (let i = 0; i < 16; i++) g.fillRect(i * 46 + (i % 2) * 8, H - 52 + (i % 3) * 16, 40, 2); g.fillStyle = col; for (let i = 0; i < 3; i++) { const x = i * 240 + 60 + R() * 60; g.fillRect(x, 0, 16, H - 54); g.fillRect(x - 5, H * 0.3, 26, 7); g.fillRect(x - 5, H * 0.62, 26, 7); } g.fillStyle = shade(Z.acc, -0.55); for (let i = 0; i < 3; i++) { const x = i * 240 + 170; g.beginPath(); g.arc(x, H - 30, 15, 0, 7); g.fill(); g.fillStyle = 'rgba(0,0,0,.4)'; g.fillRect(x - 12, H - 31, 24, 2); g.fillRect(x - 1, H - 42, 2, 24); g.fillStyle = shade(Z.acc, -0.55); } }
    } else if (zid === 2) {   // 성채: 무너진 탑 · 성벽
      if (far) { for (let i = 0; i < 5; i++) { const x = i * 150 + R() * 50, w = 36 + R() * 30, h = 90 + R() * 90; g.beginPath(); g.moveTo(x, H); g.lineTo(x, H - h); g.lineTo(x + w * 0.3, H - h - 10); g.lineTo(x + w * 0.5, H - h + 14); g.lineTo(x + w * 0.8, H - h - 4); g.lineTo(x + w, H - h + 20); g.lineTo(x + w, H); g.fill(); } g.fillRect(0, H - 30, TILE, 30); }
      else { g.fillRect(0, H - 70, TILE, 70); for (let i = 0; i < 18; i++) g.fillRect(i * 40, H - 84, 24, 16); g.fillStyle = shade(Z.acc, -0.5); for (let i = 0; i < 3; i++) { const x = i * 240 + 80; g.fillRect(x, H - 66, 22, 44); g.beginPath(); g.moveTo(x, H - 22); g.lineTo(x + 11, H - 12); g.lineTo(x + 22, H - 22); g.fill(); } g.fillStyle = 'rgba(0,0,0,.3)'; for (let i = 0; i < 3; i++) { const x = i * 240 + 190; g.beginPath(); g.moveTo(x, H); g.lineTo(x, H - 40); g.quadraticCurveTo(x + 14, H - 58, x + 28, H - 40); g.lineTo(x + 28, H); g.fill(); } }
    } else {   // 숲: 탄 나무
      const tr = (x, w, h) => { g.beginPath(); g.moveTo(x - w, H); g.lineTo(x - w * 0.6, H - h); g.lineTo(x - w * 2.4, H - h - 30); g.lineTo(x - w * 0.3, H - h - 14); g.lineTo(x, H - h - 50); g.lineTo(x + w * 0.4, H - h - 10); g.lineTo(x + w * 2.6, H - h - 36); g.lineTo(x + w * 0.7, H - h + 4); g.lineTo(x + w, H); g.fill(); };
      if (far) { for (let i = 0; i < 9; i++) tr(i * 82 + R() * 40, 5 + R() * 4, 70 + R() * 80); g.fillRect(0, H - 20, TILE, 20); }
      else { for (let i = 0; i < 4; i++) tr(i * 180 + 40 + R() * 80, 10 + R() * 6, 110 + R() * 60); g.fillStyle = shade(Z.floor[1], -0.25); for (let i = 0; i < 7; i++) { const x = i * 104 + R() * 50; g.beginPath(); g.ellipse(x, H, 34 + R() * 20, 10 + R() * 8, 0, Math.PI, 0); g.fill(); } g.fillStyle = 'rgba(255,150,70,.5)'; for (let i = 0; i < 16; i++) g.fillRect(R() * TILE, H - 20 - R() * 150, 2, 2); }
    }
    return cv;
  }
  function paintFloor(zid, K, hpx, Z) {
    const cv = document.createElement('canvas'); cv.width = Math.ceil(TILE * K); cv.height = Math.ceil(hpx);
    const g = cv.getContext('2d'); g.scale(K, K); const H = hpx / K; let n = zid * 311 + 7; const R = () => hash(n++);
    const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, Z.floor[0]); gr.addColorStop(1, Z.floor[1]); g.fillStyle = gr; g.fillRect(0, 0, TILE, H);
    g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 1.2;
    if (zid === 0) { for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(0, i * 26 + 6); g.lineTo(TILE, i * 26 + 6); g.stroke(); } for (let i = 0; i < 30; i++) { const x = R() * TILE, r = Math.floor(R() * 6); g.beginPath(); g.moveTo(x, r * 26 + 6); g.lineTo(x, r * 26 + 32); g.stroke(); } }
    else if (zid === 1) { for (let i = 0; i < 5; i++) { g.beginPath(); g.moveTo(0, i * 32 + 10); g.lineTo(TILE, i * 32 + 10); g.stroke(); for (let j = 0; j < 10; j++) { const x = j * 72 + (i % 2) * 36; g.beginPath(); g.moveTo(x, i * 32 + 10); g.lineTo(x, i * 32 + 42); g.stroke(); } } g.fillStyle = 'rgba(120,220,170,.10)'; for (let i = 0; i < 8; i++) { g.beginPath(); g.ellipse(64 + R() * (TILE - 128), 20 + R() * (H - 30), 30 + R() * 30, 5 + R() * 4, 0, 0, 7); g.fill(); } }
    else if (zid === 2) { for (let i = 0; i < 5; i++) for (let j = 0; j < 9; j++) { const x = j * 80 + (i % 2) * 40, y = i * 30 + 6; g.strokeRect(x + 2, y, 76, 28); } }
    else { g.fillStyle = 'rgba(0,0,0,.14)'; for (let i = 0; i < 40; i++) { g.beginPath(); g.ellipse(34 + R() * (TILE - 68), R() * H, 8 + R() * 22, 2 + R() * 3, 0, 0, 7); g.fill(); } g.strokeStyle = 'rgba(0,0,0,.25)'; for (let i = 0; i < 9; i++) { const x = R() * (TILE - 50), y = 10 + R() * (H - 20); g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + 20, y - 6, x + 44, y + 3); g.stroke(); } }
    g.fillStyle = 'rgba(255,255,255,.035)'; for (let i = 0; i < 60; i++) g.fillRect(R() * TILE, R() * H, 6 + R() * 16, 1.2);
    const sh = g.createLinearGradient(0, 0, 0, 16); sh.addColorStop(0, 'rgba(0,0,0,.45)'); sh.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = sh; g.fillRect(0, 0, TILE, 16);
    return cv;
  }

  /* ======================= 본체 ======================= */
  function mount(root, api, D) {
    const S = D.sim, DT = S.DT, { ZD, CLS, AUG, EN, ZONES, PJ, ZN, MV } = D;
    const h = L.h;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const FXM = () => (L.fx ? L.fx() : 1);
    const testBot = () => !!(L.debug && (L.debug.autoplay || (L.debug.noTut && api.online)));
    const ME = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const isHost = () => !api.online || api.isHost;
    function controlledHere(seat) { const p = api.players[seat]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !!p.local && !p.ai; }
    const humanHere = (seat) => { const p = api.players[seat]; return !!p && !p.ai && (!api.online || !!p.local) && !testBot(); };
    const meHum = () => { const me = ME(); return me >= 0 && humanHere(me); };
    const nmOf = (s) => String((api.players[s] && api.players[s].name) || (st && st.nm && st.nm[s]) || (s + 1) + '번').slice(0, 8);
    let st = null, W = null, wkey = '', dead = false, raf = 0, last = 0, acc = 0, paused = false, sentOver = false, wallT = 0;
    let vw = 1, vh = 1, K = 1, uiK = 1, fy0 = 0, camX = 450, camInit = false, dpr = 1, portrait = false;
    let touchUI = !!(L.touchOnly && L.touchOnly());

    /* ---------- DOM ---------- */
    const wrap = h('div', { class: 'bb-wrap' });
    const css = document.createElement('style');
    css.textContent = `
.bb-wrap{position:absolute;inset:0;overflow:hidden;background:#141018;touch-action:none;user-select:none;-webkit-user-select:none;color:#f2e9d8;font-family:var(--f-body),sans-serif;--k:1}
.bb-wrap canvas{position:absolute;inset:0;width:100%;height:100%;display:block}
.bb-btn{position:absolute;border-radius:50%;border:2px solid rgba(242,233,216,.5);background:rgba(28,22,34,.5);color:#f2e9d8;padding:0;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:none;-webkit-tap-highlight-color:transparent;font-family:inherit;cursor:pointer}
.bb-btn svg{width:56%;height:56%;pointer-events:none;opacity:.95}
.bb-btn.on{background:rgba(227,174,69,.42);border-color:#e3ae45}
.bb-btn .cdm{position:absolute;inset:0;background:rgba(10,8,14,.68);pointer-events:none;display:none}
.bb-btn.cd .cdm{display:block}
.bb-btn.tch{opacity:.55}.bb-btn.tch.on{opacity:1}
.bb-btn.pc.rdy{border-color:#e3ae45;box-shadow:0 0 0 2px rgba(227,174,69,.28)}
.bb-btn.pc.cd{border-color:rgba(242,233,216,.28)}
.bb-nm{position:absolute;text-align:center;font-size:calc(13px*var(--kn,1));line-height:1.2;white-space:nowrap;pointer-events:none;text-shadow:0 1px 2px #000;color:#e8dfd0}
.bb-btn .cdt{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font:600 calc(19px*var(--k)) var(--f-mono),monospace;pointer-events:none;text-shadow:0 1px 2px #000}
.bb-btn .kb{position:absolute;left:2px;top:2px;font:600 13px var(--f-mono),monospace;line-height:1.15;background:rgba(10,8,14,.82);padding:0 4px;border-radius:5px;pointer-events:none;z-index:2}
.bb-btn.pc{border-radius:12px}
.bb-btn.atk{border-color:rgba(255,220,170,.7)}
.bb-stick{position:absolute;width:112px;height:112px;margin:-56px 0 0 -56px;border-radius:50%;border:2px solid rgba(242,233,216,.32);background:rgba(28,22,34,.26);pointer-events:none;display:none}
.bb-stick i{position:absolute;left:50%;top:50%;width:48px;height:48px;margin:-24px 0 0 -24px;border-radius:50%;background:rgba(242,233,216,.45)}
.bb-note{position:absolute;left:50%;transform:translateX(-50%);top:24%;padding:4px 12px;border-radius:14px;background:rgba(16,12,20,.6);font-size:calc(13px*var(--k));pointer-events:none;opacity:0;transition:opacity .25s;white-space:nowrap;max-width:90%}
.bb-ov{position:absolute;inset:0;background:rgba(14,10,18,.78);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:calc(8px*var(--k));padding:calc(8px*var(--k)) calc(10px*var(--k));z-index:20;box-sizing:border-box}
.bb-ov h3{margin:0;font:400 calc(18px*var(--k)) var(--f-display),sans-serif;letter-spacing:1px}
.bb-ov .sub{font-size:calc(12px*var(--k));opacity:.78;text-align:center}
.bb-cards{display:flex;gap:calc(8px*var(--k));justify-content:center;align-items:stretch;width:100%;max-width:calc(700px*var(--k))}
.bb-card{flex:1 1 0;min-width:0;border-radius:10px;border:2px solid #6a6272;background:rgba(34,28,46,.94);color:#f2e9d8;padding:calc(7px*var(--k));text-align:left;font-family:inherit;display:flex;flex-direction:column;gap:calc(3px*var(--k));cursor:pointer;position:relative;min-height:44px}
.bb-card:hover,.bb-card.sel{background:rgba(52,42,66,.98)}
.bb-card.lock{opacity:.55;pointer-events:none}
.bb-card .hd{display:flex;align-items:center;gap:6px}
.bb-card .ic{width:calc(30px*var(--k));height:calc(30px*var(--k));flex:none}
.bb-card .nm{font:400 calc(15px*var(--k)) var(--f-display),sans-serif;line-height:1.15;word-break:keep-all}
.bb-card .tg{font-size:calc(12px*var(--k));opacity:.8;word-break:keep-all}
.bb-card .ds{font-size:calc(12.5px*var(--k));line-height:1.35;word-break:keep-all}
.bb-card .kb{position:absolute;right:6px;top:5px;font:600 calc(12px*var(--k)) var(--f-mono),monospace;background:rgba(10,8,14,.7);padding:0 5px;border-radius:4px}
.bb-row{display:flex;gap:calc(8px*var(--k));align-items:center;justify-content:center;flex-wrap:wrap}
.bb-b{min-height:44px;padding:0 calc(14px*var(--k));border-radius:10px;border:1px solid #8a8292;background:rgba(40,33,52,.95);color:#f2e9d8;font:inherit;font-size:calc(13px*var(--k));cursor:pointer}
.bb-b.pri{background:#e3ae45;color:#241a08;border-color:#e3ae45;font-weight:600}
.bb-mine{display:flex;gap:4px;flex-wrap:wrap;justify-content:center;max-width:100%;font-size:calc(12px*var(--k));opacity:.9}
.bb-mine span{display:inline-flex;align-items:center;gap:3px;background:rgba(40,33,52,.9);border-radius:8px;padding:1px 6px}
.bb-mine i{display:inline-block;width:calc(14px*var(--k));height:calc(14px*var(--k))}
.bb-pick{display:flex;gap:calc(10px*var(--k));width:100%;max-width:calc(760px*var(--k));flex:1 1 auto;min-height:0;align-items:stretch}
.bb-pl{display:grid;grid-template-columns:repeat(5,1fr);gap:calc(5px*var(--k));flex:1.15 1 0;min-width:0;align-content:start}
.bb-pc{border-radius:10px;border:2px solid #5a5262;background:#221c2e;color:#f2e9d8;padding:0;overflow:hidden;position:relative;aspect-ratio:3/5;cursor:pointer;font-family:inherit;min-height:44px}
.bb-pc canvas,.bb-pc img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 12%}
.bb-pc b{position:absolute;left:0;right:0;bottom:0;padding:2px 0;background:rgba(14,10,18,.78);font:400 calc(12.5px*var(--k)) var(--f-display),sans-serif;text-align:center}
.bb-pc.sel{border-color:#e3ae45;box-shadow:0 0 0 2px rgba(227,174,69,.35)}
.bb-pc .tk{position:absolute;left:3px;top:3px;font-size:calc(11px*var(--k));background:rgba(14,10,18,.8);border-radius:6px;padding:0 4px}
.bb-pd{flex:1 1 0;min-width:0;display:flex;flex-direction:column;gap:calc(4px*var(--k));overflow:auto;font-size:calc(12.5px*var(--k));line-height:1.36;word-break:keep-all}
.bb-pd .t{font:400 calc(17px*var(--k)) var(--f-display),sans-serif}
.bb-pd .sk{display:flex;gap:6px;align-items:flex-start}
.bb-pd .sk i{flex:none;width:calc(22px*var(--k));height:calc(22px*var(--k));margin-top:1px}
.bb-pd .sk b{font-weight:600}
.bb-info{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);max-width:92%;max-height:86%;overflow:auto;background:rgba(20,16,26,.94);border:1px solid #6a6272;border-radius:12px;padding:calc(10px*var(--k));z-index:15;font-size:calc(12.5px*var(--k));line-height:1.4;display:none;word-break:keep-all}
.bb-info div{margin:2px 0}.bb-info b{font-weight:600}
@media (orientation:portrait){.bb-pick{flex-direction:column}.bb-cards{flex-direction:column}.bb-pl{grid-template-columns:repeat(5,1fr);flex:none}}
`;
    wrap.append(css);
    const cv = document.createElement('canvas'); wrap.append(cv);
    const g = cv.getContext('2d');
    const stick = h('div', { class: 'bb-stick' }, h('i', {}));
    const noteEl = h('div', { class: 'bb-note' });
    const infoEl = h('div', { class: 'bb-info' });
    wrap.append(stick, noteEl, infoEl);
    root.append(wrap);
    let noteT = 0;
    const note = (t, ms) => { noteEl.textContent = t; noteEl.style.opacity = '1'; noteT = (ms || 1400) / 1000; };

    /* ---------- 그림(있으면) ---------- */
    const IMG = {};
    const loadImg = (k, src) => { const im = new Image(); im.onload = () => { IMG[k] = im; bgKey = ''; if (pickEl) pickDraw(); }; im.onerror = () => {}; im.src = src; };
    const ART = D.ART || {};
    for (const k in ART) loadImg(k, 'assets/beltbrawl/' + ART[k]);

    /* ---------- 소리 ---------- */
    const sndT = {};
    function snd(n, vol, pitch) { if (SPD() > 2) return; const now = performance.now(); if (now - (sndT[n] || 0) < 55) return; sndT[n] = now; try { api.sfx(n, { vol: vol == null ? 1 : vol, pitch: pitch || 1 }); } catch (e) {} }

    /* ---------- 조작 ---------- */
    const inp = { jx: 0, jy: 0, stickId: null, sx: 0, sy: 0, tAtk: 0, mAtk: 0, edge: 0 };
    const sq = [0, 0, 0, 0];
    const press = (b) => { inp.edge |= b; const i = b === 8 ? 3 : b === 1 ? 0 : b === 2 ? 1 : 2; sq[i] = (sq[i] + 1) % 100000; };
    const btns = [];
    function mkBtn(kind, idx, action) {
      const b = h('button', { class: 'bb-btn' + (kind === 'atk' ? ' atk' : ''), 'aria-label': action });
      const cdm = h('div', { class: 'cdm' }), cdt = h('div', { class: 'cdt' }), kb = h('div', { class: 'kb' });
      const ic = h('div', { style: { width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' } });
      b.append(ic, cdm, cdt, kb);
      let id = null;
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); if (e.pointerType !== 'mouse') setTouch(true); id = e.pointerId; try { b.setPointerCapture(id); } catch (x) {} b.classList.add('on'); if (kind === 'atk') inp.tAtk = 1; else press(kind === 'ev' ? 8 : 1 << idx); try { api.buzz(8, 'ui'); } catch (x) {} });
      const up = (e) => { if (e.pointerId !== id) return; id = null; b.classList.remove('on'); if (kind === 'atk') inp.tAtk = 0; };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
      const nm = h('div', { class: 'bb-nm' });
      wrap.append(b, nm);
      const o = { el: b, ic, cdm, cdt, kb, nm, kind, idx, action, key: '' }; btns.push(o); return o;
    }
    const bAtk = mkBtn('atk', 0, 'atk'), bS = [mkBtn('sk', 0, 's0'), mkBtn('sk', 1, 's1'), mkBtn('sk', 2, 's2')], bEv = mkBtn('ev', 0, 'ev');
    let btnCls = -1;
    function setBtnIcons() {
      const me = ME(), c = W && me >= 0 ? W.ps[me].cls : -1; if (c === btnCls) return; btnCls = c; if (c < 0) return;
      const C = CLS[c];
      bAtk.ic.innerHTML = D.svgW(D.IC.sword('#ffe8c8'));
      bAtk.nm.textContent = '공격'; bEv.nm.textContent = C.ev.nm;
      bS.forEach((b, i) => { b.ic.innerHTML = D.svgW(D.IC[C.sk[i].ic](C.col)); b.el.title = C.sk[i].nm; b.nm.textContent = C.sk[i].nm; });
      bEv.ic.innerHTML = D.svgW(D.IC[C.ev.ic]('#d8e8f8')); bEv.el.title = C.ev.nm;
    }
    function setTouch(on) { if (touchUI === on) return; touchUI = on; layout(); }
    function layout() {
      const r = wrap.getBoundingClientRect(); vw = Math.max(1, r.width); vh = Math.max(1, r.height); portrait = vh > vw * 1.05;
      dpr = Math.min(window.devicePixelRatio || 1, 2); cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr);
      K = portrait ? vw / 430 : vh / 360;
      fy0 = portrait ? vh * 0.5 - ZD * K * 0.2 : vh - (ZD + (touchUI ? 24 : 50)) * K;
      const raw = Math.min(vw / 640, vh / 360); uiK = portrait ? clamp(vw / 400, 1, 1.5) : clamp(1 + (raw - 1) * 0.62, 1, 2.2);
      wrap.style.setProperty('--k', uiK.toFixed(3));
      const ck = (L.ui && L.ui.ctlScale ? L.ui.ctlScale() : 1);
      const show = !!W && st && st.ph === 'play' && meHum();
      for (const b of btns) { b.el.style.display = show ? '' : 'none'; b.nm.style.display = show && !touchUI ? '' : 'none'; b.el.classList.toggle('tch', touchUI); }
      if (touchUI) {
        const k = ck * clamp(Math.min(vw, vh) / 360, 1, 1.35), B = Math.round(84 * k), Sm = Math.round(56 * k), E = Math.round(62 * k), m = Math.round(14 * k);
        const put = (o, w, right, bottom) => { o.el.classList.remove('pc'); Object.assign(o.el.style, { width: w + 'px', height: w + 'px', right: right + 'px', bottom: bottom + 'px', left: '' }); o.kb.style.display = 'none'; };
        put(bAtk, B, m, m); put(bS[0], Sm, m + B + Math.round(8 * k), m - 2); put(bS[1], Sm, m + Math.round(B * 0.72), m + Math.round(B * 0.86)); put(bS[2], Sm, m - 4, m + B + Math.round(8 * k)); put(bEv, E, m + B + Sm + Math.round(18 * k), m + Math.round(40 * k));
      } else {
        const w = Math.max(46, Math.round(40 * uiK)), gap = Math.round(14 * uiK), tot = w * 5 + gap * 4, x0 = Math.round(vw / 2 - tot / 2), nh = Math.round(Math.max(13, 13 * Math.min(1.25, uiK)) * 1.3), bot = nh + 3;
        wrap.style.setProperty('--kn', Math.min(1.25, Math.max(1, uiK)).toFixed(2));
        [bAtk, bS[0], bS[1], bS[2], bEv].forEach((o, i) => { Object.assign(o.nm.style, { left: x0 + i * (w + gap) - gap / 2 + 'px', width: w + gap + 'px', bottom: '2px' }); });
        [bAtk, bS[0], bS[1], bS[2], bEv].forEach((o, i) => { o.el.classList.add('pc'); Object.assign(o.el.style, { width: w + 'px', height: w + 'px', left: x0 + i * (w + gap) + 'px', right: '', bottom: bot + 'px' }); o.kb.style.display = ''; });
        keyLabels();
      }
      bgKey = '';
    }
    function keyLabels() { for (const o of btns) { let k = ''; try { k = (L.ui && L.ui.keyLabel && L.ui.keyLabel('beltbrawl', o.action)) || ''; } catch (e) {} o.kb.textContent = k; o.kb.style.display = k && !touchUI ? '' : 'none'; } }
    function onDown(e) {
      if (e.pointerType !== 'mouse') setTouch(true);
      if (!W || !st || st.ph !== 'play' || !meHum() || augEl || pickEl) return;
      const r = wrap.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      if (e.pointerType === 'mouse') { if (e.button === 0) inp.mAtk = 1; return; }
      if (x < vw * 0.46 && inp.stickId == null) { inp.stickId = e.pointerId; inp.sx = x; inp.sy = y; inp.jx = inp.jy = 0; stick.style.display = 'block'; stick.style.left = x + 'px'; stick.style.top = y + 'px'; stick.firstChild.style.transform = ''; try { wrap.setPointerCapture(e.pointerId); } catch (x2) {} }
    }
    function onMove(e) {
      if (e.pointerId !== inp.stickId) return;
      const r = wrap.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; let dx = x - inp.sx, dy = y - inp.sy; const d = Math.hypot(dx, dy), mx = 46;
      if (d > mx * 1.5) { inp.sx += dx * (1 - mx * 1.5 / d); inp.sy += dy * (1 - mx * 1.5 / d); dx = x - inp.sx; dy = y - inp.sy; }
      const dd = Math.min(mx, Math.hypot(dx, dy)), a = Math.atan2(dy, dx), mg = clamp((dd - 6) / (mx * 0.7 - 6), 0, 1);
      inp.jx = Math.cos(a) * mg; inp.jy = Math.sin(a) * mg;
      stick.style.left = inp.sx + 'px'; stick.style.top = inp.sy + 'px'; stick.firstChild.style.transform = 'translate(' + (Math.cos(a) * dd) + 'px,' + (Math.sin(a) * dd) + 'px)';
    }
    function onUp(e) {
      if (e.pointerId === inp.stickId) { inp.stickId = null; inp.jx = inp.jy = 0; stick.style.display = 'none'; }
      if (e.pointerType === 'mouse' && e.button === 0) inp.mAtk = 0;
    }
    wrap.addEventListener('pointerdown', onDown); wrap.addEventListener('pointermove', onMove); wrap.addEventListener('pointerup', onUp); wrap.addEventListener('pointercancel', onUp);
    const onKeyCap = (e) => { if (e.code === 'Tab' && W && st && st.ph === 'play') e.preventDefault(); };
    document.addEventListener('keydown', onKeyCap, true);
    const offs = [];
    offs.push(api.input.on((type, id) => {
      if (type !== 'down') return;
      if (touchUI && !(L.touchOnly && L.touchOnly())) setTouch(false);
      if (augEl) { if (id === 's0') augChoose(0); else if (id === 's1') augChoose(1); else if (id === 's2') augChoose(2); return; }
      if (!W || !st || st.ph !== 'play') return;
      if (id === 's0') press(1); else if (id === 's1') press(2); else if (id === 's2') press(4); else if (id === 'ev') press(8);
    }));
    const myIn = { mx: 0, mz: 0, a: 0, k: 0 };
    function readInput(first) {
      let ix = api.input.axis('left', 'right') + inp.jx, iz = api.input.axis('up', 'down') + inp.jy;
      const m = Math.hypot(ix, iz); if (m > 1) { ix /= m; iz /= m; }
      const blocked = !!augEl || !!pickEl;
      myIn.mx = blocked ? 0 : ix; myIn.mz = blocked ? 0 : iz; myIn.a = !blocked && (inp.tAtk || inp.mAtk || api.input.held('atk')) ? 1 : 0;
      myIn.k = first && !blocked ? inp.edge : 0; if (first) inp.edge = 0;
      return myIn;
    }

    /* ---------- 직업 고르기 ---------- */
    let pickEl = null, pickSel = 0, pickBar = null, pickSent = -1, autoPickT = 0;
    const picked = (s) => !!(st && st.cls && st.cls[s] >= 0);
    function pickOpen() {
      if (pickEl) return;
      pickEl = h('div', { class: 'bb-ov', style: { justifyContent: 'flex-start', paddingBottom: '64px' } });
      wrap.append(pickEl);
      try { pickBar = api.pickBar({ picked, onForce() { startRun(true); }, note: '모두 고르면 시작' }); } catch (e) { pickBar = null; }
      pickDraw();
    }
    function pickClose() { if (pickBar) { try { pickBar.destroy(); } catch (e) {} pickBar = null; } if (pickEl) { pickEl.remove(); pickEl = null; } }
    function drawPortrait(c, cvs) {
      const x = cvs.getContext('2d'), w = cvs.width, hh = cvs.height, C = CLS[c];
      const gr = x.createLinearGradient(0, 0, 0, hh); gr.addColorStop(0, shade(C.col, -0.55)); gr.addColorStop(1, shade(C.col, -0.8)); x.fillStyle = gr; x.fillRect(0, 0, w, hh);
      x.save(); x.translate(w * 0.46, hh * 0.86); const s = hh / 100; x.scale(s * 1.03, s * 1.12);
      x.fillStyle = 'rgba(0,0,0,.35)'; x.beginPath(); x.ellipse(0, 0, 18, 5, 0, 0, 7); x.fill();
      rig(x, full(BASE[C.wpn], {}), PSTY[c], false, INK, false); x.restore();
    }
    function pickDraw() {
      if (!pickEl || !st) return;
      const me = ME(), mine = me >= 0 && humanHere(me), done = me >= 0 && picked(me);
      pickEl.innerHTML = '';
      const head = h('div', { class: 'bb-row', style: { width: '100%', maxWidth: 'calc(760px*var(--k))', justifyContent: 'space-between', flexWrap: 'nowrap', paddingRight: '50px', boxSizing: 'border-box' } }, h('h3', { text: '직업 고르기' }));
      if (mine && !done) head.append(h('button', { class: 'bb-b pri', style: { flex: 'none' }, text: CLS[pickSel].nm + ' 정하기', onclick() { choosePick(pickSel); } }));
      else head.append(h('div', { class: 'sub', text: done ? '골랐음 — 다른 동료를 기다리는 중' : '관전 중' }));
      pickEl.append(head);
      const body = h('div', { class: 'bb-pick' }), left = h('div', { class: 'bb-pl' }), right = h('div', { class: 'bb-pd' });
      CLS.forEach((C, c) => {
        const b = h('button', { class: 'bb-pc' + (c === pickSel ? ' sel' : ''), onclick() { if (done) return; pickSel = c; snd('click'); pickDraw(); } });
        if (IMG['cls' + c]) { const im = document.createElement('img'); im.src = IMG['cls' + c].src; im.alt = C.nm; b.append(im); }
        else { const pc = document.createElement('canvas'); pc.width = 150; pc.height = 250; drawPortrait(c, pc); b.append(pc); }
        const who = st.cls.map((q, s) => (q === c ? nmOf(s) : null)).filter(Boolean);
        if (who.length) b.append(h('span', { class: 'tk', text: who.join(' · ') }));
        b.append(h('b', { text: C.nm }));
        left.append(b);
      });
      const C = CLS[pickSel];
      right.append(h('div', { class: 't', style: { color: shade(C.col, 0.35) }, text: C.nm + ' — ' + C.sub }));
      right.append(h('div', { text: '체력 ' + C.hp + ' · 이동 ' + C.spd + ' · ' + C.d }));
      C.sk.forEach((m) => { const row = h('div', { class: 'sk' }); const i = document.createElement('i'); i.innerHTML = D.svgW(D.IC[m.ic](C.col)); row.append(i, h('div', {}, h('b', { text: m.nm + ' ' }), document.createTextNode(m.d + ' (' + m.cd + '초)'))); right.append(row); });
      { const row = h('div', { class: 'sk' }); const i = document.createElement('i'); i.innerHTML = D.svgW(D.IC[C.ev.ic]('#d8e8f8')); row.append(i, h('div', {}, h('b', { text: C.ev.nm + ' ' }), document.createTextNode(C.ev.d))); right.append(row); }
      body.append(left, right); pickEl.append(body);
      if (pickBar) try { pickBar.update(); } catch (e) {}
    }
    function choosePick(c) {
      const me = ME(); if (me < 0 || !st || st.ph !== 'pick' || picked(me)) return;
      snd('pop'); try { api.buzz(12, 'ui'); } catch (e) {}
      if (isHost()) { const cls = st.cls.slice(); cls[me] = c; api.setState(Object.assign({}, st, { cls, seq: st.seq + 1 })); }
      else { pickSent = c; pubNow(); }
    }
    function startRun(force) {
      if (!isHost() || !st || st.ph !== 'pick') return;
      const wait = L.pick && L.pick.waiting ? L.pick.waiting(api.players, picked) : api.players.map((p, i) => (!p.ai && !picked(i) ? i : -1)).filter((i) => i >= 0);
      if (wait.length && !force) return;
      let s = st.seed ^ 0x2545f491; const rr = () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) % 100000) / 100000; };
      const cls = D.fillClasses(st, rr);
      api.setState(Object.assign({}, st, { cls, ph: 'play', seq: st.seq + 1 }));
    }
    function pickTick(dt) {
      if (!st || st.ph !== 'pick') return;
      const me = ME();
      if (me >= 0 && !picked(me) && !api.players[me].ai && testBot()) { autoPickT += dt; if (autoPickT > 0.5) { autoPickT = -9; choosePick((st.seed + me * 2) % CLS.length); } }
      if (isHost()) {
        if (api.online) { let rem = null; try { rem = api.net.remote(); } catch (e) {} if (rem) { let cls = null; for (const kk in rem) { const o = rem[kk], s = +kk; if (!o || o.k !== st.rid || typeof o.pk !== 'number' || picked(s) || controlledHere(s)) continue; if (o.pk >= 0 && o.pk < CLS.length) { cls = cls || st.cls.slice(); cls[s] = o.pk; } } if (cls) { api.setState(Object.assign({}, st, { cls, seq: st.seq + 1 })); return; } } }
        startRun(false);
      }
    }

    /* ---------- 능력 고르기 ---------- */
    let augEl = null, augRound = -1, augLock = 0, augSent = null;
    function augClose() { if (augEl) { augEl.remove(); augEl = null; } }
    function mineRow(p) { const row = h('div', { class: 'bb-mine' }); for (const i of p.al) { const x = AUG[i], sp = h('span', { title: D.augDesc(x, p.aug[i]) }); const ic = document.createElement('i'); ic.innerHTML = D.svgW(D.augIcon(x)); sp.append(ic, document.createTextNode(x.nm + (p.aug[i] > 1 ? ' ' + p.aug[i] : ''))); row.append(sp); } return row; }
    function augOpen() {
      const me = ME(); if (me < 0 || !W.offers || !W.pk) return;
      augClose(); augRound = W.ar; augLock = 0.55; augSent = null;
      const p = W.ps[me], of = W.offers[me] || [];
      augEl = h('div', { class: 'bb-ov' });
      augEl.append(h('h3', { text: '능력 고르기' }), h('div', { class: 'sub', text: CLS[p.cls].nm + ' · 하나를 고름' + (W.n > 1 ? ' — 각자 따로' : '') }));
      const cards = h('div', { class: 'bb-cards' });
      of.forEach((ai, i) => {
        const x = AUG[ai], have = p.aug[ai] || 0;
        const c = h('button', { class: 'bb-card', style: { borderColor: D.TIERC[x.tier] }, onclick() { augChoose(i); } });
        const ic = h('div', { class: 'ic' }); ic.innerHTML = D.svgW(D.augIcon(x));
        c.append(h('div', { class: 'hd' }, ic, h('div', { class: 'nm', text: x.nm })));
        c.append(h('div', { class: 'tg', style: { color: D.TIERC[x.tier] }, text: D.TIERNM[x.tier] + ' · ' + (x.cls >= 0 ? CLS[x.cls].nm : '공통') + ' · ' + x.tags.join(' ') + (x.max > 1 ? ' · ' + (have + 1) + '/' + x.max : '') }));
        c.append(h('div', { class: 'ds', text: D.augDesc(x) }));
        let kl = ''; try { kl = (!touchUI && L.ui && L.ui.keyLabel && L.ui.keyLabel('beltbrawl', 's' + i)) || ''; } catch (e) {}
        if (kl) c.append(h('div', { class: 'kb', text: kl }));
        cards.append(c);
      });
      augEl.append(cards);
      augEl.append(h('div', { class: 'bb-row' }, h('button', { class: 'bb-b', text: p.st === 'ko' ? '넘기기 — 일어나서 체력 30%' : '넘기기 — 체력 30% 회복', onclick() { augChoose(3); } })));
      if (p.al.length) augEl.append(mineRow(p));
      wrap.append(augEl);
    }
    function augChoose(c) {
      const me = ME(); if (!augEl || augLock > 0 || me < 0 || !W || W.ph !== 'aug' || !W.pk || W.pk[me] !== -2) return;
      const of = W.offers[me] || []; if (c < 3 && c >= of.length) return;
      snd('pop'); try { api.buzz(14, 'ui'); } catch (e) {}
      if (isHost()) S.applyPick(W, me, c); else { augSent = [W.ar, c]; pubNow(); }
      augEl.innerHTML = ''; augEl.append(h('h3', { text: c < 3 ? AUG[of[c]].nm : '체력 회복' }), h('div', { class: 'sub', text: W.n > 1 ? '다른 동료를 기다리는 중' : '' }));
    }
    function augTick(dt) {
      if (augLock > 0) augLock -= dt;
      const me = ME(), mine = me >= 0 && humanHere(me);
      if (W && W.ph === 'aug' && W.pk && mine) { if (!augEl && W.pk[me] === -2 && augRound !== W.ar) augOpen(); }
      else if (augEl) augClose();
      if (W && W.ph !== 'aug') augRound = -1;
    }
    /* 내 능력 보기(누르고 있기 · 내 체력 칸을 누름) */
    let infoHold = false;
    function infoDraw() {
      const me = ME(); const on = !!W && st && st.ph === 'play' && !augEl && (api.input.held('info') || infoHold);
      if (!on) { if (infoEl.style.display !== 'none') infoEl.style.display = 'none'; return; }
      if (infoEl.style.display === 'block') return;
      infoEl.style.display = 'block'; infoEl.innerHTML = '';
      const list = me >= 0 ? [W.ps[me]].concat(W.ps.filter((p) => p.s !== me)) : W.ps;
      for (const p of list) { infoEl.append(h('div', {}, h('b', { style: { color: shade(CLS[p.cls].col, 0.35) }, text: nmOf(p.s) + ' · ' + CLS[p.cls].nm }))); if (!p.al.length) infoEl.append(h('div', { text: '능력 없음' })); for (const i of p.al) infoEl.append(h('div', { text: AUG[i].nm + (p.aug[i] > 1 ? ' ' + p.aug[i] : '') + ' — ' + D.augDesc(AUG[i], p.aug[i]) })); }
    }

    /* ---------- 효과 ---------- */
    const fx = [], nums = [], flashAt = {};
    let shakeT = 0, shakeA = 0, hurtT = 0, banT = 0, banTxt = '', banSub = '', banCol = '#f2e9d8', goT = 0, slowT = 0;
    const addFx = (k, x, z, y, a, b, life) => { if (fx.length > 70) fx.shift(); fx.push({ k, x, z, y, a, b, t: 0, life: life || 0.3 }); };
    function addNum(x, z, y, v, col, big, id) {
      if (id) for (const n of nums) if (n.id === id && n.t < 0.3 && (n.m = (n.m || 0) + 1) < 5) { n.v += v; n.t = 0.05; n.big = n.big || big; if (big) n.col = col; return; }
      if (nums.length > 18) nums.shift(); nums.push({ x, z, y, v, col, big, t: 0, id, ox: (hash(v * 7.3 + x) - 0.5) * 16 });
    }
    function banner(t, sub, col, ms) { banTxt = t; banSub = sub || ''; banCol = col || '#f2e9d8'; banT = (ms || 1500) / 1000; }
    function onEv(e) {
      const k = e[1], x = e[2], z = e[3], y = e[4], a = e[5], b = e[6], me = ME();
      switch (k) {
        case 'h': { const crit = b & 1, blk = b & 2, proc = b & 4, hv = b & 8; addFx(blk ? 'blk' : 'hit', x, z, y, crit || hv ? 1.5 : 1, proc, 0.2); if (!blk) addNum(x, z, y + 14, a, crit ? '#ffe070' : proc ? '#d8c8b0' : '#ffffff', crit, 'e' + (e.nid || x + '_' + z)); snd(blk ? 'tick' : hv ? 'thud' : 'hit', proc ? 0.35 : crit ? 0.9 : 0.6, crit ? 1.25 : 1); break; }
        case 'dt': addNum(x, z, y + 8, a, b === 1 ? '#e06060' : b === 3 ? '#ff9a50' : b === 2 ? '#f0e060' : '#d8c8b0', false, 'd' + x + '_' + z + b); break;
        case 'pd': addFx('hit', x, z, y, 1.2, 1, 0.22); addNum(x, z, y + 18, a, '#ff7060', false, 'p' + b); if (b === me) { hurtT = 0.35; try { api.buzz(26, 'hit'); } catch (er) {} } snd('thud', b === me ? 0.9 : 0.4, 0.8); break;
        case 'hl': addNum(x, z, y + 10, a, '#7fe0a0', false, 'h' + b); break;
        case 'k': addFx('puff', x, z, y + 20, b ? 1.6 : 1, a, 0.45); break;
        case 'bk': addFx('ring', x, z, 0, 160, 6, 0.7); shakeT = 0.5; shakeA = 5; slowT = 0.5; snd('win', 0.6); banner('우두머리 격파', EN[a].nm, '#e3ae45', 1500); break;
        case 'ex': addFx('ring', x, z, y, a, b, 0.36); snd('thud', 0.7, 0.7); break;
        case 'shk': if (b === me || b < 0 || Math.abs(x - camX) < 320) { shakeT = 0.22; shakeA = Math.max(shakeA, a * 1.6); } break;
        case 'bl': addFx('blk', x, z, y, 1, 0, 0.2); break;
        case 'gb': addFx('txt', x, z, 60, '방패 깨짐', 0, 0.8); snd('pop'); break;
        case 'pf': if (!CLS[W.ps[a].cls].ev.guard) addFx('txt', x, z, 66, '회피', 1, 0.6); break;
        case 'pg': addFx('blk', x, z, y, 1.8, 0, 0.3); addFx('txt', x, z, 78, '완벽 막기', 1, 0.8); snd('pop', 0.9, 1.3); break;
        case 'stg': addFx('txt', x, z, y + 14, '기절', 2, 0.9); snd('pop', 0.8, 0.8); break;
        case 'rp': addFx('ring', x, z, y, 44, 1, 0.3); break;
        case 'ch': addFx('bolt', x, z, y, a, b, 0.22); snd('tick', 0.5, 1.6); break;
        case 'ko': addFx('txt', x, z, 50, nmOf(a) + ' 쓰러짐', 3, 1.2); snd('lose', 0.5); break;
        case 'rv': addFx('ring', x, z, 0, 50, 8, 0.5); addFx('txt', x, z, 70, '일어남', 4, 0.9); snd('win', 0.4, 1.3); break;
        case 'orb': addFx('ring', x, z, 0, 26, 8, 0.3); snd('chip', 0.6); break;
        case 'sw': { const mv = MV[a]; if (mv && mv.kind === 'b') snd('whoosh', 0.3, 1.1); else if (mv && mv.kind === 's') snd('whoosh', 0.55, 0.8); break; }
        case 'dg': snd('whoosh', 0.45, 1.4); break;
        case 'sh': snd(a === 0 ? 'tick' : a === 2 ? 'whoosh' : 'pop', a === 0 ? 0.5 : 0.4, a === 0 ? 0.7 : 1); break;
        case 'tl': if (b) snd('warn', 0.35); break;
        case 'sum': addFx('ring', x, z, 0, 30, 9, 0.4); break;
        case 'ld': addFx('dust', x, z, 0, 1, 0, 0.3); break;
        case 'bk2': addFx('ring', x, z, 0, 30, 9, 0.3); break;
        case 'p2': banner('격노', '빨라지고 새 패턴을 씀', RED, 1300); snd('warn', 0.7); break;
        case 'boss': banner(EN[a].nm, ZONES[S.zoneOf(W)].nm + '의 우두머리', '#ffb090', 1900); snd('warn', 0.8, 0.7); break;
        case 'zone': banner(ZONES[a].nm, (b + 1) + '구역 · ' + ZONES[a].sub, '#f2e9d8', 1600); bgKey = ''; break;
        case 'clear': banner(a ? '구역 돌파' : '구간 돌파', '', '#e3ae45', 1100); snd('win', 0.5); break;
        case 'go': goT = 6; break;
        case 'aug': if (b !== me) addFx('txt', x, z, 80, AUG[a].nm, 5, 0.8); break;
      }
    }
    let evSeen = 0;
    function drainEv() { for (const e of W.ev) { if (e[0] <= evSeen) continue; evSeen = e[0]; onEv(e); } }

    /* ---------- 온라인 ---------- */
    let pubT = 0, hsQ = -1;
    const key = () => st.rid;
    function pubNow() { pubT = 0; }
    function pollNet() {
      if (!api.online || !W || !st || st.ph !== 'play') return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) {}
        if (rem) for (const kk in rem) { const o = rem[kk], s = +kk; if (!o || o.k !== key() || controlledHere(s)) continue; S.ingest(W, s, o); }
        for (const p of W.ps) if (controlledHere(p.s)) p.rem = false;
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) {}
        if (hs && hs.k === key() && hs.q !== hsQ) { hsQ = hs.q; const evs = S.applyHost(W, hs, meHum() || testBot() ? ME() : -1); for (const e of evs) onEv(e); }
      }
    }
    function publish(dt) {
      if (!api.online || !st) return;
      pubT -= dt; if (pubT > 0) return; pubT = 0.075;
      try {
        if (api.isHost) { if (W && st.ph === 'play') { const o = S.packHost(W); o.k = key(); api.net.hostSend(o); } }
        else {
          const me = ME(); if (me < 0) return;
          const o = { k: key() };
          if (st.ph === 'pick') { if (pickSent >= 0) o.pk = pickSent; }
          else if (W) { const p = W.ps[me]; o.i = [Math.round(myIn.mx * 100), Math.round(myIn.mz * 100), myIn.a, sq[0], sq[1], sq[2], sq[3]]; o.x = Math.round(p.x); o.z = Math.round(p.z); if (augSent) o.ap = augSent; }
          api.net.publish(o);
        }
      } catch (e) {}
    }
    function guestBot(p) { const t = W.t + p.s; myIn.mx = Math.sin(t * 0.9) * 0.8; myIn.mz = Math.cos(t * 1.3) * 0.6; myIn.a = Math.sin(t * 2) > -0.3 ? 1 : 0; if (W.tick % 90 === 0) { sq[(W.tick / 90) % 4 | 0]++; } if (W.ph === 'aug' && W.pk && W.pk[p.s] === -2 && W.pt > 1) augSent = [W.ar, 0]; return myIn; }

    /* ---------- 판 진행 ---------- */
    function ensureWorld() {
      if (!st || st.ph === 'pick') return;
      const k = st.rid + '_' + st.seed;
      if (k === wkey && W) return;
      W = S.makeWorld(st, { host: isHost() }); wkey = k; sentOver = false; evSeen = 0; acc = 0; camInit = false; btnCls = -1; bgKey = '';
      banner(ZONES[S.zoneOf(W)].nm, '1구역 · ' + ZONES[S.zoneOf(W)].sub, '#f2e9d8', 1600);
      setBtnIcons(); layout();
      if (meHum() && !(L.debug && L.debug.noTut)) note(touchUI ? '왼쪽 끌기: 이동 · 오른쪽: 공격(누르고 있기)과 기술' : '이동 WASD · 공격 J(누르고 있기) · 기술 K L I · 회피 Space', 3200);
    }
    const humanPick = (s) => { const p = api.players[s]; return !!p && !p.ai && !(testBot() && controlledHere(s)); };
    function simTick(dt) {
      if (!W || st.ph !== 'play') return;
      acc += dt;
      const maxSteps = Math.ceil(0.25 * SPD() / DT) + 2;
      let steps = Math.floor(acc / DT); if (steps > maxSteps) { steps = maxSteps; acc = 0; } else acc -= steps * DT;
      const me = ME(), hum = meHum(), host = isHost();
      for (let i = 0; i < steps; i++) {
        if (host) {
          const mi = hum ? readInput(i === 0) : null;
          S.worldStep(W, DT, (s) => (s === me && hum ? mi : undefined), humanPick);
          if (W.over && !sentOver) { sentOver = true; const res = W.over; if (res.win && hum) { try { api.best('t_' + st.len, res.time, { label: '가장 빠른 돌파 · ' + D.LENS[st.len].nm, lower: true, fmt: 'time' }); } catch (e) {} } api.setState(Object.assign({}, st, { ph: 'done', seq: st.seq + 1, res })); break; }
        } else {
          const mine = me >= 0 && W.ps[me];
          S.guestStep(W, DT, me, mine ? (hum ? readInput(i === 0) : testBot() ? guestBot(W.ps[me]) : null) : null);
        }
      }
      if (host) drainEv();
    }

    /* ======================= 그리기 ======================= */
    const X = (x) => (x - camX) * K + vw / 2;
    const Yg = (z) => fy0 + z * K;
    let bgKey = '', bgFar = null, bgNear = null, bgFloor = null;
    function ensureBg() {
      const zid = W ? S.zoneOf(W) : 0, k = zid + '_' + vw + '_' + vh + '_' + (IMG['bg' + zid] ? 1 : 0);
      if (k === bgKey) return; bgKey = k; const Z = ZONES[zid];
      bgFloor = paintFloor(zid, K, (vh - fy0) + 2, Z);
      if (IMG['bg' + zid]) { bgFar = bgNear = null; } else { bgFar = paintLayer(zid, 0, K, Math.max(40, fy0 * 0.8), Z); bgNear = paintLayer(zid, 1, K, Math.max(40, fy0 * 0.62), Z); }
    }
    function tileDraw(img, off, y, w, hh) { let x = -(((off % w) + w) % w); for (; x < vw; x += w) g.drawImage(img, x, y, w, hh); }
    function drawBg() {
      const zid = S.zoneOf(W), Z = ZONES[zid];
      const sky = g.createLinearGradient(0, 0, 0, fy0); sky.addColorStop(0, Z.sky[0]); sky.addColorStop(1, Z.sky[1]); g.fillStyle = sky; g.fillRect(0, 0, vw, fy0 + 1);
      const im = IMG['bg' + zid];
      if (im) { const hh = fy0 + 4 * K, w = im.width * (hh / im.height); tileDraw(im, camX * K * 0.45, 0, w, hh); }
      else if (bgFar) { tileDraw(bgFar, camX * K * 0.18, fy0 - bgFar.height / (bgFar.width / (TILE * K)), TILE * K, bgFar.height / (bgFar.width / (TILE * K))); tileDraw(bgNear, camX * K * 0.5, fy0 - bgNear.height / (bgNear.width / (TILE * K)), TILE * K, bgNear.height / (bgNear.width / (TILE * K))); }
      tileDraw(bgFloor, camX * K, fy0, TILE * K, bgFloor.height / (bgFloor.width / (TILE * K)));
      if (portrait) { g.fillStyle = Z.floor[1]; g.fillRect(0, fy0 + (ZD + 26) * K, vw, vh); } else { g.fillStyle = 'rgba(10,8,14,.42)'; g.fillRect(0, fy0 + (ZD + 8) * K, vw, vh); }
    }
    const ell = (x, z, rx, rz) => { g.beginPath(); g.ellipse(X(x), Yg(z), rx * K, rz * K, 0, 0, 7); };
    function drawZones(a) {
      for (const q of W.zn) {
        const Z = ZN[q.k], foe = q.own !== 0; const col = foe ? RED : Z.col;
        if (q.age < q.warn) {
          const f = clamp(q.age / q.warn, 0, 1);
          g.fillStyle = foe ? 'rgba(255,80,64,.13)' : 'rgba(180,140,255,.12)'; ell(q.x, q.z, q.rx, q.rz); g.fill();
          g.fillStyle = foe ? 'rgba(255,80,64,.34)' : 'rgba(180,140,255,.3)'; ell(q.x, q.z, q.rx * f, q.rz * f); g.fill();
          g.strokeStyle = col; g.lineWidth = 2 * K; g.globalAlpha = 0.85; ell(q.x, q.z, q.rx, q.rz); g.stroke(); g.globalAlpha = 1;
        } else if (q.dur) {
          const left = q.warn + q.dur - q.age, al = clamp(left / 0.4, 0, 1) * (0.2 + 0.05 * Math.sin(wallT * 3));
          g.globalAlpha = al; g.fillStyle = Z.col; ell(q.x, q.z, q.rx, q.rz); g.fill(); g.globalAlpha = clamp(left / 0.4, 0, 1) * 0.7; g.strokeStyle = Z.col; g.lineWidth = 1.6 * K; g.setLineDash([8 * K, 6 * K]); g.lineDashOffset = wallT * 12 * K; ell(q.x, q.z, q.rx * 0.92, q.rz * 0.92); g.stroke(); g.setLineDash([]); g.globalAlpha = 1;
        }
      }
      /* 적의 공격 예고(띠 · 줄) */
      for (const e of W.es) {
        if (e.st !== 'act' || !e.mv) continue; const mv = e.mv; if (!mv.tele && !mv.line) continue;
        const ex = lerp(e.ox, e.x, a), ez = lerp(e.oz, e.z, a);
        for (const x of mv.acts) {
          if (x.k === 'hit' && mv.tele) {
            const end = x.to || x.at; if (e.mt > end + 0.05) continue; const lead = x.at - e.mt; if (lead > 1.3) continue;
            let x0 = x.x0, x1 = x.x1; if (x.to) { const ds = mv.acts.find((q) => q.k === 'dash'); if (ds && e.mt < x.at) x1 += ds.v * ds.t; }
            const f = clamp(e.mt / x.at, 0, 1), sx0 = X(ex + e.face * x0), sx1 = X(ex + e.face * x1), l = Math.min(sx0, sx1), w = Math.abs(sx1 - sx0), top = Yg(ez - x.zr), hh = x.zr * 2 * K;
            g.fillStyle = 'rgba(255,80,64,.13)'; g.fillRect(l, top, w, hh);
            g.fillStyle = 'rgba(255,80,64,.3)'; if (e.face > 0) g.fillRect(l, top, w * f, hh); else g.fillRect(l + w * (1 - f), top, w * f, hh);
            g.strokeStyle = 'rgba(255,80,64,.8)'; g.lineWidth = 1.6 * K; g.strokeRect(l, top, w, hh);
          } else if (x.k === 'proj' && mv.line && !PJ[x.p].lob) {
            if (e.mt > x.at) continue; const lead = x.at - e.mt; if (lead > 1.1) continue; const P = PJ[x.p], n = x.n || 1;
            g.strokeStyle = 'rgba(255,80,64,' + (0.25 + 0.4 * clamp(e.mt / x.at, 0, 1)) + ')'; g.lineWidth = Math.max(2, P.zr * 0.5 * K);
            for (let i = 0; i < n; i++) { const off = n > 1 ? i / (n - 1) - 0.5 : 0, dz = x.fan ? off * x.fan * 2.4 * (mv.line / P.spd) : 0; g.beginPath(); g.moveTo(X(ex + e.face * 16), Yg(ez)); g.lineTo(X(ex + e.face * mv.line), Yg(clamp(ez + dz, -6, ZD + 6))); g.stroke(); }
          }
        }
      }
    }
    function statusPips(e, sx, sy) {
      let n = 0; const pip = (c) => { g.fillStyle = c; g.beginPath(); g.arc(sx - 12 * K + n * 7 * K, sy, 2.6 * K, 0, 7); g.fill(); n++; };
      if (e.bl > 0) for (let i = 0; i < Math.min(5, e.bl); i++) pip('#e04848'); if (e.bu > 0) pip('#ff9a40'); if (e.sk > 0) pip('#f0e060'); if (e.ch > 0) pip('#8fd8f0'); if (e.mk > 0) pip('#c070ff');
    }
    function actMeta(mv, mt) {   // 예고 진행 u · 친 직후 s
      let u = 0, s = 0, prev = 0;
      for (const x of mv.acts) { if (x.k === 'die' || x.k === 'turn') continue; if (x.at > mt) { u = clamp((mt - prev) / Math.max(0.05, x.at - prev), 0, 1); break; } prev = x.at; s = clamp(1 - (mt - x.at) / 0.22, 0, 1); if (x.to && mt <= x.to) s = 1; }
      return [u, s];
    }
    function drawFoe(e, a) {
      const Kd = EN[e.k], ex = lerp(e.ox, e.x, a), ez = lerp(e.oz, e.z, a), ey = lerp(e.oy, e.y, a);
      const sx = X(ex), sy = Yg(ez); if (sx < -120 * K || sx > vw + 120 * K) return;
      const sc = (Kd.sc || 1) * (e.el ? 1.2 : 1), fl = flashAt[e.id] && wallT - flashAt[e.id] < 0.05;
      /* 그림자 · 정예 고리 */
      g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(sx, sy, e.w * 1.1 * K * (1 - Math.min(0.5, ey / 200)), e.w * 0.36 * K, 0, 0, 7); g.fill();
      if (e.el || Kd.boss) { g.strokeStyle = Kd.boss ? 'rgba(255,150,110,.7)' : 'rgba(255,210,110,.75)'; g.lineWidth = 2 * K; g.beginPath(); g.ellipse(sx, sy, e.w * 1.5 * K, e.w * 0.5 * K, 0, 0, 7); g.stroke(); }
      let u = 0, s = 0; if (e.st === 'act' && e.mv) { const m = actMeta(e.mv, e.mt); u = m[0]; s = m[1]; }
      const ol = u > 0.25 && e.st === 'act' ? (Math.sin(wallT * 14) > 0 ? '#ffd9a0' : '#ff8060') : INK;
      const lying = e.st === 'down', air = e.st === 'air' || e.st === 'held', stag = e.st === 'stag';
      g.save(); g.translate(sx, sy - ey * K); g.scale(K * sc * e.face, K * sc);
      const ph = (ex + ez) * 0.11, tm = wallT + e.id * 0.7;
      if (Kd.sh === 'hum' || Kd.sh === 'golem') {
        const S2 = foeStyle(Kd), base = BASE[Kd.wpn === 'bow' ? 'bow' : Kd.wpn === 'pike' ? 'pike' : Kd.off === 'shield' ? 'foeS' : Kd.wpn ? 'foe' : 'none'];
        let P;
        if (lying) { g.translate(0, -5); g.rotate(-1.5); P = full(base, P_AIR); }
        else if (air) { g.translate(0, -12); g.rotate(-1.0); P = full(base, P_AIR); }
        else if (e.st === 'hit') P = full(base, P_HIT);
        else if (stag) P = full(base, P_KNEEL);
        else if (e.st === 'up') P = mix(full(base, P_KNEEL), full(base, {}), 0.5);
        else if (e.st === 'act' && e.mv) { const q = EAN[e.mv.an] || EAN.e_sw; P = s > 0 ? mix(full(base, q[0]), full(base, q[1]), ease(clamp(1.35 - s * 0.35, 0, 1))) : mix(full(base, {}), full(base, q[0]), ease(clamp(u * 2.2, 0, 1))); if (e.mv.an === 'e_fuse') P.l += Math.sin(wallT * 30) * 0.03; }
        else if (e.mvn) { const w = Math.sin(ph), c2 = Math.cos(ph); P = full(base, { f: [9 * w, Math.max(0, c2) * 5], k: [-9 * w, Math.max(0, -c2) * 5], y: base.y + Math.abs(w) * 1.2 }); }
        else P = full(base, { y: base.y + Math.sin(tm * 2.2) * 0.6 });
        rig(g, P, S2, fl, ol, false);
      } else {
        const fn = CRE[Kd.sh], k2 = Kd.h / (CBASE[Kd.sh] || 40);
        if (lying && Kd.sh !== 'slime' && Kd.sh !== 'cart' && Kd.sh !== 'tree') { g.translate(0, -6); g.rotate(-1.4); } else if (air) g.rotate(-0.5);
        if (stag) g.translate(0, 3);
        g.scale(k2, k2 * (stag ? 0.85 : lying && Kd.sh === 'slime' ? 0.6 : 1));
        if (fn) fn(g, Kd, fl ? '#ffffff' : Kd.col, ol, u, s, e.mvn ? ph : 0, tm);
      }
      g.restore();
      const top = sy - (ey + (Kd.sh === 'hum' ? 66 : Kd.h) * sc + 8) * K;
      if (stag) { g.fillStyle = '#ffe070'; for (let i = 0; i < 3; i++) { const an = wallT * 4 + i * 2.1; g.beginPath(); g.arc(sx + Math.cos(an) * 10 * K, top + 4 * K + Math.sin(an) * 3 * K, 2.2 * K, 0, 7); g.fill(); } }
      if (!Kd.boss && (e.hp < e.mhp || e.el)) { const w = (e.el ? 38 : 28) * K, f = clamp(e.hpf != null ? e.hpf : e.hp / e.mhp, 0, 1); g.fillStyle = 'rgba(10,8,14,.7)'; g.fillRect(sx - w / 2 - 1, top - 1, w + 2, 4 * K + 2); g.fillStyle = e.el ? '#ffc860' : '#e8605a'; g.fillRect(sx - w / 2, top, w * f, 4 * K); if (e.pmax > 0) { g.fillStyle = '#d8d0b0'; g.fillRect(sx - w / 2, top + 4.6 * K, w * clamp(e.poise / e.pmax, 0, 1), 1.6 * K); } }
      statusPips(e, sx, top - 6 * K);
    }
    function slashFx(p, x, mt, px, py) {
      const dt2 = mt - x.at; if (dt2 < -0.02 || dt2 > 0.16 || !x.fx) return;
      const al = clamp(1 - dt2 / 0.16, 0, 1), col = CLS[p.cls].col, R2 = Math.max(Math.abs(x.x1), 30) * (1 + (p.m.reach || 0) * (p.mv && p.mv.kind === 'b' ? 1 : 0));
      g.save(); g.translate(px, py); g.scale(K * p.face, K); g.globalAlpha = al * 0.9; g.lineCap = 'round';
      const grad = (w) => { g.globalAlpha = al * 0.45; g.strokeStyle = shade(col, 0.35); g.lineWidth = w * 2.4; g.stroke(); g.globalAlpha = al * 0.95; g.strokeStyle = '#fffaf0'; g.lineWidth = w; g.stroke(); };
      switch (x.fx) {
        case 'arc': g.beginPath(); g.ellipse(R2 * 0.25, -30, R2 * 0.78, 30, 0, -1.2, 1.15); grad(4); break;
        case 'arc2': g.beginPath(); g.ellipse(R2 * 0.25, -34, R2 * 0.78, 34, 0, 1.2, -1.15, true); grad(4); break;
        case 'ovh': g.beginPath(); g.ellipse(R2 * 0.3, -34, R2 * 0.72, 52, 0, -1.9, 0.9); grad(5); break;
        case 'up': g.beginPath(); g.ellipse(R2 * 0.3, -40, R2 * 0.66, 58, 0, 1.3, -1.7, true); grad(5); break;
        case 'spin': g.beginPath(); g.ellipse(0, -26, R2, 20, 0, 0, 7); grad(4); break;
        case 'slam': g.beginPath(); g.ellipse(20, 0, 30 + dt2 * 520, (30 + dt2 * 520) * 0.4, 0, 0, 7); grad(4); break;
        case 'pun': g.beginPath(); g.moveTo(R2 * 0.3, -36); g.lineTo(R2 * 0.95, -36); grad(5); g.beginPath(); g.arc(R2 * 0.95, -36, 7 + dt2 * 60, 0, 7); g.globalAlpha = al * 0.6; g.strokeStyle = '#fff'; g.lineWidth = 2; g.stroke(); break;
        case 'thr': g.beginPath(); g.moveTo(24, -34); g.lineTo(R2 * 1.02, -34); grad(3.4); break;
      }
      g.restore();
    }
    function drawPlayer(p, a, mine) {
      const C = CLS[p.cls], px = lerp(p.ox, p.x, a), pz = lerp(p.oz, p.z, a), py = lerp(p.oy, p.y, a);
      const sx = X(px), sy = Yg(pz);
      g.fillStyle = 'rgba(0,0,0,.34)'; g.beginPath(); g.ellipse(sx, sy, 15 * K * (1 - Math.min(0.5, py / 200)), 5 * K, 0, 0, 7); g.fill();
      /* 발밑 고리: 나는 밝고 굵게, 동료는 가늘게 */
      g.strokeStyle = mine ? '#ffe9a8' : shade(C.col, 0.2); g.globalAlpha = mine ? 0.95 : 0.6; g.lineWidth = (mine ? 2.6 : 1.4) * K; g.beginPath(); g.ellipse(sx, sy, 19 * K, 6.4 * K, 0, 0, 7); g.stroke(); g.globalAlpha = 1;
      const base = BASE[C.wpn], ko = p.st === 'ko', mv = p.st === 'act' ? p.mv : null;
      let P, rot = 0, lift = 0, flip = 1, alpha = 1, hideW = false;
      const ph = (px * 0.085 + pz * 0.12), tm = wallT + p.s * 1.3;
      if (ko || p.st === 'down') { rot = -1.5; lift = -5; P = full(base, P_AIR); }
      else if (p.st === 'air') { rot = -0.9; lift = -12; P = full(base, P_AIR); }
      else if (p.st === 'hit') P = full(base, P_HIT);
      else if (p.st === 'up') P = full(base, P_KNEEL);
      else if (mv) {
        P = animPose(base, AN[mv.an] || [[0, {}]], p.mt);
        if (mv.an === 'spin') { const tu = p.mt < 0.42 ? ease(clamp((p.mt - 0.06) / 0.26, 0, 1)) : p.mt < 0.68 ? 1 + ease(clamp((p.mt - 0.3) / 0.26, 0, 1)) : 2 + ease(clamp((p.mt - 0.56) / 0.26, 0, 1)); flip = Math.cos(tu * Math.PI * 2); if (Math.abs(flip) < 0.25) flip = 0.25 * sgn(flip); }
        else if (mv.an === 'roll') { rot = (p.mt / mv.dur) * Math.PI * 2 * 1; lift = -14; }
        else if (mv.an === 'blink') alpha = 0.25 + 0.75 * clamp(Math.abs(p.mt - 0.1) / 0.18, 0, 1);
        else if (mv.an === 'hop') lift = -Math.sin(clamp(p.mt / mv.dur, 0, 1) * Math.PI) * 12;
        else if (mv.an === 'burst') { P.a = [P.a[0], P.a[1] + Math.sin(p.mt * 90) * 0.05]; P.b = [P.b[0], P.b[1] + Math.cos(p.mt * 90) * 0.05]; }
        else if (mv.an === 'hurl' && p.mt > 0.26) hideW = true;
        else if (mv.an === 'lob' && p.mt > 0.22) hideW = false;
      }
      else if (p.mvn) { const w = Math.sin(ph), c2 = Math.cos(ph); P = full(base, { f: [10 * w, Math.max(0, c2) * 5], k: [-10 * w, Math.max(0, -c2) * 5], y: base.y + Math.abs(w) * 1.4, l: base.l + 0.08 }); }
      else P = full(base, { y: base.y + Math.sin(tm * 2.4) * 0.7 });
      const fl = flashAt['p' + p.s] && wallT - flashAt['p' + p.s] < 0.08;
      if (p.inv > 0 && !mv && !ko && Math.sin(wallT * 30) > 0.2) alpha *= 0.6;
      g.save(); g.translate(sx, sy - py * K); g.scale(K * p.face * flip * 1.03, K * 1.12); if (lift) g.translate(0, lift); if (rot) { g.translate(0, mv && mv.an === 'roll' ? -4 : 0); g.rotate(rot); }
      g.globalAlpha = alpha * (ko ? 0.75 : 1);
      rig(g, P, PSTY[p.cls], fl, INK, hideW);
      g.restore(); g.globalAlpha = 1;
      if (mv) { for (const x of mv.acts) if (x.k === 'hit' && (!x.req || p.m[x.req])) slashFx(p, x, p.mt, sx, sy - py * K); if (mv.guard) { g.strokeStyle = p.mt < mv.guard ? '#fff6c8' : 'rgba(160,200,240,.8)'; g.lineWidth = 3 * K; g.beginPath(); g.ellipse(sx + p.face * 16 * K, sy - 30 * K, 7 * K, 26 * K, 0, 0, 7); g.stroke(); } }
      if (p.sh > 0) { g.strokeStyle = 'rgba(150,210,255,.7)'; g.lineWidth = 1.6 * K; g.beginPath(); g.ellipse(sx, sy - (30 + py) * K, 20 * K, 36 * K, 0, 0, 7); g.stroke(); }
      /* 머리 위: 이름표(동료) · 화살표(나) · 일으키기 고리 */
      const top = sy - (py + 76) * K;
      if (mine) { g.fillStyle = '#ffe9a8'; g.beginPath(); g.moveTo(sx - 5 * K, top - 4 * K); g.lineTo(sx + 5 * K, top - 4 * K); g.lineTo(sx, top + 3 * K); g.closePath(); g.fill(); }
      else { g.font = '600 ' + Math.round(12 * uiK) + 'px "IBM Plex Sans KR",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'bottom'; g.lineWidth = 3; g.strokeStyle = 'rgba(14,10,18,.8)'; g.strokeText(nmOf(p.s), sx, top + 2 * K); g.fillStyle = shade(C.col, 0.45); g.fillText(nmOf(p.s), sx, top + 2 * K); }
      if (ko) { const r = 13 * K, cy = sy - 34 * K; g.strokeStyle = 'rgba(14,10,18,.7)'; g.lineWidth = 5 * K; g.beginPath(); g.arc(sx, cy, r, 0, 7); g.stroke(); g.strokeStyle = '#7fe0a0'; g.lineWidth = 3.4 * K; g.beginPath(); g.arc(sx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * clamp(p.auto > 0 ? 1 - (W.host ? p.auto / 3 : 0.5) : p.rev, 0, 1)); g.stroke(); g.fillStyle = '#f2e9d8'; g.font = '600 ' + Math.round(12 * uiK) + 'px "IBM Plex Sans KR",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(p.auto > 0 ? '재기' : '도움', sx, cy); }
    }
    function drawProj(q, a) {
      const P = PJ[q.k], x = X(lerp(q.ox != null ? q.ox : q.x, q.x, a)), zz = lerp(q.oz != null ? q.oz : q.z, q.z, a), y = lerp(q.oy != null ? q.oy : q.y, q.y, a), gy = Yg(zz), sy = gy - y * K, d = sgn(q.vx || (q.tx - q.sx) || 1);
      g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(x, gy, 6 * K, 2 * K, 0, 0, 7); g.fill();
      g.fillStyle = P.col; g.strokeStyle = P.col; g.lineCap = 'round';
      switch (P.sh) {
        case 'tr': g.lineWidth = 2.4 * K; g.globalAlpha = 0.9; g.beginPath(); g.moveTo(x, sy); g.lineTo(x - d * 26 * K, sy); g.stroke(); g.globalAlpha = 1; g.fillStyle = '#fff'; g.beginPath(); g.arc(x, sy, 2.2 * K, 0, 7); g.fill(); break;
        case 'orb': { const r = (P.big ? 9 : 6) * K; const gr = g.createRadialGradient(x, sy, 1, x, sy, r * 1.8); gr.addColorStop(0, '#fff'); gr.addColorStop(0.4, P.col); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, sy, r * 1.8, 0, 7); g.fill(); break; }
        case 'nade': g.beginPath(); g.arc(x, sy, 5.5 * K, 0, 7); g.fill(); g.strokeStyle = INK; g.lineWidth = 1.4 * K; g.stroke(); break;
        case 'jav': g.lineWidth = 3 * K; g.beginPath(); g.moveTo(x - d * 44 * K, sy); g.lineTo(x + d * 14 * K, sy); g.stroke(); g.fillStyle = '#fff'; g.beginPath(); g.moveTo(x + d * 24 * K, sy); g.lineTo(x + d * 10 * K, sy - 4 * K); g.lineTo(x + d * 10 * K, sy + 4 * K); g.fill(); break;
        case 'bolt': g.lineWidth = 2.6 * K; g.beginPath(); g.moveTo(x - d * 16 * K, sy); g.lineTo(x + d * 4 * K, sy); g.stroke(); g.strokeStyle = RED; g.lineWidth = 1 * K; g.globalAlpha = 0.6; g.beginPath(); g.moveTo(x - d * 30 * K, sy); g.lineTo(x - d * 16 * K, sy); g.stroke(); g.globalAlpha = 1; break;
        case 'hook': { g.lineWidth = 1.6 * K; const src = W.es.find((e) => e.id === q.src); if (src) { g.beginPath(); g.moveTo(X(src.x), Yg(src.z) - 34 * K); g.lineTo(x, sy); g.stroke(); } g.lineWidth = 3 * K; g.beginPath(); g.arc(x, sy, (P.big ? 9 : 6) * K, -1.6, 1.8); g.stroke(); break; }
        case 'wave': g.globalAlpha = 0.85; g.beginPath(); g.moveTo(x - d * 10 * K, gy); g.quadraticCurveTo(x + d * 4 * K, gy - 34 * K, x + d * 16 * K, gy); g.closePath(); g.fill(); g.globalAlpha = 1; break;
      }
    }
    function drawFx(dt) {
      for (let i = fx.length - 1; i >= 0; i--) {
        const f = fx[i]; f.t += dt; const u = f.t / f.life; if (u >= 1) { fx.splice(i, 1); continue; }
        const x = X(f.x), y = Yg(f.z) - f.y * K;
        switch (f.k) {
          case 'hit': { g.strokeStyle = f.b ? '#ffb0a0' : '#fff6d8'; g.lineWidth = 2.2 * K * (1 - u); g.lineCap = 'round'; const n = 5, r0 = 4 * K * f.a, r1 = (10 + 22 * u) * K * f.a; g.beginPath(); for (let j = 0; j < n; j++) { const an = j * 1.2566 + f.x * 0.37 + f.z; g.moveTo(x + Math.cos(an) * r0, y + Math.sin(an) * r0); g.lineTo(x + Math.cos(an) * r1, y + Math.sin(an) * r1); } g.stroke(); g.fillStyle = 'rgba(255,255,255,' + (0.8 * (1 - u)) + ')'; g.beginPath(); g.arc(x, y, 5 * K * f.a * (1 - u), 0, 7); g.fill(); break; }
          case 'blk': g.strokeStyle = 'rgba(170,215,255,' + (1 - u) + ')'; g.lineWidth = 2.4 * K; g.beginPath(); g.arc(x, y, (6 + 16 * u) * K * f.a, -1.2, 1.2); g.stroke(); break;
          case 'puff': g.fillStyle = 'rgba(230,220,210,' + (0.5 * (1 - u)) + ')'; for (let j = 0; j < 5; j++) { const an = j * 1.2566 + f.x; g.beginPath(); g.arc(x + Math.cos(an) * 18 * u * K * f.a, y + Math.sin(an) * 12 * u * K * f.a - 10 * u * K, (7 - 4 * u) * K * f.a, 0, 7); g.fill(); } break;
          case 'ring': { const col = f.b === 8 ? '127,224,160' : f.b === 9 ? '190,150,255' : f.b === 7 ? '255,90,70' : f.b === 1 ? '224,72,72' : '255,200,120'; g.strokeStyle = 'rgba(' + col + ',' + (0.9 * (1 - u)) + ')'; g.lineWidth = 3.4 * K * (1 - u * 0.6); g.beginPath(); g.ellipse(x, Yg(f.z), f.a * K * (0.35 + 0.65 * ease(u)), f.a * 0.6 * K * (0.35 + 0.65 * ease(u)), 0, 0, 7); g.stroke(); if (f.b === 6 || f.b === 7) { g.fillStyle = 'rgba(' + col + ',' + (0.28 * (1 - u)) + ')'; g.fill(); } break; }
          case 'dust': g.fillStyle = 'rgba(200,190,175,' + (0.4 * (1 - u)) + ')'; g.beginPath(); g.ellipse(x - 12 * u * K, y - 3 * K, (6 + 6 * u) * K, 3 * K, 0, 0, 7); g.ellipse(x + 12 * u * K, y - 3 * K, (6 + 6 * u) * K, 3 * K, 0, 0, 7); g.fill(); break;
          case 'bolt': { g.strokeStyle = 'rgba(255,240,130,' + (1 - u) + ')'; g.lineWidth = 2 * K; const x2 = X(f.a), y2 = Yg(f.b) - 30 * K; g.beginPath(); g.moveTo(x, y); for (let j = 1; j < 4; j++) g.lineTo(lerp(x, x2, j / 4) + (hash(j + f.a) - 0.5) * 14 * K, lerp(y, y2, j / 4) + (hash(j * 3 + f.b) - 0.5) * 14 * K); g.lineTo(x2, y2); g.stroke(); break; }
          case 'txt': { const col = ['#d8d0c0', '#a8e0ff', '#ffe070', '#ff9080', '#7fe0a0', '#e3ae45'][f.b] || '#fff'; g.font = '600 ' + Math.round(13 * uiK) + 'px "IBM Plex Sans KR",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.globalAlpha = clamp((1 - u) * 2.5, 0, 1); g.lineWidth = 3; g.strokeStyle = 'rgba(14,10,18,.8)'; g.strokeText(f.a, x, y - 14 * u * K); g.fillStyle = col; g.fillText(f.a, x, y - 14 * u * K); g.globalAlpha = 1; break; }
        }
      }
      g.textAlign = 'center'; g.textBaseline = 'middle';
      for (let i = nums.length - 1; i >= 0; i--) {
        const n = nums[i]; n.t += dt; const u = n.t / 0.65; if (u >= 1) { nums.splice(i, 1); continue; }
        const x = X(n.x) + n.ox * K, y = Yg(n.z) - (n.y + 26 * (1 - (1 - u) * (1 - u))) * K;
        g.font = '600 ' + Math.round((n.big ? 17 : 13) * uiK) + 'px "IBM Plex Mono",monospace'; g.globalAlpha = clamp((1 - u) * 2.2, 0, 1) * 0.95; g.lineWidth = 3; g.strokeStyle = 'rgba(14,10,18,.85)'; g.strokeText(n.v, x, y); g.fillStyle = n.col; g.fillText(n.v, x, y);
      }
      g.globalAlpha = 1;
    }
    function bar(x, y, w, hh, f, col, back) { g.fillStyle = back || 'rgba(10,8,14,.72)'; g.fillRect(x - 1, y - 1, w + 2, hh + 2); g.fillStyle = col; g.fillRect(x, y, w * clamp(f, 0, 1), hh); }
    const hudRect = { x: 0, y: 0, w: 0, h: 0 };
    function drawHud() {
      const me = ME(), u = uiK, F = (px, wt) => { g.font = (wt || '600') + ' ' + Math.round(px * u) + 'px "IBM Plex Sans KR",sans-serif'; };
      /* 왼쪽 위: 일행 체력 */
      let y = 8 * u; const x0 = 8 * u + (portrait ? 0 : 0);
      const order = me >= 0 ? [W.ps[me]].concat(W.ps.filter((p) => p.s !== me)) : W.ps;
      g.textBaseline = 'middle'; g.textAlign = 'left';
      order.forEach((p, i) => {
        const big = i === 0 && me >= 0, w = (big ? 150 : 104) * u, hh = (big ? 11 : 7) * u, C = CLS[p.cls];
        g.fillStyle = 'rgba(14,10,18,.5)'; g.fillRect(x0 - 4 * u, y - 3 * u, w + 8 * u, (big ? 34 : 25) * u);
        F(big ? 13 : 12); g.fillStyle = shade(C.col, 0.5); g.fillText((big ? '' : nmOf(p.s) + ' · ') + C.nm + (p.st === 'ko' ? ' — 쓰러짐' : ''), x0, y + 6 * u);
        const by = y + (big ? 16 : 14) * u;
        bar(x0, by, w, hh, p.hp / p.mhp, p.st === 'ko' ? '#6a6068' : p.hp < p.mhp * 0.3 ? '#ff6a50' : '#6fd08a');
        if (p.sh > 0) { g.fillStyle = 'rgba(150,210,255,.85)'; g.fillRect(x0, by, w * clamp(p.sh / p.mhp, 0, 1), hh * 0.45); }
        if (big) { g.font = '600 ' + Math.round(12 * u) + 'px "IBM Plex Mono",monospace'; g.fillStyle = '#f2e9d8'; g.textAlign = 'right'; g.fillText(Math.max(0, Math.ceil(p.hp)) + '/' + p.mhp, x0 + w - 2 * u, y + 6 * u); g.textAlign = 'left'; hudRect.x = x0 - 4 * u; hudRect.y = y - 3 * u; hudRect.w = w + 8 * u; hudRect.h = 34 * u; }
        y += (big ? 39 : 29) * u;
      });
      /* 위 가운데: 구역 · 구간 */
      const zid = S.zoneOf(W), segs = W.len.segs, cx = vw / 2; let ty = 12 * u;
      F(13); g.textAlign = 'center'; g.fillStyle = 'rgba(14,10,18,.5)'; const lab = ZONES[zid].nm + '  ' + (W.zi + 1) + '/' + W.plan.length; const lw = g.measureText(lab).width + (segs + 1) * 13 * u + 24 * u; g.fillRect(cx - lw / 2, ty - 10 * u, lw, 21 * u);
      g.fillStyle = '#f2e9d8'; g.textAlign = 'left'; g.fillText(lab, cx - lw / 2 + 8 * u, ty + 0.5 * u);
      for (let i = 0; i <= segs; i++) { const px = cx + lw / 2 - (segs + 1 - i) * 13 * u, done = i < W.si || (i === W.si && (W.ph === 'clear' || W.ph === 'aug' || W.ph === 'go' || W.ph === 'travel')), cur = i === W.si && !done; g.fillStyle = done ? '#e3ae45' : cur ? '#f2e9d8' : 'rgba(242,233,216,.3)'; g.beginPath(); if (i === segs) { g.moveTo(px, ty - 5 * u); g.lineTo(px + 5 * u, ty); g.lineTo(px, ty + 5 * u); g.lineTo(px - 5 * u, ty); } else g.arc(px, ty, 3.6 * u, 0, 7); g.fill(); }
      ty += 20 * u;
      /* 우두머리 체력 */
      const boss = W.bossId ? W.es.find((e) => e.id === W.bossId) : null;
      if (boss) { const bw = Math.min(vw * 0.44, 380 * u), Kd = EN[boss.k]; F(13); g.textAlign = 'center'; g.lineWidth = 3; g.strokeStyle = 'rgba(14,10,18,.8)'; g.strokeText(Kd.nm, cx, ty + 2 * u); g.fillStyle = '#ffd0b0'; g.fillText(Kd.nm, cx, ty + 2 * u); bar(cx - bw / 2, ty + 11 * u, bw, 8 * u, boss.hpf != null ? boss.hpf : boss.hp / boss.mhp, boss.st === 'stag' ? '#ffe070' : '#e8605a'); g.fillStyle = 'rgba(14,10,18,.8)'; g.fillRect(cx - 1, ty + 10 * u, 2, 10 * u); bar(cx - bw / 2, ty + 21.5 * u, bw, 3 * u, boss.st === 'stag' ? 0 : boss.poise / boss.pmax, '#d8d0b0'); }
      /* 오른쪽 위(☰ 아래): 콤보 */
      if (me >= 0 && W.ps[me].combo >= 3) { const c = W.ps[me].combo; g.textAlign = 'right'; g.font = '600 ' + Math.round(20 * u) + 'px "IBM Plex Mono",monospace'; g.lineWidth = 3; g.strokeStyle = 'rgba(14,10,18,.8)'; g.strokeText(c, vw - 12 * u, 62 * u); g.fillStyle = c >= 20 ? '#ffe070' : '#f2e9d8'; g.fillText(c, vw - 12 * u, 62 * u); F(12); g.strokeText('콤보', vw - 12 * u, 79 * u); g.fillText('콤보', vw - 12 * u, 79 * u); }
      /* 앞으로 표시 */
      if (W.ph === 'go') { const al = 0.55 + 0.35 * Math.sin(wallT * 5); g.globalAlpha = al; g.fillStyle = '#e3ae45'; const ax = vw - 46 * u + Math.sin(wallT * 5) * 5 * u, ay = fy0 - 26 * u; g.beginPath(); g.moveTo(ax - 22 * u, ay - 7 * u); g.lineTo(ax, ay - 7 * u); g.lineTo(ax, ay - 15 * u); g.lineTo(ax + 20 * u, ay); g.lineTo(ax, ay + 15 * u); g.lineTo(ax, ay + 7 * u); g.lineTo(ax - 22 * u, ay + 7 * u); g.closePath(); g.fill(); g.globalAlpha = 1; F(13); g.textAlign = 'center'; g.fillStyle = '#f2e9d8'; g.lineWidth = 3; g.strokeStyle = 'rgba(14,10,18,.8)'; g.strokeText('앞으로', vw - 46 * u, ay + 26 * u); g.fillText('앞으로', vw - 46 * u, ay + 26 * u); }
      /* 화면 밖 동료 · 쓰러진 동료 표시 */
      for (const p of W.ps) { if (p.s === me) continue; const sx = X(p.x); if (sx > 14 && sx < vw - 14) continue; const left = sx <= 14, ax = left ? 14 * u : vw - 14 * u, ay = Yg(p.z) - 30 * K; g.fillStyle = p.st === 'ko' ? '#7fe0a0' : shade(CLS[p.cls].col, 0.35); g.beginPath(); g.moveTo(ax + (left ? -8 : 8) * u, ay); g.lineTo(ax + (left ? 4 : -4) * u, ay - 8 * u); g.lineTo(ax + (left ? 4 : -4) * u, ay + 8 * u); g.fill(); }
      /* 띠 알림(작고 반투명 · 짧게) */
      if (banT > 0) { const al = clamp(banT / 0.25, 0, 1) * 0.92, by = vh * 0.3, bf = Math.min(22, 18 * u), sf = Math.max(12, Math.min(14, 12 * u)); g.globalAlpha = al * 0.55; g.fillStyle = '#140f1a'; const bh = banSub ? bf + sf + 16 : bf + 12; g.fillRect(vw * 0.28, by - bh / 2, vw * 0.44, bh); g.globalAlpha = al; g.textAlign = 'center'; g.font = '400 ' + Math.round(bf) + 'px "Black Han Sans","IBM Plex Sans KR",sans-serif'; g.fillStyle = banCol; g.fillText(banTxt, cx, by - (banSub ? sf * 0.55 : 0)); if (banSub) { g.font = '400 ' + Math.round(sf) + 'px "IBM Plex Sans KR",sans-serif'; g.fillStyle = '#d8d0c0'; g.fillText(banSub, cx, by + bf * 0.62); } g.globalAlpha = 1; }
      if (W.ph === 'intro' && boss && IMG['boss_' + EN[boss.k].id]) { const im = IMG['boss_' + EN[boss.k].id], ih = vh * 0.7, iw = im.width * (ih / im.height); g.globalAlpha = 0.8 * clamp(Math.min(W.pt, 2 - W.pt) / 0.3, 0, 1); g.drawImage(im, vw - iw - 12 * u, vh * 0.16, iw, ih); g.globalAlpha = 1; }
      if (hurtT > 0 && FXM() > 0) { const al = clamp(hurtT / 0.35, 0, 1) * 0.22 * FXM(); const gr = g.createRadialGradient(cx, vh / 2, vh * 0.35, cx, vh / 2, vh * 0.8); gr.addColorStop(0, 'rgba(255,60,40,0)'); gr.addColorStop(1, 'rgba(255,60,40,' + al + ')'); g.fillStyle = gr; g.fillRect(0, 0, vw, vh); }
      if (W.fade > 0) { g.fillStyle = 'rgba(10,8,14,' + clamp(W.ph === 'travel' ? 1 - W.pt / 1.1 : W.fade / 0.6, 0, 1) + ')'; g.fillRect(0, 0, vw, vh); }
    }
    function updButtons() {
      const me = ME(); if (me < 0 || !W) return; const p = W.ps[me], C = CLS[p.cls];
      const setCd = (b, cd, showNum) => { const on = cd > 0.02; if (b._on !== on) { b._on = on; b.el.classList.toggle('cd', on); b.el.classList.toggle('rdy', !on); } const t = on && showNum ? (cd < 3 ? cd.toFixed(1) : String(Math.ceil(cd))) : ''; if (b._t !== t) { b._t = t; b.cdt.textContent = t; } };
      bS.forEach((b, i) => setCd(b, p.cd[i], true)); setCd(bEv, p.ecd, p.ecd > 0.5); void C;
    }
    const drawList = [];
    function render(a, rdt) {
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!W) { g.fillStyle = '#141018'; g.fillRect(0, 0, vw, vh); return; }
      ensureBg();
      const me = ME(); const fp = me >= 0 ? W.ps[me] : (W.ps.find((p) => p.st !== 'ko') || W.ps[0]);
      const fxp = lerp(fp.ox, fp.x, a), half = vw / K / 2;
      /* 싸움터 가장자리 밖을 조금 보여 줌(들어오는 적이 보이게) */
      const shift = touchUI && !portrait ? half * 0.3 : 0;   // 터치: 오른쪽 단추에 가리지 않게 싸움을 화면 왼쪽 2/3로
      let lo = W.bx0 + half - 80, hi = W.bx1 - half + 80 + shift * 1.6; if (lo > hi) lo = hi = (W.bx0 + W.bx1) / 2;
      const tgt = clamp(fxp + fp.face * 26 + shift, lo, hi);
      if (!camInit) { camX = tgt; camInit = true; } else camX += (tgt - camX) * (1 - Math.exp(-rdt * 7));
      let shx = 0, shy = 0; if (shakeT > 0 && FXM() > 0) { const k = shakeA * (shakeT / 0.22) * FXM() * 0.5 * K; shx = Math.sin(wallT * 61) * k; shy = Math.cos(wallT * 47) * k * 0.6; }
      g.save(); g.translate(shx, shy);
      drawBg();
      drawZones(a);
      for (const q of W.orb) { const x = X(q.x), y = Yg(q.z), bob = Math.sin(wallT * 3 + q.x) * 2 * K; g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(x, y, 7 * K, 2.4 * K, 0, 0, 7); g.fill(); const gr = g.createRadialGradient(x, y - 12 * K + bob, 1, x, y - 12 * K + bob, 12 * K); gr.addColorStop(0, '#f0fff4'); gr.addColorStop(0.45, '#6fe09a'); gr.addColorStop(1, 'rgba(110,220,150,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y - 12 * K + bob, 12 * K, 0, 7); g.fill(); }
      drawList.length = 0;
      for (const e of W.es) if (!e.dead) drawList.push([lerp(e.oz, e.z, a), 0, e]);
      for (const p of W.ps) drawList.push([lerp(p.oz, p.z, a) + 0.01, 1, p]);
      for (const q of W.pj) drawList.push([q.z + 0.02, 2, q]);
      drawList.sort((p, q) => p[0] - q[0]);
      for (const d of drawList) { if (d[1] === 0) drawFoe(d[2], a); else if (d[1] === 1) drawPlayer(d[2], a, d[2].s === me); else drawProj(d[2], a); }
      drawFx(rdt);
      g.restore();
      drawHud();
    }

    /* ---------- 프레임 ---------- */
    let prevPh = '';
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      const rdt = Math.min(0.1, (now - (last || now)) / 1000); last = now;
      if (!st) return;
      wallT += rdt;
      if (st.ph === 'pick') { if (!paused) { pickTick(rdt); publish(rdt); } render(1, rdt); return; }
      if (!W) { render(1, rdt); return; }
      if (!paused) {
        const sm = slowT > 0 && !api.online ? 0.4 : 1; if (slowT > 0) slowT -= rdt;
        if (st.ph === 'play') simTick(rdt * SPD() * sm);
        pollNet(); publish(rdt);
        augTick(rdt);
      }
      /* 맞은 번쩍임 표시용 */
      if (shakeT > 0) { shakeT -= rdt; if (shakeT <= 0) shakeA = 0; } if (hurtT > 0) hurtT -= rdt; if (banT > 0) banT -= rdt;
      if (noteT > 0) { noteT -= rdt; if (noteT <= 0) noteEl.style.opacity = '0'; }
      const al = st.ph === 'play' && !paused ? clamp(acc / DT, 0, 1) : 1;
      setBtnIcons(); updButtons(); infoDraw();
      if (W.ph !== prevPh) { prevPh = W.ph; const show = st.ph === 'play' && meHum(); for (const b of btns) { b.el.style.display = show ? '' : 'none'; b.nm.style.display = show && !touchUI ? '' : 'none'; } }
      render(al, rdt);
    }
    /* 맞은 적 번쩍임: 사건에서 가장 가까운 대상에 표시 */
    const _onEv = onEv;
    onEv = function (e) { if (e[1] === 'h' && W) { let b = null, bd = 30; for (const q of W.es) { const d = Math.abs(q.x - e[2]) + Math.abs(q.z - e[3]); if (d < bd) { bd = d; b = q; } } if (b) { if (wallT - (flashAt[b.id] || -9) > 0.22) flashAt[b.id] = wallT; e.nid = b.id; } } else if (e[1] === 'pd') flashAt['p' + e[6]] = wallT; _onEv(e); };

    const onResize = () => layout();
    const onKeys = () => keyLabels();
    const onTapInfo = (e) => { if (!W || !st || st.ph !== 'play' || augEl) return; const r = wrap.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; if (x >= hudRect.x && x <= hudRect.x + hudRect.w && y >= hudRect.y && y <= hudRect.y + hudRect.h) { infoHold = true; e.stopPropagation(); } };
    const onTapInfoUp = () => { infoHold = false; };
    wrap.addEventListener('pointerdown', onTapInfo, true); window.addEventListener('pointerup', onTapInfoUp);
    window.addEventListener('resize', onResize); window.addEventListener('lounge-keys', onKeys); window.addEventListener('lounge-ctl', onResize);
    layout();
    raf = requestAnimationFrame(frame);
    return {
      update(s) {
        if (!s) return; const was = st ? st.ph : ''; if (!st || st.rid !== s.rid) { pickSent = -1; autoPickT = 0; augSent = null; augRound = -1; hsQ = -1; } st = s;
        if (st.ph === 'pick') { pickOpen(); pickDraw(); if (isHost()) startRun(false); }
        else { pickClose(); ensureWorld(); if (was !== st.ph) layout(); }
        if (st.ph === 'done') { augClose(); for (const b of btns) { b.el.style.display = 'none'; b.nm.style.display = 'none'; } }
      },
      pause() { paused = true; }, resume() { paused = false; last = 0; },
      destroy() {
        dead = true; cancelAnimationFrame(raf);
        window.removeEventListener('resize', onResize); window.removeEventListener('lounge-keys', onKeys); window.removeEventListener('lounge-ctl', onResize); window.removeEventListener('pointerup', onTapInfoUp); document.removeEventListener('keydown', onKeyCap, true);
        for (const f of offs) try { f(); } catch (e) {}
        pickClose(); augClose(); wrap.remove();
      },
    };
  }
  G.BELTBRAWL_VIEW = { mount };
})();
