/* 잿빛 가도 — 세계 시뮬(순수 로직). 고정 걸음 1/60초, 난수는 판 시드(W.rs)만 씀 — Math.random 없음. node에서도 돎.
   좌표: x 길(오른쪽이 앞) · z 깊이(0 안쪽 ~ ZD 바깥쪽) · y 높이. 편: 플레이어 0 · 적 1.
   호스트가 worldStep으로 전부 돌리고 packHost로 묶어 보냄. 손님은 applyHost + guestStep(자기 자리 이동만 예측). */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const D = G.BELTBRAWL;
  const { ZD, AW, SEG, MV, PJ, ZN, CLS, AUG, EN, EI, ZONES } = D;
  const DT = 1 / 60, GR = 1500;
  const HPZ = [1, 1.4, 1.85], DMZ = [1, 1.2, 1.42];
  const MOB_HP = D.SCALE.mobHp, BOSS_HP = D.SCALE.bossHp, BOSS_ATK = D.SCALE.bossAtk;   // 자료 표에 곱하는 전체 배율(도감도 같은 값을 씀)
  const ST = ['idle', 'act', 'hit', 'air', 'down', 'up', 'stag', 'ko', 'held'], STI = {}; ST.forEach((s, i) => { STI[s] = i; });
  const PH = ['start', 'intro', 'fight', 'clear', 'aug', 'go', 'travel', 'over'], PHI = {}; PH.forEach((s, i) => { PHI[s] = i; });
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const sgn = (v) => (v < 0 ? -1 : 1);
  const abs = Math.abs;
  const PJK = Object.keys(PJ), ZNK = Object.keys(ZN);

  function rnd(W) { let t = (W.rs = (W.rs + 0x6D2B79F5) | 0); t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  function ev(W, k, x, z, y, a, b) { W.ev.push([W.evq++, k, Math.round(x), Math.round(z), Math.round(y || 0), a || 0, b || 0, W.tick]); if (W.ev.length > 120) W.ev.splice(0, W.ev.length - 120); }

  /* ======================= 세계 만들기 ======================= */
  function makeWorld(st, o) {
    const W = { host: !o || o.host !== false, rs: (st.seed | 0) || 1, t: 0, tick: 0, n: st.n, len: D.LENS[st.len] || D.LENS.m, ps: [], es: [], pj: [], zn: [], orb: [], ev: [], evq: 1, eid: 1, ph: 'start', pt: 1.2, zi: 0, si: 0, bx0: 0, bx0t: 0, bx1: AW, sq: [], wq: [], wave: 0, wt: 0, spT: 0, over: null, offers: null, pk: null, ar: 0, solo: st.n === 1, fade: 0, bossId: 0, ft: 0, em: {}, waves: 0 };
    let s = ((st.seed | 0) ^ 0x51ed27) | 0;
    const pr = () => { let t = (s = (s + 0x6D2B79F5) | 0); t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const zs = [0, 1, 2, 3]; for (let i = 3; i > 0; i--) { const j = Math.floor(pr() * (i + 1)), q = zs[i]; zs[i] = zs[j]; zs[j] = q; }
    W.plan = zs.slice(0, W.len.zones).map((z) => ({ z, boss: EI[ZONES[z].boss[pr() < 0.5 ? 0 : 1]] }));
    for (let i = 0; i < st.n; i++) {
      const c = clamp(st.cls && st.cls[i] >= 0 ? st.cls[i] : 0, 0, CLS.length - 1), C = CLS[c];
      W.ps.push({ s: i, cls: c, isE: false, x: 110 + (i % 2) * 46 + (i > 1 ? 30 : 0), z: 24 + i * 24, y: 0, vx: 0, vz: 0, vy: 0, ox: 0, oz: 0, oy: 0, face: 1, hp: C.hp, mhp: C.hp, sh: 0, st: 'idle', t: 0, mv: null, mt: 0, ai: 0, dur: 0, msp: 1, hset: null, ci: 0, ct: 0, cd: [0, 0, 0], ecd: 0, inv: 0, hs: 0, buf: 0, bt: 0, aug: {}, al: [], m: {}, bf: {}, combo: 0, cbt: 0, rev: 0, auto: 0, srUsed: 0, stt: { d: 0, k: 0, o: 0, r: 0, m: 0 }, bu: 0, ch: 0, w: 14, lv: st.lv ? st.lv[i] || 0 : 0, mvn: 0, dvx: 0, dvz: 0, dtm: 0, pfT: -9, rem: false, rin: null, rx: 0, rz: 0, sq: [0, 0, 0, 0], grabE: 0,
        bot: { tk: pr() * 0.3, o: { mx: 0, mz: 0, a: 0, k: 0 }, tg: 0, seen: {}, sn: 0, hab: { aggr: 0.35 + pr() * 0.65, caut: 0.35 + pr() * 0.65, team: 0.35 + pr() * 0.65, sk: 0.3 + pr() * 0.7, lane: (pr() - 0.5) * 20 }, wait: 0 } });
    }
    for (const p of W.ps) { p.ox = p.x; p.oz = p.z; }
    return W;
  }
  const zoneOf = (W) => W.plan[Math.min(W.zi, W.plan.length - 1)].z;
  const bossSeg = (W) => W.si >= W.len.segs;

  function calcMods(p) {
    const m = {}; for (const id in p.aug) { const x = AUG[id], n = p.aug[id]; for (const k in x.fx) m[k] = (m[k] || 0) + x.fx[k] * n; }
    p.m = m; const mh = Math.round(CLS[p.cls].hp * (1 + (m.hp || 0)));
    if (mh !== p.mhp) { const d = mh - p.mhp; p.mhp = mh; p.hp = d > 0 && p.st !== 'ko' ? Math.min(mh, p.hp + d) : Math.min(p.hp, mh); }
  }
  function addAug(W, p, i) { if (!AUG[i]) return; p.aug[i] = (p.aug[i] || 0) + 1; if (p.al.indexOf(i) < 0) p.al.push(i); calcMods(p); }
  const heal = (W, p, v) => { if (p.st === 'ko' || v <= 0) return; const b = p.hp; p.hp = Math.min(p.mhp, p.hp + v); if (p.hp - b >= 1) ev(W, 'hl', p.x, p.z, 40, Math.round(p.hp - b), p.s); };

  /* ======================= 구간 · 단계 ======================= */
  function spawnEnemy(W, k, x, z, o) {
    const K = EN[k], zi = W.zi, n = W.n; o = o || {};
    const hs = K.boss ? BOSS_HP * Math.pow(HPZ[zi], 0.85) * (1 + 1.1 * (n - 1)) : MOB_HP * HPZ[zi] * (1 + 0.75 * (n - 1)) * (o.el ? 2.6 : 1);
    const e = { id: W.eid++, k, isE: true, x, z, y: K.fly || 0, vx: 0, vz: 0, vy: 0, ox: x, oz: z, oy: K.fly || 0, face: x > (W.bx0 + W.bx1) / 2 ? -1 : 1, hp: Math.round(K.hp * hs), mhp: Math.round(K.hp * hs), atk: K.atk * DMZ[zi] * (o.el ? 1.3 : 1) * (K.boss ? BOSS_ATK : 1) * (D.SCALE.atk1 + D.SCALE.atkN * (n - 1)), st: 'idle', t: 0, mv: null, mi: -1, mt: 0, ai: 0, hset: null, c: K.mv.map((m, i) => (K.boss ? 1 + i * 1.6 : rnd(W) * 1.2)), gcd: 0.5 + rnd(W) * 0.8, pm: -1, tg: -1, tk: 0, poise: Math.max(K.pmax, o.el ? 5 : 0), pmax: Math.max(K.pmax, o.el ? 5 : 0), gp: K.guard || 0, jug: 0, el: o.el ? 1 : 0, in: !!o.in, w: K.w * (o.el ? 1.2 : 1), bl: 0, blt: 0, bu: 0, sk: 0, ch: 0, mk: 0, own: -1, lb: -1, p2: false, dead: false, hst: 0, par: o.par || 0, inv: 0, hs: 0, rate: 1, dvx: 0, dvz: 0, dtm: 0, mvn: 0, held: -1, age: 0, m: null };
    W.es.push(e); return e;
  }
  function buildWaves(W) {
    const Z = ZONES[zoneOf(W)], n = W.n, zi = W.zi, si = W.si;
    const total = (17 + 5.5 * si + 8 * zi) * (1 + 0.65 * (n - 1));
    const nw = si === 0 && zi === 0 ? 2 : 3; W.wq = [];
    for (let w = 0; w < nw; w++) {
      let bud = total / nw * (0.85 + 0.15 * w), big = 0; const list = []; let guard = 0;
      while (bud >= 1 && guard++ < 40) {
        const id = Z.pool[Math.floor(rnd(W) * Z.pool.length)], K = EN[EI[id]];
        if (K.cost > bud + 0.5) { if (bud < 2) { const sm = Z.pool.map((q) => EN[EI[q]]).filter((q) => q.cost <= 2); if (sm.length) { const q = sm[Math.floor(rnd(W) * sm.length)]; list.push([q.i, 0]); bud -= q.cost; } else break; } continue; }
        if (K.cost >= 6 && (big || (zi === 0 && si === 0))) continue;
        if (K.stat && list.filter((q) => EN[q[0]].stat).length >= 1) continue;
        if (K.cost >= 6) big = 1;
        list.push([K.i, 0]); bud -= K.cost;
      }
      if (w === nw - 1 && (zi > 0 || si >= 1) && rnd(W) < 0.3 + 0.15 * zi) { const c = list.filter((q) => { const K = EN[q[0]]; return !K.boomOnDeath && !K.minion && K.cost >= 2 && K.cost <= 4 && !K.stat; }); if (c.length) c[Math.floor(rnd(W) * c.length)][1] = 1; }
      W.wq.push(list);
    }
  }
  function startSeg(W) {
    W.bx0t = W.si * SEG; W.bx1 = W.si * SEG + AW; W.wave = 0; W.wt = 0; W.sq = []; W.ft = 0;
    for (const p of W.ps) { if (p.m.shield && p.st !== 'ko') p.sh = Math.round(p.mhp * p.m.shield); }
    if (bossSeg(W)) {
      const k = W.plan[W.zi].boss, b = spawnEnemy(W, k, W.bx1 - 150, ZD / 2, { in: true }); b.face = -1; W.bossId = b.id; W.wq = [];
      W.ph = 'intro'; W.pt = 2.0; ev(W, 'boss', b.x, b.z, 0, k, 0);
    } else { W.bossId = 0; buildWaves(W); W.ph = 'fight'; nextWave(W); }
  }
  function nextWave(W) { const l = W.wq.shift(); if (!l) return false; W.sq = l.slice(); W.wave++; W.wt = 0; W.spT = 0.2; return true; }
  function spawnTick(W, dt) {
    if (!W.sq.length) return;
    W.spT -= dt; if (W.spT > 0) return;
    let alive = 0; for (const e of W.es) if (!e.dead && !EN[e.k].minion) alive++;
    if (alive >= 7 + 2 * W.n) { W.spT = 0.3; return; }
    const q = W.sq.shift(), K = EN[q[0]]; W.spT = 0.4 + rnd(W) * 0.3;
    if (K.stat) { spawnEnemy(W, K.i, W.bx0t + 320 + rnd(W) * (AW - 440), 14 + rnd(W) * (ZD - 28), { in: true, el: q[1] }); return; }
    const left = W.si > 0 && rnd(W) < 0.28;
    spawnEnemy(W, K.i, left ? W.bx0t - 30 - rnd(W) * 30 : W.bx1 + 30 + rnd(W) * 40, 8 + rnd(W) * (ZD - 16), { el: q[1] });
  }
  function makeOffers(W) {
    W.offers = []; W.pk = []; W.ar++;
    for (const p of W.ps) {
      const tags = {}; for (const id of p.al) for (const t of AUG[id].tags) tags[t] = 1;
      const pool = []; let tot = 0;
      for (const x of AUG) {
        if (x.cls >= 0 && x.cls !== p.cls) continue; if ((p.aug[x.i] || 0) >= x.max) continue;
        let w = x.tier === 1 ? 6 : x.tier === 2 ? 2.6 + W.zi * 0.7 : 0.7 + W.zi * 0.5;
        if (x.cls >= 0) w *= 1.5; if (x.tags.some((t) => tags[t])) w *= 1.7; if (p.aug[x.i]) w *= 1.2;
        pool.push([x.i, w]); tot += w;
      }
      const o = [];
      for (let k = 0; k < 3 && pool.length; k++) { let r = rnd(W) * tot, j = 0; for (; j < pool.length - 1; j++) { r -= pool[j][1]; if (r <= 0) break; } o.push(pool[j][0]); tot -= pool[j][1]; pool.splice(j, 1); }
      W.offers.push(o); W.pk.push(-2);
    }
  }
  function botPick(W, p, of) {
    if (!of.length) return 3;
    if (p.lv === 1) return Math.floor(rnd(W) * of.length);
    const tags = {}; for (const id of p.al) for (const t of AUG[id].tags) tags[t] = (tags[t] || 0) + 1;
    let best = 0, bs = -9;
    of.forEach((i, k) => { const x = AUG[i]; let s = x.tier * 0.8 + (x.cls >= 0 ? 0.6 : 0) + rnd(W) * (1.6 - p.bot.hab.sk * 0.6); for (const t of x.tags) s += Math.min(2, tags[t] || 0) * 0.7; if (x.fx.hp || x.fx.def || x.fx.leech) s += (1 - p.hp / p.mhp) * 1.2 + p.bot.hab.caut * 0.4; if (s > bs) { bs = s; best = k; } });
    if (p.hp < p.mhp * 0.3 && bs < 2.2) return 3;
    return best;
  }
  function applyPick(W, s, c) {
    if (W.ph !== 'aug' || !W.pk || W.pk[s] !== -2) return false;
    const p = W.ps[s], of = W.offers[s] || [];
    if (c >= 0 && c < of.length) { W.pk[s] = c; addAug(W, p, of[c]); ev(W, 'aug', p.x, p.z, 0, of[c], s); }
    else { W.pk[s] = 3; if (p.st === 'ko') revive(W, p, 0.3); else heal(W, p, p.mhp * 0.3); }
    return true;
  }
  function finish(W, win) {
    if (W.over) return;
    W.ph = 'over';
    W.over = { win: win ? 1 : 0, zone: zoneOf(W), zi: W.zi, si: W.si, boss: bossSeg(W) ? 1 : 0, time: Math.round(W.t), zones: W.plan.map((q) => q.z), st: W.ps.map((p) => ({ c: p.cls, d: Math.round(p.stt.d), k: p.stt.k, o: p.stt.o, r: p.stt.r, m: p.stt.m, a: p.al.map((i) => [i, p.aug[i]]) })) };
  }
  function phase(W, dt, humanPick) {
    W.bx0 += clamp(W.bx0t - W.bx0, -420 * dt, 420 * dt);
    if (W.fade > 0) W.fade = Math.max(0, W.fade - dt);
    switch (W.ph) {
      case 'start': W.pt -= dt; if (W.pt <= 0) startSeg(W); break;
      case 'intro': W.pt -= dt; if (W.pt <= 0) W.ph = 'fight'; break;
      case 'fight': {
        W.wt += dt; W.ft += dt; spawnTick(W, dt);
        let alive = 0, real = 0; for (const e of W.es) if (!e.dead) { alive++; if (!EN[e.k].minion) real++; }
        if (!W.sq.length) {
          if (W.wq.length) { if (real <= 1 || W.wt > 26) nextWave(W); }
          else if (alive === 0 || (W.bossId && !W.es.some((e) => e.id === W.bossId && !e.dead))) {
            for (const e of W.es) if (!e.dead) killEnemy(W, e, null, true);
            W.ph = 'clear'; W.pt = 1.4; W.pj = W.pj.filter((q) => q.own === 0); W.zn = W.zn.filter((q) => q.own === 0);
            ev(W, 'clear', (W.bx0 + W.bx1) / 2, ZD / 2, 0, bossSeg(W) ? 1 : 0, 0);
            for (const p of W.ps) { if (p.st === 'ko') revive(W, p, 0.3); else heal(W, p, p.mhp * 0.15); }
          }
        }
        break;
      }
      case 'clear':
        W.pt -= dt;
        if (W.pt <= 0) { if (bossSeg(W) && W.zi >= W.plan.length - 1) finish(W, true); else { makeOffers(W); W.ph = 'aug'; W.pt = 0; } }
        break;
      case 'aug': {
        W.pt += dt; let all = true;
        for (const p of W.ps) {
          if (W.pk[p.s] !== -2) continue;
          const human = humanPick && humanPick(p.s);
          if (!human) { if (W.pt > 0.5) applyPick(W, p.s, botPick(W, p, W.offers[p.s])); else all = false; }
          else if (W.pt > 45) applyPick(W, p.s, botPick(W, p, W.offers[p.s])); else all = false;
        }
        if (all) {
          if (bossSeg(W)) { W.ph = 'travel'; W.pt = 1.1; W.fade = 1.1; ev(W, 'fade', 0, 0, 0, 0, 0); }
          else { W.ph = 'go'; W.bx1 = (W.si + 1) * SEG + AW; ev(W, 'go', 0, 0, 0, 0, 0); }
        }
        break;
      }
      case 'go': {
        let lead = -1e9; for (const p of W.ps) if (p.st !== 'ko') lead = Math.max(lead, p.x);
        if (lead >= (W.si + 1) * SEG + 250) { W.si++; startSeg(W); }
        break;
      }
      case 'travel':
        W.pt -= dt;
        if (W.pt <= 0) {
          W.zi++; W.si = 0; W.bx0 = W.bx0t = 0; W.bx1 = AW; W.pj.length = 0; W.zn.length = 0; W.orb.length = 0; W.es.length = 0;
          W.ps.forEach((p, i) => { p.x = p.ox = 110 + (i % 2) * 46 + (i > 1 ? 30 : 0); p.z = p.oz = 24 + i * 24; p.y = p.oy = 0; p.vx = p.vz = p.vy = 0; p.face = 1; p.srUsed = 0; p.rx = p.x; p.rz = p.z; p.tpN = (p.tpN || 0) + 1; if (p.st !== 'ko') { p.st = 'idle'; p.mv = null; } });
          W.ph = 'start'; W.pt = 1.3; W.fade = 0.6; ev(W, 'zone', 0, 0, 0, zoneOf(W), W.zi);
        }
        break;
    }
  }

  /* ======================= 맞히기 ======================= */
  function revive(W, p, f) { p.st = 'up'; p.t = 0.3; p.hp = Math.max(1, Math.round(p.mhp * f)); p.inv = 2; p.rev = 0; p.auto = 0; p.bu = 0; p.ch = 0; p.y = 0; p.vx = p.vz = p.vy = 0; ev(W, 'rv', p.x, p.z, 0, p.s, 0); }
  function perfect(W, p) { if (W.t - p.pfT < 0.5) return; p.pfT = W.t; ev(W, 'pf', p.x, p.z, 30, p.s, 0); if (p.m.perfect) p.bf.pf = 4; if (p.m.dodgeCrit) p.bf.dc = 3; }
  function ko(W, p) {
    p.st = 'ko'; p.hp = 0; p.rev = 0; p.mv = null; p.vx = p.vz = 0; p.y = 0; p.vy = 0; p.stt.o++; p.sh = 0; p.bf = {}; p.combo = 0;
    const allow = (W.solo ? 1 : 0) + (p.m.selfRev ? 1 : 0);
    if (p.srUsed < allow) { p.srUsed++; p.auto = 3; } else p.auto = 0;
    ev(W, 'ko', p.x, p.z, 0, p.s, p.auto > 0 ? 1 : 0);
  }
  function hurtPlayer(W, p, src, h, dmg) {
    if (p.st === 'ko' || W.ph === 'clear' || W.ph === 'aug') return 0;
    const mv = p.st === 'act' ? p.mv : null, m = p.m;
    if (p.inv > 0 || (mv && mv.inv && p.mt >= mv.inv[0] && p.mt < mv.inv[1])) { if (!h.soft && (mv && mv.inv)) perfect(W, p); return 0; }
    let blocked = false;
    if (mv && mv.guard && (!src || sgn(src.x - p.x) === p.face || h.soft)) {
      if (m.guardSh) p.sh = Math.min(p.mhp * 0.5, p.sh + p.mhp * m.guardSh);
      if (p.mt < mv.guard && !h.soft) { perfect(W, p); if (m.guardCtr) p.bf.ctr = 5; if (src && src.isE && !src.dead) poiseHit(W, src, 3, p); ev(W, 'pg', p.x + p.face * 16, p.z, 34, p.s, 0); return 0; }
      dmg *= 0.15; blocked = true; ev(W, 'bl', p.x + p.face * 16, p.z, 34, 0, 0);
    }
    dmg *= 1 - Math.min(0.75, (m.def || 0) + (mv && mv.kind === 's' ? m.armDef || 0 : 0));
    dmg = Math.max(1, Math.round(dmg));
    if (p.sh > 0) { const a = Math.min(p.sh, dmg); p.sh -= a; dmg -= a; }
    p.hp -= dmg;
    if (m.thorn && src && src.isE && !src.dead) dotEnemy(W, src, CLS[p.cls].atk * m.thorn, p.s, 3);
    if (!h.soft || dmg > 0) ev(W, 'pd', p.x, p.z, 44, dmg, p.s);
    if (h.burn) p.bu = 3; if (h.chill) p.ch = 2.5;
    if (p.hp <= 0) { ko(W, p); return dmg; }
    if (blocked || h.soft) return dmg;
    if (mv && mv.arm && p.mt >= mv.arm[0] && p.mt < mv.arm[1]) return dmg;
    const dir = src ? sgn(p.x - src.x) || 1 : (h.cx != null ? sgn(p.x - h.cx) || 1 : -p.face);
    p.mv = null; p.buf = 0; p.dtm = 0;
    if (h.pull && src) { p.st = 'hit'; p.t = Math.max(0.3, h.stun || 0.3); p.pull = 0.26; p.vx = (src.x - dir * 54 - p.x) / 0.26; p.vz = (src.z - p.z) / 0.26 * 0.6; }
    else if (h.down || h.lift) { p.st = 'air'; p.vy = h.lift ? Math.min(330, h.lift) : 210; p.vx = dir * (h.kb || 120) * 0.7; p.y = Math.max(p.y, 1); }
    else { p.st = 'hit'; p.t = h.stun || 0.24; p.vx = dir * (h.kb || 60) * 0.6; }
    p.inv = Math.max(p.inv, 0.3);
    return dmg;
  }
  function stagger(W, e, t) { const K = EN[e.k]; releaseHeld(W, e); e.st = 'stag'; e.t = t; e.mv = null; e.dtm = 0; e.poise = e.pmax; if (K.fly) e.vy = 0; ev(W, 'stg', e.x, e.z, K.h * 0.8, e.id, 0); }
  function poiseHit(W, e, pd, p) {
    if (e.dead) return;
    if (e.pmax > 0) { if (e.st !== 'stag') { e.poise -= pd; if (e.poise <= 0) stagger(W, e, EN[e.k].boss ? 2.6 : 1.9); } }
    else if (e.gp > 0) { e.gp -= pd; if (e.gp <= 0) { e.gp = EN[e.k].guard; stagger(W, e, 2.0); ev(W, 'gb', e.x, e.z, 30, 0, 0); } }
    else if (e.st === 'idle' || e.st === 'act') { e.st = 'hit'; e.t = 0.5; e.mv = null; }
    void p;
  }
  function credit(W, s, e, dmg) { if (s >= 0 && W.ps[s]) { const p = W.ps[s]; p.stt.d += Math.min(dmg, Math.max(0, e.hp + dmg)); if (p.m.leech) { p.lc = (p.lc || 0) + dmg * p.m.leech; if (p.lc >= 1) { const v = Math.floor(p.lc); p.lc -= v; if (p.st !== 'ko') p.hp = Math.min(p.mhp, p.hp + v); } } } }
  function dotEnemy(W, e, dmg, s, kind) { if (e.dead) return; dmg = Math.max(1, Math.round(dmg)); e.hp -= dmg; credit(W, s, e, dmg); ev(W, 'dt', e.x, e.z, EN[e.k].h * 0.7 + e.y, dmg, kind || 0); if (e.hp <= 0) killEnemy(W, e, s >= 0 ? W.ps[s] : null); }
  function releaseHeld(W, e) { if (e.held >= 0) { const p = W.ps[e.held]; if (p) p.grabE = 0; e.held = -1; } }
  function killEnemy(W, e, p, quiet) {
    if (e.dead) return; e.dead = true; e.hp = 0; const K = EN[e.k]; releaseHeld(W, e);
    ev(W, 'k', e.x, e.z, e.y, e.k, e.el ? 1 : 0);
    if (quiet) return;
    if (p) {
      p.stt.k++; const m = p.m;
      if (m.killHeal) heal(W, p, m.killHeal);
      if (m.killHaste) p.bf.kh = 3;
      if (m.killBoom && !e.selfKill) areaProc(W, p, e.x, e.z, 64, CLS[p.cls].atk * m.killBoom, e.id, 4);
      if (m.burnSpread && e.bu > 0) for (const q of W.es) if (!q.dead && q !== e && abs(q.x - e.x) < 90 && abs(q.z - e.z) < 50) { q.bu = 3; q.bown = p.s; }
      if (m.zoneKill) for (const z of W.zn) if (z.own === 0 && z.src === p.s && inEll(e.x, e.z, z)) { heal(W, p, m.zoneKill); break; }
    }
    if (K.split && !e.noSplit) { const k2 = EI[K.split[0]]; for (let i = 0; i < K.split[1]; i++) { const c = spawnEnemy(W, k2, e.x + (i ? 22 : -22), clamp(e.z + (i ? 10 : -10), 4, ZD - 4), { in: true, par: e.id }); c.st = 'air'; c.vy = 240; c.vx = (i ? 1 : -1) * 90; c.y = 4; } }
    if (K.boomOnDeath && !e.selfKill) { W.zn = W.zn.filter((z) => !(z.own === 1 && z.srcE === e.id)); addZone(W, 'boomP', e.x, e.z, 0, p ? p.s : -1, null, 1, { kind: 'x' }); }
    if (!K.minion && !K.boss) { const lootUp = W.ps.reduce((q, pl) => Math.max(q, pl.m.loot || 0), 0); if (e.el || rnd(W) < 0.07 + lootUp * 0.03) W.orb.push({ x: e.x, z: e.z, t: 16 }); }
    if (K.boss) { for (const q of W.es) if (!q.dead && q !== e) killEnemy(W, q, null, true); ev(W, 'bk', e.x, e.z, 0, e.k, 0); }
  }
  const inEll = (x, z, q) => { const a = (x - q.x) / q.rx, b = (z - q.z) / q.rz; return a * a + b * b <= 1; };
  function areaProc(W, p, x, z, r, dmg, skip, kind) { for (const q of W.es) { if (q.dead || q.id === skip) continue; const a = (q.x - x) / r, b = (q.z - z) / (r * 0.6); if (a * a + b * b <= 1) dotEnemy(W, q, dmg, p ? p.s : -1, kind); } ev(W, 'ex', x, z, 0, Math.round(r), kind || 0); }
  function dmgMult(p, e, c, air, down) {
    const m = p.m, K = EN[e.k]; let A = 1 + (m.dmg || 0), B = 1, C = 1;
    if (c.kind === 'b') { A += m.basic || 0; if (c.last) A += m.lastD || 0; if (p.bf.sb) A += m.stepBuff || 0; }
    else if (c.kind === 's') { A += (m.skill || 0) + (m['sk' + c.si + 'd'] || 0); if (c.si === 0 && p.bf.hb) A += m.hopBuff || 0; }
    if (air) B += m.airDmg || 0; if (down) B += m.downDmg || 0;
    if (e.bl > 0) B += m.vsBleed || 0; if (e.bu > 0) B += m.vsBurn || 0; if (e.ch > 0) B += m.vsChill || 0; if (e.st === 'stag') B += m.vsStag || 0;
    if (m.vsStatus && (e.bl > 0 || e.bu > 0 || e.sk > 0 || e.ch > 0)) B += m.vsStatus;
    if (m.exec && e.hp < e.mhp * 0.25) B += m.exec; if (m.elite && (K.boss || e.el)) B += m.elite;
    if (m.low && p.hp < p.mhp * 0.4) B += m.low; if (m.full && p.hp > p.mhp * 0.8) B += m.full;
    if (m.combo) B += m.combo * Math.min(5, Math.floor(p.combo / 10));
    if (m.rage && p.combo >= 20) B += m.rage;
    const dist = abs(e.x - p.x); if (m.far && dist > 180) B += m.far; if (m.near && dist < 90) B += m.near;
    if (p.bf.pf) C += m.perfect || 0; if (p.bf.gb) C += m.grabBuff || 0; if (p.bf.ctr) C += m.guardCtr || 0; if (p.bf.mu) C += m.multi || 0; if (p.bf.za) C += p.zaV || 0;
    return A * B * C;
  }
  /* c: { kind 'b' 기본 | 's' 기술 | 'x' 부가, si, last, sx(때린 쪽 x) } */
  function hitEnemy(W, p, e, h, d, c) {
    if (e.dead || e.inv > 0) return 0;
    const K = EN[e.k], m = p ? p.m : {}, atk = p ? CLS[p.cls].atk : 10;
    const downed = e.st === 'down', air = !downed && (e.y > 2 || e.st === 'air');
    const sx = c.sx != null ? c.sx : p ? p.x : e.x - e.face;
    let blocked = false;
    if (K.guard && e.gp > 0 && !air && !downed && e.st !== 'stag' && e.st !== 'hit' && e.st !== 'held' && !h.slam && !c.grab && !(h.lift >= 300) && sgn(sx - e.x) === e.face && !(e.st === 'act' && e.mt > 0.3)) blocked = true;
    let dmg = d * atk, crit = false;
    if (p) {
      dmg *= dmgMult(p, e, c, air, downed);
      if (c.kind !== 'x') {
        let cc = 0.05 + (m.crit || 0) + (e.bl > 0 ? m.critBleed || 0 : 0);
        if (p.bf.dc) { cc = 1; delete p.bf.dc; } if (c.last && m.lastCrit) cc = 1;
        if (rnd(W) < cc) { crit = true; dmg *= 1.5 + (m.critd || 0); }
      }
    }
    if (downed && !h.otg) dmg *= 0.6;
    if (e.st === 'stag') dmg *= 1.25;
    if (e.mk > 0) dmg *= 1.15;
    const pd = (h.poise != null ? h.poise : d * 0.6) * (1 + (m.poise || 0)) * (e.sk > 0 ? 1 + (m.vsShock || 0) : 1);
    if (blocked) { dmg *= 0.15; ev(W, 'bl', e.x + e.face * 14, e.z, K.h * 0.6, 0, 0); }
    dmg = Math.max(1, Math.round(dmg));
    e.hp -= dmg;
    credit(W, p ? p.s : -1, e, dmg);
    ev(W, 'h', e.x, e.z, K.h * 0.6 + e.y, dmg, (crit ? 1 : 0) | (blocked ? 2 : 0) | (c.kind === 'x' ? 4 : 0) | (h.hv || (h.hs || 3) >= 5 ? 8 : 0));
    if (e.hp <= 0) { killEnemy(W, e, p); return dmg; }
    e.hs = Math.max(e.hs, h.hs != null ? Math.min(h.hs, 4) : c.kind === 'x' ? 0 : 3);
    if (blocked) { poiseHit(W, e, pd, p); return dmg; }
    /* 상태 이상 */
    if (p && c.kind !== 'x') {
      if (h.bleed || (c.kind === 'b' && m.bleed && rnd(W) < m.bleed)) { e.bl = Math.min(5, e.bl + 1 + (h.bleed ? m.bleedAdd || 0 : 0)); e.blt = 4; e.own = p.s; }
      if (m.rupture && e.bl >= 5) { e.bl = 0; ev(W, 'rp', e.x, e.z, K.h * 0.5, 0, 0); dotEnemy(W, e, atk * m.rupture, p.s, 1); if (e.dead) return dmg; }
      if (h.burn || (c.kind === 's' && m.burn && rnd(W) < m.burn)) { e.bu = 3; e.bown = p.s; }
      if (e.sk > 0) { e.sk = 0; let n = 2 + (m.chainN || 0); for (const q of W.es) { if (n <= 0) break; if (q.dead || q === e || abs(q.x - e.x) > 170 || abs(q.z - e.z) > 70) continue; n--; ev(W, 'ch', e.x, e.z, K.h * 0.5, Math.round(q.x), Math.round(q.z)); dotEnemy(W, q, atk * 0.8 * (1 + (m.chain || 0)), p.s, 2); } }
      else if (m.shock && rnd(W) < m.shock) e.sk = 6;
      if (h.chill || (m.chill && rnd(W) < m.chill)) e.ch = 3;
      if (crit && m.freeze && e.ch > 0 && !K.boss && e.pmax === 0) { e.st = 'hit'; e.t = m.freeze; e.mv = null; e.vx = 0; return dmg; }
      if (m.markOn && c.kind === 'b') e.mk = 5;
      if (c.kind === 's' && c.si === 2 && m.dashRefund && p.cls === 1) p.cd[2] = Math.max(0, p.cd[2] - m.dashRefund);
    }
    /* 반응 */
    const superA = e.pmax > 0 || (e.st === 'act' && e.mv && e.mv.arm && e.mt >= e.mv.arm[0] && e.mt < e.mv.arm[1]);
    if (e.pmax > 0 && e.st !== 'stag') { e.poise -= pd; if (e.poise <= 0) { stagger(W, e, K.boss ? 2.6 : 1.9); return dmg; } }
    if (e.st === 'held') return dmg;
    const canReact = !superA || (e.st === 'stag' && !K.heavy && !K.stat);
    if (!canReact) return dmg;
    if (K.stat) { if (e.st !== 'act' || h.stun) { e.st = 'hit'; e.t = Math.min(0.2, h.stun || 0.2); e.mv = null; } return dmg; }
    const dir = c.dir || sgn(e.x - sx) || 1, kb = h.kb || 0;
    const dec = Math.pow(0.8 + 0.12 * Math.min(1, m.juggle || 0), e.jug);
    const lift = h.lift && !K.heavy ? h.lift * (1 + (m.launch || 0)) : 0;
    e.mv = null; e.dtm = 0; if (p) e.lb = p.s;
    if (air) { e.vy = Math.max(e.vy, (lift ? lift * 0.85 : 190) * dec); e.jug++; e.vx = dir * kb * 0.5; e.st = 'air'; e.y = Math.max(e.y, 2); }
    else if (lift) { e.vy = lift * dec; e.jug++; e.st = 'air'; e.vx = dir * kb; e.y = Math.max(e.y, 2); }
    else if (downed) { if (h.otg && !K.heavy) { e.vy = 170; e.st = 'air'; e.y = 2; e.vx = dir * kb * 0.4; } }
    else if (h.down && !K.heavy) { e.vy = 200; e.vx = dir * kb; e.st = 'air'; e.y = 2; }
    else if (e.st === 'stag') e.vx = dir * kb * 0.4;
    else { e.st = 'hit'; e.t = (h.stun || 0.3) + (c.pin || 0); e.vx = dir * kb * (K.heavy ? 0.4 : 1); }
    return dmg;
  }

  function ctxOf(a, x) { const mv = a.mv; return { kind: mv ? mv.kind : 'x', si: mv ? mv.si : 0, last: x && x.last ? 1 : 0 }; }
  function hitBox(W, a, x) {
    const isP = !a.isE, m = a.m || {};
    const sc = isP ? 1 + (a.mv && a.mv.kind === 'b' ? m.reach || 0 : m.aoe || 0) : 1;
    let x0 = a.x + a.face * x.x0 * sc, x1 = a.x + a.face * x.x1 * sc; if (x0 > x1) { const q = x0; x0 = x1; x1 = q; }
    const zr = x.zr * sc; let n = 0;
    const key = x.to ? 'k' + x.at : null; if (key && !a.hset) a.hset = {};
    if (isP) {
      const c = ctxOf(a, x);
      for (let i = 0; i < W.es.length; i++) {
        const t = W.es[i]; if (t.dead) continue;
        if (t.x < x0 - t.w || t.x > x1 + t.w || abs(t.z - a.z) > zr + t.w * 0.4) continue;
        if (x.slam && t.id === a.slamSkip) continue;
        if (hitEnemy(W, a, t, x, x.d, c)) n++;
      }
      if (n) {
        a.hs = Math.max(a.hs, x.hs != null ? x.hs : 3); a.combo += n; a.cbt = 2.6; if (a.combo > a.stt.m) a.stt.m = a.combo;
        if (n >= 2 && m.multi) a.bf.mu = 3;
        if (a.bf.ctr && a.mv && a.mv.kind !== 'e') a.ctrUse = 1;
        if (x.shake) ev(W, 'shk', a.x, a.z, 0, x.shake, a.s);
      }
    } else {
      for (const t of W.ps) {
        if (t.st === 'ko') continue;
        if (t.x < x0 - t.w || t.x > x1 + t.w || abs(t.z - a.z) > zr + t.w * 0.4) continue;
        if (key) { if (a.hset[key + t.s]) continue; a.hset[key + t.s] = 1; }
        if (hurtPlayer(W, t, a, x, a.atk * x.d)) { n++; if (x.shake) ev(W, 'shk', t.x, t.z, 0, x.shake, t.s); }
      }
    }
    return n;
  }
  /* 겨눌 대상(플레이어): 가까운 적, 막대를 민 쪽 우선 */
  function aimTarget(W, p, range, zr, mx) {
    let best = null, bs = 1e9;
    for (const e of W.es) {
      if (e.dead) continue; const dx = e.x - p.x, dz = abs(e.z - p.z); if (abs(dx) > range || dz > zr) continue;
      let s = abs(dx) + dz * 2.2; if (mx && sgn(dx) !== sgn(mx)) s += 400; else if (!mx && sgn(dx) !== p.face) s += 40;
      if (s < bs) { bs = s; best = e; }
    }
    return best;
  }
  function tgtPoint(W, a, x) {
    if (a.tpAt === x.at && a.tp && !x.any) return a.tp;
    let tx, tz;
    if (a.isE) {
      let t = W.ps[a.tg]; if (x.any || !t || t.st === 'ko') { const al = W.ps.filter((q) => q.st !== 'ko'); t = al.length ? al[Math.floor(rnd(W) * al.length)] : null; }
      tx = t ? t.x : a.x + a.face * 100; tz = t ? t.z : a.z;
      if (x.jit) { tx += (rnd(W) - 0.5) * 2 * x.jit; tz += (rnd(W) - 0.5) * x.jit; }
    } else {
      const e = aimTarget(W, a, x.rmax || 240, 80, 0);
      if (e) { tx = e.x; tz = e.z; a.face = sgn(e.x - a.x) || a.face; } else { tx = a.x + a.face * (x.dx || 120); tz = a.z; }
    }
    a.tpAt = x.at; a.tp = { x: clamp(tx, W.bx0 + 10, W.bx1 - 10), z: clamp(tz, 2, ZD - 2) };
    return a.tp;
  }
  function addZone(W, zk, x, z, own, src, a, d, c, ov) {
    const Z = ZN[zk], m = a && !a.isE ? a.m : {};
    let sc = 1, dur = Z.dur;
    if (own === 0 && a) { sc = 1 + (m.aoe || 0) + (zk === 'bind' || zk === 'pure' ? m.zoneBig || 0 : 0); if (dur && (zk === 'bind' || zk === 'pure')) dur += m.zoneDur || 0; }
    const q = { id: W.eid++, k: zk, x, z, rx: ((ov && ov.rx) || Z.rx) * sc, rz: ((ov && ov.rz) || Z.rz) * sc, age: 0, warn: ov && ov.warn != null ? ov.warn : Z.warn, dur, tn: 0, own, src, srcE: a && a.isE ? a.id : 0, d: d != null ? d : Z.d, c: c || { kind: 's', si: 0 }, on: false, down: (ov && ov.down) || Z.down, lift: Z.lift, kb: Z.kb, ally: own === 0 && a && m.zoneAlly ? m.zoneAlly : 0, healUp: own === 0 && a ? m.zoneHeal || 0 : 0 };
    W.zn.push(q); return q;
  }
  function fire(W, a, x) {
    const P = PJ[x.p], isP = !a.isE, m = a.m || {}, n = x.n || 1, c = isP ? ctxOf(a, x) : null;
    if (isP && x.sk) { c.kind = 's'; c.si = 1; }
    const dmg = isP ? x.d : a.atk * x.d;
    if (P.lob) {
      const t = tgtPoint(W, a, x); let tx = t.x, tz = t.z;
      if (isP && x.rmax) { const dx = clamp(tx - a.x, -x.rmax, x.rmax); tx = a.x + dx; }
      W.pj.push({ id: W.eid++, k: x.p, own: isP ? 0 : 1, src: isP ? a.s : a.id, x: a.x, z: a.z, y: 40, sx: a.x, sz: a.z, tx, tz, t: 0, T: P.lob * (isP ? 1 : 1), d: dmg, c, zone: x.zone || (x.zf && m.incend ? x.zf : P.zone), atk: a.atk });
      if (!isP) addZone(W, 'thorn', tx, tz, 2, -1, null, 0, null, { warn: P.lob, rx: P.aoe, rz: P.aoe * 0.6 });   // 떨어질 자리 예고(피해 없음)
      ev(W, 'sh', a.x, a.z, 40, 2, 0); return;
    }
    let tz = null;
    if (isP) { const e = aimTarget(W, a, CLS[a.cls].reach + 60, 34, 0); if (e && sgn(e.x - a.x) === a.face) tz = e; }
    else { const t = W.ps[a.tg]; if (t && t.st !== 'ko') tz = t; }
    for (let i = 0; i < n; i++) {
      const off = n > 1 ? (i / (n - 1) - 0.5) : 0;
      let vz = x.fan ? off * x.fan * 2.4 : 0;
      const sz = a.z + (x.sway ? ((a.ai * 7) % 5 - 2) * 2.5 : n > 1 && !x.fan ? off * 8 : 0);
      if (tz && !x.fan) { const tt = Math.max(0.08, abs(tz.x - a.x) / P.spd); vz = clamp((tz.z - sz) / tt, -90, 90); }
      const q = { id: W.eid++, k: x.p, own: isP ? 0 : 1, src: isP ? a.s : a.id, x: a.x + a.face * (isP ? 22 : 16), z: sz, y: isP ? 36 : EN[a.k].h * 0.55 + a.y * 0.5, vx: a.face * P.spd, vz, life: P.life * (isP && a.cls === 3 ? 1 : 1), d: dmg, c, pierce: (P.pierce || 0) + (isP && x.p === 'bullet' ? m.pierce || 0 : 0), hit: null, kb: x.kb, atk: a.atk, hom: isP && m.homing && (x.p === 'orb' || x.p === 'orbL') ? 1 : 0, pin: isP && x.p === 'jav' ? m.pin || 0 : 0, slow: isP && x.sk && m.slowShot ? 1 : 0, rico: isP && m.rico && x.p === 'bullet' ? 1 : 0 };
      W.pj.push(q);
    }
    ev(W, 'sh', a.x + a.face * 20, a.z, 36, isP ? (a.cls === 2 ? 0 : 1) : 3, 0);
  }
  function pjHitEnemy(W, q, e, P) {
    const p = W.ps[q.src]; if (!p) return;
    const c = Object.assign({}, q.c, { sx: q.x - sgn(q.vx || 1) * 10, pin: q.pin });
    const h = { kb: q.kb != null ? q.kb : P.kb, stun: P.stun, lift: P.lift, down: P.down, hs: 2, chill: q.slow };
    hitEnemy(W, p, e, h, q.d, c);
    if (P.aoe && !P.lob) { for (const o of W.es) { if (o.dead || o === e) continue; const a = (o.x - e.x) / P.aoe, b = (o.z - e.z) / (P.aoe * 0.6); if (a * a + b * b <= 1) hitEnemy(W, p, o, { kb: 40, stun: 0.15, hs: 0 }, q.d * 0.6, c); } ev(W, 'ex', e.x, e.z, 30, P.aoe, 5); }
    p.combo++; p.cbt = 2.6; if (p.combo > p.stt.m) p.stt.m = p.combo;
    if (q.rico && rnd(W) < p.m.rico) { let b = null, bd = 170; for (const o of W.es) { if (o.dead || o === e) continue; const dd = abs(o.x - e.x) + abs(o.z - e.z); if (dd < bd) { bd = dd; b = o; } } if (b) { const dx = b.x - e.x, dz = b.z - e.z, l = Math.hypot(dx, dz) || 1; W.pj.push({ id: W.eid++, k: 'bullet', own: 0, src: q.src, x: e.x, z: e.z, y: 30, vx: dx / l * 800, vz: dz / l * 800, life: 0.3, d: q.d * 0.6, c: q.c, pierce: 0, hit: [e.id], atk: q.atk, free: 1 }); } }
  }
  function explode(W, q, P) {
    ev(W, 'ex', q.x, q.z, 0, P.aoe, q.own === 0 ? 6 : 7);
    if (P.shake) ev(W, 'shk', q.x, q.z, 0, P.shake, -1);
    if (q.own === 0) { const p = W.ps[q.src]; if (p) { const sc = 1 + (p.m.aoe || 0); for (const e of W.es) { if (e.dead) continue; const a = (e.x - q.x) / (P.aoe * sc + e.w), b = (e.z - q.z) / (P.aoe * 0.6 * sc + e.w * 0.4); if (a * a + b * b <= 1) hitEnemy(W, p, e, { kb: P.kb, lift: P.lift, down: P.down, hs: 3, hv: 1 }, q.d, Object.assign({}, q.c, { sx: q.x })); } if (q.zone) addZone(W, q.zone, q.x, q.z, 0, p.s, p, null, q.c); } }
    else { for (const p of W.ps) { const a = (p.x - q.x) / P.aoe, b = (p.z - q.z) / (P.aoe * 0.6); if (a * a + b * b <= 1) hurtPlayer(W, p, null, { down: P.down, kb: P.kb, cx: q.x }, q.d); } if (q.zone) { const z = addZone(W, q.zone, q.x, q.z, 1, -1, null, q.atk * ZN[q.zone].d, null); z.warn = Math.min(z.warn, 0.15); } }
  }
  function stepProj(W, dt) {
    for (let i = W.pj.length - 1; i >= 0; i--) {
      const q = W.pj[i], P = PJ[q.k]; q.ox = q.x; q.oz = q.z; q.oy = q.y;
      if (P.lob) { q.t += dt; const f = Math.min(1, q.t / q.T); q.x = q.sx + (q.tx - q.sx) * f; q.z = q.sz + (q.tz - q.sz) * f; q.y = 40 * (1 - f) + 4 * 70 * f * (1 - f); if (f >= 1) { explode(W, q, P); W.pj.splice(i, 1); } continue; }
      if (q.hom) { let b = null, bd = 200; for (const e of W.es) { if (e.dead || sgn(e.x - q.x) !== sgn(q.vx)) continue; const dd = abs(e.x - q.x) + abs(e.z - q.z) * 2; if (dd < bd) { bd = dd; b = e; } } if (b) q.vz += clamp((b.z - q.z) * 8 - q.vz, -600 * dt, 600 * dt); }
      q.x += q.vx * dt; q.z += q.vz * dt; q.life -= dt;
      let gone = q.life <= 0 || q.z < -10 || q.z > ZD + 10 || q.x < W.bx0 - 80 || q.x > W.bx1 + 80;
      if (!gone) {
        const reach = abs(q.vx) * dt * 0.5 + 6;
        if (q.own === 0) {
          for (const e of W.es) {
            if (e.dead || (q.hit && q.hit.indexOf(e.id) >= 0)) continue;
            if (abs(e.x - q.x) > e.w + reach || abs(e.z - q.z) > P.zr + e.w * 0.4) continue;
            pjHitEnemy(W, q, e, P); (q.hit || (q.hit = [])).push(e.id);
            if (q.pierce-- <= 0) { gone = true; break; }
          }
        } else {
          for (const p of W.ps) {
            if (p.st === 'ko' || (q.hit && q.hit.indexOf(p.s) >= 0)) continue;
            if (abs(p.x - q.x) > p.w + reach || abs(p.z - q.z) > P.zr + 6) continue;
            (q.hit || (q.hit = [])).push(p.s);
            const src = W.es.find((e) => e.id === q.src && !e.dead) || null;
            const got = hurtPlayer(W, p, P.pull ? src : { x: q.x - sgn(q.vx) * 10, z: q.z, isE: false }, { kb: P.kb, stun: P.stun, down: P.down, pull: P.pull && src ? 1 : 0 }, q.d);
            if (got) { gone = true; break; }
          }
        }
      }
      if (gone) W.pj.splice(i, 1);
    }
  }
  function stepZones(W, dt) {
    for (let i = W.zn.length - 1; i >= 0; i--) {
      const q = W.zn[i], Z = ZN[q.k]; q.age += dt;
      if (q.age < q.warn) continue;
      const burst = !q.dur;
      if (!q.on) { q.on = true; q.tn = q.warn; if (burst && q.own !== 2) { ev(W, 'ex', q.x, q.z, 0, Math.round(q.rx), q.own === 0 ? 6 : 7); if (Z.shake) ev(W, 'shk', q.x, q.z, 0, Z.shake, -1); } }
      if (q.own === 2) { W.zn.splice(i, 1); continue; }
      if (q.age >= q.tn) {
        q.tn += Z.tick || 99;
        if (q.own === 0) {
          const p = W.ps[q.src] || null;
          for (const e of W.es) { if (e.dead) continue; const a = (e.x - q.x) / (q.rx + e.w * 0.6), b = (e.z - q.z) / (q.rz + e.w * 0.3); if (a * a + b * b > 1) continue; hitEnemy(W, p, e, { kb: q.kb || 0, lift: q.lift, down: q.down, hs: burst ? 3 : 0, stun: burst ? 0.3 : 0.12, chill: Z.chill, burn: Z.burn, poise: burst ? undefined : 0.15, hv: burst }, q.d, Object.assign({}, q.c, { sx: q.x, kind: burst ? q.c.kind : q.c.kind === 'x' ? 'x' : 's' })); }
          if (Z.heal || q.ally) for (const pl of W.ps) { if (pl.st === 'ko' || !inEll(pl.x, pl.z, q)) continue; if (Z.heal) heal(W, pl, pl.mhp * Z.heal * (1 + q.healUp)); if (q.ally) { pl.bf.za = 0.7; pl.zaV = q.ally; } }
        } else {
          for (const p of W.ps) { if (p.st === 'ko' || !inEll(p.x, p.z, q)) continue; hurtPlayer(W, p, null, { down: q.down, lift: q.lift, kb: 120, cx: q.x, soft: !burst, burn: Z.burn }, q.d); }
        }
      }
      if (burst || q.age >= q.warn + q.dur) W.zn.splice(i, 1);
    }
  }

  /* ======================= 동작 실행(플레이어 · 적 공용) ======================= */
  function doAct(W, a, x) {
    if (x.req && !(a.m && a.m[x.req])) return;
    if (x.p2 && !a.p2) return;
    switch (x.k) {
      case 'hit': hitBox(W, a, x); break;
      case 'proj': fire(W, a, x); break;
      case 'zone': {
        const isP = !a.isE;
        if (x.all) { for (const p of W.ps) { if (p.st === 'ko') continue; if (x.one && rnd(W) < 0.5) continue; addZone(W, x.z, clamp(p.x + (x.jit ? (rnd(W) - 0.5) * 2 * x.jit : 0), W.bx0 + 10, W.bx1 - 10), clamp(p.z + (x.jit ? (rnd(W) - 0.5) * x.jit : 0), 2, ZD - 2), 1, -1, a, a.atk * ZN[x.z].d, null); } break; }
        let px, pz;
        if (x.self) { px = a.x - (x.back ? a.bkx || 0 : 0); pz = a.z - (x.back ? a.bkz || 0 : 0); }
        else if (x.toward) { const t = W.ps[a.tg]; const dz = t ? clamp((t.z - a.z) / Math.max(60, abs(t.x - a.x)), -0.5, 0.5) : 0; px = a.x + a.face * x.dx; pz = clamp(a.z + dz * x.dx, 4, ZD - 4); }
        else if (x.tgt) { const t = tgtPoint(W, a, x); px = t.x; pz = t.z; }
        else { px = a.x + a.face * (x.dx || 0); pz = a.z; }
        const ov = (x.warn != null || x.rx) ? { warn: a.leapAt === x.at ? a.leapT : x.warn, rx: x.rx, rz: x.rz, down: x.down } : (a.leapAt === x.at ? { warn: a.leapT } : null);
        const z = addZone(W, x.z, clamp(px, W.bx0 + 6, W.bx1 - 6), pz, isP ? 0 : 1, isP ? a.s : -1, a, isP ? (x.d != null ? x.d : null) : a.atk * (x.d != null ? x.d : ZN[x.z].d), isP ? ctxOf(a, x) : null, ov);
        void z; break;
      }
      case 'dash': {
        let dx = a.face, dz = 0;
        if (x.dir && !a.isE) { if (a.ddx || a.ddz) { dx = a.ddx; dz = a.ddz; } else if (x.back) dx = -a.face; }
        a.dvx = dx * x.v; a.dvz = dz * x.v * 0.62; a.dtm = x.t; break;
      }
      case 'leap': {
        if (x.tgt) { const t = tgtPoint(W, a, x), T = 2 * x.vy / GR; a.vy = x.vy; a.y = Math.max(a.y, 1); a.dvx = (t.x - a.x) / T; a.dvz = (t.z - a.z) / T; a.dtm = T; a.leapAt = x.at; a.leapT = T; a.fall = 1; }
        else { a.vy = x.vy; a.y = Math.max(a.y, 1); a.dvx = a.face * x.v; a.dvz = 0; a.dtm = 2 * x.vy / GR; a.fall = 1; }
        break;
      }
      case 'grab': {
        let best = null, bd = 1e9;
        for (const e of W.es) { if (e.dead || e.st === 'held') continue; const dx = (e.x - a.x) * a.face; if (dx < -10 || dx > x.x1 + e.w || abs(e.z - a.z) > x.zr + e.w * 0.4) continue; if (dx < bd) { bd = dx; best = e; } }
        a.slamSkip = 0;
        if (!best) break;
        const K = EN[best.k], c = { kind: 's', si: 1, grab: 1 };
        if (K.heavy || K.boss || K.stat || best.pmax > 0) { hitEnemy(W, a, best, { kb: 60, hs: 6, poise: 4.5, hv: 1 }, x.d * 1.1, c); a.hs = Math.max(a.hs, 5); ev(W, 'shk', a.x, a.z, 0, 2, a.s); }
        else { releaseHeld(W, best); best.st = 'held'; best.held = a.s; best.mv = null; best.t = x.hold + 0.1; a.grabE = best.id; a.grabD = x.d; a.slamSkip = best.id; }
        a.combo++; a.cbt = 2.6;
        break;
      }
      case 'blink': {
        if (a.isE) { const t = W.ps[a.tg]; const dir = t ? (t.x < (W.bx0 + W.bx1) / 2 ? 1 : -1) : -a.face; a.x = clamp((t ? t.x : a.x) + dir * x.dist, W.bx0 + 40, W.bx1 - 40); a.z = 10 + rnd(W) * (ZD - 20); a.ox = a.x; a.oz = a.z; a.tpN = (a.tpN || 0) + 1; ev(W, 'bk2', a.x, a.z, 0, 0, 0); break; }
        let dx = a.ddx, dz = a.ddz; if (!dx && !dz) dx = a.face;
        a.bkx = dx * x.dist; a.bkz = dz * x.dist * 0.62;
        ev(W, 'bk2', a.x, a.z, 0, 0, 0);
        a.x = clamp(a.x + a.bkx, W.bx0 + 14, W.bx1 - 14); a.z = clamp(a.z + a.bkz, 0, ZD); a.tpN = (a.tpN || 0) + 1;
        ev(W, 'bk2', a.x, a.z, 0, 1, 0);
        break;
      }
      case 'summon': {
        const k = EI[x.e]; let cnt = 0; for (const e of W.es) if (!e.dead && e.par === a.id) cnt++;
        for (let i = 0; i < x.n && cnt < x.cap; i++, cnt++) { const c = spawnEnemy(W, k, clamp(a.x + (rnd(W) - 0.5) * 160, W.bx0 + 30, W.bx1 - 30), 8 + rnd(W) * (ZD - 16), { in: true, par: a.id }); c.st = 'up'; c.t = 0.6; ev(W, 'sum', c.x, c.z, 0, 0, 0); }
        break;
      }
      case 'turn': { const t = W.ps[a.tg]; if (t) a.face = sgn(t.x - a.x) || a.face; break; }
      case 'die': a.selfKill = 1; killEnemy(W, a, null); break;
    }
  }
  function runMove(W, a, dt) {
    const mv = a.mv; a.mt += dt * a.msp;
    while (a.mv === mv && a.ai < mv.acts.length && mv.acts[a.ai].at <= a.mt) { const x = mv.acts[a.ai++]; doAct(W, a, x); if (a.dead) return; }
    if (a.mv !== mv) return;
    for (let i = 0; i < a.ai; i++) { const x = mv.acts[i]; if (x.to && a.mt <= x.to && x.k === 'hit') hitBox(W, a, x); }
    if (a.dtm > 0) { a.dtm -= dt; a.vx = a.dvx; a.vz = a.dvz; if (a.dtm <= 0 && a.y <= 0) { a.vx *= 0.25; a.vz = 0; } }
    else if (mv.mvv && a.mt >= mv.mvv[0] && a.mt < mv.mvv[1]) { a.vx = a.face * mv.mvv[2]; a.vz = 0; }
    else if (a.y <= 0) { a.vx *= 0.8; a.vz *= 0.8; }
  }
  function phys(W, a, dt, bound) {
    let landed = false;
    if (!a.nog && (a.y > 0 || a.vy > 0)) { a.vy -= GR * dt; a.y += a.vy * dt; if (a.y <= 0) { a.y = 0; a.vy = 0; landed = true; } }
    a.x += a.vx * dt; a.z += a.vz * dt;
    if (a.z < 0) a.z = 0; else if (a.z > ZD) a.z = ZD;
    if (bound) { const lo = W.bx0 + a.w, hi = W.bx1 - a.w; if (a.x < lo) a.x = lo; else if (a.x > hi) a.x = hi; }
    return landed;
  }

  /* ======================= 플레이어 ======================= */
  function startPMove(W, p, mv, inp, slot) {
    const m = p.m;
    let mx = inp ? inp.mx : 0, mz = inp ? inp.mz : 0;
    if (mv.kind !== 'e') {
      const C = CLS[p.cls], rg = C.rng ? C.reach + 40 : C.reach + 70;
      const e = aimTarget(W, p, rg, C.rng ? 40 : 52, abs(mx) > 0.5 ? mx : 0);
      if (e) { p.face = sgn(e.x - p.x) || p.face; p.az = e.z; p.azT = C.rng ? 0.1 : 0.2; } else { if (abs(mx) > 0.3) p.face = sgn(mx); p.azT = 0; }
    } else {
      const l = Math.hypot(mx, mz); if (l > 0.3) { p.ddx = mx / l; p.ddz = mz / l; if (!mv.guard && abs(mx) > 0.3) p.face = sgn(mx) * (mv.acts[0] && mv.acts[0].back ? -1 : 1); } else { p.ddx = 0; p.ddz = 0; }
      if (mv.acts[0] && mv.acts[0].back && l <= 0.3) { /* 뒤로 */ }
      if (mv.guard) { const e = aimTarget(W, p, 200, 60, 0); if (e) p.face = sgn(e.x - p.x) || p.face; }
      ev(W, 'dg', p.x, p.z, 0, p.s, p.cls);
      if (m.stepBuff) p.bf.sb = 1.2; if (m.hopBuff) p.bf.hb = 4; if (m.rollCd) for (let i = 0; i < 3; i++) p.cd[i] = Math.max(0, p.cd[i] - m.rollCd);
    }
    p.st = 'act'; p.mv = mv; p.mt = 0; p.ai = 0; p.hset = null; p.dtm = 0; p.tp = null; p.tpAt = -1; p.leapAt = -1; p.buf = 0; p.bt = 0;
    let ext = 0; if (mv.ext) for (const k in mv.ext) if (m[k]) ext += mv.ext[k];
    p.dur = mv.dur + ext;
    let sp = 1;
    if (mv.kind === 'b') sp = 1 + (m.aspd || 0) + (m.baspd || 0) + (p.bf.kh ? m.killHaste || 0 : 0) + (m.rage && p.combo >= 20 ? m.rage : 0);
    else if (mv.kind === 's') sp = 1 + (m.aspd || 0) * 0.5;
    if (p.ch > 0) sp *= 0.75;
    p.msp = sp;
    if (mv.kind === 's') { p.cd[slot] = rnd(W) < (m.freeCast || 0) ? 0.4 : mv.cd * (1 - Math.min(0.6, (m.cdr || 0) + (m['sk' + slot + 'c'] || 0))); if (slot === 0 && p.bf.hb && p.cls === 4) p.hbUse = 1; }
    else if (mv.kind === 'e') p.ecd = mv.cd * (1 - Math.min(0.6, m.ecd || 0));
    ev(W, 'sw', p.x, p.z, 0, mv.i, p.s);
  }
  function endPMove(p) {
    const mv = p.mv; p.st = 'idle'; p.mv = null; p.dtm = 0;
    if (mv && mv.kind === 'b') { p.ci = (mv.ci + 1) % CLS[p.cls].basic.length; p.ct = 0.5; }
    if (p.ctrUse) { delete p.bf.ctr; p.ctrUse = 0; }
    if (p.hbUse) { delete p.bf.hb; p.hbUse = 0; }
    if (p.grabE) p.grabE = 0;
  }
  function tryAct(W, p, inp) {
    const C = CLS[p.cls];
    if (p.buf === 8) { if (p.ecd <= 0) { startPMove(W, p, C.ev, inp, -1); return true; } }
    else if (p.buf) { const i = p.buf === 1 ? 0 : p.buf === 2 ? 1 : 2; if (p.cd[i] <= 0) { startPMove(W, p, C.sk[i], inp, i); return true; } }
    else if (inp && inp.a) { startPMove(W, p, C.basic[p.ci], inp, -1); return true; }
    return false;
  }
  function stepPlayer(W, p, inp, dt) {
    p.ox = p.x; p.oz = p.z; p.oy = p.y;
    if (p.hs > 0) { p.hs--; return; }
    for (let i = 0; i < 3; i++) if (p.cd[i] > 0) p.cd[i] = Math.max(0, p.cd[i] - dt);
    if (p.ecd > 0) p.ecd = Math.max(0, p.ecd - dt);
    if (p.inv > 0) p.inv -= dt;
    for (const k in p.bf) { p.bf[k] -= dt; if (p.bf[k] <= 0) delete p.bf[k]; }
    if (p.cbt > 0) { p.cbt -= dt; if (p.cbt <= 0) p.combo = 0; }
    if (p.ch > 0) p.ch -= dt;
    if (p.bu > 0) { p.bu -= dt; if (W.tick % 30 === 0 && p.st !== 'ko') { p.hp -= 2; ev(W, 'pd', p.x, p.z, 44, 2, p.s); if (p.hp <= 0) ko(W, p); } }
    const C = CLS[p.cls], m = p.m;
    if (p.st === 'ko') {
      p.mvn = 0;
      if (p.auto > 0) { p.auto -= dt; if (p.auto <= 0) revive(W, p, 0.5); return; }
      let near = null; for (const q of W.ps) if (q !== p && q.st !== 'ko' && abs(q.x - p.x) < 58 && abs(q.z - p.z) < 34) { near = q; break; }
      if (near) { p.rev += dt * (1 + (near.m.revive || 0)) / 2.4; if (p.rev >= 1) { revive(W, p, 0.4); near.stt.r++; if (near.m.reviveHeal) { heal(W, near, near.mhp * near.m.reviveHeal); heal(W, p, p.mhp * near.m.reviveHeal); } } }
      else p.rev = Math.max(0, p.rev - dt * 0.15);
      return;
    }
    const k = inp ? inp.k : 0;
    if (k) { p.buf = k & 8 ? 8 : k & 1 ? 1 : k & 2 ? 2 : 4; p.bt = 0.3; } else if (p.bt > 0) { p.bt -= dt; if (p.bt <= 0) p.buf = 0; }
    switch (p.st) {
      case 'idle': {
        const sp = C.spd * (1 + (m.move || 0)) * (p.ch > 0 ? 0.6 : 1);
        const mx = inp ? inp.mx : 0, mz = inp ? inp.mz : 0;
        if (p.rem) { const dx = p.rx - p.x, dz = p.rz - p.z; if (abs(dx) > 90 || abs(dz) > 60) { /* 너무 멀면 무시 */ p.vx = p.vz = 0; } else { p.vx = clamp(dx * 14, -sp * 1.6, sp * 1.6); p.vz = clamp(dz * 14, -sp, sp); } p.mvn = abs(mx) + abs(mz) > 0.15 ? 1 : 0; }
        else { p.vx = mx * sp; p.vz = mz * sp * 0.62; p.mvn = abs(mx) + abs(mz) > 0.15 ? 1 : 0; }
        if (abs(mx) > 0.2) p.face = sgn(mx);
        if (p.ct > 0) { p.ct -= dt; if (p.ct <= 0) p.ci = 0; }
        phys(W, p, dt, true);
        tryAct(W, p, inp);
        break;
      }
      case 'act': {
        const mv = p.mv;
        if (p.azT > 0) { p.azT -= dt; p.z += clamp(p.az - p.z, -90 * dt, 90 * dt); }
        if (p.grabE) { const e = W.es.find((q) => q.id === p.grabE); if (e && !e.dead && e.st === 'held') { e.x = p.x + p.face * 26; e.z = p.z; e.y = 26; if (p.mt >= 0.48) { e.st = 'air'; e.held = -1; e.y = 6; e.vy = 0; p.grabE = 0; hitEnemy(W, p, e, { kb: 120, down: 1, hs: 5, otg: 1, hv: 1 }, p.grabD, { kind: 's', si: 1, grab: 1 }); if (!e.dead) e.vy = -260; if (m.grabBuff) p.bf.gb = 4; } } else p.grabE = 0; }
        runMove(W, p, dt);
        if (p.st !== 'act' || p.mv !== mv) break;
        phys(W, p, dt, true);
        if (p.buf === 8 && p.ecd <= 0 && mv.kind !== 'e' && !p.grabE) { p.dtm = 0; startPMove(W, p, C.ev, inp, -1); break; }
        if (p.mt >= mv.can && p.y <= 0) {
          if (p.buf && p.buf < 8) { const i = p.buf === 1 ? 0 : p.buf === 2 ? 1 : 2; if (p.cd[i] <= 0 && C.sk[i] !== mv) { if (mv.kind === 'b') p.ci = 0; p.dtm = 0; startPMove(W, p, C.sk[i], inp, i); break; } }
          if (mv.kind === 'b' && inp && inp.a && mv.ci + 1 < C.basic.length) { startPMove(W, p, C.basic[mv.ci + 1], inp, -1); break; }
          if (mv.kind !== 'b' && inp && inp.a && p.mt >= Math.min(p.dur, mv.can + 0.06)) { p.ci = 0; startPMove(W, p, C.basic[0], inp, -1); break; }
        }
        if (p.mt >= p.dur && p.y <= 0) endPMove(p);
        break;
      }
      case 'hit':
        p.t -= dt; if (p.pull > 0) p.pull -= dt; else { p.vx *= 0.86; p.vz *= 0.8; }
        phys(W, p, dt, true); p.mvn = 0;
        if (p.t <= 0) { p.st = 'idle'; p.vx = p.vz = 0; }
        break;
      case 'air': if (phys(W, p, dt, true)) { p.st = 'down'; p.t = 0.45; p.vx *= 0.3; } break;
      case 'down': p.t -= dt; p.vx *= 0.85; phys(W, p, dt, true); if (p.t <= 0 || (k && p.t < 0.3)) { p.st = 'up'; p.t = 0.22; p.inv = Math.max(p.inv, 0.9); } break;
      case 'up': p.t -= dt; p.vx = p.vz = 0; if (p.t <= 0) p.st = 'idle'; break;
    }
  }

  /* ======================= 적 ======================= */
  function startEMove(W, e, idx) {
    const K = EN[e.k], mv = K.mv[idx];
    e.st = 'act'; e.mv = mv; e.mi = idx; e.mt = 0; e.ai = 0; e.hset = null; e.pm = -1; e.dtm = 0; e.tp = null; e.tpAt = -1; e.leapAt = -1; e.mvn = 0;
    e.c[idx] = mv.cd * (0.85 + rnd(W) * 0.3) * (e.p2 ? 0.8 : 1);
    e.msp = (e.hst > 0 ? 1.25 : 1) * (e.p2 ? 1.15 : 1) * (e.ch > 0 ? 0.6 : 1);
    ev(W, 'tl', e.x, e.z, 0, e.id, K.boss ? 1 : 0);
  }
  function stepEnemy(W, e, dt) {
    e.ox = e.x; e.oz = e.z; e.oy = e.y;
    if (e.hs > 0) { e.hs--; return; }
    const K = EN[e.k]; e.age += dt;
    if (e.gcd > 0) e.gcd -= dt; if (e.inv > 0) e.inv -= dt;
    for (let i = 0; i < e.c.length; i++) if (e.c[i] > 0) e.c[i] -= dt;
    if (e.blt > 0) { e.blt -= dt; if (e.blt <= 0) e.bl = 0; } if (e.bu > 0) e.bu -= dt; if (e.ch > 0) e.ch -= dt; if (e.mk > 0) e.mk -= dt; if (e.sk > 0) e.sk -= dt; if (e.hst > 0) e.hst -= dt;
    if (K.boss && !e.p2 && e.hp < e.mhp * 0.5) { e.p2 = true; ev(W, 'p2', e.x, e.z, 0, e.id, 0); }
    if (!e.in && e.x > W.bx0 + e.w + 4 && e.x < W.bx1 - e.w - 4) e.in = true;
    e.nog = !!K.fly && (e.st === 'idle' || e.st === 'hit' || (e.st === 'act' && !e.fall));
    switch (e.st) {
      case 'idle': {
        e.tk -= dt; let t = W.ps[e.tg];
        if (e.tk <= 0 || !t || t.st === 'ko') { e.tk = 0.6 + rnd(W) * 0.6; let bs = 1e9; e.tg = -1; for (const p of W.ps) { if (p.st === 'ko') continue; const s = (abs(p.x - e.x) + abs(p.z - e.z) * 1.5) * (0.8 + rnd(W) * 0.4) - (p.s === e.tg ? 40 : 0); if (s < bs) { bs = s; e.tg = p.s; } } t = W.ps[e.tg]; }
        if (K.fly && e.y < K.fly) { e.y = Math.min(K.fly, e.y + 90 * dt); }
        if (!t) { e.vx = e.vz = 0; e.mvn = 0; break; }
        const dx = t.x - e.x, adx = abs(dx), dz = t.z - e.z;
        if (e.pm < 0 && e.gcd <= 0 && e.in) {
          let tot = 0; const cand = [];
          for (let i = 0; i < K.mv.length; i++) { const mv = K.mv[i]; if (e.c[i] > 0 || (mv.p2 && !e.p2)) continue; let w = mv.w || 1; if (adx >= mv.rng[0] && adx <= mv.rng[1]) w *= 2.5; cand.push([i, w]); tot += w; }
          if (cand.length) { let r = rnd(W) * tot, j = 0; for (; j < cand.length - 1; j++) { r -= cand[j][1]; if (r <= 0) break; } e.pm = cand[j][0]; e.pmT = 0; } else e.gcd = 0.3;
        }
        const sp = K.spd * (e.ch > 0 ? 0.6 : 1) * (e.hst > 0 ? 1.25 : 1) * (e.p2 ? 1.12 : 1) * (e.in ? 1 : 1.3);
        let wx = e.x, wz = e.z;
        if (e.pm >= 0) {
          const mv = K.mv[e.pm]; e.pmT += dt;
          const inR = adx >= mv.rng[0] && adx <= mv.rng[1] && (mv.zr >= 100 || abs(dz) <= mv.zr * 0.75);
          const melee = mv.rng[1] <= 150 && !K.boss;
          if (inR && e.in && (!melee || W.actM < W.tokM) && (melee || K.boss || W.actR < W.tokR)) { e.face = sgn(dx) || e.face; if (melee) W.actM++; else if (!K.boss) W.actR++; e.vx = e.vz = 0; startEMove(W, e, e.pm); break; }
          if (e.pmT > 5) { e.pm = -1; e.gcd = 0.2; }
          const wd = clamp(adx, mv.rng[0] + 10, Math.max(mv.rng[0] + 12, mv.rng[1] - 14)); wx = t.x - sgn(dx) * (K.keep && mv.rng[1] > 150 ? clamp(K.keep, mv.rng[0] + 10, mv.rng[1] - 14) : Math.min(wd, (mv.rng[0] + mv.rng[1]) * 0.6));
          wz = mv.zr >= 100 ? e.z + (K.keep ? clamp(dz, -30, 30) : 0) : t.z;
        } else {
          const hold = K.keep || 84 + (e.id % 3) * 28;
          wx = t.x - sgn(dx || -e.face) * hold; wz = clamp(t.z + ((e.id % 5) - 2) * 15, 4, ZD - 4);
        }
        if (K.keep && adx < K.keep * 0.5) { wx = e.x - sgn(dx) * 60; }
        if (!e.in) { wx = (W.bx0t + W.bx1) / 2; wz = e.z; }
        wx = clamp(wx, W.bx0t + e.w + 8, W.bx1 - e.w - 8);
        const ddx = wx - e.x, ddz = wz - e.z;
        if (K.stat) { e.vx = e.vz = 0; e.mvn = 0; }
        else { e.vx = abs(ddx) > 5 ? sgn(ddx) * sp : 0; e.vz = abs(ddz) > 4 ? sgn(ddz) * sp * 0.6 : 0; e.mvn = e.vx || e.vz ? 1 : 0; }
        e.face = sgn(dx) || e.face;
        phys(W, e, dt, e.in);
        break;
      }
      case 'act': {
        const mv = e.mv; runMove(W, e, dt);
        if (e.dead || e.st !== 'act' || e.mv !== mv) break;
        phys(W, e, dt, e.in);
        if (K.fly && !e.fall && e.y < K.fly) e.y = Math.min(K.fly, e.y + 90 * dt);
        if (e.mt >= mv.dur && (e.y <= 0 || K.fly)) { e.st = 'idle'; e.mv = null; e.dtm = 0; e.fall = 0; e.vx = e.vz = 0; e.gcd = (K.boss ? 0.85 : 0.6 + rnd(W) * 0.7) * (e.p2 ? 0.7 : 1); }
        break;
      }
      case 'hit': e.t -= dt; e.vx *= 0.86; e.vz *= 0.8; e.mvn = 0; if (K.fly && e.y > 0) { /* 떠 있는 채 경직 */ } phys(W, e, dt, e.in); if (K.fly && e.y < K.fly * 0.6) e.y = Math.min(K.fly, e.y + 60 * dt); if (e.t <= 0) { e.st = 'idle'; e.vx = 0; } break;
      case 'air':
        if (phys(W, e, dt, e.in)) {
          e.st = 'down'; e.t = 0.75; e.vx *= 0.3; e.fall = 0;
          if (e.lb >= 0) { const p = W.ps[e.lb]; if (p && p.m.landBoom && e.jug > 0) areaProc(W, p, e.x, e.z, 58, CLS[p.cls].atk * p.m.landBoom, e.id, 4); }
          ev(W, 'ld', e.x, e.z, 0, 0, 0);
        }
        break;
      case 'down': e.t -= dt; e.vx *= 0.85; phys(W, e, dt, e.in); if (e.t <= 0) { e.st = 'up'; e.t = 0.3; e.jug = 0; e.inv = 0.25; } break;
      case 'up': e.t -= dt; e.vx = e.vz = 0; if (e.t <= 0) { e.st = 'idle'; e.gcd = Math.max(e.gcd, 0.3); } break;
      case 'stag': e.t -= dt; e.vx *= 0.8; e.vz = 0; if (e.y > 0 || e.vy > 0) phys(W, e, dt, e.in); if (e.t <= 0) { e.st = 'idle'; e.poise = e.pmax; e.gcd = 0.4; } break;
      case 'held': e.t -= dt; if (e.t <= 0) { e.st = 'air'; e.held = -1; e.vy = 0; } break;
    }
  }
  function separate(W) {
    const es = W.es;
    for (let i = 0; i < es.length; i++) {
      const a = es[i]; if (a.dead || a.st !== 'idle' || EN[a.k].stat) continue;
      for (let j = i + 1; j < es.length; j++) {
        const b = es[j]; if (b.dead || b.st !== 'idle') continue;
        const dx = b.x - a.x, dz = (b.z - a.z) * 1.8, r = (a.w + b.w) * 0.9, d2 = dx * dx + dz * dz;
        if (d2 < r * r && d2 > 0.01) { const d = Math.sqrt(d2), k = (r - d) / d * 0.12; a.x -= dx * k; a.z -= dz * k / 1.8; if (!EN[b.k].stat) { b.x += dx * k; b.z += dz * k / 1.8; } }
        else if (d2 <= 0.01) { a.z -= 0.5; b.z += 0.5; }
      }
      if (a.z < 0) a.z = 0; else if (a.z > ZD) a.z = ZD;
    }
  }

  /* ======================= 봇(AI 동료) =======================
     고정 규칙이 아니라 상황 점수 + 판 시드 버릇(hab: 공세 · 신중함 · 동료 챙기기 · 기술 애호). lv에 따라 반응 간격 · 피할 확률 · 기술 문턱. */
  function threat(W, p) {
    let best = null;
    const put = (t, ax, az, key, src) => { if (!best || t < best.t) best = { t, ax, az, key, src }; };
    for (const q of W.zn) {
      if (q.own !== 1 && q.own !== 2) continue;
      const a = (p.x - q.x) / (q.rx + 16), b = (p.z - q.z) / (q.rz + 10); if (a * a + b * b > 1) continue;
      const t = q.on ? 0.1 : q.warn - q.age; if (t > 1.0) continue;
      const ex = (p.x - q.x) / q.rx, ez = (p.z - q.z) / q.rz;
      if (abs(ex) * q.rx > abs(ez) * q.rz * 1.2 || q.rz > 46) put(t, sgn(p.x - q.x) || 1, ez * 0.4, 'z' + q.id, null); else put(t, ex * 0.4, sgn(p.z - q.z) || (p.z < ZD / 2 ? 1 : -1), 'z' + q.id, null);
    }
    for (const e of W.es) {
      if (e.dead || e.st !== 'act' || !e.mv) continue; const mv = e.mv;
      for (let i = 0; i < mv.acts.length; i++) {
        const x = mv.acts[i]; let t = (x.at - e.mt) / (e.msp || 1); if (t > 0.65) break;
        if (i < e.ai) { if (x.k === 'hit' && x.to && e.mt <= x.to) t = 0.05; else continue; }
        if (x.k === 'hit') {
          let x0 = e.x + e.face * x.x0, x1 = e.x + e.face * x.x1; if (x.to) { const ds = mv.acts.find((q) => q.k === 'dash'); if (ds) x1 += e.face * ds.v * ds.t; } if (x0 > x1) { const q = x0; x0 = x1; x1 = q; }
          if (p.x < x0 - 22 || p.x > x1 + 22 || abs(p.z - e.z) > x.zr + 16) continue;
          if (x.zr <= 30) put(t, 0, sgn(p.z - e.z) || (p.z < ZD / 2 ? 1 : -1), 'e' + e.id + '_' + e.mi + '_' + i, e); else put(t, sgn(p.x - e.x) || 1, 0, 'e' + e.id + '_' + e.mi + '_' + i, e);
        } else if (x.k === 'proj' && !PJ[x.p].lob) { if (sgn(p.x - e.x) === e.face && abs(p.z - e.z) < PJ[x.p].zr + 18 + (x.fan ? 20 : 0)) put(t + abs(p.x - e.x) / PJ[x.p].spd, 0, sgn(p.z - e.z) || (p.z < ZD / 2 ? 1 : -1), 'e' + e.id + '_' + e.mi + '_' + i, e); }
      }
    }
    for (const q of W.pj) {
      if (q.own !== 1 || PJ[q.k].lob) continue; const dx = p.x - q.x; if (sgn(dx) !== sgn(q.vx)) continue;
      const t = abs(dx) / abs(q.vx); if (t > 0.45) continue; const zz = q.z + q.vz * t;
      if (abs(p.z - zz) < PJ[q.k].zr + 16) put(t, 0, sgn(p.z - zz) || (p.z < ZD / 2 ? 1 : -1), 'j' + q.id, { x: q.x, isP: 1 });
    }
    return best;
  }
  function botInput(W, p, dt) {
    const b = p.bot, o = b.o, C = CLS[p.cls], lv = p.lv || 2, hab = b.hab;
    o.k = 0;
    if (p.st === 'ko') { o.mx = o.mz = 0; o.a = 0; return o; }
    b.tk -= dt; if (b.tk > 0) return o;
    b.tk = [0, 0.3, 0.18, 0.1][lv] + rnd(W) * 0.05;
    o.mx = 0; o.mz = 0; o.a = 0;
    const go = (tx, tz, tol) => { const dx = tx - p.x, dz = tz - p.z; o.mx = abs(dx) > (tol || 8) ? sgn(dx) : 0; o.mz = abs(dz) > (tol || 8) * 0.6 ? sgn(dz) : 0; return abs(dx) <= (tol || 8) && abs(dz) <= (tol || 8); };
    /* 위험: 예고를 본 것마다 한 번만 피할지 정함 */
    const th = threat(W, p);
    if (th) {
      let dec = b.seen[th.key];
      if (dec == null) { if (b.sn++ > 60) { b.seen = {}; b.sn = 0; } dec = b.seen[th.key] = rnd(W) < [0, 0.3, 0.62, 0.9][lv] * (0.75 + hab.caut * 0.3) ? 1 : 0; }
      if (dec) {
        const edge = (th.az > 0 && p.z > ZD - 8) || (th.az < 0 && p.z < 8);
        let ax = th.ax, az = edge ? -th.az : th.az; if (!ax && edge) ax = p.x < (W.bx0 + W.bx1) / 2 ? 1 : -1;
        o.mx = ax; o.mz = az;
        const canEv = p.ecd <= 0 && (p.st === 'idle' || p.st === 'act');
        if (canEv && C.ev.guard) { if (th.t < 0.17) { o.k = 8; return o; } }
        else if (canEv && th.t < 0.3 && lv >= 2) { o.k = 8; return o; }
        if (th.t < 0.5) return o;
      }
    }
    const adv = W.ph === 'go' || W.ph === 'clear' || W.ph === 'start';
    /* 쓰러진 동료 */
    let down = null, dd = 1e9; for (const q of W.ps) if (q !== p && q.st === 'ko' && q.auto <= 0) { const d = abs(q.x - p.x) + abs(q.z - p.z); if (d < dd) { dd = d; down = q; } }
    let near = null, nd = 1e9, cnt = 0; for (const e of W.es) { if (e.dead) continue; cnt++; const d = abs(e.x - p.x) + abs(e.z - p.z) * 1.6; if (d < nd) { nd = d; near = e; } }
    if (down && lv >= 2 && (adv || !near || hab.team * 1.3 + (dd < 200 ? 0.4 : 0) - (p.hp < p.mhp * 0.3 ? 0.5 : 0) > 0.75)) { go(down.x + (p.s % 2 ? 20 : -20), down.z, 14); if (near && nd < C.reach * 0.8 && !C.rng) o.a = 1; return o; }
    /* 회복 구슬 */
    if (W.orb.length && p.hp < p.mhp * (0.45 + hab.caut * 0.3)) { let ob = null, od = 520; for (const q of W.orb) { const d = abs(q.x - p.x) + abs(q.z - p.z); if (d < od) { od = d; ob = q; } } if (ob && (adv || od < 240)) { go(ob.x, ob.z, 6); return o; } }
    if (!near) { if (W.ph === 'go') { o.mx = 1; o.mz = abs(ZD / 2 + hab.lane + (p.s - 1.5) * 16 - p.z) > 8 ? sgn(ZD / 2 + hab.lane + (p.s - 1.5) * 16 - p.z) : 0; } return o; }
    /* 대상 고르기 */
    let tg = null, ts = -1e9;
    for (const e of W.es) {
      if (e.dead) continue; const K = EN[e.k], dx = abs(e.x - p.x), dz = abs(e.z - p.z);
      let s = -(dx + dz * 1.8) * 0.01;
      if (e.id === b.tg) s += 0.5; if (K.keep) s += 0.25 + (C.rng ? 0.3 : hab.aggr * 0.3); if (K.aura || K.mv.some((q) => q.acts.some((y) => y.k === 'summon'))) s += 0.4;
      if (K.boomOnDeath) s += C.rng ? 0.8 : -0.4; if (e.hp < e.mhp * 0.3) s += 0.3; if (e.st === 'stag') s += 0.5; if (e.y > 2 && e.st === 'air') s += 0.35 * lv / 3;
      if (K.boss) s += 0.2; if (K.guard && e.gp > 0 && !C.rng) s -= 0.15; if (!e.in) s -= 0.6;
      if (s > ts) { ts = s; tg = e; }
    }
    b.tg = tg.id; const K = EN[tg.k];
    const dx = tg.x - p.x, adx = abs(dx), dz = tg.z - p.z, adz = abs(dz);
    /* 기술 */
    if (lv >= 1 && (p.st === 'idle' || (p.st === 'act' && p.mv && p.mt >= p.mv.can)) && b.wait <= W.t) {
      let bi = -1, bsc = [0, 2.2, 1.7, 1.35][lv];
      for (let i = 0; i < 3; i++) {
        if (p.cd[i] > 0 || (lv === 1 && i === 2)) continue; const mv = C.sk[i], h = mv.bot || {}; let sc = (h.pr || 1) + hab.sk * 0.35 + rnd(W) * 0.3;
        if (h.heal) { let need = 0; for (const q of W.ps) if (q.st !== 'ko' && q.hp < q.mhp * 0.6 && abs(q.x - p.x) < 90 && abs(q.z - p.z) < 46) need++; if (!need) continue; sc += need * 0.4; }
        else if (h.esc) { if (nd > 100) continue; sc += 0.3 + (p.hp < p.mhp * 0.5 ? 0.3 : 0); }
        else {
          let n = 0, gr = 0; const r0 = h.r[0], r1 = h.r[1];
          for (const e of W.es) { if (e.dead || !e.in) continue; const ex = abs(e.x - (r0 < 0 ? p.x : tg.x)) , ez = abs(e.z - (h.zr > 50 ? tg.z : p.z)); const ddx = abs(e.x - p.x); if (r0 < 0 ? (ddx <= r1 && abs(e.z - p.z) <= h.zr) : (ddx >= r0 && ddx <= r1 && (h.zr > 50 ? ex < 80 && ez < 46 : abs(e.z - p.z) <= h.zr && sgn(e.x - p.x) === sgn(dx)))) { n++; if (!EN[e.k].heavy && e.y <= 2 && e.st !== 'down') gr++; } }
          if (n < (h.n || 1)) continue; if (h.gr && !gr) sc -= 0.5; sc += Math.min(3, n) * 0.25;
          if (K.boss || tg.el) sc += 0.2;
        }
        if (sc > bsc) { bsc = sc; bi = i; }
      }
      if (bi >= 0) { o.k = 1 << bi; b.wait = W.t + 0.35; o.mx = sgn(dx) * 0.4; return o; }
    }
    /* 자리 잡기 */
    if (C.rng) {
      const lo = 150 - hab.aggr * 30, hi = 250;
      if (adx < 105 && nd < 120) { const room = dx > 0 ? p.x - W.bx0 : W.bx1 - p.x; if (room > 70) { o.mx = -sgn(dx); o.mz = adz < 20 ? (p.z < ZD / 2 ? 1 : -1) * 0.6 : 0; if (lv >= 2 && p.ecd <= 0 && nd < 70 && rnd(W) < 0.5) o.k = 8; } else { o.mz = p.z < ZD / 2 ? 1 : -1; o.mx = sgn(dx) * -0.3; } if (adz < 14 && adx < C.reach) o.a = 1; return o; }
      if (adz > 10) o.mz = sgn(dz);
      if (adx > hi) o.mx = sgn(dx); else if (adx < lo) o.mx = -sgn(dx) * 0.6;
      if (adz <= 14 && adx <= C.reach + 10) { o.a = 1; if (p.face !== sgn(dx) && p.st === 'idle') o.mx = sgn(dx) * 0.3; }
    } else {
      /* 방패 든 적은 뒤로 돎 */
      const side = sgn(dx) || 1;
      const want = C.reach * 0.7, tx = tg.x - side * want, zt = tg.z + (K.boss ? 0 : (p.s % 2 ? 3 : -3));
      if (adz > 9) o.mz = sgn(zt - p.z);
      if (abs(tx - p.x) > 12) o.mx = sgn(tx - p.x);
      if (adx <= C.reach * 0.96 + tg.w && adz <= 16) { o.a = 1; if (adx > want * 0.6) o.mx *= 0.3; }
      /* 신중한 봇은 체력이 낮으면 한 박자 물러남 */
      if (p.hp < p.mhp * 0.25 && hab.caut > 0.7 && tg.st === 'act' && adx < 110) { o.mx = -sgn(dx); o.a = 0; }
    }
    /* 예고 안으로 걸어 들어가지 않음 */
    if (lv >= 2 && (o.mx || o.mz)) { const fx = p.x + o.mx * 34, fz = p.z + o.mz * 22; for (const q of W.zn) { if (q.own === 0) continue; const a = (fx - q.x) / (q.rx + 12), c = (fz - q.z) / (q.rz + 8); if (a * a + c * c <= 1 && !inEll(p.x, p.z, q)) { o.mx = 0; o.mz = 0; break; } } }
    return o;
  }

  /* ======================= 한 걸음 ======================= */
  function worldStep(W, dt, inputFn, humanPick) {
    if (W.over) return;
    W.t += dt; W.tick++;
    phase(W, dt, humanPick);
    if (W.over) return;
    const frozen = W.ph === 'aug' || W.ph === 'intro' || W.ph === 'travel';
    if (frozen) { for (const p of W.ps) { p.ox = p.x; p.oz = p.z; p.oy = p.y; p.mvn = 0; } for (const e of W.es) { e.ox = e.x; e.oz = e.z; e.oy = e.y; } for (const q of W.pj) { q.ox = q.x; q.oz = q.z; q.oy = q.y; } return; }
    for (const p of W.ps) { let inp = inputFn ? inputFn(p.s, p) : undefined; if (inp === undefined) inp = p.rem ? p.rin : botInput(W, p, dt); stepPlayer(W, p, inp, dt); if (p.rem && p.rin) p.rin.k = 0; }
    W.actM = 0; W.actR = 0; let aura = null;
    for (const e of W.es) { if (e.dead) continue; if (e.st === 'act' && e.mv && !EN[e.k].boss) { if (e.mv.rng[1] <= 150) W.actM++; else W.actR++; } if (EN[e.k].aura && e.st !== 'down' && e.st !== 'air') (aura || (aura = [])).push(e); }
    W.tokM = 1 + Math.ceil(W.n / 2) + (W.zi > 0 ? 1 : 0) + (W.n >= 3 ? W.n - 2 : 0); W.tokR = 1 + Math.ceil(W.n / 2) + (W.n >= 4 ? 1 : 0);
    if (aura && W.tick % 20 === 0) for (const a of aura) for (const e of W.es) if (!e.dead && e !== a && abs(e.x - a.x) < 200) e.hst = 0.6;
    for (let i = 0; i < W.es.length; i++) { const e = W.es[i]; if (!e.dead) stepEnemy(W, e, dt); }
    separate(W);
    stepProj(W, dt); stepZones(W, dt);
    if (W.tick % 30 === 0) for (const e of W.es) { if (e.dead) continue; if (e.bl > 0) { const o = W.ps[e.own]; dotEnemy(W, e, 1.4 * e.bl * (1 + (o ? o.m.bleedDmg || 0 : 0)), e.own, 1); } if (!e.dead && e.bu > 0) { const o = W.ps[e.bown]; dotEnemy(W, e, 3.5 * (1 + (o ? o.m.burnDmg || 0 : 0)), e.bown != null ? e.bown : -1, 3); } }
    for (let i = W.orb.length - 1; i >= 0; i--) { const q = W.orb[i]; q.t -= dt; let got = q.t <= 0; if (!got) for (const p of W.ps) if (p.st !== 'ko' && p.hp < p.mhp && abs(p.x - q.x) < 26 && abs(p.z - q.z) < 18) { heal(W, p, p.mhp * 0.12 * (1 + (p.m.loot || 0))); ev(W, 'orb', q.x, q.z, 0, p.s, 0); got = true; break; } if (got) W.orb.splice(i, 1); }
    if (W.es.some((e) => e.dead)) W.es = W.es.filter((e) => !e.dead);
    if (W.ph !== 'clear' && W.ph !== 'aug' && W.ps.every((p) => p.st === 'ko' && p.auto <= 0)) finish(W, false);
  }

  /* ======================= 네트워크 ======================= */
  const r1 = (v) => Math.round(v);
  function packHost(W) {
    const o = { q: W.tick, t: Math.round(W.t * 10), ph: [PHI[W.ph], W.zi, W.si, r1(W.pt * 10), r1(W.bx0), r1(W.bx1), W.wave, W.wave + W.wq.length, W.bossId, r1(W.fade * 10), W.ar] };
    o.p = W.ps.map((p) => [r1(p.x), r1(p.z), r1(p.y), p.face, r1(p.hp), p.mhp, r1(p.sh), STI[p.st], p.mv ? p.mv.i : -1, r1(p.mt * 100), r1(p.cd[0] * 10), r1(p.cd[1] * 10), r1(p.cd[2] * 10), r1(p.ecd * 10), p.combo, r1(p.rev * 100), (p.mvn ? 1 : 0) | (p.inv > 0 ? 2 : 0) | (p.bu > 0 ? 4 : 0) | (p.ch > 0 ? 8 : 0) | (p.auto > 0 ? 16 : 0), r1(p.msp * 100), p.tpN || 0, r1(p.stt.d)]);
    o.e = W.es.map((e) => [e.id, e.k, r1(e.x), r1(e.z), r1(e.y), e.face, Math.max(1, Math.ceil(e.hp / e.mhp * 1000)), STI[e.st], e.mv ? e.mi : -1, r1(e.mt * 100), (e.el ? 1 : 0) | (e.bl > 0 ? 2 : 0) | (e.bu > 0 ? 4 : 0) | (e.sk > 0 ? 8 : 0) | (e.ch > 0 ? 16 : 0) | (e.mk > 0 ? 32 : 0) | (e.mvn ? 64 : 0) | (e.p2 ? 128 : 0) | (e.gp > 0 ? 256 : 0), r1((e.msp || 1) * 100), e.pmax ? r1(e.poise / e.pmax * 100) : 0, e.tpN || 0, e.bl]);
    o.j = W.pj.map((q) => (PJ[q.k].lob ? [q.id, PJK.indexOf(q.k), q.own, r1(q.sx), r1(q.sz), r1(q.tx), r1(q.tz), r1(q.t * 100), r1(q.T * 100)] : [q.id, PJK.indexOf(q.k), q.own, r1(q.x), r1(q.z), r1(q.y), r1(q.vx), r1(q.vz)]));
    o.z = W.zn.map((q) => [q.id, ZNK.indexOf(q.k), r1(q.x), r1(q.z), r1(q.rx), r1(q.rz), r1(q.age * 100), r1(q.warn * 100), r1(q.dur * 10), q.own]);
    o.o = W.orb.map((q) => [r1(q.x), r1(q.z)]);
    o.v = W.ev.filter((e) => e[7] > W.tick - 40).map((e) => e.slice(0, 7));
    if (W.ph === 'aug') o.a = { o: W.offers, d: W.pk };
    o.au = W.ps.map((p) => p.al.map((i) => [i, p.aug[i]]));
    if (W.over) o.ov = 1;
    return o;
  }
  function mkGhostE(W, a) { const K = EN[a[1]]; return { id: a[0], k: a[1], isE: true, x: a[2], z: a[3], y: a[4], ox: a[2], oz: a[3], oy: a[4], nx: a[2], nz: a[3], ny: a[4], vx: 0, vz: 0, vy: 0, face: a[5], hp: 1, mhp: 1, hpf: 1, st: 'idle', mv: null, mi: -1, mt: 0, el: 0, w: K.w, bl: 0, bu: 0, sk: 0, ch: 0, mk: 0, mvn: 0, p2: false, gp: 0, pmax: K.pmax, poise: K.pmax, msp: 1, tpN: a[13], dead: false, age: 0, t: 0, jug: 0 }; }
  /* 손님: 호스트 묶음을 받아 세계에 반영. 새 사건 목록을 돌려줌 */
  function applyHost(W, hs, me) {
    const ph = hs.ph, out = [];
    W.t = hs.t / 10; W.ph = PH[ph[0]]; W.zi = ph[1]; W.si = ph[2]; W.pt = ph[3] / 10; W.bx0 = W.bx0t = ph[4]; W.bx1 = ph[5]; W.wave = ph[6]; W.waves = ph[7]; W.bossId = ph[8]; W.fade = ph[9] / 10; W.ar = ph[10];
    hs.p.forEach((a, i) => {
      const p = W.ps[i]; if (!p) return; const st = ST[a[7]], mine = i === me;
      const tp = a[18] !== (p.tpN || 0); p.tpN = a[18];
      p.nx = a[0]; p.nz = a[1]; p.ny = a[2];
      if (tp || (mine && (abs(p.x - a[0]) > 110 || abs(p.z - a[1]) > 70))) { p.x = p.ox = a[0]; p.z = p.oz = a[1]; p.y = p.oy = a[2]; }
      const predicting = mine && p.pred > 0 && st === 'idle';
      if (!predicting) {
        if (!mine || st !== 'idle' || p.st !== 'idle') p.face = a[3];
        const nmv = a[8] >= 0 ? MV[a[8]] : null;
        if (nmv !== p.mv || abs(a[9] / 100 - p.mt) > 0.25 || !mine) { p.mv = nmv; p.mt = a[9] / 100; }
        p.st = st; if (mine && st !== 'idle') p.pred = 0;
      }
      p.hp = a[4]; p.mhp = a[5]; p.sh = a[6]; p.cd[0] = a[10] / 10; p.cd[1] = a[11] / 10; p.cd[2] = a[12] / 10; p.ecd = a[13] / 10; p.combo = a[14]; p.rev = a[15] / 100;
      const f = a[16]; if (!mine || st !== 'idle') p.mvn = f & 1; p.inv = f & 2 ? 0.2 : 0; p.bu = f & 4 ? 1 : 0; p.ch = f & 8 ? 1 : 0; p.auto = f & 16 ? 1 : 0; p.msp = a[17] / 100; p.stt.d = a[19];
    });
    const seen = {};
    for (const a of hs.e) {
      seen[a[0]] = 1; let e = W.em[a[0]]; if (!e) { e = W.em[a[0]] = mkGhostE(W, a); W.es.push(e); }
      if (a[13] !== e.tpN) { e.tpN = a[13]; e.x = e.ox = a[2]; e.z = e.oz = a[3]; }
      e.nx = a[2]; e.nz = a[3]; e.ny = a[4]; e.face = a[5]; e.hpf = a[6] / 1000; e.hp = e.hpf; e.st = ST[a[7]];
      const K = EN[e.k], nmv = a[8] >= 0 ? K.mv[a[8]] : null; if (nmv !== e.mv || abs(a[9] / 100 - e.mt) > 0.25) { e.mv = nmv; e.mi = a[8]; e.mt = a[9] / 100; }
      const f = a[10]; e.el = f & 1; e.bl = f & 2 ? a[14] || 1 : 0; e.bu = f & 4 ? 1 : 0; e.sk = f & 8 ? 1 : 0; e.ch = f & 16 ? 1 : 0; e.mk = f & 32 ? 1 : 0; e.mvn = f & 64 ? 1 : 0; e.p2 = !!(f & 128); e.gp = f & 256 ? 1 : 0; e.msp = a[11] / 100; e.poise = a[12] / 100 * (e.pmax || 1); if (e.el) e.w = K.w * 1.2;
    }
    for (let i = W.es.length - 1; i >= 0; i--) if (!seen[W.es[i].id]) { delete W.em[W.es[i].id]; W.es.splice(i, 1); }
    const pm = {}; for (const q of W.pj) pm[q.id] = q; W.pj = [];
    for (const a of hs.j) {
      const k = PJK[a[1]], P = PJ[k]; let q = pm[a[0]];
      if (P.lob) { if (!q) q = { id: a[0], k, own: a[2], sx: a[3], sz: a[4], tx: a[5], tz: a[6], T: a[8] / 100, x: a[3], z: a[4], y: 40 }; q.t = a[7] / 100; }
      else { if (!q) q = { id: a[0], k, own: a[2], x: a[3], z: a[4], y: a[5], ox: a[3], oz: a[4], oy: a[5] }; else if (abs(q.x - a[3]) > 60) { q.x = a[3]; q.z = a[4]; } q.nx = a[3]; q.nz = a[4]; q.vx = a[6]; q.vz = a[7]; q.life = 1; }
      W.pj.push(q);
    }
    W.zn = hs.z.map((a) => ({ id: a[0], k: ZNK[a[1]], x: a[2], z: a[3], rx: a[4], rz: a[5], age: a[6] / 100, warn: a[7] / 100, dur: a[8] / 10, own: a[9], on: a[6] >= a[7] }));
    W.orb = hs.o.map((a) => ({ x: a[0], z: a[1], t: 9 }));
    for (const e of hs.v) { if (e[0] <= (W.evSeen || 0)) continue; W.evSeen = e[0]; out.push(e); }
    if (hs.a) { W.offers = hs.a.o; W.pk = hs.a.d; } else { W.offers = null; W.pk = null; }
    if (hs.au) hs.au.forEach((l, i) => { const p = W.ps[i]; if (!p) return; let ch = l.length !== p.al.length; const aug = {}; for (const q of l) { aug[q[0]] = q[1]; if (p.aug[q[0]] !== q[1]) ch = true; } if (ch) { p.aug = aug; p.al = l.map((q) => q[0]); const hp = p.hp; calcMods(p); p.hp = hp; } });
    return out;
  }
  /* 손님 걸음: 받은 자리 쪽으로 부드럽게, 내 자리는 서 있는 동안 직접 움직임 */
  function guestStep(W, dt, me, inp) {
    W.tick++;
    for (const p of W.ps) {
      p.ox = p.x; p.oz = p.z; p.oy = p.y;
      if (p.mv && p.st === 'act') p.mt += dt * (p.msp || 1);
      if (p.s === me && inp) {
        if (p.pred > 0) { p.pred -= dt; if (p.pred <= 0 && p.st === 'act') { p.st = 'idle'; p.mv = null; } }
        if (p.st === 'idle') {
          const sp = CLS[p.cls].spd * (1 + (p.m.move || 0)) * (p.ch > 0 ? 0.6 : 1);
          p.x = clamp(p.x + inp.mx * sp * dt, W.bx0 + p.w, W.bx1 - p.w); p.z = clamp(p.z + inp.mz * sp * 0.62 * dt, 0, ZD); p.mvn = abs(inp.mx) + abs(inp.mz) > 0.15 ? 1 : 0; if (abs(inp.mx) > 0.2) p.face = sgn(inp.mx);
          p.y += (0 - p.y) * 0.3;
          continue;
        }
      }
      if (p.nx != null) { p.x += (p.nx - p.x) * 0.3; p.z += (p.nz - p.z) * 0.3; p.y += (p.ny - p.y) * 0.4; }
    }
    for (const e of W.es) { e.ox = e.x; e.oz = e.z; e.oy = e.y; e.age += dt; if (e.mv && e.st === 'act') e.mt += dt * (e.msp || 1); e.x += (e.nx - e.x) * 0.28; e.z += (e.nz - e.z) * 0.28; e.y += (e.ny - e.y) * 0.4; }
    for (const q of W.pj) { q.ox = q.x; q.oz = q.z; q.oy = q.y; const P = PJ[q.k]; if (P.lob) { q.t += dt; const f = Math.min(1, q.t / q.T); q.x = q.sx + (q.tx - q.sx) * f; q.z = q.sz + (q.tz - q.sz) * f; q.y = 40 * (1 - f) + 280 * f * (1 - f); } else { q.nx += q.vx * dt; q.nz += q.vz * dt; q.x += q.vx * dt + (q.nx - q.x) * 0.2; q.z += q.vz * dt + (q.nz - q.z) * 0.2; } }
    for (const q of W.zn) q.age += dt;
    if (W.fade > 0) W.fade = Math.max(0, W.fade - dt);
  }
  /* 손님 입력을 호스트가 받음: o = { i:[mx,mz,a, q0,q1,q2,q3], x, z, ap:[라운드, 고른 칸] } */
  function ingest(W, s, o) {
    const p = W.ps[s]; if (!p || !o || !Array.isArray(o.i)) return;
    p.rem = true; const i = o.i; let k = 0;
    for (let b = 0; b < 4; b++) { const v = i[3 + b] | 0; if (v !== p.sq[b]) { if (p.sqInit) k |= b === 3 ? 8 : 1 << b; p.sq[b] = v; } }
    p.sqInit = 1;
    p.rin = { mx: clamp(+i[0] / 100 || 0, -1, 1), mz: clamp(+i[1] / 100 || 0, -1, 1), a: i[2] ? 1 : 0, k: k | (p.rin && p.rin.k ? p.rin.k : 0) };
    if (typeof o.x === 'number' && typeof o.z === 'number') { p.rx = o.x; p.rz = o.z; }
    if (Array.isArray(o.ap) && o.ap[0] === W.ar) applyPick(W, s, o.ap[1] | 0);
  }

  D.sim = { DT, GR, ST, PH, makeWorld, worldStep, guestStep, applyHost, packHost, ingest, applyPick, botInput, botPick, calcMods, addAug, zoneOf, bossSeg, rnd, PJK, ZNK, HPZ, DMZ };
  if (typeof module === 'object' && module) module.exports = D.sim;
})();
