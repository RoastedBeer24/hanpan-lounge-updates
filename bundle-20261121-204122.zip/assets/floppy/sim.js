/* 흐물 협동 (floppy) — 시뮬(순수 로직, node에서도 돎)
   · 고정 걸음 60/초. 몸통은 원기둥 컨트롤러(속도 · 받침 · 계단 오르기) + 잡기 제약(매달리기 · 끌기 · 들기 · 밧줄).
   · 움직이는 것: 상자 bx(회전 없는 상자, 쌓기 · 밀기) · 승강/문살 mv(신호로 움직임) · 미닫이/수레 sl(한 축, 사람이 끎) ·
     시소/투석기 pk(기울어지는 판) · 밧줄 rp · 손잡이 lv · 무게 발판 pt · 벨트(받침 속도가 있는 붙박이).
   · 봇(S.bot): 마당마다 준비된 단계(yards.js)를 상황에 맞춰 따라감. 사람이 있으면 돕는 쪽이 먼저.
   · 온라인: S.pack / S.unpack (움직이는 것만). */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const S = {};
  const DT = 1 / 60, GRAV = 18, WALK = 3.6, JUMP = 6.3, PR = 0.3, PH = 1.7, SH = 1.3, ARM = 0.78, REACH = 1.05, STEP = 0.36;
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  const angD = (a, b) => { let d = (b - a) % TAU; if (d > Math.PI) d -= TAU; if (d < -Math.PI) d += TAU; return d; };
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  Object.assign(S, { DT, GRAV, WALK, JUMP, PR, PH, SH, ARM, REACH, clamp, angD, rng });

  /* ======================= 세계 ======================= */
  S.newWorld = function (n, seed) {
    return { t: 0, n, seed, rnd: rng(seed || 1), st: [], bx: [], mv: [], sl: [], pk: [], rp: [], lv: [], pt: [], P: [], sig: {}, yards: [], cpi: 0, yT: 0, ev: [], evn: 0, killY: -14, done: 0, fin: null, warps: 0, resets: 0 };
  };
  const ev = (W, ty, a, b) => { W.ev.push([++W.evn, ty, a == null ? 0 : a, b == null ? 0 : b]); if (W.ev.length > 14) W.ev.shift(); };
  S.addStatic = (W, x0, y0, z0, x1, y1, z1, k, o) => { const s = Object.assign({ T: 'st', x0, y0, z0, x1, y1, z1, k: k || 'c', vx: 0, vz: 0 }, o || {}); W.st.push(s); return s; };
  S.addBox = (W, x, y, z, hx, hy, hz, m, o) => { const b = Object.assign({ T: 'bx', i: W.bx.length, x, y, z, hx, hy, hz, m, vx: 0, vy: 0, vz: 0, gr: 0, sup: null, svx: 0, svy: 0, svz: 0, ld: 0, held: -1, qx: 0, qz: 0, nqx: 0, nqz: 0, cqx: 0, cqz: 0, hp: 0, lqx: 0, lqz: 0, home: [x, y, z], ox: x, oy: y, oz: z }, o || {}); W.bx.push(b); return b; };
  S.addMover = (W, hx, hy, hz, a, b, o) => { const m = Object.assign({ T: 'mv', i: W.mv.length, hx, hy, hz, a, b, f: 0, of: 0, spd: 0.5, sig: null, lat: 0, x: a[0], y: a[1], z: a[2], vx: 0, vy: 0, vz: 0, ph: 0 }, o || {}); if (m.cyc) m.ph = m.cyc.ph || 0; W.mv.push(m); mvBox(m); return m; };
  S.addSlider = (W, hx, hy, hz, p, ax, max, o) => { const s = Object.assign({ T: 'sl', i: W.sl.length, hx, hy, hz, p, ax, min: 0, max, s: 0, os: 0, v: 0, m: 1.5, q: 0, nq: 0, idle: 9, rid: 0, noR: 0, vx: 0, vz: 0, held: 0 }, o || {}); W.sl.push(s); slBox(s); return s; };
  S.addPlank = (W, px, py, pz, L, Wd, lim, o) => { const k = Object.assign({ T: 'pk', i: W.pk.length, px, py, pz, L, W: Wd, lim, th: 0, oth: 0, w: 0, tq: 0, I: 110, kr: 25, rest: 0, cat: null }, o || {}); k.th = k.rest; if (k.cat) { k.cat = Object.assign({ st: 0, t: 0, delay: 2.5, side: -1 }, k.cat); k.th = k.cat.side < 0 ? k.lim : -k.lim; } k.oth = k.th; W.pk.push(k); return k; };
  S.addRope = (W, ax, ay, az, len) => { const r = { T: 'rp', i: W.rp.length, ax, ay, az, len, bx: ax, by: ay - len, bz: az, vx: 0, vy: 0, vz: 0, held: 0 }; W.rp.push(r); return r; };
  S.addLever = (W, x, y, z, o) => { const l = Object.assign({ T: 'lv', i: W.lv.length, x, y, z, mode: 'hold', keep: 0, on: 0, tm: 0, held: 0, sig: null, sl: -1 }, o || {}); l.bx = x; l.by = y; l.bz = z; W.lv.push(l); return l; };
  S.addPlate = (W, x, y, z, hw, hd, need, o) => { const p = Object.assign({ T: 'pt', i: W.pt.length, x, y, z, hw, hd, need, load: 0, on: 0, lat: 0, latch: 1, sig: null }, o || {}); W.pt.push(p); return p; };
  S.addPlayer = function (W, seat, info) {
    const p = { T: 'pl', seat, ai: !!info.ai, lv: info.lv || 2, m: 1, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, yaw: Math.PI / 2, ay: Math.PI / 2, pit: 0, mx: 0, mz: 0, grab: false, jump: false, jq: 0, coy: 0, gr: 0, wgr: 0, sup: null, svx: 0, svy: 0, svz: 0, ld: 0, g: null, gw: null, gcd: 0, mt: 0, stun: 0, falls: 0, moved: 0, grabs: 0, gt: 0, air: 0, pvy: 0, cnx: 0, cnz: 0, hitH: 0, off: false, ox: 0, oy: 0, oz: 0, oyaw: 0, bot: null };
    W.P[seat] = p; return p;
  };
  S.spawn = function (W, p, ci) {
    const c = W.yards[ci == null ? W.cpi : ci].cp, n = W.P.length;
    drop(W, p); p.x = c[0] - 0.4 * (p.seat % 2); p.y = c[1] + 0.02; p.z = c[2] + (p.seat - (n - 1) / 2) * 1.1; p.vx = p.vy = p.vz = 0; p.stun = 0; p.gr = 0; p.coy = 0; p.sup = null; p.mt = 0; p.gcd = 0.3;
    p.ox = p.x; p.oy = p.y; p.oz = p.z; p.tp = 1;
  };
  function mvBox(m) { m.x0 = m.x - m.hx; m.x1 = m.x + m.hx; m.y0 = m.y - m.hy; m.y1 = m.y + m.hy; m.z0 = m.z - m.hz; m.z1 = m.z + m.hz; }
  function slBox(s) { const x = s.p[0] + (s.ax === 0 ? s.s : 0), z = s.p[2] + (s.ax === 2 ? s.s : 0); s.x = x; s.y = s.p[1]; s.z = z; s.x0 = x - s.hx; s.x1 = x + s.hx; s.y0 = s.y - s.hy; s.y1 = s.y + s.hy; s.z0 = z - s.hz; s.z1 = z + s.hz; }
  const sigOn = (W, s) => (s == null ? true : Array.isArray(s) ? s.every((q) => sigOn(W, q)) : s[0] === '!' ? !W.sig[s.slice(1)] : !!W.sig[s]);
  S.sigOn = sigOn;
  S.plankH = function (k, x, z) { const dx = x - k.px, dz = z - k.pz; if (Math.abs(dz) > k.W || Math.abs(dx) > k.L * Math.cos(k.th)) return null; return k.py + dx * Math.tan(k.th); };
  S.refresh = function (W) { for (const m of W.mv) { const f = m.f; m.x = m.a[0] + (m.b[0] - m.a[0]) * f; m.y = m.a[1] + (m.b[1] - m.a[1]) * f; m.z = m.a[2] + (m.b[2] - m.a[2]) * f; mvBox(m); } for (const s of W.sl) slBox(s); for (const l of W.lv) leverPos(W, l); };
  function leverPos(W, l) { if (l.sl >= 0) { const s = W.sl[l.sl]; l.x = s.x + l.bx; l.y = s.y + l.by; l.z = s.z + l.bz; } }

  /* ======================= 잡기 ======================= */
  const carryable = (b) => b.m <= 1 && b.ld < 0.5;
  S.holdDist = (b) => PR + b.hx + 0.2;
  function gripPoint(W, g) {
    if (g.k === 's') return [g.lx, g.ly, g.lz];
    if (g.k === 'm') { const o = W.mv[g.i]; return [o.x + g.lx, o.y + g.ly, o.z + g.lz]; }
    if (g.k === 'd') { const o = W.sl[g.i]; return [o.x + g.lx, o.y + g.ly, o.z + g.lz]; }
    if (g.k === 'b') { const o = W.bx[g.i]; return [o.x + g.lx, o.y + g.ly, o.z + g.lz]; }
    if (g.k === 'l') { const o = W.lv[g.i]; return [o.x, o.y, o.z]; }
    if (g.k === 'p') { const o = W.P[g.i]; return [o.x, o.y + 1.0, o.z]; }
    if (g.k === 'r') { const o = W.rp[g.i]; return [o.ax, o.ay, o.az]; }
    return [0, 0, 0];
  }
  S.gripPoint = gripPoint;
  function aabbCand(p, o, k, i, sx, sy, sz, fx, fz, tx, ty, tz, any, bonus, best) {
    let cx = clamp(sx, o.x0, o.x1), cz = clamp(sz, o.z0, o.z1);
    if (cx === sx && cz === sz) { const a = sx - o.x0, b = o.x1 - sx, c = sz - o.z0, d = o.z1 - sz, m = Math.min(a, b, c, d); if (m === a) cx = o.x0; else if (m === b) cx = o.x1; else if (m === c) cz = o.z0; else cz = o.z1; }
    const dx = cx - sx, dz = cz - sz, dh = hyp(dx, dz), top = o.y1;
    if (top > p.y + 0.45 && top <= sy + REACH * 0.93 && dh <= 0.85 && (dh < 0.2 || (dx * fx + dz * fz) / dh >= -0.15) && o.y0 < sy + 0.9) {
      const sc = hyp(dh, Math.max(0, top - sy)) - bonus - 0.05;
      if (!best || sc < best.sc) return { sc, k, i, x: cx, y: top, z: cz, top: 1, nx: dh > 1e-4 ? -dx / dh : -fx, nz: dh > 1e-4 ? -dz / dh : -fz };
      return best;
    }
    if (!any) return best;
    const px = clamp(tx, o.x0, o.x1), py = clamp(ty, o.y0, o.y1), pz = clamp(tz, o.z0, o.z1);
    if (py <= p.y + 0.12) return best;
    const d = hyp(px - sx, py - sy, pz - sz);
    if (d > REACH) return best;
    const sc = d - bonus;
    if (!best || sc < best.sc) { const hx = sx - px, hz = sz - pz, hd = hyp(hx, hz); return { sc, k, i, x: px, y: py, z: pz, top: 0, nx: hd > 1e-4 ? hx / hd : -fx, nz: hd > 1e-4 ? hz / hd : -fz }; }
    return best;
  }
  /* 지금 손이 닿는 잡을 것(가장 알맞은 하나). 화면 강조와 실제 잡기가 같은 함수를 씀 */
  S.findGrip = function (W, p, yaw, pitch) {
    if (yaw == null) yaw = p.ay; if (pitch == null) pitch = p.pit;
    const sx = p.x, sy = p.y + SH, sz = p.z, cp = Math.cos(pitch), fx = Math.sin(yaw), fz = Math.cos(yaw);
    const ax = fx * cp, ay = Math.sin(pitch), az = fz * cp, tx = sx + ax * 0.6, ty = sy + ay * 0.6, tz = sz + az * 0.6;
    let best = null;
    const pt = (x, y, z, k, i, r, bonus, ex) => { const dx = x - sx, dy = y - sy, dz = z - sz, d = hyp(dx, dy, dz); if (d > r) return; if (d > 0.35 && (dx * fx + dz * fz) < -0.25 * d) return; const sc = d * 0.5 - bonus; if (!best || sc < best.sc) best = Object.assign({ sc, k, i, x, y, z, top: 0, nx: -fx, nz: -fz }, ex || {}); };
    for (const l of W.lv) if (l.sl < 0 || true) pt(l.x, l.y, l.z, 'l', l.i, 1.3, 0.6);
    for (const s of W.sl) if (s.hd) pt(s.x + s.hd[0], s.y + s.hd[1], s.z + s.hd[2], 'd', s.i, 1.3, 0.55, { hd: 1 });
    for (const r of W.rp) {
      const ex = r.bx - r.ax, ey = r.by - r.ay, ez = r.bz - r.az, L2 = ex * ex + ey * ey + ez * ez;
      const u = clamp(((tx - r.ax) * ex + (ty - r.ay) * ey + (tz - r.az) * ez) / L2, 0.25, 1), x = r.ax + ex * u, y = r.ay + ey * u, z = r.az + ez * u, d = hyp(x - sx, y - sy, z - sz);
      if (d <= 1.2) { const sc = d * 0.5 - 0.5; if (!best || sc < best.sc) best = { sc, k: 'r', i: r.i, x, y, z, top: 0, nx: -fx, nz: -fz }; }
    }
    if (!p.ai) for (const q of W.P) if (q && q !== p && !q.off) pt(q.x, q.y + 1.0, q.z, 'p', q.seat, 1.0, 0.1, { top: 1 });
    for (const b of W.bx) { if (b.held >= 0 || (p.sup === b)) continue; b.x0 = b.x - b.hx; b.x1 = b.x + b.hx; b.y0 = b.y - b.hy; b.y1 = b.y + b.hy; b.z0 = b.z - b.hz; b.z1 = b.z + b.hz; best = aabbCand(p, b, 'b', b.i, sx, sy, sz, fx, fz, tx, ty, tz, 1, 0.2, best); }
    for (const s of W.sl) if (p.sup !== s && !s.ng) best = aabbCand(p, s, 'd', s.i, sx, sy, sz, fx, fz, tx, ty, tz, !s.hd, 0.15, best);
    for (const m of W.mv) if (!m.ng) best = aabbCand(p, m, 'm', m.i, sx, sy, sz, fx, fz, tx, ty, tz, 0, 0.1, best);
    for (let i = 0; i < W.st.length; i++) { const o = W.st[i]; if (o.ng || o.x1 < sx - 1.2 || o.x0 > sx + 1.2 || o.z1 < sz - 1.2 || o.z0 > sz + 1.2) continue; best = aabbCand(p, o, 's', i, sx, sy, sz, fx, fz, tx, ty, tz, 0, 0.1, best); }
    return best;
  };
  function latch(W, p, c) {
    const g = { k: c.k, i: c.i, hd: c.hd || 0, top: c.top, nx: c.nx, nz: c.nz, lx: c.x, ly: c.y, lz: c.z, ox: 0, oz: 0, oy: p.y, L: 0, carry: 0 };
    if (c.k === 'm' || c.k === 'd' || c.k === 'b') { const o = c.k === 'm' ? W.mv[c.i] : c.k === 'd' ? W.sl[c.i] : W.bx[c.i]; g.lx = c.x - o.x; g.ly = c.y - o.y; g.lz = c.z - o.z; g.ox = p.x - o.x; g.oz = p.z - o.z; g.oy = p.y - o.y; }
    if (c.k === 'b') { const b = W.bx[c.i]; if (carryable(b)) { g.carry = 1; b.held = p.seat; b.gr = 0; } }
    if (c.k === 'r') { const r = W.rp[c.i]; g.L = clamp(hyp(p.x - r.ax, p.y + SH - r.ay, p.z - r.az), 1.2, r.len + 0.3); r.held++; }
    if (c.k === 'l') { const l = W.lv[c.i]; if (l.mode === 'toggle') { l.on = l.on ? 0 : 1; ev(W, 'lv', l.i, l.on); } else if (!l.on) ev(W, 'lv', l.i, 1); }
    p.g = g; p.mt = 0; p.grabs++; ev(W, 'grab', p.seat, c.k.charCodeAt(0));
  }
  function drop(W, p) {
    const g = p.g; if (!g) return;
    if (g.k === 'b' && g.carry) { const b = W.bx[g.i]; if (b.held === p.seat) { b.held = -1; b.vx = clamp(b.vx, -4, 4); b.vy = clamp(b.vy, -4, 4); b.vz = clamp(b.vz, -4, 4); } }
    if (g.k === 'r') { const r = W.rp[g.i]; r.held = Math.max(0, r.held - 1); r.bx = p.x; r.by = p.y + SH; r.bz = p.z; r.vx = p.vx; r.vy = p.vy; r.vz = p.vz; }
    p.g = null; p.gw = null; p.mt = 0;
  }
  S.drop = drop;
  function grips(W) {
    for (const l of W.lv) l.held = 0;
    for (const s of W.sl) s.held = 0;
    for (const p of W.P) {
      if (!p || p.off) continue;
      if (p.gcd > 0) p.gcd -= DT;
      let g = p.g;
      if (g && (!p.grab || p.stun > 0)) { drop(W, p); g = null; }
      if (g) {
        if (g.k === 'b') { const b = W.bx[g.i]; if (g.carry ? b.held !== p.seat : b.held >= 0) { drop(W, p); g = null; } }
        if (g && g.k === 'p' && (!W.P[g.i] || W.P[g.i].off)) { drop(W, p); g = null; }
      }
      if (!g && p.grab && p.gcd <= 0 && p.stun <= 0) { const c = S.findGrip(W, p); if (c) { latch(W, p, c); g = p.g; } }
      if (g) { if (g.k === 'l') W.lv[g.i].held++; if (g.k === 'd') W.sl[g.i].held++; p.gw = g.k === 'r' ? [p.x + Math.sin(p.ay) * 0.15, p.y + SH + 0.45, p.z + Math.cos(p.ay) * 0.15] : gripPoint(W, g); }
      else p.gw = null;
    }
  }

  /* ======================= 장치 ======================= */
  function mech(W) {
    const dt = DT;
    for (const k in W.sig) W.sig[k] = 0;
    for (const p of W.pt) { const on = p.load >= p.need - 0.01 ? 1 : 0; if (on && !p.on) ev(W, 'pt', p.i, 1); p.on = on; if (on && p.latch) p.lat = 1; if (p.sig && (on || p.lat)) W.sig[p.sig] = 1; }
    for (const l of W.lv) {
      leverPos(W, l);
      if (l.mode === 'hold') { if (l.held) { l.on = 1; l.tm = l.keep; } else if (l.tm > 0) { l.tm -= dt; l.on = l.tm > 0 ? 1 : 0; if (!l.on) ev(W, 'lv', l.i, 0); } else l.on = 0; }
      else if (l.mode === 'once') { if (l.held) l.on = 1; }
      if (l.sig && l.on) W.sig[l.sig] = 1;
    }
    for (const m of W.mv) {
      m.of = m.f;
      let f = m.f;
      if (m.cyc && sigOn(W, m.cyc.sig)) { if (!m.cyOn) { m.cyOn = 1; if (m.sig) m.ph = m.f >= 0.5 ? 0.5 : 0; } m.ph = (m.ph + dt / m.cyc.per) % 1; const u = m.ph, d = m.cyc.dw || 0.12, h = 0.5 - d; f = u < d ? 0 : u < 0.5 ? (u - d) / h : u < 0.5 + d ? 1 : 1 - (u - 0.5 - d) / h; f = f * f * (3 - 2 * f); }
      else if (!m.cyc || m.sig) { const on = m.lat || sigOn(W, m.sig); const t = on ? 1 : 0; f += clamp(t - f, -m.spd * dt, m.spd * dt); if (m.latch && f >= 1) { if (!m.lat) ev(W, 'open', m.i); m.lat = 1; } }
      m.f = f;
      const x = m.a[0] + (m.b[0] - m.a[0]) * f, y = m.a[1] + (m.b[1] - m.a[1]) * f, z = m.a[2] + (m.b[2] - m.a[2]) * f;
      m.vx = (x - m.x) / dt; m.vy = (y - m.y) / dt; m.vz = (z - m.z) / dt; m.x = x; m.y = y; m.z = z; mvBox(m);
    }
    for (const k of W.pk) {
      k.oth = k.th;
      const c = k.cat;
      if (c) {
        const down = c.side < 0 ? k.lim : -k.lim, up = -down;
        if (c.st === 0) { k.w = 0; k.th = down; if (sigOn(W, c.sig)) { c.st = 1; c.t = c.delay; ev(W, 'arm', k.i); } }
        else if (c.st === 1) { c.t -= dt; if (c.t <= 0) { c.st = 2; c.t = 2.2; ev(W, 'fire', k.i); const all = W.bx.concat(W.P); for (const o of all) { if (!o || o.off || o.sup !== k) continue; if ((o.x - k.px) * c.side > k.L * 0.3) { o.vx = c.vx; o.vy = c.vy; o.vz = 0; o.gr = 0; o.sup = null; o.y += 0.06; if (o.T === 'pl') { drop(W, o); o.coy = 0; o.air = 1; } } } } }
        else if (c.st === 2) { const d = up - k.th; k.w = Math.sign(d) * 9; if (Math.abs(d) <= 9 * dt) { k.th = up; k.w = 0; } else k.th += k.w * dt; c.t -= dt; if (c.t <= 0) c.st = 3; }
        else { const d = down - k.th; k.w = Math.sign(d) * 0.6; if (Math.abs(d) <= 0.6 * dt) { k.th = down; k.w = 0; c.st = 0; } else k.th += k.w * dt; }
        k.tq = 0; continue;
      }
      let a = (k.tq + k.kr * (k.rest - k.th)) / k.I;
      k.w = clamp((k.w + a * dt) * (1 - 2.2 * dt), -2.5, 2.5);
      k.th += k.w * dt;
      if (k.th > k.lim) { k.th = k.lim; if (k.w > 0) k.w = 0; } else if (k.th < -k.lim) { k.th = -k.lim; if (k.w < 0) k.w = 0; }
      k.tq = 0;
    }
    for (const r of W.rp) {
      if (r.held) continue;
      r.vy -= GRAV * dt; r.vx *= 1 - 1.2 * dt; r.vz *= 1 - 1.2 * dt;
      r.bx += r.vx * dt; r.by += r.vy * dt; r.bz += r.vz * dt;
      const dx = r.bx - r.ax, dy = r.by - r.ay, dz = r.bz - r.az, d = hyp(dx, dy, dz) || 1, k = r.len / d;
      if (d > r.len) { r.bx = r.ax + dx * k; r.by = r.ay + dy * k; r.bz = r.az + dz * k; const vr = (r.vx * dx + r.vy * dy + r.vz * dz) / d; if (vr > 0) { r.vx -= dx / d * vr; r.vy -= dy / d * vr; r.vz -= dz / d * vr; } }
    }
    for (const o of W.st) if (o.cv) { const on = sigOn(W, o.cv.sig); o.vx = on ? o.cv.v1 : o.cv.v0; o.cvOn = on ? 1 : 0; }
  }

  /* ======================= 속도 정하기 ======================= */
  function objVel(W) {
    const dt = DT;
    for (const p of W.P) {   // 끌기: 잡은 사람의 뜻을 물체에 싣기
      if (!p || p.off || !p.g || p.mt || p.stun > 0) continue;
      const g = p.g, m = hyp(p.mx, p.mz);
      if (m < 0.05) continue;
      if (g.k === 'b' && !g.carry) { const b = W.bx[g.i]; b.qx += p.mx; b.qz += p.mz; if (!p.ai) b.hp = 0.6; }
      else if (g.k === 'd') { const s = W.sl[g.i]; s.q += s.ax === 0 ? p.mx : p.mz; if (!p.ai) s.hp = 0.6; }
    }
    for (const b of W.bx) {
      b.ox = b.x; b.oy = b.y; b.oz = b.z;
      b.qx += b.nqx; b.qz += b.nqz; b.nqx = b.nqz = 0;
      if (b.hp > 0) b.hp -= dt;
      if (b.held >= 0) {
        const p = W.P[b.held];
        if (!p || !p.g || p.g.k !== 'b' || p.g.i !== b.i) { b.held = -1; } else {
          const hd = S.holdDist(b), ty = clamp(p.y + 1.05 + p.pit * 0.95, p.y + b.hy + 0.06, p.y + 2.0), tx = p.x + Math.sin(p.ay) * hd, tz = p.z + Math.cos(p.ay) * hd;
          b.vx = clamp(p.vx + (tx - b.x) * 12, -9, 9); b.vy = clamp(p.vy + (ty - b.y) * 12, -9, 9); b.vz = clamp(p.vz + (tz - b.z) * 12, -9, 9);
          b.qx = b.qz = b.cqx = b.cqz = 0; continue;
        }
      }
      b.vy -= GRAV * dt;
      const q = hyp(b.qx, b.qz);
      if (b.gr) {
        let tx = b.svx, tz = b.svz;
        if (q > 0.05) { const sp = WALK * Math.min(0.85, 0.75 * q / (b.m + b.ld)); tx += b.qx / q * sp; tz += b.qz / q * sp; b.lqx = b.qx / q; b.lqz = b.qz / q; }
        const ax = tx - b.vx, az = tz - b.vz, d = hyp(ax, az), mx = 30 * dt;
        if (d <= mx) { b.vx = tx; b.vz = tz; } else { b.vx += ax / d * mx; b.vz += az / d * mx; }
      }
      b.cqx = b.qx; b.cqz = b.qz; b.qx = b.qz = 0;
    }
    for (const s of W.sl) {
      s.os = s.s; s.q += s.nq; s.nq = 0;
      if (s.hp > 0) s.hp -= dt;
      const os = s.s; let v = s.v;
      if (s.drive) {
        const l = W.lv[s.drive.lv];
        if (l.held) { v = s.drive.v; s.noR = 0; }
        else { s.noR = s.rid ? 0 : s.noR + dt; v = (!s.rid && s.noR > 2 && s.s > 0) ? -s.drive.ret : 0; }
      } else if (Math.abs(s.q) > 0.05) { v = Math.sign(s.q) * WALK * Math.min(0.85, 0.75 * Math.abs(s.q) / (s.m + s.rid * 0.5)); s.idle = 0; }
      else {
        s.idle += dt;
        if (s.spring && !s.held) v = s.idle > s.spring.wait && s.s > 0 ? -s.spring.v : 0;
        else if (s.roll) v *= 1 - s.roll * dt; else v = 0;
      }
      if (s.auto && s.s > s.auto.from && s.s < s.max) v = Math.max(v, s.auto.v);
      s.s = clamp(s.s + v * dt, s.min, s.max); if (s.s === s.min || s.s === s.max) v = 0;
      s.v = v; s.q = 0;
      const d = (s.s - os) / dt; s.vx = s.ax === 0 ? d : 0; s.vz = s.ax === 2 ? d : 0; slBox(s);
    }
  }
  function walk(p, sp, dt) {
    const tx = p.svx + p.mx * sp, tz = p.svz + p.mz * sp, m = hyp(p.mx, p.mz);
    const acc = (p.gr ? (p.sup && p.sup.cv ? 90 : 34) : m > 0.05 ? (p.air ? 3 : 9) : 1.5) * dt;
    const ax = tx - p.vx, az = tz - p.vz, d = hyp(ax, az);
    if (d <= acc) { p.vx = tx; p.vz = tz; } else { p.vx += ax / d * acc; p.vz += az / d * acc; }
    if (p.gr && m > 0.05) p.moved += m * sp * dt;
  }
  function tryJump(W, p, k) {
    if (p.jq > 0 && p.coy > 0 && (!(p.sup && p.sup.cv) || p.gt > 0.1)) { p.vy = JUMP * (k || 1) + Math.max(0, p.svy); p.jq = 0; p.coy = 0; p.gr = 0; ev(W, 'jump', p.seat); return true; }
    return false;
  }
  function ctrl(W, p) {
    const dt = DT;
    p.ox = p.x; p.oy = p.y; p.oz = p.z; p.oyaw = p.yaw;
    if (p.jq > 0) p.jq -= dt;
    if (p.stun > 0) { p.stun -= dt; p.vy -= GRAV * dt; if (p.gr) { const k = Math.min(1, 5 * dt); p.vx += (p.svx - p.vx) * k; p.vz += (p.svz - p.vz) * k; } return; }
    const m = hyp(p.mx, p.mz), g = p.g;
    const ty = p.grab || g ? p.ay : m > 0.1 ? Math.atan2(p.mx, p.mz) : p.yaw;
    p.yaw += angD(p.yaw, ty) * Math.min(1, 12 * dt);
    p.mt = 0;
    if (g && g.k === 'r') {
      p.vy -= GRAV * dt; p.vx += p.mx * 6 * dt; p.vz += p.mz * 6 * dt;
      if (p.jq > 0) { p.jq = 0; drop(W, p); p.vy += 2.4; p.gcd = 0.5; p.air = 1; ev(W, 'jump', p.seat); }
      return;
    }
    if (g && g.k !== 'l' && !g.carry) {
      const A = p.gw || gripPoint(W, g), stat = g.k === 's' || g.k === 'm';
      const into = -(p.mx * g.nx + p.mz * g.nz);
      if (g.top && (g.m || A[1] > p.y + 0.3) && (p.jump || (stat && into > 0.5))) {
        p.mt = 1; g.m = 1; p.vy = 3.3; p.gr = 0;
        const hx = A[0] - p.x, hz = A[2] - p.z, hd = hyp(hx, hz), k = hd > 0.36 ? 2.2 / hd : 0;
        p.vx = hx * k; p.vz = hz * k;
        if (g.k === 'm') p.vy += Math.max(0, W.mv[g.i].vy);
        if (p.y >= A[1] - 0.05) { const nx = g.nx, nz = g.nz; drop(W, p); p.gcd = 0.45; p.vy = 1.6; p.vx = -nx * 2.0; p.vz = -nz * 2.0; p.jq = 0; }
        return;
      }
      if (stat || g.k === 'p') {
        if (p.gr) { walk(p, WALK * 0.7, dt); p.vy -= GRAV * dt; if (p.jq > 0 && g.k === 'p') { drop(W, p); p.gcd = 0.3; tryJump(W, p); } p.jq = Math.min(p.jq, 0.05); return; }
        p.vy -= GRAV * dt; p.vx += p.mx * 4 * dt; p.vz += p.mz * 4 * dt; p.vx *= 1 - 1.5 * dt; p.vz *= 1 - 1.5 * dt;
        if (g.k === 's') { const tx = -g.nz, tz = g.nx, s = p.mx * tx + p.mz * tz, o = W.st[g.i]; if (Math.abs(s) > 0.3) { g.lx = clamp(g.lx + tx * s * 1.5 * dt, o.x0 + 0.03, o.x1 - 0.03); g.lz = clamp(g.lz + tz * s * 1.5 * dt, o.z0 + 0.03, o.z1 - 0.03); } }
        return;
      }
      /* 무거운 상자 · 미닫이 · 수레: 붙어서 같이 움직임 */
      const o = g.k === 'b' ? W.bx[g.i] : W.sl[g.i];
      if (p.jq > 0 && p.gr) { drop(W, p); p.gcd = 0.35; tryJump(W, p); walk(p, WALK, dt); p.vy -= GRAV * dt; return; }
      p.vx = o.vx; p.vz = o.vz; p.vy -= GRAV * dt;
      if (g.hd) { /* 손잡이를 잡았으면 붙지 않고 따라 걷기 */ walk(p, WALK * 0.6, dt); }
      return;
    }
    walk(p, WALK * (g && g.carry ? 0.85 : g ? 0.6 : 1), dt);
    p.vy -= GRAV * dt;
    if (!tryJump(W, p, g && g.carry ? 0.88 : 1)) { /* 길게 누르지 않으면 낮게 */ if (!p.jump && p.vy > 3 && !p.air) p.vy -= 14 * dt; }
  }

  /* ======================= 부딪힘 ======================= */
  function plFix(p, o, svx, svy, svz) {
    if (p.y >= o.y1 || p.y + PH <= o.y0) { if (p.gr && p.y - o.y1 < 0.003 && p.y >= o.y1 && p.sup !== o && p.x >= o.x0 && p.x <= o.x1 && p.z >= o.z0 && p.z <= o.z1) { p.sup = o; p.svx = svx; p.svy = svy; p.svz = svz; } return 0; }   // 맞닿아 서 있는 받침(가운데가 올라간 쪽)
    const cx = clamp(p.x, o.x0, o.x1), cz = clamp(p.z, o.z0, o.z1), dx = p.x - cx, dz = p.z - cz, d2 = dx * dx + dz * dz;
    if (d2 >= PR * PR) return 0;
    const up = o.y1 - p.y, dn = p.y + PH - o.y0;
    let ph, nx, nz;
    if (d2 > 1e-9) { const d = Math.sqrt(d2); ph = PR - d; nx = dx / d; nz = dz / d; }
    else { const a = p.x - o.x0, b = o.x1 - p.x, c = p.z - o.z0, e = o.z1 - p.z, m = Math.min(a, b, c, e); ph = m + PR; nx = nz = 0; if (m === a) nx = -1; else if (m === b) nx = 1; else if (m === c) nz = -1; else nz = 1; }
    if (up <= dn && (up <= ph || (up <= STEP && (p.wgr || p.gr || p.coy > 0) && p.vy <= svy + 0.5) || (p.mt && up <= 0.5))) {
      p.y = o.y1; if (p.vy < svy) p.vy = svy;
      if (!p.gr || (p.x >= o.x0 && p.x <= o.x1 && p.z >= o.z0 && p.z <= o.z1)) { p.sup = o; p.svx = svx; p.svy = svy; p.svz = svz; }
      p.gr = 1; return 1;
    }
    if (dn < ph && dn < up) { p.y = o.y0 - PH; if (p.vy > svy) p.vy = Math.min(svy, 0); return 3; }
    p.x += nx * ph; p.z += nz * ph;
    const vn = (p.vx - svx) * nx + (p.vz - svz) * nz; if (vn < 0) { p.vx -= vn * nx; p.vz -= vn * nz; }
    p.cnx = nx; p.cnz = nz; p.hitH = 1; return 2;
  }
  function boxFix(b, o, svx, svy, svz) {
    const ox = Math.min(b.x + b.hx, o.x1) - Math.max(b.x - b.hx, o.x0); if (ox <= 0) return 0;
    const oz = Math.min(b.z + b.hz, o.z1) - Math.max(b.z - b.hz, o.z0); if (oz <= 0) return 0;
    const oy = Math.min(b.y + b.hy, o.y1) - Math.max(b.y - b.hy, o.y0);
    if (oy <= 0) { if (b.gr && oy > -0.003 && b.y > o.y1 && b.sup !== o && b.x >= o.x0 && b.x <= o.x1 && b.z >= o.z0 && b.z <= o.z1) { b.sup = o; b.svx = svx; b.svy = svy; b.svz = svz; } return 0; }
    const up = o.y1 - (b.y - b.hy);
    if ((oy <= ox && oy <= oz) || (up > 0 && up <= 0.14)) {
      if (b.y > (o.y0 + o.y1) / 2 || up <= 0.14) {
        b.y += up; if (b.vy < svy) b.vy = svy;
        if (!b.gr || (b.x >= o.x0 && b.x <= o.x1 && b.z >= o.z0 && b.z <= o.z1)) { b.sup = o; b.svx = svx; b.svy = svy; b.svz = svz; }
        b.gr = 1; return 1;
      }
      b.y -= oy; if (b.vy > 0) b.vy = 0; return 3;
    }
    if (ox < oz) { const d = b.x > (o.x0 + o.x1) / 2 ? 1 : -1; b.x += d * ox; if ((b.vx - svx) * d < 0) b.vx = svx; b.bkx = d; }
    else { const d = b.z > (o.z0 + o.z1) / 2 ? 1 : -1; b.z += d * oz; if ((b.vz - svz) * d < 0) b.vz = svz; b.bkz = d; }
    return 2;
  }
  function boxBox(a, b) {   // a가 아래(먼저 놓인 쪽)
    const ox = Math.min(a.x + a.hx, b.x + b.hx) - Math.max(a.x - a.hx, b.x - b.hx); if (ox <= 0) return;
    const oy = Math.min(a.y + a.hy, b.y + b.hy) - Math.max(a.y - a.hy, b.y - b.hy); if (oy <= 0) return;
    const oz = Math.min(a.z + a.hz, b.z + b.hz) - Math.max(a.z - a.hz, b.z - b.hz); if (oz <= 0) return;
    const up = a.y + a.hy - (b.y - b.hy);
    if (up > 0 && b.y > a.y && ((up <= ox && up <= oz) || up <= 0.2)) {
      if (a.held >= 0 && b.held < 0) { a.y -= up; return; }
      b.y += up; if (b.vy < a.vy) b.vy = a.vy; b.gr = 1; if (b.held < 0) { b.sup = a; b.svx = a.vx; b.svy = a.vy; b.svz = a.vz; } return;
    }
    const X = ox < oz, d = X ? (b.x > a.x ? 1 : -1) : (b.z > a.z ? 1 : -1), pen = X ? ox : oz;
    const va = (X ? a.vx : a.vz) * d, vb = -(X ? b.vx : b.vz) * d;
    const mv = b.held >= 0 ? b : a.held >= 0 ? a : va >= vb ? a : b, ot = mv === a ? b : a, sg = mv === a ? -d : d;
    if (X) { mv.x += sg * pen; if (mv.held < 0) { mv.vx = ot.vx; if (mv.cqx * -sg > 0) ot.nqx += mv.cqx; } }
    else { mv.z += sg * pen; if (mv.held < 0) { mv.vz = ot.vz; if (mv.cqz * -sg > 0) ot.nqz += mv.cqz; } }
  }
  function surf(o, k, bot) {   // 기울어지는 판 위에 얹기
    if (k.cat && k.cat.st === 2 && k.w !== 0) return;
    const h = S.plankH(k, o.x, o.z); if (h == null) return;
    const y = o.y - bot, sv = k.w * (o.x - k.px);
    if (y <= h + 0.03 && y >= h - 0.5 && o.vy <= sv + 1.2) { o.y = h + bot; if (o.vy < sv) o.vy = sv; o.gr = 1; o.sup = k; o.svx = 0; o.svy = sv; o.svz = 0; }
  }
  function plPl(p, q) {
    const dx = p.x - q.x, dz = p.z - q.z, d = hyp(dx, dz), R = PR * 2;
    if (d >= R) return;
    const hi = p.y >= q.y ? p : q, lo = hi === p ? q : p;
    if (hi.y >= lo.y + PH - 0.35) { if (hi.y <= lo.y + PH + 0.02 && hi.vy <= lo.vy + 0.6 && d < R * 0.85) { hi.y = lo.y + PH; if (hi.vy < lo.vy) hi.vy = lo.vy; hi.gr = 1; hi.sup = lo; hi.svx = lo.vx; hi.svy = lo.vy; hi.svz = lo.vz; } return; }
    if (hi.y >= lo.y + PH) return;
    const pen = (R - d) / 2, nx = d > 1e-4 ? dx / d : 1, nz = d > 1e-4 ? dz / d : 0;
    p.x += nx * pen; p.z += nz * pen; q.x -= nx * pen; q.z -= nz * pen;
  }
  function plAll(W, p) {
    for (const o of W.st) if (o.x1 > p.x - 0.4 && o.x0 < p.x + 0.4) plFix(p, o, o.vx, 0, o.vz);
    for (const o of W.mv) plFix(p, o, o.vx, o.vy, o.vz);
    for (const s of W.sl) { const r = plFix(p, s, s.vx, 0, s.vz); if (r === 2 && p.gr && !p.g && !p.ai && p.ps !== s) { const dd = -(p.mx * p.cnx + p.mz * p.cnz); if (dd > 0.3) { p.ps = s; s.nq += -(s.ax === 0 ? p.cnx : p.cnz) * dd; if (!p.ai) s.hp = 0.6; } } }
    for (const b of W.bx) {
      if (b.held >= 0) continue;
      if (b.y - b.hy >= p.y + PH - 0.3 && Math.abs(b.x - p.x) < b.hx + PR * 0.7 && Math.abs(b.z - p.z) < b.hz + PR * 0.7 && b.y - b.hy < p.y + PH) { b.y = p.y + PH + b.hy; if (b.vy < Math.max(0, p.vy)) b.vy = Math.max(0, p.vy); b.gr = 1; b.sup = p; b.svx = p.vx; b.svz = p.vz; continue; }
      b.x0 = b.x - b.hx; b.x1 = b.x + b.hx; b.y0 = b.y - b.hy; b.y1 = b.y + b.hy; b.z0 = b.z - b.hz; b.z1 = b.z + b.hz;
      const r = plFix(p, b, b.vx, b.vy, b.vz);
      if (r === 2 && p.gr && !p.g && !p.ai && p.pb !== b) { const dd = -(p.mx * p.cnx + p.mz * p.cnz); if (dd > 0.3) { p.pb = b; b.nqx -= p.cnx * dd; b.nqz -= p.cnz * dd; if (!p.ai) b.hp = 0.6; } }
    }
    for (const k of W.pk) surf(p, k, 0);
  }
  function collide(W) {
    const B = W.bx, P = W.P;
    for (const b of B) { b.gr = 0; b.sup = null; b.svx = b.svy = b.svz = 0; b.bkx = b.bkz = 0; }
    for (const p of P) if (p && !p.off) { p.wgr = p.gr; p.pvy = p.vy; p.pb = p.ps = null; p.gr = 0; p.sup = null; p.svx = p.svy = p.svz = 0; p.hitH = 0; }
    const ord = B.slice().sort((a, b) => a.y - b.y);
    for (let it = 0; it < 4; it++) {
      for (let i = 0; i < ord.length; i++) {
        const b = ord[i];
        for (const o of W.st) if (o.x1 > b.x - b.hx && o.x0 < b.x + b.hx) boxFix(b, o, o.vx, 0, o.vz);
        for (const o of W.mv) boxFix(b, o, o.vx, o.vy, o.vz);
        for (const s of W.sl) boxFix(b, s, s.vx, 0, s.vz);
        for (let j = 0; j < i; j++) boxBox(ord[j], b);
        for (const k of W.pk) surf(b, k, b.hy);
      }
    }
    for (const p of P) {   // 끄는 사람은 물체에 붙임
      if (!p || p.off || !p.g || p.mt || p.g.hd) continue; const g = p.g;
      if ((g.k === 'b' && !g.carry) || g.k === 'd') { const o = g.k === 'b' ? B[g.i] : W.sl[g.i]; p.x = o.x + g.ox; p.z = o.z + g.oz; }
    }
    for (let it = 0; it < 3; it++) {
      for (let i = 0; i < P.length; i++) { const p = P[i]; if (!p || p.off) continue; plAll(W, p); for (let j = i + 1; j < P.length; j++) if (P[j] && !P[j].off) plPl(p, P[j]); }
    }
    constraints(W);
    for (const p of P) if (p && !p.off) plAll(W, p);
    /* 미닫이 · 수레가 끼인 것을 밀고 있으면 물러남 */
    for (const s of W.sl) {
      const mv = s.s - s.os; if (Math.abs(mv) < 1e-6) continue; const d = Math.sign(mv); let back = 0;
      const chk = (x0, x1, y0, y1, z0, z1) => { if (y1 <= s.y0 + 0.02 || y0 >= s.y1 - 0.02) return; const ox = Math.min(x1, s.x1) - Math.max(x0, s.x0), oz = Math.min(z1, s.z1) - Math.max(z0, s.z0); if (ox <= 0.02 || oz <= 0.02) return; back = Math.max(back, s.ax === 0 ? ox : oz); };
      for (const b of B) if (b.held < 0) chk(b.x - b.hx, b.x + b.hx, b.y - b.hy, b.y + b.hy, b.z - b.hz, b.z + b.hz);
      for (const p of P) if (p && !p.off) chk(p.x - PR * 0.7, p.x + PR * 0.7, p.y, p.y + PH, p.z - PR * 0.7, p.z + PR * 0.7);
      if (back > 0) { s.s = clamp(s.s - d * Math.min(back, Math.abs(mv) + 0.02), s.min, s.max); s.v = 0; slBox(s); }
    }
  }
  function soft(p, ax, ay, az, maxd, rigid) {
    const dx = p.x - ax, dy = p.y + SH - ay, dz = p.z - az, d = hyp(dx, dy, dz);
    if (d <= maxd || d < 1e-6) return d;
    const e = rigid ? d - maxd : Math.min(d - maxd, 5 * DT), nx = dx / d, ny = dy / d, nz = dz / d;
    p.x -= nx * e; p.y -= ny * e; p.z -= nz * e;
    const vr = p.vx * nx + p.vy * ny + p.vz * nz; if (vr > 0) { p.vx -= nx * vr; p.vy -= ny * vr; p.vz -= nz * vr; }
    return d;
  }
  function constraints(W) {
    for (const p of W.P) {
      if (!p || p.off || !p.g) continue; const g = p.g;
      if (g.k === 'r') { const r = W.rp[g.i]; soft(p, r.ax, r.ay, r.az, g.L, true); r.bx = p.x; r.by = p.y + SH; r.bz = p.z; continue; }
      if (g.carry) { const b = W.bx[g.i]; if (hyp(b.x - p.x, b.y - p.y - 1, b.z - p.z) > 2.1) drop(W, p); continue; }
      const A = gripPoint(W, g); p.gw = A;
      if (g.k === 'l') { soft(p, A[0], A[1], A[2], 1.15); continue; }
      if (g.k === 'p') {
        const q = W.P[g.i], dx = p.x - q.x, dy = p.y + SH - (q.y + 1), dz = p.z - q.z, d = hyp(dx, dy, dz);
        if (!p.mt && d > 0.85) { const e = Math.min(d - 0.85, 0.1), wp = p.gr ? 0.3 : 1, wq = q.g && (q.g.k === 's' || q.g.k === 'm') ? 0.08 : q.gr ? 0.3 : 1, s = e / (wp + wq) / d; p.x -= dx * s * wp; p.y -= dy * s * wp; p.z -= dz * s * wp; q.x += dx * s * wq; q.y += dy * s * wq; q.z += dz * s * wq; const rv = ((p.vx - q.vx) * dx + (p.vy - q.vy) * dy + (p.vz - q.vz) * dz) / d; if (rv > 0) { const k = rv / (wp + wq) / d; p.vx -= dx * k * wp; p.vy -= dy * k * wp; p.vz -= dz * k * wp; q.vx += dx * k * wq; q.vy += dy * k * wq; q.vz += dz * k * wq; } }
        if (d > 2.2) drop(W, p); continue;
      }
      if (p.mt) continue;
      if ((g.k === 'b' || g.k === 'd') && !g.hd) { const o = g.k === 'b' ? W.bx[g.i] : W.sl[g.i]; if (Math.abs(p.y - o.y - g.oy) > 1.0 || (!p.gr && !p.wgr && p.coy < -0.3)) drop(W, p); continue; }
      const d = soft(p, A[0], A[1], A[2], g.hd ? 1.0 : p.gr ? 0.95 : ARM);
      if (d > 2.0) drop(W, p);
    }
  }

  /* ======================= 걸음 마무리 ======================= */
  const isBody = (o) => o && (o.T === 'bx' || o.T === 'pl');
  function post(W) {
    const dt = DT, all = [];
    for (const b of W.bx) { b.ld = 0; all.push(b); }
    for (const p of W.P) if (p && !p.off) { p.ld = 0; all.push(p); }
    all.sort((a, b) => b.y - a.y);
    for (const s of W.sl) s.rid = 0;
    for (const p of W.pt) p.load = 0;
    for (const o of all) {
      const w = o.m + o.ld, s = o.sup;
      if (!o.gr || !s) continue;
      if (isBody(s)) s.ld += w;
      else {
        if (s.T === 'pk') s.tq -= w * GRAV * (o.x - s.px);
        if (s.T === 'sl') s.rid += o.T === 'pl' ? 1 : 0.5;
        const by = o.T === 'pl' ? o.y : o.y - o.hy;
        for (const p of W.pt) if (Math.abs(o.x - p.x) <= p.hw && Math.abs(o.z - p.z) <= p.hd && Math.abs(by - p.y) < 0.3) p.load += w;
      }
    }
    for (const b of W.bx) {
      if (b.held < 0) { /* 끌던 사람이 밀려나 떨어지면 놓게: 위치 어긋남 검사 */ }
      if (b.y < W.killY || !isFinite(b.x + b.y + b.z)) { b.x = b.home[0]; b.y = b.home[1] + 0.3; b.z = b.home[2]; b.vx = b.vy = b.vz = 0; if (b.held >= 0) { const p = W.P[b.held]; if (p) drop(W, p); b.held = -1; } ev(W, 'boxback', b.i); }
    }
    let hum = 0; for (const p of W.P) if (p && !p.off && !p.ai) hum++;
    for (const p of W.P) {
      if (!p || p.off) continue;
      const g = p.g;
      if (g && ((g.k === 'b' && !g.carry) || (g.k === 'd' && !g.hd)) && !p.mt) { const o = g.k === 'b' ? W.bx[g.i] : W.sl[g.i]; if (hyp(p.x - o.x - g.ox, p.z - o.z - g.oz) > 0.45) drop(W, p); }
      if (p.gr) {
        if (!p.wgr) { const imp = -p.pvy; if (imp > 13.5) { p.stun = 0.8; drop(W, p); ev(W, 'thud', p.seat, Math.round(imp)); } else if (imp > 4) ev(W, 'land', p.seat, Math.round(imp)); p.air = 0; }
        p.coy = 0.12; p.gt += dt;
      } else { p.coy -= dt; p.gt = 0; }
      if (p.y < W.killY || !isFinite(p.x + p.y + p.z)) { p.falls++; S.spawn(W, p); ev(W, 'fall', p.seat); }
    }
    /* 기점 · 끝 */
    const lead = (p) => p && !p.off && (hum ? !p.ai : true);
    for (let j = W.yards.length - 1; j > W.cpi; j--) {
      const c = W.yards[j].cp;
      if (W.P.some((p) => lead(p) && p.gr && p.x >= c[0] - 1.2 && Math.abs(p.y - c[1]) < 1.2)) { W.cpi = j; W.yT = 0; ev(W, 'cp', j); break; }
    }
    W.yT += dt;
    if (W.fin && !W.done) { const f = W.fin; let ok = 0, need = 0; for (const p of W.P) if (lead(p)) { need++; if (p.gr && p.x >= f[0] - 2.6 && Math.abs(p.y - f[1]) < 1.2) ok++; } W.finN = ok; W.finNeed = need; if (need && ok >= need) { W.done = 1; ev(W, 'done'); } }
  }
  S.resetYard = function (W, j) {
    const Y = W.yards[j]; if (!Y) return;
    const inY = (x) => x >= Y.x0 - 0.5 && x < Y.x1 + 0.5;
    for (const b of W.bx) if (inY(b.home[0])) { if (b.held >= 0) { const p = W.P[b.held]; if (p) drop(W, p); b.held = -1; } b.x = b.home[0]; b.y = b.home[1] + 0.05; b.z = b.home[2]; b.vx = b.vy = b.vz = 0; }
    for (const s of W.sl) if (inY(s.p[0])) { s.s = 0; s.v = 0; slBox(s); }
    for (const p of W.P) if (p && p.g && (p.g.k === 'b' || p.g.k === 'd')) drop(W, p);
    W.resets++; ev(W, 'reset', j);
  };
  S.step = function (W) {
    W.t += DT;
    mech(W); grips(W); objVel(W);
    for (const p of W.P) if (p && !p.off) ctrl(W, p);
    for (const b of W.bx) { b.x += b.vx * DT; b.y += b.vy * DT; b.z += b.vz * DT; }
    for (const p of W.P) if (p && !p.off) { p.vy = Math.max(p.vy, -30); p.x += p.vx * DT; p.y += p.vy * DT; p.z += p.vz * DT; }
    collide(W); post(W);
  };
  /* 입력 넣기(사람 · 봇 · 온라인 손님 공통) */
  S.input = function (p, i) {
    const m = hyp(i.mx || 0, i.mz || 0), k = m > 1 ? 1 / m : 1;
    p.mx = (i.mx || 0) * k; p.mz = (i.mz || 0) * k;
    if (i.ay != null) p.ay = i.ay; if (i.pit != null) p.pit = clamp(i.pit, -1.1, 1.2);
    p.grab = !!i.grab;
    if (i.jump && !p.jump) p.jq = 0.16;
    p.jump = !!i.jump;
  };

  /* ======================= 봇 ======================= */
  /* (x, z)에 발 디딜 곳이 있는가(높이 y 근처) — 봇이 사람을 따라가다 떨어지지 않게 */
  function gnd(W, x, z, y) {
    for (const o of W.st) if (x >= o.x0 && x <= o.x1 && z >= o.z0 && z <= o.z1 && o.y1 <= y + 0.6 && o.y1 >= y - 0.9 && !o.cv) return true;
    for (const o of W.bx) if (Math.abs(x - o.x) <= o.hx && Math.abs(z - o.z) <= o.hz && o.y + o.hy <= y + 0.6 && o.y + o.hy >= y - 0.9) return true;
    return false;
  }
  const yardOf = (W, x) => { const Y = W.yards; for (let j = Y.length - 1; j >= 0; j--) if (x >= Y[j].x0) return j; return 0; };
  S.yardOf = yardOf;
  const val = (v, W, p) => (typeof v === 'function' ? v(W, p) : v);
  function botInit(W, p) { const r = W.rnd; p.bot = { yi: -1, si: -1, ss: {}, blk: 0, side: 0, sameT: 0, hab: { side: r() < 0.5 ? -1 : 1, dist: 1.8 + r() * 1.6, eager: 0.75 + r() * 0.5, slop: r() }, pz: 0, npz: 3 + r() * 5, lag: 0, fol: 0, beh: 0 }; }
  function goTo(W, p, I, x, z, r, fast) {
    const dx = x - p.x, dz = z - p.z, d = hyp(dx, dz);
    if (d > (r == null ? 0.22 : r)) { const k = fast ? 1 : clamp(d / 0.6, 0.4, 1); I.mx = dx / d * k; I.mz = dz / d * k; I.ay = Math.atan2(dx, dz); }
    return d;
  }
  function face(p, I, x, y, z) { const dx = x - p.x, dz = z - p.z; I.ay = Math.atan2(dx, dz); I.pit = Math.atan2(y - (p.y + SH), hyp(dx, dz) || 0.01); }
  function via(W, p, I, s, ss) {
    const v = val(s.via, W, p); if (!v) return true;
    ss.vi = ss.vi || 0; if (ss.vi >= v.length) return true;
    if (goTo(W, p, I, v[ss.vi][0], v[ss.vi][1], 0.45, true) <= 0.45) ss.vi++;
    return ss.vi >= v.length && false;
  }
  const ACT = {
    go(W, p, I, s, ss) {
      if (!via(W, p, I, s, ss)) return;
      const t = val(s.to, W, p), d = goTo(W, p, I, t[0], t[1], 0.25, true);
      if (s.j) for (const jv of s.j) { const jx = val(jv, W, p); if (p.gr && p.x >= jx - 0.32 - ss.jit && p.x <= jx + 0.2 && I.mx > 0.3) I.jump = true; }
      if (s.hop && p.gr && d < 1.5 && d > 0.2 && val(s.hop, W, p) > p.y + 0.3) I.jump = true;
      if (!p.gr && s.g) { const c = S.findGrip(W, p, I.ay, 0.5); if (c && c.top && c.k !== 'p') { I.grab = true; I.pit = 0.5; } }
      if (p.g && p.g.top) { I.grab = true; I.jump = true; I.pit = 0.5; }
    },
    climb(W, p, I, s, ss) {
      const h = val(s.h, W, p), f = s.face || [1, 0];
      if (p.g && p.g.top && p.g.k !== 'p') { I.grab = true; I.jump = true; I.ay = Math.atan2(f[0], f[1]); I.pit = 0.6; return; }
      if (!via(W, p, I, s, ss)) return;
      const t = val(s.at, W, p), d = goTo(W, p, I, t[0], t[1], 0.28);
      if (d < 0.5 || (p.hitH && d < 1.0) || !p.gr) {
        I.ay = Math.atan2(f[0], f[1]); I.pit = 0.7; if (d < 0.5 || !p.gr) { I.mx = f[0] * 0.55; I.mz = f[1] * 0.55; }
        const c = S.findGrip(W, p, I.ay, 0.7);
        if (c && c.top && c.k !== 'p' && c.y >= h - 0.35) I.grab = true;
        else if (p.gr) { ss.t = (ss.t || 0) + DT; if (ss.t > 0.2) { I.jump = true; ss.t = -0.5; } }
      }
    },
    push(W, p, I, s, ss) {
      const b = W.bx[s.b], t = val(s.to, W, p), dx = t[0] - b.x, dz = t[1] - b.z, d = hyp(dx, dz) || 0.001;
      if (p.g && p.g.k === 'b' && p.g.i === s.b && !p.g.carry) { I.grab = true; const k = clamp(d / 0.4, 0.3, 1); I.mx = dx / d * k; I.mz = dz / d * k; I.ay = Math.atan2(b.x - p.x, b.z - p.z); I.pit = -0.2; return; }
      const ux = dx / d, uz = dz / d, ext = Math.abs(ux) * b.hx + Math.abs(uz) * b.hz + PR + 0.12;
      let gx = b.x - ux * ext, gz = b.z - uz * ext;
      const rel = (p.x - b.x) * ux + (p.z - b.z) * uz, lat = (p.x - b.x) * -uz + (p.z - b.z) * ux;
      if (rel > -ext + 0.35 && Math.abs(lat) < Math.max(b.hx, b.hz) + PR + 0.1) { const sd = lat >= 0 ? 1 : -1, w = Math.max(b.hx, b.hz) + PR + 0.5; gx = b.x - uz * sd * w - ux * Math.min(ext, Math.max(-ext, -rel - 0.6)); gz = b.z + ux * sd * w - uz * Math.min(ext, Math.max(-ext, -rel - 0.6)); goTo(W, p, I, gx, gz, 0.2, true); return; }
      const dd = goTo(W, p, I, gx, gz, 0.2);
      if (dd < 0.45) { face(p, I, b.x, b.y, b.z); I.grab = true; }
    },
    drag(W, p, I, s, ss) {
      const sl = W.sl[s.i], dir = s.s >= sl.s ? 1 : -1;
      if (p.g && p.g.k === 'd' && p.g.i === s.i) { I.grab = true; if (sl.ax === 0) I.mx = dir; else I.mz = dir; face(p, I, p.gw[0], p.gw[1], p.gw[2]); return; }
      const hp = sl.hd ? [sl.x + sl.hd[0], sl.y + sl.hd[1], sl.z + sl.hd[2]] : [sl.x, sl.y, sl.z], o = s.off || [-0.75, 0];
      if (!via(W, p, I, s, ss)) return;
      const dd = goTo(W, p, I, hp[0] + o[0], hp[2] + o[1], 0.25);
      if (dd < 0.5) { face(p, I, hp[0], hp[1], hp[2]); I.grab = true; }
    },
    carry(W, p, I, s, ss) {
      const b = W.bx[s.b], hd = S.holdDist(b);
      if (b.held >= 0 && b.held !== p.seat) { const w = val(s.wait, W, p); if (w) goTo(W, p, I, w[0], w[1] + (p.seat - 1.5) * 0.8, 0.5); return; }
      if (b.held === p.seat) {
        I.grab = true; I.ay = p.ay; I.pit = 0.1;
        if (!via(W, p, I, s, ss)) { I.grab = true; I.pit = 0.1; return; }
        const t = val(s.to, W, p), dx = t[0] - p.x, dz = t[2] - p.z, d = hyp(dx, dz) || 0.001;
        I.ay = Math.atan2(dx, dz); I.pit = clamp((t[1] + 0.14 - p.y - 1.05) / 0.95, -0.95, 1);
        if (d > hd + 0.1) { const k = clamp((d - hd) / 0.5, 0.35, 1); I.mx = dx / d * k; I.mz = dz / d * k; }
        else if (d < hd - 0.3) { I.mx = -dx / d * 0.5; I.mz = -dz / d * 0.5; }
        ss.ct = (ss.ct || 0) + DT;
        const near = hyp(b.x - t[0], b.z - t[2]);
        if ((near < 0.25 && b.y >= t[1] - 0.06) || (ss.ct > 6 && near < 0.8 && b.y >= t[1] - 0.06 && hyp(p.vx, p.vz) < 0.3)) { I.grab = false; ss.rel = 0.5; }
        return;
      }
      if (ss.rel > 0) { ss.rel -= DT; return; }
      ss.ct = 0; ss.vi = 0;
      const dd = goTo(W, p, I, b.x, b.z, hd + 0.05);
      if (dd < hd + 0.3) { face(p, I, b.x, b.y, b.z); if (dd < hd + 0.15) I.grab = true; }
    },
    lever(W, p, I, s, ss) {
      const li = val(s.i, W, p), l = W.lv[li];
      if (l.held && !(p.g && p.g.k === 'l' && p.g.i === li)) return 'skip';
      if (p.g && p.g.k === 'l' && p.g.i === li) { I.grab = true; face(p, I, l.x, l.y, l.z); return; }
      if (!via(W, p, I, s, ss)) return;
      const o = s.off || [-0.7, 0], dd = goTo(W, p, I, l.x + o[0], l.z + o[1], 0.3);
      if (dd < 0.6) { face(p, I, l.x, l.y, l.z); I.grab = true; }
    },
    stand(W, p, I, s, ss) { if (!via(W, p, I, s, ss)) return; const t = val(s.at, W, p); goTo(W, p, I, t[0], t[1] + (s.spread ? (p.seat - (W.P.length - 1) / 2) * s.spread : 0), 0.3); if (s.hop && p.gr && val(s.hop, W, p) > p.y + 0.3 && hyp(t[0] - p.x, t[1] - p.z) < 1.5) I.jump = true; },
    wait() {},
    plate(W, p, I, s, ss) {
      const pt = W.pt[s.i]; let bl = 0;
      const on = (b) => Math.abs(b.x - pt.x) <= pt.hw && Math.abs(b.z - pt.z) <= pt.hd && b.held < 0;
      for (const bi of s.boxes || []) if (on(W.bx[bi])) bl += W.bx[bi].m;
      const spot = (k) => [pt.x + ((k % 2) - 0.5) * pt.hw * 0.9, pt.z + ((k >> 1) - 0.5) * pt.hd * 0.9];
      if (W.P.length >= pt.need - bl) { const t = spot(p.seat); goTo(W, p, I, t[0], t[1], 0.25); return; }
      let k = 0;
      for (const bi of s.boxes || []) { const b = W.bx[bi]; if (on(b)) { k++; continue; } if (b.held >= 0 && b.held !== p.seat) { k++; continue; } const t = spot(3 - k); return ACT.carry(W, p, I, { b: bi, to: [t[0], pt.y + b.hy, t[1]] }, ss); }
      const t = spot(0); goTo(W, p, I, t[0], t[1], 0.25);
    },
    rope(W, p, I, s, ss) {
      const r = W.rp[s.i], f = s.from;
      if (p.g && p.g.k === 'r') { ss.sw = (ss.sw || 0) + DT; I.mx = 1; I.ay = Math.PI / 2; I.pit = 0.4; I.grab = !((p.x > r.ax + s.rel && p.vx > 0.3 && p.vy > -1) || (ss.sw > 1.2 && p.x > r.ax + s.rel * 0.75 && p.vx < 0.4 && p.vx > -0.2)); if (!I.grab) I.jump = true; return; }
      ss.sw = 0;
      if (!p.gr) { I.mx = 1; I.ay = Math.PI / 2; I.pit = 0.55; I.grab = p.x > f[0] + 0.2; return; }
      if (p.x > f[0] + 0.5) return;   // 건너편에 내림
      if (!ss.run) { if (goTo(W, p, I, f[0] - 2.4, f[1], 0.4, true) <= 0.4) ss.run = 1; return; }
      I.mx = 1; I.mz = clamp((f[1] - p.z) * 2, -0.3, 0.3); I.ay = Math.PI / 2;
      if (p.x >= f[0] - 0.3 - ss.jit) { I.jump = true; ss.run = 0; }
    },
    hang(W, p, I, s, ss) {
      if (p.g && p.g.top && p.g.k === 's') { if (p.x >= s.rx) { I.grab = false; return; } I.grab = true; I.mx = 1; I.ay = Math.PI / 2; I.pit = 0.5; return; }
      if (p.x >= s.rx - 0.3) { I.mx = 1; return; }
      const t = s.at, f = s.face, d = goTo(W, p, I, t[0], t[1], 0.25);
      if (d < 0.4 || !p.gr) { I.ay = Math.atan2(f[0], f[1]); I.pit = 0.9; I.mx = I.mz = 0; const c = S.findGrip(W, p, I.ay, 0.9); if (c && c.top && c.k === 's') I.grab = true; else if (p.gr) { ss.t = (ss.t || 0) + DT; if (ss.t > 0.25) { I.jump = true; ss.t = -0.6; } } }
    },
    ferry(W, p, I, s, ss, mode) {
      const sl = W.sl[s.i], l = W.lv[s.lv], on = p.sup === sl || (p.gr && Math.abs(p.x - sl.x) < sl.hx + 0.25 && Math.abs(p.z - sl.z) < sl.hz + 0.25 && Math.abs(p.y - sl.y1) < 0.3);
      if (sl.s >= sl.max - 0.06 && (on || p.x > s.exit[0] - 3.2)) { goTo(W, p, I, s.exit[0], s.exit[1], 0.3, true); return; }
      if (on) {
        const hum = W.P.some((q) => q && !q.ai && !q.off && q.sup === sl);
        ss.bt = (ss.bt || 0) + DT;
        const mine = !W.P.some((q) => q && q !== p && q.ai && !q.off && q.sup === sl && q.seat < p.seat);
        if (mine && (!hum || ss.bt > 2.5 + (3 - p.lv) * 1.2) && !(l.held && !(p.g && p.g.k === 'l'))) { if (p.g && p.g.k === 'l') { I.grab = true; face(p, I, l.x, l.y, l.z); } else { const dd = goTo(W, p, I, l.x - 0.75, l.z, 0.25); if (dd < 0.5) { face(p, I, l.x, l.y, l.z); I.grab = true; } } }
        else goTo(W, p, I, sl.x - 0.5, sl.z + (p.seat - 1.5) * 0.6, 0.3);
        return;
      }
      ss.bt = 0;
      if (sl.s < 0.5 && !l.held) goTo(W, p, I, sl.x - 0.4, sl.z + (p.seat - 1.5) * 0.6, 0.3, true);
      else goTo(W, p, I, s.wait[0], s.wait[1] + (p.seat - 1.5) * 0.9, 0.4);
    },
    cat(W, p, I, s, ss, mode) {
      if (!p.gr && p.air) { I.mx = 1; I.ay = Math.PI / 2; return; }
      const k = W.pk[s.i], c = k.cat, l = W.lv[s.lv], sp = [k.px + c.side * k.L * 0.72, k.pz + (p.seat - (W.P.length - 1) / 2) * 0.7];
      const here = (q) => q && !q.off && q.x < s.gx && !(q.stun > 0);
      const puller = !W.P.some((q) => q && q !== p && q.ai && here(q) && q.seat < p.seat);
      const humOn = W.P.some((q) => q && !q.ai && !q.off && q.sup === k && (q.x - k.px) * c.side > k.L * 0.3);
      if (c.st === 0 && puller && (mode === 'lead' || humOn)) {
        ss.w = (ss.w || 0) + DT;
        if (mode === 'lead' || ss.w > 1.5 + (3 - p.lv)) { if (p.g && p.g.k === 'l') { I.grab = true; return; } const dd = goTo(W, p, I, l.x - 0.7, l.z, 0.3, true); if (dd < 0.6) { face(p, I, l.x, l.y, l.z); I.grab = true; } return; }
      } else ss.w = 0;
      if (c.st === 3 && k.th !== (c.side < 0 ? k.lim : -k.lim)) { goTo(W, p, I, sp[0] + c.side * 0.2, sp[1] + 2.2, 0.4); return; }
      goTo(W, p, I, sp[0], sp[1], 0.3, true);
    },
  };
  function runSteps(W, p, I, Y, mode) {
    const b = p.bot, St = Y.steps || [];
    for (let i = 0; i < St.length; i++) {
      const s = St[i];
      if (mode === 'help' && !s.h) continue;
      if (!p.gr && b.yi === Y.i && i < b.si) continue;   // 뛰어오른 동안에는 앞 단계로 되돌아가지 않음
      if (s.done && s.done(W, p, mode)) continue;
      if (s.when && !s.when(W, p, mode)) continue;
      if (b.yi !== Y.i || b.si !== i) { b.yi = Y.i; b.si = i; b.ss = { jit: (p.lv === 1 ? 0.55 : p.lv === 2 ? 0.15 : 0) * (W.rnd() - 0.3) }; b.sameT = 0; }
      const r = ACT[s.a](W, p, I, s, b.ss, mode);
      if (r === 'skip') continue;
      return s;
    }
    return null;
  }
  S.bot = function (W, p) {
    if (!p.bot) botInit(W, p);
    const b = p.bot, lv = p.lv || 2, I = { mx: 0, mz: 0, grab: false, jump: false, ay: p.ay, pit: 0 };
    if (p.stun > 0 || W.done) { S.input(p, I); return; }
    if (b.pz > 0) { b.pz -= DT; S.input(p, I); return; }
    if (lv < 3) { b.npz -= DT; if (b.npz <= 0) { b.npz = (lv === 1 ? 5 : 11) + W.rnd() * 6; if (p.gr && !p.g) { b.pz = lv === 1 ? 0.5 + W.rnd() * 0.5 : 0.2; S.input(p, I); return; } } }
    const yi = yardOf(W, p.x), Y = W.yards[yi];
    let H = null, hd = 1e9;
    if (!p.auto) for (const q of W.P) if (q && q !== p && !q.ai && !q.off) { const d = hyp(q.x - p.x, q.z - p.z); if (d < hd) { hd = d; H = q; } }   // p.auto: 시험용(사람 자리를 봇이 앞장서 조작)
    /* 뒤처지면 기점으로 */
    if (yi < W.cpi) { b.beh += DT; if (b.beh > 14) { b.beh = 0; S.spawn(W, p); W.warps++; S.input(p, I); return; } } else b.beh = 0;
    let s = null, mode = 'lead';
    const leadT = (lv === 3 ? 50 : lv === 2 ? 65 : 85) * b.hab.eager;
    if (H && !(W.yT > leadT && yi >= W.cpi)) {
      const yh = yardOf(W, H.x);
      if (yi < yh || (yi === yh && Y.gx != null && H.x > Y.gx && p.x < Y.gx)) mode = 'lead';
      else {
        mode = 'help';
        /* 사람이 미는 것을 같이 밀기 */
        let jb = null; for (const x of W.bx) if (x.hp > 0 && x.held < 0 && hyp(x.x - p.x, x.z - p.z) < 9) jb = x;
        if (jb && lv >= 2 - (b.hab.slop > 0.6 ? 0 : 0)) { ACT.push(W, p, I, { b: jb.i, to: [jb.x + jb.lqx * 3, jb.z + jb.lqz * 3] }, b.ss); s = 1; }
      }
    }
    if (!s) s = runSteps(W, p, I, Y, mode);
    if (!s && mode === 'lead') { const n = W.yards[yi + 1], t = n ? n.cp : W.fin; goTo(W, p, I, t[0] + 0.6, t[2] + (p.seat - (W.P.length - 1) / 2) * 0.9, 0.4, true); s = 2; }
    if (!s && H) {   // 따라다니기
      const d = hyp(H.x - p.x, H.z - p.z), tx = H.x - Math.sin(H.yaw) * b.hab.dist + Math.cos(H.yaw) * b.hab.side * 1.1, tz = H.z - Math.cos(H.yaw) * b.hab.dist - Math.sin(H.yaw) * b.hab.side * 1.1;
      if ((d > b.hab.dist + 0.8 || b.fol > 0) && H.gr && Math.abs(H.y - p.y) < 2.6) { b.fol = d > b.hab.dist * 0.7 ? 0.5 : b.fol - DT; goTo(W, p, I, tx, tz, 0.5); { const m = hyp(I.mx, I.mz); if (m > 0.05 && !(gnd(W, p.x + I.mx / m * 0.7, p.z + I.mz / m * 0.7, p.y) && gnd(W, p.x + I.mx / m * 1.3, p.z + I.mz / m * 1.3, p.y) && gnd(W, tx, tz, p.y))) { I.mx = I.mz = 0; } } if (H.y > p.y + 0.5 && d < 2.5 && p.gr) { I.grab = true; I.pit = 0.6; } if (p.g && p.g.top) { I.grab = true; I.jump = true; } }
    }
    /* 막힘 풀기 */
    const want = hyp(I.mx, I.mz) > 0.3, sp = hyp(p.vx - p.svx, p.vz - p.svz);
    if (want && sp < 0.5 && p.gr && !p.g) { b.blk += DT; if (b.blk > 0.45) { I.jump = true; if (b.blk > 1.6) { const a = Math.atan2(I.mx, I.mz) + b.hab.side * 1.3; I.mx = Math.sin(a); I.mz = Math.cos(a); } if (b.blk > 2.4) { b.blk = 0; b.hab.side = -b.hab.side; } } } else if (b.blk > 0) b.blk = Math.max(0, b.blk - DT * 2);
    if (mode === 'lead' && s && s !== 2 && s !== 1 && s.a !== 'wait' && s.a !== 'stand' && s.a !== 'ferry' && s.a !== 'cat' && s.a !== 'plate') {
      b.sameT += DT;
      if (b.sameT > 40) { b.sameT = 0; b.n40 = (b.n40 || 0) + 1; b.ss = { jit: 0 }; if (p.g) { I.grab = false; } if (b.n40 % 3 === 0 && !H) S.resetYard(W, yi); S.spawn(W, p, Math.min(yi, W.cpi)); W.warps++; }
    }
    /* 점프 단추: 누르면 0.34초 쥐고 있다가 잠깐 뗌(다시 누를 수 있게). 매달려 오르는 중에는 계속 쥠 */
    if (!(p.g && p.g.top && I.jump)) { if (b.jr > 0) { b.jr -= DT; I.jump = false; } else if (b.jh > 0) { b.jh -= DT; I.jump = true; if (b.jh <= 0) b.jr = 0.12; } else if (I.jump) b.jh = 0.34; }
    if (lv === 1) { I.mx *= 0.85; I.mz *= 0.85; } else if (lv === 2) { I.mx *= 0.94; I.mz *= 0.94; }
    S.input(p, I);
  };

  /* ======================= 온라인 묶기 ======================= */
  const r2 = (v) => Math.round(v * 100);
  S.pack = function (W) {
    const p = [], b = [];
    for (const q of W.P) { const g = q.g, w = q.gw; p.push(r2(q.x), r2(q.y), r2(q.z), r2(q.yaw), r2(q.ay), r2(q.pit), (q.gr ? 1 : 0) | (q.grab ? 2 : 0) | (q.stun > 0 ? 4 : 0) | (q.mt ? 8 : 0) | (q.off ? 16 : 0) | (g && g.carry ? 32 : 0), g ? g.k : 0, g ? g.i : 0, w ? r2(w[0]) : 0, w ? r2(w[1]) : 0, w ? r2(w[2]) : 0, q.falls, r2(hyp(q.vx - q.svx, q.vz - q.svz))); }
    for (const x of W.bx) b.push(r2(x.x), r2(x.y), r2(x.z), x.held);
    return { t: Math.round(W.t * 10), c: W.cpi, y: Math.round(W.yT), d: W.done, fn: [W.finN | 0, W.finNeed | 0], p, b,
      m: W.mv.map((m) => Math.round(m.f * 1000)), s: W.sl.map((s) => r2(s.s)), k: W.pk.map((k) => Math.round(k.th * 1000)), kc: W.pk.map((k) => (k.cat ? k.cat.st * 100 + Math.round(Math.max(0, k.cat.t) * 10) : 0)),
      r: W.rp.map((r) => [r2(r.bx), r2(r.by), r2(r.bz), r.held]), l: W.lv.map((l) => (l.on ? 1 : 0) + (l.held ? 2 : 0) + Math.round(Math.max(0, l.tm) * 10) * 4), q: W.pt.map((q) => Math.round(q.load * 10) * 4 + (q.on ? 1 : 0) + (q.lat ? 2 : 0)), cv: W.st.filter((o) => o.cv).map((o) => o.cvOn | 0), e: W.ev.slice(-8) };
  };
  S.unpack = function (W, o) {
    const N = 14;
    W.nt = o.t / 10; W.cpi = o.c; W.yT = o.y; W.done = o.d; W.finN = o.fn[0]; W.finNeed = o.fn[1];
    for (let i = 0; i < W.P.length; i++) {
      const q = W.P[i], a = o.p, j = i * N; if (!q || a[j] == null) continue;
      q.tx = a[j] / 100; q.ty = a[j + 1] / 100; q.tz = a[j + 2] / 100; q.tyaw = a[j + 3] / 100; q.tay = a[j + 4] / 100; q.tpit = a[j + 5] / 100;
      const f = a[j + 6]; q.gr = f & 1; q.grab = !!(f & 2); q.stun = f & 4 ? 0.3 : 0; q.mt = f & 8 ? 1 : 0; q.off = !!(f & 16);
      q.g = a[j + 7] ? { k: a[j + 7], i: a[j + 8], carry: f & 32 ? 1 : 0, net: 1 } : null; q.tgw = a[j + 7] ? [a[j + 9] / 100, a[j + 10] / 100, a[j + 11] / 100] : null;
      q.falls = a[j + 12]; q.nsp = a[j + 13] / 100;
      if (q.nfirst !== 1 || hyp(q.tx - q.x, q.ty - q.y, q.tz - q.z) > 6) { q.x = q.tx; q.y = q.ty; q.z = q.tz; q.yaw = q.tyaw; q.nfirst = 1; q.tp = 1; }
    }
    for (let i = 0; i < W.bx.length; i++) { const b = W.bx[i], j = i * 4; b.tx = o.b[j] / 100; b.ty = o.b[j + 1] / 100; b.tz = o.b[j + 2] / 100; b.held = o.b[j + 3]; if (b.nfirst !== 1 || hyp(b.tx - b.x, b.ty - b.y, b.tz - b.z) > 5) { b.x = b.tx; b.y = b.ty; b.z = b.tz; b.nfirst = 1; } }
    W.mv.forEach((m, i) => { m.tf = o.m[i] / 1000; }); W.sl.forEach((s, i) => { s.ts = o.s[i] / 100; }); W.pk.forEach((k, i) => { k.tth = o.k[i] / 1000; if (k.cat) { k.cat.st = Math.floor(o.kc[i] / 100); k.cat.t = (o.kc[i] % 100) / 10; } });
    W.rp.forEach((r, i) => { const a = o.r[i]; r.tb = [a[0] / 100, a[1] / 100, a[2] / 100]; r.held = a[3]; });
    W.lv.forEach((l, i) => { const v = o.l[i]; l.on = v & 1; l.held = v & 2 ? 1 : 0; l.tm = (v >> 2) / 10; });
    W.pt.forEach((q, i) => { const v = o.q[i]; q.on = v & 1; q.lat = v & 2 ? 1 : 0; q.load = (v >> 2) / 10; });
    let ci = 0; for (const s of W.st) if (s.cv) { s.cvOn = o.cv[ci++]; s.vx = s.cvOn ? s.cv.v1 : s.cv.v0; }
    W.evIn = o.e;
  };
  /* 손님 쪽: 받은 값으로 부드럽게 따라가기 */
  S.netSmooth = function (W, dt, me) {
    const k = Math.min(1, dt * 12);
    for (const q of W.P) { if (!q || q.tx == null) continue; q.x += (q.tx - q.x) * k; q.y += (q.ty - q.y) * k; q.z += (q.tz - q.z) * k; q.yaw += angD(q.yaw, q.tyaw) * k; if (q.seat !== me) { q.ay += angD(q.ay, q.tay) * k; q.pit += (q.tpit - q.pit) * k; } q.gw = q.tgw; }
    for (const b of W.bx) if (b.tx != null) { b.x += (b.tx - b.x) * k; b.y += (b.ty - b.y) * k; b.z += (b.tz - b.z) * k; }
    for (const m of W.mv) if (m.tf != null) m.f += (m.tf - m.f) * k;
    for (const s of W.sl) if (s.ts != null) s.s += (s.ts - s.s) * k;
    for (const p of W.pk) if (p.tth != null) p.th += (p.tth - p.th) * Math.min(1, dt * 20);
    for (const r of W.rp) if (r.tb) { r.bx += (r.tb[0] - r.bx) * k; r.by += (r.tb[1] - r.by) * k; r.bz += (r.tb[2] - r.bz) * k; }
    S.refresh(W);
  };

  G.FLOPPY_SIM = S;
  if (typeof module === 'object' && module) module.exports = S;
})();
