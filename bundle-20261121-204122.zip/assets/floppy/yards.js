/* 흐물 협동 (floppy) — 구역 5 × 마당 4 (지형 · 장치 · 봇 풀이 단계). sim.js 다음에 불러옴. node에서도 돎.
   마당 하나 = 함수 (c) → { nm, goal, hint, len, rise, gx(막힌 곳 x), steps }.  c.x · c.y = 이 마당의 시작 x · 바닥 높이.
   steps: 봇이 「아직 안 끝난 첫 단계」를 수행. done(W, p, mode) / when(W, p, mode), h: 사람을 도울 때도 하는 단계. */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const S = G.FLOPPY_SIM || (typeof require === 'function' ? require('./sim.js') : null);
  const ZW = 5, TH = 1.2, HB = 7.5;
  /* 상자: L 나무 상자(들 수 있음) · H 큰 상자(끌기) · R 돌덩이(더 무거움) */
  const SIZES = { L: [0.45, 0.45, 0.45, 1], H: [0.8, 0.6, 0.8, 3], R: [0.7, 0.6, 0.7, 5] };
  const BOXNM = { L: '나무 상자', H: '큰 상자', R: '돌덩이' };

  function ctx(W) {
    const c = { W, x: 0, y: 0 };
    c.blk = (x0, y0, z0, x1, y1, z1, k, ex) => S.addStatic(W, c.x + x0, c.y + y0, z0, c.x + x1, c.y + y1, z1, k, ex);
    c.fl = (x0, x1, o) => { o = o || {}; return c.blk(x0, -TH, o.z0 == null ? -ZW : o.z0, x1, o.y || 0, o.z1 == null ? ZW : o.z1, o.y ? 'r' : 'f', o.ex); };
    c.box = (x, z, sz, y) => { const s = SIZES[sz]; return S.addBox(W, c.x + x, c.y + (y || 0) + s[1] + 0.01, z, s[0], s[1], s[2], s[3], { sz }).i; };
    /* 가로막(가운데 문 구멍) */
    c.bar = (x, z0, z1, h) => { c.blk(x, 0, -ZW, x + 0.6, HB, z0, 'w', { ng: 1 }); c.blk(x, 0, z1, x + 0.6, HB, ZW, 'w', { ng: 1 }); c.blk(x, h, z0, x + 0.6, HB, z1, 'w', { ng: 1 }); };
    c.gate = (x, z0, z1, h, sig, o) => S.addMover(W, 0.22, h / 2 + 0.3, (z1 - z0) / 2, [c.x + x + 0.3, c.y + h / 2 - 0.3, (z0 + z1) / 2], [c.x + x + 0.3, c.y - h / 2 - 0.36, (z0 + z1) / 2], Object.assign({ sig, spd: 0.9, k: 'gate', ng: 1 }, o || {}));
    c.plate = (x, z, hw, hd, need, sig, o) => S.addPlate(W, c.x + x, c.y, z, hw, hd, need, Object.assign({ sig }, o || {})).i;
    c.lever = (x, z, o) => { o = Object.assign({}, o); const dy = o.y || 0; delete o.y; return S.addLever(W, c.x + x, c.y + 1.1 + dy, z, o).i; };
    return c;
  }
  const hum = (W, f) => W.P.some((q) => q && !q.ai && !q.off && f(q));

  /* ======================= 구역 1 · 야적장 ======================= */
  const y11 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 8); c.fl(8, 14, { y: 1.9 });
    const up = (W, p) => p.y > Y + 1.6 && p.x > X + 7.9;
    return { nm: '낮은 턱', goal: '턱을 잡고 올라서기', hint: '턱 앞에서 잡기를 누른 채 앞으로(또는 점프)를 누르면 몸을 끌어올림.', len: 14, rise: 1.9, gx: X + 8,
      steps: [{ a: 'climb', at: [X + 7.6, 0], h: Y + 1.9, done: up }] };
  };
  const y12 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 12); c.fl(12, 18, { y: 3.6 }); const b = c.box(6, 2, 'L');
    const up = (W, p) => p.y > Y + 3.3 && p.x > X + 11.9, B = (W) => W.bx[b];
    const placed = (W) => { const o = B(W); return o.held < 0 && o.x > X + 11.2 && o.y < Y + 0.7; };
    return { nm: '상자 하나', goal: '상자를 딛고 벽 위로', hint: '나무 상자는 들어서 옮길 수 있음. 벽 앞에 놓고 올라선 뒤, 점프하면서 잡기.', len: 18, rise: 3.6, gx: X + 12,
      steps: [
        { a: 'carry', b, to: [X + 11.5, Y + 0.46, 0], wait: [X + 9, 0], done: (W, p) => up(W, p) || placed(W) },
        { a: 'go', to: (W) => [B(W).x, B(W).z], hop: (W) => B(W).y + 0.45, done: (W, p) => up(W, p) || (p.y > B(W).y + 0.3 && Math.abs(p.x - B(W).x) < 0.5) },
        { a: 'climb', at: (W) => [B(W).x + 0.12, B(W).z], h: Y + 3.6, done: up },
      ] };
  };
  const y13 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 12); c.fl(12, 18, { y: 3.9 }); const b = c.box(5, -1.5, 'H');
    const up = (W, p) => p.y > Y + 3.6 && p.x > X + 11.9, B = (W) => W.bx[b];
    return { nm: '무거운 상자', goal: '큰 상자를 벽에 붙이기', hint: '큰 상자는 들 수 없음. 잡고 끌거나 몸으로 밀기. 여럿이 밀면 빨라짐.', len: 18, rise: 3.9, gx: X + 12,
      steps: [
        { a: 'push', b, to: (W) => [X + 11.17, B(W).z], done: (W, p) => up(W, p) || B(W).x > X + 10.95 },
        { a: 'climb', at: (W) => [B(W).x - 1.13, B(W).z], h: Y + 1.2, done: (W, p) => up(W, p) || p.y > Y + 1.0 },
        { a: 'climb', at: (W) => [B(W).x + 0.38, B(W).z], h: Y + 3.9, done: up },
      ] };
  };
  const y14 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 14); c.fl(14, 20, { y: 4.9 }); const h = c.box(6, 2, 'H'), l = c.box(4, -2, 'L'); c.box(9, -3, 'L');
    const up = (W, p) => p.y > Y + 4.6 && p.x > X + 13.9, Hb = (W) => W.bx[h], Lb = (W) => W.bx[l];
    const stacked = (W) => { const a = Lb(W), b = Hb(W); return a.held < 0 && a.y > b.y + 0.8 && Math.abs(a.x - b.x) < 0.85 && Math.abs(a.z - b.z) < 0.85; };
    return { nm: '쌓기', goal: '상자를 쌓아 높은 벽 넘기', hint: '큰 상자를 벽에 붙이고 그 위에 나무 상자를 올리기. 시선을 올리면 상자를 높이 듦.', len: 20, rise: 4.9, gx: X + 14,
      steps: [
        { a: 'push', b: h, to: (W) => [X + 13.17, Hb(W).z], done: (W, p) => up(W, p) || Hb(W).x > X + 12.95 },
        { a: 'carry', b: l, wait: [X + 10, -1], via: (W) => [[Hb(W).x + 0.3, Hb(W).z - 2.1]], to: (W) => [Hb(W).x + 0.3, Y + 1.66, Hb(W).z], done: (W, p) => up(W, p) || stacked(W) },
        { a: 'climb', at: (W) => [Hb(W).x - 1.13, Hb(W).z], h: Y + 1.2, done: (W, p) => up(W, p) || p.y > Y + 1.0 },
        { a: 'go', to: (W) => [Lb(W).x, Lb(W).z], hop: (W) => Lb(W).y + 0.45, done: (W, p) => up(W, p) || p.y > Y + 1.9 },
        { a: 'climb', at: (W) => [Math.min(Lb(W).x + 0.25, X + 13.7), Lb(W).z], h: Y + 4.9, done: up },
      ] };
  };

  /* ======================= 구역 2 · 창고 ======================= */
  const y21 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 16); c.bar(8, -0.9, 0.9, 2.4);
    const d = S.addSlider(W_, 0.12, 1.2, 1.0, [X + 7.86, Y + 1.2, 0], 2, 2.3, { m: 1.2, spring: { wait: 1.0, v: 0.55 }, hd: [-0.2, -0.1, 0.8], k: 'door' }).i;
    const D = (W) => W.sl[d], thru = (W, p) => p.x > X + 8.75, mine = (p) => p.g && p.g.k === 'd' && p.g.i === d;
    return { nm: '미닫이문', goal: '닫히는 문 지나가기', hint: '손잡이를 잡고 옆으로 끌면 열림. 놓으면 천천히 닫힘. 누가 잡아 주면 편함.', len: 16, rise: 0, gx: X + 8.3,
      steps: [
        { a: 'drag', i: d, s: 2.3, off: [-0.6, 0], h: 1, when: (W, p, m) => m === 'help' && hum(W, (q) => q.x < X + 8.7 && q.x > X + 1), done: () => false },
        { a: 'drag', i: d, s: 2.3, off: [-0.6, 0], done: (W, p) => p.x > X + 7.95 || D(W).s > (mine(p) ? 2.2 : 1.25) },
        { a: 'go', via: (W, p) => (p.x < X + 7.3 ? [[X + 7.25, -0.3]] : null), to: [X + 9.6, -0.3], done: thru },
      ] };
  };
  const y22 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 18); c.bar(12, -1.5, 1.5, 3); c.gate(12, -1.5, 1.5, 3, 'g22');
    const b1 = c.box(4, 3, 'L'), b2 = c.box(5, -3, 'L'), pl = c.plate(7, 0, 1.3, 1.3, 2, 'g22');
    return { nm: '무게 발판', goal: '발판에 무게 둘 올리기', hint: '사람도 나무 상자도 무게 하나. 둘이 올라서거나, 상자를 올려 채우기. 한번 열리면 열린 채.', len: 18, rise: 0, gx: X + 12.6,
      steps: [
        { a: 'plate', i: pl, boxes: [b1, b2], h: 1, done: (W, p) => W.pt[pl].lat || p.x > X + 12.9 },
        { a: 'go', to: [X + 13.6, 0], done: (W, p) => p.x > X + 12.9 },
      ] };
  };
  const y23 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 18); c.bar(12, -1.5, 1.5, 3); const g = c.gate(12, -1.5, 1.5, 3, ['a23', 'b23'], { latch: 1, spd: 0.8 }).i;
    const A = c.lever(6, -3.5, { keep: 5, sig: 'a23' }), B = c.lever(6, 3.5, { keep: 5, sig: 'b23' });
    const open = (W) => W.mv[g].lat, far = (W) => { let z = 0; for (const q of W.P) if (q && !q.ai && !q.off) z += q.z; return z > 0 ? A : B; };
    return { nm: '손잡이 둘', goal: '두 손잡이를 함께 당기기', hint: '손잡이는 놓아도 5초 동안 켜져 있음. 혼자면 하나를 당기고 다른 쪽으로 달리기.', len: 18, rise: 0, gx: X + 12.6,
      steps: [
        { a: 'lever', i: far, h: 1, when: (W, p, m) => m === 'help', done: open },
        { a: 'lever', i: A, when: (W, p, m) => m !== 'help', done: (W) => open(W) || W.lv[A].on },
        { a: 'lever', i: B, when: (W, p, m) => m !== 'help', done: open },
        { a: 'go', to: [X + 13.6, 0], done: (W, p) => p.x > X + 12.9 },
      ] };
  };
  const y24 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 12); c.fl(12, 20, { y: 4.2 });
    const lf = S.addMover(W_, 1.2, 2.4, 1.2, [X + 10.76, Y + 0.25 - 2.4, 0], [X + 10.76, Y + 4.2 - 2.4, 0], { sig: 'l24', spd: 0.22, cyc: { sig: 'au24', per: 11, dw: 0.14 }, k: 'lift' }).i;
    const pl = c.plate(5, 0, 1, 1, 1, 'l24', { latch: 0 }), b = c.box(3, 2.5, 'L'), au = c.lever(13.6, 3, { y: 4.2, mode: 'once', sig: 'au24' });
    const L = (W) => W.mv[lf], up = (W, p) => p.y > Y + 4.0 && p.x > X + 11.9, auto = (W) => W.lv[au].on, B = (W) => W.bx[b];
    const onPl = (W) => { const o = B(W); return o.held < 0 && Math.abs(o.x - X - 5) < 1 && Math.abs(o.z) < 1; };
    const onL = (W, p) => { const m = L(W); return p.sup === m || (p.gr && Math.abs(p.x - m.x) < m.hx + 0.28 && Math.abs(p.z - m.z) < m.hz + 0.28 && Math.abs(p.y - m.y1) < 0.3); };
    const stuck = (W) => !auto(W) && L(W).f > 0.6 && onPl(W) && !W.P.some((q) => q && !q.off && q.x > X + 9 && q.y > Y + 0.4);
    return { nm: '승강대', goal: '승강대를 타고 위로', hint: '발판에 무게가 있으면 승강대가 오름. 상자를 올려 두고 서둘러 타기. 위쪽 손잡이를 당기면 스스로 오르내림.', len: 20, rise: 4.2, gx: X + 12,
      steps: [
        { a: 'stand', at: [X + 5, 0], h: 1, when: (W, p, m) => m === 'help' && !auto(W) && hum(W, (q) => q.x > X + 8 && q.x < X + 12.1 && q.y < Y + 3.9), done: () => false },
        { a: 'carry', b, to: [X + 3, Y + 0.46, 2.5], when: stuck, done: (W) => !stuck(W) },
        { a: 'carry', b, to: [X + 5, Y + 0.46, 0], wait: [X + 8.2, 0], done: (W, p) => up(W, p) || onL(W, p) || auto(W) || onPl(W) },
        { a: 'stand', at: [X + 8.3, 0], spread: 0.7, done: (W, p) => up(W, p) || onL(W, p) || L(W).y1 < Y + 2.6 },
        { a: 'climb', at: [X + 9.2, 0], h: (W) => L(W).y1, done: (W, p) => up(W, p) || onL(W, p) },
        { a: 'stand', at: (W) => [L(W).x, 0], done: (W, p) => up(W, p) || L(W).y1 > Y + 4.12 },
        { a: 'go', to: [X + 13.3, 0], done: up },
        { a: 'lever', i: au, done: auto },
      ] };
  };

  /* ======================= 구역 3 · 부두 ======================= */
  const y31 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 8); c.fl(12.6, 20);
    c.blk(10.15, 6.3, -5.5, 10.45, 6.6, 5.5, 'beam', { ng: 1 }); c.blk(10.1, -TH, 5.3, 10.5, 6.6, 5.7, 'post', { ng: 1 }); c.blk(10.1, -TH, -5.7, 10.5, 6.6, -5.3, 'post', { ng: 1 });
    const r = S.addRope(W_, X + 10.3, Y + 6.3, 0, 4.9).i;
    return { nm: '밧줄', goal: '밧줄로 틈 건너기', hint: '달려가 점프하면서 잡기를 누르고 있으면 밧줄을 잡음. 앞으로 흔들릴 때 놓기.', len: 20, rise: 0, gx: X + 12.6,
      steps: [{ a: 'rope', i: r, from: [X + 8, 0], rel: 1.5, done: (W, p) => p.x > X + 12.6 && p.gr }] };
  };
  const y32 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 8); c.fl(13, 21);
    const s = S.addSlider(W_, 0.9, 0.25, 0.9, [X + 5, Y + 0.25, 0], 0, 5.5, { m: 2, auto: { from: 3.05, v: 1.7 }, k: 'cart', rail: [X + 3.6, X + 13] }).i;
    const C = (W) => W.sl[s];
    return { nm: '수레', goal: '수레를 디딤돌로 쓰기', hint: '수레를 가장자리 너머로 밀면 레일 가운데까지 굴러가 멈춤. 수레를 딛고 건너기.', len: 21, rise: 0, gx: X + 13,
      steps: [
        { a: 'drag', i: s, s: 5.5, off: [-1.32, 0], done: (W, p) => C(W).s > 3.1 || p.x > X + 13 },
        { a: 'stand', at: [X + 7.2, 0], spread: 0.7, done: (W, p) => C(W).s >= 5.45 || p.x > X + 8.3 },
        { a: 'go', to: [X + 14.4, 0], j: [X + 8.0, X + 11.42], g: 1, done: (W, p) => p.x > X + 13.1 && p.gr },
      ] };
  };
  const y33 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 8); c.fl(20, 26);
    const s = S.addSlider(W_, 1.3, 0.25, 1.3, [X + 9.33, Y - 0.25, 0], 0, 9.34, { k: 'ferry', ng: 1, rail: [X + 8, X + 20] });
    const l = S.addLever(W_, 0.8, 1.3, 0, { sl: s.i, mode: 'hold' }); s.drive = { lv: l.i, v: 2.2, ret: 2.6 };
    return { nm: '나룻수레', goal: '나룻수레를 타고 건너기', hint: '올라타서 손잡이를 잡고 있으면 나아감. 아무도 타지 않으면 스스로 돌아옴.', len: 26, rise: 0, gx: X + 20,
      steps: [{ a: 'ferry', i: s.i, lv: l.i, h: 1, wait: [X + 6.4, 0], exit: [X + 21.6, 0], done: (W, p) => p.x > X + 20.2 }] };
  };
  const y34 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 8); c.fl(16, 24);
    c.blk(7, 2.6, -0.2, 17, 2.9, 0.2, 'beam');
    for (const x of [7, 17]) { c.blk(x - 0.15, 2.9, -2.75, x + 0.15, 3.15, 2.75, 'beam', { ng: 1 }); c.blk(x - 0.15, 0, 2.45, x + 0.15, 2.9, 2.75, 'post', { ng: 1 }); c.blk(x - 0.15, 0, -2.75, x + 0.15, 2.9, -2.45, 'post', { ng: 1 }); }
    return { nm: '들보', goal: '들보에 매달려 건너기', hint: '점프해서 들보를 잡고, 매달린 채 방향키로 옮겨 감. 점프를 누르면 들보 위로 올라섬.', len: 24, rise: 0, gx: X + 16,
      steps: [{ a: 'hang', at: [X + 7.7, 0.55], face: [0, -1], rx: X + 16.6, done: (W, p) => p.x > X + 16.2 && p.gr }] };
  };

  /* ======================= 구역 4 · 채석장 ======================= */
  const seesaw = (c, x) => { c.blk(x - 0.2, 0, -1.5, x + 0.2, 0.95, 1.5, 'ful', { ng: 1 }); return S.addPlank(c.W, c.x + x, c.y + 1.1, 0, 4.5, 1.5, 0.224, { rest: 0.224 }).i; };
  const y41 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 14.2); c.fl(14.2, 22, { y: 3.9 }); const k = seesaw(c, 9.5), r = c.box(2.5, -0.75, 'R');
    const up = (W, p) => p.y > Y + 3.6 && p.x > X + 14.1, R = (W) => W.bx[r];
    return { nm: '시소', goal: '시소 끝을 높게 둔 채 오르기', hint: '돌덩이를 시소의 낮은 쪽에 올려 두면, 반대쪽 끝까지 걸어가도 내려가지 않음.', len: 22, rise: 3.9, gx: X + 14.2,
      steps: [
        { a: 'push', b: r, to: [X + 6.0, -0.75], done: (W, p) => up(W, p) || R(W).x > X + 5.6 },
        { a: 'go', via: (W, p) => (p.y > Y + 0.7 ? null : [[X + 4.3, 0.9], [X + 7.6, 0.9]]), to: [X + 13.6, 0], done: (W, p) => up(W, p) || (p.x > X + 13.25 && p.y > Y + 1.7) },
        { a: 'climb', at: [X + 13.62, 0], h: Y + 3.9, done: up },
      ] };
  };
  const y42 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 7); c.fl(10.4, 20);
    c.blk(7, -1.45, 0.45, 10.4, -1.2, 0.65, 'rail', { ng: 1 }); c.blk(7, -1.45, -0.65, 10.4, -1.2, -0.45, 'rail', { ng: 1 });
    const r = c.box(3.5, 0, 'R'), R = (W) => W.bx[r];
    return { nm: '돌 디딤', goal: '돌덩이를 틈에 떨어뜨리기', hint: '돌덩이를 가장자리 너머로 밀어 떨어뜨리면 레일에 걸쳐 디딤돌이 됨. 딛고 건너뛰기.', len: 20, rise: 0, gx: X + 10.4,
      steps: [
        { a: 'push', b: r, to: (W) => [X + 7.9, 0], done: (W, p) => R(W).y < Y - 0.3 || p.x > X + 10.4 },
        { a: 'go', to: [X + 11.8, 0], j: [(W) => R(W).x + 0.62], g: 1, done: (W, p) => p.x > X + 10.5 && p.gr },
      ] };
  };
  const y43 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 28); c.blk(14, 0, -ZW, 14.8, 4.6, ZW, 'w', { ng: 1 });
    c.blk(8.8, 0, -1.2, 9.2, 0.85, 1.2, 'ful', { ng: 1 });
    const l = c.lever(4, 3, { keep: 0.4, sig: 'c43' });
    const k = S.addPlank(W_, X + 9, Y + 1.0, 0, 3.4, 1.2, 0.268, { cat: { sig: 'c43', side: -1, vx: 8.5, vy: 15, delay: 2.5 } }).i;
    return { nm: '투석기', goal: '투석기로 벽 넘기', hint: '손잡이를 당기면 2.5초 뒤 발사. 그 사이에 낮은 쪽 끝에 올라서기. 여럿이 함께 타도 됨.', len: 28, rise: 0, gx: X + 14.8,
      steps: [{ a: 'cat', i: k, lv: l, gx: X + 14.5, h: 1, done: (W, p) => p.x > X + 14.9 }] };
  };
  const y44 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 14.2); c.fl(14.2, 24, { y: 5.6 }); const k = seesaw(c, 9.5), r = c.box(2.5, -0.75, 'R'), l = c.box(3, 2.6, 'L');
    const up = (W, p) => p.y > Y + 5.3 && p.x > X + 14.1, R = (W) => W.bx[r], Lb = (W) => W.bx[l], K = (W) => W.pk[k];
    const ramp = (W, p) => (p.y > Y + 0.7 ? null : [[X + 4.3, 0.9], [X + 7.6, 0.9]]);
    const set = (W) => { const o = Lb(W); return o.held < 0 && o.sup === K(W) && o.x > X + 12.3; };
    return { nm: '높은 벽', goal: '시소와 상자로 높은 벽 넘기', hint: '돌덩이로 시소를 눌러 두고, 나무 상자를 높은 쪽 끝에 올려 딛기.', len: 24, rise: 5.6, gx: X + 14.2,
      steps: [
        { a: 'push', b: r, to: [X + 6.0, -0.75], done: (W, p) => up(W, p) || R(W).x > X + 5.6 },
        { a: 'carry', b: l, wait: [X + 3, 3], via: (W, p) => (p.y > Y + 0.7 ? [[X + 11.6, 0.4]] : [[X + 4.3, 0.9], [X + 7.6, 0.9], [X + 11.6, 0.4]]), to: (W) => [X + 13.1, Y + 1.1 + 3.6 * Math.tan(K(W).th) + 0.46, 0.4], done: (W, p) => up(W, p) || set(W) },
        { a: 'go', via: ramp, to: (W) => [Lb(W).x, Lb(W).z], hop: (W) => Lb(W).y + 0.45, done: (W, p) => up(W, p) || (p.y > Lb(W).y + 0.3 && Math.abs(p.x - Lb(W).x) < 0.6) },
        { a: 'climb', at: (W) => [Math.min(Lb(W).x + 0.25, X + 13.8), Lb(W).z], h: Y + 5.6, done: up },
      ] };
  };

  /* ======================= 구역 5 · 공장 ======================= */
  const y51 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 5); c.fl(17, 22);
    c.blk(5, -0.6, -1.6, 17, 0, 1.6, 'belt', { cv: { sig: 'b51', v0: -4.6, v1: 2.2 }, ng: 1 });
    for (let x = 6; x <= 16; x += 2) { c.blk(x - 0.1, 1.78, -1.85, x + 0.1, 2.0, 1.85, 'bar', { ng: 1 }); c.blk(x - 0.1, -0.6, 1.62, x + 0.1, 1.78, 1.85, 'post', { ng: 1 }); c.blk(x - 0.1, -0.6, -1.85, x + 0.1, 1.78, -1.62, 'post', { ng: 1 }); }
    const l = c.lever(3, -3, { keep: 6.5, sig: 'b51' }), over = (W, p) => p.x > X + 16.8;
    return { nm: '거꾸로 벨트', goal: '벨트의 방향 바꾸기', hint: '손잡이를 당기면 6.5초 동안 벨트가 앞으로 돎. 켜져 있는 동안 건너기.', len: 22, rise: 0, gx: X + 17,
      steps: [
        { a: 'lever', i: l, h: 1, when: (W, p, m) => m === 'help' && hum(W, (q) => q.x < X + 16.8 && q.x > X), done: () => false },
        { a: 'lever', i: l, done: (W, p) => over(W, p) || (W.lv[l].on && (p.x > X + 5.4 || W.lv[l].tm > 4.6)) },
        { a: 'go', via: (W, p) => (p.x < X + 4.9 ? [[X + 4.7, 0]] : null), to: [X + 18.2, 0], done: over },
      ] };
  };
  const y52 = (c) => {
    const X = c.x, Y = c.y; c.fl(0, 6); c.fl(16, 26);
    c.blk(6, -0.6, -1.7, 16, 0, 1.7, 'belt', { cv: { v0: 2, v1: 2 }, ng: 1 });
    c.bar(21, -1.5, 1.5, 3); c.gate(21, -1.5, 1.5, 3, 'g52');
    const pl = c.plate(17.25, 0, 1.45, 1.5, 3, 'g52'), b = c.box(3, 0, 'H'), B = (W) => W.bx[b], open = (W) => W.pt[pl].lat;
    return { nm: '벨트 배달', goal: '큰 상자를 발판까지 보내기', hint: '발판은 무게 셋(큰 상자 하나가 셋). 큰 상자를 벨트에 올리면 발판까지 실려 감.', len: 26, rise: 0, gx: X + 21.6,
      steps: [
        { a: 'push', b, to: (W) => [X + 7.4, B(W).z], done: (W, p) => open(W) || B(W).x > X + 6.25 },
        { a: 'push', b, to: [X + 17.25, 0], when: (W) => B(W).x > X + 15.5, done: open },
        { a: 'go', via: (W, p) => (p.x < X + 15 ? [[X + 13.4, 1.3], [X + 17.4, 1.3]] : null), to: [X + 22.6, 0], when: open, done: (W, p) => p.x > X + 21.9 },
      ] };
  };
  const y53 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 6); c.fl(15.4, 24, { y: 3 });
    const a = S.addMover(W_, 1.0, 0.15, 1.2, [X + 7.22, Y - 0.15, 0], [X + 10.8, Y - 0.15, 0], { cyc: { per: 9, dw: 0.15, ph: 0 }, k: 'plat' }).i;
    const b = S.addMover(W_, 1.2, 0.15, 1.2, [X + 14.12, Y - 0.15, 0], [X + 14.12, Y + 2.85, 0], { cyc: { per: 9, dw: 0.15, ph: 0.5 }, k: 'plat' }).i;
    const A = (W) => W.mv[a], B = (W) => W.mv[b], up = (W, p) => p.x > X + 15.3 && p.y > Y + 2.6;
    const on = (p, m) => p.sup === m || (p.gr && Math.abs(p.x - m.x) < m.hx + 0.28 && Math.abs(p.z - m.z) < m.hz + 0.28 && Math.abs(p.y - m.y1) < 0.3);
    return { nm: '오가는 발판', goal: '움직이는 발판 갈아타기', hint: '첫 발판이 건너편에 닿을 때 둘째 발판이 내려와 있음. 그때 건너뛰고, 올라가면 내리기.', len: 24, rise: 3, gx: X + 15.4,
      steps: [
        { a: 'stand', at: [X + 5.3, 0], spread: 0.6, done: (W, p) => p.x > X + 6.15 || (A(W).f < 0.03 && (A(W).ph < 0.07 || A(W).ph > 0.97)) },
        { a: 'go', to: (W) => [A(W).x, 0], done: (W, p) => p.x > X + 12.2 || (on(p, A(W)) && A(W).f > 0.985 && B(W).f < 0.08) },
        { a: 'go', to: (W) => [B(W).x, 0], j: [(W) => A(W).x1 - 0.02], g: 1, done: (W, p) => up(W, p) || on(p, B(W)) },
        { a: 'stand', at: (W) => [B(W).x, 0], done: (W, p) => up(W, p) || B(W).f > 0.985 },
        { a: 'go', to: [X + 16.8, 0], done: up },
      ] };
  };
  const y54 = (c) => {
    const X = c.x, Y = c.y, W_ = c.W; c.fl(0, 24); c.bar(8, -1, 1, 2.4); c.bar(18, -1.5, 1.5, 3); c.gate(18, -1.5, 1.5, 3, 'g54');
    const d = S.addSlider(W_, 0.12, 1.2, 1.05, [X + 7.86, Y + 1.2, 0], 2, 2.9, { m: 1.2, spring: { wait: 1.6, v: 0.55 }, hd: [-0.2, -0.1, 0.85], k: 'door' }).i;
    const b = c.box(3.5, 0, 'H'), pl = c.plate(13.5, 0, 1.4, 1.4, 3, 'g54');
    const D = (W) => W.sl[d], B = (W) => W.bx[b], open = (W) => W.pt[pl].lat, mine = (p) => p.g && p.g.k === 'd' && p.g.i === d;
    return { nm: '마지막 작업', goal: '큰 상자를 문 너머 발판으로', hint: '상자를 문 앞에 붙여 두고 문을 연 뒤 밀어 넣으면, 상자가 문을 받쳐 줌. 발판은 무게 셋.', len: 24, rise: 0, gx: X + 18.6,
      steps: [
        { a: 'drag', i: d, s: 2.9, off: [-0.6, 0], h: 1, when: (W, p, m) => m === 'help' && !open(W) && hum(W, (q) => q.x < X + 8.7 && q.x > X + 1 && B(W).x < X + 8.9 && B(W).x > X + 5.6), done: () => false },
        { a: 'push', b, to: [X + 6.9, 0], done: (W) => open(W) || B(W).x > X + 6.75 },
        { a: 'drag', i: d, s: 2.9, off: [-0.6, 0], done: (W, p) => p.x > X + 7.95 || (B(W).x > X + 7.25 && B(W).x < X + 8.9) || D(W).s > (mine(p) ? 2.8 : B(W).x > X + 8.9 ? 1.25 : 1.95) },
        { a: 'push', b, to: [X + 13.5, 0], done: open },
        { a: 'go', via: (W, p) => (p.x < X + 7.3 ? [[X + 7.25, -0.3]] : null), to: [X + 9.6, -0.3], done: (W, p) => p.x > X + 8.7 },
        { a: 'go', to: [X + 19.6, 0], done: (W, p) => p.x > X + 18.9 },
      ] };
  };

  const ZONES = [
    { id: 'yard', nm: '야적장', d: '잡기 · 오르기 · 상자', sky: ['#cfd9e2', '#eef1f0'], fog: '#dfe6ea', acc: '#c98a3c', yards: [y11, y12, y13, y14] },
    { id: 'depot', nm: '창고', d: '미닫이문 · 발판 · 손잡이 · 승강대', sky: ['#d9d3c8', '#f1ede4'], fog: '#e6e0d5', acc: '#b9683e', yards: [y21, y22, y23, y24] },
    { id: 'dock', nm: '부두', d: '밧줄 · 수레 · 들보', sky: ['#c3d6dc', '#e9f1f1'], fog: '#d6e4e7', acc: '#3f8f9b', yards: [y31, y32, y33, y34] },
    { id: 'quarry', nm: '채석장', d: '시소 · 돌덩이 · 투석기', sky: ['#d8d4cf', '#efeeea'], fog: '#e3e0db', acc: '#8f7a5a', yards: [y41, y42, y43, y44] },
    { id: 'plant', nm: '공장', d: '벨트 · 오가는 발판 · 종합', sky: ['#cdd2dd', '#eceef3'], fog: '#dcdfe8', acc: '#6a78b8', yards: [y51, y52, y53, y54] },
  ];
  /* 구역 세계 만들기: players = [{ai, lv, off}] */
  S.buildZone = function (zi, players, seed) {
    const Z = ZONES[zi], W = S.newWorld(players.length, (seed || 1) + zi * 7919), c = ctx(W);
    W.zi = zi;
    let minY = 0;
    Z.yards.forEach((f, i) => {
      const y = f(c); y.i = i; y.x0 = c.x; y.x1 = c.x + y.len; y.y0 = c.y; y.cp = [c.x + 1.6, c.y, 0];
      W.yards.push(y); c.x += y.len; c.y += y.rise; minY = Math.min(minY, c.y);
    });
    c.fl(0, 8); W.fin = [c.x + 4, c.y, 0];
    W.yards.push({ i: Z.yards.length, nm: '도착', goal: '모두 도착 지점으로', hint: '사람 자리 모두가 끝 표시 위에 서면 구역 통과.', len: 8, rise: 0, x0: c.x, x1: c.x + 8, y0: c.y, cp: [c.x + 1.6, c.y, 0], steps: [], end: 1 });
    W.killY = minY - 12; W.len = c.x + 8;
    players.forEach((q, i) => { const p = S.addPlayer(W, i, q); p.off = !!q.off; S.spawn(W, p, 0); });
    S.refresh(W);
    return W;
  };
  S.ZONES = ZONES;
  /* 마당별 [목표, 힌트] — 판 밖(F1 도움말)에서도 쓰게 한 번 뽑아 둠 */
  S.HINTS = ZONES.map((Z, zi) => { const W = S.buildZone(zi, [], 1); return W.yards.slice(0, 4).map((y) => [y.goal, y.hint]); });
  S.SIZES = SIZES; S.BOXNM = BOXNM; S.ZW = ZW; S.TH = TH; S.HB = HB;
  if (typeof module === 'object' && module) module.exports = S;
})();
