/* 열두 파수 — 화면(캔버스 2D). 시뮬은 초당 60걸음, 화면은 걸음 사이를 보간해서 그림.
   사수 · 파수는 생성 그림(스프라이트)을 변형해 그리고(안 오면 코드 그림), 탄 · 예고 · 발판은 코드(벡터). 프레임마다 무작위로 떠는 연출은 쓰지 않음(시간에 대한 부드러운 함수만). */
(function () {
  'use strict';
  const G = window, L = G.Lounge, U = L.util, D = G.BOSSRUN, S = D.sim;
  const DT = S.DT, AW = S.AW, AH = S.AH, GY = S.GY, PI = Math.PI, TAU = PI * 2;
  const clamp = D.clamp, lerp = (a, b, t) => a + (b - a) * t;
  const FONT = '"IBM Plex Sans KR",sans-serif', FD = '"Black Han Sans","IBM Plex Sans KR",sans-serif';
  const HZC = ['#ff6a4a', '#ff8a3a', '#d8c8ff', '#6ac8f0', '#b070ff', '#e8c060'];

  /* ---------- 그리기 도우미 ---------- */
  const el = (g, x, y, rx, ry, c, rot) => { g.fillStyle = c; g.beginPath(); g.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot || 0, 0, TAU); g.fill(); };
  const po = (g, c, p) => { g.fillStyle = c; g.beginPath(); g.moveTo(p[0], p[1]); for (let i = 2; i < p.length; i += 2) g.lineTo(p[i], p[i + 1]); g.closePath(); g.fill(); };
  const ln = (g, c, w, p) => { g.strokeStyle = c; g.lineWidth = w; g.lineCap = 'round'; g.lineJoin = 'round'; g.beginPath(); g.moveTo(p[0], p[1]); for (let i = 2; i < p.length; i += 2) g.lineTo(p[i], p[i + 1]); g.stroke(); };
  const rr = (g, x, y, w, h, r, c) => { g.fillStyle = c; g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); g.fill(); };
  const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

  /* ======================= 파수 그림 ======================= */
  /* (g, x, y, B, T, W): x,y 보간된 자리 · T 부드러운 시간(걸음) · B.po 자세 · B.ph 단계 */
  const BD = {};
  BD.gate = (g, x, y, B, T) => {
    const ph = B.ph, wind = B.po === 'wind', dash = B.po === 'dash', sq = wind ? 0.86 : 1, f = B.fl, br = Math.sin(T * 0.06) * 1.5;
    g.save(); g.translate(x, y + 40); g.scale(f, sq); g.rotate(dash ? 0.12 : B.po === 'air' ? -0.15 : 0);
    el(g, -16, -6, 11, 9, '#3a2418'); el(g, 14, -6, 11, 9, '#3a2418');
    el(g, 0, -42 + br, 36, 38, '#6a3a20'); el(g, -3, -46 + br, 31, 32, ph ? '#a8522a' : '#b8683a');
    rr(g, -20, -64 + br, 34, 9, 4, '#1a1014'); rr(g, -17, -62 + br, 12, 5, 2, ph ? '#ff9a4a' : '#ffd9a0'); rr(g, -1, -62 + br, 12, 5, 2, ph ? '#ff9a4a' : '#ffd9a0');
    if (!ph) { rr(g, 12, -78 + br, 22, 72, 5, '#4a3a34'); rr(g, 15, -74 + br, 16, 64, 3, '#7a6a5a'); for (let i = 0; i < 4; i++) el(g, 23, -66 + i * 17 + br, 2.5, 2.5, '#2a2020'); ln(g, '#2a2020', 2, [17, -42 + br, 29, -42 + br]); }
    else { el(g, 6, -38 + br, 10, 10, '#ffb060'); el(g, 6, -38 + br, 5 + Math.sin(T * 0.15) * 1.5, 5 + Math.sin(T * 0.15) * 1.5, '#fff0c8'); po(g, '#3a2418', [-22, -74, -30, -92, -14, -78]); po(g, '#3a2418', [12, -76, 22, -94, 22, -74]); ln(g, '#2a1410', 2, [-18, -30, -6, -22, -12, -10]); }
    el(g, -28, -34 + br, 9, 14, '#5a3220', 0.3 + (wind ? 0.5 : 0));
    g.restore();
    if (dash) for (let i = 1; i < 4; i++) ln(g, 'rgba(255,200,150,' + (0.3 - i * 0.07) + ')', 3, [x - f * (30 + i * 16), y - 24 + i * 14, x - f * (60 + i * 22), y - 24 + i * 14]);
  };
  BD.bloom = (g, x, y, B, T) => {
    const ph = B.ph, sw = Math.sin(T * 0.04) * 4, rear = B.po === 'wind' ? 8 : 0, hx = x + sw + rear, hy = y - rear;
    ln(g, '#2f5a3a', 12, [x + 20, GY, x + 26 + sw * 0.5, GY - 40, hx + 6, hy + 30]); ln(g, '#3f7a4a', 5, [x + 20, GY, x + 26 + sw * 0.5, GY - 40, hx + 6, hy + 30]);
    for (let i = 0; i < 3; i++) po(g, '#2f5a3a', [x + 24 + i * 2, GY - 14 - i * 22, x + 44, GY - 20 - i * 22, x + 26, GY - 26 - i * 22]);
    if (ph === 2) for (let i = 0; i < 5; i++) ln(g, '#4a2f3a', 4, [x + 10, GY, x - 20 - i * 26, GY - 6 - Math.abs(Math.sin(T * 0.05 + i)) * 8, x - 44 - i * 26, GY]);
    const n = ph === 0 ? 5 : 7, open = ph === 0 ? 0.35 : 1, pc = ph === 2 ? '#7a2f4a' : '#d8608a', pc2 = ph === 2 ? '#5a2038' : '#b84070';
    for (let i = 0; i < n; i++) { const a = (i / n) * TAU + T * (ph ? 0.012 : 0) + 0.3; el(g, hx + Math.cos(a) * 26 * open, hy + Math.sin(a) * 26 * open, 22, 12, i % 2 ? pc : pc2, a); }
    el(g, hx, hy, 24, 24, '#3a1828'); el(g, hx, hy, 18, 18, ph ? '#f0c060' : '#5a2840');
    el(g, hx - 8, hy - 3, 4, 5, '#17131f'); el(g, hx + 5, hy - 3, 4, 5, '#17131f'); el(g, hx - 8, hy - 4, 1.5, 1.5, '#fff');
    for (let i = 0; i < 5; i++) po(g, '#f2e9d8', [hx - 11 + i * 5, hy + 7, hx - 8.5 + i * 5, hy + 13, hx - 6 + i * 5, hy + 7]);
  };
  BD.tide = (g, x, y, B, T) => {
    const f = B.fl, ph = B.ph, w = Math.sin(T * 0.05) * 3;
    g.save(); g.translate(x, y + w); g.scale(-f, 1); if (B.po === 'leap') g.rotate(Math.cos(clamp((B.k - 40) / 70, 0, 1) * PI) * -0.7);
    po(g, '#1f4a66', [36, -6, 78, -30 + w, 70, 0, 80, 26 - w, 36, 8]);
    el(g, 0, 0, 56, 40, '#1f4a66'); el(g, -4, 10, 48, 26, '#9cc8d8'); el(g, 0, -4, 54, 34, '#2f6a8a');
    for (let i = 0; i < 5; i++) ln(g, 'rgba(20,50,70,.5)', 1.5, [-40 + i * 8, 16, -34 + i * 8, 30]);
    el(g, -32, -8, 6, 6, '#f2e9d8'); el(g, -33, -8, 3, 3.5, '#17131f');
    po(g, '#1f4a66', [0, -30, 14, -50, 22, -28]); el(g, 6, 22, 16, 7, '#1f4a66', 0.5);
    if (ph) { ln(g, '#7ff0e8', 2, [-20, -24, -6, -14, -16, -2]); ln(g, '#7ff0e8', 2, [14, -22, 26, -8]); }
    g.restore();
    if (B.po === 'cast' || B.po === 'tide') { const s = (Math.sin(T * 0.3) + 1) * 0.5; ln(g, 'rgba(160,220,240,.7)', 4, [x, y - 34, x - 4, y - 54 - s * 8]); el(g, x - 4, y - 58 - s * 8, 6, 4, 'rgba(200,240,250,.7)'); }
  };
  BD.kiln = (g, x, y, B, T) => {
    const ph = B.ph, gl = (Math.sin(T * 0.08) + 1) * 0.5, sink = ph === 2 ? 26 : 0, po2 = B.po;
    g.save(); g.translate(x, y + sink);
    po(g, '#2a2228', [-50, 96, -40, -30, 44, -30, 58, 96]); po(g, '#4a3a3c', [-42, 96, -34, -26, 38, -26, 50, 96]);
    el(g, 0, -48, 20, 18, '#3a2e30'); rr(g, -12, -52, 9, 5, 2, '#ffb050'); rr(g, 3, -52, 9, 5, 2, '#ffb050');
    rr(g, -24, -6, 48, 44, 8, '#1a1014'); rr(g, -20, -2, 40, 36, 6, 'rgb(' + (200 + gl * 55) + ',' + (90 + gl * 50) + ',40)');
    for (let i = 0; i < 4; i++) rr(g, -18 + i * 10, -2, 4, 36, 1, '#1a1014');
    el(g, -46, -22, 16, 14, '#3a2e30'); el(g, 50, -22, 16, 14, '#3a2e30');
    if (ph) { ln(g, '#ff8a3a', 2.5, [-30, 30, -20, 50, -32, 70]); ln(g, '#ff8a3a', 2.5, [30, 40, 22, 62]); }
    g.restore();
    /* 주먹: 예고한 줄로 뻗음 */
    const row = B.a[0] === 2 ? GY - 104 : B.a[0] === 1 ? GY - 26 : 0, fx2 = po2 === 'punch' ? x - 78 - clamp((B.k % 62 - 40) / 5, 0, 1) * 400 : x - 78;
    if (row && (po2 === 'fist' || po2 === 'punch')) { ln(g, '#3a2e30', 14, [x - 46, y - 22 + sink, fx2 + 8, row]); el(g, fx2, row, 20, 18, '#5a4244'); el(g, fx2 - 6, row, 8, 8, '#ff9a4a'); }
    else { ln(g, '#3a2e30', 14, [x - 46, y - 22 + sink, x - 60, y + 30 + sink]); el(g, x - 62, y + 38 + sink, 16, 15, '#5a4244'); }
  };
  BD.rail = (g, x, y, B, T, W) => {
    const ph = B.ph, sp = W.pl[0] ? -W.pl[0].vx : 60, rot = T * sp * 0.0045, hot = ph === 2;
    g.save(); g.translate(x, y + Math.sin(T * 0.5) * 0.6);
    rr(g, -30, -50, 90, 130, 8, '#2a2228'); el(g, -6, 0, 44, 44, '#3a2e38'); el(g, -10, 0, 36, 36, hot ? '#7a3030' : '#5a3a44');
    el(g, -14, -2, 15, 15, '#1a1014'); el(g, -14, -2, 10, 10, hot ? '#ff7a4a' : '#ffd080'); el(g, -16, -4, 4, 4, '#fff6dc');
    rr(g, 4, -92, 20, 46, 3, '#2a2228'); rr(g, 0, -98, 28, 10, 3, '#4a3a44');
    for (let i = 0; i < 3; i++) { const u = ((T * 0.012 + i / 3) % 1); el(g, 14 - u * 26, -104 - u * 46, 8 + u * 12, 7 + u * 10, 'rgba(150,140,160,' + (0.4 * (1 - u)) + ')'); }
    po(g, '#4a3a44', [-56, 96, -30, 46, 30, 46, 30, 96]); for (let i = 0; i < 5; i++) ln(g, '#1a1014', 2, [-50 + i * 14, 94, -28 + i * 10, 50]);
    for (const wx of [-18, 34]) { el(g, wx, 84, 16, 16, '#1a1014'); el(g, wx, 84, 11, 11, '#5a4a54'); ln(g, '#1a1014', 3, [wx + Math.cos(rot) * 10, 84 + Math.sin(rot) * 10, wx - Math.cos(rot) * 10, 84 - Math.sin(rot) * 10]); }
    if (ph) { ln(g, '#ff8a3a', 2, [-34, 22, -26, 34, -36, 44]); }
    if (B.po === 'beam' || B.po === 'wind') el(g, -14, -2, 20, 20, 'rgba(255,220,150,.25)');
    g.restore();
  };
  BD.swarm = (g, x, y, B, T) => {
    const ph = B.ph, hx = 320, hy = 86;
    /* 벌집(늘 천장에 있음) */
    ln(g, '#5a4020', 6, [hx, 0, hx, hy - 34]);
    po(g, '#8a6420', [hx - 30, hy - 30, hx + 30, hy - 30, hx + 38, hy + 4, hx + 20, hy + 34, hx - 20, hy + 34, hx - 38, hy + 4]);
    po(g, ph ? '#a07828' : '#d8a438', [hx - 26, hy - 26, hx + 26, hy - 26, hx + 32, hy + 4, hx + 16, hy + 29, hx - 16, hy + 29, hx - 32, hy + 4]);
    for (let i = 0; i < 4; i++) ln(g, 'rgba(90,60,20,.6)', 2, [hx - 30 + i * 2, hy - 14 + i * 13, hx + 30 - i * 2, hy - 14 + i * 13]);
    el(g, hx, hy + 6, 9, 11, '#2a1808');
    if (ph) { ln(g, '#2a1808', 2, [hx - 20, hy - 22, hx - 8, hy - 6, hx - 18, hy + 10]); }
    else { el(g, hx - 4, hy + 4, 2.5, 2.5, '#ffe9a8'); el(g, hx + 4, hy + 4, 2.5, 2.5, '#ffe9a8'); return; }
    /* 여왕 */
    const f = B.fl, fl = Math.sin(T * 0.9) * 0.5, rage = ph === 2;
    g.save(); g.translate(x, y); g.scale(f, 1); g.rotate(B.po === 'dive' ? 0.4 : 0);
    el(g, -8, -18, 22, 9, 'rgba(230,240,255,.45)', -0.5 + fl); el(g, 6, -18, 22, 9, 'rgba(230,240,255,.45)', 0.5 - fl);
    el(g, -18, 6, 20, 14, '#2a1808', 0.3); el(g, -18, 6, 17, 11, rage ? '#e06a30' : '#e8b040', 0.3);
    ln(g, '#2a1808', 4, [-26, -2, -20, 16]); ln(g, '#2a1808', 4, [-14, -6, -8, 16]);
    po(g, '#2a1808', [-36, 10, -48, 18, -34, 16]);
    el(g, 4, 0, 13, 12, '#3a2410'); el(g, 18, -4, 10, 10, '#2a1808'); el(g, 21, -6, 3.5, 4, rage ? '#ff5a3a' : '#ffe9a8');
    po(g, '#e8c060', [10, -14, 13, -24, 17, -15, 21, -25, 24, -14]);
    g.restore();
  };
  BD.mirror = (g, x, y, B, T) => {
    const ph = B.ph, f = B.fl, po2 = B.po, guard = B.a[0] && B.a[1] <= 0 && B.a[2] <= 0, stun = po2 === 'stun';
    let al = 1; if (po2 === 'fade') al = clamp(1 - (B.k % 80) / 16, 0.08, 1); else if (po2 === 'slash') al = 1;
    g.save(); g.globalAlpha *= al; g.translate(x, y + 32); g.scale(f, 1); if (stun) { g.translate(0, 8); g.rotate(-0.25); }
    const lean = po2 === 'thrust' ? 0.35 : po2 === 'wind' ? -0.18 : 0; g.rotate(lean);
    po(g, ph === 2 ? '#3a2a4a' : '#5a4a8a', [-10, -56, -30 - Math.sin(T * 0.07) * 4, -8, -12, -4]);
    ln(g, '#3a3a50', 7, [-5, -22, -8, 0]); ln(g, '#3a3a50', 7, [6, -22, 9, 0]);
    po(g, '#8a94b0', [-12, -58, 12, -58, 9, -20, -9, -20]); po(g, '#c8d0e4', [-8, -56, 6, -56, 4, -24, -6, -24]);
    el(g, 0, -68, 10, 11, '#8a94b0'); rr(g, -2, -72, 11, 4, 1, ph === 2 ? '#ff6a6a' : '#17131f'); po(g, '#c05070', [-4, -78, -14, -92, 2, -80]);
    /* 창 */
    const ext = po2 === 'thrust' ? 26 : po2 === 'slash' ? 14 : 0;
    ln(g, '#d8d0c0', 3, [-6 + ext, -44, 44 + ext, -40 - (po2 === 'slash' ? 20 : 0)]); po(g, '#f2e9d8', [44 + ext, -46, 58 + ext, -40, 44 + ext, -35]);
    /* 거울 방패 */
    if (B.a[0]) {
      if (guard) { el(g, 16, -40, 9, 22, '#5a6a8a'); el(g, 17, -40, 7, 19, '#bfe8f4'); ln(g, '#ffffff', 2, [14, -52, 19, -44]); }
      else if (B.a[1] > 0) { el(g, 16, -40, 9, 22, 'rgba(90,106,138,.5)'); ln(g, '#17131f', 1.5, [12, -54, 18, -40, 13, -30, 20, -22]); }
      else { g.save(); g.translate(6, -22); g.rotate(1.1); el(g, 0, 0, 8, 19, '#5a6a8a'); g.restore(); }
    }
    g.restore();
    if (stun) for (let i = 0; i < 3; i++) { const a = T * 0.12 + i * 2.1; el(g, x + Math.cos(a) * 16, y - 46 + Math.sin(a) * 5, 2.5, 2.5, '#ffe9a8'); }
  };
  BD.storm = (g, x, y, B, T) => {
    const ph = B.ph, dive = B.po === 'dive', fl = dive ? -0.9 : Math.sin(T * 0.1) * 0.5, c1 = ph === 2 ? '#2a1f5a' : '#3a2f6a', c2 = '#5a4a9a';
    g.save(); g.translate(x, y); if (dive) g.rotate(-0.15);
    for (const s of [-1, 1]) { g.save(); g.scale(1, s); g.rotate(-0.5 - fl * 0.5); po(g, c1, [0, -6, 30, -70, 44, -62, 36, -40, 56, -44, 40, -22, 54, -18, 24, -2]); po(g, c2, [4, -8, 28, -58, 32, -38, 20, -8]); g.restore(); }
    el(g, 6, 0, 40, 24, c1); el(g, 0, 2, 30, 17, c2);
    po(g, c1, [36, -8, 76, -14, 70, 0, 78, 12, 36, 10]);
    el(g, -30, -4, 17, 15, c1); po(g, '#f0c040', [-42, -6, -66, 2, -42, 6]); ln(g, '#8a6a10', 1.5, [-44, 0, -62, 2]);
    el(g, -32, -8, 4.5, 4.5, ph ? '#fff' : '#ffe9a8'); el(g, -33, -8, 2, 2.5, '#17131f');
    po(g, '#d8c8ff', [-24, -18, -18, -34, -16, -22, -8, -32, -10, -16]);
    if (ph) { const a = (Math.sin(T * 0.2) + 1) * 0.3 + 0.2; ln(g, 'rgba(216,200,255,' + a + ')', 2, [-8, -22, 4, -30, 0, -20, 14, -28]); ln(g, 'rgba(216,200,255,' + a + ')', 2, [10, 20, 22, 28, 18, 18, 30, 24]); }
    g.restore();
  };
  BD.clock = (g, x, y, B, T) => {
    const ph = B.ph, red = ph === 2;
    po(g, '#2a2430', [x - 46, GY, x - 38, y + 30, x + 38, y + 30, x + 46, GY]); po(g, '#3a3240', [x - 36, GY, x - 30, y + 34, x + 30, y + 34, x + 36, GY]);
    for (let i = 0; i < 3; i++) rr(g, x - 8, y + 66 + i * 34, 16, 20, 8, '#1a1620');
    po(g, '#3a3240', [x - 52, y - 30, x, y - 84, x + 52, y - 30]);
    el(g, x, y, 54, 54, '#6a5020'); el(g, x, y, 48, 48, '#c9a45a'); el(g, x, y, 42, 42, red ? '#3a1820' : '#f2e9d8');
    for (let i = 0; i < 12; i++) { const a = (i / 12) * TAU; ln(g, red ? '#ff8a6a' : '#3a3240', i % 3 ? 1.5 : 3, [x + Math.cos(a) * 34, y + Math.sin(a) * 34, x + Math.cos(a) * 40, y + Math.sin(a) * 40]); }
    if (ph) { const a = T * 0.03; for (let i = 0; i < 8; i++) po(g, '#8a6a30', [x - 16 + Math.cos(a + i * 0.785) * 12, y + 14 + Math.sin(a + i * 0.785) * 12, x - 16 + Math.cos(a + i * 0.785 + 0.3) * 17, y + 14 + Math.sin(a + i * 0.785 + 0.3) * 17, x - 16 + Math.cos(a + i * 0.785 + 0.5) * 12, y + 14 + Math.sin(a + i * 0.785 + 0.5) * 12]); el(g, x - 16, y + 14, 11, 11, '#8a6a30'); el(g, x - 16, y + 14, 4, 4, '#3a3240'); ln(g, '#17131f', 1.5, [x + 10, y - 38, x + 20, y - 18, x + 12, y - 6, x + 26, y + 10]); }
    if (B.po !== 'hand') { const a1 = T * 0.01 - PI / 2, a2 = T * 0.0012 - 1; ln(g, red ? '#ff8a6a' : '#17131f', 3, [x, y, x + Math.cos(a1) * 34, y + Math.sin(a1) * 34]); ln(g, red ? '#ff8a6a' : '#17131f', 4, [x, y, x + Math.cos(a2) * 22, y + Math.sin(a2) * 22]); }
    el(g, x, y, 5, 5, '#6a5020');
    el(g, x - 14, y - 10, 5, 3, red ? '#ff5a3a' : '#3a3240'); el(g, x + 14, y - 10, 5, 3, red ? '#ff5a3a' : '#3a3240');
  };
  BD.puppet = (g, x, y, B, T) => {
    const ph = B.ph, bob = Math.sin(T * 0.05) * 3, my = y + bob;
    for (let h = 0; h < 2; h++) {
      if (h && B.a[5]) continue;
      const hx = B.a[h * 2], hy = B.a[h * 2 + 1], hot = B.a[4] & (1 << h), s = h ? -1 : 1;
      ln(g, 'rgba(220,210,230,.35)', 1, [hx - 8, hy - 14, hx - 8 + (x - hx) * 0.15, 0]); ln(g, 'rgba(220,210,230,.35)', 1, [hx + 8, hy - 14, hx + 8 + (x - hx) * 0.15, 0]);
      g.save(); g.translate(hx, hy); g.scale(s, 1);
      if (hot || B.po === 'sweep' || B.po === 'clap') { rr(g, -22, -20, 44, 40, 12, '#4a2a40'); rr(g, -19, -17, 38, 34, 10, '#e8e0ec'); for (let i = 0; i < 3; i++) ln(g, '#b8a8c0', 2, [-10 + i * 10, -14, -10 + i * 10, 2]); }
      else { rr(g, -18, -6, 36, 26, 9, '#4a2a40'); rr(g, -15, -3, 30, 20, 7, '#e8e0ec'); for (let i = 0; i < 4; i++) rr(g, -16 + i * 8.5, -24, 7, 22, 3.5, '#e8e0ec'); rr(g, 14, -8, 7, 16, 3.5, '#d8cce0'); }
      rr(g, -14, 16, 28, 7, 3, '#b05a80');
      g.restore();
    }
    ln(g, 'rgba(220,210,230,.3)', 1, [x - 12, my - 30, x - 20, 0]); ln(g, 'rgba(220,210,230,.3)', 1, [x + 12, my - 30, x + 20, 0]);
    po(g, '#3a2038', [x - 34, my - 26, x, my - 46, x + 34, my - 26, x + 22, my - 18, x - 22, my - 18]);
    el(g, x, my, 24, 30, '#4a2a40'); el(g, x, my - 1, 21, 27, '#f2ecf4');
    po(g, '#17131f', [x - 15, my - 8, x - 4, my - 4, x - 14, my - 1]); po(g, '#17131f', [x + 15, my - 8, x + 4, my - 4, x + 14, my - 1]);
    if (ph === 2) { el(g, x - 9, my - 5, 2.5, 2.5, '#ff5a7a'); el(g, x + 9, my - 5, 2.5, 2.5, '#ff5a7a'); ln(g, '#17131f', 1.5, [x + 4, my - 26, x - 2, my - 12, x + 8, my, x, my + 14]); }
    ln(g, '#b05a80', 2, [x - 8, my + 12, x, my + 15, x + 8, my + 12]);
    if (ph) el(g, x - 14, my + 6, 3, 5, 'rgba(176,90,128,.6)');
  };
  BD.deep = (g, x, y, B, T) => {
    const ph = B.ph, bite = B.po === 'bite' || B.po === 'suck', jaw = bite ? 0.5 : 0.12 + (Math.sin(T * 0.05) + 1) * 0.04, lure = B.po === 'lure' ? (Math.sin(T * 0.55) > 0 ? 1 : 0.3) : 0.6 + Math.sin(T * 0.06) * 0.15;
    const lx = x - 78, ly = y - 58;
    ln(g, '#1a4a48', 3, [x - 10, y - 40, x - 40, y - 78, lx, ly]); el(g, lx, ly, 14, 14, 'rgba(160,255,230,' + lure * 0.25 + ')'); el(g, lx, ly, 7, 7, 'rgba(200,255,240,' + lure + ')');
    g.save(); g.translate(x, y);
    po(g, '#143a3a', [34, -8, 70, -30, 64, 0, 72, 28, 34, 10]); po(g, '#143a3a', [-6, -40, 14, -64, 26, -38]);
    el(g, 0, 0, 50, 42, '#143a3a'); el(g, 2, -2, 44, 36, ph === 2 ? '#2a5a50' : '#1f5a56');
    g.save(); g.rotate(-jaw); po(g, '#143a3a', [-52, -4, -8, -18, 6, 0, -44, 6]); for (let i = 0; i < 5; i++) po(g, '#f2e9d8', [-48 + i * 9, 4, -44 + i * 9, 16, -40 + i * 9, 4]); g.restore();
    g.save(); g.rotate(jaw * 1.4); po(g, '#0f2c2c', [-50, 8, -6, 6, 4, 26, -34, 30]); for (let i = 0; i < 5; i++) po(g, '#f2e9d8', [-46 + i * 9, 10, -42 + i * 9, -2, -38 + i * 9, 10]); g.restore();
    el(g, -18, -20, 7, 7, '#d8fff0'); el(g, -19, -20, 3, 4, '#17131f');
    el(g, 14, 16, 14, 6, '#143a3a', 0.6);
    if (ph) for (let i = 0; i < 4; i++) el(g, 6 + i * 9, -14 + (i % 2) * 14, 2.5, 2.5, 'rgba(160,255,230,.7)');
    g.restore();
  };
  BD.core = (g, x, y, B, T) => {
    const ph = B.ph, pu = 1 + Math.sin(T * 0.08) * 0.05, sh = ph === 2 && B.a[1];
    for (let i = 0; i < 3; i++) { g.save(); g.translate(x, y); g.rotate(T * 0.01 * (i % 2 ? -1 : 1) + i * 1.05); g.strokeStyle = 'rgba(176,112,255,' + (0.5 - i * 0.1) + ')'; g.lineWidth = 2.5; g.beginPath(); g.ellipse(0, 0, 50 + i * 4, 18 + i * 6, 0, 0, TAU); g.stroke(); g.restore(); }
    if (ph >= 1) for (let i = 0; i < 6; i++) { const a = T * 0.02 + i * 1.047; po(g, '#4a2a8a', [x + Math.cos(a) * 58, y + Math.sin(a) * 30 - 6, x + Math.cos(a) * 58 + 5, y + Math.sin(a) * 30, x + Math.cos(a) * 58, y + Math.sin(a) * 30 + 6, x + Math.cos(a) * 58 - 5, y + Math.sin(a) * 30]); }
    g.save(); g.translate(x, y); g.scale(pu, pu);
    po(g, '#2a1650', [0, -40, 30, -10, 20, 30, 0, 42, -20, 30, -30, -10]); po(g, '#6a3ac8', [0, -34, 24, -8, 16, 25, 0, 35, -16, 25, -24, -8]);
    po(g, '#9a6af0', [0, -34, 24, -8, 0, 0]); po(g, '#4a2a9a', [0, 35, -16, 25, -24, -8, 0, 0]);
    el(g, 0, -2, 9, 12, '#17131f'); el(g, 0, -2, 4 + Math.sin(T * 0.1) * 1, 7, ph === 2 ? '#ff7ab0' : '#f0d8ff');
    g.restore();
    if (sh) { g.strokeStyle = 'rgba(120,240,230,.8)'; g.lineWidth = 3; g.fillStyle = 'rgba(120,240,230,.12)'; g.beginPath(); for (let i = 0; i <= 6; i++) { const a = i * 1.047 + T * 0.004; g.lineTo(x + Math.cos(a) * 50, y + Math.sin(a) * 50); } g.fill(); g.stroke(); for (let i = 0; i < B.a[0]; i++) ln(g, '#17131f', 2.5, [x - 30 + i * 26, y - 40, x - 22 + i * 26, y - 18, x - 34 + i * 26, y - 4]); }
    else if (ph === 2) { g.strokeStyle = 'rgba(120,240,230,.25)'; g.lineWidth = 1.5; g.setLineDash([6, 8]); g.beginPath(); g.arc(x, y, 50, 0, TAU); g.stroke(); g.setLineDash([]); }
  };
  const BACK = { clock: 1, tide: 1, kiln: 1, rail: 1 };
  const BIG = { gate: 40, mirror: 32, tide: 0.01, storm: 0.01, deep: 0.01, core: 0.01 };   // 그림만 키우는 파수(값 = 기준점 y)   // 바닥 · 발판 뒤에 그리는 파수

  /* ======================= 그림(스프라이트) ======================= */
  /* 전투 중 사수 · 파수는 생성 그림(assets/bossrun/s_<이름>.webp, 투명 배경)을 변형(자리 · 기울기 · 크기 · 색조)해 그림.
     판정 · 수치와는 무관(자리만 맞춤). 그림이 하나라도 안 오면 그 대상은 위의 코드 그림(BD · drawHeroCode)으로 받침.
     SPM[이름] = [높이(무대 단위), 기준점 x, 기준점 y(0~1)] — 기준점이 파수 자리 · 사수 발밑에 놓임. 파수 그림은 왼쪽을 보는 것이 기본. */
  const SPM = {
    h_stand: [61, 0.46, 0.985], h_aimup: [69, 0.34, 0.985], h_run: [57, 0.5, 0.975], h_jump: [62, 0.47, 0.95], h_dash: [41, 0.37, 0.975], h_hit: [61, 0.38, 0.985],
    gate: [104, 0.5, 0.985], door: [80, 0.5, 0.99], bloom: [150, 0.535, 0.13], tide: [107, 0.42, 0.3], kiln: [180, 0.5, 0.3], rail: [175, 0.5, 0.275],
    hive: [84, 0.5, 0.5], queen: [86, 0.5, 0.42], mirror: [108, 0.6, 0.985], storm: [140, 0.48, 0.5], clock: [310, 0.5, 0.445], mask: [96, 0.5, 0.62], hand: [76, 0.5, 0.4], deep: [150, 0.45, 0.42], core: [110, 0.5, 0.42],
  };
  const BREQ = { gate: ['gate', 'door'], bloom: ['bloom'], tide: ['tide'], kiln: ['kiln'], rail: ['rail'], swarm: ['hive', 'queen'], mirror: ['mirror'], storm: ['storm'], clock: ['clock'], puppet: ['mask', 'hand'], deep: ['deep'], core: ['core'] };
  const HPOSE = ['h_stand', 'h_aimup', 'h_run', 'h_jump', 'h_dash', 'h_hit'];
  const SPI = {}, SPC = {}; let SPN = 0, SPQ = 2;   // 불러온 그림 · 화면 크기로 미리 줄인 그림 · 화면 픽셀/무대 단위
  function spr(k) {
    if (!(D.ART.spr && D.ART.spr.indexOf(k) >= 0)) return null;
    if (SPI[k] === undefined) { SPI[k] = null; const im = new Image(); im.onload = () => { SPI[k] = im; }; im.onerror = () => { SPI[k] = false; }; im.src = 'assets/bossrun/s_' + k + '.webp'; }
    return SPI[k] || null;
  }
  const sprOk = (list) => { let ok = true; for (const k of list) if (!spr(k)) ok = false; return ok; };
  /* 화면에 그려질 픽셀 크기로 한 번 줄여 둠(큰 원본을 프레임마다 줄이지 않게). tint: 그림 위에만 얹는 색(단계 · 2번 사수 · 번쩍임) */
  function sprC(k, tint, s) {
    const im = spr(k); if (!im) return null;
    const ph = Math.min(im.height, Math.max(24, Math.ceil(SPM[k][0] * (s || 1) * SPQ / 24) * 24)), key = k + '|' + (tint || '') + '|' + ph;
    let c = SPC[key];
    if (!c) {
      if (SPN > 90) { for (const q in SPC) delete SPC[q]; SPN = 0; }
      c = document.createElement('canvas'); c.height = ph; c.width = Math.max(1, Math.round(ph * im.width / im.height));
      const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(im, 0, 0, c.width, c.height);
      if (tint) { x.globalCompositeOperation = 'source-atop'; x.fillStyle = tint; x.fillRect(0, 0, c.width, c.height); }
      SPC[key] = c; SPN++;
    }
    return c;
  }
  /* o: fx 좌우(1/-1) · rot 기울기 · s 크기 · sx, sy 늘림 · al 투명도 · tint */
  function sd(g, k, x, y, o) {
    o = o || {}; const c = sprC(k, o.tint, o.s); if (!c) return false;
    const m = SPM[k], hU = m[0] * (o.s || 1), wU = hU * c.width / c.height;
    g.save(); g.translate(x, y); if (o.rot) g.rotate(o.rot); g.scale((o.fx || 1) * (o.sx || 1), o.sy || 1); if (o.al != null) g.globalAlpha *= o.al;
    g.drawImage(c, -m[1] * wU, -m[2] * hU, wU, hU); g.restore(); return true;
  }
  const glow = (g, x, y, r, c, a) => { const q = g.createRadialGradient(x, y, 0, x, y, r); q.addColorStop(0, 'rgba(' + c + ',' + a + ')'); q.addColorStop(1, 'rgba(' + c + ',0)'); g.globalCompositeOperation = 'lighter'; g.fillStyle = q; g.fillRect(x - r, y - r, r * 2, r * 2); g.globalCompositeOperation = 'source-over'; };

  /* 파수: 코드 그림(BD)과 같은 자세 · 단계 변화를 그림 변형으로. 판정에 걸린 표시(방패 상태 · 껍질 · 주먹 · 바늘 · 손)는 코드로 얹음 */
  const BS = {};
  BS.gate = (g, x, y, B, T) => {
    const ph = B.ph, wind = B.po === 'wind', dash = B.po === 'dash', fl = B.fl, br = Math.sin(T * 0.06) * 0.012;
    const rot = (dash ? 0.12 : B.po === 'air' ? -0.15 : 0) * fl, o = { fx: -fl, rot, sy: (wind ? 0.88 : 1) + br, sx: wind ? 1.06 : 1, tint: ph ? 'rgba(255,70,20,.16)' : '' };
    sd(g, 'gate', x, y + 40, o);
    if (!ph) sd(g, 'door', x + fl * 36, y + 40, { fx: -fl, rot, sy: wind ? 0.94 : 1 });
    else glow(g, x + fl * 10, y - 6, 20 + Math.sin(T * 0.15) * 3, '255,170,80', 0.75);
    if (dash) for (let i = 1; i < 4; i++) ln(g, 'rgba(255,200,150,' + (0.3 - i * 0.07) + ')', 3, [x - fl * (30 + i * 16), y - 24 + i * 14, x - fl * (60 + i * 22), y - 24 + i * 14]);
  };
  BS.bloom = (g, x, y, B, T) => {
    const ph = B.ph, sw = Math.sin(T * 0.04) * 4, rear = B.po === 'wind' ? 8 : 0, hx = x + sw + rear, hy = y - rear;
    if (ph === 2) for (let i = 0; i < 5; i++) ln(g, '#4a2f3a', 4, [x + 10, GY, x - 20 - i * 26, GY - 6 - Math.abs(Math.sin(T * 0.05 + i)) * 8, x - 44 - i * 26, GY]);
    sd(g, 'bloom', hx, hy, { rot: sw * 0.008 + rear * 0.012, s: ph === 0 ? 0.88 : 1, sy: 1 + Math.sin(T * 0.05) * 0.012, tint: ph === 2 ? 'rgba(70,10,40,.45)' : ph === 0 ? 'rgba(20,30,30,.22)' : '' });
    /* 꽃 한가운데의 얼굴(이빨 줄) */
    el(g, hx, hy, 11, 11, '#2a0f1e'); el(g, hx - 4.5, hy - 3, 2.2, 2.8, '#ffe9a8'); el(g, hx + 4.5, hy - 3, 2.2, 2.8, '#ffe9a8');
    for (let i = 0; i < 4; i++) po(g, '#f2e9d8', [hx - 7 + i * 3.6, hy + 3, hx - 5.2 + i * 3.6, hy + 8, hx - 3.4 + i * 3.6, hy + 3]);
  };
  BS.tide = (g, x, y, B, T) => {
    const fl = B.fl, w = Math.sin(T * 0.05) * 3, rot = B.po === 'leap' ? Math.cos(clamp((B.k - 40) / 70, 0, 1) * PI) * -0.7 * -fl : Math.sin(T * 0.03) * 0.03;
    sd(g, 'tide', x, y + w, { fx: -fl, rot, tint: B.ph ? 'rgba(80,255,230,.13)' : '' });
    if (B.ph) glow(g, x, y + w, 46, '127,240,232', 0.16 + Math.sin(T * 0.08) * 0.06);
    if (B.po === 'cast' || B.po === 'tide') { const s = (Math.sin(T * 0.3) + 1) * 0.5; ln(g, 'rgba(160,220,240,.7)', 4, [x, y - 34, x - 4, y - 54 - s * 8]); el(g, x - 4, y - 58 - s * 8, 6, 4, 'rgba(200,240,250,.7)'); }
  };
  BS.kiln = (g, x, y, B, T) => {
    const ph = B.ph, gl = (Math.sin(T * 0.08) + 1) * 0.5, sink = ph === 2 ? 26 : 0, po2 = B.po;
    sd(g, 'kiln', x, y + 4 + sink, { tint: ph ? 'rgba(255,90,30,' + (ph === 2 ? 0.2 : 0.1) + ')' : '' });
    glow(g, x, y + 4 + sink, 30, '255,150,60', 0.2 + gl * 0.3);
    /* 주먹: 예고한 줄로 뻗음(판정 표시 — 코드) */
    const row = B.a[0] === 2 ? GY - 104 : B.a[0] === 1 ? GY - 26 : 0, fx2 = po2 === 'punch' ? x - 78 - clamp((B.k % 62 - 40) / 5, 0, 1) * 400 : x - 78;
    if (row && (po2 === 'fist' || po2 === 'punch')) { ln(g, '#17131a', 17, [x - 46, y - 22 + sink, fx2 + 8, row]); ln(g, '#3a2e30', 13, [x - 46, y - 22 + sink, fx2 + 8, row]); el(g, fx2, row, 22, 20, '#17131a'); el(g, fx2, row, 20, 18, '#5a4244'); el(g, fx2 - 6, row, 8, 8, '#ff9a4a'); }
  };
  BS.rail = (g, x, y, B, T) => {
    const ph = B.ph, hot = ph === 2, jy = Math.sin(T * 0.5) * 0.6;
    sd(g, 'rail', x - 14, y - 2 + jy, { tint: hot ? 'rgba(255,50,20,.24)' : ph ? 'rgba(255,90,30,.08)' : '' });
    for (let i = 0; i < 3; i++) { const u = ((T * 0.012 + i / 3) % 1); el(g, x + 14 - u * 26, y - 104 - u * 46, 8 + u * 12, 7 + u * 10, 'rgba(150,140,160,' + (0.4 * (1 - u)) + ')'); }
    glow(g, x - 14, y - 2 + jy, B.po === 'beam' || B.po === 'wind' ? 34 : 20, hot ? '255,120,70' : '255,220,150', B.po === 'beam' || B.po === 'wind' ? 0.8 : 0.4);
  };
  BS.swarm = (g, x, y, B, T) => {
    const ph = B.ph, hx = 320, hy = 86;
    ln(g, '#3a2a14', 7, [hx, 0, hx, hy - 30]); ln(g, '#6a4c22', 4, [hx, 0, hx, hy - 30]);
    sd(g, 'hive', hx, hy, { rot: Math.sin(T * 0.03) * 0.03, tint: ph ? 'rgba(30,16,8,.42)' : '' });
    if (!ph) { el(g, hx - 4, hy + 6, 2.5, 2.5, '#ffe9a8'); el(g, hx + 4, hy + 6, 2.5, 2.5, '#ffe9a8'); return; }
    const fl = B.fl, rage = ph === 2;
    sd(g, 'queen', x, y + Math.sin(T * 0.2) * 1.5, { fx: -fl, rot: (B.po === 'dive' ? 0.4 : 0) * fl, sy: 1 + Math.sin(T * 0.9) * 0.035, tint: rage ? 'rgba(255,50,20,.26)' : '' });
  };
  BS.mirror = (g, x, y, B, T) => {
    const ph = B.ph, fl = B.fl, po2 = B.po, guard = B.a[0] && B.a[1] <= 0 && B.a[2] <= 0, stun = po2 === 'stun';
    let al = 1; if (po2 === 'fade') al = clamp(1 - (B.k % 80) / 16, 0.08, 1);
    const lean = (po2 === 'thrust' ? 0.3 : po2 === 'wind' ? -0.16 : stun ? -0.25 : 0) * fl, by = y + 32 + (stun ? 8 : 0), lunge = po2 === 'thrust' ? 12 * fl : 0;
    g.save(); g.globalAlpha *= al;
    sd(g, 'mirror', x + lunge, by, { fx: -fl, rot: lean, tint: ph === 2 ? 'rgba(120,20,60,.22)' : '' });
    /* 거울 방패(판정 표시): 세운 상태 · 금 간 상태 · 내린 상태 */
    if (B.a[0]) {
      const sx = x + lunge + fl * 21, sy = by - 46;
      g.save(); g.translate(sx, sy); g.rotate(lean);
      if (guard) { el(g, 0, 0, 12.5, 27, '#2a3048'); el(g, 0, 0, 10.5, 25, '#6a7aa0'); const q = g.createLinearGradient(-8, -22, 8, 22); q.addColorStop(0, '#f2fdff'); q.addColorStop(0.5, '#9fdcf0'); q.addColorStop(1, '#5f9cc8'); g.fillStyle = q; g.beginPath(); g.ellipse(0, 0, 8.5, 22.5, 0, 0, TAU); g.fill(); ln(g, 'rgba(255,255,255,.9)', 2, [-3, -14, 2, -5]); ln(g, 'rgba(255,255,255,.5)', 1.2, [1, 4, 4, 10]); }
      else if (B.a[1] > 0) { el(g, 0, 0, 12, 26, 'rgba(42,48,72,.7)'); el(g, 0, 0, 9, 23, 'rgba(120,140,170,.45)'); ln(g, '#17131f', 1.6, [-4, -16, 2, -2, -3, 8, 4, 18]); ln(g, '#17131f', 1.2, [2, -2, 7, -8]); }
      else { g.translate(-fl * 10, 22); g.rotate(1.1 * fl); el(g, 0, 0, 10, 22, '#2a3048'); el(g, 0, 0, 8, 19, '#5a6a8a'); }
      g.restore();
    }
    g.restore();
    if (stun) for (let i = 0; i < 3; i++) { const a = T * 0.12 + i * 2.1; el(g, x + Math.cos(a) * 18, y - 62 + Math.sin(a) * 5, 2.5, 2.5, '#ffe9a8'); }
  };
  BS.storm = (g, x, y, B, T) => {
    const ph = B.ph, dive = B.po === 'dive', fl = dive ? -0.9 : Math.sin(T * 0.1) * 0.5;
    sd(g, 'storm', x, y, { rot: dive ? -0.22 : Math.sin(T * 0.05) * 0.03, sy: 1 + fl * 0.11, sx: 1 - fl * 0.03, tint: ph === 2 ? 'rgba(60,20,120,.22)' : 'rgba(150,130,255,.16)' });
    if (ph) { const a = (Math.sin(T * 0.2) + 1) * 0.3 + 0.2; ln(g, 'rgba(216,200,255,' + a + ')', 2, [x - 8, y - 26, x + 4, y - 36, x, y - 24, x + 14, y - 34]); ln(g, 'rgba(216,200,255,' + a + ')', 2, [x + 10, y + 24, x + 22, y + 32, x + 18, y + 22, x + 30, y + 28]); }
  };
  BS.clock = (g, x, y, B, T) => {
    const ph = B.ph, red = ph === 2;
    sd(g, 'clock', x, y, { tint: red ? 'rgba(110,10,24,.42)' : ph ? 'rgba(40,20,10,.14)' : '' });
    /* 바늘(바늘 쓸기 때는 위험 구역 쪽에서 따로 그려짐) */
    if (B.po !== 'hand') { const a1 = T * 0.01 - PI / 2, a2 = T * 0.0012 - 1, c = red ? '#ff8a6a' : '#f2e9d8', r1 = 50, r2 = 32; ln(g, '#17131f', 6, [x, y, x + Math.cos(a1) * r1, y + Math.sin(a1) * r1]); ln(g, c, 3, [x, y, x + Math.cos(a1) * r1, y + Math.sin(a1) * r1]); ln(g, '#17131f', 7.5, [x, y, x + Math.cos(a2) * r2, y + Math.sin(a2) * r2]); ln(g, c, 4.5, [x, y, x + Math.cos(a2) * r2, y + Math.sin(a2) * r2]); }
    el(g, x, y, 6.5, 6.5, '#2a1c0c'); el(g, x, y, 4, 4, '#c9a45a');
    const ec = red ? '255,90,58' : '255,214,130'; glow(g, x - 19, y - 17, 11, ec, 0.9); glow(g, x + 19, y - 17, 11, ec, 0.9); el(g, x - 19, y - 17, 5.5, 3.2, red ? '#ff5a3a' : '#fff2c8'); el(g, x + 19, y - 17, 5.5, 3.2, red ? '#ff5a3a' : '#fff2c8');
  };
  BS.puppet = (g, x, y, B, T) => {
    const ph = B.ph, bob = Math.sin(T * 0.05) * 3, my = y + bob;
    for (let h = 0; h < 2; h++) {
      if (h && B.a[5]) continue;
      const hx = B.a[h * 2], hy = B.a[h * 2 + 1], hot = (B.a[4] & (1 << h)) || B.po === 'sweep' || B.po === 'clap', s = h ? -1 : 1;
      ln(g, 'rgba(220,210,230,.4)', 1, [hx - 8, hy - 18, hx - 8 + (x - hx) * 0.15, 0]); ln(g, 'rgba(220,210,230,.4)', 1, [hx + 8, hy - 18, hx + 8 + (x - hx) * 0.15, 0]);
      sd(g, 'hand', hx, hy, { fx: s, s: hot ? 1.14 : 1, rot: hot ? 0 : Math.sin(T * 0.04 + h * 2) * 0.06 * s, tint: hot ? 'rgba(255,90,150,.2)' : '' });
    }
    ln(g, 'rgba(220,210,230,.35)', 1, [x - 12, my - 34, x - 20, 0]); ln(g, 'rgba(220,210,230,.35)', 1, [x + 12, my - 34, x + 20, 0]);
    sd(g, 'mask', x, my, { rot: Math.sin(T * 0.03) * 0.04, tint: ph === 2 ? 'rgba(120,10,50,.16)' : '' });
    if (ph === 2) { glow(g, x - 10, my - 6, 7, '255,90,122', 0.9); glow(g, x + 10, my - 6, 7, '255,90,122', 0.9); ln(g, '#17131f', 1.5, [x + 4, my - 26, x - 2, my - 12, x + 8, my, x, my + 14]); }
  };
  BS.deep = (g, x, y, B, T) => {
    const ph = B.ph, bite = B.po === 'bite' || B.po === 'suck', lure = B.po === 'lure' ? (Math.sin(T * 0.55) > 0 ? 1 : 0.3) : 0.6 + Math.sin(T * 0.06) * 0.15;
    sd(g, 'deep', x, y, { s: bite ? 1.1 : 1, sx: bite ? 1.05 : 1, sy: 1 + Math.sin(T * 0.05) * 0.015, rot: bite ? -0.06 : Math.sin(T * 0.03) * 0.03, tint: ph === 2 ? 'rgba(80,255,220,.12)' : '' });
    const L2 = D.ART.lure || [-46, -50]; glow(g, x + L2[0], y + L2[1], 20, '170,255,230', lure * 0.9); el(g, x + L2[0], y + L2[1], 3.5, 3.5, 'rgba(230,255,246,' + lure + ')');
  };
  BS.core = (g, x, y, B, T) => {
    const ph = B.ph, pu = 1 + Math.sin(T * 0.08) * 0.05, sh = ph === 2 && B.a[1];
    for (let i = 0; i < 3; i++) { g.save(); g.translate(x, y); g.rotate(T * 0.01 * (i % 2 ? -1 : 1) + i * 1.05); g.strokeStyle = 'rgba(200,150,255,' + (0.75 - i * 0.12) + ')'; g.lineWidth = 3; g.beginPath(); g.ellipse(0, 0, 54 + i * 4, 19 + i * 6, 0, PI, TAU); g.stroke(); g.restore(); }
    if (ph >= 1) for (let i = 0; i < 6; i++) { const a = T * 0.02 + i * 1.047; po(g, '#6a3ac8', [x + Math.cos(a) * 62, y + Math.sin(a) * 32 - 6, x + Math.cos(a) * 62 + 5, y + Math.sin(a) * 32, x + Math.cos(a) * 62, y + Math.sin(a) * 32 + 6, x + Math.cos(a) * 62 - 5, y + Math.sin(a) * 32]); }
    sd(g, 'core', x, y, { s: pu });
    /* 세로로 긴 눈 + 앞쪽 고리(그림 위에 얹음) */
    el(g, x, y - 2, 9.5, 13, '#17131f'); el(g, x, y - 2, 4 + Math.sin(T * 0.1) * 1, 8, ph === 2 ? '#ff7ab0' : '#f0d8ff'); glow(g, x, y - 2, 16, ph === 2 ? '255,122,176' : '220,190,255', 0.5);
    for (let i = 0; i < 3; i++) { g.save(); g.translate(x, y); g.rotate(T * 0.01 * (i % 2 ? -1 : 1) + i * 1.05); g.strokeStyle = 'rgba(200,150,255,' + (0.75 - i * 0.12) + ')'; g.lineWidth = 3; g.beginPath(); g.ellipse(0, 0, 54 + i * 4, 19 + i * 6, 0, 0, PI); g.stroke(); g.restore(); }
    if (sh) { g.strokeStyle = 'rgba(120,240,230,.8)'; g.lineWidth = 3; g.fillStyle = 'rgba(120,240,230,.12)'; g.beginPath(); for (let i = 0; i <= 6; i++) { const a = i * 1.047 + T * 0.004; g.lineTo(x + Math.cos(a) * 54, y + Math.sin(a) * 54); } g.fill(); g.stroke(); for (let i = 0; i < B.a[0]; i++) ln(g, '#17131f', 2.5, [x - 30 + i * 26, y - 40, x - 22 + i * 26, y - 18, x - 34 + i * 26, y - 4]); }
    else if (ph === 2) { g.strokeStyle = 'rgba(120,240,230,.25)'; g.lineWidth = 1.5; g.setLineDash([6, 8]); g.beginPath(); g.arc(x, y, 54, 0, TAU); g.stroke(); g.setLineDash([]); }
  };
  const bossSpr = (id) => !!BREQ[id] && sprOk(BREQ[id]);
  /* 카드 · 등장 알림 · 표지에서 파수를 전투 모습 그대로 그릴 때 쓰는 가짜 상태(1단계, 제자리) */
  const CARD = { gate: [-14, -12, 130], bloom: [0, 44, 150], tide: [14, 12, 110], kiln: [0, 26, 170], rail: [0, 30, 185], swarm: [0, 10, 130], mirror: [-4, -22, 130], storm: [0, 0, 140], clock: [0, 26, 230], puppet: [0, 34, 180], deep: [-4, 10, 150], core: [0, 4, 140] };
  function fakeBoss(id) {
    const B = { id, ph: id === 'swarm' ? 1 : 0, po: '', fl: -1, k: 0, hf: 0, hr: 36, a: [0, 0, 0, 0, 0, 0] };
    if (id === 'mirror') B.a[0] = 1; if (id === 'puppet') B.a = [-64, 74, 64, 74, 0, 0];
    return B;
  }
  /* (cx, cy) 가운데에 높이 hpx 픽셀로 파수를 그림. 그림이 없으면 코드 그림 */
  function drawBossAt(g, id, cx, cy, hpx, T) {
    const c = CARD[id], k = hpx / c[2], B = fakeBoss(id), q = SPQ; let x = 0, y = 0;
    if (id === 'swarm') { x = 300; y = 150; } else if (id === 'clock' || id === 'bloom') { y = GY - (id === 'clock' ? 172 : 84); }
    if (id === 'puppet') { B.a[0] += x; B.a[2] += x; }
    g.save(); g.translate(cx, cy); g.scale(k, k); SPQ = Math.max(q, k * (G.devicePixelRatio || 1));
    if (id === 'swarm') g.translate(-310, -118 - c[1]); else g.translate(-x - c[0], -y - c[1]);
    const col = D.BI[id].col, gx = id === 'swarm' ? 310 : x + c[0], gy = id === 'swarm' ? 118 + c[1] : y + c[1], gl = g.createRadialGradient(gx, gy, 8, gx, gy, c[2] * 0.62); gl.addColorStop(0, col + '77'); gl.addColorStop(1, col + '00'); g.fillStyle = gl; g.fillRect(gx - c[2], gy - c[2], c[2] * 2, c[2] * 2);
    try { (bossSpr(id) ? BS : BD)[id](g, x, y, B, T, { pl: [] }); } catch (e) {}
    SPQ = q; g.restore();
  }

  /* ======================= 사수 그림 ======================= */
  /* 자세 그림 6장(서서 쏘기 · 위로 겨누기 · 달리기 · 뛰기 · 대시 · 피격)을 상태에 따라 고르고 흔들림 · 반동 · 총구 섬광 · 번쩍임을 코드로 입힘.
     2번 사수는 같은 그림에 푸른 색조. 발 자리 · 판정 점은 코드 그림과 같음 */
  const HMZ = { h_stand: [33, -41], h_aimup: [21, -67], h_run: [34, -31], h_jump: [34, -44], h_dash: [31, -27] };
  function drawHero(g, p, x, y, T, col, me) {
    if (!sprOk(HPOSE)) { drawHeroCode(g, p, x, y, T, col, me); return; }
    const fly = p._fly, run = p.g && Math.abs(p.vx) > 20, f = p.f, ga = g.globalAlpha;
    if (!fly) { g.globalAlpha = ga * 0.3; el(g, x, y + 1.5, 15, 4, col); g.globalAlpha = ga * 0.95; g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); g.ellipse(x, y + 1.5, 15, 4, 0, 0, TAU); g.stroke(); }
    else { g.globalAlpha = ga * 0.8; g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); g.arc(x, y - 24, 30, 0.6, 2.54); g.stroke(); }
    g.globalAlpha = ga;
    const tx = p.ax || x + f * 50, ty = p.ay || y - 24, a = Math.atan2(ty - (y - 24), tx - x), ca = Math.cos(a), sa = Math.sin(a);
    const hurt = p.inv > 62 && p.inv <= 84 && p.sp <= 0;
    let k = 'h_stand', rot = 0, oy = 0, sy = 1;
    if (hurt) { k = 'h_hit'; rot = -0.12 * f * clamp((p.inv - 62) / 22, 0, 1); }
    else if (p.dash > 0) k = 'h_dash';
    else if (fly) { k = 'h_jump'; rot = clamp((p.vy || 0) / 700, -0.22, 0.22) * f; oy = 4 + Math.sin(T * 0.08 + p.s) * 1.5; }
    else if (!p.g) { k = 'h_jump'; rot = clamp((p.vy || 0) / 1500, -0.14, 0.18) * f; oy = 3; }
    else if (run) { k = 'h_run'; const w = Math.sin(p.an * 0.11); oy = -Math.abs(w) * 2.4; rot = w * 0.04; }
    else { k = sa < -0.6 ? 'h_aimup' : 'h_stand'; sy = 1 + Math.sin(T * 0.06 + p.s) * 0.008; }
    const wp = D.WEAPONS[p.w[p.wi]], kick = wp && p.cd > 0 && !hurt ? clamp((p.cd - (wp.cd - 4)) / 4, 0, 1) : 0;
    const tint = hurt && p.inv > 77 ? 'rgba(255,255,255,.72)' : p.s !== 0 ? 'rgba(60,150,255,.32)' : '';
    sd(g, k, x - f * kick * 1.6, y + oy, { fx: f, rot, sy, tint });
    /* 총구 섬광(쏜 직후) · 겨눈 쪽 점 */
    const m = HMZ[k];
    if (kick > 0 && m && wp.id !== 'maul') { glow(g, x + f * m[0], y + oy + m[1], 5 + kick * 9, '255,226,150', 0.95 * kick); el(g, x + f * m[0], y + oy + m[1], 1 + kick * 2, 1 + kick * 2, '#fffbe8'); }
    g.globalAlpha = ga * 0.85; el(g, x + ca * 27, y - 26 + sa * 27, 2.6, 2.6, '#120e1c'); el(g, x + ca * 27, y - 26 + sa * 27, 1.7, 1.7, '#ffe08a'); g.globalAlpha = ga;
    /* 판정 점: 실제로 맞는 크기 */
    el(g, x, y - 15, S.PRAD - 0.5, S.PRAD - 0.5, '#120e1c'); el(g, x, y - 15, S.PRAD - 2, S.PRAD - 2, me ? '#ffffff' : 'rgba(255,255,255,.75)'); el(g, x, y - 15, 1.8, 1.8, col);
  }
  function drawHeroCode(g, p, x, y, T, col, me) {
    const fly = p._fly, run = p.g && Math.abs(p.vx) > 20, sw = run ? Math.sin(p.an * 0.11) : 0, f = p.f, mov = run || fly || !p.g, lag = (mov ? 3.5 : 0) + Math.sin(T * 0.07 + p.s) * 0.8;
    const P2 = p.s !== 0, hair = P2 ? '#bfe4ff' : '#fbf4ff', hair2 = P2 ? '#8fbdea' : '#d9cdea', coat = P2 ? '#e4edff' : '#fff1da', coat2 = P2 ? '#a9c0ee' : '#e6cfa6', OL = '#120e1c';
    const pso = (c, q) => { g.beginPath(); g.moveTo(q[0], q[1]); for (let i = 2; i < q.length; i += 2) g.lineTo(q[i], q[i + 1]); g.closePath(); g.lineJoin = 'round'; g.strokeStyle = OL; g.lineWidth = 2; g.stroke(); g.fillStyle = c; g.fill(); };
    const lno = (c, w, q) => { ln(g, OL, w + 2, q); ln(g, c, w, q); };
    /* 발밑 표식(자리 색) */
    const ga = g.globalAlpha;
    if (!fly) { g.globalAlpha = ga * 0.3; el(g, x, y + 1.5, 15, 4, col); g.globalAlpha = ga * 0.95; g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); g.ellipse(x, y + 1.5, 15, 4, 0, 0, TAU); g.stroke(); }
    else { g.globalAlpha = ga * 0.8; g.strokeStyle = col; g.lineWidth = 2; g.beginPath(); g.arc(x, y - 24, 30, 0.6, 2.54); g.stroke(); }
    g.globalAlpha = ga;
    g.save(); g.translate(x, y);
    if (p.dash > 0) g.scale(1.15, 0.9);
    g.scale(f * 1.42, 1.42);
    /* 긴 머리(뒤로 흐름) */
    pso(hair2, [-2.5, -37, -8 - lag, -30, -11 - lag * 1.6, -17, -6.5 - lag, -19, -4, -28]);
    /* 다리 */
    if (!p.g || fly) { lno('#cfc4e6', 2.6, [-1.5, -14, -5, -7, -8, -2]); lno('#cfc4e6', 2.6, [1.5, -14, 3, -7, -1, -1.5]); }
    else { lno('#cfc4e6', 2.6, [-1.5, -14, -1.5 - sw * 5, 0]); lno('#cfc4e6', 2.6, [1.5, -14, 1.5 + sw * 5, 0]); }
    /* 긴 겉옷: 허리가 들어가고 자락이 뒤로 퍼짐 */
    pso(coat2, [-4, -22, -10 - lag * 1.2, -7, -3, -9.5]);
    pso(coat, [-4.6, -30, 4.6, -30, 3.6, -22, 6.5, -9, -3.5, -9.5, -3.6, -22]);
    rr(g, -4.2, -22.6, 8.2, 2.4, 1, col); ln(g, col, 1.4, [0.5, -30, 2.2, -23]);
    /* 머리 */
    el(g, 0.3, -34.6, 5.4, 5.6, OL); el(g, 0.3, -34.6, 4.4, 4.6, '#fbe6d4');
    pso(hair, [-5, -34.5, -4.6, -40, 1.5, -41, 5.6, -37.5, 4.9, -34, 2.6, -37, -1.6, -36.6, -3.6, -31]);
    ln(g, hair, 1.5, [4.2, -35, 4.6, -29.5]);
    el(g, 2.5, -34.4, 0.9, 1.4, '#3a2a50');
    g.restore();
    /* 총(겨눈 쪽) */
    const a = Math.atan2((p.ay || y - 24) - (y - 24), (p.ax || x + f * 50) - x), ca = Math.cos(a), sa = Math.sin(a);
    ln(g, OL, 6.5, [x + ca * 3, y - 26 + sa * 3, x + ca * 19, y - 26 + sa * 19]); ln(g, '#f2e9d8', 3.6, [x + ca * 3, y - 26 + sa * 3, x + ca * 19, y - 26 + sa * 19]); el(g, x + ca * 21, y - 26 + sa * 21, 3.4, 3.4, '#ffe08a');
    /* 판정 점: 실제로 맞는 크기 */
    el(g, x, y - 15, S.PRAD - 0.5, S.PRAD - 0.5, OL); el(g, x, y - 15, S.PRAD - 2, S.PRAD - 2, me ? '#ffffff' : 'rgba(255,255,255,.75)'); el(g, x, y - 15, 1.8, 1.8, col);
  }

  /* ======================= 배경 ======================= */
  function paintBg(cv, b, W) {
    const g = cv.getContext('2d'), w = cv.width, k = w / AW; g.setTransform(k, 0, 0, k, 0, 0);
    const key = b.id === 'deep' ? 'deep' : b.bg;
    /* [하늘 위, 가운데, 아래, 먼 층, 중간 층, 앞 장식] */
    const TH = { ruin: ['#2b2760', '#4c4490', '#8262a4', '#5c549c', '#2c2858', '#17142e'], garden: ['#134640', '#22705e', '#57a47e', '#2f8a70', '#14483e', '#0b2a26'], sky: ['#27397a', '#4b64ac', '#8fa6d6', '#6f86c2', '#2a3a72', '#161e40'], deep: ['#0a3c4c', '#13626c', '#2f9088', '#1c7478', '#0c3c48', '#06242c'], forge: ['#3c1c20', '#6c2e26', '#9a4a2c', '#84402c', '#341619', '#1c0c0e'] }[key];
    const sky = g.createLinearGradient(0, 0, 0, GY); sky.addColorStop(0, TH[0]); sky.addColorStop(0.6, TH[1]); sky.addColorStop(1, TH[2]); g.fillStyle = sky; g.fillRect(0, 0, AW, AH);
    const sd = b.i * 31, R = (n) => hash(sd + n);
    if (key === 'ruin') {
      el(g, 500, 74, 46, 46, 'rgba(250,240,255,.10)'); el(g, 500, 74, 30, 30, 'rgba(250,244,255,.55)'); el(g, 490, 66, 7, 7, 'rgba(200,190,230,.5)');
      for (let i = 0; i < 9; i++) { const x = i * 80 - 20 + R(i) * 16, hh = 70 + R(i * 3) * 60; g.fillStyle = TH[3]; g.fillRect(x, GY - hh, 20, hh); g.fillRect(x - 4, GY - hh, 28, 5); g.strokeStyle = TH[3]; g.lineWidth = 7; g.beginPath(); g.arc(x + 50, GY - hh + 26, 40, PI, 0); g.stroke(); }
      for (let i = 0; i < 5; i++) { const x = 40 + i * 140 + R(i + 20) * 40, hh = 130 + R(i * 5) * 110; g.fillStyle = TH[4]; g.fillRect(x, GY - hh, 30, hh); g.fillRect(x - 6, GY - hh, 42, 8); g.fillRect(x - 3, GY - hh + 14, 36, 4); po(g, TH[4], [x, GY - hh, x + 8 + R(i) * 14, GY - hh - 18, x + 30, GY - hh]); g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(x + 3, GY - hh + 20, 5, hh - 20); }
      po(g, TH[5], [0, 0, 44, 0, 30, 60, 22, 150, 0, 190]); po(g, TH[5], [640, 0, 590, 0, 606, 80, 618, 170, 640, 210]);
    } else if (key === 'garden') {
      g.lineWidth = 4; for (let i = 0; i < 7; i++) { g.strokeStyle = TH[3]; g.beginPath(); g.arc(320, GY + 30, 110 + i * 62, PI, 0); g.stroke(); } for (let i = 0; i < 11; i++) { const a = PI + (i / 10) * PI; ln(g, TH[3], 2.5, [320 + Math.cos(a) * 110, GY + 30 + Math.sin(a) * 110, 320 + Math.cos(a) * 500, GY + 30 + Math.sin(a) * 500]); }
      for (let i = 0; i < 9; i++) { const x = i * 80 - 10 + R(i) * 30, hh = 40 + R(i * 3) * 70; el(g, x, GY - hh * 0.4, 36, hh * 0.6, TH[4]); el(g, x + 26, GY - hh * 0.2, 26, hh * 0.4, TH[4]); po(g, TH[4], [x - 6, GY - hh * 0.8, x + 2, GY - hh - 26, x + 10, GY - hh * 0.8]); }
      for (let i = 0; i < 13; i++) { const x = R(i + 40) * AW, l = 36 + R(i * 7) * 90; ln(g, TH[5], 2.5, [x, 0, x + Math.sin(i) * 8, l]); el(g, x + Math.sin(i) * 8, l, 5, 8, TH[5]); el(g, x + Math.sin(i) * 4 - 4, l * 0.55, 4, 6, TH[5], 0.6); }
      for (let i = 0; i < 16; i++) el(g, R(i + 70) * AW, 40 + R(i + 90) * 200, 1.6, 1.6, 'rgba(230,255,200,.35)');
    } else if (key === 'sky') {
      for (let i = 0; i < 8; i++) { const x = R(i) * AW, y = 40 + R(i * 5) * 110; el(g, x, y, 80 + R(i + 3) * 70, 13 + R(i * 2) * 10, 'rgba(210,222,250,.20)'); el(g, x + 30, y - 9, 46, 11, 'rgba(210,222,250,.16)'); }
      for (let i = 0; i < 7; i++) { const x = R(i + 30) * AW, y = 150 + R(i * 9) * 110; el(g, x, y, 100 + R(i + 5) * 80, 16 + R(i * 4) * 12, 'rgba(34,48,100,.34)'); }
      if (b.id === 'tide') { for (let i = 0; i < 6; i++) { const x = 30 + i * 112, hh = 46 + R(i) * 60; g.fillStyle = TH[4]; g.fillRect(x, GY - hh, 12, hh); g.fillRect(x - 8, GY - hh, 64, 6); g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(x + 2, GY - hh + 6, 3, hh); } for (let i = 0; i < 12; i++) el(g, i * 58 + 10, GY - 5, 34, 5, 'rgba(160,210,240,.25)'); }
      else for (let i = 0; i < 4; i++) ln(g, 'rgba(230,225,255,.12)', 2, [90 + i * 150, 0, 70 + i * 150 + R(i) * 30, 70, 96 + i * 150, 120]);
      po(g, TH[5], [0, GY, 0, GY - 44, 26, GY - 30, 54, GY]); po(g, TH[5], [640, GY, 640, GY - 56, 610, GY - 34, 588, GY]);
    } else if (key === 'deep') {
      for (let i = 0; i < 5; i++) po(g, 'rgba(170,240,225,.09)', [70 + i * 130, 0, 126 + i * 130, 0, 40 + i * 130, AH, -40 + i * 130, AH]);
      for (let i = 0; i < 9; i++) { const x = i * 78 + R(i) * 30; ln(g, TH[3], 7, [x, GY, x + 10, GY - 50 - R(i * 3) * 50, x - 6, GY - 110 - R(i * 5) * 60]); }
      for (let i = 0; i < 7; i++) { const x = i * 100 + R(i + 9) * 40; el(g, x, GY + 4, 50 + R(i) * 30, 26 + R(i * 2) * 24, TH[4]); }
      for (let i = 0; i < 18; i++) { const x = R(i + 50) * AW, y = R(i + 60) * 250; g.strokeStyle = 'rgba(200,255,245,.3)'; g.lineWidth = 1; g.beginPath(); g.arc(x, y, 1.5 + R(i) * 3, 0, TAU); g.stroke(); }
      po(g, TH[5], [0, 0, 60, 0, 30, 40, 0, 90]); po(g, TH[5], [640, 0, 600, 0, 620, 60, 640, 120]);
    } else {
      g.fillStyle = TH[3]; g.fillRect(0, 60, AW, 8); g.fillRect(0, 150, AW, 5);
      for (let i = 0; i < 6; i++) { const x = 34 + i * 108; rr(g, x, 84, 46, 54, 5, TH[4]); rr(g, x + 5, 89, 36, 44, 4, 'rgba(255,170,80,.38)'); g.fillStyle = TH[4]; g.fillRect(x + 21, 89, 4, 44); g.fillRect(x + 5, 109, 36, 3); }
      for (let i = 0; i < 6; i++) { const x = 20 + i * 112 + R(i) * 20; g.fillStyle = TH[4]; g.fillRect(x, 160, 18, GY - 160); g.fillRect(x - 5, 176 + R(i) * 60, 28, 7); g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(x + 2, 160, 4, GY - 160); }
      for (let i = 0; i < 5; i++) el(g, 70 + i * 130, GY + 6, 80, 30, 'rgba(255,150,70,.16)');
      g.fillStyle = TH[5]; g.fillRect(0, 0, AW, 16); for (let i = 0; i < 7; i++) { const x = 30 + i * 96 + R(i + 11) * 30, l = 30 + R(i * 3) * 60; ln(g, TH[5], 3, [x, 14, x, l]); g.strokeStyle = TH[5]; g.lineWidth = 3; g.beginPath(); g.arc(x, l + 5, 5, 0, TAU); g.stroke(); }
    }
    /* 탄이 묻히지 않게 살짝 누름 */
    g.fillStyle = 'rgba(10,8,20,.12)'; g.fillRect(0, 0, AW, AH);
    void W;
  }

  /* ======================= 본체 ======================= */
  function mount(root, api) {
    const h = L.h, cvs = U.canvas(root), g = cvs.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const testBot = () => !!(L.debug && (L.debug.autoplay || (L.debug.noTut && api.online)));
    const ME = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const isHost = () => !api.online || api.isHost;
    const humanHere = (s) => { const p = api.players[s]; return !!p && !p.ai && (!api.online || !!p.local) && !testBot(); };
    const controlledHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !!p.local && !p.ai; };
    let st = null, W = null, wkey = '', dead = false, raf = 0, last = 0, acc = 0, T = 0, sc = 1, ox = 0, oy = 0, bgc = null, bgKey = '';
    let touchUI = false, sentOver = false, overT = 0, failEl = null, pickEl = null, pickBar = null, myPick = null, waitEl = null, shake = 0, flash = 0, evSeen = 0, recNote = null, recT = 0;
    const offs = [], parts = [], pend = { jump: 0, dash: 0, par: 0, sp: 0, sw: 0 };
    const cnt = { par: 0, sp: 0, sw: 0 }, rmSeen = {};
    const imgs = {};
    const loadImg = (k) => { if (imgs[k] === undefined) { const im = new Image(); im.onload = () => { imgs[k] = im; bgKey = ''; }; im.onerror = () => { imgs[k] = null; }; imgs[k] = null; im.src = 'assets/bossrun/' + k + '.webp'; } return imgs[k]; };
    try { touchUI = !!L.touchOnly(); } catch (e) {}
    const auto = () => (D.store.get('auto', 1) ? 1 : 0);

    /* ---------- 입력 ---------- */
    offs.push(api.input.on((type, id) => {
      if (type !== 'down') return;
      if (pickEl && id === 'jump') { confirmPick(); return; }
      if (failEl && id === 'jump') { retry(); return; }
      if (id === 'jump' || id === 'up') pend.jump = 1; else if (id === 'dash') pend.dash = 1; else if (id === 'parry') pend.par = 1; else if (id === 'special') pend.sp = 1; else if (id === 'swap') pend.sw = 1;
    }));
    const tc = { stick: null, sx: 0, sy: 0, mx: 0, my: 0, btn: {}, held: {} };
    const btnK = () => (L.ui && L.ui.ctlScale ? L.ui.ctlScale() : 1) * clamp(Math.min(cvs.w, cvs.h) / 360, 0.9, 1.5);
    function buttons() {
      const k = btnK(), w = cvs.w, hh = cvs.h, b = [];
      const fly = W && W.fly;
      if (!fly) b.push({ id: 'jump', x: w - 46 * k, y: hh - 48 * k, r: 36 * k, t: '점프' });
      b.push({ id: 'dash', x: fly ? w - 46 * k : w - 122 * k, y: fly ? hh - 48 * k : hh - 36 * k, r: (fly ? 36 : 27) * k, t: '대시' });
      b.push({ id: 'parry', x: w - 108 * k, y: hh - 100 * k, r: 29 * k, t: '받아치기' });
      b.push({ id: 'special', x: w - 40 * k, y: hh - 126 * k, r: 25 * k, t: '필살' });
      b.push({ id: 'swap', x: w - 38 * k, y: hh - 182 * k, r: 22 * k, t: '무기' });
      if (!auto()) b.push({ id: 'fire', x: w - 100 * k, y: hh - 160 * k, r: 24 * k, t: '사격' });
      return b;
    }
    function onDown(e) {
      if (e.pointerType === 'touch' && !touchUI) touchUI = true;
      if (!touchUI || !W || pickEl || failEl) return;
      const q = cvs.local(e);
      for (const b of buttons()) if (Math.hypot(q.x - b.x, q.y - b.y) < b.r + 8) {
        tc.btn[e.pointerId] = b.id; tc.held[b.id] = 1;
        if (b.id === 'jump') pend.jump = 1; else if (b.id === 'dash') pend.dash = 1; else if (b.id === 'parry') pend.par = 1; else if (b.id === 'special') pend.sp = 1; else if (b.id === 'swap') pend.sw = 1;
        try { api.buzz(8, 'ui'); } catch (er) {}
        e.preventDefault(); return;
      }
      if (q.x < cvs.w * 0.5 && tc.stick == null) { tc.stick = e.pointerId; tc.sx = q.x; tc.sy = q.y; tc.mx = tc.my = 0; tc.cx = q.x; tc.cy = q.y; e.preventDefault(); }
    }
    function onMove(e) {
      if (tc.stick !== e.pointerId) return;
      const q = cvs.local(e), dx = q.x - tc.sx, dy = q.y - tc.sy, dz = 9, fly = W && W.fly;
      tc.cx = q.x; tc.cy = q.y;
      tc.mx = Math.abs(dx) > dz ? clamp(dx / 30, -1, 1) : 0; tc.my = Math.abs(dy) > (fly ? dz : 26) ? clamp(dy / 30, -1, 1) : 0;
      if (!fly) tc.mx = tc.mx > 0.3 ? 1 : tc.mx < -0.3 ? -1 : 0;
      /* 막대를 멀리 끌면 기준점이 따라옴(손가락이 화면 끝에 막히지 않게) */
      const m = Math.hypot(dx, dy); if (m > 46) { tc.sx += dx * (1 - 46 / m); tc.sy += dy * (1 - 46 / m); }
    }
    function onUp(e) {
      if (tc.stick === e.pointerId) { tc.stick = null; tc.mx = tc.my = 0; }
      const b = tc.btn[e.pointerId]; if (b) { delete tc.btn[e.pointerId]; tc.held[b] = 0; }
    }
    cvs.cv.addEventListener('pointerdown', onDown); cvs.cv.addEventListener('pointermove', onMove); cvs.cv.addEventListener('pointerup', onUp); cvs.cv.addEventListener('pointercancel', onUp);
    function readInput(first) {
      const fly = W.fly, I = api.input;
      let mx = I.axis('left', 'right') + tc.mx, my = I.axis('up', 'down') + tc.my;
      if (!fly) { mx = mx > 0.35 ? 1 : mx < -0.35 ? -1 : 0; if (my < 0) my = 0; } else { mx = clamp(mx, -1, 1); my = clamp(my, -1, 1); }
      const i = { mx, my, jump: I.held('jump') || (!fly && I.held('up')) || tc.held.jump ? 1 : 0, fire: auto() || I.held('fire') || tc.held.fire ? 1 : 0 };
      if (first) { i.jumpE = pend.jump; i.dashE = pend.dash; i.parE = pend.par; i.spE = pend.sp; i.swE = pend.sw; pend.jump = pend.dash = pend.par = pend.sp = pend.sw = 0; }
      return i;
    }

    /* ---------- 장비 고르기 ---------- */
    function closePick() { if (pickEl) { pickEl.remove(); pickEl = null; } }
    function confirmPick() {
      if (!pickEl || !myPick) return;
      const me = ME(); D.store.set('ld', myPick);
      closePick(); api.sfx('click');
      if (isHost()) { const ld = st.ld.slice(); ld[me] = myPick.slice(); tryStart(Object.assign({}, st, { ld })); }
      else showWait('방장 기기에서 판을 여는 중');
    }
    function tryStart(s) {
      const waiting = s.ld.some((x, i) => !x && !api.players[i].ai && !(i === ME() && testBot()));
      if (waiting) { api.setState(Object.assign({}, s, { seq: s.seq + 1 })); return; }
      const ld = s.ld.map((x) => x || D.aiLoadout(Math.random));
      api.setState(Object.assign({}, s, { ld, ph: 'play', seq: s.seq + 1 }));
    }
    function showWait(t) { if (!waitEl) { waitEl = h('div', { style: { position: 'absolute', left: '50%', bottom: '18%', transform: 'translateX(-50%)', padding: '8px 14px', borderRadius: '10px', background: 'rgba(16,14,24,.8)', color: '#f2e9d8', fontSize: '14px', zIndex: 6, pointerEvents: 'none' } }); root.append(waitEl); } waitEl.textContent = t; }
    function hideWait() { if (waitEl) { waitEl.remove(); waitEl = null; } }
    function openPick() {
      if (pickEl) return;
      const b = D.BI[st.list[st.bi]], saved = D.store.get('ld', [0, 1, 0]);
      myPick = [clamp(saved[0] | 0, 0, D.WEAPONS.length - 1), clamp(saved[1] | 0, 0, D.WEAPONS.length - 1), clamp(saved[2] | 0, 0, D.CHARMS.length - 1)]; if (myPick[0] === myPick[1]) myPick[1] = (myPick[0] + 1) % D.WEAPONS.length;
      const f = clamp(Math.min(cvs.w / 640, cvs.h / 360), 1, 2), port = cvs.h > cvs.w;
      const rec = D.store.get('rec', {})[b.id + (st.hard ? '+' : '')], seen = D.store.get('seen', []).indexOf(b.id) >= 0;
      const desc = h('div', { style: { fontSize: '1em', lineHeight: '1.4', minHeight: '2.8em', color: '#d8cfe0', marginTop: '.4em' } });
      const say = (nm, d) => { desc.innerHTML = ''; desc.append(h('b', { style: { color: '#f2e9d8' }, text: nm + ' ' }), document.createTextNode(d)); };
      const chip = (icon, nm, on, badge, fn) => {
        const e = h('button', { style: { minHeight: '44px', minWidth: '0', padding: '.25em .4em', borderRadius: '.6em', border: '2px solid ' + (on ? '#62e8dc' : 'rgba(255,255,255,.14)'), background: on ? 'rgba(98,232,220,.14)' : 'rgba(255,255,255,.05)', color: '#f2e9d8', display: 'flex', alignItems: 'center', gap: '.35em', fontSize: '1em', fontFamily: 'inherit', cursor: 'pointer', position: 'relative', textAlign: 'left', wordBreak: 'keep-all', lineHeight: '1.15' }, onclick: fn });
        const ic = h('span', { style: { width: '1.9em', height: '1.9em', flex: '0 0 auto', display: 'block' } }); ic.innerHTML = icon; e.append(ic, h('span', { text: nm }));
        if (badge) e.append(h('span', { style: { position: 'absolute', right: '.25em', top: '.1em', fontSize: '1em', color: '#62e8dc', fontFamily: 'var(--f-mono)' }, text: badge }));
        return e;
      };
      const wg = h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '.35em' } }), cg = h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: '.35em' } });
      const draw = () => {
        wg.innerHTML = ''; cg.innerHTML = '';
        D.WEAPONS.forEach((w, i) => { const at = myPick[0] === i ? 1 : myPick[1] === i ? 2 : 0; wg.append(chip(D.svgW(D.WIC[w.id](w.col)), w.nm, at, at ? String(at) : '', () => { if (!at) { myPick[1] = myPick[0]; myPick[0] = i; } else if (at === 2) { myPick[1] = myPick[0]; myPick[0] = i; } say(w.nm + ' (' + w.kd + ' · 초당 ' + D.dps(w) + ')', w.d); draw(); })); });
        D.CHARMS.forEach((c, i) => { cg.append(chip(D.svgW(D.CIC[c.id]), c.nm, myPick[2] === i, '', () => { myPick[2] = i; say(c.nm, c.d); draw(); })); });
        if (sumFn) sumFn();
      };
      let sumFn = null;
      draw(); say(D.WEAPONS[myPick[0]].nm + ' (' + D.WEAPONS[myPick[0]].kd + ')', D.WEAPONS[myPick[0]].d);
      const lab = (t) => h('div', { style: { fontSize: '1em', color: '#ab9fb8', margin: '.5em 0 .25em' }, text: t });
      const art = true, sh = '0 1px 3px #0e0c16, 0 0 6px #0e0c16';
      const roomy = !port && cvs.h >= 560, wide = roomy && cvs.w >= 1500;   // PC처럼 넓은 화면: 고른 장비 요약 · 사수 그림 · 패턴 목록으로 빈자리를 채움
      const card = h('div', { style: { flex: port ? '0 0 auto' : '0 0 30%', display: 'flex', flexDirection: 'column', gap: '.35em', minWidth: '0', position: 'relative', textShadow: sh } },
        h('div', { style: { flex: port ? '0 0 11em' : '1 1 auto' } }),
        h('div', { style: { fontSize: '1em', color: '#d8cfe0' }, text: (st.list.length > 1 ? '연전 ' + (st.bi + 1) + '/' + st.list.length + ' · ' : '') + (st.hard ? '어려움' : '보통') + (st.try ? ' · 다시 도전 ' + st.try : '') }),
        h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '1.9em', color: b.col, lineHeight: '1.1' }, text: b.nm }),
        h('div', { style: { fontSize: '1em', color: '#e3ae45' }, text: b.ty + ' · ' + '★'.repeat(b.lv) + ' · ' + b.hp.length + '단계' }),
        h('div', { style: { fontSize: '1em', lineHeight: '1.4', color: '#d8cfe0' }, text: seen ? b.d : '처음 만나는 파수. 예고를 잘 볼 것.' }),
        h('div', { style: { fontSize: '1em', color: '#d8cfe0' }, text: rec ? '기록 ' + D.fmtT(rec.t) + ' · 피격 ' + rec.h + ' · 등급 ' + D.GRADES[rec.g] : '기록 없음' }),
        h('button', { class: 'btn primary', 'data-action': 'jump', style: { minHeight: '48px', fontSize: '1.25em', width: '100%', textShadow: 'none' }, text: '시작', onclick: confirmPick }));
      {
        /* 파수 카드: 무대 배경 위에 전투 모습 그대로(같은 그림 · 같은 그리기 함수)를 기기 배율 캔버스에 그림. 글이 놓이는 아래쪽만 어둡게 */
        const pic = h('div', { style: { position: 'absolute', left: '-.5em', right: '-.5em', top: '-.5em', bottom: '3.6em', zIndex: '-1', borderRadius: '.7em', overflow: 'hidden', pointerEvents: 'none', background: '#15121f' } });
        const cvp = h('canvas', { style: { position: 'absolute', left: '0', top: '0', width: '100%', height: '100%', display: 'block' } });
        pic.append(cvp, h('div', { style: { position: 'absolute', inset: '0', background: 'linear-gradient(to bottom, rgba(14,12,22,0) 0%, rgba(14,12,22,.1) ' + (port ? 45 : 34) + '%, rgba(14,12,22,.86) ' + (port ? 72 : 60) + '%, rgba(14,12,22,.95) 100%)', boxShadow: 'inset 0 0 0 1px ' + b.col + '55', borderRadius: '.7em' } }));
        card.style.zIndex = '0'; card.prepend(pic);
        const bgIm = D.ART.bg.indexOf(b.bg) >= 0 ? new Image() : null; if (bgIm) bgIm.src = 'assets/bossrun/bg_' + b.bg + '.webp';
        bossSpr(b.id); sprOk(HPOSE);
        const t0 = performance.now(); let myEl = null;
        const paint = () => {
          if (dead || (myEl && pickEl !== myEl)) return; myEl = pickEl; requestAnimationFrame(paint);
          const r = pic.getBoundingClientRect(), dp = Math.max(2, G.devicePixelRatio || 1), w = Math.round(r.width * dp), hh = Math.round(r.height * dp); if (w < 4 || hh < 4) return;
          if (cvp.width !== w || cvp.height !== hh) { cvp.width = w; cvp.height = hh; }
          const c = cvp.getContext('2d'); c.setTransform(1, 0, 0, 1, 0, 0); c.imageSmoothingQuality = 'high'; c.fillStyle = '#15121f'; c.fillRect(0, 0, w, hh);
          if (bgIm && bgIm.complete && bgIm.naturalWidth) { const k = Math.max(w / bgIm.naturalWidth, hh / bgIm.naturalHeight); c.drawImage(bgIm, (w - bgIm.naturalWidth * k) / 2, (hh - bgIm.naturalHeight * k) / 2, bgIm.naturalWidth * k, bgIm.naturalHeight * k); c.fillStyle = 'rgba(10,8,20,.22)'; c.fillRect(0, 0, w, hh); }
          const top = port ? 0.44 : 0.36, hp = Math.min(hh * (port ? 0.8 : 0.6), w * 1.02);
          drawBossAt(c, b.id, w / 2, hh * top, hp, (performance.now() - t0) * 0.06);
        };
        requestAnimationFrame(paint);
      }
      /* 넓은 화면: 고른 장비 요약(늘 보임) */
      const sumEl = h('div', { style: { display: roomy ? 'grid' : 'none', gap: '.4em', marginTop: '.8em' } });
      const srow = (icon, tag, nm, stat, d) => {
        const ic = h('span', { style: { width: '2.3em', height: '2.3em', flex: '0 0 auto', display: 'block' } }); ic.innerHTML = icon;
        return h('div', { style: { display: 'flex', gap: '.6em', alignItems: 'center', padding: '.4em .6em', borderRadius: '.6em', background: 'rgba(255,255,255,.045)', border: '1px solid rgba(255,255,255,.09)' } }, ic,
          h('div', { style: { minWidth: '0', lineHeight: '1.35' } },
            h('div', null, h('span', { style: { color: '#62e8dc', marginRight: '.5em' }, text: tag }), h('b', { text: nm }), stat ? h('span', { style: { color: '#e3ae45', marginLeft: '.6em' }, text: stat }) : null),
            h('div', { style: { color: '#d8cfe0' }, text: d })));
      };
      sumFn = () => {
        if (!roomy) return; sumEl.innerHTML = '';
        [0, 1].forEach((i) => { const w = D.WEAPONS[myPick[i]]; sumEl.append(srow(D.svgW(D.WIC[w.id](w.col)), (i + 1) + '번 무기', w.nm, w.kd + ' · 초당 ' + D.dps(w) + ' · 한 발 ' + w.dmg + (w.n ? ' ×' + w.n : '') + (w.rng ? ' · 거리 ' + w.rng : ''), w.d)); });
        const c = D.CHARMS[myPick[2]]; sumEl.append(srow(D.svgW(D.CIC[c.id]), '부적', c.nm, '', c.d));
      };
      sumFn(); if (roomy) desc.style.display = 'none';
      const lo = h('div', { style: { flex: '1 1 auto', minWidth: '0' } }, lab('무기 둘 — 누른 것이 1번, 앞서 고른 것이 2번'), wg, lab('부적 하나'), cg, desc, roomy ? lab('고른 장비') : null, sumEl);
      /* 아주 넓은 화면: 사수 그림 + 이 파수의 패턴 목록(만난 적이 있을 때) */
      let side = null;
      if (wide) {
        const me = ME(), pats = h('div', { style: { flex: '0 0 auto', padding: '.5em .7em', borderRadius: '.7em', background: 'rgba(255,255,255,.045)', border: '1px solid rgba(255,255,255,.09)', lineHeight: '1.4' } }, h('div', { style: { color: '#ab9fb8', marginBottom: '.2em' }, text: '파수 패턴' }));
        if (seen) b.pats.forEach((ph, i) => pats.append(h('div', null, h('span', { style: { color: b.col, marginRight: '.5em' }, text: (i + 1) + '단계' }), document.createTextNode(ph.map((p) => p[0]).join(' · ')))));
        else pats.append(h('div', { style: { color: '#d8cfe0' }, text: '한 번 맞서면 여기에 적힘.' }));
        side = h('div', { style: { flex: '0 0 22%', minWidth: '0', display: 'flex', flexDirection: 'column', gap: '.6em' } },
          h('div', { style: { flex: '1 1 0', minHeight: '0', position: 'relative', borderRadius: '.7em', overflow: 'hidden', background: 'linear-gradient(#262048,#15121f)', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.1)' } },
            D.ART.hero ? h('img', { src: 'assets/bossrun/hero.webp', alt: '', draggable: 'false', onerror() { this.remove(); }, style: { position: 'absolute', left: '0', top: '0', width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% 0%' } }) : null,
            h('div', { style: { position: 'absolute', left: '0', right: '0', bottom: '0', padding: '1.6em .7em .5em', background: 'linear-gradient(to bottom, rgba(14,12,22,0), rgba(14,12,22,.9))', textShadow: sh } },
              h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '1.35em' }, text: me > 0 ? D.HERO.nm2 : D.HERO.nm }),
              h('div', { style: { color: '#d8cfe0' }, text: '체력 ' + D.HERO.hp + ' · 대시 무적 ' + D.HERO.dash + '초 · 받아치기 ' + D.HERO.parry + '초' }))),
          pats);
      }
      pickEl = h('div', { style: { position: 'absolute', inset: '0', zIndex: 6, background: 'rgba(14,12,22,.93)', color: '#f2e9d8', fontSize: 12.5 * f + 'px', padding: '.9em 1.1em', paddingRight: port ? '1.1em' : '4.4em', display: 'flex', flexDirection: port ? 'column' : 'row', gap: '1.1em', overflowY: 'auto', boxSizing: 'border-box' } }, card, lo, side);
      root.append(pickEl);
      if (api.online && api.isHost && !pickBar) pickBar = api.pickBar({ picked: (s) => !!(st && st.ld && st.ld[s]), onForce() { closePick(); const ld = st.ld.map((x) => x || D.aiLoadout(Math.random)); api.setState(Object.assign({}, st, { ld, ph: 'play', seq: st.seq + 1 })); } });
    }

    /* ---------- 쓰러졌을 때 ---------- */
    function closeFail() { if (failEl) { failEl.remove(); failEl = null; } }
    function retry() {
      if (!failEl || !isHost()) return; closeFail();
      const one = st.list.length === 1;
      api.setState(Object.assign({}, st, { try: (st.try || 0) + 1, bi: one ? st.bi : 0, carry: null, log: one ? st.log : [], acc: one ? st.acc : null, seed: 1 + Math.floor(Math.random() * 2e9), seq: st.seq + 1 }));
    }
    function giveUp() { closeFail(); finish(0); }
    function openFail() {
      if (failEl) return;
      const b = D.BI[W.bid], left = leftFrac();
      failEl = h('div', { style: { position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', zIndex: 6, background: 'rgba(20,16,30,.94)', border: '1px solid rgba(255,255,255,.15)', borderRadius: '14px', padding: '14px 18px', color: '#f2e9d8', textAlign: 'center', minWidth: '250px' } },
        D.ART.hero ? h('img', { src: 'assets/bossrun/hero_down.webp', alt: '', draggable: 'false', onerror() { this.remove(); }, style: { display: 'block', width: '116px', height: '116px', objectFit: 'cover', borderRadius: '50%', margin: '0 auto 6px', border: '2px solid rgba(255,255,255,.22)', background: '#15121f' } }) : null,
        h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '22px' }, text: '쓰러짐' }),
        h('div', { style: { fontSize: '14px', color: '#d8cfe0', margin: '6px 0 12px' }, text: b.nm + ' ' + (W.B.ph + 1) + '단계 · 남은 체력 ' + Math.round(left * 100) + '%' }),
        h('div', { style: { display: 'flex', gap: '8px', justifyContent: 'center' } },
          h('button', { class: 'btn', style: { minHeight: '46px' }, text: '그만하기', onclick: giveUp }),
          h('button', { class: 'btn primary', 'data-action': 'jump', style: { minHeight: '46px', minWidth: '130px' }, text: st.list.length > 1 ? '처음부터 다시' : '다시 도전', onclick: retry })));
      root.append(failEl);
    }
    const leftFrac = () => { const b = D.BI[W.bid]; let rest = W.B.hp; for (let i = W.B.ph + 1; i < b.hp.length; i++) rest += b.hp[i] * W.hs; return clamp(rest / W.tot, 0, 1); };
    const statsNow = () => W.P.map((p, s) => { const a = (st.acc && st.acc[s]) || { d: 0, p: 0, h: 0, r: 0 }; return { d: a.d + Math.round(p.dmg), p: a.p + p.pn, h: a.h + p.hits, r: a.r + p.rv }; });
    function finish(win) { api.setState(Object.assign({}, st, { ph: 'done', seq: st.seq + 1, res: { win: win ? 1 : 0, st: statsNow(), bph: W.B.ph, left: leftFrac() } })); }
    function onOver() {
      const me = ME(), hum = me >= 0 && humanHere(me), bid = W.bid;
      if (W.over.win) {
        const myHits = me >= 0 ? W.P[me].hits : W.P[0].hits, gr = D.gradeOf(D.BI[bid], W.time, myHits);
        if (hum) { const r = D.saveRec(bid, W.time, myHits, st.hard); try { api.best('b_' + bid + (st.hard ? '_h' : ''), Math.round(W.time * 10) / 10, { label: D.BI[bid].nm + (st.hard ? ' (어려움)' : ''), lower: true, fmt: 'time' }); } catch (e) {} recNote = '등급 ' + D.GRADES[gr] + (r && r.best ? ' · 새 기록' : ''); recT = T; }
        if (!isHost()) return;
        const log = (st.log || []).concat([[bid, Math.round(W.time), W.P[0].hits, gr]]);
        if (st.bi < st.list.length - 1) api.setState(Object.assign({}, st, { bi: st.bi + 1, log, acc: statsNow(), carry: W.P.map((p) => Math.min(p.mhp, Math.max(1, p.hp) + 1)), seq: st.seq + 1 }));
        else api.setState(Object.assign({}, st, { log, ph: 'done', seq: st.seq + 1, res: { win: 1, st: statsNow(), bph: W.B.ph, left: 0 } }));
      } else {
        if (!isHost()) { showWait('방장이 다시 도전할지 정하는 중'); return; }
        if (hum) openFail(); else finish(0);
      }
    }

    /* ---------- 사건 → 소리 · 입자 ---------- */
    let ps = 7;
    const pr = () => { ps = (Math.imul(ps, 1664525) + 1013904223) | 0; return (ps >>> 0) / 4294967296; };
    function burst(x, y, n, c, sp, r) { if (parts.length > 160) return; for (let i = 0; i < n; i++) { const a = pr() * TAU, v = sp * (0.4 + pr() * 0.6); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 0, L: 18 + pr() * 14, c, r: r || 2.5 }); } }
    const snd = (n, o) => { if (SPD() > 2) return; try { api.sfx(n, o); } catch (e) {} };
    function onEv(e) {
      const ty = e[1], x = e[2], y = e[3], me = ME(), fx = L.fx ? L.fx() : 1;
      if (ty === 'tele') snd('tick', { pitch: 0.6, vol: 0.7 });
      else if (ty === 'zap') { snd('thud', { vol: 0.35 }); }
      else if (ty === 'rush') snd('whoosh', { vol: 0.6 });
      else if (ty === 'thud') { snd('thud', { vol: 0.7 }); burst(x, y - 2, 8, 'rgba(220,200,180,.7)', 2.4); shake = Math.max(shake, 5 * fx); }
      else if (ty === 'par0') snd('tick', { pitch: 1.5, vol: 0.4 });
      else if (ty === 'par') { snd('chip', { pitch: 1.4 }); burst(x, y, 12, '#7ff0e8', 3.2, 3); if (e[4] === me) { try { api.buzz(14, 'hit'); } catch (er) {} } }
      else if (ty === 'hurt') { snd('hit'); burst(x, y, 10, '#ff8a7a', 2.8); if (e[4] === me) { shake = Math.max(shake, 7 * fx); flash = 0.3 * fx; try { api.buzz(40, 'hit'); } catch (er) {} } }
      else if (ty === 'ward') { snd('bounce'); burst(x, y, 10, '#8fb0e0', 2.6); }
      else if (ty === 'down') snd('thud', { pitch: 0.7 });
      else if (ty === 'revive') { snd('pop', { pitch: 1.3 }); burst(x, y, 14, '#fff6dc', 3); }
      else if (ty === 'sp') { snd('whoosh', { pitch: 0.8 }); snd('hit', { vol: 0.8 }); shake = Math.max(shake, 6 * fx); }
      else if (ty === 'dash') snd('whoosh', { vol: 0.3, pitch: 1.4 });
      else if (ty === 'swap') snd('click', { vol: 0.5 });
      else if (ty === 'clink') burst(x - 20, y, 3, '#bfe8f4', 2);
      else if (ty === 'break') { snd('chip', { pitch: 0.7 }); burst(x, y, 18, '#bfe8f4', 3.6, 3); }
      else if (ty === 'phase') { snd('roll'); burst(x, y, 24, '#fff6dc', 4.2, 3); shake = Math.max(shake, 6 * fx); }
      else if (ty === 'dead') { snd('roll', { pitch: 0.7 }); burst(x, y, 40, '#fff6dc', 5, 3.5); shake = Math.max(shake, 8 * fx); }
      else if (ty === 'pop') { snd('pop', { vol: 0.5 }); burst(x, y, 7, '#e8c060', 2.4); }
      else if (ty === 'splash') burst(x, y - 2, 4, 'rgba(255,170,90,.7)', 1.8);
      else if (ty === 'maul') burst(x, y, 5, '#ffffff', 2.6);
      else if (ty === 'chg') snd('pop', { vol: 0.4, pitch: 0.8 });
    }
    function drainEv() { for (const e of W.ev) if (e[0] > evSeen) { evSeen = e[0]; onEv(e); } }

    /* ---------- 온라인 ---------- */
    let pubT = 0, hsT = -1;
    const key = () => st.rid + ':' + st.seed + ':' + st.bi + ':' + (st.try || 0);
    function pollNet() {
      if (!api.online || !st) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) {}
        if (!rem) return;
        for (const kk in rem) {
          const o = rem[kk], s = +kk; if (!o || o.r !== st.rid || controlledHere(s)) continue;
          if (st.ph === 'pick' && Array.isArray(o.pk) && !st.ld[s]) { const ld = st.ld.slice(); ld[s] = [clamp(o.pk[0] | 0, 0, D.WEAPONS.length - 1), clamp(o.pk[1] | 0, 0, D.WEAPONS.length - 1), clamp(o.pk[2] | 0, 0, D.CHARMS.length - 1)]; tryStart(Object.assign({}, st, { ld })); return; }
          if (W && o.k === key() && o.c) rmSeen[s] = Object.assign(rmSeen[s] || { par: o.n[0], sp: o.n[1], sw: o.n[2], fk: o.n[3] }, { c: o.c, n: o.n, f: o.f });
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) {}
        if (W && hs && hs.k === key() && hs.t !== hsT) { hsT = hs.t; const evs = S.applyHost(W, hs, ME()); for (const e of evs) onEv(e); }
      }
    }
    function remoteInput(s) {
      const q = rmSeen[s]; if (!q || !q.c) return {};
      const c = q.c, i = { rm: { x: c[0] / 2, y: c[1] / 2, vx: c[2], vy: c[3], f: c[4] & 1 ? 1 : -1, g: c[4] & 2 ? 1 : 0, di: c[4] & 4 ? 1 : 0, fk: 0 }, rf: q.f ? 1 : 0 };
      if (q.n[0] !== q.par) { q.par = q.n[0]; i.parE = 1; } if (q.n[1] !== q.sp) { q.sp = q.n[1]; i.spE = 1; } if (q.n[2] !== q.sw) { q.sw = q.n[2]; i.swE = 1; } if (q.n[3] !== q.fk) { q.fk = q.n[3]; i.rm.fk = 1; }
      return i;
    }
    function publish(dt) {
      if (!api.online || !st) return;
      pubT -= dt; if (pubT > 0) return; pubT = 1 / 15;
      try {
        if (api.isHost) { if (W && st.ph === 'play') { const o = S.packHost(W); o.k = key(); api.net.hostSend(o); } }
        else {
          const me = ME(), o = { r: st.rid }; if (me < 0) return;
          if (st.ph === 'pick' && myPick && !pickEl) o.pk = myPick;
          if (W && st.ph === 'play') { const p = W.P[me]; o.k = key(); o.c = S.packMe(p); o.n = [cnt.par, cnt.sp, cnt.sw, p.fkn || 0]; o.f = lastFire; }
          api.net.publish(o);
        }
      } catch (e) {}
    }
    let lastFire = 1;

    /* ---------- 판 진행 ---------- */
    function ensureWorld() {
      if (!st || st.ph === 'pick' || !st.ld || st.ld.some((x) => !x)) return;
      const k = key(); if (k === wkey && W) return;
      W = S.makeWorld(st, { host: isHost() }); wkey = k; sentOver = false; overT = 0; evSeen = 0; acc = 0; parts.length = 0; hsT = -1; recNote = null; closeFail(); hideWait();
      for (const s in rmSeen) delete rmSeen[s];
      const me = ME(); if (me >= 0 && humanHere(me)) D.markSeen(W.bid);
    }
    function simTick(dt) {
      if (!W || !st || st.ph === 'pick') return;
      acc += dt; const maxSteps = Math.ceil(0.25 * SPD() / DT) + 2;
      let steps = Math.floor(acc / DT); if (steps > maxSteps) { steps = maxSteps; acc = 0; } else acc -= steps * DT;
      const me = ME(), hum = me >= 0 && humanHere(me), host = isHost();
      for (let n = 0; n < steps; n++) {
        let myIn = null;
        if (me >= 0 && W.P[me]) { myIn = hum ? readInput(n === 0) : S.botInput(W, W.P[me]); lastFire = myIn.fire ? 1 : 0; if (!host) { if (myIn.parE) cnt.par++; if (myIn.spE) cnt.sp++; if (myIn.swE) cnt.sw++; if (myIn.parE && W.P[me].par <= 0) W.P[me].par = 14; } }
        if (host) S.worldStep(W, (s, p) => (s === me ? myIn : controlledHere(s) ? S.botInput(W, p) : remoteInput(s)));
        else S.guestStep(W, me, myIn);
        if (shake > 0) shake *= 0.9; if (flash > 0) flash -= 0.02;
        for (let j = parts.length - 1; j >= 0; j--) { const q = parts[j]; q.l++; q.x += q.vx; q.y += q.vy; q.vy += 0.08; q.vx *= 0.96; if (q.l >= q.L) parts.splice(j, 1); }
        if (host) drainEv();
        if (W.B.hf === 5 && W.t % 5 === 0) burst(W.B.x - W.B.hr * 0.6 * (W.P[0].x < W.B.x ? 1 : -1), W.B.y + (pr() - 0.5) * W.B.hr, 2, '#fff6dc', 2.2, 2);
        if (W.over && st.ph === 'play') { overT++; if (!sentOver && overT > (W.over.win ? 50 : 60)) { sentOver = true; onOver(); break; } }
      }
    }

    /* ---------- 그리기 ---------- */
    function layout() {
      const land = cvs.w > cvs.h, res = touchUI && land ? Math.min(104 * btnK(), cvs.w * 0.2) : 0;
      const top = res ? 50 * clamp(Math.min(cvs.w / 640, cvs.h / 360), 1.08, 2.4) : 0;   // 터치 가로: 위쪽은 HUD 띠
      sc = Math.min((cvs.w - res) / AW, (cvs.h - top) / AH);
      ox = res ? Math.max(0, (cvs.w - res - AW * sc) / 2) : (cvs.w - AW * sc) / 2;
      oy = land ? cvs.h - AH * sc : Math.min((cvs.h - AH * sc) / 2, cvs.h * 0.08);
      SPQ = sc * cvs.dpr;
    }
    function ensureBg() {
      const b = D.BI[W.bid], k = b.id + ':' + Math.round(sc * cvs.dpr * 100);
      if (bgKey === k && bgc) return; bgKey = k;
      if (!bgc) bgc = document.createElement('canvas');
      bgc.width = Math.max(2, Math.round(AW * sc * cvs.dpr)); bgc.height = Math.max(2, Math.round(AH * sc * cvs.dpr));
      paintBg(bgc, b, W);
      const im = D.ART.bg.indexOf(b.bg) >= 0 ? loadImg('bg_' + b.bg) : null;
      if (im) { const c = bgc.getContext('2d'); c.imageSmoothingQuality = 'high'; c.globalAlpha = b.bg === 'garden' ? 0.66 : 0.88; c.drawImage(im, 0, 0, AW, AH);   /* 온실은 밝은 청록 선이 받아치기 탄과 겹쳐 조금 옅게 */ c.globalAlpha = 1; c.fillStyle = 'rgba(8,6,14,.24)'; c.fillRect(0, 0, AW, AH); }
    }
    function drawHaz(z, al) {
      const c = HZC[z.c] || HZC[0], act = z.t >= z.T, u = clamp((z.t + al) / Math.max(1, z.T), 0, 1);
      g.save();
      if (z.nd) { g.globalAlpha = act ? 0.1 : 0.1 + u * 0.12; g.fillStyle = c; g.strokeStyle = c; }
      else if (act) { g.globalAlpha = 0.5; g.fillStyle = c; g.strokeStyle = '#fff'; }
      else { g.globalAlpha = 0.1 + u * 0.3; g.fillStyle = c; g.strokeStyle = c; }
      if (z.k === 0) {
        g.fillRect(z.x, z.y, z.w, z.h);
        if (!act && !z.nd) { g.globalAlpha = 0.85; g.fillRect(z.x, z.y + z.h * (1 - u), z.w, 2); g.lineWidth = 1.5; g.setLineDash([5, 4]); g.strokeRect(z.x + 0.5, z.y + 0.5, z.w - 1, z.h - 1); }
        if (act && !z.nd) { g.globalAlpha = 0.9; g.fillStyle = '#ffffff'; if (z.w > z.h) { g.fillRect(z.x, z.y + z.h * 0.44, z.w, Math.max(2, z.h * 0.12)); g.fillStyle = c; g.fillRect(z.x, z.y, z.w, 2); g.fillRect(z.x, z.y + z.h - 2, z.w, 2); } else { g.fillRect(z.x + z.w * 0.44, z.y, Math.max(2, z.w * 0.12), z.h); g.fillStyle = c; g.fillRect(z.x, z.y, 2, z.h); g.fillRect(z.x + z.w - 2, z.y, 2, z.h); } }
        if (z.nd) { g.globalAlpha = 0.3; g.lineWidth = 1; g.setLineDash([3, 5]); g.strokeRect(z.x + 0.5, z.y + 0.5, z.w - 1, z.h - 1); }
      } else if (z.k === 1) {
        g.beginPath(); g.arc(z.x, z.y, z.w, 0, TAU); g.fill(); if (act && !z.nd) { g.globalAlpha = 0.9; g.lineWidth = 2.5; g.stroke(); }
        if (!act) { g.globalAlpha = 0.85; g.lineWidth = 1.5; g.setLineDash([5, 4]); g.stroke(); g.setLineDash([]); g.beginPath(); g.arc(z.x, z.y, z.w * u, 0, TAU); g.stroke(); }
      } else {
        const an = z.an + (act ? z.av * al : 0), ex = z.x + Math.cos(an) * z.w, ey = z.y + Math.sin(an) * z.w;
        g.lineCap = 'round'; g.lineWidth = z.wd; g.beginPath(); g.moveTo(z.x, z.y); g.lineTo(ex, ey); g.stroke();
        if (!act && !z.nd) { g.globalAlpha = 0.9; g.lineWidth = 1.5; g.setLineDash([6, 5]); g.beginPath(); g.moveTo(z.x, z.y); g.lineTo(ex, ey); g.stroke(); }
        if (act && !z.nd) { g.strokeStyle = c; g.lineWidth = z.wd * 0.5; g.beginPath(); g.moveTo(z.x, z.y); g.lineTo(ex, ey); g.stroke(); }
      }
      g.restore();
    }
    function drawBullet(b, al) {
      const x = lerp(b.px, b.x, al), y = lerp(b.py, b.y, al), r = b.r;
      if (b.k === 1) {
        const a = T * 0.05, pu = 1 + Math.sin(T * 0.2) * 0.12;
        g.strokeStyle = 'rgba(127,240,232,.55)'; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, (r + 5) * pu, 0, TAU); g.stroke();
        g.save(); g.translate(x, y); g.rotate(a); po(g, '#0b3a40', [0, -r - 3, r + 3, 0, 0, r + 3, -r - 3, 0]); po(g, '#5ff0e0', [0, -r - 1, r + 1, 0, 0, r + 1, -r - 1, 0]); po(g, '#ffffff', [0, -r * 0.45, r * 0.45, 0, 0, r * 0.45, -r * 0.45, 0]); g.restore();
      } else if (b.k === 3) {
        const a = Math.atan2(b.vy, b.vx); g.save(); g.translate(x, y); g.rotate(a); po(g, '#3a0d10', [-11, -4.5, 9, 0, -11, 4.5]); po(g, '#ffb060', [-9, -3, 7, 0, -9, 3]); g.restore();
      } else if (b.k === 5) {
        const d = b.vx > 0 ? 1 : -1, hh = r * 2.4; po(g, '#3a0d10', [x - d * 10, GY, x + d * 4, GY - hh - 2, x + d * 9, GY - hh * 0.5, x + d * 7, GY]); po(g, '#ff8a5a', [x - d * 8, GY, x + d * 4, GY - hh, x + d * 7, GY - hh * 0.5, x + d * 5, GY]); po(g, '#ffe2b0', [x - d * 2, GY, x + d * 3, GY - hh * 0.6, x + d * 4, GY]);
      } else {
        const big = b.k === 2, c = big ? '#e0487a' : b.k === 4 ? '#ff8a3a' : '#ff6a3d';
        el(g, x, y, r + 1.5, r + 1.5, '#3a0d10'); el(g, x, y, r, r, c); el(g, x - r * 0.2, y - r * 0.2, r * 0.45, r * 0.45, '#ffe2b0');
      }
    }
    function drawMinion(m, al) {
      const x = lerp(m.px, m.x, al), y = lerp(m.py, m.y, al), c = m.par ? '#5ff0e0' : '#e8b040';
      if (m.k === 0) {
        const fl = Math.sin(T * 0.9 + m.x) * 0.5; el(g, x - 4, y - 7, 9, 4, 'rgba(230,240,255,.5)', -0.5 + fl); el(g, x + 4, y - 7, 9, 4, 'rgba(230,240,255,.5)', 0.5 - fl);
        el(g, x, y, m.r + 1, m.r - 1, m.par ? '#0b3a40' : '#2a1808'); el(g, x, y, m.r - 1, m.r - 3, c); ln(g, m.par ? '#0b3a40' : '#2a1808', 2, [x - 2, y - 5, x - 2, y + 5]); ln(g, m.par ? '#0b3a40' : '#2a1808', 2, [x + 3, y - 4, x + 3, y + 4]);
      } else {
        const bl = m.t > 110 ? (Math.sin(m.t * 0.5) > 0 ? 1 : 0.4) : 0.7, pu = 1 + Math.sin(T * 0.1 + m.x) * 0.06;
        for (let i = 0; i < 4; i++) ln(g, m.par ? 'rgba(95,240,224,.5)' : 'rgba(240,160,200,.5)', 1.5, [x - 6 + i * 4, y + 4, x - 7 + i * 4 + Math.sin(T * 0.08 + i) * 2, y + 16]);
        el(g, x, y, (m.r + 1) * pu, m.r * pu, m.par ? '#0b3a40' : '#4a1838'); el(g, x, y - 1, (m.r - 1) * pu, (m.r - 2) * pu, m.par ? 'rgba(95,240,224,' + bl + ')' : 'rgba(240,120,170,' + bl + ')');
      }
      if (m.par) { g.strokeStyle = 'rgba(127,240,232,.55)'; g.lineWidth = 1.5; g.beginPath(); g.arc(x, y, m.r + 6, 0, TAU); g.stroke(); }
    }
    function drawWorld(al) {
      const B = W.B, b = D.BI[W.bid], fx = L.fx ? L.fx() : 1;
      T = W.t + al;
      /* 무대 밖(가장자리) */
      g.fillStyle = '#0e0c16'; g.fillRect(0, 0, cvs.w, cvs.h);
      g.save();
      const sx = shake > 0.3 ? Math.sin(T * 1.9) * shake * 0.5 * fx : 0, sy = shake > 0.3 ? Math.cos(T * 2.3) * shake * 0.35 * fx : 0;
      g.translate(ox + sx * sc, oy + sy * sc); g.scale(sc, sc);
      g.beginPath(); g.rect(0, 0, AW, AH); g.clip();
      ensureBg(); g.drawImage(bgc, 0, 0, AW, AH);
      const bx = lerp(B.px, B.x, al), by = lerp(B.py, B.y, al);
      const drawBoss = () => {
        g.save();
        if (B.st === 'dead') { g.globalAlpha = clamp(1 - B.k / 90, 0, 1); g.translate(Math.sin(T * 0.8) * 3, B.k * 0.3); }
        else if (B.st === 'tr') { g.translate(Math.sin(T * 0.9) * 2.5 * (1 - Math.abs(B.k - 40) / 44), 0); }
        else if (B.st === 'in') g.globalAlpha = clamp(B.k / 30, 0, 1);
        const on = (B.st === 'idle' || B.st === 'pat'), hx = bx + (B.hf > 0 ? Math.sin(T * 2.4) * 1.6 : 0);
        const gl = g.createRadialGradient(bx, by, B.hr * 0.4, bx, by, B.hr * 3.2); gl.addColorStop(0, b.col + '66'); gl.addColorStop(1, b.col + '00'); g.fillStyle = gl; g.fillRect(bx - B.hr * 3.2, by - B.hr * 3.2, B.hr * 6.4, B.hr * 6.4);
        const useS = bossSpr(B.id), pv = useS ? 0 : BIG[B.id];
        g.save();
        if (pv) { g.translate(hx, by + pv); g.scale(1.16, 1.16); g.translate(-hx, -by - pv); }
        (useS ? BS : BD)[B.id](g, hx, by, B, T, W);
        g.restore();
        if (B.hf > 0 || B.st === 'tr') { g.globalCompositeOperation = 'lighter'; el(g, bx, by, B.hr + 4, B.hr + 4, 'rgba(255,255,255,' + (B.st === 'tr' ? 0.16 + Math.sin(T * 0.4) * 0.08 : 0.1 * B.hf / 5) + ')'); g.globalCompositeOperation = 'source-over'; }
        /* 약점(맞는 자리) 고리: 맞을 수 있을 때만 */
        if (on && !B.inv) { g.strokeStyle = B.hf > 0 ? 'rgba(255,255,255,.9)' : 'rgba(255,244,214,.5)'; g.lineWidth = 1.6; g.setLineDash([7, 6]); g.lineDashOffset = -T * 0.3; g.beginPath(); g.arc(bx, by, B.hr + 3, 0, TAU); g.stroke(); g.setLineDash([]); }
        g.restore();
      };
      const back = BACK[B.id] || (B.id === 'bloom' && bossSpr('bloom'));
      if (back) drawBoss();
      /* 바닥 · 발판 */
      const fk = W.fk, warn = W.fkw > 0;
      if (W.fly) { g.fillStyle = 'rgba(10,8,18,.5)'; g.fillRect(0, GY, AW, AH - GY); }
      else {
        const GC = { ruin: ['#3b3566', '#8f84c4'], garden: ['#2a4f48', '#7fc0a0'], sky: ['#35426e', '#9fb4e4'], forge: ['#4c3234', '#c08a70'] }[b.bg] || ['#3b3566', '#8f84c4'];
        g.fillStyle = '#1c1830'; g.fillRect(0, GY, AW, AH - GY); g.fillStyle = GC[0]; g.fillRect(0, GY, AW, 16);
        if (!fk) { g.fillStyle = GC[1]; g.fillRect(0, GY, AW, 4); g.fillStyle = '#f4ecff'; g.fillRect(0, GY, AW, 1.5); g.fillStyle = 'rgba(10,8,20,.35)'; for (let i = 0; i < 11; i++) g.fillRect(i * 64 + 20, GY + 4, 2, 12); }
        if (fk) {
          const c = b.id === 'core' ? [120, 70, 230] : b.id === 'rail' ? [70, 44, 52] : [255, 120, 40], a = warn ? 0.15 + 0.2 * (Math.sin(T * 0.25) + 1) * 0.5 : 0.55;
          g.fillStyle = 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; g.fillRect(0, GY - 5, AW, AH - GY + 5);
          if (b.id === 'rail') { for (let i = 0; i < 16; i++) { const x = ((i * 44 - T * 1.2) % 704 + 704) % 704 - 30; g.fillStyle = '#17131f'; g.fillRect(x, GY + 6, 22, 5); } g.fillStyle = '#8a8090'; g.fillRect(0, GY + 2, AW, 2); }
          else for (let i = 0; i < 9; i++) { const x = i * 76 + Math.sin(T * 0.02 + i) * 14; el(g, x, GY + 2 + Math.sin(T * 0.05 + i * 1.7) * 2, 26, 4, 'rgba(255,240,220,' + (warn ? 0.1 : 0.22) + ')'); }
        }
      }
      for (const q of W.pl) {
        if (q.off) continue; const x = lerp(q.px, q.x, al), bl = q.t > 0 && q.t <= 54;
        g.globalAlpha = bl ? 0.45 + 0.3 * Math.sin(q.t * 0.5) : 1;
        rr(g, x - 3, q.y - 1, q.w + 6, b.id === 'rail' ? 16 : 13, 3, '#120e1c'); rr(g, x - 1, q.y + 3, q.w + 2, b.id === 'rail' ? 10 : 7, 2, '#4a4270'); rr(g, x - 2, q.y, q.w + 4, 4.5, 2, bl ? '#c79aff' : '#f4ecff');
        if (b.id === 'rail') { g.fillStyle = '#6a5460'; g.fillRect(x + 4, q.y + 14, q.w - 8, GY - q.y - 20); g.fillStyle = '#2a1c24'; for (let i = 0; i < 3; i++) g.fillRect(x + 12 + i * (q.w - 24) / 3, q.y + 20, (q.w - 24) / 3 - 8, 12); }
        g.globalAlpha = 1;
      }
      for (const z of W.hz) drawHaz(z, al);
      if (!back) drawBoss();
      for (const m of W.mn) drawMinion(m, al);
      /* 내 탄 */
      for (const q of W.pb) {
        const x = lerp(q.px, q.x, al), y = lerp(q.py, q.y, al), w = D.WEAPONS[[0, 1, 2, 3, 0, 5, 0, 0][q.k] || 0];
        if (q.k === 7) { el(g, x, y, 6, 6, '#5ff0e0'); el(g, x, y, 3, 3, '#fff'); }
        else if (q.k === 5) { const a = Math.atan2(q.vy, q.vx); g.save(); g.translate(x, y); g.rotate(a); rr(g, -16, -4, 28, 8, 4, 'rgba(168,232,255,.9)'); rr(g, -8, -2, 18, 4, 2, '#fff'); g.restore(); }
        else if (q.k === 3) { el(g, x, y, 5, 5, '#ffd070'); el(g, x, y, 2.5, 2.5, '#fff6dc'); }
        else { const m = Math.hypot(q.vx, q.vy) || 1; ln(g, w.col, q.k === 1 ? 2.5 : 3, [x - q.vx / m * 7, y - q.vy / m * 7, x, y]); }
      }
      /* 사수 */
      const me = ME();
      W.P.forEach((p, s) => {
        const col = (api.players[s] && api.players[s].color) || '#e3ae45', x = lerp(p.px, p.x, al), y = lerp(p.py, p.y, al);
        if (p.down) { if (p.sy > -24) { const a = 0.6 + Math.sin(T * 0.1) * 0.2, sy = p.sy - 0.55 * al; g.strokeStyle = 'rgba(127,240,232,' + a + ')'; g.lineWidth = 1.5; g.beginPath(); g.arc(p.sx, sy, 16, 0, TAU); g.stroke(); po(g, 'rgba(95,240,224,' + a + ')', [p.sx, sy - 11, p.sx + 8, sy, p.sx + 5, sy + 10, p.sx, sy + 6, p.sx - 5, sy + 10, p.sx - 8, sy]); el(g, p.sx - 3, sy - 2, 1.5, 2, '#0b3a40'); el(g, p.sx + 3, sy - 2, 1.5, 2, '#0b3a40'); } return; }
        p._fly = W.fly;
        if (p.dash > 0) { g.globalAlpha = 0.3; drawHero(g, p, x - p.dd * 20, y - p.ddy * 20, T, col, 0); g.globalAlpha = 1; }
        if (p.sp > 0) { const a = clamp(p.sp / 30, 0, 1); ln(g, 'rgba(255,240,200,' + a * 0.9 + ')', 16 * a + 2, [x, y - 17, p.ax, p.ay]); ln(g, 'rgba(255,255,255,' + a + ')', 5 * a + 1, [x, y - 17, p.ax, p.ay]); }
        const wp = D.WEAPONS[p.w[p.wi]];
        if (p.bm > 0 && wp.id === 'beam') { const a = Math.atan2(p.ay - (y - 17), p.ax - x), l = p.bl || 100; ln(g, 'rgba(240,184,255,.35)', 7, [x, y - 17, x + Math.cos(a) * l, y - 17 + Math.sin(a) * l]); ln(g, '#f8e0ff', 2, [x, y - 17, x + Math.cos(a) * l, y - 17 + Math.sin(a) * l]); }
        if (p.bm > 0 && wp.id === 'maul') { const a = Math.atan2(p.ay - (y - 17), p.ax - x), u = 1 - p.bm / 8; g.strokeStyle = 'rgba(255,255,255,' + (1 - u) + ')'; g.lineWidth = 5; g.beginPath(); g.arc(x, y - 17, 30 + u * 24, a - 0.8, a + 0.8); g.stroke(); }
        if (wp.id === 'chg' && p.cd > 0 && p.cd < 50) { const u = 1 - p.cd / 50; el(g, x + p.f * 12, y - 17, 2 + u * 5, 2 + u * 5, 'rgba(168,232,255,' + (0.3 + u * 0.5) + ')'); }
        g.globalAlpha = p.inv > 0 && p.sp <= 0 ? 0.55 : 1;
        drawHero(g, p, x, y, T, col, s === me);
        g.globalAlpha = 1;
        if (p.sh) { g.strokeStyle = 'rgba(160,196,240,.85)'; g.lineWidth = 2; g.beginPath(); g.arc(x, y - 25, 29, 0, TAU); g.stroke(); }
        if (p.par > 0) { const R = S.PARRY_R * (p.ch === 'reach' ? 1.4 : 1); g.strokeStyle = 'rgba(127,240,232,.9)'; g.lineWidth = 3; g.beginPath(); g.arc(x, y - 15, R, T * 0.5, T * 0.5 + 4.2); g.stroke(); g.fillStyle = 'rgba(127,240,232,.10)'; g.beginPath(); g.arc(x, y - 15, R, 0, TAU); g.fill(); }
        if (p.pok > 0) { const u = 1 - p.pok / 12; g.strokeStyle = 'rgba(255,255,255,' + (1 - u) + ')'; g.lineWidth = 3; g.beginPath(); g.arc(x, y - 15, 20 + u * 26, 0, TAU); g.stroke(); }
        if (W.P.length > 1) { g.fillStyle = col; g.beginPath(); g.moveTo(x - 5, y - 68); g.lineTo(x + 5, y - 68); g.lineTo(x, y - 61); g.fill(); }
      });
      /* 적 탄은 맨 위에(가려지지 않게) */
      for (const q of W.bl) drawBullet(q, al);
      for (const q of parts) { g.globalAlpha = clamp(1 - q.l / q.L, 0, 1) * 0.8; el(g, q.x + q.vx * al, q.y + q.vy * al, q.r, q.r, q.c); } g.globalAlpha = 1;
      if (flash > 0.01) { g.fillStyle = 'rgba(255,90,70,' + flash * 0.5 + ')'; g.fillRect(0, 0, AW, AH); }
      g.restore();
    }
    function text(t, x, y, size, col, al, font, bold) {
      g.font = (bold ? '600 ' : '') + size + 'px ' + (font || FONT); g.textAlign = al || 'left'; g.textBaseline = 'middle';
      g.lineWidth = Math.max(2.5, size * 0.22); g.strokeStyle = 'rgba(10,8,16,.8)'; g.lineJoin = 'round'; g.strokeText(t, x, y); g.fillStyle = col; g.fillText(t, x, y);
    }
    function drawHUD() {
      const u = clamp(Math.min(cvs.w / 640, cvs.h / 360), 1.08, 2.4) * (L.ui && L.ui.scale ? clamp(L.ui.scale(), 0.9, 1.3) : 1), B = W.B, b = D.BI[W.bid], me = ME(), cw = cvs.w, ac = ox + AW * sc / 2;
      /* 파수 이름 · 체력 · 시간 */
      const bw = Math.min(230 * u, AW * sc * 0.4), bxx = ac - bw / 2, byy = 23 * u, bh = 9 * u;
      text(b.nm, ac, 10 * u, 14 * u, '#f2e9d8', 'center', FD);
      rr(g, bxx - 2, byy - 2, bw + 4, bh + 4, 4, 'rgba(10,8,16,.8)');
      let acc2 = 0; const tot = b.hp.reduce((a, c) => a + c, 0);
      b.hp.forEach((hp, i) => { const x0 = bxx + (acc2 / tot) * bw, w = (hp / tot) * bw - 2; acc2 += hp; const fr = i < B.ph ? 0 : i > B.ph ? 1 : clamp(B.hp / B.mhp, 0, 1); rr(g, x0, byy, w, bh, 2, 'rgba(255,255,255,.14)'); if (fr > 0) rr(g, x0, byy, Math.max(2, w * fr), bh, 2, i === B.ph ? b.col : 'rgba(210,200,220,.6)'); });
      text(D.fmtT(W.time) + (st.list.length > 1 ? '  ·  ' + (st.bi + 1) + '/' + st.list.length : ''), ac, byy + bh + 10 * u, 12.5 * u, '#f2e9d8', 'center');
      /* 사수: 체력 칸 · 필살 게이지 · 무기 */
      W.P.forEach((p, s) => {
        const x0 = 8 * u, y0 = 11 * u + s * 50 * u, col = (api.players[s] && api.players[s].color) || '#e3ae45', lx = x0 + 31 * u;
        text('체력', x0, y0, 12 * u, '#ffb0a4', 'left', null, 1);
        for (let i = 0; i < p.mhp; i++) { const cx = lx + 8 * u + i * 17 * u, on = i < p.hp && !p.down; po(g, 'rgba(10,8,16,.85)', [cx, y0 - 8 * u, cx + 8 * u, y0, cx, y0 + 8 * u, cx - 8 * u, y0]); po(g, on ? '#ff7a6a' : 'rgba(255,255,255,.16)', [cx, y0 - 6 * u, cx + 6 * u, y0, cx, y0 + 6 * u, cx - 6 * u, y0]); }
        if (p.sh) { const cx = lx + 8 * u + p.mhp * 17 * u; po(g, 'rgba(10,8,16,.85)', [cx, y0 - 8 * u, cx + 8 * u, y0, cx, y0 + 8 * u, cx - 8 * u, y0]); po(g, '#8fb0e0', [cx, y0 - 6 * u, cx + 6 * u, y0, cx, y0 + 6 * u, cx - 6 * u, y0]); }
        if (W.P.length > 1) text((st.nm[s] || '') + (s === me ? ' (나)' : ''), lx + (p.mhp + (p.sh ? 1 : 0)) * 17 * u + 6 * u, y0, 12 * u, col, 'left');
        const gw = 70 * u, gy = y0 + 13 * u, full = p.ga >= D.HERO.gauge;
        text('필살', x0, gy + 4 * u, 12 * u, full ? '#ffffff' : '#8ff0e6', 'left', null, 1);
        rr(g, lx, gy, gw, 8 * u, 4, 'rgba(10,8,16,.85)'); rr(g, lx + 1.5, gy + 1.5, Math.max(0, (gw - 3) * p.ga / D.HERO.gauge), 8 * u - 3, 3, full ? (Math.sin(T * 0.15) > 0 ? '#ffffff' : '#7ff0e8') : '#3fb8b0');
        const w0 = D.WEAPONS[p.w[p.wi]], w1 = D.WEAPONS[p.w[p.wi ^ 1]];
        if (s === me || W.P.length === 1) { text(w0.nm, x0, gy + 20 * u, 12.5 * u, w0.col, 'left', null, 1); text('↔ ' + w1.nm, x0 + g.measureText(w0.nm).width + 6 * u, gy + 20 * u, 12 * u, 'rgba(242,233,216,.7)', 'left'); }
      });
      /* 등장 · 단계 · 기록 알림(작게, 짧게) */
      const ch = oy + AH * sc;
      if (B.st === 'in' && B.k < 76) { const a = clamp(Math.min(B.k / 12, (76 - B.k) / 14), 0, 1); g.globalAlpha = a; rr(g, ac - 120 * u, oy + AH * sc * 0.6, 240 * u, 36 * u, 8, 'rgba(10,8,16,.65)');
        { const tw = 60 * u, tx = ac - 120 * u - tw - 5 * u, ty = oy + AH * sc * 0.6 + 18 * u - tw / 2; rr(g, tx - 2, ty - 2, tw + 4, tw + 4, 8, b.col); rr(g, tx, ty, tw, tw, 7, '#1a1626'); g.save(); g.beginPath(); g.rect(tx, ty, tw, tw); g.clip(); drawBossAt(g, b.id, tx + tw / 2, ty + tw / 2, tw * 0.92, T); g.restore(); } text(b.nm, ac, oy + AH * sc * 0.6 + 12 * u, 17 * u, b.col, 'center', FD); text(b.ty + ' · ' + b.hp.length + '단계', ac, oy + AH * sc * 0.6 + 27 * u, 12 * u, '#e8dff0', 'center'); g.globalAlpha = 1; }
      if (B.st === 'tr') { const a = clamp(Math.min(B.k / 10, (84 - B.k) / 14), 0, 1) * 0.9; g.globalAlpha = a; text((B.k < 40 ? B.ph + 2 : B.ph + 1) + '단계', ac, oy + AH * sc * 0.3, 18 * u, '#f2e9d8', 'center', FD); g.globalAlpha = 1; }
      if (W.over && W.over.win) { text('격파', ac, oy + AH * sc * 0.36, 22 * u, '#f2e9d8', 'center', FD); if (recNote) text(recNote, ac, oy + AH * sc * 0.36 + 22 * u, 13 * u, '#7ff0e8', 'center'); }
      if (me >= 0 && W.P[me] && W.P[me].down && !W.over) text('동료가 혼을 받아치면 되살아남', ac, oy + AH * sc * 0.3, 13 * u, '#7ff0e8', 'center');
      /* 터치 단추: 누르지 않을 때는 반투명 */
      if (touchUI && !pickEl && !failEl) {
        const p = me >= 0 ? W.P[me] : null;
        for (const q of buttons()) {
          const on = tc.held[q.id], rdy = q.id === 'special' ? p && p.ga >= D.HERO.gauge : q.id === 'dash' ? p && p.dcd <= 0 : q.id === 'parry' ? p && p.pcd <= 0 : true, base = on ? 0.95 : rdy ? 0.5 : 0.28;
          g.globalAlpha = base * 0.5; el(g, q.x, q.y, q.r, q.r, q.id === 'parry' ? '#3fb8b0' : q.id === 'special' ? '#e3ae45' : '#d8d0e4');
          g.globalAlpha = base; g.strokeStyle = '#f2e9d8'; g.lineWidth = 1.5; g.beginPath(); g.arc(q.x, q.y, q.r, 0, TAU); g.stroke();
          g.globalAlpha = Math.min(1, base + 0.3); text(q.t, q.x, q.y, Math.max(12, q.r * 0.42), '#f2e9d8', 'center', null, 1); g.globalAlpha = 1;
        }
        if (tc.stick != null) { g.globalAlpha = 0.3; el(g, tc.sx, tc.sy, 44, 44, '#d8d0e4'); g.globalAlpha = 0.6; el(g, clamp(tc.cx, tc.sx - 46, tc.sx + 46), clamp(tc.cy, tc.sy - 46, tc.sy + 46), 20, 20, '#f2e9d8'); g.globalAlpha = 1; }
        else if (W.t < 400 && W.B.st === 'in') text('왼쪽을 누르고 끌면 이동', ox + AW * sc * 0.22, ch - 40, 12 * u, 'rgba(242,233,216,.8)', 'center');
      }
      void cw;
    }

    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      const rdt = Math.min(0.1, (now - (last || now)) / 1000); last = now;
      pollNet();
      if (st && st.ph === 'play') ensureWorld();
      if (W && st && st.ph !== 'pick' && !(api.paused && api.paused())) { simTick(rdt * SPD()); publish(rdt); }
      else if (st) publish(rdt);
      layout();
      if (W) { const al = clamp(acc / DT, 0, 1); drawWorld(al); drawHUD(); }
      else { g.fillStyle = '#0e0c16'; g.fillRect(0, 0, cvs.w, cvs.h); }
    }
    raf = requestAnimationFrame(frame);

    if (L.debug) L.debug.bossrunW = () => W;   // 시험용: 지금 판의 세계
    function update(s) {
      st = s; if (!st) return;
      if (st.ph === 'pick') {
        const me = ME();
        if (me >= 0 && humanHere(me) && !st.ld[me]) { openPick(); hideWait(); }
        else {
          closePick();
          if (isHost()) { if (!st.ld.some((x, i) => !x && !api.players[i].ai && !(i === me && testBot()))) setTimeout(() => { if (!dead && st && st.ph === 'pick') { const ld = st.ld.map((x) => x || D.aiLoadout(Math.random)); api.setState(Object.assign({}, st, { ld, ph: 'play', seq: st.seq + 1 })); } }, 0); else showWait('다른 사수가 장비를 고르는 중'); }
          else if (me >= 0 && testBot() && !myPick) myPick = D.aiLoadout(Math.random);
        }
      } else {
        closePick(); if (pickBar) { try { pickBar.destroy(); } catch (e) {} pickBar = null; }
        if (st.ph === 'play') { myPick = myPick || [0, 1, 0]; ensureWorld(); } else { closeFail(); hideWait(); }
      }
    }
    function destroy() {
      dead = true; cancelAnimationFrame(raf); offs.forEach((f) => { try { f(); } catch (e) {} });
      cvs.cv.removeEventListener('pointerdown', onDown); cvs.cv.removeEventListener('pointermove', onMove); cvs.cv.removeEventListener('pointerup', onUp); cvs.cv.removeEventListener('pointercancel', onUp);
      closePick(); closeFail(); hideWait(); if (pickBar) { try { pickBar.destroy(); } catch (e) {} } cvs.destroy();
    }
    return { update, destroy };
  }

  G.BOSSRUN_VIEW = { mount };
})();
