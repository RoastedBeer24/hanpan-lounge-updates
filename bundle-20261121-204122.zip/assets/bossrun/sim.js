/* 열두 파수 — 순수 시뮬(초당 60걸음, 시드 난수만 사용). 브라우저와 node 양쪽에서 돎.
   W(세계) = 사수 P · 파수 B · 적 탄 bl · 내 탄 pb · 예고 구역 hz · 소환물 mn · 발판 pl · 사건 ev.
   파수 패턴은 (W, B, k) → 끝났으면 true 인 함수. k는 패턴이 시작된 뒤의 걸음 수라서 같은 예고 뒤에는 늘 같은 공격이 온다. */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const D = G.BOSSRUN;
  const S = {};
  const DT = 1 / 60, AW = 640, AH = 360, GY = 300, PI = Math.PI, TAU = PI * 2;
  const RUN = 190, JV = 470, GRAV = 1300, DASHV = 430, DASHN = 13, FLYV = 200, PRAD = 6, PARRY_R = 30;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const sgn = (v) => (v < 0 ? -1 : 1);

  function rnd(W) { let t = (W.rs = (W.rs + 0x6D2B79F5) | 0); t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  const ri = (W, n) => Math.floor(rnd(W) * n);
  function pickN(W, n, k) { const a = []; for (let i = 0; i < n; i++) a.push(i); for (let i = n - 1; i > 0; i--) { const j = ri(W, i + 1), t = a[i]; a[i] = a[j]; a[j] = t; } return a.slice(0, k); }
  function ev(W, ty, x, y, v) { W.ev.push([++W.en, ty, Math.round(x), Math.round(y), v || 0, W.t]); if (W.ev.length > 28) W.ev.shift(); }

  /* ======================= 만들기 ======================= */
  const PL = (x, y, w, vx) => ({ x, px: x, y, w, vx: vx || 0, off: 0, t: 0, wr: 0 });
  function newPlayer(W, s, ld, hp0, lv, ai) {
    ld = ld || [0, 1, 0];
    const ch = D.CHARMS[ld[2]] ? D.CHARMS[ld[2]].id : '';
    const mhp = D.HERO.hp + (ch === 'heart' ? 1 : ch === 'focus' ? -1 : 0);
    const x = 110 + s * 44, y = W.fly ? 190 + s * 30 : GY;
    return { s, x, y, px: x, py: y, vx: 0, vy: 0, f: 1, g: W.fly ? 0 : 1, on: -1, hp: hp0 > 0 ? Math.min(hp0, mhp) : mhp, mhp, inv: 70, dash: 0, di: 0, dcd: 0, dd: 1, ddy: 0, ad: 0, aj: 0, par: 0, pcd: 0, pok: 0, ga: 0, w: [ld[0] | 0, ld[1] | 0], wi: 0, cd: 20, bm: 0, ax: 0, ay: 0, ch, dm: ch === 'heart' ? 0.92 : ch === 'focus' ? 1.15 : 1, sh: ch === 'ward' ? 1 : 0, down: 0, sx: 0, sy: 0, coy: 0, jb: 0, drop: 0, sp: 0, hits: 0, pn: 0, dmg: 0, rv: 0, lv: lv || 0, ai: ai ? 1 : 0, an: 0, fkh: 0, A: null };
  }
  function makeWorld(st, o) {
    o = o || {};
    const bid = st.list[st.bi], meta = D.BI[bid], bd = BOSS[bid];
    const W = { rs: (st.seed + st.bi * 7919 + (st.try || 0) * 104729) | 0, t: 0, hard: st.hard ? 1 : 0, n: st.n, bid, host: o.host === false ? 0 : 1, P: [], bl: [], pb: [], hz: [], mn: [], pl: [], ev: [], en: 0, fly: meta.fly ? 1 : 0, fk: 0, fkw: 0, wind: 0, over: null, time: 0 };
    W.sm = W.hard ? 1.15 : 1;
    W.hs = (st.n > 1 ? 1.7 : 1) * (W.hard ? 1.15 : 1);
    for (let s = 0; s < st.n; s++) W.P.push(newPlayer(W, s, st.ld && st.ld[s], st.carry ? st.carry[s] : 0, st.lv[s], st.ai[s]));
    W.B = { id: bid, ph: 0, np: meta.hp.length, hp: 1, mhp: 1, x: 540, y: 200, px: 540, py: 200, tx: 540, ty: 200, st: 'in', k: 0, pi: -1, last: -1, bag: [], gap: 40, inv: 1, hr: 36, cr: 0, hx: 0, hy: 0, a: [0, 0, 0, 0, 0, 0], fl: -1, po: '', v: {}, parts: [], stun: 0, tgi: 0, hf: 0 };
    W.tot = meta.hp.reduce((a, c) => a + c, 0) * W.hs;
    setPhase(W, 0); W.B.x = W.B.px = W.B.tx; W.B.y = W.B.py = W.B.ty;
    return W;
  }
  function setPhase(W, ph) {
    const B = W.B, meta = D.BI[B.id];
    B.ph = ph; B.mhp = B.hp = meta.hp[ph] * W.hs; B.bag = []; B.last = -1; B.pi = -1; B.v = {}; B.po = ''; B.parts = []; B.stun = 0;
    BOSS[B.id].enter(W, B, ph);
  }
  function home(B, x, y) { B.tx = x; B.ty = y; }

  /* ======================= 탄 · 예고 · 소환 ======================= */
  const BR = [6, 7, 11, 4.5, 7, 8];
  function shot(W, x, y, ang, spd, k, o) {
    if (W.bl.length >= 150) return null;
    spd *= W.sm; k = k || 0;
    const b = { x, y, px: x, py: y, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd, r: BR[k], k, g: 0, l: 540, n: 0, rv: 0, fz: 0 };
    if (o) Object.assign(b, o); W.bl.push(b); return b;
  }
  /* pi: 받아칠 수 있는 갈래 번호(-1 없음) */
  function fan(W, x, y, ang, n, spr, spd, k, pi) { for (let i = 0; i < n; i++) shot(W, x, y, ang + (n > 1 ? (i / (n - 1) - 0.5) * spr : 0), spd, i === pi ? 1 : k); }
  /* pe: pe번째마다 받아칠 수 있음(0 없음) */
  function ring(W, x, y, n, spd, off, k, pe, o) { for (let i = 0; i < n; i++) shot(W, x, y, off + (i / n) * TAU, spd, pe && i % pe === 0 ? 1 : k, o); }
  /* 물결은 예고된 착지 · 휘두름에서만 나오므로 봇도 나오자마자 알아봄(n = 나이) */
  function wave(W, x, dir, spd, o) { return shot(W, x, GY - 8, dir > 0 ? 0 : PI, spd / W.sm * (W.hard ? 1.08 : 1), 5, Object.assign({ n: 30, l: 570 }, o)); }
  function lobAt(W, x, y, tx, ty, T, k, o) {
    const t = T / 60, g = 700, b = shot(W, x, y, 0, 0, k, o); if (!b) return null;
    b.g = g; b.vx = (tx - x) / t; b.vy = (ty - y) / t - 0.5 * g * t; return b;
  }
  /* c: 0 광선 · 1 불 · 2 벼락 · 3 물 · 4 공허 · 5 종 / nd: 피해 없는 예고 줄 */
  function haz(W, x, y, w, h, T, A, c, o) { const z = { k: 0, x, y, w, h, an: 0, wd: 0, t: 0, T, A, c: c || 0, nd: 0, vx: 0, av: 0, pl: -1 }; if (o) Object.assign(z, o); W.hz.push(z); return z; }
  const hcirc = (W, x, y, r, T, A, c, o) => haz(W, x, y, r, 0, T, A, c, Object.assign({ k: 1 }, o));
  const hray = (W, x, y, an, len, wd, T, A, c, o) => haz(W, x, y, len, 0, T, A, c, Object.assign({ k: 2, an, wd }, o));
  function spawn(W, k, x, y, o) { if (W.mn.length >= 9) return null; const m = { k, x, y, px: x, py: y, vx: 0, vy: 0, hp: (k === 2 ? 10 : 6) * (W.hard ? 1.3 : 1), r: k === 2 ? 11 : 9, t: 0, par: 0 }; if (o) Object.assign(m, o); W.mn.push(m); return m; }
  const alive = (W) => W.P.filter((p) => !p.down);
  function tp(W, B) { const a = alive(W); if (!a.length) return W.P[0]; return a[B.tgi % a.length]; }
  const aim = (x, y, p) => Math.atan2(p.y - 15 - y, p.x - x);
  const H = (W, a, b) => (W.hard ? b : a);

  /* ======================= 사수 물리(호스트 · 손님 예측 · 봇 미리 보기 공용) ======================= */
  function phys(W, p, i) {
    p.px = p.x; p.py = p.y;
    if (p.dcd > 0) p.dcd--; if (p.di > 0) p.di--; if (p.drop > 0) p.drop--; if (p.jb > 0) p.jb--; if (p.coy > 0) p.coy--;
    const mx = i.mx || 0, my = i.my || 0, veil = p.ch === 'veil';
    if (mx) p.f = mx > 0 ? 1 : -1;
    if (i.dashE && p.dcd <= 0 && p.dash <= 0 && (W.fly || p.g || p.ad < (p.ch === 'air' ? 2 : 1))) {
      let dx = mx, dy = W.fly ? my : 0; if (!dx && !dy) dx = p.f; const m = Math.hypot(dx, dy);
      p.dd = dx / m; p.ddy = dy / m; p.dash = DASHN; p.di = DASHN + (veil ? 7 : 0); p.dcd = Math.round((DASHN + 22) * (veil ? 0.85 : 1)); if (!p.g) p.ad++; p.vy = 0; p.de = 1;
    }
    if (p.dash > 0) { p.dash--; p.vx = p.dd * DASHV; p.x += p.vx * DT; p.y += p.ddy * DASHV * DT; p.vy = 0; }
    else if (W.fly) { const m = Math.hypot(mx, my), q = m > 1 ? 1 / m : 1; p.vx = mx * q * FLYV; p.vy = my * q * FLYV; p.x += p.vx * DT; p.y += p.vy * DT; }
    else {
      p.vx = mx * RUN; p.x += p.vx * DT;
      if (i.jumpE) p.jb = 7;
      if (p.jb > 0 && (p.g || p.coy > 0)) { p.vy = -JV; p.g = 0; p.coy = 0; p.jb = 0; p.on = -1; }
      else if (i.jumpE && !p.g && p.ch === 'air' && p.aj < 1) { p.vy = -JV * 0.88; p.aj++; p.jb = 0; }
      if (!i.jump && p.vy < -250) p.vy = -250;
      if (my > 0.6 && p.g && p.on >= 0) { p.drop = 10; p.g = 0; p.on = -1; }
    }
    if (!W.fly && p.dash <= 0) {
      p.vy = Math.min(p.vy + GRAV * DT, 700);
      const ny = p.y + p.vy * DT; let land = -2;
      if (p.vy >= 0) {
        if (p.drop <= 0) for (let j = 0; j < W.pl.length; j++) { const q = W.pl[j]; if (!q.off && p.x >= q.x - 5 && p.x <= q.x + q.w + 5 && p.y <= q.y + 1.5 && ny >= q.y) { land = j; break; } }
        if (land < 0 && ny >= GY) land = -1;
      }
      if (land >= -1) {
        p.y = land >= 0 ? W.pl[land].y : GY; p.vy = 0; p.g = 1; p.on = land; p.ad = 0; p.aj = 0; p.coy = 6; if (land >= 0) p.x += W.pl[land].vx * DT;
        if (land === -1 && W.fk && W.fkw <= 0) { p.vy = -560; p.g = 0; p.fkh = 1; }
      } else { p.y = ny; p.g = 0; p.on = -1; }
    }
    if (W.wind) p.x += W.wind * DT;
    p.x = clamp(p.x, 14, AW - 14);
    if (W.fly) p.y = clamp(p.y, 46, GY);
    p.an += Math.abs(p.vx) * DT;
  }

  /* ======================= 피해 ======================= */
  function hurt(W, p, force) {
    if (p.down || W.over) return;
    if (!force && (p.inv > 0 || p.di > 0)) return;
    if (force && p.inv > 0) return;
    if (p.sh) { p.sh = 0; p.inv = 70; ev(W, 'ward', p.x, p.y - 15, p.s); return; }
    p.hp--; p.hits++; p.inv = Math.round(D.HERO.inv * 60); ev(W, 'hurt', p.x, p.y - 15, p.s);
    if (p.hp <= 0) { p.down = 1; p.sx = p.x; p.sy = p.y - 15; p.dash = 0; p.par = 0; ev(W, 'down', p.x, p.y - 15, p.s); if (!alive(W).length) { W.over = { win: 0 }; } }
  }
  function clearField(W) { W.bl.length = 0; W.hz.length = 0; W.mn.length = 0; W.wind = 0; }
  function dmgBoss(W, d, p, kind, sx) {
    const B = W.B, bd = BOSS[B.id];
    if (B.st === 'tr' || B.st === 'dead' || B.st === 'in' || W.over) return false;
    if (kind !== 'sp' && B.inv) return false;
    if (bd.block && bd.block(W, B, kind, sx)) { if (W.t % 6 === 0 || kind === 'rf') ev(W, 'clink', B.x + B.hx, B.y + B.hy); return false; }
    B.hp -= d; B.hf = 5; if (p) { p.dmg += d; if (kind !== 'sp') p.ga = Math.min(D.HERO.gauge, p.ga + d * 0.08); }
    if (B.hp <= 0) {
      clearField(W); B.v = {}; B.parts = []; B.stun = 0; B.k = 0; B.inv = 1;
      if (B.ph < B.np - 1) { B.st = 'tr'; ev(W, 'phase', B.x, B.y, B.ph + 1); }
      else { B.st = 'dead'; B.hp = 0; ev(W, 'dead', B.x, B.y); }
    }
    return true;
  }
  function parryOK(W, p, x, y) {
    p.ga = Math.min(D.HERO.gauge, p.ga + D.HERO.gParry); p.inv = Math.max(p.inv, 22); p.pok = 12; p.pn++;
    if (!p.g && !W.fly) p.vy = -340;
    p.pv = 1;
    const B = W.B; W.pb.push({ x, y, px: x, py: y, vx: 0, vy: -200, d: 16 * p.dm, k: 7, s: p.s, n: 0, l: 180, g: 0, hit: 0 });
    if (p.ch === 'echo') W.bl = W.bl.filter((b) => b.k === 1 || Math.hypot(b.x - p.x, b.y - (p.y - 15)) > 72);
    ev(W, 'par', x, y, p.s); void B;
  }

  /* ======================= 사수 한 걸음(호스트) ======================= */
  function aimPoint(W, p) {
    const B = W.B, cx = p.x, cy = p.y - 15; let bx = B.x + B.hx, by = B.y + B.hy, br = B.hr, best = 1e9, m = null;
    for (const q of W.mn) { const d = Math.hypot(q.x - cx, q.y - cy); if (d < 130 && d < best) { best = d; m = q; } }
    if (m) return { x: m.x, y: m.y, r: m.r, m };
    return { x: bx, y: by, r: br, m: null };
  }
  function fire(W, p) {
    const w = D.WEAPONS[p.w[p.wi]] || D.WEAPONS[0], cx = p.x, cy = p.y - 17, T = aimPoint(W, p), a = Math.atan2(T.y - cy, T.x - cx), dm = p.dm;
    p.ax = T.x; p.ay = T.y; p.f = T.x >= cx ? 1 : -1; p.cd = w.cd;
    const mk = (ang, k, o) => { const b = { x: cx + Math.cos(ang) * 14, y: cy + Math.sin(ang) * 14, px: cx, py: cy, vx: Math.cos(ang) * w.spd, vy: Math.sin(ang) * w.spd, d: w.dmg * dm, k, s: p.s, n: 0, l: 120, g: 0, hit: 0 }; if (o) Object.assign(b, o); W.pb.push(b); return b; };
    if (W.pb.length > 70 && w.id !== 'maul' && w.id !== 'beam') return;
    if (w.id === 'line') mk(a, 0);
    else if (w.id === 'fan') { const l = Math.round((w.rng / w.spd) * 60); mk(a - 0.2, 1, { l }); mk(a, 1, { l }); mk(a + 0.2, 1, { l }); }
    else if (w.id === 'seek') mk(a, 2, { l: 150 });
    else if (w.id === 'chg') { mk(a, 5, { l: 80 }); ev(W, 'chg', cx, cy, p.s); }
    else if (w.id === 'lob') { const dist = Math.hypot(T.x - cx, T.y - cy), t = clamp(dist / 420, 0.42, 0.95), g = 900; mk(0, 3, { vx: (T.x - cx) / t, vy: (T.y - cy) / t - 0.5 * g * t, g, l: 140 }); }
    else if (w.id === 'maul') {
      p.bm = 8;
      if (Math.hypot(T.x - cx, T.y - cy) - T.r <= w.rng) { if (T.m) T.m.hp -= w.dmg * dm; else dmgBoss(W, w.dmg * dm, p, 'maul', cx); ev(W, 'maul', T.x, T.y, 1); }
    } else if (w.id === 'beam') {
      p.bm = 4; const ca = Math.cos(a), sa = Math.sin(a);
      for (const q of W.mn) { const u = (q.x - cx) * ca + (q.y - cy) * sa; if (u > 0 && u < w.rng && Math.abs((q.x - cx) * sa - (q.y - cy) * ca) < q.r + 3) q.hp -= w.dmg * dm; }
      const B = W.B, d = Math.hypot(B.x + B.hx - cx, B.y + B.hy - cy) - B.hr;
      p.bl = Math.min(w.rng, Math.max(20, d + 4));
      if (!T.m && d <= w.rng) dmgBoss(W, w.dmg * dm, p, 'beam', cx);
    }
  }
  function playerStep(W, p, i) {
    if (p.down) { if (p.sy > -30) p.sy -= 0.55; p.px = p.x; p.py = p.y; return; }
    if (i.rm) { const r = i.rm; p.px = p.x; p.py = p.y; p.x += (r.x - p.x) * 0.4; p.y += (r.y - p.y) * 0.4; p.vx = r.vx; p.vy = r.vy; p.f = r.f; p.g = r.g; if (r.di) p.di = Math.max(p.di, 3); else if (p.di > 0) p.di--; if (r.fk) p.fkh = 1; p.dash = r.di ? 2 : 0; p.an += Math.abs(p.vx) * DT; }
    else phys(W, p, i);
    if (p.de) { p.de = 0; ev(W, 'dash', p.x, p.y - 15, p.s); }
    if (p.fkh) { p.fkh = 0; hurt(W, p, 1); if (p.down) return; }
    if (p.inv > 0) p.inv--; if (p.par > 0) p.par--; if (p.pcd > 0) p.pcd--; if (p.pok > 0) p.pok--; if (p.sp > 0) p.sp--; if (p.bm > 0) p.bm--; if (p.cd > 0) p.cd--;
    if (p.ch === 'spark' && W.t % 30 === 0) p.ga = Math.min(D.HERO.gauge, p.ga + 1);
    if (i.swE) { p.wi ^= 1; p.cd = Math.max(p.cd, 8); ev(W, 'swap', p.x, p.y - 30, p.s); }
    const reach = p.ch === 'reach';
    if (i.parE && p.pcd <= 0) { const n = Math.round(D.HERO.parry * 60) + (reach ? 5 : 0); p.par = n; p.pcd = n + 13; ev(W, 'par0', p.x, p.y - 15, p.s); }
    if (p.par > 0) {
      const R = PARRY_R * (reach ? 1.4 : 1), cx = p.x, cy = p.y - 15;
      for (let j = W.bl.length - 1; j >= 0; j--) { const b = W.bl[j]; if (b && b.k === 1 && Math.hypot(b.x - cx, b.y - cy) < R + b.r) { W.bl.splice(j, 1); parryOK(W, p, b.x, b.y); } }
      for (let j = W.mn.length - 1; j >= 0; j--) { const m = W.mn[j]; if (m.par && Math.hypot(m.x - cx, m.y - cy) < R + m.r) { W.mn.splice(j, 1); parryOK(W, p, m.x, m.y); } }
      for (const q of W.P) if (q !== p && q.down && q.sy > -20 && Math.hypot(q.sx - cx, q.sy - cy) < R + 14) { q.down = 0; q.hp = 1; q.inv = 100; q.x = q.px = q.sx; q.y = q.py = Math.min(GY, q.sy + 15); q.vy = -200; q.g = 0; p.rv++; p.pok = 12; ev(W, 'revive', q.x, q.y - 15, q.s); }
    }
    if (i.spE && p.ga >= D.HERO.gauge) {
      p.ga = 0; p.inv = Math.max(p.inv, 42); p.sp = 36; const cx = p.x, cy = p.y - 15;
      W.bl = W.bl.filter((b) => Math.hypot(b.x - cx, b.y - cy) > 95);
      for (const m of W.mn) if (Math.hypot(m.x - cx, m.y - cy) < 220) m.hp -= 40;
      const B = W.B; p.ax = B.x + B.hx; p.ay = B.y + B.hy;
      dmgBoss(W, D.HERO.sp * p.dm, p, 'sp', cx); ev(W, 'sp', cx, cy, p.s);
    }
    if ((i.fire || i.rf) && p.cd <= 0 && p.dash <= 0) fire(W, p);
  }

  /* ======================= 판정(호스트) ======================= */
  function hzHit(z, cx, cy, pr) {
    if (z.k === 0) return cx > z.x - pr && cx < z.x + z.w + pr && cy > z.y - pr && cy < z.y + z.h + pr;
    if (z.k === 1) return Math.hypot(cx - z.x, cy - z.y) < z.w + pr;
    const ca = Math.cos(z.an), sa = Math.sin(z.an), u = clamp((cx - z.x) * ca + (cy - z.y) * sa, 0, z.w);
    return Math.hypot(cx - (z.x + ca * u), cy - (z.y + sa * u)) < z.wd / 2 + pr;
  }
  function stepKin(W) {
    /* 탄 · 예고 · 발판의 움직임 — 호스트와 손님이 같은 식으로 */
    for (const q of W.pl) { q.px = q.x; q.x += q.vx * DT; if (q.wr && q.x + q.w < -12) { q.x += q.wr; q.px = q.x; } if (q.t > 0) { q.t++; q.off = q.t > 54 && q.t <= 164 ? 1 : 0; if (q.t > 164) q.t = 0; } }
    if (W.fkw > 0) W.fkw--;
    for (let j = W.bl.length - 1; j >= 0; j--) {
      const b = W.bl[j]; b.px = b.x; b.py = b.y; b.n++;
      if (b.rv && b.n === b.rv) { b.vx = -b.vx; b.vy = -b.vy; }
      b.vy += b.g * DT; b.x += b.vx * DT; b.y += b.vy * DT;
      let dead = b.n > b.l || b.x < -40 || b.x > AW + 40 || b.y < -90 || b.y > (W.fly ? AH + 30 : GY + 10);
      if (!dead && b.g > 0 && b.y >= GY - 3 && b.vy > 0) { dead = true; if (W.host) { if (b.fz) haz(W, b.x - 18, GY - 46, 36, 46, 8, 34, 1); ev(W, 'splash', b.x, GY); } }
      if (dead) W.bl.splice(j, 1);
    }
    for (let j = W.hz.length - 1; j >= 0; j--) {
      const z = W.hz[j]; z.t++;
      if (z.t >= z.T) { z.x += z.vx * DT; z.an += z.av; }
      if (z.pl >= 0 && W.pl[z.pl]) z.x += W.pl[z.pl].vx * DT;
      if (W.host && z.t === z.T && !z.nd) ev(W, 'zap', z.k === 0 ? z.x + z.w / 2 : z.x, z.k === 0 ? z.y + z.h / 2 : z.y, z.c);
      if (z.t >= z.T + z.A) W.hz.splice(j, 1);
    }
    for (let j = W.pb.length - 1; j >= 0; j--) {
      const b = W.pb[j]; b.px = b.x; b.py = b.y; b.n++; b.vy += b.g * DT; b.x += b.vx * DT; b.y += b.vy * DT;
      if (b.n > b.l || b.x < -30 || b.x > AW + 30 || b.y < -200 || b.y > GY + 6) W.pb.splice(j, 1);
    }
  }
  function steer(b, tx, ty, spd, turn) {
    const a = Math.atan2(b.vy, b.vx), t = Math.atan2(ty - b.y, tx - b.x); let d = t - a; while (d > PI) d -= TAU; while (d < -PI) d += TAU;
    const na = a + clamp(d, -turn, turn); b.vx = Math.cos(na) * spd; b.vy = Math.sin(na) * spd;
  }
  function collide(W) {
    const B = W.B, bx = B.x + B.hx, by = B.y + B.hy, bossOn = B.st === 'idle' || B.st === 'pat';
    /* 내 탄 */
    for (let j = W.pb.length - 1; j >= 0; j--) {
      const b = W.pb[j], p = W.P[b.s];
      if (b.k === 7) { if (!bossOn) { W.pb.splice(j, 1); continue; } steer(b, bx, by, 540, 0.5); }
      else if (b.k === 2) { let tx = bx, ty = by, best = Math.hypot(bx - b.x, by - b.y); for (const m of W.mn) { const d = Math.hypot(m.x - b.x, m.y - b.y); if (d < best) { best = d; tx = m.x; ty = m.y; } } steer(b, tx, ty, 380, 0.11); }
      let gone = false;
      if (b.k !== 7) for (const m of W.mn) { if (m.hp > 0 && Math.hypot(m.x - b.x, m.y - b.y) < m.r + 5) { if (b.k === 5) { if (!(b.hit & 2)) m.hp -= b.d; } else { m.hp -= b.d; gone = true; break; } } }
      if (!gone && bossOn && Math.hypot(bx - b.x, by - b.y) < B.hr + 4) {
        if (b.k === 5) { if (!(b.hit & 1)) { b.hit |= 1; dmgBoss(W, b.d, p, 'chg', b.px); } }
        else { dmgBoss(W, b.d, p, b.k === 7 ? 'rf' : b.k === 3 ? 'lob' : b.k === 2 ? 'seek' : 'line', b.k === 3 ? B.x : b.px); gone = true; }
      }
      if (gone) W.pb.splice(j, 1);
    }
    /* 소환물 */
    for (let j = W.mn.length - 1; j >= 0; j--) {
      const m = W.mn[j]; m.px = m.x; m.py = m.y; m.t++;
      if (m.hp <= 0) { ev(W, 'pop', m.x, m.y); W.mn.splice(j, 1); continue; }
      if (m.k === 0) {
        const a = alive(W); let q = a[0]; for (const o of a) if (Math.hypot(o.x - m.x, o.y - m.y) < Math.hypot(q.x - m.x, q.y - m.y)) q = o;
        if (m.t > 400 || !q) { m.vy -= 0.1; } else { const an = Math.atan2(q.y - 15 - m.y, q.x - m.x), sp = 2 * W.sm; m.vx += (Math.cos(an) * sp - m.vx) * 0.05; m.vy += (Math.sin(an) * sp - m.vy) * 0.05; }
        if (m.y < -30) { W.mn.splice(j, 1); continue; }
      } else if (m.k === 2) {
        if (m.t >= 170) { if (!m.par) ring(W, m.x, m.y, 6, 150, 0.5, 0, 0); ev(W, 'pop', m.x, m.y, 1); W.mn.splice(j, 1); continue; }
      }
      m.x += m.vx; m.y += m.vy;
    }
    /* 사수가 맞는지 */
    for (const p of W.P) {
      if (p.down) continue;
      const cx = p.x, cy = p.y - 15; let hit = false;
      if (p.inv > 0 || p.di > 0) continue;
      for (const b of W.bl) if (Math.hypot(b.x - cx, b.y - cy) < b.r + PRAD - 1.5) { hit = true; break; }
      if (!hit) for (const z of W.hz) if (!z.nd && z.t >= z.T && hzHit(z, cx, cy, PRAD - 2)) { hit = true; break; }
      if (!hit) for (const m of W.mn) if (Math.hypot(m.x - cx, m.y - cy) < m.r + PRAD - 1) { hit = true; if (m.k === 0) m.hp = 0; break; }
      if (!hit && bossOn) {
        if (B.cr > 0 && Math.hypot(B.x - cx, B.y - cy) < B.cr + PRAD - 2) hit = true;
        for (let q = 0; q < B.parts.length && !hit; q += 3) if (Math.hypot(B.parts[q] - cx, B.parts[q + 1] - cy) < B.parts[q + 2] + PRAD - 2) hit = true;
      }
      if (hit) hurt(W, p);
    }
  }

  /* ======================= 파수 진행 ======================= */
  function bossStep(W) {
    const B = W.B, bd = BOSS[B.id]; B.px = B.x; B.py = B.y; B.k++; if (B.hf > 0) B.hf--;
    if (B.st === 'dead') { if (B.k > 100 && !W.over) W.over = { win: 1 }; return; }
    if (B.st === 'in') { if (B.k >= 80) { B.st = 'idle'; B.k = 0; B.inv = 0; B.gap = 30; } return; }
    if (B.st === 'tr') {
      if (B.k === 40) { setPhase(W, B.ph + 1); B.st = 'tr'; B.k = 40; B.inv = 1; }
      if (B.k > 40) { B.x += (B.tx - B.x) * 0.1; B.y += (B.ty - B.y) * 0.1; }
      if (B.k >= 84) { B.st = 'idle'; B.k = 0; B.inv = 0; B.gap = 36; }
      return;
    }
    if (bd.tick) bd.tick(W, B);
    if (B.stun > 0) { B.stun--; B.po = 'stun'; return; }
    if (B.st === 'idle') {
      B.po = '';
      if (bd.idle) bd.idle(W, B); else { B.x += (B.tx - B.x) * 0.08; B.y += (B.ty - B.y) * 0.08; }
      if (B.k >= B.gap) {
        const n = bd.ph[B.ph].length;
        if (!B.bag.length) { B.bag = pickN(W, n, n); if (n > 1 && B.bag[B.bag.length - 1] === B.last) B.bag.reverse(); }
        B.pi = B.last = B.bag.pop(); B.st = 'pat'; B.k = 0; B.v = {}; B.tgi++; ev(W, 'tele', B.x, B.y, B.pi);
      }
      return;
    }
    if (bd.ph[B.ph][B.pi](W, B, B.k - 1)) { B.st = 'idle'; B.k = 0; B.po = ''; B.parts = []; B.gap = Math.round((bd.gap || 46) * (W.hard ? 0.65 : 1) * (1 - B.ph * 0.15)); }
  }

  /* ---------- 패턴 조각 ---------- */
  const chain = (a, len, b) => (W, B, k) => { if (k < len) { a(W, B, k); return false; } if (k === len) B.v = {}; return b(W, B, k - len); };
  const both = (a, b) => (W, B, k) => { const v = B.v; if (k === 0) { v.A = {}; v.B = {}; v.da = v.db = false; } let r; B.v = v.A; if (!v.da) v.da = a(W, B, k); B.v = v.B; if (!v.db) v.db = b(W, B, k); r = v.da && v.db; B.v = v; return r; };
  const glide = (B, x, y, r) => { B.x += (x - B.x) * r; B.y += (y - B.y) * r; };

  const BOSS = {};
  /* ---- 1. 녹슨 문지기: 돌진형 ---- */
  const gCharge = (n) => (W, B, k) => {
    const v = B.v; if (k === 0) { v.i = 0; v.s = 0; v.t = 0; } v.t++;
    if (v.s === 0) { B.po = 'wind'; if (v.t === 1) { B.fl = B.x > 320 ? -1 : 1; haz(W, 0, GY - 70, AW, 70, 50, 50, 0, { nd: 1 }); } if (v.t >= 50) { v.s = 1; v.t = 0; ev(W, 'rush', B.x, B.y); } }
    else if (v.s === 1) { B.po = 'dash'; B.x += B.fl * H(W, 7.6, 9); if ((B.fl > 0 && B.x >= 548) || (B.fl < 0 && B.x <= 92)) { v.s = 2; v.t = 0; ev(W, 'thud', B.x, GY); } }
    else { B.po = 'skid'; if (v.t >= 24) { if (++v.i >= n) { B.tx = B.x; return true; } v.s = 0; v.t = 0; } }
    return false;
  };
  const gSlam = (n, gap) => (W, B, k) => {
    const v = B.v; if (k === 0) { v.i = 0; v.s = 0; v.t = 0; } v.t++;
    if (v.s === 0) { B.po = 'wind'; if (v.t === 1) { const p = tp(W, B); v.x0 = B.x; v.tx = clamp(p.x, 70, 570); B.fl = sgn(v.tx - B.x); hcirc(W, v.tx, GY - 12, 46, gap + 32, 6, 0); } if (v.t >= gap) { v.s = 1; v.t = 0; } }
    else if (v.s === 1) { B.po = 'air'; const u = v.t / 32; B.x = v.x0 + (v.tx - v.x0) * u; B.y = GY - 40 - Math.sin(u * PI) * 150; if (v.t >= 32) { B.y = GY - 40; wave(W, B.x - 10, -1, 250); wave(W, B.x + 10, 1, 250); ev(W, 'thud', B.x, GY); v.s = 2; v.t = 0; } }
    else { B.po = 'land'; if (v.t >= 24) { if (++v.i >= n) { B.tx = B.x; return true; } v.s = 0; v.t = 0; } }
    return false;
  };
  const gRivets = (W, B, k) => {
    B.po = k < 24 ? 'wind' : 'cast'; const n = H(W, 3, 4);
    if (k >= 24 && k < 24 + n * 16 && (k - 24) % 16 === 0) { const i = (k - 24) / 16, p = tp(W, B); B.fl = sgn(p.x - B.x); lobAt(W, B.x, B.y - 30, clamp(p.x + (i - 1) * 70, 20, 620), GY, 54, i === 1 ? 1 : 4); }
    return k >= 40 + n * 16 + 40;
  };
  const gSpin = (W, B, k) => {
    B.po = k < 30 ? 'wind' : 'cast';
    if (k >= 30 && k < 30 + 26 * 3 && (k - 30) % 26 === 0) ring(W, B.x, B.y - 10, H(W, 14, 16), 170, ((k - 30) / 26) * 0.22, 0, 5);
    return k >= 130;
  };
  BOSS.gate = {
    enter(W, B, ph) { W.pl = [PL(130, GY - 70, 90), PL(420, GY - 70, 90)]; B.hr = 34; B.cr = 28; if (ph === 0) home(B, 540, GY - 40); else home(B, B.x, GY - 40); B.y = ph ? B.y : GY - 40; },
    idle(W, B) { B.y += (GY - 40 - B.y) * 0.2; },
    ph: [[gCharge(1), gSlam(2, 26), gRivets], [gCharge(2), gSlam(3, 20), gSpin]],
  };

  /* ---- 2. 가시 화원: 탄막형 ---- */
  const bSeed = (n) => (W, B, k) => {
    B.po = k < 30 ? 'wind' : 'cast'; const m = H(W, n, n + 1);
    if (k >= 30 && k < 30 + m * 28 && (k - 30) % 28 === 0) { const i = (k - 30) / 28; fan(W, B.x - 34, B.y, aim(B.x - 34, B.y, tp(W, B)), 5, 0.8, 210, 0, i === 1 ? 2 : -1); }
    return k >= 30 + m * 28 + 16;
  };
  const bVine = (n, gap) => (W, B, k) => {
    B.po = 'root'; const m = H(W, n, n + 1);
    if (k >= 10 && k < 10 + m * gap && (k - 10) % gap === 0) { const p = tp(W, B); haz(W, clamp(p.x - 22, 0, 480), GY - 150, 44, 150, 42, 22, 1); }
    return k >= 10 + m * gap + 60;
  };
  const bSpiral = (W, B, k) => {
    const v = B.v; if (k === 0) v.a = PI; B.po = k < 30 ? 'wind' : 'cast';
    if (k >= 30 && k < 150 && k % 6 === 0) { v.a += 0.4; const c = (k / 6) % 7 === 3 ? 1 : 0; shot(W, B.x - 30, B.y, v.a, 150, c); shot(W, B.x - 30, B.y, v.a + PI, 150, 0); }
    return k >= 170;
  };
  const bPollen = (W, B, k) => {
    const v = B.v; if (k === 0) v.o = rnd(W); B.po = k < 24 ? 'wind' : 'cast';
    if (k >= 24 && k < 24 + 5 * 14 && (k - 24) % 14 === 0) { const i = (k - 24) / 14; lobAt(W, B.x - 20, B.y - 30, 40 + ((v.o + i * 0.618) % 1) * 440, GY, 60, 4, { fz: 1 }); }
    return k >= 24 + 70 + 90;
  };
  const bThorn = (W, B, k) => {
    const v = B.v, n = H(W, 4, 5); if (k === 0) { v.q = []; for (let i = 0; i < n; i++) v.q.push(ri(W, 2)); } B.po = 'root';
    const i = Math.floor(k / 46), t = k % 46;
    if (i < n) {
      if (t === 1) haz(W, 0, v.q[i] ? GY - 98 : GY - 18, 520, v.q[i] ? 56 : 18, 30, 8, 1, { nd: 1 });
      if (t === 30) { if (v.q[i]) { for (let j = 0; j < 3; j++) shot(W, B.x - 50, GY - 50 - j * 20, PI, 320, 3); } else wave(W, B.x - 50, -1, 300); }
    }
    return k >= n * 46 + 40;
  };
  BOSS.bloom = {
    enter(W, B, ph) { W.pl = [PL(110, GY - 72, 84), PL(290, GY - 72, 84)]; B.hr = 38; B.cr = 36; home(B, 562, GY - 84); void ph; },
    ph: [[bSeed(3), bVine(3, 26)], [bSpiral, bPollen, bVine(4, 20)], [bThorn, bSeed(2)]],
  };

  /* ---- 3. 밀물 고래: 바닥 변화형 ---- */
  const tSpout = (W, B, k) => {
    const v = B.v; if (k === 0) v.q = pickN(W, 5, 3).concat(pickN(W, 5, 3)); B.po = 'cast';
    if (k >= 20 && k < 20 + 6 * 22 && (k - 20) % 22 === 0) haz(W, v.q[(k - 20) / 22] * 128 + 34, 0, 60, GY, 45, 26, 3);
    if (k > 30 && k % 50 === 0) shot(W, B.x, B.y - 10, aim(B.x, B.y - 10, tp(W, B)), 160, 0);
    return k >= 20 + 132 + 70;
  };
  const tBubble = (W, B, k) => {
    B.po = k < 20 ? 'wind' : 'cast';
    if (k >= 20 && k < 20 + 8 * 15 && (k - 20) % 15 === 0) { const i = (k - 20) / 15; shot(W, B.x - 44 * B.fl * -1, B.y - 10, aim(B.x, B.y, tp(W, B)) + (rnd(W) - 0.5) * 0.7, 105, i % 3 === 1 ? 1 : 2, { l: 440 }); }
    return k >= 20 + 120 + 50;
  };
  const tTide = (W, B, k) => {
    B.po = 'tide';
    if (k === 1) { haz(W, 0, GY - 22, AW, 22, 90, 150, 3); ev(W, 'tide', 320, GY); }
    if (k >= 100 && k < 240 && k % 45 === 0) shot(W, B.x, B.y - 10, aim(B.x, B.y - 10, tp(W, B)), 150, 0);
    return k >= 250;
  };
  const tLeap = (W, B, k) => {
    const v = B.v; if (k === 0) { v.x0 = B.x > 320 ? 575 : 65; v.x1 = AW - v.x0; }
    if (k < 40) { B.po = 'sink'; B.cr = 0; B.x += (v.x0 - B.x) * 0.2; B.y += 2.2; if (k === 1) { hcirc(W, v.x1, GY - 10, 64, 110, 8, 3); hcirc(W, v.x0, GY - 10, 64, 40, 6, 3, { nd: 1 }); } }
    else if (k < 110) { B.po = 'leap'; B.cr = 42; const u = (k - 40) / 70; B.x = v.x0 + (v.x1 - v.x0) * u; B.y = GY + 30 - Math.sin(u * PI) * 225; B.fl = sgn(v.x1 - v.x0); }
    else if (k === 110) { B.y = GY - 56; B.tx = v.x1; B.fl = v.x1 > 320 ? -1 : 1; wave(W, v.x1 + B.fl * 50, B.fl, 240); ev(W, 'thud', B.x, GY); }
    else B.po = 'land';
    return k >= 140;
  };
  const tRain = (W, B, k) => {
    B.po = 'cast';
    if (k >= 10 && k < 10 + H(W, 10, 13) * 10 && (k - 10) % 10 === 0) { const x = 30 + rnd(W) * 580; haz(W, x - 8, 0, 16, 26, 22, 4, 3, { nd: 1 }); shot(W, x, -70, PI / 2, 60, 4, { g: 520 }); }
    return k >= 10 + 130 + 70;
  };
  const tFlood = (W, B, k) => {
    const v = B.v; if (k === 0) v.o = ri(W, 3); B.po = 'tide';
    if (k === 1) { haz(W, 0, GY - 22, AW, 22, 90, 210, 3); ev(W, 'tide', 320, GY); }
    if (k === 120 || k === 178 || k === 236) { const q = W.pl[(v.o + (k - 120) / 58) % 3]; haz(W, q.x - 4, q.y - 130, q.w + 8, 130, 42, 18, 3); }
    return k >= 310;
  };
  BOSS.tide = {
    enter(W, B, ph) { W.pl = [PL(70, GY - 64, 100), PL(270, GY - 92, 100), PL(470, GY - 64, 100)]; B.hr = 44; B.cr = 40; if (!ph) { home(B, 575, GY - 56); B.fl = -1; } else home(B, B.x > 320 ? 575 : 65, GY - 56); },
    ph: [[tSpout, tBubble, tTide], [tLeap, tRain, tFlood]],
  };

  /* ---- 4. 가마 거인: 달군 바닥 ---- */
  const kHeat = (nsel, rounds) => (W, B, k) => {
    B.po = 'heat';
    if (k >= 10 && k < 10 + rounds * 90 && (k - 10) % 90 === 0) for (const s of pickN(W, 5, nsel)) haz(W, s * 128, GY - 26, 128, 26, 50, H(W, 40, 52), 1);
    return k >= 10 + rounds * 90 + 16;
  };
  const kLob = (n) => (W, B, k) => {
    B.po = k < 20 ? 'wind' : 'cast'; const m = H(W, n, n + 1), iv = W.fk ? 32 : 22;
    if (k >= 20 && k < 20 + m * iv && (k - 20) % iv === 0) { const i = (k - 20) / iv, p = tp(W, B); lobAt(W, B.x - 30, B.y - 44, p.x, W.fk ? p.y - 8 : GY, 56, i % 3 === 2 ? 1 : 4, i % 3 === 2 ? null : { fz: W.fk ? 0 : 1 }); }
    return k >= 20 + m * iv + 60;
  };
  const kFist = (W, B, k) => {
    const v = B.v; if (k === 0) { v.q = [ri(W, 2), ri(W, 2), ri(W, 2)]; if (v.q[0] === v.q[1] && v.q[1] === v.q[2]) v.q[1] ^= 1; }
    const i = Math.floor(k / 62), t = k % 62;
    B.a[0] = i < 3 && t < 54 ? (v.q[i] ? 2 : 1) : 0;
    if (i < 3) { B.po = t < 40 ? 'fist' : t < 54 ? 'punch' : ''; if (t === 1) { if (v.q[i]) haz(W, 0, GY - 142, 500, 76, 40, 12, 0); else haz(W, 0, GY - 52, 500, 52, 40, 12, 0); } }
    return k >= 3 * 62 + 10;
  };
  const kVent = (W, B, k) => { B.po = k < 30 ? 'wind' : 'cast'; if (k === 30 || k === 58 || (W.hard && k === 86)) ring(W, B.x - 20, B.y, 14, 165, k * 0.013, 0, 5); return k >= 120; };
  const kSea = (W, B, k) => {
    const v = B.v; if (k === 0) v.o = ri(W, 3); B.po = 'heat';
    if (k >= 20 && k < 20 + 4 * 60 && (k - 20) % 60 === 0) { const q = W.pl[(v.o + (k - 20) / 60 * 2) % 3]; haz(W, q.x - 4, q.y - 76, q.w + 8, 76, 64, 16, 1); }
    return k >= 20 + 240 + 36;
  };
  BOSS.kiln = {
    enter(W, B, ph) { W.pl = [PL(92, GY - 70, 98), PL(246, GY - 104, 98), PL(400, GY - 70, 98)]; B.hr = 46; B.cr = 42; home(B, 548, GY - 96); if (ph === 2) { W.fk = 1; W.fkw = 110; } },
    ph: [[kHeat(3, 2), kLob(4)], [kFist, kHeat(4, 1), kVent], [kSea, kLob(3)]],
  };

  /* ---- 5. 폭주 화차: 움직이는 무대 ---- */
  const rSmoke = (n) => (W, B, k) => {
    B.po = k < 24 ? 'wind' : 'cast';
    if (k >= 24 && k < 24 + n * 30 && (k - 24) % 30 === 0) { const i = (k - 24) / 30; shot(W, B.x - 44, B.y, aim(B.x - 44, B.y, tp(W, B)), 120, i === 1 ? 1 : 2, i === 1 ? { r: 9 } : null); }
    return k >= 24 + n * 30 + 40;
  };
  const rCoal = (n) => (W, B, k) => {
    B.po = k < 20 ? 'wind' : 'cast'; const m = H(W, n, n + 2);
    if (k >= 20 && k < 20 + m * 16 && (k - 20) % 16 === 0) lobAt(W, B.x - 30, B.y - 34, 50 + rnd(W) * 430, GY - 50, 58, 4);
    return k >= 20 + m * 16 + 60;
  };
  const rBeam = (W, B, k) => { B.po = k < 46 ? 'wind' : 'beam'; if (k === 1) haz(W, 0, GY - 152, 560, 52, 46, 30, 0); return k >= 96; };
  const rBomb = (W, B, k) => {
    B.po = 'cast';
    if (k >= 10 && k < 10 + 3 * 34 && (k - 10) % 34 === 0) {
      const p = tp(W, B), i = (k - 10) / 34; let j = 0, best = 1e9; W.pl.forEach((q, n) => { const d = Math.abs(q.x + q.w / 2 - p.x - i * 150 * (i === 2 ? -1 : 1)); if (d < best) { best = d; j = n; } });
      const q = W.pl[j]; hcirc(W, q.x + q.w / 2, q.y - 12, 42, 46, 10, 1, { pl: j });
    }
    return k >= 10 + 102 + 66;
  };
  const rRing = (W, B, k) => { B.po = k < 30 ? 'wind' : 'cast'; if (k === 30 || k === 62) ring(W, B.x - 30, B.y, H(W, 10, 12), 160, k * 0.02, 0, 5); return k >= 110; };
  BOSS.rail = {
    enter(W, B, ph) {
      const sp = [-55, -80, -105][ph]; W.fk = 1;
      if (!ph) { W.fkw = 0; W.pl = []; for (let i = 0; i < 4; i++) { const q = PL(40 + i * 180, i % 2 ? GY - 66 : GY - 40, 130, sp); q.wr = 720; W.pl.push(q); } for (const p of W.P) { p.y = p.py = GY - 40; p.on = 0; } }
      else for (const q of W.pl) q.vx = sp;
      B.hr = 42; B.cr = 38; home(B, 592, GY - 96);
    },
    gap: 38,
    ph: [[rSmoke(3), both(rCoal(5), rSmoke(2)), rBeam], [both(rBomb, rSmoke(2)), both(rSmoke(3), chain(() => false, 50, rBeam))], [both(rCoal(5), rSmoke(3)), both(rRing, chain(() => false, 40, rBeam))]],
  };

  /* ---- 6. 벌집 여왕: 소환형 ---- */
  const sDrone = (n) => (W, B, k) => {
    B.po = 'cast';
    if (k >= 20 && k < 20 + n * 30 && (k - 20) % 30 === 0) { const i = (k - 20) / 30; spawn(W, 0, 320 + (i % 2 ? 18 : -18), 110, { par: i === n - 1 ? 1 : 0, vy: 1 }); ev(W, 'spawn', 320, 110); }
    return k >= 20 + n * 30 + 80;
  };
  const sHoney = (W, B, k) => {
    B.po = k < 16 ? 'wind' : 'cast'; const n = H(W, 6, 8);
    if (k >= 16 && k < 16 + n * 12 && (k - 16) % 12 === 0) shot(W, 320, 112, 0, 0, 4, { g: 700, vx: (rnd(W) - 0.5) * 520, vy: -100 - rnd(W) * 140 });
    return k >= 16 + n * 12 + 70;
  };
  const sSting = (W, B, k) => {
    B.po = 'aim'; const n = H(W, 3, 4);
    if (k >= 10 && k < 10 + n * 40 && (k - 10) % 40 === 0) { const p = tp(W, B); B.fl = sgn(p.x - B.x); hray(W, B.x, B.y, aim(B.x, B.y, p), 700, 10, 34, 8, 2); }
    return k >= 10 + n * 40 + 40;
  };
  const sDive = (W, B, k) => {
    const v = B.v; if (k === 0) { v.x0 = B.x < 320 ? 70 : 570; v.x1 = AW - v.x0; }
    if (k < 40) { B.po = 'wind'; glide(B, v.x0, 90, 0.12); if (k === 1) hcirc(W, 320, GY - 30, 62, 68, 14, 0); }
    else if (k < 110) { B.po = 'dive'; const u = (k - 40) / 70; B.x = v.x0 + (v.x1 - v.x0) * u; B.y = 90 + (GY - 124) * Math.sin(u * PI); B.fl = sgn(v.x1 - v.x0); }
    return k >= 126;
  };
  const sRage = (W, B, k) => {
    B.po = 'rage'; B.x = 320 + 200 * Math.sin(k * 0.035); B.y = 124 + 40 * Math.sin(k * 0.07);
    if (k % 50 === 25) ring(W, B.x, B.y, H(W, 10, 12), 150, k * 0.01, 0, 5);
    if (k === 40 || k === 110) spawn(W, 0, 320, 110, { vy: 1 });
    return k >= 157;
  };
  BOSS.swarm = {
    enter(W, B, ph) { W.pl = [PL(60, GY - 70, 96), PL(272, GY - 58, 96), PL(484, GY - 70, 96)]; if (!ph) { B.hr = 34; B.cr = 0; home(B, 320, 86); } else { B.hr = 26; B.cr = 22; home(B, 320, 132); B.a[0] = 1; } },
    tick(W, B) { if (B.ph >= 1 && W.t % 150 === 0) spawn(W, 0, 320, 110, { vy: 1, par: W.t % 450 === 0 ? 1 : 0 }); },
    gap: 38,
    ph: [[sDrone(4), sHoney], [sSting, sDive, sDrone(3)], [sRage, sDive]],
  };

  /* ---- 7. 거울 기사: 받아치기형 ---- */
  const mThrust = (n) => (W, B, k) => {
    const v = B.v; if (k === 0) { v.i = 0; v.s = 0; v.t = 0; } v.t++;
    if (v.s === 0) { B.po = 'wind'; if (v.t === 1) { B.fl = sgn(tp(W, B).x - B.x); haz(W, B.fl > 0 ? B.x : B.x - 240, GY - 46, 240, 46, 34, 10, 0); } if (v.t >= 34) { v.s = 1; v.t = 0; ev(W, 'rush', B.x, B.y); } }
    else if (v.s === 1) { B.po = 'thrust'; B.x = clamp(B.x + B.fl * 20, 40, 600); if (v.t >= 10) { v.s = 2; v.t = 0; B.a[2] = 54; } }
    else { B.po = 'rec'; if (v.t === 4 && B.ph) { wave(W, B.x, B.fl, 260); wave(W, B.x, -B.fl, 260); } if (v.t >= H(W, 40, 30)) { if (++v.i >= n) { B.tx = B.x; return true; } v.s = 0; v.t = 0; } }
    return false;
  };
  const mOrb = (n, cy) => (W, B, k) => {
    B.po = k < 24 ? 'wind' : 'cast'; if (k === 0) B.fl = sgn(tp(W, B).x - B.x);
    if (k >= 24 && k < 24 + n * 26 && (k - 24) % 26 === 0) { const i = (k - 24) / 26; shot(W, B.x + B.fl * 20, B.y - 22, aim(B.x + B.fl * 20, B.y - 22, tp(W, B)), 190, cy.indexOf(i) >= 0 ? 1 : 0, { r: 8 }); if (B.ph) wave(W, B.x, B.fl, 220); }
    return k >= 24 + n * 26 + 36;
  };
  const mStep = (W, B, k) => {
    const v = B.v, p = tp(W, B); if (k === 0) v.x = p.x < 320 ? 520 : 120; B.po = 'walk';
    const d = v.x - B.x; B.fl = sgn(d); B.x += clamp(d, -3.2, 3.2);
    if (Math.abs(d) < 4 || k > 130) { B.fl = sgn(p.x - B.x); B.tx = B.x; return true; }
    return false;
  };
  const mBlink = (n, rg) => (W, B, k) => {
    const v = B.v; if (k === 0) { v.i = 0; v.t = 0; } v.t++;
    if (v.t === 1) { const p = tp(W, B); v.x = clamp(p.x + (rnd(W) < 0.5 ? -46 : 46), 40, 600); hcirc(W, v.x, GY - 30, 44, 34, 10, 0); ev(W, 'blink', B.x, B.y); }
    if (v.t < 24) { B.po = 'fade'; B.inv = 1; B.cr = 0; }
    else { if (v.t === 24) { B.x = B.px = v.x; B.fl = sgn(tp(W, B).x - B.x); } B.po = v.t < 44 ? 'slash' : 'rec'; B.inv = 0; B.cr = v.t >= 34 ? 22 : 0; if (rg && v.t === 38) ring(W, B.x, B.y - 10, 12, 170, rnd(W), 0, 6); }
    if (v.t >= H(W, 56, 48)) { B.cr = 22; if (++v.i >= n) { B.tx = B.x; return true; } v.t = 0; }
    return false;
  };
  const mWave = (W, B, k) => {
    if (k === 0) B.fl = sgn(tp(W, B).x - B.x); B.po = k < 20 ? 'wind' : 'cast';
    if (k === 20) wave(W, B.x, B.fl, 230); if (k === 44 || k === 92) shot(W, B.x, GY - 64, B.fl > 0 ? 0 : PI, 300, 3);
    if (k === 68) wave(W, B.x, B.fl, 290); if (W.hard && k === 116) wave(W, B.x, B.fl, 250);
    return k >= 150;
  };
  BOSS.mirror = {
    enter(W, B, ph) { W.pl = [PL(120, GY - 74, 84), PL(436, GY - 74, 84)]; B.hr = 26; B.cr = 22; B.inv = 0; if (!ph) home(B, 500, GY - 32); else home(B, B.x, GY - 32); B.a[0] = ph < 2 ? 1 : 0; B.a[1] = 0; B.a[2] = 0; },
    tick(W, B) { if (B.a[1] > 0) B.a[1]--; if (B.a[2] > 0) B.a[2]--; },
    /* 앞에서 온 탄은 방패가 막음. 되받아친 구슬은 방패를 깨고 멈추게 함. 곡사 · 추적 · 필살은 통과 */
    block(W, B, kind, sx) {
      if (!B.a[0] || B.a[1] > 0 || B.a[2] > 0) return false;
      if (kind === 'rf') { B.a[1] = 260; B.stun = 100; B.st = 'idle'; B.k = 0; B.gap = 30; B.inv = 0; B.cr = 22; W.hz.length = 0; ev(W, 'break', B.x, B.y); return false; }
      if (kind === 'lob' || kind === 'seek' || kind === 'sp') return false;
      return (sx - B.x) * B.fl > 0;
    },
    gap: 32,
    ph: [[mThrust(1), mOrb(3, [1]), mStep], [mBlink(3, 0), mWave, mOrb(4, [1, 3])], [mBlink(4, 1), mThrust(2), mOrb(4, [1, 3])]],
  };

  /* ---- 8. 뇌운 까마귀: 비행 무대 ---- */
  const bob = (W, B) => { B.x += (B.tx - B.x) * 0.06; B.y += (B.ty + Math.sin(W.t * 0.04) * 24 - B.y) * 0.06; };
  const cFeather = (W, B, k) => {
    B.po = k < 26 ? 'wind' : 'cast'; const n = H(W, 3, 4);
    if (k >= 26 && k < 26 + n * 30 && (k - 26) % 30 === 0) { const i = (k - 26) / 30; fan(W, B.x - 40, B.y, aim(B.x - 40, B.y, tp(W, B)), 7, 1.25, 230, 3, i === 1 ? 3 : -1); }
    return k >= 26 + n * 30 + 20;
  };
  const cCol = (rounds, nsel) => (W, B, k) => {
    B.po = 'call';
    if (k >= 10 && k < 10 + rounds * 74 && (k - 10) % 74 === 0) for (const c of pickN(W, 5, nsel)) haz(W, c * 128, 0, 128, GY, 48, 14, 2);
    return k >= 10 + rounds * 74 + 10;
  };
  const cRow = (W, B, k) => {
    B.po = 'call';
    if (k >= 10 && k < 10 + 3 * 70 && (k - 10) % 70 === 0) for (const c of pickN(W, 3, 2)) haz(W, 0, 30 + c * 90, AW, 90, 44, 14, 2);
    return k >= 10 + 210 + 10;
  };
  const lunge = (po, spd) => (W, B, k) => {
    const v = B.v; if (k === 0) { v.y = clamp(tp(W, B).y - 15, 50, GY - 20); v.x = B.x; hray(W, AW, v.y, PI, AW, 80, 40, 24, 2, { nd: 1 }); }
    if (k < 40) { B.po = 'wind'; B.y += (v.y - B.y) * 0.14; }
    else if (k < 40 + Math.round(500 / spd)) { B.po = po; B.x -= spd; if (k === 40) ev(W, 'rush', B.x, B.y); }
    else { B.po = 'rec'; B.x += (v.x - B.x) * 0.12; }
    return k >= 40 + Math.round(500 / spd) + 36;
  };
  const cWall = (W, B, k) => {
    B.po = k < 20 ? 'wind' : 'cast'; const n = H(W, 3, 4);
    if (k >= 20 && k < 20 + n * 44 && (k - 20) % 44 === 0) { const gp = 1 + ri(W, 6); for (let j = 0; j < 9; j++) if (j !== gp && j !== gp + 1) shot(W, B.x - 50, 50 + j * 30, PI, 170, j === gp - 1 ? 1 : 3); }
    return k >= 20 + n * 44 + 30;
  };
  const cEye = (W, B, k) => {
    const v = B.v; if (k === 0) v.a = 0; B.po = 'rage';
    if (k >= 20 && k < 170 && k % 6 === 0) { v.a += 0.21; for (let j = 0; j < 3; j++) shot(W, B.x, B.y, v.a + j * TAU / 3, 130, (k / 6) % 9 === 4 && j === 0 ? 1 : 0); }
    if (k === 40 || k === 110) for (const c of pickN(W, 4, 2)) haz(W, (c >= 2 ? c + 1 : c) * 128, 0, 128, GY, 48, 14, 2);
    return k >= 190;
  };
  BOSS.storm = {
    enter(W, B, ph) { W.pl = []; B.hr = 44; B.cr = 40; if (ph < 2) home(B, 545, 170); else home(B, 320, 160); },
    idle: bob, gap: 30,
    ph: [[cFeather, cCol(2, 3)], [cRow, lunge('dive', 20), cWall], [cEye, cCol(1, 2)]],
  };

  /* ---- 9. 태엽 시계탑: 암기형 ---- */
  const kHand = (two) => (W, B, k) => {
    B.po = 'hand';
    if (k === 1) { hray(W, 320, 128, 0, 170, 14, 40, 96, 4, { av: PI / 96 }); if (two) hray(W, 320, 128, PI, 130, 12, 40, 96, 4, { av: -PI / 96 }); }
    if (k > 50 && k < 130 && k % 26 === 0) shot(W, 320, 128, aim(320, 128, tp(W, B)), 170, k % 52 === 0 ? 1 : 0);
    return k >= 148;
  };
  const kBell = (n, gap) => (W, B, k) => {
    B.po = 'bell';
    if (k === 1) { let last = -1; for (let j = 0; j < n; j++) { let s = ri(W, 5); if (s === last) s = (s + 1 + ri(W, 3)) % 5; last = s; haz(W, s * 128 + 5, 0, 118, GY, 64 + j * gap, 12, 5); } }
    if (k > 20 && k % 34 === 0 && k < 64 + n * gap) shot(W, 320, 128, aim(320, 128, tp(W, B)), 175, k % 68 === 0 ? 1 : 0);
    return k >= 64 + n * gap + 24;
  };
  const kChime = (W, B, k) => { B.po = k < 30 ? 'wind' : 'cast'; if (k === 30 || k === 58 || (W.hard && k === 86)) ring(W, 320, 128, 14, 165, k * 0.017, 0, 7); return k >= 120; };
  const kPend = (W, B, k) => {
    B.po = 'pend';
    if (k === 1) haz(W, 0, GY - 20, AW, 20, 40, 8, 4, { nd: 1 });
    if (k === 40) shot(W, 14, GY - 10, 0, 290 / W.sm, 5, { r: 11, rv: 126, l: 252 });
    return k >= 300;
  };
  const kRewind = (W, B, k) => {
    B.po = k < 30 ? 'wind' : 'cast';
    if (k === 30 || k === 74) ring(W, 320, 128, H(W, 20, 22), 170 / W.sm, k * 0.03, 0, 10, { rv: 66, l: 131 });
    return k >= 220;
  };
  BOSS.clock = {
    enter(W, B, ph) { W.pl = [PL(50, GY - 72, 96), PL(494, GY - 72, 96)]; B.hr = 42; B.cr = 0; home(B, 320, 128); void ph; },
    gap: 18,
    ph: [[kHand(0), kBell(4, 22), kChime], [both(kHand(1), chain(() => false, 50, kChime)), both(kPend, kBell(4, 30)), kBell(5, 18)], [both(kRewind, kBell(3, 40)), both(kHand(1), chain(() => false, 60, kChime))]],
  };

  /* ---- 10. 줄 끊긴 인형사: 양손형 (a[0..3] 손 위치, a[4] 뜨거운 손 비트, a[5] 오른손 없음) ---- */
  const REST = [[190, 126], [450, 126]];
  const hx = (B, h) => B.a[h * 2], hy = (B, h) => B.a[h * 2 + 1];
  const hset = (B, h, x, y) => { B.a[h * 2] = x; B.a[h * 2 + 1] = y; };
  const hgl = (B, h, x, y, r) => { B.a[h * 2] += (x - B.a[h * 2]) * r; B.a[h * 2 + 1] += (y - B.a[h * 2 + 1]) * r; };
  const hot = (B, h) => { B.a[4] |= 1 << h; };
  const pSlam = (n, wv) => (W, B, k) => {
    const v = B.v; if (k === 0) { v.i = 0; v.t = 0; } v.t++; const h = B.a[5] ? 0 : v.i % 2; B.po = 'slam';
    if (v.t <= 24) hgl(B, h, clamp(tp(W, B).x, 40, 600), 108, 0.16);
    else if (v.t === 25) { v.x = hx(B, h); haz(W, v.x - 26, 96, 52, GY - 96, 30, 8, 0); }
    else if (v.t > 54 && v.t <= 60) { hset(B, h, v.x, 108 + (GY - 26 - 108) * (v.t - 54) / 6); hot(B, h); if (v.t === 60) { ev(W, 'thud', v.x, GY); if (wv) { wave(W, v.x - 4, -1, 165); wave(W, v.x + 4, 1, 165); } } }
    else if (v.t > 60 && v.t <= 68) hot(B, h);
    else if (v.t > 68) hgl(B, h, v.x, 108, 0.2);
    if (v.t >= H(W, wv ? 108 : 96, 80)) { if (++v.i >= n) return true; v.t = 0; }
    return false;
  };
  const pSweep = (W, B, k) => {
    const v = B.v; if (k === 0) { v.h = B.a[5] ? 0 : ri(W, 2); v.d = v.h ? -1 : 1; } const h = v.h, x0 = v.d > 0 ? 28 : 612; B.po = 'sweep';
    if (k === 1) haz(W, 0, GY - 54, AW, 54, 40, 38, 0, { nd: 1 });
    if (k < 40) hgl(B, h, x0, GY - 26, 0.14);
    else if (k < 78) { hset(B, h, x0 + v.d * (k - 40) * 16, GY - 26); hot(B, h); if (k === 40) ev(W, 'rush', x0, GY - 26); }
    return k >= 96;
  };
  const pClap = (W, B, k) => {
    const v = B.v; if (k === 0) v.q = [ri(W, 2), ri(W, 2), ri(W, 2)]; const i = Math.floor(k / 80), t = k % 80; B.po = 'clap';
    if (i >= 3) return true;
    const y = v.q[i] ? GY - 94 : GY - 26;
    if (t === 1) haz(W, 0, y - 28, AW, 56, 48, 26, 0, { nd: 1 });
    if (t < 48) { hgl(B, 0, 28, y, 0.14); hgl(B, 1, 612, y, 0.14); }
    else if (t < 72) { const d = (t - 48) * 11.6; hset(B, 0, 28 + d, y); hset(B, 1, 612 - d, y); hot(B, 0); hot(B, 1); if (t === 71) ev(W, 'thud', 320, y); }
    return false;
  };
  const pFan = (W, B, k) => {
    B.po = 'cast'; const n = H(W, 4, 5);
    if (k >= 20 && k < 20 + n * 34 && (k - 20) % 34 === 0) fan(W, B.x, B.y + 12, aim(B.x, B.y + 12, tp(W, B)), 3, 0.5, 190, 0, 1);
    return k >= 20 + n * 34 + 20;
  };
  const pString = (W, B, k) => { B.po = 'cast'; if (k === 1) for (const s of pickN(W, 8, H(W, 3, 4))) haz(W, s * 80 + 35, 0, 10, GY, 46, 40, 4); return k >= 100; };
  const pRing = (W, B, k) => { B.po = k < 30 ? 'wind' : 'cast'; if (k === 30 || k === 70) ring(W, B.x, B.y, 10, 160, k * 0.02, 0, 5); return k >= 110; };
  BOSS.puppet = {
    enter(W, B, ph) { W.pl = [PL(100, GY - 70, 84), PL(456, GY - 70, 84)]; B.hr = 30; B.cr = 0; if (!ph) { home(B, 320, 74); hset(B, 0, REST[0][0], REST[0][1]); hset(B, 1, REST[1][0], REST[1][1]); } B.a[4] = 0; if (ph === 2) { B.a[5] = 1; home(B, 320, 96); } },
    tick(W, B) {
      B.parts = []; for (let h = 0; h < 2; h++) { if (h && B.a[5]) continue; if (B.a[4] & (1 << h)) B.parts.push(hx(B, h), hy(B, h), 24); }
      B.a[4] = 0;
      if (B.st === 'idle') { for (let h = 0; h < 2; h++) hgl(B, h, REST[h][0] + Math.sin(W.t * 0.03 + h * 2) * 14, REST[h][1] + Math.cos(W.t * 0.04 + h) * 8, 0.08); }
    },
    idle(W, B) { if (B.ph === 2) { B.x += clamp(tp(W, B).x - B.x, -0.7, 0.7); B.y += (B.ty - B.y) * 0.08; } else glide(B, B.tx, B.ty, 0.08); },
    gap: 30,
    ph: [[pSlam(2, 0), pSweep], [pClap, pFan, pString], [pSlam(3, 1), pRing, pSweep]],
  };
  /* 손은 한 걸음 늦게 판정되므로(tick → 패턴) 패턴이 켠 비트는 다음 걸음의 tick에서 parts가 됨 */

  /* ---- 11. 심해 등불: 비행 무대 ---- */
  const dLure = (n) => (W, B, k) => {
    B.po = k < 36 ? 'lure' : 'cast';
    if (k >= 36 && k < 36 + n * 30 && (k - 36) % 30 === 0) ring(W, B.x - 78, B.y - 58, H(W, 22, 24), 185, ((k - 36) / 30) * 0.2, 0, 8);
    return k >= 36 + n * 30 + 30;
  };
  const dMine = (n) => (W, B, k) => {
    B.po = 'cast';
    if (k >= 20 && k < 20 + n * 24 && (k - 20) % 24 === 0) { const i = (k - 20) / 24; spawn(W, 2, B.x - 60, 60 + rnd(W) * 220, { vx: -0.9 - rnd(W), par: i === 0 ? 1 : 0 }); ev(W, 'spawn', B.x - 60, B.y); }
    return k >= 20 + n * 24 + 50;
  };
  const dSuck = (W, B, k) => {
    B.po = 'suck'; W.wind = k < 200 ? 110 : 0;
    if (k === 30 || k === 95 || k === 160) hcirc(W, B.x - 84, B.y, 62, 34, 14, 0);
    if (k > 20 && k < 200 && k % 28 === 0) fan(W, B.x - 78, B.y - 58, aim(B.x - 78, B.y - 58, tp(W, B)), 3, 0.5, 150, 0, k % 84 === 0 ? 1 : -1);
    return k >= 206;
  };
  const dFrenzy = (W, B, k) => {
    B.po = 'rage'; B.y += (clamp(tp(W, B).y - 15, 70, GY - 40) - B.y) * 0.04;
    if (k >= 20 && k % 18 === 0) fan(W, B.x - 50, B.y, aim(B.x - 50, B.y, tp(W, B)), 5, 0.8, 220, 0, (k / 18) % 3 === 1 ? 2 : -1);
    return false;
  };
  BOSS.deep = {
    enter(W, B, ph) { W.pl = []; B.hr = 46; B.cr = 42; home(B, 545, 180); void ph; },
    idle: bob, gap: 8,
    ph: [[dLure(3), chain(lunge('bite', 22), 99, lunge('bite', 22))], [both(dMine(4), dLure(2)), dSuck, chain(lunge('bite', 20), 100, dLure(3))], [chain(dFrenzy, 150, lunge('bite', 21)), both(dMine(3), dLure(3))]],
  };

  /* ---- 12. 공허 심장: 최종 ---- */
  const vArms = (n, rot, len) => (W, B, k) => {
    const v = B.v; if (k === 0) v.a = rnd(W) * TAU; B.po = k < 24 ? 'wind' : 'cast';
    if (k >= 24 && k < 24 + len && k % 6 === 0) { v.a += rot; for (let j = 0; j < n; j++) shot(W, B.x, B.y, v.a + j * TAU / n, 140, (k / 6) % 10 === 5 && j === 0 ? 1 : 0); }
    return k >= 24 + len + 30;
  };
  const vCross = (rounds) => (W, B, k) => {
    B.po = 'call';
    if (k >= 10 && k < 10 + rounds * 70 && (k - 10) % 70 === 0) { for (const s of pickN(W, 6, 2)) haz(W, s * 106 + 18, 0, 70, GY, 46, 16, 4); if (ri(W, 2)) haz(W, 0, GY - 36, AW, 36, 46, 16, 4); else haz(W, 0, GY - 124, AW, 62, 46, 16, 4); }
    return k >= 10 + rounds * 70 + 10;
  };
  const vCollapse = (W, B, k) => {
    B.po = 'call';
    if (k === 1) { const q = pickN(W, 5, 2); for (const j of q) W.pl[j].t = 1; ev(W, 'tide', 320, GY); }
    if (k === 60 || k === 100 || k === 140) shot(W, B.x, B.y, aim(B.x, B.y, tp(W, B)), 150, k === 100 ? 1 : 0);
    return k >= 190;
  };
  const vLaser = (W, B, k) => { const v = B.v; if (k === 0) v.o = ri(W, 2); B.po = 'call'; if (k === 1 || k === 76) for (let j = (v.o + (k > 1 ? 1 : 0)) % 2; j < W.pl.length; j += 2) { const q = W.pl[j]; haz(W, q.x, 0, q.w, GY, 52, 16, 4); } return k >= 150; };
  const vShell = (W, B, k) => {
    B.po = 'cast'; const n = H(W, 4, 5);
    if (k >= 20 && k < 20 + n * 40 && (k - 20) % 40 === 0) fan(W, B.x, B.y, aim(B.x, B.y, tp(W, B)), 3, 0.5, 150, 0, 1);
    return k >= 20 + n * 40 + 30;
  };
  BOSS.core = {
    enter(W, B, ph) {
      B.hr = 40; B.cr = 0; home(B, 320, 132); B.a[0] = 0; B.a[1] = ph === 2 ? 1 : 0; B.a[2] = 0; B.a[3] = 0;
      if (ph === 1) { W.fk = 1; W.fkw = 110; W.pl = [PL(6, GY - 44, 116), PL(142, GY - 84, 104), PL(268, GY - 44, 104), PL(394, GY - 84, 104), PL(518, GY - 44, 116)]; }
      else { W.fk = 0; W.pl = [PL(60, GY - 72, 96), PL(272, GY - 104, 96), PL(484, GY - 72, 96)]; }
    },
    tick(W, B) {
      if (B.ph !== 2) return;
      if (B.a[1]) { if (++B.a[2] > 1200) { B.a[1] = 0; B.a[3] = 200; ev(W, 'break', B.x, B.y); } }
      else if (--B.a[3] <= 0) { B.a[1] = 1; B.a[0] = 0; B.a[2] = 0; }
    },
    block(W, B, kind) {
      if (B.ph !== 2 || !B.a[1] || kind === 'sp') return false;
      if (kind === 'rf') { if (++B.a[0] >= 3) { B.a[1] = 0; B.a[3] = 360; ev(W, 'break', B.x, B.y); return false; } }
      return true;
    },
    gap: 24,
    ph: [[vArms(5, 0.12, 130), vCross(3)], [both(vCollapse, chain(() => false, 60, vArms(2, 0.2, 90))), vArms(3, 0.16, 110), vLaser], [both(vShell, vCross(2)), vArms(3, 0.14, 100)]],
  };

  /* ======================= 한 걸음 ======================= */
  /* inputFor(seat, p) → 입력({mx,my,jump,jumpE,dashE,parE,spE,swE,fire} 또는 {rm:…}) */
  function worldStep(W, inputFor) {
    W.t++; if (!W.over && W.B.st !== 'in' && W.B.st !== 'dead') W.time += DT;
    for (const p of W.P) { const i = inputFor(p.s, p) || NOIN; playerStep(W, p, i); }
    bossStep(W);
    stepKin(W);
    collide(W);
  }
  const NOIN = {};
  /* 손님: 자기 사수만 예측, 나머지는 호스트 소식 사이를 같은 식으로 흘려보냄 */
  function guestStep(W, me, input) {
    W.t++;
    for (const p of W.P) {
      if (p.s === me && !p.down) { phys(W, p, input || NOIN); if (p.de) p.de = 0; if (p.fkh) { p.fkh = 0; p.fkn = (p.fkn || 0) + 1; } }
      else { p.px = p.x; p.py = p.y; if (!p.down) { p.x += p.vx * DT; if (!p.g || W.fly) p.y += p.vy * DT; } else if (p.sy > -30) p.sy -= 0.55; p.an += Math.abs(p.vx) * DT; }
      if (p.inv > 0) p.inv--; if (p.par > 0) p.par--; if (p.pok > 0) p.pok--; if (p.sp > 0) p.sp--; if (p.bm > 0) p.bm--;
    }
    const B = W.B; B.px = B.x; B.py = B.y; B.k++; B.x += B.gvx || 0; B.y += B.gvy || 0; if (B.hf > 0) B.hf--;
    for (const m of W.mn) { m.px = m.x; m.py = m.y; m.x += m.vx; m.y += m.vy; m.t++; }
    stepKin(W);
  }

  /* ======================= 네트워크 묶기 ======================= */
  const r1 = Math.round, r2 = (v) => Math.round(v * 2), r10 = (v) => Math.round(v * 10);
  function packHost(W) {
    const B = W.B, o = { t: W.t, f: [W.fk, W.fkw, r1(W.wind), r1(W.time * 10), W.over ? (W.over.win ? 1 : 2) : 0] };
    o.B = [B.ph, r1(B.hp), r1(B.mhp), r2(B.x), r2(B.y), B.st, B.k, B.po, B.inv ? 1 : 0, B.fl, B.hr, B.cr, r10(B.x - B.px), r10(B.y - B.py), B.stun, B.hf].concat(B.a.map(r1));
    o.P = W.P.map((p) => [r2(p.x), r2(p.y), r1(p.vx), r1(p.vy), (p.f > 0 ? 1 : 0) | (p.g ? 2 : 0) | (p.down ? 4 : 0) | (p.dash > 0 ? 8 : 0) | (p.sh ? 16 : 0), p.hp, r1(p.ga), p.inv, p.wi, p.par, p.pok, p.sp, p.bm, r1(p.ax), r1(p.ay), r1(p.sx), r1(p.sy), p.hits, p.pn, r1(p.dmg), p.rv, r1(p.bl || 0), p.cd]);
    const bl = []; for (const b of W.bl) bl.push(r2(b.x), r2(b.y), r1(b.vx), r1(b.vy), r2(b.r), b.k, r1(b.g), b.rv ? b.rv - b.n : 0, b.l - b.n); o.bl = bl;
    const pb = []; for (const b of W.pb) pb.push(r2(b.x), r2(b.y), r1(b.vx), r1(b.vy), b.k, r1(b.g), b.s); o.pb = pb;
    const hz = []; for (const z of W.hz) hz.push(z.k, r1(z.x), r1(z.y), r1(z.w), r1(z.h), r1(z.an * 1000), z.wd, z.t, z.T, z.A, z.c | (z.nd ? 16 : 0), r1(z.vx), r1(z.av * 1e5), z.pl); o.hz = hz;
    const mn = []; for (const m of W.mn) mn.push(m.k, r2(m.x), r2(m.y), r1(m.vx * 100), r1(m.vy * 100), m.r, m.par, m.t); o.mn = mn;
    const pl = []; for (const q of W.pl) pl.push(r2(q.x), q.y, q.w, q.vx, q.off, q.t, q.wr); o.pl = pl;
    o.ev = W.ev.filter((e) => W.t - e[5] < 50).map((e) => e.slice(0, 5));
    return o;
  }
  function applyHost(W, o, me) {
    const out = [], B = W.B, a = o.B;
    W.fk = o.f[0]; W.fkw = o.f[1]; W.wind = o.f[2]; W.time = o.f[3] / 10; W.over = o.f[4] ? { win: o.f[4] === 1 ? 1 : 0 } : null;
    B.ph = a[0]; B.hp = a[1]; B.mhp = a[2]; B.px = B.x; B.py = B.y; B.x = a[3] / 2; B.y = a[4] / 2; B.st = a[5]; B.k = a[6]; B.po = a[7]; B.inv = a[8]; B.fl = a[9]; B.hr = a[10]; B.cr = a[11]; B.gvx = a[12] / 10; B.gvy = a[13] / 10; B.stun = a[14]; B.hf = Math.max(B.hf, a[15]);
    if (Math.hypot(B.x - B.px, B.y - B.py) > 60) { B.px = B.x; B.py = B.y; }
    for (let i = 0; i < 6; i++) B.a[i] = a[16 + i];
    o.P.forEach((q, s) => {
      const p = W.P[s]; if (!p) return; const wasDown = p.down, down = q[4] & 4 ? 1 : 0;
      if (s !== me || down || wasDown) { p.px = p.x; p.py = p.y; p.x = q[0] / 2; p.y = q[1] / 2; if (Math.hypot(p.x - p.px, p.y - p.py) > 50) { p.px = p.x; p.py = p.y; } p.vx = q[2]; p.vy = q[3]; p.g = q[4] & 2 ? 1 : 0; if (s === me && wasDown && !down) { p.vy = -200; p.g = 0; } if (s !== me) { p.f = q[4] & 1 ? 1 : -1; p.dash = q[4] & 8 ? 2 : 0; } }
      p.down = down; p.sh = q[4] & 16 ? 1 : 0; p.hp = q[5]; p.ga = q[6]; p.inv = q[7]; p.wi = q[8]; if (s !== me) p.par = q[9]; p.pok = Math.max(p.pok, q[10]); p.sp = q[11]; p.bm = q[12]; p.ax = q[13]; p.ay = q[14]; p.sx = q[15]; p.sy = q[16]; p.hits = q[17]; p.pn = q[18]; p.dmg = q[19]; p.rv = q[20]; p.bl = q[21]; p.cd = q[22];
    });
    let n = o.bl.length / 9; W.bl.length = 0;
    for (let i = 0; i < n; i++) { const j = i * 9, vx = o.bl[j + 2], vy = o.bl[j + 3]; W.bl.push({ x: o.bl[j] / 2, y: o.bl[j + 1] / 2, px: o.bl[j] / 2 - vx * DT, py: o.bl[j + 1] / 2 - vy * DT, vx, vy, r: o.bl[j + 4] / 2, k: o.bl[j + 5], g: o.bl[j + 6], n: 0, rv: o.bl[j + 7] > 0 ? o.bl[j + 7] : 0, l: o.bl[j + 8], fz: 0 }); }
    n = o.pb.length / 7; W.pb.length = 0;
    for (let i = 0; i < n; i++) { const j = i * 7, vx = o.pb[j + 2], vy = o.pb[j + 3]; W.pb.push({ x: o.pb[j] / 2, y: o.pb[j + 1] / 2, px: o.pb[j] / 2 - vx * DT, py: o.pb[j + 1] / 2 - vy * DT, vx, vy, k: o.pb[j + 4], g: o.pb[j + 5], s: o.pb[j + 6], n: 0, l: 60, d: 0 }); }
    n = o.hz.length / 14; W.hz.length = 0;
    for (let i = 0; i < n; i++) { const j = i * 14, h = o.hz; W.hz.push({ k: h[j], x: h[j + 1], y: h[j + 2], w: h[j + 3], h: h[j + 4], an: h[j + 5] / 1000, wd: h[j + 6], t: h[j + 7], T: h[j + 8], A: h[j + 9], c: h[j + 10] & 15, nd: h[j + 10] & 16 ? 1 : 0, vx: h[j + 11], av: h[j + 12] / 1e5, pl: h[j + 13] }); }
    n = o.mn.length / 8; W.mn.length = 0;
    for (let i = 0; i < n; i++) { const j = i * 8, m = o.mn; W.mn.push({ k: m[j], x: m[j + 1] / 2, y: m[j + 2] / 2, px: m[j + 1] / 2 - m[j + 3] / 100, py: m[j + 2] / 2 - m[j + 4] / 100, vx: m[j + 3] / 100, vy: m[j + 4] / 100, r: m[j + 5], par: m[j + 6], t: m[j + 7], hp: 1 }); }
    n = o.pl.length / 7;
    if (W.pl.length !== n) { W.pl = []; for (let i = 0; i < n; i++) W.pl.push(PL(0, 0, 0)); }
    for (let i = 0; i < n; i++) { const j = i * 7, q = W.pl[i], nx = o.pl[j] / 2; q.px = Math.abs(nx - q.x) > 40 ? nx : q.x; q.x = nx; q.y = o.pl[j + 1]; q.w = o.pl[j + 2]; q.vx = o.pl[j + 3]; q.off = o.pl[j + 4]; q.t = o.pl[j + 5]; q.wr = o.pl[j + 6]; }
    for (const e of o.ev) if (e[0] > W.en) { W.en = e[0]; out.push(e); }
    return out;
  }
  const packMe = (p) => [r2(p.x), r2(p.y), r1(p.vx), r1(p.vy), (p.f > 0 ? 1 : 0) | (p.g ? 2 : 0) | (p.di > 0 ? 4 : 0)];

  /* ======================= 봇 ======================= */
  /* 후보 행동(좌/우/제자리 × 그대로/점프/대시)을 가볍게 앞으로 돌려 보고 점수를 매김. 점수 = 맞는지 + 자리(무기 거리 · 버릇).
     쉬움은 짧게 · 드물게 보고 가끔 그냥 넘김, 어려움은 길게 · 자주 봄. 버릇은 판 시드에서. */
  function botInit(W, p) {
    let s = (W.rs ^ (p.s * 7477 + 99991)) | 0; const R = () => { s = (Math.imul(s, 1664525) + 1013904223) | 0; return (s >>> 0) / 4294967296; };
    return { R, t: 0, mx: 0, my: 0, jh: 0, act: 0, dist: 140 + R() * 150, parry: 0.75 + R() * 0.25, jmp: R() * 0.8, lz: 0, spT: 20 + R() * 120, rt: [0, 28, 20, 13][p.lv || 2] + Math.floor(R() * 4) };
  }
  function danger(W, q, t, inv, rt) {
    if (inv - t > 0 || q.di > 0) return 99;
    const cx = q.x, cy = q.y - 15, tt = t * DT, B = W.B; let c = 99;
    for (const b of W.bl) {
      if (b.bp || b.n < rt) continue;
      let bx, by; if (b.rv && b.n + t >= b.rv) { const u = (b.rv - b.n) * DT, w = tt - u; bx = b.x + b.vx * (u - w); by = b.y + b.vy * (u - w); } else { bx = b.x + b.vx * tt; by = b.y + b.vy * tt + 0.5 * b.g * tt * tt; }
      const d = Math.hypot(bx - cx, by - cy) - b.r - PRAD; if (d < c) c = d;
    }
    for (const z of W.hz) {
      const zt = z.t + t; if (z.t < rt || zt < z.T - 1 || zt >= z.T + z.A) continue;
      let d;
      if (z.k === 0) { const x = z.x + (zt > z.T ? z.vx * (zt - z.T) * DT : 0); const dx = Math.max(x - cx, 0, cx - x - z.w), dy = Math.max(z.y - cy, 0, cy - z.y - z.h); d = Math.hypot(dx, dy) - PRAD; }
      else if (z.k === 1) d = Math.hypot(cx - z.x, cy - z.y) - z.w - PRAD;
      else { const an = z.an + (zt > z.T ? z.av * (zt - z.T) : 0), ca = Math.cos(an), sa = Math.sin(an), u = clamp((cx - z.x) * ca + (cy - z.y) * sa, 0, z.w); d = Math.hypot(cx - (z.x + ca * u), cy - (z.y + sa * u)) - z.wd / 2 - PRAD; }
      if (z.nd) d += 4; if (d < c) c = d;
    }
    for (const m of W.mn) { if (m.bp || m.t < rt) continue; const d = Math.hypot(m.x + m.vx * t - cx, m.y + m.vy * t - cy) - m.r - PRAD; if (d < c) c = d; }
    if (B.st === 'pat' || B.st === 'idle') {
      if (B.cr > 0) { const d = Math.hypot(B.x + (B.x - B.px) * t - cx, B.y + (B.y - B.py) * t - cy) - B.cr - PRAD; if (d < c) c = d; }
      for (let j = 0; j < B.parts.length; j += 3) { const d = Math.hypot(B.parts[j] - cx, B.parts[j + 1] - cy) - B.parts[j + 2] - PRAD; if (d < c) c = d; }
    }
    return c;
  }
  const CAND_G = [[0, 0, 0], [-1, 0, 0], [1, 0, 0], [0, 0, 1], [-1, 0, 1], [1, 0, 1], [-1, 0, 2], [1, 0, 2], [0, 1, 0], [-1, 0, 3], [1, 0, 3], [-1, 0, 4], [1, 0, 4], [-1, 0, 5], [1, 0, 5]];
  const CAND_F = []; for (let a = 0; a < 9; a++) { const mx = (a % 3) - 1, my = Math.floor(a / 3) - 1; CAND_F.push([mx, my, 0]); if (mx || my) CAND_F.push([mx, my, 2]); }
  function botInput(W, p) {
    const A = p.A || (p.A = botInit(W, p)), lv = p.lv || 2, B = W.B, i = { mx: A.mx, my: A.my, jump: A.jh > 0 ? 1 : 0, fire: 1 };
    if (A.jh > 0) A.jh--;
    /* 한눈팔기: 가끔 잠깐 판단을 멈춤(난이도가 낮을수록 잦음) — 탄이 촘촘한 파수일수록 이때 맞음 */
    if (A.lz > 0) { A.lz--; return i; }
    const Hn = [0, 16, 30, 46][lv], Rp = [0, 10, 6, 3][lv];
    /* 받아치기: 청록빛을 보면 받을지 한 번 정함(버릇 × 난이도) */
    const pp = [0, 0.2, 0.7, 0.97][lv] * A.parry, R = PARRY_R * (p.ch === 'reach' ? 1.4 : 1), cx = p.x, cy = p.y - 15;
    const consider = (o, la) => {
      if (o.bp == null) o.bp = A.R() < pp ? 1 : 0;
      if (!o.bp) return;
      if (Math.hypot(o.x + o.vx * la - cx, o.y + o.vy * la - cy) < R + o.r - 5) { if (p.pcd <= 0 && p.par <= 0) i.parE = 1; else if (p.par <= 2) o.bp = 0; }
    };
    for (const b of W.bl) if (b.k === 1) consider(b, 2 * DT);
    for (const m of W.mn) if (m.par) consider(m, 2);
    let soul = null; for (const q of W.P) if (q !== p && q.down && q.sy > 20) soul = q;
    if (soul && Math.hypot(soul.sx - cx, soul.sy - cy) < R + 10 && p.pcd <= 0) i.parE = 1;
    /* 필살 · 무기 */
    if (p.ga >= D.HERO.gauge && (B.st === 'pat' || B.st === 'idle')) { if (--A.spT <= 0 || lv === 3) { i.spE = 1; A.spT = 30 + A.R() * 120; } }
    const w0 = D.WEAPONS[p.w[p.wi]], w1 = D.WEAPONS[p.w[p.wi ^ 1]], bd = Math.hypot(B.x + B.hx - cx, B.y + B.hy - cy) - B.hr;
    const fit = (w) => (w.rng ? (bd <= w.rng - 8 ? D.dps(w) : 0) : D.dps(w) * (w.id === 'lob' && Math.abs(B.x - B.px) > 2 ? 0.4 : 1));
    if (W.t % 20 === p.s * 7 && fit(w1) > fit(w0) * 1.15) i.swE = 1;
    /* 길 찾기 */
    if (--A.t > 0) return i;
    A.t = Rp; if (A.R() < [0, 0.08, 0.04, 0.016][lv]) { A.lz = [0, 16, 14, 12][lv] + Math.floor(A.R() * [0, 22, 18, 14][lv]); return i; }
    const cands = W.fly ? CAND_F : CAND_G, wr = Math.max(w0.rng || 0, w1.rng || 0), want = w0.rng ? Math.max(30, w0.rng - 40) : A.dist;
    /* 바닥이 곧 위험해지는지(넓은 바닥 예고 · 밟을 수 없는 바닥) → 발판을 찾아감 */
    let fb = !W.fly && W.fk ? 1 : 0; if (!W.fly && !fb) for (const z of W.hz) if (z.k === 0 && z.w >= 400 && z.y >= GY - 80 && z.y + z.h >= GY - 2) fb = 1;
    let gx = B.x + (p.x < B.x ? -1 : 1) * (want + B.hr); if (gx < 50 || gx > 590) { const o = 2 * B.x - gx; gx = o >= 50 && o <= 590 ? o : clamp(gx, 50, 590); }
    let best = null, bs = -1e9; const plx = W.pl.map((o) => o.x), mov = W.pl.some((o) => o.vx);
    for (const c of cands) {
      if (c[2] === 2 && (p.dcd > 0 || (!W.fly && !p.g && p.ad >= 1))) continue;
      if (c[1] === 1 && !W.fly && !(p.g && p.on >= 0)) continue;
      if (c[2] === 1 && !W.fly && !(p.g || p.coy > 0 || (p.ch === 'air' && p.aj < 1))) continue;
      const q = { x: p.x, y: p.y, px: p.px, py: p.py, vx: p.vx, vy: p.vy, f: p.f, g: p.g, on: p.on, dash: p.dash, di: p.di, dcd: p.dcd, dd: p.dd, ddy: p.ddy, ad: p.ad, aj: p.aj, drop: p.drop, jb: p.jb, coy: p.coy, ch: p.ch, an: 0, fkh: 0 };
      let sc = 0, minc = 99, fk = 0; const jt = c[2] === 1 ? 1 : c[2] === 3 ? 8 : c[2] === 4 ? 18 : c[2] === 5 ? 28 : 0;
      for (let t = 1; t <= Hn; t++) {
        if (mov && t > 1) for (const o of W.pl) { o.x += o.vx * DT; if (o.wr && o.x + o.w < -12) o.x += o.wr; }
        phys(W, q, { mx: c[0], my: c[1], jump: (jt && t >= jt && t < jt + 14) || t <= A.jh ? 1 : 0, jumpE: t === jt ? 1 : 0, dashE: c[2] === 2 && t === 1 ? 1 : 0 });
        if (q.fkh) { q.fkh = 0; if (!fk) { fk = 1; sc -= 700 - t * 6; } }
        const d = danger(W, q, t, p.inv, A.rt); if (d < minc) minc = d;
        if (d < 1) { sc -= 1000 - t * 9; break; }
      }
      if (mov) for (let j = 0; j < W.pl.length; j++) W.pl[j].x = plx[j];
      sc -= Math.max(0, 12 - minc) * 0.8;
      /* 자리: 무기 거리(바닥 무대는 가로 거리), 가장자리 · 파수 몸 피하기, 쓰러진 동료 쪽 */
      const tx = soul ? soul.sx : null, hd = W.fly ? Math.hypot(B.x + B.hx - q.x, B.y + B.hy - (q.y - 15)) - B.hr : Math.abs(B.x - q.x) - B.hr;
      if (tx != null) sc -= Math.abs(tx - q.x) * 0.05 + (soul.sy < cy - 30 && c[2] !== 1 ? 0.5 : 0);
      else if (fb) { let dp = 1e9; for (const o of W.pl) if (!o.off && !o.t) { const d = Math.max(o.x + 12 - q.x, 0, q.x - o.x - o.w + 12) + (q.y - o.y > 78 ? 90 : Math.abs(o.y - q.y) * 0.3); if (d < dp) dp = d; } sc -= q.on >= 0 && q.g ? 0 : 5 + dp * 0.07; }
      else if (W.fly) sc -= Math.abs(hd - want) * 0.012;
      else sc -= Math.abs(q.x - gx) * (wr ? 0.03 : 0.012);
      if (q.x < 40 || q.x > 600) sc -= 1.5;
      if (W.fk && !W.fly && q.on < 0 && q.g) sc -= 3;
      if (c[2] === 1 || c[2] > 2) sc -= 0.9 - A.jmp * 0.5; if (c[2] === 2) sc -= 1.3 + A.jmp * 0.4; if (c[1] === 1 && !W.fly) sc -= 0.6;
      if (c[0] === A.mx && c[1] === A.my && !c[2]) sc += 0.35;
      sc += A.R() * [0, 2.5, 0.6, 0.1][lv];
      if (sc > bs) { bs = sc; best = c; }
    }
    if (best) { A.mx = best[0]; A.my = best[1]; i.mx = A.mx; i.my = A.my; if (best[2] === 1) { i.jumpE = 1; i.jump = 1; A.jh = 14; A.t = Math.max(A.t, 3); } if (best[2] === 2) { i.dashE = 1; A.t = Math.max(A.t, 6); } }
    return i;
  }

  Object.assign(S, { DT, AW, AH, GY, PRAD, PARRY_R, BOSS, makeWorld, setPhase, worldStep, guestStep, botInput, packHost, applyHost, packMe, phys, hzHit, danger, aimPoint });
  D.sim = S;
  if (typeof module === 'object' && module) module.exports = S;
})();
