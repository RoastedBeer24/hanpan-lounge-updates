/* 산탄 룰렛 — 3D 장면 (three.js r170, 하이퍼 레이스와 같은 파일). games/buckshot.js가 게임을 켤 때만 불러와요.
   BS_SCENE.create(host, {speed, motion, fx, colors}) → 장면 객체(아래 api). 모든 시간(ms)은 부르는 쪽이 이미 배속을 나눠서 줘요.
   좌표: 탁자 윗면 y=0, 가운데 (0,0,0). 나(이 화면) = 카메라 쪽(+z), 다른 사람은 먼 쪽(−z)에 왼쪽→오른쪽.
   모델·결 그림은 모두 코드로 직접 만듦(외부 파일 없음). */
(function () {
  'use strict';
  const THREE = window.THREE;
  if (!THREE) return;
  const V3 = THREE.Vector3, Q = THREE.Quaternion;
  const PI = Math.PI;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const ease = (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);
  const easeOut = (k) => 1 - Math.pow(1 - k, 3);

  /* ---------- 결 그림(캔버스) ---------- */
  function canvasTex(w, hgt, draw, rep) {
    const c = document.createElement('canvas'); c.width = w; c.height = hgt;
    draw(c.getContext('2d'), w, hgt);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep[0], rep[1]); }
    t.anisotropy = 4;
    return t;
  }
  function rnd(seed) { let s = seed >>> 0; return () => { s = (s + 0x6d2b79f5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function woodTex() {
    return canvasTex(512, 512, (g, w, h) => {
      const R = rnd(7);
      g.fillStyle = '#3a2618'; g.fillRect(0, 0, w, h);
      const planks = 5, ph = h / planks;
      for (let p = 0; p < planks; p++) {
        const base = 40 + R() * 22;
        g.fillStyle = 'hsl(24,' + (38 + R() * 12) + '%,' + (base * 0.42) + '%)';
        g.fillRect(0, p * ph, w, ph);
        for (let i = 0; i < 70; i++) {
          const y = p * ph + R() * ph;
          g.strokeStyle = 'rgba(' + (R() < 0.5 ? '20,10,4' : '120,80,50') + ',' + (0.05 + R() * 0.12) + ')';
          g.lineWidth = 0.6 + R() * 1.8;
          g.beginPath(); g.moveTo(0, y);
          for (let x = 0; x <= w; x += 32) g.lineTo(x, y + Math.sin(x * 0.01 + i) * 2.5 + (R() - 0.5) * 1.5);
          g.stroke();
        }
        g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(0, p * ph, w, 2);
      }
      // 얼룩·긁힘
      for (let i = 0; i < 14; i++) { const x = R() * w, y = R() * h, r = 10 + R() * 40; const gr = g.createRadialGradient(x, y, 1, x, y, r); gr.addColorStop(0, 'rgba(10,5,2,.35)'); gr.addColorStop(1, 'rgba(10,5,2,0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, 2 * r, 2 * r); }
      g.strokeStyle = 'rgba(200,170,130,.12)'; for (let i = 0; i < 40; i++) { g.lineWidth = 0.5 + R(); g.beginPath(); const x = R() * w, y = R() * h; g.moveTo(x, y); g.lineTo(x + (R() - 0.5) * 60, y + (R() - 0.5) * 20); g.stroke(); }
      // 탄 자국(둥근 그을음)
      for (let i = 0; i < 5; i++) { const x = R() * w, y = R() * h; g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.arc(x, y, 2 + R() * 3, 0, 7); g.fill(); }
    });
  }
  function concreteTex(seed, tint) {
    return canvasTex(256, 256, (g, w, h) => {
      const R = rnd(seed);
      g.fillStyle = tint; g.fillRect(0, 0, w, h);
      const id = g.getImageData(0, 0, w, h), d = id.data;
      for (let i = 0; i < d.length; i += 4) { const n = (R() - 0.5) * 26; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
      g.putImageData(id, 0, 0);
      for (let i = 0; i < 18; i++) { const x = R() * w, y = R() * h, r = 20 + R() * 60; const gr = g.createRadialGradient(x, y, 1, x, y, r); gr.addColorStop(0, 'rgba(0,0,0,.25)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, 2 * r, 2 * r); }
    }, [3, 3]);
  }
  function glowTex(inner, outer) {
    return canvasTex(128, 128, (g, w) => {
      const gr = g.createRadialGradient(w / 2, w / 2, 0, w / 2, w / 2, w / 2);
      gr.addColorStop(0, inner); gr.addColorStop(0.35, outer); gr.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = gr; g.fillRect(0, 0, w, w);
    });
  }
  function flashTex() {
    return canvasTex(128, 128, (g, w) => {
      g.translate(w / 2, w / 2);
      for (let i = 0; i < 9; i++) {
        g.rotate((PI * 2) / 9 + Math.sin(i) * 0.2);
        const gr = g.createLinearGradient(0, 0, w / 2, 0); gr.addColorStop(0, 'rgba(255,250,220,1)'); gr.addColorStop(0.4, 'rgba(255,170,60,.8)'); gr.addColorStop(1, 'rgba(255,90,20,0)');
        g.fillStyle = gr; g.beginPath(); g.moveTo(0, -6); g.lineTo(w / 2 * (0.7 + (i % 3) * 0.15), 0); g.lineTo(0, 6); g.fill();
      }
      const gr = g.createRadialGradient(0, 0, 0, 0, 0, w / 3); gr.addColorStop(0, 'rgba(255,255,240,1)'); gr.addColorStop(1, 'rgba(255,160,60,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(0, 0, w / 3, 0, 7); g.fill();
    });
  }

  /* ---------- 재질 ---------- */
  const M = {};
  function mats() {
    if (M.ok) return M;
    M.ok = true;
    M.metal = new THREE.MeshStandardMaterial({ color: 0x2a2c31, metalness: 0.85, roughness: 0.38 });
    M.metalDark = new THREE.MeshStandardMaterial({ color: 0x17181b, metalness: 0.8, roughness: 0.5 });
    M.gunWood = new THREE.MeshStandardMaterial({ color: 0x5a3720, metalness: 0.05, roughness: 0.55 });
    M.brass = new THREE.MeshStandardMaterial({ color: 0xc9a24a, metalness: 0.9, roughness: 0.3 });
    M.red = new THREE.MeshStandardMaterial({ color: 0xc62e22, roughness: 0.45, metalness: 0.1 });
    M.blue = new THREE.MeshStandardMaterial({ color: 0x2b62c8, roughness: 0.45, metalness: 0.1 });
    M.cloth = new THREE.MeshStandardMaterial({ color: 0x17141b, roughness: 0.95 });
    M.skin = new THREE.MeshStandardMaterial({ color: 0x241c1a, roughness: 0.8 });
    M.eye = new THREE.MeshBasicMaterial({ color: 0xfff1cc });
    M.white = new THREE.MeshStandardMaterial({ color: 0xe8e2d6, roughness: 0.7 });
    M.glass = new THREE.MeshStandardMaterial({ color: 0x9fd0ff, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.35 });
    M.green = new THREE.MeshBasicMaterial({ color: 0x57f28a });
    M.orange = new THREE.MeshBasicMaterial({ color: 0xff8a2a });
    M.can = new THREE.MeshStandardMaterial({ color: 0x1f7a6a, metalness: 0.7, roughness: 0.35 });
    M.pillR = new THREE.MeshStandardMaterial({ color: 0xb4352a, roughness: 0.4 });
    M.plastic = new THREE.MeshStandardMaterial({ color: 0x2b2d33, roughness: 0.6 });
    M.saw = new THREE.MeshStandardMaterial({ color: 0x9aa0a8, metalness: 0.9, roughness: 0.3 });
    M.handleR = new THREE.MeshStandardMaterial({ color: 0x8a1f18, roughness: 0.6 });
    return M;
  }
  const cyl = (rt, rb, hh, mat, seg) => new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, hh, seg || 16), mat);
  const box = (x, y, z, mat) => new THREE.Mesh(new THREE.BoxGeometry(x, y, z), mat);
  const sph = (r, mat, seg) => new THREE.Mesh(new THREE.SphereGeometry(r, seg || 16, seg ? seg - 4 : 12), mat);
  function limb(a, b, r, mat) {
    const d = new V3().subVectors(b, a), len = d.length();
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(r, Math.max(0.01, len - r * 2), 4, 10), mat);
    m.position.copy(a).addScaledVector(d, 0.5);
    m.quaternion.setFromUnitVectors(new V3(0, 1, 0), d.normalize());
    return m;
  }
  const shadowAll = (o, cast, recv) => o.traverse((m) => { if (m.isMesh) { m.castShadow = cast; m.receiveShadow = recv; } });

  /* ---------- 산탄총 (총구 = +z) ---------- */
  function makeGun() {
    mats();
    const g = new THREE.Group();
    const recv = box(0.075, 0.12, 0.3, M.metal); recv.position.set(0, 0, -0.1); g.add(recv);
    const port = box(0.01, 0.04, 0.08, M.metalDark); port.position.set(0.04, 0.02, -0.08); g.add(port);
    // 개머리(나무)
    const stock = new THREE.Group();
    const s1 = box(0.07, 0.11, 0.36, M.gunWood); s1.position.set(0, -0.03, -0.18); s1.rotation.x = -0.13; stock.add(s1);
    const s2 = box(0.072, 0.19, 0.05, M.gunWood); s2.position.set(0, -0.06, -0.36); stock.add(s2);
    const pad = box(0.074, 0.2, 0.02, M.metalDark); pad.position.set(0, -0.06, -0.39); stock.add(pad);
    stock.position.set(0, -0.005, -0.25); g.add(stock);
    // 방아쇠
    const guard = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.006, 6, 16, PI), M.metalDark); guard.rotation.set(0, PI / 2, PI); guard.position.set(0, -0.06, -0.12); g.add(guard);
    const trig = box(0.008, 0.035, 0.01, M.metalDark); trig.position.set(0, -0.07, -0.11); trig.rotation.x = 0.3; g.add(trig);
    // 총열(톱으로 자르면 짧아짐) — 그룹의 z 크기를 줄임
    const barrel = new THREE.Group(); barrel.position.set(0, 0.03, 0.05);
    const b = cyl(0.024, 0.024, 0.66, M.metal, 18); b.rotation.x = PI / 2; b.position.z = 0.33; barrel.add(b);
    const rib = box(0.012, 0.008, 0.66, M.metalDark); rib.position.set(0, 0.027, 0.33); barrel.add(rib);
    const bead = sph(0.006, M.brass, 8); bead.position.set(0, 0.034, 0.64); barrel.add(bead);
    const bore = cyl(0.016, 0.016, 0.01, new THREE.MeshBasicMaterial({ color: 0x000000 }), 14); bore.rotation.x = PI / 2; bore.position.z = 0.662; barrel.add(bore);
    g.add(barrel);
    const mag = cyl(0.019, 0.019, 0.5, M.metalDark, 14); mag.rotation.x = PI / 2; mag.position.set(0, -0.022, 0.3); g.add(mag);
    const cap = cyl(0.021, 0.021, 0.03, M.metal, 14); cap.rotation.x = PI / 2; cap.position.set(0, -0.022, 0.56); g.add(cap);
    // 펌프(앞 손잡이, 나무 + 홈)
    const pump = new THREE.Group(); pump.position.set(0, -0.022, 0.2);
    const pw = cyl(0.036, 0.036, 0.2, M.gunWood, 16); pw.rotation.x = PI / 2; pump.add(pw);
    for (let i = 0; i < 6; i++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.0365, 0.003, 4, 18), M.metalDark); r.position.z = -0.07 + i * 0.028; pump.add(r); }
    g.add(pump);
    // 총구 불꽃(빛 + 그림)
    const muzzle = new THREE.Object3D(); muzzle.position.set(0, 0.03, 0.71); g.add(muzzle);
    const fl = new THREE.Sprite(new THREE.SpriteMaterial({ map: flashTex(), color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0 }));
    fl.scale.set(0.5, 0.5, 1); muzzle.add(fl);
    const light = new THREE.PointLight(0xffaa55, 0, 6, 2); muzzle.add(light);
    shadowAll(g, true, false);
    return { g, pump, barrel, muzzle, fl, light, port };
  }

  /* ---------- 탄 ---------- */
  function makeShell(t) {
    mats();
    const g = new THREE.Group();
    const body = cyl(0.026, 0.026, 0.09, t === 'L' ? M.red : M.blue, 14); body.position.y = 0.06; g.add(body);
    const head = cyl(0.028, 0.028, 0.026, M.brass, 14); head.position.y = 0.013; g.add(head);
    const rim = cyl(0.03, 0.03, 0.005, M.brass, 14); rim.position.y = 0.0025; g.add(rim);
    shadowAll(g, true, false);
    return g;
  }

  /* ---------- 물건 소품(약 0.1) ---------- */
  function makeItem(c) {
    mats();
    const g = new THREE.Group();
    if (c === 'l') {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.04, 0.007, 8, 24), M.brass); ring.rotation.x = PI / 2; ring.position.y = 0.008; g.add(ring);
      const gl = cyl(0.037, 0.037, 0.004, M.glass, 20); gl.position.y = 0.008; g.add(gl);
      const hd = cyl(0.009, 0.009, 0.07, M.handleR, 8); hd.rotation.z = PI / 2; hd.position.set(0.075, 0.009, 0); g.add(hd);
    } else if (c === 'c') {
      for (let i = 0; i < 2; i++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.028, 0.006, 8, 20), M.saw); r.rotation.x = PI / 2; r.position.set(i ? 0.04 : -0.04, 0.007, 0); g.add(r); }
      const ch = box(0.03, 0.006, 0.008, M.saw); ch.position.y = 0.007; g.add(ch);
    } else if (c === 's') {
      const bl = box(0.13, 0.004, 0.03, M.saw); bl.position.set(0.02, 0.004, 0); g.add(bl);
      const fr = box(0.13, 0.01, 0.006, M.metalDark); fr.position.set(0.02, 0.006, -0.03); g.add(fr);
      const hd = box(0.04, 0.02, 0.05, M.handleR); hd.position.set(-0.06, 0.012, -0.012); g.add(hd);
    } else if (c === 'k') {
      const cn = cyl(0.026, 0.026, 0.09, M.can, 16); cn.position.y = 0.045; g.add(cn);
      const tp = cyl(0.022, 0.026, 0.006, M.saw, 16); tp.position.y = 0.093; g.add(tp);
    } else if (c === 'g') {
      const cg = cyl(0.006, 0.006, 0.08, M.white, 8); cg.rotation.z = PI / 2; cg.position.y = 0.006; g.add(cg);
      const tip = cyl(0.0062, 0.0062, 0.02, new THREE.MeshStandardMaterial({ color: 0xc08a4a, roughness: 0.8 }), 8); tip.rotation.z = PI / 2; tip.position.set(-0.05, 0.006, 0); g.add(tip);
      const em = sph(0.006, M.orange, 8); em.position.set(0.041, 0.006, 0); g.add(em);
    } else if (c === 'r') {
      const bd = box(0.045, 0.09, 0.022, M.plastic); bd.position.y = 0.045; g.add(bd);
      const sc = box(0.03, 0.02, 0.002, M.green); sc.position.set(0, 0.065, 0.012); g.add(sc);
      const an = cyl(0.003, 0.003, 0.06, M.metalDark, 6); an.position.set(0.014, 0.12, 0); g.add(an);
    } else if (c === 'f') {
      const bd = box(0.06, 0.03, 0.045, M.plastic); bd.position.y = 0.015; g.add(bd);
      const sw = cyl(0.005, 0.005, 0.03, M.saw, 6); sw.position.set(0.008, 0.04, 0); sw.rotation.z = 0.5; g.add(sw);
      const led = sph(0.006, M.orange, 8); led.position.set(-0.018, 0.031, 0.012); g.add(led);
    } else if (c === 'a') {
      const tb = cyl(0.012, 0.012, 0.08, M.glass, 10); tb.rotation.z = PI / 2; tb.position.y = 0.013; g.add(tb);
      const fluid = cyl(0.009, 0.009, 0.05, new THREE.MeshBasicMaterial({ color: 0xff4a6a }), 8); fluid.rotation.z = PI / 2; fluid.position.set(0.01, 0.013, 0); g.add(fluid);
      const nd = cyl(0.0015, 0.0015, 0.04, M.saw, 4); nd.rotation.z = PI / 2; nd.position.set(0.06, 0.013, 0); g.add(nd);
      const pl = cyl(0.004, 0.004, 0.04, M.white, 6); pl.rotation.z = PI / 2; pl.position.set(-0.055, 0.013, 0); g.add(pl);
    } else if (c === 'p') {
      const a = new THREE.Mesh(new THREE.CapsuleGeometry(0.012, 0.022, 4, 10), M.pillR); a.rotation.z = PI / 2; a.position.set(-0.01, 0.012, 0); g.add(a);
      const b = new THREE.Mesh(new THREE.CapsuleGeometry(0.0121, 0.018, 4, 10), M.white); b.rotation.z = PI / 2; b.position.set(0.016, 0.012, 0); g.add(b);
    }
    g.scale.setScalar(1.25);
    shadowAll(g, true, false);
    return g;
  }

  /* ---------- 사람(그림자 같은 실루엣) ---------- */
  function makeFigure(color) {
    mats();
    const root = new THREE.Group();
    const body = new THREE.Group(); body.position.y = -0.3; root.add(body);
    const torso = cyl(0.25, 0.2, 0.62, M.cloth, 18); torso.position.y = 0.31; torso.scale.z = 0.7; body.add(torso);
    const sh = sph(0.27, M.cloth, 18); sh.scale.set(1, 0.42, 0.62); sh.position.y = 0.58; body.add(sh);
    const neck = cyl(0.06, 0.07, 0.1, M.skin, 10); neck.position.y = 0.68; body.add(neck);
    const head = sph(0.15, M.skin, 20); head.scale.set(0.92, 1.08, 1); head.position.y = 0.84; body.add(head);
    const hood = sph(0.165, M.cloth, 18); hood.scale.set(1, 1.05, 1); hood.position.set(0, 0.87, -0.03); body.add(hood);
    const eyes = [];
    for (const s of [-1, 1]) {
      const e = sph(0.013, M.eye.clone(), 8); e.position.set(s * 0.05, 0.85, 0.135); body.add(e); eyes.push(e);
      const a = limb(new V3(s * 0.25, 0.56, 0.02), new V3(s * 0.29, 0.26, 0.24), 0.055, M.cloth); body.add(a);
      const f = limb(new V3(s * 0.29, 0.26, 0.24), new V3(s * 0.17, 0.32, 0.52), 0.048, M.cloth); body.add(f);
      const hd = sph(0.045, M.skin, 10); hd.scale.set(1, 0.7, 1.2); hd.position.set(s * 0.16, 0.32, 0.57); body.add(hd);
    }
    const rim = new THREE.PointLight(new THREE.Color(color), 2.2, 3.2, 1.6); rim.position.set(0, 0.95, -0.55); root.add(rim);
    const hit = new THREE.PointLight(0xff2a1a, 0, 2.5, 2); hit.position.set(0, 0.4, 0.4); root.add(hit);
    shadowAll(root, true, true);
    return { root, body, eyes, rim, hit, down: 0, downT: 0, jolt: 0 };
  }

  /* ======================= 장면 ======================= */
  function create(host, opt) {
    mats();
    const motion = () => { try { return opt.motion ? opt.motion() : true; } catch (e) { return true; } };
    const fx = () => { try { return opt.fx ? opt.fx() : 1; } catch (e) { return 1; } };
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    host.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x060508);
    scene.fog = new THREE.Fog(0x060508, 4.5, 10);
    const cam = new THREE.PerspectiveCamera(55, 1, 0.05, 40);
    const CAM = new V3(0, 1.95, 2.45), LOOK = new V3(0, 0.12, -0.42);

    // 방
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(20, 20), new THREE.MeshStandardMaterial({ map: concreteTex(3, '#2a2724'), roughness: 0.95, dithering: true }));
    floor.rotation.x = -PI / 2; floor.position.y = -0.95; floor.receiveShadow = true; scene.add(floor);
    const wallM = new THREE.MeshStandardMaterial({ map: concreteTex(11, '#2f2a28'), roughness: 1, dithering: true });
    const wall = new THREE.Mesh(new THREE.PlaneGeometry(14, 6), wallM); wall.position.set(0, 1.5, -3.6); wall.receiveShadow = true; scene.add(wall);
    for (const s of [-1, 1]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(10, 6), wallM); w.position.set(s * 4.2, 1.5, -0.5); w.rotation.y = -s * PI / 2; scene.add(w); }
    // 벽의 배관 몇 줄(분위기)
    for (let i = 0; i < 3; i++) { const p = cyl(0.05, 0.05, 14, M.metalDark, 10); p.rotation.z = PI / 2; p.position.set(0, 2.2 + i * 0.22, -3.5); scene.add(p); }

    // 탁자
    const TW = 2.6, TD = 2.05;
    const top = new THREE.Mesh(new THREE.BoxGeometry(TW, 0.07, TD), new THREE.MeshStandardMaterial({ map: woodTex(), roughness: 0.78, metalness: 0.02, dithering: true }));
    top.position.y = -0.035; top.receiveShadow = true; top.castShadow = true; scene.add(top);
    const trimM = new THREE.MeshStandardMaterial({ color: 0x2b2a2a, metalness: 0.7, roughness: 0.5 });
    for (const s of [-1, 1]) {
      const a = box(TW + 0.04, 0.08, 0.03, trimM); a.position.set(0, -0.035, s * (TD / 2 + 0.015)); scene.add(a);
      const b = box(0.03, 0.08, TD + 0.04, trimM); b.position.set(s * (TW / 2 + 0.015), -0.035, 0); scene.add(b);
    }
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const l = box(0.08, 0.9, 0.08, trimM); l.position.set(sx * (TW / 2 - 0.1), -0.5, sz * (TD / 2 - 0.1)); scene.add(l); }

    // 매달린 등 + 깜빡이는 빛
    const lamp = new THREE.Group(); lamp.position.set(0, 2.05, -0.25); scene.add(lamp);
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.4, 0.26, 24, 1, true), new THREE.MeshStandardMaterial({ color: 0x2d3a2c, metalness: 0.6, roughness: 0.5, side: THREE.DoubleSide }));
    lamp.add(shade);
    const bulbM = new THREE.MeshBasicMaterial({ color: 0xffe2a8 });
    const bulb = sph(0.06, bulbM, 12); bulb.position.y = -0.08; lamp.add(bulb);
    const cord = cyl(0.006, 0.006, 3, M.metalDark, 6); cord.position.y = 1.6; lamp.add(cord);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex('rgba(255,230,180,1)', 'rgba(255,190,110,.35)'), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.85 }));
    glow.scale.set(0.9, 0.9, 1); glow.position.y = -0.1; lamp.add(glow);
    const spot = new THREE.SpotLight(0xffd9a0, 36, 7, 0.86, 0.55, 1.6);
    spot.position.set(0, 1.95, -0.25); spot.target.position.set(0, 0, -0.1);
    spot.castShadow = true; spot.shadow.mapSize.set(1024, 1024); spot.shadow.bias = -0.0004; spot.shadow.normalBias = 0.012; spot.shadow.radius = 2.5; spot.shadow.camera.near = 0.5; spot.shadow.camera.far = 6;
    scene.add(spot, spot.target);
    const amb = new THREE.AmbientLight(0x6a6a88, 0.22); scene.add(amb);
    const hemi = new THREE.HemisphereLight(0x405070, 0x100804, 0.25); scene.add(hemi);
    const fill = new THREE.PointLight(0x8090c0, 1.2, 6, 2); fill.position.set(0, 1.6, 2.6); scene.add(fill);

    // 총
    const gun = makeGun(); scene.add(gun.g);
    const gp = { p: new V3(), q: new Q() }, rec = { kick: 0, pitch: 0 };
    let sawK = 0, sawT = 0;
    const dummy = new THREE.Object3D();
    function poseLook(pos, tgt, roll) { dummy.position.copy(pos); dummy.quaternion.identity(); dummy.lookAt(tgt); if (roll) dummy.rotateZ(roll); return { p: pos.clone(), q: dummy.quaternion.clone() }; }
    const REST = poseLook(new V3(-0.05, 0.038, 0.12), new V3(1, 0.038, -0.2), PI / 2);
    gp.p.copy(REST.p); gp.q.copy(REST.q);

    // 사람
    let cfg = { me: 0, order: [], n: 2, out: [], inv: [], colors: [], saw: 0, top: 110, bottom: 220 };
    const figs = {};           // seat → 그림자 사람
    const itemGroups = {};     // seat → {str, g}
    const seatX = (k, m) => (m === 1 ? 0 : m === 2 ? [-0.68, 0.68][k] : [-0.98, 0, 0.98][k]);
    function figPos(seat) {
      const k = cfg.order.indexOf(seat), m = cfg.order.length;
      if (k < 0) return null;
      const x = seatX(k, m);
      return new V3(x, 0, -1.3 + Math.abs(x) * 0.12);
    }
    const camTarget = () => new V3(cam.position.x, cam.position.y - 0.32, cam.position.z - 0.1);
    function aimPoint(seat) { if (seat === cfg.me) return camTarget(); const f = figPos(seat); return f ? new V3(f.x, 0.52, f.z) : new V3(0, 0.5, -1.3); }
    function holdPose(by, to) {
      if (by === cfg.me) {
        if (to === by) return poseLook(new V3(0.02, 1.02, 1.12), cam.position.clone().add(new V3(0, 0.02, 0)), 0);
        return poseLook(new V3(0.2, 0.62, 1.08), aimPoint(to), 0);
      }
      const f = figPos(by) || new V3(0, 0, -1.3);
      if (to === by) return poseLook(new V3(f.x * 0.9, 0.66, f.z + 0.6), new V3(f.x, 0.6, f.z), 0);
      return poseLook(new V3(f.x * 0.82 + 0.06, 0.42, f.z + 0.52), aimPoint(to), 0);
    }

    function syncFigures() {
      // 자리 수·색이 바뀌면 다시 만듦
      for (const k in figs) if (!cfg.order.includes(+k)) { scene.remove(figs[k].root); delete figs[k]; }
      cfg.order.forEach((seat) => {
        let f = figs[seat];
        const col = cfg.colors[seat] || '#888';
        if (!f || f.col !== col) { if (f) scene.remove(f.root); f = figs[seat] = makeFigure(col); f.col = col; scene.add(f.root); }
        const p = figPos(seat);
        f.root.position.copy(p); f.root.lookAt(0, 0, 1.4);
        f.downT = cfg.out[seat] ? 1 : 0;
      });
      // 다른 사람 물건(앞에 놓임)
      for (const k in itemGroups) if (!cfg.order.includes(+k)) { scene.remove(itemGroups[k].g); delete itemGroups[k]; }
      cfg.order.forEach((seat) => {
        const str = cfg.inv[seat] || '';
        let ig = itemGroups[seat];
        if (!ig) { ig = itemGroups[seat] = { str: '', g: new THREE.Group(), list: [] }; scene.add(ig.g); }
        const f = figPos(seat);
        ig.g.position.set(f.x, 0, f.z + 0.5); ig.g.lookAt(0, 0, 1.4);
        if (ig.str === str) return;
        const old = ig.str; ig.str = str;
        ig.g.clear(); ig.list = [];
        [...str].forEach((c, i) => {
          const m = makeItem(c);
          const row = i < 4 ? 0 : 1, col = i % 4;
          m.position.set((col - 1.5) * 0.13, 0, row * -0.12 + 0.02);
          m.rotation.y = ((i * 37) % 10 - 5) * 0.05;
          ig.g.add(m); ig.list.push(m);
          if (i >= old.length || old[i] !== c) { m.scale.multiplyScalar(0.01); const s0 = 1.25; tween(260, (k) => m.scale.setScalar(Math.max(0.01, s0 * easeOut(k)))); }
        });
      });
      sawT = cfg.saw ? 1 : 0;
    }

    /* ---------- 흔들림 · 시간 ---------- */
    const tws = [];
    const now = () => performance.now();
    function tween(dur, fn, done) { const t = { t0: now(), dur: Math.max(1, dur), fn, done }; tws.push(t); fn(0); return t; }
    let shakeA = 0;
    function shake(a) { if (!motion()) return; shakeA = Math.max(shakeA, a * fx()); }

    /* ---------- 떠다니는 것들(탄피·연기·불꽃) ---------- */
    const bits = [];   // {m, v, w(각속도), life, kind, rest}
    const smokeTex = glowTex('rgba(180,170,160,.55)', 'rgba(120,115,110,.2)');
    const sparkM = new THREE.MeshBasicMaterial({ color: 0xffc070 });
    function spawnSmoke(p, n) {
      if (!motion()) n = Math.min(n, 2);
      for (let i = 0; i < n; i++) {
        const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTex, transparent: true, depthWrite: false, opacity: 0.5 }));
        s.position.copy(p); s.scale.setScalar(0.1);
        scene.add(s);
        bits.push({ m: s, v: new V3((Math.random() - 0.5) * 0.3, 0.25 + Math.random() * 0.3, (Math.random() - 0.5) * 0.3), life: 1.6 + Math.random(), age: 0, kind: 'smoke' });
      }
    }
    function spawnSparks(p, n, dir) {
      for (let i = 0; i < n; i++) {
        const s = new THREE.Mesh(new THREE.SphereGeometry(0.006, 4, 3), sparkM);
        s.position.copy(p);
        scene.add(s);
        const v = new V3((Math.random() - 0.5) * 1.6, Math.random() * 1.2 + 0.3, (Math.random() - 0.5) * 1.6);
        if (dir) v.addScaledVector(dir, 1.5);
        bits.push({ m: s, v, life: 0.4 + Math.random() * 0.4, age: 0, kind: 'spark' });
      }
    }
    const spent = [];
    function ejectShell(t, strong) {
      const s = makeShell(t);
      gun.g.updateMatrixWorld(true);
      const p = gun.port.getWorldPosition(new V3());
      const q = gun.g.quaternion;
      const right = new V3(1, 0, 0).applyQuaternion(q), up = new V3(0, 1, 0).applyQuaternion(q);
      s.position.copy(p);
      s.scale.setScalar(1.35);
      scene.add(s);
      const v = right.multiplyScalar(1.4 + Math.random() * 0.5).addScaledVector(up, 0.9 + Math.random() * 0.4);
      v.y = Math.max(v.y, 1.2 * (strong ? 1.2 : 1));
      const b = { m: s, v, w: new V3((Math.random() - 0.5) * 18, (Math.random() - 0.5) * 10, (Math.random() - 0.5) * 18), life: 1e9, age: 0, kind: 'shell', rest: false };
      bits.push(b); spent.push(b);
      while (spent.length > 10) { const o = spent.shift(); o.life = 0; }
      return s;
    }
    function updBits(dt) {
      for (let i = bits.length - 1; i >= 0; i--) {
        const b = bits[i]; b.age += dt;
        if (b.age >= b.life) { scene.remove(b.m); if (b.m.material && b.m.material.map === smokeTex) b.m.material.dispose(); bits.splice(i, 1); continue; }
        if (b.kind === 'smoke') {
          b.m.position.addScaledVector(b.v, dt); b.v.multiplyScalar(0.98);
          const k = b.age / b.life; b.m.scale.setScalar(0.12 + k * 0.6); b.m.material.opacity = 0.45 * (1 - k);
        } else if (b.kind === 'spark') {
          b.v.y -= 6 * dt; b.m.position.addScaledVector(b.v, dt);
          if (b.m.position.y < 0.005) { b.m.position.y = 0.005; b.v.y *= -0.3; b.v.x *= 0.5; b.v.z *= 0.5; }
        } else if (b.kind === 'shell' && !b.rest) {
          b.v.y -= 9.8 * dt;
          b.m.position.addScaledVector(b.v, dt);
          b.m.rotation.x += b.w.x * dt; b.m.rotation.y += b.w.y * dt; b.m.rotation.z += b.w.z * dt;
          const onTable = Math.abs(b.m.position.x) < TW / 2 && Math.abs(b.m.position.z) < TD / 2;
          const fl = onTable ? 0.03 : -0.92;
          if (b.m.position.y < fl) {
            b.m.position.y = fl;
            if (Math.abs(b.v.y) < 0.6) {
              b.rest = true; b.m.rotation.x = PI / 2; b.m.rotation.y = 0;
            } else { b.v.y *= -0.35; b.v.x *= 0.55; b.v.z *= 0.55; b.w.multiplyScalar(0.5); }
          }
        }
      }
    }

    /* ---------- 장전 진열 ---------- */
    let showRow = [];
    function clearRow() { for (const s of showRow) scene.remove(s); showRow = []; }

    /* ---------- 크기 ---------- */
    let W = 1, H = 1;
    function resize() {
      W = Math.max(1, host.clientWidth); H = Math.max(1, host.clientHeight);
      renderer.setSize(W, H, false);
      const asp = W / H;
      const halfW = 1.5;   // 탁자 가운데에서 보이게 할 반너비
      const dist = CAM.distanceTo(LOOK);
      const band = Math.max(0.3, (H - cfg.top - cfg.bottom) / H);
      let vf = 2 * Math.atan(Math.tan(Math.atan(halfW / dist)) / asp) * 180 / PI;
      // 가로·PC: 위아래 UI 사이 공간에 탁자가 들어오게
      vf = Math.max(vf, 2 * Math.atan(1.05 / dist / band) * 180 / PI);
      cam.fov = clamp(vf, 38, 82);
      cam.aspect = asp;
      cam.position.copy(CAM); cam.lookAt(LOOK);
      const yc = (cfg.top + (H - cfg.bottom)) / 2;
      cam.setViewOffset(W, H, 0, Math.round(H / 2 - yc), W, H);
      cam.updateProjectionMatrix();
    }
    let ro = null;
    try { ro = new ResizeObserver(() => resize()); ro.observe(host); } catch (e) { window.addEventListener('resize', resize); }

    /* ---------- 그리기 ---------- */
    let raf = 0, last = now(), alive = true, t0 = now(), flickOff = 0, dipK = 0, slowAvg = 0.016, slowN = 0;
    const BULB_COL = new THREE.Color(0xffe2a8), EYE_COL = new THREE.Color(0xfff1cc);
    const base = { spot: spot.intensity };
    function frame() {
      if (!alive) return;
      raf = requestAnimationFrame(frame);
      const tn = now(), rawDt = (tn - last) / 1000, dt = Math.min(0.05, rawDt); last = tn;
      // 느린 기기: 해상도 → 그림자 순으로 낮춤
      //   불러오는 동안의 끊김(긴 프레임 한두 번)은 세지 않음 — 예전에는 그것만으로 해상도가 1배로 떨어져 화면이 계단졌음. 해상도는 한 단계씩.
      if (rawDt < 0.25) { slowAvg = slowAvg * 0.95 + rawDt * 0.05; if (++slowN > 150 && slowAvg > 0.045) { slowN = 0; slowAvg = 0.02; const pr0 = renderer.getPixelRatio(); if (pr0 > 1) { renderer.setPixelRatio(pr0 > 1.5 ? 1.5 : 1); resize(); } else if (renderer.shadowMap.enabled) { renderer.shadowMap.enabled = false; scene.traverse((o) => { if (o.material) o.material.needsUpdate = true; }); } } }
      for (let i = tws.length - 1; i >= 0; i--) { const t = tws[i]; const k = Math.min(1, (tn - t.t0) / t.dur); try { t.fn(k); } catch (e) { /* 무시 */ } if (k >= 1) { tws.splice(i, 1); if (t.done) try { t.done(); } catch (e) { /* 무시 */ } } }
      // 등 흔들림: 느리고 약하게. 가끔(또는 발사 · 쓰러짐 때) 어두워지는 것도 프레임마다 무작위로 튀지 않고 부드럽게 내려갔다 돌아옴
      //   (예전: 밝기 ×0.35~0.75를 프레임마다 새로 뽑아 0.06~0.4초 동안 번쩍임 → 눈이 아픔)
      const tt = (tn - t0) / 1000;
      let fl = 1;
      if (motion()) {
        fl = 0.97 + Math.sin(tt * 2.1) * 0.012 + Math.sin(tt * 3.7 + 1) * 0.008;
        if (flickOff > 0) flickOff -= dt;
        else if (Math.random() < dt * 0.05) flickOff = 0.12 + Math.random() * 0.15;
      } else flickOff = 0;
      dipK += ((flickOff > 0 ? 1 : 0) - dipK) * Math.min(1, dt * (flickOff > 0 ? 12 : 4.5));
      fl *= 1 - 0.26 * dipK;
      spot.intensity = base.spot * fl; bulbM.color.setScalar(0.6 + 0.4 * fl).multiply(BULB_COL); glow.material.opacity = 0.85 * fl;
      lamp.rotation.z = motion() ? Math.sin(tt * 0.7) * 0.025 : 0;
      // 총
      sawK += (sawT - sawK) * Math.min(1, dt * 8);
      gun.barrel.scale.z = 1 - 0.45 * sawK;
      gun.muzzle.position.z = 0.05 + 0.66 * (1 - 0.45 * sawK) + 0.01;
      const back = new V3(0, 0, -rec.kick).applyQuaternion(gp.q);
      gun.g.position.copy(gp.p).add(back);
      gun.g.quaternion.copy(gp.q);
      if (rec.pitch) gun.g.rotateX(-rec.pitch);
      // 사람
      for (const k in figs) {
        const f = figs[k];
        f.down += (f.downT - f.down) * Math.min(1, dt * 4);
        f.body.rotation.x = f.down * 0.95 - f.jolt;
        f.body.position.y = -0.3 - f.down * 0.12;
        f.jolt *= Math.pow(0.02, dt);
        const breath = motion() && !f.downT ? Math.sin(tt * 1.6 + +k) * 0.008 : 0;
        f.body.scale.y = 1 + breath;
        for (const e of f.eyes) e.material.color.setScalar(f.downT ? 0.05 : 0.95 - (motion() && Math.sin(tt * 0.9 + +k * 3) > 0.985 ? 0.9 : 0)).multiply(EYE_COL);
        f.rim.intensity = 2.2 * (1 - f.down * 0.7) * (0.7 + 0.3 * fl);
        f.hit.intensity *= Math.pow(0.01, dt);
      }
      updBits(dt);
      // 카메라
      cam.position.copy(CAM);
      if (motion()) { cam.position.x += Math.sin(tt * 0.31) * 0.012; cam.position.y += Math.sin(tt * 0.23) * 0.009; }
      // 흔들림: 프레임마다 무작위 자리로 튀지 않게 부드러운 떨림(약 6Hz)으로, 폭도 줄임
      if (shakeA > 0.001) { const sa = Math.min(1.2, shakeA) * 0.034; cam.position.x += Math.sin(tt * 39) * sa; cam.position.y += Math.cos(tt * 31) * sa * 0.8; shakeA *= Math.pow(0.004, dt); }
      cam.lookAt(LOOK);
      renderer.render(scene, cam);
    }

    /* ---------- 총 움직임 ---------- */
    let gunTw = null;
    function moveGun(pose, dur) {
      const p0 = gp.p.clone(), q0 = gp.q.clone();
      if (gunTw) { const i = tws.indexOf(gunTw); if (i >= 0) tws.splice(i, 1); }
      gunTw = tween(dur, (k) => { const e = ease(k); gp.p.lerpVectors(p0, pose.p, e); gp.q.slerpQuaternions(q0, pose.q, e); if (k < 1 && k > 0.05 && k < 0.95) gp.p.y += Math.sin(k * PI) * 0.12 * (pose === REST ? 1 : 0.4); });
    }
    let held = false;

    const api = {
      // 화면 눌러 고르기: 그 사람 그림의 화면 위치(host 기준 CSS px)와 대략의 반지름
      screenOf(seat) {
        const f = figs[seat]; if (!f || W <= 1) return null;
        const base = f.root.position;
        const pr = (y) => { const v = new V3(base.x, y, base.z).project(cam); return { x: (v.x + 1) / 2 * W, y: (1 - v.y) / 2 * H }; };
        const c = pr(0.28), hd = pr(0.62);
        return { x: c.x, y: (c.y + hd.y) / 2, r: Math.max(44, Math.abs(c.y - hd.y) * 1.25) };
      },
      setSeats(c) {
        const lay = c.top !== cfg.top || c.bottom !== cfg.bottom;
        cfg = Object.assign({}, cfg, c);
        syncFigures();
        if (lay || W === 1) resize();
      },
      aim(t) {
        if (t == null) { if (held === 'aim') { held = false; moveGun(REST, 320); } return; }
        held = 'aim';
        moveGun(holdPose(cfg.me, t), 300);
      },
      roundStart(d) {
        for (const b of spent) b.life = 0;
        spent.length = 0;
        sawT = 0;
        for (const k in figs) figs[k].downT = 0;
        if (motion()) flickOff = 0.4;
        held = false; moveGun(REST, d || 400);
      },
      showLoad(Ln, Bn, d) {
        clearRow();
        const n = Ln + Bn, sp = Math.min(0.13, 1.4 / Math.max(1, n));
        for (let i = 0; i < n; i++) {
          const s = makeShell(i < Ln ? 'L' : 'B');
          s.position.set((i - (n - 1) / 2) * sp, 0, 0.32);
          s.scale.setScalar(1.6);
          scene.add(s); showRow.push(s);
          const y0 = 0.35;
          s.position.y = y0;
          tween(Math.min(400, d * 0.3) + i * 30, (k) => { s.position.y = y0 * (1 - easeOut(k)); });
        }
      },
      loadIn(d) {
        const tgt = gun.port.getWorldPosition(new V3());
        showRow.forEach((s, i) => {
          const p0 = s.position.clone();
          tween(d * 0.6, (k) => {
            const kk = clamp(k * 1.4 - i * 0.05, 0, 1), e = ease(kk);
            s.position.lerpVectors(p0, tgt, e); s.position.y += Math.sin(e * PI) * 0.25;
            s.scale.setScalar(1.6 * (1 - e * 0.7));
          }, () => scene.remove(s));
        });
        const row = showRow; showRow = [];
        setTimeout(() => { for (const s of row) scene.remove(s); }, d + 50);
        // 펌프 한 번
        tween(d * 0.5, (k) => { gun.pump.position.z = 0.2 - Math.sin(k * PI) * 0.09; });
      },
      dealItems() { /* setSeats가 새 물건을 튀어나오게 함 */ },
      pickUp(by, to, d) {
        held = 'shot';
        moveGun(holdPose(by, to), d);
        if (to === cfg.me && by !== cfg.me) shake(0.15);
      },
      fire(live, saw, to, d) {
        const mz = gun.muzzle.getWorldPosition(new V3());
        if (live) {
          gun.fl.material.opacity = 1; gun.fl.scale.setScalar(saw ? 0.75 : 0.55); gun.fl.material.rotation = Math.random() * PI;
          gun.light.intensity = 18;
          tween(Math.max(60, d * 0.35), (k) => { gun.fl.material.opacity = 1 - k; gun.light.intensity = 18 * (1 - k); });
          rec.kick = saw ? 0.16 : 0.12; rec.pitch = saw ? 0.42 : 0.3;
          tween(Math.max(120, d), (k) => { const e = easeOut(k); rec.kick = (saw ? 0.16 : 0.12) * (1 - e); rec.pitch = (saw ? 0.42 : 0.3) * (1 - e); });
          spawnSmoke(mz, 5);
          spot.intensity *= 1.6; flickOff = 0.12;
          if (to === cfg.me) shake(1.1); else shake(0.45);
          const f = figs[to];
          if (f) { f.jolt = 0.45; f.hit.intensity = 7; }
        } else {
          rec.pitch = 0.04; tween(Math.max(80, d * 0.5), (k) => { rec.pitch = 0.04 * (1 - k); });
          if (to === cfg.me) shake(0.08);
        }
      },
      rack(sh, d) {
        tween(d, (k) => { gun.pump.position.z = 0.2 - Math.sin(k * PI) * 0.1; });
        setTimeout(() => { if (alive) ejectShell(sh, true); }, d * 0.4);
      },
      eject(sh, d) {
        // 들고 → 펌프 → 탄 튀어나옴 → 내려놓기
        moveGun(poseLook(new V3(0.0, 0.5, 0.15), new V3(1.2, 0.6, -0.4), 0), d * 0.35);
        setTimeout(() => {
          if (!alive) return;
          tween(d * 0.4, (k) => { gun.pump.position.z = 0.2 - Math.sin(k * PI) * 0.1; });
          setTimeout(() => { if (alive) ejectShell(sh, true); }, d * 0.15);
          setTimeout(() => { if (alive && held !== 'shot') moveGun(REST, d * 0.4); }, d * 0.45);
        }, d * 0.35);
      },
      putDown(d) { held = false; moveGun(REST, d); },
      useItem(by, c, d) {
        // 다른 사람: 그 사람 앞의 소품이 떠올라 빛나다 사라짐. 나: 화면 앞쪽에 잠깐 떠오름
        let m = null, from = null;
        const ig = itemGroups[by];
        if (ig) {
          const idx = ig.list.findIndex((x, i) => ig.str[i] === c);
          if (idx >= 0) { m = ig.list[idx]; from = m.getWorldPosition(new V3()); ig.g.remove(m); ig.list.splice(idx, 1); ig.str = ig.str.slice(0, idx) + ig.str.slice(idx + 1); }
        }
        if (!m) { m = makeItem(c); from = by === cfg.me ? new V3(0, 0.05, 0.8) : (figPos(by) ? figPos(by).add(new V3(0, 0.05, 0.5)) : new V3(0, 0.05, 0)); }
        m.position.copy(from); m.rotation.set(0, 0, 0);
        scene.add(m);
        const s0 = m.scale.x;
        const up = by === cfg.me ? new V3(0, 0.55, 0.65) : from.clone().add(new V3(0, 0.38, 0.25));
        tween(d, (k) => {
          const e = easeOut(Math.min(1, k * 1.6));
          m.position.lerpVectors(from, up, e);
          m.rotation.y = k * 4; m.rotation.x = Math.sin(k * PI) * 0.4;
          m.scale.setScalar(s0 * (1 + 1.2 * e) * (k > 0.75 ? 1 - (k - 0.75) * 4 : 1));
        }, () => scene.remove(m));
        if (c === 's') spawnSparks(gun.muzzle.getWorldPosition(new V3()), motion() ? 24 : 6);
        if (c === 'g') { const p = up.clone(); setTimeout(() => alive && spawnSmoke(p, 3), d * 0.5); }
        if (c === 'f' || c === 'r') { flickOff = 0.08; }
      },
      peek(sh, d) {
        // 내가 렌즈로 본 탄: 총 위에 잠깐 떠오름
        const s = makeShell(sh); s.scale.setScalar(2.2);
        const p = gun.port.getWorldPosition(new V3());
        s.position.copy(p); scene.add(s);
        const L = new THREE.PointLight(sh === 'L' ? 0xff3a2a : 0x3a7aff, 6, 1.6, 2); s.add(L);
        tween(d, (k) => { s.position.y = p.y + 0.12 + easeOut(Math.min(1, k * 2)) * 0.14; s.rotation.y = k * 3; s.scale.setScalar(2.2 * (k > 0.8 ? 1 - (k - 0.8) * 5 : 1)); }, () => scene.remove(s));
      },
      saw(on) { sawT = on ? 1 : 0; },
      down(p) { const f = figs[p]; if (f) { f.downT = 1; f.jolt = 0.3; f.hit.intensity = 5; } if (p === cfg.me) shake(0.6); flickOff = 0.25; },
      destroy() {
        alive = false; cancelAnimationFrame(raf);
        try { if (ro) ro.disconnect(); else window.removeEventListener('resize', resize); } catch (e) { /* 무시 */ }
        scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) { const ms = Array.isArray(o.material) ? o.material : [o.material]; for (const m of ms) { if (m.map) m.map.dispose(); m.dispose(); } } });
        renderer.dispose();
        try { renderer.forceContextLoss(); } catch (e) { /* 무시 */ }
        renderer.domElement.remove();
        M.ok = false; for (const k in M) if (k !== 'ok') delete M[k];
      },
    };
    resize();
    frame();
    return api;
  }

  window.BS_SCENE = { create };
})();
