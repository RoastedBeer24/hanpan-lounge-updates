/* 하이퍼 레이스 — 3D 화면 (three.js). games/hyperrace.js가 게임을 켤 때만 불러와요.
   HR_VIEW.mount(root, api, H, hooks) → { update(state, prev), destroy(), pause(), resume() } · HR_VIEW.showroom(canvas, H, carId) (도감)
   좌표: 시뮬(x, y) → three (x, 높이, −y). 차 모델은 +Z가 앞, +X가 왼쪽, 바퀴 노드 wheel_FL/FR/RL/RR(바퀴 중심). */
(function () {
  'use strict';
  const L = window.Lounge, THREE = window.THREE;
  const V = {};
  const PI = Math.PI;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;
  const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

  /* ======================= 파일 → 그림 · 모델 ======================= */
  function imageFrom(u8, type) {
    return new Promise((ok, no) => {
      const url = URL.createObjectURL(new Blob([u8], { type: type || 'image/webp' }));
      const im = new Image();
      im.onload = () => { ok(im); setTimeout(() => URL.revokeObjectURL(url), 1000); };
      im.onerror = () => { URL.revokeObjectURL(url); no(new Error('그림 풀기 실패')); };
      im.src = url;
    });
  }
  function texFrom(u8, o) {
    o = o || {};
    return imageFrom(u8).then((im) => {
      const t = new THREE.Texture(im);
      if (o.srgb) t.colorSpace = THREE.SRGBColorSpace;
      if (o.rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
      t.anisotropy = o.aniso || 4;
      t.needsUpdate = true;
      return t;
    });
  }
  let loader = null;
  function gltfFrom(u8) {
    if (!loader) { loader = new THREE.GLTFLoader(); loader.setMeshoptDecoder(THREE.MeshoptDecoder); }
    const buf = u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength);
    return new Promise((ok, no) => loader.parse(buf, '', ok, no));
  }
  function canvasTex(w, h, draw, o) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    if (o && o.rep) t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.anisotropy = 4;
    return t;
  }
  const radial = (stops) => (g, w, h) => { const r = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2); stops.forEach(([o, c]) => r.addColorStop(o, c)); g.fillStyle = r; g.fillRect(0, 0, w, h); };

  /* ======================= 차 모델 ======================= */
  const THUMBS = { url: {}, p: null };   // 고르기 화면 카드 그림(pk_thumbs, 한 번만 풂)
  const carTpl = {}, carTplDone = {};   // id+tier → Promise<{scene, tier, clean, roles}> · (settled) → the template
  /* 셰이더 종류 줄이기(첫 출발 때 프레임 급락의 원인 — 차 8대 · 보통에서 셰이더 135개, D3D에서 13초 걸려 첫 화면이 멈췄음):
     - 모든 단계: 투과(transmission — 장면을 한 번 더 그림) · 반사 세기/색 결 · 광택 천(sheen) · 무지개(iridescence) · 분산을 끔 → 유리는 반투명으로
     - 보통: 도색 말고는 MeshStandardMaterial로, 그늘 결(aoMap) · 코팅 결 뺌 / 낮음: 결은 색 · 빛 결만(노멀 · 거칠기 · 금속 결 뺌), 모두 Standard */
  const STD_KEYS = ['name', 'color', 'map', 'normalMap', 'normalMapType', 'normalScale', 'roughness', 'roughnessMap', 'metalness', 'metalnessMap', 'emissive', 'emissiveMap', 'emissiveIntensity',
    'alphaMap', 'transparent', 'opacity', 'alphaTest', 'side', 'depthWrite', 'envMapIntensity', 'vertexColors', 'flatShading', 'polygonOffset', 'polygonOffsetFactor', 'polygonOffsetUnits', 'blending', 'userData'];
  function simplifyMat(m, tier) {
    if (!m || !(m.isMeshStandardMaterial)) return m;
    const nm = m.name || '', paint = /^PAINT/.test(nm), light = /^L_(HEAD|TAIL)/.test(nm), glass = /^GLASS/.test(nm) || m.transmission > 0;
    if (m.isMeshPhysicalMaterial) {
      if (m.transmission > 0) { m.transparent = true; m.opacity = Math.min(m.opacity, 0.42 + 0.3 * (1 - m.transmission)); m.depthWrite = false; m.roughness = Math.min(m.roughness, 0.15); }
      m.transmission = 0; m.transmissionMap = null; m.thicknessMap = null; m.thickness = 0;
      m.specularIntensityMap = null; m.specularColorMap = null; m.sheen = 0; m.sheenColorMap = null; m.sheenRoughnessMap = null;
      if (!paint) m.iridescence = 0;
      m.iridescenceMap = null; m.iridescenceThicknessMap = null; m.dispersion = 0; m.anisotropy = 0; m.anisotropyMap = null;
      if (tier !== 'high') { m.clearcoatNormalMap = null; m.clearcoatRoughnessMap = null; m.clearcoatMap = null; }
    }
    if (tier !== 'high') { m.aoMap = null; m.lightMap = null; m.bumpMap = null; m.displacementMap = null; }
    if (tier === 'low' && !light) { m.normalMap = null; m.roughnessMap = null; m.metalnessMap = null; if (!paint) m.emissiveMap = null; }
    if (m.isMeshPhysicalMaterial && (tier === 'low' || (tier === 'mid' && !paint))) {
      const s = new THREE.MeshStandardMaterial();
      for (const k of STD_KEYS) { const v = m[k]; if (v === undefined) continue; if (v && v.isColor) s[k].copy(v); else if (v && v.isVector2) s[k].copy(v); else s[k] = v; }
      if (glass) s.depthWrite = m.depthWrite;
      return s;
    }
    m.needsUpdate = true;
    return m;
  }
  function loadCarTpl(H, id, tier) {
    const key = id + '_' + tier;
    if (!carTpl[key]) carTpl[key] = H.pack('car_' + key).then((p) => gltfFrom(p.m).then((g) => [g, p.clean])).then(([g, cleanU8]) => {
      const sc = g.scene, roles = {}, swap = new Map();
      let paintMap = null;
      sc.traverse((o) => {
        if (!o.isMesh || !o.material || Array.isArray(o.material)) return;
        if (!swap.has(o.material)) swap.set(o.material, simplifyMat(o.material, tier));
        o.material = swap.get(o.material);
      });
      sc.traverse((o) => {
        if (!o.isMesh) return;
        const m = o.material, nm = (m && m.name) || '';
        o.castShadow = tier !== 'low'; o.receiveShadow = false;
        // three.js reads uv … uv3 only: a map on a 5th UV set (some multilayer models) would break the shader → drop that map
        if (m) for (const k of Object.keys(m)) { const t = m[k]; if (t && t.isTexture && t.channel > 3) { m[k] = null; m.needsUpdate = true; } }
        if (/^GLASS/.test(nm)) { m.userData.role = 'glass'; if (tier !== 'high') { m.transparent = true; m.opacity = Math.max(m.opacity, 0.88); m.color.multiplyScalar(0.35); m.depthWrite = true; } }
        if (/^L_HEAD/.test(nm)) { if (m.map && !m.emissiveMap) m.emissiveMap = m.map; m.emissive = new THREE.Color(1, 0.97, 0.9); m.userData.role = 'head'; }
        if (/^L_TAIL/.test(nm)) { if (m.map && !m.emissiveMap) m.emissiveMap = m.map; m.emissive = new THREE.Color(1, 0.06, 0.03); m.userData.role = 'tail'; }
        if (/^PAINT/.test(nm)) { m.userData.role = 'paint'; if (m.map && !paintMap) paintMap = m.map; }
        if (/^RIM/.test(nm)) m.userData.role = 'rim';
        if (/^CALIPER/.test(nm)) m.userData.role = 'caliper';
        if (/^BRAND_/.test(nm)) o.userData.brand = /Banner|BANNER/.test(nm) ? 'plain' : 'hide';
        if (/^LOGO_/.test(nm)) o.userData.logo = 1;
        if (m.userData.role) roles[m.userData.role] = 1;
        if (m && m.envMapIntensity != null) m.envMapIntensity = 1.15;
      });
      sc.traverse((o) => { if (/^brand_geo/.test(o.name)) o.traverse((q) => { if (q.isMesh) q.userData.brand = 'hide'; }); });
      // paint meshes: bake car-space position / normal (stored positions are quantized and node-scaled) for the pattern shader
      sc.updateMatrixWorld(true);
      sc.traverse((o) => {
        if (!o.isMesh || !o.material || o.material.userData.role !== 'paint' || o.geometry.getAttribute('aCP')) return;
        const g = o.geometry, P0 = g.getAttribute('position'), N0 = g.getAttribute('normal'), n = P0.count, cp = new Float32Array(n * 3), cn = new Float32Array(n * 3), v = new THREE.Vector3();
        const nm = new THREE.Matrix3().getNormalMatrix(o.matrixWorld);
        for (let i = 0; i < n; i++) {
          v.fromBufferAttribute(P0, i).applyMatrix4(o.matrixWorld); cp[i * 3] = v.x; cp[i * 3 + 1] = v.y; cp[i * 3 + 2] = v.z;
          if (N0) { v.fromBufferAttribute(N0, i).applyMatrix3(nm).normalize(); cn[i * 3] = v.x; cn[i * 3 + 1] = v.y; cn[i * 3 + 2] = v.z; } else cn[i * 3 + 1] = 1;
        }
        g.setAttribute('aCP', new THREE.BufferAttribute(cp, 3));
        g.setAttribute('aCN', new THREE.BufferAttribute(cn, 3));
      });
      // the sponsor-free livery (GT): same UV as the painted map
      const clean = cleanU8 && paintMap ? texFrom(cleanU8, { srgb: true, aniso: 8 }).then((t) => { t.flipY = false; t.wrapS = paintMap.wrapS; t.wrapT = paintMap.wrapT; t.channel = paintMap.channel; t.needsUpdate = true; return t; }).catch(() => null) : Promise.resolve(null);
      return clean.then((cleanTex) => (carTplDone[key] = { scene: sc, tier, clean: cleanTex, roles }));
    });
    return carTpl[key];
  }
  /* ======================= 꾸미기 (cust, docs/HYPERRACE.md 「꾸미기」) =======================
     무늬 · 스티커 · 투톤 · 경주 번호는 캔버스 한 장(아틀라스)에 미리 구워 결로 씀 — 바뀔 때만 다시 그림(매 프레임 계산 없음, 셰이더는 결 3번 읽기).
     아틀라스(정사각 W, 위에서부터 ¼씩): 오른쪽 옆 · 왼쪽 옆(거울) · 위 · 앞(왼쪽 반) / 뒤(오른쪽 반).
     면마다 그리는 좌표(미터, 차 모델 좌표 +Z 앞 · +X 왼쪽 · Y 위): 옆 x = 뒤끝에서 앞으로 · y = 위에서 아래로(왼쪽 옆은 거울 — 글자 · 스티커는 바로 보이게 되뒤집음)
     · 위 x = 뒤 → 앞 · y = 왼쪽(+X) → 오른쪽 · 앞 x = 오른쪽(-X) → 왼쪽 · 뒤 x = 왼쪽 → 오른쪽(둘 다 보는 사람 기준 왼 → 오).
     미터로 그려서 결이 차에 다시 붙을 때 비율이 맞아 원은 원, 글자는 바르게. 차마다 UV가 달라도 다 맞음. */
  const STK = [['ZORVEX', '번개오일'], ['KAIRON', '하늘타이어'], ['QUANTA', '불새 레이싱'], ['TRAXON', 'MOXLY'], ['VELTRO', '흑룡 연료']];   // 지어낸 이름(실제 상표 아님)
  const hexRgb = (hx) => { const v = parseInt(String(hx || '#ffffff').slice(1), 16) || 0; return [v >> 16, (v >> 8) & 255, v & 255]; };
  const shade = (hx, k, a) => { const c = hexRgb(hx).map((v) => Math.round(k >= 0 ? v + (255 - v) * k : v * (1 + k))); return 'rgba(' + c.join(',') + ',' + (a == null ? 1 : a) + ')'; };
  const lumOf = (hx) => { const c = hexRgb(hx); return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) / 255; };
  const hexHsv = (hx) => { const [r, g, b] = hexRgb(hx).map((v) => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let hh = 0; if (d) hh = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; hh = ((hh * 60) + 360) % 360; return [hh, mx ? d / mx : 0, mx]; };
  const hsvHex = ([hh, sa, va]) => { const f = (n) => { const k = (n + hh / 60) % 6; return va - va * sa * Math.max(0, Math.min(k, 4 - k, 1)); }; return '#' + [f(5), f(3), f(1)].map((v) => Math.round(v * 255).toString(16).padStart(2, '0')).join(''); };
  const contra = (hx) => (lumOf(hx) > 0.55 ? '#111111' : '#f4f4f0');
  const hash2 = (x, y, s) => { let h = (x * 374761393 + y * 668265263 + s * 2147483647) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  const FONT = 'bold 100px "Arial Black","Segoe UI",sans-serif';
  // 글꼴(글자 스티커 · 번호): 이미 앱이 불러 둔 OFL 글꼴(Black Han Sans · IBM Plex Sans KR · IBM Plex Mono) + 기기 글꼴
  const FONTS = [FONT, '100px "Black Han Sans","Arial Black",sans-serif', '700 100px "IBM Plex Sans KR","Malgun Gothic",sans-serif', '600 100px "IBM Plex Mono",ui-monospace,monospace',
    'bold 100px Georgia,"Batang","Times New Roman",serif', 'italic bold 100px "Arial Black","Segoe UI",sans-serif'];
  const D_SHP = 50, D_TXT = 70, D_LOGO = 71, D_SHP2 = 100, D_BRUSH = 120, isDecT = (t) => t >= D_SHP;   // = CUST.SHP0 · TXT_T · LOGO0 · SHP2 · BRUSH_T
  const xOf = (l) => { const q = l && l.length > 1 && l[l.length - 1]; return q && typeof q === 'object' && !Array.isArray(q) ? q : {}; };   // 겹 덧붙임(v4)
  // 로고 꼴: [바탕(0 없음 · 1 평행사변형 · 2 둥근 네모 · 3 타원 · 4 테두리 알약 · 5 표 모양), 아이콘, 기울임]
  const LOGO_ST = [[1, '', 1], [2, 'bolt', 0], [0, 'swoosh', 1], [3, '', 0], [0, 'q', 0], [2, 'flame', 1], [0, 'hex', 0], [4, '', 0], [1, 'v', 1], [5, '', 0],
    [2, 'star', 1], [5, 'wing', 0], [4, 'wing', 1], [3, 'drop', 0], [1, 'ring', 1]];
  const LOGO_NM = ['ZORVEX', '번개오일', 'KAIRON', '하늘타이어', 'QUANTA', '불새 레이싱', 'TRAXON', 'MOXLY', 'VELTRO', '흑룡 연료', 'NOVARC', '철마 엔진', 'KESTRIX', '은하 윤활유', 'ZYPHOR'];
  const B64C = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  /* 손그림 점 글자 → 획 목록 [[x, y]…](단위 −0.5~0.5) */
  const brushPts = (p) => String(p || '').split('.').map((s) => { const o = []; for (let i = 0; i + 1 < s.length; i += 2) o.push([B64C.indexOf(s[i]) / 63 - 0.5, B64C.indexOf(s[i + 1]) / 63 - 0.5]); return o; }).filter((s) => s.length);
  /* 스티커 하나를 단위 크기(높이 1, 가운데 0,0)로 그림 → 너비. dry = 너비만 · X = 덧붙임(글꼴 · 손그림) */
  function decShape(g, t, c, c2, tx, dry, X) {
    X = X || {};
    const P = (pts) => { g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath(); };
    const paint = (lw) => { if (c2) { g.lineJoin = 'round'; g.lineWidth = lw || 0.12; g.strokeStyle = c2; g.stroke(); } g.fillStyle = c; g.fill(); };
    const paintEO = (lw) => { if (c2) { g.lineJoin = 'round'; g.lineWidth = lw || 0.08; g.strokeStyle = c2; g.stroke(); } g.fillStyle = c; g.fill('evenodd'); };
    const ring = (r1, r0) => { g.beginPath(); g.arc(0, 0, r1, 0, 7); g.moveTo(r0, 0); g.arc(0, 0, r0, 0, 7, true); };
    const fnt = t === D_TXT ? FONTS[X.o | 0] || FONT : FONT;
    const textW = (s, th) => { g.save(); g.font = fnt; const w = g.measureText(s).width * th / 100; g.restore(); return w; };
    const text = (s, x, y, th, col, stroke, sk) => { g.save(); g.translate(x, y); if (sk) g.transform(1, 0, -0.22, 1, 0, 0); g.scale(th / 100, th / 100); g.font = fnt; g.textAlign = 'center'; g.textBaseline = 'middle';
      if (stroke) { g.lineJoin = 'round'; g.lineWidth = 18; g.strokeStyle = stroke; g.strokeText(s, 0, 4); } g.fillStyle = col; g.fillText(s, 0, 4); g.restore(); };
    const rr = (x, y, w, h, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
    if (t === D_TXT) { const w = textW(tx || 'A', 1); if (!dry) text(tx, 0, 0, 1, c, c2 || null); return w; }
    if (t === D_BRUSH) {   // freehand strokes (round, smoothed through midpoints) — the box is 1 × 1
      if (dry) return 1;
      const S = brushPts(X.p), lw = clamp((X.b || 8) / 100, 0.01, 1);
      g.lineCap = 'round'; g.lineJoin = 'round';
      const path = (s) => { g.beginPath(); g.moveTo(s[0][0], s[0][1]); if (s.length === 1) g.lineTo(s[0][0] + 0.001, s[0][1]);
        for (let i = 1; i < s.length - 1; i++) g.quadraticCurveTo(s[i][0], s[i][1], (s[i][0] + s[i + 1][0]) / 2, (s[i][1] + s[i + 1][1]) / 2); if (s.length > 1) g.lineTo(s[s.length - 1][0], s[s.length - 1][1]); };
      if (c2) for (const s of S) { path(s); g.lineWidth = lw + 0.05; g.strokeStyle = c2; g.stroke(); }
      for (const s of S) { path(s); g.lineWidth = lw; g.strokeStyle = c; g.stroke(); }
      return 1;
    }
    if (t >= D_SHP2) return decShape2(g, t - D_SHP2, c, c2, dry, P, paint, paintEO, ring, rr);
    if (t >= D_LOGO) {
      const k = t - D_LOGO, [bg, ic, sk] = LOGO_ST[k] || LOGO_ST[0], s = LOGO_NM[k] || 'ZORVEX', th = 0.52, tw = textW(s, th), iw = ic && ic !== 'swoosh' ? 0.78 : 0;
      const W = tw + iw + (bg ? 0.55 : 0.1) + (bg === 3 ? 0.4 : 0), tc = bg && bg !== 4 ? (c2 || contra(c)) : c, ac = bg && bg !== 4 ? tc : (c2 || c);
      if (dry) return W + (bg === 1 ? 0.4 : 0);
      if (bg === 1) { P([[-W / 2 + 0.2, -0.5], [W / 2 + 0.2, -0.5], [W / 2 - 0.2, 0.5], [-W / 2 - 0.2, 0.5]]); g.fillStyle = c; g.fill(); }
      else if (bg === 2) { rr(-W / 2, -0.5, W, 1, 0.2); g.fillStyle = c; g.fill(); }
      else if (bg === 3) { g.beginPath(); g.ellipse(0, 0, W / 2, 0.5, 0, 0, 7); g.fillStyle = c; g.fill(); }
      else if (bg === 4) { rr(-W / 2 + 0.05, -0.45, W - 0.1, 0.9, 0.45); g.lineWidth = 0.09; g.strokeStyle = c; g.stroke(); }
      else if (bg === 5) { g.beginPath(); g.moveTo(-W / 2, -0.5); g.lineTo(W / 2, -0.5); g.arc(W / 2, 0, 0.2, -PI / 2, PI / 2, true); g.lineTo(-W / 2, 0.5); g.arc(-W / 2, 0, 0.2, PI / 2, -PI / 2, true); g.closePath(); g.fillStyle = c; g.fill(); }
      const ix = -W / 2 + (bg ? 0.28 : 0.05) + iw / 2 - 0.05, tx0 = iw ? ix + iw / 2 + tw / 2 + 0.02 : 0;
      g.save(); g.translate(ix, 0); g.scale(0.7, 0.7);
      if (ic === 'bolt') { P([[0.12, -0.5], [-0.3, 0.06], [-0.02, 0.06], [-0.14, 0.5], [0.3, -0.1], [0.02, -0.1], [0.18, -0.5]]); g.fillStyle = ac; g.fill(); }
      else if (ic === 'q') { ring(0.5, 0.32); g.fillStyle = ac; g.fill('evenodd'); P([[0.12, 0.18], [0.3, 0.1], [0.56, 0.52], [0.38, 0.6]]); g.fill(); }
      else if (ic === 'flame') { g.beginPath(); g.moveTo(0, 0.5); g.bezierCurveTo(-0.4, 0.45, -0.45, 0.05, -0.15, -0.5); g.quadraticCurveTo(-0.05, -0.1, 0.12, -0.3); g.quadraticCurveTo(0.5, 0.1, 0, 0.5); g.fillStyle = ac; g.fill(); }
      else if (ic === 'hex') { g.beginPath(); for (let i = 0; i < 6; i++) { const a = -PI / 2 + i * PI / 3; g.lineTo(Math.cos(a) * 0.5, Math.sin(a) * 0.5); } g.closePath(); g.lineWidth = 0.14; g.strokeStyle = ac; g.stroke(); }
      else if (ic === 'v') { P([[-0.45, -0.45], [-0.18, -0.45], [0, 0.1], [0.18, -0.45], [0.45, -0.45], [0.1, 0.5], [-0.1, 0.5]]); g.fillStyle = ac; g.fill(); }
      else if (ic === 'star') { const pt = []; for (let i = 0; i < 10; i++) { const a = -PI / 2 + i * PI / 5, r = i % 2 ? 0.22 : 0.54; pt.push([Math.cos(a) * r, Math.sin(a) * r + 0.04]); } P(pt); g.fillStyle = ac; g.fill(); }
      else if (ic === 'wing') { g.fillStyle = ac; for (let i = 0; i < 3; i++) { const y = -0.42 + i * 0.3, x0 = -0.5 + i * 0.12; P([[x0, y], [0.5, y], [0.36, y + 0.2], [x0 + 0.14, y + 0.2]]); g.fill(); } }
      else if (ic === 'drop') { g.beginPath(); g.moveTo(0, -0.55); g.bezierCurveTo(0.1, -0.3, 0.4, -0.05, 0.4, 0.15); g.bezierCurveTo(0.4, 0.4, 0.2, 0.52, 0, 0.52); g.bezierCurveTo(-0.2, 0.52, -0.4, 0.4, -0.4, 0.15); g.bezierCurveTo(-0.4, -0.05, -0.1, -0.3, 0, -0.55); g.closePath(); g.fillStyle = ac; g.fill(); }
      else if (ic === 'ring') { ring(0.5, 0.3); g.fillStyle = ac; g.fill('evenodd'); g.beginPath(); g.arc(0, 0, 0.13, 0, 7); g.fill(); }
      g.restore();
      text(s, tx0, bg ? 0 : -0.06, th, tc, null, sk);
      if (ic === 'swoosh') { g.beginPath(); g.moveTo(-tw / 2, 0.36); g.quadraticCurveTo(0, 0.18, tw / 2 + 0.1, 0.28); g.quadraticCurveTo(0, 0.3, -tw / 2, 0.44); g.closePath(); g.fillStyle = ac; g.fill(); }
      return W + (bg === 1 ? 0.4 : 0);
    }
    const k = t - D_SHP, WS = [1, 0.96, 1.1, 0.62, 0.72, 1.7, 1.6, 6, 0.82, 1.02, 0.72, 1.1, 0.88, 0.8, 1, 1.05, 1, 1, 0.72, 1.05][k] || 1;
    if (dry) return WS;
    switch (k) {
      case 0: g.beginPath(); g.arc(0, 0, 0.5, 0, 7); paint(); break;
      case 1: { const pt = []; for (let i = 0; i < 10; i++) { const a = -PI / 2 + i * PI / 5, r = i % 2 ? 0.21 : 0.52; pt.push([Math.cos(a) * r, Math.sin(a) * r + 0.04]); } P(pt); paint(); break; }
      case 2: g.beginPath(); g.moveTo(0, 0.45); g.bezierCurveTo(-0.1, 0.35, -0.55, 0.1, -0.55, -0.18); g.bezierCurveTo(-0.55, -0.45, -0.2, -0.55, 0, -0.3); g.bezierCurveTo(0.2, -0.55, 0.55, -0.45, 0.55, -0.18); g.bezierCurveTo(0.55, 0.1, 0.1, 0.35, 0, 0.45); g.closePath(); paint(); break;
      case 3: P([[0.12, -0.5], [-0.3, 0.06], [-0.02, 0.06], [-0.14, 0.5], [0.3, -0.1], [0.02, -0.1], [0.18, -0.5]]); paint(0.07); break;
      case 4: { const fl = (sc, col) => { g.save(); g.translate(0, (1 - sc) * 0.5); g.scale(sc, sc); g.beginPath(); g.moveTo(0, 0.5); g.bezierCurveTo(-0.32, 0.5, -0.4, 0.2, -0.3, -0.02); g.quadraticCurveTo(-0.26, -0.25, -0.12, -0.5); g.quadraticCurveTo(-0.08, -0.22, 0, -0.18);
        g.quadraticCurveTo(0.04, -0.38, 0.16, -0.42); g.quadraticCurveTo(0.12, -0.2, 0.24, -0.12); g.bezierCurveTo(0.4, 0.1, 0.36, 0.5, 0, 0.5); g.closePath(); g.fillStyle = col; g.fill(); g.restore(); };
        fl(1, c); fl(0.55, c2 || shade(c, lumOf(c) > 0.6 ? -0.35 : 0.5)); break; }
      case 5: P([[-0.82, 0.12], [-0.6, -0.12], [0.82, -0.5], [0.5, -0.27], [0.86, -0.25], [0.45, -0.03], [0.76, 0.02], [0.3, 0.2], [0.56, 0.26], [-0.1, 0.42], [-0.62, 0.36]]); paint(0.07); break;
      case 6: P([[-0.8, -0.18], [0.2, -0.18], [0.2, -0.46], [0.8, 0], [0.2, 0.46], [0.2, 0.18], [-0.8, 0.18]]); paint(0.08); break;
      case 7: g.beginPath(); g.rect(-3, -0.5, 6, 1); paint(0.2); break;
      case 8: g.beginPath(); g.moveTo(-0.4, -0.46); g.lineTo(0.4, -0.46); g.lineTo(0.4, 0); g.quadraticCurveTo(0.38, 0.32, 0, 0.5); g.quadraticCurveTo(-0.38, 0.32, -0.4, 0); g.closePath(); paint(); break;
      case 9: P([[-0.5, 0.36], [-0.5, -0.32], [-0.25, -0.02], [0, -0.48], [0.25, -0.02], [0.5, -0.32], [0.5, 0.36]]); paint(0.07); if (c2) { g.fillStyle = c2; g.fillRect(-0.5, 0.36, 1, 0.14); } break;
      case 10: P([[0, -0.5], [0.36, 0], [0, 0.5], [-0.36, 0]]); paint(0.07); break;
      case 11: P([[0, -0.5], [0.55, 0.46], [-0.55, 0.46]]); paint(0.07); break;
      case 12: { const pt = []; for (let i = 0; i < 6; i++) { const a = -PI / 2 + i * PI / 3; pt.push([Math.cos(a) * 0.5, Math.sin(a) * 0.5]); } P(pt); paint(); break; }
      case 13: for (let i = -1; i <= 1; i++) { const x = i * 0.26; g.beginPath(); g.moveTo(x - 0.02, -0.5); g.quadraticCurveTo(x + 0.22, 0, x - 0.08, 0.5); g.quadraticCurveTo(x + 0.06, 0, x - 0.13, -0.44); g.closePath(); paint(0.05); } break;
      case 14: if (c2) { g.beginPath(); g.arc(0, 0, 0.5, 0, 7); g.fillStyle = c2; g.fill(); } g.beginPath(); g.arc(0, 0, 0.5, 0, 7); g.arc(0, 0, 0.37, 0, 7, true); g.moveTo(0.24, 0); g.arc(0, 0, 0.24, 0, 7); g.arc(0, 0, 0.11, 0, 7, true); g.fillStyle = c; g.fill('evenodd'); break;
      case 15: { g.fillStyle = c; g.fillRect(-0.5, -0.5, 0.06, 1); const cw = 0.18, chh = 0.18;
        for (let j = 0; j < 3; j++) for (let i = 0; i < 5; i++) { const x = -0.44 + i * cw, y = -0.48 + j * chh + Math.sin(i * 1.2) * 0.05; g.fillStyle = (i + j) % 2 ? (c2 || '#f4f4f0') : c; g.fillRect(x, y, cw + 0.005, chh + 0.005); } break; }
      case 16: g.beginPath(); g.arc(0, 0, 0.5, 0, 7); g.fillStyle = c; g.fill(); { const pt = []; for (let i = 0; i < 10; i++) { const a = -PI / 2 + i * PI / 5, r = i % 2 ? 0.14 : 0.34; pt.push([Math.cos(a) * r, Math.sin(a) * r + 0.03]); } P(pt); g.fillStyle = c2 || contra(c); g.fill(); } break;
      case 17: ring(0.5, 0.34); if (c2) { g.lineWidth = 0.06; g.strokeStyle = c2; g.stroke(); } g.fillStyle = c; g.fill('evenodd'); break;
      case 18: g.beginPath(); g.moveTo(0, -0.5); g.bezierCurveTo(0.12, -0.25, 0.36, -0.02, 0.36, 0.16); g.bezierCurveTo(0.36, 0.38, 0.18, 0.5, 0, 0.5); g.bezierCurveTo(-0.18, 0.5, -0.36, 0.38, -0.36, 0.16); g.bezierCurveTo(-0.36, -0.02, -0.12, -0.25, 0, -0.5); g.closePath(); paint(); break;
      case 19: for (const x of [-0.32, 0, 0.32]) { P([[x - 0.2, -0.5], [x, -0.5], [x + 0.22, 0], [x, 0.5], [x - 0.2, 0.5], [x + 0.02, 0]]); paint(0.06); } break;
    }
    return WS;
  }
  /* 모양 2(v4, 100~119): 반짝 · 해골 · 교차 피스톤 · 렌치 · 바퀴 · 날개 바퀴 · 타이어 자국 · 소용돌이 · 심박선 · 산봉우리 · 태양 · 초승달 · 나뭇잎 · 스페이드 · 클로버 · 교차 깃발 · 터보 팬 · 펼친 날개 · 표창 · 깃털 (모두 직접 그린 모양) */
  function decShape2(g, k, c, c2, dry, P, paint, paintEO, ring, rr) {
    const WS = [1, 0.86, 1, 1.7, 1, 2.3, 4, 1, 3, 1.6, 1, 0.85, 0.72, 0.9, 1, 1.4, 1, 2.4, 1, 0.5][k] || 1;
    if (dry) return WS;
    const dk = c2 || shade(c, lumOf(c) > 0.55 ? -0.45 : 0.45);
    const stroke = (lw, col) => { g.lineCap = 'round'; g.lineJoin = 'round'; if (c2) { g.lineWidth = lw + 0.07; g.strokeStyle = c2; g.stroke(); } g.lineWidth = lw; g.strokeStyle = col || c; g.stroke(); };
    switch (k) {
      case 0: g.beginPath(); g.moveTo(0, -0.5); g.quadraticCurveTo(0.06, -0.06, 0.5, 0); g.quadraticCurveTo(0.06, 0.06, 0, 0.5); g.quadraticCurveTo(-0.06, 0.06, -0.5, 0); g.quadraticCurveTo(-0.06, -0.06, 0, -0.5); g.closePath(); paint(0.05);
        g.beginPath(); g.moveTo(0.3, -0.36); g.quadraticCurveTo(0.33, -0.33, 0.42, -0.3); g.quadraticCurveTo(0.33, -0.27, 0.3, -0.18); g.quadraticCurveTo(0.27, -0.27, 0.18, -0.3); g.quadraticCurveTo(0.27, -0.33, 0.3, -0.42); g.closePath(); g.fillStyle = c; g.fill(); break;
      case 1: { g.beginPath(); g.arc(0, -0.08, 0.4, PI * 0.82, PI * 2.18); g.lineTo(0.22, 0.26); g.lineTo(0.22, 0.46); g.lineTo(-0.22, 0.46); g.lineTo(-0.22, 0.26); g.closePath();
        g.moveTo(-0.04, -0.05); g.arc(-0.16, -0.05, 0.12, 0, 7); g.moveTo(0.28, -0.05); g.arc(0.16, -0.05, 0.12, 0, 7);
        g.moveTo(0, 0.08); g.lineTo(0.06, 0.2); g.lineTo(-0.06, 0.2); g.closePath(); paintEO(0.06);
        g.strokeStyle = dk; g.lineWidth = 0.035; for (const x of [-0.11, 0, 0.11]) { g.beginPath(); g.moveTo(x, 0.3); g.lineTo(x, 0.46); g.stroke(); } break; }
      case 2: for (const s of [-1, 1]) { g.save(); g.rotate(s * 0.7);
          rr(-0.17, -0.5, 0.34, 0.3, 0.05); g.fillStyle = c; g.fill(); if (c2) { g.lineWidth = 0.04; g.strokeStyle = c2; g.stroke(); }
          g.fillStyle = dk; g.fillRect(-0.17, -0.44, 0.34, 0.035); g.fillRect(-0.17, -0.37, 0.34, 0.035);
          g.fillStyle = c; g.fillRect(-0.05, -0.2, 0.1, 0.56); g.beginPath(); g.arc(0, 0.4, 0.09, 0, 7); g.fill(); g.restore(); } break;
      case 3: { g.beginPath(); g.moveTo(-0.62, -0.07); g.lineTo(0.55, -0.07); g.lineTo(0.55, 0.07); g.lineTo(-0.62, 0.07); g.closePath();   // nonzero: body clockwise, openings anticlockwise
        g.moveTo(-0.35, 0); g.arc(-0.62, 0, 0.27, 0, 7); g.moveTo(0.86, 0); g.arc(0.66, 0, 0.2, 0, 7);
        g.moveTo(-0.92, -0.1); g.lineTo(-0.92, 0.1); g.lineTo(-0.7, 0.1); g.lineTo(-0.7, -0.1); g.closePath(); g.moveTo(0.75, 0); g.arc(0.66, 0, 0.09, 0, 7, true); paint(0.06); break; }
      case 4: { ring(0.5, 0.36); g.fillStyle = c; g.fill('evenodd'); g.beginPath(); g.arc(0, 0, 0.1, 0, 7); g.fill();
        g.strokeStyle = c; g.lineWidth = 0.06; for (let i = 0; i < 5; i++) { const a = -PI / 2 + i * PI * 0.4; g.beginPath(); g.moveTo(Math.cos(a) * 0.1, Math.sin(a) * 0.1); g.lineTo(Math.cos(a) * 0.38, Math.sin(a) * 0.38); g.stroke(); }
        if (c2) { g.beginPath(); g.arc(0, 0, 0.43, 0, 7); g.lineWidth = 0.03; g.strokeStyle = c2; g.setLineDash([0.05, 0.05]); g.stroke(); g.setLineDash([]); } break; }
      case 5: { for (const s of [-1, 1]) { g.save(); g.scale(s, 1); P([[0.42, -0.1], [1.15, -0.42], [1.02, -0.22], [1.12, -0.18], [0.95, -0.02], [1.03, 0.02], [0.82, 0.14], [0.42, 0.14]]); paint(0.05); g.restore(); }
        ring(0.42, 0.28); g.fillStyle = c; g.fill('evenodd'); g.beginPath(); g.arc(0, 0, 0.12, 0, 7); g.fillStyle = c2 || c; g.fill(); break; }
      case 6: { g.fillStyle = c; g.fillRect(-2, -0.5, 4, 0.1); g.fillRect(-2, 0.4, 4, 0.1);
        for (let x = -2; x < 2; x += 0.42) { P([[x, -0.36], [x + 0.18, -0.36], [x + 0.36, 0], [x + 0.18, 0.36], [x, 0.36], [x + 0.18, 0]]); g.fillStyle = c; g.fill(); }
        if (c2) { g.fillStyle = c2; g.fillRect(-2, -0.03, 4, 0.06); } break; }
      case 7: { g.beginPath(); for (let i = 0; i <= 80; i++) { const a = i * 0.16, r = 0.02 + i * 0.0058; const x = Math.cos(a) * r, y = Math.sin(a) * r; i ? g.lineTo(x, y) : g.moveTo(x, y); } stroke(0.07); break; }
      case 8: { g.beginPath(); const pts = [[-1.5, 0], [-0.5, 0], [-0.35, -0.12], [-0.2, 0], [-0.1, 0], [0, 0.22], [0.12, -0.5], [0.26, 0.42], [0.36, 0], [0.55, 0], [0.7, -0.14], [0.85, 0], [1.5, 0]];
        pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); stroke(0.07); break; }
      case 9: { P([[-0.8, 0.5], [-0.25, -0.3], [0.05, 0.08], [0.32, -0.5], [0.8, 0.5]]); g.fillStyle = c; g.fill();
        g.fillStyle = c2 || shade(c, 0.75); P([[0.32, -0.5], [0.45, -0.24], [0.38, -0.2], [0.32, -0.27], [0.24, -0.2], [0.19, -0.23]]); g.fill(); P([[-0.25, -0.3], [-0.12, -0.12], [-0.2, -0.1], [-0.25, -0.16], [-0.32, -0.08], [-0.37, -0.13]]); g.fill(); break; }
      case 10: { g.beginPath(); g.arc(0, 0, 0.27, 0, 7); g.fillStyle = c; g.fill(); if (c2) { g.lineWidth = 0.04; g.strokeStyle = c2; g.stroke(); }
        for (let i = 0; i < 12; i++) { const a = i * PI / 6; g.save(); g.rotate(a); P([[0.32, -0.05], [0.5, 0], [0.32, 0.05]]); g.fillStyle = c; g.fill(); g.restore(); } break; }
      case 11: { g.save(); g.beginPath(); g.arc(0, 0, 0.5, 0, 7); g.clip(); g.beginPath(); g.arc(0, 0, 0.5, 0, 7); g.moveTo(0.62, -0.1); g.arc(0.2, -0.1, 0.42, 0, 7); paintEO(0.05); g.restore(); break; }
      case 12: { g.beginPath(); g.moveTo(0, -0.5); g.bezierCurveTo(0.42, -0.25, 0.4, 0.25, 0, 0.42); g.bezierCurveTo(-0.4, 0.25, -0.42, -0.25, 0, -0.5); g.closePath(); paint(0.05);
        g.strokeStyle = c2 || dk; g.lineWidth = 0.03; g.beginPath(); g.moveTo(0, -0.42); g.lineTo(0, 0.5); for (const y of [-0.2, 0, 0.2]) { g.moveTo(0, y + 0.06); g.lineTo(0.2, y - 0.08); g.moveTo(0, y + 0.06); g.lineTo(-0.2, y - 0.08); } g.stroke(); break; }
      case 13: { g.beginPath(); g.moveTo(0, -0.5); g.bezierCurveTo(0.2, -0.25, 0.46, -0.1, 0.42, 0.12); g.bezierCurveTo(0.38, 0.32, 0.12, 0.34, 0.03, 0.18); g.lineTo(0.14, 0.48); g.lineTo(-0.14, 0.48); g.lineTo(-0.03, 0.18);
        g.bezierCurveTo(-0.12, 0.34, -0.38, 0.32, -0.42, 0.12); g.bezierCurveTo(-0.46, -0.1, -0.2, -0.25, 0, -0.5); g.closePath(); paint(0.05); break; }
      case 14: { g.beginPath(); for (const [x, y] of [[0, -0.24], [-0.24, 0.06], [0.24, 0.06]]) { g.moveTo(x + 0.22, y); g.arc(x, y, 0.22, 0, 7); } paint(0.05);
        P([[-0.04, 0.1], [0.04, 0.1], [0.1, 0.5], [-0.1, 0.5]]); g.fillStyle = c; g.fill(); break; }
      case 15: for (const s of [-1, 1]) { g.save(); g.scale(s, 1); g.rotate(-0.38); g.fillStyle = c; g.fillRect(-0.04, -0.48, 0.05, 1);
          const cs = 0.11; for (let j = 0; j < 3; j++) for (let i = 0; i < 4; i++) { g.fillStyle = (i + j) % 2 ? (c2 || '#f4f4f0') : c; g.fillRect(0.01 + i * cs, -0.48 + j * cs + Math.sin(i) * 0.02, cs + 0.004, cs + 0.004); } g.restore(); } break;
      case 16: { ring(0.5, 0.42); g.fillStyle = c; g.fill('evenodd'); g.beginPath(); g.arc(0, 0, 0.1, 0, 7); g.fillStyle = c2 || c; g.fill();
        for (let i = 0; i < 9; i++) { g.save(); g.rotate(i * PI * 2 / 9); g.beginPath(); g.moveTo(0.09, -0.03); g.quadraticCurveTo(0.26, -0.14, 0.42, -0.06); g.lineTo(0.42, 0.04); g.quadraticCurveTo(0.24, -0.03, 0.09, 0.04); g.closePath(); g.fillStyle = c; g.fill(); g.restore(); } break; }
      case 17: { for (const s of [-1, 1]) { g.save(); g.scale(s, 1);   // fanned feathers, longest at the top
          for (let i = 4; i >= 0; i--) { const a = -0.28 - i * 0.2, len = 1.1 - i * 0.13; g.save(); g.translate(0.1, 0.18); g.rotate(a); g.beginPath(); g.ellipse(len / 2, 0, len / 2, 0.075, 0, 0, 7); paint(0.03); g.restore(); }
          g.restore(); }
        g.beginPath(); g.ellipse(0, 0.16, 0.11, 0.24, 0, 0, 7); g.fillStyle = c2 || c; g.fill(); break; }
      case 18: { g.beginPath(); for (let i = 0; i < 4; i++) { const a = i * PI / 2; const p = (r, b) => [Math.cos(a + b) * r, Math.sin(a + b) * r];
          const [x1, y1] = p(0.12, -0.6), [x2, y2] = p(0.5, 0), [x3, y3] = p(0.16, 0.5); i ? g.lineTo(x1, y1) : g.moveTo(x1, y1); g.quadraticCurveTo(...p(0.36, -0.3), x2, y2); g.lineTo(x3, y3); }
        g.closePath(); g.moveTo(0.08, 0); g.arc(0, 0, 0.08, 0, 7); paintEO(0.04); break; }
      case 19: { g.beginPath(); g.moveTo(0.02, -0.5); g.bezierCurveTo(0.28, -0.3, 0.24, 0.2, 0.04, 0.36); g.lineTo(-0.02, 0.34); g.bezierCurveTo(-0.24, 0.12, -0.2, -0.3, 0.02, -0.5); g.closePath(); paint(0.04);
        g.strokeStyle = c2 || dk; g.lineWidth = 0.025; g.beginPath(); g.moveTo(0.02, -0.46); g.quadraticCurveTo(0.06, 0, -0.02, 0.5); g.stroke(); break; }
    }
    return WS;
  }
  /* 스티커 겹의 그리기 자리: [면 키, x, y(미터), 반사 sx, sy, 대칭 사본인가] 목록 */
  function decalPuts(l, D) {
    const Lm = D.front - D.rear, Hm = Math.max(0.5, D.top - D.bot), Wm = 2 * D.half, f = l[2] | 0, a = (l[3] == null ? 100 : l[3]) / 200, b = (l[4] == null ? 100 : l[4]) / 200;
    const m = l[7] == null ? 1 : l[7], tl = l[0] >= D_TXT && l[0] < D_SHP2, FK = ['R', 'L', 'T', 'F', 'B'], k = FK[f] || 'R';
    const rw = k === 'T' ? [Lm, Wm] : k === 'F' || k === 'B' ? [Wm, Hm] : [Lm, Hm], x = a * rw[0], y = b * rw[1], out = [[k, x, y, 1, 1, false]];
    if (m & 1) {
      if (f <= 1) out.push([f ? 'R' : 'L', x, y, tl ? 1 : -1, 1, true]);
      else if (k === 'T') { if (Math.abs(rw[1] - 2 * y) > 0.03) out.push(['T', x, rw[1] - y, 1, tl ? 1 : -1, true]); }
      else if (Math.abs(rw[0] - 2 * x) > 0.03) out.push([k, rw[0] - x, y, tl ? 1 : -1, 1, true]);
    }
    return out;
  }
  // 겹 마감(v4) → 마감 결의 색: R 거칠기 · G 금속 · B 클리어코트 끔(무광) — 0 = 차와 같음
  const LFIN_C = [null, [0.12, 0.08, 0], [0.82, 0.02, 1], [0.3, 0.85, 0], [0.05, 1, 0], [0.5, 0.25, 1]];
  const LFIN_S = LFIN_C.map((v) => (v ? 'rgb(' + v.map((x) => Math.round(x * 255)).join(',') + ')' : ''));
  const isoPool = [];   // 겹을 따로 그리는 캔버스(반투명 · 그라데이션 · 마스크 · 마감) — 결 크기마다 재사용
  const isoCv = (W, i) => { let c = isoPool[i]; if (!c || c.canvas.width !== W) { const cv = document.createElement('canvas'); cv.width = cv.height = W; c = isoPool[i] = cv.getContext('2d'); } c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.globalCompositeOperation = 'source-over'; return c; };
  const FACEB = { R: 1, L: 2, T: 4, F: 8, B: 16 }, AREAM = [31, 3, 1, 2, 4, 8, 16, 7, 24];   // = CUST.AREAM
  /* 그라데이션: 겹 색 위에 끝 색이 점점 덮임(0 가로 · 1 세로 · 2 비스듬히 · 3 가운데부터) — x, y, w, h = 그 겹의 칸 */
  function gradOf(g, md, x, y, w, h, ec) {
    const gr = md === 3 ? g.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, Math.max(w, h) * 0.6) : g.createLinearGradient(x, md === 1 ? y : md === 2 ? y + h : y, md === 1 ? x : x + w, md === 1 ? y + h : y);
    gr.addColorStop(md === 3 ? 0.15 : 0.1, shade(ec, 0, 0)); gr.addColorStop(md === 3 ? 1 : 0.9, shade(ec, 0, 1)); return gr;
  }
  /* 겹 · 투톤 · 번호를 결 한 장(W × W)에 구움. fg = 마감 결(W/2, 겹 마감이 있을 때만) → 무엇이든 그렸으면 true */
  function bakeDecal(g, W, cu, D, fg) {
    const Lm = D.front - D.rear, Hm = Math.max(0.5, D.top - D.bot), Wm = 2 * D.half, q = W / 4;
    const G0 = g;
    g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, W);
    if (fg) { fg.setTransform(1, 0, 0, 1, 0, 0); fg.clearRect(0, 0, fg.canvas.width, fg.canvas.height); }
    // [x0, y0, px w, px h, m w, m h, mirrored]
    const RG = { R: [0, 0, W, q, Lm, Hm, 0], L: [0, q, W, q, Lm, Hm, 1], T: [0, 2 * q, W, q, Lm, Wm, 0], F: [0, 3 * q, W / 2, q, Wm, Hm, 0], B: [W / 2, 3 * q, W / 2, q, Wm, Hm, 0] };
    let mir = false, AM = 31, PX = null, fontN = FONT;
    // a face region in metres (+ the layer's area mask · free transform about the face centre)
    const inR = (k, fn) => {
      if (!(AM & FACEB[k])) return;
      const r = RG[k]; g.save(); g.beginPath(); g.rect(r[0], r[1], r[2], r[3]); g.clip();
      if (r[6]) g.setTransform(-r[2] / r[4], 0, 0, r[3] / r[5], r[0] + r[2], r[1]); else g.setTransform(r[2] / r[4], 0, 0, r[3] / r[5], r[0], r[1]);
      if (PX) { const w = r[4], h = r[5]; g.translate(w / 2 + PX.x, h / 2 + PX.y); if (PX.r) g.rotate(PX.r); if (PX.k) g.transform(1, 0, PX.k, 1, 0, 0); g.scale(PX.w, PX.h); g.translate(-w / 2, -h / 2); }
      mir = !!r[6]; fn(r[4], r[5]); g.restore(); mir = false;
    };
    const sides = (fn) => { inR('R', fn); inR('L', fn); };
    const all = (fs, ft, fe) => { if (fs) sides(fs); if (ft) inR('T', ft); if (fe) { inR('F', (w, h) => fe(w, h, 1)); inR('B', (w, h) => fe(w, h, 0)); } };
    const rect = (x, y, w, h, c) => { g.fillStyle = c; g.fillRect(x, y, w, h); };
    // text of height th (m), centred on (x, y); rot = quarter turns; reads right on mirrored regions too
    const text = (s, x, y, th, col, rot, stroke) => {
      g.save(); g.translate(x, y); if (mir) g.scale(-1, 1); if (rot) g.rotate(rot * PI / 2); g.scale(th / 100, th / 100);
      g.font = fontN; g.textAlign = 'center'; g.textBaseline = 'middle';
      if (stroke) { g.lineJoin = 'round'; g.lineWidth = 16; g.strokeStyle = stroke; g.strokeText(s, 0, 4); }
      g.fillStyle = col; g.fillText(s, 0, 4); g.restore();
    };
    const textW = (s, th) => { g.save(); g.font = fontN; const w = g.measureText(s).width * th / 100; g.restore(); return w; };
    const rrect = (x, y, w, h, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
    let any = false;
    // ---- two-tone zones (under the layers): 지붕 · 아래쪽 · 앞쪽 절반 · 뒤쪽 절반 · 보닛 · 앞 범퍼 · 꼬리 · 옆 아래 띠 · 윗면 전체 ----
    const tone = (tt, c) => {
      if (tt === 1) all((w, h) => rect(0, 0, w, h * 0.33, c), (w, h) => rect(w * 0.3, 0, w * 0.42, h, c));
      else if (tt === 2) all((w, h) => rect(0, h * 0.62, w, h, c), null, (w, h) => rect(0, h * 0.62, w, h, c));
      else if (tt === 3) all((w, h) => rect(w * 0.5, 0, w, h, c), (w, h) => rect(w * 0.5, 0, w, h, c), (w, h, fr) => { if (fr) rect(0, 0, w, h, c); });
      else if (tt === 4) all((w, h) => rect(0, 0, w * 0.5, h, c), (w, h) => rect(0, 0, w * 0.5, h, c), (w, h, fr) => { if (!fr) rect(0, 0, w, h, c); });
      else if (tt === 5) all(null, (w, h) => rect(w * 0.7, 0, w, h, c), (w, h, fr) => { if (fr) rect(0, 0, w, h * 0.55, c); });
      else if (tt === 6) all((w, h) => rect(w * 0.87, h * 0.5, w, h, c), (w, h) => rect(w * 0.93, 0, w, h, c), (w, h, fr) => { if (fr) rect(0, h * 0.45, w, h, c); });
      else if (tt === 7) all((w, h) => rect(0, 0, w * 0.13, h, c), (w, h) => rect(0, 0, w * 0.1, h, c), (w, h, fr) => { if (!fr) rect(0, 0, w, h, c); });
      else if (tt === 8) all((w, h) => rect(0, h * 0.76, w, h, c), null, (w, h) => rect(0, h * 0.8, w, h, c));
      else if (tt === 9) all((w, h) => rect(0, 0, w, h * 0.16, c), (w, h) => rect(0, 0, w, h, c), (w, h) => rect(0, 0, w, h * 0.16, c));
    };
    if (cu.tt && cu.tc) { any = true; tone(cu.tt, cu.tc); }
    if (cu.t2 && cu.t2c) { any = true; tone(cu.t2, cu.t2c); }
    // ---- layers (first = bottom; hidden ones skipped) ----
    const Ls = (cu.L || []).map((l, i) => [l, i]).filter(([l]) => !xOf(l).v);
    const finOn = !!fg && Ls.some(([l]) => xOf(l).f > 0);
    let finSeen = false, maskC = null, toneC = null, isoI = 0;
    Ls.forEach(([l, li], n) => {
      const t = l[0] | 0, c = l[1] || '#f4f4f0', dec = isDecT(t), op = (dec ? l[8] : l[5]) || 100, X = xOf(l), nx = Ls[n + 1] && xOf(Ls[n + 1][0]);
      const lf = X.f | 0, keepMask = !!(nx && (nx.m === 1 || nx.m === 2));
      any = true;
      if (lf) finSeen = true;
      const iso = op < 100 || !!X.g || !!X.m || keepMask || (finOn && (lf || finSeen));
      if (iso) { isoI = (isoI + 1) % 2; if (maskC && isoPool[isoI] === maskC) isoI = (isoI + 1) % 2; g = isoCv(W, isoI); g.clearRect(0, 0, W, W); }
      // the layer itself (+ its drop shadow under it)
      if (dec) decal(l, li === cu._sel, li === cu._hov, X);
      else {
        const sw = X.w ? X.w / 100 : 1, sh = X.h ? X.h / 100 : 1;
        PX = X.x || X.y || X.r || X.k || sw !== 1 || sh !== 1 ? { x: (X.x | 0) / 100, y: (X.y | 0) / 100, r: ((X.r | 0) * PI) / 180, k: Math.tan(((X.k | 0) * PI) / 180), w: sw, h: sh } : null;
        AM = AREAM[X.a | 0] || 31;
        const s = l[2] == null ? 2 : l[2] | 0, o = l[3] == null ? 2 : l[3] | 0, c2 = l[4] || '';
        if (X.d) { const P0 = PX; PX = Object.assign({ x: 0, y: 0, r: 0, k: 0, w: 1, h: 1 }, P0 || {}); PX.x += 0.025; PX.y += 0.035; g.save(); g.globalAlpha = 0.45; pattern(t, '#000000', s, o, c2 ? '#000000' : ''); g.restore(); PX = P0; }
        pattern(t, c, s, o, c2);
        // gradient: the layer fades into the end colour across each face it covers (follows the free transform)
        if (X.g) { g.save(); g.globalCompositeOperation = 'source-atop'; const ec = X.g[0], md = X.g[1] | 0;
          for (const k of ['R', 'L', 'T', 'F', 'B']) inR(k, (w, h) => { g.fillStyle = gradOf(g, md, 0, 0, w, h, ec); g.fillRect(-w, -h, w * 3, h * 3); }); g.restore(); }
        PX = null; AM = 31;
      }
      if (iso) {
        if (X.m === 1 || X.m === 2) { g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = X.m === 1 ? 'destination-in' : 'destination-out'; if (maskC) g.drawImage(maskC.canvas, 0, 0); else if (X.m === 1) g.clearRect(0, 0, W, W); g.restore(); }
        else if (X.m === 3) {
          if (!toneC) { toneC = isoCv(W, 2); toneC.clearRect(0, 0, W, W); const g1 = g; g = toneC; if (cu.tt) tone(cu.tt, '#ffffff'); if (cu.t2) tone(cu.t2, '#ffffff'); g = g1; }
          g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'destination-in'; g.drawImage(toneC.canvas, 0, 0); g.restore();
        }
        const L1 = g; g = G0;
        g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = op / 100; g.drawImage(L1.canvas, 0, 0); g.restore();
        // finish map: this layer's own finish, or (plain finish on top of a finished layer) back to the car's
        if (finOn) { const fw = fg.canvas.width; fg.save(); fg.setTransform(1, 0, 0, 1, 0, 0);
          if (lf) { const tc = isoCv(W, 3); tc.clearRect(0, 0, W, W); tc.drawImage(L1.canvas, 0, 0); tc.globalCompositeOperation = 'source-in'; tc.fillStyle = LFIN_S[lf]; tc.fillRect(0, 0, W, W); tc.globalCompositeOperation = 'source-over';
            fg.globalAlpha = op / 100; fg.drawImage(tc.canvas, 0, 0, fw, fw); }
          else { fg.globalCompositeOperation = 'destination-out'; fg.globalAlpha = op / 100; fg.drawImage(L1.canvas, 0, 0, fw, fw); }
          fg.restore(); }
        maskC = keepMask ? L1 : null;
      } else maskC = null;
    });
    g = G0;
    function decal(l, sel, hov, X) {
      const t = l[0] | 0, c = l[1] || '#f4f4f0', sm = (l[5] || 40) / 100, rot = ((l[6] | 0) * PI) / 180, m = l[7] == null ? 1 : l[7], c2 = l[9] || '', tx = l[10] || '';
      const st = (X.w || 100) / 100, sk = X.k ? Math.tan((X.k * PI) / 180) : 0;
      for (const [k, x, y, sx, sy, cp] of decalPuts(l, D)) inR(k, () => {
        g.translate(x, y); if (k === 'L') g.scale(-1, 1); g.scale(sx, sy); g.rotate(rot + (k === 'T' ? PI / 2 : 0)); g.scale(sm, sm); if (m & 2) g.scale(-1, 1);
        if (sk) g.transform(1, 0, -sk, 1, 0, 0);
        if (st !== 1) g.scale(st, 1);
        if (X.d) { g.save(); g.translate(0.05, 0.07); g.globalAlpha *= 0.45; decShape(g, t, '#000000', c2 ? '#000000' : '', tx, false, X); g.restore(); }
        const w = decShape(g, t, c, c2, tx, false, X);
        if (X.g) { g.save(); g.globalCompositeOperation = 'source-atop'; g.fillStyle = gradOf(g, X.g[1] | 0, -w / 2, -0.5, w, 1, X.g[0]); g.fillRect(-w / 2 - 0.6, -1.1, w + 1.2, 2.2); g.restore(); }
        if (sel) {   // the decal being edited: dashed frame (preview only)
          const lw = 0.025 / sm, p = 0.1; g.lineWidth = lw; g.setLineDash([0.12, 0.08]); g.strokeStyle = '#ffffff'; g.strokeRect(-w / 2 - p, -0.5 - p, w + 2 * p, 1 + 2 * p);
          g.lineDashOffset = 0.1; g.strokeStyle = '#111111'; g.strokeRect(-w / 2 - p, -0.5 - p, w + 2 * p, 1 + 2 * p); g.setLineDash([]);
        } else if (hov) {   // PC: the sticker under the mouse (click = select it)
          const lw = 0.02 / sm, p = 0.08; g.lineWidth = lw; g.strokeStyle = 'rgba(255,214,110,0.95)'; g.strokeRect(-w / 2 - p, -0.5 - p, w + 2 * p, 1 + 2 * p);
        }
      });
    }
    function pattern(t, c, s, o, c2) {
      const f = [0.55, 0.78, 1, 1.3, 1.7][s], oo = o - 2;
      if (t === 1 || t === 2) {   // racing stripes over the top (+ nose / tail)
        const bands = t === 1 ? (() => { const w = 0.13 * f, gp = 0.06 + 0.05 * o; return [[-(gp / 2 + w), w], [gp / 2, w]]; })() : [[oo * 0.12 - 0.16 * f, 0.32 * f]];
        const draw = (pad, col) => all(null, (w, h) => { for (const [x, bw] of bands) rect(0, h / 2 - x - bw - pad, w, bw + 2 * pad, col); }, (w, h, fr) => { for (const [x, bw] of bands) rect((fr ? w / 2 + x : w / 2 - x - bw) - pad, 0, bw + 2 * pad, h, col); });
        if (c2) draw(0.025, c2);
        draw(0, c);
      } else if (t === 3) {   // side band, around the car
        const band = (w, h) => { const hc = h * (0.52 - oo * 0.08), th = h * 0.09 * f; if (c2) rect(0, hc - th / 2 - 0.03, w, th + 0.06, c2); rect(0, hc - th / 2, w, th, c); };
        all(band, null, band);
      } else if (t === 4) {   // three slanted bars on the sides
        sides((w, h) => { const a0 = w * (0.55 + oo * 0.08), bw = 0.11 * f, sp = 0.2 * f, k = h * 0.5; g.fillStyle = c;
          for (let i = -1; i <= 1; i++) { const a = a0 + i * sp; g.beginPath(); g.moveTo(a, h); g.lineTo(a + bw, h); g.lineTo(a + bw + k, 0); g.lineTo(a + k, 0); g.closePath(); g.fill(); } });
      } else if (t === 5 || t === 6) {   // chequered tail / chequered all over
        const cs = t === 5 ? 0.11 * f : 0.2 * f, ph = t === 6 ? o * cs / 4 : 0, lim = (w) => (t === 5 ? w * (0.22 + 0.04 * oo) : w);
        const chk = (w, h, x1) => { for (let y = -ph, j = 0; y < h; y += cs, j++) for (let x = -ph, i = 0; x < x1; x += cs, i++) { const on = (i + j) % 2 === 0; if (!on && !c2) continue; g.fillStyle = on ? c : c2; g.fillRect(x, y, Math.min(cs, x1 - x), cs); } };
        all((w, h) => chk(w, h, lim(w)), (w, h) => chk(w, h, lim(w)), (w, h, fr) => { if (t === 6 || !fr) chk(w, h, w); });
      } else if (t === 7) {   // flames from the nose, rearwards on the sides and over the bonnet
        const flame = (x0, y0, span, len, n, col, seed) => {   // tongues from x0 towards −x, spread over y0..y0+span
          g.fillStyle = col; g.beginPath(); g.moveTo(x0, y0);
          for (let i = 0; i < n; i++) {
            const ya = y0 + span * i / n, yb = y0 + span * (i + 1) / n, ym = (ya + yb) / 2, tip = x0 - len * (0.5 + 0.5 * hash2(i, seed, 7)), vy = x0 - len * 0.18;
            g.quadraticCurveTo(x0 - len * 0.3, ya, tip, ym - (yb - ya) * 0.15); g.quadraticCurveTo(x0 - len * 0.25, ym + (yb - ya) * 0.1, vy, yb);
          }
          g.lineTo(x0 + 0.05, y0 + span); g.lineTo(x0 + 0.05, y0); g.closePath(); g.fill();
        };
        const len = 0.3 + 0.08 * s, hot = c2 || shade(c, lumOf(c) > 0.6 ? -0.35 : 0.45);
        sides((w, h) => { const hc = h * (0.55 - oo * 0.07), th = h * 0.42; flame(w, hc - th / 2, th, w * len, 5, c, 1); flame(w, hc - th * 0.32, th * 0.64, w * len * 0.62, 4, hot, 2); });
        inR('T', (w, h) => { flame(w, h * 0.12, h * 0.76, w * len * 0.55, 6, c, 3); flame(w, h * 0.24, h * 0.52, w * len * 0.35, 5, hot, 4); });
        inR('F', (w, h) => rect(0, h * 0.25, w, h * 0.5, c));
      } else if (t === 8) {   // lightning bolt along the sides
        sides((w, h) => {
          const bl = Math.min(w * 0.85, w * 0.42 * f), a0 = w * (0.5 + oo * 0.1) + bl / 2, hc = h * 0.5, amp = h * 0.16, tk = h * 0.075 * Math.sqrt(f);
          const xs = [0, 0.3, 0.26, 0.6, 0.55, 1], ys = [-0.5, 0.35, -0.35, 0.45, -0.25, 0.3], up = [], dn = [];
          xs.forEach((x, i) => { const px = a0 - x * bl, py = hc + ys[i] * amp, th = tk * (1 - x * 0.92); up.push([px, py - th]); dn.push([px, py + th]); });
          g.fillStyle = c; g.beginPath(); up.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); dn.reverse().forEach(([x, y]) => g.lineTo(x, y)); g.closePath(); g.fill();
          g.strokeStyle = c2 || shade(c, lumOf(c) > 0.5 ? -0.5 : 0.5); g.lineWidth = c2 ? 0.02 : 0.012; g.stroke();
        });
      } else if (t === 9) {   // carbon bonnet (twill weave), roof too when placed further back
        const weave = (x0, x1, h) => {
          rect(x0, 0, x1 - x0, h, shade(c, -0.82)); const cs = 0.03;
          for (let y = 0, j = 0; y < h; y += cs, j++) for (let x = x0, i = 0; x < x1; x += cs, i++) { const k = (i + j * 2) % 4 < 2; g.fillStyle = k ? shade(c, -0.55) : shade(c, -0.7); g.fillRect(x, y, cs * 0.9, cs * 0.9); }
        };
        inR('T', (w, h) => { weave(w * (1 - (0.24 + 0.05 * s)), w, h); if (o >= 3) weave(w * 0.36, w * 0.66, h); });
      } else if (t === 10 || t === 19) {   // fade (10: colour → clear · 19: colour → second colour): rear → front · front → rear · bottom → top · top → bottom · diagonal
        const ext = t === 10 ? 0.35 + 0.16 * s : [0.2, 0.4, 0.6, 0.8, 1][s], md = o, c1 = c2 && t === 19 ? c2 : null;
        const grad = (x0, y0, x1, y1) => {
          const gr = g.createLinearGradient(x0, y0, x1, y1);
          if (t === 10) { gr.addColorStop(0, shade(c, 0, 1)); gr.addColorStop(1, shade(c, 0, 0)); }
          else { gr.addColorStop(0, shade(c, 0, 1)); gr.addColorStop(1, c1 || shade(c, 0, 0)); }
          return gr;
        };
        const fill = (w, h, gr) => { g.fillStyle = gr; g.fillRect(0, 0, w, h); };
        if (t === 19) {   // the whole body, start colour → end colour, centred
          const a = 0.5 - ext / 2, b = 0.5 + ext / 2, end = c1 || null;
          const along = (w, h) => fill(w, h, md === 1 ? grad(w * b, 0, w * a, 0) : md === 2 ? grad(0, h * b, 0, h * a) : md === 3 ? grad(0, h * a, 0, h * b) : md === 4 ? grad(0, h, w * b, h * (1 - b)) : grad(w * a, 0, w * b, 0));
          const ends = (w, h, fr) => { if (md <= 1) { if ((fr === 1) === (md === 0)) { if (end) rect(0, 0, w, h, end); } else rect(0, 0, w, h, c); } else along(w, h); };
          all(along, md === 2 ? (w, h) => { if (end) rect(0, 0, w, h, end); } : md === 3 ? (w, h) => rect(0, 0, w, h, c) : along, ends);
        } else if (md <= 1) all((w, h) => fill(w, h, md ? grad(w, 0, w * (1 - ext), 0) : grad(0, 0, w * ext, 0)), (w, h) => fill(w, h, md ? grad(w, 0, w * (1 - ext), 0) : grad(0, 0, w * ext, 0)), (w, h, fr) => { if (fr === md) rect(0, 0, w, h, c); });
        else if (md <= 3) all((w, h) => fill(w, h, md === 2 ? grad(0, h, 0, h * (1 - ext)) : grad(0, 0, 0, h * ext)), md === 3 ? (w, h) => rect(0, 0, w, h, c) : null, (w, h) => fill(w, h, md === 2 ? grad(0, h, 0, h * (1 - ext)) : grad(0, 0, 0, h * ext)));
        else all((w, h) => fill(w, h, grad(0, h, w * ext, h - w * ext * 0.4)), null, (w, h, fr) => { if (!fr) fill(w, h, grad(0, h, 0, h * (1 - ext))); });
      } else if (t === 11) {   // digital camo: three shades in blocks (two scales, seeded by 위치)
        const b = 0.06 * f, cols = [c, c2 || shade(c, 0.3), shade(c, -0.4)];
        const camo = (w, h, sd) => { for (let y = 0, j = 0; y < h; y += b, j++) for (let x = 0, i = 0; x < w; x += b, i++) {
          const v = hash2(Math.floor(i / 3), Math.floor(j / 3), sd + o * 11) * 0.6 + hash2(i, j, sd + 5) * 0.4; if (v < 0.42) continue;
          g.fillStyle = cols[v > 0.78 ? 2 : v > 0.6 ? 1 : 0]; g.fillRect(x, y, b * 1.02, b * 1.02); } };
        all((w, h) => camo(w, h, 1), (w, h) => camo(w, h, 2), (w, h, fr) => camo(w, h, fr ? 3 : 4));
      } else if (t === 12) {   // made-up sponsor stickers: sides (behind the front wheel · rear quarter) + bonnet
        const set = STK[o % STK.length], tc = c2 || contra(c);
        const stick = (x, y, s0, th, rot) => { const tw = textW(s0, th) + th * 0.7, hh = th * 1.5; g.save(); g.translate(x, y); if (rot) g.rotate(rot * PI / 2); g.fillStyle = c; rrect(-tw / 2, -hh / 2, tw, hh, hh * 0.25); g.fill(); g.restore(); text(s0, x, y, th, tc, rot); };
        sides((w, h) => { const th = 0.075 * f; stick(w * 0.7, h * 0.66, set[0], th); stick(w * 0.27, h * 0.6, set[1], th * 0.85); });
        inR('T', (w, h) => stick(w * 0.83, h / 2, set[0], Math.min(0.14 * f, h * 0.12), 1));
      } else if (t === 13) {   // halftone dots, growing towards one end
        const cs = 0.085 * f, md = o;
        const dots = (w, h, along) => { g.fillStyle = c; for (let y = cs / 2; y < h; y += cs) for (let x = cs / 2; x < w; x += cs) {
          const k = md === 1 ? x / w : md === 2 ? y / h : md === 3 ? 1 - y / h : md === 4 ? (x / w + y / h) / 2 : 1 - x / w, r = cs * 0.5 * clamp((k - 0.15) / 0.85, 0, 1) * (along === false ? 0.6 : 1);
          if (r > 0.004) { g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); } } };
        all((w, h) => dots(w, h), md <= 1 ? (w, h) => dots(w, h, false) : null, null);
      } else if (t === 14) {   // tiger stripes: tapering claws in from the edges
        const sp = 0.34 * f;
        // a blade from the edge, swept back (x = rear → front), sometimes forked
        const spike = (x, y0, len, wd, dir, fork) => {
          const tip = x - wd * 0.9, yt = y0 + dir * len;
          g.beginPath(); g.moveTo(x - wd / 2, y0); g.quadraticCurveTo(x - wd * 0.45, y0 + dir * len * 0.55, tip, yt); g.quadraticCurveTo(x + wd * 0.2, y0 + dir * len * 0.5, x + wd / 2, y0); g.closePath();
          if (fork) { g.moveTo(x + wd * 0.1, y0 + dir * len * 0.3); g.quadraticCurveTo(x + wd * 0.3, y0 + dir * len * 0.62, x + wd * 0.75, y0 + dir * len * 0.78); g.quadraticCurveTo(x + wd * 0.35, y0 + dir * len * 0.45, x + wd * 0.35, y0 + dir * len * 0.25); g.closePath(); }
          if (c2) { g.lineJoin = 'round'; g.lineWidth = 0.025; g.strokeStyle = c2; g.stroke(); } g.fillStyle = c; g.fill(); };
        const tiger = (w, h, sd) => { for (let x = sp * 0.5, i = 0; x < w + sp; x += sp, i++) { const r1 = hash2(i, sd + o, 3), r2 = hash2(i, sd + o, 9);
          spike(x + (r1 - 0.5) * sp * 0.3, -0.02, h * (0.3 + 0.32 * r1), sp * 0.5, 1, r1 > 0.6); spike(x + sp * 0.5, h + 0.02, h * (0.24 + 0.3 * r2), sp * 0.44, -1, r2 > 0.7); } };
        all((w, h) => tiger(w, h, 1), (w, h) => tiger(w, h, 2), (w, h, fr) => tiger(w, h, fr ? 3 : 4));
      } else if (t === 15) {   // waves along the sides
        const wl = 0.9 * f;
        const wave = (w, yc, amp, th, col, ph) => { g.fillStyle = col; g.beginPath(); for (let x = 0; x <= w + 0.05; x += 0.04) g.lineTo(x, yc + Math.sin((x / wl) * 2 * PI + ph) * amp - th / 2);
          for (let x = w + 0.05; x >= -0.01; x -= 0.04) g.lineTo(x, yc + Math.sin((x / wl) * 2 * PI + ph) * amp + th / 2); g.closePath(); g.fill(); };
        const sd = (w, h) => { const yc = h * (0.55 - oo * 0.08), th = h * 0.075 * f; wave(w, yc, h * 0.07, th, c, 0); if (c2) wave(w, yc + th * 1.5, h * 0.07, th * 0.6, c2, 0.9); };
        all(sd, null, (w, h) => { const yc = h * (0.55 - oo * 0.08), th = h * 0.075 * f; rect(0, yc - th / 2, w, th, c); if (c2) rect(0, yc + th, w, th * 0.6, c2); });
      } else if (t === 16) {   // geometric triangles, denser towards one end
        const cs = 0.2 * f, md = o;
        const tri = (w, h, sd, side) => { for (let y = 0, j = 0; y < h; y += cs, j++) for (let x = 0, i = 0; x < w; x += cs, i++) for (let u = 0; u < 2; u++) {
          const cx = (x + cs / 2) / w, cy = (y + cs / 2) / h, k = md === 0 ? 1 - cx : md === 1 ? cx : md === 2 ? cy : md === 3 ? 1 - cy : 0.55, v = hash2(i * 2 + u, j, sd);
          if (v > k * 1.05 - 0.15 || (!side && md <= 1 && v > 0.5)) continue;
          g.fillStyle = c2 && hash2(i, j * 2 + u, sd + 7) < 0.4 ? c2 : c; g.beginPath();
          if (u) { g.moveTo(x, y); g.lineTo(x + cs, y); g.lineTo(x + cs, y + cs); } else { g.moveTo(x, y); g.lineTo(x, y + cs); g.lineTo(x + cs, y + cs); }
          g.closePath(); g.fill(); } };
        all((w, h) => tri(w, h, 1, true), (w, h) => tri(w, h, 2, true), (w, h, fr) => tri(w, h, fr ? 3 : 4, false));
      } else if (t === 17) {   // chequered band (two rows) around the car
        const cs = 0.1 * f;
        const band = (w, h) => { const y0 = h * (0.5 - oo * 0.09) - cs; for (let j = 0; j < 2; j++) for (let x = 0, i = 0; x < w; x += cs, i++) { const on = (i + j) % 2 === 0; if (!on && !c2) continue; g.fillStyle = on ? c : c2; g.fillRect(x, y0 + j * cs, cs * 1.01, cs * 1.01); } };
        all(band, null, band);
      } else if (t === 18) {   // splatter: blobs + drops, gathered low / rear / front / all over / high
        const blobs = (w, h, sd) => { for (let i = 0; i < 46; i++) {
          const r1 = hash2(i, sd, 1), r2 = hash2(i, sd, 2), r3 = hash2(i, sd, 3), x = w * (o === 1 ? r1 * r1 * 0.7 : o === 2 ? 1 - r1 * r1 * 0.7 : r1), y = h * (o === 0 ? 1 - r2 * r2 * 0.65 : o === 4 ? r2 * r2 * 0.6 : r2), r = (0.02 + 0.07 * r3 * r3) * f;
          g.fillStyle = c2 && hash2(i, sd, 4) < 0.3 ? c2 : c; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
          for (let k = 0; k < 3; k++) { const a = hash2(i, k, sd + 5) * 7, d = r * (1.4 + hash2(k, i, sd + 6) * 1.6); g.beginPath(); g.arc(x + Math.cos(a) * d, y + Math.sin(a) * d, r * 0.22, 0, 7); g.fill(); } } };
        all((w, h) => blobs(w, h, 1), (w, h) => blobs(w, h, 2), (w, h, fr) => blobs(w, h, fr ? 3 : 4));
      } else if (t === 20) {   // pinstripes: two fine lines along the waist (+ second colour between), bonnet edges
        const th = 0.008 + 0.006 * s;
        const line = (x0, x1, y, col, lw) => { g.strokeStyle = col; g.lineWidth = lw; g.lineCap = 'round'; g.beginPath(); g.moveTo(x0, y); g.lineTo(x1, y); g.stroke(); };
        sides((w, h) => { const y = h * (0.42 - oo * 0.07); line(w * 0.06, w * 0.94, y - th * 2, c, th); line(w * 0.06, w * 0.94, y + th * 2, c, th); if (c2) line(w * 0.08, w * 0.92, y, c2, th * 0.8); });
        inR('T', (w, h) => { for (const y of [h * 0.24, h * 0.76]) { line(w * 0.62, w * 0.97, y - th * 2, c, th); line(w * 0.62, w * 0.97, y + th * 2, c, th); if (c2) line(w * 0.64, w * 0.96, y, c2, th * 0.8); } });
      } else if (t === 21) {   // hex carbon: bonnet · bonnet + roof · all top · top + lower sides · everywhere
        const r = 0.032 * f, dx = r * Math.sqrt(3), dy = r * 1.5;
        // one seamless tile (2 rows of cells) drawn once, then filled as a pattern in metres — thousands of cells stay cheap
        const TP = 24, tw = Math.round(TP * Math.sqrt(3)), th = TP * 3, tc = document.createElement('canvas'); tc.width = tw; tc.height = th;
        const tg = tc.getContext('2d'); tg.fillStyle = shade(c, -0.8); tg.fillRect(0, 0, tw, th);
        for (const [cx, cy, k] of [[0, 0, 0], [tw, 0, 0], [tw / 2, th / 2, 1], [0, th, 0], [tw, th, 0]]) {
          tg.beginPath(); for (let i = 0; i < 6; i++) { const a = -PI / 2 + i * PI / 3; tg.lineTo(cx + Math.cos(a) * TP * 0.86, cy + Math.sin(a) * TP * 0.86); } tg.closePath();
          tg.fillStyle = shade(c, k ? -0.62 : -0.55); tg.fill(); if (c2) { tg.lineWidth = TP * 0.12; tg.strokeStyle = c2; tg.stroke(); } }
        const pat = g.createPattern(tc, 'repeat'), ok = pat && typeof pat.setTransform === 'function' && typeof DOMMatrix === 'function';
        if (ok) pat.setTransform(new DOMMatrix().scale(dx / tw, (2 * dy) / th));
        const hex = (x0, x1, y0, y1) => {
          if (ok) { g.fillStyle = pat; g.fillRect(x0, y0, x1 - x0, y1 - y0); return; }
          rect(x0, y0, x1 - x0, y1 - y0, shade(c, -0.8));
          for (let y = y0, j = 0; y < y1 + r; y += dy, j++) for (let x = x0 + (j % 2 ? dx / 2 : 0); x < x1 + dx; x += dx) {
            g.beginPath(); for (let i = 0; i < 6; i++) { const a = -PI / 2 + i * PI / 3; g.lineTo(x + Math.cos(a) * r * 0.86, y + Math.sin(a) * r * 0.86); } g.closePath();
            g.fillStyle = shade(c, -0.58); g.fill();
            if (c2) { g.lineWidth = r * 0.12; g.strokeStyle = c2; g.stroke(); } } };
        inR('T', (w, h) => (o === 0 ? hex(w * 0.72, w, 0, h) : o === 1 ? (hex(w * 0.72, w, 0, h), hex(w * 0.36, w * 0.66, 0, h)) : hex(0, w, 0, h)));
        if (o >= 3) sides((w, h) => hex(0, w, o === 3 ? h * 0.74 : 0, h));
        if (o === 4) all(null, null, (w, h) => hex(0, w, 0, h));
      } else if (t === 22) {   // swoosh: one sweeping curve from the front low to the rear high
        sides((w, h) => {
          const th = h * 0.12 * f, y0 = h * (0.3 - oo * 0.06);
          const curve = (dy) => { g.moveTo(w * 1.02, h * 0.8 + dy); g.quadraticCurveTo(w * 0.45, h * 0.86 + dy, -0.02, y0 + dy); };
          if (c2) { g.beginPath(); curve(th * 1.5); g.lineWidth = th * 0.25; g.strokeStyle = c2; g.stroke(); }
          g.beginPath(); g.moveTo(w * 1.02, h * 0.8); g.quadraticCurveTo(w * 0.45, h * 0.86, -0.02, y0); g.lineTo(-0.02, y0 + th * 0.4); g.quadraticCurveTo(w * 0.45, h * 0.86 + th * 1.2, w * 1.02, h * 0.8 + th); g.closePath(); g.fillStyle = c; g.fill();
        });
      } else if (t === 23) {   // zigzag band along the sides
        const p = 0.3 * f;
        const zz = (w, h) => { const hc = h * (0.5 - oo * 0.08), amp = h * 0.06 * f, th = h * 0.05 * f, top = [];
          for (let x = -p, i = 0; x <= w + p; x += p / 2, i++) top.push([x, hc + (i % 2 ? amp : -amp) - th / 2]);
          g.beginPath(); top.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); for (let i = top.length - 1; i >= 0; i--) g.lineTo(top[i][0], top[i][1] + th); g.closePath();
          if (c2) { g.lineJoin = 'miter'; g.lineWidth = 0.03; g.strokeStyle = c2; g.stroke(); } g.fillStyle = c; g.fill(); };
        all(zz, null, null);
      } else if (t === 24 || t === 25) {   // woodland camo (soft blobs) · splinter camo (sharp shards) — three tones over the paint
        const cols = [c, c2 || shade(c, lumOf(c) > 0.5 ? -0.3 : 0.35), shade(c, -0.55)], sz = 0.22 * f;
        const camo = (w, h, sd) => {
          const n = Math.ceil(((w * h) / (sz * sz)) * 1.1);
          for (let i = 0; i < n; i++) {
            const x = hash2(i, sd, 1 + o) * w, y = hash2(i, sd, 2 + o) * h, r = sz * (0.5 + hash2(i, sd, 3) * 0.8);
            g.fillStyle = cols[i % 3]; g.beginPath();
            if (t === 24) {
              const k = 9, pts = [];
              for (let j = 0; j < k; j++) { const a = (j / k) * PI * 2, q = r * (0.6 + 0.5 * hash2(i, j, sd + 9)); pts.push([x + Math.cos(a) * q * 1.4, y + Math.sin(a) * q * 0.8]); }
              for (let j = 0; j <= k; j++) { const p0 = pts[j % k], p1 = pts[(j + 1) % k], mx = (p0[0] + p1[0]) / 2, my = (p0[1] + p1[1]) / 2; if (j) g.quadraticCurveTo(p0[0], p0[1], mx, my); else g.moveTo(mx, my); }
            } else {
              const a = -0.5 + hash2(i, sd, 4) * 0.4, L = r * 2.2, W2 = r * 0.5, ca = Math.cos(a), sa = Math.sin(a);
              [[-L, -W2 * 0.2], [L * 0.2, -W2], [L, W2 * 0.1], [-L * 0.3, W2]].forEach(([px, py], j) => { const X = x + px * ca - py * sa, Y = y + px * sa + py * ca; if (j) g.lineTo(X, Y); else g.moveTo(X, Y); });
            }
            g.closePath(); g.fill();
          }
        };
        all((w, h) => camo(w, h, 1), (w, h) => camo(w, h, 2), (w, h, fr) => camo(w, h, fr ? 3 : 4));
      } else if (t === 26) {   // honeycomb outlines (+ a few filled cells in the second colour)
        const r = 0.07 * f, dx = r * Math.sqrt(3), dy = r * 1.5, lw = 0.012 * f + 0.004;
        const hc = (w, h, sd) => { g.lineWidth = lw; g.strokeStyle = c; g.lineJoin = 'round';
          for (let y = 0, j = 0; y < h + r; y += dy, j++) for (let x = j % 2 ? dx / 2 : 0, i = 0; x < w + dx; x += dx, i++) {
            g.beginPath(); for (let k = 0; k < 6; k++) { const a = -PI / 2 + (k * PI) / 3; g.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } g.closePath();
            if (c2 && hash2(i, j, sd + o) < 0.08 + o * 0.06) { g.fillStyle = c2; g.fill(); } g.stroke(); } };
        all((w, h) => hc(w, h, 1), (w, h) => hc(w, h, 2), (w, h, fr) => hc(w, h, fr ? 3 : 4));
      } else if (t === 27) {   // carbon twill weave (a tile filled as a pattern — cheap), coverage like hex carbon
        const TP = 16, tc = document.createElement('canvas'); tc.width = tc.height = TP * 4; const tg = tc.getContext('2d');
        tg.fillStyle = shade(c, -0.82); tg.fillRect(0, 0, TP * 4, TP * 4);
        for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) { const k = (i + j) % 4 < 2; tg.fillStyle = k ? shade(c, -0.55) : c2 ? shade(c2, -0.25) : shade(c, -0.7); tg.fillRect(i * TP + 1, j * TP + 1, TP - 2, TP - 2);
          tg.fillStyle = 'rgba(255,255,255,0.07)'; if (k) tg.fillRect(i * TP + 1, j * TP + 1, TP - 2, (TP - 2) * 0.35); else tg.fillRect(i * TP + 1, j * TP + 1, (TP - 2) * 0.35, TP - 2); }
        const pat = g.createPattern(tc, 'repeat'), ok = pat && typeof pat.setTransform === 'function' && typeof DOMMatrix === 'function', cs = 0.016 * f;
        if (ok) pat.setTransform(new DOMMatrix().scale((cs * 4) / (TP * 4), (cs * 4) / (TP * 4)));
        const cf = (x0, x1, y0, y1) => { g.fillStyle = ok ? pat : shade(c, -0.7); g.fillRect(x0, y0, x1 - x0, y1 - y0); };
        inR('T', (w, h) => (o === 0 ? cf(w * 0.72, w, 0, h) : o === 1 ? (cf(w * 0.72, w, 0, h), cf(w * 0.36, w * 0.66, 0, h)) : cf(0, w, 0, h)));
        if (o >= 3) sides((w, h) => cf(0, w, o === 3 ? h * 0.74 : 0, h));
        if (o === 4) all(null, null, (w, h) => cf(0, w, 0, h));
      } else if (t === 28) {   // overlapping scales (round · pointed), lower rows over upper
        const r = 0.1 * f, dx = r * 1.6, dy = r * 0.85, pointed = o % 2 === 1, edge = c2 || shade(c, lumOf(c) > 0.5 ? -0.35 : 0.35);
        const sc = (w, h, sd) => { g.lineWidth = 0.008; g.strokeStyle = edge;
          for (let y = -r, j = 0; y < h + r; y += dy, j++) for (let x = (j % 2 ? dx / 2 : 0) - dx, i = 0; x < w + dx; x += dx, i++) {
            g.beginPath(); g.moveTo(x - r, y);
            if (pointed) { g.quadraticCurveTo(x - r, y + r * 0.9, x, y + r * 1.25); g.quadraticCurveTo(x + r, y + r * 0.9, x + r, y); } else g.arc(x, y, r, PI, 0, true);
            g.closePath(); g.fillStyle = hash2(i, j, sd) < 0.5 ? c : shade(c, lumOf(c) > 0.5 ? -0.08 : 0.08); g.fill(); g.stroke(); } };
        all((w, h) => sc(w, h, 1), (w, h) => sc(w, h, 2), (w, h, fr) => sc(w, h, fr ? 3 : 4));
      } else if (t === 29) {   // paint poured on the roof: the top covered, drips running down the sides · ends
        const len = 0.25 + 0.12 * o;
        const drip = (w, h, sd) => { const band = h * 0.1 * f; rect(-0.05, -0.05, w + 0.1, band + 0.05, c);
          for (let x = 0.03, i = 0; x < w; x += (0.07 + hash2(i, sd, 1) * 0.12) * f, i++) {
            const dw = (0.022 + hash2(i, sd, 2) * 0.035) * f, dl = band + h * len * (0.15 + hash2(i, sd, 3) * 0.85);
            g.fillStyle = c2 && hash2(i, sd, 5) < 0.3 ? c2 : c; g.fillRect(x - dw / 2, 0, dw, dl); g.beginPath(); g.arc(x, dl, dw * 0.75, 0, 7); g.fill(); } };
        all((w, h) => drip(w, h, 1), (w, h) => rect(0, 0, w, h, c), (w, h, fr) => drip(w, h, fr ? 3 : 4));
      } else if (t === 30) {   // halftone lines: lines that thicken towards one end
        const sp = 0.05 * f, kOf = (u, v) => clamp(((o === 1 ? u : o === 2 ? v : o === 3 ? 1 - v : o === 4 ? (u + v) / 2 : 1 - u) - 0.1) / 0.9, 0, 1);
        const ln = (w, h) => { g.fillStyle = c; for (let y = sp / 2; y < h; y += sp) { const N = 24; g.beginPath();
          for (let i = 0; i <= N; i++) { const x = (w * i) / N; g.lineTo(x, y - (sp * 0.9 * kOf(x / w, y / h)) / 2); }
          for (let i = N; i >= 0; i--) { const x = (w * i) / N; g.lineTo(x, y + (sp * 0.9 * kOf(x / w, y / h)) / 2); } g.closePath(); g.fill(); } };
        all(ln, ln, null);
      } else if (t === 31) {   // speed lines streaming back from the nose
        const sl = (w, h, sd) => { for (let i = 0; i < 26; i++) {
          const y = h * (0.15 + 0.75 * hash2(i, sd, 1)), len = w * (0.15 + 0.45 * hash2(i, sd, 2)) * f, x1 = w * (0.62 + 0.36 * hash2(i, sd, 3)) + oo * 0.1 * w, th = (0.006 + 0.018 * hash2(i, sd, 4)) * f;
          const col = c2 && hash2(i, sd, 5) < 0.35 ? c2 : c, gr = g.createLinearGradient(x1 - len, 0, x1, 0); gr.addColorStop(0, shade(col, 0, 0)); gr.addColorStop(1, shade(col, 0, 1));
          g.fillStyle = gr; g.beginPath(); g.moveTo(x1 - len, y); g.lineTo(x1, y - th); g.quadraticCurveTo(x1 + th * 2, y, x1, y + th); g.closePath(); g.fill(); } };
        all((w, h) => sl(w, h, 1), (w, h) => sl(w, h, 3), null);
      } else if (t === 32) {   // tribal flames: sharp curved blades sweeping back from the nose
        const tri = (w, h, sd, n) => { for (let i = 0; i < n; i++) {
          const yc = h * (0.25 + (0.5 * (i + 0.5)) / n - oo * 0.07), len = w * (0.35 + 0.25 * hash2(i, sd, 1)) * (0.8 + 0.1 * s), th = h * 0.11 * f, bend = h * (hash2(i, sd, 2) - 0.5) * 0.5;
          g.beginPath(); g.moveTo(w + 0.05, yc - th); g.bezierCurveTo(w - len * 0.4, yc - th + bend * 0.2, w - len * 0.7, yc + bend, w - len, yc + bend * 1.4 - th * 0.2);
          g.bezierCurveTo(w - len * 0.65, yc + bend * 0.9 + th * 0.4, w - len * 0.35, yc + th * 0.6, w + 0.05, yc + th); g.closePath();
          if (c2) { g.lineJoin = 'round'; g.lineWidth = 0.03; g.strokeStyle = c2; g.stroke(); } g.fillStyle = c; g.fill(); } };
        sides((w, h) => tri(w, h, 1, 4)); inR('T', (w, h) => tri(w, h, 2, 5)); inR('F', (w, h) => rect(0, h * 0.2, w, h * 0.6, c));
      } else if (t === 33) {   // polka dots (offset rows)
        const sp = 0.16 * f, r = sp * (0.16 + 0.05 * o);
        const pd = (w, h) => { for (let y = sp / 2, j = 0; y < h + sp; y += sp * 0.866, j++) for (let x = j % 2 ? sp / 2 : 0, i = 0; x < w + sp; x += sp, i++) { g.fillStyle = c2 && (i + j) % 3 === 0 ? c2 : c; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); } };
        all(pd, pd, pd);
      } else if (t === 34) {   // diagonal (candy) stripes everywhere
        const sw = 0.09 * f, per = sw * (2 + o * 0.5);
        const band = (x, h, wd, col) => { g.fillStyle = col; g.beginPath(); g.moveTo(x, h); g.lineTo(x + wd, h); g.lineTo(x + wd + h, 0); g.lineTo(x + h, 0); g.closePath(); g.fill(); };
        const ds = (w, h) => { for (let x = -h - per; x < w + h; x += per) { band(x, h, sw, c); if (c2) band(x + sw + (per - sw) / 2 - sw * 0.25, h, sw * 0.5, c2); } };
        all(ds, ds, ds);
      } else if (t === 35) {   // topographic contour lines (value noise, marching squares)
        const cs = 0.03, lv = 7 + o * 2, sc = 0.9 * f;
        const vn = (x, y, k) => { const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
          const a = hash2(xi, yi, k), b = hash2(xi + 1, yi, k), e = hash2(xi, yi + 1, k), d = hash2(xi + 1, yi + 1, k); return a + (b - a) * u + (e - a) * v + (a - b - e + d) * u * v; };
        const nz = (x, y, sd) => vn(x / sc, y / sc, sd) * 0.7 + vn((x / sc) * 2.3, (y / sc) * 2.3, sd + 3) * 0.3;
        const ct = (w, h, sd) => {
          const nx = Math.ceil(w / cs) + 2, ny = Math.ceil(h / cs) + 2, F = new Float32Array(nx * ny);
          for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) F[j * nx + i] = nz(i * cs, j * cs, sd);
          g.lineWidth = 0.008 * f + 0.004; g.lineCap = 'round';
          for (let L1 = 1; L1 < lv; L1++) {
            const iso = L1 / lv; g.strokeStyle = c2 && L1 % 4 === 0 ? c2 : c; g.beginPath();
            for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) {
              const a = F[j * nx + i], b = F[j * nx + i + 1], d = F[(j + 1) * nx + i + 1], e = F[(j + 1) * nx + i];
              if ((a < iso) === (b < iso) && (b < iso) === (d < iso) && (d < iso) === (e < iso)) continue;
              const pts = [], X0 = i * cs, Y0 = j * cs, X1 = X0 + cs, Y1 = Y0 + cs;
              const edge = (v0, v1, x0, y0, x1, y1) => { if ((v0 < iso) !== (v1 < iso)) { const k = (iso - v0) / (v1 - v0); pts.push([x0 + (x1 - x0) * k, y0 + (y1 - y0) * k]); } };
              edge(a, b, X0, Y0, X1, Y0); edge(b, d, X1, Y0, X1, Y1); edge(d, e, X1, Y1, X0, Y1); edge(e, a, X0, Y1, X0, Y0);
              if (pts.length >= 2) { g.moveTo(pts[0][0], pts[0][1]); g.lineTo(pts[1][0], pts[1][1]); if (pts.length === 4) { g.moveTo(pts[2][0], pts[2][1]); g.lineTo(pts[3][0], pts[3][1]); } }
            }
            g.stroke();
          }
        };
        all((w, h) => ct(w, h, 1), (w, h) => ct(w, h, 2), (w, h, fr) => ct(w, h, fr ? 3 : 4));
      } else if (t === 36) {   // circuit traces: grid walks with 45° turns, pads at the ends
        const gs = 0.05 * f;
        const cir = (w, h, sd) => { g.lineWidth = gs * 0.22; g.lineCap = 'round'; g.lineJoin = 'round'; const n = Math.max(4, Math.round((w * h) / (gs * gs) / (9 + (4 - o) * 3)));
          for (let i = 0; i < n; i++) {
            let x = Math.floor((hash2(i, sd, 1) * w) / gs) * gs, y = Math.floor((hash2(i, sd, 2) * h) / gs) * gs, dir = Math.floor(hash2(i, sd, 3) * 4) * 2;
            g.strokeStyle = c; g.beginPath(); g.moveTo(x, y); g.fillStyle = c2 || c; const x0 = x, y0 = y;
            const steps = 3 + Math.floor(hash2(i, sd, 4) * 8);
            for (let k = 0; k < steps; k++) { const len = 1 + Math.floor(hash2(i, k, sd + 5) * 3); x += [1, 1, 0, -1, -1, -1, 0, 1][dir] * gs * len; y += [0, 1, 1, 1, 0, -1, -1, -1][dir] * gs * len; g.lineTo(x, y);
              const r = hash2(k, i, sd + 6); if (r < 0.3) dir = (dir + 1) % 8; else if (r < 0.6) dir = (dir + 7) % 8; }
            g.stroke(); for (const [px, py] of [[x0, y0], [x, y]]) { g.beginPath(); g.arc(px, py, gs * 0.35, 0, 7); g.fill(); }
          } };
        all((w, h) => cir(w, h, 1), (w, h) => cir(w, h, 2), (w, h, fr) => cir(w, h, fr ? 3 : 4));
      } else if (t === 37) {   // scattered four-point stars (twinkles), a few big ones
        const st = (w, h, sd) => { const n = Math.round(((w * h) * 30 * (0.5 + o * 0.3)) / (f * f));
          for (let i = 0; i < n; i++) { const x = hash2(i, sd, 1) * w, y = hash2(i, sd, 2) * h, r = (0.02 + 0.075 * Math.pow(hash2(i, sd, 3), 3)) * f;
            g.fillStyle = c2 && hash2(i, sd, 4) < 0.3 ? c2 : c; g.beginPath(); for (let k = 0; k < 8; k++) { const a = -PI / 2 + (k * PI) / 4, q = k % 2 ? r * 0.3 : r; g.lineTo(x + Math.cos(a) * q, y + Math.sin(a) * q); } g.closePath(); g.fill(); } };
        all((w, h) => st(w, h, 1), (w, h) => st(w, h, 2), (w, h, fr) => st(w, h, fr ? 3 : 4));
      } else if (t === 38) {   // loose brush strokes with bristle streaks
        const bs = (w, h, sd) => { const n = 5 + o * 2;
          for (let i = 0; i < n; i++) {
            const x0 = w * hash2(i, sd, 1) * 0.9, y0 = h * (0.15 + 0.7 * hash2(i, sd, 2)), len = w * (0.25 + 0.35 * hash2(i, sd, 3)) * f, th = h * (0.07 + 0.08 * hash2(i, sd, 4)) * f, a = (hash2(i, sd, 5) - 0.5) * 0.6;
            const col = c2 && i % 3 === 1 ? c2 : c, N = 18;
            g.save(); g.translate(x0, y0); g.rotate(a); g.fillStyle = col; g.beginPath();
            for (let k = 0; k <= N; k++) { const u = k / N, wv = th * (0.55 + 0.45 * Math.sin(u * PI)) * (0.85 + 0.3 * hash2(k, i, sd + 7)); g.lineTo(u * len, -wv / 2 + Math.sin(u * 5 + i) * th * 0.15); }
            for (let k = N; k >= 0; k--) { const u = k / N, wv = th * (0.55 + 0.45 * Math.sin(u * PI)) * (0.85 + 0.3 * hash2(i, k, sd + 8)); g.lineTo(u * len, wv / 2 + Math.sin(u * 5 + i) * th * 0.15); }
            g.closePath(); g.fill();
            g.strokeStyle = shade(col, lumOf(col) > 0.5 ? -0.25 : 0.25, 0.6); g.lineWidth = th * 0.04;
            for (let b = 0; b < 5; b++) { const yy = (hash2(b, i, sd + 9) - 0.5) * th * 0.7; g.beginPath(); g.moveTo(len * 0.05, yy); g.lineTo(len * (0.6 + 0.35 * hash2(i, b, sd)), yy + Math.sin(b) * th * 0.05); g.stroke(); }
            g.restore();
          } };
        all((w, h) => bs(w, h, 1), (w, h) => bs(w, h, 2), (w, h, fr) => bs(w, h, fr ? 3 : 4));
      }
    }
    // ---- race number (both sides, + roof) ----
    if (cu.n > 0) {
      any = true; fontN = FONTS[cu.nf | 0] || FONT;
      const ns = cu.ns | 0, nc = cu.nc || (ns === 3 ? '#f4f4f0' : '#111111'), str = String(cu.n | 0);
      const disc = (x, y, r, rot) => {
        if (ns === 0 || ns === 3) { g.beginPath(); g.arc(x, y, r, 0, 7); g.fillStyle = ns === 3 ? '#141416' : '#f4f4f0'; g.fill(); g.lineWidth = r * 0.08; g.strokeStyle = ns === 3 ? '#f4f4f0' : '#111111'; g.stroke(); }
        else if (ns === 1) { g.fillStyle = '#f4f4f0'; rrect(x - r, y - r * 0.85, 2 * r, 1.7 * r, r * 0.18); g.fill(); }
        text(str, x, y, r * (str.length > 1 ? 1.05 : 1.25), nc, rot, ns === 2 ? (lumOf(nc) > 0.5 ? '#111111' : '#f4f4f0') : null);
      };
      sides((w, h) => disc(w * 0.53, D.top - D.top * 0.42 - (D.top - D.bot - h), clamp(D.top * 0.22, 0.16, 0.3)));
      if (cu.nh) inR('T', (w, h) => disc(w * 0.47, h / 2, Math.min(h * 0.24, 0.42)));
    }
    return any;
  }
  /* 차 공간의 점(+ 법선) → 스티커 자리 [면, 가로 0~200, 세로 0~200]. face를 주면 그 면으로(끌어 옮길 때), 아니면 법선이 가장 큰 쪽(셰이더가 가장 많이 쓰는 결) */
  function decalSpot(P, N, D, face) {
    const Lm = D.front - D.rear, Hm = Math.max(0.5, D.top - D.bot), hx = D.half, Wm = 2 * hx;
    let f = face;
    if (f == null) {
      const ax = Math.abs(N.x), ay = N.y > -0.25 ? Math.abs(N.y) : 0, az = Math.abs(N.z);
      f = ax >= ay && ax >= az ? (N.x < 0 ? 0 : 1) : ay >= az ? 2 : N.z > 0 ? 3 : 4;
    }
    const yTop = D.bot + Hm - P.y;
    const xy = f <= 1 ? [(P.z - D.rear) / Lm, yTop / Hm] : f === 2 ? [(P.z - D.rear) / Lm, (hx - P.x) / Wm] : f === 3 ? [(P.x + hx) / Wm, yTop / Hm] : [(hx - P.x) / Wm, yTop / Hm];
    return [f, Math.round(clamp(xy[0], 0, 1) * 200), Math.round(clamp(xy[1], 0, 1) * 200)];
  }
  const CUST_CSS = `
    .hr-ls{display:flex;gap:5px;overflow-x:auto;padding:2px 0 6px;margin-bottom:2px;scrollbar-width:thin;min-height:50px;align-items:center}
    .hr-lt{position:relative;flex:0 0 auto;width:58px;height:48px;padding:0;border-radius:10px;border:2px solid rgba(255,255,255,.18);background:#2a2433;overflow:hidden;cursor:pointer}
    .hr-lt img{display:block;width:100%;height:100%;object-fit:cover;pointer-events:none}
    .hr-lt i{position:absolute;left:3px;top:1px;font:700 10px/1.2 var(--f-mono,monospace);font-style:normal;color:#fff;text-shadow:0 0 3px #000,0 0 2px #000}
    .hr-lt.sel{border-color:var(--brass);box-shadow:0 0 0 2px rgba(227,174,69,.4)}
    .hr-kinds{display:flex;flex-wrap:wrap;gap:4px;margin:2px 0 8px}
    .hr-kd{width:46px;height:46px;padding:0;border-radius:10px;border:2px solid rgba(255,255,255,.14);background:#2a2433;cursor:pointer;flex:0 0 auto;overflow:hidden}
    .hr-kd img{display:block;width:100%;height:100%;pointer-events:none}
    .hr-kd.wide{width:94px}
    .hr-kd.sel{border-color:var(--brass);box-shadow:0 0 0 2px rgba(227,174,69,.4)}
    .hr-pick .hr-rr{flex-wrap:nowrap;margin:0 0 4px}
    .hr-rg{flex:1 1 auto;min-width:0;height:44px;accent-color:#e3ae45;margin:0;cursor:pointer}
    .hr-rv{min-width:50px;text-align:right;font:600 13px var(--f-mono,monospace)}
    .hr-seg .hr-ur{flex:0 0 44px;min-width:44px;display:flex;align-items:center;justify-content:center;padding:0}
    .hr-seg .hr-ur:disabled{opacity:.3;cursor:default}
    .hr-chip:disabled{opacity:.38;cursor:default}
    .hr-tpl{display:grid;grid-template-columns:repeat(auto-fill,minmax(132px,1fr));gap:6px;margin:4px 0 12px}
    .hr-tp{display:flex;align-items:center;gap:7px;justify-content:flex-start;text-align:left;padding:0 9px}
    .hr-tp .hr-pre{flex:0 0 auto;min-width:0}.hr-tp .hr-pre i{width:10px;height:24px}
    .hr-hint{color:#9fd8ff}
    .hr-pick.cmp .hr-kinds{flex-wrap:nowrap;overflow-x:auto;padding-bottom:3px}
    .hr-pick.cmp .hr-seg.hr-sub button{font-size:12.5px}
    .hr-pick.cmp .hr-sh{margin-right:34px}
    .hr-llh{margin-bottom:2px!important}.hr-llh .lbl{width:auto;flex:1 1 140px}
    .hr-ll{display:flex;flex-direction:column;gap:4px;max-height:min(232px,34vh);overflow-y:auto;overscroll-behavior:contain;margin:0 0 8px;padding:2px;border-radius:12px;background:rgba(0,0,0,.18);touch-action:pan-y}
    .hr-lr{display:flex;align-items:center;gap:2px;min-height:44px;border-radius:10px;border:2px solid transparent;background:rgba(255,255,255,.04);position:relative;flex:0 0 auto}
    .hr-lr.sel{border-color:var(--brass);background:rgba(227,174,69,.12)}.hr-lr.ms{border-color:rgba(159,216,255,.8);background:rgba(159,216,255,.1)}
    .hr-lr.hid .hr-lb{opacity:.45}.hr-lr.drag{z-index:3;box-shadow:0 6px 18px rgba(0,0,0,.5);background:#2d2638}
    .hr-lr.dropa{box-shadow:inset 0 3px 0 #9fd8ff}.hr-lr.dropb{box-shadow:inset 0 -3px 0 #9fd8ff}
    .hr-lg{flex:0 0 30px;align-self:stretch;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.55);cursor:grab;touch-action:none}
    .hr-lb{flex:1 1 auto;min-width:0;min-height:44px;display:flex;align-items:center;gap:8px;padding:0 4px;border:0;background:none;color:var(--ink);text-align:left;cursor:pointer}
    .hr-lb img{flex:0 0 auto;width:52px;height:40px;border-radius:7px;border:1px solid rgba(255,255,255,.18);object-fit:cover}
    .hr-ln{display:flex;flex-direction:column;min-width:0}.hr-ln b{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.hr-ln small{font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .hr-li{flex:0 0 44px;width:44px;height:44px;border:0;border-radius:9px;background:none;color:rgba(255,255,255,.4);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}
    .hr-li.on{color:#fff}.hr-lr .hr-li:last-child.on{color:var(--brass)}
    .hr-multi b{font-size:12px;color:#9fd8ff;font-weight:600;width:100%}
    .hr-seg.hr-kg{margin:0 0 6px}.hr-seg.hr-kg button{font-size:12.5px}
    .hr-nums{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:6px;margin:4px 0 10px}
    .hr-nf{display:flex;flex-direction:column;gap:2px;font-size:11px;color:var(--muted);position:relative}
    .hr-nin{min-height:44px;width:100%;box-sizing:border-box;border-radius:10px;border:1px solid rgba(255,255,255,.25);background:rgba(0,0,0,.25);color:var(--ink);font:600 15px var(--f-mono,monospace);padding:0 26px 0 8px;user-select:text;-webkit-user-select:text}
    .hr-nf i{position:absolute;right:8px;bottom:13px;font-style:normal;font-size:11px;color:var(--muted);pointer-events:none}
    .hr-lh .hr-lname{flex:1 1 auto;min-height:44px;font-size:14px}
    .hr-rl{margin-top:-4px!important}.hr-rl .hr-chip{font-size:12px;padding:0 9px}
    .hr-code{font:12px var(--f-mono,monospace)!important}
    .hr-sv{display:block;width:100%;height:120px;border-radius:10px;touch-action:none;cursor:crosshair;margin:2px 0 6px}
    .hr-hrow{margin:0 0 6px!important}.hr-hue{width:100%;height:44px;margin:0;-webkit-appearance:none;appearance:none;background:transparent;cursor:pointer}
    .hr-hue::-webkit-slider-runnable-track{height:14px;border-radius:7px;background:linear-gradient(90deg,red,#ff0,lime,cyan,blue,#f0f,red)}
    .hr-hue::-moz-range-track{height:14px;border-radius:7px;background:linear-gradient(90deg,red,#ff0,lime,cyan,blue,#f0f,red)}
    .hr-hue::-webkit-slider-thumb{-webkit-appearance:none;width:26px;height:26px;margin-top:-6px;border-radius:50%;background:#fff;border:3px solid #222}
    .hr-hex{flex:0 1 120px!important;font-family:var(--f-mono,monospace)}
    .hr-svw{width:44px;height:44px;border-radius:10px;border:2px solid rgba(255,255,255,.3);flex:0 0 auto}
    .hr-gz{position:absolute;left:0;top:0;width:0;height:0;pointer-events:none}
    .hr-gk{position:absolute;left:0;top:0;width:44px;height:44px;border-radius:50%;border:0;padding:0;background:none;pointer-events:auto;touch-action:none;cursor:pointer;color:#1b1408;font:700 17px/44px var(--f-body,sans-serif);text-align:center}
    .hr-gk::before{content:'';position:absolute;left:9px;top:9px;width:26px;height:26px;border-radius:50%;background:rgba(255,214,110,.92);border:2px solid #1b1408;box-shadow:0 1px 5px rgba(0,0,0,.55);z-index:-1}
    .hr-gk-c::before{left:14px;top:14px;width:16px;height:16px;background:rgba(255,255,255,.95)}.hr-gk-c{cursor:move}
    .hr-gk-r{cursor:alias}.hr-gk-s{cursor:nwse-resize}.hr-gk-w{cursor:ew-resize}.hr-gk-h{cursor:ns-resize}
    .hr-gl{position:absolute;left:0;top:0;height:2px;margin-top:-1px;transform-origin:0 50%;background:rgba(255,214,110,.85);box-shadow:0 0 3px rgba(0,0,0,.7);pointer-events:none}
  `;
  /* 면의 크기(미터) [가로, 세로] */
  function decalExt(D, f) { const Lm = D.front - D.rear, Hm = Math.max(0.5, D.top - D.bot), Wm = 2 * D.half; return f <= 1 ? [Lm, Hm] : f === 2 ? [Lm, Wm] : [Wm, Hm]; }
  let measG = null;
  const decalW = (l) => { if (!measG) measG = document.createElement('canvas').getContext('2d'); const X = xOf(l); return decShape(measG, l[0], '', '', l[10] || 'A', true, X) * ((X.w || 100) / 100); };
  /* 겹 그림(목록 칸): 무늬 = 작은 옆모습에 구워 가운데를 잘라 봄 · 스티커 = 모양 그대로 */
  const iconCache = new Map();
  function layerIcon(l, base, w, h) {
    const key = JSON.stringify([l, base, w, h]);
    let u = iconCache.get(key); if (u) return u;
    const cv = document.createElement('canvas'); cv.width = w * 2; cv.height = h * 2; const g = cv.getContext('2d');
    g.fillStyle = base || '#9aa3ab'; g.fillRect(0, 0, cv.width, cv.height);
    const X = xOf(l), X1 = Object.assign({}, X); delete X1.v; delete X1.m;   // the thumbnail shows hidden / masked layers too
    if (isDecT(l[0])) {
      const st = (X.w || 100) / 100, k = Math.min(cv.width / (decShape(g, l[0], '', '', l[10] || 'A', true, X) * st + 0.3), cv.height / 1.3);
      const sc = document.createElement('canvas'); sc.width = cv.width; sc.height = cv.height; const sg = sc.getContext('2d');
      sg.translate(cv.width / 2, cv.height / 2); sg.scale(k, k); if (l[7] & 2) sg.scale(-1, 1); if (X.k) sg.transform(1, 0, -Math.tan((X.k * PI) / 180), 1, 0, 0); sg.scale(st, 1);
      const w = decShape(sg, l[0], l[1], l[9] || '', l[10] || 'A', false, X);
      if (X.g) { sg.globalCompositeOperation = 'source-atop'; sg.fillStyle = gradOf(sg, X.g[1] | 0, -w / 2, -0.5, w, 1, X.g[0]); sg.fillRect(-w, -1, 2 * w, 2); }
      g.drawImage(sc, 0, 0);
    } else {
      const W = 512, tc = document.createElement('canvas'), l1 = l.slice(); tc.width = tc.height = W;
      if (l1.length && typeof l1[l1.length - 1] === 'object') l1[l1.length - 1] = X1;
      bakeDecal(tc.getContext('2d'), W, { L: [l1] }, { rear: 0, front: 4.4, top: 1.25, bot: 0, half: 0.95 });
      g.globalAlpha = 1; g.drawImage(tc, W * 0.18, 0, W * 0.64, W / 4, 0, 0, cv.width, cv.height);
    }
    u = cv.toDataURL();
    if (iconCache.size > 300) iconCache.clear();
    iconCache.set(key, u);
    return u;
  }
  /* 도색 셰이더: 색상 회전 · 곱하는 색 + 구운 무늬 결(옆 · 위 · 앞뒤를 법선으로 섞음) + 펄 색 변화(가장자리) + 메탈 입자 */
  const PAINT_HEAD = 'uniform float uHue, uSat, uDecOn, uPearlK, uFlake, uFinOn;\nuniform vec3 uTint, uPearl;\nuniform vec4 uD0;\nuniform vec2 uD1;\nuniform sampler2D uDec, uFin;\nvarying vec3 vOP;\nvarying vec3 vON;\n';
  const PAINT_MAP = `
    vec2 hrS = vec2(0.0), hrT = vec2(0.0), hrE = vec2(0.0); vec3 hrW = vec3(0.0); float hrMatte = 0.0;
    { vec3 c = diffuseColor.rgb; float l = dot(c, vec3(0.299, 0.587, 0.114)); vec3 k = vec3(0.57735); float cs = cos(uHue), sn = sin(uHue);
      c = c * cs + cross(k, c) * sn + k * dot(k, c) * (1.0 - cs); c = max(mix(vec3(l), c, uSat), 0.0) * uTint;
      if (uDecOn > 0.5 && gl_FrontFacing) {
        vec3 nn = normalize(vON), a = abs(nn), w = a * a; w = w * w; w /= (w.x + w.y + w.z + 1e-5);
        float al = clamp((vOP.z - uD0.x) / (uD0.y - uD0.x), 0.0, 1.0), hv = clamp((vOP.y - uD0.z) / (uD0.w - uD0.z), 0.0, 1.0), ac = clamp((vOP.x + uD1.x) / (2.0 * uD1.x), 0.0, 1.0), e = uD1.y;
        float hq = mix(e * 4.0, 1.0 - e * 4.0, hv) * 0.25;
        vec2 uS = nn.x < 0.0 ? vec2(mix(e, 1.0 - e, al), 0.75 + hq) : vec2(mix(e, 1.0 - e, 1.0 - al), 0.5 + hq);
        vec2 uT = vec2(mix(e, 1.0 - e, al), 0.25 + mix(e * 4.0, 1.0 - e * 4.0, ac) * 0.25);
        vec2 uE = nn.z > 0.0 ? vec2(mix(e, 0.5 - e, ac), hq) : vec2(mix(0.5 + e, 1.0 - e, 1.0 - ac), hq);
        vec4 s1 = texture2D(uDec, uS), s2 = texture2D(uDec, uT), s3 = texture2D(uDec, uE);
        float wy = nn.y > -0.25 ? w.y : 0.0;
        hrS = uS; hrT = uT; hrE = uE; hrW = vec3(w.x, wy, w.z);
        float A = s1.a * w.x + s2.a * wy + s3.a * w.z;
        c = c * (1.0 - A) + s1.rgb * s1.a * w.x + s2.rgb * s2.a * wy + s3.rgb * s3.a * w.z;
      }
      diffuseColor.rgb = c; }`;
  // 겹 마감(v4): 마감 결(R 거칠기 · G 금속 · B 무광)을 같은 자리 · 무게로 읽어 그 부분만 바꿈
  const PAINT_FIN = `
    if (uFinOn > 0.5 && hrW.x + hrW.y + hrW.z > 0.0) {
      vec4 f1 = texture2D(uFin, hrS), f2 = texture2D(uFin, hrT), f3 = texture2D(uFin, hrE);
      float fA = f1.a * hrW.x + f2.a * hrW.y + f3.a * hrW.z;
      if (fA > 0.002) { vec3 fv = (f1.rgb * f1.a * hrW.x + f2.rgb * f2.a * hrW.y + f3.rgb * f3.a * hrW.z) / fA; fA = clamp(fA, 0.0, 1.0);
        roughnessFactor = mix(roughnessFactor, max(fv.r, 0.04), fA); metalnessFactor = mix(metalnessFactor, fv.g, fA); hrMatte = fv.b * fA; }
    }`;
  const PAINT_NRM = `
    if (uFlake > 0.001) { vec3 cl = floor(vOP * 150.0);
      vec3 rn = fract(sin(vec3(dot(cl, vec3(12.9898, 78.233, 37.719)), dot(cl, vec3(39.346, 11.135, 83.155)), dot(cl, vec3(73.156, 52.235, 9.151)))) * 43758.5453) - 0.5;
      float fd = clamp(1.4 - length(fwidth(vOP)) * 190.0, 0.0, 1.0);
      normal = normalize(normal + rn * uFlake * fd); }
    if (uPearlK > 0.001) { float fr = 1.0 - abs(dot(normal, normalize(vViewPosition))); diffuseColor.rgb = mix(diffuseColor.rgb, uPearl, uPearlK * fr * fr); }`;
  let blankTex = null;
  function paintShader(mat, dims, withPat) {
    if (!blankTex) { blankTex = new THREE.DataTexture(new Uint8Array(4), 1, 1); blankTex.needsUpdate = true; }
    const U = mat.userData.U = { uHue: { value: 0 }, uSat: { value: 1 }, uTint: { value: new THREE.Color(1, 1, 1) }, uDecOn: { value: 0 }, uDec: { value: blankTex },
      uD0: { value: new THREE.Vector4(dims.rear, dims.front, dims.bot, Math.max(dims.bot + 0.5, dims.top)) }, uD1: { value: new THREE.Vector2(Math.max(0.4, dims.half), 0.004) },
      uPearl: { value: new THREE.Color(1, 1, 1) }, uPearlK: { value: 0 }, uFlake: { value: 0 }, uFinOn: { value: 0 }, uFin: { value: blankTex } };
    mat.userData.pat = withPat;
    mat.onBeforeCompile = (sh) => {
      Object.assign(sh.uniforms, U);
      sh.vertexShader = 'attribute vec3 aCP;\nattribute vec3 aCN;\nvarying vec3 vOP;\nvarying vec3 vON;\n' + sh.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>\nvOP = aCP; vON = aCN;');
      sh.fragmentShader = PAINT_HEAD + sh.fragmentShader.replace('#include <map_fragment>', '#include <map_fragment>\n' + PAINT_MAP).replace('#include <metalnessmap_fragment>', '#include <metalnessmap_fragment>\n' + PAINT_FIN)
        .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n' + PAINT_NRM).replace('#include <lights_physical_fragment>', '#include <lights_physical_fragment>\n#ifdef USE_CLEARCOAT\nmaterial.clearcoat *= 1.0 - hrMatte;\n#endif');
    };
    mat.customProgramCacheKey = () => 'hrpaint4';
    mat.needsUpdate = true;
  }
  /* 상표 · 스폰서 설정 (이 기기): logo = 스폰서 그림 · 스티커(구구이 R은 깨끗한 도색), badge = 차에 붙은 상표 글자 · 엠블럼 (둘 다 기본 켬) */
  const brandPref = (H) => ({ logo: H.store.get('logo', '1') !== '0', badge: H.store.get('badge', '1') !== '0' });
  let plainM = null;
  const FIN = [null, [0.22, 0.25], [0.3, 0.75], [0.72, 0.04], [0.16, 0.5], [0.05, 1], [0.46, 0.3], [0.08, 0.55], [0.16, 0.6]];   // finish: 기본 · 유광 · 메탈릭 · 무광 · 펄 · 크롬 · 새틴 · 캔디 · 카멜레온 (roughness, metalness)
  const RFIN = [null, [0.8, 0.35], [0.2, 0.7], [0.05, 1], [0.38, 0.9]];   // wheel finish: 기본 · 무광 · 유광 · 크롬 · 건메탈
  const HLC = [[1, 0.97, 0.9], [1, 0.82, 0.45], [0.72, 0.84, 1], [1, 0.62, 0.22]];          // headlight: 흰빛 · 노란빛 · 푸른빛 · 호박빛
  const fontWait = new Set();   // web fonts being loaded for the decal atlas (rebake when they arrive)
  const PLATE = [['#f4f4f0', '#111111'], ['#f0c419', '#111111'], ['#141416', '#f4f4f0']];
  /* number plate spot: the rear-most surface on the centre line (a ray from behind), once per model */
  function plateSpot(tpl, model, tilt, dims) {
    if (tpl.plateP !== undefined) return tpl.plateP;
    tpl.plateP = null;
    try {
      tilt.updateWorldMatrix(true, true);
      const rc = new THREE.Raycaster(), inv = tilt.matrixWorld.clone().invert(), Hm = dims.top - dims.bot;
      for (const f of [0.4, 0.34, 0.46, 0.28, 0.22]) {
        const o = tilt.localToWorld(new THREE.Vector3(0, dims.bot + Hm * f, dims.rear - 1)), d = tilt.localToWorld(new THREE.Vector3(0, dims.bot + Hm * f, dims.rear)).sub(o).normalize();
        rc.set(o, d); rc.far = 3;
        const hit = rc.intersectObject(model, true).find((x) => x.object.visible && x.object.isMesh && !(x.object.material && x.object.material.transparent));
        if (hit) { const p = hit.point.clone().applyMatrix4(inv); tpl.plateP = [p.y, p.z]; break; }
      }
    } catch (e) { tpl.plateP = null; }
    return tpl.plateP;
  }
  /* one car on track: clone + its own paint / light materials; o.paint(liv, cust) repaints it live (pick screen) */
  function makeCarObj(tpl, def, liv, pref, cust) {
    pref = pref || { logo: true, badge: true };
    const root = new THREE.Group(), tilt = new THREE.Group(), model = tpl.scene.clone(true);
    root.userData.keep = true;   // shares geometry with the template: never dispose
    tilt.add(model); root.add(tilt);
    // body size (for effects / patterns): rear end, width, height (model: +Z front, +X left)
    const box = new THREE.Box3().setFromObject(model);
    const dims = { rear: box.min.z, front: box.max.z, half: (box.max.x - box.min.x) / 2, top: box.max.y, bot: Math.min(box.min.y, box.max.y * 0.1) };
    const wheels = [], wheelNodes = new Set();
    model.traverse((o) => { const k = /^wheel_([FR])([LR])\d?$/.exec(o.name); if (k) { wheels.push({ o, front: k[1] === 'F', left: k[2] === 'L' }); o.rotation.order = 'YXZ'; wheelNodes.add(o); } });
    const onWheel = (o) => { for (let p = o; p; p = p.parent) if (wheelNodes.has(p)) return true; return false; };
    const mats = { paint: [], head: [], tail: [], rim: [], caliper: [], glass: [] }, done = new Map();
    if (!plainM) plainM = new THREE.MeshStandardMaterial({ color: 0x050506, roughness: 0.5, metalness: 0.1 });
    model.traverse((o) => {
      if (!o.isMesh || !o.material) return;
      if (o.userData.logo && !pref.logo) { o.visible = false; return; }
      if (o.userData.brand && !pref.badge) { if (o.userData.brand === 'hide') o.visible = false; else o.material = plainM; return; }
      const r = o.material.userData.role;
      if (!r) return;
      const wh = r === 'paint' && onWheel(o), key = o.material.uuid + (wh ? 'w' : '');
      let m = done.get(key);
      if (!m) {
        m = o.material.clone(); m.userData = Object.assign({}, o.material.userData, { c0: o.material.color.clone(), map0: o.material.map, r0: o.material.roughness, m0: o.material.metalness, o0: o.material.opacity, e0: o.material.emissive ? o.material.emissive.clone() : null });
        done.set(key, m); mats[r].push(m);
        if (r === 'paint') paintShader(m, dims, !wh);
      }
      o.material = m;
    });
    const rws = wheels.filter((w) => !w.front);
    dims.rx = rws.length ? rws.reduce((s, w) => s + Math.abs(w.o.position.x), 0) / rws.length : 0.8;
    dims.rz = rws.length ? rws.reduce((s, w) => s + w.o.position.z, 0) / rws.length : -1.35;
    if (wheels.length) { const b = new THREE.Box3().setFromObject(wheels[0].o); dims.wr = Math.max(0.15, (b.max.y - b.min.y) / 2); }
    let glow = null, dec = null, fin = null, plate = null, decKey = '', headK = 0.4, lastArgs = null;
    const obj = { root, tilt, model, mats, wheels, dims, spin: 0, def, hlCol: new THREE.Color(1, 0.94, 0.8),
      setLights(head, brake) { headK = head; for (const m of mats.head) m.emissiveIntensity = head; for (const m of mats.tail) m.emissiveIntensity = brake; },
      paint(lv, cu) {
        cu = cu || {}; lastArgs = [lv, cu];
        const L0 = def.liv[lv] || def.liv[0], custom = cu.m === 1 && cu.c && !def.nocolor;
        // decal atlas: baked only when the pattern / two-tone / number changed
        const dk = JSON.stringify([cu.tt, cu.tc, cu.t2, cu.t2c, cu.L, cu.n, cu.ns, cu.nc, cu.nh, cu.nf, cu._sel, cu._hov]);
        if (dk !== decKey) {
          decKey = dk;
          // web fonts (글자 스티커 · 번호): bake now, and again once the font has arrived
          if (typeof document !== 'undefined' && document.fonts && document.fonts.check) {
            const used = new Set([cu.nf | 0]); for (const l of cu.L || []) if (l[0] === D_TXT) used.add(xOf(l).o | 0);
            for (const k of used) { const fs = FONTS[k]; if (k && fs && !fontWait.has(fs)) { let ok = true; try { ok = document.fonts.check(fs, '가A'); } catch (e) {} if (!ok) { fontWait.add(fs); document.fonts.load(fs, '가A').then(() => { decKey = ''; if (lastArgs) obj.paint(lastArgs[0], lastArgs[1]); }).catch(() => {}); } } }
          }
          if (cu.tt || cu.t2 || (cu.L && cu.L.length) || cu.n) {
            const W = tpl.tier === 'low' ? 512 : 1024;
            if (!dec) { const cv = document.createElement('canvas'); cv.width = cv.height = W; const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; dec = { cv, g: cv.getContext('2d'), t, W }; }
            const wantFin = (cu.L || []).some((l) => xOf(l).f > 0 && !xOf(l).v);
            if (wantFin && !fin) { const cv = document.createElement('canvas'); cv.width = cv.height = W / 2; const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.NoColorSpace; dec.fin = fin = { cv, g: cv.getContext('2d'), t }; }
            dec.on = bakeDecal(dec.g, dec.W, cu, dims, wantFin ? fin.g : null); dec.t.needsUpdate = true; obj.dec = dec;
            if (fin) { fin.on = wantFin; if (wantFin) fin.t.needsUpdate = true; }
          } else { if (dec) dec.on = false; if (fin) fin.on = false; }
        }
        for (const m of mats.paint) {
          const U = m.userData.U, d = m.userData;
          m.map = d.map0; m.color.copy(d.c0); U.uHue.value = 0; U.uSat.value = 1; U.uTint.value.setRGB(1, 1, 1);
          if (def.clean && !pref.logo && tpl.clean && d.map0) m.map = tpl.clean;
          if (custom) {
            if (d.map0 && (def.lv === 'hue' || def.pm)) m.map = null;
            m.color.set(cu.c);
          } else if (def.lv === 'hue') {
            U.uHue.value = ((L0[2] || 0) * PI) / 180; U.uSat.value = L0[3] == null ? 1 : L0[3];
            if (L0[4]) U.uTint.value.set(L0[4]);
          } else if (lv > 0) {
            if (d.map0 && def.pm) m.map = null;
            m.color.set(L0[1]);
          }
          const f = FIN[cu.f | 0];
          if (cu.f === 7) m.color.multiply(m.color).multiplyScalar(1.15);   // candy: deep, saturated tint under a clear coat
          if (f) { m.roughness = f[0]; m.metalness = f[1]; if (m.isMeshPhysicalMaterial) { m.clearcoat = cu.f === 3 || cu.f === 6 ? 0 : 1; m.iridescence = cu.f === 8 ? 1 : cu.f === 4 && !cu.pc ? 0.9 : 0; } }
          else if (!d.map0 || custom || lv > 0) { m.metalness = Math.max(d.m0, def.lv === 'solid' && lv > 0 ? 0.5 : d.m0); m.roughness = Math.min(d.r0, 0.35); }
          else { m.roughness = d.r0; m.metalness = d.m0; }
          const on = !!(d.pat && dec && dec.on);
          U.uDecOn.value = on ? 1 : 0; U.uDec.value = on ? dec.t : blankTex;
          U.uPearlK.value = cu.pc ? [0, 0.35, 0.6, 0.9][cu.pk | 0] : 0; if (cu.pc) U.uPearl.value.set(cu.pc);
          if (cu.f === 8) { U.uPearlK.value = Math.max(U.uPearlK.value, 0.95); if (!cu.pc) U.uPearl.value.copy(m.color).offsetHSL(0.42, 0.1, 0.05); }   // 카멜레온: strong colour flip at grazing angles
          const fo = !!(on && fin && fin.on); U.uFinOn.value = fo ? 1 : 0; U.uFin.value = fo ? fin.t : blankTex;
          U.uFlake.value = [0, 0.14, 0.28, 0.48][cu.fk | 0];
          m.needsUpdate = true;
        }
        for (const m of mats.rim) { const d = m.userData, rf = RFIN[cu.rf | 0]; m.color.copy(d.c0); m.roughness = d.r0; m.metalness = d.m0; if (cu.r) { m.color.set(cu.r); m.metalness = Math.max(d.m0, 0.55); } if (rf) { m.roughness = rf[0]; m.metalness = rf[1]; if (cu.rf === 4 && !cu.r) m.color.set('#3a3d42'); } }
        for (const m of mats.caliper) { m.color.copy(m.userData.c0); if (cu.k) m.color.set(cu.k); }
        for (const m of mats.glass) { m.color.copy(m.userData.c0); const t = cu.t | 0; if (cu.tw) m.color.set(cu.tw).multiplyScalar(0.55);
          if (t || cu.tw) { m.color.multiplyScalar(t === 1 ? 0.45 : t === 2 ? 0.12 : 1); m.transparent = true; m.opacity = Math.max(m.userData.o0, t === 1 ? 0.85 : t === 2 ? 0.96 : 0.72); } else m.opacity = m.userData.o0; }
        const hc = HLC[cu.hl | 0];
        for (const m of mats.head) m.emissive.setRGB(hc[0], hc[1], hc[2]);
        obj.hlCol.setRGB(hc[0], hc[1] * 0.97, hc[2] * 0.9);
        if (cu.u) {
          if (!glow) {
            glow = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: canvasTex(64, 128, radial([[0, 'rgba(255,255,255,0.9)'], [0.55, 'rgba(255,255,255,0.35)'], [1, 'rgba(255,255,255,0)']])), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, polygonOffset: true, polygonOffsetFactor: -9, polygonOffsetUnits: -9 }));
            glow.rotation.x = -PI / 2; glow.position.y = 0.05; glow.scale.set(dims.half * 3.2, (dims.front - dims.rear) * 1.25, 1); glow.position.z = (dims.front + dims.rear) / 2; root.add(glow);
          }
          glow.material.color.set(cu.u); glow.visible = true;
        } else if (glow) glow.visible = false;
        obj.glow = glow;
        // number plate (rear, on the centre line): its own little canvas
        const pk = cu.pl ? cu.pl + '|' + (cu.ps | 0) + '|' + (cu.nf | 0) : '';
        if (pk && (!plate || plate.userData.k !== pk)) {
          const sp = plateSpot(tpl, model, tilt, dims);
          if (sp) {
            if (!plate) {
              const cv = document.createElement('canvas'); cv.width = 256; cv.height = 64;
              const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
              const pw = clamp(dims.half * 0.55, 0.32, 0.52);
              plate = new THREE.Mesh(new THREE.PlaneGeometry(pw, pw * 0.25), new THREE.MeshStandardMaterial({ map: t, roughness: 0.45, metalness: 0.1, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }));
              plate.rotation.y = PI; plate.position.set(0, sp[0], sp[1] - 0.02); tilt.add(plate);
            }
            const [bg, fg] = PLATE[cu.ps | 0], g = plate.material.map.image.getContext('2d');
            g.fillStyle = bg; g.fillRect(0, 0, 256, 64); g.lineWidth = 4; g.strokeStyle = fg; g.strokeRect(4, 4, 248, 56);
            g.fillStyle = fg; g.font = (FONTS[cu.nf | 0] || FONT).replace('100px', '40px'); g.textAlign = 'center'; g.textBaseline = 'middle';
            const tw = g.measureText(cu.pl).width; g.save(); g.translate(128, 34); if (tw > 228) g.scale(228 / tw, 1); g.fillText(cu.pl, 0, 0); g.restore();
            plate.material.map.needsUpdate = true; plate.userData.k = pk; plate.visible = true;
          }
        } else if (!pk && plate) plate.visible = false;
        if (plate && pk) plate.visible = true;
      },
    };
    obj.paint(liv, cust);
    return obj;
  }

  /* ======================= 도감 · 고르기: 돌아가는 차 ======================= */
  V.showroom = function (canvas, H, carId, opt) {
    opt = opt || {};
    const R = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    R.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    R.toneMapping = THREE.ACESFilmicToneMapping; R.outputColorSpace = THREE.SRGBColorSpace;
    const S = new THREE.Scene(), C = new THREE.PerspectiveCamera(30, 2, 0.1, 100);
    S.add(new THREE.HemisphereLight(0xffffff, 0x302838, 1.1));
    const key = new THREE.DirectionalLight(0xffffff, 2.4); key.position.set(4, 6, 3); S.add(key);
    const rim = new THREE.DirectionalLight(0xb0c8ff, 1.2); rim.position.set(-5, 3, -4); S.add(rim);
    const floor = new THREE.Mesh(new THREE.CircleGeometry(4.6, 48), new THREE.MeshBasicMaterial({ map: canvasTex(128, 128, radial([[0, 'rgba(0,0,0,.6)'], [0.6, 'rgba(0,0,0,.25)'], [1, 'rgba(0,0,0,0)']])), transparent: true, depthWrite: false }));
    floor.rotation.x = -PI / 2; S.add(floor);
    let car = null, dead = false, ang = 0.6, drag = null, raf = 0, want = null, fitD = 7.6, onLoad = opt.onLoad || null;
    H.pack('sky_day').then((p) => texFrom(p.sky, { srgb: true })).then((t) => { if (dead) return; t.mapping = THREE.EquirectangularReflectionMapping; const pm = new THREE.PMREMGenerator(R); S.environment = pm.fromEquirectangular(t).texture; S.environmentIntensity = 0.9; pm.dispose(); }).catch(() => {});
    function show(id, liv, cust) {
      want = [id, liv | 0, cust];
      if (onLoad) onLoad(true);
      loadCarTpl(H, id, opt.tier || 'mid').then((tpl) => {
        if (dead || !want || want[0] !== id) return;
        if (car) S.remove(car.root);
        car = makeCarObj(tpl, H.CAR[id], want[1], brandPref(H), want[2]); S.add(car.root); car.setLights(0.6, 0.6);
        const L = car.dims.front - car.dims.rear; fitD = clamp(L * 1.55, 6.2, 12);
        if (onLoad) onLoad(false);
      }).catch(() => { if (onLoad) onLoad(false); });
    }
    if (carId) show(carId);
    const fit = () => { const w = canvas.clientWidth || 300, h = canvas.clientHeight || 200; R.setSize(w, h, false); C.aspect = w / h; C.updateProjectionMatrix(); };
    const loop = () => {
      if (dead) return;
      raf = requestAnimationFrame(loop);
      if (!drag) ang += 0.006;
      fit();
      const d = fitD * (C.aspect < 1.2 ? 1.25 : 1);
      C.position.set(Math.sin(ang) * d, 0.3 * d, Math.cos(ang) * d); C.lookAt(0, car ? car.dims.top * 0.42 : 0.55, 0);
      R.render(S, C);
    };
    loop();
    const pd = (e) => { drag = { x: e.clientX, a: ang }; canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId); };
    const pm = (e) => { if (drag) ang = drag.a - (e.clientX - drag.x) * 0.012; };
    const pu = () => { drag = null; };
    canvas.addEventListener('pointerdown', pd); canvas.addEventListener('pointermove', pm); canvas.addEventListener('pointerup', pu); canvas.addEventListener('pointercancel', pu);
    canvas.style.touchAction = 'none';
    return {
      car: show,
      paint(liv, cust) { if (want) { want[1] = liv | 0; want[2] = cust; } if (car) car.paint(liv | 0, cust); },
      roles() { return car && want && car.def.id === want[0] ? (carTplDone[want[0] + '_' + (opt.tier || 'mid')] || {}).roles || {} : null; },
      destroy() { dead = true; cancelAnimationFrame(raf); R.dispose(); try { R.forceContextLoss(); } catch (e) {} },
    };
  };

  /* 고르기 화면 카드 그림 만들기(도구 전용: tools/hyperrace/thumbs.py → pk_thumbs.js) — 앞 ¾ 모습, 투명 바탕, 차가 칸에 꽉 차게 */
  V.thumbs = async function (H, ids, w, h, tier) {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    const R = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, preserveDrawingBuffer: true });
    R.setPixelRatio(1); R.setSize(w, h, false); R.toneMapping = THREE.ACESFilmicToneMapping; R.outputColorSpace = THREE.SRGBColorSpace; R.setClearColor(0, 0);
    const S = new THREE.Scene(), C = new THREE.PerspectiveCamera(22, w / h, 0.1, 200);
    S.add(new THREE.HemisphereLight(0xffffff, 0x302838, 1.2));
    const key = new THREE.DirectionalLight(0xffffff, 2.6); key.position.set(5, 7, 6); S.add(key);
    const rim = new THREE.DirectionalLight(0xb0c8ff, 1.3); rim.position.set(-5, 3, -4); S.add(rim);
    const sky = await H.pack('sky_day').then((p) => texFrom(p.sky, { srgb: true }));
    sky.mapping = THREE.EquirectangularReflectionMapping; const pm = new THREE.PMREMGenerator(R); S.environment = pm.fromEquirectangular(sky).texture; S.environmentIntensity = 0.95;
    const out = {};
    for (const id of ids) {
      const tpl = await loadCarTpl(H, id, tier || 'mid');
      const o = makeCarObj(tpl, H.CAR[id], 0, { logo: true, badge: true }, null); o.setLights(0.5, 0.4);
      S.add(o.root); o.root.updateMatrixWorld(true);
      const b = new THREE.Box3().setFromObject(o.model), ctr = b.getCenter(new THREE.Vector3()), dir = new THREE.Vector3(Math.sin(0.78), 0.32, Math.cos(0.78)).normalize();
      let d = b.getSize(new THREE.Vector3()).length() * 2.2;
      const pts = []; for (let k = 0; k < 8; k++) pts.push(new THREE.Vector3(k & 1 ? b.max.x : b.min.x, k & 2 ? b.max.y : b.min.y, k & 4 ? b.max.z : b.min.z));
      for (let it = 0; it < 6; it++) {
        C.position.copy(ctr).addScaledVector(dir, d); C.lookAt(ctr); C.updateMatrixWorld(true);
        let x0 = 9, x1 = -9, y0 = 9, y1 = -9;
        for (const p of pts) { const q = p.clone().project(C); x0 = Math.min(x0, q.x); x1 = Math.max(x1, q.x); y0 = Math.min(y0, q.y); y1 = Math.max(y1, q.y); }
        if (it < 5) { d *= Math.max((x1 - x0) / 1.9, (y1 - y0) / 1.8); continue; }
      }
      // crop to the drawn pixels (box corners overshoot the silhouette): render, find the opaque area, zoom the view onto it
      R.render(S, C);
      const c2 = document.createElement('canvas'); c2.width = w; c2.height = h; const g2 = c2.getContext('2d'); g2.drawImage(cv, 0, 0);
      const px = g2.getImageData(0, 0, w, h).data; let bx0 = w, bx1 = 0, by0 = h, by1 = 0;
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (px[(y * w + x) * 4 + 3] > 20) { if (x < bx0) bx0 = x; if (x > bx1) bx1 = x; if (y < by0) by0 = y; if (y > by1) by1 = y; }
      if (bx1 > bx0) { const sc = Math.max((bx1 - bx0 + 1) / (w * 0.95), (by1 - by0 + 1) / (h * 0.9)); C.setViewOffset(w, h, (bx0 + bx1) / 2 - w * sc / 2, (by0 + by1) / 2 - h * sc / 2, w * sc, h * sc); R.render(S, C); C.clearViewOffset(); }
      out[id] = cv.toDataURL('image/webp', 0.84);
      S.remove(o.root);
    }
    pm.dispose(); R.dispose();
    return out;
  };

  /* ======================= 게임 화면 ======================= */
  V._cust = { bakeDecal, decShape, layerIcon };   // (tests: test-output/hyperrace8/gallery.py)
  V.mount = function (root, api, H, hooks) {
    const h = L.h, U = L.util;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let tierId = H.gfxTier(), TIER = H.TIERS.find((t) => t.id === tierId) || H.TIERS[0];
    const PC = !H.touchOnly();
    const wrap = h('div', { class: 'hr-wrap', style: { position: 'absolute', inset: '0', overflow: 'hidden', background: '#0d0b12', userSelect: 'none', touchAction: 'none' } });
    root.append(wrap);
    const css = h('style', { text: `
      .hr-wrap canvas.hr3d{position:absolute;inset:0;width:100%;height:100%;display:block}
      .hr-wrap canvas.hr-sl{position:absolute;inset:0;width:100%;height:100%;display:block;pointer-events:none}
      .hr-hud{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body);color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.7)}
      .hr-pos{position:absolute;left:12px;top:10px;line-height:1}
      .hr-pos b{font-family:var(--f-display);font-size:30px;letter-spacing:1px}
      .hr-pos span{font-size:14px;opacity:.85;margin-left:3px}
      .hr-pos i{display:block;font-style:normal;font-size:12px;margin-top:5px;opacity:.9}
      .hr-cls{display:inline-block;font-size:10px;font-weight:700;padding:1px 5px;border-radius:4px;color:#111;margin-right:4px;text-shadow:none;vertical-align:1px}
      .hr-lap{position:absolute;left:50%;top:8px;transform:translateX(-50%);text-align:center;font-family:var(--f-mono);font-size:13px;line-height:1.35;background:rgba(10,8,14,.38);padding:4px 10px;border-radius:9px;white-space:nowrap}
      .hr-lap b{font-size:15px}
      .hr-spd{position:absolute;left:50%;bottom:10px;transform:translateX(-50%);text-align:center;line-height:1}
      .hr-spd b{font-family:var(--f-mono);font-size:34px;font-weight:700}
      .hr-spd small{font-size:11px;opacity:.85;margin-left:2px}
      .hr-gear{display:inline-block;font-family:var(--f-mono);font-size:15px;font-weight:700;margin-left:8px;padding:1px 6px;border-radius:5px;background:rgba(255,255,255,.14)}
      .hr-bars{display:flex;gap:4px;justify-content:center;margin-top:5px}
      .hr-bar{width:64px;height:5px;border-radius:3px;background:rgba(255,255,255,.18);overflow:hidden}
      .hr-bar>div{height:100%;width:0;background:#ffcf5a}
      .hr-bar.sl>div{background:#7fd7ff}
      .hr-dg{display:flex;gap:3px;justify-content:center;margin-top:5px;opacity:0;transition:transform .12s}
      .hr-dg i{display:block;width:42px;height:6px;border-radius:3px;background:rgba(255,255,255,.16);overflow:hidden}
      .hr-dg s{display:block;height:100%;width:0;text-decoration:none}
      .hr-dg.fl{transform:scale(1.18)}
      .hr-spd.bst b{color:#ffd27a;text-shadow:0 0 12px rgba(255,180,60,.8),0 1px 3px rgba(0,0,0,.7)}
      .hr-pos.up b{color:#8cff9a}.hr-pos.dn b{color:#ff8a7a}
      .hr-pos b{display:inline-block;transition:transform .15s}.hr-pos.up b,.hr-pos.dn b{transform:scale(1.18)}
      .hr-map{position:absolute;right:10px;top:58px;width:118px;height:118px;opacity:.92}
      .hr-islot{position:absolute;width:60px;height:60px;border-radius:16px;background:rgba(14,11,20,.5);border:1.5px solid rgba(255,255,255,.3);display:none;align-items:center;justify-content:center;box-sizing:border-box;pointer-events:none;color:#fff}
      .hr-islot svg{width:62%;height:62%;filter:drop-shadow(0 1px 2px rgba(0,0,0,.6))}
      .hr-islot.has{border-color:var(--ic,#ffd27a);box-shadow:inset 0 0 14px var(--ic,#ffd27a)}
      .hr-islot.roll svg{opacity:.7;transform:scale(.86)}
      .hr-islot.tap{pointer-events:auto;touch-action:none;border-radius:18px}
      .hr-islot.tap.on{background:rgba(227,174,69,.5)}
      .hr-islot em{position:absolute;left:50%;bottom:-17px;transform:translateX(-50%);font-size:11px;font-style:normal;white-space:nowrap;opacity:.92}
      .hr-ifx{position:absolute;display:none;align-items:center;gap:5px;font-size:11px;padding:2px 8px 2px 4px;border-radius:999px;background:rgba(10,8,14,.45);white-space:nowrap}
      .hr-ifx svg{width:16px;height:16px}.hr-ifx i{display:block;width:40px;height:4px;border-radius:2px;background:rgba(255,255,255,.2);overflow:hidden}.hr-ifx s{display:block;height:100%;background:var(--ic,#fff)}
      .hr-haze{position:absolute;inset:0;pointer-events:none;opacity:0;background:radial-gradient(ellipse at 50% 46%,rgba(196,200,208,.5),rgba(160,164,172,.86));transition:opacity .3s}
      .hr-hint{position:absolute;left:12px;max-width:min(62vw,560px);font-size:12px;line-height:1.5;padding:5px 10px;border-radius:10px;background:rgba(10,8,14,.5);opacity:0;transition:opacity .4s;pointer-events:auto}
      .hr-hint kbd{font-family:var(--f-mono);font-size:11px;padding:0 4px;border-radius:4px;background:rgba(255,255,255,.16);margin:0 1px}
      .hr-camtag{position:absolute;left:50%;top:94px;transform:translateX(-50%);font-size:11.5px;padding:2px 9px;border-radius:999px;background:rgba(10,8,14,.42);display:none;white-space:nowrap}
      .hr-tower{position:absolute;left:10px;top:76px;font-size:12px;line-height:17px;font-family:var(--f-mono)}
      .hr-tower div{background:rgba(10,8,14,.42);padding:0 6px;margin-bottom:1px;border-radius:4px;white-space:nowrap}
      .hr-tower div.me{background:rgba(227,174,69,.55);color:#111;text-shadow:none}
      .hr-note{position:absolute;left:50%;top:62px;transform:translateX(-50%);font-size:15px;font-weight:700;background:rgba(10,8,14,.45);padding:4px 12px;border-radius:999px;opacity:0;transition:opacity .2s;white-space:nowrap}
      .hr-lights{position:absolute;left:50%;top:27%;transform:translateX(-50%);display:flex;gap:8px;padding:8px 10px;border-radius:10px;background:rgba(8,6,10,.55)}
      .hr-lights i{width:26px;height:26px;border-radius:50%;background:#2a1012;box-shadow:inset 0 0 6px #000}
      .hr-lights i.on{background:radial-gradient(circle at 40% 35%,#ff8a7a,#e01b12 60%,#7a0a06);box-shadow:0 0 14px #ff2a1a}
      .hr-go{position:absolute;left:50%;top:26%;transform:translateX(-50%);font-family:var(--f-display);font-size:44px;color:#7dff8a;text-shadow:0 0 18px rgba(80,255,120,.6),0 2px 4px #000}
      .hr-prep{position:absolute;left:50%;top:30%;transform:translateX(-50%);display:flex;align-items:center;gap:10px;font-size:14px;font-weight:700;background:rgba(10,8,14,.6);padding:8px 16px;border-radius:999px}
      .hr-prep i{width:16px;height:16px;border-radius:50%;border:3px solid rgba(255,255,255,.25);border-top-color:#ffd27a;animation:hrspin .8s linear infinite}
      @keyframes hrspin{to{transform:rotate(360deg)}}
      .hr-trk{position:absolute;left:50%;top:calc(27% + 54px);transform:translateX(-50%);display:flex;align-items:center;gap:10px;max-width:min(92vw,330px);padding:6px 12px 6px 6px;border-radius:12px;background:rgba(10,8,14,.62);pointer-events:none}
      .hr-trk canvas{width:62px;height:62px;flex:0 0 62px}
      .hr-trk b{display:block;font-size:15px;line-height:1.25}
      .hr-trk span{display:block;font-size:11.5px;line-height:1.35;opacity:.85}
      .hr-trkr{display:flex;gap:10px;align-items:center}.hr-trkc{width:72px;height:72px;flex:0 0 72px;background:rgba(0,0,0,.25);border-radius:10px}
      .hr-wrong{position:absolute;left:50%;top:40%;transform:translateX(-50%);font-size:20px;font-weight:800;color:#ff6a5a;background:rgba(10,8,14,.5);padding:4px 14px;border-radius:999px}
      .hr-ctl{position:absolute;pointer-events:auto;touch-action:none;border-radius:16px;background:rgba(20,16,28,.36);border:1.5px solid rgba(255,255,255,.28);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;-webkit-user-select:none;user-select:none;box-sizing:border-box}
      .hr-ctl.on{background:rgba(227,174,69,.5);border-color:rgba(255,230,160,.85)}
      .hr-ctl svg{width:34px;height:34px;fill:currentColor}
      .hr-steer{display:flex;padding:0;overflow:hidden}
      .hr-steer i{flex:1;display:flex;align-items:center;justify-content:center;height:100%;transition:background .08s}
      .hr-steer i+i{border-left:1.5px solid rgba(255,255,255,.22)}
      .hr-steer.l .hr-sl,.hr-steer.r .hr-sr{background:rgba(227,174,69,.5)}
      .hr-steer .hr-knob{display:none}
      .hr-steer.drag{background:rgba(20,16,28,.12);border-style:dashed;border-color:rgba(255,255,255,.22);border-radius:22px;overflow:visible}
      .hr-steer.drag i{opacity:.4}.hr-steer.drag i+i{border-left:0}
      .hr-steer.drag.l .hr-sl,.hr-steer.drag.r .hr-sr{background:none;opacity:.9}
      .hr-steer.drag .hr-knob{display:block;position:absolute;width:52px;height:52px;margin:-26px 0 0 -26px;border-radius:50%;background:rgba(255,230,160,.35);border:2px solid rgba(255,230,160,.85);pointer-events:none}
      .hr-sbtn{position:absolute;pointer-events:auto;min-width:44px;height:44px;border-radius:12px;background:rgba(20,16,28,.42);border:1px solid rgba(255,255,255,.25);color:#fff;font-size:12px;font-weight:700;display:flex;align-items:center;justify-content:center;padding:0 8px;box-sizing:border-box}
      .hr-pick{position:absolute;pointer-events:auto;background:rgba(23,19,29,.92);border:1px solid rgba(255,255,255,.12);border-radius:16px;color:var(--ink);padding:8px;box-sizing:border-box;display:flex;flex-direction:column;gap:6px;overflow:hidden}
      .hr-pb{flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;padding:0 2px 6px}
      .hr-pick .row{display:flex;gap:6px;flex-wrap:wrap;margin:4px 0 10px;align-items:center}
      .hr-pick .lbl{font-size:12px;color:var(--muted);width:100%}
      .hr-sw{width:44px;height:44px;border-radius:50%;border:3px solid rgba(255,255,255,.25);cursor:pointer;padding:0;flex:0 0 auto}
      .hr-sw.sel{border-color:#fff;box-shadow:0 0 0 2px var(--brass)}
      .hr-swc{width:52px;height:44px;border-radius:12px}
      .hr-chip{min-height:44px;min-width:44px;padding:0 11px;border-radius:10px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.06);color:var(--ink);font-size:13px;cursor:pointer}
      .hr-chip.sel{background:var(--brass);color:#1b1408;border-color:var(--brass);font-weight:700}
      .hr-st{min-width:44px;padding:0 6px;font-family:var(--f-mono);font-size:15px}
      .hr-ready{width:100%;min-height:48px;font-size:17px;flex:0 0 auto}
      .hr-seg{display:flex;gap:4px;background:rgba(255,255,255,.06);border-radius:12px;padding:3px;flex:0 0 auto}
      .hr-seg button{flex:1;min-height:44px;border:0;border-radius:9px;background:none;color:var(--ink);font-size:14px;font-weight:700;cursor:pointer;padding:0 4px}
      .hr-seg button.sel{background:var(--brass);color:#1b1408}
      .hr-seg.hr-sub{margin:2px 0 8px;position:sticky;top:0;z-index:2;background:#211c29}
      .hr-seg.hr-sub button{font-size:13px;min-height:44px}
      .hr-tabs{display:flex;gap:5px;overflow-x:auto;padding-bottom:4px;margin-bottom:6px;scrollbar-width:thin;position:sticky;top:0;z-index:2;background:rgba(23,19,29,.97)}
      .hr-tabs button{flex:0 0 auto;min-height:44px;min-width:44px;padding:0 11px;border-radius:10px;border:1px solid rgba(255,255,255,.18);border-bottom:3px solid var(--c);background:rgba(255,255,255,.05);color:var(--ink);font-size:13px;cursor:pointer;white-space:nowrap}
      .hr-tabs button.sel{background:rgba(255,255,255,.16);font-weight:700}
      .hr-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(138px,1fr));gap:6px}
      .hr-gh{grid-column:1/-1;display:flex;align-items:baseline;gap:8px;margin:6px 0 0;padding-left:8px;border-left:4px solid var(--c);min-width:0}
      .hr-gh b{font-size:14px;white-space:nowrap}.hr-gh small{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
      .hr-cc{position:relative;display:flex;flex-direction:column;align-items:stretch;text-align:left;min-height:44px;padding:0 0 6px;border-radius:12px;overflow:hidden;cursor:pointer;color:var(--ink);
        border:2px solid rgba(255,255,255,.1);background:linear-gradient(180deg,color-mix(in srgb,var(--c) 26%,#2c2636) 0%,#1d1924 78%)}
      .hr-cc.sel{border-color:var(--brass);box-shadow:0 0 0 2px rgba(227,174,69,.35),0 4px 14px rgba(0,0,0,.4)}
      .hr-cc.sel::after{content:'';position:absolute;right:7px;top:7px;width:16px;height:16px;border-radius:50%;background:var(--brass) center/10px no-repeat url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 10'%3E%3Cpath d='M1.5 5.2 4 7.6 8.6 2.4' fill='none' stroke='%231b1408' stroke-width='1.8'/%3E%3C/svg%3E")}
      .hr-ci{display:block;aspect-ratio:2.25;width:100%;background:radial-gradient(ellipse at 50% 80%,rgba(255,255,255,.16),rgba(255,255,255,0) 70%)}
      .hr-ci img{display:block;width:100%;height:100%;object-fit:contain;pointer-events:none}
      .hr-ci em{display:flex;height:100%;align-items:center;justify-content:center;font-style:normal;font-size:13px;opacity:.5}
      .hr-cc .hr-cls{position:absolute;left:6px;top:6px;margin:0}
      .hr-cc b{font-size:13.5px;padding:0 8px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .hr-cc small{font-size:11px;color:var(--muted);padding:1px 8px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .hr-pinfo{position:absolute;pointer-events:none;text-shadow:0 1px 4px rgba(0,0,0,.85);color:#fff}
      .hr-pn{display:flex;align-items:center;gap:6px}
      .hr-pn b{font-family:var(--f-display);font-size:clamp(22px,3.3vh,36px);font-weight:400;line-height:1.1}
      .hr-pt{font-size:clamp(13px,1.9vh,20px);font-weight:700;color:#ffd27a;margin-top:2px}
      .hr-pr{font-size:11.5px;opacity:.8;margin-top:1px}
      .hr-pl{font-size:12px;color:#9fd8ff;margin-top:3px;min-height:15px}
      .hr-pstat{position:absolute;pointer-events:none;background:rgba(14,11,19,.62);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:7px 10px;box-sizing:border-box;color:#fff}
      .hr-stats{display:grid;grid-template-columns:1fr 1fr;gap:4px 12px}
      .hr-stat{display:flex;align-items:center;gap:6px;font-size:11.5px}
      .hr-stat span{width:52px;flex:0 0 auto;color:rgba(255,255,255,.72)}
      .hr-stat i{flex:1;height:6px;border-radius:3px;background:rgba(255,255,255,.14);overflow:hidden}
      .hr-stat s{display:block;height:100%;background:linear-gradient(90deg,#e3ae45,#ffd27a)}
      .hr-spec{font-size:11px;color:rgba(255,255,255,.7);margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .hr-pstat.cmp{padding:5px 8px}.hr-pstat.cmp .hr-stats{gap:3px 10px}.hr-pstat.cmp .hr-spec{display:none}
      .hr-pstat.por{padding:5px 8px}.hr-pstat.por .hr-stats{grid-template-columns:1fr 1fr 1fr;gap:3px 10px}.hr-pstat.por .hr-stat span{width:44px;font-size:10.5px}.hr-pstat.por .hr-spec{display:none}
      .hr-ptools{position:absolute;pointer-events:auto;display:flex;gap:8px;align-items:center}
      .hr-ptools .hr-sbtn{position:static}
      .hr-ph2{display:flex;gap:10px;align-items:center}.hr-ph2 span{font-size:12px;color:#fff;text-shadow:0 1px 3px #000;background:rgba(10,8,14,.4);padding:4px 10px;border-radius:999px}
      .hr-cdesc{font-size:11px;color:var(--muted);margin:2px 0 8px;line-height:1.35}
      .hr-layer{border:1px solid rgba(255,255,255,.12);border-radius:12px;padding:6px 8px 0;margin-bottom:8px;background:rgba(255,255,255,.03)}
      .hr-lh{display:flex;align-items:center;gap:6px}.hr-lh b{flex:1;font-size:13px}
      .hr-pats .hr-chip{padding:0 9px;font-size:12.5px}
      .hr-in{min-height:44px;flex:1 1 140px;min-width:0;border-radius:10px;border:1px solid rgba(255,255,255,.25);background:rgba(0,0,0,.25);color:var(--ink);font-size:15px;padding:0 10px;box-sizing:border-box;user-select:text;-webkit-user-select:text}
      .hr-pre{display:inline-flex;gap:3px;flex:1 1 60px;min-width:60px;font-size:12px}.hr-pre i{width:18px;height:28px;border-radius:5px;border:1px solid rgba(255,255,255,.25)}
      .hr-pnm{width:18px;text-align:center;font-family:var(--f-mono)}
      .hr-prow{border-bottom:1px solid rgba(255,255,255,.07);padding-bottom:6px}
      .hr-act{margin-top:0!important}
      .hr-sheet{position:absolute;inset:0;z-index:5;background:#1d1924;border-radius:16px;padding:10px;overflow-y:auto;box-sizing:border-box}
      .hr-sh{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}.hr-sh b{font-size:15px}
      .hr-swg{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 10px}
      .hr-any{position:relative;overflow:hidden;display:inline-block}
      .hr-pickc{position:absolute;inset:0;opacity:0;width:100%;height:100%;cursor:pointer;border:0;padding:0}
      .hr-stp{display:inline-flex;align-items:center;gap:4px;margin-right:10px}.hr-stl{font-size:12px;color:var(--muted);min-width:30px}
      .hr-num{min-width:34px;text-align:center;font-family:var(--f-mono);font-size:16px}
      .hr-pick.cmp{padding:6px}
      .hr-pick.cmp .hr-gh small,.hr-pick.cmp .hr-cc small{display:none}
      .hr-pick.cmp .hr-grid{grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:5px}
      .hr-pick.cmp .hr-cc b{font-size:12px;padding:0 6px}.hr-pick.cmp .hr-cc .hr-cls{font-size:9px;padding:0 4px;left:4px;top:4px}
      .hr-pick.cmp > .hr-seg{margin-right:38px}
      .hr-pick.cmp .hr-ready{min-height:44px}
      .hr-pick.cmp .hr-pats{flex-wrap:nowrap;overflow-x:auto;padding-bottom:3px}.hr-pick.cmp .hr-pats .hr-chip{flex:0 0 auto}
    ` });
    wrap.append(css);

    /* ----- renderer ----- */
    let R;
    try {
      R = new THREE.WebGLRenderer({ antialias: TIER.aa, powerPreference: 'high-performance' });
    } catch (e) { hooks.progress(1, '3D 그래픽을 켜지 못했어요. (' + (e && e.message || e) + ')'); return { update() {}, destroy() { wrap.remove(); } }; }
    R.domElement.className = 'hr3d';
    wrap.append(R.domElement);
    R.outputColorSpace = THREE.SRGBColorSpace;
    R.toneMapping = THREE.ACESFilmicToneMapping;
    R.shadowMap.enabled = TIER.shadow > 0;
    R.shadowMap.type = TIER.id === 'high' ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    const scene = new THREE.Scene();
    const DBG = window.HR_DBG = { scene, R };
    const cam = new THREE.PerspectiveCamera(62, 1, 0.12, 4200);
    let vw = 1, vh = 1;
    function resize() {
      const r = wrap.getBoundingClientRect(); vw = Math.max(1, r.width); vh = Math.max(1, r.height);
      R.setPixelRatio(Math.min(window.devicePixelRatio || 1, TIER.pr));
      R.setSize(vw, vh, false);
      cam.aspect = vw / vh; cam.updateProjectionMatrix();
      layout();
    }

    /* ----- state ----- */
    let st = null, W = null, T = null, built = null, objs = [], dead = false, raf = 0, last = 0, acc = 0;
    let phase = 'load', countT = 0, goT = null, doneSent = false, firstFinT = null, allHumFinT = null;
    let ASSETS = null;
    const isHost = () => !api.online || api.isHost;
    const P = (seat) => api.players[seat] || { name: '?', ai: true };
    const mySeat = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    function controlledHere(seat) {
      const p = api.players[seat];
      if (!p) return false;
      if (!api.online) return true;
      if (api.isHost) return !!p.ai || !!p.local;
      return !!p.local && !p.ai;
    }
    // test drivers: shot.py autoplay, or the online test harness (online.py sets noTut) — people's seats are driven/picked by the AI
    const testBot = () => !!(L.debug && (L.debug.autoplay || (L.debug.noTut && api.online)));
    const isHumanHere = (seat) => { const p = api.players[seat]; return !!p && !p.ai && (!api.online || !!p.local) && !testBot(); };
    const key = () => 'h' + (st ? st.rid : 0);

    /* ======================= 불러오기 ======================= */
    /* sky pack of a race: the 초원 서킷 keeps its HDRIs with land on the horizon (sky_*), the other maps use pure skies (psky_*) over their own terrain */
    const SKY_KEY = (s) => {
      const k = s.wx === 'rain' && s.tod === 'day' ? 'rain' : s.tod;
      if (!s.th || s.th === 'park') return 'sky_' + k;
      return 'psky_' + (k === 'day' ? (s.seed % 2 ? 'day' : 'day2') : k);
    };
    /* map assets (ground textures, the plant / rock atlas, roadside rocks) — per map, loaded once and kept */
    const THA = {}, thLoading = {};
    function themeLoad(th) {
      const L0 = LOOK[th] || LOOK.park;
      if (!thLoading[th]) thLoading[th] = Promise.all([
        Promise.all((L0.gt || []).map((k) => H.pack('gt_' + k).then(async (p) => { const o = {}; for (const nm of Object.keys(p)) o[nm.slice(k.length + 1)] = await texFrom(p[nm], { srgb: /_c$/.test(nm), rep: true, aniso: 8 }); return [k, o]; }))),
        L0.flora ? H.pack('flora').then((p) => texFrom(p.flora, { srgb: true, aniso: 4 })) : null,
        L0.rocks ? H.pack('rocks').then(async (p) => { const o = {}; for (const k of Object.keys(p)) o[k] = (await gltfFrom(p[k])).scene; return o; }) : null,
      ]).then(([gts, flora, rocks]) => { THA[th] = { g: Object.fromEntries(gts), flora, rocks: rocks || {} }; }).catch((e) => { thLoading[th] = null; console.warn(e); THA[th] = { g: {}, flora: null, rocks: {} }; });
      return thLoading[th];
    }
    function loadAssets(s) {
      const want = { sky: SKY_KEY(s) };
      const prog = { n: 0, of: 5 };
      const tick = (txt) => { prog.n++; hooks.progress(0.25 + 0.7 * (prog.n / prog.of), txt); };
      const P1 = H.pack(want.sky).then((p) => imageFrom(p.sky)).then((im) => { tick('하늘'); return im; });
      const P5 = themeLoad(s.th || 'park').then(() => tick('맵'));
      const P2 = H.pack('tex').then(async (p) => {
        const o = {};
        for (const k of Object.keys(p)) o[k] = await texFrom(p[k], { srgb: /_c$|^trees$/.test(k), rep: k !== 'trees', aniso: 8 });
        tick('바닥 결'); return o;
      });
      const P3 = H.pack('props').then(async (p) => { const o = {}; for (const k of Object.keys(p)) o[k] = (await gltfFrom(p[k])).scene; tick('관중석 · 소품'); return o; }).catch(() => ({}));
      const P4 = H.pack('sfx').then((p) => { tick('소리'); return p; }).catch(() => ({}));
      // cars: only the ones a race needs, loaded on demand (needCars) — 26 cars × 3 tiers never load at once
      return Promise.all([P1, P2, P3, P4, P5]).then(([sky, tex, props, sfx]) => ({ sky, tex, props, sfx, cars: {}, skyKey: want.sky }));
    }
    /* the car templates a race / the preview needs: true when all are ready, else starts loading them and returns false */
    const carLoading = {};
    function needCars(ids) {
      let ok = true;
      for (const id of ids) {
        if (ASSETS.cars[id]) continue;
        ok = false;
        if (!carLoading[id]) carLoading[id] = loadCarTpl(H, id, tierId).then((t) => { ASSETS.cars[id] = t; }).catch((e) => { carLoading[id] = null; note('차를 불러오지 못했어요'); console.warn(e); });
      }
      return ok;
    }

    /* ======================= 하늘 · 빛 ======================= */
    let sun = null, hemi = null, fogCol = new THREE.Color(0x8899aa), sunDir = new THREE.Vector3(0.4, 0.8, 0.3).normalize(), pmrem = null, nightK = 0;
    let skyKeyNow = null, skyLoading = false;
    function setupSky(s) {
      if (sun) { scene.remove(sun, sun.target); sun.dispose && sun.dispose(); sun = null; }
      if (hemi) { scene.remove(hemi); hemi = null; }
      if (scene.environment) { scene.environment.dispose(); scene.environment = null; }
      if (scene.background && scene.background.dispose) scene.background.dispose();
      if (pmrem) { pmrem.dispose(); pmrem = null; }
      skyKeyNow = SKY_KEY(s);
      const im = ASSETS.sky;
      const tex = new THREE.Texture(im); tex.needsUpdate = true; tex.colorSpace = THREE.SRGBColorSpace; tex.mapping = THREE.EquirectangularReflectionMapping;
      scene.background = tex;
      pmrem = new THREE.PMREMGenerator(R);
      scene.environment = pmrem.fromEquirectangular(tex).texture;
      // horizon colour (fog) and the brightest point of the sky (sun)
      const c = document.createElement('canvas'); c.width = 128; c.height = 64;
      const g = c.getContext('2d'); g.drawImage(im, 0, 0, 128, 64);
      const d = g.getImageData(0, 0, 128, 64).data;
      let r = 0, gg = 0, b = 0, n = 0, best = -1, bx = 0, by = 0;
      for (let y = 0; y < 64; y++) for (let x = 0; x < 128; x++) {
        const i = (y * 128 + x) * 4, lum = d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11;
        if (y >= 29 && y <= 31) { r += d[i]; gg += d[i + 1]; b += d[i + 2]; n++; }
        if (y < 30 && lum > best) { best = lum; bx = x; by = y; }
      }
      fogCol = new THREE.Color(r / n / 255, gg / n / 255, b / n / 255);
      fogCol.convertSRGBToLinear();
      const night = s.tod === 'night', dusk = s.tod === 'dusk', rain = s.wx === 'rain';
      nightK = night ? 1 : 0;
      if (!night && best > 200) {   // equirect: u → longitude, v → latitude
        const lon = (bx / 128) * 2 * PI - PI / 2, lat = (0.5 - by / 64) * PI;
        sunDir.set(Math.cos(lat) * Math.cos(lon), Math.max(0.12, Math.sin(lat)), -Math.cos(lat) * Math.sin(lon)).normalize();
        sunDir.x = -sunDir.x;
      } else sunDir.set(0.35, 0.85, 0.2).normalize();
      const cfg = night ? { si: 0.34, sc: 0x9fb2ff, hi: 0.4, ei: 0.16, ex: 1.05, bi: 0.16 }
        : dusk ? { si: rain ? 0.9 : 2.0, sc: 0xffb27a, hi: 0.35, ei: rain ? 0.6 : 0.85, ex: rain ? 0.85 : 1.0, bi: rain ? 0.7 : 1 }
          : rain ? { si: 0.85, sc: 0xdfe6ef, hi: 0.5, ei: 0.95, ex: 1.0, bi: 1 }
            : { si: 2.7, sc: 0xfff1dc, hi: 0.35, ei: 0.9, ex: 1.0, bi: 1 };
      R.toneMappingExposure = cfg.ex;
      scene.environmentIntensity = cfg.ei;
      scene.backgroundIntensity = cfg.bi;
      hemi = new THREE.HemisphereLight(night ? 0x5566aa : 0xdde8ff, night ? 0x10141a : 0x3b4a2c, cfg.hi); scene.add(hemi);
      sun = new THREE.DirectionalLight(cfg.sc, cfg.si);
      sun.castShadow = TIER.shadow > 0 && !night;
      if (sun.castShadow) {
        const S = TIER.id === 'high' ? 60 : 42;
        sun.shadow.mapSize.set(TIER.shadow, TIER.shadow);
        Object.assign(sun.shadow.camera, { left: -S, right: S, top: S, bottom: -S, near: 1, far: 400 });
        sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.04;
      }
      scene.add(sun); scene.add(sun.target);
      const fogFar = rain ? 650 : night ? 900 : 1700;
      scene.fog = new THREE.Fog(rain ? fogCol.clone().lerp(new THREE.Color(0x8a9099), 0.4) : fogCol, rain ? 60 : 220, fogFar);
    }

    /* ======================= 서킷 짓기 ======================= */
    /* sim (sample i, lateral offset) → three. Banked corners: the road height changes across (H − lat × BK) */
    const X3 = (T0, i, lat, up) => new THREE.Vector3(T0.X[i] - T0.TY[i] * lat, T0.H[i] - lat * (T0.BK ? T0.BK[i] || 0 : 0) + (up || 0), -(T0.Y[i] + T0.TX[i] * lat));
    /* 맵 그림(로직 값은 hyperrace.js THEMES): gt = 쓰는 결 묶음 · ground 바닥 결 · tint 바닥 색 곱 · hills 언덕 배율 · far 지평선 색 · mount 먼 산(결 · 높이 · 메사 · 눈 · 초록) ·
       flora [atlas 이름, 비율, 크기] · dens 나무 수 배율 · near 길에서 떨어진 거리 · rocks 길가 바위 · sea 바다 · city 건물 · wall/band 벽 색 */
    const LOOK = {
      park: { hills: 1 },
      coast: { gt: ['sand', 'cliff'], ground: null, shore: [1.45, 1.28, 0.86], tint: [1.0, 1.06, 0.86], uv: 9, hills: 0.9, far: 0x2a4656, sea: 1, flora: [['palm1', 0.55, 1], ['bush', 0.3, 0.9], ['broadleaf', 0.15, 1]], dens: 0.7, near: 8, rocks: ['boulder', 'crag'], rockS: 2.2, mount: { tex: 'cliff', h: [60, 210], col: [0.8, 0.8, 0.78] }, band: '#d23b2f' },
      canyon: { gt: ['sand', 'rock'], ground: 'sand', tint: [1.18, 0.92, 0.72], uv: 8, hills: 1.3, far: 0xa0643a, flora: [['quiver', 0.3, 1.4], ['dryshrub', 0.42, 3], ['boulder', 0.16, 2.2], ['rockpile', 0.12, 1.8]], dens: 0.55, near: 6, spread: 1.3, rocks: ['rubble', 'boulder', 'crag'], rockS: 3.2, mount: { tex: 'rock', h: [90, 280], mesa: 1, col: [1.15, 0.85, 0.66] }, wall: 0xe7d2b6, band: '#c8641e' },
      snow: { gt: ['snow', 'cliff'], ground: 'snow', tint: [1.0, 1.02, 1.06], uv: 10, hills: 1.8, far: 0xdfe6ee, flora: [['pine', 0.85, 1], ['boulder', 0.15, 1.6]], dens: 1.1, near: 9, rocks: ['crag', 'boulder'], rockS: 2.4, mount: { tex: 'cliff', h: [160, 460], snow: 1, col: [0.75, 0.76, 0.8] }, band: '#d23b2f', moundCol: 0xffffff },
      forest: { gt: ['forest', 'cliff'], ground: 'forest', tint: [0.82, 1.02, 0.74], uv: 6, hills: 1.6, far: 0x2a4026, flora: [['pine', 0.5, 1.3], ['broadleaf', 0.35, 1.8], ['bush', 0.15, 1.2]], dens: 2.6, near: 5, spread: 2.4, rocks: ['crag', 'boulder'], rockS: 2, mount: { tex: 'cliff', h: [80, 240], green: 1, col: [0.7, 0.72, 0.66] }, band: '#2f8a4a' },
      city: { gt: ['paving', 'facade'], ground: 'paving', tint: [0.95, 0.95, 0.97], uv: 6, hills: 0.08, far: 0x2b2e34, flora: [['broadleaf', 1, 1]], dens: 0.18, near: 4, city: 1, wall: 0xcfd0d2, band: '#e8c21c' },
      plateau: { gt: ['dryg', 'cliff'], ground: 'dryg', tint: [1.08, 1.04, 0.86], uv: 9, hills: 1.2, far: 0x6f6747, flora: [['dryshrub', 0.55, 3.2], ['boulder', 0.25, 2], ['rockpile', 0.2, 1.6]], dens: 0.85, near: 7, rocks: ['boulder', 'rubble', 'crag'], rockS: 3.2, mount: { tex: 'cliff', h: [140, 380], snow: 1, col: [0.8, 0.78, 0.7] } },
    };
    let TH0 = { g: {}, flora: null, rocks: {} }, SEA = null;
    let hash = null;
    function buildHash(T0) {
      const m = new Map(), C = 40;
      for (let i = 0; i < T0.n; i++) { const k = Math.floor(T0.X[i] / C) + ',' + Math.floor(T0.Y[i] / C); if (!m.has(k)) m.set(k, []); m.get(k).push(i); }
      hash = { m, C };
    }
    function nearest(T0, x, y, rad) {   // sim coords → [dist, idx] (dist 1e9 when nothing within ~rad)
      const C = hash.C, cx = Math.floor(x / C), cy = Math.floor(y / C), rr = Math.ceil((rad || 80) / C);
      let bd = 1e18, bi = -1;
      for (let a = -rr; a <= rr; a++) for (let b = -rr; b <= rr; b++) {
        const L0 = hash.m.get((cx + a) + ',' + (cy + b)); if (!L0) continue;
        for (const i of L0) { const dx = x - T0.X[i], dy = y - T0.Y[i], d = dx * dx + dy * dy; if (d < bd) { bd = d; bi = i; } }
      }
      return bi < 0 ? [1e9, -1] : [Math.sqrt(bd), bi];
    }
    function vnoise(x, y, seed) {
      const hs = (i, j) => { let n = (i * 374761393 + j * 668265263 + seed * 1442695041) | 0; n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; };
      const i = Math.floor(x), j = Math.floor(y), fx = x - i, fy = y - j, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
      return lerp(lerp(hs(i, j), hs(i + 1, j), u), lerp(hs(i, j + 1), hs(i + 1, j + 1), u), v);
    }
    /* map looks (docs/HYPERRACE.md 「맵 · 코스」): ground texture (gt_*), its tint, hills, far mountains, plants (flora atlas), rocks, sea, city blocks */
    function terrainH(T0, x, y) {
      const [d, i] = nearest(T0, x, y, 120), LK = LOOK[T0.th] || LOOK.park;
      let far = (vnoise(x / 260, y / 260, T0.seed) - 0.35) * 26 * LK.hills + vnoise(x / 70, y / 70, T0.seed + 3) * 4 * Math.min(1, LK.hills) + Math.max(0, bboxDist(x, y) - 120) * 0.09 * LK.hills;
      if (SEA) { const s = (x - SEA.cx) * SEA.dx + (y - SEA.cy) * SEA.dy - SEA.line; if (s > 0) far = Math.min(far, SEA.y + 4 - s * 0.35); }
      if (i < 0) return far;
      const Dw = T0.WD[i], lat = (x - T0.X[i]) * -T0.TY[i] + (y - T0.Y[i]) * T0.TX[i];
      const near = T0.H[i] - clamp(lat, -Dw, Dw) * (T0.BK[i] || 0) - 0.08;
      let h = lerp(near, Math.max(far, near - 2), sstep(Dw + 4, Dw + 90, d));
      const g = gorgeK(T0, i);   // under a bridge: a valley across the road, deepest in the middle of the span
      if (g > 0) h = lerp(h, T0.H[i] - 26 * g, 1 - sstep(Dw + 22, Dw + 80, d));
      return h;
    }
    /* 0..1 how deep the gorge under the bridge is at sample i (0 at the abutments) */
    function gorgeK(T0, i) {
      const b = T0.BRG; if (!b) return 0;
      if (i < b[0] - 2 || i > b[1] + 2) return 0;
      return clamp(Math.min(i - b[0], b[1] - i) / 7, 0, 1);
    }
    const inSpan = (T0, i, m) => [T0.TUN, T0.BRG].some((sp) => sp && i >= sp[0] - (m || 0) && i <= sp[1] + (m || 0));
    let BB = null;
    const bboxDist = (x, y) => { if (!BB) return 0; const dx = Math.max(BB[0] - x, 0, x - BB[2]), dy = Math.max(BB[1] - y, 0, y - BB[3]); return Math.hypot(dx, dy); };
    function ribbon(T0, i0, i1, lat0, lat1, up0, up1, uvS, uvL, mat, o) {   // a strip along samples i0..i1 (wraps) between two lateral offsets
      const n = T0.n, pos = [], uv = [], idx = [];
      let k = 0, s = 0;
      for (let ii = i0; ii <= i1; ii++) {
        const i = ((ii % n) + n) % n;
        const a = X3(T0, i, typeof lat0 === 'function' ? lat0(i) : lat0, up0), b = X3(T0, i, typeof lat1 === 'function' ? lat1(i) : lat1, up1);
        pos.push(a.x, a.y, a.z, b.x, b.y, b.z);
        uv.push(0, s / uvL, uvS, s / uvL);
        if (k) idx.push(2 * k - 2, 2 * k - 1, 2 * k, 2 * k - 1, 2 * k + 1, 2 * k);
        k++; s += H.DS;
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
      g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
      g.setIndex(idx);
      g.computeVertexNormals();
      const m = new THREE.Mesh(g, mat);
      m.receiveShadow = TIER.shadow > 0;
      if (o && o.flip) { for (let q = 0; q < idx.length; q += 3) { const t = idx[q]; idx[q] = idx[q + 1]; idx[q + 1] = t; } g.setIndex(idx); g.computeVertexNormals(); }
      return m;
    }
    function runs(T0, test) {   // [start, end] index runs where test(i) (wrapping)
      const n = T0.n, out = [];
      let s = -1;
      for (let i = 0; i <= n; i++) {
        const on = i < n && test(i);
        if (on && s < 0) s = i;
        if (!on && s >= 0) { out.push([s - 1, i]); s = -1; }
      }
      return out;
    }
    const world = new THREE.Group();
    scene.add(world);
    let wetK = 0;
    function buildTrack(s) {
      T = H.genTrack(s.seed, s.n, s.th, s.cs, s.arc);
      buildHash(T);
      BB = [Math.min(...T.X), Math.min(...T.Y), Math.max(...T.X), Math.max(...T.Y)];
      const tex = ASSETS.tex, wet = s.wx === 'rain', D = T.half + T.run, LK = LOOK[T.th] || LOOK.park;
      TH0 = THA[T.th] || { g: {}, flora: null, rocks: {} };
      // 해안 도로: the sea on one side (a direction from the seed), its shore beyond the farthest part of the circuit that way
      SEA = null;
      if (LK.sea) {
        const a = T.LH ? Math.atan2(T.LH[1] * T.TX[T.LH[0]], -T.LH[1] * T.TY[T.LH[0]]) : (T.seed % 360) * PI / 180, dx = Math.cos(a), dy = Math.sin(a), cx = (BB[0] + BB[2]) / 2, cy = (BB[1] + BB[3]) / 2;
        let ext = -1e9; for (let i = 0; i < T.n; i++) ext = Math.max(ext, (T.X[i] - cx) * dx + (T.Y[i] - cy) * dy + T.WD[i]);
        SEA = { cx, cy, dx, dy, line: ext + 70, y: Math.min(...T.H) - 4 };
      }
      DBG.SEA = SEA;
      wetK = wet ? 1 : 0;
      const rep = (t, x, y) => { const c = t.clone(); c.repeat.set(x, y); c.needsUpdate = true; return c; };
      // road
      const roadM = new THREE.MeshStandardMaterial({ map: tex.asphalt_c, normalMap: tex.asphalt_n, roughnessMap: wet ? null : tex.asphalt_r, roughness: wet ? 0.22 : 1, metalness: 0, color: wet ? 0x9a9a9e : 0xe2e2e2, normalScale: wet ? new THREE.Vector2(0.4, 0.4) : new THREE.Vector2(0.8, 0.8), polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
      roadM.envMapIntensity = wet ? 1.5 : 0.45;
      world.add(ribbon(T, 0, T.n, T.half, -T.half, 0.06, 0.06, (T.half * 2) / 7, 7, roadM));
      // white edge lines
      const lineM = new THREE.MeshStandardMaterial({ color: 0xf2f2ee, roughness: 0.55, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
      world.add(ribbon(T, 0, T.n, T.half - 0.25, T.half - 0.5, 0.075, 0.075, 1, 6, lineM));
      world.add(ribbon(T, 0, T.n, -T.half + 0.5, -T.half + 0.25, 0.075, 0.075, 1, 6, lineM));
      // curbs (red / white, raised outer edge)
      const curbT = canvasTex(8, 64, (g, w, hh) => { for (let k = 0; k < 4; k++) { g.fillStyle = k % 2 ? '#f1efe9' : '#d1281f'; g.fillRect(0, (k * hh) / 4, w, hh / 4); } }, { rep: true });
      const curbM = new THREE.MeshStandardMaterial({ map: curbT, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 });
      for (const [a, b] of runs(T, (i) => T.CU[i])) {
        world.add(ribbon(T, a, b, T.half + 1.3, T.half - 0.05, 0.13, 0.07, 1, 8, curbM));
        world.add(ribbon(T, a, b, -T.half + 0.05, -T.half - 1.3, 0.07, 0.13, 1, 8, curbM));
      }
      // gravel traps on the outside of the faster corners
      const gravM = new THREE.MeshStandardMaterial({ map: rep(tex.gravel_c, 1, 1), normalMap: tex.gravel_n, roughness: 1, color: 0xd9cdb6, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
      for (const sd of [1, -1]) for (const [a, b] of runs(T, (i) => T.RO[i] === sd)) {
        world.add(ribbon(T, a, b, sd > 0 ? D - 1.2 : -T.half - 1.3, sd > 0 ? T.half + 1.3 : -D + 1.2, 0.05, 0.05, (T.run - 2.5) / 4, 4, gravM));
      }
      // barrier walls (concrete) with a painted top band — at each sample's wall distance (narrower in tunnels / on bridges)
      const wallM = new THREE.MeshStandardMaterial({ map: rep(tex.concrete_c, 1, 1), normalMap: tex.concrete_n, roughness: 0.92, color: LK.wall || 0xd8d6d2, side: THREE.DoubleSide });
      const bandT = canvasTex(64, 8, (g, w, hh) => { for (let k = 0; k < 2; k++) { g.fillStyle = k ? '#f4f4f4' : LK.band || '#1d5fd0'; g.fillRect((k * w) / 2, 0, w / 2, hh); } }, { rep: true });
      const bandM = new THREE.MeshStandardMaterial({ map: bandT, roughness: 0.6, side: THREE.DoubleSide });
      for (const sd of [1, -1]) {
        const lat = (i) => sd * T.WD[i];
        const g = wallGeo(T, lat, -0.6, 0.85), g2 = wallGeo(T, lat, 0.85, 1.1);
        const w1 = new THREE.Mesh(g, wallM), w2 = new THREE.Mesh(g2, bandM);
        w1.receiveShadow = w2.receiveShadow = TIER.shadow > 0; w1.castShadow = TIER.id === 'high';
        world.add(w1, w2);
        if (TIER.id !== 'low' || T.th === 'city') world.add(fenceMesh(T, (i) => sd * (T.WD[i] + 0.05)));
      }
      // start / finish: chequered stripe + grid boxes
      const chk = canvasTex(64, 8, (g, w, hh) => { for (let x = 0; x < 16; x++) for (let y = 0; y < 2; y++) { g.fillStyle = (x + y) % 2 ? '#111' : '#f4f4f4'; g.fillRect(x * 4, y * 4, 4, 4); } });
      const sl = ribbon(T, 0, 1, T.half, -T.half, 0.085, 0.085, 1, 4, new THREE.MeshStandardMaterial({ map: chk, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: -5, polygonOffsetUnits: -5 }));
      world.add(sl);
      const boxM = new THREE.MeshBasicMaterial({ color: 0xe8e8e8, polygonOffset: true, polygonOffsetFactor: -5, polygonOffsetUnits: -5 });
      for (let slot = 0; slot < s.n; slot++) {
        const back = 10 + slot * 8.5 - 2.6, i = ((-Math.round(back / H.DS)) % T.n + T.n) % T.n, lat = (slot % 2 ? -1 : 1) * Math.min(T.half - 2.2, 3.1);
        const a = X3(T, i, lat + 1.2, 0.09), b = X3(T, i, lat - 1.2, 0.09);
        const geo = new THREE.BufferGeometry().setFromPoints([a, b]);
        const q = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.22), boxM);
        q.position.copy(a.clone().add(b).multiplyScalar(0.5)); q.rotation.x = -PI / 2; q.rotation.z = Math.atan2(-(b.z - a.z), b.x - a.x);
        world.add(q); geo.dispose();
      }
      buildTerrain(s);
      buildTrees(s);
      buildProps(s);
      buildSetPieces(s);
      buildSigns();
      buildGuide();
      buildMinimap();
    }
    /* 코너 읽기: 코너 바깥 벽에 화살표 판(급할수록 빨강), 긴 직선 끝 급코너 앞에는 150 · 100 · 50m 제동 판 */
    const signTex = {};
    function signMat(kind) {
      if (signTex[kind]) return signTex[kind];
      const t = canvasTex(256, 128, (g, w, hh) => {
        if (kind[0] === 'c') {   // chevron: c<dir L/R><severity 0..2>
          const col = ['#f2c230', '#f07a22', '#e2231a'][+kind[2]], left = kind[1] === 'L';
          g.fillStyle = '#16161a'; g.fillRect(0, 0, w, hh); g.fillStyle = col; g.fillRect(6, 6, w - 12, hh - 12);
          g.fillStyle = '#111';
          for (let k = 0; k < 2; k++) {
            const x0 = w * (0.24 + k * 0.32);
            g.beginPath();
            if (left) { g.moveTo(x0 + 34, 18); g.lineTo(x0 - 14, hh / 2); g.lineTo(x0 + 34, hh - 18); g.lineTo(x0 + 58, hh - 18); g.lineTo(x0 + 10, hh / 2); g.lineTo(x0 + 58, 18); }
            else { g.moveTo(x0 - 4, 18); g.lineTo(x0 + 44, hh / 2); g.lineTo(x0 - 4, hh - 18); g.lineTo(x0 - 28, hh - 18); g.lineTo(x0 + 20, hh / 2); g.lineTo(x0 - 28, 18); }
            g.closePath(); g.fill();
          }
        } else {   // braking board: b<metres>
          g.fillStyle = '#f4f4f0'; g.fillRect(0, 0, w, hh); g.strokeStyle = '#1d5fd0'; g.lineWidth = 10; g.strokeRect(5, 5, w - 10, hh - 10);
          g.fillStyle = '#111'; g.font = 'bold 84px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(kind.slice(1), w / 2, hh / 2 + 4);
        }
      });
      return (signTex[kind] = new THREE.MeshStandardMaterial({ map: t, roughness: 0.55, emissive: 0xffffff, emissiveMap: t, emissiveIntensity: nightK ? 0.55 : 0.12 }));
    }
    function corners(T0) {   // [{a, b, apex, dir, R, run}] runs of real corners (radius < 150 m)
      const n = T0.n, out = [];
      for (const [a, b] of runs(T0, (i) => Math.abs(T0.K[i]) > 1 / 150)) {
        let apex = a, km = 0; for (let i = a; i <= b; i++) { const k = Math.abs(T0.K[((i % n) + n) % n]); if (k > km) { km = k; apex = i; } }
        const R = 1 / km; if (R > 110) continue;
        let run = 0; while (run < 200 && Math.abs(T0.K[((a - run) % n + n) % n]) < 1 / 150) run++;
        out.push({ a, b, apex, dir: Math.sign(T0.K[((apex % n) + n) % n]), R, run: run * H.DS });
      }
      return out;
    }
    function buildSigns() {
      const D = T.half + T.run, geo = new THREE.PlaneGeometry(3.6, 1.8), post = new THREE.CylinderGeometry(0.08, 0.08, 1.4, 6), postM = new THREE.MeshStandardMaterial({ color: 0x55585e, roughness: 0.6 });
      const put = (i, lat, mat, turn) => {
        i = ((i % T.n) + T.n) % T.n;
        const g = new THREE.Group(), q = new THREE.Mesh(geo, mat), p = new THREE.Mesh(post, postM);
        q.position.y = 2.25; p.position.y = 0.7; g.add(q, p);
        const pp = X3(T, i, lat, 0); g.position.set(pp.x, T.H[i], pp.z);
        // face the oncoming cars, turned a little towards the road
        g.rotation.y = Math.atan2(T.TY[i], T.TX[i]) - PI / 2 + (turn || 0);
        world.add(g);
      };
      for (const c of corners(T)) {
        const sev = c.R < 50 ? 2 : c.R < 80 ? 1 : 0, out = -c.dir, mat = signMat('c' + (c.dir > 0 ? 'L' : 'R') + sev);
        // chevrons on the outside wall from the turn-in to just past the apex
        const from = c.a + 2, to = Math.min(c.b, c.apex + 4), step = Math.max(3, Math.round((to - from) / 4));
        for (let i = from; i <= to; i += step) { const j = ((i % T.n) + T.n) % T.n; if (!inSpan(T, j, 0)) put(i, out * (T.WD[j] - 0.9), mat, -out * 0.35); }
        // braking boards before a slow corner at the end of a fast run
        if (c.R < 80 && c.run > 180) for (const m of [150, 100, 50]) put(c.a - Math.round((m + 10) / H.DS), out * (T.half + 2.2), signMat('b' + m), 0);
      }
    }
    /* 주행선 안내(설정, 보조 「켬」이면 기본 켬): 레이싱 라인 위의 띠 — 지금 속도로 그 자리까지 줄일 수 있으면 초록, 곧 줄여야 하면 노랑, 지금 밟아야 하면 빨강 */
    let guide = null;
    const guideOn = () => { const v = H.store.get('guide', ''); return v === '1' || (v === '' && assist === 2); };
    function buildGuide() {
      const n = T.n, pos = new Float32Array((n + 1) * 6), col = new Float32Array((n + 1) * 8), idx = [];
      for (let k = 0; k <= n; k++) {
        const i = k % n, x = T.LX[i], y = T.LY[i], hw = 0.45;
        pos.set([x + T.TY[i] * hw, T.H[i] + 0.1, -(y - T.TX[i] * hw), x - T.TY[i] * hw, T.H[i] + 0.1, -(y + T.TX[i] * hw)], k * 6);
        if (k) idx.push(2 * k - 2, 2 * k - 1, 2 * k, 2 * k - 1, 2 * k + 1, 2 * k);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 4)); g.setIndex(idx);
      const m = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -7, polygonOffsetUnits: -7 });
      const mesh = new THREE.Mesh(g, m); mesh.frustumCulled = false; mesh.renderOrder = 1; mesh.visible = false;
      world.add(mesh);
      guide = DBG.guide = { mesh, col, last: [] };
    }
    function guideTick(c) {
      if (!guide) return;
      const on = !!c && guideOn() && (phase === 'race' || phase === 'count') && camMode !== 4;
      guide.mesh.visible = on;
      if (!on) return;
      const n = T.n, col = guide.col, prof = H.speedProfile(T, c, wetK > 0, 1), p = H.phOf(c);
      for (const k of guide.last) col.fill(0, k * 8, k * 8 + 8);
      guide.last.length = 0;
      const v = Math.max(0, c.vf), cap = p.brake * 9.81 * 1.3 * (wetK ? 0.82 : 1) * 0.85;
      for (let q = 1; q < 75; q++) {
        const i = (c.idx + q) % n, d = q * H.DS, vp = prof[i] * 0.98;
        let r = 0.2, g = 0.95, b = 0.45;
        if (v > vp) {
          const need = (v * v - vp * vp) / (2 * Math.max(4, d - v * 0.25)) / cap;   // a quarter second to react
          if (need > 0.85) { r = 1; g = 0.16; b = 0.12; } else if (need > 0.45) { r = 1; g = 0.78; b = 0.15; }
        }
        const a = 0.75 * clamp((d - 3) / 10, 0, 1) * clamp((290 - d) / 90, 0, 1);
        for (const k of i === 0 ? [0, n] : [i]) { col.set([r, g, b, a, r, g, b, a], k * 8); guide.last.push(k); }
      }
      guide.mesh.geometry.attributes.color.needsUpdate = true;
    }
    function wallGeo(T0, lat, y0, y1, i0, i1) {   // lat: number or (i) => lateral offset; optional sample range
      const n = T0.n, pos = [], uv = [], idx = [], a = i0 == null ? 0 : i0, b = i1 == null ? n : i1;
      for (let k = a; k <= b; k++) {
        const i = ((k % n) + n) % n, L0 = typeof lat === 'function' ? lat(i) : lat, p = X3(T0, i, L0, 0), q = k - a;
        pos.push(p.x, p.y + y0, p.z, p.x, p.y + y1, p.z);
        uv.push((k * H.DS) / 3, 0, (k * H.DS) / 3, (y1 - y0) / 3);
        if (q) idx.push(2 * q - 2, 2 * q - 1, 2 * q, 2 * q - 1, 2 * q + 1, 2 * q);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals();
      return g;
    }
    let fenceTex = null;
    function fenceMesh(T0, lat) {
      if (!fenceTex) fenceTex = canvasTex(64, 64, (g, w, hh) => {
        g.clearRect(0, 0, w, hh); g.strokeStyle = 'rgba(205,210,215,1)'; g.lineWidth = 3;
        g.beginPath(); g.moveTo(0, 0); g.lineTo(w, hh); g.moveTo(w, 0); g.lineTo(0, hh); g.stroke();
        g.fillStyle = 'rgba(90,95,100,1)'; g.fillRect(0, 0, 4, hh);
      }, { rep: true });
      const g = wallGeo(T0, lat, 1.1, 3.6);
      const uv = g.getAttribute('uv'); for (let k = 0; k < uv.count; k++) uv.setXY(k, uv.getX(k) * 3 / 1.2, uv.getY(k) * 3 / 1.2);
      // 철망: alphaTest로 자르면 먼 곳에서 가는 선이 점점이 끊겨 달리는 내내 반짝거림 → 화면이 다중 표본(MSAA)이면 알파를 덮임 비율로(alphaToCoverage) 넘겨 멀수록 옅게 풀림
      let msaa = false; try { const gl = R.getContext(); msaa = gl.getParameter(gl.SAMPLES) > 1; } catch (e) {}
      const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: fenceTex, alphaTest: msaa ? 0 : 0.5, alphaToCoverage: msaa, transparent: false, side: THREE.DoubleSide, roughness: 0.5, metalness: 0.6 }));
      return m;
    }
    function buildTerrain(s) {
      const tex = ASSETS.tex, LK = LOOK[T.th] || LOOK.park, G = LK.ground && TH0.g[LK.ground], M = 520, N = TIER.id === 'low' ? 110 : TIER.id === 'mid' ? 160 : 210;
      const x0 = BB[0] - M, y0 = BB[1] - M, sx = (BB[2] - BB[0] + 2 * M) / N, sy = (BB[3] - BB[1] + 2 * M) / N;
      const pos = [], uv = [], col = [], idx = [];
      const dry = s.tod === 'dusk' && !G ? 0.25 : 0, tint = LK.tint || [1.05, 1.08, 0.92], uvS = LK.uv || 9;
      for (let j = 0; j <= N; j++) for (let i = 0; i <= N; i++) {
        const x = x0 + i * sx, y = y0 + j * sy, hh = terrainH(T, x, y);
        pos.push(x, hh, -y); uv.push(x / uvS, y / uvS);
        const v = vnoise(x / 90, y / 90, T.seed + 9), k = 0.78 + v * 0.3;
        // rock shows through on steep / high ground (mountain maps), wet sand by the sea
        let r = k * (tint[0] + dry * 0.3 + v * 0.18), g = k * (tint[1] - v * 0.04), b = k * (tint[2] - dry * 0.2);
        if (SEA) {   // a sandy shore band, darker wet sand at the water
          const sd = (x - SEA.cx) * SEA.dx + (y - SEA.cy) * SEA.dy - SEA.line, k2 = sstep(-60, -5, sd);
          if (k2 > 0 && LK.shore) { r = lerp(r, k * LK.shore[0], k2); g = lerp(g, k * LK.shore[1], k2); b = lerp(b, k * LK.shore[2], k2); }
          if (hh < SEA.y + 1.5) { r *= 0.8; g *= 0.8; b *= 0.85; }
        }
        col.push(r, g, b);
        if (i < N && j < N) { const a = j * (N + 1) + i, b2 = a + 1, c = a + N + 1, d = c + 1; idx.push(a, b2, c, b2, d, c); }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      g.setIndex(idx); g.computeVertexNormals();
      const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: G ? G.c : tex.grass_c, normalMap: G ? G.n : tex.grass_n, roughness: LK.ground === 'snow' ? 0.75 : 1, vertexColors: true, color: s.tod === 'night' ? 0xb0b8b0 : 0xffffff }));
      m.material.envMapIntensity = 0.6;
      m.receiveShadow = TIER.shadow > 0;
      world.add(m);
      // the far ring to the horizon (low, flat, fogged)
      const ring = new THREE.Mesh(new THREE.RingGeometry(Math.max(BB[2] - BB[0], BB[3] - BB[1]) * 0.5 + M * 0.8, 6000, 48, 1), new THREE.MeshStandardMaterial({ color: LK.far || 0x46552f, roughness: 1 }));
      ring.rotation.x = -PI / 2; ring.position.set((BB[0] + BB[2]) / 2, SEA ? SEA.y - 3 : -6, -(BB[1] + BB[3]) / 2);
      world.add(ring);
      buildMountains(s);
      if (SEA) buildSea(s);
    }
    /* far mountains: a ring of noisy peaks well outside the circuit (fog softens them) — rock texture, snow caps on 설산, green on 숲 */
    function buildMountains(s) {
      const LK = LOOK[T.th] || LOOK.park, MT = LK.mount; if (!MT) return;
      const G = TH0.g[MT.tex] || null, cx = (BB[0] + BB[2]) / 2, cy = (BB[1] + BB[3]) / 2;
      const R0 = Math.max(BB[2] - BB[0], BB[3] - BB[1]) * 0.5 + 700, R1 = R0 + 2600, A = TIER.id === 'low' ? 96 : 160, RN = 10;
      const pos = [], uv = [], col = [], idx = [];
      for (let a = 0; a <= A; a++) for (let r = 0; r <= RN; r++) {
        const t = (a / A) * PI * 2, f = r / RN, R = R0 + (R1 - R0) * f, x = cx + Math.cos(t) * R, y = cy + Math.sin(t) * R;
        // ridge profile: rises from the plain, peaks around a third out, stays high to the horizon
        const prof = sstep(0, 0.3, f) * (0.75 + 0.25 * (1 - f));
        let n = vnoise(x / 520, y / 520, T.seed + 41) * 0.65 + vnoise(x / 180, y / 180, T.seed + 42) * 0.35;
        if (MT.mesa) n = Math.min(1, Math.round(n * 3.2) / 3.2 + vnoise(x / 60, y / 60, T.seed + 43) * 0.08);   // flat-topped mesas
        const sea = SEA && (x - SEA.cx) * SEA.dx + (y - SEA.cy) * SEA.dy > SEA.line + 200;
        const hh = sea ? SEA.y - 20 : -6 + prof * (MT.h[0] + n * (MT.h[1] - MT.h[0]));
        pos.push(x, hh, -y); uv.push(x / 60, (y + hh) / 60);
        const hk = hh / MT.h[1];
        let c = MT.col || [0.85, 0.82, 0.78];
        if (MT.snow && hk > 0.42 - n * 0.1) c = [1.25, 1.27, 1.32];
        else if (MT.green && hk < 0.55) c = [0.55, 0.72, 0.45];
        col.push(c[0], c[1], c[2]);
        if (a < A && r < RN) { const p = a * (RN + 1) + r, q = p + RN + 1; idx.push(p, q, p + 1, q, q + 1, p + 1); }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
      g.setIndex(idx); g.computeVertexNormals();
      const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: G ? G.c : null, normalMap: G ? G.n : null, color: 0xffffff, vertexColors: true, roughness: 1, side: THREE.DoubleSide }));
      m.material.envMapIntensity = 0.5;
      world.add(m);
    }
    /* the sea (해안 도로): one big water plane on one side, waves = a scrolling normal map */
    let waterN = null;
    const waters = [];
    function waterMat() {
      if (!waterN) waterN = canvasTex(256, 256, (g, w, hh) => {
        const im = g.createImageData(w, hh), r = H.prng(5);
        const hgt = []; for (let k = 0; k < w * hh; k++) hgt.push(0);
        for (let o = 0; o < 40; o++) { const fx = 1 + Math.floor(r() * 6), fy = 1 + Math.floor(r() * 6), ph = r() * 6.28, am = 1 / (fx + fy); for (let y = 0; y < hh; y++) for (let x = 0; x < w; x++) hgt[y * w + x] += am * Math.sin((x * fx / w + y * fy / hh) * PI * 2 + ph); }
        for (let y = 0; y < hh; y++) for (let x = 0; x < w; x++) {
          const k = y * w + x, dx = hgt[y * w + (x + 1) % w] - hgt[k], dy = hgt[((y + 1) % hh) * w + x] - hgt[k], l = Math.hypot(dx * 6, dy * 6, 1);
          im.data[k * 4] = 128 + (-dx * 6 / l) * 127; im.data[k * 4 + 1] = 128 + (-dy * 6 / l) * 127; im.data[k * 4 + 2] = 128 + (1 / l) * 127; im.data[k * 4 + 3] = 255;
        }
        g.putImageData(im, 0, 0);
      }, { rep: true });
      waterN.colorSpace = THREE.NoColorSpace;
      const t = waterN.clone(); t.needsUpdate = true; t.repeat.set(60, 60);
      const m = new THREE.MeshStandardMaterial({ color: 0x14394d, roughness: 0.06, metalness: 0.1, normalMap: t, normalScale: new THREE.Vector2(0.35, 0.35) });
      m.envMapIntensity = 1.2;
      waters.push(t);
      return m;
    }
    function buildSea() {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(16000, 16000), waterMat());
      m.rotation.x = -PI / 2; m.position.set(SEA.cx + SEA.dx * (SEA.line + 8000), SEA.y, -(SEA.cy + SEA.dy * (SEA.line + 8000)));
      world.add(m);
    }
    // tree impostors: atlas rects (fir ×3 | jacaranda) — see tools/hyperrace/README.txt
    const TREES = [[0.0068, 0.0195, 0.1763, 1, 19.32], [0.1792, 0.2715, 0.3242, 1, 19.32], [0.3296, 0.249, 0.4932, 1, 19.32], [0.5049, 0.2178, 0.9951, 1, 24.9]];
    // map plants / rock formations: flora.webp atlas (u0, v0, u1, v1 from the top · height m · width m)
    const FLORA = { palm1: [0.0039, 0.0078, 0.1802, 0.4922, 10.11, 7.37], quiver: [0.1841, 0.0078, 0.2896, 0.4922, 2.72, 1.18], pine: [0.2935, 0.0078, 0.4111, 0.4922, 14.88, 7.23],
      broadleaf: [0.415, 0.0078, 0.6436, 0.4922, 5.03, 4.76], bush: [0.6475, 0.0078, 0.957, 0.4922, 3.24, 4.15], dryshrub: [0.0039, 0.5322, 0.2993, 0.9922, 0.54, 0.69],
      boulder: [0.3032, 0.5322, 0.6084, 0.9922, 1.9, 2.52], rockpile: [0.6123, 0.5322, 0.9956, 0.9922, 4.97, 8.29] };
    function buildTrees(s) {
      const LK = LOOK[T.th] || LOOK.park, rnd = H.prng(T.seed * 3 + 11), total = Math.round(TIER.trees * (LK.dens || 1));
      const useAtlas = !!(LK.flora && TH0.flora);
      const kinds = useAtlas ? LK.flora : [['f0', 0.24], ['f1', 0.24], ['f2', 0.24], ['jac', 0.28]];
      const mat = new THREE.MeshStandardMaterial({ map: useAtlas ? TH0.flora : ASSETS.tex.trees, alphaTest: 0.45, side: THREE.FrontSide, roughness: 1, metalness: 0, color: s.tod === 'night' ? 0x8090a0 : 0xffffff });
      mat.map.wrapS = mat.map.wrapT = THREE.ClampToEdgeWrapping;
      const pts = kinds.map(() => []), wsum = kinds.reduce((a, k) => a + k[1], 0);
      let tries = 0, have = 0;
      while (have < total && tries++ < total * 12) {
        const i = Math.floor(rnd() * T.n), sd = rnd() < 0.5 ? -1 : 1, D = T.WD[i], dist = D + (LK.near || 9) + Math.pow(rnd(), LK.spread || 1.6) * 260;
        const x = T.X[i] - T.TY[i] * sd * dist, y = T.Y[i] + T.TX[i] * sd * dist;
        const [d, j] = nearest(T, x, y, 120);
        if (d < (j >= 0 ? T.WD[j] : D) + (LK.near || 8) - 1) continue;
        if (i < 45 || i > T.n - 40) { if (d < D + 60) continue; }   // keep the stands / pits clear
        if (j >= 0 && inSpan(T, j, 8) && d < T.WD[j] + 30) continue;   // tunnel mouths / bridge banks
        if (SEA && (x - SEA.cx) * SEA.dx + (y - SEA.cy) * SEA.dy > SEA.line - 10) continue;   // not in the sea
        let r = rnd() * wsum, k = 0; while (k < kinds.length - 1 && r > kinds[k][1]) { r -= kinds[k][1]; k++; }
        pts[k].push([x, y, 0.5 + rnd() * 0.45, rnd() * PI]); have++;
      }
      pts.forEach((list, k) => {
        if (!list.length) return;
        let u0, v0, u1, v1, hh, w, base = -0.3;
        if (useAtlas) { const F = FLORA[kinds[k][0]]; [u0, v0, u1, v1] = F; const sc = kinds[k][2] || 1; hh = F[4] * sc * 1.6; w = F[5] * sc * 1.6; base = (/boulder|rockpile/.test(kinds[k][0]) ? -0.15 : -0.05) * hh; }
        else { const [a, b, c, d2, S] = TREES[k]; u0 = a; v0 = b; u1 = c; v1 = d2; w = (u1 - u0) * 2 * S; hh = (v1 - v0) * S; }
        const geo = crossQuad(w, hh, u0, 1 - v1, u1, 1 - v0);
        const im = new THREE.InstancedMesh(geo, mat, list.length);
        const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
        list.forEach(([x, y, sc, rot], j) => { e.set(0, rot, 0); q.setFromEuler(e); m4.compose(new THREE.Vector3(x, terrainH(T, x, y) + base * sc, -y), q, new THREE.Vector3(sc, sc * (0.9 + (j % 5) * 0.05), sc)); im.setMatrixAt(j, m4); });
        im.frustumCulled = false;
        world.add(im);
      });
      buildRocks(s);
      if (LK.city) buildCity(s);
      if (T.TUN) buildTunnel(s);
      if (T.BRG) buildBridge(s);
    }
    /* real rock meshes close to the road (instanced): a few per type, bigger on canyon / plateau */
    function buildRocks() {
      const LK = LOOK[T.th] || LOOK.park; if (!LK.rocks || !TH0.rocks) return;
      const rnd = H.prng(T.seed * 5 + 3), per = { low: 10, mid: 22, high: 36 }[TIER.id] || 10;
      for (const key of LK.rocks) {
        const src = TH0.rocks[key]; if (!src) continue;
        let mesh = null; src.traverse((o) => { if (o.isMesh && !mesh) mesh = o; }); if (!mesh) continue;
        const list = [];
        for (let t = 0; t < per * 6 && list.length < per; t++) {
          const i = Math.floor(rnd() * T.n), sd = rnd() < 0.5 ? -1 : 1, dist = T.WD[i] + 4 + Math.pow(rnd(), 1.4) * 70;
          const x = T.X[i] - T.TY[i] * sd * dist, y = T.Y[i] + T.TX[i] * sd * dist, [d, j] = nearest(T, x, y, 120);
          if (j >= 0 && d < T.WD[j] + 3.5) continue;
          if (i < 45 || i > T.n - 40) continue;
          if (SEA && (x - SEA.cx) * SEA.dx + (y - SEA.cy) * SEA.dy > SEA.line + 30) continue;
          list.push([x, y, (LK.rockS || 2) * (0.6 + rnd() * 0.9), rnd() * PI * 2]);
        }
        if (!list.length) continue;
        const im = new THREE.InstancedMesh(mesh.geometry, mesh.material, list.length), m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
        const sc0 = new THREE.Vector3(); mesh.getWorldScale(sc0);
        list.forEach(([x, y, sc, rot], k) => { e.set(0, rot, 0); q.setFromEuler(e); m4.compose(new THREE.Vector3(x, terrainH(T, x, y) - 0.25 * sc, -y), q, new THREE.Vector3(sc * sc0.x, sc * sc0.y, sc * sc0.z)); im.setMatrixAt(k, m4); });
        im.castShadow = TIER.id === 'high'; im.receiveShadow = TIER.shadow > 0; im.frustumCulled = false;
        world.add(im);
      }
    }
    /* 야경 도시: blocks of buildings along the circuit (one merged mesh, facade texture with lit windows at night) */
    function buildCity(s) {
      const G = TH0.g.facade; if (!G) return;
      const rnd = H.prng(T.seed * 7 + 1), pos = [], uv = [], nor = [], idx = [], rpos = [], ridx = [];
      const quad = (P, Nn, U, out, oi) => { const b = out.length / 3; for (const p of P) out.push(p[0], p[1], p[2]); if (Nn) for (let k = 0; k < 4; k++) nor.push(Nn[0], Nn[1], Nn[2]); if (U) uv.push(...U); oi.push(b, b + 1, b + 2, b, b + 2, b + 3); };
      const boxes = [];
      const step = 9, maxB = { low: 70, mid: 130, high: 200 }[TIER.id] || 70;
      for (let i = 0; i < T.n && boxes.length < maxB; i += step) {
        for (const sd of [1, -1]) {
          if (rnd() < 0.18) continue;
          const w = 22 + rnd() * 26, dep = 18 + rnd() * 22, hgt = 14 + Math.pow(rnd(), 1.6) * 70, gap = T.WD[i] + 5 + rnd() * 6;
          const ang = Math.atan2(T.TY[i], T.TX[i]), cx = T.X[i] - T.TY[i] * sd * (gap + dep / 2), cy = T.Y[i] + T.TX[i] * sd * (gap + dep / 2);
          // corners must stay clear of every part of the track
          const ca = Math.cos(ang), sa = Math.sin(ang), cr = [[-w / 2, -dep / 2], [w / 2, -dep / 2], [w / 2, dep / 2], [-w / 2, dep / 2]].map(([u, v]) => [cx + ca * u - sa * v, cy + sa * u + ca * v]);
          if ([[cx, cy]].concat(cr).some(([x, y]) => { const [d, j] = nearest(T, x, y, 160); return j >= 0 && d < T.WD[j] + 3; })) continue;
          if (boxes.some((b) => Math.hypot(b[0] - cx, b[1] - cy) < (b[2] + w) * 0.5)) continue;
          if ((i < 50 || i > T.n - 45)) continue;   // the stands / pits
          boxes.push([cx, cy, w, dep, hgt, ang]);
        }
      }
      for (const [cx, cy, w, dep, hgt, ang] of boxes) {
        const y0 = terrainH(T, cx, cy) - 1, ca = Math.cos(ang), sa = Math.sin(ang);
        const P = (u, v, z) => [cx + ca * u - sa * v, y0 + z, -(cy + sa * u + ca * v)];
        const sides = [[[-w / 2, -dep / 2], [w / 2, -dep / 2], w], [[w / 2, -dep / 2], [w / 2, dep / 2], dep], [[w / 2, dep / 2], [-w / 2, dep / 2], w], [[-w / 2, dep / 2], [-w / 2, -dep / 2], dep]];
        const tu = 18, tv = 18, ofs = Math.floor(rnd() * 4) * 0.25;
        for (const [a, b, L0] of sides) {
          const nx = (b[1] - a[1]), ny = -(b[0] - a[0]), l = Math.hypot(nx, ny), N0 = [(ca * nx - sa * ny) / l, 0, -(sa * nx + ca * ny) / l];
          quad([P(a[0], a[1], 0), P(b[0], b[1], 0), P(b[0], b[1], hgt), P(a[0], a[1], hgt)], N0, [ofs, 0, ofs + L0 / tu, 0, ofs + L0 / tu, hgt / tv, ofs, hgt / tv], pos, idx);
        }
        quad([P(-w / 2, -dep / 2, hgt), P(w / 2, -dep / 2, hgt), P(w / 2, dep / 2, hgt), P(-w / 2, dep / 2, hgt)], null, null, rpos, ridx);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
      const lit = s.tod === 'night' ? 1.6 : s.tod === 'dusk' ? 0.7 : 0;
      const m = new THREE.MeshStandardMaterial({ map: G.c, normalMap: G.n, emissiveMap: G.e || null, emissive: lit ? 0xffd9a0 : 0x000000, emissiveIntensity: lit, roughness: 0.85, side: THREE.DoubleSide });
      const bm = new THREE.Mesh(g, m); bm.receiveShadow = TIER.shadow > 0; bm.castShadow = TIER.id === 'high'; world.add(bm);
      const rg = new THREE.BufferGeometry(); rg.setAttribute('position', new THREE.Float32BufferAttribute(rpos, 3)); rg.setIndex(ridx); rg.computeVertexNormals();
      world.add(new THREE.Mesh(rg, new THREE.MeshStandardMaterial({ color: 0x3a3d43, roughness: 0.9, side: THREE.DoubleSide })));
    }
    /* tunnel: side walls + an arched roof + a ground mound over it, a portal at each end, a light strip along the ceiling */
    function buildTunnel(s) {
      const [a, b] = T.TUN, n = T.n, LK = LOOK[T.th] || LOOK.park, G = TH0.g[LK.ground] || null, tex = ASSETS.tex;
      const HW = 5.8, K = 10;
      const conc = new THREE.MeshStandardMaterial({ map: tex.concrete_c, normalMap: tex.concrete_n, color: 0xb9b5ae, roughness: 0.95, side: THREE.DoubleSide });
      const archY = (i, t) => HW + T.WD[i] * 0.42 * Math.sin(t);
      // walls up to the arch spring
      for (const sd of [1, -1]) { const w = new THREE.Mesh(wallGeo(T, (i) => sd * T.WD[i], -0.6, HW, a, b), conc); w.receiveShadow = TIER.shadow > 0; world.add(w); }
      // arch roof + mound: profiles across the road, swept along the samples
      const sweep = (prof, M, uvk) => {
        const pos = [], uv = [], idx = [], P = prof.length;
        for (let k = a; k <= b; k++) {
          const i = ((k % n) + n) % n;
          prof.forEach(([lat, up], q) => { const p = X3(T, i, lat(i), up(i)); pos.push(p.x, p.y, p.z); uv.push(q / (P - 1) * uvk, (k * H.DS) / 8); });
          if (k > a) { const r0 = (k - a - 1) * P, r1 = (k - a) * P; for (let q = 0; q < P - 1; q++) idx.push(r0 + q, r1 + q, r0 + q + 1, r1 + q, r1 + q + 1, r0 + q + 1); }
        }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals();
        const o = new THREE.Mesh(g, M); o.castShadow = TIER.shadow > 0; o.receiveShadow = TIER.shadow > 0; world.add(o); return o;
      };
      const arch = []; for (let q = 0; q <= K; q++) { const t = (q / K) * PI; arch.push([(i) => T.WD[i] * Math.cos(t), (i) => archY(i, t)]); }
      sweep(arch, conc, 4);
      const ext = 16, mound = [];
      for (let q = 0; q <= 12; q++) { const u = q / 12 * 2 - 1; mound.push([(i) => u * (T.WD[i] + ext), (i) => (HW + T.WD[i] * 0.42 + 1.6) * (1 - Math.pow(Math.abs(u), 2.2)) + 0.2 * Math.abs(u) - 0.2]); }
      const gm = new THREE.MeshStandardMaterial({ map: G ? G.c : tex.grass_c, normalMap: G ? G.n : tex.grass_n, roughness: 1, color: LK.moundCol || 0xffffff });
      sweep(mound, gm, 6);
      // portals: a face between the mound outline and the arch opening
      for (const [k, dir] of [[a, 1], [b, -1]]) {
        const i = ((k % n) + n) % n, Wd = T.WD[i], top = HW + Wd * 0.42 + 1.6, wide = Wd + ext;
        const sh = new THREE.Shape(); sh.moveTo(-wide, -0.9);   // (the outline must enclose the opening completely or the hole is lost)
        for (let q = 0; q <= 16; q++) { const u = q / 16 * 2 - 1; sh.lineTo(u * wide, Math.max(0, top * (1 - Math.pow(Math.abs(u), 2.2)))); }
        sh.lineTo(wide, -0.9);
        const hole = new THREE.Path(); hole.moveTo(Wd, -0.6); for (let q = 0; q <= K; q++) { const t = (q / K) * PI; hole.lineTo(Wd * Math.cos(t), HW + Wd * 0.42 * Math.sin(t)); } hole.lineTo(-Wd, -0.6); hole.lineTo(Wd, -0.6);
        sh.holes.push(hole);
        const pm = new THREE.Mesh(new THREE.ShapeGeometry(sh, 6), conc);
        const p = X3(T, i, 0, 0); pm.position.copy(p); pm.rotation.y = Math.atan2(T.TY[i], T.TX[i]) + PI / 2;
        world.add(pm);
      }
      // light strip along the ceiling
      const strip = ribbon(T, a, b, 0.5, -0.5, HW + T.WD[a] * 0.42 - 0.15, HW + T.WD[a] * 0.42 - 0.15, 1, 4, new THREE.MeshBasicMaterial({ color: 0xffe2b0, side: THREE.DoubleSide }));
      strip.receiveShadow = false; world.add(strip);
    }
    /* bridge over a gorge (with a river): deck sides, piers down to the water, the walls are the parapets */
    function buildBridge(s) {
      const [a, b] = T.BRG, n = T.n, tex = ASSETS.tex;
      const conc = new THREE.MeshStandardMaterial({ map: tex.concrete_c, normalMap: tex.concrete_n, color: 0xc8c4bc, roughness: 0.9, side: THREE.DoubleSide });
      for (const sd of [1, -1]) world.add(new THREE.Mesh(wallGeo(T, (i) => sd * (T.WD[i] + 0.3), -2.2, -0.55, a - 2, b + 2), conc));
      const under = ribbon(T, a - 2, b + 2, T.WD[a] + 0.3, -T.WD[a] - 0.3, -2.2, -2.2, 2, 8, conc, { flip: true }); world.add(under);
      let lo = 1e9; for (let k = a; k <= b; k++) lo = Math.min(lo, T.H[k % n]);
      const pier = new THREE.BoxGeometry(2.2, 1, 3.4);
      for (let k = a + 5; k <= b - 5; k += 7) for (const sd of [1, -1]) {
        const i = k % n, top = T.H[i] - 2.2, bot = T.H[i] - 26 * gorgeK(T, i) - 3, p = X3(T, i, sd * T.WD[i] * 0.55, 0);
        const o = new THREE.Mesh(pier, conc); o.scale.y = Math.max(1, top - bot); o.position.set(p.x, (top + bot) / 2, p.z); o.rotation.y = Math.atan2(T.TY[i], T.TX[i]) + PI / 2; o.castShadow = TIER.shadow > 0; world.add(o);
      }
      // the river
      const mid = Math.round((a + b) / 2) % n, p = X3(T, mid, 0, 0), w = new THREE.Mesh(new THREE.PlaneGeometry(90, (b - a) * H.DS + 40), waterMat());
      w.rotation.x = -PI / 2; w.rotation.z = Math.atan2(T.TY[mid], T.TX[mid]); w.position.set(p.x, lo - 21, p.z); world.add(w);
    }
    function crossQuad(w, hh, u0, v0, u1, v1) {
      const pos = [], uv = [], idx = [];
      for (let k = 0; k < 4; k++) {   // two crossed quads, each twice (front + back faces, so lighting never flips)
        const a = ((k % 2) * PI) / 2, cx = Math.cos(a) * w / 2, cz = Math.sin(a) * w / 2, b = k * 4;
        pos.push(-cx, 0, -cz, cx, 0, cz, cx, hh, cz, -cx, hh, -cz);
        uv.push(u0, v0, u1, v0, u1, v1, u0, v1);
        if (k < 2) idx.push(b, b + 1, b + 2, b, b + 2, b + 3); else idx.push(b, b + 2, b + 1, b, b + 3, b + 2);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx);
      g.computeVertexNormals();
      const nr = g.getAttribute('normal'); for (let k = 0; k < nr.count; k++) nr.setXYZ(k, 0, 1, 0);   // lit like foliage from above
      return g;
    }
    /* Kenney Racing Kit props: stands along the main straight, pits opposite, a light gantry over the line, billboards, light towers */
    const lamps = [];
    function placeProp(name, i, lat, sc, face, yaw) {
      const src = ASSETS.props[name]; if (!src) return null;
      const o = src.clone(true);
      const box = new THREE.Box3().setFromObject(o), c = box.getCenter(new THREE.Vector3());
      const g = new THREE.Group(); o.position.set(-c.x, -box.min.y, -c.z); g.add(o);
      const p = X3(T, i, lat, 0);
      g.position.set(p.x, terrainH(T, T.X[i] - T.TY[i] * lat, T.Y[i] + T.TX[i] * lat), p.z);
      g.scale.setScalar(sc);
      // face: +1 = the prop's −Z side looks at the track
      const tA = Math.atan2(T.TY[i], T.TX[i]);
      g.rotation.y = tA + PI / 2 + (face > 0 ? (lat > 0 ? PI : 0) : (lat > 0 ? 0 : PI)) + (yaw || 0);
      g.traverse((m) => { if (m.isMesh) { m.castShadow = TIER.id === 'high'; m.receiveShadow = TIER.shadow > 0; if (m.material) { m.material = m.material.clone(); m.material.roughness = 0.75; m.material.metalness = 0.05; } } });
      world.add(g);
      return g;
    }
    function buildProps(s) {
      const D = T.half + T.run, rnd = H.prng(T.seed + 77);
      // grandstands on the left (outside) of the main straight, pit building on the right
      buildStands(-10, 48, D + 3);
      buildPits(-6, 40, -(D + 3));
      // gantry over the start line (scaled to the track width)
      buildGantry(2, D);
      placeProp('flagCheckers', 1, D + 2.5, 5, 1);
      // billboards and banner towers around the lap
      for (let k = 0; k < 10; k++) {
        const i = Math.floor(((k + 0.5) / 10) * T.n + rnd() * 20) % T.n, sd = rnd() < 0.5 ? 1 : -1;
        if (i < 40 || i > T.n - 30 || inSpan(T, i, 10)) continue;
        placeProp(k % 3 === 0 ? (k % 2 ? 'bannerTowerRed' : 'bannerTowerGreen') : 'billboard', i, sd * (D + 4 + rnd() * 6), k % 3 === 0 ? 7 : 8, 1);
      }
      for (let k = 0; k < 4; k++) { const i = Math.floor(rnd() * T.n); if (i > 40 && i < T.n - 30 && !inSpan(T, i, 10) && T.th !== 'city') placeProp('tent', i, (rnd() < 0.5 ? 1 : -1) * (D + 14), 7, 1); }
      // light towers every ~70 m, alternating sides (lit at night)
      const every = Math.round(70 / H.DS);
      for (let i = 6, k = 0; i < T.n - 4; i += every, k++) {
        if (inSpan(T, i, 3)) continue;
        const sd = k % 2 ? 1 : -1, g = placeProp('lightPostLarge', i, sd * (T.WD[i] + 2.2), 9, 1);
        if (g) lamps.push({ i, lat: sd * (T.WD[i] + 2.2), g, p: X3(T, i, sd * (T.WD[i] + 1.2), 0) });
      }
      if (nightK) {
        // lamp heads + light pools on the road (cheap fake lighting)
        const pool = canvasTex(128, 128, radial([[0, 'rgba(255,220,160,0.55)'], [0.45, 'rgba(255,200,140,0.22)'], [1, 'rgba(255,200,140,0)']]));
        const pm = new THREE.MeshBasicMaterial({ map: pool, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, polygonOffset: true, polygonOffsetFactor: -6, polygonOffsetUnits: -6 });
        const headM = new THREE.MeshBasicMaterial({ color: 0xfff1cf });
        for (const l of lamps) {
          const q = new THREE.Mesh(new THREE.PlaneGeometry(26, 26), pm);
          const c = X3(T, l.i, l.lat * 0.55, 0.1); q.position.copy(c); q.rotation.x = -PI / 2; world.add(q);
          const b = new THREE.Box3().setFromObject(l.g), hd = new THREE.Mesh(new THREE.SphereGeometry(0.7, 10, 8), headM);
          hd.position.set((b.min.x + b.max.x) / 2, b.max.y - 0.6, (b.min.z + b.max.z) / 2); world.add(hd);
        }
        // a few real lights follow the camera between the lamps (mid/high)
        if (TIER.id !== 'low') for (let k = 0; k < 4; k++) { const pl = new THREE.PointLight(0xffd9a0, 0, 60, 1.6); scene.add(pl); /* always "on" (intensity 0 when unused): a changing light count would recompile every shader */ nightLights.push(pl); }
      }
    }
    const nightLights = [];
    /* 명소 · 아케이드 소품 (docs/HYPERRACE.md 「명소 코스」): 부스트 발판 · 점프대(노랑 · 검정 띠 + 「점프」 판) · 등대 · 머리 위 고가도로 */
    const spinners = [];
    function buildSetPieces(s) {
      buildBoxes();
      const n = T.n, tex = ASSETS.tex;
      const faceIn = (o, i) => { o.rotation.y = Math.atan2(-T.TX[i], T.TY[i]); };   // a board facing the cars coming
      if (T.PAD && T.PAD.length) {
        const padT = canvasTex(64, 128, (g, w, hh) => {
          g.fillStyle = '#0a2238'; g.fillRect(0, 0, w, hh); g.strokeStyle = '#3fe6ff'; g.lineWidth = 9; g.lineJoin = 'round';
          for (let k = 0; k < 3; k++) { const y = hh - 22 - k * 38; g.beginPath(); g.moveTo(9, y + 6); g.lineTo(w / 2, y - 22); g.lineTo(w - 9, y + 6); g.stroke(); }
          g.fillStyle = '#ffd23a'; g.fillRect(0, 0, 4, hh); g.fillRect(w - 4, 0, 4, hh);
        });
        const pm = new THREE.MeshBasicMaterial({ map: padT, polygonOffset: true, polygonOffsetFactor: -6, polygonOffsetUnits: -6 });
        for (const [i, l] of T.PAD) { const r = ribbon(T, i, i + 4, l + 2, l - 2, 0.1, 0.1, 1, 16, pm); r.receiveShadow = false; world.add(r); }
      }
      if (T.JMP && T.JMP.length) {
        const stT = canvasTex(64, 64, (g, w, hh) => { g.fillStyle = '#f2c230'; g.fillRect(0, 0, w, hh); g.fillStyle = '#16161a'; for (let k = -2; k < 4; k++) { g.beginPath(); g.moveTo(k * 32, 0); g.lineTo(k * 32 + 16, 0); g.lineTo(k * 32 + 16 + 32, hh); g.lineTo(k * 32 + 32, hh); g.fill(); } }, { rep: true });
        const sm = new THREE.MeshStandardMaterial({ map: stT, roughness: 0.6, polygonOffset: true, polygonOffsetFactor: -6, polygonOffsetUnits: -6 });
        const signT = canvasTex(256, 128, (g, w, hh) => { g.fillStyle = '#f2c230'; g.fillRect(0, 0, w, hh); g.strokeStyle = '#16161a'; g.lineWidth = 10; g.strokeRect(6, 6, w - 12, hh - 12); g.fillStyle = '#16161a'; g.font = 'bold 64px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('점프', w / 2, hh / 2 + 4); });
        const signM = new THREE.MeshStandardMaterial({ map: signT, roughness: 0.6, side: THREE.DoubleSide }), postM = new THREE.MeshStandardMaterial({ color: 0x55585e, roughness: 0.7 });
        for (const j of T.JMP) {
          const r = ribbon(T, j - 6, j + 1, T.half, -T.half, 0.1, 0.1, (T.half * 2) / 6, 6, sm); r.receiveShadow = TIER.shadow > 0; world.add(r);
          const i = (j - 22 + n) % n;
          for (const sd of [1, -1]) {
            const p = X3(T, i, sd * (T.WD[i] + 1.4), 0), g = new THREE.Group();
            const b = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 1.8), signM); b.position.y = 2.6; g.add(b);
            const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2, 6), postM); post.position.y = 0.9; g.add(post);
            g.position.copy(p); faceIn(g, i); world.add(g);
          }
        }
      }
      if (T.LH) {   // 등대: on the cape, beyond the wall
        const [i, sd] = T.LH, lat = sd * (T.WD[i] + 30), x = T.X[i] - T.TY[i] * lat, y = T.Y[i] + T.TX[i] * lat, gy = terrainH(T, x, y);
        const g = new THREE.Group(); g.position.set(x, gy, -y);
        const bandT = canvasTex(16, 128, (q, w, hh) => { for (let k = 0; k < 6; k++) { q.fillStyle = k % 2 ? '#f4f2ec' : '#c8261d'; q.fillRect(0, (k * hh) / 6, w, hh / 6); } });
        const tower = new THREE.Mesh(new THREE.CylinderGeometry(2.1, 3.1, 24, 20, 1, true), new THREE.MeshStandardMaterial({ map: bandT, roughness: 0.7 })); tower.position.y = 12; g.add(tower);
        const base = new THREE.Mesh(new THREE.CylinderGeometry(4.6, 5.2, 2.4, 20), new THREE.MeshStandardMaterial({ map: tex.concrete_c, color: 0xd9d4ca, roughness: 0.9 })); base.position.y = 1; g.add(base);
        const dark = new THREE.MeshStandardMaterial({ color: 0x22252a, roughness: 0.5, metalness: 0.4 });
        const gal = new THREE.Mesh(new THREE.CylinderGeometry(3, 3, 0.4, 20), dark); gal.position.y = 24.2; g.add(gal);
        const lamp = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 2.2, 14), new THREE.MeshStandardMaterial({ color: 0xfff1c4, emissive: 0xffd27a, emissiveIntensity: nightK ? 3 : 0.6, roughness: 0.2 })); lamp.position.y = 25.6; g.add(lamp);
        const cap = new THREE.Mesh(new THREE.ConeGeometry(1.9, 1.8, 14), dark); cap.position.y = 27.6; g.add(cap);
        if (nightK) {   // a slow sweeping beam at night
          const bm = new THREE.MeshBasicMaterial({ color: 0xfff0c0, transparent: true, opacity: nightK ? 0.22 : 0.06, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
          const beam = new THREE.Mesh(new THREE.ConeGeometry(9, 140, 16, 1, true), bm); beam.rotation.z = PI / 2; beam.position.x = 70;
          const piv = new THREE.Group(); piv.position.y = 25.6; piv.add(beam); g.add(piv); spinners.push(piv);
        }
        g.traverse((m) => { if (m.isMesh && !m.material.transparent) { m.castShadow = TIER.id !== 'low'; m.receiveShadow = TIER.shadow > 0; } });
        world.add(g);
      }
      if (T.OV && T.OV.length) {   // 고가도로: a deck across the track on two piers (the city's flyovers — you drive under them)
        const conc = new THREE.MeshStandardMaterial({ map: tex.concrete_c, normalMap: tex.concrete_n, color: 0xb5b2ad, roughness: 0.9 });
        const railM = new THREE.MeshStandardMaterial({ color: 0x3a3f46, roughness: 0.6, metalness: 0.5 });
        const glowM = new THREE.MeshBasicMaterial({ color: nightK ? 0xffc36b : 0x9aa0a8 });
        for (const i of T.OV) {
          const span = 2 * (T.WD[i] + 7), top = T.H[i] + 8.2, p = X3(T, i, 0, 0), g = new THREE.Group();
          g.position.set(p.x, 0, p.z); g.rotation.y = Math.atan2(T.TX[i], -T.TY[i]);
          const deck = new THREE.Mesh(new THREE.BoxGeometry(span, 1.3, 13), conc); deck.position.y = top; g.add(deck);
          for (const z of [-6.2, 6.2]) { const r = new THREE.Mesh(new THREE.BoxGeometry(span, 1.1, 0.3), railM); r.position.set(0, top + 1.2, z); g.add(r); const l = new THREE.Mesh(new THREE.BoxGeometry(span, 0.18, 0.12), glowM); l.position.set(0, top - 0.55, z * 1.03); g.add(l); }
          for (const sd of [1, -1]) {
            const lx = sd * (T.WD[i] + 3.2), wx = T.X[i] - T.TY[i] * lx, wy = T.Y[i] + T.TX[i] * lx, gy = Math.min(T.H[i], terrainH(T, wx, wy)) - 1;
            const col = new THREE.Mesh(new THREE.BoxGeometry(2.4, top - gy, 9), conc); col.position.set(lx, (top + gy) / 2, 0); g.add(col);
          }
          g.traverse((m) => { if (m.isMesh) { m.castShadow = TIER.shadow > 0; m.receiveShadow = TIER.shadow > 0; } });
          world.add(g);
        }
      }
    }
    /* grandstand: concrete terraces under a crowd, a steel roof on posts — built along the track from sample i0 to i1 at lateral `lat` */
    let crowdTex = null;
    function buildStands(i0, i1, lat) {
      if (!crowdTex) crowdTex = canvasTex(512, 128, (g, w, hh) => {
        g.fillStyle = '#3a3d44'; g.fillRect(0, 0, w, hh);
        const r = H.prng(7), cols = ['#d23b2f', '#f2c230', '#2f6fd2', '#f4f4f4', '#2a2a2a', '#38a85a', '#e07b28', '#9a4fd0', '#c9c9c9'];
        for (let row = 0; row < 8; row++) for (let x = 0; x < 64; x++) {
          if (r() < 0.12) continue;
          const px = x * 8 + r() * 3, py = row * 16 + 4 + r() * 2;
          g.fillStyle = cols[Math.floor(r() * cols.length)]; g.fillRect(px, py + 5, 6, 8);
          g.fillStyle = ['#f1c9a5', '#c68f62', '#8d5a3b', '#3b2a20'][Math.floor(r() * 4)]; g.beginPath(); g.arc(px + 3, py + 3, 2.6, 0, 7); g.fill();
        }
      }, { rep: true });
      const sd = Math.sign(lat), DEP = 13, HT = 8.5, conc = new THREE.MeshStandardMaterial({ map: ASSETS.tex.concrete_c, color: 0xbfbfbf, roughness: 0.95 });
      const steel = new THREE.MeshStandardMaterial({ color: 0x9aa3ad, roughness: 0.4, metalness: 0.7 });
      const crowdM = new THREE.MeshStandardMaterial({ map: crowdTex, roughness: 1 });
      const roofM = new THREE.MeshStandardMaterial({ color: 0x6d737c, roughness: 0.55, metalness: 0.4, side: THREE.DoubleSide });
      const fasc = canvasTex(256, 16, (g, w, hh) => { g.fillStyle = '#1d5fd0'; g.fillRect(0, 0, w, hh); g.fillStyle = '#f4f4f4'; g.fillRect(0, 11, w, 2); }, { rep: true });
      const fascM = new THREE.MeshStandardMaterial({ map: fasc, roughness: 0.6 });
      // crowd slope + back wall + roof as strips along the track
      const strip = (lat0, lat1, y0, y1, mat, uvL, uvS) => {
        const pos = [], uv = [], idx = []; let k = 0;
        for (let ii = i0; ii <= i1; ii++) {
          const i = ((ii % T.n) + T.n) % T.n, a = X3(T, i, lat0, 0), b = X3(T, i, lat1, 0), base = T.H[((i0 % T.n) + T.n) % T.n];
          pos.push(a.x, base + y0, a.z, b.x, base + y1, b.z); uv.push(((ii - i0) * H.DS) / uvL, 0, ((ii - i0) * H.DS) / uvL, uvS);
          if (k) idx.push(2 * k - 2, 2 * k - 1, 2 * k, 2 * k - 1, 2 * k + 1, 2 * k);
          k++;
        }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals();
        const m = new THREE.Mesh(g, mat); m.receiveShadow = TIER.shadow > 0; m.castShadow = TIER.id === 'high'; world.add(m); return m;
      };
      const L0 = lat, L1 = lat + sd * DEP;
      strip(L0, L0, 0, 1.6, conc, 4, 0.5);                          // front wall
      const cr = strip(L0, L1, 1.6, HT, crowdM, 24, 1.6);               // crowd terraces
      cr.material.side = THREE.DoubleSide;
      strip(L1, L1, 0, HT + 1.5, conc, 4, 1.2);                      // back wall
      strip(L0 - sd * 1.5, L1 + sd * 0.5, HT + 4.2, HT + 3.2, roofM, 6, 1);   // roof sloping back
      strip(L0 - sd * 1.5, L0 - sd * 1.5, HT + 3.4, HT + 4.4, fascM, 12, 1);   // fascia
      for (let ii = i0; ii <= i1; ii += 4) {                           // posts
        const i = ((ii % T.n) + T.n) % T.n, base = T.H[((i0 % T.n) + T.n) % T.n];
        for (const l of [L0 - sd * 0.8, L1]) { const p = X3(T, i, l, 0), post = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, HT + 4.3, 8), steel); post.position.set(p.x, base + (HT + 4.3) / 2, p.z); world.add(post); }
      }
    }
    /* pit building: a long two-storey block with lit garage bays and a team-colour band */
    function buildPits(i0, i1, lat) {
      const sd = Math.sign(lat), DEP = 14;
      const bays = canvasTex(512, 128, (g, w, hh) => {
        g.fillStyle = '#d9d9d6'; g.fillRect(0, 0, w, hh);
        const cols = ['#c0392b', '#1d5fd0', '#2aa198', '#e3ae45', '#8e44ad', '#27ae60', '#e67e22', '#34495e'];
        for (let k = 0; k < 8; k++) {
          const x = k * 64;
          g.fillStyle = '#1c1f24'; g.fillRect(x + 6, 40, 52, 88);
          const gr = g.createLinearGradient(0, 40, 0, 128); gr.addColorStop(0, '#5d646e'); gr.addColorStop(1, '#2a2e35'); g.fillStyle = gr; g.fillRect(x + 9, 44, 46, 84);
          g.fillStyle = cols[k]; g.fillRect(x, 26, 64, 10);
          g.fillStyle = 'rgba(160,200,255,.55)'; g.fillRect(x + 8, 4, 48, 16);
        }
      }, { rep: true });
      const m = new THREE.MeshStandardMaterial({ map: bays, roughness: 0.8 }), roof = new THREE.MeshStandardMaterial({ color: 0x4a4f57, roughness: 0.7, metalness: 0.3, side: THREE.DoubleSide });
      const base = T.H[((i0 % T.n) + T.n) % T.n];
      const strip = (lat0, lat1, y0, y1, mat, uvL) => {
        const pos = [], uv = [], idx = []; let k = 0;
        for (let ii = i0; ii <= i1; ii++) {
          const i = ((ii % T.n) + T.n) % T.n, a = X3(T, i, lat0, 0), b = X3(T, i, lat1, 0);
          pos.push(a.x, base + y0, a.z, b.x, base + y1, b.z); uv.push(((ii - i0) * H.DS) / uvL, 0, ((ii - i0) * H.DS) / uvL, 1);
          if (k) idx.push(2 * k - 2, 2 * k - 1, 2 * k, 2 * k - 1, 2 * k + 1, 2 * k);
          k++;
        }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals();
        const o = new THREE.Mesh(g, mat); o.receiveShadow = TIER.shadow > 0; o.castShadow = TIER.id === 'high'; o.material.side = THREE.DoubleSide; world.add(o);
      };
      strip(lat, lat, 0, 7.5, m, 24);
      strip(lat + sd * DEP, lat + sd * DEP, 0, 7.5, roof, 24);
      strip(lat - sd * 2.5, lat + sd * DEP, 7.6, 7.6, roof, 24);
    }
    /* start gantry: two posts, a beam with the five start lights (lit by the countdown) and a chequered banner */
    const gantryLights = [];
    function buildGantry(i, D) {
      const g = new THREE.Group(), metal = new THREE.MeshStandardMaterial({ color: 0x2b2f36, roughness: 0.45, metalness: 0.8 });
      const W2 = D + 1.5, Hh = 7.2;
      for (const sd of [1, -1]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.6, Hh, 0.6), metal); p.position.set(sd * W2, Hh / 2, 0); p.castShadow = TIER.shadow > 0; g.add(p); }
      const beam = new THREE.Mesh(new THREE.BoxGeometry(2 * W2 + 0.6, 1.3, 0.8), metal); beam.position.y = Hh; beam.castShadow = TIER.shadow > 0; g.add(beam);
      const chk = canvasTex(256, 32, (c, w, hh) => { for (let x = 0; x < 32; x++) for (let y = 0; y < 4; y++) { c.fillStyle = (x + y) % 2 ? '#111' : '#f2f2f2'; c.fillRect(x * 8, y * 8, 8, 8); } });
      for (const z of [0.41, -0.41]) { const b = new THREE.Mesh(new THREE.PlaneGeometry(2 * W2, 0.9), new THREE.MeshStandardMaterial({ map: chk, roughness: 0.6 })); b.position.set(0, Hh - 1.25, z); if (z < 0) b.rotation.y = PI; g.add(b); }
      for (let k = 0; k < 5; k++) for (const z of [0.42, -0.42]) {
        const l = new THREE.Mesh(new THREE.CircleGeometry(0.32, 16), new THREE.MeshStandardMaterial({ color: 0x220606, emissive: 0xff1a0a, emissiveIntensity: 0 }));
        l.position.set((k - 2) * 0.9, Hh, z); if (z < 0) l.rotation.y = PI; g.add(l); gantryLights.push([k, l.material]);
      }
      const p = X3(T, i, 0, 0); g.position.copy(p); g.position.y = T.H[i];
      g.rotation.y = Math.atan2(T.TY[i], T.TX[i]) + PI / 2;
      world.add(g);
    }

    /* ======================= 차 ======================= */
    const carObjs = [];
    let blobM = null, beamTex = null;
    function addBlob(o) {   // soft dark patch under a car (grounds it on 낮음 where there are no shadows)
      if (!blobM) blobM = new THREE.MeshBasicMaterial({ map: canvasTex(64, 128, (g, w, hh) => { const r = g.createRadialGradient(w / 2, hh / 2, 2, w / 2, hh / 2, hh / 2); r.addColorStop(0, 'rgba(0,0,0,0.75)'); r.addColorStop(0.55, 'rgba(0,0,0,0.45)'); r.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = r; g.fillRect(0, 0, w, hh); }), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -8, polygonOffsetUnits: -8 });
      const blob = new THREE.Mesh(new THREE.PlaneGeometry(2.5, 5.6), blobM); blob.rotation.x = -PI / 2; blob.position.y = 0.04; blob.scale.set(clamp(o.dims.half * 2.3 / 2.5, 0.7, 1.4), clamp((o.dims.front - o.dims.rear) * 1.2 / 5.6, 0.6, 1.7), 1); blob.position.z = (o.dims.front + o.dims.rear) / 2; o.root.add(blob);
    }
    function buildCars() {
      for (const o of carObjs) { world.remove(o.root); if (o.beam) { world.remove(o.beam); o.beam.geometry.dispose(); } }
      carObjs.length = 0;
      if (!beamTex) beamTex = canvasTex(64, 128, (g, w, hh) => { const r = g.createLinearGradient(0, hh, 0, 0); r.addColorStop(0, 'rgba(255,240,200,0)'); r.addColorStop(0.14, 'rgba(255,240,200,0.55)'); r.addColorStop(1, 'rgba(255,240,200,0)'); g.fillStyle = r; g.beginPath(); g.moveTo(w * 0.32, hh); g.lineTo(w * 0.68, hh); g.lineTo(w, 0); g.lineTo(0, 0); g.closePath(); g.fill(); });
      const beamM = new THREE.MeshBasicMaterial({ map: beamTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -7, polygonOffsetUnits: -7 });
      for (const c of W.cars) {
        const def = H.CAR[c.car], liv = (st.pk[c.seat] && st.pk[c.seat][1]) | 0;
        const o = makeCarObj(ASSETS.cars[c.car], def, liv, brandPref(H), st.pk[c.seat] && st.pk[c.seat][2]);
        addBlob(o);
        if (nightK) { const cu = st.pk[c.seat] && st.pk[c.seat][2], bm = cu && cu.hl ? beamM.clone() : beamM; if (bm !== beamM) bm.color.copy(o.hlCol); const beam = new THREE.Mesh(beamGeo(), bm); beam.frustumCulled = false; beam.renderOrder = 1; world.add(beam); o.beam = beam; }
        o.def = def; o.seat = c.seat; o.dist = 0;
        carSprites(o);
        if (W && W.items) itemCarFx(o);
        // name tag over the other cars (this device's choice): the driver's own tag text, else the player name
        if (tagsOn() && c.seat !== mySeat()) {
          const cu = st.pk[c.seat] && st.pk[c.seat][2], txt = String((cu && cu.tg) || (api.players[c.seat] && api.players[c.seat].name) || '').slice(0, 12);
          if (txt) {
            const t = canvasTex(256, 64, (g, w, hh) => {
              g.font = 'bold 30px "Segoe UI",sans-serif'; const tw = Math.min(236, g.measureText(txt).width + 26);
              g.fillStyle = 'rgba(14,11,19,.72)'; g.beginPath(); g.roundRect ? g.roundRect((w - tw) / 2, 8, tw, 48, 12) : g.rect((w - tw) / 2, 8, tw, 48); g.fill();
              g.fillStyle = H.CLS[def.cls].col; g.fillRect((w - tw) / 2 + 8, 46, tw - 16, 4);
              g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(txt, w / 2, 30, 220);
            });
            const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, sizeAttenuation: false, depthWrite: false, transparent: true }));
            sp.scale.set(0.18, 0.045, 1); sp.position.set(0, o.dims.top + 0.75, (o.dims.front + o.dims.rear) / 2); sp.renderOrder = 5;
            o.root.add(sp); o.tag = sp;
          }
        }
        world.add(o.root);
        carObjs[c.seat] = o;
      }
      // the player's headlights are real lights at night
      if (nightK && mySeat() >= 0 && carObjs[mySeat()]) {
        const o = carObjs[mySeat()], sp = new THREE.SpotLight(o.hlCol.clone(), 900, 140, 0.55, 0.55, 1.4);
        sp.position.set(0, 0.8, 1.9); sp.target.position.set(0, 0, 22); o.root.add(sp, sp.target);
      }
    }
    function roadY(c) {   // road height under a car (between samples)
      const n = T.n, i = c.idx, f = clamp(c.along / H.DS, -1, 1), j = (i + (f >= 0 ? 1 : -1) + n) % n;
      const base = T.H[i] + (T.H[j] - T.H[i]) * Math.abs(f);
      const off = Math.abs(c.lat) > T.half ? -0.02 : 0.06;
      return base + off - c.lat * (T.BK[i] || 0);
    }
    /* 전조등 빛 띠(밤): 차 앞 2.2~24.2m, 폭 9m. 줄마다 그 자리의 길 높이(표본 사이 보간 · 뱅크)에 맞춰 눕힘 */
    const BEAM_N = 8;
    function beamGeo() {
      const g = new THREE.BufferGeometry(), n = (BEAM_N + 1) * 2, uv = new Float32Array(n * 2), idx = [];
      for (let r = 0; r <= BEAM_N; r++) { uv.set([0, 1 - r / BEAM_N, 1, 1 - r / BEAM_N], r * 4); if (r < BEAM_N) { const a = r * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); } }
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(n * 3), 3)); g.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); g.setIndex(idx);
      return g;
    }
    function beamSync(c, o) {
      const b = o.beam; b.visible = o.root.visible; if (!b.visible) return;
      const P = b.geometry.attributes.position, n = T.n, ch = Math.cos(c.h), sh = Math.sin(c.h), tx = T.TX[c.idx], ty = T.TY[c.idx];
      const ca = ch * tx + sh * ty, sa = sh * tx - ch * ty, lift = o.zz || 0;   // 차 방향의 길 방향 · 옆 방향 성분
      for (let r = 0; r <= BEAM_N; r++) {
        const d = 2.2 + 22 * r / BEAM_N;
        for (let q = 0; q < 2; q++) {
          const sd = q ? 4.5 : -4.5, x = c.x + ch * d - sh * sd, y = c.y + sh * d + ch * sd;
          const fa = (c.along + d * ca - sd * sa) / H.DS, i0 = Math.floor(fa), f = fa - i0, iA = (((c.idx + i0) % n) + n) % n, iB = (iA + 1) % n;
          const lat = c.lat + d * sa + sd * ca, hy = T.H[iA] + (T.H[iB] - T.H[iA]) * f - lat * ((T.BK[iA] || 0) + ((T.BK[iB] || 0) - (T.BK[iA] || 0)) * f);
          P.setXYZ(r * 2 + q, x, hy + 0.12 + lift, -y);
        }
      }
      P.needsUpdate = true;
    }
    function syncCarObj(c, o, dt) {
      const zt = c.air && c.zA != null ? Math.max(0, c.zA - H.roadH(T, c)) : controlledHere(c.seat) ? 0 : c.zR || 0;
      o.zz = (o.zz || 0) + (zt - (o.zz || 0)) * (controlledHere(c.seat) ? 1 : Math.min(1, dt * 14));
      const y = roadY(c) + o.zz;
      o.root.position.set(c.x, y, -c.y);
      o.root.rotation.y = c.h + PI / 2;
      if (o.tag) o.tag.visible = o.root.position.distanceToSquared(cam.position) < 110 * 110;
      // banked road: lean the whole car with it (sideways to the road = roll, along = a little pitch)
      const bk = T.BK[c.idx] || 0, rr = c.h - Math.atan2(T.TY[c.idx], T.TX[c.idx]);
      o.root.rotation.z = 0; o.root.rotation.x = 0; o.root.rotation.order = 'YXZ';
      o.root.rotation.z = -bk * Math.cos(rr); o.root.rotation.x = bk * Math.sin(rr);
      // body on springs: pitch (slope + braking dive / squat), roll (outwards in corners), a jolt on hits, kerb rumble
      const slope = Math.atan(T.SL[c.idx] || 0) * Math.cos(c.h - Math.atan2(T.TY[c.idx], T.TX[c.idx]));
      const alat = c.alat != null ? c.alat : c.vf * c.w, ax = c.ax || 0;
      const sp = o.sp || (o.sp = { p: 0, pv: 0, r: 0, rv: 0 }), h = Math.min(dt, 0.05);
      const rl = o.def.ph.roll || 1, tp = -slope + clamp(-ax * 0.0055 * Math.min(rl, 1.6), -0.045 * rl, 0.05 * rl), tr = clamp(alat * 0.0042 * rl, -0.075 * rl, 0.075 * rl);
      const hit = c.fxHit || 0;
      if (hit > 2) { sp.pv += (Math.random() - 0.5) * hit * 0.012; sp.rv += (Math.random() - 0.5) * hit * 0.02; }
      if (c.surf === 1 && Math.abs(c.vf) > 8) sp.rv += (Math.random() - 0.5) * 0.25 * h * 60 * 0.02;
      if (c.surf >= 2 && Math.abs(c.vf) > 8) sp.pv += (Math.random() - 0.5) * 0.3 * h * 60 * 0.02;
      sp.pv += (130 * (tp - sp.p) - 15 * sp.pv) * h; sp.p += sp.pv * h;
      sp.rv += (110 * (tr - sp.r) - 13 * sp.rv) * h; sp.r += sp.rv * h;
      o.tilt.rotation.x = clamp(sp.p, -0.12 * rl, 0.12 * rl); o.tilt.rotation.z = clamp(sp.r, -0.1 * rl, 0.1 * rl);
      if (o.def.ph.hover) { o.hv = (o.hv || 0) + dt; o.tilt.position.y = 0.06 + Math.sin(o.hv * 2.3 + c.seat) * 0.035; }
      // wheels: roll with the speed (spin up with wheelspin), fronts steer — counter-steer shows in a slide
      const r = o.dims.wr || o.def.ph.wr || 0.35, ds = c.vf * dt;
      o.spin = (o.spin + (ds / r) * (1 + (c.ws || 0) * 2.5)) % (PI * 2);
      const fs = clamp((c.st || 0) - (c.sa || 0) * Math.min(1, (c.dr || 0) * 1.2) * 0.9, -0.6, 0.6);
      for (const w of o.wheels) { const wh = w.o; if (!o.def.ph.hover) wh.rotation.x = o.spin; if (w.front) wh.rotation.y = lerp(wh.rotation.y, fs * (o.def.ph.hover ? 0.4 : 1), Math.min(1, dt * 18)); }
      const night = nightK;
      o.setLights(night ? 3.2 : 0.35, (c.brk > 0.05 ? 5 : night ? 1.6 : 0.5));
      o.root.visible = true;
      if (c.ghost > 0) o.root.visible = (c.ghost * 4) % 1 < 0.72;
      if (o.beam) beamSync(c, o);
    }

    /* ======================= 입력 ======================= */
    const inp = { gas: 0, brake: 0, left: 0, right: 0, hb: 0 };
    /* 시점(카메라) 6가지 — Tab · C · 폰 「카메라」로 차례대로. PC: 우클릭을 누른 채 마우스 = 자유 시점(놓으면 돌아옴), 자유 시점 중 ` = 그 시점 고정(Tab이나 ` 다시 = 풀림) */
    const CAMS = ['가까운 추적', '먼 추적', '보닛', '범퍼', '운전석', 'TV 중계'];
    let steerCmd = 0, autoGas = H.store.get('auto', H.touchOnly() ? '1' : '0') === '1';
    let camMode = (() => { const v = H.store.get('cam2', ''); if (v !== '') return clamp(+v | 0, 0, CAMS.length - 1); return [0, 3, 4][+H.store.get('cam', '0') | 0] || 0; })();
    let assist = H.assistLevel(), itemQ = 0;
    const fl = { on: false, lock: false, yaw: 0, pitch: 0.25, R: 7, k: 0, ptr: -1, x: 0, y: 0 };   // 자유 시점
    DBG.fl = fl; DBG.cams = () => camMode;
    const offs = [];
    try {
      offs.push(api.input.on((type, id) => {
        if (type !== 'down') return;
        if (id === 'cam') { if (pvOn()) pvPreset(1); else cycleCam(); }
        if (id === 'look') toggleLook();
        if (id === 'item') useItemKey();
        if (id === 'reset') doReset();
      }));
    } catch (e) {}
    function useItemKey() { const s = mySeat(); if (W && W.items && phase === 'race' && s >= 0 && isHumanHere(s)) itemQ = 1; }
    function toggleLook() {
      if (pvOn()) { pv.lock = !pv.lock; pv.idle = pv.lock ? -1e9 : 0; note(pv.lock ? '보기 고정(저절로 돌지 않음)' : '보기 고정 풀림'); return; }
      if (!W) return;
      if (fl.on) { fl.lock = !fl.lock; note(fl.lock ? '자유 시점 고정' : '자유 시점 고정 풀림'); }
      else if (fl.lock) { fl.lock = false; note('자유 시점 고정 풀림'); }
    }
    function readInput(dt) {
      let gas = inp.gas, brake = inp.brake, hb = inp.hb, ax = 0;
      try {
        if (api.input.held('gas')) gas = 1;
        if (api.input.held('brake')) brake = 1;
        if (api.input.held('hb')) hb = 1;
        ax = api.input.axis('left', 'right');
      } catch (e) {}
      const dig = (inp.right ? 1 : 0) - (inp.left ? 1 : 0);
      const want = Math.abs(ax) > 0.05 ? ax : dig;
      const analog = Math.abs(ax) > 0.05 && Math.abs(ax) < 0.98;
      if (tStyle === 'drag' && touchSteer.on && Math.abs(ax) <= 0.05) {   // touch drag pad: analog, a light low-pass (no jitter) and a gentle curve near the centre
        const t = Math.sign(touchSteer.v) * Math.pow(Math.abs(touchSteer.v), 1.2);
        steerCmd += (t - steerCmd) * (1 - Math.exp(-dt * 16));
      } else if (analog) steerCmd = Math.sign(want) * Math.pow(Math.abs(want), 1.35);   // stick: finer near the centre
      else { const r = want === 0 ? 9 : Math.sign(want) !== Math.sign(steerCmd) ? 11 : 5.5; steerCmd += clamp(want - steerCmd, -r * dt, r * dt); }
      const thr = autoGas ? (brake ? 0 : 1) : gas;
      const it = itemQ; itemQ = 0;
      return { thr, brk: brake, steer: -steerCmd, hb, it };
    }
    function cycleCam() { fl.lock = false; camMode = (camMode + 1) % CAMS.length; H.store.set('cam2', String(camMode)); note(CAMS[camMode]); }
    let resetCD = 0;
    function doReset() {
      const s = mySeat(); if (!W || s < 0 || phase !== 'race' || resetCD > 0) return;
      const c = W.cars[s]; if (!c || c.fin) return;
      H.resetToTrack(T, c); resetCD = 3; note('트랙으로 복귀');
    }

    /* ======================= HUD ======================= */
    const hud = h('div', { class: 'hr-hud' });
    const posEl = h('div', { class: 'hr-pos' }), lapEl = h('div', { class: 'hr-lap' }), spdEl = h('div', { class: 'hr-spd' });
    const mapC = h('canvas', { class: 'hr-map', width: 236, height: 236 }), tower = h('div', { class: 'hr-tower' });
    const noteEl = h('div', { class: 'hr-note' }), lightsEl = h('div', { class: 'hr-lights', style: { display: 'none' } }), goEl = h('div', { class: 'hr-go', style: { display: 'none' }, text: 'GO!' });
    const wrongEl = h('div', { class: 'hr-wrong', style: { display: 'none' }, text: '역주행' });
    const prepEl = h('div', { class: 'hr-prep', style: { display: 'none' } }, h('i'), h('span', { text: '출발 준비 중…' }));
    const trkEl = h('div', { class: 'hr-trk', style: { display: 'none' } });
    for (let k = 0; k < 5; k++) lightsEl.append(h('i'));
    spdEl.innerHTML = '<b>0</b><small>km/h</small><span class="hr-gear">N</span><div class="hr-bars"><div class="hr-bar"><div></div></div><div class="hr-bar sl"><div></div></div></div>' +
      '<div class="hr-dg"><i><s></s></i><i><s></s></i><i><s></s></i></div>';
    const dgEl = spdEl.querySelector('.hr-dg'), dgS = [...dgEl.querySelectorAll('s')];
    let dgFlash = 0, dgShow = 0;
    /* drift gauge under the speed: three steps fill while sliding; a clean exit turns them into a boost */
    function driftHud(c) {
      if (!c) return;
      const D = H.DLV, dc = c.dc || 0, on = (c.dr || 0) > 0.4 || dc > 0 || (c.bst || 0) > 0;
      dgShow = on ? 1 : Math.max(0, dgShow - 0.04);
      dgEl.style.opacity = String(Math.min(1, dgShow * 2));
      const lv = c.dlv || 0;
      dgS.forEach((el, k) => {
        const a = k ? D[k - 1] : 0, f = (c.bst || 0) > 0 ? (k < (c.blv || 0) ? Math.min(1, c.bst / 0.4) : 0) : clamp((dc - a) / (D[k] - a), 0, 1);
        el.style.width = Math.round(f * 100) + '%';
        el.style.background = (c.bst || 0) > 0 ? '#ffd27a' : k < lv ? ['#7fd7ff', '#8cff9a', '#ffcf5a'][k] : 'rgba(255,255,255,.75)';
      });
      if (dgFlash > 0) dgFlash -= 1 / 60;
      dgEl.classList.toggle('fl', dgFlash > 0);
      spdEl.classList.toggle('bst', (c.bst || 0) > 0);
    }
    let bnT = 0;
    function boostNote(lv) { if (lv >= 2) note(['', '부스트', '부스트!', '최대 부스트!'][lv]); }
    hud.append(posEl, lapEl, spdEl, mapC, tower, noteEl, lightsEl, goEl, wrongEl, prepEl, trkEl);
    const slC = h('canvas', { class: 'hr-sl' });
    /* ----- 아이템 칸(「아케이드 요소」): PC = 왼쪽 아래 칸 + R(조작 설정에서 바꿈), 폰 = 이 칸이 곧 아이템 단추 ----- */
    const ISVG = {
      nitro: '<path d="M9 2h5v2.3A4 4 0 0 1 17 8.2V19a3 3 0 0 1-3 3H9a3 3 0 0 1-3-3V8.2a4 4 0 0 1 3-3.9z"/><path d="M8.6 11.2l2.6 2.3-2.6 2.3M12 11.2l2.6 2.3-2.6 2.3" fill="none" stroke="#1a1420" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
      oil: '<path d="M12 2c-2.6 4-5.2 6.6-5.2 9.7a5.2 5.2 0 0 0 10.4 0C17.2 8.6 14.6 6 12 2z"/><path d="M2.5 20.6c0-1.3 4.3-2.2 9.5-2.2s9.5.9 9.5 2.2-4.3 2.1-9.5 2.1-9.5-.8-9.5-2.1z" opacity=".75"/>',
      jam: '<path d="M10.8 11h2.4l2.8 11h-2.3l-.7-3h-2l-.7 3H8z"/><circle cx="12" cy="8.6" r="1.9"/><path d="M8.3 4.9a5.2 5.2 0 0 0 0 7.4M15.7 4.9a5.2 5.2 0 0 1 0 7.4M5.4 2.2a9.2 9.2 0 0 0 0 12.8M18.6 2.2a9.2 9.2 0 0 1 0 12.8" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
      grip: '<circle cx="12" cy="12" r="8.2" fill="none" stroke="currentColor" stroke-width="4.2" stroke-dasharray="2.6 1.7"/><circle cx="12" cy="12" r="3.4"/>',
      shield: '<path d="M12 2l8.5 3.2V11c0 5.2-3.6 9.2-8.5 11-4.9-1.8-8.5-5.8-8.5-11V5.2z"/><path d="M7.5 12.5h9M9 9h6" stroke="#1a1420" stroke-width="2" stroke-linecap="round"/>',
      smoke: '<path d="M6.8 19.5a4.3 4.3 0 0 1-.7-8.55A5.9 5.9 0 0 1 17.4 9.2a4.9 4.9 0 0 1 .4 9.8z"/><circle cx="5" cy="5.5" r="2.2" opacity=".7"/><circle cx="10" cy="4" r="1.5" opacity=".55"/>',
      mag: '<path d="M4.5 3h5v8.2a2.5 2.5 0 0 0 5 0V3h5v8.2a7.5 7.5 0 0 1-15 0z"/><path d="M4.5 3h5v3.4h-5zM14.5 3h5v3.4h-5z" fill="#f4f4f0"/>',
    };
    const itemSvg = (k) => { const it = H.ITEMS[k]; return it ? '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">' + ISVG[it.id] + '</svg>' : ''; };
    const islot = h('div', { class: 'hr-islot', 'data-action': 'item', title: '아이템 쓰기' }), ifx = h('div', { class: 'hr-ifx' }), haze = h('div', { class: 'hr-haze' });
    const iname = h('em'), hintEl = h('div', { class: 'hr-hint' }), camTag = h('div', { class: 'hr-camtag' });
    let islotK = -1, islotR = false, islotOn = false, ifxK = '', hintT = 0;
    islot.addEventListener('pointerdown', (e) => { if (!islot.classList.contains('tap')) return; e.preventDefault(); e.stopPropagation(); islot.classList.add('on'); useItemKey(); audioKick(); });
    const islotUp = () => islot.classList.remove('on');
    islot.addEventListener('pointerup', islotUp); islot.addEventListener('pointercancel', islotUp); islot.addEventListener('pointerleave', islotUp);
    hintEl.addEventListener('pointerdown', () => { hintT = 0; hintEl.style.opacity = '0'; });
    hud.append(islot, ifx, hintEl, camTag);
    function itemHud(c) {
      const on = !!(W && W.items && c && (phase === 'race' || phase === 'count'));
      if (on !== islotOn) { islotOn = on; islot.style.display = on ? 'flex' : 'none'; if (!on) ifx.style.display = 'none'; }
      if (!on) { haze.style.opacity = '0'; return; }
      const roll = c.itR > 0, k = roll ? 1 + (Math.floor(performance.now() / 90) % (H.ITEMS.length - 1)) : c.it | 0;
      if (k !== islotK || roll !== islotR) {
        islotK = k; islotR = roll;
        islot.innerHTML = k ? itemSvg(k) : '<svg viewBox="0 0 24 24" aria-hidden="true" style="opacity:.38"><path d="M12 3l7.8 4.5v9L12 21l-7.8-4.5v-9z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M12 8.5v7M8.5 12h7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'; islot.append(iname);   // empty: a faint box outline
        iname.textContent = roll || !k ? '' : H.ITEMS[k].nm;
        islot.classList.toggle('has', !!k && !roll); islot.classList.toggle('roll', roll);
        islot.style.setProperty('--ic', k ? H.ITEMS[k].col : '#fff'); islot.style.color = k ? H.ITEMS[k].col : '#fff';
      }
      // the effect on my car right now (one at a time): 범퍼 · 접지 타이어 · 자석 · 맞음
      const ef = c.shd > 0 ? [5, c.shd / H.IT.shd] : c.trc > 0 ? [4, c.trc / H.IT.grip] : c.mag > 0 ? [7, c.mag / H.IT.mag] : c.slow > 0 ? [c.slK === 2 ? 2 : 3, c.slow] : c.smk > 0 ? [6, 1] : null;
      const ek = ef ? String(ef[0]) : '';
      if (ek !== ifxK) {
        ifxK = ek; ifx.style.display = ef ? 'flex' : 'none';
        if (ef) { const it = H.ITEMS[ef[0]], hit = c.slow > 0 && !(c.shd > 0 || c.trc > 0 || c.mag > 0); ifx.innerHTML = '<span style="color:' + it.col + ';display:flex">' + itemSvg(ef[0]) + '</span><span>' + (hit ? (ef[0] === 2 ? '미끄러짐' : '방해 받음') : ef[0] === 6 ? '연막 속' : it.nm) + '</span><i><s></s></i>'; ifx.style.setProperty('--ic', it.col); }
      }
      if (ef) { const s = ifx.querySelector('s'); if (s) s.style.width = Math.round(clamp(ef[1], 0, 1) * 100) + '%'; }
      haze.style.opacity = c.smk > 0 && mySeat() === c.seat ? (calmOn() ? '0.6' : '1') : '0';
    }
    function showHint() {   // PC, the first race on this device: one small line, bottom left (tap = gone)
      if (!PC || showTouch() || H.store.get('hint.cam', '') === '1' || !isHumanHere(mySeat())) return;
      H.store.set('hint.cam', '1');
      const kn = (id, d) => { try { return (L.ui && L.ui.keyLabel && L.ui.keyLabel('hyperrace', id)) || d; } catch (e) { return d; } };
      hintEl.innerHTML = '<kbd>' + kn('cam', 'Tab') + '</kbd> 시점 바꾸기 · <kbd>우클릭</kbd> 누른 채 끌기 = 자유 시점(휠 = 거리) · 그동안 <kbd>' + kn('look', '`') + '</kbd> = 그 시점 고정' + (W && W.items ? ' · <kbd>' + kn('item', 'R') + '</kbd> 아이템' : '');
      hintEl.style.opacity = '1'; hintT = 7;
    }
    wrap.append(slC, haze, hud);
    let noteT = 0;
    function note(t) { noteEl.textContent = t; noteEl.style.opacity = '1'; noteT = 1.5; }
    noteEl.addEventListener('pointerdown', () => { noteT = 0; noteEl.style.opacity = '0'; });
    // touch controls (docs/HYPERRACE.md 「폰 조작」): 핸들 = 「버튼」(◀ ▶이 한 판 — 엄지를 미끄러뜨리면 떼지 않고 좌우가 바로 바뀜) 또는
    // 「끌기」(왼쪽 큰 칸 아무 데나 대고 좌우로 끄는 만큼 꺾임 — 아날로그). 오른쪽: 가속 · 브레이크 · 드리프트(따로 눌러 여러 손가락 동시).
    // 이 기기 설정: 핸들 방식 · 단추 크기 3단계 · 좌우 바꾸기 · 자동 가속
    const ICO = {
      l: '<svg viewBox="0 0 24 24"><path d="M15 4 7 12l8 8z"/></svg>', r: '<svg viewBox="0 0 24 24"><path d="m9 4 8 8-8 8z"/></svg>',
    };
    const ctl = {};
    let tStyle = H.store.get('tsteer', 'btn') === 'drag' ? 'drag' : 'btn', tSize = clamp(+H.store.get('tsize', '1') | 0, 0, 2), tSwap = H.store.get('tswap', '0') === '1';
    const touchSteer = { v: 0, on: false };   // the drag pad's analog value (−1..1, + = right)
    DBG.inp = inp; DBG.touchSteer = touchSteer;
    function mkCtl(id, html, cls) {
      const b = h('div', { class: 'hr-ctl lounge-ctl ' + (cls || ''), html });
      const set = (v) => { inp[id] = v; b.classList.toggle('on', !!v); };
      const ptrs = new Set();
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); ptrs.add(e.pointerId); try { b.setPointerCapture(e.pointerId); } catch (x) {} set(1); audioKick(); });
      const up = (e) => { ptrs.delete(e.pointerId); if (!ptrs.size) set(0); };
      b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
      ctl[id] = b; return b;
    }
    const knob = h('b', { class: 'hr-knob', style: { display: 'none' } });
    const steerPad = h('div', { class: 'hr-ctl hr-steer lounge-ctl' }, h('i', { class: 'hr-sl', html: ICO.l }), h('i', { class: 'hr-sr', html: ICO.r }), knob);
    const sPtr = new Map();   // pointerId → { x0, x }
    function steerUpdate() {
      const r = steerPad.getBoundingClientRect();
      let l = 0, rr = 0, an = 0, n = 0;
      for (const p of sPtr.values()) {
        if (tStyle === 'drag') { an += clamp((p.x - p.x0) / Math.max(40, Math.min(r.width * 0.3, 110)), -1, 1); n++; }
        else if (p.x < r.left + r.width / 2) l = 1; else rr = 1;
      }
      if (tStyle === 'drag') { touchSteer.on = n > 0; touchSteer.v = n ? clamp(an / n, -1, 1) : 0; inp.left = inp.right = 0; }
      else { touchSteer.on = false; touchSteer.v = 0; inp.left = l && !rr ? 1 : 0; inp.right = rr && !l ? 1 : 0; }
      const v = tStyle === 'drag' ? touchSteer.v : inp.right - inp.left;
      steerPad.classList.toggle('l', v < -0.12); steerPad.classList.toggle('r', v > 0.12);
      if (tStyle === 'drag') { const p = [...sPtr.values()][0]; knob.style.display = p ? '' : 'none'; if (p) { knob.style.left = (p.x0 - r.left + touchSteer.v * Math.min(r.width * 0.3, 110)) + 'px'; knob.style.top = '50%'; } }
    }
    steerPad.addEventListener('pointerdown', (e) => { e.preventDefault(); try { steerPad.setPointerCapture(e.pointerId); } catch (x) {} sPtr.set(e.pointerId, { x0: e.clientX, x: e.clientX }); steerUpdate(); audioKick(); });
    steerPad.addEventListener('pointermove', (e) => { const p = sPtr.get(e.pointerId); if (!p) return; p.x = e.clientX; steerUpdate(); });
    const sUp = (e) => { if (sPtr.delete(e.pointerId)) steerUpdate(); };
    steerPad.addEventListener('pointerup', sUp); steerPad.addEventListener('pointercancel', sUp); steerPad.addEventListener('lostpointercapture', sUp);
    const touchBox = h('div', { style: { position: 'absolute', inset: '0', pointerEvents: 'none', display: 'none' } });
    touchBox.append(steerPad, mkCtl('gas', '가속'), mkCtl('brake', '브레이크'), mkCtl('hb', '드리프트'));
    const camBtn = h('button', { class: 'hr-sbtn', text: '카메라', onclick() { cycleCam(); } });
    const rstBtn = h('button', { class: 'hr-sbtn', text: '복귀', onclick() { doReset(); } });
    touchBox.append(camBtn, rstBtn);
    wrap.append(touchBox);
    const showTouch = () => !PC || (L.touchOnly && L.touchOnly());
    function layout() {
      const land = vw >= vh, s = clamp(Math.min(vw, vh) / 380, 0.85, 1.25);
      // control boxes in design units (scaled by S); spans = width taken from each side edge
      const B = land
        ? { st: { x: 12, b: 12, w: 204, h: 98 }, gas: { x: 12, b: 12, w: 98, h: 126 }, brk: { x: 120, b: 12, w: 90, h: 88 }, hb: { x: 120, b: 110, w: 90, h: 58 },
          aBrk: { x: 12, b: 12, w: 104, h: 126 }, aHb: { x: 126, b: 12, w: 90, h: 92 }, L: 216, R: 210, top: 168 }
        : { st: { x: 10, b: 14, w: 184, h: 94 }, gas: { x: 10, b: 14, w: 86, h: 112 }, brk: { x: 104, b: 14, w: 80, h: 80 }, hb: { x: 104, b: 102, w: 80, h: 52 },
          aBrk: { x: 10, b: 14, w: 90, h: 112 }, aHb: { x: 108, b: 14, w: 80, h: 84 }, L: 194, R: 184, top: 154 };
      // size setting, then shrink to fit: landscape keeps ~150 px in the middle for the speed read-out, portrait just has to fit the width
      let S = s * [0.86, 1, 1.16][tSize];
      S = Math.min(S, (vw - (land ? 150 : 12)) / (B.L + B.R));
      const px = (v) => Math.round(v * S) + 'px';
      const near = tSwap ? 'right' : 'left', far = tSwap ? 'left' : 'right';
      const put = (el, o, side) => { el.style.left = el.style.right = el.style.top = ''; el.style[side] = px(o.x); el.style.bottom = px(o.b); el.style.width = px(o.w); el.style.height = px(o.h); };
      if (tStyle === 'drag') {   // a big pad: the lower ~45% of the screen on the steering side
        const w = Math.round(vw * (land ? 0.36 : 0.5)), hh = Math.round(vh * (land ? 0.55 : 0.3));
        steerPad.style.left = steerPad.style.right = steerPad.style.top = ''; steerPad.style[near] = '8px'; steerPad.style.bottom = '8px'; steerPad.style.width = w + 'px'; steerPad.style.height = hh + 'px';
      } else put(steerPad, B.st, near);
      steerPad.classList.toggle('drag', tStyle === 'drag');
      if (autoGas) { put(ctl.brake, B.aBrk, far); put(ctl.hb, B.aHb, far); } else { put(ctl.gas, B.gas, far); put(ctl.brake, B.brk, far); put(ctl.hb, B.hb, far); }
      ctl.gas.style.display = autoGas ? 'none' : '';
      // camera / reset: out of the thumbs' way — landscape: a row left of the minimap, portrait: under the minimap
      const small = vh < 430 || vw < 520, mapW = small ? 96 : 118, mapT = vw < 520 ? 60 : 56;
      [[camBtn, 0], [rstBtn, 1]].forEach(([el, k]) => {
        el.style.left = ''; el.style.bottom = '';
        if (land) { el.style.right = (10 + mapW + 8 + k * 54) + 'px'; el.style.top = '8px'; } else { el.style.right = '10px'; el.style.top = (mapT + mapW + 8 + k * 52) + 'px'; }
      });
      spdEl.style.bottom = land ? '8px' : Math.round((B.top + 10) * S) + 'px';
      // item slot: PC = bottom left (a read-out + key badge) / touch = the item button, above the right-hand cluster on its inner side (clear of the minimap)
      const tch = showTouch() && isHumanHere(mySeat());
      islot.classList.toggle('tap', tch);
      islot.style.left = islot.style.right = islot.style.top = ''; ifx.style.left = ifx.style.right = ifx.style.top = '';
      if (tch) {
        const isz = 66, sz = Math.max(48, Math.round(isz * S)), off = land ? B.R - isz : 10 / S, bot = Math.round((B.top + 8) * S) + (land ? 0 : 0);
        islot.style.width = islot.style.height = sz + 'px'; islot.style[far] = px(off); islot.style.bottom = bot + 'px';
        ifx.style[far] = px(off); ifx.style.bottom = (bot + sz + 22) + 'px';
      } else {
        islot.style.width = islot.style.height = '60px'; islot.style.left = '14px'; islot.style.bottom = '30px';
        ifx.style.left = '84px'; ifx.style.bottom = '48px';
      }
      hintEl.style.bottom = W && W.items && !tch ? '112px' : '14px';
      const racing = phase === 'count' || phase === 'race';
      touchBox.style.display = showTouch() && racing && isHumanHere(mySeat()) ? '' : 'none';
      spdEl.style.display = racing || phase === 'done' ? '' : 'none';
      mapC.style.display = lapEl.style.display = posEl.style.display = W ? '' : 'none';
      tower.style.display = small && showTouch() ? 'none' : '';
      mapC.style.width = mapC.style.height = mapW + 'px';
      mapC.style.top = mapT + 'px';
      if (pickEl) layoutPick();
    }
    // minimap
    let mapImg = null, mapTf = null;
    function buildMinimap() {
      const c = document.createElement('canvas'); c.width = c.height = 236;
      const g = c.getContext('2d'), pad = 18, w = BB[2] - BB[0], hh = BB[3] - BB[1], k = (236 - 2 * pad) / Math.max(w, hh);
      mapTf = (x, y) => [pad + (x - BB[0]) * k + ((236 - 2 * pad) - w * k) / 2, 236 - (pad + (y - BB[1]) * k + ((236 - 2 * pad) - hh * k) / 2)];
      g.lineJoin = 'round'; g.lineCap = 'round';
      for (const [lw, col] of [[14, 'rgba(0,0,0,.45)'], [7, 'rgba(235,235,240,.9)']]) {
        g.beginPath(); for (let i = 0; i <= T.n; i++) { const [x, y] = mapTf(T.X[i % T.n], T.Y[i % T.n]); i ? g.lineTo(x, y) : g.moveTo(x, y); }
        g.lineWidth = lw; g.strokeStyle = col; g.stroke();
      }
      // set pieces on the map: jumps (orange), boost pads (cyan), tunnel (dark) · bridge (green) stretches
      const seg = (r, col) => { if (!r) return; g.beginPath(); for (let i = r[0]; i <= r[1]; i++) { const [x, y] = mapTf(T.X[i % T.n], T.Y[i % T.n]); i > r[0] ? g.lineTo(x, y) : g.moveTo(x, y); } g.lineWidth = 7; g.strokeStyle = col; g.stroke(); };
      seg(T.TUN, 'rgba(90,96,110,.95)'); seg(T.BRG, 'rgba(110,210,140,.95)');
      for (const j of T.JMP || []) { const [x, y] = mapTf(T.X[j], T.Y[j]); g.beginPath(); g.arc(x, y, 6, 0, PI * 2); g.fillStyle = '#ff9a2a'; g.fill(); }
      for (const [j] of T.PAD || []) { const [x, y] = mapTf(T.X[j], T.Y[j]); g.beginPath(); g.arc(x, y, 4.5, 0, PI * 2); g.fillStyle = '#3fe6ff'; g.fill(); }
      for (const [j] of T.IB || []) { const [x, y] = mapTf(T.X[j], T.Y[j]); g.save(); g.translate(x, y); g.rotate(PI / 4); g.fillStyle = '#ffcf5a'; g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 1.5; g.fillRect(-4.5, -4.5, 9, 9); g.strokeRect(-4.5, -4.5, 9, 9); g.restore(); }   // item boxes
      const [sx, sy] = mapTf(T.X[0], T.Y[0]); g.fillStyle = '#e3ae45'; g.fillRect(sx - 5, sy - 5, 10, 10);
      mapImg = c;
      trkEl.innerHTML = '';
      const tc = document.createElement('canvas'); tc.width = tc.height = 124; tc.getContext('2d').drawImage(c, 0, 0, 124, 124);
      trkEl.append(tc, h('div', null, h('b', { text: T.nm }), h('span', { text: trackInfo(T) }), h('span', { text: trackFeat(T) })));
    }
    function trackInfo(T0) { return (H.THEMES[T0.th] ? H.THEMES[T0.th].nm : '') + ' · ' + (T0.lm ? '명소 코스' : (H.STYLES[T0.cs] || '') + ' 서킷') + ' · ' + (T0.len / 1000).toFixed(1) + 'km'; }
    function trackFeat(T0) {
      if (T0.lm && H.LM[T0.lm]) return H.LM[T0.lm].pt;
      const f = []; let up = 0; for (let i = 0; i < T0.n; i++) up = Math.max(up, T0.H[i]);
      if (T0.TUN) f.push('터널'); if (T0.BRG) f.push('다리'); if ((T0.OV || []).length) f.push('고가도로 아래'); if ((T0.JMP || []).length) f.push('점프대'); if ((T0.PAD || []).length) f.push('부스트 발판');
      f.push('높낮이 ' + Math.round(up - Math.min(...T0.H)) + 'm');
      return f.join(' · ');
    }
    function drawMap() {
      if (!mapImg || !W) return;
      const g = mapC.getContext('2d'); g.clearRect(0, 0, 236, 236); g.drawImage(mapImg, 0, 0);
      const me = mySeat();
      for (const c of W.cars) {
        const [x, y] = mapTf(c.x, c.y), mine = c.seat === me;
        g.beginPath(); g.arc(x, y, mine ? 9 : 6.5, 0, PI * 2);
        g.fillStyle = mine ? '#ffd23a' : H.CLS[H.CAR[c.car].cls].col; g.fill();
        g.lineWidth = mine ? 3 : 2; g.strokeStyle = '#111'; g.stroke();
      }
    }

    /* ======================= 소리 =======================
       엔진(녹음 반복음 · 전기 윙) + 몸통 톱니파, 타이어: 끌림(접지 한계 근처) · 비명(미끄러짐), 벽 긁힘, 연석 · 잔디 덜컹, 바람, 비,
       기어 바꿈(툭), 부스트(쉭), 드리프트 단계(딩), 부딪힘(녹음). 모두 코드 합성 + CC0 녹음(CREDITS.txt). */
    let AC = null, snd = null;
    function audioKick() {
      if (AC) { if (AC.state === 'suspended') AC.resume().catch(() => {}); return; }
      try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AC = null; return; }
      const vol = () => (L.audio && L.audio.sfx ? L.audio.sfx() : 0.7);
      const master = AC.createGain(); master.gain.value = vol(); master.connect(AC.destination);
      const noiseBuf = AC.createBuffer(1, AC.sampleRate * 2, AC.sampleRate); const nd = noiseBuf.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
      const noise = (type, f, q) => { const s = AC.createBufferSource(); s.buffer = noiseBuf; s.loop = true; const fl = AC.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q || 0.7; const g = AC.createGain(); g.gain.value = 0; s.connect(fl); fl.connect(g); g.connect(master); s.start(); return { g, fl }; };
      snd = { master, vol, noiseBuf, skid: noise('bandpass', 1100, 1.4), squeal: noise('bandpass', 1500, 7), scrape: noise('bandpass', 3200, 1.8), rumble: noise('lowpass', 160, 0.8),
        wind: noise('lowpass', 500, 0.5), rain: noise('highpass', 2500, 0.4), buf: {}, eng: null, osc: null, gear: 1, dip: 0 };
      // engine layers: recorded engine (GT) or an electric whine (HY), plus a sawtooth body
      const o1 = AC.createOscillator(); o1.type = 'sawtooth'; const f1 = AC.createBiquadFilter(); f1.type = 'lowpass'; f1.frequency.value = 900; const g1 = AC.createGain(); g1.gain.value = 0; o1.connect(f1); f1.connect(g1); g1.connect(master); o1.start();
      const o2 = AC.createOscillator(); o2.type = 'sine'; const g2 = AC.createGain(); g2.gain.value = 0; o2.connect(g2); g2.connect(master); o2.start();
      snd.osc = { o1, f1, g1, o2, g2 };
      const sfx = ASSETS && ASSETS.sfx || {};
      for (const k of Object.keys(sfx)) { const u8 = sfx[k]; AC.decodeAudioData(u8.buffer.slice(u8.byteOffset, u8.byteOffset + u8.byteLength)).then((b) => { if (snd) snd.buf[k] = b; if (k === 'en_car') startEngineLoop(); }).catch(() => {}); }
    }
    function startEngineLoop() {
      if (!AC || !snd || !snd.buf.en_car || snd.eng) return;
      const s = AC.createBufferSource(); s.buffer = snd.buf.en_car; s.loop = true; const g = AC.createGain(); g.gain.value = 0; s.connect(g); g.connect(snd.master); s.start();
      snd.eng = { s, g };
    }
    function playBuf(k, v, rate) {
      if (!AC || !snd || !snd.buf[k]) return;
      const s = AC.createBufferSource(); s.buffer = snd.buf[k]; s.playbackRate.value = rate || 1; const g = AC.createGain(); g.gain.value = v; s.connect(g); g.connect(snd.master); s.start();
    }
    // short one-shots: a filtered noise burst (gear pop, boost whoosh) or a chime
    function burst(f0, f1, q, dur, v) {
      if (!AC || !snd || paused) return;
      const t = AC.currentTime, s = AC.createBufferSource(); s.buffer = snd.noiseBuf; const fl = AC.createBiquadFilter(); fl.type = 'bandpass'; fl.Q.value = q;
      fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(f1, t + dur);
      const g = AC.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(v, t + Math.min(0.03, dur * 0.2)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(fl); fl.connect(g); g.connect(snd.master); s.start(t, Math.random()); s.stop(t + dur + 0.05);
    }
    function chime(lv) {
      if (!AC || !snd || paused) return;
      const t = AC.currentTime;
      [660, 880, 1175, 1568].slice(0, lv + 1).forEach((f, k) => {
        const o = AC.createOscillator(); o.type = 'triangle'; o.frequency.value = f; const g = AC.createGain(); g.gain.setValueAtTime(0.0001, t + k * 0.05);
        g.gain.exponentialRampToValueAtTime(0.09, t + k * 0.05 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + k * 0.05 + 0.22);
        o.connect(g); g.connect(snd.master); o.start(t + k * 0.05); o.stop(t + k * 0.05 + 0.25);
      });
    }
    // engine per car (CARS[].snd): ['ice', pitch, gears] = recorded engine through a gearbox · ['ev', pitch] = electric whine
    const GEARS = {};
    const gearsOf = (id) => { const sd = H.CAR[id].snd || ['ice', 1, 6]; if (sd[0] !== 'ice') return null; if (!GEARS[id]) { const n = sd[2] || 6; GEARS[id] = Array.from({ length: n }, (_, i) => 0.27 * Math.pow(1 / 0.27, i / (n - 1))); } return GEARS[id]; };
    const pitchOf = (id) => (H.CAR[id].snd || [0, 1])[1] || 1;
    function gearTick(c) {   // rpm / gear of the watched car (HUD + engine sound)
      if (!c) return;
      const g = gearsOf(c.car), p = H.phOf(c), sp = Math.abs(c.vf);
      if (!g) { c.gear = 1; c.rpmK = sp / p.vtop; c.rpm = c.rpmK * 15000; return; }
      const top = p.vtop * 1.03, ratio = (i) => g[i - 1] * top;
      let gi = c.gear | 0 || 1;
      if (sp / ratio(gi) > 0.97 && gi < g.length) gi++;
      else if (gi > 1 && sp / ratio(gi - 1) < 0.72) gi--;
      if (gi !== c.gear && snd && c.seat === mySeat() && phase === 'race') { snd.dip = gi > c.gear ? 0.12 : 0.06; burst(gi > c.gear ? 420 : 300, 160, 2.5, 0.09, gi > c.gear ? 0.16 : 0.1); }
      c.gear = gi;
      const lo = gi > 1 ? ratio(gi - 1) * 0.62 : 0;
      let rk = clamp((sp - lo) / (ratio(gi) - lo), 0, 1);
      if (c.ws > 0.2) rk = Math.max(rk, 0.75 + Math.random() * 0.05);   // wheelspin revs
      if (phase !== 'race') rk = Math.max(rk, c.thr ? 0.55 + Math.random() * 0.05 : 0.08);
      c.rpmK = rk; c.rpm = 1100 + rk * 7900;
    }
    function audioTick(c, dt) {
      if (!AC || !snd) return;
      const t = AC.currentTime, sp = Math.abs(c ? c.vf : 0);
      snd.master.gain.setTargetAtTime(paused ? 0 : snd.vol() * 0.9, t, 0.05);
      const off = (n) => n.g.gain.setTargetAtTime(0, t, 0.1);
      if (!c) { for (const n of [snd.skid, snd.squeal, snd.scrape, snd.rumble, snd.wind]) off(n); if (snd.eng) snd.eng.g.gain.setTargetAtTime(0, t, 0.2); snd.osc.g1.gain.setTargetAtTime(0, t, 0.2); snd.osc.g2.gain.setTargetAtTime(0, t, 0.2); return; }
      const g = gearsOf(c.car), rpmK = c.rpmK || 0, pit = pitchOf(c.car);
      snd.dip = Math.max(0, snd.dip - dt);
      const dipK = snd.dip > 0 ? 0.45 : 1, bst = (c.bst || 0) > 0 ? 1 : 0;
      if (g) {
        if (snd.eng) { snd.eng.s.playbackRate.setTargetAtTime((0.55 + rpmK * 1.25) * pit * (snd.dip > 0 ? 0.88 : 1), t, snd.dip > 0 ? 0.01 : 0.04); snd.eng.g.gain.setTargetAtTime((0.16 + (c.thr ? 0.2 : 0.06) + bst * 0.06) * dipK, t, 0.03); }
        snd.osc.o1.frequency.setTargetAtTime(38 + rpmK * 150, t, 0.04); snd.osc.f1.frequency.setTargetAtTime(500 + rpmK * 1400 + bst * 600, t, 0.05);
        snd.osc.g1.gain.setTargetAtTime((0.025 + (c.thr ? 0.05 : 0.015)) * dipK, t, 0.04); snd.osc.g2.gain.setTargetAtTime(0, t, 0.1);
      } else {   // electric: whine rises with speed
        if (snd.eng) snd.eng.g.gain.setTargetAtTime(0, t, 0.1);
        snd.osc.o2.frequency.setTargetAtTime((160 + rpmK * 1350) * pit + bst * 200, t, 0.04); snd.osc.g2.gain.setTargetAtTime(0.02 + (c.thr ? 0.05 : 0.015) * (0.3 + rpmK) + bst * 0.02, t, 0.06);
        snd.osc.o1.frequency.setTargetAtTime(40 + rpmK * 300, t, 0.05); snd.osc.f1.frequency.setTargetAtTime(300 + rpmK * 900, t, 0.05); snd.osc.g1.gain.setTargetAtTime(0.012 + rpmK * 0.025, t, 0.06);
      }
      // tyres: a scrub near the grip limit, a squeal when sliding (pitch wobbles with the slide)
      const asphalt = (c.surf | 0) <= 1, slip = c.slip || 0, sv = clamp(sp / 12, 0, 1);
      const scrub = clamp(((c.gu || 0) - 0.82) * 4, 0, 1) * sv * (asphalt ? 1 : 0.3);
      const sq = clamp((slip - 0.15) * 2.2, 0, 1) * sv * (asphalt ? 1 : 0.25) * (wetK ? 0.45 : 1);
      snd.skid.g.gain.setTargetAtTime(Math.max(scrub * 0.07, sq * 0.12), t, 0.05);
      snd.skid.fl.frequency.setTargetAtTime(700 + sq * 600, t, 0.08);
      snd.squeal.g.gain.setTargetAtTime(sq * 0.16, t, 0.04);
      snd.squeal.fl.frequency.setTargetAtTime(1250 + sq * 500 + Math.sin(t * 9) * 90, t, 0.03);
      snd.scrape.g.gain.setTargetAtTime(clamp(((c.fxScrS || 0) - 3) / 25, 0, 1) * 0.22, t, 0.03);
      snd.rumble.g.gain.setTargetAtTime((c.surf === 1 ? 0.16 : (c.surf | 0) >= 2 ? 0.22 : 0) * sv, t, 0.06);
      snd.wind.g.gain.setTargetAtTime(clamp(sp / 80, 0, 1) ** 2 * 0.12 + bst * 0.04, t, 0.1);
      snd.rain.g.gain.setTargetAtTime(wetK ? 0.05 : 0, t, 0.3);
    }

    /* ======================= 효과(연기 · 흙먼지 · 물보라 · 불꽃 · 스키드 자국 · 부스트 불꽃 · 브레이크 빛 · 비) =======================
       그래픽 단계마다 입자 수 · 자국 길이를 나눠 폰(낮음)도 부드럽게. 입자 = 크기 · 투명도가 수명 따라 변하는 점(셰이더 하나). */
    const FXN = { low: { smoke: 150, spray: 140, spark: 90, skid: 360, rate: 0.45 }, mid: { smoke: 380, spray: 300, spark: 180, skid: 1000, rate: 0.8 }, high: { smoke: 700, spray: 520, spark: 280, skid: 1800, rate: 1 } }[TIER.id] || { smoke: 150, spray: 140, spark: 90, skid: 360, rate: 0.45 };
    let puffTex = null;
    const pUni = { scale: { value: 400 } };
    function partSys(n, o) {
      if (!puffTex) puffTex = canvasTex(64, 64, (g, w, hh) => {
        const r = g.createRadialGradient(w / 2, hh / 2, 0, w / 2, hh / 2, w / 2);
        r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(0.45, 'rgba(255,255,255,.55)'); r.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = r; g.fillRect(0, 0, w, hh);
      });
      const g = new THREE.BufferGeometry(), pos = new Float32Array(n * 3), sz = new Float32Array(n), al = new Float32Array(n), col = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) pos[i * 3 + 1] = -999;
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aSize', new THREE.BufferAttribute(sz, 1));
      g.setAttribute('aAlpha', new THREE.BufferAttribute(al, 1)); g.setAttribute('aCol', new THREE.BufferAttribute(col, 3));
      const m = new THREE.ShaderMaterial({
        uniforms: { map: { value: puffTex }, scale: pUni.scale },
        vertexShader: 'attribute float aSize; attribute float aAlpha; attribute vec3 aCol; uniform float scale; varying float vA; varying vec3 vC;\n' +
          // 점 입자는 한가운데 깊이로만 그려져, 커진 연기 · 물보라의 아래쪽이 길에 가려 수평으로 뚝 잘리고 그 선이 프레임마다 튐
          // → 커질수록 조금 띄우고(바닥에 반쯤 묻히지 않게) 깊이는 카메라 쪽으로 당김
          'void main(){ vA = aAlpha; vC = aCol; vec4 mv = modelViewMatrix * vec4(position.x, position.y + aSize * 0.35, position.z, 1.0); gl_Position = projectionMatrix * mv; gl_PointSize = aSize * scale / max(0.5, -mv.z); vA *= smoothstep(1.5, ' + (o.add ? '6.0' : '9.0') + ', -mv.z)' + (o.add ? '' : ' * 0.6') + ';\n' +
          '  vec4 pb = projectionMatrix * vec4(mv.xy, min(mv.z + aSize * 0.3, -0.2), 1.0); gl_Position.z = pb.z / pb.w * gl_Position.w; }',
        fragmentShader: 'uniform sampler2D map; varying float vA; varying vec3 vC;\n' +
          'void main(){ vec4 t = texture2D(map, gl_PointCoord); float a = t.a * vA; if (a < 0.004) discard; gl_FragColor = vec4(vC * ' + (o.add ? 'a' : '1.0') + ', ' + (o.add ? '1.0' : 'a') + '); }',
        transparent: true, depthWrite: false, blending: o.add ? THREE.AdditiveBlending : THREE.NormalBlending,
      });
      const pts = new THREE.Points(g, m); pts.frustumCulled = false; pts.renderOrder = o.add ? 3 : 2; scene.add(pts);
      // per particle: x y z vx vy vz life max s0 s1 a0 r g b grav drag
      const D = new Float32Array(n * 16);
      let head = 0, live = 0;
      return {
        pts,
        emit(x, y, z, vx, vy, vz, life, s0, s1, a0, r, gg, b, grav, drag) {
          const k = head * 16; head = (head + 1) % n;
          D[k] = x; D[k + 1] = y; D[k + 2] = z; D[k + 3] = vx; D[k + 4] = vy; D[k + 5] = vz; D[k + 6] = life; D[k + 7] = life;
          D[k + 8] = s0; D[k + 9] = s1; D[k + 10] = a0; D[k + 11] = r; D[k + 12] = gg; D[k + 13] = b; D[k + 14] = grav; D[k + 15] = drag; live = 1;
        },
        tick(dt) {
          if (!live) return;
          let any = 0;
          for (let i = 0; i < n; i++) {
            const k = i * 16;
            if (D[k + 6] <= 0) { if (pos[i * 3 + 1] !== -999) { pos[i * 3 + 1] = -999; al[i] = 0; } continue; }
            any = 1;
            D[k + 6] -= dt;
            const f = Math.exp(-D[k + 15] * dt);
            D[k + 3] *= f; D[k + 4] = D[k + 4] * f - D[k + 14] * dt; D[k + 5] *= f;
            D[k] += D[k + 3] * dt; D[k + 1] += D[k + 4] * dt; D[k + 2] += D[k + 5] * dt;
            const t = 1 - Math.max(0, D[k + 6]) / D[k + 7];
            pos[i * 3] = D[k]; pos[i * 3 + 1] = D[k + 1]; pos[i * 3 + 2] = D[k + 2];
            sz[i] = D[k + 8] + (D[k + 9] - D[k + 8]) * Math.sqrt(t);
            al[i] = D[k + 10] * (t < 0.12 ? t / 0.12 : 1 - (t - 0.12) / 0.88);
            col[i * 3] = D[k + 11]; col[i * 3 + 1] = D[k + 12]; col[i * 3 + 2] = D[k + 13];
          }
          live = any;
          for (const nm of ['position', 'aSize', 'aAlpha', 'aCol']) g.attributes[nm].needsUpdate = true;
        },
      };
    }
    /* skid marks: one ring buffer of quads (two per car when sliding), darker where the slide is harder */
    function skidSys(n) {
      const g = new THREE.BufferGeometry(), pos = new Float32Array(n * 12), al = new Float32Array(n * 4), idx = new Uint32Array(n * 6);
      for (let q = 0; q < n; q++) { const v = q * 4; idx.set([v, v + 1, v + 2, v + 1, v + 3, v + 2], q * 6); }
      for (let i = 0; i < n * 4; i++) pos[i * 3 + 1] = -999;
      g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('aA', new THREE.BufferAttribute(al, 1)); g.setIndex(new THREE.BufferAttribute(idx, 1));
      const m = new THREE.ShaderMaterial({
        vertexShader: 'attribute float aA; varying float vA; void main(){ vA = aA; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }',
        fragmentShader: 'varying float vA; void main(){ gl_FragColor = vec4(0.045, 0.045, 0.05, vA); }',
        transparent: true, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -6, polygonOffsetUnits: -6,
      });
      const mesh = new THREE.Mesh(g, m); mesh.frustumCulled = false; mesh.renderOrder = 1; scene.add(mesh);
      let head = 0, dirty = 0;
      return {
        mesh,
        add(ax, ay, az, bx, by, bz, wdt, a0, a1) {   // three coords: segment a → b
          const dx = bx - ax, dz = bz - az, l = Math.hypot(dx, dz) || 1, nx = (-dz / l) * wdt / 2, nz = (dx / l) * wdt / 2, v = head * 4;
          pos.set([ax - nx, ay, az - nz, ax + nx, ay, az + nz, bx - nx, by, bz - nz, bx + nx, by, bz + nz], v * 3);
          al[v] = al[v + 1] = a0; al[v + 2] = al[v + 3] = a1;
          head = (head + 1) % n; dirty = 1;
        },
        flush() { if (!dirty) return; dirty = 0; g.attributes.position.needsUpdate = true; g.attributes.aA.needsUpdate = true; },
      };
    }
    let smoke = null, spray = null, sparks = null, rain = null, skids = null;
    function clearFx() {
      for (const o of [smoke, sparks, spray]) if (o && o.pts) { scene.remove(o.pts); o.pts.geometry.dispose(); o.pts.material.dispose(); }
      if (skids) { scene.remove(skids.mesh); skids.mesh.geometry.dispose(); skids.mesh.material.dispose(); }
      if (rain) { scene.remove(rain); rain.geometry.dispose(); }
      smoke = sparks = spray = rain = skids = null;
    }
    function buildFx(s) {
      const lo = TIER.id === 'low';
      smoke = partSys(FXN.smoke, {});
      sparks = partSys(FXN.spark, { add: true });
      skids = skidSys(FXN.skid);
      if (s.wx === 'rain') {
        spray = partSys(FXN.spray, {});
        const N = lo ? 500 : 1300, g = new THREE.BufferGeometry(), pos = new Float32Array(N * 6);
        for (let i = 0; i < N; i++) { const x = (Math.random() - 0.5) * 60, y = Math.random() * 30, z = (Math.random() - 0.5) * 60; pos.set([x, y, z, x + 0.05, y - 0.9, z], i * 6); }
        g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        const m = new THREE.LineBasicMaterial({ color: 0xaab4c0, transparent: true, opacity: 0.35 });
        rain = new THREE.LineSegments(g, m); rain.frustumCulled = false; scene.add(rain); rain.userData.N = N;
      }
    }
    const R01 = () => Math.random() - 0.5;
    function fxTick(dt) {
      if (!W || !smoke) return;
      pUni.scale.value = (R.domElement.height || vh) / (2 * Math.tan((cam.fov * PI) / 360));
      const rate = FXN.rate, camP = cam.position;
      for (const c of W.cars) {
        const o = carObjs[c.seat]; if (!o) continue;
        const v = Math.hypot(c.vf, c.vl), ch = Math.cos(c.h), sh = Math.sin(c.h), y = roadY(c);
        const near = (c.x - camP.x) ** 2 + (-c.y - camP.z) ** 2 < 260 * 260;
        const wx = c.vf * ch - c.vl * sh, wz = -(c.vf * sh + c.vl * ch);   // world velocity (three coords)
        const d = o.dims, rz = d.rz, rx = d.rx;
        const slip = c.slip || 0, surf = c.surf | 0, onRoad = surf <= 1, dirt = surf >= 2;
        // rear tyre contact points (sim → three)
        const wp = [-1, 1].map((sd) => [c.x + ch * rz - sh * rx * sd, -(c.y + sh * rz + ch * rx * sd)]);
        // tyre smoke: slides, burnouts, handbrake — light grey on asphalt
        if (near && onRoad && !wetK && !o.def.ph.hover && slip > 0.22 && (v > 3 || c.ws > 0.2)) {
          const k = Math.min(0.8, (slip - 0.18) * 1.3) * rate, gy = nightK ? 0.5 : 0.86;
          for (const [x, z] of wp) if (Math.random() < k) smoke.emit(x + R01() * 0.4, y + 0.3, z + R01() * 0.4, wx * 0.3 + R01() * 1.4, 0.4 + Math.random() * 0.8, wz * 0.3 + R01() * 1.4, 1.1 + Math.random() * 0.9, 0.7, 3.2 + slip * 1.6, 0.16 + slip * 0.09, gy, gy, gy + 0.02, -0.2, 1.1);
        }
        // dust on grass / gravel
        if (near && dirt && v > 6 && Math.random() < Math.min(1, v / 30) * rate) for (const [x, z] of wp) smoke.emit(x, y + 0.25, z, wx * 0.15 + R01() * 2.5, 0.8 + Math.random() * 1.2, wz * 0.15 + R01() * 2.5, 0.9 + Math.random() * 0.6, 0.7, 3.4, 0.38, surf === 3 ? 0.62 : 0.45, surf === 3 ? 0.55 : 0.4, surf === 3 ? 0.44 : 0.27, 1.2, 1.4);
        // rain spray behind the wheels
        if (spray && near && v > 12 && Math.random() < Math.min(1, v / 45) * rate) for (const [x, z] of wp) spray.emit(x + R01() * 0.5, y + 0.25, z + R01() * 0.5, wx * 0.55 + R01() * 2, 0.9 + Math.random() * 1.2, wz * 0.55 + R01() * 2, 0.45 + Math.random() * 0.35, 0.6, 3.2, 0.26, 0.8, 0.83, 0.87, 3, 1.8);
        // skid marks (asphalt / kerbs)
        const mark = onRoad && !wetK && !o.def.ph.hover && v > 2 && (slip > 0.3 || (c.brk > 0.9 && v > 25 && surf === 0));
        if (!o.skid) o.skid = [null, null];
        wp.forEach(([x, z], k) => {
          if (!mark) { o.skid[k] = null; return; }
          const L0 = o.skid[k], a1 = Math.min(0.42, 0.12 + slip * 0.36), yy = y + 0.075;
          if (!L0) { o.skid[k] = [x, yy, z, a1 * 0.3]; return; }
          if ((x - L0[0]) ** 2 + (z - L0[2]) ** 2 < 0.36) return;
          skids.add(L0[0], L0[1], L0[2], x, yy, z, 0.26, L0[3], a1);
          o.skid[k] = [x, yy, z, a1];
        });
        // sparks: wall scrapes and hard hits, at the contact point
        const hit = c.fxHit || 0, scr = c.fxScr || 0;
        if (near && (hit > 3 || scr > 6)) {
          const px = c.hx != null ? c.hx : c.x, pz = -(c.hy != null ? c.hy : c.y), nn = Math.round(Math.min(26, hit * 1.6 + scr * 0.7) * rate) + 2;
          for (let k = 0; k < nn; k++) sparks.emit(px + R01() * 0.6, y + 0.35 + Math.random() * 0.4, pz + R01() * 0.6, wx * 0.6 + R01() * 7, 1 + Math.random() * 4, wz * 0.6 + R01() * 7, 0.3 + Math.random() * 0.4, 0.34, 0.1, 1, 1, 0.6 + Math.random() * 0.3, 0.22, 9.8, 0.5);
        }
        // boost flame
        if (o.flame) {
          const on = (c.bst || 0) > 0 ? Math.min(1, c.bst / 0.3) : 0;
          o.flame.visible = on > 0.02;
          if (o.flame.visible) { o.flT = (o.flT || c.seat * 1.7) + dt; const f = 1 + 0.12 * Math.sin(o.flT * 31) + 0.08 * Math.sin(o.flT * 47.3), g = 1.15 + 0.16 * Math.sin(o.flT * 23.7) + 0.09 * Math.sin(o.flT * 39.1); o.flame.scale.set(on * f, 1, on * f * g); o.flame.material.opacity = 0.7 * on; }
        }
        // brake-light glow
        if (o.brake) { const op = lerp(o.brake.material.opacity, c.brk > 0.05 ? 0.8 : nightK ? 0.28 : 0, Math.min(1, dt * 14)); o.brake.material.opacity = op; o.brake.visible = op > 0.02; }
      }
      skids.flush();
      smoke.tick(dt); sparks.tick(dt); if (spray) spray.tick(dt);
      if (rain) {
        rain.position.set(cam.position.x, cam.position.y - 12, cam.position.z);
        const p = rain.geometry.attributes.position, a = p.array, N = rain.userData.N, fall = 26 * dt;
        for (let i = 0; i < N; i++) { let y0 = a[i * 6 + 1] - fall; if (y0 < 0) y0 += 30; a[i * 6 + 1] = y0; a[i * 6 + 4] = y0 - 0.9; }
        p.needsUpdate = true;
      }
    }
    /* per car: boost flame and brake-light glow (camera-facing enough from behind; additive) */
    let flameTex = null, glowTex = null;
    function carSprites(o) {
      if (!flameTex) flameTex = canvasTex(64, 128, (g, w, hh) => {
        const r = g.createRadialGradient(w / 2, hh * 0.12, 1, w / 2, hh * 0.3, hh * 0.6);
        r.addColorStop(0, 'rgba(200,230,255,1)'); r.addColorStop(0.12, 'rgba(120,180,255,.85)'); r.addColorStop(0.35, 'rgba(255,150,60,.6)'); r.addColorStop(0.7, 'rgba(255,80,20,.22)'); r.addColorStop(1, 'rgba(255,60,10,0)');
        g.fillStyle = r; g.beginPath(); g.ellipse(w / 2, hh * 0.46, w * 0.38, hh * 0.46, 0, 0, 7); g.fill();
      });
      if (!glowTex) glowTex = canvasTex(64, 64, radial([[0, 'rgba(255,70,50,1)'], [0.35, 'rgba(255,30,20,.5)'], [1, 'rgba(255,0,0,0)']]));
      const d = o.dims;
      // flame: two crossed quads lying along the car's axis, pointing backwards from the rear centre
      const fm = new THREE.MeshBasicMaterial({ map: flameTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, opacity: 0 });
      const flame = new THREE.Group();
      for (const rz of [0, PI / 2]) {
        const q = new THREE.Mesh(new THREE.PlaneGeometry(0.34, 1.1), fm);
        q.rotation.order = 'ZXY'; q.rotation.set(PI / 2, 0, rz); q.position.z = -0.5; flame.add(q);
      }
      flame.position.set(0, 0.42, d.rear + 0.02); flame.visible = false; flame.material = fm;
      o.tilt.add(flame); o.flame = flame;
      const gm = new THREE.MeshBasicMaterial({ map: glowTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0 });
      const br = new THREE.Group(); br.material = gm;
      for (const sd of [-1, 1]) { const q = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.6), gm); q.position.set(sd * d.half * 0.7, clamp(d.top * 0.55, 0.45, 1.2), d.rear - 0.04); q.rotation.y = PI; br.add(q); }
      br.visible = false; o.tilt.add(br); o.brake = br;
    }

    /* ======================= 아이템 그림 (「아케이드 요소」) =======================
       상자 = 떠서 도는 육각 보급 캡슐(청록 껍데기 · 육각 고리 · 금빛 심) — 인스턴스 3묶음(그리기 3번), 먹히면 꺼졌다 3초 뒤 부풀며 다시 나타남.
       기름 = 바닥의 짙은 무지갯빛 웅덩이, 연막 = 회색 연기 구름(입자), 차 = 충격 범퍼 막(초록 테두리 빛) · 바닥 고리(맞음 · 접지 타이어 · 자석), 방해 전파 = 지지직 번개 줄. */
    let IB3 = null, oilM = null, cloud = null;
    const hz3 = new Map(), zaps = [];
    function buildBoxes() {
      IB3 = null;
      if (!(T.IB && T.IB.length)) return;
      const pts = [];
      T.IB.forEach(([i, lats], r) => lats.forEach((l, j) => pts.push({ r, j, p: X3(T, i, l, 1.05), ph: (r * 7 + j) * 0.9 })));
      const N = pts.length;
      const shell = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.62, 0.62, 0.95, 6), new THREE.MeshStandardMaterial({ color: 0x1fc8c0, emissive: 0x0f8a84, roughness: 0.25, metalness: 0.1, transparent: true, opacity: 0.4, depthWrite: false }), N);
      const ring = new THREE.InstancedMesh(new THREE.TorusGeometry(0.68, 0.06, 6, 6), new THREE.MeshBasicMaterial({ color: 0x7ff6ee }), N);
      const core = new THREE.InstancedMesh(new THREE.OctahedronGeometry(0.3), new THREE.MeshBasicMaterial({ color: 0xffcf5a }), N);
      for (const m of [core, shell, ring]) { m.frustumCulled = false; m.renderOrder = 2; world.add(m); }   // the gold core first, the see-through shell over it
      IB3 = { pts, shell, ring, core, m: new THREE.Matrix4(), q: new THREE.Quaternion(), e: new THREE.Euler(), s: new THREE.Vector3(), t: 0 };
      boxTick(0);
    }
    function boxTick(dt) {
      if (!IB3) return;
      const B = IB3, now = W ? W.t : 0; B.t += dt;
      for (let k = 0; k < B.pts.length; k++) {
        const q = B.pts[k], back = W && W.ibT ? W.ibT[q.r][q.j] : 0, gone = back > now;
        const sc = gone ? 0 : clamp(1 - (back + 0.35 - now) / 0.35, 0, 1);   // pops back in over 0.35 s
        const bob = Math.sin(B.t * 2.2 + q.ph) * 0.12, yaw = B.t * 1.4 + q.ph;
        const s = sc < 1 ? sc * (1.2 - 0.2 * sc) : 1;
        B.e.set(0, yaw, 0); B.q.setFromEuler(B.e); B.s.set(s, s, s);
        B.m.compose(new THREE.Vector3(q.p.x, q.p.y + bob, q.p.z), B.q, B.s); B.shell.setMatrixAt(k, B.m);
        B.e.set(PI / 2, 0, yaw); B.q.setFromEuler(B.e); B.m.compose(new THREE.Vector3(q.p.x, q.p.y + bob, q.p.z), B.q, B.s); B.ring.setMatrixAt(k, B.m);
        B.e.set(B.t * 2.1 + q.ph, yaw * 1.6, 0); B.q.setFromEuler(B.e); B.m.compose(new THREE.Vector3(q.p.x, q.p.y + bob, q.p.z), B.q, B.s); B.core.setMatrixAt(k, B.m);
      }
      B.shell.instanceMatrix.needsUpdate = B.ring.instanceMatrix.needsUpdate = B.core.instanceMatrix.needsUpdate = true;
    }
    function oilMat() {
      if (!oilM) oilM = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -7, polygonOffsetUnits: -7,
        map: canvasTex(128, 128, (g, w, hh) => {
          const r = g.createRadialGradient(w / 2, hh / 2, 2, w / 2, hh / 2, w / 2);
          r.addColorStop(0, 'rgba(10,8,14,.95)'); r.addColorStop(0.55, 'rgba(14,10,20,.9)'); r.addColorStop(0.8, 'rgba(20,14,30,.55)'); r.addColorStop(1, 'rgba(20,14,30,0)');
          g.fillStyle = r; g.beginPath(); for (let k = 0; k <= 24; k++) { const a = (k / 24) * PI * 2, rr = w / 2 * (0.82 + 0.16 * Math.sin(k * 2.7) * Math.cos(k * 1.3)); k ? g.lineTo(w / 2 + Math.cos(a) * rr, hh / 2 + Math.sin(a) * rr) : g.moveTo(w / 2 + Math.cos(a) * rr, hh / 2 + Math.sin(a) * rr); } g.fill();
          for (const [c, o] of [['rgba(120,90,255,.35)', 0.18], ['rgba(60,220,200,.28)', 0.3], ['rgba(255,120,200,.22)', 0.42]]) { g.strokeStyle = c; g.lineWidth = 5; g.beginPath(); g.ellipse(w * (0.45 + o * 0.2), hh * (0.44 + o * 0.1), w * o * 0.9, hh * o * 0.6, 0.6, 0, PI * 1.3); g.stroke(); }
        }) });
      return oilM;
    }
    function itemCarFx(o) {   // per car: shield film + a ring on the ground (made with the car so the shaders are compiled before the start)
      const d = o.dims, L0 = d.front - d.rear, mz = (d.front + d.rear) / 2;
      const sm = new THREE.ShaderMaterial({
        uniforms: { col: { value: new THREE.Color(0x8cff9a) }, op: { value: 0 } },
        vertexShader: 'varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }',
        fragmentShader: 'uniform vec3 col; uniform float op; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - abs(dot(normalize(vN), normalize(vV))), 4.0); gl_FragColor = vec4(col * (0.012 + 0.62 * f) * op, 1.0); }',
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      });
      const sh = new THREE.Mesh(new THREE.SphereGeometry(1, 22, 14), sm);
      sh.scale.set(d.half * 1.4, clamp(d.top, 0.9, 3) * 0.8, L0 * 0.62); sh.position.set(0, clamp(d.top, 0.9, 3) * 0.42, mz); sh.visible = false; sh.renderOrder = 4;
      o.tilt.add(sh); o.shield = sh;
      const rm = new THREE.MeshBasicMaterial({ color: 0x5ad1ff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -8, polygonOffsetUnits: -8 });
      const rg = new THREE.Mesh(new THREE.RingGeometry(1, 1.16, 40), rm);
      rg.rotation.x = -PI / 2; rg.position.set(0, 0.07, mz); rg.scale.setScalar(clamp(L0 * 0.62, 1.6, 4.5)); rg.visible = false; o.root.add(rg); o.iring = rg;
    }
    function itemFxTick(dt) {
      if (!W || !W.items) return;
      boxTick(dt);
      // hazards on the road
      const live = new Set();
      for (const z of W.hz) {
        live.add(z.id);
        let m = hz3.get(z.id);
        if (!m) {
          const yy = T.H[z.idx] - z.lat * (T.BK[z.idx] || 0);
          if (z.k === 'oil') { m = new THREE.Mesh(new THREE.CircleGeometry(1, 28), oilMat().clone()); m.rotation.x = -PI / 2; m.rotation.z = (z.id % 7) * 0.9; m.position.set(z.x, yy + 0.07, -z.y); m.scale.setScalar(z.r * 1.2); world.add(m); }
          else { m = { isCloud: 1, y: yy }; if (cloud) for (let k = 0; k < 10; k++) cloud.emit(z.x + R01() * 4, yy + 0.8 + Math.random() * 1.5, -z.y + R01() * 4, R01() * 2, 0.5 + Math.random(), R01() * 2, 1.6 + Math.random(), 3, 8.5, 0.6, 0.8, 0.81, 0.84, -0.05, 0.9); }
          hz3.set(z.id, m);
        }
        const left = z.end - W.t;
        if (m.isCloud) { if (cloud && Math.random() < dt * (left > 1 ? 16 : 6)) cloud.emit(z.x + R01() * z.r * 1.1, m.y + 0.5 + Math.random() * 1.8, -z.y + R01() * z.r * 1.1, R01() * 1.2, 0.3 + Math.random() * 0.6, R01() * 1.2, 1.6 + Math.random() * 0.8, 3.5, 8.5, 0.55, 0.78, 0.79, 0.82, -0.05, 0.8); }
        else m.material.opacity = clamp(left / 0.8, 0, 1) * clamp((W.t - z.t0) / 0.25, 0, 1);
      }
      for (const [id, m] of hz3) if (!live.has(id)) { if (m.isMesh) { world.remove(m); m.geometry.dispose(); m.material.dispose(); } hz3.delete(id); }
      if (cloud) cloud.tick(dt);
      // car effects (a remote car's come from its flags)
      for (const c of W.cars) {
        const o = carObjs[c.seat]; if (!o || !o.shield) continue;
        const inCar = c.seat === mySeat() && camMode >= 2 && camMode <= 4 && fl.k < 0.5;   // hood / bumper / seat view: the camera is inside the film
        const sOn = c.shd > 0 && !inCar, so = o.shield.material.uniforms.op;
        so.value = lerp(so.value, sOn ? 0.9 + Math.sin(performance.now() / 120) * 0.1 : 0, Math.min(1, dt * 10)); o.shield.visible = so.value > 0.02;
        const rk = c.slow > 0 ? (c.slK === 2 ? 0xb48cff : 0x5ad1ff) : c.trc > 0 ? 0xffcf5a : c.mag > 0 ? 0x3fe6ff : null, rm = o.iring.material;
        if (rk != null) rm.color.setHex(rk);
        rm.opacity = lerp(rm.opacity, rk != null ? (c.slow > 0 ? 0.95 : 0.55) : 0, Math.min(1, dt * 10)); o.iring.visible = rm.opacity > 0.02; o.iring.rotation.z += dt * (c.slow > 0 ? 7 : 2);
        if (c.slow > 0 && c.slK !== 2 && Math.random() < dt * 30 && sparks) { const y = roadY(c); sparks.emit(c.x + R01() * 2, y + 0.4 + Math.random() * 1.2, -c.y + R01() * 2, R01() * 3, 1 + Math.random() * 2, R01() * 3, 0.25, 0.3, 0.06, 1, 0.35, 0.82, 1, 2, 1); }
      }
      // 방해 전파: a jagged bolt from the user to the car ahead
      if (zaps.length) {
        const P = [];
        for (const z of zaps) {
          z.t -= dt; const A = W.cars[z.a], B = W.cars[z.b]; if (!A || !B || z.t <= 0) continue;
          const ya = roadY(A) + 1.3, yb = roadY(B) + 1.2, n = 9;
          let px = A.x, py = ya, pz = -A.y;
          for (let k = 1; k <= n; k++) { const f = k / n, j = k < n ? 0.9 : 0; const x = lerp(A.x, B.x, f) + R01() * j * 2, y = lerp(ya, yb, f) + Math.sin(f * PI) * 2 + R01() * j, zz = lerp(-A.y, -B.y, f) + R01() * j * 2; P.push(px, py, pz, x, y, zz); px = x; py = y; pz = zz; }
        }
        for (let k = zaps.length - 1; k >= 0; k--) if (zaps[k].t <= 0) zaps.splice(k, 1);
        zapLine.geometry.setAttribute('position', new THREE.Float32BufferAttribute(P.length ? P : [0, -999, 0, 0, -999, 0], 3));
        zapLine.visible = P.length > 0;
      } else if (zapLine && zapLine.visible) zapLine.visible = false;
    }
    let zapLine = null;
    function buildItemFx() {
      for (const [, m] of hz3) if (m.isMesh) { world.remove(m); m.geometry.dispose(); m.material.dispose(); }
      hz3.clear(); zaps.length = 0;
      if (cloud) { scene.remove(cloud.pts); cloud.pts.geometry.dispose(); cloud.pts.material.dispose(); cloud = null; }
      if (!W || !W.items) return;
      cloud = partSys(TIER.id === 'low' ? 90 : 160, {});
      if (!zapLine) { zapLine = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0x9fe8ff, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false })); zapLine.frustumCulled = false; scene.add(zapLine); }
      zapLine.geometry.setAttribute('position', new THREE.Float32BufferAttribute([0, -999, 0, 0, -999, 0], 3)); zapLine.visible = false;
      // a hidden oil puddle so its shader is compiled with the rest before the start
      const t = new THREE.Mesh(new THREE.CircleGeometry(1, 8), oilMat()); t.rotation.x = -PI / 2; t.position.set(T.X[0], T.H[0] - 50, -T.Y[0]); t.visible = false; t.userData.warm = 1; world.add(t); W.oilWarm = t;
    }

    /* ======================= 카메라 =======================
       뒤따라 보기: 차체 방향을 늦게 따라가며(무게감) 미끄러질 땐 진행 방향 쪽으로 돌아 차의 옆모습이 보이게, 속도 · 부스트에 시야각 ↑,
       부딪힘 · 연석 · 잔디에 살짝 흔들림(사람이 탄 차만). */
    const camPos = new THREE.Vector3(), camLook = new THREE.Vector3(), sdR = new THREE.Vector3(), sdU = new THREE.Vector3();
    let camInit = false, orbit = 0, tvSeat = -1, tvT = 0, camYaw = 0, camSeat = -1, camY = 0, shake = 0, shT = 0, camSide = 0, camInto = 0;
    function camTick(dt) {
      if (DBG.camOv) { const o = DBG.camOv; cam.position.set(o[0], o[1], o[2]); cam.lookAt(o[3], o[4], o[5]); if (cam.view && cam.view.enabled) cam.clearViewOffset(); cam.fov = o[6] || 60; cam.updateProjectionMatrix(); return; }   // test shots
      if (!W) {   // picking: orbit the car on show — drag = turn / tilt, wheel / two fingers = zoom, turns by itself when left alone
        if (!previewObj) return;
        pv.idle += dt;
        if (pv.idle > 3 && !pv.ptr.size) pv.yaw += dt * 0.28 * Math.min(1, pv.idle - 3);
        if (pv.ty != null) {   // Tab view presets: glide there
          const k = 1 - Math.exp(-dt * 7), dy = H.wrapA(pv.ty - pv.yaw);
          pv.yaw += dy * k; pv.pitch += (pv.tp - pv.pitch) * k;
          if (Math.abs(dy) < 0.002 && Math.abs(pv.tp - pv.pitch) < 0.002) pv.ty = null;
        }
        const p = previewObj.root.position, d = previewObj.dims, Lc = clamp(d.front - d.rear, 2.6, 9);
        const fx = pickPW ? (vw - pickPW) / vw : 1, fy = pickPH ? (vh - pickPH) / vh : 1, th = Math.tan(20 * PI / 180);
        const fit = Math.max((Lc * 0.92 + 0.8) / (1.45 * fx * th * (vw / vh)), (clamp(d.top, 0.9, 3.4) + 1.2) / (1.3 * fy * th));
        const R0 = Math.max(3.4 + Lc * 0.95, fit) * pv.zoom, cy = Math.cos(pv.pitch), yaw = pv.yaw + previewObj.root.rotation.y;
        const ty = p.y + clamp(d.top * 0.42, 0.4, 1.4);
        cam.position.set(p.x + Math.sin(yaw) * R0 * cy, ty + R0 * Math.sin(pv.pitch), p.z + Math.cos(yaw) * R0 * cy);
        cam.lookAt(p.x, ty, p.z);
        if (cam.fov !== 40) { cam.fov = 40; cam.updateProjectionMatrix(); }
        if (pickPW) cam.setViewOffset(vw, vh, pickPW / 2, 0, vw, vh); else if (pickPH) cam.setViewOffset(vw, vh, 0, pickPH / 2 - 10, vw, vh); else if (cam.view && cam.view.enabled) cam.clearViewOffset();
        return;
      }
      if (cam.view && cam.view.enabled) cam.clearViewOffset();
      let me = mySeat();
      const spectate = me < 0 || !W.cars[me];
      if (spectate) {   // TV mode: follow a car near the front, switch every 9 s
        tvT -= dt;
        if (tvT <= 0 || tvSeat < 0) { const r = H.ranking(W.cars); tvSeat = r[Math.floor(Math.random() * Math.min(3, r.length))].seat; tvT = 9; }
        me = tvSeat;
      }
      const c = W.cars[me]; if (!c) return;
      const o = carObjs[me];
      const y = roadY(c), ch = Math.cos(c.h), sh = Math.sin(c.h), sp = Math.abs(c.vf);
      const fw = new THREE.Vector3(ch, 0, -sh);
      const bst = (c.bst || 0) > 0 ? Math.min(1, c.bst / 0.4) : 0;
      // shake: hits, kerbs / grass rumble, a fine buzz at top speed
      shake = Math.max(shake * Math.exp(-dt * 7), Math.min(0.35, (c.fxHit || 0) * 0.025));
      const rumble = c.surf === 1 ? 0.025 : c.surf >= 2 ? 0.045 : 0;
      const amp = (shake + rumble * clamp(sp / 25, 0, 1) + clamp((sp - 60) / 40, 0, 1) * 0.01 + bst * 0.012) * (spectate ? 0.4 : 1) * (calmOn() ? 0.25 : 1);
      shT += dt;
      const jx = amp * (Math.sin(shT * 61) + Math.sin(shT * 37.3)) * 0.5, jy = amp * (Math.sin(shT * 53.1) + Math.sin(shT * 29.7)) * 0.5;
      let fov = 60;
      if (phase === 'pick' || phase === 'load') {
        orbit += dt * 0.25;
        const R0 = 7.5, a = orbit;
        camPos.set(c.x + Math.cos(a) * R0, y + 2.2, -c.y + Math.sin(a) * R0);
        camLook.set(c.x, y + 0.6, -c.y);
        cam.position.copy(camPos); cam.lookAt(camLook); camInit = false;
      } else if (phase === 'done' && st && st.ph === 'done') {
        orbit += dt * 0.18;
        camPos.lerp(new THREE.Vector3(c.x + Math.cos(orbit) * 9, y + 3, -c.y + Math.sin(orbit) * 9), Math.min(1, dt * 2));
        cam.position.copy(camPos); cam.lookAt(c.x, y + 0.7, -c.y);
      } else {
        const mode = spectate ? 0 : camMode;
        let fovP = 60;
        if (mode <= 1) {
          // chase (near / far): the camera trails the heading with weight; in a slide it swings towards the direction of travel (you see the angle)
          const far = mode === 1;
          const vdir = Math.atan2(c.vf * Math.sin(c.h) + c.vl * Math.cos(c.h), c.vf * Math.cos(c.h) - c.vl * Math.sin(c.h));
          const dr = clamp(c.dr || 0, 0, 1) * (calmOn() ? 0.6 : 1), mixV = 0.35 + 0.4 * dr;
          const wantYaw = sp > 3 && c.vf > 0 ? c.h + H.wrapA(vdir - c.h) * mixV : c.h;
          if (!camInit || camSeat !== me) { camYaw = wantYaw; camInit = true; camSeat = me; camY = y; camSide = 0; }
          camYaw += H.wrapA(wantYaw - camYaw) * (1 - Math.exp(-dt * (5.2 - 1.4 * dr)));
          camY += (y - camY) * (1 - Math.exp(-dt * 6));
          // a small sideways lean into the corner (follows lateral g)
          camSide += (clamp((c.alat || 0) * 0.016, -0.45, 0.45) - camSide) * (1 - Math.exp(-dt * 3));
          // camera size follows the car (a 7 m truck or a 2.6 m city car): GT-sized 4.6 m · 1.25 m tall = the old 6.1 m back · 1.9 m up
          const dmL = o ? clamp(o.dims.front - o.dims.rear, 2.6, 8) : 4.6, dmT = o ? clamp(o.dims.top, 0.9, 3.2) : 1.25;
          const back = (6.1 + (dmL - 4.6) * 0.95 + (dmT - 1.25) * 0.8 + sp * 0.022 + bst * 0.7) * (far ? 1.5 : 1) + (far ? 1.6 : 0), up = (1.9 + (dmT - 1.25) * 1.05 + sp * 0.0045) * (far ? 1.65 : 1);
          const cf = new THREE.Vector3(Math.cos(camYaw), 0, -Math.sin(camYaw));
          const cr = new THREE.Vector3(Math.sin(camYaw), 0, Math.cos(camYaw));   // camera's left (three coords)
          camPos.set(c.x, camY + up, -c.y).addScaledVector(cf, -back).addScaledVector(cr, camSide);
          // look into the corner: aim a little towards the road ~1 s ahead (you see the apex coming)
          const la = (c.idx + Math.round((14 + sp * 0.7) / H.DS)) % T.n, ax = T.X[la] - c.x, ay = T.Y[la] - c.y;
          const into = sp > 6 && c.vf > 0 ? clamp(H.wrapA(Math.atan2(ay, ax) - camYaw), -0.5, 0.5) : 0;
          camInto += (into * 0.4 - camInto) * (1 - Math.exp(-dt * 3));
          camLook.set(c.x, camY + 0.9 + (dmT - 1.25) * 0.75, -c.y).addScaledVector(cf, far ? 6 : 4).addScaledVector(cr, Math.tan(camInto) * 9);
          camPos.y += jy; camPos.addScaledVector(cr, jx);
          fovP = (far ? 56 : 60) + (clamp(sp / 90, 0, 1) * 14 + bst * 7 + clamp(c.draft || 0, 0, 1) * 2) * (calmOn() ? 0.35 : 1);
        } else if (mode === 5) {
          // TV: trackside cameras every ~120 m (sides alternate); the one just ahead watches the car come and go, zooming with the distance
          const n = T.n, stp = 30, k0 = Math.floor(((c.idx - 8 + n) % n) / stp) + 1, k = (k0 * stp) % n, sd = k0 % 2 ? 1 : -1;
          const wd = (T.WD && T.WD[k]) || T.half + T.run, lat = sd * Math.max(T.half + 1.5, wd - 1.6);
          const p0 = X3(T, k, lat, 3.4);
          camPos.copy(p0); camLook.set(c.x, y + 0.7, -c.y);
          const d = camPos.distanceTo(camLook);
          fovP = clamp((2 * Math.atan(4.2 / Math.max(1, d)) * 180) / PI, 9, 58);
          camInit = false;
        } else {
          // hood / bumper / driver's seat: fixed to the body (with its pitch & roll)
          const dd = o.dims, Lc = dd.front - dd.rear, mz = (dd.front + dd.rear) / 2;
          const lp = mode === 2 ? new THREE.Vector3(0, clamp(dd.top * 0.8, 0.72, 2.3), dd.front - Lc * 0.3)
            : mode === 3 ? new THREE.Vector3(0, clamp(dd.top * 0.45, 0.45, 1.4), dd.front - 0.45)
            : new THREE.Vector3(o.def.cls === 'F1' || o.def.id === 'mf1' ? 0 : o.def.ph.L > 3.5 ? 0.45 : 0.36, clamp(dd.top * 0.8, 0.85, 2.4), mz - 0.25 + (Lc - 4.6) * 0.15);
          const la = mode === 2 ? new THREE.Vector3(0, lp.y - 0.32, 14) : mode === 3 ? new THREE.Vector3(0, lp.y - 0.04, 12) : new THREE.Vector3(lp.x, lp.y - 0.11, 10);
          o.tilt.updateWorldMatrix(true, false);
          camPos.copy(lp.applyMatrix4(o.tilt.matrixWorld)); camLook.copy(la.applyMatrix4(o.tilt.matrixWorld));
          camPos.y += jy * 0.6;
          fovP = (mode === 3 ? 66 : mode === 2 ? 64 : 62) + (clamp(sp / 90, 0, 1) * 10 + bst * 6) * (calmOn() ? 0.35 : 1);
          camInit = false;
        }
        // free look (PC: right mouse held — or locked with `): orbit around the car at a fixed angle to its heading, blended in / out
        const want = (fl.on || fl.lock) && !spectate ? 1 : 0;
        const C0 = new THREE.Vector3(c.x, y + 0.85, -c.y);
        if (want && fl.need) {   // start from where the camera is now (no jump)
          const d = cam.position.clone().sub(C0), L0 = Math.max(0.5, d.length());
          fl.R = clamp(L0, 3.5, 40); fl.pitch = clamp(Math.asin(clamp(d.y / L0, -1, 1)), -0.05, 1.35);
          fl.yaw = H.wrapA(Math.atan2(-d.z, d.x) - c.h - PI); fl.need = false;
        }
        fl.k += (want - fl.k) * (1 - Math.exp(-dt * 9)); if (fl.k < 0.003 && !want) fl.k = 0;
        if (fl.k > 0) {
          const a = c.h + PI + fl.yaw, cp = Math.cos(fl.pitch);
          const P0 = C0.clone().add(new THREE.Vector3(Math.cos(a) * cp * fl.R, Math.sin(fl.pitch) * fl.R, -Math.sin(a) * cp * fl.R));
          const gy = roadY(c) + 0.3; if (P0.y < gy) P0.y = gy;
          camPos.lerp(P0, fl.k); camLook.lerp(C0, fl.k); fovP += (58 - fovP) * fl.k;
        }
        cam.position.copy(camPos); cam.lookAt(camLook);
        fov = fovP;
      }
      if (vw < vh) fov += 16;   // portrait: wider
      if (Math.abs(cam.fov - fov) > 0.05) { cam.fov = lerp(cam.fov, fov, Math.min(1, dt * 4)); cam.updateProjectionMatrix(); }
      // shadows follow the camera target
      if (sun) {
        const tg = new THREE.Vector3(c.x, y, -c.y).addScaledVector(fw, 14);
        if (sun.castShadow) {   // 빛이 차를 따라 미끄러지면 울타리 · 나무 · 관중석 그림자 가장자리가 프레임마다 자글거림 → 중심을 그림자 칸(범위 ÷ 해상도)에 맞춤
          sdR.set(sunDir.z, 0, -sunDir.x);   // (0,1,0) × sunDir
          if (sdR.lengthSq() > 1e-6) {
            sdR.normalize(); sdU.crossVectors(sunDir, sdR).normalize();
            const tex = (sun.shadow.camera.right - sun.shadow.camera.left) / sun.shadow.mapSize.x, a1 = tg.dot(sdR), a2 = tg.dot(sdU), a3 = tg.dot(sunDir);
            tg.set(0, 0, 0).addScaledVector(sdR, Math.round(a1 / tex) * tex).addScaledVector(sdU, Math.round(a2 / tex) * tex).addScaledVector(sunDir, Math.round(a3 / 4) * 4);
          }
        }
        sun.target.position.copy(tg); sun.position.copy(tg).addScaledVector(sunDir, 150);
      }
      if (nightLights.length) {   // the 4 lamps nearest the camera become real lights
        const all = lamps.map((l) => [l, l.p.distanceToSquared(cam.position)]).sort((a, b) => a[1] - b[1]), near = all.slice(0, nightLights.length);
        const cut = all[nightLights.length] ? all[nightLights.length][1] : 0;   // 다음 차례 등까지 거리²: 여기서 밝기 0 → 등이 바뀌는 순간 빛이 툭 꺼지고 켜지지 않음
        nightLights.forEach((pl, k) => { const l = near[k]; if (!l) { pl.intensity = 0; return; } pl.intensity = 260 * (cut ? clamp((cut - l[1]) / (cut * 0.3), 0, 1) : 1); pl.position.set(l[0].p.x, l[0].p.y + 9, l[0].p.z); });
      }
      speedLines(c, sp, bst, dt);
    }
    /* speed lines: a 2D overlay at high speed / boost / slipstream (fewer on 낮음) */
    const slN = TIER.id === 'low' ? 14 : TIER.id === 'mid' ? 26 : 36, SL = [];
    let slOn = false;
    function speedLines(c, sp, bst, dt) {
      const dft = clamp(((c.draft || 0) - 0.3) / 0.5, 0, 1), k = Math.max(clamp((sp - 52) / 30, 0, 1), bst * clamp((sp - 18) / 20, 0, 1), dft * 0.8 * clamp((sp - 25) / 15, 0, 1));
      const show = k > 0.02 && phase === 'race' && !calmOn();
      if (!show) { if (slOn) { slC.getContext('2d').clearRect(0, 0, slC.width, slC.height); slOn = false; } return; }
      const w = Math.round(vw), hh = Math.round(vh);
      if (slC.width !== w || slC.height !== hh) { slC.width = w; slC.height = hh; }
      const g = slC.getContext('2d'); g.clearRect(0, 0, w, hh); slOn = true;
      const cx = w / 2, cy = hh * 0.45, R0 = Math.hypot(w, hh) / 2;
      while (SL.length < slN) SL.push({ a: Math.random() * PI * 2, r: 0.6 + Math.random() * 0.4, l: 0.04 + Math.random() * 0.07, s: 0.6 + Math.random() * 0.8 });
      const col = bst > 0.05 ? '255,214,140' : dft > 0.2 ? '170,228,255' : '235,240,255';
      g.lineCap = 'round';
      for (const L0 of SL) {
        L0.r += dt * L0.s * (1.2 + k * 2.2);
        if (L0.r > 1.05) { L0.a = Math.random() * PI * 2; L0.r = 0.6 + Math.random() * 0.2; L0.l = 0.04 + Math.random() * 0.07; }
        const ca = Math.cos(L0.a), sa = Math.sin(L0.a) * 0.75, r1 = L0.r * R0, r2 = (L0.r + L0.l * (0.6 + k)) * R0;
        const al = k * 0.3 * clamp((L0.r - 0.6) / 0.15, 0, 1);
        if (al < 0.01) continue;
        g.strokeStyle = 'rgba(' + col + ',' + al.toFixed(3) + ')'; g.lineWidth = 1 + k * 1.2;
        g.beginPath(); g.moveTo(cx + ca * r1, cy + sa * r1); g.lineTo(cx + ca * r2, cy + sa * r2); g.stroke();
      }
    }

    /* ======================= 고르기 화면 (docs/HYPERRACE.md 「고르기 화면」) =======================
       가로: 왼쪽 = 3D 미리보기(끌어서 돌리기 · 휠 / 두 손가락 확대) + 차 이름 · 한 줄 성격 · 능력치, 오른쪽 = 판(차 · 꾸미기 · 설정).
       세로: 위 = 미리보기, 아래 = 판. 「사진」 = 판을 모두 숨기고 카메라만 돌림. 차 카드 그림은 미리 구운 묶음(pk_thumbs). */
    let pickKey = null;   // PC shortcuts while 꾸미기 is open (set by openPick)
    let pickEl = null, pickInfo = null, pickStat = null, pickTools = null, myPick = null, pickSent = 0, pbar = null, pkForce = false, pickDraw = null, photo = false;
    const remPick = {};
    const pv = { yaw: 0.7, pitch: 0.2, zoom: 1, idle: 9, ptr: new Map(), pd: 0, lock: false, ty: null, tp: 0, pre: -1, wAcc: 0, hvT: 0 };   // preview camera: auto-turns when left alone for 3 s
    const recent = (() => { try { const v = JSON.parse(H.store.get('recent', '[]')); return Array.isArray(v) ? v.filter((x) => /^#[0-9a-f]{6}$/.test(x)).slice(0, 8) : []; } catch (e) { return []; } })();
    const pushRecent = (c) => { if (!/^#[0-9a-f]{6}$/i.test(c || '')) return; c = c.toLowerCase(); const i = recent.indexOf(c); if (i >= 0) recent.splice(i, 1); recent.unshift(c); if (recent.length > 8) recent.length = 8; H.store.set('recent', JSON.stringify(recent)); };
    // preview camera input on the 3D view (picking only): drag = turn / tilt, wheel or two fingers = zoom
    // PC: right button held = turn the car even while a sticker is selected (left = place / move it), Tab = set views (앞 · 옆 · 뒤 · 위 · 3/4), ` = stop the auto-turn
    const cv3 = R.domElement, pvOn = () => phase === 'pick' && !W && !!(pickEl || photo);
    const pvIdle = () => (pv.lock || (pv.dec && pv.dec.on()) ? -1e9 : 0);   // placing decals / locked: the car stays still
    const PVP = [['앞', 0, 0.12], ['오른쪽 옆', -PI / 2, 0.08], ['뒤', PI, 0.14], ['위', -PI / 2, 1.42], ['3/4', 0.7, 0.22]];
    function pvPreset(d) { pv.pre = (pv.pre + d + PVP.length) % PVP.length; const q = PVP[pv.pre]; pv.ty = q[1]; pv.tp = q[2]; pv.idle = -1e9; note('보기: ' + q[0]); }
    cv3.addEventListener('contextmenu', (e) => e.preventDefault());
    cv3.addEventListener('pointerdown', (e) => {
      if (!pvOn()) {   // racing (PC): right button held = free look around the car
        if (W && e.button === 2 && e.pointerType === 'mouse') { e.preventDefault(); fl.on = true; fl.need = !fl.lock; fl.ptr = e.pointerId; fl.x = e.clientX; fl.y = e.clientY; try { cv3.setPointerCapture(e.pointerId); } catch (x) {} }
        return;
      }
      const p = { x: e.clientX, y: e.clientY, x0: e.clientX, y0: e.clientY, t0: performance.now(), dec: false, multi: pv.ptr.size > 0, rmb: e.button === 2, sel: false };
      pv.ptr.set(e.pointerId, p); pv.ty = null; pv.idle = pvIdle(); pv.pd = 0; try { cv3.setPointerCapture(e.pointerId); } catch (x) {}
      if (!p.multi && !p.rmb && pv.eye) { p.eye = true; return; }   // eyedropper: the next tap on the car picks its colour
      if (!p.multi && !p.rmb && pv.dec && pv.dec.edit()) {
        if (e.pointerType === 'mouse' && !pv.dec.drawing()) { const hv = pv.dec.hover(e.clientX, e.clientY); if (hv >= 0 && hv !== pv.dec.selI()) { pv.dec.select(hv); p.sel = true; } }   // click another sticker on the car = select it
        if (pv.dec.on() && pv.dec.down(e.clientX, e.clientY)) p.dec = true;   // 꾸미기: the selected layer grabbed → move it (or a brush stroke)
      } else if (p.multi) {
        // a second finger while the first one holds a layer = pinch / twist that layer; otherwise two fingers = zoom
        const g = [...pv.ptr.values()].find((q) => q !== p && q.dec);
        if (g && pv.dec && pv.dec.busy && pv.dec.busy()) { g.pin = p.pin = true; p.mate = g; g.mate = p; pv.dec.pinchStart(Math.hypot(p.x - g.x, p.y - g.y), Math.atan2(p.y - g.y, p.x - g.x)); }
        else for (const q of pv.ptr.values()) { q.multi = true; if (q.dec) { q.dec = false; if (pv.dec) pv.dec.up(); } }
      }
    });
    cv3.addEventListener('pointermove', (e) => {
      if (fl.on && e.pointerId === fl.ptr) { fl.yaw -= (e.clientX - fl.x) * 0.0065; fl.pitch = clamp(fl.pitch + (e.clientY - fl.y) * 0.005, -0.05, 1.35); fl.x = e.clientX; fl.y = e.clientY; return; }
      const p = pv.ptr.get(e.pointerId);
      if (!p) {   // mouse hover (꾸미기 · 무늬): the sticker under the pointer gets a light frame
        if (e.pointerType === 'mouse' && pvOn() && pv.dec && pv.dec.edit() && performance.now() - pv.hvT > 45) { pv.hvT = performance.now(); pv.dec.hover(e.clientX, e.clientY); }
        return;
      }
      if (!pvOn()) return;
      if (p.pin) { p.x = e.clientX; p.y = e.clientY; const g = p.mate; if (g && pv.dec) { const a = p.dec ? p : g, b = p.dec ? g : p; pv.dec.pinch(Math.hypot(b.x - a.x, b.y - a.y), Math.atan2(b.y - a.y, b.x - a.x)); } pv.idle = pvIdle(); return; }
      if (p.dec) { if (pv.dec) pv.dec.move(e.clientX, e.clientY, e); p.x = e.clientX; p.y = e.clientY; pv.idle = pvIdle(); return; }
      if (pv.ptr.size === 1) { pv.yaw -= (e.clientX - p.x) * 0.011; pv.pitch = clamp(pv.pitch + (e.clientY - p.y) * 0.006, 0.02, 1.45); }
      p.x = e.clientX; p.y = e.clientY;
      if (pv.ptr.size === 2) { const [a, b] = [...pv.ptr.values()], d = Math.hypot(a.x - b.x, a.y - b.y); if (pv.pd) pv.zoom = clamp(pv.zoom * pv.pd / Math.max(1, d), 0.45, 1.8); pv.pd = d; }
      pv.idle = pvIdle();
    });
    const pvUp = (e) => {
      if (fl.on && e.pointerId === fl.ptr) { fl.on = false; fl.ptr = -1; return; }
      const p = pv.ptr.get(e.pointerId); pv.ptr.delete(e.pointerId); pv.pd = 0;
      if (!p || !pv.dec) return;
      if (p.eye) { if (e.type === 'pointerup' && Math.hypot(e.clientX - p.x0, e.clientY - p.y0) < 12 && pv.eye) { const c = pv.dec.colorAt(e.clientX, e.clientY); if (c) { pv.eye(c); pv.eye = null; } } return; }
      if (p.pin) { const g = p.mate; if (g) { g.pin = false; g.mate = null; if (g.dec) { g.dec = false; pv.dec.up(); } } if (p.dec) pv.dec.up(); return; }
      if (p.dec) pv.dec.up();
      else if (e.type === 'pointerup' && !p.multi && !p.rmb && !p.sel && Math.hypot(e.clientX - p.x0, e.clientY - p.y0) < 9 && performance.now() - p.t0 < 1000 && pv.dec.on()) pv.dec.tap(e.clientX, e.clientY);   // short tap = put it here
    };
    /* the preview car under a screen point → car-space point + normal (for decals) */
    const pvRay = new THREE.Raycaster();
    function pvHit(x, y) {
      const po = previewObj; if (!po || !po.model) return null;
      const r = cv3.getBoundingClientRect(), nd = new THREE.Vector2(((x - r.left) / r.width) * 2 - 1, -((y - r.top) / r.height) * 2 + 1);
      cam.updateMatrixWorld(); pvRay.setFromCamera(nd, cam);
      const hit = pvRay.intersectObject(po.model, true).find((q) => q.face && q.object.visible && q.object.isMesh);
      if (!hit || (hit.object.material && hit.object.material.userData.role === 'glass')) return null;   // windows: no decal there
      po.tilt.updateWorldMatrix(true, false);
      const inv = po.tilt.matrixWorld.clone().invert(), P = hit.point.clone().applyMatrix4(inv);
      const n = hit.face.normal.clone().transformDirection(hit.object.matrixWorld); if (n.dot(pvRay.ray.direction) > 0) n.negate();
      n.transformDirection(inv);
      return { P, N: n };
    }
    cv3.addEventListener('pointerup', pvUp); cv3.addEventListener('pointercancel', pvUp);
    cv3.addEventListener('wheel', (e) => {
      const dy = e.deltaMode === 1 ? e.deltaY * 33 : e.deltaY;
      if (pvOn()) {
        e.preventDefault();
        if (pv.dec && pv.dec.busy && pv.dec.busy()) {   // dragging a layer: wheel up = turn left (↺), down = turn right (↻), 5° a notch (Shift 1° · Ctrl 15° steps)
          if (Math.abs(dy) >= 40) pv.wAcc = Math.sign(dy) * 60; else pv.wAcc += dy;
          while (Math.abs(pv.wAcc) >= 60) { pv.dec.rot(Math.sign(pv.wAcc) * (e.shiftKey ? 1 : 5), e.ctrlKey || e.metaKey); pv.wAcc -= Math.sign(pv.wAcc) * 60; }
          return;
        }
        pv.zoom = clamp(pv.zoom * Math.exp(dy * 0.0012), 0.45, 1.8); pv.idle = pvIdle();
        return;
      }
      if (W && (fl.on || fl.lock)) { e.preventDefault(); fl.R = clamp(fl.R * Math.exp(dy * 0.0012), 3.5, 40); }   // free look: wheel = distance
    }, { passive: false });
    function setPhoto(on) {
      photo = on;
      for (const el of [pickEl, pickInfo, pickStat]) if (el) el.style.display = on ? 'none' : '';
      if (pickTools) { pickTools.querySelector('.hr-ph1').style.display = on ? 'none' : ''; pickTools.querySelector('.hr-ph2').style.display = on ? '' : 'none'; }
      if (pbar && pbar.el) pbar.el.style.display = on ? 'none' : '';
      pv.idle = 9; layoutPick();
    }
    function openPick() {
      if (pickEl) return;
      const s = mySeat();
      if (s < 0 || !isHumanHere(s)) return;
      const prev = (() => { try { return JSON.parse(H.store.get('last', 'null')); } catch (e) { return null; } })();
      const cm = st && H.CLS[st.cmix] ? st.cmix : null;
      let carId = prev && H.CAR[prev[0]] ? prev[0] : H.CARS[0].id;
      if (cm && H.CAR[carId].cls !== cm) carId = H.CARS.find((c) => c.cls === cm).id;   // the race class first
      const saved = (id) => { try { const v = JSON.parse(H.store.get('cust.' + id, 'null')); return v && typeof v === 'object' ? v : null; } catch (e) { return null; } };
      const cur = { car: carId, liv: 0, cust: {}, tab: 'car', sub: 'paint', cls: cm || 'all', sel: -1, tplK: -1, tplS: 0, ms: [], multi: false, draw: false, cmp: false, base: '', gzf: null, kg: null, kgFor: -1 };
      // undo / redo: snapshots of (livery, cust), up to 30 steps back; a new car starts a new history
      const hist = { a: [], i: -1 };
      const snap = () => JSON.stringify([cur.liv, H.custClean(cur.cust) || {}]);
      const commit = () => { const v = snap(); if (hist.a[hist.i] === v) return; hist.a.length = hist.i + 1; hist.a.push(v); if (hist.a.length > 31) hist.a.shift(); hist.i = hist.a.length - 1; };
      const undo = (d) => { const j = hist.i + d; if (j < 0 || j >= hist.a.length) return; hist.i = j; const v = JSON.parse(hist.a[j]); cur.liv = v[0]; cur.cust = v[1]; if (!cur.cust.L || cur.sel >= cur.cust.L.length) cur.sel = cur.cust.L ? cur.cust.L.length - 1 : -1; api.sfx('click'); draw(); };
      const loadCar = (id) => { const v = saved(id); cur.car = id; cur.liv = v ? clamp(v.liv | 0, 0, H.CAR[id].liv.length - 1) : 0; cur.cust = H.custClean(v && v.cust) || {}; cur.sel = cur.cust.L ? cur.cust.L.length - 1 : -1; cur.tplK = -1; cur.ms = []; cur.draw = false; cur.cmp = false; hist.a = []; hist.i = -1; cur.base = snap(); };
      const save = () => H.store.set('cust.' + cur.car, JSON.stringify({ liv: cur.liv, cust: H.custClean(cur.cust) || {} }));
      const presets = () => { try { const v = JSON.parse(H.store.get('pre.' + cur.car, '[]')); return Array.isArray(v) ? v : []; } catch (e) { return []; } };
      const NPRE = 10;
      loadCar(carId);
      const ST = H.carStats(), ranks = Object.keys(H.CLS).sort((a, b) => H.CLS[a].rk - H.CLS[b].rk), C = H.CUST;
      pickEl = h('div', { class: 'hr-pick' });
      pickInfo = h('div', { class: 'hr-pinfo' });
      pickStat = h('div', { class: 'hr-pstat' });
      pickTools = h('div', { class: 'hr-ptools' },
        h('button', { class: 'hr-sbtn hr-ph1', text: '사진 모드', onclick() { setPhoto(true); } }),
        h('div', { class: 'hr-ph2', style: { display: 'none' } }, h('button', { class: 'hr-sbtn', text: '돌아가기', onclick() { setPhoto(false); } }), h('span', { text: '끌어서 돌리기 · 휠 / 두 손가락으로 확대' })));
      let body = null, sheet = null;
      const bar = (lbl, v) => h('div', { class: 'hr-stat' }, h('span', { text: lbl }), h('i', null, h('s', { style: { width: Math.round(clamp(v, 0.04, 1) * 100) + '%' } })));
      const lbl = (t, extra) => h('div', { class: 'lbl' }, t, extra || null);
      const chips = (t, list, get, set, cls) => { const r = h('div', { class: 'row' + (cls ? ' ' + cls : '') }, t ? lbl(t) : null); list.forEach(([v, x]) => r.append(h('button', { class: 'hr-chip' + (get() === v ? ' sel' : ''), text: x, onclick() { set(v); draw(); } }))); return r; };
      const stepper = (t, get, set, lo, hi, show) => h('span', { class: 'hr-stp' }, h('span', { class: 'hr-stl', text: t }),
        h('button', { class: 'hr-chip hr-st', text: '−', onclick() { set(clamp(get() - 1, lo, hi)); draw(); } }), h('b', { class: 'hr-num', text: show ? show(get()) : String(get()) }),
        h('button', { class: 'hr-chip hr-st', text: '+', onclick() { set(clamp(get() + 1, lo, hi)); draw(); } }));
      /* colour: current swatch (opens the palette sheet) + recent colours, (+ 끔/원래) */
      const colorRow = (t, get, set, noneTxt) => {
        const r = h('div', { class: 'row' }, lbl(t));
        if (noneTxt) r.append(h('button', { class: 'hr-chip' + (!get() ? ' sel' : ''), text: noneTxt, onclick() { set(''); draw(); } }));
        r.append(h('button', { class: 'hr-sw hr-swc' + (get() ? ' sel' : ''), title: '색 고르기', style: { background: get() || 'conic-gradient(#f33,#ff3,#3f3,#3ff,#33f,#f3f,#f33)' }, onclick() { openSheet(t, get, set); } }));
        for (const c of recent.slice(0, 5)) if (c !== get()) r.append(h('button', { class: 'hr-sw', title: c, style: { background: c }, onclick() { set(c); pushRecent(c); draw(); } }));
        r.append(h('button', { class: 'hr-chip', text: '팔레트', onclick() { openSheet(t, get, set); } }));
        return r;
      };
      function openSheet(t, get, set) {
        closeSheet();
        const pick = (c) => { set(c); pushRecent(c); closeSheet(); draw(); };
        sheet = h('div', { class: 'hr-sheet' }, h('div', { class: 'hr-sh' }, h('b', { text: t }), h('button', { class: 'hr-chip', text: '닫기', onclick() { closeSheet(); } })));
        // 직접 고르기(v4): 채도 · 밝기 판 + 색상 띠 + #hex 칸 + 스포이트(차에서 색 가져오기)
        const c0 = /^#[0-9a-f]{6}$/i.test(get() || '') ? get() : '#ff4b2b', hsv = hexHsv(c0);
        const sv = h('canvas', { class: 'hr-sv', width: '240', height: '120' }), hue = h('input', { type: 'range', class: 'hr-hue', min: '0', max: '359', step: '1', value: String(Math.round(hsv[0])), 'aria-label': '색상' });
        const hx = h('input', { type: 'text', class: 'hr-in hr-hex', maxlength: '7', value: c0, 'aria-label': '색 코드(#RRGGBB)' }), sw = h('i', { class: 'hr-svw', style: { background: c0 } });
        const paintSV = () => { const cw = Math.round(sv.clientWidth || 0); if (cw > 20 && sv.width !== cw) sv.width = cw; const g = sv.getContext('2d'), W = sv.width, Hh = sv.height; g.fillStyle = 'hsl(' + hsv[0] + ',100%,50%)'; g.fillRect(0, 0, W, Hh);
          let gr = g.createLinearGradient(0, 0, W, 0); gr.addColorStop(0, '#fff'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, W, Hh);
          gr = g.createLinearGradient(0, 0, 0, Hh); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, '#000'); g.fillStyle = gr; g.fillRect(0, 0, W, Hh);
          const x = hsv[1] * W, y = (1 - hsv[2]) * Hh; g.lineWidth = 3; g.strokeStyle = '#000'; g.beginPath(); g.arc(x, y, 7, 0, 7); g.stroke(); g.lineWidth = 1.5; g.strokeStyle = '#fff'; g.stroke(); };
        let lpC = 0;
        const apply = (fin) => { const c = hsvHex(hsv); hx.value = c; sw.style.background = c; set(c); const n = performance.now(); if (fin) { pushRecent(c); commit(); } else if (n - lpC > 60) { lpC = n; previewCar(); } };
        let svP = null;
        const svAt = (e) => { const r = sv.getBoundingClientRect(); hsv[1] = clamp((e.clientX - r.left) / r.width, 0, 1); hsv[2] = clamp(1 - (e.clientY - r.top) / r.height, 0, 1); paintSV(); apply(false); };
        sv.addEventListener('pointerdown', (e) => { svP = e.pointerId; try { sv.setPointerCapture(e.pointerId); } catch (x) {} svAt(e); });
        sv.addEventListener('pointermove', (e) => { if (svP === e.pointerId) svAt(e); });
        const svUp = (e) => { if (svP !== e.pointerId) return; svP = null; apply(true); previewCar(); };
        sv.addEventListener('pointerup', svUp); sv.addEventListener('pointercancel', svUp);
        hue.addEventListener('input', () => { hsv[0] = +hue.value; paintSV(); apply(false); });
        hue.addEventListener('change', () => { apply(true); previewCar(); });
        hue.addEventListener('keydown', (e) => e.stopPropagation());
        hx.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') hx.blur(); });
        hx.addEventListener('change', () => { let v = hx.value.trim(); if (!v.startsWith('#')) v = '#' + v; if (/^#[0-9a-f]{3}$/i.test(v)) v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
          if (!/^#[0-9a-f]{6}$/i.test(v)) { hx.value = hsvHex(hsv); return; } const q = hexHsv(v.toLowerCase()); hsv[0] = q[0]; hsv[1] = q[1]; hsv[2] = q[2]; hue.value = String(Math.round(q[0])); paintSV(); apply(true); previewCar(); });
        paintSV();
        sheet.append(h('div', { class: 'lbl', text: '직접 고르기 — 판을 끌어 채도 · 밝기, 띠로 색상, 칸에 #코드' }), sv, h('div', { class: 'row hr-hrow' }, hue),
          h('div', { class: 'row' }, sw, hx, h('button', { class: 'hr-chip', text: '스포이트', title: '차를 눌러 그 자리 색 가져오기', onclick() {
            closeSheet(); pv.eye = (c) => { set(c); pushRecent(c); note('색 가져옴 ' + c); draw(); }; note('차를 누르면 그 자리 색을 가져와요'); } }),
            h('button', { class: 'hr-chip sel', text: '확인', onclick() { closeSheet(); draw(); } })));
        if (recent.length) sheet.append(h('div', { class: 'lbl', text: '최근 색' }), h('div', { class: 'hr-swg' }, ...recent.map((c) => h('button', { class: 'hr-sw' + (get() === c ? ' sel' : ''), style: { background: c }, onclick() { pick(c); } }))));
        for (const [nm, cols] of C.PAL) sheet.append(h('div', { class: 'lbl', text: nm }), h('div', { class: 'hr-swg' }, ...cols.map((c) => h('button', { class: 'hr-sw' + (get() === c ? ' sel' : ''), title: c, style: { background: c }, onclick() { pick(c); } }))));
        pickEl.append(sheet); requestAnimationFrame(paintSV);
      }
      function closeSheet() { if (sheet) { sheet.remove(); sheet = null; } }
      const swatches = (cu) => {   // a preset's colours at a glance
        const def = H.CAR[cur.car], cs = [cu.m === 1 && cu.c ? cu.c : (def.liv[cu._liv | 0] || def.liv[0])[1]];
        if (cu.tt && cu.tc) cs.push(cu.tc);
        if (cu.t2 && cu.t2c) cs.push(cu.t2c);
        for (const l of cu.L || []) cs.push(l[1]);
        return h('span', { class: 'hr-pre' }, ...cs.slice(0, 5).map((c) => h('i', { style: { background: c } })));
      };
      const posName = (t, o) => (t === 10 || t === 19 ? ['뒤 → 앞', '앞 → 뒤', '아래 → 위', '위 → 아래', '비스듬히'][o] : t === 13 || t === 30 ? ['뒤쪽 크게', '앞쪽 크게', '아래 크게', '위 크게', '비스듬히'][o]
        : t === 27 ? ['보닛', '보닛 + 지붕', '윗면', '윗면 + 옆 아래', '전체'][o] : t === 28 ? (o % 2 ? '뾰족 ' : '둥근 ') + (o + 1)
        : t === 12 ? ['묶음 1', '묶음 2', '묶음 3', '묶음 4', '묶음 5'][o] : t === 9 ? (o >= 3 ? '보닛 + 지붕' : '보닛') : t === 16 ? ['뒤쪽', '앞쪽', '아래', '위', '고르게'][o]
        : t === 18 ? ['아래', '뒤', '앞', '고르게', '위'][o] : t === 21 ? ['보닛', '보닛 + 지붕', '윗면', '윗면 + 옆 아래', '전체'][o] : String(o + 1));
      const posLbl = (t) => ({ 1: '간격', 2: '좌우', 3: '높이', 4: '앞뒤', 5: '길이', 6: '어긋남', 7: '높이', 8: '앞뒤', 9: '범위', 10: '방향', 11: '모양', 12: '이름', 13: '방향',
        14: '모양', 15: '높이', 16: '방향', 17: '높이', 18: '모이는 곳', 19: '방향', 20: '높이', 21: '범위', 22: '높이', 23: '높이',
        24: '모양', 25: '모양', 26: '채움', 27: '범위', 28: '모양', 29: '길이', 30: '방향', 31: '앞뒤', 32: '높이', 33: '점 크기', 34: '간격', 35: '촘촘함', 36: '촘촘함', 37: '양', 38: '양' })[t] || '위치';
      const lname = (l) => (l[0] >= C.SHP0 ? (l[0] === C.TXT_T ? '글자 「' + (l[10] || '') + '」' : l[0] >= C.LOGO0 && l[0] < C.SHP2 ? '로고 ' + C.LOGO[l[0] - C.LOGO0] : C.decName(l[0])) : C.PATS[l[0]]);
      // a layer with its short (cleaned) tail filled back in, for editing
      const expandL = (L0, i) => { const l = L0[i], d = l[0] >= C.SHP0 ? [0, '#f4f4f0', 0, 100, 100, 40, 0, 1, 100, '', ''] : [0, '#f4f4f0', 2, 2, '', 100];
        const hasX = l.length > 1 && l[l.length - 1] && typeof l[l.length - 1] === 'object' && !Array.isArray(l[l.length - 1]), X = hasX ? l.pop() : null;
        for (let k = l.length; k < d.length; k++) l.push(d[k]); if (X) l.push(X); return l; };
      // v4: a layer's extras object (made on first write) · set / clear one value
      const ext = (l) => { const q = l[l.length - 1]; if (q && typeof q === 'object' && !Array.isArray(q)) return q; const o = {}; l.push(o); return o; };
      const setX = (l, k, v, d) => { const o = ext(l); if (v == null || v === d || v === '') delete o[k]; else o[k] = v; };
      const isPat = (l) => !(l[0] >= C.SHP0);
      if (!cur.ms) cur.ms = [];
      // a slider row: live preview while dragging (light), saved + undo step on release
      let lpT = 0, lpTm = 0;
      const livePrev = () => { clearTimeout(lpTm); const n = performance.now(); if (n - lpT > 70) { lpT = n; previewCar(); } else lpTm = setTimeout(() => { lpT = performance.now(); previewCar(); }, 75); };
      const range = (t, get, set, lo, hi, step, fmt) => {
        const out = h('b', { class: 'hr-rv', text: fmt(get()) }), inp = h('input', { type: 'range', class: 'hr-rg', min: String(lo), max: String(hi), step: String(step), value: String(get()) });
        inp.addEventListener('input', () => { set(+inp.value); out.textContent = fmt(+inp.value); livePrev(); });
        inp.addEventListener('change', () => { set(+inp.value); draw(); });
        inp.addEventListener('keydown', (e) => e.stopPropagation());
        return h('div', { class: 'row hr-rr' }, h('span', { class: 'hr-stl', text: t }), inp, out);
      };
      const tog = (t, on, fn) => h('button', { class: 'hr-chip' + (on ? ' sel' : ''), text: t + (on ? ' 켬' : ' 끔'), onclick() { fn(); draw(); } });
      /* ---- 꾸미기 v4: 겹 목록 · 겹 편집 · 복사/붙여넣기 · 숫자 칸 ---- */
      const SVG_GRIP = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01" stroke="currentColor" stroke-width="3.2" stroke-linecap="round"/></svg>';
      const SVG_EYE = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>';
      const SVG_EYE0 = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" fill="none" stroke="currentColor" stroke-width="2" opacity=".45"/><path d="M4 4l16 16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>';
      const SVG_LOCK = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2" fill="currentColor"/><path d="M8 11V8a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2.2"/></svg>';
      const SVG_UNLOCK = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="2" opacity=".55"/><path d="M8 11V8a4 4 0 0 1 7.6-1.7" fill="none" stroke="currentColor" stroke-width="2" opacity=".55"/></svg>';
      const clipGet = (k) => { try { const v = JSON.parse(H.store.get(k, 'null')); return v && typeof v === 'object' ? v : null; } catch (e) { return null; } };
      const copyLayer = (l) => { H.store.set('clip', JSON.stringify({ l: H.layerClean(l) })); note('겹 복사 — 어느 차에서든 붙여 넣어요'); draw(); };
      const pasteLayer = () => {
        const v = clipGet('clip'), q = v && H.layerClean(v.l), L0 = cur.cust.L = cur.cust.L || [];
        if (!q) return; if (L0.length >= C.MAXL) { note('겹은 ' + C.MAXL + '장까지예요'); return; }
        L0.splice(cur.sel + 1 || L0.length, 0, q); cur.sel = L0.indexOf(q); cur.ms = []; api.sfx('click'); note('겹 붙여넣기'); draw();
      };
      const STY = ['f', 'g', 'm', 'd'];   // style = colours · opacity · finish · gradient · mask · shadow
      const copyStyle = (l) => { const X = xOf(l), dec = l[0] >= C.SHP0, o = { c: l[1], c2: dec ? l[9] : l[4], op: dec ? l[8] : l[5], X: {} }; for (const k of STY) if (X[k] != null) o.X[k] = X[k]; H.store.set('clipS', JSON.stringify(o)); note('스타일 복사(색 · 불투명 · 마감 · 그라데이션 · 그림자)'); draw(); };
      const pasteStyle = (l) => { const o = clipGet('clipS'); if (!o) return; const dec = l[0] >= C.SHP0; if (/^#[0-9a-f]{6}$/i.test(o.c || '')) l[1] = o.c;
        if (dec) { l[9] = o.c2 || ''; l[8] = clamp(o.op | 0 || 100, 10, 100); } else { if (C.PC2[l[0]]) l[4] = o.c2 || ''; l[5] = clamp(o.op | 0 || 100, 10, 100); }
        for (const k of STY) setX(l, k, o.X && o.X[k] != null ? o.X[k] : null); api.sfx('click'); draw(); };
      // multi-select from the list: Shift / Ctrl / Cmd (PC) or 「여러 개 고르기」 (touch)
      const pickRow = (i, e) => {
        if ((e && (e.shiftKey || e.ctrlKey || e.metaKey)) || cur.multi) {
          if (i === cur.sel) { if (cur.ms.length) cur.sel = cur.ms.shift(); }
          else if (cur.ms.includes(i)) cur.ms = cur.ms.filter((k) => k !== i);
          else if (cur.sel < 0) cur.sel = i; else cur.ms.push(i);
        } else { cur.sel = i; cur.ms = []; }
        cur.draw = false; hovI = -1; api.sfx('click'); draw();
      };
      const layerList = (L0, base) => {
        const n = L0.length, box = h('div', { class: 'hr-ll' });
        for (let d = 0; d < n; d++) {
          const i = n - 1 - d, l = expandL(L0, i), X = xOf(l), on = cur.sel === i, ms = cur.ms.includes(i);
          box.append(h('div', { class: 'hr-lr' + (on ? ' sel' : '') + (ms ? ' ms' : '') + (X.v ? ' hid' : '') },
            h('span', { class: 'hr-lg', title: '끌어서 순서 바꾸기', html: SVG_GRIP }),
            h('button', { class: 'hr-lb', title: lname(l), onclick(e) { pickRow(i, e); } }, h('img', { src: layerIcon(l, base, 28, 23), alt: '' }),
              h('span', { class: 'hr-ln' }, h('b', { text: X.n || lname(l) }), h('small', { text: (i + 1) + '번' + (X.n ? ' · ' + lname(l) : '') + (X.m ? ' · 마스크' : '') + (X.f ? ' · ' + C.LFIN[X.f] : '') }))),
            h('button', { class: 'hr-li' + (X.v ? '' : ' on'), title: X.v ? '보이기' : '숨기기(온라인에도 안 보냄)', 'aria-label': X.v ? '보이기' : '숨기기', html: X.v ? SVG_EYE0 : SVG_EYE, onclick() { setX(l, 'v', X.v ? 0 : 1, 0); hovI = -1; draw(); } }),
            h('button', { class: 'hr-li' + (X.l ? ' on' : ''), title: X.l ? '잠금 풀기' : '잠그기(차 위에서 안 움직임 · 무작위에도 남음)', 'aria-label': X.l ? '잠금 풀기' : '잠그기', html: X.l ? SVG_LOCK : SVG_UNLOCK, onclick() { setX(l, 'l', X.l ? 0 : 1, 0); draw(); } })));
        }
        // the grip: drag up / down to change the order
        let dg = null;
        box.addEventListener('pointerdown', (e) => {
          const gp = e.target.closest('.hr-lg'); if (!gp) return; e.preventDefault();
          const row = gp.parentElement, rows = [...box.children], from = rows.indexOf(row);
          dg = { row, rows, from, to: from, y0: e.clientY, rh: row.getBoundingClientRect().height + 4, id: e.pointerId };
          row.classList.add('drag'); try { box.setPointerCapture(e.pointerId); } catch (x) {}
        });
        box.addEventListener('pointermove', (e) => {
          if (!dg || e.pointerId !== dg.id) return;
          const dy = e.clientY - dg.y0; dg.row.style.transform = 'translateY(' + dy + 'px)'; dg.to = clamp(dg.from + Math.round(dy / dg.rh), 0, dg.rows.length - 1);
          dg.rows.forEach((r, k) => { r.classList.toggle('dropa', k === dg.to && dg.to < dg.from); r.classList.toggle('dropb', k === dg.to && dg.to > dg.from); });
        });
        const end = (e) => {
          if (!dg || e.pointerId !== dg.id) return; const q = dg; dg = null;
          if (q.to !== q.from) { const fi = n - 1 - q.from, ti = n - 1 - q.to, sel = L0[cur.sel], ms = cur.ms.map((k) => L0[k]); L0.splice(ti, 0, L0.splice(fi, 1)[0]); cur.sel = L0.indexOf(sel); cur.ms = ms.map((x) => L0.indexOf(x)).filter((k) => k >= 0); api.sfx('click'); }
          draw();
        };
        box.addEventListener('pointerup', end); box.addEventListener('pointercancel', end);
        return box;
      };
      // a small number field (PC-friendly, 44 px): live preview on input, one undo step on change
      const numIn = (t, get, set, lo, hi, unit) => {
        const i = h('input', { type: 'number', class: 'hr-nin', min: String(lo), max: String(hi), step: '1', value: String(Math.round(get())), 'aria-label': t });
        i.addEventListener('input', () => { const v = +i.value; if (isFinite(v) && i.value !== '') { set(clamp(Math.round(v), lo, hi)); livePrev(); } });
        i.addEventListener('change', () => draw());
        i.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') i.blur(); });
        return h('label', { class: 'hr-nf' }, h('span', { text: t }), i, unit ? h('i', { text: unit }) : null);
      };
      const KG = [['모양', C.SHP.map((_, k) => C.SHP0 + k)], ['모양 2', C.SHPB.map((_, k) => C.SHP2 + k)], ['글자 · 손그림', [C.TXT_T, C.BRUSH_T]], ['로고', C.LOGO.map((_, k) => C.LOGO0 + k)]];
      const kgOf = (t) => Math.max(0, KG.findIndex((g) => g[1].includes(t)));
      /* the editor of one layer: actions · kind · colours / gradient / finish / mask · free transform (numbers + on-car) · text / brush */
      const layerEditor = (l, i, L0, full, base) => {
        const dec = l[0] >= C.SHP0, X = xOf(l), box = h('div', { class: 'hr-layer' }), nL = L0.length;
        const nm = h('input', { type: 'text', class: 'hr-in hr-lname', maxlength: '12', placeholder: lname(l), value: X.n || '', 'aria-label': '겹 이름(이 기기에만)' });
        nm.addEventListener('input', () => setX(l, 'n', nm.value.trim().slice(0, 12), ''));
        nm.addEventListener('change', () => draw()); nm.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') nm.blur(); });
        box.append(h('div', { class: 'hr-lh' }, h('b', { text: (i + 1) + '.' }), nm),
          h('div', { class: 'row' },
            h('button', { class: 'hr-chip', text: '↓ 밑으로', disabled: i === 0, onclick() { L0.splice(i - 1, 0, L0.splice(i, 1)[0]); cur.sel = i - 1; cur.ms = []; draw(); } }),
            h('button', { class: 'hr-chip', text: '↑ 위로', disabled: i >= nL - 1, onclick() { L0.splice(i + 1, 0, L0.splice(i, 1)[0]); cur.sel = i + 1; cur.ms = []; draw(); } }),
            h('button', { class: 'hr-chip', text: '복제', disabled: full, onclick() { dupSel(); } }),
            h('button', { class: 'hr-chip', text: '복사', onclick() { copyLayer(l); } }),
            h('button', { class: 'hr-chip', text: '스타일 복사', onclick() { copyStyle(l); } }),
            clipGet('clipS') ? h('button', { class: 'hr-chip', text: '스타일 붙이기', onclick() { pasteStyle(l); } }) : null,
            h('button', { class: 'hr-chip', text: '지우기', onclick() { L0.splice(i, 1); cur.sel = Math.min(i, L0.length - 1); cur.ms = []; cur.draw = false; hovI = -1; draw(); } })));
        if (X.l) box.append(h('p', { class: 'hr-cdesc hr-hint', text: '잠긴 겹 — 차 위에서는 안 움직여요(목록의 자물쇠로 풀기). 아래 값은 바꿀 수 있어요.' }));
        // kind
        if (!dec) {
          const tr = h('div', { class: 'row hr-pats' });
          C.PATS.forEach((t0, t) => { if (t) tr.append(h('button', { class: 'hr-chip' + (l[0] === t ? ' sel' : ''), text: t0, onclick() { l[0] = t; if (!C.PC2[t]) l[4] = ''; draw(); } })); });
          box.append(tr);
        } else {
          if (cur.kg == null || !KG[cur.kg] || (cur.kgFor !== i)) { cur.kg = kgOf(l[0]); cur.kgFor = i; }
          const kinds = h('div', { class: 'hr-kinds' }), sample = (t) => [t, l[1], 0, 100, 100, 40, 0, 1, 100, l[9], t === C.TXT_T ? (l[0] === C.TXT_T ? l[10] : '') || 'A' : '', t === C.BRUSH_T ? { p: 'AAgg.gAAg', b: 14 } : {}];
          box.append(h('div', { class: 'hr-seg hr-kg' }, ...KG.map(([t0], k) => h('button', { class: cur.kg === k ? 'sel' : '', text: t0, onclick() { cur.kg = k; draw(); } }))));
          for (const t of KG[cur.kg][1]) kinds.append(h('button', { class: 'hr-kd' + (t >= C.LOGO0 && t < C.SHP2 ? ' wide' : '') + (l[0] === t ? ' sel' : ''), title: C.decName(t),
            onclick() { if (t === C.TXT_T && !l[10]) l[10] = 'HR'; if (t === C.BRUSH_T && !X.p) { cur.draw = true; note('차 위에 그려요'); } l[0] = t; draw(); } },
            h('img', { src: layerIcon(sample(t), '#2a2433', t >= C.LOGO0 && t < C.SHP2 ? 47 : 23, 23), alt: '' })));
          box.append(kinds);
        }
        if (l[0] === C.TXT_T) {
          const ti = h('input', { type: 'text', class: 'hr-in', maxlength: '12', placeholder: '글자(12자)', value: l[10] || '' });
          ti.addEventListener('input', () => { l[10] = ti.value; livePrev(); });
          ti.addEventListener('change', () => draw());
          ti.addEventListener('keydown', (e) => e.stopPropagation());
          box.append(h('div', { class: 'row' }, lbl('글자 — 숫자 · 영문 · 한글 · 기호 몇 개, 12자'), ti),
            chips('글꼴', C.FONT.map((x, k) => [k, x]), () => X.o | 0, (v) => setX(l, 'o', v, 0)));
        }
        if (l[0] === C.BRUSH_T) {
          box.append(h('p', { class: 'hr-cdesc hr-hint', text: cur.draw ? '그리는 중 — 차 위를 끌면 획이 생겨요(한 겹에 여러 획). 빈 곳을 끌면 차가 돌아요. 다 그렸으면 「그리기 끝」.' : '「그리기」를 켜고 차 위를 끌어 그려요. 그린 뒤엔 스티커처럼 옮기고 · 돌리고 · 크기를 바꿔요.' }),
            h('div', { class: 'row' }, h('button', { class: 'hr-chip' + (cur.draw ? ' sel' : ''), text: cur.draw ? '그리기 끝' : '그리기', onclick() { cur.draw = !cur.draw; draw(); } }),
              X.p ? h('button', { class: 'hr-chip', text: '마지막 획 지우기', onclick() { const S = X.p.split('.'); S.pop(); if (S.length) setX(l, 'p', S.join('.')); else { L0.splice(i, 1); cur.sel = Math.min(i, L0.length - 1); cur.draw = false; } draw(); } }) : null),
            range('붓 굵기', () => X.b || 8, (v) => setX(l, 'b', v, 8), 1, 40, 1, (v) => v + '%'));
        }
        // colours · gradient · opacity · finish · mask · shadow
        const c2lbl = dec ? (l[0] >= C.LOGO0 && l[0] < C.SHP2 ? '둘째 색' : l[0] === C.SHP0 + 4 || l[0] === C.SHP0 + 16 ? '안쪽 색' : '테두리') : C.PC2[l[0]];
        box.append(colorRow('색', () => l[1], (v) => { l[1] = v || '#f4f4f0'; }));
        if (dec || C.PC2[l[0]]) box.append(colorRow(c2lbl, () => (dec ? l[9] : l[4]) || '', (v) => { if (dec) l[9] = v || ''; else l[4] = v || ''; }, '없음'));
        box.append(colorRow('그라데이션 끝 색', () => (X.g ? X.g[0] : ''), (v) => setX(l, 'g', v ? [v, X.g ? X.g[1] : 0] : null), '없음'));
        if (X.g) box.append(chips('그라데이션 방향', C.GRAD.map((x, k) => [k, x]), () => X.g[1] | 0, (v) => setX(l, 'g', [X.g[0], v])));
        box.append(range('불투명', () => (dec ? l[8] : l[5]), (v) => { if (dec) l[8] = v; else l[5] = v; }, 10, 100, 5, (v) => v + '%'),
          chips('겹 마감(이 겹만)', C.LFIN.map((x, k) => [k, x]), () => X.f | 0, (v) => setX(l, 'f', v, 0)),
          chips('마스크', C.MASK.map((x, k) => [k, x]), () => X.m | 0, (v) => setX(l, 'm', v, 0)),
          h('div', { class: 'row' }, tog('그림자', !!X.d, () => setX(l, 'd', X.d ? 0 : 1, 0))));
        if (X.m === 1 || X.m === 2) box.append(h('p', { class: 'hr-cdesc', text: i === 0 ? '맨 아래 겹이라 마스크로 쓸 아래 겹이 없어요.' : '바로 아래 겹(' + (i) + '번)의 모양으로 ' + (X.m === 1 ? '안쪽만' : '바깥만') + ' 보여요.' }));
        if (X.m === 3 && !cur.cust.tt && !cur.cust.t2) box.append(h('p', { class: 'hr-cdesc', text: '투톤이 없어요 — 도색에서 투톤을 고르면 그 안에만 보여요.' }));
        // free transform
        box.append(lbl('자유 변형 — ' + (PC && !showTouch() ? '차 위에서 끌기 · 금빛 손잡이(돌리기 · 크기 · 늘이기) · 끄는 중 휠 회전(Ctrl 15°)' : '차 위에서 끌기 · 두 손가락으로 크기 · 회전 · 금빛 손잡이')));
        if (dec) {
          box.append(chips('붙일 면', C.FACE.map((x, k) => [k, x]), () => l[2], (v) => { l[2] = v; }),
            h('div', { class: 'hr-nums' },
              numIn(l[2] <= 2 ? '앞뒤' : '좌우', () => (l[2] === 1 ? 200 - l[3] : l[3]) / 2, (v) => { l[3] = l[2] === 1 ? 200 - v * 2 : v * 2; }, 0, 100, '%'),
              numIn(l[2] === 2 ? '좌우' : '높이', () => (l[2] === 2 ? l[4] : 200 - l[4]) / 2, (v) => { l[4] = l[2] === 2 ? v * 2 : 200 - v * 2; }, 0, 100, '%'),
              numIn('각도', () => l[6], (v) => { l[6] = ((v % 360) + 360) % 360; }, -360, 360, '°'),
              numIn('크기', () => l[5], (v) => { l[5] = v; }, 4, 300, 'cm'),
              numIn('늘이기', () => X.w || 100, (v) => setX(l, 'w', v, 100), 20, 500, '%'),
              numIn('기울임', () => X.k || 0, (v) => setX(l, 'k', v, 0), -60, 60, '°')),
            range('크기', () => l[5], (v) => { l[5] = v; }, 5, 250, 1, (v) => v + 'cm'),
            range('회전', () => l[6], (v) => { l[6] = v; }, 0, 359, 1, (v) => v + '°'),
            h('div', { class: 'row' }, tog(l[2] <= 1 ? '양쪽 옆' : '좌우 대칭', l[7] & 1, () => { l[7] ^= 1; }), tog('뒤집기', l[7] & 2, () => { l[7] ^= 2; }),
              h('button', { class: 'hr-chip', text: '변형 초기화', onclick() { l[6] = 0; setX(l, 'w', null); setX(l, 'k', null); draw(); } })));
        } else {
          box.append(chips('범위', C.AREA.map((x, k) => [k, x]), () => X.a | 0, (v) => setX(l, 'a', v, 0)),
            h('div', { class: 'row' }, stepper('굵기', () => l[2], (v) => { l[2] = v; }, 0, 4, (v) => String(v + 1)), stepper(posLbl(l[0]), () => l[3], (v) => { l[3] = v; }, 0, 4, (v) => posName(l[0], v))),
            h('div', { class: 'hr-nums' },
              numIn('옮김 앞뒤', () => X.x || 0, (v) => setX(l, 'x', v, 0), -800, 800, 'cm'),
              numIn('옮김 위아래', () => X.y || 0, (v) => setX(l, 'y', v, 0), -800, 800, 'cm'),
              numIn('각도', () => X.r || 0, (v) => setX(l, 'r', ((v % 360) + 360) % 360, 0), -360, 360, '°'),
              numIn('가로', () => X.w || 100, (v) => setX(l, 'w', v, 100), 10, 400, '%'),
              numIn('세로', () => X.h || 100, (v) => setX(l, 'h', v, 100), 10, 400, '%'),
              numIn('기울임', () => X.k || 0, (v) => setX(l, 'k', v, 0), -60, 60, '°')),
            range('회전', () => X.r || 0, (v) => setX(l, 'r', v, 0), 0, 359, 1, (v) => v + '°'),
            h('div', { class: 'row' }, h('button', { class: 'hr-chip', text: '변형 초기화', onclick() { for (const k of ['x', 'y', 'r', 'w', 'h', 'k']) setX(l, k, null); draw(); } })));
        }
        return box;
      };
      /* 무작위 꾸미기 + 고정(도색 · 겹 · 번호 · 부품) — 잠근 겹은 언제나 남음 */
      const rlock = () => { try { const v = JSON.parse(H.store.get('rlock', '{}')); return v && typeof v === 'object' ? v : {}; } catch (e) { return {}; } };
      const randomize = () => {
        const def = H.CAR[cur.car], rl = rlock(), old = cur.cust, r = H.custRandom(Math.random, !!rl.p) || {};
        const o = Object.assign({}, r);
        const PK = ['m', 'c', 'f', 'fk', 'pc', 'pk', 'tt', 'tc', 't2', 't2c'], NK = ['n', 'ns', 'nc', 'nh', 'nf', 'pl', 'ps', 'tg'], RK = ['r', 'rf', 'k', 't', 'tw', 'u', 'hl'];
        const keep = (ks) => { for (const k of ks) { delete o[k]; if (old[k] != null) o[k] = old[k]; } };
        if (rl.p) keep(PK); else cur.liv = Math.floor(Math.random() * def.liv.length);
        if (rl.n) keep(NK);
        if (rl.r) keep(RK);
        const locked = (old.L || []).filter((l) => xOf(l).l);
        o.L = rl.l ? (old.L || []).slice() : locked.concat(r.L || []);
        if (!o.L.length) delete o.L;
        if (def.nocolor) delete o.m;
        cur.cust = H.custClean(o) || {}; cur.sel = cur.cust.L ? cur.cust.L.length - 1 : -1; cur.ms = []; cur.draw = false; api.sfx('click'); draw();
      };
      /* 나눔 코드: 지금 꾸미기 → 「HR4.…」 글자(복사) · 받은 코드 붙여 넣기 → 그대로 */
      const shareBox = () => {
        const box = h('div', { class: 'hr-layer' }), code = H.custCode(cur.liv, cur.cust);
        const out = h('input', { type: 'text', class: 'hr-in hr-code', readonly: 'readonly', value: code, 'aria-label': '나눔 코드' });
        out.addEventListener('focus', () => out.select()); out.addEventListener('keydown', (e) => e.stopPropagation());
        const inp = h('input', { type: 'text', class: 'hr-in hr-code', placeholder: 'HR4.… 코드를 붙여 넣기', 'aria-label': '받은 코드' });
        const use = () => { const v = H.custDecode(inp.value); if (!v) { note('코드를 읽지 못했어요'); return; } const def = H.CAR[cur.car]; cur.liv = clamp(v.liv, 0, def.liv.length - 1); cur.cust = v.cust || {}; if (def.nocolor) delete cur.cust.m; cur.sel = cur.cust.L ? cur.cust.L.length - 1 : -1; cur.ms = []; api.sfx('click'); note('코드 꾸미기를 입혔어요'); draw(); };
        inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') use(); });
        const copy = () => { out.select(); try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(code).then(() => note('코드 복사'), () => note('코드를 길게 눌러 복사해요')); return; } } catch (e) {} try { document.execCommand('copy'); note('코드 복사'); } catch (e) { note('코드를 길게 눌러 복사해요'); } };
        box.append(lbl('나눔 코드 — 다른 차 · 다른 사람과 같은 꾸미기(숨긴 겹 · 이름은 빠짐, ' + code.length + '자)'),
          h('div', { class: 'row' }, out, h('button', { class: 'hr-chip', text: '복사', onclick() { copy(); } })),
          h('div', { class: 'row' }, inp, h('button', { class: 'hr-chip', text: '입히기', onclick() { use(); } })));
        return box;
      };
      const dupSel = () => {
        const L0 = cur.cust.L || [], i = cur.sel; if (i < 0 || !L0[i] || L0.length >= C.MAXL) return;
        const c = JSON.parse(JSON.stringify(expandL(L0, i)));
        if (c[0] >= C.SHP0) { c[3] = clamp(c[3] + 12, 0, 200); c[4] = clamp(c[4] + 8, 0, 200); } else { const X = ext(c); X.x = (X.x | 0) + 25; }
        const Xc = xOf(c); if (Xc.n) Xc.n = Xc.n.slice(0, 10) + ' 2';
        L0.splice(i + 1, 0, c); cur.sel = i + 1; cur.ms = []; api.sfx('click'); draw();
      };
      const SVG_U = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M8 4 3 9l5 5M3 9h11a6 6 0 0 1 0 12h-4" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      const SVG_R = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M16 4l5 5-5 5M21 9H10a6 6 0 0 0 0 12h4" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
      /* ---- the info overlay (name · one-line character · stats) ---- */
      const drawInfo = () => {
        const def = H.CAR[cur.car], cs = H.CLS[def.cls], sv = ST[cur.car], p = def.ph;
        pickInfo.innerHTML = '';
        pickInfo.append(h('div', { class: 'hr-pn' }, h('span', { class: 'hr-cls', style: { background: cs.col }, text: cs.short }), h('b', { text: def.nm })),
          h('div', { class: 'hr-pt', text: def.tag }), h('div', { class: 'hr-pr', text: cs.nm + ' · ' + def.real }), h('div', { class: 'hr-pl', text: '' }));
        pickStat.innerHTML = '';
        pickStat.append(h('div', { class: 'hr-stats' }, bar('최고 속도', sv.top), bar('가속', sv.acc), bar('코너', sv.corner), bar('제동', sv.brake), bar('드리프트', sv.drift), bar('무게', sv.kg)),
          h('div', { class: 'hr-spec', text: H.kmh(p.vtop) + 'km/h · ' + def.spec.hp + ' · ' + def.spec.kg + ' · ' + (p.hover ? '떠서 달림' : p.awd ? '네 바퀴' : '뒷바퀴') }));
        pickStat.style.display = cur.tab === 'car' && !photo ? '' : 'none';
      };
      const card = (c) => {
        const cs = H.CLS[c.cls], th = THUMBS.url[c.id];
        return h('button', { class: 'hr-cc' + (cur.car === c.id ? ' sel' : ''), 'data-id': c.id, style: { '--c': cs.col }, onclick() { if (cur.car !== c.id) { closeSheet(); loadCar(c.id); previewCar(true); pv.idle = 9; draw(); } } },
          h('span', { class: 'hr-ci' }, th ? h('img', { src: th, alt: '', draggable: 'false' }) : h('em', { text: c.nm })),
          h('span', { class: 'hr-cls', style: { background: cs.col }, text: cs.short }),
          h('b', { text: c.nm }), h('small', { text: c.tag }));
      };
      const draw = (keepScroll) => {
        const sc = body && keepScroll !== false ? body.scrollTop : 0;
        closeSheet(); commit();
        { const v = hist.a[hist.i]; if (cur.cmp && cur.cmpAt != null && cur.cmpAt !== v) cur.cmp = false; cur.cmpAt = v; }   // an edit leaves 「처음과 비교」
        if (pv.dec && pv.dec.on()) pv.idle = -1e9; else if (pv.idle < 0) pv.idle = 0;
        pickEl.innerHTML = '';
        const def = H.CAR[cur.car];
        const seg = h('div', { class: 'hr-seg' }, ...[['car', '차'], ['paint', '꾸미기'], ['set', '설정']].map(([k, t]) => h('button', { class: cur.tab === k ? 'sel' : '', text: t, onclick() { if (cur.tab !== k) { cur.tab = k; draw(false); } } })));
        if (cur.tab === 'paint') seg.append(   // undo / redo (꾸미기)
          h('button', { class: 'hr-ur', title: '되돌리기', 'aria-label': '되돌리기', html: SVG_U, disabled: hist.i <= 0, onclick() { undo(-1); } }),
          h('button', { class: 'hr-ur', title: '다시 하기', 'aria-label': '다시 하기', html: SVG_R, disabled: hist.i >= hist.a.length - 1, onclick() { undo(1); } }));
        body = h('div', { class: 'hr-pb' });
        if (cur.tab === 'car') {
          const filt = h('div', { class: 'hr-tabs' }, h('button', { class: cur.cls === 'all' ? 'sel' : '', style: { '--c': '#d8d4cc' }, text: '전체 ' + H.CARS.length, onclick() { cur.cls = 'all'; draw(false); } }));
          for (const k of ranks) filt.append(h('button', { class: cur.cls === k ? 'sel' : '', style: { '--c': H.CLS[k].col }, text: H.CLS[k].nm + (cm === k ? ' ★' : ''), onclick() { cur.cls = k; draw(false); } }));
          const grid = h('div', { class: 'hr-grid' });
          for (const k of cur.cls === 'all' ? ranks : [cur.cls]) {
            const cars = H.CARS.filter((x) => x.cls === k);
            grid.append(h('div', { class: 'hr-gh', style: { '--c': H.CLS[k].col } }, h('b', { text: H.CLS[k].nm }), h('small', { text: cars.length + '대 · ' + H.CLS[k].desc })));
            for (const c of cars) grid.append(card(c));
          }
          body.append(filt, grid);
        } else if (cur.tab === 'paint') {
          const cu = cur.cust, roles = (previewObj && previewObj.def.id === cur.car && carTplRoles(cur.car)) || {};
          const rl = rlock();
          const act = h('div', { class: 'row hr-act' },
            h('button', { class: 'hr-chip', text: '무작위 꾸미기', onclick() { randomize(); } }),
            h('button', { class: 'hr-chip', text: '원래 도색', onclick() { const keep = (cur.cust.L || []).filter((l) => xOf(l).l); cur.liv = 0; cur.cust = keep.length ? { L: keep } : {}; cur.sel = keep.length - 1; cur.ms = []; draw(); } }),
            h('button', { class: 'hr-chip' + (cur.cmp ? ' sel' : ''), text: cur.cmp ? '지금 모습 보기' : '처음과 비교', title: 'PC: B', onclick() { cur.cmp = !cur.cmp; draw(); } }));
          const lockRow = h('div', { class: 'row hr-rl' }, h('span', { class: 'hr-stl', text: '무작위에서 고정' }),
            ...[['p', '도색'], ['l', '겹'], ['n', '번호'], ['r', '부품']].map(([k, t]) => h('button', { class: 'hr-chip' + (rl[k] ? ' sel' : ''), text: (rl[k] ? '🔒 ' : '') + t, onclick() { rl[k] = !rl[k]; H.store.set('rlock', JSON.stringify(rl)); draw(); } })));
          const shortScr = vh < 440;
          if (!shortScr) body.append(act, lockRow);
          body.append(h('div', { class: 'hr-seg hr-sub' }, ...[['paint', '도색'], ['pat', '무늬'], ['num', '번호'], ['part', '부품'], ['pre', '리버리']].map(([k, t]) => h('button', { class: cur.sub === k ? 'sel' : '', text: t, onclick() { cur.sub = k; draw(false); } }))));
          if (PC && !showTouch() && vh >= 440) body.append(h('p', { class: 'hr-cdesc hr-pckeys', text: cur.sub === 'pat'
            ? 'PC — 차 위 겹 누르기 = 고르기 · 끌기 = 옮기기(무늬도, Alt = 맞춤 끔) · 끄는 중 휠 = 회전(위 ↺ · 아래 ↻, Shift 1° · Ctrl 15°) · 금빛 손잡이 = 돌리기 · 크기 · 늘이기 · Q/E 회전 · [ ] 크기 · 방향키 옮기기 · Del 지우기 · Ctrl+D 복제 · Ctrl+C/V 복사 · 붙여넣기 · H 숨기기 · L 잠그기 · B 처음과 비교 · 목록 Shift/Ctrl 누르기 = 여러 개 · Ctrl+Z/Y · Tab 보기 · 우클릭 끌기 = 돌려 보기 · ` 저절로 돌기 멈춤'
            : 'PC — Ctrl+Z/Y 되돌리기/다시 · Tab 보기(앞 · 옆 · 뒤 · 위 · 3/4) · 끌기/우클릭 끌기 = 돌려 보기 · 휠 = 확대 · ` 저절로 돌기 멈춤' }));
          if (cur.sub === 'paint') {
            const sw = h('div', { class: 'row' }, lbl('기본 도색 — ' + (cu.m === 1 ? '직접 고른 색' : def.liv[cur.liv][0])));
            def.liv.forEach((l, i) => sw.append(h('button', { class: 'hr-sw' + (cu.m !== 1 && cur.liv === i ? ' sel' : ''), title: l[0], style: { background: l[1] }, onclick() { cur.liv = i; delete cu.m; delete cu.c; draw(); } })));
            body.append(sw);
            if (!def.nocolor) body.append(colorRow('직접 색', () => (cu.m === 1 ? cu.c : ''), (v) => { if (v) { cu.m = 1; cu.c = v; } else { delete cu.m; delete cu.c; } }));
            body.append(
              chips('마감', C.FIN.map((x, i) => [i, x]), () => cu.f | 0, (v) => { cu.f = v; }),
              chips('메탈 입자(반짝이)', [[0, '없음'], [1, '약'], [2, '중'], [3, '강']], () => cu.fk | 0, (v) => { cu.fk = v; }),
              colorRow('펄 색 변화(보는 각도에 따라)', () => cu.pc || '', (v) => { cu.pc = v; if (v && !cu.pk) cu.pk = 2; }, '없음'));
            if (cu.pc) body.append(chips('', [[1, '약하게'], [2, '보통'], [3, '강하게']], () => cu.pk | 0 || 2, (v) => { cu.pk = v; }));
            body.append(chips('투톤', C.TT.map((x, i) => [i, x]), () => cu.tt | 0, (v) => { cu.tt = v; if (v && !cu.tc) cu.tc = '#16161a'; }));
            if (cu.tt) {
              body.append(colorRow('투톤 색', () => cu.tc || '#16161a', (v) => { cu.tc = v || '#16161a'; }),
                chips('투톤 2(겹쳐서)', C.TT.map((x, i) => [i, x]), () => cu.t2 | 0, (v) => { cu.t2 = v; if (v && !cu.t2c) cu.t2c = '#f4f4f0'; }));
              if (cu.t2) body.append(colorRow('투톤 2 색', () => cu.t2c || '#f4f4f0', (v) => { cu.t2c = v || '#f4f4f0'; }));
            }
          } else if (cur.sub === 'pat') {
            const L0 = cu.L = cu.L || [], nL = L0.length, base = cu.m === 1 && cu.c ? cu.c : (def.liv[cur.liv] || def.liv[0])[1];
            if (cur.sel >= nL) cur.sel = nL - 1;
            cur.ms = cur.ms.filter((k) => k < nL && k !== cur.sel);
            const by = H.custBytes(H.custNet(cu) || {}), full = nL >= C.MAXL || by > C.MAXB - 70, con = lumOf(base) > 0.5 ? '#16161a' : '#f4f4f0';
            // the stack (top layer first): grip (drag = order) · picture · name · eye · lock
            body.append(h('div', { class: 'row hr-llh' }, lbl('겹 ' + nL + '/' + C.MAXL + ' · 위가 맨 위 · 용량 ' + Math.min(100, Math.round(by / C.MAXB * 100)) + '%'),
              showTouch() ? h('button', { class: 'hr-chip' + (cur.multi ? ' sel' : ''), text: cur.multi ? '여러 개 고르기 켬' : '여러 개 고르기', onclick() { cur.multi = !cur.multi; if (!cur.multi) cur.ms = []; draw(); } }) : null));
            if (nL) body.append(layerList(L0, base)); else body.append(h('p', { class: 'hr-cdesc', text: '아직 겹이 없어요 — 아래 단추로 더해요' }));
            const add = (l) => { if (L0.length >= C.MAXL) return; L0.splice(cur.sel + 1 || L0.length, 0, l); cur.sel = L0.indexOf(l); cur.ms = []; cur.draw = l[0] === C.BRUSH_T; api.sfx('click'); draw(); };
            const clipL = clipGet('clip');
            body.append(h('div', { class: 'row' },
              h('button', { class: 'hr-chip', text: '+ 무늬', disabled: full, onclick() { add([3, con, 2, 2, '', 100]); } }),
              h('button', { class: 'hr-chip', text: '+ 스티커', disabled: full, onclick() { add([C.SHP0 + 1, con, 0, 100, 90, 40, 0, 1, 100, '', '']); } }),
              h('button', { class: 'hr-chip', text: '+ 글자', disabled: full, onclick() { add([C.TXT_T, con, 0, 100, 90, 24, 0, 1, 100, '', 'HR']); } }),
              h('button', { class: 'hr-chip', text: '+ 로고', disabled: full, onclick() { add([C.LOGO0 + Math.floor(Math.random() * C.LOGO.length), con, 0, 100, 80, 20, 0, 1, 100, '', '']); } }),
              h('button', { class: 'hr-chip', text: '+ 손그림', disabled: full, onclick() { add([C.BRUSH_T, con, 0, 100, 100, 40, 0, 0, 100, '', '', { b: 8 }]); note('차 위에 손가락 · 마우스로 그려요'); } }),
              clipL ? h('button', { class: 'hr-chip', text: '붙여넣기', disabled: full, onclick() { pasteLayer(); } }) : null));
            if (full) body.append(h('p', { class: 'hr-cdesc', text: nL >= C.MAXL ? '겹은 ' + C.MAXL + '장까지예요.' : '용량이 거의 찼어요 — 글자 · 손그림을 줄이거나 겹을 지워 주세요.' }));
            if (cur.ms.length) body.append(h('div', { class: 'row hr-multi' }, h('b', { text: (cur.ms.length + 1) + '개 고름 — 차 위에서 끌면 함께 옮겨요 · 방향키 · Q/E · 휠도 함께' }),
              h('button', { class: 'hr-chip', text: '함께 지우기', onclick() { const del = new Set([cur.sel, ...cur.ms]); cur.cust.L = L0.filter((_, k) => !del.has(k)); cur.sel = cur.cust.L.length - 1; cur.ms = []; api.sfx('click'); draw(); } }),
              h('button', { class: 'hr-chip', text: '고르기 풀기', onclick() { cur.ms = []; draw(); } })));
            const l = cur.sel >= 0 && cur.sel < nL ? expandL(L0, cur.sel) : null;
            if (l) body.append(layerEditor(l, cur.sel, L0, full, base));
          } else if (cur.sub === 'num') {
            const nr = h('div', { class: 'row' }, lbl('경주 번호(양옆)'));
            nr.append(h('button', { class: 'hr-chip' + (!cu.n ? ' sel' : ''), text: '없음', onclick() { cu.n = 0; draw(); } }));
            for (const d of [-10, -1]) nr.append(h('button', { class: 'hr-chip hr-st', text: String(d).replace('-', '−'), onclick() { cu.n = clamp((cu.n || 1) + d, 1, 99); draw(); } }));
            nr.append(h('b', { class: 'hr-num', text: cu.n ? String(cu.n) : '-' }));
            for (const d of [1, 10]) nr.append(h('button', { class: 'hr-chip hr-st', text: '+' + d, onclick() { cu.n = clamp((cu.n || 0) + d, 1, 99); draw(); } }));
            body.append(nr);
            if (cu.n) body.append(chips('번호 모양', C.NS.map((x, i) => [i, x]), () => cu.ns | 0, (v) => { cu.ns = v; }),
              colorRow('번호 글자 색', () => cu.nc || '', (v) => { cu.nc = v; }, '기본'),
              chips('지붕에도', [[0, '끔'], [1, '켬']], () => cu.nh | 0, (v) => { cu.nh = v; }));
            if (cu.n || cu.pl) body.append(chips('번호 · 번호판 글꼴', C.FONT.map((x, i) => [i, x]), () => cu.nf | 0, (v) => { cu.nf = v; }));
            const tIn = (key, max, ph, up) => {
              const i = h('input', { type: 'text', class: 'hr-in', maxlength: String(max), placeholder: ph, value: cu[key] || '' });
              i.addEventListener('input', () => { cu[key] = up ? i.value.toUpperCase() : i.value; previewCar(); save(); });
              i.addEventListener('change', () => commit());
              i.addEventListener('keydown', (e) => e.stopPropagation());
              return i;
            };
            body.append(h('div', { class: 'row' }, lbl('번호판 글자(뒤, ' + 8 + '자)'), tIn('pl', 8, '예: HR 2026', true)));
            if (cu.pl) body.append(chips('번호판 바탕', C.PS.map((x, i) => [i, x]), () => cu.ps | 0, (v) => { cu.ps = v; }));
            body.append(h('div', { class: 'row' }, lbl('이름표(경주 중 차 위, 10자 — 비우면 내 이름)'), tIn('tg', 10, api.players[mySeat()] ? String(api.players[mySeat()].name || '') : '이름표')),
              chips('다른 차 이름표 보기 (이 기기)', [['1', '켬'], ['0', '끔']], () => (tagsOn() ? '1' : '0'), (v) => H.store.set('tags', v)));
          } else if (cur.sub === 'part') {
            if (roles.rim) body.append(colorRow('휠 색', () => cu.r || '', (v) => { cu.r = v; }, '원래'), chips('휠 마감', C.RF.map((x, i) => [i, x]), () => cu.rf | 0, (v) => { cu.rf = v; }));
            if (roles.caliper) body.append(colorRow('캘리퍼 색', () => cu.k || '', (v) => { cu.k = v; }, '원래'));
            if (roles.glass) body.append(chips('창 틴팅', [[0, '기본'], [1, '진하게'], [2, '아주 진하게']], () => cu.t | 0, (v) => { cu.t = v; }), colorRow('창 색(틴팅 빛깔)', () => cu.tw || '', (v) => { cu.tw = v; }, '기본'));
            if (roles.head) body.append(chips('전조등 색', C.HL.map((x, i) => [i, x]), () => cu.hl | 0, (v) => { cu.hl = v; }));
            body.append(colorRow('언더글로(차 밑 불빛)', () => cu.u || '', (v) => { cu.u = v; }, '끔'));
            if (!roles.rim || !roles.caliper) body.append(h('p', { class: 'hr-cdesc', text: '이 차 모델에 따로 없는 부품(' + [!roles.rim && '휠', !roles.caliper && '캘리퍼', !roles.glass && '창'].filter(Boolean).join(' · ') + ')은 바꿀 수 없어요.' }));
          } else {
            const P = presets(), tg = h('div', { class: 'hr-tpl' });
            body.append(lbl('리버리 템플릿 — 아무 차에나 · 다시 누르면 다른 색 · 번호와 부품은 그대로'));
            C.TPL.forEach(([nm, sch], k) => {
              const on = cur.tplK === k, cs = sch[on ? cur.tplS % sch.length : 0];
              tg.append(h('button', { class: 'hr-chip hr-tp' + (on ? ' sel' : ''), onclick() { cur.tplS = on ? cur.tplS + 1 : 0; cur.tplK = k; cur.cust = H.custTpl(cur.cust, k, cur.tplS); if (def.nocolor) delete cur.cust.m; cur.sel = cur.cust.L ? cur.cust.L.length - 1 : -1; api.sfx('click'); draw(); } },
                h('span', { class: 'hr-pre' }, ...cs.map((c) => h('i', { style: { background: c } }))), h('span', { text: nm })));
            });
            body.append(tg, lbl('내 프리셋'));
            body.append(h('p', { class: 'hr-cdesc', text: '이 차의 꾸미기를 ' + NPRE + '개까지 저장해 두고 바로 불러와요(이 기기). 나눔 코드는 맨 아래.' }));
            for (let i = 0; i < NPRE; i++) {
              const v = P[i];
              body.append(h('div', { class: 'row hr-prow' }, h('b', { class: 'hr-pnm', text: String(i + 1) }), v ? swatches(Object.assign({ _liv: v.liv }, v.cust || {})) : h('span', { class: 'muted hr-pre', text: '비어 있음' }),
                v ? h('button', { class: 'hr-chip sel', text: '불러오기', onclick() { cur.liv = clamp(v.liv | 0, 0, def.liv.length - 1); cur.cust = H.custClean(v.cust) || {}; cur.sel = cur.cust.L ? cur.cust.L.length - 1 : -1; api.sfx('click'); draw(); } }) : null,
                h('button', { class: 'hr-chip', text: v ? '덮어쓰기' : '지금 꾸미기 저장', onclick() { const Q = presets(); while (Q.length < NPRE) Q.push(null); Q[i] = { liv: cur.liv, cust: H.custClean(cur.cust) || {} }; H.store.set('pre.' + cur.car, JSON.stringify(Q)); note('프리셋 ' + (i + 1) + ' 저장'); draw(); } }),
                v ? h('button', { class: 'hr-chip', text: '지우기', onclick() { const Q = presets(); Q[i] = null; H.store.set('pre.' + cur.car, JSON.stringify(Q)); draw(); } }) : null));
            }
          }
          if (cur.sub === 'pre') body.append(shareBox());
          if (shortScr) body.append(act, lockRow);
          body.append(h('p', { class: 'hr-cdesc', text: '모두 처음부터 · 차마다 이 기기에 저장 · 온라인 상대에게도 보여요' }));
        } else {
          if (T) { const tc = document.createElement('canvas'); tc.width = tc.height = 236; if (mapImg) tc.getContext('2d').drawImage(mapImg, 0, 0); tc.className = 'hr-trkc'; body.append(h('div', { class: 'row hr-trkr' }, tc, h('div', null, h('b', { text: T.nm }), h('div', { class: 'hr-cdesc', text: trackInfo(T) }), h('div', { class: 'hr-cdesc', text: trackFeat(T) })))); }
          body.append(
            chips('주행 보조 (이 기기)', [[2, '켬'], [1, '일부'], [0, '끔']], () => assist, (v) => { assist = v; H.store.set('assist', String(v)); }),
            chips('주행선 안내 — 초록 그대로 · 노랑 곧 감속 · 빨강 브레이크', [['1', '켬'], ['0', '끔']], () => (guideOn() ? '1' : '0'), (v) => H.store.set('guide', v)),
            showTouch() ? chips('자동 가속', [[true, '켬'], [false, '끔']], () => autoGas, (v) => { autoGas = v; H.store.set('auto', v ? '1' : '0'); layout(); }) : h('span'),
            showTouch() ? chips('핸들 (폰) — 버튼: ◀ ▶ 누르기 · 끌기: 왼쪽 칸을 좌우로 끄는 만큼', [['btn', '버튼'], ['drag', '끌기']], () => tStyle, (v) => { tStyle = v; H.store.set('tsteer', v); sPtr.clear(); steerUpdate(); layout(); }) : h('span'),
            showTouch() ? chips('단추 크기', [[0, '작게'], [1, '보통'], [2, '크게']], () => tSize, (v) => { tSize = v; H.store.set('tsize', String(v)); layout(); }) : h('span'),
            showTouch() ? chips('핸들 위치', [[false, '왼쪽'], [true, '오른쪽']], () => tSwap, (v) => { tSwap = v; H.store.set('tswap', v ? '1' : '0'); layout(); }) : h('span'),
            chips('그래픽 품질 (이 기기)', H.TIERS.map((t) => [t.id, t.nm]), () => H.gfxTier(), (v) => { H.store.set('gfx', v); if (v !== tierId) note('다음 판부터 바뀌어요'); }),
            chips('편한 화면 — 흔들림 · 시야 넓어짐 · 속도선 줄이기 (멀미 덜함)', [['1', '켬'], ['0', '끔']], () => (calmOn() ? '1' : '0'), (v) => H.store.set('calm', v)),
            chips('다른 차 이름표 (이 기기)', [['1', '켬'], ['0', '끔']], () => (tagsOn() ? '1' : '0'), (v) => H.store.set('tags', v)),
            (() => {   // car markings (this device): sponsor logos / stickers, brand lettering / emblems
              const r = h('div', { class: 'row' }, lbl('차 표식 (이 기기)')), bp = brandPref(H);
              for (const [k, nm] of [['logo', '스폰서 로고'], ['badge', '상표 글자 · 엠블럼']]) r.append(h('button', { class: 'hr-chip' + (bp[k] ? ' sel' : ''), text: nm + (bp[k] ? ' 켬' : ' 끔'), onclick() { H.store.set(k, bp[k] ? '0' : '1'); previewCar(true); draw(); } }));
              return r;
            })());
        }
        const ready = h('button', { class: 'btn primary hr-ready', text: '준비 완료', onclick() { save(); myPick = [cur.car, cur.liv, H.custNet(cur.cust)]; H.store.set('last', JSON.stringify([cur.car, cur.liv])); api.sfx('click'); api.buzz(12, 'ui'); closePick(); sendPick(); } });
        pickEl.append(seg, body, ready);
        if (keepScroll !== false) body.scrollTop = sc;
        drawInfo();
        save(); previewCar();
      };
      let hovI = -1;   // PC: the layer under the mouse (a light frame on the car)
      const previewCar = (rebuild) => {
        let cu = H.custClean(cur.cust) || {};
        if (cur.cmp && cur.base) { const v = JSON.parse(cur.base); pendingPreview = [cur.car, v[0], H.custClean(v[1]) || {}, !!rebuild]; return; }   // 처음과 비교
        if (cur.tab === 'paint' && cur.sub === 'pat' && cu.L && cu.L[cur.sel] && cu.L[cur.sel][0] >= C.SHP0) cu._sel = cur.sel;   // dashed frame (preview only)
        if (cur.tab === 'paint' && cur.sub === 'pat' && hovI >= 0 && hovI !== cur.sel && cu.L && cu.L[hovI] && cu.L[hovI][0] >= C.SHP0) cu._hov = hovI;
        pendingPreview = [cur.car, cur.liv, cu, !!rebuild || !!(pendingPreview && pendingPreview[3] && pendingPreview[0] === cur.car)];
      };
      /* 3D 미리보기에서 겹 다루기(v4 — 무늬도 스티커처럼):
         짧게 누름 = 고른 스티커를 그 자리로 · 고른 겹(무늬 · 스티커 · 손그림) 위에서 끌기 = 옮기기(스티커는 끄는 대로 다른 면으로도) · 나머지는 돌려 보기
         두 손가락(첫 손가락이 겹을 잡았을 때) = 크기 · 회전 · 금빛 손잡이(돌리기 · 크기 · 늘이기) · 「그리기」 중엔 끌기 = 붓
         PC: 다른 스티커를 누르면 그 스티커를 고름 · 끄는 중 휠 = 회전(Ctrl 15°) · 단축키(pickKey) · 여러 개 고르면 함께 옮김 · 돌림 */
      const selL = () => { const L0 = cur.cust.L; return L0 && cur.sel >= 0 && L0[cur.sel] ? expandL(L0, cur.sel) : null; };
      const selDec = () => { const l = selL(); return l && l[0] >= C.SHP0 ? l : null; };
      const free = (l) => { const X = xOf(l); return !X.l && !X.v; };
      let grab = null, kbT = 0, snapNote = '';
      // is (hit) on sticker layer l (or its mirror copy)? → how it was grabbed
      const decTest = (l, hit) => {
        const D = previewObj.dims, fN = decalSpot(hit.P, hit.N, D)[0], f = l[2], m = l[7];
        let cp = '';
        if (fN !== f) { if ((m & 1) && f <= 1 && fN === 1 - f) cp = 'S'; else return null; }
        const s = decalSpot(hit.P, null, D, fN), ex = decalExt(D, f);
        let a = l[3], b = l[4];
        if (!cp && (m & 1) && f === 2 && Math.abs(s[2] - (200 - b)) < Math.abs(s[2] - b)) { b = 200 - b; cp = 'T'; }
        else if (!cp && (m & 1) && f >= 3 && Math.abs(s[1] - (200 - a)) < Math.abs(s[1] - a)) { a = 200 - a; cp = 'X'; }
        const sm = l[5] / 100, rr = Math.max(0.16, sm * Math.max(1, Math.min(decalW(l), 3)) * 0.62);
        if (Math.hypot((s[1] - a) / 200 * ex[0], (s[2] - b) / 200 * ex[1]) > rr) return null;
        return { cp, f: fN, da: s[1] - a, db: s[2] - b };
      };
      // is (face spot) on pattern layer l? — the layer alone baked small (cached), alpha around the spot
      const hitC = { key: '', g: null, W: 256 };
      const patTest = (l, sp) => {
        const D = previewObj.dims, l1 = JSON.parse(JSON.stringify(l)), X1 = ext(l1); delete X1.m; delete X1.v; delete X1.g; delete X1.d;
        const key = JSON.stringify([l1, D.front, D.rear, D.top, D.half]), W = hitC.W, q = W / 4;
        if (hitC.key !== key) { if (!hitC.g) { const cv = document.createElement('canvas'); cv.width = cv.height = W; hitC.g = cv.getContext('2d', { willReadFrequently: true }); } bakeDecal(hitC.g, W, { L: [l1] }, D); hitC.key = key; }
        const u = sp[1] / 200, v = sp[2] / 200, f = sp[0];
        const px = f === 0 ? u * W : f === 1 ? W - u * W : f === 2 ? u * W : f === 3 ? u * W / 2 : W / 2 + u * W / 2, py = q * [0, 1, 2, 3, 3][f] + v * q;
        const x0 = clamp(Math.round(px) - 4, 0, W - 9), y0 = clamp(Math.round(py) - 4, 0, W - 9), d = hitC.g.getImageData(x0, y0, 9, 9).data;
        for (let k = 3; k < d.length; k += 4) if (d[k] > 40) return true;
        return false;
      };
      // move one layer by (du, dv) metres on face f (group moves): stickers in their face ratio, patterns by their offset
      const shiftL = (l, o, du, dv, f) => {
        if (l[0] >= C.SHP0) { const ex = decalExt(previewObj.dims, l[2]), sg = l[2] === f || f == null ? 1 : 1; l[3] = Math.round(clamp(o[0] + (du / ex[0]) * 200 * sg, 0, 200)); l[4] = Math.round(clamp(o[1] + (dv / ex[1]) * 200, 0, 200)); }
        else { setX(l, 'x', clamp(Math.round(o[0] + du * 100), -800, 800), 0); setX(l, 'y', clamp(Math.round(o[1] + dv * 100), -800, 800), 0); }
      };
      const posOf = (l) => (l[0] >= C.SHP0 ? [l[3], l[4]] : [xOf(l).x | 0, xOf(l).y | 0]);
      const others = () => { const L0 = cur.cust.L || []; return cur.ms.filter((k) => L0[k] && k !== cur.sel && free(L0[k])).map((k) => { const l = expandL(L0, k); return [l, posOf(l)]; }); };
      const later = () => { clearTimeout(kbT); kbT = setTimeout(() => { if (pickEl) draw(); }, 450); };   // keyboard edits: one undo step after a pause
      // which way a + angle turns on screen: the left side is seen mirrored (patterns), a mirror copy of a shape / a flipped sticker turns the other way
      const rotSign = (l, cp, f) => (l[0] >= C.SHP0 ? (cp && l[0] < C.TXT_T ? -1 : 1) * (l[7] & 2 ? -1 : 1) : (f === 1 ? -1 : 1));
      const rotL = (l, d, cp, f) => { if (l[0] >= C.SHP0) l[6] = ((((l[6] | 0) + d * rotSign(l, cp, f)) % 360) + 360) % 360; else setX(l, 'r', (((((xOf(l).r | 0) + d * rotSign(l, cp, f)) % 360) + 360) % 360), 0); };
      const angOf = (l) => (l[0] >= C.SHP0 ? l[6] | 0 : xOf(l).r | 0);
      // turn the selected layer(s) by d degrees as seen on screen (− = counter-clockwise); snap = to 15° steps
      const turn = (d, snap) => {
        const l = selL(); if (!l || !free(l)) return;
        const f = grab ? grab.f : gzFace(l);
        if (snap) { const a = angOf(l), sg = rotSign(l, grab && grab.cp, f), t = (Math.round(a / 15) + Math.sign(d) * sg) * 15; rotL(l, (((t - a) * sg) % 360), grab && grab.cp, f); }
        else rotL(l, d, grab && grab.cp, f);
        for (const [o] of others()) rotL(o, d, '', o[0] >= C.SHP0 ? o[2] : f);
        livePrev(); note('회전 ' + angOf(l) + '°');
      };
      // brush: strokes in metres on the layer's face while drawing → encoded into the layer (centre · size · 2 letters a point)
      const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
      const brushRaw = (l) => {   // decode the layer back to face metres (its current place · angle · size · flip)
        const D = previewObj.dims, ex = decalExt(D, l[2]), cx = (l[3] / 200) * ex[0], cy = (l[4] / 200) * ex[1], S = l[5] / 100, X = xOf(l), st = (X.w || 100) / 100;
        const r = ((l[6] | 0) * PI) / 180 + (l[2] === 2 ? PI / 2 : 0), cs = Math.cos(r), sn = Math.sin(r), fl = (l[7] & 2 ? -1 : 1) * (l[2] === 1 ? -1 : 1);
        return brushPts(X.p).map((s) => s.map(([x, y]) => { const lx = x * S * st * (l[7] & 2 ? -1 : 1), ly = y * S, fx = lx * cs - ly * sn, fy = lx * sn + ly * cs; return [cx + fx * (l[2] === 1 ? -1 : 1), cy + fy]; }));
      };
      const rdp = (pts, eps) => { if (pts.length < 3) return pts; let dm = 0, k = 0; const [a, b] = [pts[0], pts[pts.length - 1]], L1 = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1e-6;
        for (let i = 1; i < pts.length - 1; i++) { const d = Math.abs((b[0] - a[0]) * (a[1] - pts[i][1]) - (a[0] - pts[i][0]) * (b[1] - a[1])) / L1; if (d > dm) { dm = d; k = i; } }
        return dm > eps ? rdp(pts.slice(0, k + 1), eps).slice(0, -1).concat(rdp(pts.slice(k), eps)) : [a, b]; };
      const brushSet = (l, strokes) => {
        const D = previewObj.dims, f = l[2], ex = decalExt(D, f); let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        for (const s of strokes) for (const [x, y] of s) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
        const S = Math.max(x1 - x0, y1 - y0, 0.06) * 1.04, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, tq = f === 2 ? -PI / 2 : 0, cs = Math.cos(tq), sn = Math.sin(tq);
        let eps = 0.004, enc = '';
        for (let tries = 0; tries < 8; tries++, eps *= 1.6) {
          enc = strokes.map((s) => rdp(s, eps * S).map(([x, y]) => { const fx = (x - cx) * (f === 1 ? -1 : 1), fy = y - cy, lx = (fx * cs - fy * sn) / S, ly = (fx * sn + fy * cs) / S;
            return B64[Math.round(clamp(lx + 0.5, 0, 1) * 63)] + B64[Math.round(clamp(ly + 0.5, 0, 1) * 63)]; }).join('')).filter((q) => q.length).join('.');
          if (enc.length <= 600) break;
        }
        l[3] = Math.round(clamp((cx / ex[0]) * 200, 0, 200)); l[4] = Math.round(clamp((cy / ex[1]) * 200, 0, 200)); l[5] = Math.round(clamp(S * 100, 4, 300)); l[6] = 0; l[7] &= 1;
        const X = ext(l); X.p = enc.slice(0, 640).replace(/\.$/, ''); delete X.w; delete X.k;
      };
      pv.dec = {
        on: () => !photo && !!pickEl && cur.tab === 'paint' && cur.sub === 'pat' && !!selL() && free(selL()) && !!previewObj && previewObj.def.id === cur.car,
        edit: () => !photo && !!pickEl && cur.tab === 'paint' && cur.sub === 'pat' && !!previewObj && previewObj.def.id === cur.car,
        drawing: () => !!(cur.draw && selL() && selL()[0] === C.BRUSH_T),
        selI: () => cur.sel,
        select(i) { cur.sel = i; cur.ms = []; hovI = -1; cur.draw = false; api.sfx('click'); draw(); },
        hover(x, y) {
          const L0 = cur.cust.L || [], hit = pvHit(x, y); let hv = -1;
          if (hit) for (let i = L0.length - 1; i >= 0; i--) { if (!(L0[i][0] >= C.SHP0) || !free(L0[i])) continue; if (decTest(expandL(L0, i), hit)) { hv = i; break; } }
          if (hv < 0 && hit && selL() && !(selL()[0] >= C.SHP0) && free(selL()) && patTest(selL(), decalSpot(hit.P, hit.N, previewObj.dims))) hv = cur.sel;
          cv3.style.cursor = hv < 0 ? '' : hv === cur.sel ? 'grab' : 'pointer';
          if (hv !== hovI) { hovI = hv; previewCar(); }
          return hv;
        },
        down(x, y, force) {
          const l = selL(); if (!l || !free(l)) return false;
          const D = previewObj.dims, hit = pvHit(x, y);
          if (this.drawing()) {   // a new brush stroke (the first one picks the face)
            if (!hit) return false;
            const sp = decalSpot(hit.P, hit.N, D), X = xOf(l);
            if (!X.p) l[2] = sp[0];
            const s0 = decalSpot(hit.P, null, D, l[2]), ex = decalExt(D, l[2]);
            grab = { brush: true, f: l[2], raw: X.p ? brushRaw(l) : [], pts: [[(s0[1] / 200) * ex[0], (s0[2] / 200) * ex[1]]] };
            return true;
          }
          if (l[0] >= C.SHP0) {
            if (force) { grab = { cp: '', f: l[2], da: 0, db: 0, force: true }; }
            else { if (!hit) return false; const g = decTest(l, hit); if (!g) return false; grab = g; }
          } else {
            if (!hit) { if (!force) return false; grab = { pat: true, f: gzFace(l), u0: null, x0: xOf(l).x | 0, y0: xOf(l).y | 0 }; }
            else {
              const sp = decalSpot(hit.P, hit.N, D);
              if (!force && !patTest(l, sp)) return false;
              grab = { pat: true, f: sp[0], u0: sp[1], v0: sp[2], x0: xOf(l).x | 0, y0: xOf(l).y | 0 };
            }
          }
          grab.os = others(); grab.p0 = posOf(l); cur.gzf = grab.f;
          cv3.style.cursor = 'grabbing'; return true;
        },
        move(x, y, e) {
          const l = selL(), hit = grab && l && pvHit(x, y); if (!hit) return;
          const D = previewObj.dims, snap = !(e && e.altKey);
          if (grab.brush) {
            const s = decalSpot(hit.P, null, D, grab.f), ex = decalExt(D, grab.f), p = [(s[1] / 200) * ex[0], (s[2] / 200) * ex[1]], q = grab.pts[grab.pts.length - 1];
            if (Math.hypot(p[0] - q[0], p[1] - q[1]) > 0.012) { grab.pts.push(p); brushSet(l, grab.raw.concat([grab.pts])); livePrev(); }
            return;
          }
          let sn = '';
          if (grab.pat) {
            const s = decalSpot(hit.P, null, D, grab.f), ex = decalExt(D, grab.f);
            if (grab.u0 == null) { grab.u0 = s[1]; grab.v0 = s[2]; }
            const du = ((s[1] - grab.u0) / 200) * ex[0], dv = ((s[2] - grab.v0) / 200) * ex[1];
            let nx = Math.round(grab.x0 + du * 100), ny = Math.round(grab.y0 + dv * 100);
            if (snap && Math.abs(nx) < 4) { nx = 0; sn = '가운데 맞춤'; } if (snap && Math.abs(ny) < 4) { ny = 0; sn = '가운데 맞춤'; }
            setX(l, 'x', clamp(nx, -800, 800), 0); setX(l, 'y', clamp(ny, -800, 800), 0);
            for (const [o, p0] of grab.os) shiftL(o, p0, (nx - grab.x0) / 100, (ny - grab.y0) / 100, grab.f);
          } else {
            // a sticker can be carried over to another face (not its mirror copy, not with others)
            if (!grab.cp && !grab.os.length) { const fN = decalSpot(hit.P, hit.N, D)[0], N = hit.N, sv = fN <= 1 ? Math.abs(N.x) : fN === 2 ? N.y : Math.abs(N.z); if (fN !== l[2] && sv > 0.82) { l[2] = fN; grab.f = fN; grab.da = grab.db = 0; } }
            const s = decalSpot(hit.P, null, D, grab.f); let a = clamp(s[1] - grab.da, 0, 200), b = clamp(s[2] - grab.db, 0, 200);
            if (grab.cp === 'T') b = 200 - b; else if (grab.cp === 'X') a = 200 - a;
            if (snap) {   // centre line (top · front · back) and lines of the other stickers on this face
              const ax = l[2] >= 3 ? 'a' : l[2] === 2 ? 'b' : '';
              if (ax === 'a' && Math.abs(a - 100) < 3) { a = 100; sn = '가운데 맞춤'; } if (ax === 'b' && Math.abs(b - 100) < 3) { b = 100; sn = '가운데 맞춤'; }
              for (const o of cur.cust.L || []) if (o !== l && o[0] >= C.SHP0 && o[2] === l[2] && !xOf(o).v) { if (Math.abs(a - o[3]) < 2 && !sn) { a = o[3]; sn = '줄 맞춤'; } if (Math.abs(b - o[4]) < 2 && !sn) { b = o[4]; sn = '줄 맞춤'; } }
            }
            const ex = decalExt(D, l[2]), du = ((a - grab.p0[0]) / 200) * ex[0], dv = ((b - grab.p0[1]) / 200) * ex[1];
            l[3] = Math.round(a); l[4] = Math.round(b);
            for (const [o, p0] of grab.os) shiftL(o, p0, du, dv, l[2]);
          }
          if (sn && sn !== snapNote) note(sn + ' (Alt = 끔)'); snapNote = sn;
          livePrev();
        },
        rot: turn,
        busy: () => !!grab && !grab.brush,
        colorAt(x, y) {
          const po = previewObj, hit = po && pvHit(x, y); if (!hit) return null;
          const sp = decalSpot(hit.P, hit.N, po.dims), d = po.dec;
          if (d && d.on) { const W = d.W, q = W / 4, u = sp[1] / 200, v = sp[2] / 200, f = sp[0];
            const px = clamp(Math.round(f === 0 ? u * W : f === 1 ? W - u * W : f === 2 ? u * W : f === 3 ? (u * W) / 2 : W / 2 + (u * W) / 2), 0, W - 1), py = clamp(Math.round(q * [0, 1, 2, 3, 3][f] + v * q), 0, W - 1);
            try { const c = d.g.getImageData(px, py, 1, 1).data; if (c[3] > 128) return '#' + [c[0], c[1], c[2]].map((k) => k.toString(16).padStart(2, '0')).join(''); } catch (e) {} }
          const def = H.CAR[cur.car]; return cur.cust.m === 1 && cur.cust.c ? cur.cust.c : (def.liv[cur.liv] || def.liv[0])[1];
        },
        // two fingers on a grabbed layer: spread = size, twist = angle
        pinchStart(d, a) { const l = selL(); if (!l || !grab) return; grab.pz = { d, a, s: l[0] >= C.SHP0 ? l[5] : [xOf(l).w || 100, xOf(l).h || 100], r: angOf(l) }; },
        pinch(d, a) {
          const l = selL(); if (!l || !grab || !grab.pz) return; const z = grab.pz, k = d / Math.max(10, z.d), sg = rotSign(l, grab.cp, grab.f);
          if (l[0] >= C.SHP0) l[5] = Math.round(clamp(z.s * k, 4, 300)); else { setX(l, 'w', Math.round(clamp(z.s[0] * k, 10, 400)), 100); setX(l, 'h', Math.round(clamp(z.s[1] * k, 10, 400)), 100); }
          const r = Math.round(z.r + ((a - z.a) * 180 / PI) * sg); if (l[0] >= C.SHP0) l[6] = ((r % 360) + 360) % 360; else setX(l, 'r', ((r % 360) + 360) % 360, 0);
          livePrev();
        },
        up() {
          if (!grab) return; const g = grab; grab = null; cv3.style.cursor = 'grab'; snapNote = '';
          if (g.brush && g.pts.length) { const l = selL(); if (l) { brushSet(l, g.raw.concat([g.pts])); } }
          draw();
        },
        tap(x, y) {
          const l = selDec(), hit = l && free(l) && l[0] !== C.BRUSH_T && pvHit(x, y); if (!hit) return;
          const sp = decalSpot(hit.P, hit.N, previewObj.dims); l[2] = sp[0]; l[3] = sp[1]; l[4] = sp[2]; api.sfx('click'); api.buzz(8, 'ui'); draw();
        },
      };
      /* ---- 금빛 손잡이(gizmo): 고른 겹 가운데(●, 끌면 옮김) · 돌리기(↻) · 크기(⤡) · 늘이기(↔, 무늬는 ↕도) — PC · 폰 모두, 매 프레임 화면 자리만 다시 셈 ---- */
      const NRM = [[-1, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1], [0, 0, -1]];
      const facePt = (D, f, u, v) => { const Lm = D.front - D.rear, Hm = Math.max(0.5, D.top - D.bot), hx = D.half, Wm = 2 * hx, y = D.bot + Hm - v * Hm;
        return f === 0 ? new THREE.Vector3(-hx, y, D.rear + u * Lm) : f === 1 ? new THREE.Vector3(hx, y, D.rear + u * Lm) : f === 2 ? new THREE.Vector3(hx - v * Wm, D.top, D.rear + u * Lm) : f === 3 ? new THREE.Vector3(u * Wm - hx, y, D.front) : new THREE.Vector3(hx - u * Wm, y, D.rear); };
      // the face of a pattern the handles sit on: the last one touched if it is in the layer's area, else the one turned most to the camera
      function gzFace(l) {
        if (l[0] >= C.SHP0) return l[2];
        const am = [31, 3, 1, 2, 4, 8, 16, 7, 24][xOf(l).a | 0] || 31, po = previewObj;
        if (cur.gzf != null && (am & (1 << cur.gzf))) { const n = NRM[cur.gzf]; if (po && camDot(po, n) > 0.15) return cur.gzf; }
        let best = 0, bv = -9; for (let f = 0; f < 5; f++) if (am & (1 << f)) { const v = po ? camDot(po, NRM[f]) : 0; if (v > bv) { bv = v; best = f; } }
        return best;
      }
      function camDot(po, n) { po.tilt.updateWorldMatrix(true, false); const c = po.tilt.worldToLocal(cam.position.clone()).normalize(); return c.x * n[0] + c.y * n[1] + c.z * n[2]; }
      const gzRay = new THREE.Raycaster(); let gzKey = '', gzC = null;
      const gz = h('div', { class: 'hr-gz', style: { display: 'none' } });
      const gzK = {};
      for (const [k, t, tip] of [['c', '', '끌어서 옮기기'], ['r', '↻', '돌리기(Shift 15°)'], ['s', '⤡', '크기'], ['w', '↔', '가로 늘이기'], ['h', '↕', '세로 늘이기']]) { gzK[k] = h('button', { class: 'hr-gk hr-gk-' + k, title: tip, 'aria-label': tip, text: t }); gz.append(gzK[k]); }
      const gzLine = h('i', { class: 'hr-gl' }); gz.prepend(gzLine);
      wrap.append(gz); pv.gzEl = gz;
      let gzS = null;   // screen frame of the handles: centre · local right / up (unit) · radius
      pv.gz = () => {
        const l = selL(), po = previewObj;
        const show = !!(l && pickEl && !photo && cur.tab === 'paint' && cur.sub === 'pat' && free(l) && po && po.def.id === cur.car && !cur.cmp && !(cur.draw && l[0] === C.BRUSH_T) && phase === 'pick' && !W);
        if (!show) { if (gz.style.display !== 'none') gz.style.display = 'none'; gzS = null; return; }
        const D = po.dims, f = gzFace(l), ex = decalExt(D, f), X = xOf(l);
        let u, v, rot, sz;
        if (l[0] >= C.SHP0) { u = l[3] / 200; v = l[4] / 200; rot = ((l[6] | 0) * PI) / 180 + (f === 2 ? PI / 2 : 0); sz = (l[5] / 100) * 0.5; }
        else { u = 0.5 + (X.x | 0) / 100 / ex[0]; v = 0.5 + (X.y | 0) / 100 / ex[1]; rot = ((X.r | 0) * PI) / 180; sz = 0.3; }
        if (camDot(po, NRM[f]) < 0.08) { if (gz.style.display !== 'none') gz.style.display = 'none'; gzS = null; return; }   // the face is turned away
        // the surface point (a ray from outside, only when the layer moved)
        const key = [f, u.toFixed(3), v.toFixed(3), po.def.id].join('|');
        if (key !== gzKey) {
          gzKey = key; const P = facePt(D, f, clamp(u, 0, 1), clamp(v, 0, 1)), n = new THREE.Vector3(...NRM[f]);
          po.tilt.updateWorldMatrix(true, true);
          const o = po.tilt.localToWorld(P.clone().addScaledVector(n, 1.2)), dir = po.tilt.localToWorld(P.clone()).sub(o).normalize();
          gzRay.set(o, dir); const hit = gzRay.intersectObject(po.model, true).find((q) => q.object.visible && q.object.isMesh);
          gzC = hit ? po.tilt.worldToLocal(hit.point.clone()) : P;
        }
        const r = cv3.getBoundingClientRect(), wr = wrap.getBoundingClientRect();
        const scr = (p) => { const w = po.tilt.localToWorld(p.clone()).project(cam); return [r.left - wr.left + ((w.x + 1) / 2) * r.width, r.top - wr.top + ((1 - w.y) / 2) * r.height]; };
        const at = (du, dv) => { const P = facePt(D, f, u + du / ex[0], v + dv / ex[1]), P0 = facePt(D, f, u, v); return gzC.clone().add(P.sub(P0)); };
        const fl = l[0] >= C.SHP0 && f === 1 ? -1 : 1, cs = Math.cos(rot), sn = Math.sin(rot);
        const loc = (lx, ly) => { const fx = (lx * cs - ly * sn) * fl, fy = lx * sn + ly * cs; return scr(at(fx, fy)); };
        const C0 = scr(gzC), R1 = loc(sz, 0), U1 = loc(0, -sz);
        const nrm = (p) => { const dx = p[0] - C0[0], dy = p[1] - C0[1], d = Math.hypot(dx, dy) || 1; return [dx / d, dy / d, d]; };
        const ax = nrm(R1), up = nrm(U1), rad = clamp(Math.max(ax[2], up[2]) + 26, 58, 150);
        gzS = { C: C0, ax, up, rad, f };
        gz.style.display = '';
        const put = (el, x, y) => { el.style.transform = 'translate(' + (x - 22).toFixed(1) + 'px,' + (y - 22).toFixed(1) + 'px)'; };
        put(gzK.c, C0[0], C0[1]); put(gzK.r, C0[0] + up[0] * rad, C0[1] + up[1] * rad);
        const dg = [ax[0] - up[0], ax[1] - up[1]], dn = Math.hypot(dg[0], dg[1]) || 1; put(gzK.s, C0[0] + (dg[0] / dn) * rad * 0.85, C0[1] + (dg[1] / dn) * rad * 0.85);
        put(gzK.w, C0[0] + ax[0] * rad * 0.8, C0[1] + ax[1] * rad * 0.8);
        gzK.h.style.display = l[0] >= C.SHP0 ? 'none' : ''; if (l[0] < C.SHP0) put(gzK.h, C0[0] - up[0] * rad * 0.8, C0[1] - up[1] * rad * 0.8);
        const ang = Math.atan2(up[1], up[0]);
        Object.assign(gzLine.style, { width: rad.toFixed(1) + 'px', transform: 'translate(' + C0[0].toFixed(1) + 'px,' + C0[1].toFixed(1) + 'px) rotate(' + ang.toFixed(3) + 'rad)' });
      };
      // handle drags
      let gzD = null;
      gz.addEventListener('pointerdown', (e) => {
        const k = Object.keys(gzK).find((q) => gzK[q] === e.target); const l = selL(); if (!k || !l || !gzS) return;
        e.preventDefault(); e.stopPropagation(); try { e.target.setPointerCapture(e.pointerId); } catch (x) {}
        pv.idle = -1e9;
        if (k === 'c') { if (pv.dec.down(e.clientX, e.clientY, true)) gzD = { k, id: e.pointerId }; return; }
        const wr = wrap.getBoundingClientRect(), x = e.clientX - wr.left, y = e.clientY - wr.top, dx = x - gzS.C[0], dy = y - gzS.C[1], X = xOf(l);
        gzD = { k, id: e.pointerId, a0: Math.atan2(dy, dx), d0: Math.max(8, Math.hypot(dx, dy)), pw: Math.max(8, dx * gzS.ax[0] + dy * gzS.ax[1]), ph: Math.max(8, -(dx * gzS.up[0] + dy * gzS.up[1])),
          r0: angOf(l), s0: l[0] >= C.SHP0 ? l[5] : [X.w || 100, X.h || 100], w0: X.w || 100, h0: X.h || 100, S: gzS, f: gzS.f };
      });
      gz.addEventListener('pointermove', (e) => {
        if (!gzD || e.pointerId !== gzD.id) return; const l = selL(); if (!l) return;
        if (gzD.k === 'c') { pv.dec.move(e.clientX, e.clientY, e); return; }
        const wr = wrap.getBoundingClientRect(), x = e.clientX - wr.left, y = e.clientY - wr.top, S = gzD.S, dx = x - S.C[0], dy = y - S.C[1], dec = l[0] >= C.SHP0;
        if (gzD.k === 'r') {
          let r = gzD.r0 + ((Math.atan2(dy, dx) - gzD.a0) * 180 / PI) * rotSign(l, '', gzD.f);
          if (e.shiftKey) r = Math.round(r / 15) * 15; r = ((Math.round(r) % 360) + 360) % 360;
          if (dec) l[6] = r; else setX(l, 'r', r, 0); note('회전 ' + r + '°');
        } else if (gzD.k === 's') {
          const k = Math.hypot(dx, dy) / gzD.d0;
          if (dec) l[5] = Math.round(clamp(gzD.s0 * k, 4, 300)); else { setX(l, 'w', Math.round(clamp(gzD.s0[0] * k, 10, 400)), 100); setX(l, 'h', Math.round(clamp(gzD.s0[1] * k, 10, 400)), 100); }
        } else if (gzD.k === 'w') {
          const k = Math.max(0.05, (dx * S.ax[0] + dy * S.ax[1]) / gzD.pw);
          setX(l, 'w', Math.round(clamp(gzD.w0 * k, dec ? 20 : 10, dec ? 500 : 400)), 100);
        } else if (gzD.k === 'h') {
          const k = Math.max(0.05, -(dx * S.up[0] + dy * S.up[1]) / gzD.ph);
          setX(l, 'h', Math.round(clamp(gzD.h0 * k, 10, 400)), 100);
        }
        livePrev();
      });
      const gzUp = (e) => { if (!gzD || e.pointerId !== gzD.id) return; const k = gzD.k; gzD = null; if (k === 'c') pv.dec.up(); else draw(); };
      gz.addEventListener('pointerup', gzUp); gz.addEventListener('pointercancel', gzUp);
      gz.addEventListener('wheel', (e) => { e.preventDefault(); cv3.dispatchEvent(new WheelEvent('wheel', { deltaY: e.deltaY, deltaMode: e.deltaMode, shiftKey: e.shiftKey, ctrlKey: e.ctrlKey, altKey: e.altKey, cancelable: true })); }, { passive: false });
      /* PC shortcuts in 꾸미기: Ctrl+Z / Ctrl+Y(Ctrl+Shift+Z) 되돌리기 · 다시 / 무늬: Delete · Backspace 지우기 · Ctrl+D 복제 · Ctrl+C / Ctrl+V 겹 복사 · 붙여넣기
         · 방향키 옮기기(Shift 크게) · [ ] 크기 · Q E 회전(Shift 1° · Ctrl 15°) · H 숨기기 · L 잠그기 · B 처음과 비교 · Esc 여러 개 고르기 풀기 */
      pickKey = (e) => {
        if (cur.tab !== 'paint' || photo || sheet) return false;
        const k = e.code, ctrl = e.ctrlKey || e.metaKey;
        if (ctrl && k === 'KeyZ') { undo(e.shiftKey ? 1 : -1); return true; }
        if (ctrl && k === 'KeyY') { undo(1); return true; }
        if (!ctrl && !e.altKey && k === 'KeyB') { cur.cmp = !cur.cmp; note(cur.cmp ? '처음 모습(B = 돌아가기)' : '지금 모습'); draw(); return true; }
        if (cur.sub !== 'pat') return false;
        if (ctrl && k === 'KeyV') { pasteLayer(); return true; }
        const L0 = cur.cust.L || [], i = cur.sel, l = i >= 0 && i < L0.length ? expandL(L0, i) : null; if (!l) return false;
        const dec = l[0] >= C.SHP0;
        if (ctrl && k === 'KeyD') { dupSel(); return true; }
        if (ctrl && k === 'KeyC') { copyLayer(l); return true; }
        if (ctrl || e.altKey) return false;
        if (k === 'Escape' && cur.ms.length) { cur.ms = []; draw(); return true; }
        if (k === 'Delete' || k === 'Backspace') { const del = new Set([i, ...cur.ms]); cur.cust.L = L0.filter((_, q) => !del.has(q)); cur.sel = Math.min(i, cur.cust.L.length - 1); cur.ms = []; hovI = -1; api.sfx('click'); draw(); return true; }
        if (k === 'KeyH') { setX(l, 'v', xOf(l).v ? 0 : 1, 0); note(xOf(l).v ? '숨김' : '보임'); draw(); return true; }
        if (k === 'KeyL') { setX(l, 'l', xOf(l).l ? 0 : 1, 0); note(xOf(l).l ? '잠금' : '잠금 풀림'); draw(); return true; }
        if (!free(l)) return false;
        const st = e.shiftKey ? 6 : 1;
        if (k === 'ArrowLeft' || k === 'ArrowRight' || k === 'ArrowUp' || k === 'ArrowDown') {
          const f = dec ? l[2] : gzFace(l), sx = (k === 'ArrowRight' ? 1 : k === 'ArrowLeft' ? -1 : 0) * (f === 1 ? -1 : 1), sy = k === 'ArrowDown' ? 1 : k === 'ArrowUp' ? -1 : 0;
          const ex = decalExt(previewObj ? previewObj.dims : { front: 4.4, rear: 0, top: 1.25, bot: 0, half: 0.95 }, f), du = (sx * st / 200) * ex[0], dv = (sy * st / 200) * ex[1];
          for (const [o, p0] of [[l, posOf(l)], ...others()]) shiftL(o, p0, o[0] >= C.SHP0 ? du : sx * st * 0.01 * (dec ? 2 : 1), o[0] >= C.SHP0 ? dv : sy * st * 0.01 * (dec ? 2 : 1), f);
          livePrev(); later(); return true;
        }
        if (k === 'BracketLeft' || k === 'BracketRight') {
          const up = k === 'BracketRight';
          if (dec) { const v = l[5] || 40; l[5] = clamp(e.shiftKey ? v + (up ? 1 : -1) : Math.round(up ? Math.max(v + 1, v * 1.08) : Math.min(v - 1, v / 1.08)), 4, 300); note('크기 ' + l[5] + 'cm'); }
          else { const X = xOf(l), m = up ? 1.08 : 1 / 1.08; setX(l, 'w', Math.round(clamp((X.w || 100) * m, 10, 400)), 100); setX(l, 'h', Math.round(clamp((X.h || 100) * m, 10, 400)), 100); note('크기 ' + (xOf(l).w || 100) + '%'); }
          livePrev(); later(); return true;
        }
        if (k === 'KeyQ' || k === 'KeyE') { turn((k === 'KeyQ' ? -1 : 1) * (e.shiftKey ? 1 : 5)); later(); return true; }
        return false;
      };
      if (!wrap.querySelector('#hr-cust-css')) wrap.append(h('style', { id: 'hr-cust-css', text: CUST_CSS }));
      pickDraw = () => { if (cur.tab === 'paint') draw(); };
      DBG.pick = { cur, draw: (k) => draw(k), previewCar, pv, hist, hit: pvHit, cam, selL, load: (id) => { closeSheet(); loadCar(id); previewCar(true); draw(); }, gz: () => gzS, randomize, undo, spot: (x, y) => { const q = pvHit(x, y); return q && previewObj ? decalSpot(q.P, q.N, previewObj.dims) : null; } };
      wrap.append(pickInfo, pickStat, pickTools, pickEl);
      draw(); previewCar(true);
      layoutPick();
      // the selected card in view; card pictures come from one small pack (loaded once)
      const toSel = () => { const el = pickEl && pickEl.querySelector('.hr-cc.sel'); if (el && body) body.scrollTop = Math.max(0, el.offsetTop - body.offsetTop - 84); };
      requestAnimationFrame(toSel);
      if (!THUMBS.p) THUMBS.p = H.pack('thumbs').then((p) => { for (const k of Object.keys(p)) THUMBS.url[k] = URL.createObjectURL(new Blob([p[k]], { type: 'image/webp' })); }).catch(() => {});
      THUMBS.p.then(() => { if (pickEl && cur.tab === 'car') { draw(); requestAnimationFrame(toSel); } });
    }
    const tagsOn = () => H.store.get('tags', '0') === '1';
    const calmOn = () => H.store.get('calm', '0') === '1';
    const carTplRoles = (id) => { const t = ASSETS && ASSETS.cars[id]; return t && t.roles; };
    let pickPW = 0, pickPH = 0;   // panel size (the preview camera keeps the car in the free part of the screen)
    function layoutPick() {
      if (!pickEl) return;
      const land = vw >= vh * 1.1, short = vh < 440;
      pickEl.classList.toggle('cmp', short && land);
      if (land) {
        pickPW = Math.round(clamp(vw * (vw < 760 ? 0.52 : 0.42), 300, 600)); pickPH = 0;
        Object.assign(pickEl.style, { right: '8px', top: short ? '8px' : Math.min(56, vh * 0.08) + 'px', bottom: '8px', left: '', width: pickPW + 'px', height: '', maxHeight: '' });
        Object.assign(pickInfo.style, { left: '12px', top: short ? '8px' : '12px', right: '', bottom: '', maxWidth: Math.max(160, vw - pickPW - 120) + 'px' });
        Object.assign(pickStat.style, { left: '12px', bottom: '10px', top: '', width: Math.round(clamp(vw - pickPW - 40, 200, clamp(vh * 0.42, 380, 480))) + 'px' });
        Object.assign(pickTools.style, { right: photo ? '' : pickPW + 18 + 'px', left: photo ? '12px' : '', top: short ? '8px' : '12px', bottom: '' });
      } else {
        pickPW = 0; pickPH = Math.round(vh * 0.56);
        Object.assign(pickEl.style, { left: '8px', right: '8px', bottom: '8px', top: '', width: '', height: pickPH + 'px', maxHeight: '' });
        Object.assign(pickInfo.style, { left: '12px', top: '12px', right: '', bottom: '', maxWidth: (vw - 130) + 'px' });
        Object.assign(pickStat.style, { left: '10px', right: '10px', top: '', bottom: pickPH + 16 + 'px', width: '' });
        Object.assign(pickTools.style, { right: photo ? '' : '10px', left: photo ? '12px' : '', top: '12px', bottom: '' });
      }
      if (photo) { pickPW = pickPH = 0; }
      pickStat.classList.toggle('cmp', short && land); pickStat.classList.toggle('por', !land);
    }
    function closePick() { pv.dec = null; pickKey = null; pv.eye = null; if (pv.gzEl) pv.gzEl.remove(); pv.gz = null; pv.gzEl = null; cv3.style.cursor = ''; if (photo) setPhoto(false); for (const el of [pickEl, pickInfo, pickStat, pickTools]) if (el) el.remove(); pickEl = pickInfo = pickStat = pickTools = null; pickDraw = null; }
    let pendingPreview = null, previewObj = null;
    const lowTpl = {};   // 고르기 화면: 보통 · 높음이면 낮음 모델을 먼저 보여 주고(빨리 뜸) 제 단계가 오면 바꿈
    function placePreview(po) {
      const i = ((-3) % T.n + T.n) % T.n, p = X3(T, i, 0, 0);
      po.root.position.set(p.x, T.H[i] + 0.06, p.z); po.root.rotation.y = Math.atan2(T.TY[i], T.TX[i]) + PI / 2;
      po.setLights(nightK ? 3 : 0.4, 0.6);
    }
    function showPreview(tpl, id, liv, cust, low) {
      const old = previewObj, po = makeCarObj(tpl, H.CAR[id], liv, brandPref(H), cust);
      po.low = low; previewObj = po; placePreview(po); addBlob(po); DBG.pv = { id, low, t: performance.now(), po };
      // compile its shaders in the background first (switching cars never stalls); the old car stays until then
      compileBg(po.root, scene).then(() => { if (dead) return; if (old) world.remove(old.root); if (previewObj === po) world.add(po.root); });
      if (pickDraw) pickDraw();   // the paint tab shows rim / caliper / tint only when the model has them
    }
    function previewTick() {
      if (!pendingPreview || !T) return;
      const [id, liv, cust, rebuild] = pendingPreview;
      if (previewObj && previewObj.def.id === id && !rebuild && !previewObj.low) { pendingPreview = null; previewObj.paint(liv, cust); return; }   // same car: repaint only
      if (!needCars([id])) {   // loading this car (keeps the request): a quick low model meanwhile
        if (previewObj && previewObj.def.id === id && previewObj.low) { previewObj.paint(liv, cust); return; }
        if (tierId !== 'low') {
          if (!lowTpl[id]) lowTpl[id] = loadCarTpl(H, id, 'low').then((t) => { lowTpl[id] = t; }).catch(() => {});
          else if (lowTpl[id].scene) showPreview(lowTpl[id], id, liv, cust, true);
        }
        return;
      }
      pendingPreview = null;
      showPreview(ASSETS.cars[id], id, liv, cust, false);
    }
    function loadLabel() {
      const el = pickInfo && pickInfo.querySelector('.hr-pl'); if (!el) return;
      const ld = !!pendingPreview && (!previewObj || previewObj.def.id !== pendingPreview[0] || previewObj.low);
      const t = ld ? (previewObj && previewObj.low && previewObj.def.id === pendingPreview[0] ? '고화질 모델 불러오는 중…' : '불러오는 중…') : '';
      if (el.textContent !== t) el.textContent = t;
    }
    function sendPick() { if (api.online && !api.isHost && myPick) { try { api.net.publish({ k: key(), pick: myPick }); } catch (e) {} } }

    /* ======================= 호스트: 단계 진행 ======================= */
    function hostFlow(dt) {
      if (!isHost() || !st) return;
      if (st.ph === 'pick') {
        const force = pkForce; pkForce = false;
        const pk = st.pk.slice(); let ch = false;
        for (let s = 0; s < st.n; s++) {
          if (pk[s]) continue;
          const p = api.players[s]; let v = null;
          if (p && !p.ai && !testBot()) {
            if (isHumanHere(s) && myPick) v = myPick;
            else if (api.online && remPick[s]) v = remPick[s];
            else if (force) { const c = H.CARS[Math.floor(Math.random() * H.CARS.length)]; v = [c.id, Math.floor(Math.random() * c.liv.length)]; }
          }
          if (v && H.CAR[v[0]]) { const cu = H.custNet(v[2]); pk[s] = cu ? [v[0], clamp(v[1] | 0, 0, H.CAR[v[0]].liv.length - 1), cu] : [v[0], clamp(v[1] | 0, 0, H.CAR[v[0]].liv.length - 1)]; ch = true; }
        }
        const humansLeft = pk.some((v, s) => !v && api.players[s] && !api.players[s].ai && !testBot());
        if (!humansLeft) {
          const full = H.aiPicks(Object.assign({}, st, { pk }), api.players);
          api.setState(Object.assign({}, st, { pk: full, grid: H.makeGrid(full, st), ph: 'count', seq: st.seq + 1 }));
        } else if (ch) api.setState(Object.assign({}, st, { pk }));
        return;
      }
      if (st.ph === 'count' && phase === 'race') { api.setState(Object.assign({}, st, { ph: 'race' })); return; }
      if (st.ph === 'race' && W && !doneSent) {
        const now = W.t;
        let all = true, humAll = true, anyFin = false;
        for (const c of W.cars) {
          if (!c.fin) all = false; else anyFin = true;
          if (!api.players[c.seat] || !api.players[c.seat].ai) if (!c.fin) humAll = false;
        }
        // multi-class: the 40 s countdown starts once every class has its winner (a slow class still gets to finish)
        const clsAll = [...new Set(W.cars.map((c) => H.CAR[c.car].cls))].every((k) => W.cars.some((c) => c.fin && H.CAR[c.car].cls === k));
        if (anyFin && clsAll && firstFinT == null) firstFinT = now;
        const hasHum = W.cars.some((c) => api.players[c.seat] && !api.players[c.seat].ai);
        if (anyFin && hasHum && humAll && allHumFinT == null) allHumFinT = now;
        const end = all || (allHumFinT != null && now - allHumFinT > 4) || (firstFinT != null && now - firstFinT > 40) || now > 60 * 20;
        if (end) {
          doneSent = true;
          const rk = H.ranking(W.cars);
          let fl = null;
          for (const c of W.cars) if (c.best > 0 && (!fl || c.best < fl[1])) fl = [c.seat, Math.round(c.best * 100) / 100];
          const res = rk.map((c) => [c.seat, c.fin ? Math.round(c.finT * 100) / 100 : 0, Math.round(Math.max(0, c.prog + (c.lap ? 1 : 0)) * 100) / 100, Math.round((c.best || 0) * 100) / 100, Math.round(c.vmax || 0), (W.posH && W.posH[c.seat] || []).slice(0, 7)]);
          api.setState(Object.assign({}, st, { ph: 'done', res, fl, tn: T.nm }));
        }
      }
      void dt;
    }

    /* ======================= 온라인 ======================= */
    let pubT = 0;
    const r2 = (v) => Math.round(v * 100) / 100;
    const packCar = (c) => [r2(c.x), r2(c.y), Math.round(c.h * 1000) / 1000, r2(c.vf), r2(c.vl), r2(c.w), r2(c.st), (c.brk > 0.05 ? 1 : 0) | (c.thr > 0.5 ? 2 : 0) | (c.fin ? 4 : 0) | (c.bst > 0 ? 8 : 0) | (c.dr > 0.5 ? 16 : 0) | ((c.slip || 0) > 0.25 ? 32 : 0), c.lap, c.maxI, r2(c.prog), c.finT ? r2(c.finT) : 0, r2(c.best || 0), Math.round(c.vmax || 0), c.idx, c.air && c.zA != null ? r2(Math.max(0, c.zA - H.roadH(T, c))) : 0,
      // items: holding · hit (oil / jam) · 충격 범퍼 · 접지 타이어 · 자석 · in smoke (the picture on other devices; boxes knocked out there)
      W && W.items ? (c.it || c.itR > 0 ? 1 : 0) | (c.slow > 0 ? 2 : 0) | (c.slK === 2 ? 4 : 0) | (c.shd > 0 ? 8 : 0) | (c.trc > 0 ? 16 : 0) | (c.mag > 0 ? 32 : 0) | (c.smk > 0 ? 64 : 0) : 0];
    function ingest(seat, a, now) {
      const c = W && W.cars[seat]; if (!c || controlledHere(seat) || !Array.isArray(a)) return;
      c.snap = { x: a[0], y: a[1], h: a[2], vf: a[3], vl: a[4], w: a[5], t: now };
      c.st = a[6]; c.brk = a[7] & 1 ? 1 : 0; c.thr = a[7] & 2 ? 1 : 0; c.fin = a[7] & 4 ? 1 : 0;
      // effects of a remote car come from its flags and its own velocity (it is not simulated here)
      c.bst = a[7] & 8 ? 0.5 : 0; c.dr = a[7] & 16 ? 1 : 0; c.sa = Math.abs(a[3]) > 3 ? -Math.atan2(a[4], a[3]) : 0;
      c.slip = a[7] & 32 ? Math.max(0.35, Math.min(1, Math.abs(c.sa) * 2.2)) : 0; c.alat = a[3] * a[5];
      c.lap = a[8]; c.maxI = a[9]; c.prog = a[10]; c.finT = a[11]; c.best = a[12]; c.vmax = a[13]; c.zR = +a[15] || 0;
      const f = a[16] | 0;
      c.itF = f & 1; c.slow = f & 2 ? 0.5 : 0; c.slK = f & 4 ? 2 : 3; c.shd = f & 8 ? 1 : 0; c.trc = f & 16 ? 1 : 0; c.mag = f & 32 ? 1 : 0; c.smk = f & 64 ? 1 : 0;
    }
    /* items over the network: hazards placed here (z: [id, kind, x, y, life left, owner]) and hits on cars simulated elsewhere (x: [id, target, kind, from]),
       repeated for ~3 s in every packet (the latest packet is all that arrives) — the receiver keeps each id once */
    function itemsOut() {
      if (!W || !W.items) return null;
      const z = W.hzOut.map((q) => { const a = q.a.slice(); a[4] = r2(Math.max(0.1, a[4] - (W.t - q.t))); return a; });
      const x = W.out.map((q) => [q.id, q.to, q.k, q.from]);
      return z.length || x.length ? { z, x } : null;
    }
    function itemsIn(o) {
      if (!W || !W.items || !o) return;
      if (Array.isArray(o.z)) for (const a of o.z) H.addHazard(W, a);
      if (Array.isArray(o.x)) for (const q of o.x) {
        const seen = W.seenHit || (W.seenHit = {});
        if (!Array.isArray(q) || seen[q[0]]) continue;
        seen[q[0]] = 1;
        if (W.cars[q[3]] && W.cars[q[1]]) zaps.push({ a: q[3], b: q[1], t: 0.4 });
        if (controlledHere(q[1])) H.itemHit(W, W.cars[q[1]], q[2] === H.ITK.oil ? 'oil' : 'jam');
      }
    }
    function pollRemote() {
      if (!api.online) return;
      let rem = null, hs = null;
      try { rem = api.net.remote(); } catch (e) {}
      if (!api.isHost) { try { hs = api.net.hostState(); } catch (e) {} }
      const now = performance.now();
      if (rem) for (const k in rem) {
        const o = rem[k]; if (!o || o.k !== key()) continue;
        if (o.pick && api.isHost) remPick[+k] = o.pick;
        if (o.c && W) for (const s in o.c) ingest(+s, o.c[s], now);
        if (o.i && W) itemsIn(o.i);
      }
      if (W && hs && hs.k === key()) { if (hs.c) for (const s in hs.c) ingest(+s, hs.c[s], now); if (hs.i) itemsIn(hs.i); }
    }
    function publish(dt) {
      if (!api.online) return;
      pubT -= dt; if (pubT > 0) return; pubT = 1 / 15;
      if (!W) {   // picking: a guest keeps telling the host its choice until the race starts
        if (!api.isHost && st && st.ph === 'pick' && myPick) try { api.net.publish({ k: key(), pick: myPick }); } catch (e) {}
        return;
      }
      const mine = {}, ai = {}; let nm = 0;
      for (const c of W.cars) { if (!controlledHere(c.seat)) continue; if (P(c.seat).ai) ai[c.seat] = packCar(c); else { mine[c.seat] = packCar(c); nm++; } }
      const io = itemsOut();
      try {
        if (api.isHost) { if (nm) api.net.publish(io ? { k: key(), c: mine, i: io } : { k: key(), c: mine }); api.net.hostSend(io ? { k: key(), c: ai, i: io } : { k: key(), c: ai }); }
        else if (nm) api.net.publish(io ? { k: key(), c: mine, i: io } : { k: key(), c: mine });
        else if (st && st.ph === 'pick' && myPick) api.net.publish({ k: key(), pick: myPick });
      } catch (e) {}
    }
    function smoothRemote(dt) {
      const now = performance.now(), k = 1 - Math.exp(-dt * 12);
      for (const c of W.cars) {
        if (controlledHere(c.seat) || !c.snap) continue;
        const s = c.snap, age = Math.min(0.35, (now - s.t) / 1000);
        const ch = Math.cos(s.h), sh = Math.sin(s.h);
        const tx = s.x + (s.vf * ch - s.vl * sh) * age, ty = s.y + (s.vf * sh + s.vl * ch) * age, th = s.h + s.w * age;
        if (Math.hypot(tx - c.x, ty - c.y) > 15) { c.x = tx; c.y = ty; c.h = th; }
        else { c.x += (tx - c.x) * k; c.y += (ty - c.y) * k; c.h += H.wrapA(th - c.h) * k; }
        c.vf = s.vf; c.vl = s.vl; c.w = s.w;
        H.locate(T, c);
      }
    }

    /* ======================= 판 시작 · 단계 ======================= */
    let haveAssets = null, carWaitT = 0;
    function ensureWorld() {
      if (!st || !ASSETS) return;
      if (built !== st.rid) {
        // a rematch can change the time of day / weather: swap the sky first
        if (SKY_KEY(st) !== skyKeyNow) {
          if (skyLoading) return;
          skyLoading = true;
          H.pack(SKY_KEY(st)).then((p) => imageFrom(p.sky)).then((im) => { skyLoading = false; if (dead) return; ASSETS.sky = im; setupSky(st); ensureWorld(); })
            .catch(() => { skyLoading = false; skyKeyNow = SKY_KEY(st); ensureWorld(); });
          return;
        }
        if (!THA[st.th || 'park']) { themeLoad(st.th || 'park').then(() => { if (!dead) ensureWorld(); }); return; }
        if (previewObj) previewObj = null;
        clearFx();
        // new race (or a rematch): rebuild everything that depends on the seed
        while (world.children.length) { const ch = world.children[0]; world.remove(ch); if (!ch.userData.keep) ch.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); }
        for (const pl of nightLights) scene.remove(pl);
        nightLights.length = 0;
        lamps.length = 0; gantryLights.length = 0; spinners.length = 0;
        buildTrack(st);
        built = st.rid; W = null; DBG.T = T; phase = 'pick'; trkEl.style.display = 'none'; layout(); doneSent = false; firstFinT = allHumFinT = null; goT = null; myPick = null; closePick();
        // the track's shaders compile in the background behind the loading screen, then it goes away
        holdRender = true; hooks.progress(0.97, '그래픽 준비 중…');
        const t0 = performance.now();
        compileBg(scene).then(() => {
          holdRender = false; DBG.tm = Object.assign(DBG.tm || {}, { track: Math.round(performance.now() - t0) });
          if (!dead) hooks.ready();
        });
      }
      if (st.ph === 'pick') {
        phase = 'pick';
        if (!myPick) openPick(); else closePick();
        const humans = api.players.filter((p) => p && !p.ai).length;
        if (isHost() && !pbar && api.pickBar && (api.online || humans > 1)) try { pbar = api.pickBar({ picked: (i) => !!(st && st.pk && st.pk[i]) || (i === mySeat() && !!myPick), onForce: () => { pkForce = true; } }); } catch (e) {}
        if (!pickEl && !previewObj && T) { const s = mySeat(); pendingPreview = s >= 0 && st.pk[s] ? st.pk[s] : [H.CARS[0].id, 0]; }
        return;
      }
      closePick();
      if (pbar) { try { pbar.destroy(); } catch (e) {} pbar = null; }
      if (!W && st.pk && st.pk.every(Boolean) && st.grid) {
        if (!needCars([...new Set(st.pk.map((v) => v[0]))])) { if (!carWaitT) carWaitT = setTimeout(() => { carWaitT = 0; if (!dead) ensureWorld(); }, 150); return; }
        if (previewObj) { world.remove(previewObj.root); previewObj = null; }
        W = H.makeWorld(st); W.hum = api.players.map((p, i) => (p && !p.ai ? i : -1)).filter((i) => i >= 0); DBG.W = W; DBG.carObjs = carObjs; DBG.cam = cam;
        W.t = -3.6;
        buildCars(); buildItemFx();
        if (!smoke) buildFx(st);
        // compile every shader and upload every texture before the lights start (no stall in the first seconds)
        phase = 'prep'; prepEl.style.display = ''; trkEl.style.display = ''; layout();
        const rid = st.rid;
        warmUp().then(() => {
          if (dead || !W || built !== rid || phase !== 'prep') return;
          prepEl.style.display = 'none';
          phase = 'count'; countT = 0; last = 0; acc = 0;
          lightsEl.style.display = '';
          layout();
        });
      }
      if (st.ph === 'done' && phase !== 'done') { phase = 'done'; layout(); }
    }
    function startLoad(s) {
      if (haveAssets) return;
      haveAssets = loadAssets(s).then((A) => {
        if (dead) return;
        ASSETS = A;
        setupSky(s);
        ensureWorld();
      }).catch((e) => { hooks.progress(1, '불러오지 못했어요: ' + (e && e.message || e)); });
    }

    /* ======================= 프레임 ======================= */
    let paused = false, hudT = 0, holdRender = false, lastSurf = 0;
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      const rdt = Math.min(0.1 * Math.max(1, SPD()), (now - (last || now)) / 1000); last = now;   // (tests at ×speed may run at a few fps)
      DBG.fps = (DBG.fps || 30) * 0.95 + (rdt > 0 ? Math.min(240, 1 / rdt) : 30) * 0.05;
      if (!ASSETS || !T) return;
      const dt = rdt * SPD();
      previewTick(); loadLabel();
      if (W && !paused) {
        if (phase === 'count' || phase === 'race' || phase === 'done') simTick(dt); else ivK = 0;
        pollRemote(); if (api.online) smoothRemote(rdt);
        publish(rdt);
        ivApply();   // 그리는 값(걸음 사이 위치)으로: 연기 · 스키드 자국 · 아이템 효과
        try { fxTick(rdt); itemFxTick(rdt); } finally { ivRestore(); }
      } else if (st && st.ph === 'pick') { pollRemote(); publish(rdt); }
      if (!W) ivK = 0;
      hostFlow(rdt);
      ivApply();   // 카메라 · 차 모델 · 안내선도 같은 값으로
      try {
      camTick(rdt);
      if (W) for (const c of W.cars) if (carObjs[c.seat]) syncCarObj(c, carObjs[c.seat], rdt);
      hudT -= rdt; if (hudT <= 0) { hudT = 1 / 12; hudTick(); }
      if (noteT > 0) { noteT -= rdt; if (noteT <= 0) noteEl.style.opacity = '0'; }
      if (hintT > 0) { hintT -= rdt; if (hintT <= 0) hintEl.style.opacity = '0'; }
      const watched = W ? W.cars[mySeat() >= 0 ? mySeat() : tvSeat] : null;
      gearTick(watched);
      audioTick(W && mySeat() >= 0 ? W.cars[mySeat()] : null, rdt);
      if (W) for (const c of W.cars) { c.fxScrS = Math.max((c.fxScrS || 0) * Math.exp(-rdt * 8), c.fxScr || 0); c.fxHit = 0; c.fxScr = 0; }
      if (W && phase === 'race') driftHud(watched);
      if (W) guideTick(mySeat() >= 0 && (isHumanHere(mySeat()) || testBot()) ? W.cars[mySeat()] : null);
      } finally { ivRestore(); }
      for (const t of waters) { t.offset.x += rdt * 0.006; t.offset.y += rdt * 0.004; }
      for (const o of spinners) o.rotation.y += rdt * 0.7;
      if (phase !== 'prep' && !holdRender) R.render(scene, cam);   // while shaders compile in the background, drawing would force them to finish on this thread
      if (pv.gz) pv.gz();
    }
    /* 셰이더 미리 굽기: 장면 전체(화면 밖 차 · 꺼진 불꽃 · 브레이크 빛 · 안내 띠까지)를 병렬 컴파일(KHR_parallel_shader_compile)로 굽고,
       한 번 그려 결 · 모양을 GPU에 올린 뒤 출발 신호를 켬 → 첫 몇 초 프레임 급락 없음 */
    /* compile shaders off the main thread when the GPU driver can (KHR_parallel_shader_compile), else right away (behind the loading screen) */
    function compileBg(obj, target) {
      try {
        if (R.compileAsync && R.extensions.has('KHR_parallel_shader_compile')) return R.compileAsync(obj, cam, target || null).catch(() => {});
        R.compile(obj, cam, target || null);
      } catch (e) { console.warn(e); }
      return Promise.resolve();
    }
    async function warmUp() {
      const t0 = performance.now(), p0 = R.info.programs.length;
      camTick(1 / 60);
      const show = [];
      for (const o of carObjs) if (o) for (const q of [o.flame, o.brake, o.shield, o.iring]) if (q && !q.visible) show.push(q);
      if (guide && !guide.mesh.visible) show.push(guide.mesh);
      const culled = [];
      for (const q of show) q.visible = true;
      scene.traverseVisible((o) => { if (o.frustumCulled && (o.isMesh || o.isPoints || o.isLine)) { culled.push(o); o.frustumCulled = false; } });
      await compileBg(scene);
      const t1 = performance.now();
      if (!dead) {
        for (const q of show) q.visible = true;
        try { R.render(scene, cam); } catch (e) {}
        for (const q of show) q.visible = false;
        for (const o of culled) o.frustumCulled = true;
        try { R.render(scene, cam); } catch (e) {}
      }
      DBG.tm = Object.assign(DBG.tm || {}, { compile: Math.round(t1 - t0), upload: Math.round(performance.now() - t1), progs: R.info.programs.length, newProgs: R.info.programs.length - p0 });
    }
    /* 걸음 사이 보간: 시뮬은 초당 120걸음 고정 → 화면이 60Hz의 배수가 아니면(75 · 90 · 144Hz, 프레임이 흔들릴 때도) 프레임마다 0 · 1 · 2걸음씩 움직여
       길 전체가 덜컹거림(시속 250km면 한 걸음이 0.6m). 그리는 동안만 이 기기가 모는 차를 남은 시간(1 - acc / DT)만큼 속도대로 되돌려 놓음.
       판정 · 전송은 원래 값 그대로(다른 기기 차는 smoothRemote가 프레임마다 부드럽게 옮김) */
    let ivK = 0, ivOn = false;
    const ivS = [];
    function ivApply() {
      if (ivOn || !W || !T || !(ivK > 0)) return;
      const k = ivK * H.DT;
      for (const c of W.cars) {
        const q = ivS[c.seat] || (ivS[c.seat] = {});
        q.on = controlledHere(c.seat); if (!q.on) continue;
        q.x = c.x; q.y = c.y; q.h = c.h; q.idx = c.idx; q.lat = c.lat; q.along = c.along; q.zA = c.zA;
        const ch = Math.cos(c.h), sh = Math.sin(c.h);
        c.x -= (c.vf * ch - c.vl * sh) * k; c.y -= (c.vf * sh + c.vl * ch) * k; c.h -= (c.w || 0) * k;
        if (c.air && c.zA != null) c.zA -= (c.vz || 0) * k;
        H.locate(T, c);
      }
      ivOn = true;
    }
    function ivRestore() {
      if (!ivOn) return; ivOn = false;
      for (const c of W.cars) { const q = ivS[c.seat]; if (!q || !q.on) continue; c.x = q.x; c.y = q.y; c.h = q.h; c.idx = q.idx; c.lat = q.lat; c.along = q.along; c.zA = q.zA; }
    }
    function simTick(dt) {
      // fixed steps; large frame gaps (slow devices, ×speed tests) are split
      acc += dt;
      const maxSteps = Math.ceil(0.4 * SPD() / H.DT) + 4;
      let steps = Math.floor(acc / H.DT); if (steps > maxSteps) { steps = maxSteps; acc = 0; } else acc -= steps * H.DT;
      ivK = clamp(1 - acc / H.DT, 0, 1);
      if (!steps) return;
      const wasT = W.t;
      const me = mySeat();
      const hum = me >= 0 && isHumanHere(me) ? readInput(steps * H.DT / SPD()) : null;
      const AIC = {};
      H.worldStep(W, steps * H.DT, (seat, c) => {
        if (W.t < 0) return { thr: seat === me && hum ? hum.thr : 0, brk: 1, steer: 0, hb: 0 };
        if (seat === me && hum) return hum;
        // AI: decide at ~30 Hz, hold in between
        const a = c.aiHold;
        if (a && W.t - a.t < 1 / 30) return a.inp;
        const lv = (api.players[seat] && api.players[seat].lv) || 2;
        const inp2 = H.aiInput(T, c, W.cars, lv, W.hab[seat], W.t, W.wet, W);
        c.aiHold = { t: W.t, inp: inp2 };
        return inp2;
      }, (seat) => controlledHere(seat), (seat) => (seat === me && hum ? assist : 1), (seat) => (seat === me && hum ? assist : 0));
      void AIC;
      for (const c of W.cars) { c.vmax = Math.max(c.vmax || 0, H.kmh(c.vf)); }
      // phase changes from the local clock
      if (wasT < 0 && W.t >= 0) { for (const [, m] of gantryLights) m.emissiveIntensity = 0; phase = 'race'; goT = 0; lightsEl.style.display = 'none'; goEl.style.display = ''; api.sfx('go'); api.buzz(30, 'alert'); showHint(); layout(); }
      if (phase === 'count') {
        const lit = Math.floor((W.t + 3.6) / 0.6);   // 5 lights, 0.6 s apart, all out at GO
        lightsEl.querySelectorAll('i').forEach((el, k) => el.classList.toggle('on', k < lit));
        for (const [k, m] of gantryLights) m.emissiveIntensity = k < lit ? 4 : 0;
        if (lit !== countT && lit > 0 && lit <= 5) api.sfx('count');
        countT = lit;
      }
      if (goT != null) { goT += dt / SPD(); if (goT > 1.1) { goEl.style.display = 'none'; trkEl.style.display = 'none'; goT = null; } }
      if (resetCD > 0) resetCD -= dt;
      for (const e of W.ev) {
        const mine = e.seat === me;
        if (e.k === 'lap' || e.k === 'fin') { const ph = W.posH || (W.posH = {}), q = ph[e.seat] || (ph[e.seat] = [st && st.grid ? st.grid.indexOf(e.seat) + 1 : 0]); q.push(H.ranking(W.cars).findIndex((x) => x.seat === e.seat) + 1); }
        if (e.k === 'lap' && mine) { const c = W.cars[me]; const lt = c.laps[c.laps.length - 1]; note((c.lap === W.laps ? '마지막 바퀴! ' : (c.lap) + '바퀴째 · ') + H.fmtT(lt) + (lt <= c.best + 1e-6 && c.laps.length > 1 ? ' 최고 랩' : '')); api.sfx('tick'); }
        if (e.k === 'fin' && mine) { note('완주! ' + H.fmtT(W.cars[me].finT)); api.sfx('win'); api.buzz(40, 'win'); try { const c = W.cars[me]; if (c.best > 0) api.best('lap', Math.round(c.best * 100) / 100, { label: '최고 랩', lower: true, fmt: 'time' }); } catch (x) {} }
        if (e.k === 'bump' && (mine || e.o === me)) { playBuf('i_metal' + (1 + Math.floor(Math.random() * 3)), clamp(e.v / 10, 0.15, 0.8), 0.8 + Math.random() * 0.3); api.buzz(Math.round(clamp(e.v * 3, 10, 50))); }
        if (e.k === 'reset' && mine) note('트랙으로 복귀');
        if (e.k === 'pad' && mine) { burst(300, 1800, 1.4, 0.35, 0.14); api.buzz(10, 'ui'); }
        if (e.k === 'dlv' && mine) { chime(e.lv); dgFlash = 0.35; api.buzz(8, 'ui'); }
        if (e.k === 'boost' && mine) { burst(380, 2400, 1.6, 0.55, 0.22); api.buzz(14 + e.lv * 6, 'ui'); boostNote(e.lv); }
        // items (「아케이드 요소」)
        if (e.k === 'ibox' && mine) { chime(2); api.buzz(8, 'ui'); }
        if (e.k === 'use' && mine) { const it = H.ITEMS[e.it]; if (it.id === 'nitro') { burst(380, 2400, 1.6, 0.6, 0.24); api.buzz(18, 'ui'); } else burst(520, 1600, 1.2, 0.25, 0.12); note(it.nm); }
        if (e.k === 'ihit' && mine) { playBuf('i_metal2', 0.35, 0.55); burst(900, 200, 0.8, 0.3, 0.14); api.buzz(26); note(e.it === 'oil' ? '기름에 미끄러짐' : '방해 전파에 맞음'); }
        if (e.k === 'iblk' && mine) { chime(1); note('충격 범퍼가 막았어요'); }
        if (e.k === 'inone' && mine) note('앞차가 없어요');
        if (e.k === 'zap') zaps.push({ a: e.seat, b: e.o, t: 0.4 });
      }
      W.ev.length = 0;
      // haptics: leaving the road (grass / gravel) — hits, boosts and drift steps buzz above
      if (me >= 0 && W.cars[me] && hum) { const c = W.cars[me], sf = c.surf | 0; if (sf >= 2 && lastSurf < 2 && c.vf > 12) api.buzz(14); lastSurf = sf; }
      if (me >= 0 && W.cars[me] && W.cars[me].hit > 4) { playBuf('i_metal' + (1 + Math.floor(Math.random() * 3)), clamp(W.cars[me].hit / 14, 0.2, 0.9), 0.7); api.buzz(20); }
      if (me >= 0 && W.cars[me] && W.cars[me].land > 2.5) { playBuf('i_metal1', clamp(W.cars[me].land / 12, 0.1, 0.4), 0.55); api.buzz(16); }
      for (const c of W.cars) c.land = 0;
      for (const c of W.cars) { c.fxHit = Math.max(c.fxHit || 0, c.hit || 0); c.fxScr = Math.max(c.fxScr || 0, c.scr || 0); c.hit = 0; c.scr = 0; }
    }
    let lastPos = 0, lastMe = -1, posT = 0;
    function hudTick() {
      if (!W) { posEl.innerHTML = ''; lapEl.innerHTML = ''; return; }
      const me = mySeat() >= 0 ? mySeat() : tvSeat, c = W.cars[me];
      const rk = H.ranking(W.cars), pos = rk.findIndex((x) => x.seat === me) + 1;
      if (!c) return;
      const cl = H.CAR[c.car].cls, cpos = rk.filter((x) => H.CAR[x.car].cls === cl).findIndex((x) => x.seat === me) + 1;
      // position change: the P number flashes green (gained) / red (lost) for a moment
      if (phase === 'race' && W.t > 3 && lastPos && pos !== lastPos && me === lastMe) { posEl.classList.toggle('up', pos < lastPos); posEl.classList.toggle('dn', pos > lastPos); posT = 0.9; if (pos < lastPos && me === mySeat()) api.sfx('tick'); }
      lastPos = pos; lastMe = me;
      if (posT > 0) { posT -= 1 / 12; if (posT <= 0) posEl.classList.remove('up', 'dn'); }
      posEl.innerHTML = '<b>P' + pos + '</b><span>/' + W.cars.length + '</span><i><span class="hr-cls" style="background:' + H.CLS[cl].col + '">' + H.CLS[cl].short + '</span>클래스 ' + cpos + '위' + (mySeat() < 0 && api.players[me] ? ' · ' + escapeH(String(api.players[me].name)) : '') + '</i>';
      const lapN = Math.max(1, Math.min(W.laps, c.lap || 1)), cur = c.fin ? c.finT : c.lap ? W.t - c.lapStart : 0;
      lapEl.innerHTML = '<b>' + (c.fin ? '완주' : lapN + '/' + W.laps + '바퀴') + '</b><br>' + H.fmtT(Math.max(0, cur)) + (c.best ? ' · 최고 ' + H.fmtT(c.best) : '');
      spdEl.querySelector('b').textContent = H.kmh(c.vf);
      spdEl.querySelector('.hr-gear').textContent = c.vf < -0.5 ? 'R' : !gearsOf(c.car) ? 'D' : String(c.gear || 1);
      const bars = spdEl.querySelectorAll('.hr-bar>div');
      bars[0].style.width = Math.round(clamp((c.rpm || 0) / (!gearsOf(c.car) ? 15000 : 9000), 0, 1) * 100) + '%';
      bars[1].style.width = Math.round(clamp(c.draft, 0, 1) * 100) + '%';
      wrongEl.style.display = c.wrong && phase === 'race' ? '' : 'none';
      itemHud(mySeat() >= 0 && (isHumanHere(mySeat()) || testBot()) ? c : null);
      const ft = fl.k > 0.5 && W ? (fl.lock ? '자유 시점 고정 ·  또는 Tab = 풀기' : '자유 시점 ·  = 고정') : '';
      if (camTag.textContent !== ft) { camTag.textContent = ft; camTag.style.display = ft ? 'block' : 'none'; }
      // standings tower: leader … around me
      const rows = [];
      const show = rk.length <= 6 ? rk : rk.filter((x, k) => k < 2 || Math.abs(k - (pos - 1)) <= 1 || k === rk.length - 1);
      let lastK = -1;
      for (const x of show) {
        const k = rk.indexOf(x);
        if (lastK >= 0 && k > lastK + 1) rows.push('<div style="opacity:.6">…</div>');
        const nm = String(api.players[x.seat] ? api.players[x.seat].name : '?').slice(0, 7), cc = H.CLS[H.CAR[x.car].cls];
        rows.push('<div class="' + (x.seat === me ? 'me' : '') + '">' + (k + 1) + ' <span class="hr-cls" style="background:' + cc.col + '">' + cc.short + '</span>' + escapeH(nm) + (x.fin ? ' ✓' : '') + '</div>');
        lastK = k;
      }
      tower.innerHTML = rows.join('');
      drawMap();
    }
    const escapeH = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

    /* ======================= 시작 ======================= */
    const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(() => resize()) : null;
    if (ro) ro.observe(wrap);
    window.addEventListener('resize', resize);
    const onCtl = () => layout(); window.addEventListener('lounge-ctl', onCtl);
    resize();
    raf = requestAnimationFrame(frame);
    const kick = () => { audioKick(); if (noteT > 0) { noteT = 0; noteEl.style.opacity = '0'; } };   // any tap also clears the notice
    wrap.addEventListener('pointerdown', kick);
    window.addEventListener('keydown', kick);
    const onPickKey = (e) => { if (pickKey && pickEl && !/^(INPUT|TEXTAREA|SELECT)$/.test((e.target && e.target.tagName) || '') && pickKey(e)) e.preventDefault(); };
    window.addEventListener('keydown', onPickKey);

    return {
      update(s, prev) {
        st = s;
        if (!s) return;
        if (!ASSETS) { startLoad(s); return; }
        ensureWorld();
        void prev;
      },
      pause() { paused = true; if (AC) AC.suspend().catch(() => {}); },
      resume() { paused = false; last = 0; if (AC) AC.resume().catch(() => {}); },
      destroy() {
        dead = true; cancelAnimationFrame(raf);
        if (ro) ro.disconnect();
        window.removeEventListener('resize', resize); window.removeEventListener('lounge-ctl', onCtl); window.removeEventListener('keydown', kick); window.removeEventListener('keydown', onPickKey);
        for (const f of offs) try { f(); } catch (e) {}
        if (pbar) try { pbar.destroy(); } catch (e) {}
        if (AC) try { AC.close(); } catch (e) {}
        scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
        if (pmrem) pmrem.dispose();
        R.dispose(); try { R.forceContextLoss(); } catch (e) {}
        wrap.remove();
      },
    };
  };

  window.HR_VIEW = V;
})();
