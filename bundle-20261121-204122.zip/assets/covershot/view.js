/* 엄폐 사격 — 화면(캔버스) · HUD · 조작 · 소리 · 고르기 창. 시뮬은 sim.js(초당 60 고정 걸음), 여기서는 걸음 사이를 보간해 그린다. */
(function () {
  const G = window, L = G.Lounge, U = L.util, CS = G.COVERSHOT, D = CS.DATA, S = CS.SIM, A = CS.DRAW;
  const DT = S.DT, SLOTX = S.SLOTX, COVY = S.COVY, sc = S.sc, SHD = S.SH, W = D.WEAPONS, BS = D.BOSSES;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v), lerp = (a, b, t) => a + (b - a) * t, TAU = Math.PI * 2, FEETY = 126;
  const FB = '"IBM Plex Sans KR",system-ui,sans-serif', FD = '"Black Han Sans","IBM Plex Sans KR",sans-serif', FM = '"IBM Plex Mono",ui-monospace,monospace';
  const CSS = '.cvs-root{position:absolute;inset:0;overflow:hidden;background:#0d0e14;touch-action:none;user-select:none;-webkit-user-select:none;cursor:crosshair}'
    + '.cvs-ov{position:absolute;inset:0;z-index:20;display:flex;flex-direction:column;align-items:center;gap:calc(8px*var(--u));padding:calc(12px*var(--u)) calc(10px*var(--u));background:rgba(10,12,18,.9);color:#f2e9d8;overflow-y:auto;font-size:calc(13px*var(--u));cursor:default;word-break:keep-all}'
    + '.cvs-ov h3{margin:0;font-family:var(--f-display);font-weight:400;font-size:calc(22px*var(--u));letter-spacing:1px}'
    + '.cvs-sub{color:#b9b0c4;font-size:calc(12.5px*var(--u));text-align:center;line-height:1.45}'
    + '.cvs-pick{display:grid;grid-template-columns:minmax(0,1fr);justify-items:center;gap:calc(8px*var(--u));width:100%}.cvs-hd{display:flex;flex-direction:column;align-items:center;gap:calc(5px*var(--u))}'
    + '.cvs-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:calc(6px*var(--u));width:100%;max-width:calc(430px*var(--u))}'
    + '.cvs-card{position:relative;display:block;padding:0;overflow:hidden;height:var(--ph,104px);background:#1c1e2a;border:2px solid #343848;border-radius:10px;color:inherit;font:inherit;min-height:44px;cursor:pointer}'
    + '.cvs-card canvas,.cvs-im{position:absolute;left:0;top:0;width:100%;height:100%}.cvs-im{background-repeat:no-repeat}'
    + '.cvs-cap{position:absolute;left:0;right:0;bottom:0;padding:calc(16px*var(--u)) 2px calc(4px*var(--u));background:linear-gradient(rgba(10,11,16,0),rgba(10,11,16,.82) 58%);text-align:center;line-height:1.2}'
    + '.cvs-card.on{border-color:#e3ae45}.cvs-card.foc{box-shadow:0 0 0 1px rgba(255,255,255,.4) inset}.cvs-card.on .cvs-cap{background:linear-gradient(rgba(60,44,12,0),rgba(60,44,12,.88) 58%)}'
    + '.cvs-nm{font-family:var(--f-display);font-size:calc(15px*var(--u));letter-spacing:.5px}.cvs-cl{font-size:calc(12px*var(--u));color:#cfc6d8}'
    + '.cvs-bd{position:absolute;top:4px;left:4px;min-width:calc(22px*var(--u));height:calc(22px*var(--u));border-radius:50%;background:#e3ae45;color:#1a1410;font-weight:700;font-size:calc(13px*var(--u));display:flex;align-items:center;justify-content:center;z-index:1}'
    + '.cvs-det{width:100%;max-width:calc(430px*var(--u));background:#171922;border:1px solid #303444;border-radius:10px;padding:calc(8px*var(--u)) calc(10px*var(--u));line-height:1.5;font-size:calc(12.5px*var(--u));min-height:calc(86px*var(--u))}'
    + '.cvs-det b{color:#e3ae45;font-weight:600}.cvs-det:after{content:"";display:block;clear:both}.cvs-pt{float:left;width:calc(78px*var(--u));height:calc(104px*var(--u));object-fit:cover;object-position:50% 0;border-radius:8px;margin:0 calc(10px*var(--u)) 0 0;border:1px solid #3a3e50;background:#0c0d13;cursor:zoom-in}'
    + '.cvs-bt{display:flex;flex-direction:column;align-items:center;gap:calc(8px*var(--u));width:100%;max-width:calc(430px*var(--u))}.cvs-row{display:flex;gap:calc(8px*var(--u));width:100%;max-width:calc(430px*var(--u))}.cvs-row .btn{flex:1;min-height:calc(46px*var(--u));font-size:calc(15px*var(--u))}'
    + '.cvs-ov.wide{justify-content:center}.cvs-ov.wide .cvs-pick{grid-template-columns:auto minmax(0,calc(470px*var(--u)));grid-template-areas:"dt hd" "dt gr" "dt bt";column-gap:calc(22px*var(--u));width:auto;align-items:start}'
    + '.cvs-ov.wide .cvs-hd{grid-area:hd}.cvs-ov.wide .cvs-grid{grid-area:gr;max-width:none}.cvs-ov.wide .cvs-bt{grid-area:bt;max-width:none}.cvs-ov.wide .cvs-row{max-width:none}'
    + '.cvs-ov.wide .cvs-det{grid-area:dt;width:calc(var(--bh)*.75);max-width:none;background:none;border:0;padding:0;display:flex;flex-direction:column;gap:calc(8px*var(--u));font-size:calc(13px*var(--u))}'
    + '.cvs-ov.wide .cvs-pt{float:none;width:100%;height:var(--bh);margin:0;border-radius:12px}.cvs-ov.wide .cvs-dtx{background:#171922;border:1px solid #303444;border-radius:10px;padding:calc(8px*var(--u)) calc(10px*var(--u))}'
    + '.cvs-lb{position:absolute;inset:0;z-index:30;background:rgba(8,9,14,.93);display:flex;align-items:center;justify-content:center;cursor:zoom-out}.cvs-lb img{max-width:96%;max-height:96%;border-radius:12px}'
    + '.cvs-upc{display:block;width:100%;max-width:calc(430px*var(--u));text-align:left;padding:calc(10px*var(--u)) calc(12px*var(--u));background:#1c1e2a;border:2px solid #3a3e50;border-radius:12px;color:inherit;font:inherit;min-height:calc(74px*var(--u));cursor:pointer}'
    + '.cvs-upc:hover,.cvs-upc:active{border-color:#e3ae45;background:#262433}.cvs-upc .t{display:flex;align-items:baseline;gap:8px;font-family:var(--f-display);font-size:calc(17px*var(--u))}'
    + '.cvs-upc .g{font-family:var(--f-body);font-size:calc(12px*var(--u));color:#9fd0c0}.cvs-upc .lv{margin-left:auto;font-family:var(--f-mono);font-size:calc(12px*var(--u));color:#e3ae45}'
    + '.cvs-upc .l{font-size:calc(13px*var(--u));color:#e6dccb;margin-top:3px}.cvs-upc .l i{font-style:normal;color:#e3ae45;font-family:var(--f-mono)}'
    + '.cvs-sq{display:flex;gap:calc(6px*var(--u));width:100%;max-width:calc(430px*var(--u));font-size:calc(12px*var(--u))}.cvs-sq div{flex:1;background:#171922;border-radius:8px;padding:calc(5px*var(--u)) calc(7px*var(--u))}'
    + '.cvs-sq .b{height:5px;border-radius:3px;background:#2c2f3c;margin-top:4px;overflow:hidden}.cvs-sq .b i{display:block;height:100%;background:#6ad08a}';

  /* ───────── 소리(자체 합성 × 설정의 효과음 크기) ───────── */
  let AC = null, NB = null; const lastS = {};
  const SND = { ar: { f: 1800, q: 0.8, d: 0.07, g: 0.2, o: 160, o2: 70, og: 0.1, gap: 55 }, smg: { f: 2600, q: 0.9, d: 0.05, g: 0.15, o: 200, o2: 90, og: 0.06, gap: 45 }, mg: { f: 1300, q: 0.7, d: 0.08, g: 0.2, o: 130, o2: 60, og: 0.12, gap: 50 },
    sr: { f: 900, q: 0.5, d: 0.3, g: 0.34, o: 140, o2: 40, og: 0.24, gap: 80 }, sg: { f: 700, q: 0.5, d: 0.24, g: 0.34, o: 120, o2: 40, og: 0.2, gap: 80 }, gl: { f: 420, q: 0.6, d: 0.14, g: 0.2, o: 220, o2: 110, og: 0.14, gap: 80 },
    efire: { f: 1100, q: 1.2, d: 0.06, g: 0.08, gap: 60 }, boom: { f: 220, q: 0.4, d: 0.5, g: 0.36, o: 90, o2: 30, og: 0.28, gap: 90 }, hit: { f: 3200, q: 2, d: 0.03, g: 0.04, gap: 50 }, cov: { f: 2400, q: 3, d: 0.05, g: 0.09, gap: 60 },
    warn: { o: 920, o2: 920, og: 0.06, d: 0.07, ot: 'square', gap: 120 }, rld: { f: 3000, q: 4, d: 0.04, g: 0.1, o: 700, o2: 900, og: 0.04, gap: 200 }, hurt: { f: 500, q: 0.6, d: 0.16, g: 0.24, o: 180, o2: 80, og: 0.16, gap: 80 }, skill: { o: 440, o2: 880, og: 0.1, d: 0.22, ot: 'triangle', gap: 150 }, kill: { f: 1500, q: 1, d: 0.08, g: 0.07, gap: 60 } };
  function snd(kind, vol) {
    const P = SND[kind], v = (L.audio && L.audio.sfx ? L.audio.sfx() : 1) * (vol == null ? 1 : vol);
    if (!P || v <= 0.001 || ((L.debug && L.debug.speed) || 1) > 2) return;
    const now = Date.now(); if (now - (lastS[kind] || 0) < P.gap) return; lastS[kind] = now;
    try {
      if (!AC) AC = new (G.AudioContext || G.webkitAudioContext)();
      if (AC.state === 'suspended') AC.resume();
      if (!NB) { NB = AC.createBuffer(1, AC.sampleRate * 0.6 | 0, AC.sampleRate); const d = NB.getChannelData(0); let s = 12345; for (let i = 0; i < d.length; i++) { s = (s * 16807) % 2147483647; d[i] = s / 1073741823.5 - 1; } }
      const t = AC.currentTime;
      if (P.f) { const src = AC.createBufferSource(), bq = AC.createBiquadFilter(), gn = AC.createGain(); src.buffer = NB; bq.type = 'bandpass'; bq.frequency.value = P.f; bq.Q.value = P.q; gn.gain.setValueAtTime(P.g * v, t); gn.gain.exponentialRampToValueAtTime(0.001, t + P.d); src.connect(bq); bq.connect(gn); gn.connect(AC.destination); src.start(t, (now % 400) / 1000); src.stop(t + P.d + 0.02); }
      if (P.o) { const o = AC.createOscillator(), gn = AC.createGain(); o.type = P.ot || 'sine'; o.frequency.setValueAtTime(P.o, t); o.frequency.exponentialRampToValueAtTime(P.o2, t + P.d); gn.gain.setValueAtTime(P.og * v, t); gn.gain.exponentialRampToValueAtTime(0.001, t + P.d); o.connect(gn); gn.connect(AC.destination); o.start(t); o.stop(t + P.d + 0.02); }
    } catch (e) {}
  }
  const IMG = {};
  function art(kind, id) { const p = D.ART[kind] && D.ART[kind][id]; if (!p) return null; let im = IMG[p]; if (!im) { im = IMG[p] = new Image(); im.src = p; } return im.complete && im.naturalWidth ? im : null; }
  function artLater(kind, id, cb) { const im = art(kind, id); if (im) { cb(im); return; } const p = D.ART[kind] && D.ART[kind][id], q = p && IMG[p]; if (q) q.addEventListener('load', () => { if (q.naturalWidth) cb(q); }, { once: true }); }   // 아직 안 불러와졌으면 불러온 뒤에 그림(실패하면 받침 그대로)
  /* 초점 자르기: ART.focus[kind][id] = [가운데x, 가운데y, 보이는 너비](그림 크기에 대한 비율) — 얼굴이 칸 가운데에 오게. 없으면 위쪽 가운데 */
  function focusRect(im, kind, id, w, hh, zoom) {
    const f = D.ART.focus && D.ART.focus[kind] && D.ART.focus[kind][id], W0 = im.naturalWidth, H0 = im.naturalHeight;
    if (!f) { const k = Math.max(w / W0, hh / H0), sw = w / k, sh = hh / k; return [(W0 - sw) / 2, Math.min(H0 - sh, H0 * 0.04), sw, sh]; }
    let sw = Math.min(W0, f[2] * W0 * (zoom || 1)), sh = sw * hh / w; if (sh > H0) { sh = H0; sw = sh * w / hh; }
    return [clamp(f[0] * W0 - sw / 2, 0, W0 - sw), clamp(f[1] * H0 - sh / 2, 0, H0 - sh), sw, sh];
  }
  function cropFocus(c, im, kind, id, x, y, w, hh, zoom) { const r = focusRect(im, kind, id, w, hh, zoom); c.drawImage(im, r[0], r[1], r[2], r[3], x, y, w, hh); }
  /* 큰 원본을 화면 픽셀 크기로 한 번만 줄여 둔다(반씩 줄여 가며 — 한 번에 크게 줄이면 선이 뭉개지고, 프레임마다 줄이면 느리다) */
  function shrink(src, sx, sy, sw, sh, dw, dh) {
    dw = Math.max(1, Math.round(dw)); dh = Math.max(1, Math.round(dh));
    let cur = src, cx = sx, cy = sy, cw = sw, ch = sh;
    while (cw / dw > 2.2) { const nw = Math.ceil(cw / 2), nh = Math.ceil(ch / 2), t = document.createElement('canvas'); t.width = nw; t.height = nh; const c = t.getContext('2d'); c.imageSmoothingQuality = 'high'; c.drawImage(cur, cx, cy, cw, ch, 0, 0, nw, nh); cur = t; cx = 0; cy = 0; cw = nw; ch = nh; }
    const o = document.createElement('canvas'); o.width = dw; o.height = dh; const c = o.getContext('2d'); c.imageSmoothingQuality = 'high'; c.drawImage(cur, cx, cy, cw, ch, 0, 0, dw, dh); return o;
  }
  function tinted(cv, col) { const o = document.createElement('canvas'); o.width = cv.width; o.height = cv.height; const c = o.getContext('2d'); c.drawImage(cv, 0, 0); c.globalCompositeOperation = 'source-in'; c.fillStyle = col; c.fillRect(0, 0, o.width, o.height); return o; }   // 그림 모양 그대로의 단색 판(피격 번쩍임 · 어둡게 하기)

  function mount(root, api) {
    const h = L.h, doc = document;
    if (!doc.getElementById('cvs-css')) doc.head.append(h('style', { id: 'cvs-css', text: CSS }));
    const box = h('div', { class: 'cvs-root' }); root.append(box);
    const C = U.canvas(box), ctx = C.ctx;
    const P0 = api.players[0] || {}, isBot = !!P0.ai, lv = P0.lv || 2;
    let state = null, g = null, seed = null, dead = false, acc = 0, M = {}, ov = null, ovKey = '', ended = false, endT = 0, upAt = 0, simT = 0;
    const inp = { down: false, ax: 50, ay: 45, sw: -1, sk: -1, burst: false, pick: null, up: null, reroll: false };
    let firePtr = null, lastP = null, mouse = false;
    const lay = { W: 1, H: 1, ui: 1, hudH: 88, kx: 3.6, ky: 4.4, fx0: 0, fy1: 500, X: (x) => lay.fx0 + x * lay.kx, Y: (y) => lay.fy1 - (130 - y) * lay.ky, cards: [], burst: null };
    let bgC = null, bgKey = '';
    const fx = [], tr = [], mz = [{ x: 0, y: 0 }, { x: 0, y: 0 }, { x: 0, y: 0 }], flash = [0, 0, 0];
    let shake = 0, vig = 0, hitMk = 0, strip = null, note = null, flashW = 0, hintT = 0, cache = {}, lb = null, pickFit = null;
    const downK = [0, 0, 0]; let bigOn = false; const burstR = () => (bigOn ? lay.burstHi : lay.burst);
    const cached = (key, make) => cache[key] || (cache[key] = make());
    const warned = {};

    function relayout() {
      const Wd = C.w, Ht = C.h, ui = clamp(Math.min(Wd / 360, Ht / 640), 1, 1.7), hudH = Math.round(88 * ui);
      let ky = (Ht - hudH) / 124; const kx = Math.min(Wd / 100, ky); ky = Math.min(ky, kx * 1.32);
      lay.W = Wd; lay.H = Ht; lay.ui = ui; lay.hudH = hudH; lay.kx = kx; lay.ky = ky; lay.fx0 = (Wd - 100 * kx) / 2; lay.fy1 = Ht - hudH;
      const cw = Math.min(Wd - 8, 540 * ui), gap = 5 * ui, w = (cw - gap * 2) / 3, x0 = (Wd - cw) / 2, y0 = lay.fy1 + 5 * ui, ch = hudH - 9 * ui, sw = Math.max(44, w * 0.36);
      lay.cards = [0, 1, 2].map((i) => ({ x: x0 + i * (w + gap), y: y0, w, h: ch, sx: x0 + i * (w + gap) + w - sw, sw }));
      const bw = Math.max(46, 15 * kx), bh2 = Math.max(46, 13 * ky);   // 일제 사격 단추: 사수 사이 빈 자리 두 곳(어느 엄지로든)
      lay.burst = [35, 65].map((x) => ({ x: lay.fx0 + x * kx - bw / 2, y: lay.fy1 - 10.5 * ky - bh2 / 2, w: bw, h: bh2 }));
      lay.burstHi = [35, 65].map((x) => ({ x: lay.fx0 + x * kx - bw / 2, y: lay.fy1 - 47 * ky - bh2 / 2, w: bw, h: bh2 }));   // 사수 그림이 켜졌을 때: 그림을 가리지 않게 방벽 위 머리 사이로 올림
      box.style.setProperty('--u', String(Math.min(ui, 1.5)));
      bgKey = ''; cache = {}; if (strip) strip.cv = null; fitPick();
    }
    C.onresize = relayout; relayout();

    /* ── 입력 ── */
    const toField = (p) => [clamp((p.x - lay.fx0) / lay.kx, 2, 98), clamp(130 - (lay.fy1 - p.y) / lay.ky, 12, 98)];
    const inR = (p, r) => r && p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h;
    function nearEnemy(x, y, R) { let b = null, bd = R; if (!g) return null; for (const e of g.en) { if (e.dead || e.cl > 0.5 || e.st === 'flee') continue; const d = Math.hypot(e.x - x, (e.y - y) * 0.8); if (d < bd) { bd = d; b = e; } } return b; }
    function onDown(ev) {
      if (dead || !g || isBot || ov) return;
      const p = C.local(ev); mouse = ev.pointerType === 'mouse';
      if (g.ph === 'fight') {
        if (S.burstReady(g) && (inR(p, burstR()[0]) || inR(p, burstR()[1]))) { inp.burst = true; api.sfx('click'); ev.preventDefault(); return; }
        if (p.y >= lay.fy1) {
          for (let i = 0; i < 3; i++) { const c = lay.cards[i]; if (!inR(p, c)) continue; const sh = g.sq[i]; if (sh.down) { api.toast(sh.n + ': 쓰러짐 — 다음 구간에 복귀'); return; } if (p.x >= c.sx) { if (sh.g >= 100) inp.sk = i; else api.toast('기술 충전 ' + Math.floor(sh.g) + '%'); } else if (i !== g.act) inp.sw = i; api.sfx('click'); }
          ev.preventDefault(); return;
        }
        if (mouse && ev.button === 2) { inp.sk = g.act; return; }
      }
      if (firePtr != null) return;
      firePtr = ev.pointerId; lastP = p; inp.down = true;
      try { C.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      if (mouse) { const f = toField(p); inp.ax = f[0]; inp.ay = f[1]; }
      else if (state.o.aim === 'direct') { const f = toField({ x: p.x, y: p.y - 78 * lay.ui }); inp.ax = f[0]; inp.ay = f[1]; }
      else if (state.o.assist && g.ph === 'fight' && !nearEnemy(inp.ax, inp.ay, 12)) { const t = S.autoTarget(g, g.sq[g.act], 0); if (t) { inp.ax = t.x; inp.ay = t.y; } }
      ev.preventDefault();
    }
    function onMove(ev) {
      if (dead || !g || isBot) return;
      const p = C.local(ev);
      if (ev.pointerType === 'mouse') { mouse = true; const f = toField(p); inp.ax = f[0]; inp.ay = f[1]; return; }
      if (ev.pointerId !== firePtr) return;
      if (state.o.aim === 'direct') { const f = toField({ x: p.x, y: p.y - 78 * lay.ui }); inp.ax = f[0]; inp.ay = f[1]; }
      else { inp.ax = clamp(inp.ax + (p.x - lastP.x) / lay.kx * 1.35, 2, 98); inp.ay = clamp(inp.ay + (p.y - lastP.y) / lay.ky * 1.35, 12, 98); }
      lastP = p;
    }
    function onUp(ev) { if (ev.pointerId === firePtr) { firePtr = null; inp.down = false; } }
    const release = () => { firePtr = null; inp.down = false; };
    C.cv.addEventListener('pointerdown', onDown); C.cv.addEventListener('pointermove', onMove); C.cv.addEventListener('pointerup', onUp); C.cv.addEventListener('pointercancel', onUp);
    G.addEventListener('blur', release); G.addEventListener('lounge-pause', release);
    const offIn = api.input.on((type, id) => {
      if (type !== 'down' || !g || isBot) return;
      const n = id === 's1' ? 0 : id === 's2' ? 1 : id === 's3' ? 2 : -1;
      if (g.ph === 'up') { if (n >= 0 && performance.now() - upAt > 450) { inp.up = n; api.sfx('click'); } return; }
      if (g.ph !== 'fight') return;
      if (n >= 0) inp.sw = n; else if (id === 'skill') inp.sk = g.act; else if (id === 'burst') inp.burst = true; else if (id === 'k1') inp.sk = 0; else if (id === 'k2') inp.sk = 1; else if (id === 'k3') inp.sk = 2;
    });

    /* ── 고르기 창(분대 · 강화) ── */
    function closeOv() { if (lb) { lb.remove(); lb = null; } if (ov) { ov.remove(); ov = null; } ovKey = ''; pickFit = null; }
    function bustCv(look, w, hh) { const cv = doc.createElement('canvas'), dpr = Math.max(2, Math.min(G.devicePixelRatio || 1, 3)); cv.width = w * dpr; cv.height = hh * dpr; const c = cv.getContext('2d'); c.scale(dpr, dpr); A.bust(c, 0, 0, w, hh, look); return cv; }
    function fitPick() { if (pickFit && ov && ovKey === 'pick') pickFit(); }
    function showBig(src) {   // 초상 크게 보기(아무 곳이나 누르면 닫힘)
      if (lb) lb.remove();
      lb = h('div', { class: 'cvs-lb', onclick() { if (lb) { lb.remove(); lb = null; } } }, h('img', { src, alt: '' })); box.append(lb);
    }
    function openPick() {
      closeOv(); ovKey = 'pick';
      const sel = []; let foc = D.SHOOTERS[0].id;
      const pt = h('img', { class: 'cvs-pt', alt: '', onclick() { if (pt.src) showBig(pt.src); } }), dtx = h('div', { class: 'cvs-dtx' }), det = h('div', { class: 'cvs-det' }, pt, dtx);
      const go = h('button', { class: 'btn primary', text: '출격', onclick() { if (sel.length === 3) { inp.pick = sel.slice(); api.sfx('click'); closeOv(); } else api.toast('사수 셋을 골라 주세요'); } });
      const cards = D.SHOOTERS.map((s) => {
        const cv = bustCv(s.look, 64, 52), bd = h('div', { class: 'cvs-bd' }), im = h('div', { class: 'cvs-im' });
        artLater('portrait', s.id, (q) => { im.style.backgroundImage = 'url("' + q.src + '")'; im._ar = q.naturalWidth / q.naturalHeight; fitPick(); });
        const b = h('button', { class: 'cvs-card', onclick() { foc = s.id; const i = sel.indexOf(s.id); if (i >= 0) sel.splice(i, 1); else if (sel.length < 3) { sel.push(s.id); art('fire', s.id); art('cover', s.id); } else api.toast('이미 셋을 골랐습니다. 고른 사수를 눌러 빼세요'); api.sfx('click'); render(); } },
          cv, im, h('div', { class: 'cvs-cap' }, h('div', { class: 'cvs-nm', text: s.n }), h('div', { class: 'cvs-cl', text: D.WCLS[W[s.w].cls].n })), bd);
        return { s, b, bd, im };
      });
      function render() {
        cards.forEach((c) => { const i = sel.indexOf(c.s.id); c.b.classList.toggle('on', i >= 0); c.b.classList.toggle('foc', c.s.id === foc); c.bd.style.display = i >= 0 ? 'flex' : 'none'; c.bd.textContent = i >= 0 ? String(i + 1) : ''; });
        const s = SHD[foc], w = W[s.w];
        const pim = art('portrait', s.id); if (pim) { pt.src = pim.src; pt.style.display = ''; } else { pt.removeAttribute('src'); pt.style.display = 'none'; artLater('portrait', s.id, () => { if (ov && ovKey === 'pick' && foc === s.id) render(); }); }
        dtx.innerHTML = '';
        dtx.append(h('div', {}, h('b', { text: s.n }), ' · ' + s.role + ' · 체력 ' + s.hp), h('div', { text: w.n + ' — ' + D.wLine(w) }), h('div', {}, '기술 ', h('b', { text: s.sk.n }), ': ' + s.sk.d));
        go.textContent = sel.length === 3 ? '출격' : '출격 (' + sel.length + ' / 3)'; go.style.opacity = sel.length === 3 ? '1' : '.55';
      }
      const grid = h('div', { class: 'cvs-grid' }, cards.map((c) => c.b));
      ov = h('div', { class: 'cvs-ov' }, h('div', { class: 'cvs-pick' },
        h('div', { class: 'cvs-hd' }, h('h3', { text: '분대 편성' }), h('div', { class: 'cvs-sub', text: '사수 셋을 고르세요. 고른 순서대로 왼쪽부터 섭니다.' })),
        grid, det,
        h('div', { class: 'cvs-bt' }, h('div', { class: 'cvs-row' }, h('button', { class: 'btn', text: '무작위', onclick() { const pool = D.SHOOTERS.map((s) => s.id); sel.length = 0; while (sel.length < 3) sel.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]); foc = sel[0]; api.sfx('click'); render(); } }), go),
          h('div', { class: 'cvs-sub', text: '누르고 있기: 사격 · 떼기: 엄폐와 장전' }))));
      pickFit = () => {   // 화면 크기에 맞춰 초상 칸을 가능한 한 크게(PC 넓은 화면은 큰 초상 + 3×3 칸을 나란히)
        const u = Math.min(lay.ui, 1.5), wide = lay.W >= 680 && lay.H <= lay.W * 1.15;
        ov.style.setProperty('--u', String(u)); ov.classList.toggle('wide', wide);
        const Hu = lay.H / u, ph = wide ? clamp((Hu - 190) / 3, 96, 190) : clamp((Hu - 318) / 3, 96, 170);
        ov.style.setProperty('--ph', (ph * u).toFixed(1) + 'px'); ov.style.setProperty('--bh', (wide ? Math.min(lay.H * 0.6, lay.W * 0.5) : 0).toFixed(1) + 'px');
        const cw = grid.clientWidth ? (grid.clientWidth - 12 * u) / 3 : 110 * u, ch = ph * u;
        for (const c of cards) {   // 얼굴이 칸 위쪽 가운데에 오게 배경 그림을 맞춤
          const f = (D.ART.focus && D.ART.focus.portrait && D.ART.focus.portrait[c.s.id]) || [0.5, 0.3, 1], ar = c.im._ar || 0.75;
          const iw = Math.max(cw * 1.3 * Math.min(1, f[2] + 0.12), ch * ar * 0.9), ih = iw / ar;
          c.im.style.backgroundSize = iw.toFixed(1) + 'px ' + ih.toFixed(1) + 'px';
          c.im.style.backgroundPosition = clamp(cw / 2 - f[0] * iw, cw - iw, 0).toFixed(1) + 'px ' + clamp(ch * 0.4 - f[1] * ih, ch - ih, 0).toFixed(1) + 'px';
        }
      };
      box.append(ov); pickFit(); render();
    }
    function openUp() {
      closeOv(); ovKey = 'up' + g.si + ':' + g.opts.join(','); upAt = performance.now();
      const pick = (i) => { if (performance.now() - upAt < 450) return; inp.up = i; api.sfx('click'); };
      const bossNext = g.si + 1 === g.N - 1 || (g.mid && g.si + 1 === g.mid - 1);
      ov = h('div', { class: 'cvs-ov' }, h('h3', { text: '강화 선택' }),
        h('div', { class: 'cvs-sub', text: g.done + '구간 돌파 · 다음 ' + (g.si + 2) + ' / ' + g.N + '구간' + (g.si + 1 === g.N - 1 ? ' — 우두머리(엄폐물 전부 수리 · 체력 +30%)' : bossNext ? ' — 중간 우두머리(엄폐물 +50% · 체력 +15%)' : '') }),
        g.opts.map((id, i) => {
          const u = D.UPG.find((x) => x.id === id), cur = g.up[id] || 0;
          return h('button', { class: 'cvs-upc', 'data-action': 's' + (i + 1), onclick: () => pick(i) },
            h('div', { class: 't' }, h('span', { text: u.n }), h('span', { class: 'g', text: u.g + (u.cls ? ' 전용' : '') }), h('span', { class: 'lv', text: (cur + 1) + ' / ' + D.UPG_MAX + '단계' })),
            u.t.map((x) => h('div', { class: 'l' }, x[0] + ': ', h('i', { text: x[1] }))));
        }),
        h('div', { class: 'cvs-sq' }, g.sq.map((s) => h('div', {}, s.n + ' ' + Math.ceil(s.hp) + ' / ' + s.mhp, h('div', { class: 'b' }, h('i', { style: { width: Math.round(100 * s.hp / s.mhp) + '%' } }))))),
        g.rr > 0 ? h('div', { class: 'cvs-row' }, h('button', { class: 'btn', text: '다시 뽑기 (한 판에 1회)', onclick() { if (performance.now() - upAt < 450) return; inp.reroll = true; api.sfx('click'); } })) : null);
      ov.style.setProperty('--u', String(Math.min(lay.ui, 1.5)));
      box.append(ov);
    }

    /* ── 시뮬 사건 → 연출 · 소리 ── */
    const float = (x, y, txt, col) => { fx.push({ k: 'float', x, y, txt, col, t: 0, T: 0.9 }); };
    const say = (txt, sub) => { note = { txt, sub: sub || '', t: 0, T: 1.5 }; };
    function pushPI() {
      if (!state || ended) return;
      const st = g.st, ms = D.MISSIONS[st.type];
      api.setState(Object.assign({}, state, { pi: [{ label: '구간', value: (g.si + 1) + ' / ' + g.N }, { label: '임무', value: st.type === 'boss' ? BS[st.boss].n : ms.n + ' — ' + ms.d }, { label: '전장', value: D.THEMES[st.theme].n }, { label: '분대', value: g.sq.map((s) => s.n).join(' · ') }, { label: '강화', value: g.ups.length + '개' }] }));
    }
    function onEv(e) {
      const own = e.s === g.act, fxm = L.fx ? L.fx() : 1;
      switch (e.t) {
        case 'shot': tr.push({ s: e.s, x: e.x, y: e.y, t: 0, T: e.w === 'sr' ? 0.16 : e.w === 'gl' ? 0.3 : 0.07, w: e.w, own }); flash[e.s] = 1; snd(e.w, own ? 1 : 0.4); if (own && e.h) hitMk = 1; break;
        case 'dmg': if (fx.length < 90) fx.push({ k: 'spark', x: e.x, y: e.y, t: 0, T: 0.14, w: e.w }); if ((e.w || e.c) && fx.length < 90) fx.push({ k: 'num', x: e.x, y: e.y - 8, d: Math.round(e.d), w: e.w, c: e.c, t: 0, T: 0.55 }); snd('hit'); break;
        case 'kill': fx.push({ k: 'puff', x: e.x, y: e.y, r: e.r, t: 0, T: e.boss ? 1.2 : 0.4, boss: e.boss }); snd(e.boss ? 'boom' : 'kill'); if (e.boss) { shake = Math.max(shake, 6 * fxm); flashW = 0.5 * fxm; } break;
        case 'boom': fx.push({ k: 'boom', x: e.x, y: e.y, r: e.r, p: e.p, t: 0, T: 0.42 }); snd('boom', e.p === 0 ? 1 : 0.6); if (e.p === 0) shake = Math.max(shake, 3.5 * fxm); break;
        case 'efire': { const en = g.en.find((q) => q.id === e.id); if (en) { let ox = en.x, oy = en.y; if (e.op >= 0 && en.parts && en.parts[e.op]) { ox += en.parts[e.op].ox * sc(en.y); oy += en.parts[e.op].oy * sc(en.y); } fx.push({ k: 'etr', x: ox, y: oy, s: e.s, prc: e.prc, t: 0, T: e.prc ? 0.22 : 0.09 }); } snd('efire', e.prc ? 2 : 1); break; }
        case 'hurt': if (own) { vig = 1; shake = Math.max(shake, 4 * fxm); api.buzz(25); } snd('hurt', own ? 1 : 0.5); float(SLOTX[e.s], COVY - 14, '−' + Math.max(1, Math.round(e.d)), '#ff7a6a'); break;
        case 'dodge': float(SLOTX[e.s], COVY - 4, '회피', '#9fe0b0'); break;
        case 'covhit': if (fx.length < 90) fx.push({ k: 'spark', x: SLOTX[e.s] + (A.hsh(simT * 60 | 0, e.s) - 0.5) * 12, y: COVY - 5, t: 0, T: 0.16, w: 0, cv: 1 }); snd('cov'); break;
        case 'covbreak': float(SLOTX[e.s], COVY + 2, '엄폐물 파괴', '#ffb070'); snd('boom', 0.6); break;
        case 'down': float(SLOTX[e.s], COVY - 20, g.sq[e.s].n + ' 쓰러짐', '#ff7a6a'); break;
        case 'revive': float(SLOTX[e.s], COVY - 20, g.sq[e.s].n + ' 복귀', '#9fe0b0'); break;
        case 'skill': strip = { s: e.s, n: e.n, t: 0, T: 0.85 }; snd('skill'); break;
        case 'burst': strip = { s: -1, n: '일제 사격', t: 0, T: 1.3 }; snd('skill'); snd('boom', 0.7); flashW = 0.45 * fxm; break;
        case 'lance': fx.push({ k: 'lance', x: e.x, s: e.s, t: 0, T: 0.4 }); snd('sr', 1.4); break;
        case 'blast': fx.push({ k: 'blast', s: e.s, t: 0, T: 0.45 }); snd('sg', 1.4); break;
        case 'heal': fx.push({ k: 'heal', x: e.x, y: e.y, x2: e.fx, y2: e.fy, t: 0, T: 0.45 }); break;
        case 'launch': snd('gl', 0.5); break;
        case 'pjkill': fx.push({ k: 'boom', x: e.x, y: e.y, r: 4, p: 2, t: 0, T: 0.3 }); snd('kill'); break;
        case 'stagger': float(e.x, e.y - 8, '차단', '#c8a0ff'); snd('cov'); break;
        case 'part': float(e.x, e.y - 6, e.n + ' 파괴', '#ffd27a'); fx.push({ k: 'boom', x: e.x, y: e.y, r: 8, p: 1, t: 0, T: 0.45 }); snd('boom', 0.8); break;
        case 'phase': say('우두머리 ' + e.n + '단계', '공격이 빨라집니다'); break;
        case 'boss': say(BS[e.k].n, g.st.mini ? '중간 우두머리' : '우두머리'); break;
        case 'stage': bgKey = ''; for (const q of g.sq) { art('fire', q.id); art('cover', q.id); } if (g.st.type !== 'boss') say((e.i + 1) + '구간 · ' + D.MISSIONS[g.st.type].n, D.MISSIONS[g.st.type].d); pushPI(); for (const k in warned) delete warned[k]; break;
        case 'clear': say('구간 돌파', ''); api.sfx('pop'); break;
        case 'sw': inp.ax = clamp(inp.ax, 2, 98); break;
        case 'rld': if (own) snd('rld'); break;
        case 'block': if (fx.length < 90) fx.push({ k: 'spark', x: e.x, y: e.y, t: 0, T: 0.14, w: 0, cv: 1 }); snd('cov', 0.6); break;
      }
    }

    /* ── 그리기 ── */
    const txt = (s, x, y, px, col, al, f, wt) => { ctx.font = (wt || 500) + ' ' + px + 'px ' + (f || FB); ctx.textAlign = al || 'left'; ctx.fillStyle = col; ctx.fillText(s, x, y); };
    const otxt = (s, x, y, px, col, al, f, wt) => { ctx.font = (wt || 600) + ' ' + px + 'px ' + (f || FB); ctx.textAlign = al || 'left'; ctx.lineWidth = Math.max(2, px * 0.22); ctx.strokeStyle = 'rgba(8,8,12,.8)'; ctx.lineJoin = 'round'; ctx.strokeText(s, x, y); ctx.fillStyle = col; ctx.fillText(s, x, y); };
    function bar(x, y, w, hh, f, col, back) { ctx.fillStyle = back || 'rgba(0,0,0,.55)'; A.rrect(ctx, x, y, w, hh, hh / 2); ctx.fill(); if (f > 0) { ctx.fillStyle = col; A.rrect(ctx, x, y, Math.max(hh, w * clamp(f, 0, 1)), hh, hh / 2); ctx.fill(); } }
    function ensureBg() {
      const st = g.st, th = D.THEMES[st ? st.theme : 0], im = art('bg', th.id), key = lay.W + 'x' + lay.H + ':' + (st ? st.theme + ':' + st.i : 'x') + (im ? ':i' : '');
      if (key === bgKey && bgC) return;
      bgKey = key;
      if (!bgC) bgC = doc.createElement('canvas');
      const dpr = C.dpr; bgC.width = Math.round(lay.W * dpr); bgC.height = Math.round(lay.H * dpr);
      const c = bgC.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
      A.bg(c, lay, th, (seed | 0) + (st ? st.i * 131 : 0));
      if (im) {   // 그림 배경: 전장 칸에 맞춰 늘리고, 어두운 막은 아래쪽(사수 자리)으로 갈수록만 옅게(전체를 덮지 않음)
        const bx = lay.X(0), by = lay.Y(6), bw = 100 * lay.kx, bh = 124 * lay.ky;
        c.imageSmoothingQuality = 'high';
        if (bx > 2) {   // 가로로 넓은 화면: 양옆은 같은 그림을 늘려 어둡게 깔고, 가운데 전장 그림은 가장자리를 흐려 잇는다
          c.drawImage(im, 0, by, lay.W, bh); c.fillStyle = 'rgba(10,11,16,.3)'; c.fillRect(0, by, lay.W, bh);
          const tc = doc.createElement('canvas'); tc.width = Math.max(1, Math.round(bw * dpr)); tc.height = Math.max(1, Math.round(bh * dpr));
          const t2 = tc.getContext('2d'); t2.imageSmoothingQuality = 'high'; t2.drawImage(im, 0, 0, tc.width, tc.height);
          const mg = t2.createLinearGradient(0, 0, tc.width, 0); mg.addColorStop(0, 'rgba(0,0,0,0)'); mg.addColorStop(0.16, '#000'); mg.addColorStop(0.84, '#000'); mg.addColorStop(1, 'rgba(0,0,0,0)');
          t2.globalCompositeOperation = 'destination-in'; t2.fillStyle = mg; t2.fillRect(0, 0, tc.width, tc.height);
          c.drawImage(tc, bx, by, bw, bh);
        } else c.drawImage(im, bx, by, bw, bh);
        const tg = c.createLinearGradient(0, by, 0, by + bh * 0.07); const fc = parseInt(th.far.slice(1), 16), frgb = (fc >> 16) + ',' + ((fc >> 8) & 255) + ',' + (fc & 255); tg.addColorStop(0, 'rgba(' + frgb + ',1)'); tg.addColorStop(1, 'rgba(' + frgb + ',0)'); c.fillStyle = tg; c.fillRect(0, by, lay.W, bh * 0.07);   // 위 가장자리는 먼 풍경 색으로 이음
        const gr = c.createLinearGradient(0, by, 0, by + bh); gr.addColorStop(0, 'rgba(10,11,16,0)'); gr.addColorStop(0.45, 'rgba(10,11,16,.08)'); gr.addColorStop(0.78, 'rgba(10,11,16,.2)'); gr.addColorStop(1, 'rgba(10,11,16,.3)'); c.fillStyle = gr; c.fillRect(bx, by, bw, bh);
      }
    }
    /* ── 사수 그림(뒷모습 두 자세: 사격 fire · 엄폐 cover) ──
       ART.figm[id] = { f: [키 비율, 발 가운데 x, 총구 x, 총구 y], c: [키 비율, 발 가운데 x, 가라앉힘] } — x · y는 그림 크기에 대한 비율, 그림 아래 끝이 발.
       가라앉힘: 엄폐 그림의 아래쪽(군화 · 허리 아래)을 그 비율만큼 아래 사수 카드 띠 밑으로 내려 가림 */
    const FIGH = 44, FIGY = 129;   // 서 있는 사수의 키(전장 세로 단위) · 발 자리
    function figReady() { if (!g.sq || g.sq.length < 3 || !D.ART.figm) return false; let ok = true; for (const sh of g.sq) if (!D.ART.figm[sh.id] || !art('fire', sh.id) || !art('cover', sh.id)) ok = false; return ok; }
    function figSprite(kind, id, im, hh) { const px = Math.round(hh * C.dpr); return cached('f:' + kind + ':' + id + ':' + px, () => { const cv = shrink(im, 0, 0, im.naturalWidth, im.naturalHeight, px * im.naturalWidth / im.naturalHeight, px); return { cv, rd: tinted(cv, '#ff4638'), dk: tinted(cv, '#0a0b12') }; }); }
    function drawFig(i, sh, pose, t) {
      const id = sh.id, m = D.ART.figm[id], imF = art('fire', id), imC = art('cover', id), ui = lay.ui;
      const Hs = FIGH * lay.ky, x0 = lay.X(SLOTX[i]), y0 = lay.Y(FIGY), e = pose * pose * (3 - 2 * pose), dn = downK[i], act = i === g.act;
      const br = Math.sin(t * 1.7 + i * 2.1), dim = (act ? 0 : 0.16) + dn * 0.4, rec = sh.rec || 0;
      ctx.fillStyle = 'rgba(0,0,0,.34)'; ctx.beginPath(); ctx.ellipse(x0, y0 - 0.012 * Hs, 0.2 * Hs, 0.028 * Hs, 0, 0, TAU); ctx.fill();
      if (act && !sh.down) { ctx.strokeStyle = 'rgba(227,174,69,.9)'; ctx.lineWidth = 2 * ui; ctx.beginPath(); ctx.ellipse(x0, y0 - 0.012 * Hs, 0.24 * Hs, 0.034 * Hs, 0, 0, TAU); ctx.stroke(); }
      if (sh.bT > 0) { ctx.strokeStyle = 'rgba(227,174,69,' + (0.5 + 0.3 * Math.sin(t * 4)).toFixed(2) + ')'; ctx.lineWidth = 1.6 * ui; ctx.beginPath(); ctx.ellipse(x0, y0 - 0.012 * Hs, 0.28 * Hs, 0.042 * Hs, 0, 0, TAU); ctx.stroke(); }
      const one = (kind, im, mm, a, dy, rot, sy) => {
        if (a <= 0.01) return;
        const hh = Hs * mm[0], w = hh * im.naturalWidth / im.naturalHeight, sp = figSprite(kind, id, im, hh);
        ctx.save(); ctx.translate(x0, y0 + dy); ctx.rotate(rot); ctx.scale(1, sy);
        ctx.globalAlpha = a; ctx.drawImage(sp.cv, -w * mm[1], -hh, w, hh);
        if (dim > 0.01) { ctx.globalAlpha = a * dim; ctx.drawImage(sp.dk, -w * mm[1], -hh, w, hh); }
        if (sh.fl > 0.01) { ctx.globalAlpha = a * Math.min(1, sh.fl) * 0.36; ctx.drawImage(sp.rd, -w * mm[1], -hh, w, hh); }
        ctx.restore();
      };
      // 숨쉬기 · 쓰러짐(기울며 흐려짐) · 엄폐↔사격은 두 그림을 겹쳐 넘김(나오는 그림이 먼저 또렷해지고 들어가는 그림이 뒤에서 사라짐)
      const bob = br * 0.004 * Hs, sq = 1 + br * 0.004, rotD = dn * 0.32 * (i === 0 ? -1 : 1), aM = 1 - 0.45 * dn, dyD = dn * 0.04 * Hs;
      const lean = clamp((sh.ax - SLOTX[i]) / 70, -1, 1) * 0.05 * e;
      one('cover', imC, m.c, clamp((1 - e) * 2, 0, 1) * aM, bob + dyD - e * 0.03 * Hs + (m.c[2] || 0) * m.c[0] * Hs, rotD, sq);
      const dyF = bob + dyD + (1 - e) * 0.12 * Hs + rec * 0.014 * Hs, rotF = lean + rotD - rec * 0.012 * (lean >= 0 ? 1 : -1), syF = sq * (1 - rec * 0.012);
      one('fire', imF, m.f, clamp(e * 2, 0, 1) * aM, dyF, rotF, syF);
      // 총구 자리(탄 궤적 · 섬광의 시작점)
      const hh = Hs * m.f[0], w = hh * imF.naturalWidth / imF.naturalHeight, lx = (m.f[2] - m.f[1]) * w, ly = -(1 - m.f[3]) * hh * syF, cs = Math.cos(rotF), sn = Math.sin(rotF);
      const mx = x0 + lx * cs - ly * sn, my = y0 + dyF + lx * sn + ly * cs; mz[i].x = mx; mz[i].y = my;
      if (flash[i] > 0 && pose > 0.8) {
        const a = flash[i], r = (7 + a * 11) * ui * (sh.cls === 'sg' || sh.cls === 'sr' ? 1.45 : 1), gr = ctx.createRadialGradient(mx, my, 0, mx, my, r * 1.6);
        gr.addColorStop(0, 'rgba(255,250,225,' + (a * 0.95).toFixed(3) + ')'); gr.addColorStop(0.35, 'rgba(255,214,130,' + (a * 0.7).toFixed(3) + ')'); gr.addColorStop(1, 'rgba(255,170,70,0)');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(mx, my, r * 1.6, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(255,246,214,' + (a * 0.9).toFixed(3) + ')'; ctx.beginPath();
        for (let k = 0; k < 8; k++) { const an = k * 0.7854 + i, rr = k % 2 ? r * 0.28 : r * (k % 4 ? 0.8 : 1.25); ctx.lineTo(mx + Math.cos(an) * rr, my + Math.sin(an) * rr); }
        ctx.closePath(); ctx.fill();
      }
    }
    function coverBig(cx, c, i) {   // 사수 그림에 맞춘 높은 방벽(판정 자리는 그대로, 모습만 큼)
      const kx = lay.kx, ui = lay.ui, yT = lay.Y(90), yB = lay.Y(121), hh = yB - yT, wT = 12.2 * kx, wB = 13.8 * kx, ratio = c.hp / c.mhp, sd = (seed | 0) + i * 17;
      ctx.fillStyle = 'rgba(0,0,0,.34)'; ctx.beginPath(); ctx.ellipse(cx, yB, wB * 1.1, hh * 0.07, 0, 0, TAU); ctx.fill();
      if (ratio <= 0) {
        for (let k = 0; k < 8; k++) { const rx = (A.hsh(sd, k) - 0.5) * 2 * wB, rw = (0.12 + A.hsh(sd, k + 9) * 0.16) * wB, rh = rw * (0.7 + A.hsh(sd, k + 20) * 0.9); ctx.fillStyle = k % 2 ? '#5a5a5c' : '#46464a'; ctx.beginPath(); ctx.moveTo(cx + rx - rw, yB); ctx.lineTo(cx + rx - rw * 0.4, yB - rh); ctx.lineTo(cx + rx + rw * 0.6, yB - rh * 0.7); ctx.lineTo(cx + rx + rw, yB); ctx.fill(); }
        return;
      }
      const shape = () => { ctx.beginPath(); ctx.moveTo(cx - wT, yT); ctx.lineTo(cx + wT, yT); ctx.lineTo(cx + wB, yB); ctx.lineTo(cx - wB, yB); ctx.closePath(); };
      const gr = ctx.createLinearGradient(0, yT, 0, yB); gr.addColorStop(0, '#b4b3ac'); gr.addColorStop(0.45, '#8b8a84'); gr.addColorStop(1, '#55544f');
      ctx.fillStyle = gr; shape(); ctx.fill();
      ctx.save(); shape(); ctx.clip();
      ctx.fillStyle = 'rgba(255,255,255,.2)'; ctx.fillRect(cx - wB, yT, wB * 2, hh * 0.045);
      const sy = yT + hh * 0.13, sh2 = hh * 0.15; ctx.fillStyle = '#2c2c2e'; ctx.fillRect(cx - wB, sy, wB * 2, sh2);
      ctx.fillStyle = '#d2a93c'; for (let k = -5; k <= 5; k++) { const x = cx + k * wT * 0.22; ctx.beginPath(); ctx.moveTo(x, sy); ctx.lineTo(x + wT * 0.11, sy); ctx.lineTo(x + wT * 0.11 - sh2 * 0.6, sy + sh2); ctx.lineTo(x - sh2 * 0.6, sy + sh2); ctx.fill(); }
      ctx.fillStyle = 'rgba(0,0,0,.16)'; ctx.fillRect(cx - wB, yT + hh * 0.36, wB * 2, 1.5 * ui); ctx.fillRect(cx - 0.75 * ui, yT + hh * 0.36, 1.5 * ui, hh);
      const n = Math.round((1 - ratio) * 10); ctx.strokeStyle = 'rgba(26,24,26,.85)'; ctx.lineWidth = 1.4 * ui; ctx.lineJoin = 'round';
      for (let k = 0; k < n; k++) { const x = cx + (A.hsh(sd, k * 3) - 0.5) * 1.8 * wT, y = yT + A.hsh(sd, k * 3 + 1) * hh * 0.5; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (A.hsh(sd, k + 30) - 0.5) * wT * 0.3, y + hh * 0.07); ctx.lineTo(x + (A.hsh(sd, k + 60) - 0.5) * wT * 0.42, y + hh * 0.16); ctx.stroke(); }
      if (c.fl > 0) { ctx.fillStyle = 'rgba(255,240,200,' + (c.fl * 0.5).toFixed(3) + ')'; ctx.fillRect(cx - wB, yT, wB * 2, hh); }
      ctx.restore();
      ctx.strokeStyle = '#2a2a2c'; ctx.lineWidth = 1.5 * ui; shape(); ctx.stroke();
      if (ratio < 0.5) { ctx.fillStyle = '#26262a'; ctx.beginPath(); ctx.moveTo(cx + wT * 0.42, yT - 1); ctx.lineTo(cx + wT + 1, yT - 1); ctx.lineTo(cx + wT * 1.04, yT + hh * 0.15); ctx.lineTo(cx + wT * 0.7, yT + hh * 0.06); ctx.fill(); }
      if (ratio < 0.25) { ctx.fillStyle = '#26262a'; ctx.beginPath(); ctx.moveTo(cx - wT - 1, yT - 1); ctx.lineTo(cx - wT * 0.5, yT - 1); ctx.lineTo(cx - wT * 0.72, yT + hh * 0.1); ctx.lineTo(cx - wT * 1.04, yT + hh * 0.2); ctx.fill(); }
      if (g.bf.fort > 0) { ctx.strokeStyle = 'rgba(184,206,224,.85)'; ctx.lineWidth = 2.4 * ui; ctx.beginPath(); ctx.ellipse(cx, yT + hh * 0.42, wB * 1.08, hh * 0.56, 0, Math.PI, TAU); ctx.stroke(); }
    }
    function drawThreat(th, t) {
      const src = g.en.find((q) => q.id === th.src); if (!src) return;
      const s = sc(src.y), ui = lay.ui, mine = th.slot === g.act, f = clamp(th.t / th.T, 0, 1), firing = th.t >= th.T;
      let ox = src.x, oy = src.y - (src.boss ? 0 : src.r * s * 0.2);
      if (th.op >= 0 && src.parts && src.parts[th.op]) { ox = src.x + src.parts[th.op].ox * s; oy = src.y + src.parts[th.op].oy * s; }
      const x1 = lay.X(ox), y1 = lay.Y(oy), x2 = lay.X(SLOTX[th.slot]), y2 = lay.Y(COVY - 3), pulse = 0.5 + 0.5 * Math.sin(t * 5);
      if (th.k === 'wind') { ctx.strokeStyle = 'rgba(255,170,70,' + (0.4 + 0.5 * f).toFixed(2) + ')'; ctx.lineWidth = 2 * ui; ctx.beginPath(); ctx.arc(x1, y1 - src.r * s * lay.kx * 1.7, 5 * ui, Math.PI, Math.PI + Math.PI * f); ctx.stroke(); return; }
      const col = th.k === 'prc' ? '200,140,255' : th.k === 'flk' ? '255,220,120' : '255,70,60';
      const a = (mine ? 0.3 : 0.16) + f * (mine ? 0.6 : 0.32);
      if (th.k === 'sup') { const hw = 3.2 * lay.kx; ctx.fillStyle = 'rgba(' + col + ',' + (firing ? 0.3 + 0.1 * pulse : 0.05 + f * 0.17).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2 - hw, y2); ctx.lineTo(x2 + hw, y2); ctx.closePath(); ctx.fill(); }
      ctx.strokeStyle = 'rgba(' + col + ',' + (firing ? 1 : a).toFixed(3) + ')'; ctx.lineWidth = ((mine ? 1.2 : 0.8) + f * (th.k === 'prc' ? 3.4 : 2.1) + (firing ? 1 : 0)) * ui;
      if (th.k === 'flk') ctx.setLineDash([6 * ui, 5 * ui]);
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); ctx.setLineDash([]);
      // 표적 쪽 고리: 닫히면 발사
      const rr2 = lerp(10, 2.6, f) * lay.kx;
      ctx.lineWidth = (mine ? 2.4 : 1.4) * ui; ctx.strokeStyle = 'rgba(' + col + ',' + (mine ? 0.55 + 0.4 * f : 0.3 + 0.3 * f).toFixed(3) + ')';
      ctx.beginPath(); ctx.arc(x2, y2, rr2, 0, TAU); ctx.stroke();
      if (mine && f > 0.72 && !firing) { ctx.strokeStyle = 'rgba(255,255,255,' + (0.35 + 0.4 * pulse).toFixed(2) + ')'; ctx.lineWidth = 1.2 * ui; ctx.beginPath(); ctx.arc(x2, y2, rr2 + 3 * ui, 0, TAU); ctx.stroke(); }
      if (th.stg > 0) { const bw = 34 * ui; bar(x1 - bw / 2, y1 - src.r * s * lay.kx * (src.boss ? 0.2 : 1.9) - 10 * ui, bw, 5 * ui, 1 - th.acc / th.stg, 'rgb(' + col + ')'); otxt('끊기', x1, y1 - src.r * s * lay.kx * (src.boss ? 0.2 : 1.9) - 13 * ui, 12 * ui, 'rgb(' + col + ')', 'center'); }
      if (th.k === 'flk') { const sd = SLOTX[th.slot] < 50 ? -1 : 1, ax = lay.X(SLOTX[th.slot] + sd * 13), ay = y2 + 6 * lay.ky; ctx.strokeStyle = 'rgba(' + col + ',' + (0.5 + 0.4 * pulse).toFixed(2) + ')'; ctx.lineWidth = 2.4 * ui; for (let i = 0; i < 3; i++) { const cx = ax - sd * i * 7 * ui; ctx.beginPath(); ctx.moveTo(cx + sd * 5 * ui, ay - 6 * ui); ctx.lineTo(cx, ay); ctx.lineTo(cx + sd * 5 * ui, ay + 6 * ui); ctx.stroke(); } }
    }
    function drawField(now, alpha) {
      const t = now / 1000, ui = lay.ui, kx = lay.kx, X = lay.X, Y = lay.Y;
      ensureBg(); ctx.drawImage(bgC, 0, 0, lay.W, lay.H);
      for (const z of g.zn) if (z.k === 'smk') { const a = Math.min(1, z.t * 2, (z.T - z.t) * 1.5) * 0.5; for (let i = 0; i < 5; i++) { const ox = Math.sin(i * 2.1 + t * 0.3) * z.R * 0.5, oy = Math.cos(i * 1.7 + t * 0.25) * z.R * 0.25; ctx.fillStyle = 'rgba(190,196,204,' + (a * 0.5).toFixed(3) + ')'; ctx.beginPath(); ctx.ellipse(X(z.x + ox), Y(z.y + oy), z.R * 0.7 * kx * sc(z.y), z.R * 0.45 * lay.ky * sc(z.y), 0, 0, TAU); ctx.fill(); } }
      const list = g.en.slice().sort((a, b) => a.y - b.y);
      for (const e of list) {
        const ex = lerp(e.px, e.x, alpha), ey = lerp(e.py, e.y, alpha), s = sc(ey), x = X(ex), y = Y(ey);
        if (e.boss) {
          const im = art('boss', e.k);
          if (im) { const w = e.r * 3.2 * s * kx; ctx.globalAlpha = 1 - 0.78 * clamp(e.cl, 0, 1); ctx.drawImage(im, x - w / 2, y - w / 2, w, w); ctx.globalAlpha = 1; }
          else A.boss(ctx, e, x, y, s * kx, s * lay.ky, t);
          for (const p of e.parts) if (p.hp > 0 && p.hp < p.mhp) { const px = x + p.ox * s * kx, py = y + p.oy * s * lay.ky; bar(px - 11 * ui, py - p.r * s * lay.ky - 7 * ui, 22 * ui, 3.5 * ui, p.hp / p.mhp, '#ffd27a'); }
          if (e.stg > 0) otxt('무력화', x, y - e.r * s * lay.ky - 6 * ui, 12 * ui, '#ffd27a', 'center');
          continue;
        }
        const R = e.r * s * kx;
        A.enemy(ctx, e, x, y, R, t);
        const top = y - R * (e.d.fly ? 0.9 : 1.75);
        if (e.cl < 0.5) {
          if (e.hp < e.mhp) bar(x - R, top - 5 * ui, R * 2, 3 * ui, e.hp / e.mhp, e.hvt ? '#ffd27a' : '#ff8a70');
          if (e.pr < 1) { ctx.strokeStyle = 'rgba(127,224,240,.75)'; ctx.lineWidth = 1.5 * ui; ctx.beginPath(); ctx.ellipse(x, y, R * 1.15, R * 1.5, 0, 0, TAU); ctx.stroke(); }
          if (e.hs > 1) { ctx.strokeStyle = 'rgba(240,210,90,.9)'; ctx.lineWidth = 1.6 * ui; ctx.beginPath(); ctx.moveTo(x - 4 * ui, top - 8 * ui); ctx.lineTo(x, top - 12 * ui); ctx.lineTo(x + 4 * ui, top - 8 * ui); ctx.stroke(); }
          if (e.sn > 0) otxt('기절', x, top - 8 * ui, 12 * ui, '#c8d0e0', 'center');
          if (e.hvt) { ctx.fillStyle = '#ffd27a'; ctx.beginPath(); ctx.moveTo(x, top - 10 * ui); ctx.lineTo(x - 5 * ui, top - 17 * ui); ctx.lineTo(x, top - 24 * ui); ctx.lineTo(x + 5 * ui, top - 17 * ui); ctx.fill(); }
        }
      }
      // 엄폐물 · 사수(그림이 다 불러와졌으면 큰 뒷모습 그림, 아니면 코드 인형)
      const big = figReady(); bigOn = big;
      for (let i = 0; i < 3; i++) {
        const c = g.cov[i], cx = X(SLOTX[i]), cy = Y(COVY);
        if (big) { coverBig(cx, c, i); continue; }
        A.cover(ctx, cx, cy, kx, c.hp / c.mhp, c.fl, (seed | 0) + i * 17);
        if (g.bf.fort > 0) { ctx.strokeStyle = 'rgba(184,196,204,.8)'; ctx.lineWidth = 2 * ui; ctx.beginPath(); ctx.ellipse(cx, cy + 4 * kx, 12.5 * kx, 7 * kx, 0, Math.PI, TAU); ctx.stroke(); }
      }
      const ord = [0, 1, 2].filter((i) => i !== g.act); ord.push(g.act);
      for (const i of ord) {
        const sh = g.sq[i]; if (!sh) continue;
        const pose = lerp(sh.pp, sh.pose, alpha);
        if (big) { drawFig(i, sh, pose, t); continue; }
        const fxp = X(SLOTX[i]), fyp = Y(FEETY), ang = Math.atan2(Y(sh.ay) - Y(COVY), X(sh.ax) - fxp);
        const m = A.shooter(ctx, fxp, fyp, kx, SHD[sh.id].look, sh.cls, pose, ang, sh.rec, t, { active: i === g.act, down: sh.down, fl: sh.fl });
        mz[i].x = m.x; mz[i].y = m.y;
        if (flash[i] > 0 && pose > 0.8) { const a = flash[i], r = (3 + a * 5) * ui * (sh.cls === 'sg' || sh.cls === 'sr' ? 1.5 : 1); ctx.fillStyle = 'rgba(255,224,150,' + (a * 0.9).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(m.x, m.y, r, 0, TAU); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,' + (a * 0.8).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(m.x, m.y, r * 0.45, 0, TAU); ctx.fill(); }
        if (sh.bT > 0) { ctx.strokeStyle = 'rgba(227,174,69,' + (0.5 + 0.3 * Math.sin(t * 4)).toFixed(2) + ')'; ctx.lineWidth = 1.6 * ui; ctx.beginPath(); ctx.ellipse(fxp, fyp + 0.4 * kx, 7.4 * kx, 2 * kx, 0, 0, TAU); ctx.stroke(); }
        if (!sh.down && i !== g.act) { bar(fxp - 7 * kx, fyp + 2.2 * kx, 14 * kx, 3 * ui, sh.hp / sh.mhp, sh.hp / sh.mhp < 0.35 ? '#ff7a6a' : '#6ad08a'); }
      }
      for (const z of g.zn) if (z.k === 'burn') { const cx = X(SLOTX[z.slot]), cy = Y(big ? FIGY - 1 : COVY + 12), a = Math.min(1, z.t * 3, (z.T - z.t) * 2); for (let i = 0; i < 6; i++) { const fxp = cx + (i - 2.5) * 3.2 * kx, hh = (5 + 2.5 * Math.sin(t * 6 + i * 1.9)) * kx * (big ? 1.5 : 1); ctx.fillStyle = 'rgba(255,' + (120 + i * 14) + ',40,' + (0.55 * a).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(fxp - 1.8 * kx, cy); ctx.quadraticCurveTo(fxp + Math.sin(t * 4 + i) * kx, cy - hh, fxp + 1.8 * kx, cy); ctx.fill(); } }
      for (const th of g.th) if (!th.dead) drawThreat(th, t);
      // 날아오는 것
      for (const p of g.pj) {
        if (p.dead || p.t < 0) continue;
        const f = clamp(p.t / p.T, 0, 1), px = X(lerp(p.px, p.x, alpha)), py = Y(lerp(p.py, p.y, alpha)), mine = p.slot === g.act, pulse = 0.5 + 0.5 * Math.sin(t * 5);
        if (p.k === 'lob') {
          const cx = X(SLOTX[p.slot]), cy = Y(COVY + 9), rx = 9.5 * kx, ry = 3.4 * lay.ky, col = p.burn ? '255,120,50' : '255,170,70';
          ctx.fillStyle = 'rgba(' + col + ',' + (0.08 + 0.14 * f).toFixed(3) + ')'; ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU); ctx.fill();
          ctx.strokeStyle = 'rgba(' + col + ',' + (mine ? 0.75 + 0.2 * pulse : 0.5).toFixed(2) + ')'; ctx.lineWidth = (mine ? 2.4 : 1.5) * ui; ctx.beginPath(); ctx.ellipse(cx, cy, rx, ry, 0, 0, TAU); ctx.stroke();
          ctx.beginPath(); ctx.ellipse(cx, cy, rx * (1 - f), ry * (1 - f), 0, 0, TAU); ctx.stroke();
          ctx.fillStyle = '#1c1c20'; ctx.strokeStyle = 'rgb(' + col + ')'; ctx.lineWidth = 1.5 * ui; ctx.beginPath(); ctx.arc(px, py, (2.2 + f * 2.6) * ui, 0, TAU); ctx.fill(); ctx.stroke();
        } else {
          const cx = X(SLOTX[p.slot]), cy = Y(COVY - 3);
          ctx.strokeStyle = 'rgba(255,70,60,' + (mine ? 0.6 + 0.3 * f : 0.35).toFixed(2) + ')'; ctx.lineWidth = (mine ? 2.2 : 1.4) * ui; ctx.beginPath(); ctx.arc(cx, cy, lerp(10, 2.6, f) * kx, 0, TAU); ctx.stroke();
          ctx.strokeStyle = 'rgba(220,220,225,.4)'; ctx.lineWidth = 2 * ui; ctx.beginPath(); ctx.moveTo(X(p.sx), Y(p.sy)); ctx.lineTo(px, py); ctx.stroke();
          ctx.fillStyle = '#e8e2d6'; ctx.strokeStyle = '#ff5a48'; ctx.lineWidth = 1.5 * ui; ctx.beginPath(); ctx.arc(px, py, (2.4 + f * 2.2) * ui, 0, TAU); ctx.fill(); ctx.stroke();
        }
      }
      for (const p of g.pg) if (p.t >= 0 && !p.dead) { const f = clamp(p.t / p.T, 0, 1), m = mz[p.s], px = lerp(m.x, X(p.x), f), py = lerp(m.y, Y(p.y), f) - Math.sin(f * Math.PI) * 14 * ui; ctx.fillStyle = '#2a2c30'; ctx.strokeStyle = '#f0c86a'; ctx.lineWidth = 1.2 * ui; ctx.beginPath(); ctx.arc(px, py, 2.6 * ui, 0, TAU); ctx.fill(); ctx.stroke(); }
      // 탄 궤적
      for (const q of tr) {
        const m = mz[q.s], f = q.t / q.T, x2 = X(q.x), y2 = Y(q.y);
        if (q.w === 'gl') continue;
        ctx.strokeStyle = 'rgba(255,236,170,' + ((q.own ? 0.85 : 0.45) * (1 - f)).toFixed(3) + ')'; ctx.lineWidth = (q.w === 'sr' ? 2.4 : q.w === 'sg' ? 1.6 : 1.2) * ui;
        ctx.beginPath(); ctx.moveTo(lerp(m.x, x2, f * 0.6), lerp(m.y, y2, f * 0.6)); ctx.lineTo(x2, y2); ctx.stroke();
        if (q.w === 'sg') for (let i = 0; i < 4; i++) { const ox = (A.hsh(i, q.x * 10 | 0) - 0.5) * 9 * kx, oy = (A.hsh(i + 5, q.y * 10 | 0) - 0.5) * 7 * kx; ctx.beginPath(); ctx.moveTo(lerp(m.x, x2 + ox, 0.3), lerp(m.y, y2 + oy, 0.3)); ctx.lineTo(x2 + ox, y2 + oy); ctx.stroke(); }
      }
      // 연출
      for (const q of fx) {
        const f = q.t / q.T, x = X(q.x), y = Y(q.y);
        if (q.k === 'spark') { ctx.strokeStyle = q.w ? 'rgba(255,210,120,' + (1 - f).toFixed(2) + ')' : q.cv ? 'rgba(220,220,210,' + (1 - f).toFixed(2) + ')' : 'rgba(255,240,210,' + (1 - f).toFixed(2) + ')'; ctx.lineWidth = 1.4 * ui; const r = (2 + f * 6) * ui; for (let i = 0; i < 4; i++) { const a = i * 1.57 + q.x; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.4, y + Math.sin(a) * r * 0.4); ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); ctx.stroke(); } }
        else if (q.k === 'num') otxt(String(q.d), x, y - f * 14 * ui, (q.c ? 15 : 13) * ui, q.c ? '#ffe08a' : '#ffd0a0', 'center', FM, 700);
        else if (q.k === 'puff') { const R = q.r * sc(q.y) * kx * (q.boss ? 2.6 : 1.2); ctx.fillStyle = 'rgba(60,56,60,' + (0.55 * (1 - f)).toFixed(3) + ')'; for (let i = 0; i < (q.boss ? 7 : 4); i++) { const a = i * 1.7 + q.x, d = R * (0.3 + f * 0.9); ctx.beginPath(); ctx.arc(x + Math.cos(a) * d, y + Math.sin(a) * d * 0.7 - f * R * 0.4, R * (0.45 + f * 0.3), 0, TAU); ctx.fill(); } if (f < 0.4) { ctx.fillStyle = 'rgba(255,190,110,' + (0.8 * (1 - f / 0.4)).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(x, y, R * (0.5 + f), 0, TAU); ctx.fill(); } }
        else if (q.k === 'boom') { const R = q.r * (q.p === 0 ? 1 : sc(q.y)) * kx; ctx.fillStyle = 'rgba(255,' + (q.p === 0 ? '150,80' : '200,120') + ',' + (0.55 * (1 - f)).toFixed(3) + ')'; ctx.beginPath(); ctx.ellipse(x, y, R * (0.35 + f * 0.75), R * (0.35 + f * 0.75) * 0.8, 0, 0, TAU); ctx.fill(); ctx.strokeStyle = 'rgba(255,240,210,' + (0.8 * (1 - f)).toFixed(3) + ')'; ctx.lineWidth = 2 * ui; ctx.beginPath(); ctx.ellipse(x, y, R * (0.3 + f), R * (0.3 + f) * 0.8, 0, 0, TAU); ctx.stroke(); }
        else if (q.k === 'etr') { const x2 = X(SLOTX[q.s]), y2 = Y(COVY - 2); ctx.strokeStyle = q.prc ? 'rgba(210,160,255,' + (1 - f).toFixed(2) + ')' : 'rgba(255,170,140,' + (0.8 * (1 - f)).toFixed(2) + ')'; ctx.lineWidth = (q.prc ? 4 : 1.5) * ui; ctx.beginPath(); ctx.moveTo(lerp(x, x2, f * 0.5), lerp(y, y2, f * 0.5)); ctx.lineTo(x2, y2); ctx.stroke(); ctx.fillStyle = 'rgba(255,220,160,' + (0.8 * (1 - f)).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x, y, 3 * ui, 0, TAU); ctx.fill(); }
        else if (q.k === 'float') otxt(q.txt, x, y - f * 16 * ui, 12.5 * ui, q.col, 'center', FB, 700);
        else if (q.k === 'lance') { ctx.fillStyle = 'rgba(159,208,192,' + (0.7 * (1 - f)).toFixed(3) + ')'; const w = (5 * (1 - f) + 1) * kx; ctx.fillRect(x - w / 2, Y(10), w, Y(COVY) - Y(10)); ctx.fillStyle = 'rgba(255,255,255,' + (0.8 * (1 - f)).toFixed(3) + ')'; ctx.fillRect(x - w * 0.15, Y(10), w * 0.3, Y(COVY) - Y(10)); }
        else if (q.k === 'blast') { const cx = X(SLOTX[q.s]), cy = Y(COVY - 4); ctx.strokeStyle = 'rgba(255,170,110,' + (0.8 * (1 - f)).toFixed(3) + ')'; ctx.lineWidth = 5 * ui * (1 - f) + 1; ctx.beginPath(); ctx.ellipse(cx, cy, (10 + f * 90) * kx, (6 + f * 55) * lay.ky, 0, Math.PI, TAU); ctx.stroke(); }
        else if (q.k === 'heal') { ctx.strokeStyle = 'rgba(138,208,138,' + (0.8 * (1 - f)).toFixed(3) + ')'; ctx.lineWidth = 2 * ui; ctx.beginPath(); ctx.moveTo(X(q.x2), Y(q.y2)); ctx.lineTo(x, y); ctx.stroke(); }
      }
      if (g.bf.smoke > 0) { ctx.fillStyle = 'rgba(180,200,220,' + (0.16 * Math.min(1, g.bf.smoke)).toFixed(3) + ')'; ctx.fillRect(0, Y(60), lay.W, Y(100) - Y(60)); }
      if (g.bf.mark > 0) for (const e of g.en) if (!e.dead && e.cl < 0.5) { const x = X(e.x), y = Y(e.y), R = e.r * sc(e.y) * kx * 1.5; ctx.strokeStyle = 'rgba(168,200,255,.8)'; ctx.lineWidth = 1.4 * ui; for (let i = 0; i < 4; i++) { const a = i * 1.5708 + 0.785; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * R, y + Math.sin(a) * R); ctx.lineTo(x + Math.cos(a) * R * 0.7, y + Math.sin(a) * R * 0.7); ctx.stroke(); } }
      // 조준점
      const sh = g.sq[g.act];
      if (sh && !sh.down && g.ph === 'fight') {
        const pose = lerp(sh.pp, sh.pose, alpha), x = X(sh.ax), y = Y(sh.ay), w = W[sh.w], mag = S.magOf(g, sh), r = 13 * ui, a0 = pose > 0.5 ? 1 : 0.5;
        const col = sh.lockR ? '255,170,110' : '255,246,224';
        ctx.lineWidth = 3.4 * ui; ctx.strokeStyle = 'rgba(8,8,12,' + (0.5 * a0).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
        ctx.lineWidth = 2 * ui; ctx.strokeStyle = 'rgba(' + col + ',' + (0.28 * a0).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.stroke();
        ctx.strokeStyle = 'rgba(' + col + ',' + (0.95 * a0).toFixed(2) + ')'; ctx.beginPath(); ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(sh.ammo / mag, 0, 1)); ctx.stroke();
        ctx.lineWidth = 1.6 * ui; for (let i = 0; i < 4; i++) { const a = i * 1.5708; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 0.25, y + Math.sin(a) * r * 0.25); ctx.lineTo(x + Math.cos(a) * r * 0.6, y + Math.sin(a) * r * 0.6); ctx.stroke(); }
        if (w.mode === 'charge' && sh.chg > 0) { ctx.strokeStyle = 'rgba(159,208,192,.95)'; ctx.lineWidth = 2.6 * ui; ctx.beginPath(); ctx.arc(x, y, r * 0.72, -Math.PI / 2, -Math.PI / 2 + TAU * sh.chg); ctx.stroke(); }
        if (w.mode === 'heat' && sh.heat > 0.02) { ctx.strokeStyle = 'rgba(255,150,90,.9)'; ctx.lineWidth = 2.2 * ui; ctx.beginPath(); ctx.arc(x, y, r + 4.5 * ui, Math.PI * 0.75, Math.PI * 0.75 - Math.PI * 0.5 * sh.heat, true); ctx.stroke(); }
        if (hitMk > 0) { ctx.strokeStyle = 'rgba(255,255,255,' + hitMk.toFixed(2) + ')'; ctx.lineWidth = 2 * ui; for (let i = 0; i < 4; i++) { const a = i * 1.5708 + 0.785; ctx.beginPath(); ctx.moveTo(x + Math.cos(a) * r * 1.15, y + Math.sin(a) * r * 1.15); ctx.lineTo(x + Math.cos(a) * r * 1.6, y + Math.sin(a) * r * 1.6); ctx.stroke(); } }
        otxt(sh.lockR ? '장전' : String(Math.floor(sh.ammo)), x, y + r + 14 * ui, 12.5 * ui, 'rgba(' + col + ',' + a0 + ')', 'center', sh.lockR ? FB : FM, 700);
        if (g.jam) otxt('조준 보조 끊김', x, y - r - 6 * ui, 12 * ui, '#c890f0', 'center');
      }
    }
    function drawHud(now) {
      const t = now / 1000, ui = lay.ui, Wd = lay.W, st = g.st, pcK = L.ui && L.ui.keyLabel;
      // 위: 구간 · 임무
      const tg = ctx.createLinearGradient(0, 0, 0, 62 * ui); tg.addColorStop(0, 'rgba(8,9,14,.78)'); tg.addColorStop(1, 'rgba(8,9,14,0)'); ctx.fillStyle = tg; ctx.fillRect(0, 0, Wd, 62 * ui);
      const lx = Math.max(10 * ui, lay.fx0 + 8 * ui);
      if (st) {
        txt((g.si + 1) + ' / ' + g.N + '구간', lx, 21 * ui, 17 * ui, '#f2e9d8', 'left', FD, 400);
        let s2 = D.MISSIONS[st.type].n;
        const n = g.en.filter((e) => !e.dead && e.st !== 'flee').length;
        if (st.type === 'clear') { let left = n + st.q.length; for (let i = st.wi; i < st.waves.length; i++) left += st.waves[i].length; s2 += ' · 남은 적 ' + left; }
        else if (st.type === 'hold') s2 += ' · ' + Math.max(0, Math.ceil(st.dur - st.t)) + '초';
        else if (st.type === 'hvt') s2 += ' · 금색 표식의 지휘관';
        else s2 = BS[st.boss].n;
        txt(s2, lx, 38 * ui, 12.5 * ui, '#d8cfc0', 'left', FB, 500);
        const pw = Math.min(8 * ui, (Math.min(Wd, lay.fx0 + 100 * lay.kx) - lx - 60 * ui) / g.N - 3 * ui);
        for (let i = 0; i < g.N; i++) { const bossS = i === g.N - 1 || (g.mid && i === g.mid - 1); ctx.fillStyle = i < g.si ? '#e3ae45' : i === g.si ? '#f2e9d8' : 'rgba(242,233,216,.28)'; const px = lx + i * (pw + 3 * ui), py = 45 * ui; if (bossS) { ctx.beginPath(); ctx.moveTo(px + pw / 2, py - 1 * ui); ctx.lineTo(px + pw + 1 * ui, py + 3.5 * ui); ctx.lineTo(px + pw / 2, py + 8 * ui); ctx.lineTo(px - 1 * ui, py + 3.5 * ui); ctx.fill(); } else ctx.fillRect(px, py + 1 * ui, pw, 5 * ui); }
        // 걸린 효과
        const boss = g.en.find((e) => e.boss && !e.dead);
        const bn = { smoke: '연막', mark: '표식', fort: '보강', barrage: '탄막', burst: '일제 사격' }; let bx = lx, by = (boss ? 86 : 70) * ui;
        for (const k in g.bf) { const s = bn[k] + ' ' + g.bf[k].toFixed(1); ctx.font = '600 ' + 12 * ui + 'px ' + FB; const w = ctx.measureText(s).width + 12 * ui; ctx.fillStyle = 'rgba(20,22,30,.72)'; A.rrect(ctx, bx, by - 13 * ui, w, 18 * ui, 9 * ui); ctx.fill(); txt(s, bx + 6 * ui, by, 12 * ui, '#e3ae45', 'left', FB, 600); bx += w + 4 * ui; }
        if (boss) { const bw = Math.min(Wd - 24 * ui, 100 * lay.kx - 16 * ui), x0 = (Wd - bw) / 2, y0 = 58 * ui; bar(x0, y0, bw, 8 * ui, boss.hp / boss.mhp, boss.inv > 0 ? '#c8d0e0' : '#e0604a'); ctx.fillStyle = 'rgba(8,8,12,.8)'; ctx.fillRect(x0 + bw * 0.6, y0, 2, 8 * ui); ctx.fillRect(x0 + bw * 0.3, y0, 2, 8 * ui); }
      }
      // 아래: 사수 카드
      ctx.fillStyle = '#101118'; ctx.fillRect(0, lay.fy1, Wd, lay.hudH); ctx.fillStyle = 'rgba(227,174,69,.35)'; ctx.fillRect(0, lay.fy1, Wd, 1);
      for (let i = 0; i < 3; i++) {
        const c = lay.cards[i], sh = g.sq[i]; if (!sh) continue;
        const d = SHD[sh.id], act = i === g.act, pw = c.sx - c.x - 3 * ui;
        ctx.fillStyle = act ? '#262433' : '#191b25'; A.rrect(ctx, c.x, c.y, c.w, c.h, 9 * ui); ctx.fill();
        ctx.strokeStyle = act ? '#e3ae45' : '#343848'; ctx.lineWidth = act ? 2 : 1; A.rrect(ctx, c.x + 0.5, c.y + 0.5, c.w - 1, c.h - 1, 9 * ui); ctx.stroke();
        const px0 = c.x + 4 * ui, py0 = c.y + 4 * ui, pw2 = pw - 4 * ui, bh = c.h - 8 * ui, im = art('portrait', sh.id); art('cutin', sh.id);   // 컷인은 기술을 쓰기 전에 미리 불러 둠
        ctx.save(); A.rrect(ctx, px0, py0, pw2, bh, 6 * ui); ctx.clip();
        if (im) { const pc = cached('p:' + sh.id + ':' + Math.round(pw2 * C.dpr) + 'x' + Math.round(bh * C.dpr), () => { const r = focusRect(im, 'portrait', sh.id, pw2, bh, 0.82); r[1] = clamp(r[1] + r[3] * 0.13, 0, im.naturalHeight - r[3]); return shrink(im, r[0], r[1], r[2], r[3], pw2 * C.dpr, bh * C.dpr); }); ctx.drawImage(pc, px0, py0, pw2, bh); }
        else A.bust(ctx, px0, py0, pw2, bh, d.look, { dim: sh.down });
        const cg = ctx.createLinearGradient(0, py0 + bh * 0.42, 0, py0 + bh); cg.addColorStop(0, 'rgba(14,15,22,0)'); cg.addColorStop(0.5, 'rgba(14,15,22,.78)'); cg.addColorStop(1, 'rgba(14,15,22,.94)'); ctx.fillStyle = cg; ctx.fillRect(px0, py0 + bh * 0.42, pw2, bh * 0.58);
        if (sh.down) { ctx.fillStyle = 'rgba(12,12,18,.6)'; ctx.fillRect(px0, py0, pw2, bh); }
        ctx.restore();
        const ny = c.y + c.h - 21 * ui;
        otxt(sh.n, c.x + 7 * ui, ny, 14 * ui, sh.down ? '#9a94a4' : '#f2e9d8', 'left', FD, 400);
        if (sh.down) otxt('쓰러짐', c.x + pw - 2 * ui, ny, 12 * ui, '#ff7a6a', 'right', FB, 600); else otxt(String(Math.ceil(sh.hp)), c.x + pw - 2 * ui, ny, 12 * ui, '#a9d8b4', 'right', FM, 600);
        const hpf = sh.hp / sh.mhp; bar(c.x + 5 * ui, c.y + c.h - 15 * ui, pw - 4 * ui, 6 * ui, hpf, hpf < 0.35 ? '#ff6a58' : '#6ad08a', '#0a0b10');
        bar(c.x + 5 * ui, c.y + c.h - 7 * ui, pw - 4 * ui, 3.5 * ui, sh.ammo / S.magOf(g, sh), sh.lockR ? '#ffa86a' : '#e8dcc0', '#0a0b10');
        if (sh.fl > 0) { ctx.fillStyle = 'rgba(255,70,60,' + (sh.fl * 0.3).toFixed(3) + ')'; A.rrect(ctx, c.x, c.y, c.w, c.h, 9 * ui); ctx.fill(); }
        // 기술 칸
        const full = sh.g >= 100 && !sh.down, zx = c.sx, zy = c.y + 4 * ui, zw = c.sw - 4 * ui, zh = c.h - 8 * ui;
        ctx.save(); A.rrect(ctx, zx, zy, zw, zh, 7 * ui); ctx.clip(); ctx.fillStyle = '#0c0d13'; ctx.fillRect(zx, zy, zw, zh);
        ctx.fillStyle = full ? 'rgba(227,174,69,' + (0.8 + 0.2 * Math.sin(t * 3)).toFixed(2) + ')' : A.shade(d.look.ac, -0.45); ctx.fillRect(zx, zy + zh * (1 - sh.g / 100), zw, zh * sh.g / 100); ctx.restore();
        ctx.strokeStyle = full ? '#ffe2a0' : '#3a3e50'; ctx.lineWidth = full ? 2 : 1; A.rrect(ctx, zx + 0.5, zy + 0.5, zw - 1, zh - 1, 7 * ui); ctx.stroke();
        const wd = d.sk.n.split(' '), tc = full ? '#1a1410' : '#cfc6d8';
        if (wd.length > 1) { txt(wd[0], zx + zw / 2, zy + zh / 2 - 3 * ui, 12 * ui, tc, 'center', FB, 700); txt(wd.slice(1).join(' '), zx + zw / 2, zy + zh / 2 + 11 * ui, 12 * ui, tc, 'center', FB, 700); } else txt(wd[0], zx + zw / 2, zy + zh / 2 + 4 * ui, 12 * ui, tc, 'center', FB, 700);
        if (pcK && L.ui.drawKeyBadge && !isBot) { L.ui.drawKeyBadge(ctx, c.x + pw, c.y + 20 * ui, L.ui.keyLabel('covershot', 's' + (i + 1))); L.ui.drawKeyBadge(ctx, zx + zw - 1, zy + zh - 1, L.ui.keyLabel('covershot', act ? 'skill' : 'k' + (i + 1))); }
      }
      if (S.burstReady(g)) for (const b of burstR()) { const p = 0.5 + 0.5 * Math.sin(t * 3); ctx.fillStyle = 'rgba(227,174,69,' + (0.88 + 0.1 * p).toFixed(2) + ')'; A.rrect(ctx, b.x, b.y, b.w, b.h, 10 * ui); ctx.fill(); ctx.strokeStyle = '#fff0c8'; ctx.lineWidth = 2; A.rrect(ctx, b.x, b.y, b.w, b.h, 10 * ui); ctx.stroke(); txt('일제', b.x + b.w / 2, b.y + b.h / 2 - 2 * ui, 14 * ui, '#1a1410', 'center', FD, 400); txt('사격', b.x + b.w / 2, b.y + b.h / 2 + 14 * ui, 14 * ui, '#1a1410', 'center', FD, 400); if (pcK && L.ui.drawKeyBadge && !isBot) L.ui.drawKeyBadge(ctx, b.x + b.w - 2, b.y + b.h - 2, L.ui.keyLabel('covershot', 'burst')); }
      // 기술 띠 · 알림(작고 반투명 · 짧게 · 누르기 안 막음)
      if (strip) {
        const f = strip.t / strip.T, sh2 = strip.s >= 0 ? g.sq[strip.s] : null, cim = sh2 ? art('cutin', sh2.id) : null;
        if (cim) {   // 컷인 그림: 화면 높이의 20% 띠가 스치고 사라짐(반투명 · 조작을 막지 않음)
          const hh = Math.round(lay.H * 0.2), y0 = clamp(lay.Y(66) - hh / 2, 64 * ui, lay.fy1 - hh - 8 * ui), iw = Math.min(lay.W, Math.round(hh * 4)), ix = (lay.W - iw) / 2;
          const a = Math.min(1, f * 10, (1 - f) * 3.4), k = 1 - Math.min(1, f * 5), sl = k * k * 44 * ui - f * 12 * ui;
          if (!strip.cv) {
            const r = focusRect(cim, 'cutin', sh2.id, iw, hh, 1.3), cv = shrink(cim, r[0], r[1], r[2], r[3], iw * C.dpr, hh * C.dpr);
            if (iw < lay.W - 2) { const c2 = cv.getContext('2d'), mg = c2.createLinearGradient(0, 0, cv.width, 0); mg.addColorStop(0, 'rgba(0,0,0,0)'); mg.addColorStop(0.14, '#000'); mg.addColorStop(0.86, '#000'); mg.addColorStop(1, 'rgba(0,0,0,0)'); c2.globalCompositeOperation = 'destination-in'; c2.fillStyle = mg; c2.fillRect(0, 0, cv.width, cv.height); }
            strip.cv = cv;
          }
          ctx.save(); ctx.globalAlpha = a * 0.9; ctx.beginPath(); ctx.rect(0, y0, lay.W, hh); ctx.clip();
          ctx.fillStyle = 'rgba(10,11,16,.82)'; ctx.fillRect(0, y0, lay.W, hh);
          ctx.drawImage(strip.cv, ix + sl, y0, iw, hh);
          const tg2 = ctx.createLinearGradient(0, y0 + hh * 0.5, 0, y0 + hh); tg2.addColorStop(0, 'rgba(10,11,16,0)'); tg2.addColorStop(1, 'rgba(10,11,16,.78)'); ctx.fillStyle = tg2; ctx.fillRect(0, y0 + hh * 0.5, lay.W, hh * 0.5);
          ctx.fillStyle = 'rgba(227,174,69,.95)'; ctx.fillRect(0, y0, lay.W, 2 * ui); ctx.fillRect(0, y0 + hh - 2 * ui, lay.W, 2 * ui);
          const tx = Math.max(12 * ui, ix + 14 * ui) - k * 30 * ui;
          otxt(sh2.n, tx, y0 + hh - 34 * ui, 13 * ui, '#e6dccb', 'left', FB, 600); otxt(strip.n, tx, y0 + hh - 11 * ui, 22 * ui, '#f6e2b0', 'left', FD, 400);
          ctx.restore();
        } else {
          const a = Math.min(1, f * 8, (1 - f) * 4), hh = 40 * ui, y0 = lay.Y(84), sl = (1 - Math.min(1, f * 6)) * 40 * ui;
          ctx.globalAlpha = a * 0.86; const gr = ctx.createLinearGradient(0, 0, lay.W, 0); gr.addColorStop(0, 'rgba(14,15,22,0)'); gr.addColorStop(0.25, 'rgba(14,15,22,.92)'); gr.addColorStop(0.75, 'rgba(14,15,22,.92)'); gr.addColorStop(1, 'rgba(14,15,22,0)'); ctx.fillStyle = gr; ctx.fillRect(0, y0, lay.W, hh);
          ctx.fillStyle = 'rgba(227,174,69,.9)'; ctx.fillRect(lay.W * 0.2, y0, lay.W * 0.6, 1.5); ctx.fillRect(lay.W * 0.2, y0 + hh - 1.5, lay.W * 0.6, 1.5);
          const cxm = lay.W / 2 - sl;
          if (sh2) { A.bust(ctx, cxm - 96 * ui, y0 + 3 * ui, 40 * ui, hh - 6 * ui, SHD[sh2.id].look); txt(sh2.n, cxm - 48 * ui, y0 + 17 * ui, 12.5 * ui, '#d8cfc0', 'left', FB, 600); txt(strip.n, cxm - 48 * ui, y0 + 34 * ui, 18 * ui, '#f6e2b0', 'left', FD, 400); }
          else txt(strip.n, cxm, y0 + 28 * ui, 22 * ui, '#f6e2b0', 'center', FD, 400);
          ctx.globalAlpha = 1;
        }
      }
      if (note) {
        const f = note.t / note.T, a = Math.min(1, f * 8, (1 - f) * 4) * 0.9, y0 = 108 * ui;
        ctx.globalAlpha = a; ctx.font = '400 ' + 18 * ui + 'px ' + FD; const w = Math.max(ctx.measureText(note.txt).width, note.sub ? note.sub.length * 12.5 * ui : 0) + 36 * ui;
        ctx.fillStyle = 'rgba(14,15,22,.74)'; A.rrect(ctx, lay.W / 2 - w / 2, y0, w, (note.sub ? 48 : 32) * ui, 10 * ui); ctx.fill();
        txt(note.txt, lay.W / 2, y0 + 22 * ui, 18 * ui, '#f2e9d8', 'center', FD, 400); if (note.sub) txt(note.sub, lay.W / 2, y0 + 40 * ui, 12.5 * ui, '#c9c0d0', 'center', FB, 500);
        ctx.globalAlpha = 1;
      }
      if (!isBot && g.si === 0 && g.ph === 'fight' && hintT < 9 && !strip) { const a = Math.min(1, hintT * 2, (9 - hintT)) * 0.9; ctx.globalAlpha = a; const s = mouse ? '마우스를 누르고 있기: 사격 · 떼기: 엄폐와 장전' : '누르고 있기: 사격 · 끌기: 조준 · 떼기: 엄폐와 장전'; ctx.font = '600 ' + 12.5 * ui + 'px ' + FB; const w = ctx.measureText(s).width + 22 * ui, y0 = lay.Y(77); ctx.fillStyle = 'rgba(14,15,22,.72)'; A.rrect(ctx, lay.W / 2 - w / 2, y0, w, 26 * ui, 13 * ui); ctx.fill(); txt(s, lay.W / 2, y0 + 17.5 * ui, 12.5 * ui, '#f2e9d8', 'center', FB, 600); ctx.globalAlpha = 1; }
      if (g.ph === 'won' || g.ph === 'lost') { const a = Math.min(1, endT * 2); ctx.fillStyle = 'rgba(8,9,14,' + (0.55 * a).toFixed(2) + ')'; ctx.fillRect(0, 0, lay.W, lay.H); ctx.globalAlpha = a; txt(g.ph === 'won' ? '임무 완수' : '임무 실패', lay.W / 2, lay.H * 0.42, 34 * ui, g.ph === 'won' ? '#f6e2b0' : '#ff9a88', 'center', FD, 400); ctx.globalAlpha = 1; }
      // 피격 · 체력 경고(가장자리만, 느리게)
      const sh = g.sq[g.act], low = sh && !sh.down ? clamp(0.4 - sh.hp / sh.mhp, 0, 0.4) / 0.4 : 0, va = (vig * 0.3 + low * (0.16 + 0.05 * Math.sin(t * 2.2))) * (L.fx ? 0.4 + 0.6 * L.fx() : 1);
      if (va > 0.01) { const vg = ctx.createRadialGradient(lay.W / 2, lay.H / 2, Math.min(lay.W, lay.H) * 0.36, lay.W / 2, lay.H / 2, Math.max(lay.W, lay.H) * 0.72); vg.addColorStop(0, 'rgba(255,40,30,0)'); vg.addColorStop(1, 'rgba(255,40,30,' + va.toFixed(3) + ')'); ctx.fillStyle = vg; ctx.fillRect(0, 0, lay.W, lay.fy1); }
      if (flashW > 0.01) { ctx.fillStyle = 'rgba(255,244,220,' + (flashW * 0.5).toFixed(3) + ')'; ctx.fillRect(0, 0, lay.W, lay.fy1); }
    }

    /* ── 한 프레임 ── */
    function softAim() {   // 터치(끌어서 조준): 붙은 표적이 없으면 가까운 적 쪽으로 조준점이 천천히 따라감
      if (mouse || !state.o.assist || state.o.aim === 'direct' || !inp.down || g.jam) return;
      const sh = g.sq[g.act]; if (!sh || sh.lk) return;
      const e = nearEnemy(inp.ax, inp.ay, 26); if (!e) return;
      const dx = e.x - inp.ax, dy = e.y - inp.ay, d = Math.hypot(dx, dy), v = 55 * DT; if (d > 0.01) { inp.ax += dx / d * Math.min(v, d); inp.ay += dy / d * Math.min(v, d); }
    }
    function frame(dt, now) {
      if (dead || !g) return;
      const sp = (L.debug && L.debug.speed) || 1;
      if (!isBot) {
        if (g.ph === 'pick' && ovKey !== 'pick') openPick();
        else if (g.ph === 'up' && g.opts) { if (ovKey !== 'up' + g.si + ':' + g.opts.join(',')) openUp(); }
        else if (g.ph !== 'pick' && g.ph !== 'up' && ov) closeOv();
      }
      if (!ended) {
        acc += dt * sp; let n = 0;
        while (acc >= DT && n < 80) {
          let I;
          if (isBot) I = S.bot(g, lv, M); else { if (g.ph === 'fight') softAim(); I = inp; if (ov) inp.down = false; }
          S.step(g, I); simT += DT;
          for (const e of g.ev) onEv(e);
          if (!isBot) { inp.sw = -1; inp.sk = -1; inp.burst = false; inp.pick = null; inp.up = null; inp.reroll = false; }
          acc -= DT; n++;
          if (g.ph !== 'fight' && g.ph !== 'clear') { acc = 0; break; }
        }
        if (n >= 80) acc = 0;
      }
      const rdt = dt * Math.min(sp, 3);
      for (let i = fx.length - 1; i >= 0; i--) { fx[i].t += rdt; if (fx[i].t >= fx[i].T) fx.splice(i, 1); }
      for (let i = tr.length - 1; i >= 0; i--) { tr[i].t += rdt; if (tr[i].t >= tr[i].T) tr.splice(i, 1); }
      for (let i = 0; i < 3; i++) { flash[i] = Math.max(0, flash[i] - rdt * 14); const sq = g.sq[i]; downK[i] = sq && sq.down ? Math.min(1, downK[i] + rdt * 2.6) : Math.max(0, downK[i] - rdt * 4); }
      shake *= Math.exp(-rdt * 9); vig = Math.max(0, vig - rdt * 2.2); hitMk = Math.max(0, hitMk - rdt * 7); flashW = Math.max(0, flashW - rdt * 2.5);
      if (strip) { strip.t += rdt; if (strip.t >= strip.T) strip = null; }
      if (note) { note.t += rdt; if (note.t >= note.T) note = null; }
      if (g.ph === 'fight') hintT += rdt;
      // 내 자리로 오는 직사가 곧 발사될 때 짧은 경고음(한 번)
      if (g.ph === 'fight' && !isBot) for (const th of g.th) if (!th.dead && th.slot === g.act && (th.k === 'aim' || th.k === 'sup') && !warned[th.id] && th.T - th.t < 0.45) { warned[th.id] = 1; if (g.sq[g.act].pose > 0.35) snd('warn'); }
      if ((g.ph === 'won' || g.ph === 'lost') && !ended) {
        endT += dt * Math.min(sp, 4);
        if (endT > 1.7) {
          ended = true; closeOv();
          const sum = S.summary(g);
          if (!isBot) { try { api.best('stage', sum.st, { label: '돌파 구간', unit: '구간' }); if (sum.won) api.best('t_' + state.o.len, sum.t, { label: '완수 시간(' + sum.n + '구간)', lower: true, fmt: 'time' }); } catch (e) {} }
          api.sfx(sum.won ? 'win' : 'lose');
          api.setState(Object.assign({}, state, { done: 1, sum }));
        }
      }
      // 그리기
      const alpha = ended || g.ph === 'pick' || g.ph === 'up' ? 1 : clamp(acc / DT, 0, 1);
      ctx.clearRect(0, 0, lay.W, lay.H);
      if (g.ph === 'pick' || !g.sq.length) { ctx.fillStyle = '#0d0e14'; ctx.fillRect(0, 0, lay.W, lay.H); return; }
      ctx.save();
      if (shake > 0.05) ctx.translate(Math.sin(now * 0.055) * shake, Math.cos(now * 0.047) * shake * 0.7);
      drawField(now, alpha);
      ctx.restore();
      drawHud(now);
    }
    const stop = U.loop(frame);

    return {
      update(s) {
        state = s;
        if (!s) return;
        if (seed !== s.seed) {
          seed = s.seed; g = S.create(s.seed, { len: s.o.len, boss: s.o.boss, assist: s.o.assist });
          M = {}; acc = 0; ended = false; endT = 0; hintT = 0; simT = 0; fx.length = 0; tr.length = 0; strip = null; note = null; bgKey = ''; closeOv(); release();
          inp.ax = 50; inp.ay = 45; inp.pick = null; inp.up = null;
        }
        if (s.done) { ended = true; closeOv(); }
      },
      destroy() {
        dead = true; stop(); if (offIn) offIn(); closeOv();
        C.cv.removeEventListener('pointerdown', onDown); C.cv.removeEventListener('pointermove', onMove); C.cv.removeEventListener('pointerup', onUp); C.cv.removeEventListener('pointercancel', onUp);
        G.removeEventListener('blur', release); G.removeEventListener('lounge-pause', release);
        if (C.destroy) C.destroy(); box.remove();
      },
    };
  }
  CS.VIEW = { mount };
})();
