/* 엄폐 사격 — 코드 그림(캔버스 벡터). 사수 뒷모습 · 초상 실루엣 · 엄폐물 · 적 · 우두머리 · 전장 배경.
   그림 파일이 생기면 DATA.ART에 경로를 적는다(view.js가 초상 · 컷인 · 배경에 씀). 여기 함수는 그림이 없을 때의 기본 모습. */
(function () {
  const G = typeof window !== 'undefined' ? window : globalThis;
  const CS = G.COVERSHOT = G.COVERSHOT || {};
  const lerp = (a, b, t) => a + (b - a) * t, clamp = (v, a, b) => (v < a ? a : v > b ? b : v), TAU = Math.PI * 2;
  const hsh = (a, b) => { let x = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263)) | 0; x = Math.imul(x ^ (x >>> 13), 1274126177); return ((x ^ (x >>> 16)) >>> 0) / 4294967296; };
  function shade(hex, f) {   // f<0 어둡게, f>0 밝게
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function rrect(c, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r); c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h); c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath(); }
  const line = (c, x1, y1, x2, y2) => { c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke(); };
  const circ = (c, x, y, r) => { c.beginPath(); c.arc(x, y, Math.max(0.01, r), 0, TAU); };
  const SKIN = '#e9cdb6', GUN = '#23262c', GUN2 = '#3a3f48';
  const WLEN = { ar: 8.5, sr: 11.5, sg: 8.5, mg: 10.5, gl: 7.5, smg: 5.8 };

  /* ───────── 초상 실루엣(정면 흉상) ───────── */
  function hairFront(c, st, w, hc) {
    c.fillStyle = hc;
    // 머리 뒤쪽 덩어리
    if (st === 'long') { c.beginPath(); c.moveTo(-w * 0.27, -w * 0.5); c.quadraticCurveTo(-w * 0.36, w * 0.1, -w * 0.3, w * 0.5); c.lineTo(w * 0.3, w * 0.5); c.quadraticCurveTo(w * 0.36, w * 0.1, w * 0.27, -w * 0.5); c.fill(); }
    else if (st === 'bob' || st === 'wolf') { c.beginPath(); c.moveTo(-w * 0.26, -w * 0.5); c.quadraticCurveTo(-w * 0.34, -w * 0.1, -w * (st === 'wolf' ? 0.3 : 0.27), w * (st === 'wolf' ? 0.12 : 0.02)); c.lineTo(w * (st === 'wolf' ? 0.3 : 0.27), w * (st === 'wolf' ? 0.12 : 0.02)); c.quadraticCurveTo(w * 0.34, -w * 0.1, w * 0.26, -w * 0.5); c.fill(); }
    else if (st === 'pony') { c.beginPath(); c.moveTo(w * 0.12, -w * 0.62); c.quadraticCurveTo(w * 0.46, -w * 0.5, w * 0.36, w * 0.18); c.quadraticCurveTo(w * 0.3, -w * 0.2, w * 0.1, -w * 0.5); c.fill(); }
    else if (st === 'side') { c.beginPath(); c.moveTo(w * 0.2, -w * 0.4); c.quadraticCurveTo(w * 0.48, -w * 0.2, w * 0.38, w * 0.3); c.quadraticCurveTo(w * 0.28, 0, w * 0.2, -w * 0.2); c.fill(); }
    else if (st === 'twin') { for (const s of [-1, 1]) { c.beginPath(); c.moveTo(s * w * 0.2, -w * 0.12); c.quadraticCurveTo(s * w * 0.4, w * 0.1, s * w * 0.3, w * 0.46); c.quadraticCurveTo(s * w * 0.22, w * 0.2, s * w * 0.16, -w * 0.05); c.fill(); } }
    else if (st === 'braid') { for (let i = 0; i < 4; i++) { c.beginPath(); c.ellipse(w * 0.27, -w * 0.02 + i * w * 0.12, w * 0.07, w * 0.075, 0, 0, TAU); c.fill(); } }
    else if (st === 'bun') { circ(c, 0, -w * 0.66, w * 0.12); c.fill(); }
  }
  function bust(c, x, y, w, h, look, o) {
    o = o || {};
    c.save(); rrect(c, x, y, w, h, Math.min(w, h) * 0.12); c.clip();
    const bg = c.createLinearGradient(x, y, x, y + h); bg.addColorStop(0, shade(look.oc, -0.55)); bg.addColorStop(1, shade(look.oc, -0.75)); c.fillStyle = bg; c.fillRect(x, y, w, h);
    c.fillStyle = shade(look.ac, -0.2); c.globalAlpha = 0.16; c.beginPath(); c.moveTo(x, y + h); c.lineTo(x + w * 0.7, y); c.lineTo(x + w, y); c.lineTo(x + w * 0.3, y + h); c.fill(); c.globalAlpha = 1;
    const s = Math.min(w / 1.05, h / 1.15), cx = x + w / 2, cy = y + h * 0.62;
    c.translate(cx, cy);
    hairFront(c, look.hair, s, shade(look.hc, -0.25));
    // 어깨 · 옷
    c.fillStyle = look.oc; c.beginPath(); c.moveTo(-s * 0.46, s * 0.6); c.quadraticCurveTo(-s * 0.44, s * 0.12, -s * 0.16, s * 0.06); c.lineTo(s * 0.16, s * 0.06); c.quadraticCurveTo(s * 0.44, s * 0.12, s * 0.46, s * 0.6); c.fill();
    c.fillStyle = shade(look.oc, -0.3); c.beginPath(); c.moveTo(-s * 0.1, s * 0.06); c.lineTo(0, s * 0.3); c.lineTo(s * 0.1, s * 0.06); c.fill();
    c.strokeStyle = look.ac; c.lineWidth = s * 0.03; line(c, -s * 0.36, s * 0.22, -s * 0.24, s * 0.16);
    // 목 · 얼굴
    c.fillStyle = shade(SKIN, -0.15); c.fillRect(-s * 0.07, -s * 0.08, s * 0.14, s * 0.18);
    c.fillStyle = SKIN; c.beginPath(); c.ellipse(0, -s * 0.3, s * 0.19, s * 0.23, 0, 0, TAU); c.fill();
    // 앞머리
    c.fillStyle = look.hc; c.beginPath(); c.moveTo(-s * 0.22, -s * 0.26); c.quadraticCurveTo(-s * 0.26, -s * 0.6, 0, -s * 0.6); c.quadraticCurveTo(s * 0.26, -s * 0.6, s * 0.22, -s * 0.26); c.quadraticCurveTo(s * 0.16, -s * 0.44, s * 0.04, -s * 0.4); c.quadraticCurveTo(-s * 0.02, -s * 0.34, -s * 0.1, -s * 0.36); c.quadraticCurveTo(-s * 0.18, -s * 0.38, -s * 0.22, -s * 0.26); c.fill();
    c.beginPath(); c.moveTo(-s * 0.21, -s * 0.4); c.quadraticCurveTo(-s * 0.25, -s * 0.2, -s * 0.2, -s * 0.06); c.lineTo(-s * 0.17, -s * 0.3); c.fill();
    c.beginPath(); c.moveTo(s * 0.21, -s * 0.4); c.quadraticCurveTo(s * 0.25, -s * 0.2, s * 0.2, -s * 0.06); c.lineTo(s * 0.17, -s * 0.3); c.fill();
    // 눈매(실루엣 수준)
    c.fillStyle = 'rgba(40,30,36,.75)'; c.fillRect(-s * 0.115, -s * 0.275, s * 0.07, s * 0.022); c.fillRect(s * 0.045, -s * 0.275, s * 0.07, s * 0.022);
    // 장구
    if (look.gear === 'cap') { c.fillStyle = shade(look.oc, -0.1); c.beginPath(); c.ellipse(0, -s * 0.5, s * 0.25, s * 0.12, 0, Math.PI, TAU); c.fill(); c.fillRect(-s * 0.3, -s * 0.51, s * 0.42, s * 0.045); }
    else if (look.gear === 'beret') { c.fillStyle = shade(look.oc, -0.2); c.beginPath(); c.ellipse(s * 0.04, -s * 0.56, s * 0.27, s * 0.1, -0.15, 0, TAU); c.fill(); }
    else if (look.gear === 'headset') { c.strokeStyle = '#22252b'; c.lineWidth = s * 0.035; c.beginPath(); c.arc(0, -s * 0.34, s * 0.25, Math.PI * 1.08, Math.PI * 1.92); c.stroke(); c.fillStyle = '#22252b'; rrect(c, -s * 0.28, -s * 0.36, s * 0.07, s * 0.14, s * 0.02); c.fill(); }
    else if (look.gear === 'goggles') { c.fillStyle = '#22252b'; rrect(c, -s * 0.2, -s * 0.53, s * 0.4, s * 0.08, s * 0.03); c.fill(); c.fillStyle = look.ac; c.globalAlpha = 0.7; rrect(c, -s * 0.16, -s * 0.515, s * 0.13, s * 0.05, s * 0.02); c.fill(); rrect(c, s * 0.03, -s * 0.515, s * 0.13, s * 0.05, s * 0.02); c.fill(); c.globalAlpha = 1; }
    else if (look.gear === 'mask') { c.fillStyle = shade(look.ac, -0.45); c.beginPath(); c.moveTo(-s * 0.2, -s * 0.02); c.quadraticCurveTo(0, s * 0.12, s * 0.2, -s * 0.02); c.lineTo(s * 0.16, s * 0.12); c.lineTo(-s * 0.16, s * 0.12); c.fill(); }
    if (o.dim) { c.fillStyle = 'rgba(12,12,18,.62)'; c.fillRect(-w, -h, w * 2, h * 2); }
    c.restore();
  }

  /* ───────── 사수(뒷모습 · 관절 보간) ─────────
     x, feetY: 발 위치(화면), u: 단위 px, p: 0 엄폐(웅크림) ~ 1 사격(일어섬), ang: 총이 향하는 화면 각도, rec: 반동 0~1 */
  function hairBack(c, st, hx, hy, hc, sway, shY) {
    c.fillStyle = hc; c.strokeStyle = shade(hc, -0.35); c.lineWidth = 0.25;
    const tail = (x0, y0, x1, y1, w0) => { c.beginPath(); c.moveTo(x0 - w0, y0); c.quadraticCurveTo(x0 - w0 * 1.3 + sway * 0.5, (y0 + y1) / 2, x1 + sway, y1); c.quadraticCurveTo(x0 + w0 * 1.5 + sway * 0.5, (y0 + y1) / 2, x0 + w0, y0); c.fill(); c.stroke(); };
    if (st === 'pony') tail(hx, hy - 1.2, hx + 0.6, hy + 7.5, 0.95);
    else if (st === 'long') { c.beginPath(); c.moveTo(hx - 2.3, hy - 0.4); c.quadraticCurveTo(hx - 3 + sway * 0.3, hy + 5, hx - 2.2 + sway, shY + 6.5); c.lineTo(hx + 2.2 + sway, shY + 6.5); c.quadraticCurveTo(hx + 3 + sway * 0.3, hy + 5, hx + 2.3, hy - 0.4); c.fill(); c.stroke(); }
    else if (st === 'bob') { c.beginPath(); c.moveTo(hx - 2.4, hy - 0.6); c.quadraticCurveTo(hx - 3.1, hy + 2.4, hx - 2.2, hy + 3.1); c.lineTo(hx + 2.2, hy + 3.1); c.quadraticCurveTo(hx + 3.1, hy + 2.4, hx + 2.4, hy - 0.6); c.fill(); c.stroke(); }
    else if (st === 'wolf') { c.beginPath(); c.moveTo(hx - 2.4, hy - 0.6); c.lineTo(hx - 2.9, hy + 3.4); c.lineTo(hx - 1.5, hy + 2.8); c.lineTo(hx - 0.8 + sway * 0.4, hy + 4.4); c.lineTo(hx, hy + 3); c.lineTo(hx + 0.9 + sway * 0.4, hy + 4.4); c.lineTo(hx + 1.6, hy + 2.8); c.lineTo(hx + 2.9, hy + 3.4); c.lineTo(hx + 2.4, hy - 0.6); c.fill(); c.stroke(); }
    else if (st === 'braid') { for (let i = 0; i < 6; i++) { c.beginPath(); c.ellipse(hx + sway * (i / 5), hy + 2 + i * 1.5, 0.95 - i * 0.07, 1.0, 0, 0, TAU); c.fill(); c.stroke(); } }
    else if (st === 'side') tail(hx + 1.9, hy + 0.2, hx + 3.2, hy + 7, 0.8);
    else if (st === 'twin') { tail(hx - 1.7, hy + 1.3, hx - 2.6, shY + 5.5, 0.7); tail(hx + 1.7, hy + 1.3, hx + 2.6, shY + 5.5, 0.7); }
  }
  function gunShape(c, cls, L) {   // 총구가 +x 방향, 손잡이가 원점
    c.fillStyle = GUN; c.strokeStyle = GUN2; c.lineWidth = 0.3;
    if (cls === 'sr') { c.fillRect(-2.6, -0.55, L * 0.55 + 2.6, 1.1); c.fillRect(L * 0.5, -0.3, L * 0.5, 0.6); c.fillStyle = GUN2; rrect(c, 0.4, -1.5, 3.2, 0.9, 0.3); c.fill(); }
    else if (cls === 'mg') { c.fillRect(-2.6, -0.7, L * 0.62 + 2.6, 1.4); c.fillRect(L * 0.6, -0.35, L * 0.4, 0.7); c.fillStyle = GUN2; c.fillRect(0.6, 0.5, 2.4, 1.7); }
    else if (cls === 'sg') { c.fillRect(-2.4, -0.6, L * 0.5 + 2.4, 1.2); c.fillRect(L * 0.45, -0.45, L * 0.55, 0.9); c.fillStyle = GUN2; c.fillRect(L * 0.5, 0.25, L * 0.3, 0.7); }
    else if (cls === 'gl') { c.fillRect(-2.2, -0.6, 3.4, 1.2); c.fillRect(1, -0.85, L - 1, 1.7); c.fillStyle = GUN2; circ(c, 1.6, 0.9, 1.25); c.fill(); }
    else if (cls === 'smg') { c.fillRect(-1.6, -0.55, L + 1.6, 1.1); c.fillStyle = GUN2; c.fillRect(0.8, 0.4, 0.9, 2.0); }
    else { c.fillRect(-2.6, -0.6, L * 0.6 + 2.6, 1.2); c.fillRect(L * 0.55, -0.3, L * 0.45, 0.6); c.fillStyle = GUN2; c.fillRect(1.0, 0.4, 1.0, 1.9); }
  }
  function shooter(c, x, feetY, u, look, cls, p, ang, rec, t, o) {
    o = o || {};
    const e = p * p * (3 - 2 * p);
    const hipY = -lerp(7.2, 13.2, e), shY = hipY - lerp(7.6, 9.4, e), lean = lerp(0, 1.1, e), hx = lean * 0.5, hy = shY - 3.3;
    const sway = Math.sin(t * 1.3 + x * 0.07) * 0.35 - rec * 0.5;
    c.save(); c.translate(x, feetY); c.scale(u, u);
    if (o.down) { c.rotate(1.25); c.translate(-2, 3); c.globalAlpha = 0.55; }
    if (o.active && !o.down) { c.strokeStyle = 'rgba(227,174,69,.85)'; c.lineWidth = 0.45; c.beginPath(); c.ellipse(0, 0.4, 6.2, 1.5, 0, 0, TAU); c.stroke(); }
    c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(0, 0.5, 5, 1.1, 0, 0, TAU); c.fill();
    c.lineCap = 'round'; c.lineJoin = 'round';
    // 다리
    const pants = shade(look.oc, -0.5), kx = lerp(4.3, 2.3, e), ky = lerp(-4.2, -6.8, e);
    c.strokeStyle = pants; c.lineWidth = 2.9;
    for (const s of [-1, 1]) { c.beginPath(); c.moveTo(s * 1.6 + lean * 0.4, hipY + 0.6); c.lineTo(s * kx, ky); c.lineTo(s * 2.6, -0.6); c.stroke(); }
    c.strokeStyle = '#1c1d22'; c.lineWidth = 2.7; for (const s of [-1, 1]) line(c, s * 2.6, -0.9, s * 2.75, -0.1);
    // 몸통
    const tx = lean * 0.7;
    c.fillStyle = look.oc; c.strokeStyle = shade(look.oc, -0.55); c.lineWidth = 0.3;
    c.beginPath(); c.moveTo(tx - 3.2, shY); c.quadraticCurveTo(tx - 3.3, shY + 3, tx - 2.1, hipY - 2.6); c.quadraticCurveTo(tx - 3.1 + lean * 0.3, hipY - 0.6, -2.9 + lean * 0.4, hipY + 1.3); c.lineTo(2.9 + lean * 0.4, hipY + 1.3); c.quadraticCurveTo(tx + 3.1 + lean * 0.3, hipY - 0.6, tx + 2.1, hipY - 2.6); c.quadraticCurveTo(tx + 3.3, shY + 3, tx + 3.2, shY); c.quadraticCurveTo(tx, shY - 1.1, tx - 3.2, shY); c.fill(); c.stroke();
    c.fillStyle = pants; c.beginPath(); c.moveTo(-2.9 + lean * 0.4, hipY + 1.3); c.lineTo(2.9 + lean * 0.4, hipY + 1.3); c.lineTo(2.5 + lean * 0.4, hipY - 0.9); c.lineTo(-2.5 + lean * 0.4, hipY - 0.9); c.fill();
    c.fillStyle = shade(look.oc, -0.3); rrect(c, tx - 1.7, shY + 1.2, 3.4, 3.6, 0.6); c.fill();   // 등 장구
    c.fillStyle = look.ac; c.fillRect(tx - 3.1, shY + 0.5, 1.2, 0.55); c.fillRect(-2.5 + lean * 0.4, hipY - 1.2, 5, 0.45);
    // 총 · 팔
    const gx = tx + 2.2, gy = shY + 1.4, a = lerp(-1.12, ang, e), L = WLEN[cls] * lerp(0.8, 0.9, e), k = rec * 0.7;
    const mx = gx + Math.cos(a) * (L - k), my = gy + Math.sin(a) * (L - k);
    c.strokeStyle = shade(look.oc, -0.25); c.lineWidth = 1.6;
    c.beginPath(); c.moveTo(tx - 2.9, shY + 0.7); c.lineTo(tx - 2.2 + Math.cos(a) * 1.2, shY + 2.6 + Math.sin(a) * 1.4); c.lineTo(gx + Math.cos(a) * (L * 0.45 - k), gy + Math.sin(a) * (L * 0.45 - k)); c.stroke();
    c.save(); c.translate(gx - Math.cos(a) * k, gy - Math.sin(a) * k); c.rotate(a); gunShape(c, cls, L); c.restore();
    c.strokeStyle = shade(look.oc, -0.25); c.lineWidth = 1.6; c.beginPath(); c.moveTo(tx + 2.9, shY + 0.7); c.lineTo(gx + 0.9, gy + 1.3); c.lineTo(gx - Math.cos(a) * k, gy - Math.sin(a) * k); c.stroke();
    // 머리
    hairBack(c, look.hair, hx, hy, look.hc, sway, shY);
    c.fillStyle = shade(SKIN, -0.12); c.fillRect(hx - 0.7, hy + 1.6, 1.4, 1.6);
    c.fillStyle = look.hc; c.strokeStyle = shade(look.hc, -0.35); c.lineWidth = 0.25; circ(c, hx, hy, 2.3); c.fill(); c.stroke();
    if (look.hair === 'bun') { circ(c, hx, hy - 2.2, 1.15); c.fill(); c.stroke(); }
    if (look.hair === 'short') { c.beginPath(); c.moveTo(hx - 2.2, hy + 0.4); c.lineTo(hx - 1.6, hy + 2.5); c.lineTo(hx + 1.6, hy + 2.5); c.lineTo(hx + 2.2, hy + 0.4); c.fill(); }
    if (look.gear === 'headset') { c.strokeStyle = '#1c1e24'; c.lineWidth = 0.5; c.beginPath(); c.arc(hx, hy, 2.45, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); c.fillStyle = '#1c1e24'; rrect(c, hx - 3, hy - 0.7, 0.9, 1.7, 0.3); c.fill(); rrect(c, hx + 2.1, hy - 0.7, 0.9, 1.7, 0.3); c.fill(); }
    else if (look.gear === 'cap') { c.fillStyle = shade(look.oc, -0.15); c.beginPath(); c.arc(hx, hy - 0.3, 2.4, Math.PI, TAU); c.fill(); c.fillRect(hx - 2.4, hy - 0.5, 4.8, 0.6); }
    else if (look.gear === 'beret') { c.fillStyle = shade(look.oc, -0.25); c.beginPath(); c.ellipse(hx + 0.4, hy - 1.7, 2.6, 1.1, -0.2, 0, TAU); c.fill(); }
    else if (look.gear === 'goggles') { c.strokeStyle = '#1c1e24'; c.lineWidth = 0.6; c.beginPath(); c.arc(hx, hy, 2.3, Math.PI * 1.02, Math.PI * 1.98); c.stroke(); }
    else if (look.gear === 'mask') { c.fillStyle = shade(look.ac, -0.4); c.fillRect(hx - 1.5, hy + 1.7, 3, 1.2); }
    if (o.fl > 0) { c.fillStyle = 'rgba(255,70,60,' + (o.fl * 0.45).toFixed(3) + ')'; c.beginPath(); c.ellipse(tx, (shY + hipY) / 2, 4.2, 7.5, 0, 0, TAU); c.fill(); }
    c.restore();
    return { x: x + mx * u, y: feetY + my * u };
  }

  /* ───────── 엄폐물 ───────── */
  function cover(c, x, topY, u, ratio, fl, seed) {
    c.save(); c.translate(x, topY); c.scale(u, u);
    c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(0, 10.2, 12, 1.6, 0, 0, TAU); c.fill();
    if (ratio <= 0) {
      c.fillStyle = '#4a4c52'; for (let i = 0; i < 6; i++) { const rx = (hsh(seed, i) - 0.5) * 18, rw = 2.4 + hsh(seed, i + 9) * 3; c.beginPath(); c.moveTo(rx - rw, 10); c.lineTo(rx - rw * 0.4, 10 - rw * 0.9); c.lineTo(rx + rw * 0.7, 10 - rw * 0.6); c.lineTo(rx + rw, 10); c.fill(); }
      c.restore(); return;
    }
    const gr = c.createLinearGradient(0, 0, 0, 10); gr.addColorStop(0, '#a9a8a2'); gr.addColorStop(1, '#6e6d6a');
    c.fillStyle = gr; c.strokeStyle = '#3a3a3c'; c.lineWidth = 0.4;
    c.beginPath(); c.moveTo(-8.5, 0); c.lineTo(8.5, 0); c.lineTo(9.6, 4.2); c.lineTo(11, 10); c.lineTo(-11, 10); c.lineTo(-9.6, 4.2); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(-8.3, 0.2, 16.6, 0.9);
    c.fillStyle = '#c8a23a'; for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(i * 3.6 - 1, 5); c.lineTo(i * 3.6 + 0.6, 5); c.lineTo(i * 3.6 - 0.2, 8.4); c.lineTo(i * 3.6 - 1.8, 8.4); c.fill(); }
    const n = Math.round((1 - ratio) * 9);
    c.strokeStyle = 'rgba(28,26,28,.8)'; c.lineWidth = 0.35;
    for (let i = 0; i < n; i++) { const cx = (hsh(seed, i * 3) - 0.5) * 17, cy = hsh(seed, i * 3 + 1) * 5; c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + (hsh(seed, i + 30) - 0.5) * 3, cy + 2); c.lineTo(cx + (hsh(seed, i + 60) - 0.5) * 4, cy + 4.4); c.stroke(); }
    if (ratio < 0.5) { c.fillStyle = '#2e2d30'; c.beginPath(); c.moveTo(4, 0); c.lineTo(8.5, 0); c.lineTo(9, 2.4); c.lineTo(6, 1.2); c.fill(); }
    if (fl > 0) { c.fillStyle = 'rgba(255,240,200,' + (fl * 0.5).toFixed(3) + ')'; c.fillRect(-9, 0, 18, 10); }
    c.restore();
  }

  /* ───────── 적(정면) — R: 화면 반지름 px ───────── */
  function soldier(c, e, R, t, o) {
    const d = e.d, tint = d.tint, chg = e.st === 'chg', heavy = d.sh === 'heavy', w = heavy ? 1.45 : 1.05, mv = e.st === 'in' || e.st === 'mv' || e.st === 'rush' ? Math.sin(t * 11 + e.id) * 0.18 : 0;
    c.lineCap = 'round'; c.lineJoin = 'round';
    const kneel = d.sh === 'mortar';
    // 다리
    c.strokeStyle = shade(tint, -0.55); c.lineWidth = R * (heavy ? 0.5 : 0.36);
    if (kneel) { line(c, -R * 0.3, R * 0.4, -R * 0.7, R * 1.0); line(c, R * 0.3, R * 0.4, R * 0.6, R * 0.75); line(c, R * 0.6, R * 0.75, R * 0.2, R * 1.05); }
    else { line(c, -R * 0.28, R * 0.4, -R * (0.36 + mv), R * 1.3); line(c, R * 0.28, R * 0.4, R * (0.36 - mv), R * 1.3); }
    // 몸통
    c.fillStyle = tint; c.strokeStyle = shade(tint, -0.6); c.lineWidth = R * 0.07;
    rrect(c, -R * w * 0.5, -R * 0.6, R * w, R * 1.1, R * 0.22); c.fill(); c.stroke();
    c.fillStyle = shade(tint, -0.3); rrect(c, -R * w * 0.36, -R * 0.42, R * w * 0.72, R * 0.6, R * 0.12); c.fill();
    if (heavy) { c.fillStyle = shade(tint, -0.2); rrect(c, -R * 0.95, -R * 0.68, R * 0.5, R * 0.44, R * 0.12); c.fill(); rrect(c, R * 0.45, -R * 0.68, R * 0.5, R * 0.44, R * 0.12); c.fill(); }
    if (d.sh === 'bomb') { c.fillStyle = '#3a3030'; rrect(c, -R * 0.5, -R * 0.3, R, R * 0.55, R * 0.1); c.fill(); const pl = 0.5 + 0.5 * Math.sin(t * 5); c.fillStyle = 'rgba(255,80,50,' + (0.45 + 0.5 * pl).toFixed(2) + ')'; circ(c, 0, -R * 0.03, R * 0.17); c.fill(); }
    // 머리
    c.fillStyle = shade(SKIN, -0.2); circ(c, 0, -R * 1.05, R * 0.36); c.fill();
    c.fillStyle = shade(tint, -0.4); c.beginPath(); c.arc(0, -R * 1.1, R * 0.42, Math.PI * 0.95, Math.PI * 2.05); c.fill();
    c.fillStyle = 'rgba(20,20,26,.8)'; c.fillRect(-R * 0.3, -R * 1.08, R * 0.6, R * 0.13);
    if (o.k === 'officer') { c.fillStyle = '#d8b84a'; c.fillRect(-R * 0.42, -R * 1.2, R * 0.84, R * 0.1); }
    if (o.k === 'engineer') { c.strokeStyle = '#8ad08a'; c.lineWidth = R * 0.12; line(c, -R * 0.12, -R * 0.12, R * 0.12, -R * 0.12); line(c, 0, -R * 0.24, 0, 0); }
    // 무기
    c.strokeStyle = GUN; c.lineWidth = R * (heavy ? 0.3 : 0.2);
    if (d.sh === 'mortar') { c.lineWidth = R * 0.34; line(c, R * 0.75, R * 1.0, R * 1.25, -R * 0.3); c.strokeStyle = GUN2; c.lineWidth = R * 0.12; line(c, R * 1.0, R * 0.35, R * 0.6, R * 1.05); }
    else if (d.sh === 'bomb') { /* 맨손 */ }
    else if (chg) { c.fillStyle = GUN; circ(c, R * 0.22, -R * 0.2, R * (heavy ? 0.3 : 0.2)); c.fill(); c.lineWidth = R * 0.16; line(c, R * 0.22, -R * 0.2, R * 0.5, R * 0.3); c.fillStyle = '#0c0c10'; circ(c, R * 0.22, -R * 0.2, R * 0.09); c.fill(); if (d.long) { c.fillStyle = 'rgba(255,255,255,' + (0.4 + 0.3 * Math.sin(t * 4)).toFixed(2) + ')'; circ(c, R * 0.22, -R * 0.48, R * 0.1); c.fill(); } }
    else line(c, -R * 0.55, R * 0.25, R * (d.long ? 1.1 : 0.7), -R * (d.long ? 0.75 : 0.45));
  }
  function drone(c, e, R, t, o) {
    const tint = e.d.tint, bob = Math.sin(t * 3 + e.id) * R * 0.08;
    c.translate(0, bob);
    c.strokeStyle = shade(tint, -0.5); c.lineWidth = R * 0.14; c.lineCap = 'round';
    for (const s of [-1, 1]) { line(c, 0, 0, s * R * 1.0, -R * 0.45); line(c, 0, 0, s * R * 0.9, R * 0.3); }
    c.fillStyle = 'rgba(210,220,230,.28)'; for (const s of [-1, 1]) { c.beginPath(); c.ellipse(s * R * 1.0, -R * 0.5, R * 0.5, R * 0.12, 0, 0, TAU); c.fill(); c.beginPath(); c.ellipse(s * R * 0.9, R * 0.25, R * 0.45, R * 0.11, 0, 0, TAU); c.fill(); }
    c.fillStyle = tint; c.strokeStyle = shade(tint, -0.6); c.lineWidth = R * 0.08; c.beginPath(); c.ellipse(0, 0, R * 0.62, R * 0.46, 0, 0, TAU); c.fill(); c.stroke();
    const k = o.k;
    c.fillStyle = k === 'swarm' ? 'rgba(255,90,60,.95)' : k === 'aegis' ? '#7fe0f0' : k === 'jammer' ? '#c890f0' : '#ffd070'; circ(c, 0, R * 0.05, R * 0.2); c.fill();
    if (k === 'aegis') { c.strokeStyle = 'rgba(127,224,240,.5)'; c.lineWidth = R * 0.08; c.beginPath(); c.arc(0, 0, R * 1.25, 0, TAU); c.stroke(); }
    if (k === 'jammer') { c.strokeStyle = 'rgba(200,144,240,.6)'; c.lineWidth = R * 0.08; const ph = (t * 0.8) % 1; for (let i = 0; i < 2; i++) { c.globalAlpha *= 1 - ((ph + i * 0.5) % 1); c.beginPath(); c.arc(0, -R * 0.5, R * (0.5 + ((ph + i * 0.5) % 1) * 1.1), Math.PI * 1.2, Math.PI * 1.8); c.stroke(); c.globalAlpha /= Math.max(0.001, 1 - ((ph + i * 0.5) % 1)); } line(c, 0, -R * 0.4, 0, -R * 0.9); }
  }
  function enemy(c, e, x, y, R, t, o) {
    o = o || {};
    const d = e.d;
    c.save(); c.translate(x, y);
    if (!d.fly) { c.fillStyle = 'rgba(0,0,0,.26)'; c.beginPath(); c.ellipse(0, R * 1.32, R * 0.9, R * 0.2, 0, 0, TAU); c.fill(); }
    c.globalAlpha = 1 - 0.8 * clamp(e.cl || 0, 0, 1);
    if (d.sh === 'drone') drone(c, e, R, t, { k: e.k });
    else if (d.sh === 'turret') {
      c.strokeStyle = '#2a2c30'; c.lineWidth = R * 0.18; c.lineCap = 'round'; line(c, 0, R * 0.3, -R * 0.8, R * 1.3); line(c, 0, R * 0.3, R * 0.8, R * 1.3); line(c, 0, R * 0.3, 0, R * 1.3);
      c.fillStyle = d.tint; c.strokeStyle = shade(d.tint, -0.6); c.lineWidth = R * 0.08; rrect(c, -R * 0.75, -R * 0.75, R * 1.5, R * 1.1, R * 0.2); c.fill(); c.stroke();
      if (e.sh) { c.fillStyle = shade(d.tint, 0.25); rrect(c, -R * 0.6, -R * 0.6, R * 1.2, R * 0.8, R * 0.1); c.fill(); c.strokeStyle = shade(d.tint, -0.4); line(c, 0, -R * 0.6, 0, R * 0.2); }
      else { c.fillStyle = '#101014'; circ(c, 0, -R * 0.2, R * 0.34); c.fill(); c.fillStyle = 'rgba(255,90,60,.9)'; circ(c, 0, -R * 0.2, R * 0.14); c.fill(); }
    } else if (d.sh === 'hound') {
      const run = Math.sin(t * 14 + e.id) * 0.3;
      c.strokeStyle = shade(d.tint, -0.5); c.lineWidth = R * 0.2; c.lineCap = 'round';
      line(c, -R * 0.6, R * 0.1, -R * (0.8 + run), R * 1.0); line(c, R * 0.6, R * 0.1, R * (0.8 - run), R * 1.0); line(c, -R * 0.3, R * 0.1, -R * (0.3 - run), R * 1.0); line(c, R * 0.3, R * 0.1, R * (0.3 + run), R * 1.0);
      c.fillStyle = d.tint; c.strokeStyle = shade(d.tint, -0.6); c.lineWidth = R * 0.08; rrect(c, -R * 0.85, -R * 0.4, R * 1.7, R * 0.75, R * 0.3); c.fill(); c.stroke();
      c.fillStyle = shade(d.tint, -0.3); rrect(c, -R * 0.36, -R * 0.75, R * 0.72, R * 0.6, R * 0.2); c.fill(); c.fillStyle = 'rgba(255,90,60,.9)'; c.fillRect(-R * 0.22, -R * 0.55, R * 0.44, R * 0.1);
    } else {
      soldier(c, e, R, t, { k: e.k });
      if (d.sh === 'shield') {
        const sx = e.sh ? 0 : R * 0.95;
        c.fillStyle = e.sh ? '#8e96a8' : '#70788a'; c.strokeStyle = '#30343e'; c.lineWidth = R * 0.09; rrect(c, sx - R * 0.72, -R * 0.75, R * 1.44 * (e.sh ? 1 : 0.45), R * 1.75, R * 0.2); c.fill(); c.stroke();
        if (e.sh) { c.fillStyle = 'rgba(20,24,30,.8)'; c.fillRect(-R * 0.4, -R * 0.5, R * 0.8, R * 0.16); }
      }
    }
    if (e.fl > 0) { c.globalAlpha = Math.min(1, e.fl) * 0.6; c.fillStyle = '#fff'; c.beginPath(); c.ellipse(0, d.fly ? 0 : R * 0.05, R * 0.8, R * (d.fly ? 0.6 : 1.3), 0, 0, TAU); c.fill(); }
    c.restore();
  }

  /* ───────── 우두머리 — 원점 = 몸 중심, 단위 = 시뮬 단위(부위 위치가 판정과 같음) ───────── */
  function boss(c, e, x, y, sx, sy, t) {
    const d = e.d, tint = d.tint, dk = shade(tint, -0.5), lt = shade(tint, 0.18), r = d.r;
    const part = (id) => e.parts.find((p) => p.id === id), okp = (id) => part(id).hp > 0;
    c.save(); c.translate(x, y); c.scale(sx, sy);
    c.globalAlpha = 1 - 0.78 * clamp(e.cl || 0, 0, 1);
    c.lineJoin = 'round'; c.lineCap = 'round'; c.strokeStyle = dk; c.lineWidth = 0.5; c.fillStyle = tint;
    const k = d.sh, mod = (p, f) => { const a = p.hp > 0; c.fillStyle = a ? shade(tint, -0.15) : '#26262a'; c.strokeStyle = a ? dk : '#18181c'; c.lineWidth = 0.5; f(a); };
    if (!d.fly) { c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(0, r * 1.25, r * 1.5, r * 0.22, 0, 0, TAU); c.fill(); c.fillStyle = tint; }
    if (k === 'walker') {
      c.strokeStyle = dk; c.lineWidth = 3.2; line(c, -6, 6, -9, 16); line(c, 6, 6, 9, 16); c.lineWidth = 4; line(c, -10.5, 16, -7, 16); line(c, 7, 16, 10.5, 16);
      c.lineWidth = 0.5; rrect(c, -10, -8, 20, 15, 3); c.fill(); c.stroke(); c.fillStyle = lt; rrect(c, -6, -5, 12, 5, 1.5); c.fill(); c.fillStyle = 'rgba(255,120,80,.9)'; c.fillRect(-4, -3.4, 8, 1.4);
      for (const id of ['lg', 'rg']) { const p = part(id); mod(p, (a) => { rrect(c, p.ox - 3.6, p.oy - 3.2, 7.2, 6.4, 1.4); c.fill(); c.stroke(); c.fillStyle = '#0e0e12'; circ(c, p.ox - 1.3, p.oy + 0.6, 1.1); c.fill(); circ(c, p.ox + 1.3, p.oy + 0.6, 1.1); c.fill(); }); }
      const p = part('pod'); mod(p, () => { rrect(c, p.ox - 5, p.oy - 3, 10, 6, 1.2); c.fill(); c.stroke(); c.fillStyle = '#0e0e12'; for (let i = 0; i < 4; i++) { circ(c, p.ox - 3.3 + i * 2.2, p.oy, 0.8); c.fill(); } });
    } else if (k === 'heli') {
      c.fillStyle = 'rgba(210,220,230,.22)'; c.beginPath(); c.ellipse(0, -8.5, 17, 1.7, 0, 0, TAU); c.fill();
      c.strokeStyle = dk; c.lineWidth = 1.2; line(c, 0, -8.5, 0, -5); c.lineWidth = 2.2; line(c, 6, -3, 15, -6);
      c.fillStyle = tint; c.lineWidth = 0.5; c.beginPath(); c.ellipse(0, 0, 9.5, 6.2, 0, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = 'rgba(150,200,220,.55)'; c.beginPath(); c.ellipse(0, -0.5, 5.6, 3.3, 0, 0, TAU); c.fill();
      c.strokeStyle = dk; c.lineWidth = 1.3; line(c, -8, 2, -13, 3); line(c, 8, 2, 13, 3);
      for (const id of ['lp', 'rp']) { const p = part(id); mod(p, () => { rrect(c, p.ox - 3.2, p.oy - 2.2, 6.4, 4.4, 1.6); c.fill(); c.stroke(); c.fillStyle = '#0e0e12'; circ(c, p.ox - 1.2, p.oy, 0.9); c.fill(); circ(c, p.ox + 1.2, p.oy, 0.9); c.fill(); }); }
      const p = part('tail'); mod(p, (a) => { circ(c, p.ox, p.oy, 1.4); c.fill(); c.stroke(); if (a) { c.fillStyle = 'rgba(210,220,230,.3)'; circ(c, p.ox, p.oy, 3.4); c.fill(); } });
    } else if (k === 'cannon') {
      c.fillStyle = dk; for (let i = -2; i <= 2; i++) { circ(c, i * 6.5, 14, 2.6); c.fill(); }
      c.fillStyle = tint; rrect(c, -18, 2, 36, 11, 2); c.fill(); c.stroke(); rrect(c, -9, -10, 18, 14, 2.5); c.fill(); c.stroke();
      const b = part('barrel'); mod(b, (a) => { circ(c, b.ox, b.oy, 4.6); c.fill(); c.stroke(); c.fillStyle = '#0a0a0e'; circ(c, b.ox, b.oy, 2.8); c.fill(); if (a) { c.fillStyle = 'rgba(180,120,255,.35)'; circ(c, b.ox, b.oy, 1.6); c.fill(); } });
      for (const id of ['loader', 'plate']) { const p = part(id); mod(p, () => { rrect(c, p.ox - 4, p.oy - 3.6, 8, 7.2, 1.2); c.fill(); c.stroke(); c.strokeStyle = '#0e0e12'; c.lineWidth = 0.9; if (id === 'loader') line(c, p.ox - 2, p.oy - 4, p.ox + 1, p.oy - 8); else { line(c, p.ox - 1.5, p.oy, p.ox + 1.5, p.oy); } }); }
    } else if (k === 'spider') {
      c.strokeStyle = dk; c.lineWidth = 1.8; line(c, -7, -1, -15, -7); line(c, -15, -7, -19, 9); line(c, 7, -1, 15, -7); line(c, 15, -7, 19, 9);
      for (const id of ['ll', 'rl']) { const p = part(id), s = id === 'll' ? -1 : 1; c.strokeStyle = p.hp > 0 ? dk : '#18181c'; c.lineWidth = 2.4; if (p.hp > 0) { line(c, s * 6, 2, s * 12, -2); line(c, s * 12, -2, p.ox, p.oy + 6); } else line(c, s * 6, 2, s * 10, 4); mod(p, () => { circ(c, p.ox, p.oy, 2.6); c.fill(); c.stroke(); }); }
      c.fillStyle = tint; c.strokeStyle = dk; c.lineWidth = 0.5; c.beginPath(); c.ellipse(0, 1, 9.5, 6.5, 0, 0, TAU); c.fill(); c.stroke(); c.fillStyle = 'rgba(255,120,80,.9)'; for (let i = -1; i <= 1; i++) { circ(c, i * 2.6, 2.4, 0.8); c.fill(); }
      const p = part('tur'); mod(p, () => { rrect(c, p.ox - 4.4, p.oy - 3.2, 8.8, 6.4, 2); c.fill(); c.stroke(); c.fillStyle = '#0e0e12'; circ(c, p.ox, p.oy + 0.4, 1.5); c.fill(); });
    } else if (k === 'fort') {
      c.fillStyle = tint; c.beginPath(); c.moveTo(-24, 14); c.lineTo(-21, -2); c.lineTo(21, -2); c.lineTo(24, 14); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = dk; rrect(c, -5, 4, 10, 10, 1); c.fill(); c.fillStyle = lt; c.fillRect(-21, -2, 42, 1.4); c.fillStyle = 'rgba(0,0,0,.35)'; for (let i = -3; i <= 3; i++) if (i) c.fillRect(i * 5.6 - 1, 1.5, 2, 1.6);
      for (const id of ['t0', 't1', 't2']) { const p = part(id); mod(p, () => { rrect(c, p.ox - 4, p.oy - 3, 8, 7, 1.6); c.fill(); c.stroke(); c.fillStyle = '#0e0e12'; circ(c, p.ox, p.oy + 0.4, 1.4); c.fill(); }); }
    } else if (k === 'ghost') {
      c.strokeStyle = dk; c.lineWidth = 2.2; line(c, -3, 6, -4.5, 15); line(c, 3, 6, 4.5, 15);
      c.fillStyle = tint; c.lineWidth = 0.5; c.beginPath(); c.moveTo(-6, -6); c.lineTo(6, -6); c.lineTo(4, 7); c.lineTo(-4, 7); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = lt; c.beginPath(); c.moveTo(-2.4, -12); c.lineTo(2.4, -12); c.lineTo(3, -7); c.lineTo(-3, -7); c.closePath(); c.fill(); c.fillStyle = 'rgba(160,140,255,.9)'; c.fillRect(-2, -10.2, 4, 0.9);
      c.strokeStyle = dk; c.lineWidth = 1.8; line(c, -6, -4, -10, 3);
      const g1 = part('gen'); mod(g1, (a) => { rrect(c, g1.ox - 3.6, g1.oy - 5.2, 7.2, 3.4, 1); c.fill(); c.stroke(); if (a) { c.fillStyle = 'rgba(160,140,255,.5)'; c.fillRect(g1.ox - 2.6, g1.oy - 4.2, 5.2, 1.2); } });
      const a1 = part('arm'); mod(a1, (a) => { c.lineWidth = 1.8; c.strokeStyle = a ? dk : '#18181c'; line(c, 6, -4, a1.ox, a1.oy); if (a) { c.fillStyle = '#c8d0e0'; c.beginPath(); c.moveTo(a1.ox - 0.8, a1.oy); c.lineTo(a1.ox + 1.6, a1.oy + 9); c.lineTo(a1.ox + 1.4, a1.oy - 0.5); c.fill(); } circ(c, a1.ox, a1.oy, 1.8); c.fillStyle = a ? shade(tint, -0.15) : '#26262a'; c.fill(); });
    } else {   // hive
      c.fillStyle = tint; c.beginPath(); c.ellipse(0, 0, 19, 8.5, 0, 0, TAU); c.fill(); c.stroke();
      c.fillStyle = lt; c.beginPath(); c.ellipse(0, -3, 14, 3.4, 0, Math.PI, TAU); c.fill(); c.fillStyle = dk; c.fillRect(-3, 6.5, 6, 3.4);
      for (const id of ['lb', 'rb']) { const p = part(id); mod(p, (a) => { rrect(c, p.ox - 4.2, p.oy - 3, 8.4, 6, 1.4); c.fill(); c.stroke(); c.fillStyle = a ? '#0c0c10' : '#1a1a1e'; rrect(c, p.ox - 3, p.oy - 1.8, 6, 3.6, 0.8); c.fill(); if (a) { c.fillStyle = 'rgba(255,170,70,.75)'; c.fillRect(p.ox - 2.4, p.oy + 0.9, 4.8, 0.6); } }); }
      const p = part('ant'); mod(p, (a) => { c.lineWidth = 0.9; c.strokeStyle = a ? dk : '#18181c'; line(c, 0, -8, p.ox, p.oy); circ(c, p.ox, p.oy, 1.7); c.fill(); if (a) { c.fillStyle = 'rgba(255,90,60,' + (0.5 + 0.4 * Math.sin(t * 3)).toFixed(2) + ')'; circ(c, p.ox, p.oy, 0.8); c.fill(); } });
    }
    for (const p of e.parts) if (p.fl > 0 && p.hp > 0) { c.fillStyle = 'rgba(255,255,255,' + (p.fl * 0.55).toFixed(3) + ')'; circ(c, p.ox, p.oy, p.r * 0.9); c.fill(); }
    if (e.fl > 0) { c.fillStyle = 'rgba(255,255,255,' + (e.fl * 0.22).toFixed(3) + ')'; c.beginPath(); c.ellipse(0, 0, r * 0.9, r * 0.7, 0, 0, TAU); c.fill(); }
    c.restore();
  }

  /* ───────── 전장 배경(구간이 바뀔 때 한 번 그려 둠) — lay: { W, H, X(x), Y(y), kx, ky } ───────── */
  function bg(c, lay, th, seed) {
    const W = lay.W, H = lay.H, hz = lay.Y(13), gb = lay.Y(131);
    let gr = c.createLinearGradient(0, 0, 0, hz); gr.addColorStop(0, th.sky[0]); gr.addColorStop(0.65, th.sky[1]); gr.addColorStop(1, th.sky[2]); c.fillStyle = gr; c.fillRect(0, 0, W, hz + 1);
    // 먼 풍경
    c.fillStyle = th.far; const n = 16, bw = W / n;
    for (let i = -1; i <= n; i++) {
      const r1 = hsh(seed, i * 7 + 1), r2 = hsh(seed, i * 7 + 2), x = i * bw + r2 * bw * 0.3, hh = lay.ky * (4 + r1 * 9);
      if (th.prop === 'bld') { c.fillRect(x, hz - hh, bw * (0.6 + r2 * 0.5), hh + 1); if (r1 > 0.6) c.fillRect(x + bw * 0.2, hz - hh - lay.ky * 2, bw * 0.12, lay.ky * 2); }
      else if (th.prop === 'crane') { if (i % 3 === 0) { c.fillRect(x, hz - hh * 1.3, bw * 0.12, hh * 1.3); c.fillRect(x - bw * 0.8, hz - hh * 1.3, bw * 2, lay.ky * 0.7); } else c.fillRect(x, hz - hh * 0.45, bw * 1.1, hh * 0.45 + 1); }
      else if (th.prop === 'peak' || th.prop === 'dune') { const k = th.prop === 'peak' ? 1.5 : 0.6; c.beginPath(); c.moveTo(x - bw, hz + 1); c.quadraticCurveTo(x + bw * 0.4, hz - hh * k * (th.prop === 'peak' ? 1.6 : 1.2), x + bw * 1.8, hz + 1); c.fill(); }
      else { c.fillRect(x, hz - hh * 0.6, bw * 1.05, hh * 0.6 + 1); if (i % 2 === 0) { c.fillRect(x + bw * 0.3, hz - hh * 1.5, bw * 0.16, hh * 1.5); } }
    }
    c.fillStyle = 'rgba(255,255,255,.06)'; c.fillRect(0, hz - lay.ky * 2.5, W, lay.ky * 2.5);
    // 바닥
    gr = c.createLinearGradient(0, hz, 0, gb); gr.addColorStop(0, th.gnd[1]); gr.addColorStop(0.25, th.gnd[0]); gr.addColorStop(1, th.gnd[1]); c.fillStyle = gr; c.fillRect(0, hz, W, H - hz);
    c.strokeStyle = th.line; c.globalAlpha = 0.28; c.lineWidth = 1;
    const cx = lay.X(50);
    for (let i = -6; i <= 6; i++) { c.beginPath(); c.moveTo(cx + i * lay.kx * 5, hz); c.lineTo(cx + i * lay.kx * 22, gb); c.stroke(); }
    for (let j = 0; j < 7; j++) { const yy = lay.Y(13 + Math.pow(j / 7, 1.7) * 100); c.beginPath(); c.moveTo(0, yy); c.lineTo(W, yy); c.stroke(); }
    c.globalAlpha = 1;
    // 흩어진 구조물(깊이감)
    for (let i = 0; i < 9; i++) {
      const fx = 4 + hsh(seed, i * 5 + 40) * 92, fy = 20 + hsh(seed, i * 5 + 41) * 62, s = (0.5 + 0.5 * clamp((fy - 10) / 70, 0, 1)) * lay.kx, x = lay.X(fx), y = lay.Y(fy), kind = hsh(seed, i * 5 + 42);
      c.fillStyle = 'rgba(0,0,0,.22)'; c.beginPath(); c.ellipse(x, y + s * 0.4, s * 5, s * 0.9, 0, 0, TAU); c.fill();
      c.fillStyle = shade(th.far, kind > 0.5 ? 0.12 : 0.02);
      if (kind < 0.4) { c.fillRect(x - s * 4, y - s * 3.4, s * 8, s * 3.6); c.fillStyle = shade(th.far, 0.22); c.fillRect(x - s * 4, y - s * 3.4, s * 8, s * 0.6); }
      else if (kind < 0.7) { for (let b = 0; b < 3; b++) { c.beginPath(); c.ellipse(x + (b - 1) * s * 2.6, y - s * 0.9, s * 1.7, s * 1.1, 0, 0, TAU); c.fill(); } }
      else { c.beginPath(); c.moveTo(x - s * 4.5, y); c.lineTo(x - s * 3, y - s * 2.6); c.lineTo(x + s * 2, y - s * 3); c.lineTo(x + s * 4.5, y); c.fill(); }
    }
    // 가장자리 어둡게
    gr = c.createLinearGradient(0, lay.Y(90), 0, H); gr.addColorStop(0, 'rgba(8,8,14,0)'); gr.addColorStop(1, 'rgba(8,8,14,.5)'); c.fillStyle = gr; c.fillRect(0, lay.Y(90), W, H - lay.Y(90));
    const fx0 = lay.X(0), fx1 = lay.X(100);
    if (fx0 > 4) { gr = c.createLinearGradient(0, 0, fx0, 0); gr.addColorStop(0, 'rgba(8,8,14,.9)'); gr.addColorStop(1, 'rgba(8,8,14,0)'); c.fillStyle = gr; c.fillRect(0, 0, fx0, H); gr = c.createLinearGradient(fx1, 0, W, 0); gr.addColorStop(0, 'rgba(8,8,14,0)'); gr.addColorStop(1, 'rgba(8,8,14,.9)'); c.fillStyle = gr; c.fillRect(fx1, 0, W - fx1, H); }
  }

  CS.DRAW = { bust, shooter, cover, enemy, boss, bg, shade, rrect, circ, line, hsh };
})();
