/* 엄폐 사격 — 순수 시뮬(초당 60 고정 걸음). DOM · Math.random 없음(시드 난수 g.r). node에서도 돎.
   좌표: 가로 0~100, 세로 0(먼 곳)~130(화면 아래). 적은 y 14~74, 엄폐물 y 104, 사수 발 y 126. 멀수록(y가 작을수록) 작게 보임(sc). */
(function () {
  const G = typeof window !== 'undefined' ? window : globalThis;
  const CS = G.COVERSHOT = G.COVERSHOT || {};
  const D = CS.DATA, W = D.WEAPONS, EN = D.ENEMIES, BS = D.BOSSES;
  const SH = {}; D.SHOOTERS.forEach((s) => { SH[s.id] = s; });
  const DT = 1 / 60, SLOTX = [20, 50, 80], COVY = 104, MUZY = 99, ALLY = 0.45, JUDG = 0.86, COVHP = 300, ASSIST = 12;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v), lerp = (a, b, t) => a + (b - a) * t;
  const sc = (y) => 0.5 + 0.5 * clamp((y - 10) / 70, 0, 1);
  function rnd(g) { let t = (g.r = (g.r + 0x6D2B79F5) | 0); t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  const rr = (g, a, b) => a + (b - a) * rnd(g);
  const hash = (a, b) => { let x = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263)) | 0; x = Math.imul(x ^ (x >>> 13), 1274126177); return ((x ^ (x >>> 16)) >>> 0) / 4294967296; };
  const ev = (g, o) => { g.ev.push(o); };

  /* ───────── 판 만들기 ───────── */
  function create(seed, o) {
    o = o || {};
    const len = D.LENS[o.len] || D.LENS.short;
    const g = { r: seed | 0, seed: seed | 0, o: { assist: o.assist === 0 ? 0 : 1 }, ph: 'pick', T: 0, N: len.n, mid: len.mid, si: -1, done: 0, sq: [], cov: [], act: 0,
      en: [], th: [], pj: [], zn: [], pg: [], ev: [], nid: 1, bf: {}, up: {}, ups: [], m: {}, opts: null, rr: 1, kills: 0, dodge: 0, st: null, pt: 0, jam: false, won: false };
    const tk = D.THEMES.map((t, i) => i); for (let i = tk.length - 1; i > 0; i--) { const j = Math.floor(rnd(g) * (i + 1)), t = tk[i]; tk[i] = tk[j]; tk[j] = t; }
    g.thm = tk;
    const bk = Object.keys(BS);
    g.bossId = BS[o.boss] ? o.boss : bk[Math.floor(rnd(g) * bk.length)];
    const rest = bk.filter((k) => k !== g.bossId); g.midId = rest[Math.floor(rnd(g) * rest.length)];
    calcMods(g);
    return g;
  }
  function calcMods(g) {
    const m = { dmg: 0, rof: 0, mag: 0, rld: 0, wk: 0, crit: 0, first: 0, exe: 0, aoe: 0, aoeD: 0, boss: 0, stg: 0, shp: 0, kill: 0, hp: 0, cov: 0, rep: 0, med: 0, low: 0, quick: 0, armor: 0, rev: 0,
      sk: 0, ally: 0, judg: 0, burst: 0, burstT: 0, slow: 0, dodge: 0, icpt: 0, icD: 0, arSp: 0, arD: 0, srC: 0, sgFar: 0, sgPel: 0, mgHeat: 0, mgKeep: 0, glClu: 0, smgR: 0, smgL: 0 };
    D.UPG.forEach((u) => { const lv = g.up[u.id] || 0; if (lv) for (const k in u.fx) m[k] += u.fx[k] * lv; });
    g.m = m;
  }
  const magOf = (g, sh) => Math.round(W[sh.w].mag * (1 + g.m.mag));
  function setSquad(g, ids) {
    const all = D.SHOOTERS.map((s) => s.id), pick = [];
    (ids || []).forEach((id) => { if (SH[id] && pick.indexOf(id) < 0 && pick.length < 3) pick.push(id); });
    while (pick.length < 3) { const id = all[Math.floor(rnd(g) * all.length)]; if (pick.indexOf(id) < 0) pick.push(id); }
    g.sq = pick.map((id, i) => { const s = SH[id], w = W[s.w];
      return { id, n: s.n, w: s.w, cls: w.cls, slot: i, hp: s.hp, mhp: s.hp, bhp: s.hp, down: false, pose: 0, pp: 0, ammo: w.mag, cd: 0, heat: 0, heatK: 0, chg: 0, bq: 0, bt: 0, g: 0, rt: 0, outT: 0, lastOut: -9,
        lockR: false, dmg: 0, shots: 0, hitn: 0, hits: 0, ax: SLOTX[i], ay: 45, lk: 0, rec: 0, fl: 0, bK: '', bT: 0, ai: { out: false, t: 0.4 + i * 0.5, tg: 0 } }; });
    g.cov = [0, 1, 2].map(() => ({ hp: COVHP, mhp: COVHP, fl: 0 }));
    g.act = 0;
    startStage(g, 0);
    g.ph = 'fight';
  }

  /* ───────── 구간 ───────── */
  function startStage(g, i) {
    g.si = i; g.en = []; g.th = []; g.pj = []; g.zn = []; g.pg = [];
    const p = g.N > 1 ? i / (g.N - 1) : 1;
    const bossId = i === g.N - 1 ? g.bossId : (g.mid && i === g.mid - 1 ? g.midId : null);
    const st = g.st = { i, t: 0, p, type: 'clear', hm: 1 + (0.7 + 0.05 * (g.N - 8)) * p, dm: 1 + (0.3 + 0.025 * (g.N - 8)) * p, waves: [], wi: 0, wt: 0, q: [], set: [], theme: g.thm[Math.min(g.thm.length - 1, Math.floor(i / Math.ceil(g.N / 3)))], boss: null, dur: 0, sc: 0, cap: 5 + Math.floor(p * 3), hvt: 0, end: 0 };
    if (bossId) {
      const fin = i === g.N - 1;   // 우두머리 앞 재정비: 마지막은 엄폐물 전부 수리 · 체력 +30%, 중간 우두머리는 엄폐물 +50% · 체력 +15%
      if (i > 0) { g.cov.forEach((c) => { c.hp = fin ? c.mhp : Math.min(c.mhp, c.hp + c.mhp * 0.5); }); g.sq.forEach((s) => { if (!s.down) s.hp = Math.min(s.mhp, s.hp + s.mhp * (fin ? 0.3 : 0.15)); }); }
      st.type = 'boss'; st.boss = bossId; st.mini = i !== g.N - 1; st.q.push({ k: bossId, t: 1.4, boss: 1 }); ev(g, { t: 'stage', i }); return; }
    if (i > 0) { const x = rnd(g); st.type = x < 0.6 ? 'clear' : x < 0.8 ? 'hold' : 'hvt'; }
    const pool = Object.keys(EN).filter((k) => EN[k].f <= p + 0.04);
    const basics = pool.filter((k) => k === 'rifle' || k === 'trooper' || k === 'elite');
    const set = [basics[Math.floor(rnd(g) * basics.length)]];
    const want = Math.min(pool.length, 3 + (p > 0.35 ? 1 : 0) + (p > 0.7 ? 1 : 0));
    let guard = 0;
    while (set.length < want && guard++ < 60) { let tot = 0; pool.forEach((k) => { tot += 1 + 3 * EN[k].f; }); let x = rnd(g) * tot, pk = pool[0]; for (const k of pool) { x -= 1 + 3 * EN[k].f; if (x <= 0) { pk = k; break; } } if (set.indexOf(pk) < 0) set.push(pk); }
    st.set = set;
    if (st.type === 'hold') { st.dur = 26 + 8 * p; ev(g, { t: 'stage', i }); return; }
    let budget = (16 + 30 * p) * (st.type === 'hvt' ? 0.75 : 1);
    const list = [], cnt = {};
    guard = 0;
    while (budget > 0.6 && list.length < 34 && guard++ < 80) {
      const k = rnd(g) < 0.35 ? set[0] : set[Math.floor(rnd(g) * set.length)], d = EN[k];
      const lim = d.aura ? 1 + (p > 0.6 ? 1 : 0) : k === 'jugger' ? 1 + (p > 0.8 ? 1 : 0) : k === 'swarm' ? 8 : 6;
      if ((cnt[k] || 0) >= lim || d.c > budget + 0.5) continue;
      cnt[k] = (cnt[k] || 0) + 1; list.push(k); budget -= d.c;
    }
    if (!list.length) list.push('rifle');
    for (let a = 0; a < list.length; a += st.cap) st.waves.push(list.slice(a, a + st.cap));
    if (st.type === 'hvt') st.waves[0].unshift('*hvt');
    ev(g, { t: 'stage', i });
  }
  function spot(g, d) {
    let x = 50, y = 40;
    for (let a = 0; a < 8; a++) {
      x = rr(g, 10, 90); y = rr(g, d.row[0], d.row[1]);
      let ok = true; for (const e of g.en) if (!e.dead && Math.abs(e.tx - x) < 9 && Math.abs(e.ty - y) < 7) { ok = false; break; }
      if (ok) break;
    }
    return [x, y];
  }
  function spawn(g, k, o) {
    o = o || {};
    if (BS[k]) {
      const d = BS[k], st = g.st, mul = (st.mini ? 0.35 : 1) * (1 + 0.12 * (g.N - 8) / 2);
      const e = { id: g.nid++, k, d, boss: 1, x: 50, y: -8, px: 50, py: -8, tx: 50, ty: d.y, hp: d.hp * mul, mhp: d.hp * mul, r: d.r, st: 'in', cd: 2.2, fl: 0, sn: 0, stg: 0, inv: 0, phs: 0, cl: 0, sh: false, dead: false, last: -1, ph0: rnd(g) * 6.28, off: 0,
        parts: d.parts.map((p) => ({ id: p.id, n: p.n, hp: p.hp * mul, mhp: p.hp * mul, ox: p.ox, oy: p.oy, r: p.r, fl: 0 })) };
      g.en.push(e); ev(g, { t: 'boss', k }); return e;
    }
    const hvt = k === '*hvt'; if (hvt) k = 'officer';
    const d = EN[k], st = g.st, p = spot(g, d), side = rnd(g) < 0.5 ? -1 : 1;
    const fromSide = d.mv === 'strafe' || d.mv === 'hop';
    const e = { id: g.nid++, k, d, x: fromSide ? (side < 0 ? -5 : 105) : clamp(p[0] + rr(g, -14, 14), 4, 96), y: fromSide ? p[1] : 11, tx: p[0], ty: p[1], hp: d.hp * st.hm * (hvt ? 2.4 : 1), r: d.r * (hvt ? 1.12 : 1), st: 'in', cd: 0, mt: rr(g, 3, 6), fl: 0, sn: 0, cl: 0, sh: !!d.shield, dead: false, side, tg: 0, hvt, hx: p[0], hy: p[1], hl: 0, smk: false, pr: 1, hs: 1 };
    if (o.x != null) { e.x = o.x; e.y = o.y; }
    e.px = e.x; e.py = e.y; e.mhp = e.hp;
    if (d.mv === 'rush') { e.st = 'rush'; e.tg = pickSlot(g); }
    if (d.mv === 'flank') { e.st = 'flank'; e.tg = nearSlot(g, side < 0 ? 0 : 2); }
    g.en.push(e); if (hvt) g.st.hvt = e.id;
    return e;
  }
  function pickSlot(g) {
    let tot = 0; const w = g.sq.map((s, i) => { const v = s.down ? 0 : (i === g.act ? 1.5 : 1); tot += v; return v; });
    if (tot <= 0) return 0;
    let x = rnd(g) * tot; for (let i = 0; i < 3; i++) { x -= w[i]; if (x <= 0) return i; }
    return 0;
  }
  function nearSlot(g, s) { const ord = s === 0 ? [0, 1, 2] : s === 2 ? [2, 1, 0] : [1, 0, 2]; for (const i of ord) if (g.sq[i] && !g.sq[i].down) return i; return s; }
  const byId = (g, id) => { for (const e of g.en) if (e.id === id) return e; return null; };
  const alive = (g) => { let n = 0; for (const e of g.en) if (!e.dead && e.st !== 'flee') n++; return n; };

  /* ───────── 피해 ───────── */
  function hurt(g, sh, d) {
    if (g.bf.burst > 0 || sh.down || d <= 0) return;
    sh.hp -= d; sh.hits++; sh.fl = 1; ev(g, { t: 'hurt', s: sh.slot, d });
    if (sh.hp <= 0) {
      sh.hp = 0; sh.down = true; sh.g = 0; ev(g, { t: 'down', s: sh.slot });
      if (g.sq.every((s) => s.down)) { g.ph = 'lost'; return; }
      if (sh.slot === g.act) for (let i = 1; i < 3; i++) { const j = (sh.slot + i) % 3; if (!g.sq[j].down) { g.act = j; ev(g, { t: 'sw', s: j }); break; } }
    }
  }
  function covDmg(g, slot, v) { const c = g.cov[slot]; if (g.bf.fort > 0 || c.hp <= 0) return; c.hp = Math.max(0, c.hp - v); c.fl = 1; if (c.hp <= 0) ev(g, { t: 'covbreak', s: slot }); }
  function directHit(g, slot, dmg, cov) {
    if (g.bf.burst > 0) return;
    const sh = g.sq[slot], c = g.cov[slot], m = g.m, pr = g.bf.fort > 0 ? 0.5 : 1;
    if (sh && !sh.down && sh.pose > 0.35) { hurt(g, sh, dmg * (1 - m.armor) * pr); return; }
    if (c.hp > 0) {
      covDmg(g, slot, cov); ev(g, { t: 'covhit', s: slot });
      if (sh && !sh.down && g.T - sh.lastOut < 0.7) { if (slot === g.act) g.dodge++; sh.g = Math.min(100, sh.g + m.dodge); sh.lastOut = -9; ev(g, { t: 'dodge', s: slot }); }
    } else if (sh && !sh.down) hurt(g, sh, dmg * 0.5 * (1 - m.low) * pr);
  }
  function behindHit(g, slot, dmg, cov) {   // 곡사: 엄폐물 뒤에 떨어짐 — 나와 있으면 피함
    const sh = g.sq[slot], pr = g.bf.fort > 0 ? 0.5 : 1;
    covDmg(g, slot, cov);
    if (!sh || sh.down) return;
    if (sh.pose < 0.65) hurt(g, sh, dmg * (1 - g.m.low) * pr); else { if (slot === g.act) g.dodge++; ev(g, { t: 'dodge', s: slot }); }
  }
  function anyHit(g, slot, dmg, cov) {   // 관통 · 측면: 엄폐 무시
    const sh = g.sq[slot], pr = g.bf.fort > 0 ? 0.5 : 1;
    if (cov) covDmg(g, slot, cov);
    if (sh && !sh.down) hurt(g, sh, dmg * (sh.pose > 0.35 ? 1 - g.m.armor : 1 - g.m.low) * pr);
  }
  function endAttack(g, e, quick) {
    if (!e || e.dead || e.boss) return;
    const a = e.d.a;
    if (e.d.mv === 'flank') { e.st = 'fpos'; e.cd = quick ? 0.8 : rr(g, a.cd[0], a.cd[1]); return; }
    e.st = 'idle'; e.cd = quick ? 0.8 : rr(g, a.cd[0], a.cd[1]);
    if (e.d.mv === 'hop' && !quick) { const p = spot(g, e.d); e.tx = p[0]; e.ty = p[1]; e.st = 'mv'; }
  }
  function cancelThreats(g, e, all) {
    for (const th of g.th) if (!th.dead && (all || th.src === e.id)) { th.dead = 1; if (all) endAttack(g, byId(g, th.src), true); }
  }
  function kill(g, e, sh) {
    if (e.dead) return;
    e.dead = true; e.hp = 0; g.kills++;
    ev(g, { t: 'kill', x: e.x, y: e.y, k: e.k, boss: e.boss ? 1 : 0, r: e.r });
    for (const th of g.th) if (th.src === e.id) th.dead = 1;
    if (sh && g.m.kill) sh.ammo = Math.min(magOf(g, sh), sh.ammo + magOf(g, sh) * g.m.kill);
    if (e.boss) { for (const o of g.en) if (!o.dead && o !== e) { o.dead = true; ev(g, { t: 'kill', x: o.x, y: o.y, k: o.k, boss: 0, r: o.r }); } g.th = []; g.pj = []; g.st.end = 1; }
    if (e.hvt) g.st.end = 1;
  }
  function damage(g, e, d, sh, o) {
    if (e.dead || d <= 0) return 0;
    const m = g.m; o = o || {};
    if (e.boss && e.inv > 0) return 0;
    if (!o.expl && !o.pierce) { if (e.sh) { d *= m.shp; if (d <= 0) { ev(g, { t: 'block', x: e.x, y: e.y }); return 0; } } if (e.smk) d *= 0.5; }
    else if (o.expl && e.sh) d *= 0.5;
    if (e.d.armor && !o.weak) d *= 1 - e.d.armor;
    if (!e.boss) d *= e.pr;
    if (g.bf.mark > 0) d *= 1.4;
    if (e.hp / e.mhp <= 0.3) d *= 1 + m.exe;
    if (e.boss) { d *= 1 + m.boss; if (e.stg > 0) d *= 1.3; }
    if (o.part) {
      const p = o.part; p.hp -= d; p.fl = 1; e.hp -= d * 0.25;
      if (p.hp <= 0) { p.hp = 0; e.hp -= e.mhp * 0.05; const legs = e.k === 'spider' && e.parts.filter((q) => (q.id === 'll' || q.id === 'rl') && q.hp > 0).length === 0 && (p.id === 'll' || p.id === 'rl'); e.stg = legs ? 6 : 3; cancelThreats(g, e); ev(g, { t: 'part', x: e.x + p.ox * sc(e.y), y: e.y + p.oy * sc(e.y), n: p.n }); }
    } else e.hp -= d;
    e.fl = 1;
    if (sh) { sh.dmg += d; sh.g = Math.min(100, sh.g + d * 0.035 * (1 + m.sk) * (g.jam ? 0.5 : 1)); }
    for (const th of g.th) if (!th.dead && th.stg > 0 && th.src === e.id) { th.acc += d * (1 + m.stg); if (th.acc >= th.stg) { th.dead = 1; if (e.boss) e.stg = Math.max(e.stg, 1.6); else { e.sn = 1.6; endAttack(g, e, true); } ev(g, { t: 'stagger', x: e.x, y: e.y }); } }
    ev(g, { t: 'dmg', x: o.px != null ? o.px : e.x, y: o.py != null ? o.py : e.y, d, w: o.weak ? 1 : 0, c: o.crit ? 1 : 0 });
    if (e.hp <= 0) kill(g, e, sh);
    return d;
  }
  function explode(g, x, y, R, dmg, sh, kind) {
    let hits = 0;
    ev(g, { t: 'boom', x, y, r: R, p: kind || 1 });
    for (const e of g.en) {
      if (e.dead) continue;
      const s = sc(e.y);
      if (e.boss) for (const p of e.parts) { if (p.hp <= 0) continue; const dd = Math.hypot(e.x + p.ox * s - x, e.y + p.oy * s - y); if (dd < R + p.r * s) { hits++; damage(g, e, dmg * (1 - 0.5 * Math.min(1, dd / R)), sh, { expl: 1, part: p }); } }
      if (e.dead) continue;
      const dd = Math.hypot(e.x - x, e.y - y);
      if (dd < R + e.r * s) { hits++; damage(g, e, dmg * (1 - 0.5 * Math.min(1, dd / R)), sh, { expl: 1 }); }
    }
    for (const p of g.pj) if (!p.dead && p.t >= 0 && Math.hypot(p.x - x, p.y - y) < R) { p.dead = 1; hits++; ev(g, { t: 'pjkill', x: p.x, y: p.y }); }
    return hits;
  }

  /* ───────── 조준 · 명중 판정 ───────── */
  function hitTest(g, x, y) {
    const ic = 3.4 * (1 + g.m.icpt);
    for (const p of g.pj) if (!p.dead && p.t >= 0 && Math.hypot(p.x - x, p.y - y) < ic) return { pj: p };
    let best = null, by = -99;
    for (const e of g.en) {
      if (e.dead) continue;
      const s = sc(e.y), R = e.r * s;
      if (e.boss) {
        for (const p of e.parts) if (p.hp > 0 && Math.hypot(e.x + p.ox * s - x, e.y + p.oy * s - y) < p.r * s * 1.15) { if (e.y + 50 > by) { by = e.y + 50; best = { e, part: p }; } }
        if (Math.hypot(e.x - x, (e.y - y) / 1.1) < R && e.y > by) { by = e.y; best = { e }; }
        continue;
      }
      const head = !e.d.fly && e.d.sh !== 'turret' && e.d.sh !== 'hound';
      if (head && Math.hypot(e.x - x, e.y - R * 1.05 - y) < R * 0.45) { if (e.y > by) { by = e.y; best = { e, weak: 1 }; } continue; }
      const dx = e.x - x, dy = (e.y - y) / 1.25;
      if (dx * dx + dy * dy < R * R && e.y > by) { by = e.y; best = { e }; }
    }
    return best;
  }
  function assist(g, sh, ax, ay) {
    sh.lk = 0;
    if (!g.o.assist || g.jam) return [ax, ay];
    let bd = ASSIST, bx = ax, by = ay, id = 0;
    for (const p of g.pj) { if (p.dead || p.t < 0) continue; const d = Math.hypot(p.x - ax, p.y - ay) * 0.8; if (d < bd) { bd = d; bx = p.x; by = p.y; id = -1; } }
    const sr = sh.cls === 'sr';
    for (const e of g.en) {
      if (e.dead || e.cl > 0.5 || e.smk) continue;
      const s = sc(e.y);
      if (e.boss) {
        let got = false;
        for (const p of e.parts) { if (p.hp <= 0) continue; const px = e.x + p.ox * s, py = e.y + p.oy * s, d = Math.hypot(px - ax, py - ay); if (d < Math.min(bd, ASSIST * 0.8)) { bd = d; bx = px; by = py; id = e.id; got = true; } }
        if (!got && Math.hypot(e.x - ax, e.y - ay) < e.r * s && bd >= ASSIST) { bd = ASSIST * 0.9; bx = ax; by = ay; id = e.id; }
        continue;
      }
      const head = sr && !e.d.fly && e.d.sh !== 'turret' && e.d.sh !== 'hound';
      const cx = e.x, cy = head ? e.y - e.r * s * 1.05 : e.y, d = Math.hypot(cx - ax, (e.y - ay) * 0.8);
      if (d < bd) { bd = d; bx = cx; by = cy; id = e.id; }
    }
    sh.lk = id;
    return [bx, by];
  }
  function prio(g, e, sh) {
    const a = e.d.a; let p = 1;
    if (e.boss) p = 0.9;
    if (a && a.k === 'boom') p = 3 + (e.y / 100) * 4;
    else if (a && a.k === 'flk') p = 3.5;
    else if (e.d.aura) p = 2.6;
    if (e.st === 'chg') p += 1;
    for (const th of g.th) if (!th.dead && th.k === 'prc' && th.src === e.id) p += 5;
    if (e.hvt) p += 0.8;
    if (e.sh) p *= 0.15;
    if (e.cl > 0.5) p *= 0.3;
    p *= 1 + (1 - e.hp / e.mhp) * 0.5;
    if (sh && sh.cls === 'sg') p *= 0.4 + e.y / 70;
    return p;
  }
  function autoTarget(g, sh, keep) {   // 동료 · 일제 사격 · 봇이 쓰는 표적 고르기 → {id, x, y} 또는 null
    let best = null, bp = 0;
    for (const p of g.pj) if (!p.dead && p.t >= 0 && p.hp > 0) { const v = 4 * (p.T - p.t < 0.25 ? 0.2 : 1); if (v > bp) { bp = v; best = { id: -p.id, x: p.x, y: p.y }; } }
    for (const e of g.en) {
      if (e.dead || e.st === 'flee' || e.y < 9) continue;
      let v = prio(g, e, sh) * (0.85 + 0.3 * hash(e.id, sh.slot + 7));
      if (keep && e.id === keep) v *= 1.6;
      if (v > bp) {
        bp = v; const s = sc(e.y); let x = e.x, y = e.y;
        if (e.boss) { const lp = e.parts.filter((q) => q.hp > 0), w6 = g.T / 6 | 0; const pp = lp.length ? lp[(sh.slot + w6) % lp.length] : null; if (pp && hash(e.id + w6, sh.slot) < 0.7) { x = e.x + pp.ox * s; y = e.y + pp.oy * s; } }
        else if (sh.cls === 'sr' && !e.d.fly && e.d.sh !== 'turret' && e.d.sh !== 'hound') y = e.y - e.r * s * 1.05;
        best = { id: e.id, x, y };
      }
    }
    return best;
  }

  /* ───────── 사수 ───────── */
  function fireOne(g, sh, w, ax, ay, me) {
    const m = g.m, burst = g.bf.burst > 0, free = burst || sh.bT > 0;
    if (!free) sh.ammo -= 1;
    sh.shots++; sh.rec = 1;
    const spread = w.sp * (sh.cls === 'ar' ? 1 - m.arSp : 1) * (me ? 1 : 1.5);
    if (w.mode === 'gren') {
      const a = rnd(g) * 6.283, d = Math.sqrt(rnd(g)) * spread;
      g.pg.push({ x: ax + Math.cos(a) * d, y: ay + Math.sin(a) * d, t: 0, T: 0.32, s: sh.slot, me, R: w.aoe * (1 + m.aoe), dmg: w.dmg * (1 + m.dmg) * (1 + m.aoeD), clu: m.glClu });
      ev(g, { t: 'shot', s: sh.slot, x: ax, y: ay, w: sh.cls, h: 0 }); return;
    }
    const pel = w.pel ? w.pel + m.sgPel : 1;
    let any = false, fx = ax, fy = ay;
    for (let i = 0; i < pel; i++) {
      const a = rnd(g) * 6.283, d = Math.sqrt(rnd(g)) * spread, px = ax + Math.cos(a) * d, py = ay + Math.sin(a) * d * 0.8;
      if (i === 0) { fx = px; fy = py; }
      const h = hitTest(g, px, py);
      if (!h) continue;
      any = true;
      if (h.pj) { h.pj.hp -= w.dmg * (w.pel ? 1 : 1); if (h.pj.hp <= 0) { h.pj.dead = 1; ev(g, { t: 'pjkill', x: h.pj.x, y: h.pj.y }); if (m.icD) explode(g, h.pj.x, h.pj.y, 10, m.icD, sh, 2); } continue; }
      const e = h.e;
      let d0 = w.dmg * (1 + m.dmg) * (sh.cls === 'ar' ? 1 + m.arD : 1);
      if (w.pel) d0 *= lerp(Math.min(1, w.far + m.sgFar), 1, clamp((e.y - 22) / 40, 0, 1));
      if (h.weak && w.wk > 1) d0 *= w.wk + m.wk;
      if (sh.outT < 1.2) d0 *= 1 + m.first;
      if (sh.bK === 'focus' && sh.bT > 0) d0 *= 1.2;
      const crit = m.crit > 0 && rnd(g) < m.crit; if (crit) d0 *= 2;
      if (burst) d0 *= 1 + m.burst; else if (!me) d0 *= ALLY * (1 + m.ally);
      damage(g, e, d0, sh, { weak: h.weak, crit, part: h.part, px, py });
    }
    if (any) sh.hitn++;
    ev(g, { t: 'shot', s: sh.slot, x: fx, y: fy, w: sh.cls, h: any ? 1 : 0 });
  }
  function allyThink(g, sh) {
    const a = sh.ai, slot = sh.slot;
    let hide = false, out = false;
    for (const th of g.th) { if (th.dead || th.slot !== slot || !th.jd) continue; if ((th.k === 'aim' || th.k === 'sup') && th.T - th.t < 0.45) hide = true; }
    for (const p of g.pj) { if (p.dead || p.slot !== slot || !p.jd) continue; const rem = p.T - p.t; if (p.k === 'rkt' && rem < 0.45) hide = true; if (p.k === 'lob' && rem < 0.5) out = true; }
    for (const z of g.zn) if (z.k === 'burn' && z.slot === slot) out = true;
    a.t -= DT;
    if (a.t <= 0) { a.out = !a.out; a.t = a.out ? rr(g, 1.5, 2.7) : rr(g, 0.6, 1.2); }
    let tg = a.tg ? (a.tg > 0 ? byId(g, a.tg) : null) : null;
    if (!tg || tg.dead || (g.T * 60 | 0) % 20 === slot) { const t = autoTarget(g, sh, a.tg); a.tg = t ? t.id : 0; a.tx = t ? t.x : sh.ax; a.ty = t ? t.y : sh.ay; }
    else { const t = autoTarget(g, sh, a.tg); if (t && t.id === a.tg) { a.tx = t.x; a.ty = t.y; } }
    let want = a.out && !!a.tg;
    if (hide) want = false; else if (out) want = true;
    return want;
  }
  function stepShooter(g, sh, I) {
    sh.pp = sh.pose; sh.fl = Math.max(0, sh.fl - DT * 4); sh.rec = Math.max(0, sh.rec - DT * 12);
    if (sh.bT > 0) { sh.bT -= DT; if (sh.bT <= 0) sh.bK = ''; }
    if (sh.down) { sh.pose = Math.max(0, sh.pose - DT * 8); return; }
    const w = W[sh.w], m = g.m, mag = magOf(g, sh), burst = g.bf.burst > 0, free = burst || sh.bT > 0;
    let want, ax, ay, me = false;
    if (I) { me = true; want = !!I.down; const p = assist(g, sh, I.ax, I.ay); ax = p[0]; ay = p[1]; if (burst && !want) { const t = autoTarget(g, sh, 0); if (t) { ax = t.x; ay = t.y; } } }
    else { want = allyThink(g, sh); ax = sh.ai.tx != null ? sh.ai.tx : sh.ax; ay = sh.ai.ty != null ? sh.ai.ty : sh.ay; }
    if (burst) want = true;
    if (sh.ammo < 1 && !free) sh.lockR = true;
    if (sh.lockR && sh.ammo >= mag) sh.lockR = false;
    if (sh.lockR && !free) want = false;
    sh.ax += (ax - sh.ax) * (me ? 1 : 0.25); sh.ay += (ay - sh.ay) * (me ? 1 : 0.25);
    sh.pose = want ? Math.min(1, sh.pose + DT / 0.14) : Math.max(0, sh.pose - DT / (0.10 / (1 + m.quick)));
    if (sh.pose > 0.35) sh.lastOut = g.T;
    if (sh.pose >= 0.9) sh.outT += DT; else if (sh.pose < 0.2) sh.outT = 0;
    if (sh.pose < 0.2) {
      sh.rt += DT;
      if (sh.rt > 0.25 && sh.ammo < mag) { const T = w.rld * (1 - m.rld) * (sh.cls === 'smg' ? 1 - m.smgL : 1); sh.ammo = Math.min(mag, sh.ammo + mag / T * DT); if (sh.ammo >= mag) ev(g, { t: 'rld', s: sh.slot }); }
    } else sh.rt = 0;
    const can = sh.pose >= 0.9 && (sh.ammo >= 1 || free) && (me ? want : !!sh.ai.tg || burst);
    const rofMul = (1 + m.rof) * (sh.cls === 'smg' ? 1 + m.smgR : 1) * (sh.bK === 'focus' && sh.bT > 0 ? 1.6 : 1) * (burst ? 2.2 : 1);
    sh.cd = Math.max(sh.cd - DT, -DT);
    let fired = false;
    if (can) {
      if (w.mode === 'charge') {
        if (sh.cd <= 0) { sh.chg += DT / (w.chg * (1 - m.srC) / (burst ? 2.2 : 1)); if (sh.chg >= 1) { fireOne(g, sh, w, ax, ay, me); sh.chg = 0; sh.cd = 0.25; fired = true; } }
      } else if (w.mode === 'burst') {
        if (sh.bq > 0) { sh.bt -= DT; if (sh.bt <= 0) { fireOne(g, sh, w, ax, ay, me); sh.bq--; sh.bt = 0.07; fired = true; } }
        else if (sh.cd <= 0) { sh.bq = w.bn; sh.bt = 0; sh.cd += 1 / (w.rof * rofMul); }
      } else if (sh.cd <= 0) {
        let rof = w.rof;
        if (w.mode === 'heat') { if (sh.bK === 'barrage' && sh.bT > 0) sh.heat = 1; rof = lerp(w.rof, w.rof2, sh.heat); }
        if (w.mode === 'semi' && sh.cls === 'sr') rof *= 1 / (1 - m.srC);
        fireOne(g, sh, w, ax, ay, me); sh.cd += 1 / (rof * rofMul); fired = true;
      }
      if (w.mode === 'heat') { sh.heat = Math.min(1, sh.heat + DT / (w.heat / (1 + m.mgHeat))); sh.heatK = 0; }
    } else {
      sh.bq = 0;
      if (w.mode === 'charge') sh.chg = Math.max(0, sh.chg - DT * 2.5);
      if (w.mode === 'heat') { sh.heatK += DT; if (sh.heatK > 0.3 + m.mgKeep) sh.heat = Math.max(0, sh.heat - DT / 0.8); }
    }
    return fired;
  }

  /* ───────── 기술 ───────── */
  function useSkill(g, slot) {
    const sh = g.sq[slot];
    if (!sh || sh.down || sh.g < 100 || g.ph !== 'fight' || g.bf.burst > 0) return false;
    const k = SH[sh.id].sk; sh.g = 0;
    ev(g, { t: 'skill', s: slot, id: k.id, n: k.n });
    if (k.id === 'focus') { sh.bK = 'focus'; sh.bT = k.dur; }
    else if (k.id === 'barrage') { sh.bK = 'barrage'; sh.bT = k.dur; g.bf.barrage = k.dur; }
    else if (k.id === 'lance') {
      let x = sh.ax; if (slot !== g.act || !hitNear(g, x)) { let b = null; for (const e of g.en) if (!e.dead && (!b || e.hp > b.hp)) b = e; if (b) x = b.x; }
      ev(g, { t: 'lance', x, s: slot });
      for (const e of g.en.slice()) { if (e.dead) continue; const s = sc(e.y); if (Math.abs(e.x - x) < 7 + e.r * s) { let hitp = false; if (e.boss) for (const p of e.parts) if (p.hp > 0 && Math.abs(e.x + p.ox * s - x) < 7 + p.r * s && !hitp) { hitp = true; damage(g, e, k.v, sh, { pierce: 1, part: p }); } if (!e.dead) damage(g, e, k.v, sh, { pierce: 1, weak: 1 }); } }
    } else if (k.id === 'blast') {
      ev(g, { t: 'blast', s: slot });
      for (const e of g.en.slice()) { if (e.dead) continue; const near = e.y > 44; damage(g, e, near ? k.v : k.v2, sh, { expl: 1 }); if (!e.dead && near && !e.boss) { e.sn = k.stun; cancelThreats(g, e); if (e.st === 'chg') endAttack(g, e, true); } }
      for (const p of g.pj) if (!p.dead && p.t >= 0) { p.dead = 1; ev(g, { t: 'pjkill', x: p.x, y: p.y }); }
    } else if (k.id === 'carpet') {
      const list = g.en.filter((e) => !e.dead).sort((a, b) => b.hp - a.hp).slice(0, k.cnt);
      for (let i = 0; i < k.cnt; i++) { const e = list.length ? list[i % list.length] : null; g.pg.push({ x: e ? e.x + (i >= list.length ? rr(g, -8, 8) : 0) : rr(g, 20, 80), y: e ? e.y + (i >= list.length ? rr(g, -5, 5) : 0) : rr(g, 25, 60), t: -i * 0.14, T: 0.35, s: slot, me: true, R: 13 * (1 + g.m.aoe), dmg: k.v * (1 + g.m.aoeD), clu: 0, sk: 1 }); }
    } else if (k.id === 'smoke') { g.bf.smoke = k.dur; for (const th of g.th) if (!th.dead && th.k !== 'wind') { th.dead = 1; endAttack(g, byId(g, th.src), true); } }
    else if (k.id === 'fortify') { g.bf.fort = k.dur; g.cov.forEach((c) => { c.hp = Math.min(c.mhp, c.hp + c.mhp * k.v); }); }
    else if (k.id === 'medic') { g.sq.forEach((s) => { if (s.down) { s.down = false; s.hp = s.mhp * k.v; s.ammo = magOf(g, s); s.lockR = false; ev(g, { t: 'revive', s: s.slot }); } else s.hp = Math.min(s.mhp, s.hp + s.mhp * k.v); }); }
    else if (k.id === 'mark') g.bf.mark = k.dur;
    return true;
  }
  function hitNear(g, x) { for (const e of g.en) if (!e.dead && Math.abs(e.x - x) < 7 + e.r * sc(e.y)) return true; return false; }
  const burstReady = (g) => { let n = 0; for (const s of g.sq) { if (s.down) continue; if (s.g < 100) return false; n++; } return n > 0 && g.ph === 'fight' && !(g.bf.burst > 0); };
  function useBurst(g) {
    if (!burstReady(g)) return false;
    g.sq.forEach((s) => { s.g = 0; });
    g.bf.burst = 3.5 + g.m.burstT;
    for (const th of g.th) if (!th.dead) { th.dead = 1; endAttack(g, byId(g, th.src), true); }
    for (const p of g.pj) if (!p.dead && p.t >= 0) { p.dead = 1; ev(g, { t: 'pjkill', x: p.x, y: p.y }); }
    ev(g, { t: 'burst' });
    for (const e of g.en.slice()) if (!e.dead) damage(g, e, 80 * (1 + g.m.burst), g.sq[g.act], { expl: 1 });
    return true;
  }

  /* ───────── 적 ───────── */
  function moveTo(e, x, y, v) { const dx = x - e.x, dy = y - e.y, d = Math.hypot(dx, dy), s = v * DT; if (d <= s) { e.x = x; e.y = y; return true; } e.x += dx / d * s; e.y += dy / d * s; return false; }
  function mkThreat(g, e, k, slot, o) {
    const th = { k, src: e.id, slot, t: 0, pt: 0, T: (o.T || 1) * (k === 'wind' ? 1 : 1 + g.m.slow), dmg: (o.dmg || 0) * g.st.dm, cov: o.cov || 0, n: o.n || 1, fi: 0, ft: 0, dur: o.dur || 0, u: 0, tk: 0, stg: 0, acc: 0, jd: rnd(g) < JUDG + g.m.judg, dead: 0, op: o.op == null ? -1 : o.op, then: o.then || null, id: g.nid++ };
    g.th.push(th); return th;
  }
  function launch(g, e, a, slot, k, delay, ox, oy) {
    const lob = k !== 'rkt', s = sc(e.y);
    g.pj.push({ id: g.nid++, k: lob ? 'lob' : 'rkt', sx: e.x + (ox || 0) * s, sy: e.y + (oy == null ? -e.r * s : oy * s), x: e.x, y: e.y, px: e.x, py: e.y, slot, t: -(delay || 0), T: a.fl, hp: lob ? (a.burn ? 22 : 16) : 14, dmg: a.dmg * g.st.dm, cov: a.cov, burn: a.burn || 0, bdps: (a.bdps || 0) * g.st.dm, jd: rnd(g) < (JUDG + g.m.judg) * (lob ? 0.85 : 1), dead: 0 });
    ev(g, { t: 'launch', x: e.x, y: e.y, k: lob ? 'lob' : 'rkt' });
  }
  function startAttack(g, e) {
    const a = e.d.a;
    if (g.bf.smoke > 0 && (a.k === 'aim' || a.k === 'sup' || a.k === 'prc')) { e.cd = 0.5; return; }
    const slot = pickSlot(g);
    e.st = 'chg';
    if (a.k === 'aim') mkThreat(g, e, 'aim', slot, a);
    else if (a.k === 'sup') mkThreat(g, e, 'sup', slot, a);
    else if (a.k === 'prc') { const th = mkThreat(g, e, 'prc', slot, a); th.stg = a.stg * e.mhp; }
    else mkThreat(g, e, 'wind', slot, { T: a.T, then: a.k });
  }
  function stepEnemy(g, e) {
    e.px = e.x; e.py = e.y; e.fl = Math.max(0, e.fl - DT * 6);
    const d = e.d, a = d.a;
    const clT = d.cloak && e.st !== 'chg' && !(e.sn > 0) ? 1 : 0; e.cl += clamp(clT - e.cl, -DT * 3, DT * 2);
    e.sh = !!d.shield && e.st !== 'chg' && !(e.sn > 0);
    if (e.sn > 0) { e.sn -= DT; return; }
    if (d.aura && d.aura.k === 'heal') { e.hl += DT; if (e.hl >= d.aura.ev) { e.hl = 0; let b = null; for (const o of g.en) if (!o.dead && o !== e && !o.boss && o.hp < o.mhp && Math.hypot(o.x - e.x, o.y - e.y) < d.aura.R && (!b || o.hp / o.mhp < b.hp / b.mhp)) b = o; if (b) { b.hp = Math.min(b.mhp, b.hp + d.aura.v * g.st.hm); ev(g, { t: 'heal', x: b.x, y: b.y, fx: e.x, fy: e.y }); } } }
    switch (e.st) {
      case 'in': if (moveTo(e, e.tx, e.ty, 26)) { e.st = 'idle'; e.cd = rr(g, 0.3, 1.3); e.hx = e.x; e.hy = e.y; } break;
      case 'idle':
        if (d.mv === 'hover') { e.x = e.hx + Math.sin(g.T * 0.9 + e.id) * 6; e.y = e.hy + Math.cos(g.T * 0.7 + e.id) * 2; }
        else if (d.mv === 'adv') e.y = Math.min(d.row[1], e.y + 0.9 * DT);
        else if (d.mv === 'strafe') { e.mt -= DT; if (e.mt <= 0) { const p = spot(g, d); e.tx = p[0]; e.ty = p[1]; e.st = 'mv'; e.mt = rr(g, 3, 6); break; } }
        if (a) { e.cd -= DT; if (e.cd <= 0) startAttack(g, e); }
        break;
      case 'mv': if (moveTo(e, e.tx, e.ty, d.mv === 'hop' ? 44 : 16)) e.st = 'idle'; break;
      case 'chg': { let has = false; for (const th of g.th) if (!th.dead && th.src === e.id) { has = true; break; } if (!has) endAttack(g, e, true); break; }
      case 'rush': {
        if (g.sq[e.tg] && g.sq[e.tg].down) e.tg = nearSlot(g, e.tg);
        if (moveTo(e, SLOTX[e.tg] + (hash(e.id, 3) - 0.5) * 8, COVY - 5, d.spd * (0.75 + 0.25 * sc(e.y)))) {
          e.dead = true; ev(g, { t: 'boom', x: e.x, y: e.y, r: 9, p: 0 });
          covDmg(g, e.tg, a.cov); const sh = g.sq[e.tg]; if (sh && !sh.down) hurt(g, sh, a.dmg * g.st.dm * (sh.pose > 0.35 ? 1 : 0.4) * (g.bf.fort > 0 ? 0.5 : 1));
        } break; }
      case 'flank': if (moveTo(e, e.side < 0 ? 6 : 94, 90, d.spd)) { e.st = 'fpos'; e.cd = 0.3; } break;
      case 'fpos': e.cd -= DT; if (e.cd <= 0) { e.tg = nearSlot(g, e.side < 0 ? 0 : 2); e.st = 'chg'; mkThreat(g, e, 'flk', e.tg, a); } break;
      case 'flee': e.y -= 30 * DT; if (e.y < 6) e.dead = true; break;
    }
  }
  function bossPattern(g, e, pt) {
    const live = [0, 1, 2].filter((i) => !g.sq[i].down), s = sc(e.y);
    const pidx = (id) => e.parts.findIndex((p) => p.id === id);
    if (pt.k === 'aim3') { const rev = rnd(g) < 0.5; live.forEach((sl, i) => { mkThreat(g, e, 'aim', rev ? live[live.length - 1 - i] : sl, { T: pt.T + i * 0.45, dmg: pt.dmg, cov: pt.cov, op: pt.need ? pidx(pt.need) : -1 }); }); }
    else if (pt.k === 'aim1') mkThreat(g, e, 'aim', pickSlot(g), { T: pt.T, dmg: pt.dmg, cov: pt.cov, n: pt.n, op: pt.need ? pidx(pt.need) : -1 });
    else if (pt.k === 'aimS') mkThreat(g, e, 'aim', nearSlot(g, pt.slot), { T: pt.T, dmg: pt.dmg, cov: pt.cov, n: 2, op: pidx(pt.need) });
    else if (pt.k === 'sweep') { const rev = rnd(g) < 0.5; [0, 1, 2].forEach((sl, i) => { mkThreat(g, e, 'sup', rev ? 2 - sl : sl, { T: pt.T + i * (pt.dur + 0.25), dmg: pt.dmg, cov: pt.cov, dur: pt.dur, op: pt.need ? pidx(pt.need) : -1 }); }); }
    else if (pt.k === 'lob' || pt.k === 'fire') { const n = pt.n || 1, st0 = Math.floor(rnd(g) * 3); for (let i = 0; i < n; i++) launch(g, e, pt, n >= 3 ? (st0 + i) % 3 : (i === 0 ? pickSlot(g) : (st0 + i) % 3), 'lob', i * 0.5, 0, -e.r * 0.8); }
    else if (pt.k === 'rkt') { const p = pt.need ? e.parts[pidx(pt.need)] : null; for (let i = 0; i < pt.n; i++) launch(g, e, pt, pickSlot(g), 'rkt', i * 0.45, p ? p.ox : 0, p ? p.oy : 0); }
    else if (pt.k === 'prc') { const th = mkThreat(g, e, 'prc', pickSlot(g), { T: pt.T, dmg: pt.dmg, cov: pt.cov, op: pt.need ? pidx(pt.need) : -1 }); th.stg = pt.stg * e.mhp; }
    else if (pt.k === 'flk') { const sd = rnd(g) < 0.5 ? 0 : 2; e.off = sd === 0 ? -1 : 1; const th = mkThreat(g, e, 'flk', nearSlot(g, sd), { T: pt.T, dmg: pt.dmg }); th.stg = 0.035 * e.mhp; }
    else if (pt.k === 'add') { if (alive(g) <= 5) pt.list.forEach((k, i) => { g.st.q.push({ k, t: g.st.t + 0.3 + i * 0.35 }); }); else return false; }
    return true;
  }
  function stepBoss(g, e) {
    e.px = e.x; e.py = e.y; e.fl = Math.max(0, e.fl - DT * 6);
    const d = e.d;
    for (const p of e.parts) p.fl = Math.max(0, p.fl - DT * 6);
    if (e.st === 'in') { if (moveTo(e, 50, d.y, 18)) e.st = 'idle'; return; }
    let own = 0; for (const th of g.th) if (!th.dead && th.src === e.id) own++;
    const tail = e.k === 'heli' && e.parts[2].hp <= 0 ? 0.4 : 1;
    const bx = 50 + Math.sin(g.T * 0.5 * tail + e.ph0) * d.sway * tail + e.off * 30 * (own ? 1 : 0);
    e.x += clamp(bx - e.x, -26 * DT, 26 * DT);
    if (!own) e.off = 0;
    if (e.inv > 0) e.inv -= DT;
    const ph = e.hp / e.mhp <= 0.3 ? 2 : e.hp / e.mhp <= 0.6 ? 1 : 0;
    if (ph > e.phs) { e.phs = ph; e.inv = 1.0; cancelThreats(g, e); e.cd = 1.4; ev(g, { t: 'phase', n: ph + 1 }); }
    const gen = d.cloak ? e.parts[0].hp > 0 : false;
    const clT = gen && !own && !(e.stg > 0) ? 1 : 0; e.cl += clamp(clT - e.cl, -DT * 3, DT * 1.2);
    if (e.stg > 0) { e.stg -= DT; return; }
    if (own) return;
    e.cd -= DT;
    if (e.cd > 0) return;
    const av = d.pats.map((p, i) => i).filter((i) => { const p = d.pats[i]; return i !== e.last && (p.ph || 0) <= e.phs && (!p.need || e.parts.find((q) => q.id === p.need).hp > 0) && !(g.bf.smoke > 0 && (p.k === 'aim1' || p.k === 'aim3' || p.k === 'aimS' || p.k === 'sweep')); });
    if (!av.length) { e.cd = 0.6; e.last = -1; return; }
    let tot = 0; av.forEach((i) => { tot += d.pats[i].w; });
    let x = rnd(g) * tot, pk = av[0]; for (const i of av) { x -= d.pats[i].w; if (x <= 0) { pk = i; break; } }
    e.last = pk;
    e.cd = bossPattern(g, e, d.pats[pk]) ? d.gap[e.phs] * rr(g, 0.85, 1.2) : 0.3;
  }
  function stepThreats(g) {
    for (const th of g.th) {
      if (th.dead) continue;
      const src = byId(g, th.src);
      if (!src || src.dead) { th.dead = 1; continue; }
      if (src.sn > 0 || src.stg > 0) { th.dead = 1; if (src.st === 'chg') endAttack(g, src, true); continue; }
      th.pt = th.t;
      th.t += DT * (src.hs || 1) * (g.bf.barrage > 0 && th.k !== 'wind' ? 0.45 : 1);
      if (th.t < th.T) continue;
      let done = false;
      if (th.k === 'aim') { th.ft -= DT; if (th.ft <= 0) { directHit(g, th.slot, th.dmg, th.cov); ev(g, { t: 'efire', id: src.id, s: th.slot, op: th.op }); th.fi++; th.ft = 0.13; } done = th.fi >= th.n; }
      else if (th.k === 'sup') { th.tk -= DT; if (th.tk <= 0) { directHit(g, th.slot, th.dmg, th.cov); ev(g, { t: 'efire', id: src.id, s: th.slot, op: th.op }); th.tk = 0.2; } th.u += DT; done = th.u >= th.dur; }
      else if (th.k === 'prc') { anyHit(g, th.slot, th.dmg, th.cov); ev(g, { t: 'efire', id: src.id, s: th.slot, op: th.op, prc: 1 }); done = true; }
      else if (th.k === 'flk') { anyHit(g, th.slot, th.dmg, 0); ev(g, { t: 'efire', id: src.id, s: th.slot, op: -1, flk: 1 }); done = true; }
      else if (th.k === 'wind') {
        const a = src.d.a;
        if (th.then === 'smk') { g.zn.push({ k: 'smk', x: src.x, y: src.y, R: a.R, t: 0, T: a.dur }); ev(g, { t: 'smoke', x: src.x, y: src.y }); }
        else launch(g, src, a, th.slot, th.then, 0);
        done = true;
      }
      if (done) { th.dead = 1; endAttack(g, src, false); }
    }
    if (g.ph === 'lost') return;
    for (const p of g.pj) {
      if (p.dead) continue;
      p.px = p.x; p.py = p.y; p.t += DT;
      if (p.t < 0) { p.x = p.px = p.sx; p.y = p.py = p.sy; continue; }
      const f = Math.min(1, p.t / p.T), tx = SLOTX[p.slot], ty = p.k === 'lob' ? COVY + 8 : COVY - 3;
      p.x = lerp(p.sx, tx, f); p.y = lerp(p.sy, ty, f) - (p.k === 'lob' ? 34 * 4 * f * (1 - f) * 0.5 : 0);
      if (p.t - DT < 0) { p.px = p.x; p.py = p.y; }
      if (f >= 1) {
        p.dead = 1;
        if (p.k === 'lob') { ev(g, { t: 'boom', x: tx, y: ty, r: 9, p: 0 }); behindHit(g, p.slot, p.dmg, p.cov); if (p.burn) g.zn.push({ k: 'burn', slot: p.slot, t: 0, T: p.burn, dps: p.bdps, tk: 0.5 }); }
        else { ev(g, { t: 'boom', x: tx, y: ty, r: 7, p: 0 }); directHit(g, p.slot, p.dmg, p.cov); }
      }
    }
    for (const z of g.zn) {
      z.t += DT;
      if (z.k === 'burn') { z.tk -= DT; if (z.tk <= 0) { z.tk = 0.5; const sh = g.sq[z.slot]; if (sh && !sh.down && sh.pose < 0.65) hurt(g, sh, z.dps * 0.5 * (1 - g.m.low)); } }
    }
  }

  /* ───────── 한 걸음 ───────── */
  function rollUps(g) {
    const cls = {}; g.sq.forEach((s) => { cls[s.cls] = 1; });
    const el = D.UPG.filter((u) => (g.up[u.id] || 0) < D.UPG_MAX && (!u.cls || cls[u.cls]));
    const out = [];
    while (out.length < 3 && el.length) { const i = Math.floor(rnd(g) * el.length); out.push(el[i].id); el.splice(i, 1); }
    g.opts = out;
  }
  function applyUp(g, id) {
    const u = D.UPG.find((x) => x.id === id); if (!u) return;
    g.up[id] = (g.up[id] || 0) + 1; g.ups.push(id); calcMods(g);
    g.sq.forEach((s) => { const nm = Math.round(s.bhp * (1 + g.m.hp)); if (nm > s.mhp) { if (!s.down) s.hp += nm - s.mhp; s.mhp = nm; } s.ammo = magOf(g, s); });
    g.cov.forEach((c) => { const nm = Math.round(COVHP * (1 + g.m.cov)); if (nm > c.mhp) { c.hp += nm - c.mhp; c.mhp = nm; } });
  }
  function stageClear(g) {
    g.ph = 'clear'; g.pt = 1.5; g.done = g.si + 1; g.th = []; g.pj = []; g.zn = []; g.pg = [];
    for (const e of g.en) if (!e.dead) { if (e.boss) e.dead = true; else e.st = 'flee'; }
    for (const k in g.bf) delete g.bf[k];
    ev(g, { t: 'clear', i: g.si });
  }
  function step(g, I) {
    g.ev.length = 0;
    I = I || {};
    if (g.ph === 'pick') { if (I.pick) setSquad(g, I.pick); return; }
    if (g.ph === 'up') {
      if (I.reroll && g.rr > 0) { g.rr--; rollUps(g); ev(g, { t: 'reroll' }); }
      else if (I.up != null && g.opts && g.opts[I.up]) { applyUp(g, g.opts[I.up]); g.opts = null; startStage(g, g.si + 1); g.ph = 'fight'; }
      return;
    }
    if (g.ph === 'won' || g.ph === 'lost') return;
    g.T += DT;
    const m = g.m;
    if (g.ph === 'clear') {
      for (const sh of g.sq) { sh.pp = sh.pose; sh.pose = Math.max(0, sh.pose - DT * 6); sh.fl = Math.max(0, sh.fl - DT * 4); sh.rec = 0; }
      for (const e of g.en) if (!e.dead) stepEnemy(g, e);
      g.en = g.en.filter((e) => !e.dead);
      g.pt -= DT;
      if (g.pt <= 0) {
        if (g.si >= g.N - 1) { g.ph = 'won'; g.won = true; return; }
        g.sq.forEach((s) => { if (s.down) { s.down = false; s.hp = s.mhp * Math.min(1, 0.3 + m.rev); ev(g, { t: 'revive', s: s.slot }); } else s.hp = Math.min(s.mhp, s.hp + s.mhp * (0.1 + m.med)); s.ammo = magOf(g, s); s.lockR = false; s.heat = 0; s.chg = 0; });
        g.cov.forEach((c) => { c.hp = Math.min(c.mhp, Math.max(c.hp + c.mhp * (0.3 + m.rep), c.mhp * 0.4)); });
        if (g.sq[g.act].down) g.act = nearSlot(g, g.act);
        g.en = []; rollUps(g); g.ph = 'up';
      }
      return;
    }
    // fight
    const st = g.st; st.t += DT; st.wt += DT;
    if (I.sw != null && I.sw >= 0 && I.sw < 3 && I.sw !== g.act && g.sq[I.sw] && !g.sq[I.sw].down) { g.act = I.sw; ev(g, { t: 'sw', s: I.sw }); }
    if (I.burst) useBurst(g);
    if (I.sk != null && I.sk >= 0) useSkill(g, I.sk);
    for (const k in g.bf) { g.bf[k] -= DT; if (g.bf[k] <= 0) delete g.bf[k]; }
    for (const c of g.cov) c.fl = Math.max(0, c.fl - DT * 5);
    // 지원 효과(방호 · 지휘 · 교란 · 연막)
    g.jam = false;
    for (const e of g.en) { e.pr = 1; e.hs = 1; e.smk = false; }
    for (const a of g.en) {
      if (a.dead || !a.d.aura || a.sn > 0) continue;
      const au = a.d.aura;
      if (au.k === 'jam') { g.jam = true; continue; }
      if (au.k === 'shield' || au.k === 'haste') for (const e of g.en) if (e !== a && !e.dead && Math.hypot(e.x - a.x, e.y - a.y) < au.R) { if (au.k === 'shield') e.pr = Math.min(e.pr, au.v); else e.hs = Math.max(e.hs, au.v); }
    }
    for (const z of g.zn) if (z.k === 'smk') for (const e of g.en) if (!e.dead && !e.boss && Math.hypot(e.x - z.x, e.y - z.y) < z.R) e.smk = true;
    for (const sh of g.sq) stepShooter(g, sh, sh.slot === g.act ? I : null);
    for (const p of g.pg) {
      p.t += DT;
      if (p.t >= p.T && !p.dead) { p.dead = 1; if (explode(g, p.x, p.y, p.R, p.dmg * (p.me || g.bf.burst > 0 ? 1 : ALLY * (1 + m.ally)), g.sq[p.s], 1) && !p.sk) g.sq[p.s].hitn++; for (let i = 0; i < p.clu; i++) { const a = rnd(g) * 6.283; explode(g, p.x + Math.cos(a) * 8, p.y + Math.sin(a) * 6, p.R * 0.6, p.dmg * 0.4 * (p.me ? 1 : ALLY), g.sq[p.s], 2); } }
    }
    for (const e of g.en) if (!e.dead) { if (e.boss) stepBoss(g, e); else stepEnemy(g, e); }
    stepThreats(g);
    if (g.ph !== 'fight') return;
    g.en = g.en.filter((e) => !e.dead); g.th = g.th.filter((t) => !t.dead); g.pj = g.pj.filter((p) => !p.dead); g.pg = g.pg.filter((p) => !p.dead); g.zn = g.zn.filter((z) => z.t < z.T);
    // 편성 · 증원
    for (let i = st.q.length - 1; i >= 0; i--) if (st.t >= st.q[i].t) { spawn(g, st.q[i].k); st.q.splice(i, 1); }
    const n = alive(g);
    if (st.type === 'hold') {
      st.sc -= DT;
      if (st.t > 1.2 && st.t < st.dur && n < st.cap && st.sc <= 0) { spawn(g, rnd(g) < 0.35 ? st.set[0] : st.set[Math.floor(rnd(g) * st.set.length)]); st.sc = 1.7 - 0.5 * st.p; }
      if (st.t >= st.dur || st.end) stageClear(g);
    } else if (st.type !== 'boss') {
      if (!st.q.length && st.wi < st.waves.length && st.t >= 1.2 && (n <= (st.wi === 0 ? 0 : st.p > 0.5 ? 3 : 2) || st.wt > 14)) { st.waves[st.wi].forEach((k, j) => { st.q.push({ k, t: st.t + j * 0.4 }); }); st.wi++; st.wt = 0; }
      if (st.end || (st.wi >= st.waves.length && !st.q.length && n === 0)) stageClear(g);
    } else if (st.end) stageClear(g);
  }
  function summary(g) {
    let mvp = null; g.sq.forEach((s) => { if (!mvp || s.dmg > mvp.dmg) mvp = s; });
    const cnt = {}; g.ups.forEach((id) => { cnt[id] = (cnt[id] || 0) + 1; });
    return { won: g.ph === 'won', st: g.done, n: g.N, t: Math.round(g.T), kills: g.kills, dodge: g.dodge,
      sq: g.sq.map((s) => ({ n: s.n, w: D.WCLS[s.cls].n, dmg: Math.round(s.dmg), acc: s.shots ? Math.round(100 * s.hitn / s.shots) : 0, hits: s.hits })),
      ups: Object.keys(cnt).map((id) => D.UPG.find((u) => u.id === id).n + (cnt[id] > 1 ? ' ' + cnt[id] : '')),
      nup: g.ups.length, boss: BS[g.bossId].n, mvp: mvp ? mvp.n : '' };
  }

  /* ───────── 봇(AI 자리 · 점검용) — 상황 점수 + 판 시드 버릇. lv 1/2/3: 반응 속도 · 조준 흔들림 · 숨는 판단 ───────── */
  const UPW = { dmg: 1.2, rof: 1.1, mag: 0.7, rld: 0.8, wk: 0.6, crit: 0.9, first: 0.7, exe: 0.6, aoe: 0.6, boss: 0.7, stg: 0.5, kill: 0.5, hp: 1.0, cov: 0.8, rep: 0.7, med: 1.0, low: 0.6, quick: 0.5, armor: 0.8, rev: 0.4,
    sk: 0.9, ally: 1.0, judg: 0.9, burst: 0.6, slow: 0.9, dodge: 0.5, icpt: 0.4, c_ar: 0.8, c_sr: 0.8, c_sg: 0.8, c_mg: 0.7, c_gl: 0.8, c_smg: 0.8 };
  function bot(g, lv, M) {
    lv = lv || 2;
    if (!M.h) { const s = g.seed; M.h = { early: hash(s, 11), greed: hash(s, 12), hold: hash(s, 13) < 0.5, tough: hash(s, 14), ph: hash(s, 15) * 6.28 }; M.ax = 50; M.ay = 45; M.q = []; M.tg = 0; M.sw = 0; M.ut = 0; M.pt = 0; M.miss = {}; }
    const I = { down: false, ax: M.ax, ay: M.ay, sw: -1, sk: -1, burst: false };
    if (g.ph === 'pick') { M.pt += DT; if (M.pt > 0.3) I.pick = M.squad || []; return I; }
    if (g.ph === 'up') {
      M.ut += DT;
      if (M.ut > 0.5 && g.opts) { let b = 0, bv = -1; g.opts.forEach((id, i) => { let v = (UPW[id] || 0.5) * (0.6 + 0.8 * hash(g.seed + g.si * 31, id.length * 7 + id.charCodeAt(0) + i)); if (lv === 1) v = hash(g.seed + g.si, i + 40); if (v > bv) { bv = v; b = i; } }); I.up = b; M.ut = 0; }
      return I;
    }
    if (g.ph !== 'fight') return I;
    const slot = g.act, sh = g.sq[slot], h = M.h;
    let dHide = 9, dOut = 9, vHide = 0, vOut = 0;
    const missP = lv === 1 ? 0.34 : lv === 2 ? 0.12 : 0.05;
    for (const th of g.th) {
      if (th.dead || th.slot !== slot) continue;
      if (th.k !== 'aim' && th.k !== 'sup') continue;
      if (hash(th.id, g.seed & 1023) < missP) continue;
      const rem = Math.max(0, th.T - th.t); if (rem < dHide) dHide = rem; if (rem < 0.6) vHide += th.dmg * (th.k === 'sup' ? 4 : th.n);
    }
    for (const p of g.pj) { if (p.dead || p.slot !== slot || p.t < 0) continue; const rem = p.T - p.t; if (p.k === 'rkt') { if (rem < dHide) dHide = rem; if (rem < 0.6) vHide += p.dmg; } else if (hash(p.id, g.seed & 1023) >= missP) { if (rem < dOut) dOut = rem; if (rem < 0.6) vOut += p.dmg; } }
    for (const z of g.zn) if (z.k === 'burn' && z.slot === slot) { dOut = 0; vOut += z.dps; }
    const lead = (lv === 1 ? 0.2 : lv === 2 ? 0.3 : 0.27) + h.early * 0.06 - (lv === 3 ? h.greed * 0.05 : 0);
    let hide = dHide < lead, out = dOut < 0.42;
    if (hide && out) { if (vHide >= vOut) out = false; else hide = false; }
    // 표적
    let t = autoTarget(g, sh, M.tg);
    M.tg = t ? t.id : 0;
    if (lv >= 2 && sh.ammo < magOf(g, sh) * 0.12 && dHide < 1.0 && !out) hide = true;
    let want = !hide && (!!t || out);
    if (!t && !out && sh.ammo < magOf(g, sh)) want = false;
    // 반응 지연
    M.q.push(want); const dl = lv === 1 ? 13 : lv === 2 ? 6 : 2; if (M.q.length > dl) want = M.q.shift(); else want = M.q[0];
    I.down = want;
    if (t) {
      const sp = (lv === 1 ? 60 : lv === 2 ? 100 : 170) * DT, dx = t.x - M.ax, dy = t.y - M.ay, d = Math.hypot(dx, dy);
      if (d <= sp) { M.ax = t.x; M.ay = t.y; } else { M.ax += dx / d * sp; M.ay += dy / d * sp; }
    }
    const amp = lv === 1 ? 4.5 : lv === 2 ? 2.2 : 0.6;
    I.ax = M.ax + Math.sin(g.T * 2.3 + h.ph) * amp; I.ay = M.ay + Math.cos(g.T * 1.7 + h.ph) * amp * 0.7;
    // 기술 · 일제 사격 · 사수 바꾸기
    const n = alive(g), boss = g.en.some((e) => e.boss && !e.dead);
    if (burstReady(g)) { if (boss || n >= 3) I.burst = true; }
    else {
      const liveS = g.sq.filter((s) => !s.down), nearAll = liveS.every((s) => s.g >= 62);
      const holdB = lv >= 2 && h.hold && nearAll && liveS.length > 1;
      for (const s of g.sq) {
        if (s.down || s.g < 100 || I.sk >= 0) continue;
        const k = SH[s.id].sk.id;
        let ok = (n >= 2 || boss) && !holdB;
        if (k === 'medic') ok = g.sq.some((x) => x.down || x.hp / x.mhp < 0.55);
        else if (k === 'fortify') ok = g.cov.some((c) => c.hp / c.mhp < 0.5) || (boss && !holdB);
        else if (k === 'smoke') ok = g.th.filter((x) => !x.dead && (x.k === 'aim' || x.k === 'sup')).length >= 2 && !holdB;
        else if (k === 'blast') ok = g.en.filter((e) => !e.dead && e.y > 44).length >= 2 || (boss && !holdB);
        if (lv === 1 && hash(g.T * 2 | 0, s.slot) < 0.7) ok = false;
        if (ok) I.sk = s.slot;
      }
    }
    M.sw -= DT;
    if (lv >= 2 && M.sw <= 0 && sh.hp / sh.mhp < 0.3 + h.tough * 0.1) { let b = -1, bv = 0.55; g.sq.forEach((s, i) => { if (!s.down && i !== slot && s.hp / s.mhp > bv) { bv = s.hp / s.mhp; b = i; } }); if (b >= 0) { I.sw = b; M.sw = 4; M.q.length = 0; } }
    return I;
  }

  CS.SIM = { DT, SLOTX, COVY, MUZY, sc, create, step, bot, summary, burstReady, magOf, autoTarget, hash, SH };
})();
