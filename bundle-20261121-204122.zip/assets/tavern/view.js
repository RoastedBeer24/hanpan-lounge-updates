/* 여관 주인 — 3D 화면(three.js r170 · assets/hyperrace/lib/three.min.js 공용) · 관리 창 · 조작 · HUD · 온라인.
   - 여관: 코드로 만든 낮은 폴리곤 목조 · 석조 홀(바닥 널 · 돌벽 · 회벽 · 기둥 결은 캔버스로 그림). 정적인 것은 재질별로 합쳐 그리기 호출을 적게.
   - 사람: 부위(다리 · 몸통 · 팔 · 머리 · 모자 여섯 · 망토 · 앞치마 · 등짐)마다 InstancedMesh 하나 — 손님 50명이어도 그리기 20번 안팎.
   - 불빛: 난로 · 계산대 등 · 식탁 촛불(그래픽 단계별 개수 고정 → 셰이더 다시 굽지 않음). 처음 불러올 때 모든 재질 조합을 미리 굽기.
   - 온라인: 영업 세계는 호스트(sim.js)가 돌리고 12Hz로 묶어 보냄. 손님 기기는 자기 캐릭터만 먼저 움직이고(예측) 「쓰기」는 요청으로 보냄. */
(function () {
  'use strict';
  const L = window.Lounge, THREE = window.THREE;
  const V = {};
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const SERIF = '"Nanum Myeongjo","Noto Serif KR","Batang","AppleMyungjo",serif';

  /* ======================= 결 그리기(캔버스) ======================= */
  function rnd(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function canvasTex(w, h, draw, rep) {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h; draw(cv.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(cv); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
    if (rep) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
    return t;
  }
  function grain(g, x, y, w, h, R, col, n) {
    g.strokeStyle = col; g.lineWidth = 1;
    for (let i = 0; i < n; i++) {
      const yy = y + R() * h, amp = 1 + R() * 3, ph = R() * 6; g.globalAlpha = 0.18 + R() * 0.25; g.beginPath();
      for (let xx = x; xx <= x + w; xx += 6) { const v = yy + Math.sin(xx * 0.03 + ph) * amp; if (xx === x) g.moveTo(xx, v); else g.lineTo(xx, v); }
      g.stroke();
    }
    g.globalAlpha = 1;
  }
  const texPlanks = () => canvasTex(512, 512, (g, w, h) => {
    const R = rnd(11), bh = h / 6;
    for (let i = 0; i < 6; i++) {
      let x = -R() * 200;
      while (x < w) {
        const len = 180 + R() * 220, t = 0.82 + R() * 0.3;
        g.fillStyle = 'rgb(' + Math.round(140 * t) + ',' + Math.round(98 * t) + ',' + Math.round(62 * t) + ')';
        g.fillRect(x, i * bh, len, bh);
        grain(g, x, i * bh + 2, len, bh - 4, R, '#3e2614', 9);
        g.fillStyle = 'rgba(20,10,4,.55)'; g.fillRect(x + len - 2, i * bh, 3, bh);
        g.fillStyle = 'rgba(30,20,10,.7)'; g.fillRect(x + 8, i * bh + bh * 0.3, 3, 3); g.fillRect(x + 8, i * bh + bh * 0.66, 3, 3);
        x += len;
      }
      g.fillStyle = 'rgba(15,8,3,.7)'; g.fillRect(0, i * bh, w, 3);
    }
  }, true);
  const texStone = () => canvasTex(512, 512, (g, w, h) => {
    const R = rnd(23); g.fillStyle = '#3d3630'; g.fillRect(0, 0, w, h);
    let y = 0;
    while (y < h) {
      const rh = 46 + R() * 30; let x = -R() * 60;
      while (x < w) {
        const rw = 60 + R() * 70, t = 0.75 + R() * 0.35;
        g.fillStyle = 'rgb(' + Math.round(128 * t) + ',' + Math.round(118 * t) + ',' + Math.round(104 * t) + ')';
        g.beginPath(); const r = 9; g.moveTo(x + r + 3, y + 3); g.lineTo(x + rw - r - 3, y + 3); g.quadraticCurveTo(x + rw - 3, y + 3, x + rw - 3, y + r + 3); g.lineTo(x + rw - 3, y + rh - r - 3); g.quadraticCurveTo(x + rw - 3, y + rh - 3, x + rw - r - 3, y + rh - 3); g.lineTo(x + r + 3, y + rh - 3); g.quadraticCurveTo(x + 3, y + rh - 3, x + 3, y + rh - r - 3); g.lineTo(x + 3, y + r + 3); g.quadraticCurveTo(x + 3, y + 3, x + r + 3, y + 3); g.fill();
        for (let k = 0; k < 14; k++) { g.fillStyle = 'rgba(0,0,0,' + (R() * 0.12) + ')'; g.fillRect(x + R() * rw, y + R() * rh, 3 + R() * 6, 2 + R() * 4); }
        g.fillStyle = 'rgba(255,240,220,.06)'; g.fillRect(x + 5, y + 4, rw - 10, 4);
        x += rw;
      }
      y += rh;
    }
  }, true);
  const texPlaster = () => canvasTex(256, 256, (g, w, h) => {
    const R = rnd(31); g.fillStyle = '#cdbd9c'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 1400; i++) { g.fillStyle = 'rgba(' + (R() < 0.5 ? '90,70,40' : '255,250,235') + ',' + (R() * 0.07) + ')'; const s = 2 + R() * 9; g.fillRect(R() * w, R() * h, s, s); }
  }, true);
  const texWood = () => canvasTex(256, 256, (g, w, h) => { const R = rnd(41); g.fillStyle = '#b48a62'; g.fillRect(0, 0, w, h); grain(g, 0, 0, w, h, R, '#5a3a20', 26); }, true);
  const texRug = () => canvasTex(256, 160, (g, w, h) => {
    g.fillStyle = '#6e2a22'; g.fillRect(0, 0, w, h); g.strokeStyle = '#c9a45a'; g.lineWidth = 6; g.strokeRect(12, 12, w - 24, h - 24);
    g.fillStyle = '#2f3d52'; g.fillRect(28, 28, w - 56, h - 56); g.strokeStyle = '#d9c08a'; g.lineWidth = 3;
    for (let i = 0; i < 4; i++) { const cx = 60 + i * 46; g.beginPath(); g.moveTo(cx, 50); g.lineTo(cx + 18, 80); g.lineTo(cx, 110); g.lineTo(cx - 18, 80); g.closePath(); g.stroke(); }
  });
  const texTapestry = () => canvasTex(256, 192, (g, w, h) => {
    g.fillStyle = '#3d4a2e'; g.fillRect(0, 0, w, h); g.strokeStyle = '#b58a3c'; g.lineWidth = 8; g.strokeRect(6, 6, w - 12, h - 12);
    g.fillStyle = '#5c3a22'; for (let i = 0; i < 5; i++) { const x = 30 + i * 48; g.fillRect(x, 70, 10, 90); g.beginPath(); g.arc(x + 5, 60, 22, 0, TAU); g.fillStyle = '#2f4a26'; g.fill(); g.fillStyle = '#5c3a22'; }
    g.fillStyle = '#d8c8a0'; g.beginPath(); g.ellipse(150, 140, 28, 12, 0, 0, TAU); g.fill(); g.fillRect(170, 128, 16, 6); g.fillRect(128, 148, 4, 20); g.fillRect(166, 148, 4, 20);
  });
  const texMap = () => canvasTex(256, 192, (g, w, h) => {
    g.fillStyle = '#d8c69a'; g.fillRect(0, 0, w, h); g.strokeStyle = '#6b4a2c'; g.lineWidth = 3;
    g.beginPath(); g.moveTo(20, 150); g.bezierCurveTo(80, 120, 120, 170, 180, 100); g.bezierCurveTo(210, 70, 230, 60, 240, 30); g.stroke();
    g.setLineDash([6, 6]); g.beginPath(); g.moveTo(30, 40); g.lineTo(120, 90); g.lineTo(220, 140); g.stroke(); g.setLineDash([]);
    g.fillStyle = '#7a2a22'; for (const [x, y] of [[120, 90], [60, 58], [200, 128]]) { g.beginPath(); g.arc(x, y, 6, 0, TAU); g.fill(); }
    g.strokeStyle = '#4a3020'; g.lineWidth = 10; g.strokeRect(5, 5, w - 10, h - 10);
  });
  const texBanner = () => canvasTex(128, 256, (g, w, h) => {
    g.fillStyle = '#6b1f22'; g.fillRect(0, 0, w, h); g.fillStyle = '#c9a45a'; g.fillRect(0, 0, w, 14);
    g.beginPath(); g.moveTo(64, 70); g.lineTo(100, 90); g.lineTo(96, 150); g.lineTo(64, 180); g.lineTo(32, 150); g.lineTo(28, 90); g.closePath(); g.fill();
    g.fillStyle = '#2f3d52'; g.beginPath(); g.moveTo(64, 86); g.lineTo(88, 100); g.lineTo(84, 144); g.lineTo(64, 164); g.lineTo(44, 144); g.lineTo(40, 100); g.closePath(); g.fill();
    g.clearRect(0, h - 30, 40, 30); g.clearRect(88, h - 30, 40, 30);
  });
  const texSoft = () => canvasTex(64, 64, (g, w, h) => { const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, w, h); });

  /* ======================= 모양 ======================= */
  const M4 = (x, y, z, rx, ry, rz, sx, sy, sz) => new THREE.Matrix4().compose(new THREE.Vector3(x || 0, y || 0, z || 0), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx || 0, ry || 0, rz || 0, 'YXZ')), new THREE.Vector3(sx == null ? 1 : sx, sy == null ? (sx == null ? 1 : sx) : sy, sz == null ? (sx == null ? 1 : sx) : sz));
  function prep(g, m) { const q = g.index ? g.toNonIndexed() : g.clone(); if (m) q.applyMatrix4(m); for (const k of Object.keys(q.attributes)) if (k !== 'position' && k !== 'normal' && k !== 'uv') q.deleteAttribute(k); if (!q.attributes.uv) q.setAttribute('uv', new THREE.Float32BufferAttribute(new Float32Array(q.attributes.position.count * 2), 2)); return q; }
  const merge = (list) => THREE.BufferGeometryUtils.mergeGeometries(list.map(([g, m]) => prep(g, m)), false);
  /* 상자 UV를 실제 크기(m)에 맞춤 → 결 크기가 늘 같음 */
  function boxW(w, h, d, s) {
    const g = new THREE.BoxGeometry(w, h, d), uv = g.attributes.uv, n = g.attributes.normal; s = s || 1;
    for (let i = 0; i < uv.count; i++) {
      const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i));
      const sw = ax > 0.5 ? d : w, sh = ay > 0.5 ? d : h;
      uv.setXY(i, uv.getX(i) * sw / s, uv.getY(i) * sh / s);
    }
    return g;
  }
  function barrelGeo(r, len) {
    const pts = []; for (let i = 0; i <= 8; i++) { const t = i / 8, y = (t - 0.5) * len, rr = r * (0.86 + 0.14 * Math.sin(t * Math.PI)); pts.push(new THREE.Vector2(rr, y)); }
    const side = new THREE.LatheGeometry(pts, 14);
    const cap1 = new THREE.CircleGeometry(r * 0.86, 14); const cap2 = cap1.clone();
    return merge([[side, null], [cap1, M4(0, len / 2, 0, -Math.PI / 2)], [cap2, M4(0, -len / 2, 0, Math.PI / 2)]]);
  }

  V.mount = function (root, api, T, hooks) {
    const h = L.h, S = T.sim;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const tierId = (L.debug && L.debug.noTut && !T.store.get('gfx', '')) ? 'low' : T.gfxTier();
    const TIER = T.TIERS.find((t) => t.id === tierId) || T.TIERS[0];
    const low = TIER.id === 'low', high = TIER.id === 'high';
    const touch = T.touchOnly();
    const wrap = h('div', { class: 'tv-wrap', style: { position: 'absolute', inset: '0', overflow: 'hidden', background: '#120c08', userSelect: 'none', touchAction: 'none' } });
    root.append(wrap);
    wrap.append(h('style', { text: `
      .tv-wrap canvas.tv3d{position:absolute;inset:0;width:100%;height:100%;display:block}
      .tv-layer{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body);color:#efe2c4}
      .tv-plaque{position:absolute;left:10px;top:10px;background:rgba(22,15,9,.78);border:1px solid rgba(201,150,63,.32);border-radius:8px;padding:5px 11px 6px;line-height:1.2;min-width:116px}
      .tv-plaque b{display:block;font-family:${SERIF};font-weight:700;font-size:15px;letter-spacing:.04em}
      .tv-plaque span{font-family:var(--f-mono);font-size:12.5px;color:#e2d3b2}
      .tv-plaque i{display:block;height:3px;border-radius:2px;background:rgba(255,240,210,.14);margin-top:4px;overflow:hidden}.tv-plaque i s{display:block;height:100%;background:#c9963f;width:0}
      .tv-purse{position:absolute;left:50%;top:10px;transform:translateX(-50%);display:flex;gap:6px;align-items:stretch}
      .tv-pill{background:rgba(22,15,9,.78);border:1px solid rgba(201,150,63,.28);border-radius:8px;padding:4px 10px;font-size:12.5px;white-space:nowrap;display:flex;align-items:center;gap:5px}
      .tv-pic{pointer-events:none;-webkit-user-drag:none;user-select:none}
      .tv-pill b{font-family:var(--f-mono);font-size:15px;color:#f3d79a}
      .tv-pill em{font-style:normal;font-family:var(--f-mono);font-size:12px;color:#9fc27a}
      .tv-stock{position:absolute;right:8px;top:58px;background:rgba(22,15,9,.66);border:1px solid rgba(201,150,63,.2);border-radius:8px;padding:4px 7px;font-size:12.5px;line-height:1.38;min-width:112px;max-width:210px;background:rgba(22,15,9,.8)}
      .tv-stock div{display:flex;align-items:center;gap:5px;white-space:nowrap;min-height:24px}.tv-stock div svg{flex:none}.tv-stock div b{margin-left:auto;font-family:var(--f-mono);font-weight:600}
      .tv-stock div u{margin-left:auto;text-decoration:none;font-size:12px;font-weight:700;line-height:1.4;padding:0 5px;border-radius:8px;background:rgba(247,239,220,.94);color:#2a1c10}.tv-stock div u+b{margin-left:3px}.tv-stock div u i{font-style:normal;font-weight:600}
      .tv-stock .z{opacity:.6;text-decoration:line-through;text-decoration-color:rgba(239,226,196,.45)}.tv-stock hr{border:0;border-top:1px solid rgba(201,150,63,.2);margin:3px 0}
      .tv-carry{position:absolute;left:10px;bottom:12px;display:flex;gap:6px;align-items:flex-end}
      .tv-slot{width:48px;height:48px;border-radius:9px;background:rgba(22,15,9,.7);border:1px solid rgba(201,150,63,.3);display:flex;align-items:center;justify-content:center;position:relative}
      .tv-slot.e{border-style:dashed;background:rgba(22,15,9,.5)}
      .tv-cl{align-self:center;font-size:12px;font-weight:600;color:#e2d3b2;background:rgba(22,15,9,.78);padding:3px 7px;border-radius:6px;white-space:nowrap}
      .tv-slot small{position:absolute;bottom:0;right:3px;font-size:12px;font-weight:700;font-family:var(--f-mono);color:#f6e8c8;text-shadow:0 1px 2px #000}
      .tv-near{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);font-size:13px;background:rgba(22,15,9,.78);padding:4px 10px;border-radius:7px;white-space:nowrap;max-width:46vw;overflow:hidden;text-overflow:ellipsis}
      .tv-act{position:absolute;right:14px;bottom:14px;display:flex;flex-direction:column;align-items:flex-end;gap:8px;pointer-events:none}
      .tv-use{pointer-events:auto;touch-action:none;width:96px;min-height:72px;border-radius:14px;border:1.5px solid rgba(224,176,96,.75);background:rgba(110,70,28,.82);color:#f6e8c8;font-family:var(--f-body);font-weight:700;font-size:13px;line-height:1.2;padding:6px 8px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;box-sizing:border-box;cursor:pointer;transform-origin:100% 100%}
      .tv-use small{font-weight:500;font-size:12px;color:#ead9b8}
      .tv-use.off small{color:#f0b89a}
      .tv-use.off{background:rgba(40,30,20,.78);border:1.5px dashed rgba(201,150,63,.45);color:rgba(239,226,196,.8)}
      .tv-use.on{background:rgba(200,140,60,.95);transform:scale(.97)}
      .tv-drop{pointer-events:auto;touch-action:none;min-width:64px;min-height:44px;border-radius:11px;border:1px solid rgba(201,150,63,.4);background:rgba(22,15,9,.75);color:#efe2c4;font-size:13px;font-weight:700;padding:0 10px;cursor:pointer}
      .tv-note{position:absolute;left:50%;top:52px;transform:translateX(-50%);font-size:13px;padding:4px 12px;border-radius:7px;background:rgba(22,15,9,.62);opacity:0;transition:opacity .15s;white-space:nowrap;pointer-events:none}
      .tv-note.bad{color:#f0a080}.tv-note.good{color:#d8e8a8}
      .tv-bub{position:absolute;left:0;top:0;transform:translate(-50%,-100%);display:flex;align-items:center;gap:2px;padding:3px 6px 3px 4px;border-radius:14px;background:rgba(247,239,220,.96);border:1.5px solid rgba(70,46,22,.65);box-shadow:0 2px 5px rgba(0,0,0,.45);will-change:transform;margin-top:-6px}
      .tv-bub::after{content:'';position:absolute;left:50%;top:100%;margin-left:-5px;border:5px solid transparent;border-bottom:0;border-top-color:rgba(70,46,22,.8)}
      .tv-bub svg.r{flex:none}.tv-bub .rg{display:flex;flex:none}
      .tv-bub .it{display:flex;flex:none;border-radius:7px;padding:1px}
      .tv-bub .it.have{background:rgba(111,154,58,.35);box-shadow:0 0 0 2px #4f7a24}
      .tv-bub.urg{border-color:#b0402a;box-shadow:0 0 0 2px rgba(176,64,42,.65),0 2px 5px rgba(0,0,0,.45)}.tv-bub.urg::after{border-top-color:#b0402a}
      .tv-bub.rw{background:rgba(150,40,30,.96);border-color:#f0b89a;color:#fff1e0;font-size:13px;font-weight:700;padding:3px 8px}.tv-bub.rw::after{border-top-color:#f0b89a}
      .tv-tag{position:absolute;left:0;top:0;transform:translate(-50%,-100%);display:flex;align-items:center;gap:3px;font-size:12px;line-height:1.55;padding:1px 6px;border-radius:5px;background:rgba(22,15,9,.84);white-space:nowrap;will-change:transform;border-left:3px solid var(--c,#c9963f)}
      .tv-tag b{font-family:var(--f-mono);font-weight:600;color:#f3d79a;margin-right:2px}
      .tv-tag.dim{opacity:.75}
      .tv-aim{position:absolute;left:0;top:0;transform:translate(-50%,-100%);font-size:12.5px;font-weight:700;line-height:1.45;padding:2px 9px;border-radius:9px;background:rgba(122,79,31,.96);border:1.5px solid #e0b060;color:#fff3da;white-space:nowrap;will-change:transform;box-shadow:0 2px 6px rgba(0,0,0,.5);margin-top:-6px}
      .tv-aim::after{content:'';position:absolute;left:50%;top:100%;margin-left:-5px;border:5px solid transparent;border-bottom:0;border-top-color:#e0b060}
      .tv-aim.off{background:rgba(40,30,20,.92);border:1.5px dashed rgba(224,176,96,.7);color:#f0d9c0;font-weight:600}.tv-aim.off::after{border-top-color:rgba(224,176,96,.7)}
      .tv-bub{z-index:2}.tv-aim{z-index:3}.tv-tag{z-index:1}
      .tv-bdg{position:absolute;left:0;top:0;transform:translate(-50%,-100%);width:28px;height:28px;border-radius:50%;background:rgba(22,15,9,.82);border:1.5px solid rgba(224,176,96,.7);display:flex;align-items:center;justify-content:center;will-change:transform;box-sizing:border-box}
      .tv-coin{position:absolute;left:0;top:0;transform:translate(-50%,-100%);font-family:var(--f-mono);font-size:13px;font-weight:700;color:#f3d79a;text-shadow:0 1px 2px #000;will-change:transform}
      .tv-panel{position:absolute;pointer-events:auto;background:rgba(24,17,11,.94);border:1px solid rgba(201,150,63,.32);display:flex;flex-direction:column;color:#efe2c4;font-family:var(--f-body);box-sizing:border-box;touch-action:pan-y}
      .tv-panel.r{right:0;top:0;bottom:0;border-width:0 0 0 1px}
      .tv-panel.b{left:0;right:0;bottom:0;border-width:1px 0 0 0;border-radius:14px 14px 0 0}
      .tv-head{padding:10px 12px 8px;border-bottom:1px solid rgba(201,150,63,.2)}
      .tv-panel.r .tv-head{padding-right:54px}
      .tv-head h3{margin:0;font-family:${SERIF};font-weight:700;font-size:18px;letter-spacing:.03em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .tv-head h3 small{font-family:var(--f-body);font-weight:400;font-size:12.5px;color:#cdbd9c}
      .tv-ev{margin-top:4px;font-size:12px;color:#e6c88a;line-height:1.4}
      .tv-chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
      .tv-headrow{display:flex;gap:6px;align-items:center;margin-top:6px}.tv-headrow .tv-chips{flex:1;margin-top:0}.tv-headrow>.tv-b{flex:none}
      .tv-chip{font-size:12px;padding:2px 8px;border-radius:6px;background:rgba(255,240,210,.07);white-space:nowrap}
      .tv-chip b{font-family:var(--f-mono);color:#f3d79a;font-weight:600}
      .tv-tabs{display:flex;gap:4px;padding:6px 8px 0;overflow-x:auto;flex:none}
      .tv-tab{flex:1 0 auto;min-height:44px;min-width:56px;border:1px solid rgba(201,150,63,.25);border-bottom:0;border-radius:9px 9px 0 0;background:rgba(255,240,210,.04);color:#cdbd9c;font-size:13.5px;font-weight:700;cursor:pointer;padding:0 10px}
      .tv-tab.on{background:rgba(201,150,63,.2);color:#f6e8c8}
      .tv-body{flex:1;overflow-y:auto;padding:8px 10px;border-top:1px solid rgba(201,150,63,.25);-webkit-overflow-scrolling:touch}
      .tv-row{display:flex;align-items:center;gap:8px;padding:6px 2px;border-bottom:1px solid rgba(201,150,63,.1)}
      .tv-row .nm{flex:1;min-width:0;font-size:13.5px;line-height:1.3}
      .tv-row .nm small{display:block;font-size:12px;color:#c9b996;white-space:normal}
      .tv-row .nm .bad{color:#e49a7a}
      .tv-row .num{font-family:var(--f-mono);font-size:13px;min-width:26px;text-align:right}
      .tv-b{min-height:44px;min-width:44px;border-radius:9px;border:1px solid rgba(201,150,63,.38);background:#33251a;color:#efe2c4;font-size:12.5px;font-weight:700;padding:0 9px;cursor:pointer;flex:none;line-height:1.15}
      .tv-b small{font-size:12px;font-weight:500}
      .tv-b .tv-pic{margin-right:4px}
      .tv-b:disabled{opacity:.5;cursor:default;border-style:dashed;background:#241a12}
      .tv-b.p{background:#7a4f1f;border-color:#d9a85a;color:#fff3da}
      .tv-b.w{flex:1}
      .tv-card{border:1px solid rgba(201,150,63,.22);border-radius:9px;padding:7px 9px;margin:6px 0;background:rgba(255,240,210,.03)}
      .tv-card h4{margin:0 0 4px;font-size:13.5px;display:flex;align-items:center;gap:6px}
      .tv-inv{display:flex;flex-wrap:wrap;gap:4px 10px;font-size:13px}.tv-inv span{display:flex;align-items:center;gap:3px;white-space:nowrap}.tv-inv b{font-family:var(--f-mono);font-weight:600;color:#f3d79a}
      .tv-card h4 span{margin-left:auto;font-weight:400;font-size:12px;opacity:.75}
      .tv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(118px,1fr));gap:5px}
      .tv-grid .tv-b{min-height:52px;text-align:left;padding:4px 8px;font-weight:600}
      .tv-grid .tv-b small{display:block;font-weight:400;font-size:12px;color:#d6c6a4}
      .tv-foot{display:flex;gap:6px;padding:8px 10px;border-top:1px solid rgba(201,150,63,.22);flex-wrap:wrap;align-items:center}
      .tv-ready{display:flex;gap:4px;flex-wrap:wrap;width:100%;font-size:12px}
      .tv-ready span{padding:1px 7px;border-radius:999px;background:rgba(255,240,210,.06)}.tv-ready span.k{background:rgba(110,140,70,.45)}
      .tv-sum{width:100%;border-collapse:collapse;font-size:13px}
      .tv-sum td{padding:3px 2px;border-bottom:1px solid rgba(201,150,63,.1)}.tv-sum td:last-child{text-align:right;font-family:var(--f-mono)}
      .tv-sum tr.t td{font-weight:700;color:#f3d79a;border-top:1px solid rgba(201,150,63,.35)}
      .tv-log{font-size:12.5px;line-height:1.55;color:#e2d3b2}
      .tv-fold{position:absolute;pointer-events:auto;min-width:44px;min-height:44px;border-radius:10px;border:1px solid rgba(201,150,63,.35);background:rgba(22,15,9,.82);color:#efe2c4;font-size:12.5px;font-weight:700;padding:0 10px;cursor:pointer}
      .tv-tip{position:absolute;left:50%;bottom:96px;transform:translateX(-50%);width:min(80vw,440px);font-size:13px;line-height:1.5;background:rgba(22,15,9,.9);border:1px solid rgba(201,150,63,.3);border-radius:10px;padding:8px 12px;pointer-events:auto}
      .tv-tip kbd{font-family:var(--f-mono);font-size:12px;padding:0 4px;border-radius:3px;background:rgba(255,240,210,.14)}
      .tv-stk{position:absolute;left:0;top:0;border-radius:50%;border:2px solid rgba(239,226,196,.42);background:rgba(22,15,9,.34);display:none;pointer-events:none;box-sizing:border-box}
      .tv-stk.on{border-color:rgba(224,176,96,.85);background:rgba(22,15,9,.48)}
      .tv-stk i{position:absolute;left:50%;top:50%;width:52px;height:52px;margin:-26px 0 0 -26px;border-radius:50%;background:rgba(201,150,63,.78);border:2px solid rgba(255,240,210,.85);box-shadow:0 2px 8px rgba(0,0,0,.45)}
      .tv-stk b{position:absolute;left:0;right:0;top:100%;margin-top:4px;text-align:center;font-size:12px;font-weight:600;color:#efe2c4;text-shadow:0 1px 3px #000}
      .tv-stk.on b{display:none}
      .tv-wrap.stick .tv-carry{left:auto;right:calc(30px + 96px*var(--ctl-scale,1));bottom:14px}.tv-wrap.stick .tv-cl{display:none}
      .tv-wrap.stick .tv-near{left:auto;right:calc(30px + 96px*var(--ctl-scale,1));bottom:70px;transform:none;max-width:44vw}
      .tv-intro{position:absolute;left:50%;top:38%;transform:translate(-50%,-50%);text-align:center;font-family:${SERIF};color:#f6e8c8;text-shadow:0 2px 8px #000;opacity:0;transition:opacity .25s;pointer-events:none}
      .tv-intro b{display:block;font-size:min(7vh,30px);letter-spacing:.06em}.tv-intro span{font-family:var(--f-body);font-size:13px;opacity:.85}
      @media (max-height:520px){.tv-head{padding:6px 10px 5px}.tv-head h3{font-size:15px}.tv-ev{font-size:12px;margin-top:2px}.tv-chips{margin-top:3px;gap:3px}.tv-chip{font-size:12px;padding:1px 6px}.tv-chips .tv-b{min-height:44px;font-size:12.5px}
        .tv-tabs{padding:4px 6px 0}.tv-tab{font-size:12.5px;min-width:48px}.tv-body{padding:4px 8px}.tv-row{padding:3px 2px}.tv-row .nm{font-size:12.5px}.tv-row .nm small{font-size:12px}.tv-log{font-size:12px}
        .tv-foot{padding:5px 8px;gap:5px}.tv-card{padding:5px 7px;margin:4px 0}.tv-grid .tv-b{min-height:46px}.tv-headrow{margin-top:3px}}
      @media (max-height:520px),(max-width:560px){.tv-stock{display:grid;grid-template-columns:repeat(3,auto);gap:0 8px;max-width:none}.tv-stock hr{grid-column:1/-1;width:100%}.tv-stock .n{display:none}.tv-stock div u i{display:none}.tv-stock div b{margin-left:0}.tv-stock div u{margin-left:0;order:3}.tv-stock div.w{grid-column:1/-1}}
      @media (max-width:560px){.tv-purse{left:auto;right:58px;transform:none;flex-direction:column;gap:3px;align-items:flex-end}.tv-stock{top:108px}.tv-note{top:62px}
        .tv-wrap.stick .tv-near{left:10px;right:auto;top:74px;bottom:auto;max-width:56vw}}
    ` }));

    /* ----- 렌더러 ----- */
    let R;
    try { R = new THREE.WebGLRenderer({ antialias: TIER.aa, powerPreference: 'high-performance' }); }
    catch (e) { hooks.progress(1, '3D 그래픽을 켜지 못했습니다.'); return { update() {}, destroy() { wrap.remove(); } }; }
    R.domElement.className = 'tv3d';
    wrap.prepend(R.domElement);
    R.outputColorSpace = THREE.SRGBColorSpace;
    R.toneMapping = THREE.ACESFilmicToneMapping; R.toneMappingExposure = 1.0;
    R.shadowMap.enabled = TIER.shadow > 0; R.shadowMap.type = THREE.PCFSoftShadowMap;
    R.setClearColor(0x0d0907);
    const scene = new THREE.Scene();
    const cam = new THREE.PerspectiveCamera(38, 1, 0.3, 160);
    const DBG = window.TV_DBG = { scene, R, cam };
    let vw = 1, vh = 1;

    /* ----- 빛(개수 고정) ----- */
    const hemi = new THREE.HemisphereLight(0x8090b0, 0x2a1a10, 0.4);
    const sun = new THREE.DirectionalLight(0xffe2b8, 2.0);
    sun.position.set(-8, 16, 14); sun.target.position.set(9, 0, 5);
    if (TIER.shadow) { sun.castShadow = true; sun.shadow.mapSize.set(TIER.shadow, TIER.shadow); const sc = sun.shadow.camera; sc.left = -14; sc.right = 14; sc.top = 12; sc.bottom = -12; sc.near = 1; sc.far = 60; sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.03; sun.shadow.radius = high ? 4 : 2.5; }
    scene.add(hemi, sun, sun.target);
    const PL = [];
    const plSpots = [[1.7, 1.1, 1.0, 0xffa45a, 7], [9.4, 2.6, 2.6, 0xffc07a, 5], [6.6, 1.8, 7.0, 0xffc483, 3.6], [12.6, 1.8, 7.2, 0xffc483, 3.6], [15.6, 1.8, 7.6, 0xffc483, 3.2], [3.0, 2.2, 9.6, 0xffc483, 3]];
    for (let i = 0; i < TIER.lights; i++) { const p = plSpots[i]; const l = new THREE.PointLight(p[3], p[4] * (low ? 1.5 : 1), 14, 1.25); l.position.set(p[0], p[1], p[2]); l.userData.base = p[4]; PL.push(l); scene.add(l); }
    if (high && PL[0]) { PL[0].castShadow = true; PL[0].shadow.mapSize.set(512, 512); PL[0].shadow.bias = -0.002; }

    /* ----- 재질 ----- */
    const TX = { planks: texPlanks(), stone: texStone(), plaster: texPlaster(), wood: texWood(), rug: texRug(), tap: texTapestry(), map: texMap(), banner: texBanner(), soft: texSoft() };
    if (!low) { const an = Math.min(8, R.capabilities.getMaxAnisotropy()); for (const k in TX) TX[k].anisotropy = an; }
    TX.planks.repeat.set(1 / 3, 1 / 3); TX.stone.repeat.set(1 / 2.2, 1 / 2.2); TX.plaster.repeat.set(1 / 2, 1 / 2); TX.wood.repeat.set(1, 1);
    const Std = (o) => { if (low) { const q = Object.assign({}, o); delete q.roughness; delete q.metalness; return new THREE.MeshLambertMaterial(q); } return new THREE.MeshStandardMaterial(Object.assign({ roughness: 0.85, metalness: 0 }, o)); };
    const MT = {
      floor: Std({ map: TX.planks, color: 0xe0cbb0, roughness: 0.8 }),
      stone: Std({ map: TX.stone, color: 0xd6cbbd, roughness: 0.95 }),
      plaster: Std({ map: TX.plaster, color: 0xf0e4cc, roughness: 1 }),
      beam: Std({ map: TX.wood, color: 0x7a5a40, roughness: 0.85 }),
      furn: Std({ map: TX.wood, color: 0xf0dcc4, roughness: 0.75 }),
      sack: Std({ color: 0xa8916c, roughness: 1 }),
      steel: Std({ color: 0xa0a6ac, roughness: 0.4, metalness: 0.75 }),
      dark: Std({ color: 0x241810, roughness: 0.9 }),
      iron: Std({ color: 0x3a3836, roughness: 0.55, metalness: 0.6 }),
      brass: Std({ color: 0xb8904a, roughness: 0.4, metalness: 0.75 }),
      cloth: Std({ color: 0xffffff, roughness: 0.95 }),
      clothD: Std({ color: 0xffffff, roughness: 0.95, side: THREE.DoubleSide }),
      skin: Std({ color: 0xffffff, roughness: 0.75 }),
      metal: Std({ color: 0xffffff, roughness: 0.45, metalness: 0.7 }),
      ceramic: Std({ color: 0xffffff, roughness: 0.6 }),
      rug: Std({ map: TX.rug, roughness: 1 }), tap: Std({ map: TX.tap, roughness: 1, side: THREE.DoubleSide }), map: Std({ map: TX.map, roughness: 1 }), banner: Std({ map: TX.banner, roughness: 1, transparent: true, alphaTest: 0.5, side: THREE.DoubleSide }),
      ground: Std({ color: 0x3a3a26, roughness: 1 }), soil: Std({ color: 0x4a3422, roughness: 1 }), leaf: Std({ color: 0xffffff, roughness: 0.9 }),
      glass: new THREE.MeshBasicMaterial({ color: 0x24324a }),
      fire: new THREE.MeshBasicMaterial({ color: 0xffa040, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }),
      fire2: new THREE.MeshBasicMaterial({ color: 0xffe0a0, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false }),
      ember: new THREE.MeshBasicMaterial({ color: 0xff5a1a }),
      glow: new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, depthWrite: false }),
      ring: new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.7, depthWrite: false }),
      water: Std({ color: 0x4a5a5a, roughness: 0.2, metalness: 0.1 }),
      spill: new THREE.MeshBasicMaterial({ color: 0x6a3a14, transparent: true, opacity: 0.55, depthWrite: false }),
    };
    const ptsMat = new THREE.PointsMaterial({ size: 0.5, map: TX.soft, transparent: true, depthWrite: false, opacity: 0.32, color: 0xd8d0c4, sizeAttenuation: true });

    /* ======================= 여관 짓기(정적) ======================= */
    const staticG = new THREE.Group(); scene.add(staticG);
    function bake(lists, group, shadow) {
      for (const k in lists) {
        if (!lists[k].length) continue;
        const m = new THREE.Mesh(merge(lists[k]), MT[k]);
        m.castShadow = !!(shadow && TIER.shadow); m.receiveShadow = !!TIER.shadow;
        m.userData.ownGeo = 1;
        group.add(m);
      }
    }
    const P = () => ({ stone: [], plaster: [], beam: [], furn: [], dark: [], iron: [], brass: [], cloth: [], ceramic: [], soil: [], ground: [], glass: [], ember: [], water: [], leaf: [], sack: [], steel: [] });
    const add = (o, k, g, x, y, z, ry, rx, rz) => o[k].push([g, M4(x, y, z, rx || 0, ry || 0, rz || 0)]);
    function buildStatic() {
      const o = P(), WH = 3.5;
      // 바닥 · 바깥 땅
      const fl = new THREE.Mesh(new THREE.PlaneGeometry(18, 11), MT.floor); fl.rotation.x = -Math.PI / 2; fl.position.set(9, 0, 5.5); fl.receiveShadow = !!TIER.shadow;
      const uv = fl.geometry.attributes.uv; for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * 18, uv.getY(i) * 11);
      staticG.add(fl);
      const gr = new THREE.Mesh(new THREE.PlaneGeometry(90, 70), MT.ground); gr.rotation.x = -Math.PI / 2; gr.position.set(9, -0.04, 4); gr.receiveShadow = !!TIER.shadow; staticG.add(gr);
      // 벽: 돌 아랫단 1m + 회벽 + 들보/기둥. 구멍(창 · 문)
      const wallX = (z0, z1, x0, x1, holes) => {   // z0..z1 두께, x 방향 벽
        let cx = x0;
        const segs = []; for (const hl of holes.concat([[x1, x1, 0, 0]]).sort((a, b) => a[0] - b[0])) { if (hl[0] > cx) segs.push([cx, hl[0], 0, WH]); if (hl[1] > hl[0]) { if (hl[2] > 0) segs.push([hl[0], hl[1], 0, hl[2]]); if (hl[3] < WH) segs.push([hl[0], hl[1], hl[3], WH]); } cx = Math.max(cx, hl[1]); }
        for (const [a, b, y0, y1] of segs) {
          const w = b - a, d = z1 - z0;
          if (y0 < 1.0) add(o, 'stone', boxW(w, Math.min(1.0, y1) - y0, d, 1), (a + b) / 2, (y0 + Math.min(1.0, y1)) / 2, (z0 + z1) / 2);
          if (y1 > 1.0) add(o, 'plaster', boxW(w, y1 - Math.max(1.0, y0), d * 0.9, 1), (a + b) / 2, (Math.max(1.0, y0) + y1) / 2, (z0 + z1) / 2);
        }
      };
      const wallZ = (x0, x1, z0, z1, holes) => {
        let cz = z0;
        const segs = []; for (const hl of holes.concat([[z1, z1, 0, 0]]).sort((a, b) => a[0] - b[0])) { if (hl[0] > cz) segs.push([cz, hl[0], 0, WH]); if (hl[1] > hl[0]) { if (hl[2] > 0) segs.push([hl[0], hl[1], 0, hl[2]]); if (hl[3] < WH) segs.push([hl[0], hl[1], hl[3], WH]); } cz = Math.max(cz, hl[1]); }
        for (const [a, b, y0, y1] of segs) {
          const w = b - a, d = x1 - x0;
          if (y0 < 1.0) add(o, 'stone', boxW(d, Math.min(1.0, y1) - y0, w, 1), (x0 + x1) / 2, (y0 + Math.min(1.0, y1)) / 2, (a + b) / 2);
          if (y1 > 1.0) add(o, 'plaster', boxW(d * 0.9, y1 - Math.max(1.0, y0), w, 1), (x0 + x1) / 2, (Math.max(1.0, y0) + y1) / 2, (a + b) / 2);
        }
      };
      wallX(-0.35, 0, -0.35, 18.35, [[13.6, 14.9, 1.5, 2.8]]);
      wallZ(-0.35, 0, 0, 11.3, [[8.0, 9.3, 1.3, 2.6]]);
      wallZ(18, 18.35, 0, 11.3, [[5.0, 6.2, 1.3, 2.6], [8.15, 9.45, 0, 2.35]]);
      // 앞쪽 잘린 낮은 벽
      add(o, 'stone', boxW(18.7, 0.42, 0.32, 1), 9, 0.21, 11.16);
      // 기둥 · 들보
      for (const x of [0.15, 4.9, 9.4, 13.4, 17.85]) add(o, 'beam', boxW(0.26, WH, 0.22, 1), x, WH / 2, 0.12);
      for (const z of [0.15, 4.0, 7.5, 11.1]) { add(o, 'beam', boxW(0.22, WH, 0.26, 1), 0.12, WH / 2, z); add(o, 'beam', boxW(0.22, WH, 0.26, 1), 17.88, WH / 2, z); }
      add(o, 'beam', boxW(18.3, 0.24, 0.26, 1), 9, WH - 0.12, 0.13); add(o, 'beam', boxW(18.3, 0.12, 0.2, 1), 9, 1.06, 0.1);
      add(o, 'beam', boxW(0.26, 0.24, 11.3, 1), 0.13, WH - 0.12, 5.6); add(o, 'beam', boxW(0.26, 0.24, 11.3, 1), 17.87, WH - 0.12, 5.6);
      // 창(유리 + 살)
      const win = (x, y, z, w, hh, ry) => { add(o, 'glass', new THREE.PlaneGeometry(w, hh), x, y, z, ry); add(o, 'beam', boxW(w + 0.16, 0.1, 0.12), x, y - hh / 2, z, ry); add(o, 'beam', boxW(w + 0.16, 0.1, 0.12), x, y + hh / 2, z, ry); add(o, 'beam', boxW(0.06, hh, 0.08), x, y, z, ry); };
      win(14.25, 2.15, -0.12, 1.3, 1.3, 0);
      win(-0.12, 1.95, 8.65, 1.3, 1.3, Math.PI / 2);
      win(18.12, 1.95, 5.6, 1.2, 1.3, -Math.PI / 2);
      // 문틀
      add(o, 'beam', boxW(0.3, 2.5, 0.16), 18.05, 1.25, 8.08); add(o, 'beam', boxW(0.3, 2.5, 0.16), 18.05, 1.25, 9.52); add(o, 'beam', boxW(0.3, 0.2, 1.6), 18.05, 2.42, 8.8);
      // 난로(벽난로): 옆기둥 · 이맛돌 · 굴뚝 가슴 · 바닥돌
      add(o, 'stone', boxW(0.36, 1.25, 1.1), 0.98, 0.62, 0.55); add(o, 'stone', boxW(0.36, 1.25, 1.1), 2.42, 0.62, 0.55);
      add(o, 'stone', boxW(1.9, 0.4, 1.2), 1.7, 1.42, 0.58); add(o, 'stone', boxW(1.6, 1.9, 0.9), 1.7, 2.55, 0.45);
      add(o, 'beam', boxW(2.1, 0.14, 0.3), 1.7, 1.66, 1.12);
      add(o, 'stone', boxW(2.2, 0.08, 1.5), 1.7, 0.04, 0.75);
      add(o, 'dark', boxW(1.1, 1.05, 0.08), 1.7, 0.6, 0.06);
      add(o, 'dark', boxW(0.9, 0.12, 0.14), 1.6, 0.12, 0.55, 0.3); add(o, 'dark', boxW(0.9, 0.12, 0.14), 1.8, 0.16, 0.6, -0.4);
      add(o, 'ember', boxW(0.7, 0.04, 0.5), 1.7, 0.1, 0.55);
      add(o, 'iron', new THREE.CylinderGeometry(0.012, 0.012, 0.75, 4), 1.7, 1.0, 0.55);
      // 솥(가마솥) — 걸어 둠
      const pot = merge([[new THREE.SphereGeometry(0.32, 12, 8, 0, TAU, Math.PI * 0.35, Math.PI * 0.65), M4(0, 0, 0)], [new THREE.TorusGeometry(0.27, 0.025, 6, 16), M4(0, 0.15, 0, Math.PI / 2)]]);
      add(o, 'iron', pot, 1.7, 0.52, 0.55);
      add(o, 'water', new THREE.CircleGeometry(0.25, 14), 1.7, 0.62, 0.55, 0, -Math.PI / 2);
      // 화덕(돌 화덕)
      add(o, 'stone', boxW(1.6, 0.85, 1.2), 3.8, 0.42, 0.6);
      add(o, 'stone', new THREE.SphereGeometry(0.7, 12, 8, 0, TAU, 0, Math.PI / 2), 3.8, 0.85, 0.55);
      add(o, 'dark', new THREE.CircleGeometry(0.3, 12, 0, Math.PI), 3.8, 0.87, 1.15);
      add(o, 'stone', boxW(0.4, 1.6, 0.4), 3.8, 2.0, 0.35);
      // 찬장 도마(왼쪽 벽) + 선반
      add(o, 'furn', boxW(1.0, 0.1, 1.7), 0.6, 0.86, 3.3); add(o, 'furn', boxW(0.9, 0.8, 1.6), 0.6, 0.4, 3.3);
      add(o, 'beam', boxW(0.6, 0.06, 0.4), 0.7, 0.93, 3.0);
      add(o, 'furn', boxW(0.32, 0.06, 1.8), 0.18, 1.9, 3.3); add(o, 'furn', boxW(0.32, 0.06, 1.8), 0.18, 2.4, 3.3);
      for (let i = 0; i < 6; i++) add(o, i % 2 ? 'ceramic' : 'dark', new THREE.CylinderGeometry(0.07, 0.08, 0.2, 8), 0.18, 2.03 + (i > 2 ? 0.5 : 0), 2.7 + (i % 3) * 0.5);
      add(o, 'sack', new THREE.CylinderGeometry(0.17, 0.17, 0.1, 12), 0.55, 0.96, 3.75);   // 치즈 바퀴
      // 설거지통
      add(o, 'furn', new THREE.CylinderGeometry(0.5, 0.42, 0.55, 14, 1, true), 0.6, 0.6, 5.6);
      add(o, 'furn', boxW(1.0, 0.33, 1.1), 0.6, 0.16, 5.6);
      add(o, 'water', new THREE.CircleGeometry(0.47, 14), 0.6, 0.8, 5.6, 0, -Math.PI / 2);
      add(o, 'iron', new THREE.TorusGeometry(0.47, 0.02, 4, 18), 0.6, 0.78, 5.6, 0, Math.PI / 2);
      // 술통 선반 · 계산대
      add(o, 'beam', boxW(7.2, 0.12, 0.95), 9.75, 0.08, 0.5); add(o, 'beam', boxW(7.2, 0.1, 0.12), 9.75, 0.92, 0.92);
      for (let i = 0; i <= 6; i++) add(o, 'beam', boxW(0.1, 0.95, 0.9), 6.25 + i * 1.08, 0.47, 0.5);
      add(o, 'furn', boxW(6.6, 0.1, 0.75), 9.4, 1.06, 2.6); add(o, 'beam', boxW(6.4, 1.0, 0.5), 9.4, 0.5, 2.6);
      for (let i = 0; i < 7; i++) add(o, 'dark', boxW(0.06, 0.8, 0.04), 6.4 + i * 1.0, 0.5, 2.86);
      add(o, 'furn', boxW(6.4, 0.06, 0.35), 9.4, 1.95, 0.2);   // 뒷벽 잔 선반
      // 계단(오른쪽 뒤)
      for (let i = 0; i < 10; i++) { const z = 3.0 - i * 0.32, y = 0.12 + i * 0.24; add(o, 'furn', boxW(2.5, 0.1, 0.36), 16.6, y + 0.07, z); add(o, 'beam', boxW(2.5, y + 0.12, 0.06), 16.6, (y + 0.12) / 2, z + 0.17); }
      add(o, 'beam', boxW(0.1, 1.0, 0.1), 15.35, 0.95, 3.1); add(o, 'beam', new THREE.CylinderGeometry(0.04, 0.04, 3.9, 6), 15.35, 2.05, 1.6, 0, -0.73);
      add(o, 'beam', boxW(2.8, 0.14, 0.14), 16.6, 2.6, 0.2);
      // 바깥 텃밭 · 건조대
      add(o, 'beam', boxW(5.6, 0.5, 0.08), -3.9, 0.25, 1.4); add(o, 'beam', boxW(5.6, 0.5, 0.08), -3.9, 0.25, 9.8); add(o, 'beam', boxW(0.08, 0.5, 8.4), -6.7, 0.25, 5.6);
      for (let z = 1.4; z <= 9.8; z += 1.4) add(o, 'beam', boxW(0.1, 0.7, 0.1), -6.7, 0.35, z);
      add(o, 'beam', boxW(2.2, 0.08, 1.6), -2.4, 1.1, 0.3); for (const [x, z] of [[-3.4, -0.4], [-1.4, -0.4], [-3.4, 1.0], [-1.4, 1.0]]) add(o, 'beam', boxW(0.1, 2.2, 0.1), x, 1.1, z);
      add(o, 'furn', boxW(2.4, 0.12, 1.8), -2.4, 2.25, 0.3, 0, 0, 0.1);
      bake(o, staticG, true);
    }

    /* ======================= 바뀌는 배치(식탁 · 술통 · 꾸미기 · 텃밭) ======================= */
    const layG = new THREE.Group(); scene.add(layG);
    let layKey = '', Lay = null, brkKey = '';
    const LEN = { bubble: null };
    const caskGeo = barrelGeo(0.42, 0.82), hoopGeo = merge([[new THREE.TorusGeometry(0.4, 0.022, 4, 16), M4(0, 0, 0.3)], [new THREE.TorusGeometry(0.4, 0.022, 4, 16), M4(0, 0, -0.3)], [new THREE.TorusGeometry(0.43, 0.022, 4, 16), M4(0, 0, 0)]]);
    let caskIM = null, hoopIM = null, tapIM = null, candleIM = null, flameIM = null, cropIM = null, stoolIM = null;
    const candles = [];
    function clearLay() { for (const ch of layG.children.slice()) { layG.remove(ch); if (ch.isInstancedMesh) ch.dispose(); if (ch.userData.ownGeo) ch.geometry.dispose(); } candles.length = 0; }
    function buildLayout(st) {
      const key = [T.upLv(st, 'hall'), T.caskCap(st), st.deco.join(','), T.plotCap(st), T.bedCap(st)].join('|');
      if (key === layKey) return;
      layKey = key; clearLay();
      Lay = S.layout(st);
      const o = P();
      // 식탁 · 의자
      for (const tb of Lay.tbs) {
        if (tb.bar) continue;
        if (tb.sh === 'rect') { add(o, 'furn', boxW(1.6, 0.08, 0.95), tb.x, 0.78, tb.z); for (const [dx, dz] of [[-0.68, -0.36], [0.68, -0.36], [-0.68, 0.36], [0.68, 0.36]]) add(o, 'beam', boxW(0.08, 0.74, 0.08), tb.x + dx, 0.37, tb.z + dz); }
        else { add(o, 'furn', new THREE.CylinderGeometry(0.6, 0.6, 0.07, 16), tb.x, 0.78, tb.z); add(o, 'beam', new THREE.CylinderGeometry(0.07, 0.1, 0.74, 8), tb.x, 0.37, tb.z); add(o, 'beam', new THREE.CylinderGeometry(0.32, 0.36, 0.06, 10), tb.x, 0.03, tb.z); }
        candles.push([tb.x + 0.12, 0.82, tb.z - 0.05]);
      }
      // 닫힌 창고 상자
      const R = rnd(7);
      for (const c of Lay.crates) {
        for (let k = 0; k < 6; k++) { const s = 0.5 + R() * 0.3, x = c[0] + 0.3 + R() * (c[2] - c[0] - 0.6), z = c[1] + 0.3 + R() * (c[3] - c[1] - 0.6), y = s / 2 + (k > 3 ? 0.55 : 0); add(o, 'furn', boxW(s, s, s), x, y, z, R() * 0.6); }
        add(o, 'sack', new THREE.SphereGeometry(0.3, 8, 6).scale(1, 1.2, 0.9), c[0] + 0.4, 0.3, c[3] - 0.4); add(o, 'sack', new THREE.SphereGeometry(0.28, 8, 6).scale(1, 1.25, 0.9), c[0] + 0.95, 0.3, c[3] - 0.35);
      }
      // 꾸미기
      const has = (id) => st.deco.includes(id);
      if (has('rug')) { const m = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.5), MT.rug); m.rotation.x = -Math.PI / 2; m.position.set(2.2, 0.012, 7.4); m.receiveShadow = !!TIER.shadow; m.userData.ownGeo = 1; layG.add(m); }
      if (has('candle')) for (const [x, z] of [[0.55, 10.3], [17.4, 10.4]]) { add(o, 'iron', new THREE.CylinderGeometry(0.03, 0.05, 1.6, 6), x, 0.8, z); add(o, 'iron', new THREE.CylinderGeometry(0.18, 0.2, 0.04, 8), x, 0.03, z); add(o, 'iron', new THREE.CylinderGeometry(0.12, 0.06, 0.05, 8), x, 1.62, z); candles.push([x, 1.66, z]); }
      if (has('herbs')) for (let i = 0; i < 5; i++) add(o, 'leaf', new THREE.ConeGeometry(0.1, 0.4, 5), 0.3, 2.9, 2.4 + i * 0.45, 0, Math.PI);
      if (has('ivy')) for (const [x, z] of [[17.65, 5.25], [17.65, 5.95], [-0.05, 8.3]]) { add(o, 'furn', new THREE.CylinderGeometry(0.13, 0.1, 0.22, 8), x, 1.42, z); add(o, 'leaf', new THREE.IcosahedronGeometry(0.2, 0), x, 1.66, z); }
      if (has('map')) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 1.1), MT.map); m.position.set(9.4, 2.65, 0.03); m.userData.ownGeo = 1; layG.add(m); }
      if (has('antler')) { add(o, 'furn', boxW(0.5, 0.35, 0.06), 1.7, 3.0, 0.92); for (const s of [-1, 1]) { add(o, 'ceramic', new THREE.CylinderGeometry(0.025, 0.04, 0.6, 5), 1.7 + s * 0.3, 3.25, 0.95, 0, 0, -s * 0.9); add(o, 'ceramic', new THREE.CylinderGeometry(0.02, 0.03, 0.3, 5), 1.7 + s * 0.42, 3.45, 0.95, 0, 0, s * 0.3); } }
      if (has('banner')) for (const x of [5.5, 13.2]) { const m = new THREE.Mesh(new THREE.PlaneGeometry(0.75, 1.5), MT.banner); m.position.set(x, 2.55, 0.04); m.userData.ownGeo = 1; layG.add(m); add(o, 'iron', new THREE.CylinderGeometry(0.02, 0.02, 0.9, 5), x, 3.32, 0.06, 0, 0, Math.PI / 2); }
      if (has('furs')) { /* 의자 덮개는 의자 색으로 */ }
      if (has('lantern')) for (const [x, z] of [[6.6, 7.0], [12.0, 7.0]]) { add(o, 'iron', new THREE.CylinderGeometry(0.01, 0.01, 0.8, 4), x, 3.1, z); add(o, 'brass', new THREE.CylinderGeometry(0.14, 0.12, 0.3, 6), x, 2.55, z); candles.push([x, 2.55, z, 0x9ad0a0]); }
      if (has('settle')) { add(o, 'furn', boxW(0.5, 0.08, 2.4), 0.55, 0.45, 8.0); add(o, 'furn', boxW(0.08, 1.3, 2.4), 0.3, 0.75, 8.0); add(o, 'beam', boxW(0.5, 0.45, 0.08), 0.55, 0.22, 6.84); add(o, 'beam', boxW(0.5, 0.45, 0.08), 0.55, 0.22, 9.16); }
      if (has('tapestry')) { const m = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.6), MT.tap); m.rotation.y = Math.PI / 2; m.position.set(0.04, 2.35, 6.0); m.userData.ownGeo = 1; layG.add(m); }
      if (has('chandelier')) { add(o, 'iron', new THREE.TorusGeometry(0.6, 0.03, 4, 20), 9.0, 2.75, 7.0, 0, Math.PI / 2); add(o, 'iron', new THREE.CylinderGeometry(0.012, 0.012, 0.75, 4), 9.0, 3.12, 7.0); for (let k = 0; k < 6; k++) { const a = k * TAU / 6; candles.push([9.0 + Math.sin(a) * 0.6, 2.85, 7.0 + Math.cos(a) * 0.6]); } }
      if (has('stage')) add(o, 'furn', boxW(2.2, 0.18, 1.1), 15.4, 0.09, 10.3);
      if (has('armor')) { add(o, 'steel', new THREE.CylinderGeometry(0.2, 0.24, 0.6, 8), 14.5, 1.15, 0.45); add(o, 'steel', new THREE.SphereGeometry(0.15, 8, 6), 14.5, 1.6, 0.45); add(o, 'steel', boxW(0.12, 0.8, 0.14), 14.38, 0.42, 0.45); add(o, 'steel', boxW(0.12, 0.8, 0.14), 14.62, 0.42, 0.45); add(o, 'dark', boxW(0.6, 0.06, 0.5), 14.5, 0.03, 0.45); }
      // 침대 수 표시(계단 위 층계참 옆 표지)
      // 텃밭 이랑
      for (let i = 0; i < T.plotCap(st); i++) { const x = -5.6 + (i % 2) * 2.4, z = 2.4 + Math.floor(i / 2) * 1.8; add(o, 'soil', boxW(1.9, 0.14, 1.3), x, 0.07, z); }
      bake(o, layG, true);
      // 술통(인스턴스)
      caskIM = new THREE.InstancedMesh(caskGeo, MT.furn, 6); caskIM.count = 0; hoopIM = new THREE.InstancedMesh(hoopGeo, MT.iron, 6); hoopIM.count = 0; tapIM = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.03, 0.03, 0.16, 6), MT.brass, 6); tapIM.count = 0;
      for (const im of [caskIM, hoopIM, tapIM]) { im.castShadow = !!TIER.shadow; im.receiveShadow = !!TIER.shadow; layG.add(im); }
      // 의자
      stoolIM = new THREE.InstancedMesh(merge([[new THREE.CylinderGeometry(0.22, 0.2, 0.07, 10), M4(0, 0.48, 0)], [new THREE.CylinderGeometry(0.025, 0.035, 0.46, 5), M4(0.12, 0.23, 0, 0, 0, 0.1)], [new THREE.CylinderGeometry(0.025, 0.035, 0.46, 5), M4(-0.06, 0.23, 0.1, 0.1)], [new THREE.CylinderGeometry(0.025, 0.035, 0.46, 5), M4(-0.06, 0.23, -0.1, -0.1)]]), MT.furn, Lay.seats.length);
      stoolIM.castShadow = !!TIER.shadow; stoolIM.receiveShadow = !!TIER.shadow; layG.add(stoolIM);
      const fur = has('furs');
      Lay.seats.forEach((s, i) => { stoolIM.setMatrixAt(i, M4(s.x, Lay.tbs[s.tb].bar ? 0.18 : 0, s.z, 0, s.yaw, 0, 1, Lay.tbs[s.tb].bar ? 1.4 : 1, 1)); stoolIM.setColorAt(i, new THREE.Color(fur ? 0xd8c8b0 : 0xffffff)); });
      // 촛불
      candleIM = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.035, 0.04, 0.16, 6), MT.ceramic, Math.max(1, candles.length)); flameIM = new THREE.InstancedMesh(new THREE.ConeGeometry(0.03, 0.09, 6), MT.fire2, Math.max(1, candles.length));
      candles.forEach((c, i) => { candleIM.setMatrixAt(i, M4(c[0], c[1], c[2])); candleIM.setColorAt(i, new THREE.Color(0xefe4c6)); });
      candleIM.count = flameIM.count = candles.length; layG.add(candleIM, flameIM);
      // 작물
      cropIM = new THREE.InstancedMesh(new THREE.ConeGeometry(0.09, 0.3, 5), MT.leaf, 8 * 6); cropIM.count = 0; layG.add(cropIM);
      tagsDirty = true;
    }

    /* ======================= 사람(인스턴스 부위) ======================= */
    const MAXC = 72;
    const PART = {
      leg: [new THREE.BoxGeometry(0.13, 0.5, 0.15).translate(0, -0.25, 0), MT.cloth],
      torso: [merge([[new THREE.CylinderGeometry(0.17, 0.24, 0.56, 9), M4(0, 0.8, 0)], [new THREE.CylinderGeometry(0.245, 0.27, 0.16, 9), M4(0, 0.5, 0)]]), MT.cloth],
      arm: [new THREE.BoxGeometry(0.1, 0.46, 0.11).translate(0, -0.23, 0), MT.cloth],
      head: [new THREE.IcosahedronGeometry(0.14, 1).translate(0, 1.25, 0), MT.skin],
      hair: [new THREE.SphereGeometry(0.15, 9, 6, 0, TAU, 0, Math.PI * 0.55).translate(0, 1.27, -0.012), MT.cloth],
      hood: [merge([[new THREE.SphereGeometry(0.19, 9, 6, 0, TAU, 0, Math.PI * 0.62), M4(0, 1.25, -0.02)], [new THREE.BoxGeometry(0.34, 0.22, 0.12), M4(0, 1.07, -0.12)]]), MT.cloth],
      cowl: [merge([[new THREE.SphereGeometry(0.2, 9, 6, 0, TAU, 0, Math.PI * 0.62), M4(0, 1.25, -0.03)], [new THREE.CylinderGeometry(0.2, 0.36, 0.3, 10), M4(0, 1.0, 0)]]), MT.cloth],
      brim: [merge([[new THREE.CylinderGeometry(0.27, 0.27, 0.025, 14), M4(0, 1.36, 0)], [new THREE.CylinderGeometry(0.12, 0.15, 0.15, 10), M4(0, 1.44, 0)]]), MT.cloth],
      cap: [merge([[new THREE.SphereGeometry(0.158, 10, 6, 0, TAU, 0, Math.PI * 0.5), M4(0, 1.29, 0)], [new THREE.ConeGeometry(0.06, 0.18, 5), M4(0, 1.43, -0.1, -0.9)]]), MT.cloth],
      helm: [merge([[new THREE.SphereGeometry(0.168, 10, 6, 0, TAU, 0, Math.PI * 0.5), M4(0, 1.27, 0)], [new THREE.BoxGeometry(0.03, 0.12, 0.03), M4(0, 1.24, 0.16)]]), MT.metal],
      coif: [merge([[new THREE.SphereGeometry(0.172, 9, 6, 0, TAU, 0, Math.PI * 0.7), M4(0, 1.24, -0.01)], [new THREE.CylinderGeometry(0.16, 0.22, 0.16, 9), M4(0, 1.06, 0)]]), MT.metal],
      cloak: [new THREE.CylinderGeometry(0.27, 0.36, 0.88, 12, 1, true, Math.PI * 0.62, Math.PI * 1.76).translate(0, 0.7, 0), MT.clothD],
      apron: [new THREE.BoxGeometry(0.3, 0.52, 0.025).translate(0, 0.66, 0.235).rotateX(-0.05), MT.cloth],
      pack: [new THREE.BoxGeometry(0.32, 0.38, 0.2).translate(0, 0.9, -0.28), MT.cloth],
      plume: [new THREE.ConeGeometry(0.035, 0.26, 5).rotateX(-0.6).translate(0.08, 1.56, -0.08), MT.cloth],
      ring: [new THREE.RingGeometry(0.3, 0.38, 24).rotateX(-Math.PI / 2).translate(0, 0.015, 0), MT.ring],
    };
    const PIM = {};
    for (const k in PART) { const im = new THREE.InstancedMesh(PART[k][0], PART[k][1], MAXC * (k === 'leg' || k === 'arm' ? 2 : 1)); im.count = 0; im.castShadow = !!TIER.shadow && k !== 'ring'; im.frustumCulled = false; im.setColorAt(0, new THREE.Color(1, 1, 1)); PIM[k] = im; scene.add(im); }
    /* 들고 있는 것 · 식탁 위 그릇 */
    const ITEM = {
      mug: [merge([[new THREE.CylinderGeometry(0.06, 0.055, 0.13, 8), M4(0, 0.065, 0)], [new THREE.TorusGeometry(0.035, 0.012, 4, 8, Math.PI), M4(0.065, 0.07, 0, 0, 0, -Math.PI / 2)]]), MT.ceramic],
      top: [new THREE.CylinderGeometry(0.052, 0.052, 0.012, 8).translate(0, 0.128, 0), MT.ceramic],
      plate: [new THREE.CylinderGeometry(0.15, 0.12, 0.025, 12).translate(0, 0.012, 0), MT.ceramic],
      food: [new THREE.SphereGeometry(0.1, 8, 5, 0, TAU, 0, Math.PI / 2).scale(1, 0.55, 1).translate(0, 0.02, 0), MT.ceramic],
    };
    const IIM = {};
    for (const k in ITEM) { const im = new THREE.InstancedMesh(ITEM[k][0], ITEM[k][1], 160); im.count = 0; im.frustumCulled = false; im.castShadow = !!TIER.shadow; im.setColorAt(0, new THREE.Color(1, 1, 1)); IIM[k] = im; scene.add(im); }
    /* 불꽃 · 쏟은 술 · 김 */
    const fireG = new THREE.Group(); scene.add(fireG);
    const fl1 = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.6, 7), MT.fire), fl2 = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.42, 7), MT.fire2), fl3 = new THREE.Mesh(new THREE.ConeGeometry(0.15, 0.45, 7), MT.fire);
    fl1.position.set(1.7, 0.36, 0.55); fl2.position.set(1.65, 0.3, 0.6); fl3.position.set(1.88, 0.3, 0.5);
    const ovGlow = new THREE.Mesh(new THREE.CircleGeometry(0.26, 12, 0, Math.PI), MT.fire); ovGlow.position.set(3.8, 0.88, 1.16);
    fireG.add(fl1, fl2, fl3, ovGlow);
    const spillIM = new THREE.InstancedMesh(new THREE.CircleGeometry(0.42, 14).rotateX(-Math.PI / 2), MT.spill, 12); spillIM.count = 0; scene.add(spillIM);
    const markIM = new THREE.InstancedMesh(new THREE.RingGeometry(0.22, 0.3, 20).rotateX(-Math.PI / 2), MT.ring, 1); markIM.count = 0; markIM.setColorAt(0, new THREE.Color(0xe0b060)); scene.add(markIM);
    const NP = low ? 40 : 80;
    const pPos = new Float32Array(NP * 3), pAge = new Float32Array(NP), pVel = new Float32Array(NP * 3);
    const pGeo = new THREE.BufferGeometry(); pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    const steam = new THREE.Points(pGeo, ptsMat); steam.frustumCulled = false; scene.add(steam);
    for (let i = 0; i < NP; i++) { pAge[i] = 99; pPos[i * 3 + 1] = -50; }
    let pNext = 0;
    function emit(x, y, z, vy, spread) { const i = pNext; pNext = (pNext + 1) % NP; pPos[i * 3] = x + (Math.random() - 0.5) * spread; pPos[i * 3 + 1] = y; pPos[i * 3 + 2] = z + (Math.random() - 0.5) * spread; pVel[i * 3] = (Math.random() - 0.5) * 0.15; pVel[i * 3 + 1] = vy * (0.7 + Math.random() * 0.6); pVel[i * 3 + 2] = (Math.random() - 0.5) * 0.15; pAge[i] = 0; }

    /* ----- 미리 굽기 ----- */
    function warmGroup() {
      const g = new THREE.Group(), bx = new THREE.BoxGeometry(0.1, 0.1, 0.1);
      for (const k of Object.keys(MT)) { const m = new THREE.Mesh(bx, MT[k]); m.position.y = -60; g.add(m); const im = new THREE.InstancedMesh(bx, MT[k], 1); im.setMatrixAt(0, M4(0, -60, 0)); im.setColorAt(0, new THREE.Color(1, 1, 1)); g.add(im); }
      const pg = new THREE.BufferGeometry(); pg.setAttribute('position', new THREE.Float32BufferAttribute([0, -60, 0], 3)); g.add(new THREE.Points(pg, ptsMat));
      g.traverse((o) => { if (o.isMesh) { o.castShadow = !!TIER.shadow; o.receiveShadow = !!TIER.shadow; } o.frustumCulled = false; });
      return g;
    }
    function compileBg(obj) {
      try { if (R.compileAsync && R.extensions.has('KHR_parallel_shader_compile')) return R.compileAsync(obj, cam).catch(() => {}); R.compile(obj, cam); } catch (e) { console.warn(e); }
      return Promise.resolve();
    }

    /* ======================= HUD · 창 ======================= */
    const layer = h('div', { class: 'tv-layer' }); wrap.append(layer);
    const bubL = h('div', { class: 'tv-layer' }); wrap.append(bubL);
    const plaque = h('div', { class: 'tv-plaque' }); const purse = h('div', { class: 'tv-purse' }); const stock = h('div', { class: 'tv-stock' });
    const carryEl = h('div', { class: 'tv-carry' }); const nearEl = h('div', { class: 'tv-near' });
    const useBtn = h('button', { class: 'tv-use lounge-ctl', 'data-action': 'use' }); const dropBtn = h('button', { class: 'tv-drop lounge-ctl', 'data-action': 'drop', text: '버리기' });
    const actEl = h('div', { class: 'tv-act' }, dropBtn, useBtn);
    const noteEl = h('div', { class: 'tv-note' }); const introEl = h('div', { class: 'tv-intro' });
    const stkEl = h('div', { class: 'tv-stk' }, h('i'), h('b', { text: '이동' }));
    layer.append(plaque, purse, stock, carryEl, nearEl, stkEl, actEl, noteEl, introEl);
    const panelEl = h('div', { class: 'tv-panel' }); wrap.append(panelEl);
    const foldBtn = h('button', { class: 'tv-fold', 'data-action': 'panel' }); wrap.append(foldBtn);
    let tipEl = null;
    let noteT = 0;
    function note(t, kind) { if (!t) return; noteEl.textContent = t; noteEl.className = 'tv-note ' + (kind || ''); noteEl.style.opacity = '1'; noteT = 1.5; }
    const sfxGate = {};
    function sfx(name, vol) { const now = performance.now(); if (sfxGate[name] && now - sfxGate[name] < 80) return; sfxGate[name] = now; try { api.sfx(name, { vol: vol == null ? 1 : vol }); } catch (e) {} }
    const icoD = (code, sz) => (code < 11 ? T.ico.drink(T.DRINK[code - 1].id, sz || 22) : T.ico.dish(T.DISH[code - 11].id, sz || 22));
    const icoM = (k, sz) => T.ico.misc(k, sz, k === 'dirty' || k === 'plate' ? T.IC.dish('#7a6a58') : k === 'mug' ? T.IC.mug('#8a6240') : k === 'coin' ? '<circle cx="28" cy="28" r="18" fill="#cfd3d6" stroke="#6f7478" stroke-width="4"/>' : k === 'fame' ? T.IC.star('#e3ae45') : k === 'mop' ? '<path d="M12 40q4 -16 16 -14t16 14q-16 6 -32 0z" fill="#9aa4a8"/>' : '');
    const esc = (t) => String(t).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
    const setHTML = (e, html) => { if (e._h !== html) { e._h = html; e.innerHTML = html; e._w0 = 0; return true; } return false; };
    const setCls = (e, c) => { if (e.className !== c) e.className = c; };

    /* ----- 상태 ----- */
    let st = null, W = null, wkey = '', dead = false, raf = 0, last = 0, acc = 0, paused = false, ready = false, warming = false;
    let phSeq = -1, phT = 0, sentSeq = -1, planQ = null, planT = 0;
    let tab = 'market', ntab = 'sum', folded = false, panelDirty = true;
    let tagsDirty = true;
    const isHost = () => !api.online || api.isHost;
    const testBot = () => !!(L.debug && (L.debug.autoplay || (L.debug.noTut && api.online)));
    const mySeat = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const humanHere = (s) => { const p = api.players[s]; return !!p && !p.ai && (!api.online || !!p.local) && !testBot(); };
    const isBot = (s) => { const p = api.players[s]; return !p || !!p.ai || testBot(); };
    const remoteHuman = (s) => { const p = api.players[s]; return api.online && !!p && !p.ai && !p.local; };
    const nm = (s) => String((api.players[s] && api.players[s].name) || (st && st.nm && st.nm[s]) || (s + 1) + '번').slice(0, 10);
    const habs = {};
    const habOf = (s) => habs[s] || (habs[s] = T.habitsOf(st ? st.rid : 1, s));
    const lvOfSeat = (s) => (api.players[s] && api.players[s].ai ? api.players[s].lv || 2 : 2);
    const netKey = () => (st ? 't' + st.rid + '_' + st.day + '_' + st.ph : 't0');

    /* ======================= 입력 ======================= */
    const offs = [];
    let useEdge = 0, dropEdge = 0, goReq = null;
    offs.push(api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'use') useEdge = 1;
      else if (id === 'drop') dropEdge = 1;
      else if (id === 'panel') { if (st && (st.ph === 'morn' || st.ph === 'night')) { folded = !folded; panelDirty = true; layout(); } }
    }));
    const press = (el, fn, fnUp) => { el.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); el.classList.add('on'); fn(); }); const up = () => { el.classList.remove('on'); if (fnUp) fnUp(); }; el.addEventListener('pointerup', up); el.addEventListener('pointerleave', up); el.addEventListener('pointercancel', up); };
    let btnHeld = false, holdK = '';
    press(useBtn, () => { useEdge = 1; btnHeld = true; }, () => { btnHeld = false; });
    press(dropBtn, () => { dropEdge = 1; });
    foldBtn.addEventListener('click', (e) => { e.stopPropagation(); folded = !folded; panelDirty = true; layout(); });
    const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), hit = new THREE.Vector3();
    let downP = null;
    function floorAt(cx, cy) {
      const r = R.domElement.getBoundingClientRect();
      ndc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
      ray.setFromCamera(ndc, cam);
      return ray.ray.intersectPlane(plane, hit) ? hit.clone() : null;
    }
    function targetAt(p) {
      if (!Lay || !W) return null;
      let best = null, bd = 0.55;
      for (const id of S.allTargets(W)) {
        const t = S.targetPos(W, id); if (!t) continue;
        let d = S.edgeDist(t, p.x, p.z);
        if (id[0] === 't') d -= 0.45;
        if (id[0] === 's') d -= 0.2;
        if (d < bd) { bd = d; best = id; }
      }
      // 손님을 누르면 그 식탁
      if (!best) for (const g of W.g) { if (g.st < 1 || g.st > 3 || g.seat < 0) continue; if (Math.hypot((g.rx != null ? g.rx : g.x) - p.x, (g.rz != null ? g.rz : g.z) - p.z) < 0.5) { best = 't' + W.Lay.seats[g.seat].tb; break; } }
      return best;
    }
    R.domElement.addEventListener('pointerdown', (e) => {
      if (stickStart(e)) { e.preventDefault(); return; }
      downP = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId, touch: e.pointerType !== 'mouse' };
    });
    R.domElement.addEventListener('pointerup', (e) => {
      if (stickEnd(e)) return;
      if (!downP || downP.id !== e.pointerId) return;
      const downP0 = downP, moved = Math.hypot(e.clientX - downP.x, e.clientY - downP.y), dt = performance.now() - downP.t; downP = null;
      if (moved > 14 || dt > 650 || !st) return;
      const p = floorAt(e.clientX, e.clientY); if (!p) return;
      if (st.ph === 'svc' && W && mySeat() >= 0 && humanHere(mySeat())) {
        if (downP0.touch && moveMode() === 'stick') return;   // 막대 방식: 손가락 눌러서 걷기는 끔(마우스 클릭은 그대로)
        const id = targetAt(p);
        goReq = { id, x: clamp(p.x, 0.3, S.WX - 0.3), z: clamp(p.z, 0.3, S.WZ - 0.3) };
        markAt = [id ? (S.targetPos(W, id) || p).x : p.x, id ? (S.targetPos(W, id) || p).z : p.z, 0.8];
      } else if (st.ph === 'morn') {
        let t2 = null;
        if (p.x < -0.5) t2 = 'yard'; else if (p.z < 1.6 && p.x > 6 && p.x < 13.5) t2 = 'brew'; else if (p.x < 5 && p.z < 6.5) t2 = 'kitchen'; else if (p.x > 15 && p.z > 6.5) t2 = 'market';
        if (t2 && t2 !== tab) { tab = t2; folded = false; panelDirty = true; layout(); sfx('click', 0.5); }
      }
    });
    let markAt = null;
    /* 휴대폰 이동 막대(기본) — 누른 자리에 생기는 떠다니는 막대. 이 기기 설정(tavern.move: stick | tap) */
    const moveMode = () => (T.store.get('move', 'stick') === 'tap' ? 'tap' : 'stick');
    const ctlK = () => { try { return clamp((L.ui && L.ui.ctlScale && L.ui.ctlScale()) || 1, 0.7, 1.5); } catch (e) { return 1; } };
    let stk = null, stkV = { x: 0, z: 0 }, sawTouch = touch;
    const stickOn = () => moveMode() === 'stick' && !!st && st.ph === 'svc' && !!W && mySeat() >= 0 && humanHere(mySeat());
    function inStickZone(cx, cy) {
      const r = R.domElement.getBoundingClientRect(), x = cx - r.left, y = cy - r.top;
      return vw >= vh * 1.05 ? x < vw * 0.5 && y > vh * 0.25 : x < vw * 0.62 && y > vh * 0.45;
    }
    function stickStart(e) {
      if (e.pointerType === 'mouse' || stk || !stickOn() || !inStickZone(e.clientX, e.clientY)) return false;
      const r = R.domElement.getBoundingClientRect();
      stk = { id: e.pointerId, ox: e.clientX - r.left, oy: e.clientY - r.top, R: 60 * ctlK() };
      try { R.domElement.setPointerCapture(e.pointerId); } catch (er) {}
      stickMove(e);
      return true;
    }
    function stickMove(e) {
      if (!stk || e.pointerId !== stk.id) return;
      const r = R.domElement.getBoundingClientRect(), Rr = stk.R;
      let dx = e.clientX - r.left - stk.ox, dy = e.clientY - r.top - stk.oy, d = Math.hypot(dx, dy);
      // 손가락이 막대 밖으로 나가면 바탕이 따라감(방향을 바꿀 때 바로 반응)
      if (d > Rr) { const k = (d - Rr) / d; stk.ox += dx * k; stk.oy += dy * k; dx -= dx * k; dy -= dy * k; d = Rr; }
      stk.kx = dx; stk.ky = dy;
      const dead = Rr * 0.1, full = Rr * 0.72;
      if (d <= dead) { stkV.x = 0; stkV.z = 0; return; }
      const m = 0.2 + 0.8 * clamp((d - dead) / (full - dead), 0, 1);
      stkV.x = dx / d * m; stkV.z = dy / d * m;   // 화면 오른쪽 = +x, 화면 아래 = +z(카메라가 돌지 않음)
    }
    function stickEnd(e) {
      if (!stk || (e && e.pointerId !== stk.id)) return false;
      try { R.domElement.releasePointerCapture(stk.id); } catch (er) {}
      stk = null; stkV.x = 0; stkV.z = 0;
      return true;
    }
    function stickDraw() {
      const show = stickOn() && (sawTouch || !!stk);
      if (wrap.classList.contains('stick') !== (moveMode() === 'stick' && sawTouch)) wrap.classList.toggle('stick');
      if (!show) { stkEl.style.display = 'none'; return; }
      const Rr = stk ? stk.R : 60 * ctlK(), D = Rr * 2;
      const cx = stk ? stk.ox : 24 + Rr, cy = stk ? stk.oy : vh - 30 - Rr;
      stkEl.style.display = 'block'; stkEl.className = 'tv-stk' + (stk ? ' on' : '');
      stkEl.style.width = stkEl.style.height = D + 'px';
      stkEl.style.transform = 'translate(' + Math.round(cx - Rr) + 'px,' + Math.round(cy - Rr) + 'px)';
      stkEl.firstChild.style.transform = stk ? 'translate(' + Math.round(stk.kx || 0) + 'px,' + Math.round(stk.ky || 0) + 'px)' : '';
    }
    R.domElement.addEventListener('pointermove', stickMove);
    R.domElement.addEventListener('pointercancel', stickEnd);
    R.domElement.addEventListener('lostpointercapture', stickEnd);
    function moveAxis() {
      let mx = api.input.axis('left', 'right') + stkV.x, mz = -api.input.axis('down', 'up') + stkV.z;
      const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; }
      return { mx, mz };
    }
    function readInput() {
      const ax = moveAxis(), ix = ax.mx, iz = ax.mz;
      // 조작감: 일하는 중(따르기 · 담기 등)에 누른 걸음 · 쓰기는 버리지 않고 끝나면 이어서 함
      const c = W && W.ch ? W.ch.find((q) => q.s === mySeat()) : null, wait = !!(c && c.busy);
      let use = wait ? 0 : useEdge;
      if (c && !wait) {
        // 쓰기를 누르고 있으면 같은 자리 · 같은 일을 이어서 함(잔 둘 따르기, 한 식탁에 둘 내주기). 화덕에 올리기는 한 번씩만. 방장 · 혼자 할 때만(손님 기기는 응답이 늦어 겹쳐 보낼 수 있음)
        let held = btnHeld; try { held = held || !!api.input.held('use'); } catch (e) {}
        if (!held) holdK = '';
        if (use || (held && holdK)) {
          const nb = S.nearest(W, c), k = nb && !nb.o.no ? nb.id + '|' + nb.o.op + '|' + (nb.o.op === 'serve' ? 0 : nb.o.code || 0) : '';
          if (use) {
            holdK = k && nb.o.op !== 'cook' && isHost() ? k : '';
            // 눌렀는데 아무 일도 안 될 때는 까닭을 알림
            if (!nb) note('가까이에 쓸 것 없음');
            else if (nb.o.no && nb.o.no !== '할 일 없음') { note(nb.o.lbl + ' · ' + nb.o.no, 'bad'); sfx('warn', 0.3); }
          } else if (k && k === holdK) use = 1;
          else holdK = '';
        }
      }
      const o = { mx: ix, mz: iz, use, drop: wait ? 0 : dropEdge, go: wait ? null : goReq };
      if (!wait) { useEdge = 0; dropEdge = 0; goReq = null; }
      return o;
    }

    /* ======================= 관리 요청 ======================= */
    let mSeq = 0, pendM = [], lastM = {}, lastU = {}, errOut = {}, uSeq = 0, pendU = [];
    function applyReq(s0, seat, a) {
      let s = JSON.parse(JSON.stringify(s0));
      if (a.k === 'auto') {
        const lv = Math.max(2, ...api.players.map((p, i) => (p.ai ? p.lv || 2 : 0)));
        for (const x of T.plan(s, lv, Math.random, habOf(0))) { try { T.mg(s, seat, x); } catch (e) {} }
      } else if (a.k === 'bb' || a.k === 'bp') {
        const D = a.k === 'bb' ? T.DR[a.r] : T.DS[a.r]; if (!D) throw new Error('없는 항목');
        if (s.lab < 1) throw new Error('일손이 모자람');
        for (const it in D.need) { const lack = D.need[it] - (s.inv[it] || 0); if (lack > 0) T.mg(s, seat, { k: 'buy', it, n: lack }); }
        T.mg(s, seat, a.k === 'bb' ? { k: 'brew', i: a.i, r: a.r } : { k: 'prep', r: a.r });
      } else if (a.k === 'bm') {
        const n = Math.min(T.kilnCap(s) - s.kiln, a.n || 8); if (n <= 0) throw new Error('건조대가 가득 참');
        const lack = n - (s.inv.barley || 0); if (lack > 0) T.mg(s, seat, { k: 'buy', it: 'barley', n: lack });
        T.mg(s, seat, { k: 'malt', n });
      } else T.mg(s, seat, a);
      s.seq++;
      return s;
    }
    function doMg(a) {
      if (!st) return;
      const me = Math.max(0, mySeat());
      if (isHost()) {
        try { const ns = applyReq(st, me, a); api.setState(ns); sfx(a.k === 'rdy' ? 'turn' : a.k === 'buy' ? 'chip' : 'click', 0.6); }
        catch (e) { note(e.message, 'bad'); sfx('warn', 0.5); }
      } else { pendM.push([++mSeq, a]); pubT = 0; sfx('click', 0.5); }
    }

    /* ======================= 관리 창 그리기 ======================= */
    const ingIco = (k, sz) => T.ico.ing(k, sz || 26);
    const fmtNeed = (need, s) => Object.keys(need).map((k) => { const lack = (s.inv[k] || 0) < need[k]; return (lack ? '<span class="bad">' : '') + T.ING[k].nm + ' ' + need[k] + (lack ? '</span>' : ''); }).join(' · ');
    const btn = (txt, on, cls, dis, title) => { const b = h('button', { class: 'tv-b ' + (cls || ''), title: title || '' }); b.innerHTML = txt; b.disabled = !!dis; b.addEventListener('click', (e) => { e.stopPropagation(); on(); }); return b; };
    const row = (ico, nmHtml, right) => { const r = h('div', { class: 'tv-row' }); if (ico) { const i = h('span'); i.innerHTML = ico; r.append(i); } const n = h('div', { class: 'nm' }); n.innerHTML = nmHtml; r.append(n); for (const x of right) if (x) r.append(x); return r; };
    function lvBar(s) { const lv = T.lvOf(s.xp), a = T.LEVELS[lv - 1].xp, b = T.LEVELS[lv] ? T.LEVELS[lv].xp : a + 1; return { lv, f: T.LEVELS[lv] ? clamp((s.xp - a) / (b - a), 0, 1) : 1, nm: T.LEVELS[lv - 1].nm, next: T.LEVELS[lv] ? b - s.xp : 0 }; }
    function drawPanel() {
      panelDirty = false;
      if (!st || (st.ph !== 'morn' && st.ph !== 'night')) { panelEl.style.display = 'none'; foldBtn.style.display = 'none'; return; }
      foldBtn.style.display = '';
      foldBtn.textContent = folded ? (st.ph === 'morn' ? '아침 준비 창' : '밤 결산 창') : '창 접기';
      if (folded) { panelEl.style.display = 'none'; return; }
      panelEl.style.display = 'flex';
      const scrollY = panelEl.querySelector('.tv-body') ? panelEl.querySelector('.tv-body').scrollTop : 0;
      panelEl.innerHTML = '';
      const s = st, lb = lvBar(s), S0 = T.SEASONS[T.ssnOf(s)], me = mySeat(), canAct = me >= 0 || isHost();
      const head = h('div', { class: 'tv-head' });
      const t = h('h3'); t.innerHTML = s.day + '일째 ' + (s.ph === 'morn' ? '아침' : '밤') + ' <small>' + S0.nm + ' · ' + s.day + '/' + s.days + '일 · ' + lb.nm + '</small>';
      head.append(t);
      const ev = s.ph === 'morn' ? s.ev : s.evN;
      if (ev && T.EV[ev]) head.append(h('div', { class: 'tv-ev', text: (s.ph === 'morn' ? '오늘 · ' : '내일 · ') + T.EV[ev].nm + ' — ' + T.EV[ev].d }));
      const chips = h('div', { class: 'tv-chips' });
      const chip = (a, b) => { const c = h('span', { class: 'tv-chip' }); c.innerHTML = a + ' <b>' + b + '</b>'; chips.append(c); };
      chip('은화', s.money);
      if (s.ph === 'morn') { chip('일손', s.lab + '/' + T.labMax(s)); chip('청결', s.clean); chip('예상 손님', '약 ' + T.expGuests(s)); }
      chip('명성 ' + lb.lv + '단계', s.xp + (lb.next ? '/' + T.LEVELS[lb.lv].xp : ''));
      const hrow = h('div', { class: 'tv-headrow' }); hrow.append(chips);
      if (s.ph === 'morn' && s.clean < 100) hrow.append(btn('청소<br><small>일손 2</small>', () => doMg({ k: 'clean' }), '', !canAct || s.lab < 2, '청결을 100으로'));
      head.append(hrow);
      panelEl.append(head);
      const tabs = h('div', { class: 'tv-tabs' });
      const TABS = s.ph === 'morn' ? [['market', '장터'], ['brew', '양조'], ['kitchen', '주방'], ['yard', '텃밭'], ['log', '장부']] : [['sum', '결산'], ['up', '확장'], ['deco', '꾸미기'], ['staff', '일꾼']];
      const cur = s.ph === 'morn' ? tab : ntab;
      for (const [k, label] of TABS) { const b = h('button', { class: 'tv-tab' + (k === cur ? ' on' : ''), text: label }); b.addEventListener('click', (e) => { e.stopPropagation(); if (s.ph === 'morn') tab = k; else ntab = k; panelDirty = true; sfx('click', 0.4); }); tabs.append(b); }
      panelEl.append(tabs);
      const body = h('div', { class: 'tv-body' });
      panelEl.append(body);
      const dis = !canAct;
      if (s.ph === 'morn') {
        if (cur === 'market') {
          body.append(h('div', { class: 'tv-log', text: '장보기는 일손이 들지 않음. 값은 계절 · 사건에 따라 바뀜.' }));
          for (const k of T.ING_IDS) {
            const p = T.price(s, k), b0 = T.ING[k].p;
            body.append(row(ingIco(k), T.ING[k].nm + ' <small>한 개 ' + p + (p < b0 ? ' (쌈)' : p > b0 ? ' (비쌈)' : '') + '</small>', [h('span', { class: 'num', text: String(s.inv[k] || 0) }), btn('+1', () => doMg({ k: 'buy', it: k, n: 1 }), '', dis || s.money < p), btn('+5', () => doMg({ k: 'buy', it: k, n: 5 }), '', dis || s.money < p * 5)]));
          }
        } else if (cur === 'brew') {
          body.append(h('div', { class: 'tv-log', text: '빈 통에 담그면 정한 날 수 뒤 완성. 다 익은 뒤 이틀마다 품질 +1(최대 +2).' }));
          s.ck.forEach((c, i) => {
            const card = h('div', { class: 'tv-card' });
            if (c) {
              const D = T.DR[c.r], rd = T.cReady(c), q = T.cQ(s, c);
              const hd = h('h4'); hd.innerHTML = T.ico.drink(D.id, 26) + (i + 1) + '번 통 · ' + D.nm + '<span>' + (rd ? '다 익음 · 품질 ' + q + ' · ' + c.sv + '잔' : '발효 ' + c.d + '/' + D.days + '일') + '</span>';
              card.append(hd);
              card.append(btn('통 비우기', () => doMg({ k: 'dump', i }), '', dis, '남은 술을 버리고 빈 통으로'));
            } else {
              const hd = h('h4'); hd.innerHTML = (i + 1) + '번 통 · 빈 통<span>담글 술 고르기 · 일손 1</span>'; card.append(hd);
              const grid = h('div', { class: 'tv-grid' });
              for (const D of T.unlockedD(s)) {
                const ok = T.hasNeed(s, D.need), cost = T.needCost(s, D.need);
                const b = btn(T.ico.drink(D.id, 22) + D.nm + ' · ' + D.days + '일<small>' + fmtNeed(D.need, s) + (ok ? '' : ' · 사서 담그기 ' + cost) + '</small>', () => doMg(ok ? { k: 'brew', i, r: D.id } : { k: 'bb', i, r: D.id }), ok ? 'p' : '', dis || s.lab < 1 || (!ok && s.money < cost));
                grid.append(b);
              }
              card.append(grid);
            }
            body.append(card);
          });
          const mk = h('div', { class: 'tv-card' });
          const hd = h('h4'); hd.innerHTML = T.ico.ing('malt', 26) + '맥아 건조대<span>' + (s.kiln ? '보리 ' + s.kiln + ' 말리는 중 · 내일 맥아' : '비어 있음') + ' · ' + s.kiln + '/' + T.kilnCap(s) + '</span>';
          mk.append(hd);
          const rowb = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } });
          rowb.append(btn('가진 보리 말리기 (' + Math.min(s.inv.barley || 0, T.kilnCap(s) - s.kiln) + ')', () => doMg({ k: 'malt' }), '', dis || !(s.inv.barley > 0) || s.kiln >= T.kilnCap(s) || s.lab < 1));
          const n8 = Math.min(8, T.kilnCap(s) - s.kiln), lack = Math.max(0, n8 - (s.inv.barley || 0));
          rowb.append(btn('보리 사서 ' + n8 + ' 말리기' + (lack ? ' (' + lack * T.price(s, 'barley') + ')' : ''), () => doMg({ k: 'bm', n: n8 }), '', dis || n8 <= 0 || s.lab < 1 || s.money < lack * T.price(s, 'barley')));
          mk.append(rowb); mk.append(h('div', { class: 'tv-log', text: '맥아 ' + (s.inv.malt || 0) + ' · 보리 ' + (s.inv.barley || 0) + ' 가지고 있음. 장터 맥아는 한 개 ' + T.price(s, 'malt') + '.' }));
          body.append(mk);
        } else if (cur === 'kitchen') {
          body.append(h('div', { class: 'tv-log', text: '밑준비 한 번 = 일손 1. 남은 몫은 내일까지, 이틀 지나면 버림. 화덕 요리는 영업 중에 구워 냄.' }));
          for (const D of T.unlockedF(s)) {
            const a = s.dish[D.id] || [0, 0], ok = T.hasNeed(s, D.need), cost = T.needCost(s, D.need);
            const where = { pot: '솥', board: '찬장', oven: '화덕 ' + D.ck + '초' }[D.st];
            body.append(row(T.ico.dish(D.id, 30), D.nm + ' <small>' + where + ' · ' + D.n + '인분 · 한 접시 ' + D.p + ' · ' + fmtNeed(D.need, s) + '</small>', [h('span', { class: 'num', text: (a[0] + a[1]) + (a[1] ? '(' + a[1] + ')' : '') }), btn(ok ? '밑준비' : '사서 준비<br><small>' + cost + '</small>', () => doMg(ok ? { k: 'prep', r: D.id } : { k: 'bp', r: D.id }), ok ? 'p' : '', dis || s.lab < 1 || (!ok && s.money < cost))]));
          }
          const lock = T.DISH.filter((d) => d.rep > lb.lv);
          if (lock.length) body.append(h('div', { class: 'tv-log', style: { marginTop: '6px', opacity: '.6' }, text: '명성이 오르면: ' + lock.map((d) => d.nm + '(' + d.rep + '단계)').join(' · ') }));
        } else if (cur === 'yard') {
          const S1 = T.SEASONS[T.ssnOf(s)];
          body.append(h('div', { class: 'tv-log', text: S1.grow > 0 ? '씨 뿌리기 = 일손 1 · 씨값. 거두기는 일손이 들지 않음. ' + S1.nm + ' 자람 ×' + S1.grow : '겨울에는 씨를 뿌릴 수 없고 자라던 작물도 멈춤.' }));
          s.plots.forEach((p, i) => {
            const card = h('div', { class: 'tv-card' });
            if (p) {
              const C = T.CR[p.c], done = p.g >= C.days;
              const hd = h('h4'); hd.innerHTML = T.ico.ing(C.id, 26) + (i + 1) + '번 이랑 · ' + C.nm + '<span>' + (done ? '거둘 때 · ' + C.y : Math.floor(p.g * 10) / 10 + '/' + C.days + '일') + '</span>';
              card.append(hd);
              if (done) card.append(btn('거두기 (+' + C.y + ')', () => doMg({ k: 'harvest', i }), 'p', dis));
            } else {
              const hd = h('h4'); hd.innerHTML = (i + 1) + '번 이랑 · 비어 있음'; card.append(hd);
              if (S1.grow > 0) { const grid = h('div', { class: 'tv-grid' }); for (const C of T.CROP) grid.append(btn(T.ico.ing(C.id, 22) + C.nm + ' · 씨 ' + C.seed + '<small>' + Math.ceil(C.days / S1.grow) + '일 · ' + C.y + ' 거둠</small>', () => doMg({ k: 'plant', i, c: C.id }), '', dis || s.lab < 1 || s.money < C.seed)); card.append(grid); }
            }
            body.append(card);
          });
        } else if (cur === 'log') {
          const lg = h('div', { class: 'tv-log' }); lg.innerHTML = s.log.slice().reverse().map((x) => '· ' + x).join('<br>'); body.append(lg);
          const inv = h('div', { class: 'tv-card' }); inv.innerHTML = '<h4>창고</h4><div class="tv-inv">' + (T.ING_IDS.filter((k) => s.inv[k]).map((k) => '<span>' + T.ico.ing(k, 22) + T.ING[k].nm + ' <b>' + s.inv[k] + '</b></span>').join('') || '비어 있음') + '</div>';
          body.append(inv);
          if (sawTouch) {
            const mv = h('div', { class: 'tv-card' }); mv.append(h('h4', { text: '휴대폰 이동 · 이 기기' }));
            const rw = h('div', { style: { display: 'flex', gap: '6px' } });
            for (const [k, lbl] of T.MOVES) rw.append(btn(lbl, () => { T.store.set('move', k); panelDirty = true; sfx('click', 0.4); }, 'w' + (moveMode() === k ? ' p' : '')));
            mv.append(rw); body.append(mv);
          }
        }
      } else {
        const r = s.rpt;
        if (cur === 'sum' && r) {
          const tbl = h('table', { class: 'tv-sum' });
          const tr = (a, b, cls) => { const x = h('tr', { class: cls || '' }); x.append(h('td', { text: a }), h('td', { text: String(b) })); tbl.append(x); };
          tr('영업 매출', r.inc); tr('팁', r.tip); tr('방값 · 객실 ' + r.rooms + '/' + r.beds + ' (찾은 손님 ' + r.req + ')', r.room);
          tr('일꾼 품삯', -r.wages); tr('땔감 · 초 · 유지비', -r.upkeep); if (r.repair) tr('부서진 의자 수리', -r.repair); if (r.fee) tr('음유시인 사례', -r.fee);
          tr('순이익', (r.net >= 0 ? '+' : '') + r.net, 't');
          body.append(tbl);
          const c2 = h('div', { class: 'tv-card' });
          c2.innerHTML = '<h4>손님</h4>받은 손님 ' + r.served + '명 · 놓친 손님 ' + r.lost + '명 · 화나서 떠난 손님 ' + r.angry + '명' + (r.brawl ? ' · 싸움 ' + r.brawl + '번' : '') + '<br>흡족함 ' + Math.round(r.sat * 100) + '% · 명성 ' + (r.xp >= 0 ? '+' : '') + r.xp + (r.up ? ' · 명성 ' + r.up + '단계 「' + T.LEVELS[r.up - 1].nm + '」' : '') + (r.top ? '<br>오늘 가장 많이 온 손님 · ' + T.GU[r.top].nm : '');
          body.append(c2);
          if (s.day >= s.days) body.append(h('div', { class: 'tv-card', text: '마지막 밤. 「영업 마감」을 누르면 최종 평가.' }));
        } else if (cur === 'up') {
          for (const U of T.UPG) {
            const l = T.upLv(s, U.id), nx = U.lv[l];
            const desc = nx ? (nx.d || U.d || '') : '끝까지 들임';
            const locked = nx && (nx.rep || 1) > lb.lv;
            body.append(row(T.svgW(T.IC.tool('#8a6a44'), 22), U.nm + (U.lv.length > 1 ? ' ' + l + '/' + U.lv.length : '') + ' <small>' + desc + (locked ? ' · 명성 ' + nx.rep + '단계부터' : '') + '</small>', [nx ? btn('들이기<br><small>' + nx.p + '</small>', () => doMg({ k: 'up', id: U.id }), 'p', dis || locked || s.money < nx.p) : null]));
          }
        } else if (cur === 'deco') {
          body.append(h('div', { class: 'tv-log', text: '편안함 ' + T.comfort(s) + ' · 분위기 ' + T.ambience(s, 'x') + '. 편안함은 기다림 · 방값 · 팁을, 분위기는 손님 수 · 팁을 올림.' }));
          for (const D of T.DECO) {
            const own = s.deco.includes(D.id), locked = D.rep > lb.lv;
            body.append(row(T.svgW(T.IC.deco(own ? '#e3ae45' : '#8a7a5a'), 22), D.nm + ' <small>' + (D.c ? '편안함 +' + D.c + ' ' : '') + (D.a ? '분위기 +' + D.a : '') + ' · ' + D.d + (locked ? ' · 명성 ' + D.rep + '단계부터' : '') + '</small>', [own ? h('span', { class: 'num', text: '들임' }) : btn('들이기<br><small>' + D.p + '</small>', () => doMg({ k: 'deco', id: D.id }), 'p', dis || locked || s.money < D.p)]));
          }
        } else if (cur === 'staff') {
          body.append(h('div', { class: 'tv-log', text: '일꾼은 영업 중에 정해진 일만 함. 밤마다 품삯. 아침 일손도 한 사람 몫씩 늘어남.' }));
          for (const F of T.STAFF) {
            const own = s.staff.includes(F.id), locked = F.rep > lb.lv;
            body.append(row(T.svgW(T.IC.staff('#5a4a36'), 22), F.nm + ' <small>하루 품삯 ' + F.wage + ' · ' + F.d + (locked ? ' · 명성 ' + F.rep + '단계부터' : '') + '</small>', [own ? btn('내보내기', () => doMg({ k: 'fire', id: F.id }), '', dis) : btn('고용', () => doMg({ k: 'hire', id: F.id }), 'p', dis || locked)]));
          }
        }
      }
      // 아래: 준비
      const foot = h('div', { class: 'tv-foot' });
      const hum = []; for (let i = 0; i < s.n; i++) if (!isBot(i)) hum.push(i);
      if (hum.length > 1 || (api.online && hum.length)) { const rd = h('div', { class: 'tv-ready' }); for (const i of hum) rd.append(h('span', { class: s.rdy[i] ? 'k' : '', text: nm(i) + (s.rdy[i] ? ' 준비' : ' …') })); foot.append(rd); }
      const mine = me >= 0 ? s.rdy[me] : 0;
      foot.append(btn('맡기기', () => doMg({ k: 'auto' }), 'w', dis, s.ph === 'morn' ? '오늘 준비를 AI가 대신 짜 줌' : '확장 · 꾸미기 · 일꾼을 AI가 골라 줌'));
      const goLbl = s.ph === 'morn' ? '영업 시작' : s.day >= s.days ? '영업 마감' : '다음 날로';
      foot.append(btn(mine ? '준비 취소' : goLbl, () => doMg({ k: 'rdy', on: mine ? 0 : 1 }), mine ? 'w' : 'p w', me < 0 && !isHost()));
      if (isHost() && hum.length > 1 && hum.some((i) => !s.rdy[i]) && hum.some((i) => s.rdy[i])) foot.append(btn('지금 시작', () => { const ns = JSON.parse(JSON.stringify(st)); ns.rdy = ns.rdy.map(() => 1); ns.seq++; api.setState(ns); }, '', false, '준비하지 않은 자리를 기다리지 않음'));
      panelEl.append(foot);
      const nb = panelEl.querySelector('.tv-body'); if (nb) nb.scrollTop = scrollY;
    }

    /* ======================= HUD ======================= */
    let hudT = 0, nearO = null;
    const hhmm = (t) => { const m = 17 * 60 + Math.floor(t / S.DUR * 7 * 60); return String(Math.floor(m / 60) % 24).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0'); };
    const OPING = { pour: '따르는 중', plate: '담는 중', cook: '올리는 중', take: '꺼내는 중', dump: '넣는 중', wash: '씻는 중', serve: '내주는 중', calm: '달래는 중', clear: '치우는 중', mop: '닦는 중', drop: '버리는 중' };
    const opIco = (o) => (o.code ? icoD(o.code, 28) : o.op === 'clear' || o.op === 'dump' || o.op === 'wash' ? icoM('dirty', 28) : o.op === 'mop' ? icoM('mop', 28) : '');
    /* 다음에 할 일 한 줄(사람 자리): 든 것을 기다리는 손님 → 빈 그릇 → 다 된 화덕 → 가장 급한 주문 → 치우기 · 설거지 */
    function nextHint(c) {
      const carry = c.carry.filter((it) => it.c !== 99).map((it) => it.c);
      const waiting = W.g.filter((g) => g.st === 2 && g.seat >= 0);
      for (const code of carry) if (waiting.some((g) => g.want.includes(code))) return S.codeNm(code) + ' · 주문한 손님 식탁으로';
      if (c.carry.some((it) => it.c === 99)) return '빈 그릇 · 설거지통으로';
      if (c.carry.length >= W.cap) return '';
      if (W.ov.some((o) => o && o.t >= o.T)) return '화덕 요리 다 됨 · 꺼내기';
      const onWay = (code) => { let n = 0; for (const q of W.ch) for (const it of q.carry) if (it.c === code) n++; for (const q of W.np) for (const it of q.carry) if (it.c === code) n++; if (code >= 11) for (const o of W.ov) if (o && 11 + T.DS[o.r].i === code) n++; return n; };
      let best = 0, bf = 9;
      for (const g of waiting) for (const code of g.want) { const f = g.pat / g.pat0; if (f < bf && S.stockOf(W, code) > 0 && S.pending(W, code) > onWay(code)) { bf = f; best = code; } }
      if (best) {
        if (best < 11) return W.mug > 0 ? S.codeNm(best) + ' 주문 · 술통에서 따르기' : '깨끗한 잔 없음 · 설거지통에서 씻기';
        if (W.plate <= 0) return '깨끗한 접시 없음 · 설거지통에서 씻기';
        const D = T.DISH[best - 11];
        return D.nm + ' 주문 · ' + (D.st === 'pot' ? '솥에서 담기' : D.st === 'board' ? '찬장에서 담기' : '화덕에 굽기');
      }
      if (W.Lay.tbs.some((tb) => tb.dm + tb.dp > 0)) return '빈 그릇 치우기 · 접시 표시가 뜬 식탁';
      if (W.sp.length) return '쏟은 술 닦기';
      if (W.tub.m + W.tub.p > 0) return '설거지통 · 쌓인 그릇 씻기';
      return '';
    }
    function hudTick() {
      if (!st) return;
      const svc = st.ph === 'svc' && W;
      const lb = lvBar(st);
      setHTML(plaque, '<b>' + st.day + '일째 · ' + T.SEASONS[T.ssnOf(st)].nm + '</b><span>' + (svc ? hhmm(Math.min(W.t, S.DUR)) + (W.t > S.DUR * S.LAST_CALL ? ' · 마지막 주문' : ' · 저녁 영업') : T.PH_NM[st.ph]) + '</span>' + (svc ? '<i><s style="width:' + Math.round(clamp(W.t / S.DUR, 0, 1) * 100) + '%"></s></i>' : ''));
      purse.style.display = panelInfo() ? 'none' : '';
      const gain = svc ? W.inc + W.tip : 0;
      setHTML(purse, '<div class="tv-pill">' + icoM('coin', 20) + '은화 <b>' + (st.money + gain) + '</b>' + (gain ? ' <em>+' + gain + '</em>' : '') + '</div><div class="tv-pill">' + icoM('fame', 20) + '명성 ' + lb.lv + ' <b>' + (svc ? Math.max(0, st.xp + Math.round(W.xp)) : st.xp) + '</b></div>');
      stock.style.display = svc ? '' : 'none';
      actEl.style.display = svc && mySeat() >= 0 && humanHere(mySeat()) ? '' : 'none';
      carryEl.style.display = actEl.style.display; nearEl.style.display = actEl.style.display;
      if (!svc) return;
      // 재고 + 기다리는 주문 수
      let html = '';
      const pend = {}; for (const g of W.g) if (g.st === 2) for (const code of g.want) pend[code] = (pend[code] || 0) + 1;
      const pb = (code) => (pend[code] ? '<u><i>주문 </i>' + pend[code] + '</u>' : '');
      const dr = {}; W.ck.forEach((c) => { if (c && c.rd) dr[c.r] = (dr[c.r] || 0) + c.sv; });
      for (const D of T.DRINK) if (dr[D.id] != null) html += '<div class="' + (dr[D.id] ? '' : 'z') + '">' + T.ico.drink(D.id, 22) + '<span class="n">' + D.nm + '</span>' + pb(1 + D.i) + '<b>' + dr[D.id] + '</b></div>';
      if (!html) html = '<div class="z w">꼭지 단 술 없음</div>';
      html += '<hr>';
      let any = 0; for (const D of T.DISH) { const n = W.dish[D.id] || 0, ck = W.ov.filter((o) => o && o.r === D.id).length; if (n || ck) { any = 1; html += '<div>' + T.ico.dish(D.id, 22) + '<span class="n">' + D.nm + '</span>' + pb(11 + D.i) + '<b>' + n + (ck ? '+' + ck : '') + '</b></div>'; } }
      if (!any) html += '<div class="z w">요리 없음</div>';
      html += '<hr><div class="' + (W.mug ? '' : 'z') + '">' + icoM('mug', 22) + '<span class="n">깨끗한 잔</span><b>' + W.mug + '</b></div><div class="' + (W.plate ? '' : 'z') + '">' + icoM('plate', 22) + '<span class="n">깨끗한 접시</span><b>' + W.plate + '</b></div>' + (W.tub.m + W.tub.p ? '<div>' + icoM('dirty', 22) + '<span class="n">설거지 쌓임</span><b>' + (W.tub.m + W.tub.p) + '</b></div>' : '');
      setHTML(stock, html);
      hudRects();
      // 든 것 · 가까운 것
      const me = mySeat(), c = me >= 0 ? W.ch[me] : null;
      if (c && humanHere(me)) {
        let ch = '<div class="tv-cl">든 것</div>';
        for (let i = 0; i < W.cap; i++) {
          const it = c.carry[i];
          ch += '<div class="tv-slot' + (it ? '' : ' e') + '">' + (it ? (it.c === 99 ? icoM('dirty', 36) + '<small>' + (it.m + it.p) + '</small>' : icoD(it.c, 36) + (it.c < 11 && it.q ? '<small>' + it.q + '</small>' : '')) : '') + '</div>';
        }
        setHTML(carryEl, ch);
        nearO = S.nearest(W, c);
        const on = useBtn.classList.contains('on') && btnHeld;
        if (c.busy) { setCls(useBtn, 'tv-use lounge-ctl on'); setHTML(useBtn, '<span>' + (OPING[c.busy.op] || '') + '</span>'); }
        else if (nearO) { setCls(useBtn, 'tv-use lounge-ctl' + (nearO.o.no ? ' off' : on ? ' on' : '')); setHTML(useBtn, (nearO.o.no ? '' : opIco(nearO.o)) + '<span>' + nearO.o.lbl + '</span>' + (nearO.o.no ? '<small>' + nearO.o.no + '</small>' : '')); }
        else { setCls(useBtn, 'tv-use lounge-ctl off'); setHTML(useBtn, '<span>쓰기</span><small>가까이 가기</small>'); }
        dropBtn.style.display = c.carry.some((it) => it.c !== 99) ? '' : 'none';
        const nt = c.path ? '걸어가는 중' : nextHint(c) || (nearO || stk ? '' : sawTouch ? (moveMode() === 'stick' ? '왼쪽 아래를 끌어 걷기' : '바닥 · 술통 · 식탁을 눌러 걸어가기') : 'WASD 걷기 · 클릭하면 걸어가서 쓰기');
        if (nearEl._t !== nt) { nearEl._t = nt; nearEl.textContent = nt; nearEl.style.visibility = nt ? '' : 'hidden'; }
      } else nearO = null;
    }

    /* ======================= 말풍선 · 표지(DOM) ======================= */
    const pool = { bub: [], tag: [], coin: [], aim: [], bdg: [] };
    const vtmp = new THREE.Vector3();
    function scr(x, y, z) { vtmp.set(x, y, z).project(cam); return [(vtmp.x + 1) / 2 * vw, (1 - vtmp.y) / 2 * vh, vtmp.z < 1]; }
    if (L.debug) L.debug.tavern = { W: () => W, scr: (x, y, z) => { const p = scr(x, y, z), r = R.domElement.getBoundingClientRect(); return [p[0] + r.left, p[1] + r.top, p[2]]; } };   // 시험 도구용
    function getEl(kind, i, cls) { let e = pool[kind][i]; if (!e) { e = h('div', { class: cls }); bubL.append(e); pool[kind][i] = e; } e.style.display = ''; return e; }
    function hideFrom(kind, n) { for (let i = n; i < pool[kind].length; i++) pool[kind][i].style.display = 'none'; }
    const coins = [];
    function ring(f) { const r = 9, c = TAU * r, col = f > 0.5 ? '#5f8a2e' : f > 0.25 ? '#c8902a' : '#b0402a'; return '<svg class="r" width="24" height="24" viewBox="0 0 24 24"><circle cx="12" cy="12" r="' + r + '" fill="none" stroke="rgba(0,0,0,.18)" stroke-width="4.5"/><circle cx="12" cy="12" r="' + r + '" fill="none" stroke="' + col + '" stroke-width="4.5" stroke-dasharray="' + (c * f).toFixed(1) + ' 99" transform="rotate(-90 12 12)"/></svg>'; }
    let domDt = 1 / 60;
    const put = (e, x, y) => { e.style.transform = 'translate(' + Math.round(x) + 'px,' + Math.round(y) + 'px) translate(-50%,-100%)'; };
    /* 표지 자리 잡기: 먼저 놓인 것([x, 아래 y, 폭, 높이])과 겹치면 그 위로 비켜 놓는다 */
    let hudR = [];
    function hudRects() {
      const r0 = wrap.getBoundingClientRect(); hudR = [];
      for (const el of [plaque, purse, stock, nearEl]) { if (el.style.display === 'none' || el.style.visibility === 'hidden') continue; const r = el.getBoundingClientRect(); if (r.width > 0) hudR.push([r.left - r0.left, r.top - r0.top, r.right - r0.left, r.bottom - r0.top]); }
    }
    function seatAt(placed, x, y, w, hh) {
      // 날짜판 · 은화 · 재고 표에 걸리면 그 아래로 내리고, 그 뒤로는 겹칠 때 아래쪽으로 비킨다(위로 비키면 다시 표 밑으로 들어감)
      let down = false;
      for (let k = 0; k < 8; k++) {
        let moved = false;
        for (const r of hudR) if (x + w / 2 > r[0] && x - w / 2 < r[2] && y - hh < r[3] && y > r[1]) { y = r[3] + hh + 3; down = true; moved = true; }
        const o = placed.find((q) => Math.abs(q[0] - x) < (q[2] + w) / 2 && y - hh < q[1] && q[1] - q[3] < y);
        if (o) { y = down ? o[1] + hh + 2 : o[1] - o[3] - 2; moved = true; }
        if (!moved) break;
      }
      placed.push([x, y, w, hh]);
      return y;
    }
    function domTick() {
      if (!st || st.ph !== 'svc' || !W) { for (const k in pool) hideFrom(k, 0); return; }
      const placed = [];
      const me = mySeat(), mc = me >= 0 && humanHere(me) ? W.ch[me] : null;
      const mine = mc ? mc.carry.map((it) => it.c) : [];
      const BS = Math.min(vw, vh) < 430 ? 26 : 30;
      // 손님 주문 말풍선: 기다림 고리 + 주문 그림. 내가 든 것을 주문한 손님은 그림에 초록 테두리, 고리가 1/4 아래면 붉은 테두리
      let nb = 0;
      for (const g of W.g) {
        const rw = g.rowdy && (g.st === 2 || g.st === 3);
        if (!rw && g.st !== 2) continue;
        const p = scr(g.rx != null ? g.rx : g.x, 1.85, g.rz != null ? g.rz : g.z); if (!p[2]) continue;
        const e = getEl('bub', nb++, 'tv-bub');
        let bw;
        if (rw) { const t = '소란 ' + Math.max(0, Math.ceil(g.rt)); if (e._t !== t) { e._t = t; e.textContent = t; e._h = null; } setCls(e, 'tv-bub rw'); bw = 64; }
        else {
          const f = clamp(g.pat / g.pat0, 0, 1);
          if (setHTML(e, '<span class="rg"></span>' + g.want.map((c) => '<span class="it' + (mine.includes(c) ? ' have' : '') + '">' + icoD(c, BS) + '</span>').join(''))) { e._r = null; e._t = null; }
          const rk = Math.round(f * 24); if (e._r !== rk) { e._r = rk; e.firstChild.innerHTML = ring(f); }
          setCls(e, 'tv-bub' + (f < 0.25 ? ' urg' : ''));
          bw = 38 + g.want.length * (BS + 4);
        }
        put(e, p[0], seatAt(placed, p[0], p[1] - 6, bw, BS + 16) + 6);
      }
      hideFrom('bub', nb);
      // 지금 쓰기 버튼이 닿는 곳: 그 자리에 할 일 이름표
      let na = 0;
      if (mc && !mc.busy && nearO && nearO.o.no !== '할 일 없음') {
        const t = S.targetPos(W, nearO.id);
        if (t) {
          const k0 = nearO.id[0], sp = t.spots && t.spots[0];
          const ax = k0 === 't' || k0 === 's' || !sp ? t.x : (t.x + sp[0]) / 2, az = k0 === 't' || k0 === 's' || !sp ? t.z : (t.z + sp[1]) / 2;
          const p = scr(ax, k0 === 's' ? 0.5 : k0 === 't' ? 1.3 : 1.25, az);
          if (p[2]) {
            const e = getEl('aim', na++, 'tv-aim');
            setHTML(e, esc(nearO.o.lbl) + (nearO.o.no ? ' · ' + esc(nearO.o.no) : ''));
            setCls(e, 'tv-aim' + (nearO.o.no ? ' off' : ''));
            const w = e._w0 || (e._w0 = e.offsetWidth || 90);
            put(e, p[0], seatAt(placed, p[0], p[1] - 6, w, 30) + 6);
          }
        }
      }
      hideFrom('aim', na);
      let nt = 0;
      const tag = (x, y, z, html, col, dim) => {
        const p = scr(x, y, z); if (!p[2]) return;
        const e = getEl('tag', nt++, 'tv-tag');
        setHTML(e, html); setCls(e, 'tv-tag' + (dim ? ' dim' : ''));
        if (e._c !== col) { e._c = col; e.style.setProperty('--c', col); }
        const w = e._w0 || (e._w0 = e.offsetWidth || 60);
        put(e, p[0], seatAt(placed, p[0], p[1], w, 22));
      };
      // 술통 · 솥 · 찬장 · 화덕 · 설거지통 표지(남은 양)
      W.ck.forEach((c, i) => {
        if (!c || !c.rd) return;
        tag(6.8 + i * 1.08, i % 2 ? 1.55 : 1.15, 0.9, T.ico.drink(c.r, 20) + T.DR[c.r].nm + ' <b>' + c.sv + '</b>', T.DR[c.r].col, !c.sv);
      });
      const stk2 = (place) => T.DISH.filter((d) => d.st === place && (W.dish[d.id] || 0) > 0).map((d) => T.ico.dish(d.id, 20) + '<b>' + W.dish[d.id] + '</b>').join('');
      const potH = stk2('pot'), brdH = stk2('board'), ovH = stk2('oven');
      tag(1.7, 1.95, 0.7, '솥 ' + potH, '#a5652f', !potH);
      tag(0.55, 1.75, 3.3, '찬장 ' + brdH, '#d9b46a', !brdH);
      tag(3.8, 1.8, 0.8, '화덕 ' + ovH, '#b4743a', !ovH && !W.ov.some((o) => o));
      W.ov.forEach((o) => {
        if (!o) return;
        const done = o.t >= o.T;
        tag(3.8, 2.25, 0.8, T.ico.dish(o.r, 20) + (done ? (o.t > o.T + 20 ? '타기 직전' : '다 됨') : Math.ceil(o.T - o.t) + '초'), done ? '#e3ae45' : '#8a6a44', false);
      });
      { const n = W.tub.m + W.tub.p; tag(0.55, 1.3, 5.6, '설거지통' + (n ? ' <b>' + n + '</b>' : ''), '#7f95a0', !n && !(mc && mc.carry.some((it) => it.c === 99))); }
      // 이름표(여럿일 때)
      if (st.n > 1) W.ch.forEach((c, s) => {
        tag(c.rx != null ? c.rx : c.x, 1.95, c.rz != null ? c.rz : c.z, esc(nm(s) + (isBot(s) && !humanHere(s) ? ' · ' + ['', '쉬움', '보통', '어려움'][lvOfSeat(s)] : '')), (api.players[s] && api.players[s].color) || '#c9963f', false);
      });
      hideFrom('tag', nt);
      // 치울 식탁 · 쏟은 술 표시
      let nd = 0;
      const bdg = (x, y, z, html) => { const p = scr(x, y, z); if (!p[2]) return; const e = getEl('bdg', nd++, 'tv-bdg'); setHTML(e, html); put(e, p[0], p[1]); };
      for (const tb of W.Lay.tbs) if (tb.dm + tb.dp > 0) bdg(tb.x, tb.bar ? 1.5 : 1.25, tb.z, icoM('dirty', 20));
      for (const sp of W.sp) bdg(sp.x, 0.5, sp.z, icoM('mop', 20));
      hideFrom('bdg', nd);
      let nc = 0;
      for (let i = coins.length - 1; i >= 0; i--) { const c = coins[i]; c.t += domDt; if (c.t > 1.2) { coins.splice(i, 1); continue; } }
      for (const c of coins) {
        const p = scr(c.x, 1.6 + c.t * 0.8, c.z); if (!p[2]) continue;
        const e = getEl('coin', nc++, 'tv-coin'); if (e._k !== c.txt) { e._k = c.txt; e.textContent = c.txt; }
        e.style.opacity = String(clamp(1.4 - c.t, 0, 1));
        e.style.transform = 'translate(' + Math.round(p[0]) + 'px,' + Math.round(p[1]) + 'px) translate(-50%,-100%)';
      }
      hideFrom('coin', nc);
    }

    /* ======================= 그리기: 사람 · 그릇 ======================= */
    const LOOKS = T.GUEST.map((g) => g.look);
    const SKIN = [0xe2b896, 0xc99a74, 0x9a6a48];
    const HAIR = [0x2a1a10, 0x4a3020, 0x6b4a2a, 0x8a7a68, 0x1a1410];
    const tmpM = new THREE.Matrix4(), baseM = new THREE.Matrix4(), partM = new THREE.Matrix4(), tq = new THREE.Quaternion(), te = new THREE.Euler(0, 0, 0, 'YXZ'), tv = new THREE.Vector3(), ts = new THREE.Vector3(1, 1, 1), tc = new THREE.Color();
    const cnt = {};
    function putPart(k, m, col) { const im = PIM[k], i = cnt[k]++; if (i >= im.instanceMatrix.count) return; im.setMatrixAt(i, m); tc.set(col); im.setColorAt(i, tc); }
    function local(x, y, z, rx, ry, rz) { te.set(rx || 0, ry || 0, rz || 0, 'YXZ'); tq.setFromEuler(te); tv.set(x, y, z); ts.set(1, 1, 1); partM.compose(tv, tq, ts); return tmpM.multiplyMatrices(baseM, partM); }
    function mute(hex, k) { tc.set(hex); const r = tc.r, g = tc.g, b = tc.b; tc.setRGB(r * k + 0.32 * (1 - k), g * k + 0.24 * (1 - k), b * k + 0.16 * (1 - k)); return tc.getHex(); }
    /* who: {x, z, yaw, sit, walk, carry, busy, look:{hat, body, cloak, skin, hair, pack, plume, apron, legs}, ring} */
    function drawPerson(o) {
      te.set(0, o.yaw, 0, 'YXZ'); tq.setFromEuler(te); tv.set(o.x, o.sit ? -0.02 : Math.abs(Math.sin(o.ph * 2)) * 0.03 * o.walk, o.z); ts.set(1, 1, 1); baseM.compose(tv, tq, ts);
      const lk = o.look, sw = Math.sin(o.ph) * 0.6 * o.walk;
      const y0 = o.sit ? -0.04 : 0;
      if (o.sit) { putPart('leg', local(0.09, 0.5, 0.02, -1.45), lk.legs); putPart('leg', local(-0.09, 0.5, 0.02, -1.45), lk.legs); }
      else { putPart('leg', local(0.09, 0.52, 0, sw), lk.legs); putPart('leg', local(-0.09, 0.52, 0, -sw), lk.legs); }
      putPart('torso', local(0, y0, 0), lk.body);
      let aL = -sw * 0.8, aR = sw * 0.8;
      if (o.carry) { aL = aR = -1.15; }
      else if (o.sit) { aL = aR = -0.9; }
      if (o.busy) { const b = Math.sin(o.t * 12); aL = -0.9 + b * 0.35; aR = -0.9 - b * 0.35; }
      if (o.rowdy) { aR = -2.6 + Math.sin(o.t * 9) * 0.4; }
      putPart('arm', local(0.26, 1.03 + y0, 0, aR, 0, 0.08), lk.body);
      putPart('arm', local(-0.26, 1.03 + y0, 0, aL, 0, -0.08), lk.body);
      putPart('head', local(0, y0, 0, o.nod || 0), lk.skin);
      if (lk.hat) putPart(lk.hat, local(0, y0, 0), lk.hatCol);
      else putPart('hair', local(0, y0, 0), lk.hair);
      if (lk.cloak) putPart('cloak', local(0, y0, 0), lk.cloak);
      if (lk.apron) putPart('apron', local(0, y0, 0), lk.apron);
      if (lk.pack) putPart('pack', local(0, y0, 0), 0x6b4a2a);
      if (lk.plume) putPart('plume', local(0, y0, 0), 0xe8e0d0);
      if (o.ring) { putPart('ring', local(0, 0, 0), o.ring); }
    }
    const icnt = {};
    function putItem(k, x, y, z, col, ry) { const im = IIM[k], i = icnt[k]++; if (i >= 160) return; te.set(0, ry || 0, 0, 'YXZ'); tq.setFromEuler(te); tv.set(x, y, z); ts.set(1, 1, 1); tmpM.compose(tv, tq, ts); im.setMatrixAt(i, tmpM); tc.set(col); im.setColorAt(i, tc); }
    const DRC = T.DRINK.map((d) => new THREE.Color(d.col).getHex()), DSC = T.DISH.map((d) => new THREE.Color(d.col).getHex());
    function drawThing(code, x, y, z, ry) {
      if (code === 99) { putItem('plate', x, y, z, 0x8a8070, ry); putItem('mug', x + 0.06, y + 0.02, z, 0x6a5a48, ry); return; }
      if (code < 11) { putItem('mug', x, y, z, 0x7a5636, ry); putItem('top', x, y, z, code === 3 ? 0xd8c8a8 : DRC[code - 1], ry); }
      else { putItem('plate', x, y, z, 0xe6dcc6, ry); putItem('food', x, y + 0.02, z, DSC[code - 11], ry); }
    }
    /* 걸음 사이 보간: 시뮬은 초당 30걸음, 화면은 60~144Hz → 걸음 위치를 그대로 쫓으면 두세 프레임에 한 번만 목표가 움직여 걸음이 덜컹거린다.
       걸음 직전 위치를 남기고(keepPose) 남은 시간 비율(stepA = acc / DT)로 그 사이를 목표로 준다(호스트 · 혼자 할 때). 손님 기기는 받은 위치를 그대로 쫓는다. */
    const RP = new WeakMap(), _tp = { x: 0, z: 0, k: 18 };
    let stepA = 1;
    function keepPose(o) { let r = RP.get(o); if (!r) { r = { px: 0, pz: 0 }; RP.set(o, r); } r.px = o.x; r.pz = o.z; }
    function tpos(o) {
      const r = RP.get(o); _tp.x = o.x; _tp.z = o.z; _tp.k = 18;
      if (!r || !isHost()) return _tp;
      const dx = o.x - r.px, dz = o.z - r.pz;
      if (stepA < 1 && dx * dx + dz * dz < 1) { _tp.x = r.px + dx * stepA; _tp.z = r.pz + dz * stepA; }
      _tp.k = 32;   // 보간은 한 걸음(33ms)쯤 늦게 그린다 → 따라가는 속도를 18 → 32로 올려 전체 늦음은 전과 같게(60Hz에서 55ms → 55ms)
      return _tp;
    }
    function smooth(o, x, z, yaw, dt, kk) {
      if (o.rx == null || Math.hypot(o.rx - x, o.rz - z) > 3) { o.rx = x; o.rz = z; o.ryaw = yaw; o.ph = o.ph || 0; }
      const k = 1 - Math.exp(-dt * (kk || 18)), px = o.rx, pz = o.rz;
      o.rx += (x - o.rx) * k; o.rz += (z - o.rz) * k;
      let d = yaw - o.ryaw; d = Math.atan2(Math.sin(d), Math.cos(d)); o.ryaw += d * Math.min(1, k * 1.2);
      const sp = Math.hypot(o.rx - px, o.rz - pz) / Math.max(1e-3, dt);
      o.walkA = (o.walkA || 0) + (clamp(sp / 2, 0, 1) - (o.walkA || 0)) * Math.min(1, dt * 10);
      o.ph = (o.ph || 0) + sp * dt * 4.2;
    }
    const staffLook = (s) => {
      const col = (api.players[s] && api.players[s].color) || '#8a6a44';
      return { hat: '', body: mute(col, 0.42), hair: HAIR[s % HAIR.length], skin: SKIN[(s * 2 + 1) % 3], legs: 0x3a2c22, apron: 0xe2d6bc };
    };
    const NPC_LOOK = { scullion: { hat: 'cap', hatCol: 0xd8ccb0, body: 0x6a5a48, skin: SKIN[0], legs: 0x3a2c22, apron: 0xcfc2a2 }, hand: { hat: '', hair: HAIR[2], body: 0x5a4a32, skin: SKIN[1], legs: 0x3a2c22, apron: 0x9a8a6a }, cookhand: { hat: 'cap', hatCol: 0xf0e8d8, body: 0xd8ccb0, skin: SKIN[0], legs: 0x4a3a2c, apron: 0xf0e8d8 }, bouncer: { hat: 'coif', hatCol: 0x8d9298, body: 0x3a3430, skin: SKIN[2], legs: 0x2a2420, cloak: 0x4a2c24 } };
    const guestLook = (g) => {
      const L0 = LOOKS[g.ty], v = (g.id * 2654435761) >>> 0;
      return { hat: L0.hat, hatCol: L0.hat === 'helm' || L0.hat === 'coif' ? 0x9aa0a6 : new THREE.Color(L0.cloak || L0.body).multiplyScalar(0.8).getHex(), body: new THREE.Color(L0.body).multiplyScalar(1.1 + (v % 7) * 0.06).getHex(), cloak: L0.cloak || '', skin: SKIN[(v >> 3) % 3], hair: HAIR[(v >> 5) % 5], legs: 0x2e2620, pack: L0.pack, plume: L0.plume };
    };
    let tNow = 0;
    function drawWorld(dt) {
      for (const k in cnt) cnt[k] = 0; for (const k in PIM) cnt[k] = 0;
      for (const k in IIM) icnt[k] = 0;
      if (W && st && st.ph === 'svc') {
        // 직원
        W.ch.forEach((c, s) => {
          { const tp = tpos(c); smooth(c, tp.x, tp.z, c.yaw, dt, tp.k); }
          const lk = staffLook(s);
          drawPerson({ x: c.rx, z: c.rz, yaw: c.ryaw, walk: c.walkA, ph: c.ph, carry: c.carry.length > 0, busy: !!c.busy, t: tNow, look: lk, ring: st.n > 1 || humanHere(s) ? new THREE.Color((api.players[s] && api.players[s].color) || '#c9963f').getHex() : 0 });
          const fx_ = Math.sin(c.ryaw), fz = Math.cos(c.ryaw);
          c.carry.forEach((it, k) => drawThing(it.c, c.rx + fx_ * 0.34 + (k - (c.carry.length - 1) / 2) * 0.2 * fz, 0.96, c.rz + fz * 0.34 - (k - (c.carry.length - 1) / 2) * 0.2 * fx_, c.ryaw));
        });
        for (const c of W.np) {
          { const tp = tpos(c); smooth(c, tp.x, tp.z, c.yaw, dt, tp.k); }
          drawPerson({ x: c.rx, z: c.rz, yaw: c.ryaw, walk: c.walkA, ph: c.ph, carry: c.carry.length > 0, busy: !!c.busy, t: tNow, look: NPC_LOOK[c.kind] || NPC_LOOK.hand });
          const fx_ = Math.sin(c.ryaw), fz = Math.cos(c.ryaw);
          c.carry.forEach((it) => drawThing(it.c, c.rx + fx_ * 0.34, 0.96, c.rz + fz * 0.34, c.ryaw));
        }
        // 손님
        for (const g of W.g) {
          if (g.st >= 6) continue;
          const tp = tpos(g), tx = g.tx != null ? g.tx : tp.x, tz = g.tz != null ? g.tz : tp.z;
          smooth(g, tx, tz, g.tyaw != null ? g.tyaw : g.yaw, dt, g.tx != null ? 18 : tp.k);
          if (!g.lk) g.lk = guestLook(g);
          const sit = g.st >= 1 && g.st <= 3 && g.seat >= 0;
          drawPerson({ x: g.rx, z: g.rz, yaw: g.ryaw, walk: sit ? 0 : g.walkA, ph: g.ph, sit, t: tNow + g.id, look: g.lk, rowdy: g.rowdy && sit, nod: g.st === 3 ? Math.sin(tNow * 3 + g.id) * 0.12 : 0 });
          if (sit && g.st === 3) {
            const s = W.Lay.seats[g.seat]; if (s) {
              const tb = W.Lay.tbs[s.tb], k = tb.bar ? 0.55 : 0.42, ax = s.x + (tb.x - s.x) * k, az = s.z + (tb.z - s.z) * k, y = tb.bar ? 1.1 : 0.82;
              let dc = 0, fc = 0;
              if (g.got) { for (const it of g.got) { if (it.c < 11) dc = it.c; else fc = it.c; } }
              else if (g.lastGot) { const c0 = Math.floor(g.lastGot / 10); if (c0 < 11) dc = c0; else fc = c0; }
              if (g.drinks) drawThing(dc || 1, ax, y, az, 0);
              if (g.dishes) drawThing(fc || 11, ax + (tb.z - s.z) * 0.2, y, az - (tb.x - s.x) * 0.2, 0);
            }
          }
        }
        // 식탁 위 빈 그릇
        const bk = W.Lay.seats.map((q) => q.brk ? 1 : 0).join('');
        if (bk !== brkKey && stoolIM) { brkKey = bk; W.Lay.seats.forEach((q, i) => { if (i < stoolIM.count) stoolIM.setMatrixAt(i, q.brk ? M4(q.x, 0.2, q.z, 0, q.yaw, Math.PI / 2) : M4(q.x, W.Lay.tbs[q.tb].bar ? 0.18 : 0, q.z, 0, q.yaw, 0, 1, W.Lay.tbs[q.tb].bar ? 1.4 : 1, 1)); }); stoolIM.instanceMatrix.needsUpdate = true; }
        for (const tb of W.Lay.tbs) {
          const n = Math.min(8, tb.dm + tb.dp); if (!n) continue;
          for (let k = 0; k < n; k++) { const a = k * 2.1, r = 0.22 + (k % 3) * 0.08, y = tb.bar ? 1.1 : 0.82; if (k < tb.dm) putItem('mug', tb.x + Math.sin(a) * r * (tb.bar ? 6 : 1), y, tb.z + Math.cos(a) * r * (tb.bar ? 0.4 : 1), 0x5a4a3a, a); else putItem('plate', tb.x + Math.sin(a) * r * (tb.bar ? 6 : 1), y, tb.z + Math.cos(a) * r * (tb.bar ? 0.4 : 1), 0x9a9080, a); }
        }
        // 깨끗한 잔(계산대 끝) · 접시(찬장)
        for (let i = 0; i < Math.min(14, W.mug); i++) putItem('mug', 6.5 + (i % 7) * 0.16, 1.98 + Math.floor(i / 7) * 0.0, 0.16 + Math.floor(i / 7) * 0.14, 0x8a6240, 0);
        for (let i = 0; i < Math.min(12, W.plate); i++) putItem('plate', 0.75, 0.92 + i * 0.026, 4.0, 0xe6dcc6, 0);
        for (let i = 0; i < Math.min(8, W.tub.m + W.tub.p); i++) putItem(i % 2 ? 'mug' : 'plate', 0.45 + (i % 3) * 0.15, 0.82 + Math.floor(i / 3) * 0.04, 5.45 + (i % 2) * 0.25, 0x6a5a48, i);
        // 화덕 안
        W.ov.forEach((o, i) => { if (o) drawThing(fCodeOf(o.r), 3.62 + i * 0.22, 0.9, 1.0, 0); });
        // 쏟은 술
        spillIM.count = Math.min(12, W.sp.length);
        W.sp.slice(0, 12).forEach((p, i) => { spillIM.setMatrixAt(i, M4(p.x, 0.012 + i * 0.001, p.z, 0, (p.id * 1.3) % 3, 0, 0.8 + (p.id % 3) * 0.15, 1, 1)); });
        spillIM.instanceMatrix.needsUpdate = true;
      } else {
        // 아침 · 밤: 직원이 홀에 서 있음
        if (st) for (let s = 0; s < st.n; s++) {
          const spots = [[9.0, 1.8], [5.4, 3.6], [10.4, 4.2], [2.6, 2.6]];
          const p = spots[s % 4];
          drawPerson({ x: p[0], z: p[1], yaw: Math.PI * 0.95, walk: 0, ph: 0, t: tNow, look: staffLook(s), ring: st.n > 1 ? new THREE.Color((api.players[s] && api.players[s].color) || '#c9963f').getHex() : 0 });
        }
        spillIM.count = 0;
      }
      // 술통
      if (caskIM && st) {
        const n = T.caskCap(st); caskIM.count = hoopIM.count = n; let nt = 0;
        const cks = W && st.ph === 'svc' ? W.ck : st.ck.map((c) => (c ? { r: c.r, sv: c.sv, rd: T.cReady(c) } : null));
        for (let i = 0; i < n; i++) {
          const x = 6.8 + i * 1.08, c = cks[i];
          const m = M4(x, 0.58, 0.5, Math.PI / 2, 0, 0); caskIM.setMatrixAt(i, m); hoopIM.setMatrixAt(i, m);
          caskIM.setColorAt(i, tc.set(c ? 0xc09060 : 0x8a6a50));
          if (c && c.rd && c.sv > 0) { tapIM.setMatrixAt(nt++, M4(x, 0.42, 0.96, Math.PI / 2)); }
        }
        tapIM.count = nt;
        caskIM.instanceMatrix.needsUpdate = hoopIM.instanceMatrix.needsUpdate = tapIM.instanceMatrix.needsUpdate = true; if (caskIM.instanceColor) caskIM.instanceColor.needsUpdate = true;
      }
      // 작물
      if (cropIM && st) {
        let n = 0;
        st.plots.forEach((p, i) => {
          if (!p) return; const C = T.CR[p.c], f = clamp(p.g / C.days, 0.15, 1), x0 = -5.6 + (i % 2) * 2.4, z0 = 2.4 + Math.floor(i / 2) * 1.8;
          for (let k = 0; k < 6; k++) { cropIM.setMatrixAt(n, M4(x0 - 0.6 + (k % 3) * 0.6, 0.14 + 0.15 * f, z0 - 0.3 + Math.floor(k / 3) * 0.6, 0, k, 0, f, f, f)); cropIM.setColorAt(n, tc.set(f >= 1 ? 0xb8a040 : 0x6c8f3a)); n++; }
        });
        cropIM.count = n; cropIM.instanceMatrix.needsUpdate = true; if (cropIM.instanceColor) cropIM.instanceColor.needsUpdate = true;
      }
      // 표시 고리
      if (markAt && markAt[2] > 0) { markAt[2] -= dt; markIM.count = 1; markIM.setMatrixAt(0, M4(markAt[0], 0.02, markAt[1], 0, 0, 0, 1 + (0.8 - markAt[2]) * 0.6)); markIM.instanceMatrix.needsUpdate = true; } else markIM.count = 0;
      for (const k in PIM) { const im = PIM[k]; im.count = cnt[k] || 0; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true; }
      for (const k in IIM) { const im = IIM[k]; im.count = icnt[k] || 0; im.instanceMatrix.needsUpdate = true; if (im.instanceColor) im.instanceColor.needsUpdate = true; }
    }
    const fCodeOf = (r) => 11 + T.DS[r].i;

    /* ======================= 빛 · 불 · 김 ======================= */
    let dayF = 1;
    const cA = new THREE.Color(), cB = new THREE.Color();
    function lightTick(dt) {
      let target = 0;
      if (st) { if (st.ph === 'morn') target = 1; else if (st.ph === 'svc' && W) target = clamp(0.4 - W.t / S.DUR * 2, 0, 0.4); else target = 0; }
      dayF += (target - dayF) * Math.min(1, dt * 1.5);
      const fl = 0.85 + Math.sin(tNow * 13) * 0.06 + Math.sin(tNow * 7.3) * 0.07 + Math.sin(tNow * 23) * 0.03;
      hemi.intensity = (low ? 1.25 : 0.95) + dayF * 0.55;
      hemi.color.copy(cA.set(0xd8c4a8)).lerp(cB.set(0xe6e8ea), dayF); hemi.groundColor.copy(cA.set(0x3a2818)).lerp(cB.set(0x6a5640), dayF);
      sun.intensity = 0.7 + dayF * 1.9; sun.color.copy(cA.set(0xffc890)).lerp(cB.set(0xfff0d8), dayF);
      PL.forEach((l, i) => { l.intensity = l.userData.base * (i === 0 ? fl : 0.92 + Math.sin(tNow * 9 + i * 2) * 0.05) * (i === 0 ? 0.55 + (1 - dayF) * 0.45 : (1 - dayF * 0.85)); });
      MT.glass.color.copy(cA.set(0x1a2840)).lerp(cB.set(0xd8e4ea), dayF);
      R.toneMappingExposure = 1.05 + (1 - dayF) * 0.1;
      fl1.scale.set(1, fl * 1.1, 1); fl2.scale.set(1, 0.9 + Math.sin(tNow * 17) * 0.15, 1); fl3.scale.set(1, 0.85 + Math.sin(tNow * 11 + 1) * 0.18, 1);
      const cook = W && st && st.ph === 'svc' && W.ov.some((o) => o);
      ovGlow.visible = !!cook; if (cook) ovGlow.scale.setScalar(0.9 + Math.sin(tNow * 9) * 0.08);
      if (flameIM) { candles.forEach((c, i) => { const s = (1 - dayF * 0.9) * (0.85 + Math.sin(tNow * 15 + i * 1.7) * 0.15); flameIM.setMatrixAt(i, M4(c[0], c[1] + 0.12, c[2], 0, 0, 0, s, s, s)); }); flameIM.instanceMatrix.needsUpdate = true; }
      // 김 · 연기
      if (Math.random() < dt * 5) emit(1.7, 0.75, 0.6, 0.35, 0.3);
      if (cook && Math.random() < dt * 3) emit(3.8, 1.2, 1.0, 0.4, 0.2);
      if (W && st && st.ph === 'svc' && W.ov.some((o) => o && o.t > o.T + 18) && Math.random() < dt * 8) emit(3.8, 1.1, 1.0, 0.7, 0.3);
      for (let i = 0; i < NP; i++) { if (pAge[i] > 5) continue; pAge[i] += dt; pPos[i * 3] += pVel[i * 3] * dt; pPos[i * 3 + 1] += pVel[i * 3 + 1] * dt; pPos[i * 3 + 2] += pVel[i * 3 + 2] * dt; if (pAge[i] > 3.2) pPos[i * 3 + 1] = -50; }
      pGeo.attributes.position.needsUpdate = true;
    }

    /* ======================= 카메라 ======================= */
    const camT = new THREE.Vector3(9, 0, 5.5), camW = { w: 20, h: 12 };
    let camD = 20, camInit = false;
    let pitch = 0.95;
    function panelInfo() {
      if (!st || (st.ph !== 'morn' && st.ph !== 'night') || folded) return null;
      const land = vw >= vh * 1.05;
      return land ? { side: 'r', size: Math.round(clamp(vw * 0.44, 300, 430)) } : { side: 'b', size: Math.round(vh * 0.56) };
    }
    function layout() {
      vw = Math.max(1, wrap.clientWidth); vh = Math.max(1, wrap.clientHeight);
      R.setPixelRatio(Math.min(window.devicePixelRatio || 1, TIER.pr)); R.setSize(vw, vh, false);
      const pi = panelInfo();
      if (pi && pi.side === 'r') { Object.assign(panelEl.style, { width: pi.size + 'px', height: '', left: '', top: '0', right: '0', bottom: '0' }); panelEl.className = 'tv-panel r'; Object.assign(foldBtn.style, { right: (pi.size + 8) + 'px', left: '', bottom: '12px', top: '' }); }
      else if (pi) { Object.assign(panelEl.style, { width: '', height: pi.size + 'px', left: '0', right: '0', top: '', bottom: '0' }); panelEl.className = 'tv-panel b'; Object.assign(foldBtn.style, { right: '8px', left: '', bottom: (pi.size + 8) + 'px', top: '' }); }
      else Object.assign(foldBtn.style, { right: '8px', left: '', bottom: '12px', top: '' });
      panelDirty = true;
    }
    function camTick(dt) {
      if (!st) return;
      const land = vw >= vh * 1.05, pi = panelInfo();
      let tx = 9, tz = 5.3, w = 20.5, hM = 12.5;
      if (st.ph === 'svc') {
        const me = mySeat(), c = W && me >= 0 ? W.ch[me] : null;
        if (!land) { w = 8; hM = 0; tx = 9; tz = 5.6; if (c) { tx = clamp(c.rx != null ? c.rx : c.x, 3.4, 14.6); tz = clamp((c.rz != null ? c.rz : c.z) + 0.3, 4.4, 7.0); } }
      } else if (st.ph === 'morn' && !folded) {
        const F = { brew: [9.6, 1.8, 10], kitchen: [2.8, 2.8, 9], yard: [-3.6, 5.4, 10] }[tab] || [9, 5.3, 20.5];
        tx = F[0]; tz = F[1]; w = F[2]; hM = w * 0.62;
      } else if (st.ph === 'morn' || st.ph === 'night') { if (!land) w = 13; }
      const pT = !land && st.ph === 'svc' ? 1.12 : 0.95;
      const k = camInit ? 1 - Math.exp(-dt * 3) : 1; camInit = true;
      pitch += (pT - pitch) * k;
      camT.x += (tx - camT.x) * k; camT.z += (tz - camT.z) * k; camW.w += (w - camW.w) * k; camW.h += (hM - camW.h) * k;
      const fw = vw + (pi && pi.side === 'r' ? pi.size : 0), fh = vh + (pi && pi.side === 'b' ? pi.size : 0);
      const freeW = vw - (pi && pi.side === 'r' ? pi.size : 0), freeH = vh - (pi && pi.side === 'b' ? pi.size : 0);
      cam.aspect = fw / fh; cam.setViewOffset(fw, fh, pi && pi.side === 'r' ? pi.size : 0, pi && pi.side === 'b' ? pi.size : 0, vw, vh); cam.updateProjectionMatrix();
      const t = Math.tan(cam.fov * Math.PI / 360);
      camD = Math.max(camW.w * (fh / 2) / (Math.max(80, freeW) * t), camW.h * Math.sin(pitch) * (fh / 2) / (Math.max(80, freeH) * t));
      cam.position.set(camT.x, Math.sin(pitch) * camD, camT.z + Math.cos(pitch) * camD);
      cam.lookAt(camT.x, 0.6, camT.z);
    }

    /* ======================= 온라인 ======================= */
    let pubT = 0;
    function pollNet() {
      if (!api.online || !st) return;
      let rem = null, hs = null;
      try { rem = api.net.remote(); } catch (e) {}
      if (!api.isHost) { try { hs = api.net.hostState(); } catch (e) {} }
      if (api.isHost && rem) {
        let ns = null;
        for (const k in rem) {
          const s = +k, o = rem[k]; if (!o) continue;
          // 관리 요청(어느 단계든)
          if (Array.isArray(o.m)) for (const [sq, a] of o.m) {
            if (sq <= (lastM[s] || 0)) continue; lastM[s] = sq;
            try { ns = applyReq(ns || st, s, a); } catch (e) { errOut[s] = [sq, String(e.message || e)]; }
          }
          if (o.k !== netKey() || !W || st.ph !== 'svc') continue;
          const c = W.ch[s]; if (!c || !remoteHuman(s)) continue;
          if (Array.isArray(o.p)) { c.x = o.p[0] / 10; c.z = o.p[1] / 10; c.yaw = o.p[2] / 50; c.mv = o.p[3]; }
          if (Array.isArray(o.u)) for (const [sq, op, id] of o.u) {
            if (sq <= (lastU[s] || 0)) continue; lastU[s] = sq;
            if (op === 'use') S.tryUse(W, c, id, false); else if (op === 'drop') S.dropTop(W, c);
          }
        }
        if (ns) api.setState(ns);
      }
      if (!api.isHost && hs) {
        if (hs.mack) { const me = mySeat(); if (me >= 0 && hs.mack[me] != null) pendM = pendM.filter((x) => x[0] > hs.mack[me]); if (me >= 0 && hs.err && hs.err[me] && hs.err[me][0] > (errOut.seen || 0)) { errOut.seen = hs.err[me][0]; note(hs.err[me][1], 'bad'); } }
        if (hs.k === netKey() && W && st.ph === 'svc' && hs.w) {
          S.unpack(W, hs.w, mySeat());
          const me = mySeat(); if (me >= 0 && hs.uack && hs.uack[me] != null) pendU = pendU.filter((x) => x[0] > hs.uack[me]);
          if (Array.isArray(W.fxIn)) { for (const f of W.fxIn) if (f[0] > (W.fxSeen || 0)) { W.fxSeen = f[0]; onFx(f); } W.fxIn = null; }
        }
      }
    }
    function publish(dt) {
      if (!api.online || !st) return;
      pubT -= dt; if (pubT > 0) return;
      const svc = st.ph === 'svc' && W;
      pubT = svc ? 1 / 12 : 1 / 4;
      try {
        if (!api.isHost) {
          const me = mySeat(); if (me < 0) return;
          const o = { k: netKey() };
          if (pendM.length) o.m = pendM.slice(-6);
          if (svc) { const c = W.ch[me]; if (c) o.p = [Math.round(c.x * 10), Math.round(c.z * 10), Math.round(c.yaw * 50), c.mv ? 1 : 0]; if (pendU.length) o.u = pendU.slice(-6); }
          api.net.publish(o);
        } else {
          const o = { k: netKey(), mack: Object.assign({}, lastM), uack: Object.assign({}, lastU), err: errOut };
          if (svc) o.w = S.pack(W);
          api.net.hostSend(o);
        }
      } catch (e) {}
    }

    /* ======================= 판 진행 ======================= */
    let fxSeen = 0;
    function onFx(f) {
      const k = f[1];
      if (k === 'pay') { coins.push({ x: f[2], z: f[3], t: 0, txt: '+' + f[4] }); sfx('chip', 0.5); }
      else if (k === 'serve') sfx('pop', 0.45);
      else if (k === 'angry') { sfx('warn', 0.4); }
      else if (k === 'rowdy') { note('소란 · 붉은 표시 손님을 달래기', 'bad'); sfx('warn', 0.6); }
      else if (k === 'brawl') { note('싸움 · 의자가 부서짐', 'bad'); sfx('hit', 0.9); try { api.buzz(60, 'hit'); } catch (e) {} }
      else if (k === 'calm') { sfx('click', 0.5); }
      else if (k === 'escort') { note('소란 피운 손님을 내보냄'); }
      else if (k === 'spill') sfx('thud', 0.25);
      else if (k === 'done') sfx('tick', 0.5);
      else if (k === 'burn') { note('화덕 요리가 탐', 'bad'); sfx('warn', 0.5); }
      else if (k === 'door') sfx('thud', 0.15);
    }
    function ensureWorld() {
      if (!st) return;
      buildLayout(st);
      if (st.ph !== 'svc') { W = null; wkey = ''; return; }
      const k = st.rid + '_' + st.day + '_' + st.sv;
      if (k === wkey && W) return;
      W = S.makeWorld(st, { host: isHost() }); wkey = k; fxSeen = 0; DBG.W = W; Lay = W.Lay; brkKey = '';
      for (const c of W.ch) { c.rx = null; }
      if (!isHost()) { W.arr = []; }
      introEl.innerHTML = '<b>저녁 영업</b><span>17시 · 문을 엶' + (st.ev && T.EV[st.ev] ? ' · ' + T.EV[st.ev].nm : '') + '</span>'; introEl.style.opacity = '1'; introT = 1.6;
      // 처음 영업: 조작 안내
      if (!L.debug.noTut && mySeat() >= 0 && humanHere(mySeat()) && T.store.get('tip', '') !== '1') {
        T.store.set('tip', '1');
        tipEl = h('div', { class: 'tv-tip' }); tipEl.innerHTML = (sawTouch || T.touchOnly()) ? (moveMode() === 'stick' ? '왼쪽 아래를 누른 채 끌면 걷습니다. 오른쪽 아래 큰 버튼은 가까운 것 쓰기. 손님 머리 위 그림이 주문, 고리가 기다림.' : '바닥 · 술통 · 화덕 · 식탁을 누르면 걸어가서 바로 씁니다. 오른쪽 아래 큰 버튼은 가까운 것 쓰기. 손님 머리 위 그림이 주문, 고리가 기다림.') : '<kbd>WASD</kbd> 걷기 · <kbd>E</kbd> 가까운 것 쓰기 · <kbd>Q</kbd> 든 것 버리기 · 클릭하면 걸어가서 바로 씁니다. 손님 머리 위 그림이 주문, 고리가 기다림.';
        tipEl.addEventListener('pointerdown', () => { if (tipEl) { tipEl.remove(); tipEl = null; } });
        layer.append(tipEl); setTimeout(() => { if (tipEl) { tipEl.remove(); tipEl = null; } }, 7000);
      }
    }
    let introT = 0;
    function simTick(dt) {
      if (!W || !st || st.ph !== 'svc') return;
      const me = mySeat(), meHum = me >= 0 && humanHere(me);
      if (isHost()) {
        acc += dt;
        const maxSteps = Math.ceil(0.5 * SPD() / S.DT) + 4;
        let steps = Math.floor(acc / S.DT); if (steps > maxSteps) { steps = maxSteps; acc = 0; } else acc -= steps * S.DT;
        for (let i = 0; i < steps && !W.done; i++) {
          for (const c of W.ch) keepPose(c); for (const c of W.np) keepPose(c); for (const g of W.g) keepPose(g);
          S.step(W, S.DT, (s) => (s === me && meHum ? (i === 0 ? readInput() : moveAxis()) : remoteHuman(s) && !testBot() ? 'remote' : null), (s) => ({ lv: lvOfSeat(s), hab: habOf(s) }));
        }
        stepA = clamp(acc / S.DT, 0, 1);
        for (const f of W.fx) if (f[0] > fxSeen) { fxSeen = f[0]; onFx(f); }
        if (W.done && sentSeq !== st.seq) { sentSeq = st.seq; api.setState(T.endSvc(st, S.out(W))); sfx('result', 0.7); }
      } else if (meHum) {
        // 손님 기기: 자기 캐릭터만 먼저 움직임
        const c = W.ch[me]; if (!c) return;
        const inp = readInput();
        if (!c.busy) {
          if (inp.go) S.goTo(W, c, inp.go.id, inp.go.x, inp.go.z);
          if (Math.hypot(inp.mx, inp.mz) > 0.1) { c.path = null; c.tgt = null; const steps = Math.max(1, Math.round(dt / S.DT)); for (let i = 0; i < steps; i++) stepFreeLocal(c, inp.mx, inp.mz, dt / steps); }
          else if (c.path) { const was = c.tgt; const p0 = c.path; const arr = moveLocal(c, dt); if (arr && was) { pendU.push([++uSeq, 'use', was]); pubT = 0; } void p0; }
        }
        if (inp.use && !c.busy) { const nb = S.nearest(W, c); if (nb && !nb.o.no) { pendU.push([++uSeq, 'use', nb.id]); pubT = 0; } }
        if (inp.drop) { pendU.push([++uSeq, 'drop', '']); pubT = 0; }
        // 다른 사람 부드럽게
        const kf = 1 - Math.pow(0.7, Math.min(3, dt * 60));
        for (const o of W.ch) if (o !== c && o.tx != null) { o.x += (o.tx - o.x) * kf; o.z += (o.tz - o.z) * kf; o.yaw = o.tyaw; }
        for (const o of W.np) if (o.tx != null) { o.x += (o.tx - o.x) * kf; o.z += (o.tz - o.z) * kf; o.yaw = o.tyaw; }
      }
    }
    function stepFreeLocal(c, mx, mz, dt) {
      const l = Math.hypot(mx, mz); if (l < 0.08) return;
      const sp = 2.7 * Math.min(1, l), vx = mx / l * sp * dt, vz = mz / l * sp * dt, blk = W.Lay.blk;
      const okR = (x, z, q) => S.walk(blk, x + q, z + q) && S.walk(blk, x - q, z + q) && S.walk(blk, x + q, z - q) && S.walk(blk, x - q, z - q);
      const r = okR(c.x, c.z, 0.199) ? 0.199 : 0.06;   // 벽 칸에 걸친 자리에서도 빠져나오게(sim.stepFree와 같음)
      const ok = (x, z) => okR(x, z, r);
      if (ok(c.x + vx, c.z)) c.x += vx; if (ok(c.x, c.z + vz)) c.z += vz;
      c.yaw = Math.atan2(mx, mz); c.mv = 1;
    }
    function moveLocal(c, dt) {
      let rem = 2.7 * dt;
      while (rem > 0 && c.path && c.path.length) { const p = c.path[0], dx = p[0] - c.x, dz = p[1] - c.z, d = Math.hypot(dx, dz); if (d > 1e-4) c.yaw = Math.atan2(dx, dz); if (d <= rem) { c.x = p[0]; c.z = p[1]; c.path.shift(); rem -= d; } else { c.x += dx / d * rem; c.z += dz / d * rem; rem = 0; } }
      c.mv = 1;
      if (c.path && !c.path.length) { c.path = null; const t = c.tgt; c.tgt = null; return !!t; }
      return false;
    }
    function phaseTick(rdt) {
      if (!st) return;
      if (phSeq !== st.seq) {
        const prevPh = phSeq < 0 ? null : lastPh;
        phSeq = st.seq; lastPh = st.ph;
        panelDirty = true;
        if (st.ph !== prevPh) {
          phT = 0; planQ = null;
          if (st.ph === 'morn') { folded = false; tab = 'market'; if (prevPh === 'night' || prevPh == null) { try { api.banner(st.day + '일째 아침', { sub: T.SEASONS[T.ssnOf(st)].nm + (st.ev && T.EV[st.ev] ? ' · ' + T.EV[st.ev].nm : ''), ms: 1400, small: true }); } catch (e) {} } }
          if (st.ph === 'night') { folded = false; ntab = 'sum'; }
          layout();
          if (st.ph === 'morn' && prevPh == null && !L.debug.noTut && mySeat() >= 0 && humanHere(mySeat()) && T.store.get('tut', '') !== '1') { T.store.set('tut', '1'); setTimeout(() => { try { api.tutorial(); } catch (e) {} }, 700); }
        }
      }
      phT += rdt * SPD();
      if (!isHost()) return;
      if (st.ph !== 'morn' && st.ph !== 'night') return;
      // AI 자리는 바로 준비 · 모두 AI면 관리도 AI
      const allBot = st.rdy.every((_, i) => isBot(i));
      if (allBot) {
        if (!planQ) { const lv = Math.max(...api.players.map((p) => (p.ai ? p.lv || 2 : 2))); planQ = T.plan(st, lv, Math.random, habOf(0)); planT = 0.6; }
        planT -= rdt * SPD();
        if (planT <= 0 && planQ.length) {
          planT = 0.3;
          const a = planQ.shift();
          try { const ns = JSON.parse(JSON.stringify(st)); T.mg(ns, -1, a); ns.seq++; sentSeq = -1; api.setState(ns); if (a.k === 'brew' || a.k === 'prep' || a.k === 'up' || a.k === 'deco') note(a.k === 'brew' ? T.DR[a.r].nm + ' 담금' : a.k === 'prep' ? T.DS[a.r].nm + ' 밑준비' : a.k === 'up' ? T.UP[a.id].nm : T.DC[a.id].nm + ' 들임'); } catch (e) {}
          return;
        }
        if (!planQ.length && phT > (st.ph === 'morn' ? 2.2 : 2.6) && sentSeq !== st.seq + 2000) { sentSeq = st.seq + 2000; const ns = JSON.parse(JSON.stringify(st)); ns.rdy = ns.rdy.map(() => 1); api.setState(ns.ph === 'morn' ? T.startSvc(ns) : T.nextDay(ns)); }
        return;
      }
      const need = st.rdy.map((r, i) => (isBot(i) ? 1 : r));
      if (need.some((r, i) => r !== st.rdy[i])) { const ns = JSON.parse(JSON.stringify(st)); ns.rdy = need; ns.seq++; api.setState(ns); return; }
      if (need.every((r) => r) && sentSeq !== st.seq + 3000) { sentSeq = st.seq + 3000; api.setState(st.ph === 'morn' ? T.startSvc(st) : T.nextDay(st)); }
    }
    let lastPh = null;

    /* ======================= 프레임 ======================= */
    function frame(now) {
      if (dead) return;
      raf = requestAnimationFrame(frame);
      const rdt = Math.min(0.1 * Math.max(1, SPD()), (now - (last || now)) / 1000); last = now;
      if (!ready || !st) return;
      const dt = rdt * SPD();
      tNow += rdt;
      if (!paused) {
        pollNet();
        if (W && st.ph === 'svc') simTick(isHost() ? dt : rdt);
        publish(rdt);
        phaseTick(rdt);
      }
      if (panelDirty) drawPanel();
      lightTick(rdt);
      drawWorld(rdt);
      camTick(rdt);
      if (stk && (!stickOn() || paused)) stickEnd();
      stickDraw();
      hudT -= rdt; if (hudT <= 0) { hudT = 1 / 8; hudTick(); }
      domDt = rdt; domTick();
      if (noteT > 0) { noteT -= rdt; if (noteT <= 0) noteEl.style.opacity = '0'; }
      if (introT > 0) { introT -= rdt; if (introT <= 0) introEl.style.opacity = '0'; }
      R.render(scene, cam);
    }
    wrap.addEventListener('pointerdown', (e) => { if (e.pointerType && e.pointerType !== 'mouse') sawTouch = true; noteT = Math.min(noteT, 0.05); if (introT > 0) introT = 0.05; }, true);

    /* ======================= 시작 ======================= */
    const onResize = () => layout();
    window.addEventListener('resize', onResize);
    buildStatic();
    layout();
    function start() {
      if (warming || ready) return;
      warming = true;
      hooks.progress(0.75, '불 지피는 중');
      ensureWorld(); camTick(0.016); drawWorld(0.016); lightTick(0.016);
      const wg = warmGroup(); scene.add(wg);
      const t0 = performance.now();
      compileBg(scene).then(() => {
        if (dead) return;
        try { R.render(scene, cam); } catch (e) {}
        scene.remove(wg); wg.traverse((o) => { if (o.isInstancedMesh) o.dispose(); });
        DBG.tm = { compile: Math.round(performance.now() - t0), progs: R.info.programs.length };
        ready = true; hooks.ready();
      });
    }
    raf = requestAnimationFrame(frame);

    return {
      update(s) {
        if (!s) return;
        st = s; panelDirty = true;
        if (!ready) { start(); return; }
        ensureWorld();
      },
      pause() { paused = true; stickEnd(); }, resume() { paused = false; last = 0; },
      destroy() {
        dead = true; cancelAnimationFrame(raf);
        window.removeEventListener('resize', onResize);
        for (const f of offs) try { f(); } catch (e) {}
        clearLay();
        for (const k in TX) TX[k].dispose();
        try { R.dispose(); R.forceContextLoss(); } catch (e) {}
        wrap.remove();
      },
    };
  };
  window.TAVERN_VIEW = V;
})();
