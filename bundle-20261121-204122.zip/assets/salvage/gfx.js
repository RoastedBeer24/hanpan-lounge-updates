/* 폐건물 회수 하청 — 그림 재료(three.js r170): 캔버스 결 · 재질 · 시설 형상 · 소품 · 트럭 · 고철/장비 · 개체 · 동료 모형.
   모두 코드로 생성(외부 모델 · 그림 없음). view.js가 씀. */
(function () {
  'use strict';
  const THREE = window.THREE;
  const GX = {};
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function prng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  GX.prng = prng;

  /* ======================= 캔버스 결 ======================= */
  function cv(n) { const c = document.createElement('canvas'); c.width = c.height = n; return c; }
  function speckle(g, n, R, k, a0, a1, light) {
    const id = g.getImageData(0, 0, n, n), d = id.data;
    for (let i = 0; i < d.length; i += 4) { const v = (R() - 0.5) * k; d[i] = clamp(d[i] + v, 0, 255); d[i + 1] = clamp(d[i + 1] + v, 0, 255); d[i + 2] = clamp(d[i + 2] + v * (light ? 0.9 : 1), 0, 255); }
    g.putImageData(id, 0, 0); void a0; void a1;
  }
  function blotches(g, n, R, cnt, col, rMin, rMax, aMax) {
    for (let i = 0; i < cnt; i++) {
      const x = R() * n, y = R() * n, r = rMin + R() * (rMax - rMin);
      const gr = g.createRadialGradient(x, y, 0, x, y, r);
      gr.addColorStop(0, col.replace('A', (aMax * (0.4 + R() * 0.6)).toFixed(3))); gr.addColorStop(1, col.replace('A', '0'));
      g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
      // 이음매에서 이어지게(바둑판 반복)
      if (x < r) { g.save(); g.translate(n, 0); g.fillRect(x - r, y - r, r * 2, r * 2); g.restore(); }
      if (y < r) { g.save(); g.translate(0, n); g.fillRect(x - r, y - r, r * 2, r * 2); g.restore(); }
    }
  }
  function mkTex(c, rep) { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; if (rep !== false) t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; }
  function normalFrom(c, strength) {   // 밝기를 높이로 보고 요철 결
    const n = c.width, g = c.getContext('2d'), src = g.getImageData(0, 0, n, n).data, o = cv(n), og = o.getContext('2d'), id = og.createImageData(n, n), d = id.data;
    const H = (x, y) => { x = (x + n) % n; y = (y + n) % n; const i = (y * n + x) * 4; return (src[i] + src[i + 1] + src[i + 2]) / 765; };
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const dx = (H(x + 1, y) - H(x - 1, y)) * strength, dy = (H(x, y + 1) - H(x, y - 1)) * strength;
      const l = Math.hypot(dx, dy, 1), i = (y * n + x) * 4;
      d[i] = (-dx / l * 0.5 + 0.5) * 255; d[i + 1] = (dy / l * 0.5 + 0.5) * 255; d[i + 2] = (1 / l * 0.5 + 0.5) * 255; d[i + 3] = 255;
    }
    og.putImageData(id, 0, 0);
    const t = new THREE.CanvasTexture(o); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
  }
  GX.textures = function (tier) {
    const N = tier === 'low' ? 256 : 512, R = prng(90211), T = {}, K = N / 512;
    // 벽: 칠한 콘크리트(4m × 3.2m) — 아래 띠 · 물때 · 긁힘 · 이음매
    { const c = cv(N), g = c.getContext('2d');
      g.fillStyle = '#d6d6d0'; g.fillRect(0, 0, N, N);
      const band = N * (1 - 1.05 / 3.2);
      g.fillStyle = '#a9aaa2'; g.fillRect(0, band, N, N - band);
      g.fillStyle = 'rgba(40,40,36,.55)'; g.fillRect(0, band - 3 * K, N, 3 * K);
      speckle(g, N, R, 26);
      blotches(g, N, R, 26, 'rgba(70,64,50,A)', 10 * K, 70 * K, 0.22);
      for (let i = 0; i < 26; i++) {   // 위에서 흘러내린 물때
        const x = R() * N, w = (2 + R() * 10) * K, L = N * (0.15 + R() * 0.6);
        const gr = g.createLinearGradient(0, 0, 0, L); gr.addColorStop(0, 'rgba(60,52,38,' + (0.15 + R() * 0.25) + ')'); gr.addColorStop(1, 'rgba(60,52,38,0)');
        g.fillStyle = gr; g.fillRect(x, 0, w, L);
      }
      for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(30,30,28,' + (0.1 + R() * 0.25) + ')'; g.fillRect(R() * N, band + R() * (N - band) * 0.9, (8 + R() * 40) * K, (1 + R() * 2) * K); }
      blotches(g, N, R, 14, 'rgba(35,32,26,A)', 20 * K, 60 * K, 0.3);
      g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(0, 0, 2 * K, N); g.fillRect(N / 2, 0, 2 * K, N);
      T.wall = mkTex(c); if (tier === 'high') T.wallN = normalFrom(c, 2.2);
    }
    // 바닥 타일(0.5m 칸 — 연구 단지)
    { const c = cv(N), g = c.getContext('2d'), s = N / 8;
      for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) { const v = 150 + R() * 30 - (R() < 0.12 ? 40 : 0); g.fillStyle = 'rgb(' + v + ',' + (v + 4) + ',' + (v - 6) + ')'; g.fillRect(x * s, y * s, s, s); }
      speckle(g, N, R, 22);
      g.strokeStyle = 'rgba(30,30,26,.6)'; g.lineWidth = 2 * K; for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * s, 0); g.lineTo(i * s, N); g.stroke(); g.beginPath(); g.moveTo(0, i * s); g.lineTo(N, i * s); g.stroke(); }
      blotches(g, N, R, 30, 'rgba(48,42,30,A)', 8 * K, 60 * K, 0.35);
      T.tile = mkTex(c); if (tier === 'high') T.tileN = normalFrom(c, 1.6);
    }
    // 콘크리트 바닥(이음 줄 · 기름 얼룩 · 금)
    { const c = cv(N), g = c.getContext('2d');
      g.fillStyle = '#8f8d86'; g.fillRect(0, 0, N, N);
      speckle(g, N, R, 34);
      blotches(g, N, R, 40, 'rgba(60,56,48,A)', 10 * K, 80 * K, 0.25);
      blotches(g, N, R, 8, 'rgba(15,14,12,A)', 12 * K, 40 * K, 0.45);
      g.strokeStyle = 'rgba(25,24,22,.55)'; g.lineWidth = 2 * K; g.beginPath(); g.moveTo(N / 2, 0); g.lineTo(N / 2, N); g.moveTo(0, N / 2); g.lineTo(N, N / 2); g.stroke();
      g.strokeStyle = 'rgba(20,20,18,.5)'; g.lineWidth = 1 * K;
      for (let i = 0; i < 7; i++) { let x = R() * N, y = R() * N; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 8; k++) { x += (R() - 0.5) * 40 * K; y += (R() - 0.3) * 30 * K; g.lineTo(x, y); } g.stroke(); }
      T.conc = mkTex(c); if (tier === 'high') T.concN = normalFrom(c, 1.8);
    }
    // 천장 판(0.5m 격자, 얼룩 · 빠진 판)
    { const c = cv(N), g = c.getContext('2d'), s = N / 8;
      g.fillStyle = '#b9b7ae'; g.fillRect(0, 0, N, N); speckle(g, N, R, 30);
      for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) { if (R() < 0.05) { g.fillStyle = '#121212'; g.fillRect(x * s, y * s, s, s); } else if (R() < 0.25) { const gr = g.createRadialGradient(x * s + s / 2, y * s + s / 2, 0, x * s + s / 2, y * s + s / 2, s * 0.7); gr.addColorStop(0, 'rgba(110,86,40,.45)'); gr.addColorStop(1, 'rgba(110,86,40,0)'); g.fillStyle = gr; g.fillRect(x * s, y * s, s, s); } }
      g.strokeStyle = 'rgba(70,70,64,.9)'; g.lineWidth = 3 * K; for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * s, 0); g.lineTo(i * s, N); g.stroke(); g.beginPath(); g.moveTo(0, i * s); g.lineTo(N, i * s); g.stroke(); }
      T.ceil = mkTex(c);
    }
    // 철판(소품): 긁힘 · 가장자리 어둡게
    { const n2 = N / 2, c = cv(n2), g = c.getContext('2d');
      g.fillStyle = '#c4c6c2'; g.fillRect(0, 0, n2, n2); speckle(g, n2, R, 22);
      for (let i = 0; i < 60; i++) { g.strokeStyle = 'rgba(' + (R() < 0.5 ? '255,255,255' : '30,30,30') + ',' + (0.08 + R() * 0.15) + ')'; g.lineWidth = 1; g.beginPath(); const x = R() * n2, y = R() * n2; g.moveTo(x, y); g.lineTo(x + (R() - 0.5) * 50, y + (R() - 0.5) * 10); g.stroke(); }
      blotches(g, n2, R, 10, 'rgba(90,60,30,A)', 6, 30, 0.35);
      const gr = g.createRadialGradient(n2 / 2, n2 / 2, n2 * 0.3, n2 / 2, n2 / 2, n2 * 0.75); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.35)'); g.fillStyle = gr; g.fillRect(0, 0, n2, n2);
      T.metal = mkTex(c, false);
    }
    // 녹
    { const n2 = N / 2, c = cv(n2), g = c.getContext('2d');
      g.fillStyle = '#7d7a72'; g.fillRect(0, 0, n2, n2); speckle(g, n2, R, 30);
      blotches(g, n2, R, 40, 'rgba(120,62,24,A)', 4, 36, 0.7); blotches(g, n2, R, 20, 'rgba(60,30,12,A)', 3, 18, 0.6);
      T.rust = mkTex(c);
    }
    // 나무 상자 · 팔레트
    { const n2 = N / 2, c = cv(n2), g = c.getContext('2d'), p = n2 / 5;
      for (let i = 0; i < 5; i++) { const v = 120 + R() * 30; g.fillStyle = 'rgb(' + v + ',' + (v * 0.78 | 0) + ',' + (v * 0.52 | 0) + ')'; g.fillRect(0, i * p, n2, p); g.fillStyle = 'rgba(30,20,10,.6)'; g.fillRect(0, i * p, n2, 2); }
      for (let i = 0; i < 120; i++) { g.fillStyle = 'rgba(40,25,10,' + R() * 0.25 + ')'; g.fillRect(R() * n2, R() * n2, 10 + R() * 40, 1); }
      speckle(g, n2, R, 18);
      g.strokeStyle = 'rgba(30,20,10,.7)'; g.lineWidth = 3; g.strokeRect(2, 2, n2 - 4, n2 - 4);
      T.wood = mkTex(c, false);
    }
    // 아스팔트(마당)
    { const c = cv(N), g = c.getContext('2d');
      g.fillStyle = '#3b3c3a'; g.fillRect(0, 0, N, N); speckle(g, N, R, 40);
      blotches(g, N, R, 30, 'rgba(15,15,14,A)', 10 * K, 70 * K, 0.4); blotches(g, N, R, 20, 'rgba(90,88,80,A)', 6 * K, 40 * K, 0.2);
      g.strokeStyle = 'rgba(10,10,10,.6)'; g.lineWidth = 1.5 * K;
      for (let i = 0; i < 9; i++) { let x = R() * N, y = R() * N; g.beginPath(); g.moveTo(x, y); for (let k = 0; k < 10; k++) { x += (R() - 0.5) * 60 * K; y += (R() - 0.5) * 60 * K; g.lineTo(x, y); } g.stroke(); }
      T.asph = mkTex(c);
    }
    return T;
  };

  /* ======================= 재질 ======================= */
  GX.materials = function (tier, T) {
    const low = tier === 'low', high = tier === 'high';
    const Std = (o) => {
      if (low) { const q = Object.assign({}, o); delete q.roughness; delete q.metalness; delete q.normalMap; delete q.normalScale; return new THREE.MeshLambertMaterial(q); }
      return new THREE.MeshStandardMaterial(Object.assign({ roughness: 0.85, metalness: 0.05 }, o));
    };
    const ns = new THREE.Vector2(0.6, 0.6);
    const M = {
      wall: Std({ map: T.wall, normalMap: T.wallN || null, normalScale: ns, color: 0xffffff, roughness: 0.93 }),
      tile: Std({ map: T.tile, normalMap: T.tileN || null, normalScale: ns, roughness: 0.7 }),
      conc: Std({ map: T.conc, normalMap: T.concN || null, normalScale: ns, roughness: 0.9 }),
      ceil: Std({ map: T.ceil, roughness: 0.95 }),
      paint: Std({ map: T.metal, color: 0x7d8a80, roughness: 0.7, metalness: 0.15 }),
      metal: Std({ map: T.metal, color: 0x9aa0a0, roughness: 0.5, metalness: 0.55 }),
      rust: Std({ map: T.rust, color: 0xffffff, roughness: 0.85, metalness: 0.3 }),
      wood: Std({ map: T.wood, roughness: 0.9 }),
      dark: Std({ color: 0x23282a, roughness: 0.55, metalness: 0.3 }),
      white: Std({ map: T.metal, color: 0xd8dbd6, roughness: 0.6, metalness: 0.1 }),
      door: Std({ map: T.metal, color: 0x56625e, roughness: 0.65, metalness: 0.3 }),
      truck: Std({ map: T.metal, color: 0x6c726c, roughness: 0.6, metalness: 0.35 }),
      glass: Std({ color: 0x0a0e10, roughness: 0.15, metalness: 0.4 }),
      rubber: Std({ color: 0x141414, roughness: 0.9 }),
      asph: Std({ map: T.asph, roughness: 0.95 }),
      facade: Std({ map: T.wall, color: 0x8a8a84, roughness: 0.95 }),
      scrap: Std({ vertexColors: true, roughness: 0.5, metalness: 0.5 }),
      ent: Std({ vertexColors: true, roughness: 0.75, metalness: 0.05 }),
      crew: Std({ vertexColors: true, roughness: 0.75, metalness: 0.05 }),
      lamp: new THREE.MeshBasicMaterial({ color: 0xffffff }),
      glow: new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }),
      label: new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, depthWrite: false, opacity: 0.85 }),
      screen: new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }),
    };
    M.paint.userData.inst = 1;
    // 손전등 원뿔(빛기둥처럼 보이게: 가장자리 · 끝으로 갈수록 흐려짐, 가산)
    M.cone = new THREE.ShaderMaterial({
      uniforms: { col: { value: new THREE.Color(0xfff1d6) }, op: { value: 0.11 } },
      vertexShader: 'varying vec3 vN; varying vec3 vV; varying float vL; void main(){ vec4 wp = modelMatrix * vec4(position,1.0); vN = normalize(normalMatrix * normal); vec4 mv = viewMatrix * wp; vV = normalize(-mv.xyz); vL = -position.y; gl_Position = projectionMatrix * mv; }',
      fragmentShader: 'uniform vec3 col; uniform float op; varying vec3 vN; varying vec3 vV; varying float vL; void main(){ float e = pow(abs(dot(vN, vV)), 1.6); float f = (1.0 - smoothstep(0.0, 1.0, vL)) * smoothstep(0.0, 0.06, vL); gl_FragColor = vec4(col * e * f * op, 1.0); }',
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    });
    M.dust = new THREE.PointsMaterial({ color: 0xfff1d6, size: 0.022, transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending });
    M.marker = new THREE.SpriteMaterial({ color: 0xffffff, depthTest: false, depthWrite: false, transparent: true });
    return M;
  };

  /* ======================= 형상 도우미 ======================= */
  function colorize(g, hex) {
    const n = g.attributes.position.count, c = new THREE.Color(hex), a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
    g.setAttribute('color', new THREE.BufferAttribute(a, 3));
    return g;
  }
  function part(geo, hex, x, y, z, rx, ry, rz) {
    let g = geo.index ? geo.toNonIndexed() : geo;
    if (g.attributes.uv) g.deleteAttribute('uv');
    g = colorize(g, hex);
    const m = new THREE.Matrix4().compose(new THREE.Vector3(x || 0, y || 0, z || 0), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx || 0, ry || 0, rz || 0)), new THREE.Vector3(1, 1, 1));
    g.applyMatrix4(m);
    return g;
  }
  const merge = (list) => THREE.BufferGeometryUtils.mergeGeometries(list, false);
  const B = (w, h, d) => new THREE.BoxGeometry(w, h, d);
  const Cy = (r0, r1, h, s) => new THREE.CylinderGeometry(r0, r1, h, s || 12);
  const Sp = (r, s) => new THREE.SphereGeometry(r, s || 10, Math.max(6, (s || 10) * 0.7 | 0));
  const To = (r, t, s) => new THREE.TorusGeometry(r, t, 6, s || 14);
  GX.part = part; GX.merge = merge;

  /* ======================= 시설 형상 ======================= */
  // 상자 면을 월드 좌표 UV로(벽 결이 이어지게)
  function pushQuad(P, Nn, U, a, b, c, d, n, uv) { const vs = [a, b, c, a, c, d], us = [uv[0], uv[1], uv[2], uv[0], uv[2], uv[3]]; for (let i = 0; i < 6; i++) { P.push(vs[i][0], vs[i][1], vs[i][2]); Nn.push(n[0], n[1], n[2]); U.push(us[i][0], us[i][1]); } }
  function pushBox(P, Nn, U, x0, y0, z0, x1, y1, z1, base, su, sv, skipTB) {
    const v = (y) => (y - base) / sv;
    pushQuad(P, Nn, U, [x1, y0, z0], [x1, y0, z1], [x1, y1, z1], [x1, y1, z0], [1, 0, 0], [[z0 / su, v(y0)], [z1 / su, v(y0)], [z1 / su, v(y1)], [z0 / su, v(y1)]]);
    pushQuad(P, Nn, U, [x0, y0, z1], [x0, y0, z0], [x0, y1, z0], [x0, y1, z1], [-1, 0, 0], [[-z1 / su, v(y0)], [-z0 / su, v(y0)], [-z0 / su, v(y1)], [-z1 / su, v(y1)]]);
    pushQuad(P, Nn, U, [x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [0, 0, -1], [[-x0 / su, v(y0)], [-x1 / su, v(y0)], [-x1 / su, v(y1)], [-x0 / su, v(y1)]]);
    pushQuad(P, Nn, U, [x1, y0, z1], [x0, y0, z1], [x0, y1, z1], [x1, y1, z1], [0, 0, 1], [[x1 / su, v(y0)], [x0 / su, v(y0)], [x0 / su, v(y1)], [x1 / su, v(y1)]]);
    if (!skipTB) {
      pushQuad(P, Nn, U, [x0, y1, z1], [x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [0, 1, 0], [[x0 / su, z1 / su], [x0 / su, z0 / su], [x1 / su, z0 / su], [x1 / su, z1 / su]]);
      pushQuad(P, Nn, U, [x0, y0, z0], [x0, y0, z1], [x1, y0, z1], [x1, y0, z0], [0, -1, 0], [[x0 / su, z0 / su], [x0 / su, z1 / su], [x1 / su, z1 / su], [x1 / su, z0 / su]]);
    }
  }
  function geoFrom(P, Nn, U) { const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(Nn, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(U, 2)); g.computeBoundingSphere(); return g; }
  // 바닥 · 천장 판(구멍 있는 칸은 들쭉날쭉한 원 구멍)
  function holeShapeGeo(x0, z0, s, cx, cz, r, seed, up) {
    const sh = new THREE.Shape(); sh.moveTo(x0, z0); sh.lineTo(x0 + s, z0); sh.lineTo(x0 + s, z0 + s); sh.lineTo(x0, z0 + s); sh.lineTo(x0, z0);
    const R = prng(seed), hole = new THREE.Path(), n = 14;
    for (let i = 0; i <= n; i++) { const a = i / n * TAU, rr = r * (0.82 + R() * 0.32); const x = cx + Math.cos(a) * rr, z = cz + Math.sin(a) * rr; if (i === 0) hole.moveTo(x, z); else hole.lineTo(x, z); }
    sh.holes.push(hole);
    const g = new THREE.ShapeGeometry(sh);
    const p = g.attributes.position, P = [], Nn = [], U = [], idx = g.index.array;
    for (let k = 0; k < idx.length; k += 3) {
      const tri = up ? [idx[k], idx[k + 2], idx[k + 1]] : [idx[k], idx[k + 1], idx[k + 2]];
      for (const i of tri) { const x = p.getX(i), z = p.getY(i); P.push(x, 0, z); Nn.push(0, up ? 1 : -1, 0); U.push(x / 4, z / 4); }
    }
    g.dispose();
    return [P, Nn, U];
  }
  GX.buildFacility = function (F, D, M, tier) {
    const C = D.C, FH = D.FH, CEIL = D.CEIL, YARD = D.YARD, GW = F.GW, GH = F.GH;
    const site = D.SITES[F.site];
    const group = new THREE.Group();
    const own = [];
    const add = (mesh) => { group.add(mesh); own.push(mesh); mesh.matrixAutoUpdate = false; mesh.updateMatrix(); return mesh; };
    const shadow = tier !== 'low';
    // 벽(층마다 하나로 합침)
    const wallMat = M.wall.clone(); wallMat.color.setHex(site.wall[0]);
    M._wallSite = wallMat;
    { const P = [], Nn = [], U = [];
      for (let f = 0; f < 2; f++) for (const b of F.walls[f]) pushBox(P, Nn, U, b[0], b[4], b[1], b[2], b[5], b[3], -f * FH, 4, 3.2, b[5] - b[4] > 0.9);
      const m = add(new THREE.Mesh(geoFrom(P, Nn, U), wallMat)); m.castShadow = shadow; m.receiveShadow = shadow; }
    // 바닥 · 천장
    const holeSet = {}; for (const h of F.holes) holeSet[h.ci] = h;
    const floorP = [[], [], []], floorN = [[], [], []], floorU = [[], [], []];   // 0 1층 바닥(결: 사이트) 1 2층 바닥 2 계단(콘크리트)
    const ceilP = [], ceilN = [], ceilU = [];
    const quadUp = (P, Nn, U, x0, z0, x1, z1, y) => pushQuad(P, Nn, U, [x0, y, z1], [x1, y, z1], [x1, y, z0], [x0, y, z0], [0, 1, 0], [[x0 / 4, z1 / 4], [x1 / 4, z1 / 4], [x1 / 4, z0 / 4], [x0 / 4, z0 / 4]]);
    const quadDn = (P, Nn, U, x0, z0, x1, z1, y) => pushQuad(P, Nn, U, [x0, y, z0], [x1, y, z0], [x1, y, z1], [x0, y, z1], [0, -1, 0], [[x0 / 4, z0 / 4], [x1 / 4, z0 / 4], [x1 / 4, z1 / 4], [x0 / 4, z1 / 4]]);
    for (let f = 0; f < 2; f++) for (let ci = 0; ci < GW * GH; ci++) {
      const r = F.cell[f][ci]; if (r < 0) continue;
      const room = F.rooms[r], gx = ci % GW, gz = (ci / GW) | 0, x0 = gx * C, z0 = gz * C, yb = -f * FH;
      if (room.m === 'stair') continue;
      const hole = holeSet[ci];
      if (f === 0 && hole) { const [p, n, u] = holeShapeGeo(x0, z0, C, hole.x, hole.z, 0.85, 77 + ci, true); floorP[0].push(...p); floorN[0].push(...n); floorU[0].push(...u); }
      else quadUp(floorP[f], floorN[f], floorU[f], x0, z0, x0 + C, z0 + C, yb);
      if (f === 1 && hole) { const [p, n, u] = holeShapeGeo(x0, z0, C, hole.x, hole.z, 0.85, 77 + ci, false); for (let i = 1; i < p.length; i += 3) p[i] = yb + CEIL; ceilP.push(...p); ceilN.push(...n); ceilU.push(...u); }
      else quadDn(ceilP, ceilN, ceilU, x0, z0, x0 + C, z0 + C, yb + CEIL);
    }
    // 계단: 디딤판 + 층계참 + 천장
    for (const st of F.stairs) {
      const along = st.ax !== 0, len = 8, wid = 4, steps = 20;
      const at = (s, t) => along ? [st.sx + st.ax * s, st.z0 + t] : [st.x0 + t, st.sz + st.az * s];
      const box = (s0, s1, t0, t1, y0, y1) => { const a = at(s0, t0), b = at(s1, t1); pushBox(floorP[2], floorN[2], floorU[2], Math.min(a[0], b[0]), y0, Math.min(a[1], b[1]), Math.max(a[0], b[0]), y1, Math.max(a[1], b[1]), 0, 4, 4); };
      box(0, 1.0, 0.1, wid - 0.1, -0.25, 0);
      for (let i = 0; i < steps; i++) { const s0 = 1 + i * 6 / steps, y = -FH * (i + 1) / steps; box(s0, s0 + 6 / steps + 0.02, 0.1, wid - 0.1, y - 0.25, y + FH / steps * 0.5); }
      box(7.0, len, 0.1, wid - 0.1, -FH - 0.25, -FH);
      quadDn(ceilP, ceilN, ceilU, st.x0, st.z0, st.x0 + st.w, st.z0 + st.h, CEIL);
      // 난간(벽에 붙은 손잡이)
      const a = at(1, 0.25), b = at(7, 0.25);
      void a; void b;
    }
    const fm0 = site.floor === 'tile' ? M.tile : M.conc;
    [[0, fm0], [1, M.conc], [2, M.conc]].forEach(([i, mat]) => { if (!floorP[i].length) return; const m = add(new THREE.Mesh(geoFrom(floorP[i], floorN[i], floorU[i]), mat)); m.receiveShadow = shadow; if (i === 2) m.castShadow = shadow; });
    { const m = add(new THREE.Mesh(geoFrom(ceilP, ceilN, ceilU), M.ceil)); m.receiveShadow = shadow; }
    // 구멍 테두리(부서진 슬래브)
    for (const h of F.holes) {
      const m = add(new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.82, 14, 1, true), new THREE.MeshBasicMaterial({ color: 0x1a1918, side: THREE.BackSide })));
      m.position.set(h.x, -0.41, h.z); m.updateMatrix(); m.userData.ownMat = 1;
    }
    // 소품: 상자 · 원기둥을 재질별 인스턴스로
    const boxes = {}, cyls = {};
    const addB = (mat, x, y, z, w, h, d, ry, tint) => (boxes[mat] || (boxes[mat] = [])).push([x, y, z, w, h, d, ry || 0, tint == null ? 1 : tint]);
    const addC = (mat, x, y, z, r, h, rx, rz, tint) => (cyls[mat] || (cyls[mat] = [])).push([x, y, z, r, h, rx || 0, rz || 0, tint == null ? 1 : tint]);
    const glows = [];   // [x,y,z,w,h,d,색]
    const R = prng(F.seed ^ 0x77);
    for (const p of F.props) {
      const yb = -p.f * FH, x = p.x, z = p.z, w = p.w, d = p.d, hh = p.hgt, rot = p.rot, tn = 0.85 + R() * 0.3;
      const along = (fn) => fn(rot ? d : w, rot ? w : d);   // 소품 고유 가로(긴 쪽) · 깊이
      void along;
      const L = Math.max(w, d), Dp = Math.min(w, d), ry = w >= d ? 0 : Math.PI / 2;
      const off = (a, b) => (w >= d ? [x + a, z + b] : [x + b, z + a]);   // (긴 쪽 a, 깊이 b) → 월드
      switch (p.k) {
        case 'desk': addB('paint', x, yb + hh - 0.03, z, w, 0.05, d, 0, tn); { const [x1, z1] = off(-L / 2 + 0.04, 0), [x2, z2] = off(L / 2 - 0.04, 0); addB('paint', x1, yb + (hh - 0.05) / 2, z1, w >= d ? 0.05 : Dp, hh - 0.05, w >= d ? Dp : 0.05, 0, tn * 0.8); addB('paint', x2, yb + (hh - 0.05) / 2, z2, w >= d ? 0.05 : Dp, hh - 0.05, w >= d ? Dp : 0.05, 0, tn * 0.8); } break;
        case 'cab': case 'locker': addB('paint', x, yb + hh / 2, z, w, hh, d, 0, tn * (p.k === 'locker' ? 0.75 : 1)); addB('dark', x, yb + hh * 0.66, z, w * 1.002, 0.02, d * 1.002, 0); addB('dark', x, yb + hh * 0.33, z, w * 1.002, 0.02, d * 1.002, 0); break;
        case 'shelf': case 'rackp': {
          const mat = p.k === 'rackp' ? 'rust' : 'metal', post = p.k === 'rackp' ? 0.08 : 0.04;
          for (const a of [-L / 2 + post / 2, L / 2 - post / 2]) for (const b of [-Dp / 2 + post / 2, Dp / 2 - post / 2]) { const [px, pz] = off(a, b); addB(mat, px, yb + hh / 2, pz, post, hh, post, 0, tn); }
          const lv = p.k === 'rackp' ? [0.12, 1.3, 2.5] : [0.12, 0.62, 1.12, 1.62, 2.06];
          for (const yy of lv) addB(p.k === 'rackp' ? 'rust' : 'metal', x, yb + yy, z, w, 0.04, d, 0, tn * 0.9);
          if (p.k === 'rackp') { for (const yy of [0.14, 1.32]) { addB('wood', x, yb + yy + 0.08, z, w * 0.9, 0.12, d * 0.85, 0, 0.8); if (R() < 0.7) addB('wood', x + (R() - 0.5) * 0.4, yb + yy + 0.55, z, Math.min(w, 1.0) * 0.8, 0.8, Math.min(d, 1.0) * 0.8, 0, 0.9 + R() * 0.2); } }
          else for (const yy of [0.62, 1.12, 1.62]) if (R() < 0.6) addB(R() < 0.5 ? 'wood' : 'paint', x + (R() - 0.5) * (w * 0.5), yb + yy + 0.14, z + (R() - 0.5) * (d * 0.3), 0.3 + R() * 0.3, 0.24, 0.28, 0, 0.8 + R() * 0.3);
          break;
        }
        case 'bench': addB('dark', x, yb + hh - 0.03, z, w, 0.06, d, 0); addB('paint', x, yb + (hh - 0.06) / 2, z, w * 0.98, hh - 0.08, d * 0.9, 0, tn); break;
        case 'hood': addB('paint', x, yb + 0.45, z, w, 0.9, d, 0, tn); addB('paint', x, yb + 1.75, z, w, 0.9, d, 0, tn); { const [gx2, gz2] = off(0, Dp / 2 - 0.02); addB('glass', gx2, yb + 1.35, gz2, w >= d ? w * 0.9 : 0.03, 0.8, w >= d ? 0.03 : d * 0.9, 0); } addB('metal', x, yb + 0.92, z, w, 0.04, d, 0); break;
        case 'tank': addC('metal', x, yb + hh / 2, z, w / 2, hh, 0, 0, tn); addC('dark', x, yb + hh + 0.06, z, w / 2.6, 0.12, 0, 0); break;
        case 'boiler': addC('rust', x, yb + hh / 2, z, w / 2, hh, 0, 0, 1); addC('rust', x, yb + 0.1, z, w / 2 + 0.08, 0.2, 0, 0, 0.7); addC('metal', x + w * 0.2, yb + (hh + 3.1) / 2, z, 0.12, CEIL - hh, 0, 0); addC('metal', x - w * 0.25, yb + (hh + 3.1) / 2, z + 0.2, 0.08, CEIL - hh, 0, 0); glows.push([x, yb + 1.2, z + w / 2 + 0.01, 0.14, 0.14, 0.02, 0xff7a3a]); break;
        case 'crate': addB('wood', x, yb + hh / 2, z, w, hh, d, R() * 0.3, tn); break;
        case 'crate2': addB('wood', x, yb + 0.45, z, w, 0.9, d, 0, tn); addB('wood', x + 0.05, yb + 1.3, z - 0.04, w * 0.85, 0.8, d * 0.85, 0.1, tn * 0.9); break;
        case 'server': addB('dark', x, yb + hh / 2, z, w, hh, d, 0); for (let i = 0; i < 6; i++) { const [lx, lz] = off((R() - 0.5) * L * 0.6, Dp / 2 + 0.005); glows.push([lx, yb + 0.4 + R() * 1.4, lz, w >= d ? 0.03 : 0.012, 0.012, w >= d ? 0.012 : 0.03, R() < 0.7 ? 0x3cff7a : 0xffb02e]); } break;
        case 'console': addB('dark', x, yb + 0.5, z, w, 1.0, d, 0); addB('dark', x, yb + 1.08, z, w, 0.16, d * 0.7, 0); for (let i = 0; i < 5; i++) { const [lx, lz] = off(-L / 2 + 0.25 + i * (L - 0.5) / 4, 0); glows.push([lx, yb + 1.0, lz, 0.05, 0.02, 0.05, R() < 0.5 ? 0xff5a3a : 0xffc04a]); } break;
        case 'freezer': addB('white', x, yb + hh / 2, z, w, hh, d, 0, tn); { const [hx, hz] = off(L * 0.3, Dp / 2 + 0.03); addB('metal', hx, yb + 1.1, hz, 0.04, 0.5, 0.04, 0); } break;
        case 'turbine': { const ax = rot ? 1 : 0; addB('dark', x, yb + 0.3, z, w * 0.9, 0.6, d * 0.9, 0); if (!ax) addC('metal', x, yb + 1.25, z, Dp / 2 * 0.9, L * 0.95, 0, Math.PI / 2, tn); else addC('metal', x, yb + 1.25, z, Dp / 2 * 0.9, L * 0.95, Math.PI / 2, 0, tn); break; }
        case 'press': addB('rust', x, yb + 0.6, z, w, 1.2, d, 0, tn); addC('metal', x, yb + 1.4, z, Dp * 0.3, 0.4, 0, 0); break;
        case 'barrel': addC('rust', x, yb + hh / 2, z, w / 2, hh, 0, 0, tn); break;
        case 'pallet': addB('wood', x, yb + hh / 2, z, w, hh, d, 0, tn * 0.8); if (R() < 0.6) addB('wood', x, yb + hh + 0.3, z, w * 0.8, 0.6, d * 0.8, 0, tn); break;
        default: addB('paint', x, yb + hh / 2, z, w, hh, d, 0, tn);
      }
    }
    // 마당 소품
    for (const p of F.yard) { if (p.k === 'cont') { addB('rust', p.x, p.hgt / 2, p.z, p.w, p.hgt, p.d, 0, 0.8); } else addC('rust', p.x, p.hgt / 2, p.z, p.w / 2, p.hgt, 0, 0, 0.9); }
    // 문틀(모든 문틀 · 문 자리)
    const frames = [];
    for (let f = 0; f < 2; f++) {
      const yb = -f * FH;
      for (let gz = 0; gz < GH; gz++) for (let gx = 0; gx <= GW; gx++) { const e = F.eV[f][gx + gz * (GW + 1)]; if (e >= 2) frames.push([1, gx * C, gz * C + C / 2, yb]); }
      for (let gz = 0; gz <= GH; gz++) for (let gx = 0; gx < GW; gx++) { const e = F.eH[f][gx + gz * GW]; if (e >= 2 || (f === 0 && gz === YARD && gx === F.ex)) frames.push([0, gx * C + C / 2, gz * C, yb, f === 0 && gz === YARD && gx === F.ex]); }
    }
    for (const fr of frames) {
      const [v, x, z, yb, main] = fr, top = main ? 2.6 : 2.2, half = (D.GAP1 - D.GAP0) / 2;
      if (v) { addB('metal', x, yb + top / 2, z - half - 0.04, 0.26, top, 0.08, 0, 0.6); addB('metal', x, yb + top / 2, z + half + 0.04, 0.26, top, 0.08, 0, 0.6); addB('metal', x, yb + top + 0.04, z, 0.26, 0.08, half * 2 + 0.16, 0, 0.6); }
      else { addB('metal', x - half - 0.04, yb + top / 2, z, 0.08, top, 0.26, 0, 0.6); addB('metal', x + half + 0.04, yb + top / 2, z, 0.08, top, 0.26, 0, 0.6); addB('metal', x, yb + top + 0.04, z, half * 2 + 0.16, 0.08, 0.26, 0, 0.6); }
    }
    // 배관(복도 천장을 따라)
    for (const r of F.rooms) {
      if (r.k !== 'cor' || r.m === 'entry') continue;
      const yb = -r.f * FH;
      for (const ci of r.cells) { const gx = ci % GW, gz = (ci / GW) | 0; if (R() < 0.6) { const hor = R() < 0.5; addC(R() < 0.5 ? 'rust' : 'metal', gx * C + (hor ? C / 2 : 0.5 + R() * 0.4), yb + CEIL - 0.25, gz * C + (hor ? 0.5 + R() * 0.4 : C / 2), 0.07 + R() * 0.05, C, hor ? 0 : Math.PI / 2, hor ? Math.PI / 2 : 0, 0.8); } }
    }
    const unitB = new THREE.BoxGeometry(1, 1, 1), unitC = new THREE.CylinderGeometry(1, 1, 1, tier === 'low' ? 10 : 16);
    const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v3 = new THREE.Vector3(), s3 = new THREE.Vector3(), col = new THREE.Color();
    for (const k in boxes) {
      const arr = boxes[k], im = new THREE.InstancedMesh(unitB, M[k], arr.length);
      arr.forEach((b, i) => { e.set(0, b[6], 0); q.setFromEuler(e); v3.set(b[0], b[1], b[2]); s3.set(b[3], b[4], b[5]); m4.compose(v3, q, s3); im.setMatrixAt(i, m4); col.setScalar(b[7]); im.setColorAt(i, col); });
      im.castShadow = shadow; im.receiveShadow = shadow; add(im);
    }
    for (const k in cyls) {
      const arr = cyls[k], im = new THREE.InstancedMesh(unitC, M[k], arr.length);
      arr.forEach((b, i) => { e.set(b[5], 0, b[6]); q.setFromEuler(e); v3.set(b[0], b[1], b[2]); s3.set(b[3], b[4], b[3]); m4.compose(v3, q, s3); im.setMatrixAt(i, m4); col.setScalar(b[7]); im.setColorAt(i, col); });
      im.castShadow = shadow; im.receiveShadow = shadow; add(im);
    }
    // 작은 표시등(서버 · 제어반 · 보일러 창)
    if (glows.length) { const im = new THREE.InstancedMesh(unitB, M.glow, glows.length); glows.forEach((g, i) => { m4.compose(v3.set(g[0], g[1], g[2]), q.identity(), s3.set(g[3], g[4], g[5])); im.setMatrixAt(i, m4); im.setColorAt(i, col.setHex(g[6]).multiplyScalar(0.55)); }); add(im); }
    // 천장 등(틀 + 관): 관 색은 view가 매 프레임 바꿈(깜빡임)
    const lampTube = new THREE.InstancedMesh(unitB, M.lamp, F.lamps.length), lampHouse = new THREE.InstancedMesh(unitB, M.dark, F.lamps.length);
    F.lamps.forEach((l, i) => {
      const ry = l.rot ? Math.PI / 2 : 0; e.set(0, ry, 0); q.setFromEuler(e);
      m4.compose(v3.set(l.x, l.y + 0.02, l.z), q, s3.set(1.3, 0.07, 0.26)); lampHouse.setMatrixAt(i, m4);
      m4.compose(v3.set(l.x, l.y - 0.03, l.z), q, s3.set(1.18, 0.035, 0.12)); lampTube.setMatrixAt(i, m4);
      lampTube.setColorAt(i, col.setScalar(l.s ? 1 : 0.08));
    });
    add(lampHouse); add(lampTube);
    // 문짝(인스턴스 — 열림 각도는 view가 갱신) · 잠금등
    const doorMesh = new THREE.InstancedMesh(unitB, M.door, Math.max(1, F.doors.length)); doorMesh.castShadow = shadow; doorMesh.receiveShadow = shadow;
    const lockMesh = new THREE.InstancedMesh(unitB, M.glow, Math.max(1, F.doors.length));
    add(doorMesh); add(lockMesh);
    // 방 표지(글 지도 한 장)
    let labels = null;
    if (F.labels.length) {
      const n = F.labels.length, cols = 4, rows = Math.ceil(n / cols), c = document.createElement('canvas'); c.width = 1024; c.height = Math.max(64, rows * 64);
      const g = c.getContext('2d'); g.clearRect(0, 0, c.width, c.height);
      g.font = '600 30px "IBM Plex Mono", "IBM Plex Sans KR", monospace'; g.textBaseline = 'middle';
      F.labels.forEach((lb, i) => { const x = (i % cols) * 256, y = ((i / cols) | 0) * 64; g.fillStyle = 'rgba(20,20,18,.72)'; g.fillRect(x + 6, y + 10, 244, 44); g.fillStyle = 'rgba(214,206,182,.9)'; g.fillText(lb.t.split(' ')[0], x + 16, y + 32); g.font = '500 22px "IBM Plex Sans KR", sans-serif'; g.fillText(lb.t.split(' ').slice(1).join(' ').slice(0, 7), x + 100, y + 33); g.font = '600 30px "IBM Plex Mono", "IBM Plex Sans KR", monospace'; });
      const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
      const P = [], Nn = [], U = [];
      F.labels.forEach((lb, i) => {
        const r = F.rooms[lb.r], yb = -r.f * FH + 1.85;
        // 방 안쪽 벽(문이 아닌 첫 벽) 가운데
        let spot = null;
        for (const ci of r.cells) { if (spot) break; const gx = ci % GW, gz = (ci / GW) | 0; for (let d = 0; d < 4; d++) { if (F.getEdge(r.f, gx, gz, d) !== 1) continue; const [dx, dz] = D.DIRS[d]; if (F.cell[r.f][(gx + dx) + (gz + dz) * GW] === r.id) continue; spot = [gx * C + C / 2 + dx * (C / 2 - 0.115), gz * C + C / 2 + dz * (C / 2 - 0.115), dx, dz]; break; } }
        if (!spot) return;
        const [cx, cz, dx, dz] = spot, hw = 0.6, hh = 0.15, u0 = (i % 4) / 4, v0 = 1 - (((i / 4) | 0) + 1) * 64 / c.height, u1 = u0 + 0.25, v1 = v0 + 64 / c.height;
        const tx = -dz, tz = dx;   // 벽을 따라가는 방향(안쪽에서 보면 오른쪽)
        const a = [cx - tx * hw, yb - hh, cz - tz * hw], b = [cx + tx * hw, yb - hh, cz + tz * hw], cc = [cx + tx * hw, yb + hh, cz + tz * hw], dd = [cx - tx * hw, yb + hh, cz - tz * hw];
        // 안쪽을 보게(법선 = -d)
        pushQuad(P, Nn, U, b, a, dd, cc, [-dx, 0, -dz], [[u0, v0], [u1, v0], [u1, v1], [u0, v1]]);
      });
      if (P.length) { const mat = M.label.clone(); mat.map = tex; labels = add(new THREE.Mesh(geoFrom(P, Nn, U), mat)); labels.userData.ownMat = 1; }
    }
    // 바깥: 마당 바닥 · 정면 벽 · 지붕 테두리 · 울타리 기둥 · 정문 위 등
    const Wd = GW * C, Hy = YARD * C;
    { const P = [], Nn = [], U = []; quadUp(P, Nn, U, -60, -40, Wd + 60, Hy, 0); const m = add(new THREE.Mesh(geoFrom(P, Nn, U), M.asph)); m.receiveShadow = shadow; }
    { const P = [], Nn = [], U = [], mx0 = F.ex * C + D.GAP0, mx1 = F.ex * C + D.GAP1, z0 = Hy - 0.13, z1 = Hy - 0.11 + 0.0;
      pushBox(P, Nn, U, -40, 0, z0 - 0.5, mx0 - 0.0, 11, z1, 0, 6, 6, true); pushBox(P, Nn, U, mx1, 0, z0 - 0.5, Wd + 40, 11, z1, 0, 6, 6, true); pushBox(P, Nn, U, mx0, 2.6, z0 - 0.5, mx1, 11, z1, 0, 6, 6, true);
      // 지붕(시설 위 덮개 — 위에서 들어오는 하늘빛 막기)
      pushBox(P, Nn, U, -1, CEIL + 0.02, Hy - 0.6, Wd + 1, CEIL + 0.5, GH * C + 1, 0, 6, 6, false);
      const fm = M.facade.clone(); fm.color.setHex(site.wall[1]);
      const m = add(new THREE.Mesh(geoFrom(P, Nn, U), fm)); m.userData.ownMat = 1; m.receiveShadow = shadow; }
    // 정문 위 차양과 나트륨등(깜빡임 없음, 어둑)
    addB('dark', F.mainDoor.x, 2.95, Hy - 0.9, 3.4, 0.12, 1.8, 0);
    const glowsOut = new THREE.InstancedMesh(unitB, M.glow, 1); m4.compose(v3.set(F.mainDoor.x, 2.86, Hy - 1.1), q.identity(), s3.set(0.5, 0.05, 0.2)); glowsOut.setMatrixAt(0, m4); glowsOut.setColorAt(0, col.setHex(0xffb060)); add(glowsOut);
    return { group, own, lampTube, doorMesh, lockMesh, labels, wallMat, dispose() { for (const o of own) { if (o.isInstancedMesh) o.dispose(); if (o.geometry && o.geometry !== unitB && o.geometry !== unitC) o.geometry.dispose(); if (o.userData.ownMat) o.material.dispose(); } unitB.dispose(); unitC.dispose(); wallMat.dispose(); } };
  };

  /* ======================= 트럭 ======================= */
  GX.truck = function (F, M) {
    const T = F.truck, g = new THREE.Group(), x = T.x, bz0 = T.bed[1], bz1 = T.bed[3], zf = T.z - T.l / 2, bx0 = T.bed[0], bx1 = T.bed[2], y = T.bedY;
    const box = (mat, cx, cy, cz, w, h, d) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(cx, cy, cz); m.castShadow = m.receiveShadow = true; g.add(m); return m; };
    // 운전석
    box(M.truck, x, 1.35, (zf + bz0) / 2, T.w, 1.9, bz0 - zf);
    box(M.glass, x, 1.75, zf + 0.02, T.w * 0.86, 0.7, 0.04);
    box(M.glass, bx0 - 0.03, 1.8, (zf + bz0) / 2 - 0.2, 0.04, 0.55, 1.0); box(M.glass, bx1 + 0.03, 1.8, (zf + bz0) / 2 - 0.2, 0.04, 0.55, 1.0);
    box(M.dark, x, 0.55, zf - 0.08, T.w + 0.1, 0.35, 0.16);
    // 짐칸
    box(M.truck, x, y - 0.12, (bz0 + bz1) / 2, T.w, 0.24, bz1 - bz0);
    box(M.truck, bx0 - 0.02, y + 1.4, (bz0 + bz1) / 2, 0.08, 2.8, bz1 - bz0);
    box(M.truck, bx1 + 0.02, y + 1.4, (bz0 + bz1) / 2, 0.08, 2.8, bz1 - bz0);
    box(M.truck, x, y + 2.84, (bz0 + bz1) / 2, T.w + 0.08, 0.08, bz1 - bz0);
    box(M.truck, x, y + 1.4, bz0 + 0.04, T.w, 2.8, 0.08);
    // 경사판
    const ramp = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.06, 1.5), M.metal); ramp.position.set(x, y / 2 - 0.02, bz1 + 0.72); ramp.rotation.x = Math.atan2(y, 1.4); ramp.receiveShadow = true; g.add(ramp);
    // 바퀴
    for (const zz of [zf + 1.0, bz1 - 1.0]) for (const xx of [bx0 + 0.05, bx1 - 0.05]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.32, 14), M.rubber); w.rotation.z = Math.PI / 2; w.position.set(xx + (xx < x ? -0.12 : 0.12), 0.45, zz); g.add(w); }
    // 단말 · 레버 · 천장 등
    box(M.dark, x - 0.55, y + 1.2, bz0 + 0.2, 0.9, 0.7, 0.24);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.74, 0.5), M.screen); scr.position.set(x - 0.55, y + 1.22, bz0 + 0.33); g.add(scr);
    box(M.dark, x + 0.75, y + 0.9, bz0 + 0.2, 0.3, 0.3, 0.2);
    const lever = box(M.metal, x + 0.75, y + 1.25, bz0 + 0.28, 0.05, 0.5, 0.05); lever.rotation.x = -0.4;
    const knob = box(M.glow, x + 0.75, y + 1.5, bz0 + 0.38, 0.09, 0.09, 0.09); knob.material = new THREE.MeshBasicMaterial({ color: 0xc23b2a });
    box(M.dark, x, y + 2.74, (bz0 + bz1) / 2, 0.3, 0.08, 1.2);
    const tube = box(M.lamp, x, y + 2.69, (bz0 + bz1) / 2, 0.12, 0.03, 1.1);
    // 장비함(왼쪽 벽 선반)
    box(M.paint, bx0 + 0.25, y + 0.5, bz0 + 1.6, 0.4, 1.0, 1.6);
    g.traverse((o) => { if (o.isMesh) { o.matrixAutoUpdate = false; o.updateMatrix(); } });
    return { group: g, screen: scr, lever, knob, tube, lamp: [x, y + 2.5, (bz0 + bz1) / 2], term: [x - 0.55, y + 1.2, bz0 + 0.4], leverPos: [x + 0.75, y + 1.2, bz0 + 0.4] };
  };

  /* ======================= 고철 · 장비 모형 (꼭짓점 색 하나로 합침) ======================= */
  const COL = { brass: 0xb08a3c, copper: 0xb4683f, steel: 0x8d9599, dark: 0x26292a, green: 0x41594c, red: 0x7a2c25, cream: 0xc8bfa6, glass: 0x9fb6b8, rubber: 0x161616, gold: 0xd0aa4a, white: 0xd4d6d2, olive: 0x5d5f3a, blue: 0x34495a, orange: 0xb0612a, wood: 0x7b5a36, frost: 0xdfe8ee, crystal: 0x8fd6c8 };
  GX.COL = COL;
  GX.itemGeo = function (shape) {
    const P = [];
    const p = (g, c, x, y, z, rx, ry, rz) => P.push(part(g, COL[c] != null ? COL[c] : c, x, y, z, rx, ry, rz));
    switch (shape) {
      case 'coil': p(Cy(0.17, 0.17, 0.26, 14), 'copper', 0, 0.13, 0); p(Cy(0.07, 0.07, 0.3, 8), 'dark', 0, 0.15, 0); break;
      case 'valve': p(Cy(0.08, 0.08, 0.34, 10), 'brass', 0, 0.08, 0, 0, 0, Math.PI / 2); p(Cy(0.03, 0.03, 0.2, 6), 'brass', 0, 0.2, 0); p(To(0.1, 0.018, 14), 'red', 0, 0.3, 0, Math.PI / 2); break;
      case 'gauge': p(Cy(0.15, 0.15, 0.07, 16), 'steel', 0, 0.15, 0, Math.PI / 2); p(Cy(0.125, 0.125, 0.01, 16), 'cream', 0, 0.15, 0.036, Math.PI / 2); p(B(0.01, 0.1, 0.01), 'red', 0.02, 0.17, 0.044, 0, 0, -0.6); p(Cy(0.025, 0.025, 0.1, 6), 'brass', 0, 0.03, 0); break;
      case 'pcb': for (let i = 0; i < 4; i++) p(B(0.32, 0.012, 0.22), i % 2 ? 'green' : 0x2f6a40, 0, 0.01 + i * 0.016, 0, 0, i * 0.08); p(B(0.03, 0.08, 0.24), 'cream', 0, 0.04, 0); break;
      case 'box': p(B(0.36, 0.22, 0.26), 'olive', 0, 0.11, 0); p(B(0.37, 0.03, 0.27), 'dark', 0, 0.2, 0); break;
      case 'box2': p(B(0.22, 0.12, 0.16), 'dark', 0, 0.06, 0); p(B(0.2, 0.02, 0.14), 'gold', 0, 0.125, 0); break;
      case 'centri': p(Cy(0.26, 0.28, 0.32, 16), 'white', 0, 0.16, 0); p(Cy(0.2, 0.2, 0.06, 16), 'steel', 0, 0.35, 0); p(B(0.2, 0.06, 0.04), 'dark', 0, 0.12, 0.27); break;
      case 'cryo': p(Cy(0.11, 0.11, 0.42, 14), 'frost', 0, 0.21, 0); p(Cy(0.08, 0.08, 0.08, 10), 'blue', 0, 0.46, 0); break;
      case 'tank': p(Cy(0.11, 0.11, 0.7, 12), 0x3d6b57, 0, 0.35, 0, Math.PI / 2, 0, 0); p(Sp(0.11, 10), 0x3d6b57, 0, 0.11, 0.35); p(Cy(0.03, 0.03, 0.1, 6), 'brass', 0, 0.11, 0.48, Math.PI / 2); p(Sp(0.11, 10), 0x3d6b57, 0, 0.11, -0.35); break;
      case 'tbox': p(B(0.46, 0.2, 0.2), 'red', 0, 0.1, 0); p(B(0.2, 0.04, 0.03), 'dark', 0, 0.24, 0); break;
      case 'gen': p(B(0.8, 0.5, 0.5), 'orange', 0, 0.3, 0); p(B(0.82, 0.04, 0.52), 'dark', 0, 0.56, 0); p(Cy(0.04, 0.04, 0.9, 6), 'dark', 0, 0.62, 0.26, 0, 0, Math.PI / 2); p(Cy(0.04, 0.04, 0.9, 6), 'dark', 0, 0.62, -0.26, 0, 0, Math.PI / 2); p(Cy(0.12, 0.12, 0.06, 12), 'steel', 0.25, 0.3, 0.26, Math.PI / 2); break;
      case 'xcore': for (let i = 0; i < 7; i++) p(B(0.7, 0.05, 0.42), i % 2 ? 0x5a5e60 : 0x6a6e70, 0, 0.03 + i * 0.055, 0); p(B(0.2, 0.42, 0.42), 'copper', 0, 0.21, 0); break;
      case 'safe': p(B(0.6, 0.55, 0.5), 0x3a3d3a, 0, 0.275, 0); p(Cy(0.08, 0.08, 0.04, 14), 'steel', 0.08, 0.32, 0.26, Math.PI / 2); p(B(0.04, 0.16, 0.04), 'steel', -0.18, 0.3, 0.26); break;
      case 'type': p(B(0.42, 0.12, 0.34), 'dark', 0, 0.06, 0); p(B(0.42, 0.1, 0.12), 'dark', 0, 0.16, -0.1, -0.4); p(Cy(0.04, 0.04, 0.46, 8), 'rubber', 0, 0.24, -0.13, 0, 0, Math.PI / 2); for (let i = 0; i < 3; i++) p(B(0.34, 0.012, 0.04), 'cream', 0, 0.125, 0.04 + i * 0.05); break;
      case 'radio': p(B(0.44, 0.24, 0.28), 0x3e4434, 0, 0.12, 0); p(B(0.4, 0.18, 0.01), 'dark', 0, 0.13, 0.145); p(Cy(0.03, 0.03, 0.03, 10), 'cream', -0.12, 0.13, 0.155, Math.PI / 2); p(Cy(0.03, 0.03, 0.03, 10), 'cream', 0.12, 0.13, 0.155, Math.PI / 2); break;
      case 'scale': p(B(0.36, 0.06, 0.26), 'cream', 0, 0.03, 0); p(Cy(0.11, 0.11, 0.015, 16), 'steel', 0, 0.075, 0); p(B(0.12, 0.08, 0.02), 'dark', 0, 0.06, 0.13); break;
      case 'cart': p(Cy(0.06, 0.06, 0.24, 10), 'steel', 0, 0.12, 0); p(Cy(0.065, 0.065, 0.04, 10), 'gold', 0, 0.24, 0); break;
      case 'gear': p(Cy(0.3, 0.3, 0.1, 18), 'steel', 0, 0.05, 0); for (let i = 0; i < 12; i++) { const a = i / 12 * TAU; p(B(0.08, 0.1, 0.06), 'steel', Math.cos(a) * 0.32, 0.05, Math.sin(a) * 0.32, 0, -a); } p(Cy(0.07, 0.07, 0.14, 10), 'dark', 0, 0.06, 0); break;
      case 'pump': p(Cy(0.18, 0.18, 0.44, 14), 'blue', 0, 0.2, 0, 0, 0, Math.PI / 2); p(B(0.5, 0.06, 0.36), 'dark', 0, 0.03, 0); p(Cy(0.06, 0.06, 0.24, 8), 'steel', 0.12, 0.36, 0); p(Cy(0.06, 0.06, 0.24, 8), 'steel', -0.32, 0.2, 0, 0, 0, Math.PI / 2); break;
      case 'proj': p(B(0.32, 0.2, 0.2), 'dark', 0, 0.12, 0); p(Cy(0.05, 0.05, 0.14, 10), 'steel', 0, 0.13, 0.16, Math.PI / 2); p(Cy(0.11, 0.11, 0.02, 14), 'steel', -0.08, 0.32, 0, 0, 0, Math.PI / 2); break;
      case 'scope': p(B(0.2, 0.04, 0.22), 'dark', 0, 0.02, 0); p(B(0.04, 0.28, 0.06), 'cream', 0, 0.16, -0.07); p(Cy(0.03, 0.03, 0.2, 10), 'cream', 0, 0.3, -0.02, 0.4); p(Cy(0.07, 0.07, 0.015, 12), 'dark', 0, 0.12, 0.02); break;
      case 'panel': p(B(0.7, 0.5, 0.08), 0x4a4f48, 0, 0.25, 0); for (let i = 0; i < 4; i++) for (let j = 0; j < 6; j++) p(B(0.04, 0.04, 0.03), j % 2 ? 'brass' : 'cream', -0.26 + j * 0.1, 0.1 + i * 0.1, 0.055); break;
      case 'mask': p(Sp(0.1, 10), 'rubber', 0, 0.1, 0); p(Cy(0.05, 0.06, 0.07, 10), 0x44473c, 0, 0.06, 0.1, Math.PI / 2); p(Cy(0.03, 0.03, 0.01, 10), 'glass', -0.05, 0.13, 0.08, Math.PI / 2); p(Cy(0.03, 0.03, 0.01, 10), 'glass', 0.05, 0.13, 0.08, Math.PI / 2); break;
      case 'cells': for (let i = 0; i < 4; i++) p(B(0.09, 0.22, 0.18), 'dark', -0.15 + i * 0.1, 0.11, 0); for (let i = 0; i < 4; i++) p(Cy(0.015, 0.015, 0.03, 6), 'red', -0.15 + i * 0.1, 0.235, 0.04); break;
      case 'nest': p(new THREE.OctahedronGeometry(0.16, 0), 'crystal', 0, 0.2, 0); p(new THREE.OctahedronGeometry(0.1, 0), 'crystal', 0.12, 0.1, 0.05, 0.4); p(Cy(0.22, 0.26, 0.06, 10), 0x3a3428, 0, 0.03, 0); break;
      // 장비
      case 'flash': p(Cy(0.03, 0.03, 0.22, 10), 'dark', 0, 0.03, 0, Math.PI / 2); p(Cy(0.045, 0.032, 0.06, 10), 'steel', 0, 0.03, 0.13, Math.PI / 2); break;
      case 'pro': p(Cy(0.04, 0.04, 0.26, 10), 'olive', 0, 0.045, 0, Math.PI / 2); p(Cy(0.07, 0.045, 0.09, 12), 'steel', 0, 0.05, 0.16, Math.PI / 2); break;
      case 'walkie': p(B(0.07, 0.18, 0.04), 'dark', 0, 0.09, 0); p(Cy(0.008, 0.008, 0.12, 6), 'dark', 0.022, 0.24, 0); break;
      case 'shovel': p(Cy(0.016, 0.016, 0.85, 6), 'wood', 0, 0.02, 0, Math.PI / 2); p(B(0.2, 0.012, 0.24), 'steel', 0, 0.02, 0.5); p(B(0.12, 0.02, 0.03), 'dark', 0, 0.02, -0.44); break;
      case 'stun': p(Cy(0.022, 0.022, 0.42, 8), 'dark', 0, 0.025, 0, Math.PI / 2); p(B(0.05, 0.05, 0.06), 0xc2a23a, 0, 0.025, 0.22); break;
      case 'ladder': p(B(0.04, 0.04, 1.2), 'steel', -0.18, 0.03, 0); p(B(0.04, 0.04, 1.2), 'steel', 0.18, 0.03, 0); for (let i = 0; i < 5; i++) p(B(0.36, 0.03, 0.03), 'steel', 0, 0.03, -0.5 + i * 0.25); break;
      case 'scan': p(B(0.14, 0.05, 0.2), 'olive', 0, 0.025, 0); p(B(0.1, 0.01, 0.08), 0x6fae8a, 0, 0.052, -0.03); break;
      case 'hack': p(B(0.16, 0.05, 0.12), 'dark', 0, 0.025, 0); p(B(0.1, 0.01, 0.06), 0xc2a23a, 0, 0.052, 0); p(Cy(0.006, 0.006, 0.2, 5), 'red', 0.05, 0.02, 0.15, Math.PI / 2); break;
      default: p(B(0.3, 0.2, 0.3), 'steel', 0, 0.1, 0);
    }
    const g = merge(P); g.computeBoundingSphere();
    return g;
  };

  /* ======================= 개체 모형 ======================= */
  GX.entity = function (k, M) {
    const g = new THREE.Group(), parts = {};
    const mesh = (list, name) => { const m = new THREE.Mesh(merge(list), M.ent); m.castShadow = true; g.add(m); if (name) parts[name] = m; return m; };
    const sub = (name, x, y, z) => { const s = new THREE.Group(); s.position.set(x, y, z); g.add(s); parts[name] = s; return s; };
    const mIn = (grp, list) => { const m = new THREE.Mesh(merge(list), M.ent); m.castShadow = true; grp.add(m); return m; };
    if (k === 'shade') {   // 마른 키 큰 형체 — 무광 검정, 길쭉한 머리
      mesh([part(Cy(0.12, 0.08, 1.2, 8), 0x0b0b0c, 0, 1.65, 0), part(Sp(0.17, 10), 0x0d0d0e, 0, 2.4, 0.02), part(Cy(0.1, 0.05, 0.36, 8), 0x0d0d0e, 0, 2.62, 0.05, 0.25), part(Cy(0.17, 0.12, 0.3, 8), 0x0b0b0c, 0, 2.1, 0)], 'body');
      const aL = sub('aL', -0.2, 2.15, 0), aR = sub('aR', 0.2, 2.15, 0), lL = sub('lL', -0.09, 1.08, 0), lR = sub('lR', 0.09, 1.08, 0);
      mIn(aL, [part(Cy(0.035, 0.025, 1.3, 6), 0x0b0b0c, 0, -0.65, 0)]); mIn(aR, [part(Cy(0.035, 0.025, 1.3, 6), 0x0b0b0c, 0, -0.65, 0)]);
      mIn(lL, [part(Cy(0.05, 0.03, 1.08, 6), 0x0b0b0c, 0, -0.54, 0)]); mIn(lR, [part(Cy(0.05, 0.03, 1.08, 6), 0x0b0b0c, 0, -0.54, 0)]);
      const eye = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.012, 0.01), M.glow); eye.position.set(0, 2.42, 0.17); eye.material = new THREE.MeshBasicMaterial({ color: 0x40382c }); g.add(eye); parts.eye = eye;
    } else if (k === 'ear') {   // 낮고 길쭉한 짐승 — 거무스름한 살갗, 눈 없음, 등뼈가 드러남, 큰 귀주름
      const body = Sp(0.36, 12); body.scale(1, 0.7, 1.6);
      const head = Cy(0.06, 0.2, 0.55, 8); head.rotateX(Math.PI / 2);
      const L0 = [part(body, 0x55504a, 0, 0.62, -0.1), part(head, 0x615b54, 0, 0.6, 0.62), part(B(0.05, 0.36, 0.3), 0x3a3531, -0.2, 0.82, 0.42, 0.3, 0, 0.55), part(B(0.05, 0.36, 0.3), 0x3a3531, 0.2, 0.82, 0.42, 0.3, 0, -0.55), part(Cy(0.1, 0.02, 0.7, 6), 0x4a4540, 0, 0.58, -0.95, Math.PI / 2 + 0.25)];
      for (let i = 0; i < 6; i++) L0.push(part(B(0.06, 0.05, 0.08), 0x7a736a, 0, 0.86 - Math.abs(i - 2.5) * 0.015, -0.45 + i * 0.14));
      mesh(L0, 'body');
      const jaw = new THREE.Mesh(merge([part(B(0.18, 0.04, 0.3), 0x3a1e1c, 0, 0, 0.12)]), M.ent); jaw.position.set(0, 0.52, 0.66); g.add(jaw); parts.jaw = jaw;
      for (const [nm, x, z] of [['l0', -0.22, 0.32], ['l1', 0.22, 0.32], ['l2', -0.22, -0.55], ['l3', 0.22, -0.55]]) { const sb = sub(nm, x, 0.55, z); mIn(sb, [part(Cy(0.05, 0.03, 0.58, 6), 0x4c4741, 0, -0.29, 0)]); }
    } else if (k === 'echo') {   // 작업복처럼 보이는 형체 — 목이 길고 어깨가 처짐, 흐린 헤드램프
      mesh([part(Cy(0.2, 0.17, 0.7, 10), 0x4b4a3e, 0, 1.25, 0), part(Cy(0.05, 0.05, 0.35, 6), 0x3a3830, 0, 1.75, 0), part(Sp(0.15, 10), 0x5a594e, 0, 1.98, 0.02), part(B(0.36, 0.3, 0.16), 0x2b2b26, 0, 1.3, -0.2)], 'body');
      const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 0.03), new THREE.MeshBasicMaterial({ color: 0x8a7a50 })); lamp.position.set(0, 2.05, 0.16); g.add(lamp); parts.lamp = lamp;
      const aL = sub('aL', -0.26, 1.55, 0), aR = sub('aR', 0.26, 1.55, 0), lL = sub('lL', -0.1, 0.9, 0), lR = sub('lR', 0.1, 0.9, 0);
      for (const a of [aL, aR]) mIn(a, [part(Cy(0.05, 0.04, 0.95, 6), 0x46453a, 0, -0.47, 0)]);
      for (const l of [lL, lR]) mIn(l, [part(Cy(0.07, 0.05, 0.9, 6), 0x3b3a31, 0, -0.45, 0)]);
    } else if (k === 'hang') {   // 천장에 붙은 덩어리 + 늘어진 가닥
      mesh([part(Sp(0.42, 10), 0x1e1a17, 0, 0, 0), part(Sp(0.3, 8), 0x231e1a, 0.3, -0.05, 0.1)], 'body');
      for (let i = 0; i < 7; i++) { const a = i / 7 * TAU, s = sub('t' + i, Math.cos(a) * 0.25, -0.1, Math.sin(a) * 0.25); mIn(s, [part(Cy(0.03, 0.01, 1.1 + (i % 3) * 0.25, 5), 0x2a2420, 0, -0.55 - (i % 3) * 0.12, 0)]); }
    } else if (k === 'warden') {   // 갑각이 겹친 큰 몸
      mesh([part(Sp(0.75, 14), 0x4a4236, 0, 0.9, 0), part(Sp(0.62, 12), 0x5a5040, 0, 1.15, -0.2), part(Sp(0.45, 12), 0x3e372d, 0, 0.95, 0.65), part(B(1.2, 0.08, 1.0), 0x2e2a22, 0, 1.55, -0.1, 0.2), part(B(1.1, 0.08, 0.9), 0x2e2a22, 0, 1.4, -0.45, 0.4)], 'body');
      for (const [nm, x, z] of [['l0', -0.6, 0.4], ['l1', 0.6, 0.4], ['l2', -0.65, -0.3], ['l3', 0.65, -0.3], ['l4', -0.55, -0.8], ['l5', 0.55, -0.8]]) { const s = sub(nm, x, 0.7, z); mIn(s, [part(Cy(0.08, 0.05, 0.8, 6), 0x3a342a, x > 0 ? 0.25 : -0.25, -0.38, 0, 0, 0, x > 0 ? 0.5 : -0.5)]); }
      const eye = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.03, 0.02), new THREE.MeshBasicMaterial({ color: 0x6a3a1a })); eye.position.set(0, 1.0, 1.08); g.add(eye); parts.eye = eye;
    } else if (k === 'slow') {   // 커다랗게 웅크린 덩어리
      mesh([part(Sp(1.0, 14), 0x2a2622, 0, 1.4, 0), part(Sp(0.8, 12), 0x302b26, 0, 2.05, 0.25), part(Sp(0.55, 10), 0x26221e, 0.5, 1.0, 0.4), part(Sp(0.55, 10), 0x26221e, -0.5, 1.0, 0.4)], 'body');
      const aL = sub('aL', -0.85, 1.9, 0.3), aR = sub('aR', 0.85, 1.9, 0.3);
      for (const a of [aL, aR]) mIn(a, [part(Cy(0.2, 0.12, 1.7, 8), 0x2c2824, 0, -0.85, 0)]);
    }
    g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
    return { group: g, parts };
  };

  /* ======================= 동료(작업복) ======================= */
  function roundedBox(w, h, d, r, seg) {   // 모서리를 둥글린 상자(꼭짓점 밀어내기 — 싸고 부드러운 윤곽)
    const g = new THREE.BoxGeometry(1, 1, 1, seg, seg, seg), p = g.attributes.position, nrm = g.attributes.normal;
    const hx = w / 2, hy = h / 2, hz = d / 2;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i) * w, y = p.getY(i) * h, z = p.getZ(i) * d;
      const ix = clamp(x, -hx + r, hx - r), iy = clamp(y, -hy + r, hy - r), iz = clamp(z, -hz + r, hz - r);
      let dx = x - ix, dy = y - iy, dz = z - iz; const l = Math.hypot(dx, dy, dz) || 1;
      dx /= l; dy /= l; dz /= l;
      p.setXYZ(i, ix + dx * r, iy + dy * r, iz + dz * r); nrm.setXYZ(i, dx, dy, dz);
    }
    return g;
  }
  GX.roundedBox = roundedBox;
  const Cap = (r, len, rs) => new THREE.CapsuleGeometry(r, len, 3, rs || 8);
  GX.crew = function (M, seatHex) {
    const g = new THREE.Group(), parts = {};
    const suit = 0x4e4d40, dark = 0x232421, strip = 0x8f9184, pants = 0x44433a;
    const torso = Cap(0.2, 0.34, 10); torso.scale(1, 1, 0.82);
    const pelvis = Cap(0.17, 0.12, 10); pelvis.scale(1, 1, 0.8);
    const dome = new THREE.SphereGeometry(0.19, 16, 8, 0, TAU, 0, Math.PI / 2); dome.scale(1, 0.92, 1.08);
    const brim = new THREE.CylinderGeometry(0.235, 0.24, 0.025, 18); brim.scale(1, 1, 1.12);
    const upper = new THREE.Mesh(merge([
      part(torso, suit, 0, 1.2, 0), part(pelvis, pants, 0, 0.92, 0),
      part(roundedBox(0.36, 0.44, 0.19, 0.07, 3), dark, 0, 1.22, -0.23), part(roundedBox(0.28, 0.12, 0.06, 0.03, 2), 0x3a3b36, 0, 1.04, -0.33),
      part(Cy(0.205, 0.205, 0.04, 12), strip, 0, 1.02, 0, 0, 0, 0), part(Cy(0.21, 0.205, 0.05, 12), seatHex, 0, 1.34, 0),
      part(Sp(0.1, 8), suit, -0.2, 1.43, 0), part(Sp(0.1, 8), suit, 0.2, 1.43, 0),
      part(Cy(0.075, 0.085, 0.12, 10), dark, 0, 1.55, 0),
      part(Sp(0.15, 14), 0x302f2b, 0, 1.68, 0), part(roundedBox(0.22, 0.08, 0.06, 0.025, 2), 0x0e1112, 0, 1.69, 0.12),
      part(dome, 0x8a7640, 0, 1.73, 0), part(brim, 0x7a6838, 0, 1.735, 0.02), part(Cap(0.018, 0.2, 6), 0x7d6b3b, 0, 1.9, 0, Math.PI / 2),
      part(Cy(0.035, 0.035, 0.06, 8), 0x2a2a26, 0.0, 1.8, 0.17, Math.PI / 2),
    ]), M.crew);
    g.add(upper); parts.upper = upper;
    const sub = (name, x, y, z, list) => { const s = new THREE.Group(); s.position.set(x, y, z); const m = new THREE.Mesh(merge(list), M.crew); m.castShadow = true; s.add(m); g.add(s); parts[name] = s; return s; };
    const arm = () => [part(Cap(0.058, 0.46, 8), suit, 0, -0.3, 0), part(Cy(0.064, 0.064, 0.05, 8), strip, 0, -0.3, 0), part(Sp(0.055, 8), dark, 0, -0.6, 0.01)];
    sub('aL', -0.26, 1.42, 0, arm());
    sub('aR', 0.26, 1.42, 0, arm());
    sub('lL', -0.1, 0.88, 0, [part(Cap(0.075, 0.66, 8), pants, 0, -0.42, 0), part(roundedBox(0.13, 0.1, 0.25, 0.04, 2), 0x1a1a18, 0, -0.83, 0.04)]);
    sub('lR', 0.1, 0.88, 0, [part(Cap(0.075, 0.66, 8), pants, 0, -0.42, 0), part(roundedBox(0.13, 0.1, 0.25, 0.04, 2), 0x1a1a18, 0, -0.83, 0.04)]);
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.035, 0.02), new THREE.MeshBasicMaterial({ color: 0x2a2a26 })); lamp.position.set(0, 1.8, 0.2); g.add(lamp); parts.lamp = lamp;
    g.traverse((o) => { if (o.isMesh) o.castShadow = true; });
    return { group: g, parts };
  };

  /* ======================= 표시(무전 표시 · 스캔 글) 그림 ======================= */
  GX.markerTex = function (txt, col, sub) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 96;
    const g = c.getContext('2d');
    g.clearRect(0, 0, 256, 96);
    g.strokeStyle = col; g.lineWidth = 3; g.beginPath(); g.moveTo(128, 8); g.lineTo(142, 22); g.lineTo(128, 36); g.lineTo(114, 22); g.closePath(); g.stroke();
    g.font = '600 22px "IBM Plex Mono", "IBM Plex Sans KR", monospace'; g.textAlign = 'center'; g.fillStyle = col;
    g.shadowColor = 'rgba(0,0,0,.9)'; g.shadowBlur = 4;
    g.fillText(txt, 128, 62);
    if (sub) { g.font = '500 18px "IBM Plex Sans KR", sans-serif'; g.fillStyle = 'rgba(220,214,196,.8)'; g.fillText(sub, 128, 86); }
    const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
    return t;
  };

  window.SV_GX = GX;
})();
