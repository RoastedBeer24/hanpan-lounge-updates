/* 산탄 룰렛 (buckshot) — 2~4명 심리전. 어두운 방, 탁자 하나, 산탄총 한 자루.
   장전할 때 실탄·공포탄 개수만 공개(순서는 비밀). 내 차례엔 물건을 쓰고, 다른 사람이나 나를 쏴요.
   나에게 쏜 탄이 공포탄이면 차례가 이어져요. 충전(목숨)이 0이 되면 그 라운드 탈락, 마지막 한 명이 라운드 승리.
   라운드가 오를수록 충전·물건이 늘고, 먼저 목표 승수(기본 2승)를 채우면 우승.
   파일: games/buckshot.js(규칙·AI·화면 DOM) + assets/buckshot/scene.js(3D 장면, three.js — 하이퍼 레이스와 같은 파일을 빌려 씀) + assets/buckshot/sfx(CC0 효과음). */
(function () {
  const L = window.Lounge, U = L && L.util;
  const ID = 'buckshot', ASSET = 'assets/buckshot/';

  /* ======================= 자료 ======================= */
  // 물건: 한 글자 코드 → 이름·설명·뽑힐 무게(w)·대상 필요(tg)
  const ITEMS = {
    l: { id: 'lens', n: '약실 렌즈', d: '지금 장전된 탄이 실탄인지 공포탄인지 혼자 확인해요.', w: 14 },
    c: { id: 'cuff', n: '족쇄', d: '고른 사람의 다음 차례를 한 번 건너뛰게 해요. 이미 족쇄를 찼거나 막 풀린 사람에겐 못 써요.', w: 9, tg: 1 },
    s: { id: 'saw', n: '총열 톱', d: '총열을 잘라 다음 한 발의 피해가 2배(실탄이면 충전 2). 쏘고 나면 원래대로.', w: 11 },
    k: { id: 'can', n: '탄산 캔', d: '총을 당겨 지금 탄을 쏘지 않고 빼내요. 빠진 탄이 무엇인지 모두 봐요. 차례는 그대로.', w: 12 },
    g: { id: 'smoke', n: '박하 궐련', d: '충전 1 회복(라운드 최대 충전을 넘지 않음).', w: 11 },
    r: { id: 'radio', n: '잡음 무전기', d: '앞으로 나올 탄 하나(무작위)가 몇 번째에 무엇인지 혼자 확인해요. 남은 탄이 지금 것 하나뿐이면 정보가 없어요.', w: 9 },
    f: { id: 'flip', n: '극성 스위치', d: '지금 탄을 반대로 바꿔요(실탄↔공포탄). 쓴 건 모두 보지만, 원래 무엇이었는지 몰랐다면 결과도 몰라요.', w: 9 },
    a: { id: 'adren', n: '각성 주사', d: '다른 사람의 물건 하나를 빼앗아 바로 써요(각성 주사는 못 빼앗음). 빼앗은 족쇄는 빼앗긴 사람에게 채워요.', w: 7, tg: 1 },
    p: { id: 'pill', n: '변질된 알약', d: '반반 확률: 충전 2 회복, 또는 충전 1 잃음(0이 되면 탈락).', w: 8 },
  };
  const CODES = Object.keys(ITEMS);
  const LIVES = [2, 4, 5], PER = [2, 3, 4], CAP = 8, EVMAX = 14;
  const cfg = (r) => Math.min(r, 3) - 1;
  // 연출 속도(설정 화면 옵션): 연출 · AI 생각 시간을 이 배로 빠르게. 규칙에는 영향 없음
  const PACES = [1, 1.5, 2, 3];
  const paceOf = (v) => (PACES.includes(+v) ? +v : 1);

  // 직접 그린 아이콘(24×24, currentColor) — 외부 그림 없음
  const IC = {
    l: '<circle cx="10" cy="10" r="6.2" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="10" cy="10" r="3.4" fill="currentColor" opacity=".25"/><path d="M14.6 14.6l6 6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    c: '<circle cx="7.5" cy="13" r="5" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="16.5" cy="13" r="5" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M10.5 6.5h3" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><rect x="5.5" y="5" width="4" height="3" rx="1" fill="currentColor"/><rect x="14.5" y="5" width="4" height="3" rx="1" fill="currentColor"/>',
    s: '<path d="M3 15.5L17 6.5l2.6 3.8L5.6 19.3z" fill="currentColor" opacity=".9"/><path d="M5 19l1.4-2.6 1.6 1.4 1-2.8 1.8 1.2.9-2.8 1.9 1 .7-2.9 2 .8" fill="none" stroke="currentColor" stroke-width="1.2"/><rect x="17" y="3" width="5" height="7" rx="1.6" transform="rotate(-33 19.5 6.5)" fill="none" stroke="currentColor" stroke-width="2"/>',
    k: '<rect x="6.5" y="5" width="11" height="16" rx="2.2" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M8 9h8M8 17h8" stroke="currentColor" stroke-width="1.4" opacity=".7"/><path d="M10 3h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="13" r="2" fill="currentColor"/>',
    g: '<rect x="2.5" y="13" width="15" height="4" rx="1.2" fill="none" stroke="currentColor" stroke-width="2"/><rect x="17.5" y="13" width="4" height="4" rx="1" fill="currentColor"/><path d="M7 11c-1.5-2 1.5-3 0-5.5M11 10.5c-1.3-1.8 1.3-2.8 0-5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" opacity=".75"/>',
    r: '<rect x="6" y="8" width="12" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M15 8V2.5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/><rect x="8.5" y="10.5" width="7" height="4" rx=".8" fill="currentColor" opacity=".6"/><circle cx="10" cy="18" r="1.2" fill="currentColor"/><circle cx="14" cy="18" r="1.2" fill="currentColor"/>',
    f: '<rect x="4" y="8" width="16" height="9" rx="4.5" fill="none" stroke="currentColor" stroke-width="2.2"/><circle cx="15.5" cy="12.5" r="3" fill="currentColor"/><path d="M5 4.5h7l-2-2M19 21h-7l2 2" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
    a: '<path d="M4 20l3-3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><rect x="6.5" y="7.5" width="6" height="12" rx="1.4" transform="rotate(45 9.5 13.5)" fill="none" stroke="currentColor" stroke-width="2.1"/><path d="M14 10l4.5-4.5M16.5 3.5l4 4M19.5 4.5l1.8-1.8" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"/><path d="M8.2 14.8l2.4-2.4" stroke="currentColor" stroke-width="3.2" opacity=".55"/>',
    p: '<rect x="3" y="8.5" width="18" height="8" rx="4" transform="rotate(-35 12 12.5)" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M9.3 8.6l4.6 7.4" stroke="currentColor" stroke-width="2"/><path d="M4.5 16.5a4 4 0 0 1 3.5-6.5" fill="none" stroke="currentColor" stroke-width="1" opacity=".5"/>',
  };
  // 칸 아래에 붙이는 짧은 이름(화면 표시만)
  const SHORT = { l: '렌즈', c: '족쇄', s: '톱', k: '캔', g: '궐련', r: '무전기', f: '스위치', a: '주사', p: '알약' };
  const icon = (c, sz) => '<svg viewBox="0 0 24 24" width="' + (sz || 24) + '" height="' + (sz || 24) + '" aria-hidden="true">' + (IC[c] || '') + '</svg>';
  const ICON = '<rect x="9" y="22" width="38" height="13" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><path d="M47 25h4v7h-4M9 28H4" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>' +
    '<rect x="14" y="9" width="9" height="11" rx="2" fill="currentColor"/><rect x="26" y="9" width="9" height="11" rx="2" fill="none" stroke="currentColor" stroke-width="2.4"/><rect x="38" y="9" width="9" height="11" rx="2" fill="currentColor"/>' +
    '<path d="M18 35l-6 12h10l4-12" fill="currentColor"/><circle cx="31" cy="44" r="5" fill="none" stroke="currentColor" stroke-width="2.4"/>';

  /* ======================= 작은 도구 ======================= */
  function hash(n) { n = (n ^ 61) ^ (n >>> 16); n = (n + (n << 3)) | 0; n ^= n >>> 4; n = Math.imul(n, 0x27d4eb2d); n ^= n >>> 15; return (n >>> 0) / 4294967296; }
  const setc = (str, i, c) => str.slice(0, i) + c + str.slice(i + 1);
  const cut = (str, i) => str.slice(0, i) + str.slice(i + 1);
  const alive = (s) => { const a = []; for (let i = 0; i < s.n; i++) if (!s.out[i]) a.push(i); return a; };
  function pickItem() {
    let tot = 0; for (const c of CODES) tot += ITEMS[c].w;
    let x = Math.random() * tot;
    for (const c of CODES) { x -= ITEMS[c].w; if (x < 0) return c; }
    return 'l';
  }
  // 남은 탄의 원래 종류 개수(모두가 아는 정보: 빠진 탄은 다 공개되니까)
  function remCounts(s) { let a = 0, b = 0; for (let i = s.at; i < s.og.length; i++) { if (s.og[i] === 'L') a++; else b++; } return [a, b]; }
  function snap(s) {
    const [rl, rb] = remCounts(s);
    let o = 0; for (let i = 0; i < s.n; i++) if (s.out[i]) o |= 1 << i;
    return { h: s.hp.slice(), o, w: s.wins.slice(), c: s.cuf.slice(), i: s.inv.slice(), s: s.saw, f: s.iv, a: s.at, n: s.sq.length, rl, rb, ld: s.ld, r: s.r, lv: s.lv, t: s.turn };
  }
  function pushEv(s, e) { e.id = ++s.eid; e.v = snap(s); s.ev.push(e); while (s.ev.length > EVMAX) s.ev.shift(); }

  /* ======================= 판 만들기 ======================= */
  function init(players, opts) {
    const n = Math.max(2, Math.min(4, players.length));
    opts = opts || {};
    const tw = opts.goal === '1' ? 1 : opts.goal === '3' ? 3 : 2;
    const s = {
      n, tw, pace: paceOf(opts.pace), nm: players.slice(0, n).map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 16)),
      r: 0, lv: 0, hp: [], out: [], wins: new Array(n).fill(0), inv: [], cuf: [], saw: 0,
      sq: '', og: '', at: 0, iv: 0, kn: [], ld: 0, turn: 0, ph: 'play', win: -1,
      ev: [], eid: 0, seed: (Math.random() * 1e9) | 0, first: (Math.random() * n) | 0,
      by: new Array(n).fill(-1),    // 마지막으로 나를 쏜 사람(AI 앙심)
      st: { hit: new Array(n).fill(0), self: new Array(n).fill(0), use: new Array(n).fill(0), dmg: new Array(n).fill(0), shots: new Array(n).fill(0) },
    };
    startRound(s);
    return s;
  }
  function startRound(s) {
    s.r++;
    const k = cfg(s.r);
    s.lv = LIVES[k];
    s.hp = new Array(s.n).fill(s.lv); s.out = new Array(s.n).fill(false);
    s.inv = new Array(s.n).fill(''); s.cuf = new Array(s.n).fill(0); s.saw = 0; s.ld = 0;
    s.by = new Array(s.n).fill(-1);
    s.turn = (s.first + s.r - 1) % s.n;
    pushEv(s, { k: 'round', r: s.r, lv: s.lv, per: PER[k] });
    newLoad(s);
  }
  function newLoad(s) {
    const lo = s.n === 2 ? 2 : 3;
    const t = lo + ((Math.random() * (9 - lo)) | 0);              // 2(또는 3)~8발
    const live = Math.max(1, Math.min(t - 1, Math.round(t * (0.34 + Math.random() * 0.3))));
    const a = []; for (let i = 0; i < t; i++) a.push(i < live ? 'L' : 'B');
    for (let i = a.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; const x = a[i]; a[i] = a[j]; a[j] = x; }
    s.sq = s.og = a.join(''); s.at = 0; s.iv = 0; s.ld++;
    s.kn = new Array(s.n).fill('?'.repeat(t));
    const per = s.ld > 30 ? 0 : PER[cfg(s.r)];   // 아주 길어진 라운드는 물건 그만(끝나게)
    const g = new Array(s.n).fill('');
    for (let p = 0; p < s.n; p++) {
      if (s.out[p]) continue;
      for (let k = 0; k < per; k++) { const c = pickItem(); g[p] += c; if (s.inv[p].length < CAP) s.inv[p] += c; }
    }
    pushEv(s, { k: 'load', L: live, B: t - live, g });
  }

  function actor(s) { return s.ph === 'play' ? s.turn : null; }

  function nextTurn(s, from) {
    for (let k = 1; k <= s.n; k++) {
      const j = (from + k) % s.n;
      if (s.out[j]) continue;
      if (s.cuf[j] === 1 && k < s.n) { s.cuf[j] = 2; pushEv(s, { k: 'skip', p: j }); continue; }
      if (s.cuf[j] === 2) s.cuf[j] = 0;
      return j;
    }
    if (!s.out[from]) return from;
    // 쏜 사람이 쓰러졌고 남은 사람이 모두 족쇄 → 족쇄를 풀고 다음 사람
    for (let k = 1; k <= s.n; k++) { const j = (from + k) % s.n; if (!s.out[j]) { s.cuf[j] = 0; return j; } }
    return from;
  }
  function hurt(s, p, d, by) {
    s.hp[p] = Math.max(0, s.hp[p] - d);
    if (by >= 0 && by !== p) { s.st.dmg[by] += d; s.by[p] = by; }
    if (s.hp[p] <= 0) { s.out[p] = true; s.inv[p] = ''; s.cuf[p] = 0; pushEv(s, { k: 'out', p, by }); }
  }
  // 한 명만 남으면 라운드 끝 → 다음 라운드 또는 판 끝. true = 라운드가 끝났음
  function roundCheck(s, fallback) {
    const al = alive(s);
    if (al.length > 1) return false;
    const w = al.length ? al[0] : fallback;
    s.wins[w]++;
    pushEv(s, { k: 'rwin', p: w, r: s.r });
    if (s.wins[w] >= s.tw) { s.ph = 'over'; s.win = w; pushEv(s, { k: 'over', p: w }); }
    else startRound(s);
    return true;
  }

  /* 물건을 지금 쓸 수 있는지(이유 문자열 = 안 됨, '' = 됨) */
  function why(s, by, c, to, j, stolen) {
    const others = alive(s).filter((i) => i !== by);
    if (c === 'c') {
      if (to == null) return others.some((i) => s.cuf[i] === 0) ? '' : '족쇄를 채울 사람이 없어요';
      if (to === by || to < 0 || to >= s.n || s.out[to]) return '고를 수 없는 사람';
      if (s.cuf[to] !== 0) return '이미 족쇄를 찼거나 막 풀린 사람이에요';
      return '';
    }
    if (c === 's') return s.saw ? '이미 총열을 잘랐어요' : '';
    if (c === 'g') return s.hp[by] >= s.lv ? '충전이 가득 찼어요' : '';
    if (c === 'a') {
      if (stolen) return '못 써요';
      if (to == null) return others.some((i) => [...s.inv[i]].some((x) => x !== 'a' && !why(s, by, x, i, null, true))) ? '' : '빼앗을 물건이 없어요';
      if (to === by || to < 0 || to >= s.n || s.out[to]) return '고를 수 없는 사람';
      const x = s.inv[to][j];
      if (j == null || !x) return '물건을 골라요';
      if (x === 'a') return '각성 주사는 못 빼앗아요';
      return why(s, by, x, to, null, true);
    }
    return '';
  }

  function apply(s, seat, a) {
    if (s.ph !== 'play' || seat !== s.turn || !a || typeof a !== 'object') throw new Error('차례 아님');
    if (a.t === 'fire') {
      const to = a.to | 0;
      if (to < 0 || to >= s.n || s.out[to]) throw new Error('대상 없음');
      fire(s, seat, to);
      return s;
    }
    if (a.t === 'use') {
      const i = a.i | 0, c = s.inv[seat][i];
      if (!c) throw new Error('물건 없음');
      const to = a.to == null ? null : a.to | 0, j = a.j == null ? null : a.j | 0;
      if (ITEMS[c].tg && to == null) throw new Error('대상 필요');
      const w = why(s, seat, c, to, j, false);
      if (w) throw new Error(w);
      s.inv[seat] = cut(s.inv[seat], i);
      s.st.use[seat]++;
      effect(s, seat, c, to, j, false);
      return s;
    }
    throw new Error('알 수 없는 행동');
  }

  function fire(s, by, to) {
    const sh = s.sq[s.at];
    s.at++; s.iv = 0;
    const saw = s.saw; s.saw = 0;
    const dmg = sh === 'L' ? (saw ? 2 : 1) : 0;
    s.st.shots[by]++;
    if (to === by && sh === 'B') s.st.self[by]++;
    if (dmg && to !== by) s.st.hit[by]++;
    const fe = { k: 'fire', by, to, sh, dmg, saw };
    pushEv(s, fe);
    if (dmg) { hurt(s, to, dmg, by); fe.v = snap(s); }   // 쏘는 장면의 눈금 = 맞은 뒤
    if (roundCheck(s, by)) return;
    if (!(sh === 'B' && to === by)) s.turn = nextTurn(s, by);
    if (s.at >= s.sq.length) newLoad(s);
    else s.ev[s.ev.length - 1].v = snap(s);   // 마지막 이벤트 = 지금 상태(차례 바뀜 포함)
  }

  function effect(s, by, c, to, j, stolen) {
    const e = { k: 'use', by, it: c };
    if (stolen) e.st = 1;
    if (c === 'l') { e.see = s.sq[s.at]; s.kn[by] = setc(s.kn[by], s.at, s.sq[s.at]); pushEv(s, e); return; }
    if (c === 'c') { s.cuf[to] = 1; e.to = to; pushEv(s, e); return; }
    if (c === 's') { s.saw = 1; pushEv(s, e); return; }
    if (c === 'g') { s.hp[by] = Math.min(s.lv, s.hp[by] + 1); e.heal = 1; pushEv(s, e); return; }
    if (c === 'k') {
      e.sh = s.sq[s.at]; s.at++; s.iv = 0;
      pushEv(s, e);
      if (s.at >= s.sq.length) newLoad(s);
      return;
    }
    if (c === 'r') {
      const fut = s.sq.length - s.at - 1;
      if (fut <= 0) { e.pos = 0; pushEv(s, e); return; }
      const pos = s.at + 1 + ((Math.random() * fut) | 0);
      s.kn[by] = setc(s.kn[by], pos, s.sq[pos]);
      e.pos = pos - s.at + 1; e.see = s.sq[pos];       // pos = 지금 탄이 1번째일 때 몇 번째인지
      pushEv(s, e); return;
    }
    if (c === 'f') {
      const x = s.sq[s.at] === 'L' ? 'B' : 'L';
      s.sq = setc(s.sq, s.at, x); s.iv ^= 1;
      for (let p = 0; p < s.n; p++) { const k = s.kn[p][s.at]; if (k !== '?') s.kn[p] = setc(s.kn[p], s.at, k === 'L' ? 'B' : 'L'); }
      pushEv(s, e); return;
    }
    if (c === 'a') {
      const got = s.inv[to][j];
      s.inv[to] = cut(s.inv[to], j);
      e.to = to; e.got = got; pushEv(s, e);
      effect(s, by, got, got === 'c' ? to : null, null, true);
      return;
    }
    if (c === 'p') {
      if (Math.random() < 0.5) { const b = s.hp[by]; s.hp[by] = Math.min(s.lv, s.hp[by] + 2); e.ok = 1; e.heal = s.hp[by] - b; pushEv(s, e); return; }
      e.ok = 0; pushEv(s, e);
      hurt(s, by, 1, -1);
      if (s.out[by]) {
        if (roundCheck(s, by)) return;
        s.turn = nextTurn(s, by);
        s.ev[s.ev.length - 1].v = snap(s);
      }
    }
  }

  function result(s) {
    if (s.ph !== 'over') return null;
    const w = s.win, P = [...Array(s.n).keys()];
    const hl = [];
    const mx = (arr) => Math.max(...arr);
    if (mx(s.st.self) > 0) { const p = s.st.self.indexOf(mx(s.st.self)); hl.push(s.nm[p] + ' — 자신에게 쏜 공포탄 ' + s.st.self[p] + '회'); }
    if (mx(s.st.dmg) > 0) { const p = s.st.dmg.indexOf(mx(s.st.dmg)); hl.push(s.nm[p] + ' — 상대에게 입힌 피해 ' + s.st.dmg[p]); }
    return {
      winners: [w], title: s.nm[w] + ' 우승',
      text: s.r + '라운드 만에 ' + s.tw + '승을 먼저 채웠어요.',
      highlights: hl,
      stats: [
        { label: '라운드 승리', values: P.map((i) => s.wins[i]) },
        { label: '쏜 횟수', values: P.map((i) => s.st.shots[i]) },
        { label: '상대 명중', values: P.map((i) => s.st.hit[i]) },
        { label: '입힌 피해', values: P.map((i) => s.st.dmg[i]) },
        { label: '자신에게 공포탄', values: P.map((i) => s.st.self[i]) },
        { label: '쓴 물건', values: P.map((i) => s.st.use[i]) },
      ],
    };
  }

  /* ======================= 확률(그 자리가 아는 것만으로) ======================= */
  function probLive(s, p, forget) {
    const k = (p >= 0 && s.kn[p]) || '';
    if (!forget && k[s.at] && k[s.at] !== '?') return k[s.at] === 'L' ? 1 : 0;
    let [a, b] = remCounts(s);
    if (!forget) for (let i = s.at + 1; i < s.og.length; i++) { const c = k[i]; if (c === 'L') a--; else if (c === 'B') b--; }
    let pl = a + b > 0 ? a / (a + b) : 0.5;
    if (s.iv) pl = 1 - pl;
    return pl;
  }

  /* ======================= AI ======================= */
  // 자리마다 판 시드로 정해지는 버릇(고정 규칙이 아니라 점수에 덧칠)
  function habits(s, seat) {
    const r = (k) => hash((s.seed | 0) * 31 + seat * 977 + k * 7919);
    return { brave: (r(1) - 0.5) * 0.16, itemy: 0.8 + r(2) * 0.4, grudge: r(3) * 0.5, hoard: r(4) * 0.12, gamble: r(5) };
  }
  function pickTarget(s, me, lv, hb, opt) {
    const others = alive(s).filter((i) => i !== me);
    if (others.length === 1) return others[0];
    const nxt = nextAliveRaw(s, me);
    let best = others[0], bv = -1e9;
    for (const o of others) {
      if (opt && opt.cuff && s.cuf[o] !== 0) continue;
      let v = 0;
      v += (s.lv - s.hp[o]) * 0.25 + (s.hp[o] <= 1 ? 0.6 : 0) + (opt && opt.saw && s.hp[o] === 2 ? 0.5 : 0);
      v += s.wins[o] * 0.45;
      v += s.by[me] === o ? hb.grudge : 0;
      v += s.inv[o].length * 0.05 + (s.inv[o].includes('s') ? 0.15 : 0);
      if (lv >= 3) v += (s.inv[o].includes('s') || s.inv[o].includes('l') ? 0.2 : 0) + (o === nxt && s.hp[o] <= 1 ? 0.3 : 0);
      v += (Math.random() - 0.5) * (lv === 1 ? 1.6 : lv === 2 ? 0.5 : 0.15);
      if (v > bv) { bv = v; best = o; }
    }
    return best;
  }
  function nextAliveRaw(s, from) { for (let k = 1; k < s.n; k++) { const j = (from + k) % s.n; if (!s.out[j]) return j; } return from; }

  // 물건 하나의 지금 값(0 = 안 씀). x: 행동에 덧붙일 것
  function itemValue(s, me, c, ctx) {
    const { pc, lv, hb, tgt } = ctx;
    const known = pc <= 0.001 || pc >= 0.999;
    const left = s.sq.length - s.at;
    const miss = s.lv - s.hp[me];
    if (why(s, me, c, c === 'c' ? ctx.ctg : null, null, ctx.stolen)) return null;
    switch (c) {
      case 'l': return known ? null : { v: 0.55 + 0.6 * (1 - Math.abs(2 * pc - 1)) };
      case 'r': { if (left < 2) return null; let unk = 0; const k = s.kn[me]; for (let i = s.at + 1; i < s.sq.length; i++) if (k[i] === '?') unk++; return unk ? { v: 0.22 + 0.05 * Math.min(unk, 6) } : null; }
      case 'f': if (pc >= 0.5) return null; return { v: pc <= 0.001 ? 1.05 : 0.3 + (0.5 - pc) * (lv >= 3 ? 1.1 : 0.7) };
      case 's': if (pc < 0.66 || s.hp[tgt] < 2) return null; return { v: pc >= 0.999 ? 1.0 : 0.25 + pc * 0.5 };
      case 'c': { const t = ctx.ctg; if (t == null) return null; return { v: 0.32 + (alive(s).length === 2 ? 0.28 : 0.08) + (pc >= 0.6 ? 0.12 : 0), x: { to: t } }; }
      case 'k': if (known) return null; return pc > 0.3 && pc < 0.75 ? { v: 0.34 + (hb.gamble < 0.4 ? 0.06 : 0) } : null;
      case 'g': return miss > 0 ? { v: 0.5 + 0.15 * miss + (s.hp[me] === 1 ? 0.25 : 0) } : null;
      case 'p': {
        if (miss >= 2 && s.hp[me] >= 2) return { v: 0.34 + hb.gamble * 0.25 };
        if (s.hp[me] === 1 && miss >= 1 && lv === 1 && hb.gamble > 0.7) return { v: 0.32 };
        return null;
      }
      default: return null;
    }
  }

  /* 어려움: 몬테카를로 한 수 앞보기 — 내가 아는 것과 맞는 탄 순서를 여러 번 뽑아(남의 비밀은 모름),
     후보 행동마다 라운드 끝(또는 60수)까지 보통 AI로 굴려 보고 평균이 가장 좋은 것을 고름 */
  function sampleWorld(s, me) {
    const w = JSON.parse(JSON.stringify(s));
    const k = s.kn[me], flipc = (c) => (c === 'L' ? 'B' : 'L');
    let [a, b] = remCounts(s);
    for (let i = s.at; i < s.og.length; i++) { const c = k[i]; if (c === '?') continue; const o = i === s.at && s.iv ? flipc(c) : c; if (o === 'L') a--; else b--; }
    const pool = [];
    for (let i = 0; i < Math.max(0, a); i++) pool.push('L');
    for (let i = 0; i < Math.max(0, b); i++) pool.push('B');
    for (let i = pool.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; const x = pool[i]; pool[i] = pool[j]; pool[j] = x; }
    let og = s.og.slice(0, s.at), sq = s.sq.slice(0, s.at);
    for (let i = s.at; i < s.og.length; i++) {
      const o = k[i] !== '?' ? (i === s.at && s.iv ? flipc(k[i]) : k[i]) : (pool.pop() || 'B');
      og += o; sq += i === s.at && s.iv ? flipc(o) : o;
    }
    w.og = og; w.sq = sq;
    w.kn = s.kn.map((x, p) => (p === me ? x : '?'.repeat(x.length)));
    w.ev = [];
    return w;
  }
  function rollValue(w, me, r0, wins0) {
    for (let step = 0; step < 60; step++) {
      if (w.ph !== 'play' || w.r !== r0) break;
      const seat = w.turn;
      let a;
      try { a = ai(w, seat, 2, true); apply(w, seat, a); } catch (e) { return 0.5; }
      w.ev.length = 0;
    }
    if (w.ph !== 'play' || w.r !== r0) return w.wins[me] > wins0 ? 1 : 0;
    if (w.out[me]) return 0;
    const al = alive(w);
    let tot = 0; for (const p of al) tot += w.hp[p];
    return 0.15 + 0.7 * (w.hp[me] / Math.max(1, tot)) * (al.length > 1 ? 1 : 2);
  }
  function mcChoose(s, me, heur) {
    const cands = [];
    for (const p of alive(s)) cands.push({ t: 'fire', to: p });
    const seen = {};
    for (let i = 0; i < s.inv[me].length; i++) {
      const c = s.inv[me][i]; if (seen[c]) continue; seen[c] = 1;
      if (c === 'c') { for (const p of alive(s)) if (p !== me && !why(s, me, 'c', p, null, false)) cands.push({ t: 'use', i, to: p }); }
      else if (c === 'a') { let n = 0; for (const p of alive(s)) { if (p === me) continue; for (let j = 0; j < s.inv[p].length && n < 6; j++) if (!why(s, me, 'a', p, j, false)) { cands.push({ t: 'use', i, to: p, j }); n++; } } }
      else if (!why(s, me, c, null, null, false) && !(c === 'l' && s.kn[me][s.at] !== '?') && !(c === 'p' && s.hp[me] === 1)) cands.push({ t: 'use', i });
    }
    if (cands.length <= 1) return cands[0] || heur;
    const sum = new Array(cands.length).fill(0), cnt = new Array(cands.length).fill(0);
    const t0 = Date.now(), r0 = s.r, wins0 = s.wins[me];
    for (let it = 0; it < 48; it++) {
      for (let c = 0; c < cands.length; c++) {
        const w = sampleWorld(s, me);
        try { apply(w, me, cands[c]); } catch (e) { continue; }
        w.ev.length = 0;
        sum[c] += rollValue(w, me, r0, wins0); cnt[c]++;
      }
      if (Date.now() - t0 > 140 && it >= 8) break;
    }
    let best = -1, bv = -1;
    for (let c = 0; c < cands.length; c++) {
      if (!cnt[c]) continue;
      let v = sum[c] / cnt[c];
      if (heur && JSON.stringify(cands[c]) === JSON.stringify(heur)) v += 0.02;   // 비슷하면 감각(휴리스틱)을 따름
      if (v > bv) { bv = v; best = c; }
    }
    return best >= 0 ? cands[best] : heur;
  }

  function ai(s, seat, lv, inner) {
    lv = lv || 2;
    if (lv >= 3 && !inner) { const h = ai(s, seat, 2.5, true); return mcChoose(s, seat, h); }
    if (lv === 2.5) lv = 3;
    const me = seat, hb = habits(s, me);
    const style = (L && L.aiStyle && L.aiStyle(seat)) || 'bal';
    const forget = lv === 1 && Math.random() < 0.3;
    const pc = probLive(s, me, forget);
    const noise = [0, 0.22, 0.11, 0.02][lv] || 0.11;
    const sawWant = s.inv[me].includes('s') && !s.saw;
    const tgt = pickTarget(s, me, lv, hb, { saw: sawWant && pc >= 0.66 });
    const ctg = (() => { const others = alive(s).filter((i) => i !== me && s.cuf[i] === 0); if (!others.length) return null; return pickTarget(s, me, lv, hb, { cuff: true }); })();
    const ctx = { pc, lv, hb, tgt, ctg };
    let best = null, bestV = 0.3 + hb.hoard + (lv === 1 ? 0.12 : 0) + (style === 'def' ? 0.03 : 0);
    const seen = {};
    const inv = s.inv[me];
    for (let i = 0; i < inv.length; i++) {
      const c = inv[i]; if (seen[c]) continue; seen[c] = 1;
      if (Math.random() < (lv === 1 ? 0.25 : lv === 2 ? 0.08 : 0)) continue;   // 쉬움(가끔 보통): 물건을 깜빡
      let r = null;
      if (c === 'a') {
        // 남의 물건 중 지금 가장 쓸모 있는 것
        let bv = 0, bx = null;
        for (const o of alive(s)) {
          if (o === me) continue;
          for (let j = 0; j < s.inv[o].length; j++) {
            const x = s.inv[o][j]; if (x === 'a') continue;
            const v = itemValue(s, me, x, Object.assign({}, ctx, { ctg: x === 'c' ? (s.cuf[o] === 0 ? o : null) : ctg, stolen: true }));
            if (v && v.v * 0.92 > bv) { bv = v.v * 0.92; bx = { to: o, j }; }
          }
        }
        if (bx && !why(s, me, 'a', bx.to, bx.j, false)) r = { v: bv, x: bx };
      } else r = itemValue(s, me, c, ctx);
      if (!r) continue;
      const v = r.v * hb.itemy + (Math.random() - 0.5) * noise * 2;
      if (v > bestV) { bestV = v; best = Object.assign({ t: 'use', i }, r.x || {}); }
    }
    if (best) {
      const c = inv[best.i];
      if (!why(s, me, c, best.to == null ? null : best.to, best.j == null ? null : best.j, false) && (!ITEMS[c].tg || best.to != null)) return best;
    }
    // 쏘기: 실탄일 것 같으면 남에게, 아니면 나에게(공포탄이면 한 번 더)
    let thr = 0.5 + hb.brave + (style === 'gamble' ? -0.05 : style === 'def' ? 0.04 : style === 'agg' ? -0.03 : 0);
    if (s.saw) thr -= 0.15;                      // 톱을 썼으면 남을 쏠 생각
    if (lv >= 3) {
      // 어려움: 상황을 따져 기준을 옮김 — 내가 한 대에 쓰러지면 나를 덜 쏘고, 상대를 쓰러뜨릴 수 있으면 남을 더 쏨
      thr = 0.5 + hb.brave * 0.3 - (s.saw ? 0.15 : 0);
      if (s.hp[me] === 1) thr -= 0.1;
      if (s.hp[tgt] <= (s.saw ? 2 : 1)) thr -= 0.07;
      const left = s.sq.length - s.at;
      if (left >= 4 && s.hp[me] >= 3) thr += 0.04;   // 탄이 많고 넉넉하면 공포탄으로 차례를 이어 볼 만함
    } else if (s.hp[me] === 1) thr -= 0.05;      // 내가 위험하면 나를 덜 쏨
    const p2 = pc + (Math.random() - 0.5) * noise * 2;
    if (pc >= 0.999) return { t: 'fire', to: tgt };
    if (pc <= 0.001 && !(lv === 1 && Math.random() < 0.2)) return { t: 'fire', to: me };
    return { t: 'fire', to: p2 >= thr ? tgt : me };
  }
  function aiDelayFor(s, seat, lv) {
    const e = s.ev[s.ev.length - 1];
    let d = lv === 1 ? 1300 : lv === 3 ? 850 : 1050;
    if (e && (e.k === 'load' || e.k === 'round')) d += 500;
    if (e && e.k === 'use' && e.by === seat) d -= 250;
    return d / paceOf(s.pace);
  }

  /* ======================= 상황 도움말 ======================= */
  function hint(s, seat) {
    if (s.ph !== 'play') return null;
    const [a, b] = remCounts(s);
    const lines = [s.r + '라운드 · 충전 최대 ' + s.lv + ' · 먼저 ' + s.tw + '승'];
    lines.push('총 안에 남은 탄: 실탄 ' + a + ' · 공포탄 ' + b + (s.iv ? ' (지금 탄은 극성 스위치로 뒤집힘)' : ''));
    if (seat >= 0 && seat < s.n) {
      const pc = probLive(s, seat, false);
      const k = s.kn[seat][s.at];
      lines.push(k !== '?' ? '지금 탄: ' + (k === 'L' ? '실탄' : '공포탄') + '(확인함)' : '지금 탄이 실탄일 확률: 약 ' + Math.round(pc * 100) + '%');
      const fut = []; for (let i = s.at + 1; i < s.sq.length; i++) if (s.kn[seat][i] !== '?') fut.push((i - s.at + 1) + '번째 ' + (s.kn[seat][i] === 'L' ? '실탄' : '공포탄'));
      if (fut.length) lines.push('무전기로 확인: ' + fut.join(', '));
      if (s.turn === seat) lines.push(pc >= 0.5 ? '실탄 가능성이 높아요. 상대를 겨누는 편이 유리해요.' : '공포탄 가능성이 높아요. 자신을 겨누면 공포탄일 때 차례가 이어져요.');
    }
    if (s.saw) lines.push('총열 절단 상태: 다음 실탄은 피해 2.');
    return lines.slice(0, 6);
  }

  /* ======================= 소리 ======================= */
  const SFX = { fire: ['fire1', 'fire2'], rack: ['rack1', 'rack2'], shell: ['shell1', 'shell2'], click: ['click'], saw: ['saw'], drink: ['drink'], pill: ['pill'], inject: ['inject'], chain: ['chain'], ping: ['ping'], heart: ['heart'] };
  const Snd = {
    files: {}, ac: null, ok: false,
    init() {
      if (this.ok) return; this.ok = true;
      if (typeof Audio === 'undefined') return;
      for (const k in SFX) this.files[k] = SFX[k].map((f) => { try { const a = new Audio(); a.preload = 'auto'; a.src = ASSET + 'sfx/' + f + '.ogg'; return a; } catch (e) { return null; } });
    },
    vol() { try { return L.audio && L.audio.sfx ? L.audio.sfx() : 0.6; } catch (e) { return 0.6; } },
    ctx() { if (this.ac) return this.ac; try { const A = window.AudioContext || window.webkitAudioContext; this.ac = A ? new A() : null; } catch (e) { this.ac = null; } return this.ac; },
    play(k, gain, rate) {
      const V = this.vol() * (gain == null ? 1 : gain); if (V <= 0) return;
      const list = this.files[k];
      if (list && list.length) {
        const a = list[(Math.random() * list.length) | 0];
        if (a && !a.error) { try { const c = a.cloneNode(); c.volume = Math.max(0, Math.min(1, V)); if (rate) c.playbackRate = rate; const p = c.play(); if (p && p.catch) p.catch(() => {}); return; } catch (e) { /* 합성으로 */ } }
      }
      const f = this['syn_' + k]; if (f) f.call(this, V);
    },
    tone(type, f0, f1, dur, g, delay) {
      const ac = this.ctx(); if (!ac) return;
      const t = ac.currentTime + (delay || 0);
      const o = ac.createOscillator(), gn = ac.createGain(); o.type = type; o.frequency.setValueAtTime(f0, t); if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
      gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(g, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(gn); gn.connect(ac.destination); o.start(t); o.stop(t + dur + 0.02);
    },
    noise(dur, g, f0, f1, delay, type) {
      const ac = this.ctx(); if (!ac) return;
      const t = ac.currentTime + (delay || 0), n = (ac.sampleRate * dur) | 0, buf = ac.createBuffer(1, n, ac.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
      const src = ac.createBufferSource(); src.buffer = buf;
      const fl = ac.createBiquadFilter(); fl.type = type || 'bandpass'; fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(f1, t + dur);
      const gn = ac.createGain(); gn.gain.setValueAtTime(g, t);
      src.connect(fl); fl.connect(gn); gn.connect(ac.destination); src.start(t);
    },
    syn_fire(V) { this.noise(0.6, 0.7 * V, 4000, 200, 0, 'lowpass'); this.tone('sine', 90, 40, 0.3, 0.5 * V); },
    syn_click(V) { this.tone('square', 1800, 1700, 0.03, 0.12 * V); this.tone('square', 2400, 2300, 0.03, 0.1 * V, 0.06); },
    syn_rack(V) { this.noise(0.12, 0.3 * V, 2500, 1200); this.noise(0.1, 0.35 * V, 3000, 1500, 0.16); },
    syn_shell(V) { [0, 0.09, 0.15].forEach((d, i) => this.tone('triangle', 3200 - i * 300, 2800 - i * 300, 0.05, 0.06 * V, d)); },
    // 게임 고유 합성음
    beep(V, hi) { this.tone('sine', hi ? 1320 : 990, hi ? 1320 : 990, 0.09, 0.12 * V); },
    flat(V) { this.tone('sine', 880, 880, 1.1, 0.1 * V); },
    lighter(V) { this.tone('square', 2600, 2000, 0.025, 0.08 * V); this.noise(0.5, 0.16 * V, 900, 300, 0.05); this.noise(0.9, 0.08 * V, 600, 200, 0.6, 'lowpass'); },
    radio(V) { this.noise(0.45, 0.22 * V, 1800, 1500); this.tone('sine', 660, 660, 0.12, 0.08 * V, 0.5); this.tone('sine', 520, 520, 0.18, 0.08 * V, 0.66); },
    flip(V) { this.tone('square', 300, 1200, 0.12, 0.06 * V); this.tone('square', 1200, 300, 0.12, 0.05 * V, 0.13); },
    hum(V) { this.tone('sawtooth', 55, 52, 0.5, 0.04 * V); },
    sawr(V) { for (let i = 0; i < 4; i++) this.noise(0.12, 0.2 * V, 3500, 2000, i * 0.13); },
  };
  const sfx = (k, g, r) => { try { Snd.play(k, g, r); } catch (e) { /* 소리 실패는 무시 */ } };
  const syn = (k, ...a) => { try { const V = Snd.vol(); if (V > 0) Snd[k](V, ...a); } catch (e) { /* 무시 */ } };

  /* ======================= 3D 장면 불러오기 ======================= */
  const scripts = {};
  function loadScript(src) {
    if (!scripts[src]) scripts[src] = new Promise((ok, no) => {
      const el = document.createElement('script'); el.src = src; el.async = true;
      el.onload = () => ok(); el.onerror = () => { delete scripts[src]; no(new Error('불러오기 실패: ' + src)); };
      document.head.appendChild(el);
    });
    return scripts[src];
  }
  function webglOK() { try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) { return false; } }
  function loadScene() {
    if (!webglOK()) return Promise.reject(new Error('no webgl'));
    const three = window.THREE ? Promise.resolve() : loadScript('assets/hyperrace/lib/three.min.js');
    return three.then(() => loadScript(ASSET + 'scene.js')).then(() => { if (!window.BS_SCENE) throw new Error('scene'); return window.BS_SCENE; });
  }

  /* ======================= 화면 ======================= */
  const CSS = `
.bs-root *{box-sizing:border-box}
.bs-root{position:absolute;inset:0;overflow:hidden;background:#070609;color:#efe6d6;font-family:var(--f-body),sans-serif;user-select:none;-webkit-user-select:none}
.bs-3d{position:absolute;inset:0}
.bs-3d canvas{display:block;width:100%;height:100%}
.bs-fallback{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 42%,#3a2f22 0%,#17120d 38%,#070609 72%)}
.bs-fallback:after{content:'';position:absolute;left:12%;right:12%;top:30%;height:26%;border-radius:40%;background:radial-gradient(ellipse,#2c3a2c,#141a13 70%);box-shadow:0 20px 60px #000}
.bs-tags{position:absolute;inset:0;pointer-events:none;z-index:3}
.bs-ftag{position:absolute;transform:translate(-50%,-50%);display:flex;align-items:center;gap:5px;font:600 12.5px var(--f-body),sans-serif;color:#f4ead8;background:rgba(8,8,10,.72);border:1px solid #4a4552;border-radius:10px;padding:1px 8px;white-space:nowrap;max-width:31%;overflow:hidden;text-overflow:ellipsis}
.bs-ftag.aimed{border-color:#ff6a5a;background:rgba(110,20,14,.88)}
.bs-ftag.pick{border-color:#ee6a55}
.bs-ftag.out{color:#b8aec0;text-decoration:line-through}
.bs-vig{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at 50% 45%,transparent 45%,rgba(0,0,0,.55) 100%)}
.bs-flash{position:absolute;inset:0;pointer-events:none;background:#fff3c4;opacity:0}
.bs-hurt{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse,rgba(160,0,0,.15),rgba(150,0,0,.75));opacity:0}
.bs-dark{position:absolute;inset:0;pointer-events:none;background:#000;opacity:0}
.bs-top{position:absolute;left:6px;right:54px;top:6px;display:flex;gap:6px;justify-content:center;z-index:5}
.bs-plate{flex:1 1 0;max-width:170px;min-width:0;min-height:62px;background:linear-gradient(#141519,#0b0b0e);border:1px solid #2a2c33;border-radius:10px;padding:5px 7px 6px;box-shadow:0 4px 14px rgba(0,0,0,.6),inset 0 1px 0 rgba(255,255,255,.05);position:relative;transition:transform .15s,border-color .15s,box-shadow .15s}
.bs-plate.bs-on{border-color:#e3ae45;box-shadow:0 0 0 1px #e3ae45,0 0 18px rgba(227,174,69,.35)}
.bs-plate.dead{opacity:.5;filter:saturate(.3)}
.bs-plate.pick{cursor:pointer;border-color:#ee6a55;box-shadow:0 0 0 2px #ee6a55,0 0 22px rgba(238,106,85,.45);animation:bsPulse 1s infinite}
.bs-plate.aimed{border-color:#ff4b3a;box-shadow:0 0 0 3px #ff4b3a,0 0 26px rgba(255,75,58,.6)}
.bs-plate.hit{animation:bsHit .45s}
@keyframes bsPulse{50%{transform:translateY(-2px)}}
@keyframes bsHit{20%{transform:translateX(-5px)}40%{transform:translateX(5px)}60%{transform:translateX(-3px)}}
.bs-pn{display:flex;align-items:center;gap:5px;font-size:13.5px;font-weight:700;white-space:nowrap;overflow:hidden}
.bs-pn b{overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0}
.bs-dot{width:9px;height:9px;border-radius:50%;flex:0 0 auto;background:var(--c);box-shadow:0 0 6px var(--c)}
.bs-wins{display:flex;align-items:center;gap:3px;flex:0 0 auto;font-size:12px;font-weight:600;color:#e8c77a}
.bs-wins em{font-style:normal;margin-right:1px}
.bs-wins i{width:10px;height:10px;border-radius:2px;border:1.5px solid #e3ae45;display:block}
.bs-wins i.on{background:#e3ae45}
.bs-def{display:flex;align-items:center;gap:4px;margin-top:4px;background:#030806;border:1px solid #2a3d30;border-radius:5px;padding:3px 4px;height:22px}
.bs-def svg{flex:0 0 auto}
.bs-cells{display:flex;gap:2px;flex:1;min-width:0}
.bs-cells i{flex:1;max-width:14px;height:12px;border-radius:2px;background:#0f2417;border:1px solid #2c5238;display:block}
.bs-cells i.on{background:#57f28a;border-color:#8bffb0;box-shadow:0 0 6px rgba(87,242,138,.7)}
.bs-cells.low i.on{background:#ff5a4a;border-color:#ff9a8a;box-shadow:0 0 6px rgba(255,90,74,.8)}
.bs-def .num{font-family:var(--f-mono),monospace;font-size:13px;font-weight:700;color:#8dffb6;min-width:26px;text-align:right}
.bs-def.flat .num{color:#ff5a4a}
.bs-st{display:flex;flex-wrap:wrap;gap:3px;margin-top:4px;min-height:18px;align-items:center}
.bs-st .it{color:#e4dac9;display:inline-flex}
.bs-tag{font-size:12px;font-weight:600;line-height:16px;padding:0 5px;border-radius:4px;background:#6a2219;color:#ffe0d4;white-space:nowrap}
.bs-tag.cuf{background:#433d60;color:#e6e1ff}
.bs-mid{position:absolute;left:50%;transform:translateX(-50%);z-index:4;display:flex;flex-direction:column;align-items:center;gap:4px;pointer-events:none}
.bs-shells{display:flex;align-items:center;gap:8px;padding:4px 12px;border-radius:999px;background:rgba(8,8,10,.82);border:1px solid #3a3740;font-size:13px;white-space:nowrap}
.bs-shells .grp{display:flex;align-items:center;gap:4px;font-family:var(--f-mono),monospace;font-size:15px;font-weight:700}
.bs-shells .grp small{font:600 12px var(--f-body),sans-serif;margin-right:1px}
.bs-shells .grp.L small{color:#ff9a8a}.bs-shells .grp.B small{color:#9fc0ff}
.bs-sh{display:inline-block;width:8px;height:16px;border-radius:2px 2px 1px 1px;position:relative}
.bs-sh:after{content:'';position:absolute;left:-1px;right:-1px;bottom:-1px;height:4px;border-radius:1px;background:#c9a24a}
.bs-sh.L{background:#d23a2e}.bs-sh.B{background:#2f6fd6}
.bs-flags{display:flex;gap:4px}
.bs-cap{position:absolute;left:10px;right:10px;z-index:4;text-align:center;pointer-events:none;font-size:14px;color:#f4ead8;opacity:0;transition:opacity .25s}
.bs-cap span{display:inline-block;max-width:100%;background:rgba(8,8,10,.78);border:1px solid #3a3740;border-radius:12px;padding:3px 12px;line-height:20px}
.bs-cap.on{opacity:1}
.bs-bot{position:absolute;left:0;right:0;bottom:0;z-index:6;padding:8px 8px calc(8px + env(safe-area-inset-bottom));background:linear-gradient(rgba(6,6,8,0),rgba(6,6,8,.88) 18px,#0a090c);display:flex;flex-direction:column;gap:6px;max-width:620px;margin:0 auto}
.bs-row{display:flex;gap:8px;align-items:stretch}
.bs-me{flex:0 0 46%;max-width:240px}
.bs-me .bs-plate{max-width:none;height:100%}
.bs-know{flex:1;min-width:0;background:rgba(14,14,18,.9);border:1px solid #2a2a31;border-radius:10px;padding:5px 7px;display:flex;flex-direction:column;justify-content:center;gap:4px}
.bs-know .lab{font-size:12.5px;color:#cfc4d8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bs-seq{display:flex;gap:3px;flex-wrap:nowrap;overflow:hidden}
.bs-seq b{width:19px;height:25px;border-radius:3px 3px 2px 2px;background:#2a2930;border:1px solid #4a4954;font-size:12px;line-height:23px;text-align:center;color:#c2bacb;font-weight:700;flex:0 0 auto;position:relative}
.bs-seq b.L{background:#c3352a;border-color:#ff8a7a;color:#fff}
.bs-seq b.B{background:#2a62c4;border-color:#8ab4ff;color:#fff}
.bs-seq b.cur{outline:2px solid #e3ae45;outline-offset:1px}
.bs-odds{font-size:14px;font-weight:700;color:#ffd47a}
.bs-odds b{font-family:var(--f-mono),monospace}
.bs-tray{align-self:flex-start;align-content:start;display:grid;grid-template-columns:repeat(4,1fr);gap:6px;flex:0 0 auto;width:min(222px,58vw)}
.bs-slot{height:54px;min-width:44px;border-radius:9px;border:1px dashed #3a3842;background:rgba(20,19,24,.6);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;color:#ece3d3;padding:0;position:relative}
.bs-slot .sn{font:600 12px var(--f-body),sans-serif;line-height:14px;color:#ddd3c3;white-space:nowrap}
.bs-slot.has{border:1px solid #5a5462;background:linear-gradient(#2a2730,#1a181e);cursor:pointer}
.bs-slot.has:active{transform:scale(.95)}
.bs-slot.sel{border-color:#e3ae45;box-shadow:0 0 0 2px #e3ae45}
.bs-slot.new{animation:bsNew .5s}
.bs-slot.off{opacity:.6}
@keyframes bsNew{0%{transform:scale(.4);opacity:0}70%{transform:scale(1.1)}}
.bs-act{flex:1;display:flex;flex-direction:column;gap:6px;min-width:0}
.bs-act .btn{min-height:46px;font-size:14px;padding:4px 6px;width:100%;line-height:1.15}
.bs-act .note{font-size:13.5px;color:#d8cee0;text-align:center;line-height:1.35;padding:4px 2px}
.bs-act .note.wait{font-size:15px;font-weight:600;color:#e8dfee;padding:14px 2px;display:flex;align-items:center;justify-content:center;gap:6px}
.bs-fire{background:linear-gradient(#b8322a,#7d1a14)!important;color:#fff!important;border-color:#ff7a6a!important;font-weight:800}
.bs-fire[disabled]{background:#1c171c!important;border:1px dashed #5a4c58!important;color:#b3a7b4!important;font-weight:600}
.bs-card{position:absolute;left:8px;right:8px;z-index:8;max-width:420px;margin:0 auto;background:rgba(16,15,20,.96);border:1px solid #4a4552;border-radius:12px;padding:10px 12px;box-shadow:0 10px 30px rgba(0,0,0,.7);display:none}
.bs-card.on{display:block}
.bs-card h4{margin:0 0 4px;font-size:15px;display:flex;align-items:center;gap:8px;color:#ffe2a6}
.bs-card p{margin:0 0 8px;font-size:13px;line-height:1.45;color:#ddd3c3}
.bs-card .why{color:#ff9a8a;font-size:12px;margin:-4px 0 8px}
.bs-card .row{display:flex;gap:8px}
.bs-card .row .btn{flex:1;min-height:44px}
.bs-card .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:8px}
.bs-card .grid .bs-slot{height:56px;flex-direction:column;font-size:12px;gap:1px}
.bs-load{position:absolute;left:50%;top:40%;transform:translate(-50%,-50%);z-index:7;pointer-events:none;background:rgba(8,8,10,.8);border:1px solid #3a3540;border-radius:12px;padding:8px 14px;text-align:center;opacity:0;transition:opacity .2s;max-width:86%}
.bs-load.on{opacity:1}
.bs-load .t{font-size:13px;color:#d8cee0;margin-bottom:4px}
.bs-load .rowsh{display:flex;gap:4px;justify-content:center;flex-wrap:wrap}
.bs-load .rowsh .bs-sh{width:10px;height:22px}
.bs-load .n{font-family:var(--f-mono),monospace;font-size:14px;margin-top:4px;font-weight:700}
.bs-load .n .r{color:#ff6b5c}.bs-load .n .b{color:#6ea3ff}
.bs-reveal{position:absolute;left:50%;top:46%;transform:translate(-50%,-50%) scale(.6);z-index:7;pointer-events:none;padding:6px 14px;border-radius:999px;font-weight:800;font-size:16px;opacity:0;transition:opacity .18s,transform .18s;white-space:nowrap}
.bs-reveal.on{opacity:1;transform:translate(-50%,-50%) scale(1)}
.bs-reveal.L{background:rgba(160,30,22,.9);color:#fff;border:1px solid #ff8a7a}
.bs-reveal.B{background:rgba(30,70,160,.9);color:#fff;border:1px solid #8ab4ff}
.bs-reveal.N{background:rgba(30,30,36,.9);color:#eee;border:1px solid #555}
.bs-loading{position:absolute;left:0;right:0;top:44%;text-align:center;font-size:13px;color:#b8aec0;pointer-events:none}
html.no-anim .bs-plate.pick{animation:none}
`;

  function mount(root, api) {
    const h = L.h;
    Snd.init();
    const styleEl = h('style', { text: CSS });
    const wrap = h('div', { class: 'bs-root' });
    root.append(styleEl, wrap);
    const host = h('div', { class: 'bs-3d' });
    const fb = h('div', { class: 'bs-fallback' });
    const loadingEl = h('div', { class: 'bs-loading', text: '불러오는 중' });
    const tagsEl = h('div', { class: 'bs-tags' });
    const vig = h('div', { class: 'bs-vig' }), flash = h('div', { class: 'bs-flash' }), hurtEl = h('div', { class: 'bs-hurt' }), dark = h('div', { class: 'bs-dark' });
    const top = h('div', { class: 'bs-top' });
    const mid = h('div', { class: 'bs-mid' });
    const shellsEl = h('div', { class: 'bs-shells' });
    mid.append(shellsEl);
    const cap = h('div', { class: 'bs-cap' });
    const card = h('div', { class: 'bs-card' });
    const loadEl = h('div', { class: 'bs-load' });
    const revEl = h('div', { class: 'bs-reveal' });
    const bot = h('div', { class: 'bs-bot' });
    const row1 = h('div', { class: 'bs-row' }), row2 = h('div', { class: 'bs-row' });
    const meBox = h('div', { class: 'bs-me' }), know = h('div', { class: 'bs-know' });
    const tray = h('div', { class: 'bs-tray' }), act = h('div', { class: 'bs-act' });
    row1.append(meBox, know); row2.append(tray, act); bot.append(row1, row2);
    wrap.append(fb, host, tagsEl, loadingEl, vig, top, mid, cap, loadEl, revEl, hurtEl, flash, dark, card, bot);

    let S = null;            // 마지막으로 받은 상태
    let D = null;            // 지금 화면에 보이는 공개 정보(이벤트 연출에 맞춰 바뀜)
    let seen = 0, running = false, queue = [], dead = false, sent = 0, aim = null, sel = null, mode = null, anchor = -1;
    let scene = null, sceneP = null, capT = 0;
    const timers = [];
    const P = () => api.players;
    const pname = (p) => (api.players[p] ? api.players[p].name : (S ? S.nm[p] : '?'));
    const pcol = (p) => (api.players[p] ? api.players[p].color : '#888');
    // 배속 = 시험용 배속 × core 「빠른 진행」 × 이 판의 「연출 속도」(방 옵션이라 온라인에서도 모두 같음)
    const sp = () => Math.max(0.1, (L.debug && L.debug.speed) || 1) * Math.max(1, (L.speed && L.speed()) || 1) * paceOf(S && S.pace);
    const T = (ms) => ms / sp();
    const wait = (ms) => new Promise((ok) => { const t = setTimeout(ok, T(ms)); timers.push(t); });
    const motion = () => { try { return !L.anim || L.anim.on(); } catch (e) { return true; } };
    const fxAmt = () => { try { return L.fx ? L.fx() : 1; } catch (e) { return 1; } };
    let busyOn = false;
    const busy = (on) => { if (busyOn !== on) { busyOn = on; api.setBusy(on); } };

    // 이 화면이 비밀 정보를 볼 자리
    const looker = () => { const v = api.viewer(); return typeof v === 'number' ? v : -1; };
    function pickAnchor() {
      const v = looker(); if (v >= 0) return v;
      if (anchor >= 0) return anchor;
      const m = api.mySeats ? api.mySeats() : []; return m.length ? m[0] : 0;
    }
    const others = () => { const a = []; for (let k = 1; k < S.n; k++) a.push((anchor + k) % S.n); return a; };

    /* ---------- 3D ---------- */
    sceneP = loadScene().then((M) => {
      if (dead) return;
      try {
        scene = M.create(host, { speed: sp, motion, fx: fxAmt, colors: () => S ? [...Array(S.n).keys()].map(pcol) : [] });
        fb.style.display = 'none'; loadingEl.remove();
        layoutScene();
      } catch (e) { console.warn('[buckshot] 3D 실패', e); scene = null; loadingEl.remove(); }
    }).catch(() => { loadingEl.remove(); });
    // 3D 장면에서 사람을 눌러 겨누기(물건 대상 고르기도 같음) — 작게 움직인 탭만
    let tapD = null;
    host.addEventListener('pointerdown', (e) => { tapD = { x: e.clientX, y: e.clientY, id: e.pointerId }; });
    host.addEventListener('pointercancel', () => { tapD = null; });
    host.addEventListener('pointerup', (e) => {
      const d = tapD; tapD = null;
      if (!d || d.id !== e.pointerId || Math.hypot(e.clientX - d.x, e.clientY - d.y) > 14) return;
      if (!scene || !S || !myTurn() || !scene.screenOf) return;
      const r = host.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      let best = null, bd = 1e9;
      for (const p of others()) {
        if (S.out[p]) continue;
        const q = scene.screenOf(p); if (!q) continue;
        const dd = Math.hypot(x - q.x, (y - q.y) / 1.4);
        if (dd < q.r && dd < bd) { bd = dd; best = p; }
      }
      if (best == null) return;
      if (sel != null) closeCard();
      onPlate(best);
    });
    // 3D 사람 위 이름표(위쪽 판과 같은 사람인지 바로 알 수 있게)
    function placeTags() {
      tagsEl.textContent = '';
      if (!scene || !scene.screenOf || !S || !D) return;
      for (const p of others()) {
        const q = scene.screenOf(p); if (!q) continue;
        const isOut = !!(D.o & (1 << p));
        const pickable = myTurn() && mode && mode.pick && mode.pick(p);
        const el = h('div', { class: 'bs-ftag' + (aim === p && myTurn() ? ' aimed' : '') + (pickable ? ' pick' : '') + (isOut ? ' out' : '') },
          h('span', { class: 'bs-dot', style: { '--c': pcol(p) } }), pname(p) + (isOut ? ' · 탈락' : ''));
        el.style.left = Math.round(q.x) + 'px'; el.style.top = Math.round(q.y + q.r * 0.3) + 'px';
        tagsEl.append(el);
      }
    }
    function layoutScene() {
      if (!scene || !S || !D) return;
      scene.setSeats({ me: anchor, order: others(), n: S.n, out: S.n ? [...Array(S.n).keys()].map((i) => !!(D.o & (1 << i))) : [], inv: D.i, colors: [...Array(S.n).keys()].map(pcol), saw: D.s, top: topH(), bottom: bot.offsetHeight || 220 });
      placeTags();
    }
    const topH = () => (top.offsetTop + top.offsetHeight + 34) || 110;

    /* ---------- 공개 정보 그리기 ---------- */
    function plate(p, big) {
      const isOut = !!(D.o & (1 << p));
      const el = h('div', { class: 'bs-plate' + (isOut ? ' dead' : '') + (D.t === p && S.ph === 'play' && !isOut ? ' bs-on' : '') });
      el.dataset.seat = p;
      const pn = h('div', { class: 'bs-pn' }, h('span', { class: 'bs-dot', style: { '--c': pcol(p) } }), h('b', { text: pname(p) + (big ? '' : '') }));
      const wins = h('span', { class: 'bs-wins', title: '라운드 승리' }, h('em', { text: '승' }));
      for (let k = 0; k < S.tw; k++) wins.append(h('i', { class: k < D.w[p] ? 'on' : '' }));
      pn.append(wins);
      const hp = D.h[p], cells = h('div', { class: 'bs-cells' + (hp <= 1 ? ' low' : '') });
      for (let k = 0; k < D.lv; k++) cells.append(h('i', { class: k < hp ? 'on' : '' }));
      const ecg = h('span'); ecg.innerHTML = isOut ? '<svg width="18" height="12" viewBox="0 0 18 12"><path d="M0 6h18" stroke="#ff5a4a" stroke-width="1.6"/></svg>' : '<svg width="18" height="12" viewBox="0 0 18 12"><path d="M0 7h4l2-5 3 9 2-6h7" fill="none" stroke="' + (hp <= 1 ? '#ff5a4a' : '#57f28a') + '" stroke-width="1.6" stroke-linejoin="round"/></svg>';
      const def = h('div', { class: 'bs-def' + (isOut ? ' flat' : ''), title: '충전(목숨)' }, ecg, cells, h('span', { class: 'num', text: hp + '/' + D.lv }));
      const stl = h('div', { class: 'bs-st' });
      if (D.c[p] === 1) stl.append(h('span', { class: 'bs-tag cuf', text: '족쇄' }));
      if (isOut) stl.append(h('span', { class: 'bs-tag', text: '탈락' }));
      if (!big) for (const c of D.i[p] || '') { const s = h('span', { class: 'it', title: ITEMS[c].n }); s.innerHTML = icon(c, 18); stl.append(s); }
      el.append(pn, def, stl);
      return el;
    }
    function drawPlates() {
      top.textContent = '';
      for (const p of others()) {
        const el = plate(p, false);
        if (mode && mode.pick && mode.pick(p)) el.classList.add('pick');
        if (aim === p) el.classList.add('aimed');
        el.addEventListener('click', () => onPlate(p));
        top.append(el);
      }
      meBox.textContent = '';
      const me = plate(anchor, true);
      if (mode && mode.pick && mode.pick(anchor)) me.classList.add('pick');
      if (aim === anchor) me.classList.add('aimed');
      me.addEventListener('click', () => onPlate(anchor));
      meBox.append(me);
      mid.style.top = (top.offsetTop + top.offsetHeight + 6) + 'px';
    }
    function drawShells() {
      shellsEl.textContent = '';
      const g = (cls, n, label) => { const e = h('span', { class: 'grp ' + cls, title: label }); e.append(h('i', { class: 'bs-sh ' + cls }), h('small', { text: label === '실탄' ? '실' : '공' }), h('span', { text: String(n) })); return e; };
      if (D.rl + D.rb === 0) { shellsEl.append(h('span', { text: '재장전', style: { fontSize: '13px', color: '#d8cee0' } })); return; }
      shellsEl.append(h('span', { text: '남은 탄', style: { fontSize: '12.5px', color: '#d8cee0' } }), g('L', D.rl, '실탄'), g('B', D.rb, '공포탄'));
      if (D.s) shellsEl.append(h('span', { class: 'bs-tag', text: '톱 ×2' }));
      if (D.f) shellsEl.append(h('span', { class: 'bs-tag cuf', text: '지금 탄 뒤집힘' }));
    }
    function drawKnow() {
      know.textContent = '';
      const v = looker();
      const len = D.n - D.a;
      const seq = h('div', { class: 'bs-seq' });
      const kn = v >= 0 && S && S.ld === D.ld && S.kn[v] ? S.kn[v] : '';
      // 남은 탄이 한 종류뿐이면(개수로 확정) 모두 그 색
      let ua = D.rl, ub = D.rb;
      for (let i = 1; i < len; i++) { const c = kn[D.a + i]; if (c === 'L') ua--; else if (c === 'B') ub--; }
      const k0 = kn[D.a];
      if (k0 && k0 !== '?') { const o = D.f ? (k0 === 'L' ? 'B' : 'L') : k0; if (o === 'L') ua--; else ub--; }
      const only = ua > 0 && ub <= 0 ? 'L' : ub > 0 && ua <= 0 ? 'B' : null;
      for (let i = 0; i < len; i++) {
        let c = kn[D.a + i] || '?';
        if (c === '?' && only) c = i === 0 && D.f ? (only === 'L' ? 'B' : 'L') : only;
        seq.append(h('b', { class: (c !== '?' ? c : '') + (i === 0 ? ' cur' : ''), text: c === '?' ? String(i + 1) : c === 'L' ? '실' : '공' }));
      }
      if (v < 0) {
        know.append(h('div', { class: 'lab', text: '탄 순서(맨 앞 = 지금 탄)' }), seq);
        return;
      }
      const pc = S && S.ld === D.ld ? probLive(Object.assign({}, S, { at: D.a, iv: D.f }), v, false) : D.rl / Math.max(1, D.rl + D.rb);
      const odds = h('span', { class: 'bs-odds' });
      if (pc >= 0.999 || pc <= 0.001) odds.textContent = '지금 탄: ' + (pc >= 0.999 ? '실탄' : '공포탄');
      else odds.append('실탄일 확률 ', h('b', { text: Math.round(pc * 100) + '%' }));
      know.append(h('div', { class: 'lab' }, odds), seq);
    }
    function drawTray() {
      tray.textContent = '';
      const inv = D.i[anchor] || '';
      const mine = myTurn();
      for (let k = 0; k < CAP; k++) {
        const c = inv[k];
        const b = h('button', { class: 'bs-slot' + (c ? ' has' : '') + (sel === k ? ' sel' : '') + (c && !mine ? ' off' : ''), 'aria-label': c ? ITEMS[c].n : '빈 칸' });
        if (c) { b.innerHTML = icon(c, 24); b.append(h('span', { class: 'sn', text: SHORT[c] })); b.title = ITEMS[c].n; b.addEventListener('click', () => openItem(k)); }
        tray.append(b);
      }
    }
    function myTurn() {
      return !!(S && S.ph === 'play' && !running && queue.length === 0 && S.turn === anchor && api.canAct(S.turn) && looker() === anchor && !(sent && Date.now() - sent < 3000));
    }
    function drawAct() {
      act.textContent = '';
      if (!S) return;
      if (S.ph !== 'play') { act.append(h('div', { class: 'note', text: '판이 끝났어요' })); return; }
      if (!myTurn()) {
        const t = D ? D.t : S.turn;
        const nt = h('div', { class: 'note wait' });
        if (running || queue.length) nt.textContent = '진행 중';
        else if (t === anchor && api.canAct(t)) nt.textContent = '처리 중';
        else nt.append(h('span', { class: 'bs-dot', style: { '--c': pcol(t) } }), pname(t) + ' 차례');
        act.append(nt);
        return;
      }
      if (mode) {
        act.append(h('div', { class: 'note', text: mode.say }), h('button', { class: 'btn', text: '취소', onclick: () => { mode = null; redraw(); } }));
        return;
      }
      const opp = others().filter((p) => !S.out[p]);
      if (opp.length === 1) {
        act.append(h('button', { class: 'btn' + (aim === opp[0] ? ' primary' : ''), 'data-key': 'KeyE', text: '상대 겨누기', onclick: () => setAim(opp[0]) }));
      } else if (aim == null || aim === anchor) act.append(h('div', { class: 'note', text: '위쪽 판이나 사람을 눌러 대상 선택' }));
      act.append(h('button', { class: 'btn' + (aim === anchor ? ' primary' : ''), 'data-key': 'KeyQ', text: '자신 겨누기', onclick: () => setAim(anchor) }));
      if (aim != null && aim !== anchor && opp.length > 1) act.prepend(h('div', { class: 'note', text: pname(aim) + ' 겨눔' }));
      const fireB = h('button', { class: 'btn bs-fire', 'data-key': 'Space', text: aim == null ? '발사 · 대상 먼저' : '발사 → ' + (aim === anchor ? '자신' : pname(aim)), onclick: doFire });
      if (aim == null) fireB.disabled = true;
      act.append(fireB);
    }
    function redraw() {
      if (!S || !D) return;
      anchor = pickAnchor();
      drawPlates(); drawShells(); drawKnow(); drawTray(); drawAct();
      if (sel != null && !myTurn()) closeCard();
      layoutScene();
      if (scene) scene.aim(aim == null || !myTurn() ? null : aim);
    }

    /* ---------- 내 조작 ---------- */
    function setAim(p) { if (!myTurn()) return; aim = aim === p ? null : p; sfx('click', 0.3); redraw(); }
    function onPlate(p) {
      if (!myTurn()) return;
      if (mode && mode.pick) { if (mode.pick(p)) mode.go(p); return; }
      if (S.out[p]) return;
      setAim(p);
    }
    function send(a) {
      if (!myTurn()) return;
      sent = Date.now(); aim = null; sel = null; mode = null; closeCard();
      try { api.act(a); } catch (e) { sent = 0; }
      redraw();
    }
    function doFire() { if (aim == null) return; send({ t: 'fire', to: aim }); }
    function closeCard() { card.classList.remove('on'); card.textContent = ''; sel = null; }
    function openItem(k) {
      if (!S) return;
      const c = (D.i[anchor] || '')[k]; if (!c) return;
      sel = k; mode = null;
      card.textContent = '';
      const it = ITEMS[c];
      const head = h('h4'); head.innerHTML = icon(c, 22); head.append(document.createTextNode(it.n));
      card.append(head, h('p', { text: it.d }));
      const mine = myTurn();
      const w = mine ? why(S, anchor, c, null, null, false) : '내 차례에만 쓸 수 있어요';
      if (w) card.append(h('div', { class: 'why', text: w }));
      const use = h('button', { class: 'btn primary', text: it.tg ? '쓰기 → 사람 고르기' : '쓰기', onclick: () => useItem(k) });
      if (w) use.disabled = true;
      card.append(h('div', { class: 'row' }, h('button', { class: 'btn', text: '닫기', onclick: () => { closeCard(); redraw(); } }), use));
      card.classList.add('on');
      card.style.bottom = (bot.offsetHeight + 6) + 'px';
      drawTray();
    }
    function useItem(k) {
      const c = S.inv[anchor][k]; if (!c) return;
      if (!ITEMS[c].tg) { send({ t: 'use', i: k }); return; }
      closeCard();
      if (c === 'c') {
        mode = { say: '족쇄를 채울 사람의 판을 눌러요', pick: (p) => p !== anchor && !S.out[p] && S.cuf[p] === 0, go: (p) => send({ t: 'use', i: k, to: p }) };
      } else {
        mode = { say: '물건을 빼앗을 사람의 판을 눌러요', pick: (p) => p !== anchor && !S.out[p] && [...S.inv[p]].some((x) => x !== 'a' && !why(S, anchor, x, p, null, true)), go: (p) => stealPick(k, p) };
      }
      // 고를 사람이 한 명뿐이면 바로
      const cand = others().filter((p) => mode.pick(p));
      if (cand.length === 1 && c === 'c') { mode.go(cand[0]); return; }
      if (cand.length === 1) { stealPick(k, cand[0]); return; }
      redraw();
    }
    function stealPick(k, p) {
      mode = null; card.textContent = '';
      const head = h('h4'); head.innerHTML = icon('a', 22); head.append(document.createTextNode(pname(p) + '의 물건 빼앗기'));
      card.append(head, h('p', { text: '빼앗은 물건은 바로 써요.' }));
      const g = h('div', { class: 'grid' });
      [...S.inv[p]].forEach((x, j) => {
        const bad = x === 'a' ? '못 빼앗음' : why(S, anchor, x, p, null, true);
        const b = h('button', { class: 'bs-slot has' + (bad ? ' off' : ''), title: ITEMS[x].n + (bad ? ' — ' + bad : '') });
        b.innerHTML = icon(x, 22); b.append(h('span', { text: SHORT[x] }));
        if (!bad) b.addEventListener('click', () => send({ t: 'use', i: k, to: p, j }));
        else b.disabled = true;
        g.append(b);
      });
      card.append(g, h('div', { class: 'row' }, h('button', { class: 'btn', text: '취소', onclick: () => { closeCard(); redraw(); } })));
      card.classList.add('on'); card.style.bottom = (bot.offsetHeight + 6) + 'px';
      redraw();
    }
    const onCancel = (e) => { if (mode || sel != null || aim != null) { mode = null; aim = null; closeCard(); redraw(); e.preventDefault(); } };
    window.addEventListener('lounge-cancel', onCancel);
    const onKey = (e) => {
      if (!myTurn() || e.repeat) return;
      const t = e.target; if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) return;
      if (e.code === 'KeyQ') { setAim(anchor); e.preventDefault(); }
      else if (e.code === 'KeyE') { const o = others().filter((p) => !S.out[p]); if (o.length) { const i = aim == null ? 0 : (o.indexOf(aim) + 1) % o.length; setAim(o[i]); } e.preventDefault(); }
      else if (e.code === 'Space' && aim != null) { doFire(); e.preventDefault(); }
      else if (/^Digit[1-8]$/.test(e.code)) { const k = +e.code.slice(5) - 1; if ((D.i[anchor] || '')[k]) { openItem(k); e.preventDefault(); } }
    };
    window.addEventListener('keydown', onKey);
    const onRs = () => { if (card.classList.contains('on')) card.style.bottom = (bot.offsetHeight + 6) + 'px'; redraw(); };
    window.addEventListener('resize', onRs);

    /* ---------- 연출 ---------- */
    function say(text, ms) {
      cap.textContent = ''; cap.append(h('span', { text })); cap.classList.add('on');
      cap.style.bottom = ((bot.offsetHeight || 200) + 8) + 'px';
      clearTimeout(capT); capT = setTimeout(() => cap.classList.remove('on'), Math.min(1600, Math.max(600, T(ms || 1500)) + 300));
    }
    function pulse(el, cls, ms) { el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls); setTimeout(() => el.classList.remove(cls), Math.max(200, T(ms || 500))); }
    function flashFx(kind, amt) {
      const a = fxAmt(); if (a <= 0) return;
      const el = kind === 'hurt' ? hurtEl : flash;
      el.style.transition = 'none'; el.style.opacity = String((kind === 'hurt' ? 0.9 : 0.55) * a * (amt || 1)); void el.offsetWidth;
      el.style.transition = 'opacity ' + Math.max(0.12, T(kind === 'hurt' ? 700 : 260) / 1000) + 's'; el.style.opacity = '0';
    }
    function reveal(sh, text, ms) {
      revEl.className = 'bs-reveal ' + sh; revEl.textContent = text; void revEl.offsetWidth; revEl.classList.add('on');
      const t = setTimeout(() => revEl.classList.remove('on'), Math.max(350, T(ms || 900))); timers.push(t);
    }
    function plateEl(p) { return wrap.querySelector('.bs-plate[data-seat="' + p + '"]'); }
    function setD(v) { D = v; redraw(); }

    async function playEv(e) {
      const sc = scene;
      const nm = (p) => (p === anchor && api.canAct(p) && looker() === p ? '나' : pname(p));
      switch (e.k) {
        case 'round': {
          setD(e.v);
          if (api.round) api.round(e.r + '라운드', '충전 ' + e.lv + ' · 물건 ' + e.per + '개씩');
          if (sc) sc.roundStart(T(700));
          syn('hum');
          await wait(900);
          break;
        }
        case 'load': {
          // 탄 보여 주기 → 섞어 넣기 → 물건 나눠 주기
          loadEl.textContent = '';
          const row = h('div', { class: 'rowsh' });
          for (let i = 0; i < e.L; i++) row.append(h('i', { class: 'bs-sh L' }));
          for (let i = 0; i < e.B; i++) row.append(h('i', { class: 'bs-sh B' }));
          const nn = h('div', { class: 'n' }); nn.innerHTML = '<span class="r">실탄 ' + e.L + '</span> · <span class="b">공포탄 ' + e.B + '</span>';
          loadEl.append(h('div', { class: 't', text: '장전 · 순서 비공개' }), row, nn);
          loadEl.style.top = Math.round(((topH() + (wrap.clientHeight - (bot.offsetHeight || 220))) / 2)) + 'px';
          loadEl.classList.add('on');
          if (sc) sc.showLoad(e.L, e.B, T(1500));
          sfx('shell', 0.5);
          await wait(1500);
          loadEl.classList.remove('on');
          if (sc) sc.loadIn(T(700));
          for (let i = 0; i < Math.min(4, e.L + e.B); i++) setTimeout(() => sfx('shell', 0.25, 1.3), T(i * 140));
          await wait(500);
          sfx('rack', 0.8);
          setD(e.v);
          const mine = e.g[anchor] || '';
          if (mine.length) {
            const inv = D.i[anchor] || '';
            const kids = tray.children, start = Math.max(0, inv.length - mine.length);
            for (let k = start; k < inv.length; k++) if (kids[k]) pulse(kids[k], 'new', 600);
            syn('beep', true);
          }
          if (sc) sc.dealItems(e.g, T(500));
          await wait(e.g.some((x) => x) ? 650 : 250);
          break;
        }
        case 'fire': {
          const self = e.by === e.to;
          const tgtTxt = self ? '자신' : nm(e.to);
          say(nm(e.by) + ' → ' + tgtTxt + (e.saw ? ' · 피해 2배' : ''));
          if (sc) sc.pickUp(e.by, e.to, T(520));
          await wait(560);
          sfx('heart', 0.55);
          await wait(self ? 750 : 520);
          if (e.sh === 'L') {
            sfx('fire', 1); api.buzz && api.buzz(e.to === anchor ? 60 : 25);
            flashFx('flash', e.saw ? 1.3 : 1);
            if (sc) sc.fire(true, e.saw, e.to, T(380));
            const pe = plateEl(e.to); if (pe) pulse(pe, 'hit', 450);
            if (e.to === anchor && looker() === anchor) flashFx('hurt');
            reveal('L', '실탄 · 충전 −' + e.dmg, 950);
          } else {
            sfx('click', 0.9);
            if (sc) sc.fire(false, e.saw, e.to, T(380));
            reveal('B', '공포탄' + (self ? ' · 차례 유지' : ''), 950);
          }
          setD(e.v);
          await wait(560);
          sfx('rack', 0.8);
          if (sc) sc.rack(e.sh, T(480));
          await wait(380);
          sfx('shell', 0.5);
          await wait(260);
          if (sc) sc.putDown(T(420));
          await wait(360);
          break;
        }
        case 'use': {
          const it = ITEMS[e.it];
          const who = nm(e.by);
          const meSee = e.by === looker();
          if (sc) sc.useItem(e.by, e.it, T(700), e.st ? -1 : 0);
          switch (e.it) {
            case 'l': sfx('ping', 0.5); say(who + ' — ' + it.n + (meSee ? '' : ' · 확인 내용 비공개')); if (meSee) { reveal(e.see, '지금 탄: ' + (e.see === 'L' ? '실탄' : '공포탄'), 1300); if (sc) sc.peek(e.see, T(1200)); } break;
            case 'c': sfx('chain', 0.8); say(who + ' — ' + nm(e.to) + '에게 족쇄'); break;
            case 's': sfx('saw', 0.7); say(who + ' — 총열 절단 · 다음 한 발 피해 2배'); if (sc) sc.saw(true, T(700)); break;
            case 'g': syn('lighter'); say(who + ' — ' + it.n + ' · 충전 +1'); break;
            case 'k': sfx('drink', 0.8); say(who + ' — ' + it.n + ' · 탄 배출'); await wait(450); sfx('rack', 0.7); if (sc) sc.eject(e.sh, T(600)); reveal(e.sh, '빠진 탄: ' + (e.sh === 'L' ? '실탄' : '공포탄'), 1100); await wait(300); sfx('shell', 0.5); break;
            case 'r': syn('radio'); say(who + ' — ' + it.n + (meSee ? '' : ' · 확인 내용 비공개')); if (meSee) reveal(e.pos ? e.see : 'N', e.pos ? e.pos + '번째 탄: ' + (e.see === 'L' ? '실탄' : '공포탄') : '남은 탄 없음 · 정보 없음', 1500); break;
            case 'f': syn('flip'); say(who + ' — ' + it.n + ' · 현재 탄 극성 반전'); if (meSee && S && S.kn[e.by] && S.ld === e.v.ld && S.kn[e.by][e.v.a] !== '?') reveal(S.kn[e.by][e.v.a], '반전 후: ' + (S.kn[e.by][e.v.a] === 'L' ? '실탄' : '공포탄'), 1100); break;
            case 'a': sfx('inject', 0.8); say(who + ' — ' + it.n + ' · ' + nm(e.to) + '의 ' + ITEMS[e.got].n + ' 탈취'); break;
            case 'p': sfx('pill', 0.8); say(who + ' — ' + it.n + (e.ok ? ' · 충전 +' + e.heal : ' · 충전 −1')); if (!e.ok) { const pe = plateEl(e.by); if (pe) pulse(pe, 'hit', 450); if (e.by === anchor && looker() === anchor) flashFx('hurt', 0.6); } break;
          }
          setD(e.v);
          if (e.it === 'g' || (e.it === 'p' && e.ok)) syn('beep', false);
          await wait(e.it === 'k' ? 700 : e.it === 'l' || e.it === 'r' ? 1100 : 850);
          break;
        }
        case 'skip': say(nm(e.p) + ' — 족쇄 · 차례 건너뜀'); sfx('chain', 0.6); setD(e.v); await wait(800); break;
        case 'out': {
          syn('flat'); setD(e.v);
          say(nm(e.p) + ' 탈락');
          if (sc) sc.down(e.p, T(900));
          if (e.p === anchor && looker() === anchor && fxAmt() > 0) { dark.style.transition = 'opacity ' + T(250) / 1000 + 's'; dark.style.opacity = '0.85'; setTimeout(() => { dark.style.transition = 'opacity ' + T(900) / 1000 + 's'; dark.style.opacity = '0'; }, T(700)); }
          await wait(900);
          break;
        }
        case 'rwin': {
          setD(e.v);
          sfx(e.p === looker() ? 'ping' : 'click', 0.6);
          if (api.banner) api.banner(pname(e.p) + ' — ' + e.r + '라운드 승리', { small: true, ms: Math.min(1600, T(1500)) });
          await wait(1300);
          break;
        }
        case 'over': setD(e.v); await wait(300); break;
        default: setD(e.v);
      }
    }

    async function run() {
      if (running) return;
      running = true; busy(true); redraw();
      try {
        while (queue.length && !dead) {
          const e = queue.shift();
          try { await playEv(e); } catch (err) { console.error(err); }
        }
      } finally {
        running = false;
        if (!dead) { if (S) D = snap(S); sent = 0; redraw(); busy(false); }
      }
    }

    function update(st, prev) {
      if (dead) return;
      const first = !S;
      S = st;
      if (st !== prev) sent = 0;
      anchor = pickAnchor();
      if (first || !D) {
        // 처음: 판이 막 시작했으면 라운드·장전 연출부터, 아니면 지금 상태 그대로
        const ev = st.ev || [];
        const ri = ev.map((e) => e.k).lastIndexOf('round');
        seen = st.eid;
        if (st.ph === 'play' && ri >= 0 && ri >= ev.length - 2) { D = ev[ri].v; queue.push(...ev.slice(ri)); run(); }
        else { D = snap(st); redraw(); }
        return;
      }
      const fresh = (st.ev || []).filter((e) => e.id > seen);
      if (fresh.length && fresh[0].id > seen + 1 && seen) { /* 놓친 이벤트가 있으면 지금 상태로 맞춤 */ D = snap(st); }
      seen = st.eid;
      if (fresh.length) { queue.push(...fresh); run(); }
      else if (!running) { D = snap(st); redraw(); }
    }

    // 처음 안내(내 첫 차례에 조작 한 번)
    return {
      update,
      destroy() {
        dead = true;
        for (const t of timers) clearTimeout(t);
        clearTimeout(capT);
        window.removeEventListener('lounge-cancel', onCancel);
        window.removeEventListener('keydown', onKey);
        window.removeEventListener('resize', onRs);
        try { if (scene) scene.destroy(); } catch (e) { /* 무시 */ }
        scene = null;
        api.setBusy(false);
        wrap.remove(); styleEl.remove();
      },
    };
  }

  /* ======================= 홈 미리보기 ======================= */
  function preview(cv) {
    const c = cv.getContext('2d'), W = cv.width, H = cv.height;
    const g = c.createRadialGradient(W / 2, H * 0.3, 10, W / 2, H * 0.5, W * 0.7);
    g.addColorStop(0, '#5a4630'); g.addColorStop(0.35, '#1f1810'); g.addColorStop(1, '#050405');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.fillStyle = '#1d2a1f'; c.beginPath(); c.ellipse(W / 2, H * 0.62, W * 0.42, H * 0.22, 0, 0, 7); c.fill();
    c.save(); c.translate(W * 0.5, H * 0.58); c.rotate(-0.12);
    c.fillStyle = '#4a2e1c'; c.beginPath(); c.moveTo(-210, -6); c.lineTo(-110, -14); c.lineTo(-100, 14); c.lineTo(-215, 26); c.closePath(); c.fill();
    c.fillStyle = '#222428'; c.fillRect(-110, -14, 70, 24); c.fillRect(-40, -12, 230, 9); c.fillRect(-40, 0, 200, 7);
    c.fillStyle = '#5b3a22'; c.fillRect(40, -3, 70, 14);
    c.restore();
    const sh = (x, y, col) => { c.fillStyle = col; c.fillRect(x, y, 16, 36); c.fillStyle = '#c9a24a'; c.fillRect(x - 1, y + 30, 18, 8); };
    ['#d23a2e', '#d23a2e', '#2f6fd6', '#d23a2e', '#2f6fd6'].forEach((col, i) => sh(W / 2 - 60 + i * 26, H * 0.18, col));
    c.fillStyle = 'rgba(255,220,150,.08)'; c.beginPath(); c.moveTo(W / 2 - 30, 0); c.lineTo(W / 2 + 30, 0); c.lineTo(W / 2 + 230, H); c.lineTo(W / 2 - 230, H); c.fill();
  }

  /* ======================= 등록 ======================= */
  const FIG = '<svg viewBox="0 0 340 92" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" font-size="12">' +
    [0, 1, 2, 3, 4].map((i) => '<g transform="translate(' + (14 + i * 22) + ' 14)"><rect width="14" height="34" rx="3" fill="' + (i < 3 ? '#d23a2e' : '#2f6fd6') + '"/><rect x="-1" y="28" width="16" height="8" rx="2" fill="#c9a24a"/></g>').join('') +
    '<text x="14" y="70" fill="#ff8a7a" font-weight="700">실탄 3</text><text x="64" y="70" fill="#8ab4ff" font-weight="700">공포탄 2</text>' +
    '<text x="140" y="26" fill="#efe6d6">처음 쏠 탄이 실탄일 확률</text><text x="140" y="48" fill="#ffcf6b" font-weight="700" font-size="16">3 ÷ 5 = 60%</text>' +
    '<text x="140" y="70" fill="#ab9fb8">→ 상대를 겨누는 편이 유리</text></svg>';
  const CREDIT = [
    '효과음: freesound.org(CC0) — 산탄총 발사 702672 areniporgen · 159710 AnthonyChan0, 펌프 449614 dasBUTCHER84 · 613801 Krovi, 탄피 773860 MrGungus · 620929 Metrolynn, 톱 118972 esperri, 마시기 320139 OwlStorm, 알약 315836 gneube, 주사 458423 Coniela, 심장 273150 michorvath.',
    'OpenGameArt 「Equipment Clicks II」 LFA(CC0, 빈 총 딸깍) · Kenney Impact Sounds·Interface Sounds(CC0, 쇠 소리·알림).',
    '3D: three.js(MIT). 물건 아이콘·총·탄·방은 직접 그림(코드). 라이터·무전기·심전도 소리는 게임 안에서 합성. 자세히: app/assets/buckshot/CREDITS.txt',
  ];
  const rows = CODES.map((c) => ({ icon: '<svg viewBox="0 0 24 24" width="26" height="26">' + IC[c] + '</svg>', name: ITEMS[c].n, tag: ITEMS[c].tg ? '사람 고름' : '바로 씀', desc: ITEMS[c].d + ' (나올 확률 약 ' + Math.round(ITEMS[c].w / CODES.reduce((a, k) => a + ITEMS[k].w, 0) * 100) + '%)' }));

  if (!L || !L.register) { if (typeof module !== 'undefined') module.exports = { init, actor, apply, ai, result, probLive, why, ITEMS }; return; }
  L.register({
    id: ID, name: '산탄 룰렛', tag: '심리전 · 운', cat: '파티', hidden: true, undo: false,
    icon: ICON, tint: '#4a1512', time: '10–20분', mood: 'tension', ambient: 'cave',
    blurb: '공개되는 것은 실탄과 공포탄의 개수뿐. 산탄총을 상대에게 겨눌지 자신에게 겨눌지 판단하고, 물건으로 흐름을 바꾸는 심리전.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, aiDelay: 1000,
    options: [
      { id: 'goal', label: '우승 조건', choices: [{ v: '1', label: '1라운드' }, { v: '2', label: '먼저 2승' }, { v: '3', label: '먼저 3승' }], def: '2', tip: '라운드를 이긴 횟수가 이만큼 되면 우승해요. 라운드가 오를수록 충전·물건이 늘어요.' },
      { id: 'pace', label: '연출 속도', choices: PACES.map((v) => ({ v: String(v), label: v + '배' })), def: '1', tip: '장전 · 발사 · 물건 연출과 AI가 생각하는 시간을 이 배로 빠르게 해요. 규칙은 같아요. 온라인에서는 방 설정을 모두 따라요.' },
    ],
    quick: [
      '장전 때 실탄(빨강)·공포탄(파랑)의 개수만 공개돼요. 순서는 아무도 몰라요.',
      '내 차례에는 물건을 쓰고 상대나 자신을 쏴요. 자신에게 쏜 탄이 공포탄이면 차례가 이어져요.',
      '실탄에 맞으면 충전 1을 잃어요. 끝까지 남으면 라운드 승리, 먼저 2승하면 우승이에요.',
    ],
    rules: [
      { h: '목표', p: ['충전(목숨)을 지키며 끝까지 살아남으면 그 라운드를 이겨요. 라운드를 먼저 2번(설정에서 1·2·3) 이기면 우승이에요.'] },
      { h: '장전', p: ['총에 탄 2~8발이 들어가요. 실탄(빨강)과 공포탄(파랑)이 몇 발인지는 모두에게 보여 주지만, 들어간 순서는 아무도 몰라요.',
        '탄을 다 쓰면 다시 장전하고, 그때마다 모두 물건을 받아요.'], fig: { svg: FIG, cap: '남은 탄 개수로 확률을 셈해요' } },
      { h: '차례에 할 일', p: ['① 물건을 원하는 만큼 써요(없어도 돼요).', '② 대상을 겨누고 「발사」. 상대든 자신이든 지금 탄 한 발이 나가요.',
        '자신에게 쏜 탄이 공포탄이면 차례가 이어져요. 그 밖에는 다음 사람 차례예요.'] },
      { h: '충전과 라운드', p: ['실탄에 맞으면 충전 1(총열 톱이면 2)을 잃고, 0이 되면 그 라운드 탈락이에요.',
        '라운드마다 충전과 물건이 늘어요: 1라운드 충전 2·물건 2개씩 → 2라운드 충전 4·물건 3개씩 → 3라운드부터 충전 5·물건 4개씩.',
        '물건은 한 사람 8개까지(넘친 건 버려요). 라운드가 바뀌면 물건은 사라져요.'] },
      { h: '물건 9가지', p: CODES.map((c) => ITEMS[c].n + ': ' + ITEMS[c].d) },
      { h: '예시', p: ['실탄 1 · 공포탄 2가 남았다면 지금 탄이 실탄일 확률은 1/3이에요. 자신을 겨누면 공포탄일 가능성이 높고, 공포탄이면 차례를 이어 갈 수 있어요.',
        '약실 렌즈로 확인한 탄이 실탄이라면, 총열 톱을 쓴 뒤 상대를 쏘아 충전 2를 줄일 수 있어요.'] },
      { h: '조작', p: ['아래 물건을 누르면 설명과 「쓰기」가 나와요. 족쇄·각성 주사는 쓴 뒤 위쪽 사람 판을 눌러 골라요.',
        '쏘기: 위쪽 사람 판이나 탁자 건너편 사람(또는 「상대 겨누기」·「자신 겨누기」)을 눌러 겨누면 총이 그쪽을 향해요. 「발사」로 쏴요.',
        '내가 아는 것: 아래 칸에 탄 순서(맨 앞 = 지금 탄)와 내가 렌즈·무전기로 알아낸 탄, 지금 탄이 실탄일 확률이 보여요.',
        'PC: 1~8 물건, E 상대 겨누기(여럿이면 바꾸기), Q 자신 겨누기, Space 발사, 오른쪽 클릭 취소.',
        '연출 속도: 설정 화면에서 1배 · 1.5배 · 2배 · 3배. 장전 · 발사 · 물건 연출과 AI 생각 시간이 함께 빨라져요(온라인은 방 설정).'] },
      { h: '한 폰으로 여럿이', p: ['렌즈·무전기로 확인한 탄은 그 사람만 봐야 하므로, 차례마다 가림막이 떠요. 폰을 넘겨 주세요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. AI는 남은 탄 개수와 자신이 확인한 탄만으로 확률을 계산해요(남의 비밀은 모름). 어려움은 여러 경우를 미리 따져 보고, 쉬움은 가끔 정보를 놓쳐요.'] },
      { h: '만든 사람', p: CREDIT },
    ],
    tutorial: [
      { text: '이번 장전에 들어간 탄 개수예요. 빨강은 실탄, 파랑은 공포탄. 순서는 공개되지 않아요.', sel: '.bs-shells' },
      { text: '충전 칸이 목숨이에요. 실탄에 맞으면 줄고, 0이 되면 이번 라운드에서 탈락해요.', sel: '.bs-me' },
      { text: '지금 탄이 실탄일 확률과, 내가 확인한 탄의 순서가 여기에 표시돼요.', sel: '.bs-know' },
      { text: '물건을 누르면 설명과 「쓰기」가 나와요. 차례마다 원하는 만큼 써요.', sel: '.bs-tray' },
      { text: '대상을 겨눈 뒤 「발사」. 자신에게 쏜 탄이 공포탄이면 차례가 이어져요.', sel: '.bs-act' },
    ],
    codex: [
      { h: '물건', p: ['장전할 때마다 받는 물건 9가지. 한 사람 8개까지 들 수 있어요.'], rows },
      { h: '라운드', p: ['라운드가 오를수록 판이 커져요.'], rows: [1, 2, 3].map((r) => ({ icon: '<svg viewBox="0 0 24 24" width="26" height="26"><text x="12" y="17" text-anchor="middle" font-size="14" font-weight="700" fill="currentColor">' + r + '</text></svg>', name: r + (r === 3 ? '라운드부터' : '라운드'), tag: '충전 ' + LIVES[r - 1], desc: '장전마다 물건 ' + PER[r - 1] + '개씩 · 탄 2~8발' })) },
    ],
    init, actor, apply, ai, aiDelayFor, result, hint, mount, preview,
    _t: { probLive, why, ITEMS, remCounts },
  });
})();
