/* 하이퍼 레이스 — 실시간 3D 자동차 경주(1~8대). 실제 3D 차 모델(하이퍼카 · GT 두 클래스가 한 트랙을 함께 달리는 다클래스 경주),
   판마다 새로 만드는 서킷(인원이 많을수록 길고 넓게), 시간대(낮·노을·밤) · 날씨(맑음·비), 주행 보조, 슬립스트림, AI(자리마다 쉬움·보통·어려움).

   파일 구성 (docs/HYPERRACE.md)
   - 이 파일: 차 자료 · 서킷 생성 · 물리 · AI · 경주 진행 · 규칙 · 도감 · L.register — 순수 로직(노드 시험 가능)과 가벼운 입구 화면만.
   - assets/hyperrace/lib/three.min.js (three.js r170 + GLTFLoader + meshopt 디코더, MIT) · assets/hyperrace/view.js (3D 화면 · 조작 · 소리)
     · assets/hyperrace/pk_*.js (차 모델 · 하늘 · 결 · 소품 · 소리를 base64로 담은 묶음) — 게임을 켤 때만 불러와요(홈 화면을 느리게 하지 않게).
   온라인: 각 기기가 자기 차(호스트는 AI 차도)를 직접 시뮬레이션하고 15Hz로 알려요(racing.js와 같은 방식). 경주 단계·결과는 호스트가 api.setState. */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const L = G.Lounge, U = L && L.util;

  /* ======================= 차 자료 (차를 더할 때: 여기 한 줄 + assets/hyperrace/pk_car_<id>_<tier>.js) ======================= */
  const CLS = {   // rk = 출발 순서(빠른 클래스 앞) · 클래스 섞기 경주에서도 클래스별 순위
    F1: { nm: '포뮬러', short: 'F1', rk: 0, col: '#e8505b', desc: '바퀴가 드러난 1인승 경주차. 다운포스가 엄청나 고속 코너도 거의 그대로 돌아요. 가볍고 제동이 가장 세요.' },
    HY: { nm: '하이퍼카', short: 'HY', rk: 1, col: '#ff8a3d', desc: '르망형 프로토타입 · 하이퍼카 콘셉트. 출력과 다운포스를 둘 다 가졌어요.' },
    SC: { nm: '슈퍼카', short: 'SC', rk: 4, col: '#f2c230', desc: '도로용 슈퍼카. 최고 속도는 높지만 다운포스가 작아 코너에선 조심스럽게.' },
    GT: { nm: 'GT', short: 'GT', rk: 2, col: '#5bb3e6', desc: '경주용 GT. 큰 날개 덕에 코너에서 끈질겨요.' },
    FU: { nm: '미래차', short: 'FU', rk: 3, col: '#b57bff', desc: '먼 미래 · 영화 속 차. 드리프트 부스트가 가장 세요(호버카는 바닥에서 떠서 달려요).' },
    ST: { nm: '스트리트', short: 'ST', rk: 5, col: '#6fcf86', desc: '무거운 머슬카 · 고성능 세단. 힘은 넘치고 접지는 모자라 꼬리를 잘 흘려요.' },
    CL: { nm: '클래식', short: 'CL', rk: 6, col: '#d9b48a', desc: '1930~70년대 명차. 느리지만 가늘고 딱딱한 타이어로 미끄러지며 달리는 맛.' },
    OF: { nm: '오프로드', short: 'OF', rk: 7, col: '#a4ad6b', desc: 'SUV · 군용 트럭. 느리고 크게 기울지만 잔디 · 자갈에서도 거의 안 느려져요(지름길 각).' },
  };
  /* ph: m 무게(kg) · P 출력(W, 게임용) · vtop 최고 속도(m/s, 공기 저항을 여기서 정함) · cl 다운포스(N/(m/s)²) · mu 타이어 마찰 ·
         brake 제동(g) · awd 네 바퀴 굴림 · L 축거(m) · steer 최대 조향(rad) · wr 바퀴 반지름
         over 핸들 끝까지 = 접지 한계 × over · rear 뒤 접지 여유(작을수록 꼬리가 잘 나감) · nose 코너에서 코가 안쪽을 보는 각 ·
         kS 진행 방향이 차체를 따라가는 빠르기 · yawR 차체 회전 반응(무게감) · kD 드리프트 각 잡는 빠르기 · dA 드리프트 기본 각(rad) ·
         dG 드리프트 중 옆 접지 · dS 드리프트 속도 깎임 · hbK 드리프트 단추로 꼬리 돌리는 힘 · bstA 드리프트 부스트 가속(m/s²) ·
         off 잔디 · 자갈 접지(오프로드, 기본 0) · roll 차체 기울기 배율(그림) · hover 바퀴 대신 떠서 달림(그림)
     snd: 엔진 소리 — ['ice', 음높이, 기어 수] 녹음 엔진 · ['ev', 음높이] 전기 윙
     lv: 'hue' = 원본 도색(결)을 색상 회전 · 'solid' = 단색(원본 색은 모델 그대로) — 꾸미기(cust)는 docs/HYPERRACE.md 「꾸미기」 */
  const RWD = { awd: 0, over: 1.05, rear: 1.1, nose: 0.06, kS: 9, kD: 4.8, yawR: 12, dA: 0.46, dG: 0.92, dS: 0.36, hbK: 0.8, bstA: 4.5, steer: 0.55, wr: 0.34 };
  const AWD = { awd: 1, over: 1.04, rear: 1.2, nose: 0.045, kS: 10, kD: 5.2, yawR: 11, dA: 0.36, dG: 0.9, dS: 0.52, hbK: 0.58, bstA: 4.3, steer: 0.52, wr: 0.36 };
  const PH = (base, o) => Object.assign({}, base, o);
  const SK = (who, url) => ({ by: who, src: url });
  const CARS = [
    // ---------- 포뮬러 ----------
    { id: 'w17', nm: '은화살 W17', cls: 'F1', real: '2026년형 독일 팀 F1 경주차', blurb: '긴 직선에서 가장 빠른 은빛 F1. 하이브리드 출력이 커요.',
      spec: { hp: '1,000마력급(하이브리드)', kg: '약 770kg', top: '340km/h', zero: '2.5초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 800, P: 790000, vtop: 96, cl: 3.4, mu: 1.75, brake: 2.15, L: 3.55, steer: 0.42, wr: 0.36, rear: 1.22, yawR: 14, kS: 11, nose: 0.04, dA: 0.32, dS: 0.5, hbK: 0.55, bstA: 4.6 }),
      snd: ['ice', 1.55, 8], lv: 'hue', liv: [['팀 은빛', '#9aa3ab', 0, 1], ['청록', '#1fa39a', 150, 1.2], ['진홍', '#b3121d', -160, 1.3], ['금빛', '#c9a23a', 40, 1.2], ['보라', '#7b4fd0', -80, 1.2], ['흑', '#222', 0, 0.1]],
      model: '2026 Mercedes W17', ...SK('Dave Love', 'https://sketchfab.com/3d-models/2026-mercedes-w17-b806f1e70aa343219e7158169549b97b'), lic: 'CC BY 4.0' },
    { id: 'rb22', nm: '황소 22', cls: 'F1', real: '2026년형 오스트리아 팀 F1 경주차', blurb: '다운포스가 가장 큰 남색 F1. 코너 탈출이 날카로워요.',
      spec: { hp: '1,000마력급(하이브리드)', kg: '약 770kg', top: '335km/h', zero: '2.5초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 800, P: 770000, vtop: 94.5, cl: 3.55, mu: 1.76, brake: 2.15, L: 3.55, steer: 0.42, wr: 0.36, rear: 1.2, yawR: 14.5, kS: 11, nose: 0.045, dA: 0.33, dS: 0.5, hbK: 0.55, bstA: 4.6 }),
      snd: ['ice', 1.6, 8], lv: 'hue', liv: [['팀 남색', '#1d2a4d', 0, 1], ['하늘', '#3c8fd6', -20, 1.4], ['보라', '#5a2a8a', 40, 1.2], ['진녹', '#1f5a3a', -100, 1.2], ['주황', '#d8641c', 170, 1.3], ['흑', '#222', 0, 0.1]],
      model: '2026 Redbull RB22', ...SK('Dave Love', 'https://sketchfab.com/3d-models/2026-redbull-rb22-0a3d24a58e0549d591a5a48c22eec383'), lic: 'CC BY 4.0' },
    // ---------- 하이퍼카 · 프로토타입 ----------
    { id: 'mx', nm: '미스틱 X', cls: 'HY', real: '2023년형 독일 전기 하이퍼카 콘셉트', blurb: '네 바퀴를 모두 굴리는 전기 하이퍼카 콘셉트. 순간 가속이 압도적이에요.',
      spec: { hp: '1,500마력급(전기)', kg: '약 1,500kg', top: '330km/h', zero: '2.0초대', drive: '네 바퀴 굴림(AWD)' },
      ph: PH(AWD, { m: 1500, P: 900000, vtop: 92, cl: 2.0, mu: 1.5, brake: 1.45, L: 2.66, steer: 0.52, wr: 0.37, over: 1.04, rear: 1.2, nose: 0.045, kS: 10, kD: 5.2, yawR: 11, dA: 0.36, dG: 0.9, dS: 0.55, hbK: 0.55, bstA: 4.2 }),
      snd: ['ev', 1], lv: 'solid', liv: [['샴페인 골드', '#9c8456'], ['은빛', '#b9bec6'], ['흑요석', '#16171b'], ['레이싱 블루', '#1f4fb8'], ['선홍', '#b3121d'], ['진주 흰색', '#e9e6df']],
      model: '2023 Porsche Mission X Concept', ...SK('Ddiaz Design', 'https://sketchfab.com/ddiaz-design'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'lmv', nm: '비전 LM', cls: 'HY', real: '2019년형 일본 르망 프로토타입 콘셉트', blurb: '로터리 엔진 소리가 높게 우는 프로토타입. 다운포스가 커서 고속 코너의 왕.',
      spec: { hp: '700마력급(로터리 하이브리드)', kg: '약 1,000kg', top: '340km/h', zero: '2.6초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1000, P: 560000, vtop: 92, cl: 2.1, mu: 1.5, brake: 1.8, L: 2.75, wr: 0.36, rear: 1.16, yawR: 13, dA: 0.4, bstA: 4.4 }),
      snd: ['ice', 1.45, 7], lv: 'hue', liv: [['원본 흰 은빛', '#e8e8ea', 0, 1], ['적동', '#9a3324', 0, 1, '#9a3324'], ['청', '#1f4fb8', 0, 1, '#1f4fb8'], ['흑', '#1b1b1f', 0, 1, '#1b1b1f'], ['황', '#e3b52b', 0, 1, '#e3b52b'], ['녹', '#2e7d4f', 0, 1, '#2e7d4f']],
      model: 'Mazda LM Vision', ...SK('vecarz', 'https://sketchfab.com/3d-models/mazda-lm-vision-wwwvecarzcom-f5af3811d7e64eb0b897ec6d4dad984f'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'cslh', nm: '오마주 R', cls: 'HY', real: '2015년형 독일 르망풍 콘셉트 레이서', blurb: '옛 경량 쿠페를 기리는 콘셉트 경주차. 균형이 좋아 다루기 쉬워요.',
      spec: { hp: '650마력급(하이브리드)', kg: '약 1,100kg', top: '320km/h', zero: '2.8초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1100, P: 600000, vtop: 90, cl: 2.15, mu: 1.5, brake: 1.75, L: 2.74, wr: 0.36, rear: 1.2, yawR: 12.5, dA: 0.42, bstA: 4.4 }),
      snd: ['ice', 1.15, 7], lv: 'hue', liv: [['원본 흰 줄무늬', '#eeeeee', 0, 1], ['남색', '#1d2f6b', 0, 1, '#1d2f6b'], ['적', '#b3121d', 0, 1, '#b3121d'], ['흑', '#18181c', 0, 1, '#18181c'], ['은', '#a8adb5', 0, 1, '#a8adb5'], ['주황', '#e0661e', 0, 1, '#e0661e']],
      model: '2015 BMW 3.0 CSL Hommage R Concept', ...SK('Ddiaz Design', 'https://sketchfab.com/3d-models/2015-bmw-30-csl-hommage-r-concept-e1953ee84c754f389dc05694a4aa355d'), lic: 'CC BY-NC-SA 4.0' },
    // ---------- 슈퍼카 ----------
    { id: 'countach', nm: '쿤타 800', cls: 'SC', real: '2021년형 이탈리아 V12 하이브리드 슈퍼카', blurb: 'V12에 네 바퀴 굴림. 무겁지만 직선이 가장 빠른 슈퍼카.',
      spec: { hp: '814마력(V12 하이브리드)', kg: '약 1,600kg', top: '355km/h', zero: '2.8초', drive: '네 바퀴 굴림(AWD)' },
      ph: PH(AWD, { m: 1600, P: 610000, vtop: 97, cl: 0.65, mu: 1.36, brake: 1.5, L: 2.7, steer: 0.52, wr: 0.36, yawR: 10 }),
      snd: ['ice', 1.2, 7], lv: 'solid', liv: [['원본 흰색', '#e9e9e9'], ['노랑', '#e8c21c'], ['녹', '#5fae3a'], ['적', '#b3121d'], ['청', '#2a5bd7'], ['흑', '#18181c']],
      model: '2021 Lamborghini Countach LPI 800-4', ...SK('Lexyc16', 'https://sketchfab.com/3d-models/2021-lamborghini-countach-lpi-800-4-d76b94884432422b966d1a7f8815afb5'), lic: 'CC BY-NC 4.0' },
    { id: 'f40lb', nm: 'F포티 LB', cls: 'SC', real: '1987년형 이탈리아 터보 슈퍼카 + 와이드바디', blurb: '가볍고 거친 트윈터보 슈퍼카. 뒤가 예민해서 잘 다루면 가장 신나요.',
      spec: { hp: '480마력(V8 트윈터보)', kg: '약 1,150kg', top: '324km/h', zero: '3.8초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1150, P: 460000, vtop: 90, cl: 0.85, mu: 1.4, brake: 1.4, L: 2.45, wr: 0.34, rear: 1.03, yawR: 13, dA: 0.5, bstA: 4.8 }),
      snd: ['ice', 1.05, 5], lv: 'hue', liv: [['원본 흰 도색', '#f0f0f0', 0, 1], ['적', '#c41e1e', 0, 1, '#c41e1e'], ['흑', '#151518', 0, 1, '#151518'], ['노랑', '#e8c21c', 0, 1, '#e8c21c'], ['청', '#1f4fb8', 0, 1, '#1f4fb8'], ['은', '#a8adb5', 0, 1, '#a8adb5']],
      model: 'LB-Works Ferrari F40', ...SK('vecarz', 'https://sketchfab.com/3d-models/lb-works-ferrari-f40-wwwvecarzcom-011cad3526e945799d6e98dde6390182'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'mf1', nm: '맥라 원', cls: 'SC', real: '1993년형 영국 3인승 슈퍼카', blurb: '가운데 운전석의 전설. 최고 속도는 가장 높지만 다운포스가 거의 없어요.',
      spec: { hp: '627마력(V12)', kg: '약 1,140kg', top: '386km/h', zero: '3.2초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1140, P: 470000, vtop: 99, cl: 0.5, mu: 1.37, brake: 1.4, L: 2.72, wr: 0.34, rear: 1.08, yawR: 12, dA: 0.47 }),
      snd: ['ice', 1.25, 6], lv: 'solid', liv: [['원본 흰색', '#eeeeee'], ['짙은 녹', '#1f4a36'], ['은', '#b3b8bf'], ['주황', '#e66b1f'], ['남', '#1b2c5c'], ['흑', '#151518']],
      model: 'McLaren F1 1993', ...SK('Alex.Ka.', 'https://sketchfab.com/3d-models/mclaren-f1-1993-by-alexka-294df724d96241cdbe0e0f3c91ad7fce'), lic: 'CC BY-NC 4.0' },
    { id: 'slc', nm: '은빛 번개', cls: 'SC', real: '2011년형 독일 콘셉트 로드스터', blurb: '바퀴가 차체 밖으로 나온 콘셉트 스피드스터. 긴 코와 짧은 꼬리.',
      spec: { hp: '600마력급(콘셉트)', kg: '약 1,500kg', top: '330km/h급', zero: '3초대', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1450, P: 520000, vtop: 94, cl: 0.75, mu: 1.39, brake: 1.45, L: 2.82, wr: 0.36, rear: 1.12, yawR: 11 }),
      snd: ['ice', 0.95, 7], lv: 'solid', liv: [['원본 은청', '#7b9eb0'], ['은', '#c0c5cc'], ['흑', '#151518'], ['적', '#b3121d'], ['흰', '#ececec'], ['금', '#b8954a']],
      model: '2011 Mercedes-Benz Silver Lightning Concept', ...SK('Ddiaz Design', 'https://sketchfab.com/3d-models/2011-mercedes-benz-silver-lightning-concept-ce756f30cc4541f28f641f6d34bdb2d7'), lic: 'CC BY-NC-SA 4.0' },
    // ---------- GT ----------
    { id: 'gt3r', nm: '구구이 R', cls: 'GT', real: '2024년형 독일 GT3 경주차', blurb: '뒷바퀴 굴림 GT3 경주차. 큰 날개 덕에 고속 코너가 단단해요.',
      spec: { hp: '565마력급', kg: '약 1,260kg', top: '290km/h', zero: '3.0초대', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1260, P: 450000, vtop: 81, cl: 1.75, mu: 1.5, brake: 1.6, L: 2.46, steer: 0.55, wr: 0.34, over: 1.05, rear: 1.1, nose: 0.06, kS: 9, kD: 4.8, yawR: 12, dA: 0.48, dG: 0.93, dS: 0.34, hbK: 0.8, bstA: 4.6 }),
      snd: ['ice', 1, 6], lv: 'hue', clean: 1, liv: [['금빛 원본', '#c9a23a', 0, 1], ['청록', '#2aa198', 160, 1], ['진홍', '#c0392b', -40, 1.1], ['보라', '#8e44ad', -110, 1], ['라임', '#8bc34a', 50, 1], ['은빛', '#aab1b8', 0, 0.08]],
      model: '2024 Porsche 992 GT3 R', ...SK('Dave Love', 'https://sketchfab.com/Tyler_Dave'), lic: 'CC BY 4.0' },
    { id: 'm4gt3', nm: '엠포 GT', cls: 'GT', real: '2025년형 독일 GT3 경주차', blurb: '축거가 긴 GT3. 고속에서 아주 안정적이고 브레이크가 강해요.',
      spec: { hp: '590마력급(직6 트윈터보)', kg: '약 1,300kg', top: '290km/h', zero: '3.2초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1300, P: 455000, vtop: 81, cl: 1.85, mu: 1.5, brake: 1.65, L: 2.9, wr: 0.35, rear: 1.15, yawR: 11, dA: 0.44 }),
      snd: ['ice', 0.95, 6], lv: 'solid', liv: [['원본 흑', '#141416'], ['흰', '#ececec'], ['M 청', '#1c69d4'], ['적', '#b3121d'], ['청록', '#1fa39a'], ['주황', '#e0661e']],
      model: '2025 BMW M4 GT3 EVO G82', ...SK('Ddiaz Design', 'https://sketchfab.com/3d-models/2025-bmw-m4-gt3-evo-g82-113f83dd87064697a5ec2511d280b9d5'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'bgt3', nm: '콘티 PP', cls: 'GT', real: '2021년형 영국 GT3 (산악 경주 사양)', blurb: '산을 오르려고 날개를 키운 GT3. 다운포스는 가장 크고 몸은 무거워요.',
      spec: { hp: '750마력(산악 사양)', kg: '약 1,350kg', top: '280km/h', zero: '3.0초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1360, P: 480000, vtop: 79, cl: 2.05, mu: 1.5, brake: 1.6, L: 2.85, wr: 0.36, rear: 1.14, yawR: 10.5, dA: 0.44 }),
      snd: ['ice', 0.85, 6], lv: 'hue', liv: [['원본 흑 · 황 위장', '#1b1b1b', 0, 1], ['청 위장', '#2a7bd7', 160, 1.1], ['적 위장', '#c0392b', -60, 1.2], ['녹 위장', '#4caf50', 70, 1.1], ['보라 위장', '#8e44ad', -130, 1.1], ['흑백', '#888', 0, 0.05]],
      model: 'Bentley Continental GT3 Pikes Peak', ...SK('vecarz', 'https://sketchfab.com/3d-models/bentley-continental-gt3-pikes-peak-vecarzcom-46aa342094f1492dae0d695db220697f'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'bb512', nm: '비비 512', cls: 'GT', real: '1979년형 이탈리아 르망 GT 경주차', blurb: '40여 년 전 르망을 달린 수평대향 12기통 GT. 날개는 작고 가속이 강해요.',
      spec: { hp: '480마력(F12)', kg: '약 1,100kg', top: '300km/h', zero: '4초대', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1100, P: 450000, vtop: 84, cl: 1.15, mu: 1.45, brake: 1.5, L: 2.5, wr: 0.34, rear: 1.06, yawR: 12.5, dA: 0.5, bstA: 4.7 }),
      snd: ['ice', 1.15, 5], lv: 'hue', liv: [['원본 적백', '#a3201c', 0, 1], ['청백', '#1f4fb8', -140, 1.1], ['녹백', '#2e7d4f', 120, 1], ['금백', '#c9a23a', 40, 1.2], ['흑백', '#333', 0, 0.06], ['보라백', '#7b4fd0', -100, 1]],
      model: '1979 Ferrari 512 BB LM', ...SK('vecarz', 'https://sketchfab.com/3d-models/1979-ferrari-512-bb-lm-wwwvecarzcom-cda0bcafdb714d6db720182aba6a15f3'), lic: 'CC BY-NC 4.0' },
    // ---------- 미래차 ----------
    { id: 'dmc', nm: '88마일', cls: 'FU', real: '1985년형 스테인리스 쿠페 (영화 속 시간 여행차)', blurb: '시간 여행 장치를 단 스테인리스 쿠페. 부스트가 가장 세고 길어요.',
      spec: { hp: '?? (1.21기가와트)', kg: '약 1,250kg', top: '88마일+', zero: '-', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1250, P: 560000, vtop: 89, cl: 1.5, mu: 1.48, brake: 1.5, L: 2.41, wr: 0.33, rear: 1.12, yawR: 12, dA: 0.5, bstA: 6.2 }),
      snd: ['ice', 0.8, 5], lv: 'solid', liv: [['원본 스테인리스', '#b5b5b5'], ['금', '#c9a23a'], ['흑', '#1a1a1d'], ['적', '#a3201c'], ['청', '#2a5bd7'], ['흰', '#ececec']],
      model: '1985 DeLorean DMC-12 Time Machine (BTTF)', ...SK('VTX', 'https://sketchfab.com/3d-models/1985-delorean-dmc-12-time-machine-bttf-6fdfe2e2adba4886b48cc523871e88be'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'excal', nm: '엑스칼리', cls: 'FU', real: '2077년 가상의 하늘 리무진(호버카)', blurb: '바퀴 대신 추진기로 바닥 위를 떠서 달려요. 미끄러지듯 도는 대신 부스트가 길어요.',
      spec: { hp: '추진기 4개(가상)', kg: '약 1,600kg', top: '340km/h(가상)', zero: '-', drive: '추진기(네 바퀴 굴림처럼)' },
      ph: PH(AWD, { m: 1550, P: 650000, vtop: 94, cl: 1.5, mu: 1.39, brake: 1.6, L: 3.8, steer: 0.48, wr: 0.3, rear: 1.15, yawR: 9, kS: 8, dA: 0.42, dG: 0.95, dS: 0.4, bstA: 6, hover: 1 }),
      snd: ['ev', 0.7], lv: 'solid', pm: 1, liv: [['원본 흑', '#16161a'], ['흰', '#e9e9ec'], ['적', '#9d1a1a'], ['청', '#1f3f8f'], ['금', '#b8954a'], ['청록', '#1b8a85']],
      model: 'Rayfield Excalibur (2077) [Arasaka]', ...SK('geyges', 'https://sketchfab.com/3d-models/rayfield-excalibur-2077-arasaka-4fa3d45e5c8a4b8d97a0f7e8c317570a'), lic: 'Sketchfab Standard' },
    { id: 'semi', nm: '칼날 Q340', cls: 'FU', real: '2077년 가상의 하이퍼카', blurb: '날렵한 미래 하이퍼카. 네 바퀴 굴림 전기차라 탈출 가속이 빨라요.',
      spec: { hp: '1,200마력급(가상)', kg: '약 1,500kg', top: '350km/h(가상)', zero: '2초대', drive: '네 바퀴 굴림(AWD)' },
      ph: PH(AWD, { m: 1500, P: 660000, vtop: 92, cl: 1.4, mu: 1.42, brake: 1.6, L: 2.8, wr: 0.38, yawR: 11, bstA: 5.6 }),
      snd: ['ev', 1.2], lv: 'solid', pm: 1, liv: [['원본 흑 · 주황', '#26262a'], ['흰', '#ececec'], ['주황', '#e0661e'], ['청', '#1f4fb8'], ['적', '#b3121d'], ['라임', '#9bd02a']],
      model: 'Yaiba ARV-Q340 Semimaru (2077)', ...SK('geyges', 'https://sketchfab.com/3d-models/yaiba-arv-q340-semimaru-2077-5ccf8429a0064972bfac79e8ce30a809'), lic: 'Sketchfab Standard' },
    { id: 'maimai', nm: '달팽이 MM', cls: 'FU', real: '2077년 가상의 도시형 경차', blurb: '작고 가벼운 도시 경차. 최고 속도는 낮지만 코너에서 쏙쏙 빠지고 부스트가 세요.',
      spec: { hp: '???(가상 전기)', kg: '약 800kg', top: '250km/h(게임)', zero: '-', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 820, P: 330000, vtop: 76, cl: 1.0, mu: 1.5, brake: 1.6, L: 1.95, steer: 0.62, wr: 0.24, rear: 1.15, yawR: 15, kS: 10, dA: 0.5, bstA: 6.4 }),
      snd: ['ev', 1.5], lv: 'solid', pm: 1, liv: [['원본 적갈', '#6b1f24'], ['민트', '#7fd1b9'], ['노랑', '#f0c419'], ['분홍', '#e889b5'], ['하늘', '#6fb7e8'], ['흰', '#ececec']],
      model: 'Makigai Maimai', ...SK('geyges', 'https://sketchfab.com/3d-models/makigai-maimai-0fa7d5dbcfb74c439bf67d6f73f61f6f'), lic: 'Sketchfab Standard' },
    { id: 'cyber', nm: '네온 크루저', cls: 'FU', real: '가상의 미래 쿠페', blurb: '네온 불빛이 빛나는 각진 미래 쿠페. 색을 바꾸면 네온 빛도 함께 바뀌어요.',
      spec: { hp: '???(가상 전기)', kg: '약 1,300kg', top: '320km/h(가상)', zero: '-', drive: '네 바퀴 굴림(AWD)' },
      ph: PH(AWD, { m: 1300, P: 580000, vtop: 90, cl: 1.3, mu: 1.43, brake: 1.6, L: 2.45, wr: 0.35, yawR: 12, bstA: 5.8 }),
      snd: ['ev', 0.9], lv: 'hue', liv: [['원본 청록 · 주황', '#20c5d0', 0, 1], ['분홍 네온', '#ff4fd0', 120, 1.3], ['녹 네온', '#3cff6a', -70, 1.2], ['금 네온', '#ffc23a', 170, 1.2], ['보라 네온', '#9a5cff', 80, 1.3], ['흰 네온', '#e0e0e0', 0, 0.1]],
      model: 'Cyberpunk car', ...SK('4d_Bob', 'https://sketchfab.com/3d-models/cyberpunk-car-b4301ff99d214d16a7a43708a5866bf0'), lic: 'CC BY 4.0' },
    // ---------- 스트리트 ----------
    { id: 'chall', nm: '도전자 LB', cls: 'ST', real: '2015년형 미국 머슬카 + 와이드바디', blurb: '무겁고 힘센 V8 머슬카. 가속 페달만으로 꼬리가 나가는 드리프트 장인.',
      spec: { hp: '707마력(V8 슈퍼차저)', kg: '약 2,000kg', top: '320km/h', zero: '3.6초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1950, P: 450000, vtop: 82, cl: 0.4, mu: 1.28, brake: 1.3, L: 2.95, wr: 0.36, rear: 1.0, yawR: 10, kS: 8, dA: 0.56, dG: 0.94, dS: 0.28, hbK: 0.9, bstA: 5 }),
      snd: ['ice', 0.72, 6], lv: 'solid', pm: 1, liv: [['원본 흑', '#141416'], ['주황', '#e0661e'], ['보라', '#5a2a8a'], ['라임', '#8bc34a'], ['적', '#b3121d'], ['흰', '#ececec']],
      model: '2015 Dodge Challenger LB★PERFORMANCE', ...SK('Ddiaz Design', 'https://sketchfab.com/3d-models/2015-dodge-challenger-lbperformance-db846e9b985e4ae4934a5d9b6d1683f2'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'e55', nm: '이오오 E', cls: 'ST', real: '2003년형 독일 고성능 세단 (튜닝)', blurb: '큰 날개를 단 고성능 세단. 무겁지만 안정적이고 직선에서 꾸준히 밀어요.',
      spec: { hp: '476마력(V8 슈퍼차저)', kg: '약 1,800kg', top: '300km/h(제한 해제)', zero: '4.7초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1800, P: 420000, vtop: 83, cl: 0.55, mu: 1.3, brake: 1.35, L: 2.85, wr: 0.35, rear: 1.1, yawR: 10, kS: 8.5, dA: 0.5, dS: 0.3, bstA: 4.8 }),
      snd: ['ice', 0.82, 5], lv: 'solid', pm: 0, liv: [['원본 흑', '#141416'], ['은', '#b3b8bf'], ['흰', '#ececec'], ['남', '#1b2c5c'], ['적', '#8a1a1a'], ['녹회', '#4f5b55']],
      model: 'Mercedes-Benz W211 E55', ...SK('vecarz', 'https://sketchfab.com/3d-models/mercedes-benz-w211-e55-wwwvecarzcom-f18053ad7b8347008917423c26391907'), lic: 'CC BY-NC 4.0' },
    // ---------- 클래식 ----------
    { id: 'strad', nm: '스트라다 33', cls: 'CL', real: '1967년형 이탈리아 미드십 스포츠카', blurb: '아주 가볍고 낮은 60년대 스포츠카. 클래식 중 코너가 가장 빨라요.',
      spec: { hp: '230마력(V8)', kg: '약 700kg', top: '260km/h', zero: '5.5초', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 700, P: 125000, vtop: 61, cl: 0.12, mu: 1.18, brake: 1.1, L: 2.35, wr: 0.31, rear: 1.04, yawR: 13, kS: 8, dA: 0.55, dS: 0.28, bstA: 4 }),
      snd: ['ice', 1.1, 5], lv: 'solid', liv: [['원본 적', '#d61a1a'], ['은', '#c0c5cc'], ['흰', '#ececec'], ['노랑', '#e8c21c'], ['짙은 녹', '#1f4a36'], ['하늘', '#7fb3d9']],
      model: 'Alfa Romeo Stradale 1967', ...SK('Ipatov Kirill', 'https://sketchfab.com/3d-models/alfa-romeo-stradale-1967-fbb6adc7a6e84c3db6969e1debcd364b'), lic: 'CC BY-NC 4.0' },
    { id: 'csl71', nm: '경량 71', cls: 'CL', real: '1971년형 독일 경량 쿠페', blurb: '가볍게 깎아 낸 70년대 쿠페. 반응이 솔직해 미끄러지며 돌기 좋아요.',
      spec: { hp: '200마력(직6)', kg: '약 1,165kg', top: '220km/h', zero: '7초대', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1165, P: 190000, vtop: 62, cl: 0.15, mu: 1.15, brake: 1.05, L: 2.62, wr: 0.31, rear: 1.02, yawR: 12, kS: 8, dA: 0.58, dS: 0.26, bstA: 4.2 }),
      snd: ['ice', 0.95, 4], lv: 'solid', liv: [['원본 적갈', '#6b1700'], ['흰', '#ececec'], ['은', '#b3b8bf'], ['하늘', '#7fb3d9'], ['노랑', '#e8c21c'], ['흑', '#18181c']],
      model: '1971 BMW 3.0 CSL', ...SK('OUTPISTON', 'https://sketchfab.com/3d-models/1971-bmw-30-csl-dc6cec25ed3249dbac5ba49121963dec'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'bent8', nm: '팔 리터', cls: 'CL', real: '1931년형 영국 대형 그랜드 투어러', blurb: '8리터 엔진의 거대한 30년대 고급차. 힘은 가장 세지만 무겁고 커서 미리 줄여야 해요.',
      spec: { hp: '220마력(직6 8리터)', kg: '약 1,800kg', top: '165km/h', zero: '-', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1700, P: 270000, vtop: 60, cl: 0, mu: 1.19, brake: 1.0, L: 3.97, steer: 0.5, wr: 0.42, rear: 1.04, yawR: 8, kS: 7, dA: 0.5, dG: 0.94, dS: 0.25, hbK: 0.7, bstA: 4.2, roll: 1.5 }),
      snd: ['ice', 0.6, 4], lv: 'solid', liv: [['원본 흑', '#0d0d0f'], ['영국 녹', '#1f4a36'], ['적갈', '#5a1a14'], ['남', '#1b2550'], ['크림', '#e8dfc8'], ['은', '#a8adb5']],
      model: '1931 Bentley 8-Litre', ...SK('OUTPISTON', 'https://sketchfab.com/3d-models/1931-bentley-8-litre-423d83f6b80648d19b193a8ba4927b1f'), lic: 'CC BY-NC-SA 4.0' },
    { id: 'ssk', nm: '콤프레서 SS', cls: 'CL', real: '1928년형 독일 슈퍼차저 로드스터', blurb: '슈퍼차저를 단 20년대 로드스터. 긴 코에 큰 바퀴, 가속이 의외로 세요.',
      spec: { hp: '225마력(직6 슈퍼차저)', kg: '약 1,500kg', top: '190km/h', zero: '-', drive: '뒷바퀴 굴림(RWD)' },
      ph: PH(RWD, { m: 1450, P: 240000, vtop: 61, cl: 0, mu: 1.16, brake: 1.0, L: 2.97, steer: 0.52, wr: 0.4, rear: 1.04, yawR: 9.5, kS: 7.5, dA: 0.52, dS: 0.25, bstA: 4.2, roll: 1.4 }),
      snd: ['ice', 0.7, 4], lv: 'solid', liv: [['원본 은', '#e1e6ec'], ['흰', '#f2f0ea'], ['적', '#8a1a1a'], ['흑', '#141416'], ['영국 녹', '#1f4a36'], ['남', '#1b2550']],
      model: 'Mercedes Benz SS Roadster', ...SK('vecarz', 'https://sketchfab.com/3d-models/mercedes-benz-ss-roadster-wwwvecarzcom-9ab3f68bd7db462b918faa8ecd5c0d15'), lic: 'CC BY-NC-SA 4.0' },
    // ---------- 오프로드 · 이색 ----------
    { id: 'wag', nm: '그랜드 왜건', cls: 'OF', real: '1991년형 미국 대형 SUV', blurb: '나무 무늬 옆판의 큰 SUV. 키가 커서 크게 기울지만 잔디에서도 잘 달려요.',
      spec: { hp: '144마력(V8)', kg: '약 2,100kg', top: '160km/h', zero: '-', drive: '네 바퀴 굴림(4WD)' },
      ph: PH(AWD, { m: 2000, P: 230000, vtop: 52, cl: 0, mu: 1.02, brake: 0.95, L: 2.76, steer: 0.55, wr: 0.36, rear: 1.1, yawR: 7.5, kS: 7, dA: 0.44, dG: 0.95, dS: 0.32, hbK: 0.6, bstA: 4, off: 0.88, roll: 2.4 }),
      snd: ['ice', 0.62, 4], lv: 'solid', pm: 1, liv: [['원본 짙은 청록', '#1b2e31'], ['크림', '#e8dfc8'], ['적갈', '#5a1a14'], ['남', '#1b2550'], ['은', '#a8adb5'], ['흑', '#141416']],
      model: 'Jeep Grand Wagoneer (1991)', ...SK('geyges', 'https://sketchfab.com/3d-models/jeep-grand-wagoneer-1991-8efea05e4eec410c97ee17a02786af92'), lic: 'Sketchfab Standard' },
    { id: 'ural', nm: '설원 6륜', cls: 'OF', real: '소련 군용 6x6 트럭', blurb: '여섯 바퀴 군용 트럭. 크고 무거워서 부딪히면 다 밀어내고, 코너에선 크게 기울어요.',
      spec: { hp: '230마력(V8 디젤)', kg: '약 8,000kg(게임 5,000kg)', top: '85km/h(게임 150)', zero: '-', drive: '여섯 바퀴 굴림(6x6)' },
      ph: PH(AWD, { m: 5000, P: 640000, vtop: 47, cl: 0, mu: 1.0, brake: 0.9, L: 3.9, steer: 0.5, wr: 0.54, rear: 1.15, yawR: 6, kS: 6, dA: 0.38, dG: 0.95, dS: 0.35, hbK: 0.45, bstA: 3.6, off: 0.92, roll: 3 }),
      snd: ['ice', 0.45, 5], lv: 'solid', liv: [['원본 군 녹색', '#3d4a2c'], ['사막', '#b39a6b'], ['설원 흰색', '#dcdcd8'], ['소방 적', '#a3201c'], ['남', '#26324f'], ['주황', '#d8641c']],
      model: 'URAL-4320 (soviet-army truck)', ...SK('zhe_kan', 'https://sketchfab.com/3d-models/ural-4320-soviet-army-truck-e3aadc206ef2413c90f350a3f4e8a5cd'), lic: 'CC BY 4.0' },
  ];
  const CAR = {}; CARS.forEach((c, i) => { c.ix = i; CAR[c.id] = c; });
  /* 한 줄 성격(고르기 화면 카드 · 도감) — 새 차는 여기 한 줄 */
  const TAGS = {
    w17: '직선 최강 · 하이브리드', rb22: '다운포스 최대 · 날카로운 탈출', mx: '네 바퀴 전기 · 순간 가속', lmv: '고속 코너의 왕', cslh: '균형형 · 다루기 쉬움',
    countach: '무거운 V12 · 직선 질주', f40lb: '예민한 꼬리 · 짜릿함', mf1: '최고 속도 · 접지는 약함', slc: '긴 코 스피드스터',
    gt3r: '단단한 고속 코너', m4gt3: '안정감 · 강한 제동', bgt3: '날개 최대 · 묵직함', bb512: '작은 날개 · 강한 가속',
    dmc: '부스트 최강 · 시간 여행', excal: '떠서 달림 · 긴 부스트', semi: '전기 사륜 · 빠른 탈출', maimai: '작고 가벼움 · 쏙쏙 코너', cyber: '네온 쿠페 · 색 따라 빛',
    chall: '드리프트 장인 머슬카', e55: '무겁고 꾸준한 세단', strad: '가벼움 · 클래식 코너 최강', csl71: '솔직한 반응 · 미끄러지기', bent8: '최대 힘 · 거대한 몸집',
    ssk: '긴 코 · 의외의 가속', wag: '잔디도 OK · 크게 기울어짐', ural: '여섯 바퀴 · 다 밀어냄',
  };
  for (const c of CARS) c.tag = TAGS[c.id] || '';
  /* 성능 맞춤(BoP, docs/HYPERRACE.md 「밸런스」): 경주마다 그 서킷에서 차마다 「이상적인 한 바퀴」(idealLap — 접지 · 제동 속도표 + 출력 가속)를 계산하고
     빠르기 배율 s = 내 바퀴 시간 ÷ 기준 → 모든 속도 ×s, 가속 · 접지 · 제동 ×s²(같은 줄을 같은 비율로 빠르게/느리게 = 차의 성격 · 조작감은 그대로).
     서킷마다 따로 재는 이유: 넓고 빠른 서킷은 다운포스 · 최고 속도가 센 차(F1)가, 좁은 서킷은 가벼운 차가 훨씬 유리해서 고정 표로는 못 맞춤.
     같은 클래스 안에서는 언제나 맞춤(기준 = 그 클래스 평균), 여러 클래스가 섞이면 「성능 맞춤」 켬(기본)일 때 기준 = 그 판 차들의 평균.
     CORR = AI 실제 주행과 이상 바퀴의 차이(차별 보정, test-output/hyperrace4/sim.js로 맞춤). */
  const CORR = { w17: 1.03, rb22: 1.032, mx: 0.996, lmv: 1.002, cslh: 1.003, countach: 0.989, f40lb: 0.996, mf1: 1.0, slc: 0.999, gt3r: 0.993, m4gt3: 0.995, bgt3: 0.993, bb512: 0.998,
    dmc: 0.995, excal: 0.990, semi: 0.989, maimai: 0.994, cyber: 0.988, chall: 0.992, e55: 0.988, strad: 0.986, csl71: 0.985, bent8: 0.985, ssk: 0.984, wag: 0.975, ural: 0.978 };   // 오프로드: 잔디로 비켜 가도 안 느려지고 무거워서 밀어내는 몫만큼 −1.2%
  const PH_CACHE = {};
  function scaledPh(id, s) {
    s = Math.round(s * 1000) / 1000;
    const key = id + '@' + s;
    if (PH_CACHE[key]) return PH_CACHE[key];
    const p = CAR[id].ph, s2 = s * s;
    return (PH_CACHE[key] = s === 1 ? p : Object.assign({}, p, { P: p.P * s2 * s, vtop: p.vtop * s, mu: p.mu * s2, cl: p.cl / s2, brake: p.brake * s2, bstA: p.bstA * s2, k: s }));
  }
  const phOf = (c) => c.ph || CAR[c.car].ph;
  /* ideal lap time of a car on this track (s): grip / braking speed table + power-limited acceleration out of corners.
     Cheap (one pass per car) and track-aware — a wide fast circuit favours downforce and top speed much more than a tight one */
  function idealLap(T, id, wet) {
    const p = CAR[id].ph, prof = speedProfile(T, id, wet), n = T.n, cd = p.P / (p.vtop * p.vtop * p.vtop);
    const trac = p.mu * GRAV * (p.awd ? 1 : 0.62) * (wet ? 0.82 : 1);
    let v = Math.min(...prof), t = 0;
    for (let lap = 0; lap < 2; lap++) for (let i = 0; i < n; i++) {
      const j = (i + 1) % n, down = (p.cl * v * v) / p.m;
      const a = Math.min(p.P / Math.max(v, 5) / p.m, trac * (1 + down / GRAV) * gripK(v)) - (cd * v * v) / p.m - 0.012 * GRAV;
      const v1 = Math.min(prof[j], Math.sqrt(Math.max(1, v * v + 2 * a * DS)));
      if (lap) t += DS / ((v + v1) / 2);
      v = v1;
    }
    return t;
  }
  /* per-seat speed factor for a race (deterministic from the state, so every device agrees) */
  function bopFactors(st, T) {
    const ids = st.pk.map((v) => (v && CAR[v[0]] ? v[0] : 'gt3r')), wet = st.wx === 'rain';
    const IL = T.IL || (T.IL = {});
    const pace = (id) => IL[id + wet] || (IL[id + wet] = idealLap(T, id, wet) * (CORR[id] || 1));
    const cls = (id) => CAR[id].cls;
    const geo = (list) => Math.exp(list.reduce((a, id) => a + Math.log(pace(id)), 0) / list.length);
    const multi = new Set(ids.map(cls)).size > 1, on = st.bop !== 'off';
    const allRef = geo(ids), cref = {};
    return ids.map((id) => {
      const k = cls(id), ref = multi && on ? allRef : (cref[k] || (cref[k] = geo(CARS.filter((c) => c.cls === k).map((c) => c.id))));
      return clamp(pace(id) / ref, 0.55, 1.6);
    });
  }
  const TIERS = [
    { id: 'low', nm: '낮음', tip: '폰에 알맞아요 · 차 약 2만 삼각형 · 결 512', pr: 1.25, shadow: 0, trees: 160, aa: true },
    { id: 'mid', nm: '보통', tip: '차 약 5~6만 삼각형 · 결 1024 · 그림자', pr: 1.6, shadow: 1024, trees: 380, aa: true },
    { id: 'high', nm: '높음', tip: 'PC 권장 · 차 11~15만 삼각형 · 결 2048 · 실내 · 부드러운 그림자', pr: 2, shadow: 2048, trees: 800, aa: true },
  ];
  const GRAV = 9.81, DT = 1 / 120;
  /* 조작감 보정(아케이드 쪽, docs/HYPERRACE.md 「코너링 쉽게」): 빠를수록 옆 접지가 조금 더(+GB, 핸들이 고속에서도 죽지 않게) · 제동 ×BRK */
  const GB = 0.2, BRK = 1.3;
  const gripK = (v) => 1 + GB * clamp((v - 12) / 40, 0, 1);

  /* ======================= 작은 도구 ======================= */
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const wrapA = (a) => { a = (a + Math.PI) % (Math.PI * 2); if (a < 0) a += Math.PI * 2; return a - Math.PI; };
  const fin = (v) => typeof v === 'number' && isFinite(v);
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const kmh = (v) => Math.round(Math.abs(v) * 3.6);

  /* ======================= 서킷 생성 (씨앗 → 결정적, 게스트도 같은 서킷) =======================
     폐곡선 제어점 → Catmull-Rom → 4m 간격 → 길이 맞춤 → 곡률 제한(완화) → 겹침 검사 → 높낮이 → 출발선(가장 긴 직선) → 레이싱 라인(최소 곡률) → 차별 속도표 */
  const DS = 4;
  function trackSize(n) { n = clamp(n | 0, 1, 8); return { len: 1700 + 230 * (n - 1), half: 6.9 + 0.36 * n, run: 13 + 0.4 * n }; }
  /* smallest corner radius allowed at sample i: 34 m, more after a long run-up (no hairpin at the end of a flat-out straight) */
  const RMIN = 34;
  function minRadius(K, i, n, rmin) {
    let j = 0, run = 0;
    while (j < 40 && Math.abs(K[(i - j + n) % n]) >= 1 / 60) j++;            // back through this corner
    while (run < 160 && Math.abs(K[(i - j - run + n * 2) % n]) < 1 / 60) run++;    // then the flat-out run before it (gentle bends count)
    return (rmin || RMIN) + 0.06 * clamp(run * DS - 220, 0, 420);
  }
  function closedSpline(P, step) {
    const n = P.length, out = [];
    for (let i = 0; i < n; i++) {
      const p0 = P[(i - 1 + n) % n], p1 = P[i], p2 = P[(i + 1) % n], p3 = P[(i + 2) % n];
      const seg = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]), m = Math.max(4, Math.ceil(seg / step));
      for (let k = 0; k < m; k++) {
        const t = k / m, t2 = t * t, t3 = t2 * t;
        out.push([
          0.5 * (2 * p1[0] + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
          0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3),
        ]);
      }
    }
    return out;
  }
  function resample(pts, step) {   // closed polyline → points every `step` m
    const n = pts.length, cum = [0];
    for (let i = 0; i < n; i++) { const a = pts[i], b = pts[(i + 1) % n]; cum.push(cum[i] + Math.hypot(b[0] - a[0], b[1] - a[1])); }
    const tot = cum[n], m = Math.max(16, Math.round(tot / step)), out = [];
    let j = 0;
    for (let k = 0; k < m; k++) {
      const s = (k / m) * tot;
      while (cum[j + 1] < s) j++;
      const a = pts[j], b = pts[(j + 1) % n], f = (s - cum[j]) / Math.max(1e-9, cum[j + 1] - cum[j]);
      out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f]);
    }
    return { pts: out, len: tot };
  }
  function curvature(X, Y, i, n, w) {   // signed curvature at i from neighbours ±w (+ = turning left)
    const a = (i - w + n) % n, c = (i + w) % n;
    const ax = X[i] - X[a], ay = Y[i] - Y[a], bx = X[c] - X[i], by = Y[c] - Y[i];
    const cr = ax * by - ay * bx, la = Math.hypot(ax, ay), lb = Math.hypot(bx, by), lc = Math.hypot(X[c] - X[a], Y[c] - Y[a]);
    return (2 * cr) / Math.max(1e-6, la * lb * lc);
  }
  /* 맵(테마) · 코스 성격 (docs/HYPERRACE.md 「맵 · 코스」) — 로직에 필요한 값만(그림은 view.js THEME_LOOK).
     elev 높낮이 배율 · bank 기운 코너 세기 · run 안전지대 배율 · br/tun 다리/터널이 나올 확률 · st 이 맵에 어울리는 코스 성격 */
  const THEMES = {
    park: { nm: '초원 서킷', st: ['flow', 'fast', 'tech'], elev: 1, bank: 0.6, run: 1, br: 0, tun: 0 },
    coast: { nm: '해안 도로', st: ['flow', 'tech'], elev: 1.3, bank: 0.35, run: 0.55, br: 0.75, tun: 0.35 },
    canyon: { nm: '사막 협곡', st: ['flow', 'tech', 'fast'], elev: 1.6, bank: 0.45, run: 0.8, br: 0.8, tun: 0.6 },
    snow: { nm: '설산', st: ['flow', 'tech'], elev: 1.9, bank: 0.5, run: 0.8, br: 0.4, tun: 0.75 },
    forest: { nm: '숲 계곡', st: ['tech', 'flow'], elev: 1.7, bank: 0.3, run: 0.6, br: 0.6, tun: 0.6 },
    city: { nm: '야경 도시', st: ['street'], elev: 0.35, bank: 0, run: 0.2, br: 0, tun: 0.5 },
    plateau: { nm: '고원 서킷', st: ['fast', 'flow'], elev: 2.3, bank: 0.85, run: 1.1, br: 0.5, tun: 0 },
  };
  const STYLES = { flow: '균형', fast: '고속', tech: '테크니컬', street: '시가지' };
  /* 명소 코스(docs/HYPERRACE.md 「명소 코스」): 손으로 모양을 잡은 이름 있는 서킷 — 맵마다 2개.
     P 제어점(반시계, P[0] = 출발선 · 그 앞이 긴 직선) · E 제어점마다 높이(m, 그 사이는 부드럽게) · cs 크기 · 코너 성격
     tun / brg [제어점 a, b] 터널 · 다리 · jmp [제어점(소수)] 점프대 · ov [제어점] 머리 위 고가(그림) · lh [제어점, 쪽 ±1] 등대(그림) · pt 한 줄 소개 */
  const LMK = [
    { id: 'gp', nm: '그린필드 GP', th: 'park', cs: 'flow', pt: '긴 본선 직선 → 머리핀 → S자 → 시케인 → 넓은 마지막 코너',
      P: [[0, 0], [7, 0], [12, 0], [14, 2], [13, 4.5], [9, 5], [8, 7], [12, 8.5], [13, 11], [10, 13], [6, 12], [3, 13.5], [0, 12], [-3, 13.5], [-6, 12], [-8, 9], [-5, 7], [-8, 5], [-9, 2], [-5, 0]],
      E: [0, 0, 1, 3, 5, 5, 6, 8, 9, 8, 7, 6, 6, 5, 4, 3, 3, 2, 1, 0] },
    { id: 'pinwheel', nm: '바람개비 링', th: 'park', cs: 'tech', pt: '드리프트하기 좋은 넓은 연속 코너 · 언덕 위 시케인',
      P: [[0, 0], [7, 0], [11, 1], [13, 4], [12, 7], [9, 8], [6, 6.5], [3, 7.5], [3, 10.5], [0, 12.5], [-4, 12], [-7, 10], [-10, 8], [-11, 4.5], [-9, 1.5], [-5, 0]],
      E: [0, 0, 2, 4, 6, 7, 8, 9, 10, 9, 7, 6, 5, 3, 1, 0] },
    { id: 'lighthouse', nm: '등대곶 해안로', th: 'coast', cs: 'flow', pt: '바닷가 직선 · 등대를 끼고 도는 곶 머리핀 · 절벽 위 오르막 · 바위산 터널',
      P: [[0, 0], [6, 0], [11, 0], [16, 0.5], [19, 1.6], [19.6, 3.2], [18.4, 4.6], [15, 4.6], [11, 5], [8, 7], [7, 10], [3, 12], [-2, 11.5], [-6, 12], [-9, 9.5], [-10, 5.5], [-8, 2], [-4, 0]],
      E: [0, 0, 0, 1, 1, 2, 2, 3, 5, 8, 12, 15, 16, 14, 10, 6, 2, 0], lh: [4.6, -1], tun: [12, 13] },
    { id: 'palmbay', nm: '야자수 만', th: 'coast', cs: 'tech', pt: '모래 해변 직선 · 만을 건너는 다리 · 해안 시케인',
      P: [[0, 0], [6, 0], [11, 0], [14, 2], [14, 5.5], [11, 7], [11, 10], [8, 12], [4, 11], [0, 12], [-4, 11.5], [-5, 8.5], [-7, 6], [-10, 6], [-11, 3], [-6, 0]],
      E: [0, 0, 0, 1, 3, 4, 6, 7, 6, 5, 5, 4, 4, 3, 1, 0], brg: [9, 10] },
    { id: 'redjump', nm: '붉은 협곡 점프', th: 'canyon', cs: 'flow', pt: '협곡 다리 · 내리막 직선의 점프대 · 바위 사이 S자',
      P: [[0, 0], [7, 0], [12, 0.5], [14, 3], [12.5, 6], [9, 6.5], [6, 8], [2, 9.5], [-3, 9.5], [-8, 9], [-11, 7], [-12, 3.5], [-9, 0.5], [-4, 0]],
      E: [0, 0, 2, 5, 9, 12, 16, 19, 12, 7, 4, 2, 1, 0], brg: [4, 5], jmp: [7.3] },
    { id: 'mesa', nm: '메사 고속 스윕', th: 'canyon', cs: 'fast', pt: '탁자 바위를 뚫는 터널 · 끝없이 이어지는 고속 스윕 · 마루 넘기',
      P: [[0, 0], [8, 0], [14, 1.5], [17, 5], [15, 9], [10, 10.5], [5, 9], [0, 11], [-6, 11], [-11, 8.5], [-12, 4], [-7, 0.5]],
      E: [0, 0, 3, 6, 10, 12, 8, 4, 8, 11, 6, 1], tun: [3, 4] },
    { id: 'switchback', nm: '설산 헤어핀', th: 'snow', cs: 'tech', pt: '산을 오르는 머리핀 연속 · 눈 터널 · 고개 넘어 긴 내리막',
      P: [[0, 0], [7, 0], [12, 0.5], [14, 3], [11, 4.5], [6, 4.5], [4, 6.5], [6, 8.5], [11, 9], [13, 11.5], [11, 14], [6, 14.5], [1, 13.5], [-4, 14], [-8, 12], [-10, 7], [-9, 3], [-5, 0.3]],
      E: [0, 0, 1, 3, 5, 7, 9, 11, 13, 16, 19, 22, 24, 22, 17, 10, 4, 1], tun: [12, 13] },
    { id: 'glacier', nm: '빙하 고개', th: 'snow', cs: 'flow', pt: '빙하 위 다리 · 마루에서 살짝 뜨는 점프 · 큰 내리막 직선',
      P: [[0, 0], [7, 0], [12, 1], [14, 4.5], [12, 8], [7, 9], [2, 10], [-3, 11.5], [-8, 10.5], [-11, 7], [-10.5, 3], [-6, 0.4]],
      E: [0, 0, 3, 7, 11, 15, 17, 13, 8, 4, 1, 0], brg: [3, 4], jmp: [6.4] },
    { id: 'esses', nm: '숲속 S자', th: 'forest', cs: 'tech', pt: '나무 사이로 이어지는 S자 연속 · 계곡 다리 · 오르막 시케인',
      P: [[0, 0], [6, 0], [10, 1], [11, 4], [9, 6], [11, 8], [9.5, 10.5], [6, 10], [3, 12], [0, 10.5], [-3, 12], [-6, 10.5], [-9, 11], [-10, 8], [-8, 5.5], [-10, 3], [-6, 0.4]],
      E: [0, 0, 1, 3, 4, 6, 7, 8, 9, 8, 9, 8, 7, 5, 4, 2, 0], brg: [12, 13] },
    { id: 'dropvalley', nm: '계곡 낙차', th: 'forest', cs: 'flow', pt: '숲 터널을 빠져나오면 큰 낙차 · 골짜기 바닥에서 다시 오르막',
      P: [[0, 0], [7, 0], [12, 1], [14, 4.5], [12, 8], [8, 8], [5, 11], [0, 12], [-5, 11], [-9, 8.5], [-10, 4], [-6, 0.5]],
      E: [0, 0, 4, 9, 14, 16, 6, 2, 4, 8, 6, 2], tun: [4, 5] },
    { id: 'neon', nm: '네온 고가 시가지', th: 'city', cs: 'street', pt: '머리 위로 지나가는 고가도로 · 직각 코너 · 지하 차도',
      P: [[0, 0], [5, 0], [9, 0], [9, 3.6], [6, 3.6], [6, 6.4], [9, 6.4], [9, 9.6], [4.4, 9.6], [0, 9.6], [-4, 9.6], [-4, 5.6], [-7, 5.6], [-7, 0], [-3, 0]],
      E: [0, 0, 0, 1, 1, 2, 2, 3, 3, 2, 1, 1, 1, 0, 0], ov: [1.5, 8.5, 12.5], tun: [9, 10] },
    { id: 'harbor', nm: '항구 교차로', th: 'city', cs: 'street', pt: '부두를 따라 긴 직선 · 교차로 밑을 지나는 길 · 시케인',
      P: [[0, 0], [6, 0], [11, 0], [11, 4.4], [8, 4.4], [8, 5.6], [11, 5.6], [11, 9.6], [5, 9.6], [-1, 9.6], [-1, 6], [-5, 6], [-5, 9.6], [-9, 9.6], [-9, 0], [-4, 0]],
      E: [0, 0, 0, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 0, 0], ov: [3.5, 9.5, 14.5] },
    { id: 'highsweep', nm: '고원 고속 스윕', th: 'plateau', cs: 'fast', pt: '하늘 아래 넓은 고속 스윕 · 마루 넘어 내리꽂는 직선',
      P: [[0, 0], [9, 0], [15, 2], [18, 6.5], [15, 11], [9, 12], [3, 10], [-3, 12.5], [-10, 11.5], [-14, 7], [-12, 2.5], [-6, 0.2]],
      E: [0, 0, 4, 10, 16, 20, 14, 18, 12, 6, 1, 0] },
    { id: 'ridge', nm: '하늘 능선', th: 'plateau', cs: 'flow', pt: '능선을 타는 마루 연속(차가 가벼워짐) · 점프대 · 협곡 다리',
      P: [[0, 0], [7, 0], [12, 1], [14, 4.5], [12, 7.5], [8, 7.5], [5, 10], [0, 11], [-5, 10], [-9, 8], [-11, 4], [-7, 0.6]],
      E: [0, 0, 6, 3, 9, 4, 11, 13, 8, 7, 4, 1], brg: [4, 5], jmp: [7.4] },
  ];
  const LM = {}; LMK.forEach((l) => { LM[l.id] = l; });
  /* 만든 서킷 이름(씨앗으로 정함): 맵마다 앞말 + 뒷말 */
  const TNM = { park: ['초록 언덕', '풀밭', '들꽃', '바람 들'], coast: ['파도', '모래톱', '소금 바람', '푸른 곶'], canyon: ['붉은 바위', '모래 협곡', '메마른 강', '석양 절벽'],
    snow: ['눈보라', '얼음 고개', '하얀 봉우리', '서리'], forest: ['이끼 숲', '안개 계곡', '전나무', '고사리'], city: ['네온 거리', '자정 도심', '유리 탑', '항구 불빛'], plateau: ['구름 능선', '높은 들', '하늘 고원', '바람 언덕'] };
  const TSUF = { flow: ['서킷', '링'], fast: ['스피드웨이', '고속 링'], tech: ['테크 코스', '굽이길'], street: ['시가지 코스', '스트리트'] };
  function trackName(T) {
    if (T.lm) return LM[T.lm].nm;
    const a = TNM[T.th] || TNM.park, b = TSUF[T.cs] || TSUF.flow, s = T.seed >>> 0;
    return a[s % a.length] + ' ' + b[(s >>> 3) % b.length];
  }
  /* 시가지: 격자 칸 직사각형에서 가장자리 칸을 1~3개 파낸 직각 다각형 → 모서리를 둥글게(반지름 38m) */
  function streetLoop(rnd, len) {
    const cw = 4 + Math.floor(rnd() * 3), ch = 3 + Math.floor(rnd() * 2), on = [];
    for (let y = 0; y < ch; y++) { on.push([]); for (let x = 0; x < cw; x++) on[y].push(1); }
    const cut = 1 + Math.floor(rnd() * 3);
    for (let k = 0, guard = 0; k < cut && guard < 40; guard++) {
      const side = Math.floor(rnd() * 4), t = side < 2 ? Math.floor(rnd() * cw) : Math.floor(rnd() * ch);
      const [x, y] = side === 0 ? [t, 0] : side === 1 ? [t, ch - 1] : side === 2 ? [0, t] : [cw - 1, t];
      if (!on[y][x]) continue;
      // keep it one piece without thin necks: never cut next to another cut, keep ≥ 2 cells in every row / column
      let near = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const yy = y + dy, xx = x + dx; if (yy >= 0 && yy < ch && xx >= 0 && xx < cw && !on[yy][xx]) near++; }
      if (near) continue;
      on[y][x] = 0;
      if (on[y].reduce((a, b) => a + b, 0) < 2 || on.reduce((a, r) => a + r[x], 0) < 2) { on[y][x] = 1; continue; }
      k++;
    }
    const at = (x, y) => (x >= 0 && y >= 0 && x < cw && y < ch ? on[y][x] : 0);
    // boundary edges, counter-clockwise around the filled cells (cell interior on the left)
    const E = new Map();
    for (let y = 0; y < ch; y++) for (let x = 0; x < cw; x++) {
      if (!on[y][x]) continue;
      if (!at(x, y - 1)) E.set(x + ',' + y, [x + 1, y]);
      if (!at(x + 1, y)) E.set((x + 1) + ',' + y, [x + 1, y + 1]);
      if (!at(x, y + 1)) E.set((x + 1) + ',' + (y + 1), [x, y + 1]);
      if (!at(x - 1, y)) E.set(x + ',' + (y + 1), [x, y]);
    }
    const start = E.keys().next().value, poly = [];
    let cur = start;
    for (let g = 0; g < 400; g++) { const [px, py] = cur.split(',').map(Number); poly.push([px, py]); const nx = E.get(cur); cur = nx[0] + ',' + nx[1]; if (cur === start) break; }
    // drop straight-through points, scale to the length, round every corner
    const corners = poly.filter((p, i) => { const a = poly[(i - 1 + poly.length) % poly.length], b = poly[(i + 1) % poly.length]; return (p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0]) !== 0; });
    let per = 0; for (let i = 0; i < corners.length; i++) { const a = corners[i], b = corners[(i + 1) % corners.length]; per += Math.abs(b[0] - a[0]) + Math.abs(b[1] - a[1]); }
    const cell = len / per * 1.06, sx = cell * (1 + (rnd() - 0.5) * 0.3), sy = cell * (1 + (rnd() - 0.5) * 0.3), r = 38, out = [];
    const C = corners.map((p) => [p[0] * sx, p[1] * sy]);
    for (let i = 0; i < C.length; i++) {
      const a = C[(i - 1 + C.length) % C.length], p = C[i], b = C[(i + 1) % C.length];
      const l1 = Math.hypot(p[0] - a[0], p[1] - a[1]), l2 = Math.hypot(b[0] - p[0], b[1] - p[1]);
      const d1 = [(p[0] - a[0]) / l1, (p[1] - a[1]) / l1], d2 = [(b[0] - p[0]) / l2, (b[1] - p[1]) / l2], rr = Math.min(r, l1 * 0.45, l2 * 0.45);
      const s0 = [p[0] - d1[0] * rr, p[1] - d1[1] * rr], s1 = [p[0] + d2[0] * rr, p[1] + d2[1] * rr];
      for (let k = 0; k <= 8; k++) { const t = k / 8, u = 1 - t; out.push([u * u * s0[0] + 2 * u * t * p[0] + t * t * s1[0], u * u * s0[1] + 2 * u * t * p[1] + t * t * s1[1]]); }
    }
    return out;
  }
  function genTrack(seed, nCars, th, cs, arc) {
    const lm = typeof cs === 'string' && cs.slice(0, 3) === 'lm:' && LM[cs.slice(3)] ? LM[cs.slice(3)] : null;
    if (lm) { th = lm.th; cs = lm.cs; }
    const TH = THEMES[th] || THEMES.park, style = STYLES[cs] ? cs : 'flow';
    const Z0 = trackSize(nCars), Z = { len: Z0.len * (style === 'fast' ? 1.12 : style === 'street' ? 0.95 : 1), half: Z0.half, run: Math.max(3.2, Z0.run * TH.run) };
    const rnd = prng(seed * 7919 + 13), rmin = style === 'fast' ? 44 : RMIN;
    let best = null, cpF = null;   // landmark: lap fraction of each control point
    for (let tr = 0; tr < (lm ? 1 : 40) && !best; tr++) {
      let pts;
      if (lm) {
        let per = 0; lm.P.forEach((p, i) => { const q = lm.P[(i + 1) % lm.P.length]; per += Math.hypot(q[0] - p[0], q[1] - p[1]); });
        const PS = lm.P.map((p) => [p[0] * Z.len / per, p[1] * Z.len / per]);
        pts = closedSpline(PS, 6);
        // fraction of the lap at each control point (closedSpline: m points per segment)
        const segL = PS.map((p, i) => { const q = PS[(i + 1) % PS.length]; return Math.max(4, Math.ceil(Math.hypot(q[0] - p[0], q[1] - p[1]) / 6)); });
        const cum = [0]; let tot = 0; const PL = [];
        for (let i = 0; i < pts.length; i++) { const a = pts[i], b = pts[(i + 1) % pts.length]; PL.push(Math.hypot(b[0] - a[0], b[1] - a[1])); }
        let k0 = 0; for (let s = 0; s < segL.length; s++) { cum.push(0); for (let k = 0; k < segL[s]; k++) tot += PL[k0 + k]; k0 += segL[s]; cum[s + 1] = tot; }
        cpF = cum.slice(0, lm.P.length).map((v) => v / tot);
      } else if (style === 'street') pts = streetLoop(rnd, Z.len);
      else {
        const K = style === 'fast' ? 7 + Math.floor(rnd() * 3) : style === 'tech' ? 12 + Math.floor(rnd() * 5) : 9 + Math.floor(rnd() * 6), R0 = Z.len / (2 * Math.PI), P = [];
        const sx = (style === 'fast' ? 0.95 : 0.75) + rnd() * 0.6, sy = 1.6 - sx * 0.6;   // stretch: long circuits, not circles
        const rv = style === 'fast' ? [0.7, 0.45] : style === 'tech' ? [0.4, 0.85] : [0.45, 0.75];
        let ang = rnd() * Math.PI * 2;
        for (let k = 0; k < K; k++) {
          ang += (Math.PI * 2 / K) * (0.7 + rnd() * 0.6);
          const r = R0 * (rv[0] + rnd() * rv[1]);
          P.push([Math.cos(ang) * r * sx, Math.sin(ang) * r * sy]);
        }
        // order by angle around the centroid (keeps the loop simple), then a few random pushes inward = bays and hairpins
        const cx = P.reduce((s, p) => s + p[0], 0) / K, cy = P.reduce((s, p) => s + p[1], 0) / K;
        P.sort((p, q) => Math.atan2(p[1] - cy, p[0] - cx) - Math.atan2(q[1] - cy, q[0] - cx));
        const pushes = style === 'tech' ? 2 : style === 'fast' ? (rnd() < 0.15 ? 1 : 0) : rnd() < 0.6 ? 1 : 0;
        for (let q = 0; q < pushes; q++) { const k = Math.floor(rnd() * K); P[k] = [cx + (P[k][0] - cx) * 0.35, cy + (P[k][1] - cy) * 0.35]; }
        pts = closedSpline(P, 6);
      }
      let r = resample(pts, DS);
      // scale to the target length
      const f = Z.len / r.len;
      pts = r.pts.map((p) => [p[0] * f, p[1] * f]);
      // limit curvature: relax the tightest spots (min radius 34 m — 44 m on fast circuits — more after a long straight: minRadius)
      for (let it = 0; it < 90; it++) {
        const n = pts.length, X = pts.map((p) => p[0]), Y = pts.map((p) => p[1]);
        const KK = []; for (let i = 0; i < n; i++) KK.push(curvature(X, Y, i, n, 3));
        let bad = 0;
        for (let i = 0; i < n; i++) {
          const k = Math.abs(KK[i]), rn = k > 1 / 75 ? minRadius(KK, i, n, rmin) : 0;
          if (k * rn > 1.0) {
            bad++;
            // wider corners need a wider smoothing stencil (plain neighbours only fix very local kinks)
            const m = clamp(Math.round(rn / 14), 1, 5), W2 = 2 * m + 3;
            for (let d = -W2; d <= W2; d++) {
              const j = (i + d + n) % n, a = pts[(j - m + n) % n], b = pts[(j + m) % n], w = 0.3 * (1 - Math.abs(d) / (W2 + 1));
              pts[j] = [pts[j][0] + ((a[0] + b[0]) / 2 - pts[j][0]) * w, pts[j][1] + ((a[1] + b[1]) / 2 - pts[j][1]) * w];
            }
          }
        }
        if (!bad) break;
        r = resample(pts, DS); const g = Z.len / r.len; pts = r.pts.map((p) => [p[0] * g, p[1] * g]);
      }
      r = resample(pts, DS); pts = r.pts;
      const n = pts.length, X = pts.map((p) => p[0]), Y = pts.map((p) => p[1]);
      // overlap check: far-apart samples must keep the runoff of both sides apart
      const clear = 2 * (Z.half + Z.run) + 14, c2 = clear * clear, gap = Math.ceil((clear * 2.2) / DS);
      let ok = true;
      for (let i = 0; i < n && ok; i += 2) for (let j = i + gap; j < n; j += 2) {
        if (n - (j - i) < gap) continue;
        const dx = X[i] - X[j], dy = Y[i] - Y[j];
        if (dx * dx + dy * dy < c2) { ok = false; break; }
      }
      let kmax = 0; for (let i = 0; i < n; i++) kmax = Math.max(kmax, Math.abs(curvature(X, Y, i, n, 3)));
      if ((ok && kmax < 1 / (RMIN - 6)) || lm) best = { X, Y, tr, ok: ok && kmax < 1 / (RMIN - 6) };
    }
    if (!best) {   // fallback: a rounded rectangle
      const pts = [], a = Z.len / 6, b = Z.len / 9;
      for (let k = 0; k < 64; k++) { const t = (k / 64) * Math.PI * 2, c = Math.cos(t), s = Math.sin(t); pts.push([Math.sign(c) * Math.pow(Math.abs(c), 0.35) * a, Math.sign(s) * Math.pow(Math.abs(s), 0.35) * b]); }
      const r = resample(closedSpline(pts, 6), DS); best = { X: r.pts.map((p) => p[0]), Y: r.pts.map((p) => p[1]), tr: -1 };
    }
    let { X, Y } = best;
    let n = X.length;
    let rev = false;
    if (curvatureSum(X, Y) < 0) { X = X.reverse(); Y = Y.reverse(); rev = true; }   // always run counter-clockwise (left turns dominate)
    // start line: before the longest calm stretch (landmark: at its first control point)
    let s0 = 0;
    if (lm) { if (rev) s0 = (n - 1) % n; }
    else {
      const K0 = []; for (let i = 0; i < n; i++) K0.push(Math.abs(curvature(X, Y, i, n, 3)));
      const win = Math.round(260 / DS);
      let sb = 1e9;
      for (let i = 0; i < n; i++) { let s = 0; for (let k = -Math.round(win * 0.45); k < win; k++) s += K0[(i + k + n) % n]; if (s < sb) { sb = s; s0 = i; } }
      s0 = (s0 + Math.round(win * 0.12)) % n;
    }
    X = X.slice(s0).concat(X.slice(0, s0)); Y = Y.slice(s0).concat(Y.slice(0, s0));
    // landmark control point k (fractional) → sample index
    const cpI = (k) => { if (!cpF) return 0; const K = cpF.length, a = Math.floor(k), f = k - a, fa = cpF[((a % K) + K) % K], fb = a + 1 >= K ? 1 : cpF[a + 1]; let u = fa + (fb - fa) * f; if (rev) u = 1 - u; return ((Math.round(u * n) % n) + n) % n; };
    // elevation: a few waves along the lap (crests and dips; × the map's height factor — the plateau / snow maps climb a lot more)
    const Hh = new Array(n).fill(0);
    if (lm) {   // landmark: heights at the control points, smooth (cosine) in between
      const K = lm.P.length, I = lm.E.map((_, k) => cpI(k)), eS = clamp(Z.len / 2000, 0.85, 1.5);   // longer (more cars) = higher hills, same gradients
      for (let k = 0; k < K; k++) {
        const a = I[k], b = I[(k + 1) % K], h0 = lm.E[k] * eS, h1 = lm.E[(k + 1) % K] * eS, d = rev ? (a - b + n) % n : (b - a + n) % n;
        for (let s = 0; s <= d; s++) { const i = rev ? (a - s + n) % n : (a + s) % n, f = d ? s / d : 0; Hh[i] = h0 + (h1 - h0) * (1 - Math.cos(f * Math.PI)) / 2; }
      }
    } else {
      const am = (2 + rnd() * 4.5) * TH.elev;
      const w1 = 1 + Math.floor(rnd() * 3), w2 = 3 + Math.floor(rnd() * 3), p1 = rnd() * 6.28, p2 = rnd() * 6.28;
      for (let i = 0; i < n; i++) { const u = (i / n) * Math.PI * 2; Hh[i] = am * (Math.sin(u * w1 + p1) - Math.sin(p1)) + am * 0.35 * (Math.sin(u * w2 + p2) - Math.sin(p2)); }
    }
    const T = { seed, th: THEMES[th] ? th : 'park', cs: style, lm: lm ? lm.id : null, ovl: best.ok === false, arc: arc ? 1 : 0, tries: best.tr, n, len: n * DS, half: Z.half, run: Z.run, X, Y, H: Hh, TX: [], TY: [], K: [], SL: [], OFF: [], KL: [], RO: [], CU: [], BK: [], WD: [], TUN: null, BRG: null, JMP: [], PAD: [], OV: [], LH: null };
    T.nm = trackName(T);
    for (let i = 0; i < n; i++) {
      const a = (i - 1 + n) % n, b = (i + 1) % n, dx = X[b] - X[a], dy = Y[b] - Y[a], l = Math.hypot(dx, dy) || 1;
      T.TX.push(dx / l); T.TY.push(dy / l); T.K.push(curvature(X, Y, i, n, 3));
      T.SL.push((Hh[b] - Hh[a]) / (2 * DS));
    }
    // curbs where it turns (inside & outside), gravel runoff on the outside of fast-ish corners
    for (let i = 0; i < n; i++) { let m = 0; for (let k = -3; k <= 3; k++) m = Math.max(m, Math.abs(T.K[(i + k + n) % n])); T.CU.push(m > 1 / 140 ? 1 : 0); T.RO.push(m > 1 / 90 && style !== 'street' ? (T.K[i] > 0 ? -1 : 1) : 0); }
    // banked corners (the outside is higher: road height = H − lat × BK): up to ~7°, smoothed in and out
    const bk0 = T.K.map((k) => (Math.abs(k) > 1 / 160 ? Math.sign(k) * Math.min(0.13, Math.abs(k) * 7) * TH.bank * (style === 'fast' ? 1.25 : 1) : 0));
    for (let i = 0; i < n; i++) { let s = 0; for (let k = -7; k <= 7; k++) s += bk0[(i + k + n) % n]; T.BK.push(Math.round((s / 15) * 1000) / 1000); }
    // a tunnel and / or a bridge on a calm stretch away from the start (pits, stands) — the walls close in there
    const calm = (a, L) => { for (let k = 0; k < L; k++) if (Math.abs(T.K[(a + k) % n]) > 1 / 110) return false; return true; };
    const used = [];
    const pick = (L, p) => {
      if (rnd() >= p) return null;
      for (let g = 0; g < 60; g++) {
        const a = 60 + Math.floor(rnd() * (n - 120 - L));
        if (a + L > n - 50 || !calm(a, L) || used.some(([u0, u1]) => a < u1 + 25 && a + L > u0 - 25)) continue;
        used.push([a, a + L]); return [a, a + L];
      }
      return null;
    };
    const span = (r) => {   // landmark [a, b] control points → sample run (24..56 samples, centred)
      if (!r) return null;
      let a = cpI(r[0]), b = cpI(r[1]); if (rev) { const t = a; a = b; b = t; }
      let L = (b - a + n) % n; const mid = (a + L / 2) % n; L = clamp(L, 24, 56);
      a = Math.round(mid - L / 2); if (a < 40) a = 40; if (a + L > n - 30) a = n - 30 - L;
      used.push([a, a + L]); return [a, a + L];
    };
    if (lm) { T.TUN = span(lm.tun); T.BRG = span(lm.brg); }
    else { T.TUN = pick(28 + Math.floor(rnd() * 14), TH.tun); T.BRG = pick(24 + Math.floor(rnd() * 12), TH.br); }
    // jump kickers (landmark set pieces; generated tracks only with 「아케이드 요소」): a short ramp, then the road falls away — a calm run after it to land
    const kick = (j) => {
      // a ramp rising 0.9 m over 24 m, steepest at the lip (slope ≈ 0.075), then the road drops back
      for (let d = -6; d <= 1; d++) { const i = (j + d + n) % n, f = d <= 0 ? Math.pow((d + 6) / 6, 2) : 0.3; Hh[i] += 0.9 * f; }
      T.JMP.push(j); (T.JL || (T.JL = {}))[j] = 1; T.JL[(j + 1) % n] = 1;
    };
    if (lm && lm.jmp) for (const k of lm.jmp) kick(cpI(k));
    else if (arc) {
      for (let g = 0; g < 80 && T.JMP.length < 1; g++) {
        const j = 70 + Math.floor(rnd() * (n - 140));
        if (calm(j - 14, 60) && !used.some(([u0, u1]) => j > u0 - 20 && j < u1 + 20)) kick(j);
      }
    }
    if (T.JMP.length) for (let i = 0; i < n; i++) { const a = (i - 1 + n) % n, b = (i + 1) % n; T.SL[i] = (Hh[b] - Hh[a]) / (2 * DS); }
    // vertical curvature of the road (+ = dip, − = crest), smoothed: light over crests, pressed in dips, airborne over a kicker
    T.VK = [];
    for (let i = 0; i < n; i++) { let s = 0; for (let d = -1; d <= 1; d++) { const j = (i + d + n) % n; s += (Hh[(j + 2) % n] - 2 * Hh[j] + Hh[(j - 2 + n) % n]) / (64); } T.VK.push(Math.round((s / 3) * 1e5) / 1e5); }
    // 「아케이드 요소」: boost pads on the straights out of corners (one side, 4 m wide)
    if (arc) {
      for (let i = 30; i < n - 20; i++) {
        if (Math.abs(T.K[i]) < 1 / 300 && Math.abs(T.K[(i - 8 + n) % n]) > 1 / 120 && calm(i, 10) && !T.PAD.some((p) => Math.abs(p[0] - i) < 40) && !T.JMP.some((j) => Math.abs(j - i) < 20)) {
          T.PAD.push([i, Math.round(clamp(-Math.sign(T.K[(i - 8 + n) % n]) * (Z.half - 2.6), -(Z.half - 2.4), Z.half - 2.4) * 10) / 10]);
        }
      }
    }
    if (T.PAD.length) { T.PADI = new Array(n).fill(null); for (const [i, l] of T.PAD) for (let d = 0; d < 4; d++) T.PADI[(i + d) % n] = l; }
    // 「아케이드 요소」: item box rows across the road on calm stretches (about one per 650 m, 3~6 a lap). Geometry only (no rnd) — the circuit itself is unchanged
    T.IB = [];
    if (arc) {
      const rows = clamp(Math.round((n * DS) / 650), 3, 6);
      for (let r = 0; r < rows; r++) {
        const want = Math.round(((r + 0.55) / rows) * n);
        let best = -1, bs = 1e9;
        for (let d = -40; d <= 40; d++) {
          const i = want + d;
          if (i < 30 || i > n - 25 || T.PAD.some((p) => Math.abs(p[0] - i) < 12) || T.JMP.some((j) => Math.abs(j - i) < 26) || T.IB.some((b) => Math.abs(b[0] - i) < 45)) continue;
          if (T.TUN && i > T.TUN[0] - 8 && i < T.TUN[1] + 8) continue;
          let k = 0; for (let q = -3; q <= 3; q++) k = Math.max(k, Math.abs(T.K[(i + q + n) % n]));
          const sc = k * 400 + Math.abs(d) * 0.02;
          if (sc < bs) { bs = sc; best = i; }
        }
        if (best < 0) continue;
        const w = Z.half - 1.4, m = Math.max(3, Math.floor((2 * w) / 3.4) + 1), lats = [];
        for (let q = 0; q < m; q++) lats.push(Math.round((-w + (2 * w * q) / (m - 1)) * 10) / 10);
        T.IB.push([best, lats]);
      }
      T.IB.sort((a, b) => a[0] - b[0]);
    }
    if (lm && lm.ov) T.OV = lm.ov.map(cpI);
    else if (T.th === 'city') for (let g = 0; g < 30 && T.OV.length < 2; g++) { const j = 40 + Math.floor(rnd() * (n - 80)); if (calm(j - 4, 8) && !T.OV.some((o) => Math.abs(o - j) < 60) && !used.some(([u0, u1]) => j > u0 - 10 && j < u1 + 10)) T.OV.push(j); }
    if (lm && lm.lh) T.LH = [cpI(lm.lh[0]), lm.lh[1] * (rev ? -1 : 1)];
    const wd = new Array(n).fill(Z.half + Z.run);
    for (const sp of [T.TUN, T.BRG]) if (sp) for (let i = sp[0] - 12; i <= sp[1] + 12; i++) {
      const j = ((i % n) + n) % n, e = clamp(Math.min(i - (sp[0] - 12), sp[1] + 12 - i) / 12, 0, 1);
      wd[j] = Math.min(wd[j], lerp1(Z.half + Z.run, Z.half + 2.6, e));
    }
    T.WD = wd.map((v) => Math.round(v * 100) / 100);
    racingLine(T);
    T.PROF = {};
    return T;
  }
  const lerp1 = (a, b, t) => a + (b - a) * t;
  function curvatureSum(X, Y) { let a = 0; const n = X.length; for (let i = 0; i < n; i++) { const j = (i + 1) % n; a += X[i] * Y[j] - X[j] * Y[i]; } return a; }
  /* minimum-curvature line inside ±(half − 1.7): elastic relaxation of lateral offsets */
  function racingLine(T) {
    const n = T.n, lim = T.half - 1.7, off = new Array(n).fill(0);
    const px = (i) => T.X[i] - T.TY[i] * off[i], py = (i) => T.Y[i] + T.TX[i] * off[i];
    for (let it = 0; it < 260; it++) {
      for (let i = 0; i < n; i++) {
        const a = (i - 1 + n) % n, b = (i + 1) % n;
        const mx = (px(a) + px(b)) / 2, my = (py(a) + py(b)) / 2;
        const d = (mx - T.X[i]) * -T.TY[i] + (my - T.Y[i]) * T.TX[i];
        off[i] = clamp(off[i] + (d - off[i]) * 0.6, -lim, lim);
      }
    }
    T.OFF = off.map((v) => Math.round(v * 100) / 100);
    const LX = [], LY = []; for (let i = 0; i < n; i++) { LX.push(px(i)); LY.push(py(i)); }
    T.LX = LX; T.LY = LY;
    T.KL = []; for (let i = 0; i < n; i++) T.KL.push(curvature(LX, LY, i, n, 4));
  }
  /* target speed along the racing line for one car (grip incl. downforce, then braking backwards) */
  function speedProfile(T, car, wet, safe) {   // car: a race car (its BoP-scaled physics) or a car id · safe: people (assists) — also the centre line, which is tighter than the racing line at entry / exit
    const p = typeof car === 'string' ? CAR[car].ph : phOf(car), carId = typeof car === 'string' ? car : car.car;
    const key = carId + '@' + (p.k || 1) + (wet ? 'w' : 'd') + (safe ? 's' : '');
    if (T.PROF[key]) return T.PROF[key];
    const mu = p.mu * (wet ? 0.82 : 1), n = T.n, v = new Array(n);
    for (let i = 0; i < n; i++) {
      let k = 0; for (let d = -1; d <= 1; d++) k = Math.max(k, Math.abs(T.KL[(i + d + n) % n]), safe ? Math.abs(T.K[(i + d + n) % n]) : 0);
      // grip grows a little with speed (gripK): a few fixed-point steps
      let vv = p.vtop;
      const bkA = T.BK ? Math.abs(T.BK[i] || 0) * 0.9 * (p.k || 1) * (p.k || 1) : 0;   // banking (as in stepCar)
      let vc = 0; if (T.VK) for (let d = -3; d <= 3; d++) vc = Math.min(vc, T.VK[(i + d + n) % n]);   // over a crest the tyres are lighter
      vc = Math.max(-0.03, vc) / ((p.k || 1) * (p.k || 1));
      for (let q = 0; q < 5; q++) { const g = mu * gripK(vv), den = k - g * (p.cl / p.m + vc); vv = den <= 1e-5 ? p.vtop : Math.min(p.vtop, Math.sqrt((g * GRAV + bkA * GRAV) / den)); }
      v[i] = vv >= p.vtop ? p.vtop : vv * 0.96;
    }
    for (let pass = 0; pass < 3; pass++) for (let i = n - 1; i >= 0; i--) {
      const j = (i + 1) % n, a = (p.brake * GRAV * (wet ? 0.82 : 1) + (p.cl * v[j] * v[j] * mu) / p.m * 0.9) * BRK * 0.78;
      v[i] = Math.min(v[i], Math.sqrt(v[j] * v[j] + 2 * a * DS));
    }
    return (T.PROF[key] = v);
  }

  /* ======================= 차 상태 · 위치 찾기 ======================= */
  function locate(T, c) {   // nearest sample (local search, global when lost) → c.idx, c.lat (+ = left), c.tdir
    const n = T.n;
    let best = c.idx | 0, bd = 1e18;
    const scan = (from, to) => { for (let k = from; k <= to; k++) { const i = ((best0 + k) % n + n) % n, dx = c.x - T.X[i], dy = c.y - T.Y[i], d = dx * dx + dy * dy; if (d < bd) { bd = d; best = i; } } };
    const best0 = best;
    scan(-12, 12);
    if (bd > 30 * 30) { bd = 1e18; for (let i = 0; i < n; i++) { const dx = c.x - T.X[i], dy = c.y - T.Y[i], d = dx * dx + dy * dy; if (d < bd) { bd = d; best = i; } } }
    const i = best, dx = c.x - T.X[i], dy = c.y - T.Y[i];
    c.idx = i;
    c.lat = dx * -T.TY[i] + dy * T.TX[i];
    c.along = dx * T.TX[i] + dy * T.TY[i];
    return i;
  }
  function newCar(T, seat, carId, slot) {
    // grid: two columns, 9 m apart, behind the start line (slot 0 = pole)
    const n = T.n, back = 10 + slot * 8.5, i = ((-Math.round(back / DS)) % n + n) % n;
    const side = slot % 2 ? -1 : 1, lat = side * Math.min(T.half - 2.2, 3.1);
    const c = {
      seat, car: carId, x: T.X[i] - T.TY[i] * lat, y: T.Y[i] + T.TX[i] * lat, h: Math.atan2(T.TY[i], T.TX[i]),
      vf: 0, vl: 0, w: 0, st: 0, idx: i, lat, along: 0, lap: 0, maxI: 0, prog: 0, fin: 0, best: 0, lapT: 0, lapStart: 0, laps: [],
      thr: 0, brk: 0, hb: 0, slip: 0, surf: 0, hit: 0, ghost: 0, stuck: 0, draft: 0, wrong: 0, ax: 0, ay: 0, rpm: 900, gear: 1,
      si: 0, sa: 0, dr: 0, dd: 1, dc: 0, dlv: 0, bst: 0, blv: 0, spin: 0, gu: 0, alat: 0, ws: 0, scr: 0, kmax: 0.2,
    };
    locate(T, c);
    return c;
  }
  const SURF = [   // grip factor, extra drag (1/s), name
    { g: 1, d: 0, nm: '아스팔트' }, { g: 0.92, d: 0.02, nm: '연석' }, { g: 0.6, d: 0.55, nm: '잔디' }, { g: 0.5, d: 1.1, nm: '자갈' },
  ];
  function surfaceAt(T, c) {
    const a = Math.abs(c.lat), h = T.half;
    if (a < h) return 0;
    if (a < h + 1.3 && T.CU[c.idx]) return 1;
    return T.RO[c.idx] && Math.sign(c.lat) === T.RO[c.idx] && a > h + 1.3 ? 3 : 2;
  }

  /* ======================= 물리 (한 스텝) =======================
     아케이드-시뮬 중간 (docs/HYPERRACE.md 「주행 모델」):
     - 진행 방향(속도의 방향)과 차체 방향을 따로 두고, 둘 사이 각(sa, + = 코가 진행 방향보다 왼쪽)이 미끄러짐 각이에요.
     - 접지 주행: 핸들 → 원하는 옆 가속(속도에 따라 핸들 범위가 줄어 끝까지 꺾어도 접지 한계 근처) → 차체가 무게감 있게 돌고(yawR)
       진행 방향이 차체를 따라감(kS). 앞 접지 한계를 넘으면 바깥으로 밀림(언더스티어 · 속도 깎임).
     - 뒤 접지(제동 하중 이동 · 가속 마찰원 · 핸드브레이크)가 옆 가속을 못 버티면 미끄러짐(dr 0..1, 드리프트)으로 넘어감.
       드리프트 중에는 핸들이 「각도 + 줄」을 정함: 안쪽으로 꺾으면 각이 커지고 줄이 좁아짐, 놓으면 각이 줄며 빠져나옴, 반대로 꺾으면 빨리 끝남.
       주행 보조가 각의 상한 · 복원을 도와 줌(끔이면 지나치면 스핀).
     - 드리프트를 이어 가면 게이지가 차고(c.dc), 깔끔하게 빠져나오면 단계만큼 짧은 가속(드리프트 부스트, c.bst).
     inp = {thr 0..1, brk 0..1, steer -1..1(+ = 왼쪽), hb 0/1}, env = {wet, assist 0 끔 1 일부 2 켬, draft 0..1} */
  const DLV = [0.75, 1.7, 2.9], BST = [0, 0.75, 1.15, 1.6];   // drift charge (s) per level · boost length (s) per level
  function steerK(p, v, aG) {   // path curvature for a full steering input at speed v: lock at low speed, ≈ the grip limit at speed
    const kLock = Math.tan(p.steer) / p.L;
    return v < 1 ? kLock : Math.min(kLock, (aG * p.over) / (v * v));
  }
  function stepCar(T, c, inp, dt, env) {
    const p = phOf(c), wet = env && env.wet ? 0.82 : 1, asst = env ? env.assist | 0 : 1;
    locate(T, c);
    let sf = SURF[(c.surf = surfaceAt(T, c))];
    if (p.off && c.surf >= 2) sf = { g: Math.max(sf.g, p.off), d: sf.d * 0.25 };   // off-road tyres: grass / gravel barely slow them
    if (c.trc > 0 && c.surf >= 2) sf = { g: Math.max(sf.g, 0.85), d: sf.d * 0.4 };   // 아이템 「접지 타이어」
    let v = Math.hypot(c.vf, c.vl);
    const K1 = p.k || 1, K2 = K1 * K1;   // BoP speed factor: the absolute terms below scale with it too (exactly a faster / slower copy of the car)
    const down = (p.cl * v * v) / p.m;                       // downforce as extra g·m/s²
    // crests / dips: the road's vertical curve changes the load (light over a crest, pressed into a dip); fast enough over a crest or a kicker = airborne
    const vk = T.VK ? T.VK[c.idx] || 0 : 0, gK = GRAV * K2;
    if (!c.air && c.vf > 12) {
      const along = Math.cos(c.h - Math.atan2(T.TY[c.idx], T.TX[c.idx]));
      if (T.JL && T.JL[c.idx] && along > 0.5) { c.air = 1; c.zA = roadH(T, c); c.vz = clamp(v * 0.075 * along, 0, 4.5) + v * (T.SL[(c.idx + 3) % T.n] || 0) * 0.5; }   // off a kicker (lift capped: short, safe hops)
      else if (-vk * v * v > 1.15 * gK) { c.air = 1; c.zA = roadH(T, c); c.vz = v * (T.SL[c.idx] || 0) * along; }   // over a sharp crest
    }
    const air = c.air ? 1 : 0;
    const ld = air ? 0.03 : clamp(1 + (v * v * vk) / gK, 0.35, 1.3);
    const aG = p.mu * sf.g * wet * (GRAV + down) * gripK(v) * ld * (c.trc > 0 ? 1.12 : 1);  // tyre grip (m/s²)
    let thr = clamp(inp.thr || 0, 0, 1), brk = clamp(inp.brk || 0, 0, 1);
    const hb = inp.hb ? 1 : 0;
    // steering input with weight (keys / touch are already ramped by the view; this is the rack)
    const sIn = clamp(inp.steer || 0, -1, 1), si0 = c.si || 0;
    const sr = (Math.abs(sIn) < Math.abs(si0) || sIn * si0 < 0 ? 10 : 7) * dt;
    c.si = si0 + clamp(sIn - si0, -sr, sr);
    const kmax = steerK(p, v, aG);
    c.kmax = kmax;
    const kcmd = c.si * kmax;
    // banked corner: turning the way the road leans adds (part of) gravity to the tyres' sideways grip
    const bk = T.BK ? T.BK[c.idx] || 0 : 0, bAid = bk && kcmd * bk > 0 ? GRAV * K2 * Math.abs(bk) * 0.9 : 0;
    c.st = Math.atan(kcmd * p.L);                            // front wheel angle (visual / remote)
    // drive force and traction (traction control with the assists)
    const trac = aG * p.m * (p.awd ? 1 : 0.62);
    const reverse = brk > 0 && c.vf < 0.6 && !thr;
    let Fd = reverse ? (c.vf > -8 ? -brk * p.m * 4.5 : 0) : thr * Math.min(p.P / Math.max(v, 5), trac);
    const want = thr * p.P / Math.max(v, 5);
    c.ws = !reverse && thr > 0.5 ? clamp(want / Math.max(1, trac) - 1, 0, 1) * (v < 22 ? 1 : 0) : 0;   // wheelspin (smoke at launch)
    if (asst) { const cap = (asst === 2 ? 0.72 : 0.88) * trac; if (Fd > cap) { Fd = cap; c.ws *= 0.4; } }
    const u = reverse ? 0 : clamp(Fd / Math.max(1, trac), 0, 1);
    if (c.bst > 0 && !reverse) Fd += p.m * p.bstA * Math.min(1, c.bst / 0.25 + 0.3);
    if (c.slow > 0 && Fd > 0) Fd *= 0.3;   // item hit: the engine chokes for a moment
    if (env && env.pull && !reverse) Fd += p.m * env.pull * K2;   // 슬립 자석
    if (air) { Fd = 0; c.ws = 0; }   // in the air: wheels spin free
    if (reverse) brk = 0;
    // axle grip: braking moves weight forward, throttle uses the driven tyres (friction circle), handbrake locks the rear
    const fc = Math.sqrt(1 - Math.pow(0.5 * brk, 2));
    const kf = (1 + 0.1 * brk) * fc * (p.awd ? 1 - 0.15 * u * u : 1);
    let kr = p.rear * (1 - 0.12 * brk) * fc * (1 - (p.awd ? 0.2 : 0.24) * u * u);
    if (hb) kr *= 0.3;
    kr += asst === 2 ? 0.28 : asst === 1 ? 0.1 : 0;          // stability control
    const aF = aG * kf + bAid, aR = aG * kr + bAid;
    // braking g (ABS), handbrake drag
    const bA = air ? 0 : brk * (p.brake * GRAV * sf.g * wet + down * 0.9) * BRK + (hb && v > 3 ? 2.6 * K2 : 0);
    let sa = 0, aLat = 0, scrub = 0, gu = 0;
    const hbEdge = hb && !c.hbP;
    c.hbP = hb;
    if (v < 3 || (c.vf < 0 && !c.spin)) {
      // low speed / reverse: the car goes where it points
      const wT = (c.vf * c.si * Math.tan(p.steer)) / p.L;
      c.w += (wT - c.w) * (1 - Math.exp(-dt * 14));
      c.h = wrapA(c.h + c.w * dt);
      c.vl *= Math.exp(-dt * 10);
      c.dr = Math.max(0, (c.dr || 0) - dt * 4); c.dc = 0; c.spin = 0;
      let a = (Fd - (0.012 * GRAV * p.m * K2) * Math.sign(c.vf)) / p.m - sf.d * K1 * c.vf - K2 * GRAV * (T.SL[c.idx] || 0) * Math.cos(c.h - Math.atan2(T.TY[c.idx], T.TX[c.idx]));
      const vf1 = c.vf + a * dt;
      if (bA > 0 && vf1 !== 0) { const d = bA * dt; c.vf = Math.abs(vf1) <= d ? 0 : vf1 - Math.sign(vf1) * d; } else c.vf = vf1;
      if (!thr && !brk && Math.abs(c.vf) < 0.4) { c.vf = 0; c.vl *= 0.9; }
      c.ax = a; aLat = c.vf * c.w;
    } else {
      sa = -Math.atan2(c.vl, c.vf);                          // + = nose left of the direction of travel
      let phi = c.h - sa;                                    // direction of travel
      // grip regime
      const aDes = v * v * kcmd, aGl = clamp(aDes, -aF, aF);
      const und = Math.max(0, Math.abs(aDes) / Math.max(1, aF) - 1);
      // into the slide: rear overload, handbrake, or a big slip from outside (a hit)
      let dr = c.dr || 0, dd = c.dd || 1;
      const e = air ? -1 : Math.abs(aGl) / Math.max(1, aR) - 1;
      if (hb && !air && v > 8 && Math.abs(c.si) > 0.15) {
        // which way: a clear steer decides, else the way the car is already turning
        if (dr < 0.3) { dd = Math.abs(c.si) > 0.35 || Math.abs(c.w) < 0.05 ? Math.sign(c.si) : Math.sign(c.w); if (hbEdge || dr < 0.05) c.w += dd * p.hbK * (asst === 0 ? 1.15 : asst === 2 ? 0.75 : 1); }
        dr += dt * 7;
      } else if (e > 0 && v > 10) { if (dr < 0.2) dd = Math.sign(aGl) || dd; dr += Math.min(1, e) * dt * 6; }
      if (Math.abs(sa) > 0.32 && dr < 1) { const k = clamp((Math.abs(sa) - 0.32) / 0.3, 0, 1); if (k > dr) { dr = k; dd = Math.sign(sa); } }
      // drift angle target: steering into the turn holds a bigger angle, letting go straightens, counter-steer ends it
      const into = c.si * dd;
      const hold = into >= 0 ? 0.12 + (p.dA + 0.2 - 0.12) * into : 0.12 * (1 + into);
      const thrK = p.awd ? 0 : asst === 0 ? 0.3 : asst === 1 ? 0.1 : 0;
      const saMax = asst === 0 ? 1.45 : asst === 1 ? 0.95 : 0.72;
      // no assist, rear drive: holding full power into the turn keeps swinging the tail out (lift or counter-steer to catch it)
      c.pw = clamp((c.pw || 0) + (asst === 0 && !p.awd && dr > 0.5 && thr > 0.85 && into > 0.6 ? 0.2 : -0.8) * dt, 0, 0.9);
      let saT = dd * clamp((hold + (thr - 0.5) * thrK + c.pw - brk * 0.08 + (hb ? 0.12 : 0)) * (sf.g < 0.8 ? 0.45 : 1), 0, saMax);   // off the road the slide dies out
      // way past the limit with no assist = spin
      if (asst === 0 && Math.abs(sa) > 1.25 && dr > 0.5) c.spin = 1;
      if (c.spin) { saT = Math.sign(sa) * Math.PI; if (v < 6 || Math.abs(sa) > 2.8) { c.spin = 0; dr = 0; } }
      // out of the slide: nearly straight again and nothing keeps it going
      const eNow = (Math.abs(c.alat || 0) * (c.alat * dd > 0 ? 1 : 0)) / Math.max(1, aR) - 1;   // the slide itself still overloads the rear
      const keep = hb || (Math.min(e, eNow) > (asst ? 0.1 : 0.02) && into > -0.3);
      if (!keep && (Math.abs(sa) < 0.17 || sa * dd < 0)) dr -= dt * (sa * dd < 0 ? 7 : asst === 2 ? 5 : 3.5);
      if (v < 12) dr -= dt * (v < 7 ? 5 : 2);
      dr = clamp(dr, 0, 1);
      c.dd = dd;
      // path (direction of travel) turning rate and yaw target, grip ↔ slide blend
      const saG = clamp(aGl / aG, -1.2, 1.2) * p.nose;
      const wTg = aGl / v;
      const wcg = clamp(c.w + p.kS * (sa - saG), -aF / v, aF / v);
      const aDr = c.spin ? 0 : dd * aG * p.dG * (into >= 0 ? 0.62 + 0.38 * into : 0.62 + 0.4 * into) * Math.min(1, Math.abs(sa) / 0.2);
      const wcd = aDr / v + (Fd / p.m) * Math.sin(sa) * 0.5 / v;   // throttle pushes the nose's way
      const wTd = wcd + p.kD * (asst === 0 ? 0.85 : 1) * (wrapA(saT - sa));
      const wc = wcg + (wcd - wcg) * dr, wT = wTg + (wTd - wTg) * dr;
      c.w += (wT - c.w) * (1 - Math.exp(-dt * p.yawR * (c.spin ? 0.15 : 1)));
      c.h = wrapA(c.h + c.w * dt);
      phi += wc * dt;
      aLat = wc * v;
      gu = Math.abs(aLat) / aG;
      // speed along the path: drive (along the nose), drag, slope, scrub from pushing / sliding
      const cd = p.P / (p.vtop * p.vtop * p.vtop) * (c.bst > 0 ? 0.8 : 1);
      const drag = cd * (1 - DRAFT_K * (env && env.draft || 0)) * v * v + p.m * 0.012 * GRAV * K2;
      scrub = Math.min(1.5, und) * 3.2 * K2 + dr * aG * p.dS * Math.abs(Math.sin(sa)) + (c.spin ? aG * 0.55 : 0) + 0.02 * Math.abs(aLat);
      const slope = K2 * GRAV * (T.SL[c.idx] || 0) * Math.cos(phi - Math.atan2(T.TY[c.idx], T.TX[c.idx]));
      const Fs = Fd * (1 - (p.awd ? 0.6 : 0.45) * dr * Math.abs(Math.sin(sa)));   // spinning tyres in a slide push less
      let a = (Fs * Math.cos(sa) - drag) / p.m - sf.d * K1 * v - slope - scrub - (c.slow > 0 && v > 8 ? 2.2 * K2 : 0);
      const v1 = v + a * dt;
      v = Math.max(0, v1 - bA * dt);
      c.ax = a - bA;
      const s2 = wrapA(c.h - phi);
      c.vf = v * Math.cos(s2); c.vl = -v * Math.sin(s2);
      sa = s2;
      // drift charge → boost when the slide ends cleanly
      if (dr > 0.6 && Math.abs(sa) > 0.2 && v > 12 && sf.g > 0.9 && !c.spin) {
        c.dc = (c.dc || 0) + dt * Math.min(1, v / 25);
        const lv = c.dc >= DLV[2] ? 3 : c.dc >= DLV[1] ? 2 : c.dc >= DLV[0] ? 1 : 0;
        if (lv > (c.dlv || 0)) { c.dlv = lv; c.ev = 'dlv'; }
      }
      if ((c.dr || 0) >= 0.2 && dr < 0.2) {
        const lv = c.dlv || 0;
        if (lv && Math.abs(sa) < 0.4 && !c.spin && sf.g > 0.9 && v > 10) { c.bst = Math.max(c.bst || 0, BST[lv]); c.blv = lv; c.ev = 'boost'; }
        c.dc = 0; c.dlv = 0;
      }
      if (c.spin) { c.dc = 0; c.dlv = 0; }
      c.dr = dr;
    }
    if (c.bst > 0) c.bst = Math.max(0, c.bst - dt);
    c.sa = sa; c.gu = gu; c.alat = aLat;
    c.slip = Math.max((c.dr || 0) * Math.min(1, Math.abs(sa) * 2.2), clamp((gu - 0.88) * 3, 0, 0.35), c.ws * 0.9, hb && v > 5 ? 0.45 : 0, scrub > 1.5 ? 0.3 : 0);
    c.thr = thr; c.brk = brk; c.hb = hb;
    // move
    const ch = Math.cos(c.h), sh = Math.sin(c.h);
    c.x += (c.vf * ch - c.vl * sh) * dt;
    c.y += (c.vf * sh + c.vl * ch) * dt;
    const hit = walls(T, c);
    if (hit > 6) { c.dc = 0; c.dlv = 0; }   // a light scrape keeps the drift charge
    // flight: ballistic height until the road comes back up under the car (landing on a calm stretch — a small dip of speed only when it lands hard)
    if (c.air) {
      c.vz -= GRAV * K2 * dt; c.zA += c.vz * dt;
      const rh = roadH(T, c);
      if (c.zA <= rh) {
        const vRoad = Math.max(0, c.vf) * (T.SL[c.idx] || 0), imp = Math.max(0, vRoad - c.vz);
        c.air = 0; c.zA = rh; c.land = imp;
        if (imp > 3) { const k = 1 - Math.min(0.08, (imp - 3) * 0.012); c.vf *= k; c.vl *= k; }
      } else if (c.zA - rh > 12 || Math.abs(c.lat) > T.half + T.run) c.zA = Math.min(c.zA, rh + 12);
    }
    // boost pads (「아케이드 요소」)
    if (T.PADI && !c.air) {
      const pl = T.PADI[c.idx];
      if (pl != null && Math.abs(c.lat - pl) < 2.3 && !(c.padT > 0)) { c.bst = Math.max(c.bst || 0, 0.9); c.blv = Math.max(1, c.blv || 0); c.padT = 0.8; c.ev = 'pad'; }
    }
    if (c.padT > 0) c.padT -= dt;
  }
  /* road height under a car (between samples, no banking) */
  function roadH(T, c) {
    const n = T.n, i = c.idx, f = clamp((c.along || 0) / DS, -1, 1), j = (i + (f >= 0 ? 1 : -1) + n) % n;
    return T.H[i] + (T.H[j] - T.H[i]) * Math.abs(f);
  }
  /* barrier at ±(half + run): push back, bounce a little, scrape speed, align with the wall — never a dead stop */
  function walls(T, c) {
    locate(T, c);
    const i = c.idx, D = T.WD && T.WD[i] ? T.WD[i] : T.half + T.run, rel = wrapA(c.h - Math.atan2(T.TY[i], T.TX[i]));
    const ext = 1.0 * Math.abs(Math.cos(rel)) + 2.25 * Math.abs(Math.sin(rel));
    const o = Math.abs(c.lat) + ext - D;
    if (o <= 0) return 0;
    const sgn = Math.sign(c.lat), nx = -T.TY[i] * sgn, ny = T.TX[i] * sgn;   // outward normal
    c.x -= nx * o; c.y -= ny * o; c.lat -= sgn * o;
    const ch = Math.cos(c.h), sh = Math.sin(c.h);
    let vx = c.vf * ch - c.vl * sh, vy = c.vf * sh + c.vl * ch;
    const vn = vx * nx + vy * ny;
    // scraping along the wall: where (for sparks) and how fast
    c.scr = Math.max(c.scr || 0, Math.hypot(vx, vy)); c.hx = c.x + nx * ext; c.hy = c.y + ny * ext;
    if (vn > 0) {
      // a glancing touch (small speed into the wall) only loses that bit: slide along it and keep going (불쾌감 줄이기 — 2026-11-17);
      // a real hit bounces a little and costs up to 30%
      const glance = vn < 3.5;
      vx -= (glance ? 1.05 : 1.2) * vn * nx; vy -= (glance ? 1.05 : 1.2) * vn * ny;
      const k = 1 - Math.min(0.3, Math.max(0, vn - 2.5) * 0.026);
      vx *= k; vy *= k;
      c.vf = vx * ch + vy * sh; c.vl = -vx * sh + vy * ch;
      c.w = c.w * (glance ? 0.7 : 0.4) - clamp(rel, -0.6, 0.6) * (glance ? 0.6 : 1.2);   // turn along the wall
      c.hit = Math.max(c.hit, vn);
    }
    return vn;
  }
  /* car vs car: three circles each; equal-ish masses; `soloA` = only A moves (the other is a remote car) */
  const CR = 1.02, COFF = [-1.38, 0, 1.38];
  function collide(A, B, soloA, soloB, soft) {   // soft: a gentler touch (the start, a person vs an AI) — no punts, no spins
    if (A.ghost > 0 || B.ghost > 0) return 0;
    if (A.air || B.air || (A.zA != null && B.zA != null && Math.abs((A.zA || 0) - (B.zA || 0)) > 3 && (A.air || B.air))) return 0;
    const dx0 = A.x - B.x, dy0 = A.y - B.y;
    if (dx0 * dx0 + dy0 * dy0 > 36) return 0;
    let best = null;
    const ca = Math.cos(A.h), sa = Math.sin(A.h), cb = Math.cos(B.h), sb = Math.sin(B.h);
    for (const oa of COFF) for (const ob of COFF) {
      const ax = A.x + ca * oa, ay = A.y + sa * oa, bx = B.x + cb * ob, by = B.y + sb * ob;
      const dx = ax - bx, dy = ay - by, d = Math.hypot(dx, dy), pen = 2 * CR - d;
      if (pen > 0 && (!best || pen > best.pen)) best = { pen, nx: d > 1e-6 ? dx / d : 1, ny: d > 1e-6 ? dy / d : 0, oa, ob };
    }
    if (!best) return 0;
    const ma = clamp(phOf(A).m, 800, 2400), mb = clamp(phOf(B).m, 800, 2400);   // a 5 t truck still pushes, but not like a wall
    let wa = mb / (ma + mb), wb = ma / (ma + mb);
    if ((A.shd > 0) !== (B.shd > 0)) { if (A.shd > 0) { wa *= 0.35; wb = 1 - wa; } else { wb *= 0.35; wa = 1 - wb; } }   // 충격 범퍼: barely pushed
    if (soloA) { wa = 1; wb = 0; } if (soloB) { wa = 0; wb = 1; }
    A.x += best.nx * best.pen * wa; A.y += best.ny * best.pen * wa;
    B.x -= best.nx * best.pen * wb; B.y -= best.ny * best.pen * wb;
    const vA = [A.vf * ca - A.vl * sa, A.vf * sa + A.vl * ca], vB = [B.vf * cb - B.vl * sb, B.vf * sb + B.vl * cb];
    const vr = (vA[0] - vB[0]) * best.nx + (vA[1] - vB[1]) * best.ny;
    if (vr < 0) {
      const j = -(soft ? 1.12 : 1.3) * vr;   // restitution ≈ 0.3 (soft 0.12)
      vA[0] += best.nx * j * wa; vA[1] += best.ny * j * wa; vB[0] -= best.nx * j * wb; vB[1] -= best.ny * j * wb;
      A.vf = vA[0] * ca + vA[1] * sa; A.vl = -vA[0] * sa + vA[1] * ca;
      B.vf = vB[0] * cb + vB[1] * sb; B.vl = -vB[0] * sb + vB[1] * cb;
      // a light spin from off-centre hits (capped so a tap never spins you round)
      const ta = (best.oa * (best.ny * ca - best.nx * sa)) * j * 0.05, tb = (best.ob * (best.ny * cb - best.nx * sb)) * j * 0.05;
      const tk = soft ? 0.2 : 0.5;
      A.w += clamp(ta, -tk, tk) * wa; B.w -= clamp(tb, -tk, tk) * wb;
      A.hit = Math.max(A.hit, -vr); B.hit = Math.max(B.hit, -vr);
      const cx = (A.x + B.x) / 2, cy = (A.y + B.y) / 2; A.hx = B.hx = cx; A.hy = B.hy = cy;
      if (-vr > 4) { A.dc = B.dc = 0; A.dlv = B.dlv = 0; }
    }
    return -vr;
  }
  /* slipstream: a car close behind another (≤ 45 m, nearly the same line) loses up to 42% of its drag (2026-11-16: 32 m · 32% → 45 m · 42%, 접전) */
  const DRAFT_L = 45, DRAFT_K = 0.42;
  function draftFor(T, c, cars) {
    let best = 0;
    const ch = Math.cos(c.h), sh = Math.sin(c.h);
    for (const o of cars) {
      if (o === c) continue;
      const dx = o.x - c.x, dy = o.y - c.y, fw = dx * ch + dy * sh, sd = Math.abs(-dx * sh + dy * ch);
      if (fw > 4 && fw < DRAFT_L && sd < 3 && Math.abs(o.vf) > 18) best = Math.max(best, (1 - fw / DRAFT_L) * (1 - sd / 3) * 1.7);
    }
    return clamp(best, 0, 1);
  }
  /* lap progress (call after each step) — returns 'lap' | 'fin' | null */
  function progress(T, c, now, laps) {
    const n = T.n, i = c.idx;
    const prev = c.pi == null ? i : c.pi;
    c.pi = i;
    if (c.fin) return null;
    if (c.lap === 0) {   // on the grid: the first crossing starts lap 1
      if (prev > n * 0.75 && i < n * 0.25) { c.lap = 1; c.maxI = 0; c.lapStart = now; return 'start'; }
    } else {
      if (i > c.maxI && i - c.maxI < n * 0.3) c.maxI = i;
      if (prev > n * 0.75 && i < n * 0.25 && c.maxI > n * 0.6) {
        const lt = now - c.lapStart; c.laps.push(Math.round(lt * 100) / 100);
        if (!c.best || lt < c.best) c.best = lt;
        c.lapStart = now; c.maxI = 0; c.lap++;
        if (c.lap > laps) { c.fin = 1; c.finT = now; return 'fin'; }
        return 'lap';
      }
    }
    // wrong way: driving against the track direction
    const td = Math.atan2(T.TY[i], T.TX[i]), vdir = Math.atan2(c.vf * Math.sin(c.h) + c.vl * Math.cos(c.h), c.vf * Math.cos(c.h) - c.vl * Math.sin(c.h));
    c.wrong = Math.abs(c.vf) > 4 && Math.abs(wrapA(vdir - td)) > 2.1 ? 1 : 0;
    c.prog = c.lap === 0 ? -(n - i) / n : (c.lap - 1) + (c.maxI > n * 0.6 && i < n * 0.25 ? c.maxI : i) / n;
    return null;
  }
  function ranking(cars) {
    return cars.slice().sort((a, b) => (b.fin ? 1 : 0) - (a.fin ? 1 : 0) || (a.fin && b.fin ? a.finT - b.finT : 0) || (b.prog - a.prog) || a.seat - b.seat);
  }
  function resetToTrack(T, c) {   // put the car back on the racing surface, facing the right way, briefly ghosted
    locate(T, c);
    const i = c.idx, lat = clamp(c.lat, -(T.half - 2), T.half - 2);
    c.x = T.X[i] - T.TY[i] * lat; c.y = T.Y[i] + T.TX[i] * lat; c.h = Math.atan2(T.TY[i], T.TX[i]);
    c.vf = 9; c.vl = 0; c.w = 0; c.st = 0; c.si = 0; c.dr = 0; c.dc = 0; c.dlv = 0; c.spin = 0; c.bst = 0; c.ghost = 3; c.stuck = 0; c.air = 0; c.slow = 0;
  }

  /* ======================= 아이템 (「아케이드 요소」 켬, docs/HYPERRACE.md 「아이템」) =======================
     트랙의 아이템 상자 줄(T.IB)을 지나가면 하나를 받아요(손에 하나만 — 들고 있으면 상자를 그냥 지나침, 상자는 3초 뒤 다시 생김).
     뒤에 있을수록 센 아이템이 잘 나와요(따라잡기). 맞으면 짧게 느려질 뿐(최대 1초 · 스핀 없음), 맞은 뒤 2.6초는 다시 안 맞아요.
     결정적: 뽑기는 (씨앗 · 자리 · 몇 번째)로 정한 씨앗 난수, AI는 상황 점수 + 봇 버릇.
     온라인: 자기 차를 시뮬하는 기기가 줍기 · 쓰기 · 맞기를 정하고, 놓은 것(기름 · 연막)과 남을 맞힌 것(방해 전파)은 id를 붙여 보내요(view.js). */
  const ITEMS = [null,
    { id: 'nitro', nm: '니트로', col: '#ff8a3d', w: [0.4, 2.6], d: '1.5초 동안 강하게 가속해요(드리프트 부스트보다 셈).' },
    { id: 'oil', nm: '기름 웅덩이', col: '#b48cff', w: [2.2, -1.2], foe: 1, d: '차 뒤에 기름을 흘려요(8초). 밟은 차는 1초 동안 살짝 미끄러지며 느려져요.' },
    { id: 'jam', nm: '방해 전파', col: '#5ad1ff', w: [0.2, 1.4], foe: 1, d: '바로 앞차(150m 안)의 엔진을 0.9초 동안 약하게 해요. 앞차가 없으면 쓰이지 않아요.' },
    { id: 'grip', nm: '접지 타이어', col: '#ffcf5a', w: [1.8, -0.8], d: '6초 동안 접지 +12% · 잔디 · 자갈에서 덜 느려지고 기름에 안 미끄러져요.' },
    { id: 'shield', nm: '충격 범퍼', col: '#8cff9a', w: [2.0, -1.0], d: '8초 동안 방해를 한 번 막아 주고, 부딪혀도 덜 밀려요.' },
    { id: 'smoke', nm: '연막', col: '#c8ccd4', w: [1.4, -0.6], foe: 1, d: '차 뒤에 연기 구름(6초). 지나는 차는 앞이 잘 안 보이고 슬립스트림을 못 받아요.' },
    { id: 'mag', nm: '슬립 자석', col: '#3fe6ff', w: [0.1, 2.2], foe: 1, d: '5초 동안 앞차(120m 안)의 슬립스트림을 가장 세게 받고 살짝 끌려가요.' },
  ];
  const IT = { roll: 0.9, nitro: 1.5, oilS: 1.0, jamS: 0.9, imm: 2.6, grip: 6, shd: 8, mag: 5, oilR: 2.4, oilL: 8, smkR: 6.5, smkL: 6, respawn: 3, jamR: 150, magR: 120 };
  const ITK = { oil: 1, smoke: 2, jam: 3 };   // wire codes
  /* the car just ahead / behind by race distance (m) — [car, gap] or null */
  function carNear(W, c, range, dir) {
    let best = null, bd = range;
    for (const o of W.cars) {
      if (o === c || o.fin || o.ghost > 0) continue;
      const d = (o.prog - c.prog) * W.T.len * dir;
      if (d > 2 && d < bd) { bd = d; best = o; }
    }
    return best ? [best, bd] : null;
  }
  /* item from a box: weighted by place — the leader mostly gets defence, the back of the field the strong stuff */
  function itemRoll(W, c) {
    const n = W.cars.length, pos = ranking(W.cars).indexOf(c), r = n > 1 ? pos / (n - 1) : 0.5;
    const rnd = prng(((W.seed | 0) % 1000003) * 7 + c.seat * 131 + (c.itN | 0) * 977 + 3);
    const w = ITEMS.map((it) => (it ? (n < 2 && it.foe ? 0 : Math.max(0, it.w[0] + it.w[1] * r)) : 0));
    let q = rnd() * w.reduce((a, b) => a + b, 0);
    for (let k = 1; k < w.length; k++) { q -= w[k]; if (q <= 0) return k; }
    return 1;
  }
  /* a hazard on the track (oil / smoke): placed here or received from another device (wire = [id, kind, x, y, life left, owner]) */
  function addHazard(W, a) {
    if (!W || !Array.isArray(a) || !(W.hzIds || (W.hzIds = {}))) return null;
    const id = a[0], k = a[1] === ITK.smoke ? 'smoke' : 'oil';
    if (W.hzIds[id] || !fin(a[2]) || !fin(a[3]) || !(a[4] > 0)) return null;
    W.hzIds[id] = 1;
    const z = { id, k, x: a[2], y: a[3], r: k === 'oil' ? IT.oilR : IT.smkR, end: W.t + Math.min(a[4], k === 'oil' ? IT.oilL : IT.smkL), own: a[5] | 0, t0: W.t - ((k === 'oil' ? IT.oilL : IT.smkL) - a[4]), idx: 0 };
    locate(W.T, z);
    W.hz.push(z);
    return z;
  }
  /* an item hit on a car simulated here: a short slowdown (never a spin) unless immune / shielded / grip tyres in oil */
  function itemHit(W, c, k) {
    if (!c || c.fin || c.ghost > 0 || c.imm > 0) return 0;
    if (k === 'oil' && c.trc > 0) return 0;
    if (c.shd > 0) { c.shd = 0; c.imm = 1; W.ev.push({ k: 'iblk', seat: c.seat }); return 0; }
    c.slow = k === 'oil' ? IT.oilS : IT.jamS; c.slK = k === 'oil' ? 2 : 3; c.imm = IT.imm; c.dc = 0; c.dlv = 0;
    if (k === 'oil' && c.vf > 8) { const s = c.lat >= 0 ? -1 : 1; c.w += s * 0.25; c.vl += s * 0.5; }   // a brief wiggle
    W.ev.push({ k: 'ihit', seat: c.seat, it: k });
    return 1;
  }
  /* use the held item (local car) → 1 when used */
  function useItem(W, c, local) {
    const it = c.it | 0; if (!it || c.itR > 0 || c.fin) return 0;
    const id = ITEMS[it].id, ch = Math.cos(c.h), sh = Math.sin(c.h), nid = () => c.seat * 100000 + (c.hzN = ((c.hzN | 0) + 1) % 100000);
    if (id === 'jam') {
      const a = carNear(W, c, IT.jamR, 1); if (!a) { W.ev.push({ k: 'inone', seat: c.seat }); return 0; }   // nothing ahead: keep it
      const t = a[0], hid = nid();
      W.ev.push({ k: 'zap', seat: c.seat, o: t.seat, id: hid });
      if (local(t.seat)) itemHit(W, t, 'jam'); else W.out.push({ id: hid, to: t.seat, k: ITK.jam, from: c.seat, t: W.t });
    } else if (id === 'oil' || id === 'smoke') {
      const back = id === 'oil' ? 5.5 : 4.5, L0 = id === 'oil' ? IT.oilL : IT.smkL;
      const a = [nid(), ITK[id], Math.round((c.x - ch * back) * 100) / 100, Math.round((c.y - sh * back) * 100) / 100, L0, c.seat];
      if (addHazard(W, a)) W.hzOut.push({ a, t: W.t });
    } else if (id === 'nitro') { c.bst = Math.max(c.bst || 0, IT.nitro); c.blv = 3; }
    else if (id === 'grip') c.trc = IT.grip;
    else if (id === 'shield') c.shd = IT.shd;
    else if (id === 'mag') c.mag = IT.mag;
    c.it = 0; W.ev.push({ k: 'use', seat: c.seat, it });
    return 1;
  }
  /* item boxes: crossing a row picks up the box under the car (local cars get an item; a remote car only knocks the box out here, for the picture) */
  function boxStep(W, c, isLocal) {
    const T = W.T, n = T.n, p = c.ibI == null ? c.idx : c.ibI, q = c.idx; c.ibI = q;
    const step = (q - p + n) % n; if (!step || step > 30 || c.air) return;
    for (let r = 0; r < T.IB.length; r++) {
      const bi = T.IB[r][0], lats = T.IB[r][1], d = (bi - p + n) % n; if (d === 0 || d > step) continue;
      for (let j = 0; j < lats.length; j++) {
        if (W.ibT[r][j] > W.t || Math.abs(c.lat - lats[j]) > 1.75) continue;
        if (isLocal) {
          if (c.it || c.itR > 0 || c.fin) continue;   // already holding one: drive through, the box stays for the others
          c.itN = (c.itN | 0) + 1; c.it = itemRoll(W, c); c.itR = IT.roll; c.itGot = W.t;
          W.ev.push({ k: 'ibox', seat: c.seat, it: c.it });
        } else if (c.itF) continue;
        W.ibT[r][j] = W.t + IT.respawn;
        break;
      }
    }
  }
  /* per local car each step: timers, hazards under it */
  function itemTick(W, c, h) {
    for (const k of ['itR', 'slow', 'imm', 'trc', 'shd', 'mag', 'smk']) if (c[k] > 0) c[k] = Math.max(0, c[k] - h);
    if (!W.hz.length || c.fin) return;
    for (const z of W.hz) {
      if (z.end <= W.t) continue;
      const dx = c.x - z.x, dy = c.y - z.y, rr = z.r + 0.9;
      if (dx * dx + dy * dy > rr * rr) continue;
      if (z.k === 'smoke') { if (z.own !== c.seat) c.smk = 0.3; }
      else if (!(z.own === c.seat && W.t - z.t0 < 2.5) && !c.air) itemHit(W, c, 'oil');
    }
  }
  /* an oil puddle ahead on (about) this line within d m */
  function oilAhead(W, c, d) {
    const T = W.T, n = T.n;
    for (const z of W.hz) { if (z.k !== 'oil' || z.end <= W.t) continue; const g = ((z.idx - c.idx + n) % n) * DS; if (g > 3 && g < d && Math.abs(z.lat - c.lat) < 3.2) return z; }
    return null;
  }
  /* AI: use the held item when the situation is right (scores × this bot's habits; 쉬움 muddles the timing, 어려움 waits for the best moment) */
  function aiItem(T, c, W, lv, hb) {
    const it = c.it | 0; if (!it || c.itR > 0 || c.fin || W.t < 1.5) return 0;
    const id = ITEMS[it].id, held = W.t - (c.itGot || 0), n = T.n, sp = Math.max(0, c.vf), p = phOf(c);
    const pat = held / ((lv === 1 ? 2.5 : 7) + (hb.itp || 0.5) * (lv === 1 ? 3 : 9));   // held too long → use it anyway
    const ahead = carNear(W, c, 160, 1), behind = carNear(W, c, 60, -1);
    let kx = 0; for (let q = 0; q < 18; q++) kx = Math.max(kx, Math.abs(T.K[(c.idx + q) % n]));
    const straight = kx < 1 / 260;
    let s = 0;
    if (id === 'nitro') s = (straight ? 0.9 : 0.1) + (sp < p.vtop * 0.8 ? 0.3 : 0) - (c.bst > 0 || c.air ? 2 : 0);
    else if (id === 'oil') s = behind && behind[1] < 35 && Math.abs(behind[0].lat - c.lat) < 2.8 ? 1.1 : 0;
    else if (id === 'smoke') s = behind && behind[1] < 30 ? 1 : 0;
    else if (id === 'jam') s = ahead ? (ahead[1] < (lv === 3 ? 70 : 150) && !(ahead[0].shd > 0 && lv >= 2) ? 1 : 0.3) : -20;
    else if (id === 'mag') s = ahead && ahead[1] > 15 && ahead[1] < 120 ? (straight ? 1.1 : 0.6) : -20;
    else if (id === 'grip') { let k2 = 0; for (let q = 3; q < 26; q++) k2 = Math.max(k2, Math.abs(T.KL[(c.idx + q) % n])); s = (k2 > 1 / 70 ? 0.9 : 0.15) + (W.wet ? 0.3 : 0) + (oilAhead(W, c, 40) ? 0.8 : 0); }
    else if (id === 'shield') s = (behind && behind[1] < 22 ? 0.6 : 0) + (oilAhead(W, c, 40) ? 1 : 0);
    if (lv === 1) s += 0.35 * Math.sin(W.t * (0.7 + (hb.item || 0.5)) + hb.wob);   // 쉬움: muddled timing
    const th = lv === 1 ? 0.6 + (hb.item || 0.5) * 0.3 : lv === 2 ? 0.85 + (hb.item || 0.5) * 0.2 : 0.95;
    return s + pat * (lv === 3 ? 0.35 : 0.6) > th ? 1 : 0;
  }

  /* ======================= AI =======================
     레이싱 라인 + 차별 속도표를 따라가되, 판단은 모두 상황 점수 + 봇마다 다른(씨앗) 버릇으로:
     제동 시점(늦게/일찍) · 공격성(추월 시도 거리 · 옆에 붙는 정도) · 라인 치우침 · 실수(쉬움)… 고정 규칙 없음. */
  function habits(seed, seat) {
    const r = prng(seed * 31 + seat * 977 + 5);
    return { brake: 0.985 + r() * 0.03, aggr: 0.3 + r() * 0.7, line: (r() - 0.5) * 0.9, look: 0.9 + r() * 0.25, nerve: r(), wob: r() * 6.28, defend: r(), drift: r(), smooth: r(), item: r(), itp: r() };
  }
  const SKILL = [0, 0.86, 0.93, 0.985];
  /* 접전(옵션 pack, 기본 켬): AI가 가장 앞선 사람과 멀리 떨어지면 아주 조금 늦추거나(앞선 AI) 한계 가까이 몰아붙여(뒤처진 AI) 무리를 이뤄요.
     최대 −4% / +3%(어려움은 절반), 30m 안은 그대로 — 차 성능은 그대로이고 AI의 페이스만. 사람이 없거나 끄면 1. */
  function packPace(T, c, W, lv) {
    if (!W || !W.pack || !W.hum || !W.hum.length || c.fin || !c.lap) return 1;
    let hp = -1e9;
    for (const s of W.hum) { const h = W.cars[s]; if (h && !h.fin && h.seat !== c.seat) hp = Math.max(hp, h.prog); }
    if (hp < -1e8) return 1;
    const gap = (c.prog - hp) * T.len, k = lv === 3 ? 0.5 : 1;   // + = this AI is ahead of the best person (m)
    return gap > 0 ? 1 - 0.04 * k * clamp((gap - 30) / 260, 0, 1) : 1 + 0.03 * k * clamp((-gap - 30) / 260, 0, 1);
  }
  function aiInput(T, c, cars, lv, hb, now, wet, W) {
    lv = lv || 2;
    const p = phOf(c), n = T.n, sp = Math.max(0, c.vf), prof = speedProfile(T, c, wet);
    const st = c.ai || (c.ai = { lane: 0, laneT: 0, mist: 0, mistT: 2 + (hb.nerve * 5) });
    // overtaking / defending: look at cars close ahead on track
    let ahead = null, ad = 1e9, behind = null, bd = 1e9;
    for (const o of cars) {
      if (o === c || o.fin) continue;
      let d = (o.idx - c.idx + n) % n; if (d > n / 2) d -= n;
      const dm = d * DS;
      if (dm > 0 && dm < 40 && dm < ad) { ad = dm; ahead = o; }
      if (dm < 0 && dm > -25 && -dm < bd) { bd = -dm; behind = o; }
    }
    const lim = T.half - 1.6;
    let laneT = 0;
    if (ahead) {
      const rel = sp - Math.max(0, ahead.vf);
      // a situational score: closing speed, gap, nerve, how calm the road ahead is
      let calm = 0; for (let k = 0; k < 20; k++) calm += Math.abs(T.K[(c.idx + k * 3) % n]); calm = 1 - clamp(calm * 18, 0, 1);
      const want = (rel * 0.12 + (1 - ad / 40) * 0.8) * (0.5 + hb.aggr) * (0.6 + calm * 0.6) - (lv === 1 ? 0.25 : 0) + (ahead.vf < 10 ? 2 : 0);   // a slow or stopped car ahead: always go round it
      if (want > 0.35) {
        const side = ahead.lat - T.OFF[ahead.idx] > c.lat - T.OFF[c.idx] ? -1 : 1;   // go round the side it isn't on
        const room = side > 0 ? lim - ahead.lat : lim + ahead.lat;
        laneT = room > 2.4 ? side * clamp(2.6 + hb.aggr * 1.2, 0, lim) : -side * clamp(2.4, 0, lim);
      }
    } else if (behind && lv >= 2 && hb.defend > 0.5) {
      const k = (25 - bd) / 25 * (hb.defend - 0.5) * 2;
      laneT = clamp((behind.lat - T.OFF[c.idx]) * 0.5 * k, -1.8, 1.8);
    }
    st.lane += (laneT - st.lane) * 0.04;
    // target point (pure pursuit on the direction of travel, so it also works while sliding)
    const v = Math.hypot(c.vf, c.vl), look = (7 + sp * 0.55 * hb.look);
    const j = (c.idx + Math.max(2, Math.round(look / DS))) % n;
    const off = clamp(T.OFF[j] * (lv === 1 ? 0.6 : 1) + hb.line + st.lane, -lim, lim);
    const tx = T.X[j] - T.TY[j] * off, ty = T.Y[j] + T.TX[j] * off;
    const phi = v > 3 && c.vf > 0 ? c.h - (c.sa || 0) : c.h;
    const ang = wrapA(Math.atan2(ty - c.y, tx - c.x) - phi);
    const dist = Math.hypot(tx - c.x, ty - c.y);
    const kap = (2 * Math.sin(ang)) / Math.max(4, dist);
    let steer;
    if ((c.dr || 0) > 0.5 && v > 6) {   // sliding: the stick sets the line (into = tighter, counter = wider / out)
      const aGe = ((c.kmax || 0.1) * v * v) / p.over, need = ((kap * v * v) / Math.max(1, aGe * p.dG)) * (c.dd || 1);
      const into = need >= 0.62 ? (need - 0.62) / 0.38 : (need - 0.62) / 0.4;
      // leave the slide once the corner opens (a deliberate counter-steer, not a twitch)
      let k = 0; for (let q = 2; q < 7; q++) k = Math.max(k, Math.abs(T.KL[(c.idx + q) % n]));
      steer = (c.dd || 1) * clamp(k < 1 / 70 ? Math.min(into, -0.5) : into, -1, 1);
    } else steer = clamp(kap / Math.max(1e-4, c.kmax || 0.2), -1, 1);
    // drift into hairpins (situational score × this bot's habit; harder bots more often and better timed)
    let hbOn = 0;
    if (lv >= 2 && sp > 14 && !(c.dr > 0.3)) {
      let kx = 0, at = 0; for (let q = 3; q < 12; q++) { const kk = Math.abs(T.KL[(c.idx + q) % n]); if (kk > kx) { kx = kk; at = q; } }
      const score = (kx * 46 - 1) * (lv === 3 ? 1 : 0.6) + (hb.drift - 0.55) * 1.2 - (wet ? 0.3 : 0) - (ahead && ad < 12 ? 0.6 : 0);
      if (score > 0 && at <= 5 + Math.round(sp / 12) && Math.sign(T.KL[(c.idx + at) % n]) === Math.sign(steer || 1)) hbOn = 1;
    }
    if (st.hbT > 0) { st.hbT -= 1 / 30; hbOn = 1; } else if (hbOn) st.hbT = 0.2 + hb.smooth * 0.15;
    // mistakes (쉬움 more): a wobble and the odd late brake
    if (lv === 1) steer += Math.sin(now * 0.9 + hb.wob) * 0.07;
    st.mistT -= 1 / 30;
    if (st.mistT <= 0) { st.mistT = 3 + hb.nerve * 6; st.mist = lv === 1 ? 0.8 + hb.nerve * 0.8 : lv === 2 && hb.nerve > 0.75 ? 0.4 : 0; }
    // speed: the slowest target over the next stretch (braking is already in the profile)
    const skill = SKILL[lv] * hb.brake * (st.mist > 0 ? 1.06 : 1);
    if (st.mist > 0) st.mist -= 1 / 30;
    let vt = 1e9; for (let k = 0; k < 4; k++) vt = Math.min(vt, prof[(c.idx + k) % n]);
    vt *= skill * packPace(T, c, W, lv);
    if (c.lap === 0 && now < 0) vt = 0;
    // don't run into the car right ahead on the same line (a person most of all): match its speed until there is room to pass
    if (ahead && Math.abs(ahead.lat - c.lat) < 2.4) {
      const close = sp - Math.max(0, ahead.vf), hum = W && W.hum && W.hum.indexOf(ahead.seat) >= 0;
      if (close > 0 && ad < 6 + close * (hum ? 1.6 : 1.1)) vt = Math.min(vt, Math.max(ahead.vf < 10 ? 7 : 0, Math.max(0, ahead.vf) - (hum ? 0.5 : 0)));   // (a stopped car: crawl past it, never wait behind it)
    }
    // 「아케이드 요소」: line up a boost pad coming up on this side
    if (T.PADI) for (let q = 4; q < 16; q++) { const pl = T.PADI[(c.idx + q) % n]; if (pl != null) { st.lane += ((pl - (T.OFF[c.idx] + hb.line)) * 0.6 - st.lane) * 0.05; break; } }
    if (W && W.items) {
      // empty hands (보통 · 어려움): drift towards the nearest box of the next row
      if (lv >= 2 && !c.it && !(c.itR > 0)) for (const [bi, lats] of T.IB) {
        const g = ((bi - c.idx + n) % n) * DS; if (g < 8 || g > 45) continue;
        const r = T.IB.findIndex((b) => b[0] === bi); let bl = null, bd = 1e9;
        lats.forEach((l, j) => { if (W.ibT[r][j] <= W.t + g / Math.max(10, sp) && Math.abs(l - c.lat) < bd) { bd = Math.abs(l - c.lat); bl = l; } });
        if (bl != null) st.lane += ((bl - (T.OFF[c.idx] + hb.line)) - st.lane) * 0.08;
        break;
      }
      // oil ahead (보통 · 어려움): steer round it
      const oz = lv >= 2 && !(c.trc > 0) ? oilAhead(W, c, 45) : null;
      if (oz) { const side = c.lat >= oz.lat ? 1 : -1; st.lane += (clamp(oz.lat + side * 3.6, -lim, lim) - T.OFF[c.idx] - hb.line - st.lane) * 0.12; }
      if (c.smk > 0) vt *= 0.94;   // can't see in the smoke
    }
    let thr = 0, brk = 0;
    const pk = p.k || 1;
    if (sp > vt + 0.6 * pk) brk = clamp((sp - vt) / (5 * pk), 0.25, 1);
    else thr = clamp((vt - sp) / (2.5 * pk) + 0.55, 0, 1);
    if (Math.abs(c.lat) > T.half + 0.5) thr = Math.min(thr, 0.75);   // ease off on the grass
    if (c.dr > 0.5) { brk = Math.min(brk, 0.3); if (brk) thr = 0; else thr = Math.max(thr, 0.7); }   // in a slide: keep the power on
    if (hbOn) { brk = 0; thr = Math.max(thr, 0.5); }
    if (c.wrong) { steer = Math.sign(wrapA(Math.atan2(T.TY[c.idx], T.TX[c.idx]) - c.h)) || 1; hbOn = 0; }
    return { thr, brk, steer, hb: hbOn, it: W && W.items ? aiItem(T, c, W, lv, hb) : 0 };
  }
  /* braking / steering assist for people: 켬(2) = brakes for the corner ahead when too fast + edge keeping,
     일부(1) = only a gentle brake when clearly too fast for a corner (no steering help) */
  function assistBrake(T, c, inp, wet, lvl) {
    const prof = speedProfile(T, c, wet, 1), soft = lvl === 1;
    let vt = 1e9; for (let k = 0; k < 9; k++) vt = Math.min(vt, prof[(c.idx + k) % T.n]);
    vt *= soft ? 1.0 : 0.97;   // people rarely take the ideal line: 켬 brakes a touch earlier than the AI table, 일부 only when over it
    let out = inp;
    if (c.vf > vt + 1.5 && !inp.hb && !(c.dr > 0.3)) {
      const b = soft ? clamp((c.vf - vt) / 8, 0.12, 0.85) : clamp((c.vf - vt) / 7, 0.15, 1);
      out = Object.assign({}, inp, { brk: Math.max(inp.brk || 0, b), thr: (inp.brk || 0) > 0 || b > 0.25 ? 0 : Math.min(inp.thr, 0.3) });
    }
    if (soft) return out;
    // edge keeping: near the edge and still heading out → a gentle nudge back (never against a hard steer)
    const i = c.idx, rel = wrapA(c.h - Math.atan2(T.TY[i], T.TX[i])), edge = Math.abs(c.lat) - (T.half - 1.4);
    if (edge > 0 && c.vf > 8 && Math.sign(rel) === Math.sign(c.lat) && Math.abs(out.steer || 0) < 0.9) {
      out = Object.assign({}, out, { steer: clamp((out.steer || 0) - Math.sign(c.lat) * Math.min(0.6, edge * 0.35 + Math.abs(rel) * 2), -1, 1) });
    }
    return out;
  }

  /* ======================= 경주 세계 (호스트·로컬 시뮬, 노드 시험에서도 씀) ======================= */
  function makeWorld(st) {
    const T = genTrack(st.seed, st.n, st.th, st.cs, st.arc);
    const cars = [];
    for (let s = 0; s < st.n; s++) cars.push(newCar(T, s, (st.pk && st.pk[s] && st.pk[s][0]) || 'gt3r', st.grid ? st.grid.indexOf(s) : s));
    // performance balance (BoP): each car's own scaled physics for this race
    if (st.pk && st.pk.every(Boolean)) { const F = bopFactors(st, T); for (const c of cars) { c.k = F[c.seat]; c.ph = scaledPh(c.car, c.k); } }
    // hum = people's seats (set by the view): the AI paces itself a little around them when 「접전」 is on (packPace)
    const items = !!st.arc && !!(T.IB && T.IB.length);
    return { T, cars, t: 0, laps: st.laps, wet: st.wx === 'rain', hab: cars.map((c) => habits(st.seed, c.seat)), ev: [], pack: st.pack !== 'off', hum: [], seed: st.seed,
      items, ibT: items ? T.IB.map((r) => r[1].map(() => 0)) : null, hz: [], hzOut: [], out: [], hzIds: {} };
  }
  /* advance the cars simulated here by dt (fixed sub-steps). input(seat, car) → inp; local(seat) → simulate here? */
  function worldStep(W, dt, input, local, assist, aid) {   // aid(seat) = the brake assist level for people (AI: none)
    const T = W.T, n = Math.max(1, Math.round(dt / DT)), h = dt / n;
    for (let k = 0; k < n; k++) {
      W.t += h;
      for (const c of W.cars) {
        if (!local(c.seat)) continue;
        if (c.ghost > 0) c.ghost -= h;
        let inp = c.fin ? { thr: 0, brk: 0.35, steer: 0, hb: 0 } : input(c.seat, c);
        const asl = aid ? aid(c.seat) : 0;
        if (!c.fin && asl) inp = assistBrake(T, c, inp, W.wet, asl);
        if (W.items && inp.it && !c.fin && W.t > 0) useItem(W, c, local);
        let dT = draftFor(T, c, W.cars), pull = 0;
        if (c.mag > 0 && carNear(W, c, IT.magR, 1)) { dT = 1; pull = 1.4; }   // 슬립 자석
        if (c.smk > 0) dT = 0;   // 연막: no slipstream in the smoke
        c.draft += (dT - c.draft) * Math.min(1, h * 3);
        stepCar(T, c, inp, h, { wet: W.wet, assist: assist(c.seat), draft: c.draft, pull });
        if (c.ev) { W.ev.push({ k: c.ev, seat: c.seat, lv: c.ev === 'boost' ? c.blv : c.dlv }); c.ev = null; }
        const ev = progress(T, c, W.t, W.laps);
        if (ev) W.ev.push({ k: ev, seat: c.seat, t: W.t });
        if (W.items) { itemTick(W, c, h); boxStep(W, c, true); }
        // stuck: nearly stopped while trying to drive → back onto the track after 3 s
        // stuck (nearly stopped while trying to drive, 2 s) or stopped facing the wrong way / far off the road (1.5 s) → back onto the track, ghosted
        const rel = Math.abs(wrapA(c.h - Math.atan2(T.TY[c.idx], T.TX[c.idx])));
        const lost = Math.abs(c.vf) < 6 && (rel > 2.0 || Math.abs(c.lat) > T.half + 3);
        if (!c.fin && W.t > 0 && ((Math.abs(c.vf) < 1.5 && (inp.thr > 0.3 || inp.brk > 0.3)) || lost)) { c.stuck += h; if (c.stuck > (lost ? 1.5 : 2)) { resetToTrack(T, c); W.ev.push({ k: 'reset', seat: c.seat }); } } else c.stuck = 0;
      }
      for (let a = 0; a < W.cars.length; a++) for (let b = a + 1; b < W.cars.length; b++) {
        const A = W.cars[a], B = W.cars[b], la = local(A.seat), lb = local(B.seat);
        if (!la && !lb) continue;
        // soft contact: the first 6 s (no first-corner pile-up) and any person vs AI (the AI never punts you)
        const hA = W.hum.indexOf(A.seat) >= 0, hB = W.hum.indexOf(B.seat) >= 0;
        const v = collide(A, B, la && !lb, lb && !la, W.t < 6 || hA !== hB);
        if (v > 2) W.ev.push({ k: 'bump', seat: A.seat, o: B.seat, v });
      }
    }
    if (W.items) {
      for (const c of W.cars) if (!local(c.seat)) boxStep(W, c, false);   // remote cars knock boxes out here too (the picture only)
      if (W.hz.some((z) => z.end <= W.t)) W.hz = W.hz.filter((z) => z.end > W.t);
      const old = (x) => W.t - x.t > 3;
      if (W.hzOut.length && old(W.hzOut[0])) W.hzOut = W.hzOut.filter((x) => !old(x));
      if (W.out.length && old(W.out[0])) W.out = W.out.filter((x) => !old(x));
    }
  }

  /* ======================= 꾸미기 v4 (docs/HYPERRACE.md 「꾸미기」 · 「꾸미기 v4」) =======================
     cust = {
       m 1 = 직접 고른 색 c / 없으면 도색 목록 · f 마감 0~8(기본 · 유광 · 메탈릭 · 무광 · 펄 · 크롬 · 새틴 · 캔디 · 카멜레온) · fk 메탈 입자 0~3 · pc 펄 색 변화 색 + pk 세기 1~3
       tt 투톤 0~9 + tc 색 · t2 둘째 투톤 0~9 + t2c 색
       L 겹 최대 16장(앞 = 먼저 그림, 뒤가 위):
         무늬  [종류 1~38, 색, 크기 0~4, 위치 0~4, 둘째 색|'', 불투명 10~100, {덧붙임}]
         스티커 [종류 50~85 · 100~120, 색, 면 0~4(오른쪽 옆 · 왼쪽 옆 · 위 · 앞 · 뒤), 가로 0~200, 세로 0~200, 크기 cm 4~300, 회전 0~359, 표시 0~3(1 대칭 · 2 뒤집기), 불투명, 둘째 색|'', 글자, {덧붙임}]
           가로 · 세로 = 그 면의 비율(옆: 뒤 0 → 앞 200 · 위 0 → 아래 200, 위: 뒤 → 앞, 왼쪽 → 오른쪽 · 앞/뒤: 보는 쪽 왼 → 오), 차가 달라도 같은 자리에 붙음.
           종류: 50~69 모양 · 70 글자 · 71~85 지어낸 로고 · 100~119 모양 2 · 120 손그림(붓).
         {덧붙임}(v4, 마지막 칸 · 있을 때만): 모든 겹 — f 겹 마감 0~5 · g [끝 색, 방향 0~3] 그라데이션 · m 마스크 0~3(아래 겹 안 · 아래 겹 밖 · 투톤 안) · d 그림자 · k 기울임 −60~60°
           무늬 — a 범위 0~8 · x · y 옮김(cm, 면 가운데 기준) · r 회전 · w · h 늘이기 %(자유 변형)
           스티커 — w 가로 늘이기 % · o 글꼴 0~5(글자) · p 붓 점(손그림) · b 붓 굵기(크기의 %)
           이 기기에만(온라인으로 안 보냄) — n 이름 · v 숨김 · l 잠금
         끝쪽 기본값은 줄여서 저장 · 전송. 옛 겹 [종류, 색, 크기, 위치]도 그대로 읽음.
       n 경주 번호 1~99 · ns 번호 모양 0~3 · nc 번호 글자 색 · nh 1 = 지붕에도 · nf 번호 글꼴 0~5 · pl 번호판 글자(8자) · ps 번호판 바탕 0~2 · tg 이름표 글자(10자)
       r 휠 색 · rf 휠 마감 0~4 · k 캘리퍼 색 · t 창 틴팅 0~2 · tw 창 색 · u 언더글로 색 · hl 전조등 색 0~3 }
     해금 없음 — 모두 처음부터. 차마다 이 기기에 저장(localStorage), 온라인은 custNet(숨긴 겹 · 이름 · 잠금을 뺀 것, pk[자리][2])이 함께 가요(1200바이트 안쪽).
     옛 값(p 무늬 1~6 + c2)은 custClean이 겹(L)으로 바꿔요. */
  const HEX = /^#[0-9a-f]{6}$/i;
  const SHP0 = 50, TXT_T = 70, LOGO0 = 71, SHP2 = 100, BRUSH_T = 120;   // 스티커 종류: 50~69 모양 · 70 글자 · 71~85 로고 · 100~119 모양 2 · 120 손그림
  const CUST = {
    FIN: ['기본', '유광', '메탈릭', '무광', '펄', '크롬', '새틴', '캔디', '카멜레온'],
    PATS: [null, '두 줄', '가운데 줄', '옆 띠', '사선', '체크 꼬리', '체커', '불꽃', '번개', '탄소 보닛', '그라데이션', '디지털 위장', '스티커', '점 무늬',
      '호랑이 줄무늬', '웨이브', '기하 삼각', '체크 띠', '스플래터', '2색 페이드', '핀스트라이프', '헥사 카본', '스우시', '지그재그',
      '숲 위장', '조각 위장', '벌집', '탄소 직조', '비늘', '물감 흘러내림', '하프톤 줄', '속도선', '트라이벌 불꽃', '물방울', '사선 줄무늬', '등고선', '회로', '별 흩뿌리기', '붓질'],
    // 무늬마다 둘째 색의 뜻('' = 둘째 색 없음)
    PC2: ['', '테두리', '테두리', '테두리', '', '', '둘째 칸', '안쪽 불꽃', '테두리', '', '', '둘째 색', '글자 색', '',
      '테두리', '둘째 물결', '둘째 색', '둘째 칸', '둘째 색', '끝 색', '둘째 줄', '테두리', '테두리', '테두리',
      '둘째 색', '둘째 색', '테두리', '둘째 실', '테두리', '둘째 색', '', '둘째 색', '테두리', '둘째 색', '둘째 줄', '둘째 선', '점 색', '둘째 색', '둘째 색'],
    SHP: ['원', '별', '하트', '번개', '불꽃', '날개', '화살표', '줄', '방패', '왕관', '다이아', '삼각', '육각', '발톱 자국', '과녁', '체크 깃발', '별 배지', '고리', '물방울', '갈매기'],
    SHPB: ['반짝', '해골', '교차 피스톤', '렌치', '바퀴', '날개 바퀴', '타이어 자국', '소용돌이', '심박선', '산봉우리', '태양', '초승달', '나뭇잎', '스페이드', '클로버', '교차 깃발', '터보 팬', '펼친 날개', '표창', '깃털'],
    // 지어낸 로고(실제 상표 아님)
    LOGO: ['ZORVEX', '번개오일', 'KAIRON', '하늘타이어', 'QUANTA', '불새 레이싱', 'TRAXON', 'MOXLY', 'VELTRO', '흑룡 연료', 'NOVARC', '철마 엔진', 'KESTRIX', '은하 윤활유', 'ZYPHOR'],
    FACE: ['오른쪽 옆', '왼쪽 옆', '위', '앞', '뒤'],
    AREA: ['차 전체', '양옆', '오른쪽 옆', '왼쪽 옆', '위', '앞', '뒤', '옆 + 위', '앞뒤'],
    AREAM: [31, 3, 1, 2, 4, 8, 16, 7, 24],   // 면 비트: 1 오른쪽 옆 · 2 왼쪽 옆 · 4 위 · 8 앞 · 16 뒤
    LFIN: ['차와 같음', '유광', '무광', '메탈', '크롬풍', '새틴'],
    MASK: ['없음', '아래 겹 안에만', '아래 겹 밖에만', '투톤 안에만'],
    GRAD: ['가로', '세로', '비스듬히', '가운데부터'],
    FONT: ['굵은 고딕', '블랙 한', '부드러운 고딕', '모노', '명조', '기울임'],
    TT: ['없음', '지붕', '아래쪽', '앞쪽 절반', '뒤쪽 절반', '보닛', '앞 범퍼', '꼬리', '옆 아래 띠', '윗면 전체'],
    NS: ['원판', '네모판', '글자만', '검은 원판'],
    RF: ['기본', '무광', '유광', '크롬', '건메탈'],
    HL: ['흰빛', '노란빛', '푸른빛', '호박빛'],
    PS: ['흰 바탕', '노란 바탕', '검은 바탕'],
    MAXL: 16, MAXB: 1200, SHP0, TXT_T, LOGO0, SHP2, BRUSH_T,   // 겹 16장 · 온라인으로 보내는 크기 1200바이트까지(넘으면 뒤 겹부터 뺌 — 화면에 용량 표시)
    // 고른 색 묶음(직접 고르기 + 최근 색은 화면에서)
    PAL: [
      ['기본', ['#f4f4f0', '#16161a', '#9aa3ab', '#b3121d', '#e0661e', '#f0c419', '#3fae4b', '#1f4fb8', '#7b4fd0']],
      ['레이싱', ['#c0c5cc', '#0b1f4a', '#c8102e', '#ff8000', '#00594f', '#6cace4', '#ffd100', '#1e1e1e', '#e8dfc8']],
      ['네온', ['#29e3ff', '#ff3dcf', '#7dff4a', '#ffb02e', '#9a5cff', '#ff2a4f', '#00ffa6', '#fff23a']],
      ['파스텔', ['#f6c1cc', '#c9e4ff', '#cdeccf', '#fff1b8', '#e3d4ff', '#ffd8b8', '#bfefe8', '#f2f2f2']],
      ['메탈', ['#2b2d31', '#5b6068', '#8a6a3a', '#b87333', '#c9a23a', '#d8d2c4', '#4a5a3a', '#3a2a5a']],
      ['군용 · 흙', ['#4b5320', '#6b6b3a', '#8a7f5a', '#c2b280', '#5c4033', '#3b3b2f', '#7a8b6f', '#a39171']],
    ],
  };
  const isDec = (t) => (t >= SHP0 && t <= LOGO0 + CUST.LOGO.length - 1) || (t >= SHP2 && t <= BRUSH_T);
  const decName = (t) => (t === TXT_T ? '글자' : t === BRUSH_T ? '손그림' : t >= SHP2 ? CUST.SHPB[t - SHP2] : t >= LOGO0 ? CUST.LOGO[t - LOGO0] : CUST.SHP[t - SHP0]);
  CUST.decName = decName;
  CUST.isDec = isDec;
  /* 스티커 겹 만들기(기본값 채움) */
  const decL = (t, c, f, a, b, s, r, m, op, c2, tx, X) => { const o = [t, c, f | 0, a == null ? 100 : a, b == null ? 100 : b, s || 40, r | 0, m == null ? 1 : m, op || 100, c2 || '', tx || '']; if (X) o.push(X); return o; };
  /* 무늬 겹(+ 자유 변형 덧붙임) */
  const patL = (t, c, s, o, c2, op, X) => { const q = [t, c, s == null ? 2 : s, o == null ? 2 : o, c2 || '', op || 100]; if (X) q.push(X); return q; };
  /* 리버리 템플릿: 아무 차에나 도색 + 겹을 한 번에(번호 · 부품은 그대로). 같은 템플릿을 다시 누르면 다음 색 묶음. */
  CUST.TPL = [
    ['레트로 레이싱', [['#e8dfc8', '#0b1f4a', '#c8102e'], ['#f4f4f0', '#1f4fb8', '#f0c419'], ['#0b1f4a', '#f4f4f0', '#c8102e']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [[1, b, 2, 2, c], [3, c, 0, 1], decL(SHP0 + 17, b, 0, 112, 108, 46, 0, 1, 100, c)] })],
    ['랠리', [['#f4f4f0', '#1f4fb8', '#e0661e'], ['#1f4fb8', '#f0c419', '#f4f4f0'], ['#c8102e', '#f4f4f0', '#16161a']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [[22, b, 3, 2, c], [18, '#6b4a2b', 2, 0, '', 45], decL(LOGO0 + 2, '#16161a', 0, 52, 78, 18, 0, 1, 100, '#f4f4f0'), decL(LOGO0 + 3, c, 2, 150, 100, 24, 0, 0, 100, '#16161a')] })],
    ['스트리트', [['#16161a', '#29e3ff', '#ff3dcf'], ['#2b2d31', '#7dff4a', '#16161a'], ['#f4f4f0', '#ff2a4f', '#16161a']],
      (a, b, c) => ({ m: 1, c: a, f: 3, L: [[20, b, 2, 2, c], [8, b, 2, 1], decL(SHP0 + 13, b, 0, 34, 100, 42, 0, 1, 90)] })],
    ['경찰풍', [['#f4f4f0', '#16161a', '#1f4fb8'], ['#16161a', '#f4f4f0', '#1f4fb8'], ['#f4f4f0', '#1f4fb8', '#f0c419']],
      (a, b, c) => ({ m: 1, c: a, f: 1, tt: 9, tc: b, L: [[17, c, 1, 2, '#f4f4f0'], decL(TXT_T, b, 0, 108, 78, 24, 0, 1, 100, '', '순찰'), decL(SHP0 + 16, '#f0c419', 0, 158, 80, 30, 0, 1, 100, b)] })],
    ['내구 레이스', [['#0b1f4a', '#6cace4', '#f4f4f0'], ['#f4f4f0', '#c8102e', '#16161a'], ['#16161a', '#ff8000', '#f4f4f0']],
      (a, b, c) => ({ m: 1, c: a, f: 2, L: [[19, a, 3, 0, b], [3, c, 0, 1], decL(LOGO0 + 4, c, 0, 66, 66, 20, 0, 1, 100, a), decL(LOGO0 + 8, c, 2, 156, 100, 26, 0, 0, 100, a), decL(SHP0 + 15, c, 0, 18, 66, 26, 0, 1)] })],
    ['드리프트', [['#ff3dcf', '#16161a', '#29e3ff'], ['#f0c419', '#16161a', '#ff2a4f'], ['#7b4fd0', '#f4f4f0', '#ffb02e']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [[16, b, 2, 1, c, 85], [15, c, 2, 3, b], decL(LOGO0 + 1, b, 0, 64, 76, 22, 0, 1, 100, c), decL(SHP0 + 5, c, 0, 150, 84, 36, 0, 1, 100, b)] })],
    ['네온', [['#16161a', '#29e3ff', '#ff3dcf'], ['#141416', '#7dff4a', '#fff23a'], ['#16161a', '#ff3dcf', '#9a5cff']],
      (a, b, c) => ({ m: 1, c: a, f: 4, pc: b, pk: 2, L: [[21, '#2b2d31', 1, 2, b, 80], [20, b, 1, 2, c], [8, c, 2, 2]] })],
    ['클래식 GT', [['#c0c5cc', '#1f4fb8', '#f4f4f0'], ['#00594f', '#f0c419', '#f4f4f0'], ['#b3121d', '#f4f4f0', '#16161a']],
      (a, b, c) => ({ m: 1, c: a, f: 2, L: [[2, b, 1, 2, c], [3, c, 0, 2], decL(SHP0 + 14, b, 0, 112, 108, 40, 0, 1, 100, c)] })],
    ['호랑이', [['#ff8000', '#16161a', '#f4f4f0'], ['#f4f4f0', '#16161a', '#9aa3ab'], ['#3fae4b', '#16161a', '#f0c419']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [[14, b, 2, 2], decL(SHP0 + 13, b, 2, 150, 100, 60, 0, 1), decL(LOGO0 + 9, c, 0, 70, 70, 18, 0, 1, 100, b)] })],
    // v4 (+10)
    ['카본 레이서', [['#d8d2c4', '#c8102e', '#16161a'], ['#16161a', '#ffd100', '#f4f4f0'], ['#f4f4f0', '#1f4fb8', '#16161a']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [patL(27, '#2b2d31', 2, 1, '', 100, { a: 4, f: 1 }), patL(2, b, 1, 2, c), decL(LOGO0 + 12, c, 0, 60, 74, 20, 0, 1, 100, a), decL(SHP2 + 16, b, 0, 150, 70, 28, 0, 1, 100, c)] })],
    ['레트로 웨이브', [['#2a1a4a', '#ff3dcf', '#ffb02e'], ['#16161a', '#29e3ff', '#ff3dcf'], ['#3a1a5a', '#ff8000', '#fff23a']],
      (a, b, c) => ({ m: 1, c: a, f: 4, pc: b, pk: 1, L: [patL(19, b, 3, 2, c, 85), patL(31, c, 2, 2, b, 80, { a: 1 }), decL(SHP2 + 10, c, 0, 150, 60, 42, 0, 1, 100, '', '', { g: [b, 1] })] })],
    ['숲 위장', [['#6b6b3a', '#3b3b2f', '#8a7f5a'], ['#c2b280', '#8a7f5a', '#5c4033'], ['#9aa3ab', '#5b6068', '#2b2d31']],
      (a, b, c) => ({ m: 1, c: a, f: 3, L: [patL(24, b, 2, 1, c), decL(SHP0 + 16, '#16161a', 0, 120, 60, 28, 0, 1, 100, a)] })],
    ['랠리 레이드', [['#f4f4f0', '#e0661e', '#16161a'], ['#c2b280', '#16161a', '#c8102e'], ['#f0c419', '#16161a', '#1f4fb8']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [patL(29, '#8a6a3a', 2, 0, '#5c4033', 70), patL(34, b, 2, 2, c, 100, { a: 1, h: 60, y: 22 }), decL(LOGO0 + 11, c, 0, 56, 74, 22, 0, 1, 100, a), decL(TXT_T, c, 2, 120, 100, 26, 0, 0, 100, a, 'RAID-X', { o: 1 })] })],
    ['고전 포뮬러', [['#b3121d', '#f4f4f0', '#16161a'], ['#00594f', '#f4f4f0', '#f0c419'], ['#1f4fb8', '#f4f4f0', '#c8102e']],
      (a, b, c) => ({ m: 1, c: a, f: 1, L: [decL(SHP0, b, 0, 100, 96, 46, 0, 1, 100, c), patL(20, b, 1, 2, '')] })],
    ['스트리트 아트', [['#f4f4f0', '#ff3dcf', '#29e3ff'], ['#16161a', '#7dff4a', '#ff8000'], ['#fff23a', '#16161a', '#ff2a4f']],
      (a, b, c) => ({ m: 1, c: a, f: 3, L: [patL(38, b, 2, 2, c), patL(18, c, 1, 3, b, 90), decL(SHP2 + 1, '#16161a', 0, 110, 90, 54, 350, 1, 100, a, '', { d: 1 })] })],
    ['미드나잇', [['#16161a', '#c9a23a', '#f4f4f0'], ['#0b1f4a', '#c0c5cc', '#29e3ff'], ['#2b2d31', '#b87333', '#f4f4f0']],
      (a, b, c) => ({ m: 1, c: a, f: 2, fk: 2, L: [patL(20, b, 1, 2, c), patL(1, b, 0, 1, '', 100, { a: 4, f: 4 }), decL(TXT_T, b, 0, 108, 70, 18, 0, 1, 100, '', 'MIDNIGHT', { o: 4 })] })],
    ['용 비늘', [['#00594f', '#c9a23a', '#16161a'], ['#b3121d', '#16161a', '#f0c419'], ['#3a2a5a', '#29e3ff', '#16161a']],
      (a, b, c) => ({ m: 1, c: a, f: 2, L: [patL(28, b, 2, 2, c, 80, { a: 7 }), decL(SHP2 + 17, b, 2, 140, 100, 90, 270, 0, 100, c, '', { f: 3 })] })],
    ['사이버 회로', [['#141416', '#00ffa6', '#29e3ff'], ['#f4f4f0', '#1f4fb8', '#16161a'], ['#16161a', '#ff3dcf', '#9a5cff']],
      (a, b, c) => ({ m: 1, c: a, f: 3, L: [patL(36, b, 2, 2, c), patL(31, c, 1, 2, '', 70, { a: 1 }), decL(LOGO0 + 14, b, 0, 64, 70, 20, 0, 1, 100, a)] })],
    ['별빛 은하', [['#0b1f4a', '#f4f4f0', '#9a5cff'], ['#16161a', '#fff23a', '#29e3ff'], ['#3a2a5a', '#f6c1cc', '#c9e4ff']],
      (a, b, c) => ({ m: 1, c: a, f: 4, pc: c, pk: 2, L: [patL(19, c, 2, 3, a, 80), patL(37, b, 2, 2, c), decL(SHP2 + 11, b, 0, 160, 50, 34, 20, 1, 100, '', '', { g: [c, 1] })] })],
  ];
  /* 템플릿 적용: 번호 · 번호판 · 이름표 · 부품은 지금 것 그대로 */
  function custTpl(cu, k, sch) {
    const T = CUST.TPL[k]; if (!T) return custClean(cu) || {};
    const S = T[1][((sch | 0) % T[1].length + T[1].length) % T[1].length], o = T[2](S[0], S[1], S[2]);
    for (const q of ['n', 'ns', 'nc', 'nh', 'nf', 'pl', 'ps', 'tg', 'r', 'rf', 'k', 't', 'tw', 'u', 'hl']) if (cu && cu[q] != null && o[q] == null) o[q] = cu[q];
    return custClean(o) || {};
  }
  const txtClean = (v, n) => (typeof v === 'string' ? v.replace(/[^0-9A-Za-z가-힣 ·.\-!#+?&/:★♥]/g, '').replace(/\s+/g, ' ').trim().slice(0, n) : '');
  const LEGACY_P = [0, 1, 2, 3, -1, 4, 5];   // 옛 무늬 p → 겹 종류 (4 투톤 → tt 아래쪽)
  const PTS_RE = /^[A-Za-z0-9_-]+(\.[A-Za-z0-9_-]+)*$/;
  /* 덧붙임 검사 → 깨끗한 객체(기본값은 뺌) 또는 null */
  function extClean(X, t, dec) {
    if (!X || typeof X !== 'object' || Array.isArray(X)) return null;
    const o = {}, int = (v, a, b) => { v = Math.round(+v); return fin(v) && v >= a && v <= b ? v : null; }, hx = (v) => (typeof v === 'string' && HEX.test(v) ? v.toLowerCase() : '');
    const put = (k, v, d) => { if (v != null && v !== d) o[k] = v; };
    put('f', int(X.f, 0, 5), 0);
    if (Array.isArray(X.g) && hx(X.g[0])) o.g = [hx(X.g[0]), int(X.g[1], 0, 3) || 0];
    put('m', int(X.m, 0, 3), 0);
    put('d', int(X.d, 0, 1), 0);
    put('k', int(X.k, -60, 60), 0);
    if (!dec) {
      put('a', int(X.a, 0, 8), 0);
      put('x', int(X.x, -800, 800), 0); put('y', int(X.y, -800, 800), 0);
      const r = int(X.r, -720, 720); if (r != null) put('r', ((r % 360) + 360) % 360, 0);
      put('w', int(X.w, 10, 400), 100); put('h', int(X.h, 10, 400), 100);
    } else {
      put('w', int(X.w, 20, 500), 100);
      if (t === TXT_T) put('o', int(X.o, 0, 5), 0);
      if (t === BRUSH_T) {
        if (typeof X.p === 'string' && X.p.length <= 640 && PTS_RE.test(X.p) && X.p.split('.').every((s) => s.length % 2 === 0)) o.p = X.p;
        put('b', int(X.b, 1, 100), 8);
      }
    }
    // this device only (never sent online)
    if (typeof X.n === 'string') { const n = txtClean(X.n, 12); if (n) o.n = n; }
    put('v', int(X.v, 0, 1), 0); put('l', int(X.l, 0, 1), 0);
    return Object.keys(o).length ? o : null;
  }
  /* 겹 하나 검사 → 깨끗한 배열(끝쪽 기본값은 뺌) 또는 null */
  function layerClean(l) {
    if (!Array.isArray(l)) return null;
    const int = (v, a, b, d) => { v = Math.round(+v); return fin(v) && v >= a && v <= b ? v : d; }, hx = (v) => (typeof v === 'string' && HEX.test(v) ? v.toLowerCase() : '');
    const t = int(l[0], 1, BRUSH_T, 0);
    if (!t || (t >= CUST.PATS.length && !isDec(t))) return null;
    const dec = isDec(t), last = l[l.length - 1], X = l.length > 1 && last && typeof last === 'object' && !Array.isArray(last) ? extClean(last, t, dec) : null;
    const c = hx(l[1]) || '#f4f4f0';
    let o;
    if (!dec) {
      o = [t, c, int(l[2], 0, 4, 2), int(l[3], 0, 4, 2), CUST.PC2[t] ? hx(l[4]) : '', int(l[5], 10, 100, 100)];
    } else {
      const tx = t === TXT_T ? txtClean(l[10], 12) : '';
      if (t === TXT_T && !tx) return null;
      if (t === BRUSH_T && !(X && X.p)) return null;
      o = [t, c, int(l[2], 0, 4, 0), int(l[3], 0, 200, 100), int(l[4], 0, 200, 100), int(l[5], 4, 300, 40), ((int(l[6], -720, 720, 0) % 360) + 360) % 360, int(l[7], 0, 3, 1), int(l[8], 10, 100, 100), hx(l[9]), tx];
    }
    // trailing defaults off (smaller online)
    const dflt = dec ? [null, null, null, null, null, null, 0, 1, 100, '', ''] : [null, null, 2, 2, '', 100];
    while (o.length > 2 && dflt[o.length - 1] !== null && o[o.length - 1] === dflt[o.length - 1]) o.pop();
    if (X) { while (o.length < dflt.length) o.push(dflt[o.length]); o.push(X); }
    return o;
  }
  /* 겹의 덧붙임(없으면 빈 객체 — 읽기 전용으로 씀) */
  const layerX = (l) => { const q = l && l.length > 1 && l[l.length - 1]; return q && typeof q === 'object' && !Array.isArray(q) ? q : {}; };
  /* JSON 크기(바이트, UTF-8) */
  const custBytes = (o) => { const s = JSON.stringify(o || {}); let n = s.length; for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) > 127) n += s.charCodeAt(i) > 2047 ? 2 : 1; return n; };
  /* 온라인으로 보낼 모양: 숨긴 겹 · 이름 · 잠금을 뺌 */
  function netOf(o) {
    if (!o) return null;
    const q = Object.assign({}, o);
    if (o.L) {
      q.L = o.L.filter((l) => !layerX(l).v).map((l) => { const X = layerX(l); if (!X.n && !X.l) return l; const c = l.slice(0, -1), Y = Object.assign({}, X); delete Y.n; delete Y.l; if (Object.keys(Y).length) c.push(Y); return layerClean(c); }).filter(Boolean);
      if (!q.L.length) delete q.L;
    }
    return Object.keys(q).length ? q : null;
  }
  function custClean(c, net) {
    if (!c || typeof c !== 'object') return null;
    const o = {}, int = (v, a, b) => { v = Math.round(+v); return fin(v) && v >= a && v <= b ? v : 0; }, hx = (v) => (typeof v === 'string' && HEX.test(v) ? v.toLowerCase() : '');
    if (c.m === 1 && hx(c.c)) { o.m = 1; o.c = hx(c.c); }
    for (const [k, b] of [['f', 8], ['fk', 3], ['pk', 3], ['tt', 9], ['t2', 9], ['n', 99], ['ns', 3], ['nh', 1], ['nf', 5], ['ps', 2], ['t', 2], ['rf', 4], ['hl', 3]]) { const v = int(c[k], 0, b); if (v) o[k] = v; }
    for (const k of ['pc', 'tc', 't2c', 'nc', 'r', 'k', 'u', 'tw']) { const v = hx(c[k]); if (v) o[k] = v; }
    let src = Array.isArray(c.L) ? c.L : [];
    if (!src.length && c.p) { const q = LEGACY_P[int(c.p, 0, 6)] | 0; if (q > 0) src = [[q, c.c2]]; else if (q < 0 && !o.tt) { o.tt = 2; o.tc = hx(c.c2) || '#f4f4f0'; } }
    const L = [];
    for (const l of src.slice(0, 24)) { const q = layerClean(l); if (q) L.push(q); if (L.length >= CUST.MAXL) break; }
    if (L.length) o.L = L;
    if (!o.tt) delete o.tc; else if (!o.tc) o.tc = '#16161a';
    if (!o.t2) delete o.t2c; else if (!o.t2c) o.t2c = '#f4f4f0';
    if (!o.pc) delete o.pk; else if (!o.pk) o.pk = 2;
    if (!o.n) { delete o.ns; delete o.nc; delete o.nh; delete o.nf; }
    const pl = txtClean(c.pl, 8).toUpperCase(); if (pl) o.pl = pl; else delete o.ps;
    const tg = txtClean(c.tg, 10); if (tg) o.tg = tg;
    // the size limit is about what goes online (hidden layers · names don't count)
    while (o.L && custBytes(netOf(o)) > CUST.MAXB) { o.L.pop(); if (!o.L.length) delete o.L; }
    const out = net ? netOf(o) : o;
    return out && Object.keys(out).length ? out : null;
  }
  const custNet = (c) => custClean(c, true);
  /* 나눔 코드: 「HR4.」 + base64url(UTF-8 JSON [도색 번호, 꾸미기]) — 붙여 넣으면 그대로 */
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  function utf8(s) { const o = []; for (let i = 0; i < s.length; i++) { let c = s.charCodeAt(i); if (c >= 0xd800 && c < 0xdc00 && i + 1 < s.length) { c = 0x10000 + ((c - 0xd800) << 10) + (s.charCodeAt(++i) - 0xdc00); } if (c < 128) o.push(c); else if (c < 2048) o.push(192 | (c >> 6), 128 | (c & 63)); else if (c < 65536) o.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63)); else o.push(240 | (c >> 18), 128 | ((c >> 12) & 63), 128 | ((c >> 6) & 63), 128 | (c & 63)); } return o; }
  function unutf8(b) { let s = ''; for (let i = 0; i < b.length;) { const c = b[i++]; let u; if (c < 128) u = c; else if (c < 224) u = ((c & 31) << 6) | (b[i++] & 63); else if (c < 240) u = ((c & 15) << 12) | ((b[i++] & 63) << 6) | (b[i++] & 63); else u = ((c & 7) << 18) | ((b[i++] & 63) << 12) | ((b[i++] & 63) << 6) | (b[i++] & 63); s += String.fromCodePoint(u > 0 && u < 0x110000 ? u : 32); } return s; }
  function b64e(b) { let s = ''; for (let i = 0; i < b.length; i += 3) { const n = (b[i] << 16) | ((b[i + 1] || 0) << 8) | (b[i + 2] || 0), k = Math.min(3, b.length - i); s += B64[(n >> 18) & 63] + B64[(n >> 12) & 63] + (k > 1 ? B64[(n >> 6) & 63] : '') + (k > 2 ? B64[n & 63] : ''); } return s; }
  function b64d(s) { const o = []; let n = 0, k = 0; for (const ch of s) { const v = B64.indexOf(ch); if (v < 0) return null; n = ((n << 6) | v) & 0xffffff; k += 6; if (k >= 8) { k -= 8; o.push((n >> k) & 255); } } return o; }
  function custCode(liv, cu) { return 'HR4.' + b64e(utf8(JSON.stringify([liv | 0, custNet(cu) || {}]))); }
  function custDecode(s) {
    if (typeof s !== 'string') return null;
    const m = /HR4\.([A-Za-z0-9_-]{4,4000})/.exec(s.replace(/\s+/g, '')); if (!m) return null;
    try { const b = b64d(m[1]); if (!b) return null; const v = JSON.parse(unutf8(b)); if (!Array.isArray(v)) return null; return { liv: Math.max(0, Math.min(9, v[0] | 0)), cust: custClean(v[1]) || {} }; } catch (e) { return null; }
  }
  /* 무작위 꾸미기(고르기 화면 단추 · AI 차): 잘 어울리게 — 바탕과 대비되는 무늬 색, 겹은 0~2장 + 가끔 스티커 · 템플릿 */
  const lum = (hx) => { const v = parseInt(hx.slice(1), 16); return (0.299 * (v >> 16) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255; };
  function custRandom(rnd, keepPaint) {
    rnd = rnd || Math.random;
    const pick = (a) => a[Math.floor(rnd() * a.length)], all = [].concat(...CUST.PAL.slice(0, 3).map((p) => p[1]));
    if (!keepPaint && rnd() < 0.3) {   // a ready-made livery in one of its colour sets (+ a number sometimes)
      const k = Math.floor(rnd() * CUST.TPL.length), o = custTpl(null, k, Math.floor(rnd() * 3));
      if (rnd() < 0.6) { o.n = 2 + Math.floor(rnd() * 97); o.ns = pick([0, 0, 1, 2, 3]); if (rnd() < 0.3) o.nf = pick([1, 2, 4, 5]); }
      if (rnd() < 0.4) o.rf = 1 + Math.floor(rnd() * 4);
      return custClean(o);
    }
    const o = {};
    let base = '#9aa3ab';
    if (!keepPaint) { base = pick(all); o.m = 1; o.c = base; o.f = pick([0, 1, 1, 2, 2, 2, 3, 4, 5, 6, 7, 8]); if (rnd() < 0.3) o.fk = 1 + Math.floor(rnd() * 3); if (o.f === 4 || o.f === 8 || rnd() < 0.12) { o.pc = pick(CUST.PAL[2][1]); o.pk = 1 + Math.floor(rnd() * 2); } }
    const con = () => { const c = pick(all.filter((x) => Math.abs(lum(x) - lum(base)) > 0.35)); return c || (lum(base) > 0.5 ? '#16161a' : '#f4f4f0'); };
    if (!keepPaint && rnd() < 0.25) { o.tt = 1 + Math.floor(rnd() * 9); o.tc = con(); }
    const nl = keepPaint ? (rnd() < 0.5 ? 1 : 0) : pick([0, 1, 1, 2]);
    o.L = [];
    for (let i = 0; i < nl; i++) {
      const t = pick([1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38]), q = [t, con(), 1 + Math.floor(rnd() * 3), 1 + Math.floor(rnd() * 3)];
      if (CUST.PC2[t] && rnd() < 0.35) q.push(con());
      if (rnd() < 0.15) { while (q.length < 6) q.push([0, 0, 2, 2, '', 100][q.length]); q.push({ r: pick([0, 0, 15, 345, 30, 330]), a: pick([0, 0, 1, 7]) }); }
      o.L.push(q);
    }
    if (rnd() < (keepPaint ? 0.2 : 0.4)) {   // a sponsor-like logo on the doors, sometimes a small shape on the bonnet
      const cc = con();
      o.L.push(decL(LOGO0 + Math.floor(rnd() * CUST.LOGO.length), cc, 0, 50 + Math.floor(rnd() * 30), 70 + Math.floor(rnd() * 20), 16 + Math.floor(rnd() * 8), 0, 1, 100, rnd() < 0.5 ? (lum(cc) > 0.5 ? '#16161a' : '#f4f4f0') : ''));
      if (rnd() < 0.35) o.L.push(rnd() < 0.5 ? decL(SHP0 + pick([1, 3, 5, 9, 13, 14, 16, 19]), con(), 2, 150, 100, 30 + Math.floor(rnd() * 20), 0, 1) : decL(SHP2 + Math.floor(rnd() * CUST.SHPB.length), con(), 2, 150, 100, 30 + Math.floor(rnd() * 20), 0, 1));
    }
    if (rnd() < 0.6) { o.n = 2 + Math.floor(rnd() * 97); o.ns = pick([0, 0, 1, 2, 3]); if (rnd() < 0.3) o.nh = 1; if (rnd() < 0.25) o.nf = pick([1, 2, 4, 5]); }
    if (!keepPaint) {
      if (rnd() < 0.5) o.r = pick(['#1a1a1c', '#c0c5cc', '#c9a23a', '#2b2d31', '#f4f4f0']);
      if (rnd() < 0.4) o.rf = 1 + Math.floor(rnd() * 4);
      if (rnd() < 0.5) o.k = pick(['#b3121d', '#f0c419', '#1f4fb8', '#3fae4b', '#e0661e']);
      if (rnd() < 0.3) o.t = 1 + Math.floor(rnd() * 2);
      if (rnd() < 0.25) o.u = pick(CUST.PAL[2][1]);
      if (rnd() < 0.25) o.hl = 1 + Math.floor(rnd() * 3);
    }
    return custClean(o);
  }
  /* stat bars 0..1 for the pick screen / codex (relative to all cars) */
  let statCache = null;
  function carStats() {
    if (statCache) return statCache;
    const raw = {};
    for (const c of CARS) {
      const p = c.ph, v = 42;
      const acc = (100 / 3.6) / Math.min(p.P / (p.m * 14), p.mu * GRAV * (p.awd ? 1 : 0.62));
      raw[c.id] = { top: p.vtop, acc: -acc, corner: p.mu * gripK(v) * (GRAV + (p.cl * v * v) / p.m), brake: (p.brake * GRAV + (p.cl * v * v * p.mu) / p.m * 0.9), drift: p.dA * (2 - p.rear) * (p.awd ? 0.8 : 1) + p.bstA * 0.05, kg: Math.log(p.m) };
    }
    statCache = {};
    for (const k of ['top', 'acc', 'corner', 'brake', 'drift', 'kg']) {
      const vs = CARS.map((c) => raw[c.id][k]), lo = Math.min(...vs), hi = Math.max(...vs);
      for (const c of CARS) (statCache[c.id] = statCache[c.id] || {})[k] = 0.15 + 0.85 * (raw[c.id][k] - lo) / Math.max(1e-9, hi - lo);
    }
    return statCache;
  }

  /* ======================= 판 상태 ======================= */
  const LAPS = { 1: 1, 2: 2, 3: 3, 4: 4, 5: 5 };
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = (k) => Math.floor(Math.random() * k);
    const tod = opts.tod && opts.tod !== 'rnd' ? opts.tod : ['day', 'dusk', 'night'][R(3)];
    const wx = opts.wx && opts.wx !== 'rnd' ? opts.wx : (R(10) < 3 ? 'rain' : 'sun');
    // map (theme) and course style: random by default (a fitting style for the map), or chosen
    const tk = Object.keys(THEMES);
    let th = THEMES[opts.map] ? opts.map : tk[R(tk.length)], cs;
    // course: 무작위(기본) = 그 맵의 명소 코스 40% · 새로 만든 서킷 60% / 무작위 생성 / 명소 코스 / 코스 성격 하나 / 명소 하나(맵도 그 코스의 맵)
    const oc = String(opts.course || 'rnd'), lmOf = (t) => LMK.filter((l) => l.th === t);
    if (oc.slice(0, 3) === 'lm:' && LM[oc.slice(3)]) { cs = oc; th = LM[oc.slice(3)].th; }
    else if (oc === 'lm' || (oc === 'rnd' && R(10) < 4)) { const L0 = THEMES[opts.map] ? lmOf(th) : LMK; const l = L0[R(L0.length)]; cs = 'lm:' + l.id; th = l.th; }
    else cs = STYLES[oc] ? oc : THEMES[th].st[R(THEMES[th].st.length)];
    return {
      ph: 'pick', rid: 1 + R(1e6), seed: 1 + R(2e9), n, nm: players.map((p) => String(p.name || '').slice(0, 12)),
      laps: LAPS[opts.laps] || 3, tod, wx, th, cs, arc: opts.arc === 'on' ? 1 : 0, cmix: opts.cars || 'mix', bop: opts.bop === 'off' ? 'off' : 'on', pack: opts.pack === 'off' ? 'off' : 'on',
      pk: Array(n).fill(null),          // per seat: [carId, livery] once picked
      grid: null, res: null, seq: 0,
    };
  }
  /* AI picks after the people: keep the classes mixed (mix) / everyone the same class, liveries not repeated within a model */
  function aiPicks(st, players) {
    /* AI 차(옵션 cars): 클래스 하나 = 모두 그 클래스 / mix = 사람이 고른 클래스 + 빠르기가 이웃한 클래스로 2~3개 클래스 경주 / any = 아무 차나.
       같은 모델이 겹치지 않게 고르게 나누고, 같은 모델이면 색이 겹치지 않게 */
    const pk = st.pk.slice(), used = {}, R = (k) => Math.floor(Math.random() * k), cm = st.cmix || 'mix';
    for (const v of pk) if (v) used[v[0] + '|' + v[1]] = 1;
    const ranks = Object.keys(CLS).sort((a, b) => CLS[a].rk - CLS[b].rk);
    let set;
    if (CLS[cm]) set = [cm];
    else if (cm === 'any') set = ranks.slice();
    else {
      set = [...new Set(pk.filter(Boolean).map((v) => CAR[v[0]].cls))];
      const left = pk.filter((v) => !v).length;
      const want = Math.min(left >= 5 ? 3 : 2, ranks.length);
      while (set.length < want) {
        if (!set.length) { set.push(ranks[R(ranks.length)]); continue; }
        // the closest-in-pace classes to the ones already in (neighbours of the set)
        const dist = (k) => Math.min(...set.map((q) => Math.abs(CLS[k].rk - CLS[q].rk)));
        const free = ranks.filter((k) => !set.includes(k)), dm = Math.min(...free.map(dist)), near = free.filter((k) => dist(k) === dm);
        set.push(near[R(near.length)]);
      }
    }
    const cnt = {}, ccnt = {};
    for (const v of pk) if (v) { cnt[v[0]] = (cnt[v[0]] || 0) + 1; ccnt[CAR[v[0]].cls] = (ccnt[CAR[v[0]].cls] || 0) + 1; }
    for (let s = 0; s < st.n; s++) {
      if (pk[s]) continue;
      // the least used class of the set, then its least used model
      const cl = set.slice().sort((a, b) => (ccnt[a] || 0) - (ccnt[b] || 0) || Math.random() - 0.5)[0];
      const pool = CARS.filter((c) => c.cls === cl);
      const m = Math.min(...pool.map((c) => cnt[c.id] || 0)), cand = pool.filter((c) => (cnt[c.id] || 0) === m);
      const id = cand[R(cand.length)].id;
      cnt[id] = (cnt[id] || 0) + 1; ccnt[cl] = (ccnt[cl] || 0) + 1;
      const lv = CAR[id].liv.map((_, i) => i).filter((i) => !used[id + '|' + i]);
      const li = lv.length ? lv[R(lv.length)] : R(CAR[id].liv.length);
      used[id + '|' + li] = 1;
      // AI cars sometimes wear a race number / stripes (looks like a grid of real teams)
      const cu = Math.random() < 0.75 ? custRandom(Math.random, true) : null;   // number · one decal layer (the livery stays)
      pk[s] = cu ? [id, li, cu] : [id, li];
      void players;
    }
    return pk;
  }
  /* grid: the faster class starts in front (multi-class racing), order inside a class is random */
  function makeGrid(pk, st) {
    const seats = pk.map((_, i) => i).sort(() => Math.random() - 0.5);
    // balanced (BoP) multi-class race: everyone has the same pace → a mixed grid; otherwise the faster class in front
    if (st && st.bop !== 'off' && new Set(pk.map((v) => CAR[v[0]].cls)).size > 1) return seats;
    return seats.sort((a, b) => CLS[CAR[pk[a][0]].cls].rk - CLS[CAR[pk[b][0]].cls].rk);
  }
  const fmtT = (s) => { if (!(s > 0)) return '-'; const m = Math.floor(s / 60), r = s - m * 60; return m + ':' + (r < 10 ? '0' : '') + r.toFixed(2); };
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || ((i + 1) + '번');
    const carNm = (i) => (s.pk && s.pk[i] && CAR[s.pk[i][0]] ? CAR[s.pk[i][0]] : null);
    const clsPos = {}, clsCnt = {};
    const rows = s.res.map((r, k) => {
      const c = carNm(r[0]), cl = c ? c.cls : 'GT';
      clsCnt[cl] = (clsCnt[cl] || 0) + 1;
      clsPos[r[0]] = clsCnt[cl];
      return (k + 1) + '위  ' + nm(r[0]) + '  ' + (c ? c.nm : '') + ' [' + (CLS[cl] ? CLS[cl].short : cl) + ' ' + clsCnt[cl] + '위]  ' + (r[1] > 0 ? fmtT(r[1]) : '미완주 ' + Math.max(0, Math.floor(r[2] || 0)) + '/' + s.laps + '랩');
    });
    const w = s.res[0][0];
    const clsWin = Object.keys(CLS).map((k) => { const r = s.res.find((x) => carNm(x[0]) && carNm(x[0]).cls === k); return r ? CLS[k].nm + ' 우승: ' + nm(r[0]) : null; }).filter(Boolean);
    const P = [...Array(s.n).keys()];
    const resOf = (i) => s.res.find((x) => x[0] === i) || [i, 0, 0, 0, 0];
    // 순위 변화: grid → after each lap (the biggest climb is a highlight)
    const pth = (i) => { const q = resOf(i)[5]; return Array.isArray(q) && q.length > 1 ? q : null; };
    let climb = null, cb = 1;
    for (const i of P) { const q = pth(i); if (q && q[0] - q[q.length - 1] > cb) { cb = q[0] - q[q.length - 1]; climb = '가장 많이 올라감 — ' + nm(i) + ' (' + q[0] + '위 → ' + q[q.length - 1] + '위)'; } }
    return {
      winners: [w], title: nm(w) + ' 우승!',
      text: rows.join('\n'),
      highlights: clsWin.slice(0, 2).concat(s.fl ? ['최고 랩 ' + fmtT(s.fl[1]) + ' — ' + nm(s.fl[0])] : [], climb ? [climb] : [], s.tn ? ['코스: ' + s.tn] : []).slice(0, 5),
      stats: [
        { label: '차', values: P.map((i) => (carNm(i) ? carNm(i).nm : '-')) },
        { label: '클래스 순위', values: P.map((i) => (carNm(i) ? CLS[carNm(i).cls].short + ' ' + (clsPos[i] || '-') + '위' : '-')) },
        { label: '기록', values: P.map((i) => { const r = resOf(i); return r[1] > 0 ? fmtT(r[1]) : '미완주'; }) },
        { label: '최고 랩', values: P.map((i) => fmtT(resOf(i)[3])) },
        { label: '최고 속도', values: P.map((i) => (resOf(i)[4] ? resOf(i)[4] + 'km/h' : '-')) },
        { label: '순위 변화', values: P.map((i) => (pth(i) ? pth(i).join('→') : '-')) },
      ],
    };
  }

  /* ======================= 그래픽 품질 · 보조 (이 기기 설정) ======================= */
  const store = { get(k, d) { try { const v = localStorage.getItem('hyperrace.' + k); return v == null ? d : v; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('hyperrace.' + k, v); } catch (e) {} } };
  function touchOnly() { try { if (L && L.touchOnly) return !!L.touchOnly(); return typeof matchMedia === 'function' && matchMedia('(pointer:coarse)').matches; } catch (e) { return false; } }   // 갤럭시(S펜)는 any-pointer:fine도 true — 코어 판정(주 포인터·실제 터치)을 따른다
  function gfxTier() { const v = store.get('gfx', ''); return TIERS.some((t) => t.id === v) ? v : (touchOnly() ? 'low' : 'mid'); }
  function assistLevel() { const v = store.get('assist', ''); return v === '0' || v === '1' || v === '2' ? +v : (touchOnly() ? 2 : 1); }

  /* ======================= 파일 불러오기 (3D는 게임을 켤 때만) ======================= */
  const BASE = 'assets/hyperrace/';
  const scripts = {};
  function loadScript(src) {
    if (!scripts[src]) scripts[src] = new Promise((ok, no) => {
      const el = document.createElement('script'); el.src = src; el.async = true;
      el.onload = () => ok(); el.onerror = () => { delete scripts[src]; no(new Error('불러오기 실패: ' + src)); };
      document.head.appendChild(el);
    });
    return scripts[src];
  }
  function loadCore() { return loadScript(BASE + 'lib/three.min.js').then(() => loadScript(BASE + 'view.js')); }
  /* base64 packs (pk_<key>.js → window.HR_PACK[key], made by tools/hyperrace_pack.mjs) → { name: Uint8Array } (decoded once) */
  const packs = {};
  function pack(key) {
    if (!packs[key]) packs[key] = loadScript(BASE + 'pk_' + key + '.js').then(() => {
      const P = G.HR_PACK || {}, b = P[key];
      if (typeof b !== 'string') throw new Error('묶음 없음: ' + key);
      delete P[key];
      let u;
      if (typeof Uint8Array.fromBase64 === 'function') u = Uint8Array.fromBase64(b);   // native (new browsers): no string copy
      else { const bin = atob(b); u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); }
      const dv = new DataView(u.buffer), out = {};
      if (String.fromCharCode(u[0], u[1], u[2], u[3]) !== 'HRP1') throw new Error('묶음 형식: ' + key);
      let o = 8;
      for (let k = dv.getUint32(4, true); k > 0; k--) {
        const nl = dv.getUint16(o, true), nm = new TextDecoder().decode(u.subarray(o + 2, o + 2 + nl)), len = dv.getUint32(o + 2 + nl, true);
        o += 6 + nl; out[nm] = u.subarray(o, o + len); o += len;
      }
      return out;
    });
    return packs[key];
  }
  function webglOK() { try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) { return false; } }

  /* ======================= 도감 (자료에서 자동) ======================= */
  function codex(el, ctx) {
    const h = L.h, ST = carStats(), ranks = Object.keys(CLS).sort((a, b) => CLS[a].rk - CLS[b].rk);
    el.append(h('p', { class: 'muted', text: '차 ' + CARS.length + '대 · 클래스 ' + ranks.length + '개. 모두 실제 3D 모델이고, 이름은 별명 · 수치는 게임에서 쓰는 값이에요(실제 차를 참고). 끌어서 돌려 보세요.' }));
    const can = h('canvas', { style: { width: '100%', height: '220px', display: 'block', borderRadius: '12px', background: 'radial-gradient(#3a3348,#17131f)' } });
    const cap = h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '12px', minHeight: '16px' }, text: '' });
    el.append(can, cap);
    let show = null, cls = CARS[0].cls, cur = CARS[0].id;
    const thumbs = {};
    const tabs = h('div', { style: { display: 'flex', gap: '6px', overflowX: 'auto', margin: '10px 0 6px', paddingBottom: '4px' } });
    const sel = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', margin: '6px 0 10px' } });
    const info = h('div');
    const bar = (lbl, v) => h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', margin: '2px 0' } }, h('span', { style: { width: '60px', color: 'var(--muted)' }, text: lbl }),
      h('i', { style: { flex: '1', height: '7px', borderRadius: '4px', background: 'rgba(255,255,255,.12)', overflow: 'hidden', display: 'block' } }, h('s', { style: { display: 'block', height: '100%', width: Math.round(v * 100) + '%', background: 'linear-gradient(90deg,#e3ae45,#ffd27a)' } })));
    const paint = () => {
      const c = CAR[cur], p = c.ph, s = ST[c.id];
      tabs.innerHTML = ''; sel.innerHTML = ''; info.innerHTML = '';
      for (const k of ranks) tabs.append(h('button', { class: 'btn sm' + (cls === k ? ' primary' : ''), style: { minHeight: '44px', flex: '0 0 auto', borderBottom: '3px solid ' + CLS[k].col }, text: CLS[k].nm, onclick() { cls = k; cur = CARS.find((x) => x.cls === k).id; paint(); } }));
      for (const x of CARS.filter((q) => q.cls === cls)) sel.append(h('button', { class: 'btn sm' + (x.id === cur ? ' primary' : ''), style: { minHeight: '44px', display: 'flex', alignItems: 'center', gap: '6px' }, onclick() { cur = x.id; paint(); } },
        thumbs[x.id] ? h('img', { src: thumbs[x.id], alt: '', style: { width: '72px', height: '32px', objectFit: 'contain' } }) : null, x.nm));
      const accel = (100 / 3.6) / Math.min(p.P / (p.m * 14), p.mu * GRAV * (p.awd ? 1 : 0.62));
      info.append(
        h('p', { class: 'muted', style: { fontSize: '12px', margin: '0 0 8px' }, text: CLS[cls].nm + ' — ' + CLS[cls].desc }),
        h('h3', { text: c.nm + '  ·  ' + CLS[c.cls].nm }),
        h('p', { text: c.blurb }),
        bar('최고 속도', s.top), bar('가속', s.acc), bar('코너', s.corner), bar('제동', s.brake), bar('드리프트', s.drift),
        h('table', { style: { width: '100%', fontSize: '13px', borderCollapse: 'collapse', marginTop: '8px' } },
          ...[['바탕 차', c.real], ['출력', c.spec.hp], ['무게', c.spec.kg], ['최고 속도', c.spec.top + ' (게임 ' + kmh(p.vtop) + 'km/h)'], ['0→100km/h', c.spec.zero + ' (게임 약 ' + accel.toFixed(1) + '초)'], ['구동', c.spec.drive + (p.hover ? ' · 떠서 달림' : '') + (p.off ? ' · 잔디에서도 빠름' : '')],
            ['다운포스', p.cl >= 2.5 ? '아주 큼 — 고속 코너도 그대로' : p.cl >= 1.5 ? '큼 — 고속 코너에 강함' : p.cl >= 0.6 ? '보통' : '작음 — 코너 전에 충분히 줄이기'], ['제동', (p.brake).toFixed(2) + 'g'], ['기본 도색', c.liv.map((x) => x[0]).join(' · ')],
            ['모델', c.model + ' — ' + c.by + ' (' + c.lic + ')']]
            .map(([a, b]) => h('tr', null, h('td', { style: { padding: '3px 6px', color: 'var(--muted)', whiteSpace: 'nowrap' }, text: a }), h('td', { style: { padding: '3px 6px' }, text: b })))));
      if (show) show.car(cur);
    };
    el.append(tabs, sel, info);
    paint();
    // car pictures (the same small pack as the pick screen)
    if (typeof document !== 'undefined' && typeof Blob === 'function') pack('thumbs').then((p) => { for (const k of Object.keys(p)) thumbs[k] = URL.createObjectURL(new Blob([p[k]], { type: 'image/webp' })); if (el.isConnected) paint(); }).catch(() => {});
    if (typeof document !== 'undefined' && webglOK()) {
      cap.textContent = '3D 모델 불러오는 중…';
      loadCore().then(() => {
        if (!can.isConnected && !document.body.contains(can)) return;
        show = G.HR_VIEW.showroom(can, API, cur, { onLoad(on) { cap.textContent = on ? '3D 모델 불러오는 중…' : '끌어서 돌려 보기'; } });
      }).catch(() => { cap.textContent = '3D 모델을 불러오지 못했어요'; });
    } else cap.textContent = '이 기기에서는 3D 그림을 켤 수 없어요';
    void ctx;
    return { destroy() { if (show) show.destroy(); } };
  }

  /* ======================= 규칙 ======================= */
  const RULES = [
    { h: '목표', p: ['정해진 바퀴(1~5바퀴, 기본 3바퀴)를 가장 먼저 돌면 우승이에요. 1~8대가 함께 달려요.', '차 ' + CARS.length + '대 · 클래스 8개: 포뮬러 · 하이퍼카 · GT · 미래차 · 슈퍼카 · 스트리트 · 클래식 · 오프로드. 같은 클래스 안에서는 차마다 성격은 달라도 빠르기는 비슷하게 맞췄어요.', '여러 클래스가 함께 달리면 전체 순위와 함께 클래스별 순위도 나와요.'] },
    { h: '성능 맞춤 · 접전', p: ['「성능 맞춤」(기본 켬): 여러 클래스가 섞인 경주에서는 판마다 그 서킷을 보고 차마다 빠르기를 같게 맞춰요 — 트럭으로도 F1을 이길 수 있어요. 차의 성격(가속 · 코너 · 드리프트 · 무게감)은 그대로이고, 모든 속도가 같은 비율로 빨라지거나 느려질 뿐이에요.', '같은 클래스 안에서는 언제나 맞춰요(어떤 차를 골라도 우승 가능). 끄면 클래스 실력 그대로 — 빠른 클래스가 앞에서 출발하고 클래스별 순위로 겨뤄요.', '「접전」(기본 켬): AI가 가장 앞선 사람과 너무 멀어지면 아주 조금 늦추거나(최대 4%) 더 몰아붙여요(최대 3%). 차 성능은 그대로예요. 끄면 AI는 늘 제 페이스.'] },
    { h: '맵 · 코스', p: ['맵 7개: 초원 서킷 · 해안 도로(바다 · 야자수) · 사막 협곡(메사 · 협곡 다리) · 설산 · 숲 계곡 · 야경 도시(건물 사이 시가지, 벽이 가까움) · 고원 서킷(높낮이가 크고 빠름). 기본은 무작위.',
      '코스: 「명소 코스」 = 맵마다 2개씩 모양을 잡아 만든 이름 있는 서킷(' + LMK.map((l) => l.nm).join(' · ') + '). 「무작위 생성」 = 판마다 새로 만드는 서킷(균형 · 고속 · 테크니컬 · 시가지). 기본 「무작위」는 명소 코스와 새 서킷이 섞여 나와요. 명소 코스 하나를 고르면 맵도 그 코스의 맵이 돼요.',
      '출발 전에 코스 이름 · 모양 · 볼거리가 나와요(고르기 화면 「설정」 탭에도). 서킷은 사람 · 차가 많을수록 길고 넓어요(2대 약 2km · 8대 약 3.3km).',
      '볼거리: 터널 · 다리(벽이 가까워져요) · 기운 코너(바깥이 높아 조금 더 빠르게) · 머리 위 고가도로(도시) · 등대(해안) · 점프대(노랑 · 검정 띠와 「점프」 판 — 똑바로 넘으면 짧게 떠요, 내리막 직선이라 안전하게 내려요).',
      '언덕 마루를 빠르게 넘으면 차가 가벼워져(아주 빠르면 살짝 떠요) 그 자리에선 핸들이 덜 들어요 — 마루 앞에서는 똑바로. 골짜기 바닥에서는 반대로 눌려서 더 잘 붙어요.',
      '「아케이드 요소」(기본 끔): 켜면 코너를 빠져나온 직선에 부스트 발판(파란 화살표 — 밟으면 잠깐 빨라짐)과 작은 점프대, 그리고 아이템 상자가 생겨요(아래 「아이템」).'] },
    { h: '아이템 (아케이드 요소)', p: ['「아케이드 요소」를 켜면 트랙을 가로질러 떠 있는 청록 육각 캡슐(아이템 상자)이 한 바퀴에 3~6줄 생겨요. 지나가면 아이템 하나를 받아요(손에는 하나만 — 들고 있으면 상자를 그냥 지나가요). 먹힌 상자는 3초 뒤 다시 생겨요.', '뒤에 있을수록 센 아이템(니트로 · 슬립 자석 · 방해 전파)이 잘 나오고, 1위는 지키는 아이템(충격 범퍼 · 기름 웅덩이 · 접지 타이어)이 잘 나와요.', '아이템 7가지: ' + ITEMS.slice(1).map((it) => it.nm + ' — ' + it.d).join(' / '), '맞아도 짧게(최대 1초) 느려질 뿐 스핀하지 않고, 맞은 뒤 2.6초 동안은 다시 맞지 않아요.', '쓰기: PC는 R(「⌨ 조작 설정」에서 바꿈) · 게임패드 X/RB, 폰은 오른쪽 단추들 위의 아이템 칸을 눌러요. AI도 상황을 보고 써요(어려움일수록 때를 잘 골라요).'] },
    { h: '시작', p: ['설정의 「클래스」: 클래스 하나를 고르면 AI가 모두 그 클래스로, 「클래스 섞기」는 사람이 고른 클래스와 빠르기가 비슷한 클래스 2~3개, 「아무 차나」는 무작위예요. 사람은 언제나 아무 차나 고를 수 있어요.', '출발 전에 차 · 꾸미기를 골라요. 사람이 모두 고르면 신호등이 꺼지는 순간 출발해요.', '출발 순서는 무작위예요(「성능 맞춤」을 끈 다클래스 경주만 빠른 클래스가 앞).'] },
    { h: '차 고르기 · 꾸미기', p: ['고르기 화면: 오른쪽 차 카드(그림 · 클래스 · 한 줄 성격)를 누르면 왼쪽에 3D로 바로 보여요. 위쪽 탭으로 클래스만 걸러 볼 수 있어요(「전체」 = 26대). 왼쪽 아래 막대 = 최고 속도 · 가속 · 코너 · 제동 · 드리프트 · 무게(26대 안에서 비교).', '3D 차는 끌어서 돌리고, 마우스 휠이나 두 손가락으로 확대해요. 「사진 모드」는 판을 숨기고 차만 크게 보여 줘요.', '「꾸미기」 — 도색: 기본 도색 · 직접 색 · 마감(유광 · 메탈릭 · 무광 · 펄 · 크롬 · 새틴 · 캔디 · 카멜레온) · 메탈 입자 · 펄 색 변화(보는 각도에 따라 다른 색) · 투톤 두 겹(지붕 · 아래쪽 · 보닛 · 앞 범퍼 · 꼬리 · 옆 아래 띠 · 윗면 등).', '「무늬」 — 겹을 16장까지 쌓아요(목록 위쪽이 맨 위). 겹마다 무늬 38가지(줄 · 띠 · 체커 · 불꽃 · 위장 · 호랑이 줄무늬 · 헥사 카본 · 숲 위장 · 조각 위장 · 벌집 · 탄소 직조 · 비늘 · 물감 흘러내림 · 속도선 · 트라이벌 불꽃 · 물방울 · 등고선 · 회로 · 별 · 붓질 …)나 스티커(모양 40가지 · 글자(글꼴 6가지) · 지어낸 로고 15가지 · 손그림).', '겹 목록: 왼쪽 손잡이를 끌어 순서 바꾸기 · 눈 = 숨기기(온라인에도 안 보냄) · 자물쇠 = 잠그기(차 위에서 안 움직이고 무작위에도 남음) · 이름 붙이기. PC는 Shift/Ctrl을 누른 채 여러 개를 골라 함께 옮기고 돌려요(폰은 「여러 개 고르기」).', '자유 변형: 무늬도 스티커처럼 차 위에서 끌어 옮기고(가운데 · 다른 스티커 줄에 맞춤, PC Alt = 맞춤 끔), 금빛 손잡이로 돌리기 · 크기 · 가로/세로 늘이기, 폰은 두 손가락으로 크기 · 회전. 숫자 칸(위치 · 각도 · 크기 · 늘이기 · 기울임)도 있어요. 무늬는 「범위」로 차 전체 · 양옆 · 한쪽 옆 · 위 · 앞 · 뒤만 고를 수 있어요. 스티커는 끄는 대로 다른 면(옆 → 위 …)으로도 옮겨져요.', '겹마다 색 · 둘째 색 · 그라데이션(끝 색 · 방향) · 불투명 · 겹 마감(유광 · 무광 · 메탈 · 크롬풍 · 새틴) · 마스크(아래 겹 안에만 · 밖에만 · 투톤 안에만) · 그림자. 복제 · 복사 · 붙여넣기(다른 차에도) · 스타일 복사/붙이기.', '손그림: 「+ 손그림」 → 차 위를 끌어 그려요(한 겹에 여러 획, 붓 굵기). 그린 뒤엔 스티커처럼 옮기고 돌려요.', '색 고르기: 팔레트 · 최근 색 · 채도/밝기 판 + 색상 띠 + #코드 · 스포이트(차를 눌러 그 자리 색 가져오기).', '「리버리」 — 템플릿 19가지(레트로 레이싱 · 랠리 · 경찰풍 · 네온 · 카본 레이서 · 레트로 웨이브 · 숲 위장 · 랠리 레이드 · 고전 포뮬러 · 스트리트 아트 · 미드나잇 · 용 비늘 · 사이버 회로 · 별빛 은하 …) 한 번에 입히기(다시 누르면 다른 색 묶음, 번호 · 부품은 그대로). 내 프리셋은 차마다 10개, 나눔 코드(HR4.…)로 다른 사람 · 다른 차와 꾸미기를 주고받아요. 위쪽 되돌리기 · 다시 하기(30번) · 「처음과 비교」.', '「무작위 꾸미기」는 도색 · 겹 · 번호 · 부품 중 고른 것은 그대로 두고(무작위에서 고정) 나머지만 바꿔요. 번호: 경주 번호 · 모양 · 글자 색 · 글꼴 · 지붕 번호 · 번호판 글자 · 이름표 / 부품: 휠 색 · 휠 마감 · 캘리퍼 · 창 틴팅 · 창 색 · 전조등 색 · 언더글로.', '모두 처음부터 쓸 수 있어요(해금 없음). 차마다 이 기기에 저장되고, 온라인에선 다른 사람에게도 내 꾸민 차가 보여요. 휠 · 캘리퍼 · 창은 모델에 따로 있는 차만 바꿀 수 있어요.', '이름표: 「다른 차 이름표」를 켜면(이 기기) 경주 중 다른 차 위에 이름표가 떠요 — 각자 정한 글자, 없으면 이름.'] },
    { h: '조작 — 폰', p: ['왼쪽 아래 핸들 판 ◀ ▶: 누르는 동안 부드럽게 꺾여요. 엄지를 떼지 않고 미끄러뜨려도 좌우가 바로 바뀌어요.', '「끌기」 방식(출발 전 화면 · 설정 탭): 왼쪽 큰 칸 아무 데나 대고 좌우로 끄는 만큼 꺾여요(아날로그 — 살짝 끌면 살짝).', '오른쪽 아래: 가속(큰 단추) · 브레이크(멈춘 뒤 계속 누르면 후진) · 드리프트. 여러 손가락으로 동시에 눌러도 돼요.', '「자동 가속」을 켜면 가속 단추가 없어지고 브레이크만 누르면 돼요(처음엔 켜 두기를 권해요). 단추 크기(작게 · 보통 · 크게)와 핸들 위치(왼쪽 · 오른쪽)도 바꿀 수 있어요.', '오른쪽 단추들 위의 아이템 칸(아케이드 요소)을 누르면 아이템을 써요. 위쪽 「카메라」로 시점(가까운 추적 · 먼 추적 · 보닛 · 범퍼 · 운전석 · TV 중계)을 바꿔요. 「복귀」는 차가 걸렸을 때 트랙으로 돌려놔요(2초 넘게 걸리거나, 멈춘 채 거꾸로 서 있거나 트랙에서 멀리 나가면 저절로 — 잠깐 반투명해서 다른 차와 안 부딪혀요). 부딪힘 · 부스트 · 트랙 밖으로 나갈 때 폰이 짧게 떨려요.'] },
    { h: '조작 — PC', p: ['W/↑ 가속 · S/↓ 브레이크·후진 · A·D/←→ 핸들 · Space 드리프트 · R 아이템(아케이드) · Backspace/F 복귀. 게임패드: RT 가속 · LT 브레이크 · 왼쪽 스틱 핸들 · A 드리프트 · X/RB 아이템 · Y 시점. 「⌨ 조작 설정」에서 바꿀 수 있어요.', '시점: Tab(또는 C)으로 가까운 추적 → 먼 추적 → 보닛 → 범퍼 → 운전석 → TV 중계. 마우스 오른쪽 단추를 누른 채 움직이면 자유 시점(차 주위를 돌아봄, 휠 = 거리), 놓으면 원래 시점으로 돌아와요. 자유 시점 중  키를 누르면 그 시점이 고정돼요(놓아도 그 각도로 차를 따라감) —  다시 또는 Tab이면 풀려요.', '꾸미기(PC): 차 위 겹(무늬도)을 누르면 고르고, 끄는 동안 휠을 굴리면 회전(위 = 왼쪽 ↺ · 아래 = 오른쪽 ↻, 5°씩 · Shift 1° · Ctrl 15° 단위). 금빛 손잡이 = 돌리기(Shift 15°) · 크기 · 늘이기. Q/E 회전 · [ ] 크기 · 방향키 옮기기 · Delete 지우기 · Ctrl+D 복제 · Ctrl+C/Ctrl+V 겹 복사 · 붙여넣기 · H 숨기기 · L 잠그기 · B 처음과 비교 · Ctrl+Z/Ctrl+Y 되돌리기/다시. Tab = 앞 · 옆 · 뒤 · 위 · 3/4 보기, 오른쪽 단추 끌기 = 돌려 보기,  = 저절로 돌기 멈춤.'] },
    { h: '운전 요령', p: ['코너 전에 미리 브레이크를 밟고, 꺾으면서 천천히 가속하세요. 핸들을 끝까지 꺾으면 타이어가 버티는 한계만큼 돌아요 — 그보다 빠르면 바깥으로 밀려요(타이어 소리가 커지면 한계예요).', '브레이크를 밟으며 꺾으면 무게가 앞으로 쏠려 앞이 잘 돌고, 뒷바퀴 굴림 차는 느린 코너에서 가속을 세게 하면 꼬리가 나가요(머슬카 · 클래식이 특히).', '다운포스가 큰 차(포뮬러 · 하이퍼카 · GT)는 빠를수록 더 잘 붙고, 작은 차(슈퍼카 · 스트리트 · 클래식)는 고속 코너 전에 충분히 줄여야 해요. 오프로드 차는 잔디 · 자갈에서도 거의 안 느려지지만 크게 기울어요.', '코너 바깥 벽의 노랑 · 주황 · 빨강 화살표 판 = 코너 방향과 세기(빨강이 가장 급함). 긴 직선 끝 급코너 앞에는 150 · 100 · 50m 제동 판이 있어요.', '주행선 안내(출발 전 화면, 보조 「켬」이면 기본 켬): 바닥의 띠가 초록이면 그대로, 노랑이면 곧 줄이기, 빨강이면 지금 브레이크.', '잔디는 미끄럽고 느려요. 코너 바깥 자갈은 더 느려요. 빨강·흰 연석은 밟아도 괜찮아요.', '벽에 부딪혀도 망가지지 않아요. 살짝 스치면 벽을 따라 미끄러지며 속도를 거의 잃지 않고, 세게 부딪히면 튕겨 나가며 속도가 줄어요.'] },
    { h: '드리프트', p: ['코너 입구에서 핸들을 꺾은 채 드리프트 단추(Space)를 짧게 누르면 뒤가 미끄러지며 드리프트가 시작돼요.', '드리프트 중에는 핸들이 각도와 줄을 정해요: 코너 쪽으로 꺾으면 각이 커지고 안쪽으로 파고들고, 핸들을 놓으면 각이 줄며 빠져나오고, 반대로 꺾으면 바로 끝나요. 가속은 계속 밟아 두세요.', '드리프트를 이어 가면 속도계 아래 드리프트 게이지(3칸)가 차요. 깔끔하게(트랙 위에서, 거의 똑바로) 빠져나오면 찬 칸만큼 「드리프트 부스트」 — 짧게 더 빨라져요(1칸 0.75초 · 2칸 1.15초 · 3칸 1.6초). 벽에 부딪히거나 스핀하면 게이지가 사라져요.', '네 바퀴 굴림 차는 각이 작고 안정적, 뒷바퀴 굴림 차는 각이 크고 꼬리가 잘 나가요. 미래차는 부스트가 가장 세요.'] },
    { h: '편하게 달리기', p: ['출발 직후 6초 동안과 사람 ↔ AI 사이 부딪힘은 부드럽게 처리해요: 튕김과 차가 도는 힘이 작아서 AI에게 밀려 스핀하지 않아요. AI는 바로 앞에 사람 차가 있으면 들이받지 않고 속도를 맞춘 뒤 옆으로 추월해요.', '「편한 화면」(고르기 화면 「설정」 탭, 이 기기): 화면 흔들림 · 속도에 따라 넓어지는 시야 · 속도선을 줄여요 — 멀미가 나면 켜세요.', '결과 화면에 바퀴마다 순위 변화(예: 5→3→1)와 가장 많이 올라간 사람이 나와요. 「다시 하기」 한 번이면 같은 설정으로 새 판(맵 · 코스가 무작위면 새 서킷)이에요.'] },
    { h: '슬립스트림', p: ['앞차 뒤(45m 안, 거의 같은 줄)에 붙으면 공기 저항이 최대 42% 줄어 더 빨라져요. 충분히 붙었다가 옆으로 빠져 추월하세요. 화면 아래 파란 「슬립」 막대가 차요.'] },
    { h: '주행 보조', p: ['출발 전 화면에서 이 기기만 바꿔요.', '켬: 코너 앞에서 너무 빠르면 자동 브레이크 · 트랙 가장자리에서 살짝 되돌려 줌 · 강한 미끄럼 방지와 구동력 조절 · 드리프트 각은 작게(최대 약 40°).', '일부: 코너에 확실히 너무 빠를 때만 살짝 자동 브레이크 · 가벼운 미끄럼 방지 · 구동력 조절 · 드리프트 각 상한(약 55°) — 스핀하지 않아요.', '끔: 그대로. 드리프트 각을 너무 키우면(약 70°) 스핀하고, 뒷바퀴 굴림 차는 가속만으로도 꼬리가 크게 나가요.'] },
    { h: '그래픽', p: ['출발 전 화면(또는 설정 화면의 「그래픽 품질」)에서 이 기기만 바꿔요. 낮음(폰 권장) · 보통 · 높음(PC 권장 — 그림자 · 실내까지).', '원본 모델(차 한 대 수십만 삼각형 · 수십 MB)은 폰 메모리 때문에 싣지 않고, 「높음」이 원본에 가장 가까워요. 차 모델은 그 판에 나오는 차만 불러와요.', '연기 · 스키드 자국 · 불꽃 · 물보라 수도 단계마다 달라요.', '차 표식(이 기기): 「스폰서 로고」 = 스폰서 스티커 · 번호판(구구이 R은 깨끗한 금빛 · 검정 도색으로), 「상표 글자 · 엠블럼」 = 차에 붙은 상표 글자와 엠블럼. 둘 다 기본 켬. 도색 그림에 그려져 있는 글자는 끌 수 없어요.'] },
    { h: '날씨', p: ['시간대(낮·노을·밤)와 날씨(맑음·비)는 기본 무작위. 밤엔 전조등이 켜지고(도시는 창문 불빛), 비가 오면 접지가 18% 줄어 미끄러워요.'] },
    { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 골라요. AI마다 제동 시점·공격성·추월 버릇이 달라요. 「접전」이 켜져 있으면 사람 주위로 무리를 지어 달려요.'] },
    { h: '끝나는 조건', p: ['모두 들어오면 끝나요. 사람이 모두 들어오면 4초 뒤, 또는 경주에 나온 클래스마다 1위가 들어오고 40초가 지나면 끝나요. 못 들어온 차는 달린 거리 순이에요.'] },
    { h: '만든 사람', p: [
      '차 3D 모델(모두 Sketchfab, 게임에 맞게 삼각형 · 결 크기를 줄이고 바퀴를 떼어 냄): ' + CARS.map((c) => '「' + c.model + '」 ' + c.by + ' (' + c.lic + ')').join(' · ') + '.',
      'CC BY-NC(비상업) 모델은 상업적으로 쓰지 않고, -SA 모델은 고친 모델도 같은 조건이에요. Sketchfab Standard 모델은 게임 안에서만 쓰고 따로 나누지 않아요. 원본 주소: app/assets/hyperrace/CREDITS.txt',
      '하늘(HDRI) · 나무: Poly Haven (CC0) — alps_field · grasslands_sunset · clarens_night_02 · fouriesburg_mountain_cloudy · fir_tree_01 · jacaranda_tree(그림으로 구워 씀).',
      '맵: Poly Haven (CC0) 하늘 kloofendal_48d_partly_cloudy · sunflowers · belfast_sunset · kloppenheim_02 · overcast_soil(모두 puresky) · 식물 · 바위 quiver_tree_01 · pine_tree_01 · island_tree_01 · searsia_burchellii · wild_rooibos_bush · namaqualand_boulder_02/04 · namaqualand_cliff_01 · boulder_01, ambientCG (CC0) Ground080 · Rock029 · Rock030 · Snow010A · Ground023 · PavingStones111 · Ground109 · Facade018A · Bark015(직접 만든 야자수 줄기).',
      '바닥 결: ambientCG (CC0) — Asphalt025C · Grass004 · Gravel022 · Concrete034.',
      '광고판 · 깃발 탑 · 천막 · 조명탑 · 체크 깃발: Kenney Racing Kit (CC0). 관중석 · 차고 · 출발 신호 문은 직접 만듦.',
      '엔진 소리: freesound.org #369054 AndrewAlexander (CC0) · 충돌: Kenney Impact Sounds (CC0).',
      '3D 엔진: three.js (MIT). 파일마다 출처: app/assets/hyperrace/CREDITS.txt'] },
  ];

  /* ======================= 조작 ======================= */
  const CONTROLS = [
    { id: 'gas', label: '가속', keys: ['KeyW', 'ArrowUp'], pad: ['rt', 'ry-'] },
    { id: 'brake', label: '브레이크 · 후진', keys: ['KeyS', 'ArrowDown'], pad: ['lt', 'ry+'] },
    { id: 'left', label: '왼쪽', keys: ['KeyA', 'ArrowLeft'], pad: ['lx-', 'left'] },
    { id: 'right', label: '오른쪽', keys: ['KeyD', 'ArrowRight'], pad: ['lx+', 'right'] },
    { id: 'hb', label: '드리프트(핸드브레이크)', keys: ['Space'], pad: ['a'] },
    { id: 'item', label: '아이템 쓰기(아케이드)', keys: ['KeyR'], pad: ['x', 'rb'] },
    { id: 'cam', label: '시점 바꾸기(정해진 시점)', keys: ['Tab', 'KeyC'], pad: ['y'] },
    { id: 'look', label: '자유 시점 고정 켬/끔(우클릭 누른 채)', keys: ['Backquote'], pad: ['rs'] },
    { id: 'reset', label: '트랙으로 복귀', keys: ['Backspace', 'KeyF'], pad: ['back'] },
  ];

  /* ======================= 화면 입구: 3D를 불러와 view.js에 넘김 ======================= */
  const API = { THEMES, STYLES, LMK, LM, trackName, roadH, CARS, CAR, CLS, CORR, phOf, idealLap, scaledPh, bopFactors, packPace, TIERS, GRAV, DT, DS, DLV, BST, steerK, clamp, wrapA, prng, kmh, fmtT, genTrack, speedProfile, locate, newCar, stepCar, collide, draftFor, progress, ranking, resetToTrack, aiInput, assistBrake, habits, makeWorld, worldStep, aiPicks, makeGrid, surfaceAt, SURF, store, gfxTier, assistLevel, touchOnly, pack, loadScript, trackSize, minRadius, gripK, custClean, custRandom, CUST, carStats, custTpl, layerClean, custBytes, custNet, custCode, custDecode, layerX,
    ITEMS, IT, ITK, itemRoll, itemHit, useItem, addHazard, boxStep, itemTick, aiItem, carNear };
  function mount(root, api) {
    const h = L.h;
    let view = null, dead = false, last = null, lastPrev = null;
    const box = h('div', { style: { position: 'absolute', inset: '0', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '12px', background: 'radial-gradient(circle at 50% 40%,#2b2238,#120e18)', color: 'var(--ink)', zIndex: 5, textAlign: 'center', padding: '16px' } });
    const t1 = h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '26px', letterSpacing: '1px' }, text: '하이퍼 레이스' });
    const t2 = h('div', { class: 'muted', style: { fontSize: '13px' }, text: '3D 엔진 불러오는 중…' });
    const bar = h('div', { style: { width: '220px', height: '6px', borderRadius: '3px', background: 'rgba(255,255,255,.12)', overflow: 'hidden' } }, h('div', { style: { width: '8%', height: '100%', background: 'var(--brass)', transition: 'width .2s' } }));
    box.append(t1, t2, bar);
    root.append(box);
    const prog = (f, txt) => { if (bar.firstChild) bar.firstChild.style.width = Math.round(clamp(f, 0.05, 1) * 100) + '%'; if (txt) t2.textContent = txt; };
    if (!webglOK()) { prog(1, '이 기기(브라우저)에서는 3D 그래픽(WebGL)을 켤 수 없어요.'); }
    else loadCore().then(() => {
      if (dead) return;
      prog(0.25, '차 · 서킷 준비 중…');
      view = G.HR_VIEW.mount(root, api, API, { progress: prog, ready() { box.remove(); } });
      if (last) view.update(last, lastPrev);
    }).catch((e) => { prog(1, '3D 파일을 불러오지 못했어요. (' + (e && e.message || e) + ')'); });
    return {
      update(s, p) { last = s; lastPrev = p; if (view) view.update(s, p); },
      destroy() { dead = true; if (view) view.destroy(); box.remove(); },
      pause() { if (view && view.pause) view.pause(); },
      resume() { if (view && view.resume) view.resume(); },
    };
  }

  const ICON = '<path fill="currentColor" d="M12 34c2-7 7-12 16-13l9-1c4 0 7 3 9 7l2 4c2 1 3 3 3 5v3h-5a5 5 0 0 0-10 0H22a5 5 0 0 0-10 0H9v-3c0-1 1-2 3-2zm10-11-4 6h10v-7zm9-1v7h11l-3-5c-1-1-2-2-4-2z"/><circle cx="17" cy="40" r="3.6" fill="currentColor"/><circle cx="41" cy="40" r="3.6" fill="currentColor"/><path d="M6 46h44" stroke="currentColor" stroke-width="2" stroke-dasharray="4 4" opacity=".6"/>';

  if (L) L.register({
    id: 'hyperrace', name: '하이퍼 레이스', tag: '3D 레이싱', cat: '스포츠', icon: ICON, tint: '#3a1d14',
    blurb: '실제 3D 차 모델 26대(F1 · 하이퍼카 · GT · 미래차 · 슈퍼카 · 스트리트 · 클래식 · 오프로드)로 달리는 서킷 레이스. 맵 7개(해안 · 협곡 · 설산 · 숲 · 야경 도시 …) · 명소 코스 14개(등대 · 점프대 · 고가도로 …)와 판마다 새 서킷, 성능 맞춤으로 어떤 차로도 우승 가능, 도색 · 무늬 · 스티커 · 손그림 꾸미기(나눔 코드), 낮·노을·밤과 비. 1~8대.',
    time: '4–8분', landscape: true, realtime: true, aiDelay: 0, mood: false, ambient: false, sidePanel: false,
    minPlayers: 1, maxPlayers: 8, defaultPlayers: 4,
    options: [
      { id: 'laps', label: '바퀴', choices: [1, 2, 3, 4, 5].map((k) => ({ v: String(k), label: k + '바퀴' })), def: '3' },
      { id: 'map', label: '맵', tip: '서킷이 놓인 곳. 무작위면 판마다 바뀌어요.', choices: [{ v: 'rnd', label: '무작위' }].concat(Object.keys(THEMES).map((k) => ({ v: k, label: THEMES[k].nm }))), def: 'rnd' },
      { id: 'course', label: '코스', tip: '무작위 = 명소 코스(이름 있는 서킷) 또는 새로 만든 서킷 / 무작위 생성 = 판마다 새 서킷 / 명소 코스 = 맵마다 2개씩 손으로 만든 서킷(고르면 맵도 그 코스로) / 고속 · 테크니컬 · 시가지 = 새로 만드는 서킷의 성격.',
        choices: [{ v: 'rnd', label: '무작위' }, { v: 'gen', label: '무작위 생성' }, { v: 'lm', label: '명소 코스' }].concat(Object.keys(STYLES).map((k) => ({ v: k, label: STYLES[k] })), LMK.map((l) => ({ v: 'lm:' + l.id, label: l.nm }))), def: 'rnd' },
      { id: 'arc', label: '아케이드 요소', tip: '아이템 상자(니트로 · 기름 웅덩이 · 방해 전파 · 접지 타이어 · 충격 범퍼 · 연막 · 슬립 자석) · 부스트 발판(밟으면 잠깐 빨라짐) · 작은 점프대. 명소 코스의 점프대는 언제나 있어요.', choices: [{ v: 'off', label: '끔' }, { v: 'on', label: '켬' }], def: 'off' },
      { id: 'tod', label: '시간대', choices: [{ v: 'rnd', label: '무작위' }, { v: 'day', label: '낮' }, { v: 'dusk', label: '노을' }, { v: 'night', label: '밤' }], def: 'rnd' },
      { id: 'wx', label: '날씨', choices: [{ v: 'rnd', label: '무작위' }, { v: 'sun', label: '맑음' }, { v: 'rain', label: '비 (미끄러움)' }], def: 'rnd' },
      { id: 'cars', label: '클래스', tip: 'AI가 고르는 차의 클래스(고르기 화면도 이 클래스부터 보여요). 사람은 어떤 차든 직접 골라요.', choices: [{ v: 'mix', label: '클래스 섞기' }, { v: 'any', label: '아무 차나' }, { v: 'F1', label: '포뮬러' }, { v: 'HY', label: '하이퍼카' }, { v: 'SC', label: '슈퍼카' }, { v: 'GT', label: 'GT' }, { v: 'FU', label: '미래차' }, { v: 'ST', label: '스트리트' }, { v: 'CL', label: '클래식' }, { v: 'OF', label: '오프로드' }], def: 'mix' },
      { id: 'bop', label: '성능 맞춤', tip: '여러 클래스가 섞인 경주에서 차마다 빠르기를 그 서킷에 맞춰 같게(어떤 차로도 우승 가능). 끄면 클래스 실력 그대로 — 빠른 클래스가 앞에서 출발하고 클래스별 순위로 겨뤄요.', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔 (클래스 그대로)' }], def: 'on' },
      { id: 'pack', label: '접전', tip: 'AI가 가장 앞선 사람과 너무 멀어지면 아주 조금 늦추거나 몰아붙여 무리를 지어요(최대 몇 %). 차 성능은 그대로예요.', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔' }], def: 'on' },
    ],
    setupExtra(opts, ctx) {
      if (ctx && ctx.readOnly) return null;
      const h = L.h, wrap = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center', margin: '6px 0' } });
      const draw = () => {
        wrap.innerHTML = '';
        wrap.append(h('span', { class: 'muted', style: { fontSize: '13px', marginRight: '4px' }, text: '그래픽 품질(이 기기)' }));
        for (const t of TIERS) wrap.append(h('button', { class: 'btn sm' + (gfxTier() === t.id ? ' primary' : ''), title: t.tip, style: { minHeight: '44px' }, text: t.nm, onclick() { store.set('gfx', t.id); draw(); } }));
        wrap.append(h('span', { class: 'muted', style: { fontSize: '13px', margin: '0 4px 0 8px' }, text: '차 표식' }));
        for (const [k, nm] of [['logo', '스폰서 로고'], ['badge', '상표 · 엠블럼']]) { const on = store.get(k, '1') !== '0'; wrap.append(h('button', { class: 'btn sm' + (on ? ' primary' : ''), title: k === 'logo' ? '스폰서 스티커 · 번호판' : '차에 붙은 상표 글자 · 엠블럼', style: { minHeight: '44px' }, text: nm + (on ? ' 켬' : ' 끔'), onclick() { store.set(k, on ? '0' : '1'); draw(); } })); }
      };
      draw();
      return wrap;
    },
    controls: CONTROLS,
    quick: ['차를 고르고 꾸민 뒤 신호등이 꺼지면 출발 — 정해진 바퀴를 가장 먼저 돌면 우승', '폰: 왼쪽 ◀ ▶ 핸들(또는 끌기) · 오른쪽 가속/브레이크/드리프트 (자동 가속 켤 수 있음)', '코너 전에 브레이크, 급코너는 드리프트 → 깔끔하게 빠져나오면 부스트', '앞차 뒤에 붙으면 슬립스트림으로 빨라져요'],
    rules: RULES,
    codex,
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result,
    mount,
    _t: API,
  });
  G.HYPERRACE = API;
  if (typeof module === 'object' && module) module.exports = API;
})();
