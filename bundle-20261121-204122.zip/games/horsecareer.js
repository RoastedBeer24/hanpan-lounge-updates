/* 경주마 육성 커리어 (horsecareer) — 한 마리의 경주마를 2세 데뷔부터 4세 은퇴까지 키우는 육성 시뮬레이션.
   체계 참고: 육성 시뮬레이션의 훈련·휴식·출전 일정 구조만(인물·이름·그림 없음, 말은 실제 말).
   경주 장면은 경마(horserace)의 위에서 보는 말 그림·털색을 옮겨 와 단순하게 다시 그림(원본 파일은 건드리지 않음).
   턴 = 반달(압축 모드는 한 달). 여럿이면 동시에 고르고(actor 배열) 같은 큰 경주에서 만난다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const ID = 'horsecareer';

  /* ======================= 기본 자료 ======================= */
  const jo = (w, a, b) => { w = String(w == null ? '' : w); const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };   // 이름 + 조사(받침 있으면 a)
  const SN = ['스피드', '스태미나', '파워', '근성', '판단력'];
  const GL = 'ABCDEFG';
  const APT_SPD = [1, 0.9, 0.8, 0.6, 0.4, 0.2, 0.1];     // 거리 적성 → 스피드 반영
  const APT_POW = [1, 0.9, 0.8, 0.7, 0.5, 0.3, 0.1];     // 주로 적성 → 파워 반영
  const APT_WIT = [1, 0.85, 0.75, 0.6, 0.4, 0.2, 0.1];   // 각질 적성 → 판단력 반영
  const APT_BASE = [1, 0.997, 0.992, 0.985, 0.975, 0.96, 0.95];
  const DN = ['단거리', '마일', '중거리', '장거리'], SFN = ['잔디', '더트'], STY = ['선행', '선입', '추입'];
  const STY_D = ['앞에서', '중단에서', '뒤에서'];
  const SPT = ['이르게', '보통', '늦게', '기수 판단'];
  const POSN = ['앞에서(선행)', '중단(선입)', '뒤에서(추입)', '기수 판단'];
  const dcat = (d) => (d <= 1400 ? 0 : d <= 1800 ? 1 : d <= 2400 ? 2 : 3);
  const MOODN = ['최악', '나쁨', '보통', '좋음', '최상'];
  const MOOD_TR = [0.8, 0.9, 1, 1.1, 1.2], MOOD_ST = [0.92, 0.96, 1, 1.04, 1.08];
  const GRN = ['신마', '미승리', '1승 클래스', 'L', 'G3', 'G2', 'G1'];
  const PRIZE = [700, 550, 1000, 2400, 4000, 6500, 13000];
  const SHARE = [1, 0.4, 0.25, 0.15, 0.1];
  const FAME = [30, 25, 50, 120, 250, 400, 900];
  const FIELD = [10, 11, 11, 12, 13, 13, 14];
  const TEMPER = [{ n: '차분함', d: '컨디션이 잘 흔들리지 않음 · 출발이 안정적' }, { n: '예민함', d: '컨디션 기복이 큼 · 가끔 출발이 늦음 · 훈련 효과 조금 큼' }, { n: '승부욕', d: '막판 경합에 강함 · 훈련 피로가 조금 큼' }];
  const AILN = ['', '기침 감기', '식욕 부진', '발굽 열감', '밤잠 설침', '다리 붓기'];
  const AILD = ['', '턴마다 컨디션이 떨어질 수 있음', '훈련 효과 30% 감소', '훈련 실패율 +10%', '컨디션이 오르지 않음', '훈련 실패율 +8% · 경주 체력 소모 증가'];
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  /* 털색(경마 게임의 털색 표를 옮김): c 몸, m 갈기·꼬리 */
  const CO = [
    { n: '갈색', c: '#8a5228', m: '#1c120c' }, { n: '진갈색', c: '#4a2e1c', m: '#140c08' }, { n: '흑갈색', c: '#2e2226', m: '#0c090a' },
    { n: '밤색', c: '#b0592a', m: '#c9844a' }, { n: '회색', c: '#bdb8b2', m: '#8d8780' }, { n: '청모', c: '#8d8f93', m: '#4a4c50' },
  ];
  /* 경주용 복색(NPC) — 탁한 색 위주 */
  const SILK = ['#6b3a35', '#2f4a63', '#5a5f2e', '#7a6a3a', '#3f3a5c', '#2e5a4e', '#6a4a2a', '#5c2f45', '#45525a', '#7b5a4a', '#3a4a2a', '#5e4a63', '#2a3a4a', '#6e6150'];

  /* 이름 — 사람 이름 같은 말은 쓰지 않음(자연·사물·기상) */
  const NA = ['새벽', '은빛', '북녘', '푸른', '검은', '붉은', '먼', '고요한', '늦가을', '첫눈', '강철', '황금', '청동', '하얀', '깊은', '높은', '남쪽', '서쪽', '한밤', '여름', '겨울', '긴', '마른', '젖은', '외딴', '옛', '새', '빠른', '굳센', '잿빛'];
  const NB = ['바람', '별', '강', '창', '방패', '파도', '종', '언덕', '들판', '횃불', '번개', '등대', '구름', '다리', '화살', '왕관', '깃발', '노을', '숲', '폭풍', '갈기', '모래', '돛', '닻', '봉우리', '협곡', '서리', '안개', '불꽃', '물결', '항로', '수평선', '등불', '지평선', '철새', '천둥'];

  /* 부계(아비 계열) — 적성 틀: 거리 4(단·마·중·장) + 주로 2(잔디·더트) + 각질 3(선행·선입·추입) */
  const SIRES = [
    { n: '질풍', a: 'ABEG' + 'AE' + 'ABD', g: [1.15, 0.9, 1.05, 1, 0.95], ty: -1, d: '단거리 스피드 · 일찍 피는 편' },
    { n: '번개창', a: 'BADF' + 'AD' + 'BAC', g: [1.1, 0.95, 1.05, 1, 1], ty: 0, d: '마일의 선행 · 출발이 빠름' },
    { n: '은하수', a: 'DBAC' + 'AD' + 'CAB', g: [1.05, 1.05, 1, 1, 1], ty: 0, d: '중거리 균형형' },
    { n: '먼바다', a: 'FDBA' + 'AE' + 'CBA', g: [0.95, 1.2, 0.95, 1.05, 1], ty: 1, d: '장거리 스태미나 · 늦게 피는 편' },
    { n: '붉은모래', a: 'BBCE' + 'EA' + 'ABC', g: [1, 0.95, 1.2, 1.05, 0.95], ty: 0, d: '더트의 힘' },
    { n: '철교', a: 'DBAD' + 'DA' + 'BAC', g: [0.95, 1.05, 1.1, 1.15, 0.95], ty: 0, d: '더트 중거리 · 근성' },
    { n: '겨울나무', a: 'GCBA' + 'AE' + 'DCA', g: [1, 1.15, 0.95, 1.05, 1.05], ty: 1, d: '장거리의 추입' },
    { n: '청동방패', a: 'DBAB' + 'AC' + 'CAB', g: [1, 1.05, 1, 1.15, 1], ty: 0, d: '선입의 근성' },
    { n: '새벽종', a: 'CAAC' + 'AE' + 'DBA', g: [1.1, 1, 1, 0.95, 1.1], ty: 0, d: '마일~중거리 추입 · 순발력' },
    { n: '돌풍언덕', a: 'ACFG' + 'CA' + 'ABE', g: [1.15, 0.9, 1.1, 1, 0.9], ty: -1, d: '더트 단거리 선행' },
  ];
  /* 모계(어미 쪽 특징) */
  const DAMS = [
    { n: '스피드 모계', d: '스피드 성장 +8%', f: (o) => { o.gr[0] *= 1.08; } },
    { n: '스태미나 모계', d: '스태미나 성장 +8% · 긴 거리 적성 한 단계 위', f: (o) => { o.gr[1] *= 1.08; up(o, 3); } },
    { n: '근성 모계', d: '근성 성장 +8%', f: (o) => { o.gr[3] *= 1.08; } },
    { n: '튼튼한 모계', d: '부상 위험 40% 감소', f: (o) => { o.tough = 1; } },
    { n: '기질 좋은 모계', d: '컨디션이 덜 흔들림', f: (o) => { o.calm = 1; } },
    { n: '더트 모계', d: '더트 적성 한 단계 위', f: (o) => { up(o, 5); } },
    { n: '만성 모계', d: '늦게 피는 쪽으로', f: (o) => { o.ty = Math.min(1, o.ty + 1); } },
    { n: '조숙 모계', d: '일찍 피는 쪽으로', f: (o) => { o.ty = Math.max(-1, o.ty - 1); } },
  ];
  function up(o, i) { const a = o.apt.split(''); a[i] = GL[Math.max(0, GL.indexOf(a[i]) - 1)]; o.apt = a.join(''); }
  const TYN = ['빨리 피는 형', '보통 형', '늦게 피는 형'];
  const YEAR_MUL = [[1.15, 1, 0.85], [1, 1, 1], [0.85, 1, 1.18]];

  /* 훈련: 주 능력치·보조 능력치·체력 소모 */
  const TRAIN = [
    { n: '스피드', g: [32, 0, 12, 0, 0], hp: 21, d: '주로 직선 질주 · 스피드와 파워' },
    { n: '스태미나', g: [0, 30, 0, 12, 0], hp: 20, d: '긴 거리 구보 · 스태미나와 근성' },
    { n: '파워', g: [0, 12, 30, 0, 0], hp: 22, d: '언덕길 · 수영 · 파워와 스태미나' },
    { n: '근성', g: [9, 0, 9, 30, 0], hp: 21, d: '병주 경합 · 근성 중심, 스피드·파워 조금' },
    { n: '판단력', g: [9, 0, 0, 0, 27], hp: -4, d: '게이트 · 코스 적응 · 체력이 조금 회복됨' },
  ];
  const CARE = [
    { k: 'rest', n: '휴식', d: '체력 크게 회복 · 가끔 컨디션 상승' },
    { k: 'graze', n: '방목', d: '컨디션 한 단계 상승 · 체력 조금 회복' },
    { k: 'vet', n: '진료', d: '상태 이상 치료 · 체력 조금 회복' },
    { k: 'ride', n: '기승 연습', d: '기수와 호흡 +10 · 판단력 조금 · 체력 조금 소모' },
  ];
  /* 스태프(훈련장에 무작위로 나타나 그 훈련 효과를 올림) — 역할 이름만 */
  const STAFF = [
    { n: '조교 보조', k: 0, d: '스피드 훈련 담당' }, { n: '지구력 담당', k: 1, d: '스태미나 훈련 담당' },
    { n: '기승 담당', k: 2, d: '파워 훈련 담당' }, { n: '마필 관리사', k: 3, d: '근성 훈련 담당' }, { n: '게이트 담당', k: 4, d: '판단력 훈련 담당' },
  ];
  /* 기수 — 호흡(0~100)이 오를수록 능력이 하나씩 열림 */
  const JOCKEYS = [
    { n: '노련한 선행 기수', w: 88, rr: 1, sp: 'front', d: '선행 작전에 강함' },
    { n: '추입 명수', w: 84, rr: 1, sp: 'close', d: '뒤에서 끌어올리는 막판' },
    { n: '장거리 전문 기수', w: 82, rr: 1, sp: 'long', d: '2400m 이상에서 체력 절약' },
    { n: '더트 전문 기수', w: 80, rr: 1, sp: 'dirt', d: '더트 경주에 강함' },
    { n: '단거리 전문 기수', w: 80, rr: 1, sp: 'short', d: '1600m 이하 가속' },
    { n: '신예 기수', w: 60, rr: 1.8, sp: 'young', d: '판단은 서툴지만 호흡이 빨리 오름' },
    { n: '큰 무대의 기수', w: 93, rr: 0.7, sp: 'big', d: 'G1에서 막판이 강함 · 호흡이 느리게 오름' },
  ];
  const JSP = {
    front: ['선행 숙련 Ⅰ: 선행일 때 초중반 속도 +0.6%', '선행 숙련 Ⅱ: 선행일 때 초중반 속도 +1.2%'],
    close: ['추입 숙련 Ⅰ: 추입일 때 스퍼트 +0.12m/s', '추입 숙련 Ⅱ: 추입일 때 스퍼트 +0.25m/s'],
    long: ['장거리 숙련 Ⅰ: 2400m 이상 체력 소모 −3%', '장거리 숙련 Ⅱ: 2400m 이상 체력 소모 −6%'],
    dirt: ['더트 숙련 Ⅰ: 더트에서 파워 +40', '더트 숙련 Ⅱ: 더트에서 파워 +80 · 속도 +0.3%'],
    short: ['단거리 숙련 Ⅰ: 1600m 이하 가속 +8%', '단거리 숙련 Ⅱ: 1600m 이하 가속 +15%'],
    young: ['패기 Ⅰ: 판단력 +40', '패기 Ⅱ: 판단력 +80'],
    big: ['큰 무대 Ⅰ: G1에서 스퍼트 +0.1m/s', '큰 무대 Ⅱ: G1에서 스퍼트 +0.2m/s'],
  };
  const JTIER = [20, 40, 60, 80, 100];
  function jockeyPerks(j) {
    const J = JOCKEYS[j], s = JSP[J.sp];
    return ['출발 호흡: 게이트 반응이 빨라짐', s[0], '진로 읽기: 막힘에서 빨리 빠져나옴', s[1], '인마일체: 경주 내내 속도 +0.5%'];
  }

  /* 능력(조교 노트) — 훈련·경주로 얻는 노트 점수(SP)로 익힘. 앞 능력이 있어야 다음 능력 */
  const ABIL = [
    { id: 'a1', b: 0, n: '직선 가속', c: 120, d: '마지막 직선에서 가속 +25%' },
    { id: 'a2', b: 0, n: '스퍼트 속도', c: 170, r: 'a1', d: '스퍼트 속도 +0.15m/s' },
    { id: 'a3', b: 0, n: '추월 감각', c: 200, r: 'a2', d: '진로 바꾸기가 빠르고 앞을 멀리 봄' },
    { id: 'a4', b: 0, n: '결승 질주', c: 300, r: 'a3', d: '마지막 200m 속도 +0.3m/s' },
    { id: 'b1', b: 1, n: '출발 능숙', c: 110, d: '출발 지연이 없고 첫 가속이 길게 이어짐' },
    { id: 'b2', b: 1, n: '코너 능숙', c: 160, r: 'b1', d: '코너에서 속도 +0.12m/s' },
    { id: 'b3', b: 1, n: '자리 잡기', c: 190, r: 'b2', d: '원하는 위치로 붙는 힘 +50%' },
    { id: 'b4', b: 1, n: '흐름 읽기', c: 260, r: 'b3', d: '판단력 +15% · 기수의 스퍼트 판단 오차 절반' },
    { id: 'c1', b: 2, n: '숨 고르기', c: 140, d: '경주 중간 지점에서 체력 3.5% 회복' },
    { id: 'c2', b: 2, n: '무거운 주로', c: 140, d: '무거운·불량 주로의 감속과 소모 없음' },
    { id: 'c3', b: 2, n: '막판 근성', c: 220, r: 'c1', d: '바닥난 뒤 속도 +0.5m/s · 경합 보너스 1.5배' },
    { id: 'c4', b: 2, n: '장거리 페이스', c: 240, r: 'c1', d: '2400m 이상에서 체력 소모 −6%' },
    { id: 'd1', b: 3, n: '더트 적응', c: 180, d: '더트 적성 한 단계 위(최대 A)' },
    { id: 'd2', b: 3, n: '거리 연장', c: 220, d: '가장 잘 맞는 거리보다 한 칸 긴 거리 적성 한 단계 위' },
    { id: 'd3', b: 3, n: '단거리 집중', c: 180, d: '1600m 이하 스퍼트 +0.2m/s' },
  ];
  const ABR = ['속도', '운영', '체력', '적성'];
  const ABI = {}; ABIL.forEach((a, i) => { ABI[a.id] = i; });
  const hasAb = (h, id) => h.ab.indexOf(id) >= 0;

  /* ----- 큰 경주(중상) 일정: k 열쇠, g 4 G3 / 5 G2 / 6 G1, ag '2' 2세 · '3' 3세 · 'o' 3세 이상(3세는 6월부터), m 월, hf 0 전반 1 후반,
     d 거리, sf 0 잔디 1 더트, tr 우선 출주권을 주는 G1 열쇠(tn 몇 착까지), c 삼관 차례, pz 1착 상금(만 원) ----- */
  const GR = [
    // 2세
    { k: 'j1', n: '아침이슬 스테이크스', g: 4, ag: '2', m: 8, hf: 1, d: 1200, sf: 0 },
    { k: 'j2', n: '들국화 스테이크스', g: 4, ag: '2', m: 10, hf: 0, d: 1800, sf: 0, tr: 'J2', tn: 2 },
    { k: 'j3', n: '모래시계 스테이크스', g: 4, ag: '2', m: 10, hf: 1, d: 1400, sf: 1, tr: 'J3', tn: 2 },
    { k: 'j4', n: '은방울 컵', g: 5, ag: '2', m: 11, hf: 0, d: 1400, sf: 0, tr: 'J1', tn: 3 },
    { k: 'j5', n: '서리꽃 스테이크스', g: 5, ag: '2', m: 11, hf: 1, d: 2000, sf: 0, tr: 'J2', tn: 3 },
    { k: 'J1', n: '유성 마일', g: 6, ag: '2', m: 12, hf: 0, d: 1600, sf: 0, pz: 7000 },
    { k: 'J2', n: '새벽별 스테이크스', g: 6, ag: '2', m: 12, hf: 1, d: 2000, sf: 0, pz: 7000 },
    { k: 'J3', n: '2세 더트 선수권', g: 6, ag: '2', m: 12, hf: 1, d: 1600, sf: 1, pz: 7000 },
    // 3세 한정
    { k: 'k1', n: '매화 스테이크스', g: 4, ag: '3', m: 2, hf: 1, d: 1800, sf: 0, tr: 'C1', tn: 2 },
    { k: 'k2', n: '봄바람 기념', g: 5, ag: '3', m: 3, hf: 0, d: 2000, sf: 0, tr: 'C1', tn: 3 },
    { k: 'k3', n: '벚꽃 마일', g: 5, ag: '3', m: 3, hf: 1, d: 1400, sf: 0, tr: 'C0', tn: 3 },
    { k: 'C1', n: '청춘 클래식', g: 6, ag: '3', m: 4, hf: 0, d: 2000, sf: 0, c: 1, pz: 20000 },
    { k: 'k4', n: '푸른잎 트라이얼', g: 5, ag: '3', m: 4, hf: 1, d: 2400, sf: 0, tr: 'C2', tn: 3 },
    { k: 'C0', n: '봄 마일 클래식', g: 6, ag: '3', m: 5, hf: 0, d: 1600, sf: 0, pz: 16000 },
    { k: 'C2', n: '왕관 더비', g: 6, ag: '3', m: 5, hf: 1, d: 2400, sf: 0, c: 2, pz: 30000 },
    { k: 'k5', n: '모래바람 스테이크스', g: 4, ag: '3', m: 6, hf: 0, d: 1800, sf: 1, tr: 'CD', tn: 3 },
    { k: 'CD', n: '청춘 더트 더비', g: 6, ag: '3', m: 7, hf: 0, d: 2000, sf: 1, pz: 16000 },
    { k: 'k6', n: '가을바람 기념', g: 5, ag: '3', m: 9, hf: 1, d: 2200, sf: 0, tr: 'C3', tn: 3 },
    { k: 'C3', n: '단풍 스테이어 클래식', g: 6, ag: '3', m: 10, hf: 1, d: 3000, sf: 0, c: 3, pz: 20000 },
    // 3세 이상
    { k: 'p1', n: '새해 핸디캡', g: 4, ag: 'o', m: 1, hf: 0, d: 2000, sf: 0 },
    { k: 'p2', n: '설원 스테이크스', g: 4, ag: 'o', m: 1, hf: 1, d: 1400, sf: 1, tr: 'O1', tn: 2 },
    { k: 'p3', n: '눈꽃 기념', g: 5, ag: 'o', m: 2, hf: 0, d: 2500, sf: 0, tr: 'O4', tn: 2 },
    { k: 'O1', n: '겨울 더트 컵', g: 6, ag: 'o', m: 2, hf: 1, d: 1600, sf: 1 },
    { k: 'p4', n: '봄빛 스프린트', g: 4, ag: 'o', m: 3, hf: 0, d: 1200, sf: 0, tr: 'O2', tn: 2 },
    { k: 'p5', n: '목련 기념', g: 5, ag: 'o', m: 3, hf: 0, d: 2000, sf: 0, tr: 'O3', tn: 2 },
    { k: 'O2', n: '봄 스프린트 컵', g: 6, ag: 'o', m: 3, hf: 1, d: 1200, sf: 0 },
    { k: 'p6', n: '산등성이 기념', g: 5, ag: 'o', m: 3, hf: 1, d: 3000, sf: 0, tr: 'O4', tn: 2 },
    { k: 'O3', n: '봄 중거리 컵', g: 6, ag: 'o', m: 4, hf: 0, d: 2000, sf: 0 },
    { k: 'O4', n: '봄 장거리 왕관', g: 6, ag: 'o', m: 4, hf: 1, d: 3200, sf: 0, pz: 20000 },
    { k: 'p7', n: '신록 스테이크스', g: 5, ag: 'o', m: 5, hf: 0, d: 1400, sf: 0, tr: 'O5', tn: 2 },
    { k: 'p8', n: '모래언덕 스테이크스', g: 4, ag: 'o', m: 5, hf: 1, d: 1800, sf: 1 },
    { k: 'O5', n: '초여름 마일 컵', g: 6, ag: 'o', m: 6, hf: 0, d: 1600, sf: 0 },
    { k: 'O6', n: '여름 그랑프리', g: 6, ag: 'o', m: 6, hf: 1, d: 2200, sf: 0, pz: 22000 },
    { k: 'O7', n: '한여름 더트 컵', g: 6, ag: 'o', m: 7, hf: 1, d: 2000, sf: 1 },
    { k: 'p9', n: '한여름 스프린트', g: 4, ag: 'o', m: 8, hf: 0, d: 1200, sf: 0 },
    { k: 'p10', n: '해바라기 마일', g: 4, ag: 'o', m: 8, hf: 1, d: 1600, sf: 0 },
    { k: 'p11', n: '바닷바람 기념', g: 5, ag: 'o', m: 8, hf: 1, d: 2000, sf: 0 },
    { k: 'p12', n: '초가을 스프린트', g: 5, ag: 'o', m: 9, hf: 0, d: 1200, sf: 0, tr: 'O8', tn: 2 },
    { k: 'O8', n: '가을 스프린트 컵', g: 6, ag: 'o', m: 9, hf: 1, d: 1200, sf: 0 },
    { k: 'p13', n: '갈대 스테이크스', g: 4, ag: 'o', m: 9, hf: 1, d: 1600, sf: 1 },
    { k: 'p14', n: '붉은 잎 기념', g: 5, ag: 'o', m: 10, hf: 0, d: 1800, sf: 0, tr: 'O9', tn: 2 },
    { k: 'p15', n: '억새 기념', g: 5, ag: 'o', m: 10, hf: 0, d: 2500, sf: 0, tr: 'O11', tn: 2 },
    { k: 'O9', n: '가을 중거리 왕관', g: 6, ag: 'o', m: 10, hf: 1, d: 2000, sf: 0, pz: 20000 },
    { k: 'p16', n: '서릿발 스테이크스', g: 5, ag: 'o', m: 11, hf: 0, d: 1800, sf: 1, tr: 'O12', tn: 2 },
    { k: 'O10', n: '마일 챔피언 컵', g: 6, ag: 'o', m: 11, hf: 0, d: 1600, sf: 0 },
    { k: 'O11', n: '대륙 컵', g: 6, ag: 'o', m: 11, hf: 1, d: 2400, sf: 0, pz: 30000 },
    { k: 'p17', n: '첫눈 마일', g: 4, ag: 'o', m: 12, hf: 0, d: 1600, sf: 0 },
    { k: 'O12', n: '더트 챔피언 컵', g: 6, ag: 'o', m: 12, hf: 0, d: 1800, sf: 1, pz: 16000 },
    { k: 'O13', n: '연말 그랑프리', g: 6, ag: 'o', m: 12, hf: 1, d: 2500, sf: 0, pz: 40000 },
  ];
  const GRK = {}; GR.forEach((r) => { GRK[r.k] = r; });
  const CLASSIC = ['C1', 'C2', 'C3'];
  const LNAME = ['느티나무', '갈매기', '징검다리', '물레방아', '은행나무', '솔바람', '돌담', '등나무', '해오라기', '보리밭', '물안개', '단비', '산마루', '자작나무', '풍차', '밀물', '달맞이', '저녁놀', '고갯길', '가랑비'];

  /* ======================= 난수 ======================= */
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const R = Math.random;
  const ri = (n) => Math.floor(R() * n);
  const pick = (a) => a[ri(a.length)];
  function hash(a, b) { let h = (a ^ Math.imul(b + 0x9e3779b9, 0x85ebca6b)) >>> 0; h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35) >>> 0; return (h ^ (h >>> 16)) >>> 0; }

  /* ======================= 달력 ======================= */
  // 칸(slot) = 반달 0..71: 해 y = slot/24, 월 = (slot%24)/2 + 1, 전반/후반 = slot%2
  const slotY = (sl) => Math.floor(sl / 24), slotM = (sl) => Math.floor((sl % 24) / 2) + 1, slotH = (sl) => sl % 2;
  const slotName = (sl) => (slotY(sl) + 2) + '세 · ' + slotM(sl) + '월 ' + (slotH(sl) ? '후반' : '전반');
  const slotsOf = (s, t) => (s.cm ? [t * 2, t * 2 + 1] : [t]);
  const turnName = (s, t) => (s.cm ? (slotY(t * 2) + 2) + '세 · ' + slotM(t * 2) + '월' : slotName(t));
  const grSlot = (r, y) => y * 24 + (r.m - 1) * 2 + r.hf;
  function agOk(ag, y, m) { return ag === '2' ? y === 0 : ag === '3' ? y === 1 : ag === 'o' ? (y === 2 || (y === 1 && m >= 6)) : ag === '23' ? y <= 1 : true; }

  const fillCache = {};
  function fillers(seed, sl) {
    const key = seed + ':' + sl;
    if (fillCache[key]) return fillCache[key];
    const rnd = prng(hash(seed, sl * 7919 + 13)), y = slotY(sl), m = slotM(sl), out = [];
    const dist = (a) => a[Math.floor(rnd() * a.length)];
    const add = (g, ag, nm, d, sf) => out.push({ k: 'f' + sl + '_' + out.length, n: nm, g, ag, d, sf, sl });
    const sfR = () => (rnd() < 0.68 ? 0 : 1);
    if (y === 0 && m >= 6 && m <= 10) { add(0, '2', '2세 신마전', dist([1200, 1400, 1600, 1800]), sfR()); add(0, '2', '2세 신마전', dist([1400, 1600, 1800, 2000]), sfR()); }
    if (y === 1 && m <= 3 && sl % 2 === 0) add(0, '3', '3세 신마전', dist([1400, 1600, 1800, 2000]), sfR());
    if ((y === 0 && m >= 7) || (y === 1 && m <= 9)) { add(1, '23', (y + 2) + '세 미승리전', dist([1200, 1400, 1600, 1800, 2000]), sfR()); add(1, '23', (y + 2) + '세 미승리전', dist([1600, 1800, 2000, 2200, 2400]), sfR()); }
    if ((y === 0 && m >= 8) || y >= 1) add(2, '', '1승 클래스', dist([1200, 1400, 1600, 1800, 2000, 2200, 2400, 2600]), sfR());
    if (y >= 1) add(2, '', '1승 클래스', dist([1400, 1600, 2000, 2400, 3000]), sfR());
    if ((y === 0 && m >= 9 && sl % 2 === 1) || (y >= 1 && rnd() < 0.85)) {
      const nm = LNAME[Math.floor(rnd() * LNAME.length)] + (rnd() < 0.5 ? ' 스테이크스' : ' 특별');
      add(3, y === 0 ? '2' : '', nm, dist([1200, 1400, 1600, 1800, 2000, 2200, 2400, 2500, 3000]), sfR());
    }
    fillCache[key] = out;
    return out;
  }
  /* 이 턴에 열리는 경주 전부 */
  function racesAt(s, t) {
    const out = [];
    for (const sl of slotsOf(s, t)) {
      const y = slotY(sl);
      for (const r of GR) if (grSlot(r, y) === sl && agOk(r.ag, y, r.m)) out.push(Object.assign({ sl, cm: s.cm }, r));
      for (const r of fillers(s.seed, sl)) out.push(Object.assign({ cm: s.cm }, r));
    }
    return out;
  }
  function raceByKey(s, t, k) { return racesAt(s, t).find((r) => r.k === k) || null; }
  const prizeOf = (r) => r.pz || PRIZE[r.g];

  /* 출전 조건 — 되면 '' 아니면 이유 */
  function elig(s, P, r) {
    const H = P.h, y = slotY(r.sl), m = slotM(r.sl);
    if (!H || H.out) return '은퇴';
    if (H.inj > 0) return '부상 휴양 중';
    if (r.ag && !agOk(r.ag, y, m)) return '나이 조건';
    const w = H.rec.w;
    if (r.g === 0) return H.rec.n === 0 ? '' : '데뷔한 말은 못 나감';
    if (r.g === 1) return w === 0 ? '' : '이미 1승';
    if (r.g === 2) return w === 1 || (w === 0 && (y === 2 || (y === 1 && m >= 10))) ? '' : w === 0 ? '1승이 필요' : '2승 이상은 오픈 경주로';
    if (w < 1) return '1승이 필요';
    if (r.g === 5 && H.rec.e < 1500) return '상금 1,500만 필요';
    if (r.g === 6) {
      const need = r.ag === '2' ? 1000 : 3000;
      if (H.rec.e < need && !(H.tk || []).includes(r.k)) return '상금 ' + (need >= 1000 ? (need / 1000).toFixed(0) + ',000' : need) + '만 또는 우선 출주권 필요';
    }
    return '';
  }

  /* ======================= 말 만들기 ======================= */
  function mkName(used) {
    for (let i = 0; i < 40; i++) { const n = pick(NA) + ' ' + pick(NB); if (!used.has(n)) { used.add(n); return n; } }
    const n = pick(NA) + pick(NB) + (used.size % 9); used.add(n); return n;
  }
  function mkFoal(used) {
    const si = ri(SIRES.length), S = SIRES[si];
    const di = ri(DAMS.length);
    let apt = S.a.split('').map((c) => { let i = GL.indexOf(c); const r = R(); if (r < 0.14) i--; else if (r < 0.26) i++; return GL[clamp(i, 0, 6)]; }).join('');
    const talent = 0.88 + R() * 0.28;
    const o = { apt, gr: S.g.map((g) => g * (0.9 + R() * 0.22) * talent), ty: clamp(S.ty + (R() < 0.25 ? (R() < 0.5 ? -1 : 1) : 0), -1, 1), tough: 0, calm: 0 };
    DAMS[di].f(o);
    // 각질 적성은 최소 하나는 B 이상, 거리도 하나는 B 이상
    const a = o.apt.split('');
    if (!a.slice(6, 9).some((c) => GL.indexOf(c) <= 1)) a[6 + ri(3)] = 'B';
    if (!a.slice(0, 4).some((c) => GL.indexOf(c) <= 1)) a[ri(4)] = 'B';
    if (!a.slice(4, 6).some((c) => GL.indexOf(c) <= 1)) a[4] = 'B';
    o.apt = a.join('');
    const bias = S.g;
    const st = bias.map((b) => Math.round((70 + R() * 55) * (0.85 + (b - 0.9) * 1.2)));
    const cap = o.gr.map((g) => Math.round(clamp(820 + (g - 1) * 900 + R() * 220, 760, 1200)));
    const co = ri(CO.length);
    const est = talent + (R() * 2 - 1) * 0.05;
    const ap = est >= 1.1 ? 0 : est >= 1.03 ? 1 : est >= 0.97 ? 2 : est >= 0.92 ? 3 : 4;
    const tyGuess = R() < 0.75 ? o.ty : clamp(o.ty + (R() < 0.5 ? -1 : 1), -1, 1);
    return {
      n: mkName(used), co, bz: R() < 0.45 ? 1 : 0, sk: R() < 0.35 ? 1 : 0, si, di,
      dn: mkName(used), sn: mkName(used),
      apt: o.apt, gr: o.gr.map((g) => Math.round(g * 100) / 100), ty: o.ty, tough: o.tough, calm: o.calm, tm: ri(3), cap,
      st, ap, tg: tyGuess, tal: Math.round(talent * 100) / 100,
    };
  }
  const POT = ['대물의 기운', '상', '중상', '중', '중하'];

  function newHorse(f, jk) {
    return {
      n: f.n, co: f.co, bz: f.bz, sk: f.sk, si: f.si, di: f.di, dn: f.dn, sn: f.sn, apt: f.apt, gr: f.gr, ty: f.ty, tough: f.tough, calm: f.calm, tm: f.tm,
      cap: f.cap, st: f.st.slice(), ap: f.ap, tg: f.tg,
      hp: 100, mood: 0, inj: 0, ail: 0, sp: 60, ab: [], jk, jr: 0, sf: [0, 0, 0, 0, 0], tl: [0, 0, 0, 0, 0], own: 60, str: 0, lastRace: -9, tk: [],
      rec: { n: 0, w: 0, t3: 0, e: 0, f: 0, g: [0, 0, 0], g1: [], rb: 0, rbg1: 0 }, hist: [], out: 0, why: '', camp: 0, jx: 0, goal: '', goalT: -1,
    };
  }

  /* ======================= 적성 계산 ======================= */
  function aptIdx(h, i) {
    let g = GL.indexOf(h.apt[i]);
    if (i === 5 && hasAb(h, 'd1')) g = Math.max(0, g - 1);
    if (i < 4 && hasAb(h, 'd2')) { const b = bestDist(h, true); if (i === b + 1) g = Math.max(0, g - 1); }
    return g;
  }
  function bestDist(h, raw) {
    let b = 0, bg = 9;
    for (let i = 0; i < 4; i++) { const g = raw ? GL.indexOf(h.apt[i]) : aptIdx(h, i); if (g < bg || (g === bg && i === 2)) { bg = g; b = i; } }
    return b;
  }
  const aptL = (h, i) => GL[aptIdx(h, i)];
  function bestStyle(h) { let b = 0, bg = 9; for (let i = 0; i < 3; i++) { const g = aptIdx(h, 6 + i); if (g < bg) { bg = g; b = i; } } return b; }
  function bestSurf(h) { return aptIdx(h, 5) < aptIdx(h, 4) ? 1 : 0; }

  /* ======================= 경주 시뮬레이션 (결정적: + − × ÷ √ 만 사용) ======================= */
  const TRK = [{ S: 450, R: 120 }, { S: 400, R: 100 }];
  const PI = 3.141592653589793;
  /* 거리마다 직선 길이를 골라 출발점이 늘 직선 위(다음 코너까지 200m 이상)에 오게 함 */
  const TCACHE = {};
  function track(sf, d) {
    const key = sf + ':' + d;
    if (TCACHE[key]) return TCACHE[key];
    const Rr = TRK[sf].R, C = PI * Rr;
    let best = null;
    for (let S = TRK[sf].S; S <= TRK[sf].S + 260; S += 10) {
      const P = 2 * S + 2 * C, p0 = (P - (d % P)) % P;
      const ok = (p0 >= C && p0 <= C + S - 200) || (p0 >= 2 * C + S && p0 <= P - 200);
      if (ok) { best = S; break; }
    }
    if (best == null) best = TRK[sf].S;
    return (TCACHE[key] = { S: best, R: Rr, C, P: 2 * best + 2 * C });
  }
  const SC = [[1.0, 0.98, 0.962], [0.978, 0.991, 0.975], [0.935, 0.999, 0.997]];
  const HPC = [0.95, 0.89, 0.997], ACC = [1.0, 0.985, 0.975];
  const GO_SP = [1, 0.997, 0.993, 0.988], GO_HP = [1, 1.01, 1.025, 1.04];
  const GON = ['양호', '약간 무거움', '무거움', '불량'];
  const AB_BIT = (id) => 1 << ABI[id];

  /* 출전마 한 마리 → 시뮬 매개변수(정수 위주, 상태에 저장) */
  function runnerOf(s, P, seat, r, plan) {
    const H = P.h, dc = dcat(r.d), ms = MOOD_ST[H.mood + 2];
    const sty = plan.p === 3 ? bestStyle(H) : plan.p;
    let bits = 0; H.ab.forEach((id) => { bits |= AB_BIT(id); });
    const jt = jTier(H);
    return {
      n: H.n, co: H.co, bz: H.bz, sk: H.sk, s: seat, st: H.st.map((v) => Math.round(v * ms)),
      dA: aptIdx(H, dc), sA: aptIdx(H, 4 + r.sf), yA: aptIdx(H, 6 + sty), y: sty, sp: plan.s, jw: H.jx > 0 ? 55 : JOCKEYS[H.jk].w,
      jp: H.jx > 0 ? 0 : JOCKEYS.indexOf(JOCKEYS[H.jk]) + 1, jt: H.jx > 0 ? 0 : jt, ab: bits, tm: H.tm, ail: H.ail,
    };
  }
  function jTier(H) { let t = 0; for (const v of JTIER) if (H.jr >= v) t++; return t; }
  function npcMean(r) {
    // 기준선 = 이 시기에 무난하게 자란 말의 평균 능력치. 등급이 오를수록 상대가 강함, 3세 이상 경주의 3세는 나이 든 말과 겨룸
    const sl = r.sl, e = 100 + 8 * sl;
    let f = [0.82, 0.88, 0.96, 1.0, 1.03, 1.06, 1.12][r.g];
    if (r.g === 6) f = r.ag === '2' ? 1.06 : r.ag === '3' ? 1.09 : 1.13;
    return (e * f + (r.ag === 'o' && slotY(sl) === 1 ? 30 : 0)) * (r.cm ? 0.93 : 1);   // 압축 모드는 경주 한 번이 두 배로 귀해서 상대를 조금 낮춤
  }
  const PROF = [[1.15, 0.75, 1.1, 0.95, 0.95], [1.1, 0.9, 1.05, 0.95, 1], [1.05, 1.05, 0.95, 1, 0.95], [0.95, 1.25, 0.9, 1, 0.95]];
  function npcRunner(rnd, r, mean, name, k) {
    const dc = dcat(r.d), f = 0.86 + rnd() * 0.26;
    const st = PROF[dc].map((w) => Math.round(mean * f * w * (0.92 + rnd() * 0.16)));
    const y = Math.floor(rnd() * 3);
    return { n: name, co: Math.floor(rnd() * CO.length), bz: rnd() < 0.4 ? 1 : 0, sk: rnd() < 0.3 ? 1 : 0, s: -1, st, dA: rnd() < 0.8 ? 0 : 1, sA: rnd() < 0.85 ? 0 : 1, yA: rnd() < 0.75 ? 0 : 1, y, sp: 3, jw: 60 + Math.floor(rnd() * 35), jp: 0, jt: 0, ab: 0, tm: 0, ail: 0, sl: k };
  }

  function simRace(rec, keep) {
    const Ld = rec.d, N = rec.R.length, rnd = prng(rec.sd), T = track(rec.sf, rec.d);
    const v0 = 20 - (Ld - 2000) / 1000, go = rec.go;
    const startP = ((T.P - (Ld % T.P)) % T.P);
    const H = [];
    for (let i = 0; i < N; i++) {
      const q = rec.R[i], b = q.ab | 0, has = (id) => (b & AB_BIT(id)) !== 0;
      const st = q.st;
      let spd = st[0], sta = st[1], pow = st[2], gut = st[3], wit = st[4];
      // 기수 능력
      const J = q.jp ? JOCKEYS[q.jp - 1] : null, jt = q.jt | 0;
      let jSpd = 1, jHp = 1, jAcc = 1, jSp = 0;
      if (J && jt >= 2) {
        const two = jt >= 4 ? 1 : 0;
        if (J.sp === 'front' && q.y === 0) jSpd = two ? 1.012 : 1.006;
        if (J.sp === 'close' && q.y === 2) jSp = two ? 0.25 : 0.12;
        if (J.sp === 'long' && Ld >= 2400) jHp = two ? 0.94 : 0.97;
        if (J.sp === 'dirt' && rec.sf === 1) pow += two ? 80 : 40;
        if (J.sp === 'short' && Ld <= 1600) jAcc = two ? 1.15 : 1.08;
        if (J.sp === 'young') wit += two ? 80 : 40;
        if (J.sp === 'big' && rec.g === 6) jSp = two ? 0.2 : 0.1;
      }
      const allSp = jt >= 5 ? 1.005 : 1;
      const dirtSp = J && J.sp === 'dirt' && jt >= 4 && rec.sf === 1 ? 1.003 : 1;
      if (has('b4')) wit *= 1.15;
      const witE = wit * APT_WIT[q.yA];
      const powE = pow * APT_POW[q.sA];
      const goS = has('c2') ? 1 : GO_SP[go], goH = has('c2') ? 1 : GO_HP[go];
      const base = v0 * APT_BASE[q.sA] * APT_BASE[q.yA] * goS * jSpd * allSp * dirtSp;
      const hpMul = goH * jHp * (has('c4') && Ld >= 2400 ? 0.94 : 1) * (q.ail === 5 ? 1.04 : 1);
      const hp0 = Ld + 0.8 * HPC[q.y] * sta;
      let spB = jSp + (has('a2') ? 0.15 : 0) + (has('d3') && Ld <= 1600 ? 0.2 : 0);
      const vsp = (v0 * (SC[q.y][2] + 0.01) + Math.sqrt(500 * spd) * 0.0035 * APT_SPD[q.dA] * (Ld < 2000 ? 1 + (2000 - Ld) / 2000 * 0.7 : 1)) * 1.05 * APT_BASE[q.sA] * goS * allSp + Math.sqrt(450 * gut) * 0.0006 + spB;
      const acc = 0.0006 * Math.sqrt(500 * powE) * ACC[q.y] * jAcc * (rec.sf === 1 && powE < 400 ? 0.95 : 1);
      // 출발: 판단력이 낮을수록 늦음, 예민한 말은 가끔 크게 늦음
      let delay = rnd() * 0.12 * (1.3 - Math.min(1, witE / 1200));
      if (q.tm === 1 && rnd() < 0.1) delay += 0.45;
      if (q.tm === 0) delay *= 0.7;
      if (has('b1') || (jt >= 1 && rnd() < 0.5)) delay *= 0.3;
      const err = (rnd() * 2 - 1) * (1 - q.jw / 100) * 0.3 * (has('b4') ? 0.5 : 1);
      const form = 1 + (rnd() * 2 - 1) * 0.012; // 당일 몸 상태
      H.push({
        q, x: 0, v: 0, l: i * 0.9, hp: hp0, hp0, base: base * form, vsp: vsp * form, acc, spd, gut, witE, hpMul, err, delay,
        sp: false, ex: false, fin: -1, blk: 0, nz: 0, nt: 0, has, c1: has('c1'), mid: false, rank: i, nd: 0,
        look: has('a3') ? 4.5 : 3, lane: has('a3') ? 1.6 : 1, sdash: has('b1') ? 0.88 : 0.85,
        pk: has('b3') ? 1.5 : 1, duel: (has('c3') ? 1.5 : 1) * (q.tm === 2 ? 1.25 : 1), exB: has('c3') ? 0.5 : 0, last: has('a4'), cor: has('b2'), stA: has('a1'),
      });
    }
    const dt = 0.1, frames = keep ? [] : null, idx = H.map((_, i) => i);
    let t = 0, done = 0, fi = 0;
    const tCap = Ld / 12 + 30;
    const corner = (p) => p < T.C || (p >= T.C + T.S && p < 2 * T.C + T.S);
    const cons = (h, v, ph2) => 20 * (v - v0 + 12) * (v - v0 + 12) / 144 * h.hpMul * (ph2 ? 1 + 200 / Math.sqrt(600 * h.gut) : 1);
    while (done < N && t < tCap) {
      idx.sort((a, b) => H[b].x - H[a].x || a - b);
      for (let r = 0; r < N; r++) H[idx[r]].rank = r;
      for (let i = 0; i < N; i++) {
        const h = H[i];
        if (h.fin >= 0) { h.x += h.v * dt; continue; }
        if (t < h.delay) continue;
        const rem = Ld - h.x, ph = h.x < Ld / 6 ? 0 : h.x < Ld * 2 / 3 ? 1 : 2;
        const p = (startP + h.x) % T.P, inC = corner(p), fs = rem <= T.S;
        if (h.c1 && !h.mid && h.x >= Ld / 2) { h.mid = true; h.hp += h.hp0 * 0.035; }
        // 노이즈(판단력)
        if (t >= h.nt) { h.nt = t + 2; h.nz = (rnd() * 2 - 1) * 0.006 * v0 * (1.25 - Math.min(1, h.witE / 1200)); }
        // 스퍼트 결정
        if (!h.sp && ph === 2 && !h.ex) {
          const sp = h.q.sp;
          if (sp < 3) { const D = [Math.max(Ld * 0.33, 650), Math.max(Ld * 0.22, 420), Math.max(Ld * 0.13, 260)][sp]; if (rem <= D) h.sp = true; }
          else {
            const vcr = h.base * SC[h.q.y][2] + Math.sqrt(500 * h.spd) * 0.003 * APT_SPD[h.q.dA];
            const csp = cons(h, h.vsp, true) / h.vsp, ccr = cons(h, vcr, true) / vcr;
            const need = rem * csp;
            if (h.hp >= need) h.sp = true;
            else { const Dm = (h.hp - rem * ccr) / Math.max(0.001, csp - ccr) * (1 + h.err); if (rem <= Dm) h.sp = true; }
          }
        }
        let tg;
        if (h.ex) tg = v0 * 0.86 + h.gut * 0.0008 + h.exB;
        else if (h.sp) tg = h.vsp + (h.last && rem < 200 ? 0.3 : 0);
        else {
          tg = h.base * SC[h.q.y][ph];
          if (ph === 1) tg += Math.sqrt(500 * h.spd) * 0.0012;
          if (ph === 2) tg += Math.sqrt(500 * h.spd) * 0.003 * APT_SPD[h.q.dA];
          if (ph < 2) { // 자리 잡기
            const rf = N > 1 ? h.rank / (N - 1) : 0, win = [[0, 0.12], [0.12, 0.45], [0.55, 1]][h.q.y];
            const k = h.pk * (0.6 + 0.4 * Math.min(1, h.witE / 900));
            if (rf > win[1]) tg *= 1 + [0.04, 0.025, 0.012][h.q.y] * k;
            else if (rf < win[0]) tg *= 1 - 0.025 * k;
          }
          tg += h.nz;
        }
        if (inC && h.cor) tg += 0.12;
        // 경합(근성)
        if (h.sp && fs) {
          for (let j = 0; j < N; j++) { if (j === i) continue; const o = H[j]; if (o.fin < 0 && o.sp && Math.abs(o.x - h.x) < 1.6 && Math.abs(o.l - h.l) < 2.2) { tg += Math.sqrt(200 * h.gut) * 0.0007 * h.duel; break; } }
        }
        // 앞이 막힘 / 진로 바꾸기
        let front = -1, fd = 99;
        for (let j = 0; j < N; j++) { if (j === i) continue; const o = H[j], d = o.x - h.x; if (d > 0 && d < h.look && Math.abs(o.l - h.l) < 1.0 && d < fd) { fd = d; front = j; } }
        if (front >= 0 && tg > H[front].v - 0.05) {
          let free = true;
          for (let j = 0; j < N; j++) { if (j === i) continue; const o = H[j], dl = o.l - h.l; if (Math.abs(o.x - h.x) < 2.0 && dl > 0.4 && dl < 1.5) { free = false; break; } }
          if (free && h.l < 16) h.l += 1.1 * h.lane * (fs ? 1.6 : 1) * dt;
          else if (fd < 1.0) { tg = Math.min(tg, H[front].v + 0.05); h.blk += dt; }
        } else if (!fs && h.l > 0.1) {
          let free = true;
          for (let j = 0; j < N; j++) { if (j === i) continue; const o = H[j], dl = h.l - o.l; if (Math.abs(o.x - h.x) < 2.6 && dl > 0.3 && dl < 1.5) { free = false; break; } }
          if (free) h.l = Math.max(0, h.l - (ph === 0 ? 0.9 : 0.35) * dt);
        }
        // 가속·감속
        if (h.v < tg) {
          let a = h.acc * (h.stA && fs ? 1.25 : 1);
          if (h.v < v0 * h.sdash && ph === 0) a += 24 * (h.x < 60 ? 1 : 0.5);
          h.v = Math.min(tg, h.v + a * dt);
        } else h.v = Math.max(tg, h.v - (h.ex ? 1.0 : 0.8) * dt);
        // 체력
        h.hp -= cons(h, h.v, ph === 2) * dt;
        if (h.hp <= 0 && !h.ex) { h.ex = true; h.hp = 0; }
        // 전진(코너 바깥은 손해)
        const prog = inC ? T.R / (T.R + h.l) : 1;
        h.x += h.v * dt * prog;
        if (h.x >= Ld) { h.fin = t + dt - (h.x - Ld) / Math.max(1, h.v * prog); done++; }
      }
      t += dt;
      if (keep && t >= fi * 0.5 - 1e-9) { const f = []; for (const h of H) f.push(Math.round(h.x * 10) / 10, Math.round(h.l * 10) / 10, h.sp ? 1 : 0); frames.push(f); fi++; }
    }
    for (const h of H) if (h.fin < 0) h.fin = t + (Ld - h.x) / 15;
    const ord = H.map((_, i) => i).sort((a, b) => H[a].fin - H[b].fin || a - b);
    return { ord, tm: H.map((h) => Math.round(h.fin * 100) / 100), fr: frames, blk: H.map((h) => h.blk), T: t };
  }

  /* ======================= 상태 ======================= */
  function init(players, opts) {
    opts = opts || {};
    const used = new Set();
    const s = {
      v: 1, ph: 'pick', t: 0, cm: opts.len === 'short' ? 1 : 0, seed: (Math.random() * 2147483647) | 0, n: players.length,
      P: players.map(() => ({ c: [mkFoal(used), mkFoal(used), mkFoal(used)], jc: shuffle(JOCKEYS.map((_, i) => i)).slice(0, 3), h: null, act: null, ev: null, pk: null, sa: [], fx: null })),
      rv: [], news: [], last: null, lid: 0, used: [],
    };
    s.T = s.cm ? 36 : 72;
    // 라이벌 두 마리(동갑) — 큰 경주에서 만남
    const rcat = shuffle([0, 1, 2, 3]);
    for (let i = 0; i < 2; i++) {
      const f = mkFoal(used);
      s.rv.push({ n: f.n, co: f.co, bz: f.bz, sk: f.sk, dc: rcat[i], sf: i === 1 && R() < 0.4 ? 1 : 0, y: ri(3), w: 0, g1: 0, k: 1.03 + R() * 0.05 });
    }
    s.used = Array.from(used);
    return s;
  }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = ri(i + 1); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  function actor(s) {
    if (s.ph === 'over') return null;
    const a = [];
    s.P.forEach((P, i) => {
      if (s.ph === 'pick') { if (P.pk == null) a.push(i); }
      else if (P.h && !P.h.out && (P.ev || !P.act)) a.push(i);
    });
    return a.length ? a : null;
  }

  function news(s, txt) { s.news.unshift([s.t, txt]); if (s.news.length > 10) s.news.length = 10; }

  /* ----- 훈련 미리 계산(보기·AI 공용) ----- */
  function trainGain(s, P, k) {
    const H = P.h, T = TRAIN[k], y = slotY(slotsOf(s, s.t)[0]);
    const lv = trainLv(H, k);
    let mul = MOOD_TR[H.mood + 2] * (1 + 0.07 * (lv - 1)) * YEAR_MUL[H.ty + 1][y] * (s.cm ? 2.25 : 1) * (H.ail === 2 ? 0.7 : 1) * (H.camp > 0 ? 1.3 : 1) * (H.tm === 1 ? 1.05 : 1);
    const here = staffAt(P, k);
    let sb = 1;
    for (const i of here) sb += 0.15 + (H.sf[i] >= 80 && STAFF[i].k === k ? 0.4 : 0);
    mul *= sb;
    const g = T.g.map((b, i) => { if (!b) return 0; const v = H.st[i], c = H.cap[i]; const capF = v < 0.8 * c ? 1 : v < c ? 0.55 : 0.12; return Math.max(1, Math.round(b * mul * H.gr[i] * capF)); });
    const hp = Math.round(T.hp * (s.cm ? 1.25 : 1) * (H.tm === 2 && T.hp > 0 ? 1.08 : 1));
    return { g, hp, f: failRate(H, k), lv, here };
  }
  function trainLv(H, k) { return Math.min(5, 1 + Math.floor(H.tl[k] / 4)); }
  function failRate(H, k) {
    let f = H.hp < 55 ? (55 - H.hp) * 1.7 : 0;
    if (H.ail === 3) f += 10; if (H.ail === 5) f += 8;
    if (k === 4) f *= 0.5;
    return Math.round(clamp(f, 0, 90));
  }
  function staffAt(P, k) { const out = []; (P.sa || []).forEach((m, i) => { if (m === k) out.push(i); }); return out; }
  function rollStaff(P) { P.sa = STAFF.map((S, i) => (R() < 0.3 ? -1 : R() < 0.4 ? S.k : ri(5))); }

  function addStat(H, i, v) { H.st[i] = clamp(Math.round(H.st[i] + v), 1, 1200); }
  function moodUp(H, d) { if (d > 0 && H.ail === 4) return; H.mood = clamp(H.mood + d, -2, 2); }

  /* ======================= 사건 ======================= */
  function upcomingTarget(s, P, span) {
    const out = [];
    for (let t = s.t + 1; t < Math.min(s.T, s.t + 1 + span); t++) for (const r of racesAt(s, t)) if (r.g >= 5 && !elig(s, P, r) && aptIdx(P.h, dcat(r.d)) <= 2 && aptIdx(P.h, 4 + r.sf) <= 2) out.push({ t, r });
    return out;
  }
  const EVENTS = [
    { id: 'owner', w: 3, when: (s, P) => upcomingTarget(s, P, 6).length > 0 && !P.h.goal,
      mk: (s, P) => { const u = pick(upcomingTarget(s, P, 6)); return { r: u.r.k, t: u.t, nm: u.r.n }; },
      ti: '마주의 요청', tx: (e) => '마주가 ' + e.nm + ' 출전을 원합니다. 받아들이면 그 경주에 나갔을 때 신뢰가 크게 오르고, 3착 안이면 명성도 더 얻습니다.',
      ch: [{ l: '받아들임', d: '목표 경주 지정', f: (s, P, e) => { P.h.goal = e.r; P.h.goalT = e.t; } }, { l: '정중히 거절', d: '마주 신뢰 −8', f: (s, P) => { P.h.own -= 8; } }],
      ai: (s, P, lv) => (lv >= 2 ? 0 : R() < 0.6 ? 0 : 1) },
    { id: 'cold', w: 2, when: (s, P) => !P.h.ail, ti: '기침 기운', tx: () => '아침 운동 뒤 가벼운 기침이 들립니다.',
      ch: [{ l: '바로 진료', d: '체력 −10 · 상태 이상 없음', f: (s, P) => { P.h.hp = clamp(P.h.hp - 10, 0, 100); } }, { l: '지켜봄', d: '절반 확률로 「기침 감기」', f: (s, P) => { if (R() < 0.5) P.h.ail = 1; } }],
      ai: (s, P, lv) => (lv === 1 && R() < 0.5 ? 1 : 0) },
    { id: 'spar', w: 3, when: () => true, ti: '병주 훈련 제안', tx: () => '이웃 마구간에서 함께 달려 보자는 제안이 왔습니다.',
      ch: [{ l: '강하게', d: '스피드·근성 +25 · 체력 −20', f: (s, P) => { addStat(P.h, 0, 25); addStat(P.h, 3, 25); P.h.hp = clamp(P.h.hp - 20, 0, 100); } },
        { l: '가볍게', d: '스피드·근성 +10 · 체력 −5', f: (s, P) => { addStat(P.h, 0, 10); addStat(P.h, 3, 10); P.h.hp = clamp(P.h.hp - 5, 0, 100); } }],
      ai: (s, P) => (P.h.hp >= 55 ? 0 : 1) },
    { id: 'feed', w: 2, when: () => true, ti: '새 사료', tx: () => '사료 업체가 새 배합을 시험해 보자고 합니다.',
      ch: [{ l: '써 봄', d: '스태미나 +22 · 20% 확률로 컨디션 −1', f: (s, P) => { addStat(P.h, 1, 22); if (R() < 0.2) moodUp(P.h, -1); } }, { l: '지금 사료 유지', d: '변화 없음', f: () => {} }],
      ai: (s, P) => (P.h.mood >= 0 ? 0 : 1) },
    { id: 'rival', w: 2, when: (s) => s.rv.some((r) => r.w > 0), mk: (s) => ({ nm: pick(s.rv.filter((r) => r.w > 0)).n }),
      ti: '라이벌 소식', tx: (e) => e.nm + '의 최근 승리 기사가 마구간 게시판에 붙었습니다.',
      ch: [{ l: '의식함', d: '근성 +18 · 컨디션 +1', f: (s, P) => { addStat(P.h, 3, 18); moodUp(P.h, 1); } }, { l: '흘려보냄', d: '판단력 +20', f: (s, P) => { addStat(P.h, 4, 20); } }],
      ai: () => (R() < 0.6 ? 0 : 1) },
    { id: 'visit', w: 2, when: (s, P) => P.h.rec.w > 0, ti: '견학 손님', tx: () => '지역 승마 동호회가 마구간을 견학하고 싶어 합니다.',
      ch: [{ l: '맞이함', d: '명성 +40 · 컨디션 +1 · 체력 −5', f: (s, P) => { P.h.rec.f += 40; moodUp(P.h, 1); P.h.hp = clamp(P.h.hp - 5, 0, 100); } }, { l: '사양', d: '변화 없음', f: () => {} }],
      ai: () => 0 },
    { id: 'hoof', w: 2, when: (s, P) => !P.h.ail && P.h.rec.n > 0, ti: '발굽 열감', tx: () => '장제사가 앞발굽에 열이 있다고 알려 왔습니다.',
      ch: [{ l: '장제사 처치', d: '체력 −5 · 상태 이상 없음', f: (s, P) => { P.h.hp = clamp(P.h.hp - 5, 0, 100); } }, { l: '그대로 둠', d: '「발굽 열감」(실패율 +10%)', f: (s, P) => { P.h.ail = 3; } }],
      ai: (s, P, lv) => (lv === 1 && R() < 0.4 ? 1 : 0) },
    { id: 'night', w: 2, when: (s, P) => !P.h.ail, ti: '밤잠 설침', tx: () => '밤사이 마방에서 서성인 흔적이 있습니다.',
      ch: [{ l: '방목으로 달램', d: '체력 −5', f: (s, P) => { P.h.hp = clamp(P.h.hp - 5, 0, 100); } }, { l: '그대로 둠', d: '「밤잠 설침」(컨디션이 오르지 않음)', f: (s, P) => { P.h.ail = 4; } }],
      ai: () => 0 },
    { id: 'menu', w: 3, when: () => true, mk: () => { const a = shuffle([0, 1, 2, 3, 4]); return { a: a[0], b: a[1] }; },
      ti: '조교사의 특별 메뉴', tx: () => '조교사가 따로 짠 메뉴를 내밀었습니다. 하나를 고릅니다.',
      chf: (e) => [{ l: SN[e.a] + ' 집중', d: SN[e.a] + ' +30 · 체력 −8' }, { l: SN[e.b] + ' 집중', d: SN[e.b] + ' +30 · 체력 −8' }],
      ch: [{ f: (s, P, e) => { addStat(P.h, e.a, 30); P.h.hp = clamp(P.h.hp - 8, 0, 100); } }, { f: (s, P, e) => { addStat(P.h, e.b, 30); P.h.hp = clamp(P.h.hp - 8, 0, 100); } }],
      ai: (s, P, lv, e) => (aiNeed(P.h)[e.a] >= aiNeed(P.h)[e.b] ? 0 : 1) },
    { id: 'press', w: 1, when: (s, P) => P.h.rec.w >= 2, ti: '취재 요청', tx: () => '경마 전문지 기자가 훈련 모습을 취재하고 싶어 합니다.',
      ch: [{ l: '응함', d: '명성 +60 · 컨디션 −1', f: (s, P) => { P.h.rec.f += 60; moodUp(P.h, -1); } }, { l: '사양', d: '마주 신뢰 −3', f: (s, P) => { P.h.own -= 3; } }],
      ai: (s, P) => (P.h.mood >= 1 ? 0 : 1) },
    { id: 'pressure', w: 4, when: (s, P) => P.h.own < 35 && !P.h.goal, ti: '마주의 압박', tx: () => '마주가 성적에 불만을 드러냈습니다. 석 달 안에 뚜렷한 결과가 없으면 은퇴를 검토하겠다고 합니다.',
      ch: [{ l: '알겠습니다', d: '다음 경주 3착 안이면 신뢰 +15', f: (s, P) => { P.h.goal = '*'; P.h.goalT = s.t + 6; } }], ai: () => 0 },
    { id: 'jockeyhurt', w: 1, when: (s, P) => P.h.jx === 0 && P.h.rec.n > 0, ti: '기수 부상', tx: (e, s, P) => jo(JOCKEYS[P.h.jk].n, '이', '가') + ' 다른 경주에서 낙마해 한 달 쉽니다. 그동안은 대체 기수가 탑니다.',
      ch: [{ l: '확인', d: '두 턴 동안 대체 기수(호흡 효과 없음)', f: (s, P) => { P.h.jx = s.cm ? 1 : 2; } }], ai: () => 0 },
    { id: 'swap', w: 1, when: (s, P) => P.h.rec.w >= 2 && P.h.jr < 60, mk: (s, P) => { const o = JOCKEYS.map((_, i) => i).filter((i) => i !== P.h.jk); return { j: pick(o) }; },
      ti: '기승 제안', tx: (e) => jo(JOCKEYS[e.j].n, '이', '가') + ' 기승 의사를 전해 왔습니다. 바꾸면 호흡은 처음부터 다시 쌓습니다.',
      ch: [{ l: '기수 교체', d: '호흡 0부터', f: (s, P, e) => { P.h.jk = e.j; P.h.jr = 0; } }, { l: '지금 기수 유지', d: '호흡 +5', f: (s, P) => { P.h.jr = Math.min(100, P.h.jr + 5); } }],
      ai: (s, P, lv, e) => (JOCKEYS[e.j].w > JOCKEYS[P.h.jk].w + 6 && P.h.jr < 30 ? 0 : 1) },
    { id: 'swell', w: 0, when: () => false, ti: '다리 붓기', tx: () => '연속 출전으로 다리에 붓기가 보입니다.',
      ch: [{ l: '쉬게 함', d: '체력 +20 · 이번 턴 휴식', f: (s, P) => { P.h.hp = clamp(P.h.hp + 20, 0, 100); P.h.forceRest = 1; } }, { l: '그대로 진행', d: '「다리 붓기」', f: (s, P) => { P.h.ail = 5; } }],
      ai: (s, P, lv) => (lv >= 2 ? 0 : R() < 0.5 ? 0 : 1) },
    { id: 'camp', w: 0, when: () => false, ti: '여름 합숙', tx: () => '고원 훈련장으로 옮겨 여름을 보냅니다. 한 달 동안 훈련 효과가 커집니다.',
      ch: [{ l: '확인', d: '두 턴 동안 훈련 효과 +30%', f: () => {} }], ai: () => 0 },
  ];
  const EVI = {}; EVENTS.forEach((e) => { EVI[e.id] = e; });
  function evChoices(e, ev) { const E = EVI[ev.id]; return E.chf ? E.chf(ev).map((c, i) => Object.assign({}, c, { f: E.ch[i].f })) : E.ch; }

  /* ======================= 행동 처리 ======================= */
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const P = s.P[seat];
    if (!P) throw new Error('no seat');
    if (s.ph === 'pick') {
      if (a.t !== 'pick' || P.pk != null) throw new Error('pick phase');
      const f = a.f | 0, j = a.j | 0;
      if (f < 0 || f > 2 || j < 0 || j > 2) throw new Error('bad pick');
      P.pk = f; P.h = newHorse(P.c[f], P.jc[j]); P.c = null; P.jc = null;
      rollStaff(P);
      if (s.P.every((p) => p.pk != null)) { s.ph = 'turn'; news(s, '데뷔를 향한 훈련이 시작됩니다.'); }
      return s;
    }
    if (s.ph !== 'turn') throw new Error('over');
    const H = P.h;
    if (!H || H.out) throw new Error('retired');
    if (a.t === 'ev') {
      if (!P.ev) throw new Error('no event');
      const ch = evChoices(EVI[P.ev.id], P.ev), c = ch[a.c | 0];
      if (!c) throw new Error('bad choice');
      c.f(s, P, P.ev);
      P.ev = null;
      return s;
    }
    if (P.ev) throw new Error('answer event first');
    if (a.t === 'ab') {
      const A = ABIL[ABI[a.id]];
      if (!A || hasAb(H, A.id)) throw new Error('bad ability');
      if (A.r && !hasAb(H, A.r)) throw new Error('locked');
      if (H.sp < A.c) throw new Error('sp');
      H.sp -= A.c; H.ab.push(A.id);
      return s;
    }
    if (P.act) throw new Error('already');
    if (H.inj > 0 || H.forceRest) { if (a.t !== 'rest') throw new Error('must rest'); }
    if (a.t === 'tr') { if (!(a.k >= 0 && a.k <= 4)) throw new Error('bad train'); }
    else if (a.t === 'race') {
      const r = raceByKey(s, s.t, a.r);
      if (!r) throw new Error('no race');
      const why = elig(s, P, r);
      if (why) throw new Error(why);
      if (!(a.p >= 0 && a.p <= 3 && a.s >= 0 && a.s <= 3)) throw new Error('bad plan');
    } else if (a.t === 'vet' || a.t === 'graze' || a.t === 'rest' || a.t === 'ride') { /* ok */ }
    else throw new Error('bad action');
    P.act = { t: a.t, k: a.k | 0, r: a.r, p: a.p | 0, s: a.s | 0 };
    if (s.P.every((p) => !p.h || p.h.out || (p.act && !p.ev))) resolve(s);
    return s;
  }

  function resolve(s) {
    const last = { id: ++s.lid, t: s.t, races: [], fx: [] };
    const entries = {};
    s.P.forEach((P, seat) => {
      const H = P.h;
      if (!H || H.out) return;
      const a = P.act, fx = { seat, a: a.t, d: [0, 0, 0, 0, 0], hp: H.hp, mood: H.mood };
      last.fx[seat] = fx;
      if (H.inj > 0) { H.inj--; H.hp = clamp(H.hp + 30, 0, 100); fx.inj = 1; if (H.inj === 0) news(s, H.n + ', 부상에서 복귀합니다.'); }
      else if (a.t === 'tr') doTrain(s, P, a.k, fx);
      else if (a.t === 'rest') { H.hp = clamp(H.hp + Math.round((42 + ri(20)) * (s.cm ? 1.35 : 1)), 0, 100); if (R() < 0.2) moodUp(H, 1); if (H.ail && R() < 0.25) H.ail = 0; H.forceRest = 0; }
      else if (a.t === 'graze') { H.hp = clamp(H.hp + 15, 0, 100); if (H.ail === 4 && R() < 0.5) H.ail = 0; moodUp(H, 1); }
      else if (a.t === 'vet') { const had = H.ail; H.ail = 0; H.hp = clamp(H.hp + (had ? 8 : 12), 0, 100); }
      else if (a.t === 'ride') { H.jr = Math.min(100, H.jr + Math.round(10 * JOCKEYS[H.jk].rr)); addStat(H, 4, Math.round(8 * MOOD_TR[H.mood + 2])); H.hp = clamp(H.hp - 8, 0, 100); H.sp += 4; }
      else if (a.t === 'race') { (entries[a.r] || (entries[a.r] = [])).push(seat); }
      if (a.t !== 'race') H.str = 0;
    });
    for (const k in entries) runRace(s, raceByKey(s, s.t, k), entries[k], last);
    // 라이벌이 다른 큰 경주에서 이긴 소식
    for (const r of racesAt(s, s.t)) if (r.g === 6 && !entries[r.k]) for (const rv of s.rv) if (rivalRuns(rv, r) && R() < 0.5) { rv.w++; rv.g1++; news(s, '라이벌 ' + rv.n + ', ' + r.n + ' 우승.'); break; }
    // 턴 끝 처리
    s.P.forEach((P, seat) => {
      const H = P.h;
      if (!H || H.out) return;
      const fx = last.fx[seat];
      if (H.camp > 0) H.camp--;
      if (H.jx > 0) H.jx--;
      if (H.ail === 1 && R() < 0.5) moodUp(H, -1);
      if (H.ail === 4 && R() < 0.3) moodUp(H, -1);
      if (H.ail && P.act && P.act.t !== 'vet' && R() < 0.12) H.ail = 0;
      const sw = H.calm ? 0.04 : H.tm === 1 ? 0.14 : H.tm === 0 ? 0.05 : 0.08;
      if (R() < sw) moodUp(H, R() < 0.5 ? 1 : -1);
      if (H.goal && s.t >= H.goalT) { if (H.goal !== '*') { H.own -= 10; news(s, H.n + ', 마주가 바라던 경주를 건너뛰었습니다.'); } else H.own -= 12; H.goal = ''; }
      if (s.t - H.lastRace > (s.cm ? 4 : 8) && s.t > (s.cm ? 6 : 12)) H.own -= 2;
      H.own = clamp(H.own, -10, 100);
      if (fx) { fx.hp2 = H.hp; fx.mood2 = H.mood; }
      P.act = null;
    });
    // 은퇴(마주 결정·부상)
    s.P.forEach((P) => { const H = P.h; if (H && !H.out && H.own <= 0 && slotY(slotsOf(s, s.t)[0]) >= 1) { H.out = 2; H.why = '마주 결정'; H.endT = s.t; news(s, H.n + ', 마주의 결정으로 은퇴합니다.'); } });
    s.t++;
    s.last = last;
    if (s.t >= s.T || s.P.every((P) => !P.h || P.h.out)) {
      s.P.forEach((P) => { if (P.h && !P.h.out) { P.h.out = 1; P.h.endT = s.T; } });
      s.ph = 'over';
      return;
    }
    // 새 턴: 스태프 배치·여름 합숙·사건
    const sl = slotsOf(s, s.t)[0], y = slotY(sl), m = slotM(sl);
    s.P.forEach((P) => {
      const H = P.h;
      if (!H || H.out) return;
      rollStaff(P);
      if (y >= 1 && m === 7 && (s.cm || slotH(sl) === 0) && !H.campY) { H.camp = s.cm ? 2 : 4; H.campY = 1; P.ev = { id: 'camp' }; return; }
      if (m !== 7) H.campY = 0;
      if (H.inj > 0) return;
      if (H.str >= 3 && !H.ail && R() < 0.35) { P.ev = { id: 'swell' }; return; }
      if (R() < 0.16) {
        const cand = EVENTS.filter((e) => e.w > 0 && e.when(s, P));
        let tot = 0; cand.forEach((e) => { tot += e.w; });
        let x = R() * tot;
        for (const e of cand) { x -= e.w; if (x <= 0) { P.ev = Object.assign({ id: e.id }, e.mk ? e.mk(s, P) : {}); break; } }
      }
    });
  }

  function doTrain(s, P, k, fx) {
    const H = P.h, g = trainGain(s, P, k);
    fx.k = k;
    H.tl[k]++;
    H.hp = clamp(H.hp - g.hp, 0, 100);
    if (R() * 100 < g.f) {
      fx.fail = 1;
      const loss = 5 + ri(8);
      addStat(H, k, -loss); fx.d[k] = -loss;
      moodUp(H, -1);
      if (H.hp < 28 && R() < (H.tough ? 0.18 : 0.3)) {
        H.inj = s.cm ? 1 + ri(2) : 2 + ri(3); fx.inj = 1;
        news(s, H.n + ', 훈련 중 다리를 다쳐 휴양에 들어갑니다.');
        if (H.hp < 12 && R() < (H.tough ? 0.02 : 0.05)) { H.out = 3; H.why = '부상'; H.endT = s.t; news(s, H.n + ', 큰 부상으로 은퇴가 결정되었습니다.'); }
      }
      return;
    }
    g.g.forEach((v, i) => { if (v) { addStat(H, i, v); fx.d[i] = v; } });
    for (const i of g.here) H.sf[i] = Math.min(100, H.sf[i] + 7);
    H.sp += 6 + g.here.length * 2;
  }

  function rivalRuns(rv, r) { return r.g >= 5 && dcat(r.d) === rv.dc && r.sf === rv.sf; }

  function runRace(s, r, seats, last) {
    const N = Math.max(seats.length + 2, Math.min(14, FIELD[r.g] + ri(3) - 1));
    const runners = [];
    seats.forEach((seat) => { const P = s.P[seat]; runners.push(runnerOf(s, P, seat, r, P.act)); });
    const mean = npcMean(r), rs = (Math.random() * 2147483647) | 0, rnd = prng(rs);
    const used = new Set(s.used);
    s.rv.forEach((rv, i) => {
      if (runners.length < N && rivalRuns(rv, r) && R() < 0.7) {
        const q = npcRunner(rnd, r, mean * rv.k, rv.n, 0);
        q.s = -2 - i; q.co = rv.co; q.bz = rv.bz; q.sk = rv.sk; q.y = rv.y; q.dA = 0; q.sA = 0; q.yA = 0; q.jw = 88;
        runners.push(q);
      }
    });
    while (runners.length < N) runners.push(npcRunner(rnd, r, mean, mkName(used), runners.length));
    shuffle(runners);
    const rec = { id: s.lid, k: r.k, n: r.n, g: r.g, d: r.d, sf: r.sf, go: rndGoing(r), sd: rs, R: runners, pz: prizeOf(r), t: s.t };
    const res = simRace(rec, false);
    rec.o = res.ord; rec.tm = res.ord.map((i) => res.tm[i]);
    last.races.push(rec);
    // 결과 반영
    const winner = runners[res.ord[0]];
    res.ord.forEach((ri_, pos) => {
      const q = runners[ri_];
      if (q.s <= -2) { const rv = s.rv[-2 - q.s]; if (pos === 0) { rv.w++; if (r.g === 6) rv.g1++; } }
    });
    seats.forEach((seat) => {
      const P = s.P[seat], H = P.h, i = runners.findIndex((q) => q.s === seat), pos = res.ord.indexOf(i), rank = pos + 1;
      const fx = last.fx[seat];
      fx.race = rec.id; fx.rank = rank; fx.N = N;
      const pz = rank <= 5 ? Math.round(prizeOf(r) * SHARE[rank - 1]) : 0;
      const fm = Math.round(FAME[r.g] * [1, 0.45, 0.3, 0.15, 0.08, 0.04][Math.min(5, pos)]);
      H.rec.n++; H.rec.e += pz; H.rec.f += fm;
      if (rank === 1) { H.rec.w++; if (r.g >= 4) H.rec.g[r.g - 4]++; if (r.g === 6) H.rec.g1.push(r.k); }
      if (rank <= 3) H.rec.t3++;
      // 라이벌을 앞섬
      runners.forEach((q, j) => { if (q.s <= -2 && res.ord.indexOf(j) > pos) { H.rec.rb++; if (r.g === 6 && rank <= 3) H.rec.rbg1++; } });
      fx.pz = pz; fx.fm = fm;
      const spg = Math.round([60, 45, 35, 25, 20, 15][Math.min(5, pos)] * (r.g + 3) / 5);
      H.sp += spg; fx.sp = spg;
      // 능력치 소폭 상승
      const need = aiNeed(H), a1 = need.indexOf(Math.max(...need));
      const plus = rank === 1 ? 10 : rank <= 3 ? 6 : 3;
      addStat(H, a1, plus); fx.d[a1] += plus;
      const a2 = ri(5); addStat(H, a2, Math.round(plus / 2)); fx.d[a2] += Math.round(plus / 2);
      H.hp = clamp(H.hp - Math.round(16 + r.d / 130 + (H.ail === 5 ? 6 : 0)), 0, 100);
      if (rank === 1) moodUp(H, 1); else if (rank > N * 0.6 && R() < 0.5) moodUp(H, -1);
      H.jr = Math.min(100, H.jr + Math.round((rank === 1 ? 8 : 3) * JOCKEYS[H.jk].rr));
      // 마주 신뢰
      H.own += rank === 1 ? 8 + (r.g >= 4 ? 4 : 0) : rank <= 3 ? 3 : rank > N / 2 && !(r.g === 6 && rank <= N - 2) ? -3 : 0;
      if (H.goal) {
        if (H.goal === r.k) { H.own += 15; if (rank <= 3) { H.rec.f += 120; } H.goal = ''; fx.goal = 1; }
        else if (H.goal === '*') { if (rank <= 3) { H.own += 15; H.goal = ''; fx.goal = 1; } }
      }
      H.own = clamp(H.own, -10, 100);
      // 연속 출전
      H.str = H.lastRace === s.t - 1 ? H.str + 1 : 1;
      H.lastRace = s.t;
      if (r.tr && rank <= r.tn && !H.tk.includes(r.tr)) { H.tk.push(r.tr); fx.tk = r.tr; }
      if (H.tk.length > 6) H.tk.shift();
      H.hist.push([s.t, r.n, r.g, r.d, r.sf, rank, N]);
      if (H.hist.length > 40) H.hist.shift();
      if (rank === 1 && r.g >= 4) news(s, H.n + ', ' + r.n + '(' + GRN[r.g] + ') 우승.');
      if (r.c && rank === 1 && CLASSIC.every((k) => H.rec.g1.includes(k))) news(s, H.n + ', 삼관을 달성했습니다.');
    });
    if (winner.s < 0 && r.g === 6) news(s, jo(r.n, '은', '는') + ' ' + winner.n + '의 우승.');
  }
  function rndGoing(r) { const x = R(); const m = GRK[r.k] ? GRK[r.k].m : slotM(r.sl); const wet = m >= 6 && m <= 9 ? 0.4 : 0.22; return x > wet ? 0 : x > wet * 0.5 ? 1 : x > wet * 0.18 ? 2 : 3; }

  /* ======================= 평가 · 칭호 · 결말 ======================= */
  function titlesOf(H) {
    const g1 = H.rec.g1, out = [];
    const cnt = (f) => g1.filter((k) => f(GRK[k])).length;
    if (CLASSIC.every((k) => g1.includes(k))) out.push('삼관마');
    if (H.rec.n >= 6 && H.rec.w === H.rec.n) out.push('무패의 명마');
    if (g1.filter((k) => k === 'O13').length >= 2) out.push('연말의 주인');
    if (cnt((r) => r.d <= 1400) >= 2) out.push('단거리 왕');
    if (cnt((r) => r.d > 1400 && r.d <= 1800 && r.sf === 0) >= 2) out.push('마일의 지배자');
    if (cnt((r) => r.sf === 1) >= 2) out.push('더트의 제왕');
    if (cnt((r) => r.d > 2400) >= 2) out.push('장거리의 귀재');
    if (g1.includes('O6') || g1.includes('O13')) out.push('그랑프리 호스');
    if (H.rec.rbg1 > 0) out.push('라이벌을 넘은 말');
    if (g1.length >= 1) out.push('G1 우승마');
    else if (H.rec.g[0] + H.rec.g[1] > 0) out.push('중상 우승마');
    if (H.rec.n >= 20) out.push('성실한 일꾼');
    if (!out.length) out.push(H.rec.w > 0 ? '현역 완주' : '미완의 대기');
    return out;
  }
  function ratingOf(H) {
    const st = H.st.reduce((a, b) => a + b, 0);
    const g = H.rec.g;
    return Math.round(st * 1.2 + H.ab.length * 90 + g[2] * 900 + g[1] * 380 + g[0] * 220 + H.rec.w * 80 + H.rec.t3 * 25 + Math.min(4000, H.rec.e / 30) + (H.out >= 2 ? -500 : 0));
  }
  const RANKS = [[12000, 'SS'], [10000, 'S'], [8200, 'A'], [6800, 'B'], [5600, 'C'], [4500, 'D'], [0, 'E']];
  const rankOf = (v) => RANKS.find((x) => v >= x[0])[1];
  function endingOf(H) {
    const g1 = H.rec.g1.length;
    if (H.out === 3) return { k: 'inj', n: '부상 은퇴', tx: jo(H.n, '은', '는') + ' 훈련 중 입은 큰 부상으로 경주로를 떠납니다. ' + H.rec.n + '전 ' + H.rec.w + '승. 목장에서 조용한 회복의 시간을 보냅니다.' };
    if (H.out === 2) return { k: 'own', n: '마주 결정 은퇴', tx: '마주는 ' + H.n + '의 현역 생활을 여기서 마무리하기로 했습니다. ' + H.rec.n + '전 ' + H.rec.w + '승. 승용마로 새 일을 찾습니다.' };
    if (g1 >= 4 || CLASSIC.every((k) => H.rec.g1.includes(k))) return { k: 'legend', n: '전설의 은퇴식', tx: '마지막 경주가 끝난 경주로에서 ' + H.n + '의 은퇴식이 열렸습니다. G1 ' + g1 + '승을 포함한 ' + H.rec.n + '전 ' + H.rec.w + '승. 종마로 들어가 다음 세대를 잇습니다.' };
    if (g1 >= 1) return { k: 'star', n: '명마의 은퇴', tx: H.n + ', G1 ' + g1 + '승으로 현역을 마칩니다. ' + H.rec.n + '전 ' + H.rec.w + '승, 통산 상금 ' + money(H.rec.e) + '. 종마로 새 출발합니다.' };
    if (H.rec.g[0] + H.rec.g[1] > 0) return { k: 'graded', n: '중상 마의 은퇴', tx: '중상 우승의 이력을 남긴 ' + jo(H.n, '이', '가') + ' 은퇴합니다. ' + H.rec.n + '전 ' + H.rec.w + '승. 지방의 종마장에서 새 일을 맡습니다.' };
    if (H.rec.w > 0) return { k: 'worker', n: '무대 뒤의 일꾼', tx: jo(H.n, '은', '는') + ' ' + H.rec.n + '전 ' + H.rec.w + '승으로 경주 생활을 마칩니다. 앞으로는 출발대 뒤에서 어린 말들을 이끄는 유도마로 일합니다.' };
    return { k: 'none', n: '무관의 은퇴', tx: jo(H.n, '은', '는') + ' 끝내 승리를 거두지 못했지만 ' + H.rec.n + '번의 경주를 끝까지 달렸습니다. 승마 클럽에서 새 삶을 시작합니다.' };
  }
  function money(m) {
    m = Math.round(m);
    if (m <= 0) return '0원';
    if (m >= 10000) { const e = Math.floor(m / 10000), r = m % 10000; return e + '억' + (r ? ' ' + r.toLocaleString('ko-KR') + '만' : '') + ' 원'; }
    return m.toLocaleString('ko-KR') + '만 원';
  }

  function result(s) {
    if (s.ph !== 'over') return null;
    const rt = s.P.map((P) => (P.h ? ratingOf(P.h) : 0));
    const best = Math.max(...rt);
    const lines = [], hl = [];
    s.P.forEach((P, i) => {
      if (!P.h) return;
      const H = P.h, en = endingOf(H), tt = titlesOf(H);
      lines.push(H.n + ' · ' + en.n + ' · 평가 ' + rankOf(rt[i]) + ' (' + rt[i].toLocaleString('ko-KR') + ')');
      if (s.n === 1) { hl.push(en.tx); hl.push('칭호: ' + tt.slice(0, 3).join(' · ')); }
      else hl.push(H.n + ' — ' + tt[0]);
    });
    let winners;
    if (s.n === 1) { const H = s.P[0].h; winners = H && H.rec.w > 0 && H.out < 2 ? [0] : []; }
    else winners = rt.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const v = (f) => s.P.map((P) => (P.h ? f(P.h) : '-'));
    return {
      winners, title: s.n === 1 ? endingOf(s.P[0].h).n : '커리어 종료',
      text: lines.join('\n'), highlights: hl.slice(0, 4),
      stats: [
        { label: '전적', values: v((H) => H.rec.n + '전 ' + H.rec.w + '승') },
        { label: 'G1 우승', values: v((H) => String(H.rec.g[2])) },
        { label: '중상 우승', values: v((H) => String(H.rec.g[0] + H.rec.g[1] + H.rec.g[2])) },
        { label: '상금', values: v((H) => money(H.rec.e)) },
        { label: '명성', values: v((H) => H.rec.f.toLocaleString('ko-KR')) },
        { label: '평가', values: s.P.map((P, i) => rankOf(rt[i]) + ' ' + rt[i].toLocaleString('ko-KR')) },
      ],
    };
  }

  /* ======================= AI ======================= */
  const W_DC = [[1, 0.35, 0.85, 0.55, 0.5], [1, 0.55, 0.75, 0.55, 0.5], [0.95, 0.85, 0.6, 0.55, 0.5], [0.85, 1.1, 0.5, 0.6, 0.5]];
  function aiNeed(H) {
    const dc = bestDist(H), w = W_DC[dc].slice();
    if (bestSurf(H) === 1) w[2] += 0.25;
    const sum = H.st.reduce((a, b) => a + b, 0) / 5 || 1;
    return w.map((x, i) => x * clamp(1.4 - H.st[i] / (sum * 1.4), 0.3, 1.6) * (H.st[i] >= H.cap[i] ? 0.15 : 1));
  }
  function habit(s, seat) { const h = hash(s.seed, seat * 31 + 7); return { fav: h % 5, app: 0.75 + ((h >>> 3) % 50) / 100, care: ((h >>> 9) % 17) - 8 }; }
  function power(H, r) {
    const dc = dcat(r.d), w = PROF[dc];
    let p = 0, ws = 0; for (let i = 0; i < 5; i++) { p += H.st[i] * MOOD_ST[H.mood + 2] * w[i]; ws += w[i]; }
    p /= ws;
    p *= 0.6 + 0.4 * APT_SPD[aptIdx(H, dc)];
    p *= 0.75 + 0.25 * APT_POW[aptIdx(H, 4 + r.sf)];
    return p;
  }
  function winProb(H, r, N) {
    const rel = power(H, r) / npcMean(r), o = Math.exp(-(rel - 1.37) * 7.5);
    const p = 1 / (1 + o * (N || 14) / 14);
    return clamp(p, 0.005, 0.95);
  }
  function raceValue(s, P, r, lv, hb) {
    const H = P.h, dA = aptIdx(H, dcat(r.d)), sA = aptIdx(H, 4 + r.sf);
    const lim = lv === 1 ? 3 : 2;
    if (dA > lim || sA > lim) return -1;
    let pw = winProb(H, r, FIELD[r.g]);
    if (lv === 1) pw = clamp(pw * (0.6 + R() * 0.9), 0, 0.95);
    const p3 = Math.min(0.97, pw * 2.1);
    let v = pw * (prizeOf(r) / 60 + FAME[r.g] / 8) + p3 * prizeOf(r) / 250;
    v += (s.cm ? 2 : 5) + (s.t - H.lastRace > (s.cm ? 3 : 6) ? 6 : 0) + (H.own < 40 ? 5 : 0);   // 출전 자체의 값(경험·노트·마주)
    if (H.rec.w === 0) v += 40 * pw;
    else if (H.rec.w === 1 && r.g === 2) v += 20 * pw;
    if (r.g === 6) v += pw * (lv === 3 && !s.cm ? 140 : 70) * (r.c ? 1.5 : 1);
    if (H.goal === r.k) v += 30;
    if (H.goal === '*') v += 15;
    v *= hb.app;
    if (H.hp < 50) v *= lv === 3 ? 0.3 : lv === 2 ? 0.55 : 0.85;
    if (H.str >= 2) v *= lv >= 2 ? 0.35 : 0.8;
    if (H.ail) v *= lv >= 2 ? 0.5 : 0.9;
    return v;
  }
  function aiPlan(H, r, lv) {
    if (lv === 1) return { p: R() < 0.5 ? 3 : ri(3), s: R() < 0.6 ? 3 : ri(3) };
    const p = lv === 3 ? bestStyle(H) : (R() < 0.7 ? 3 : bestStyle(H));
    return { p, s: 3 };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const P = s.P[seat];
    if (s.ph === 'pick') {
      let bi = 0, bv = -1e9;
      P.c.forEach((f, i) => {
        const ap = f.apt.split('').map((c) => GL.indexOf(c));
        let v = -Math.min(...ap.slice(0, 4)) * 2 - Math.min(ap[4], ap[5]) - Math.min(...ap.slice(6)) + (4 - f.ap) * 1.5 + f.st.reduce((a, b) => a + b, 0) / 120;
        if (lv === 3) v += (f.tal - 1) * 30;
        if (lv === 1) v += R() * 6;
        if (v > bv) { bv = v; bi = i; }
      });
      let bj = 0, bjv = -1;
      P.jc.forEach((j, i) => { const v = JOCKEYS[j].w * (lv === 1 ? R() : 1) + (JOCKEYS[j].sp === 'young' && lv === 3 ? 10 : 0); if (v > bjv) { bjv = v; bj = i; } });
      return { t: 'pick', f: bi, j: bj };
    }
    const H = P.h;
    if (!H || H.out) return null;
    if (P.ev) { const E = EVI[P.ev.id]; let c = 0; try { c = E.ai ? E.ai(s, P, lv, P.ev) : 0; } catch (e) { c = 0; } return { t: 'ev', c: clamp(c | 0, 0, evChoices(E, P.ev).length - 1) }; }
    if (P.act) return null;
    // 능력 익히기(보통·어려움)
    if (lv >= 2 || R() < 0.4) {
      const can = ABIL.filter((A) => !hasAb(H, A.id) && (!A.r || hasAb(H, A.r)) && H.sp >= A.c && abUseful(H, A));
      if (can.length) { can.sort((a, b) => abScore(H, b) - abScore(H, a)); return { t: 'ab', id: can[0].id }; }
    }
    if (H.inj > 0 || H.forceRest) return { t: 'rest' };
    const hb = habit(s, seat);
    const sty = (L.aiStyle && L.aiStyle(seat)) || 'bal';
    const restAt = (lv === 1 ? 30 : lv === 2 ? 42 : 45) + hb.care + (sty === 'def' ? 6 : sty === 'agg' ? -4 : 0);
    // 경주
    let best = null, bv = 0;
    for (const r of racesAt(s, s.t)) {
      if (elig(s, P, r)) continue;
      let v = raceValue(s, P, r, lv, hb) * (sty === 'agg' ? 1.2 : sty === 'gamble' && r.g >= 5 ? 1.3 : 1);
      if (lv === 1) v *= 0.6 + R() * 0.8;
      if (v > bv) { bv = v; best = r; }
    }
    // 큰 경주 앞두고 쉬기(어려움)
    if (lv === 3 && H.hp < (s.cm ? 55 : 70)) {
      const nx = racesAt(s, s.t + 1).filter((r) => r.g === 6 && !elig(s, P, r) && raceValue(s, P, r, lv, hb) > 30);
      if (nx.length) return { t: H.hp < 55 ? 'rest' : (H.mood < 1 ? 'graze' : 'rest') };
    }
    const gap = s.t - H.lastRace, thr = (lv === 3 ? 14 : lv === 2 ? 16 : 10) * (gap <= 1 && !s.cm ? 1.8 : 1);
    if (best && bv > thr && H.hp >= (lv === 1 ? 15 : 35)) { const pl = aiPlan(H, best, lv); return { t: 'race', r: best.k, p: pl.p, s: pl.s }; }
    if (H.ail && (lv >= 2 || R() < 0.4)) return { t: 'vet' };
    if (H.hp < restAt) return { t: 'rest' };
    if (lv >= 2 && (H.mood <= -1 || (lv === 3 && H.mood === 0 && !s.cm && R() < 0.4)) && R() < 0.85) return { t: 'graze' };
    // 훈련 점수
    const need = aiNeed(H);
    need[hb.fav] *= 1.12;
    let bk = 0, bs = -1e9;
    for (let k = 0; k < 5; k++) {
      const g = trainGain(s, P, k);
      let v = 0; for (let i = 0; i < 5; i++) v += g.g[i] * need[i];
      v += g.here.length * (lv >= 2 ? 6 : 2);
      v -= g.f * (lv === 1 ? 0.6 : 2.2);
      if (k === 4 && H.hp < 60) v += lv >= 2 ? 8 : 0;
      if (lv === 1) v *= 0.7 + R() * 0.6;
      if (v > bs) { bs = v; bk = k; }
    }
    if (H.jr < 60 && lv === 3 && trainGain(s, P, bk).here.length === 0 && R() < 0.12) return { t: 'ride' };
    return { t: 'tr', k: bk };
  }
  function abUseful(H, A) {
    if (A.id === 'd1') return aptIdx(H, 5) <= 2 && aptIdx(H, 5) > 0;
    if (A.id === 'd3') return bestDist(H) <= 1;
    if (A.id === 'c4') return bestDist(H) >= 2;
    if (A.id === 'd2') return bestDist(H) < 3;
    return true;
  }
  function abScore(H, A) { return 1000 / A.c + (A.b === 0 ? 2 : 0) + (A.id === 'c4' && bestDist(H) === 3 ? 4 : 0); }
  function aiDelayFor(s, seat) { const P = s.P[seat]; return s.ph === 'pick' ? 900 : P && P.ev ? 700 : 520; }

  /* ----- 상황 도움말 ----- */
  function hint(s, seat) {
    if (seat < 0) seat = 0;
    const P = s.P[seat];
    if (!P) return null;
    if (s.ph === 'pick') return ['망아지 고르기', '세 마리 중 한 마리와 기수 한 명을 고릅니다.', '적성 표의 A가 가장 잘 맞는 조건입니다. 거리·주로·각질 셋을 봅니다.', '조교사 소견은 잠재력 추정이라 틀릴 수 있습니다.'];
    const H = P.h;
    if (!H) return null;
    const out = [turnName(s, s.t) + ' · ' + (s.t + 1) + ' / ' + s.T + '턴'];
    if (P.ev) out.push('연락이 와 있습니다. 먼저 고릅니다.');
    if (H.inj > 0) out.push('부상 휴양 중 — ' + H.inj + '턴 남음. 휴양만 할 수 있습니다.');
    out.push('체력 ' + H.hp + ' · 컨디션 ' + MOODN[H.mood + 2] + (H.ail ? ' · ' + AILN[H.ail] : ''));
    const f = failRate(H, 0);
    out.push(f > 0 ? '지금 훈련 실패율 약 ' + f + '%. 체력이 55 아래면 실패율이 오릅니다.' : '체력이 넉넉해 훈련 실패 걱정이 없습니다.');
    const ok = racesAt(s, s.t).filter((r) => !elig(s, P, r));
    out.push(ok.length ? '이번 턴 나갈 수 있는 경주 ' + ok.length + '개.' : '이번 턴 나갈 수 있는 경주가 없습니다.');
    if (H.rec.w === 0 && slotY(slotsOf(s, s.t)[0]) === 0) out.push('첫 승이 있어야 오픈·중상 경주에 나갈 수 있습니다.');
    return out.slice(0, 6);
  }
  function panelInfo(s, seat) {
    const P = s.P[Math.max(0, seat)];
    if (!P || !P.h) return null;
    const H = P.h;
    return [{ label: '시기', value: turnName(s, Math.min(s.t, s.T - 1)) }, { label: '전적', value: H.rec.n + '전 ' + H.rec.w + '승' }, { label: '상금', value: money(H.rec.e) }, { label: '체력', value: String(H.hp) }];
  }

  /* 엔진을 바깥(노드 시험)에서 쓰도록 */
  const E = {
    init, actor, apply, ai, result, simRace, racesAt, elig, trainGain, ratingOf, rankOf, titlesOf, endingOf, npcMean, power, money,
    npcRunner, prng, PROF, GR, ABIL, TRAIN, JOCKEYS, SIRES, DAMS, STAFF, EVENTS, slotName, turnName, slotsOf, track, dcat,
  };
  /* ======================= 그림 도구 ======================= */
  const SERIF = '"Noto Serif KR","Nanum Myeongjo","AppleMyungjo","Batang","Times New Roman",serif';
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16), f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }
  const coatOf = (q) => Object.assign({}, CO[q.co || 0], { bz: q.bz, sk: q.sk });
  /* 옆모습(경마 게임의 옆모습 그림을 옮겨 크기만 맞춤): 원점 = 발 아래 가운데, 폭 약 50 · 높이 약 36 */
  function drawHorseSide(g, Co, ph) {
    const coat = Co.c, mane = Co.m, dark = shade(coat, -0.3);
    const leg = (hx, hy, a1, a2, col) => {
      const kx = hx + Math.sin(a1) * 8, ky = hy + Math.cos(a1) * 8, fx = kx + Math.sin(a1 + a2) * 8, fy = ky + Math.cos(a1 + a2) * 8;
      g.strokeStyle = col; g.lineWidth = 2.6; g.lineCap = 'round'; g.beginPath(); g.moveTo(hx, hy); g.lineTo(kx, ky); g.lineTo(fx, fy); g.stroke();
    };
    leg(-11, -16, 0.55 * Math.sin(ph), 0.8 * Math.max(0, Math.sin(ph - 1)), dark); leg(10, -15, 0.6 * Math.sin(ph + 1.4), -0.5, dark);
    g.strokeStyle = mane; g.lineWidth = 3.2; g.lineCap = 'round'; g.beginPath(); g.moveTo(-15, -21); g.quadraticCurveTo(-22, -22, -25, -14); g.stroke();
    g.fillStyle = coat; g.beginPath(); g.ellipse(0, -18.5, 15, 7.5, 0, 0, 7); g.fill();
    g.fillStyle = coat; g.beginPath(); g.moveTo(7, -23); g.lineTo(13, -33); g.lineTo(19, -31); g.lineTo(15, -16); g.closePath(); g.fill();
    g.save(); g.translate(18, -31); g.rotate(0.55); g.beginPath(); g.ellipse(4, 0, 7, 3.4, 0, 0, 7); g.fill(); g.restore();
    g.strokeStyle = mane; g.lineWidth = 2.6; g.beginPath(); g.moveTo(7.5, -25); g.lineTo(14, -34.5); g.stroke();
    if (Co.bz) { g.save(); g.translate(18, -31); g.rotate(0.55); g.fillStyle = '#f4efe6'; g.beginPath(); g.ellipse(5, -1.2, 4.2, 1, 0, 0, 7); g.fill(); g.restore(); }
    leg(-11, -16, 0.55 * Math.sin(ph + 0.45), 0.4, coat); leg(10, -15, 0.6 * Math.sin(ph + 1.85), -0.6, coat);
    if (Co.sk) { g.fillStyle = '#f4efe6'; for (const [x, y] of [[-11 + Math.sin(0.55 * Math.sin(ph + 0.45)) * 8, -3], [10 + Math.sin(0.6 * Math.sin(ph + 1.85)) * 8, -2]]) { g.beginPath(); g.arc(x, y, 1.7, 0, 7); g.fill(); } }
  }
  /* 서 있는 말 옆모습(카드·표지용): 100×70 칸, 발 = y 68, 머리는 오른쪽 */
  function drawHorseStand(g, Co) {
    const coat = Co.c, dark = shade(coat, -0.28), mane = Co.m;
    const leg = (pts, col) => { g.fillStyle = col; g.beginPath(); g.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.closePath(); g.fill(); };
    // 먼 쪽 다리
    leg([66, 38, 69, 50, 68, 62, 70, 68, 66, 68, 65, 62, 64, 50, 61, 39], dark);
    leg([31, 40, 28, 48, 25, 54, 26, 62, 28, 68, 24, 68, 22, 62, 21, 54, 24, 44], dark);
    // 꼬리
    g.strokeStyle = mane; g.lineCap = 'round'; g.lineWidth = 4; g.beginPath(); g.moveTo(19, 22); g.quadraticCurveTo(11, 30, 13, 48); g.stroke();
    g.lineWidth = 2; g.beginPath(); g.moveTo(18, 24); g.quadraticCurveTo(14, 36, 16, 50); g.stroke();
    // 몸통·목·머리
    g.fillStyle = coat; g.beginPath();
    g.moveTo(19, 22); g.bezierCurveTo(26, 17, 40, 21, 56, 19); g.lineTo(63, 15);
    g.bezierCurveTo(68, 9, 74, 4, 79, 2); g.lineTo(81, -2); g.lineTo(83, 2);
    g.bezierCurveTo(87, 6, 91, 13, 94, 18); g.bezierCurveTo(95, 21, 92, 23, 89, 21);
    g.bezierCurveTo(85, 18, 82, 16, 80, 15); g.bezierCurveTo(77, 22, 74, 28, 73, 34);
    g.lineTo(74, 40); g.lineTo(73, 50); g.lineTo(73, 62); g.lineTo(75, 68); g.lineTo(70, 68); g.lineTo(69, 62); g.lineTo(68, 50); g.lineTo(66, 41);
    g.bezierCurveTo(58, 43, 46, 43, 38, 41);
    g.lineTo(36, 46); g.lineTo(33, 52); g.lineTo(32, 62); g.lineTo(34, 68); g.lineTo(29, 68); g.lineTo(28, 62); g.lineTo(27, 54); g.lineTo(23, 47);
    g.bezierCurveTo(19, 40, 17, 30, 19, 22); g.closePath(); g.fill();
    // 갈기
    g.strokeStyle = mane; g.lineWidth = 2.6; g.beginPath(); g.moveTo(62, 15); g.bezierCurveTo(67, 9, 73, 4, 79, 3); g.stroke();
    // 얼굴 흰 줄 · 흰 양말
    if (Co.bz) { g.strokeStyle = '#f2ece0'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(84, 5); g.lineTo(92, 17); g.stroke(); }
    if (Co.sk) { g.fillStyle = '#f2ece0'; g.fillRect(69.2, 63, 4.2, 4.6); g.fillRect(28.4, 63, 4.2, 4.6); }
    // 눈
    g.fillStyle = 'rgba(0,0,0,.55)'; g.beginPath(); g.arc(84, 8, 0.9, 0, 7); g.fill();
  }
  /* 위에서 본 말(경마 게임 그림을 옮김): 단위 m, 머리 방향 hd */
  function drawHorseTop(g, x, y, hd, Co, silk, ph) {
    g.save(); g.translate(x, y); g.rotate(hd);
    g.fillStyle = 'rgba(0,0,0,.26)'; g.beginPath(); g.ellipse(0.1, 0.25, 1.25, 0.45, 0, 0, 7); g.fill();
    g.lineWidth = 0.13; g.lineCap = 'round';
    const lg = (bx, by, o) => { const a = Math.sin(ph + o) * 0.45; g.strokeStyle = shade(Co.c, -0.35); g.beginPath(); g.moveTo(bx, by); g.lineTo(bx + a, by + Math.sign(by) * 0.18); g.stroke(); };
    lg(0.75, 0.32, 0); lg(0.75, -0.32, 0.7); lg(-0.75, 0.32, 2.2); lg(-0.75, -0.32, 2.9);
    g.strokeStyle = Co.m; g.lineWidth = 0.22; g.beginPath(); g.moveTo(-1.05, 0); g.quadraticCurveTo(-1.45, Math.sin(ph * 0.5) * 0.25, -1.65, Math.sin(ph * 0.5 + 1) * 0.2); g.stroke();
    g.fillStyle = Co.c; g.beginPath(); g.ellipse(0, 0, 1.08, 0.38, 0, 0, 7); g.fill();
    const nod = Math.sin(ph) * 0.05;
    g.beginPath(); g.ellipse(1.15 + nod, 0, 0.42, 0.2, 0, 0, 7); g.fill();
    g.beginPath(); g.ellipse(1.58 + nod, 0, 0.3, 0.15, 0, 0, 7); g.fill();
    g.strokeStyle = Co.m; g.lineWidth = 0.1; g.beginPath(); g.moveTo(0.75, 0); g.lineTo(1.4 + nod, 0); g.stroke();
    if (Co.bz) { g.strokeStyle = '#f4efe6'; g.lineWidth = 0.07; g.beginPath(); g.moveTo(1.45 + nod, 0); g.lineTo(1.84 + nod, 0); g.stroke(); }
    g.fillStyle = silk; g.fillRect(-0.35, -0.42, 0.55, 0.84);
    g.fillStyle = shade(silk, -0.25); g.beginPath(); g.ellipse(0.12, 0, 0.32, 0.36, 0, 0, 7); g.fill();
    g.fillStyle = silk; g.beginPath(); g.arc(0.38, 0, 0.17, 0, 7); g.fill();
    g.fillStyle = '#efe7d6'; g.beginPath(); g.arc(0.38, 0, 0.07, 0, 7); g.fill();
    g.restore();
  }
  /* 트랙 위 위치: p = 결승선부터 진행 방향으로 잰 안쪽 울타리 거리, l = 울타리에서 바깥으로(m) */
  function posAt(T, p, l) {
    p = ((p % T.P) + T.P) % T.P;
    const S = T.S, Rr = T.R, C = T.C, r = Rr + l;
    if (p < C) { const th = PI / 2 - p / Rr; return [S / 2 + r * Math.cos(th), r * Math.sin(th), th - PI / 2]; }
    if (p < C + S) return [S / 2 - (p - C), -r, PI];
    if (p < 2 * C + S) { const th = -PI / 2 - (p - C - S) / Rr; return [-S / 2 + r * Math.cos(th), r * Math.sin(th), th - PI / 2]; }
    return [-S / 2 + (p - 2 * C - S), r, 0];
  }
  function ovalPath(g, T, l) {
    const S = T.S, r = T.R + l;
    g.beginPath(); g.moveTo(-S / 2, r); g.lineTo(S / 2, r); g.arc(S / 2, 0, r, PI / 2, -PI / 2, true); g.lineTo(-S / 2, -r); g.arc(-S / 2, 0, r, -PI / 2, PI / 2, true); g.closePath();
  }
  const GBADGE = ['신마', '미승리', '1승', 'L', 'G3', 'G2', 'G1'];
  const fmtTime = (t) => { const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); };
  function marginTxt(dt) { // 초 차 → 마신 차(1마신 ≈ 0.17초)
    const b = dt / 0.17;
    if (b < 0.05) return '코';
    if (b < 0.15) return '머리';
    if (b < 0.3) return '목';
    if (b < 0.75) return '1/2';
    if (b < 1.1) return '1';
    if (b < 1.4) return '1 1/4';
    if (b < 1.65) return '1 1/2';
    if (b < 1.9) return '1 3/4';
    if (b < 2.5) return '2';
    if (b < 3.5) return '3';
    if (b < 4.5) return '4';
    if (b < 6) return '5';
    return '대차';
  }

  const ICON = '<path d="M15 47c2-9 5-15 10-19-2-5-1-10 2-14l3-7 3 5c5 1 10 4 13 9l4 7c1 3-1 5-4 4l-6-2c-2 3-3 7-3 11l1 6z" fill="currentColor"/><circle cx="34" cy="17" r="1.6" fill="#1d2a24"/><path d="M8 50h40" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>';
  const IC = {
    race: '<svg viewBox="0 0 24 24"><circle cx="12" cy="9" r="5.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8.5 13.5L6 22l6-3 6 3-2.5-8.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/></svg>',
    train: '<svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="8" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 13V8M10 2h4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    ab: '<svg viewBox="0 0 24 24"><path d="M5 4h10l4 4v12H5z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M8 11h8M8 15h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    jk: '<svg viewBox="0 0 24 24"><path d="M4 15a8 8 0 0116 0z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M2 15h20M12 7V4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    staff: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 21c1-5 4-7 8-7s7 2 8 7" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
    ped: '<svg viewBox="0 0 24 24"><path d="M12 21V11M12 11L6 5M12 11l6-6M6 5v-2M18 5v-2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    title: '<svg viewBox="0 0 24 24"><path d="M7 4h10v5a5 5 0 01-10 0zM12 14v4M8 21h8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
    hof: '<svg viewBox="0 0 24 24"><path d="M3 9l9-5 9 5M5 10v8M10 10v8M14 10v8M19 10v8M3 20h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  };

  /* ======================= 명예의 전당(이 기기) ======================= */
  const HOF_KEY = 'lounge.horsecareer.hof';
  function hofList() { try { const a = JSON.parse(localStorage.getItem(HOF_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; } }
  function hofAdd(e) {
    try {
      const a = hofList();
      if (a.some((x) => x.id === e.id)) return;
      a.push(e); a.sort((x, y) => y.rt - x.rt);
      localStorage.setItem(HOF_KEY, JSON.stringify(a.slice(0, 30)));
    } catch (er) { /* 저장 불가 — 무시 */ }
  }

  /* ======================= 화면 ======================= */
  const CSS = `
.hc{word-break:keep-all;overflow-wrap:break-word;--pp:#ebe4d2;--pp2:#e1d8c2;--ink:#23211c;--ink2:#5e584b;--rule:#c4b99d;--red:#8e2b22;--grn:#2f5a43;--brs:#9a7a34;--dk:#1b1a16;--dk2:#27251f;--dki:#e8e0cc;--dkm:#a49d8b;
 position:absolute;inset:0;display:flex;flex-direction:column;overflow:hidden;background:#1b1a16;color:var(--ink);font-family:var(--f-body);user-select:none;-webkit-user-select:none}
.hc *{box-sizing:border-box}
.hc button{font-family:inherit;-webkit-tap-highlight-color:transparent}
.hc-head{flex:none;display:flex;align-items:center;gap:10px;height:44px;padding:0 54px 0 12px;background:var(--dk);color:var(--dki);border-bottom:1px solid #3a372e}
.hc-when{font-family:${SERIF};font-weight:700;font-size:16px;letter-spacing:.01em;white-space:nowrap}
.hc-turn{font:500 12px var(--f-mono);color:var(--dkm);white-space:nowrap}
.hc-money{margin-left:auto;text-align:right;line-height:1.1;white-space:nowrap}
.hc-money b{display:block;font:600 14px var(--f-mono);color:#e2c98e}
.hc-money span{font-size:12px;color:var(--dkm)}
.hc-others{flex:none;display:flex;gap:6px;overflow-x:auto;padding:4px 8px;background:var(--dk2);touch-action:pan-x;scrollbar-width:none}
.hc-others::-webkit-scrollbar{display:none}
.hc-oc{flex:none;display:flex;align-items:center;gap:6px;min-height:44px;padding:0 12px;border-radius:22px;border:1px solid #5a5440;background:transparent;color:var(--dki);font-size:12.5px;white-space:nowrap;cursor:pointer}
.hc-oc i{width:10px;height:10px;border-radius:50%;background:var(--c)}
.hc-oc.me{border-color:#c9b27a;background:#3a3424}
.hc-oc em{font-style:normal;color:var(--dkm);font-size:12px}
.hc-oc em.ok{color:#9cc49f}
.hc-body{flex:1 1 auto;min-height:0;display:flex;flex-direction:column}
.hc-left{flex:none;display:flex;flex-direction:column}
.hc-right{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;position:relative}
.hc-card{display:flex;gap:10px;align-items:center;padding:8px 12px 6px;background:var(--pp);border-bottom:1px solid var(--rule)}
.hc-card canvas{flex:none;width:84px;height:58px}
.hc-id{flex:1 1 auto;min-width:0}
.hc-nmr{display:flex;align-items:baseline;gap:8px;min-width:0}
.hc-rc{flex:none;margin-left:auto;font:600 12px var(--f-mono);color:var(--ink)}
.hc-nm{min-width:0;font-family:${SERIF};font-weight:700;font-size:19px;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--ink)}
.hc-ped{font-size:12px;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:16px}
.hc-apt{display:flex;flex-wrap:wrap;gap:0 5px;margin-top:1px;font-size:12px;color:var(--ink);white-space:nowrap;line-height:17px}
.hc-apt .k{color:var(--ink2);font-size:12px}
.hc-apt .k:not(:first-child){margin-left:4px}
.hc-apt b{font:700 12.5px var(--f-mono);color:var(--ink)}
.hc-apt b.A{color:var(--red)}
.hc-rec{flex:none;text-align:right;line-height:1.2}
.hc-rec b{display:block;font:600 14px var(--f-mono)}
.hc-rec span{font-size:12px;color:var(--ink2)}
.hc-stats{display:grid;grid-template-columns:repeat(5,1fr);background:var(--pp);border-bottom:1px solid var(--rule)}
.hc-st{position:relative;padding:4px 4px 5px;text-align:center;border-left:1px solid var(--pp2)}
.hc-st:first-child{border-left:0}
.hc-st small{display:block;font-size:12px;color:var(--ink2);line-height:14px;letter-spacing:-.02em}
.hc-st .gr{font-family:${SERIF};font-weight:700;font-size:18px;line-height:20px}
.hc-st .v{font:600 12.5px var(--f-mono);color:var(--ink);line-height:15px}
.hc-st .bar{height:4px;margin:3px 2px 0;background:#d3c8ad;border-radius:2px;overflow:hidden}
.hc-st .bar i{display:block;height:100%;background:var(--ink2)}
.hc-st .pop{position:absolute;left:0;right:0;top:-2px;font:700 14px var(--f-mono);color:var(--grn);text-shadow:0 0 3px #ebe4d2,0 0 3px #ebe4d2;pointer-events:none;animation:hcUp 1.5s forwards}
.hc-st .pop.m{color:var(--red)}
@keyframes hcUp{0%{opacity:0;transform:translateY(6px)}15%{opacity:1}75%{opacity:1}100%{opacity:0;transform:translateY(-10px)}}
.hc-status{display:flex;align-items:center;gap:6px 8px;padding:5px 12px;background:var(--pp2);border-bottom:1px solid var(--rule);font-size:12px;color:var(--ink2);min-height:34px;flex-wrap:wrap}
.hc-hp{display:flex;align-items:center;gap:6px;flex:1 1 120px;min-width:110px}
.hc-hp .g{flex:1;height:10px;background:#cdbf9e;border-radius:4px;overflow:hidden}
.hc-hp .g i{display:block;height:100%;background:var(--grn);transition:width .4s}
.hc-hp .g i.lo{background:#a8732c}.hc-hp .g i.vlo{background:var(--red)}
.hc-hp b{font:700 13px var(--f-mono);color:var(--ink);min-width:28px;text-align:right}
.hc-tag{padding:2px 8px;border-radius:10px;border:1px solid var(--rule);background:var(--pp);color:var(--ink);white-space:nowrap;line-height:17px;font-size:12px}
.hc-tag.bad{border-color:#b98a80;color:var(--red);font-weight:600}
.hc-tag.good{border-color:#8fb09a;color:var(--grn)}
.hc-tabs{flex:none;display:grid;grid-template-columns:repeat(5,1fr);background:var(--dk);border-bottom:1px solid #3a372e}
.hc-tab{min-height:44px;border:0;background:transparent;color:#bdb5a0;font-size:14px;font-weight:500;cursor:pointer;position:relative;padding:0 2px}
.hc-tab.on{color:var(--dki);font-weight:700}
.hc-tab.on::after{content:"";position:absolute;left:14%;right:14%;bottom:0;height:3px;background:#c9b27a}
.hc-tab:disabled{opacity:.35;cursor:default}
.hc-panel{flex:1 1 auto;min-height:0;overflow-y:auto;overscroll-behavior:contain;touch-action:pan-y;background:var(--pp);padding:8px 10px 10px;position:relative}
.hc-go{flex:none;display:flex;gap:8px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));background:var(--dk);border-top:1px solid #3a372e}
.hc-btn{min-height:48px;border-radius:6px;border:1px solid #6b6045;background:#2c2a22;color:var(--dki);font-size:15px;font-weight:600;cursor:pointer;padding:0 14px}
.hc-btn.pri{flex:1;background:#d8c9a3;color:#1d1b16;border-color:#d8c9a3}
.hc-btn.pri:disabled{background:#33302a;color:#bdb5a0;border-color:#4a463b;border-style:dashed;cursor:default}
.hc-btn:active:not(:disabled){transform:translateY(1px);filter:brightness(.92)}
.hc-sec{font-family:${SERIF};font-weight:700;font-size:14px;color:var(--ink);margin:6px 0 5px;padding-bottom:3px;border-bottom:1px solid var(--rule);display:flex;justify-content:space-between;align-items:baseline;gap:8px}
.hc-sec small{font:500 12px var(--f-body);color:var(--ink2)}
.hc-sec:first-child{margin-top:0}
.hc-trs{display:grid;grid-template-columns:repeat(5,1fr);gap:5px}
.hc-tr{position:relative;min-height:108px;border:1px solid #b5a988;border-radius:6px;background:#f3eddf;padding:5px 3px 4px;text-align:center;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:1px;color:var(--ink)}
.hc-tr.on{border:2px solid var(--ink);padding:4px 2px 3px;background:#fbf7ec}
.hc-tr:disabled{background:#e6dfcd;border-style:dashed;cursor:default}
.hc-tr:active:not(:disabled),.hc-race:active,.hc-cr:active:not(:disabled),.hc-ab:active,.hc-foal:active,.hc-jk:active,.hc-seg button:active{filter:brightness(.93)}
.hc-tr .n{font-size:13px;font-weight:700;line-height:16px;letter-spacing:-.02em}
.hc-tr .lv{font:600 11px var(--f-mono);color:var(--ink2)}
.hc-tr .g{font:700 18px var(--f-mono);line-height:21px;color:var(--grn)}
.hc-tr .s{font-size:12px;color:var(--ink);line-height:14px;display:flex;flex-direction:column;gap:1px;letter-spacing:-.04em;white-space:normal;word-break:keep-all}
.hc-tr .f{font:600 12px var(--f-body);margin-top:auto;letter-spacing:-.03em}
.hc-tr .f.w{color:#a8732c}.hc-tr .f.d{color:var(--red)}
.hc-tr .sf{display:flex;gap:3px;justify-content:center;min-height:8px}
.hc-tr .sf i{width:8px;height:8px;border-radius:50%;background:var(--brs)}
.hc-tr .sf i.b{background:var(--red);border-radius:1px;transform:rotate(45deg)}
.hc-det{margin-top:8px;padding:7px 9px;border-left:3px solid var(--ink2);background:#f3eddf;font-size:13px;line-height:1.5;color:var(--ink)}
.hc-det .mono{font-family:var(--f-mono)}
.hc-det p{margin:0}
.hc-det p+p{margin-top:2px;color:var(--ink2);font-size:12.5px}
.hc-rl{display:flex;flex-direction:column;gap:5px}
.hc-race{display:flex;gap:8px;align-items:center;min-height:52px;padding:6px 8px;border:1px solid var(--rule);border-radius:6px;background:#f3eddf;cursor:pointer;color:var(--ink);text-align:left}
.hc-race.on{border:2px solid var(--ink);padding:5px 7px;background:#fbf7ec}
.hc-race.no{background:#e6dfcd;border-style:dashed}
.hc-race.no .hc-ri .n{color:var(--ink2)}
.hc-gb{flex:none;min-width:42px;text-align:center;font:700 12px var(--f-body);letter-spacing:0;padding:3px 4px;border-radius:3px;border:1px solid var(--ink2);color:var(--ink)}
.hc-gb.g6{background:var(--red);border-color:var(--red);color:#f3eadb}
.hc-gb.g5,.hc-gb.g4{background:var(--ink);border-color:var(--ink);color:#f3eadb}
.hc-gb.g3{border-color:var(--brs);color:var(--brs)}
.hc-ri{flex:1;min-width:0}
.hc-ri .n{font-family:${SERIF};font-weight:700;font-size:14px;line-height:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hc-ri .m{font-size:12px;color:var(--ink2);line-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hc-ri .why{font-size:12px;color:var(--red);font-weight:600}
.hc-ra{flex:none;text-align:right;font-size:12px;color:var(--ink2);line-height:16px}
.hc-ra b{font:700 13px var(--f-mono);color:var(--ink)}
.hc-plan{margin-top:8px;padding:8px;border:1px solid var(--rule);border-radius:6px;background:#f3eddf}
.hc-seg{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;margin:4px 0 8px}
.hc-seg button{min-height:48px;border:1px solid #b5a988;border-radius:5px;background:var(--pp);color:var(--ink);font-size:13px;font-weight:600;line-height:15px;cursor:pointer;padding:2px}
.hc-seg button small{display:block;font:500 12px var(--f-body);color:var(--ink2);margin-top:1px}
.hc-seg button.on{background:var(--ink);color:#f3eadb;border-color:var(--ink)}
.hc-seg button.on small{color:#cfc4a8}
.hc-pl{font-size:12.5px;color:var(--ink2);line-height:1.45}
.hc-pl b{color:var(--ink)}
.hc-care{display:flex;flex-direction:column;gap:5px}
.hc-cr{display:flex;align-items:center;gap:10px;min-height:50px;padding:6px 10px;border:1px solid var(--rule);border-radius:6px;background:#f3eddf;cursor:pointer;text-align:left;color:var(--ink)}
.hc-cr.on{border:2px solid var(--ink);padding:5px 9px;background:#fbf7ec}
.hc-cr:disabled{background:#e6dfcd;border-style:dashed;color:var(--ink2);cursor:default}
.hc-cr b{font-family:${SERIF};font-size:14px;min-width:64px}
.hc-cr span{font-size:12.5px;color:var(--ink2);line-height:1.4}
.hc-abs{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.hc-ab{min-height:48px;padding:5px 7px;border:1px solid var(--rule);border-radius:6px;background:#f3eddf;text-align:left;cursor:pointer;color:var(--ink);display:flex;flex-direction:column;gap:1px}
.hc-ab b{font-size:13px}
.hc-ab span{font-size:12px;color:var(--ink2);line-height:1.35}
.hc-ab em{font-size:12px;font-weight:700;font-style:normal;color:var(--ink2)}
.hc-ab.have{background:#e3eadf;border-color:#9db3a3}
.hc-ab.have em{color:var(--grn)}
.hc-ab.lock{background:#e6dfcd;border-style:dashed}
.hc-ab.lock b{color:var(--ink2)}
.hc-ab.on{border:2px solid var(--ink);padding:4px 6px}
.hc-rows{display:flex;flex-direction:column}
.hc-row{display:flex;gap:6px;align-items:baseline;padding:5px 0;border-bottom:1px dotted var(--rule);font-size:13px;line-height:1.4}
.hc-row .a{flex:none;width:84px;color:var(--ink2);font-size:12px}
.hc-row .b{flex:1;min-width:0}
.hc-row .c{flex:none;font:600 12.5px var(--f-mono)}
.hc-row .c.w{color:var(--red)}
.hc-meter{height:6px;background:#d3c8ad;border-radius:3px;overflow:hidden;margin-top:3px}
.hc-meter i{display:block;height:100%;background:var(--brs)}
.hc-empty{padding:16px 6px;color:var(--ink2);font-size:13px;text-align:center;line-height:1.6}
.hc-slip{position:absolute;left:50%;bottom:74px;transform:translateX(-50%);z-index:6;max-width:92%;padding:6px 14px;border-radius:16px;background:rgba(27,26,22,.86);color:#f3ead6;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;animation:hcSlip 1.6s forwards}
@keyframes hcSlip{0%{opacity:0}10%{opacity:1}80%{opacity:1}100%{opacity:0}}
.hc-wait{font-size:12.5px;color:var(--ink2);text-align:center;padding:2px 0 0}
.hc-ov{position:absolute;inset:0;z-index:20;display:flex;align-items:center;justify-content:center;background:rgba(15,14,11,.62);padding:16px}
.hc-ev{width:min(420px,100%);max-height:100%;overflow-y:auto;background:var(--pp);border-radius:4px;box-shadow:0 10px 40px rgba(0,0,0,.6);padding:14px 14px 12px;touch-action:pan-y}
.hc-ev .k{font-size:12px;font-weight:600;letter-spacing:.04em;color:var(--ink2)}
.hc-ev h3{font-family:${SERIF};font-size:19px;margin:2px 0 8px;color:var(--ink);padding-bottom:6px;border-bottom:2px solid var(--ink)}
.hc-ev p{font-size:13.5px;line-height:1.6;margin:0 0 12px;color:var(--ink)}
.hc-ev .ch{display:flex;flex-direction:column;gap:6px}
.hc-ev .ch button{min-height:52px;text-align:left;padding:6px 12px;border:1px solid var(--ink2);border-radius:5px;background:#f6f1e5;color:var(--ink);cursor:pointer}
.hc-ev .ch button b{display:block;font-size:15px}
.hc-ev .ch button span{font-size:12.5px;color:var(--ink2)}
.hc-pick{flex:1 1 auto;min-height:0;overflow-y:auto;touch-action:pan-y;background:var(--pp);padding:10px 10px 6px}
.hc-pick h2{font-family:${SERIF};font-size:20px;margin:0 0 2px;color:var(--ink)}
.hc-pick .lead{font-size:13px;color:var(--ink2);margin:0 0 8px;line-height:1.5}
.hc-foals{display:flex;flex-direction:column;gap:7px}
.hc-foal{display:flex;gap:9px;padding:8px;border:1px solid var(--rule);border-radius:6px;background:#f3eddf;cursor:pointer;text-align:left;color:var(--ink);align-items:flex-start}
.hc-foal.on{border:2px solid var(--ink);padding:7px;background:#fbf7ec}
.hc-foal canvas{flex:none;width:76px;height:54px}
.hc-foal .t{flex:1;min-width:0}
.hc-foal .fn{font-family:${SERIF};font-weight:700;font-size:17px;line-height:20px;color:var(--ink)}
.hc-foal .op{color:var(--ink)!important}
.hc-foal .mono{font:500 12px var(--f-body)!important;margin-top:2px;color:var(--ink)!important}
.hc-foal .t span{display:block;font-size:12px;color:var(--ink2);line-height:16px}
.hc-at{display:grid;grid-template-columns:auto repeat(4,1fr);gap:1px 4px;margin-top:4px;font-size:12px;color:var(--ink2);align-items:center}
.hc-at b{font:700 12.5px var(--f-mono);color:var(--ink);text-align:center}
.hc-at b.A{color:var(--red)}
.hc-at i{font-style:normal;text-align:center;font-size:12px}
.hc-jks{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-top:4px}
.hc-jk{min-height:64px;padding:5px;border:1px solid var(--rule);border-radius:6px;background:#f3eddf;text-align:left;cursor:pointer;color:var(--ink);display:flex;flex-direction:column;gap:1px}
.hc-jk.on{border:2px solid var(--ink);padding:4px}
.hc-jk b{font-size:13px;line-height:16px}
.hc-jk span{font-size:12px;color:var(--ink2);line-height:15px}
.hc-rv{position:absolute;inset:0;z-index:25;background:#16170f;overflow:hidden}
.hc-rv canvas{position:absolute;inset:0;width:100%;height:100%}
.hc-rv .top{position:absolute;left:0;right:0;top:0;padding:6px 64px 8px 10px;background:linear-gradient(#000d,#0000);text-shadow:0 1px 2px #000;color:#efe6d2;pointer-events:none}
.hc-rv .top b{font-family:${SERIF};font-size:16px;display:block;line-height:20px}
.hc-rv .top span{font-size:12px;color:#d6ccb6}
.hc-rv .cm{position:absolute;left:10px;right:96px;bottom:calc(10px + env(safe-area-inset-bottom));min-height:44px;padding:6px 10px;border-radius:4px;background:rgba(15,14,11,.8);color:#f3ead6;font-size:14px;line-height:1.4;pointer-events:none;display:flex;align-items:center}
.hc-rv .skip{position:absolute;right:8px;bottom:calc(8px + env(safe-area-inset-bottom));min-width:80px;min-height:48px;border-radius:6px;border:1px solid #c9b27a;background:rgba(27,26,22,.9);color:#f3ead6;font-size:14px;font-weight:600;cursor:pointer}
.hc-res{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:min(400px,calc(100% - 20px));max-height:calc(100% - 24px);overflow-y:auto;background:var(--pp);border-radius:3px;box-shadow:0 10px 40px #000;padding:12px 12px 10px;touch-action:pan-y;color:var(--ink)}
.hc-res .k{font-size:12px;font-weight:600;letter-spacing:.04em;color:var(--ink2)}
.hc-res h3{font-family:${SERIF};font-size:18px;margin:1px 0 2px}
.hc-res .sub{font-size:12px;color:var(--ink2);padding-bottom:5px;border-bottom:2px solid var(--ink)}
.hc-res table{width:100%;border-collapse:collapse;font-size:13px;margin-top:4px}
.hc-res td{padding:3px 3px;border-bottom:1px dotted var(--rule);white-space:nowrap}
.hc-res td.n{max-width:150px;overflow:hidden;text-overflow:ellipsis}
.hc-res td.r{font:600 13px var(--f-mono);width:24px;text-align:center}
.hc-res td.t{font-size:12.5px;font-variant-numeric:tabular-nums;text-align:right;color:var(--ink2)}
.hc-res tr.me td{background:#efe2bf;font-weight:700}
.hc-res tr.me td.t{color:var(--ink)}
.hc-res .sq{display:inline-block;width:10px;height:10px;margin-right:5px;border-radius:2px;vertical-align:0}
.hc-res .gain{margin-top:6px;font-size:13px;line-height:1.5}
.hc-res .gain b{font-weight:700}
.hc-res .act{display:flex;justify-content:flex-end;margin-top:8px}
.hc.wide .hc-body{flex-direction:row}
.hc.wide .hc-left{width:min(46%,460px);border-right:1px solid var(--rule);background:var(--pp);overflow-y:auto}
.hc.wide .hc-card canvas{width:120px;height:84px}
.hc.wide .hc-nm{font-size:24px}
.hc.wide .hc-st .gr{font-size:22px;line-height:26px}
.hc.wide .hc-tr{min-height:120px}
.hc-lnews{display:none}
.hc.wide .hc-lnews{display:block;padding:8px 12px;font-size:13px;line-height:1.55;color:var(--ink2)}
.hc.wide .hc-lnews p{margin:0 0 3px}
`;

  function aptRow(h, i0, n, labels, fx) {
    const out = [];
    for (let i = 0; i < n; i++) { const g = fx ? fx(i0 + i) : h.apt[i0 + i]; out.push(L.h('span', {}, labels[i] + ' ', L.h('b', { class: g === 'A' ? 'A' : '', text: g }))); }
    return out;
  }
  function statGrade(v) { return v >= 1000 ? 'S+' : v >= 900 ? 'S' : v >= 750 ? 'A' : v >= 600 ? 'B' : v >= 450 ? 'C' : v >= 320 ? 'D' : v >= 220 ? 'E' : v >= 130 ? 'F' : 'G'; }
  function popLabel(p) { return p > 0.45 ? '1번 인기권' : p > 0.22 ? '상위 인기' : p > 0.08 ? '중간 인기' : p > 0.025 ? '인기 밖' : '큰 인기 밖'; }

  function mount(root, api) {
    const h = L.h;
    if (!document.getElementById('hc-css')) document.head.append(h('style', { id: 'hc-css', text: CSS }));
    const wrap = h('div', { class: 'hc' });
    root.append(wrap);
    let st = null, focus = -1, tab = 'tr', dead = false, shownLast = 0, seenEv = '';
    const sel = { tr: -1, race: '', p: 3, s: 3, care: -1, ab: '' };
    const NM = (i) => (api.players[i] && api.players[i].name) || ('자리 ' + (i + 1));
    const COL = (i) => (api.players[i] && api.players[i].color) || '#c9b27a';
    const SPD = () => Math.max(0.25, (L.debug.speed || 1) * (L.speed ? L.speed() : 1));
    const raceQ = [];
    let rv = null, busy = false, tutDone = false;
    function setBusy(b) { if (busy !== b) { busy = b; api.setBusy(b); } }

    function pickFocus(s, auto) {
      const mine = api.mySeats();
      if (auto && focus >= 0 && mine.length > 1 && mine.includes(focus)) {   // 한 폰 여럿: 내 자리가 끝났으면 아직 고를 내 다음 자리로 넘김
        const act = actor(s) || [];
        if (!act.includes(focus)) { const nx = mine.find((x) => act.includes(x)); if (nx != null) { if (nx !== focus) { sel.tr = -1; sel.race = ''; sel.care = -1; pickSel.f = -1; pickSel.j = -1; } return nx; } }
      }
      if (focus >= 0 && (mine.includes(focus) || !mine.length)) return focus;
      if (mine.length) {
        const act = (actor(s) || []).filter((x) => mine.includes(x));
        return act.length ? act[0] : mine[0];
      }
      return 0;
    }
    const P = () => st.P[focus];
    const canAct = () => st && api.canAct(focus) && (actor(st) || []).includes(focus);
    function act(a) { if (!canAct()) return; api.sfx('click'); api.actAs(focus, a); }

    /* ---------- 레이아웃 ---------- */
    const head = h('div', { class: 'hc-head' });
    const others = h('div', { class: 'hc-others' });
    const body = h('div', { class: 'hc-body' });
    const left = h('div', { class: 'hc-left' }), right = h('div', { class: 'hc-right' });
    const card = h('div', { class: 'hc-card' });
    const hcv = h('canvas', { width: 168, height: 116 });
    const stats = h('div', { class: 'hc-stats' });
    const status = h('div', { class: 'hc-status' });
    const lnews = h('div', { class: 'hc-lnews' });
    const tabs = h('div', { class: 'hc-tabs', role: 'tablist' });
    const panel = h('div', { class: 'hc-panel' });
    const go = h('div', { class: 'hc-go' });
    left.append(card, stats, status, lnews);
    right.append(tabs, panel, go);
    body.append(left, right);
    let pickEl = null;
    wrap.append(head, others, body);
    function layout() {
      const W = wrap.clientWidth || 360, Hh = wrap.clientHeight || 640;
      wrap.classList.toggle('wide', W >= 760 && Hh >= 420);
    }
    const onRs = () => { layout(); if (rv) rv.resize(); };
    /* PC 단축키(controls): Space = 아래 큰 단추(진행 · 건너뛰기 · 확인), 1~5 = 지금 목록의 n번째, ←/→ = 탭 바꾸기 */
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || dead) return;
      const vis = (el) => el && el.isConnected && el.getClientRects().length;
      if (id === 'go') {
        const b = [wrap.querySelector('.hc-resok'), wrap.querySelector('.hc-racev .skip'), wrap.querySelector('.hc-gobtn')].find((x) => vis(x) && !x.disabled);
        if (b && !wrap.querySelector('.hc-evov')) b.click();
        return;
      }
      if (rv) return;
      const m = /^n(\d)$/.exec(id);
      if (m) {
        const k = +m[1] - 1;
        const list = wrap.querySelector('.hc-evov') ? wrap.querySelectorAll('.hc-ev .ch button')
          : st && st.ph === 'pick' ? wrap.querySelectorAll('.hc-foal')
          : wrap.querySelectorAll(tab === 'tr' ? '.hc-tr' : tab === 'race' ? '.hc-race' : tab === 'care' ? '.hc-cr' : tab === 'ab' ? '.hc-ab' : '.none');
        const b = list[k];
        if (b && !b.disabled) { b.click(); if (b.scrollIntoView) b.scrollIntoView({ block: 'nearest' }); }
        return;
      }
      if ((id === 'prev' || id === 'next') && st && st.ph !== 'pick' && !wrap.querySelector('.hc-evov')) {
        const i = TABS.findIndex((x) => x[0] === tab), j = (i + (id === 'next' ? 1 : TABS.length - 1)) % TABS.length;
        tab = TABS[j][0]; api.sfx('tick'); render();
      }
    }) : null;
    window.addEventListener('resize', onRs);
    layout();

    function drawCardHorse(cv, q, big) {
      const g = cv.getContext('2d'), W = cv.width, Hh = cv.height;
      g.clearRect(0, 0, W, Hh);
      g.strokeStyle = 'rgba(35,33,28,.25)'; g.lineWidth = 1; g.beginPath(); g.moveTo(6, Hh - 12); g.lineTo(W - 6, Hh - 12); g.stroke();
      const k = Math.min((W - 8) / 100, (Hh - 10) / 72);
      g.save(); g.translate((W - 100 * k) / 2, Hh - 12 - 68 * k + 2); g.scale(k, k);
      drawHorseStand(g, coatOf(q));
      g.restore();
    }
    let cardKey = '';

    /* ---------- 위 막대 ---------- */
    function renderHead() {
      head.textContent = '';
      const s = st;
      if (s.ph === 'pick') { head.append(h('span', { class: 'hc-when', text: '망아지 고르기' })); return; }
      const t = Math.min(s.t, s.T - 1);
      head.append(h('span', { class: 'hc-when', text: turnName(s, t) }), h('span', { class: 'hc-turn', text: (t + 1) + ' / ' + s.T }));
      const H = P() && P().h;
      if (H) head.append(h('span', { class: 'hc-money' }, h('b', { text: money(H.rec.e) }), h('span', { text: '통산 상금' })));
    }
    function renderOthers() {
      others.textContent = '';
      const s = st, mine = api.mySeats();
      if (s.n <= 1) { others.style.display = 'none'; return; }
      others.style.display = '';
      const acts = actor(s) || [];
      s.P.forEach((p, i) => {
        const H = p.h, ready = s.ph !== 'over' && !acts.includes(i);
        const lab = s.ph === 'pick' ? (p.pk != null ? '고름' : '고르는 중') : H && H.out ? '은퇴' : ready ? '결정함' : '고르는 중';
        const b = h('button', { class: 'hc-oc' + (i === focus ? ' me' : ''), style: { '--c': COL(i) }, onclick() { if (mine.includes(i) || !mine.length || true) { focus = i; sel.tr = -1; sel.race = ''; render(); } } },
          h('i'), (H ? H.n : NM(i)) + (H ? ' ' + H.rec.n + '전' + H.rec.w + '승' : ''), h('em', { class: ready ? 'ok' : '', text: lab }));
        others.append(b);
      });
    }

    /* ---------- 말 카드·능력치·상태 ---------- */
    function renderCard() {
      const H = P().h;
      const key = H.n + H.co;
      card.textContent = '';
      if (cardKey !== key) { cardKey = key; drawCardHorse(hcv, H); }
      const ty = H.ty === undefined ? 1 : H.ty + 1;
      card.append(hcv, h('div', { class: 'hc-id' },
        h('div', { class: 'hc-nmr' }, h('div', { class: 'hc-nm', text: H.n }), h('span', { class: 'hc-rc', text: H.rec.n + '전 ' + H.rec.w + '승' + (H.rec.g[2] ? ' · G1 ' + H.rec.g[2] + '승' : '') })),
        h('div', { class: 'hc-ped', text: CO[H.co].n + ' · 부 ' + H.sn + '(' + SIRES[H.si].n + ' 계열) · 모 ' + H.dn }),
        h('div', { class: 'hc-apt' }, h('span', { class: 'k', text: '거리' }), ...aptRow(H, 0, 4, ['단', '마', '중', '장'], (i) => aptL(H, i)), h('span', { class: 'k', text: '주로' }), ...aptRow(H, 4, 2, ['잔', '더'], (i) => aptL(H, i))),
        h('div', { class: 'hc-apt' }, h('span', { class: 'k', text: '각질' }), ...aptRow(H, 6, 3, ['선행', '선입', '추입'], (i) => aptL(H, i)), h('span', { class: 'k', text: '명성' }), h('span', { text: H.rec.f.toLocaleString('ko-KR') }))));
    }
    let popAt = 0;
    function renderStats(fx) {
      const H = P().h;
      stats.textContent = '';
      H.st.forEach((v, i) => {
        const c = h('div', { class: 'hc-st' }, h('small', { text: SN[i] }), h('div', { class: 'gr', text: statGrade(v) }), h('div', { class: 'v', text: String(v) }), h('div', { class: 'bar' }, h('i', { style: { width: Math.min(100, v / 12) + '%' } })));
        if (fx && fx.d && fx.d[i]) c.append(h('div', { class: 'pop' + (fx.d[i] < 0 ? ' m' : ''), text: (fx.d[i] > 0 ? '+' : '') + fx.d[i] }));
        stats.append(c);
      });
    }
    function renderStatus() {
      const H = P().h;
      status.textContent = '';
      const hp = H.hp;
      status.append(h('div', { class: 'hc-hp' }, h('span', { text: '체력' }), h('div', { class: 'g' }, h('i', { class: hp < 30 ? 'vlo' : hp < 55 ? 'lo' : '', style: { width: hp + '%' } })), h('b', { text: String(hp) })));
      status.append(h('span', { class: 'hc-tag' + (H.mood > 0 ? ' good' : H.mood < 0 ? ' bad' : ''), text: '컨디션 ' + MOODN[H.mood + 2] }));
      if (H.ail) status.append(h('span', { class: 'hc-tag bad', text: AILN[H.ail] }));
      if (H.inj > 0) status.append(h('span', { class: 'hc-tag bad', text: '부상 휴양 ' + H.inj }));
      if (H.camp > 0) status.append(h('span', { class: 'hc-tag good', text: '여름 합숙' }));
      status.append(h('span', { class: 'hc-tag' + (H.own < 35 ? ' bad' : ''), text: '마주 신뢰 ' + Math.max(0, H.own) }));
      if (H.goal && H.goal !== '*') { const g = GRK[H.goal]; if (g) status.append(h('span', { class: 'hc-tag', text: '목표 ' + g.n })); }
    }
    function renderNews() {
      lnews.textContent = '';
      if (!st.news.length) return;
      lnews.append(h('div', { class: 'hc-sec', style: { color: 'var(--ink)' } }, '소식'));
      st.news.slice(0, 6).forEach((n) => lnews.append(h('p', { text: '— ' + n[1] })));
    }

    /* ---------- 탭 ---------- */
    const TABS = [['tr', '훈련'], ['race', '출전'], ['care', '관리'], ['ab', '능력'], ['log', '기록']];
    function renderTabs() {
      tabs.textContent = '';
      TABS.forEach(([k, n]) => tabs.append(h('button', { class: 'hc-tab' + (tab === k ? ' on' : ''), role: 'tab', 'data-tab': k, text: n, onclick() { tab = k; api.sfx('tick'); render(); } })));
    }
    function goBtn(label, fn, dis, extra) {
      go.textContent = '';
      if (extra) go.append(extra);
      go.append(h('button', { class: 'hc-btn pri hc-gobtn', 'data-action': 'go', text: label, disabled: !!dis, onclick: fn }));
    }
    function waitLabel() {
      const p = api.players[focus];
      if (st.ph === 'over') return '커리어 종료';
      if (p && p.ai) return 'AI가 결정하는 중';
      if (!api.canAct(focus)) return '보기만 하는 자리';
      if (P().h && P().h.out) return '은퇴';
      return '다른 마주를 기다리는 중';
    }

    function renderPanel() {
      const keep = panel.scrollTop;
      panel.textContent = '';
      const H = P().h, mine = canAct();
      const forced = !!(H.inj > 0 || H.forceRest);
      if (tab === 'tr') {
        const sec = h('div', { class: 'hc-sec' }, '훈련', h('small', { text: '점은 함께하는 스태프' }));
        const grid = h('div', { class: 'hc-trs hc-train' });
        const gs = [0, 1, 2, 3, 4].map((k) => trainGain(st, P(), k));
        gs.forEach((g, k) => {
          const subs = g.g.map((v, i) => (v && i !== k ? SN[i] + ' +' + v : '')).filter(Boolean);
          const sf = h('div', { class: 'sf' }, ...g.here.map((i) => h('i', { class: H.sf[i] >= 80 && STAFF[i].k === k ? 'b' : '' })));
          grid.append(h('button', { class: 'hc-tr' + (sel.tr === k ? ' on' : ''), disabled: forced, onclick() { sel.tr = k; api.sfx('tick'); render(); } },
            h('span', { class: 'n', text: TRAIN[k].n }), h('span', { class: 'lv', text: 'Lv' + g.lv }), h('span', { class: 'g', text: '+' + g.g[k] }),
            h('span', { class: 's' }, ...subs.map((x) => h('span', { text: x }))), sf, h('span', { class: 'f' + (g.f >= 25 ? ' d' : g.f > 0 ? ' w' : ''), text: '실패 ' + g.f + '%' })));
        });
        panel.append(sec, grid);
        if (forced) panel.append(h('div', { class: 'hc-det' }, h('p', { text: H.inj > 0 ? '부상 휴양 중입니다. ' + H.inj + '턴 동안 휴양만 할 수 있습니다.' : '다리 붓기로 이번 턴은 쉬기로 했습니다.' })));
        else if (sel.tr >= 0) {
          const k = sel.tr, g = gs[k];
          const parts = g.g.map((v, i) => (v ? SN[i] + ' +' + v : '')).filter(Boolean);
          const staff = g.here.map((i) => STAFF[i].n + '(호흡 ' + H.sf[i] + ')').join(', ');
          panel.append(h('div', { class: 'hc-det' },
            h('p', {}, h('b', { text: TRAIN[k].n + ' 훈련 Lv' + g.lv }), ' — ' + parts.join(' · ') + ' · 체력 ' + (g.hp > 0 ? '−' + g.hp : '+' + (-g.hp)) + ' · 실패율 ' + g.f + '%'),
            h('p', { text: TRAIN[k].d + (staff ? ' · 동행: ' + staff : ' · 동행 스태프 없음') + ' · 같은 훈련 4번마다 Lv이 오름' })));
        } else panel.append(h('div', { class: 'hc-det' }, h('p', { text: '훈련을 눌러 효과를 확인합니다. 체력이 55 아래로 내려가면 실패율이 오르고, 실패하면 능력치와 컨디션이 떨어집니다.' })));
        if (mine) goBtn(forced ? '휴양' : sel.tr >= 0 ? TRAIN[sel.tr].n + ' 훈련 진행' : '훈련을 고르세요', () => { if (forced) act({ t: 'rest' }); else if (sel.tr >= 0) act({ t: 'tr', k: sel.tr }); }, !forced && sel.tr < 0);
        else goBtn(waitLabel(), null, true);
      } else if (tab === 'race') renderRace(H, mine, forced);
      else if (tab === 'care') {
        panel.append(h('div', { class: 'hc-sec' }, '관리', h('small', { text: '체력 ' + H.hp + ' · 컨디션 ' + MOODN[H.mood + 2] })));
        const list = h('div', { class: 'hc-care' });
        CARE.forEach((c, i) => {
          let d = c.d;
          if (c.k === 'rest') d += ' (체력 약 +' + Math.round(52 * (st.cm ? 1.3 : 1)) + ')';
          if (c.k === 'vet') d = H.ail ? AILN[H.ail] + ' 치료 · ' + AILD[H.ail] + ' 해소' : '상태 이상 없음 · 체력 조금 회복';
          if (c.k === 'ride') d += ' · 지금 호흡 ' + H.jr;
          const dis = forced && c.k !== 'rest';
          list.append(h('button', { class: 'hc-cr' + (sel.care === i ? ' on' : ''), disabled: dis, onclick() { sel.care = i; api.sfx('tick'); render(); } }, h('b', { text: forced && c.k === 'rest' ? '휴양' : c.n }), h('span', { text: d })));
        });
        panel.append(list);
        if (mine) goBtn(sel.care >= 0 ? CARE[sel.care].n + ' 진행' : '관리 방법을 고르세요', () => { if (sel.care >= 0) act({ t: CARE[sel.care].k }); }, sel.care < 0);
        else goBtn(waitLabel(), null, true);
      } else if (tab === 'ab') renderAb(H);
      else renderLog(H);
      panel.scrollTop = keep;
    }

    // 경주를 고르면 작전(위치·스퍼트) 상자가 보이도록 목록을 살짝 내림(작은 화면에서 접힘 아래로 숨지 않게)
    function revealPlan() {
      const box = panel.querySelector('.hc-planbox, .hc-det');
      if (!box) return;
      const pr = panel.getBoundingClientRect(), br = box.getBoundingClientRect();
      if (br.bottom > pr.bottom) panel.scrollTo({ top: panel.scrollTop + Math.min(br.bottom - pr.bottom + 8, br.top - pr.top - 8), behavior: 'smooth' });
    }
    function renderRace(H, mine, forced) {
      const list = racesAt(st, st.t);
      panel.append(h('div', { class: 'hc-sec' }, '이번 턴 경주', h('small', { text: list.length + '개' })));
      if (!list.length) panel.append(h('div', { class: 'hc-empty', text: '이번 턴에 열리는 경주가 없습니다.' }));
      const rl = h('div', { class: 'hc-rl hc-races' });
      const ordered = list.slice().sort((a, b) => (elig(st, P(), a) ? 1 : 0) - (elig(st, P(), b) ? 1 : 0) || b.g - a.g);
      ordered.forEach((r) => {
        const why = elig(st, P(), r), dc = dcat(r.d);
        const dA = aptL(H, dc), sA = aptL(H, 4 + r.sf);
        const rv_ = st.rv.filter((x) => r.g >= 5 && dcat(r.d) === x.dc && r.sf === x.sf).map((x) => x.n);
        rl.append(h('button', { class: 'hc-race' + (sel.race === r.k ? ' on' : '') + (why ? ' no' : ''), onclick() { const was = sel.race; sel.race = r.k; if (!why) api.sfx('tick'); render(); if (was !== r.k) revealPlan(); } },
          h('span', { class: 'hc-gb g' + r.g, text: GBADGE[r.g] }),
          h('span', { class: 'hc-ri' }, h('div', { class: 'n', text: r.n }), h('div', { class: 'm', text: SFN[r.sf] + ' ' + r.d + 'm (' + DN[dc] + ') · 1착 ' + money(prizeOf(r)) + (rv_.length ? ' · 라이벌 출전 가능' : '') }), why ? h('div', { class: 'why', text: why }) : null),
          h('span', { class: 'hc-ra' }, '거리 ', h('b', { text: dA }), h('br'), '주로 ', h('b', { text: sA }))));
      });
      panel.append(rl);
      const r = list.find((x) => x.k === sel.race);
      if (r && !elig(st, P(), r)) {
        const plan = h('div', { class: 'hc-plan hc-planbox' });
        const pw = winProb(H, r, FIELD[r.g]);
        plan.append(h('div', { class: 'hc-pl' }, '예상 ', h('b', { text: popLabel(pw) }), ' · 출전 뒤 체력 약 −' + Math.round(16 + r.d / 130) + (H.str >= 2 ? ' · 연속 출전 ' + (H.str + 1) + '번째(다리 부담)' : '')));
        plan.append(h('div', { class: 'hc-pl', style: { marginTop: '6px' } }, h('b', { text: '위치' }), ' — 어디서 자리를 잡을지'));
        const s1 = h('div', { class: 'hc-seg' });
        [3, 0, 1, 2].forEach((p) => s1.append(h('button', { class: sel.p === p ? 'on' : '', onclick() { sel.p = p; render(); } }, p === 3 ? '기수 판단' : STY_D[p], h('small', { text: p === 3 ? STY[bestStyle(H)] : STY[p] + ' ' + aptL(H, 6 + p) }))));
        plan.append(s1, h('div', { class: 'hc-pl' }, h('b', { text: '스퍼트' }), ' — 언제 승부를 걸지'));
        const s2 = h('div', { class: 'hc-seg' });
        [3, 0, 1, 2].forEach((sp) => s2.append(h('button', { class: sel.s === sp ? 'on' : '', onclick() { sel.s = sp; render(); } }, SPT[sp], h('small', { text: sp === 3 ? '판단 ' + JOCKEYS[H.jk].w : ['남은 1/3', '남은 1/5', '남은 1/8'][sp] }))));
        plan.append(s2, h('div', { class: 'hc-pl', text: '이르게 걸면 길게 달리지만 스태미나가 모자라면 막판에 처집니다. 기수 판단은 남은 체력을 보고 정합니다(판단력이 낮은 기수는 오차가 큼).' }));
        panel.append(plan);
      } else if (r) panel.append(h('div', { class: 'hc-det' }, h('p', { text: '출전할 수 없는 경주입니다 — ' + elig(st, P(), r) + '.' })));
      // 다가오는 큰 경주
      const up = [];
      for (let t = st.t + 1; t < Math.min(st.T, st.t + (st.cm ? 4 : 8)); t++) for (const x of racesAt(st, t)) if (x.g >= 4) up.push([t, x]);
      if (up.length) {
        panel.append(h('div', { class: 'hc-sec', style: { marginTop: '10px' } }, '다가오는 중상 경주'));
        const rows = h('div', { class: 'hc-rows' });
        up.slice(0, 8).forEach(([t, x]) => rows.append(h('div', { class: 'hc-row' }, h('span', { class: 'a', text: turnName(st, t).replace(/^\d세 · /, '') }), h('span', { class: 'b', text: x.n + ' · ' + SFN[x.sf] + ' ' + x.d + 'm' }), h('span', { class: 'c' + (x.g === 6 ? ' w' : ''), text: GBADGE[x.g] }))));
        panel.append(rows);
      }
      if (mine) {
        const ok = r && !elig(st, P(), r) && !forced;
        goBtn(forced ? '이번 턴은 출전할 수 없음' : ok ? '출전 확정' : '경주를 고르세요', () => { if (ok) act({ t: 'race', r: r.k, p: sel.p, s: sel.s }); }, !ok);
      } else goBtn(waitLabel(), null, true);
    }

    function renderAb(H) {
      panel.append(h('div', { class: 'hc-sec' }, '조교 노트', h('small', { text: '노트 점수 ' + H.sp })));
      for (let b = 0; b < 4; b++) {
        panel.append(h('div', { class: 'hc-pl', style: { margin: '6px 0 3px', fontWeight: 700, color: 'var(--ink)' }, text: ABR[b] }));
        const grid = h('div', { class: 'hc-abs' });
        ABIL.filter((A) => A.b === b).forEach((A) => {
          const have = hasAb(H, A.id), lock = A.r && !hasAb(H, A.r);
          grid.append(h('button', { class: 'hc-ab' + (have ? ' have' : lock ? ' lock' : '') + (sel.ab === A.id ? ' on' : ''), onclick() { sel.ab = A.id; api.sfx('tick'); render(); } },
            h('b', { text: A.n }), h('span', { text: A.d }), h('em', { text: have ? '익힘' : lock ? ABIL[ABI[A.r]].n + ' 먼저' : '노트 ' + A.c })));
        });
        panel.append(grid);
      }
      const J = JOCKEYS[H.jk], pk = jockeyPerks(H.jk), tier = jTier(H);
      panel.append(h('div', { class: 'hc-sec', style: { marginTop: '10px' } }, '기수 · ' + J.n, h('small', { text: '호흡 ' + H.jr + (H.jx > 0 ? ' · 대체 기수 탑승 중' : '') })));
      panel.append(h('div', { class: 'hc-meter' }, h('i', { style: { width: H.jr + '%' } })));
      const rows = h('div', { class: 'hc-rows' });
      pk.forEach((t, i) => rows.append(h('div', { class: 'hc-row' }, h('span', { class: 'a', text: '호흡 ' + JTIER[i] }), h('span', { class: 'b', text: t, style: { color: i < tier ? 'var(--ink)' : 'var(--ink2)' } }), h('span', { class: 'c', text: i < tier ? '열림' : '' }))));
      panel.append(rows);
      panel.append(h('div', { class: 'hc-sec', style: { marginTop: '10px' } }, '스태프', h('small', { text: '호흡 80부터 담당 훈련 효과 크게' })));
      const sr = h('div', { class: 'hc-rows' });
      STAFF.forEach((S, i) => sr.append(h('div', { class: 'hc-row' }, h('span', { class: 'a', text: S.n }), h('span', { class: 'b' }, h('div', { class: 'hc-meter' }, h('i', { style: { width: H.sf[i] + '%' } }))), h('span', { class: 'c', text: String(H.sf[i]) }))));
      panel.append(sr);
      const A = ABIL[ABI[sel.ab]];
      const can = A && !hasAb(H, A.id) && (!A.r || hasAb(H, A.r)) && H.sp >= A.c && api.canAct(focus) && (actor(st) || []).includes(focus) && !P().ev && !P().act;
      goBtn(!A ? '능력을 고르세요' : hasAb(H, A.id) ? '이미 익힌 능력' : A.r && !hasAb(H, A.r) ? jo(ABIL[ABI[A.r]].n, '이', '가') + ' 먼저 필요' : H.sp < A.c ? '노트 점수 부족 (' + H.sp + ' / ' + A.c + ')' : A.n + ' 익히기 (노트 ' + A.c + ')', () => { if (can) { api.sfx('chip'); api.actAs(focus, { t: 'ab', id: A.id }); } }, !can);
    }

    function renderLog(H) {
      panel.append(h('div', { class: 'hc-sec' }, '전적', h('small', { text: H.rec.n + '전 ' + H.rec.w + '승 · 3착 안 ' + H.rec.t3 })));
      if (!H.hist.length) panel.append(h('div', { class: 'hc-empty', text: '아직 출전 기록이 없습니다. 2세 6월부터 신마전에 나갈 수 있습니다.' }));
      const rows = h('div', { class: 'hc-rows' });
      H.hist.slice().reverse().forEach((x) => rows.append(h('div', { class: 'hc-row' }, h('span', { class: 'a', text: turnName(st, x[0]).replace(/세 · /, '세 ') }), h('span', { class: 'b', text: x[1] + ' (' + GBADGE[x[2]] + ') · ' + SFN[x[4]] + ' ' + x[3] + 'm' }), h('span', { class: 'c' + (x[5] === 1 ? ' w' : ''), text: x[5] + '착/' + x[6] }))));
      panel.append(rows);
      if (H.tk.length) panel.append(h('div', { class: 'hc-pl', style: { marginTop: '6px' }, text: '우선 출주권: ' + H.tk.map((k) => GRK[k] ? GRK[k].n : k).join(', ') }));
      panel.append(h('div', { class: 'hc-sec', style: { marginTop: '10px' } }, '라이벌'));
      const rr = h('div', { class: 'hc-rows' });
      st.rv.forEach((x) => rr.append(h('div', { class: 'hc-row' }, h('span', { class: 'a', text: DN[x.dc] + (x.sf ? '·더트' : '') }), h('span', { class: 'b', text: x.n }), h('span', { class: 'c', text: x.w + '승 (G1 ' + x.g1 + ')' }))));
      panel.append(rr);
      panel.append(h('div', { class: 'hc-sec', style: { marginTop: '10px' } }, '소식'));
      if (!st.news.length) panel.append(h('div', { class: 'hc-empty', text: '아직 소식이 없습니다.' }));
      st.news.forEach((n) => panel.append(h('div', { class: 'hc-row' }, h('span', { class: 'a', text: turnName(st, Math.min(n[0], st.T - 1)).replace(/세 · /, '세 ') }), h('span', { class: 'b', text: n[1] }))));
      goBtn(canAct() ? '훈련 탭으로' : waitLabel(), () => { tab = 'tr'; render(); }, !canAct());
    }

    /* ---------- 고르기 화면 ---------- */
    const pickSel = { f: -1, j: -1 };
    function renderPick() {
      body.style.display = 'none';
      if (!pickEl) { pickEl = h('div', { class: 'hc-pick' }); wrap.insertBefore(pickEl, go.parentNode === wrap ? go : null); }
      pickEl.style.display = '';
      if (go.parentNode !== wrap) wrap.append(go);
      pickEl.textContent = '';
      const p = P();
      if (p.pk != null || !p.c) {
        pickEl.append(h('h2', { text: '고르기 완료' }), h('p', { class: 'lead', text: '다른 마주가 고르는 중입니다.' }));
        goBtn(waitLabel(), null, true);
        return;
      }
      pickEl.append(h('p', { class: 'lead', text: '2세부터 4세 말까지 함께할 한 마리와 기수를 고릅니다. 적성 A가 가장 잘 맞는 조건이고, 조교사 소견은 추정입니다.' }));
      const fl = h('div', { class: 'hc-foals hc-pickfoals' });
      p.c.forEach((f, i) => {
        const cv = h('canvas', { width: 152, height: 108 });
        drawCardHorse(cv, f);
        const ap = (k) => f.apt[k];
        const row1 = h('div', { class: 'hc-apt' }, h('span', { class: 'k', text: '거리' }), ...aptRow(f, 0, 4, ['단', '마', '중', '장'], ap), h('span', { class: 'k', text: '주로' }), ...aptRow(f, 4, 2, ['잔', '더'], ap));
        const row2 = h('div', { class: 'hc-apt' }, h('span', { class: 'k', text: '각질' }), ...aptRow(f, 6, 3, ['선행', '선입', '추입'], ap));
        fl.append(h('button', { class: 'hc-foal' + (pickSel.f === i ? ' on' : ''), onclick() { pickSel.f = i; api.sfx('tick'); render(); } }, cv,
          h('div', { class: 't' }, h('div', { class: 'fn', text: f.n }), h('span', { text: CO[f.co].n + ' · 기질 ' + TEMPER[f.tm].n }),
            h('span', { text: '부 ' + f.sn + ' — ' + SIRES[f.si].n + ' 계열(' + SIRES[f.si].d + ')' }),
            h('span', { text: '모 ' + f.dn + ' — ' + DAMS[f.di].n + '(' + DAMS[f.di].d + ')' }),
            h('span', { class: 'op', text: '조교사 소견: 잠재력 「' + POT[f.ap] + '」 · ' + TYN[f.tg + 1] + '으로 보임' }),
            row1, row2,
            h('span', { class: 'mono', text: SN.map((n, k) => n + ' ' + f.st[k]).join(' · ') }))));
      });
      pickEl.append(fl, h('div', { class: 'hc-sec', style: { marginTop: '10px' } }, '기수'));
      const jk = h('div', { class: 'hc-jks hc-pickjk' });
      p.jc.forEach((j, i) => jk.append(h('button', { class: 'hc-jk' + (pickSel.j === i ? ' on' : ''), onclick() { pickSel.j = i; api.sfx('tick'); render(); } }, h('b', { text: JOCKEYS[j].n }), h('span', { text: '판단 ' + JOCKEYS[j].w }), h('span', { text: JOCKEYS[j].d }))));
      pickEl.append(jk);
      if (canAct()) goBtn(pickSel.f < 0 ? '망아지를 고르세요' : pickSel.j < 0 ? '기수를 고르세요' : '이 말과 기수로 시작', () => { if (pickSel.f >= 0 && pickSel.j >= 0) act({ t: 'pick', f: pickSel.f, j: pickSel.j }); }, pickSel.f < 0 || pickSel.j < 0);
      else goBtn(waitLabel(), null, true);
    }

    /* ---------- 사건 창 ---------- */
    let evEl = null;
    function renderEvent() {
      const p = P();
      const need = p && p.ev && canAct() && !rv;
      const key = need ? st.lid + ':' + focus + ':' + p.ev.id : '';
      if (!need) { if (evEl) { evEl.remove(); evEl = null; } return; }
      if (evEl && evEl.dataset.k === key) return;
      if (evEl) evEl.remove();
      const E_ = EVI[p.ev.id], ch = evChoices(E_, p.ev);
      const box = h('div', { class: 'hc-ev', role: 'dialog' }, h('div', { class: 'k', text: '연락 · ' + turnName(st, st.t) }), h('h3', { text: E_.ti }), h('p', { text: E_.tx(p.ev, st, p) }));
      const cb = h('div', { class: 'ch' });
      ch.forEach((c, i) => cb.append(h('button', { onclick() { act({ t: 'ev', c: i }); } }, h('b', { text: c.l }), h('span', { text: c.d }))));
      box.append(cb);
      evEl = h('div', { class: 'hc-ov hc-evov' }, box);
      evEl.dataset.k = key;
      wrap.append(evEl);
      api.sfx('pop');
    }

    function slip(text) {
      const el = h('div', { class: 'hc-slip', text });
      el.style.animationDuration = Math.max(0.6, 1.6 / Math.min(2, SPD())) + 's';
      panel.parentNode.append(el);
      const t = setTimeout(() => el.remove(), 1700);
      el.addEventListener('animationend', () => { clearTimeout(t); el.remove(); });
    }

    function render(fx) {
      if (!st || dead) return;
      focus = pickFocus(st);
      renderHead(); renderOthers();
      if (st.ph === 'pick') { renderPick(); renderEvent(); return; }
      if (pickEl) { pickEl.remove(); pickEl = null; }
      body.style.display = '';
      if (go.parentNode !== right) right.append(go);
      if (!P().h) return;
      renderCard(); renderStats(fx); renderStatus(); renderNews(); renderTabs(); renderPanel(); renderEvent();
    }

    /* ======================= 경주 재생 ======================= */
    function RacePlayer(rec, done) {
      const box = h('div', { class: 'hc-rv hc-racev' });
      const cv = h('canvas');
      const top = h('div', { class: 'top' }, h('b', { text: rec.n + (rec.g >= 3 ? ' (' + GBADGE[rec.g] + ')' : '') }), h('span', { text: SFN[rec.sf] + ' ' + rec.d + 'm · ' + GON[rec.go] + ' · ' + rec.R.length + '두' }));
      const cm = h('div', { class: 'cm', text: '출발 대기' });
      const skip = h('button', { class: 'skip', 'data-action': 'go', text: '건너뛰기', onclick() { tp = 1e9; api.sfx('tick'); } });
      box.append(cv, top, cm, skip);
      wrap.append(box);
      const g = cv.getContext('2d');
      const sim = simRace(rec, true), T = track(rec.sf, rec.d), N = rec.R.length, fr = sim.fr;
      const startP = ((T.P - (rec.d % T.P)) % T.P);
      const mineIdx = rec.R.map((q, i) => (q.s >= 0 ? i : -1)).filter((i) => i >= 0);
      const focusIdx = rec.R.findIndex((q) => q.s === focus);
      const camI = focusIdx >= 0 ? focusIdx : mineIdx.length ? mineIdx[0] : 0;
      let W = 0, Hh = 0, dpr = 1;
      function resize() { const r = box.getBoundingClientRect(); W = r.width || 360; Hh = r.height || 640; dpr = Math.min(2.5, window.devicePixelRatio || 1); cv.width = Math.round(W * dpr); cv.height = Math.round(Hh * dpr); }
      resize();
      const totT = sim.T;
      const rate = totT / (11 + rec.d / 260);
      let tp = 0, last = performance.now(), raf = 0, fin = false, cx = null, cy = null, lastCm = -1, cmTxt = '';
      const silk = (q) => (q.s >= 0 ? COL(q.s) : q.s <= -2 ? '#c8c2b0' : SILK[(q.sl || 0) % SILK.length]);
      const nameOf = (i) => rec.R[i].n;
      function stateAt(t) {
        const f = Math.max(0, t) / 0.5, i0 = Math.max(0, Math.min(fr.length - 1, Math.floor(f))), i1 = Math.min(fr.length - 1, i0 + 1), a = Math.min(1, Math.max(0, f - i0));
        const A = fr[i0], B = fr[i1], out = [];
        for (let k = 0; k < N; k++) out.push([A[k * 3] + (B[k * 3] - A[k * 3]) * a, A[k * 3 + 1] + (B[k * 3 + 1] - A[k * 3 + 1]) * a, A[k * 3 + 2]]);
        return out;
      }
      function comment(S, t) {
        const ord = S.map((x, i) => i).sort((a, b) => S[b][0] - S[a][0]);
        const lead = ord[0], x0 = S[lead][0], rem = rec.d - x0;
        const myRank = focusIdx >= 0 ? ord.indexOf(focusIdx) + 1 : 0;
        const me = focusIdx >= 0 ? nameOf(focusIdx) : '';
        const stage = t < 3 ? 0 : x0 < rec.d / 3 ? 1 : x0 < rec.d * 2 / 3 ? 2 : rem > T.S ? 3 : rem > 200 ? 4 : 5;
        const key = stage * 100 + (stage === 1 || stage === 2 ? Math.floor(t / 4) : 0);
        if (key === lastCm) return;
        lastCm = key;
        const L2 = nameOf(ord[1]);
        cmTxt = [
          '게이트가 열렸습니다. ' + N + '두 출발.',
          '선두는 ' + nameOf(lead) + ', 2번째 ' + L2 + '.' + (me ? ' ' + jo(me, '은', '는') + ' ' + myRank + '번째.' : ''),
          '중반. ' + jo(nameOf(lead), '이', '가') + ' 흐름을 만듭니다.' + (me ? ' ' + me + ' ' + myRank + '번째.' : ''),
          '마지막 코너. 선두 ' + nameOf(lead) + ', 뒤에서 ' + L2 + '.',
          '직선. ' + nameOf(lead) + ' 선두' + (me && myRank > 1 ? ', ' + me + ' ' + myRank + '번째에서 추격.' : me ? ', ' + jo(me, '이', '가') + ' 앞.' : '.'),
          '남은 200m. ' + nameOf(lead) + (L2 ? ', ' + L2 : '') + '.',
        ][stage];
        cm.textContent = cmTxt;
      }
      function draw(t) {
        const S = stateAt(Math.min(t, totT));
        const sc = Math.max(8, Math.min(16, W / 30));
        const camP = S[camI][0];
        const [tx, ty] = posAt(T, startP + camP, S[camI][1] + 2);
        cx = tx; cy = ty;
        g.setTransform(dpr, 0, 0, dpr, 0, 0);
        g.fillStyle = rec.sf ? '#2b2a1f' : '#26301f'; g.fillRect(0, 0, W, Hh);
        g.save(); g.translate(W / 2, Hh * 0.52); g.scale(sc, sc); g.translate(-cx, -cy);
        // 안쪽 잔디밭
        g.fillStyle = rec.sf ? '#3a4a30' : '#304a2c'; ovalPath(g, T, -1.2); g.fill();
        // 주로
        g.lineJoin = 'round';
        const band = 19;
        if (rec.sf === 0) { for (let k = 0; k < 6; k++) { g.strokeStyle = k % 2 ? '#4f6d42' : '#56754a'; g.lineWidth = band / 6 + 0.05; ovalPath(g, T, -0.6 + band / 12 + k * band / 6); g.stroke(); } }
        else { g.strokeStyle = '#7d6247'; g.lineWidth = band; ovalPath(g, T, band / 2 - 0.6); g.stroke(); g.strokeStyle = 'rgba(60,40,25,.25)'; g.lineWidth = 0.15; for (let k = 1; k < 9; k++) { ovalPath(g, T, k * 2); g.stroke(); } }
        // 울타리
        g.strokeStyle = '#e9e2d2'; g.lineWidth = 0.22; ovalPath(g, T, -0.6); g.stroke(); ovalPath(g, T, band - 0.6); g.stroke();
        // 거리 표지(결승선까지 200m 단위)
        g.fillStyle = '#e9e2d2'; g.font = '700 1.6px ' + MONO; g.textAlign = 'center'; g.textBaseline = 'middle';
        for (let d = 200; d <= rec.d; d += 200) { const [x, y] = posAt(T, -d, -2.4); g.fillRect(x - 0.15, y - 0.15, 0.3, 0.3); const [lx, ly] = posAt(T, -d, -4.2); g.fillText(String(d), lx, ly); }
        // 결승선
        const f0 = posAt(T, 0, -0.6), f1 = posAt(T, 0, band - 0.6);
        g.strokeStyle = '#efe6d2'; g.lineWidth = 0.35; g.beginPath(); g.moveTo(f0[0], f0[1]); g.lineTo(f1[0], f1[1]); g.stroke();
        g.fillStyle = '#9b2b22'; g.beginPath(); g.arc(f0[0], f0[1] - 1.2, 0.9, 0, 7); g.fill();
        g.fillStyle = '#efe6d2'; g.font = '700 1.8px ' + FONT; g.fillText('결승', f0[0], f0[1] - 3.2);
        // 출발 게이트(처음 몇 초)
        if (t < 4) { const [gx, gy, gh] = posAt(T, startP, N * 0.45); g.save(); g.translate(gx, gy); g.rotate(gh); g.fillStyle = 'rgba(220,214,200,' + (1 - t / 4) * 0.8 + ')'; g.fillRect(-1.6, -N * 0.5 - 0.6, 1.2, N * 0.95 + 1.2); g.restore(); }
        // 말
        const order = S.map((x, i) => i).sort((a, b) => S[a][1] - S[b][1]);
        for (const i of order) {
          const [x, y, hd] = posAt(T, startP + S[i][0], S[i][1]);
          const q = rec.R[i];
          drawHorseTop(g, x, y, hd, coatOf(q), silk(q), t * 9 + i * 1.3);
        }
        // 이름표(사람 자리·라이벌)
        g.font = '600 1.35px ' + FONT;
        for (let i = 0; i < N; i++) {
          const q = rec.R[i];
          if (q.s < 0 && q.s > -2) continue;
          const [x, y] = posAt(T, startP + S[i][0], S[i][1]);
          const label = q.s >= 0 ? q.n : '라이벌 ' + q.n;
          const w = g.measureText(label).width + 1.2;
          g.fillStyle = q.s >= 0 ? 'rgba(20,19,15,.82)' : 'rgba(20,19,15,.6)';
          g.fillRect(x - w / 2, y - 3.6, w, 1.9);
          g.fillStyle = q.s >= 0 ? COL(q.s) : '#d8d0bc';
          g.fillText(label, x, y - 2.6);
        }
        g.restore();
        // 미니맵
        const mw = Math.min(124, W * 0.32), mh = mw * 0.5, mx = W - mw - 8, my = 52;
        g.fillStyle = 'rgba(15,14,11,.6)'; g.fillRect(mx - 4, my - 4, mw + 8, mh + 8);
        const ms = mw / (T.S + 2 * (T.R + 20));
        g.save(); g.translate(mx + mw / 2, my + mh / 2); g.scale(ms, ms);
        g.strokeStyle = '#8f8a78'; g.lineWidth = 1.5 / ms; ovalPath(g, T, 8); g.stroke();
        for (let i = 0; i < N; i++) { const q = rec.R[i]; const [x, y] = posAt(T, startP + S[i][0], 8); g.fillStyle = q.s >= 0 ? COL(q.s) : q.s <= -2 ? '#e8e0cc' : '#77725f'; g.beginPath(); g.arc(x, y, (q.s >= 0 ? 3.2 : 2.2) / ms, 0, 7); g.fill(); }
        g.restore();
        // 순위
        const ord = S.map((x, i) => i).sort((a, b) => S[b][0] - S[a][0]);
        const show = ord.slice(0, 5);
        if (focusIdx >= 0 && !show.includes(focusIdx)) show.push(focusIdx);
        let yy = 52;
        g.font = '600 13px ' + FONT; g.textAlign = 'left'; g.textBaseline = 'middle';
        const lw = Math.min(170, W * 0.44);
        g.fillStyle = 'rgba(15,14,11,.74)'; g.fillRect(6, yy - 4, lw, show.length * 20 + 8);
        show.forEach((i) => {
          const r = ord.indexOf(i) + 1, q = rec.R[i];
          if (q.s >= 0) { g.fillStyle = 'rgba(201,178,122,.28)'; g.fillRect(6, yy, lw, 19); }
          g.fillStyle = '#c9c0a8'; g.font = '700 13px ' + MONO; g.fillText(String(r), 11, yy + 10);
          g.fillStyle = silk(q); g.fillRect(30, yy + 4, 9, 12); g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 1; g.strokeRect(30.5, yy + 4.5, 8, 11);
          g.fillStyle = q.s >= 0 ? '#fff6e0' : '#ddd5c2'; g.font = (q.s >= 0 ? '700 ' : '500 ') + '13px ' + FONT;
          let nm = q.n; while (g.measureText(nm).width > lw - 50 && nm.length > 2) nm = nm.slice(0, -1);
          g.fillText(nm, 45, yy + 10);
          yy += 20;
        });
        const remN = Math.max(0, Math.round((rec.d - S[ord[0]][0]) / 10) * 10);
        g.textAlign = 'right'; g.font = '700 15px ' + MONO;
        const remT = remN > 0 ? '남은 ' + remN + 'm' : '결승', remW = g.measureText(remT).width;
        g.fillStyle = 'rgba(15,14,11,.74)'; g.fillRect(W - 16 - remW, my + mh + 6, remW + 12, 22);
        g.fillStyle = '#f3ead6'; g.fillText(remT, W - 10, my + mh + 17);
        comment(S, t);
      }
      function frame(now) {
        if (dead) return;
        const dt = Math.max(0, Math.min(0.1, (now - last) / 1000)); last = now;
        if (!(api.paused && api.paused())) tp += dt * rate * SPD();
        if (tp >= totT + 1.2) { if (!fin) { fin = true; draw(totT); finish(); } return; }
        draw(tp);
        raf = requestAnimationFrame(frame);
      }
      raf = requestAnimationFrame(frame);
      api.sfx('whoosh');
      function finish() {
        skip.remove(); cm.remove();
        const res = h('div', { class: 'hc-res hc-result' });
        res.append(h('div', { class: 'k', text: '경주 성적 · ' + turnName(st, rec.t) }), h('h3', { text: rec.n + (rec.g >= 3 ? ' (' + GBADGE[rec.g] + ')' : '') }), h('div', { class: 'sub', text: SFN[rec.sf] + ' ' + rec.d + 'm · ' + GON[rec.go] + ' · ' + N + '두 · 1착 상금 ' + money(rec.pz) }));
        const tb = h('table');
        const t0 = rec.tm[0];
        rec.o.forEach((i, pos) => {
          const q = rec.R[i];
          if (pos >= 8 && q.s < 0) return;
          const mt = pos === 0 ? fmtTime(t0) : marginTxt(rec.tm[pos] - rec.tm[pos - 1]);
          tb.append(h('tr', { class: q.s >= 0 ? 'me' : '' }, h('td', { class: 'r', text: String(pos + 1) }), h('td', { class: 'n' }, h('span', { class: 'sq', style: { background: silk(q) } }), q.n + (q.s <= -2 ? ' (라이벌)' : '')), h('td', { class: 't', text: mt })));
        });
        res.append(tb);
        const lines = [];
        rec.R.forEach((q, i) => {
          if (q.s < 0) return;
          const fx = st.last && st.last.fx && st.last.fx[q.s];
          const pos = rec.o.indexOf(i) + 1;
          if (fx && fx.race === rec.id) lines.push(h('div', {}, h('b', { text: q.n }), ' ' + pos + '착 · 상금 ' + (fx.pz ? money(fx.pz) : '없음') + ' · 명성 +' + fx.fm + ' · 노트 +' + fx.sp + (fx.tk ? ' · ' + (GRK[fx.tk] ? GRK[fx.tk].n : '') + ' 우선 출주권' : '') + (fx.goal ? ' · 마주 신뢰 상승' : '')));
        });
        if (lines.length) res.append(h('div', { class: 'gain' }, ...lines));
        const local = rec.R.some((q) => q.s >= 0 && api.canAct(q.s));
        const ok = h('button', { class: 'hc-btn pri hc-resok', 'data-action': 'go', text: '확인', style: { flex: 'none', minWidth: '120px' }, onclick() { close(); } });
        res.append(h('div', { class: 'act' }, ok));
        box.append(res);
        const win = rec.R[rec.o[0]];
        if (win.s >= 0 && api.canAct(win.s)) { api.sfx('win'); api.buzz(30, 'win'); } else if (local) api.sfx('result');
        if (!local) setTimeout(close, 1400 / SPD());
        else if (L.debug.noTut) setTimeout(close, 2600 / SPD());   // 시험 도구에서는 사람 자리도 저절로 닫음
      }
      let closed = false;
      function close() { if (closed) return; closed = true; cancelAnimationFrame(raf); box.remove(); done(); }
      return { resize, destroy() { closed = true; cancelAnimationFrame(raf); box.remove(); } };
    }
    function nextRace() {
      if (dead || rv) return;
      const rec = raceQ.shift();
      if (!rec) { setBusy(false); render(); return; }
      setBusy(true);
      if (evEl) { evEl.remove(); evEl = null; }
      rv = RacePlayer(rec, () => { rv = null; nextRace(); });
    }

    /* ---------- 갱신 ---------- */
    function update(s, prev) {
      st = s;
      if (s.ph !== 'over') { const f0 = focus; focus = pickFocus(s, true); if (f0 >= 0 && f0 !== focus && !dead) setTimeout(() => { if (!dead && st && st.ph !== 'over') slip(NM(focus) + '의 차례'); }, 50); }
      if (s.last && s.last.id !== shownLast) {
        const fresh = prev != null && prev !== s;
        shownLast = s.last.id;
        if (fresh) {
          focus = pickFocus(s);
          const mine = api.mySeats();
          const races = s.last.races.filter((r) => r.R.some((q) => q.s >= 0 && (mine.length ? mine.includes(q.s) : q.s === focus)));
          raceQ.push(...races);
          const fx = s.last.fx && s.last.fx[focus];
          render(fx && !fx.race ? fx : null);
          if (fx && !fx.race) {
            if (fx.a === 'tr') slip(fx.fail ? TRAIN[fx.k].n + ' 훈련 실패' + (fx.inj ? ' · 부상' : '') : TRAIN[fx.k].n + ' 훈련 · ' + fx.d.map((v, i) => (v ? SN[i] + ' +' + v : '')).filter(Boolean).join(' · '));
            else if (fx.inj) slip('부상 휴양');
            else slip({ rest: '휴식', graze: '방목', vet: '진료', ride: '기승 연습' }[fx.a] + ' · 체력 ' + fx.hp + ' → ' + fx.hp2);
          }
          if (raceQ.length) nextRace();
          return;
        }
      }
      render();
      if (!tutDone && s.ph === 'turn' && api.mySeats().length && !L.debug.noTut) {
        tutDone = true;
        let seen = false; try { seen = localStorage.getItem('lounge.horsecareer.tut2') === '1'; } catch (e) { seen = false; }
        if (!seen) { try { localStorage.setItem('lounge.horsecareer.tut2', '1'); } catch (e) { /* 무시 */ } setTimeout(() => { if (!dead) api.tutorial(TUT2); }, 400); }
      }
      if (s.ph === 'over') saveHof(s);
    }
    function saveHof(s) {
      s.P.forEach((p, i) => {
        if (!p.h || !api.canAct(i)) return;
        const H = p.h, rt = ratingOf(H), en = endingOf(H);
        hofAdd({ id: s.seed + ':' + i, n: H.n, rt, rk: rankOf(rt), tt: titlesOf(H)[0], en: en.n, w: H.rec.w, r: H.rec.n, g1: H.rec.g[2], e: H.rec.e, d: Date.now() });
      });
    }
    return {
      update(s, prev) { try { update(s, prev); } catch (e) { console.error(e); } },
      destroy() { dead = true; window.removeEventListener('resize', onRs); if (offIn) offIn(); if (rv) rv.destroy(); rv = null; if (busy) api.setBusy(false); wrap.remove(); },
    };
  }
  const TUT2 = [
    { text: '맨 위는 시기와 남은 턴, 통산 상금입니다. 한 턴은 반달입니다(압축 모드는 한 달).', sel: '.hc-head' },
    { text: '능력치 다섯 가지와 등급입니다. 스피드는 막판 속도, 스태미나는 버티는 힘, 파워는 가속, 근성은 경합과 바닥난 뒤의 버팀, 판단력은 자리 잡기와 안정감입니다.', sel: '.hc-stats' },
    { text: '체력이 55 아래면 훈련 실패율이 오릅니다. 컨디션은 훈련 효과와 경주에 영향을 줍니다.', sel: '.hc-status' },
    { text: '훈련 · 출전 · 관리 중 하나를 골라 아래 단추로 턴을 넘깁니다. 능력 탭에서 노트 점수로 경주 능력을 익힙니다(턴을 쓰지 않음).', sel: '.hc-tabs' },
  ];

  /* ======================= 규칙 · 도감 · 표지 ======================= */
  const FIG_FLOW = '<svg viewBox="0 0 340 92" xmlns="http://www.w3.org/2000/svg" font-family="IBM Plex Sans KR,sans-serif" font-size="11"><g fill="none" stroke="#8a826e"><rect x="4" y="30" width="54" height="30" rx="4"/><rect x="72" y="30" width="54" height="30" rx="4"/><rect x="140" y="30" width="60" height="30" rx="4"/><rect x="214" y="30" width="52" height="30" rx="4"/><rect x="280" y="30" width="56" height="30" rx="4" stroke="#9b2b22"/></g><g fill="#8a826e"><path d="M60 45l8-4v8zM128 45l8-4v8zM202 45l8-4v8zM268 45l8-4v8z"/></g><g fill="currentColor" text-anchor="middle"><text x="31" y="49">신마전</text><text x="99" y="49">미승리전</text><text x="170" y="49">1승 클래스</text><text x="240" y="49">L · G3</text><text x="308" y="49" fill="#b8473c">G2 · G1</text></g><g fill="#8a826e" font-size="9.5" text-anchor="middle"><text x="31" y="22">데뷔 전</text><text x="99" y="22">0승</text><text x="170" y="22">1승</text><text x="240" y="22">1승 이상</text><text x="308" y="22">상금 · 출주권</text></g><text x="170" y="84" fill="#8a826e" font-size="10" text-anchor="middle">이기면 한 단계씩 위 경주에 나갈 수 있습니다</text></svg>';
  const RULES = [
    { h: '목표', p: [
      '경주마 한 마리를 2세 1월부터 4세 12월까지 키웁니다. 한 턴은 반달(압축 모드는 한 달)이고, 모두 72턴(압축 36턴)입니다.',
      '훈련으로 능력을 올리고, 알맞은 경주를 골라 이겨 상금과 명성을 쌓습니다. 은퇴할 때 전적·능력·수상 기록으로 평가 등급과 칭호, 은퇴 후의 길(결말)이 정해집니다.'] },
    { h: '시작: 망아지와 기수', p: [
      '망아지 세 마리 중 한 마리를 고릅니다. 혈통(부계·모계)에 따라 적성과 성장 방향이 다릅니다.',
      '적성은 A(가장 잘 맞음)부터 G까지 — 거리(단거리 1400m 이하 · 마일 1800m 이하 · 중거리 2400m 이하 · 장거리), 주로(잔디 · 더트), 각질(선행 · 선입 · 추입).',
      '조교사 소견(잠재력 · 성장형)은 추정이라 틀릴 수 있습니다. 빨리 피는 형은 2세에, 늦게 피는 형은 4세에 훈련 효과가 큽니다.',
      '기질: 차분함(컨디션이 안정적 · 출발이 고름) · 예민함(기복이 크고 가끔 출발이 늦지만 훈련 효과가 조금 큼) · 승부욕(막판 경합에 강하지만 훈련 피로가 조금 큼).',
      '기수도 세 명 중 한 명을 고릅니다. 기수마다 특기와 판단력이 다릅니다.'] },
    { h: '한 턴에 할 일', p: [
      '훈련 · 출전 · 관리 가운데 하나를 고르면 턴이 넘어갑니다.',
      '능력 탭에서 노트 점수로 경주 능력을 익히는 일은 턴을 쓰지 않습니다.',
      '가끔 「연락」이 옵니다(마주의 요청, 병주 제안, 질병 기운 등). 먼저 답한 뒤 할 일을 고릅니다.'] },
    { h: '훈련', p: [
      '스피드 · 스태미나 · 파워 · 근성 · 판단력 다섯 가지. 각 훈련은 주 능력치와 보조 능력치를 올리고 체력을 씁니다(판단력 훈련은 체력이 조금 회복).',
      '체력이 55 아래로 내려가면 실패율이 오릅니다. 실패하면 그 능력치와 컨디션이 떨어지고, 체력이 아주 낮으면 부상으로 몇 턴 쉬어야 합니다.',
      '같은 훈련을 4번 할 때마다 그 훈련의 Lv이 오릅니다(최대 5).',
      '훈련 칸의 점은 그 턴에 함께하는 스태프입니다. 스태프가 있으면 효과가 오르고 호흡이 쌓입니다. 호흡 80이 넘은 스태프가 담당 훈련에 오면(붉은 점) 효과가 크게 오릅니다.',
      '능력치는 혈통이 정한 한계 근처에서 잘 오르지 않습니다.'] },
    { h: '관리', p: [
      '휴식: 체력을 크게 회복합니다. 방목: 컨디션이 한 단계 오릅니다. 진료: 상태 이상을 치료합니다. 기승 연습: 기수와 호흡을 쌓습니다.',
      '컨디션(최악 · 나쁨 · 보통 · 좋음 · 최상)은 훈련 효과와 경주 능력에 함께 영향을 줍니다.',
      '상태 이상: 기침 감기 · 식욕 부진 · 발굽 열감 · 밤잠 설침 · 다리 붓기. 진료로 바로 낫고, 쉬면 가끔 저절로 낫습니다.'] },
    { h: '경주와 출전 조건', fig: { svg: FIG_FLOW, cap: '경주 등급' }, p: [
      '2세 6월부터 신마전(데뷔전)이 열립니다. 이기지 못한 말은 미승리전, 1승을 한 말은 1승 클래스에 나갑니다.',
      '1승 이상이면 리스티드(L)·G3에 나갈 수 있습니다. G2는 통산 상금 1,500만 원, G1은 3,000만 원(2세 G1은 1,000만 원)이 필요합니다.',
      '지정된 전초전에서 정해진 착순 안에 들면, 상금이 모자라도 그 G1의 「우선 출주권」을 받습니다.',
      '2세 · 3세 한정 경주가 있고, 3세 이상 경주에는 3세가 6월부터 나갑니다. 3세의 청춘 클래식 · 왕관 더비 · 단풍 스테이어 클래식을 모두 이기면 「삼관」입니다.',
      '경주를 하면 체력을 많이 씁니다. 연달아 나가면 다리에 부담이 쌓입니다.',
      '상금은 5착까지(1착 100% · 2착 40% · 3착 25% · 4착 15% · 5착 10%). 착순에 따라 명성과 노트 점수, 능력치가 조금 오릅니다.'] },
    { h: '기수 작전', p: [
      '출전할 때 위치와 스퍼트 시점을 정합니다. 「기수 판단」에 맡길 수도 있습니다.',
      '위치: 앞에서(선행) · 중단(선입) · 뒤에서(추입). 그 각질 적성이 낮으면 판단력과 속도가 깎입니다.',
      '스퍼트: 이르게 걸면 길게 전력으로 달리지만, 스태미나가 모자라면 결승 전에 힘이 바닥나 처집니다. 늦게 걸면 안전하지만 힘을 다 못 쓸 수 있습니다.',
      '기수 판단은 남은 체력을 계산해 시점을 정합니다. 판단력이 낮은 기수일수록 오차가 큽니다.',
      '경주 장면에서 「건너뛰기」로 결과로 바로 갈 수 있습니다.'] },
    { h: '능력과 호흡', p: [
      '훈련과 경주로 노트 점수가 쌓입니다. 능력 탭에서 속도 · 운영 · 체력 · 적성 네 갈래의 능력을 익힙니다(앞 능력이 있어야 다음 능력).',
      '기수와의 호흡이 20 · 40 · 60 · 80 · 100에 닿을 때마다 기수 능력이 하나씩 열립니다. 호흡은 함께 나간 경주와 기승 연습으로 오릅니다.'] },
    { h: '마주 신뢰', p: [
      '이기면 오르고, 오래 경주에 나가지 않거나 크게 지면 내려갑니다. 마주의 요청을 받아들이고 그 경주에 나가면 크게 오릅니다.',
      '3세 이후에 신뢰가 0이 되면 마주의 결정으로 은퇴합니다.'] },
    { h: '은퇴 · 평가 · 결말', p: [
      '4세 12월 후반이 지나면 은퇴합니다. 평가점 = 능력치 + 익힌 능력 + 중상 우승 + 승수 + 상금. 등급은 E부터 SS까지.',
      '결말: 전설의 은퇴식(G1 4승 이상 또는 삼관) · 명마의 은퇴(G1 우승) · 중상 마의 은퇴 · 무대 뒤의 일꾼(승리는 있으나 중상 없음) · 무관의 은퇴, 그리고 부상 · 마주 결정에 의한 이른 은퇴.',
      '칭호는 성적에 따라 여러 개가 붙습니다(삼관마, 무패의 명마, 단거리 왕, 더트의 제왕 등). 지난 커리어는 이 기기의 「명예의 전당」(도감)에 남습니다. 판 밖으로 이어지는 성장은 없습니다.'] },
    { h: '여럿이 할 때(2~4명)', p: [
      '각자 한 마리씩 동시에 키웁니다. 모두가 그 턴의 할 일을 고르면 함께 진행됩니다.',
      '같은 경주를 고르면 한 경주에서 맞붙습니다. 끝났을 때 평가점이 가장 높은 사람이 이깁니다.',
      'AI 난이도는 자리마다 쉬움 · 보통 · 어려움으로 고를 수 있습니다.'] },
    { h: '조작', p: [
      '아래 탭에서 훈련 · 출전 · 관리를 고르고, 항목을 눌러 효과를 확인한 뒤 맨 아래 단추로 진행합니다.',
      '출전 탭: 경주를 누르면 적성과 예상 인기가 보이고, 위치·스퍼트를 고른 뒤 「출전 확정」.',
      'PC: 1~5 = 지금 목록의 항목 고르기 · Space = 맨 아래 단추(진행 · 경주 건너뛰기 · 확인) · ←/→ = 탭 바꾸기.'] },
    { h: '예시', p: [
      '3세 4월, 마일 A · 중거리 B · 장거리 D인 선입마. 왕관 더비(2400m)보다 봄 마일 클래식(1600m)이 잘 맞습니다.',
      '스태미나가 넉넉하면 스퍼트를 「이르게」로 걸어 긴 직선을 전력으로 버티는 작전이 통합니다. 모자라면 「늦게」나 기수 판단이 안전합니다.'] },
  ];
  function codexData() {
    const ag = { '2': '2세', '3': '3세', 'o': '3세 이상' };
    const races = GR.slice().sort((a, b) => ({ '2': 0, '3': 1, 'o': 2 }[a.ag] - { '2': 0, '3': 1, 'o': 2 }[b.ag]) || a.m - b.m || a.hf - b.hf).map((r) => ({
      icon: IC.race, name: r.n, tag: GRN[r.g] + ' · ' + ag[r.ag],
      desc: SFN[r.sf] + ' ' + r.d + 'm(' + DN[dcat(r.d)] + ') · ' + r.m + '월 ' + (r.hf ? '후반' : '전반') + ' · 1착 ' + money(prizeOf(r)) + (r.c ? ' · 삼관 ' + r.c + '차' : '') + (r.tr ? ' · ' + r.tn + '착까지 ' + GRK[r.tr].n + ' 우선 출주권' : ''),
    }));
    const hof = hofList();
    return [
      { h: '경주', p: ['중상(G1·G2·G3) 경주 일정입니다. 이 밖에 신마전·미승리전·1승 클래스·리스티드(L)가 커리어마다 조금씩 다르게 열립니다.'], rows: races },
      { h: '훈련', rows: TRAIN.map((T) => ({ icon: IC.train, name: T.n + ' 훈련', tag: '체력 ' + (T.hp > 0 ? '−' + T.hp : '+' + (-T.hp)), desc: T.d + ' · 기본 ' + T.g.map((v, i) => (v ? SN[i] + ' +' + v : '')).filter(Boolean).join(' · ') + ' (Lv · 컨디션 · 성장 · 스태프로 달라짐)' }))
        .concat(CARE.map((C) => ({ icon: IC.train, name: C.n, tag: '관리', desc: C.d }))) },
      { h: '능력', p: ['노트 점수로 익힙니다. 앞 능력이 있어야 다음 능력을 익힐 수 있습니다.'], rows: ABIL.map((A) => ({ icon: IC.ab, name: A.n, tag: ABR[A.b] + ' · 노트 ' + A.c, desc: A.d + (A.r ? ' · 먼저: ' + ABIL[ABI[A.r]].n : '') })) },
      { h: '기수', p: ['호흡 20·40·60·80·100에서 능력이 하나씩 열립니다.'], rows: JOCKEYS.map((J, i) => ({ icon: IC.jk, name: J.n, tag: '판단 ' + J.w, desc: J.d + ' · ' + jockeyPerks(i).join(' / ') + (J.rr !== 1 ? ' · 호흡 오름 ×' + J.rr : '') })) },
      { h: '스태프', rows: STAFF.map((S) => ({ icon: IC.staff, name: S.n, tag: TRAIN[S.k].n, desc: S.d + ' · 함께하면 효과 +15% · 호흡 80부터 담당 훈련 +40% 더' })) },
      { h: '혈통', rows: SIRES.map((S) => ({ icon: IC.ped, name: S.n + ' 계열', tag: '부계', desc: S.d + ' · 거리 ' + S.a.slice(0, 4).split('').join('') + ' · 잔디/더트 ' + S.a[4] + '/' + S.a[5] + ' · 선행/선입/추입 ' + S.a.slice(6).split('').join('/') }))
        .concat(DAMS.map((D) => ({ icon: IC.ped, name: D.n, tag: '모계', desc: D.d }))) },
      { h: '칭호·결말', rows: [
        ['전설의 은퇴식', '결말', 'G1 4승 이상 또는 삼관'], ['명마의 은퇴', '결말', 'G1 우승'], ['중상 마의 은퇴', '결말', 'G2·G3 우승'], ['무대 뒤의 일꾼', '결말', '승리는 있으나 중상 우승 없음'], ['무관의 은퇴', '결말', '승리 없음'], ['부상 은퇴 · 마주 결정 은퇴', '결말', '커리어 도중 은퇴'],
        ['삼관마', '칭호', '청춘 클래식 · 왕관 더비 · 단풍 스테이어 클래식'], ['무패의 명마', '칭호', '6전 이상 전승'], ['연말의 주인', '칭호', '연말 그랑프리 2회'], ['단거리 왕', '칭호', '1400m 이하 G1 2승'],
        ['마일의 지배자', '칭호', '마일 잔디 G1 2승'], ['더트의 제왕', '칭호', '더트 G1 2승'], ['장거리의 귀재', '칭호', '2500m 이상 G1 2승'], ['그랑프리 호스', '칭호', '여름 · 연말 그랑프리 우승'], ['라이벌을 넘은 말', '칭호', 'G1에서 3착 안에 들며 라이벌을 앞섬'], ['성실한 일꾼', '칭호', '20전 이상'],
      ].map(([n, t, d]) => ({ icon: IC.title, name: n, tag: t, desc: d })) },
      { h: '명예의 전당', p: [hof.length ? '이 기기에서 마친 커리어(평가점 순, 30개까지).' : '아직 기록이 없습니다. 커리어를 마치면 여기에 남습니다.'],
        rows: hof.map((x) => ({ icon: IC.hof, name: x.n, tag: x.rk + ' ' + x.rt.toLocaleString('ko-KR'), desc: x.en + ' · ' + x.tt + ' · ' + x.r + '전 ' + x.w + '승 · G1 ' + x.g1 + '승 · 상금 ' + money(x.e) })) },
    ];
  }
  function preview(cv) {
    const g = cv.getContext('2d'), W = cv.width, Hh = cv.height;
    g.fillStyle = '#e9e2cf'; g.fillRect(0, 0, W, Hh);
    g.fillStyle = '#1f1d18'; g.fillRect(0, 0, W, 44);
    g.fillStyle = '#e8e0cc'; g.font = '700 24px ' + SERIF; g.textBaseline = 'middle'; g.fillText('경주마 육성 커리어', 20, 23);
    g.fillStyle = '#a49d8b'; g.font = '500 13px ' + MONO; g.textAlign = 'right'; g.fillText('3세 · 5월 후반', W - 20, 23); g.textAlign = 'left';
    g.strokeStyle = '#c4b99d'; g.lineWidth = 1;
    for (let y = 70; y < Hh; y += 26) { g.beginPath(); g.moveTo(320, y); g.lineTo(W - 20, y); g.stroke(); }
    g.strokeStyle = '#8a826e'; g.beginPath(); g.moveTo(24, 292); g.lineTo(300, 292); g.stroke();
    g.save(); g.translate(30, 292 - 68 * 2.7); g.scale(2.7, 2.7); drawHorseStand(g, Object.assign({}, CO[0], { bz: 1, sk: 1 })); g.restore();
    const rows = [['스피드', 'B', 642], ['스태미나', 'C', 518], ['파워', 'B', 610], ['근성', 'C', 470], ['판단력', 'D', 388]];
    g.font = '600 15px ' + FONT;
    rows.forEach(([n, gr, v], i) => {
      const y = 96 + i * 30;
      g.fillStyle = '#5e584b'; g.fillText(n, 330, y);
      g.fillStyle = '#23211c'; g.font = '700 20px ' + SERIF; g.fillText(gr, 430, y);
      g.font = '600 14px ' + MONO; g.fillText(String(v), 460, y);
      g.fillStyle = '#d3c8ad'; g.fillRect(510, y - 4, 100, 6); g.fillStyle = '#5e584b'; g.fillRect(510, y - 4, v / 10, 6);
      g.font = '600 15px ' + FONT;
    });
    g.fillStyle = '#8e2b22'; g.fillRect(330, 260, 38, 20); g.fillStyle = '#f3eadb'; g.font = '700 13px ' + MONO; g.fillText('G1', 338, 271);
    g.fillStyle = '#23211c'; g.font = '700 17px ' + SERIF; g.fillText('왕관 더비', 378, 271);
    g.fillStyle = '#5e584b'; g.font = '500 12px ' + FONT; g.fillText('잔디 2400m · 3세 · 1착 3억 원', 330, 300);
  }

  L.register({
    id: ID, name: '경주마 육성 커리어', tag: '경주마 육성', cat: '전략', icon: ICON, tint: '#26392f', time: '30–60분', mood: 'calm', ambient: 'forest',
    blurb: '한 마리의 경주마를 2세 데뷔부터 4세 은퇴까지 키웁니다. 훈련·휴식·출전 일정과 기수 작전을 짜서 큰 경주에 도전하고, 은퇴 때 평가와 칭호를 받습니다. 1~4명.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, hidden: false, fixedOrder: true, undo: false, aiDelay: 520, save: true,
    saveLabel: (s) => (s.ph === 'pick' ? '망아지 고르기' : turnName(s, Math.min(s.t, s.T - 1)) + ' · ' + (s.P[0].h ? s.P[0].h.rec.n + '전 ' + s.P[0].h.rec.w + '승' : '')),
    options: [
      { id: 'len', label: '커리어 길이', tip: '어느 쪽이든 2세 1월부터 4세 12월까지입니다. 압축은 한 턴이 한 달이고 훈련 효과가 그만큼 큽니다.', choices: [{ v: 'full', label: '표준(반달 72턴)' }, { v: 'short', label: '압축(한 달 36턴)' }], def: 'full' },
    ],
    quick: [
      '경주마 한 마리를 2세 1월부터 4세 12월까지 키웁니다.',
      '턴마다 훈련 · 출전 · 관리 중 하나. 체력이 55 아래면 훈련 실패율이 오릅니다.',
      '경주는 신마전 → 미승리전 → 1승 클래스 → 중상(G3·G2·G1). 출전할 때 위치와 스퍼트를 정합니다.',
      '은퇴 때 평가 등급 · 칭호 · 결말이 정해집니다. 여럿이면 평가점이 높은 쪽이 승리.',
    ],
    rules: RULES,
    controls: [
      { id: 'go', label: '진행 · 건너뛰기 · 확인', keys: ['Space'], pad: ['a'] },
      { id: 'n1', label: '목록 1번째', keys: ['Digit1'] },
      { id: 'n2', label: '목록 2번째', keys: ['Digit2'] },
      { id: 'n3', label: '목록 3번째', keys: ['Digit3'] },
      { id: 'n4', label: '목록 4번째', keys: ['Digit4'] },
      { id: 'n5', label: '목록 5번째', keys: ['Digit5'] },
      { id: 'prev', label: '앞 탭', keys: ['ArrowLeft', 'KeyQ'], pad: ['lb'] },
      { id: 'next', label: '다음 탭', keys: ['ArrowRight', 'KeyE'], pad: ['rb'] },
    ],
    tutorial: [
      { text: '함께할 망아지를 고릅니다. 혈통 · 적성(A가 가장 잘 맞음) · 기질 · 조교사 소견을 비교합니다.', sel: '.hc-pickfoals' },
      { text: '기수를 고릅니다. 판단력이 높을수록 「기수 판단」 작전이 정확하고, 특기가 맞으면 능력이 열립니다.', sel: '.hc-pickjk' },
      { text: '고른 뒤 아래 단추로 커리어를 시작합니다.', sel: '.hc-gobtn' },
    ],
    get codex() { return codexData(); },
    init, actor, apply, ai, aiDelayFor, result, hint, panelInfo, mount, preview,
    _t: E,
  });
})();
