/* 말 위의 군주 (crownride) — 금화만으로 다스리는 옆 스크롤 왕국 전략. 1~2인(협동), 실시간, 가로 화면.
   시스템 참고: Kingdom Two Crowns(체계만 — 이름·그림·글은 독자). 그림·소리는 모두 이 파일에서 직접 그리고 합성(CC0).
   구조: 순수 시뮬(genIsland·startIsland·stepWorld·aiInput, 고정 스텝 1/30초, 판 시드 난수) + 뷰(mount).
   온라인: 방장이 세계 전체를 돌리고(hostSend 약 12Hz), 손님은 자기 군주만 미리 움직이며 위치·누르기를 publish. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const ID = 'crownride';
  const H = 1 / 30;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const sgn = (v) => (v < 0 ? -1 : 1);

  /* ======================= 자료 ======================= */
  const SEASONS = ['봄', '여름', '가을', '겨울'];
  const ORD = ['첫째', '둘째', '셋째', '넷째', '다섯째', '여섯째', '일곱째', '여덟째', '아홉째', '열째'];
  const PACE = { fast: 80, norm: 105, slow: 150 };
  const DIFF = { low: 0.72, mid: 1, high: 1.32 };
  const SEASON_DAYS = 3;
  const MOUNTS = {
    steed: { n: '군마', walk: 50, gal: 118, drain: 0.11, regen: 0.09, cap: 30, d: '처음 함께하는 말. 빠르기와 지구력이 고름.', col: '#3b2f28' },
    courser: { n: '질주마', walk: 54, gal: 152, drain: 0.17, regen: 0.09, cap: 30, d: '가장 빠른 질주. 그만큼 빨리 지침.', col: '#5a4636' },
    draft: { n: '짐말', walk: 45, gal: 100, drain: 0.06, regen: 0.12, cap: 45, d: '느리지만 좀처럼 지치지 않음. 안장 주머니가 커서 금화 45닢까지.', col: '#4a3b2e' },
    barded: { n: '갑주마', walk: 46, gal: 108, drain: 0.11, regen: 0.08, cap: 30, armor: 1, d: '마갑을 두른 말. 밤마다 한 번, 탐욕의 손길을 막아 줌.', col: '#2e2c2c' },
    stag: { n: '흰 사슴', walk: 56, gal: 134, drain: 0.13, regen: 0.1, cap: 30, lure: 1, d: '숲의 사슴들이 뒤를 따름. 궁수의 사냥감이 성벽 가까이 모임.', col: '#cfc6b4' },
  };
  const ISLE_MOUNT = ['courser', 'draft', 'stag', 'barded', 'courser', 'draft', 'stag'];
  const WALL = { cost: [2, 4, 6, 9], hp: [0, 10, 22, 40, 64], work: [4, 7, 11, 15], n: ['', '말뚝 울타리', '목책', '돌벽', '성벽'] };
  const TOWN = { cost: [3, 6, 10], work: [10, 16, 24], n: ['모닥불', '목책 장원', '돌 성채', '왕성'] };
  const TOWER = { cost: [3, 6], work: [8, 12], req: [1, 2], n: ['', '나무 망루', '돌 망루'], posts: [0, 2, 3], range: [0, 275, 310] };
  const FARM = { cost: [4, 6], work: [6, 9], req: [1, 2], n: ['', '밭', '넓은 밭'], slots: [0, 1, 2] };
  const BOAT = { cost: [3, 6, 9], work: [14, 22, 30], req: [1, 1, 2], n: ['난파선', '용골', '선체', '돛배'] };
  const TOOLS = {
    bow: { n: '활', c: 2, role: 'arc', req: 0, x: -60 },
    hammer: { n: '망치', c: 3, role: 'bld', req: 0, x: 60 },
    scythe: { n: '낫', c: 3, role: 'far', req: 1, x: 100 },
    shield: { n: '방패', c: 5, role: 'kni', req: 2, x: -100 },
  };
  const TOOL_OF = { arc: 'bow', bld: 'hammer', far: 'scythe', kni: 'shield' };
  const SHOP_N = { bow: '활 공방', hammer: '망치 공방', scythe: '낫 공방', shield: '방패 공방' };
  const BOMB = { c: 8, req: 3, x: -140, spd: 26 };
  const RACK = 4;
  const ROLE = { vag: '떠돌이', pea: '백성', arc: '궁수', bld: '일꾼', far: '농부', kni: '기사', deer: '사슴' };
  const ENEMY = {
    g: { n: '손아귀', hp: 1, spd: 46, dmg: 1, cd: 1.0, d: '가장 흔한 탐욕. 작고 빠름. 금화·도구·왕관을 낚아채 균열로 달아남.' },
    c: { n: '발톱', hp: 5, spd: 36, dmg: 3, cd: 1.2, d: '셋째 밤부터. 단단하고 성벽을 세게 긁음.' },
    r: { n: '등짐꾼', hp: 20, spd: 24, dmg: 9, cd: 1.6, d: '핏빛 달의 밤에 옴. 성벽을 부수고, 등에 업은 손아귀를 내려놓음.' },
    f: { n: '날개', hp: 3, spd: 40, dmg: 0, cd: 1, d: '셋째 섬부터. 성벽을 넘어 날아와 망루와 성벽 위의 궁수에게서 활을 빼앗음.' },
  };
  const KNIGHT_HP = 10;
  const PORTAL_HP = (k) => 24 + 10 * k;
  const BM_EVERY = [7, 6, 5, 5, 4, 4, 4];
  const RECRUIT_COST = 1;
  const PAY_INT = 0.3;           // 금화 하나를 떨어뜨리는 간격(초)
  const PAY_R = 26;              // 표시까지 닿는 거리
  const START_PURSE = 6;

  const tfOf = (W) => (W.t % W.D) / W.D;
  const dayOf = (W) => Math.floor(W.t / W.D) + 1;
  const isDark = (tf) => tf >= 0.69 || tf < 0.03;
  const seasonOf = (day) => Math.floor((day - 1) / SEASON_DAYS) % 4;
  const isWinter = (W) => seasonOf(W.day) === 3;
  const isleName = (k) => (ORD[k] || (k + 1) + '번째') + ' 섬';
  const dayName = (d) => d + '일째';

  function mkRand(seed) {
    let a = (seed >>> 0) || 1;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), a | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function rnd(W) { let t = (W.rs = (W.rs + 0x6D2B79F5) | 0); t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }

  /* ======================= 섬 배치(시드로 결정 — 방장·손님이 같은 섬을 만든다) ======================= */
  function genIsland(sd, k) {
    const R = mkRand((sd * 31 + k * 7919 + 17) | 0);
    const hw = 1150 + 190 * k;
    const S = []; let id = 1;
    const add = (o) => { o.i = id++; S.push(o); return o; };
    add({ k: 'town', x: 0, s: 0, d: 0 });
    for (const t in TOOLS) add({ k: 'shop', t, x: TOOLS[t].x, s: sgn(TOOLS[t].x), d: Math.abs(TOOLS[t].x) });
    add({ k: 'bomb', x: BOMB.x, s: -1, d: -BOMB.x });
    const WD = [175, 360, 580, 820, 1080, 1340, 1600, 1860], TD = [250, 470, 700, 950, 1210, 1470, 1730], FD = [305, 640, 885, 1145];
    const lim = hw - 330;
    for (const s of [-1, 1]) {
      WD.forEach((d, j) => { if (d < lim) add({ k: 'wall', x: s * d, s, d, j }); });
      TD.forEach((d) => { if (d < lim - 40) add({ k: 'tower', x: s * d, s, d }); });
    }
    let fs = R() < 0.5 ? -1 : 1;
    const nf = 2 + (k >= 1 ? 1 : 0);
    FD.forEach((d, j) => { if (j < nf && d < lim) { add({ k: 'farm', x: fs * d, s: fs, d }); fs = -fs; } });
    add({ k: 'boat', x: hw - 62, s: 1, d: hw - 62 });
    const px = hw - 170;
    const P = [{ x: -px, s: -1, kind: 'p' }, { x: px, s: 1, kind: 'p' }, { x: -(hw - 48), s: -1, kind: 'c' }];
    const used = S.map((o) => o.x).concat(P.map((p) => p.x));
    const free = (lo, hi, s) => {
      for (let n = 0; n < 80; n++) { const x = Math.round(s * (lo + R() * (hi - lo))); if (used.every((u) => Math.abs(u - x) >= 50)) { used.push(x); return x; } }
      const x = Math.round(s * (lo + hi) / 2); used.push(x); return x;
    };
    const camps = [free(hw * 0.46, hw * 0.66, -1), free(hw * 0.46, hw * 0.66, 1)];
    const ms = R() < 0.5 ? -1 : 1;
    const mx = free(hw * 0.32, hw * 0.6, ms);
    add({ k: 'mount', x: mx, s: ms, d: Math.abs(mx), t: ISLE_MOUNT[k % ISLE_MOUNT.length] });
    const chests = [{ x: free(30, 50, R() < 0.5 ? -1 : 1), c: k ? 6 : 8 }];
    for (let j = 0; j < 2; j++) { const s = j ? -chests[1].x / Math.abs(chests[1].x) : (R() < 0.5 ? -1 : 1); chests.push({ x: free(hw * 0.3, hw * 0.72, s), c: 5 + Math.floor(R() * 4) + k }); }
    const trees = [];
    for (let x = -hw + 8; x < hw - 8; x += 13 + R() * 24) { if (Math.abs(x) < 160) continue; trees.push([Math.round(x), Math.round(46 + R() * 54), Math.floor(R() * 3), Math.round(R() * 100)]); }
    return { hw, S, P, camps, chests, trees, sd, k };
  }

  /* ======================= 세계 ======================= */
  function newRun(o) {
    const n = clamp(o.n | 0, 1, 2);
    const W = {
      v: 1, sd: (o.sd | 0) || 1, nI: o.nI || 3, D: o.D || PACE.norm, df: o.df || 1, n,
      rs: ((o.sd | 0) ^ 0x5bd1e995) | 0, k: 0, uid: 1, fq: 0, fx: [],
      M: [], ST: { nt: 0, cn: 0, wb: 0, rc: 0, kl: 0, isl: 0, days: 0, cl: 0 }, over: null,
    };
    for (let s = 0; s < n; s++) W.M.push({ x: n > 1 ? (s ? 24 : -24) : 0, v: 0, dir: s ? -1 : 1, g: 0, sta: 1, tired: 0, mt: 'steed', cr: 1, pu: START_PURSE, inv: 0, ar: 1, mk: 0, ht: 0, lock: 0, gt: 0, hold: 0 });
    startIsland(W, 0, null);
    if (o.trial) { W.trial = 1; W.df *= 0.85; W.S.find((q) => q.k === 'boat').lv = 2; }
    return W;
  }
  function startIsland(W, k, carry) {
    const G = genIsland(W.sd, k);
    W.k = k; W.hw = G.hw; W.t = W.D * 0.07; W.day = 1; W.dawnDay = 1; W.nightDay = 0;
    W.S = G.S.map((o) => Object.assign({ lv: 0, hp: 0, mh: 0, paid: 0, pc: [0, 0], job: null, br: 0, rack: 0, pt: 0 }, o));
    const town = W.S.find((o) => o.k === 'town'); town.lv = 0;
    W.P = G.P.map((p) => ({ x: p.x, s: p.s, kind: p.kind, hp: p.kind === 'c' ? 1 : PORTAL_HP(k), mh: p.kind === 'c' ? 1 : PORTAL_HP(k), al: 1, sp: 0 }));
    W.camps = G.camps.slice(); W.ch = G.chests.map((c) => ({ x: c.x, c: c.c, op: 0 }));
    W.tc = 0; W.u = []; W.e = []; W.gc = []; W.ar = []; W.tl = []; W.cw = []; W.bm = null; W.sq = [null, null];
    W.reach = [240, 240]; W.spawnQ = []; W.bmn = 0; W.sail = null; W.clean = 0; W.trans = 0;
    W.M.forEach((m, s) => { m.x = W.n > 1 ? (s ? 24 : -24) : 0; m.v = 0; m.inv = 0; m.mk = 0; m.ht = 0; m.lock = 0; m.ar = 1; m.sta = 1; m.tired = 0; m.cr = 1; });
    // 백성: 처음 섬은 둘, 다음 섬은 데려온 사람들
    if (!carry) { uAdd(W, 'pea', -30); uAdd(W, 'pea', 34); }
    else carry.forEach((t, j) => { const u = uAdd(W, t, (j % 2 ? 1 : -1) * (30 + j * 8)); if (t === 'arc' || t === 'kni') u.sd = j % 2 ? 1 : -1; });
    W.camps.forEach((x) => { for (let j = 0; j < 2; j++) uAdd(W, 'vag', x + (j ? 14 : -12), { home: x }); });
    for (const s of [-1, 1]) for (let j = 0; j < 3; j++) spawnDeer(W, s);
    fx(W, 'isle', 0, k);
  }
  function uAdd(W, t, x, o) {
    const u = Object.assign({ i: W.uid++, t, x, dir: x < 0 ? 1 : -1, tx: x, cc: 0, hp: t === 'kni' ? KNIGHT_HP : 1, cd: 0, sd: 0, job: 0, st: 0, wt: 0, sq: 0, home: 0, ph: 0 }, o || {});
    if ((t === 'arc' || t === 'kni') && !u.sd) u.sd = pickSide(W, t);
    W.u.push(u); return u;
  }
  function pickSide(W, t) {
    let l = 0, r = 0; for (const u of W.u) if (u.t === t) { if (u.sd < 0) l++; else if (u.sd > 0) r++; }
    return l < r ? -1 : r < l ? 1 : (rnd(W) < 0.5 ? -1 : 1);
  }
  function fx(W, k, x, a, b) { W.fq++; W.fx.push([W.fq, k, Math.round(x || 0), a == null ? 0 : a, b == null ? 0 : b]); if (W.fx.length > 30) W.fx.shift(); }
  function spawnDeer(W, s) {
    const si = s < 0 ? 0 : 1, lo = W.reach[si] + 70, hi = W.hw - 200;
    if (hi - lo < 40) return;
    uAdd(W, 'deer', s * (lo + rnd(W) * (hi - lo)), { home: s });
  }
  function dropCoin(W, x, n, spread) { for (let j = 0; j < n; j++) { if (W.gc.length > 90) break; W.gc.push({ x: x + (rnd(W) - 0.5) * (spread || 20), a: 0, i: W.uid++ }); } }

  /* ----- 한 걸음마다 다시 만드는 보조 정보(저장하지 않음) ----- */
  function ctxOf(W) {
    const C = { wl: [[], []], outer: [null, null], outerB: [null, null], tw: [[], []], town: null, shop: {}, boat: null, bomb: null, mount: null, farms: [], cnt: { vag: 0, pea: 0, arc: 0, bld: 0, far: 0, kni: 0, deer: 0 }, side: { arc: [0, 0], kni: [0, 0] } };
    for (const o of W.S) {
      if (o.k === 'wall') { const si = o.s < 0 ? 0 : 1; C.wl[si].push(o); if (o.lv > 0) { if (!C.outerB[si] || o.d > C.outerB[si].d) C.outerB[si] = o; if (!o.br && (!C.outer[si] || o.d > C.outer[si].d)) C.outer[si] = o; } }
      else if (o.k === 'tower') C.tw[o.s < 0 ? 0 : 1].push(o);
      else if (o.k === 'town') C.town = o;
      else if (o.k === 'shop') C.shop[o.t] = o;
      else if (o.k === 'boat') C.boat = o;
      else if (o.k === 'bomb') C.bomb = o;
      else if (o.k === 'mount') C.mount = o;
      else if (o.k === 'farm') C.farms.push(o);
    }
    for (const u of W.u) { C.cnt[u.t] = (C.cnt[u.t] || 0) + 1; if (u.t === 'arc' || u.t === 'kni') C.side[u.t][u.sd < 0 ? 0 : 1]++; }
    // 궁수 자리: 바깥 망루 → 바깥 성벽 뒤
    C.posts = [[], []];
    for (const si of [0, 1]) {
      const s = si ? 1 : -1, ow = C.outer[si];
      const tws = C.tw[si].filter((t) => t.lv > 0 && t.job == null && (!ow || t.d < ow.d + 5)).sort((a, b) => b.d - a.d);
      for (const t of tws) for (let j = 0; j < TOWER.posts[t.lv]; j++) C.posts[si].push({ x: t.x - s * (j * 6 - 3), tw: t.lv });
      const bx = ow ? ow.x - s * 16 : s * 70;
      for (let j = 0; j < 14; j++) C.posts[si].push({ x: bx - s * j * 8, tw: 0 });
    }
    return C;
  }
  const sideIdx = (x) => (x < 0 ? 0 : 1);
  /* x에서 보아 s쪽 바깥에 있는 탐욕과 사이에 성한 성벽이 있나 */
  function wallBetween(C, s, inner, outer) { const si = s < 0 ? 0 : 1; for (const w of C.wl[si]) if (w.lv > 0 && !w.br && s * w.x > s * inner && s * w.x < s * outer) return w; return null; }
  function insideWalls(C, x) { const si = sideIdx(x), ow = C.outer[si]; return ow ? Math.abs(x) < ow.d - 6 : Math.abs(x) < 60; }

  /* ----- 표시(금화를 내는 곳) ----- */
  function costOf(W, C, o) {
    const town = C.town;
    switch (o.k) {
      case 'town': return o.lv < 3 && !o.job ? TOWN.cost[o.lv] : 0;
      case 'wall': {
        if (o.job || o.d > W.reach[sideIdx(o.x)]) return 0;
        if (o.br) return Math.max(1, Math.floor(WALL.cost[o.lv - 1] / 2));
        return o.lv < Math.min(4, town.lv + 1) ? WALL.cost[o.lv] : 0;
      }
      case 'tower': if (o.job || o.d > W.reach[sideIdx(o.x)]) return 0; return o.lv < 2 && town.lv >= TOWER.req[o.lv] ? TOWER.cost[o.lv] : 0;
      case 'farm': if (o.job || o.d > W.reach[sideIdx(o.x)]) return 0; return o.lv < 2 && town.lv >= FARM.req[o.lv] ? FARM.cost[o.lv] : 0;
      case 'shop': return town.lv >= TOOLS[o.t].req && o.rack < RACK ? TOOLS[o.t].c : 0;
      case 'boat': {
        if (o.job) return 0;
        if (o.lv < 3) return town.lv >= (W.trial ? 1 : BOAT.req[o.lv]) ? BOAT.cost[o.lv] + W.k : 0;
        const tf = tfOf(W); return !W.sail && tf > 0.04 && tf < 0.6 ? 2 : 0;
      }
      case 'bomb': return town.lv >= BOMB.req && !W.bm && W.P[2].al ? BOMB.c : 0;
      case 'mount': return 4 + W.k;
      case 'asl': return 0;
    }
    return 0;
  }
  function canStand(W, o, m) { // 함께 타야 하는 표시(출항)
    if (o.k === 'boat' && o.lv >= 3) return W.M.every((q) => !q.cr || Math.abs(q.x - o.x) < 90);
    return true;
  }
  /* 돌격 깃발: 바깥 성벽 앞(그 쪽 기사가 있고 균열이 남아 있을 때, 낮 전반) */
  function aslSpot(W, C, si) {
    const s = si ? 1 : -1, P = W.P[si];
    if (!P.al || W.sq[si] || C.side.kni[si] < 1 || C.town.lv < 2) return null;
    const tf = tfOf(W); if (tf < 0.04 || tf > 0.4) return null;
    const ow = C.outer[si]; const x = (ow ? ow.x : s * 120) + s * 34;
    return { k: 'asl', s, si, x, i: 900 + si, paid: W.aslPaid ? W.aslPaid[si] : 0, cost: 3 };
  }
  function targetsNear(W, C, m, s) {
    // 가장 가까운 표시나 떠돌이
    let best = null, bd = 1e9;
    for (const o of W.S) {
      const c = costOf(W, C, o); if (!c) continue;
      const d = Math.abs(o.x - m.x); if (d < PAY_R && d < bd) { bd = d; best = { o, c }; }
    }
    for (const si of [0, 1]) { const a = aslSpot(W, C, si); if (a) { const d = Math.abs(a.x - m.x); if (d < PAY_R && d < bd) { bd = d; best = { o: a, c: a.cost, asl: si }; } } }
    for (const u of W.u) if (u.t === 'vag' && !u.rc) { const d = Math.abs(u.x - m.x); if (d < 30 && d < bd) { bd = d; best = { vag: u, c: RECRUIT_COST }; } }
    return best;
  }

  /* ======================= 한 걸음 ======================= */
  function stepWorld(W, IN, dt) {
    if (W.over) return;
    if (W.trans > 0) { W.trans -= dt; if (W.trans <= 0) finishSail(W); return; }
    const prevTf = tfOf(W);
    W.t += dt;
    const tf = tfOf(W), day = dayOf(W);
    if (day !== W.day) { W.day = day; dawn(W); }
    if (prevTf < 0.6 && tf >= 0.6) { // 해 질 녘
      W.bmn = W.day % (BM_EVERY[Math.min(W.k, BM_EVERY.length - 1)]) === 0 && W.day > 2 ? 1 : 0;
      fx(W, 'dusk', 0, W.bmn);
    }
    if (prevTf < 0.7 && tf >= 0.7 && W.nightDay !== W.day) { W.nightDay = W.day; planWave(W); }
    const C = ctxOf(W);
    // 군주
    W.M.forEach((m, s) => {
      const inp = (IN && IN[s]) || {};
      if (inp.ext) { if (typeof inp.x === 'number' && isFinite(inp.x)) { const dx = clamp(inp.x - m.x, -200 * dt * 3, 200 * dt * 3); m.x = clamp(m.x + dx, -W.hw + 22, W.hw - 22); } m.dir = inp.dir || m.dir; m.g = inp.g ? 1 : 0; if (typeof inp.sta === 'number') m.sta = clamp(inp.sta, 0, 1); }
      else monMove(W, m, inp, dt);
      m.inv = Math.max(0, m.inv - dt); m.lock = Math.max(0, m.lock - dt);
      m.hold = inp.hold ? 1 : 0;
      payStep(W, C, m, s, !!inp.hold, dt);
      collectStep(W, C, m, s, dt);
    });
    // 땅이 넓어짐
    for (const si of [0, 1]) { const ow = C.outerB[si]; if (ow) W.reach[si] = Math.max(W.reach[si], ow.d + 230); }
    unitsStep(W, C, dt);
    enemyStep(W, C, dt);
    arrowStep(W, C, dt);
    spawnStep(W, C, dt);
    bombStep(W, C, dt);
    W.gc.forEach((c) => { c.a += dt; });
    if (W.sail) { W.sail.t += dt; if (W.sail.t > 3.2) { W.trans = 2.2; fx(W, 'sailaway', W.S.find((o) => o.k === 'boat').x); } }
    if (!W.clean && !W.P.some((p) => p.al)) { W.clean = 1; W.ST.cl++; fx(W, 'clean', 0); W.sail = { t: 0, clean: 1 }; }
  }
  function monMove(W, m, inp, dt) {
    const M = MOUNTS[m.mt] || MOUNTS.steed;
    const ax = clamp(+inp.ax || 0, -1, 1);
    if (m.tired && m.sta >= 0.35) m.tired = 0;
    const wantGal = !!inp.gal && !m.tired && Math.abs(ax) > 0.3;
    const top = Math.abs(ax) < 0.15 ? 0 : (wantGal ? M.gal : M.walk) * ax;
    const a = (top === 0 ? 260 : Math.abs(top) < Math.abs(m.v) ? 200 : 150) * dt;
    m.v += clamp(top - m.v, -a, a);
    m.x += m.v * dt;
    const lo = -W.hw + 22, hi = W.hw - 22;
    if (m.x < lo) { m.x = lo; m.v = 0; } else if (m.x > hi) { m.x = hi; m.v = 0; }
    if (Math.abs(m.v) > 2) m.dir = m.v > 0 ? 1 : -1;
    const gal = Math.abs(m.v) > M.walk + 6;
    m.g = gal ? 1 : 0;
    if (gal) { m.sta -= M.drain * dt; if (m.sta <= 0) { m.sta = 0; m.tired = 1; } }
    else m.sta = Math.min(1, m.sta + M.regen * dt * (Math.abs(m.v) < 2 ? 2.4 : 0.7));
  }
  function capOf(m) { return (MOUNTS[m.mt] || MOUNTS.steed).cap; }
  function give(W, m, n, x) { // 지갑에 넣고 넘치면 땅에
    const room = capOf(m) - m.pu, k = Math.min(room, n);
    m.pu += k; if (n > k) dropCoin(W, x == null ? m.x : x, n - k, 16);
    return k;
  }
  function refund(W, o, s) {
    const m = W.M[s]; const n = o.pc ? o.pc[s] : 0;
    if (n > 0) { give(W, m, n, o.x); o.paid -= n; o.pc[s] = 0; fx(W, 'refund', o.x, s, n); W.ST.rf = (W.ST.rf || 0) + n; }
    if (o.paid < 0) o.paid = 0;
  }
  function findTarget(W, C, id) {
    if (!id) return null;
    if (id >= 900 && id < 902) return aslSpot(W, C, id - 900);
    if (id >= 100000) { const u = W.u.find((q) => q.i === id - 100000); return u && u.t === 'vag' ? { vag: u } : null; }
    return W.S.find((o) => o.i === id) || null;
  }
  function payStep(W, C, m, s, hold, dt) {
    let cur = findTarget(W, C, m.mk);
    // 놓거나 멀어지면 돌려받음
    const gone = () => { refundId(W, m.mk, s); m.mk = 0; m.ht = 0; };
    if (!hold || !m.cr || m.lock > 0) { if (m.mk) gone(); return; }
    if (cur) {
      const x = cur.vag ? cur.vag.x : cur.x;
      const c = cur.vag ? RECRUIT_COST : cur.k === 'asl' ? cur.cost : costOf(W, C, cur);
      if (Math.abs(x - m.x) > PAY_R + 10 || !c || (cur.vag && cur.vag.t !== 'vag')) { gone(); cur = null; }
    }
    if (!cur) {
      const t = targetsNear(W, C, m, s); if (!t) return;
      m.mk = t.vag ? 100000 + t.vag.i : t.o.i; m.ht = PAY_INT * 0.5; cur = t.vag ? { vag: t.vag } : t.o;
    }
    if (m.pu <= 0) return;
    m.ht -= dt;
    if (m.ht > 0) return;
    m.ht = PAY_INT;
    if (cur.vag) { // 떠돌이 모으기
      m.pu--; recruit(W, cur.vag); fx(W, 'coin', cur.vag.x, s, 1); m.mk = 0; m.lock = 0.35; return;
    }
    if (!canStand(W, cur, m)) return;
    const cost = cur.k === 'asl' ? 3 : costOf(W, C, cur);
    if (cur.k === 'asl') { W.aslPaid = W.aslPaid || [0, 0]; W.aslPc = W.aslPc || [[0, 0], [0, 0]]; m.pu--; W.aslPaid[cur.si]++; W.aslPc[cur.si][s]++; fx(W, 'coin', cur.x, s, W.aslPaid[cur.si]); if (W.aslPaid[cur.si] >= cost) { W.aslPaid[cur.si] = 0; W.aslPc[cur.si] = [0, 0]; startAssault(W, C, cur.si); m.mk = 0; m.lock = 0.6; } return; }
    m.pu--; cur.paid++; cur.pc[s] = (cur.pc[s] || 0) + 1; W.ST.sp = (W.ST.sp || 0) + 1;
    fx(W, 'coin', cur.x, s, cur.paid);
    if (cur.paid >= cost) { cur.paid = 0; cur.pc = [0, 0]; complete(W, C, cur, s); m.mk = 0; m.lock = 0.6; }
  }
  function refundId(W, id, s) {
    if (!id || id >= 100000) return;
    if (id >= 900 && id < 902) { const si = id - 900; if (W.aslPc && W.aslPc[si][s]) { const n = W.aslPc[si][s]; give(W, W.M[s], n); W.aslPaid[si] = Math.max(0, W.aslPaid[si] - n); W.aslPc[si][s] = 0; fx(W, 'refund', W.M[s].x, s, n); } return; }
    const o = W.S.find((q) => q.i === id); if (o) refund(W, o, s);
  }
  function recruit(W, u) {
    u.t = 'pea'; u.rc = 1; u.home = 0; u.tx = (rnd(W) - 0.5) * 80; W.ST.rc++;
    fx(W, 'recruit', u.x);
  }
  function complete(W, C, o, s) {
    switch (o.k) {
      case 'town': o.job = { to: o.lv + 1, need: TOWN.work[o.lv], done: 0 }; break;
      case 'wall': o.job = o.br ? { to: o.lv, need: Math.ceil(WALL.work[o.lv - 1] * 0.6), done: 0, fix: 1 } : { to: o.lv + 1, need: WALL.work[o.lv], done: 0 }; break;
      case 'tower': o.job = { to: o.lv + 1, need: TOWER.work[o.lv], done: 0 }; break;
      case 'farm': o.job = { to: o.lv + 1, need: FARM.work[o.lv], done: 0 }; break;
      case 'boat':
        if (o.lv < 3) o.job = { to: o.lv + 1, need: BOAT.work[o.lv], done: 0 };
        else { W.sail = { t: 0 }; fx(W, 'sail', o.x); }
        break;
      case 'shop': o.rack++; fx(W, 'tool', o.x, o.t); break;
      case 'bomb': W.bm = { x: o.x, go: 0, b: [] }; fx(W, 'built', o.x); break;
      case 'mount': { const m = W.M[s]; const old = m.mt; m.mt = o.t; o.t = old; m.sta = 1; m.tired = 0; if (m.pu > capOf(m)) { dropCoin(W, m.x, m.pu - capOf(m), 20); m.pu = capOf(m); } fx(W, 'mount', o.x, s); break; }
    }
    if (o.job) fx(W, 'order', o.x, o.k);
  }
  function collectStep(W, C, m, s, dt) {
    m.gt -= dt;
    // 땅의 금화
    if (m.pu < capOf(m)) for (let j = W.gc.length - 1; j >= 0; j--) { const c = W.gc[j]; if (c.a > 0.45 && Math.abs(c.x - m.x) < 15) { W.gc.splice(j, 1); m.pu++; W.ST.cn++; fx(W, 'pick', c.x, s); if (m.pu >= capOf(m)) break; } }
    // 상자
    for (const c of W.ch) if (!c.op && Math.abs(c.x - m.x) < 16) { c.op = 1; dropCoin(W, c.x, c.c, 46); fx(W, 'chest', c.x); }
    // 금고(모닥불 곁)와 일꾼들이 들고 온 금화
    if (m.gt <= 0 && m.pu < capOf(m)) {
      if (W.tc > 0 && Math.abs(m.x) < 28) { W.tc--; m.pu++; W.ST.cn++; m.gt = 0.09; fx(W, 'pick', 0, s); }
      else for (const u of W.u) if (u.cc > 0 && Math.abs(u.x - m.x) < 32) { u.cc--; m.pu++; W.ST.cn++; m.gt = 0.14; fx(W, 'give', u.x, s); break; }
    }
    // 떨어진 왕관
    for (let j = W.cw.length - 1; j >= 0; j--) { const c = W.cw[j]; if (Math.abs(c.x - m.x) < 16 && (m.cr || c.s === s)) { W.M[c.s].cr = 1; W.cw.splice(j, 1); fx(W, 'crownback', c.x, c.s); } }
  }

  /* ----- 새벽 ----- */
  function dawn(W) {
    const tfNow = tfOf(W);
    if (W.nightDay) W.ST.nt++;
    W.ST.days++;
    fx(W, 'dawn', 0, W.day);
    for (const e of W.e) { e.st = 2; }
    W.spawnQ.length = 0;
    // 도구는 공방 선반으로
    const C = ctxOf(W);
    for (const t of W.tl) { const sh = C.shop[t.t]; if (sh && sh.rack < RACK) sh.rack++; }
    W.tl.length = 0;
    for (const u of W.u) { if (u.t === 'kni') u.hp = KNIGHT_HP; }
    W.M.forEach((m) => { m.ar = 1; });
    // 새벽의 세금: 백성 넷마다 한 닢(최소 한 닢)이 금고에
    const subj = W.u.filter((u) => u.t !== 'vag' && u.t !== 'deer').length;
    W.tc += 1 + Math.floor(subj / 4);
    // 떠돌이가 새로 옴
    W.camps.forEach((x) => { const n = W.u.filter((u) => u.t === 'vag' && u.home === x).length; if (n < 3 && rnd(W) < 0.75) uAdd(W, 'vag', x + (rnd(W) - 0.5) * 30, { home: x }); });
    for (const s of [-1, 1]) { const n = W.u.filter((u) => u.t === 'deer' && u.home === s).length, lim = isWinter(W) ? 2 : 5; for (let j = n; j < lim; j++) if (rnd(W) < 0.7) spawnDeer(W, s); }
    void tfNow;
  }
  /* ----- 밤의 무리 ----- */
  function planWave(W) {
    const D = W.day, k = W.k, df = W.df, bm = W.bmn;
    const t0 = W.t, nl = W.D * 0.24;
    const q = [];
    const push = (si, t, n, fromCliff) => { for (let j = 0; j < n; j++) q.push({ at: t0 + nl * (0.04 + 0.62 * ((j + 0.5 + rnd(W) * 0.6) / Math.max(1, n))), si, t, c: fromCliff ? 1 : 0 }); };
    for (const si of [0, 1]) {
      const P = W.P[si], cliff = W.P[2];
      let mul = 1, fromCliff = 0;
      if (!P.al) { if (si === 0 && cliff.al) { mul = 0.5; fromCliff = 1; } else continue; }
      const jit = 0.85 + rnd(W) * 0.3;
      let g = Math.round(df * mul * jit * (1.6 + 1.05 * D + 1.1 * k));
      let c = D >= 3 ? Math.round(df * mul * ((D - 2) * 0.6 + k * 0.6)) : 0;
      let r = bm ? 1 + k + Math.floor(D / 6) : D >= 8 ? Math.round(df * mul * Math.max(0, (D - 6) / 4 + k * 0.3) * (0.6 + rnd(W) * 0.5)) : 0;
      let f = k >= 2 && D >= 4 ? Math.round(df * mul * (D - 3) * 0.22) : 0;
      if (bm) { g = Math.round(g * 2); c = Math.round(c * 1.8 + 1); }
      if (si === 0 && cliff.al && bm && !fromCliff) { push(0, 'g', Math.round(g * 0.6), 1); push(0, 'c', Math.round(c * 0.5), 1); push(0, 'r', 1, 1); }
      push(si, 'g', g, fromCliff); push(si, 'c', c, fromCliff); push(si, 'r', r, fromCliff); push(si, 'f', f, fromCliff);
    }
    q.sort((a, b) => a.at - b.at);
    W.spawnQ = q;
    W.waveN = q.length;
  }
  function spawnStep(W, C, dt) {
    while (W.spawnQ.length && W.spawnQ[0].at <= W.t) {
      const q = W.spawnQ.shift();
      const P = q.c ? W.P[2] : W.P[q.si];
      if (!P.al) continue;
      eAdd(W, q.t, P.x + (rnd(W) - 0.5) * 16, q.si ? 1 : -1, P.x);
    }
    // 돌격 중 균열 지킴이
    for (const si of [0, 1]) {
      const sq = W.sq[si], P = W.P[si]; if (!sq || !P.al) continue;
      if (sq.at) { sq.sp = (sq.sp || 0) - dt; if (sq.sp <= 0) { sq.sp = 2.6; const n = W.e.filter((e) => e.df && e.s === (si ? 1 : -1)).length; if (n < 4) { const e = eAdd(W, 'g', P.x, si ? 1 : -1, P.x); e.df = 1; } } }
    }
  }
  function eAdd(W, t, x, s, home) {
    const E = ENEMY[t];
    const e = { i: W.uid++, t, x, y: t === 'f' ? 64 : 0, s, hp: Math.round(E.hp * (1 + 0.2 * W.k + 0.015 * Math.max(0, W.day - 6))), mh: 0, st: 0, cd: 0.5, home, loot: 0, tg: 0, sp: 4 };
    if (t === 'g') e.hp = E.hp;
    e.mh = e.hp; W.e.push(e); return e;
  }

  /* ----- 백성 ----- */
  function walkTo(u, x, spd, dt) { const d = x - u.x; if (Math.abs(d) < 1.5) return true; const s = Math.min(Math.abs(d), spd * dt) * sgn(d); u.x += s; u.dir = sgn(d); u.mv = 1; return Math.abs(x - u.x) < 1.5; }
  function startAssault(W, C, si) {
    const s = si ? 1 : -1;
    W.sq[si] = { t: W.t, at: 0 };
    let ar = 0; const kn = W.u.filter((u) => u.t === 'kni' && u.sd === s).length;
    for (const u of W.u) { if (u.t === 'kni' && u.sd === s) u.sq = 1; }
    for (const u of W.u) { if (u.t === 'arc' && u.sd === s && ar < kn * 2 + 1) { u.sq = 1; ar++; } }
    fx(W, 'assault', s * 200, si);
  }
  function endAssault(W, si) { W.sq[si] = null; const s = si ? 1 : -1; for (const u of W.u) if (u.sq && u.sd === s) u.sq = 0; for (const e of W.e) if (e.df && e.s === s) e.st = 2; }
  function unitsStep(W, C, dt) {
    const tf = tfOf(W), dark = isDark(tf), eve = tf > 0.6 || tf < 0.03, winter = isWinter(W);
    // 돌격 끝내기
    for (const si of [0, 1]) if (W.sq[si] && (tf > 0.58 || tf < 0.03 || !W.P[si].al)) endAssault(W, si);
    // 일꾼 일감
    const jobs = [];
    for (const o of W.S) {
      if (o.job) { const outside = o.k === 'boat' || (o.d && !insideWalls(C, o.x) && o.k !== 'town' && o.k !== 'shop' && o.k !== 'bomb'); if (!eve || !outside) jobs.push({ o, x: o.x, rep: 0 }); }
      else if (o.k === 'wall' && o.lv > 0 && !o.br && o.hp < o.mh && !dark && tf < 0.6) jobs.push({ o, x: o.x, rep: 1 });
    }
    const asg = {};
    for (const u of W.u) if (u.t === 'bld' && u.job) asg[u.job] = (asg[u.job] || 0) + 1;
    const fslots = {}; for (const f of C.farms) fslots[f.i] = 0; for (const u of W.u) if (u.t === 'far' && u.job && fslots[u.job] != null) fslots[u.job]++;
    const posts = C.posts, pidx = [0, 0];
    const arcs = W.u.filter((u) => u.t === 'arc' && !u.sq).sort((a, b) => a.i - b.i);
    const postOf = {};
    for (const u of arcs) { const si = u.sd < 0 ? 0 : 1; const p = posts[si][Math.min(posts[si].length - 1, pidx[si]++)]; postOf[u.i] = p; }
    const kn = [0, 0];
    for (let j = W.u.length - 1; j >= 0; j--) {
      const u = W.u[j]; u.mv = 0; u.cd -= dt;
      switch (u.t) {
        case 'vag': { if (rnd(W) < dt * 0.4) u.tx = u.home + (rnd(W) - 0.5) * 70; walkTo(u, u.tx, 14, dt); break; }
        case 'pea': {
          let goal = null;
          for (const t in C.shop) { const sh = C.shop[t]; if (sh.rack > 0 && C.town.lv >= TOOLS[t].req && (!goal || Math.abs(sh.x - u.x) < Math.abs(goal.x - u.x))) goal = sh; }
          if (goal) { if (walkTo(u, goal.x, 30, dt) && goal.rack > 0) { goal.rack--; u.t = TOOLS[goal.t].role; u.hp = u.t === 'kni' ? KNIGHT_HP : 1; u.sd = (u.t === 'arc' || u.t === 'kni') ? pickSide(W, u.t) : 0; u.job = 0; fx(W, 'equip', u.x, goal.t); } }
          else { if (rnd(W) < dt * 0.3 || Math.abs(u.tx) > 90) u.tx = (rnd(W) - 0.5) * 120; walkTo(u, u.tx, 16, dt); }
          break;
        }
        case 'arc': arcStep(W, C, u, dt, tf, dark, eve, postOf[u.i]); break;
        case 'bld': bldStep(W, C, u, dt, tf, eve, jobs, asg); break;
        case 'far': {
          let f = u.job ? C.farms.find((q) => q.i === u.job && q.lv > 0) : null;
          if (!f) { u.job = 0; f = C.farms.filter((q) => q.lv > 0 && !q.job && fslots[q.i] < FARM.slots[q.lv]).sort((a, b) => Math.abs(a.x - u.x) - Math.abs(b.x - u.x))[0]; if (f) { u.job = f.i; fslots[f.i]++; } }
          if (f && !eve && tf >= 0.53) { // 해 지기 전 거두기
            const c = u.cc < 8 ? W.gc.find((q) => q.a > 0.5 && Math.abs(q.x - f.x) < 46) : null;
            if (c) { if (walkTo(u, c.x, 30, dt)) pickCoins(W, u, c.x, 6, 8); }
            else if (walkTo(u, 0, 30, dt)) { W.tc += u.cc; u.cc = 0; }
          } else if (eve || !f) {
            if (u.cc > 0) { if (walkTo(u, 0, 30, dt)) { W.tc += u.cc; u.cc = 0; } }
            else { if (Math.abs(u.x) > 80 || rnd(W) < dt * 0.2) u.tx = (rnd(W) - 0.5) * 100; walkTo(u, u.tx, 26, dt); }
          } else {
            const wx = f.x + (u.i % 2 ? 14 : -14) + Math.sin(W.t * 0.4 + u.i) * 12;
            u.wk = 0;
            if (walkTo(u, wx, 26, dt) || Math.abs(u.x - f.x) < 34) {
              u.wk = winter ? 0 : 1;
              if (!winter) { f.pt += dt; if (f.pt >= 6) { f.pt = 0; const n = W.gc.filter((c) => Math.abs(c.x - f.x) < 44).length; if (n < 6) { dropCoin(W, f.x + (rnd(W) - 0.5) * 50, 1, 4); fx(W, 'grow', f.x); } } }
            }
          }
          break;
        }
        case 'kni': {
          const si = u.sd < 0 ? 0 : 1, s = u.sd < 0 ? -1 : 1;
          if (u.sq && W.sq[si]) { kniAssault(W, C, u, dt, si); break; }
          const ow = C.outer[si];
          const px = (ow ? ow.x + s * (14 + kn[si] * 7) : s * (60 + kn[si] * 7)); kn[si]++;
          const foe = nearestEnemy(W, u.x, 22, (e) => e.t !== 'f' && e.st !== 2);
          if (foe) { u.dir = sgn(foe.x - u.x); if (u.cd <= 0) { u.cd = 0.8; hurt(W, foe, 1); } }
          else walkTo(u, px, 30, dt);
          if (u.hp <= 0) { W.tl.push({ x: u.x, t: 'shield' }); u.t = 'pea'; u.hp = 1; u.sq = 0; u.tx = 0; fx(W, 'fall', u.x); }
          break;
        }
        case 'deer': {
          const sx = u.home;
          const lim0 = W.reach[sx < 0 ? 0 : 1] + 30;
          let lure = null; for (const m of W.M) if ((MOUNTS[m.mt] || {}).lure && Math.abs(m.x - u.x) < 220 && !dark) lure = m;
          let threat = null; for (const a of W.u) if (a.t === 'arc' && Math.abs(a.x - u.x) < 70) threat = a;
          if (threat) { u.tx = u.x + sgn(u.x - threat.x) * 60; walkTo(u, u.tx, 48, dt); }
          else if (lure) { walkTo(u, lure.x - lure.dir * 30 + (u.i % 3 - 1) * 12, 40, dt); }
          else { if (rnd(W) < dt * 0.25) u.tx = sx * (lim0 + rnd(W) * Math.max(40, W.hw - 210 - lim0)); walkTo(u, u.tx, 12, dt); }
          u.x = clamp(u.x, -W.hw + 60, W.hw - 60);
          break;
        }
      }
    }
  }
  function pickCoins(W, u, cx, r, cap) {
    for (let j = W.gc.length - 1; j >= 0 && u.cc < cap; j--) { const c = W.gc[j]; if (c.a > 0.5 && Math.abs(c.x - cx) < r && Math.abs(c.x - u.x) < 12) { W.gc.splice(j, 1); u.cc++; } }
  }
  function nearestEnemy(W, x, r, f) { let b = null, bd = r; for (const e of W.e) { const d = Math.abs(e.x - x); if (d < bd && (!f || f(e))) { bd = d; b = e; } } return b; }
  function arcStep(W, C, u, dt, tf, dark, eve, post) {
    const si = u.sd < 0 ? 0 : 1, s = u.sd < 0 ? -1 : 1;
    if (u.sq && W.sq[si]) { // 돌격
      const P = W.P[si]; const gx = P.x - s * (120 + (u.i % 4) * 10);
      const foe = nearestEnemy(W, u.x, 220, (e) => e.st !== 2);
      walkTo(u, gx, 40, dt);
      if (u.cd <= 0) { if (foe) shoot(W, u, foe, 0); else if (Math.abs(u.x - gx) < 40) { u.cd = 1.7; W.ar.push({ x0: u.x, y0: 16, x1: P.x, y1: 40, t: 0, tf: 0.6, tg: -1 - si, a: 1 }); } }
      return;
    }
    if (eve) {
      if (u.cc > 0 && tf > 0.5 && tf < 0.66) { if (walkTo(u, 0, 40, dt)) { W.tc += u.cc; u.cc = 0; } return; }
      const p = post || { x: s * 60, tw: 0 };
      const there = walkTo(u, p.x, 40, dt);
      u.tw = there ? p.tw : 0;
      const rg = p.tw ? TOWER.range[p.tw] : 210;
      if (u.cd <= 0) { const foe = nearestEnemy(W, u.x, rg, (e) => e.st !== 3); if (foe) shoot(W, u, foe, u.tw); }
      return;
    }
    u.tw = 0;
    if (u.cc > 0 && W.M.some((m) => Math.abs(m.x - u.x) < 160)) { const m = W.M.reduce((a, b) => (Math.abs(b.x - u.x) < Math.abs(a.x - u.x) ? b : a)); walkTo(u, m.x, 34, dt); }
    // 사냥
    let deer = null, bd = 1e9;
    for (const d of W.u) if (d.t === 'deer' && sgn(d.x) === s) { const dd = Math.abs(d.x - u.x); if (dd < bd) { bd = dd; deer = d; } }
    pickCoins(W, u, u.x, 30, 6);
    if (deer && u.cc < 6) {
      if (bd > 150) walkTo(u, deer.x - sgn(deer.x - u.x) * 120, 34, dt);
      else { u.dir = sgn(deer.x - u.x); if (u.cd <= 0) shoot(W, u, deer, 0); }
      const near = W.gc.find((c) => c.a > 0.6 && sgn(c.x) === s && Math.abs(c.x - u.x) < 260);
      if (near && bd > 120) walkTo(u, near.x, 36, dt);
    } else {
      const near = W.gc.find((c) => c.a > 0.6 && sgn(c.x) === s && Math.abs(c.x) > 150 && Math.abs(c.x - u.x) < 300);
      if (near) walkTo(u, near.x, 36, dt);
      else { const ow = C.outerB[si]; const gx = s * ((ow ? ow.d : 120) + 50 + (u.i % 5) * 18); if (rnd(W) < dt * 0.2) u.tx = gx + (rnd(W) - 0.5) * 60; walkTo(u, u.tx || gx, 22, dt); }
    }
  }
  function shoot(W, u, tg, tw) {
    const d = Math.abs(tg.x - u.x);
    const tf = 0.3 + d / 430;
    const lead = tg.t === 'deer' ? 0 : (tg.st === 2 ? sgn(tg.home - tg.x) : -tg.s) * (ENEMY[tg.t] ? ENEMY[tg.t].spd : 0) * tf * (tg.st === 1 ? 0 : 1);
    const y1 = tg.t === 'f' ? tg.y : 12;
    W.ar.push({ x0: u.x, y0: tw ? 46 : 16, x1: tg.x + lead, y1, t: 0, tf, tg: tg.i, a: tw ? 0.78 : 0.66, dr: tg.t === 'deer' ? 1 : 0 });
    u.cd = 1.55 + rnd(W) * 0.35; u.dir = sgn(tg.x - u.x);
    fx(W, 'bow', u.x);
  }
  function arrowStep(W, C, dt) {
    for (let j = W.ar.length - 1; j >= 0; j--) {
      const a = W.ar[j]; a.t += dt;
      if (a.t < a.tf) continue;
      W.ar.splice(j, 1);
      if (a.tg < 0) { const P = W.P[-a.tg - 1]; if (P && P.al && rnd(W) < 0.85) hurtPortal(W, P, 1); continue; }
      if (a.dr) { const d = W.u.find((q) => q.i === a.tg); if (d && Math.abs(d.x - a.x1) < 16 && rnd(W) < a.a) { const k = W.u.indexOf(d); W.u.splice(k, 1); dropCoin(W, d.x, isWinter(W) ? 2 : 3, 14); fx(W, 'hunt', d.x); } continue; }
      const e = W.e.find((q) => q.i === a.tg);
      if (e && Math.abs(e.x - a.x1) < 16 && (e.t !== 'f' || Math.abs(e.y - a.y1) < 26) && rnd(W) < a.a) hurt(W, e, 1);
    }
  }
  function hurt(W, e, n) {
    e.hp -= n; e.hit = 0.2;
    if (e.hp <= 0) {
      const k = W.e.indexOf(e); if (k >= 0) W.e.splice(k, 1);
      W.ST.kl++;
      if (e.loot === 1) dropCoin(W, e.x, 1, 6);
      else if (e.loot >= 10) { W.cw.push({ x: e.x, s: e.loot - 10 }); fx(W, 'crowndrop', e.x, e.loot - 10); }
      else if (e.loot === 2 && e.lt) W.tl.push({ x: e.x, t: e.lt });
      fx(W, 'kill', e.x, e.t);
    }
  }
  function hurtPortal(W, P, n) {
    P.hp -= n; fx(W, 'phit', P.x);
    if (P.hp <= 0 && P.al) { P.al = 0; P.hp = 0; fx(W, 'portal', P.x, P.kind === 'c' ? 1 : 0); for (const e of W.e) if (e.home === P.x) e.st = 2; }
  }
  function kniAssault(W, C, u, dt, si) {
    const s = si ? 1 : -1, P = W.P[si];
    const foe = nearestEnemy(W, u.x, 24, (e) => e.st !== 2);
    if (foe) { u.dir = sgn(foe.x - u.x); if (u.cd <= 0) { u.cd = 0.8; hurt(W, foe, 1); } }
    else if (walkTo(u, P.x - s * (20 + (u.i % 3) * 8), 34, dt) || Math.abs(u.x - P.x) < 50) { W.sq[si].at = 1; u.dir = s; if (u.cd <= 0) { u.cd = 0.8; hurtPortal(W, P, 1); } }
    if (u.hp <= 0) { W.tl.push({ x: u.x, t: 'shield' }); u.t = 'pea'; u.hp = 1; u.sq = 0; u.tx = 0; fx(W, 'fall', u.x); }
  }
  function bldStep(W, C, u, dt, tf, eve, jobs, asg) {
    let j = u.job ? jobs.find((q) => q.o.i === u.job) : null;
    if (W.bm && !eve && tf < 0.5) {
      if (!u.bm && W.bm.b.length < 2) { u.bm = 1; W.bm.b.push(u.i); if (u.job) { asg[u.job] = Math.max(0, (asg[u.job] || 1) - 1); u.job = 0; } }
      if (u.bm) { walkTo(u, W.bm.x + 10 + Math.max(0, W.bm.b.indexOf(u.i)) * 9, 30, dt); return; }
    } else if (u.bm) { u.bm = 0; if (W.bm) W.bm.b = W.bm.b.filter((q) => q !== u.i); }
    if (!j) {
      if (u.job) { asg[u.job] = Math.max(0, (asg[u.job] || 1) - 1); u.job = 0; }
      let best = null, bs = -1e9;
      for (const q of jobs) { const n = asg[q.o.i] || 0; const sc = -Math.abs(q.x - u.x) / 320 - n * 1.6 + (q.rep ? (q.o.hp < q.o.mh * 0.5 ? 0.5 : -1.5) : 2) + (q.o.k === 'wall' ? 0.8 : q.o.k === 'boat' ? 1.6 : 0); if (n < 3 && sc > bs) { bs = sc; best = q; } }
      if (best) { u.job = best.o.i; asg[u.job] = (asg[u.job] || 0) + 1; j = best; }
    }
    if (!j) {
      // 빈손이면 모닥불 곁
      if (Math.abs(u.x) > 90 || rnd(W) < dt * 0.2) u.tx = (rnd(W) - 0.5) * 120;
      walkTo(u, u.tx, eve ? 34 : 20, dt);
      return;
    }
    const o = j.o, wx = o.x + ((u.i % 3) - 1) * 9;
    if (walkTo(u, wx, 32, dt) || Math.abs(u.x - o.x) < 16) {
      u.wk = 1;
      if (j.rep) { o.hp = Math.min(o.mh, o.hp + 2.5 * dt); if (o.hp >= o.mh) { u.job = 0; } }
      else if (o.job) {
        o.job.done += dt;
        if (o.job.done >= o.job.need) {
          o.lv = o.job.to; o.br = 0;
          if (o.k === 'wall') { o.mh = WALL.hp[o.lv]; o.hp = o.mh; W.ST.wb++; }
          o.job = null; u.job = 0; fx(W, 'built', o.x, o.k);
          if (o.k === 'boat' && o.lv >= 3) fx(W, 'boatready', o.x);
        }
      }
    } else u.wk = 0;
  }
  function bombStep(W, C, dt) {
    const b = W.bm; if (!b) return;
    const tf = tfOf(W), cliff = W.P[2];
    if (!cliff.al) { W.bm = null; return; }
    b.b = b.b.filter((id) => W.u.some((u) => u.i === id && u.t === 'bld' && u.bm));
    const pushers = W.u.filter((u) => u.bm && u.t === 'bld' && Math.abs(u.x - b.x) < 24);
    if (pushers.length >= 2 && tf > 0.04 && tf < 0.58) { b.go = 1; b.x -= BOMB.spd * dt; for (const u of pushers) u.x = b.x + 10 + W.bm.b.indexOf(u.i) * 9; }
    else b.go = 0;
    if (b.x <= cliff.x + 30) { hurtPortal(W, cliff, 99); fx(W, 'boom', cliff.x); for (const u of W.u) if (u.bm) u.bm = 0; W.bm = null; }
  }

  /* ----- 탐욕 ----- */
  function enemyStep(W, C, dt) {
    const tf = tfOf(W), day = tf > 0.03 && tf < 0.66;
    for (let j = W.e.length - 1; j >= 0; j--) {
      const e = W.e[j]; if (!W.e[j]) continue;
      const E = ENEMY[e.t]; e.cd -= dt; if (e.hit) e.hit = Math.max(0, e.hit - dt);
      if (day && !e.df && e.st !== 2) e.st = 2;
      if (e.st === 2) { // 달아남
        const spd = E.spd * 1.5 * (e.t === 'r' ? 1.6 : 1);
        e.x += sgn(e.home - e.x) * spd * dt; e.dir = sgn(e.home - e.x);
        if (e.t === 'f') e.y = Math.min(90, e.y + 20 * dt);
        if (Math.abs(e.home - e.x) < 6 || (day && tf > 0.16 && tf < 0.6)) {
          W.e.splice(j, 1);
          if (e.loot >= 10) { W.over = { win: 0, why: 'crown', s: e.loot - 10 }; fx(W, 'crownlost', e.x, e.loot - 10); }
        }
        continue;
      }
      if (e.df) { defStep(W, C, e, dt); continue; }
      const s = e.s;
      if (e.t === 'f') { flyStep(W, C, e, dt); continue; }
      // 성벽
      const w = blockAhead(C, s, e.x);
      // 기사
      const kn = nearestUnit(W, e.x, 14, (u) => u.t === 'kni' && !wallBetweenX(C, s, u.x, e.x));
      if (kn) { e.st = 1; if (e.cd <= 0) { e.cd = E.cd; kn.hp -= E.dmg >= 3 ? 2 : 1; fx(W, 'clash', kn.x); } continue; }
      if (w && s * e.x - s * w.x < 13) {
        e.st = 1;
        if (e.cd <= 0) { e.cd = E.cd; w.hp -= E.dmg; fx(W, 'whit', w.x, w.lv); if (w.hp <= 0) { w.hp = 0; w.br = 1; fx(W, 'wbreak', w.x); } }
        if (e.t === 'r') { e.sp -= dt; if (e.sp <= 0) { e.sp = 7; eAdd(W, 'g', e.x + s * 8, s, e.home); } }
        continue;
      }
      e.st = 0;
      // 군주
      let hitM = false;
      W.M.forEach((m, si2) => {
        if (hitM || Math.abs(m.x - e.x) > 12 || wallBetweenX(C, s, m.x, e.x)) return;
        if (m.inv > 0) return;
        hitM = true;
        if (!m.cr) return;
        if ((MOUNTS[m.mt] || {}).armor && m.ar) { m.ar = 0; m.inv = 1.4; fx(W, 'armor', m.x, si2); e.st = 2; return; }
        if (m.pu > 0) {
          m.pu--; e.loot = 1; const sc = Math.min(2, m.pu); m.pu -= sc; dropCoin(W, m.x, sc, 40); m.inv = 1.3; e.st = 2; fx(W, 'mhit', m.x, si2);
        } else {
          m.cr = 0; e.loot = 10 + si2; e.st = 2; m.inv = 2; fx(W, 'crown', m.x, si2);
        }
      });
      if (hitM) continue;
      // 백성
      const v = nearestUnit(W, e.x, 10, (u) => u.t !== 'vag' && u.t !== 'deer' && u.t !== 'kni' && !wallBetweenX(C, s, u.x, e.x));
      if (v) {
        const tool = TOOL_OF[v.t];
        if (tool) { W.tl.push({ x: v.x, t: tool }); v.t = 'pea'; v.cc = 0; v.job = 0; v.sq = 0; e.loot = 2; e.lt = 0; fx(W, 'grab', v.x, tool); }
        else if (v.t === 'pea') { v.t = 'vag'; v.home = W.camps[s < 0 ? 0 : 1]; v.tx = v.home; v.rc = 0; e.loot = 1; fx(W, 'grab', v.x, 'coin'); }
        e.st = 2; continue;
      }
      // 떨어진 왕관
      if (!e.loot && W.cw.length) { const ci = W.cw.findIndex((c) => Math.abs(c.x - e.x) < 8); if (ci >= 0) { e.loot = 10 + W.cw[ci].s; W.cw.splice(ci, 1); e.st = 2; fx(W, 'crown', e.x, e.loot - 10); continue; } }
      // 땅의 금화
      if (e.t === 'g' && !e.loot) { const ci = W.gc.findIndex((c) => Math.abs(c.x - e.x) < 8); if (ci >= 0) { W.gc.splice(ci, 1); e.loot = 1; e.st = 2; continue; } }
      // 앞으로(성벽 너머 없이 가까운 군주가 있으면 그쪽으로)
      let tgtX = 0;
      for (const m of W.M) if (m.cr && m.inv <= 0 && Math.abs(m.x - e.x) < 170 && !wallBetweenX(C, s, m.x, e.x)) { tgtX = m.x; break; }
      e.x += sgn(tgtX - e.x) * E.spd * dt; e.dir = sgn(tgtX - e.x);
      if (Math.abs(e.x) < 4) e.x = 4 * s;
    }
  }
  function blockAhead(C, s, x) { const si = s < 0 ? 0 : 1; let b = null; for (const w of C.wl[si]) if (w.lv > 0 && !w.br && s * w.x <= s * x + 0.5 && (!b || s * w.x > s * b.x)) b = w; return b; }
  function wallBetweenX(C, s, a, b) { const lo = Math.min(s * a, s * b), hi = Math.max(s * a, s * b); const si = s < 0 ? 0 : 1; for (const w of C.wl[si]) if (w.lv > 0 && !w.br && s * w.x > lo + 1 && s * w.x < hi - 1) return true; return false; }
  function nearestUnit(W, x, r, f) { let b = null, bd = r; for (const u of W.u) { const d = Math.abs(u.x - x); if (d < bd && f(u)) { bd = d; b = u; } } return b; }
  function flyStep(W, C, e, dt) {
    const si = e.s < 0 ? 0 : 1;
    let tg = null, bd = 1e9;
    for (const u of W.u) if (u.t === 'arc' && !u.sq && sgn(u.x) === e.s) { const d = Math.abs(u.x - e.x); if (d < bd) { bd = d; tg = u; } }
    const tx = tg ? tg.x : 0;
    e.x += sgn(tx - e.x) * ENEMY.f.spd * dt; e.dir = sgn(tx - e.x);
    e.y += ((tg ? 52 : 64) + Math.sin(W.t * 3 + e.i) * 5 - e.y) * dt * 2;
    if (tg && Math.abs(tg.x - e.x) < 7) { W.tl.push({ x: tg.x, t: 'bow' }); tg.t = 'pea'; tg.cc = 0; tg.tw = 0; e.loot = 2; e.st = 2; fx(W, 'grab', tg.x, 'bow'); }
    void si; void C;
  }
  function defStep(W, C, e, dt) {
    const foe = nearestUnit(W, e.x, 260, (u) => u.sq);
    if (!foe) { e.st = 2; return; }
    if (Math.abs(foe.x - e.x) < 11) {
      if (e.cd <= 0) { e.cd = 1; if (foe.t === 'kni') { foe.hp -= 1; fx(W, 'clash', foe.x); } else { W.tl.push({ x: foe.x, t: TOOL_OF[foe.t] || 'bow' }); foe.t = 'pea'; foe.sq = 0; foe.cc = 0; e.st = 2; e.loot = 2; fx(W, 'grab', foe.x, 'bow'); } }
    } else { e.x += sgn(foe.x - e.x) * ENEMY.g.spd * dt; e.dir = sgn(foe.x - e.x); }
  }

  /* ----- 출항 ----- */
  function finishSail(W) {
    const clean = W.sail && W.sail.clean;
    W.ST.isl++;
    if (W.k + 1 >= W.nI) { W.over = { win: 1, why: clean ? 'clean' : 'sail' }; fx(W, 'win', 0); return; }
    // 데려갈 사람: 궁수 → 일꾼 → 기사 → 농부(백성으로)
    const lim = clean ? 12 : 8;
    const order = ['bld', 'arc', 'bld', 'arc', 'arc', 'bld', 'kni', 'arc', 'arc', 'kni', 'far', 'far', 'pea'];
    const pool = {}; for (const u of W.u) pool[u.t] = (pool[u.t] || 0) + 1;
    const carry = [];
    for (let r = 0; r < 4 && carry.length < lim; r++) for (const t of order) if (carry.length < lim && pool[t] > 0) { pool[t]--; carry.push(t === 'far' ? 'pea' : t); }
    if (clean) W.M.forEach((m) => give(W, m, 5));
    startIsland(W, W.k + 1, carry);
  }

  /* ======================= AI 군주 =======================
     정해진 순서 없이, 매번 상황 점수(경제·방어·확장·위험) + 판 시드로 정한 버릇(seat·섬마다) + 수준별 흔들림으로 고른다. */
  function habits(W, s) {
    const R = mkRand((W.sd * 131 + s * 977 + W.k * 31) | 0);
    return { exp: 0.75 + R() * 0.55, def: 0.75 + R() * 0.55, eco: 0.75 + R() * 0.55, arch: 0.8 + R() * 0.5, bold: R(), boat: 0.7 + R() * 0.6, ride: R() };
  }
  function aiInput(W, s, lv, mem, mems) {
    const m = W.M[s];
    if (!mem.h || mem.hk !== W.k) { mem.h = habits(W, s); if (lv === 1) { mem.h.def *= 0.6; mem.h.boat *= 0.8; } mem.hk = W.k; mem.tg = null; mem.nt = 0; }
    if (W.trans > 0 || W.over) return { ax: 0, gal: 0, hold: 0 };
    const C = ctxOf(W), tf = tfOf(W), hb = mem.h;
    mem.nt -= H;
    // 위험: 가까운 탐욕
    let threat = null, td = lv === 1 ? 70 : lv === 2 ? 130 : 170;
    for (const e of W.e) { if (e.st === 2 && !e.loot) continue; const d = Math.abs(e.x - m.x); if (d < td && !wallBetweenX(C, e.s, m.x, e.x)) { td = d; threat = e; } }
    if (threat && (lv > 1 || rnd(W) < 0.35)) {
      mem.tg = null;
      // 왕관 도둑 쫓기(협동: 남의 왕관)
      if (threat.loot >= 10 && m.cr && threat.loot - 10 !== s) return { ax: sgn(threat.x - m.x), gal: 1, hold: 0 };
      return { ax: sgn(m.x - threat.x) * (Math.abs(m.x) < 12 ? 0 : 1) || -sgn(m.x), gal: m.sta > 0.15 ? 1 : 0, hold: 0 };
    }
    // 떨어진 왕관
    const myc = W.cw.find((c) => m.cr || c.s === s);
    if (myc) return { ax: Math.abs(myc.x - m.x) < 3 ? 0 : sgn(myc.x - m.x), gal: 1, hold: 0 };
    if (!m.cr) return { ax: Math.abs(m.x) > 20 ? -sgn(m.x) : 0, gal: 0, hold: 0 };
    const paying = m.mk && mem.tg && mem.tg.pay === m.mk && m.pu > 0;
    if (!paying && (!mem.tg || mem.nt <= 0 || mem.tg.done)) { mem.tg = aiPick(W, C, s, lv, mem, tf, mems && mems[1 - s]); mem.nt = lv === 1 ? 1.3 : lv === 2 ? 0.8 : 0.5; }
    const g = mem.tg;
    if (!g) return { ax: 0, gal: 0, hold: 0 };
    const dx = g.x - m.x, far = Math.abs(dx);
    let ax = far < (g.pay ? 6 : 4) ? 0 : sgn(dx) * (far < 20 ? 0.5 : 1);
    const gal = far > 150 && m.sta > (lv === 1 ? 0.05 : 0.35 + hb.ride * 0.2);
    let hold = 0;
    if (g.pay && far < 14) {
      ax = 0;
      const t = findTarget(W, C, g.pay);
      let c = 0, paid = 0;
      if (t) { if (t.vag) c = t.vag.t === 'vag' ? 1 : 0; else if (t.k === 'asl') { c = 3; paid = W.aslPaid ? W.aslPaid[t.si] : 0; } else { c = costOf(W, C, t); paid = t.paid || 0; } }
      if (t && !t.vag && t.k === 'boat' && t.lv >= 3 && !canStand(W, t, m)) c = 0;
      if (!c || m.lock > 0) { mem.tg = null; mem.nt = 0; }
      else if (m.pu < c - paid && (lv > 1 || m.pu === 0)) { mem.tg = null; mem.nt = 0; }
      else hold = 1;
    }
    if (g.coin) { if (far < 6) mem.tg = null; }
    return { ax, gal: gal ? 1 : 0, hold };
  }
  function aiPick(W, C, s, lv, mem, tf, otherMem) {
    const m = W.M[s], hb = mem.h, cnt = C.cnt, town = C.town;
    const noise = lv === 1 ? 0.45 : lv === 2 ? 0.16 : 0.06;
    if (mem.cd !== W.day) { mem.cd = W.day; mem.care = lv === 1 && rnd(W) < 0.3 + hb.bold * 0.2; }   // 쉬움: 어떤 날은 해가 져도 밖에 머묾
    const late = lv === 1 ? (mem.care ? 0.92 : 0.65 + hb.bold * 0.09) : lv === 2 ? 0.58 : 0.555;
    const dark = tf >= late || tf < 0.025;
    const cands = [];
    const add = (x, v, o) => {
      if (v <= 0) return;
      const dist = Math.abs(x - m.x);
      let sc = v - dist / (lv === 3 ? 480 : lv === 2 ? 420 : 360);
      if (dark && !insideOK(C, x)) return;
      if (otherMem && otherMem.tg && Math.abs(otherMem.tg.x - x) < 30 && W.M.length > 1) sc -= 2.5;
      sc *= 1 + (rnd(W) * 2 - 1) * noise;
      cands.push(Object.assign({ x, sc }, o));
    };
    const pu = m.pu, cap = capOf(m);
    // 금화 줍기
    if (pu < cap) {
      for (const c of W.gc) if (c.a > 0.3) add(c.x, 1.6, { coin: 1 });
      if (W.tc > 0) add(0, 1.2 + W.tc * 0.8, { coin: 1 });
      for (const c of W.ch) if (!c.op) add(c.x, 2.5 + c.c * 0.6, { coin: 1 });
      for (const u of W.u) if (u.cc > 0) add(u.x, 1 + u.cc * 0.8, { coin: 1 });
    }
    const day = W.day, bmSoon = (W.day + 1) % (BM_EVERY[Math.min(W.k, BM_EVERY.length - 1)]) === 0 || W.bmn;
    const arcWant = 2 + Math.round(W.day * 0.55 * hb.arch) + W.k;
    const nJobs = W.S.filter((o) => o.job).length, boatJob = C.boat && C.boat.job;
    const bldWant = Math.min(6, 2 + Math.ceil(nJobs / 1.5) + (boatJob || (C.boat && C.boat.lv > 0 && C.boat.lv < 3) ? 2 : 0) + (day > 6 ? 1 : 0));
    const farmSlots = C.farms.reduce((a, f) => a + FARM.slots[f.lv], 0);
    const needTool = { bow: arcWant - cnt.arc, hammer: bldWant - cnt.bld, scythe: farmSlots - cnt.far, shield: (town.lv >= 2 ? (lv === 3 ? 4 : 2) : 0) - cnt.kni };
    const spare = cnt.pea;
    const rackSum = Object.values(C.shop).reduce((a, sh) => a + sh.rack, 0);
    const threatN = (1.2 + 0.75 * day + 1.1 * W.k) * W.df * (bmSoon ? 2 : 1);
    // 표시들
    const want = { v: 0, c: 0 }, spend = [];
    for (const o of W.S) {
      const c = costOf(W, C, o);
      if (o.k === 'boat' && o.lv >= 3 && !W.sail) { const tf2 = tfOf(W); if (tf2 > 0.04 && tf2 < 0.58) add(o.x, 40, c && pu >= c ? { pay: o.i } : { idle: 1 }); continue; }
      if (!c) continue;
      const afford = pu - c;
      let v = 0;
      switch (o.k) {
        case 'town': v = o.lv === 0 ? 10 : o.lv === 1 ? 4.5 + day * 0.35 : 1.5 + day * 0.18 + (W.P[0].al && !W.P[2].al ? 0 : 0); break;
        case 'wall': {
          const si = sideIdx(o.x), ow = C.outerB[si];
          if (o.br) v = 12 * hb.def;
          else if (o.lv === 0) { v = (ow ? 0 : 9) + (ow && o.d > ow.d ? 3.5 * hb.exp - (o.d - ow.d) / 200 : 0); if (ow && o.d < ow.d) v = 1; if (C.posts && cnt.arc < 2 && ow) v -= 2; }
          else { const outer = ow && o.i === ow.i; v = outer ? (2.5 + threatN * 0.35 - o.lv * 1.2) * hb.def : 0.8; if (bmSoon && outer) v += 3; }
          break;
        }
        case 'tower': v = (cnt.arc >= 3 ? 3.2 : 1) * hb.def - o.lv * 0.6 + (C.outer[sideIdx(o.x)] && o.d < C.outer[sideIdx(o.x)].d ? 1 : -2); break;
        case 'farm': v = (o.lv === 0 ? 5.5 : 3) * hb.eco - (insideWalls(C, o.x) ? 0 : 1.5) + (day < 3 ? -1 : 0); break;
        case 'shop': { const need = needTool[o.t] - o.rack; v = need > 0 ? (o.t === 'bow' ? 6 * hb.arch : o.t === 'hammer' ? 6.5 : o.t === 'scythe' ? 5 * hb.eco : 4.5 * hb.def) + Math.min(2, need) : 0; if (rackSum >= spare + 3 && o.t !== 'hammer') v -= 3; if (o.t === 'bow' && cnt.arc + o.rack < 2) v += 5; break; }
        case 'boat': {
          const ready = cnt.arc >= 3 + W.k && town.lv >= 1 && day >= 3;
          v = ready ? (5 + day * 0.9 + W.k * 2) * hb.boat + o.lv * 3 : 0; break;
        }
        case 'bomb': v = !W.P[0].al ? 7 : 0; break;
        case 'mount': v = (o.t === 'courser' || o.t === 'draft' ? 2.4 : o.t === 'barded' ? 2.8 : 2) * (0.5 + hb.ride) - (m.mt !== 'steed' ? 3 : 0); break;
      }
      const reachable = !dark || insideOK(C, o.x);
      if (afford < 0 || !reachable) { if (v > want.v) { want.v = v; want.c = c; } if (!reachable || lv > 1 || rnd(W) < 0.5) continue; }
      spend.push([o.x, v, { pay: o.i }, c]);
    }
    // 모으는 중이면(더 큰 목표) 작은 지출은 줄임 — 어려움일수록 잘 참음
    const bestSpend = spend.reduce((a, q) => Math.max(a, q[1]), 0);
    const saving = lv > 1 && want.v > bestSpend * (lv === 3 ? 1.1 : 1.35);
    const flush = pu >= cap - 3 ? 1.4 : 1;
    for (const q of spend) { let v = q[1] * flush; if (saving && v < want.v * 0.75 && pu - q[3] < want.c) v *= lv === 3 ? 0.35 : 0.6; add(q[0], v, q[2]); }
    if (saving) { for (const c of W.gc) if (c.a > 0.3) add(c.x, 1.2, { coin: 1 }); }
    for (const si of [0, 1]) { const a = aslSpot(W, C, si); if (a && pu >= 3) { const ks = C.side.kni[si]; add(a.x, ks >= 2 + (lv === 3 ? 0 : 1) ? 6 + ks : 0, { pay: a.i }); } }
    // 떠돌이
    if (pu >= 1) {
      const want = Math.max(0, rackSum - spare) * 3 + (cnt.pea + cnt.arc + cnt.bld + cnt.far + cnt.kni < 4 + day ? 3 : 0.8);
      for (const u of W.u) if (u.t === 'vag') add(u.x, want, { pay: 100000 + u.i });
    }
    // 밤에는 안쪽에서 대기
    if (dark) add(s ? 14 : -14, 0.6, { idle: 1 });
    else add(m.x + (rnd(W) - 0.5) * 40, 0.15, { idle: 1 });
    if (!cands.length) return { x: dark ? (s ? 12 : -12) : m.x, idle: 1 };
    const cur = mem.tg;
    if (cur && !cur.idle) for (const c of cands) if ((cur.pay && c.pay === cur.pay) || (cur.coin && c.coin && Math.abs(c.x - cur.x) < 12)) { c.sc += lv === 1 ? 0.6 : 1.4; break; }
    cands.sort((a, b) => b.sc - a.sc);
    return cands[0];
  }
  function insideOK(C, x) { return insideWalls(C, x) || Math.abs(x) < 90; }

  /* ======================= 결과 ======================= */
  function init(players, opts) {
    const o = opts || {};
    const nI = [1, 3, 5].indexOf(+o.isl) >= 0 ? +o.isl : o.isl === 'trial' ? 0 : 3;
    const D = PACE[o.pace] || PACE.norm;
    const df = DIFF[o.diff] || DIFF.mid;
    return { rid: 1 + U.rand(999999), sd: 1 + U.rand(2147483000), n: players.length, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), nI, D, df, ph: 'play', res: null, day: 1, isl: 0 };
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !s.res) return null;
    const r = s.res, ST = r.ST || {}, n = s.n || 1, all = Array.from({ length: n }, (_, i) => i);
    const trial = !s.nI;
    const total = trial ? 1 : s.nI;
    const title = r.win ? (r.why === 'clean' ? '마지막 섬을 정화함' : trial ? '연습 섬을 떠남' : '마지막 섬을 떠남') : '왕관을 잃음';
    const where = (trial ? '연습 섬' : isleName(r.k)) + ' · ' + dayName(r.day);
    const text = r.win ? where + '\n바다를 건넌 섬 ' + (ST.isl || 0) + ' / ' + total : where + '에서 왕관이 균열 너머로 사라짐\n바다를 건넌 섬 ' + (ST.isl || 0) + ' / ' + total;
    const hl = [];
    if (ST.cl) hl.push('균열을 모두 닫은 섬 ' + ST.cl);
    if (ST.nt) hl.push('버틴 밤 ' + ST.nt);
    return {
      winners: r.win ? all : [], title, text, highlights: hl,
      stats: [
        { label: '건넌 섬', value: (ST.isl || 0) + ' / ' + total }, { label: '버틴 밤', value: String(ST.nt || 0) },
        { label: '거둔 금화', value: String(ST.cn || 0) }, { label: '모은 백성', value: String(ST.rc || 0) },
        { label: '쌓은 성벽', value: String(ST.wb || 0) }, { label: '물리친 탐욕', value: String(ST.kl || 0) },
      ],
    };
  }
  function resOf(W) { return { win: W.over && W.over.win ? 1 : 0, why: W.over ? W.over.why : '', k: W.k, day: W.day, ST: Object.assign({}, W.ST) }; }

  /* ======================= 그리기 자료 ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const MT_LIST = ['steed', 'courser', 'draft', 'barded', 'stag'];
  const UT_LIST = ['vag', 'pea', 'arc', 'bld', 'far', 'kni', 'deer'];
  const ET_LIST = ['g', 'c', 'r', 'f'];
  const TL_LIST = ['bow', 'hammer', 'scythe', 'shield', 'coin'];
  // 하늘 열쇠 장면 [tf, 위, 아래, 빛 세기]
  const SKY = [
    [0.00, '#10131d', '#2a2b36', 0.15], [0.05, '#2c3040', '#a08a80', 0.55], [0.12, '#5d7383', '#c2bdb0', 0.9],
    [0.45, '#6b8394', '#c8ccc6', 1], [0.57, '#56607a', '#c7a682', 0.85], [0.64, '#2f2c44', '#a8704f', 0.55],
    [0.70, '#141625', '#3a3240', 0.25], [0.80, '#0a0d17', '#1b2030', 0.12], [0.97, '#0b0e18', '#1c2130', 0.12], [1.0, '#10131d', '#2a2b36', 0.15],
  ];
  const SKY_BM = [['#1a0a0c', '#47161a'], ['#140708', '#2e0f12']];
  const SEASON_COL = [ // 풀, 나무, 잎, 먼 숲
    { gr: '#56643f', tr: '#2b3628', lf: '#3e4c34', fz: '#33402f' },
    { gr: '#4a5a35', tr: '#253224', lf: '#34452c', fz: '#2c3a2a' },
    { gr: '#6b5f3b', tr: '#2c2c22', lf: '#7a5a31', fz: '#4a3f2c' },
    { gr: '#b9bdbb', tr: '#262d2a', lf: '#3a423d', fz: '#4a524f' },
  ];
  function hex(c) { const n = parseInt(c.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
  function mix(a, b, t) { const A = typeof a === 'string' ? hex(a) : a, B = typeof b === 'string' ? hex(b) : b; return 'rgb(' + Math.round(A[0] + (B[0] - A[0]) * t) + ',' + Math.round(A[1] + (B[1] - A[1]) * t) + ',' + Math.round(A[2] + (B[2] - A[2]) * t) + ')'; }
  function mixA(a, b, t) { const A = typeof a === 'string' ? hex(a) : a, B = typeof b === 'string' ? hex(b) : b; return [A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]; }
  function rgb(A, a) { return a == null ? 'rgb(' + (A[0] | 0) + ',' + (A[1] | 0) + ',' + (A[2] | 0) + ')' : 'rgba(' + (A[0] | 0) + ',' + (A[1] | 0) + ',' + (A[2] | 0) + ',' + a + ')'; }
  function skyAt(tf, bm) {
    let i = 0; while (i < SKY.length - 2 && SKY[i + 1][0] <= tf) i++;
    const A = SKY[i], B = SKY[i + 1], k = clamp((tf - A[0]) / Math.max(1e-6, B[0] - A[0]), 0, 1);
    let top = mixA(A[1], B[1], k), bot = mixA(A[2], B[2], k); const lit = A[3] + (B[3] - A[3]) * k;
    if (bm) { const night = clamp((tf - 0.6) / 0.1, 0, 1) * (tf > 0.98 ? 0 : 1); top = mixA(top, SKY_BM[0][0], night * 0.8); bot = mixA(bot, SKY_BM[0][1], night * 0.85); }
    return { top, bot, lit };
  }
  const darkOf = (tf) => { if (tf < 0.04) return 0.45 - tf * 6; if (tf < 0.58) return 0; if (tf < 0.7) return (tf - 0.58) / 0.12 * 0.48; if (tf < 0.97) return 0.48; return 0.48 - (tf - 0.97) / 0.03 * 0.03; };
  function ridge(x, sd, a1, a2, a3) { return a1 * Math.sin(x * 0.0021 + sd) + a2 * Math.sin(x * 0.0057 + sd * 1.7) + a3 * Math.abs(Math.sin(x * 0.0123 + sd * 2.3)) + a3 * 0.45 * Math.abs(Math.sin(x * 0.031 + sd * 0.7)); }
  function hash(n) { n = (n ^ 61) ^ (n >>> 16); n = n + (n << 3); n = n ^ (n >>> 4); n = Math.imul(n, 0x27d4eb2d); n = n ^ (n >>> 15); return (n >>> 0) / 4294967296; }

  /* ======================= 소리(합성) ======================= */
  const Snd = {
    ac: null,
    get() { if (!this.ac) { try { this.ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { this.ac = null; } } if (this.ac && this.ac.state === 'suspended') { try { this.ac.resume(); } catch (e) {} } return this.ac; },
    vol() { return (L.audio && L.audio.sfx ? L.audio.sfx() : 1); },
    tone(f, d, type, v, f2, at) {
      const ac = this.get(), vv = this.vol() * v; if (!ac || vv <= 0) return;
      try {
        const t = ac.currentTime + (at || 0), o = ac.createOscillator(), g = ac.createGain();
        o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vv, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
        o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + d + 0.02);
      } catch (e) {}
    },
    noise(d, fq, v, at) {
      const ac = this.get(), vv = this.vol() * v; if (!ac || vv <= 0) return;
      try {
        const t = ac.currentTime + (at || 0), n = Math.max(1, Math.floor(ac.sampleRate * d)), b = ac.createBuffer(1, n, ac.sampleRate), da = b.getChannelData(0);
        for (let i = 0; i < n; i++) da[i] = (Math.random() * 2 - 1) * (1 - i / n);
        const s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        s.buffer = b; f.type = 'bandpass'; f.frequency.value = fq; f.Q.value = 1.2; g.gain.value = vv;
        s.connect(f); f.connect(g); g.connect(ac.destination); s.start(t);
      } catch (e) {}
    },
    coin() { const p = 1 + (Math.random() - 0.5) * 0.06; this.tone(2350 * p, 0.09, 'sine', 0.05); this.tone(3480 * p, 0.12, 'sine', 0.03, 0, 0.012); },
    pick() { const p = 1 + (Math.random() - 0.5) * 0.08; this.tone(2900 * p, 0.05, 'sine', 0.025); },
    bow() { this.tone(210, 0.07, 'triangle', 0.025, 140); this.noise(0.05, 2400, 0.012); },
    knock() { this.tone(160, 0.07, 'sine', 0.08, 90); this.noise(0.04, 900, 0.03); },
    horn(bm) { const f = bm ? 98 : 110; this.tone(f, 1.6, 'sawtooth', 0.018, f * 0.98); this.tone(f * 1.5, 1.4, 'sine', 0.02, f * 1.49, 0.05); },
    bell() { this.tone(660, 1.4, 'sine', 0.03, 655); this.tone(990, 1.1, 'sine', 0.014, 985, 0.01); },
    boom() { this.tone(70, 0.8, 'sine', 0.12, 35); this.noise(0.6, 300, 0.05); },
  };

  /* ======================= 뷰 ======================= */
  const CSS = `
  .cr-ui{position:absolute;inset:0;pointer-events:none;z-index:5}
  .cr-b{position:absolute;pointer-events:auto;width:62px;height:62px;border-radius:16px;border:1.5px solid rgba(214,180,110,.55);background:rgba(12,12,18,.58);
    color:#f3ead8;display:flex;flex-direction:column;gap:1px;align-items:center;justify-content:center;touch-action:none;-webkit-user-select:none;user-select:none;padding:0;transform-origin:center;
    box-shadow:0 2px 10px rgba(0,0,0,.35);-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}
  .cr-b svg{width:30px;height:30px}
  .cr-b.on{background:rgba(214,180,110,.34);border-color:rgba(236,200,130,.95);transform:scale(.96)}
  .cr-bl{font:600 12px/1 ${FONT};color:#ead9b0;letter-spacing:.02em;pointer-events:none}
  .cr-b.gal{box-shadow:0 0 0 2px rgba(214,180,110,.45) inset}
  .cr-c{border-radius:50%;width:72px;height:72px}
  .cr-c svg{width:30px;height:30px}
  .cr-tip{position:absolute;background:rgba(10,10,14,.6);border:1px solid rgba(214,180,110,.26);
    border-radius:12px;padding:8px 12px;color:#f3ead8;font:13px/1.55 ${FONT};pointer-events:auto;box-sizing:border-box;background:rgba(10,10,14,.8)}
  .cr-tip b{color:#d9b871;font-weight:600}
  `;
  const SVG_L = '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const SVG_R = '<svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const SVG_C = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.2" fill="none" stroke="#d6b46e" stroke-width="1.8"/><circle cx="12" cy="12" r="5.4" fill="none" stroke="#d6b46e" stroke-width="1" opacity=".6"/><path d="M12 8.6v6.8" stroke="#d6b46e" stroke-width="1.6" stroke-linecap="round"/></svg>';

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    cv.cv.style.touchAction = 'none';
    const styleEl = document.createElement('style'); styleEl.textContent = CSS; root.appendChild(styleEl);
    const ui = document.createElement('div'); ui.className = 'cr-ui'; root.appendChild(ui);
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', ai: true, lv: 2 };
    const host = () => !api.online || api.isHost;
    const me = () => { const m = api.mySeats ? api.mySeats() : []; return m.length ? m[0] : -1; };
    const isMine = (s) => s >= 0 && s === me();
    const auto = () => !!(L.debug && L.debug.autoplay);
    const fxAmt = () => (L.fx ? L.fx() : 1);
    let st = null, key = null, W = null, acc = 0;
    let mems = [{}, {}];
    let camX = 0, camInit = false, lastFq = 0, doneAt = 0, doneSent = false, lastSetDay = 0;
    let parts = [], flies = [], notes = [], tipEl = null, tipShown = false, isleCard = 0, isleCardK = -1;
    let G = null, pubT = 0, inQ = 0, hsQ = 0, lastQ = -1;
    let rem = {};
    const disp = new Map();
    let realNow = 0, lastNow = 0, flash = 0, shake = 0;
    const sdSky = 1.7;

    /* ----- 조작 ----- */
    const inp = { l: 0, r: 0, gal: 0, coin: 0, upT: { l: -9, r: -9 }, kbGalT: { l: -9, r: -9 } };
    const btn = (cls, html, act) => { const b = document.createElement('button'); b.className = 'cr-b lounge-ctl ' + cls; b.innerHTML = html + (act === 'coin' ? '<span class="cr-bl">금화</span>' : ''); b.setAttribute('data-action', act); b.setAttribute('aria-label', act === 'left' ? '왼쪽' : act === 'right' ? '오른쪽' : '금화 내기'); ui.appendChild(b); return b; };
    const bL = btn('cr-l', SVG_L, 'left'), bR = btn('cr-r', SVG_R, 'right'), bC = btn('cr-c', SVG_C, 'coin');
    function bindHold(el, on, off) {
      const ids = new Set();
      el.addEventListener('pointerdown', (e) => { e.preventDefault(); ids.add(e.pointerId); try { el.setPointerCapture(e.pointerId); } catch (x) {} Snd.get(); el.classList.add('on'); on(); });
      const up = (e) => { if (!ids.has(e.pointerId)) return; ids.delete(e.pointerId); if (!ids.size) { el.classList.remove('on'); off(); } };
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); el.addEventListener('lostpointercapture', up);
      el.addEventListener('contextmenu', (e) => e.preventDefault());
    }
    const nowS = () => performance.now() / 1000;
    bindHold(bL, () => { inp.l = 1; inp.gal = nowS() - inp.upT.l < 0.32 ? 1 : 0; dismissTip(); }, () => { inp.l = 0; inp.gal = 0; inp.upT.l = nowS(); });
    bindHold(bR, () => { inp.r = 1; inp.gal = nowS() - inp.upT.r < 0.32 ? 1 : 0; dismissTip(); }, () => { inp.r = 0; inp.gal = 0; inp.upT.r = nowS(); });
    bindHold(bC, () => { inp.coin = 1; dismissTip(); try { api.buzz(8, 'ui'); } catch (e) {} }, () => { inp.coin = 0; });
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      const t = nowS();
      if (type === 'down' && (id === 'left' || id === 'right')) { const k = id === 'left' ? 'l' : 'r'; inp.kbGal = t - inp.kbGalT[k] < 0.3 ? 1 : 0; dismissTip(); }
      if (type === 'up' && (id === 'left' || id === 'right')) { inp.kbGalT[id === 'left' ? 'l' : 'r'] = t; inp.kbGal = 0; }
      if (type === 'down') Snd.get();
    }) : () => {};
    const held = (id) => !!(api.input && api.input.held && api.input.held(id));
    function localInput() {
      let ax = (inp.r || held('right') ? 1 : 0) - (inp.l || held('left') ? 1 : 0);
      if (!ax && api.input && api.input.axis) { const a = api.input.axis('left', 'right'); if (Math.abs(a) > 0.25) ax = a; }
      const gal = inp.gal || inp.kbGal || held('gallop');
      return { ax, gal: gal ? 1 : 0, hold: inp.coin || held('coin') ? 1 : 0 };
    }
    function layoutCtl() {
      const w = cv.w, h = cv.h, land = w >= h, sc = (L.ui && L.ui.ctlScale ? L.ui.ctlScale() : 1);
      const pad = 14, bot = land ? 12 : 22, gap = 12 * sc;
      const bw = 62 * sc, cw = 72 * sc;
      [bL, bR].forEach((b) => { b.style.width = bw + 'px'; b.style.height = bw + 'px'; b.style.transform = 'none'; });
      bC.style.width = cw + 'px'; bC.style.height = cw + 'px'; bC.style.transform = 'none';
      bL.style.left = pad + 'px'; bL.style.bottom = bot + 'px';
      bR.style.left = (pad + bw + gap) + 'px'; bR.style.bottom = bot + 'px';
      bC.style.right = (pad + 4) + 'px'; bC.style.bottom = (bot - 4) + 'px';
      const show = me() >= 0 && !P(me()).ai && !auto();
      [bL, bR, bC].forEach((b) => { b.style.display = show ? 'flex' : 'none'; });
      if (tipEl) {
        if (land && w - (pad + 2 * bw + gap + 10) - (pad + cw + 14) >= 250) { tipEl.style.left = (pad + 2 * bw + gap + 10) + 'px'; tipEl.style.right = (pad + cw + 14) + 'px'; tipEl.style.bottom = bot + 'px'; }
        else { tipEl.style.left = '14px'; tipEl.style.right = '14px'; tipEl.style.bottom = (bot + cw + 12) + 'px'; }
      }
    }
    cv.onresize = () => { layoutCtl(); };
    const onCtl = () => layoutCtl(); window.addEventListener('lounge-ctl', onCtl);
    function showTip() {
      if (tipShown || me() < 0 || P(me()).ai || auto() || (L.debug && L.debug.noTut)) return;
      tipShown = true;
      tipEl = document.createElement('div'); tipEl.className = 'cr-tip';
      tipEl.innerHTML = '<b>◀ ▶</b> 누르고 있기: 말을 몲(두 번 눌러 질주)<br><b>금화</b> 누르고 있기: 가까운 표시에 금화를 냄<br>떠돌이에게 한 닢이면 백성 · 해가 지면 성벽 안으로';
      tipEl.addEventListener('pointerdown', dismissTip);
      ui.appendChild(tipEl); layoutCtl();
      setTimeout(dismissTip, 9000);
    }
    function dismissTip() { if (tipEl) { tipEl.remove(); tipEl = null; } }
    const onDownCanvas = () => { notes.length = 0; Snd.get(); };
    cv.cv.addEventListener('pointerdown', onDownCanvas);
    const noCtx = (e) => e.preventDefault(); cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- 세계 준비 ----- */
    function curKey() { return st ? st.rid + '.' + st.sd : null; }
    function build() {
      W = newRun({ n: st.n, sd: st.sd, nI: st.nI || 1, D: st.D, df: st.df, trial: !st.nI });
      acc = 0; mems = [{}, {}]; lastFq = W.fq; doneAt = 0; doneSent = false; camInit = false; disp.clear(); G = null; lastQ = -1; parts = []; flies = []; notes = [];
      isleCard = 2.4; isleCardK = 0;
      if (L.debug) L.debug.crownW = () => W;   // 시험 도구용(사람 조작 점검)
    }

    /* ----- 방장: 시뮬 ----- */
    function simStep() {
      const IN = W.M.map((m, s) => {
        const p = P(s);
        if (p.ai) return aiInput(W, s, p.lv || 2, mems[s], mems);
        if (isMine(s)) return auto() ? aiInput(W, s, 2, mems[s], mems) : localInput();
        const r = rem[s];
        if (api.online && r && r.k === key) return { ext: 1, x: r.x, dir: r.d, g: r.g, hold: r.h, sta: r.st };
        return { ax: 0, hold: 0 };
      });
      stepWorld(W, IN, H);
    }
    function hostFlow(now) {
      if (!W) return;
      if (W.over) {
        if (!doneAt) doneAt = now;
        if (!doneSent && now - doneAt > 2600) { doneSent = true; try { api.setState(Object.assign({}, st, { ph: 'done', res: resOf(W), day: W.day, isl: W.k })); } catch (e) { console.error(e); } }
        return;
      }
      if ((W.day !== st.day || W.k !== st.isl) && now - lastSetDay > 1500) { lastSetDay = now; try { api.setState(Object.assign({}, st, { day: W.day, isl: W.k })); } catch (e) {} }
    }
    /* ----- 온라인 ----- */
    const ri = (v) => Math.round(v);
    function packHost() {
      return {
        k: key, q: hsQ, t: Math.round(W.t * 100) / 100, I: W.k, d: W.day, b: W.bmn, sl: W.sail ? r1(W.sail.t) : 0, tr: W.trans > 0 ? r1(W.trans) : 0, o: W.over || 0, tc: W.tc, r: W.reach.map(ri), ap: W.aslPaid || 0, tri: W.trial ? 1 : 0,
        m: W.M.map((m) => [r1(m.x), m.dir, m.g, MT_LIST.indexOf(m.mt), m.pu, m.cr, ri(m.sta * 100), m.mk ? 1 : 0, m.inv > 0 ? 1 : 0, m.hold ? 1 : 0]),
        S: W.S.map((o) => [o.lv, o.br, o.mh ? ri(o.hp / o.mh * 100) : 0, o.job ? ri(o.job.done / o.job.need * 100) : -1, o.paid, o.rack, o.k === 'mount' ? MT_LIST.indexOf(o.t) : 0]),
        u: W.u.map((u) => [u.i, UT_LIST.indexOf(u.t), ri(u.x), u.dir, (u.mv ? 1 : 0) | (u.wk ? 2 : 0) | ((u.tw || 0) << 2) | (u.cc > 0 ? 16 : 0) | (u.sq ? 32 : 0) | (u.bm ? 64 : 0)]),
        e: W.e.map((e) => [e.i, ET_LIST.indexOf(e.t), ri(e.x), ri(e.y), e.dir || 0, e.st, e.loot >= 10 ? 3 : e.loot, e.hit > 0 ? 1 : 0, e.df ? 1 : 0]),
        g: W.gc.map((c) => [ri(c.x), c.a < 0.45 ? 1 : 0, c.i % 997]),
        a: W.ar.map((a) => [ri(a.x0), a.y0, ri(a.x1), a.y1, ri(a.t / a.tf * 100)]),
        p: W.P.map((p) => [p.al, ri(p.hp / p.mh * 100)]),
        c: W.ch.map((c) => c.op), tl: W.tl.map((t) => [ri(t.x), TL_LIST.indexOf(t.t)]), cw: W.cw.map((c) => [ri(c.x), c.s]), bm: W.bm ? [ri(W.bm.x), W.bm.go] : 0,
        f: W.fx.slice(-14),
      };
    }
    function unpackGuest(hs) {
      if (hs.I !== W.k) { const keepM = W.M.map((m) => ({ mt: m.mt, pu: m.pu })); startIsland(W, hs.I, null); W.M.forEach((m, s) => Object.assign(m, keepM[s])); disp.clear(); if (G) { G.x = hs.m[me()] ? hs.m[me()][0] : 0; G.v = 0; } isleCard = 2.4; isleCardK = hs.I; }
      if (hs.tri && !W.trial) W.trial = 1;
      W.t = Math.abs(W.t - hs.t) > 0.5 ? hs.t : W.t + (hs.t - W.t) * 0.25;
      W.day = hs.d; W.bmn = hs.b; W.sail = hs.sl ? { t: hs.sl } : null; W.trans = hs.tr; W.over = hs.o || null; W.tc = hs.tc; W.reach = hs.r; W.aslPaid = hs.ap || null;
      const my = me();
      hs.m.forEach((a, s) => { const m = W.M[s]; if (!m) return; if (s !== my) { m.x = a[0]; m.dir = a[1]; m.g = a[2]; m.sta = a[6] / 100; } m.mt = MT_LIST[a[3]] || 'steed'; m.pu = a[4]; m.cr = a[5]; m.mk = a[7]; m.inv = a[8]; if (s !== my) m.hold = a[9]; });
      hs.S.forEach((a, j) => { const o = W.S[j]; if (!o) return; o.lv = a[0]; o.br = a[1]; o.mh = 100; o.hp = a[2]; o.job = a[3] >= 0 ? { done: a[3], need: 100 } : null; o.paid = a[4]; o.rack = a[5]; if (o.k === 'mount') o.t = MT_LIST[a[6]] || o.t; });
      W.u = hs.u.map((a) => ({ i: a[0], t: UT_LIST[a[1]], x: a[2], dir: a[3], mv: a[4] & 1, wk: (a[4] >> 1) & 1, tw: (a[4] >> 2) & 3, cc: a[4] & 16 ? 1 : 0, sq: a[4] & 32 ? 1 : 0, bm: a[4] & 64 ? 1 : 0 }));
      W.e = hs.e.map((a) => ({ i: a[0], t: ET_LIST[a[1]], x: a[2], y: a[3], dir: a[4], st: a[5], loot: a[6] === 3 ? 10 : a[6], hit: a[7] ? 0.1 : 0, df: a[8] }));
      W.gc = hs.g.map((a) => ({ x: a[0], a: a[1] ? 0.2 : 1, i: a[2] }));
      W.ar = hs.a.map((a) => ({ x0: a[0], y0: a[1], x1: a[2], y1: a[3], t: a[4] / 100, tf: 1 }));
      hs.p.forEach((a, j) => { if (W.P[j]) { W.P[j].al = a[0]; W.P[j].hp = a[1]; W.P[j].mh = 100; } });
      hs.c.forEach((v, j) => { if (W.ch[j]) W.ch[j].op = v; });
      W.tl = hs.tl.map((a) => ({ x: a[0], t: TL_LIST[a[1]] }));
      W.cw = hs.cw.map((a) => ({ x: a[0], s: a[1] }));
      W.bm = hs.bm ? { x: hs.bm[0], go: hs.bm[1], b: [] } : null;
      const fresh = (hs.f || []).filter((f) => f[0] > lastFq);
      if (fresh.length) { W.fx = hs.f; }
    }
    function pollHost() {
      if (!api.online || !api.isHost) return;
      let r = null; try { r = api.net.remote(); } catch (e) { r = null; }
      if (r && typeof r === 'object') rem = r;
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.m)) return;
      lastQ = hs.q; unpackGuest(hs);
    }
    function guestPredict(dt) {
      const s = me(); if (s < 0 || !W.M[s]) return;
      const m = W.M[s];
      if (!G) G = { x: m.x, v: 0, dir: m.dir, sta: 1, tired: 0, mt: m.mt, g: 0 };
      G.mt = m.mt;
      let li = auto() ? null : localInput();
      if (!li) { try { li = aiInput(W, s, 2, mems[s], null); } catch (e) { li = { ax: 0 }; } }
      if (W.trans > 0 || W.sail) li.ax = 0;
      monMove(W, G, li, dt);
      m.x = G.x; m.dir = G.dir; m.g = G.g; m.sta = G.sta; m.v = G.v; m.hold = li.hold;
      G.hold = li.hold;
    }
    function publish(dt) {
      if (!api.online || !W) return;
      pubT -= dt; if (pubT > 0) return;
      try {
        if (api.isHost) { pubT = 1 / 12; hsQ = (hsQ + 1) % 100000; api.net.hostSend(packHost()); }
        else { pubT = 1 / 15; const s = me(); if (s < 0 || !G) return; inQ = (inQ + 1) % 100000; api.net.publish({ k: key, q: inQ, x: r1(G.x), d: G.dir, g: G.g, h: G.hold ? 1 : 0, st: Math.round(G.sta * 100) / 100 }); }
      } catch (e) {}
    }

    /* ----- 사건 → 소리·입자·알림 ----- */
    const focusSeat = () => { const s = me(); return s >= 0 ? s : 0; };
    function note(t, ms) { notes = notes.filter((n) => n.t !== t); notes.push({ t, a: 0, life: (ms || 1500) / 1000 }); if (notes.length > 2) notes.shift(); }
    const near = (x) => Math.abs(x - camX) < (cv.w / zoom()) * 0.62;
    function processFx() {
      if (!W) return;
      for (const f of W.fx) {
        if (f[0] <= lastFq) continue;
        lastFq = f[0];
        const k = f[1], x = f[2], a = f[3], b = f[4], vis = near(x);
        switch (k) {
          case 'coin': { const m = W.M[a]; if (m) flies.push({ x0: m.x, y0: 46, x1: x, y1: 60, t: 0, d: 0.28 }); if (vis) Snd.coin(); break; }
          case 'pick': case 'give': if (a === focusSeat()) Snd.pick(); break;
          case 'refund': if (a === focusSeat()) Snd.pick(); break;
          case 'chest': if (vis) { Snd.coin(); Snd.coin(); } burst(x, 14, '#d9b45e', 8); break;
          case 'built': if (vis) Snd.knock(); burst(x, 30, '#8a7a62', 6); if (b === 'town' && vis) note('왕국이 자람'); break;
          case 'order': if (vis) Snd.knock(); break;
          case 'recruit': if (vis) { try { api.sfx('pop', { vol: 0.4 }); } catch (e) {} } break;
          case 'equip': case 'tool': if (vis) Snd.knock(); break;
          case 'bow': if (vis && Math.random() < 0.5) Snd.bow(); break;
          case 'whit': if (vis) { if (Math.random() < 0.35) try { api.sfx('thud', { vol: 0.35 }); } catch (e) {} burst(x, 16, '#6e6252', 3); } break;
          case 'wbreak': if (vis) { try { api.sfx('thud', { vol: 0.8 }); } catch (e) {} shake = Math.max(shake, 5); } burst(x, 20, '#6e6252', 14); note('성벽이 무너짐'); break;
          case 'kill': if (vis) burst(x, 12, '#2b2433', 7, 1); break;
          case 'hunt': if (vis) burst(x, 10, '#6a4a3a', 4); break;
          case 'mhit': if (a === focusSeat()) { try { api.buzz(30, 'hit'); } catch (e) {} flash = 0.3; } burst(x, 30, '#d9b45e', 4); break;
          case 'armor': if (a === focusSeat()) note('마갑이 막아 냄'); break;
          case 'crown': if (a === focusSeat() || W.n === 1) { note('왕관을 빼앗김', 1600); try { api.sfx('warn'); api.buzz(120, 'alert'); } catch (e) {} } else note('동료의 왕관을 빼앗김', 1600); break;
          case 'crownback': note('왕관을 되찾음'); break;
          case 'crownlost': try { api.sfx('lose'); } catch (e) {} break;
          case 'dawn': Snd.bell(); note(dayName(a) + ' · ' + SEASONS[seasonOf(a)], 1600); break;
          case 'dusk': Snd.horn(a); if (a) note('핏빛 달이 뜸', 1600); break;
          case 'portal': Snd.boom(); shake = Math.max(shake, 7); burst(x, 50, '#3b2a4a', 26, 1); note(a ? '절벽 균열이 무너짐' : '균열이 닫힘', 1600); break;
          case 'boom': burst(x, 40, '#c08040', 30); break;
          case 'phit': if (vis && Math.random() < 0.3) burst(x, 40, '#3b2a4a', 3, 1); break;
          case 'boatready': note('배가 바다에 나갈 채비를 마침', 1600); break;
          case 'sail': note('출항', 1400); try { api.sfx('go', { vol: 0.5 }); } catch (e) {} break;
          case 'clean': note('섬에 탐욕이 남지 않음', 1600); break;
          case 'mount': if (a === focusSeat()) note('탈것을 바꿈 · ' + MOUNTS[W.M[a].mt].n); break;
          case 'assault': note('기사들이 균열로 향함'); break;
          case 'fall': break;
          case 'grab': if (vis) burst(x, 14, '#2b2433', 4, 1); break;
          case 'isle': isleCard = 2.6; isleCardK = a; break;
          case 'win': try { api.sfx('win'); } catch (e) {} break;
        }
      }
    }
    function burst(x, y, col, n, wisp) {
      if (parts.length > 260) return;
      for (let j = 0; j < n; j++) parts.push({ x, y: y * (0.4 + Math.random() * 0.6), vx: (Math.random() - 0.5) * 70, vy: 20 + Math.random() * 60, life: 0.5 + Math.random() * 0.6, t: 0, col, wisp: wisp ? 1 : 0, r: 1 + Math.random() * 1.6 });
    }

    /* ----- 화면 배치 ----- */
    let Z = 1, GY = 200, WL = 0;
    function zoom() { return Z; }
    function lay() {
      const w = cv.w, h = cv.h, land = w >= h * 1.05;
      if (land) { Z = clamp(h / 265, 0.8, 2.8); GY = Math.round(h * 0.7); }   // 가독성: 폰 가로(360px)에서 1.2 → 1.36배
      else { Z = clamp(w / 330, 0.8, 1.8); GY = Math.round(h * 0.5); }
      WL = GY + Math.round(9 * Z);
    }
    const SX = (x) => (x - camX) * Z + cv.w / 2;
    // 가독성: 그림 위 글씨는 늘 어두운 외곽선(글자 대비 강화와 같은 도우미, 항상 켬)
    const oText = (t, x, y, sw) => { if (L.ui && L.ui.strokeText) L.ui.strokeText(ctx, t, x, y, { force: true, stroke: 'rgba(8,8,12,0.78)', width: sw }); else ctx.fillText(t, x, y); };

    /* ----- 프레임 ----- */
    function frame(rdt, now) {
      realNow = now;
      if (!W) return;
      const dt = Math.min(0.05, rdt);
      if (host()) {
        pollHost();
        acc += dt * SPD(); let n = 0;
        while (acc >= H && n < 48) { simStep(); acc -= H; n++; }
        if (n >= 48) acc = 0;
        hostFlow(now);
      } else {
        pollGuest();
        guestPredict(dt * SPD());
      }
      publish(dt);
      processFx();
      if (!tipShown && W.t > W.D * 0.07 + 0.5) showTip();
    }

    /* ======================= 그리기 ======================= */
    let rb = null, rbc = null, lc = null, lcc = null;
    function draw(now, dt) {
      const w = cv.w, h = cv.h;
      lay();
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      if (!W) { ctx.fillStyle = '#0b0d14'; ctx.fillRect(0, 0, w, h); return; }
      const tf = tfOf(W), season = seasonOf(W.day), SC = SEASON_COL[season];
      const fs = focusSeat(), fm = W.M[fs] || W.M[0];
      // 카메라
      const look = fm.dir * Math.min(120, w / Z * 0.16) * (Math.abs(fm.v || 0) > 5 || fm.g ? 1 : 0.6);
      let tx = fm.x + look;
      if (L.debug && typeof L.debug.crCam === 'number') tx = L.debug.crCam;
      if (W.sail) { const b = W.S.find((o) => o.k === 'boat'); if (b) tx = b.x + Math.min(200, W.sail.t * 30); }
      const half = w / Z / 2;
      tx = clamp(tx, -W.hw - 140 + half, W.hw + 160 - half);
      if (!camInit) { camX = tx; camInit = true; }
      camX += (tx - camX) * Math.min(1, dt * 3.2);
      // 흔들림
      let shx = 0;
      if (shake > 0) { shx = (Math.random() - 0.5) * shake * fxAmt(); shake = Math.max(0, shake - dt * 18); }
      ctx.save(); ctx.translate(shx, 0);
      const sky = skyAt(tf, W.bmn);
      drawSky(w, h, tf, sky);
      drawFar(w, sky, SC, tf, season);
      drawWorld(w, h, tf, sky, SC, season, now, dt);
      drawLight(w, h, tf);
      ctx.restore();
      drawWater(w, h, tf, sky, now);
      ctx.save(); ctx.translate(shx, 0); drawMarkers(sky.lit, W.t); ctx.restore();
      drawParticles(dt, tf);
      drawHUD(w, h, tf, now, dt);
      // 질주 중이면 누르고 있는 쪽 단추에 테(눌림 상태와 함께 바로 보이게)
      const gl = !!(fm.g && isMine(fs)); bL.classList.toggle('gal', gl && fm.dir < 0); bR.classList.toggle('gal', gl && fm.dir > 0);
      // 금화 단추를 눌렀는데 낼 곳이 없으면 짧게 알려 줌(눌러도 아무 일 없는 것처럼 느껴지지 않게)
      const hd = isMine(fs) && !auto() && (inp.coin || held('coin'));
      if (!hd) { coinHeld = 0; coinHad = 0; }
      else if (coinHeld >= 0) {
        coinHeld += dt; if (fm.mk) coinHad = 1;
        if (coinHeld > 0.45) { coinHeld = -1; if (!fm.cr) note('왕관이 없음'); else if (fm.pu <= 0 && !coinHad) note('지갑이 비었음'); else if (!coinHad && !fm.mk && W.trans <= 0 && !W.sail) note('가까이에 금화를 낼 곳 없음', 1200); }
      }
    }
    let coinHeld = 0, coinHad = 0;
    function drawSky(w, h, tf, sky) {
      const g = ctx.createLinearGradient(0, 0, 0, GY);
      g.addColorStop(0, rgb(sky.top)); g.addColorStop(1, rgb(sky.bot));
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, GY + 2);
      // 별
      const night = clamp((tf - 0.66) / 0.08, 0, 1) * clamp((1.0 - tf) / 0.03 + (tf < 0.05 ? 0 : 0), 0, 1) + (tf < 0.04 ? 1 - tf / 0.04 : 0);
      if (night > 0.02) {
        ctx.fillStyle = 'rgba(220,225,235,' + (0.5 * night) + ')';
        for (let j = 0; j < 70; j++) { const sx = ((hash(j * 7 + 1) * w * 1.6 - camX * 0.02 * Z) % w + w) % w, sy = hash(j * 13 + 5) * GY * 0.62; const tw = 0.6 + 0.4 * Math.sin(realNow * 0.001 * (0.5 + hash(j)) + j); ctx.globalAlpha = tw; ctx.fillRect(sx, sy, hash(j * 3) < 0.15 ? 1.6 : 1, hash(j * 3) < 0.15 ? 1.6 : 1); }
        ctx.globalAlpha = 1;
      }
      // 해·달
      const dayArc = (tf - 0.02) / 0.66, nightArc = ((tf + 1 - 0.66) % 1) / 0.38;
      if (dayArc > 0 && dayArc < 1) {
        const x = w * (0.12 + 0.76 * dayArc), y = GY * (0.9 - 0.75 * Math.sin(Math.PI * dayArc));
        const col = mix('#f3e3c0', '#e2a06a', clamp((tf - 0.5) / 0.15, 0, 1));
        const gl = ctx.createRadialGradient(x, y, 2, x, y, 70 * Z); gl.addColorStop(0, 'rgba(250,236,200,0.35)'); gl.addColorStop(1, 'rgba(250,236,200,0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, 70 * Z, 0, 7); ctx.fill();
        ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, 11 * Z, 0, 7); ctx.fill();
      }
      if (nightArc > 0 && nightArc < 1) {
        const x = w * (0.18 + 0.64 * nightArc), y = GY * (0.85 - 0.6 * Math.sin(Math.PI * nightArc));
        const bm = W.bmn;
        const gl = ctx.createRadialGradient(x, y, 2, x, y, 60 * Z); gl.addColorStop(0, bm ? 'rgba(170,40,40,0.35)' : 'rgba(200,210,225,0.22)'); gl.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, 60 * Z, 0, 7); ctx.fill();
        ctx.fillStyle = bm ? '#9e3a32' : '#d8dbe0'; ctx.beginPath(); ctx.arc(x, y, 9 * Z, 0, 7); ctx.fill();
        ctx.fillStyle = bm ? 'rgba(60,10,10,0.5)' : 'rgba(120,125,140,0.35)'; ctx.beginPath(); ctx.arc(x + 2.5 * Z, y - 1.5 * Z, 3 * Z, 0, 7); ctx.fill();
      }
    }
    function drawFar(w, sky, SC, tf, season) {
      const bot = sky.bot, lit = sky.lit;
      const layer = (f, base, a1, a2, a3, col, sd, step) => {
        ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, GY + 2);
        for (let sx = 0; sx <= w + step; sx += step) { const wx = camX * f + (sx - w / 2) / Z; ctx.lineTo(sx, GY - (base + ridge(wx, sd, a1, a2, a3)) * Z); }
        ctx.lineTo(w, GY + 2); ctx.closePath(); ctx.fill();
      };
      const dk = (t) => rgb(mixA(bot, [16, 18, 24], t));
      // 먼 산맥: 겹친 봉우리
      const peaks = (f, P, h0, h1, wd, col, seed, step) => {
        ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(0, GY + 2);
        for (let sx = -step; sx <= w + step; sx += step) {
          const wx = camX * f + (sx - w / 2) / Z, ci = Math.floor(wx / P);
          let hh = 0;
          for (let j = ci - 2; j <= ci + 2; j++) { const c = (j + 0.5 + (hash(j * 31 + seed) - 0.5) * 0.6) * P, H = h0 + (h1 - h0) * hash(j * 17 + seed * 3), Wd = wd * (0.7 + 0.6 * hash(j * 7 + seed)); const k = 1 - Math.abs(wx - c) / Wd; if (k > 0) hh = Math.max(hh, H * Math.pow(k, 1.15)); }
          hh += 3 * Math.sin(wx * 0.05 + seed) + 2 * Math.sin(wx * 0.13);
          ctx.lineTo(sx, GY - (24 + hh) * Z);
        }
        ctx.lineTo(w, GY + 2); ctx.closePath(); ctx.fill();
      };
      peaks(0.05, 230, 70, 150, 210, dk(0.22), 3, 6);
      // 안개
      const fg = ctx.createLinearGradient(0, GY - 120 * Z, 0, GY);
      fg.addColorStop(0, rgb(bot, 0)); fg.addColorStop(1, rgb(bot, 0.55)); ctx.fillStyle = fg; ctx.fillRect(0, GY - 120 * Z, w, 120 * Z);
      peaks(0.14, 170, 40, 96, 170, dk(0.38), 11, 6);
      ctx.fillStyle = fg; ctx.fillRect(0, GY - 120 * Z, w, 120 * Z);
      layer(0.26, 34, 12, 9, 10, dk(0.5), 4.1, 7);
      ctx.fillStyle = fg; ctx.fillRect(0, GY - 90 * Z, w, 90 * Z);
      // 먼 숲(침엽수 실루엣)
      const fc = rgb(mixA(mixA(bot, [14, 16, 18], 0.62), hex(SC.fz), 0.25 * lit));
      ctx.fillStyle = fc; ctx.beginPath(); ctx.moveTo(0, GY + 2);
      const f = 0.45, step = 5;
      for (let sx = -step; sx <= w + step; sx += step) {
        const wx = camX * f + (sx - w / 2) / Z, cell = Math.floor(wx / 9);
        const hgt = 34 + 18 * hash(cell * 3 + 11) + 10 * Math.sin(wx * 0.004 + 2);
        const peak = ((wx / 9) % 1 + 1) % 1;
        ctx.lineTo(sx, GY - (hgt - Math.abs(peak - 0.5) * 2 * 12) * Z);
      }
      ctx.lineTo(w, GY + 2); ctx.closePath(); ctx.fill();
      const fg2 = ctx.createLinearGradient(0, GY - 50 * Z, 0, GY);
      fg2.addColorStop(0, rgb(bot, 0)); fg2.addColorStop(1, rgb(bot, 0.35 + 0.15 * (1 - lit))); ctx.fillStyle = fg2; ctx.fillRect(0, GY - 50 * Z, w, 50 * Z);
      void season;
    }
    function drawWorld(w, h, tf, sky, SC, season, now, dt) {
      const lit = sky.lit, z = Z, t = W.t;
      const lo = camX - w / z / 2 - 80, hi = camX + w / z / 2 + 80;
      const vis = (x, m) => x > lo - (m || 0) && x < hi + (m || 0);
      const shade = (c, k) => rgb(mixA(hex(c), [10, 12, 18], (1 - lit) * (k == null ? 0.55 : k)));
      // 땅
      const gx0 = Math.max(SX(-W.hw - 10), -10), gx1 = Math.min(SX(W.hw + 10), w + 10);
      if (gx1 > gx0) {
        ctx.fillStyle = shade('#231d18', 0.4); ctx.fillRect(gx0, GY, gx1 - gx0, WL - GY + 2);
        ctx.fillStyle = shade(SC.gr); ctx.fillRect(gx0, GY - 2 * z, gx1 - gx0, 3.2 * z);
      }
      // 나무(뒤)
      const reach = W.reach;
      const trees = W._trees || (W._trees = genIsland(W.sd, W.k).trees);
      if (W._treesK !== W.k) { W._trees = genIsland(W.sd, W.k).trees; W._treesK = W.k; }
      for (const tr of W._trees) {
        const x = tr[0]; if (!vis(x, 40)) continue;
        const cut = Math.abs(x) < reach[x < 0 ? 0 : 1] - 20;
        drawTree(SX(x), tr, cut, SC, season, lit, t);
      }
      // 절벽과 부두
      drawCliff(SX(-W.hw), lit, tf);
      drawShore(SX(W.hw), lit);
      // 균열
      W.P.forEach((p) => { if (vis(p.x, 120)) drawPortal(SX(p.x), p, t, lit); });
      // 야영지
      W.camps.forEach((x) => { if (vis(x, 40)) drawCamp(SX(x), lit, t); });
      // 건물
      for (const o of W.S) if (vis(o.x, 90)) drawStruct(o, SX(o.x), lit, t, SC, season);
      // 상자
      for (const c of W.ch) if (vis(c.x)) drawChest(SX(c.x), c.op, lit);
      // 폭약 수레
      if (W.bm && vis(W.bm.x)) drawBomb(SX(W.bm.x), t);
      // 떨어진 도구·왕관
      for (const tl of W.tl) if (vis(tl.x)) drawToolGround(SX(tl.x), tl.t, lit);
      for (const c of W.cw) if (vis(c.x)) drawCrown(SX(c.x), GY - 3 * z - Math.abs(Math.sin(t * 3)) * 2 * z, z * 1.2);
      // 금화
      for (const c of W.gc) if (vis(c.x)) { const pop = c.a < 0.45 ? Math.sin(c.a / 0.45 * Math.PI) * 18 : 0; drawCoin(SX(c.x), GY - (2.2 + pop) * z, z, t + (c.i || 0)); }
      // 백성·사슴
      const gx = (u) => { if (host() || !W) return u.x; let d = disp.get(u.i); if (d == null || Math.abs(d - u.x) > 90) d = u.x; d += (u.x - d) * Math.min(1, dt * 9); disp.set(u.i, d); return d; };
      for (const u of W.u) { const x = gx(u); if (!vis(x)) continue; if (u.t === 'deer') drawDeer(SX(x), u, t, lit); else drawPerson(SX(x), u, t, lit); }
      // 탐욕
      for (const e of W.e) { const x = gx({ i: -e.i, x: e.x }); if (!vis(x, 30)) continue; drawGreed(SX(x), e, t, lit); }
      // 군주
      W.M.forEach((m, s) => { if (W.sail || W.trans > 0) return; if (!vis(m.x, 60)) return; drawMonarch(SX(m.x), m, s, t, lit); });
      // 화살
      ctx.strokeStyle = shade('#c9bca2', 0.4); ctx.lineWidth = Math.max(1, 1.1 * z);
      for (const a of W.ar) {
        const k = clamp(a.t / a.tf, 0, 1); if (!vis(a.x0) && !vis(a.x1)) continue;
        const x = a.x0 + (a.x1 - a.x0) * k, arc = Math.abs(a.x1 - a.x0) * 0.25 + 10;
        const y = a.y0 + (a.y1 - a.y0) * k + Math.sin(Math.PI * k) * arc;
        const k2 = Math.min(1, k + 0.04), x2 = a.x0 + (a.x1 - a.x0) * k2, y2 = a.y0 + (a.y1 - a.y0) * k2 + Math.sin(Math.PI * k2) * arc;
        const ang = Math.atan2(-(y2 - y), x2 - x);
        const X0 = SX(x), Y0 = GY - y * z;
        ctx.beginPath(); ctx.moveTo(X0 - Math.cos(ang) * 5 * z, Y0 + Math.sin(ang) * 5 * z); ctx.lineTo(X0 + Math.cos(ang) * 4 * z, Y0 - Math.sin(ang) * 4 * z); ctx.stroke();
      }
      // 금화가 날아감
      for (let j = flies.length - 1; j >= 0; j--) {
        const f = flies[j]; f.t += dt; const k = f.t / f.d; if (k >= 1) { flies.splice(j, 1); continue; }
        const x = f.x0 + (f.x1 - f.x0) * k, y = f.y0 + (f.y1 - f.y0) * k + Math.sin(Math.PI * k) * 18;
        drawCoin(SX(x), GY - y * z, z, t);
      }
      // 앞쪽 풀
      ctx.strokeStyle = shade(mix(SC.gr, '#151713', 0.45), 0.6); ctx.lineWidth = Math.max(1, 0.9 * z);
      ctx.beginPath();
      const g0 = Math.floor((camX - w / z / 2) / 6) - 1, g1 = Math.ceil((camX + w / z / 2) / 6) + 1;
      for (let gi = g0; gi <= g1; gi++) { const r = hash(gi * 5 + 3); if (r < 0.45) continue; const wx = gi * 6 + r * 4; if (Math.abs(wx) > W.hw) continue; const sx = SX(wx), hh = (1.5 + 3.5 * hash(gi * 11 + 1)) * z, lean = (hash(gi * 3) - 0.5) * 2 * z + Math.sin(t * 1.3 + gi) * 0.6 * z; ctx.moveTo(sx, GY + 1); ctx.lineTo(sx + lean, GY - hh); if (r > 0.75) { ctx.moveTo(sx + 1.5 * z, GY + 1); ctx.lineTo(sx + 1.5 * z + lean * 1.6, GY - hh * 0.7); } }
      ctx.stroke();
    }

    /* ----- 낱개 그림 ----- */
    function drawTree(X, tr, cut, SC, season, lit, t) {
      const z = Z, hgt = tr[1] * z, kind = tr[2], sh = (c) => rgb(mixA(hex(c), [10, 12, 18], (1 - lit) * 0.6));
      if (cut) { if (tr[3] % 3) return; ctx.fillStyle = sh('#2e251e'); ctx.beginPath(); ctx.moveTo(X - 2.4 * z, GY); ctx.lineTo(X - 1.8 * z, GY - 2.6 * z); ctx.lineTo(X + 1.8 * z, GY - 3 * z); ctx.lineTo(X + 2.4 * z, GY); ctx.fill(); return; }
      const sway = Math.sin(t * 0.8 + tr[3]) * 1.2 * z;
      ctx.fillStyle = sh('#2a221c'); ctx.fillRect(X - 1.6 * z, GY - hgt * 0.45, 3.2 * z, hgt * 0.45);
      if (kind === 0 || season === 3) { // 침엽수
        ctx.fillStyle = sh(season === 3 ? '#26302b' : SC.tr);
        for (let j = 0; j < 3; j++) { const y0 = GY - hgt * (0.25 + j * 0.24), wdt = (13 - j * 3.4) * z; ctx.beginPath(); ctx.moveTo(X - wdt, y0); ctx.lineTo(X + sway * (j / 3), y0 - hgt * 0.36); ctx.lineTo(X + wdt, y0); ctx.fill(); }
        if (season === 3) { ctx.fillStyle = sh('#c8ccc9'); for (let j = 0; j < 3; j++) { const y0 = GY - hgt * (0.25 + j * 0.24), wdt = (13 - j * 3.4) * z; ctx.beginPath(); ctx.moveTo(X - wdt * 0.5, y0 - hgt * 0.18); ctx.lineTo(X + sway * (j / 3), y0 - hgt * 0.36); ctx.lineTo(X + wdt * 0.5, y0 - hgt * 0.18); ctx.fill(); } }
      } else { // 활엽수
        ctx.fillStyle = sh(kind === 1 ? SC.lf : SC.tr);
        const cy = GY - hgt * 0.7, r = hgt * 0.24;
        ctx.beginPath(); ctx.arc(X + sway, cy, r, 0, 7); ctx.arc(X - r * 0.7 + sway, cy + r * 0.45, r * 0.75, 0, 7); ctx.arc(X + r * 0.7 + sway, cy + r * 0.4, r * 0.7, 0, 7); ctx.fill();
        if (lit > 0.85) { ctx.globalAlpha = 0.1 * lit; ctx.fillStyle = '#c8cdb0'; ctx.beginPath(); ctx.arc(X - r * 0.25 + sway, cy - r * 0.3, r * 0.62, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
      }
    }
    function drawCliff(X, lit, tf) {
      const z = Z; if (X < -300 * z) return;
      const sh = (c, k) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * (k || 0.6)));
      ctx.fillStyle = sh('#2c2a2e'); ctx.beginPath(); ctx.moveTo(X + 30 * z, GY + 2); ctx.lineTo(X + 38 * z, GY - 70 * z); ctx.lineTo(X + 18 * z, GY - 150 * z); ctx.lineTo(X + 26 * z, GY - 230 * z); ctx.lineTo(X - 400 * z, GY - 260 * z); ctx.lineTo(X - 400 * z, GY + 2); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = sh('#4a464a'); ctx.lineWidth = 1.2 * z; ctx.beginPath(); ctx.moveTo(X + 38 * z, GY - 70 * z); ctx.lineTo(X + 18 * z, GY - 150 * z); ctx.lineTo(X + 26 * z, GY - 230 * z); ctx.stroke();
      void tf;
    }
    function drawShore(X, lit) {
      const z = Z; if (X > cv.w + 300 * z) return;
      ctx.fillStyle = rgb(mixA(hex('#3a3026'), [8, 9, 14], (1 - lit) * 0.6));
      ctx.beginPath(); ctx.moveTo(X - 30 * z, GY - 1); ctx.lineTo(X + 4 * z, GY + 6 * z); ctx.lineTo(X - 40 * z, GY + 9 * z); ctx.fill();
      // 부두
      ctx.fillStyle = rgb(mixA(hex('#4a3a2c'), [8, 9, 14], (1 - lit) * 0.6));
      ctx.fillRect(X - 40 * z, GY - 6 * z, 120 * z, 3 * z);
      for (let j = 0; j < 5; j++) ctx.fillRect(X - 36 * z + j * 28 * z, GY - 6 * z, 2.4 * z, 16 * z);
    }
    function drawPortal(X, p, t, lit) {
      const z = Z;
      if (p.kind === 'c') {
        const R = 46 * z, cy = GY - 50 * z;
        if (!p.al) { ctx.fillStyle = rgb([30, 28, 34]); ctx.fillRect(X - 30 * z, GY - 14 * z, 60 * z, 14 * z); return; }
        const g = ctx.createRadialGradient(X, cy, 4, X, cy, R * 1.4); g.addColorStop(0, 'rgba(18,8,24,0.95)'); g.addColorStop(0.6, 'rgba(48,24,64,0.6)'); g.addColorStop(1, 'rgba(40,20,60,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(X, cy, R * 0.8, R * 1.15, 0, 0, 7); ctx.fill();
        swirl(X, cy, R * 0.6, R * 0.95, t);
        return;
      }
      const cy = GY - 30 * z;
      if (!p.al) { ctx.fillStyle = rgb(mixA([60, 56, 52], [8, 9, 14], (1 - lit) * 0.6)); for (let j = -2; j <= 2; j++) ctx.fillRect(X + j * 8 * z - 3 * z, GY - (5 + (j & 1) * 4) * z, 7 * z, (5 + (j & 1) * 4) * z); return; }
      // 돌 테두리
      ctx.strokeStyle = rgb(mixA([70, 64, 66], [8, 9, 14], (1 - lit) * 0.7)); ctx.lineWidth = 5 * z;
      ctx.beginPath(); ctx.ellipse(X, cy, 17 * z, 28 * z, 0, 0, 7); ctx.stroke();
      const g = ctx.createRadialGradient(X, cy, 2, X, cy, 30 * z); g.addColorStop(0, 'rgba(10,4,16,0.98)'); g.addColorStop(0.7, 'rgba(46,22,62,0.85)'); g.addColorStop(1, 'rgba(60,30,80,0.2)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(X, cy, 15 * z, 26 * z, 0, 0, 7); ctx.fill();
      swirl(X, cy, 10 * z, 20 * z, t);
      if (p.hp < 100 && p.mh === 100 || p.hp < p.mh) { const k = p.hp / p.mh; ctx.fillStyle = 'rgba(200,190,170,0.5)'; ctx.fillRect(X - 14 * z, cy - 36 * z, 28 * z * k, 2 * z); }
    }
    function swirl(X, cy, rx, ry, t) {
      ctx.strokeStyle = 'rgba(120,80,150,0.35)'; ctx.lineWidth = 1.2 * Z;
      for (let j = 0; j < 3; j++) { ctx.beginPath(); ctx.ellipse(X, cy, rx * (0.4 + j * 0.25), ry * (0.4 + j * 0.25), 0, t * (1 + j * 0.4) + j, t * (1 + j * 0.4) + j + 2.2); ctx.stroke(); }
    }
    function drawCamp(X, lit, t) {
      const z = Z, sh = (c) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * 0.6));
      ctx.fillStyle = sh('#4a4238'); ctx.beginPath(); ctx.moveTo(X - 24 * z, GY); ctx.lineTo(X - 14 * z, GY - 16 * z); ctx.lineTo(X - 2 * z, GY); ctx.fill();
      ctx.strokeStyle = sh('#2a241e'); ctx.lineWidth = 1.2 * z; ctx.beginPath(); ctx.moveTo(X - 14 * z, GY - 16 * z); ctx.lineTo(X - 14 * z, GY - 20 * z); ctx.stroke();
      fire(X + 10 * z, GY, 0.6, t);
    }
    function fire(X, Y, s, t) {
      const z = Z * s;
      ctx.fillStyle = '#2a201a'; ctx.fillRect(X - 6 * z, Y - 2 * z, 12 * z, 2 * z);
      for (let j = 0; j < 3; j++) {
        const f = Math.sin(t * 9 + j * 2.1) * 0.25 + 0.75, hh = (9 + j * 3) * z * f;
        ctx.fillStyle = j === 0 ? 'rgba(214,120,52,0.85)' : j === 1 ? 'rgba(232,170,80,0.75)' : 'rgba(248,220,150,0.6)';
        ctx.beginPath(); ctx.moveTo(X - (5 - j * 1.4) * z, Y - 2 * z); ctx.quadraticCurveTo(X + Math.sin(t * 7 + j) * 2 * z, Y - hh * 1.3, X + (5 - j * 1.4) * z, Y - 2 * z); ctx.fill();
      }
    }
    function drawStruct(o, X, lit, t, SC, season) {
      const z = Z, sh = (c, k) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * (k == null ? 0.6 : k)));
      const building = o.job && o.lv < (o.job.to || 1);
      if (o.k === 'town') {
        // 금고 상자
        drawChest(X + 22 * z, 0, lit, W.tc > 0);
        if (o.lv >= 1) {
          const hw = (16 + o.lv * 8) * z, hh = (20 + o.lv * 14) * z;
          ctx.fillStyle = sh(o.lv >= 2 ? '#56524c' : '#4e3d2d'); ctx.fillRect(X - hw, GY - hh, hw * 2, hh);
          if (o.lv >= 2) { ctx.fillStyle = sh('#46423e'); for (let j = -1; j <= 1; j += 2) { ctx.fillRect(X + j * hw - 7 * z, GY - hh - 16 * z, 14 * z, hh + 16 * z); for (let k = 0; k < 3; k++) ctx.fillRect(X + j * hw - 7 * z + k * 5 * z, GY - hh - 20 * z, 3 * z, 4 * z); } }
          else { ctx.fillStyle = sh('#3a2c20'); ctx.beginPath(); ctx.moveTo(X - hw - 4 * z, GY - hh); ctx.lineTo(X, GY - hh - 14 * z); ctx.lineTo(X + hw + 4 * z, GY - hh); ctx.fill(); }
          if (o.lv >= 3) { ctx.fillStyle = sh('#4c4844'); ctx.fillRect(X - 9 * z, GY - hh - 34 * z, 18 * z, 34 * z); }
          ctx.fillStyle = 'rgba(240,190,110,' + (0.25 + 0.6 * (1 - lit)) + ')'; ctx.fillRect(X - 3 * z, GY - hh * 0.55, 6 * z, 8 * z);
          // 깃발
          const fy = GY - hh - (o.lv >= 3 ? 34 : o.lv >= 2 ? 0 : 14) * z;
          ctx.strokeStyle = sh('#2a241e'); ctx.lineWidth = 1.2 * z; ctx.beginPath(); ctx.moveTo(X, fy); ctx.lineTo(X, fy - 18 * z); ctx.stroke();
          ctx.fillStyle = sh('#7a2e2e', 0.5); ctx.beginPath(); ctx.moveTo(X, fy - 18 * z); ctx.quadraticCurveTo(X + 7 * z, fy - 17 * z + Math.sin(t * 2) * z, X + 13 * z, fy - 15 * z + Math.sin(t * 2.4) * 1.5 * z); ctx.lineTo(X, fy - 11 * z); ctx.fill();
        }
        fire(X - (o.lv ? 0 : 0), GY, 1, t);
        if (building) scaffold(X, 40 * z, o.job.done / o.job.need);
        return;
      }
      if (o.k === 'shop') {
        const av = C0().town.lv >= TOOLS[o.t].req; if (!av) return;
        ctx.fillStyle = sh('#3c2f24'); ctx.fillRect(X - 13 * z, GY - 20 * z, 2 * z, 20 * z); ctx.fillRect(X + 11 * z, GY - 20 * z, 2 * z, 20 * z);
        ctx.fillStyle = sh('#5a4634'); ctx.beginPath(); ctx.moveTo(X - 16 * z, GY - 19 * z); ctx.lineTo(X, GY - 26 * z); ctx.lineTo(X + 16 * z, GY - 19 * z); ctx.fill();
        ctx.fillStyle = sh('#3a2e24'); ctx.fillRect(X - 12 * z, GY - 13 * z, 24 * z, 1.6 * z);
        for (let j = 0; j < o.rack; j++) drawToolIcon(X - 8 * z + j * 5.4 * z, GY - 12 * z, o.t, z * 0.75, lit);
        return;
      }
      if (o.k === 'bomb') {
        if (C0().town.lv < BOMB.req) return;
        ctx.fillStyle = sh('#3c3430'); ctx.fillRect(X - 12 * z, GY - 14 * z, 24 * z, 14 * z); ctx.fillStyle = sh('#262220'); ctx.fillRect(X - 14 * z, GY - 16 * z, 28 * z, 3 * z);
        return;
      }
      if (o.k === 'wall') {
        if (o.lv === 0 && !building) return;
        const lv = Math.max(o.lv, building ? 1 : 0), k = building ? o.job.done / o.job.need : 1;
        const hgt = [0, 16, 26, 32, 42][lv] * z;
        if (o.br) { ctx.fillStyle = sh('#4a4038'); for (let j = -2; j <= 2; j++) ctx.fillRect(X + j * 4 * z - 2 * z, GY - (3 + hash(o.i * 5 + j) * 5) * z, 4.5 * z, (3 + hash(o.i * 5 + j) * 5) * z); if (building) scaffold(X, hgt, k); return; }
        if (building && o.lv === 0) { ctx.globalAlpha = 0.35 + 0.65 * k; }
        const dmg = o.mh ? 1 - o.hp / o.mh : 0;
        if (lv <= 2) {
          ctx.fillStyle = sh(lv === 1 ? '#5a4632' : '#4e3c2a');
          const n = lv === 1 ? 4 : 6, wd = lv === 1 ? 3 : 3.4;
          for (let j = 0; j < n; j++) { const xx = X + (j - (n - 1) / 2) * (wd + 0.6) * z, hh = hgt * (0.85 + 0.15 * hash(o.i * 9 + j)) * (1 - dmg * 0.3 * hash(j + 3)); ctx.beginPath(); ctx.moveTo(xx - wd * z / 2, GY); ctx.lineTo(xx - wd * z / 2, GY - hh + 2 * z); ctx.lineTo(xx, GY - hh - 1.5 * z); ctx.lineTo(xx + wd * z / 2, GY - hh + 2 * z); ctx.lineTo(xx + wd * z / 2, GY); ctx.fill(); }
          ctx.fillStyle = sh('#3a2c1e'); ctx.fillRect(X - 11 * z, GY - hgt * 0.62, 22 * z, 1.6 * z);
        } else {
          const ww = (lv === 3 ? 10 : 13) * z;
          ctx.fillStyle = sh(lv === 3 ? '#5c5750' : '#625d56'); ctx.fillRect(X - ww, GY - hgt, ww * 2, hgt);
          ctx.strokeStyle = sh('#403c36'); ctx.lineWidth = 0.8 * z;
          for (let r = 1; r < 6; r++) { const yy = GY - hgt * r / 6; ctx.beginPath(); ctx.moveTo(X - ww, yy); ctx.lineTo(X + ww, yy); ctx.stroke(); }
          if (lv === 4) { ctx.fillStyle = sh('#625d56'); for (let j = 0; j < 3; j++) ctx.fillRect(X - ww + j * ww * 0.8, GY - hgt - 5 * z, ww * 0.5, 5 * z); }
          if (dmg > 0.3) { ctx.strokeStyle = 'rgba(20,18,16,0.7)'; ctx.lineWidth = 1 * z; ctx.beginPath(); ctx.moveTo(X - 2 * z, GY - hgt); ctx.lineTo(X + 3 * z, GY - hgt * 0.6); ctx.lineTo(X - 1 * z, GY - hgt * 0.3); ctx.stroke(); }
        }
        ctx.globalAlpha = 1;
        if (lv >= 2 && !o.br) fire(X, GY - hgt - 1 * z, 0.35, t + o.i);
        if (building) scaffold(X, hgt, k);
        return;
      }
      if (o.k === 'tower') {
        if (o.lv === 0 && !building) return;
        const lv = Math.max(o.lv, 1), k = building ? o.job.done / o.job.need : 1;
        if (building && o.lv === 0) ctx.globalAlpha = 0.35 + 0.65 * k;
        if (lv === 1) {
          ctx.strokeStyle = sh('#4a3826'); ctx.lineWidth = 2.2 * z;
          ctx.beginPath(); ctx.moveTo(X - 9 * z, GY); ctx.lineTo(X - 6 * z, GY - 42 * z); ctx.moveTo(X + 9 * z, GY); ctx.lineTo(X + 6 * z, GY - 42 * z); ctx.moveTo(X - 8 * z, GY - 14 * z); ctx.lineTo(X + 8 * z, GY - 28 * z); ctx.moveTo(X + 8 * z, GY - 14 * z); ctx.lineTo(X - 8 * z, GY - 28 * z); ctx.stroke();
          ctx.fillStyle = sh('#4e3c2a'); ctx.fillRect(X - 12 * z, GY - 44 * z, 24 * z, 3 * z); ctx.fillRect(X - 12 * z, GY - 52 * z, 2 * z, 8 * z); ctx.fillRect(X + 10 * z, GY - 52 * z, 2 * z, 8 * z);
        } else {
          ctx.fillStyle = sh('#5a554f'); ctx.fillRect(X - 9 * z, GY - 44 * z, 18 * z, 44 * z);
          ctx.fillStyle = sh('#625d56'); ctx.fillRect(X - 12 * z, GY - 48 * z, 24 * z, 5 * z); for (let j = 0; j < 4; j++) ctx.fillRect(X - 12 * z + j * 6.6 * z, GY - 53 * z, 3.4 * z, 5 * z);
        }
        ctx.globalAlpha = 1;
        fire(X + 10 * z, GY - 44 * z, 0.3, t + o.i);
        if (building) scaffold(X, 50 * z, k);
        return;
      }
      if (o.k === 'farm') {
        if (o.lv === 0 && !building) { ctx.fillStyle = sh('#3a2f22'); ctx.fillRect(X - 26 * z, GY - 1 * z, 52 * z, 2 * z); return; }
        const k = building ? o.job.done / o.job.need : 1, wd = (o.lv >= 2 ? 40 : 30) * z;
        const col = season === 3 ? '#b8bcba' : season === 2 ? '#8a7034' : season === 1 ? '#6a7a3a' : '#5c6e3c';
        ctx.globalAlpha = building && o.lv === 0 ? 0.4 + 0.6 * k : 1;
        ctx.fillStyle = sh('#2e241b'); ctx.fillRect(X - wd, GY - 3 * z, wd * 2, 3 * z);
        ctx.fillStyle = sh(col);
        for (let j = 0; j < (o.lv >= 2 ? 10 : 7); j++) { const xx = X - wd + 4 * z + j * 8 * z, hh = (season === 3 ? 1.5 : 5 + 2 * Math.sin(t * 1.5 + j)) * z; ctx.fillRect(xx, GY - 3 * z - hh, 3 * z, hh); }
        ctx.globalAlpha = 1;
        ctx.fillStyle = sh('#4a3a2a'); ctx.fillRect(X + wd + 2 * z, GY - 14 * z, 12 * z, 14 * z); ctx.fillStyle = sh('#3a2c20'); ctx.beginPath(); ctx.moveTo(X + wd, GY - 14 * z); ctx.lineTo(X + wd + 8 * z, GY - 21 * z); ctx.lineTo(X + wd + 16 * z, GY - 14 * z); ctx.fill();
        if (building) scaffold(X, 18 * z, k);
        return;
      }
      if (o.k === 'boat') {
        const lv = o.lv, k = building ? o.job.done / o.job.need : 1;
        let bx = X; if (W.sail) bx += Math.min(1, W.sail.t / 3) * 120 * z + Math.max(0, W.sail.t - 3) * 60 * z;
        const bob = Math.sin(t * 1.3) * 1.2 * z;
        ctx.save(); ctx.translate(bx, GY + 4 * z + bob);
        ctx.fillStyle = sh('#3a2c20');
        if (lv === 0 && !building) { for (let j = 0; j < 5; j++) { ctx.save(); ctx.translate(-30 * z + j * 14 * z, 0); ctx.rotate(-0.25 + j * 0.12); ctx.fillRect(-1.2 * z, -18 * z, 2.4 * z, 18 * z); ctx.restore(); } ctx.fillRect(-36 * z, -3 * z, 72 * z, 3 * z); }
        else {
          const L2 = lv >= 2 || (building && o.job.to >= 2);
          ctx.beginPath(); ctx.moveTo(-44 * z, -14 * z); ctx.lineTo(44 * z, -14 * z); ctx.lineTo(34 * z, 0); ctx.lineTo(-36 * z, 0); ctx.closePath();
          if (L2) ctx.fill(); else { ctx.strokeStyle = sh('#3a2c20'); ctx.lineWidth = 2 * z; ctx.stroke(); for (let j = -3; j <= 3; j++) ctx.fillRect(j * 11 * z - 1, -14 * z, 2 * z, 14 * z); }
          if (lv >= 3 || (building && o.job.to >= 3 && k > 0.4)) {
            ctx.fillStyle = sh('#2e241b'); ctx.fillRect(-1.5 * z, -64 * z, 3 * z, 50 * z);
            const open = W.sail ? 1 : 0;
            ctx.fillStyle = sh('#bfb59e', 0.7);
            if (open) { ctx.beginPath(); ctx.moveTo(2 * z, -60 * z); ctx.quadraticCurveTo(26 * z, -42 * z, 2 * z, -20 * z); ctx.fill(); }
            else ctx.fillRect(-14 * z, -60 * z, 28 * z, 4 * z);
          }
        }
        ctx.restore();
        if (building) scaffold(X, 40 * z, k);
        return;
      }
      if (o.k === 'mount') {
        const mt = MOUNTS[o.t] || MOUNTS.steed;
        drawMountBody(X, GY, o.t, -1, t, 0, 0, lit, 0.9);
        ctx.fillStyle = sh('#4a4644'); ctx.fillRect(X + 18 * z, GY - 10 * z, 5 * z, 10 * z);
        void mt;
      }
    }
    function scaffold(X, hgt, k) {
      const z = Z;
      ctx.strokeStyle = 'rgba(150,120,80,0.6)'; ctx.lineWidth = 1 * z;
      ctx.beginPath(); ctx.moveTo(X - 14 * z, GY); ctx.lineTo(X - 14 * z, GY - hgt - 4 * z); ctx.moveTo(X + 14 * z, GY); ctx.lineTo(X + 14 * z, GY - hgt - 4 * z);
      for (let y = 8; y < hgt / z; y += 10) { ctx.moveTo(X - 14 * z, GY - y * z); ctx.lineTo(X + 14 * z, GY - y * z); }
      ctx.stroke();
      ctx.fillStyle = 'rgba(214,180,110,0.55)'; ctx.fillRect(X - 14 * z, GY + 3 * z, 28 * z * clamp(k, 0, 1), 1.5 * z);
    }
    function drawChest(X, op, lit, glow) {
      const z = Z, sh = (c) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * 0.6));
      ctx.fillStyle = sh('#4a3626'); ctx.fillRect(X - 6 * z, GY - 7 * z, 12 * z, 7 * z);
      ctx.fillStyle = sh('#2a2018'); ctx.fillRect(X - 6 * z, GY - 4.5 * z, 12 * z, 1 * z);
      if (op) { ctx.fillStyle = sh('#3a2a1e'); ctx.fillRect(X - 6 * z, GY - 11 * z, 12 * z, 2.4 * z); }
      else { ctx.fillStyle = sh('#4e3a2a'); ctx.fillRect(X - 6.5 * z, GY - 9 * z, 13 * z, 2.6 * z); }
      if (glow) { ctx.fillStyle = 'rgba(217,180,94,0.8)'; ctx.fillRect(X - 3 * z, GY - 8 * z, 6 * z, 1.4 * z); }
    }
    function drawBomb(X, t) { const z = Z; ctx.fillStyle = '#2a2420'; ctx.fillRect(X - 9 * z, GY - 6 * z, 18 * z, 4 * z); ctx.fillStyle = '#1c1a18'; ctx.beginPath(); ctx.arc(X, GY - 12 * z, 7 * z, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(230,160,80,' + (0.5 + 0.5 * Math.sin(t * 12)) + ')'; ctx.beginPath(); ctx.arc(X + 5 * z, GY - 19 * z, 1.4 * z, 0, 7); ctx.fill(); }
    function drawToolGround(X, tl, lit) { drawToolIcon(X, GY - 2 * Z, tl, Z * 0.8, lit, 1); }
    function drawToolIcon(X, Y, tl, s, lit, flat) {
      const sh = (c) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * 0.5));
      ctx.save(); ctx.translate(X, Y); if (flat) ctx.rotate(-1.2);
      ctx.strokeStyle = sh('#8a7660'); ctx.fillStyle = sh('#8a7660'); ctx.lineWidth = 1.2 * s;
      if (tl === 'bow') { ctx.beginPath(); ctx.arc(0, 5 * s, 5 * s, -Math.PI * 0.85, -Math.PI * 0.15); ctx.stroke(); ctx.strokeStyle = 'rgba(200,200,190,0.5)'; ctx.lineWidth = 0.5 * s; ctx.beginPath(); ctx.moveTo(-4.3 * s, 2.3 * s); ctx.lineTo(4.3 * s, 2.3 * s); ctx.stroke(); }
      else if (tl === 'hammer') { ctx.fillRect(-0.6 * s, -1 * s, 1.2 * s, 9 * s); ctx.fillStyle = sh('#6a6a6a'); ctx.fillRect(-2.6 * s, -2 * s, 5.2 * s, 2.4 * s); }
      else if (tl === 'scythe') { ctx.fillRect(-0.5 * s, -2 * s, 1 * s, 10 * s); ctx.strokeStyle = sh('#9a9a9a'); ctx.beginPath(); ctx.arc(-3 * s, -1 * s, 3.4 * s, -Math.PI * 0.1, Math.PI * 0.6); ctx.stroke(); }
      else if (tl === 'shield') { ctx.fillStyle = sh('#6e6a66'); ctx.beginPath(); ctx.moveTo(-3 * s, -2 * s); ctx.lineTo(3 * s, -2 * s); ctx.lineTo(3 * s, 3 * s); ctx.lineTo(0, 6 * s); ctx.lineTo(-3 * s, 3 * s); ctx.fill(); ctx.fillStyle = sh('#6e2a2a'); ctx.fillRect(-0.7 * s, -2 * s, 1.4 * s, 7 * s); }
      ctx.restore();
    }
    function drawCoin(X, Y, z, t) {
      const sp = Math.abs(Math.cos(t * 3));
      ctx.fillStyle = '#c9a24a'; ctx.beginPath(); ctx.ellipse(X, Y, 2.6 * z * (0.35 + 0.65 * sp), 2.6 * z, 0, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(250,230,170,0.7)'; ctx.fillRect(X - 0.6 * z, Y - 1.6 * z, 1.1 * z, 1.1 * z);
    }
    function drawCrown(X, Y, s) {
      ctx.fillStyle = '#c9a24a'; ctx.beginPath(); ctx.moveTo(X - 4 * s, Y); ctx.lineTo(X - 4.5 * s, Y - 5 * s); ctx.lineTo(X - 2 * s, Y - 2.6 * s); ctx.lineTo(X, Y - 5.6 * s); ctx.lineTo(X + 2 * s, Y - 2.6 * s); ctx.lineTo(X + 4.5 * s, Y - 5 * s); ctx.lineTo(X + 4 * s, Y); ctx.closePath(); ctx.fill();
    }
    const ROLE_COL = { vag: ['#4f4a44', '#3e3a36'], pea: ['#6a5c4a', '#4a4036'], arc: ['#4c5643', '#3a4234'], bld: ['#6a5038', '#4a3a2a'], far: ['#7a6a48', '#5a4c34'], kni: ['#6e6c6a', '#6e2a2a'] };
    function drawPerson(X, u, t, lit) {
      const z = Z, c = ROLE_COL[u.t] || ROLE_COL.pea, sh = (cc, k) => rgb(mixA(hex(cc), [8, 9, 14], (1 - lit) * (k == null ? 0.6 : k)));
      let Y = GY;
      if (u.tw) Y = GY - (u.tw >= 2 ? 48 : 44) * z;
      const walk = u.mv ? Math.sin(t * 10 + u.i) : 0, dir = u.dir || 1;
      const hgt = (u.t === 'kni' ? 19 : 17) * z;
      // 다리
      ctx.strokeStyle = sh('#2a241e'); ctx.lineWidth = 1.6 * z;
      ctx.beginPath(); ctx.moveTo(X - 1.5 * z, Y - 6 * z); ctx.lineTo(X - 1.5 * z + walk * 2 * z, Y); ctx.moveTo(X + 1.5 * z, Y - 6 * z); ctx.lineTo(X + 1.5 * z - walk * 2 * z, Y); ctx.stroke();
      // 몸
      ctx.fillStyle = sh(c[0]);
      ctx.beginPath(); ctx.moveTo(X - 3.4 * z, Y - 5.5 * z); ctx.lineTo(X - 2.6 * z, Y - hgt + 5 * z); ctx.lineTo(X + 2.6 * z, Y - hgt + 5 * z); ctx.lineTo(X + 3.4 * z, Y - 5.5 * z); ctx.fill();
      if (u.t === 'kni') { ctx.fillStyle = sh(c[1], 0.5); ctx.fillRect(X - 2 * z, Y - hgt + 6 * z, 4 * z, 7 * z); }
      // 머리
      ctx.fillStyle = sh(u.t === 'kni' ? '#7a7876' : '#c2ab90', 0.65); ctx.beginPath(); ctx.arc(X, Y - hgt + 2.6 * z, 2.5 * z, 0, 7); ctx.fill();
      if (u.t === 'arc') { ctx.fillStyle = sh(c[1]); ctx.beginPath(); ctx.moveTo(X - 2.8 * z, Y - hgt + 3 * z); ctx.lineTo(X, Y - hgt - 1.6 * z); ctx.lineTo(X + 2.8 * z, Y - hgt + 3 * z); ctx.fill(); }
      if (u.t === 'far') { ctx.fillStyle = sh('#9a8a5a'); ctx.fillRect(X - 4 * z, Y - hgt + 0.8 * z, 8 * z, 1.4 * z); ctx.fillRect(X - 2 * z, Y - hgt - 0.8 * z, 4 * z, 1.8 * z); }
      if (u.t === 'vag') { ctx.fillStyle = sh('#3a3632'); ctx.fillRect(X - 3.4 * z, Y - 9 * z, 6.8 * z, 1.4 * z); }
      // 도구
      const hx = X + dir * 3.4 * z, hy = Y - hgt * 0.62;
      ctx.save(); ctx.translate(hx, hy); ctx.scale(dir, 1);
      ctx.strokeStyle = sh('#7a6650'); ctx.lineWidth = 1.1 * z;
      if (u.t === 'arc') { ctx.beginPath(); ctx.arc(-1 * z, 0, 5.5 * z, -1.2, 1.2); ctx.stroke(); }
      else if (u.t === 'bld') { const sw = u.wk ? Math.sin(t * 9 + u.i) * 0.9 : 0.3; ctx.rotate(sw); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -6 * z); ctx.stroke(); ctx.fillStyle = sh('#6a6a6a'); ctx.fillRect(-2 * z, -7.5 * z, 4 * z, 2 * z); }
      else if (u.t === 'far') { const sw = u.wk ? Math.sin(t * 4 + u.i) * 0.6 : 0; ctx.rotate(sw); ctx.beginPath(); ctx.moveTo(0, 4 * z); ctx.lineTo(0, -8 * z); ctx.stroke(); ctx.strokeStyle = sh('#9a9a9a'); ctx.beginPath(); ctx.arc(-3 * z, -8 * z, 3.4 * z, -0.2, 1.4); ctx.stroke(); }
      else if (u.t === 'kni') { ctx.fillStyle = sh('#6e6a66'); ctx.fillRect(0, -3 * z, 3 * z, 7 * z); ctx.strokeStyle = sh('#a8a8a8'); ctx.beginPath(); ctx.moveTo(-1 * z, 2 * z); ctx.lineTo(-1 * z, -9 * z); ctx.stroke(); }
      ctx.restore();
      if (u.cc) drawCoin(X - dir * 3 * z, Y - hgt * 0.45, z * 0.7, t);
    }
    function drawDeer(X, u, t, lit) {
      const z = Z, sh = (c) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * 0.6)), dir = u.dir || 1, walk = u.mv ? Math.sin(t * 12 + u.i) : 0;
      ctx.save(); ctx.translate(X, GY); ctx.scale(dir, 1);
      ctx.strokeStyle = sh('#4a3a2c'); ctx.lineWidth = 1.2 * z;
      ctx.beginPath(); ctx.moveTo(-5 * z, -7 * z); ctx.lineTo(-5 * z + walk * 1.5 * z, 0); ctx.moveTo(5 * z, -7 * z); ctx.lineTo(5 * z - walk * 1.5 * z, 0); ctx.stroke();
      ctx.fillStyle = sh('#6a5440'); ctx.beginPath(); ctx.ellipse(0, -9 * z, 7 * z, 3.4 * z, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.moveTo(5 * z, -10 * z); ctx.lineTo(9 * z, -16 * z); ctx.lineTo(11 * z, -15 * z); ctx.lineTo(7 * z, -8 * z); ctx.fill();
      ctx.restore();
    }
    function drawGreed(X, e, t, lit) {
      const z = Z, dir = e.dir || -1;
      const big = e.t === 'r' ? 2.1 : e.t === 'c' ? 1.35 : 1, Y = GY - (e.y || 0) * z;
      const bob = Math.sin(t * 8 + e.i) * 1 * z;
      ctx.save(); ctx.translate(X, Y); ctx.scale(dir, 1);
      const body = e.hit ? '#3a3046' : '#120f17';
      ctx.fillStyle = body;
      if (e.t === 'f') {
        const fl = Math.sin(t * 10 + e.i) * 6 * z;
        ctx.beginPath(); ctx.moveTo(-3 * z, 0); ctx.lineTo(-14 * z, -6 * z + fl); ctx.lineTo(-6 * z, -2 * z); ctx.lineTo(0, -4 * z); ctx.lineTo(6 * z, -2 * z); ctx.lineTo(14 * z, -6 * z + fl); ctx.lineTo(3 * z, 0); ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.ellipse(0, 0, 4 * z, 5 * z, 0, 0, 7); ctx.fill();
      } else {
        ctx.beginPath();
        ctx.moveTo(-6 * z * big, 0); ctx.quadraticCurveTo(-7 * z * big, -12 * z * big + bob, 0, -14 * z * big + bob); ctx.quadraticCurveTo(7 * z * big, -12 * z * big + bob, 6 * z * big, 0); ctx.closePath(); ctx.fill();
        // 팔
        ctx.strokeStyle = body; ctx.lineWidth = 1.6 * z * big; const sw = e.st === 1 ? Math.sin(t * 10 + e.i) * 3 : 1;
        ctx.beginPath(); ctx.moveTo(3 * z * big, -8 * z * big); ctx.lineTo((8 + sw) * z * big, -2 * z * big); ctx.stroke();
        if (e.t === 'r') { ctx.fillStyle = '#18141e'; ctx.beginPath(); ctx.arc(-3 * z * big, -15 * z * big, 4 * z, 0, 7); ctx.arc(2 * z * big, -16 * z * big, 3.4 * z, 0, 7); ctx.fill(); }
        if (e.t === 'c') { ctx.strokeStyle = '#2a2430'; ctx.lineWidth = 1 * z; ctx.beginPath(); ctx.moveTo((8 + sw) * z * big, -2 * z * big); ctx.lineTo((11 + sw) * z * big, 0); ctx.stroke(); }
      }
      // 눈
      ctx.fillStyle = 'rgba(214,170,110,0.75)';
      const ey = e.t === 'f' ? -1 * z : (-10 * z * big + bob);
      ctx.fillRect(1.2 * z * big, ey, 1.3 * z, 1.3 * z); ctx.fillRect(3.4 * z * big, ey, 1.3 * z, 1.3 * z);
      ctx.restore();
      // 들고 가는 것
      if (e.loot === 1) drawCoin(X, Y - 18 * z * big, z * 0.8, t);
      else if (e.loot >= 10) drawCrown(X, Y - 18 * z * big, z * 1.1);
      else if (e.loot === 2) { ctx.fillStyle = 'rgba(138,118,96,0.9)'; ctx.fillRect(X - 3 * z, Y - 19 * z * big, 6 * z, 1.4 * z); }
    }
    function drawMountBody(X, Y, mt, dir, t, gal, mv, lit, alpha) {
      const z = Z, M = MOUNTS[mt] || MOUNTS.steed, col = M.col;
      const sh = (c, k) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * (k == null ? 0.55 : k)));
      const big = mt === 'draft' ? 1.12 : mt === 'courser' ? 0.96 : 1;
      ctx.save(); ctx.translate(X, Y); ctx.scale(dir * big, big); ctx.globalAlpha = alpha == null ? 1 : alpha;
      const ph = t * (gal ? 15 : 9), amp = mv ? (gal ? 1 : 0.55) : 0;
      // 다리
      ctx.strokeStyle = sh(col, 0.65); ctx.lineWidth = 2 * z; ctx.lineCap = 'round';
      const leg = (x, o) => { const a = Math.sin(ph + o) * amp; ctx.beginPath(); ctx.moveTo(x * z, -13 * z); ctx.lineTo((x + a * 4) * z, -6 * z); ctx.lineTo((x + a * 5.5) * z, 0); ctx.stroke(); };
      leg(-9, 0); leg(-6, Math.PI); leg(8, Math.PI * 0.5); leg(11, Math.PI * 1.5);
      ctx.lineCap = 'butt';
      // 몸
      const by = gal ? Math.sin(ph * 2) * 0.8 * z : 0;
      ctx.fillStyle = sh(col);
      ctx.beginPath(); ctx.ellipse(1 * z, -16 * z + by, 13 * z, 5.6 * z, 0, 0, 7); ctx.fill();
      // 목·머리
      ctx.beginPath(); ctx.moveTo(9 * z, -19 * z + by); ctx.lineTo(15 * z, -28 * z + by); ctx.lineTo(19 * z, -27 * z + by); ctx.lineTo(21 * z, -22 * z + by); ctx.lineTo(18 * z, -21 * z + by); ctx.lineTo(13 * z, -14 * z + by); ctx.fill();
      // 꼬리
      ctx.strokeStyle = sh(mt === 'stag' ? '#b8ae9a' : '#1c1814'); ctx.lineWidth = 1.6 * z;
      ctx.beginPath(); ctx.moveTo(-12 * z, -18 * z + by); ctx.quadraticCurveTo(-17 * z, -14 * z + (gal ? -3 : 0) * z, -16 * z, -8 * z); ctx.stroke();
      if (mt === 'stag') { ctx.strokeStyle = sh('#d8d0c0', 0.45); ctx.lineWidth = 1 * z; ctx.beginPath(); ctx.moveTo(16 * z, -28 * z + by); ctx.lineTo(14 * z, -35 * z + by); ctx.lineTo(11 * z, -37 * z + by); ctx.moveTo(14 * z, -33 * z + by); ctx.lineTo(17 * z, -36 * z + by); ctx.moveTo(18 * z, -28 * z + by); ctx.lineTo(20 * z, -34 * z + by); ctx.lineTo(23 * z, -35 * z + by); ctx.stroke(); }
      else { ctx.strokeStyle = sh('#1c1814'); ctx.lineWidth = 1.4 * z; ctx.beginPath(); ctx.moveTo(10 * z, -20 * z + by); ctx.lineTo(15 * z, -27 * z + by); ctx.stroke(); }
      if (mt === 'barded') { ctx.fillStyle = sh('#4a4a4c'); ctx.beginPath(); ctx.ellipse(1 * z, -16.5 * z + by, 12 * z, 4.6 * z, 0, Math.PI, 0); ctx.fill(); ctx.fillStyle = sh('#6e2a2a', 0.5); ctx.fillRect(-11 * z, -14 * z + by, 24 * z, 1.4 * z); }
      ctx.restore(); ctx.globalAlpha = 1;
    }
    function drawMonarch(X, m, s, t, lit) {
      const z = Z, dir = m.dir || 1, gal = m.g, mv = Math.abs(m.v || 0) > 3 || (!host() && s !== me() && m.g);
      const pc = (P(s).color || '#8a6a4a');
      if (m.inv > 0 && Math.floor(t * 12) % 2) ctx.globalAlpha = 0.55;
      drawMountBody(X, GY, m.mt, dir, t, gal, mv || gal, lit);
      ctx.globalAlpha = m.inv > 0 && Math.floor(t * 12) % 2 ? 0.55 : 1;
      const by = gal ? Math.sin(t * 30) * 0.8 * z : 0;
      // 기수
      const cx = X + dir * 1 * z, cy = GY - 21 * z + by;
      const sh = (c, k) => rgb(mixA(hex(c), [8, 9, 14], (1 - lit) * (k == null ? 0.5 : k)));
      ctx.fillStyle = sh(mix(pc, '#2a2228', 0.45)); // 망토
      ctx.beginPath(); ctx.moveTo(cx - 2 * dir * z, cy - 10 * z); ctx.quadraticCurveTo(cx - dir * (9 + (gal ? 4 : 0)) * z, cy - 4 * z, cx - dir * (8 + (gal ? 5 : 0)) * z, cy + 4 * z); ctx.lineTo(cx + dir * 1 * z, cy + 2 * z); ctx.fill();
      ctx.fillStyle = sh('#3a3236'); ctx.fillRect(cx - 2.6 * z, cy - 10 * z, 5.2 * z, 10 * z);
      ctx.fillStyle = sh('#c2ab90', 0.6); ctx.beginPath(); ctx.arc(cx + dir * 0.5 * z, cy - 12.6 * z, 2.6 * z, 0, 7); ctx.fill();
      if (m.cr) drawCrown(cx + dir * 0.5 * z, cy - 14.4 * z, z * 0.62);
      ctx.globalAlpha = 1;
      // 지구력
      if (m.sta < 0.98 && (gal || m.sta < 0.5) && s === focusSeat()) {
        const bw = Math.max(26, 18 * z), by2 = GY + 4.5 * z, bh = Math.max(3.5, 2 * z);
        ctx.fillStyle = 'rgba(8,8,12,0.6)'; ctx.fillRect(X - bw / 2 - 1, by2 - 1, bw + 2, bh + 2);
        ctx.fillStyle = m.sta < 0.2 ? 'rgba(230,120,96,0.95)' : 'rgba(226,190,116,0.92)'; ctx.fillRect(X - bw / 2, by2, bw * m.sta, bh);
      }
      // 금화를 내는 중
      if (m.hold && m.cr && s === focusSeat() && !m.mk) { ctx.fillStyle = 'rgba(214,180,110,0.35)'; ctx.beginPath(); ctx.arc(cx, cy - 22 * z, 2.2 * z, 0, 7); ctx.fill(); }
      if (gal && Math.random() < 0.4 && parts.length < 240) parts.push({ x: m.x - dir * 10, y: 1, vx: -dir * 20, vy: 8, life: 0.5, t: 0, col: '#6a5a48', dust: 1, r: 1.6 });
      // 남의 자리 표시(협동)
      if (W.n > 1) { ctx.fillStyle = pc; ctx.globalAlpha = 0.7; ctx.beginPath(); ctx.moveTo(cx - 2 * z, cy - 24 * z); ctx.lineTo(cx + 2 * z, cy - 24 * z); ctx.lineTo(cx, cy - 21 * z); ctx.fill(); ctx.globalAlpha = 1; }
    }
    /* 표시: 가까이 있을 때만 금화 자리 동그라미 + 짧은 이름 */
    let C0c = null, C0t = -1;
    function C0() { if (!C0c || C0t !== W.t) { C0c = ctxOf(W); C0t = W.t; } return C0c; }
    function markerName(o, C) {
      switch (o.k) {
        case 'town': return TOWN.n[o.lv + 1];
        case 'wall': return o.br ? WALL.n[o.lv] + ' 보수' : WALL.n[o.lv + 1];
        case 'tower': return TOWER.n[o.lv + 1];
        case 'farm': return FARM.n[o.lv + 1];
        case 'shop': return TOOLS[o.t].n;
        case 'boat': return o.lv < 3 ? BOAT.n[o.lv + 1] : (W.n > 1 ? '출항 · 함께 타야 함' : '출항');
        case 'bomb': return '폭약';
        case 'mount': return MOUNTS[o.t].n;
        case 'asl': return '돌격';
      }
      return '';
    }
    function drawMarkers(lit, t) {
      const fm = W.M[focusSeat()]; if (!fm || !fm.cr) return;
      const C = C0(), z = Z, us = (L.ui && L.ui.scale ? L.ui.scale() : 1);
      const list = [];
      for (const o of W.S) { const c = costOf(W, C, o); if (c && Math.abs(o.x - fm.x) < 90) list.push([o, c, o.paid || 0]); }
      for (const si of [0, 1]) { const a = aslSpot(W, C, si); if (a && Math.abs(a.x - fm.x) < 90) list.push([a, 3, W.aslPaid ? W.aslPaid[si] : 0]); }
      let nearest = null, nd = PAY_R; for (const q of list) { const d = Math.abs(q[0].x - fm.x); if (d < nd) { nd = d; nearest = q[0]; } }
      for (const [o, c, paid] of list) {
        const d = Math.abs(o.x - fm.x), a = o === nearest ? 1 : clamp(1 - d / 80, 0, 1) * 0.4;
        if (a <= 0.02) continue;
        const X = SX(o.x), top = markerTop(o) * z, Y = GY - top - 16 * z;
        // 가독성: 금화 자리는 4px 이상, 이름은 13px 이상 + 어두운 받침
        const r = Math.max(4.2, 2.9 * z), gap = Math.max(11, 7.6 * z), n = c, x0 = X - (n - 1) * gap / 2;
        ctx.globalAlpha = a;
        if (o === nearest) { ctx.fillStyle = 'rgba(8,8,12,0.5)'; const pw = (n - 1) * gap + r * 2 + 10; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(X - pw / 2, Y - r - 4, pw, r * 2 + 8, r + 4) : ctx.rect(X - pw / 2, Y - r - 4, pw, r * 2 + 8); ctx.fill(); }
        for (let j = 0; j < n; j++) {
          ctx.beginPath(); ctx.arc(x0 + j * gap, Y, r, 0, 7);
          if (j < paid) { ctx.fillStyle = '#e6bd55'; ctx.fill(); ctx.strokeStyle = 'rgba(70,50,20,0.9)'; ctx.lineWidth = 1; ctx.stroke(); }
          else { ctx.strokeStyle = 'rgba(240,226,190,0.95)'; ctx.lineWidth = Math.max(1.4, 1 * z); ctx.stroke(); }
        }
        if (o === nearest) {
          const fsz = Math.max(13, Math.round(11 * us * Math.max(1, z * 0.9)));
          ctx.font = '600 ' + fsz + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
          const nmT = markerName(o, C) + ' · ' + c + '닢', tw = ctx.measureText(nmT).width + 14, ly = Y - r - 7;
          ctx.fillStyle = 'rgba(8,8,12,0.62)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(X - tw / 2, ly - fsz - 3, tw, fsz + 7, 6) : ctx.rect(X - tw / 2, ly - fsz - 3, tw, fsz + 7); ctx.fill();
          ctx.fillStyle = '#f3e8cf'; ctx.fillText(nmT, X, ly + 1);
        }
        ctx.globalAlpha = 1;
      }
      // 떠돌이 위 작은 금화 자리
      for (const u of W.u) if (u.t === 'vag' && Math.abs(u.x - fm.x) < 50) { const X = SX(disp.has(u.i) && !host() ? disp.get(u.i) : u.x), a = clamp(1.4 - Math.abs(u.x - fm.x) / 40, 0, 1) * 0.8; ctx.globalAlpha = a; ctx.strokeStyle = 'rgba(240,226,190,0.95)'; ctx.lineWidth = Math.max(1.4, 1 * z); ctx.beginPath(); ctx.arc(X, GY - 25 * z, Math.max(4, 2.6 * z), 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
      void lit; void t;
    }
    function markerTop(o) {
      switch (o.k) { case 'town': return o.lv ? 34 + o.lv * 14 + (o.lv >= 3 ? 34 : 0) : 28; case 'wall': return [16, 26, 32, 42, 46][o.lv] || 20; case 'tower': return 54; case 'boat': return o.lv >= 3 ? 64 : 22; case 'shop': return 26; case 'mount': return 36; case 'farm': return 20; case 'bomb': return 18; case 'asl': return 30; }
      return 24;
    }
    /* ----- 밤 빛 ----- */
    function drawLight(w, h, tf) {
      const dk = darkOf(tf); if (dk <= 0.01) return;
      const lw = Math.max(1, Math.round(w / 2)), lh = Math.max(1, Math.round(GY / 2) + 4);
      if (!lc || lc.width !== lw || lc.height !== lh) { lc = document.createElement('canvas'); lc.width = lw; lc.height = lh; lcc = lc.getContext('2d'); }
      const c = lcc;
      c.globalCompositeOperation = 'source-over'; c.clearRect(0, 0, lw, lh);
      c.fillStyle = W.bmn ? 'rgba(14,4,6,' + dk + ')' : 'rgba(6,8,16,' + dk + ')'; c.fillRect(0, 0, lw, lh);
      c.globalCompositeOperation = 'destination-out';
      const hole = (x, y, r, a) => { const X = SX(x) / 2, Y = (GY - y * Z) / 2, R = r * Z / 2; if (X < -R || X > lw + R) return; const g = c.createRadialGradient(X, Y, 0, X, Y, R); g.addColorStop(0, 'rgba(0,0,0,' + a + ')'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.beginPath(); c.arc(X, Y, R, 0, 7); c.fill(); };
      const C = C0();
      hole(0, 10, 120 + C.town.lv * 25, 0.95);
      for (const o of W.S) { if ((o.k === 'wall' && o.lv >= 2 && !o.br) || (o.k === 'tower' && o.lv > 0)) hole(o.x, o.k === 'tower' ? 40 : 30, 70, 0.8); }
      W.camps.forEach((x) => hole(x + 10, 6, 55, 0.7));
      W.M.forEach((m) => { if (!W.sail) hole(m.x, 24, 80, 0.75); });
      if (W.bm) hole(W.bm.x, 14, 40, 0.6);
      c.globalCompositeOperation = 'source-over';
      ctx.drawImage(lc, 0, 0, lw, lh, 0, 0, w, lh * 2);
      // 불빛 따뜻함
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const glow = (x, y, r, a) => { const X = SX(x), Y = GY - y * Z, R = r * Z; if (X < -R || X > w + R) return; const g = ctx.createRadialGradient(X, Y, 0, X, Y, R); g.addColorStop(0, 'rgba(160,90,40,' + a + ')'); g.addColorStop(1, 'rgba(160,90,40,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.fill(); };
      const fl = 0.9 + 0.1 * Math.sin(realNow * 0.013);
      glow(0, 8, 80 + C.town.lv * 12, 0.42 * dk * fl);
      for (const o of W.S) if ((o.k === 'wall' && o.lv >= 2 && !o.br) || (o.k === 'tower' && o.lv > 0)) glow(o.x, o.k === 'tower' ? 44 : 34, 40, 0.32 * dk * fl);
      W.camps.forEach((x) => glow(x + 10, 4, 30, 0.16 * dk * fl));
      W.P.forEach((p) => { if (p.al) { const X = SX(p.x), Y = GY - 30 * Z, R = 50 * Z; if (X > -R && X < w + R) { const g = ctx.createRadialGradient(X, Y, 0, X, Y, R); g.addColorStop(0, 'rgba(70,30,90,' + 0.25 * dk + ')'); g.addColorStop(1, 'rgba(70,30,90,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.fill(); } } });
      ctx.restore();
      void h;
    }
    /* ----- 물(반사) ----- */
    function drawWater(w, h, tf, sky, now) {
      const top = WL, hh = h - top; if (hh <= 2) return;
      const dpr = cv.dpr;
      const srcH = Math.min(top, hh * 1.05);
      const rw = Math.max(1, Math.round(w / 2)), rh = Math.max(1, Math.round(srcH / 2));
      if (!rb || rb.width !== rw || rb.height !== rh) { rb = document.createElement('canvas'); rb.width = rw; rb.height = rh; rbc = rb.getContext('2d'); }
      try { rbc.clearRect(0, 0, rw, rh); rbc.drawImage(cv.cv, 0, Math.round((top - srcH) * dpr), Math.round(w * dpr), Math.round(srcH * dpr), 0, 0, rw, rh); } catch (e) { return; }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = rgb(mixA(sky.bot, [6, 8, 12], 0.72)); ctx.fillRect(0, top, w, hh);
      const tt = now / 1000, step = 2;
      ctx.globalAlpha = 0.5;
      for (let y = 0; y < Math.min(hh, srcH); y += step) {
        const k = y / Math.max(1, srcH), amp = (1 + k * 6) * Math.sin(y * 0.22 + tt * 1.6) + Math.sin(y * 0.07 - tt * 0.9) * k * 3;
        const sy = rh - 1 - (y / 2);
        if (sy < 0) break;
        ctx.drawImage(rb, 0, sy, rw, 1, amp - 14, top + y, w + 28, step);
      }
      ctx.globalAlpha = 1;
      const g = ctx.createLinearGradient(0, top, 0, h);
      g.addColorStop(0, rgb(mixA(sky.bot, [6, 8, 12], 0.5), 0.25)); g.addColorStop(1, rgb([6, 8, 12], 0.75));
      ctx.fillStyle = g; ctx.fillRect(0, top, w, hh);
      // 물결 빛
      ctx.strokeStyle = rgb(mixA(sky.bot, [240, 236, 220], 0.4), 0.10 + 0.1 * sky.lit); ctx.lineWidth = 1;
      for (let j = 0; j < 14; j++) { const y = top + 4 + hash(j * 17) * (hh - 8), x = ((hash(j * 5) * w * 1.3 - camX * Z * 0.9 + tt * 6 * (j % 3 + 1)) % (w + 60) + w + 60) % (w + 60) - 30, ln = 10 + hash(j) * 30; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + ln, y); ctx.stroke(); }
      ctx.fillStyle = rgb(mixA(sky.bot, [10, 12, 16], 0.3), 0.6); ctx.fillRect(0, top, w, 1);
    }
    function drawParticles(dt, tf) {
      const z = Z;
      for (let j = parts.length - 1; j >= 0; j--) {
        const p = parts[j]; p.t += dt; if (p.t >= p.life) { parts.splice(j, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt; p.vy -= (p.wisp ? -10 : p.dust ? 0 : 140) * dt; if (p.y < 0 && !p.wisp) { p.y = 0; p.vy *= -0.3; p.vx *= 0.6; }
        const a = 1 - p.t / p.life;
        ctx.fillStyle = p.col; ctx.globalAlpha = a * (p.dust ? 0.35 : 0.9);
        ctx.fillRect(SX(p.x) - p.r * z / 2, GY - p.y * z - p.r * z / 2, p.r * z, p.r * z);
      }
      ctx.globalAlpha = 1;
      // 눈·불티
      if (seasonOf(W.day) === 3) {
        ctx.fillStyle = 'rgba(230,232,236,0.55)';
        for (let j = 0; j < 50; j++) { const sx = ((hash(j * 7) * cv.w * 1.4 + realNow * 0.01 * (0.4 + hash(j))) % cv.w + cv.w) % cv.w, sy = ((hash(j * 11) * cv.h + realNow * 0.03 * (0.6 + hash(j * 2))) % cv.h); ctx.fillRect(sx, sy, 1.4, 1.4); }
      }
      void tf;
    }
    /* ----- HUD ----- */
    function drawHUD(w, h, tf, now, dt) {
      const us = (L.ui && L.ui.scale ? L.ui.scale() : 1), z = Math.max(1, Math.min(1.5, Z));
      const fs = focusSeat(), m = W.M[fs];
      // 지갑
      const purse = (x, y, mm, main) => {
        const s = (main ? 1 : 0.78) * us * z;
        ctx.save(); ctx.translate(x, y);
        ctx.fillStyle = 'rgba(10,10,14,0.55)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(-6 * s, -14 * s, 80 * s, 28 * s, 9 * s) : ctx.rect(-6 * s, -14 * s, 80 * s, 28 * s); ctx.fill();
        ctx.fillStyle = '#5a4430'; ctx.beginPath(); ctx.ellipse(8 * s, 3 * s, 8 * s, 8.5 * s, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#3e2e20'; ctx.fillRect(4 * s, -7 * s, 8 * s, 3 * s);
        ctx.strokeStyle = '#c9a24a'; ctx.lineWidth = 1 * s; ctx.beginPath(); ctx.moveTo(3 * s, -5 * s); ctx.lineTo(13 * s, -5 * s); ctx.stroke();
        if (!mm.cr) { ctx.strokeStyle = 'rgba(200,110,90,0.9)'; ctx.lineWidth = 1.6 * s; ctx.beginPath(); ctx.moveTo(1 * s, -6 * s); ctx.lineTo(15 * s, 10 * s); ctx.stroke(); }
        ctx.font = '600 ' + Math.round(15 * s) + 'px ' + MONO; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillStyle = mm.pu >= capOf(mm) ? '#e0c27a' : 'rgba(240,232,214,0.92)';
        L.ui && L.ui.strokeText ? L.ui.strokeText(ctx, String(mm.pu), 22 * s, 1 * s) : ctx.fillText(String(mm.pu), 22 * s, 1 * s);
        ctx.font = '500 ' + Math.max(12, Math.round(11 * s)) + 'px ' + MONO; ctx.fillStyle = 'rgba(226,216,196,0.85)'; ctx.fillText('/' + capOf(mm), (22 + 9 * String(mm.pu).length) * s + 2 * s, 3 * s);
        ctx.restore();
      };
      const px = 14, py = 22 * us * z;
      purse(px + 6, py, m, true);
      if (W.n > 1) { const o = W.M[1 - fs]; if (o) { purse(px + 6 + 88 * us * z, py, o, false); ctx.fillStyle = P(1 - fs).color || '#888'; ctx.beginPath(); ctx.arc(px + 6 + 88 * us * z - 2, py - 10 * us * z, 2.5, 0, 7); ctx.fill(); } }
      // 작은 줄: 섬 · 날 · 계절
      ctx.font = '500 ' + Math.max(13, Math.round(12 * us)) + 'px ' + FONT; ctx.textAlign = 'left'; ctx.textBaseline = 'top'; ctx.fillStyle = 'rgba(240,232,214,0.94)';
      const line = (W.trial ? '연습 섬' : isleName(W.k) + (W.nI > 1 ? ' / ' + W.nI : '')) + ' · ' + dayName(W.day) + ' · ' + SEASONS[seasonOf(W.day)];
      oText(line, px, py + 17 * us * z);
      // 동료가 화면 밖
      if (W.n > 1) {
        const o = W.M[1 - fs]; if (o && !W.sail) { const X = SX(o.x); if (X < 0 || X > w) { const right = X > w; ctx.fillStyle = P(1 - fs).color || '#999'; ctx.globalAlpha = 0.7; const ax = right ? w - 10 : 10, ay = GY - 30 * Z; ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax + (right ? -8 : 8), ay - 6); ctx.lineTo(ax + (right ? -8 : 8), ay + 6); ctx.fill(); ctx.globalAlpha = 1; } }
      }
      // 알림(작게·반투명·짧게)
      let ny = h * (w >= h ? 0.13 : 0.1);
      for (let j = notes.length - 1; j >= 0; j--) {
        const n = notes[j]; n.a += dt; if (n.a >= n.life) { notes.splice(j, 1); continue; }
        const al = Math.min(1, n.a / 0.15, (n.life - n.a) / 0.35);
        ctx.font = '500 ' + Math.round(13 * us) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const tw = ctx.measureText(n.t).width + 22;
        ctx.globalAlpha = al * 0.9; ctx.fillStyle = 'rgba(10,10,14,0.6)'; ctx.fillRect(w / 2 - tw / 2, ny - 12 * us, tw, 24 * us);
        ctx.fillStyle = 'rgba(236,226,206,0.95)'; ctx.fillText(n.t, w / 2, ny); ctx.globalAlpha = 1;
        ny += 28 * us;
      }
      // 섬 이름 카드(섬에 닿을 때)
      if (isleCard > 0) {
        isleCard -= dt; const a = Math.min(1, isleCard / 0.6, (2.6 - isleCard) / 0.5);
        ctx.globalAlpha = clamp(a, 0, 1) * 0.92; ctx.font = '400 ' + Math.round(20 * us) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#e6dcc6';
        oText(W.trial ? '연습 섬' : isleName(isleCardK >= 0 ? isleCardK : W.k), w / 2, GY * 0.4);
        ctx.font = '500 ' + Math.max(13, Math.round(13 * us)) + 'px ' + FONT; ctx.fillStyle = 'rgba(236,228,210,0.92)';
        oText(W.trial ? '배는 거의 다 고쳐 둠' : W.k === 0 ? '모닥불 하나와 금화 몇 닢' : '탐욕은 더 거세짐', w / 2, GY * 0.4 + 22 * us);
        ctx.globalAlpha = 1;
      }
      // 섬을 떠남(검게)
      if (W.trans > 0 || (W.sail && W.sail.t > 2.4)) {
        const a = W.trans > 0 ? clamp(1 - Math.abs(W.trans - 1.1) / 1.1, 0, 1) * 0.6 + 0.4 : clamp((W.sail.t - 2.4) / 0.8, 0, 1);
        ctx.fillStyle = 'rgba(6,7,10,' + a + ')'; ctx.fillRect(0, 0, w, h);
        if (W.trans > 0) { ctx.globalAlpha = a; ctx.font = '400 ' + Math.round(17 * us) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#d8ccb4'; ctx.fillText(W.k + 1 >= W.nI ? '먼 바다로' : isleName(W.k + 1) + '으로', w / 2, h * 0.45); ctx.globalAlpha = 1; }
      }
      if (flash > 0) { ctx.fillStyle = 'rgba(160,40,30,' + (flash * 0.35 * fxAmt()) + ')'; ctx.fillRect(0, 0, w, h); flash = Math.max(0, flash - dt * 1.5); }
      // 비네트
      const vg = ctx.createRadialGradient(w / 2, h * 0.45, Math.min(w, h) * 0.35, w / 2, h * 0.5, Math.max(w, h) * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.38)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, w, h);
      void now;
    }

    const stopLoop = U.loop((rdt, now) => {
      const dt = Math.min(0.05, (now - (lastNow || now)) / 1000); lastNow = now;
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now, dt); } catch (e) { console.error(e); }
    });
    layoutCtl();

    return {
      update(next) {
        if (!next) return;
        st = next;
        const k = curKey();
        if (k !== key) { key = k; build(); layoutCtl(); }
      },
      destroy() {
        stopLoop(); offIn();
        window.removeEventListener('lounge-ctl', onCtl);
        cv.cv.removeEventListener('pointerdown', onDownCanvas); cv.cv.removeEventListener('contextmenu', noCtx);
        dismissTip(); ui.remove(); styleEl.remove(); cv.destroy();
      },
      saveState() {
        if (!host() || !W || W.over || !st || st.ph !== 'play') return false;
        st.svd = (W.trial ? '연습 섬' : isleName(W.k)) + ' · ' + dayName(W.day);
        const o = Object.assign({}, W); delete o._trees; delete o._treesK;
        return { rid: st.rid, w: JSON.stringify(o) };
      },
      loadState(b) {
        if (!b || !b.w || !st || b.rid !== st.rid) return;
        try { W = JSON.parse(b.w); acc = 0; mems = [{}, {}]; lastFq = W.fq; camInit = false; doneAt = 0; doneSent = false; isleCard = 2.4; isleCardK = W.k; } catch (e) { console.error(e); }
      },
      _dbg: () => ({ W, st, camX, Z, GY, pack: () => (W ? JSON.stringify(packHost()).length : 0) }),
    };
  }

  /* ======================= 상황 도움말 · 도감 · 미리보기 ======================= */
  function hint(s) {
    if (!s || s.ph !== 'play') return null;
    const d = s.day || 1, k = s.isl || 0;
    const where = (s.nI ? isleName(k) + ' / ' + s.nI : '연습 섬') + ' · ' + dayName(d) + ' · ' + SEASONS[seasonOf(d)];
    const tips = [where];
    if (d <= 2) tips.push('먼저 떠돌이에게 한 닢씩 주어 백성을 모으고, 망치(3닢)와 활(2닢)을 공방 선반에 올려 둠. 백성이 집어 들면 일꾼·궁수가 됨.');
    else tips.push('밤마다 무리가 커짐. 바깥 성벽을 높이고(장원을 키우면 더 높은 단계) 궁수를 늘리면 버팀.');
    tips.push('해가 지면 성벽 안으로. 왕관이 균열 너머로 넘어가면 끝.');
    tips.push('농부(낫 3닢)는 장원부터. 밭은 겨울에 쉼. 궁수는 낮에 사슴을 사냥해 금화를 들고 옴 — 곁을 지나가면 건네줌.');
    tips.push('섬을 떠나려면 오른쪽 끝 부두의 난파선을 세 번 고쳐 출항. 기사와 폭약으로 균열을 모두 닫아도 섬을 넘어감.');
    if (s.n > 1) tips.push('협동: 출항은 두 군주가 모두 배 곁에 있어야 함. 동료의 왕관을 빼앗기면 쫓아가 되찾을 수 있음.');
    return tips.slice(0, 6);
  }
  const ic = (body) => '<svg viewBox="0 0 32 32" width="28" height="28" fill="currentColor">' + body + '</svg>';
  const IC = {
    town: ic('<path d="M6 28V14l10-7 10 7v14z" opacity=".85"/><rect x="14" y="20" width="4" height="8" fill="#000" opacity=".35"/><path d="M16 7V2l5 2-5 2"/>'),
    wall1: ic('<path d="M7 28V13l2-3 2 3v15zM13 28V11l2-3 2 3v17zM19 28V13l2-3 2 3v15z"/>'),
    wall2: ic('<path d="M5 28V10l2-3 2 3v18zM10 28V9l2-3 2 3v19zM15 28V9l2-3 2 3v19zM20 28V9l2-3 2 3v19zM25 28V10l1.5-3 1.5 3v18z"/>'),
    wall3: ic('<rect x="7" y="9" width="18" height="19"/><path d="M7 14h18M7 19h18M7 24h18" stroke="#000" stroke-opacity=".35"/>'),
    wall4: ic('<rect x="5" y="9" width="22" height="19"/><rect x="5" y="5" width="4" height="4"/><rect x="11" y="5" width="4" height="4"/><rect x="17" y="5" width="4" height="4"/><rect x="23" y="5" width="4" height="4"/>'),
    tower: ic('<path d="M10 28l2-18h8l2 18z"/><rect x="8" y="7" width="16" height="3"/><path d="M8 7V3h2v4zM22 7V3h2v4z"/>'),
    farm: ic('<rect x="3" y="24" width="26" height="4" opacity=".7"/><path d="M5 24v-6M9 24v-8M13 24v-6M17 24v-8M21 24v-6" stroke="currentColor" stroke-width="2"/><path d="M23 24V15l3-3 3 3v9z"/>'),
    bow: ic('<path d="M10 4c10 4 10 20 0 24" fill="none" stroke="currentColor" stroke-width="2.2"/><path d="M10 4v24" stroke="currentColor" stroke-width=".8"/><path d="M6 16h18l-3-2.5M24 16l-3 2.5" fill="none" stroke="currentColor" stroke-width="1.6"/>'),
    hammer: ic('<rect x="15" y="10" width="2.6" height="19" rx="1"/><rect x="9" y="5" width="14" height="6" rx="1"/>'),
    scythe: ic('<rect x="15" y="6" width="2.4" height="23" rx="1"/><path d="M16 6C10 3 4 6 3 12c4-4 8-4 13-3z"/>'),
    shield: ic('<path d="M7 5h18v10c0 7-5 11-9 13-4-2-9-6-9-13z"/><path d="M16 5v23" stroke="#000" stroke-opacity=".35" stroke-width="2.4"/>'),
    boat: ic('<path d="M3 20h26l-4 7H7z"/><rect x="15" y="3" width="2" height="17"/><path d="M17 4c7 4 7 10 0 14z" opacity=".8"/>'),
    bomb: ic('<circle cx="15" cy="19" r="9"/><path d="M20 11l4-5" stroke="currentColor" stroke-width="2"/><circle cx="25" cy="5" r="2" opacity=".7"/>'),
    person: ic('<circle cx="16" cy="7" r="4"/><path d="M10 28l2-15h8l2 15z"/>'),
    vag: ic('<circle cx="16" cy="8" r="4"/><path d="M9 28l3-14h8l3 14z" opacity=".75"/><path d="M8 20h16" stroke="currentColor" stroke-width="1.5" opacity=".6"/>'),
    archer: ic('<circle cx="13" cy="8" r="4"/><path d="M8 28l2-15h7l2 15z"/><path d="M21 6c6 4 6 14 0 18" fill="none" stroke="currentColor" stroke-width="2"/>'),
    builder: ic('<circle cx="12" cy="8" r="4"/><path d="M7 28l2-15h7l2 15z"/><rect x="21" y="8" width="2.4" height="14"/><rect x="18" y="6" width="8" height="4"/>'),
    farmer: ic('<circle cx="12" cy="9" r="4"/><rect x="6" y="5" width="12" height="2"/><path d="M7 28l2-14h7l2 14z"/><rect x="22" y="6" width="2" height="22"/><path d="M23 6c-4-2-8 0-9 4 3-2 6-2 9-1z"/>'),
    knight: ic('<circle cx="13" cy="8" r="4"/><path d="M8 28l2-15h7l2 15z"/><path d="M19 13h8v6c0 4-2 6-4 7-2-1-4-3-4-7z"/>'),
    deer: ic('<ellipse cx="14" cy="17" rx="9" ry="4"/><path d="M20 15l5-8 2 1-3 9z"/><path d="M8 20v8M11 20v8M18 20v8M21 20v8" stroke="currentColor" stroke-width="1.6"/>'),
    horse: ic('<ellipse cx="14" cy="17" rx="10" ry="4.5"/><path d="M20 15l5-9 4 2-2 5-4 4z"/><path d="M7 20v8M10 20v8M18 20v8M21 20v8" stroke="currentColor" stroke-width="1.8"/>'),
    stag: ic('<ellipse cx="14" cy="18" rx="9" ry="4"/><path d="M20 16l4-7 3 2-3 7z"/><path d="M24 9l-2-6M24 9l4-5M22 5l-3-1" stroke="currentColor" stroke-width="1.3" fill="none"/><path d="M8 21v7M11 21v7M18 21v7M21 21v7" stroke="currentColor" stroke-width="1.6"/>'),
    greed: ic('<path d="M7 28C6 18 10 10 16 10s10 8 9 18z"/><rect x="17" y="15" width="2" height="2" fill="#c9a067"/><rect x="21" y="15" width="2" height="2" fill="#c9a067"/>'),
    claw: ic('<path d="M5 28C4 15 9 6 16 6s12 9 11 22z"/><path d="M24 16l6 6M24 19l5 7" stroke="currentColor" stroke-width="1.6"/><rect x="18" y="12" width="2" height="2" fill="#c9a067"/><rect x="22" y="12" width="2" height="2" fill="#c9a067"/>'),
    crusher: ic('<path d="M3 29C2 16 8 8 16 8s14 8 13 21z"/><circle cx="10" cy="7" r="4"/><circle cx="18" cy="5" r="3.4"/><rect x="18" y="14" width="2" height="2" fill="#c9a067"/><rect x="22" y="14" width="2" height="2" fill="#c9a067"/>'),
    wing: ic('<path d="M16 12L2 6l6 8-5 4 9-2 4 6 4-6 9 2-5-4 6-8z"/><rect x="15" y="14" width="1.6" height="1.6" fill="#c9a067"/><rect x="17.4" y="14" width="1.6" height="1.6" fill="#c9a067"/>'),
    portal: ic('<ellipse cx="16" cy="16" rx="9" ry="13" fill="none" stroke="currentColor" stroke-width="3"/><ellipse cx="16" cy="16" rx="5" ry="9" opacity=".5"/>'),
    cliff: ic('<path d="M2 30V4l12 2 6 8-4 16z"/><ellipse cx="22" cy="20" rx="6" ry="9" opacity=".55"/>'),
    island: ic('<path d="M2 22c6-6 22-6 28 0z"/><path d="M14 17l2-9 2 9z"/><path d="M2 26h28" stroke="currentColor" stroke-width="1.2" opacity=".6"/>'),
  };
  function codex() {
    const wallRows = [1, 2, 3, 4].map((lv) => ({ icon: IC['wall' + lv], name: WALL.n[lv], tag: '성벽 ' + lv + '단계', desc: '금화 ' + WALL.cost[lv - 1] + ' · 튼튼함 ' + WALL.hp[lv] + ' · 일 ' + WALL.work[lv - 1] + '초' + (lv > 1 ? ' · ' + TOWN.n[lv - 1] + ' 이상' : '') + '. 무너지면 반값으로 보수.' }));
    return [
      { h: '건물', p: ['표시 앞에서 금화 버튼을 누르고 있으면 동그라미가 하나씩 채워지고, 다 차면 일꾼이 지음. 손을 떼면 낸 금화는 돌아옴.'], rows: [
        { icon: IC.town, name: TOWN.n.slice(1).join(' → '), tag: '장원', desc: '금화 ' + TOWN.cost.join(' / ') + '. 키울수록 높은 성벽·망루·밭·공방이 열림. 모닥불 곁 금고에 백성이 거둔 금화가 쌓임.' },
      ].concat(wallRows, [
        { icon: IC.tower, name: TOWER.n[1] + ' · ' + TOWER.n[2], tag: '망루', desc: '금화 ' + TOWER.cost.join(' / ') + '. 궁수 ' + TOWER.posts[1] + '·' + TOWER.posts[2] + '명이 높은 곳에서 더 멀리(' + TOWER.range[1] + '·' + TOWER.range[2] + ') 더 정확히 쏨. 장원부터.' },
        { icon: IC.farm, name: FARM.n[1] + ' · ' + FARM.n[2], tag: '밭', desc: '금화 ' + FARM.cost.join(' / ') + '. 농부 ' + FARM.slots[1] + '·' + FARM.slots[2] + '명. 일하는 농부 하나가 6초마다 금화 한 닢. 겨울엔 쉼.' },
        { icon: IC.bow, name: SHOP_N.bow, tag: '도구 ' + TOOLS.bow.c + '닢', desc: '활 → 궁수. 낮엔 사냥, 밤엔 성벽과 망루를 지킴. 선반에 4개까지.' },
        { icon: IC.hammer, name: SHOP_N.hammer, tag: '도구 ' + TOOLS.hammer.c + '닢', desc: '망치 → 일꾼. 짓기·고치기·배 수리·폭약 밀기.' },
        { icon: IC.scythe, name: SHOP_N.scythe, tag: '도구 ' + TOOLS.scythe.c + '닢', desc: '낫 → 농부. ' + TOWN.n[1] + '부터.' },
        { icon: IC.shield, name: SHOP_N.shield, tag: '도구 ' + TOOLS.shield.c + '닢', desc: '방패 → 기사. 바깥 성벽 앞에서 몸으로 막음. 돌격을 이끎. ' + TOWN.n[2] + '부터.' },
        { icon: IC.bomb, name: '폭약 공방', tag: '금화 ' + BOMB.c, desc: '일꾼 둘이 폭약 수레를 왼쪽 끝 절벽 균열까지 밀고 감(낮에만). ' + TOWN.n[3] + '부터.' },
        { icon: IC.boat, name: BOAT.n.slice(1).join(' → '), tag: '배', desc: '오른쪽 끝 부두의 난파선. 금화 ' + BOAT.cost.join(' / ') + '(섬마다 +1씩)에 일꾼이 고침. 다 고치면 낮에 2닢으로 출항.' },
      ]) },
      { h: '백성', p: ['떠돌이에게 한 닢 → 백성. 백성은 공방 선반의 도구를 집어 들고 일을 시작함.'], rows: [
        { icon: IC.vag, name: ROLE.vag, tag: '야영지', desc: '숲 속 야영지에 모여 지냄. 새벽마다 조금씩 늘어남. 금화 한 닢이면 왕국의 백성이 됨.' },
        { icon: IC.person, name: ROLE.pea, tag: '도구 없음', desc: '모닥불 곁에서 지냄. 탐욕에 붙잡히면 금화를 빼앗기고 떠돌이로 돌아감.' },
        { icon: IC.archer, name: ROLE.arc, tag: '활', desc: '낮엔 사슴을 사냥(한 마리에 금화 3), 해 질 녘엔 바깥 성벽과 망루로. 거둔 금화는 군주가 곁을 지나가면 건네줌.' },
        { icon: IC.builder, name: ROLE.bld, tag: '망치', desc: '금화를 낸 일감부터 지음. 낮에는 다친 성벽도 고침. 바깥 일은 해가 지면 멈춤.' },
        { icon: IC.farmer, name: ROLE.far, tag: '낫', desc: '밭을 일구고, 해 지기 전 금화를 거둬 금고에 넣음.' },
        { icon: IC.knight, name: ROLE.kni, tag: '방패', desc: '튼튼함 ' + KNIGHT_HP + '. 바깥 성벽 앞에서 싸움. 쓰러지면 방패를 떨어뜨림. 새벽에 회복.' },
        { icon: IC.deer, name: ROLE.deer, tag: '사냥감', desc: '왕국 바깥 숲에 삶. 땅이 넓어질수록 멀어짐. 겨울엔 적고 금화도 두 닢.' },
      ] },
      { h: '탈것', p: ['섬마다 숲 어딘가에 탈것 하나가 기다림. 금화를 내면 지금 탈것과 바꿈(두고 간 탈것은 그 자리에 남음).'], rows: Object.keys(MOUNTS).map((k) => { const M = MOUNTS[k]; return { icon: k === 'stag' ? IC.stag : IC.horse, name: M.n, tag: '질주 ' + M.gal + ' · 금화 ' + M.cap, desc: M.d + ' 걷기 ' + M.walk + ' · 지침 ' + Math.round(M.drain * 100) + '/초.' }; }) },
      { h: '탐욕', p: ['밤이면 숲의 균열에서 몰려와 금화·도구·왕관을 노림. 새벽이 오면 흩어짐.'], rows: Object.keys(ENEMY).map((k) => { const E = ENEMY[k]; return { icon: k === 'g' ? IC.greed : k === 'c' ? IC.claw : k === 'r' ? IC.crusher : IC.wing, name: E.n, tag: '체력 ' + E.hp + (E.dmg ? ' · 성벽 피해 ' + E.dmg : ''), desc: E.d }; }).concat([
        { icon: IC.portal, name: '균열', tag: '섬 양쪽 숲', desc: '튼튼함 ' + PORTAL_HP(0) + '(섬마다 +10). 기사가 있으면 바깥 성벽 앞 「돌격」 깃발에 3닢 → 기사와 궁수가 낮 동안 공격.' },
        { icon: IC.cliff, name: '절벽 균열', tag: '왼쪽 끝', desc: '핏빛 달의 밤마다 큰 무리를 보냄. 폭약으로만 무너짐.' },
      ]) },
      { h: '섬', p: ['섬을 건널 때마다 땅이 넓어지고 무리가 거세짐. 판 밖에서 이어지는 성장은 없음.'], rows: [0, 1, 2, 3, 4].map((k) => ({ icon: IC.island, name: isleName(k), tag: '폭 ' + (2 * (1150 + 190 * k)), desc: '핏빛 달 ' + BM_EVERY[k] + '일마다 · 균열 ' + PORTAL_HP(k) + ' · 탈것 ' + MOUNTS[ISLE_MOUNT[k]].n + (k >= 2 ? ' · 날개 출몰' : '') + '. 배로 데려갈 수 있는 백성 8명(균열을 모두 닫으면 12명과 금화 5닢).' })) },
    ];
  }
  function preview(cnv) {
    const c = cnv.getContext('2d'), w = cnv.width, h = cnv.height, gy = h * 0.68;
    const g = c.createLinearGradient(0, 0, 0, gy); g.addColorStop(0, '#2f2c44'); g.addColorStop(1, '#a8704f'); c.fillStyle = g; c.fillRect(0, 0, w, gy);
    c.fillStyle = 'rgba(240,210,160,0.9)'; c.beginPath(); c.arc(w * 0.78, gy * 0.72, 16, 0, 7); c.fill();
    const lay = (base, a1, a2, a3, col, sd) => { c.fillStyle = col; c.beginPath(); c.moveTo(0, gy); for (let x = 0; x <= w + 6; x += 6) c.lineTo(x, gy - base - ridge(x * 1.6, sd, a1, a2, a3)); c.lineTo(w, gy); c.fill(); };
    lay(110, 24, 16, 28, '#5a4048', 1.3); lay(60, 16, 12, 18, '#3c2c34', 4.1);
    c.fillStyle = '#251c22'; c.beginPath(); c.moveTo(0, gy); for (let x = 0; x <= w + 5; x += 5) c.lineTo(x, gy - 30 - 14 * hash(Math.floor(x / 9)) + Math.abs(((x / 9) % 1) - 0.5) * 12); c.lineTo(w, gy); c.fill();
    c.fillStyle = '#1a1416'; c.fillRect(0, gy, w, 8);
    // 목책
    c.fillStyle = '#20171a'; for (let j = 0; j < 6; j++) { const x = 400 + j * 7; c.beginPath(); c.moveTo(x, gy); c.lineTo(x, gy - 30); c.lineTo(x + 3, gy - 34); c.lineTo(x + 6, gy - 30); c.lineTo(x + 6, gy); c.fill(); }
    // 모닥불
    const fg = c.createRadialGradient(230, gy - 6, 0, 230, gy - 6, 90); fg.addColorStop(0, 'rgba(230,150,70,0.5)'); fg.addColorStop(1, 'rgba(230,150,70,0)'); c.fillStyle = fg; c.fillRect(140, gy - 96, 180, 100);
    c.fillStyle = '#e8a050'; c.beginPath(); c.moveTo(222, gy); c.quadraticCurveTo(230, gy - 22, 238, gy); c.fill();
    // 말과 군주
    c.fillStyle = '#17110f'; c.beginPath(); c.ellipse(320, gy - 22, 20, 8, 0, 0, 7); c.fill();
    c.beginPath(); c.moveTo(334, gy - 26); c.lineTo(344, gy - 42); c.lineTo(350, gy - 40); c.lineTo(352, gy - 33); c.lineTo(340, gy - 20); c.fill();
    c.strokeStyle = '#17110f'; c.lineWidth = 3; c.beginPath(); [306, 311, 328, 333].forEach((x, j) => { c.moveTo(x, gy - 18); c.lineTo(x + (j % 2 ? 3 : -2), gy); }); c.stroke();
    c.fillStyle = '#1d1517'; c.fillRect(316, gy - 46, 8, 16); c.beginPath(); c.arc(320, gy - 50, 4, 0, 7); c.fill();
    c.fillStyle = '#c9a24a'; c.beginPath(); c.moveTo(316, gy - 53); c.lineTo(316, gy - 58); c.lineTo(318.5, gy - 55); c.lineTo(320, gy - 59); c.lineTo(321.5, gy - 55); c.lineTo(324, gy - 58); c.lineTo(324, gy - 53); c.fill();
    c.beginPath(); c.arc(320, gy - 66, 2.6, 0, 7); c.fill();
    // 물
    c.fillStyle = '#120e12'; c.fillRect(0, gy + 8, w, h - gy - 8);
    c.save(); c.globalAlpha = 0.28; c.translate(0, 2 * gy + 16); c.scale(1, -1); c.drawImage(cnv, 0, 0, w, gy, 0, 0, w, gy); c.restore();
    const wg = c.createLinearGradient(0, gy + 8, 0, h); wg.addColorStop(0, 'rgba(10,8,12,0.2)'); wg.addColorStop(1, 'rgba(10,8,12,0.85)'); c.fillStyle = wg; c.fillRect(0, gy + 8, w, h - gy - 8);
  }
  const ICON = '<path d="M8 40c3-7 9-9 15-9h12l5-8 6 2-2 7-5 5v13" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 40v10M19 40v10M33 42v8M38 41v9" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><path d="M24 31v-11h7v11" fill="currentColor"/><path d="M23 18l1-6 2.6 3 1.4-4 1.4 4 2.6-3 1 6z" fill="currentColor"/><circle cx="48" cy="12" r="5" fill="none" stroke="currentColor" stroke-width="2"/>';

  L.register({
    id: ID, name: '말 위의 군주', tag: '금화 왕국 전략', cat: '전략', icon: ICON, tint: '#2b2a36', time: '15–70분',
    blurb: '말을 탄 군주가 금화만으로 성벽을 쌓고 궁수를 모으고 영토를 넓힙니다. 밤마다 균열에서 몰려오는 탐욕의 무리를 막고, 배를 고쳐 다음 섬으로. 버튼 셋으로 하는 절제된 옆 스크롤 전략, 1~2인 협동.',
    minPlayers: 1, maxPlayers: 2, defaultPlayers: 1, hidden: false, realtime: true, coop: true, aiDelay: 0, landscape: true, undo: false,
    sidePanel: false, mood: 'calm', ambient: 'forest', save: true, saveLabel: (s) => (s && s.svd) || '왕국을 다스리는 중',
    controls: [
      { id: 'left', label: '왼쪽으로 몰기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 몰기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'gallop', label: '질주 (누르고 있기)', keys: ['ShiftLeft', 'ShiftRight'], pad: ['rb', 'rt', 'b'] },
      { id: 'coin', label: '금화 내기 (누르고 있기)', keys: ['ArrowDown', 'KeyS', 'Space'], pad: ['a', 'down'] },
    ],
    options: [
      { id: 'isl', label: '섬', tip: '마지막 섬을 떠나면 승리. 섬마다 무리가 거세짐.', choices: [{ v: 'trial', label: '연습 섬', tip: '배를 거의 다 고쳐 둔 섬 하나. 10분 안팎.' }, { v: 1, label: '하나' }, { v: 3, label: '셋' }, { v: 5, label: '다섯' }], def: 3 },
      { id: 'pace', label: '하루 길이', tip: '낮과 밤이 한 번 도는 시간.', choices: [{ v: 'fast', label: '짧게', tip: '1분 20초' }, { v: 'norm', label: '보통', tip: '1분 45초' }, { v: 'slow', label: '길게', tip: '2분 30초' }], def: 'norm' },
      { id: 'diff', label: '탐욕의 기세', tip: '밤마다 오는 무리의 크기.', choices: [{ v: 'low', label: '약하게' }, { v: 'mid', label: '보통' }, { v: 'high', label: '거세게' }], def: 'mid' },
    ],
    quick: [
      '목표: 금화로 왕국을 키우며 밤을 버티고, 배를 고쳐 마지막 섬까지 건너가요.',
      '할 일: 말을 몰아 표시 앞에서 금화 버튼을 누르고 있으면 그 자리에 무언가가 지어져요.',
      '밤에는 양쪽 균열에서 탐욕이 몰려와요. 성벽과 궁수로 막고, 군주는 성벽 안에 있어요.',
      '왕관을 빼앗겨 균열 너머로 넘어가면 끝이에요.',
    ],
    rules: [
      { h: '목표', p: [
        '군주는 말을 타고 섬을 오가며 금화로만 다스려요. 말로 명령하는 일은 없고, 금화를 어디에 내는지가 곧 결정이에요.',
        '섬의 오른쪽 끝 부두에는 난파선이 있어요. 세 번에 걸쳐 고치고 출항하면 다음 섬으로 건너가요. 마지막 섬을 떠나면 승리.',
        '다른 길: 기사와 폭약으로 섬의 균열 셋을 모두 닫아도 그 섬을 넘어가요(데려가는 백성이 늘고 금화 5닢을 더 받아요).',
        '왕관을 빼앗기고, 그 탐욕이 균열 너머로 사라지면 패배예요.'] },
      { h: '조작', p: [
        '◀ ▶ 누르고 있기 = 그쪽으로 걸음. 같은 쪽을 두 번 눌러 누르고 있으면 질주. 질주하면 말이 지치고, 멈춰 서 있으면 풀을 뜯으며 회복해요.',
        '금화 버튼 누르고 있기 = 가까운 표시에 금화를 한 닢씩 냄. 표시 위 동그라미가 모두 차면 결정돼요. 도중에 손을 떼거나 멀어지면 낸 금화는 돌아와요.',
        '땅의 금화·상자·금고는 지나가기만 하면 주워요. 지갑이 가득 차면(보통 30닢) 더 줍지 못해요.',
        'PC: ←/→ 또는 A/D 몰기, Shift 질주(같은 키 두 번도 됨), ↓·S·Space 금화. 게임패드: 스틱·방향키, RB 질주, A 금화. 「⌨ 조작 설정」에서 바꿀 수 있어요.'] },
      { h: '백성과 도구', p: [
        '숲 속 야영지의 떠돌이에게 한 닢을 주면 백성이 되어 모닥불 곁으로 와요.',
        '공방에 금화를 내면 선반에 도구가 놓이고, 빈손의 백성이 집어 들어요: 활 2닢 → 궁수, 망치 3닢 → 일꾼, 낫 3닢 → 농부(장원부터), 방패 5닢 → 기사(돌 성채부터).',
        '궁수는 낮에 사슴을 사냥해 금화를 들고 오고, 해 질 녘엔 바깥 성벽과 망루에 올라 지켜요. 군주가 곁을 지나가면 들고 있던 금화를 건네요.',
        '일꾼은 금화를 낸 일감을 짓고 낮엔 다친 성벽을 고쳐요. 농부는 밭에서 금화를 거둬 금고에 넣어요.',
        '탐욕에 붙잡힌 백성은 도구를 떨어뜨려요. 떨어진 도구는 새벽에 공방 선반으로 돌아가요.',
        '새벽마다 모닥불 곁 금고에 세금이 들어와요(백성 넷마다 한 닢, 적어도 한 닢). 금고 곁을 지나가면 거둬요.'] },
      { h: '짓기와 영토', p: [
        '모닥불(장원)을 키우면 더 높은 성벽·망루·밭·공방이 열려요: 모닥불 → 목책 장원(3) → 돌 성채(6) → 왕성(10).',
        '성벽: 말뚝 울타리 2 → 목책 4 → 돌벽 6 → 성벽 9. 바깥에 성벽을 세우면 숲이 물러나고 그 너머에 새 표시가 나타나요.',
        '망루(궁수가 높은 곳에서 더 멀리 쏨), 밭(겨울엔 쉼)은 영토 안쪽 자리에. 무너진 성벽은 반값으로 다시 세워요.'] },
      { h: '밤과 탐욕', p: [
        '해가 지면 뿔피리 소리와 함께 양쪽 숲의 균열에서 무리가 와요. 날이 갈수록 커지고, 셋째 날부터 단단한 「발톱」, 핏빛 달의 밤엔 성벽을 부수는 「등짐꾼」, 셋째 섬부터 하늘의 「날개」가 섞여요.',
        '탐욕은 성벽을 긁고, 성벽 밖의 백성에게서 도구와 금화를 빼앗고, 군주에게서는 금화를 낚아채요. 성벽 밖의 군주가 가까이 있으면 쫓아와요. 지갑이 비어 있을 때 닿으면 왕관을 빼앗겨요.',
        '왕관을 든 탐욕을 궁수가 쓰러뜨리면 왕관이 땅에 떨어져요. 다시 지나가면 되찾아요.',
        '새벽이 오면 무리는 균열로 흩어져요.'] },
      { h: '계절 · 핏빛 달', p: [
        '사흘마다 계절이 바뀌어요(봄 → 여름 → 가을 → 겨울). 겨울엔 밭이 쉬고 사슴이 줄어요.',
        '핏빛 달은 첫째 섬 7일마다, 섬이 바뀔수록 더 자주 떠요. 해 질 녘 하늘이 붉어지면 그날 밤이에요.'] },
      { h: '섬을 떠나는 법', p: [
        '출항: 난파선에 금화를 세 번(3 · 6 · 9닢, 섬마다 +1) 내고 일꾼이 고치면 돛배가 돼요. 낮에 배 곁에서 2닢을 내면 출항. 협동이면 두 군주가 모두 배 곁에 있어야 해요.',
        '데려가는 것: 지갑의 금화, 탈것, 백성 8명(일꾼·궁수를 고르게, 그다음 기사·농부). 균열을 모두 닫고 떠나면 12명과 금화 5닢을 더 받아요.',
        '정화: 기사가 있는 쪽 바깥 성벽 앞에 「돌격」 깃발이 서요(낮 전반). 3닢을 내면 그쪽 기사와 궁수 몇이 균열로 가서 해 질 녘까지 공격해요. 왼쪽 끝 절벽 균열은 폭약(왕성부터)으로만 무너져요.'] },
      { h: '탈것', p: [
        '섬마다 숲 어딘가에 탈것이 하나 기다려요. 금화를 내면 바꿔 타요: 질주마(가장 빠름), 짐말(지치지 않고 금화 45닢), 갑주마(밤마다 한 번 막아 줌), 흰 사슴(사슴이 뒤를 따름).'] },
      { h: '함께 하기', p: [
        '가로 화면 게임이에요. 폰을 돌릴 수 없으면 「세로로 그냥 하기」로도 할 수 있어요.',
        '혼자 또는 2인 협동. 한 폰에는 군주 한 명이고, 친구와는 온라인·LAN 방에서 각자 폰으로 해요. 화면은 각자 자기 군주를 따라가요.',
        '지갑은 각자, 왕국은 함께예요. 같은 표시에 둘이 함께 금화를 낼 수 있어요. 한쪽이 왕관을 빼앗기면 다른 군주가 쫓아가 되찾을 수 있어요.',
        'AI 군주의 난이도는 자리마다 쉬움·보통·어려움으로 골라요. 쉬움은 늦게까지 밖에 있고 금화를 허투루 쓰며, 어려움은 큰 지출을 위해 모아 두고 핏빛 달 전에 성벽을 높여요.'] },
      { h: '만든 사람', p: [
        '체계는 「Kingdom Two Crowns」에서 빌렸고 이름·그림·글은 이 게임의 것이에요.',
        '그림과 소리는 모두 게임 안에서 직접 그리고 합성했어요(외부 파일 없음, CC0). 자세한 것은 app/assets/crownride/CREDITS.txt.'] },
    ],
    hint, codex: codex(), preview,
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { genIsland, newRun, startIsland, stepWorld, aiInput, aiPick, ctxOf, tfOf, costOf, PACE, DIFF, H, MOUNTS, ENEMY, WALL },
  });
})();
