(function () {
  'use strict';
  const L = (typeof window !== 'undefined' && window.Lounge) || {};
  const ID = 'madexp';
  const rnd = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const josa = (w, a, b) => { const c = String(w || '').charCodeAt(String(w || '').length - 1); return c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b; };   // 받침 있으면 a
  const shuf = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; };
  // 판 시드로 정하는 값(버릇 등) — 같은 시드면 같은 값
  const hash = (s) => { let x = 2166136261; s = String(s); for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return x >>> 0; };
  const srand = (seed, k) => (hash(seed + '|' + k) % 100000) / 100000;

  /* ---------- 능력치 이름 ---------- */
  const STN = { acc: '명중', dg: '회피', pr: '방어', spd: '속도', cr: '치명', dm: '피해', str: '받는 스트레스', mh: '최대 체력', hl: '받는 치유', hb: '주는 치유',
    rst: '기절 저항', rbl: '출혈 저항', rbg: '역병 저항', rdb: '약화 저항', rmv: '밀림 저항', rtr: '함정 회피', dbr: '죽음 저항', vir: '각성 확률', vsU: '망자·이형 상대 피해', vsB: '짐승 상대 피해', scout: '정찰' };
  const PCT = { pr: 1, cr: 1, dm: 1, str: 1, mh: 1, hl: 1, hb: 1, rst: 1, rbl: 1, rbg: 1, rdb: 1, rmv: 1, rtr: 1, dbr: 1, vir: 1, vsU: 1, vsB: 1, scout: 1 };
  const fmtMod = (k, v) => (STN[k] || k) + ' ' + (v > 0 ? '+' : '−') + Math.abs(v) + (PCT[k] ? '%' : '');
  const modsText = (m) => Object.keys(m || {}).map((k) => fmtMod(k, m[k])).join(' · ');

  /* ---------- 직업 12 (이름은 역할·모습으로, 사람 이름 없음) ----------
     기술: f 쓸 수 있는 자리 · t 대상(e 적, a 아군 아무나, o 다른 아군, s 자신, p 아군 전체) · r 대상 자리 · m 여럿 · acc 명중 · dm 피해 배율 · cr 치명 보정
           hl 치유 · sh 스트레스 회복 · fx 대상 효과 · sx 자신 효과 · sm 자신 이동(+앞/−뒤) · ip 방어 무시 · vsM 표식 대상 추가 피해 · vsU 망자·이형 추가 · exe 빈사 대상 추가 · low 체력 절반 아래에서만 · lt 빛 · gold 금화
     효과: bl 출혈 · bg 역병 · stun 기절 · mk 표식 · db 약화 · bf 강화 · gd 호위 · rp 반격 태세 · tn 도발 · cu 정화 · pu 밀기 · pl 당기기 */
  const CLS = [
    { id: 'kn', n: '성채 기사', s: '기사', hp: 36, spd: 3, dg: 5, pr: 15, dmg: [6, 12], cr: 4, res: { st: 40, bl: 30, bg: 30, db: 30, mv: 40, tr: 10 }, rk: '12', role: 'front',
      d: '무너진 성채의 마지막 수비대. 방패로 동료를 가리고 앞줄을 지킨다.',
      sk: [
        { n: '성벽 일격', ic: 'broadsword', f: '12', t: 'e', r: '12', acc: 85, dm: 1 },
        { n: '방패 밀치기', ic: 'shield-bash', f: '12', t: 'e', r: '12', acc: 90, dm: 0.5, fx: [{ k: 'stun', c: 100 }, { k: 'pu', n: 1, c: 90 }] },
        { n: '호위', ic: 'shield', f: '1234', t: 'o', r: '1234', fx: [{ k: 'gd', t: 2 }], sx: [{ k: 'bf', s: 'pr', v: 15, t: 2 }] },
        { n: '깃발 아래', ic: 'knight-banner', f: '1234', t: 'p', sh: 7, fx: [{ k: 'bf', s: 'str', v: -15, t: 3 }] },
        { n: '돌진', ic: 'sword-brandish', f: '34', t: 'e', r: '12', acc: 90, dm: 0.9, sm: 2 },
        { n: '정화의 칼날', ic: 'relic-blade', f: '12', t: 'e', r: '123', acc: 85, dm: 0.85, vsU: 0.5 },
        { n: '도발', ic: 'shouting', f: '12', t: 's', fx: [{ k: 'tn', t: 2 }, { k: 'bf', s: 'pr', v: 20, t: 2 }] },
      ], def: [0, 1, 2, 6],
      camp: [{ n: '맹세 낭독', ic: 'knight-banner', h: 3, t: 'p', e: { st: -10, buf: { s: 'str', v: -10 } } }, { n: '방패 손질', ic: 'shield', h: 2, t: 's', e: { buf: { s: 'pr', v: 10 } } }],
      a: { b: 'armor', h: 'helm', w: 'sword', o: 'shield', k: 1.04, c: '#b9a27a' } },
    { id: 'vt', n: '노병', s: '노병', hp: 33, spd: 4, dg: 8, pr: 10, dmg: [5, 10], cr: 4, res: { st: 40, bl: 30, bg: 30, db: 40, mv: 40, tr: 20 }, rk: '123', role: 'front',
      d: '셀 수 없는 전장을 살아 나온 늙은 병사. 칼보다 경험을 믿는다.',
      sk: [
        { n: '반격 태세', ic: 'riposte', f: '12', t: 's', fx: [{ k: 'rp', t: 2 }, { k: 'bf', s: 'dg', v: 10, t: 2 }] },
        { n: '칼자루 치기', ic: 'spiral-hilt', f: '12', t: 'e', r: '12', acc: 90, dm: 0.6, fx: [{ k: 'stun', c: 100 }] },
        { n: '엄호', ic: 'bell-shield', f: '123', t: 'o', r: '1234', fx: [{ k: 'gd', t: 2 }], sx: [{ k: 'bf', s: 'dg', v: 10, t: 2 }] },
        { n: '전열 정비', ic: 'trumpet', f: '1234', t: 'p', fx: [{ k: 'bf', s: 'acc', v: 8, t: 3 }, { k: 'bf', s: 'spd', v: 2, t: 3 }] },
        { n: '휩쓸기', ic: 'axe-swing', f: '12', t: 'e', r: '12', m: 1, acc: 85, dm: 0.55 },
        { n: '숨 고르기', ic: 'heart-beats', f: '1234', t: 's', hl: [6, 9], sh: 10 },
        { n: '표적 지시', ic: 'target-arrows', f: '1234', t: 'e', r: '1234', acc: 100, dm: 0, fx: [{ k: 'mk', t: 3 }, { k: 'db', s: 'dg', v: -10, t: 3, c: 100 }] },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '옛 전장 이야기', ic: 'trumpet', h: 3, t: 'p', e: { st: -12 } }, { n: '보초 서기', ic: 'hourglass', h: 2, t: 's', e: { amb: -20 } }],
      a: { b: 'armor', h: 'cap', w: 'sword', o: 'buckler', k: 0.98, c: '#a39274' } },
    { id: 'ex', n: '사형 집행인', s: '집행인', hp: 30, spd: 5, dg: 5, pr: 0, dmg: [8, 15], cr: 7, res: { st: 30, bl: 30, bg: 30, db: 30, mv: 30, tr: 10 }, rk: '12', role: 'front',
      d: '두건 아래 얼굴을 보인 적이 없다. 도끼는 한 번 들면 끝을 본다.',
      sk: [
        { n: '내려찍기', ic: 'battle-axe', f: '12', t: 'e', r: '12', acc: 85, dm: 1.15, cr: 4 },
        { n: '목 베기', ic: 'meat-cleaver', f: '12', t: 'e', r: '12', acc: 85, dm: 0.9, exe: 0.8 },
        { n: '피 내기', ic: 'bleeding-wound', f: '123', t: 'e', r: '123', acc: 90, dm: 0.55, fx: [{ k: 'bl', n: 3, t: 3, c: 100 }] },
        { n: '넓게 휘두르기', ic: 'crescent-blade', f: '12', t: 'e', r: '12', m: 1, acc: 85, dm: 0.5 },
        { n: '위압', ic: 'executioner-hood', f: '1234', t: 'e', r: '1234', acc: 100, dm: 0, fx: [{ k: 'db', s: 'dm', v: -25, t: 3, c: 100 }] },
        { n: '마지막 일격', ic: 'bloody-sword', f: '12', t: 'e', r: '123', acc: 90, dm: 1.6, cr: 10, low: 1 },
        { n: '물러서며 베기', ic: 'war-axe', f: '12', t: 'e', r: '12', acc: 85, dm: 0.75, sm: -1 },
      ], def: [0, 1, 2, 5],
      camp: [{ n: '숫돌질', ic: 'battle-axe', h: 3, t: 's', e: { buf: { s: 'dm', v: 15 } } }, { n: '침묵의 경계', ic: 'executioner-hood', h: 2, t: 's', e: { st: -15 } }],
      a: { b: 'brute', h: 'exhood', w: 'axe', k: 1.06, c: '#8f5a4a' } },
    { id: 'ls', n: '등불 수녀', s: '수녀', hp: 24, spd: 4, dg: 5, pr: 0, dmg: [3, 7], cr: 2, res: { st: 30, bl: 30, bg: 30, db: 40, mv: 20, tr: 10 }, rk: '34', role: 'heal',
      d: '꺼지지 않는 등잔을 들고 다니는 수녀. 빛을 나누고 상처를 덮는다.',
      sk: [
        { n: '성광', ic: 'lantern-flame', f: '234', t: 'e', r: '12', acc: 90, dm: 0.7, lt: 6, vsU: 0.3 },
        { n: '손 얹기', ic: 'hand-of-god', f: '34', t: 'a', r: '1234', hl: [5, 8] },
        { n: '등불 기도', ic: 'candle-light', f: '34', t: 'p', hl: [2, 4] },
        { n: '고해', ic: 'prayer', f: '234', t: 'a', r: '1234', sh: 13 },
        { n: '눈부심', ic: 'candlebright', f: '234', t: 'e', r: '123', acc: 90, dm: 0.25, fx: [{ k: 'stun', c: 90 }] },
        { n: '정결', ic: 'chalice-drops', f: '234', t: 'a', r: '1234', hl: [2, 3], fx: [{ k: 'cu' }] },
        { n: '성유물 들기', ic: 'holy-symbol', f: '34', t: 'p', fx: [{ k: 'bf', s: 'str', v: -25, t: 3 }] },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '저녁 미사', ic: 'prayer', h: 4, t: 'p', e: { st: -15 } }, { n: '등잔 기름 채우기', ic: 'lantern-flame', h: 2, t: 's', e: { light: 20 } }],
      a: { b: 'robe', h: 'veil', w: 'lantern', k: 0.95, c: '#d8c9a6' } },
    { id: 'hb', n: '독초 약제사', s: '약제사', hp: 24, spd: 6, dg: 8, pr: 0, dmg: [3, 6], cr: 3, res: { st: 30, bl: 30, bg: 60, db: 30, mv: 20, tr: 10 }, rk: '234', role: 'heal',
      d: '약과 독을 같은 주머니에 넣고 다닌다. 차이는 양과 쓰는 손에 있다.',
      sk: [
        { n: '독 병', ic: 'poison-bottle', f: '234', t: 'e', r: '234', acc: 90, dm: 0.35, fx: [{ k: 'bg', n: 4, t: 3, c: 100 }] },
        { n: '독 안개', ic: 'poison-gas', f: '34', t: 'e', r: '34', m: 1, acc: 90, dm: 0.2, fx: [{ k: 'bg', n: 3, t: 3, c: 90 }] },
        { n: '마취 연기', ic: 'smoke-bomb', f: '234', t: 'e', r: '12', m: 1, acc: 90, dm: 0, fx: [{ k: 'stun', c: 75 }] },
        { n: '응급 처치', ic: 'herbs-bundle', f: '234', t: 'a', r: '1234', hl: [3, 5], fx: [{ k: 'cu' }] },
        { n: '각성제', ic: 'bubbling-flask', f: '234', t: 'a', r: '1234', sh: 5, fx: [{ k: 'bf', s: 'spd', v: 4, t: 3 }, { k: 'bf', s: 'dm', v: 15, t: 3 }] },
        { n: '절개', ic: 'plain-dagger', f: '123', t: 'e', r: '12', acc: 90, dm: 0.75, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] },
        { n: '해독 혼합', ic: 'fizzing-flask', f: '234', t: 'p', fx: [{ k: 'cu' }, { k: 'bf', s: 'rbg', v: 40, t: 3 }] },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '약초 달이기', ic: 'herbs-bundle', h: 3, t: 'p', e: { hp: 15, cure: 1 } }, { n: '진정 차', ic: 'round-bottom-flask', h: 2, t: 'o', e: { st: -20 } }],
      a: { b: 'coat', h: 'beak', w: 'flask', k: 0.97, c: '#7c8b5a' } },
    { id: 'xb', n: '성벽 석궁수', s: '석궁수', hp: 26, spd: 3, dg: 3, pr: 0, dmg: [6, 11], cr: 6, res: { st: 30, bl: 30, bg: 30, db: 30, mv: 30, tr: 20 }, rk: '34', role: 'ranged',
      d: '성벽 위에서 평생을 보냈다. 벽이 무너진 뒤에도 자리를 떠나지 않는 법만 안다.',
      sk: [
        { n: '조준 사격', ic: 'crossbow', f: '34', t: 'e', r: '234', acc: 90, dm: 1, cr: 5 },
        { n: '일제 사격', ic: 'arrow-cluster', f: '34', t: 'e', r: '1234', m: 1, acc: 85, dm: 0.4 },
        { n: '표식 사격', ic: 'eye-target', f: '34', t: 'e', r: '1234', acc: 95, dm: 0.3, fx: [{ k: 'mk', t: 3 }] },
        { n: '표식 노리기', ic: 'on-target', f: '34', t: 'e', r: '1234', acc: 90, dm: 0.9, vsM: 0.7 },
        { n: '압박대', ic: 'bandage-roll', f: '1234', t: 'a', r: '1234', hl: [3, 5], fx: [{ k: 'cu' }] },
        { n: '견제 사격', ic: 'plain-arrow', f: '34', t: 'e', r: '12', acc: 90, dm: 0.5, fx: [{ k: 'pu', n: 1, c: 100 }, { k: 'db', s: 'spd', v: -3, t: 3, c: 100 }] },
        { n: '조명탄', ic: 'lantern', f: '34', t: 'p', lt: 20, sh: 4 },
      ], def: [0, 1, 2, 4],
      camp: [{ n: '화살촉 갈기', ic: 'crossbow', h: 2, t: 's', e: { buf: { s: 'acc', v: 8 } } }, { n: '망루 감시', ic: 'eye-target', h: 3, t: 's', e: { amb: -25 } }],
      a: { b: 'lean', h: 'kettle', w: 'crossbow', k: 1, c: '#8a8f99' } },
    { id: 'sf', n: '그림자발', s: '그림자발', hp: 26, spd: 7, dg: 15, pr: 0, dmg: [5, 10], cr: 8, res: { st: 30, bl: 30, bg: 30, db: 30, mv: 20, tr: 50 }, rk: '123', role: 'front',
      d: '발소리를 남기지 않는 사람. 어둠 속에서 칼이 먼저 도착한다.',
      sk: [
        { n: '등 찌르기', ic: 'cloak-dagger', f: '12', t: 'e', r: '123', acc: 90, dm: 1, cr: 8 },
        { n: '단검 던지기', ic: 'thrown-daggers', f: '234', t: 'e', r: '234', acc: 90, dm: 0.65, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] },
        { n: '그림자 숨기', ic: 'hooded-assassin', f: '1234', t: 's', sm: -1, fx: [{ k: 'bf', s: 'dg', v: 20, t: 3 }] },
        { n: '파고들기', ic: 'diving-dagger', f: '34', t: 'e', r: '123', acc: 90, dm: 1.15, sm: 2 },
        { n: '독 바른 칼', ic: 'dripping-knife', f: '123', t: 'e', r: '12', acc: 90, dm: 0.6, fx: [{ k: 'bg', n: 3, t: 3, c: 100 }] },
        { n: '다리 베기', ic: 'knife-thrust', f: '12', t: 'e', r: '12', acc: 90, dm: 0.5, fx: [{ k: 'db', s: 'spd', v: -4, t: 3, c: 100 }, { k: 'db', s: 'dg', v: -10, t: 3, c: 100 }] },
        { n: '소매치기', ic: 'robber-hand', f: '123', t: 'e', r: '123', acc: 95, dm: 0.3, gold: [10, 30] },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '그림자 정찰', ic: 'hooded-assassin', h: 3, t: 's', e: { scout: 1 } }, { n: '자물쇠 다루기', ic: 'skeleton-key', h: 2, t: 's', e: { item: 'key' } }],
      a: { b: 'lean', h: 'hood', w: 'dagger', o: 'dagger', k: 0.96, c: '#5f6a72' } },
    { id: 'dg', n: '장송 악사', s: '악사', hp: 24, spd: 6, dg: 12, pr: 0, dmg: [3, 7], cr: 4, res: { st: 30, bl: 30, bg: 30, db: 40, mv: 20, tr: 20 }, rk: '234', role: 'stress',
      d: '장례 행렬 맨 앞에서 연주하던 악사. 슬픔을 다루는 법을 안다.',
      sk: [
        { n: '장송곡', ic: 'lyre', f: '34', t: 'p', sh: 7 },
        { n: '불협화음', ic: 'musical-notes', f: '234', t: 'e', r: '234', m: 1, acc: 90, dm: 0.25, fx: [{ k: 'db', s: 'acc', v: -10, t: 3, c: 90 }] },
        { n: '행진곡', ic: 'drum', f: '234', t: 'p', fx: [{ k: 'bf', s: 'spd', v: 3, t: 3 }, { k: 'bf', s: 'acc', v: 5, t: 3 }] },
        { n: '조종', ic: 'ringing-bell', f: '234', t: 'e', r: '123', acc: 90, dm: 0.2, fx: [{ k: 'stun', c: 80 }] },
        { n: '자장가', ic: 'pan-flute', f: '234', t: 'a', r: '1234', sh: 16 },
        { n: '가는 칼', ic: 'switchblade', f: '123', t: 'e', r: '12', acc: 90, dm: 0.75, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] },
        { n: '조소', ic: 'carnival-mask', f: '1234', t: 'e', r: '1234', acc: 100, dm: 0, fx: [{ k: 'mk', t: 3 }, { k: 'db', s: 'dm', v: -15, t: 3, c: 100 }] },
      ], def: [0, 1, 2, 4],
      camp: [{ n: '모닥불 연주', ic: 'lyre', h: 3, t: 'p', e: { st: -14 } }, { n: '애도의 노래', ic: 'pan-flute', h: 2, t: 'o', e: { st: -22 } }],
      a: { b: 'coat', h: 'tricorn', w: 'lute', k: 0.97, c: '#7a5c7e' } },
    { id: 'sc', n: '금서 학자', s: '학자', hp: 24, spd: 5, dg: 5, pr: 0, dmg: [4, 9], cr: 5, res: { st: 30, bl: 30, bg: 30, db: 50, mv: 20, tr: 10 }, rk: '234', role: 'ranged',
      d: '읽어서는 안 될 책을 끝까지 읽은 사람. 그 대가를 아직 다 치르지 않았다.',
      sk: [
        { n: '심연의 손', ic: 'brain-tentacle', f: '234', t: 'e', r: '1234', acc: 90, dm: 0.8, ip: 1, fx: [{ k: 'pl', n: 1, c: 90 }] },
        { n: '쇠약의 저주', ic: 'evil-book', f: '234', t: 'e', r: '1234', acc: 100, dm: 0, fx: [{ k: 'db', s: 'pr', v: -20, t: 3, c: 100 }, { k: 'db', s: 'dm', v: -15, t: 3, c: 100 }] },
        { n: '금지된 봉합', ic: 'spell-book', f: '234', t: 'a', r: '1234', hl: [6, 11], sx: [{ k: 'st', v: 5 }] },
        { n: '기억 봉인', ic: 'scroll-unfurled', f: '234', t: 'o', r: '1234', sh: 20, fx: [{ k: 'hurt', v: 3 }] },
        { n: '꿰뚫는 눈', ic: 'all-seeing-eye', f: '234', t: 'e', r: '1234', acc: 100, dm: 0, fx: [{ k: 'mk', t: 3 }, { k: 'db', s: 'dg', v: -15, t: 3, c: 100 }] },
        { n: '불타는 장', ic: 'burning-book', f: '34', t: 'e', r: '234', m: 1, acc: 85, dm: 0.35, fx: [{ k: 'bg', n: 2, t: 2, c: 90 }] },
        { n: '응시', ic: 'crystal-eye', f: '234', t: 'e', r: '123', acc: 90, dm: 0.3, fx: [{ k: 'stun', c: 80 }] },
      ], def: [0, 1, 2, 4],
      camp: [{ n: '금서 낭독', ic: 'evil-book', h: 3, t: 'p', e: { buf: { s: 'cr', v: 5 }, st: 4 } }, { n: '봉인의 표식', ic: 'all-seeing-eye', h: 2, t: 'p', e: { amb: -15 } }],
      a: { b: 'robe', h: 'cowl', w: 'book', k: 1.02, c: '#5a4f7a' } },
    { id: 'fc', n: '매사냥꾼', s: '매사냥꾼', hp: 26, spd: 6, dg: 10, pr: 0, dmg: [4, 9], cr: 5, res: { st: 30, bl: 30, bg: 30, db: 30, mv: 30, tr: 30 }, rk: '234', role: 'ranged',
      d: '지하에서도 매를 놓지 않는 사냥꾼. 매는 어둠 속에서도 길을 잃지 않는다.',
      sk: [
        { n: '매 날리기', ic: 'falcon-moon', f: '234', t: 'e', r: '1234', acc: 90, dm: 0.95 },
        { n: '발톱 할퀴기', ic: 'bird-claw', f: '234', t: 'e', r: '234', acc: 90, dm: 0.55, fx: [{ k: 'bl', n: 3, t: 2, c: 100 }] },
        { n: '눈 쪼기', ic: 'raven', f: '234', t: 'e', r: '1234', acc: 90, dm: 0.4, fx: [{ k: 'db', s: 'acc', v: -15, t: 3, c: 100 }] },
        { n: '매의 눈', ic: 'hawk-emblem', f: '234', t: 'e', r: '1234', acc: 100, dm: 0, fx: [{ k: 'mk', t: 3 }], sx: [{ k: 'bf', s: 'cr', v: 6, t: 3 }] },
        { n: '휘파람 경계', ic: 'feather', f: '1234', t: 'p', fx: [{ k: 'bf', s: 'dg', v: 8, t: 2 }] },
        { n: '사냥칼', ic: 'bowie-knife', f: '12', t: 'e', r: '12', acc: 90, dm: 0.9 },
        { n: '매 방패', ic: 'feathered-wing', f: '234', t: 'o', r: '1234', fx: [{ k: 'gd', t: 1 }, { k: 'bf', s: 'dg', v: 10, t: 1 }] },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '사냥감 굽기', ic: 'campfire', h: 3, t: 'p', e: { hp: 10, food: 2 } }, { n: '매 띄우기', ic: 'falcon-moon', h: 2, t: 's', e: { scout: 1 } }],
      a: { b: 'coat', h: 'hood', w: 'falcon', k: 1, c: '#8c7a55' } },
    { id: 'cw', n: '사슬 파수꾼', s: '파수꾼', hp: 35, spd: 2, dg: 2, pr: 20, dmg: [6, 11], cr: 3, res: { st: 50, bl: 30, bg: 40, db: 30, mv: 60, tr: 10 }, rk: '12', role: 'front',
      d: '옥문을 지키던 자. 사슬은 죄수를 묶던 것이고, 이제는 적을 끌어온다.',
      sk: [
        { n: '사슬 휘두르기', ic: 'flail', f: '12', t: 'e', r: '12', acc: 85, dm: 1 },
        { n: '끌어오기', ic: 'harpoon-chain', f: '123', t: 'e', r: '234', acc: 90, dm: 0.5, fx: [{ k: 'pl', n: 2, c: 100 }, { k: 'mk', t: 2 }] },
        { n: '결박', ic: 'crossed-chains', f: '12', t: 'e', r: '12', acc: 90, dm: 0.3, fx: [{ k: 'stun', c: 100 }] },
        { n: '사슬 벽', ic: 'chain-mail', f: '12', t: 's', fx: [{ k: 'tn', t: 2 }, { k: 'bf', s: 'pr', v: 25, t: 2 }] },
        { n: '짓밟기', ic: 'metal-boot', f: '1', t: 'e', r: '1', acc: 85, dm: 1.3, fx: [{ k: 'pu', n: 1, c: 100 }] },
        { n: '고문 고리', ic: 'meat-hook', f: '12', t: 'e', r: '12', acc: 90, dm: 0.6, fx: [{ k: 'bl', n: 3, t: 3, c: 100 }] },
        { n: '이를 악물기', ic: 'fist', f: '1234', t: 's', hl: [7, 10], sh: 5 },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '사슬 감기', ic: 'crossed-chains', h: 2, t: 's', e: { buf: { s: 'pr', v: 15 } } }, { n: '옥문 지키기', ic: 'chain-mail', h: 3, t: 'p', e: { amb: -30 } }],
      a: { b: 'brute', h: 'bare', w: 'chain', k: 1.08, c: '#6d6a63' } },
    { id: 'sp', n: '화약 공병', s: '공병', hp: 26, spd: 4, dg: 5, pr: 5, dmg: [5, 10], cr: 4, res: { st: 30, bl: 30, bg: 30, db: 30, mv: 30, tr: 40 }, rk: '234', role: 'ranged',
      d: '갱도를 무너뜨리던 손. 화약 냄새가 옷에서 빠지지 않는다.',
      sk: [
        { n: '화약 단지', ic: 'fire-bomb', f: '234', t: 'e', r: '234', m: 1, acc: 85, dm: 0.55 },
        { n: '섬광탄', ic: 'stun-grenade', f: '234', t: 'e', r: '12', m: 1, acc: 90, dm: 0.1, fx: [{ k: 'stun', c: 70 }] },
        { n: '긴 도화선', ic: 'sparky-bomb', f: '34', t: 'e', r: '34', acc: 90, dm: 1.05, fx: [{ k: 'bl', n: 2, t: 2, c: 90 }] },
        { n: '산탄 권총', ic: 'crossed-pistols', f: '234', t: 'e', r: '12', m: 1, acc: 85, dm: 0.5 },
        { n: '버팀목', ic: 'barrel', f: '1234', t: 'a', r: '1234', fx: [{ k: 'bf', s: 'pr', v: 20, t: 3 }] },
        { n: '연막 후퇴', ic: 'powder-bag', f: '1234', t: 'p', sm: -2, fx: [{ k: 'bf', s: 'dg', v: 10, t: 2 }] },
        { n: '천장 무너뜨리기', ic: 'hammer-break', f: '234', t: 'e', r: '12', acc: 85, dm: 0.7, fx: [{ k: 'db', s: 'spd', v: -5, t: 3, c: 100 }] },
      ], def: [0, 1, 2, 3],
      camp: [{ n: '화약 말리기', ic: 'powder-bag', h: 2, t: 's', e: { buf: { s: 'dm', v: 12 } } }, { n: '덫 놓기', ic: 'wolf-trap', h: 3, t: 'p', e: { amb: -25 } }],
      a: { b: 'coat', h: 'cap', w: 'bomb', k: 0.99, c: '#9a6a3a' } },
  ];
  const CL = {}; CLS.forEach((c, i) => { CL[c.id] = c; c.i = i; });
  // 모두가 쓰는 야영 기술
  const CAMP_ALL = [
    { n: '상처 손질', ic: 'bandage-roll', h: 3, t: 'a', e: { hp: 25, cure: 1 } },
    { n: '짧은 기도', ic: 'prayer', h: 2, t: 's', e: { st: -15 } },
    { n: '불침번', ic: 'hourglass', h: 1, t: 's', e: { amb: -10 } },
  ];
  const CAMP_H = 12;   // 야영 시간

  /* ---------- 별명(모습·버릇에서 딴 말, 사람 이름 아님) ---------- */
  const EPI = ['외눈', '백발', '흉터진', '말 없는', '절름발이', '잿빛', '쉰 목소리', '마른', '검은 손톱', '불탄', '떠돌이', '늙은', '젊은', '맨발', '이 빠진', '손가락 잘린', '창백한', '굽은 등', '문신한', '눈 먼 쪽', '떨리는 손', '붉은 눈', '긴 그림자', '빗속의'];

  /* ---------- 상태 ---------- */
  const FXN = { bl: '출혈', bg: '역병', stun: '기절', mk: '표식', gd: '호위', rp: '반격 태세', tn: '도발', bf: '강화', db: '약화', dd: '죽음의 문턱', ddr: '문턱의 후유증' };
  const FXI = { bl: 'bleeding-wound', bg: 'poison', stun: 'knocked-out-stars', mk: 'eye-target', gd: 'shield', rp: 'riposte', tn: 'shouting', bf: 'upgrade', db: 'armor-downgrade', dd: 'dread-skull' };

  /* ---------- 붕괴(고통) 7 · 각성(덕) 5 ---------- */
  // m 능력치 · act 차례 시작에 제멋대로 할 확률 · ref 명령 거부 · nh 치유 거부 · beh 제멋대로 할 때 고르는 짓(가중치)
  const AFF = [
    { id: 'fear', n: '공포', ic: 'terror', m: { dg: 10, acc: -10 }, act: 0.3, ref: 0.2, nh: 0, beh: { back: 3, pass: 2, bark: 3 }, d: '물러서고 숨으려 함. 앞으로 나서라는 명령을 따르지 않음.',
      bark: ['저건 사람이 상대할 게 아니다.', '나는 여기서 더 못 간다.', '불을 꺼, 우리가 보인다.', '뒤에서 뭔가 숨 쉬고 있어.', '다들 여기서 죽는다.'] },
    { id: 'para', n: '편집', ic: 'angry-eyes', m: { acc: -5, str: 10 }, act: 0.25, ref: 0.25, nh: 0.5, beh: { bark: 4, pass: 1 }, d: '동료를 믿지 않음. 치유를 거부하고 의심을 퍼뜨림.',
      bark: ['네 손에 든 약, 무엇을 섞었지.', '처음부터 날 버릴 셈이었지.', '등 뒤에 서지 마.', '누가 지도를 바꿨어.', '다 알고 있다. 다.'] },
    { id: 'maso', n: '자학', ic: 'scar-wound', m: { pr: -10 }, act: 0.3, ref: 0.15, nh: 0.3, beh: { self: 3, fwd: 2, bark: 2 }, d: '스스로 상처를 냄. 위험한 앞줄로 나가려 함.',
      bark: ['아프다는 건 아직 살아 있다는 뜻이지.', '이 정도로는 모자라.', '내 몫의 피다.', '더 깊이 베어라.'] },
    { id: 'self', n: '이기심', ic: 'robber-hand', m: { hl: -20 }, act: 0.25, ref: 0.2, nh: 0, beh: { eat: 2, bark: 3, pass: 1 }, d: '자기 몫만 챙김. 식량을 몰래 먹고 동료를 깎아내림.',
      bark: ['내가 왜 너희를 지켜야 하지.', '이건 내 몫이다.', '먼저 가. 나는 뒤에서 본다.', '살아 나가는 건 하나면 충분해.'] },
    { id: 'rage', n: '광포', ic: 'burning-passion', m: { dm: 10, acc: -5 }, act: 0.35, ref: 0.25, nh: 0, beh: { atk: 4, bark: 3 }, d: '아무에게나 칼을 휘두르고 동료에게 고함을 지름.',
      bark: ['비켜, 아니면 너도 벤다.', '쓸모없는 것들.', '내 앞에서 떨지 마.', '전부 다 부숴 버리겠다.', '입 다물고 따라와.'] },
    { id: 'hope', n: '절망', ic: 'despair', m: { dm: -15, spd: -2 }, act: 0.35, ref: 0.3, nh: 0.2, beh: { pass: 4, bark: 3 }, d: '아무것도 하지 않으려 함. 체념이 동료에게 번짐.',
      bark: ['이제 와서 뭘 하겠어.', '끝은 이미 정해졌다.', '그만두자. 다 소용없다.', '빛은 곧 꺼진다.'] },
    { id: 'reck', n: '무모', ic: 'sprint', m: { dg: -10, cr: 5 }, act: 0.35, ref: 0.25, nh: 0, beh: { fwd: 3, atk: 3, bark: 1 }, d: '앞뒤를 가리지 않고 돌진함. 위치를 마음대로 바꿈.',
      bark: ['기다리는 건 질색이다.', '따라오든지 말든지.', '생각은 죽은 뒤에 하지.', '저기가 끝이야. 간다.'] },
  ];
  const VIR = [
    { id: 'stal', n: '불굴', ic: 'spiked-halo', m: { pr: 10, dbr: 20 }, d: '받는 피해가 줄고 쉽게 쓰러지지 않음. 차례마다 가끔 스스로 마음을 다잡음.', bark: ['아직 끝나지 않았다.', '이 정도로는 나를 꺾지 못한다.', '버텨라. 나도 버틴다.'] },
    { id: 'focu', n: '집중', ic: 'all-seeing-eye', m: { acc: 10, cr: 5 }, d: '명중과 치명이 오름. 차례마다 가끔 동료를 진정시킴.', bark: ['숨을 고르고, 본다.', '흔들리지 마라. 저것도 피를 흘린다.', '한 번에 하나씩.'] },
    { id: 'cour', n: '용기', ic: 'sunbeams', m: { dg: 5 }, d: '차례마다 자주 동료의 스트레스를 덜어 줌.', bark: ['내 뒤에 서라.', '두려움은 나눌수록 가볍다.', '앞으로. 같이 간다.'] },
    { id: 'powr', n: '강인', ic: 'fist', m: { dm: 20 }, d: '주는 피해가 크게 오름.', bark: ['부서지는 건 저쪽이다.', '힘은 아직 남았다.', '끝까지 밀어붙인다.'] },
    { id: 'vigo', n: '굳건', ic: 'heart-beats', m: { mh: 10 }, d: '차례마다 가끔 스스로 상처를 회복함.', bark: ['피는 멎는다. 언제나.', '아직 서 있다.', '숨이 붙어 있는 한.'] },
  ];
  const AF = {}; AFF.forEach((a) => (AF[a.id] = a));
  const VI = {}; VIR.forEach((a) => (VI[a.id] = a));

  /* ---------- 기질 (원정 중에만 얻음, 판 밖으로 이어지지 않음) ---------- */
  // c 조건: lh 빛 75 이상 · ll 빛 25 이하 · fx 특수 동작
  const QK = [
    { id: 'nerve', n: '강철 신경', p: 1, m: { str: -15 } }, { id: 'eye', n: '매의 눈', p: 1, m: { acc: 5 } }, { id: 'swift', n: '날랜 발', p: 1, m: { spd: 2 } },
    { id: 'tough', n: '굳은살', p: 1, m: { mh: 10 } }, { id: 'lamp', n: '등불 아래', p: 1, c: 'lh', m: { dg: 8, acc: 5 } }, { id: 'night', n: '어둠에 익숙함', p: 1, c: 'll', m: { cr: 5, dg: 8 } },
    { id: 'reap', n: '사신의 손', p: 1, m: { cr: 3 } }, { id: 'life', n: '질긴 목숨', p: 1, m: { dbr: 12 } }, { id: 'antiv', n: '해독 체질', p: 1, m: { rbg: 30 } },
    { id: 'clot', n: '굳은 피', p: 1, m: { rbl: 30 } }, { id: 'grave', n: '무덤 파는 손', p: 1, m: { vsU: 15 } }, { id: 'hunt', n: '짐승 사냥꾼', p: 1, m: { vsB: 15 } },
    { id: 'wary', n: '경계심', p: 1, m: { rtr: 25, scout: 10 } },
    { id: 'craven', n: '겁 많음', p: 0, m: { str: 20 } }, { id: 'shaky', n: '떨리는 손', p: 0, m: { acc: -5 } }, { id: 'slug', n: '굼뜸', p: 0, m: { spd: -2 } },
    { id: 'frail', n: '허약', p: 0, m: { mh: -10 } }, { id: 'nyct', n: '어둠 공포', p: 0, c: 'll', m: { str: 25, acc: -5 } }, { id: 'photo', n: '빛 혐오', p: 0, c: 'lh', m: { acc: -5, dg: -5 } },
    { id: 'thin', n: '묽은 피', p: 0, m: { rbl: -30 } }, { id: 'sick', n: '병약', p: 0, m: { rbg: -30 } }, { id: 'insom', n: '잠 못 듦', p: 0, m: {}, fx: 'insom' },
    { id: 'comp', n: '손대는 버릇', p: 0, m: {}, fx: 'comp' }, { id: 'klep', n: '손버릇', p: 0, m: {}, fx: 'klep' }, { id: 'glut', n: '폭식', p: 0, m: {}, fx: 'glut' },
    { id: 'pess', n: '비관', p: 0, m: { vir: -10 } }, { id: 'night2', n: '악몽', p: 0, m: { str: 10 }, fx: 'night' },
  ];
  const QFX = { insom: '야영에서 회복하는 체력이 절반', comp: '기묘한 물건을 보면 멋대로 손을 댈 때가 있음', klep: '전투에서 얻은 금화를 일부 빼돌림', glut: '야영에서 식량을 두 배로 먹음', night: '야영에서 덜어 내는 스트레스가 절반' };
  const QC = { lh: '빛 75 이상일 때', ll: '빛 25 이하일 때' };
  const QI = {}; QK.forEach((q) => (QI[q.id] = q));
  const quirkDesc = (q) => (q.c ? QC[q.c] + ': ' : '') + [modsText(q.m), q.fx ? QFX[q.fx] : ''].filter(Boolean).join(' · ');

  /* ---------- 장신구 ---------- */
  // r 0 흔함 1 드묾 2 희귀 3 우두머리 · cls 그 직업만 · v 값(되팔기 절반)
  const TRK = [
    { id: 'rosary', n: '녹슨 묵주', ic: 'prayer', r: 0, m: { str: -10, acc: -2 } },
    { id: 'kerch', n: '피 묻은 손수건', ic: 'bandage-roll', r: 0, m: { rbl: 30, hl: 10 } },
    { id: 'ratbone', n: '쥐뼈 목걸이', ic: 'tribal-pendant', r: 0, m: { dg: 6, mh: -5 } },
    { id: 'plate', n: '무거운 철판', ic: 'armor-upgrade', r: 0, m: { pr: 10, spd: -2 } },
    { id: 'feath', n: '깃털 부적', ic: 'feather-necklace', r: 0, m: { spd: 2, pr: -5 } },
    { id: 'tooth', n: '순교자의 이빨', ic: 'tooth', r: 1, m: { dm: 12, str: 10 } },
    { id: 'wax', n: '촛농 굳은 반지', ic: 'engagement-ring', r: 0, c: 'lh', m: { acc: 8 } },
    { id: 'map', n: '그을린 지도', ic: 'scroll-unfurled', r: 1, m: { scout: 25 } },
    { id: 'knot', n: '사냥꾼의 매듭', ic: 'ribbon-medal', r: 1, m: { cr: 4 } },
    { id: 'shard', n: '깨진 거울 조각', ic: 'mirror-mirror', r: 1, m: { vir: 12, str: 5 } },
    { id: 'keyr', n: '납골당 열쇠고리', ic: 'pendant-key', r: 1, m: { vsU: 20 } },
    { id: 'scale', n: '늪 비늘', ic: 'scarab-beetle', r: 0, m: { rbg: 40 } },
    { id: 'conf', n: '고해 성사 기록', ic: 'scroll-unfurled', r: 1, m: { str: -15, dm: -8 } },
    { id: 'oath', n: '피의 맹세', ic: 'bloody-sword', r: 2, m: { dm: 20, mh: -15 } },
    { id: 'bann', n: '성채 문장', ic: 'knight-banner', r: 1, cls: 'kn', m: { pr: 10, str: -10 } },
    { id: 'lampst', n: '수녀의 등잔 받침', ic: 'candle-light', r: 1, cls: 'ls', m: { hb: 25 } },
    { id: 'pouch', n: '약초 주머니', ic: 'herbs-bundle', r: 1, cls: 'hb', m: { hb: 15, rbg: 20 } },
    { id: 'obsid', n: '흑요석 손톱', ic: 'crystal-eye', r: 1, m: { cr: 6, acc: -4 } },
    { id: 'dice', n: '뼈 주사위', ic: 'gem-pendant', r: 0, m: { cr: 8, dg: -6 } },
    { id: 'flag', n: '낡은 군기', ic: 'trumpet', r: 1, m: { dbr: 15 } },
    { id: 'nail', n: '은 십자 못', ic: 'holy-symbol', r: 1, m: { vsU: 15, rst: 15 } },
    { id: 'jess', n: '매의 발목끈', ic: 'feather', r: 1, cls: 'fc', m: { dm: 15, acc: 4 } },
    { id: 'hunger', n: '굶주린 목걸이', ic: 'gem-necklace', r: 2, m: { mh: 15, str: 10 } },
    { id: 'chainl', n: '끊어진 사슬 고리', ic: 'crossed-chains', r: 1, cls: 'cw', m: { pr: 10, rmv: 30 } },
    { id: 'fuse', n: '젖지 않는 도화선', ic: 'sparky-bomb', r: 1, cls: 'sp', m: { dm: 12, cr: 3 } },
    { id: 'eyeb', n: '심연의 눈알', ic: 'all-seeing-eye', r: 3, m: { acc: 8, cr: 6, str: 15 } },
    { id: 'sluice', n: '수문 어미의 비늘', ic: 'scarab-beetle', r: 3, m: { pr: 15, rbg: 50 } },
    { id: 'crown', n: '포자 왕관 조각', ic: 'crown-of-thorns', r: 3, m: { mh: 20, hl: 20 } },
    { id: 'silent', n: '침묵의 묵주', ic: 'rune-stone', r: 3, m: { str: -25 } },
    { id: 'bonec', n: '뼈 왕관 조각', ic: 'medal-skull', r: 3, m: { dm: 20, cr: 4 } },
  ];
  const TI = {}; TRK.forEach((t) => (TI[t.id] = t));
  const RARN = ['흔함', '드묾', '희귀', '우두머리'];
  const RARV = [60, 120, 220, 300];
  const trkDesc = (t) => (t.c ? QC[t.c] + ': ' : '') + modsText(t.m) + (t.cls ? ' · ' + CL[t.cls].n + ' 전용' : '');

  /* ---------- 보급품 ---------- */
  const PROV = [
    { id: 'food', n: '식량', ic: 'bread', p: 8, d: '야영과 허기에 먹음. 아무 때나 먹으면 체력 +3.' },
    { id: 'torch', n: '횃불', ic: 'torch', p: 12, d: '빛 +25.' },
    { id: 'shovel', n: '삽', ic: 'dig-dug', p: 25, d: '통로를 막은 잔해를 치움. 일부 기묘한 물건에 씀.' },
    { id: 'band', n: '붕대', ic: 'bandage-roll', p: 15, d: '출혈을 멈추고 체력 +2. 일부 기묘한 물건에 씀.' },
    { id: 'anti', n: '해독초', ic: 'herbs-bundle', p: 15, d: '역병을 씻어 냄. 일부 기묘한 물건에 씀.' },
    { id: 'key', n: '열쇠 꾸러미', ic: 'skeleton-key', p: 30, d: '잠긴 상자와 문을 엶.' },
    { id: 'holy', n: '성수', ic: 'holy-water', p: 25, d: '아군 하나: 3라운드 동안 모든 저항 +30%, 스트레스 −5. 제단·성물에 씀.' },
    { id: 'laud', n: '진정 팅크', ic: 'round-bottom-flask', p: 40, d: '아군 하나의 스트레스 −20.' },
  ];
  const PV = {}; PROV.forEach((p) => (PV[p.id] = p));

  /* ---------- 구역 4 ---------- */
  const ZONES = [
    { id: 'oss', n: '무너진 납골당', img: 'ossuary', tint: [150, 120, 90], d: '산 자가 마지막으로 내려온 지 오래된 뼈의 회랑.', boss: 'bonecrown' },
    { id: 'aq', n: '잠긴 수로', img: 'aqueduct', tint: [90, 120, 120], d: '도시의 물이 모이던 곳. 지금은 물이 무엇을 데려오는지 아무도 모른다.', boss: 'sluice' },
    { id: 'gar', n: '썩은 정원', img: 'garden', tint: [110, 125, 80], d: '햇빛 없이 자라는 것들의 정원. 숨을 쉴 때마다 무언가 따라 들어온다.', boss: 'sporecrown' },
    { id: 'clo', n: '불 꺼진 수도원', img: 'cloister', tint: [140, 100, 120], d: '기도가 끊긴 뒤에도 무언가는 계속 듣고 있다.', boss: 'abbot' },
  ];
  const ZI = {}; ZONES.forEach((z, i) => { ZI[z.id] = z; z.i = i; });

  /* ---------- 적 42 ----------
     tg: U 망자 · B 짐승 · H 사람 · E 이형 · P 식물 / rk 서는 자리 / sk 기술(f 쓰는 자리, r 노리는 자리, st 스트레스, t 'a' 아군(적 편) 'e' 원정대 's' 자신, sum 불러오기)
     a: 그림 */
  const EN = [
    // 납골당
    { id: 'skspear', n: '해골 창병', z: 'oss', tg: 'U', hp: 14, spd: 2, dg: 5, pr: 15, dmg: [3, 7], cr: 4, rk: '12', d: '창끝은 녹이 슬었지만 찌르는 법은 잊지 않았다.',
      sk: [{ n: '창 찌르기', f: '12', r: '12', acc: 85, dm: 1 }, { n: '창벽', f: '12', t: 's', fx: [{ k: 'bf', s: 'pr', v: 20, t: 2 }], w: 0.5 }], a: { b: 'bones', h: 'skull', w: 'spear', o: 'buckler' } },
    { id: 'skarch', n: '해골 궁수', z: 'oss', tg: 'U', hp: 10, spd: 5, dg: 10, pr: 10, dmg: [3, 6], cr: 5, rk: '34', d: '빈 눈구멍으로도 과녁은 보인다.',
      sk: [{ n: '뼈 화살', f: '34', r: '1234', acc: 85, dm: 1 }, { n: '조준', f: '34', r: '1234', acc: 90, dm: 0.4, fx: [{ k: 'mk', t: 2 }] }], a: { b: 'bones', h: 'skull', w: 'bow' } },
    { id: 'gravedog', n: '무덤 개', z: 'oss', tg: 'B', hp: 12, spd: 7, dg: 15, pr: 0, dmg: [2, 5], cr: 5, rk: '12', d: '주인이 묻힌 뒤에도 떠나지 않은 개들.',
      sk: [{ n: '물어뜯기', f: '12', r: '12', acc: 85, dm: 0.8, fx: [{ k: 'bl', n: 1, t: 3, c: 100 }] }, { n: '울부짖기', f: '1234', r: '1234', acc: 100, dm: 0, st: 6, w: 0.5 }], a: { b: 'hound', h: 'none' } },
    { id: 'wraith', n: '수의 망령', z: 'oss', tg: 'E', hp: 11, spd: 6, dg: 20, pr: 0, dmg: [1, 3], cr: 3, rk: '23', d: '수의 아래에는 아무것도 없다. 그래서 더 무겁다.',
      sk: [{ n: '비탄의 속삭임', f: '1234', r: '1234', acc: 90, dm: 0, st: 11 }, { n: '차가운 손', f: '123', r: '12', acc: 85, dm: 0.8, fx: [{ k: 'db', s: 'acc', v: -10, t: 2, c: 80 }] }], a: { b: 'float', h: 'shroud' } },
    { id: 'ospriest', n: '납골 사제', z: 'oss', tg: 'U', hp: 12, spd: 4, dg: 5, pr: 5, dmg: [2, 4], cr: 3, rk: '34', d: '죽은 자에게 미사를 올리던 사제. 이제는 죽은 자를 일으킨다.',
      sk: [{ n: '뼈 맞추기', f: '34', t: 'a', hl: [4, 6] }, { n: '저주의 축도', f: '34', r: '1234', acc: 90, dm: 0.3, st: 7, fx: [{ k: 'db', s: 'dm', v: -10, t: 2, c: 80 }] }], a: { b: 'robe', h: 'mitre', w: 'censer' } },
    { id: 'bonerider', n: '뼈 기수', z: 'oss', tg: 'U', hp: 22, spd: 3, dg: 0, pr: 20, dmg: [5, 9], cr: 5, rk: '12', d: '말은 오래전에 쓰러졌다. 기수는 아직 내리지 않았다.',
      sk: [{ n: '내려치기', f: '12', r: '12', acc: 85, dm: 1 }, { n: '짓밟기', f: '1', r: '1', acc: 85, dm: 0.7, fx: [{ k: 'stun', c: 70 }] }], a: { b: 'bones', h: 'helm', w: 'mace', k: 1.12 } },
    { id: 'wailskull', n: '곡하는 두개골', z: 'oss', tg: 'U', hp: 8, spd: 8, dg: 25, pr: 0, dmg: [1, 3], cr: 3, rk: '234', d: '떠다니며 우는 머리. 울음이 멎으면 더 나쁘다.',
      sk: [{ n: '곡소리', f: '1234', r: '1234', m: 1, acc: 85, dm: 0, st: 5 }, { n: '이 갈기', f: '1234', r: '12', acc: 85, dm: 0.8 }], a: { b: 'head', h: 'skull' } },
    { id: 'gravrat', n: '무덤 쥐 떼', z: 'oss', tg: 'B', hp: 9, spd: 6, dg: 15, pr: 0, dmg: [1, 3], cr: 3, rk: '1234', d: '관을 갉아 길을 낸 것들.',
      sk: [{ n: '갉기', f: '1234', r: '12', acc: 85, dm: 0.7, fx: [{ k: 'bg', n: 1, t: 3, c: 100 }] }], a: { b: 'swarm', h: 'rat' } },
    // 수로
    { id: 'drowned', n: '익사자', z: 'aq', tg: 'U', hp: 16, spd: 2, dg: 0, pr: 0, dmg: [4, 8], cr: 4, rk: '12', d: '물에서 나온 것은 물을 데리고 나온다.',
      sk: [{ n: '늪물 토하기', f: '12', r: '12', acc: 85, dm: 0.5, fx: [{ k: 'bg', n: 2, t: 3, c: 100 }] }, { n: '붙잡기', f: '12', r: '12', acc: 85, dm: 1 }], a: { b: 'hunch', h: 'bare' } },
    { id: 'hookfish', n: '갈고리 어부', z: 'aq', tg: 'H', hp: 14, spd: 4, dg: 8, pr: 5, dmg: [3, 7], cr: 5, rk: '23', d: '건져 올리는 것이 물고기만은 아니다.',
      sk: [{ n: '갈고리 던지기', f: '23', r: '234', acc: 85, dm: 0.7, fx: [{ k: 'pl', n: 2, c: 90 }] }, { n: '그물', f: '123', r: '12', acc: 85, dm: 0.2, fx: [{ k: 'stun', c: 70 }] }], a: { b: 'coat', h: 'hat', w: 'hook' } },
    { id: 'leech', n: '수로 거머리', z: 'aq', tg: 'B', hp: 10, spd: 5, dg: 10, pr: 0, dmg: [2, 4], cr: 3, rk: '12', d: '팔뚝만 한 거머리. 배가 부르면 떨어지지만 배가 부른 적이 없다.',
      sk: [{ n: '피 빨기', f: '12', r: '12', acc: 85, dm: 0.7, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }], drain: 1 }], a: { b: 'worm', h: 'none' } },
    { id: 'scalepr', n: '비늘 사제', z: 'aq', tg: 'E', hp: 12, spd: 5, dg: 10, pr: 5, dmg: [2, 5], cr: 3, rk: '34', d: '깊은 물에 기도하는 자들. 대답을 들었다고 한다.',
      sk: [{ n: '깊은 곳의 노래', f: '34', r: '1234', m: 1, acc: 85, dm: 0, st: 5 }, { n: '비늘 축복', f: '34', t: 'a', fx: [{ k: 'bf', s: 'pr', v: 20, t: 3 }] }], a: { b: 'robe', h: 'fishhead', w: 'staff' } },
    { id: 'mist', n: '안개 형상', z: 'aq', tg: 'E', hp: 9, spd: 7, dg: 30, pr: 0, dmg: [2, 4], cr: 3, rk: '234', d: '물 위에 서 있는 사람 모양의 안개. 다가가면 없다.',
      sk: [{ n: '스며들기', f: '1234', r: '1234', acc: 90, dm: 0.5, st: 9, ip: 1 }], a: { b: 'float', h: 'none' } },
    { id: 'serpent', n: '물뱀', z: 'aq', tg: 'B', hp: 13, spd: 7, dg: 15, pr: 0, dmg: [2, 5], cr: 5, rk: '123', d: '수면 아래로 길게 이어진 그림자.',
      sk: [{ n: '독니', f: '123', r: '123', acc: 85, dm: 0.6, fx: [{ k: 'bg', n: 3, t: 2, c: 100 }] }], a: { b: 'serpent', h: 'none' } },
    { id: 'mud', n: '진흙 덩어리', z: 'aq', tg: 'E', hp: 24, spd: 1, dg: 0, pr: 10, dmg: [3, 6], cr: 2, rk: '12', d: '수로 바닥이 일어선 것. 안에 무엇이 섞였는지 보이지 않는다.',
      sk: [{ n: '삼키기', f: '1', r: '1', acc: 85, dm: 0.8, fx: [{ k: 'stun', c: 60 }] }, { n: '진흙 튀기기', f: '12', r: '12', m: 1, acc: 85, dm: 0.5, fx: [{ k: 'db', s: 'spd', v: -3, t: 2, c: 80 }] }], a: { b: 'blob', h: 'none', k: 1.1 } },
    { id: 'smugg', n: '밀수꾼', z: 'aq', tg: 'H', hp: 13, spd: 5, dg: 10, pr: 0, dmg: [3, 7], cr: 6, rk: '12', d: '수로를 길로 쓰던 자들. 들어와서 나간 자는 드물다.',
      sk: [{ n: '찢는 칼', f: '12', r: '12', acc: 85, dm: 0.7, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] }, { n: '등불 걷어차기', f: '12', r: '12', acc: 85, dm: 0.5, lt: -10 }], a: { b: 'lean', h: 'hood', w: 'dagger' } },
    // 정원
    { id: 'husk', n: '포자 인간', z: 'gar', tg: 'P', hp: 15, spd: 3, dg: 0, pr: 0, dmg: [3, 6], cr: 3, rk: '12', d: '머리에서 버섯이 자란 사람. 아직 걷는다.',
      sk: [{ n: '포자 기침', f: '12', r: '12', m: 1, acc: 85, dm: 0.3, fx: [{ k: 'bg', n: 1, t: 3, c: 90 }] }, { n: '할퀴기', f: '12', r: '12', acc: 85, dm: 1 }], a: { b: 'hunch', h: 'shroom' } },
    { id: 'vine', n: '가시 덩굴', z: 'gar', tg: 'P', hp: 18, spd: 2, dg: 0, pr: 10, dmg: [3, 6], cr: 4, rk: '1234', d: '돌 틈으로 뻗은 덩굴. 피를 따라 자란다.',
      sk: [{ n: '휘감기', f: '1234', r: '12', acc: 85, dm: 0.4, fx: [{ k: 'stun', c: 60 }, { k: 'bl', n: 2, t: 2, c: 100 }] }], a: { b: 'plant', h: 'none' } },
    { id: 'moths', n: '독나방 떼', z: 'gar', tg: 'B', hp: 8, spd: 8, dg: 25, pr: 0, dmg: [1, 3], cr: 3, rk: '234', d: '빛을 향해 날아드는 것들. 날개 가루가 눈을 멀게 한다.',
      sk: [{ n: '날개 가루', f: '1234', r: '1234', m: 1, acc: 85, dm: 0.3, fx: [{ k: 'db', s: 'acc', v: -8, t: 2, c: 80 }] }], a: { b: 'swarm', h: 'moth' } },
    { id: 'gardener', n: '정원지기 시체', z: 'gar', tg: 'U', hp: 17, spd: 3, dg: 5, pr: 5, dmg: [5, 9], cr: 5, rk: '12', d: '죽은 뒤에도 가지를 친다. 무엇이든.',
      sk: [{ n: '낫질', f: '12', r: '12', m: 1, acc: 85, dm: 0.6, fx: [{ k: 'bl', n: 1, t: 2, c: 80 }] }, { n: '전지가위', f: '12', r: '12', acc: 85, dm: 1 }], a: { b: 'hunch', h: 'hat', w: 'scythe' } },
    { id: 'mycel', n: '균사 덩어리', z: 'gar', tg: 'P', hp: 20, spd: 1, dg: 0, pr: 5, dmg: [2, 4], cr: 2, rk: '34', d: '땅 밑으로 정원 전체와 이어진 덩어리.',
      sk: [{ n: '퍼뜨리기', f: '34', t: 'a', hl: [3, 5] }, { n: '포자 구름', f: '34', r: '1234', m: 1, acc: 85, dm: 0, st: 6 }], a: { b: 'blob', h: 'shroom' } },
    { id: 'rootb', n: '뿌리 짐승', z: 'gar', tg: 'B', hp: 20, spd: 4, dg: 5, pr: 10, dmg: [5, 10], cr: 5, rk: '12', d: '뿌리가 짐승의 모양을 흉내 낸 것.',
      sk: [{ n: '들이받기', f: '12', r: '12', acc: 85, dm: 1, fx: [{ k: 'pu', n: 1, c: 80 }] }], a: { b: 'beast', h: 'antler' } },
    { id: 'petal', n: '꽃잎 마녀', z: 'gar', tg: 'H', hp: 12, spd: 6, dg: 12, pr: 0, dmg: [2, 5], cr: 5, rk: '34', d: '정원의 주인을 자처하는 여자. 향기가 먼저 닿는다.',
      sk: [{ n: '홀리는 향기', f: '34', r: '1234', acc: 90, dm: 0, st: 10, fx: [{ k: 'db', s: 'dg', v: -10, t: 2, c: 80 }] }, { n: '가시 화살', f: '34', r: '1234', acc: 85, dm: 0.9 }], a: { b: 'robe', h: 'veil', w: 'staff' } },
    { id: 'stag', n: '썩은 사슴', z: 'gar', tg: 'B', hp: 18, spd: 6, dg: 10, pr: 0, dmg: [4, 9], cr: 6, rk: '12', d: '뿔에 이끼가 낀 사슴. 눈이 너무 많다.',
      sk: [{ n: '뿔 찌르기', f: '12', r: '12', acc: 85, dm: 1.1 }, { n: '울음', f: '12', r: '1234', acc: 90, dm: 0, st: 7 }], a: { b: 'beast', h: 'antler', k: 1.1 } },
    // 수도원
    { id: 'zealot', n: '광신도', z: 'clo', tg: 'H', hp: 14, spd: 5, dg: 5, pr: 0, dmg: [3, 7], cr: 5, rk: '12', d: '마지막 설교를 끝까지 들은 자들.',
      sk: [{ n: '채찍', f: '12', r: '12', acc: 85, dm: 0.7, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] }, { n: '광신', f: '12', t: 's', fx: [{ k: 'bf', s: 'dm', v: 25, t: 2 }], w: 0.6 }], a: { b: 'robe', h: 'hood', w: 'whip' } },
    { id: 'confess', n: '눈먼 고해 신부', z: 'clo', tg: 'H', hp: 13, spd: 4, dg: 5, pr: 0, dmg: [2, 4], cr: 3, rk: '34', d: '모든 고해를 기억한다. 당신의 것도.',
      sk: [{ n: '죄의 낭독', f: '34', r: '1234', acc: 90, dm: 0, st: 12 }, { n: '참회의 종', f: '34', r: '1234', acc: 85, dm: 0.3, fx: [{ k: 'stun', c: 50 }] }], a: { b: 'robe', h: 'blind', w: 'bell' } },
    { id: 'candlew', n: '촛불 마녀', z: 'clo', tg: 'E', hp: 11, spd: 6, dg: 12, pr: 0, dmg: [2, 5], cr: 4, rk: '34', d: '촛불을 하나씩 끄며 다가오는 여자.',
      sk: [{ n: '촛불 끄기', f: '34', r: '1234', m: 1, acc: 85, dm: 0, st: 4, lt: -12 }, { n: '뜨거운 촛농', f: '34', r: '123', acc: 85, dm: 0.8, fx: [{ k: 'bl', n: 2, t: 2, c: 90 }] }], a: { b: 'robe', h: 'candle' } },
    { id: 'martyr', n: '사슬 순교자', z: 'clo', tg: 'U', hp: 22, spd: 2, dg: 0, pr: 20, dmg: [4, 8], cr: 4, rk: '12', d: '스스로를 묶은 사슬을 끝내 풀지 않았다.',
      sk: [{ n: '사슬 휘두르기', f: '12', r: '12', m: 1, acc: 85, dm: 0.65 }, { n: '순교의 고통', f: '12', r: '1234', acc: 90, dm: 0, st: 8 }], a: { b: 'bones', h: 'bare', w: 'chain', k: 1.08 } },
    { id: 'choir', n: '성가대 망령', z: 'clo', tg: 'E', hp: 10, spd: 7, dg: 25, pr: 0, dmg: [1, 3], cr: 3, rk: '234', d: '아직 끝나지 않은 노래를 부른다.',
      sk: [{ n: '불협 성가', f: '1234', r: '1234', m: 1, acc: 85, dm: 0, st: 6 }], a: { b: 'float', h: 'shroud' } },
    { id: 'ratpr', n: '쥐 사제', z: 'clo', tg: 'H', hp: 11, spd: 6, dg: 10, pr: 0, dmg: [2, 5], cr: 4, rk: '23', d: '쥐에게도 신이 있다고 믿는 사제.',
      sk: [{ n: '역병 축복', f: '234', t: 'a', fx: [{ k: 'bf', s: 'dm', v: 20, t: 2 }] }, { n: '병든 이빨', f: '123', r: '12', acc: 85, dm: 0.7, fx: [{ k: 'bg', n: 2, t: 3, c: 100 }] }], a: { b: 'hunch', h: 'rat', w: 'staff' } },
    { id: 'ringer', n: '종지기', z: 'clo', tg: 'H', hp: 16, spd: 3, dg: 0, pr: 5, dmg: [3, 6], cr: 3, rk: '23', d: '아무도 오지 않는 예배를 위해 종을 친다.',
      sk: [{ n: '큰 종', f: '123', r: '12', m: 1, acc: 80, dm: 0.3, fx: [{ k: 'stun', c: 45 }] }, { n: '종메', f: '12', r: '12', acc: 85, dm: 1 }], a: { b: 'brute', h: 'hood', w: 'bell' } },
    { id: 'penit', n: '고행자', z: 'clo', tg: 'H', hp: 18, spd: 4, dg: 5, pr: 5, dmg: [5, 9], cr: 5, rk: '12', d: '자기 등을 내리치던 채찍을 이제 남에게 쓴다.',
      sk: [{ n: '철퇴', f: '12', r: '12', acc: 85, dm: 1.05 }, { n: '자기 채찍', f: '12', t: 's', fx: [{ k: 'bf', s: 'dm', v: 30, t: 2 }], self: 3, w: 0.5 }], a: { b: 'lean', h: 'bare', w: 'mace' } },
    // 어디서나
    { id: 'brig', n: '굶주린 도적', z: '*', tg: 'H', hp: 12, spd: 4, dg: 5, pr: 0, dmg: [3, 7], cr: 4, rk: '12', d: '먹을 것이 떨어지면 사람은 아래로 내려온다.',
      sk: [{ n: '몽둥이', f: '12', r: '12', acc: 85, dm: 1 }], a: { b: 'lean', h: 'bare', w: 'club' } },
    { id: 'brigxb', n: '도적 석궁수', z: '*', tg: 'H', hp: 10, spd: 4, dg: 5, pr: 0, dmg: [3, 6], cr: 5, rk: '34', d: '어둠 속에서 먼저 쏘는 자가 산다.',
      sk: [{ n: '석궁', f: '34', r: '1234', acc: 85, dm: 1 }], a: { b: 'lean', h: 'hood', w: 'crossbow' } },
    { id: 'brigcut', n: '도적 칼잡이', z: '*', tg: 'H', hp: 13, spd: 6, dg: 10, pr: 0, dmg: [3, 7], cr: 6, rk: '12', d: '칼끝이 늘 웃고 있다.',
      sk: [{ n: '칼질', f: '12', r: '12', acc: 85, dm: 0.75, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] }], a: { b: 'lean', h: 'tricorn', w: 'sword' } },
    { id: 'rat', n: '큰 쥐', z: '*', tg: 'B', hp: 8, spd: 7, dg: 15, pr: 0, dmg: [1, 4], cr: 3, rk: '12', d: '개만 한 쥐. 둘 이상이면 더는 쥐로 보이지 않는다.',
      sk: [{ n: '물기', f: '12', r: '12', acc: 85, dm: 1, fx: [{ k: 'bg', n: 1, t: 2, c: 60 }] }], a: { b: 'rodent', h: 'none' } },
    { id: 'bats', n: '박쥐 떼', z: '*', tg: 'B', hp: 7, spd: 9, dg: 25, pr: 0, dmg: [1, 3], cr: 3, rk: '1234', d: '횃불을 향해 쏟아지는 날개.',
      sk: [{ n: '날개 폭풍', f: '1234', r: '1234', acc: 85, dm: 0.8 }, { n: '횃불 덮치기', f: '1234', r: '1234', acc: 85, dm: 0.3, lt: -6 }], a: { b: 'swarm', h: 'bat' } },
    { id: 'burrow', n: '굴 파는 것', z: '*', tg: 'E', hp: 16, spd: 3, dg: 5, pr: 10, dmg: [3, 6], cr: 4, rk: '23', d: '벽 너머에서 소리만 들리던 것.',
      sk: [{ n: '끌어당김', f: '23', r: '234', acc: 85, dm: 0.6, fx: [{ k: 'pl', n: 1, c: 90 }], st: 3 }, { n: '턱', f: '123', r: '12', acc: 85, dm: 1 }], a: { b: 'worm', h: 'maw', k: 1.1 } },
    // 우두머리 4
    { id: 'bonecrown', n: '뼈 왕관을 쓴 자', z: 'oss', tg: 'U', boss: 1, hp: 78, spd: 4, dg: 5, pr: 25, dmg: [6, 11], cr: 6, rk: '12', d: '납골당의 왕. 왕국은 뼈로, 백성은 침묵으로 이루어졌다.',
      sk: [{ n: '왕의 일격', f: '12', r: '12', acc: 85, dm: 1.1 }, { n: '장례 행렬', f: '1234', t: 's', sum: 'skspear', w: 0.8 }, { n: '무덤 냉기', f: '1234', r: '1234', m: 1, acc: 85, dm: 0.35, st: 5 }, { n: '복종하라', f: '1234', r: '1234', acc: 90, dm: 0, st: 14, fx: [{ k: 'stun', c: 50 }] }],
      a: { b: 'giant', h: 'crown', w: 'sword', k: 1.3 } },
    { id: 'sluice', n: '수문의 어미', z: 'aq', tg: 'E', boss: 1, hp: 84, spd: 3, dg: 5, pr: 15, dmg: [5, 10], cr: 5, rk: '12', d: '수로의 물이 모두 흘러드는 곳에 웅크린 것. 물보다 오래되었다.',
      sk: [{ n: '물살', f: '1234', r: '1234', m: 1, acc: 85, dm: 0.45, fx: [{ k: 'pu', n: 1, c: 60 }] }, { n: '깊은 부름', f: '1234', r: '1234', acc: 90, dm: 0, st: 13 }, { n: '촉수', f: '12', r: '12', acc: 85, dm: 1.15, fx: [{ k: 'bl', n: 2, t: 3, c: 100 }] }, { n: '알 낳기', f: '1234', t: 's', sum: 'leech', w: 0.7 }],
      a: { b: 'tentacle', h: 'none', k: 1.35 } },
    { id: 'sporecrown', n: '포자 왕관', z: 'gar', tg: 'P', boss: 1, hp: 90, spd: 2, dg: 0, pr: 10, dmg: [5, 9], cr: 4, rk: '12', d: '정원 한가운데서 자라는 왕관 모양의 버섯. 그 아래에 무엇이 묻혔는지 아무도 모른다.',
      sk: [{ n: '개화', f: '1234', r: '1234', m: 1, acc: 85, dm: 0, st: 7 }, { n: '뿌리 감기', f: '1234', r: '12', acc: 85, dm: 0.6, fx: [{ k: 'stun', c: 60 }] }, { n: '포자 폭풍', f: '1234', r: '1234', m: 1, acc: 85, dm: 0.3, fx: [{ k: 'bg', n: 2, t: 3, c: 90 }] }, { n: '씨앗 뿌리기', f: '1234', t: 's', sum: 'husk', w: 0.7 }],
      a: { b: 'plant', h: 'crownshroom', k: 1.4 } },
    { id: 'abbot', n: '침묵의 대수도원장', z: 'clo', tg: 'H', boss: 1, hp: 82, spd: 5, dg: 10, pr: 10, dmg: [6, 11], cr: 6, rk: '12', d: '수도원의 마지막 기도를 올린 자. 그 뒤로 입을 연 적이 없다.',
      sk: [{ n: '침묵의 서약', f: '1234', r: '1234', acc: 90, dm: 0, st: 14, fx: [{ k: 'db', s: 'acc', v: -10, t: 2, c: 80 }] }, { n: '불 끄기', f: '1234', r: '1234', m: 1, acc: 85, dm: 0, st: 5, lt: -25 }, { n: '신의 철퇴', f: '12', r: '12', acc: 85, dm: 1.25 }, { n: '수도승 부르기', f: '1234', t: 's', sum: 'zealot', w: 0.7 }],
      a: { b: 'giant', h: 'mitre', w: 'mace', k: 1.3 } },
  ];
  const EI = {}; EN.forEach((e, i) => { EI[e.id] = e; e.i = i; });
  const TGN = { U: '망자', B: '짐승', H: '사람', E: '이형', P: '식물' };

  /* ---------- 기묘한 물건 ---------- */
  // it 쓰면 좋은 결과가 확실한 보급품 · g 좋은 결과 확률(손대기) · good/bad 결과 목록
  // 결과: gold, trk(희귀도), item {k:n}, heal(%), st(±, 전원 또는 손댄 이), qk(+/-), bl/bg, fight, light, buf(층 끝까지), xp
  const CUR = [
    { id: 'coffin', n: '열린 관', ic: 'coffin', z: 'oss', it: 'shovel', g: 0.5, d: '뚜껑이 반쯤 밀려 있다. 안쪽에서 민 자국.',
      good: [{ gold: [60, 140] }, { trk: 1 }], bad: [{ st: 15 }, { fight: 1 }, { bg: 3 }] },
    { id: 'ossuary', n: '뼈 무더기 제단', ic: 'sword-altar', z: 'oss', it: 'holy', g: 0.4, d: '두개골이 가지런히 쌓여 있다. 누군가 아직 돌본다.',
      good: [{ st: -20 }, { buf: { s: 'vsU', v: 20 } }], bad: [{ st: 20 }, { qk: -1 }] },
    { id: 'urn', n: '봉인된 유골함', ic: 'cauldron', z: 'oss', it: 'key', g: 0.45, d: '밀랍으로 봉인한 항아리. 안에서 무언가 구른다.',
      good: [{ trk: 1 }, { gold: [80, 160] }], bad: [{ bg: 3 }, { st: 12 }] },
    { id: 'well', n: '물 마른 우물', ic: 'fountain', z: 'aq', it: 'shovel', g: 0.45, d: '바닥이 보이지 않는다. 물소리는 들린다.',
      good: [{ gold: [50, 130] }, { item: { torch: 2 } }], bad: [{ fight: 1 }, { st: 12 }] },
    { id: 'net', n: '버려진 그물', ic: 'spider-web', z: 'aq', it: 'band', g: 0.5, d: '무언가 걸려 있다. 아직 움직인다.',
      good: [{ item: { food: 4 } }, { trk: 0 }], bad: [{ bl: 3 }, { fight: 1 }] },
    { id: 'idol', n: '비늘 덮인 우상', ic: 'crystal-shrine', z: 'aq', it: 'holy', g: 0.35, d: '물고기도 사람도 아닌 얼굴. 바닥에 제물이 놓여 있다.',
      good: [{ gold: [100, 200] }, { qk: 1 }], bad: [{ st: 25 }, { qk: -1 }] },
    { id: 'shroom', n: '빛나는 버섯 군락', ic: 'mushrooms', z: 'gar', it: 'anti', g: 0.4, d: '은은한 빛. 먹어도 되는지는 먹어 봐야 안다.',
      good: [{ heal: 30 }, { light: 25 }], bad: [{ bg: 4 }, { qk: -1 }] },
    { id: 'grave', n: '꽃 덮인 무덤', ic: 'grave-flowers', z: 'gar', it: 'shovel', g: 0.5, d: '꽃이 너무 싱싱하다. 이 어둠 속에서.',
      good: [{ trk: 1 }, { gold: [60, 150] }], bad: [{ fight: 1 }, { st: 15 }] },
    { id: 'pod', n: '부푼 꼬투리', ic: 'scarab-beetle', z: 'gar', it: 'anti', g: 0.45, d: '사람 하나가 들어갈 만한 크기. 맥박이 뛴다.',
      good: [{ item: { anti: 2, band: 2 } }, { gold: [70, 140] }], bad: [{ bg: 4 }, { fight: 1 }] },
    { id: 'confbox', n: '고해실', ic: 'bookshelf', z: 'clo', it: 'holy', g: 0.4, d: '칸막이 너머에서 누군가 숨을 쉰다.',
      good: [{ st: -25 }, { qk: 1 }], bad: [{ st: 22 }, { qk: -1 }] },
    { id: 'reliq', n: '성유물함', ic: 'locked-chest', z: 'clo', it: 'key', g: 0.4, d: '금박이 벗겨진 상자. 성인의 손가락뼈가 든다고 적혀 있다.',
      good: [{ trk: 2 }, { gold: [100, 180] }], bad: [{ st: 15 }, { bl: 3 }] },
    { id: 'candles', n: '촛불 꽂힌 벽감', ic: 'candles', z: 'clo', it: 'holy', g: 0.5, d: '타지 않는 초. 손을 대면 따뜻하다.',
      good: [{ light: 40 }, { buf: { s: 'acc', v: 6 } }], bad: [{ light: -30 }, { st: 10 }] },
    { id: 'books', n: '곰팡이 핀 책장', ic: 'bookshelf', z: '*', it: '', g: 0.5, d: '책등의 글자가 읽히지 않는다. 읽히는 것도 있다.',
      good: [{ xp: 3 }, { buf: { s: 'cr', v: 5 } }], bad: [{ st: 14 }, { qk: -1 }] },
    { id: 'chest', n: '잠긴 상자', ic: 'locked-chest', z: '*', it: 'key', g: 0.4, d: '자물쇠가 녹슬었다. 억지로 열 수는 있다.',
      good: [{ gold: [80, 180] }, { trk: 0 }], bad: [{ bl: 2 }, { st: 8 }] },
    { id: 'corpse', n: '먼저 온 원정대', ic: 'dread-skull', z: '*', it: '', g: 0.55, d: '배낭을 멘 채 벽에 기대 앉아 있다. 얼굴은 보지 않는 게 좋다.',
      good: [{ item: { food: 3, torch: 1 } }, { gold: [40, 100] }], bad: [{ st: 16 }, { bg: 2 }] },
    { id: 'altar', n: '피 흘린 제단', ic: 'sword-altar', z: '*', it: 'holy', g: 0.35, d: '돌에 홈이 파여 있다. 무엇을 받으려고.',
      good: [{ buf: { s: 'dm', v: 15 } }, { qk: 1 }], bad: [{ hurt: 20 }, { st: 18 }] },
    { id: 'mirror', n: '금 간 거울', ic: 'mirror-mirror', z: '*', it: '', g: 0.4, d: '비친 얼굴이 조금 늦게 따라온다.', good: [{ st: -15 }, { vir: 1 }], bad: [{ st: 22 }] },
    { id: 'cauld', n: '식은 솥', ic: 'cauldron', z: '*', it: 'anti', g: 0.5, d: '아직 국물이 남아 있다. 건더기는 고기처럼 보인다.', good: [{ item: { food: 5 } }, { heal: 20 }], bad: [{ bg: 3 }, { qk: -1 }] },
  ];
  const CI = {}; CUR.forEach((c) => (CI[c.id] = c));

  /* ---------- 함정 ---------- */
  const TRAPS = [
    { n: '바닥 창', d: '디딤돌 아래에서 창이 솟는다.', e: { hurt: 18, bl: 2 } },
    { n: '독 바늘', d: '벽 틈에서 바늘이 튀어나온다.', e: { hurt: 8, bg: 3 } },
    { n: '무너지는 천장', d: '돌이 쏟아진다.', e: { hurt: 12, all: 1 } },
    { n: '목소리 덫', d: '벽 속에서 아는 목소리가 부른다.', e: { st: 18, all: 1 } },
  ];

  /* ---------- 서술 (절제된 문장, 느낌표 없음) ---------- */
  const NAR = {
    start: ['계단은 생각보다 길었다. 돌아갈 길도 그만큼 길 것이다.', '횃불을 들고 내려가는 자들은 늘 같은 것을 믿는다. 자기들은 돌아올 거라고.', '위에서는 아무도 기다리지 않는다. 그래서 내려갈 수 있다.'],
    floor: ['한 층 더 내려왔다. 공기가 무거워졌다.', '발밑의 돌이 젖어 있다. 위에서 흘러온 것은 아니다.', '이 층의 어둠은 조금 더 오래되었다.', '벽에 손자국이 있다. 안에서 밖으로.'],
    dark: ['빛이 줄어들수록 벽은 가까워진다.', '어둠 속에서는 숨소리가 하나 더 들린다.', '불꽃이 낮아지자 그림자들이 자리를 바꿨다.'],
    pitch: ['완전한 어둠. 이제 보이는 것은 보여서는 안 되는 것뿐이다.', '불이 꺼졌다. 여기서는 눈을 뜨나 감으나 같다.'],
    crit: ['정확했다. 그리고 그것으로 충분했다.', '한 번의 일격이 망설임을 끝냈다.', '칼날은 길을 알고 있었다.'],
    hurt: ['피는 생각보다 따뜻하다.', '상처는 거짓말을 하지 않는다.'],
    dd: ['숨이 끊어질 듯 이어진다. 문턱은 바로 앞이다.', '쓰러졌다. 아직 일어날 수는 있다.'],
    death: ['한 사람의 자리가 비었다. 어둠은 그 자리를 오래 비워 두지 않는다.', '이름을 부를 사람도 없이 쓰러졌다.', '남은 자들은 뒤를 돌아보지 않으려 애썼다.'],
    afflict: ['무너지는 것은 소리 없이 시작된다.', '마음이 먼저 꺾였다. 몸은 아직 모른다.', '두려움은 전염된다. 가장 가까운 사람부터.'],
    virtue: ['어떤 이들은 바닥에서 단단해진다.', '부서지는 대신, 굳었다.', '두려움 앞에서 그는 오히려 조용해졌다.'],
    boss: ['그것은 기다리고 있었다. 오래전부터.', '이 층의 주인이 고개를 들었다.', '여기까지 온 자들은 많았다. 여기서 끝난 자들도.'],
    bossdown: ['주인이 쓰러지자 어둠이 잠시 물러났다.', '왕좌는 비었다. 오래 비어 있지는 않을 것이다.'],
    camp: ['불가에 둘러앉았다. 아무도 먼저 말하지 않았다.', '불은 작고, 밤은 길다.', '잠들기 전 각자 무기를 한 번 더 확인했다.'],
    way: ['무너진 역참. 아직 불 피울 자리가 남아 있다.', '여기서 숨을 고른다. 다음 계단은 더 깊다.'],
    win: ['가장 깊은 곳의 문이 닫혔다. 돌아가는 계단은 처음보다 짧게 느껴졌다.', '그들은 돌아왔다. 전부는 아니지만.'],
    lose: ['마지막 횃불이 꺼졌다. 이 이야기를 위로 전할 사람은 없다.', '지하는 그들을 기억하지 않을 것이다.'],
    curio: ['손을 대기 전에 한 번 더 생각해야 했다.', '호기심은 늘 값을 받아 간다.'],
    loot: ['죽은 자의 주머니는 무겁지 않았다. 그래도 가져간다.'],
  };
  const narr = (k) => pick(NAR[k] || ['']);
  const ICO = {
    "all-seeing-eye": "M4.5 4.5v3.9L44.9 53.9l2.4-4.1L7 4.5H4.5zm19.4 0l24.2 43.6 2.6-4.5L29.1 4.5h-5.1zm22.8 0c1.1 4.8 3.8 16.8 7.1 31.3 .1 .6 .3 1.2 .4 1.8l3.3-5.7C54.8 19.7 52.5 9.5 51.3 4.5h-4.6zM61.8 4.5v20.1l2.2-3.9 1.9 3.4L66.2 24.6V4.5h-4.5zm14.9 0l-6.1 27.6 3.3 5.8L81.3 4.5h-4.6zm22.2 0l-21.7 39.1 2.6 4.5L104.1 4.5h-5.1zm22.1 0L80.8 49.7l2.4 4.1L123.5 8.4V4.5h-2.5zM4.5 24.6v5.6l37.7 28.3 2.3-3.9L4.5 24.6zm119 0L83.5 54.5l2.3 3.9L123.5 30.2v-5.6zm-59.5 5.1l-18.7 32.3c5.1-2.3 11.6-3.6 18.7-3.6 7.1 0 13.6 1.3 18.7 3.6L64 29.7zm-59.5 17.6v4.8l34 12.8 2.3-4L4.5 47.3zm119 0l-36.3 13.6 2.3 4L123.5 52.1v-4.8zM4.5 62.3v4.5l30.7 3.8 2.4-4.2L4.5 62.3zm119 0l-33.1 4.1 2.4 4.2L123.5 66.8v-4.5zm-59.5 .6c-3.7 0-6.6 2.9-6.6 6.6 0 2.1 1 4 2.5 5.2a7 7 0 0 1-.3-2.2 7 7 0 0 1 7-7 7 7 0 0 1 3.3 .8c-1.1-2.1-3.3-3.5-5.8-3.5zm-9.5 .9c-3.2 .6-6 1.6-8.3 2.7-4.4 2.2-6.6 4.9-6.6 7.4 0 2.5 2.1 5.2 6.6 7.4 4.4 2.2 10.8 3.7 17.8 3.7 7 0 13.4-1.5 17.8-3.7 4.4-2.2 6.6-4.9 6.6-7.4 0-2.5-2.1-5.2-6.6-7.4-2.3-1.1-5.1-2.1-8.3-2.7 1 1.7 1.6 3.6 1.6 5.7 0 6.1-5 11.1-11.1 11.1-6.1 0-11.1-5-11.1-11.1 0-2.1 .6-4 1.6-5.7zm-21 9.7L4.5 77.2v4.5l26.2-3.3 2.8-4.9zm61 0l2.8 4.9L123.5 81.7v-4.5l-29-3.6zm-58.4 4.5l-14.3 24.7h84.4l-14.3-24.7c-1.4 3-4.4 5.5-8.1 7.3-5.2 2.6-12.2 4.1-19.8 4.1-7.7 0-14.6-1.5-19.8-4.1-3.7-1.8-6.7-4.3-8.1-7.3zm64 5l3.5 6.1L123.5 96.7v-4.8l-23.5-8.8zm-72.1 0L4.5 91.9v4.8l19.9-7.5 3.5-6.1zm-7.9 13.7L4.5 106.5v5.3l10.8-6.7 4.8-8.3zm87.9 0l4.8 8.3L123.5 111.8v-5.3l-15.6-9.7zm-87.7 10.5L4.5 121.1V123.5h4.1l18.5-16.2H20.2zm10.5 0L16.9 123.5h5.9l13.9-16.2h-5.9zm10.5 0L32 123.5h5.2l9.3-16.2h-5.2zm10.7 0c-2.2 7.2-3.9 13-4.9 16.2h4.7c1.2-3.8 2.9-9.4 4.9-16.2h-4.7zm9.8 0V123.5h4.5v-16.2h-4.5zm10 0L76.4 123.5h4.7l-4.6-16.2h-4.7zm9.8 0L90.8 123.5h5.2l-9.3-16.2h-5.2zm9.7 0L105.2 123.5h5.9l-13.9-16.2H91.3zm9.6 0L119.4 123.5H123.5v-2.4l-15.7-13.8H100.9z",
    "angry-eyes": "M28 40.8c-4.9 0-12.8 3-12 8 17.1 4.6 30.8 12.1 44 20-10.7-12.8-27.2-28-32-28zm72 0c-4.8 0-21.3 15.2-32 28 13.2-7.9 26.9-15.4 44-20 .8-5-7.1-8-12-8zm-76 24.3c-1.6 0-2.9 .4-4.4 1.2-1.9 1.1-4.1 3.1-6.6 6.4 3.1 3.2 7.2 7.6 13.1 9.3 6.3 1.9 14.9 1.1 27.1-8.2-4.5-1.3-8.3-2.6-11.6-3.7 .4 .8 .7 1.8 .7 2.8 0 3.4-2.8 6.2-6.2 6.2s-6.2-2.8-6.2-6.2c0-2.5 1.5-4.6 3.6-5.6-2.6-.9-4.8-1.5-6.6-1.8-.7-.1-1.4-.2-2-.2-.2 0-.5 0-.7 0zm80 0c-.2 0-.5 0-.7 0-.6 0-1.3 .1-2 .2-1.8 .3-4 1-6.6 1.8 2.1 1 3.6 3.2 3.6 5.6 0 3.4-2.8 6.2-6.2 6.2s-6.2-2.8-6.2-6.2c0-1 .2-1.9 .7-2.8-3.4 1.2-7.2 2.4-11.6 3.7 12.2 9.3 20.8 10.1 27.1 8.2 5.9-1.8 10-6.1 13.1-9.3-2.6-3.2-4.7-5.3-6.6-6.4-1.4-.8-2.8-1.2-4.4-1.2z",
    "armor-downgrade": "M64 5.5l-1.4 1C46.9 18.4 31.4 26.1 7.6 30.1l-1.9 .3v1.9c0 4.8 2.1 12.2 5.5 21.3 3.4 9.1 8.2 19.7 13.8 29.8 5.6 10.1 11.8 19.7 18.4 26.9 6.5 7.2 13.4 12.2 20.5 12.2s14-5 20.6-12.2c6.5-7.2 12.8-16.8 18.4-26.9 5.5-10.1 10.3-20.7 13.8-29.8 3.4-9.1 5.5-16.5 5.5-21.3v-1.9l-1.9-.3c-23.6-4-39.2-11.7-55-23.6zm0 5.5c15.3 11.3 31.1 19 53.6 23.1-.5 3.8-2.2 10.3-5.1 17.9-1 2.7-2.1 5.5-3.4 8.5H72v11.5l16-4-24 28-24-28 16 4v-11.5H18.9c-1.2-3-2.4-5.8-3.4-8.5-2.8-7.5-4.6-14.1-5.1-17.9C32.9 30.1 48.7 22.3 64 11z",
    "armor-upgrade": "M64 5.5l-1.4 1C46.9 18.4 31.4 26.1 7.6 30.1l-1.9 .3v1.9c0 4.8 2.1 12.2 5.5 21.3 3.4 9.1 8.2 19.7 13.8 29.8 5.6 10.1 11.8 19.7 18.4 26.9 6.5 7.2 13.4 12.2 20.5 12.2s14-5 20.6-12.2c6.5-7.2 12.8-16.8 18.4-26.9 5.5-10.1 10.3-20.7 13.8-29.8 3.4-9.1 5.5-16.5 5.5-21.3v-1.9l-1.9-.3c-23.6-4-39.2-11.7-55-23.6zm0 5.5c15.3 11.3 31.1 19 53.6 23.1-.5 3.8-2.2 10.3-5.1 17.9-1 2.7-2.1 5.5-3.4 8.5H72v-12.2l16 4-24-28-24 28 16-4V60.5H18.9c-1.2-3-2.4-5.8-3.4-8.5-2.8-7.5-4.6-14.1-5.1-17.9C32.9 30.1 48.7 22.3 64 11z",
    "arrow-cluster": "M64.3 3.9l-12.6 21.9 7-2.1 5.6-9.7 5.6 9.7 7 2.1-12.6-21.9zm-34.7 19.4l4.6 24.8 3.5-5.5L35.4 30l12.2 4.3 5.8-2.5-23.8-8.4zm69.7 0l-23.8 8.4 6 2.6L93.9 30l-2.5 13.2 3.2 5 4.6-24.8zm-34.9 .5l-2.3 .7v26.1l2.4 2.8 2.2-2.6V24.6l-2.3-.7zm20.3 13l-13.6 15.9 .1 .1-3.6 4.2 3 3.5 17.8-20.8-1.2-1.8-2.5-1.1zm-40.3 .1l-2.1 .9-1.4 2.1 63.9 74.9L108.2 111.9l-2-2.4 5.7-2.5 2.9-1.3-2-2.4-11-12.9-.6-.7-.9-.1-12.4-1.7-43.5-51zm14 30.8l-15.6 18.2 0 0-1.7 1.9-12.4 1.7-.9 .1-.6 .7-11.1 13-2 2.4 2.9 1.3 5.7 2.5-2 2.4 3.6 3L61.4 71.3l-3-3.5zm6.1 7l-2.4 2.8v44.7h4.7v-3.8l6.2 1.9 3 .9v-21.8l-.6-.7-8.6-9.6v-11.9l-2.2-2.6zm-27.9 18.4l-10.7 12.6L21.7 104l8.5-9.9 6.4-.9zm55.8 .1l6.4 .9 8.4 9.9-4.1 1.8-10.7-12.5zm-35 1.1l-4 4.5-.6 .7v21.8l3-.9 1.6-.5v-25.6zm9.3 1.9l4.6 5.1v13.7l-4.6-1.4v-17.4zm-21.9 1.4l-16.1 18.7 .9 1.4 1.7 2.6 2-2.4 11.1-13 .6-.7 0-.9-.1-5.7zm39.5 0l-.1 5.7 0 .9 .6 .7 11 12.9 2 2.4 1.7-2.7 .9-1.4-16.1-18.6z",
    "axe-swing": "M58 6.4c-20.5 .2-40.7 9.4-53.3 25.9 6.5-5.6 14.3-9.6 22.5-11.9-15.6 13.4-23.6 34.8-19.9 56.3 .3-7.1 1.9-13.9 4.8-20.2 .3 12.9 4.6 25.5 13.1 35.8-9.5-19-5.7-48.3 10-60.1 2.9-1.5 6-2.7 9.3-3.6C71.1 21.3 98.6 37.8 105.8 65.4c4.1 15.9 .6 32.1-8.3 44.3-1.2 1.2-2.5 2.2-3.9 3.2-1.5-.5-2.8-1-4-1.8-3-1.9-4.9-5-5.2-8.4-.5-6.2 3.5-13.3 11.6-20.1l-7.4-5.5c-4 9.9-9.7 15.5-16 16.3-3.5 .4-6.9-.7-9.8-3-2.1-1.7-3.9-4-5.4-6.9-4.2 4.8-5.2 10.8-4 16.8 1.4 7 5.9 13.9 11.8 18.1 5.5 3.8 12.4 5.3 18.7 4.1 2.3-.4 4.4-1.2 6.5-2.3 4.5-2.2 8.6-5 11.8-8.8 16.3-14.5 24.1-37.8 18.1-60.7C113.4 23.9 89.7 6.2 63.9 6.5c-.4 0-.8 0-1.2 0-1.6-.1-3.1-.1-4.7-.1zm-22.7 36.3c-3.1 0-4.5 4-1.5 5.9l47.2 33.3c1.1-1.6 2.1-3.5 3.1-5.8L37.7 43.4c-.9-.5-1.7-.7-2.4-.7z",
    "back-forth": "M60.5 7.2l-5.3 1.3L8.3 19.6l-2.4 .6 .7 2.4 13.7 46 1.5 5.2 2.7-4.7 9.2-15.8 9.8 5.7 2.3-4-11.9-6.8L32 46.9l-1.2 2-7.6 13.1-11.4-38.5 39.2-9.4-7.6 13.1-1.2 2 2 1.2L83.2 52.9l-4.4 7.6 4.1 2.3 5.6-9.6 1.2-2-2-1.2-39-22.4 9.1-15.8 2.7-4.7zm-7.1 44.1l-14.4 24.8 38.8 22.4 2 1.2-1.2 2-11 19.1 54.7-13.1-16-53.9-11 19.1-1.2 2-2-1.2-38.8-22.4z",
    "bandage-roll": "M31.8 4.6c-2.1 0-4.1 1-6.3 3.1-2.1 2.1-4.2 5.4-6 9.6-3.5 8.4-5.8 20.2-5.8 33.3 0 13.1 2.3 24.9 5.8 33.3 1.8 4.2 3.8 7.5 6 9.6 2.1 2.1 4.2 3.1 6.3 3.1v0l23.6-.1c-4.7-11.8-6.5-24.9-5.9-38.3 .8-16.7-4.8-31.1-10-36-1.5-1.4-2.7-1.9-3.9-1.8-1.2 0-2.5 .6-3.9 2-2.8 2.8-5.7 9-7.1 18.1-1 6.9-.9 14.7 .1 21.2 1.1 6.6 3.3 11.9 5.5 13.8 .8 .7 1.3 .8 1.7 .8 .5 0 1.1-.3 1.9-1.1 1.5-1.5 3.1-5.1 3.9-10.2 0 0 0 0 0 0 .3-1.5 .5-3.3 .5-5.2 0-5.6-1.6-10.1-3.7-10.1-1.9 0-3.5 4.1-3.6 9.3-.4-1.8-.6-3.7-.6-5.9 0-7.1 2.4-12.8 5.4-12.8 .8 0 1.5 .4 2.2 1.1 0 0 0 0 0 0 2.6 2.2 3.6 5.8 4.3 9.9 .7 4.3 .8 9.1 .2 13.6-.8 6.1-2.6 10.7-5.3 13.5-1.3 1.4-3 2.4-4.9 2.5-1.9 .1-3.7-.6-5.2-1.9-3.8-3.4-5.8-9.5-7-16.6-1.1-7.1-1.2-15.2-.1-22.6 1.4-9.7 4.3-16.7 8.4-20.7 2-2 4.5-3.3 7.1-3.3 2.6-.1 5.1 1.1 7.3 3.1 7 6.7 12.3 21.8 11.4 39.6-.7 16.1 2.1 31.2 9.3 44.4 2.4 4.2 5.3 8.2 8.7 11.9 0 0 0 .1 .1 .1l8.3 9.2 3.5-3.1-2.1-2.4 3.4-3-3.7-4.2c1.5-.5 3.1-.9 4.7-1.2 .3 .3 .6 .7 1 1.1 .9 1 2 2.2 3.1 3.4 2.2 2.5 4.3 4.9 4.3 4.9l3.5-3.1s-2.1-2.4-4.3-4.9c-.6-.7-1.3-1.4-1.9-2.1 0 0 .1 0 .1 0 1.5 .8 3.4 1.9 5.3 3 3.8 2.1 7.5 4.2 7.5 4.2l2.2-3.9c3.3 1.8 6.6 3.7 6.6 3.7l2.3-4.1s-3.7-2.1-7.5-4.2c-1.2-.7-2.3-1.3-3.4-1.9 1.1-.4 2.2-.8 3.3-1.3l13.1 .5 .2-4.7L114.2 100.5c-12.4-2.6-21.8-18.6-22.2-36.4 .6-4.3 .9-8.8 .9-13.5 0-12.8-2.4-24.4-6.2-32.6-3.8-8.3-8.8-12.9-13.6-13.2l-41.4-.1v0z",
    "barrel": "M64 10.2c-10.9 0-20.8 .9-27.8 2.3-3.5 .7-6.3 1.5-8.1 2.4-.9 .4-1.5 .8-1.7 1.1l0 0 0 0c.3 .3 .9 .7 1.7 1.1 1.7 .8 4.5 1.7 8.1 2.4C43.2 20.9 53.1 21.8 64 21.8s20.8-.9 27.8-2.3c3.5-.7 6.3-1.5 8.1-2.4 .9-.4 1.5-.8 1.7-1.1l0 0 0 0c-.3-.3-.9-.7-1.7-1.1-1.7-.8-4.5-1.7-8.1-2.4C84.8 11.1 74.9 10.2 64 10.2zm-20 3.8a8 2 0 0 1 8 2 8 2 0 0 1-8 2 8 2 0 0 1-8-2 8 2 0 0 1 8-2zm-18.8 6.6c-.7 3-1.9 8-3 13.8 4.2 1.1 8.4 2 12.6 2.7 .7-4.3 1.7-8.6 2.8-12.9-.8-.1-1.6-.3-2.3-.4-3.7-.7-6.8-1.6-9.1-2.7-.3-.2-.7-.3-1-.5zm77.6 0c-.3 .2-.6 .3-1 .5-2.3 1.1-5.4 2-9.1 2.7-.7 .1-1.5 .3-2.3 .4 1.3 4.2 2.4 8.5 3.2 12.8 4.1-.7 8.1-1.6 12.1-2.7-1.2-5.8-2.3-10.8-3-13.8zm-16.9 4.3c-5.8 .7-12.5 1.2-19.7 1.3v13.5c7.7-.1 15.4-.8 23-1.9-.9-4.3-2-8.6-3.3-12.9zm-43.9 0c-1.2 4.3-2.1 8.7-2.9 13 7.5 1.1 15 1.7 22.5 1.8V26.2c-7.2-.1-13.9-.5-19.7-1.3zm-21.1 13.8l-1.4 7.5c32.1 7.7 60 7.5 88.3 0l-1.2-7.5c-27.7 7.2-57 7.4-85.7 0zm87.7 12c-4.2 1.1-8.5 2-12.7 2.8 .9 11.9 .4 24-.9 36.1 4.7-1 9.2-2.1 13.6-3.5C109.9 78.7 109.8 72.9 109.8 64c0-3.7-.4-8.3-1.1-13.2zm-89.3 .1C18.7 55.7 18.2 60.3 18.2 64c0 5.9 1.2 14.3 2.6 22.4 4.2 1.2 8.3 2.2 12.6 3.1-1.1-11.9-1.5-23.8-.6-35.8-4.4-.8-8.9-1.7-13.4-2.8zm17.9 3.5c-.8 12-.4 24 .8 36 7.9 1.4 15.8 2.1 23.7 2.3V56.5c-8-.1-16.1-.8-24.5-2.1zm54.2 0c-8.3 1.3-16.7 2-25.2 2.1V92.7c8.2 0 16.3-.7 24.2-2.1 1.4-12.3 1.9-24.4 1.1-36.2zM21.7 91.2l2.1 8c26 8.1 56.4 8.1 81.5 .2l2.1-8.1c-26.5 7.8-57 7.8-85.7-.1zm2.8 12.9c1 4.2 1.6 7 1.7 7.2 .2 .5 1.2 1.6 3.2 2.6 1.9 .9 4.6 1.7 7.7 2.4-.5-3.1-1-6.3-1.5-9.4-3.8-.8-7.5-1.7-11.1-2.7zm79.6 .3c-3.7 1.1-7.6 2-11.5 2.8-.5 3-1 6-1.6 9.1 3.1-.7 5.7-1.5 7.6-2.4 2.1-1 3.1-2.1 3.3-2.6 .8-2.4 1.5-4.7 2.2-6.8zm-63.8 3.3c.5 3.1 1 6.3 1.5 9.4 5.9 .9 12.9 1.4 20 1.5V109.8c-7.2-.2-14.4-.8-21.5-2zm47.6 .3c-7.1 1.1-14.3 1.7-21.6 1.8v8.9c7.1-.1 14.1-.6 20-1.5 .6-3 1.1-6.1 1.7-9.1z",
    "battle-axe": "M60 4.9c-14.2 .1-27.7 7.3-37.9 18.1-13.4 14.2-20.5 34.5-15.3 52.5 4.1-2.2 8.2-4 12.2-5.3-1.6-30.8 22.3-52.7 50-52.6 1.1-3.3 2.6-6.8 4.5-10.5-4.1-1.4-8.2-2.1-12.2-2.2-.5 0-.9 0-1.4 0zM67.8 22.2C43.4 22.7 22.8 41.5 23.7 68.8c2.7-.7 5.4-1.1 8.1-1.4 3.6-.3 7.2-.1 10.4 .6L69.6 40.7c-1.3-3-2.1-6.3-2.3-9.7-.2-2.8 0-5.7 .6-8.8 0 0 0 0-.1 0zm15.2 15.2l-4.2 4.2L86.4 49.2l4.2-4.2-7.6-7.6zm-9.3 5.8L43.9 73l11.2 11.1 29.8-29.8L73.8 43.2zm47.5 11.5c-3.6 2-7.1 3.5-10.4 4.5 .2 27.8-21.8 51.7-52.7 50.1-1.3 4-3.1 8.1-5.3 12.2 18 5.2 38.3-1.9 52.5-15.3 14.3-13.4 22.1-32.7 15.9-51.5zm-34 3.9L60.2 85.7c.8 3.4 1 7.1 .7 10.9-.2 2.6-.7 5.4-1.4 8.1 27.4 .9 46.3-19.8 46.6-44.2-3.1 .6-6 .9-8.9 .7-3.6-.2-6.9-1.1-10.1-2.5zM42.4 78.1L5 115.4V123.5H12.2l37.8-37.8-7.6-7.6z",
    "bell-shield": "M53.6 19.1c0 4.2 1.4 7.9 3.6 10.5l2.5 3-3.9 .7c-2.8 .5-4.8 2-6.5 4.3-1.7 2.4-3 5.7-4 9.5-1.7 6.9-2 15.4-2.1 22.8h9.2l2.5 33.8c6.4 1.4 13.2 1.4 19.4 0l2.2-33.8h8.7c0-7.5-.1-16.1-1.6-23.1-.8-3.9-2.1-7.2-3.9-9.5-1.8-2.4-3.9-3.8-7-4.3l-4-.6 2.5-3.1c2-2.5 3.4-6.2 3.4-10.3 0-8.1-5.1-14.1-10.6-14.1-6.2-.1-10.5 8.3-10.6 14.1zm-7-13.1C27.3 19.5 4.9 64.5 4.9 106.3v.2c0 1.6 1.1 3.5 3.9 5.6 2.8 2.1 7.1 4.1 12.5 5.8 10.8 3.4 26 5.5 42.8 5.5 16.8 0 32-2.1 42.8-5.5 5.4-1.7 9.7-3.7 12.5-5.8 2.8-2 3.9-4 3.9-5.6 0-.3 0-.6-.1-.9-.2-41.6-22.4-86.2-41.6-99.6C99.8 40.2 102.1 79.7 99.9 110.8c-8.3 3.4-21.3 5.5-35.8 5.5-14.6 0-27.5-2.2-35.9-5.5-3.4-43.2 3.2-85.6 18.2-104.7z",
    "bird-claw": "M4.1 3.6v17.4c14.1 6.6 34.9 31.2 30.4 38.4-5 2.4-10.4 4.5-16.6 6.5-.7 .1-1.4 .4-2 .6-.1 0-.1 0-.1 0l0 0c-4.2 1.9-7.2 6.5-7.4 11.1-.3 .4-.6 .7-.8 1.2-3 5.2-4.8 11.6-2.8 17.6 2 5.9 7.8 10.8 18.3 12.6l7.6 1.3-5.6-5.3c-5.1-4.9-5.9-11.1-3.9-15.9 4.6-.6 8.3-4.3 9.7-8.7 0 0 0 0 0-.1 2.1-5.3 5.3-10.1 10.5-11.7 5.5-1.7 22.4 4.9 30.7 18.9 .8 2.4 2.5 4.7 5.4 6.3 1.7 .9 3.4 1.4 5 1.5 2 1.9 4 4.4 5.5 7.2 2.1 3.9 3.1 8.1 2.1 12.1l-1.9 7.5L93.9 117c7.9-7.1 10.4-14.4 9.4-20.9-1-6-4.7-11-8.7-14.9-.5-3-2.2-5.9-5.7-7.8-2-1.1-4-1.6-5.9-1.5-.3 0-.5 0-.8 .1-3.9 0-8.5-.7-12.5-2.2-5.5-4-5.2-7.7-.6-10.2 6.9-.7 13.6 1.5 19 4.3 .5 .4 1 .7 1.6 1 5.5 3 10.6 1.3 13.8-2.3 1.9 .3 3.9 1.1 5.8 2.5 2.8 2 5.3 5.2 7.2 8.7l2.6 4.8 1.7-5.2c3.3-10.1 1.8-17.6-2.6-22.1-3.8-4-9.3-5.5-14.6-5.7-.3 0-.5 0-.8 0-.5-.4-1.1-.8-1.8-1.2-2-1.1-4-1.6-5.9-1.5-1.5 .1-2.9 .4-4.2 1v0c-7.9 3.8-15.6 5.6-23.3 7-2-.8-2.6-2.3-1.3-4.9 4.7-4.5 10.3-8.2 15.9-10.1 3.5-.5 6.5-2.8 8.3-5.8 2.1-.6 4.5-1 6.8-1 3.8 0 7.4 1.1 9.9 3.8l5.3 5.8-1.3-7.7C109.5 20.8 105 15 99.5 12.8c-2.1-.8-4.3-1.2-6.4-1.2-3 0-6 .6-8.8 1.5-1.1-.3-2.1-.5-3.1-.5-4.8-.1-8.8 3.2-10.7 7.4 0 0 0 0 0 0-.3 .6-.5 1.2-.6 1.8-1.5 3.8-3.2 7.5-5.3 10.9-8.7 7.8-17 4.8-23.4-3.9C36.1 21.6 31.7 12.4 29.2 3.6H4.1zm88.9 12.7c1.7 0 3.3 .3 4.8 .8 3 1.2 5.6 3.7 7.4 8.9-2.5-1.1-5.2-1.5-7.8-1.5-3.3 0-6.5 .6-9.3 1.6-1.8 .6-2.9 1.2-3.4 1.4-.5 .3-.3 .3-.8-.2-.5-.5-1.2-1.7-1.5-3.1-.3-1.4-.3-2.9 .1-4 .4-1.1 .9-1.8 2-2.2h0v0c2.8-1 5.8-1.7 8.6-1.7zm9.4 34.1c4.8 0 9.5 1.4 12.3 4.3 2.4 2.5 3.8 6.3 2.8 12.3-1.6-2.1-3.4-4.1-5.5-5.6-3.5-2.6-7.6-4.1-11.9-3.4-.8 .1-1 0-1.4-.6-.4-.6-.8-1.6-.8-2.8 0-1.1 .3-2.3 .9-3 .6-.7 1.3-1.2 2.7-1.3 .3 0 .6 0 1 0zM14.8 79.4c.8 0 1.6 .3 2.4 .7 1 .5 1.8 1.4 2.1 2 .3 .6 .3 .9-.2 1.5-4 5.2-4.8 12.7-1.4 19.2-5-1.9-7.4-4.7-8.4-7.8-1.4-4.1-.1-9.3 2.4-13.8 .7-1.2 1.5-1.6 2.4-1.8 .2 0 .5-.1 .7 0zm73.6 3.6c.7 0 1.4 .2 2.1 .9 3.9 3.6 7.3 8.1 8.1 13 .6 3.7-.2 7.7-3.7 12.2-.4-3.1-1.4-6-2.8-8.6-2.4-4.6-5.9-8.4-9.3-10.8-.5-.4-.6-.6-.4-1.4 .2-.9 .9-2.1 1.9-3.2 1-1 2.3-1.8 3.4-2 .3-.1 .5-.1 .8-.1z",
    "bleeding-wound": "M6.7 12c2.9 11.2 14 32.5 16.9 60.7-1.6 19.1-5.7 24.7-5.7 38.2 0 6.9 2.8 9.5 5.8 9.5 2.9 0 5.9-3 5.9-10.2 0-14.2-4.2-18.5-5.8-37.9 1.6-20.9 14.9-11.5 14.9 .7 0-28.2 25.5-21.3 29-8.7-1.3 8.8-3.8 11.5-3.8 18.8 0 4.2 2.1 7.2 4.2 7.2 2.1 0 4.1-2.9 4.1-6.8 0-7-2.3-10.3-3.6-19 3.9-9.4 28.9-8.6 29-.4-.9 6.6-3.2 8-3.2 12.8 0 2.4 1.6 4.2 3.2 4.2 1.6 0 3.2-1.7 3.2-4 0-4.6-2.3-6.5-3.1-13.2 3.5-12.3 21.6-5 23-18.3-12.8 11.5-89.3 6.7-114-33.6zm32.2 66.6c-1.2 8-4.4 10.1-4.4 15.4 0 2.7 2.1 4.6 4.4 4.6 2.2 0 4.5-2.1 4.5-4.9 0-5.6-3.4-7.2-4.5-15.2z",
    "bloody-sword": "M8.8 8.9c-1.4 0-2.9 .7-3.6 2.1-1.1 2-.5 4.5 1.5 5.6 1.2 .7 2.6 .7 3.8 .2l17.1 9.8-7.4 13 7.1 4.1c1.6-12.4 7-22.5 17.2-30l-7.1-4.1-7.4 12.9-17.1-9.8c-.1-1.3-.8-2.5-2-3.2-.6-.4-1.3-.5-1.9-.5zm38.3 17.9l-9.5 .2 62.9 36.2-2.3 4-63.4-36.5 5 8.8c1 .5 7.5 3.6 14.9 8.5 7.7 5 16 11.2 18.6 18.7 1.1 .6 7.9 3.9 17.4 6.9 9.5 3.1 21 5.4 30 3.9-3.2-8.9-11.2-17.5-18.6-24-6.9-6-13-9.9-14.8-11-7.7 1.5-17.3-2.7-25.5-6.9-7.9-4.1-13.8-8.2-14.7-8.8zm-6.7 18.2c1.4 4.4 2.6 9.9 3.6 16.1v19.3h4.7v-10.5c3.7-7.1 10.2-.8 12.7 13.4v40.3h4.7V84c3.2-3.3 7 .9 9.7 8.1v8.8h4.7v-6.4c4.3-5.2 11.6-1.4 15 12.3v16.7h4.7v-16.8c4.4-14.5 12.3-21.1 18.6-24.1-9.7 .9-20.4-1.6-29.4-4.5-10.7-3.5-18.9-7.6-18.9-7.6l-.9-.5-.3-1c-1.4-5.1-9.2-12-17-17.1-4.6-3-9-5.4-11.8-6.9zm6 45.4c-2.9 0-5.3 2.4-5.3 5.3 0 2.9 2.4 5.3 5.3 5.3 2.9 0 5.3-2.4 5.3-5.3 0-2.9-2.4-5.3-5.3-5.3zm70.9 1.9s-5.3 13.2-5.3 16.1 2.4 5.3 5.3 5.3c2.9 0 5.3-2.4 5.3-5.3 0-2.9-5.3-16.1-5.3-16.1zM78 106.5c-2.9 0-5.3 2.4-5.3 5.3 0 2.9 2.4 5.3 5.3 5.3 2.9 0 5.3-2.4 5.3-5.3 0-2.9-2.4-5.3-5.3-5.3z",
    "bookshelf": "M42.2 14.2v107.5h19.5V14.2h-19.5zM6.2 26.2v47.5h11.5V26.2H6.2zm39.5 5.8h4.5v80h-4.5V32zm32.2 1.9l-11.3 2 15.5 86.1 11.3-2-15.5-86.1zM22.2 38.2v67.5h15.5V38.2H22.2zm70.4 7.2l-6.9 2.9 1.4 3.2 6.9-2.9-1.4-3.2zm3.1 7.4l-6.9 2.9 1.4 3.2 6.9-2.9-1.4-3.2zm3.1 7.4l-6.9 2.9 24.9 58.4 6.9-2.9-24.9-58.4zM6.2 78.2v7.5h11.5v-7.5H6.2zm47.5 1.8h4.5v32h-4.5V80zM6.2 90.2v31.5h11.5V90.2H6.2zm16 20v11.5h15.5v-11.5H22.2z",
    "bowie-knife": "M15 4.4L3.9 15.5l8 8L23 12.4 15 4.4zM23.3 18.8L18.6 23.5c4.5 8 12.6 16.3 20.2 21l5.4-5.4C39.5 31.3 31.1 23.2 23.3 18.8zM60 29.8L28.2 61.6l3.3 3.3 31.8-31.8L60 29.8zm1.2 12.2l-18.7 18.7 3 3c1.3-1.2 3-1.8 4.6-1.8 1.7 0 3.5 .7 4.8 2 2.6 2.6 2.6 6.7 .1 9.4l33.2 33.2c8.8 8.8 23.4 19.4 35.4 16.7-5.9-5.3-20.4-26.7-17.9-36.5l-10.2 1.8 1.9-10-10.1 1.8 2-9.9-10 1.9 1.9-10-10.1 1.8 1.9-10.2-11.8-11.8z",
    "brain-tentacle": "M52.4 4.7c-1.9 0-3.7 .5-4.8 1.7-.8 .9-1.2 2.1 0 4.8 1.3 2 2.3 4.8 3.2 8.3l-4.5 1.2c-1.5-5.9-3.5-8.2-4.6-8.8-.6-.3-1.2-.3-2.1 0-.9 .3-2.1 .9-3.4 1.9-2 1.4-3.1 3.3-3.1 4.8 .9 3.1 3.3 4.7 6.2 6l-2 4.2c-1.1-.5-2.2-1.1-3.1-1.7-3.3-1.8-5.8-2.6-7-2.5-.7 .1-1 .2-1.5 .7-.5 .5-1.1 1.4-1.6 2.9-.9 2.5-1 4.4-.4 5.5 .5 .8 1.8 1.7 5 2 .8 0 1.7 .1 2.6 .1v0h.3l.1 4.7c-.9 0-1.8 0-2.6-.1-2.8 0-4.4 .2-5 .5-.4 .2-.5 .3-.7 .8-.2 .5-.5 1.3-.6 2.5-.1 1.1-.1 1.9 .2 2.5 .2 .5 .5 .9 1.3 1.3 1.6 .9 5.4 1.4 11.8 .9l.4 4.7c-4.3 .4-7.7 .4-10.4-.1 1.2 3.8 3.6 5.5 6.4 5.5h23.5c2.6 0 5-1.9 5.8-5.5l2-8 2.5 7.9c1.2 3.7 3.5 5.7 5.9 5.7H95.8c2.8 0 5.3-1.7 6.4-5.5-2.7 .5-6.2 .5-10.6 .1l.4-4.7c6.4 .5 10.2-.1 11.8-.9 .8-.4 1.1-.8 1.3-1.3 .3-1.6 .5-4.8-1.1-5.7-.6-.3-2.3-.6-5-.5-.8 .1-1.7 .1-2.6 .1l.1-4.7h.2v0c.9-.1 1.8-.1 2.6-.1 3.2-.3 4.5-1.2 5-2 .6-1 .5-3-.4-5.5-.6-1.6-1.5-3.4-3.1-3.6-4.3 .5-7.3 2.4-10.1 4.2l-2-4.2c1.1-.5 1.9-1.1 2.9-1.6 2.5-1.7 3.2-3.3 3.3-4.4 .1-1.5-1.1-3.4-3.1-4.8-1.3-.9-2.5-1.6-3.4-1.9-.9-.3-1.5-.3-2.1 0-.4 .2-.9 .6-1.4 1.3-1.4 2.3-2.6 5.3-3.2 7.5l-4.5-1.2c1-3.9 2.2-6.9 3.8-9 .8-2.2 .4-3.3-.3-4.1-2.4-1.9-7.1-2.4-9.7-.5-1.1 .8-2 2.1-2.7 3.8-1.4 3.2-1.8 7.7-1.8 11v0l-.1 7.7v0h-4.7v0l-.1-7.7v0c0-3.3-.4-7.8-1.8-11-.7-1.6-1.6-2.9-2.7-3.8-1.1-.7-3-1.2-4.8-1.2zm11.8 54.5c-2 2.7-4.8 4.4-8.2 4.4h-10.7c.5 1.1 1.4 2 2.5 3 3 2.2 8 3.8 13.4 4.1l-.1 .1c-2 2.1-8.3 1.6-12 .2-8.8-3.2-17-5.5-25.3-2.8-10.9 4.3-18.7 16.7-16.4 28.3 2.6 12.8 16.7 31.1 30.3 24.9 15.3-6.9 2.9-28.6-6.3-33 2.1 5.8 9.9 20 2.9 23-8.6 3.6-20.4-10.9-17.4-21.7 5.2-14.3 16.5-12.4 24.8-9.4 15.1 5.4 7.8 42.5 23.8 41.8 9.7-.4 21.4-15.2 12.2-26.6 1 7.2-5.1 18.9-10.7 15.8-8.4-4.5 3-21.1 10.9-26.6 6.1-4.3 17.6-7 22.4-.9 7.5 9.7-13.3 18.6-6.9 29.6 5.6 9.8 18.9 11.8 29.4-2.7-7.3 4.3-17.1 6.5-19.9 .4-3.5-7.8 15.7-8.8 17.3-19 1.4-9.2-4.6-18.5-12.4-23.5-10-6.4-27.3 7.7-40.1 1.9 4.9-.5 9.5-2 12.2-4.2 1.1-.8 1.8-1.8 2.3-2.8h-9.8c-3.2 0-6-1.8-8-4.4z",
    "brain": "M60.3 13.6c-.6 0-1.2 0-1.7 0-.5 0-.9 0-1.4 0-2.2 .4-3.2 1.4-3.8 2.5-.6 1.2-.6 2.9 .1 4.3 .7 1.5 1.9 2.6 3.7 3.1 1.7 .4 4.1 .2 7.3-1.8l2.5 3.9c-4 2.5-7.8 3.2-11 2.4-3.2-.8-5.5-3-6.7-5.6-1.1-2.5-1.4-5.3-.3-7.9-10.7 1.7-20.4 5.8-27.9 11.6-2.5 2.7-2.7 5.8-1.6 7.9 1.2 2.4 4.1 4.1 9.7 2.3l1.4 4.5c-7.1 2.3-13-.1-15.3-4.7-.6-1.1-.9-2.3-1-3.5-1.2 1.4-2.3 2.9-3.2 4.5l0 0c-2.2 4.9-2.2 8.3-1.3 10.5 .9 2.2 2.7 3.6 5.4 4.4 5.5 1.5 14.5-.3 20.8-5 2.7-2 5.3-6.9 5.5-10.7 .1-1.9-.3-3.4-1.1-4.4-.8-1-2.1-1.7-4.7-1.6l0-4.7c3.6 0 6.6 1.2 8.3 3.3 1.8 2.1 2.3 4.9 2.2 7.6-.3 5.4-3.1 11-7.4 14.2-7.5 5.6-17.3 7.9-24.9 5.8-3.5-1-6.6-3.1-8.2-6.4-2.4 11.4 1.1 21.9 7.7 29.2 .9 1 1.8 1.9 2.7 2.7-.7-2-1-4-.9-6 .1-3.6 1.5-7.1 4.3-9.5 2.3-2 5.4-3.1 9.2-3.1 .3 0 .5 0 .8 0 .6 0 1.2 .1 1.8 .2l-.6 4.6c-3.9-.5-6.4 .4-8.1 1.8-1.7 1.5-2.6 3.7-2.7 6.2-.2 5 3 10.9 9.9 12.5l0 0c6.8 1.3 14.4 .1 22-4.6 0 0 0 0 0 0 1.6-1.1 2.4-2.2 2.9-3.1 .5-1.1 .5-2.1 .1-3.1-.7-2.1-3.2-4.2-5.6-4.8-3.8-1-6.1 .4-7.2 1.9-1.1 1.6-1.2 3.1 .5 4.5l-2.9 3.7c-3.5-2.8-3.8-7.6-1.5-10.9 1.7-2.4 4.7-4.1 8.4-4.2 .2 0 .3 0 .5 0 1.1 0 2.2 .2 3.4 .5 3.9 1 7.5 3.8 8.8 7.8 .4 1 .5 2.2 .5 3.3 4.2-2.1 8.6-4 13.1-5.5 7.5-3.4 10.8-9.5 10.7-14.6-.1-5.1-3.3-9.4-10.6-10.2l.5-4.6c9.2 .9 14.6 7.5 14.8 14.7 .1 4.2-1.4 8.6-4.5 12.3 4-.5 8-.4 11.9 .4-.8-1.6-1.2-3.4-1.1-5.1 .2-5.5 4.9-10.6 12.2-10.7 .5 0 1 0 1.5 .1l-.4 4.7c-6.2-.5-8.6 2.8-8.7 6.2-.1 3.4 2.1 7.1 8.6 7.6 7.1 .1 12.1-3.8 14.6-9.5 3.3-7.6 1.7-19.1-8.7-29.5-.2-.2-.4-.4-.6-.6-.1 .9-.4 1.9-.7 2.7-1.8 4.3-6.1 7.3-10.5 8.1-6.1 1.1-11.1-1.3-13.4-5.1-2.3-3.8-1.7-9.1 2.4-11.9l2.6 3.9c-2.2 1.5-2.3 3.5-1.1 5.6 1.2 2 4 3.8 8.5 3 2.8-.5 6-2.8 7-5.3 .5-1.2 .6-2.5 .1-3.9-.4-1.1-1.3-2.4-2.9-3.8l0 0c-6.8-5.1-14.1-8.8-21.4-11.3 0 0 0 0 0 0 1.7 3.1 1.8 6.5 .8 9.6-2.1 6.1-8.5 11-16.5 10.7-1.7-.1-3.4 .8-4.8 2.4-1.4 1.6-2.4 4-2.7 6.6-.5 5.1 1.7 10.7 10.3 13.5L69.2 64.6c-10.3-3.3-14.2-11.4-13.6-18.4 .3-3.5 1.7-6.7 3.8-9.2 2.1-2.5 5.1-4.2 8.5-4 6 .2 10.6-3.5 11.9-7.5 .7-2 .6-4-.4-5.9-1-1.8-3-3.6-6.5-4.9-4.3-.7-8.5-1.1-12.7-1.1zM85.6 76.6c-10.5 .9-21.8 5.8-31.3 11.6-14 8.5-28.7 6.7-39.2-1.1 4.1 14.7 18.7 17.7 33.9 14 1.5-.6 3-1.6 4.3-3 1.8-1.9 3-4.4 3.4-6.4l4.6 .9c-.6 3.1-2.3 6.2-4.6 8.7-2.2 2.4-5.2 4.3-8.5 4.8-1.7 3.8-3.1 7.4-3.6 10-.9 4 3.6 5.6 5.5 1.5 4.8-9.7 11.5-18.3 19.9-25.7 6.5-4.3 12.1-9.6 15.7-15.3z",
    "bread": "M109.8 17.7c-.2 0-.5 0-.8 .1-1.2 .2-2.8 .6-4.7 1.4-3.8 1.6-8.9 4.4-14.5 8-2.7 1.7-5.5 3.6-8.4 5.7 2.6 .4 5.5 1 8.2 1.8 3.3 1 6.4 2.2 8.6 3.7 1.1 .7 2.1 1.4 2.7 2.6 .3 .6 .6 1.4 .5 2.2-.1 .8-.5 1.6-1.1 2.1-2.2 2.2-5.5 2.7-8.9 2.7-3.4 0-7.2-.6-10.6-1.7-3.4-1-6.4-2.4-8.5-4.2-.5-.4-.9-.9-1.3-1.4-3.2 2.5-6.5 5.2-9.8 7.9 3.4 .4 7.5 1.3 11.5 2.3 4 1.1 7.8 2.3 10.6 3.5 1.4 .6 2.5 1.2 3.5 1.9 .5 .4 .9 .8 1.3 1.6 .3 .8 .2 2.2-.4 2.9l0 0 0 0c-2.4 2.7-6.2 3.7-10.4 3.9-4.1 .2-8.7-.3-12.8-1.4-4.2-1.1-7.9-2.6-10.4-4.7-.8-.6-1.4-1.3-2-2.2-2.9 2.6-5.7 5.3-8.5 7.9 1 .1 1.9 .2 3 .4 3.4 .6 7.3 1.9 10.9 3.4 3.6 1.5 6.9 3.2 9.1 5 1.1 .9 2.1 1.8 2.7 3.1 .3 .7 .5 1.5 .3 2.3-.2 .9-.7 1.6-1.3 2.1-2.6 2.2-6.3 2.5-10.1 2.1-3.8-.4-7.9-1.5-11.5-3-3.7-1.5-6.9-3.4-8.9-5.7-.6-.7-1.2-1.4-1.5-2.2-3.1 3.2-5.9 6.4-8.5 9.5 .7 .3 1.6 .7 2.6 1.1 2.6 1.1 5.8 2.4 8.9 3.6 3.1 1.2 6 2.4 8 3.3 1 .4 1.7 .8 2.4 1.1 .2 .1 .3 .2 .5 .3 .2 .2 .5 .2 .8 1.2 .2 .5 .1 1.4-.3 2-.4 .5-.7 .7-1 .8-2.5 2.1-5.8 2.7-9.1 2.5-3.5-.2-7.2-1.2-10.5-2.7-3.2-1.5-6-3.4-7.8-5.8 0 0 0-.1-.1-.1-.3 .4-.6 .9-.9 1.3-3.4 5-5.5 9.6-6.1 13-.6 3.3 0 5.1 2.1 6.6 6.8 2.4 17.1-.9 28.5-8.1 11.5-7.3 23.9-18.5 34.8-30.4 10.9-11.9 20.3-24.6 25.9-34.8 2.8-5.1 4.7-9.7 5.3-13 .3-1.7 .3-3 .1-4-.2-.9-.5-1.4-1-1.8 0 0-.1-.1-.4-.1-.1 0-.3 0-.5 0zM77.3 37.2c-.6 0-1.1 0-1.5 .1-.2 0-.3 .1-.4 .1-.3 .2-.6 .4-.9 .7 .1 .2 .3 .5 .7 .8 1.2 1.1 3.8 2.4 6.8 3.3 3 .9 6.4 1.5 9.3 1.5 2.1 0 3.9-.4 5-.9-.2-.1-.3-.3-.6-.4-1.6-1-4.4-2.2-7.5-3.1-3.1-.9-6.4-1.6-9.1-1.9-.7-.1-1.3-.1-1.9-.1zm-19.8 15.8c-.3 0-.5 0-.7 0-.4 0-.6 .1-.8 .2l-.3 .3c-.1 .2-.1 .3-.1 .5 .1 .2 .4 .8 1.2 1.5 1.6 1.4 4.9 2.8 8.7 3.8 3.7 1 7.9 1.4 11.4 1.2 2.3-.1 4.2-.6 5.6-1.3-.3-.2-.6-.3-1-.5-2.4-1.1-6.1-2.3-9.9-3.3-3.8-1-7.8-1.8-10.9-2.2-.8-.1-1.5-.1-2.1-.2-.3 0-.6 0-.9 0zm-15.2 16.2c-.1 0-.3 0-.4 0-1 0-1.5 .3-1.5 .3-.5 .4-.4 .4-.4 .6 0 .1 .2 .7 .8 1.4 1.3 1.4 4.1 3.2 7.4 4.5 3.3 1.4 7 2.4 10.2 2.7 2.7 .3 4.9-.1 6.2-.8-.2-.3-.5-.6-1-.9-1.7-1.3-4.7-3-8.1-4.4-3.3-1.4-7-2.5-10-3.1-1.3-.2-2.5-.3-3.4-.3zm-17.2 16.4c.1 .3 .2 .6 .5 1.1 1 1.4 3.3 3.1 6 4.4 2.8 1.3 6 2.2 8.8 2.3 1.1 .1 2 0 2.8-.2-1.8-.8-3.6-1.5-6-2.5-3.1-1.2-6.3-2.5-8.9-3.7-1.3-.5-2.4-1-3.3-1.4zm23.2 5.4c0 0 0 0 0 0l.2 0c0 0 0 0-.1 0z",
    "broadsword": "M123 5.6l-20.9 3.7L49.1 62.3c.8 1.2 1.3 2.7 1.3 4.2 0 1.5-.4 2.8-1.2 4-1.3-.4-2.6-.6-4-.6-3.9 0-7.5 1.7-9.9 4.4l-2.3-2.3 4.3-4.3c-1.1-1.4-2.2-2.9-3.3-4.4l-4.9 4.9-3.3-3.3 5.5-5.5c-1.1-1.6-2.2-3.3-3.2-5l-10.2 10.2 14.6 14.6c-.4 1.3-.6 2.6-.6 4 0 1.9 .4 3.7 1.1 5.4l-18 18-3.6-3.6L5.3 109.2l3.6 3.6-2.2 2.2 6.8 6.8 2.2-2.2 3.6 3.6 6.2-6.2-3.6-3.6 18-18c1.6 .7 3.5 1.1 5.4 1.1 1.4 0 2.7-.2 4-.6l14.6 14.6L74.1 100.4c-1.7-1-3.4-2.1-5-3.2l-5.5 5.5L60.3 99.3l4.9-4.9c-1.5-1.1-3-2.2-4.4-3.3l-4.3 4.3-2.3-2.3c2.7-2.4 4.4-6 4.4-9.9 0-1.3-.2-2.6-.6-3.8 1.2-.8 2.6-1.2 4.1-1.2 1.6 0 2.9 .4 4.1 1.2L119.2 26.5l3.7-20.9zm-16.6 13.3l3.3 3.3-47.9 47.9-3.3-3.3L106.4 18.9zM45.3 74.6c4.8 0 8.7 3.9 8.7 8.7 0 4.8-3.9 8.7-8.7 8.7-4.8 0-8.7-3.9-8.7-8.7s3.9-8.7 8.7-8.7z",
    "broken-heart": "M93.4 6.4c-8.4 0-16.9 3.4-23.6 10.8l9.3 36.3-8.4 0 8.8 33-29.2-47.1 12.5 1.3L50.6 11.8C30.1-.4 1.2 10.1 2.1 39.5c1.1 34.6 47.8 46.1 61.9 82.9 14.8-36.8 62.8-46.1 61.7-82.9-.6-20.5-16.1-33.1-32.3-33.2z",
    "bubbling-flask": "M46.6 5.3c.3 1.9 .7 3.7 1.1 5.4h-6.2l2.6 3.7s3.4 4.8 5.4 11c1 3.1 1.6 6.4 1.4 9.5-.2 3.1-1.3 5.9-3.8 8.4-5.1 5.1-12 10.1-17.7 16.1-5.8 6-10.5 13.4-10.5 22.9 0 .5 0 9.9 0 19.2 0 4.7 0 9.3 0 12.9 0 1.8 0 3.3 0 4.4 0 1.1 0 1.9 0 1.8l-.1 2.4 2.4 0 78.1 .6 2.4 0-.1-2.4c0 .1 0-.8 0-1.9 0-1.1 0-2.6 0-4.4 0-3.6 0-8.3 0-13 0-9.4 0-18.9 0-19.5 0-9.7-4.9-17.2-10.9-23.3-6-6.1-13.2-11-18.4-16.1-2.5-2.4-3.5-5.1-3.6-8.1-.1-3 .6-6.3 1.8-9.4 2.3-5.9 5.8-10.5 6-10.8l3.9-3.9h-8.1c.4-1.7 .8-3.5 1.1-5.4H46.6zM54.2 24.9c3.6 3.9 7.8 3.9 11.4 0-1.1 3.1-1.8 6.6-1.7 10.1 .2 4 1.6 8 5 11.3v0c5.7 5.5 12.8 10.4 18.4 16 5.6 5.6 9.5 11.8 9.5 20 0 .6 0 10.1 0 19.5 0 4.7 0 9.4 0 13 0 1.6 0 3 0 4.1l-73.4-.5c0-1.1 0-2.3 0-4 0-3.6 0-8.2 0-12.9 0-9.3 0-18.7 0-19.2 0-8 3.8-14.1 9.2-19.7 5.4-5.6 12.2-10.5 17.7-16 3.3-3.3 4.8-7.4 5.1-11.4 .3-3.6-.3-7.1-1.3-10.3zm8.6 24.7c-4.3 0-7.9 3.6-7.9 7.9 0 4.3 3.6 7.9 7.9 7.9 4.3 0 7.9-3.6 7.9-7.9 0-4.3-3.6-7.9-7.9-7.9zm0 4.7c1.8 0 3.2 1.4 3.2 3.2 0 1.8-1.4 3.2-3.2 3.2-1.8 0-3.2-1.4-3.2-3.2 0-1.8 1.4-3.2 3.2-3.2zM32.9 69.4c-2.7 3.7-4.5 7.9-4.5 13 0 1.3 0 29.9-.1 31.2l64 1c-.1-1.6-.1-30.5-.1-32.1 0-5.1-1.9-9.3-4.5-13h-9.2c.8 1.4 1.3 3 1.3 4.7 0 5.2-4.3 9.5-9.5 9.5-5.2 0-9.5-4.3-9.5-9.5 0-1.7 .5-3.3 1.3-4.7H32.9zm36 0c-2.1 .5-3.7 2.4-3.7 4.7 0 2.7 2.1 4.9 4.9 4.9 2.7 0 4.9-2.2 4.9-4.9 0-2.3-1.5-4.2-3.7-4.7H68.9zM52.8 79.9c4.7 0 8.6 3.9 8.6 8.6 0 4.7-3.9 8.6-8.6 8.6s-8.6-3.9-8.6-8.6c0-4.7 3.9-8.6 8.6-8.6zm0 4.7c-2.2 0-3.9 1.7-3.9 3.9s1.7 3.9 3.9 3.9 3.9-1.7 3.9-3.9-1.7-3.9-3.9-3.9zm23.2 2.5c6.4 0 11.6 5.2 11.6 11.6 0 6.4-5.2 11.6-11.6 11.6-6.4 0-11.6-5.2-11.6-11.6 0-6.4 5.2-11.6 11.6-11.6zM76.1 91.8c-3.9 0-6.9 3.1-6.9 6.9s3.1 6.9 6.9 6.9 6.9-3.1 6.9-6.9c0-3.9-3.1-6.9-6.9-6.9z",
    "burning-book": "M66 4.6c-12.6 3.2-20.2 16.6-12.7 27.8 5.6 8.4 11.2 15.3 2.2 19.8-5.8 2.9-12.5-4.1-11.5-12.3 1.2-10.1-4.7-20-11.5-22 11.6 26.6-10.9 44.2-6.1 19.3-7.6 4-8.2 14.8-2.8 30.7-10.1-4.3-13.8-16.7-9.6-30.1-9 7.1-13.3 32.7-3.7 45.9C34.1 116 62 124.1 67 124.1c5.3 0 29.3-8.4 47.4-28.8 10.4-11.8 12.7-42.2 2.3-60.9 1.5 6.3-1.5 19.2-8.5 23.5 1.2-14.4-1-35.2-9.2-42.9 8.2 43.2-23.3 38.1-12.1 24.9 7.4-8.7 0-25.6-4.4-28.1 2.7 10.5-3.6 17.4-13.7 15.4-6.8-1.4-11.2-11.2-3-22.5zm-28.8 52.9h4.7V98.8l25.7 14L93.2 98.8V57.5h4.7v44.1l-1.2 .7L68.6 117.5l-1.1 .6-1.1-.6L38.4 102.3l-1.2-.7V57.5zm9.4 .1l18.4 11.1v37.1l-18.4-10.4V57.6zm41.9 0v37.9l-18.9 10.6V69l18.9-11.4z",
    "burning-passion": "M5 4.7v.7c16.1 12.7 23.8 29 22.4 44.8-2.7-13.8-10.4-26.2-22.4-34.7v5.9c13.8 11.3 20.6 28.6 18.2 46.3-.1 .6-.2 1.2-.3 1.8 0 .1 0 .3-.1 .4h0c-1.6 13.4 2.8 27.1 12.4 39 1.6 2.8 3.5 5.5 5.7 8C23.8 101.7 14.8 83.9 13.3 65.6c-2.8 20.8 3.8 40.8 22.7 57.6H47.1c0 0 0 0 0 0h32.6c0 0 0 0 0 0h10.9c18.9-16.8 25.4-36.8 22.7-57.6-1.4 17.9-10.2 35.4-26.7 50.4 2.4-2.9 4.4-6 6.1-9.2 8.5-11.4 12.4-24.3 10.9-37 0 0 0 0 0 0-.1-.8-.2-1.7-.4-2.5-2.3-18.6 5.3-36.6 20.6-47.7V13.9c-13.2 8.5-21.8 21.6-24.6 36.2-1.5-16.1 6.5-32.5 23-45.3l-.1-.1h-7c-18 16.1-25 37.4-18.1 57 .7 2.1 1.3 4.2 1.7 6.3 0 0 0 0 0 0 .1 .9 .2 1.7 .4 2.6h0c.6 4.8 .3 9.7-.9 14.5 0-7.1-1.7-14.3-5.1-21.3-10-20.5-5.2-42.9 13.1-59.2h-7.8c-12.5 11.7-16.6 22.9-14.4 37.8-5.4-14.8-4.9-25.9 5.2-37.8H38c10 11.9 10.5 23 5.2 37.8 2.2-14.9-1.8-26.1-14.4-37.8H20.8c18.3 16.3 23.1 38.7 13.1 59.2-3.7 7.6-5.4 15.5-5.1 23.2-1.5-5.4-2-11-1.4-16.5 .1-.9 .3-1.7 .4-2.6 .4-2.1 .9-4.2 1.7-6.3 6.8-19.6-.1-40.9-18.1-57H5zm58.6 4.9c4.1 0 6.8 1.5 8.7 4.1 1.9 2.6 3 6.4 3 10.8 0 4.7-1.7 9.6-4 12.4l-2.5 3.1 3.9 .7c3.1 .6 5.4 2.2 7.4 4.8 1.9 2.6 3.4 6.1 4.4 10.2 1.9 7.5 2.3 16.6 2.3 24.8h-5.8l-.2-17.6-4.7 .1 .2 21.6-1.9 27.9c11.8-10.9 18-23.6 19-36.6 2.1 15.3-2.8 30.2-16.8 42.5H73.9v.1h-8.2V83.5h-4.7v34.9H53.2v-.1h-2.4c-14-12.4-18.8-27.2-16.8-42.5 1 12.9 7.2 25.4 18.7 36.3L50.9 86.4l.6-23.5-4.7-.1-.5 17.7h-6.1c.1-8.2 .5-17.4 2.4-24.8 1-4.1 2.5-7.6 4.4-10.2 1.9-2.6 4.2-4.2 7.4-4.8l3.9-.7-2.5-3.1c-2.3-2.7-4-7.7-4-12.4 0-4.3 1.1-8.1 3-10.8 1.9-2.6 4.6-4.1 8.7-4.1z",
    "campfire": "M70.4 5.9c12.1 17.9-4.6 36.4-15.9 14.7 6.8 36.1-16.3 41.6-18.7 18.7-18.4 16.3-14.8 36.8-5.1 52.7l11.5-6.6c-3-4.6-4.5-10.6-3.8-16.6 6.4 9.9 26.7 2.5 24.3-15 2.7 8 9.5 7.2 16.4-5.1C69.5 74.4 84.5 91.1 94.5 83.4c.4 3-.7 6.4-2.6 9.5l11.7 3.1c13.8-11.9 19.9-34-1-43.9 9.8 15.1-3.3 26.3-15.2 10.4-9.6-18 20.6-28.3-17.1-56.6zM43.5 12c-16 8.1-3.7 15.1-3.5 23.1 11-9.7-.9-13.4 3.5-23.1zm18.6 67.3L18.8 104.2c.7 4.6 2.2 8.6 4.7 12.1l23-11-19.7 15c.8 .8 1.8 1.7 2.7 2.4L48.2 112c0-.2 0-.4 0-.6 0-9.3 7.6-16.9 17-16.9 2.6 0 5.1 .6 7.4 1.7-.6-3.4-1.8-6.8-3.7-9.8l-23.7 10 20.6-14.1c-1.1-1.1-2.3-2.2-3.6-3zm14.7 14.4c.4 1.8 .7 3.6 .7 5.3l.1 1c2.8 3 4.5 7 4.5 11.4 0 1.9-.3 3.8-1 5.6l22.8 6.1c1.2-1.6 2.1-3.2 3-4.8l-15.8-6.2 17.5 1.7c.2-.7 .4-1.5 .6-2.2l-24.3-8.6L109.8 106.9c0-1.4 0-2.9-.2-4.4L76.8 93.7zm-11.7 5.5c-6.8 0-12.3 5.5-12.3 12.2 0 6.8 5.5 12.2 12.3 12.2 6.8 0 12.3-5.4 12.3-12.2 0-6.8-5.5-12.2-12.3-12.2zm-1.2 2.9c10.9 0 14.6 17.9 0 17.9 6.7-5.8 7.5-11.7 0-17.9zm0 2.5c-5.4 4.5-4.8 8.8 0 13-10.6 0-7.9-13 0-13z",
    "candle-light": "M64.7 5.9c-7 0-23.5 21.8-23.5 39.6 0 14.8 7.3 19.9 17.2 23.7-3.9-3.9-6.5-10.9-6.5-19 0-12.3 7.8-22.3 13.3-22.3 5.3 0 13.3 10 13.3 22.3 0 7.6-2.4 14.2-5.8 18.2 9-4.5 15.5-8.9 15.5-22.9 0-17.8-16.7-39.6-23.5-39.6zm1.7 44l-4.6 .7c1.4 9.8 1.7 17.3 1.1 24.5-6.2-.2-12.4-1.5-18.4-3.7v23.9c-.8 6.4-5.6 7.6-5.5 13.4 .1 4.9 3.7 6.5 5.5 4.4v9.1h41.2v-22.1c2.2 2.7 6.8 .8 6.9-5.3 .1-7.3-6.1-8.7-6.9-17.2V71.3c-6 2.2-12 3.4-18.1 3.7 .6-7.4 .3-15.2-1.1-25.1z",
    "candlebright": "M45.6 5.1c6.1 46.5-23.6 70.3-17.4 93.2 .9 3.4 2.6 6.5 4.7 9.3-.6-1.8-1-3.7-1.1-5.6-.3-12.3 12.6-23.1 21.8-40.3 2.9 7.8 5.9 17.2 4.2 29.1 15.7-4.6 27.7-16.6 30.3-29.4 9.3 16.6 10.4 35.4 .2 49.2 0-.8-.2-1.5-.4-2.3-1.7-5.9-9.9-9.1-18.2-7-15.3 3.9-17.4 24.7 4.2 21.3 .1 0 .2 0 .3-.1 6.1-.9 11.8-3.2 16.2-7C127.7 83.8 97 25.9 45.6 5.1z",
    "candles": "M86.5 30.2c1.3 6.6-5.6 7-6.6 12.4-.2 1.1 .7 2.4 2 3.5 2.8-1.6 5.4-3.2 6.9-6.4 0 3.3 .2 5.1-.7 7.8 1.3-.5 2.5-1.5 3-2.8 1.8-4.7 .4-8.4-4.6-14.5zm-40.9 .5c-5.3 3.3-8.5 9.6-6.6 14.7 .4 1.1 1.4 1.9 2.6 2.4 2.1-3 2.7-7 3.3-11 1 3.6 2.3 7.2 1.9 11.3 1.7-.6 3.3-1.9 3.8-3.5 1.4-4.7-4.9-7.1-5.1-13.9zM24.2 34c-5 6.1-8.8 11.4-6.8 17.2 .5 1.5 2 2.7 3.6 3.4 0-2.3 1.1-4.3 2-6.4 .6 2.4 2.4 4.4 4.6 6.1 1.1-.7 1.9-1.7 2.3-2.8 1.7-5.1-7-10.9-5.7-17.5zm41.8 2.1c-5 6.1-8 11.2-6.8 17.2 .4 1.9 1.8 3.9 3.5 4.8-.3-4 .9-7.5 1.9-11 .6 3.8 1.2 7.7 3.1 10.7 1.9-1.1 3.5-2.9 3.9-4.2 1.7-5.1-4-10.7-5.7-17.5zm42.3 .6c-5 6.1-8.8 10.1-7.7 15.9 .3 1.7 1.8 3.3 3.5 3.9-.4-3.5 .9-6.5 1.9-9.6 .6 3.2 1.2 6.4 3 8.9 1.2-.7 2.2-1.7 2.5-2.7 1.7-5.1-4.5-9.8-3.2-16.4zm-63.4 13.5c-1.7 0-3.6 .2-5.5 .9v58.8h12V51c-2.1-.5-4.2-.9-6.5-.9zm39.9 .9c-1.8 0-3.5 .4-5.4 1.6l0 0s-2.6 5.1-2.1 7.8c.2 1.6 1.5 1.5 2.1 .8v48.5h13.1v-57.1c-2.5-.8-5.1-1.6-7.7-1.6zM24.4 57.4c-2.8 0-5.5 .7-8.2 1.6v4c-1.5 2.3-4.1 6.9-3.5 9.8 .4 1.8 2.1 2.1 3.5 1.6v35.4h15.2V102.2c1.3 .3 3 .1 3.4-1.2 .6-2.1-1.9-5.4-3.4-7.2V59c-2.4-1.1-4.7-1.6-7-1.6zm82.2 1.5c-1.7 0-3.9 .7-6.7 2.7v48.1h12v-3.9c.9 0 2.3-2 2.7-5 .8-5.4-2.4-11.6-2.7-12.2V61.7c-1.4-1.5-3-2.7-5.3-2.7zm-40.9 1.5c-1.7 0-3.6 .4-5.6 1.3v30.8c-1.2 2.2-2.2 4.9-1.7 6.8 .2 1.1 .9 1.6 1.7 1.8v8.7h10.4V61.7c-1.5-.9-3.1-1.3-4.9-1.3zM4.2 114.2l5 7.5h109.6l5-7.5H4.2z",
    "carnival-mask": "M102.8 31.1c.8 3.3 .8 6.4 .3 9.5-4.9 3.9-10.1 7.2-14.9 9.5l-.3-.1c6.1-4.8 11.4-10.5 14.9-18.9zm-77.7 0c3.5 8.3 8.9 14.1 14.9 18.9-.1 0-.2 .1-.3 .1-4.8-2.3-10-5.6-14.9-9.5-.5-3-.5-6.2 .3-9.5zm91.8 2.8c-.5 3.1-1.3 6.4-2.2 9.7C108.9 49.5 102.4 52 96 52c-.4 0-.9 0-1.5-.1 8-4.4 16.1-10.9 22.4-18zm-105.8 0c6.2 7.1 14.4 13.5 22.4 18-.5 .1-1 .1-1.5 .1-6.4 0-12.9-2.4-18.7-8.4-.9-3.3-1.6-6.7-2.2-9.7zm113.3 4.5c-1.8 8.9-5.3 18.5-10.8 26.6C105.4 76.9 93.2 93.5 76 92c-4 0-8-16-12-16s-8 16-12 16c-17.2 1.5-29.4-15.1-37.6-27.1-5.5-8.1-9-17.7-10.8-26.6C11.5 50.9 21.7 56.5 32 56.5c5.5 0 9.9-3.2 15.4-4.6 2.8-.7 5.4-1 7.5-.5 2 .4 5.2 1.4 9.1 3.6 3.9-2.2 7.1-3.2 9.1-3.6 2.2-.5 4.7-.2 7.5 .5 5.5 1.4 9.9 4.6 15.4 4.6 10.3 0 20.5-5.6 28.4-18.1zm-36.8 23.9c-7.1 0-15.7 1.3-15.6 3.1 1.5 17.5 24.5 4 24.5-.9 0-1.5-4.1-2.2-8.9-2.2zm-47.2 0c-4.8 0-8.9 .7-8.9 2.2 0 4.9 23 18.4 24.5 .9 .2-1.8-8.5-3.1-15.6-3.1zm62.8 26.9a64.2 64.2 0 0 0 3.7 1.7c4 1.7 8.8 3.2 14 4.2-1.3 .4-2.7 .8-4.3 1.1-5 .9-11.2 1.2-17.3 .5-3.1-.3-6.2-.9-9.1-1.7 4.7-1.2 9-3.2 12.9-5.7zm-78.5 0c3.9 2.6 8.2 4.5 12.9 5.7-2.9 .8-6 1.4-9.1 1.7-6.1 .6-12.3 .4-17.3-.5-1.6-.3-3-.7-4.3-1.1 5.2-1 10-2.5 14-4.2a64.2 64.2 0 0 0 3.7-1.7z",
    "cauldron": "M64.8 6.3c-14 0-26.7 2.4-36.1 6.5-4.7 2-8.6 4.5-11.4 7.4-2.8 2.9-4.6 6.3-4.6 10 0 2.5 .8 4.8 2.2 7-2.6 5.5-4 11.4-4 17.7 0 25.8 23.9 47 53.9 47 29.9 0 53.9-21.2 53.9-47 0-6.2-1.4-12.2-4-17.7 1.4-2.2 2.2-4.5 2.2-7 0-3.7-1.8-7.2-4.6-10-2.8-2.9-6.7-5.3-11.4-7.4-9.4-4.1-22.1-6.5-36.1-6.5zm0 4.7c13.5 0 25.6 2.4 34.2 6.1 4.3 1.9 7.7 4.1 9.9 6.4 2.2 2.3 3.2 4.5 3.2 6.8 0 2.3-1 4.5-3.2 6.8-2.2 2.3-5.6 4.5-9.9 6.4-8.6 3.7-20.8 6.1-34.2 6.1-13.5 0-25.6-2.4-34.2-6.1-4.3-1.9-7.7-4.1-9.9-6.4-2.2-2.3-3.2-4.5-3.2-6.8 0-2.3 1-4.5 3.2-6.8 2.2-2.3 5.6-4.5 9.9-6.4 8.6-3.7 20.8-6.1 34.2-6.1zm-1.9 4.3c-20.1 0-36.5 6.5-36.5 14.5 0 8 16.4 14.5 36.5 14.5 10 0 19.1-1.7 25.7-4.2-5.3 .8-11.3 1.5-17.7 1.5-21.5 0-39-5.4-39-12s17.5-11.8 39-11.8c5.1 0 10 .2 14.5 .7-6.2-1.9-14-3.1-22.5-3.1zM21.9 90.1c-2.5 5-3.7 9.2-3.9 12.3-.3 3.7 .7 5.6 1.7 6.2 1 .6 2.9 .6 5.8-1.4 2.3-1.6 5-4.4 7.8-8.6-4.2-2.4-8-5.2-11.4-8.4zm85.7 0c-3.4 3.2-7.2 6-11.4 8.4 2.8 4.2 5.5 7 7.8 8.6 3 2.1 4.9 2 5.8 1.4 1-.6 2-2.4 1.7-6.2-.3-3.1-1.5-7.3-3.9-12.2zm-49.8 16.1c.3 5.3 1.3 9.4 2.6 12.1 1.6 3.4 3.3 4.5 4.4 4.5 1.1 0 2.8-.9 4.3-4.2 1.3-2.7 2.3-6.9 2.6-12.4-2.3 .2-4.6 .4-7 .4-2.4 0-4.7-.1-7-.4z",
    "chain-mail": "M43.7 15.3L36 19.7 10.9 34.2l-2.5 1.5-2.7 1.5-1.4 .8 16.4 28.3 .5-.3 1.2-.7 2.3-1.3V64l14-8.1-2.2 49 0 .8-.3 6h55.5l0-.7-.1-1.8-.2-4.3-2.1-48.9 13.8 8 0 0 3.3 1.9 .2 .1 .5 .3L123.5 38l-1.4-.8-2.7-1.5-23.6-13.6-4.1-2.4-5.6-3.2-2-1.2c-2.9 5.9-10.9 10.1-20.3 10.1-9.4 0-17.3-4.3-20.1-10.1l0 0zm-4.3 7.9c9.6 8.9 22.8 11.6 34.3 8.6l-1.9 3.6 3.3 6.1 3.3-6.1-2.3-4.3c4.7-1.6 9.1-4.2 12.7-7.8l28.4 16.4-11.7 20.2L98 55.7l3-5.6-3.3-6.1-3.3 6.1L97.3 55.2l-4.8-2.8-8.4-5 .1 2.1-3.2-6-3.3 6.1L81 55.8l3.2-6 .4 6.2h0l.5 12.4-2.7-4.9-3.3 6.1L81.7 74h-15.1l2.2-4.2-3.3-6.1-3.3 6.1 2.2 4.2h-22l.9-19.3h0l.3-7.2-8.4 5-12.9 7.5-11.7-20.2 28.7-16.5zm1.1 4.2l-3.3 6.1 3.3 6.1 3.3-6.1-3.3-6.1zm67.5 9.9l-3.3 6.1 3.3 6.1 3.3-6.1-3.3-6.1zM32.2 41.7l-3.3 6.1 3.3 6.1 3.3-6.1-3.3-6.1zm28.5 9.5l-3.3 6.1 3.3 6.1 3.3-6.1-3.3-6.1zm14 5l-3.3 6.1 3.3 6.1 3.3-6.1-3.3-6.1zm-24.9 2.3l-3.3 6.1 3.3 6.1 3.3-6.1-3.3-6.1zm35.6 11.9l.2 3.6h-2.1l2-3.6zM42.4 78.2h43.2l.2 5H42.1l.2-5zm-.4 9.2H51.8l-2.7 5 3.3 6.1 3.3-6.1-2.7-5h30.1l-2.9 5.3 3.3 6.1L86.2 93.7l.5 11.2h-13.4l2-3.7-3.3-6.1-3.3 6.1 2 3.7H41.2l.8-17.4zm41.9 0h2.1l.2 4.3-2.3-4.3z",
    "chalice-drops": "M51.6 4.9c-1.1 10.6-7.1 18.6-7.1 23.9 0 2.6 3.9 5.9 7.6 5.9 1 0 2-.2 2.9-.7-.5 1.3-1 2.5-1.3 3.7-3.7 .5-7.1 1.2-9.9 2.2-2.7 .9-5 2-6.8 3.3-1.8 1.4-3.1 3.2-3.1 5.5 0 .3 0 .6 .1 .9h0c0 17.8 11 32.6 25.5 35.5-2.1 10.5-7.3 20-14.6 27.5-2 1.1-3.2 2.4-3.2 3.8 0 4.2 10.3 7.6 22.9 7.6s22.9-3.4 22.9-7.6c0-1.4-1.2-2.7-3.3-3.9-7.3-7.6-12.4-17-14.4-27.5C84.1 82 95.1 67.2 95.1 49.5h0c0-.3 .1-.6 .1-.9 0-2.2-1.4-4.1-3.1-5.5-1.8-1.4-4-2.4-6.8-3.3-4-1.3-9-2.2-14.5-2.6-1.9-6.8-6.9-15.6-8.7-26.1-.6 5.3-2.1 10-3.7 14.3-1.4-5.3-5.4-12.3-6.8-20.5zm27.7 2.4c-1 9.6-6.4 16.7-6.4 21.5 0 2.4 3.5 5.3 6.8 5.3 3.2 0 6.2-2.9 6.2-5.4 0-5-5-12.3-6.6-21.4zm-7.9 34.7c4.8 .4 9.1 1.2 12.3 2.3 2.4 .8 4.3 1.7 5.4 2.6 1.1 .9 1.3 1.5 1.3 1.8 0 .3-.2 .9-1.3 1.8-1.1 .9-3 1.8-5.4 2.6-4.8 1.6-11.7 2.6-19.3 2.6-7.6 0-14.5-1-19.3-2.6-2.4-.8-4.3-1.7-5.4-2.6-1.1-.9-1.3-1.5-1.3-1.8 0-.3 .2-.9 1.3-1.8 1.1-.9 3-1.8 5.4-2.6 2.2-.7 4.8-1.3 7.8-1.8 .5 3.3 5.3 7 9.7 7 4.5 0 8.7-4 8.8-7.6z",
    "cloak-dagger": "M63.5 4.9c-14.1 7.2-26.6 26.8-30.7 42.2 8.1 .5 14.7 3.2 19.7 7.7l2.3-2.5c-3.3-3.3-7.6-6-13.2-8.7 3.2-7.9 8-19.8 14.1-20.5 2.4-.3 5 1.2 7.8 5.3 8.8-14.6 17.1 4.7 21.9 15.3-5.5 3-9.8 5.7-13.2 9l2.2 2.4c4.9-4.4 11.4-7.3 19.6-7.9C89.6 31.8 77.9 12.5 63.5 4.9zM54.9 36.1c-2.2 0-4 1-4 2.2 0 1.2 1.8 2.2 4 2.2 2.2 0 4-1 4-2.2 0-1.2-1.8-2.2-4-2.2zm17.2 0c-2.2 0-4 1-4 2.2 0 1.2 1.8 2.2 4 2.2 2.2 0 4-1 4-2.2 0-1.2-1.8-2.2-4-2.2zm-29.7 17.7c-.5 .9-1.1 1.9-1.6 2.9-6.4 12.2-10.8 30.9-11 55.9 8.2 4.7 16.1 7.8 23.9 9.2-8.9-6.1-15.1-20.2-15.1-36.7 0-11.5 3-21.8 7.9-29.1-1.3-.8-2.6-1.6-4.1-2.2zm42.2 .1c-1.5 .6-2.8 1.4-4.1 2.2 4.8 7.3 7.8 17.6 7.8 29 0 16.5-6.2 30.6-15.1 36.7 7.7-1.4 15.6-4.5 23.9-9.2-.2-24.9-4.6-43.5-11-55.8-.5-1-1.1-2-1.6-2.9zm-24.4 5.9c1.8 5.6 2.3 11.3 .2 16.9h-10.4v4.6c2.5-.8 5.1-1.3 7.6-1.6 0 12.6 .3 24.1 5 36.4l1 2.8 1.1-2.7c4.9-11.9 4.5-23.8 4.5-36.3 2.6 .3 5.1 .8 7.6 1.5v-4.6h-10.3c-1.7-5.6-1.5-11.3 .2-16.9h-6.6z",
    "coffin": "M78 5.5l14.8 29.9h13L90.6 5.5l-12.6 0zM43.2 5.7l-15.9 31.8 16.5 86.4 28.7 0L88.6 37.5 72.9 5.7 43.2 5.7zm4 19.1h22.2v4.7h-22.2V24.7zm0 9.1h22.2v4.7h-22.2v-4.7zm45.6 6.3L77.2 123.9l11.8 0 17.1-83.8h-13.2z",
    "coins": "M34 6.3c-4.1 0-7.8 .8-10.3 2.1-2.5 1.2-3.4 2.6-3.4 3.6 0 1 .9 2.4 3.4 3.6 2.5 1.2 6.2 2.1 10.3 2.1s7.8-.9 10.3-2.1c2.5-1.2 3.5-2.6 3.5-3.6 0-1-.9-2.4-3.5-3.6-2.5-1.2-6.2-2.1-10.3-2.1zm40 8c-4.1 0-7.8 .8-10.3 2.1-2.5 1.2-3.5 2.6-3.5 3.6 0 1 .9 2.4 3.5 3.6 2.5 1.2 6.2 2.1 10.3 2.1 1.1 0 2.2-.1 3.3-.2 1.1-1.4 2.6-2.6 4.4-3.4 2-.9 4.4-1.7 6.1-2.1 0-1-.9-2.4-3.5-3.6-2.5-1.2-6.2-2.1-10.3-2.1zM20.3 18.9c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.2-.9 6.3-2.7 6.4-5.9-4 2.7-9.9 3.4-13.8 3.4-4.9-.4-10-.9-13.7-3.4zM94 24.1c-4.1 0-7.8 .8-10.3 2.1-2.5 1.2-3.5 2.6-3.5 3.6 0 1 .9 2.4 3.5 3.6 2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.2 3.5-2.6 3.5-3.6 0-1-.9-2.4-3.5-3.6-2.5-1.3-6.2-2.1-10.3-2.1zM60.2 26.9v.6c.7 .2 1.4 .6 2.1 .9 2.2 1.1 4.2 2.7 5.2 4.7 2.5 .6 5.4 .8 8.2 .7v-3.5c-.6 0-1.1 .1-1.8 .1-4.7 0-9-.9-12.3-2.6-.5-.2-1-.5-1.4-.8zm-40 0c-.1 3.6 3.9 5.2 6.4 5.9 1.7 .5 3.6 .8 5.5 .9 .5-1.3 1.4-2.5 2.5-3.4-3.2 .1-6.4-.3-9.3-1.1-1.9-.6-3.7-1.3-5.1-2.2zM50 30.2c-4.1 0-7.8 .9-10.3 2.1-2.5 1.2-3.5 2.6-3.5 3.6s.9 2.4 3.5 3.6c2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.2 3.5-2.6 3.5-3.6s-.9-2.4-3.5-3.6c-2.5-1.2-6.2-2.1-10.3-2.1zM20.3 34.9c-.1 3.6 3.9 5.2 6.4 5.9 1.6 .5 3.3 .8 5.1 .9v-3.5c-2.2-.1-4.3-.5-6.4-1.1-1.9-.6-3.7-1.3-5.1-2.2zM80.2 36.7c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.2-.9 6.3-2.7 6.4-5.9-.5 .3-.9 .6-1.4 .8-3.3 1.6-7.6 2.6-12.3 2.6s-9-.9-12.3-2.6c-.5-.2-1-.5-1.4-.8zm-12 1.1v3.4c2.4 .5 5 .7 7.5 .5v-3.5c-2.5 .1-5.1 0-7.5-.5zm-32 5.1c-.1 1.5 .6 2.7 1.4 3.5 1.1 .9 2.8 1.8 5 2.5 4.5 1.3 10.3 1.3 14.8 0 2.2-.7 4-1.6 5-2.5 1.2-1 1.4-2 1.4-3.5-.5 .3-.9 .6-1.4 .8-3.3 1.6-7.6 2.6-12.3 2.6s-9-.9-12.3-2.6c-.5-.2-1-.5-1.4-.8zm-16 0c-.1 3.6 3.9 5.2 6.4 5.9 1.6 .5 3.3 .8 5.1 .9v-3.5c-2.2-.1-4.3-.5-6.4-1.1-1.9-.6-3.7-1.3-5.1-2.2zM80.2 44.7c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.2-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm-12 1.1v3.4c2.4 .5 5 .7 7.5 .5v-3.5c-2.5 .1-5.1 0-7.5-.5zM20.3 50.9c-.1 3.6 3.9 5.2 6.4 5.9 1.6 .5 3.3 .8 5.1 .9v-3.5c-2.2-.1-4.3-.5-6.4-1.1-1.9-.6-3.7-1.3-5.1-2.2zm16 0c-.1 1.5 .6 2.7 1.4 3.4 1.1 .9 2.8 1.8 5 2.5 4.5 1.3 10.3 1.3 14.8 0 2.2-.7 4-1.6 5-2.5 1.2-1 1.4-2 1.4-3.4-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm44 1.8c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.2-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm-12 1.1v3.4c2.4 .5 5 .7 7.5 .5v-3.5c-2.5 .1-5.1 0-7.5-.5zm-32 5.1v.6c.7 .2 1.4 .6 2.1 .9 2.2 1.1 4.2 2.7 5.2 4.7 4.3 1.1 9.7 1 13.8-.2 2.2-.7 4-1.6 5-2.5 1.2-1 1.4-2 1.4-3.4-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm44 1.8c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.2-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm-12 1.1v3.4c2.4 .5 5 .7 7.5 .5v-3.5c-2.5 .1-5.1 0-7.5-.5zm-42.2 .5c-4.1 0-7.8 .9-10.3 2.1-2.5 1.2-3.4 2.6-3.4 3.6s.9 2.4 3.4 3.6c2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.2 3.5-2.6 3.5-3.6s-.9-2.4-3.5-3.6c-2.5-1.2-6.2-2.1-10.3-2.1zm37.8 4.6c-1.4 .9-3.2 1.6-5.1 2.2-4.5 1.3-9.7 1.5-14.4 .7v3.4c4.2 .9 9.2 .7 13.1-.4 3.1-.9 6.3-2.7 6.4-5.9zm16.5 1.8c-.1 3.5 3.7 5.1 6.2 5.8 1.4-1.1 2.7-2 4.2-2.6-1.8-.2-3.5-.5-5.2-1-1.9-.6-3.7-1.3-5.1-2.2zm27.5 0c-.7 .5-1.5 .8-2.3 1.2 .8 .1 1.6 .2 2.3 .3 .1-.5 .1-1 .1-1.5zM68.2 69.8v3.4c2.7 .5 5 .7 7.5 .6v-3.5c-2.5 .1-5.1 0-7.5-.5zm33.8 4.5c-4.1 0-7.8 .9-10.3 2.1-2.5 1.2-3.5 2.6-3.5 3.6s.9 2.4 3.5 3.6c2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.2 3.5-2.6 3.5-3.6s-.9-2.4-3.5-3.6c-2.5-1.2-6.2-2.1-10.3-2.1zm-89.7 .6c-.1 3.7 3.8 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.7 0 3.2-.9 6.3-2.7 6.4-5.9-.5 .3-.9 .6-1.4 .8-3.3 1.6-7.6 2.6-12.3 2.6-4.9-.4-10-.9-13.7-3.4zm51.5 0c-1.4 .9-3.2 1.6-5.1 2.2-4.5 1.3-9.7 1.5-14.4 .7v3.4c4.2 .9 9.2 .7 13.1-.4 3.1-.9 6.3-2.7 6.4-5.9zm16.5 1.8c-.1 2.6 2 4 3.5 4.8 0 0 0 0 .1 0v-3.1c-1.3-.5-2.5-1.1-3.5-1.7zM12.3 82.9c-.1 3.6 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.7 0 3.1-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zM44.2 85.8v3.4c1.2 .3 2.5 .5 3.9 .6 .5-1.3 1.4-2.5 2.5-3.5-2.2 .1-4.4-.1-6.5-.5zm21.8 .5c-4.1 0-7.8 .9-10.3 2.1-2.5 1.2-3.5 2.6-3.5 3.6s.9 2.4 3.5 3.6c2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.2 3.5-2.6 3.5-3.6s-.9-2.4-3.5-3.6c-2.5-1.2-6.2-2.1-10.3-2.1zm22.2 .6c0 3.7 3.8 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.2-.9 6.3-2.7 6.4-5.9-4 2.4-9.9 3.4-13.8 3.4-4.9-.4-10-.9-13.8-3.4zM12.3 90.9c-.1 3.6 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.7 0 3.1-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm76 4c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.1-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm-36 4c-.1 1.5 .6 2.7 1.4 3.5 1.1 .9 2.8 1.8 5 2.5 4.5 1.3 10.3 1.3 14.8 0 2.2-.7 4-1.6 5-2.5 1.1-.9 1.4-1.7 1.4-2.3v-1.1c-.5 .3-.9 .6-1.4 .8-3.3 1.6-7.6 2.6-12.3 2.6s-9-.9-12.3-2.6c-.5-.2-1-.5-1.4-.8zm-40 0c-.1 3.6 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.7 0 3.1-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm76 4c-.1 3.7 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.8 0 3.1-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm-76 4c-.1 3.6 3.9 5.2 6.4 5.9 4.5 1.3 10.3 1.3 14.7 0 3.1-.9 6.3-2.7 6.4-5.9-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm40 0c-.1 2.6 2 4 3.5 4.8 2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.6 3.5-2.1 3.5-4.8-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm36 4c-.1 2.6 2 4 3.5 4.8 2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.6 3.5-2.1 3.5-4.8-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2zm-76 4c-.1 2.5 2 4 3.4 4.8 2.5 1.2 6.2 2.1 10.3 2.1 4.1 0 7.8-.8 10.3-2.1 2.5-1.6 3.5-2.1 3.5-4.8-1.4 .9-3.2 1.6-5.1 2.2-5.4 1.6-11.8 1.6-17.2 0-1.9-.6-3.7-1.3-5.1-2.2z",
    "crescent-blade": "M68.8 5.3c-6 .1-12 .9-17.7 3-9.4 4.8-15.7 12-19.3 20.2-4.5 10.1-4.9 21.7-2 32.3 3 10.6 9.4 20.2 18.4 26.1 9 5.9 20.7 8.3 34.9 4.5 12.4-3.3 21-9.9 26.3-18.1-10.1 9.9-21.8 12.6-32.4 10.6 .1 1.1-.3 2.2-1.3 3.2-3.7 3.7-9.4-1.6-6.4-5.5-1.9-.8-3.8-1.8-5.6-2.9 .1 1.5-.4 3.1-1.9 4.5-5.7 5.7-14.5-3-8.7-8.7 .9-.9 2-1.5 3-1.7-1.5-1.4-2.8-3-4.1-4.6-.3 1-.9 1.9-1.7 2.8-6.1 6.1-15.5-3.2-9.4-9.4 1.4-1.4 3.1-2 4.6-2 .5 0 1 .1 1.4 .2-.9-2.1-1.7-4.3-2.2-6.5-.1 .1-.2 .2-.2 .3-5.5 5.5-14-2.9-8.4-8.4 1.2-1.2 2.6-1.8 3.9-1.8 1.4-.1 2.7 .4 3.7 1.2 0-2.7 .4-5.5 1.1-8.2-5.3 2.5-11.5-4.7-6.6-9.6 1.2-1.2 2.5-1.8 3.9-1.8 2.5-.1 4.8 1.5 5.8 3.7 .9-1.7 2-3.5 3.3-5.2-2.8-2.2-4-6.5-.7-9.8 1.4-1.4 2.9-2 4.3-2 3.6-.1 6.9 3 7 6.6 0 0 0 0 0 0 .2 1 .1 2-.1 3-1.7 3-2.7 6.6-2.7 10.3 0 11.6 9.5 21 21 21 11.6 0 21-9.5 21-21 0-6.2-2.7-11.7-6.9-15.6 0 0 0 0 0 0-6.7-7-14.9-10.1-25.2-10.6zm-29.9 5.7c-5.7 2.8-11.2 6.8-16.6 12.1-6.4 6.4-10.9 13.2-13.8 20.2 0 0 0 0 0 0 6.4 .1 12 8.5 6 14.5-3.1 3.1-7 3.1-9.9 1.4-.5 5.7 .1 11.3 1.4 16.7 .5-.8 1.1-1.7 1.9-2.5 2.4-2.4 5-3.3 7.5-3.3 8.3 .1 15.3 10.9 7.7 18.5C19.8 92.1 15.6 92.5 12.2 91.1c3 5.4 6.9 10.3 11.4 14.7 0-3 1.1-6.1 3.9-8.8 2.8-2.8 5.9-3.9 8.9-3.9 9.8 .1 18.2 12.9 9.1 21.9-1.4 1.4-2.9 2.4-4.4 3 6.1 2.9 12.6 4.7 19.3 5.3-3.6-4.5-4.4-11 1-16.4 2.7-2.7 5.8-3.9 8.7-3.8 8.3 .1 15.5 9.4 11.7 17.7 4.6-1.6 9.1-3.8 13.6-6.8-5.5-2.5-8.9-10.1-3.2-15.8 2-2 4.2-2.9 6.3-3 4.4-.2 8.5 3 9.9 7.1 2.2-2.6 4.2-5.2 5.9-7.8-4.4-.9-7.7-6.7-3.4-10.9 1.4-1.4 3-2 4.5-2 1.6 0 3.2 .8 4.4 1.9 3.9-10.7 4-21.6 1.3-31.8-.1 .7-.3 1.4-.4 2.1 0 0 0 0 0 0-1.6 18.3-13.1 35.7-36.3 41.9-15.3 4.1-28.5 1.5-38.6-5.1-10.1-6.6-17.1-17.1-20.3-28.7-3.2-11.6-2.8-24.3 2.2-35.5 2.6-5.8 6.4-11.1 11.4-15.6zM79.9 15.1c9.1 0 16.4 7.3 16.4 16.4s-7.3 16.4-16.4 16.4c-9.1 0-16.4-7.3-16.4-16.4s7.3-16.4 16.4-16.4z",
    "crossbow": "M22.4 4.5l-2.7 2.7 0 0 6.9 83.4-20.8 23.2 8.3 8.3 22.5-20.1 84 6.2c0 0 0 0 0 0l0 0h0v0l2.6-2.6c-.4-.4-.8-.9-1.2-1.3-5.3-6.4-6.4-15.8-8.9-27.3-2.1-9.5-5.3-20.3-13.3-31.3l-9.5 12.7c0 0 0 0 0 0 7.2 9 11.5 16.9 14.9 24.1 3.8 7.8 6.5 14.8 11.1 20.9L41.3 97.9 84.4 59.4l16.1-21.5-10.4-10.4-21.5 16.1L30.7 86 24.5 11.3c6.2 4.6 13.1 7.4 20.9 11.1 7.1 3.4 15.1 7.7 24.1 14.9l12.7-9.5c-11-8-21.8-11.2-31.3-13.3C39.5 12.1 30.1 11 23.7 5.7c-.4-.4-.9-.8-1.3-1.2zm79.3 .1c-.8 0-1.7 .1-2.6 .2-1.1 .2-2.2 .5-3.2 .8-1 .3-1.7 .6-2.4 1.2a1.8 1.8 0 0 0-.7 1.5l1.3 15.6a1.8 1.8 0 0 0 .5 1.1l8.4 8.4a1.8 1.8 0 0 0 1.1 .5l15.6 1.3a1.8 1.8 0 0 0 1.6-.7c.6-.7 .8-1.5 1.2-2.4 .3-1 .6-2.1 .8-3.2 .2-1.1 .3-2.3 .2-3.4-.1-1.1-.3-2.2-1.2-3.2L105.7 5.8c-1-1-2.1-1.1-3.2-1.2-.3 0-.6 0-.8 0zm0 3.6c.2 0 .4 0 .6 0 .6 0 .9 .2 .9 .2l16.4 16.4c0 0 .2 .3 .2 .9 0 .7 0 1.6-.2 2.6-.2 .9-.4 1.9-.6 2.7-.1 .3-.1 .3-.2 .5l-13.7-1.1-7.5-7.5-1.1-13.7c.2-.1 .2-.1 .5-.2 .8-.2 1.7-.5 2.7-.6 .7-.1 1.4-.2 2-.2zm-12 30.1l-4.7 7.9-51.1 51.1-2.2-.2-.3-3.6 50.5-50.5 7.9-4.7z",
    "crossed-chains": "M4.8 4.9v6.8L18.9 26.1l6.2-6.2-14.7-14.9H4.8zm16.4 .9c-1.1 0-2.1 .2-3 .6L47.3 35.5c.7-1.8 .8-4.3 0-7.3-1.2-4.2-4-9.1-8.4-13.5-4.3-4.3-9.2-7.2-13.5-8.4-1.6-.4-3-.6-4.3-.6zm-15.8 13.4c-.7 1.8-.8 4.3 0 7.3 1.2 4.2 4 9.1 8.4 13.5 4.3 4.3 9.2 7.2 13.5 8.4 3 .8 5.4 .8 7.3 0L5.3 19.2zm26.8 7.7l-6.2 6.2 29.9 29.9 6.2-6.2-29.9-29.9zm91.5 14.1c-1.9 .7-3.9 1.5-5.8 2.7-5.1 2.9-8.9 6.8-11 10.4-1.4 2.5-2 4.7-1.8 6.6l18.7-10.7v-8.9zm-64.3 3c-1.1 0-2.1 .2-3 .6l18.4 18.4c2.7-1.3 5.3-2.2 7.9-2.8-1.4-2.4-3.3-4.9-5.6-7.2-4.3-4.3-9.2-7.2-13.5-8.4-1.6-.4-3-.6-4.3-.6zm-15.7 13.3c-.7 1.8-.8 4.3 0 7.3 1.2 4.2 4 9.1 8.4 13.5 1.6 1.6 3.3 3 5 4.2 .4-1.9 1.2-3.9 2.3-5.7 .4-.7 .9-1.5 1.4-2.2l-17.1-17.1zm76 .2L84.6 77.8l4.1 7.2 34.5-19.9v-1.5l-3.5-6zm-30.7 6.6c-4.2 0-9.5 1.5-14.6 4.4-5.1 2.9-9 6.8-11.1 10.4-1.4 2.5-2 4.7-1.8 6.6l34.1-19.7c-1.5-1.1-3.7-1.7-6.6-1.7zm34.6 5.9l-9.9 5.7c.8 .6 1.8 1 3.1 1.3 1.9 .4 4.3 .5 6.9 .1V70zm-18.8 10.9l-34.1 19.7c1.5 1.1 3.7 1.7 6.6 1.7 4.2 0 9.5-1.5 14.6-4.4 5.1-2.9 9-6.8 11.1-10.4 1.4-2.5 2-4.7 1.8-6.6zM74.1 83.5l-2.7 1.5 0 0-3.2 1.8 0 0-29.2 16.9 4.1 7.1 35.1-20.3-4.1-7.1zm34.7 1.9c-.4 1.5-1.1 2.9-1.9 4.4-.6 1.1-1.4 2.1-2.2 3.2l17.2 17.2c.7-1.8 .8-4.3 0-7.3-1.2-4.2-4-9.1-8.4-13.5-1.5-1.5-3.1-2.8-4.7-4zM44.4 90.1c-4.2 0-9.5 1.5-14.6 4.4C24.7 97.4 20.8 101.3 18.7 104.9c-1.4 2.5-2 4.7-1.8 6.6l34.1-19.7c-1.5-1.1-3.7-1.7-6.6-1.7zM106.8 101.7l-6.2 6.1 15.6 15.7h6.9V118L106.8 101.7zm-16.5 2.2c-2.7 1.2-5.3 2-7.9 2.5 1.5 2.7 3.5 5.5 6.1 8.1 4.3 4.3 9.2 7.2 13.5 8.4 3 .8 5.4 .8 7.3 0l-19-19zM59.8 106.9l-28.6 16.5h16.5c4.7-2.9 8.4-6.6 10.4-10 1.4-2.5 2-4.7 1.8-6.5zm-28.7 1.8L5.4 123.5h16.4l13.3-7.7-4.1-7.1z",
    "crossed-pistols": "M38 6.9L28.9 17.5l51.9 44.5c1 .9 1.9 1.7 2.8 2.5-2.3 2.7-3.7 5.4-4.2 8.1-.5 2.8 0 5.5 1.2 8 2.2 4.7 6.6 8.8 11.9 13.4-2.6 4.3-6.7 7.7-10.7 10.6-2.6 1.9-3.1 3.8-2.7 6.1 .4 2.3 2.1 4.9 4.7 7 2.6 2 5.9 3.5 9.2 3.7 3.3 .2 6.6-.7 9.6-3.6 14.6-13.8 12.9-31.6 7.2-41.2l-2.9-4.9 5.5 1.5c5.1 1.4 7.7 .3 9.1-1.5 1.1-1.5 1.5-3.9 .9-6.8-2.3 .7-5.1 1.4-8.2 1.3-4.2-.1-8.9-1.5-13.5-5.3L38 6.9zm51.6 0l-22.2 19.1 10.7 9.2 20.6-17.7-9.1-10.6zM49.5 41.3l-22.7 19.5c-4.5 3.9-9.3 5.3-13.5 5.3-3.1 0-5.8-.6-8.2-1.3-.7 2.9-.3 5.3 .9 6.8 1.4 1.8 4 2.9 9.1 1.5l5.5-1.5-2.9 4.9c-5.6 9.6-7.4 27.4 7.2 41.2 3 2.8 6.3 3.8 9.6 3.6 3.3-.2 6.6-1.6 9.2-3.7 2.6-2 4.3-4.7 4.7-7 .4-2.3-.1-4.2-2.7-6.1-4-3-8.2-6.4-10.7-10.6 5.3-4.6 9.7-8.7 11.9-13.4 1.2-2.5 1.7-5.2 1.2-8-.5-2.7-1.9-5.4-4.2-8.1 .9-.8 1.8-1.7 2.8-2.5l13.4-11.5-10.7-9.2zm-8.8 26.6c1.7 2.1 2.6 3.9 2.9 5.6 .3 1.7 0 3.3-.8 5.1-1.5 3.2-5 6.8-9.7 10.9-.2-.5-.3-1.1-.4-1.6-1-5.8 1.2-12.4 8-19.9zm46.2 0c6.8 7.5 9 14.1 8 19.9-.1 .6-.2 1.1-.4 1.6-4.7-4.1-8.2-7.7-9.7-10.9-.9-1.8-1.1-3.4-.8-5.1 .3-1.6 1.1-3.4 2.9-5.6z",
    "crossed-swords": "M4.9 3.6c14.9 28.1 35.6 50.6 58.1 73.2l.9 .9 0 0c5.5 5.5 11 11 16.6 16.6-4.7 3.7-9.7 7-15 10.1l7.1 7.1 17.2-17.2c10.6 6.9 19.1 15.9 26 26.5l7-7c-10.6-6.9-19.9-15.1-26.5-26l17.2-17.2-7.1-7.1c-2.8 5.5-6.1 10.5-9.9 15.1-11-10.9-21.6-21.5-32.5-31.4-.1-.1-.1-.1-.2-.2C45.9 30.7 27.1 16 4.9 3.6zm118 0c-20.8 11.6-38.5 25.2-55.5 40.3l5.7 5.4 14.2-14.2 3.3 3.3-14.1 14.1 6.1 5.8c15.5-16.7 29.4-34.2 40.2-54.7zm-82.4 31.5l50.1 50.1c-1.1 1.1-2.2 2.2-3.4 3.3L37.2 38.4l3.3-3.3zm-19.2 28.3l-7.1 7.1 17.2 17.2c-6.6 10.9-15.9 19.1-26.5 26l7 7c7-10.5 15.4-19.5 26-26.5l17.2 17.2 7.1-7.1c-5.2-3-10.3-6.4-15-10.1 4.5-4.5 8.9-8.9 13.3-13.2l-6.2-6.4-13.9 13.9c-1.1-1.1-2.3-2.2-3.3-3.3l14-14-6.1-6.3c-4.6 4.5-9.2 9-13.8 13.6-3.8-4.6-7.1-9.7-9.9-15.2z",
    "crown-of-thorns": "M63.8 6.2c-4.2 2.3-8.6 10.5-10.4 14.9-3.7-.6-7.2-.9-10.6-.9-2.9 0-5.6 .2-8.3 .6-4.1-2.1-8.7-7.3-10.7-12.5-2.3 3.9-2.4 10.6-1.4 16.1-4.9 2.4-8.8 5.9-11.4 10.4-1.8 3.1-2.9 6.6-3.2 10.2 3.3-6.5 8.8-11.7 16.4-13.6-8.7 7.9-15 21.8-12.9 32.4-.3 5.7-2.4 9.4-6.2 11.1 4.1 1.1 8.9 .8 12.4-.3 6.2 8.7 15.2 17 26.3 23.6-1.7 4.4-4.2 12.3-4.1 16.5 2.7-3.3 9.4-10.1 15.4-10.7 5.9 2.6 11.8 4.4 17.6 5.6 3.1 4.3 3.2 9.7 1.8 13.4 4.1-2.3 8.5-8.3 10-12 11.8 .4 22-2.6 28.7-8.9 4.4 1.4 7.7 3.9 10 7.6 .1-4.9-2-11.1-4.5-15.1 3.4-7.1 3.2-15.5 .1-24l.1 .1c2.5-3 4.6-8.3 4.5-13.2-2.1 2.6-5.2 3.8-9.2 3.5-3.4-5.6-8-11.2-13.5-16.3 2.6-4.8 7.6-9.1 11-12-4.7-1.3-16.9 1.3-20.2 4.4l1.5 2.1c1.4 3 2.4 6.1 2.8 9.3-6.6-9.3-17.7-18.7-28.7-23.9-4-6.4-4.8-14-3.2-18.4zm-20.7 24.3c.3 0 .6 0 .9 0 7.9 .1 17.2 2.2 26.8 6.4-2.2 5-3.7 11.1-2.5 15.3 3.3-4.7 9.3-8.6 13.9-9.4 14 8.6 24.1 19.7 27.9 29.7l0 .1c4 9.5 3.3 21.3-6.6 29.3 1.2-2.9 2-6 2.4-9.1-3.5 2.5-8.4 3.8-14.1 4-.5-4.3-2.3-13.2-5.6-16.4 .4 4-2 11.6-6.6 15.3-8-1.6-16.7-4.9-25.3-9.9-2.4-1.4-4.7-2.8-6.8-4.3-.9-5.9 2-13.4 5.1-16-4.7-.1-11.7 5.5-14.8 8.2-10.2-9.6-16-20.3-15.3-28.8 4.1-.4 9 .2 12.9 2-1-3.8-4.6-7.9-8.6-11.1 3.7-3.5 9.4-5.2 16.3-5.3z",
    "crystal-eye": "M42 29.7c-3.3 0-6.7 .2-10 .5-1 .1-1.9 .2-2.9 .3-.5 .1-1 .1-1.4 .2-1.9 .3-3.8 .6-5.7 .9-1 .2-1.9 .4-2.9 .6-.4 .1-.9 .2-1.3 .3-.1 0-.3 .1-.4 .1-.3 .1-.7 .1-1 .2-.1 0-.1 0-.2 0-.2 .1-.5 .1-.7 .2-.2 .1-.5 .1-.7 .2-3.3 .8-6.7 1.8-10 2.8 1.4 12.2 4.9 22.1 10 30.1v-.1c5.2 8.2 12.1 14.3 20 18.4-5.4-6.3-8.6-14.5-8.6-23.5 0-13.2 7.1-24.8 17.7-31.2-.6 0-1.3 0-1.9 0zm11.9 .7c-1 .3-1.9 .6-2.8 .9l7.2 15.9L77.5 50.3l9.2-9c-10.9-6-21.9-9.4-32.8-10.8zm-7 3c-9.5 5.5-15.9 15.7-15.9 27.5 0 2.9 .4 5.7 1.1 8.3L44.9 66.8l9.1-17.8-7.1-15.6zm43 11.3l-9.3 9.1 3 18.6L90.6 76c2.4-4.5 3.8-9.6 3.8-15.1 0-6-1.6-11.5-4.5-16.3zm6.5 2.6c1.7 4.2 2.7 8.8 2.7 13.7 0 11.2-5.1 21.3-13.1 28 6.9-1.6 13.8-3.9 20.4-7v.1c6-2.8 11.9-6.1 17.4-9.9-5.8-6.7-11.6-12.4-17.4-17.3v.1c-3.3-2.8-6.6-5.4-9.9-7.7zM57.7 51.9l-8.4 16.6 13.1 13.1 16.6-8.4-2.9-18.3-18.4-2.9zM45.6 71.4l-12 2.4c3.1 6.9 8.5 12.6 15.3 15.8 3.6 .8 7.3 1.4 11.1 1.6l-.1-5.5-14.3-14.3zm36.4 5.5l-17.5 8.9 .1 5.6c2.7 0 5.3-.1 8-.3 6.2-2.1 11.5-6 15.3-11.1l-6-3.1z",
    "crystal-shrine": "M29.1 4.4c0 4-4 8-8 8 4 0 8 4 8 8 0-4 4-8 8-8-4 0-8-4-8-8zm16.1 3.2l-5.9 23h16l6.9-6.9-17-16.1zm57 6.5c0 5.1-5.1 10.1-10.1 10.1 5.1 0 10.1 5.1 10.1 10.1 0-5.1 5.1-10.1 10.1-10.1-5.1 0-10.1-5.1-10.1-10.1zm-37.5 13.5l-5.8 5.8L70.8 77.8h7.3l-13.4-50.2zm18.8 .6l4 8.1 11.3 8.3-1.1-13.4-14.2-3zm-4.5 1l-6.7 9.5 2.5 9.4 8.3-10.6-4.2-8.4zm-40.2 5.9L43.1 51.6l5.5 3.2L59.8 77.8h6.3l-11.4-42.7h-15.9zm47.4 5.8l-10 12.7L82.7 77.8h0l16-27.8-12.5-9.1zm30.6 1.5c0 4-4 8-8 8 4 0 8 4 8 8 0-4 4-8 8-8-4 0-8-4-8-8zm-93.6 3.1l2.8 19 12.2-1.6 4.8-6-19.9-11.4zm86.7 13.4l-13.1 3.3L87.9 77.8h6.4l4.8-4.9 10.9-14zm-63.8 1.3l-4.4 5.4 6.4 12.1h6.4l-8.5-17.6zm-8.5 7.3l-9.8 1.3L37 77.8h6.2l-5.5-10.3zm-22.8 2.8c0 4-4 8-8 8 4 0 8 4 8 8 0-4 4-8 8-8-4 0-8-4-8-8zM34.2 82.2v7.5h59.5v-7.5H34.2zm8 12v19.5h4v-19.5h-4zm8.5 0v19.5h26.5v-19.5H50.8zm31 0v19.5h4v-19.5h-4zm-41.2 24l-7.5 4h61.9l-7.5-4H40.6z",
    "despair": "M11.3 4.8v109.6l4.7-6.8V4.8H11.3zm12.6 0v102h4.7V4.8H23.9zm13.5 0V73.5h.8c1.2-1.4 2.5-2.7 3.9-3.9V4.8h-4.7zm12.6 0v59.2c1.5-.9 3.1-1.6 4.7-2.4V4.8h-4.7zm12.6 0v54c1.5-.4 3.1-.8 4.7-1.2V4.8h-4.7zm12.2 0v51.8c1.3-.1 2.6-.1 3.9-.1 .3 0 .5 0 .8 0V4.8h-4.7zm13.5 0v52.8c1 .2 2.1 .5 3.1 .9 .4-.5 .9-1 1.3-1.5 .1-.1 .2-.2 .3-.3V4.8h-4.7zm12.6 0v46c1.5-.7 3.1-1.3 4.7-1.7V4.8h-4.7zm12.6 0v44.1c1.7 .3 3.2 .9 4.7 1.8V4.8h-4.7zM110.2 53.2c-.9 0-1.8 .1-2.7 .3-3.8 .7-8 3-11.4 6.6-1.2 1.3-2.3 2.7-3.1 4.1-23.3-14.4-82.8 18.9-44.9 47.3H18.2l-6.6 11.9h64.3l-22.1-25.8c6.1-6.7 16.9-10.9 24.2-11.3 3.4 11.3 9.1 28.4 17.9 37.1h15.2c-11-11.9-19.5-27.9-20.6-46 .5 1.4 1.2 2.6 2.3 3.6 2.3 2.1 5.5 2.9 9.3 2.2 3.8-.7 8-3 11.4-6.6 3.4-3.7 5.4-8 5.9-11.8 .5-3.8-.5-7.1-2.7-9.2-1.7-1.6-4-2.4-6.6-2.4z",
    "dig-dug": "M29.4 4.5l-23.7 24.1c4 4.8 10.9 8.9 16.6 10.1 3.8 .8 7.7 .5 10.8-1.2 7.3 7.2 14.6 14.6 21.8 22l5.5-5.6-21.9-21.9c1.6-3.1 2.1-7 1.1-10.7-2-7.6-5.3-11.9-10.2-16.8zm31.3 2.4c-2.3 0-4.6 .2-6.9 .7 29.3 17.6 51.1 41.2 68.4 68.4 .7-14.8-5.3-30.1-14.8-42.4-3.8 1.4-8.4 .1-11.6-3-3.2-3.2-4.4-7.8-3-11.6-9.8-7.5-21.1-12.1-32-12zM32.1 15.1c1.4 2.4 2.4 4.8 2.8 7.1 .8 4.1 .1 7.5-2.1 9.7-2.2 2.2-5.6 3-9.7 2.1-2.3-.5-4.7-1.4-7.1-2.8zm65.9 4c-1.8 1.8-1.6 5.4 1.1 8.1 2.7 2.7 6.3 2.9 8.1 1.1 1.8-1.8 1.7-5.5-1.1-8.1-2.2-2-5.8-3.4-8.1-1.1zm-14.1 17.8L5.6 115.2c1.1 2.9 2.7 5.1 6.1 6.2L90.1 43c-1.9-2.2-4-4.2-6.2-6.2zm-10.8 29.8l-5.8 5.8c8.1 8.5 16.2 17.1 24.4 25.6-3.9 3.6-7.9 6.8-11.6 9 14 14 31.2 19.5 40.5 13.6 5.7-9.3 .3-26.6-13.6-40.5-2.4 3.8-5.5 7.7-8.9 11.4z",
    "diving-dagger": "M4.5 4.7v4.3l33.3 33.3c-1 1.6-1.5 3.3-1.6 5L4.5 15.7v8.9l47.9 47.9c-.8 1.4-1.6 2.9-2.3 4.3L4.5 31.2v9.8l42.8 42.8c-.6 1.7-1 3.4-1.5 5.1L4.5 47.6v8.4l39.6 39.4 .5-.5 0 0 3.5-.7c6.5-1.4 12.5-3.7 18-6.9 16.7 16.5 29.9 25.7 52.6 33.8l4.2 1.5L121.7 118.2c-6.2-23.1-17.3-34.1-34.8-51.6 3.4-5.6 5.9-11.9 7.3-18.7l.7-3.4 .4-.4L56 4.7h-8.8l41.2 41.1c-1.7 .4-3.5 .9-5.1 1.5L40.7 4.7h-9.9L76.3 50.2c-1.5 .7-2.9 1.5-4.3 2.3L24.2 4.7H14.9L47.4 37.2c-.3 0-.7 0-1 0-1.5 .1-3 .4-4.4 1.2L8.3 4.7h-3.8zm42.2 37.1c1.3 0 2.6 .4 3.8 1.1 1.2 .7 2.1 1.7 2.6 2.6 .5 .9 .5 1.6 .2 2.4l-.8 1.9L54.2 50.8c4.4 2.6 7.8 5.5 11.2 9.5l1.5 1.7 1.8-1.4c5.7-4.6 12.4-7.9 20-9.9-1.5 5.5-3.7 10.6-6.7 15.2L81 67.4l1.3 1.3c17.1 17.1 27.3 26.7 33.6 46.3-20-7.6-31.9-16.3-47.8-32.3l-1.3-1.3-1.6 1c-4.4 2.7-9.2 4.8-14.5 6.2 1.9-7.3 5.1-13.9 9.3-19.5l1.4-1.8-1.7-1.4c-4.1-3.5-7.8-6.9-10.4-11.3l-.8-1.5-1.6 .3c-2.1 .4-4.3-.9-5.4-3-1.1-2.1-1.2-4.6 1.4-7.1 1.2-1.1 2.5-1.6 3.8-1.7zm24.8 24.7l-4.2 4.5c10.4 10.9 28.1 27.2 39.5 35.2-8-11.5-24.4-29.2-35.3-39.6z",
    "dread-skull": "M55 6.3c-8.6 1.2-16.8 4.3-23.7 9.3l17.3 35-27.4-24.8c-7.1 9.8-10.6 23.3-7.9 40.9l3.8 23.6 17.6-3.3 .9 4.6-3.9 .7 11.2 31.9H49.3l-2-15.5 4.6-.6 2 16.1h7.4V107.8h4.7v16.4h7.4l2-16.1 4.6 .6-2 15.5h6.4l11.1-31.8-4.5-.9 .9-4.6 17.6 3.3 4.6-23.6c2.7-17.4-.9-30.9-8.1-40.7l-27.2 24.7L96.1 15.9c-6.9-5-15.1-8.2-23.7-9.5l-8.6 41.1L55 6.3zm-23 48.1c1.1 0 2.2 .2 3.3 .6-1.9 1.7-3.1 4.2-3.1 7 0 5.2 4.2 9.5 9.5 9.5 4 0 7.4-2.5 8.8-5.9l7.3 5.6-20.4 6.6-.1 0c-4 1.1-7.6 .2-10-1.9-2.5-2.1-3.8-5-4.3-8.1-.5-3-.1-6.2 1.3-8.8 1.4-2.6 4.3-4.6 7.8-4.6zm54.1 4.2c-.4 1.1-.6 2.2-.6 3.4 0 5.2 4.2 9.5 9.5 9.5s9.5-4.2 9.5-9.5c0-.1 0-.3 0-.4 .6 2 .6 4.1 .3 6.2-.5 3-1.8 6-4.3 8.1-2.5 2.1-6.1 2.9-10 1.9l-.1 0-20.4-6.6 16.3-12.5zm-22.3 14.3l10 25.5-4.3 1.8-5.7-8.9-5.7 8.9-4.4-1.8 10.2-25.5z",
    "dripping-knife": "M122.7 3.8c-4 6.9-9.7 12.4-16.5 16.5-.4 5.7-3.3 11.1-7.7 16-6.2 6.9-15.5 13-26.2 18.5-21 10.8-47.7 19.2-67.7 24.4v13.5c1.9-.6 3.8-1.2 5.7-1.8 4.7 0 9.9 1.8 11.6 12.6C20.2 111.4 16 113.3 16 119.2c0 3.1 3.1 5.4 6 5.4 3 0 5.9-2.1 5.9-5 0-5.8-4.1-8.1-5.8-16.3 2.4-19.1 33.4-29.3 33.4-17.9 0 2.9-3.2 5.3-3.2 7.9 0 3.2 2.9 5.4 6 5.4 3 0 6.2-2.5 6.2-5.9 0-3.4-3.5-5.2-3.5-7.9 0-17.8 28.7-19.5 33.2-4.2-3.3 14.2-10.5 18.8-10.5 29.2 0 5.5 5.4 9.5 11.1 9.5 5.5 0 11.3-4.3 11.3-10.1 0-10.9-7.5-14.5-10.8-28.8 5.8-32.4 15.3-30.4 22.1-44 0 0 0 0 0 0C122.6 27.4 124.7 16.7 122.7 3.8zm-21.6 19.2c-9.3 4.3-20 6.1-30.8 5.3C55.4 38.3 27 51.7 4.6 56.2v18c19.7-5.2 45.5-13.4 65.6-23.7 10.4-5.4 19.3-11.3 24.9-17.5 3.1-3.4 5.1-6.7 6-10.1zm13.6 25.5c-1.9 10.8-7.4 12.9-7.4 20.5 0 3.8 3.7 6.6 7.4 6.6 3.7 0 7.2-2.6 7.2-6.2 0-7.2-5.3-10.1-7.2-20.9z",
    "drum": "M119.2 6.4L70.7 36.4l4.8 2.3L121.6 10.2l-2.4-3.8zM18.4 16.4l-1.9 4.1 71.6 34.2 .3 .7c.8 1.6 2.4 3.1 4.4 4.1l0 0 0 0c2.1 1 4.3 1.3 5.9 1.1 1.6-.2 2.6-.9 3.1-2 .5-1.1 .4-2.1-.4-3.4-.8-1.3-2.5-2.7-4.7-3.8-2-1-4.2-1.2-6-.9l-.7 .2L18.4 16.4zm30.3 24.4c-10.2 .7-19.4 2.2-26.5 4.1-5.3 1.4-9.5 3.1-12.2 4.8C7.2 51.4 6.2 52.9 6.2 54c0 1.1 .9 2.6 3.7 4.3 2.7 1.7 6.9 3.4 12.2 4.8C32.7 66 47.6 67.8 64 67.8c12.3 0 23.7-1 33.1-2.7-2-.1-4.1-.6-6.2-1.6l0 0 0 0c-2.5-1.2-4.7-3.1-6-5.4l-18.2-8.7-9.1 5.6c-1.1 2.4-3 4.5-5.4 6l0 0 0 0c-2.7 1.7-5.6 2.5-8.3 2.4-2.7-.1-5.4-1.4-7-3.8-1.5-2.5-1.3-5.4-.1-7.8 1.2-2.4 3.3-4.4 5.9-6.1l0 0h0c2.4-1.5 5.1-2.2 7.8-2.2l1.7-1.1-3.6-1.7zm31.9 .1l-.1 .1 10.3 4.9c2.6-.4 5.4 .1 8 1.3h0c2.8 1.3 5.1 3.1 6.6 5.4 1.5 2.3 2 5.2 .7 7.8-.8 1.6-2 2.8-3.5 3.6 1.2-.3 2.3-.5 3.4-.8 5.3-1.4 9.5-3.1 12.2-4.8C120.8 56.6 121.8 55.1 121.8 54c0-1.1-.9-2.6-3.7-4.3-2.7-1.7-6.9-3.4-12.2-4.8-6.9-1.8-15.6-3.2-25.3-4zm-23.5 3.9l-5.4 3.3-.8-.1c-1.8-.2-3.9 .3-5.8 1.5l0 0c-2.1 1.3-3.6 2.9-4.3 4.3-.7 1.4-.7 2.4-.1 3.4 .7 1.1 1.7 1.6 3.3 1.7 1.6 .1 3.7-.5 5.8-1.7 1.9-1.2 3.3-2.9 4-4.5l.3-.7 7.8-4.9-4.8-2.3zM9.9 63.5l6.7 11.2 8.3-6.2a102.1 102.1 0 0 1-4-1c-4.3-1.2-8.1-2.5-11.1-4zm108.2 0c-3 1.5-6.7 2.9-11.1 4-1.7 .5-3.6 .9-5.5 1.3l9.7 6.1 6.8-11.4zM121.8 66.1l-4.4 7.3a22.7 22.7 0 0 0 .6-.2c1.5-.7 2.6-1.4 3.2-2 .6-.6 .7-.9 .7-1.2v-3.9zm-115.5 0V70c0 .3 .1 .6 .7 1.2 .6 .6 1.7 1.3 3.2 2 .2 .1 .4 .2 .6 .2L6.2 66.1zm24.7 3.5l-9.2 6.9c.5 .1 .9 .2 1.4 .3 5.4 1 11.8 1.7 18.7 2.2l-9-9a143.4 143.4 0 0 1-1.9-.3zm58.5 1.1c-5.8 .7-12.2 1.2-18.8 1.4l9.3 7 9.5-8.3zm6.8 0l-9.3 8.1c6.6-.5 12.7-1.2 17.9-2.1 .3 0 .5-.1 .7-.1l-9.4-5.9zm-56.1 .2l8.1 8.1 9.2-6.9c-6.1-.2-11.8-.6-17.2-1.2zM64 72.8l-9.1 6.8c3 .1 6 .1 9.1 .1 3 0 6.1 0 9.1-.1L64 72.8zM6.2 76.3V110c0 1.4 1.1 2.9 4 4.6 1 .6 2.2 1.1 3.5 1.6V79.3c-2.1-.6-3.9-1.3-5.5-2-.7-.3-1.4-.7-2-1zm115.5 0c-.6 .4-1.3 .7-2 1-1.6 .7-3.5 1.4-5.5 2V116.2c1.3-.5 2.5-1.1 3.5-1.6C120.7 112.9 121.8 111.4 121.8 110V76.3zM18.2 80.4v37.4c1.5 .5 3.2 .9 5 1.3 6.4 1.4 14.2 2.4 22.5 3V83.7c-8.6-.5-16.6-1.3-23.4-2.5A107.5 107.5 0 0 1 18.2 80.4zm91.5 0a107.5 107.5 0 0 1-4.1 .8c-6.8 1.2-14.8 2-23.4 2.5v38.4c8.3-.6 16.1-1.6 22.5-3 1.8-.4 3.4-.8 5-1.3V80.4zM50.2 84v38.4c4.5 .2 9.1 .4 13.8 .4 4.6 0 9.2-.1 13.8-.4V84c-4.5 .2-9.1 .3-13.8 .3-4.6 0-9.2-.1-13.8-.3z",
    "engagement-ring": "M52.2 4.5c-3.5 0-6.7 1.2-10 3.9 1.9 18.3 4.8 35.9 9.5 52.5-2.6 .2-5.3 .5-7.9 .7-8.3-12.1-13.7-24.9-19.9-37.4-2.4-.3-5.6 .3-8.3 1.8-2.9 1.6-5 3.9-5.6 6.3C17.9 49 27.9 66.5 38.5 81.8c2.3 2.9 4.3 5.8 6.2 8.8l.7 1-.1 0c1.7 2.6 3.4 5.1 5.1 7.5l-3.7 2.8c-3.5-4.7-6.4-9.5-9.6-14-9.7-4.3-19.1-7.1-24.9-6.4-2.9 .3-4.8 1.4-6 3.4-1.1 1.8-1.7 4.7-1.3 9.1 19.8 4.9 31 15 38.6 21.5 3.2 2.8 6.4 5.3 10.2 7.5h31c7.9-3.4 13.9-8.9 15.3-15.6 1.2-5.8 4-15.5 5.4-21.4 2.2-9.5 6.6-21.2 10.5-30.5 1.9-4.6 3.7-8.7 5.1-11.5 .7-1.4 1.3-2.6 1.7-3.4 0-.1 .1-.1 .1-.2-1.1-2.6-3-5-5.3-6.5-2.3-1.5-4.7-2.1-6.8-1.7-5.6 10-10.7 20.3-14.3 32.3-2.2-.9-4.5-1.6-6.8-2.2-.1-3.3-.2-6.6-.1-9.8l-15.8-1.7c-.1 3.1-.1 6.2-.1 9.3-2.1-.1-4.2-.1-6.3 0C63 42 60.2 24 59.5 6c-2.4-.9-4.5-1.4-6.5-1.5 0 0-.1 0-.1 0-.2 0-.5 0-.7 0zm33.3 1.4c-2 0-3.9 .4-5.1 1.2-2.3 8.8-4.1 17.6-5.2 26.5l15.7 1.7c1.1-8.4 2.9-16.6 5.2-24.6-1.7-2.2-4.7-3.8-7.7-4.4-1-.2-1.9-.3-2.9-.3zm-13.9 32c-.1 0-.2 0-.3 0-.6 .1-.9 .3-1.3 .7-.5 .6-.9 1.6-1 2.8-.1 1.1 .2 2.4 .6 3.1 .4 .8 .8 1.1 1.5 1.2l21.4 2.2h0l0 0c1.2 .2 1.8-.1 2.3-.7 .5-.6 1-1.6 1.1-2.7 .1-1.1-.2-2.3-.6-3.1-.5-.8-1-1.2-1.9-1.3l0 0-21.3-2.2h0c-.1 0-.3 0-.4 0z",
    "evil-book": "M23.5 7c-6 0-10.7 3.8-13.7 8.2C6.8 19.7 5.2 24.7 6.2 28.8l0 0 20.4 79.5c0-2.4 .6-4.8 1.6-7.1 1.1-2.5 2.7-4.9 4.8-6.8 1.9-1.9 4.3-3.3 7.3-4.1 0 0 0 0 0 0 1.1-.3 2.2-.6 3.4-.7l.2 0 80.8 2.8-31.7-82.1-68.8-3.2c-.2 0-.4 0-.6 0zm0 4.7c.1 0 .3 0 .4 0L89.6 14.7l28.1 72.7-74.9-2.4-.2 0c-6.5 .7-11.9 4-15.1 8.5l-16.9-65.8v0c-.4-1.6 .5-6.3 3-9.9 2.4-3.5 5.8-6.2 9.8-6.1zm4.4 4.4L23.3 17.3l18.3 63.8 4.5-1.3-18.3-63.8zm13.1 4.8c.8 15.6 11.5 21.2 20.4 21.9l2.3-4.2-11-5 4-2.2c-6.2-.6-10.7-6.1-15.7-10.4zm45 .7c-2.7 4.6-4.6 10.2-9.8 11.5l2.6 3.5-6.2 4 3.7 3.5c7.5-1.8 14.8-8.3 9.7-22.5zm11.1 22.1l-8.4 14.8-4.5-10-6.4 12.7-12.5-9.3-2.1 8.8-19.2-14.9 11.5 24.8 3.4-5.5 11.5 14.8 5-11.6 10.3 11.8 4.4-13 5 7.2 2-30.4zM44.1 94.2c-5.9 .7-9.8 4.4-11.7 8.8-1.7 4-1.4 8.3 .5 10.7l78.8 2.7c-.6-3.4-.5-6.9 .6-10.3l-5.4-1.7 8.6-5c.6-.9 1.2-1.8 1.9-2.6l-73.2-2.5z",
    "executioner-hood": "M81.5 8.2C56.4 14.9 47.9 25.6 45 34.1l-4.7 47.2c-8.3 7-18.8 11.3-30.5 15.2l4.6 9.3 9.6-3.5 5.5 5.3-4.3 6.9 9.1 4.8 5.1-7.5 9.2 1.8-2.7 7.6 10.4 2.5 3.1-9.4 10.5 .1 5.8 8.2 10.6-.9-3.8-8.1 9-2.4 5.9 7.2 12-4.8-8.8-6.9 6.3-4.3 7.7 2.4 3.9-8.2c-10.7-4.7-21.8-9.3-28.7-15l-4-49.4c.1-4.8-10.8-12.6-4.3-24.2zM49.6 52c1.5 7 7.2 8.3 14.4 10.2-6.6 .2-10.8 3.9-14.4 0-2.7-2.9-1.6-7 0-10.2zm32.8 0c1.6 3.3 2.7 7.3 0 10.2-3.6 3.9-7.8 .2-14.4 0 7.2-1.9 12.9-3.2 14.4-10.2z",
    "eye-target": "M64 26.2c-15.1 0-31.2 9.6-42 19.4-8.7 7.9-14.7 15.6-16.7 18.3 2 2.7 8 10.4 16.7 18.3C32.8 92.2 48.9 101.8 64 101.8s31.2-9.6 42-19.4c8.7-7.9 14.7-15.6 16.7-18.3-2-2.7-8-10.4-16.7-18.3C95.2 35.8 79.1 26.2 64 26.2zm0 5.8a32 32 0 0 1 15.9 4.2A12 12 0 0 0 72 47.5a12 12 0 0 0 0 .1A18.1 18.1 0 0 0 66.2 45.9V40h-4.5v5.9c-8.3 1-14.8 7.6-15.9 15.9H40v4.5h5.9c1 8.3 7.6 14.8 15.9 15.9V88h4.5v-5.9c8.3-1 14.8-7.6 15.9-15.9H88v-4.5h-5.9a18.1 18.1 0 0 0-.5-2.5A12 12 0 0 0 84 59.5a12 12 0 0 0 10.3-5.8A32 32 0 0 1 96 64a32 32 0 0 1-32 32 32 32 0 0 1-32-32 32 32 0 0 1 32-32zm-2.2 18.4V56h4.5v-5.6c5.8 .9 10.4 5.5 11.3 11.3H72v4.5h5.6c-.9 5.8-5.5 10.4-11.3 11.3V72h-4.5v5.6c-5.8-.9-10.4-5.5-11.3-11.3H56v-4.5h-5.6c.9-5.8 5.5-10.4 11.3-11.3z",
    "falcon-moon": "M61.3 8.8a60 60 0 0 0-26.4 6.2A80 80 0 0 1 111.3 94.8a80 80 0 0 1-.4 7.7A60 60 0 0 0 121.3 68.8a60 60 0 0 0-60-60zM32.3 35c-3.6 0-8.7 1-13.6 2.8-4.6 1.7-9 4-12.1 6a114.1 114.1 0 0 1 7.7 3.2c3.2-1.1 6.7-1.9 10.3-2.5-2.2 1.4-4.5 2.7-6.5 4.3a105.3 105.3 0 0 1 5.4 2.9c2.9-1.7 6.2-3.1 9.6-4.4-2.1 2.1-4.5 4-6.2 6.4 5.9 3.7 11.8 8.2 18 13.8-5 6-8.7 12.4-15.7 20.8-3.1 3.7-8.8 5.7-14.2 8-2.7 1.1-5.3 2.2-7.4 3.2-.1 .1-.2 .1-.3 .2 .7 .1 1.3 .2 2.1 .4 3.9 .9 8.3 2.2 11.1 5 2.8 2.8 4.1 7.3 5 11.1 .2 .8 .3 1.4 .4 2.1 .1-.1 .1-.2 .2-.3 1.1-2 2.1-4.6 3.2-7.4 2.2-5.4 4.3-11.2 8-14.2 8.4-6.9 14.8-10.7 20.8-15.7 5.6 6.2 10.1 12.1 13.8 18 2.3-1.8 4.3-4.1 6.4-6.2-1.2 3.4-2.7 6.7-4.4 9.6a105.3 105.3 0 0 1 2.9 5.4c1.6-2 2.9-4.3 4.3-6.5-.6 3.6-1.3 7.1-2.5 10.3a114.1 114.1 0 0 1 3.2 7.7c2-3.1 4.3-7.5 6-12.1 2.4-6.5 3.5-13.4 2.5-16.5-1.1-3.2-5.7-8.2-11.6-12.7-3.3-2.5-7-5-10.6-7.1 5.7-6.9 11.9-15.4 11.9-15.4l0-.1 0-.1a13.6 13.6 0 0 0 .7-1c2.8-.9 3.9 .5 6.6 3.3-.1-6-2.6-9.4-6-11.3a6.6 6.6 0 0 0-.9-1.1c-1.1-1.1-2.5-1.8-4.2-1.8-1.7 0-3.7 .6-5.8 2.3l-.1 0-.1 0s-8.5 6.1-15.4 11.9c-2.1-3.6-4.6-7.2-7.1-10.6-4.5-5.9-9.5-10.5-12.7-11.6-.8-.3-1.8-.4-3-.4z",
    "feather-necklace": "M64 6.2c-1.9 0-3.6 .4-4.7 .9-.8 .4-1 .7-1.1 .8 .1 .1 .2 .4 1.1 .8 1.1 .5 2.8 .9 4.7 .9 1.9 0 3.6-.4 4.7-.9 .8-.4 1-.7 1.1-.8-.1-.1-.2-.4-1.1-.8-1.1-.5-2.8-.9-4.7-.9zm5.7 1.8c0 0 0 0 0 0s0 0 0 0zm-11.4 0c0 0 0 0 0 0s0 0 0 0zm-4.2-1.6c-7.1 .9-15.3 2.6-22.7 4.9-5.6 1.8-10.8 4-14.7 6.6C12.7 20.6 9.8 23.9 9.8 28c0 15.2 9.5 28.7 20.8 38.4 6.8 5.8 14.3 10.4 21.1 13.1-.1-1.7-.1-3.4-.1-5.1-5.8-2.5-12.3-6.5-18.1-11.4C22.8 53.8 14.2 41.3 14.2 28c0-1.9 1.5-4.1 4.9-6.3 3.3-2.2 8.2-4.3 13.5-6 7.2-2.3 15.2-3.9 22.1-4.7-.6-.8-1.1-1.8-1.1-2.9 0-.6 .1-1.1 .3-1.6zm19.9 0c.2 .5 .3 1 .3 1.6 0 1.1-.4 2.1-1.1 2.9 6.9 .8 15 2.5 22.1 4.7 5.4 1.7 10.2 3.8 13.6 6C112.2 23.9 113.8 26.1 113.8 28c0 13-8.5 25.6-19.2 34.8-5 4.3-10.4 7.8-15.6 10.4-.2 1.4-.4 3.3-.6 5.4 6.2-2.8 12.9-7.1 19.1-12.4C108.8 56.4 118.2 43 118.2 28c0-4.1-3-7.4-6.9-10.1-3.9-2.6-9.1-4.8-14.7-6.6-7.4-2.4-15.6-4-22.7-4.9zM63.9 54.7l-3.2 2.7c1.1 4.9 .9 9.8 .8 14.7l6-.4c-.7-5.8-1.3-11.6-3.6-17zm3.9 17.6c-.9 10.9-1.8 15.5-2.3 27.1-3.2-11.1-4.2-15.7-4.3-27-1.5 .9-3.2 1.6-5.2 2.5 .1 10 .8 21.2 3.3 30.4 2.4 8.6 6.1 15.2 11.9 18.1 .1-1.2 .2-2.6 .3-4.5 .1-1.4 .2-3.1 .2-4.8l-5.2-1.7 5.3-2.2c.1-1.6 .1-3.2 .2-4.9l-6.3-2 6.6-2.8c.5-10 1-20.2 1.8-26.5-2.2-.3-4.4-.8-6.5-1.8z",
    "feather": "M117.7 5L92 12.5l10.4-7c-6.5 1.5-14.8 4.4-25.2 9l-17 17.7L66.2 19.8c-5.8 3.2-12 7.5-17.9 12.5l-4 16.1-.8-11.9c-5.9 5.4-11.4 11.4-16 17.7-4.8 6.6-8.6 13.6-10.4 20.6l-7-4.7c.6 5.9 2.6 11.1 5.8 15.8l-8.4-2.6c1.9 5.9 5 9.7 10.3 12.8-3 8.3-4.3 17-5.8 25.7l4.6 .8C21.8 69.3 59.5 35.5 93.5 20.4l1.7 4.3c-30.4 13.6-54.1 36.6-66.5 69.8 4.5 0 8.9-.5 13.1-1.6l1.2-15.2 3.3 13.9c2.7-1 5.2-2.2 7.5-3.6l-5.2-10.9 8.2 8.7c2-1.6 3.6-3.4 4.9-5.4 7.6-11.9 15.6-23.7 31.2-33.5l-11.4-4 17.5 .5c2.9-1.4 5.8-3.2 8.1-4.9l-12.4-1 18.7-4.4c1.4-1.4 2.8-3 4-4.5 4.3-5.5 7.2-11.2 6.5-16.4-.3-2.6-1.9-5-4.4-6.4-.6-.3-1.3-.6-1.9-.8z",
    "feathered-wing": "M5.6 7.2c26.9 17 51.8 30.4 80.5 33.4 10.2 1.1 12 8.7 7.9 17.5-6.6 14.4 4.1 35.9 28.1 48.9-1.5 7-11.6 12.9-17.8 10.8-5.2-10.8-13.2-22.2-22-19.1-17.8 6.3-36.2 7.7-48.7 .9 16.6-2.2 32.3-6.6 46.2-13.6C54.8 89.8 25.1 89.8 13.8 77.3c22.8 .9 41.2-1.4 61.8-6.6C48.2 68.2 18.1 63.2 9.6 46.3c20.2 6.3 47.4 8.7 65.8 8.8C46.7 47.9 8.2 28.2 5.6 7.2z",
    "fire-bomb": "M27.2 8c-4.2 0-8.2 1.5-11.5 3.8-8.5 6-12.6 18.7-4.7 29.5C17.3 49.9 14.6 61 8.2 67.2L11.4 70.6c8-7.7 11.3-21.4 3.5-32-6.5-8.8-3.1-18.2 3.5-22.9 3.3-2.4 7.4-3.4 11.5-2.6 3.9 .8 7.9 3.3 11.5 8.6l-14.8 8.6 6 10.5c-12.4 15.8-14.6 38.3-4 56.8 14 24.3 45 32.6 69.2 18.6 24.2-14 32.5-45.1 18.5-69.4-10.6-18.5-31.1-27.7-50.9-24.9L59.5 11.2l-14 8.1c-4.2-6.3-9.4-9.9-14.7-11-1.2-.2-2.4-.3-3.6-.3zm36.9 23.8c23.4 10.9 27.9 25.4 18.7 42.3 8.5-4.5 12.1-11.3 8.6-21 8.2 5.5 12.5 16.4 12.3 28.2-.2 15.7-8.3 25.6-18.6 29.8 2.1-3.3 3.4-7.4 3.4-11.8 0-10.1-6.5-18.3-14.8-19.3 3.3 2 5.6 5.7 5.6 9.9 0 6.4-5.2 11.6-11.6 11.6-5.3 0-9.8-3.6-11.1-8.4-.6 2-.9 4.1-.9 6.2 0 4.1 1.1 7.9 2.9 11-9.8-4.6-17.4-14.4-17.7-29-.2-11.4 4.1-18.9 14.2-24.4-3.8 7.1-2.3 15.3 1.7 18.8-2.7-17.3 23.7-26.7 7.3-43.9v0z",
    "fist": "M56.8 5.4c-.5 0-.9 0-1.4 0-3.8 .2-7.7 1.3-9.9 2.7l0 18.3c.7 0 1.4 0 2.2 0 5.8 0 11.8 .8 17.1 2.4l0-21.9c-1.8-.9-4.8-1.5-8-1.5zm20.2 2.3c-3 0-5.8 .6-7.5 1.4l0 19.4v1.9c9.6 3.9 16.2 10.6 14.7 19.7l-.2 1.4-1.4 .4c-4.4 1.3-8.7 2.4-13.1 3.3V61.6c6.4-.2 12.8-.7 19.3-1.5l0-49.5c-2.1-1.4-5.9-2.6-9.7-2.8-.7 0-1.4-.1-2.1-.1zM35.8 11.6c-.3 0-.6 0-.9 0-1 0-2.1 .1-3.2 .3-3.9 .6-7.9 2.1-10.1 3.9l0 18.2c4.7-4 11.7-6.3 19.3-7.1l0-14.5c-1.2-.4-3-.7-5.1-.8zm64.6 .9c-2.7 0-5.2 .5-6.8 1.2l0 45.8c6.3-1 12.5-2.4 18.8-4.1l.5-39.6c-2.1-1.5-5.9-2.8-9.8-3.1-.9-.1-1.8-.1-2.8-.1zm-55.7 18.6c-13.4 .2-25.4 5.1-24.5 16.6 4-1 7.7-1.5 11.2-1.5 8.7-.1 16.1 2.4 21.8 6.9 8.7-.8 17.5-2.5 26.4-5.1 0-10.3-18.5-17.2-34.9-16.9zm-12.2 19.7c-.3 0-.7 0-1 0-4.3 .1-9.1 1-14.4 2.8 1.4 13.5 6.6 26.6 14.6 35.8 1.6 1.8 3.2 3.4 5 4.9 7.3 2.3 17.3 3.2 27.6 3 .9-14-2.2-27.1-9-35.7-5.3-6.7-12.8-10.8-22.8-10.9zm32.3 5.6c-2.3 .4-4.7 .8-7 1 .4 .4 .8 .9 1.1 1.3 .8 1 1.5 2 2.2 3.1 2.5 0 5 0 7.5 0H64.8v-5.4zm48 3.8c-16.4 4.5-32.9 6.4-49 6.3 4.2 8.8 6 19.5 5.3 30.6 10.6-.5 21.3-2.1 29.5-4 6.7-8.2 11.8-19.3 14.2-33zM100.1 97.5c-9.6 2.3-22 4-34.2 4.4-11.9 .3-23.6-.6-32.4-3.8l0 19.7c6.8 3.1 19.1 5.1 31.8 5.1 12.8 0 26.1-1.8 34.8-5.2l0-20.2z",
    "fizzing-flask": "M91.4 4.7c-2.8 0-5.3 1.8-6.2 5h0c-6.1-1.9-14.4-1-17.1 5-3.9-5.2-12-3.5-13.8 2.5-1.8 6 3.4 12.4 11.2 12.1-.8 8.5 11.1 13.7 20.4 9.8-.1 4.8 2.1 10.5 7.6 11.2-1.6 4.5 .8 10.5 7.2 10.5 7.9 0 9.5-9.1 5.3-13.3 2.4-2.6 3.2-6.3 2.8-9.8 4.3 3 8.6-1.6 8.4-5-.4-6.2-5.1-9-8.4-6.1-2.2-6.9-9.3-8-13.1-4.1 .3-1.9 .1-3.3-1.3-4.8 5.7-1.4 4.7-9.4 1.2-11.7-1.4-.9-2.7-1.3-4-1.3zm17.1 1.3c-5.7 0-5.7 8.7 0 8.7s5.7-8.7 0-8.7zM44.4 18.7c-5.7 0-5.7 8.7 0 8.7s5.7-8.7 0-8.7zm16.2 14.8c-.4 0-.9 .2-1.5 .7-1.2 1.1-2 3.5-.5 6.1 .3 .6 .7 1.1 1.1 1.7l-3.6 6.6-8.6 14.9-38.4 21.9 0 0c-2.8 1.6-4.1 3.7-4.4 6-.3 2.3 .6 5.1 3.3 7.9 11.3 12 25.3 19.4 41.2 23.8 3.9 1.1 6.6 .7 8.3-.5 1.7-1.2 2.8-3.3 2.8-7.1v0l.1-44.4 9.5-16.5c-3.5-1-6.5-2.7-9.1-4.7l2.2-4.2c3.4 3 7.9 5.2 13.8 5.2 2.9 0 4.6-1.9 5-3.4 .2-.8 .1-1.3-.2-1.7-.3-.4-.8-.8-2.2-.9-7.8-.6-13.4-3.9-17.1-9.9-.7-1.2-1.2-1.4-1.7-1.4-.1 0-.1 0-.2 0zm58.5 9.8c-5.7 0-5.7 8.7 0 8.7s5.7-8.7 0-8.7zm-11.2 21.5c-8.8 0-8.9 13.5 0 13.5s8.8-13.5 0-13.5zm-58.8 2.1l2.3 4-34.1 19.8 0 0c-1 .6-1.2 1-1.3 1.3-.1 .3 0 .9 .5 1.8 .1 .2 .3 .5 .5 .8l-.1 0c4.5 6.8 13.6 15.5 22.3 20.2-5.9-2.6-12.7-6.3-18.2-10.2C17.3 101.9 14.1 99.1 12.4 96.1c-.8-1.5-1.3-3.3-.9-5.1 .4-1.8 1.7-3.3 3.5-4.3l34.1-19.8zm-22 22.2c4.6 1.6 13.2 6.3 20 11.5 3.4 2.6 6.3 5.2 8 8 .8 1.2 1.3 2.6 1.3 4.1l-5.2-2.4c-2.4-2.9-6-5.7-8.9-7.4-6.1-4.3-13.6-8.3-16.8-9.4l1.5-4.4z",
    "flail": "M39.4 3.7c-2 0-3.9 .4-5.7 1.3-1 .5-2 1.3-2.6 2.2a7 7 0 0 0-.4 0 7.3 7.3 0 0 0-1.7 .1c-4.4 .8-8.3 4.1-10 8.2-.5 1.4-.7 2.9-.3 4.3a7.4 7.4 0 0 0-.7 .8C14.9 23.9 13.9 28.9 15.3 33.2c.4 1.2 1.1 2.4 2.1 3.2-.7 4.4 1.1 9.1 4.4 12.1a7.3 7.3 0 0 0 1.4 .9c-.1 .3-.1 .7-.1 1 0 .1 0 .1 0 .2l4.5 3.3c-.4-1.1-.5-2.2-.5-3.2 0-.2 .1-.3 .1-.5a6.3 6.3 0 0 0 1.3-.3 6.2 6.2 0 0 0 2.2-1.4c.2 .1 .3 .1 .5 .2 2.3 1.7 4.1 5.3 3.9 8.2 0 .5-.4 1.3-.8 1.8l3.3 2.4c.9-1.1 1.4-2.5 1.5-3.9v0c.3-4.5-1.9-9.1-5.5-11.7a7.4 7.4 0 0 0-.9-.5c0-.1 .1-.2 .1-.4 .7-4.3-1-9.1-4.2-12 1.3-2.8 1.7-6.2 .9-9.2 2.6-1.2 4.8-3.2 6.2-5.7 3 1.1 6.4 1.1 9.4 0a14.1 14.1 0 0 0 .7 1.3l3.4-2.3a11.5 11.5 0 0 1-.7-1.2c.9-1 1.4-2.3 1.5-3.8a6.2 6.2 0 0 0-.3-2.1c.1 0 .2 0 .3 0 .5 0 1.1 .1 1.4 .3 1.2 .7 2.3 1.8 3.1 3l3.4-2.3c-1.2-1.7-2.7-3.2-4.5-4.2-1-.6-2.2-.9-3.3-.9a6.3 6.3 0 0 0-2.8 .6 7.4 7.4 0 0 0-.4-.3c-1.9-1.2-4.1-1.9-6.4-2a14.1 14.1 0 0 0-.8 0zm.2 4.1c1.6 0 3.3 .4 4.6 1.1-.5 1.1-.8 2.3-.7 3.5a12.4 12.4 0 0 0 .2 1.5c-2 .7-4.8 .7-6.9-.1 .1-1.5-.4-3.1-1.4-4.4a6.4 6.4 0 0 0-.4-.4c.2-.2 .4-.3 .6-.4 1-.5 2.1-.7 3.4-.8a11.4 11.4 0 0 1 .8 0zm-9.7 3.4c.1 1.8 .9 3.3 2.1 4.5-1 1.7-2.8 3.3-4.7 4.2-.8-.8-1.9-1.4-3.1-1.6a6.3 6.3 0 0 0-.9-.1 6.2 6.2 0 0 0-.8 0c0-.4 0-.8 .1-1.1 1-2.7 4.2-5.2 7-5.8 .1 0 .2 0 .2 0zm28.6 3.7l-9.2 6.4 6.4 9.2 9.2-6.4-6.4-9.2zM20.8 23.2c1.3 1 3 1.4 4.6 1.3 .5 1.9 .2 4.3-.7 6.3a6.3 6.3 0 0 0-1.4-.1c-.6 0-1.2 .1-1.8 .4a6.2 6.2 0 0 0-2.3 1.4c-.1-.2-.2-.3-.2-.5-.9-2.7-.1-6.6 1.7-8.8zm46.3 4.1l-9.2 6.4 50.5 71.8c4-1.1 6.7-3.5 9.1-6.5L67.2 27.3zm-41.1 8.7c1.8 2 3 5.4 2.6 8a1.7 1.7 0 0 1-.1 .3 6.2 6.2 0 0 0-3.5 1.7c-.3-.1-.5-.2-.7-.4-1.9-1.7-3.2-4.9-3.2-7.6 1.9 .1 3.6-.7 4.8-2zm27.5 14l-8.1 10c2.9 .4 5.7 1.2 8.4 2.5l-.3-12.5zm-33.1 3.7l5.3 22.7c5.4 1.4 12.6-2.5 13.5-8.9l-5.6-4.1c0 0 .1 0 .1 0l-8-5.8-5.2-3.8zm21.4 9.1c-1.2 0-2.4 .1-3.6 .3 1.4 1 2 1.5 4.1 2.8l-.1 1c-.5 9.3-10.6 14.9-18.3 12.1l-.8-.3-.2-.8-1-4.2a24.3 24.3 0 0 0-1.2 2.2C14.9 87.7 19.6 102 31.4 107.9a24.3 24.3 0 0 0 1.8 .8l-2.9-6.2-.3-.7 .4-.7c3.6-5.9 12.2-8.3 18.7-5.1a13.3 13.3 0 0 1 4.1 3.2l.5 .6-.2 .8-2.2 8c5-2.1 9.4-6 12-11.3a24 24 0 0 0 1.7-4.3l-1.3 1-.6 .5-.8-.3c-7.8-2.8-11.9-13.6-6.3-21l.6-.6 .7 0 4.2 .3c-2.2-3.1-5.1-5.7-8.7-7.5l0 0c-3.5-1.8-7.2-2.6-10.9-2.5zm-23.7 11.7l-13.8 .8 11.1 8.5a26.7 26.7 0 0 1 2.7-9.1c0 0 0-.1 0-.1h0zm39.8 1.1c-3.4 5.4-.4 13.1 4.7 15.4l18.6-14-23.2-1.4zm-15.1 22.1c-3.7 0-7.4 1.6-9.4 4.4l10.5 22.3 6.5-23.7c-.8-.8-1.7-1.4-2.7-1.9-1.5-.7-3.2-1.1-4.9-1.1zm22.3 2.7a26.6 26.6 0 0 1-6.3 7.3l12.9 5.1-6.6-12.3zM20.1 101.9l-5.5 14 12.8-6.8a26.6 26.6 0 0 1-7.3-7.1zm100 .5c-2.4 2.7-5.3 5.2-9.1 6.5l3.5 5c4.5-.5 7.3-2.6 9.2-6.4l-3.6-5.1z",
    "fountain": "M72.2 4.1c-5.8 5.5-10.1 12-12.6 19.5-2.3-4.6-5.5-8.8-9.4-12.5 2.4 5.8 4.1 12.1 4.9 18.4-5.3-6-12.6-9.3-21.8-10 5.2 3 9.6 6.9 12.9 11.7-10.5-3.4-21.3-3.8-32.7-1.3 7.1 .7 14 2.1 20.3 4.4-9.4 1.1-18.6 3.9-27.6 8.5 9.8-1.6 19.6-1.9 28.9-.9-12.4 6.3-22.6 15.7-30.5 28.1 7.1-5.9 14.8-10.8 22.7-14.5-6.2 10.8-9.6 23-10.3 36.3 2.8-7.6 6.4-14.8 10.6-21.3-1.9 10.4-1.6 21.2 .8 32.2 1.3-13 4.6-25.5 10.1-36.1 .2 8.2 1.6 16.4 4.5 24.7-.2-11.9 2.4-24.1 7.4-34.1 12.9-15.7 12.5 54.5-12.5 66.3H92.9c-25.1-11.8-25.7-77.3-16.2-66.4 5.1 10.1 7.7 22.2 7.5 34.1 2.8-8.3 4.3-16.5 4.5-24.7 5.5 10.7 8.9 23.1 10.1 36.1 2.4-11 2.7-21.8 .8-32.2 4.2 6.5 7.8 13.7 10.6 21.3-.6-13.3-4-25.5-10.3-36.3 7.9 3.7 15.5 8.6 22.7 14.5-8-12.4-18.1-21.7-30.5-28.1 9.3-1 19.1-.7 28.9 .9-9-4.6-18.2-7.4-27.6-8.5 6.4-2.3 13.2-3.7 20.3-4.4-11.4-2.5-22.3-2.1-32.7 1.3 3.2-4.7 7.7-8.6 12.9-11.7-6.7 .5-12.5 2.4-17.1 5.7 4.8-6.3 10.6-11.9 16.8-16.7-10.1 2.4-18.8 7.1-26.2 14.2 .9-6.4 2.7-12.7 5.1-18.6z",
    "gem-necklace": "M6.6 4.7c-1.3 3.4 .5 8.1 5.4 8.1 .3 0 .5 0 .8 0-3.6 3-2.3 10.4 3.8 10.4 .8 0 1.5-.1 2.2-.4-1.8 3.5-.1 8.7 5.1 8.7 1.3 0 2.3-.3 3.2-.8-1.4 3.4 .4 8.2 5.3 8.2 1 0 1.9-.2 2.6-.5-.5 2.9 .9 6.2 4.3 6.8l-13.9 19.1 42.4 58.4L110.3 64.2 91.2 38c3.5-.6 5-3.8 4.5-6.7 .5 .1 .9 .2 1.5 .2 5.2 0 6.9-5.3 5.1-8.7 .6 .2 1.4 .4 2.2 .4 6.1 0 7.3-7.3 3.8-10.4 .3 0 .5 0 .8 0 4.9 0 6.6-4.7 5.4-8.1h-10.7c-.9 2.3-.3 5.2 1.5 6.8-.3 0-.5 0-.8 0-5.1 0-6.9 5.3-5.1 8.7-.6-.2-1.3-.4-2.1-.4-4.2 0-6.2 3.6-5.7 6.8-.5-.1-.9-.2-1.5-.2-2.5 0-4.2 1.3-5.1 3L74.6 15.1 67.8 5.8l-1.9 2.6-20.3 28c-.9-1.6-2.6-2.8-5-2.8-1 0-1.9 .2-2.6 .5 .6-3.2-1.3-7-5.7-7-1.3 0-2.3 .3-3.2 .9 1.3-3.4-.4-8.2-5.3-8.2-.8 0-1.5 .1-2.1 .4 1.8-3.5 .1-8.7-5.1-8.7-.3 0-.5 0-.8 0 1.9-1.6 2.4-4.5 1.5-6.8h-10.7zm68 18.4l9.6 13.2L81.5 46.3c-.7-.1-1.4-.2-2.1-.2-1 0-1.9 .1-2.8 .4l-5.1-19.1 3.1-4.3zm-6.6 9.1l4.4 16.3c-1.1 .8-2.2 1.9-3.1 3-.8 1-1.4 2.1-2 3.2l-11.2-6.3 11.8-16.2zm19.8 8.9l8.1 11.1-4.3 2.4c-.5-1.2-1.2-2.2-1.9-3.2-1-1.4-2.3-2.5-3.7-3.4l1.9-6.9zm-8.3 9.6c2.4 0 4.7 1.3 6.4 3.6 1.8 2.3 3 5.7 3 9.4 0 3.8-1.2 7.1-3 9.4-1.8 2.3-4 3.6-6.4 3.6-2.4 0-4.7-1.3-6.4-3.6-1.8-2.3-3-5.7-3-9.4 0-3.8 1.2-7.1 3-9.4 1.8-2.3 4-3.6 6.4-3.6zm-26 1.5l12.4 7c-.3 1.4-.5 3-.5 4.5 0 1.9 .2 3.7 .7 5.3L53.4 76.2l-8.7-12 8.7-11.9zm45.2 3.8l5.9 8.1-5.9 8.2-5.7-3.2c.4-1.7 .7-3.5 .7-5.3 0-1.6-.2-3.1-.5-4.5l5.6-3.2zm-30.9 17.5c.5 .9 1 1.7 1.6 2.5 1 1.3 2.1 2.4 3.4 3.2l-4.6 17.1-11.9-16.4 11.5-6.5zm23.5 0l4.7 2.6-8.2 11.3-2.1-7.7c1.5-.9 2.9-2.2 4-3.7 .6-.8 1.1-1.6 1.6-2.5zm-14.1 7.6c.8 .2 1.6 .3 2.4 .3 .6 0 1.2-.1 1.7-.1l2.9 11-9.5 13-3-4.1 5.4-20.1z",
    "gem-pendant": "M7.3 4.7c-.7 2.6 0 5.4 2 7.4 2.5 2.5 6.4 2.9 9.3 1.2 1.5 1.3 2.9 2.6 4.3 3.8-.1 .5-.1 .9-.1 1.4 0 4.3 3.5 7.8 7.8 7.8 1.2 0 2.4-.3 3.4-.8 1.4 1 2.9 1.9 4.4 2.9-.1 .5-.2 1.1-.2 1.7 0 4.3 3.5 7.8 7.8 7.8 1.9 0 3.6-.7 5-1.8l3.5 2c-.1 .4-.1 .8-.1 1.2v9.7L28.5 63.8v40l34.6 20 34.6-20V63.8l-26-15.1V39.2c0-.2 0-.5 0-.7 1.3-.8 2.7-1.5 3.9-2.2 1.3 1 2.9 1.6 4.7 1.6 4.3 0 7.8-3.5 7.8-7.8 0-.5 0-.9-.1-1.4 1.5-1 3-2 4.5-3.1 1 .5 2.1 .7 3.3 .7 4.3 0 7.8-3.5 7.8-7.8 0-.5 0-1-.1-1.4 1.3-1.1 2.7-2.3 4.1-3.5 2.9 1.4 6.5 .9 8.9-1.5 2-2 2.7-4.9 2-7.4h-5.1c1 1.2 .9 3-.2 4.1-1.2 1.2-3.1 1.2-4.4 0-1.1-1.1-1.2-2.9-.2-4.1h-5.1c-.5 1.9-.2 3.9 .7 5.6-1 .9-2 1.8-3 2.6-1.4-1.3-3.3-2.1-5.3-2.1-4.3 0-7.8 3.5-7.8 7.8 0 1.4 .4 2.6 1 3.8-1.1 .7-2.1 1.5-3.2 2.2-1.4-1.4-3.3-2.2-5.4-2.2-4.3 0-7.8 3.5-7.8 7.8 0 .8 .1 1.6 .3 2.3-1.1 .6-2.2 1.3-3.3 1.9-.3-.2-.5-.5-.8-.7-1.7-1.2-3.7-1.7-5.7-1.8-2 0-4 .4-5.7 1.6-.2 .1-.4 .3-.6 .5-1.1-.6-2.2-1.3-3.2-1.9 .2-.6 .2-1.3 .2-1.9 0-4.3-3.5-7.8-7.8-7.8-2 0-3.8 .8-5.2 2-1.1-.7-2.2-1.4-3.3-2.1 .6-1.1 .9-2.3 .9-3.6 0-4.3-3.5-7.8-7.8-7.8-2.1 0-4 .8-5.3 2.2-1.1-1-2.3-2-3.4-3 .8-1.6 .9-3.5 .5-5.2H17.1c1 1.2 .9 3-.2 4.1-1.2 1.2-3.1 1.2-4.4 0-1.1-1.1-1.2-2.9-.2-4.1H7.3zm23.3 10.8c1.7 0 3.1 1.4 3.1 3.1s-1.3 3.1-3.1 3.1c-1.7 0-3.1-1.3-3.1-3.1 0-1.7 1.4-3.1 3.1-3.1zm65 0c1.7 0 3.1 1.4 3.1 3.1s-1.4 3.1-3.1 3.1c-1.7 0-3.1-1.3-3.1-3.1 0-1.7 1.4-3.1 3.1-3.1zM45.9 27c1.7 0 3.1 1.4 3.1 3.1 0 1.7-1.4 3.1-3.1 3.1-1.7 0-3.1-1.3-3.1-3.1 0-1.7 1.4-3.1 3.1-3.1zm34.3 0c1.7 0 3.1 1.4 3.1 3.1 0 1.7-1.3 3.1-3.1 3.1-1.7 0-3.1-1.3-3.1-3.1 0-1.7 1.4-3.1 3.1-3.1zm-17.3 9.5c1.2 0 2.3 .4 3 .9 .7 .5 1 1 1 1.8v6.9l-3.9-2.2-4.1 2.4V39.2c0-1 .3-1.5 1-1.9 .7-.5 1.8-.8 3-.8zm-2 14v8.2l-18.5 10.8-7.1-4.1 25.7-14.9zm4.7 .2l25.5 14.8-7.2 4.1-18.4-10.7 0-8.2zm-2.5 12.2l18.1 10.5 0 21.1-18.1 10.5-18.1-10.5 0-21.1 18.1-10.5zm.1 4.6l-14.2 24.5v.2l14.1 8.2L77.2 92.1v-16.5l-14.1-8.2zm-30 2.2l7.1 4.1v21l-7.1 4.1V69.6zm59.8 .2l0 28.9-7.2-4.1v-20.6l7.2-4.1zM83.4 98.5l7.1 4.1-24.9 14.4v-8.1l17.8-10.4zm-40.4 .1l18 10.5v8.1l-25.1-14.5 7.1-4.1z",
    "grave-flowers": "M64 10.2c-11.8 0-21.1 2-27.5 7.5C30.1 23.2 26.2 32.4 26.2 48v3.3l3.1 4.2 5.7-14 2.2 4.6s.7 1.4 1.6 3.6H52v4.5h-11.4c.8 2.2 1.5 4.8 2.1 7.5H60v4.5h-16.4c.7 4.2 .9 8.6 .1 12.7-.8 4.1-2.8 8.1-6.4 10.8 2.8 4 4.9 8 6.5 12.1h.9c3.9-4.6 9.5-8 14.2-10.6l2.5-1.4 .8 2.8c.9 3.4 1.5 6.5 1.7 9.2h9.7c0-.9 .1-1.8 .3-2.7 .3-1.6 .9-3.1 1.7-4.7-1.9-.5-3.6-1.1-5.2-1.9-3.3-1.6-6.1-4.1-6.5-7.4-.4-3.2 1.8-5.6 4.7-7 1.3-.7 2.8-1.1 4.4-1.5-1.1-1.4-1.9-2.9-2.6-4.3-.8-1.6-1.2-3.2-1.3-4.8-.1-1.6 .3-3.2 1.4-4.4 1.1-1.2 2.7-1.8 4.2-1.9 1.6-.1 3.2 .2 4.8 .8 1.4 .5 3 1.2 4.5 2.1 .1-1.8 .5-3.5 1.1-5 .8-2.2 2.2-4.1 4.1-4.9H60v-4.5h32v4.1c3.1 .3 5.7 2.8 7.6 5.7 .8 1.3 1.6 2.8 2.1 4.4V48c0-15.6-3.8-24.8-10.2-30.3C85.2 12.2 75.8 10.2 64 10.2zM36 37.8h36v4.5H36v-4.5zm44 0h12v4.5h-12v-4.5zM20.6 51.2l2.7 17.9L9.8 57.4l7.4 14.2-13-2c1.9 2.8 4.8 6.5 8.2 10 3.2 3.2 6.9 6.1 10.5 7.6 3.6 1.5 7 1.7 10.4-.2 3.5-1.9 5.3-5 6-8.9 .8-3.9 .5-8.6-.4-13.1-.9-4.6-2.3-8.9-3.5-12l-4.8 11.6-10-13.3zm71.6 7.5c-.8 0-2 .8-2.8 3-.8 2.2-1.2 5.6-.7 9.3 .1 .9 .3 1.7 .5 2.5 3.1-1.3 6.7-1.3 10.1 0 0-.7-.1-1.5-.2-2.3-.5-3.8-1.8-7.2-3.2-9.5-1.4-2.3-2.8-3.1-3.6-3.2zm-17.3 6.9c-.7 .1-1 .2-1.1 .4-.1 .2-.3 .5-.3 1.2 .1 .7 .3 1.8 .9 3 .8 1.7 2.1 3.6 3.8 5.6 .5 0 1 0 1.5 0 1.9 .1 3.7 .3 5.5 .6 0-.1 .1-.1 .1-.1 .1-.1 .1-.1 .2-.2-.6-1.8-1-3.7-1.3-5.7-.1-.3-.1-.7-.1-1-2.1-1.5-4.2-2.6-6-3.3-1.1-.4-2.1-.6-2.9-.6h-.3zm35.2 1c-.7 0-1.4 .1-2.2 .4-1.4 .5-3 1.3-4.5 2.5 .1 .5 .1 .9 .2 1.4 .2 1.9 .3 3.7 .2 5.4 .1 .1 .2 .2 .4 .3 .1 .1 .2 .2 .3 .3 1.5-.2 3.1-.3 4.9-.2 .7 0 1.3 .1 2 .1 1.1-1.7 1.8-3.4 2-4.8 .5-2.3 .1-3.9-.8-4.7-.6-.5-1.4-.8-2.5-.8zm-16.1 10.5c-2.1 0-4 .8-5.4 2.3-2.8 3.1-2.2 8.7 1.9 12.4 4.2 3.8 9.8 3.8 12.6 .6 2.8-3.1 2.2-8.7-1.9-12.4-2.2-2-4.8-2.9-7.2-2.9zm-14.4 3.2c-3.5 0-6.5 .7-8.6 1.7-2.1 1.1-2.8 2.3-2.7 3.1 .1 .8 1.1 2.1 3.5 3.3 2.4 1.2 6 2.1 9.8 2.2 .8 0 1.6 0 2.3-.1-1.6-3.2-2.1-6.8-1.1-10-.8-.1-1.7-.2-2.6-.2-.2 0-.5 0-.7 0zm29.7 .8c-.5 0-1.1 0-1.6 .1 1.6 3.2 2.1 6.8 1.1 10 .8 .1 1.7 .2 2.6 .2 3.8 .1 7.1-.6 9.2-1.6 2.1-1.1 2.8-2.3 2.7-3.1-.1-.8-1.1-2.1-3.5-3.3-2.4-1.2-6-2.1-9.8-2.2-.2 0-.5 0-.7 0zm-76 10.6c-2.4 .9-4.7 1.1-7 .8V101.8h12.7c-1.4-3.4-3.3-6.7-5.6-9.9zm53.9 3.1c-1.5 .2-3.2 .3-4.9 .2-.7 0-1.3-.1-1.9-.1-1.1 1.7-1.7 3.4-2 4.8-.5 2.3 0 3.8 .8 4.6 .9 .8 2.4 1.1 4.7 .3 1.4-.5 3-1.3 4.6-2.5-.1-.6-.2-1.3-.3-1.9-.2-1.7-.3-3.4-.2-4.9-.1-.1-.2-.2-.3-.3-.1-.1-.2-.2-.3-.3zm19.3 .5c0 .1-.1 .1-.1 .1-.1 .1-.1 .1-.1 .1 .5 1.7 .9 3.5 1.2 5.3 .1 .5 .1 1 .1 1.5 2.1 1.6 4.2 2.6 6 3.2 1.3 .5 2.4 .6 3.1 .6 .8 0 1-.2 1.2-.4 .1-.2 .3-.5 .2-1.2 0-.8-.3-1.8-.9-3.1-.8-1.7-2.1-3.6-3.8-5.6-.5 0-1 0-1.5 0-1.9-.1-3.7-.3-5.5-.6zm-47.9 1.1C54.1 99.2 49.5 102.5 47 106.1c-1.5 2.2-2.2 4.4-2 6.8 .1 2.1 1.1 4.5 3 7.2 4.9-3 8.3-5.7 10-9.1 1.7-3.4 2.1-7.8 .6-14.4zm33.8 1.7c0 .8 .1 1.5 .2 2.3 .5 3.8 1.8 7.2 3.2 9.5 1.4 2.3 2.8 3.1 3.6 3.1 .8 0 2-.8 2.8-3 .8-2.2 1.2-5.6 .7-9.3-.1-.9-.3-1.7-.5-2.5-3.1 1.3-6.8 1.2-10.1-.1zM10.2 106.2v15.5h33c0-.2 0-.4 0-.6-1.6-2.7-2.5-5.3-2.7-7.8-.1-1.9 .1-3.7 .7-5.3-.1-.6-.3-1.1-.5-1.7H10.2zm53.6 0c-.2 2.5-.8 4.8-1.9 6.8-1.8 3.5-4.6 6.2-8.2 8.7h27.2c-.3-4.4 1.2-8.6 3.7-12.4-3.1 .8-6.3 .6-8.6-1.4-.6-.5-1-1-1.4-1.6h-10.8zm43.7 1.6c-.2 1.7-.5 3.2-1 4.5-1.1 3-3.3 5.5-6.5 5.3-3.3-.1-6-2.6-8-5.8-.6-.9-1.1-1.9-1.6-2.9-3.4 4.4-5.3 8.6-4.8 12.8H117.8v-11.1c-.2 .1-.5 .1-.8 .1-1.6 .1-3.2-.2-4.8-.8-1.5-.5-3-1.2-4.6-2.2z",
    "hammer-break": "M54 15.9l-12.4 11.2 25.4 28.2 6.1-5.5c-2.1-2.4-3.9-4.6-4.9-7.2-1.1-3-.9-6.3 .5-10.3l-14.7-16.3zm56.5 4.1l-22 19.6-2.6-9.6-9 23.2s10.3-2.9 15.5-4.4v8.2l30.6-19.9-23.8 6.2 11.3-23.3zM46.8 39.6L6 76.4l5.5 6.1L52.3 45.7l-5.5-6.1zm16.4 24.1v9.2l13.4 14-1.6 5.8 14.3 14.3-3.2 3.2-3-3-12.1 6.8-2.2-3.9 10.9-6.2-6.2-6.2-1.6 5.8-4.3-1.2 4-14.1-8.3-8.7V123.2h59.5V63.8H87.1l4.7 11.1 13.7 1.6 9.7-8.7 3 3.4-4.3 3.9 3.2 9.5-4.2 1.4-2.6-7.7-3.3 3-13.2-1.5 4.6 10.8-5.8 7.7-3.6-2.7 4.2-5.7-7.4-17.4-6.1 3.8-2.4-3.8 6.7-4.1 .1 .2-2-4.7h-19.1z",
    "hand-of-god": "M96.8 4.8c-.2 6.1-2 12.3-5.5 18-9.2 14.8-27.7 21.5-44.7 17.7 1.1-.5 2.1-1 3-1.6 9.8-5.6 14.3-13.9 13.6-22.9-1.8 5.5-6.2 10.3-12.6 14-12 6.9-29.5 7.9-46.9 4.2v9.3c9.1 3.3 20.5 3.2 30.6 1 .8 .5 1.6 1 2.5 1.5 19.1 10.2 43.5 4.4 55-13 10.1 3.7 21.2 5 31.8 4.1v-9.8c-9.2 .9-18.8 .2-27.8-2.3 2.4-6.7 2.6-13.7 1-20.3zm7.6 40c-7.1 3.1-14.8 3.5-21.9 2.6-4.8 2.7-10.4 4.7-16.2 5.8-11 2.3-23 1.7-32.4-3.5l19.6 44c2.8 3.1 6 6.4 10.5 10.3l0 0 0 0c.4 .4 .7 .5 1.3 .4 .6-.1 1.5-.4 2.3-1 .8-.6 1.6-1.4 2.2-2.1 .3-.4 .5-.8 .6-1.1l-9.9-9.6 3.2-3.4 11.4 11 0 0c.1 .1 0 .1 .6 0 .5-.1 1.4-.5 2.3-1.1 1.5-1.1 3-2.9 3.6-4.1l-9.8-9.5 3.2-3.4 11.3 10.9c2.9-.7 5.3-2.7 6.3-5.1l-12.5-12.1 3.2-3.4 26.5 25.5c1.3 1.2 2.3 1.5 3.3 1.5 .9 0 1.8-.5 2.5-1.2 1.3-1.4 1.9-3.5-.5-5.8l-36.7-35.4 3.2-3.4 5.8 5.6c6.5-.7 11.9-2.5 15.2-4.6 1.8-1.1 2.9-2.3 3.5-3.3 .5-1 .6-1.6 .2-2.5-.3-.7-.9-1.5-2.1-2.4z",
    "harpoon-chain": "M4.5 4.5V7.9l1.7 1.7c-.7 1.2-1 2.6-1 4C5.2 18.2 8.9 22 13.5 22c1.5 0 2.8-.4 4-1l3.6 3.6c-.7 1.2-1 2.6-1 4 0 4.6 3.8 8.3 8.3 8.3 1.5 0 2.8-.4 4-1l3.4 3.4c-.7 1.2-1 2.6-1 4 0 4.6 3.8 8.3 8.3 8.3 1.5 0 2.8-.4 4-1.1l3.7 3.7c-.7 1.2-1 2.6-1 4 0 4.6 3.8 8.3 8.3 8.3 1.5 0 2.8-.4 4-1l3.7 3.7c-4.2 2.9-9.7 3.2-14.1 .8 8.6 12.4 47 13 7.2 34.3l64.9 19.7-19.7-64.9c-21.1 39.5-21.9 2-34-7 2.2 4.4 1.9 9.7-1 13.8l-3.7-3.7c.6-1.2 1-2.5 1-4 0-4.6-3.8-8.3-8.3-8.3-1.4 0-2.8 .4-4 1l-3.7-3.7c.6-1.2 1-2.5 1-4 0-4.6-3.8-8.3-8.3-8.3-1.4 0-2.8 .4-4 1l-3.5-3.5c.6-1.2 1-2.5 1-4 0-4.6-3.8-8.3-8.3-8.3-1.4 0-2.8 .4-4 1L20.8 17.6c.6-1.2 1-2.5 1-4 0-4.6-3.8-8.3-8.3-8.3-1.4 0-2.8 .4-4 1l-1.8-1.8H4.5zM13.5 10c2 0 3.7 1.6 3.7 3.7 0 2-1.6 3.7-3.7 3.7-2 0-3.7-1.6-3.7-3.7 0-2 1.6-3.7 3.7-3.7zm14.9 14.9c2 0 3.7 1.6 3.7 3.7 0 2-1.6 3.7-3.7 3.7-2 0-3.7-1.6-3.7-3.7 0-2 1.6-3.7 3.7-3.7zm14.8 14.8c2 0 3.7 1.6 3.7 3.7 0 2-1.6 3.7-3.7 3.7s-3.7-1.6-3.7-3.7c0-2 1.6-3.7 3.7-3.7zm15 15c2 0 3.7 1.6 3.7 3.7 0 2-1.6 3.7-3.7 3.7-2 0-3.7-1.6-3.7-3.7 0-2 1.6-3.7 3.7-3.7zm43.6 20.2l9.3 30.7-23.8-23.8c7.3 1.8 12.6-1.2 14.4-6.9zm-20.2 12.7l23.8 23.8-30.7-9.4c5.7-1.9 8.7-7.1 6.9-14.5z",
    "hawk-emblem": "M10.9 4.6l19.5 20.8-25.9-13.1v5.2l27.7 14-27.7-4.7v4.7l26.1 4.4-26.1 3.1v4.7L31.5 40.6 4.5 51.2v5l28.3-11.1L4.9 64.1l-.4-.2v5.3c16.5 8.6 33.1 11.6 44.8 8 1 3.1 2.3 5.9 4 8.3l-24.7 37.9h5.6l21.7-33.3-12.8 33.3h5l11.8-30.7-4.2 30.7h4.7l4.2-30.8 4.2 30.8h4.7l-4.2-30.7 11.8 30.7h5L73.4 90.2l21.7 33.2h5.6l-24.7-37.9c1.7-2.3 3.1-5.1 4.1-8.3 11.3 3.5 27.3 .7 43.3-7.3v-6.1L95.9 45.1l27.5 10.8v-5l-26.2-10.3 26.2 3.1v-4.7l-25.3-3 25.3-4.3V27l-26.2 4.4 26.2-13.2V13L97.1 26.2l20.2-21.6h-6.4l-21.8 23.3 2.6 2.4 .3 .8c.6 1.6 .9 3 .9 4.6 0 7-5.6 13.5-14.4 16.9-3.7-4-5.2-8-4.9-10.1 .2-1.1 .5-1.7 1.6-2.2 1.1-.5 3.2-.8 6.2-.3l2.7 .5 0-2.8c0-5-1.1-9-3.7-11.7-2.6-2.7-6.4-3.8-10.8-3.9h0c-5.4-.1-12 1.1-20.2 3.1l-3 .8 1.5 2.7c4.5 7.7 5.1 11.4 4.7 14.5-.4 2.5-1.7 5.1-2.8 9.1-8.3-3.6-13.6-9.8-13.6-16.5 0-1.4 .4-2.8 1-4.5l.7-1.9c1.1-1.4 .8-1.1 1.1-1.4l-21.8-23.3zm57.8 22.2c.3 0 .5 0 .8 0h0c3.8 .1 6.1 1 7.6 2.5 1.1 1.2 1.9 3 2.2 5.8-2.4-.1-4.4 .2-6.1 1-1.8 .8-3.1 2.3-3.8 4.1-2.2-2.5-3-4.9-3.3-7.7-7.6 3.4-9.6-3.1-3.3-5.1 2.2-.3 4.2-.5 5.9-.5zm.1 16.2c-.1 3.7 1.7 7.6 4.9 11.4-6.9 2.1-13.9 2.3-19.7 0 1-3.8 2.4-6.4 3.1-9.9 3.1 1 8.3 .8 11.7-1.5zm-32.8 5.6L19.3 70.4c-3.2-1.1-6.4-2.4-9.7-3.9zm56.6 0L119.3 66.7c-3.3 1.5-6.6 2.8-9.8 3.9zm-53.3 3.4l-7.5 21.5c-2.5-.3-5.1-.9-7.8-1.6zm50 0l15.3 20c-2.7 .7-5.3 1.2-7.8 1.5zm-46.3 3.5l-.4 18.3c-1.9 .2-3.9 .2-6 .1zm42.6 0l6.4 18.4c-2.1 .1-4.2 0-6-.2zm-37.9 .9c1 .4 2 .8 3 1.2l1.4 .5-.4 13.3-1.8 .7c-.8 .3-1.7 .6-2.6 .9zm33.3 .3l.3 16c-.7-.2-1.3-.4-1.9-.7L76.8 71c-.8-.1 .5-12.9 .5-12.9l1.4-.5c.8-.3 1.6-.6 2.3-.9z",
    "heart-beats": "M91.7 7.5c-.3 0-.5 0-.8 0h0c-10.4 .1-20.9 5.5-27.7 17.3-10.5-29.4-59.1-19.1-58 16.1 .2 5 1.3 9.7 3.1 14.2h19.1l5.3-18.5 6.6 22.5 4.6-16.1 4.3 12.1H82l5.3-18.5 6.6 22.5 4.6-16.1 4.3 12.1h18.1c1.8-4.5 2.7-9.3 2.6-14.2-.7-20.8-16-33.3-31.9-33.4zM32.8 52.8l-2 6.8h-20.4c13.6 25.8 49.4 43.1 54 60.3 4.2-15.7 41.3-34.9 54.5-60.3h-19.3l-.7-1.9-5 17.6-6.6-22.5-2 6.8H45.1l-.7-1.9-5 17.6-6.6-22.5z",
    "herbs-bundle": "M119.5 5.9c-2.8 .1-5.9 .4-8.7 .9-4 .8-7.6 2.1-9.5 3.5-.2 .6-.2 1.3-.2 1.8 0 .5 .1 1.1 .2 1.7 3.3-2.5 7.4-3.9 11.5-5.2-3.6 2.5-6.7 5.2-9.6 7.9 2 .9 4.4 .9 6-.2h0c3.4-2.4 7.8-6.4 10.2-10.3zm-74.5 .9c-.7 0-1.4 .1-2.1 .2-.5 2.4-.2 4.7 .7 6.4-2.2-.9-5-.7-7.7 1.6 1.7 5.7 6.7 8.2 11.9 5.7 .1 2.4 .2 4.7 .2 7.1-1.6-1.8-4.3-3.4-7.1-3.3-1.9 .1-4 1-5.8 3.2 2.8 5.2 8.2 6.7 12.8 3.1-.1 2.6-.2 5.2-.4 7.8-1.5-2.1-4.2-4.1-7.3-4.1-1.4 0-2.8 .5-4.2 1.4 4 1.1 7.7 2.7 10.9 4.9 1.2 .8 1.9 2 2.2 3.1 .3 1.2 .4 2.4 .4 3.6-.1 2.5-.7 5.2-1.6 7.5l-.3 .8-.7 .4c-.5 .3-1.1 .6-1.6 .8-.5 3.2-1.1 6.4-1.7 9.7-3.7-4.5-7.4-6.2-11.1-6.2-9.4-.1-18.6 10.3-27.2 10.5 11.6 .8 29.7-11 36 2.9 4.7 3.5 9.5 6.3 14.4 8.4 .4-2.4 1.1-4.8 1.9-7 .6-1.4 1.2-2.7 2-3.8 .8-1.1 1.8-2.1 3.4-2.5 .4-.1 .9-.2 1.3-.3-1.4-2.6-1.2-6.2 .4-9.1 1.6-3 4.6-5.1 7.6-5.3 3.1-4.7 6.3-9.3 9.8-13.8 2.6 5.6 8.5 6.7 13.3 2.7-1.2-4.5-4.5-6-7.6-5.9-1.4 0-2.8 .4-4 .9 4.9-6.4 10.2-12.5 15.8-18.4-2-.9-2.2-1.6-2.7-3.7-5.8 6-11.1 12.2-16.1 18.7-.1 4-2.4 7.5-6.2 8.3h-.1C72.3 46.6 70 50 67.8 53.5c.6-3.7 1.1-7.5 1.9-11.3-1.8-1.1-3.1-3-3.9-5.1-2.4 7.6-4.1 15.7-6.3 22.7-.3-.1-.6-.1-.9-.1-4 0-7.4 3.4-8.3 6 3 2.6 6.3 3.1 9.1 1.9-1 1.8-2.1 3.7-3.1 5.5-.9-.4-1.8-.6-2.7-.6-2.9 0-5.5 1.8-7 3.7 1.7-8.2 3.3-16.4 4.4-24.6 4.6 2.3 9.4 .3 11.5-4.9-1.8-1.9-3.7-2.6-5.5-2.6-2 0-3.9 .8-5.3 2 .3-2.8 .6-5.7 .8-8.5 4.7 4.6 10.8 3.4 13.8-2.3-1.8-2.2-3.8-3.1-5.8-3.2-3.4-.1-6.6 2.3-8 4.5 .1-2.7 .2-5.3 .2-8 5.1 2.4 10.1-.1 11.7-5.8-1.8-1.5-3.6-2.1-5.2-2.1-2.7 0-5 1.7-6.5 3.7-.1-1.8-.1-3.5-.3-5.3 5.8 1.9 10.6-1.6 11.1-7.7-5-2.7-8.8-.2-10.7 3-.5-3.5-2.8-7.7-7.6-7.7zm44.5 3.5c-9.2 1.5-14.9 7.1-18.9 14.5l.6-.1c1.3-.2 2.6-.1 3.8 .3 3-6 7.5-11.1 14.6-14.7zM122.5 26.2c-11.8 17-27.7 24.2-43.3 32 1.3 2.6 1.1 6.1-.4 9v0c16.4-10.2 33.2-19.9 43.7-41.1zm-22.4 1.1c-4-.1-7.4 3.4-8.3 6 5.2 4.5 11.3 2.7 13.8-3.3-1.8-1.9-3.7-2.6-5.5-2.6zm-27.8 1.7c-.1 0-.2 0-.3 .1-1.6 .3-3 2.5-2.4 5.5 .6 3 2.8 4.5 4.3 4.2 1.6-.3 3-2.5 2.4-5.5-.6-2.8-2.5-4.3-4-4.2zM21.2 38.6c-.4 0-.8 0-1.1 0 2.3 6.3 4.9 11.7 10.2 15h0c3.5 2.2 7.8 1.6 11.5 .2l-10.6-8.8 13.2 7c.4-2.2 1.7-5.2 .3-7.3h0v0c-6.1-4-13.8-6-23.5-6.1zm51.7 20.3c-1.4 .1-3 1-4.1 3-1.4 2.6-.7 5.2 .7 6 2.1 .9 4.5-1.2 5.3-2.7 1.4-2.6 .7-5.2-.7-6-.3-.2-.8-.3-1.2-.3zm-.8 13.6c-.4 0-.8 0-1.1 0-2.3 .1-4.5 .5-6.8 1h0c0 0-.4 .2-.8 .8-.5 .7-1 1.6-1.5 2.8-.7 1.6-1.2 3.6-1.6 5.4l16-2.5-13 5.2c1.4 2 1.7 2.8 2 4.3 2.1 1.3 4.3 1.9 7 1.2 6.9-1.6 12.3-7.2 18-13.9-6.5-3-12.6-4.4-18.3-4.4zm-34.3 4.5l-2.2 5.7c8.2 3.6 15.2 7.8 21.8 12l3.1-5.7c-8-2.5-15.5-6.6-22.7-12.1zm-3.1 10.2c-5.2 6.8-11.5 12.8-18.7 16.2l2 4c8.3-4 15.2-10.8 20.9-18.3-1.4-.7-2.8-1.4-4.2-2zm5.1 2.4c-5.9 10.5-11.6 18-17.6 29l4 2.1c5.8-10.7 11.5-18.2 17.6-29.1-1.3-.7-2.6-1.4-4-2.1zm6.5 3.5c-6.2 9.4-10.6 17.1-14.9 27.1l4.1 1.8c4.3-9.8 8.6-17.2 14.7-26.6-1.3-.8-2.5-1.6-3.9-2.3zm5.8 3.4c-3.9 6.5-4.3 14.2-5 20.1l4.5 .5c.7-6 1.3-13.1 4.3-18.3z",
    "holy-symbol": "M64.4 5.9c-16.6 0-30 13.4-30 29.8 0 4.7 1.1 9.2 3.1 13.1h0l.5 .9c.1 .1 .1 .2 .2 .3l11.3 21-22.4-11.9v53.6l15.3-8.2 19.4-40.5c-4.3-8.2-12.1-24.1-12.1-30 0-8.1 6.6-14.8 14.9-14.8 8.2 0 14.9 6.6 14.9 14.8 0 7.7-13 31.7-14.6 34.5L49.2 100.9l.1-.1-.7 1.3-10 20.9h52.7l-12-22.2 22.4 11.9v-53.6l-15.4 8.2-24.1 41.7h10.5v4.7h-18.6l2-3.5 30.7-52.9 4-7.4 .6-1.1h0c2-4 3.1-8.4 3.1-13.1 0-16.5-13.4-29.8-30-29.8zm0 18.2c-5.5 0-10 4.4-10 9.9 0 5.5 4.4 9.9 10 9.9 5.5 0 10-4.4 10-9.9 0-5.5-4.4-9.9-10-9.9z",
    "holy-water": "M75.1 9.8c-.6 0-1.3 .3-1.8 .8-.5 .5-.9 1.1-.9 1.7-.1 .6 0 1.2 .8 2l1.5 1.7 10.1 11.1 1.5 1.7c.7 .8 1.3 1 1.9 1 .6 0 1.3-.3 1.8-.8 .5-.5 .9-1.1 .9-1.7 .1-.6 0-1.2-.8-2L77 10.8c-.7-.8-1.3-1-1.9-.9zm-3.8 9.2l-9.7 8.7-1.5-1.7c-5.8-6.4-9.1-6.7-13.3-6.9L5.8 56.3 37.8 91.6 78.8 54.4c.2-4.1 .2-7.5-5.5-13.9l-1.5-1.7 9.7-8.7-10.1-11.1zm-28 13.6l8.5 9.3 9.3-8.5 4.9 5.4-9.3 8.5 8.5 9.3-5.4 4.9-8.5-9.3-23.8 21.6-4.9-5.4 23.8-21.6-8.5-9.3 5.4-4.9zm49.3 1.1s-6.5 13.2-4 18.5c1.6 3.3 6.4 3.3 8 0 2.5-5.3-4-18.5-4-18.5zm.5 25.8l-1.4 11.6c.3-.1 .6-.1 1-.1 .6 0 1.1 .1 1.6 .3l-1.1-11.8zm-14.7 3.8l7 16.5c.6-1.5 1.3-2.8 1.9-4l-9-12.6zm29.4 .4l-9.3 12.4c.7 1.2 1.3 2.5 1.9 3.9l7.4-16.3zM67.5 73.8l15.8 11.9c.1-.5 .3-1.1 .5-1.6 .3-.9 .6-1.7 .9-2.5l-17.2-7.8zm50.9 .6l-17.3 7.3c.3 .8 .5 1.6 .8 2.4 .2 .6 .3 1.1 .5 1.7l16-11.4zm-25.6 1.2c-.4 .4-.9 1.1-1.4 2-1.1 1.9-2.4 4.7-3.3 7.7-.9 3-1.5 6.2-1.5 9 0 2.8 .6 5 1.7 6.3 .6 .7 2.5 1.5 4.4 1.5 1.9 0 3.8-.7 4.4-1.5 1.1-1.3 1.8-3.6 1.8-6.3 0-2.8-.5-6-1.4-9-.9-3-2.1-5.8-3.2-7.7-.6-.9-1.1-1.7-1.5-2.1zm-9.7 10.9l-19.8 1.9 18.9 2.3c.2-1.4 .5-2.8 .8-4.2zm19.4 .3c.3 1.4 .6 2.8 .7 4.2l18.9-1.8-19.6-2.4zm-20.4 5.7l-15 10.7 15-6.4c-.1-.8-.1-1.5-.1-2.3 0-.7 0-1.3 .1-2zm21.3 .4c0 .6 0 1.1 0 1.6 0 .9-.1 1.8-.2 2.6l14.7 6.7-14.6-11zm-20 8.7l-5.7 12.5 7.5-10c-.1-.1-.2-.3-.4-.4-.6-.7-1-1.4-1.4-2.2zm18.3 .4c-.4 .6-.8 1.3-1.3 1.8-.2 .2-.4 .4-.6 .6l7.2 10.1-5.3-12.5zm-10.5 4.8l1.1 11.5 1.4-11.5c-.4 0-.7 0-1.1 0-.5 0-1 0-1.4-.1z",
    "hooded-assassin": "M83 16.5c-7.2 0-13.9 3.5-17 10.2 5.2 .4 4 13.8 4 13.8-3 4.2-6.2 8.3-9.1 12.5 0 0-24.8 33.1-44.6 42-7 5.6-8.3 9.1-11 13.2-1.2 2.4 2.3 3.6 2.9 3.3 5.7-2.6 6.3-5.2 11.8-8.9 3.2-1.3 6-4 8-2.8 8.7 5.2 26.9 11.1 29.6 9.7 4.5-2.3-1.4-10.9 4-22.3 8-.8 14.7-.2 22.1-3 .9 12.6 2.5 13.6 1.7 26.8l17.8 .3 .2-3.7-10.5-2.8c2.9-14 3-19.7 1.2-32-.2-1.7-13.4-2.1-20.3-.9 6.1-6.1 10.1-11.3 11.9-17.1l0 0c1.9 4 7.5 8.5 8.8 9.3 6.9 2.8 9.6 2 15.7 1 1.2-.2 6.9 6.1 11.2 2.4 .7-5.1 4.1-5.1-1.2-8.2-1.2-.7-6.8 1.9-7.9 1.7-5.1-.6-7.7-1.3-14.6-3.2-2.6-3.3-8.2-14-13.9-14.9 1.6-3.5 7.1-13.3 18.4-16.6-5.2-6.6-12.5-9.8-19.2-9.8zm20.6 11.7c-11.7 4.9-14.6 12.6-14.6 12.6l2.5 1.9s2.4-1.2 12.1-14.5zm5.8 40l-1.2 2.9c1.3 0 2.6 .1 3.8 .4-3.2 7.7-6 14.9-7 23.3l-.2 1.9 1.2-1.5c5.2-6.4 8.1-13.8 11.2-21.4 1.1 .7 2.1 1.5 3 2.3l1.2-2.8-5.1-2.1-7.9 16.6 6-17.4-5-2.1z",
    "hourglass": "M23.2 4.8v10.4h82.9v-10.4H23.2zM29.9 19.8V108.4h5.6V19.8H29.9zm11.6 0c.8 10.8 3.3 20.5 6.9 27.7 4.4 8.8 10.2 13.7 16 13.7 5.8 0 11.6-4.9 16-13.7 3.6-7.2 6.1-16.9 6.9-27.7H41.5zm52.3 0V108.4h5.6V19.8h-5.6zm-29.3 46.3c-5.8 0-11.6 4.9-16 13.7-3.7 7.4-6.3 17.4-7 28.6H87.5c-.7-11.2-3.3-21.2-7-28.6-4.4-8.8-10.2-13.7-16-13.7zM23.2 113.1v10.4h82.9V113.1H23.2z",
    "knife-thrust": "M11.9 4.8c-.1 0-.2 0-.3 0-1.5 .1-3.1 .7-4.3 2-2.5 2.5-2.6 6.2-.4 8.4 1 1 2.3 1.5 3.7 1.5l.8-.8L16.9 10.4l.4-.4c0-1.4-.6-2.7-1.5-3.7-1-1-2.4-1.5-3.8-1.5zm7.1 10.1L15.8 18.1c3.4 8.3 9.3 14.1 16.9 18.4l4.7-4.7C32.6 24.3 26.5 18.5 19 14.9zm32.3 9.6L25 50.8l6 6c7.4-10.2 16.4-18.8 26.4-26.3l-6-6zm3.2 14.1c-5.6 4.7-10.8 9.8-15.5 15.4 8.5 11 19.1 20.7 30.6 28.1-5.2 .4-10.1 .3-14.6-.3 8.5 6.2 17.8 11.4 27.6 15.3-7.1 .7-13.6 .6-19.7-.3 18.1 13.2 38.9 22.8 60.8 26.9-5.1-23.7-14.5-44.6-27.5-62.3 .9 6.2 1.1 13.1 .6 20.6-4-10.3-9.2-19.7-15.4-28.2 .7 4.6 .9 9.7 .6 15.2-7.4-11.8-16.6-22.1-27.4-30.4z",
    "knight-banner": "M64 5.9l-4 12.2h8.1zM18.2 22.6v4h91.5V22.6zm12 8.5V119.8l33.8-26.2 33.8 26.2V31.1zm21.8 9.2h24l-8 20 20-8v24l-20-8 8 20h-24l8-20-20 8v-24l20 8zm12 58.9l-5.8 4.5v18.4h11.5v-18.4z",
    "knocked-out-stars": "M29.1 43.8l1.4 5.7-3.9 4.4 5.8 .4 3 5.1 2.2-5.5 5.7-1.3-4.5-3.8 .5-5.8-5 3.1zm63.9-22.9l1.9 3.8-2 3.8 4.2-.7 2.9 3.1 .7-4.2 3.8-1.8-3.8-1.9-.6-4.2-3 3zm-14.8 12l-1.7 4.7-4.7 1.3 3.9 3-.1 2a16.8 61.6 64.1 0 0-17.1 7.4 16.8 61.6 64.1 0 0-.1 0 16.8 61.6 64.1 0 0-37.2 23.6l-3.1-1.8L17.5 67.1l-4.5 4-5.8-1.4 2.4 5.5-3.2 5.1 6-.6 1.8 2.1a16.8 61.6 64.1 0 0-4 11.4 16.8 61.6 64.1 0 0 20.6 3L29.8 99l-5.4 1.4 4.4 3.4-.3 5.6 4.6-3.1 5.2 2-1.6-5.3 3.5-4.3-5.6-.2-1.8-2.7a16.8 61.6 64.1 0 0 18.1-5.1l1.7 4.7 3.6-5.7 6.8-.2-2.1-2.5a16.8 61.6 64.1 0 0 11.9-5.4 16.8 61.6 64.1 0 0 30.1-17.9l2.1 4.5-3.5 5.9 6.8-.9 4.5 5.1 1.3-6.7 6.2-2.7-6-3.3-.6-6.8-5 4.7-4.3-1a16.8 61.6 64.1 0 0 16.4-22.9 16.8 61.6 64.1 0 0-38.4 1.8l-.1-.2 3.1-3.9-5-.1zm-18.9 20.7a12.8 47 64.1 0 1 .2-.1 12.8 47 64.1 0 1 15.9-6.7v.1l.1-.1a12.8 47 64.1 0 1 5.8-2l2.7 1.1-.5-1.7a12.8 47 64.1 0 1 23.9 .4 12.8 47 64.1 0 1-14.6 19.1l-.5-2.7 2.5-2.6-3.6-.4-1.6-3.2-1.5 3.3-3.6 .6 2.7 2.5-.5 3.5 3.1-1.7 2.5 1.2a12.8 47 64.1 0 1-21.5 12.6 12.8 47 64.1 0 1-10.9 4.8l1.1-3.8-6.3 2.4-5.6-3.8 .4 6.8-4.2 3.3a12.8 47 64.1 0 1-22.3-.8A12.8 47 64.1 0 1 59.2 53.5z",
    "lantern-flame": "M64.1 4.8c-7.1 0-13 5.8-13 13 0 3.4 1.3 6.5 3.5 8.8l-27.6 19.6h74.2l-27.6-19.6c2.2-2.3 3.5-5.5 3.5-8.9 0-7.1-5.8-13-13-13zm0 4.7c4.6 0 8.3 3.7 8.3 8.3 0 2.4-1 4.6-2.7 6.1l-5.7-4-5.6 4c-1.6-1.5-2.6-3.7-2.6-6.1 0-4.6 3.7-8.3 8.3-8.3zM24.1 51l.8 3 16.3 58.2 .5 1.7h44.7l.5-1.7 16.3-58.2L104.1 51H24.1zm6.2 4.7h67.7L82.9 109.2H45.3l-15-53.5zm36.5 4.2c7.3 11.9-19.2 17.6-15 33.4 2.8 6.2 7.3 10.3 12.6 10.5 12.2 0 18.4-13.4 15.2-25-1.2 6-6.2 8.7-8.7 5.6-6-7.6 9.1-14.2-4-24.6zM31.8 118.4v4.7h64.6V118.4H31.8z",
    "lantern": "M64.3 5.8c-10.4 0-18.9 8.5-18.9 18.9 0 4.3 1.4 8.2 3.8 11.4-8.6 7.4-18.8 13.1-29.5 18.2H108.9c-11.1-5.1-21.3-10.8-29.7-18 2.5-3.2 4-7.2 4-11.6 0-10.4-8.5-18.9-18.9-18.9zm0 4.7c7.9 0 14.2 6.3 14.2 14.2 0 3.2-1 6.1-2.8 8.5-4.5-4.4-8.4-9.2-11.4-14.8-3.3 5.5-7.2 10.3-11.6 14.5-1.6-2.3-2.6-5.1-2.6-8.2 0-7.9 6.3-14.2 14.2-14.2zm-26 48.4v51h52V58.9H38.3zm25.9 4.5c.2 0 .5 0 .7 0 3.5 .1 7 1 10.2 2.9 10.3 5.9 13.8 19.2 7.9 29.4-5.9 10.3-19.1 13.8-29.4 7.9-10.3-5.9-13.8-19.1-7.9-29.4 4-6.8 11.1-10.7 18.5-10.8zm2.3 4.8v9.2h12.9c-1.4-2.9-3.7-5.3-6.7-7.1-2-1.1-4.1-1.8-6.2-2.1zm-4.7 0c-4.9 .7-9.4 3.6-12.1 8.3-.2 .3-.3 .6-.5 .9h12.6v-9.1zm-14.2 13.8c-.4 2.3-.3 4.7 .3 7h13.9V82.1H47.7zm18.8 0v7h14.2c.6-2.3 .7-4.7 .3-7h-14.4zm-16.6 11.7c1.4 2.3 3.4 4.4 6 5.8 1.9 1.1 3.9 1.8 6 2.1v-7.9h-11.9zm16.6 0v8c4.9-.6 9.5-3.4 12.2-8H66.5zm-36.1 20.8v9.6H98.2v-9.6H30.4z",
    "locked-chest": "M36.7 5.2c-3.1 0-6.1 .7-9.3 2.4h0C15.3 13.7 5 30.2 4.5 44l10.5 3.6c1.1-15.5 11.8-32.1 25.4-39h0c1.1-.6 2.2-1 3.3-1.4l-5.6-1.9c-.5 0-.9 0-1.4 0zm14.8 5c-2.6 0-5.7 .8-9.1 2.5l0 0c-12.1 6.1-22.4 22.6-22.9 36.4l39.1 13.3c1-15.6 11.7-32.3 25.4-39.3h0l0 0c1.1-.5 2.1-1 3.2-1.4l-33.6-11.3c-.7-.1-1.4-.2-2.1-.2zm43.7 14.6c-2.6 0-5.7 .8-9.1 2.5l0 0c-12.1 6.1-22.6 22.9-22.9 36.7l11.6 3.9c1-15.5 11.7-32.3 25.4-39.2 1.1-.6 2.3-1.1 3.4-1.5l-6.6-2.2c-.5-.1-1.1-.1-1.7-.1zm15.9 5.5c-2.6 0-5.5 .8-8.8 2.5-11.8 6-21.9 21.9-22.8 35.4l43.6-18.4c-.1-9.8-2.7-15.3-6.1-17.8-.6-.4-1.2-.8-1.9-1l0 0-1.2-.4c-.9-.2-1.8-.3-2.8-.3zM4.5 48.9l0 46.9L14.9 99.4V52.4L4.5 48.9zM19.5 54v47l39.1 13.6V67.3l-7.3-2.5v29.9l-25.3-8.5V56.3L19.5 54zm103.6 .9L79.6 73.3v47.3l43.5-18.4v-47.3zm-92.3 2.9v25l15.9 5.4v-24.9l-15.9-5.4zm7.8 7.2c2.4 0 4.4 2 4.4 4.4 0 1.6-.8 3-2.1 3.7v7.1h-4.7v-7.2c-1.2-.8-2-2.1-2-3.7 0-2.4 2-4.4 4.4-4.4zm24.7 3.9v47.3l11.7 4.1V72.9l-11.7-4z",
    "lyre": "M27.2 8.8c-3.8 0-8.4 1.3-11.7 4-2.7 2.1-4.7 4.8-5.3 8.6 .1 0 .1-.1 .2-.1-.2 .7-.3 1.4-.3 2.2 0 4.3 3.5 7.7 7.7 7.7 3.6 0 6.6-2.4 7.5-5.7 0 0 0-.1 0-.1 .1-.5 .2-1 .2-1.5 0-.1 0-.2 0-.2 0 0 0-.1 0-.1 0 0 0-.1 0-.1 0-.4 0-.8-.1-1.1-.3-2-1.7-3-3.1-3.4-2.1-.6-4.8 .2-5.9 4.5l-.1 0C15.5 18.5 18.1 16 21 15.2c.6-.2 1.3-.3 1.9-.2 2.3 0 4.6 1.2 6.1 4.3 0 0 0 .1 .1 .1 1.3 3.8 .5 10.8-.8 14.4-1.8 4.7-5.6 10.1-11.9 16.4C1.7 64.6 1 82.5 10 97.2 19 112 38 123.4 63.6 123.4c25.6 0 44.6-11.4 53.6-26.2 9-14.7 8.2-32.6-6.2-47l-.1-.1h0c-6.3-6.2-10.1-11.7-11.9-16.4-1.3-4.1-2.3-10.7-.7-14.4 0 0 0-.1 0-.1 0 0 0 0 0 0 1.5-3.1 3.9-4.2 6.1-4.3 .7 0 1.3 .1 1.9 .2 2.9 .8 5.5 3.3 4.8 8.2l-.1 0c-1.2-4.4-3.8-5.1-5.9-4.5-1.1 .3-2.2 1-2.7 2.1 0 0 0 0 0 0-.2 .8-.4 1.6-.4 2.4 0 4.3 3.5 7.7 7.7 7.7 4.3 0 7.7-3.5 7.7-7.7 0-1.1-.2-2.1-.6-3.1-.8-3.3-2.6-5.8-5.1-7.7-3.6-2.8-8.6-4.1-12.5-3.9-3.3 .1-6.2 1-8.3 2.6-.9 .7-1.6 1.4-2.2 2.3-17.4 8.9-34.7 9.7-52.1-1.9-.2-.1-.3-.3-.5-.4-2.1-1.6-5-2.5-8.3-2.6-.2 0-.5 0-.7 0zm13.2 13.3c1.6 .7 3.2 1.2 4.8 1.8v78.3c-7.7-2.1-14.5-5.5-19.3-10.3-4.3-4.2-7-9.7-7.2-15.9-.2-6.2 2.1-13.2 7.2-20.7 10.3-14.9 14.3-25.9 14.6-33.1zm46.5 .4c.4 7.2 4.4 18.1 14.6 32.8 5.2 7.5 7.4 14.4 7.2 20.7-.2 6.2-3 11.7-7.2 15.9-4.8 4.7-11.3 8.1-18.8 10.2V23.7c1.4-.4 2.8-.8 4.2-1.3zm-8.9 2.5v78.1c-2.1 .4-4.2 .7-6.3 .9V26c2.1-.3 4.2-.7 6.3-1.1zm-28.2 .2c2.1 .5 4.2 .9 6.3 1.1v77.8c-2.1-.2-4.3-.5-6.3-.9V25.1zm17.2 1.4v77.8c-1.1 0-2.3 .1-3.4 .1-.9 0-1.9 0-2.8 0V26.6c2.1 .1 4.2 0 6.2-.1z",
    "meat-cleaver": "M78.2 6.1L22.1 70.7l16.4 23.9c22.6-17 45.5-44.5 63.7-74l-24-14.6zm2.3 7.5c.7 0 1.2 .2 1.6 .5 .9 .6 1.6 1.9 1.6 4.1 0 4.5-3.6 10.3-7.4 12-1.9 .9-3.2 .7-4 .1-.9-.6-1.6-1.9-1.6-4.1 0-4.5 3.6-10.3 7.4-12 1-.4 1.7-.6 2.4-.6zm25.7 9.5c-18.5 29.9-41.7 57.8-65.1 75.4l10.6 15.5c23.5-17 54.8-50.6 70.4-81.2L106.2 23.1zM18.4 73.5c-4.5 4.3-8.9 8.2-13.4 11.7V115.4c6.9-8.4 14.4-18.9 21.9-29.4L18.4 73.5z",
    "meat-hook": "M4.8 4.7v1.5l13.6 13.5h0v0c.6 .6 .9 .6 1.5 .5 .6-.1 1.4-.5 2.1-1.2 .6-.7 1.1-1.5 1.2-2.1 .1-.6 0-1-.5-1.5L12 4.7H4.8zM20.6 6.7l5.4 5.4c1.2 1.2 1.8 2.9 1.9 4.4 1.7 .1 3.4 .8 4.8 2.2l4.4 4.4c.1-1.7-.4-3.4-1.8-4.8l-9.2-9.2c-1.6-1.6-3.5-2.3-5.3-2.3 0 0-.1 0-.1 0zm-10.7 11.1c0 1.8 .7 3.6 2.2 5.1l9.2 9.2c1.4 1.4 3.1 2 4.8 1.9l-4.4-4.4c-1.3-1.3-2-3.1-2.1-4.7-1.6 0-3.2-.6-4.5-1.9l0 0-5.2-5.2zm17.7 3.3c-.1 0-.2 0-.2 0-.6 .1-1.4 .5-2 1.1-.6 .6-1 1.5-1.1 2.2-.1 .7 0 1.2 .7 1.9l19 19c.5 .5 .9 .6 1.5 .5 .6-.1 1.4-.5 2.1-1.2 .7-.7 1.1-1.5 1.2-2.2 .1-.6 0-1-.5-1.5l-19-19c-.7-.7-1.2-.8-1.7-.8zm18.5 11l5.6 5.6c1.2 1.2 1.8 2.7 1.8 4.2 1.6 .1 3.2 .8 4.5 2.1l4.4 4.4c.1-1.7-.4-3.4-1.8-4.8l-9.2-9.2c-1.6-1.6-3.5-2.3-5.3-2.3zm-10.8 11.1c0 1.8 .7 3.6 2.2 5.1l9.2 9.2c1.4 1.4 3.1 2 4.9 1.9l-4.4-4.4v0c-1.3-1.3-1.9-2.9-2.1-4.5-1.5-.1-3.1-.7-4.3-1.9l-5.4-5.4zm17.7 3.3c-.1 0-.2 0-.2 0-.6 .1-1.4 .5-2 1.1-.6 .6-1 1.5-1.1 2.2-.1 .7 0 1.2 .7 1.9l19 19c.5 .5 .9 .6 1.5 .5 .6-.1 1.5-.5 2.1-1.2 .7-.7 1.1-1.5 1.2-2.2 .1-.6 0-1-.5-1.5l-19-19c-.7-.7-1.2-.8-1.7-.8zm17.8 7.5c-.8 0-1.7 .1-2.5 .3l8.8 8.8c1.5 1.5 2.1 3.7 1.8 5.5-.3 1.8-1.2 3.4-2.5 4.7-1.2 1.3-2.8 2.2-4.7 2.5-1.9 .3-4-.3-5.6-1.8l-9-9c-1 4.4 .1 9.2 3.5 12.6 2.8 2.8 6.7 4.1 10.5 3.8l0 .1c.1 0 .2-.1 .3-.1 1.1-.1 2.2-.3 3.3-.7 7.7-1.2 19.5-.7 27.2 3.3 9.4 4.8 13.4 14.7 9 22-4.3 7-14.8 9.1-24.1 3.1l6.7-3-17.2-7.8 2.3 5.5 5.8 17.4 27.9-1.3 2-7.1 7-2 1.4-27.9-38.6-12.7c.9-4.3-.3-9-3.6-12.3-2.6-2.6-6.1-3.9-9.7-3.9z",
    "medal-skull": "M62.1 5.2c-10.9 0-21.8 1.1-32.9 3.5v13.5c23.4-6.9 48.4-5 69.5 .2V8.7c-11.4-2.1-22.9-3.4-34.4-3.5-.7 0-1.4 0-2.2 0zm-.9 17.1c-3.1 0-6.1 .1-9.2 .4V72.4c3.6-1.5 7.7-2.3 11.9-2.3 4.2 0 8.1 .8 11.7 2.2l0-49.2c-4.3-.4-8.7-.7-13.1-.7-.4 0-.9 0-1.3 0zm-13.9 .9c-3.6 .4-7.3 1-10.9 1.9v45.2l8.3 6.4c.8-.7 1.7-1.3 2.6-1.8V23.2zm33 .4v51c.9 .6 1.8 1.2 2.6 1.8l7.8-6.2V25.3c-3.4-.7-6.8-1.3-10.4-1.7zm-16.4 51.2c-12.7 0-22.5 8.2-22.5 17.7 0 6 4 11.5 10.1 14.7l-4.4 15 4.5 1.3 3.1-10.8 6.1 0v11.2h4.7v-11.2h6.3l3.1 10.8 4.5-1.3-4.2-14.5c6.7-3.1 11.1-8.9 11.1-15.2 0-9.5-9.8-17.7-22.4-17.7zm-13.8 10.3l11 12.1-13-1.7 2-10.4zm27.4 0l2 10.4-13 1.7 11-12.1zm-13.9 15.4l3.8 7.4h-7.5l3.8-7.4z",
    "metal-boot": "M67.2 6l-21.9 0c.3 15.3-.6 29-3.5 39.9-2.2 8.5-5.9 15.4-11.3 19.8 0 2.4-.2 4.8-.5 7.2-.8 5.7-3.4 10.8-5.7 16.2 5.9-.3 10.9-2.9 16.3-6.2 5.2-3.1 10.6-6.9 17.2-9.4-.1-.3-.1-.7-.1-1.1-.5-5.9 0-13.1 1-20.8C60.8 36.9 64.5 20.3 67.2 6zm-26.4 0H20.2c-.4 9.1 2.5 19 5.4 29.8 2.1 7.6 4.1 15.6 4.8 23.9 3.1-3.6 5.5-8.6 7.2-15 2.7-10.2 3.6-23.5 3.4-38.7zm10.4 3.7a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm-.6 13.1a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm-1.5 14.1a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm-4 15.2a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm-8 12a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm21.4 13.8c-5.7 2.4-10.6 5.7-15.7 8.8-6.2 3.7-12.6 7-20.5 6.9-2 5.7-3.5 12-2.5 20h20.6c3.3-10.3 10.7-19.5 23.8-26.7-.3-.2-.7-.5-1.1-.8-2.4-1.9-3.8-4.7-4.7-8.1zm10.1 11.7c-13 6.5-20.1 14.6-23.4 23.9h31.9c0-3.6 .1-7.2 1-10.9 .7-2.9 1.8-5.7 3.5-8.5-4-.8-8.4-2-12.9-4.5zm17.7 5.5c-2 2.7-3.2 5.6-3.9 8.6-.7 3.1-.9 6.5-.9 9.9h26c-.5-4.5-3.1-9.9-7-13-4.5-3.5-9-4.5-14.2-5.5zm2.1 2.6a2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm-63.5 8.8a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm11.2 .1a2.2 2.2 0 0 1 0 0 2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zm50.4 0a2.2 2.2 0 0 1 2.2 2.2 2.2 2.2 0 0 1-2.2 2.2 2.2 2.2 0 0 1-2.2-2.2 2.2 2.2 0 0 1 2.2-2.2zM18 117.5v4.5H110V117.5z",
    "mirror-mirror": "M64.4 5.1c-9.6 0-18.7 3.1-26.8 8.7h-13.6V115.1H37.5c8.1 5.6 17.3 8.8 26.9 8.8 9.6 0 18.8-3.2 26.9-8.8h13.5V13.8h-13.6c-8.1-5.6-17.2-8.7-26.8-8.7zM30.8 21.1H98.1V108H30.8V21.1zm4.7 4.7v27.2l31.7-27.2H35.5zm50.1 0L35.5 68.7v14.2l57.9-49.7v-7.4H85.6zm7.8 35L43.6 103.4h11.6l38.1-32.1v-10.5zm0 16.6l-30.9 26h30.9V77.4z",
    "mushrooms": "M43 7c-.9 0-1.8 .1-2.6 .3-6.5 1.3-10.6 6.5-13.4 13.5-2.9 7.1-4.4 15.7-5.8 22.9-1 5.2-2.2 11.6-2.1 17.1 .1 5.5 1.4 9.8 5 12.2C33 78.5 45.8 78.4 57.9 74.2c12.1-4.1 23.2-12.2 28.5-21.6 .9-1.6 1.2-4.2 .7-6.6-.6-2.5-1.9-4.5-3.3-5.4-9.2-5.5-16.4-15-23.2-22.4-3.5-3.7-6.8-6.9-10.1-8.9-2.5-1.5-4.9-2.3-7.5-2.3zM108 72.5c-.9 0-2 .1-3.2 .2-2.4 .3-5.2 1.1-8.1 2.1-5.7 2.1-11.1 5.6-13.2 9.3-1.1 1.9-.3 6 1.4 8 7.5 8.9 22.7 14.2 33.9 11.2 1.9-.5 4.1-3 4.3-4.8 .6-4.6-.8-10.7-3.4-15.8-2.6-5-6.4-9-9.7-10-.4-.1-1.1-.2-1.9-.2zm-42.2 3.5c-2.1 1-4.3 1.9-6.5 2.6-4.1 1.4-8.4 2.4-12.6 2.9 0 .4-.1 .8-.1 1.2-.3 4.1-.7 8.3-.4 11.9 .2 3.5 1.1 6.2 2.5 7.6 2.5 2.3 6.8 3.8 11.2 3.9 4.3 .1 8.6-1.4 10.8-3.8 2.2-2.4 2.5-4.7 2-7.9-.6-3.2-2.2-7-4-11.3-1-2.2-2-4.7-2.9-7.1zM15.5 86.3c-.2 0-.3 0-.5 0-.9 .1-1.7 .2-2.4 .6C9.4 88.2 6.4 93.5 5.3 99c-.6 2.7-.6 5.4-.3 7.5 .4 2.1 1.2 3.5 2.1 4.1 .4 .3 .7 .3 1.4 .2 .7-.1 1.6-.5 2.6-1.1 2.1-1.2 4.6-3.2 7.3-4.7 3.4-1.9 7.2-2.9 9.9-4.1 1.4-.6 2.4-1.2 2.9-1.7 .5-.5 .6-.7 .5-1.4-.3-2.5-3.4-6.3-7.5-8.8-2.9-1.7-6.1-2.7-8.7-2.6zm77.8 17.9c-1 2.2-1.8 4.7-2.1 6.8-.4 2.1-.2 3.9 .4 4.8 1.2 2.1 4.2 4 7.5 4.8 3.3 .8 6.7 .4 8.6-1 .7-.5 1.3-1.7 1.7-3.5 .3-1.8 .4-4 .3-6.2 0-.4-.1-.8-.1-1.2-5.5-.3-11.2-1.9-16.2-4.5zM24.6 107.2c-1.4 .6-2.8 1.1-3.9 1.8-1.4 .8-2.9 1.8-4.4 2.9-.4 1.4-.6 3-.4 4.5 .2 1.8 .8 3 1.6 3.4 1.2 .7 3.4 .6 5.5-.3 2.1-.9 3.8-2.6 4.3-4 .5-1.4 .2-3.7-.9-5.7-.5-.9-1.1-1.8-1.8-2.4z",
    "musical-notes": "M24.5 4.6c-2.9 0-5.9 .3-9 1L32.5 65.3c-3.5-1.3-7.8-1.6-12-.8-9.8 1.7-16.8 8.4-15.6 14.9 1.2 6.5 10 10.4 19.8 8.7 9.8-1.7 16.8-8.4 15.6-14.9-5.5-20.2-11.1-40.8-16.6-61.1 12.7 .9 18.1 7.9 22.6 15.1-.1-15.6-9.4-22.5-21.8-22.5zm77.7 7.7c-3.5 0-7.2 .6-11 1.8l21.8 58.1c-3.6-1-7.9-.9-12.1 .2-9.6 2.5-16.1 9.8-14.4 16.1 1.7 6.4 10.8 9.6 20.4 7 9.6-2.5 16.1-9.8 14.4-16.1-7.2-19.7-14.3-39.7-21.4-59.5 12.7-.1 18.7 6.4 23.8 13.2-1.3-14.6-10.1-20.9-21.5-20.8zM64.6 40.9l.5 62c-3.1-2.1-7.1-3.6-11.4-4-9.8-.9-18.4 3.6-19.1 10.2-.6 6.6 6.9 12.7 16.8 13.6 9.9 1 18.4-3.6 19.1-10.2 .1-20.9 .2-42.2 .3-63.3 12 4.2 15.4 12.4 17.8 20.6 5-18.5-7-28.1-24-29z",
    "on-target": "M26.9 5.4c30.6 46.9 26.9 54-18.7 14 20.8 25.9 45.8 46.4 72 65.2-11.9 13.7-16.4 29.1-9.8 35.3 7 6.7 23.8 .6 37.6-13.7 13.7-14.3 19.2-31.4 12.2-38.1-6.6-6.3-21.9-1.1-35.2 11.5C66.9 53.5 48.7 27.6 26.9 5.4zm81.2 66.7c2.5 0 4.6 .6 6.1 2.1 5.3 5.1 1.2 18.2-9.3 29.1-10.5 10.9-23.5 15.7-28.8 10.6-5-4.8-1.6-16.5 7.4-26.9 .9 .7 1.9 1.3 2.8 2-6.6 7.8-9.1 16.4-5.4 19.9 4 3.8 13.7 .3 21.5-7.9 7.9-8.2 11-18 7-21.8-3.8-3.6-12.6-.6-20.3 6.7-.6-.9-1.3-1.9-1.9-2.8 7.1-6.8 15-10.8 20.9-10.9zm-5.5 9.3c1.4 0 2.6 .4 3.5 1.2 3.1 2.9 .7 10.4-5.3 16.7-6 6.3-13.5 9-16.5 6.1-2.8-2.7-1-9.2 4-15.1 1.5 1 3 2.1 4.5 3.1-2.4 2.8-3.5 5.7-2.4 6.8 1.2 1.2 4.6-.2 7.6-3.1 3-3 4.4-6.4 3.1-7.6-1.2-1.2-4.5 .1-7.4 2.9-1.1-1.5-2.1-3-3.2-4.6 4.1-4 8.7-6.3 12.1-6.3z",
    "open-treasure-chest": "M102.6 25.3c2.1-5.6 4.1-7.8 5.1-8.6 .8-.6 1.4-.9 2-.7 1 .3 2.1 1.9 3 4.2 2.7 7.6 2.5 21.1-.2 32.4zm-71.5 18.2c1.9-7.8 2.6-16.5 1.9-23.7l-10.9-1.2zm72.4-28.2l-75.3-8.4c-.6-.1-1.3 .4-1.8 .8-.9 .8-2.6 2.6-4.4 6.9l77.2 8.6c1.3-3.3 2.8-6 4.3-7.9zm-57.2 74.7v-17.7l2.7 .3 10.6 1.3v17.6zm4-10.1a3.2 3.2 0 0 0 1.3 2.6l-.6 6.1 4.2 .4-1-6.2a2.4 2.4 0 0 0 1.2-2.3 3.4 3.4 0 0 0-2.8-3.1s0 0 0 0c-1.5-.2-2.8 1-2.5 2.5zm13.2 16.1l-21.2-2.5v-21.7l-.3 0a2 2 0 0 1-1.8 1.7 2 2 0 0 1 1.3 2.2 2 2 0 0 1-2 1.7c2.1 1 1.1 4.2-1.2 3.8a2 2 0 0 1-2 3.5 2 2 0 0 1-3.1 2.6v0a2 2 0 0 1-1 2.1l2.3 1.3v3.6l-3 1.8-3-1.8v-3.6l2-1.2a2.1 2.1 0 0 1-1.3-1.5 .1 .1 0 0 1 0 0 2 2 0 0 1-3.8-1.2c-1.7 1.8-4.5-.5-3.1-2.5-2.1 1.1-4.1-1.7-2.3-3.2-2.3 .7-3.6-2.5-1.5-3.7a2 2 0 0 1-.8-3.9c-2.3-.3-2.4-3.6-.1-4-.2 0-.3-.1-.5-.2l-4.3-.5 .1 41.8 77.3 8.6-.1-41.5-26.8-3.3zm35-41l1.2 .5 .2 .1 9.7 1.1-5.8-16.2-3.2 9.2c0 .1-.9 2.5-2.1 5.2zm-52.1-9.9l1.2 1.4 3.2-2.8 5.4-.6 4.2 3.8 2.6 2.2 4.6-2.3 .9 .1c0-.2 .1-.3 .1-.5 .8-4 1.8-7.5 1.9-7.7l3.3-11 4.2 10.7 2.1 5.4 2.7-3.1 5.5-6.4 1.4 8.4 .8 4.8 4.3-2.4 8.8-4.9-4.6-12.8-62-6.9c.6 8.7-.5 19.3-3.1 28h.6l1.8-3.2h10.1zm-27.8 24.3c1.9 .5 2 3.2 .1 3.8 1.9 .2 2.5 2.8 .8 3.7 1.9-.1 2.9 2.2 1.5 3.5 1.8-.5 3.3 1.6 2.2 3.1 1.6-.9 3.4 .6 2.9 2.3 1.1-1.2 3.1-.6 3.4 1 .5-1.4 2.4-1.8 3.4-.7-.3-1.6 1.3-2.9 2.8-2.2-1.1-1.4 .1-3.5 1.9-3.2-1.6-1.1-.8-3.7 1.2-3.6-1.8-.9-1.3-3.6 .7-3.8a2 2 0 0 1-1.3-2l-19.1-2.1c-.1 0-.2 0-.3 .1zm91.9 34.8l-.1-41-2.2 1.8-13.9 11.7 .1 40.5zm-6.6-41.3l-6-3.8-1-.4c-1.5 2.9-3.3 5.8-5.7 7-1.4 .7-3.1 1.1-5 1.1-2.8 0-6.2-.7-9.3-2-2.5-1-5.8-2.8-7.6-5.3-1.2-1.8-1.7-4.4-1.3-8.2l-5.4 2.7-4.8-4-2.9-2.6-2.3 .2-5.1 4.5-2.8-2.9h-6.1l-4.4 8-1.4-1.8-1.1 1.2-2.7 4.1-3.1 1.2L24.4 64h-3l-.7 1.5 19.2 2.1a2 2 0 0 1 .5-.7 2 2 0 0 1 2.6-.1 .4 .4 0 0 1 0-.1c-1.2-2.1 1.6-4.2 3.2-2.3 1.6 1.8-.8 4.4-2.7 2.9a2 2 0 0 1 .3 .7l5.7 .6 42.1 5.1 12.9-10.8zm-7.1-14.4l-9.2 5.2-1.8-10.4-7 8.1-4.5-11.5s-4.2 13.6-1.8 17.2c1.9 2.9 8.9 5.6 13.6 5.6 1.2 0 2.4-.2 3.2-.6 3.5-1.8 7.5-13.6 7.5-13.6zm-79.3 67.7v-.1c0-.9-2.1-1.7-4.6-1.7-2.5 0-4.6 .8-4.6 1.7 0 .8 1.5 1.5 3.5 1.7v.1c0 .9 2.1 1.7 4.6 1.7 2.5 0 4.6-.8 4.6-1.7 0-.8-1.5-1.5-3.5-1.7zm87.5 1.7c-2.5 0-4.6 .8-4.6 1.7s2.1 1.7 4.6 1.7c2.5 0 4.6-.8 4.6-1.7s-2.1-1.7-4.6-1.7zm10-4.1c-2.5 0-4.6 .8-4.6 1.7s2.1 1.7 4.6 1.7c2.5 0 4.6-.8 4.6-1.7s-2.1-1.7-4.6-1.7z",
    "pan-flute": "M6.2 12.2v9.5h7.5V12.2H6.2zm12 0v9.5h7.5V12.2H18.2zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zm12 0v9.5h7.5V12.2h-7.5zM6.2 26.2v7.5h115.5v-7.5H6.2zm0 12v66.2c1.9-2.2 4.5-4.7 7.5-7.5V38.2H6.2zm12 0v54.6c2.3-2 4.8-4.1 7.5-6.3V38.2H18.2zm12 0v44.7c2.4-1.9 4.9-3.8 7.5-5.7V38.2h-7.5zm12 0v35.7c1.3-.9 2.6-1.9 4-2.8 1.2-.8 2.3-1.6 3.5-2.4V38.2h-7.5zm12 0v27.5c2.5-1.6 5-3.2 7.5-4.7V38.2h-7.5zm12 0v20c2.5-1.5 5-2.9 7.5-4.2V38.2h-7.5zm12 0v13.4c2.5-1.3 5-2.5 7.5-3.7V38.2h-7.5zm12 0v7.8c2.5-1.1 5-2.1 7.5-3V38.2h-7.5zm12 0v3.3c2.5-.8 5-1.5 7.5-2V38.2h-7.5zm19.5 4.1c-2.4 .1-4.9 .4-7.5 .9V47.8h7.5v-5.4zm-12 1.9c-2.4 .6-4.9 1.3-7.5 2.2V51.8h7.5v-7.5zm-12 3.8c-2.5 .9-5 2-7.5 3.1V55.8h7.5v-7.8zm-12 5.1c-2.5 1.2-5 2.4-7.5 3.7V63.8h7.5v-10.6zm-12 6.2c-2.5 1.4-5 2.8-7.5 4.3V71.8h7.5v-12.5zm-12 7c-2.5 1.6-5 3.2-7.5 4.8V79.8h7.5v-13.4zm-12 7.9c-.3 .2-.6 .4-1 .7-2.2 1.5-4.4 3.1-6.5 4.7V87.8h7.5v-13.6zm-12 8.7c-2.6 2-5.1 3.9-7.5 5.8V95.8h7.5v-12.9zm-12 9.5c-2.7 2.3-5.2 4.5-7.5 6.5V107.8h7.5v-15.4zm-12 10.8c-1.9 1.9-3.5 3.5-4.7 4.9-1 1.2-1.8 2.2-2.3 3-.5 .8-.5 1.3-.5 .9v3.8h7.5v-12.6z",
    "pendant-key": "M17.8 8c0 12.9 7.3 27.1 16.5 38.4 2.5 3 5 5.8 7.7 8.2-.1 .5-.1 .9-.1 1.4 0 3.4 2.8 6.2 6.2 6.2 1 0 1.9-.2 2.8-.7 3.7 2.4 7.4 4 11 4.5V70c-4.5 1.1-8 5.2-8 10s3.5 8.9 8 10v30h4.5v-3.5h9.8v-4.5h-9.8v-4.5h5.8v-4.5h-5.8v-13c4.5-1.1 8-5.2 8-10s-3.5-8.9-8-10v-3.9c3.5-.5 7.2-2.1 11-4.5 .8 .4 1.8 .7 2.8 .7 3.4 0 6.2-2.8 6.2-6.2 0-.5-.1-.9-.1-1.4 2.6-2.5 5.2-5.2 7.7-8.2 9.2-11.3 16.5-25.6 16.5-38.4h-4.5c0 11.1-6.7 24.9-15.5 35.6-2.1 2.6-4.4 5.1-6.7 7.3-1-.7-2.2-1.1-3.5-1.1-3.4 0-6.2 2.8-6.2 6.2 0 .8 .1 1.5 .4 2.2C70.3 60.5 66.7 61.8 64 61.8c-2.7 0-6.3-1.2-10.2-3.5 .2-.7 .4-1.4 .4-2.2 0-3.4-2.8-6.2-6.2-6.2-1.3 0-2.5 .4-3.5 1.1-2.3-2.2-4.6-4.7-6.7-7.3C29 32.9 22.2 19.1 22.2 8H17.8zm44 66.7V78.5h4.5v-3.8c2.1 .9 3.5 2.9 3.5 5.3 0 3.2-2.5 5.8-5.8 5.8s-5.8-2.5-5.8-5.8c0-2.4 1.4-4.4 3.5-5.3z",
    "plain-arrow": "M32.7 5.4v61.5H11L64 122.3l53-55.4H95.3V5.4H32.7z",
    "plain-dagger": "M10.9 3.9c-3.9 0-7.1 3.1-7.1 7.1 0 3.5 2.5 6.4 5.9 7L10.7 17 17.2 10.5l.7-.7C17.3 6.5 14.4 3.9 10.9 3.9zm8.4 11l-4.2 4.2c4 9.8 10.9 16.7 19.7 21.9 2-2.1 4.2-4.2 6.4-6.2-5.6-8.8-12.9-15.6-21.8-19.9zM80.6 19.8l-12.8 1.1c-19.8 12-36 27-46.7 46.6l-1.1 12.9 11-4.7-.7-8.5-.1-.8 .4-.7c9-14.6 20-27.4 35.4-35.3l.6-.3 .7 .1 8.5 .7 4.7-11.1zm-15.6 16.6c-2.5 1.5-4.9 3.1-7.1 4.8 11.7 12 21.8 27.1 28.7 41.6l2.8 5.9-5.9-2.8c-14.5-6.9-29.5-16.9-41.4-28.5-1.8 2.4-3.5 4.8-5.2 7.3 25.5 23.7 56.8 44.3 87 58.7-14.3-30-35-61.5-58.8-87.1zm-10.8 7.8c-3.3 2.9-6.4 6.1-9.3 9.6 9.8 9.6 22 18.2 34.2 24.7-6.5-12.2-15.2-24.5-24.9-34.3z",
    "poison-bottle": "M45.4 8.2v12.9h37.4V8.2H45.4zm3.5 17.6c-.2 .7-.4 1.3-.7 1.7-.7 .9-1.8 1.6-4.9 1.6-5.4 0-10.2 1.5-13.8 4-3.6 2.6-6 6.3-6 10.6V106.7c0 8.1 6.6 14.7 14.6 14.7h53.4c8.1 0 14.6-6.6 14.6-14.7V43.8c0-4.3-2.4-8.1-5.9-10.6-3.5-2.6-8.2-4-13.4-4-4.2 0-5.9-.9-6.7-1.8-.4-.4-.6-.9-.8-1.6h-4.8c.3 1.7 .8 3.3 2.1 4.7 2 2.3 5.4 3.4 10.2 3.4 4.2 0 8 1.3 10.6 3.1 2.6 1.9 4 4.3 4 6.8V106.7c0 5.6-4.4 10-10 10H38.3c-5.6 0-10-4.4-10-10V43.8c0-2.6 1.4-4.9 4-6.8 2.7-1.9 6.6-3.2 11.1-3.2 4 0 7-1.3 8.7-3.6 1-1.4 1.4-2.9 1.7-4.5h-4.8zm16.5 11.4c-7.6 0-12.5 3.2-15.8 8.1-3.1 4.5-4.6 10.6-4.8 16.5 6.3 3.2 9.9 6.9 11 11.2 .2 .7 .3 1.5 .3 2.2 2.3 1.3 5.8 2.1 9.5 2.1 3.2 0 6.5-.6 9-1.7 0-.8 .2-1.7 .4-2.5 1.1-4.4 4.8-8.3 11.1-11.4-.2-5.6-1.7-11.6-4.8-16.2-3.3-5-8.2-8.3-15.9-8.3zM58 55.9c2.3 0 4.1 1.9 4.1 4.1 0 2.3-1.9 4.1-4.1 4.1-2.3 0-4.1-1.9-4.1-4.1 0-2.3 1.9-4.1 4.1-4.1zm13.9 0c2.3 0 4.1 1.9 4.1 4.1 0 2.3-1.9 4.1-4.1 4.1-2.3 0-4.1-1.9-4.1-4.1 0-2.3 1.9-4.1 4.1-4.1zm-7.2 8.4c1.6 3.3 2.8 6.6 3.4 9.9-2.3-.8-4.6-.9-6.9 0 .8-3.3 1.8-6.6 3.4-9.9zm-9.3 15.9c-.5 1.6-1.3 3.2-2.3 4.8 3 2 7.9 3.2 12.7 3.1 4.7-.1 9.2-1.4 11.6-3.1-.9-1.4-1.6-3-2.1-4.5-3 1.1-6.4 1.6-9.7 1.6-3.6 0-7.2-.6-10.2-1.9zm-17.7 4.3c-2.2 2.8-3.2 5.6-2.5 9.1 17.2 1.4 41 8 56.7 15.2 2.3-2.8 3.1-5.7 2.5-9.2-16.9-1.7-41-7.2-56.7-15.1zm54.1 0c-5.2 2.6-11.3 5-17.8 7 5.1 1.1 10.1 2 14.7 2.7 1.9-.3 3.8-.5 5.7-.6 .7-3.5-.3-6.3-2.5-9.1zm-50.9 14.4c-2 .3-3.9 .5-5.7 .7-.6 3.5 .2 6.4 2.5 9.2 5.3-2.5 11.6-4.9 18.3-7-5.2-1.2-10.3-2.2-15.1-2.9z",
    "poison-gas": "M93 4.1c-4.7 0-9.4 1.9-12.3 5.8-6.3-6.1-19.7-3.4-19.7 8.1 0 1.7 .3 3.2 .8 4.5h31.7l11 45.5h-18.9l-2.6 22.6c9 .2 18.1-5.6 18.1-17.3l0 0c3.8 .3 7.7-1.1 10.1-4.1 3.3 3 10 1.6 10-4.3 0-4.7-4.5-6.5-7.9-5.4-.8-4.3-3.8-6.9-7.3-8.1 1.3-1.8 2.1-4 2.1-6.8 0-5.5-3-8.9-6.9-10.4 .1-.4 .1-.8 .1-1.2 0-.4 0-.8-.1-1.2 4-2.3 6.9-6.6 6.9-12.7 0-9.9-7.6-14.9-15.1-14.9zM24.7 9.9c-4.8 0-9.6 2.7-10.9 8.9-3.2 14.7 19.2 19.5 22.3 4.9 .1-.6 .2-1.1 .2-1.6 2.9 .8 6.4-.4 7.3-4.3 1.5-6.7-7.5-9.4-10.6-4.6-2.2-2-5.3-3.2-8.4-3.2zm15.5 17.1L31.5 63.2h17.1l5.2 44.7h22.5l5.2-44.7h17.1L89.8 27H40.2zm77.2 2.8c-2.7 0-5.4 1.8-5.4 5.3 0 7.1 10.8 7.1 10.8 0 0-3.5-2.7-5.3-5.4-5.3zM42.3 41.9l16.8 11.8-19.8 1.8 2.9-13.6zm45.4 0l2.9 13.6-19.8-1.8 16.8-11.8zm27.9 2.4c-1.9 0-3.7 1.2-3.7 3.7 0 4.9 7.4 4.9 7.4 0 0-2.4-1.9-3.7-3.7-3.7zM12 47.4c-3.9 0-7.9 2.6-7.9 7.7 0 7 7.2 9.2 11.9 6.8 .3 15.8 21.3 17.8 26.9 6h-17.4l4.9-20.3c-4.1-.1-8.3 1.5-11.1 4.5-1.2-3.2-4.3-4.8-7.3-4.8zm53 10.3l8 10.5-3.7 2.8-4.2-5.6-4.2 5.6-3.7-2.8 8-10.5zM10.1 68.2c-1.9 0-3.7 1.2-3.7 3.7 0 4.9 7.4 4.9 7.4 0 0-2.4-1.9-3.7-3.7-3.7zm35.3 8.1c-3.8 .2-7.5 2.7-7.5 7.7 0 1.9 .6 3.5 1.5 4.7-2 1.9-3.4 4.6-3.4 8.3 0 6 3.6 9.6 8 10.8-.6 .9-.9 2-.9 3.3 0 7.2 10.2 7.7 11.6 1.4h-5l-4.2-36.2zm36.8 20.9l-1.8 15.3h-13.1c2.8 6.6 11.6 8.1 17.1 4.6 1.3 8.9 15.6 8.5 15.6-1.4 0-6.5-6.2-8.9-10.8-7.2 0-.3 0-.5 0-.8 0-5.6-3.1-9.1-7.1-10.5zm38.4 1.6c-1.8 0-3.6 1.5-3 3.8 1 3.8 6.9 2.3 5.8-1.6-.4-1.6-1.6-2.2-2.8-2.2zM15.3 104.2c-3.3 0-6.6 2.2-6.6 6.5 0 4.3 3.3 6.5 6.6 6.5-.1 .3-.1 .7-.1 1.1 0 6.6 10.1 6.6 10.1 0 0-2.8-1.8-4.4-3.9-4.9 .3-.8 .5-1.7 .5-2.7 0-4.3-3.3-6.5-6.6-6.5zM115.8 107.9c-1.4 0-2.8 .8-3.4 2-3.4-2.2-9.1 .5-7.7 5.5 1.5 5.6 9.3 4.3 9.9-.5 2.4 .7 5.6-1.2 4.7-4.4-.5-1.9-2-2.7-3.4-2.7zm-83.2 .5c-1.9 0-3.7 1.2-3.7 3.7 0 4.9 7.4 4.9 7.4 0 0-2.4-1.9-3.7-3.7-3.7z",
    "poison": "M45.2 45.2c3.8 0 15-15 7.5-26.2 3.8-3.8 3.8-7.5 11.2-7.5s15 11.2 15 18.8-7.5 15-18.8 22.5-30 22.5-30 41.2c0 15 11.2 30 30 30s37.5-7.5 37.5-30c0-15-15-22.5-22.5-22.5-11.2 0-18.8 7.5-22.5 18.8 11.2-15 33.8-15 33.8 3.8 0 11.2-11.2 18.8-26.2 18.8-7.5 0-15-7.5-15-18.8s11.2-22.5 22.5-30 22.5-18.8 22.5-30c0-15-11.2-30-26.2-30-7.5 0-15 7.5-18.8 11.2s-11.2 3.8-11.2 15c0 3.8 7.5 15 11.2 15z",
    "powder-bag": "M63.1 12.4c-.7 0-1.7 .3-3 .9a4.3 1.8 0 0 1 2.4 1.6 4.3 1.8 0 0 1-4.3 1.8 4.3 1.8 0 0 1-2.9-.5C52.4 18.3 49.1 21.2 46 24.5a80.2 80.2 0 0 0-2.1 2.4 4.3 1.8 0 0 1 .5 0 4.3 1.8 0 0 1 4.3 1.8 4.3 1.8 0 0 1-4.3 1.8 4.3 1.8 0 0 1-3-.5c-3.5 4.5-6.5 9.2-8.2 13.4 19.2 3.7 41.2 3.4 61.5-.7a34 34 0 0 0-.8-1.8 4.3 1.6 0 0 1-1.9 .2 4.3 1.6 0 0 1-4.3-1.6 4.3 1.6 0 0 1 4.3-1.6 4.3 1.6 0 0 1 .4 0c-2.5-4.5-6-9.3-10-13.5-6.6-7-14.6-11.9-19.4-11.8zm5.7 5a4.2 1.5 0 0 1 4.2 1.5 4.2 1.5 0 0 1-4.2 1.5 4.2 1.5 0 0 1-4.2-1.5 4.2 1.5 0 0 1 4.2-1.5zm7.6 7.6a4.3 1.7 0 0 1 4.3 1.7 4.3 1.7 0 0 1-4.3 1.7 4.3 1.7 0 0 1-4.3-1.7 4.3 1.7 0 0 1 4.3-1.7zm-16.5 5.4a4.3 1.8 0 0 1 4.3 1.8 4.3 1.8 0 0 1-4.3 1.8 4.3 1.8 0 0 1-4.3-1.8 4.3 1.8 0 0 1 4.3-1.8zm-9.7 9.2a4.4 1.5 0 0 1 4.4 1.5 4.4 1.5 0 0 1-4.4 1.5 4.4 1.5 0 0 1-4.4-1.5 4.4 1.5 0 0 1 4.4-1.5zM103.9 45c-25.4 6.7-54.3 7.2-78.3 1.2-1.6 1.9-3 3.6-3.8 5.2-.8 1.7-1.2 3.4-.9 5.7 28.6 6.5 59.6 4.9 88.6-.3 .3-1.7 .1-3.4-.8-5.3-.9-2-2.6-4.3-4.8-6.6zm3.1 16.9c-5.5 .9-11.2 1.7-16.8 2.4 2.5 10.4 5.5 22.2 4.4 33.1l-.2 1.6-1.5 .4c-17.3 4.4-35.9 7.9-53.5-.1l-1.1-.5-.2-1.2c-1.7-11.2 1.8-22.1 3.6-32.4-6.1-.6-12.2-1.5-18.3-2.7-5.9 14.5-9.1 32.2-7.7 48.3-2.5 2.6-4.9 5.9-3.6 8.1 2.3 3.9 10.7 1.9 15.8 .2 23.2 5.4 50.1 4.8 72.4 .4 4.6 1.7 14.9 4.8 17.5 .4 1.2-2.1-.9-5.2-3.2-7.7 2.6-17.4-2.5-34.8-7.7-50zm-21.3 2.9c-13.1 1.3-26.4 1.6-39.5 .7-1.7 10.5-4.8 20.5-3.7 30.2 15.1 6.4 31.5 3.8 47.7-.2 .6-9.5-2.1-20.6-4.5-30.6z",
    "prayer": "M65.4 4.5c-13 0-23.7 11.4-23.7 25.8 0 14.4 10.7 25.8 23.7 25.8 13 0 23.7-11.4 23.7-25.8 0-14.4-10.7-25.8-23.7-25.8zM50.8 39.9c3.3 .9 6.6 1.5 9.8 1.8v4.7c-3.7-.3-7.4-1-11.1-2l1.2-4.5zm29.3 0l1.2 4.5c-3.6 1-7.3 1.6-11 2v-4.7c3.3-.3 6.5-.9 9.7-1.8zM40.1 43.8c-18.8 12.7-27.7 31.3-29.1 55h.1c-.1 .4-.1 .9-.1 1.3 0 3.5 2.8 6.2 6.2 6.2 .1 0 .1 0 .2 0v.1l44.9 0V75.6c-6.4 1.2-11.3 7.1-11.3 15.6v2.3H25.8v-4.7h3.2c.9-8.8 6.6-19.5 11.3-25.3l3.6 2.9c-3.9 4.8-9.2 15.4-10.2 22.4h12.6c1-10.5 8.8-18.2 18.3-18.2 8.7 0 17.2 7.2 18.5 18.2h13.9c-1.4-7.1-6.6-17.6-10.5-22.4l3.6-2.9c4.7 5.9 10.4 16.6 11.6 25.3h2.6v4.7H78.6l-.1-2.3c-.3-8.9-5.9-14.6-11.7-15.7v30.9h45.2v-.1c.1 0 .1 0 .2 0 3.5 0 6.2-2.8 6.2-6.2 0-.5-.1-1-.2-1.5-1.4-23.2-9.8-41.4-27.8-54.1-4.8 9.6-14.1 16.2-25 16.2-11.2 0-20.8-6.9-25.4-16.9zM35.1 111.1l2.3 11.9h55.1l2.1-11.9h-59.6z",
    "raven": "M85.8 5.6c-14.3 0-15.3 9-22.8 13.7C38.7 10.6 33.3 55.4 42.5 82.5c-3.8 8-7.7 19-11 33.7 14.2 7.7 29.8 9.7 45.6 2.5-1.6-9.4-3.5-17.2-5.5-23.8 6.3-3.2 14.9-3.6 21.6 3.6 .1-7.2-4.8-10.2-10.1-10.6l-5.5-11.8c10.7-11.3 18.6-25 14.5-39.3-2.6-9.6 14.6-15.6 30.6-13.4-6.1-5.3-14-7.6-21.5-8.5-2.2-5.4-8.2-9.3-15.3-9.3zm2.7 5.5c2.5 0 4.4 2 4.4 4.4 0 2.5-2 4.4-4.4 4.4-2.5 0-4.4-2-4.4-4.4 0-2.5 2-4.4 4.4-4.4zm-14.5 68.6l4.1 8.7c-2.9 .7-5.6 2.1-7.3 3.9-.8-2.7-1.6-5.2-2.4-7.6 1.9-1.6 3.8-3.3 5.6-5.1z",
    "relic-blade": "M124.9 4L119.3 5.6l-37.9 10.6-1.6 .5-.1 1.7-.2 7.3-4.7 1.3-1.7 .4-.1 1.7-.2 6.2-33.5 33.4-.7 .7 0 1c.2 5.1-3.6 8-5.7 7.8-2.5-.2-3.8-1-4.7-2.1-.9-1.1-1.4-2.7-1.4-4.9l0-6-4.1 4.4c-4.3 4.7-6.7 10.7-6.7 16.7l0 2.4h2.4c3.1 0 6.1 .7 8.9 2.1l-1 3.6c-5.2 4.3-10.5 10.1-13.2 15-.4 .7-.7 1.4-1 2L4.1 113.7l-.4 10.4 10.4-.4 2.2-8c.6-.3 1.2-.6 1.9-1 4.8-2.8 10.6-8 14.9-13.2l3.6-1c1.3 2.8 2 5.8 2 8.8l0 2.3h2.3c6.2 0 12.4-2.3 17.2-6.9l3.5-3.3-4.8-.7c-2.6-.4-4.6-1.4-5.8-2.4-1.2-1.1-1.6-2.2-1.5-3.4 .3-2.8 1-4 2.1-4.8 1.1-.8 2.8-1.1 5.3-1.1l1 0 .7-.7 34.1-34.1 4.7-.1 1.7 0 .5-1.7 1.1-4 8.2-.4 1.7-.1 .5-1.6L122.9 9.2l2-5.1zM116.5 11.2L107.5 43.5 99.2 43.8l-1.7 .1-.5 1.6-1.1 4-3.9 .1-.9 0-.7 .7-34.1 34.1c-2.5 0-4.8 .4-6.8 1.7l.2-4.8 36.1-36.1 6.6-.3L93.7 40.8l.5-1.7 1.7 0 8.1-.2 5.7-20.6-20.6 5.7L88.8 31.4l-.1 1.7-1.7 .5-4.8 1.3-.2 7.6-35.6 35.6-5.3 .2c1.2-1.9 2-4.2 2.1-6.8l33.5-33.4 .7-.6 0-.9 .2-5.4 4.7-1.3 1.7-.5 0-1.7 .2-7.4L116.5 11.2zM23.3 76.9c.3 .8 .8 1.5 1.3 2.2 1.2 1.5 3 2.7 5.1 3.3l-1.1 3.9c-2.5-1.1-5.1-1.8-7.7-2.1 .3-2.5 1.1-5 2.4-7.3zm21.8 5.8l-.4 10.7-14.4 4 4-14.4 10.7-.4zm.7 15.3c.5 1.4 1.4 2.6 2.5 3.7 1 .9 2.2 1.7 3.5 2.3-2.6 1.6-5.4 2.5-8.3 2.8-.3-2.6-1-5.1-2-7.6l4.4-1.2z",
    "ribbon-medal": "M64.2 7.4L60.3 12.9l-5.8-3.5-1.6 6.6-6.7-1 1.1 6.7-6.6 1.6 3.5 5.7-5.4 4L44.4 36.8l-3.5 5.7 6.6 1.6-1 6.7 6.7-1.1 1.6 6.5 5.7-3.5 4 5.4 3.9-5.5 5.8 3.5 1.1-4.5 .5-2 6.7 1-1.1-6.7 6.6-1.6-3.5-5.7 5.4-4-5.5-3.9 3.5-5.7-6.6-1.6 1-6.7-6.7 1.1-1.6-6.5-5.7 3.5-4-5.4zm-.1 12.9a12.4 12.4 0 0 1 12.4 12.4 12.4 12.4 0 0 1-12.4 12.4 12.4 12.4 0 0 1-12.4-12.4 12.4 12.4 0 0 1 12.4-12.4zm14.8 34.3l-2 8.5-7.5-4.6-2.4 3.4c2.9 20.5 4.5 41 13.7 61.8l4.1-16.5c2.6 3.5 6.9 6.5 12.4 8.3-7.8-19.4-10.7-39.7-13.7-60.1l-4.6-.7zm-29.3 .1l-4.9 .8c-3 20.3-5.9 40.6-13.7 60 5.5-1.8 9.8-4.8 12.4-8.3l4.1 16.5c9.2-20.9 10.8-41.5 13.7-62.2l-2.1-3-7.5 4.6-2.1-8.5z",
    "ringing-bell": "M63.5 6.5c-4.3 0-7.9 3.6-7.9 7.9 0 1.9 .7 3.7 1.8 5-2.7 1-4.8 2.7-6.7 5.5-3.3 4.6-5.9 12.3-8.9 23.2-2.6 9.6-6.1 14.3-8.7 17.6-2.6 3.4-4.1 5.1-4.1 10.7 0 .9 .5 1.8 2.1 3 1.6 1.2 4.2 2.3 7.5 3.3 6.5 1.9 15.6 3 25.1 3 4.8 0 9.6-.3 13.9-.8v0c3-.3 8.3-1 12.8-2.6 1.4-.5 2.8-1.1 4-1.9 .7-.3 1.2-.7 1.7-1 1.6-1.2 2.1-2.1 2.1-3 0-5.6-1.5-7.3-4.1-10.7-2.6-3.4-6.1-8.1-8.7-17.6-2.9-10.9-5.6-18.6-8.9-23.2-2.1-2.9-4.2-4.7-7.1-5.6 1.1-1.4 1.7-3.1 1.7-4.9 0-4.3-3.6-7.9-7.9-7.9zm0 4.7c1.8 0 3.2 1.4 3.2 3.2 0 1.8-1.4 3.2-3.2 3.2-1.8 0-3.2-1.4-3.2-3.2 0-1.8 1.4-3.2 3.2-3.2zm2.3 10.8c8.7 2.5 12.4 16.2 14.5 25.4 3.7 16.1 11.4 20.7 13.3 27.8-.1 .2-.3 .3-.5 .6-.7 .7-2.2 1.6-4.1 2.2-1.8 .7-4 1.2-6 1.5-.4-9.5-8.4-13.4-8.3-26.9 .2-15.8-4.3-25.8-9.9-30.4 .4-.1 .7-.1 1.1-.2zm-51.7 22.8C5.9 56 2.8 72.3 7.2 88.8c4.6 17 15.9 29.7 29.1 35-9.6-7.6-18.1-20.8-22.4-37.1-4.2-15.6-3.7-30.6 .3-41.9zm99.9 0c4 11.3 4.4 26.3 .3 41.9-4.4 16.3-12.8 29.5-22.4 37.1 13.2-5.3 24.5-18 29.1-35 4.4-16.5 1.3-32.8-6.9-44zM26.4 52.6c-7.4 8.6-10.6 20.9-7.3 33.1 3.4 12.6 12.7 21.8 23.9 25.3-8-5.4-14.9-15-18.1-27.1-3.1-11.5-2.2-22.8 1.6-31.4zm75.3 0c3.8 8.6 4.6 19.8 1.6 31.4-3.2 12.1-10 21.7-18.1 27.1 11.2-3.5 20.5-12.7 23.9-25.3 3.3-12.2 .1-24.5-7.3-33.1zM36.6 87.1c.3 3.2 3 5.7 6.2 5.7 2.4 0 4.4-1.3 5.5-3.2-4-.5-7.7-1.3-11-2.2-.3-.1-.5-.2-.8-.2z",
    "riposte": "M66.2 3.7 60.9 32.7 33.5 24.7l16.1 20.8C2.2 65.4 14 139 95.8 121.7 68.6 125 16.6 95.5 60.1 71l1.8 18.3L76.2 64.5l28.6 6.7-18.7-21.3 20.1-17.3-27.8 1.4z",
    "robber-hand": "M74.1 5.7c-5.3 0-11 .8-14.2 3.1L42.2 18.3l-9.8 13.4c-2.1 3.2-.6 9.4 5.9 5.4l7.1-9.3c9-7.8 27.3-4.2 18.6 11.4-4.3 9-2.3 13.4 3.2 15.3l2.5-8.4c4.3-9.8 12.5-11.5 12.1-19.4 0 0 44.3 32.3 16.7 70.6-14.6 19.9-51.7 20.9-68.7 11.5C11.8 98.6 1.2 75.1 11.5 54.9c3.2-7.7 3.7-9.9-2.5-.1-11.4 20.4 4.1 55.1 21.7 62.7 24.9 10.8 66.4 2 77.9-12.8 5.5-7.1 11.9-18.1 13.7-30.8 1.9-12.9-.9-24.3-6-35.1C107.1 19.6 87 7.5 87 7.5c-1.3-.9-6.9-1.8-12.9-1.8zm-17.4 22.1c-3.2 0-6.3 1.3-8.5 3.2l-7.1 9.3c1.9 1.5 3.9 .7 5.8-1.2 2.3 1.2 4.1-.6 5.5-4.2 .6-2.5 1.5-4.2 4.3-7.1zm-24.1 15.4c-.4 0-.8 .1-1.2 .3-.8 .4-1.6 1.3-2.4 2.9 3.5 2.4 7.5 5 10.6 8.8 .2-.1 .5-.3 .7-.3 0 0 .1 0 .1 0-.6-4.2-2.7-8.2-4.9-10.2-1.1-.9-2-1.4-2.9-1.4zm14.1 1.9c-1.2 2.1-2.6 4.2-3.3 6.7a14.7 14.7 0 0 0-.6 2.5c.1 0 .1 0 .2 0 .8 0 1.6 .2 2.3 .6 .1-.8 .3-1.5 .5-2.3 .7-2 1.9-4.1 3.1-6.1zm-22.2 1.8c-.5 0-1.1 .1-1.7 .4-.1 0-.2 .1-.2 .1-1.3 .7-2.7 2-3.6 3.4-.9 1.5-1.4 3-1.2 4 .2 1 .6 1.7 2.4 2 4.8 .8 9.7 1.5 14.5 3.1 .5-.9 1.2-1.7 1.9-2.5 .3-.3 .6-.6 .9-.8-3.3-3.8-7.7-6.5-11.5-9.2-.5-.3-.9-.5-1.5-.5zm30.5 4.5c-1.8 0-3.4 .3-4.9 1-1.5 .7-2.8 1.6-4 2.9 .1 .1 .2 .1 .3 .2 .5 .4 .9 1 1.3 1.7 2.2-2.5 4.9-3.5 8.3-3.2l.2-2.5a12.7 12.7 0 0 0-1.2-.1zm-12.1 5.3c-.6 0-1.2 .2-1.9 .5-.1 .1-.2 .1-.3 .2-.8 .4-1.6 1-2.3 1.7-1.4 1.4-2.3 3.3-2.3 4.4 0 .6 .1 .8 .4 1.1 .2 .2 .5 .4 1.1 .5 .5-1.1 1.2-2.1 2-2.9 1.7-1.7 3.6-3 5.6-3.9 .1 0 .1-.1 .2-.1-.2-.3-.4-.6-.7-.8-.6-.5-1.1-.7-1.8-.7zm10.1 2.4c-2.4 0-4.6 .4-6.8 1.4-1.7 .8-3.3 1.9-4.8 3.5-1.6 1.6-2.7 4.8-3.2 8.7-.4 3.9-.1 8.5 .8 12.8 1 4.3 3.2 7.9 4.8 11.1 12.1 24 52.4 2.9 36.6-19-2.6-3.7-5.6-8.4-10.2-11.8-4.6-3.4-9.9-5.9-15-6.5a20.5 20.5 0 0 0-2.4-.1zm-33.2 .2c0 .3-.1 .5-.1 .8-.1 1.6 .3 2.9 .9 3.6 .6 .7 1.4 1 2.9 .6 3.2-.9 7.3-1.5 10.2-1.8a2.3 2.3 0 0 0 .1-.3c-4.5-1.4-9.2-2.1-14-2.9z",
    "round-bottom-flask": "M49.1 4.6l9.9 23.1c3.9 1.3 7.6 1.2 11.5 0l8.6-23.1H49.1zM40.9 8.8l1.1 3.1c2.1 5.7 5.4 11.5 7.2 16.9 1.8 5.4 2.3 10.1-.8 14.4-3.4 4.8-9.6 9.8-15.2 15.6S23 71.7 23 80.9c0 22.7 18.5 41.4 41.2 41.4 22.8 0 41.4-18.6 41.4-41.4 0-9.1-4.7-16.2-10.1-22.2-5.4-5.9-11.7-10.9-15.6-15.6-2.3-2.8-2-8.5-.2-14.7 1.8-6.2 4.8-12.5 6.5-16.3l1.4-3.3H82.5l-8.2 22.3c-1.2 5.5-1.2 11 2.1 15 4.4 5.3 10.6 10.2 15.7 15.8 5.1 5.5 8.9 11.5 8.9 19 0 20.2-16.5 36.7-36.7 36.7-20.2 0-36.6-16.5-36.6-36.7 0-7.5 3.9-13.3 9.1-18.8 5.2-5.5 11.5-10.4 15.6-16.1 4-5.7 3.5-12.2 1.6-18.1l-6.1-14.2c0-.1-.1-.1-.1-.2h0l-2-4.7H40.9zm23.3 50.6c-7.4 0-14.1 1.1-18.7 2.9-2.3 .9-4.1 1.9-5.2 2.8-1 .9-1.3 1.6-1.4 2.1h-.1c0 3.8 2 7.5 5.2 10.5-.1-.1-.3-.1-.4-.2-2.7-1.2-4.9-2.6-6.6-4.2-.6-.5-1.1-1.1-1.5-1.8-1.9 3-3.1 6.4-3.1 10.3 0 17.4 14.2 31.8 31.6 31.8 17.4 0 31.8-14.3 31.8-31.8 0-3.9-1.2-7.4-3.1-10.5-.5 .7-1 1.3-1.6 2-1.7 1.6-3.9 3-6.6 4.2-.1 0-.2 .1-.3 .1 3.3-3 5.2-6.6 5.2-10.5h-.1c-.1-.6-.4-1.2-1.4-2.1-1.1-1-2.9-2-5.2-2.8-4.6-1.7-11.3-2.9-18.7-2.9z",
    "run": "M93.2 6.2c-2.2 0-4.5 .9-6.7 2.6-3.2 2.4-6 6.3-7.6 11.2-1.6 4.9-1.6 9.8-.5 13.5 1.2 3.8 3.3 6.3 6.2 7.2 2.9 .9 6.2 .2 9.3-2.2 3.2-2.4 6-6.3 7.6-11.2 1.6-4.9 1.6-9.8 .5-13.5-1.2-3.8-3.4-6.3-6.2-7.2-.7-.2-1.5-.4-2.2-.4-.1 0-.3 0-.4 0zm-38.9 17.4c-5.4 0-10.8 .6-16.3 1.8-6.2 7.5-11 15.1-13.2 24.6l9.3 4.5c2.1-7.7 5.4-13.5 10.8-19.2 5.7-2 11.4-1.6 17 .4-18.6 16.3-12.8 30.2-20.1 56.6-10.7 4.5-21.3 5.1-30.8 0L5.8 103.9c14.9 6.8 31.4 7.5 47.7 0 5.1-10.9 6.8-22.2 6.2-33.2C73.8 88.7 80.8 99.5 84.7 124.6h14.5c-.8-3.7-1.6-7.1-2.3-10.3-5.6-23-11.8-34.9-25.1-49.6 2.4-9 5.5-14.9 13.1-18.6 2.8 4.9 7.5 9.2 12.8 12.2l24.3 .4 .1-10.3L100.5 48c-2-1.4-3.7-2.9-5.2-4.6-3.7 2.3-8 3.1-12 1.8-4.6-1.5-7.8-5.5-9.3-10.3-.9-2.8-1.2-6-.9-9.3-6.3-1.2-12.5-1.9-18.8-1.9z",
    "rune-stone": "M38.4 5.1L27.3 17.7l15.9 72.8-4.7 .4L23.1 20.3 9.1 34.4 27.6 106.9l10.3-11.8 3.3 3.3-10.9 12.5L80.5 122.9l13.4-12.4-48.1-12.5 1.3-4.5 50 13 26-48.8-17.2-32-67.5-20.6zm20.5 13c20.2 .2 42.2 19.8 38.9 41.2-7-17-23.2-33.2-41.4-28.9-15.8 3.7-1.3 20.1 16.5 24.4C92.4 59.6 115 75.6 100 91.4c-13.8 14.6-39.8 .5-37.7-16.9 4.5 8.2 20.4 21.4 30.2 10.9 13.6-14.8-19.4-23.4-30.6-28.2-11.5-5-34.7-21.5-20.3-33.3 5-4.1 11-5.9 17.2-5.8zm5.5 15.4c1.8 0 3.8 .2 6 .6-6.3 2.8-7.6 7.8-6.4 13.7-12.2-8.9-9.2-14.4 .4-14.3zm35.2 5.3c9.7 4.3 13.4 16.7 2.2 24 1.7-8.1 1.6-16.1-2.2-24zM61.7 61.6c1.3 0 2.7 .4 4 1.1 3 1.7 4.5 4.9 3.3 7-1.2 2.1-4.6 2.4-7.7 .7-3-1.7-4.5-4.9-3.3-7 .7-1.2 2.1-1.8 3.7-1.8z",
    "scar-wound": "M4.4 5c4.2 8 9 15.8 14.1 23.3 2.1 5.5 .9 11.6-9.5 19.1 37.5-10.1 26.6 14.1-2.8 31.6 50-18.6 62.4-14.3 30.3 23.4 25.3-18.4 45.2-13.4 37 9.4 9.5-7.4 17.4-8.9 23.5-6.3 8.7 6.2 17.8 12.1 27.2 17.7-5.1-10.1-10.5-19.8-16.3-29.1-4.5-9.7-5.6-19.8-1.9-28.5-14.2 17.6-22.9 1.3-1.2-21.3-30.6 18.9-44.4 9.5-4.2-26.5-31 16.4-54.9 20.8-39.4 4.6-11.2 3.2-17.5 1.6-22.9-.7C27.9 15.3 16.7 9.7 4.4 5zm12.4 10c7.2 5.4 14.2 11 21 16.8l9.2-2.4-5.5 5.5c3.9 3.4 7.7 6.8 11.5 10.3l18-7.6-4.7 7.3 .1-.1c-5.4 6.9 4.7 21.5 11.5 19.6l8-4.4-6.2 9.1 9.2 13.2c.1 .1 .1 .1 .2 .2 3.4 3.1 7.8 .4 10.8-3.6l-4.9 10.5c5.4 6.4 10.6 12.9 15.7 19.6-5.8-4.1-11.4-8.4-16.9-12.7-5-3-7.9 .1-11.1 4.2 2.2-4.5 3.3-9.2 .8-12.7-.4-.3-.7-.6-1.1-1l-11.2-8.8-11.9 6.6 4.3-6.3c1.8-3.1 .9-6.8-1.4-10.3-2.7-2.7-5.4-5.5-8.1-8.3-.4-.3-.8-.6-1.2-.9l-16.6 4.7 5.4-6.4c2.6-4.4 0-10.4-2.5-13.9-1.4-1.6-2.8-3.3-4.2-4.9l-10.9 1.8c4.6-1.8 7.8-5.6 4.2-10l-.6-.6c.2 .2 .4 .4 .6 .6l.5 .6c-4.1-5.1-8.1-10.4-12-15.7z",
    "scarab-beetle": "M63.9 5.1c-4.6 0-8.6 1.2-11.4 3-2.8 1.8-4.1 3.9-4.1 6 0 2.1 1.3 4.2 4.1 6 1.1 .7 2.3 1.3 3.7 1.7-4.7 1.8-9 5.3-12.6 10.1-.6 .8-1.2 1.7-1.8 2.6 6.8-3.2 14.4-4.7 22-4.7 7.6 0 15.2 1.6 22 4.7-.6-.9-1.2-1.8-1.8-2.6-3.5-4.8-7.8-8.3-12.6-10.1 1.4-.5 2.7-1.1 3.7-1.7 2.8-1.8 4.1-3.9 4.1-6s-1.3-4.2-4.1-6c-2.8-1.8-6.9-3-11.4-3zm-21 2.9c-3.7 0-6.6 2.9-6.6 6.6 0 3.7 2.9 6.6 6.6 6.6 1 0 1.9-.2 2.8-.6-1.5-1.9-2.4-4.2-2.4-6.7 0-2.1 .6-4 1.7-5.7-.7-.2-1.4-.3-2.1-.3zm42.1 0c-.7 0-1.4 .1-2.1 .3 1.1 1.7 1.7 3.6 1.7 5.7 0 2.5-.9 4.7-2.4 6.6 .8 .4 1.8 .6 2.8 .6 3.7 0 6.6-2.9 6.6-6.6 0-3.7-2.9-6.6-6.6-6.6zM14 15C16.5 18.1 17.2 21 17.3 23.8l-5.8-1.2c2 2.7 4 5 4.9 9.8-.3 3.3 0 6.6 2.7 10.1 2.2 3.8 5.3 6.2 8.9 7 .9 .2 1.8 .3 2.7 .3 .3-1.6 .7-3.2 1.1-4.7-1 .1-1.9 0-2.8-.2-2.1-.5-3.9-1.6-5.4-4.1-.6-16.2 8.1-24.6-9.6-25.9zm99.7 0c-17.7 1.3-9 9.7-9.6 25.9-1.6 2.5-3.3 3.6-5.4 4.1-.8 .2-1.6 .2-2.6 .2 .4 1.5 .8 3.1 1.1 4.7 .8 0 1.7-.1 2.5-.3 3.6-.8 6.7-3.2 8.9-7 2.5-3.2 2.9-6.2 2.8-9.2 .9-5.5 3-7.9 5.1-10.8l-6.1 1.2c.1-2.8 .8-5.7 3.4-8.8zM61.6 34.6c-1.5 .1-2.9 .2-4.4 .4l-3 55.3-2.5-54.3c-1.5 .4-3 .8-4.5 1.4l-3.1 39.2-2.5-36.8c-1.2 .6-2.3 1.3-3.4 2-2.2 5.6-3.4 12.1-3.4 19 0 11.4 3.4 21.7 8.8 29 4.8 6.6 11.1 10.7 17.9 11.4V34.6zm4.7 0v66.6c6.9-.8 13.1-4.9 17.9-11.4 5.3-7.3 8.8-17.6 8.8-29 0-6.9-1.2-13.3-3.4-19-.8-.5-1.7-1-2.5-1.5l-2.5 36.3-3.1-38.9c-1.5-.6-3-1.1-4.5-1.5l-2.5 54-2.9-55.2c-1.7-.3-3.5-.4-5.3-.5zm-37.5 23.7c-3.1 0-6.1 1.3-8.7 3.6-4.6 3-5.9 7.7-6.9 12.5-2.2 4.5-4.7 6.3-7.4 8.3l5.2 .3c-1.2 2.9-3 5.5-6.4 7.3 16.7 6 11.9-9.8 19-25.3 2-1.6 3.8-2.2 5.8-2.1 .2 0 .3 0 .5 0 0-.7 0-1.5 0-2.2 0-.8 0-1.6 0-2.5-.1 0-.2 0-.3 0-.3 0-.5 0-.8 0zm70.1 0c-.2 0-.5 0-.8 0 0 0-.1 0-.1 0 0 .8 0 1.6 0 2.5 0 .7 0 1.5 0 2.2 .1 0 .2 0 .3 0 2-.1 3.9 .5 5.8 2.1 7.1 15.5 2.3 31.3 19 25.3-3.4-1.8-5.3-4.3-6.4-7.3l5.4-.3c-2.8-2.2-5.4-4-7.7-9.1-1-4.6-2.4-8.9-6.7-11.8-2.7-2.3-5.7-3.5-8.7-3.6zM33.2 80.9c-1.6 .7-3.1 1.6-4.4 2.7-2.8 2.6-4.3 6.4-4.2 11-.5 3.2 1.7 5.9 5 9 1.7 4.8 1.1 7.8 .7 11.2l5-4.4c.9 3.6 .4 6.3 .1 9.1l5.4-4.8c1.7 2.2 3.4 4.6 4.7 7.4 6-17.9-13.7-19.4-15.7-32 .5-1.2 1.2-2.2 2.1-3.1 .8-.7 1.8-1.3 3-1.9-.7-1.4-1.3-2.8-1.8-4.3zm61.5 .1c-.5 1.5-1.1 2.9-1.8 4.3 1.1 .5 2.1 1.1 2.9 1.8 .9 .8 1.6 1.8 2.1 3.1-1.9 12.6-21.7 14.1-15.7 32 1.3-2.8 2.9-5.2 4.6-7.3l5.3 4.7c-.3-2.8-.8-5.5 .1-9.1l5 4.4c-.4-3.3-.9-6.3 .6-10.9 3.5-3.2 5.9-6 5.3-9.3 .1-4.6-1.4-8.4-4.2-11-1.2-1.1-2.6-2-4.2-2.7z",
    "scroll-unfurled": "M25.9 4.5c-.3 0-.6 0-.8 0-.6 0-1.3 .1-1.9 .2-5 .7-9.8 3.4-13.1 8.4-6.2 9.3 .5 24.5 14.2 24.5 .1 0 .3 0 .4 0v.2h15.1c-2.7 8-7.6 16.6-13.1 25.4-.5 .8-1.1 1.7-1.6 2.6l8.7 8.9-14.1 2.4c-8.2 21.5-6.9 45.5 12.1 45.5v0l2.3 0c6-.1 11.7-1.1 15.3-3.2 1-.6 1.9-1.3 2.6-2.1h-8.1c-5.1 1.5-10.2-1.7-11.8-6.5-2.2-6.4 1.9-13.1 8-15.1 1.5-.5 2.9-.7 4.4-.7v-.1h44.6c-.1-11.1 4.1-22.5 12.3-31.5 6-6.5 10.5-15.2 12.8-23.7l-10.3-6.2 9.6-1.7-10.8-6.5h0l0 0 0 0 13-2.2c-1.3-9.8-7.2-17-19.3-17C85.3 8.1 55.5 8.8 37.3 7.1c-3.7-1.7-7.6-2.7-11.5-2.7zm.1 4.7c3.3 0 6.9 1 10.3 2.7l0 0c1.2 1.2 2.1 2.4 2.9 3.7H20.7l2.6 3.7c2.7 3.7 5 8 5.3 10.5 .2 1.3 0 1.8-.5 2.2-.4 .4-1.6 1-4 1-10.1 0-14.2-11.2-10.3-17.3C16.6 11.7 19.9 9.8 23.8 9.3c.7-.1 1.5-.1 2.2-.1zM29.6 20.2h11.6c1.1 3.9 .9 8.3-.1 12.9H32.9c.5-1.3 .6-2.6 .4-3.9-.4-3-1.9-6-3.7-8.9zm25.4 79.3c1.6 1.7 2.8 3.8 3.3 6.2 .9 4.2 .8 7.8-.4 10.8-1.1 2.8-3.1 4.9-5.6 6.5h59.3c3.6 0 6.2-1.4 8.1-3.6 1.8-2.2 2.8-5.1 2.7-8.1 0-1.1-.2-2.2-.6-3.3l-17.5-2.1 10.5-5.1c-2.1-.9-4.7-1.4-7.8-1.4H55zm-10.7 .1c-.3 0-.6 0-.9 0-.7 .1-1.3 .2-2 .4-3.8 1.3-6.3 5.4-5 9.1 .9 2.6 3.8 4.4 6.4 3.5l.4-.1h10.8c.2-1.6 .2-3.5-.3-5.8-.9-4.1-5.1-7.1-9.5-7.1z",
    "shield-bash": "M68.7 15.8L22.7 20.1l38.5 4.8c1.3-3.3 3.2-6.1 5.6-8a13 13 0 0 1 1.8-1.2zm5 3.2c-1.3 0-2.6 .6-4 1.6-2 1.5-3.8 4.1-4.7 7.4-1 3.3-.9 6.5-.1 9 .8 2.5 2.2 4 3.9 4.6 1.7 .6 3.7 .1 5.7-1.4 2-1.5 3.8-4.1 4.7-7.4 1-3.3 .9-6.5 .1-9-.8-2.5-2.2-4-3.9-4.6a4.8 4.8 0 0 0-1.7-.2zm41.7 2.4c-6 3.5-11.5 5.1-21.8 4.3L85.1 57.1c-.2 .7-.1 1.5 .5 2.7 .6 1.2 1.6 2.7 3 4.4 2.5 3.1 6.1 6.8 9.9 11.1 3.6-1.4 7.1-3.2 9.7-5 3-2 5.1-4.2 5.5-5l10.5-29.6c-4.2-3.7-7.4-8.5-8.9-14.4zm-72 12.8L5.9 39.6l22.3 3.2 .5-1.3zm71.6 .6l4.2 1.5-9.8 27.3-9.3 4.8-2.1-4 7.7-4zm-65 1.1l-17.6 9-7.3 17.1 4.8 2.2 6.2-14.4 14.8-5.7-3.7 19-.2 .4c-8.2 12.5-17.9 23.4-29.6 33.6L10.7 108.2l4.3 1.8 8-11 .3-.2c11.4-7.5 19-15.6 28.1-23.6l1.1-1 1.4 .7c5.8 2.9 10.7 6 15.5 9.4l2.2 1.6-17.3 16.4 6.2 9.9 4.4-2.6-5-7.1 2.1-1.3c7.5-4.5 12.5-9.9 18-16.5-5.9-8.9-10.5-12.4-17.9-17.8l2.5-1.8c8.7-6.3 9.5-13.6 10.4-19.9-2.3 1.1-4.9 1.4-7.4 .6-3.4-1.1-5.7-4.1-6.9-7.6 0-.1-.1-.3-.1-.4zm29.2 11.3c-.3 1.8-.8 3.5-1.5 5.3l3.5 2.4 1.5-5.6zm-43.6 24.4l-31.7 4.5 24.9 3.5a149.7 149.7 0 0 0 6.8-8zm22.9 20.7l-24 5.4 14.9 3.3z",
    "shield": "M64 4c6.2 6 25 18 37.5 18v24c0 24-18.8 60-37.5 78-18.8-18-37.5-54-37.5-78V22c12.5 0 31.2-12 37.5-18z",
    "shouting": "M64.2 8.5c-8.2 0-15.7 4.9-21.3 13.3-5.6 8.4-9.2 20.1-9.2 33.2s3.6 24.8 9.2 33.2c5.6 8.4 13.2 13.3 21.3 13.3s15.7-4.9 21.3-13.3c5.6-8.4 9.2-20.1 9.2-33.2 0-13-3.6-24.8-9.2-33.2-5.6-8.4-13.2-13.3-21.3-13.3zM16.1 31.9c-9.5 13.8-13.1 31.4-8.4 48.8 6 22.2 23.8 38 44.8 42.6C36.5 115.1 22.5 97.6 16.5 75c-4.1-15.2-3.9-30.3-.4-43.1zm96.2 0c3.5 12.8 3.7 27.9-.4 43.1-6.1 22.6-20 40.1-36 48.2 21.1-4.5 38.9-20.3 44.8-42.6 4.7-17.4 1.1-35-8.4-48.8zM29.6 41.9c-6.9 10.1-9.5 22.9-6.1 35.6 4.3 16.2 17.3 27.7 32.6 31C44.5 102.6 34.3 89.9 29.9 73.4c-3-11.1-2.8-22.1-.3-31.4zm69.1 0c2.6 9.3 2.7 20.3-.3 31.4-4.4 16.5-14.6 29.2-26.3 35.1 15.3-3.3 28.3-14.8 32.6-31 3.4-12.7 .8-25.5-6.1-35.6zm-49.5 .5c5-.1 9.7 2.1 13 6.3l-3.7 2.9c-4-5.1-9.7-6.2-16.2-2.6l-2.3-4.1c3-1.7 6.1-2.5 9.1-2.6zm29.3 .1c.2 0 .3 0 .5 0 3 0 6.1 .9 9.1 2.6l-2.3 4.1c-6.5-3.7-12.2-2.5-16.2 2.6l-3.7-2.9c3.2-4 7.7-6.2 12.5-6.3zm-14.4 16.7c10.5 0 19.1 8.6 19.1 19.1 0 10.5-8.5 19.1-19.1 19.1s-19.1-8.5-19.1-19.1 8.6-19.1 19.1-19.1z",
    "skeleton-key": "M33.3 4.6c-5.3 0-10.9 2-15.9 5.8-.7-.3-1.4-.4-2.1-.5-2.6-.2-5.3 .8-7 3-2.2 2.8-2.4 6.6-.6 9.5-4.9 10.3-3.4 21.7 4 27.7 5.6 4.5 13.1 5.2 20.6 2.3l1.3-.5 1.1 .9 11.6 9.5L50.5 57l-11-8.9 2.9-3.6 11 8.9 3.8-4.7-11-8.9 2.9-3.6 11 8.9 4.1-5.1-11.6-9.5-1.1-.9 .2-1.3c1.3-7.9-.9-15.2-6.5-19.7-3.4-2.7-7.6-4.1-12.1-4zm-.6 6.4l11 3.5L34.9 25.2l-6.1-1.9 3.9-12.4zM14.5 14.4c.1 0 .3 0 .4 0 .7 .1 1.3 .3 1.9 .8 1.5 1.2 1.7 3.4 .5 4.9-1.2 1.5-3.4 1.7-4.9 .5-1.5-1.2-1.7-3.4-.5-4.9 .7-.8 1.6-1.3 2.6-1.3zm14.2 14.9l13.8 2.9-8.2 10.1-5.7-13zM22.8 30.8l3.1 5.5-8.8 10.9-5.6-10L22.8 30.8zm38.8 20l-5.5 6.8 31.3 25.4-6.1 7.6 4.4 3.6 5-6.1 3.6 2.9-5 6.1 3.3 2.7-4.2 5.1-9.5 11.1 3.5 3 8.1-9.5 4.8 2 5.7-7 3.6 2.9-10.3 12.6 4.5 3.7 15.4-18.9 3.9 3.1 5.5-6.8L61.6 50.8z",
    "smoke-bomb": "M71.3 5.4c-5.1 0-9.9 1.7-13.2 4.5a13.2 13.2 0 0 0-7.5-2.3c-6.9 0-12.7 5.4-13.2 12.2-4.5 1.2-7.7 5.3-7.7 10.2 0 .6 .1 1.3 .2 1.9a10.5 10.5 0 0 0-1.1 4.7c0 5.8 4.7 10.5 10.5 10.5a10.6 10.6 0 0 0 1.8-.2 10.5 10.5 0 0 0 1.3 2c-4.3 .8-6.8 4.3-5.8 9-2.3 1.2-4.2 1.6-4.3 4.6-.1 2.5 1.2 4.8 3.3 6.4-2.1 1.6-3.3 3.9-3.3 6.4 0 2.8 2.6 5.4 4.4 7.1-1.9 2.4-2 6.2-.1 9.5a10.5 10.5 0 0 0 .6 .9l-3.7 12.3 12.1-7.6c1.8-.1 3.3-.2 5 0 2.5 0 4.8-1.1 6.6-3.1 .4 0 .8 .1 1.2 .1 6.4 0 11.5-5.2 11.5-11.5 0-.7-.1-1.5-.2-2.2a11.5 11.5 0 0 0 7.7-7.1 13.3 13.3 0 0 0 5.7-3.6c6.9 0 12.9-5 14.3-11.7 3.7-2.6 6-6.7 6.2-11.3 4.4-1.7 7.4-5.9 7.4-10.8 0-6.1-4.8-11.1-10.7-11.5-.9-5.5-5.7-9.6-11.4-9.6-.3 0-.5 0-.8 0-1.9-5.9-8.8-10.1-17-10.1zm0 3.8c7 0 13 3.8 13.6 8.6l0 .2a12.8 12.9 58.2 0 0-8.9-3.5 12.8 12.9 58.2 0 0-10.7 5.7 12.8 12.9 58.2 0 1 8.7-3.4 12.8 12.9 58.2 0 1 12.9 12.8 12.8 12.9 58.2 0 1-2.2 7.2 12.8 12.9 58.2 0 0 4.2-9.5 12.8 12.9 58.2 0 0-2.5-7.6c.9-.2 1.7-.4 2.7-.4 4.2 0 7.7 3.4 7.7 7.7l0 2.2c1-.1 1.9-.2 2.9-.3 4.2 0 7.7 3.4 7.7 7.7 0 3.6-2.4 6.7-5.9 7.5l-1.6 .4c0 .7 .1 1.4 .1 2.1 0 3.8-1.9 7.3-5.2 9.3l-.8 .5-.1 .9c-.8 5.3-5.4 9.3-10.7 9.3-.5 0-1.1 0-1.6-.1l-.6 .8c-1.4 1.7-3.9 3-6.4 3.5-.9 3.5-3 5.8-7.2 6.9l-2.7 .2 1 2.5a7.6 7.6 0 0 1 .6 3c0 4.2-3.4 7.7-7.7 7.7-.9 0-1.9-.2-2.8-.4-1.4 1.9-2.4 3-5 3.4-1.9 0-4.1-.4-6.2 0l-4.3 2.7 .9-3.1 .5-1.4c-.6-.7-1.1-1.2-1.6-2-1.3-2.3-1.1-4.9 .4-5.8a2 2 0 0 0 1-1.5c.1-1.1-.5-1.7-1.6-2.7-1-.9-3.6-3.3-3.6-4.7 0-1.9 1.6-3.7 4.1-4.6l5.4-1.8-5.4-1.8c-2.5-.8-4.1-2.6-4.1-4.6 0-1 3.3-2 4.2-3-.8-3.3 .1-6.1 4.1-6.9 .9 0 1.9 .3 2.9 .5 .8-1.3 1.6-2.5 2.7-3.6l-2.2-1a6.7 6.7 0 0 1-3.6-4.3l-.5-2c-1.5 .6-2.7 1.1-4.3 1.1-3.7 0-6.7-3-6.7-6.7 0-1.2 .3-2.4 1-3.4l.4-.7c-.2-.9-.4-1.6-.4-2.5 0-3.4 2.6-6.3 6-6.7l1.8-.2c0-.8-.1-1.5-.1-2.3 0-5.2 4.2-9.4 9.4-9.4 2.4 0 4.6 .9 6.3 2.5l1.4 1.3 1.3-1.4c2.5-2.8 6.9-4.5 11.6-4.5zM49.5 23.6a8 9.2 23.5 0 0-8.1 5.9 8 9.2 23.5 0 0 3.7 11.7 8 9.2 23.5 0 0 .5 .2 7.4 8.6 23.5 0 1-2-9.9 7.4 8.6 23.5 0 1 10.2-4.9 7.4 8.6 23.5 0 1 .3 .1A7.1 6.1 9.3 0 0 50.8 31.1a7.1 6.1 9.3 0 0 0 .4 7.8 6.1 5.7 0 1 7.5-2.8 7.8 6.1 5.7 0 1 6.5 4.3 7.1 6.1 9.3 0 0 0-.2 7.1 6.1 9.3 0 0-6.3-6.9 7.1 6.1 9.3 0 0-1.2-.1 7.1 6.1 9.3 0 0-2.2 .3 8 9.2 23.5 0 0-2.7-2.1 8 9.2 23.5 0 0-2.9-.6zm12.5 34.8a10.1 8.7 14.8 0 0-9.3 6.2 10.1 8.7 14.8 0 0-.2 1.7 9.2 7.9 18.1 0 1 0-.1 9.2 7.9 18.1 0 1 11.2-4.7 9.2 7.9 18.1 0 1 6.3 10.4 9.2 7.9 18.1 0 1-1.8 2.9 10.1 8.7 14.8 0 0 4.1-5 10.1 8.7 14.8 0 0-7.5-11 10.1 8.7 14.8 0 0-2.7-.4zm-33.2 40.3c-6.6 0-11.9 5.3-11.9 11.9 0 6.6 5.3 11.9 11.9 11.9 6.6 0 11.9-5.3 11.9-11.9 0-1.7-.4-3.4-1-4.8-.4-.8-4.6 4.8-8.3 2.3-1.8-1.2-.5-5 .4-7.2 .4-1 .6-1.6 .5-1.7a11.9 11.9 0 0 0-3.5-.5zm-3.8 4.1c.3 .1-2.3 3.5 .3 9.2 .5 1.1-.1 2.5-1.2 3-1.2 .5-2.5 0-3-1.2-.5-1.2 0-8.3 3.8-10.9 .1-.1 .2-.1 .2-.1z",
    "sparky-bomb": "M64.9 4.8L44.7 22.2l-19.2-11.5 2.2 22.2-22.2 7.2 23.2 10.4L18.3 81.3 39.8 63.5l4 23.8 7.9-12.5 3.3 3.3c-1.1 3.3-1.7 6.8-1.7 10.6 0 19.1 15.4 34.7 34.6 34.7s34.7-15.6 34.7-34.7c0-19.1-15.6-34.6-34.7-34.6-3.9 0-7.7 .7-11.3 1.9l-1.6-1.6 16.6-6.6-22-6.6 18.4-16.2-27.1 1.9 4.1-22.1zM4.4 17.8l5.3 7.8 9 .8-5.6-8.2-8.7-.3zm101.7 4.5l-18.5 11.3 16.6-2 7.6-4-5.7-5.3zM42.9 37.5l4.6 .4c-.6 6.2 1.3 8 4.6 10.9 2.5 2.2 6 4.7 8.9 9l5.3-5.3 7.8 7.8 1.1 1.1 1.4-.6c3.1-1.2 6.5-1.9 10.1-2-1.7 .7-3.3 1.8-4.6 3.1-3.3 3.3-4.7 7.9-4.4 12.8l9.5 1.2-.5-12.1 9.5 10 11.3-5.7-3 11.9 11.4 4.5-13.4 5 1.8 10c4.1-.1 7.9-1.6 10.8-4.5 .9-.9 1.6-1.8 2.2-2.9-1.7 14.9-14.4 26.5-29.8 26.5-16.6 0-29.9-13.4-29.9-30 0-3.7 .7-7.1 1.9-10.4l.5-1.4-1.1-1.1-8-8 6.5-6.5c-2.5-4.1-5.7-6.3-8.6-8.9-3.6-3.2-6.9-7.4-6.2-14.9zM21.3 56L8.8 60.6l-3 8 9.4-2L21.3 56zm15.9 26.9L30.7 99.6l3.8 8.1 4.3-9-1.8-15.9z",
    "spell-book": "M79.9 5.2c3.3 8.3 3.3 8.3-1.4 15.9 8.3-3.3 8.3-3.3 15.9 1.4-3.3-8.3-3.3-8.3 1.4-15.9-8.3 3.3-8.3 3.3-15.9-1.4zM28.3 9.5c-3 5.3-3 5.3-8.9 6.1 5.3 3 5.3 3 6.1 8.9 3-5.3 3-5.3 8.9-6.1-5.3-3-5.3-3-6.1-8.9zm19.1 14c-.2 12.6-.2 12.6-10.5 20 12.6 .2 12.6 .2 20 10.5 .2-12.6 .2-12.6 10.5-20-12.6-.2-12.6-.2-20-10.5zm47.8 14c0 6 0 6-4.8 9.6 6 0 6 0 9.6 4.8 0-6 0-6 4.8-9.6-6 0-6 0-9.6-4.8zm-46 21c-.3 0-.6 0-.9 0-4.6 .3-10.5 2.1-19.4 5.6L19 108.4c19.6-5.2 33.2-5.5 42.7-1.2V61.9c-4.5-2.2-7.9-3.3-11.7-3.4a22.8 22.8 0 0 0-.9 0zm30.7 2.9c-.7 0-1.5 0-2.1 0-3.2 .1-6.9 .6-11.5 1.1V106.8c10.9-2 26.7-1.1 42.8 1.9l-9.9-44.3c-9-2.1-14.1-3-19.3-3zm.6 4.2c4.7 .1 9.2 .7 13.4 1.3l1.1 4.1c-5.9-.9-16.5-1.2-23.1-.2l-.2-4.5c3-.5 5.9-.7 8.7-.7zm-62.6 1.2l-2.7 11.5h6l2.6-11.5H17.8zm86.5 0l9.9 44.3 .6 2.5 5.6 0-10.2-46.7h-5.9zm-19.7 14.5c4.2 0 8.4 .2 12.3 .6l.9 4.3c-8.2-.8-18.1-.7-25.7 0l-.2-4.3c4.2-.4 8.5-.6 12.8-.6zm-70.4 1.5l-1.7 7.5h6.1l1.7-7.5H14.1zm68.6 6.8c1.2 0 2.4 0 3.7 .1l.6 4.4c-5-.1-11.8 .1-14.9 .3l-.2-4.5c4.2-.1 7.3-.2 10.8-.2zm10.4 .1c2.1 0 4.2 .1 6 0l.6 4.4c-2.2-.1-6.2-.2-8-.1l-.7-4.3a64.3 64.3 0 0 1 2 0zm-81.7 5.1l-4.5 19.5 6.3 0 4.4-19.4H11.3zm75.8 3c4.9 0 9.7 .2 14.1 .6l.7 5.2c-8.6-1.1-21.4-1.9-29.8-.8l0-4.5c5-.3 10-.5 14.9-.5zm-41.7 11c-7.5 0-17 1.6-28.9 4.9l-1.8 .5 46.9-.3v-1.6c-4.1-2.3-9.4-3.6-16.3-3.5zm33.6 1.5c-4.9 0-9.3 .4-12.8 1v2.5l44.4-.3c-11.1-2.2-22.3-3.3-31.6-3.3zM6.5 118.8v4.5h115v-4.5H6.5z",
    "spider-web": "M5.1 4.6L19.4 22.6C18.7 34.8 13.5 44.1 6.3 52.7l-1.7-.4v4.8l.6 .2c3.8 11.3 2.3 22.7 .5 34.6l-1.1 .5v5.2l2.3-1.1c1.6 2.7 3.4 6.8 4.8 10.3 1.1 2.8 1.9 5.2 2.3 6.6l-9.4 9.4v.6h6l7.1-7.2c2.3-.1 10.4-.4 20.7-.2 11.7 .2 25.7 1.1 34.8 3.4l1.3 3.9h4.9l-1.9-5.8c9-10.4 18-20.1 32.9-25.6l12.9 5.1v-5l-10.7-4.3c-1.6-9.8 3.2-19.2 7.7-29.2l3.1-.6v-4.8l-1.6 .3-1.4-.7C106.4 45.7 101.4 33.4 97.1 19.7l11-15.1h-5.8l-9.7 13.2c-14.6 .3-28.1-.6-38.6-9.4l-.6-3.8h-4.7l.7 4.7C42.7 16.6 35.1 21.3 23.4 20.1l-12.3-15.5H5.1zm50 10.3c10.2 6.6 22.1 7.7 34.2 7.7l-8.3 11.3c-9.1 .1-17.5-.8-24-6.2l-1.9-12.8zm-4.7 .1l2.1 13.7c-4.5 4.7-9.3 7.5-17 6.7L27.2 25c9.6-.2 17.1-4.3 23.2-10zM93.7 24.4c3.9 11.7 9.3 23.2 21.1 30.7l-12.9 2.7-.2-.1c-9.3-4.8-12.6-12.9-15.5-22.2l-.2-.6 7.7-10.5zm-70.2 3.5l8.6 10.8c-.6 7.4-3.9 13.2-8.3 18.6L11.2 54c5.9-7.4 10.7-15.8 12.3-26.1zm34.5 6.2c6 3.4 12.8 4.3 19.6 4.5l-8.2 11.3c-3.8-1.6-6.5-4.4-9.6-7.6l-.6-.6-1.1-7.6zm-4.7 .2l1.4 9.2c-2.8 1.9-6.1 3-9.8 3.9l-5.7-7.2c5.7-.3 10.3-2.7 14.1-5.9zm29.3 5.3c2.4 7.3 5.8 14.5 12.6 19.6l-14 2.9c-3.2-2.8-5-6.2-6.8-10l-.4-.9 8.5-11.7zm-46.6 4.1l4.8 6 0 .2c-.5 4.3-2.2 7.4-4.2 10.8l-7.9-2.1c3.3-4.3 6-9.2 7.3-14.9zm19.4 4.8l1.5 9.9c-.9 .2-1.8 .5-2.6 .9l-6.3-7.9c2.5-.7 5-1.6 7.4-2.9zm4.8 .8c1.8 1.6 3.9 3.2 6.3 4.3l-4 5.4c-.3-.1-.6-.2-.9-.3l-1.4-9.4zm-15.7 5.2l6.2 7.9c-.4 .5-.7 1.1-1 1.8l-8.5-2.2c1.2-2.2 2.5-4.6 3.3-7.4zm26.4 1c1.3 2.6 2.8 5.3 4.9 7.7l-7.8 1.6c-.4-1.1-1-2.2-1.7-3.1l4.6-6.3zM10.5 58.6l12.2 3.2c2.3 7.1 1.4 14.3 .3 21.9L10.8 89.4c1.5-10 2.6-20.4-.2-30.8zm104 1.3c-3.7 8.2-7.5 16.7-6.9 26l-10.9-4.3c-.9-6.3 2.2-12.4 5.2-19.1l12.6-2.6zm-86.6 3.3l6.9 1.8 .1 .3c1.5 3.8 1.3 7.9 .7 12.4l-7.6 3.5c.8-5.9 1.2-12-.2-18.1zm68.3 .6c-2.3 5-4.4 10.2-4.3 16l-9.1-3.6c0-3.3 .3-5.7 2.3-8.5l1.2-1.8 9.9-2.1zm-56.1 2.7l8.8 2.3c.1 .9 .2 1.8 .5 2.6l-8.8 4.1c.3-3 .2-6-.5-9zm39.8 .8c-1.2 2.4-1.6 4.7-1.7 7.1l-9.8-3.9c.1-.3 .1-.6 .2-.9l11.4-2.4zm-13.7 7.4l9.1 3.6c-2.2 1.1-4.3 2.6-6.2 4-1 .7-1.8 1.4-2.5 2l-2.5-7.8c.8-.5 1.4-1.1 2-1.8zm-14.5 .9L42.3 84.9c-.6-1.6-1.5-2.8-2.4-3.8l0-.1 11.8-5.5zm4.4 2.2c.8 .2 1.7 .4 2.7 .4 .3 0 .7 0 1-.1l2.6 8.1c-3.3 0-9.4 0-15.4 .8l9.2-9.2zm25.9 3.2l6.3 2.5c-7.3 3.7-12.6 9-17.3 14.3L68.3 89c.9-.8 2.2-1.9 3.8-3.1 2.9-2.2 6.6-4.4 8.9-4.9l1.1-.2zM35.4 83l.4 .4c1.5 1.5 2.5 2.6 2.8 5.2l-7.8 7.8c-.1-.6-.2-1.2-.3-1.8-.5-2.7-1.1-5.7-2.3-8.2l7.2-3.4zm59 2.6l9.8 3.9c-12.4 5.6-20.7 14.2-28.4 22.9l-3.1-9.7c6-7 11.9-13.4 21.7-17.1zM23.9 88.4c.8 1.7 1.6 4.5 2 7.1 .4 2.2 .6 4 .7 5.1l-9 9c-.4-1.2-.9-2.7-1.6-4.6-1.3-3.6-3-7.5-4.9-10.7l12.7-6zm37.7 2.3c1 0 1.7 0 2.3 0l2.6 8.1c-6.6-1-14.7-1-21.8-.8-3.9 .1-7 .3-9.5 .5l6-6.1 .2-.1c5.9-1.4 15-1.7 20-1.7zm-10.5 11.8c6.2 0 12.6 .3 17.1 1.3l3.4 10.4c-9.7-2.1-22.2-2.7-33-2.9-6.8-.1-12.3 0-16 0l7.7-7.7c1.9-.2 7.7-.7 14.7-1 2-.1 4-.1 6.1-.1z",
    "spiked-halo": "M64.4 4.8l-11.9 21.4c-12.9 4-22.9 14.4-26.5 27.5L8.4 63.1l17.3 9.6c1.5 6.6 4.6 12.5 8.9 17.4 1.4-2 3.1-3.8 5.1-5.3-4.8-5.6-7.7-12.9-7.7-20.9 0-17.8 14.5-32.1 32.2-32.1 17.8 0 32.1 14.4 32.1 32.1 0 7.5-2.6 14.4-6.9 19.9 2.1 1.5 3.9 3.2 5.4 5.1 3.8-4.6 6.6-10.1 7.9-16.2l17.6-9.8-18-9.5c-3.6-13.1-13.7-23.5-26.7-27.5L64.4 4.8zm.1 37.6c-4.4 0-8.4 2.3-11.5 6.2-3.1 3.9-5 9.4-5 15.6 0 6.5 2.3 12.3 5.7 16.3l2.5 2.9-3.8 .9c-9.5 2.2-14 6.6-16.6 13.6-2.4 6.5-2.9 15.4-3 26.1h63.6c0-10.7-.2-19.8-2.4-26.5-2.4-7.1-6.8-11.6-17-13.6l-3.8-.7 2.5-3c3.2-3.9 5.3-9.6 5.3-15.9 0-6.2-2-11.7-5-15.6-3.1-3.9-7.1-6.2-11.5-6.2h0z",
    "spiral-hilt": "M57 6.2c-1.6 1.7-3.1 4.2-3.9 6.5-.7 2.2-.7 3.8 0 5h21.7c.7-1.2 .7-2.9 0-5-.8-2.3-2.3-4.7-3.9-6.5zm-3.9 16c-1.1 1.5-1.8 3.6-1.8 5.8s.7 4.3 1.8 5.8h21.8c1.1-1.5 1.8-3.6 1.8-5.8s-.7-4.3-1.8-5.8zm0 16c-1.1 1.5-1.8 3.6-1.8 5.8s.7 4.3 1.8 5.8h21.8c1.1-1.5 1.8-3.6 1.8-5.8s-.7-4.3-1.8-5.8zm.1 16c-.4 .8-.9 2.1-1.2 3.7C51.5 60.2 51.2 63.1 51.2 66c0 1.2 0 2.3 .1 3.4 5.8 3.2 10.5 6.3 12.6 7.8 2.1-1.5 6.8-4.6 12.6-7.8 .1-1.1 .1-2.3 .1-3.4 0-2.9-.2-5.8-.7-8.1-.3-1.6-.8-2.9-1.2-3.7zM21.8 64c-2.2 0-4.3 .4-6.2 1.4-4.1 2.3-7.4 7.5-8.8 13.3-1.4 5.8-.9 12.1 1.6 16.1 2.2 3.5 6.9 6 12.2 6.9 5.3 1 11 .4 14.3-1.3C38.2 98.9 38.8 96.4 38.8 93.8c0-2.5-.7-4.6-.8-4.9-2-3.9-3.9-7.3-5.9-9.2-2.1-1.9-3.9-2.6-7.3-1.6-2.1 .9-5.4 2.9-5 5.5C20.7 87.2 24.3 89.7 28 89.8v4.5c-2.6 0-5.4-1-7.8-2.6-2.4-1.6-4.5-4.1-5-7.3 .9-10.4 13.3-13.6 19.9-7.9 2.8 2.6 4.7 6.1 6.6 9.9L64 96.4l22.3-10c1.9-3.8 3.9-7.4 6.6-9.9 6.6-5.7 19-2.5 19.9 7.9-.5 3.2-2.6 5.7-5 7.3C105.4 93.3 102.6 94.2 100 94.2v-4.5c3.7-.1 7.3-2.5 8.4-6.1 .3-2.6-2.9-4.6-5-5.5-3.4-1.1-5.2-.4-7.3 1.6-2.1 1.9-4 5.3-5.9 9.2-.1 .2-.8 2.4-.8 4.9 0 2.6 .6 5.2 3.8 6.7 3.3 1.7 9 2.2 14.3 1.3 5.3-1 10.1-3.5 12.2-6.9 2.5-4 3-10.3 1.6-16.1-1.4-5.8-4.7-11-8.8-13.3-1.9-1-4-1.4-6.2-1.4-2.2 0-4.4 .3-6.4 .7-5.1 1.1-10.6 3.3-15.8 5.9-8.7 4.3-15.7 9.1-20 10.6-4.3-1.5-11.4-6.3-20-10.6-5.1-2.5-10.7-4.8-15.8-5.9-2-.4-4.3-.7-6.4-.7zm28.5 31.6V123.5h7v-16.1l3.6-6.5zm27.5 0l-10.6 5.3L70.8 107.4V123.5h7zm-13.8 8.9l-2.2 4V123.5h4.5v-14.9z",
    "sprint": "M42.4 4.1L64.8 22 84.2 23.1l-.3 4.7-40.3-2.2-29.7-1.2 56.8 17-49.4 61.7-3.6-4.4-12.3 24.2 62.2-50.7 13 2.9-9.7 10.1L67.6 82.4l-14.3 21L111.2 68.4 82 60.3l25.1-20.4c.3 .1 .6 .2 .9 .3 5.8 1.6 12.4-4.2 14.8-12.9 2.3-8.7-.5-17-6.4-18.5-5.8-1.6-12.4 4.2-14.8 12.9-.4 1.4-.6 2.7-.7 4.1L42.4 4.1z",
    "stairs": "M16 112v-16h16v-16h16v-16h16v-16h16v-16h16V16h16v96z",
    "stone-wall": "M4.5 5.8l0 4.5H123.5V5.8H4.5zM63.6 13.7L33.2 15.4l7.5 17.1 24.5-.9-1.7-17.9zm29 .1l-23.2 .1 .8 18 24.2-.2-1.7-17.9zM4.6 14.1l.1 18.7 18.1-.6 6.1-18.1H4.6zM98.2 16.1l-.1 11.8 3.9 5.4 21.4-1.6V16.2l-25.2-.2zM30.2 21.2l-4.4 12.5 10.3-.2-2-8.5-3.8-3.7zm88.7 14l-1 18.9 5.6-.1v-18.7h-4.6zm-6.4 .9l-24.3 2.7L86.5 54.8l27.7-.8-1.7-17.9zm-61 .2l-1 18.9 31.5-1 1.8-17.8-32.3-.1zm-36.3 .7l-1 18.9 31.5-1-1.7-17.9H15.2zm-10.5 .4l.1 18.1 6.2-.2-1.7-17.9h-4.5zm69.7 21.1L69 69.3l.5 10.5 32.2-.5-1.9-19.9-25.4-1.1zm-10.1 .3l-31.8 1.5 2 17.4 31.2 1.6-1.4-20.5zm59.1 .8l-16.6 .7-1.9 18.9 18.5-1.3v-18.4zm-118.7 1.8l.1 16.4 25.2-.8-1.7-15.7H4.8zm117.6 20.3l-29 2.6-.8 16.2 30.4-.9-.6-18zm-105.6 1l-11.9 .5 .1 18.2 12.8-.3-1-18.4zm4.5 0l1 17.1 34.7 2.4-.8-19.5H21.2zm40.3 1.1l-1.4 17.2 26.9 1.4-.2-18.4-25.2-.2zm46.4 20.3l-1 18.9 16.6-.1v-18.4l-15.6-.3zm-2.5 .3l-9.8 .9 6.8 7 2.9-7.9zm-99.9 .5l-.5 10.2 0 8.7H36.4v-17.2l-11.6-.6-4.6 3.5L17.1 105.2l-11.6-.6zm62 .1l-27.8 .4 .9 18.1 28.7-.6-1.7-17.9zm25.3 1.1l-18.1 1.5-2.2 15.5 31.4 .1-1.6-6.8-9.6-10.4z",
    "stun-grenade": "M63.7 5.1c-4.2 0-8.1 1-11.1 2.8-3 1.8-5.2 4.6-5.2 7.9 0 3.3 2.2 6.1 5.2 7.9 3 1.8 6.8 2.8 11.1 2.8 2.9 0 5.5-.5 7.9-1.3l-4.7 4.7L97.6 60.7l5.3-5.3-30.5-30.5c.8-.3 1.6-.7 2.3-1.2 1.6-1 3.1-2.3 4-3.8l4.7 4.7-2.5 2.5 26.9 26.9 4.1-12.2-22.9-22.9-2.5 2.5-6.8-6.8c-.5-2.8-2.5-5.1-5.1-6.7-3-1.8-6.8-2.8-11.1-2.8zM89.8 8.3l-2.5 2.5L117.2 40.6l-6.2 18.7-35.7 41.2 2.5 2.5L118.3 57.1l5.1-15.2L89.8 8.3zm-26.1 1.3c3.5 0 6.6 .9 8.7 2.2 2.1 1.3 3 2.7 3 4.1 0 1.3-.9 2.8-3 4.1-2.1 1.3-5.2 2.2-8.7 2.2-3.5 0-6.6-.9-8.7-2.2-2.1-1.3-3-2.7-3-4.1 0-1.3 .9-2.8 3-4.1 2.1-1.3 5.2-2.2 8.7-2.2zm0 23.5L13.1 83.7 43.9 114.4l50.6-50.6-30.8-30.8zM10 86.8l-5.3 5.3L35.4 122.9l5.3-5.3L10 86.8z",
    "sunbeams": "M4.4 4.5V6.8l7.9 3.3c-1.2 4.2-2 8.5-2.1 13.1L4.4 22.4v15.9l7.2-1c1 4.1 2.5 8.1 4.4 11.8l-11.6 4.8v21.4l19.3-15.1c2.7 3 5.7 5.6 9 7.9L4.4 104.8v18.7h19.8l20.1-49.3c3.6 1.4 7.5 2.3 11.4 2.8l-6.2 46.5H75L68.8 77c4-.5 7.9-1.4 11.6-2.7l20 49.2h23v-14.6L92 68.3c3.3-2.2 6.2-4.8 8.9-7.7l22.4 17.3V55.3l-14.4-5.9c1.9-3.7 3.5-7.6 4.5-11.8l9.9 1.3V21.8l-8.4 1.1c-.2-4.5-.9-8.9-2.2-13l10.6-4.4v-1.1h-28.1l-10.6 8.1c-1.2-2-2.6-3.8-4.2-5.4l2-2.7H41.9l1.9 2.4c-1.7 1.7-3.1 3.6-4.3 5.7l-10.4-8.1H4.4zm104.1 7.3c1.1 3.8 1.7 7.8 1.8 11.9l-22.1 3c0-.3 0-.5 0-.8 0-1.8-.2-3.7-.5-5.4l20.8-8.6zM16.6 11.9l19.7 8.2c-.4 1.8-.5 3.8-.5 5.7 0 .3 0 .5 0 .8L14.8 23.8c.1-4.1 .7-8.1 1.8-11.9zm20.7 21.9c.6 1.9 1.4 3.7 2.4 5.4l-19.5 8.1c-1.8-3.3-3.1-6.9-4.1-10.6l21.1-2.9zm49.5 .3l22 2.9c-1 3.7-2.4 7.3-4.2 10.6l-20.4-8.4c1-1.6 2-3.4 2.6-5.2zm-43 10.4c1.4 1.4 2.8 2.5 4.5 3.5l-12.7 16.4c-3-2.1-5.8-4.5-8.2-7.1l16.4-12.8zm36.1 0l17.4 13.4c-2.4 2.6-5.1 4.9-8.1 6.8l-13.2-17.1c1.4-.9 2.7-2 3.9-3.1zm-9.4 5.7l8.1 19.8c-3.3 1.2-6.8 2-10.4 2.4L65.4 51.6c1.7-.2 3.5-.9 5.2-1.5zm-16.5 .3c1.6 .5 3.4 1 5.2 1.2l-2.8 20.7c-3.6-.5-7-1.3-10.3-2.5l7.9-19.4z",
    "switchblade": "M56.7 58.8l5.4-4.9c-5.4-4.9-9.8-1.4-10.6-.2-2.5 3.8 2.4 2.3 5.2 5.1zm23.1 12.9c-.8 1.2-5.1 4.6-10.4 .1l4.9-5.4c2.8 3.1 8.1 1.4 5.5 5.3zm-7.3-21.9C111.6 10.7 121.5 6.2 121.5 6.2s-3.9 10.6-43 49.7zM8.7 110.1c2.7-1.9 2.7-.9 5.9-3.8l.1 .1 7.2 7.2 .1 .1c-2.8 3.2-1.8 3.1-3.7 5.9a5.1 5.1 0 0 1-7.8 .7l-2.4-2.4a5.1 5.1 0 0 1 .7-7.8zm47.4-45.2l13.3-12.2 6.1 6.1-12.2 13.3zm-38.6 38.6l7.2 7.2 35.3-35.3-7.2-7.2zM46.7 77.1a3 3 0 1 1 0 4.2 3 3 0 0 1 0-4.2z",
    "sword-altar": "M64 6l-5 6 3 4.8v9.7c1.3 .1 2.7 .1 4 0V16.8L69 12l-5-6zm-15.4 21.6l-1.2 3.8c12.2 4.1 21 4.1 33.2 0l-1.2-3.8c-11.8 3.9-19 3.9-30.8 0zM58 38v32h4V38h-4zm8 0v32h4V38h-4zm-12.8 36l-2 4h25.6l-2-4h-21.6zm-20.1 8L17.9 110H110.1l-15.3-28H33.2zm10.8 4h24v4h-24v-4zm28 0h12v4h-12v-4zm-28 8h8v4h-8v-4zm12 0h28v4H56v-4zm-12 8h16v4h-16v-4zM9.4 114L6.8 122h114.5l-2.7-8H9.4z",
    "sword-brandish": "M30.5 4.4L46.6 40.2l26.1-11.2-11.1-24.6h-12.8l8.9 20.2-4.1 1.8-9.8-22zm66.3 19.4L27.6 53.8l3 7 69.5-29.9zm-17.4 24.6l-6 2.9c3.2 1.4 6.5 3.4 9.6 3.9 4.5-3.3-1.2-7.6-3.6-6.8zm-15.2 2.8l-9.1 4.2c-3 4.6-3.7 11.5-4.5 17.4 5.2 7.5 7.6 15.6 9.9 23.5 4.5-.9 8.1-1.7 12.2-2.9-6.1-9.7-10.6-19.6-13.4-29.7 0 0 1.4-2.6 2.1-4 3 1.8 6.2 3.1 9.2 2.5 2.5-1 5.4-2 6.9-4.2-4.4-1.7-9.3-4.4-13.2-6.9zm23.1 6.7c-2.7 1.4-5.8 2.8-8 4.7-1.3 1.2-3 2.2-5.1 3.1 .3 1.8 0 4.9 2 4.7 5.1-1.6 10.1-3.8 14.9-7.1 0-2.3-2-6-3.9-5.4zm-22.6 8.6c2.8 8.7 6.9 17.2 12.3 25.6 1.2-.4 2.3-.8 3.4-1.2-1.8-1.6-2.9-4-3-6.3-4.2-1-5.2-7.3-4.3-10.4-2.4-1.8-3.4-4.5-3.5-7.2-1.8 .2-3.4 0-4.8-.5zm25.8 2.6c-3.4 2-6.9 3.6-10.4 4.8l-2.2 1.1c-1.1 1.1-1.1 3.9 .2 5.1 2.4 .9 12.5-5.3 14.4-7 .3-1.4-.9-3.7-2-4zm-44.5 5.3L4.8 84V123.8c23.9-6.3 36.7-11.8 52.4-22.6-2.7-9.5-5.1-18.7-11.1-26.9zm47 4.2c-3.4 2.5-6.8 4-10.7 5.3-.1 1.7 .6 4.5 3 4 5-1.1 9.1-4.4 9.2-6.2 .1-.9-.5-2.6-1.4-3.2zm-1.9 12.2c-3.6 2-7.9 4-11.7 5.3l4.7 8 9.8-4.7zm5.5 12.3L85.7 108.2l.8 5.5c3.8 .1 11.7-2.8 13.8-6.5v0z",
    "target-arrows": "M6.9 6.4C9.2 15.7 13 25.1 17.3 34.5c4.4-7.9 10.3-13.2 17.9-17.6C25.7 12.6 16.3 9.1 6.9 6.4zm114.1 0c-9.4 2.6-18.8 6.2-28.3 10.4 7.6 4.4 13.5 9.7 17.9 17.6 4.3-9.4 8-18.8 10.4-28zm-91.8 20.3c-.9 .8-1.7 1.6-2.6 2.5L58 60.7l2.6-2.6L29.2 26.8zm69.5 0L7 118.3l2.6 2.6L101.2 29.3c-.8-.9-1.7-1.7-2.6-2.5zm-34.7 6.7c-6.1 0-11.8 1.8-16.5 4.9l3.4 3.4c3.8-2.3 8.3-3.6 13.1-3.6 4.8 0 9.3 1.3 13.1 3.6l3.4-3.4c-4.7-3.1-10.4-4.9-16.5-4.9zm0 11.3c-3 0-5.7 .7-8.2 1.9l3.6 3.6c1.5-.5 3-.8 4.7-.8 1.6 0 3.2 .3 4.7 .8l3.6-3.6c-2.5-1.2-5.3-1.9-8.2-1.9zm25.6 2.9l-3.4 3.4c2.1 3.7 3.3 8 3.3 12.6 0 4.8-1.3 9.3-3.6 13.1l3.4 3.4c3.1-4.7 4.9-10.4 4.9-16.5 0-5.9-1.7-11.4-4.6-16zm-51.1 0c-2.9 4.6-4.6 10.1-4.6 16 0 6.1 1.8 11.7 4.9 16.5l3.4-3.4c-2.3-3.8-3.6-8.3-3.6-13.1 0-4.6 1.2-8.9 3.3-12.6l-3.4-3.4zm42.8 8.3l-3.6 3.6c.4 1.3 .6 2.7 .6 4.1 0 1.6-.3 3.2-.8 4.7l3.6 3.6c1.2-2.5 1.9-5.3 1.9-8.2 0-2.7-.6-5.3-1.6-7.7zm-34.5 0c-1.1 2.4-1.6 5-1.6 7.7 0 2.9 .7 5.7 1.9 8.2l3.6-3.6c-.5-1.5-.8-3-.8-4.7 0-1.4 .2-2.8 .6-4.1l-3.6-3.6zm23.1 11.4l-2.6 2.6 51 51 2.6-2.6-51-51zm-10 10l-3.6 3.6c2.4 1.1 5 1.7 7.7 1.7 2.7 0 5.3-.6 7.7-1.6l-3.6-3.6c-1.3 .4-2.7 .6-4.1 .6-1.4 0-2.8-.2-4.1-.6zM20.5 85.3l-17 17h12.9l17-17H20.5zm73.9 0l17 17h12.9L107.3 85.3H94.4zm-43.1 .5l-3.4 3.4c4.6 2.9 10.1 4.6 16 4.6 5.9 0 11.4-1.7 16-4.6l-3.4-3.4c-3.7 2.1-8 3.3-12.6 3.3-4.6 0-8.9-1.2-12.6-3.3zm-8.7 8.7l-17 17 0 12.9 17-17v-12.9zm42.7 0v12.9L102.2 124.4l0-12.9-17-17z",
    "terror": "M62.6 5.2c-11.4 .1-22.4 5.2-28.2 15.3-5.6 9.8-8.6 20.7-7.8 28.9 .4 4.1 1.6 7.4 3.7 9.9 2.1 2.4 5 4 9.4 4.5l2.8 .3-.8 2.7c-.6 2.1-.9 4.1-.9 6.2 0 6.8 1.1 19.8 4.6 30.9 1.8 5.5 4.2 10.5 7.2 14 3 3.5 6.5 5.5 11 5.5 4.5 0 7.9-2 11-5.5 3-3.5 5.4-8.5 7.2-14 3.6-11.1 4.6-24.1 4.6-30.9 0-2.2-.4-4.2-.9-6.2l-.7-2.6 2.7-.3c4.3-.5 7.3-2.1 9.4-4.4 2.1-2.3 3.4-5.5 3.8-9.5 .8-7.9-2.2-18.7-8.7-29.3-6.4-10.4-17.7-15.4-29.1-15.4h0zM43.4 36.4c6.1 0 11 4.9 11 11 0 6.1-4.9 11-11 11-6.1 0-11-4.9-11-11s4.9-11 11-11zm40.4 0c6.1 0 11 4.9 11 11 0 6.1-4.9 11-11 11-6.1 0-11-4.9-11-11 0-6.1 4.9-11 11-11zm-40.6 8.8c-1.7 0-2.9 1.3-2.9 3s1.3 2.9 2.9 2.9c1.7 0 3-1.3 3-2.9 0-1.7-1.3-3-3-3zm41.1 0c-1.7 0-2.9 1.3-2.9 3 0 1.7 1.3 2.9 2.9 2.9s3-1.3 3-2.9c0-1.7-1.3-3-3-3zm-20.4 13c9.7 0 17.2 9 17.2 19.6 0 5-.6 14-2.9 22.2-1.1 4.1-2.7 7.9-4.9 10.9-2.3 3-5.5 5.2-9.4 5.2-3.9 0-7.2-2.2-9.4-5.2-2.3-3-3.8-6.8-4.9-10.9-2.3-8.1-2.9-17.2-2.9-22.2 0-10.6 7.5-19.6 17.2-19.6zm0 4.7c-4.5 0-8.5 2.9-10.8 7.3h21.5c-2.2-4.4-6.3-7.3-10.8-7.3zm-6.8 43.5c.4 .6 .7 1.2 1.1 1.7 1.7 2.2 3.4 3.3 5.7 3.3 2.3 0 4-1.1 5.7-3.3 .4-.5 .8-1.1 1.1-1.7h-13.6z",
    "thrown-daggers": "M41.8 4.7c-5.1 0-9.2 4.2-9.2 9.3 0 5.1 4.1 9.2 9.2 9.2 3 0 5.7-1.4 7.4-3.7l18.3 4.9L76.4 36.4l46.7 0-40.4-23.4-13.5 5.8L51.1 14c0-5.1-4.2-9.3-9.3-9.3zm0 4.7c2.6 0 4.7 2.1 4.7 4.7 0 2.6-2.1 4.5-4.7 4.5s-4.5-2-4.5-4.5c0-2.6 2-4.7 4.5-4.7zM16 17.5c-.9 0-1.8 .1-2.7 .4C7.6 19.4 4.2 25.3 5.7 31c1.2 4.6 5.2 7.6 9.7 7.9l5.7 21.2-6.9 16 27.3 47.2 0-54.5-13.7-10.2-5.7-21.4c3.8-2.5 5.7-7.2 4.5-11.8-1.3-4.8-5.7-8-10.5-8zm.1 4.8c2.7 0 5.1 1.7 5.9 4.5 .9 3.2-1 6.5-4.2 7.4-3.2 .9-6.5-1-7.4-4.2-.9-3.2 1-6.5 4.2-7.4 .5-.1 1-.2 1.5-.2zm28.1 11.1c-3 .1-6 1.4-8.2 3.9-4 4.7-3.5 11.7 1.2 15.7 3.7 3.2 8.9 3.5 12.9 1.2l17.3 14.9 3.4 17.7 50.9 24.5L89.9 64.5 72.2 63.8l-17.4-15c1.8-4.3 .7-9.5-3-12.7-2.2-1.9-4.9-2.8-7.6-2.7zm.2 5c1.5 0 3 .5 4.2 1.5 2.6 2.2 2.9 6.2 .7 8.8-2.2 2.6-6.2 2.9-8.8 .6-2.6-2.2-2.9-6.2-.7-8.8 1.2-1.4 2.9-2.1 4.6-2.2z",
    "tooth": "M61.7 5.8c-2.9-.1-5.8 1.1-7.7 3.8-7.3 10.1-9.9 19.7-11.1 27.9-1.1 7.6-3.4 14.9-7.7 21.8-7.9 12.4-16.5 31.2-18.4 41.9-1.5 8.1 4.5 10.5 8.2 1.8 5.1-12 16.4-31.4 30.5-26 12.8 4.9 2.2 30.5-5.5 38.1-6.3 6.1-1.8 12.9 6 5.5 8.3-7.8 19.7-23.1 23.7-36.8 1.6-5.3 3.9-10.9 8.6-13.6 10-5.6 20.5-14.7 24.5-33.3 2.7-12.4-12.6-17.6-21.3-9.3-1.3-12.6-11.6-15.6-19.1-8.9 2.5-6.9-4.1-12.7-10.5-12.8z",
    "torch": "M119.2 12.8c-1.3 7.5-31.2 27-20.6 4.2-20.1 11.3-26.9 5.9-19.6-1.4-13.7 .7-15.7 22-13.8 28.1l4.4 4.8c-.5-7.8 .1-12.1 4.9-17.9 3.4 5.2 4.6 8.4 13 1.7-2.3 13.4 13.7 4.7 22.2 2.7-3.8 3.5-8.8 8.2-9.7 13.9-.3 1.9 1.6 4.5 3.5 6.4-2.4 .6-10.4 2.2-9.6 6.6 .7 4.3 3 3 .9 3.8-3.1 .7-5.3 1.4-9.9-.5l4.7 5.2c7.1 3.7 18.5 1.8 20.9-3.7-3.7-.3-6.8-1.2-8.2-2.9 11-2.1 16.7-9.8 21.4-18.8-8.4 4.7-10.5 4.4-14 4.1 8.9-3.6 11.7-27.2 9.7-36.3zM61.7 46.5l-14.2 17.5 19.8 21.7 18.8-12.5-24.4-26.8zm-15.6 22.5L5.4 116.9l5.4 5.9 51.4-36.1-16.1-17.6z",
    "tribal-pendant": "M12.7 4.5C15.8 9.4 19.7 15.4 24.3 21.4c2.2 2.9 4.5 5.8 7 8.5a6.8 6.8 0 0 1 1.5-1.8 6.8 6.8 0 0 1 2-1.2c-2.4-2.7-4.7-5.5-6.8-8.3C24.1 13.7 20.8 8.8 18 4.5zm97.3 0c-2.8 4.3-6.1 9.2-9.9 14.1-2.2 2.8-4.5 5.6-6.8 8.3a6.8 6.8 0 0 1 2 1.2 6.8 6.8 0 0 1 1.5 1.8c2.5-2.8 4.8-5.7 7-8.5 4.6-6 8.5-12 11.6-16.9zm-19.6 26.4a4.8 4.8 0 0 0-.9 .1c-1.2 .3-2.7 1.1-3.8 2.4-1.1 1.3-1.7 2.9-1.8 4.1-.1 1.3 .3 2.1 .9 2.7 .6 .6 1.6 .8 2.8 .5 1.2-.3 2.7-1.1 3.8-2.4 1.1-1.3 1.7-2.9 1.8-4.1 .1-1.3-.3-2.1-.9-2.7-.5-.4-1.1-.6-1.9-.6zm-52.7 0c-.8 0-1.4 .2-1.9 .6-.6 .6-1 1.4-.9 2.7 .1 1.3 .7 2.8 1.8 4.1 1.1 1.3 2.6 2.1 3.8 2.4 1.2 .3 2.2 .1 2.8-.5s1-1.4 .9-2.7c-.1-1.3-.7-2.8-1.8-4.1s-2.6-2.1-3.8-2.4a4.8 4.8 0 0 0-.9-.1zm10.8 8.8c-.3 1.5-1 2.9-2.2 3.9 3 2.1 6.1 3.8 9.2 5l-1.1-5.4c-2-.9-3.9-2.1-5.9-3.5zm31.1 0c-2 1.4-4 2.6-5.9 3.6l-1.1 5.4c3.1-1.2 6.2-2.9 9.2-5-1.2-1.1-1.9-2.4-2.2-3.9zM58.7 42.2l3.1 15.5h4.3l3.1-15.5zm-2 12.8c-.7 1-1.4 2.1-2 3.4C52 63.8 50.2 71.5 50.2 80c0 8.5 1.8 16.2 4.4 21.6C57.4 107 60.8 109.8 64 109.8c3.2 0 6.6-2.7 9.3-8.1C76 96.2 77.8 88.5 77.8 80c0-8.5-1.8-16.2-4.4-21.6-.6-1.3-1.3-2.4-2-3.4L69.8 62.2H58.2zm-10.8 2.1a21.7 21.7 0 0 0-1 0c-7 .3-13 3.9-18.3 8.8-4.9 4.6-8.9 10.3-12.1 15.4 5.4-3.2 11.6-6.5 17.7-8.8 4.7-1.8 9.1-2.9 13-2.7 .4 0 .9 .1 1.3 .1 .7-4.6 2-8.8 3.6-12.4-1.4-.3-2.8-.4-4.2-.4zm36.1 0c-1.4 0-2.8 .2-4.2 .4 1.6 3.6 2.9 7.8 3.6 12.4 .4-.1 .8-.1 1.3-.1 3.9-.2 8.4 .9 13 2.7 6 2.3 12.3 5.6 17.7 8.8-3.2-5.1-7.2-10.8-12.1-15.4-5.3-4.9-11.3-8.5-18.3-8.8a21.7 21.7 0 0 0-1 0zM59 65.8h10L73.8 71.2v17.5l-9.8 15.6-9.8-15.6V71.2zm2 4.5L58.8 72.8v14.5l5.2 8.4 5.2-8.4v-14.5L67 70.2zm-15.3 10.4c-8.9 .8-13.7 5.6-17 11.8-2.3 4.4-3.7 9.6-4.7 14.6 3.6-4.5 7.5-8.9 11.4-12.1 3.1-2.5 6.2-4.3 9.5-4.7a8.6 8.6 0 0 1 1.6 0c-.5-3.1-.8-6.3-.8-9.7zm36.5 0c0 3.4-.3 6.6-.8 9.7a8.6 8.6 0 0 1 1.6 0c3.3 .4 6.4 2.2 9.5 4.7 3.9 3.2 7.8 7.5 11.4 12.1-1-4.9-2.4-10.1-4.7-14.6-3.3-6.2-8.1-11-17-11.8zm-23.2 32.4L64 123l5-9.9C67.4 113.8 65.8 114.2 64 114.2c-1.8 0-3.4-.4-5-1.2z",
    "trumpet": "M96.5 5.3c-.7 0-1.2 .1-1.7 .3 1.1 9.7-.8 17.4-5.4 24.9-4.8 7.8-12.3 15.2-22.2 25.1l-.9 .9 5.3 5.3 .9-.9c7.1-7.1 12.9-13 18.5-17.5a12.5 12.5 0 0 1 1.9-.2 11.9 11.9 0 0 1 .6 0c3.2 0 6 1.4 8 3.4 4.1 4.1 5.4 11.1-.8 18.4-2.2-1.9-4.4-2.7-6.4-2.7a6.2 6.2 0 0 0-1 .1c-2.7 .5-4.3 2.4-5.7 3.8l-5.8 5.8 3.2 3.2 5.8-5.8c1.4-1.4 2.6-2.4 3.4-2.6a2.3 2.3 0 0 1 .5 0c.7 0 1.5 .3 2.9 1.4l-9.8 9.8 3.2 3.2 11.5-11.5c9.1-9.1 8.4-20.3 2.3-26.3-2.1-2.1-4.9-3.6-8-4.2 .3-.2 .5-.3 .8-.5 7.4-4.6 15.2-6.5 24.9-5.4 .2-.4 .3-1 .3-1.7 0-1.2-.5-2.8-1.3-4.6-1.7-3.6-4.9-7.9-8.7-11.6-3.7-3.7-8-7-11.6-8.7-1.8-.8-3.4-1.3-4.6-1.3zM54.4 50.6l-3.9 3.9 3.2 3.2 3.9-3.9-3.2-3.2zm5.9 6.1l-3.5 3.5 27.9 27.9 3.5-3.5L60.2 56.8zm-12.6 .6l-3.9 3.9 3.2 3.2 3.9-3.9-3.2-3.2zm5.9 6.2l-3.5 3.5L77.9 95l3.5-3.5L53.5 63.5zm-12.6 .5l-3.9 3.9 3.2 3.2L44.2 67.2l-3.2-3.2zm5.8 6.2l-3.5 3.5 27.9 27.9 3.5-3.5L46.8 70.2zm-3.4 10L12.8 111.9l3.2 3.2 10-9.6c0 0 0 0 0 .1 .2 4.3 2.2 8.3 5.2 11.3 3 3 7 5 11.3 5.2 4.3 .2 9-1.4 12.9-5.4l12.2-12.2-3.2-3.2-10.6 10.6c-1.8-1.8-1.7-2.6-1.5-3.4 .2-.8 1.3-2.1 2.7-3.5l6.5-6.5-3.2-3.2-6.5 6.5c-1.4 1.4-3.2 3-3.9 5.4-.7 2.3 .2 5.1 2.5 7.7-2.6 2-5.3 2.7-7.8 2.6-3.1-.2-6.1-1.6-8.3-3.9-2.2-2.2-3.7-5.2-3.9-8.3-.1-1.7 .2-3.4 .9-5.1l16.3-15.7-4.4-4.4zM8.4 113.9l-3.2 3.2 5.7 5.7 3.2-3.2-5.7-5.7z",
    "upgrade": "M64 7.5l-57.8 38.5v26.6l57.8-38.5 57.8 38.5V46zm0 32L26.2 64.9v22.6l37.8-25.5 37.8 25.5v-22.6zm0 28l-21.8 14.7v16.9l21.8-14.5 21.8 14.5v-16.9zm0 22.5l-21.8 14.5v16.1l21.8-14.5 21.8 14.5v-16.1z",
    "war-axe": "M102.5 4.8c-7.6 6.1-13.5 9.6-16 12.1-.8 .8-1.6 2.3-1.7 3.4-.2 1.2 0 1.8 .9 2.5l0 0 6.6 4.6c.8 .6 1.4 .4 2.3-.2 1-.6 1.9-2 2.3-3 1.2-3.8 2.6-10.2 5.7-19.5zM55.9 20.1l5.6 12.5 3.1-.9 6.6 4.6 5.1-7.4-6.6-4.6-.2-3.2zm53.4 2.5c-2.1 6.8-4.8 10.7-7.6 12.9 2.4 21.5-1.7 34.9-9.1 44-7.4 9.2-17.6 13.9-27 19.2l-.1-.1c-6.3 16.3-20 21.6-22.6 24 5.7-1.2 14.8-3.2 24.8-6.8l3.5-6.4 3.7 3 4.8-6 4.7 2.2c11.3-6.1 21.9-14.5 28.1-26.4l-7.5-7.8s5.8 2.4 9.3 3.8c4-9.7 5.1-21.4 1.8-35.7l-4.9-2.1 3.7-2.6c-1.4-4.8-3.3-9.9-5.8-15.2zM83.3 26.7l-2 2.9 6.2 4.3 2-2.9zm-4.6 6.6L51.6 72.3l6.2 4.3 27.1-39zm18.7 4.5c-2.5 .7-5.1 .6-7.5 .4l-2.4 3.5c1.1 0 2.4 0 4.3 .1l1.8 .1 .3 1.7c.8 3.9 .6 5.8 0 8.4l-.3 1.6-10.3 1.1-2.2-3.7-10 14.3c1.9 1.7 3.1 4.3 4.2 6.9 1.4 3.2 2.5 6.7 3.3 9.4l-4.3 1.3c-.8-2.7-1.9-6-3.1-9-.9-2-1.9-3.8-2.8-4.9l-3.7 5.3c2.8-1.3 3.6-.5 3.8 2.8 .3 5.9-.2 11.1-1.2 15.5 8.2-4.5 16.1-8.9 21.7-15.9 6.3-7.9 10.2-19.3 8.3-39zM38.4 45.2l5.7 12.4 3.1-.9 6.6 4.6 4.9-7-6.5-4.7-.2-3.2zm46 .8l-.5 .7 1.8 3 4.1-.4c.2-1 .2-1.8-.1-3.2-2 0-3.4 0-5.4-.1zm2.6 11.6c1.2 0 2.5 0 3.7 .1l2.4 .2-.3 2.4c-.8 5.6-2.3 10.2-8.6 14.2l-1.5 1-1.3-1.3c-1.8-1.8-3.2-3.9-4.1-6.1-.9-2.2-1.4-4.6 0-6.8 1.4-2.2 3.8-3.1 6.2-3.5 1.2-.2 2.4-.3 3.7-.3zm-.1 4.5c-1 0-1.9 .1-2.8 .2-1.7 .3-2.8 .9-3.2 1.5-.1 .2-.2 1.1 .4 2.6 .4 1 1.1 2.1 2 3.2 3.1-2.4 4-4.4 4.6-7.5-.3 0-.7 0-1 0zm-37.8 13.8l-2 2.9 6.2 4.3 2-2.9zm-4.6 6.6L15.9 123.5h9.1l25.5-36.7z",
    "wolf-trap": "M26.5 28.4l-8.2 18.6c-.3 .1-.5 .1-.8 .2-1.3 .3-2.5 .7-3.5 1.2l-2.1-13.4-6.3 21.8c-.3 .9-.6 1.9-.8 2.9l-.1 .2 0 0c-.9 4.2-.9 8.9 .9 14 .8 3.5 3.9 7.6 10.1 12 7.3 5.2 18.8 10.7 34.6 16-.1-.4-.1-.9-.1-1.4 0-3.1 1.4-5.8 3.6-7.6l-1-10.7-7.9 9.4c-2.4-.9-4.8-1.9-7-2.8l-.7-19.5-8.4 15.2c-2.3-1.2-4.4-2.4-6.3-3.7l-1.2-22.5-7.2 16.3c-1.9-1.7-3.5-3.3-4.9-5-1.1-5-.1-9.5 1.5-13.1l1.1-.7c4-1.4 8.9-1.9 14.6-1.5 8.2 .5 18.1 2.9 29.5 7.7 0-3.3 1.9-6.1 4.7-7.5l-1.4-13.1-7.5 10.7c-2.4-.9-4.8-1.7-7-2.4l-1.1-17.2-8.1 14.9c-2.9-.5-5.7-.9-8.2-1l-.9-18zm80.8 7.5l-4 17.6c-2.5-.3-5.2-.5-8.2-.4l-4.9-16.6-4.5 17.2c-2.3 .3-4.8 .7-7.3 1.1l-4.8-11.2-4.1 11.4c2.2 1.5 3.7 4.1 3.7 7 0 .6-.1 1.2-.2 1.8 11.8-2.6 21.8-3.3 29.8-2.4 5.7 .6 10.5 2 14.1 4l1 .8c1 3.8 1.2 8.4-.7 13.2-1.6 1.4-3.5 2.8-5.6 4.1l-4.4-17.3-5 22c-2.1 .9-4.4 1.7-6.8 2.5l-4.9-15.4-4.8 18.2c-2.3 .6-4.8 1.1-7.3 1.6l-5.7-11.4-3.7 12.5c.6 1.3 1 2.8 1 4.3 0 1.4-.3 2.8-.9 4 17.6-2.5 30.5-6 39-10.1 6.8-3.3 10.6-6.8 12-10.1 2.6-4.6 3.4-9.3 3.3-13.6l0 0 0-.2c-.1-1-.2-2-.3-3l-2.5-22.6-4.3 12.8c-.9-.6-2-1.2-3.3-1.8-.2-.1-.5-.2-.7-.3L107.3 35.9zm-42.6 22.3c-2.2 0-3.9 1.7-3.9 3.9 0 .9 .3 1.7 .8 2.3 .9 0 1.7 0 2.6 .1 1.1 .1 2.1 .2 3.2 .4 .7-.7 1.2-1.7 1.2-2.8 0-2.2-1.7-3.9-3.9-3.9zm-3.2 10.9c-.3 0-.5 0-.8 0-3 .1-5.6 .5-7.6 1.2-1.3 .5-2.2 1.1-2.7 1.6-.5 .5-.6 .8-.6 1.1 0 .6 1 2.1 3.6 3.5 2.6 1.4 6.5 2.4 10.7 2.7 4.3 .3 8.1-.2 10.7-1.2 1.3-.5 2.2-1.1 2.7-1.6 .5-.5 .6-.8 .6-1.1 0-.6-1-2.1-3.6-3.5-2.6-1.4-6.5-2.4-10.7-2.7-.8-.1-1.6-.1-2.4-.1zm-1.4 14.3l-.7 7.4c.3 0 .5 0 .8 0 1.3 0 2.6 .3 3.8 .8l.8-7.6c-.3 0-.6 0-.9-.1-1.3-.1-2.6-.2-3.8-.5zm.1 12c-2.9 0-5.2 2.3-5.2 5.2 0 2.9 2.3 5.2 5.2 5.2 2.9 0 5.2-2.3 5.2-5.2 0-2.9-2.3-5.2-5.2-5.2z",
  };
  const ICO_BY = {"delapouite": ["all-seeing-eye", "angry-eyes", "armor-downgrade", "armor-upgrade", "barrel", "bookshelf", "brain-tentacle", "bread", "candles", "carnival-mask", "coins", "crystal-shrine", "drum", "executioner-hood", "eye-target", "falcon-moon", "feather-necklace", "flail", "grave-flowers", "hammer-break", "hand-of-god", "heart-beats", "herbs-bundle", "holy-water", "knight-banner", "knocked-out-stars", "metal-boot", "mushrooms", "musical-notes", "pan-flute", "pendant-key", "plain-arrow", "powder-bag", "ribbon-medal", "shield-bash", "spell-book", "spiral-hilt", "stairs", "stone-wall", "stun-grenade", "sword-altar", "sword-brandish", "torch", "tribal-pendant", "trumpet", "upgrade", "war-axe"], "lorc": ["arrow-cluster", "axe-swing", "back-forth", "bandage-roll", "battle-axe", "bell-shield", "bird-claw", "bleeding-wound", "bloody-sword", "bowie-knife", "brain", "broadsword", "broken-heart", "bubbling-flask", "burning-book", "burning-passion", "campfire", "candle-light", "candlebright", "cauldron", "chalice-drops", "cloak-dagger", "coffin", "crescent-blade", "crossed-chains", "crossed-pistols", "crossed-swords", "crown-of-thorns", "crystal-eye", "despair", "dig-dug", "diving-dagger", "dread-skull", "dripping-knife", "engagement-ring", "evil-book", "feather", "feathered-wing", "fire-bomb", "fist", "fizzing-flask", "fountain", "gem-necklace", "gem-pendant", "harpoon-chain", "hawk-emblem", "holy-symbol", "hourglass", "knife-thrust", "lantern-flame", "lantern", "locked-chest", "lyre", "meat-cleaver", "meat-hook", "medal-skull", "mirror-mirror", "on-target", "plain-dagger", "poison-bottle", "poison-gas", "prayer", "raven", "relic-blade", "ringing-bell", "round-bottom-flask", "run", "rune-stone", "scar-wound", "scarab-beetle", "scroll-unfurled", "shouting", "skeleton-key", "sparky-bomb", "spider-web", "spiked-halo", "sprint", "sunbeams", "target-arrows", "terror", "thrown-daggers", "tooth", "wolf-trap"], "willdabeast": ["chain-mail"], "carl-olsen": ["crossbow"], "darkzaitzev": ["hooded-assassin", "robber-hand", "smoke-bomb"], "skoll": ["open-treasure-chest", "switchblade"], "sbed": ["poison", "shield"], "andymeneely": ["riposte"]};
  /* ---------- 빛 단계 ---------- */
  const LB = [
    { n: '밝음', min: 76, eAcc: 0, eCr: 0, eDm: 0, hs: 6, es: 25, loot: 1, step: 0, scout: 50 },
    { n: '어스름', min: 51, eAcc: 2, eCr: 2, eDm: 0, hs: 10, es: 15, loot: 1.15, step: 0.5, scout: 40 },
    { n: '어둠', min: 26, eAcc: 5, eCr: 4, eDm: 10, hs: 16, es: 10, loot: 1.3, step: 1, scout: 25 },
    { n: '칠흑', min: 1, eAcc: 8, eCr: 7, eDm: 20, hs: 25, es: 5, loot: 1.5, step: 2, scout: 12 },
    { n: '완전한 어둠', min: 0, eAcc: 12, eCr: 10, eDm: 30, hs: 35, es: 0, loot: 1.75, step: 3, scout: 0 },
  ];
  const band = (light) => (light >= 76 ? 0 : light >= 51 ? 1 : light >= 26 ? 2 : light >= 1 ? 3 : 4);
  const LVXP = [0, 5, 13, 24, 38];
  const ZLEN = 3;   // 구역당 층 수(마지막 층에 우두머리)
  const START_GOLD = 600;

  const heroName = (h) => EPI[h.ep % EPI.length] + ' ' + CL[h.c].n;
  const enName = (e) => EI[e.e].n;
  const isHero = (s, u) => s.pt.some((h) => h.u === u);
  const findU = (s, u) => s.pt.find((h) => h.u === u) || (s.fi && s.fi.en.find((e) => e.u === u)) || null;
  const newU = (s) => ++s.nu;

  /* ---------- 대원 만들기 ---------- */
  function mkHero(s, cid, lv) {
    const C = CL[cid];
    const h = { u: newU(s), c: cid, ep: rnd(0, EPI.length - 1), o: 0, lv: lv || 1, xp: LVXP[(lv || 1) - 1], hp: 0, st: rnd(0, 12), af: '', vi: '', dd: 0, sk: C.def.slice(), q: [], tr: [], fx: [], cb: [] };
    if (Math.random() < 0.35) addQuirk(s, h, 1, null);
    if (Math.random() < 0.35) addQuirk(s, h, 0, null);
    h.hp = hStats(s, h).mh;
    return h;
  }
  function addQuirk(s, h, pos, ev) {
    const have = h.q.filter((id) => !!QI[id].p === !!pos);
    const pool = QK.filter((q) => !!q.p === !!pos && !h.q.includes(q.id));
    if (!pool.length) return null;
    const q = pick(pool);
    if (have.length >= 3) h.q.splice(h.q.indexOf(have[0]), 1);
    h.q.push(q.id);
    if (ev) ev.push({ k: 'qk', u: h.u, q: q.id, p: q.p });
    return q;
  }
  function candidates(s, n, lv, avoid) {
    const ids = shuf(CLS.map((c) => c.id).filter((id) => !(avoid || []).includes(id))).concat(shuf(CLS.map((c) => c.id)));
    const out = [], seen = {};
    for (const id of ids) { if (out.length >= n) break; if (seen[id]) continue; seen[id] = 1; out.push(mkHero(s, id, lv)); }
    return out;
  }

  /* ---------- 능력치 ---------- */
  function lightCond(s, c) { return !c || (c === 'lh' ? s.light >= 75 : c === 'll' ? s.light <= 25 : true); }
  function hStats(s, h) {
    const C = CL[h.c], lv = h.lv - 1;
    const m = { acc: 2 * lv, dg: 2 * lv, pr: C.pr, spd: C.spd + (h.lv >= 3 ? 1 : 0) + (h.lv >= 5 ? 1 : 0), cr: C.cr + lv, dm: 0, str: 0, mh: 0, hl: 0, hb: 0, rst: 0, rbl: 0, rbg: 0, rdb: 0, rmv: 0, rtr: 0, dbr: 0, vir: 0, vsU: 0, vsB: 0, scout: 0 };
    const add = (mm) => { for (const k in mm) m[k] = (m[k] || 0) + mm[k]; };
    for (const id of h.q) { const q = QI[id]; if (q && lightCond(s, q.c)) add(q.m); }
    for (const id of h.tr) { const t = TI[id]; if (t && lightCond(s, t.c)) add(t.m); }
    if (h.af) add(AF[h.af].m);
    if (h.vi) add(VI[h.vi].m);
    for (const b of h.cb) add({ [b.s]: b.v });
    for (const f of h.fx) {
      if (f.k === 'bf' || f.k === 'db') add({ [f.s]: f.v });
      else if (f.k === 'ddr') add({ acc: -5, dm: -10, spd: -1 });
      else if (f.k === 'rs') add({ rst: f.v, rbl: f.v, rbg: f.v, rdb: f.v, rmv: f.v });
    }
    m.dg += C.dg;
    m.mh = Math.max(8, Math.round(C.hp * (1 + 0.1 * lv) * (1 + m.mh / 100)));
    const dk = (1 + 0.07 * lv);
    m.lo = Math.max(1, Math.round(C.dmg[0] * dk)); m.hi = Math.max(m.lo, Math.round(C.dmg[1] * dk));
    m.res = { st: C.res.st + m.rst, bl: C.res.bl + m.rbl, bg: C.res.bg + m.rbg, db: C.res.db + m.rdb, mv: C.res.mv + m.rmv, tr: C.res.tr + m.rtr };
    m.dbr = 60 + m.dbr;
    m.pr = clamp(m.pr, 0, 80);
    return m;
  }
  const ENRES = { st: 25, bl: 20, bg: 20, db: 20, mv: 30 };
  function eStats(s, e) {
    const D = EI[e.e], f = e.lv || 0;
    const m = { acc: f, dg: D.dg + Math.floor(f / 2), pr: D.pr, spd: D.spd, cr: D.cr, dm: 0, vsU: 0 };
    for (const x of e.fx) if (x.k === 'bf' || x.k === 'db') m[x.s] = (m[x.s] || 0) + x.v;
    const dk = 1 + 0.07 * f;
    m.lo = Math.max(1, Math.round(D.dmg[0] * dk)); m.hi = Math.max(m.lo, Math.round(D.dmg[1] * dk));
    const r = Object.assign({}, ENRES);
    if (D.tg === 'U') { r.bl = 60; r.bg = 40; }
    if (D.tg === 'P') { r.bg = 55; r.bl = 30; }
    if (D.tg === 'E') { r.st = 35; r.db = 35; }
    if (D.boss) { r.st = 55; r.mv = 90; r.db = 40; }
    for (const k in r) r[k] += f * 2;
    m.res = r;
    m.pr = clamp(m.pr, 0, 80);
    return m;
  }
  const stOf = (s, u) => (u.e ? eStats(s, u) : hStats(s, u));
  const maxHp = (s, u) => (u.e ? u.mh : hStats(s, u).mh);

  /* ---------- 새 판 ---------- */
  function init(players, opts) {
    opts = opts || {};
    const np = Math.max(1, players.length);
    let len = +(opts.len || 6); if (![3, 6, 9, 12].includes(len)) len = 6;
    const zs = shuf(ZONES.map((z) => z.id));
    const s = {
      v: 1, np, len, zs: zs.slice(0, Math.ceil(len / ZLEN)), fl: 0, ph: 'prep', nu: 0, ld: 0, seed: Math.floor(Math.random() * 1e9),
      gold: START_GOLD, inv: { food: 0, torch: 0, shovel: 0, band: 0, anti: 0, key: 0, holy: 0, laud: 0 }, bag: [],
      light: 100, hu: 0, pt: [], dead: [], mp: null, fi: null, cu: null, cp: null, wy: null, res: null,
      log: [], last: { id: 0, ev: [] }, st: { kills: 0, crits: 0, aff: 0, vir: 0, gold: 0, rooms: 0, fights: 0, boss: 0, steps: 0 },
    };
    s.pr = { c: candidates(s, 8, 1) };
    s.nar = narr('start');
    return s;
  }
  function logp(s, t) { s.log.push(t); if (s.log.length > 14) s.log.shift(); }

  /* ---------- 지도 ---------- */
  const GW = 5, GH = 4;
  function genFloor(s) {
    const zone = s.zs[Math.floor(s.fl / ZLEN)], fz = s.fl % ZLEN, boss = fz === ZLEN - 1;
    const n = Math.min(GW * GH - 4, 6 + fz + rnd(0, 2));
    const rooms = [{ x: 0, y: rnd(0, GH - 1) }], cors = [];
    const at = (x, y) => rooms.findIndex((r) => r.x === x && r.y === y);
    let guard = 0;
    while (rooms.length < n && guard++ < 500) {
      const i = Math.random() < 0.55 ? rooms.length - 1 : rnd(0, rooms.length - 1), r = rooms[i];
      const d = pick([[1, 0], [1, 0], [0, 1], [0, -1], [-1, 0]]);
      const x = r.x + d[0], y = r.y + d[1];
      if (x < 0 || y < 0 || x >= GW || y >= GH || at(x, y) >= 0) continue;
      rooms.push({ x, y }); cors.push({ a: i, b: rooms.length - 1 });
    }
    // 고리 하나 둘
    for (let k = 0, add = rnd(1, 2); k < 40 && add > 0; k++) {
      const i = rnd(0, rooms.length - 1), r = rooms[i], d = pick([[1, 0], [0, 1]]), j = at(r.x + d[0], r.y + d[1]);
      if (j < 0 || cors.some((c) => (c.a === i && c.b === j) || (c.a === j && c.b === i))) continue;
      cors.push({ a: i, b: j }); add--;
    }
    // 가장 먼 방 = 출구
    const dist = rooms.map(() => 99); dist[0] = 0; const q = [0];
    while (q.length) { const i = q.shift(); for (const c of cors) { const j = c.a === i ? c.b : c.b === i ? c.a : -1; if (j >= 0 && dist[j] > dist[i] + 1) { dist[j] = dist[i] + 1; q.push(j); } } }
    let ex = 0; rooms.forEach((r, i) => { if (dist[i] > dist[ex] || (dist[i] === dist[ex] && Math.random() < 0.5)) ex = i; });
    const curPool = CUR.filter((c) => c.z === zone || c.z === '*');
    rooms.forEach((r, i) => {
      r.v = i === 0 ? 1 : 0; r.sc = i === 0 || i === ex ? 1 : 0;
      if (i === 0) r.k = 'e';
      else if (i === ex) r.k = boss ? 'b' : 'x';
      else { const p = Math.random(); r.k = p < 0.42 ? 'f' : p < 0.68 ? 'c' : p < 0.78 ? 't' : 'e'; }
      if (r.k === 'c') r.c = pick(curPool).id;
    });
    cors.forEach((c) => {
      const len = rnd(2, 3); let str = '';
      for (let k = 0; k < len; k++) { const p = Math.random(); str += p < 0.56 ? '.' : p < 0.67 ? 'T' : p < 0.78 ? 'C' : p < 0.92 ? 'F' : 'O'; }
      c.s = str; c.sc = 0; c.w = 0; c.cu = [];
      for (let k = 0; k < len; k++) c.cu.push(str[k] === 'C' ? pick(curPool).id : '');
    });
    s.mp = { z: zone, r: rooms, c: cors, at: { r: 0 }, prev: 0, boss };
    s.ld = s.fl % s.np;
    s.ph = 'map';
  }
  function corOf(s, a, b) { return s.mp.c.findIndex((c) => (c.a === a && c.b === b) || (c.a === b && c.b === a)); }
  function adjRooms(s) {
    const at = s.mp.at;
    if (at.c != null) { const c = s.mp.c[at.c]; return [c.a, c.b]; }
    const out = [];
    s.mp.c.forEach((c) => { if (c.a === at.r) out.push(c.b); else if (c.b === at.r) out.push(c.a); });
    return out;
  }
  function scout(s, r, ev, force) {
    const sc = LB[band(s.light)].scout + Math.max(0, ...s.pt.map((h) => hStats(s, h).scout)) + (s.scB || 0);
    if (!force && Math.random() * 100 >= sc) return false;
    s.mp.c.forEach((c) => { if (c.a === r || c.b === r) { c.sc = 1; s.mp.r[c.a === r ? c.b : c.a].sc = 1; } });
    if (ev) ev.push({ k: 'scout' });
    return true;
  }

  /* ---------- 스트레스 · 체력 ---------- */
  function addSt(s, h, v, ev) {
    if (!h || h.hp == null || !s.pt.includes(h)) return;
    if (v > 0) {
      const m = hStats(s, h);
      v = Math.max(1, Math.round(v * (1 + m.str / 100)));
      h.st = Math.min(200, h.st + v);
      ev.push({ k: 'st', u: h.u, v, s: h.st });
      if (h.st >= 200) heart(s, h, ev);
      else if (h.st >= 100 && !h.af && !h.vi) resolve(s, h, ev);
    } else if (v < 0) {
      const m = hStats(s, h);
      const nv = Math.min(-1, Math.round(v));
      const was = h.st;
      h.st = Math.max(0, h.st + nv);
      if (was !== h.st) ev.push({ k: 'st', u: h.u, v: h.st - was, s: h.st });
      if (h.af && h.st <= 40) { ev.push({ k: 'calm', u: h.u, af: h.af }); h.af = ''; }
      void m;
    }
  }
  function resolve(s, h, ev) {
    const m = hStats(s, h);
    const ch = 25 + m.vir + (band(s.light) === 0 ? 5 : 0);
    if (Math.random() * 100 < ch) {
      const v = pick(VIR); h.vi = v.id; h.st = Math.min(h.st, 45); s.st.vir++;
      ev.push({ k: 'res', u: h.u, vi: v.id, s: h.st, say: pick(v.bark) });
      for (const o of s.pt) if (o !== h) addSt(s, o, -8, ev);
      logp(s, heroName(h) + ' · 각성: ' + v.n);
    } else {
      const a = pick(AFF); h.af = a.id; s.st.aff++;
      ev.push({ k: 'res', u: h.u, af: a.id, s: h.st, say: pick(a.bark) });
      logp(s, heroName(h) + ' · 붕괴: ' + a.n);
      for (const o of s.pt) if (o !== h) addSt(s, o, rnd(3, 6), ev);
    }
    if (Math.random() < 0.5) s.nar = narr(h.vi ? 'virtue' : 'afflict');
  }
  function heart(s, h, ev) {
    ev.push({ k: 'heart', u: h.u });
    logp(s, heroName(h) + ' · 심장 발작');
    h.vi = '';
    if (h.dd) { kill(s, h, ev, '심장 발작'); return; }
    h.hp = 0; h.dd = 1; h.st = 170;
    ev.push({ k: 'dd', u: h.u });
  }
  function healHero(s, h, v, ev, src) {
    if (!s.pt.includes(h)) return 0;
    const m = hStats(s, h);
    if (h.af && AF[h.af].nh && src !== h && Math.random() < AF[h.af].nh) { ev.push({ k: 'refh', u: h.u }); return 0; }
    v = Math.max(1, Math.round(v * (1 + m.hl / 100)));
    const was = h.hp; h.hp = Math.min(m.mh, h.hp + v);
    if (h.dd && h.hp > 0) { h.dd = 0; h.fx = h.fx.filter((f) => f.k !== 'ddr'); h.fx.push({ k: 'ddr', t: 99 }); }
    ev.push({ k: 'heal', u: h.u, v: h.hp - was, hp: h.hp });
    return h.hp - was;
  }
  function kill(s, h, ev, why) {
    const i = s.pt.indexOf(h); if (i < 0) return;
    s.pt.splice(i, 1);
    s.dead.push({ c: h.c, ep: h.ep, fl: s.fl, lv: h.lv, why: why || '' });
    ev.push({ k: 'die', u: h.u, hero: 1 });
    logp(s, heroName(h) + ' 사망' + (why ? ' (' + why + ')' : ''));
    s.nar = narr('death');
    for (const o of s.pt) addSt(s, o, 20, ev);
    ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi ? s.fi.en.map((x) => x.u) : [] });
    if (!s.pt.length) endRun(s, false, ev);
  }
  function hurtHero(s, h, d, ev, why, noDeath) {
    if (!s.pt.includes(h)) return;
    if (h.dd) {
      if (noDeath) return;
      const m = hStats(s, h);
      if (Math.random() * 100 < m.dbr + (why === '지속 피해' ? 15 : 0)) { ev.push({ k: 'ddok', u: h.u }); return; }
      kill(s, h, ev, why); return;
    }
    h.hp -= d;
    if (h.hp <= 0) {
      if (noDeath) { h.hp = 1; return; }
      h.hp = 0; h.dd = 1; ev.push({ k: 'dd', u: h.u });
      addSt(s, h, 8, ev);
      for (const o of s.pt.slice()) if (o !== h) addSt(s, o, 3, ev);
      if (Math.random() < 0.4) s.nar = narr('dd');
    }
  }

  /* ---------- 전투 ---------- */
  const effF = (f) => (f <= 5 ? f : 5 + (f - 5) * 0.55);   // 깊은 층은 덜 가파르게(대원 단계 상한 5)
  function mkEnemy(s, id, extra) {
    const D = EI[id], f = effF(s.fl) + (extra || 0);
    const mh = Math.round(D.hp * (1 + (D.boss ? 0.085 : 0.11) * f));
    return { u: newU(s), e: id, hp: mh, mh, lv: Math.round(f * 10) / 10, fx: [] };
  }
  function encounter(s, kind) {
    const zone = s.mp ? s.mp.z : s.zs[0];
    const pool = EN.filter((e) => !e.boss && e.z === zone), com = EN.filter((e) => !e.boss && e.z === '*');
    const fz = s.fl % ZLEN;
    let n = kind === 'cor' ? rnd(2, 3) : kind === 'camp' ? rnd(3, 4) : rnd(2, 4);
    if (s.fl === 0 && n > 3) n = 3;
    if (fz >= 1 && Math.random() < 0.4) n = Math.min(4, n + 1);
    const ids = [];
    for (let i = 0; i < n; i++) ids.push((Math.random() < 0.72 ? pick(pool) : pick(com)).id);
    // 앞에 서는 것부터
    const pref = (id) => { const r = EI[id].rk; return +r[0] + (r.length > 2 ? 0.5 : 0) + Math.random() * 0.6; };
    ids.sort((a, b) => pref(a) - pref(b));
    return ids;
  }
  function startFight(s, ids, kind, ev, room) {
    const en = ids.map((id) => mkEnemy(s, id, kind === 'camp' ? 0.5 : 0));
    s.fi = { en, rd: 0, q: [], cur: 0, kind, room: room == null ? -1 : room, boss: en.some((e) => EI[e.e].boss) ? 1 : 0, sur: '', loot: 0, n0: en.length };
    const b = LB[band(s.light)];
    let hs = b.hs + (kind === 'camp' ? 15 : 0) - Math.max(0, ...s.pt.map((h) => hStats(s, h).scout)) / 3;
    if (s.fi.boss) hs = 0;
    if (Math.random() * 100 < hs) {
      s.fi.sur = 'h';
      shuf(s.pt);
      ev.push({ k: 'surp', who: 'h' });
    } else if (!s.fi.boss && Math.random() * 100 < b.es) { s.fi.sur = 'e'; ev.push({ k: 'surp', who: 'e' }); }
    s.ph = 'fight'; s.st.fights++;
    ev.push({ k: 'fight', e: en.map((e) => ({ u: e.u, e: e.e, hp: e.hp, mh: e.mh })), boss: s.fi.boss });
    ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: en.map((x) => x.u) });
    if (s.fi.boss) s.nar = narr('boss');
    newRound(s, ev);
    advance(s, ev);
  }
  function newRound(s, ev) {
    const fi = s.fi; fi.rd++;
    const list = [];
    for (const h of s.pt) list.push({ u: h.u, v: hStats(s, h).spd + Math.random() * 8 + (fi.rd === 1 && fi.sur === 'e' ? 100 : 0) - (fi.rd === 1 && fi.sur === 'h' ? 100 : 0) });
    for (const e of fi.en) {
      list.push({ u: e.u, v: eStats(s, e).spd + Math.random() * 8 + (fi.rd === 1 && fi.sur === 'h' ? 100 : 0) - (fi.rd === 1 && fi.sur === 'e' ? 100 : 0) });
      if (EI[e.e].boss) list.push({ u: e.u, v: eStats(s, e).spd + Math.random() * 8 - 6 });
    }
    list.sort((a, b) => b.v - a.v);
    fi.q = list.map((x) => x.u);
    ev.push({ k: 'round', n: fi.rd });
    if (fi.rd > 40) {   // 끝없는 싸움 방지: 40라운드가 넘으면 적이 물러남
      ev.push({ k: 'flee', who: 'e' });
      fi.en = [];
    }
  }
  function fightOver(s) { return !s.fi || !s.fi.en.length || !s.pt.length; }
  // 차례 시작: 지속 피해 · 효과 시간 · 기절
  function turnStart(s, u, ev) {
    const hero = isHero(s, u.u);
    let dot = 0;
    for (const f of u.fx) if ((f.k === 'bl' || f.k === 'bg') && f.t > 0) { dot += f.n; ev.push({ k: 'dot', u: u.u, f: f.k, d: f.n }); }
    if (dot > 0) {
      if (hero) { hurtHero(s, u, dot, ev, '지속 피해'); if (!s.pt.includes(u)) return false; ev.push({ k: 'hp', u: u.u, hp: u.hp }); }
      else { u.hp -= dot; ev.push({ k: 'hp', u: u.u, hp: Math.max(0, u.hp) }); if (u.hp <= 0) { enemyDie(s, u, ev); return false; } }
    }
    let stun = false;
    u.fx = u.fx.filter((f) => {
      if (f.k === 'stun') { stun = true; return false; }
      if (f.k === 'ddr') return true;
      if (f.t != null) { f.t--; if (f.t <= 0) return false; }
      return true;
    });
    if (stun) { ev.push({ k: 'stunned', u: u.u }); return false; }
    return true;
  }
  function enemyDie(s, e, ev) {
    const i = s.fi.en.indexOf(e); if (i < 0) return;
    s.fi.en.splice(i, 1);
    s.st.kills++;
    ev.push({ k: 'die', u: e.u });
    if (EI[e.e].boss) { s.st.boss++; s.nar = narr('bossdown'); }
    ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi.en.map((x) => x.u) });
  }
  function advance(s, ev) {
    for (let guard = 0; guard < 400; guard++) {
      if (s.ph !== 'fight') return;
      if (fightOver(s)) { endFight(s, ev); return; }
      if (!s.fi.q.length) { newRound(s, ev); continue; }
      const uid = s.fi.q.shift();
      const u = findU(s, uid); if (!u) continue;
      if (!turnStart(s, u, ev)) continue;
      if (fightOver(s)) { endFight(s, ev); return; }
      if (isHero(s, uid)) {
        virtueTick(s, u, ev);
        if (!s.pt.includes(u)) continue;
        if (u.af && Math.random() < AF[u.af].act) { ev.push({ k: 'turn', u: uid }); actOut(s, u, ev); continue; }
        s.fi.cur = uid;
        ev.push({ k: 'turn', u: uid });
        return;
      }
      ev.push({ k: 'turn', u: uid });
      enemyAct(s, u, ev);
    }
    // 안전장치
    if (s.ph === 'fight' && !fightOver(s) && s.pt.length) { s.fi.cur = s.pt[0].u; }
  }
  function virtueTick(s, h, ev) {
    if (!h.vi) return;
    const r = Math.random();
    if (h.vi === 'stal' && r < 0.25) addSt(s, h, -10, ev);
    else if (h.vi === 'focu' && r < 0.2) { ev.push({ k: 'say', u: h.u, t: pick(VI.focu.bark) }); for (const o of s.pt) addSt(s, o, -4, ev); }
    else if (h.vi === 'cour' && r < 0.3) { ev.push({ k: 'say', u: h.u, t: pick(VI.cour.bark) }); for (const o of s.pt) if (o !== h) addSt(s, o, -6, ev); }
    else if (h.vi === 'powr' && r < 0.2) { ev.push({ k: 'say', u: h.u, t: pick(VI.powr.bark) }); for (const o of s.pt) o.fx.push({ k: 'bf', s: 'dm', v: 10, t: 2 }); }
    else if (h.vi === 'vigo' && r < 0.3) healHero(s, h, Math.round(hStats(s, h).mh * 0.1), ev, h);
  }
  function wpick(w) { let t = 0; for (const k in w) t += w[k]; let r = Math.random() * t; for (const k in w) { r -= w[k]; if (r <= 0) return k; } return Object.keys(w)[0]; }
  function actOut(s, h, ev) {
    const A = AF[h.af];
    const k = wpick(A.beh);
    const i = s.pt.indexOf(h);
    const bark = () => {
      ev.push({ k: 'say', u: h.u, t: pick(A.bark), bad: 1 });
      const others = s.pt.filter((o) => o !== h);
      if (others.length) { const tg = pick(others); addSt(s, tg, rnd(5, 9), ev); if (Math.random() < 0.35) for (const o of others) if (o !== tg) addSt(s, o, rnd(1, 3), ev); }
    };
    ev.push({ k: 'act', u: h.u, n: '제멋대로', af: h.af });
    if (k === 'bark') bark();
    else if (k === 'pass') { ev.push({ k: 'say', u: h.u, t: pick(A.bark), bad: 1 }); ev.push({ k: 'pass', u: h.u }); }
    else if (k === 'back' || k === 'fwd') {
      const j = k === 'back' ? i + 1 : i - 1;
      if (j >= 0 && j < s.pt.length) { swapH(s, i, j, ev); ev.push({ k: 'say', u: h.u, t: pick(A.bark), bad: 1 }); } else bark();
    } else if (k === 'self') {
      const d = Math.max(1, Math.round(hStats(s, h).mh * 0.1));
      ev.push({ k: 'hit', u: h.u, d, hp: Math.max(0, h.hp - d), self: 1 });
      hurtHero(s, h, d, ev, '자해', false);
      ev.push({ k: 'say', u: h.u, t: pick(A.bark), bad: 1 });
    } else if (k === 'eat') {
      if (s.inv.food > 0) { s.inv.food--; ev.push({ k: 'eat', u: h.u }); healHero(s, h, 3, ev, h); ev.push({ k: 'say', u: h.u, t: pick(A.bark), bad: 1 }); } else bark();
    } else if (k === 'atk') {
      const opts = [];
      h.sk.forEach((si) => { const S = CL[h.c].sk[si]; if (S.t === 'e' && S.dm > 0) for (const g of targetsFor(s, h, si)) opts.push([si, g]); });
      if (opts.length) { const [si, g] = pick(opts); useSkill(s, h, si, g, ev, true); } else bark();
    }
  }
  function swapH(s, i, j, ev) {
    const t = s.pt[i]; s.pt[i] = s.pt[j]; s.pt[j] = t;
    ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi ? s.fi.en.map((x) => x.u) : [] });
  }
  function moveIn(arr, i, d) {   // d > 0 = 뒤로, d < 0 = 앞으로
    const j = clamp(i + d, 0, arr.length - 1);
    if (j === i) return false;
    const [x] = arr.splice(i, 1); arr.splice(j, 0, x); return true;
  }
  /* 기술을 쓸 수 있나 · 대상 목록 */
  function heroRank(s, h) { return s.pt.indexOf(h); }
  function canUse(s, h, si) {
    const S = CL[h.c].sk[si], r = heroRank(s, h);
    if (r < 0 || !S.f.includes(String(r + 1))) return false;
    if (S.low && h.hp > hStats(s, h).mh / 2 && !h.dd) return false;
    if (S.sm > 0 && h.af === 'fear') return false;
    return targetsFor(s, h, si).length > 0;
  }
  function targetsFor(s, h, si) {
    const S = CL[h.c].sk[si];
    if (S.t === 's' || S.t === 'p') return [-1];
    if (S.t === 'e') {
      const out = [];
      if (!s.fi) return out;
      s.fi.en.forEach((e, i) => { if (S.r.includes(String(i + 1))) out.push(i); });
      return S.m ? (out.length ? [-1] : []) : out;
    }
    const out = [];
    s.pt.forEach((o, i) => { if (S.r.includes(String(i + 1)) && !(S.t === 'o' && o === h)) out.push(i); });
    return out;
  }
  function resist(base, res) { return clamp(base - res, 0, 95); }
  function hitChance(s, atkU, S, tgU, heroAtk) {
    const am = stOf(s, atkU), tm = stOf(s, tgU);
    let acc = (S.acc || 100) + am.acc - tm.dg;
    if (!heroAtk) acc += LB[band(s.light)].eAcc + 3;
    if (tgU.fx.some((f) => f.k === 'mk') && !heroAtk) acc += 5;
    return clamp(acc, 5, 95);
  }
  function critChance(s, atkU, S, heroAtk) {
    const am = stOf(s, atkU);
    let c = am.cr + (S.cr || 0);
    if (!heroAtk) c += LB[band(s.light)].eCr;
    return clamp(c, 0, 60);
  }
  function dmgRange(s, atkU, S, tgU, heroAtk) {
    const am = stOf(s, atkU), tm = stOf(s, tgU);
    let mul = S.dm * (1 + (am.dm || 0) / 100);
    if (heroAtk) {
      const tg = EI[tgU.e].tg;
      if ((tg === 'U' || tg === 'E') && (S.vsU || am.vsU)) mul *= 1 + (S.vsU || 0) + am.vsU / 100;
      if (tg === 'B' && am.vsB) mul *= 1 + am.vsB / 100;
      if (S.vsM && tgU.fx.some((f) => f.k === 'mk')) mul *= 1 + S.vsM;
      if (S.exe && tgU.hp <= tgU.mh / 3) mul *= 1 + S.exe;
    } else {
      mul *= 1 + LB[band(s.light)].eDm / 100;
      if (tgU.fx.some((f) => f.k === 'mk')) mul *= 1.15;
    }
    const pr = S.ip ? 0 : tm.pr;
    const k = mul * (1 - pr / 100);
    return [Math.max(S.dm > 0 ? 1 : 0, Math.round(am.lo * k)), Math.max(S.dm > 0 ? 1 : 0, Math.round(am.hi * k))];
  }
  function applyFx(s, src, tg, list, ev, heroSrc) {
    if (!list) return;
    const tm = stOf(s, tg);
    const tgHero = isHero(s, tg.u);
    for (const f of list) {
      const chance = (c, r) => Math.random() * 100 < resist(c == null ? 100 : c, r);
      if (f.k === 'bl' || f.k === 'bg') {
        if (chance(f.c, f.k === 'bl' ? tm.res.bl : tm.res.bg)) { tg.fx.push({ k: f.k, n: Math.max(1, Math.round(f.n * (1 + (heroSrc ? 0 : (tg.lv || s.fl) * 0.06)))), t: f.t }); ev.push({ k: 'fx', u: tg.u, f: f.k }); }
        else ev.push({ k: 'resist', u: tg.u, f: f.k });
      } else if (f.k === 'stun') {
        if (chance(f.c, tm.res.st)) { if (!tg.fx.some((x) => x.k === 'stun')) tg.fx.push({ k: 'stun' }); ev.push({ k: 'fx', u: tg.u, f: 'stun' }); }
        else ev.push({ k: 'resist', u: tg.u, f: 'stun' });
      } else if (f.k === 'mk') { tg.fx = tg.fx.filter((x) => x.k !== 'mk'); tg.fx.push({ k: 'mk', t: f.t }); ev.push({ k: 'fx', u: tg.u, f: 'mk' }); }
      else if (f.k === 'db') {
        if (chance(f.c, tm.res.db)) { tg.fx.push({ k: 'db', s: f.s, v: f.v, t: f.t }); ev.push({ k: 'fx', u: tg.u, f: 'db', s: f.s, v: f.v }); }
        else ev.push({ k: 'resist', u: tg.u, f: 'db' });
      } else if (f.k === 'bf') { tg.fx.push({ k: 'bf', s: f.s, v: f.v, t: f.t }); ev.push({ k: 'fx', u: tg.u, f: 'bf', s: f.s, v: f.v }); }
      else if (f.k === 'gd') { tg.fx = tg.fx.filter((x) => x.k !== 'gd'); tg.fx.push({ k: 'gd', by: src.u, t: f.t }); ev.push({ k: 'fx', u: tg.u, f: 'gd' }); }
      else if (f.k === 'rp') { tg.fx = tg.fx.filter((x) => x.k !== 'rp'); tg.fx.push({ k: 'rp', t: f.t }); ev.push({ k: 'fx', u: tg.u, f: 'rp' }); }
      else if (f.k === 'tn') { tg.fx = tg.fx.filter((x) => x.k !== 'tn'); tg.fx.push({ k: 'tn', t: f.t }); ev.push({ k: 'fx', u: tg.u, f: 'tn' }); }
      else if (f.k === 'cu') { const n0 = tg.fx.length; tg.fx = tg.fx.filter((x) => x.k !== 'bl' && x.k !== 'bg'); if (tg.fx.length !== n0) ev.push({ k: 'cure', u: tg.u }); }
      else if (f.k === 'st') { if (tgHero) addSt(s, tg, f.v, ev); }
      else if (f.k === 'hurt') { if (tgHero) { ev.push({ k: 'hit', u: tg.u, d: f.v, hp: Math.max(0, tg.hp - f.v), self: 1 }); hurtHero(s, tg, f.v, ev, '', true); } }
      else if (f.k === 'pu' || f.k === 'pl') {
        if (chance(f.c, tm.res.mv)) {
          const arr = tgHero ? s.pt : s.fi.en, i = arr.indexOf(tg);
          if (i >= 0 && moveIn(arr, i, f.k === 'pu' ? f.n : -f.n)) ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi.en.map((x) => x.u), mv: tg.u });
        } else ev.push({ k: 'resist', u: tg.u, f: 'mv' });
      }
    }
  }
  /* 원정대 기술 쓰기 */
  function useSkill(s, h, si, g, ev, wild) {
    const S = CL[h.c].sk[si];
    s.fi.cur = 0;
    ev.push({ k: 'act', u: h.u, n: S.n, ic: S.ic, wild: wild ? 1 : 0 });
    const tgs = [];
    if (S.t === 'e') { if (S.m) s.fi.en.forEach((e, i) => { if (S.r.includes(String(i + 1))) tgs.push(e); }); else if (s.fi.en[g]) tgs.push(s.fi.en[g]); }
    else if (S.t === 's') tgs.push(h);
    else if (S.t === 'p') tgs.push(...s.pt);
    else if (s.pt[g]) tgs.push(s.pt[g]);
    let crit = false;
    for (const t of tgs) {
      if (S.t === 'e') {
        if (!s.fi.en.includes(t)) continue;
        if (Math.random() * 100 >= hitChance(s, h, S, t, true)) { ev.push({ k: 'miss', u: t.u }); continue; }
        if (S.dm > 0) {
          const [lo, hi] = dmgRange(s, h, S, t, true);
          let d = rnd(lo, hi);
          const c = Math.random() * 100 < critChance(s, h, S, true);
          if (c) { d = Math.round(d * 1.5); crit = true; }
          t.hp -= d;
          ev.push({ k: 'hit', u: t.u, d, cr: c ? 1 : 0, hp: Math.max(0, t.hp) });
          if (S.gold) { const gd = rnd(S.gold[0], S.gold[1]); s.gold += gd; s.st.gold += gd; ev.push({ k: 'gold', v: gd }); }
          if (t.hp <= 0) { enemyDie(s, t, ev); continue; }
        }
        applyFx(s, h, t, S.fx, ev, true);
      } else {
        if (S.hl) {
          const m = hStats(s, h);
          let v = rnd(S.hl[0], S.hl[1]) * (1 + 0.06 * (h.lv - 1)) * (1 + m.hb / 100);
          if (Math.random() < 0.06) { v *= 1.5; ev.push({ k: 'hcrit', u: t.u }); }
          healHero(s, t, Math.round(v), ev, h);
        }
        if (S.sh) addSt(s, t, -S.sh, ev);
        if (S.fx) applyFx(s, h, t, S.fx, ev, true);
      }
    }
    if (S.lt) { s.light = clamp(s.light + S.lt, 0, 100); ev.push({ k: 'light', v: S.lt, l: s.light }); }
    if (S.sx) applyFx(s, h, h, S.sx, ev, true);
    if (S.sm) { const i = s.pt.indexOf(h); if (i >= 0 && moveIn(s.pt, i, -S.sm)) ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi.en.map((x) => x.u), mv: h.u }); }
    if (crit) {
      s.st.crits++;
      ev.push({ k: 'critok', u: h.u });
      for (const o of s.pt) addSt(s, o, o === h ? -6 : -3, ev);
      if (Math.random() < 0.3) s.nar = narr('crit');
    }
  }
  /* 적 차례 */
  function enemyRank(s, e) { return s.fi.en.indexOf(e); }
  function enemyAct(s, e, ev) {
    const D = EI[e.e], r = enemyRank(s, e) + 1;
    const opts = [];
    for (const S of D.sk) {
      if (!S.f.includes(String(r))) continue;
      const t = S.t || 'e';
      if (S.sum) { if (s.fi.en.length < 4) opts.push({ S, w: (S.w || 1) * (s.fi.en.length <= 2 ? 1.6 : 0.8), tg: [] }); continue; }
      if (t === 's') { opts.push({ S, w: (S.w || 1) * (e.fx.some((f) => f.k === 'bf') ? 0.2 : 1), tg: [e] }); continue; }
      if (t === 'a') {
        if (S.hl) { const hurt = s.fi.en.filter((x) => x.hp < x.mh * 0.7); if (hurt.length) opts.push({ S, w: 1.4, tg: [hurt.sort((a, b) => a.hp / a.mh - b.hp / b.mh)[0]] }); }
        else { const o = s.fi.en.filter((x) => x !== e && !x.fx.some((f) => f.k === 'bf')); if (o.length) opts.push({ S, w: (S.w || 0.7), tg: [pick(o)] }); }
        continue;
      }
      const cand = s.pt.filter((h, i) => S.r.includes(String(i + 1)));
      if (!cand.length) continue;
      if (S.m) { opts.push({ S, w: (S.w || 1) * (0.7 + cand.length * 0.15), tg: cand }); continue; }
      // 대상 고르기: 도발 · 표식 · 빈사 · 스트레스
      const tn = cand.filter((h) => h.fx.some((f) => f.k === 'tn'));
      let tg;
      if (tn.length && Math.random() < 0.75) tg = pick(tn);
      else {
        const ws = cand.map((h) => {
          let w = 1;
          if (h.fx.some((f) => f.k === 'mk')) w += 1.5;
          if (h.dd) w += S.dm > 0 ? 1.2 : 0.2;
          if (S.st && h.st >= 60 && !h.af) w += 0.8;
          if (S.dm > 0 && h.hp < hStats(s, h).mh * 0.35) w += 0.6;
          return w;
        });
        let tot = ws.reduce((a, b) => a + b, 0), x = Math.random() * tot; tg = cand[0];
        for (let i = 0; i < cand.length; i++) { x -= ws[i]; if (x <= 0) { tg = cand[i]; break; } }
      }
      opts.push({ S, w: (S.w || 1), tg: [tg] });
    }
    if (!opts.length) {
      // 쓸 기술이 없으면 앞으로 한 칸
      const i = s.fi.en.indexOf(e);
      if (i > 0 && moveIn(s.fi.en, i, -1)) ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi.en.map((x) => x.u), mv: e.u });
      else ev.push({ k: 'pass', u: e.u });
      return;
    }
    let tot = opts.reduce((a, o) => a + o.w, 0), x = Math.random() * tot, o = opts[0];
    for (const op of opts) { x -= op.w; if (x <= 0) { o = op; break; } }
    const S = o.S;
    ev.push({ k: 'act', u: e.u, n: S.n, en: 1 });
    if (S.sum) {
      const m = mkEnemy(s, S.sum, 0); s.fi.en.push(m);
      ev.push({ k: 'sum', e: { u: m.u, e: m.e, hp: m.hp, mh: m.mh } });
      ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: s.fi.en.map((x) => x.u) });
      return;
    }
    if (S.self) { e.hp = Math.max(1, e.hp - S.self); ev.push({ k: 'hit', u: e.u, d: S.self, hp: e.hp, self: 1 }); }
    const t = S.t || 'e';
    if (t === 's' || t === 'a') {
      for (const tg of o.tg) {
        if (S.hl) { const v = Math.round(rnd(S.hl[0], S.hl[1]) * (1 + 0.1 * s.fl)); const was = tg.hp; tg.hp = Math.min(tg.mh, tg.hp + v); ev.push({ k: 'heal', u: tg.u, v: tg.hp - was, hp: tg.hp }); }
        applyFx(s, e, tg, S.fx, ev, false);
      }
      return;
    }
    let anyHit = false;
    for (let tg of o.tg) {
      if (!s.pt.includes(tg)) continue;
      // 호위
      const gd = tg.fx.find((f) => f.k === 'gd');
      if (gd && !S.m) { const by = s.pt.find((x) => x.u === gd.by); if (by && by !== tg) { ev.push({ k: 'guard', u: by.u, from: tg.u }); tg = by; } }
      if (Math.random() * 100 >= hitChance(s, e, S, tg, false)) { ev.push({ k: 'miss', u: tg.u }); riposte(s, tg, e, ev); continue; }
      anyHit = true;
      if (S.dm > 0) {
        const [lo, hi] = dmgRange(s, e, S, tg, false);
        let d = rnd(lo, hi);
        const c = Math.random() * 100 < critChance(s, e, S, false);
        if (c) d = Math.round(d * 1.5);
        ev.push({ k: 'hit', u: tg.u, d, cr: c ? 1 : 0, hp: Math.max(0, tg.hp - d), dd: tg.dd });
        hurtHero(s, tg, d, ev, enName(e));
        if (S.drain && s.fi.en.includes(e)) { const was = e.hp; e.hp = Math.min(e.mh, e.hp + Math.ceil(d / 2)); if (e.hp > was) ev.push({ k: 'heal', u: e.u, v: e.hp - was, hp: e.hp }); }
        if (!s.pt.includes(tg)) continue;
        if (c) { addSt(s, tg, 14, ev); if (!s.pt.includes(tg)) continue; }
      }
      if (S.st) { addSt(s, tg, Math.round(S.st * (1.35 + 0.05 * effF(s.fl))), ev); if (!s.pt.includes(tg)) continue; }
      applyFx(s, e, tg, S.fx, ev, false);
      if (s.pt.includes(tg)) riposte(s, tg, e, ev);
    }
    if (S.lt && (anyHit || S.m)) { s.light = clamp(s.light + S.lt, 0, 100); ev.push({ k: 'light', v: S.lt, l: s.light }); }
  }
  function riposte(s, h, e, ev) {
    if (!h.fx.some((f) => f.k === 'rp') || !s.fi.en.includes(e) || !s.pt.includes(h)) return;
    const S = { acc: 90, dm: 0.8 };
    ev.push({ k: 'act', u: h.u, n: '반격', ic: 'riposte' });
    if (Math.random() * 100 >= hitChance(s, h, S, e, true)) { ev.push({ k: 'miss', u: e.u }); return; }
    const [lo, hi] = dmgRange(s, h, S, e, true);
    const d = rnd(lo, hi); e.hp -= d;
    ev.push({ k: 'hit', u: e.u, d, hp: Math.max(0, e.hp) });
    if (e.hp <= 0) enemyDie(s, e, ev);
  }
  function endFight(s, ev) {
    const fi = s.fi;
    if (!s.pt.length) return;
    // 승리
    for (const h of s.pt) h.fx = h.fx.filter((f) => f.k === 'ddr');
    const n0 = fi.n0;
    const mul = LB[band(s.light)].loot;
    let gold = Math.round(rnd(5, 12) * (n0 / 3 + 0.3) * (1 + 0.12 * s.fl) * mul);
    if (fi.boss) gold += 80 + 20 * s.fl;
    const klep = s.pt.find((h) => h.q.includes('klep'));
    let stole = 0;
    if (klep) { stole = Math.round(gold * 0.2); gold -= stole; }
    s.gold += gold; s.st.gold += gold;
    const loot = { gold, stole, items: {}, trk: [] };
    if (Math.random() < 0.1 * mul || fi.boss) {
      const own = (id) => s.bag.includes(id) || s.pt.some((h) => h.tr.includes(id));
      const t = fi.boss ? pick(TRK.filter((x) => x.r === 3 && !own(x.id))) || pick(TRK.filter((x) => x.r === 2 && !own(x.id))) : rollTrk(s, 0);
      if (t) { s.bag.push(t.id); loot.trk.push(t.id); }
    }
    if (Math.random() < 0.35) { const k = pick(['food', 'torch', 'band', 'anti', 'food']); const n = rnd(1, 2); s.inv[k] += n; loot.items[k] = n; }
    // 경험치
    const xp = n0 + (fi.boss ? 8 : 0);
    for (const h of s.pt) gainXp(s, h, xp, ev);
    // 방 정리
    if (fi.kind === 'room' && fi.room >= 0) {
      const r = s.mp.r[fi.room];
      if (r.k === 't') {
        const g2 = Math.round(rnd(35, 80) * (1 + 0.1 * s.fl) * mul); s.gold += g2; s.st.gold += g2; loot.gold += g2; loot.chest = 1;
        if (Math.random() < 0.45) { const t = rollTrk(s, 1); if (t) { s.bag.push(t.id); loot.trk.push(t.id); } }
      }
      r.k = r.k === 'b' ? 'x' : 'e';
    } else if (fi.kind === 'cor') {
      const at = s.mp.at; if (at.c != null) { const c = s.mp.c[at.c]; c.s = c.s.slice(0, at.i) + '.' + c.s.slice(at.i + 1); }
    }
    ev.push({ k: 'win', loot, boss: fi.boss });
    logp(s, (fi.boss ? '우두머리 처치' : '전투 승리') + ' · 금화 ' + gold);
    const kind = fi.kind;
    s.fi = null;
    if (kind === 'camp') { nextFloor(s, ev); return; }
    if (kind === 'curio') { s.ph = 'map'; return; }
    s.ph = 'map';
  }
  function rollTrk(s, bonus) {
    const r = Math.random() * 100 - bonus * 25 - s.fl * 3;
    const rar = r < 6 ? 2 : r < 38 ? 1 : 0;
    const pool = TRK.filter((t) => t.r === rar && !s.bag.includes(t.id) && !s.pt.some((h) => h.tr.includes(t.id)));
    return pool.length ? pick(pool) : null;
  }
  function gainXp(s, h, v, ev) {
    h.xp += v;
    while (h.lv < 5 && h.xp >= LVXP[h.lv]) {
      const before = hStats(s, h).mh;
      h.lv++;
      const after = hStats(s, h).mh;
      h.hp = Math.min(after, h.hp + (after - before));
      ev.push({ k: 'lvl', u: h.u, lv: h.lv });
      logp(s, heroName(h) + ' · ' + h.lv + '단계');
    }
  }
  function flee(s, ev) {
    const fi = s.fi;
    const ch = fi.boss ? 45 : 75;
    if (Math.random() * 100 >= ch) { ev.push({ k: 'fleefail' }); return false; }
    ev.push({ k: 'flee', who: 'h' });
    for (const h of s.pt) { h.fx = h.fx.filter((f) => f.k === 'ddr'); addSt(s, h, 6, ev); }
    // 앞의 방으로 물러남
    if (fi.kind === 'room' || fi.kind === 'cor') s.mp.at = { r: s.mp.prev };
    s.fi = null;
    s.ph = fi.kind === 'camp' ? 'camp' : 'map';
    if (fi.kind === 'camp') { nextFloor(s, ev); }
    logp(s, '후퇴');
    return true;
  }

  /* ---------- 이동 ---------- */
  function step(s, ev) {
    s.light = Math.max(0, s.light - 5);
    s.st.steps++;
    s.hu++;
    const b = band(s.light);
    const sv = LB[b].step < 1 ? (s.st.steps % 2 ? 1 : 0) : LB[b].step;
    if (sv) for (const h of s.pt.slice()) addSt(s, h, sv, ev);
    if (b >= 3 && Math.random() < 0.08) s.nar = narr(b === 4 ? 'pitch' : 'dark');
    if (s.hu >= 14) { s.hu = 0; hunger(s, ev); }
  }
  function hunger(s, ev) {
    const need = s.pt.length;
    if (s.inv.food >= need) { s.inv.food -= need; ev.push({ k: 'hunger', ok: 1, n: need }); logp(s, '허기 · 식량 ' + need); for (const h of s.pt) healHero(s, h, 2, ev, h); return; }
    const fed = s.inv.food; s.inv.food = 0;
    ev.push({ k: 'hunger', ok: 0, n: fed });
    logp(s, '허기 · 식량 부족');
    s.pt.slice(fed).forEach((h) => { addSt(s, h, 12, ev); if (s.pt.includes(h)) { const d = Math.max(1, Math.round(hStats(s, h).mh * 0.1)); ev.push({ k: 'hit', u: h.u, d, hp: Math.max(1, h.hp - d), self: 1 }); hurtHero(s, h, d, ev, '굶주림', true); } });
  }
  function trap(s, ev) {
    const T = pick(TRAPS);
    const h = s.pt[0]; if (!h) return;
    const m = hStats(s, h);
    const ch = 25 + m.res.tr + (100 - s.light) * -0.1 + s.light * 0.25;
    if (Math.random() * 100 < ch) { ev.push({ k: 'trap', n: T.n, ok: 1, u: h.u }); addSt(s, h, -4, ev); gainXp(s, h, 1, ev); return; }
    ev.push({ k: 'trap', n: T.n, ok: 0, u: h.u, d: T.d });
    const tgs = T.e.all ? s.pt.slice() : [h];
    for (const t of tgs) {
      if (!s.pt.includes(t)) continue;
      if (T.e.hurt) { const d = Math.max(1, Math.round(hStats(s, t).mh * T.e.hurt / 100 * (T.e.all ? 0.6 : 1))); ev.push({ k: 'hit', u: t.u, d, hp: Math.max(0, t.hp - d) }); hurtHero(s, t, d, ev, T.n); }
      if (!s.pt.includes(t)) continue;
      if (T.e.st) addSt(s, t, T.e.st, ev);
      if (T.e.bl) t.fx.push({ k: 'bl', n: T.e.bl, t: 3 });
      if (T.e.bg) t.fx.push({ k: 'bg', n: T.e.bg, t: 3 });
    }
    // 지도 밖에서는 지속 피해가 바로 들어감
    dotOut(s, ev);
  }
  function dotOut(s, ev) {   // 전투 밖: 출혈·역병을 한 번에 정산(통로 한 칸마다 1회)
    for (const h of s.pt.slice()) {
      let d = 0;
      h.fx = h.fx.filter((f) => { if (f.k === 'bl' || f.k === 'bg') { d += f.n; f.t--; return f.t > 0; } return true; });
      if (d > 0) { ev.push({ k: 'dot', u: h.u, d }); hurtHero(s, h, d, ev, '지속 피해', true); ev.push({ k: 'hp', u: h.u, hp: h.hp }); }
    }
  }
  function obstacle(s, ev) {
    if (s.inv.shovel > 0) { s.inv.shovel--; ev.push({ k: 'obs', ok: 1 }); return; }
    ev.push({ k: 'obs', ok: 0 });
    for (const h of s.pt.slice()) { addSt(s, h, 6, ev); if (s.pt.includes(h)) { const d = Math.max(1, Math.round(hStats(s, h).mh * 0.06)); hurtHero(s, h, d, ev, '', true); ev.push({ k: 'hp', u: h.u, hp: h.hp }); } }
  }
  function go(s, to, ev) {
    const mp = s.mp, at = mp.at;
    let ci, from, seq;
    if (at.c != null) {
      const c = mp.c[at.c]; ci = at.c;
      if (to !== c.a && to !== c.b) throw new Error('bad room');
      const fwd = to === c.b;
      from = fwd ? c.a : c.b;
      seq = []; if (fwd) for (let i = at.i + 1; i < c.s.length; i++) seq.push(i); else for (let i = at.i - 1; i >= 0; i--) seq.push(i);
      // 지금 칸에 남은 사건(후퇴로 남은 싸움 등)은 넘어감
    } else {
      ci = corOf(s, at.r, to); if (ci < 0) throw new Error('not adjacent');
      const c = mp.c[ci]; from = at.r;
      const fwd = c.a === at.r;
      seq = []; if (fwd) for (let i = 0; i < c.s.length; i++) seq.push(i); else for (let i = c.s.length - 1; i >= 0; i--) seq.push(i);
    }
    const c = mp.c[ci];
    mp.prev = from;
    ev.push({ k: 'walk', c: ci, to });
    for (const i of seq) {
      if (s.ph !== 'map' || !s.pt.length) return;
      step(s, ev);
      if (!s.pt.length) return;
      if (s.pt.some((h) => h.fx.some((f) => f.k === 'bl' || f.k === 'bg'))) dotOut(s, ev);
      if (!s.pt.length) return;
      c.w |= 1 << i;
      mp.at = { c: ci, i, to };
      ev.push({ k: 'seg', c: ci, i });
      const k = c.s[i];
      if (k === '.') continue;
      if (k === 'T') { c.s = c.s.slice(0, i) + '.' + c.s.slice(i + 1); trap(s, ev); if (!s.pt.length) return; continue; }
      if (k === 'O') { c.s = c.s.slice(0, i) + '.' + c.s.slice(i + 1); obstacle(s, ev); continue; }
      if (k === 'C') {
        const id = c.cu[i] || 'books';
        c.s = c.s.slice(0, i) + '.' + c.s.slice(i + 1);
        openCurio(s, id, ev);
        return;
      }
      if (k === 'F') { startFight(s, encounter(s, 'cor'), 'cor', ev); return; }
    }
    // 도착
    mp.at = { r: to };
    const R = mp.r[to];
    const first = !R.v;
    R.v = 1; R.sc = 1;
    if (first) s.st.rooms++;
    ev.push({ k: 'room', r: to, rk: R.k });
    if (first) scout(s, to, ev);
    if (R.k === 'f' || R.k === 't') startFight(s, encounter(s, 'room'), 'room', ev, to);
    else if (R.k === 'b') startFight(s, bossGroup(s), 'room', ev, to);
    else if (R.k === 'c' && R.c) { const id = R.c; R.k = 'e'; R.c = ''; openCurio(s, id, ev); }
  }
  function bossGroup(s) {
    const z = ZI[s.mp.z], ids = [z.boss];
    const pool = EN.filter((e) => !e.boss && e.z === s.mp.z);
    ids.push(pick(pool).id);
    if (s.fl >= 3 || Math.random() < 0.5) ids.push(pick(pool).id);
    return ids;
  }

  /* ---------- 기묘한 물건 ---------- */
  function openCurio(s, id, ev) {
    s.ph = 'curio'; s.cu = { id, done: 0 };
    ev.push({ k: 'curio', id });
    // 손대는 버릇
    const comp = s.pt.find((h) => h.q.includes('comp'));
    if (comp && Math.random() < 0.35) { ev.push({ k: 'say', u: comp.u, t: '손이 먼저 나갔다.' }); curioDo(s, 'touch', null, ev, comp); }
  }
  function curioDo(s, how, it, ev, who) {
    const C = CI[s.cu.id];
    if (how === 'leave') { ev.push({ k: 'cres', id: C.id, leave: 1 }); s.cu = null; s.ph = 'map'; return; }
    let good;
    if (how === 'use') {
      if (!it || it !== C.it || !(s.inv[it] > 0)) throw new Error('bad item');
      s.inv[it]--; good = true;
    } else good = Math.random() < C.g + (s.light <= 25 ? -0.05 : 0);
    const h = who || pick(s.pt);
    const out = good ? pick(C.good) : pick(C.bad);
    const res = { k: 'cres', id: C.id, good: good ? 1 : 0, u: h.u, o: out, txt: [] };
    ev.push(res);
    s.cu = null; s.ph = 'map';
    const mul = LB[band(s.light)].loot;
    if (out.gold) { const g = Math.round(rnd(out.gold[0], out.gold[1]) * 0.5 * mul * (1 + 0.08 * s.fl)); s.gold += g; s.st.gold += g; res.txt.push('금화 +' + g); }
    if (out.trk != null) { const t = rollTrk(s, out.trk); if (t) { s.bag.push(t.id); res.txt.push('장신구: ' + t.n); } else { s.gold += 60; res.txt.push('금화 +60'); } }
    if (out.item) for (const k in out.item) { s.inv[k] += out.item[k]; res.txt.push(PV[k].n + ' +' + out.item[k]); }
    if (out.heal) { for (const x of s.pt) healHero(s, x, Math.round(hStats(s, x).mh * out.heal / 100), ev, x); res.txt.push('전원 체력 회복'); }
    if (out.st) { if (out.st < 0) { for (const x of s.pt.slice()) addSt(s, x, out.st, ev); res.txt.push('전원 스트레스 ' + out.st); } else { addSt(s, h, out.st, ev); res.txt.push('스트레스 +' + out.st); } }
    if (out.qk) { const q = addQuirk(s, h, out.qk > 0 ? 1 : 0, ev); if (q) res.txt.push('기질: ' + q.n); }
    if (out.bl) { h.fx.push({ k: 'bl', n: out.bl, t: 3 }); res.txt.push('출혈'); }
    if (out.bg) { h.fx.push({ k: 'bg', n: out.bg, t: 3 }); res.txt.push('역병'); }
    if (out.hurt) { const d = Math.round(hStats(s, h).mh * out.hurt / 100); ev.push({ k: 'hit', u: h.u, d, hp: Math.max(1, h.hp - d) }); hurtHero(s, h, d, ev, '', true); res.txt.push('체력 −' + d); }
    if (out.light) { s.light = clamp(s.light + out.light, 0, 100); res.txt.push('빛 ' + (out.light > 0 ? '+' : '') + out.light); }
    if (out.buf) { h.cb.push({ s: out.buf.s, v: out.buf.v }); res.txt.push(fmtMod(out.buf.s, out.buf.v) + ' (이번 층)'); }
    if (out.xp) { for (const x of s.pt) gainXp(s, x, out.xp, ev); res.txt.push('경험 +' + out.xp); }
    if (out.vir) { if (!h.vi && !h.af) { h.st = Math.max(h.st, 100); resolve(s, h, ev); } else addSt(s, h, -10, ev); }
    if (out.fight) { res.txt.push('무언가 깨어났다'); startFight(s, encounter(s, 'cor'), 'curio', ev); }
    logp(s, C.n + ' · ' + (res.txt.join(', ') || '아무 일 없음'));
    if (Math.random() < 0.15) s.nar = narr(good ? 'loot' : 'curio');
  }

  /* ---------- 층 넘어가기 · 야영 · 역참 ---------- */
  function descend(s, ev) {
    const R = s.mp.r[s.mp.at.r];
    if (s.mp.at.c != null || !R || R.k !== 'x') throw new Error('not at exit');
    for (const h of s.pt) { h.cb = []; h.fx = h.fx.filter((f) => f.k !== 'ddr'); }   // 이번 층 강화·문턱 후유증은 층이 끝나면 사라짐
    if (s.fl >= s.len - 1) { endRun(s, true, ev); return; }
    if ((s.fl + 1) % ZLEN === 0) { s.fl++; openWay(s, ev); return; }
    openCamp(s, ev);
  }
  function openCamp(s, ev) {
    s.ph = 'camp';
    s.cp = { h: CAMP_H, used: [], amb: 22, sc: 0 };
    // 식사
    const fed = [];
    let food = s.inv.food;
    for (const h of s.pt) {
      const need = h.q.includes('glut') ? 2 : 1;
      if (food >= need) { food -= need; fed.push(h); }
    }
    s.inv.food = food;
    ev.push({ k: 'camp', fed: fed.length, n: s.pt.length });
    for (const h of s.pt.slice()) {
      if (fed.includes(h)) { healHero(s, h, Math.round(hStats(s, h).mh * 0.1 * (h.q.includes('insom') ? 0.5 : 1)), ev, h); addSt(s, h, -5, ev); }
      else { addSt(s, h, 15, ev); if (s.pt.includes(h)) { hurtHero(s, h, Math.max(1, Math.round(hStats(s, h).mh * 0.1)), ev, '굶주림', true); } }
    }
    // 원정 중 기질
    for (const h of s.pt) if (Math.random() < 0.18) addQuirk(s, h, Math.random() < 0.5 ? 1 : 0, ev);
    s.nar = narr('camp');
    logp(s, '야영 · 식사 ' + fed.length + '/' + s.pt.length);
  }
  function campSkills(h) { return CL[h.c].camp.concat(CAMP_ALL); }
  function campTargets(s, h, ci) {
    const C = campSkills(h)[ci]; if (!C) return [];
    if (C.t === 's' || C.t === 'p') return [-1];
    const out = []; s.pt.forEach((o, i) => { if (!(C.t === 'o' && o === h)) out.push(i); }); return out;
  }
  function campUse(s, hi, ci, g, ev) {
    const h = s.pt[hi]; if (!h) throw new Error('no hero');
    const C = campSkills(h)[ci]; if (!C) throw new Error('no camp skill');
    if (s.cp.h < C.h) throw new Error('no time');
    const key = h.u + ':' + ci;
    if (s.cp.used.includes(key)) throw new Error('used');
    const tg = C.t === 's' ? [h] : C.t === 'p' ? s.pt.slice() : [s.pt[g]];
    if (!tg[0] || (C.t === 'o' && tg[0] === h)) throw new Error('bad target');
    s.cp.h -= C.h; s.cp.used.push(key);
    ev.push({ k: 'cskill', u: h.u, n: C.n, ic: C.ic });
    const e = C.e;
    for (const t of tg) {
      if (!s.pt.includes(t)) continue;
      if (e.hp) healHero(s, t, Math.round(hStats(s, t).mh * e.hp / 100 * (t.q.includes('insom') ? 0.5 : 1)), ev, t);
      if (e.st) addSt(s, t, e.st < 0 ? Math.round(e.st * (t.q.includes('night2') ? 0.5 : 1)) : e.st, ev);
      if (e.cure) { const n0 = t.fx.length; t.fx = t.fx.filter((x) => x.k !== 'bl' && x.k !== 'bg'); if (n0 !== t.fx.length) ev.push({ k: 'cure', u: t.u }); }
      if (e.buf) { t.cb.push({ s: e.buf.s, v: e.buf.v }); ev.push({ k: 'fx', u: t.u, f: 'bf', s: e.buf.s, v: e.buf.v }); }
    }
    if (e.amb) s.cp.amb = Math.max(0, s.cp.amb + e.amb);
    if (e.light) { s.light = clamp(s.light + e.light, 0, 100); ev.push({ k: 'light', v: e.light, l: s.light }); }
    if (e.scout) s.cp.sc = 1;
    if (e.item) { s.inv[e.item]++; ev.push({ k: 'gain', it: e.item, n: 1 }); }
    if (e.food) { s.inv.food += e.food; ev.push({ k: 'gain', it: 'food', n: e.food }); }
    logp(s, heroName(h) + ' · ' + C.n);
  }
  function campEnd(s, ev) {
    const sc = s.cp.sc, amb = s.cp.amb;
    s.cp = null;
    if (Math.random() * 100 < amb) {
      ev.push({ k: 'ambush' });
      logp(s, '야습');
      s.scNext = sc;
      startFight(s, encounter(s, 'camp'), 'camp', ev);
      return;
    }
    s.scNext = sc;
    nextFloor(s, ev);
  }
  function nextFloor(s, ev) {
    if (s.ph !== 'way') s.fl++;
    s.cp = null; s.wy = null;
    genFloor(s);
    s.nar = narr('floor');
    ev.push({ k: 'floor', fl: s.fl, z: s.mp.z });
    if (s.scNext) { scout(s, 0, ev, true); s.scNext = 0; }
    else scout(s, 0, ev);
    logp(s, (s.fl + 1) + '층 · ' + ZI[s.mp.z].n);
  }
  function openWay(s, ev) {
    s.ph = 'way';
    const minLv = s.pt.length ? Math.max(1, Math.min(...s.pt.map((h) => h.lv)) - 0) : 2;
    s.wy = { c: candidates(s, 3, Math.min(4, minLv), s.pt.map((h) => h.c)), rest: [] };
    s.nar = narr('way');
    ev.push({ k: 'way' });
    logp(s, '역참 도착');
  }
  const recruitCost = (h) => 140 + 70 * (h.lv - 1);
  const restCost = 55;
  function endRun(s, win, ev) {
    s.ph = 'end';
    s.res = { win: win ? 1 : 0, fl: win ? s.len : s.fl };
    s.cu = null; s.cp = null; s.wy = null;
    s.nar = narr(win ? 'win' : 'lose');
    if (ev) ev.push({ k: 'end', win: win ? 1 : 0 });
  }

  /* ---------- 공용: actor · apply ---------- */
  function actor(s) {
    if (!s || s.res) return null;
    if (s.ph === 'fight') { const h = s.pt.find((x) => x.u === s.fi.cur); return h ? h.o % s.np : 0; }
    return s.ld % s.np;
  }
  function useItem(s, it, g, ev, inFight) {
    if (!(s.inv[it] > 0)) throw new Error('no item');
    if (it === 'torch') { s.inv.torch--; s.light = Math.min(100, s.light + 25); ev.push({ k: 'light', v: 25, l: s.light, torch: 1 }); return; }
    const h = s.pt[g]; if (!h) throw new Error('no target');
    if (it === 'food') { if (inFight) throw new Error('no food in fight'); s.inv.food--; healHero(s, h, 3, ev, h); return; }
    if (it === 'band') { s.inv.band--; const n0 = h.fx.length; h.fx = h.fx.filter((f) => f.k !== 'bl'); if (n0 !== h.fx.length) ev.push({ k: 'cure', u: h.u }); healHero(s, h, 2, ev, h); return; }
    if (it === 'anti') { s.inv.anti--; const n0 = h.fx.length; h.fx = h.fx.filter((f) => f.k !== 'bg'); if (n0 !== h.fx.length) ev.push({ k: 'cure', u: h.u }); return; }
    if (it === 'laud') { s.inv.laud--; addSt(s, h, -20, ev); return; }
    if (it === 'holy') { s.inv.holy--; h.fx.push({ k: 'rs', v: 30, t: 3 }); addSt(s, h, -5, ev); ev.push({ k: 'fx', u: h.u, f: 'bf', s: 'res', v: 30 }); return; }
    throw new Error('item not usable');
  }
  function freeAct(s, a, ev) {   // 전투 밖에서 언제나 할 수 있는 정리(자리 · 기술 · 장신구)
    if (a.t === 'sw') { const i = a.a, j = a.b; if (!s.pt[i] || !s.pt[j] || i === j) throw new Error('bad swap'); const t = s.pt[i]; s.pt[i] = s.pt[j]; s.pt[j] = t; ev.push({ k: 'pos', h: s.pt.map((x) => x.u), e: [] }); return true; }
    if (a.t === 'sks') {
      const h = s.pt[a.h]; if (!h || !Array.isArray(a.sk) || a.sk.length !== 4) throw new Error('bad skills');
      const set = new Set(a.sk); if (set.size !== 4 || a.sk.some((x) => !(x >= 0 && x < CL[h.c].sk.length))) throw new Error('bad skills');
      h.sk = a.sk.map(Number); return true;
    }
    if (a.t === 'eq') {
      const h = s.pt[a.h]; const i = s.bag.indexOf(a.tr); if (!h || i < 0) throw new Error('bad equip');
      const T = TI[a.tr]; if (T.cls && T.cls !== h.c) throw new Error('class only');
      if (h.tr.includes(a.tr)) throw new Error('dup');
      const slot = a.slot === 1 ? 1 : 0;
      s.bag.splice(i, 1);
      if (h.tr[slot]) s.bag.push(h.tr[slot]);
      h.tr[slot] = a.tr; h.tr = h.tr.filter(Boolean);
      h.hp = Math.min(h.hp, hStats(s, h).mh);
      return true;
    }
    if (a.t === 'uneq') { const h = s.pt[a.h]; if (!h || !h.tr[a.slot]) throw new Error('bad'); s.bag.push(h.tr[a.slot]); h.tr.splice(a.slot, 1); h.hp = Math.min(h.hp, hStats(s, h).mh); return true; }
    return false;
  }
  function apply(s, seat, a) {
    if (s.res) throw new Error('over');
    const ev = [];
    const done = () => { s.last = { id: (s.last ? s.last.id : 0) + 1, ev, seat, a: a.t }; return s; };
    if (s.ph === 'prep') {
      if (a.t !== 'start') throw new Error('prep');
      const ids = a.party || [];
      if (!ids.length || ids.length > 4 || new Set(ids).size !== ids.length) throw new Error('party');
      const buy = a.buy || {};
      let cost = 0; for (const k in buy) { if (!PV[k] || !(buy[k] >= 0)) throw new Error('buy'); cost += PV[k].p * buy[k]; }
      if (cost > s.gold) throw new Error('gold');
      s.pt = ids.map((i) => { const h = s.pr.c[i]; if (!h) throw new Error('cand'); return h; });
      s.pt.forEach((h, i) => { h.o = i % s.np; if (a.sk && a.sk[i]) { const sk = a.sk[i].map(Number); if (sk.length === 4 && new Set(sk).size === 4 && sk.every((x) => x >= 0 && x < CL[h.c].sk.length)) h.sk = sk; } });
      s.gold -= cost; for (const k in buy) s.inv[k] += buy[k];
      s.pr = null;
      genFloor(s);
      ev.push({ k: 'floor', fl: 0, z: s.mp.z });
      scout(s, 0, ev);
      logp(s, '원정 시작 · ' + ZI[s.mp.z].n);
      return done();
    }
    if (s.ph === 'fight') {
      const h = s.pt.find((x) => x.u === s.fi.cur); if (!h) throw new Error('no actor');
      if (a.t === 'it') { useItem(s, a.it, a.g, ev, true); return done(); }
      let act = a;
      // 붕괴한 대원은 명령을 거부할 수 있음
      if (h.af && (a.t === 'sk' || a.t === 'mv') && Math.random() < AF[h.af].ref) {
        ev.push({ k: 'refuse', u: h.u });
        actOut(s, h, ev);
        if (s.ph === 'fight') advance(s, ev);
        return done();
      }
      if (act.t === 'sk') {
        const si = h.sk[act.i]; if (si == null) throw new Error('slot');
        if (!canUse(s, h, si)) throw new Error('cannot use');
        const tg = targetsFor(s, h, si);
        const g = tg.includes(-1) ? -1 : act.g;
        if (!tg.includes(g)) throw new Error('bad target');
        useSkill(s, h, si, g, ev, false);
      } else if (act.t === 'mv') {
        const i = s.pt.indexOf(h), j = i + (act.d > 0 ? 1 : -1);
        if (j < 0 || j >= s.pt.length) throw new Error('cannot move');
        if (h.af === 'fear' && act.d < 0) throw new Error('fear');
        ev.push({ k: 'act', u: h.u, n: '자리 바꾸기', ic: 'back-forth' });
        swapH(s, i, j, ev);
      } else if (act.t === 'pass') { ev.push({ k: 'act', u: h.u, n: '버티기', ic: 'hourglass' }); ev.push({ k: 'pass', u: h.u }); }
      else if (act.t === 'flee') { ev.push({ k: 'act', u: h.u, n: '후퇴', ic: 'run' }); if (flee(s, ev)) return done(); }
      else throw new Error('fight action');
      if (s.ph === 'fight') advance(s, ev);
      return done();
    }
    if (s.ph === 'map') {
      if (freeAct(s, a, ev)) return done();
      if (a.t === 'go') { go(s, a.r, ev); return done(); }
      if (a.t === 'torch') { useItem(s, 'torch', 0, ev); return done(); }
      if (a.t === 'dim') { if (s.light <= 0) throw new Error('dark'); s.light = Math.max(0, s.light - 25); ev.push({ k: 'light', v: -25, l: s.light }); return done(); }
      if (a.t === 'it') { useItem(s, a.it, a.g, ev, false); return done(); }
      if (a.t === 'down') { descend(s, ev); return done(); }
      throw new Error('map action');
    }
    if (s.ph === 'curio') {
      if (a.t !== 'cu') throw new Error('curio');
      curioDo(s, a.k, a.it, ev);
      return done();
    }
    if (s.ph === 'camp') {
      if (freeAct(s, a, ev)) return done();
      if (a.t === 'cs') { campUse(s, a.h, a.c, a.g, ev); return done(); }
      if (a.t === 'it') { useItem(s, a.it, a.g, ev, false); return done(); }
      if (a.t === 'cend') { campEnd(s, ev); return done(); }
      throw new Error('camp');
    }
    if (s.ph === 'way') {
      if (freeAct(s, a, ev)) return done();
      const w = s.wy;
      if (a.t === 'buy') { const P = PV[a.it], n = Math.max(1, a.n | 0); if (!P || s.gold < P.p * n) throw new Error('gold'); s.gold -= P.p * n; s.inv[a.it] += n; ev.push({ k: 'gain', it: a.it, n }); return done(); }
      if (a.t === 'sell') { const i = s.bag.indexOf(a.tr); if (i < 0) throw new Error('bag'); s.bag.splice(i, 1); const v = RARV[TI[a.tr].r] / 2; s.gold += v; ev.push({ k: 'gold', v }); return done(); }
      if (a.t === 'rec') {
        const h = w.c[a.c]; if (!h || s.pt.length >= 4) throw new Error('recruit');
        const cost = recruitCost(h); if (s.gold < cost) throw new Error('gold');
        s.gold -= cost; w.c.splice(a.c, 1);
        const cnt = Array.from({ length: s.np }, (_, i) => s.pt.filter((x) => x.o === i).length);
        h.o = cnt.indexOf(Math.min(...cnt));
        s.pt.push(h); ev.push({ k: 'rec', u: h.u }); logp(s, heroName(h) + ' 합류');
        return done();
      }
      if (a.t === 'rest') {
        const h = s.pt[a.h]; if (!h || w.rest.includes(h.u) || s.gold < restCost) throw new Error('rest');
        s.gold -= restCost; w.rest.push(h.u);
        addSt(s, h, -40, ev); healHero(s, h, Math.round(hStats(s, h).mh * 0.5), ev, h);
        h.fx = h.fx.filter((f) => f.k !== 'ddr' && f.k !== 'bl' && f.k !== 'bg');
        return done();
      }
      if (a.t === 'it') { useItem(s, a.it, a.g, ev, false); return done(); }
      if (a.t === 'wend') { if (!s.pt.length) throw new Error('no party'); nextFloor(s, ev); return done(); }
      throw new Error('way');
    }
    throw new Error('phase');
  }
  function result(s) {
    if (!s.res) return null;
    const win = !!s.res.win;
    const seats = Array.from({ length: s.np }, (_, i) => i);
    const alive = s.pt.map(heroName);
    const text = win ? '가장 깊은 층의 주인을 쓰러뜨리고 살아 돌아왔어요. 돌아온 대원: ' + (alive.join(', ') || '없음') + '.'
      : (s.res.fl + 1) + '층에서 원정대가 모두 쓰러졌어요.';
    return {
      winners: win ? seats : [], title: win ? '원정 완수' : '원정대 전멸', text,
      highlights: [s.nar].filter(Boolean),
      stats: [
        { label: '도달한 층', value: (win ? s.len : s.fl + 1) + ' / ' + s.len },
        { label: '처치한 적', value: String(s.st.kills) },
        { label: '모은 금화', value: String(s.st.gold) },
        { label: '붕괴 · 각성', value: s.st.aff + ' · ' + s.st.vir },
        { label: '잃은 대원', value: String(s.dead.length) },
        { label: '우두머리', value: String(s.st.boss) },
      ],
    };
  }
  function habits(s, seat) {
    const k = s.seed + ':' + seat;
    const st = (L.aiStyle && L.aiStyle(seat)) || 'bal';
    const h = { agg: 0.85 + 0.35 * srand(k, 'agg'), cur: srand(k, 'cur'), lite: srand(k, 'lite'), heal: 0.85 + 0.4 * srand(k, 'heal'), expl: srand(k, 'expl'), thrift: srand(k, 'thr'), risk: srand(k, 'risk') };
    if (st === 'agg') { h.agg += 0.15; h.expl += 0.2; }
    else if (st === 'def') { h.heal += 0.2; h.lite += 0.2; h.risk -= 0.2; }
    else if (st === 'gamble') { h.cur += 0.3; h.risk += 0.3; h.lite -= 0.2; }
    return h;
  }
  const NOISE = { 1: [0.45, 1.1], 2: [0.8, 0.4], 3: [0.96, 0.08] };
  const noisy = (v, lv) => v * (NOISE[lv][0] + Math.random() * NOISE[lv][1]);

  /* ---------- 전투 ---------- */
  function threat(s, e) {
    const D = EI[e.e], m = eStats(s, e);
    let t = (m.lo + m.hi) / 2;
    if (D.sk.some((k) => k.st)) t += 4;
    if (D.sk.some((k) => k.fx && k.fx.some((f) => f.k === 'stun'))) t += 2;
    if (D.sk.some((k) => k.hl || k.sum)) t += 3;
    if (D.boss) t *= 1.4;
    if (e.fx.some((f) => f.k === 'stun')) t *= 0.4;
    return t;
  }
  function scoreSkill(s, h, si, g, lv, hb) {
    const S = CL[h.c].sk[si];
    const my = s.pt.indexOf(h);
    let v = 0;
    const partyVsM = s.pt.some((o) => o.sk.some((x) => CL[o.c].sk[x].vsM));
    if (S.t === 'e') {
      const tgs = S.m ? s.fi.en.filter((e, i) => S.r.includes(String(i + 1))) : [s.fi.en[g]];
      for (const t of tgs) {
        if (!t) continue;
        const hc = hitChance(s, h, S, t, true) / 100;
        const th = threat(s, t);
        const willAct = s.fi.q.includes(t.u);
        if (S.dm > 0) {
          const [lo, hi] = dmgRange(s, h, S, t, true), avg = (lo + hi) / 2, cc = critChance(s, h, S, true) / 100;
          const exp = hc * avg * (1 + 0.5 * cc);
          v += Math.min(exp, t.hp) * (1 + 0.12 * th);
          if (avg >= t.hp) v += hc * (6 + th * (lv === 3 ? 1.6 : 1) * (willAct ? 1.3 : 1));
          else if (lv === 3 && hi * 1.5 >= t.hp) v += hc * cc * th;
        }
        const tm = eStats(s, t);
        for (const f of S.fx || []) {
          const rc = (100 - Math.max(0, (f.c == null ? 100 : f.c) - 0) + 0) / 100;
          const pr = Math.max(0, ((f.c == null ? 100 : f.c) - (f.k === 'stun' ? tm.res.st : f.k === 'bl' ? tm.res.bl : f.k === 'bg' ? tm.res.bg : f.k === 'db' ? tm.res.db : f.k === 'pu' || f.k === 'pl' ? tm.res.mv : 0)) / 100);
          void rc;
          if (f.k === 'stun' && !t.fx.some((x) => x.k === 'stun')) v += hc * pr * (3 + th * 1.1) * (willAct || lv < 3 ? 1.2 : 0.7);
          else if (f.k === 'bl' || f.k === 'bg') v += hc * pr * Math.min(f.n * f.t, t.hp) * 0.55;
          else if (f.k === 'mk' && !t.fx.some((x) => x.k === 'mk')) v += partyVsM ? 4 : 1.2;
          else if (f.k === 'db') v += hc * pr * 2.2;
          else if (f.k === 'pl') { const i = s.fi.en.indexOf(t); v += i >= 2 ? 1.5 * hc * pr : 0.2; }
          else if (f.k === 'pu') v += 0.4 * hc * pr;
        }
        if (S.vsM && t.fx.some((x) => x.k === 'mk')) v += 1.5;
      }
      v *= hb.agg;
    } else {
      const tgs = S.t === 's' ? [h] : S.t === 'p' ? s.pt : [s.pt[g]];
      for (const t of tgs) {
        if (!t) continue;
        const m = hStats(s, t);
        if (S.hl) {
          const avg = (S.hl[0] + S.hl[1]) / 2 * (1 + 0.06 * (h.lv - 1)) * (1 + hStats(s, h).hb / 100);
          const miss = m.mh - t.hp;
          v += Math.min(avg, miss) * 1.1 * hb.heal * (miss / m.mh > 0.4 ? 1.4 : 1);
          if (t.dd) v += 16;
          if (t.af && AF[t.af].nh) v *= 0.6;
        }
        if (S.sh) v += Math.min(S.sh, t.st) * (t.st >= 80 ? 0.7 : t.st >= 45 ? 0.45 : 0.15) * (t.af ? 1.3 : 1);
        for (const f of S.fx || []) {
          if (f.k === 'gd') v += (t.hp / m.mh < 0.5 || t.dd ? 6 : 1.2) * (s.pt.indexOf(t) <= 1 ? 1.2 : 0.6);
          else if (f.k === 'rp') v += 2.6;
          else if (f.k === 'tn') v += s.pt.some((o) => o !== h && (o.dd || o.hp < hStats(s, o).mh * 0.4)) ? 5 : 1.5;
          else if (f.k === 'bf') v += (s.fi.rd <= 2 ? 1.6 : 0.9) * (t.fx.some((x) => x.k === 'bf' && x.s === f.s) ? 0.2 : 1);
          else if (f.k === 'cu') v += t.fx.filter((x) => x.k === 'bl' || x.k === 'bg').reduce((a, x) => a + x.n * x.t, 0) * 0.8;
          else if (f.k === 'hurt') v -= t.hp <= f.v + 2 ? 20 : 2;
        }
      }
      if (S.lt) v += s.light < 50 ? S.lt * 0.25 : 0.3;
      if (S.sx && S.sx.some((f) => f.k === 'st')) v -= h.st > 70 ? 6 : 2;
      // 아무도 다치지 않았는데 치유만 하는 것은 낭비
      if (S.hl && !S.sh && v < 1) v = 0.1;
    }
    if (S.sm) {
      const to = clamp(my - S.sm, 0, s.pt.length - 1);
      v += CL[h.c].rk.includes(String(to + 1)) ? 0.5 : -3;
    }
    return v;
  }
  function aiFight(s, h, lv, hb) {
    // 공짜 행동: 보급품
    if (lv >= 2) {
      const bl = h.fx.filter((f) => f.k === 'bl').reduce((a, f) => a + f.n * f.t, 0), bg = h.fx.filter((f) => f.k === 'bg').reduce((a, f) => a + f.n * f.t, 0);
      const me = s.pt.indexOf(h);
      if (bl >= (lv === 3 ? 4 : 7) && s.inv.band > 0) return { t: 'it', it: 'band', g: me };
      if (bg >= (lv === 3 ? 5 : 8) && s.inv.anti > 0) return { t: 'it', it: 'anti', g: me };
      if (lv === 3 && h.st >= 85 && !h.af && s.inv.laud > 0) return { t: 'it', it: 'laud', g: me };
      if (lv === 3 && s.light < 30 && s.inv.torch > 2) return { t: 'it', it: 'torch', g: me };
    }
    const opts = [];
    h.sk.forEach((si, i) => {
      if (!canUse(s, h, si)) return;
      for (const g of targetsFor(s, h, si)) opts.push({ a: { t: 'sk', i, g }, v: scoreSkill(s, h, si, g, lv, hb) });
    });
    const my = s.pt.indexOf(h);
    const pref = CL[h.c].rk;
    const useful = opts.some((o) => o.v > 1);
    if (!pref.includes(String(my + 1)) || !useful) {
      const want = +pref[0] - 1;
      const d = want < my ? -1 : 1;
      const j = my + d;
      if (j >= 0 && j < s.pt.length && !(h.af === 'fear' && d < 0)) opts.push({ a: { t: 'mv', d }, v: useful ? 1.2 : 4 });
    }
    opts.push({ a: { t: 'pass' }, v: 0.05 });
    // 후퇴: 이길 가망이 없을 때(어려움이 잘 판단)
    if (lv >= 2) {
      const ehp = s.fi.en.reduce((a, e) => a + e.hp, 0), hhp = s.pt.reduce((a, x) => a + x.hp, 0);
      const dd = s.pt.filter((x) => x.dd).length;
      if ((dd >= 2 || hhp < ehp * 0.3) && s.pt.length <= 3) opts.push({ a: { t: 'flee' }, v: lv === 3 ? 9 : 3 + hb.risk * 2 });
    }
    if (lv === 1 && Math.random() < 0.18) return pick(opts).a;
    let best = opts[0], bv = -1e9;
    for (const o of opts) { const v = noisy(o.v, lv); if (v > bv) { bv = v; best = o; } }
    return best.a;
  }

  /* ---------- 탐험 ---------- */
  function wantOrder(s, lv) {
    const score = (h) => { const r = CL[h.c].rk; return (+r[0]) + r.length * 0.15 + (CL[h.c].role === 'heal' ? 0.6 : 0); };
    return s.pt.slice().sort((a, b) => score(a) - score(b));
  }
  function fixOrder(s, lv) {
    if (lv === 1 && Math.random() < 0.5) return null;
    const want = wantOrder(s, lv);
    for (let i = 0; i < s.pt.length; i++) if (s.pt[i] !== want[i]) { const j = s.pt.indexOf(want[i]); return { t: 'sw', a: i, b: j }; }
    return null;
  }
  function equipAI(s, lv) {
    if (!s.bag.length || (lv === 1 && Math.random() < 0.6)) return null;
    for (const id of s.bag) {
      const T = TI[id];
      const val = Object.keys(T.m).reduce((a, k) => a + (k === 'str' ? -T.m[k] * 0.6 : k === 'mh' || k === 'dm' ? T.m[k] * 0.8 : T.m[k] * 0.5), 0);
      if (val <= 1) continue;
      for (let i = 0; i < s.pt.length; i++) { const h = s.pt[i]; if ((!T.cls || T.cls === h.c) && h.tr.length < 2 && !h.tr.includes(id)) return { t: 'eq', h: i, tr: id, slot: h.tr.length }; }
    }
    return null;
  }
  function pathTo(s, goal) {
    // 방 그래프 BFS: 지금 위치 → goal, 다음에 갈 방
    const mp = s.mp, start = adjRooms(s);
    if (mp.at.c == null && mp.at.r === goal) return null;
    const prev = {}, q = [];
    for (const r of start) { if (prev[r] == null) { prev[r] = -1; q.push(r); } }
    while (q.length) {
      const r = q.shift();
      if (r === goal) { let x = r; while (prev[x] !== -1) x = prev[x]; return x; }
      for (const c of mp.c) { const n = c.a === r ? c.b : c.b === r ? c.a : -1; if (n >= 0 && prev[n] == null) { prev[n] = r; q.push(n); } }
    }
    return null;
  }
  function partyHealth(s) {
    const hp = s.pt.reduce((a, h) => a + h.hp / hStats(s, h).mh, 0) / Math.max(1, s.pt.length);
    const st = s.pt.reduce((a, h) => a + h.st, 0) / Math.max(1, s.pt.length);
    return { hp, st, dd: s.pt.filter((h) => h.dd).length, af: s.pt.filter((h) => h.af).length };
  }
  function aiMap(s, lv, hb) {
    const o = fixOrder(s, lv); if (o) return o;
    const eq = equipAI(s, lv); if (eq) return eq;
    // 횃불
    const floorsLeft = s.len - s.fl;
    const thr = lv === 1 ? 18 : lv === 2 ? 30 + hb.lite * 20 : 45 + hb.lite * 15;
    if (s.light < thr && s.inv.torch > 0 && (lv === 3 || s.inv.torch >= Math.min(2, floorsLeft) || s.light < 15)) return { t: 'torch' };
    // 치료
    if (lv >= 2) {
      for (let i = 0; i < s.pt.length; i++) {
        const h = s.pt[i];
        if (h.fx.some((f) => f.k === 'bl') && s.inv.band > 0) return { t: 'it', it: 'band', g: i };
        if (h.fx.some((f) => f.k === 'bg') && s.inv.anti > 0 && lv === 3) return { t: 'it', it: 'anti', g: i };
        if (lv === 3 && h.st >= 90 && s.inv.laud > 0) return { t: 'it', it: 'laud', g: i };
        if (lv === 3 && h.hp < hStats(s, h).mh * 0.4 && s.inv.food > s.pt.length * 3) return { t: 'it', it: 'food', g: i };
      }
    }
    const mp = s.mp, ph = partyHealth(s);
    const exitIdx = mp.r.findIndex((r) => r.k === 'x' || r.k === 'b');
    const atRoom = mp.at.c == null ? mp.at.r : -1;
    if (atRoom >= 0 && mp.r[atRoom].k === 'x') {
      const left = mp.r.filter((r, i) => !r.v && i !== atRoom).length;
      const strong = ph.hp > 0.62 && ph.st < 55 && !ph.dd;
      const goOn = lv === 1 ? Math.random() < 0.7 : !(strong && left > 0 && hb.expl > (lv === 3 ? 0.35 : 0.5) && (s.st.steps % 7) !== 0);
      if (goOn || s.st.steps > 300) return { t: 'down' };
    }
    // 목표 방 고르기
    const strong = ph.hp > 0.55 && ph.st < 65 && ph.dd === 0;
    let best = exitIdx, bv = 3 + (strong ? 0 : 6) + (1 - hb.expl) * 3;
    mp.r.forEach((r, i) => {
      if (r.v || i === exitIdx) return;
      let v = 0;
      const k = r.sc ? r.k : '?';
      if (k === 'f') v = strong ? 4 + hb.agg * 2 : -2;
      else if (k === 't') v = strong ? 7 : 1;
      else if (k === 'c') v = 3 + hb.cur * 3;
      else if (k === 'e') v = 0.5;
      else v = 2.5 + hb.expl * 2;
      v -= 0.6 * Math.abs(r.x - mp.r[exitIdx].x);
      v = lv === 1 ? v + Math.random() * 4 : noisy(v, lv);
      if (v > bv) { bv = v; best = i; }
    });
    if (mp.r[exitIdx].k === 'b' && best === exitIdx && lv === 3 && !strong && mp.r.some((r, i) => !r.v && i !== exitIdx && r.sc && r.k === 'c')) {
      best = mp.r.findIndex((r, i) => !r.v && i !== exitIdx && r.sc && r.k === 'c');
    }
    let nx = pathTo(s, best);
    if (nx == null) nx = pathTo(s, exitIdx);
    if (nx == null) { const adj = adjRooms(s); nx = adj[0]; }
    if (atRoom === exitIdx && mp.r[exitIdx].k === 'x') return { t: 'down' };
    return { t: 'go', r: nx };
  }
  function aiCurio(s, lv, hb) {
    const C = CI[s.cu.id];
    if (C.it && s.inv[C.it] > 0 && (lv >= 2 || Math.random() < 0.5)) return { t: 'cu', k: 'use', it: C.it };
    const ph = partyHealth(s);
    let p;
    if (lv === 1) p = 0.55;
    else if (lv === 2) p = C.g * 1.1 + hb.cur * 0.35 - (ph.st > 70 ? 0.2 : 0);
    else p = C.g >= 0.45 && ph.st < 75 ? 0.9 : C.g >= 0.4 && hb.cur > 0.5 && ph.st < 60 ? 0.6 : 0.15;
    return { t: 'cu', k: Math.random() < p ? 'touch' : 'leave' };
  }
  function aiCamp(s, lv, hb) {
    let best = null, bv = lv === 1 ? 0.2 : 0.8;
    s.pt.forEach((h, hi) => {
      campSkills(h).forEach((C, ci) => {
        if (C.h > s.cp.h || s.cp.used.includes(h.u + ':' + ci)) return;
        for (const g of campTargets(s, h, ci)) {
          const tg = C.t === 's' ? [h] : C.t === 'p' ? s.pt : [s.pt[g]];
          const e = C.e;
          let v = 0;
          for (const t of tg) {
            const m = hStats(s, t);
            if (e.hp) v += Math.min(m.mh * e.hp / 100, m.mh - t.hp) * 0.5;
            if (e.st && e.st < 0) v += Math.min(-e.st, t.st) * (t.st > 60 ? 0.5 : 0.3);
            if (e.st > 0) v -= t.st > 80 ? 4 : 1;
            if (e.cure) v += t.fx.some((f) => f.k === 'bl' || f.k === 'bg') ? 3 : 0;
            if (e.buf) v += 1.2;
          }
          if (e.amb) v += s.cp.amb > 8 ? Math.min(-e.amb, s.cp.amb) * 0.18 : 0;
          if (e.light) v += s.light < 60 ? 2.5 : 0.2;
          if (e.scout) v += 1.6;
          if (e.item) v += 1.2;
          if (e.food) v += s.inv.food < s.pt.length * 3 ? 3 : 1;
          v = v / Math.sqrt(C.h);
          v = noisy(v, lv);
          if (v > bv) { bv = v; best = { t: 'cs', h: hi, c: ci, g }; }
        }
      });
    });
    return best || { t: 'cend' };
  }
  function wantBuy(s, floors, lv) {
    const n = Math.max(1, s.pt.length || 4);
    return { food: Math.min(30, Math.ceil(floors * n * 1.5)), torch: Math.min(18, floors * (lv === 1 ? 2 : 3)), shovel: Math.min(3, Math.ceil(floors / 2)), band: 3, anti: 2, key: lv === 1 ? 0 : 1, laud: lv === 3 ? 2 : 1, holy: 1 };
  }
  function buyPlan(s, gold, floors, lv, hb) {
    const want = wantBuy(s, floors, lv), out = {};
    const order = ['food', 'torch', 'band', 'shovel', 'anti', 'laud', 'key', 'holy'];
    let g = gold - (lv === 3 ? 40 : 0);
    for (let pass = 0; pass < 3; pass++) {
      for (const k of order) {
        const tgt = Math.ceil(want[k] * (pass + 1) / 3) - (s.inv[k] || 0) - (out[k] || 0);
        for (let i = 0; i < tgt; i++) { if (g < PV[k].p) break; g -= PV[k].p; out[k] = (out[k] || 0) + 1; }
      }
    }
    void hb;
    return out;
  }
  function aiWay(s, lv, hb) {
    const w = s.wy;
    const eq = equipAI(s, lv); if (eq) return eq;
    if (s.pt.length < 4 && w.c.length) {
      const roles = s.pt.map((h) => CL[h.c].role);
      let best = -1, bv = -1;
      w.c.forEach((h, i) => {
        if (s.gold < recruitCost(h)) return;
        const r = CL[h.c].role;
        let v = 1 + Math.random() * (lv === 1 ? 3 : 0.6);
        if (r === 'front' && roles.filter((x) => x === 'front').length < 2) v += 3;
        if (r === 'heal' && !roles.includes('heal')) v += 4;
        if (r === 'stress' && !roles.includes('stress')) v += 1.5;
        if (v > bv) { bv = v; best = i; }
      });
      if (best >= 0) return { t: 'rec', c: best };
    }
    if (lv >= 2) {
      const cand = s.pt.map((h, i) => ({ h, i })).filter(({ h }) => !w.rest.includes(h.u) && (h.st >= (lv === 3 ? 40 : 60) || h.hp < hStats(s, h).mh * 0.55)).sort((a, b) => b.h.st - a.h.st);
      if (cand.length && s.gold >= restCost + 80) return { t: 'rest', h: cand[0].i };
      const full = s.pt.every((h) => h.tr.length >= 2 || !s.bag.some((id) => !TI[id].cls || TI[id].cls === h.c));
      if (s.bag.length && full) return { t: 'sell', tr: s.bag[0] };
    }
    const floors = Math.min(3, s.len - s.fl);
    const plan = buyPlan(s, s.gold, floors, lv, hb);
    for (const k in plan) if (plan[k] > 0) return { t: 'buy', it: k, n: plan[k] };
    return { t: 'wend' };
  }
  function aiPrep(s, lv, hb) {
    const c = s.pr.c;
    const roleOf = (h) => CL[h.c].role;
    let pickI = [];
    if (lv === 1 && Math.random() < 0.5) pickI = shuf(c.map((_, i) => i)).slice(0, 4);
    else {
      const sc = c.map((h, i) => ({ i, h, v: h.q.reduce((a, q) => a + (QI[q].p ? 1 : -1), 0) + noisy(1, lv) }));
      const take = (role, n) => { sc.filter((x) => roleOf(x.h) === role && !pickI.includes(x.i)).sort((a, b) => b.v - a.v).slice(0, n).forEach((x) => pickI.push(x.i)); };
      take('front', 2); take('heal', 1);
      const rest = sc.filter((x) => !pickI.includes(x.i)).sort((a, b) => (b.v + (roleOf(b.h) === 'stress' ? 0.8 : 0)) - (a.v + (roleOf(a.h) === 'stress' ? 0.8 : 0)));
      while (pickI.length < 4 && rest.length) pickI.push(rest.shift().i);
    }
    const score = (h) => { const r = CL[h.c].rk; return (+r[0]) + r.length * 0.15 + (CL[h.c].role === 'heal' ? 0.6 : 0); };
    pickI.sort((a, b) => score(c[a]) - score(c[b]));
    const floors = Math.min(s.len, 3);
    const plan = buyPlan({ inv: {}, pt: pickI.map((i) => c[i]) }, s.gold, floors, lv, hb);
    return { t: 'start', party: pickI, buy: plan };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    const hb = habits(s, seat);
    if (s.ph === 'prep') return aiPrep(s, lv, hb);
    if (s.ph === 'fight') { const h = s.pt.find((x) => x.u === s.fi.cur); return aiFight(s, h, lv, hb); }
    if (s.ph === 'map') return aiMap(s, lv, hb);
    if (s.ph === 'curio') return aiCurio(s, lv, hb);
    if (s.ph === 'camp') return aiCamp(s, lv, hb);
    if (s.ph === 'way') return aiWay(s, lv, hb);
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    const base = s.ph === 'fight' ? 620 : s.ph === 'map' ? 420 : s.ph === 'curio' ? 700 : s.ph === 'prep' ? 700 : 380;
    return base * (lv === 1 ? 1.25 : lv === 3 ? 0.85 : 1);
  }
  /* ---------- 실루엣 인물 ----------
     100×150 칸, 발끝 (50,150), 오른쪽(적 쪽)을 봄. 모양 = {d: SVG 경로, t: 'f' 채움 | 's' 선, w 굵기, c: ink 먹 · trim 직업 색 · acc 눈빛 · glow 불빛 · bone 뼈}.
     그릴 때: 횃불 쪽 테두리빛(rim)을 살짝 어긋나게 먼저 칠하고 → 먹 → 직업 색 · 눈빛. 귀엽지 않게 머리는 작고 팔다리는 길게. */
  const f1 = (v) => Math.round(v * 10) / 10;
  const Pg = (pts) => 'M' + pts.map((p) => f1(p[0]) + ' ' + f1(p[1])).join('L') + 'Z';
  const Pl = (pts) => 'M' + pts.map((p) => f1(p[0]) + ' ' + f1(p[1])).join('L');
  const El = (cx, cy, rx, ry) => 'M' + f1(cx - rx) + ' ' + f1(cy) + 'a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(2 * rx) + ' 0a' + f1(rx) + ' ' + f1(ry) + ' 0 1 0 ' + f1(-2 * rx) + ' 0Z';
  const Q = (a, c, b) => 'M' + f1(a[0]) + ' ' + f1(a[1]) + 'Q' + f1(c[0]) + ' ' + f1(c[1]) + ' ' + f1(b[0]) + ' ' + f1(b[1]);
  const F = (d, c) => ({ d, t: 'f', c: c || 'ink' });
  const S = (d, w, c) => ({ d, t: 's', w, c: c || 'ink' });

  function headAt(kind, x, y, out) {
    const hd = () => out.push(F(El(x, y, 7.5, 9)));
    const eyes = (c, dx) => { out.push(F(El(x + 3 + (dx || 0), y - 1, 1.4, 1.2), c || 'acc')); };
    switch (kind) {
      case 'helm': out.push(F(Pg([[x - 9, y - 12], [x + 9, y - 12], [x + 10, y + 10], [x - 10, y + 10]]))); out.push(S(Pl([[x - 2, y - 2], [x + 9, y - 2]]), 1.6, 'acc')); out.push(F(Pg([[x - 2, y - 12], [x + 2, y - 12], [x, y - 20]]), 'trim')); break;
      case 'cap': hd(); out.push(F(Pg([[x - 9, y - 4], [x + 9, y - 4], [x + 7, y - 12], [x - 7, y - 12]]))); out.push(S(Pl([[x - 9, y - 4], [x + 9, y - 4]]), 1.2, 'trim')); break;
      case 'exhood': out.push(F(Pg([[x - 11, y + 12], [x - 9, y - 6], [x, y - 20], [x + 9, y - 6], [x + 11, y + 12]]))); out.push(F(El(x + 2, y - 2, 1.6, 1.1), 'acc')); out.push(F(El(x + 7, y - 2, 1.4, 1), 'acc')); break;
      case 'veil': hd(); out.push(F(Pg([[x - 11, y - 6], [x, y - 13], [x + 11, y - 6], [x + 14, y + 26], [x - 15, y + 26]]))); out.push(S(Pl([[x - 11, y - 6], [x, y - 13], [x + 11, y - 6]]), 1.4, 'trim')); break;
      case 'beak': hd(); out.push(F(Pg([[x + 5, y - 3], [x + 26, y + 7], [x + 5, y + 6]]))); out.push(F(Pg([[x - 15, y - 7], [x + 15, y - 7], [x + 10, y - 11], [x - 10, y - 11]]))); out.push(F(Pg([[x - 7, y - 11], [x + 7, y - 11], [x + 5, y - 22], [x - 5, y - 22]]))); out.push(F(El(x + 3, y - 1, 1.8, 1.8), 'acc')); break;
      case 'kettle': hd(); out.push(F(Pg([[x - 16, y - 6], [x + 16, y - 6], [x + 9, y - 10], [x - 9, y - 10]]))); out.push(F(El(x, y - 11, 9, 6))); break;
      case 'hood': out.push(F(Pg([[x - 12, y + 12], [x - 10, y - 6], [x - 1, y - 16], [x + 10, y - 7], [x + 12, y + 12]]))); eyes(); break;
      case 'tricorn': hd(); out.push(F(Pg([[x - 16, y - 6], [x + 16, y - 6], [x + 11, y - 15], [x, y - 10], [x - 11, y - 15]]))); out.push(S(Pl([[x - 16, y - 6], [x + 16, y - 6]]), 1.2, 'trim')); break;
      case 'cowl': out.push(F(Pg([[x - 12, y + 14], [x - 10, y - 8], [x, y - 21], [x + 11, y - 8], [x + 12, y + 14]]))); eyes('acc', -1); out.push(F(El(x + 7, y - 1, 1.2, 1), 'acc')); break;
      case 'bare': hd(); out.push(F(Pg([[x - 8, y - 4], [x - 6, y - 11], [x + 4, y - 12], [x + 8, y - 6], [x + 2, y - 8]]))); break;
      case 'skull': out.push(F(El(x, y - 1, 8, 8.5), 'bone')); out.push(F(Pg([[x - 4, y + 5], [x + 7, y + 5], [x + 6, y + 11], [x - 3, y + 11]]), 'bone')); out.push(F(El(x + 2, y - 1, 2.2, 2.4), 'ink')); out.push(F(El(x + 7, y - 1, 1.5, 2.2), 'ink')); out.push(F(El(x + 2, y - 1, 0.9, 0.9), 'acc')); break;
      case 'mitre': hd(); out.push(F(Pg([[x - 7, y - 6], [x + 7, y - 6], [x + 6, y - 22], [x, y - 30], [x - 6, y - 22]]))); out.push(S(Pl([[x, y - 28], [x, y - 8]]), 1.3, 'trim')); eyes(); break;
      case 'shroud': out.push(F(Pg([[x - 15, y + 22], [x - 11, y - 6], [x, y - 17], [x + 12, y - 5], [x + 16, y + 22]]))); out.push(F(El(x + 1, y - 1, 2, 2.4), 'acc')); out.push(F(El(x + 7, y - 1, 1.6, 2.2), 'acc')); break;
      case 'fishhead': out.push(F(Pg([[x - 7, y + 9], [x - 6, y - 7], [x + 8, y - 10], [x + 19, y], [x + 12, y + 9]]))); out.push(F(El(x + 8, y - 3, 2, 2), 'acc')); out.push(S(Pl([[x + 8, y + 4], [x + 18, y + 2]]), 1.2, 'acc')); break;
      case 'shroom': hd(); out.push(F(Pg([[x - 18, y - 4], [x - 12, y - 14], [x, y - 19], [x + 13, y - 14], [x + 19, y - 4]]))); out.push(F(El(x - 6, y - 10, 1.6, 1.6), 'acc')); out.push(F(El(x + 7, y - 12, 1.3, 1.3), 'acc')); eyes(); break;
      case 'hat': hd(); out.push(F(Pg([[x - 18, y - 6], [x + 18, y - 6], [x + 14, y - 9], [x - 14, y - 9]]))); out.push(F(Pg([[x - 8, y - 9], [x + 8, y - 9], [x + 7, y - 21], [x - 7, y - 21]]))); eyes(); break;
      case 'blind': hd(); out.push(S(Pl([[x - 8, y - 2], [x + 8, y - 2]]), 3.2, 'bone')); out.push(F(Pg([[x - 11, y - 3], [x - 8, y - 12], [x + 8, y - 12], [x + 11, y - 3], [x + 13, y + 16], [x - 13, y + 16]]))); break;
      case 'candle': hd(); for (const dx of [-6, 0, 6]) { out.push(F(Pg([[x + dx - 2, y - 8], [x + dx + 2, y - 8], [x + dx + 2, y - 16 - Math.abs(dx) / 2], [x + dx - 2, y - 16 - Math.abs(dx) / 2]]), 'bone')); out.push(F(El(x + dx, y - 19 - Math.abs(dx) / 2, 1.6, 2.6), 'glow')); } eyes(); break;
      case 'crown': out.push(F(El(x, y - 1, 9, 9.5), 'bone')); out.push(F(El(x + 2, y - 1, 2.4, 2.6))); out.push(F(El(x + 8, y - 1, 1.6, 2.4))); out.push(F(El(x + 2, y - 1, 1, 1), 'acc')); out.push(F(Pg([[x - 10, y - 7], [x - 9, y - 19], [x - 4, y - 11], [x, y - 22], [x + 4, y - 11], [x + 9, y - 19], [x + 10, y - 7]]), 'trim')); break;
      case 'rat': out.push(F(Pg([[x - 6, y + 6], [x - 4, y - 6], [x + 6, y - 6], [x + 18, y + 3], [x + 6, y + 8]]))); out.push(F(El(x - 1, y - 8, 3, 4))); eyes(); break;
      case 'maw': out.push(F(El(x, y, 12, 13))); out.push(F(El(x + 6, y + 2, 6, 7), 'acc')); for (let i = 0; i < 6; i++) out.push(S(Pl([[x + 6 + 5 * Math.cos(i), y + 2 + 6 * Math.sin(i)], [x + 6 + 2 * Math.cos(i), y + 2 + 3 * Math.sin(i)]]), 1.1, 'bone')); break;
      case 'none': break;
      default: hd();
    }
  }
  function weapon(kind, hx, hy, out, off) {
    switch (kind) {
      case 'sword': out.push(S(Pl([[hx, hy], [hx + 18, hy - 44]]), 3.4)); out.push(S(Pl([[hx - 5, hy - 2], [hx + 5, hy + 3]]), 3)); out.push(S(Pl([[hx + 3, hy - 9], [hx + 17, hy - 41]]), 0.9, 'trim')); break;
      case 'shield': out.push(F(Pg([[hx - 12, hy - 22], [hx + 12, hy - 22], [hx + 12, hy + 4], [hx, hy + 20], [hx - 12, hy + 4]]))); out.push(S(Pl([[hx, hy - 18], [hx, hy + 14]]), 1.5, 'trim')); out.push(S(Pl([[hx - 8, hy - 8], [hx + 8, hy - 8]]), 1.5, 'trim')); break;
      case 'buckler': out.push(F(El(hx, hy, 10, 10))); out.push(F(El(hx, hy, 2.5, 2.5), 'trim')); break;
      case 'axe': out.push(S(Pl([[hx - 4, hy + 14], [hx + 12, hy - 46]]), 3.4)); out.push(F(Pg([[hx + 9, hy - 36], [hx + 28, hy - 48], [hx + 30, hy - 22], [hx + 12, hy - 28]]))); out.push(S(Pl([[hx + 28, hy - 47], [hx + 30, hy - 23]]), 1.1, 'trim')); break;
      case 'lantern': out.push(S(Pl([[hx, hy], [hx + 2, hy + 8]]), 1.4)); out.push(F(Pg([[hx - 5, hy + 8], [hx + 9, hy + 8], [hx + 8, hy + 24], [hx - 4, hy + 24]]))); out.push(F(El(hx + 2, hy + 16, 3.4, 5), 'glow')); out.push(F(Pg([[hx - 3, hy + 8], [hx + 2, hy + 3], [hx + 7, hy + 8]]))); break;
      case 'flask': out.push(F(El(hx + 3, hy - 2, 5.5, 6.5))); out.push(F(Pg([[hx + 1, hy - 8], [hx + 5, hy - 8], [hx + 5, hy - 15], [hx + 1, hy - 15]]))); out.push(F(El(hx + 3, hy, 3, 3), 'glow2')); break;
      case 'crossbow': out.push(S(Pl([[hx - 14, hy + 4], [hx + 20, hy - 3]]), 4.4)); out.push(S(Q([hx + 16, hy - 18], [hx + 25, hy - 3], [hx + 16, hy + 12]), 2.4)); out.push(S(Pl([[hx + 16, hy - 18], [hx + 6, hy - 1], [hx + 16, hy + 12]]), 0.8, 'trim')); break;
      case 'dagger': out.push(S(Pl([[hx, hy], [hx + 13, hy - 12]]), 2.6)); out.push(S(Pl([[hx + 4, hy - 4], [hx + 12, hy - 11]]), 0.8, 'trim')); break;
      case 'lute': out.push(F(El(hx - 4, hy + 2, 8, 11))); out.push(S(Pl([[hx - 2, hy - 6], [hx + 14, hy - 30]]), 2.6)); out.push(F(El(hx - 4, hy + 2, 2.4, 2.4), 'trim')); break;
      case 'book': out.push(F(Pg([[hx - 14, hy - 4], [hx, hy - 8], [hx + 14, hy - 4], [hx + 14, hy + 6], [hx, hy + 2], [hx - 14, hy + 6]]))); out.push(F(Pg([[hx - 11, hy - 3], [hx - 1, hy - 6], [hx - 1, hy], [hx - 11, hy + 3]]), 'glow2')); break;
      case 'falcon': out.push(F(Pg([[hx - 2, hy - 6], [hx + 6, hy - 14], [hx + 12, hy - 10], [hx + 26, hy - 26], [hx + 20, hy - 8], [hx + 8, hy - 2]]))); out.push(F(Pg([[hx + 5, hy - 13], [hx + 9, hy - 18], [hx + 11, hy - 13]]))); out.push(F(El(hx + 8, hy - 14, 0.9, 0.9), 'acc')); break;
      case 'chain': out.push(S('M' + hx + ' ' + hy + 'Q' + (hx + 18) + ' ' + (hy + 40) + ' ' + (hx + 34) + ' ' + (hy + 20), 2.4)); out.push(S('M' + hx + ' ' + hy + 'Q' + (hx + 18) + ' ' + (hy + 40) + ' ' + (hx + 34) + ' ' + (hy + 20), 0.9, 'trim')); out.push(F(El(hx + 34, hy + 20, 4, 4))); break;
      case 'bomb': out.push(F(El(hx + 4, hy - 2, 7, 7))); out.push(S(Q([hx + 7, hy - 9], [hx + 10, hy - 16], [hx + 15, hy - 15]), 1.4)); out.push(F(El(hx + 15, hy - 15, 2.2, 2.2), 'glow')); break;
      case 'spear': out.push(S(Pl([[hx - 18, hy + 26], [hx + 26, hy - 50]]), 2.6)); out.push(F(Pg([[hx + 23, hy - 44], [hx + 31, hy - 60], [hx + 27, hy - 42]]))); break;
      case 'bow': out.push(S(Q([hx + 4, hy - 28], [hx + 18, hy], [hx + 4, hy + 28]), 2.6)); out.push(S(Pl([[hx + 4, hy - 28], [hx + 4, hy + 28]]), 0.7, 'bone')); break;
      case 'censer': out.push(S(Pl([[hx, hy], [hx + 4, hy + 18]]), 1.2)); out.push(F(El(hx + 4, hy + 22, 5, 5))); out.push(F(El(hx + 4, hy + 22, 2, 2), 'glow')); break;
      case 'mace': out.push(S(Pl([[hx - 2, hy + 6], [hx + 10, hy - 30]]), 3.2)); out.push(F(El(hx + 11, hy - 34, 6.5, 6.5))); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3; out.push(S(Pl([[hx + 11 + 5 * Math.cos(a), hy - 34 + 5 * Math.sin(a)], [hx + 11 + 9 * Math.cos(a), hy - 34 + 9 * Math.sin(a)]]), 1.8)); } break;
      case 'hook': out.push(S(Pl([[hx - 6, hy + 30], [hx + 8, hy - 44]]), 2.4)); out.push(S('M' + (hx + 8) + ' ' + (hy - 44) + 'q12 -4 10 10q-2 8 -9 4', 2.4)); break;
      case 'staff': out.push(S(Pl([[hx - 4, hy + 66], [hx + 4, hy - 52]]), 2.8)); out.push(F(El(hx + 4, hy - 56, 4, 5), 'glow2')); break;
      case 'scythe': out.push(S(Pl([[hx - 4, hy + 40], [hx + 6, hy - 46]]), 2.6)); out.push(F('M' + (hx + 6) + ' ' + (hy - 46) + 'q22 -2 32 16q-14 -8 -32 -10Z')); break;
      case 'whip': out.push(S('M' + hx + ' ' + hy + 'c10 -14 18 6 26 -8s10 -4 14 10', 1.8)); break;
      case 'bell': out.push(S(Pl([[hx, hy], [hx + 3, hy + 8]]), 1.4)); out.push(F(Pg([[hx - 4, hy + 8], [hx + 10, hy + 8], [hx + 14, hy + 24], [hx - 8, hy + 24]]))); out.push(F(El(hx + 3, hy + 25, 2, 2), 'trim')); break;
      case 'club': out.push(S(Pl([[hx, hy], [hx + 10, hy - 30]]), 5)); out.push(F(El(hx + 11, hy - 32, 4.5, 6))); break;
      default: break;
    }
    void off;
  }
  function humanoid(spec, out) {
    const b = spec.b;
    const bony = b === 'bones';
    const lw = b === 'armor' || b === 'brute' || b === 'giant' ? 11 : bony ? 5 : 8.5;
    let hx = 50, hy = 38, sh = 54;
    const front = [74, 82];
    const hunch = b === 'hunch';
    if (hunch) { hx = 68; hy = 54; sh = 64; }
    // 다리
    if (b !== 'robe' && b !== 'float') {
      out.push(S(Pl([[45, 96], [41, 122], [38, 148]]), lw, bony ? 'bone' : 'ink'));
      out.push(S(Pl([[55, 96], [61, 122], [63, 148]]), lw, bony ? 'bone' : 'ink'));
      out.push(F(Pg([[33, 150], [43, 145], [44, 150]]))); out.push(F(Pg([[60, 145], [72, 150], [60, 150]])));
    }
    // 뒤 망토
    if (b === 'armor' || b === 'lean' || b === 'giant') out.push(F(Pg([[40, 52], [26, 104], [33, 98], [28, 132], [42, 112], [46, 96]])));
    // 몸통
    if (b === 'armor' || b === 'giant') { out.push(F(Pg([[34, 50], [66, 50], [62, 100], [38, 100]]))); out.push(F(El(35, 55, 8, 7))); out.push(F(El(65, 55, 8, 7))); out.push(S(Pl([[38, 86], [62, 86]]), 1.3, 'trim')); }
    else if (b === 'brute') { out.push(F(Pg([[28, 50], [72, 48], [66, 100], [34, 100]]))); out.push(S(Pl([[34, 70], [66, 70]]), 1, 'trim')); }
    else if (b === 'robe') { out.push(F(Pg([[38, 50], [62, 50], [72, 140], [76, 150], [24, 150], [28, 140]]))); out.push(S(Pl([[50, 54], [52, 148]]), 1.4, 'trim')); }
    else if (b === 'coat') { out.push(F(Pg([[38, 50], [62, 50], [68, 124], [56, 118], [44, 124], [32, 124]]))); out.push(S(Pl([[38, 98], [62, 98]]), 1.6, 'trim')); }
    else if (b === 'lean') { out.push(F(Pg([[40, 52], [60, 52], [58, 100], [42, 100]]))); out.push(S(Pl([[42, 96], [58, 94]]), 1.3, 'trim')); }
    else if (hunch) { out.push(F(Pg([[42, 98], [40, 70], [56, 58], [72, 60], [66, 100]]))); }
    else if (bony) { out.push(F(Pg([[43, 52], [57, 52], [55, 96], [45, 96]]), 'bone')); for (let i = 0; i < 4; i++) out.push(S(Pl([[43, 60 + i * 8], [57, 60 + i * 8]]), 1.6)); }
    // 팔
    const armC = bony ? 'bone' : 'ink', aw = bony ? 4.5 : b === 'brute' ? 9 : 7;
    const sx = hunch ? 62 : 58, bx = hunch ? 46 : 42;
    out.push(S(Pl([[bx, sh + 2], [bx - 6, sh + 24], [bx - 2, sh + 40]]), aw, armC));
    const w = spec.w;
    const hand = w === 'falcon' ? [76, 52] : w === 'staff' ? [72, 82] : w === 'crossbow' ? [66, 76] : w === 'lantern' ? [78, 70] : w === 'book' ? [72, 74] : w === 'spear' ? [64, 82] : front;
    out.push(S(Pl([[sx, sh + 2], [(sx + hand[0]) / 2 + 2, (sh + hand[1]) / 2 + 6], hand]), aw, armC));
    headAt(spec.h, hx, hy, out);
    if (spec.o === 'shield') weapon('shield', 62, 82, out, 1);
    else if (spec.o === 'buckler') weapon('buckler', 40, 92, out, 1);
    else if (spec.o === 'dagger') weapon('dagger', 38, 96, out, 1);
    if (w) weapon(w, hand[0], hand[1], out);
  }
  function creature(spec, out) {
    const b = spec.b;
    if (b === 'hound' || b === 'beast' || b === 'rodent') {
      const big = b === 'beast', rod = b === 'rodent';
      const by = rod ? 130 : big ? 98 : 114, rx = rod ? 22 : big ? 30 : 25, ry = rod ? 11 : big ? 16 : 11;
      const leg = (x0, x1) => out.push(S(Pl([[x0, by + 4], [x0 + 2, by + 22], [x1, 150]]), big ? 6 : 4.5));
      if (!rod) { leg(32, 30); leg(40, 42); leg(62, 64); leg(70, 74); }
      out.push(F(El(50, by, rx, ry)));
      out.push(S(Q([50 - rx, by - 2], [12, by - 16], [8, by + (rod ? 6 : -4)]), rod ? 2 : 3.5));
      const nx = 50 + rx - 4, ny = by - ry + 2;
      const hx = nx + (big ? 16 : 12), hy = ny - (big ? 26 : 10);
      out.push(S(Pl([[nx - 4, by - 2], [hx - 4, hy + 4]]), big ? 12 : 10));
      out.push(F(Pg([[hx - 8, hy - 6], [hx + 4, hy - 8], [hx + 18, hy + 2], [hx + 4, hy + 8], [hx - 8, hy + 6]])));
      out.push(F(El(hx + 3, hy - 2, 1.4, 1.4), 'acc'));
      if (spec.h === 'antler') { const a = (s) => { out.push(S(Pl([[hx - 2, hy - 6], [hx - 6 * s, hy - 26], [hx - 14 * s, hy - 40]]), 2.2)); out.push(S(Pl([[hx - 6 * s, hy - 26], [hx + 6 * s, hy - 38]]), 1.8)); out.push(S(Pl([[hx - 10 * s, hy - 33], [hx - 20 * s, hy - 34]]), 1.6)); }; a(1); a(-0.6); }
      else out.push(F(Pg([[hx - 6, hy - 6], [hx - 3, hy - 16], [hx + 1, hy - 7]])));
      if (rod) { out.push(F(El(hx - 4, hy - 7, 3, 4))); }
      return;
    }
    if (b === 'swarm') {
      const pts = [[30, 70], [52, 58], [72, 74], [40, 96], [64, 102], [24, 118], [50, 124], [76, 128], [38, 142]];
      for (const [x, y] of pts) {
        if (spec.h === 'bat') { out.push(F(Pg([[x - 12, y - 4], [x - 4, y - 1], [x, y - 4], [x + 4, y - 1], [x + 12, y - 4], [x + 6, y + 4], [x, y + 2], [x - 6, y + 4]]))); }
        else if (spec.h === 'moth') { out.push(F(Pg([[x, y], [x - 9, y - 7], [x - 7, y + 5]]))); out.push(F(Pg([[x, y], [x + 9, y - 7], [x + 7, y + 5]]))); out.push(F(El(x, y, 1.6, 4), 'acc')); }
        else { out.push(F(El(x, y + 2, 8, 4.5))); out.push(F(Pg([[x + 6, y - 1], [x + 13, y + 3], [x + 6, y + 5]]))); out.push(S(Q([x - 8, y + 3], [x - 14, y + 8], [x - 20, y + 2]), 1.1)); out.push(F(El(x + 9, y + 2, 0.9, 0.9), 'acc')); }
      }
      return;
    }
    if (b === 'worm' || b === 'serpent') {
      const d = b === 'worm' ? 'M14 150C10 110 30 70 62 66S94 88 84 98' : 'M20 150C60 146 20 112 46 100S82 64 70 52';
      out.push(S(d, b === 'worm' ? 16 : 11));
      if (b === 'worm') for (let i = 0; i < 6; i++) out.push(S(Pl([[18 + i * 8, 140 - i * 13], [28 + i * 8, 136 - i * 13]]), 1.2, 'trim'));
      const hx = b === 'worm' ? 84 : 72, hy = b === 'worm' ? 98 : 52;
      if (spec.h === 'maw') headAt('maw', hx, hy, out);
      else { out.push(F(El(hx, hy, 9, 7))); out.push(F(El(hx + 3, hy - 2, 1.5, 1.5), 'acc')); if (b === 'serpent') out.push(S(Pl([[hx + 8, hy + 2], [hx + 14, hy + 4]]), 1, 'acc')); }
      return;
    }
    if (b === 'blob') {
      out.push(F('M14 150C10 120 22 96 40 92C46 76 70 78 74 96C92 100 94 130 88 150Z'));
      for (const [x, y] of [[40, 108], [58, 100], [66, 118]]) out.push(F(El(x, y, 2, 1.6), 'acc'));
      out.push(S(Pl([[30, 128], [30, 146]]), 2.4)); out.push(S(Pl([[76, 126], [78, 148]]), 2.4));
      if (spec.h === 'shroom') { out.push(F(Pg([[34, 92], [44, 74], [56, 72], [66, 80], [60, 90]]))); out.push(F(El(48, 80, 1.6, 1.6), 'acc')); }
      return;
    }
    if (b === 'plant') {
      out.push(S('M50 150C40 120 64 96 46 70S58 30 70 22', 7));
      out.push(S('M38 150C24 120 36 104 22 84', 4.5));
      out.push(S('M60 150C76 126 70 110 86 92', 4.5));
      for (const [x, y] of [[44, 104], [54, 82], [26, 96], [80, 104], [62, 40]]) out.push(F(Pg([[x, y], [x + 6, y - 3], [x + 1, y + 4]])));
      if (spec.h === 'crownshroom') { out.push(F('M18 50C20 24 80 16 88 46C70 40 34 40 18 50Z')); out.push(S(Pl([[30, 47], [36, 32]]), 1.2, 'trim')); out.push(S(Pl([[52, 42], [54, 24]]), 1.2, 'trim')); out.push(S(Pl([[72, 44], [70, 28]]), 1.2, 'trim')); for (const [x, y] of [[34, 38], [60, 32], [76, 40]]) out.push(F(El(x, y, 2.2, 2.2), 'glow2')); }
      else out.push(F(El(70, 22, 6, 5)));
      return;
    }
    if (b === 'float') {
      out.push(F(Pg([[36, 48], [64, 48], [72, 104], [60, 96], [54, 138], [46, 102], [32, 116], [38, 82]])));
      out.push(S(Pl([[60, 58], [76, 74], [88, 70]]), 4)); out.push(S(Pl([[40, 58], [30, 80], [34, 92]]), 4));
      headAt(spec.h === 'shroud' ? 'shroud' : 'none', 50, 38, out);
      if (spec.h !== 'shroud') { out.push(F(El(50, 38, 9, 10))); out.push(F(El(52, 37, 1.6, 1.6), 'acc')); out.push(F(El(57, 37, 1.3, 1.3), 'acc')); }
      return;
    }
    if (b === 'head') {
      out.push(S('M44 92C34 110 40 124 28 140', 3)); out.push(S('M56 92C64 112 56 126 66 142', 3));
      out.push(F(El(50, 72, 15, 17), 'bone')); out.push(F(Pg([[42, 82], [60, 82], [58, 96], [44, 96]]), 'bone'));
      out.push(F(El(45, 70, 4, 4.5))); out.push(F(El(57, 70, 3.4, 4.5))); out.push(F(Pg([[44, 88], [58, 88], [58, 92], [44, 92]])));
      out.push(F(El(45, 70, 1.4, 1.4), 'acc')); out.push(F(El(57, 70, 1.2, 1.2), 'acc'));
      return;
    }
    if (b === 'tentacle') {
      out.push(F('M6 150C4 112 24 84 52 82C82 80 98 112 96 150Z'));
      for (const [d, w] of [['M20 120C4 90 14 60 6 36', 6], ['M40 96C34 64 46 40 34 14', 7], ['M64 94C70 64 60 44 74 18', 7], ['M84 118C98 92 92 70 98 48', 6]]) out.push(S(d, w));
      for (const [x, y, r] of [[44, 112, 4], [60, 106, 3], [52, 126, 2.4], [70, 122, 2]]) out.push(F(El(x, y, r, r * 0.8), 'acc'));
      return;
    }
    humanoid(spec, out);
  }
  const FIGC = {};
  function figShapes(spec) {
    const key = spec.b + '|' + spec.h + '|' + (spec.w || '') + '|' + (spec.o || '');
    if (FIGC[key]) return FIGC[key];
    const out = [];
    if (['armor', 'robe', 'coat', 'lean', 'brute', 'hunch', 'bones', 'giant'].includes(spec.b)) humanoid(spec, out);
    else creature(spec, out);
    return (FIGC[key] = out);
  }
  const P2D = {};
  const p2d = (d) => P2D[d] || (P2D[d] = new Path2D(d));
  // 색: rim 테두리빛, ink 먹, trim 직업 색, acc 눈빛, glow 불빛, glow2 푸른 불빛, bone 뼈
  function figColors(spec, o) {
    o = o || {};
    return { rim: o.rim || 'rgba(222,160,92,.62)', ink: o.ink || '#0c0a09', trim: spec.c || '#8c7a5a', acc: o.acc || (spec.en ? '#d9cf9a' : '#c9b48a'), glow: '#f3c26a', glow2: '#9fd3b8', bone: '#5d554a' };
  }
  function figSVG(spec, size, o) {
    o = o || {};
    const sh = figShapes(spec), col = figColors(spec, o);
    const vb = o.bust ? '18 4 64 64' : '-6 -6 112 160';
    const flip = o.flip ? ' transform="translate(100 0) scale(-1 1)"' : '';
    let s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb + '" width="' + size + '" height="' + size + '"' + (o.style ? ' style="' + o.style + '"' : '') + '>';
    if (!o.noBg) s += '<defs><radialGradient id="mxg" cx="50%" cy="45%" r="65%"><stop offset="0" stop-color="#5a4430"/><stop offset="1" stop-color="#1a1411"/></radialGradient></defs><rect x="-20" y="-20" width="160" height="200" fill="url(#mxg)"/>';
    s += '<g' + flip + ' stroke-linecap="round" stroke-linejoin="round">';
    s += '<g transform="translate(-1.6 -1.1)">';
    for (const x of sh) { if (x.c === 'acc' || x.c === 'glow' || x.c === 'glow2') continue; s += x.t === 'f' ? '<path d="' + x.d + '" fill="' + col.rim + '"/>' : '<path d="' + x.d + '" fill="none" stroke="' + col.rim + '" stroke-width="' + (x.w + 1.4) + '"/>'; }
    s += '</g>';
    for (const x of sh) { const c = col[x.c] || col.ink; s += x.t === 'f' ? '<path d="' + x.d + '" fill="' + c + '"/>' : '<path d="' + x.d + '" fill="none" stroke="' + c + '" stroke-width="' + x.w + '"/>'; }
    return s + '</g></svg>';
  }
  const heroSpec = (h) => CL[h.c].a;
  const enSpec = (id) => Object.assign({ en: 1, c: '#6a5a4a' }, EI[id].a);
  /* ---------- 아이콘 (game-icons.net, CC BY 3.0) ---------- */
  const ICP = {};
  function drawIco(ctx, name, x, y, size, color) {
    const d = ICO[name]; if (!d) return;
    const p = ICP[name] || (ICP[name] = new Path2D(d));
    ctx.save(); ctx.translate(x, y); ctx.scale(size / 128, size / 128); ctx.fillStyle = color || '#e8dcc4'; ctx.fill(p); ctx.restore();
  }
  function icoSVG(name, size, color, extra) {
    const d = ICO[name]; if (!d) return '';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="' + (size || 24) + '" height="' + (size || 24) + '"' + (extra || '') + '><path fill="' + (color || 'currentColor') + '" d="' + d + '"/></svg>';
  }
  function icoTile(name, color, bg) {   // 도감용 칸
    const d = ICO[name]; if (!d) return '';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="30" height="30"><rect width="128" height="128" rx="18" fill="' + (bg || '#241c18') + '"/><path transform="translate(14 14) scale(.78)" fill="' + (color || '#e3c890') + '" d="' + d + '"/></svg>';
  }

  /* ---------- 관절 인형(rig) ----------
     사람 꼴(기사·사제·해골 등)은 엉덩이 · 몸통 · 머리 · 팔 2마디 · 다리 2마디로 움직여요. 각도는 「아래 방향이 0, 앞(오른쪽)으로 +」.
     자세: idle 대기 · walk 걷기 · atk 휘두르기 · shoot 쏘기 · cast 들어 올리기 · hit 맞음 · down 죽음의 문턱(무릎) · sit 야영 · fear 붕괴 떨림.
     그리기: ① 횃불 쪽으로 어긋난 테두리빛 ② 먹(뒤쪽 팔다리는 조금 옅게) ③ 직업 색 · 눈빛 ④ 맞았을 때 번쩍임. 눈빛·불빛은 어둠 위에 따로(emit). */
  const RIGB = {
    armor: { hip: 96, tor: 44, th: 27, sh: 27, lw: 9.5, uw: 7.5, fw: 6.5, ua: 20, fa: 19 },
    giant: { hip: 94, tor: 48, th: 28, sh: 28, lw: 11, uw: 9, fw: 8, ua: 23, fa: 21 },
    brute: { hip: 96, tor: 44, th: 27, sh: 27, lw: 10.5, uw: 9, fw: 8, ua: 21, fa: 20 },
    robe: { hip: 96, tor: 44, th: 27, sh: 27, lw: 7, uw: 6.5, fw: 5.5, ua: 21, fa: 20 },
    coat: { hip: 96, tor: 44, th: 27, sh: 27, lw: 7.5, uw: 6.5, fw: 5.5, ua: 21, fa: 20 },
    lean: { hip: 96, tor: 42, th: 27, sh: 27, lw: 7, uw: 6, fw: 5, ua: 21, fa: 20 },
    hunch: { hip: 98, tor: 40, th: 26, sh: 26, lw: 8, uw: 7, fw: 6, ua: 22, fa: 21 },
    bones: { hip: 96, tor: 42, th: 27, sh: 27, lw: 4.6, uw: 4.2, fw: 3.8, ua: 21, fa: 20 },
  };
  const RIG_SET = { armor: 1, giant: 1, brute: 1, robe: 1, coat: 1, lean: 1, hunch: 1, bones: 1 };
  const TORSO = {
    armor: 'M-16 -46L16 -46L12 2L-12 2Z',
    giant: 'M-20 -50L20 -50L15 2L-15 2Z',
    brute: 'M-22 -46L22 -48L16 4L-16 4Z',
    robe: 'M-12 -46L12 -46L13 0L-13 0Z',
    coat: 'M-12 -46L12 -46L14 0L-14 0Z',
    lean: 'M-10 -44L10 -44L8 4L-8 4Z',
    hunch: 'M-9 4L-13 -24L0 -42L16 -40L14 4Z',
    bones: 'M-7 -44L7 -44L5 0L-5 0Z',
  };
  // 무기 종류 → 공격 자세
  const WKIND = { sword: 'm', axe: 'm', mace: 'm', club: 'm', dagger: 'm', chain: 'm', spear: 'm', scythe: 'm', whip: 'm', hook: 'm', crossbow: 's', bow: 's', lantern: 'c', book: 'c', staff: 'c', censer: 'c', bell: 'c', lute: 'c', flask: 't', bomb: 't', falcon: 'c' };
  const RIGP = {};   // 머리 · 무기 · 방패 모양(원점 기준) 캐시
  function partShapes(key, fn) { if (!RIGP[key]) { const out = []; fn(out); RIGP[key] = out.map((s) => ({ p: typeof Path2D !== 'undefined' ? new Path2D(s.d) : null, t: s.t, w: s.w, c: s.c })); } return RIGP[key]; }
  const sm = (x) => x * x * (3 - 2 * x);
  const lerp = (a, b, k) => a + (b - a) * k;
  // 자세 벡터: [lean, bl0, bl1, fl0, fl1, ba0, ba1, fa0, fa1, hd, wr]
  const PBASE = [0.06, -0.24, -0.06, 0.3, 0.1, 0.3, 0.75, 0.28, 0.55, 0, 0];
  function keyPose(kf, p) {
    let i = 0; while (i < kf.length - 2 && p > kf[i + 1][0]) i++;
    const [p0, a] = kf[i], [p1, b] = kf[i + 1];
    const k = sm(Math.max(0, Math.min(1, (p - p0) / Math.max(1e-6, p1 - p0))));
    return a.map((v, j) => lerp(v, b[j], k));
  }
  const PK = {
    m: [[0, PBASE], [0.3, [-0.14, -0.3, -0.1, 0.22, 0.05, 0.1, 0.4, -2.5, -2.2, -0.1, 0]], [0.46, [0.38, -0.55, -0.2, 0.7, 0.25, 0.6, 1.0, 1.6, 2.0, 0.15, 0.3]], [0.62, [0.32, -0.52, -0.18, 0.68, 0.22, 0.5, 0.9, 1.45, 1.8, 0.12, 0.25]], [1, PBASE]],
    s: [[0, PBASE], [0.25, [0.02, -0.3, -0.08, 0.32, 0.1, 1.2, 1.5, 1.5, 1.58, 0.02, 0]], [0.5, [0.02, -0.3, -0.08, 0.32, 0.1, 1.2, 1.5, 1.5, 1.58, 0.02, 0]], [0.58, [-0.12, -0.34, -0.1, 0.3, 0.08, 1.05, 1.3, 1.25, 1.35, -0.08, 0]], [1, PBASE]],
    c: [[0, PBASE], [0.32, [-0.1, -0.26, -0.06, 0.3, 0.1, 2.0, 2.5, 2.35, 2.75, -0.15, 0]], [0.55, [-0.06, -0.26, -0.06, 0.3, 0.1, 1.9, 2.3, 2.2, 2.6, -0.1, 0]], [0.72, [0.1, -0.3, -0.08, 0.36, 0.12, 1.4, 1.6, 1.7, 1.8, 0.05, 0]], [1, PBASE]],
    t: [[0, PBASE], [0.3, [-0.12, -0.3, -0.08, 0.26, 0.08, 0.6, 1.0, -2.2, -2.6, -0.1, 0]], [0.5, [0.3, -0.5, -0.15, 0.6, 0.2, 0.5, 0.9, 1.9, 2.1, 0.1, 0]], [1, PBASE]],
    hit: [[0, PBASE], [0.18, [-0.38, -0.5, -0.18, 0.1, 0.0, -0.5, -0.2, 0.9, 1.3, -0.35, -0.2]], [1, PBASE]],
  };
  const DOWN = [0.45, 0.35, -1.45, 1.35, 0.12, 0.85, 0.45, 0.6, 0.25, 0.42, -0.4];
  const SIT = [-0.04, 1.32, 0.25, 1.45, 0.35, 0.65, 1.25, 0.55, 1.1, 0.12, -0.5];
  const FEAR = [0.32, -0.15, 0.1, 0.2, 0.05, 0.15, 1.6, 0.25, 1.5, 0.3, -0.3];
  function rigPose(spec, o) {
    const k = (o.pose && o.pose.k) || 'idle', p = o.pose && o.pose.p != null ? o.pose.p : 0, t = o.t || 0, sd = o.seed || 0;
    const breath = Math.sin(t * 1.7 + sd) * 0.025;
    let P;
    if (k === 'walk') {
      const w = t * 8.5 + sd;
      const sF = Math.sin(w), sB = Math.sin(w + Math.PI);
      P = [0.1, sB * 0.42, sB * 0.42 - Math.max(0, Math.cos(w + Math.PI)) * 0.6, sF * 0.42, sF * 0.42 - Math.max(0, Math.cos(w)) * 0.6, 0.15 - sF * 0.35, 0.5 - sF * 0.25, 0.32 + sF * 0.2, 0.6, 0.02, 0];
    } else if (k === 'atk') P = keyPose(PK[WKIND[spec.w] || 'm'], p);
    else if (k === 'shoot') P = keyPose(PK.s, p);
    else if (k === 'cast') P = keyPose(PK.c, p);
    else if (k === 'throw') P = keyPose(PK.t, p);
    else if (k === 'hit') P = keyPose(PK.hit, p);
    else if (k === 'down') P = DOWN.map((v, j) => v + (j === 0 ? Math.sin(t * 2.1 + sd) * 0.03 : 0));
    else if (k === 'sit') P = SIT.map((v, j) => v + (j === 0 ? breath * 0.6 : 0));
    else if (k === 'fear') P = FEAR.map((v, j) => v + Math.sin(t * 31 + j * 1.7 + sd) * 0.025);
    else P = PBASE.map((v, j) => v + (j === 0 ? breath : j === 7 ? breath * 1.5 : j === 5 ? -breath : 0));
    if (spec.b === 'hunch') P[0] += 0.42;
    return P;
  }
  const at = (x, y, a, l) => [x + Math.sin(a) * l, y + Math.cos(a) * l];
  // 한 장면용 그리기 목록 만들기 (100×150 칸 좌표)
  function rigOps(spec, o) {
    const R = RIGB[spec.b] || RIGB.lean, P = rigPose(spec, o);
    const [lean, bl0, bl1, fl0, fl1, ba0, ba1, fa0, fa1, hd, wr] = P;
    const ops = [];
    const bony = spec.b === 'bones';
    const inkF = bony ? 'bone' : 'ink', inkB = bony ? 'bone2' : 'ink2';
    // 다리: 발이 땅에 닿게 엉덩이 높이를 맞춤
    const hipX = 50;
    const legPts = (hx, a0, a1) => { const k = at(hx, 0, a0, R.th), f = at(k[0], k[1], a1, R.sh); return [[hx, 0], k, f]; };
    const bL = legPts(hipX - 2, bl0, bl1), fL = legPts(hipX + 2, fl0, fl1);
    const reach = Math.max(bL[2][1], fL[2][1]);
    const hipY = (o.pose && o.pose.k === 'sit') ? 150 - reach : 150 - reach;
    const off = (pts) => pts.map((q) => [q[0], q[1] + hipY]);
    const BL = off(bL), FL = off(fL);
    const tor = [hipX, hipY];
    const tp = (x, y) => { const c = Math.cos(lean), s = Math.sin(lean); return [tor[0] + x * c - y * s, tor[1] + x * s + y * c]; };
    // 몸통 기준점: 어깨 · 목
    const shB = tp(-3, -R.tor + 4), shF = tp(3, -R.tor + 4), neck = tp(1, -R.tor - 2);
    const armPts = (sh, a0, a1) => { const e = at(sh[0], sh[1], a0, R.ua), h = at(e[0], e[1], a1, R.fa); return [sh, e, h]; };
    const BA = armPts(shB, ba0 + lean * 0.5, ba1 + lean * 0.5), FA = armPts(shF, fa0 + lean * 0.5, fa1 + lean * 0.5);
    const line = (pts) => 'M' + pts.map((q) => f1(q[0]) + ' ' + f1(q[1])).join('L');
    const limb = (pts, w1, w2, c) => { ops.push({ d: line(pts.slice(0, 2)), t: 's', w: w1, c }); ops.push({ d: line(pts.slice(1)), t: 's', w: w2, c }); };
    const foot = (pts, c) => { const a = pts[2]; ops.push({ d: Pg([[a[0] - 4, a[1] - 3], [a[0] + 8, a[1] - 1], [a[0] + 9, a[1] + 0.5], [a[0] - 5, a[1] + 0.5]]), t: 'f', c }); };
    const M = (x, y, r, s) => [Math.cos(r) * (s || 1), Math.sin(r) * (s || 1), -Math.sin(r) * (s || 1), Math.cos(r) * (s || 1), x, y];
    const part = (key, fn, m) => { for (const s of partShapes(key, fn)) ops.push({ p: s.p, t: s.t, w: s.w, c: s.c, m }); };
    const sway = Math.sin((o.t || 0) * 2.3 + (o.seed || 0)) * 3 + (o.pose && o.pose.k === 'walk' ? -4 : 0);
    // 1) 뒤 팔 · 뒤 다리
    if (spec.o === 'dagger') part('w:dagger', (out) => weapon('dagger', 0, 0, out), M(BA[2][0], BA[2][1], ba1 - 0.6));
    limb(BA, R.uw * 0.92, R.fw * 0.92, inkB);
    const robe = spec.b === 'robe';
    if (!robe) { limb(BL, R.lw * 0.95, R.lw * 0.8, inkB); foot(BL, inkB); }
    // 2) 망토
    if (spec.b === 'armor' || spec.b === 'lean' || spec.b === 'giant' || spec.b === 'coat') {
      const a = tp(-6, -R.tor + 2), b = tp(-11, -R.tor * 0.5), c2 = [tor[0] - 14 + sway * 0.5 - lean * 18, Math.min(148, hipY + (spec.b === 'coat' ? 26 : 40))];
      ops.push({ d: 'M' + f1(a[0]) + ' ' + f1(a[1]) + 'Q' + f1(b[0] - 6) + ' ' + f1(b[1]) + ' ' + f1(c2[0]) + ' ' + f1(c2[1]) + 'L' + f1(c2[0] + 12) + ' ' + f1(c2[1] - 6) + 'Q' + f1(tor[0] - 2) + ' ' + f1(hipY - 6) + ' ' + f1(tp(4, -R.tor + 4)[0]) + ' ' + f1(tp(4, -R.tor + 4)[1]) + 'Z', t: 'f', c: 'cloth' });
    }
    // 3) 몸통
    part('t:' + spec.b, (out) => { out.push(F(TORSO[spec.b] || TORSO.lean, bony ? 'bone' : 'ink'));
      if (spec.b === 'armor' || spec.b === 'giant') { out.push(F(El(-15, -41, 8, 7))); out.push(F(El(15, -41, 8, 7))); out.push(S('M-12 -10L12 -10', 1.6, 'trim')); out.push(S('M-9 -38L0 -30L9 -38', 1.1, 'trim')); }
      else if (spec.b === 'brute') { out.push(S('M-16 -24L16 -24', 1.3, 'trim')); }
      else if (spec.b === 'coat') { out.push(S('M-13 -6L13 -6', 1.8, 'trim')); out.push(S('M2 -44L4 -6', 1, 'trim')); }
      else if (spec.b === 'lean') { out.push(S('M-9 -4L9 -6', 1.5, 'trim')); }
      else if (spec.b === 'robe') { out.push(S('M0 -44L0 -2', 1.3, 'trim')); }
      else if (bony) { for (let i = 0; i < 4; i++) out.push(S('M-7 ' + (-36 + i * 8) + 'L7 ' + (-36 + i * 8), 1.8, 'ink')); }
    }, M(tor[0], tor[1], lean));
    // 치마(로브) · 옷자락(외투)
    if (robe) {
      const g = 150 - hipY;
      ops.push({ d: 'M' + f1(tor[0] - 13) + ' ' + f1(hipY - 2) + 'L' + f1(tor[0] + 13) + ' ' + f1(hipY - 2) + 'Q' + f1(tor[0] + 22 + sway) + ' ' + f1(hipY + g * 0.6) + ' ' + f1(tor[0] + 26 + sway) + ' ' + f1(hipY + g) + 'L' + f1(tor[0] - 26 + sway * 0.6) + ' ' + f1(hipY + g) + 'Q' + f1(tor[0] - 22) + ' ' + f1(hipY + g * 0.6) + ' ' + f1(tor[0] - 13) + ' ' + f1(hipY - 2) + 'Z', t: 'f', c: 'ink' });
      ops.push({ d: 'M' + f1(tor[0] + 1) + ' ' + f1(hipY) + 'L' + f1(tor[0] + 3 + sway * 0.5) + ' ' + f1(hipY + g - 2), t: 's', w: 1.3, c: 'trim' });
      foot(FL, 'ink');
    }
    if (spec.o === 'shield') part('w:shield', (out) => weapon('shield', 0, 0, out), M(BA[2][0] + 4, BA[2][1] - 2, 0));
    else if (spec.o === 'buckler') part('w:buckler', (out) => weapon('buckler', 0, 0, out), M(BA[2][0] + 2, BA[2][1], 0));
    if (spec.b === 'coat') {
      ops.push({ d: 'M' + f1(tor[0] - 14) + ' ' + f1(hipY - 4) + 'L' + f1(tor[0] + 14) + ' ' + f1(hipY - 4) + 'L' + f1(tor[0] + 17 + sway * 0.6) + ' ' + f1(hipY + 26) + 'L' + f1(tor[0] + 4) + ' ' + f1(hipY + 20) + 'L' + f1(tor[0] - 7) + ' ' + f1(hipY + 27) + 'L' + f1(tor[0] - 18 + sway) + ' ' + f1(hipY + 25) + 'Z', t: 'f', c: 'ink' });
    }
    // 4) 앞 다리
    if (!robe) { limb(FL, R.lw, R.lw * 0.85, inkF); foot(FL, inkF); }
    // 5) 머리
    part('h:' + spec.h, (out) => headAt(spec.h, 0, 0, out), M(neck[0] + 1, neck[1] - 8, lean * 0.5 + hd));
    // 6) 앞 팔 · 무기
    if (spec.w) part('w:' + spec.w, (out) => weapon(spec.w, 0, 0, out), M(FA[2][0], FA[2][1], (fa1 + lean * 0.5) - 0.55 + wr));
    limb(FA, R.uw, R.fw, inkF);
    ops.push({ d: El(FA[2][0], FA[2][1], R.fw * 0.55, R.fw * 0.55), t: 'f', c: inkF });
    // 횃불(원정대 등불): 뒤 손에
    if (o.torch) {
      const h2 = BA[2];
      ops.push({ d: line([[h2[0] - 1, h2[1] + 6], [h2[0] + 3, h2[1] - 14]]), t: 's', w: 2.6, c: 'ink' });
      const fl = 1 + Math.sin((o.t || 0) * 13) * 0.15;
      ops.push({ d: El(h2[0] + 3, h2[1] - 18, 3.2 * fl, 5.5 * fl), t: 'f', c: 'glow' });
      if (o.out) { o.out.tx = h2[0] + 3; o.out.ty = h2[1] - 18; }
    }
    if (o.out) { o.out.hx = FA[2][0]; o.out.hy = FA[2][1]; o.out.head = neck[1] - 8; }
    return ops;
  }

  /* ---------- 짐승 · 이형: 몸 전체 변형 + 부분 흔들림 ---------- */
  function creatureOps(spec, o) {
    const out = [];
    const t = o.t || 0, sd = o.seed || 0;
    const b = spec.b;
    const k = (o.pose && o.pose.k) || 'idle';
    if (b === 'tentacle') {
      out.push(F('M6 150C4 112 24 84 52 82C82 80 98 112 96 150Z'));
      [[20, 120, 6, 6, 36], [40, 96, 7, 34, 14], [64, 94, 7, 74, 18], [84, 118, 6, 98, 48]].forEach(([x0, y0, w, x1, y1], i) => {
        const s1 = Math.sin(t * 1.6 + i * 1.3 + sd) * 10, s2 = Math.sin(t * 2.3 + i * 2.1 + sd) * 8;
        out.push(S('M' + x0 + ' ' + y0 + 'C' + f1(x0 - 14 + s1) + ' ' + f1(y0 - 34) + ' ' + f1(x1 + 8 + s2) + ' ' + f1(y1 + 30) + ' ' + f1(x1 + s2 * 1.4) + ' ' + f1(y1), w));
        out.push(S('M' + x0 + ' ' + y0 + 'C' + f1(x0 - 14 + s1) + ' ' + f1(y0 - 34) + ' ' + f1(x1 + 8 + s2) + ' ' + f1(y1 + 30) + ' ' + f1(x1 + s2 * 1.4) + ' ' + f1(y1), 0.9, 'trim'));
      });
      for (const [x, y, r] of [[44, 112, 4], [60, 106, 3], [52, 126, 2.4], [70, 122, 2]]) out.push(F(El(x, y, r, r * 0.8 * (0.7 + 0.3 * Math.abs(Math.sin(t * 0.9 + x)))), 'acc'));
      return out;
    }
    if (b === 'plant') {
      const s = Math.sin(t * 1.3 + sd) * 5;
      out.push(S('M50 150C40 120 ' + f1(64 + s) + ' 96 ' + f1(46 + s) + ' 70S' + f1(58 + s * 1.5) + ' 30 ' + f1(70 + s * 1.8) + ' 22', 7));
      out.push(S('M38 150C24 120 36 104 ' + f1(22 + s) + ' 84', 4.5));
      out.push(S('M60 150C76 126 70 110 ' + f1(86 + s * 0.7) + ' 92', 4.5));
      for (const [x, y] of [[44, 104], [54, 82], [26, 96], [80, 104]]) out.push(F(Pg([[x + s * 0.4, y], [x + 6 + s * 0.4, y - 3], [x + 1 + s * 0.4, y + 4]])));
      if (spec.h === 'crownshroom') {
        const cs = s * 1.8;
        out.push(F('M' + f1(18 + cs) + ' 50C' + f1(20 + cs) + ' 24 ' + f1(80 + cs) + ' 16 ' + f1(88 + cs) + ' 46C' + f1(70 + cs) + ' 40 ' + f1(34 + cs) + ' 40 ' + f1(18 + cs) + ' 50Z'));
        out.push(S('M' + f1(30 + cs) + ' 47L' + f1(36 + cs) + ' 32', 1.2, 'trim')); out.push(S('M' + f1(52 + cs) + ' 42L' + f1(54 + cs) + ' 24', 1.2, 'trim')); out.push(S('M' + f1(72 + cs) + ' 44L' + f1(70 + cs) + ' 28', 1.2, 'trim'));
        for (const [x, y] of [[34, 38], [60, 32], [76, 40]]) out.push(F(El(x + cs, y, 2.2, 2.2), 'glow2'));
      } else { out.push(F(El(70 + s * 1.8, 22, 6, 5))); out.push(F(El(72 + s * 1.8, 21, 1.3, 1.3), 'acc')); }
      return out;
    }
    if (b === 'worm' || b === 'serpent') {
      const s = Math.sin(t * 2 + sd) * 6, s2 = Math.cos(t * 1.7 + sd) * 5;
      const d = b === 'worm' ? 'M14 150C10 110 ' + f1(30 + s) + ' 70 ' + f1(62 + s2) + ' 66S94 ' + f1(88 + s) + ' 84 98' : 'M20 150C60 146 ' + f1(20 + s) + ' 112 ' + f1(46 + s2) + ' 100S82 64 ' + f1(70 + s * 0.5) + ' 52';
      out.push(S(d, b === 'worm' ? 16 : 11));
      if (b === 'worm') for (let i = 0; i < 6; i++) out.push(S(Pl([[18 + i * 8 + s * i / 6, 140 - i * 13], [28 + i * 8 + s * i / 6, 136 - i * 13]]), 1.2, 'trim'));
      const hx = b === 'worm' ? 84 : 70 + s * 0.5, hy = b === 'worm' ? 98 : 52;
      if (spec.h === 'maw') headAt('maw', hx, hy, out);
      else { out.push(F(El(hx, hy, 9, 7))); out.push(F(El(hx + 3, hy - 2, 1.5, 1.5), 'acc')); if (b === 'serpent') out.push(S(Pl([[hx + 8, hy + 2], [hx + 14 + Math.sin(t * 9) * 2, hy + 4]]), 1, 'acc')); }
      return out;
    }
    if (b === 'swarm') {
      const pts = [[30, 70], [52, 58], [72, 74], [40, 96], [64, 102], [24, 118], [50, 124], [76, 128], [38, 142]];
      pts.forEach(([x0, y0], i) => {
        const x = x0 + Math.sin(t * 3.1 + i * 2.3 + sd) * 5, y = y0 + Math.cos(t * 2.7 + i * 1.7 + sd) * 5;
        const fl = spec.h === 'bat' || spec.h === 'moth' ? Math.abs(Math.sin(t * 18 + i)) : 1;
        if (spec.h === 'bat') out.push(F(Pg([[x - 12, y - 4 * fl], [x - 4, y - 1], [x, y - 4], [x + 4, y - 1], [x + 12, y - 4 * fl], [x + 6, y + 4], [x, y + 2], [x - 6, y + 4]])));
        else if (spec.h === 'moth') { out.push(F(Pg([[x, y], [x - 9, y - 7 * fl], [x - 7, y + 5]]))); out.push(F(Pg([[x, y], [x + 9, y - 7 * fl], [x + 7, y + 5]]))); out.push(F(El(x, y, 1.6, 4), 'acc')); }
        else { out.push(F(El(x, y + 2, 8, 4.5))); out.push(F(Pg([[x + 6, y - 1], [x + 13, y + 3], [x + 6, y + 5]]))); out.push(S(Q([x - 8, y + 3], [x - 14, y + 8], [x - 20, y + 2 + Math.sin(t * 6 + i) * 3]), 1.1)); out.push(F(El(x + 9, y + 2, 0.9, 0.9), 'acc')); }
      });
      return out;
    }
    if (b === 'hound' || b === 'beast' || b === 'rodent') {
      const big = b === 'beast', rod = b === 'rodent';
      const by = rod ? 130 : big ? 98 : 114, rx = rod ? 22 : big ? 30 : 25, ry = rod ? 11 : big ? 16 : 11;
      const gait = k === 'walk' || k === 'atk' ? t * 10 : 0;
      const leg = (x0, ph) => { const a = Math.sin(gait + ph) * (gait ? 0.35 : 0.04); out.push(S(Pl([[x0, by + 4], [x0 + 2 + Math.sin(a) * 10, by + 22], [x0 + Math.sin(a) * 18, 150]]), big ? 6 : 4.5)); };
      if (!rod) { leg(32, 0); leg(40, Math.PI); leg(62, Math.PI * 0.5); leg(70, Math.PI * 1.5); }
      const br = Math.sin(t * 2.2 + sd) * 1.2;
      out.push(F(El(50, by - br * 0.5, rx, ry + br)));
      out.push(S(Q([50 - rx, by - 2], [12, by - 16 + Math.sin(t * 3 + sd) * 4], [8, by + (rod ? 6 : -4) + Math.sin(t * 4 + sd) * 5]), rod ? 2 : 3.5));
      const nx = 50 + rx - 4, ny = by - ry + 2;
      const hx = nx + (big ? 16 : 12), hy = ny - (big ? 26 : 10) + Math.sin(t * 1.9 + sd) * 1.5;
      out.push(S(Pl([[nx - 4, by - 2], [hx - 4, hy + 4]]), big ? 12 : 10));
      const jaw = k === 'atk' ? 5 : 0;
      out.push(F(Pg([[hx - 8, hy - 6], [hx + 4, hy - 8], [hx + 18, hy + 2 - jaw * 0.3], [hx + 4, hy + 6], [hx - 8, hy + 6]])));
      if (jaw) out.push(F(Pg([[hx - 4, hy + 5], [hx + 14, hy + 6 + jaw], [hx + 2, hy + 10]])));
      out.push(F(El(hx + 3, hy - 2, 1.5, 1.5), 'acc'));
      if (spec.h === 'antler') { const a = (s) => { out.push(S(Pl([[hx - 2, hy - 6], [hx - 6 * s, hy - 26], [hx - 14 * s, hy - 40]]), 2.2)); out.push(S(Pl([[hx - 6 * s, hy - 26], [hx + 6 * s, hy - 38]]), 1.8)); out.push(S(Pl([[hx - 10 * s, hy - 33], [hx - 20 * s, hy - 34]]), 1.6)); }; a(1); a(-0.6); }
      else out.push(F(Pg([[hx - 6, hy - 6], [hx - 3, hy - 16], [hx + 1, hy - 7]])));
      if (rod) out.push(F(El(hx - 4, hy - 7, 3, 4)));
      return out;
    }
    if (b === 'float') {
      const s = Math.sin(t * 1.4 + sd) * 4;
      out.push(F(Pg([[36, 48], [64, 48], [72 + s * 0.5, 104], [60, 96], [54 + s, 138], [46, 102], [32 + s * 0.5, 116], [38, 82]])));
      const reach = k === 'atk' ? 14 : 0;
      out.push(S(Pl([[60, 58], [76 + reach, 74 - reach * 0.6], [88 + reach * 1.4, 70 - reach]]), 4)); out.push(S(Pl([[40, 58], [30, 80 + s], [34, 92 + s]]), 4));
      headAt(spec.h === 'shroud' ? 'shroud' : 'none', 50, 38, out);
      if (spec.h !== 'shroud') { out.push(F(El(50, 38, 9, 10))); out.push(F(El(52, 37, 1.6, 1.6), 'acc')); out.push(F(El(57, 37, 1.3, 1.3), 'acc')); }
      return out;
    }
    if (b === 'blob') {
      const s = Math.sin(t * 2 + sd) * 3;
      out.push(F('M14 150C10 ' + f1(120 - s) + ' 22 ' + f1(96 - s) + ' 40 ' + f1(92 - s) + 'C46 ' + f1(76 - s) + ' 70 ' + f1(78 - s) + ' 74 ' + f1(96 - s) + 'C92 ' + f1(100 - s) + ' 94 130 88 150Z'));
      for (const [x, y] of [[40, 108], [58, 100], [66, 118]]) out.push(F(El(x, y - s, 2, 1.6), 'acc'));
      out.push(S(Pl([[30, 128], [30, 146]]), 2.4)); out.push(S(Pl([[76, 126], [78, 148]]), 2.4));
      if (spec.h === 'shroom') { out.push(F(Pg([[34, 92 - s], [44, 74 - s], [56, 72 - s], [66, 80 - s], [60, 90 - s]]))); out.push(F(El(48, 80 - s, 1.6, 1.6), 'acc')); }
      return out;
    }
    if (b === 'head') {
      const s = Math.sin(t * 1.6 + sd) * 3;
      out.push(S('M44 92C34 110 ' + f1(40 + s) + ' 124 ' + f1(28 + s) + ' 140', 3)); out.push(S('M56 92C64 112 ' + f1(56 - s) + ' 126 ' + f1(66 - s) + ' 142', 3));
      out.push(F(El(50, 72 + s * 0.5, 15, 17), 'bone')); out.push(F(Pg([[42, 82 + s * 0.5], [60, 82 + s * 0.5], [58, 96 + s * 0.5], [44, 96 + s * 0.5]]), 'bone'));
      out.push(F(El(45, 70 + s * 0.5, 4, 4.5))); out.push(F(El(57, 70 + s * 0.5, 3.4, 4.5))); out.push(F(Pg([[44, 88 + s * 0.5], [58, 88 + s * 0.5], [58, 92 + s * 0.5 + (k === 'atk' ? 4 : 0)], [44, 92 + s * 0.5 + (k === 'atk' ? 4 : 0)]])));
      out.push(F(El(45, 70 + s * 0.5, 1.4, 1.4), 'acc')); out.push(F(El(57, 70 + s * 0.5, 1.2, 1.2), 'acc'));
      return out;
    }
    return out;
  }

  /* ---------- 그리기 ---------- */
  const PCACHE = {};
  const pathOf = (d) => { if (PCACHE[d]) return PCACHE[d]; const k = Object.keys(PCACHE); if (k.length > 6000) for (const x of k.slice(0, 3000)) delete PCACHE[x]; return (PCACHE[d] = new Path2D(d)); };
  function colorsFor(spec, o) {
    const en = !!spec.en;
    return {
      ink: o.ink || (en ? '#0b0909' : '#0d0a08'), ink2: en ? '#1a1514' : '#1d1712', cloth: en ? '#141010' : '#1a120d',
      trim: spec.c || '#8c7a5a', bone: '#6d6457', bone2: '#4f483f', acc: o.acc || (en ? '#e6c66e' : '#d9c79a'), glow: '#f6c66a', glow2: '#9fe0c0',
    };
  }
  const EMIT = { acc: 1, glow: 1, glow2: 1 };
  /* ---------- 인물 그림(직업 12: assets/madexp/chars/<직업 id>.webp, 원본 assets/madexp/chars · tools/madexp_cut.py) ----------
     그림이 아직 안 왔으면 먹선 실루엣으로 그린다. 자세는 그림 한 장을 기울이고 밀어서 표현(대기 숨쉬기 · 걷기 · 공격 · 피격 · 문턱 · 야영 · 붕괴). */
  const SPR = {}, SPR_T = {};
  let SPR_ID = null;
  // 자세 그림이 있는 직업만(없는 직업은 기본 그림을 기울여 표현). 동작 이름 → [파일 꼬리, 기본 그림 키에 대한 높이 비율]
  // 높이 비율: 자세 그림은 인물에 딱 맞게 잘려 있어서, 몸 크기가 기본과 같아 보이게 맞추는 값(팔을 들면 1보다 크고 몸을 낮추면 작음).
  const SPR_POSE = {
    ls: { atk: ['atk', 0.94], cast: ['skl', 1.13], hit: ['hit', 0.99] },
  };
  function sprPose(spec, pk) {
    const id = SPR_ID && SPR_ID.get(spec), P = id && SPR_POSE[id] && SPR_POSE[id][pk];
    if (!P) return null;
    const key = id + '_' + P[0];
    let im = SPR[key];
    if (!im) { im = SPR[key] = new Image(); im.src = 'assets/madexp/chars/' + key + '.webp'; }
    return sprReady(im) ? { im, k: P[1] } : null;
  }
  function sprOf(spec) {
    if (!spec || spec.en || typeof Image === 'undefined') return null;
    if (!SPR_ID) { SPR_ID = new Map(); for (const id of Object.keys(CL)) SPR_ID.set(CL[id].a, id); }
    const id = SPR_ID.get(spec); if (!id) return null;
    let im = SPR[id];
    if (!im) { im = SPR[id] = new Image(); im.src = 'assets/madexp/chars/' + id + '.webp'; if (SPR_POSE[id]) for (const pk of Object.keys(SPR_POSE[id])) sprPose(spec, pk); }   // 자세 그림도 미리 불러 둠
    return im;
  }
  const sprReady = (im) => !!im && im.complete && im.naturalWidth > 0;
  function sprTint(im, color) {   // 그림 모양 그대로 한 색으로 칠한 판(테두리빛 · 번쩍임)
    const key = im.src + '|' + color;
    if (SPR_T[key]) return SPR_T[key];
    const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight;
    const g = c.getContext('2d'); g.drawImage(im, 0, 0); g.globalCompositeOperation = 'source-in'; g.fillStyle = color; g.fillRect(0, 0, c.width, c.height);
    return (SPR_T[key] = c);
  }
  function drawSpr(ctx, im, spec, x, y, h, o) {
    const pk = (o.pose && o.pose.k) || 'idle', pp = o.pose && o.pose.p != null ? o.pose.p : 0;
    const PZ = sprPose(spec, pk);   // 그 동작의 그림이 있으면 그걸로
    if (PZ) im = PZ.im;
    const H = h * (spec.k || 1) * 0.9 * (PZ ? PZ.k : 1), W = H * im.naturalWidth / im.naturalHeight;
    const t = o.t || 0, sd = o.seed || 0;
    if (o.out) { o.out.tx = 74; o.out.ty = 58; }   // 횃불 빛 자리(실루엣 칸 기준: 가슴 앞)
    if (o.emit) return;
    let sx = 1, sy = 1 + Math.sin(t * 1.8 + sd) * 0.012, rot = 0, dx = 0, dy = 0, dim = 1;
    if (PZ) {   // 자세 그림: 기울이지 않고 살짝 밀기만
      sy = 1;
      if (pk === 'atk') dx = H * 0.03 * Math.sin(Math.min(1, pp / 0.6) * Math.PI);
      else if (pk === 'hit') dx = -H * 0.03 * Math.max(0, 1 - pp * 2.5);
    }
    else if (pk === 'atk') { const b = Math.sin(Math.min(1, pp / 0.6) * Math.PI); rot = 0.09 * b; dx = H * 0.035 * b; sx = 1 + 0.03 * b; }
    else if (pk === 'hit') { const b = Math.max(0, 1 - pp * 2.5); rot = -0.11 * b; dx = -H * 0.04 * b; }
    else if (pk === 'down') { rot = -0.2; sy *= 0.9; dy = H * 0.015; dim = 0.72; }
    else if (pk === 'sit') { sy *= 0.9; }
    else if (pk === 'walk') { dy = -Math.abs(Math.sin(t * 7 + sd)) * H * 0.012; rot = Math.sin(t * 7 + sd) * 0.012; }
    else if (pk === 'fear') { dx = Math.sin(t * 31 + sd) * H * 0.004; rot = -0.035; }
    ctx.save();
    ctx.translate(x, y);
    if (o.flip) ctx.scale(-1, 1);
    ctx.translate(dx, dy); ctx.rotate(rot); ctx.scale(sx, sy);
    const a0 = ctx.globalAlpha;
    // 1) 테두리빛(빛 쪽으로 살짝 어긋난 한 색 판)
    const rdx = (o.rimDx != null ? o.rimDx : -1) * (o.flip ? -1 : 1) * H * 0.011, rdy = -H * 0.007;
    ctx.globalAlpha = a0 * (o.rim ? 1 : (o.rimA != null ? o.rimA : 0.7));
    ctx.drawImage(sprTint(im, o.rim || 'rgb(232,168,96)'), -W / 2 + rdx, -H + rdy, W, H);
    // 2) 그림
    ctx.globalAlpha = a0;
    ctx.drawImage(im, -W / 2, -H, W, H);
    if (dim < 1) { ctx.globalAlpha = a0 * (1 - dim); ctx.drawImage(sprTint(im, '#0b0808'), -W / 2, -H, W, H); }
    // 3) 번쩍임
    if (o.flash > 0.01) { ctx.globalAlpha = a0 * Math.min(1, o.flash); ctx.drawImage(sprTint(im, o.flashC || '#f0e2c8'), -W / 2, -H, W, H); }
    ctx.restore();
  }
  // drawFig(ctx, spec, x, y, h, o): 발끝 (x, y), 키 h. o: {flip, pose:{k,p}, t, seed, rimDx(-1|1, 빛 쪽), rim, rimA, flash, flashC, emit(눈빛만), torch, out}
  function drawFig(ctx, spec, x, y, h, o) {
    o = o || {};
    { const im = sprOf(spec); if (sprReady(im)) return drawSpr(ctx, im, spec, x, y, h, o); }
    const k = h / 150 * (spec.k || 1);
    const rig = RIG_SET[spec.b];
    const ops = rig ? rigOps(spec, o) : creatureOps(spec, o).map((s) => ({ d: s.d, t: s.t, w: s.w, c: s.c }));
    const col = colorsFor(spec, o);
    const pk = (o.pose && o.pose.k) || 'idle', pp = o.pose && o.pose.p != null ? o.pose.p : 0;
    ctx.save();
    ctx.translate(x, y);
    if (o.flip) ctx.scale(-1, 1);
    ctx.scale(k, k);
    if (!rig) {   // 짐승 · 이형: 몸 전체로 숨쉬기 · 덤비기 · 움찔
      const br = 1 + Math.sin((o.t || 0) * 1.8 + (o.seed || 0)) * 0.018;
      let sx = 1, sy = br, rr = 0;
      if (pk === 'atk') { const b = Math.sin(Math.min(1, pp / 0.6) * Math.PI); sx = 1 + 0.16 * b; sy = br - 0.08 * b; rr = 0.1 * b; }
      else if (pk === 'hit') { const b = Math.max(0, 1 - pp * 2.5); sx = 1 - 0.08 * b; sy = br - 0.1 * b; rr = -0.12 * b; }
      else if (pk === 'down') { sy = 0.86; rr = 0.08; }
      ctx.translate(0, 0); ctx.rotate(rr); ctx.scale(sx, sy);
    }
    ctx.translate(-50, -150);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const draw = (s, color, extraW) => {
      if (s.m) { ctx.save(); ctx.transform(s.m[0], s.m[1], s.m[2], s.m[3], s.m[4], s.m[5]); }
      const p = s.p || pathOf(s.d);
      if (s.t === 'f') { ctx.fillStyle = color; ctx.fill(p); } else { ctx.strokeStyle = color; ctx.lineWidth = s.w + (extraW || 0); ctx.stroke(p); }
      if (s.m) ctx.restore();
    };
    if (o.emit) {   // 어둠 위에 눈빛 · 불빛만
      ctx.globalCompositeOperation = 'lighter';
      for (const s of ops) if (EMIT[s.c]) { ctx.shadowColor = col[s.c]; ctx.shadowBlur = s.c === 'acc' ? 6 : 14; draw(s, col[s.c]); }
      ctx.restore(); return;
    }
    // 1) 테두리빛
    const rdx = (o.rimDx != null ? o.rimDx : -1) * (o.flip ? -1 : 1) * 1.7, rdy = -1.1;
    ctx.save(); ctx.translate(rdx, rdy);
    const rc = o.rim || 'rgba(232,168,96,' + (o.rimA != null ? o.rimA : 0.7) + ')';
    for (const s of ops) if (!EMIT[s.c]) draw(s, rc, 0.6);
    ctx.restore();
    // 2) 먹 · 색
    for (const s of ops) {
      const c = col[s.c] || col.ink;
      if (EMIT[s.c]) { ctx.save(); ctx.shadowColor = c; ctx.shadowBlur = s.c === 'acc' ? 4 : 10; draw(s, c); ctx.restore(); }
      else draw(s, c);
    }
    // 3) 번쩍임
    if (o.flash > 0.01) {
      ctx.globalAlpha *= Math.min(1, o.flash);
      const fc = o.flashC || '#f0e2c8';
      for (const s of ops) draw(s, fc);
    }
    ctx.restore();
  }
  // DOM용 얼굴 칸(캔버스)
  function portrait(spec, size, o) {
    o = o || {};
    const c = document.createElement('canvas');
    const dpr = Math.min(2, (typeof window !== 'undefined' && window.devicePixelRatio) || 1);
    c.width = Math.round(size * dpr); c.height = Math.round(size * dpr);
    c.style.width = size + 'px'; c.style.height = size + 'px'; c.className = 'mx-por';
    const g = c.getContext('2d'); g.scale(dpr, dpr);
    const full = !!o.full;
    const hh = full ? size * 0.92 : size * 2.15;
    const paint = () => {
      const bg = g.createRadialGradient(size * 0.35, size * 0.3, 2, size * 0.5, size * 0.5, size * 0.8);
      bg.addColorStop(0, o.bg0 || '#6b4c2e'); bg.addColorStop(1, o.bg1 || '#17110d');
      g.fillStyle = bg; g.fillRect(0, 0, size, size);
      drawFig(g, spec, size * (full ? 0.5 : 0.47), full ? size * 0.97 : size * 1.9 * (spec.k ? 1 / spec.k : 1) + (spec.b === 'hunch' ? -size * 0.25 : 0), hh, { flip: !!o.flip, t: 0.6, rimDx: o.flip ? 1 : -1, rimA: 0.95 });
    };
    paint();
    { const im = sprOf(spec); if (im && !sprReady(im)) im.addEventListener('load', paint, { once: true }); }   // 그림이 늦게 오면 그때 다시 그림
    return c;
  }

  /* ---------- 배경: 판화(먼 층) · 구역 건축(가운데 층) · 바닥 · 앞 기둥 · 안개 ---------- */
  const IMG = {};
  function zoneImg(name) {
    if (typeof Image === 'undefined') return null;
    if (!IMG[name]) { const im = new Image(); im.src = 'assets/madexp/' + name + '.jpg'; IMG[name] = im; }
    const im = IMG[name];
    return im.complete && im.naturalWidth ? im : null;
  }
  // 판화를 어둡고 바랜 색으로 한 번 구워 둠(매 장면 필터 대신)
  const BAKED = {};
  function bakedImg(name, tint) {
    if (BAKED[name]) return BAKED[name];
    const im = zoneImg(name); if (!im || typeof document === 'undefined') return null;
    const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight;
    const g = c.getContext('2d');
    g.drawImage(im, 0, 0);
    g.globalCompositeOperation = 'multiply'; g.fillStyle = 'rgb(' + tint.join(',') + ')'; g.fillRect(0, 0, c.width, c.height);
    g.globalCompositeOperation = 'source-over'; g.fillStyle = 'rgba(12,9,7,.42)'; g.fillRect(0, 0, c.width, c.height);
    return (BAKED[name] = c);
  }
  let FOG = null;
  function fogTex() {
    if (FOG || typeof document === 'undefined') return FOG;
    const c = document.createElement('canvas'); c.width = 512; c.height = 160;
    const g = c.getContext('2d');
    let sd = 7; const r = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
    for (let i = 0; i < 70; i++) {
      const x = r() * 512, y = 40 + r() * 90, rad = 24 + r() * 60;
      for (const dx of [-512, 0, 512]) {
        const gr = g.createRadialGradient(x + dx, y, 0, x + dx, y, rad);
        gr.addColorStop(0, 'rgba(255,255,255,' + (0.05 + r() * 0.08) + ')'); gr.addColorStop(1, 'rgba(255,255,255,0)');
        g.fillStyle = gr; g.fillRect(x + dx - rad, y - rad, rad * 2, rad * 2);
      }
    }
    return (FOG = c);
  }
  const ZPAL = {   // 돌 색 · 빛받은 가장자리 · 안개 색 · 하늘(먼 곳)
    oss: { st: '#2a211a', lit: '#6e5843', fog: [190, 170, 140], far: '#120d0a', fl: '#1e1814' },
    aq: { st: '#1c2524', lit: '#4f6a63', fog: [150, 190, 180], far: '#0a100f', fl: '#151c1b' },
    gar: { st: '#1f2418', lit: '#56603e', fog: [170, 190, 140], far: '#0c0f08', fl: '#181c13' },
    clo: { st: '#241c24', lit: '#66506a', fog: [190, 160, 190], far: '#100b10', fl: '#1b161b' },
    way: { st: '#261d15', lit: '#7a5e3e', fog: [200, 175, 140], far: '#120d09', fl: '#1d1610' },
  };
  const hrand = (i, k) => (hash('mx' + i + ':' + k) % 10000) / 10000;
  // 구역 건축 한 칸(가운데 층) — x0: 칸 왼쪽, P: 칸 너비, top: 천장, gy: 바닥
  function archTile(ctx, z, i, x0, P, top, gy, pal, t) {
    const pw = P * 0.16, c = pal.st;
    ctx.fillStyle = c;
    if (z === 'oss' || z === 'way') {
      // 둥근 아치 + 굵은 기둥 · 기둥 속 해골 감실
      ctx.fillRect(x0, top, pw, gy - top);
      ctx.beginPath(); ctx.moveTo(x0 + pw, top); ctx.lineTo(x0 + P, top); ctx.lineTo(x0 + P, top + (gy - top) * 0.32);
      ctx.arc(x0 + pw + (P - pw) / 2, top + (gy - top) * 0.32, (P - pw) / 2, 0, Math.PI, true); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = pal.lit; ctx.globalAlpha = 0.35; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.arc(x0 + pw + (P - pw) / 2, top + (gy - top) * 0.32, (P - pw) / 2 - 2, Math.PI, 0); ctx.stroke(); ctx.globalAlpha = 1;
      if (z === 'oss') for (let r = 0; r < 3; r++) for (let q = 0; q < 2; q++) {
        const sx = x0 + pw * (0.3 + q * 0.4), sy = top + (gy - top) * (0.35 + r * 0.16);
        ctx.fillStyle = '#5b5044'; ctx.beginPath(); ctx.ellipse(sx, sy, pw * 0.13, pw * 0.15, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#0d0a08'; ctx.fillRect(sx - pw * 0.08, sy - pw * 0.02, pw * 0.06, pw * 0.06); ctx.fillRect(sx + pw * 0.02, sy - pw * 0.02, pw * 0.06, pw * 0.06);
      }
      if (hrand(i, 'ch') < 0.5) { ctx.strokeStyle = '#0b0807'; ctx.lineWidth = 2; const cx = x0 + P * 0.62 + Math.sin(t * 0.8 + i) * 3; ctx.beginPath(); ctx.moveTo(x0 + P * 0.62, top + (gy - top) * 0.1); ctx.lineTo(cx, top + (gy - top) * (0.3 + hrand(i, 'cl') * 0.2)); ctx.stroke(); }
    } else if (z === 'aq') {
      // 높은 수로 아치 두 층
      ctx.fillRect(x0, top, pw * 0.8, gy - top);
      const mid = top + (gy - top) * 0.45;
      ctx.beginPath(); ctx.moveTo(x0, top); ctx.lineTo(x0 + P, top); ctx.lineTo(x0 + P, top + (gy - top) * 0.15); ctx.arc(x0 + pw * 0.8 + (P - pw * 0.8) / 2, top + (gy - top) * 0.15, (P - pw * 0.8) / 2, 0, Math.PI, true); ctx.closePath(); ctx.fill();
      ctx.fillRect(x0, mid - 6, P, 10);
      ctx.strokeStyle = pal.lit; ctx.globalAlpha = 0.3; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x0, mid - 6); ctx.lineTo(x0 + P, mid - 6); ctx.stroke(); ctx.globalAlpha = 1;
      // 물줄기
      if (hrand(i, 'w') < 0.6) { const wx = x0 + P * (0.3 + hrand(i, 'wx') * 0.4); ctx.strokeStyle = 'rgba(140,190,180,.22)'; ctx.lineWidth = 2; ctx.setLineDash([6, 9]); ctx.lineDashOffset = -t * 40; ctx.beginPath(); ctx.moveTo(wx, mid + 4); ctx.lineTo(wx, gy); ctx.stroke(); ctx.setLineDash([]); }
    } else if (z === 'gar') {
      // 무너진 아치 + 늘어진 뿌리 · 덩굴
      ctx.fillRect(x0, top + (gy - top) * 0.2, pw * 0.9, (gy - top) * 0.8);
      if (hrand(i, 'br') < 0.7) { ctx.beginPath(); ctx.moveTo(x0, top + (gy - top) * 0.2); ctx.quadraticCurveTo(x0 + P * 0.4, top - 10, x0 + P * 0.62, top + (gy - top) * 0.08); ctx.lineTo(x0 + P * 0.58, top + (gy - top) * 0.16); ctx.quadraticCurveTo(x0 + P * 0.38, top + 12, x0 + pw * 0.9, top + (gy - top) * 0.3); ctx.closePath(); ctx.fill(); }
      ctx.strokeStyle = '#0b0d07'; ctx.lineWidth = 1.6;
      for (let k = 0; k < 5; k++) {
        const vx = x0 + P * hrand(i, 'v' + k), len = (gy - top) * (0.15 + hrand(i, 'vl' + k) * 0.45), sw = Math.sin(t * 0.9 + k + i) * 4;
        ctx.beginPath(); ctx.moveTo(vx, top); ctx.quadraticCurveTo(vx + sw, top + len * 0.5, vx + sw * 1.5, top + len); ctx.stroke();
      }
      for (let k = 0; k < 3; k++) { const mx = x0 + P * hrand(i, 'm' + k), mh = 6 + hrand(i, 'mh' + k) * 8; ctx.fillStyle = '#1a2014'; ctx.fillRect(mx - 1, gy - mh, 2, mh); ctx.fillStyle = 'rgba(150,220,180,' + (0.25 + 0.15 * Math.sin(t * 1.5 + k + i)) + ')'; ctx.beginPath(); ctx.ellipse(mx, gy - mh, 6, 3, 0, Math.PI, 0); ctx.fill(); }
    } else {
      // 수도원: 뾰족 아치 · 가는 기둥 · 높은 창의 보랏빛
      ctx.fillRect(x0, top, pw * 0.7, gy - top);
      const cx = x0 + pw * 0.7 + (P - pw * 0.7) / 2, half = (P - pw * 0.7) / 2, sp = top + (gy - top) * 0.36;
      ctx.beginPath(); ctx.moveTo(x0, top); ctx.lineTo(x0 + P, top); ctx.lineTo(x0 + P, sp); ctx.quadraticCurveTo(x0 + P, sp - half * 0.7, cx, sp - half * 1.25); ctx.quadraticCurveTo(x0 + pw * 0.7, sp - half * 0.7, x0 + pw * 0.7, sp); ctx.closePath(); ctx.fill();
      const wx = cx - half * 0.18, wy = sp - half * 0.85, ww = half * 0.36, wh = (gy - top) * 0.32;
      const gl = ctx.createLinearGradient(0, wy, 0, wy + wh); gl.addColorStop(0, 'rgba(150,110,170,.35)'); gl.addColorStop(1, 'rgba(60,40,70,.05)');
      ctx.fillStyle = gl; ctx.beginPath(); ctx.moveTo(wx, wy + wh); ctx.lineTo(wx, wy + ww * 0.6); ctx.quadraticCurveTo(wx + ww / 2, wy - ww * 0.3, wx + ww, wy + ww * 0.6); ctx.lineTo(wx + ww, wy + wh); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(8,6,8,.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(wx + ww / 2, wy); ctx.lineTo(wx + ww / 2, wy + wh); ctx.stroke();
      if (hrand(i, 'cd') < 0.55) { const kx = x0 + pw * 0.35; ctx.fillStyle = '#cdbb90'; ctx.fillRect(kx - 1.5, gy - (gy - top) * 0.36, 3, 7); ctx.fillStyle = 'rgba(255,200,120,.9)'; ctx.beginPath(); ctx.ellipse(kx, gy - (gy - top) * 0.36 - 3 + Math.sin(t * 9 + i) * 0.6, 1.8, 3.2, 0, 0, Math.PI * 2); ctx.fill(); }
    }
  }
  // o: {zone, camX, t, gy, fg(앞 기둥 그림), boss}
  function drawWorld(ctx, W, H, o) {
    const z = o.zone || 'oss', Z = ZI[z] || { img: 'way', tint: [150, 120, 90] }, pal = ZPAL[z] || ZPAL.oss;
    const gy = o.gy, t = o.t || 0, cam = o.camX || 0;
    ctx.fillStyle = pal.far; ctx.fillRect(0, 0, W, H);
    // 먼 층: 판화(좌우 뒤집어 이어 붙여 끊김 없이)
    const im = bakedImg(z === 'way' ? 'way' : Z.img, Z.tint || [150, 120, 90]);
    if (im) {
      const s = (gy * 1.15) / im.height, iw = im.width * s, ih = im.height * s;
      const ox = -((cam * 0.12) % (iw * 2));
      ctx.globalAlpha = 0.62;
      for (let k = -1; k < 4; k++) {
        const x = ox + k * iw; if (x > W || x + iw < 0) continue;
        if (k % 2) { ctx.save(); ctx.translate(x + iw, 0); ctx.scale(-1, 1); ctx.drawImage(im, 0, gy - ih * 0.97, iw, ih); ctx.restore(); }
        else ctx.drawImage(im, x, gy - ih * 0.97, iw, ih);
      }
      ctx.globalAlpha = 1;
    }
    // 먼 곳 어둡게 위로 갈수록
    const sky = ctx.createLinearGradient(0, 0, 0, gy);
    sky.addColorStop(0, 'rgba(6,4,3,.82)'); sky.addColorStop(0.55, 'rgba(6,4,3,.25)'); sky.addColorStop(1, 'rgba(6,4,3,.45)');
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, gy);
    // 가운데 층: 구역 건축
    const P = Math.max(150, gy * 0.95), top = -gy * 0.05, px = cam * 0.5;
    const i0 = Math.floor(px / P) - 1;
    for (let i = i0; i < i0 + Math.ceil(W / P) + 3; i++) archTile(ctx, z, i, i * P - px, P, top, gy, pal, t);
    // 바닥: 판석 · 원근 이음매
    const fh = H - gy;
    const fg = ctx.createLinearGradient(0, gy, 0, H); fg.addColorStop(0, pal.fl); fg.addColorStop(1, '#070605');
    ctx.fillStyle = fg; ctx.fillRect(0, gy, W, fh);
    ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.lineWidth = 1;
    for (let r = 1; r < 5; r++) { const y = gy + fh * (r * r) / 22; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }
    const J = 70, vx = W / 2, j0 = Math.floor((cam - W) / J);
    for (let j = j0; j < j0 + Math.ceil(W * 3 / J) + 2; j++) {
      const xt = j * J - cam;
      const xb = vx + (xt - vx) * 1.9;
      if (Math.max(xt, xb) < -10 || Math.min(xt, xb) > W + 10) continue;
      ctx.beginPath(); ctx.moveTo(xt, gy); ctx.lineTo(xb, H); ctx.stroke();
    }
    ctx.strokeStyle = pal.lit; ctx.globalAlpha = 0.35; ctx.beginPath(); ctx.moveTo(0, gy + 0.5); ctx.lineTo(W, gy + 0.5); ctx.stroke(); ctx.globalAlpha = 1;
    // 물(수로): 바닥 앞쪽 물길과 반짝임
    if (z === 'aq') {
      const wy = gy + fh * 0.5;
      ctx.fillStyle = 'rgba(20,40,40,.75)'; ctx.fillRect(0, wy, W, fh * 0.28);
      ctx.strokeStyle = 'rgba(150,200,190,.18)'; ctx.lineWidth = 1;
      for (let k = 0; k < 14; k++) { const x = ((k * 97 - cam * 1.2 + t * 12) % (W + 60) + W + 60) % (W + 60) - 30; const y = wy + 3 + (k % 4) * fh * 0.06; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 14 + (k % 3) * 6, y); ctx.stroke(); }
    }
    // 안개
    const fgT = fogTex();
    if (fgT) {
      const [fr, fgc, fb] = pal.fog;
      ctx.save(); ctx.globalAlpha = 0.26;
      const fw = W * 0.9, fhh = fw * 160 / 512;
      for (let layer = 0; layer < 2; layer++) {
        const off = -(((cam * (0.6 + layer * 0.5) + t * (8 + layer * 6)) % fw) + fw) % fw;
        const y = gy - fhh * (0.62 - layer * 0.25);
        for (let x = off - fw; x < W; x += fw) ctx.drawImage(fgT, x, y, fw, fhh);
      }
      ctx.restore();
      // 안개 색
      ctx.save(); ctx.globalCompositeOperation = 'multiply'; ctx.fillStyle = 'rgba(' + fr + ',' + fgc + ',' + fb + ',.06)'; ctx.fillRect(0, 0, W, H); ctx.restore();
    }
  }
  // 앞 기둥(가장 가까운 층, 걸을 때만): 어두운 실루엣
  function drawForeground(ctx, W, H, o) {
    const cam = o.camX || 0, P = W * 1.15, px = cam * 1.45;
    const i0 = Math.floor(px / P) - 1;
    for (let i = i0; i < i0 + 3; i++) {
      if (hrand(i, 'fp') < 0.45) continue;
      const x = i * P - px + P * hrand(i, 'fx') * 0.5, w = 26 + hrand(i, 'fw') * 18;
      if (x > W || x + w < 0) continue;
      const g = ctx.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, '#050403'); g.addColorStop(0.7, '#0b0806'); g.addColorStop(1, 'rgba(60,40,24,.6)');
      ctx.fillStyle = g; ctx.fillRect(x, 0, w, H);
    }
  }
  // 횃불 빛: 어둠을 덮고 빛 둘레만 뚫음. light 0~100
  function drawLight(ctx, W, H, o) {
    const L1 = Math.max(0, Math.min(100, o.light)) / 100, t = o.t || 0;
    const fl = 1 + Math.sin(t * 9.1) * 0.02 + Math.sin(t * 14.3) * 0.015 + Math.sin(t * 3.7) * 0.02;
    const R = (0.32 + 0.6 * L1) * Math.max(W, H * 1.6) * fl;
    const edge = 0.62 + 0.33 * (1 - L1);
    const g = ctx.createRadialGradient(o.x, o.y, R * 0.08, o.x, o.y, R);
    g.addColorStop(0, 'rgba(4,3,2,0)');
    g.addColorStop(0.35, 'rgba(4,3,2,' + (edge * 0.2) + ')');
    g.addColorStop(0.7, 'rgba(4,3,2,' + (edge * 0.7) + ')');
    g.addColorStop(1, 'rgba(3,2,2,' + edge + ')');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    // 따뜻한 빛 번짐
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    const w = ctx.createRadialGradient(o.x, o.y, 0, o.x, o.y, R * 0.55);
    w.addColorStop(0, 'rgba(255,150,60,' + (0.05 + 0.1 * L1) * fl + ')'); w.addColorStop(1, 'rgba(255,120,40,0)');
    ctx.fillStyle = w; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }
  const rk = (s) => s.split('').join('·');
  const FXT = {
    bl: (f) => '출혈 ' + f.n + '×' + f.t + (f.c != null && f.c < 100 ? ' (' + f.c + '%)' : ''),
    bg: (f) => '역병 ' + f.n + '×' + f.t + (f.c != null && f.c < 100 ? ' (' + f.c + '%)' : ''),
    stun: (f) => '기절 ' + (f.c == null ? 100 : f.c) + '%',
    mk: (f) => '표식 ' + f.t + '라운드',
    db: (f) => fmtMod(f.s, f.v) + ' ' + f.t + '라운드',
    bf: (f) => fmtMod(f.s, f.v) + ' ' + f.t + '라운드',
    gd: (f) => '호위 ' + f.t + '라운드(대신 맞아 줌)',
    rp: (f) => '반격 태세 ' + f.t + '라운드',
    tn: (f) => '도발 ' + f.t + '라운드(적이 나를 노림)',
    cu: () => '출혈·역병 치료',
    pu: (f) => '밀기 ' + f.n + '칸',
    pl: (f) => '당기기 ' + f.n + '칸',
    st: (f) => '자신 스트레스 +' + f.v,
    hurt: (f) => '대상 체력 −' + f.v,
  };
  const fxList = (l) => (l || []).map((f) => (FXT[f.k] ? FXT[f.k](f) : '')).filter(Boolean);
  const TGT = { e: '적', a: '아군', o: '다른 아군', s: '자신', p: '아군 전체' };
  function skillDesc(S) {
    const p = ['자리 ' + rk(S.f)];
    if (S.t === 'e') p.push('→ 적 ' + rk(S.r) + (S.m ? ' 전부' : ''));
    else if (S.t === 'a' || S.t === 'o') p.push('→ ' + TGT[S.t] + ' ' + rk(S.r));
    else p.push('→ ' + TGT[S.t]);
    if (S.t === 'e' && S.acc) p.push('명중 ' + S.acc);
    if (S.dm > 0) p.push('피해 ×' + S.dm + (S.cr ? ' · 치명 +' + S.cr + '%' : ''));
    if (S.ip) p.push('방어 무시');
    if (S.vsU) p.push('망자·이형에게 +' + Math.round(S.vsU * 100) + '%');
    if (S.vsM) p.push('표식 대상에게 +' + Math.round(S.vsM * 100) + '%');
    if (S.exe) p.push('체력 ⅓ 아래 대상에게 +' + Math.round(S.exe * 100) + '%');
    if (S.low) p.push('내 체력이 절반 아래일 때만');
    if (S.hl) p.push('치유 ' + S.hl[0] + '–' + S.hl[1]);
    if (S.sh) p.push('스트레스 −' + S.sh);
    p.push(...fxList(S.fx));
    if (S.sx) p.push(...fxList(S.sx).map((x) => '자신: ' + x));
    if (S.sm) p.push(S.sm > 0 ? '앞으로 ' + S.sm + '칸 나섬' : '뒤로 ' + (-S.sm) + '칸 물러섬');
    if (S.lt) p.push('빛 +' + S.lt);
    if (S.gold) p.push('맞히면 금화 ' + S.gold[0] + '–' + S.gold[1]);
    return p.join(' · ');
  }
  function eSkillDesc(S) {
    const p = [];
    if (S.sum) return '빈자리에 ' + EI[S.sum].n + ' 불러옴';
    const t = S.t || 'e';
    if (t === 'e') p.push('원정대 ' + rk(S.r) + (S.m ? ' 전부' : ''));
    else if (t === 'a') p.push('같은 편');
    else p.push('자신');
    if (S.dm > 0) p.push('피해 ×' + S.dm);
    if (S.st) p.push('스트레스 +' + S.st);
    if (S.hl) p.push('치유 ' + S.hl[0] + '–' + S.hl[1]);
    if (S.lt) p.push('빛 ' + S.lt);
    if (S.ip) p.push('방어 무시');
    if (S.drain) p.push('피해 절반만큼 회복');
    p.push(...fxList(S.fx));
    return p.join(' · ');
  }
  function campDesc(C) {
    const e = C.e, p = [C.h + '시간', { s: '자신', o: '다른 대원', a: '대원 하나', p: '모두' }[C.t]];
    if (e.hp) p.push('체력 +' + e.hp + '%');
    if (e.st) p.push('스트레스 ' + (e.st > 0 ? '+' : '−') + Math.abs(e.st));
    if (e.cure) p.push('출혈·역병 치료');
    if (e.buf) p.push(fmtMod(e.buf.s, e.buf.v) + '(다음 층)');
    if (e.amb) p.push('야습 확률 ' + e.amb + '%');
    if (e.light) p.push('빛 +' + e.light);
    if (e.scout) p.push('다음 층 첫 정찰 확실');
    if (e.item) p.push(PV[e.item].n + ' +1');
    if (e.food) p.push('식량 +' + e.food);
    return p.join(' · ');
  }
  const ROLE = { front: '앞줄', heal: '치유', ranged: '뒷줄 공격', stress: '마음 돌봄' };

  /* ---------- 도감 (데이터에서 자동) ---------- */
  function codex() {
    const zn = (z) => (z === '*' ? '어디서나' : ZI[z].n);
    const curOut = (o) => Object.keys(o).map((k) => ({ gold: '금화', trk: '장신구', item: '보급품', heal: '체력 회복', st: o.st < 0 ? '스트레스 회복' : '스트레스', qk: o.qk > 0 ? '좋은 기질' : '나쁜 기질', bl: '출혈', bg: '역병', fight: '습격', light: o.light > 0 ? '빛' : '빛 잃음', buf: '이번 층 강화', xp: '경험', hurt: '부상', vir: '의지 시험' }[k] || k)).join('');
    return [
      { h: '직업', p: ['원정 준비 때 후보 8명 중 넷을 고르고, 역참에서 빈자리를 채워요. 기술은 일곱 중 넷을 골라 들고 가요(전투 밖에서 언제든 바꿈).'],
        rows: CLS.map((C) => ({ icon: '<img src="assets/madexp/chars/' + C.id + '.webp" alt="" style="width:30px;height:30px;object-fit:cover;object-position:50% 3%;border-radius:6px;background:radial-gradient(#5a4430,#1a1411)">', name: C.n, tag: ROLE[C.role] + ' · 자리 ' + rk(C.rk), desc: C.d + ' 체력 ' + C.hp + ' · 속도 ' + C.spd + ' · 회피 ' + C.dg + ' · 방어 ' + C.pr + '% · 피해 ' + C.dmg[0] + '–' + C.dmg[1] + ' · 치명 ' + C.cr + '% · 기절 저항 ' + C.res.st + '%' })) },
      { h: '기술', p: ['「자리」는 내가 서 있어야 하는 칸, 「→」 뒤는 노릴 수 있는 칸이에요. 1이 맨 앞이에요.'],
        rows: [].concat(...CLS.map((C) => C.sk.map((S, i) => ({ icon: icoTile(S.ic), name: S.n, tag: C.n + (C.def.includes(i) ? ' · 기본' : ''), desc: skillDesc(S) })))) },
      { h: '야영 기술', p: ['층 사이 야영에서 12시간을 나눠 써요. 대원마다 직업 기술 둘과 공용 기술 셋, 각각 한 번씩.'],
        rows: [].concat(...CLS.map((C) => C.camp.map((K) => ({ icon: icoTile(K.ic), name: K.n, tag: C.n, desc: campDesc(K) }))), CAMP_ALL.map((K) => ({ icon: icoTile(K.ic), name: K.n, tag: '공용', desc: campDesc(K) }))) },
      { h: '적', p: ['층이 깊어질수록 체력과 피해가 늘어요. 망자는 출혈에, 식물은 역병에 강해요.'],
        rows: EN.map((E) => ({ icon: figSVG(enSpec(E.id), 30, { flip: 1 }), name: E.n, tag: (E.boss ? '우두머리 · ' : '') + zn(E.z) + ' · ' + TGN[E.tg], desc: E.d + ' 체력 ' + E.hp + ' · 속도 ' + E.spd + ' · 회피 ' + E.dg + ' · 방어 ' + E.pr + '% · 피해 ' + E.dmg[0] + '–' + E.dmg[1] + ' — ' + E.sk.map((S) => S.n + '(' + eSkillDesc(S) + ')').join(' / ') })) },
      { h: '붕괴·각성', p: ['스트레스가 100에 닿으면 의지 시험. 대개 무너지고(붕괴), 드물게 단단해져요(각성). 붕괴는 스트레스가 40 아래로 내려가면 풀려요.'],
        rows: AFF.map((A) => ({ icon: icoTile(A.ic, '#d88a7a'), name: A.n, tag: '붕괴 · 멋대로 ' + Math.round(A.act * 100) + '% · 거부 ' + Math.round(A.ref * 100) + '%', desc: A.d + ' ' + modsText(A.m) + ' — 예: 「' + A.bark[0] + '」' }))
          .concat(VIR.map((V) => ({ icon: icoTile(V.ic, '#e3c06a'), name: V.n, tag: '각성', desc: V.d + ' ' + modsText(V.m) + ' — 예: 「' + V.bark[0] + '」' }))) },
      { h: '기질', p: ['원정 중에 얻는 버릇이에요(야영·기묘한 물건). 좋은 것·나쁜 것 각각 셋까지, 넘으면 오래된 것이 밀려나요. 판이 끝나면 사라져요.'],
        rows: QK.map((q) => ({ icon: icoTile(q.p ? 'sunbeams' : 'broken-heart', q.p ? '#cdbb84' : '#b07a70'), name: q.n, tag: q.p ? '좋은 기질' : '나쁜 기질', desc: quirkDesc(q) })) },
      { h: '장신구', p: ['전투와 상자, 기묘한 물건에서 얻어요. 대원마다 둘까지 차고, 역참에서 절반 값에 팔 수 있어요.'],
        rows: TRK.map((t) => ({ icon: icoTile(t.ic, t.r === 3 ? '#e3b45a' : t.r === 2 ? '#c99ad8' : t.r === 1 ? '#9ec3d8' : '#d6c6a4'), name: t.n, tag: RARN[t.r], desc: trkDesc(t) })) },
      { h: '보급품', p: ['출발 전과 역참에서 사요. 판 밖으로 이어지지 않아요.'],
        rows: PROV.map((p) => ({ icon: icoTile(p.ic), name: p.n, tag: p.p + '금화', desc: p.d })) },
      { h: '기묘한 물건', p: ['방과 통로에서 만나요. 맞는 보급품을 쓰면 좋은 결과가 확실하고, 그냥 손대면 운에 맡겨요.'],
        rows: CUR.map((c) => ({ icon: icoTile(c.ic), name: c.n, tag: zn(c.z) + (c.it ? ' · ' + PV[c.it].n : ''), desc: c.d + ' 좋은 결과 ' + Math.round(c.g * 100) + '% — ' + c.good.map(curOut).join('·') + ' / 나쁜 결과 — ' + c.bad.map(curOut).join('·') })) },
      { h: '구역', p: ['구역 하나는 3층이고, 셋째 층 계단 앞에 우두머리가 있어요. 구역 순서는 판마다 무작위예요.'],
        rows: ZONES.map((z) => ({ icon: figSVG(enSpec(z.boss), 30, { flip: 1 }), name: z.n, tag: '우두머리: ' + EI[z.boss].n, desc: z.d })) },
    ];
  }

  /* ---------- 미리보기 (640×360) ---------- */
  function preview(cnv) {
    const c = cnv.getContext('2d'), W = cnv.width, H = cnv.height;
    c.fillStyle = '#0d0a08'; c.fillRect(0, 0, W, H);
    c.strokeStyle = 'rgba(150,120,90,.10)'; c.lineWidth = 1;
    for (let x = -H; x < W; x += 6) { c.beginPath(); c.moveTo(x, H); c.lineTo(x + H * 0.7, 0); c.stroke(); }
    for (let i = 0; i < 6; i++) { c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(40 + i * 110, 30, 26, H * 0.62); }
    const fy = H * 0.86;
    const g = c.createRadialGradient(W * 0.36, fy - 70, 20, W * 0.36, fy - 70, W * 0.55);
    g.addColorStop(0, 'rgba(255,184,100,.32)'); g.addColorStop(0.5, 'rgba(40,22,10,.35)'); g.addColorStop(1, 'rgba(0,0,0,.92)');
    c.fillStyle = g; c.fillRect(0, 0, W, H);
    ['kn', 'ex', 'ls', 'xb'].forEach((id, i) => drawFig(c, CL[id].a, W * 0.42 - i * 64, fy, 150, {}));
    ['bonecrown', 'skspear', 'wraith'].forEach((id, i) => drawFig(c, enSpec(id), W * 0.6 + i * 74, fy, i ? 150 : 170, { flip: 1, rimDx: -1.6 }));
    c.fillStyle = '#e8dcc6'; c.font = '34px "Black Han Sans", sans-serif'; c.textAlign = 'right'; c.fillText('광기의 원정대', W - 26, 52);
    c.font = 'italic 15px "IBM Plex Sans KR", serif'; c.fillStyle = 'rgba(232,220,198,.7)'; c.fillText('빛이 줄어들수록 벽은 가까워진다.', W - 26, 80);
  }

  /* ---------- 상황 도움말 ---------- */
  function hint(s, seat) {
    if (!s) return null;
    const L1 = { prep: '원정 준비', map: '탐험', fight: '전투', curio: '기묘한 물건', camp: '야영', way: '역참' }[s.ph] || '';
    const out = [L1 + ' — ' + (s.mp ? (s.fl + 1) + '층 · ' + ZI[s.mp.z].n : '출발 전')];
    const b = LB[band(s.light)];
    if (s.ph === 'prep') out.push('후보 중 넷을 골라 자리(1이 맨 앞)를 정하고, 보급품을 산 뒤 「출발」.', '앞줄 둘 · 치유 하나는 꼭 넣는 편이 안전해요.');
    else if (s.ph === 'map') {
      out.push('빛 ' + s.light + ' (' + b.n + ') — 낮을수록 기습·스트레스·적의 치명이 늘고 전리품이 많아져요.');
      out.push('지도에서 이웃한 방을 눌러 이동(다시 누르면 출발). 계단 칸에서 「내려가기」.');
      if (s.mp.boss) out.push('이 층 계단 앞에는 우두머리가 있어요.');
    } else if (s.ph === 'fight') {
      const h = s.pt.find((x) => x.u === s.fi.cur);
      if (h) {
        out.push(heroName(h) + '의 차례 · 자리 ' + (s.pt.indexOf(h) + 1));
        const ok = h.sk.filter((si) => canUse(s, h, si)).map((si) => CL[h.c].sk[si].n);
        out.push(ok.length ? '지금 쓸 수 있는 기술: ' + ok.join(', ') : '이 자리에서는 쓸 기술이 없어요 — 「앞으로」·「뒤로」로 자리를 바꿔요.');
        if (h.af) out.push('붕괴(' + AF[h.af].n + ') 중이라 명령을 거부할 수 있어요.');
      }
      out.push('적 머리 위 막대가 체력, 아래 아이콘이 상태예요. 표식이 있는 적은 일부 기술에 더 아파요.');
    } else if (s.ph === 'curio' && s.cu) { const C = CI[s.cu.id]; out.push(C.n + ': ' + C.d, C.it ? PV[C.it].n + josa(PV[C.it].n, '을', '를') + ' 쓰면 좋은 결과가 확실해요.' : '맞는 보급품이 없어요. 손대면 운에 맡겨요.'); }
    else if (s.ph === 'camp' && s.cp) out.push('남은 시간 ' + s.cp.h + '시간 · 야습 확률 ' + s.cp.amb + '%', '대원마다 기술을 한 번씩. 다 쓰면 「야영 끝내기」.');
    else if (s.ph === 'way') out.push('보급품 사기 · 빈자리 모집 · 휴식(스트레스 −40, 체력 +50%)', '준비가 끝나면 「출발」.');
    void seat;
    return out.slice(0, 6);
  }

  const ICON = '<path d="M26 54l4-26h-4l-2 26z" fill="currentColor"/><path d="M28 30c-9-5-9-13-3-19 0 6 4 7 5 3 1-5 6-7 6-12 6 7 7 16 1 22-3 4-6 6-9 6z" fill="currentColor"/><path d="M6 48h8v-6h8M34 48h8v-6h8v-6h6" fill="none" stroke="currentColor" stroke-width="3"/>';

  L.register({
    id: ID, name: '광기의 원정대', tag: '어두운 던전 로그라이크', cat: '전략', time: '40–90분', mood: 'tension', ambient: 'cave',
    blurb: '네 사람의 원정대를 이끌고 지하로 내려가요. 몸이 다치는 만큼 마음도 무너지고, 무너진 대원은 명령을 거부하거나 동료를 흔들어요. 횃불을 밝힐지 아낄지가 위험과 보상을 함께 정해요.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, hidden: false, aiDelay: 600, undo: false, save: true, sidePanel: true, landscape: true,
    saveLabel: (s) => (s.ph === 'prep' ? '출발 전' : (s.fl + 1) + '층 / ' + s.len + '층 · 대원 ' + s.pt.length),
    icon: ICON, tint: '#3a2416',
    options: [
      { id: 'len', label: '원정 길이', tip: '구역 하나 = 3층, 셋째 층에 우두머리. 구역 사이에는 역참이 있어요.', choices: [{ v: 3, label: '짧게 · 3층', tip: '구역 하나, 약 15–25분' }, { v: 6, label: '보통 · 6층', tip: '구역 둘, 약 40–60분' }, { v: 9, label: '길게 · 9층', tip: '구역 셋' }, { v: 12, label: '아주 길게 · 12층', tip: '구역 넷 전부' }], def: 6 },
    ],
    controls: [
      { id: 's1', label: '기술 1', keys: ['Digit1'], pad: ['x'] }, { id: 's2', label: '기술 2', keys: ['Digit2'], pad: ['y'] },
      { id: 's3', label: '기술 3', keys: ['Digit3'], pad: ['b'] }, { id: 's4', label: '기술 4', keys: ['Digit4'], pad: ['a'] },
      { id: 'torch', label: '횃불 넣기', keys: ['KeyT'], pad: ['rb'] }, { id: 'items', label: '보급품', keys: ['KeyI'], pad: ['lb'] },
    ],
    quick: [
      '대원 넷을 골라 보급품을 사고 지하로 내려가요. 마지막 층의 우두머리를 쓰러뜨리면 원정 완수, 모두 쓰러지면 끝.',
      '전투는 속도 순서로 한 명씩. 서 있는 자리(1이 맨 앞)에 따라 쓸 수 있는 기술과 노릴 수 있는 적이 정해져요.',
      '스트레스가 100에 닿으면 붕괴(명령 거부·동료 흔들기)나 드물게 각성, 200이면 심장 발작이에요.',
      '횃불이 밝으면 안전하고, 어두우면 위험한 대신 전리품이 늘어요. 층 사이에는 야영, 구역 사이에는 역참이 있어요.',
    ],
    rules: [
      { h: '목표', p: [
        '혼자(또는 2~4명이 함께) 원정대 넷을 이끌고 지하 여러 층을 내려가는 로그라이크예요. 원정 길이는 3·6·9·12층(기본 6층).',
        '구역 하나는 3층이고, 셋째 층 계단 앞을 우두머리가 지켜요. 마지막 우두머리를 쓰러뜨리면 원정 완수. 원정대가 모두 쓰러지면 끝이에요.',
        '판 밖으로 이어지는 성장은 없어요. 레벨·기질·장신구는 이번 원정 안에서만 유효해요. 길어지면 저장해 두고 이어서 할 수 있어요.'] },
      { h: '원정 준비', p: [
        '후보 8명 중 넷을 골라 자리를 정해요. 1이 맨 앞(적과 가장 가까움), 4가 맨 뒤예요.',
        '대원은 직업마다 기술 일곱 가운데 넷을 들고 가요. 전투 밖에서는 언제든 바꿀 수 있어요.',
        '금화 600으로 보급품(식량·횃불·삽·붕대·해독초·열쇠·성수·진정 팅크)을 사요. 「추천 구성」을 누르면 알맞게 채워져요.'] },
      { h: '탐험', p: [
        '층은 방과 통로로 이루어진 지도예요. 이웃한 방을 누르면 그 방까지 통로를 걸어가요(다시 누르면 출발).',
        '통로 한 칸마다 빛이 5 줄고, 함정·기묘한 물건·잔해·적이 숨어 있을 수 있어요. 잔해는 삽으로 치우고, 없으면 손으로 치우느라 다치고 지쳐요.',
        '방에 들어가면 가끔 이웃한 방과 통로가 보여요(정찰, 밝을수록 잘 됨). 계단이 있는 방에서 「내려가기」로 다음 층.',
        '14칸을 걸을 때마다 허기: 대원 수만큼 식량을 먹어요. 모자라면 스트레스와 체력을 잃어요.'] },
      { h: '횃불과 빛', p: [
        '빛 0~100. 「횃불」은 빛 +25, 「어둡게」는 −25(일부러 어둡게 갈 수도 있어요).',
        '밝음(76~)·어스름(51~)·어둠(26~)·칠흑(1~)·완전한 어둠(0). 어두울수록 기습을 당하기 쉽고, 걸을 때마다 스트레스가 쌓이며, 적의 명중·치명·피해가 오르는 대신 금화와 전리품이 늘어요(최대 1.75배).'] },
      { h: '전투', p: [
        '라운드마다 모두가 속도 순서로 한 번씩 움직여요(우두머리는 두 번). 내 대원 차례에는 기술 하나 · 자리 바꾸기 · 버티기 · 후퇴 중 하나를 해요. 보급품은 차례를 쓰지 않아요.',
        '기술마다 「쓸 수 있는 자리」와 「노릴 수 있는 자리」가 있어요. 밀려나거나 동료가 쓰러져 자리가 바뀌면 쓸 수 없는 기술이 생겨요.',
        '명중 = 기술 명중 + 내 명중 − 상대 회피(5~95%). 치명이면 피해 1.5배, 원정대 모두의 스트레스가 조금 줄어요. 적의 치명에 맞으면 스트레스가 크게 올라요.',
        '상태: 출혈·역병(차례마다 피해) · 기절(한 차례 쉼) · 표식(노림 대상) · 호위(대신 맞아 줌) · 반격 태세 · 도발 · 강화·약화.',
        '후퇴는 보통 75%(우두머리 45%)로 성공하고, 앞에 있던 방으로 물러나요. 남은 적은 그대로예요.'] },
      { h: '스트레스와 광기', p: [
        '스트레스 0~200. 어둠, 적의 공포스러운 기술, 치명타, 동료의 죽음, 허기가 쌓아요. 기술·야영·보급품으로 덜어 내요.',
        '100에 닿으면 의지 시험: 대개 붕괴(공포·편집·자학·이기심·광포·절망·무모), 약 4번에 1번은 각성(불굴·집중·용기·강인·굳건).',
        '붕괴한 대원은 차례에 제멋대로 굴고(물러서기·자해·아무나 공격·식량 훔치기), 명령을 거부하고, 말로 동료의 스트레스를 올려요. 스트레스가 40 아래로 내려가면 정신을 추스려요.',
        '200에 닿으면 심장 발작: 곧바로 죽음의 문턱으로, 이미 문턱이면 죽어요.'] },
      { h: '죽음의 문턱', p: [
        '체력이 0이 되면 바로 죽지 않고 죽음의 문턱에 서요. 그 상태에서 또 맞으면(지속 피해 포함) 버틸지 죽을지 판정해요(기본 60%).',
        '치유를 받으면 문턱에서 벗어나지만, 그 층이 끝날 때까지 후유증(명중·피해·속도 감소)이 남아요.'] },
      { h: '야영 · 역참', p: [
        '층 사이 계단을 내려가면 야영해요. 먼저 대원마다 식량 하나를 먹고(못 먹으면 스트레스·체력 손해), 12시간을 야영 기술에 나눠 써요. 끝낼 때 야습을 당할 수 있어요.',
        '구역 사이에는 무너진 역참이 있어요. 보급품을 사고, 빈자리에 새 대원을 모집하고, 금화를 내고 쉬고(스트레스 −40, 체력 +50%), 장신구를 팔 수 있어요.'] },
      { h: '여럿이 하기', p: [
        '2~4명 협동: 대원마다 맡은 사람이 있어요(카드의 색 점). 전투에서는 자기 대원 차례에 직접 고르고, 탐험·야영·역참은 원정대장(층마다 돌아가며)이 정해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. AI는 상황 점수와 판마다 다른 버릇으로 판단해요.'] },
      { h: '조작', p: [
        '가로 화면: 위는 장면, 아래 띠는 왼쪽 대원 · 가운데 행동 · 오른쪽 정보(대상 · 작은 지도 · 기록)예요. 세로로 들면 장면 아래에 차례로 쌓여요.',
        '전투: 가운데 기술을 누르고 → 장면의 적을 누르거나 오른쪽 대상 단추를 눌러요. 표적 아래에 명중 확률과 피해가 보여요. 자신 · 전체 기술은 대상 단추 하나만 나와요.',
        '탐험: 가운데 길 단추(동쪽 · 서쪽 · 앞으로 등)를 누르면 바로 그 방까지 걸어가요. 작은 지도를 누르면 큰 지도가 열리고, 큰 지도에서 이웃한 방을 눌러도 돼요.',
        '대원 칸이나 장면의 대원을 누르면 능력치 · 기질 · 장신구 · 기술을 보고 바꿀 수 있어요(전투 밖). 연출 중에 장면을 누르면 빨리 넘겨요.',
        'PC: 1~4 기술 · T 횃불 · I 보급품 · Esc 게임 메뉴 · F1 지금 상황. 로그라이크라 무르기는 없어요.'] },
      { h: '예시', p: [
        '앞줄의 해골 창병이 단단하면, 뒤에 있는 납골 사제(적을 치유함)부터 석궁이나 매로 노려요.',
        '등불 수녀가 2번 자리로 밀렸다면 「손 얹기」를 쓸 수 없어요. 차례 하나를 써서 뒤로 물러나거나, 다른 기술로 버텨요.',
        '빛 30에서 통로를 걸으면 한 칸마다 스트레스가 1씩. 횃불 하나로 어스름 이상을 지키면 기습도 줄어요.'] },
      { h: '만든 사람', p: [
        '시스템 참고: Darkest Dungeon(Red Hook Studios)의 진행 구조만 참고했어요. 직업·적·이름·그림·문장은 모두 이 게임을 위해 새로 만들었어요.',
        '인물·적 실루엣: 이 게임을 위해 코드로 직접 그렸어요.',
        '아이콘: game-icons.net(CC BY 3.0) — Lorc, Delapouite, Skoll, sbed, DarkZaitzev, Carl Olsen, Willdabeast, Andy Meneely. 크기만 줄여 썼어요.',
        '배경 판화(퍼블릭 도메인): 조반니 바티스타 피라네시 「상상의 감옥」(1750·1761) 「원형 탑」「도개교」「연기 나는 불이 있는 아치」「우물」, 귀스타브 도레 「신곡 지옥편」 1번 판(1861). 위키미디어 공용에서 받아 어둡게 다듬었어요.',
        '효과음·음악·환경음: 한판 라운지 공용 합성음.'] },
    ],
    tutorial: [
      { sel: '.mx-ov', text: '먼저 원정대를 꾸려요. 후보 8명 중 넷을 넣고(1이 맨 앞), 보급품을 사서 출발해요. 앞줄 둘과 치유 하나가 기본이에요.' },
      { text: '위쪽 띠의 횃불 막대가 빛이에요. 걸을수록 줄고, 어두울수록 기습 · 스트레스가 늘지만 전리품도 늘어요. 아래 「횃불」로 다시 밝혀요.' },
      { text: '아래 띠 왼쪽이 대원이에요. 붉은 막대가 체력, 보라 막대가 스트레스예요. 스트레스가 100에 닿으면 대개 무너지고(붕괴), 드물게 단단해져요(각성).' },
      { text: '전투에서는 가운데 기술 단추를 누른 뒤 장면의 적(또는 오른쪽 대상 단추)을 눌러요. 표적 아래에 명중 확률과 피해가 보여요. 위쪽 「순서」 막대가 행동 순서예요.' },
    ],
    init, actor, apply, ai, aiDelayFor, result, hint, preview, codex: codex(),
    panelInfo(s) {
      if (!s || s.ph === 'prep') return null;
      return [{ label: '층', value: (s.fl + 1) + ' / ' + s.len }, { label: '빛', value: s.light + ' · ' + LB[band(s.light)].n }, { label: '금화', value: String(s.gold) }, { label: '식량 · 횃불', value: s.inv.food + ' · ' + s.inv.torch }, { label: '대원', value: s.pt.length + '명' }];
    },
    mount,
    _t: { CL, EI, hStats, eStats, canUse, targetsFor, skillDesc, band, LB, drawFig, drawWorld, drawLight, drawForeground, heroSpec, enSpec, CLS, EN },
  });
  function mount(root, api) {
    const h = L.h, U = L.util;
    const spd = () => Math.max(0.25, ((L.debug && L.debug.speed) || 1) * (L.speed ? L.speed() : 1));
    const fxAmt = () => (L.fx ? L.fx() : 1);
    const CSS = `
.mx{position:absolute;inset:0;font-family:var(--f-body);color:#f1e6d2;-webkit-user-select:none;user-select:none;background:#0a0807;overflow:hidden;font-size:13px}
.mx button{font-family:var(--f-body);color:#f1e6d2;cursor:pointer;-webkit-tap-highlight-color:transparent}
.mx canvas.mx-cv{position:absolute;left:0;top:0;touch-action:none}
.mx-top{position:absolute;left:0;top:0;display:flex;align-items:center;gap:10px;padding:0 64px 0 10px;height:38px;box-sizing:border-box;z-index:3;pointer-events:none;background:linear-gradient(rgba(8,6,5,.88),rgba(8,6,5,.55) 70%,rgba(8,6,5,0))}
.mx-top .fl{min-width:0;flex:0 1 auto;line-height:1.1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.mx-top .fl b{font-family:var(--f-display);font-weight:400;font-size:16px;letter-spacing:.02em;color:#f4e6c8;white-space:nowrap;text-shadow:0 1px 2px #000}
.mx-top .fl span{font-size:12px;color:#d4c3a2;white-space:nowrap;margin-left:7px}
.mx-lt{display:flex;align-items:center;gap:6px;flex:0 0 auto;margin-left:auto}
.mx-lt .bar{width:92px;height:9px;border-radius:5px;background:#2b211a;overflow:hidden;border:1px solid rgba(255,220,160,.22)}
.mx-lt .bar i{display:block;height:100%;background:linear-gradient(90deg,#9a521f,#ffc76a);transition:width .35s}
.mx-lt b{font-family:var(--f-mono);font-size:13px;font-weight:700;color:#ffd894;min-width:24px}
.mx-lt em{font-style:normal;font-size:12px;color:#ead7b4;white-space:nowrap}
.mx-res{display:flex;gap:10px;align-items:center;flex:0 0 auto}
.mx-res span{display:flex;align-items:center;gap:3px;font-family:var(--f-mono);font-size:13px;font-weight:600;color:#f1e3c6}
.mx-dock{position:absolute;z-index:3;box-sizing:border-box;display:grid;gap:8px;word-break:keep-all;padding:7px 8px 8px;background:linear-gradient(#17110d,#0e0a08);border-top:1px solid rgba(220,175,110,.28)}
.mx-col{min-width:0;min-height:0;display:flex;flex-direction:column;gap:6px;overflow:hidden}
.mx-row2{display:flex;gap:6px;min-width:0}
.mx-b{min-height:44px;border-radius:9px;border:1px solid rgba(220,175,110,.38);background:#241a13;font-size:13.5px;font-weight:500;padding:4px 8px;display:flex;align-items:center;justify-content:center;gap:6px;line-height:1.15;position:relative;min-width:0;box-sizing:border-box}
.mx-b:active:not(:disabled){transform:translateY(1px);background:#33251a}
.mx-b:disabled{opacity:.42;cursor:default;border-style:dashed}
.mx-b.pri{background:#6a3f17;border-color:#f0b862;color:#fff3dc;font-weight:600}
.mx-b.sel{border-color:#ffd27a;box-shadow:0 0 0 2px #ffd27a inset;background:#3a2915}
.mx-b.warn{border-color:#d0705f;color:#ffd5cb}
.mx-b .k{position:absolute;left:5px;top:3px;font-family:var(--f-mono);font-size:11px;color:#c8b48f}
.mx-sk{flex:1 1 0;flex-direction:column;gap:2px;padding:4px 3px;min-height:62px}
.mx-sk span{font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.mx-sk small{font-family:var(--f-mono);font-size:11.5px;color:#d9c49c;white-space:nowrap}
.mx-sk.no small{color:#f09a86}
.mx-hero{display:flex;gap:8px;align-items:flex-start;min-width:0;text-align:left;background:none;border:0;padding:0}
.mx-hero .por{flex:0 0 auto;border-radius:8px;overflow:hidden;border:1px solid rgba(220,175,110,.4)}
.mx-hero .tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}
.mx-hero .tx b{font-size:14px;font-weight:600;color:#fbefd8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-hero .tx i{font-style:normal;font-size:12px;color:#d4c3a2}
.mx-bar{position:relative;height:13px;border-radius:3px;background:#3a2219;overflow:hidden}
.mx-bar i{position:absolute;inset:0 auto 0 0;background:linear-gradient(#d14a3b,#9d2d22);transition:width .25s}
.mx-bar.s{background:#251d33}.mx-bar.s i{background:linear-gradient(#a27ae0,#6f4ea8)}
.mx-bar.s em{position:absolute;left:50%;top:0;bottom:0;width:1px;background:rgba(255,255,255,.5)}
.mx-bar b{position:absolute;right:4px;top:0;font-family:var(--f-mono);font-size:11px;line-height:13px;font-weight:700;color:#fff;text-shadow:0 0 2px #000,0 0 2px #000}
.mx-bar u{position:absolute;left:4px;top:0;text-decoration:none;font-size:11px;line-height:13px;font-weight:600;color:#fff;text-shadow:0 0 2px #000}
.mx-tags{display:flex;gap:3px;flex-wrap:wrap;align-items:center;min-height:18px}
.mx-tag{font-size:12px;padding:0 6px;border-radius:4px;line-height:18px;background:#3a2c1f;color:#f3e2c0;display:inline-flex;align-items:center;gap:2px}
.mx-tag.af{background:#6e231c;color:#ffd9cf}.mx-tag.vi{background:#6a5016;color:#fff0bf}.mx-tag.dd{background:#3d0d0d;color:#ffaa9a;border:1px solid #b43c30}
.mx-party{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.mx-mini{display:grid;grid-template-columns:34px 1fr;gap:1px 6px;align-items:center;min-height:48px;padding:3px 6px 3px 3px;border-radius:8px;background:#1c1510;border:1px solid rgba(220,175,110,.22);text-align:left;min-width:0;position:relative}
.mx-mini .por{grid-row:1/3;border-radius:6px;overflow:hidden}
.mx-mini b{font-size:12.5px;font-weight:600;color:#fbefd8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-mini .mx-bar{height:11px}.mx-mini .mx-bar b{line-height:11px;font-size:10.5px}
.mx-mini.af{border-color:#b9473a}.mx-mini.dd{border-color:#e05a48;background:#2a1210}
.mx-mini .own{position:absolute;right:4px;top:4px;width:8px;height:8px;border-radius:50%}
.mx-info{font-size:13px;color:#e2d3b6;line-height:1.4}
.mx-info b{color:#fff1d6;font-weight:600}
.mx-desc{font-size:12.5px;color:#e2d3b6;line-height:1.35;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.mx-desc b{color:#ffe2a8}
.mx-tgs{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.mx-tgs .mx-b{justify-content:space-between;font-size:12.5px;padding:3px 7px}
.mx-tgs .mx-b span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-tgs .mx-b em{font-style:normal;font-family:var(--f-mono);font-size:12.5px;font-weight:700;color:#ffd894;flex:0 0 auto}
.mx-log{font-size:12px;line-height:1.45;color:#cdbd9f;overflow:hidden}
.mx-log div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-wait{font-size:13.5px;color:#e2d3b6;text-align:center;padding:10px 6px;font-style:italic}
.mx-mm{position:relative;flex:1 1 auto;min-height:56px;border-radius:9px;background:#100c09;border:1px solid rgba(220,175,110,.25);overflow:hidden;padding:0;cursor:pointer}
.mx-mm canvas{position:absolute;inset:0;width:100%;height:100%}
.mx-mm span{position:absolute;right:5px;bottom:3px;font-size:12px;color:#e6d4b0;background:rgba(10,8,6,.75);padding:0 5px;border-radius:4px}
.mx-route{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.mx-route .mx-b{justify-content:flex-start;text-align:left;font-size:13px}
.mx-route .mx-b small{display:block;font-size:12px;color:#d4c3a2}
.mx-nar{position:absolute;z-index:4;pointer-events:none;font-family:'Noto Serif KR','Nanum Myeongjo',serif;font-style:italic;font-size:14px;line-height:1.45;color:#f3e8d2;text-shadow:0 1px 3px #000,0 0 10px #000,0 0 4px #000;text-align:center;transition:opacity .8s;opacity:0;padding:0 18px;box-sizing:border-box}
.mx-toasts{position:absolute;z-index:6;pointer-events:none;display:flex;flex-direction:column;align-items:center;gap:4px}
.mx-toast{max-width:92%;font-size:13px;line-height:1.3;padding:5px 12px;border-radius:999px;background:rgba(16,12,9,.82);border:1px solid rgba(220,175,110,.38);color:#f6ead2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;animation:mxin .18s ease-out;transition:opacity .3s}
@keyframes mxin{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
.mx-ov{position:absolute;inset:0;z-index:20;background:rgba(10,8,7,.97);display:flex;flex-direction:column;overflow:hidden}
.mx-ov .hd{display:flex;align-items:center;gap:10px;padding:6px 64px 6px 14px;border-bottom:1px solid rgba(220,175,110,.25);min-height:46px;box-sizing:border-box;flex:0 0 auto}
.mx-ov .hd b{font-family:var(--f-display);font-weight:400;font-size:19px;color:#f6e7c8}
.mx-ov .hd span{font-size:13px;color:#dccaa6}
.mx-ov .bd{flex:1;overflow:auto;padding:8px 12px 12px;display:flex;flex-direction:column;gap:8px;-webkit-overflow-scrolling:touch;min-height:0}
.mx-ov .bd>*{flex-shrink:0}
.mx-ov .ft{display:flex;gap:8px;padding:7px 12px;border-top:1px solid rgba(220,175,110,.25);flex:0 0 auto}
.mx-ov .ft .mx-b{flex:1}
.mx-sec{font-size:12.5px;font-weight:600;color:#e8c98c;letter-spacing:.04em;margin-top:2px}
.mx-li{display:flex;align-items:center;gap:9px;padding:5px 8px;border-radius:9px;background:#1b1410;border:1px solid rgba(220,175,110,.2);min-height:48px;box-sizing:border-box;text-align:left;width:100%}
.mx-li.on{border-color:#f0b862;background:#2b1e12;box-shadow:0 0 0 1px #f0b862 inset}
.mx-li:disabled{opacity:.5}
.mx-li .tx{flex:1;min-width:0}
.mx-li .tx b{display:block;font-size:14px;font-weight:600;color:#fbefd8}
.mx-li .tx span{display:block;font-size:12.5px;color:#d9c8a8;line-height:1.4}
.mx-chip{display:inline-block;font-size:12px;padding:0 6px;border-radius:4px;margin:1px 3px 0 0;line-height:18px}
.mx-chip.p{background:#2f3b20;color:#dcf0bc}.mx-chip.n{background:#4a221d;color:#ffd0c5}.mx-chip.r{background:#2f2840;color:#e4d6f6}
.mx-qty{display:flex;align-items:center;gap:4px;flex:0 0 auto}
.mx-qty button{width:44px;height:44px;border-radius:9px;border:1px solid rgba(220,175,110,.35);background:#241a13;font-size:20px}
.mx-qty button:disabled{opacity:.35}
.mx-qty b{font-family:var(--f-mono);font-size:15px;min-width:26px;text-align:center}
.mx-steps{display:flex;gap:6px}
.mx-steps .mx-b{flex:1}
.mx-grid{display:grid;gap:7px}
.mx-cand{display:flex;flex-direction:column;align-items:stretch;gap:3px;padding:6px;border-radius:10px;background:#1b1410;border:1px solid rgba(220,175,110,.22);text-align:left;min-width:0;position:relative;min-height:96px}
.mx-cand.on{border-color:#f0b862;background:#2b1e12;box-shadow:0 0 0 1px #f0b862 inset}
.mx-cand .top{display:flex;gap:7px;align-items:center}
.mx-cand .top .por{border-radius:6px;overflow:hidden;flex:0 0 auto}
.mx-cand b{font-size:13.5px;font-weight:600;color:#fbefd8;line-height:1.2}
.mx-cand .r{font-size:12px;color:#dccaa6}
.mx-cand .no{position:absolute;right:6px;top:5px;font-family:var(--f-display);font-size:20px;color:#ffd27a}
.mx-slotrow{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}
.mx-slot{border-radius:10px;border:1px dashed rgba(220,175,110,.4);min-height:70px;display:flex;align-items:center;gap:6px;padding:4px 6px;font-size:13px;color:#d4c3a2;background:#130e0b;box-sizing:border-box;min-width:0;position:relative}
.mx-slot.full{border-style:solid;background:#1d150f;color:#f6ead2}
.mx-slot .nm{flex:1;min-width:0;line-height:1.25;overflow:hidden}
.mx-slot .nm b{font-size:13px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-slot .nm span{font-size:12px;color:#d4c3a2}
.mx-slot .ctl{display:flex;flex-direction:column;gap:3px;flex:0 0 auto}
.mx-slot .ctl button{min-width:44px;min-height:30px;border-radius:7px;border:1px solid rgba(220,175,110,.3);background:#2a1f16;font-size:12.5px;padding:0 6px}
.mx-slot .n{font-family:var(--f-display);font-size:22px;color:#ffd27a;flex:0 0 auto;width:18px;text-align:center}
.mx-tabs{display:flex;gap:6px}
.mx-tabs .mx-b{flex:1}
.mx-vt{display:flex;flex-direction:column;gap:6px;flex:0 0 132px}
.mx-split{display:flex;gap:10px;min-height:0;flex:1}
.mx-split>.mx-list{flex:1;min-width:0;overflow:auto;display:flex;flex-direction:column;gap:6px}
.mx-split>.mx-list>*{flex-shrink:0}
.mx-stat{display:grid;grid-template-columns:repeat(3,1fr);gap:4px 10px;font-size:13px;color:#e2d3b6}
.mx-stat b{font-family:var(--f-mono);color:#fff1d6;font-weight:700}
.mx-pips{display:flex;gap:3px}.mx-pips i{width:16px;height:10px;border-radius:2px;background:#3a2c20}.mx-pips i.on{background:#ffc76a}
.mx-campp{position:absolute;z-index:4;display:flex;flex-direction:column;gap:4px;padding:6px;box-sizing:border-box;background:rgba(14,10,8,.9);border:1px solid rgba(220,175,110,.3);border-radius:12px;overflow:auto}
.mx-camprow{display:flex;gap:5px;align-items:stretch}
.mx-camprow .who{flex:0 0 58px;display:flex;flex-direction:column;justify-content:center;line-height:1.2;min-width:0}
.mx-camprow .who b{font-size:12.5px;color:#fbefd8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-camprow .who span{font-size:12px;color:#d3b7f0}
.mx-camprow .mx-b{flex:1 1 0;flex-direction:column;gap:0;padding:1px 2px;font-size:12px;min-height:44px}
.mx-camprow .mx-b span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.mx-camprow .mx-b small{font-size:11.5px;color:#e0c890}
.mx-camprow .mx-b.used{opacity:.35}
.cmp .mx-sk{min-height:56px;padding:2px}.cmp .mx-sk svg{width:22px;height:22px}.cmp .mx-sk span{font-size:12px}
.cmp .mx-dock .mx-b{padding:3px 4px;font-size:13px}.cmp .mx-dock{gap:6px;padding:6px}
.mx-ctab{display:flex;gap:4px}.mx-ctab .mx-b{flex:1 1 0;flex-direction:column;gap:0;font-size:12.5px;padding:2px}
.mx-ctab .mx-b small{font-size:11.5px;color:#d3b7f0}
.mx-csk{display:flex;flex-direction:column;gap:4px}
.mx-csk .mx-b{justify-content:flex-start;text-align:left;gap:8px;min-height:44px}
.mx-csk .mx-b .tx{flex:1;min-width:0;display:flex;flex-direction:column}
.mx-csk .mx-b b{font-size:13px;font-weight:600;color:#fbefd8}
.mx-csk .mx-b span{font-size:12px;color:#dccaa6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx-csk .mx-b em{font-style:normal;font-family:var(--f-mono);font-size:12.5px;font-weight:700;color:#ffd894;flex:0 0 auto}
@media (prefers-reduced-motion:reduce){.mx-toast{animation:none}}
`;
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'mx' });
    const cv = h('canvas', { class: 'mx-cv' });
    const top = h('div', { class: 'mx-top' });
    const dock = h('div', { class: 'mx-dock' });
    const dl = h('div', { class: 'mx-col' }), dc = h('div', { class: 'mx-col' }), dr = h('div', { class: 'mx-col' });
    dock.append(dl, dc, dr);
    const narEl = h('div', { class: 'mx-nar' });
    const toasts = h('div', { class: 'mx-toasts' });
    wrap.append(style, cv, top, dock, narEl, toasts);
    root.append(wrap);
    const ctx = cv.getContext('2d');

    /* ---------- 상태 ---------- */
    let S = null, lastId = -1;
    let campHero = 0;
    let sel = -1, campSel = null, wayTab = 'shop', ov = null, campPanel = null, prepD = null;
    let busy = false, q = [], wait = 0, skipAll = false;
    let nowT = 0, slow = 0;          // slow: 치명타 때 잠깐 느려짐
    const D = {};                    // uid → 표시용 인물
    let active = 0, shownLight = 100;
    const pops = [], parts = [], projs = [], fxs = [];
    let banner = null, label = null, fade = null;
    let camX = 0, camTo = 0, walking = false, roomProp = null;
    let shake = 0, zoom = 1, zoomTo = 1, zfx = 0, zfy = 0;
    let G = { W: 820, H: 400, land: true, sw: 820, sh: 270 };
    let dpr = 1;

    /* ---------- 소리(합성) ---------- */
    const Snd = {
      ac: null,
      vol() { try { return L.audio && L.audio.sfx ? L.audio.sfx() : 0.6; } catch (e) { return 0.6; } },
      ctx() { if (this.ac) return this.ac; try { const A = window.AudioContext || window.webkitAudioContext; this.ac = A ? new A() : null; } catch (e) { this.ac = null; } return this.ac; },
      noise(dur, f0, f1, gain, type) {
        const ac = this.ctx(), v = this.vol(); if (!ac || v <= 0) return;
        try {
          if (ac.state === 'suspended') ac.resume();
          const n = Math.floor(ac.sampleRate * dur), buf = ac.createBuffer(1, n, ac.sampleRate), d = buf.getChannelData(0);
          for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
          const src = ac.createBufferSource(); src.buffer = buf;
          const fl = ac.createBiquadFilter(); fl.type = type || 'bandpass'; fl.Q.value = 1.2;
          fl.frequency.setValueAtTime(f0, ac.currentTime); fl.frequency.exponentialRampToValueAtTime(Math.max(40, f1), ac.currentTime + dur);
          const g = ac.createGain(); g.gain.value = gain * v;
          src.connect(fl); fl.connect(g); g.connect(ac.destination); src.start();
        } catch (e) {}
      },
      tone(f0, f1, dur, gain, type, delay) {
        const ac = this.ctx(), v = this.vol(); if (!ac || v <= 0) return;
        try {
          const t0 = ac.currentTime + (delay || 0);
          const o = ac.createOscillator(); o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
          const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(gain * v, t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
          o.connect(g); g.connect(ac.destination); o.start(t0); o.stop(t0 + dur + 0.05);
        } catch (e) {}
      },
      slash() { this.noise(0.16, 3200, 700, 0.35); },
      hit() { this.noise(0.1, 900, 200, 0.45, 'lowpass'); this.tone(150, 70, 0.12, 0.25); },
      crit() { this.noise(0.28, 1600, 120, 0.6, 'lowpass'); this.tone(90, 38, 0.45, 0.5); },
      twang() { this.tone(520, 180, 0.12, 0.12, 'triangle'); this.noise(0.08, 2400, 1200, 0.15); },
      chime() { this.tone(880, 860, 0.5, 0.12, 'sine'); this.tone(1320, 1300, 0.6, 0.07, 'sine', 0.06); },
      dark() { this.tone(110, 55, 0.9, 0.18, 'sawtooth'); this.tone(116, 58, 0.9, 0.12, 'sawtooth'); },
      beat() { this.tone(60, 40, 0.16, 0.5); this.tone(58, 40, 0.18, 0.4, 'sine', 0.22); },
      step() { this.noise(0.06, 500, 200, 0.12, 'lowpass'); },
      torch() { this.noise(0.5, 500, 1800, 0.22); },
      miss() { this.noise(0.12, 1800, 3600, 0.12, 'highpass'); },
      boss() { this.tone(70, 35, 1.6, 0.45, 'sawtooth'); this.noise(1.2, 300, 60, 0.35, 'lowpass'); },
    };
    const SND = (n, o) => { try { api.sfx(n, o); } catch (e) {} };
    const buzz = (ms) => { try { api.buzz(ms); } catch (e) {} };

    /* ---------- 배치 ---------- */
    function layout() {
      const r = wrap.getBoundingClientRect();
      const W = Math.max(300, Math.round(r.width)), H = Math.max(300, Math.round(r.height));
      const land = W >= H * 1.15;
      let sh, dockR, cols;
      if (land) {
        const dh = Math.round(Math.max(126, Math.min(176, H * 0.33)));
        sh = H - dh; dockR = [0, sh, W, dh];
        const side = Math.round(Math.max(160, Math.min(340, W * 0.26)));
        cols = side + 'px minmax(0,1fr) ' + side + 'px';
        dock.style.gridTemplateRows = '';
      } else {
        sh = Math.round(Math.max(220, Math.min(H * 0.42, W * 0.82)));
        dockR = [0, sh, W, H - sh];
        cols = 'minmax(0,1fr)';
        dock.style.gridTemplateRows = 'auto auto minmax(0,1fr)';
      }
      G = { W, H, land, sw: W, sh };
      wrap.classList.toggle('cmp', land ? H < 440 || W < 760 : W < 380);
      Object.assign(dock.style, { left: dockR[0] + 'px', top: dockR[1] + 'px', width: dockR[2] + 'px', height: dockR[3] + 'px', gridTemplateColumns: cols });
      dl.style.order = land ? 0 : 1; dc.style.order = land ? 1 : 0; dr.style.order = 2;
      top.style.width = W + 'px';
      Object.assign(narEl.style, { left: '0px', width: W + 'px', top: '84px' });
      Object.assign(toasts.style, { left: '0px', width: W + 'px', top: '112px' });
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = Math.round(W * dpr); cv.height = Math.round(sh * dpr);
      cv.style.width = W + 'px'; cv.style.height = sh + 'px';
      for (const k in D) D[k].x = D[k].tx = slotX(D[k]);
      if (S) { renderDock(); if (campPanel) renderCamp(); }
    }
    const ro = new ResizeObserver(() => layout());
    ro.observe(wrap);

    /* ---------- 장면 좌표 ---------- */
    function geo() {
      const { sw, sh } = G;
      const fh = Math.min(sh * 0.5, sw * 0.135, 230);
      const step = fh * 0.6;
      return { fh, step, gy: sh * 0.86, cx: sw * 0.5, gap: step * 0.32 };
    }
    const isBoss = (d) => d.en && EI[d.en] && EI[d.en].boss;
    const wOf = (d) => (isBoss(d) ? 1.75 : 1);
    function phOf() { return S ? S.ph : 'prep'; }
    const campX = () => (G.land ? Math.max(geo().step * 2.6, G.sw * 0.22) : G.sw * 0.5);
    function slotX(d) {
      const g = geo(), ph = phOf();
      if (d.side === 'h') {
        if (ph === 'fight' || (ph === 'end' && S && S.fi)) return g.cx - g.gap - g.step * (d.rank + 0.5);
        if (ph === 'camp') return campX() + [-1.05, 1.05, -2.1, 2.1][d.rank % 4] * g.step;
        return G.sw * (G.land ? 0.44 : 0.5) + g.step * 1.4 - g.step * 0.95 * (d.rank + 0.5);
      }
      let acc = 0;
      const list = Object.values(D).filter((x) => x.side === 'e' && !x.dead).sort((a, b) => a.rank - b.rank);
      for (const x of list) { if (x === d) break; acc += wOf(x); }
      return g.cx + g.gap + g.step * (acc + wOf(d) / 2);
    }
    function mkD(u, side, spec, rank) {
      const d = { u, side, spec, rank, hp: 0, mh: 1, st: 0, alpha: 0, ta: 1, flash: 0, dead: 0, seed: Math.random() * 9, anim: null, off: 0, offTo: 0 };
      d.x = d.tx = slotX(d);
      D[u] = d; return d;
    }
    function syncAll(s) {
      const keep = {};
      s.pt.forEach((hh, i) => {
        keep[hh.u] = 1;
        let d = D[hh.u];
        if (!d) { d = mkD(hh.u, 'h', heroSpec(hh), i); d.alpha = 1; }
        d.rank = i; d.hp = hh.hp; d.mh = hStats(s, hh).mh; d.st = hh.st; d.ta = 1; d.dead = 0; d.hh = hh;
      });
      if (s.fi && s.ph === 'fight') s.fi.en.forEach((e, i) => {
        keep[e.u] = 1;
        let d = D[e.u];
        if (!d) { d = mkD(e.u, 'e', enSpec(e.e), i); d.alpha = 1; }
        d.en = e.e; d.rank = i; d.hp = e.hp; d.mh = e.mh; d.ta = 1; d.dead = 0;
      });
      for (const k in D) if (!keep[k]) delete D[k];
      for (const k in D) D[k].tx = slotX(D[k]);
    }

    /* ---------- 알림 · 서술 ---------- */
    function toast(t, ms) {
      const el = h('div', { class: 'mx-toast', text: t });
      toasts.append(el);
      while (toasts.children.length > 2) toasts.firstChild.remove();
      setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 320); }, Math.min(1600, ms || 1500));
    }
    let narTimer = 0, narShown = '';
    function showNar(t) {
      if (!t || t === narShown) return;
      narShown = t; narEl.textContent = t; narEl.style.opacity = '1';
      clearTimeout(narTimer); narTimer = setTimeout(() => { narEl.style.opacity = '0'; }, 4600);
    }
    wrap.addEventListener('pointerdown', () => { for (const el of [...toasts.children]) el.remove(); narEl.style.opacity = '0'; if (banner && !busy) banner = null; }, true);

    /* ---------- 장면 효과 ---------- */
    const headY = (d) => geo().gy - geo().fh * (d.spec.k || 1) * (isBoss(d) ? 1.3 : 1) * (d.anim && d.anim.k === 'down' ? 0.7 : 1);
    function pop(u, text, color, size, sub) {
      const d = D[u];
      const x = d ? d.x : G.sw / 2, y = d ? headY(d) - 6 : G.sh * 0.4;
      const n = pops.filter((p) => p.u === u && p.t < 0.35).length;
      pops.push({ u, x: x + (n % 2 ? 10 : -4), y: y - n * 16, text, sub, color: color || '#f6ead2', size: size || 15, t: 0, life: 1.1 });
    }
    function burst(x, y, n, o) {
      for (let i = 0; i < n * fxAmt(); i++) {
        const a = (o.a != null ? o.a : -Math.PI / 2) + (Math.random() - 0.5) * (o.spread || Math.PI * 2), v = (o.v || 80) * (0.4 + Math.random() * 0.8);
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: o.g != null ? o.g : 160, t: 0, life: (o.life || 0.6) * (0.6 + Math.random() * 0.6), c: o.c || '#d8b78a', sz: (o.sz || 2.2) * (0.6 + Math.random() * 0.8), add: !!o.add, sq: o.sq });
      }
    }
    function anim(d, k, dur) { if (d) d.anim = { k, t: 0, dur: dur || 0.5 }; }
    const nameOf = (u) => { const hh = S && S.pt.find((x) => x.u === u); if (hh) return heroName(hh); const d = D[u]; return d && d.en ? EI[d.en].n : ''; };
    function peekTarget(actorU) {
      for (const e of q) { if (e.k === 'act' || e.k === 'turn') break; if ((e.k === 'hit' || e.k === 'miss' || e.k === 'heal' || e.k === 'fx' || e.k === 'st' || e.k === 'resist') && e.u !== actorU && D[e.u]) return D[e.u]; }
      return null;
    }
    function actKind(d, e) {
      if (!d) return { k: 'none' };
      if (d.side === 'h') {
        const hh = S && S.pt.find((x) => x.u === d.u) || d.hh;
        const C = hh ? CL[hh.c] : null;
        const Sk = C && C.sk.find((x) => x.n === e.n);
        if (e.n === '반격' || e.n === '제멋대로') return { k: 'atk', melee: 1 };
        if (!Sk) return { k: 'none' };
        if (Sk.t !== 'e') return { k: 'cast', ally: 1 };
        const wk = { sword: 'm', axe: 'm', mace: 'm', club: 'm', dagger: 'm', chain: 'm', spear: 'm', crossbow: 's', bow: 's', flask: 't', bomb: 't' }[d.spec.w] || 'c';
        if (wk === 'm') return { k: 'atk', melee: 1 };
        if (wk === 's') return { k: 'shoot', proj: 'bolt' };
        if (wk === 't') return { k: 'throw', proj: d.spec.w === 'bomb' ? 'bomb' : 'flask' };
        return { k: 'cast', proj: 'orb' };
      }
      const E = EI[d.en]; const Sk = E && E.sk.find((x) => x.n === e.n);
      if (Sk && (Sk.t === 'a' || Sk.t === 's' || Sk.sum)) return { k: 'cast', ally: 1 };
      if (d.spec.w === 'crossbow' || d.spec.w === 'bow') return { k: 'shoot', proj: 'bolt' };
      if (Sk && !Sk.dm && Sk.st) return { k: 'cast', proj: 'dread' };
      if (Sk && Sk.f && !/[12]/.test(Sk.f) && Sk.dm) return { k: 'cast', proj: 'orb' };
      return { k: 'atk', melee: 1 };
    }

    /* ---------- 사건 재생 ---------- */
    function handle(e) {
      const d = e.u != null ? D[e.u] : null;
      const g = geo();
      switch (e.k) {
        case 'fight': {
          e.e.forEach((x, i) => { const dd = mkD(x.u, 'e', enSpec(x.e), i); dd.en = x.e; dd.hp = x.hp; dd.mh = x.mh; dd.alpha = 0; dd.x = G.sw + 80 + i * 40; });
          for (const k in D) if (D[k].side === 'h') D[k].tx = slotX(D[k]);
          for (const k in D) if (D[k].side === 'e') D[k].tx = slotX(D[k]);
          walking = false; roomProp = null;
          if (e.boss) { const b = e.e.find((x) => EI[x.e].boss); banner = { title: b ? EI[b.e].n : '우두머리', sub: '우두머리', c: '#ff9c86', t: 0, life: 2.2 }; Snd.boss(); shake = Math.max(shake, 0.9); return 1500; }
          SND('go', { vol: 0.5 }); Snd.noise(0.4, 300, 900, 0.18);
          return 650;
        }
        case 'sum': { const dd = mkD(e.e.u, 'e', enSpec(e.e.e), 3); dd.en = e.e.e; dd.hp = e.e.hp; dd.mh = e.e.mh; dd.alpha = 0; dd.x = G.sw + 60; toast(EI[e.e.e].n + ' 나타남'); return 420; }
        case 'surp': toast(e.who === 'h' ? '기습당함 · 대열이 흐트러짐' : '적의 허를 찌름 · 먼저 움직임'); if (e.who === 'h') { shake = 0.6; Snd.dark(); } return 650;
        case 'pos': {
          (e.h || []).forEach((u, i) => { if (D[u]) D[u].rank = i; });
          (e.e || []).forEach((u, i) => { if (D[u]) D[u].rank = i; });
          for (const k in D) D[k].tx = slotX(D[k]);
          refreshHero(); return e.mv ? 300 : 120;
        }
        case 'turn': active = e.u; refreshHero(); return d && d.side === 'h' ? 80 : 110;
        case 'act': {
          active = e.u;
          const ak = actKind(d, e);
          label = { text: (e.wild ? '제멋대로 · ' : '') + e.n, t: 0, side: d ? d.side : 'h', u: e.u, ic: e.ic };
          if (!d || ak.k === 'none') { if (e.n === '자리 바꾸기' || e.n === '후퇴') Snd.step(); return 360; }
          const tg = peekTarget(e.u);
          if (ak.k === 'atk') {
            anim(d, 'atk', 0.62);
            if (tg && tg.side !== d.side) d.offTo = (tg.x - d.x) * 0.55 - Math.sign(tg.x - d.x) * g.step * 0.55;
            else d.offTo = (d.side === 'h' ? 1 : -1) * g.step * 0.35;
            Snd.slash(); return 300;
          }
          if (ak.k === 'shoot' || ak.k === 'throw' || (ak.k === 'cast' && ak.proj)) {
            anim(d, ak.k, 0.6);
            if (tg) setTimeout(() => {}, 0);
            if (tg && tg.side !== d.side) projs.push({ k: ak.proj, x0: d.x + (d.side === 'h' ? 1 : -1) * g.step * 0.3, y0: g.gy - g.fh * 0.62 * (d.spec.k || 1), x1: tg.x, y1: g.gy - g.fh * 0.5 * (tg.spec.k || 1), t: -0.14, dur: ak.proj === 'bolt' ? 0.16 : 0.28 });
            if (ak.k === 'shoot') Snd.twang(); else if (ak.proj === 'dread') Snd.dark(); else Snd.noise(0.25, 600, 1800, 0.15);
            return 440;
          }
          anim(d, 'cast', 0.7);
          burst(d.x, g.gy - g.fh * 0.7, 10, { c: d.side === 'h' ? '#ffe2a0' : '#c9a0f0', v: 40, g: -30, life: 0.8, add: true, sz: 2 });
          Snd.chime(); return 420;
        }
        case 'hit': {
          if (d) {
            d.hp = e.hp; d.flash = 1; if (!(d.hh && d.hh.dd)) anim(d, 'hit', 0.45);
            const hx = d.x, hy = g.gy - g.fh * 0.55 * (d.spec.k || 1);
            if (!e.self) fxs.push({ k: 'slash', x: hx, y: hy, t: 0, life: 0.28, dir: d.side === 'h' ? -1 : 1, cr: e.cr });
            burst(hx, hy, e.cr ? 18 : 9, { c: d.spec.en && (d.spec.b === 'bones' || d.spec.b === 'head') ? '#cfc3a8' : '#8d1d17', v: e.cr ? 170 : 110, a: d.side === 'h' ? Math.PI : 0, spread: 1.8, life: 0.55, sz: 2.4 });
          }
          pop(e.u, '−' + e.d, e.cr ? '#ffb070' : d && d.side === 'h' ? '#ff9a8a' : '#fff0d6', e.cr ? 22 : 17, e.cr ? '치명타' : null);
          if (e.cr) { slow = 0.16; shake = 1; zoomTo = 1.07; if (d) { zfx = d.x; zfy = g.gy - g.fh * 0.5; } Snd.crit(); }
          else { shake = Math.max(shake, e.self ? 0.2 : 0.45); if (!e.self) Snd.hit(); }
          if (d && d.side === 'h' && !e.self) buzz(e.cr ? 35 : 15);
          refreshHero(); return e.cr ? 560 : 340;
        }
        case 'miss': pop(e.u, '빗나감', '#d6cbb6', 14); if (d) { d.off = (d.side === 'h' ? -1 : 1) * 12; } Snd.miss(); return 260;
        case 'resist': pop(e.u, '저항', '#cdd6dc', 14); return 180;
        case 'heal': if (d) { d.hp = e.hp; if (e.v > 0) burst(d.x, g.gy - 10, 14, { c: '#bfe8a0', v: 50, g: -60, life: 0.9, add: true, sz: 2 }); } if (e.v > 0) { pop(e.u, '+' + e.v, '#a8f0a0', 17); Snd.chime(); } refreshHero(); return 280;
        case 'hp': if (d) d.hp = e.hp; refreshHero(); return 0;
        case 'st': if (d) { d.st = e.s; if (e.v > 0) burst(d.x, g.gy - g.fh * 0.8, 8, { c: '#b88cf0', v: 30, g: -40, life: 0.9, add: true, sz: 2.5 }); } pop(e.u, (e.v > 0 ? '스트레스 +' : '스트레스 −') + Math.abs(e.v), e.v > 0 ? '#d9b4ff' : '#e6e0f6', 13); refreshHero(); return e.v > 0 ? 150 : 90;
        case 'fx': pop(e.u, e.f === 'bf' || e.f === 'db' ? (e.s === 'res' ? '저항 +' + e.v + '%' : fmtMod(e.s, e.v)) : FXN[e.f], e.f === 'bl' ? '#ff9a8a' : e.f === 'bg' ? '#c8e88a' : e.f === 'stun' ? '#ffe78a' : e.f === 'db' ? '#f0b0a8' : '#efdcb0', 13); if (e.f === 'pu' || e.f === 'pl') Snd.step(); refreshHero(); return 150;
        case 'cure': pop(e.u, '치료', '#a8f0a0', 13); refreshHero(); return 130;
        case 'dot': pop(e.u, '−' + e.d, e.f === 'bg' ? '#c8e88a' : '#ff9a8a', 15); if (d) d.flash = 0.6; return 240;
        case 'stunned': pop(e.u, '기절 · 쉼', '#ffe78a', 14); refreshHero(); return 400;
        case 'die': {
          if (d) {
            d.ta = 0; d.dead = 1; anim(d, 'down', 0.9);
            burst(d.x, g.gy - g.fh * 0.4, 26, { c: '#1a1210', v: 60, g: -25, life: 1.2, sz: 5, spread: Math.PI * 2 });
            if (d.side === 'e') { for (const k in D) if (D[k].side === 'e' && !D[k].dead) D[k].tx = slotX(D[k]); }
          }
          Snd.noise(0.5, 400, 80, 0.3, 'lowpass');
          if (e.hero) { banner = { title: nameOf(e.u), sub: '사망', c: '#ff8e7a', t: 0, life: 1.6 }; buzz(60); Snd.dark(); }
          refreshHero(); return e.hero ? 1100 : 520;
        }
        case 'dd': pop(e.u, '죽음의 문턱', '#ff7a6a', 16); if (d) anim(d, 'hit', 0.45); Snd.beat(); refreshHero(); return 520;
        case 'ddok': pop(e.u, '버텨 냄', '#ffd890', 14); return 340;
        case 'heart': pop(e.u, '심장 발작', '#ff7a6a', 18); Snd.beat(); shake = 0.7; return 760;
        case 'res': {
          if (d) d.st = e.s;
          const A = e.af ? AF[e.af] : VI[e.vi];
          banner = { title: (e.af ? '붕괴 · ' : '각성 · ') + A.n, sub: nameOf(e.u), c: e.af ? '#ff9a86' : '#ffd98a', t: 0, life: 2.0, u: e.u };
          if (d) { zoomTo = 1.1; zfx = d.x; zfy = g.gy - g.fh * 0.6; burst(d.x, g.gy - g.fh * 0.7, 30, { c: e.af ? '#a1302a' : '#ffd98a', v: 70, g: -20, life: 1.3, add: !e.af, sz: 3 }); }
          if (e.say) say(e.u, e.say, !!e.af);
          if (e.af) { Snd.dark(); Snd.beat(); } else Snd.chime();
          refreshHero(); return 1700;
        }
        case 'calm': pop(e.u, '정신을 추스름', '#e6e0f6', 14); refreshHero(); return 440;
        case 'say': say(e.u, e.t, e.bad); return e.bad ? 560 : 400;
        case 'refuse': pop(e.u, '명령 거부', '#ff9a86', 16); Snd.dark(); return 560;
        case 'refh': pop(e.u, '치유 거부', '#ff9a86', 14); return 380;
        case 'pass': pop(e.u, '버팀', '#d6cbb6', 13); return 220;
        case 'guard': pop(e.u, '호위', '#efdcb0', 14); return 220;
        case 'win': {
          const l = e.loot, parts2 = ['금화 +' + l.gold];
          if (l.stole) parts2.push('빼돌림 ' + l.stole);
          for (const id of l.trk) parts2.push(TI[id].n);
          for (const k in l.items) parts2.push(PV[k].n + ' +' + l.items[k]);
          toast((e.boss ? '우두머리 처치 · ' : '승리 · ') + parts2.join(' · '));
          if (e.boss) banner = { title: '우두머리 처치', sub: '', c: '#ffd98a', t: 0, life: 1.8 };
          SND('chip'); return e.boss ? 1300 : 800;
        }
        case 'flee': toast(e.who === 'h' ? '후퇴' : '적이 물러남'); if (e.who === 'h') { for (const k in D) if (D[k].side === 'h') D[k].offTo = -G.sw * 0.2; } return 600;
        case 'fleefail': toast('후퇴 실패'); return 420;
        case 'lvl': pop(e.u, e.lv + '단계', '#ffd890', 15); SND('win', { vol: 0.4 }); return 300;
        case 'qk': { const Q2 = QI[e.q]; pop(e.u, '기질 · ' + Q2.n, e.p ? '#d8f0b8' : '#ffc8bc', 13); toast(nameOf(e.u) + ' · 기질 「' + Q2.n + '」'); return 440; }
        case 'walk': walking = true; roomProp = null; return 0;
        case 'seg': walking = true; camTo += geo().step * 3.2; Snd.step(); return 560;
        case 'room': walking = false; roomProp = { k: e.rk, x: camTo + G.sw * 0.82 }; return 200;
        case 'scout': toast('정찰 · 주변이 드러남'); return 280;
        case 'trap': toast(e.ok ? '함정 「' + e.n + '」 피함' : '함정 「' + e.n + '」 · ' + e.d); if (!e.ok) { shake = 0.6; Snd.hit(); } return 600;
        case 'obs': toast(e.ok ? '잔해 · 삽으로 치움' : '잔해 · 손으로 치우다 다침'); Snd.noise(0.3, 400, 150, 0.25, 'lowpass'); return 440;
        case 'hunger': toast(e.ok ? '허기 · 식량 ' + e.n : '허기 · 식량이 모자람'); return 440;
        case 'curio': walking = false; return 240;
        case 'cres': {
          const C = CI[e.id];
          if (e.leave) { toast(C.n + ' · 지나침'); return 280; }
          toast(C.n + ' · ' + (e.txt && e.txt.length ? e.txt.join(' · ') : '아무 일 없음'));
          if (e.good) Snd.chime(); else Snd.dark(); return 720;
        }
        case 'camp': fade = { t: 0, life: 0.9, txt: '야영' }; toast('야영 · 식사 ' + e.fed + '/' + e.n); return 700;
        case 'cskill': toast(nameOf(e.u) + ' · ' + e.n); Snd.chime(); return 380;
        case 'light': if (e.torch) { Snd.torch(); burst(lightPos().x, lightPos().y, 20, { c: '#ffc070', v: 60, g: -50, life: 0.8, add: true, sz: 2 }); } shownLight = e.l; updateTop(); return 180;
        case 'gold': return 120;
        case 'gain': return 80;
        case 'eat': pop(e.u, '몰래 먹음', '#ffc8bc', 14); return 340;
        case 'floor': walking = false; roomProp = null; fade = { t: 0, life: 1.4, txt: (e.fl + 1) + '층', sub: ZI[e.z].n }; return 1100;
        case 'way': fade = { t: 0, life: 1.0, txt: '역참', sub: '' }; return 600;
        case 'rec': return 200;
        case 'ambush': toast('야습'); Snd.dark(); shake = 0.6; return 560;
        default: return 60;
      }
    }
    const bubbles = [];
    function say(u, text, bad) { bubbles.push({ u, text, bad, t: 0, life: 2.4 }); while (bubbles.length > 2) bubbles.shift(); }
    function startPlay(evs) { q = evs.slice(); wait = 0; skipAll = false; setBusy(true); }
    function setBusy(v) { busy = v; try { api.setBusy(v); } catch (e) {} }
    function stepPlay(dt) {
      if (!busy) return;
      wait -= dt * 1000 * spd() * (L.debug && L.debug.speed >= 6 ? 2.5 : 1);
      let guard = 0;
      while (busy && (wait <= 0 || skipAll) && guard++ < 400) {
        const e = q.shift();
        if (!e) { finishPlay(); return; }
        const ms = handle(e);
        wait += skipAll ? 0 : ms;
      }
    }
    function finishPlay() {
      q = []; skipAll = false;
      syncAll(S);
      active = S.ph === 'fight' && S.fi ? S.fi.cur : 0;
      shownLight = S.light; walking = false;
      for (const k in D) D[k].offTo = 0;
      setBusy(false);
      renderAll();
    }

    /* ---------- 위 띠 ---------- */
    const BANDC = ['#ffe3a0', '#f2c77c', '#e0a560', '#c97a52', '#a86060'];
    function updateTop() {
      const s = S; if (!s) return;
      const light = shownLight, z = s.mp ? ZI[s.mp.z] : null, b = band(light);
      top.innerHTML = '';
      const title = s.ph === 'prep' ? '원정 준비' : s.ph === 'way' ? '역참' : (s.fl + 1) + '층 / ' + s.len;
      const sub = s.ph === 'prep' ? '' : s.ph === 'way' ? '다음: ' + ZI[s.zs[Math.floor(s.fl / ZLEN)]].n : z ? z.n + (s.ph === 'camp' ? ' · 야영' : '') + (s.mp && s.mp.boss ? ' · 우두머리 층' : '') : '';
      top.append(h('div', { class: 'fl' }, h('b', { text: title }), G.W >= 560 ? h('span', { text: sub }) : null));
      if (s.ph !== 'prep') {
        top.append(h('div', { class: 'mx-lt' }, h('span', { html: icoSVG('torch', 18, '#ffc76a') }), h('div', { class: 'bar' }, h('i', { style: { width: light + '%' } })), h('b', { text: String(light) }), G.W >= 560 ? h('em', { style: { color: BANDC[b] }, text: LB[b].n }) : null));
        top.append(h('div', { class: 'mx-res' },
          h('span', { title: '금화', html: icoSVG('coins', 16, '#ffd36a') + s.gold }),
          h('span', { title: '식량', html: icoSVG('bread', 16, '#e8cf98') + s.inv.food }),
          h('span', { title: '횃불', html: icoSVG('torch', 16, '#ffb860') + s.inv.torch })));
      }
    }

    /* ---------- 내가 할 수 있나 ---------- */
    const mine = () => { const s = S; if (!s || s.res) return false; const a = actor(s); return a != null && api.canAct(a) && !busy; };
    const act = (a) => { if (!mine()) return; sel = -1; campSel = null; try { api.act(a); } catch (e) { console.warn(e); } };
    function whoActs() { const a = actor(S); const p = api.players[a] || {}; return p.name || '원정대장'; }

    /* ---------- 아래 띠 ---------- */
    function renderAll() {
      if (!S) return;
      updateTop();
      renderDock();
      if (S.nar && S.nar !== narShown) showNar(S.nar);
      if (S.ph === 'camp' && !S.res) { if (!campPanel) openCampPanel(); else renderCamp(); } else closeCampPanel();
    }
    const fresh = (el) => { el.innerHTML = ''; return el; };
    function bars(hp, mh, st, compact) {
      return [
        h('div', { class: 'mx-bar' }, h('i', { style: { width: Math.max(0, Math.min(100, hp / mh * 100)) + '%' } }), compact ? null : h('u', { text: '체력' }), h('b', { text: Math.max(0, hp) + '/' + mh })),
        h('div', { class: 'mx-bar s' }, h('i', { style: { width: Math.min(100, st / 2) + '%' } }), h('em'), compact ? null : h('u', { text: '스트레스' }), h('b', { text: String(st) })),
      ];
    }
    function heroTags(hh, d) {
      const t = h('div', { class: 'mx-tags' });
      if (hh.dd || (d && d.hp <= 0)) t.append(h('span', { class: 'mx-tag dd', text: '죽음의 문턱' }));
      if (hh.af) t.append(h('span', { class: 'mx-tag af', text: '붕괴 · ' + AF[hh.af].n }));
      if (hh.vi) t.append(h('span', { class: 'mx-tag vi', text: '각성 · ' + VI[hh.vi].n }));
      const ks = {};
      for (const f of hh.fx) if (FXI[f.k] && f.k !== 'ddr') ks[f.k] = (ks[f.k] || 0) + 1;
      for (const k in ks) t.append(h('span', { class: 'mx-tag', title: FXN[k], html: icoSVG(FXI[k], 14, k === 'bl' ? '#ff9a8a' : k === 'bg' ? '#c8e88a' : k === 'db' ? '#f0b0a8' : '#efdcb0') + FXN[k] }));
      return t;
    }
    const porC = {};
    function por(spec, size, key, o) {
      const k = key + ':' + size;
      if (!porC[k]) porC[k] = portrait(spec, size, o);
      const c = porC[k].cloneNode(); c.getContext('2d').drawImage(porC[k], 0, 0); return c;
    }
    function heroPanel(hh, s) {
      const d = D[hh.u];
      const ps = G.land ? Math.min(58, Math.max(44, dock.clientHeight - 64)) : 48;
      const b = h('button', { class: 'mx-hero', onclick: () => openHero(s.pt.indexOf(hh)) },
        h('span', { class: 'por' }, por(heroSpec(hh), ps, 'h' + hh.c)),
        h('div', { class: 'tx' }, h('b', { text: EPI[hh.ep % EPI.length] + ' ' + CL[hh.c].s }), h('i', { text: CL[hh.c].n + ' · ' + hh.lv + '단계 · 자리\u00a0' + (s.pt.indexOf(hh) + 1) + (s.np > 1 ? ' · ' + ((api.players[hh.o] || {}).name || '') : '') }), ...bars(d ? d.hp : hh.hp, hStats(s, hh).mh, d ? d.st : hh.st)));
      return [b, heroTags(hh, d)];
    }
    function partyGrid(s) {
      const g = h('div', { class: 'mx-party' });
      s.pt.forEach((hh, i) => {
        const d = D[hh.u];
        const el = h('button', { class: 'mx-mini' + (hh.af ? ' af' : '') + (hh.dd ? ' dd' : ''), onclick: () => openHero(i) },
          h('span', { class: 'por' }, por(heroSpec(hh), 34, 'h' + hh.c)),
          h('b', { text: (i + 1) + ' ' + CL[hh.c].s + (hh.af ? ' · ' + AF[hh.af].n : hh.vi ? ' · ' + VI[hh.vi].n : '') }),
          h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px' } }, ...bars(d ? d.hp : hh.hp, hStats(s, hh).mh, d ? d.st : hh.st, 1)));
        if (s.np > 1) el.append(h('span', { class: 'own', style: { background: (api.players[hh.o] || {}).color || '#888' } }));
        g.append(el);
      });
      return g;
    }
    function refreshHero() {   // 연출 중 막대만 다시
      if (!S || S.ph === 'prep') return;
      if (S.ph === 'fight') { const hh = S.pt.find((x) => x.u === active); if (hh) { fresh(dl).append(...heroPanel(hh, S)); return; } }
      if (dl.querySelector('.mx-party')) fresh(dl).append(partyGrid(S));
    }
    function waitLine(t) { return h('div', { class: 'mx-wait', text: t }); }
    function renderDock() {
      const s = S; fresh(dl); fresh(dc); fresh(dr);
      if (!s) return;
      dock.style.display = s.ph === 'prep' || s.ph === 'way' ? 'none' : '';
      if (s.res) { dc.append(waitLine(s.nar || '')); dl.append(partyGrid(s)); return; }
      if (s.ph === 'prep') { if (mine() && !(ov && ov._draw)) openPrep(); else if (!mine() && !(ov && ov._prep)) openOv('원정 준비', '', (bd) => bd.append(waitLine(whoActs() + ' 님이 원정대를 꾸리는 중')), null)._prep = 1; return; }
      if (ov && ov._prep) closeOv();
      if (s.ph === 'way') { if (!ov || !ov._way) openWay(); else drawWay(); return; }
      if (ov && ov._way) closeOv();
      if (s.ph === 'fight') return dockFight(s);
      dl.append(partyGrid(s));
      if (s.ph === 'map') return dockMap(s);
      if (s.ph === 'curio') return dockCurio(s);
      if (s.ph === 'camp') return dockCamp(s);
    }

    /* ----- 전투 ----- */
    const rkTxt = (r) => r.split('').join('·');
    const rkC = (r) => r;
    function skillBtn(hh, slot, s, me) {
      const si = hh.sk[slot], Sk = CL[hh.c].sk[si];
      const ok = canUse(s, hh, si);
      const b = h('button', { class: 'mx-b mx-sk' + (sel === slot ? ' sel' : '') + (ok ? '' : ' no'), disabled: !ok || !me, 'data-action': 's' + (slot + 1),
        html: '<span class="k">' + (slot + 1) + '</span>' + icoSVG(Sk.ic, 28, ok ? '#ffe2a8' : '#9d8a70') + '<span>' + Sk.n + '</span><small>' + (ok ? rkC(Sk.f) + (Sk.t === 'e' ? '→' + rkC(Sk.r) : Sk.t === 'p' ? '→전체' : Sk.t === 's' ? '→자신' : '→아군') : '자리 ' + rkC(Sk.f) + '만') + '</small>',
        onclick: () => pickSkill(slot) });
      return b;
    }
    function pickSkill(slot) {
      const s = S; if (!s || s.ph !== 'fight') return;
      const hh = s.pt.find((x) => x.u === s.fi.cur); if (!hh || !mine()) return;
      const si = hh.sk[slot]; if (!canUse(s, hh, si)) return;
      const tg = targetsFor(s, hh, si);
      if (sel === slot && tg.length === 1) { act({ t: 'sk', i: slot, g: tg[0] }); return; }
      sel = slot; renderDock();
    }
    function dockFight(s) {
      const hh = s.pt.find((x) => x.u === (busy ? active : s.fi.cur)) || s.pt.find((x) => x.u === s.fi.cur);
      if (!hh) { dl.append(partyGrid(s)); return; }
      const me = mine() && hh.u === s.fi.cur;
      dl.append(...heroPanel(hh, s));
      const row = h('div', { class: 'mx-row2' });
      for (let i = 0; i < 4; i++) row.append(skillBtn(hh, i, s, me));
      const i = s.pt.indexOf(hh);
      const r2 = h('div', { class: 'mx-row2' },
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me || i === 0 || hh.af === 'fear', text: '앞으로', title: '한 칸 앞으로', onclick: () => act({ t: 'mv', d: -1 }) }),
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me || i >= s.pt.length - 1, text: '뒤로', title: '한 칸 뒤로', onclick: () => act({ t: 'mv', d: 1 }) }),
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me, text: '버티기', onclick: () => act({ t: 'pass' }) }),
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me, 'data-action': 'items', text: '보급품', onclick: () => openItems(true) }),
        h('button', { class: 'mx-b warn', style: { flex: 1 }, disabled: !me, text: '후퇴', onclick: () => confirmFlee() }));
      dc.append(row, r2);
      if (sel >= 0 && me) {
        const si = hh.sk[sel], Sk = CL[hh.c].sk[si];
        dr.append(h('div', { class: 'mx-desc', html: '<b>' + Sk.n + '</b> · ' + skillDesc(Sk) }));
        const tgs = h('div', { class: 'mx-tgs' });
        for (const g of targetsFor(s, hh, si)) {
          let t, v = '';
          if (Sk.t === 'e') {
            if (g === -1) { t = '적 ' + rkTxt(Sk.r) + ' 전부'; const e0 = s.fi.en.find((e, k) => Sk.r.includes(String(k + 1))); if (e0) v = hitChance(s, hh, Sk, e0, true) + '%'; }
            else { const e = s.fi.en[g]; t = (g + 1) + ' ' + EI[e.e].n; v = hitChance(s, hh, Sk, e, true) + '%'; }
          } else if (g === -1) t = Sk.t === 'p' ? '원정대 전체' : '자신';
          else { const o = s.pt[g]; t = (g + 1) + ' ' + CL[o.c].s; v = o.hp + '/' + hStats(s, o).mh; }
          tgs.append(h('button', { class: 'mx-b', html: '<span>' + t + '</span><em>' + v + '</em>', onclick: () => act({ t: 'sk', i: sel, g }) }));
        }
        dr.append(tgs);
      } else {
        if (me) dr.append(h('div', { class: 'mx-info', html: hh.sk.some((si) => canUse(s, hh, si)) ? '기술을 고르고 <b>장면의 적</b>이나 아래 단추로 대상을 정해요.' + (hh.af ? ' <b>' + AF[hh.af].n + '</b> 중 · 명령을 거부할 수 있어요.' : '') : '이 자리에서 쓸 기술이 없어요. 자리를 옮기거나 버텨요.' }));
        else if (!busy) dr.append(h('div', { class: 'mx-info', text: whoActs() + ' 님이 고르는 중' }));
        dr.append(logBox(s, G.land ? 4 : 3));
      }
    }
    function logBox(s, n) {
      const box = h('div', { class: 'mx-log' });
      s.log.slice(-n).forEach((t, i, a) => box.append(h('div', { style: { opacity: 0.6 + 0.4 * (i + 1) / a.length }, text: t })));
      return box;
    }
    function confirmFlee() {
      if (!mine()) return;
      const s = S;
      openOv('후퇴', s.fi.boss ? '성공 45% · 실패하면 차례를 잃어요' : '성공 75% · 앞에 있던 방으로 물러나요 · 모두 스트레스 +6', (bd) => {
        bd.append(h('div', { class: 'mx-info', text: '남은 적은 그 자리에 그대로 남아요.' }));
      }, [h('button', { class: 'mx-b', text: '취소', onclick: closeOv }), h('button', { class: 'mx-b warn', text: '후퇴', onclick: () => { closeOv(); act({ t: 'flee' }); } })]);
    }

    /* ----- 탐험 ----- */
    const KN = { f: '적이 있는 방', t: '보물 · 지키는 적', c: '기묘한 물건', e: '빈 방', x: '계단', b: '우두머리' };
    const kindName = (r) => (!r.sc ? '알 수 없음' : KN[r.k] || '방');
    function routes(s) {
      const mp = s.mp, at = mp.at, out = [];
      if (at.c != null) {
        const c = mp.c[at.c];
        for (const r of [c.a, c.b]) out.push({ r, dir: r === at.to ? '앞으로' : '되돌아가기', n: r === at.to ? c.s.length - at.i - 1 : at.i + 1 });
        return out;
      }
      const R0 = mp.r[at.r];
      for (const r of adjRooms(s)) {
        const R = mp.r[r], dx = R.x - R0.x, dy = R.y - R0.y;
        const ci = mp.c.findIndex((c) => (c.a === at.r && c.b === r) || (c.b === at.r && c.a === r));
        out.push({ r, dir: dx > 0 ? '동쪽' : dx < 0 ? '서쪽' : dy > 0 ? '남쪽' : '북쪽', n: ci >= 0 ? mp.c[ci].s.length : 0, back: r === mp.prev });
      }
      return out;
    }
    function dockMap(s) {
      const me = mine(), mp = s.mp;
      const atR = mp.at.c == null ? mp.r[mp.at.r] : null;
      const rs = routes(s), nItems = rs.length + (atR && atR.k === 'x' ? 1 : 0);
      const rt = h('div', { class: 'mx-route', style: { gridTemplateColumns: 'repeat(' + Math.min(3, Math.max(2, nItems)) + ',minmax(0,1fr))' } });
      for (const o of rs) {
        const R = mp.r[o.r];
        rt.append(h('button', { class: 'mx-b', disabled: !me, onclick: () => act({ t: 'go', r: o.r }), html: '<span style="min-width:0;overflow:hidden">' + o.dir + ' · ' + kindName(R) + '<small>통로 ' + o.n + '칸' + (o.back ? ' · 왔던 곳' : '') + (R.v ? ' · 가 본 방' : '') + '</small></span>' }));
      }
      if (atR && (atR.k === 'x')) rt.prepend(h('button', { class: 'mx-b pri', disabled: !me, html: icoSVG('stairs', 20, '#fff3dc') + '계단 내려가기 · ' + ((s.fl + 1) % ZLEN === 0 ? '역참' : '야영'), onclick: () => act({ t: 'down' }) }));
      dc.append(rt);
      dr.append(h('div', { class: 'mx-row2' },
        h('button', { class: 'mx-b', style: { flex: 1.25 }, disabled: !me || !(s.inv.torch > 0) || s.light >= 100, 'data-action': 'torch', html: icoSVG('torch', 18, '#ffc76a') + '횃불 ' + s.inv.torch, onclick: () => act({ t: 'torch' }) }),
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me || s.light <= 0, text: '어둡게', onclick: () => act({ t: 'dim' }) }),
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me, 'data-action': 'items', text: '보급품', onclick: () => openItems(false) })));
      if (!me && !busy) dc.prepend(h('div', { class: 'mx-info', text: whoActs() + ' 님이 길을 고르는 중' }));
      miniMap(dr, s);
    }
    function miniMap(col, s) {
      const box = h('button', { class: 'mx-mm', onclick: () => openMap() });
      const c = h('canvas'); box.append(c, h('span', { text: '지도 크게' }));
      col.append(box);
      let tries = 0;
      const go2 = () => { if (!c.isConnected || S !== s) return; if (c.getBoundingClientRect().width < 20 && tries++ < 30) { requestAnimationFrame(go2); return; } drawMap(c, s, false); };
      requestAnimationFrame(go2);
    }
    function mapGeo(W, H, mp, pad) {
      const xs = mp.r.map((x) => x.x), ys = mp.r.map((x) => x.y);
      const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      const cell = Math.min((W - pad * 2) / (x1 - x0 + 1), (H - pad * 2) / (y1 - y0 + 1), 130);
      const ox = (W - cell * (x1 - x0 + 1)) / 2, oy = (H - cell * (y1 - y0 + 1)) / 2;
      return { cell, pos: (i) => [ox + (mp.r[i].x - x0 + 0.5) * cell, oy + (mp.r[i].y - y0 + 0.5) * cell] };
    }
    function drawMap(cnv, s, big) {
      const r = cnv.getBoundingClientRect();
      const W = Math.max(10, r.width), H = Math.max(10, r.height);
      cnv.width = Math.round(W * dpr); cnv.height = Math.round(H * dpr);
      const c = cnv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
      const mp = s.mp; if (!mp) return null;
      const mg = mapGeo(W, H, mp, big ? 26 : 10), pos = mg.pos;
      const rs = Math.min(mg.cell * 0.52, big ? 60 : 30);
      const adj = adjRooms(s);
      mp.c.forEach((co, ci) => {
        const a = pos(co.a), b = pos(co.b);
        c.strokeStyle = co.w ? '#a88a62' : co.sc ? '#6a573f' : '#3c3128'; c.lineWidth = big ? 5 : 3; c.beginPath(); c.moveTo(a[0], a[1]); c.lineTo(b[0], b[1]); c.stroke();
        const n = co.s.length;
        for (let i = 0; i < n; i++) {
          const t = (i + 1) / (n + 1), x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t;
          const known = co.sc || (co.w >> i) & 1, k = co.s[i], here = mp.at.c === ci && mp.at.i === i;
          c.fillStyle = here ? '#ffd27a' : known ? '#c4a57c' : '#4a3d32';
          c.beginPath(); c.arc(x, y, here ? (big ? 7 : 5) : big ? 5 : 3.2, 0, Math.PI * 2); c.fill();
          if (big && known && k !== '.') { const ic = { T: 'wolf-trap', C: 'locked-chest', F: 'crossed-swords', O: 'stone-wall' }[k]; if (ic) drawIco(c, ic, x - 9, y - 24, 18, '#ffd9a0'); }
        }
      });
      mp.r.forEach((rm, i) => {
        const [x, y] = pos(i);
        const here = mp.at.c == null && mp.at.r === i, isAdj = adj.includes(i) && mine();
        c.fillStyle = rm.v ? '#3a2c20' : rm.sc ? '#241b15' : '#17120f';
        c.strokeStyle = here ? '#ffd27a' : isAdj ? '#e0b070' : rm.sc ? '#7a6248' : '#4a3c30';
        c.lineWidth = here || isAdj ? (big ? 3 : 2.2) : 1.4;
        c.beginPath(); c.rect(x - rs / 2, y - rs / 2, rs, rs); c.fill(); c.stroke();
        const ic = !rm.sc ? null : { f: 'crossed-swords', t: 'open-treasure-chest', c: rm.c ? CI[rm.c].ic : 'locked-chest', x: 'stairs', b: 'dread-skull' }[rm.k];
        if (ic) drawIco(c, ic, x - rs * 0.34, y - rs * 0.34, rs * 0.68, rm.k === 'b' ? '#ff9a86' : rm.k === 'x' ? '#ffe0a0' : '#e8d2a8');
        else if (!rm.sc) { c.fillStyle = '#9a8670'; c.font = '600 ' + Math.round(rs * 0.5) + 'px "IBM Plex Sans KR", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('?', x, y + 1); }
        if (here) { c.save(); c.shadowColor = '#ffb050'; c.shadowBlur = 10; drawIco(c, 'torch', x + rs * 0.18, y - rs * 0.86, rs * 0.55, '#ffd27a'); c.restore(); }
      });
      if (mp.at.c != null) { const co = mp.c[mp.at.c]; const a = pos(co.a), b = pos(co.b), t = (mp.at.i + 1) / (co.s.length + 1); const x = a[0] + (b[0] - a[0]) * t, y = a[1] + (b[1] - a[1]) * t; c.save(); c.shadowColor = '#ffb050'; c.shadowBlur = 10; drawIco(c, 'torch', x - 9, y - 26, 18, '#ffd27a'); c.restore(); }
      return { pos, rs };
    }
    function openMap() {
      const s = S; if (!s || !s.mp) return;
      openOv('지도', (s.fl + 1) + '층 · ' + ZI[s.mp.z].n + (mine() ? ' · 이웃한 방을 누르면 이동' : ''), (bd) => {
        bd.style.padding = '6px';
        const box = h('div', { style: { position: 'relative', flex: '1 1 auto', minHeight: '200px', borderRadius: '10px', background: '#100c09', border: '1px solid rgba(220,175,110,.25)' } });
        const c = h('canvas', { style: { position: 'absolute', inset: 0, width: '100%', height: '100%', touchAction: 'none' } });
        box.append(c); bd.append(box);
        bd.append(h('div', { class: 'mx-info', style: { fontSize: '12.5px' }, html: '<b>?</b> 알 수 없는 방 · 칼 적 · 상자 보물 · 해골 우두머리 · 계단 출구 · 노란 테두리 = 지금 갈 수 있는 방' }));
        let mg = null;
        requestAnimationFrame(() => { mg = drawMap(c, s, true); });
        c.addEventListener('pointerdown', (ev) => {
          if (!mine() || !mg) return;
          const r = c.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
          let best = -1, bdd = 1e9;
          s.mp.r.forEach((rm, i) => { const p = mg.pos(i); const dd = Math.hypot(p[0] - x, p[1] - y); if (dd < bdd) { bdd = dd; best = i; } });
          if (best < 0 || bdd > Math.max(30, mg.rs * 0.8)) return;
          if (!adjRooms(s).includes(best)) { toast('이웃한 방만 갈 수 있어요'); return; }
          closeOv(); act({ t: 'go', r: best });
        });
      }, [h('button', { class: 'mx-b', text: '닫기', onclick: closeOv })]);
      ov.querySelector('.bd').style.flexDirection = 'column';
    }

    /* ----- 기묘한 물건 ----- */
    function dockCurio(s) {
      const C = CI[s.cu.id], me = mine();
      dc.append(h('div', { class: 'mx-info', html: '<b>' + C.n + '</b> · ' + C.d }));
      const row = h('div', { class: 'mx-row2' });
      row.append(h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me, text: '손대기', onclick: () => act({ t: 'cu', k: 'touch' }) }));
      if (C.it) row.append(h('button', { class: 'mx-b pri', style: { flex: 1.3 }, disabled: !me || !(s.inv[C.it] > 0), html: icoSVG(PV[C.it].ic, 20, '#fff3dc') + PV[C.it].n + ' 쓰기 · ' + (s.inv[C.it] || 0), onclick: () => act({ t: 'cu', k: 'use', it: C.it }) }));
      row.append(h('button', { class: 'mx-b', style: { flex: 0.8 }, disabled: !me, text: '그냥 두기', onclick: () => act({ t: 'cu', k: 'leave' }) }));
      dc.append(row);
      dc.append(h('div', { class: 'mx-info', style: { fontSize: '12.5px' }, text: C.it ? PV[C.it].n + josa(PV[C.it].n, '을', '를') + ' 쓰면 좋은 결과가 확실해요.' : '맞는 보급품이 없어요.' }));
      if (!me && !busy) dc.append(h('div', { class: 'mx-info', text: whoActs() + ' 님이 고르는 중' }));
      miniMap(dr, s);
    }

    /* ----- 야영 ----- */
    function dockCamp(s) {
      const me = mine(), cp = s.cp;
      const pips = h('div', { class: 'mx-pips' }); for (let i = 0; i < CAMP_H; i++) pips.append(h('i', { class: i < cp.h ? 'on' : '' }));
      dc.append(h('div', { class: 'mx-info', html: '<b>야영</b> · 남은 시간 ' + cp.h + ' · 야습 확률 ' + cp.amb + '%' }), pips);
      dc.append(h('div', { class: 'mx-row2' },
        h('button', { class: 'mx-b', style: { flex: 1 }, disabled: !me, text: '보급품', onclick: () => openItems(false) }),
        h('button', { class: 'mx-b pri', style: { flex: 1.4 }, disabled: !me, text: '야영 끝내기', onclick: () => act({ t: 'cend' }) })));
      if (!me && !busy) dc.append(h('div', { class: 'mx-info', text: whoActs() + ' 님이 정하는 중' }));
      dr.append(h('div', { class: 'mx-info', style: { fontSize: '12.5px' }, text: '대원마다 야영 기술을 한 번씩 써요. 기술마다 시간이 들어요. 끝낼 때 야습을 당할 수 있어요.' }));
    }
    function openCampPanel() { campPanel = h('div', { class: 'mx-campp' }); wrap.append(campPanel); renderCamp(); }
    function closeCampPanel() { if (campPanel) { campPanel.remove(); campPanel = null; } }
    function renderCamp() {
      const s = S; if (!campPanel || !s || !s.cp) return;
      const me = mine(), cp = s.cp, g = geo();
      const w = G.land ? Math.min(Math.max(G.sw * 0.5, 330), 520) : G.sw - 16;
      Object.assign(campPanel.style, { right: '8px', top: '40px', width: w + 'px', maxHeight: (G.sh - 46) + 'px' });
      void g;
      campPanel.innerHTML = '';
      if (campSel) {
        const hh = s.pt[campSel.h], C = campSkills(hh)[campSel.c];
        campPanel.append(h('div', { class: 'mx-info', html: '<b>' + C.n + '</b> · ' + campDesc(C) + ' · 대상을 골라요' }));
        const tg = h('div', { class: 'mx-tgs' });
        for (const gi of campTargets(s, hh, campSel.c)) { const o = s.pt[gi]; tg.append(h('button', { class: 'mx-b', html: '<span>' + CL[o.c].s + '</span><em>' + o.hp + '/' + hStats(s, o).mh + ' · ' + o.st + '</em>', onclick: () => act({ t: 'cs', h: campSel.h, c: campSel.c, g: gi }) })); }
        tg.append(h('button', { class: 'mx-b', text: '취소', onclick: () => { campSel = null; renderCamp(); } }));
        campPanel.append(tg);
        return;
      }
      if (campHero >= s.pt.length) campHero = 0;
      const tabs = h('div', { class: 'mx-ctab' });
      s.pt.forEach((hh, hi) => {
        const left = campSkills(hh).filter((C, ci) => !cp.used.includes(hh.u + ':' + ci) && C.h <= cp.h).length;
        tabs.append(h('button', { class: 'mx-b' + (campHero === hi ? ' sel' : ''), html: '<span>' + CL[hh.c].s + '</span><small>스트레스 ' + hh.st + (left ? '' : ' · 끝') + '</small>', onclick: () => { campHero = hi; renderCamp(); } }));
      });
      campPanel.append(tabs);
      const hh = s.pt[campHero], hi = campHero, list = h('div', { class: 'mx-csk' });
      campSkills(hh).forEach((C, ci) => {
        const used = cp.used.includes(hh.u + ':' + ci);
        list.append(h('button', { class: 'mx-b' + (used ? ' used' : ''), disabled: !me || used || C.h > cp.h,
          html: icoSVG(C.ic, 22, '#ffe2a8') + '<div class="tx"><b>' + C.n + (used ? ' · 씀' : '') + '</b><span>' + campDesc(C) + '</span></div><em>' + C.h + '시간</em>',
          onclick: () => { const tg = campTargets(s, hh, ci); if (tg.length === 1) act({ t: 'cs', h: hi, c: ci, g: tg[0] }); else { campSel = { h: hi, c: ci }; renderCamp(); } } }));
      });
      campPanel.append(list);
    }

    /* ----- 역참(전체 창) ----- */
    function openWay() {
      const o = openOv('역참', '', () => {}, null); o._way = 1;
      o.append(h('div', { class: 'ft' }));
      drawWay();
    }
    function drawWay() {
      const s = S, o = ov; if (!o || !o._way || !s.wy) return;
      const me = mine(), w = s.wy;
      o.querySelector('.hd span').textContent = '금화 ' + s.gold + ' · 식량 ' + s.inv.food + ' · 횃불 ' + s.inv.torch + ' · 다음 구역 ' + ZI[s.zs[Math.floor(s.fl / ZLEN)]].n;
      const bd = o.querySelector('.bd'); bd.innerHTML = '';
      const split = h('div', { class: 'mx-split' });
      const tabs = h('div', { class: G.land ? 'mx-vt' : 'mx-tabs' });
      [['shop', '상점'], ['rec', '모집'], ['rest', '휴식'], ['sell', '장신구 팔기'], ['party', '원정대']].forEach(([k, n]) => tabs.append(h('button', { class: 'mx-b' + (wayTab === k ? ' sel' : ''), text: n, onclick: () => { wayTab = k; drawWay(); } })));
      const body = h('div', { class: 'mx-list' });
      if (wayTab === 'shop') PROV.forEach((P) => body.append(h('div', { class: 'mx-li' }, h('span', { html: icoTile(P.ic) }), h('div', { class: 'tx' }, h('b', { text: P.n + ' · ' + P.p + '금화' }), h('span', { text: '가진 것 ' + s.inv[P.id] + ' · ' + P.d })),
        h('button', { class: 'mx-b', disabled: !me || s.gold < P.p, text: '+1', onclick: () => act({ t: 'buy', it: P.id, n: 1 }) }),
        h('button', { class: 'mx-b', disabled: !me || s.gold < P.p * 3, text: '+3', onclick: () => act({ t: 'buy', it: P.id, n: 3 }) }))));
      else if (wayTab === 'rec') {
        body.append(h('div', { class: 'mx-info', text: s.pt.length >= 4 ? '원정대가 가득 찼어요(4명).' : '빈자리 ' + (4 - s.pt.length) + ' · 새 대원은 맨 뒤에 서요.' }));
        w.c.forEach((hh, i) => body.append(candRow(hh, () => act({ t: 'rec', c: i }), recruitCost(hh) + '금화', !me || s.pt.length >= 4 || s.gold < recruitCost(hh))));
      } else if (wayTab === 'rest') {
        body.append(h('div', { class: 'mx-info', text: '한 사람당 한 번, ' + restCost + '금화: 스트레스 −40 · 체력 +50% · 출혈·역병·문턱 후유증 치료' }));
        s.pt.forEach((hh, i) => body.append(h('div', { class: 'mx-li' }, h('span', { class: 'por' }, por(heroSpec(hh), 40, 'h' + hh.c)), h('div', { class: 'tx' }, h('b', { text: heroName(hh) }), h('span', { text: '체력 ' + hh.hp + '/' + hStats(s, hh).mh + ' · 스트레스 ' + hh.st + (hh.af ? ' · ' + AF[hh.af].n : '') })),
          h('button', { class: 'mx-b', disabled: !me || w.rest.includes(hh.u) || s.gold < restCost, text: w.rest.includes(hh.u) ? '쉼' : '쉬기', onclick: () => act({ t: 'rest', h: i }) }))));
      } else if (wayTab === 'sell') {
        if (!s.bag.length) body.append(h('div', { class: 'mx-info', text: '가방에 장신구가 없어요. 찬 장신구는 「원정대」에서 대원을 눌러 빼면 팔 수 있어요.' }));
        s.bag.forEach((id) => { const T = TI[id]; body.append(h('div', { class: 'mx-li' }, h('span', { html: icoTile(T.ic) }), h('div', { class: 'tx' }, h('b', { text: T.n + ' · ' + RARN[T.r] }), h('span', { text: trkDesc(T) })), h('button', { class: 'mx-b', disabled: !me, text: '팔기 ' + RARV[T.r] / 2, onclick: () => act({ t: 'sell', tr: id }) }))); });
      } else {
        s.pt.forEach((hh, i) => body.append(h('button', { class: 'mx-li', onclick: () => openHero(i) }, h('span', { class: 'por' }, por(heroSpec(hh), 40, 'h' + hh.c)), h('div', { class: 'tx' }, h('b', { text: (i + 1) + ' · ' + heroName(hh) + ' · ' + hh.lv + '단계' }), h('span', { text: '체력 ' + hh.hp + '/' + hStats(s, hh).mh + ' · 스트레스 ' + hh.st + ' · 장신구 ' + hh.tr.length + '/2 · 눌러서 자리·기술·장신구' })))));
      }
      split.append(tabs, body);
      if (!G.land) { split.style.flexDirection = 'column'; }
      bd.append(split);
      if (!me && !busy) bd.append(h('div', { class: 'mx-info', text: whoActs() + ' 님이 준비하는 중' }));
      const ft = o.querySelector('.ft'); ft.innerHTML = '';
      ft.append(h('button', { class: 'mx-b pri', disabled: !me || !s.pt.length, text: '다음 구역으로 출발', onclick: () => act({ t: 'wend' }) }));
    }
    function candRow(hh, onPick, right, dis, on) {
      const C = CL[hh.c];
      const chips = hh.q.map((id) => '<span class="mx-chip ' + (QI[id].p ? 'p' : 'n') + '">' + QI[id].n + '</span>').join('');
      return h('div', { class: 'mx-li' + (on ? ' on' : '') },
        h('span', { class: 'por' }, por(C.a, 44, 'h' + hh.c)),
        h('div', { class: 'tx' }, h('b', { text: heroName(hh) + (hh.lv > 1 ? ' · ' + hh.lv + '단계' : '') }), h('span', { html: '<span class="mx-chip r">' + ROLE[C.role] + ' · 자리 ' + rkTxt(C.rk) + '</span>' + chips })),
        h('button', { class: 'mx-b' + (on ? ' sel' : ''), disabled: dis, text: right, onclick: onPick }));
    }

    /* ---------- 창 ---------- */
    function openOv(title, sub, fill, foot) {
      closeOv();
      const bd = h('div', { class: 'bd' });
      ov = h('div', { class: 'mx-ov' }, h('div', { class: 'hd' }, h('b', { text: title }), h('span', { text: sub || '' })), bd);
      if (foot) ov.append(h('div', { class: 'ft' }, ...foot));
      fill(bd);
      wrap.append(ov);
      return ov;
    }
    function closeOv() { if (ov) { const was = ov; ov = null; was.remove(); if (was._back) was._back(); } }
    const onCancel = (e) => {
      if (ov && ov._sub) { closeOv(); e.preventDefault(); return; }
      if (ov && !ov._prep && !ov._way) { closeOv(); e.preventDefault(); return; }
      if (sel >= 0 || campSel) { sel = -1; campSel = null; renderDock(); if (campPanel) renderCamp(); e.preventDefault(); }
    };
    window.addEventListener('lounge-cancel', onCancel);

    function openItems(inFight) {
      const s = S; if (!mine()) return;
      let pickIt = null;
      const back = ov && ov._way ? null : null; void back;
      const draw = (bd) => {
        bd.innerHTML = '';
        if (!pickIt) {
          PROV.forEach((P) => {
            const usable = ['torch', 'food', 'band', 'anti', 'laud', 'holy'].includes(P.id) && !(inFight && P.id === 'food');
            bd.append(h('button', { class: 'mx-li', disabled: !usable || !(s.inv[P.id] > 0), onclick: () => { if (P.id === 'torch') { closeOv(); act(inFight ? { t: 'it', it: 'torch', g: 0 } : { t: 'torch' }); return; } pickIt = P.id; draw(bd); } },
              h('span', { html: icoTile(P.ic) }), h('div', { class: 'tx' }, h('b', { text: P.n + ' · ' + s.inv[P.id] + '개' }), h('span', { text: usable ? P.d : P.d + ' (여기서는 못 씀)' }))));
          });
        } else {
          bd.append(h('div', { class: 'mx-info', html: '<b>' + PV[pickIt].n + '</b> · 누구에게 쓸까요?' }));
          s.pt.forEach((o, g) => bd.append(h('button', { class: 'mx-li', onclick: () => { closeOv(); act({ t: 'it', it: pickIt, g }); } }, h('span', { class: 'por' }, por(heroSpec(o), 40, 'h' + o.c)), h('div', { class: 'tx' }, h('b', { text: heroName(o) }), h('span', { text: '체력 ' + o.hp + '/' + hStats(s, o).mh + ' · 스트레스 ' + o.st + (o.fx.some((f) => f.k === 'bl') ? ' · 출혈' : '') + (o.fx.some((f) => f.k === 'bg') ? ' · 역병' : '') })))));
        }
      };
      openOv('보급품', inFight ? '차례를 쓰지 않아요' : '', draw, [h('button', { class: 'mx-b', text: '닫기', onclick: closeOv })]);
    }

    /* 대원 자세히 */
    function openHero(i) {
      const s = S; const hh = s.pt[i]; if (!hh) return;
      const C = CL[hh.c], m = hStats(s, hh);
      const can = mine() && ['map', 'camp', 'way'].includes(s.ph);
      const wasWay = ov && ov._way;
      let skDraft = hh.sk.slice();
      const o = openOv(heroName(hh), C.n + ' · ' + hh.lv + '단계 · 자리 ' + (i + 1), (bd) => {
        const topRow = h('div', { style: { display: 'flex', gap: '12px', alignItems: 'flex-start', flexWrap: 'wrap' } });
        topRow.append(h('span', { style: { borderRadius: '10px', overflow: 'hidden', border: '1px solid rgba(220,175,110,.35)' } }, portrait(C.a, 96, { full: 1 })));
        const info = h('div', { style: { flex: '1 1 240px', minWidth: 0, display: 'flex', flexDirection: 'column', gap: '4px' } },
          ...bars(hh.hp, m.mh, hh.st),
          h('div', { class: 'mx-info', html: hh.af ? '<span class="mx-chip n">붕괴 · ' + AF[hh.af].n + '</span> ' + AF[hh.af].d : hh.vi ? '<span class="mx-chip p">각성 · ' + VI[hh.vi].n + '</span> ' + VI[hh.vi].d : '' }),
          h('div', { class: 'mx-info', text: '경험 ' + hh.xp + (hh.lv < 5 ? ' / 다음 단계 ' + LVXP[hh.lv] : ' · 최고 단계') }),
          h('div', { class: 'mx-info', style: { color: '#d4c3a2' }, text: C.d }));
        topRow.append(info);
        bd.append(topRow);
        const st = h('div', { class: 'mx-stat' });
        [['속도', m.spd], ['회피', m.dg], ['방어', m.pr + '%'], ['명중', '+' + m.acc], ['치명', m.cr + '%'], ['피해', m.lo + '–' + m.hi], ['기절 저항', m.res.st + '%'], ['출혈 저항', m.res.bl + '%'], ['역병 저항', m.res.bg + '%'], ['죽음 저항', m.dbr + '%'], ['받는 스트레스', (m.str >= 0 ? '+' : '') + m.str + '%'], ['함정 회피', m.res.tr + '%']].forEach(([k, v]) => st.append(h('div', { html: k + ' <b>' + v + '</b>' })));
        bd.append(st);
        if (can) bd.append(h('div', { class: 'mx-row2' },
          h('button', { class: 'mx-b', style: { flex: 1 }, disabled: i === 0, text: '◀ 앞자리로', onclick: () => { closeOv(); act({ t: 'sw', a: i, b: i - 1 }); } }),
          h('button', { class: 'mx-b', style: { flex: 1 }, disabled: i >= s.pt.length - 1, text: '뒷자리로 ▶', onclick: () => { closeOv(); act({ t: 'sw', a: i, b: i + 1 }); } })));
        bd.append(h('div', { class: 'mx-sec', text: '기질' }));
        if (!hh.q.length) bd.append(h('div', { class: 'mx-info', text: '아직 없음' }));
        hh.q.forEach((id) => { const Q2 = QI[id]; bd.append(h('div', { class: 'mx-info', html: '<span class="mx-chip ' + (Q2.p ? 'p' : 'n') + '">' + Q2.n + '</span> ' + quirkDesc(Q2) })); });
        bd.append(h('div', { class: 'mx-sec', text: '장신구 ' + hh.tr.length + '/2' }));
        hh.tr.forEach((id, k) => { const T = TI[id]; bd.append(h('div', { class: 'mx-li' }, h('span', { html: icoTile(T.ic) }), h('div', { class: 'tx' }, h('b', { text: T.n }), h('span', { text: trkDesc(T) })), can ? h('button', { class: 'mx-b', text: '빼기', onclick: () => { closeOv(); act({ t: 'uneq', h: i, slot: k }); } }) : null)); });
        if (can) s.bag.filter((id) => (!TI[id].cls || TI[id].cls === hh.c) && !hh.tr.includes(id)).forEach((id) => { const T = TI[id]; bd.append(h('div', { class: 'mx-li' }, h('span', { html: icoTile(T.ic) }), h('div', { class: 'tx' }, h('b', { text: T.n + ' · 가방' }), h('span', { text: trkDesc(T) })), h('button', { class: 'mx-b', text: hh.tr.length < 2 ? '차기' : '바꾸기', onclick: () => { closeOv(); act({ t: 'eq', h: i, tr: id, slot: hh.tr.length < 2 ? hh.tr.length : 1 }); } }))); });
        bd.append(h('div', { class: 'mx-sec', text: '기술 · 넷을 들고 감' + (can ? ' · 눌러서 바꾸기' : '') }));
        const skBox = h('div', { class: 'mx-grid', style: { gridTemplateColumns: G.land ? '1fr 1fr' : '1fr' } });
        const drawSk = () => {
          skBox.innerHTML = '';
          C.sk.forEach((Sk, si) => {
            const on = skDraft.includes(si);
            skBox.append(h('button', { class: 'mx-li' + (on ? ' on' : ''), disabled: !can, onclick: () => { if (on) { if (skDraft.length > 1) skDraft = skDraft.filter((x) => x !== si); } else if (skDraft.length < 4) skDraft.push(si); drawSk(); } },
              h('span', { html: icoTile(Sk.ic, on ? '#ffe2a8' : '#a8977f') }), h('div', { class: 'tx' }, h('b', { text: Sk.n + (on ? ' · 듦' : '') }), h('span', { text: skillDesc(Sk) }))));
          });
        };
        drawSk(); bd.append(skBox);
        ov._save = () => { if (can && skDraft.length === 4 && skDraft.slice().sort().join() !== hh.sk.slice().sort().join()) act({ t: 'sks', h: i, sk: skDraft }); };
      }, [h('button', { class: 'mx-b pri', text: can ? '닫기 · 기술 저장' : '닫기', onclick: () => { const f = ov && ov._save; closeOv(); if (f) f(); } })]);
      o._sub = 1;
      if (wasWay) o._back = () => { if (S && S.ph === 'way' && !ov) openWay(); };
    }

    /* 원정 준비: ① 대원 → ② 보급품 */
    function openPrep() {
      const s = S;
      if (!prepD) prepD = { party: [], sk: {}, buy: buyPlan({ inv: {}, pt: [1, 2, 3, 4] }, START_GOLD, Math.min(3, s.len), 2, {}), tab: 'party' };
      const P = prepD;
      const cost = () => Object.keys(P.buy).reduce((a, k) => a + PV[k].p * P.buy[k], 0);
      const o = openOv('원정대 꾸리기', '', () => {}, null);
      o._prep = 1;
      const bd = o.querySelector('.bd');
      const ft = h('div', { class: 'ft' });
      o.append(ft);
      const draw = () => {
        bd.innerHTML = ''; ft.innerHTML = '';
        o.querySelector('.hd span').textContent = P.tab === 'party' ? '후보 8명 중 넷 · 1이 맨 앞' : '금화 ' + START_GOLD + ' · 남는 금화 ' + (START_GOLD - cost());
        bd.append(h('div', { class: 'mx-steps' },
          h('button', { class: 'mx-b' + (P.tab === 'party' ? ' sel' : ''), text: '① 대원 ' + P.party.length + '/4', onclick: () => { P.tab = 'party'; draw(); } }),
          h('button', { class: 'mx-b' + (P.tab === 'shop' ? ' sel' : ''), disabled: !P.party.length, text: '② 보급품', onclick: () => { P.tab = 'shop'; draw(); } })));
        if (P.tab === 'party') {
          const slots = h('div', { class: 'mx-slotrow', style: { gridTemplateColumns: G.land && G.W >= 760 ? 'repeat(4,1fr)' : 'repeat(2,1fr)' } });
          for (let i = 0; i < 4; i++) {
            const ci = P.party[i];
            if (ci == null) { slots.append(h('div', { class: 'mx-slot' }, h('span', { class: 'n', text: String(i + 1) }), h('span', { text: i < 2 ? '빈자리 · 앞줄' : '빈자리 · 뒷줄' }))); continue; }
            const hh = s.pr.c[ci];
            slots.append(h('div', { class: 'mx-slot full' }, h('span', { class: 'n', text: String(i + 1) }),
              h('span', { style: { borderRadius: '6px', overflow: 'hidden', flex: '0 0 auto' } }, por(CL[hh.c].a, 40, 'h' + hh.c)),
              h('div', { class: 'nm' }, h('b', { text: CL[hh.c].n }), h('span', { text: ROLE[CL[hh.c].role] })),
              h('div', { class: 'ctl' },
                h('button', { text: '◀', title: '앞자리로', disabled: i === 0, onclick: () => { const t = P.party[i - 1]; P.party[i - 1] = P.party[i]; P.party[i] = t; draw(); } }),
                h('button', { text: '기술', onclick: () => prepSkills(ci, draw) }))));
          }
          bd.append(slots);
          bd.append(h('div', { class: 'mx-sec', text: '후보 · 누르면 넣거나 뺌' }));
          const grid = h('div', { class: 'mx-grid', style: { gridTemplateColumns: G.land ? (G.W >= 760 ? 'repeat(4,minmax(0,1fr))' : 'repeat(3,minmax(0,1fr))') : 'repeat(2,minmax(0,1fr))' } });
          s.pr.c.forEach((hh, ci) => {
            const on = P.party.includes(ci), C = CL[hh.c];
            const el = h('button', { class: 'mx-cand' + (on ? ' on' : ''), disabled: !on && P.party.length >= 4, onclick: () => { if (on) P.party = P.party.filter((x) => x !== ci); else if (P.party.length < 4) P.party.push(ci); draw(); } },
              h('div', { class: 'top' }, h('span', { class: 'por' }, por(C.a, 46, 'h' + hh.c)), h('div', {}, h('b', { text: C.n }), h('div', { class: 'r', text: ROLE[C.role] + ' · 자리 ' + rkTxt(C.rk) }))),
              h('div', { class: 'r', text: heroName(hh) }),
              h('div', { html: hh.q.map((id) => '<span class="mx-chip ' + (QI[id].p ? 'p' : 'n') + '">' + QI[id].n + '</span>').join('') }));
            if (on) el.append(h('span', { class: 'no', text: String(P.party.indexOf(ci) + 1) }));
            grid.append(el);
          });
          bd.append(grid);
          if (P.party.length && P.party.length < 4) bd.append(h('div', { class: 'mx-info', text: '넷보다 적게 출발할 수도 있지만, 빈자리는 역참에서야 채울 수 있어요.' }));
          ft.append(h('button', { class: 'mx-b', text: '추천 넷', onclick: () => { const a = aiPrep(s, 2, habits(s, 0)); P.party = a.party; draw(); } }),
            h('button', { class: 'mx-b pri', disabled: !P.party.length, text: '다음 · 보급품', onclick: () => { P.tab = 'shop'; draw(); } }));
        } else {
          const grid = h('div', { class: 'mx-grid', style: { gridTemplateColumns: G.land ? '1fr 1fr' : '1fr' } });
          PROV.forEach((Pv) => {
            const n = P.buy[Pv.id] || 0;
            grid.append(h('div', { class: 'mx-li' }, h('span', { html: icoTile(Pv.ic) }), h('div', { class: 'tx' }, h('b', { text: Pv.n + ' · ' + Pv.p + '금화' }), h('span', { text: Pv.d })),
              h('div', { class: 'mx-qty' }, h('button', { text: '−', disabled: !n, onclick: () => { P.buy[Pv.id] = Math.max(0, n - 1); draw(); } }), h('b', { text: String(n) }), h('button', { text: '+', disabled: cost() + Pv.p > START_GOLD, onclick: () => { P.buy[Pv.id] = n + 1; draw(); } }))));
          });
          bd.append(grid);
          bd.append(h('div', { class: 'mx-info', text: '남은 금화는 역참에서 쓸 수 있어요. 식량은 층마다 대원 수의 1.5배쯤, 횃불은 층마다 2~3개가 알맞아요.' }));
          ft.append(h('button', { class: 'mx-b', text: '◀ 대원', onclick: () => { P.tab = 'party'; draw(); } }),
            h('button', { class: 'mx-b', text: '추천 구성', onclick: () => { P.buy = buyPlan({ inv: {}, pt: P.party.length ? P.party : [1, 2, 3, 4] }, START_GOLD, Math.min(3, s.len), 2, {}); draw(); } }),
            h('button', { class: 'mx-b pri', disabled: !P.party.length || cost() > START_GOLD, text: '출발', onclick: () => {
              const sk = P.party.map((ci) => P.sk[ci] || null);
              closeOv(); act({ t: 'start', party: P.party.slice(), sk, buy: Object.assign({}, P.buy) });
            } }));
        }
      };
      o._draw = draw;
      draw();
    }
    function prepSkills(ci, back) {
      const s = S, hh = s.pr.c[ci], C = CL[hh.c];
      let d = (prepD.sk[ci] || hh.sk).slice();
      const o = h('div', { class: 'mx-ov', style: { zIndex: 25 } });
      const bd = h('div', { class: 'bd' });
      const drawK = () => {
        bd.innerHTML = '';
        const grid = h('div', { class: 'mx-grid', style: { gridTemplateColumns: G.land ? '1fr 1fr' : '1fr' } });
        C.sk.forEach((Sk, si) => {
          const on = d.includes(si);
          grid.append(h('button', { class: 'mx-li' + (on ? ' on' : ''), onclick: () => { if (on) { if (d.length > 1) d = d.filter((x) => x !== si); } else if (d.length < 4) d.push(si); drawK(); } },
            h('span', { html: icoTile(Sk.ic, on ? '#ffe2a8' : '#a8977f') }), h('div', { class: 'tx' }, h('b', { text: Sk.n + (on ? ' · 듦' : '') }), h('span', { text: skillDesc(Sk) }))));
        });
        bd.append(grid);
      };
      drawK();
      o.append(h('div', { class: 'hd' }, h('b', { text: heroName(hh) }), h('span', { text: '기술 넷 고르기' })), bd,
        h('div', { class: 'ft' }, h('button', { class: 'mx-b', text: '기본으로', onclick: () => { d = C.def.slice(); drawK(); } }), h('button', { class: 'mx-b pri', text: '확인', onclick: () => { if (d.length === 4) prepD.sk[ci] = d; o.remove(); back(); } })));
      wrap.append(o);
    }

    /* ---------- 장면 그리기 ---------- */
    let lp = { x: 200, y: 200 };
    function lightPos() { return lp; }
    function targetSet() {
      const out = {};
      const s = S; if (!s || s.ph !== 'fight' || sel < 0 || busy) return out;
      const hh = s.pt.find((x) => x.u === s.fi.cur); if (!hh) return out;
      const si = hh.sk[sel]; if (si == null || !canUse(s, hh, si)) return out;
      const Sk = CL[hh.c].sk[si];
      if (Sk.t === 'e') s.fi.en.forEach((e, i) => { if (Sk.r.includes(String(i + 1))) out[e.u] = { e, Sk, hh }; });
      else if (Sk.t === 's') out[hh.u] = {};
      else if (Sk.t === 'p') s.pt.forEach((x) => (out[x.u] = {}));
      else for (const g of targetsFor(s, hh, si)) out[s.pt[g].u] = {};
      return out;
    }
    function basePose(d) {
      const ph = phOf();
      if (d.side === 'h') {
        const hh = S && S.pt.find((x) => x.u === d.u);
        if (hh && (hh.dd || d.hp <= 0) && ph !== 'camp') return 'down';
        if (ph === 'camp') return 'sit';
        if (walking || Math.abs(camTo - camX) > 3 || Math.abs(d.off - d.offTo) > 6) return 'walk';
        if (hh && hh.af) return 'fear';
      }
      return 'idle';
    }
    function rr(c, x, y, w, hh, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + hh, r); c.arcTo(x + w, y + hh, x, y + hh, r); c.arcTo(x, y + hh, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
    function drawProp(c, g, ph) {
      const s = S; if (!s) return;
      if (ph === 'camp') {   // 모닥불
        const x = campX(), y = g.gy;
        c.fillStyle = '#1c130c'; c.fillRect(x - 26, y - 5, 52, 6);
        c.strokeStyle = '#2a1a10'; c.lineWidth = 5; c.beginPath(); c.moveTo(x - 22, y - 2); c.lineTo(x + 18, y - 9); c.moveTo(x + 22, y - 2); c.lineTo(x - 16, y - 10); c.stroke();
        for (let i = 0; i < 4; i++) {
          const fx = x + (i - 1.5) * 8, fh = 26 + Math.sin(nowT * 11 + i * 2) * 7 + (i === 1 || i === 2 ? 12 : 0);
          c.fillStyle = i === 1 || i === 2 ? '#ffd27a' : '#e07a2f';
          c.beginPath(); c.moveTo(fx - 7, y - 4); c.quadraticCurveTo(fx - 5, y - fh * 0.6, fx + Math.sin(nowT * 7 + i) * 2, y - fh); c.quadraticCurveTo(fx + 5, y - fh * 0.6, fx + 7, y - 4); c.fill();
        }
        if (Math.random() < 0.3 * fxAmt()) parts.push({ x: x + (Math.random() - 0.5) * 20, y: y - 20, vx: (Math.random() - 0.5) * 12, vy: -30 - Math.random() * 30, g: -5, t: 0, life: 1.6, c: '#ffb050', sz: 1.6, add: true });
        return;
      }
      if (ph === 'curio' && s.cu) {
        const C = CI[s.cu.id], sz = Math.min(g.fh * 0.6, 90), x = g.cx + g.step * 1.6;
        c.save(); c.shadowColor = 'rgba(255,200,120,.7)'; c.shadowBlur = 22; drawIco(c, C.ic, x - sz / 2, g.gy - sz - 2 + Math.sin(nowT * 1.5) * 2, sz, '#f0dcb4'); c.restore();
        return;
      }
      if (roomProp && ph === 'map') {
        const x = roomProp.x - camX;
        if (x < -200 || x > G.sw + 200) return;
        if (roomProp.k === 'x' || roomProp.k === 'b') {   // 아래로 내려가는 계단 · 문
          c.fillStyle = '#060504'; rr(c, x - g.step * 0.6, g.gy - g.fh * 1.25, g.step * 1.2, g.fh * 1.25, g.step * 0.6); c.fill();
          c.strokeStyle = 'rgba(200,160,110,.4)'; c.lineWidth = 2; c.stroke();
          for (let i = 0; i < 5; i++) { c.fillStyle = 'rgba(120,95,70,' + (0.5 - i * 0.09) + ')'; c.fillRect(x - g.step * 0.45 + i * 3, g.gy - 4 - i * 9, g.step * 0.9 - i * 6, 3); }
        } else if (roomProp.k === 't') {
          drawIco(c, 'open-treasure-chest', x - 30, g.gy - 54, 56, '#c9a46a');
        } else {
          c.fillStyle = 'rgba(0,0,0,.55)'; rr(c, x - g.step * 0.5, g.gy - g.fh * 1.15, g.step, g.fh * 1.15, g.step * 0.5); c.fill();
        }
      }
    }
    function drawScene(dt) {
      const { sw, sh } = G, s = S, g = geo(), ph = phOf();
      const sp = Math.min(2.5, spd());
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      camX += (camTo - camX) * Math.min(1, dt * 3.2 * sp);
      zoom += (zoomTo - zoom) * Math.min(1, dt * 6); zoomTo += (1 - zoomTo) * Math.min(1, dt * 1.6);
      shake = Math.max(0, shake - dt * 2.6);
      const zone = ph === 'way' ? 'way' : s && s.mp ? s.mp.z : s && s.zs ? s.zs[0] : 'oss';
      // 카메라
      ctx.save();
      const sx = shake ? (Math.random() - 0.5) * 9 * shake * fxAmt() : 0, sy = shake ? (Math.random() - 0.5) * 6 * shake * fxAmt() : 0;
      const fx = zfx || sw / 2, fy = zfy || sh / 2;
      ctx.translate(fx + sx, fy + sy); ctx.scale(zoom, zoom); ctx.translate(-fx, -fy);
      drawWorld(ctx, sw, sh, { zone, camX, t: nowT, gy: g.gy });
      drawProp(ctx, g, ph);
      // 인물
      const tset = targetSet();
      const list = Object.values(D).sort((a, b) => (a.side === b.side ? b.rank - a.rank : a.side === 'e' ? -1 : 1));
      let torchSet = false;
      const torchU = s && s.pt.length ? (s.pt[Math.min(1, s.pt.length - 1)] || s.pt[0]).u : -1;
      const rec = [];
      for (const d of list) {
        d.x += (d.tx - d.x) * Math.min(1, dt * 6 * sp);
        d.alpha += (d.ta - d.alpha) * Math.min(1, dt * (d.ta ? 5 : 1.4) * sp);
        d.flash = Math.max(0, d.flash - dt * 3.4 * sp);
        d.off += (d.offTo - d.off) * Math.min(1, dt * 12 * sp);
        if (d.anim) { d.anim.t += dt * sp; if (d.anim.t >= d.anim.dur) { if (d.anim.k === 'atk') d.offTo = 0; if (!d.dead) d.anim = null; else d.anim.t = d.anim.dur; } else if (d.anim.k === 'atk' && d.anim.t > d.anim.dur * 0.62) d.offTo = 0; }
        if (d.alpha < 0.02 && d.dead) continue;
        const pose = d.anim ? { k: d.anim.k, p: Math.min(1, d.anim.t / d.anim.dur) } : { k: basePose(d), p: 0 };
        if (d.dead) pose.k = 'down';
        const boss = isBoss(d);
        const fh2 = g.fh * (boss ? 1.3 : 1);
        const x = d.x + d.off, y = g.gy;
        const isCur = d.u === active && ph === 'fight';
        if (tset[d.u]) { ctx.save(); ctx.globalAlpha = 0.65 + 0.3 * Math.sin(nowT * 5); ctx.strokeStyle = d.side === 'e' ? '#ffb070' : '#a8f0c0'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(d.x, g.gy + 4, g.step * 0.5 * wOf(d), 7, 0, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
        if (isCur) { const gr = ctx.createRadialGradient(d.x, g.gy, 2, d.x, g.gy, g.step * 0.75); gr.addColorStop(0, 'rgba(255,190,100,.5)'); gr.addColorStop(1, 'rgba(255,190,100,0)'); ctx.fillStyle = gr; ctx.fillRect(d.x - g.step, g.gy - 14, g.step * 2, 28); }
        // 그림자
        ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.beginPath(); ctx.ellipse(x, g.gy + 2, g.step * 0.36 * wOf(d), 4, 0, 0, Math.PI * 2); ctx.fill();
        const out = {};
        const hasTorch = d.u === torchU && d.side === 'h' && ph !== 'camp' && !d.dead;
        ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(1, d.alpha));
        const rimDx = Math.sign(lp.x - x) || -1;
        const o = { flip: d.side === 'e' || (ph === 'camp' && d.x > campX()), pose, t: nowT, seed: d.seed, rimDx, rimA: 0.5 + 0.45 * shownLight / 100, flash: d.flash * 0.7, flashC: d.side === 'h' ? '#ffb4a0' : '#fff0d8', torch: hasTorch, out };
        drawFig(ctx, d.spec, x, y, fh2, o);
        ctx.restore();
        rec.push({ d, x, y, fh2, o });
        if (hasTorch && out.tx != null) {
          const k = fh2 / 150 * (d.spec.k || 1);
          lp = { x: x + (out.tx - 50) * k, y: y + (out.ty - 150) * k }; torchSet = true;
        }
      }
      if (!torchSet) lp = { x: sw * 0.4, y: g.gy - g.fh * 0.8 };
      if (ph === 'camp') lp = { x: campX(), y: g.gy - 26 };
      // 발사체 · 타격 효과
      drawProjFx(dt * sp, g);
      // 빛
      drawLight(ctx, sw, sh, { x: lp.x, y: lp.y, light: ph === 'camp' ? Math.max(70, shownLight) : ph === 'way' ? 85 : shownLight, t: nowT });
      // 눈빛 · 불빛
      for (const r of rec) { ctx.save(); ctx.globalAlpha = Math.max(0, Math.min(1, r.d.alpha)); drawFig(ctx, r.d.spec, r.x, r.y, r.fh2, Object.assign({}, r.o, { emit: 1 })); ctx.restore(); }
      if (ph === 'camp') { const cx2 = campX(); ctx.save(); ctx.globalCompositeOperation = 'lighter'; const gr = ctx.createRadialGradient(cx2, g.gy - 20, 0, cx2, g.gy - 20, 70); gr.addColorStop(0, 'rgba(255,170,80,.45)'); gr.addColorStop(1, 'rgba(255,120,40,0)'); ctx.fillStyle = gr; ctx.fillRect(cx2 - 80, g.gy - 100, 160, 120); ctx.restore(); }
      // 불티
      if (ph !== 'prep' && Math.random() < dt * 4 * fxAmt()) parts.push({ x: lp.x + (Math.random() - 0.5) * 6, y: lp.y, vx: (Math.random() - 0.5) * 14, vy: -18 - Math.random() * 22, g: -4, t: 0, life: 1.2, c: '#ffb460', sz: 1.3, add: true });
      drawParts(dt * sp);
      if (walking || Math.abs(camTo - camX) > 3) drawForeground(ctx, sw, sh, { camX });
      ctx.restore();
      // 화면 고정 UI: 막대 · 상태 · 표적 · 숫자
      for (const r of rec) drawUnitUI(r, g, ph, tset);
      drawOrder(g);
      drawLabel(dt);
      drawPops(dt);
      drawBubbles(dt, g);
      drawBanner(dt);
      drawFade(dt);
    }
    function drawProjFx(dt, g) {
      for (let i = projs.length - 1; i >= 0; i--) {
        const p = projs[i]; p.t += dt;
        if (p.t < 0) continue;
        const k = Math.min(1, p.t / p.dur);
        if (k >= 1) { projs.splice(i, 1); burst(p.x1, p.y1, 8, { c: p.k === 'orb' || p.k === 'dread' ? '#d0a8ff' : '#ffd090', v: 90, add: true, life: 0.4 }); continue; }
        const x = p.x0 + (p.x1 - p.x0) * k, y = p.y0 + (p.y1 - p.y0) * k - Math.sin(k * Math.PI) * (p.k === 'bolt' ? 6 : 30);
        ctx.save();
        if (p.k === 'bolt') { const a = Math.atan2(p.y1 - p.y0, p.x1 - p.x0); ctx.translate(x, y); ctx.rotate(a); ctx.strokeStyle = '#e8d4a8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-16, 0); ctx.lineTo(4, 0); ctx.stroke(); ctx.strokeStyle = 'rgba(255,220,160,.35)'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(-34, 0); ctx.lineTo(-10, 0); ctx.stroke(); }
        else { ctx.globalCompositeOperation = 'lighter'; const c = p.k === 'dread' ? '170,110,230' : p.k === 'orb' ? '200,170,255' : '255,180,90'; const gr = ctx.createRadialGradient(x, y, 0, x, y, 14); gr.addColorStop(0, 'rgba(' + c + ',.95)'); gr.addColorStop(1, 'rgba(' + c + ',0)'); ctx.fillStyle = gr; ctx.fillRect(x - 14, y - 14, 28, 28); }
        ctx.restore();
      }
      for (let i = fxs.length - 1; i >= 0; i--) {
        const f = fxs[i]; f.t += dt;
        if (f.t > f.life) { fxs.splice(i, 1); continue; }
        const k = f.t / f.life;
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 1 - k;
        ctx.strokeStyle = f.cr ? '#ffd0a0' : '#f0e0c8'; ctx.lineWidth = (f.cr ? 5 : 3) * (1 - k * 0.6);
        const r = g.step * (f.cr ? 0.7 : 0.5);
        ctx.beginPath(); ctx.arc(f.x - f.dir * r * 0.3, f.y, r, -0.9 + k * 0.4, 0.9 * (0.3 + k), false); ctx.stroke();
        if (f.cr) { ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(f.x - r, f.y - r * 0.8); ctx.lineTo(f.x + r, f.y + r * 0.8); ctx.stroke(); }
        ctx.restore();
      }
    }
    function drawParts(dt) {
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.t += dt;
        if (p.t > p.life) { parts.splice(i, 1); continue; }
        p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 1 - dt * 1.5;
        ctx.globalAlpha = Math.max(0, 1 - p.t / p.life);
        if (p.add) ctx.globalCompositeOperation = 'lighter';
        ctx.fillStyle = p.c; ctx.beginPath(); ctx.arc(p.x, p.y, p.sz, 0, Math.PI * 2); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
      }
      ctx.globalAlpha = 1;
      if (parts.length > 400) parts.splice(0, parts.length - 400);
    }
    function drawUnitUI(r, g, ph, tset) {
      const d = r.d; if (d.dead || d.alpha < 0.3) return;
      const k = r.fh2 * (d.spec.k || 1);
      const x = d.x;
      if (ph === 'fight' || d.side === 'e') {
        const bw = Math.min(g.step * 0.82 * wOf(d), 96), top2 = d.side === 'e' ? r.y - k - 14 : r.y + 9;
        ctx.fillStyle = 'rgba(0,0,0,.75)'; ctx.fillRect(x - bw / 2 - 1.5, top2 - 1.5, bw + 3, d.side === 'h' ? 12 : 8);
        ctx.fillStyle = '#c33a2c'; ctx.fillRect(x - bw / 2, top2, bw * Math.max(0, d.hp) / d.mh, 5);
        if (d.side === 'h') { ctx.fillStyle = '#251d33'; ctx.fillRect(x - bw / 2, top2 + 6, bw, 3); ctx.fillStyle = '#a27ae0'; ctx.fillRect(x - bw / 2, top2 + 6, bw * Math.min(1, d.st / 200), 3); }
        // 상태 아이콘
        let fxl = [];
        if (d.side === 'e' && S && S.fi) { const e2 = S.fi.en.find((x2) => x2.u === d.u); if (e2) fxl = e2.fx; }
        else if (S) { const hh = S.pt.find((p) => p.u === d.u); if (hh) fxl = hh.fx; }
        const ks = {}; for (const f of fxl) if (FXI[f.k] && f.k !== 'ddr') ks[f.k] = 1;
        const keys = Object.keys(ks); let ix = x - keys.length * 9;
        const iy = d.side === 'e' ? top2 - 19 : r.y - k - 20;
        for (const kk of keys) { ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.beginPath(); ctx.arc(ix + 8, iy + 8, 9, 0, Math.PI * 2); ctx.fill(); drawIco(ctx, FXI[kk], ix + 1, iy + 1, 14, kk === 'bl' ? '#ff9a8a' : kk === 'bg' ? '#c8e88a' : kk === 'stun' ? '#ffe78a' : kk === 'mk' ? '#ffb070' : '#efdcb0'); ix += 18; }
      }
      const t = tset[d.u];
      if (t && t.e) {   // 명중 확률 · 피해 미리 보기
        const hc = hitChance(S, t.hh, t.Sk, t.e, true), dm = t.Sk.dm > 0 ? dmgRange(S, t.hh, t.Sk, t.e, true) : null;
        const txt = hc + '%', t2 = dm ? dm[0] + '–' + dm[1] : '';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const tw = Math.min(g.step * 0.92, 56), ty = r.y + 16, th = t2 ? 32 : 20;
        ctx.fillStyle = 'rgba(20,12,6,.92)'; rr(ctx, x - tw / 2, ty, tw, th, 6); ctx.fill(); ctx.strokeStyle = '#ffb070'; ctx.lineWidth = 1; ctx.stroke();
        ctx.font = '800 14px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ffe6c0'; ctx.fillText(txt, x, ty + 10.5);
        if (t2) { ctx.font = '600 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#f0c8a0'; ctx.fillText(t2, x, ty + 24); }
      }
      if (d.u === active && ph === 'fight') { ctx.fillStyle = '#ffd27a'; const ty = d.side === 'e' ? r.y - k - 38 : r.y - k - 26; ctx.beginPath(); ctx.moveTo(x - 7, ty - 8); ctx.lineTo(x + 7, ty - 8); ctx.lineTo(x, ty); ctx.fill(); }
    }
    // 행동 순서 막대: 지금 차례 + 남은 차례
    function drawOrder(g) {
      const s = S; if (!s || s.ph !== 'fight' || !s.fi) return;
      const seq = [active || s.fi.cur].concat(s.fi.q).filter((u, i, a) => u && D[u] && !D[u].dead && a.indexOf(u) === i).slice(0, 8);
      if (seq.length < 2) return;
      const cw = 30, gap = 4, wTot = seq.length * (cw + gap) - gap + 46;
      let x = (G.sw - wTot) / 2; const y = 42;
      ctx.fillStyle = 'rgba(10,7,5,.72)'; rr(ctx, x - 6, y - 4, wTot + 12, cw + 8, 9); ctx.fill();
      ctx.font = '600 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#e8d2a8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText('순서', x, y + cw / 2); x += 34;
      seq.forEach((u, i) => {
        const d = D[u], sz = i === 0 ? cw : cw - 4, yy = y + (cw - sz) / 2;
        ctx.save(); rr(ctx, x, yy, sz, sz, 6); ctx.fillStyle = d.side === 'h' ? '#3b2a1a' : '#3a1715'; ctx.fill(); ctx.clip();
        const bg2 = ctx.createRadialGradient(x + sz / 2, yy + sz * 0.4, 1, x + sz / 2, yy + sz / 2, sz * 0.8); bg2.addColorStop(0, d.side === 'h' ? '#8a6238' : '#7a3328'); bg2.addColorStop(1, d.side === 'h' ? '#2a1d12' : '#2a0f0c'); ctx.fillStyle = bg2; ctx.fillRect(x, yy, sz, sz);
        drawFig(ctx, d.spec, x + sz / 2, yy + sz * 1.02, sz * 0.98 / (d.spec.k || 1), { flip: d.side === 'e', t: 0.5, rimDx: d.side === 'e' ? 1 : -1, rimA: 1, rim: 'rgba(255,214,150,.95)' });
        ctx.restore();
        ctx.strokeStyle = i === 0 ? '#ffd27a' : d.side === 'h' ? '#c9a06a' : '#d0655a'; ctx.lineWidth = i === 0 ? 2.5 : 1.5; rr(ctx, x, yy, sz, sz, 6); ctx.stroke();
        x += sz + gap;
      });
    }
    function drawLabel(dt) {
      if (!label) return;
      label.t += dt * Math.min(2, spd());
      if (label.t > 1.2) { label = null; return; }
      const d = D[label.u]; const g = geo();
      const a = Math.max(0, Math.min(1, label.t * 6, (1.2 - label.t) * 3));
      ctx.save(); ctx.globalAlpha = a;
      ctx.font = '600 15px "IBM Plex Sans KR", sans-serif';
      const tw = ctx.measureText(label.text).width + (label.ic ? 36 : 18);
      let lx = d ? d.x - tw / 2 : 10; lx = Math.max(6, Math.min(G.sw - tw - 6, lx));
      const ly = Math.max(80, d ? headY(d) - 58 : 80);
      ctx.fillStyle = 'rgba(14,10,8,.88)'; rr(ctx, lx, ly, tw, 28, 7); ctx.fill();
      ctx.strokeStyle = label.side === 'h' ? 'rgba(255,210,140,.6)' : 'rgba(230,120,100,.6)'; ctx.lineWidth = 1.2; ctx.stroke();
      if (label.ic) drawIco(ctx, label.ic, lx + 7, ly + 5, 18, '#ffe2a8');
      ctx.fillStyle = '#fff2da'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillText(label.text, lx + (label.ic ? 30 : 9), ly + 14.5);
      ctx.restore(); void g;
    }
    function drawPops(dt) {
      ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      for (let i = pops.length - 1; i >= 0; i--) {
        const p = pops[i]; p.t += dt * Math.min(2.2, spd());
        if (p.t > p.life) { pops.splice(i, 1); continue; }
        const a = Math.min(1, (p.life - p.t) * 3), sc = p.t < 0.12 ? 1 + (0.12 - p.t) * 4 : 1;
        ctx.save(); ctx.globalAlpha = a; ctx.translate(p.x, p.y - p.t * 18); ctx.scale(sc, sc);
        ctx.font = '800 ' + p.size + 'px "IBM Plex Sans KR", sans-serif';
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.92)'; ctx.lineJoin = 'round';
        ctx.strokeText(p.text, 0, 0); ctx.fillStyle = p.color; ctx.fillText(p.text, 0, 0);
        if (p.sub) { ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.strokeText(p.sub, 0, -p.size - 2); ctx.fillStyle = '#ffd890'; ctx.fillText(p.sub, 0, -p.size - 2); }
        ctx.restore();
      }
      ctx.textAlign = 'left';
    }
    function drawBubbles(dt, g) {
      for (let i = bubbles.length - 1; i >= 0; i--) {
        const b = bubbles[i]; b.t += dt * Math.min(1.6, spd());
        if (b.t > b.life) { bubbles.splice(i, 1); continue; }
        const d = D[b.u]; if (!d) continue;
        const a = Math.min(1, (b.life - b.t) * 3, b.t * 8);
        ctx.save(); ctx.globalAlpha = Math.max(0, a);
        ctx.font = 'italic 13px "Noto Serif KR", serif';
        const lines = []; let cur = '';
        for (const w of b.text.split(' ')) { if (ctx.measureText(cur + ' ' + w).width > 150 && cur) { lines.push(cur); cur = w; } else cur = cur ? cur + ' ' + w : w; }
        if (cur) lines.push(cur);
        const tw = Math.max(...lines.map((l) => ctx.measureText(l).width)) + 16, th = lines.length * 17 + 10;
        const bx = Math.max(4, Math.min(G.sw - tw - 4, d.x - tw / 2)), by = Math.max(44, headY(d) - th - 22);
        ctx.fillStyle = b.bad ? 'rgba(46,14,12,.94)' : 'rgba(34,26,12,.94)'; rr(ctx, bx, by, tw, th, 7); ctx.fill();
        ctx.strokeStyle = b.bad ? 'rgba(240,130,110,.7)' : 'rgba(240,210,130,.7)'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.fillStyle = b.bad ? '#ffd2c6' : '#fbecc4'; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
        lines.forEach((l, k) => ctx.fillText(l, bx + 8, by + 18 + k * 17));
        ctx.restore();
      }
      void g;
    }
    function drawBanner(dt) {
      if (!banner) return;
      banner.t += dt * Math.min(1.5, spd());
      if (banner.t > banner.life) { banner = null; return; }
      const a = Math.min(1, banner.t * 4, (banner.life - banner.t) * 3);
      const y = G.sh * 0.3, hgt = 64;
      ctx.save(); ctx.globalAlpha = a;
      const gr = ctx.createLinearGradient(0, 0, G.sw, 0); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.2, 'rgba(8,5,4,.86)'); gr.addColorStop(0.8, 'rgba(8,5,4,.86)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = gr; ctx.fillRect(0, y, G.sw, hgt);
      ctx.strokeStyle = banner.c; ctx.globalAlpha = a * 0.5; ctx.beginPath(); ctx.moveTo(G.sw * 0.2, y + 0.5); ctx.lineTo(G.sw * 0.8, y + 0.5); ctx.moveTo(G.sw * 0.2, y + hgt - 0.5); ctx.lineTo(G.sw * 0.8, y + hgt - 0.5); ctx.stroke(); ctx.globalAlpha = a;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '26px "Black Han Sans", sans-serif'; ctx.fillStyle = banner.c; ctx.fillText(banner.title, G.sw / 2, y + (banner.sub ? 26 : 32));
      if (banner.sub) { ctx.font = '600 13px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#f0e2c8'; ctx.fillText(banner.sub, G.sw / 2, y + 50); }
      ctx.restore();
    }
    function drawFade(dt) {
      if (!fade) return;
      fade.t += dt * Math.min(1.5, spd());
      if (fade.t > fade.life) { fade = null; return; }
      const k = fade.t / fade.life, a = k < 0.3 ? k / 0.3 : k > 0.7 ? (1 - k) / 0.3 : 1;
      ctx.save(); ctx.globalAlpha = a * 0.92; ctx.fillStyle = '#050403'; ctx.fillRect(0, 0, G.sw, G.sh);
      ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '30px "Black Han Sans", sans-serif'; ctx.fillStyle = '#f4e2bc'; ctx.fillText(fade.txt, G.sw / 2, G.sh * 0.45);
      if (fade.sub) { ctx.font = '600 15px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#e0cba4'; ctx.fillText(fade.sub, G.sw / 2, G.sh * 0.45 + 30); }
      ctx.restore();
    }

    /* ---------- 입력: 장면 누르기 ---------- */
    cv.addEventListener('pointerdown', (ev) => {
      if (busy) { skipAll = true; return; }
      const s = S; if (!s) return;
      const r = cv.getBoundingClientRect(), x = ev.clientX - r.left, y = ev.clientY - r.top;
      const g = geo();
      if (y < g.gy - g.fh * 1.5 || y > g.gy + 40) return;
      let best = null, bd = 1e9;
      const tset = s.ph === 'fight' && mine() && sel >= 0 ? targetSet() : null;
      const pool = tset ? Object.keys(tset).map((k) => D[k]).filter(Boolean) : Object.values(D).filter((d) => d.side === 'h');
      for (const d of pool) { const dd = Math.abs(d.x - x); if (dd < bd) { bd = dd; best = d; } }
      if (!best || bd > Math.max(30, g.step * 0.6 * wOf(best))) return;
      if (tset) {
        const hh = s.pt.find((p) => p.u === s.fi.cur), si = hh.sk[sel];
        const tg = targetsFor(s, hh, si);
        let gI = -1;
        if (!tg.includes(-1)) gI = best.side === 'e' ? s.fi.en.findIndex((e) => e.u === best.u) : s.pt.findIndex((p) => p.u === best.u);
        act({ t: 'sk', i: sel, g: gI });
        return;
      }
      if (best.side === 'h' && s.ph !== 'fight') { const i = s.pt.findIndex((p) => p.u === best.u); if (i >= 0) openHero(i); }
    });

    /* 키보드 · 패드 */
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !S || !mine()) return;
      if (/^s[1-4]$/.test(id) && S.ph === 'fight') pickSkill(+id[1] - 1);
      else if (id === 'torch' && S.ph === 'map' && S.inv.torch > 0) act({ t: 'torch' });
      else if (id === 'items' && ['map', 'fight', 'camp'].includes(S.ph)) openItems(S.ph === 'fight');
    }) : null;

    /* ---------- 고리 ---------- */
    const stop = U.loop((dt) => {
      dt = Math.min(dt, 0.05);
      if (slow > 0) { slow -= dt; dt *= 0.25; }
      nowT += dt;
      stepPlay(dt);
      if (!G.sw) return;
      drawScene(dt);
    });
    layout();

    return {
      update(state, prev) {
        const first = !S;
        S = state;
        if (state.ph !== 'prep') prepD = null;
        if (first || !prev || !state.last || state.last.id === lastId || state.last.id < lastId) {
          lastId = state.last ? state.last.id : -1;
          if (!busy) { syncAll(state); shownLight = state.light; active = state.ph === 'fight' && state.fi ? state.fi.cur : 0; renderAll(); }
          return;
        }
        lastId = state.last.id;
        if (busy) { q.push(...(state.last.ev || [])); return; }
        sel = -1; campSel = null;
        if (ov && !ov._prep && !ov._way) closeOv();
        const evs = state.last.ev || [];
        if (!evs.length) { syncAll(state); shownLight = state.light; renderAll(); return; }
        updateTop();
        startPlay(evs);
        renderDock();
      },
      destroy() {
        stop(); ro.disconnect();
        if (offIn) offIn();
        window.removeEventListener('lounge-cancel', onCancel);
        clearTimeout(narTimer);
        try { api.setBusy(false); } catch (e) {}
        try { if (Snd.ac) Snd.ac.close(); } catch (e) {}
        wrap.remove();
      },
    };
  }
})();
(function () {  // 배포용 줄 → 조각:줄 (tools/parts_join.js가 만든 표)
  const P = window.MADEXP_PARTS || (window.MADEXP_PARTS = {}), M = [[1,"madexp",0],[3,"data",2],[480,"icons",2],[623,"engine",2],[1737,"ai",2],[2072,"art",2],[2891,"def",2],[3126,"view",2]], N = 4566;
  P.where = function (x) {
    const one = (ln) => { ln = +ln; let m = null; for (const e of M) if (e[0] <= ln) m = e; return m && m[1] !== 'madexp' && ln < N ? m[1] + '.js:' + (ln - m[0] + m[2]) : 'madexp.js'; };
    return typeof x === 'number' ? one(x) : String(x).replace(/madexp-joined\.js:(\d+)/g, (_, ln) => 'madexp/' + one(ln));
  };
})();
//# sourceURL=games/madexp-joined.js
