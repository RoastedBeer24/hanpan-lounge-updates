/* 낙오 장애물 쇼 (dropout) — 2~32명이 장애물 코스 · 생존 · 팀 미니게임을 여러 판 거쳐 마지막 한 명이 남는 3D 파티 탈락 쇼.
   시스템만 참고(장애물 레이스 탈락 쇼 장르) — 캐릭터 · 이름 · 판 구성 · 화면은 모두 직접 만든 것.

   파일 구성 (결정 사항: docs/DECISIONS.md 「낙오 장애물 쇼」)
   - 이 파일: 순수 로직(노드 시험 가능) — 판 종류 · 판 만들기(씨앗 → 결정적) · 충돌 세계 · 캐릭터 물리 · 호스트 판정(바닥 타일 · 문 · 시소 · 공 · 알 · 언덕)
     · AI(상황 점수 + 봇마다 씨앗 버릇) · 쇼 진행(판 수 · 통과 인원 · 탈락) · 결과 · 규칙 · 도감 · L.register — 와 가벼운 입구 화면.
   - assets/dropout/view.js: 3D 화면(three.js — 하이퍼 레이스가 싣는 assets/hyperrace/lib/three.min.js를 같이 씀) · 조작 · HUD · 소리 · 온라인.
   온라인: 기기마다 자기 캐릭터를 직접 시뮬(호스트는 봇까지)하고 15Hz로 알림. 판 위 물건(무너지는 타일 · 문 · 시소 · 공 · 알 · 언덕 점수)과
   통과/탈락 판정은 호스트가 정해 hostSend로, 판 단계 · 결과는 api.setState로. 움직이는 장애물은 판 시계의 순수 함수라 모든 기기에서 같음. */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const L = G.Lounge;

  /* ======================= 물리 상수 ======================= */
  const DT = 1 / 60, GRAV = 28, RUN = 6.4, ACC_G = 46, ACC_A = 15, JUMP_V = 9.4, RAD = 0.42, HGT = 1.35, LOW = 0.72, STEP = 0.42, DIVE_V = 9.4, CELL = 4;
  const ST = { RUN: 0, DIVE: 1, SLIDE: 2, TUMB: 3, UP: 4, RESP: 5, OUT: 6, FIN: 7 };
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function shuffle(R, a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); const x = a[i]; a[i] = a[j]; a[j] = x; } return a; }

  /* ======================= 판 종류 ======================= */
  /* 글 문체: 방송 규칙 카드처럼 짧은 개조식 명사형(느낌표 · 의성어 · 귀여운 말투 없음) — 사용자 지시 2026-11-19 */
  const TYPES = {
    obst: { nm: '장애물 레이스', k: 'race', col: '#ff6a3d', d: '회전 바 · 진자 해머 · 측면 피스톤 · 낙구 경사로를 지나 결승선 통과. 정원이 차면 종료, 미통과자 탈락.' },
    doors: { nm: '게이트 러시', k: 'race', col: '#f0b429', d: '게이트 벽마다 열리는 문과 고정된 가짜 문이 섞여 있음. 먼저 열린 문을 따라가는 것도 방법.' },
    hop: { nm: '스카이 브리지', k: 'race', col: '#36c5d6', d: '이동 발판 · 시소 · 회전 플랫폼 · 점프 발판을 건너는 공중 코스. 낙하 시 마지막 체크포인트에서 재개.' },
    tiles: { nm: '붕괴 플로어', k: 'surv', col: '#9b7bff', d: '밟은 패널은 잠시 뒤 붕괴. 인원이 많으면 아래층 추가. 정해진 인원이 떨어질 때까지 생존하면 통과.' },
    sweep: { nm: '스윕 바', k: 'surv', col: '#ff3d6e', d: '낮은 회전 바는 점프, 높은 회전 바는 다이브로 통과. 시간이 갈수록 가속. 원형 무대 밖으로 밀리면 탈락.' },
    slime: { nm: '라이징 타워', k: 'surv', col: '#4fd18b', d: '나선 계단을 올라 정상 도달. 아래에서 차오르는 액체에 닿으면 탈락.' },
    ball: { nm: '빅 볼 매치', k: 'team', col: '#3d8bfd', d: '두 팀이 대형 볼을 상대 골문에 밀어 넣는 경기. 종료 시 패배 팀 전원 탈락. 동점이면 골든골 연장.' },
    eggs: { nm: '코어 쟁탈전', k: 'team', col: '#f0b429', d: '코어를 들고 자기 팀 거점으로 운반. 상대 거점에서 탈취, 운반자는 다이브 · 잡기로 저지. 최저 득점 팀 탈락.' },
    hex: { nm: '헥스 폴', k: 'final', col: '#ff3d6e', d: '결승. 밟으면 무너지는 육각 패널이 여러 층. 최후의 1인이 우승.' },
    hill: { nm: '고지 점령', k: 'final', col: '#ff8a3d', d: '결승. 중앙 고지 위 누적 25초를 먼저 채우면 우승. 회전 바와 몸싸움으로 밀려남.' },
    crown: { nm: '트로피 쟁탈', k: 'final', col: '#ffd34d', d: '결승. 나선 탑 정상 위를 떠도는 트로피를 가장 먼저 잡으면 우승.' },
  };
  const QTYPES = ['obst', 'doors', 'hop', 'tiles', 'sweep', 'slime', 'ball', 'eggs'], FTYPES = ['hex', 'hill', 'crown'];
  const KIND_NM = { race: '레이스', surv: '서바이벌', team: '팀전', final: '결승' };
  const TEAM_COL = ['#ff4d4d', '#3d8bfd', '#f0b429', '#2ec27e'], TEAM_NM = ['레드', '블루', '골드', '그린'];

  /* ======================= 꾸미기 (이 기기에 저장, 온라인엔 5글자 코드) ======================= */
  /* 참가자 모습: 둥근 모서리 몸통 + 얼굴 바이저(헬멧형) — 경기복 색 */
  const LOOK = {
    cols: ['#e63946', '#f77f00', '#fcbf49', '#2a9d8f', '#4cc9f0', '#3a6ff7', '#7b2cbf', '#d81159', '#06d6a0', '#8d99ae', '#edf2f4', '#2b2d42', '#111111', '#b08d57', '#c9d6df', '#5f0f40'],
    pats: ['단색', '가로 띠', '도트', '좌우 분할', '체커', '번개 띠', '가슴 패널', '세로 줄'],
    accs: ['없음', '안테나', '측면 핀', '헤드셋', '헬멧 리지', '등 장비'],
    eyes: ['흑요석 바이저', '금빛 바이저', '은빛 바이저', '청록 바이저'],
  };
  const b36 = (v) => v.toString(36);
  function lookCode(o) { return b36(o.c1 & 15) + b36(o.c2 & 15) + b36(o.pat & 7) + b36(o.acc % 6) + b36(o.eye & 3); }
  function lookParse(s) {
    s = String(s || '');
    if (!/^[0-9a-z]{5}$/.test(s)) return null;
    const v = [...s].map((ch) => parseInt(ch, 36));
    return { c1: v[0] & 15, c2: v[1] & 15, pat: v[2] & 7, acc: v[3] % 6, eye: v[4] & 3 };
  }
  function lookRand(R) { const c1 = Math.floor(R() * 16); let c2 = Math.floor(R() * 16); if (c2 === c1) c2 = (c1 + 5) % 16; return { c1, c2, pat: Math.floor(R() * 8), acc: Math.floor(R() * 6), eye: Math.floor(R() * 4) }; }
  const store = { get(k, d) { try { const v = localStorage.getItem('dropout.' + k); return v == null ? d : v; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('dropout.' + k, v); } catch (e) {} } };
  function myLook() { const p = lookParse(store.get('look', '')); if (p) return p; const r = lookRand(Math.random); store.set('look', lookCode(r)); return r; }

  /* ======================= 판 만들기 (씨앗 → 결정적) ======================= */
  /* 무대 색: 방송 스튜디오 · 경기장 조명(밝은 갑판 + 짙은 구조물 + 강조색 하나 + 위험 주황/빨강) */
  const PALS = [
    { nm: 'gold', a: 0xdfe3e8, b: 0x4d5b78, c: 0x7383a3, d: 0xf0b429, h: 0xff4d2e, w: 0x1b1f2a, pit: 0x0b1d33, sky: [0x070b1c, 0x283a66], night: 1 },
    { nm: 'blue', a: 0xe9eef5, b: 0x2f63c4, c: 0x4a8be6, d: 0x36c5d6, h: 0xff3d6e, w: 0x141a2e, pit: 0x081426, sky: [0x0b1433, 0x4a6fa5], night: 1 },
    { nm: 'red', a: 0xeceae6, b: 0xa8364f, c: 0xcf5a70, d: 0xffd34d, h: 0xff6a3d, w: 0x1e1418, pit: 0x1a0d14, sky: [0x1a0c1c, 0x7a3b4f], night: 1 },
    { nm: 'day', a: 0xf3f4f6, b: 0x30475e, c: 0x5b7c99, d: 0xf0b429, h: 0xff4d2e, w: 0x222831, pit: 0x16506a, sky: [0x2f6aa8, 0xc9dff0], night: 0 },
  ];
  function addS(lev, o) {
    o.i = lev.S.length;
    if (o.a == null) o.a = 0;
    if (o.p == null) o.p = 0;
    o.ca = Math.cos(o.a); o.sa = Math.sin(o.a); o.tp = Math.tan(o.p); o.cp = Math.cos(o.p);
    o.vx = o.vy = o.vz = o.w = 0; o.px0 = o.x; o.pz0 = o.z; o.off = 0;
    if (o.tile == null) o.tile = -1;
    if (o.door == null) o.door = -1;
    if (o.ssi == null) o.ssi = -1;
    if (o.bi == null) o.bi = -1;
    if (o.m == null) o.m = null;
    lev.S.push(o);
    if (o.y - (o.hy || o.r || 0) < lev.minY) lev.minY = o.y - (o.hy || o.r || 0);
    return o;
  }
  const BX = (lev, x, y, z, sx, sy, sz, o) => addS(lev, Object.assign({ k: 0, x, y, z, hx: sx / 2, hy: sy / 2, hz: sz / 2 }, o));
  const PL = (lev, x, top, z, sx, sz, o) => { const th = (o && o.th) || 1; return BX(lev, x, top - th / 2, z, sx, th, sz, Object.assign({ vis: 'plat' }, o)); };
  const CY = (lev, x, top, z, r, h, o) => addS(lev, Object.assign({ k: 1, x, y: top - h / 2, z, r, hy: h / 2 }, o));
  const SP = (lev, x, y, z, r, o) => addS(lev, Object.assign({ k: 2, x, y, z, r }, o));

  function newLev(type, seed, n, nT) {
    const R = prng(seed);
    const pal = PALS[Math.floor(R() * PALS.length)];
    return { type, k: TYPES[type].k, seed, n, nT: nT || 0, R, pal, S: [], sp: [], cps: [], killY: -8, minY: 0, finZ: null, finY: 0, deco: [], fwd: null, dur: 120, resp: 0,
      tiles: 0, tdel: 0.75, tg: null, hex: null, doors: [], drows: [], ss: 0, ssInit: [], balls: 0, field: null, goals: null, nests: null, egg0: null, zone: null, crown: null, slime: null, steps: null, W: 14, ctr: { x: 0, y: 0, z: 0, r: 20 } };
  }
  function spawnGrid(lev, R, cx, cy, cz, w, dir, maxRows) {
    const per = Math.max(2, Math.floor((w - 1.4) / 1.25)), rows = Math.ceil(lev.n / per);
    const out = [];
    for (let r = 0; r < Math.max(rows, maxRows || 0); r++) for (let i = 0; i < per; i++) out.push([cx + (i - (per - 1) / 2) * 1.25 + (r % 2) * 0.3, cy + 0.05, cz - dir * r * 1.4, dir > 0 ? 0 : Math.PI]);
    lev.sp = out;
  }

  /* --- 레이스 코스 조각 (z 방향으로 이어 붙임; 반환 = 끝 z · 높이) --- */
  const SEG = {
    spin(lev, R, z, y, W) {
      const p = lev.pal, two = W >= 13, hl = (two ? W / 4 : W / 2) - 0.25, gap = 2 * hl + 0.9, rows = 2, Ls = rows * gap + 1;
      PL(lev, 0, y, z + Ls / 2, W, Ls, { col: p.b });
      for (let r = 0; r < rows; r++) {
        const zz = z + 0.5 + gap * (r + 0.5);
        for (const xx of two ? [-W / 4, W / 4] : [0]) {
          CY(lev, xx, y + 1.2, zz, 0.4, 1.2, { col: p.w, vis: 'pillar' });
          const w = (R() < 0.5 ? -1 : 1) * (1.0 + R() * 0.6);
          BX(lev, xx, y + 0.5, zz, 2 * hl, 0.34, 0.36, { col: p.h, vis: 'bar', hit: 1, m: { t: 'spin', px: xx, pz: zz, w, a0: R() * TAU, ox: 0 } });
        }
      }
      return { z: z + Ls, y };
    },
    hammer(lev, R, z, y, W) {
      const p = lev.pal, Ls = 20;
      PL(lev, 0, y, z + Ls / 2, W, Ls, { col: p.a });
      for (let i = 0; i < 3; i++) {
        const zz = z + 3.5 + i * 6.5, ln = 6.2, py = y + 7.6, amp = Math.min(1.2, Math.asin(Math.min(0.97, (W / 2 + 0.6) / ln))), per = 2.3 + R() * 1.1;
        SP(lev, 0, py - ln, zz, 1.05, { col: p.h, vis: 'hammer', hit: 1, m: { t: 'pend', px: 0, py, pz: zz, L: ln, amp, per, ph: R() * TAU, ux: 1, uz: 0 } });
        lev.deco.push({ k: 'frame', x: 0, y, z: zz, w: W + 1.2, h: py + 0.5 - y, col: p.w });
      }
      return { z: z + Ls, y };
    },
    movers(lev, R, z, y, W) {
      const p = lev.pal, rows = 3, sp = 4.6, nc = W >= 13 ? 3 : 2, cw = W / nc, ps = Math.min(3.2, cw - 0.4);
      for (let r = 0; r < rows; r++) {
        const zz = z + 2.4 + r * sp;
        for (let c = 0; c < nc; c++) {
          const xx = -W / 2 + cw * (c + 0.5), k = R(), by = y - 0.3;
          const o = { col: [p.b, p.c, p.d][(r + c) % 3], vis: 'mplat', th: 0.6 };
          if (k < 0.36) o.m = { t: 'slide', bx: xx, by, bz: zz, dx: Math.min(1.5, cw * 0.32), dy: 0, dz: 0, per: 2.8 + R() * 1.4, ph: R() * TAU };
          else if (k < 0.62) o.m = { t: 'slide', bx: xx, by, bz: zz, dx: 0, dy: 0, dz: 0.9, per: 3 + R() * 1.2, ph: R() * TAU };
          else if (k < 0.8) o.m = { t: 'slide', bx: xx, by, bz: zz, dx: 0, dy: 0.5, dz: 0, per: 2.6 + R(), ph: R() * TAU };
          PL(lev, xx, y, zz, ps, ps, o);
        }
      }
      return { z: z + 2.4 + (rows - 1) * sp + 2.4, y };
    },
    conveyor(lev, R, z, y, W) {
      const p = lev.pal, Ls = 18;
      PL(lev, 0, y, z + Ls / 2, W, Ls, { col: p.d, vis: 'conv', cv: [0, -2.3] });
      for (let i = 0; i < 4; i++) CY(lev, (R() - 0.5) * (W - 3), y + 1.1, z + 3 + i * 3.6 + R() * 1.4, 0.6, 1.1, { col: p.w, vis: 'bumper', bnc: 7 });
      return { z: z + Ls, y };
    },
    seesaw(lev, R, z, y, W) {
      const p = lev.pal, lanes = W >= 13 ? 2 : 1, n = 3, len = 7, gap = 0.7, sw = Math.min(4.6, W / lanes - 1.2);
      for (let l = 0; l < lanes; l++) for (let i = 0; i < n; i++) {
        const xx = lanes === 2 ? (l ? W / 4 : -W / 4) : 0, zz = z + gap + len / 2 + i * (len + gap);
        BX(lev, xx, y - 0.25, zz, sw, 0.5, len, { col: [p.b, p.c][(i + l) % 2], vis: 'seesaw', m: { t: 'ss' }, ssi: lev.ss });
        lev.ssInit.push(((i + l) % 2 ? 1 : -1) * 0.2); lev.ss++;
        lev.deco.push({ k: 'pivot', x: xx, y: y - 0.5, z: zz, w: sw, col: p.w });
      }
      return { z: z + gap + n * (len + gap), y };
    },
    doors(lev, R, z, y, W) {
      const p = lev.pal, Ls = 14, M = Math.max(3, Math.round(W / 2.3)), dw = W / M, zz = z + 7;
      PL(lev, 0, y, z + Ls / 2, W, Ls, { col: p.a });
      const nReal = Math.max(1, Math.round(M * 0.42)), reals = shuffle(R, [...Array(M).keys()]).slice(0, nReal);
      const row = lev.drows.length; lev.drows.push({ z: zz, y, list: [] });
      for (let i = 0; i < M; i++) {
        const xx = -W / 2 + dw * (i + 0.5), real = reals.includes(i), di = lev.doors.length;
        BX(lev, xx, y + 2.1, zz, dw - 0.06, 4.2, 0.5, { col: p.d, vis: 'door', door: di, df: real ? 0 : 1, row });
        lev.doors.push({ x: xx, z: zz, y, w: dw, real, row });
        lev.drows[row].list.push(di);
      }
      lev.deco.push({ k: 'dframe', x: 0, y, z: zz, w: W, col: p.w });
      return { z: z + Ls, y };
    },
    punch(lev, R, z, y, W) {
      const p = lev.pal, Ls = 18;
      PL(lev, 0, y, z + Ls / 2, W, Ls, { col: p.a });
      let side = R() < 0.5 ? 1 : -1;
      for (let i = 0; i < 4; i++) {
        side = -side;
        const zz = z + 2.8 + i * 4.1, len = W * 0.6, bx = side * (W / 2 + 0.9);
        BX(lev, side * (W / 2 + 2.4), y + 1, zz, 2, 2.4, 2.4, { col: p.w, vis: 'housing' });
        BX(lev, bx, y + 0.95, zz, 1.8, 1.7, 1.7, { col: p.h, vis: 'punch', hit: 1, m: { t: 'punch', bx, bz: zz, dx: -side, dz: 0, len, per: 2.2 + R() * 0.9, ph: R() * 3 } });
      }
      return { z: z + Ls, y };
    },
    roll(lev, R, z, y, W) {
      const p = lev.pal, Ls = 20, rise = 3.2, sl = rise / Ls, pa = Math.atan(sl), ln = Math.hypot(Ls, rise);
      BX(lev, 0, y + rise / 2 - 0.5 / Math.cos(pa), z + Ls / 2, W, 1.0, ln, { col: p.c, vis: 'ramp', p: pa });
      const nl = Math.max(2, Math.floor(W / 3.6)), lw = W / nl;
      for (let i = 0; i < nl; i++) {
        const P_ = 2.8 + R() * 1.6, xx = -W / 2 + lw * (i + 0.5);
        SP(lev, xx, y + rise + 1, z + Ls, 0.95, { col: [p.h, p.d, p.w][i % 3], vis: 'roller', hit: 1, m: { t: 'roll', x: xx, zt: z + Ls + 0.4, zb: z + 1.0, z0: z, y0: y, sl, v: 6.0 + R() * 1.4, P: P_, ph: R() * P_, r: 0.95 } });
      }
      return { z: z + Ls, y: y + rise };
    },
    discs(lev, R, z, y, W) {
      const p = lev.pal, lanes = W >= 14 ? 2 : 1, r = lanes === 2 ? Math.min(3.1, W / 4 - 0.15) : Math.min(3.3, W / 2 - 0.3), n = 3, gap = 0.35;
      for (let l = 0; l < lanes; l++) for (let i = 0; i < n; i++) {
        const xx = lanes === 2 ? (l ? W / 4 : -W / 4) : 0, zz = z + gap + r + i * (2 * r + gap), w = ((i + l) % 2 ? 1 : -1) * (0.7 + R() * 0.45);
        CY(lev, xx, y, zz, r, 0.7, { col: [p.b, p.c, p.d][i % 3], vis: 'disc', m: { t: 'spin', px: xx, pz: zz, w, a0: 0, ox: 0 } });
        CY(lev, xx, y + 0.9, zz, 0.45, 0.9, { col: p.w, vis: 'bumper', bnc: 6 });
      }
      return { z: z + gap + n * (2 * r + gap), y };
    },
    gaps(lev, R, z, y, W) {
      const p = lev.pal, rows = 4, sp = 3.9, nc = Math.max(2, Math.round(W / 4.2)), cw = W / nc;
      for (let r = 0; r < rows; r++) for (let c = 0; c < nc; c++) {
        if (c > 0 && R() < 0.18) continue;
        const hh = [0, 0.6, 1.0, 0.3][(r + c) % 4] * (R() < 0.5 ? 1 : 0.6);
        PL(lev, -W / 2 + cw * (c + 0.5) + (R() - 0.5) * 0.8, y + hh, z + 2 + r * sp, 2.4, 2.4, { col: [p.b, p.c, p.d][(r + c) % 3], vis: 'stone', th: 1.2 + hh });
      }
      return { z: z + 2 + (rows - 1) * sp + 2, y };
    },
  };
  const SEG_NM = { spin: '회전 바', hammer: '진자 해머', movers: '이동 발판', conveyor: '역방향 컨베이어', seesaw: '시소', doors: '게이트 벽', punch: '측면 피스톤', roll: '낙구 경사로', discs: '회전 플랫폼', gaps: '점프 발판' };
  const RACE_POOL = { obst: ['spin', 'hammer', 'punch', 'roll', 'conveyor', 'discs'], hop: ['movers', 'seesaw', 'discs', 'gaps', 'movers'] };

  function genRace(lev, R) {
    const n = lev.n, W = clamp(9 + n * 0.32, 10, 19.5), p = lev.pal, nSeg = n > 16 ? 6 : 5;
    lev.W = W; lev.fwd = 0; lev.resp = 1; lev.dur = 100 + nSeg * 12;
    PL(lev, 0, 0, 6, W + 2, 12, { col: p.a, vis: 'start' });
    spawnGrid(lev, R, 0, 0, 9, W, 1);
    let z = 12, y = 0;
    const segs = [];
    if (lev.type === 'doors') { const o = shuffle(R, ['conveyor', 'punch', 'spin', 'hammer']); segs.push('doors', o[0], 'doors', o[1]); if (nSeg > 4) segs.push('doors'); }
    else { const pool = RACE_POOL[lev.type]; let last = ''; for (let i = 0; i < nSeg; i++) { let k; let g = 0; do { k = pool[Math.floor(R() * pool.length)]; } while ((k === last || (segs.includes(k) && g++ < 6)) && g < 12); segs.push(k); last = k; } }
    lev.segs = segs;
    for (const k of segs) {
      lev.cps.push({ z: z - 1.5, y, x0: -W / 2 + 1.2, x1: W / 2 - 1.2 });
      const r = SEG[k](lev, R, z, y, W);
      z = r.z; y = r.y;
      PL(lev, 0, y, z + 1.5, W, 3, { col: p.c, vis: 'plat' });
      z += 3;
    }
    PL(lev, 0, y, z + 8, W + 4, 16, { col: p.a, vis: 'finish' });
    lev.finZ = z + 2; lev.finY = y;
    lev.deco.push({ k: 'arch', x: 0, y, z: z + 2, w: W + 4, col: p.d });
    lev.killY = lev.minY - 7;
    lev.ctr = { x: 0, y: y / 2, z: (z + 16) / 2, r: (z + 16) / 2 + 4 };
  }
  /* 나선 탑 (점액 · 왕관) */
  function genTower(lev, R, H, crown) {
    const p = lev.pal, n = lev.n, lanes = n > 14 ? 2 : 1, rad = 6.6, dth = 0.6, dy = 0.92, steps = Math.ceil(H / dy) - 1, ps = 3.3;
    CY(lev, 0, 0, 0, 10.5, 1.2, { col: p.a, vis: 'ground' });
    CY(lev, 0, H - 0.3, 0, 2.6, H + 0.8, { col: p.w, vis: 'column' });
    const topS = CY(lev, 0, H, 0, 4.4, 0.6, { col: p.d, vis: 'top', goal: 1 });
    lev.top = { y: H, r: 4.4, i: topS.i };
    lev.steps = [];
    for (let l = 0; l < lanes; l++) {
      const a0 = l * Math.PI + R() * 0.3, path = [];
      for (let i = 0; i < steps; i++) {
        const th = a0 + i * dth, top = (i + 1) * dy, x = Math.sin(th) * rad, z = Math.cos(th) * rad, land = (i + 1) % 7 === 0;
        const o = { col: land ? p.c : [p.b, p.a][i % 2], vis: land ? 'land' : 'step', a: th, th: 0.6, step: i, lane: l, cp: land ? lev.cps.length : -1 };
        if (!land && i % 5 === 3) o.m = { t: 'slide', bx: x, by: top - 0.3, bz: z, dx: Math.sin(th) * 0.8, dy: 0, dz: Math.cos(th) * 0.8, per: 2.8 + R(), ph: R() * TAU };
        const sz = land ? 4.4 : ps;
        PL(lev, x, top, z, sz, sz, o);
        if (land) {
          lev.cps.push({ x, y: top, z, r: 1.2, step: i, lane: l });
          if (crown) BX(lev, x, top + 0.5, z, 4.0, 0.32, 0.34, { col: p.h, vis: 'bar', hit: 1, m: { t: 'spin', px: x, pz: z, w: (R() < 0.5 ? -1 : 1) * 1.3, a0: R() * TAU, ox: 0 } });
        }
        path.push({ x, y: top, z, i });
      }
      lev.steps.push(path);
    }
    // 바닥 원판 위 출발 자리(첫 계단 근처)
    const out = [];
    for (let k = 0; k < Math.max(lev.n, 8); k++) {
      const lane = k % lanes, path = lev.steps[lane], th = Math.atan2(path[0].x, path[0].z) - 0.9 - Math.floor(k / lanes) * 0.16, r = 7.6 + (k % 3) * 0.8;
      out.push([Math.sin(th) * r, 0.05, Math.cos(th) * r, th + Math.PI / 2]);
    }
    lev.sp = out;
    lev.ctr = { x: 0, y: H / 2, z: 0, r: 16 };
    lev.H = H;
  }
  function genTiles(lev, R) {
    const p = lev.pal, n = lev.n, N = clamp(Math.ceil(Math.sqrt(n * 18)), 9, 20), layers = n >= 16 ? 3 : n >= 6 ? 2 : 1, sz = 2.1, x0 = -N * sz / 2, z0 = -N * sz / 2, ys = [0, -6, -12].slice(0, layers);
    lev.tg = { N, sz, x0, z0, ys }; lev.tdel = 0.9;
    for (let l = 0; l < layers; l++) for (let iz = 0; iz < N; iz++) for (let ix = 0; ix < N; ix++)
      PL(lev, x0 + sz * (ix + 0.5), ys[l], z0 + sz * (iz + 0.5), sz - 0.12, sz - 0.12, { col: [[p.a, p.b], [p.d, p.c], [p.h, p.c]][l][(ix + iz) % 2], vis: 'tile', th: 0.5, tile: lev.tiles++ });
    lev.nb = [];
    for (let i = 0; i < lev.tiles; i++) {
      const l = Math.floor(i / (N * N)), r = i % (N * N), iz = Math.floor(r / N), ix = r % N, a = [];
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if ((dx || dz) && ix + dx >= 0 && ix + dx < N && iz + dz >= 0 && iz + dz < N) a.push(l * N * N + (iz + dz) * N + ix + dx);
      lev.nb.push(a);
    }
    const cells = shuffle(R, [...Array(N * N).keys()]);
    lev.sp = cells.slice(0, Math.max(n, 8)).map((c) => [x0 + sz * (c % N + 0.5), 0.05, z0 + sz * (Math.floor(c / N) + 0.5), R() * TAU]);
    lev.killY = ys[ys.length - 1] - 5; lev.dur = 100;
    lev.ctr = { x: 0, y: -2, z: 0, r: N * sz * 0.75 + 4 };
  }
  function genHex(lev, R) {
    const p = lev.pal, n = lev.n, rings = clamp(3 + Math.ceil(n / 2.4), 4, 9), layers = n <= 3 ? 2 : 3, hs = 1.25, ap = hs * Math.sqrt(3) / 2, ys = [0, -7, -14].slice(0, layers);
    lev.hex = { hs, rings, ys, map: {} }; lev.tdel = 0.6;
    const cols = [[p.d, p.b], [p.c, p.a], [p.h, p.b]];
    const ax = [];
    for (let q = -rings; q <= rings; q++) for (let r = -rings; r <= rings; r++) if (Math.abs(q + r) <= rings) ax.push([q, r]);
    for (let l = 0; l < layers; l++) for (const [q, r] of ax) {
      const x = hs * 1.5 * q * 1.03, z = hs * Math.sqrt(3) * (r + q / 2) * 1.03;
      lev.hex.map[q + ',' + r + ',' + l] = lev.tiles;
      CY(lev, x, ys[l], z, ap * 0.99, 0.5, { col: cols[l][(q - r + 300) % 2], vis: 'hex', tile: lev.tiles++, a: Math.PI / 6 });
    }
    lev.nb = [];
    const dirs = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];
    for (let l = 0; l < layers; l++) for (const [q, r] of ax) lev.nb.push(dirs.map(([a, b]) => lev.hex.map[(q + a) + ',' + (r + b) + ',' + l]).filter((v) => v != null));
    const cells = shuffle(R, ax.slice());
    lev.sp = cells.slice(0, Math.max(n, 8)).map(([q, r]) => [hs * 1.5 * q * 1.03, 0.05, hs * Math.sqrt(3) * (r + q / 2) * 1.03, R() * TAU]);
    lev.killY = ys[ys.length - 1] - 6; lev.dur = 240;
    lev.ctr = { x: 0, y: -5, z: 0, r: rings * 2.2 + 8 };
  }
  function genSweep(lev, R) {
    const p = lev.pal, n = lev.n, Rd = clamp(6 + n * 0.12, 6.5, 10);
    CY(lev, 0, 0, 0, Rd, 1.2, { col: p.a, vis: 'arena' });
    CY(lev, 0, 2.6, 0, 0.8, 2.6, { col: p.w, vis: 'pillar' });
    const arm = (y, h, a0, t0, col) => BX(lev, 0.8 + (Rd + 0.2) / 2, y, 0, Rd + 0.2, h, 0.42, { col, vis: 'sweeper', hit: 1, hi: y > 1 ? 1 : 0, m: { t: 'sweep', px: 0, pz: 0, ox: 0.8 + (Rd + 0.2) / 2, w0: 0.75, k: 0.02, w1: 2.1, dir: 1, a0, t0 } });
    arm(0.5, 0.36, 0, 0, p.h);
    arm(1.32, 0.5, 2.2, 18, p.w);
    arm(0.5, 0.36, Math.PI, 42, p.h);
    lev.Rd = Rd; lev.killY = -6; lev.dur = 95;
    const out = [];
    for (let k = 0; k < Math.max(n, 8); k++) { const a = Math.PI / 2 + 0.55 + k / Math.max(n, 8) * (TAU - 1.1), r = 2.2 + (k % 3) * (Rd - 3.2) / 3; out.push([Math.sin(a) * r, 0.05, Math.cos(a) * r, a + Math.PI]); }
    lev.sp = out;
    lev.ctr = { x: 0, y: 1, z: 0, r: Rd + 6 };
  }
  function genHill(lev, R) {
    const p = lev.pal, Rd = 11;
    CY(lev, 0, 0, 0, Rd, 1.4, { col: p.a, vis: 'arena' });
    const hs = CY(lev, 0, 1.0, 0, 3.2, 2.4, { col: p.d, vis: 'hill' });
    for (let k = 0; k < 2; k++) BX(lev, 3.3 + (Rd + 0.8 - 3.3) / 2, 0.5, 0, Rd + 0.8 - 3.3, 0.36, 0.42, { col: p.h, vis: 'sweeper', hit: 1, m: { t: 'sweep', px: 0, pz: 0, ox: 3.3 + (Rd + 0.8 - 3.3) / 2, w0: 0.6, k: 0.008, w1: 1.35, dir: 1, a0: k * Math.PI, t0: 8 } });
    lev.zone = { x: 0, z: 0, r: 3.1, y: 1.0, need: 25, i: hs.i };
    lev.resp = 1; lev.killY = -6; lev.dur = 160; lev.Rd = Rd;
    const out = [];
    for (let k = 0; k < Math.max(lev.n, 8); k++) { const a = k / Math.max(lev.n, 8) * TAU, r = 8.6 + (k % 2) * 1.1; out.push([Math.sin(a) * r, 0.05, Math.cos(a) * r, a + Math.PI]); }
    lev.sp = out;
    lev.ctr = { x: 0, y: 1, z: 0, r: Rd + 6 };
  }
  function genBall(lev, R) {
    const p = lev.pal, n = lev.n, Lf = clamp(30 + n * 0.7, 32, 52), Wf = clamp(18 + n * 0.4, 20, 32), gw = clamp(8 + n * 0.12, 8, 12);
    PL(lev, 0, 0, 0, Wf + 1, Lf + 1, { col: p.a, vis: 'pitch' });
    for (const sz of [-1, 1]) PL(lev, 0, 0, sz * (Lf / 2 + 2.3), gw + 1.6, 4.0, { col: p.b, vis: 'plat' });
    lev.deco.push({ k: 'bank', W: Wf, L: Lf, gw, col: p.b });
    const rail = { col: p.w, vis: 'rail' };
    BX(lev, -Wf / 2 - 0.4, 0.8, 0, 0.8, 1.6, Lf + 1.6, rail); BX(lev, Wf / 2 + 0.4, 0.8, 0, 0.8, 1.6, Lf + 1.6, rail);
    const seg = (Wf - gw) / 2;
    for (const sz of [-1, 1]) {
      const zz = sz * Lf / 2;
      BX(lev, -(gw / 2 + seg / 2), 0.8, zz, seg, 1.6, 0.8, rail); BX(lev, gw / 2 + seg / 2, 0.8, zz, seg, 1.6, 0.8, rail);
      BX(lev, 0, 1.5, sz * (Lf / 2 + 4.0), gw + 1.6, 3, 0.6, { col: TEAM_COL[sz < 0 ? 0 : 1] === undefined ? p.w : 0xffffff, vis: 'net' });
      BX(lev, -(gw / 2 + 0.4), 1.5, sz * (Lf / 2 + 2.1), 0.6, 3, 3.6, { col: 0xffffff, vis: 'net' }); BX(lev, gw / 2 + 0.4, 1.5, sz * (Lf / 2 + 2.1), 0.6, 3, 3.6, { col: 0xffffff, vis: 'net' });
    }
    lev.field = { W: Wf, L: Lf, gw };
    lev.goals = [{ z: -Lf / 2, team: 0 }, { z: Lf / 2, team: 1 }];   // 팀 0은 -z 골문을 지키고 +z로 넣음
    lev.balls = n >= 14 ? 2 : 1;
    for (let b = 0; b < lev.balls; b++) SP(lev, 0, 1.5, 0, 1.5, { col: 0xffffff, vis: 'ball', bi: b, m: { t: 'ball', i: b } });
    lev.dur = 90; lev.killY = -6;
    lev.ctr = { x: 0, y: 0, z: 0, r: Lf * 0.55 + 4 };
  }
  function genEggs(lev, R) {
    const p = lev.pal, n = lev.n, S = clamp(24 + n * 0.45, 26, 40), T = Math.max(2, lev.nT || 2);
    PL(lev, 0, 0, 0, S, S, { col: p.a, vis: 'pitch' });
    const rail = { col: p.w, vis: 'rail' };
    BX(lev, -S / 2 - 0.4, 0.7, 0, 0.8, 1.4, S + 1.6, rail); BX(lev, S / 2 + 0.4, 0.7, 0, 0.8, 1.4, S + 1.6, rail);
    BX(lev, 0, 0.7, -S / 2 - 0.4, S, 1.4, 0.8, rail); BX(lev, 0, 0.7, S / 2 + 0.4, S, 1.4, 0.8, rail);
    const c = S / 2 - 4.5;
    const spots = T === 2 ? [[0, -c], [0, c]] : T === 3 ? [[-c, -c], [c, -c], [0, c]] : [[-c, -c], [c, -c], [c, c], [-c, c]];
    lev.nests = spots.map(([x, z], t) => ({ x, z, r: 3.2, team: t }));
    const E = Math.round(clamp(n * 1.6 + 6, 12, 60));
    lev.egg0 = [];
    for (let i = 0; i < E; i++) { const a = R() * TAU, r = Math.sqrt(R()) * S * 0.28; lev.egg0.push([Math.sin(a) * r, Math.cos(a) * r]); }
    lev.field = { W: S, L: S }; lev.dur = 80; lev.killY = -6;
    lev.ctr = { x: 0, y: 0, z: 0, r: S * 0.6 + 4 };
  }
  function genLevel(type, seed, n, nT) {
    const lev = newLev(type, seed, n, nT), R = lev.R;
    const k = TYPES[type].k;
    if (k === 'race') genRace(lev, R);
    else if (type === 'tiles') genTiles(lev, R);
    else if (type === 'sweep') genSweep(lev, R);
    else if (type === 'slime') { genTower(lev, R, 30, false); lev.slime = { y0: -1.2, t0: 6, r0: 0.2, acc: 0.0012 }; lev.dur = 120; lev.killY = -8; }
    else if (type === 'crown') { genTower(lev, R, 30, true); lev.resp = 1; lev.dur = 240; lev.killY = -6; lev.crown = { y: 30 + 2.0, rr: 1.4 }; }
    else if (type === 'ball') { genBall(lev, R); lev.resp = 1; }
    else if (type === 'eggs') { genEggs(lev, R); lev.resp = 1; }
    else if (type === 'hex') genHex(lev, R);
    else if (type === 'hill') genHill(lev, R);
    buildGrid(lev);
    return lev;
  }
  const slimeY = (lev, t) => { const s = lev.slime; if (!s) return -1e9; const q = Math.max(0, t - s.t0); return s.y0 + q * s.r0 + s.acc * q * q; };
  const crownPos = (lev, t) => { const c = lev.crown; return { x: Math.cos(t * 0.6) * c.rr, y: c.y + Math.sin(t * 1.7) * 0.15, z: Math.sin(t * 0.6) * c.rr }; };

  /* ======================= 충돌 세계 ======================= */
  function aabb(s) {
    const m = s.m;
    let r = s.k === 0 ? Math.hypot(s.hx, s.hz) : s.r, x0 = s.x - r, x1 = s.x + r, z0 = s.z - r, z1 = s.z + r;
    if (m) {
      if (m.t === 'spin' || m.t === 'sweep') { const e = Math.abs(m.ox || 0) + r; x0 = m.px - e; x1 = m.px + e; z0 = m.pz - e; z1 = m.pz + e; }
      else if (m.t === 'slide') { x0 -= Math.abs(m.dx); x1 += Math.abs(m.dx); z0 -= Math.abs(m.dz); z1 += Math.abs(m.dz); }
      else if (m.t === 'pend') { const e = m.L + s.r; x0 = m.px - e * Math.abs(m.ux) - s.r; x1 = m.px + e * Math.abs(m.ux) + s.r; z0 = m.pz - e * Math.abs(m.uz) - s.r; z1 = m.pz + e * Math.abs(m.uz) + s.r; }
      else if (m.t === 'punch') { const ex = m.bx + m.dx * m.len, ez = m.bz + m.dz * m.len; x0 = Math.min(m.bx, ex) - r; x1 = Math.max(m.bx, ex) + r; z0 = Math.min(m.bz, ez) - r; z1 = Math.max(m.bz, ez) + r; }
      else if (m.t === 'roll') { x0 = m.x - m.r; x1 = m.x + m.r; z0 = m.zb - m.r; z1 = m.zt + m.r; }
      else if (m.t === 'ball') return null;   // 공은 따로(움직임 범위가 넓음)
    }
    return [x0, z0, x1, z1];
  }
  const ckey = (ix, iz) => (ix + 1024) * 4096 + (iz + 2048);
  function buildGrid(lev) {
    const g = new Map(), M = 1.7;
    lev.dynS = [];
    for (const s of lev.S) {
      const b = aabb(s);
      if (!b) { lev.dynS.push(s.i); continue; }
      for (let ix = Math.floor((b[0] - M) / CELL); ix <= Math.floor((b[2] + M) / CELL); ix++)
        for (let iz = Math.floor((b[1] - M) / CELL); iz <= Math.floor((b[3] + M) / CELL); iz++) {
          const k = ckey(ix, iz); let a = g.get(k); if (!a) g.set(k, (a = [])); a.push(s.i);
        }
    }
    if (lev.dynS.length) for (const a of g.values()) a.push(...lev.dynS);
    lev.grid = g; lev.movers = lev.S.filter((s) => s.m).map((s) => s.i);
  }
  const EMPTY = [];
  function near(lev, x, z) { const a = lev.grid.get(ckey(Math.floor(x / CELL), Math.floor(z / CELL))); return a || (lev.dynS.length ? lev.dynS : EMPTY); }

  /* 움직이는 물체의 자세(판 시계 t의 순수 함수 — 공 · 시소만 호스트 값) */
  function poseAt(W, s, t, o) {
    const m = s.m;
    if (!m) return s;
    o.k = s.k; o.hx = s.hx; o.hy = s.hy; o.hz = s.hz; o.r = s.r; o.off = 0; o.vx = o.vy = o.vz = o.w = 0; o.p = s.p; o.a = s.a;
    o.x = s.x; o.y = s.y; o.z = s.z; o.px0 = s.x; o.pz0 = s.z; o.i = s.i; o.hit = s.hit; o.bnc = s.bnc; o.e = 0;
    switch (m.t) {
      case 'spin': case 'sweep': {
        let a, w;
        if (m.t === 'spin') { a = m.a0 + m.w * t; w = m.w; }
        else {
          const tt = Math.max(0, t), tc = (m.w1 - m.w0) / m.k;
          let ang; if (tt < tc) { ang = m.w0 * tt + 0.5 * m.k * tt * tt; w = m.w0 + m.k * tt; } else { ang = m.w0 * tc + 0.5 * m.k * tc * tc + m.w1 * (tt - tc); w = m.w1; }
          a = m.a0 + m.dir * ang; w = t < 0 ? 0 : m.dir * w;
          if (t < (m.t0 || 0)) o.off = 1;
        }
        const ca = Math.cos(a), sa = Math.sin(a), ox = m.ox || 0;
        o.x = m.px + ox * ca; o.z = m.pz - ox * sa; o.a = a; o.w = w; o.px0 = m.px; o.pz0 = m.pz;
        break;
      }
      case 'slide': {
        const ph = TAU * t / m.per + m.ph, sn = Math.sin(ph), cs = Math.cos(ph) * TAU / m.per;
        o.x = m.bx + m.dx * sn; o.y = m.by + m.dy * sn; o.z = m.bz + m.dz * sn; o.vx = m.dx * cs; o.vy = m.dy * cs; o.vz = m.dz * cs;
        break;
      }
      case 'pend': {
        const ph = TAU * t / m.per + m.ph, th = m.amp * Math.sin(ph), thd = m.amp * Math.cos(ph) * TAU / m.per, s1 = Math.sin(th), c1 = Math.cos(th);
        o.x = m.px + m.L * s1 * m.ux; o.z = m.pz + m.L * s1 * m.uz; o.y = m.py - m.L * c1;
        o.vx = m.L * c1 * thd * m.ux; o.vz = m.L * c1 * thd * m.uz; o.vy = m.L * s1 * thd; o.th = th;
        break;
      }
      case 'punch': {
        let f = ((t + m.ph) / m.per) % 1; if (f < 0) f += 1;
        let e, de;
        if (f < 0.22) { e = f / 0.22; de = 1 / (0.22 * m.per); } else if (f < 0.5) { e = 1; de = 0; } else if (f < 0.85) { e = 1 - (f - 0.5) / 0.35; de = -1 / (0.35 * m.per); } else { e = 0; de = 0; }
        o.x = m.bx + m.dx * e * m.len; o.z = m.bz + m.dz * e * m.len; o.vx = m.dx * de * m.len; o.vz = m.dz * de * m.len; o.e = e;
        break;
      }
      case 'roll': {
        let q = (t + m.ph) % m.P; if (q < 0) q += m.P;
        let z = m.zt - m.v * q;
        if (z < m.zb || t < -1) { o.off = 1; z = m.zt; }
        o.x = m.x; o.z = z; o.y = m.y0 + Math.max(0, z - m.z0) * m.sl + m.r; o.vz = -m.v; o.vy = -m.v * m.sl;
        break;
      }
      case 'ss': o.p = (W && W.dyn.ss[s.ssi]) || 0; break;
      case 'ball': {
        const b = W && W.dyn.bl[m.i];
        if (!b || b.off) { o.off = 1; o.x = 0; o.y = -50; o.z = 0; break; }
        o.x = b.x; o.y = 1.5; o.z = b.z; o.vx = b.vx; o.vz = b.vz;
        break;
      }
    }
    o.ca = Math.cos(o.a); o.sa = Math.sin(o.a); o.tp = Math.tan(o.p); o.cp = Math.cos(o.p);
    return o;
  }
  function updMovers(W) { const lev = W.lev; for (const i of lev.movers) { const s = lev.S[i]; poseAt(W, s, W.t, s); } }
  /* 지금 단단한가(타일 · 문 · 끈 막대) */
  function act(W, s) {
    if (s.off) return false;
    if (s.tile >= 0 && W.dyn.tl[s.tile] === 2) return false;
    if (s.door >= 0 && W.dyn.dr[s.door]) return false;
    return true;
  }
  function actAt(W, s, tt) {
    if (s.tile >= 0) { const q = W.dyn.tt ? W.dyn.tt[s.tile] : -1; if (W.dyn.tl[s.tile] === 2 || (q >= 0 && tt >= q + W.lev.tdel - (W.tmg || 0))) return false; }
    if (s.door >= 0 && W.dyn.dr[s.door]) return false;
    return true;
  }
  /* 발밑 윗면 높이(없으면 -Infinity) */
  function topIf(s, x, z, m) {
    if (s.k === 0) {
      const dx = x - s.x, dz = z - s.z, lx = dx * s.ca - dz * s.sa, lz = dx * s.sa + dz * s.ca;
      if (Math.abs(lx) > s.hx + m || Math.abs(lz) > s.hz * s.cp + m) return -Infinity;
      return s.y + s.hy / s.cp + clamp(lz, -s.hz * s.cp, s.hz * s.cp) * s.tp;
    }
    if (s.k === 1) { const dx = x - s.x, dz = z - s.z; if (dx * dx + dz * dz > (s.r + m) * (s.r + m)) return -Infinity; return s.y + s.hy; }
    return -Infinity;
  }
  const IDLE = { mx: 0, mz: 0, j: 0, d: 0, g: 0 };

  /* ======================= 캐릭터 ======================= */
  function newChar(s, sp, team) {
    return { s, x: sp[0], y: sp[1], z: sp[2], vx: 0, vy: 0, vz: 0, yaw: sp[3] || 0, gr: 1, sup: -1, svx: 0, svy: 0, svz: 0, st: ST.RUN, stT: 0, cy: 0, jb: 0, dv: 0, inv: 0,
      grab: -1, grabT: 0, gcd: 0, held: -1, slow: 0, h: HGT, cp: 0, team: team == null ? -1 : team, qd: 0, od: 0, spin: 0, ai: null, an: 0, land: 0, hitT: 0, egg: 0, stepI: -1, outT: 0 };
  }
  const isLive = (c) => c && c.st < ST.RESP;
  function approach(c, tx, tz, a, dt) {
    const dx = tx - c.vx, dz = tz - c.vz, d = Math.hypot(dx, dz), m = a * dt;
    if (d <= m) { c.vx = tx; c.vz = tz; } else { c.vx += dx / d * m; c.vz += dz / d * m; }
  }
  function turnTo(c, ang, k) { let d = ang - c.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); c.yaw += clamp(d, -k, k); }
  function fx(W, k, c, v) { if (W.fx.length < 120) W.fx.push([k, c.s, c.x, c.y, c.z, v || 0]); }

  function tryGrab(W, c) {
    const fx_ = Math.sin(c.yaw), fz_ = Math.cos(c.yaw);
    let best = null, bd = 1.35;
    for (const d of W.chars) {
      if (!d || d === c || !isLive(d)) continue;
      const dx = d.x - c.x, dz = d.z - c.z, dist = Math.hypot(dx, dz);
      if (dist < bd && Math.abs(d.y - c.y) < 1.2 && (dx * fx_ + dz * fz_) / (dist || 1) > 0.15) { bd = dist; best = d; }
    }
    if (best) { c.grab = best.s; c.grabT = 0; fx(W, 'grab', c); }
  }
  function releaseGrab(c) { if (c.grab >= 0) { c.grab = -1; c.gcd = 0.5; } }
  function knock(W, c, nx, nz, sp, up, dur) {
    if (c.inv > 0) return;
    sp = Math.min(sp, 11);
    c.vx = nx * sp + c.vx * 0.2; c.vz = nz * sp + c.vz * 0.2; c.vy = Math.max(c.vy, up);
    c.gr = 0; c.st = ST.TUMB; c.stT = dur; c.spin = 0; c.inv = dur + 0.25; releaseGrab(c);
    fx(W, 'hit', c, sp);
  }
  function respawn(W, c) {
    const lev = W.lev;
    c.vx = c.vy = c.vz = 0; c.st = ST.RUN; c.stT = 0; c.inv = 1.2; c.gr = 0; c.sup = -1; c.svx = c.svz = c.svy = 0; c.dv = 0;
    if (lev.zone) { const a = Math.random() * TAU, r = lev.Rd - 1.6; c.x = Math.sin(a) * r; c.z = Math.cos(a) * r; c.y = 0.3; c.yaw = a + Math.PI; }
    else if (lev.goals) { const sd = c.team === 0 ? -1 : 1; c.x = (Math.random() - 0.5) * lev.field.W * 0.6; c.z = sd * lev.field.L * 0.3; c.y = 0.3; c.yaw = sd < 0 ? 0 : Math.PI; }
    else if (lev.nests) { const ne = lev.nests[Math.max(0, c.team) % lev.nests.length]; c.x = ne.x * 0.8; c.z = ne.z * 0.8; c.y = 0.3; c.yaw = Math.atan2(-ne.x, -ne.z); }
    else if (lev.steps) {
      const cp = c.cp > 0 ? lev.cps[c.cp - 1] : null;
      if (cp) { c.x = cp.x + (Math.random() - 0.5) * 1.6; c.z = cp.z + (Math.random() - 0.5) * 1.6; c.y = cp.y + 0.3; }
      else { const s = lev.sp[Math.floor(Math.random() * lev.sp.length)]; c.x = s[0]; c.y = s[1] + 0.3; c.z = s[2]; }
    } else {
      const cp = lev.cps[clamp(c.cp, 0, lev.cps.length - 1)];
      c.x = cp.x0 + Math.random() * (cp.x1 - cp.x0); c.y = cp.y + 0.3; c.z = cp.z; c.yaw = 0;
    }
    fx(W, 'resp', c);
  }

  function stepChar(W, c, inp, dt) {
    if (!c || c.st === ST.OUT || c.st === ST.FIN) return;
    const t = W.t, lev = W.lev;
    if (c.st === ST.RESP) { c.stT -= dt; if (c.stT <= 0) respawn(W, c); return; }
    c.inv = Math.max(0, c.inv - dt); c.cy -= dt; c.jb -= dt; c.gcd -= dt; c.slow = Math.max(0, c.slow - dt); c.land = Math.max(0, c.land - dt);
    const fz = t < 0;
    if (inp.j && !fz) c.jb = 0.14;
    let mx = fz ? 0 : inp.mx || 0, mz = fz ? 0 : inp.mz || 0;
    const mm = Math.hypot(mx, mz); if (mm > 1) { mx /= mm; mz /= mm; }
    // 잡기
    if (inp.g && !fz && c.st === ST.RUN) { if (c.grab < 0 && c.gcd <= 0) tryGrab(W, c); } else releaseGrab(c);
    if (c.grab >= 0) { const d = W.chars[c.grab]; c.grabT += dt; if (!d || !isLive(d) || c.grabT > 2.6 || Math.hypot(d.x - c.x, d.z - c.z) > 2.1) releaseGrab(c); }
    // 잡힘
    let held = null;
    for (const g of W.chars) if (g && g !== c && g.grab === c.s && isLive(g) && Math.hypot(g.x - c.x, g.z - c.z) < 2.2) { held = g; break; }
    c.held = held ? held.s : -1;
    const spd = RUN * (c.egg ? 0.9 : 1) * (c.grab >= 0 ? 0.55 : 1) * (held ? 0.42 : 1) * (c.slow > 0 ? 0.6 : 1);
    switch (c.st) {
      case ST.RUN: {
        approach(c, mx * spd + c.svx, mz * spd + c.svz, c.gr ? ACC_G : ACC_A, dt);
        if (mm > 0.12) turnTo(c, Math.atan2(mx, mz), 13 * dt);
        else if (c.grab >= 0) { const d = W.chars[c.grab]; if (d) turnTo(c, Math.atan2(d.x - c.x, d.z - c.z), 8 * dt); }
        if (held) { const dx = held.x - c.x, dz = held.z - c.z, d = Math.hypot(dx, dz); if (d > 1.05) { c.vx += dx / d * 5 * dt; c.vz += dz / d * 5 * dt; } }
        if (c.jb > 0 && (c.gr || c.cy > 0)) { c.vy = JUMP_V + Math.max(0, c.svy); c.gr = 0; c.cy = 0; c.jb = 0; fx(W, 'jump', c); }
        else if (inp.d && !fz && !c.dv) {
          let dx = Math.sin(c.yaw), dz = Math.cos(c.yaw);
          if (mm > 0.12) { dx = mx / Math.min(1, mm) / (mm > 1 ? 1 : 1); dz = mz; const q = Math.hypot(dx, dz); dx /= q; dz /= q; c.yaw = Math.atan2(dx, dz); }
          const hs = Math.max(DIVE_V, Math.hypot(c.vx - c.svx, c.vz - c.svz) + 2.4);
          c.vx = c.svx + dx * hs; c.vz = c.svz + dz * hs; c.vy = c.gr ? 5.0 : Math.max(c.vy + 2.5, 3.0);
          c.gr = 0; c.st = ST.DIVE; c.stT = 0; c.dv = 1; releaseGrab(c); fx(W, 'dive', c);
        }
        // 기운 바닥(시소 · 오르막)에서는 아래로 조금 미끄러짐
        if (c.gr && c.sup >= 0) { const s = lev.S[c.sup]; if (s.k === 0 && Math.abs(s.p) > 0.05) { const g = -GRAV * Math.sin(s.p) * 0.3 * dt; c.vx += s.sa * g; c.vz += s.ca * g; } }
        break;
      }
      case ST.DIVE: {
        c.stT += dt;
        if (mm > 0.12) { c.vx += mx * 2 * dt; c.vz += mz * 2 * dt; }
        if (c.gr && c.stT > 0.06) { c.st = ST.SLIDE; c.stT = 0.4; fx(W, 'slide', c); }
        break;
      }
      case ST.SLIDE: { c.stT -= dt; approach(c, c.svx, c.svz, 10, dt); if (c.stT <= 0) { c.st = ST.UP; c.stT = 0.2; } break; }
      case ST.TUMB: { c.stT -= dt; c.spin += dt; if (c.gr) approach(c, c.svx, c.svz, 7, dt); if (c.stT <= 0 && c.gr) { c.st = ST.UP; c.stT = 0.28; } break; }
      case ST.UP: { c.stT -= dt; approach(c, mx * spd * 0.3 + c.svx, mz * spd * 0.3 + c.svz, 22, dt); if (c.stT <= 0) c.st = ST.RUN; break; }
    }
    if (c.gr && c.st === ST.RUN) c.dv = 0;
    c.vy -= GRAV * dt; if (c.vy < -34) c.vy = -34;
    moveChar(W, c, dt);
    // 떨어짐 · 결승 · 깃발
    const kill = lev.slime ? Math.max(lev.killY, slimeY(lev, t)) : lev.killY;
    if (c.y < kill) {
      if (lev.resp && !lev.slime) { c.st = ST.RESP; c.stT = lev.zone ? 2.2 : 1.0; releaseGrab(c); fx(W, 'fall', c); }
      else { c.st = ST.OUT; c.outT = t; releaseGrab(c); fx(W, 'out', c); }
      return;
    }
    if (lev.finZ != null) {
      if (c.gr && c.z >= lev.finZ && c.y > lev.finY - 0.6) { c.st = ST.FIN; c.vx = c.vz = 0; releaseGrab(c); fx(W, 'fin', c); c.z = lev.finZ + 4 + Math.random() * 6; c.x = (Math.random() - 0.5) * (lev.W + 1); c.yaw = Math.PI; return; }
      if (c.gr) { while (c.cp + 1 < lev.cps.length && c.z >= lev.cps[c.cp + 1].z - 0.5) c.cp++; }
    }
    if (c.gr && c.sup >= 0) {
      const s = lev.S[c.sup];
      if (s.step != null) c.stepI = s.step;
      if (s.cp != null && s.cp >= 0) c.cp = Math.max(c.cp, s.cp + 1);
      if (s.goal && lev.slime) { c.st = ST.FIN; releaseGrab(c); fx(W, 'fin', c); return; }
      if (s.vis === 'ground') c.stepI = -1;
    }
    if (lev.crown && t >= 0) {
      const cw = crownPos(lev, t), dx = cw.x - c.x, dz = cw.z - c.z;
      if (dx * dx + dz * dz < 0.95 * 0.95 && cw.y > c.y + 0.4 && cw.y < c.y + c.h + 0.5) { c.st = ST.FIN; fx(W, 'crown', c); return; }
    }
  }

  function moveChar(W, c, dt) {
    const lev = W.lev, S = lev.S;
    const h = c.st === ST.DIVE || c.st === ST.SLIDE ? LOW : c.st === ST.TUMB ? 0.95 : HGT;
    c.h = h;
    const oy = c.y;
    let nx = c.x + c.vx * dt, ny = c.y + c.vy * dt, nz = c.z + c.vz * dt;
    const cand = near(lev, nx, nz);
    // 천장
    if (c.vy > 0) for (let i = 0; i < cand.length; i++) {
      const s = S[cand[i]]; if (s.k === 2 || !act(W, s)) continue;
      const top = topIf(s, nx, nz, -RAD * 0.4); if (top === -Infinity) continue;
      const bot = top - 2 * (s.k === 0 ? s.hy / s.cp : s.hy);
      if (bot >= oy + h - 0.02 && bot < ny + h) { ny = bot - h; c.vy = 0; }
    }
    // 바닥
    let best = -Infinity, bs = null;
    const snap = c.gr && c.vy <= 0.5 ? 0.3 : 0;
    for (let i = 0; i < cand.length; i++) {
      const s = S[cand[i]]; if (s.k === 2 || !act(W, s)) continue;
      const top = topIf(s, nx, nz, RAD * 0.55);
      if (top === -Infinity || top > Math.max(oy, ny) + STEP || ny > top + snap) continue;
      if (top > best) { best = top; bs = s; }
    }
    if (bs) {
      if (!c.gr && c.vy < -6) { c.land = 0.18; fx(W, 'land', c, -c.vy); }
      ny = best; c.vy = bs.vy || 0; c.gr = 1; c.sup = bs.i;
      c.svx = bs.vx + bs.w * (nz - bs.pz0); c.svz = bs.vz - bs.w * (nx - bs.px0); c.svy = bs.vy;
      if (bs.cv) { c.svx += bs.cv[0]; c.svz += bs.cv[1]; }
    } else {
      if (c.gr) c.cy = 0.1;
      c.gr = 0; c.sup = -1; c.svx = c.svz = c.svy = 0;
    }
    c.x = nx; c.y = ny; c.z = nz;
    // 벽 · 움직이는 장애물
    for (let i = 0; i < cand.length; i++) {
      const s = S[cand[i]]; if (!act(W, s)) continue;
      if (s.k === 0) {
        const dx = c.x - s.x, dz = c.z - s.z, lx = dx * s.ca - dz * s.sa, lz = dx * s.sa + dz * s.ca, hz = s.hz * s.cp;
        const clx = clamp(lx, -s.hx, s.hx), clz = clamp(lz, -hz, hz);
        const top = s.y + s.hy / s.cp + clz * s.tp, bot = top - 2 * s.hy / s.cp;
        if (top <= c.y + STEP + 0.01 || bot >= c.y + h) continue;
        const ex = lx - clx, ez = lz - clz, d2 = ex * ex + ez * ez;
        if (d2 >= RAD * RAD) continue;
        let nxl, nzl, pen;
        if (d2 > 1e-8) { const d = Math.sqrt(d2); nxl = ex / d; nzl = ez / d; pen = RAD - d; }
        else { const px = s.hx - Math.abs(lx), pz = hz - Math.abs(lz); if (px < pz) { nxl = lx >= 0 ? 1 : -1; nzl = 0; pen = px + RAD; } else { nxl = 0; nzl = lz >= 0 ? 1 : -1; pen = pz + RAD; } }
        pushOut(W, c, s, nxl * s.ca + nzl * s.sa, -nxl * s.sa + nzl * s.ca, pen);
      } else if (s.k === 1) {
        const top = s.y + s.hy, bot = s.y - s.hy;
        if (top <= c.y + STEP + 0.01 || bot >= c.y + h) continue;
        const dx = c.x - s.x, dz = c.z - s.z, d = Math.hypot(dx, dz), rr = s.r + RAD;
        if (d >= rr) continue;
        if (d < 1e-6) pushOut(W, c, s, 1, 0, rr); else pushOut(W, c, s, dx / d, dz / d, rr - d);
      } else {
        const py = clamp(s.y, c.y + RAD, c.y + h - RAD * 0.8), dx = c.x - s.x, dy = py - s.y, dz = c.z - s.z, d = Math.hypot(dx, dy, dz), rr = s.r + RAD;
        if (d >= rr) continue;
        const hd = Math.hypot(dx, dz);
        if (hd < 1e-5) { if (dy > 0) { c.y = s.y + s.r; if (c.vy < 0) c.vy = 0; } continue; }
        pushOut(W, c, s, dx / hd, dz / hd, (rr - d) * (d / hd > 3 ? 1 : d / Math.max(hd, 1e-3)) * 0.9 + 0.01);
        if (s.vis === 'ball' && dy > s.r * 0.7 && c.vy < 0) { c.vy = 2; }
      }
    }
  }
  function pushOut(W, c, s, nx, nz, pen) {
    c.x += nx * pen; c.z += nz * pen;
    const vn = c.vx * nx + c.vz * nz;
    let mvx = 0, mvz = 0;
    if (s.m) { mvx = s.vx + s.w * (c.z - s.pz0); mvz = s.vz - s.w * (c.x - s.px0); }
    const mn = mvx * nx + mvz * nz;
    if (s.vis === 'ball') { if (vn < mn) { c.vx += (mn - vn) * nx * 0.8; c.vz += (mn - vn) * nz * 0.8; } return; }
    if (vn < mn) { c.vx += (mn - vn) * nx; c.vz += (mn - vn) * nz; }
    if (s.bnc && c.inv <= 0) { c.vx += nx * s.bnc; c.vz += nz * s.bnc; c.vy = Math.max(c.vy, 2.5); c.slow = 0.25; fx(W, 'bump', c); }
    if (s.hit && c.st !== ST.TUMB) {
      const sp = Math.hypot(mvx, mvz);
      if (mn > 1.6 || (s.k === 2 && sp > 2)) {
        const kx = mvx / (sp || 1) * 0.65 + nx * 0.35, kz = mvz / (sp || 1) * 0.65 + nz * 0.35, kq = Math.hypot(kx, kz) || 1;
        knock(W, c, kx / kq, kz / kq, 3 + sp * 0.75, 3.5 + Math.min(4, sp * 0.3), 0.55 + Math.min(0.5, sp * 0.04));
      }
    }
  }
  /* 캐릭터끼리: 이 기기가 움직이는 캐릭터만 밀려남 · 다이브로 들이받기 */
  function charPairs(W, local) {
    const A = W.chars, n = A.length;
    for (let i = 0; i < n; i++) {
      const a = A[i]; if (!isLive(a)) continue;
      for (let j = i + 1; j < n; j++) {
        const b = A[j]; if (!isLive(b)) continue;
        const dx = b.x - a.x, dz = b.z - a.z; if (Math.abs(dx) > 1 || Math.abs(dz) > 1) continue;
        const d2 = dx * dx + dz * dz, rr = 2 * RAD * 0.92; if (d2 >= rr * rr || Math.abs(a.y - b.y) > 1.15) continue;
        const d = Math.sqrt(d2) || 0.01, nx = dx / d, nz = dz / d, pen = rr - d;
        const la = local(a.s), lb = local(b.s);
        if (la && lb) { a.x -= nx * pen / 2; a.z -= nz * pen / 2; b.x += nx * pen / 2; b.z += nz * pen / 2; }
        else if (la) { a.x -= nx * pen; a.z -= nz * pen; } else if (lb) { b.x += nx * pen; b.z += nz * pen; }
        for (const [p, q, sg] of [[a, b, 1], [b, a, -1]]) {
          if (p.st !== ST.DIVE || !local(p.s)) continue;
          const sp = Math.hypot(p.vx, p.vz);
          if (sp > 5.5 && q.inv <= 0 && (p.vx * nx + p.vz * nz) * sg > 2) hitEvent(W, p.s, q.s, nx * sg, nz * sg, 4.2);
        }
      }
    }
  }
  /* 맞힘: 맞은 캐릭터가 이 기기 것이면 바로, 아니면 이벤트로 보냄. 호스트는 알 떨어뜨리기 */
  function hitEvent(W, from, to, nx, nz, pow, id) {
    const c = W.chars[to]; if (!c) return;
    if (id == null) { id = W.evBase + (++W.evN); W.evOut.push([id, 1, from, to, Math.round(nx * 100), Math.round(nz * 100), Math.round(pow * 10), W.t]); }
    if (W.evSeen[id]) return;
    W.evSeen[id] = 1;
    if (W.isLocal(to) && c.inv <= 0 && isLive(c)) { c.vx += nx * pow; c.vz += nz * pow; c.vy = Math.max(c.vy, 3); c.st = ST.TUMB; c.stT = 0.42; c.inv = 0.8; c.gr = 0; releaseGrab(c); fx(W, 'hit', c, pow); }
    if (W.host && W.carry && W.carry[to] >= 0) dropEgg(W, to);
  }

  /* ======================= 판 위 물건 (호스트가 정함) ======================= */
  function newDyn(lev, n) {
    const D = { tt: new Float32Array(lev.tiles).fill(-1), tl: new Uint8Array(lev.tiles), dr: new Uint8Array(lev.doors.length), ss: Float32Array.from(lev.ssInit), sw: new Float32Array(lev.ss),
      bl: [], eg: [], sc: [], hp: new Float32Array(n), q: [], o: [], ot: 0, gT: 0, gl: -1 };
    for (let b = 0; b < lev.balls; b++) D.bl.push({ x: lev.balls > 1 ? (b ? 4 : -4) : 0, z: 0, vx: 0, vz: 0, off: 0, rt: 0 });
    if (lev.egg0) D.eg = lev.egg0.map(([x, z]) => ({ x, z, h: -1, on: 1, cd: 0, cs: -1 }));
    const T = lev.nests ? lev.nests.length : lev.goals ? 2 : 0;
    for (let k = 0; k < T; k++) D.sc.push(0);
    return D;
  }
  function tileAt(W, c) {
    const lev = W.lev;
    if (lev.tg) {
      const g = lev.tg; let l = -1;
      for (let k = 0; k < g.ys.length; k++) if (Math.abs(c.y - g.ys[k]) < 0.2) l = k;
      if (l < 0) return -1;
      const ix = Math.floor((c.x - g.x0) / g.sz), iz = Math.floor((c.z - g.z0) / g.sz);
      if (ix < 0 || iz < 0 || ix >= g.N || iz >= g.N) return -1;
      return l * g.N * g.N + iz * g.N + ix;
    }
    if (lev.hex) {
      const hx = lev.hex; let l = -1;
      for (let k = 0; k < hx.ys.length; k++) if (Math.abs(c.y - hx.ys[k]) < 0.2) l = k;
      if (l < 0) return -1;
      const s = hx.hs * 1.03, q = (2 / 3 * c.x) / s, r = (-1 / 3 * c.x + Math.sqrt(3) / 3 * c.z) / s;
      let rx = Math.round(q), rz = Math.round(r), ry = Math.round(-q - r);
      const dx = Math.abs(rx - q), dz = Math.abs(rz - r), dy = Math.abs(ry + q + r);
      if (dx > dy && dx > dz) rx = -ry - rz; else if (dy <= dz) rz = -rx - ry;
      const v = hx.map[rx + ',' + rz + ',' + l];
      return v == null ? -1 : v;
    }
    return -1;
  }
  function dropEgg(W, s) {
    const e = W.dyn.eg[W.carry[s]], c = W.chars[s];
    if (e && c) { const a = Math.random() * TAU; e.h = -1; e.on = 1; e.x = clamp(c.x + Math.sin(a) * 1.6, -W.lev.field.W / 2 + 1, W.lev.field.W / 2 - 1); e.z = clamp(c.z + Math.cos(a) * 1.6, -W.lev.field.L / 2 + 1, W.lev.field.L / 2 - 1); e.cd = 0.7; e.cs = s; }
    W.carry[s] = -1; if (c) c.egg = 0;
    W.efx.push(['drop', s]);
  }
  function hostTick(W, dt) {
    const lev = W.lev, D = W.dyn, t = W.t, A = W.chars;
    // 통과 · 탈락 기록
    for (const c of A) {
      if (!c) continue;
      if (c.st === ST.FIN && !c.qd) { c.qd = 1; D.q.push(c.s); }
      if (c.st === ST.OUT && !c.od) { c.od = 1; D.o.push(c.s); }
    }
    if (t < 0) return;
    // 무너지는 바닥
    if (lev.tiles) {
      for (const c of A) {
        if (!isLive(c) || !c.gr) continue;
        const i = tileAt(W, c);
        if (i >= 0 && D.tt[i] < 0) D.tt[i] = t;
      }
      for (let i = 0; i < lev.tiles; i++) if (D.tt[i] >= 0) D.tl[i] = t >= D.tt[i] + lev.tdel ? 2 : 1;
    }
    // 문: 진짜 문은 닿으면 쓰러짐
    if (lev.doors.length) for (const c of A) {
      if (!isLive(c)) continue;
      for (const row of lev.drows) {
        if (Math.abs(c.z - row.z) > 0.25 + RAD + 0.2 || Math.abs(c.y - row.y) > 1.2) continue;
        for (const di of row.list) { const d = lev.doors[di]; if (d.real && !D.dr[di] && Math.abs(c.x - d.x) < d.w / 2 + 0.05) { D.dr[di] = 1; W.efx.push(['door', di]); } }
      }
    }
    // 시소: 올라선 무게로 기울어짐
    if (lev.ss) for (const s of lev.S) {
      if (s.ssi < 0) continue;
      let tq = 0;
      for (const c of A) {
        if (!isLive(c)) continue;
        const top = topIf(s, c.x, c.z, 0.1); if (top === -Infinity || Math.abs(c.y - top) > 0.3) continue;
        tq += (c.x - s.x) * s.sa + (c.z - s.z) * s.ca;
      }
      const k = s.ssi; let w = D.sw[k] + (-tq * 0.55 - D.sw[k] * 1.6) * dt, a = D.ss[k] + w * dt;
      if (a > 0.36) { a = 0.36; w = 0; } else if (a < -0.36) { a = -0.36; w = 0; }
      D.sw[k] = w; D.ss[k] = a;
    }
    // 큰 공
    if (lev.balls) ballTick(W, dt);
    // 알
    if (lev.nests) eggTick(W, dt);
    // 언덕 점수
    if (lev.zone) {
      const z = lev.zone;
      for (const c of A) if (isLive(c) && c.y > z.y - 0.2 && Math.hypot(c.x - z.x, c.z - z.z) < z.r) D.hp[c.s] += dt;
    }
  }
  function ballTick(W, dt) {
    const lev = W.lev, D = W.dyn, F = lev.field, rb = 1.5;
    if (D.gT > 0) { D.gT -= dt; if (D.gT <= 0) for (let b = 0; b < D.bl.length; b++) Object.assign(D.bl[b], { x: D.bl.length > 1 ? (b ? 4 : -4) : 0, z: 0, vx: 0, vz: 0, off: 0 }); return; }
    for (const b of D.bl) {
      if (b.off) continue;
      for (const c of W.chars) {
        if (!isLive(c) || c.y > 2.6) continue;
        const dx = b.x - c.x, dz = b.z - c.z, d = Math.hypot(dx, dz);
        if (d >= rb + RAD + 0.08 || d < 1e-4) continue;
        const nx = dx / d, nz = dz / d, vr = (c.vx - b.vx) * nx + (c.vz - b.vz) * nz;
        if (vr > 0) { const J = vr * (c.st === ST.DIVE ? 1.3 : 0.8) + 0.6; b.vx += nx * J * 0.8; b.vz += nz * J * 0.8; }
        const pen = rb + RAD + 0.08 - d; b.x += nx * pen * 0.5; b.z += nz * pen * 0.5;
      }
      // 가장자리 경사(벽에 붙어 멈추지 않게 가운데로 흘러내림)
      const ex = Math.abs(b.x) - (F.W / 2 - 4); if (ex > 0) b.vx -= Math.sign(b.x) * (2 + ex * 3) * dt;
      const ez = Math.abs(b.z) - (F.L / 2 - 4); if (ez > 0 && Math.abs(b.x) > F.gw / 2 - 0.5) b.vx -= Math.sign(b.x) * (2 + ez * 3) * dt;
      const sp = Math.hypot(b.vx, b.vz); if (sp > 14) { b.vx *= 14 / sp; b.vz *= 14 / sp; }
      // 벽 · 모서리에 4초 넘게 끼면 가운데에서 다시(드롭 볼)
      const edge = Math.abs(b.x) > F.W / 2 - 2.4 || Math.abs(b.z) > F.L / 2 - 2.4;
      b.st = edge && sp < 1.2 ? (b.st || 0) + dt : 0;
      if (b.st > 4) { b.st = 0; b.x = 0; b.z = 0; b.vx = b.vz = 0; W.efx.push(['drop_ball']); }
      const k = Math.exp(-0.45 * dt); b.vx *= k; b.vz *= k;
      b.x += b.vx * dt; b.z += b.vz * dt; b.rt += sp * dt / rb;
      const xm = F.W / 2 - rb;
      if (b.x < -xm) { b.x = -xm; b.vx = Math.abs(b.vx) * 0.6; } else if (b.x > xm) { b.x = xm; b.vx = -Math.abs(b.vx) * 0.6; }
      const zm = F.L / 2 - rb;
      if (Math.abs(b.z) > zm && Math.abs(b.x) > F.gw / 2 - rb * 0.4) { b.z = Math.sign(b.z) * zm; b.vz = -Math.sign(b.z) * Math.abs(b.vz) * 0.6; }
      if (Math.abs(b.z) > F.L / 2 + 0.6) {   // 골
        const side = b.z > 0 ? 1 : 0, scorer = side ? 0 : 1;
        D.sc[scorer]++; D.gl = scorer; D.gT = 1.6; b.off = 1; b.vx = b.vz = 0; W.efx.push(['goal', scorer]);
        if (D.ot) D.otEnd = 1;
      }
      if (Math.abs(b.z) > F.L / 2 + 3.4) { b.z = Math.sign(b.z) * (F.L / 2 + 3.4); b.vz = 0; }
    }
  }
  function eggTick(W, dt) {
    const lev = W.lev, D = W.dyn, A = W.chars, ns = lev.nests;
    for (const e of D.eg) if (e.cd > 0) e.cd -= dt;
    for (const c of A) {
      if (!c) continue;
      const ci = W.carry[c.s];
      if (!isLive(c)) { if (ci >= 0) dropEgg(W, c.s); continue; }
      c.cdS = (c.cdS || 0) - dt;
      if (ci >= 0) {
        const e = D.eg[ci]; e.x = c.x; e.z = c.z;
        const my = ns[c.team];
        if (my && Math.hypot(c.x - my.x, c.z - my.z) < my.r) { D.sc[c.team]++; e.on = 0; e.h = -1; W.carry[c.s] = -1; c.egg = 0; c.cdS = 0.6; W.efx.push(['dep', c.s, c.team]); }
        continue;
      }
      if (c.st !== ST.RUN) continue;
      // 줍기
      let best = -1, bd = 1.0;
      for (let i = 0; i < D.eg.length; i++) { const e = D.eg[i]; if (!e.on || e.h >= 0 || (e.cd > 0 && e.cs === c.s)) continue; const d = Math.hypot(e.x - c.x, e.z - c.z); if (d < bd) { bd = d; best = i; } }
      if (best >= 0) { D.eg[best].h = c.s; W.carry[c.s] = best; c.egg = 1; W.efx.push(['pick', c.s]); continue; }
      // 훔치기
      if (c.cdS > 0) continue;
      for (const nst of ns) {
        if (nst.team === c.team || D.sc[nst.team] <= 0 || Math.hypot(c.x - nst.x, c.z - nst.z) > nst.r) continue;
        const i = D.eg.findIndex((e) => !e.on);
        if (i < 0) break;
        D.sc[nst.team]--; const e = D.eg[i]; e.on = 1; e.h = c.s; e.x = c.x; e.z = c.z; W.carry[c.s] = i; c.egg = 1; c.cdS = 1.0; W.efx.push(['steal', c.s, nst.team]);
        break;
      }
    }
    // 잡기로 빼앗기(0.5초)
    for (const c of A) {
      if (!isLive(c) || c.grab < 0) continue;
      const v = A[c.grab]; if (!v || W.carry[v.s] < 0 || W.carry[c.s] >= 0 || v.team === c.team) continue;
      if (c.grabT > 0.5) { const i = W.carry[v.s]; W.carry[v.s] = -1; v.egg = 0; W.carry[c.s] = i; c.egg = 1; D.eg[i].h = c.s; W.efx.push(['steal', c.s, -1]); }
    }
  }

  /* ======================= 판 진행: 한 걸음 ======================= */
  function makeWorld(st, opt) {
    opt = opt || {};
    const alive = [];
    for (let s = 0; s < st.n; s++) if (st.alive[s]) alive.push(s);
    const lev = genLevel(st.rt, st.rs, alive.length, st.nT || 0);
    const W = { st, lev, t: -3.5, host: opt.host !== false, chars: Array(st.n).fill(null), dyn: newDyn(lev, st.n), evOut: [], evSeen: {}, evN: 0, evBase: Math.floor(Math.random() * 9e5) * 1000,
      carry: Array(st.n).fill(-1), fx: [], efx: [], tmp: {}, isLocal: opt.isLocal || (() => true), aiC: {} };
    // 출발 자리(씨앗으로 섞어 모든 기기가 같게)
    const R = prng(st.rs ^ 0x5bd1e995), order = shuffle(R, alive.slice());
    if (st.team && (lev.field)) {
      const T = Math.max(2, st.nT || 2), per = {};
      for (const s of order) {
        const tm = st.team[s], k = per[tm] = (per[tm] || 0) + 1;
        let x, z, yaw;
        if (lev.goals) { const sd = tm === 0 ? -1 : 1, row = Math.floor((k - 1) / 6), col = (k - 1) % 6; x = (col - 2.5) * 2.2; z = sd * (5 + row * 2.2); yaw = sd < 0 ? 0 : Math.PI; }
        else { const ne = lev.nests[tm % lev.nests.length], a = k * 1.3; x = ne.x * 0.82 + Math.sin(a) * (1 + k * 0.25); z = ne.z * 0.82 + Math.cos(a) * (1 + k * 0.25); yaw = Math.atan2(-ne.x, -ne.z); }
        W.chars[s] = newChar(s, [x, 0.05, z, yaw], tm);
      }
      void T;
    } else order.forEach((s, k) => { W.chars[s] = newChar(s, lev.sp[k % lev.sp.length].slice(), st.team ? st.team[s] : -1); });
    updMovers(W);
    return W;
  }
  /* inputOf(seat, c) → 입력, local(seat) → 이 기기가 움직이는 캐릭터인가 */
  function worldStep(W, dt, inputOf) {
    const local = W.isLocal;
    W.t += dt;
    updMovers(W);
    for (const c of W.chars) if (c && local(c.s)) stepChar(W, c, inputOf(c.s, c) || IDLE, dt);
    charPairs(W, local);
    if (W.host) hostTick(W, dt);
  }

  /* ======================= 판 끝 판정 (호스트) ======================= */
  function progressOf(W, c) {
    const lev = W.lev;
    if (lev.finZ != null) return c.st === ST.FIN ? 1e6 : c.z;
    if (lev.steps) return c.st === ST.FIN ? 1e6 : c.y + (c.stepI + 1) * 0.01;
    if (lev.zone) return W.dyn.hp[c.s];
    return c.y;
  }
  function roundEnd(W) {
    const st = W.st, lev = W.lev, D = W.dyn, t = W.t;
    if (t < 0.5) return null;
    const P = W.chars.filter(Boolean), na = P.length, K = st.K, noE = K >= na;
    const ids = (a) => a.map((c) => c.s);
    const byProg = (a) => a.slice().sort((x, y) => progressOf(W, x) - progressOf(W, y));
    const res = (q, e, extra) => Object.assign({ q, e }, extra || {});
    const k = lev.k;
    if (k === 'race') {
      const q = D.q.slice();
      if (!noE && q.length >= K) { const qq = q.slice(0, K); return res(qq, ids(byProg(P.filter((c) => !qq.includes(c.s))))); }
      if (noE && q.length >= na) return res(q, []);
      if (t >= lev.dur) {
        if (noE) return res(ids(P), []);
        let qq = q; if (!qq.length) qq = ids(byProg(P).reverse().slice(0, K));
        return res(qq, ids(byProg(P.filter((c) => !qq.includes(c.s)))));
      }
      return null;
    }
    if (k === 'surv') {
      const o = D.o.slice(), q = D.q.slice(), live = P.filter((c) => !o.includes(c.s) && !q.includes(c.s));
      const fin = (qq, ee) => { qq = qq.slice(); ee = ee.slice(); if (!qq.length && ee.length) qq.push(ee.pop()); return res(qq, ee); };
      if (noE) { if (t >= lev.dur || (!live.length)) return res(ids(P), []); return null; }
      if (lev.slime) {
        if (q.length >= K) return fin(q.slice(0, K), o.concat(ids(byProg(live))).concat(q.slice(K)));
        if (o.length >= na - K) return fin(q.concat(ids(live)), o);
        if (!live.length || t >= lev.dur) return fin(q, o.concat(ids(byProg(live))));
        return null;
      }
      if (o.length >= na - K) return fin(ids(live), o);
      if (!live.length || t >= lev.dur) return fin(ids(live), o);
      return null;
    }
    if (k === 'team') {
      const T = D.sc.length;
      let end = t >= lev.dur || (D.ot && D.otEnd);
      if (!end) return null;
      const low = Math.min(...D.sc);
      let losers = [...Array(T).keys()].filter((i) => D.sc[i] === low);
      if (losers.length > 1 && lev.goals && !D.ot) { D.ot = 1; lev.dur = t + 30; return null; }   // 공: 같으면 먼저 넣는 팀이 이기는 연장 30초
      if (losers.length > 1 && lev.nests) { const car = losers.map((i) => W.carry.filter((v, s) => v >= 0 && st.team[s] === i).length), m = Math.min(...car); losers = losers.filter((_, j) => car[j] === m); }
      const lt = losers.length > 1 ? losers[Math.floor(prng(st.rs ^ 77)() * losers.length)] : losers[0];
      const e = ids(byProg(P.filter((c) => st.team[c.s] === lt))), q = ids(P.filter((c) => st.team[c.s] !== lt));
      return res(q, e, { sc: Array.from(D.sc), lt });
    }
    // 결승
    const out = D.o.slice();
    const pickWin = (cands, key) => { let best = null; for (const c of cands) if (!best || key(c) > key(best)) best = c; return best ? best.s : -1; };
    let win = -1;
    if (lev.type === 'hex') {
      const live = P.filter((c) => !out.includes(c.s));
      if (live.length <= 1) win = live.length ? live[0].s : out[out.length - 1];
      else if (t >= lev.dur) win = pickWin(live, (c) => c.y);
    } else if (lev.type === 'hill') {
      const top = pickWin(P, (c) => D.hp[c.s]);
      if (top >= 0 && D.hp[top] >= lev.zone.need) win = top;
      else if (t >= lev.dur) win = top;
    } else if (lev.type === 'crown') {
      if (D.q.length) win = D.q[0];
      else if (t >= lev.dur) win = pickWin(P, (c) => c.y);
    }
    if (win < 0) return null;
    const rest = P.filter((c) => c.s !== win && !out.includes(c.s));
    return res([win], out.filter((s) => s !== win).concat(ids(byProg(rest))), { win, hp: lev.zone ? Array.from(D.hp).map((v) => Math.round(v * 10) / 10) : null });
  }

  /* ======================= AI (상황 점수 + 봇마다 씨앗 버릇) ======================= */
  function habits(seed, s) { const R = prng((seed ^ Math.imul(s + 1, 2654435761)) >>> 0); return { ag: R(), cau: R(), lane: R() * 2 - 1, jmp: R(), dv: R(), rt: 0.85 + R() * 0.3, def: R(), nz: R() }; }
  const DIRS = { 1: [0, 0.5, -0.5, 1.05, -1.05], 2: [0, 0.42, -0.42, 0.85, -0.85, 1.4, -1.4], 3: [0, 0.3, -0.3, 0.65, -0.65, 1.05, -1.05, 1.6, -1.6, Math.PI] };
  /* 타일 판: 칸 번호를 바로 계산(빠름) */
  function tileIdxL(lev, x, z, l) {
    if (lev.tg) { const g = lev.tg, ix = Math.floor((x - g.x0) / g.sz), iz = Math.floor((z - g.z0) / g.sz); if (ix < 0 || iz < 0 || ix >= g.N || iz >= g.N) return -1; return l * g.N * g.N + iz * g.N + ix; }
    const hx = lev.hex, s = hx.hs * 1.03, q = (2 / 3 * x) / s, r = (-1 / 3 * x + Math.sqrt(3) / 3 * z) / s;
    let rx = Math.round(q), rz = Math.round(r), ry = Math.round(-q - r);
    const dx = Math.abs(rx - q), dz = Math.abs(rz - r), dy = Math.abs(ry + q + r);
    if (dx > dy && dx > dz) rx = -ry - rz; else if (dy <= dz) rz = -rx - ry;
    const v = hx.map[rx + ',' + rz + ',' + l]; return v == null ? -1 : v;
  }
  function supAt(W, x, z, y, tt) {
    const lev = W.lev, S = lev.S, o = W.tmp;
    if (lev.tg || lev.hex) {
      const ys = (lev.tg || lev.hex).ys, ts = lev.tileS || (lev.tileS = lev.S.filter((q) => q.tile >= 0));
      for (let l = 0; l < ys.length; l++) { if (ys[l] > y + STEP + 0.05) continue; const i = tileIdxL(lev, x, z, l); if (i >= 0 && actAt(W, ts[i], tt)) return ys[l]; }
      return -Infinity;
    }
    const cand = near(lev, x, z);
    let best = -Infinity;
    for (let i = 0; i < cand.length; i++) {
      const s0 = S[cand[i]]; if (s0.k === 2 || !actAt(W, s0, tt)) continue;
      const s = s0.m ? poseAt(W, s0, tt, o) : s0; if (s.off) continue;
      const top = topIf(s, x, z, RAD * 0.45);
      if (top !== -Infinity && top <= y + STEP + 0.05 && top > best) best = top;
    }
    return best;
  }
  function wallAt(W, x, z, y, h, tt, pass) {
    const lev = W.lev, S = lev.S;
    if (lev.tg || lev.hex) return false;
    const cand = near(lev, x, z);
    for (let i = 0; i < cand.length; i++) {
      const s = S[cand[i]]; if (s.k === 2 || s.m || !actAt(W, s, tt) || (s.door >= 0 && s.door === pass)) continue;
      const top = topIf(s, x, z, RAD * 0.85); if (top === -Infinity) continue;
      const bot = top - 2 * (s.k === 0 ? s.hy / s.cp : s.hy);
      if (top > y + STEP + 0.05 && bot < y + h) return true;
    }
    return false;
  }
  function hazAt(W, x, z, y, h, tt, mg) {
    const lev = W.lev, S = lev.S;
    if (lev.nHaz == null) lev.nHaz = lev.S.filter((q) => q.hit).length;
    if (!lev.nHaz) return 0;
    const cand = near(lev, x, z), o = W.tmp;
    for (let i = 0; i < cand.length; i++) {
      const s0 = S[cand[i]]; if (!s0.hit) continue;
      const s = poseAt(W, s0, tt, o); if (s.off) continue;
      if (s.k === 0) {
        const dx = x - s.x, dz = z - s.z, lx = dx * s.ca - dz * s.sa, lz = dx * s.sa + dz * s.ca, ex = Math.abs(lx) - s.hx, ez = Math.abs(lz) - s.hz;
        const d = Math.hypot(Math.max(0, ex), Math.max(0, ez));
        if (d < RAD + mg && s.y + s.hy > y + 0.05 && s.y - s.hy < y + h) return 1;
      } else if (s.k === 2) {
        const py = clamp(s.y, y + RAD, y + h - RAD * 0.8), d = Math.hypot(x - s.x, py - s.y, z - s.z);
        if (d < s.r + RAD + mg) return 1;
      }
    }
    return 0;
  }
  /* 한 방향으로 0.7~0.9초 미리 달려(뛰어) 보기 */
  function rollout(W, c, dx, dz, mode, mg, pass, sp0, prog) {
    if (mode === 1 && !c.gr && c.cy <= 0) mode = 0;   // 공중에선 다시 뛸 수 없음
    const tmg = W.tmg || 0; W.tmg = 0;
    const lev = W.lev, t0 = W.t;
    let x = c.x, y = c.y, z = c.z, vy = mode === 1 ? JUMP_V : mode === 2 ? 5.0 : 0, air = mode > 0, haz = 0, fell = 0, blk = 0, drop = 0;
    const sp = sp0;
    let vx = c.vx, vz = c.vz;
    if (mode === 2) { vx = dx * DIVE_V; vz = dz * DIVE_V; }
    const h = mode === 2 ? LOW : HGT, n = mode ? 9 : 6, dt = mode ? 0.1 : 0.12;
    const sly = lev.slime ? 1 : 0;
    let pb = -Infinity;
    for (let k = 1; k <= n; k++) {
      if (mode !== 2) { const ex = dx * sp - vx, ez = dz * sp - vz, el = Math.hypot(ex, ez), am = (air ? ACC_A : ACC_G) * dt; if (el <= am) { vx += ex; vz += ez; } else { vx += ex / el * am; vz += ez / el * am; } }
      else if (!air) { const q = Math.hypot(vx, vz), nq = Math.max(0, q - 10 * dt); if (q > 0) { vx *= nq / q; vz *= nq / q; } }   // 다이브 뒤 미끄러짐
      const tt = t0 + k * dt, nx = x + vx * dt, nz = z + vz * dt;
      if (air) {
        const ny = y + vy * dt - 0.5 * GRAV * dt * dt; vy -= GRAV * dt;
        if ((vx || vz) && wallAt(W, nx, nz, ny, h, tt, pass)) { blk = 1; dx = dz = 0; vx = vz = 0; y = ny; continue; }
        if (vy < 0) { const top = supAt(W, nx, nz, y, tt); if (top !== -Infinity && top >= ny - 0.05) { if (top < c.y - 1.6) drop = 1; x = nx; z = nz; y = top; air = false; continue; } }
        x = nx; z = nz; y = ny;
        if (y < lev.killY + 1 || y < c.y - 5) { fell = 1; break; }
      } else {
        if ((vx || vz) && wallAt(W, nx, nz, y, h, tt, pass)) { blk = 1; dx = dz = 0; vx = vz = 0; continue; }
        const top = supAt(W, nx, nz, y, tt);
        if (top === -Infinity || top < lev.killY + 1) { fell = 1; break; }
        x = nx; z = nz;
        if (top < y - 1.6) drop = 1;
        y = top;
      }
      if (sly && y < slimeY(lev, tt) + 0.25) { fell = 1; break; }
      haz += hazAt(W, x, z, y, h, tt, mg);
      if (prog && !air) { const pv = prog(x, y, z); if (pv > pb) pb = pv; }
    }
    if (air && !fell && !blk) {   // 아직 공중: 내려설 곳 기준으로 평가
      const top = supAt(W, x, z, y, t0 + n * dt + 0.3);
      if (top === -Infinity || top < lev.killY + 1) fell = 1;
      else { if (top < c.y - 1.6) drop = 1; y = Math.min(y, top); }
    }
    let risk = 0;   // 끝 자리 칸이 곧 무너질 칸이면(조심 여유) 감점
    if (tmg && !fell) { W.tmg = tmg; if (supAt(W, x, z, y, t0 + n * dt) < y - 1) risk = 1; }
    W.tmg = tmg;
    if (prog) { const pv = prog(x, y, z); if (pv > pb) pb = pv; }
    return { x, y, z, haz, fell, blk, drop, risk, pb };
  }
  function aiGoal(W, c, lv, hab, a) {
    const lev = W.lev, t = W.t, D = W.dyn;
    if (lev.finZ != null) {
      let lane = hab.lane * (lev.W / 2 - 2.2);
      a.pass = -1;
      for (const row of lev.drows) {
        if (row.z < c.z - 0.3 || row.z - c.z > 11) continue;
        const ri = lev.drows.indexOf(row);
        let di = a.door[ri];
        if (di == null || a.fake[di]) {
          let best = -1e9;
          for (const d of row.list) {
            if (a.fake[d]) continue;
            const seen = D.dr[d] && (lv > 1 || Math.random() < 0.5);
            let crowd = 0; for (const o of W.chars) if (isLive(o) && o !== c && Math.abs(o.x - lev.doors[d].x) < 1.2 && Math.abs(o.z - row.z) < 3) crowd++;
            const sc = (seen ? 6 : 0) - Math.abs(lev.doors[d].x - c.x) * 0.22 - crowd * 0.6 + Math.random() * (lv === 1 ? 3 : 1.6);
            if (sc > best) { best = sc; di = d; }
          }
          if (di == null) di = row.list[0];
          a.door[ri] = di;
        }
        const dd = lev.doors[di];
        lane = dd.x; a.pass = di;
        // 가짜 문인지 밀어 보고 앎
        if (c.z > row.z - 0.25 - RAD - 0.35 && Math.abs(c.x - dd.x) < dd.w / 2 && !D.dr[di]) { a.push = (a.push || 0) + 0.12; if (a.push > 0.4) { a.fake[di] = 1; a.push = 0; } } else a.push = 0;
        break;
      }
      // 문 앞에서는 고른 문 쪽으로 옆걸음을 크게 침
      let lk = 0.1, tz = c.z + 7;
      if (a.pass >= 0) { const dz = lev.doors[a.pass].z - c.z; if (dz < 4) { lk = 1.4; tz = lev.doors[a.pass].z + 1.5; } }
      return { tx: lane, tz, prog: (x, y, z) => z - Math.abs(x - lane) * lk + (y - c.y) * 0.05 };
    }
    if (lev.steps) {
      if (a.lane == null) { let bd = 1e9; lev.steps.forEach((p, i) => { const d = Math.hypot(p[0].x - c.x, p[0].z - c.z); if (d < bd) { bd = d; a.lane = i; } }); }
      const path = lev.steps[c.stepI >= 0 && c.sup >= 0 && lev.S[c.sup].lane != null ? (a.lane = lev.S[c.sup].lane) : a.lane];
      const i = c.stepI + 1;
      if (i >= path.length || (c.sup >= 0 && lev.S[c.sup].goal)) {
        if (lev.crown) { const cw = crownPos(lev, t + 0.3); return { tx: cw.x, tz: cw.z, prog: (x, y, z) => -Math.hypot(x - cw.x, z - cw.z) + y * 0.5, crown: cw }; }
        return { tx: 0, tz: 0, prog: (x, y, z) => y * 2 - Math.hypot(x, z) * 0.3 };
      }
      const nx = path[i];
      return { tx: nx.x, tz: nx.z, up: nx.y > c.y + 0.3, prog: (x, y, z) => y * 1.6 - Math.hypot(x - nx.x, z - nx.z) * 0.35 };
    }
    if (lev.tiles) {
      const tgt = a.tg;
      if (tgt == null || t > a.tgT || D.tt[tgt] >= 0 || (a.tgS && Math.hypot(a.tgS.x - c.x, a.tgS.z - c.z) < 0.9)) {
        let best = -1e9, bi = -1;
        for (let k = 0; k < 26; k++) {
          const i = Math.floor(Math.random() * lev.tiles), s = (lev.tileS || (lev.tileS = lev.S.filter((q) => q.tile >= 0)))[i];
          if (!s || D.tt[i] >= 0) continue;
          const d = Math.hypot(s.x - c.x, s.z - c.z), dy = s.y + (s.hy || 0) - c.y; if (dy > 0.5 || d > 9) continue;
          let nb = 0; for (const j of lev.nb[i]) if (D.tt[j] < 0) nb++;
          let crowd = 0; for (const o of W.chars) if (isLive(o) && o !== c && Math.hypot(o.x - s.x, o.z - s.z) < 1.8) crowd++;
          const sc = nb * 0.7 - d * 0.32 - crowd * 1.3 + dy * 0.5 + Math.random() * (lv === 1 ? 2.5 : 1);
          if (sc > best) { best = sc; bi = i; }
        }
        if (bi >= 0) { a.tg = bi; a.tgT = t + (lv === 3 ? 0.8 : 1.3) + Math.random(); a.tgS = lev.tileS[bi]; }
      }
      const s = a.tgS || c;
      return { tx: s.x, tz: s.z, prog: (x, y, z) => -Math.hypot(x - s.x, z - s.z) * 0.6 + y * 0.4 };
    }
    if (lev.type === 'sweep') {
      if (!a.wt || t > a.tgT) { const r = (0.25 + Math.random() * 0.4) * lev.Rd, an = Math.random() * TAU; a.wt = [Math.sin(an) * r, Math.cos(an) * r]; a.tgT = t + 1.5 + Math.random() * 2; }
      const [wx, wz] = a.wt;
      return { tx: wx, tz: wz, prog: (x, y, z) => -Math.hypot(x - wx, z - wz) * 0.25 - Math.max(0, Math.hypot(x, z) - lev.Rd * 0.75) * 2 };
    }
    if (lev.zone) {
      const zn = lev.zone, ox = hab.lane * 1.2, oz = (hab.nz - 0.5) * 2;
      return { tx: zn.x + ox, tz: zn.z + oz, up: c.y < zn.y - 0.2, prog: (x, y, z) => -Math.hypot(x - zn.x - ox, z - zn.z - oz) * 0.5 + (y > zn.y - 0.2 ? 3 : 0) - Math.max(0, Math.hypot(x, z) - lev.Rd + 1.5) * 3 };
    }
    if (lev.goals) {
      const F = lev.field, myT = c.team, atkZ = myT === 0 ? F.L / 2 + 1 : -F.L / 2 - 1, ownZ = -atkZ;
      let b = null, bd = 1e9; for (const q of D.bl) { if (q.off) continue; const d = Math.hypot(q.x - c.x, q.z - c.z); if (d < bd) { bd = d; b = q; } }
      if (!b) return { tx: 0, tz: ownZ * 0.4, prog: (x, y, z) => -Math.hypot(x, z - ownZ * 0.4) * 0.3 };
      let ux = -b.x, uz = atkZ - b.z; const ul = Math.hypot(ux, uz); ux /= ul; uz /= ul;
      if (hab.def < 0.22) {   // 수비 버릇
        const gx = b.x * 0.35, gz = ownZ + (b.z - ownZ) * 0.35;
        return { tx: gx, tz: gz, prog: (x, y, z) => -Math.hypot(x - gx, z - gz) * 0.4 };
      }
      const px = b.x - ux * 2.2, pz = b.z - uz * 2.2, ahead = (c.x - b.x) * ux + (c.z - b.z) * uz;
      if (ahead > -0.6 || Math.hypot(c.x - px, c.z - pz) > 1.1) {
        const side = ((c.x - b.x) * uz - (c.z - b.z) * ux) >= 0 ? 1 : -1, wx = ahead > -0.6 ? px + uz * side * 2.4 : px, wz = ahead > -0.6 ? pz - ux * side * 2.4 : pz;
        return { tx: wx, tz: wz, prog: (x, y, z) => -Math.hypot(x - wx, z - wz) * 0.5 - Math.max(0, 2.6 - Math.hypot(x - b.x, z - b.z)) * 1.5 };
      }
      const gx = b.x + ux * 3, gz = b.z + uz * 3;
      return { tx: gx, tz: gz, prog: (x, y, z) => -Math.hypot(x - gx, z - gz) * 0.5, push: 1, ball: b };
    }
    if (lev.nests) {
      const my = lev.nests[c.team], ci = W.carry[c.s];
      if (ci >= 0) return { tx: my.x, tz: my.z, prog: (x, y, z) => -Math.hypot(x - my.x, z - my.z) * 0.5 };
      let best = null, bd = 1e9;
      for (const e of D.eg) { if (!e.on || e.h >= 0) continue; const d = Math.hypot(e.x - c.x, e.z - c.z) + Math.random() * 1.5; if (d < bd) { bd = d; best = e; } }
      if ((!best || bd > 12) && hab.ag > 0.3) {
        let rn = null, rs = 0; for (const n of lev.nests) if (n.team !== c.team && D.sc[n.team] > rs) { rs = D.sc[n.team]; rn = n; }
        if (rn) return { tx: rn.x, tz: rn.z, prog: (x, y, z) => -Math.hypot(x - rn.x, z - rn.z) * 0.5, steal: 1 };
      }
      // 상대 운반자 쫓기
      if (hab.ag > 0.55) for (const o of W.chars) if (isLive(o) && o.team !== c.team && W.carry[o.s] >= 0 && Math.hypot(o.x - c.x, o.z - c.z) < 7) return { tx: o.x, tz: o.z, prog: (x, y, z) => -Math.hypot(x - o.x, z - o.z) * 0.5, chase: o.s };
      if (best) { const e = best; return { tx: e.x, tz: e.z, prog: (x, y, z) => -Math.hypot(x - e.x, z - e.z) * 0.5 }; }
      return { tx: 0, tz: 0, prog: (x, y, z) => -Math.hypot(x, z) * 0.2 };
    }
    return { tx: c.x, tz: c.z + 3, prog: (x, y, z) => z };
  }
  function aiInput(W, c, lv, hab) {
    const t = W.t;
    let a = c.ai;
    if (!a) a = c.ai = { nt: 0, mx: 0, mz: 0, gT: -1, door: {}, fake: {}, sx: c.x, sz: c.z, sT: t, wig: -1, wd: 0, la: 0, pass: -1 };
    if (t < 0 || c.st >= ST.RESP) { a.sT = t; a.sx = c.x; a.sz = c.z; return IDLE; }
    const o = { mx: a.mx, mz: a.mz, j: 0, d: 0, g: t < a.gT ? 1 : 0 };
    if (c.st !== ST.RUN) { a.sT = t; a.sx = c.x; a.sz = c.z; return o; }
    if (t < a.nt || !c.gr) return o;   // 공중에선 정한 방향 그대로
    a.nt = t + (lv === 1 ? 0.2 : lv === 2 ? 0.13 : 0.1) * hab.rt * (W.lev.tiles ? 1.4 : 1);
    // 막힘 풀기(떨어지지 않는 쪽으로만)
    if (t - a.sT > 1.6) {
      if (Math.hypot(c.x - a.sx, c.z - a.sz) < 0.6 && !a.still) {
        for (let k = 0; k < 6; k++) { const wd = Math.random() * TAU, r = rollout(W, c, Math.sin(wd), Math.cos(wd), 0, 0.1, a.pass, RUN); if (!r.fell) { a.wig = t + 0.45; a.wd = wd; break; } }
      }
      a.sx = c.x; a.sz = c.z; a.sT = t;
    }
    if (t < a.wig) { o.mx = a.mx = Math.sin(a.wd); o.mz = a.mz = Math.cos(a.wd); if ((W.lev.k === 'race' || W.lev.steps) && Math.random() < 0.3) o.j = 1; return o; }
    if (lv === 1 && Math.random() < 0.02) { a.mx = a.mz = 0; a.nt = t + 0.35; return IDLE; }
    const g = aiGoal(W, c, lv, hab, a);
    const lev = W.lev;
    const mg = lv === 3 ? 0.42 : lv === 2 ? 0.28 : 0.14, hazW = lv === 1 ? (Math.random() < 0.3 ? 1 : 5) : lv === 2 ? 12 : 26, noise = lv === 1 ? 1.2 : lv === 2 ? 0.5 : 0.2;
    // 무너지는 바닥: 서 있는 칸이 아직 멀쩡하면 천천히(칸을 아낌), 무너지기 시작했으면 전력으로
    let walk = lv === 1 ? 0.88 : lv === 2 ? 0.95 : 1;
    if (lev.tiles) { const ti = tileAt(W, c); if (!(ti >= 0 && W.dyn.tt[ti] >= 0)) walk = 0.72 + hab.cau * 0.08; }
    const sp0 = RUN * (c.egg ? 0.9 : 1) * walk;
    W.tmg = lev.tiles ? (lv === 3 ? 0.45 : lv === 2 ? 0.35 : 0.1) : 0;
    const p0 = g.prog(c.x, c.y, c.z), base = Math.atan2(g.tx - c.x, g.tz - c.z);
    let best = -1e9, bm = 0, ba = 0, bmov = 0;
    const evalR = (ang, mode, mov) => {
      const dx = mov ? Math.sin(ang) : 0, dz = mov ? Math.cos(ang) : 0;
      const r = rollout(W, c, dx, dz, mode, mg, a.pass, sp0, g.prog);
      let crowd = 0; if (mov) for (const q of W.chars) if (q && q !== c && isLive(q) && Math.abs(q.x - r.x) < 1 && Math.abs(q.z - r.z) < 1) crowd++;
      let sc = (r.pb - p0) - r.haz * hazW - r.fell * 60 - r.drop * (lev.tg || lev.hex ? 18 : lev.steps ? 6 : 1.5) - r.risk * 5 - r.blk * 1.2 - crowd * 0.35 + (Math.random() - 0.5) * noise;
      if (mode === 1) sc -= (lev.tiles ? 1.5 : 0.3) * (1.2 - hab.jmp * 0.6);
      if (mode === 2) sc -= 0.7;
      if (mov && Math.abs(Math.atan2(Math.sin(ang - a.la), Math.cos(ang - a.la))) < 0.3) sc += lev.tiles ? 0.6 : 0.2;
      if (sc > best) { best = sc; bm = mode; ba = ang; bmov = mov; }
      return r;
    };
    const stay = evalR(0, 0, 0);
    if (stay.haz || stay.fell) { evalR(0, 1, 0); }
    for (const off of DIRS[lv]) {
      const ang = base + off;
      const r = evalR(ang, 0, 1);
      if (r.fell || r.blk || r.haz || r.drop || g.up) evalR(ang, 1, 1);
      if ((r.haz && lev.type === 'sweep' && t > 17.5) || (r.fell && lev.k === 'race')) evalR(ang, 2, 1);
    }
    if (bmov) { a.mx = Math.sin(ba) * walk; a.mz = Math.cos(ba) * walk; a.la = ba; } else { a.mx = a.mz = 0; }
    a.still = !bmov;
    o.mx = a.mx; o.mz = a.mz;
    if (bm === 1) o.j = 1; else if (bm === 2) o.d = 1;
    // 결승선 앞 다이브(버릇)
    if (lev.finZ != null && hab.dv > 0.35 && lev.finZ - c.z > 1.2 && lev.finZ - c.z < 3.0 && c.gr && Math.random() < 0.5) o.d = 1;
    if (g.crown && Math.hypot(g.crown.x - c.x, g.crown.z - c.z) < 1.3 && c.gr) o.j = 1;
    if (g.push && g.ball && c.gr) { const b = g.ball, d = Math.hypot(b.x - c.x, b.z - c.z); if (d < 3.4 && Math.random() < 0.18 + hab.dv * 0.25) { const q = d || 1; o.mx = a.mx = (b.x - c.x) / q; o.mz = a.mz = (b.z - c.z) / q; o.d = 1; } }
    // 밀치기 · 잡기 (상황 + 버릇)
    const team = c.team;
    let foe = null, fd = 1.7;
    for (const q of W.chars) {
      if (!isLive(q) || q === c || (team >= 0 && q.team === team)) continue;
      const dx = q.x - c.x, dz = q.z - c.z, d = Math.hypot(dx, dz);
      if (d < fd && Math.abs(q.y - c.y) < 1 && (dx * Math.sin(c.yaw) + dz * Math.cos(c.yaw)) / (d || 1) > 0.3) { fd = d; foe = q; }
    }
    if (foe) {
      const want = lev.k === 'race' ? hab.ag * 0.06 : lev.zone ? (c.y > lev.zone.y - 0.2 || foe.y > lev.zone.y - 0.2 ? 0.25 + hab.ag * 0.5 : 0.05) : lev.nests ? (W.carry[foe.s] >= 0 ? 0.6 + hab.ag * 0.4 : 0.05) : lev.goals ? 0.04 : hab.ag * 0.12;
      if (Math.random() < want * (lv === 1 ? 0.5 : lv === 2 ? 0.8 : 1)) {
        if (Math.random() < 0.55 && !o.j) { a.gT = t + 0.5 + Math.random() * 0.8; o.g = 1; }
        else if (fd < 1.5 && !o.j) o.d = 1;
      }
    }
    if (g.chase != null) { const q = W.chars[g.chase]; if (q && Math.hypot(q.x - c.x, q.z - c.z) < 2.2 && Math.random() < 0.35 + hab.ag * 0.3) o.d = 1; }
    if (o.d && bm !== 2) { const dx = Math.hypot(o.mx, o.mz) > 0.1 ? o.mx : Math.sin(c.yaw), dz = Math.hypot(o.mx, o.mz) > 0.1 ? o.mz : Math.cos(c.yaw), q = Math.hypot(dx, dz) || 1; if (rollout(W, c, dx / q, dz / q, 2, 0, a.pass, RUN).fell) o.d = 0; }
    W.tmg = 0;
    return o;
  }

  /* ======================= 쇼 진행 ======================= */
  function showPlan(n, len) {
    const F = Math.min(n, n <= 3 ? 2 : n <= 6 ? 3 : n <= 12 ? 4 : n <= 20 ? 5 : 6);
    let Q = n <= F ? 1 : Math.max(1, Math.ceil(Math.log(F / n) / Math.log(0.58) - 0.05));
    if (len === 'short') Q = Math.max(1, Q - 1); else if (len === 'long') Q = Math.min(Q + 1, Math.max(1, n - F));
    return { F, Q };
  }
  const aliveOf = (st) => { const a = []; for (let s = 0; s < st.n; s++) if (st.alive[s]) a.push(s); return a; };
  function teamCount(na, K) { const e = 1 - K / na; let T = e >= 0.4 ? 2 : e >= 0.27 ? 3 : 4; T = Math.min(T, Math.floor(na / 2)); return Math.max(2, T); }
  function setupRound(st) {
    const al = aliveOf(st), na = al.length;
    const final = st.ri >= st.Q || (st.ri > 0 && na <= st.F);
    const R = prng((st.seed + st.ri * 7919 + 13) >>> 0);
    st.rs = 1 + Math.floor(R() * 2e9);
    st.team = null; st.nT = 0;
    if (final) {
      st.fn = 1; st.K = 1;
      const fl = FTYPES.filter((f) => (st.fins || FTYPES).includes(f));
      st.rt = st.fin && st.fin !== 'rnd' && TYPES[st.fin] ? st.fin : fl[Math.floor(R() * fl.length)] || 'hex';
    } else {
      st.fn = 0;
      const r = Math.max(1, st.Q - st.ri);
      st.K = na > st.F ? clamp(Math.round(na * Math.pow(st.F / na, 1 / r)), Math.min(st.F, na), na - 1) : na;
      const noE = st.K >= na;
      const ok = (ty) => {
        if (TYPES[ty].k !== 'team') return true;
        if (noE || na < 4) return false;
        const T = teamCount(na, st.K);
        if (ty === 'ball' && T !== 2) return false;
        return na - Math.ceil(na / T) >= Math.min(2, st.F);
      };
      let cands = st.pool.filter((ty) => !st.used.includes(ty) && ok(ty));
      if (!cands.length) cands = st.pool.filter(ok);
      if (!cands.length) cands = ['obst'];
      if (st.ri === 0) { const rc = cands.filter((ty) => TYPES[ty].k === 'race'); if (rc.length) cands = rc; }
      st.rt = cands[0];
      st.used.push(st.rt);
      if (TYPES[st.rt].k === 'team') {
        const T = st.rt === 'ball' ? 2 : teamCount(na, st.K), ord = shuffle(R, al.slice());
        st.nT = T; st.team = Array(st.n).fill(-1);
        ord.forEach((s, i) => { st.team[s] = i % T; });
      }
    }
    st.ph = 'intro'; st.rr = null; st.seq = (st.seq || 0) + 1;
    return st;
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = Math.random;
    const len = ['short', 'normal', 'long'].includes(opts.len) ? opts.len : 'normal';
    const { F, Q } = showPlan(n, len);
    let modes = Array.isArray(opts.modes) ? opts.modes.filter((m) => QTYPES.includes(m)) : QTYPES.slice();
    if (!modes.length) modes = QTYPES.slice();
    const pr = prng(1 + Math.floor(R() * 2e9));
    const st = {
      v: 1, ph: 'intro', rid: 1 + Math.floor(R() * 1e6), seed: 1 + Math.floor(R() * 2e9), n, nm: players.map((p) => String(p.name || '').slice(0, 12)),
      len, F, Q, fin: FTYPES.includes(opts.fin) ? opts.fin : 'rnd', pool: shuffle(pr, modes), used: [], ri: 0, rt: null, K: n, rs: 1, fn: 0, team: null, nT: 0,
      alive: Array(n).fill(1), eo: Array(n).fill(-1), ord: [], rr: null, hist: [], win: -1, seq: 0,
    };
    return setupRound(st);
  }
  function endRound(st, out) {
    const ns = JSON.parse(JSON.stringify(st));
    for (const s of out.e) if (ns.alive[s]) { ns.alive[s] = 0; ns.eo[s] = ns.ri; ns.ord.push(s); }
    ns.rr = { q: out.q.slice(), e: out.e.slice(), sc: out.sc || null, lt: out.lt == null ? -1 : out.lt, win: out.win == null ? -1 : out.win, hp: out.hp || null, rt: ns.rt };
    ns.hist.push([ns.rt, out.q.length, out.e.length, ns.ri]);
    if (out.win != null && out.win >= 0) {
      ns.win = out.win;
      for (let s = 0; s < ns.n; s++) if (ns.alive[s] && s !== out.win) { ns.alive[s] = 0; ns.eo[s] = ns.ri; ns.ord.push(s); }
    }
    ns.ph = 'res'; ns.seq++;
    return ns;
  }
  function afterRes(st) {
    const ns = JSON.parse(JSON.stringify(st)), al = aliveOf(ns);
    if (ns.win >= 0 || al.length <= 1) {
      if (ns.win < 0) ns.win = al.length ? al[0] : (ns.ord.length ? ns.ord[ns.ord.length - 1] : 0);
      ns.ph = 'done'; ns.seq++;
      return ns;
    }
    ns.ri++;
    return setupRound(ns);
  }
  function result(s) {
    if (!s || s.ph !== 'done' || s.win < 0) return null;
    const nm = (i) => (s.nm && s.nm[i]) || ((i + 1) + '번');
    const rank = [s.win].concat(s.ord.slice().reverse().filter((x) => x !== s.win));
    const total = s.hist.length;
    const lines = rank.map((p, k) => (k + 1) + '위  ' + nm(p) + '  ' + (p === s.win ? '우승' : (s.eo[p] >= 0 ? 'R' + (s.eo[p] + 1) + ' ' + TYPES[(s.hist[s.eo[p]] || [])[0] || 'obst'].nm + ' 탈락' : '')));
    return {
      winners: [s.win], title: nm(s.win) + ' 우승',
      text: lines.join('\n'),
      highlights: s.hist.map((h, i) => 'R' + (i + 1) + ' ' + TYPES[h[0]].nm + ' — ' + (TYPES[h[0]].k === 'final' ? '결승' : h[2] ? (h[1] + h[2]) + '명 중 ' + h[1] + '명 통과' : '탈락 없음')).slice(0, 4),
      stats: [{ label: '도달 라운드', values: [...Array(s.n).keys()].map((p) => 'R' + (p === s.win ? total : s.eo[p] >= 0 ? s.eo[p] + 1 : total)) }],
    };
  }
  function hint(st, seat) {
    if (!st || !st.rt) return null;
    const T = TYPES[st.rt], na = aliveOf(st).length, out = ['라운드 ' + (st.ri + 1) + ' · ' + T.nm + ' (' + KIND_NM[T.k] + ')'];
    out.push(T.d);
    if (T.k !== 'final') out.push(st.K >= na ? '이번 라운드는 탈락 없음(연습 라운드).' : '참가 ' + na + '명 중 약 ' + st.K + '명 다음 라운드 진출.');
    if (st.team && seat >= 0 && st.team[seat] >= 0) out.push('소속: ' + TEAM_NM[st.team[seat]] + ' 팀');
    if (seat >= 0 && !st.alive[seat]) out.push('탈락 — 관전 중. 화면 탭(또는 Tab)으로 관전 대상 변경.');
    out.push('조작: 이동 · 점프 · 다이브(전방 도약) · 잡기(누르는 동안)');
    return out.slice(0, 6);
  }

  /* ======================= 네트워크 묶기 ======================= */
  const r1 = (v) => Math.round(v * 10);
  function packChar(c, W) {
    const fl = (c.gr ? 1 : 0) | (c.egg ? 2 : 0) | (c.grab >= 0 ? 4 : 0) | (c.inv > 0 ? 8 : 0) | (c.land > 0 ? 16 : 0);
    return [r1(c.x), r1(c.y), r1(c.z), Math.round(c.yaw * 50), c.st, fl, c.grab, r1(c.vx), r1(c.vy), r1(c.vz), c.cp, c.stepI];
  }
  function packDyn(W) {
    const D = W.dyn, lev = W.lev, o = { q: D.q, o: D.o };
    if (lev.tiles) { let s = ''; for (let i = 0; i < lev.tiles; i++) s += D.tl[i]; o.tl = s; }
    if (lev.doors.length) { let s = ''; for (let i = 0; i < lev.doors.length; i++) s += D.dr[i]; o.dr = s; }
    if (lev.ss) o.ss = Array.from(D.ss, (v) => Math.round(v * 1000));
    if (lev.balls) o.bl = D.bl.map((b) => [r1(b.x), r1(b.z), r1(b.vx), r1(b.vz), b.off ? 1 : 0]);
    if (lev.nests) o.eg = D.eg.map((e) => (e.on ? (e.h >= 0 ? [e.h] : [r1(e.x), r1(e.z)]) : 0));
    if (D.sc.length) { o.sc = D.sc.slice(); o.ot = D.ot; }
    if (lev.zone) o.hp = Array.from(D.hp, (v) => Math.round(v * 10));
    return o;
  }
  function unpackDyn(W, o) {
    if (!o) return;
    const D = W.dyn, lev = W.lev;
    if (Array.isArray(o.q)) D.q = o.q.slice();
    if (Array.isArray(o.o)) D.o = o.o.slice();
    if (typeof o.tl === 'string') for (let i = 0; i < lev.tiles && i < o.tl.length; i++) D.tl[i] = +o.tl[i];
    if (typeof o.dr === 'string') for (let i = 0; i < lev.doors.length && i < o.dr.length; i++) D.dr[i] = +o.dr[i];
    if (Array.isArray(o.ss)) for (let i = 0; i < lev.ss && i < o.ss.length; i++) D.ss[i] = o.ss[i] / 1000;
    if (Array.isArray(o.bl)) o.bl.forEach((a, i) => { const b = D.bl[i]; if (!b) return; b.tx = a[0] / 10; b.tz = a[1] / 10; b.vx = a[2] / 10; b.vz = a[3] / 10; b.off = a[4]; if (b.x == null || Math.hypot(b.tx - b.x, b.tz - b.z) > 6) { b.x = b.tx; b.z = b.tz; } });
    if (Array.isArray(o.eg)) {
      W.carry.fill(-1);
      o.eg.forEach((a, i) => { const e = D.eg[i]; if (!e) return; if (!a) { e.on = 0; e.h = -1; } else if (a.length === 1) { e.on = 1; e.h = a[0]; W.carry[a[0]] = i; } else { e.on = 1; e.h = -1; e.x = a[0] / 10; e.z = a[1] / 10; } });
      for (const c of W.chars) if (c) c.egg = W.carry[c.s] >= 0 ? 1 : 0;
    }
    if (Array.isArray(o.sc)) { D.sc = o.sc.slice(); D.ot = o.ot || 0; }
    if (Array.isArray(o.hp)) o.hp.forEach((v, i) => { D.hp[i] = v / 10; });
  }

  /* ======================= 규칙 ======================= */
  const RULES = [
    { h: '목표', p: ['라운드마다 일부 탈락, 마지막 결승의 승자 1명이 우승.', '참가 2~32명, 빈자리는 봇. 라운드 수는 인원에 따라 2~6(「쇼 길이」로 조절).'] },
    { h: '진행', p: ['라운드 시작 전 경기 소개 → 카운트다운 후 시작.', '레이스: 결승선 통과 인원이 정원에 차면 종료, 미통과자 탈락. 낙하 시 마지막 체크포인트에서 재개.', '서바이벌: 낙하 또는 액체 접촉 시 탈락. 탈락 인원이 정해진 수에 이르면 생존자 전원 통과.', '팀전: 무작위 편성. 종료 시점에 최저 득점 팀 전원 탈락.', '결승: 최후의 1인(헥스 폴) · 고지 누적 25초(고지 점령) · 트로피 획득(트로피 쟁탈).', '참가자가 2명이면 첫 라운드는 탈락 없는 연습 라운드.'] },
    { h: '경기 종류 (11)', p: Object.keys(TYPES).map((k) => TYPES[k].nm + ' (' + KIND_NM[TYPES[k].k] + ') — ' + TYPES[k].d).concat(['경기 종류와 코스는 쇼마다 무작위로 새로 생성. 「경기 종류」 옵션에서 제외 가능.']) },
    { h: '조작 — 모바일', p: ['왼쪽 아래 끌기: 이동(가상 스틱).', '오른쪽 버튼: 점프(큰 버튼) · 다이브(전방 도약 — 빠르고 낮은 자세) · 잡기(누르는 동안 앞 참가자를 붙잡아 감속).', '오른쪽 빈 화면 끌기: 시점 회전. 탈락 후 화면 탭: 관전 대상 변경.'] },
    { h: '조작 — PC', p: ['WASD/방향키 이동 · Space 점프 · Shift(또는 C) 다이브 · F(또는 E) 잡기.', '마우스 끌기 또는 휠, Q/Z: 시점. Tab: 관전 대상 변경. 게임패드: 왼쪽 스틱 · A 점프 · B 다이브 · RT 잡기 · 오른쪽 스틱 시점. 키는 「⌨ 조작 설정」에서 변경.'] },
    { h: '요령', p: ['다이브는 공중에서도 1회 가능 — 점프 후 다이브로 더 먼 거리.', '높은 회전 바는 점프로 넘을 수 없음 — 다이브로 아래를 통과.', '장애물에 강하게 맞으면 잠시 넘어짐(직후 짧은 무적). 범퍼는 반발력으로 밀어냄.', '잡기: 잡힌 쪽은 크게, 잡은 쪽도 감속(최대 2.6초). 코어 운반자를 0.5초 이상 잡으면 탈취.', '시소는 하중 방향으로 기울어짐. 역방향 컨베이어는 뒤로 밀고, 회전 플랫폼은 올라탄 참가자를 함께 회전.'] },
    { h: '커스터마이즈', p: ['설정 화면 「커스터마이즈」: 경기복 색 2 · 무늬 8 · 머리 장식 6 · 바이저 4(이 기기에 저장, 온라인 상대에게도 표시).', '봇은 무작위 외형. 팀전에서는 발밑 링과 바이저 테가 팀 색.'] },
    { h: '그래픽', p: ['설정 화면 「그래픽 품질(이 기기)」: 낮음(모바일 기본) · 보통 · 높음(그림자 · 고해상도). 끊기면 낮음 권장.'] },
    { h: 'AI', p: ['AI 난이도는 자리마다 쉬움 · 보통 · 어려움. 쉬움은 장애물 판단이 늦고 머뭇거림이 잦음, 어려움은 멀리 내다보고 타이밍이 정확함.', '봇마다 성향(몸싸움 · 신중함 · 주행 라인 · 다이브 선호 · 수비 성향)이 다름.'] },
    { h: '제작 정보', p: ['참가자 · 장애물 · 경기장 · 하늘은 모두 코드로 생성한 3D 형상(외부 모델 · 그림 없음). 효과음은 앱 합성음.', '3D 엔진: three.js (MIT) — 하이퍼 레이스와 같은 파일 공용. 출처: app/assets/dropout/CREDITS.txt'] },
  ];
  const CONTROLS = [
    { id: 'up', label: '앞으로', keys: ['KeyW', 'ArrowUp'], pad: ['ly-', 'up'] },
    { id: 'down', label: '뒤로', keys: ['KeyS', 'ArrowDown'], pad: ['ly+', 'down'] },
    { id: 'left', label: '왼쪽', keys: ['KeyA', 'ArrowLeft'], pad: ['lx-', 'left'] },
    { id: 'right', label: '오른쪽', keys: ['KeyD', 'ArrowRight'], pad: ['lx+', 'right'] },
    { id: 'jump', label: '점프', keys: ['Space'], pad: ['a'] },
    { id: 'dive', label: '다이브', keys: ['ShiftLeft', 'KeyC'], pad: ['b', 'x'] },
    { id: 'grab', label: '잡기(누르는 동안)', keys: ['KeyF', 'KeyE'], pad: ['rt', 'rb'] },
    { id: 'camL', label: '시점 왼쪽으로', keys: ['KeyQ'], pad: ['rx-'] },
    { id: 'camR', label: '시점 오른쪽으로', keys: ['KeyZ'], pad: ['rx+'] },
    { id: 'camU', label: '시점 위로', keys: ['PageUp'], pad: ['ry-'] },
    { id: 'camD', label: '시점 아래로', keys: ['PageDown'], pad: ['ry+'] },
    { id: 'spec', label: '지켜볼 사람 바꾸기', keys: ['Tab'], pad: ['y'] },
  ];
  const ICON_T = {
    race: '<path d="M10 44 L22 14 h4 L18 44z M22 14 h20 l-4 8 h-18z M24 26 h14 l-3 6 h-13z" fill="currentColor"/>',
    surv: '<rect x="8" y="30" width="12" height="6" rx="1.5" fill="currentColor"/><rect x="22" y="30" width="12" height="6" rx="1.5" fill="currentColor"/><rect x="36" y="38" width="12" height="6" rx="1.5" fill="currentColor" opacity=".55"/><circle cx="28" cy="20" r="6" fill="currentColor"/>',
    team: '<circle cx="28" cy="28" r="12" fill="none" stroke="currentColor" stroke-width="4"/><path d="M16 28h24M28 16v24" stroke="currentColor" stroke-width="3"/><rect x="4" y="22" width="5" height="12" fill="currentColor"/><rect x="47" y="22" width="5" height="12" fill="currentColor"/>',
    final: '<path d="M10 40 L14 18 L22 28 L28 14 L34 28 L42 18 L46 40z" fill="currentColor"/><rect x="10" y="42" width="36" height="5" rx="2" fill="currentColor"/>',
  };
  const codex = [
    { h: '경기 종류', p: ['11종 — 쇼마다 무작위 편성(첫 라운드는 레이스, 마지막은 결승).'], rows: Object.keys(TYPES).map((k) => ({ icon: '<svg viewBox="0 0 56 56" width="28" height="28" style="color:' + TYPES[k].col + '">' + ICON_T[TYPES[k].k] + '</svg>', name: TYPES[k].nm, tag: KIND_NM[TYPES[k].k], desc: TYPES[k].d })) },
    { h: '장애물', p: ['레이스 코스는 아래 구간을 쇼마다 무작위로 이어 붙여 생성.'], rows: Object.keys(SEG_NM).map((k) => ({ icon: '<svg viewBox="0 0 56 56" width="28" height="28">' + ICON_T.race + '</svg>', name: SEG_NM[k], tag: '코스 구간',
      desc: ({ spin: '낮은 높이로 회전하는 바. 점프로 넘기, 접촉 시 넘어짐.', hammer: '머리 위 축에서 좌우로 흔들리는 대형 해머. 통과 직후의 틈을 노림.', movers: '낙하 구간 위를 좌우 · 앞뒤 · 상하로 움직이는 발판.', conveyor: '뒤로 흐르는 바닥과 반발 범퍼.', seesaw: '하중 방향으로 기우는 판. 중앙을 따라 이동하면 안정적.', doors: '열리는 문과 고정된 가짜 문이 섞인 게이트 벽.', punch: '측면에서 주기적으로 돌출해 밀어내는 피스톤.', roll: '경사로 위에서 대형 구체가 열을 지어 굴러 내려옴.', discs: '올라탄 참가자를 함께 회전시키는 플랫폼(중앙 범퍼).', gaps: '높이가 다른 발판. 점프로 연속 이동.' })[k] })) },
    { h: '커스터마이즈', p: ['설정 화면 「커스터마이즈」에서 선택. 모든 항목 처음부터 사용 가능(해금 없음).'], rows: [
      { icon: '<svg viewBox="0 0 56 56" width="28" height="28"><rect x="12" y="12" width="32" height="32" rx="9" fill="#3a6ff7"/></svg>', name: '경기복 색', tag: '16색 × 2', desc: '바탕 색과 무늬 색을 따로 선택.' },
      { icon: '<svg viewBox="0 0 56 56" width="28" height="28"><rect x="12" y="12" width="32" height="32" rx="9" fill="#2b2d42"/><path d="M12 24h32M12 34h32" stroke="#f0b429" stroke-width="5"/></svg>', name: '무늬', tag: LOOK.pats.length + '종', desc: LOOK.pats.join(' · ') },
      { icon: '<svg viewBox="0 0 56 56" width="28" height="28"><rect x="12" y="20" width="32" height="28" rx="9" fill="#8d99ae"/><path d="M22 20 L18 8 M34 20 L38 8" stroke="#8d99ae" stroke-width="4"/></svg>', name: '머리 장식', tag: LOOK.accs.length + '종', desc: LOOK.accs.join(' · ') },
      { icon: '<svg viewBox="0 0 56 56" width="28" height="28"><rect x="12" y="14" width="32" height="32" rx="9" fill="#8d99ae"/><rect x="15" y="22" width="26" height="10" rx="5" fill="#111"/><rect x="18" y="24" width="12" height="2" rx="1" fill="#fcbf49"/></svg>', name: '바이저', tag: LOOK.eyes.length + '종', desc: LOOK.eyes.join(' · ') },
    ] },
  ];

  /* ======================= 꾸미기 창 (설정 화면 — 2D 미리보기) ======================= */
  const VISOR = [['#0d0f14', '#5ad1ff'], ['#2a2110', '#ffcf5a'], ['#2b3036', '#e8eef4'], ['#0a2a2c', '#3ff0d0']];   // [바탕, 빛줄]
  /* 2D 참가자(커스터마이즈 미리보기 · 홈 미리보기): 정면, 발바닥 가운데 = (cx, fy), s = 키(px)/1.35 */
  function drawFig(g, cx, fy, s, lk, team) {
    if (!g.roundRect) g.roundRect = function (x, y, w2, h2) { this.rect(x, y, w2, h2); };
    const c1 = LOOK.cols[lk.c1], c2 = LOOK.cols[lk.c2], u = s / 100, vc = VISOR[lk.eye] || VISOR[0];
    const shade = (hex, k) => { const n = parseInt(hex.slice(1), 16), r = (n >> 16) & 255, gg = (n >> 8) & 255, b = n & 255; return 'rgb(' + Math.round(r * k) + ',' + Math.round(gg * k) + ',' + Math.round(b * k) + ')'; };
    const hipY = fy - 40 * u, torsoTop = hipY - 54 * u, headC = hipY - 71 * u, hr = 21 * u;
    g.save();
    g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(cx, fy + 1.5 * u, 30 * u, 6 * u, 0, 0, TAU); g.fill();
    // 다리 · 신발
    for (const sg of [-1, 1]) {
      g.fillStyle = shade(c2, 0.75); g.beginPath(); g.roundRect(cx + sg * 11 * u - 8 * u, hipY - 2 * u, 16 * u, 36 * u, 8 * u); g.fill();
      g.fillStyle = '#1a1e2a'; g.beginPath(); g.roundRect(cx + sg * 11 * u - 9 * u, fy - 9 * u, 18 * u, 10 * u, 4 * u); g.fill();
    }
    // 등 장비(뒤)
    if (lk.acc === 5) { g.fillStyle = shade(c2, 0.85); g.beginPath(); g.roundRect(cx - 17 * u, torsoTop + 8 * u, 34 * u, 28 * u, 5 * u); g.fill(); }
    // 팔
    for (const sg of [-1, 1]) {
      g.save(); g.translate(cx + sg * 30 * u, torsoTop + 11 * u); g.rotate(sg * 0.12);
      g.fillStyle = shade(c1, 0.9); g.beginPath(); g.roundRect(-6.5 * u, 0, 13 * u, 36 * u, 6.5 * u); g.fill();
      g.beginPath(); g.arc(0, 38 * u, 8 * u, 0, TAU); g.fill(); g.restore();
    }
    // 몸통(선반 모양 단면)
    const torso = () => { g.beginPath(); g.moveTo(cx - 21 * u, hipY); g.bezierCurveTo(cx - 24 * u, hipY - 20 * u, cx - 20 * u, hipY - 26 * u, cx - 26 * u, hipY - 40 * u); g.bezierCurveTo(cx - 29 * u, hipY - 50 * u, cx - 18 * u, torsoTop, cx, torsoTop); g.bezierCurveTo(cx + 18 * u, torsoTop, cx + 29 * u, hipY - 50 * u, cx + 26 * u, hipY - 40 * u); g.bezierCurveTo(cx + 20 * u, hipY - 26 * u, cx + 24 * u, hipY - 20 * u, cx + 21 * u, hipY); g.quadraticCurveTo(cx, hipY + 6 * u, cx - 21 * u, hipY); g.closePath(); };
    torso(); g.fillStyle = c1; g.fill();
    g.save(); torso(); g.clip(); g.fillStyle = c2;
    const x0 = cx - 30 * u, w = 60 * u, mid = hipY - 27 * u, pt = lk.pat;
    if (pt === 1) { g.fillRect(x0, mid - 8 * u, w, 9 * u); g.fillRect(x0, mid + 9 * u, w, 5 * u); }
    if (pt === 2) for (let a = 0; a < 6; a++) for (let b = 0; b < 6; b++) { g.beginPath(); g.arc(x0 + (5 + a * 10 + (b % 2) * 5) * u, torsoTop + (5 + b * 9) * u, 2.4 * u, 0, TAU); g.fill(); }
    if (pt === 3) g.fillRect(cx, torsoTop, 30 * u, 60 * u);
    if (pt === 4) for (let a = 0; a < 7; a++) for (let b = 0; b < 7; b++) if ((a + b) % 2) g.fillRect(x0 + a * 9 * u, torsoTop + b * 9 * u, 9 * u, 9 * u);
    if (pt === 5) { g.beginPath(); for (let k = 0; k <= 8; k++) g.lineTo(x0 + k * 7.5 * u, mid + (k % 2 ? -4 : 4) * u); for (let k = 8; k >= 0; k--) g.lineTo(x0 + k * 7.5 * u, mid + (k % 2 ? 2 : 10) * u); g.fill(); }
    if (pt === 6) { g.beginPath(); g.roundRect(cx - 12 * u, mid - 12 * u, 24 * u, 24 * u, 4 * u); g.fill(); }
    if (pt === 7) for (let k = 0; k < 4; k++) g.fillRect(x0 + (6 + k * 14) * u, torsoTop, 5 * u, 60 * u);
    g.restore();
    if (team) { g.strokeStyle = team; g.lineWidth = 3 * u; g.beginPath(); g.ellipse(cx, fy, 26 * u, 5 * u, 0, 0, TAU); g.stroke(); }
    // 머리 장식(뒤쪽 것 먼저)
    g.fillStyle = c2; g.strokeStyle = c2; g.lineWidth = 3 * u;
    if (lk.acc === 1) { g.beginPath(); g.moveTo(cx + 9 * u, headC - hr * 0.8); g.lineTo(cx + 12 * u, headC - hr - 22 * u); g.stroke(); g.beginPath(); g.arc(cx + 12 * u, headC - hr - 24 * u, 4 * u, 0, TAU); g.fill(); }
    if (lk.acc === 4) { g.beginPath(); g.roundRect(cx - 3 * u, headC - hr - 6 * u, 6 * u, 14 * u, 3 * u); g.fill(); }
    // 헬멧
    g.fillStyle = c1; g.beginPath(); g.ellipse(cx, headC, hr, hr * 1.06, 0, 0, TAU); g.fill();
    const hl = g.createRadialGradient(cx - hr * 0.4, headC - hr * 0.5, 0, cx, headC, hr * 1.1); hl.addColorStop(0, 'rgba(255,255,255,.45)'); hl.addColorStop(0.45, 'rgba(255,255,255,0)'); g.fillStyle = hl; g.beginPath(); g.ellipse(cx, headC, hr, hr * 1.06, 0, 0, TAU); g.fill();
    if (lk.acc === 2) for (const sg of [-1, 1]) { g.fillStyle = c2; g.beginPath(); g.moveTo(cx + sg * hr * 0.92, headC - 2 * u); g.lineTo(cx + sg * (hr + 9 * u), headC - 12 * u); g.lineTo(cx + sg * hr * 0.98, headC + 6 * u); g.fill(); }
    if (lk.acc === 3) { g.lineWidth = 3.5 * u; g.beginPath(); g.arc(cx, headC, hr + 2 * u, Math.PI * 1.05, Math.PI * 1.95); g.stroke(); for (const sg of [-1, 1]) { g.beginPath(); g.roundRect(cx + sg * (hr + 1 * u) - 4 * u, headC - 7 * u, 8 * u, 14 * u, 3 * u); g.fill(); } }
    // 바이저
    g.fillStyle = vc[0]; g.beginPath(); g.roundRect(cx - hr * 0.86, headC - hr * 0.32, hr * 1.72, hr * 0.62, hr * 0.31); g.fill();
    const vg = g.createLinearGradient(0, headC - hr * 0.32, 0, headC + hr * 0.3); vg.addColorStop(0, 'rgba(255,255,255,.35)'); vg.addColorStop(0.5, 'rgba(255,255,255,0)'); g.fillStyle = vg; g.fill();
    g.fillStyle = team || vc[1]; g.fillRect(cx - hr * 0.55, headC - hr * 0.02, hr * 0.62, 2 * u);
    g.restore();
  }
  function drawLook(cv, lk) {
    const g = cv.getContext('2d'), w = cv.width, h = cv.height;
    g.clearRect(0, 0, w, h);
    drawFig(g, w / 2, h - 18, Math.min(w, h) * 0.66, lk);
  }
  /* 홈 미리보기(640×360): 중계 세트 위 코스와 참가자 */
  function preview(cv) {
    const g = cv.getContext('2d'), w = cv.width, h = cv.height, R = prng(20261119);
    const sky = g.createLinearGradient(0, 0, 0, h); sky.addColorStop(0, '#070b1c'); sky.addColorStop(0.55, '#283a66'); sky.addColorStop(1, '#0e1a2e'); g.fillStyle = sky; g.fillRect(0, 0, w, h);
    // 관중석 · LED 띠 · 조명
    g.fillStyle = '#121a2a'; g.beginPath(); g.moveTo(0, h * 0.5); g.quadraticCurveTo(w / 2, h * 0.36, w, h * 0.5); g.lineTo(w, h * 0.6); g.lineTo(0, h * 0.6); g.fill();
    for (let i = 0; i < 240; i++) { const x = R() * w, y = h * 0.42 + R() * h * 0.13 + Math.abs(x - w / 2) / w * h * 0.12; g.fillStyle = ['#e63946', '#f1faee', '#a8dadc', '#f0b429', '#457b9d'][Math.floor(R() * 5)]; g.globalAlpha = 0.5; g.fillRect(x, y, 2, 3); }
    g.globalAlpha = 1;
    for (let i = 0; i < 40; i++) { g.fillStyle = i % 4 === 0 ? '#f0b429' : i % 4 === 2 ? '#ff4d2e' : '#24304e'; g.fillRect(i * w / 40 + 2, h * 0.585, w / 40 - 4, 8); }
    for (const x of [0.1, 0.35, 0.65, 0.9]) { const gr = g.createRadialGradient(w * x, h * 0.12, 0, w * x, h * 0.12, 30); gr.addColorStop(0, 'rgba(255,246,224,.95)'); gr.addColorStop(0.25, 'rgba(255,246,224,.45)'); gr.addColorStop(1, 'rgba(255,246,224,0)'); g.fillStyle = gr; g.fillRect(w * x - 30, h * 0.12 - 30, 60, 60); }
    // 물
    const wa = g.createLinearGradient(0, h * 0.6, 0, h); wa.addColorStop(0, '#11344a'); wa.addColorStop(1, '#0a1e2c'); g.fillStyle = wa; g.fillRect(0, h * 0.6, w, h * 0.4);
    // 코스(원근 사다리꼴)
    g.fillStyle = '#dfe3e8'; g.beginPath(); g.moveTo(w * 0.42, h * 0.56); g.lineTo(w * 0.58, h * 0.56); g.lineTo(w * 0.86, h); g.lineTo(w * 0.14, h); g.fill();
    g.fillStyle = '#9aa3b2'; g.fillRect(w * 0.14, h - 6, w * 0.72, 6);
    g.strokeStyle = 'rgba(255,255,255,.9)'; g.lineWidth = 3; g.beginPath(); g.moveTo(w * 0.435, h * 0.56); g.lineTo(w * 0.2, h); g.moveTo(w * 0.565, h * 0.56); g.lineTo(w * 0.8, h); g.stroke();
    g.strokeStyle = 'rgba(0,0,0,.08)'; g.lineWidth = 1; for (let k = 1; k < 8; k++) { const y = h * 0.56 + (h * 0.44) * (k / 8) ** 1.6; g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
    // 회전 바(위험 줄무늬)
    g.save(); g.translate(w * 0.5, h * 0.7); g.rotate(-0.18); g.fillStyle = '#ff4d2e'; g.fillRect(-w * 0.26, -6, w * 0.52, 12); g.fillStyle = '#0d0e12'; for (let k = -12; k < 12; k += 2) g.fillRect(k * 14, -6, 7, 12); g.restore();
    g.fillStyle = '#8f9bb0'; g.fillRect(w * 0.5 - 7, h * 0.7 - 30, 14, 34);
    // 참가자
    const figs = [[0.38, 0.62, 52], [0.6, 0.6, 46], [0.47, 0.57, 34], [0.3, 0.86, 92], [0.68, 0.94, 104]];
    for (const [x, y, s] of figs) drawFig(g, w * x, h * y, s, lookRand(R));
  }
  function lookSheet(ctx) {
    const h = L.h, lk = myLook(), body = h('div');
    const cv = h('canvas', { width: 240, height: 200, style: { width: '200px', height: '166px', display: 'block', margin: '0 auto 6px', borderRadius: '14px', background: 'radial-gradient(#3a3348,#17131f)' } });
    const rows = h('div');
    const sw = (key, i) => h('button', { 'aria-label': '색 ' + (i + 1), style: { width: '44px', height: '44px', borderRadius: '50%', border: '3px solid ' + (lk[key] === i ? '#fff' : 'rgba(255,255,255,.2)'), background: LOOK.cols[i], cursor: 'pointer', padding: 0, boxShadow: lk[key] === i ? '0 0 0 2px var(--brass)' : 'none' }, onclick() { lk[key] = i; save(); } });
    const chip = (key, i, txt) => h('button', { class: 'btn sm' + (lk[key] === i ? ' primary' : ''), style: { minHeight: '44px' }, text: txt, onclick() { lk[key] = i; save(); } });
    const draw = () => {
      rows.innerHTML = '';
      const sec = (t, kids) => rows.append(h('div', { class: 'muted', style: { fontSize: '12px', margin: '8px 0 4px' }, text: t }), h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '6px' } }, ...kids));
      sec('바탕 색', LOOK.cols.map((_, i) => sw('c1', i)));
      sec('무늬 색', LOOK.cols.map((_, i) => sw('c2', i)));
      sec('무늬', LOOK.pats.map((t, i) => chip('pat', i, t)));
      sec('머리 장식', LOOK.accs.map((t, i) => chip('acc', i, t)));
      sec('바이저', LOOK.eyes.map((t, i) => chip('eye', i, t)));
      rows.append(h('div', { style: { display: 'flex', gap: '8px', marginTop: '10px' } }, h('button', { class: 'btn', style: { minHeight: '44px' }, text: '무작위', onclick() { Object.assign(lk, lookRand(Math.random)); save(); } })));
      drawLook(cv, lk);
    };
    const save = () => { store.set('look', lookCode(lk)); draw(); };
    body.append(cv, rows);
    draw();
    ctx.sheet('커스터마이즈', body);
  }

  /* ======================= 그래픽 단계 · 불러오기 ======================= */
  const TIERS = [
    { id: 'low', nm: '낮음', tip: '폰 권장 — 그림자 없음 · 화면 배율 낮게', pr: 1, shadow: 0, aa: false },
    { id: 'mid', nm: '보통', tip: '부드러운 그림자(가까운 곳) · 계단 현상 줄임 · 보통 배율', pr: 1.5, shadow: 1024, aa: true },
    { id: 'high', nm: '높음', tip: 'PC 권장 — 부드러운 그림자 · 고운 화면', pr: 2, shadow: 2048, aa: true },
  ];
  function touchOnly() { try { if (L && L.touchOnly) return !!L.touchOnly(); return typeof matchMedia === 'function' && matchMedia('(pointer:coarse)').matches; } catch (e) { return false; } }   // 갤럭시(S펜)는 any-pointer:fine도 true — 코어 판정(주 포인터·실제 터치)을 따른다
  function gfxTier() { const v = store.get('gfx', ''); return TIERS.some((t) => t.id === v) ? v : (touchOnly() ? 'low' : 'mid'); }
  const scripts = {};
  function loadScript(src) {
    if (!scripts[src]) scripts[src] = new Promise((ok, no) => {
      const el = document.createElement('script'); el.src = src; el.async = true;
      el.onload = () => ok(); el.onerror = () => { delete scripts[src]; no(new Error('불러오기 실패: ' + src)); };
      document.head.appendChild(el);
    });
    return scripts[src];
  }
  function loadCore() { return (G.THREE ? Promise.resolve() : loadScript('assets/hyperrace/lib/three.min.js')).then(() => loadScript('assets/dropout/view.js')); }
  function webglOK() { try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) { return false; } }

  const API = { DT, GRAV, RUN, RAD, HGT, LOW, STEP, ST, TYPES, QTYPES, FTYPES, KIND_NM, TEAM_COL, TEAM_NM, LOOK, SEG_NM, TIERS, clamp, prng, shuffle,
    lookCode, lookParse, lookRand, myLook, store, gfxTier, touchOnly, genLevel, makeWorld, worldStep, poseAt, updMovers, act, topIf, near, slimeY, crownPos,
    stepChar, hitEvent, hostTick, roundEnd, aiInput, habits, setupRound, init, result, hint, endRound, afterRes, aliveOf, showPlan, packChar, packDyn, unpackDyn, isLive, IDLE, progressOf, tileAt, fx };

  function mount(root, api) {
    const h = L.h;
    let view = null, dead = false, last = null, lastPrev = null;
    const box = h('div', { style: { position: 'absolute', inset: '0', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '12px', background: 'radial-gradient(circle at 50% 40%,#3a2350,#140e1c)', color: 'var(--ink)', zIndex: 5, textAlign: 'center', padding: '16px' } });
    const t1 = h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '26px', letterSpacing: '1px' }, text: '낙오 장애물 쇼' });
    const t2 = h('div', { class: 'muted', style: { fontSize: '13px' }, text: '3D 엔진 불러오는 중…' });
    const bar = h('div', { style: { width: '220px', height: '6px', borderRadius: '3px', background: 'rgba(255,255,255,.12)', overflow: 'hidden' } }, h('div', { style: { width: '8%', height: '100%', background: 'var(--brass)', transition: 'width .2s' } }));
    box.append(t1, t2, bar);
    root.append(box);
    const prog = (f, txt) => { if (bar.firstChild) bar.firstChild.style.width = Math.round(clamp(f, 0.05, 1) * 100) + '%'; if (txt) t2.textContent = txt; };
    if (!webglOK()) prog(1, '이 기기(브라우저)에서는 3D 그래픽(WebGL)을 켤 수 없어요.');
    else loadCore().then(() => {
      if (dead) return;
      prog(0.5, '무대 준비 중…');
      view = G.DO_VIEW.mount(root, api, API, { progress: prog, ready() { box.remove(); } });
      if (last) view.update(last, lastPrev);
    }).catch((e) => { prog(1, '3D 파일을 불러오지 못했어요. (' + (e && e.message || e) + ')'); });
    return {
      update(s, p) { last = s; lastPrev = p; if (view) view.update(s, p); },
      destroy() { dead = true; if (view) view.destroy(); box.remove(); },
      pause() { if (view && view.pause) view.pause(); },
      resume() { if (view && view.resume) view.resume(); },
    };
  }

  const ICON = '<rect x="15" y="20" width="26" height="25" rx="8" fill="currentColor"/><rect x="18" y="26" width="20" height="7" rx="3.5" fill="#000" opacity=".55"/><path d="M16 15 L20 5 L25 12 L28 3 L31 12 L36 5 L40 15z" fill="currentColor"/><ellipse cx="21" cy="48" rx="5" ry="3" fill="currentColor"/><ellipse cx="35" cy="48" rx="5" ry="3" fill="currentColor"/><path d="M4 52h48" stroke="currentColor" stroke-width="2" stroke-dasharray="3 4" opacity=".6"/>';

  if (L) L.register({
    id: 'dropout', name: '낙오 장애물 쇼', tag: '3D 서바이벌 쇼', cat: '파티', icon: ICON, tint: '#16203a',
    blurb: '2~32명이 장애물 레이스 · 붕괴 플로어 · 스윕 바 · 라이징 타워 · 팀전(빅 볼 매치 · 코어 쟁탈전)을 거치며 라운드마다 탈락하고, 결승(헥스 폴 · 고지 점령 · 트로피 쟁탈)에서 최후의 1인을 가리는 3D 서바이벌 쇼. 조작은 이동 · 점프 · 다이브 · 잡기.',
    time: '6–14분', landscape: true, realtime: true, aiDelay: 0, mood: 'party', ambient: 'stadium', sidePanel: false,
    minPlayers: 2, maxPlayers: 32, defaultPlayers: 12,
    options: [
      { id: 'len', label: '쇼 길이', tip: '라운드 수. 보통 = 인원 기준(12명 3라운드 · 32명 5라운드), 짧게 = 1라운드 감소, 길게 = 1라운드 추가.', choices: [{ v: 'short', label: '짧게' }, { v: 'normal', label: '보통' }, { v: 'long', label: '길게' }], def: 'normal' },
      { id: 'modes', label: '경기 종류', multi: true, tip: '결승 전 라운드에 나올 수 있는 경기. 끈 경기는 제외.', choices: QTYPES.map((k) => ({ v: k, label: TYPES[k].nm, tip: TYPES[k].d })) },
      { id: 'fin', label: '결승', tip: '마지막 라운드. 무작위면 쇼마다 변경.', choices: [{ v: 'rnd', label: '무작위' }].concat(FTYPES.map((k) => ({ v: k, label: TYPES[k].nm, tip: TYPES[k].d }))), def: 'rnd' },
    ],
    setupExtra(opts, ctx) {
      const h = L.h, wrap = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center', margin: '6px 0' } });
      const draw = () => {
        wrap.innerHTML = '';
        wrap.append(h('button', { class: 'btn sm primary', style: { minHeight: '44px' }, text: '커스터마이즈', onclick() { lookSheet(ctx); } }));
        wrap.append(h('span', { class: 'muted', style: { fontSize: '13px', margin: '0 4px 0 8px' }, text: '그래픽 품질(이 기기)' }));
        for (const t of TIERS) wrap.append(h('button', { class: 'btn sm' + (gfxTier() === t.id ? ' primary' : ''), title: t.tip, style: { minHeight: '44px' }, text: t.nm, onclick() { store.set('gfx', t.id); draw(); } }));
      };
      draw();
      return wrap;
    },
    controls: CONTROLS,
    quick: ['레이스 · 서바이벌 · 팀전 · 결승 라운드를 거치며 매 라운드 일부 탈락, 최후의 1인 우승', '모바일: 왼쪽 끌기 이동 · 오른쪽 버튼 점프 · 다이브 · 잡기 / PC: WASD · Space · Shift · F', '낮은 회전 바는 점프, 높은 회전 바는 다이브로 통과', '낙하 시 레이스는 체크포인트에서 재개, 서바이벌 · 결승은 탈락'],
    rules: RULES,
    codex,
    preview,
    hint,
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result,
    mount,
    _t: API,
  });
  G.DROPOUT = API;
  if (typeof module === 'object' && module) module.exports = API;
})();
