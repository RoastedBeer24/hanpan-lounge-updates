/* 균열 원정대 (itemstack) — 1~4명 협동 3D 슈터. 시간이 갈수록 강해지는 적을 상대로 아이템을 쌓아 원정을 이어 가는 로그라이크.
   시스템만 참고(시간 비례 난이도 · 상자 · 전송기 충전 · 무제한 중첩 아이템 장르). 이름 · 아이템 · 적 · 글 · 화면은 모두 직접 만든 것.

   파일 구성 (결정 사항: docs/DECISIONS.md 「균열 원정대」)
   - 이 파일: 순수 로직(노드 시험 가능) — 자료(아이템 60 · 장비 10 · 생존자 5 · 적 12 · 보스 4 · 구역 5) · 지형 만들기(씨앗 → 결정적)
     · 세계 시뮬(이동 · 스킬 · 피해 · 효과 연쇄 · 적 행동 · 감독(출현) · 상호작용 · 전송기) · 봇(상황 점수 + 씨앗 버릇) · 진행 · 결과 · 규칙 · 도감 · 등록.
   - assets/itemstack/view.js: 3D 화면(three.js — 하이퍼 레이스의 assets/hyperrace/lib/three.min.js 공용) · 조작 · HUD · 소리 · 온라인.
   - assets/itemstack/pk_*.js: 애니메이션 모델(Quaternius, CC0) — tools/itemstack/build_models.py.
   온라인: 호스트가 적 · 투사체 · 피해 · 아이템을 모두 정함(hostSend 15Hz), 게스트는 자기 이동만 예측해 알림. 단계 · 인벤토리 저장은 api.setState. */
(function () {
  'use strict';
  const G = typeof window !== 'undefined' ? window : globalThis;
  const L = G.Lounge;

  /* ======================= 기본 ======================= */
  const DT = 1 / 60, GRAV = 24, TAU = Math.PI * 2, RW = 62, CELL = 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;
  const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const hyp = (x, z) => Math.sqrt(x * x + z * z);
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function shuffle(R, a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); const x = a[i]; a[i] = a[j]; a[j] = x; } return a; }
  const pick = (R, a) => a[Math.floor(R() * a.length)];

  /* ======================= 등급 · 아이템 ======================= */
  /* 글 문체: 짧은 개조식 명사형, 수치는 「첫 개(추가 1개당)」 — 느낌표 · 의성어 · 귀여운 말투 없음 (사용자 지시) */
  const RAR = {
    w: { nm: '일반', col: '#d8dde4', dim: '#5d6672' },
    g: { nm: '희귀', col: '#7fd36b', dim: '#2f5a29' },
    r: { nm: '전설', col: '#e5534b', dim: '#5e1f1c' },
    b: { nm: '보스', col: '#e8c547', dim: '#5a4a12' },
    l: { nm: '저주', col: '#6aa6ff', dim: '#1d3560' },
  };
  const RORDER = ['w', 'g', 'r', 'b', 'l'];
  // [키, 이름, 등급, 그림, 설명]
  const ITEM_SRC = [
    ['crit', '조준 보정기', 'w', 'scope', '치명타 확률 +10%(+10%). 치명타는 피해 2배.'],
    ['aspd', '과급 탄창', 'w', 'mag', '공격 속도 +15%(+15%).'],
    ['mspd', '경량 장화', 'w', 'boot', '이동 속도 +14%(+14%).'],
    ['regen', '재생 이끼', 'w', 'moss', '체력 재생 초당 +0.8(+0.8). 레벨에 비례해 증가.'],
    ['leech', '흡혈 침', 'w', 'fang', '적중 시 체력 2(+2) 회복. 효과 계수 비례.'],
    ['shield', '보호막 발생기', 'w', 'shield', '최대 체력 8%(+8%)의 보호막. 피격 없이 7초 지나면 재충전.'],
    ['armor', '복합 장갑판', 'w', 'plate', '방어 +15(+15). 받는 피해 ×100/(100+방어).'],
    ['medkit', '응급 키트', 'w', 'cross', '피격 2초 후 체력 20 + 최대 체력 5%(+5%) 회복.'],
    ['focus', '근거리 집속기', 'w', 'lens', '13m 안 적에게 주는 피해 +20%(+20%).'],
    ['sticky', '점착 폭약', 'w', 'bomb', '5%(+5%) 확률 폭약 부착. 1.5초 후 반경 3m, 적중 피해의 180%.'],
    ['bleed', '톱니 갈고리', 'w', 'hook', '10%(+10%) 확률 출혈. 3초간 기본 피해 240%, 중첩 가능.'],
    ['jumps', '보조 추진기', 'w', 'jet', '공중 점프 +1(+1).'],
    ['slowhit', '둔화 탄두', 'w', 'hour', '적중 시 적 이동 속도 -60%, 2초(+2초).'],
    ['oocspd', '기동 반응기', 'w', 'wing', '비전투 시 이동 속도 +30%(+30%). 공격 · 피격 후 1초간 전투 상태.'],
    ['bossdmg', '관통 탄심', 'w', 'spike', '보스 대상 피해 +20%(+20%).'],
    ['gas', '연소 촉매', 'w', 'flame', '처치 시 반경 12m(+4m) 화염. 기본 피해 150%(+75%) + 연소.'],
    ['bounty', '현상금 칩', 'w', 'chip', '처치 시 자금 +2(+2). 난이도 계수 비례.'],
    ['backup', '예비 탄창', 'w', 'clip', '보조 스킬 충전 +1(+1).'],
    ['block', '반사 섬유', 'w', 'fiber', '15%(+15%) 확률 피해 무효. 쌍곡선 중첩(최대 100% 미만).'],
    ['fungus', '정지 균사체', 'w', 'spore', '1초 정지 후 반경 3m(+1.5m) 아군 회복, 초당 최대 체력 4.5%(+2.25%).'],
    ['crowbar', '쇄파 망치', 'w', 'hammer', '체력 90% 이상인 적에게 주는 피해 +75%(+75%).'],
    ['topaz', '응고 수정', 'w', 'gem', '처치 시 일시 방벽 15(+15). 방벽은 초당 서서히 감소.'],
    ['opal', '완충 껍질', 'w', 'shell', '7초간 피격 없으면 방어 +100(+100). 피격 시 해제.'],
    ['mocha', '흥분 수액', 'w', 'vial', '공격 속도 +7.5%(+7.5%), 이동 속도 +7%(+7%).'],
    ['igni', '점화 증폭기', 'w', 'ember', '연소 피해 +100%(+100%), 연소 시간 +50%.'],
    ['chain', '전기 응축기', 'g', 'bolt', '25% 확률 전격 연쇄. 3(+2)명, 적중 피해의 80%, 사거리 20m.'],
    ['missile', '유도 미사일 포드', 'g', 'missile', '10%(+10%) 확률 유도 미사일. 적중 피해의 300%.'],
    ['wisp', '연쇄 기폭 장치', 'g', 'burst', '처치 시 0.5초 후 반경 12m(+2.4m) 폭발. 기본 피해 350%(+280%).'],
    ['critheal', '수확 낫', 'g', 'scythe', '치명타 확률 +5%. 치명타 시 체력 8(+4) 회복.'],
    ['fuel', '보조 연료 전지', 'g', 'cell', '장비 충전 +1(+1). 장비 재사용 대기 ×0.85(곱 중첩).'],
    ['pred', '사냥 본능', 'g', 'eye', '치명타 확률 +5%. 치명타 시 3초간 공격 속도 +12%, 최대 2(+2)중첩.'],
    ['chill', '한랭 탄두', 'g', 'flake', '6%(+6%) 확률 빙결 1.5초. 보스는 대신 둔화.'],
    ['fireband', '작열 고리', 'g', 'ringf', '기본 피해 400% 이상 한 방 적중 시 화염, 적중 피해의 300%(+300%) + 연소. 10초 재사용.'],
    ['iceband', '빙결 고리', 'g', 'ringi', '기본 피해 400% 이상 한 방 적중 시 냉기 폭발, 적중 피해의 250%(+250%) + 둔화 3초. 10초 재사용.'],
    ['infusion', '주입 심장', 'g', 'heart', '처치 시 최대 체력 +1, 이번 원정 동안 유지. 상한 100(+100).'],
    ['razor', '반격 가시선', 'g', 'wire', '피격 시 25m(+10m) 안 적 5(+2)명에게 기본 피해 160%. 0.5초 재사용.'],
    ['buckler', '이동 방패', 'g', 'buckler', '이동 중 방어 +30(+30).'],
    ['bando', '재장전 회로', 'g', 'circuit', '처치 시 18% 확률 모든 스킬 재사용 대기 초기화. 쌍곡선 중첩.'],
    ['berserk', '광분 견갑', 'g', 'pauldron', '4초 안 3명 처치 시 6초(+4초)간 공격 · 이동 속도 +50%.'],
    ['shuriken', '추적 칼날', 'g', 'star', '주무기 사용 시 추적 칼날 1(+1)개 발사. 기본 피해 400%. 칼날마다 1초 재충전.'],
    ['cloak', '잔상 장치', 'g', 'cloak', '체력 25% 미만 시 3초간 은신 · 이동 속도 +40%. 30초 재사용(쌍곡선 감소).'],
    ['clover', '행운의 나선', 'r', 'spiral', '확률 효과를 1(+1)회 더 굴려 유리한 결과 적용.'],
    ['dio', '소생 기억체', 'r', 'core', '사망 시 체력 전부로 소생. 1개 소모, 「소진된 기억체」로 바뀜.'],
    ['behemoth', '폭심 탄두', 'r', 'nuke', '모든 적중이 반경 4m(+2.5m) 폭발. 적중 피해의 60%.'],
    ['alien', '냉각 핵', 'r', 'cool', '스킬 재사용 대기 ×0.75(곱 중첩).'],
    ['frost', '서리 유물', 'r', 'frost', '처치 시 냉기 고리 +1(6초), 최대 5(+5)겹. 반경 6m + 겹당 1.5m, 초당 기본 피해 150%.'],
    ['dagger', '의식 단검', 'r', 'dagger', '처치 시 추적 단검 3개. 각 기본 피해 150%(+150%).'],
    ['tesla', '불안정 코일', 'r', 'coil', '10초 주기 켜짐 · 꺼짐. 켜짐 동안 0.5초마다 35m 안 3(+2)명에게 기본 피해 200%.'],
    ['rack', '재생 가속기', 'r', 'rack', '모든 회복량 +100%(+100%).'],
    ['aegis', '과잉 회복 장벽', 'r', 'aegis', '최대 체력을 넘친 회복의 50%(+50%)를 방벽으로 전환.'],
    ['critdmg', '치명 배율기', 'r', 'mult', '치명타 피해 +100%(+100%).'],
    ['drakegland', '비룡의 화염낭', 'b', 'flame2', '주무기 적중 시 15% 확률 화염구. 기본 피해 250%(+150%) + 연소.'],
    ['titancore', '거상의 탄약고', 'b', 'salvo', '10초마다 30m 안 적에게 미사일 4(+2)발. 각 기본 피해 300%.'],
    ['queenvenom', '여왕의 독샘', 'b', 'venom', '적중 시 10% 확률 독 5초. 초당 적 최대 체력 1%(+1%), 보스는 0.25%.'],
    ['lordheart', '군주의 심장', 'b', 'heart2', '최대 체력 +25%(+25%), 체력 재생 초당 +1.5(+1.5).'],
    ['glass', '유리 각인', 'l', 'glass', '기본 피해 ×2(×2). 최대 체력 ×0.5(×0.5).'],
    ['corpse', '잠식 이끼', 'l', 'rot', '모든 회복량 +100%(+100%). 체력 자연 재생 정지.'],
    ['purity', '정화 인장', 'l', 'seal', '스킬 재사용 대기 -2초(-1초). 확률 효과를 1(+1)회 불리하게 다시 굴림.'],
    ['crown', '금 간 왕관', 'l', 'crown', '적중 시 30% 확률 자금 +2(+1). 피격 시 피해 비율만큼 자금 손실.'],
    ['gesture', '익사자의 손짓', 'l', 'hand', '장비 재사용 대기 ×1/(1+0.5×개수). 장비가 준비되면 자동 사용.'],
  ];
  const ITEMS = ITEM_SRC.map(([k, nm, r, ic, d], i) => ({ i, k, nm, r, ic, d }));
  ITEMS.push({ i: ITEMS.length, k: 'diospent', nm: '소진된 기억체', r: 'x', ic: 'core', d: '효과 없음. 소생 기억체를 쓴 흔적.' });
  const IX = {}; ITEMS.forEach((it) => { IX[it.k] = it.i; });
  const NIT = ITEMS.length;
  const POOL = {}; for (const r of RORDER) POOL[r] = ITEMS.filter((it) => it.r === r).map((it) => it.i);

  /* ======================= 장비 ======================= */
  const EQUIP = [
    { k: 'stim', nm: '응급 주사기', ic: 'syringe', cd: 45, d: '최대 체력 50% 즉시 회복.' },
    { k: 'strike', nm: '궤도 포격 표지', ic: 'strike', cd: 60, d: '조준 지점에 1.5초 후 포격. 반경 8m, 기본 피해 2500%.' },
    { k: 'ward', nm: '위상 보호막', ic: 'ward', cd: 50, d: '3초간 받는 피해 무효.' },
    { k: 'barrage', nm: '일회용 발사관', ic: 'missile', cd: 45, d: '유도 미사일 12발. 각 기본 피해 300%.' },
    { k: 'capacitor', nm: '낙뢰 축전기', ic: 'bolt', cd: 20, d: '조준한 적에게 낙뢰. 기본 피해 3000%.' },
    { k: 'dash', nm: '추진 돌진기', ic: 'dash', cd: 30, d: '바라보는 방향 30m 돌진. 닿은 적 기본 피해 500%, 돌진 중 피해 무효.' },
    { k: 'cryo', nm: '동결 수류탄', ic: 'flake', cd: 40, d: '반경 14m 적 3초 빙결(보스는 둔화), 기본 피해 200%.' },
    { k: 'decoy', nm: '유인 홀로그램', ic: 'decoy', cd: 45, d: '8초간 적의 표적을 끄는 허상 설치.' },
    { k: 'warhorn', nm: '전투 경적', ic: 'horn', cd: 45, d: '아군 전원 8초간 공격 · 이동 속도 +70%.' },
    { k: 'ocular', nm: '표적 투시경', ic: 'scope', cd: 60, d: '8초간 치명타 확률 +100%.' },
  ];
  const EX = {}; EQUIP.forEach((e, i) => { e.i = i; EX[e.k] = i; });

  /* ======================= 생존자 ======================= */
  // 스킬: [이름, 재사용 대기(초), 충전, 설명]
  const SURV = [
    { k: 'scout', nm: '척후병', body: 'sv_swat', role: '연사 · 기동', col: '#9fb4c8', hp: 110, armor: 0, dmg: 12, spd: 7, wpn: 'pistol',
      tint: { Swat: '#3b4654', Swat_Black: '#15191f', Visor: '#5fd0ff' },
      d: '쌍권총 연사와 관통 사격, 구르기로 버티는 기본형. 사거리 길고 다루기 쉬움.',
      sk: [['연사', 0.2, 1, '쌍권총 속사. 발당 기본 피해 100%. 효과 계수 1.0.'], ['관통 사격', 3, 1, '적을 모두 꿰뚫는 탄. 기본 피해 300%.'], ['전술 구르기', 4, 1, '이동 방향으로 짧게 구름. 구르는 동안 피해 무효.'], ['제압 사격', 8, 1, '8발 연속 사격, 발당 기본 피해 120%. 맞은 적 0.4초 기절.']] },
    { k: 'gunner', nm: '포격수', body: 'sv_astro', role: '광역 · 폭발', col: '#e6a45a', hp: 130, armor: 15, dmg: 12, spd: 6.6, wpn: 'launcher',
      tint: { SciFi_Main: '#3e434b', SciFi_MainDark: '#1b1d22', SciFi_Light: '#6a6f78', SciFi_Light_Accent: '#ff9a4a' },
      d: '유탄과 충격탄, 분사 도약을 쓰는 광역 화력형. 느리지만 단단함.',
      sk: [['유탄', 0.8, 1, '착탄 폭발 반경 3.5m, 기본 피해 220%. 효과 계수 0.8.'], ['충격탄', 5, 1, '반경 5m 폭발, 기본 피해 400%, 1초 기절.'], ['분사 도약', 6, 1, '위 · 앞으로 도약. 착지 충격 반경 5m, 기본 피해 300%.'], ['일제 포격', 12, 1, '조준 지점에 로켓 10발. 발당 반경 3m, 기본 피해 250%.']] },
    { k: 'engi', nm: '정비공', body: 'sv_work', role: '설치 · 방어', col: '#e2c25a', hp: 120, armor: 5, dmg: 12, spd: 6.8, wpn: 'grenade',
      tint: { Worker_Yellow: '#d0a238', Worker_Vest: '#c9652a', Brown: '#3b3127', Brown2: '#2d2620' },
      d: '튕기는 수류탄 · 지뢰 · 방호 장막 · 자동 포탑. 포탑은 정비공의 아이템을 그대로 씀.',
      sk: [['튕김 수류탄', 0.65, 1, '수류탄 2발. 닿거나 1.2초 후 폭발 반경 3m, 기본 피해 160%.'], ['압력 지뢰', 6, 2, '0.6초 후 작동, 적 접근 시 반경 5m 기본 피해 300%.'], ['방호 장막', 18, 1, '반경 7m 장막 8초. 안의 아군 받는 피해 -50%, 들어오는 적 투사체 소멸.'], ['자동 포탑', 25, 2, '포탑 설치(최대 2기). 0.25초마다 기본 피해 70% 사격, 주인의 아이템 적용.']] },
    { k: 'tracker', nm: '추적자', body: 'sv_punk', role: '추적 · 기동', col: '#c46bd1', hp: 100, armor: 0, dmg: 12, spd: 7.4, wpn: 'rail',
      tint: { Red: '#7a3a8c', Red_Dark: '#3e2147', LightBlue: '#3a4a5c', White: '#cfd4da' },
      d: '조준 원뿔 안 적을 스스로 쫓는 화살, 튀는 칼날, 위상 도약. 이동하며 사격.',
      sk: [['추적 화살', 0.5, 1, '조준 방향 25° 안 적을 쫓는 화살. 기본 피해 150%.'], ['회전 칼날', 6, 1, '최대 6명을 튕겨 다니는 칼날. 기본 피해 280%.'], ['위상 도약', 7, 1, '14m 순간 이동. 직후 0.3초 피해 무효.'], ['화살비', 12, 1, '조준 지점 반경 7m에 6초간 화살비. 0.3초마다 기본 피해 90%.']] },
    { k: 'breaker', nm: '파쇄병', body: 'sv_hood', role: '근접 · 돌파', col: '#d65a4a', hp: 115, armor: 20, dmg: 13, spd: 7.2, wpn: 'blade',
      tint: { Purple: '#2b2f3a', White: '#8d939c', LightBlue: '#3a3f4a', Hair: '#1c1c1f' },
      d: '3연 베기 · 상승 베기 · 돌파 · 일섬 난무. 무적 시간이 긴 근접형.',
      sk: [['3연 베기', 0.45, 1, '앞쪽 120° 3.2m. 기본 피해 130% · 130% · 260%.'], ['상승 베기', 3, 1, '앞의 적을 베며 솟구침. 기본 피해 400%.'], ['돌파', 6, 1, '16m 돌진. 닿은 적 기본 피해 300%, 돌진 중 피해 무효.'], ['일섬 난무', 10, 1, '25m 안 적 최대 5명을 차례로 벰. 명당 기본 피해 200% × 3. 시전 중 피해 무효.']] },
  ];
  const SVX = {}; SURV.forEach((s, i) => { s.i = i; SVX[s.k] = i; });

  /* ======================= 적 · 보스 · 정예 ======================= */
  // at: 공격 방식 · rg 사거리 · wu 예고(초) · cd 재사용
  const ENEMY = [
    { k: 'crawler', nm: '갑각 포식체', mdl: 'm_spider', hp: 80, dmg: 9, spd: 7.5, cost: 10, lv: 1, r: 0.8, hgt: 0.9, len: 1.9, at: 'lunge', rg: 4, wu: 0.45, cd: 1.6, d: '무리 지어 빠르게 접근해 도약 물기. 예고 동작 후 직선 도약.' },
    { k: 'stalker', nm: '촉수 보행자', mdl: 'm_stalk', hp: 140, dmg: 12, spd: 5.5, cost: 12, lv: 1, r: 0.6, hgt: 1.8, at: 'melee', rg: 2.6, wu: 0.5, cd: 1.4, d: '기본 근접 개체. 팔을 들어 올린 뒤 내려침.' },
    { k: 'wasp', nm: '군체 날벌레', mdl: 'm_wasp', hp: 60, dmg: 9, spd: 9, cost: 12, lv: 1, fly: 4, r: 0.6, hgt: 0.8, len: 1.4, at: 'dive', rg: 14, wu: 0.6, cd: 2.4, d: '공중 체공 후 붉은 선을 따라 급강하.' },
    { k: 'skull', nm: '해골 망령', mdl: 'm_skull', hp: 110, dmg: 10, spd: 4, cost: 16, lv: 1, fly: 6, r: 0.8, hgt: 1.4, at: 'orb', rg: 32, wu: 0.5, cd: 2.6, d: '느린 추적 구체 발사. 구체는 사격으로 파괴 가능.' },
    { k: 'drone', nm: '감시 드론', mdl: 'm_drone', hp: 120, dmg: 14, spd: 5, cost: 20, lv: 1, fly: 7, r: 0.8, hgt: 1.2, at: 'laser', rg: 40, wu: 1.1, cd: 4, d: '조준선으로 1.1초 추적 후 고정 · 발사. 고정 직후 옆으로 피하면 회피.' },
    { k: 'walker', nm: '보행 포대', mdl: 'm_walker', hp: 180, dmg: 6, spd: 4, cost: 22, lv: 1, r: 0.8, hgt: 2.1, at: 'burst', rg: 35, wu: 0.6, cd: 3.5, d: '세 발 점사. 사거리가 길고 움직임이 느림.' },
    { k: 'bomber', nm: '자폭 탐사기', mdl: 'm_bomber', hp: 60, dmg: 45, spd: 9, cost: 14, lv: 2, r: 0.6, hgt: 1.1, at: 'fuse', rg: 3.2, wu: 0.9, cd: 99, d: '가까이 붙어 0.9초 뒤 자폭. 바닥 원 밖으로 벗어나면 회피.' },
    { k: 'horn', nm: '뿔 돌격체', mdl: 'm_horn', hp: 320, dmg: 26, spd: 5.5, cost: 32, lv: 2, r: 0.9, hgt: 2.1, at: 'charge', rg: 18, wu: 0.8, cd: 5, d: '돌진 경로를 띠로 예고한 뒤 직선 돌진.' },
    { k: 'tendril', nm: '지하 촉수', mdl: 'm_tendril', hp: 240, dmg: 22, spd: 8, cost: 24, lv: 2, r: 0.8, hgt: 3.2, at: 'burrow', rg: 3.5, wu: 0.9, cd: 1.6, d: '땅속으로 다가와 원으로 예고한 자리에서 솟구침. 땅속에서는 공격 불가.' },
    { k: 'drakeling', nm: '비늘 활공체', mdl: 'm_drake', hp: 220, dmg: 16, spd: 6, cost: 28, lv: 2, fly: 8, r: 1, hgt: 1.4, len: 2.4, at: 'spit', rg: 35, wu: 0.6, cd: 3, d: '포물선 화염탄. 떨어질 자리를 원으로 예고.' },
    { k: 'brute', nm: '늪 거인', mdl: 'm_brute', hp: 600, dmg: 32, spd: 4.2, cost: 45, lv: 3, r: 1.2, hgt: 3.4, at: 'slam', rg: 4.8, wu: 1.0, cd: 3, d: '앞쪽 원을 1초 예고한 뒤 내려찍기. 느리지만 체력이 높음.' },
    { k: 'heavy', nm: '중장갑 기계', mdl: 'm_heavy', hp: 1100, dmg: 18, spd: 3, cost: 80, lv: 5, r: 1.4, hgt: 3.3, at: 'mortar', rg: 45, wu: 1.4, cd: 4.5, d: '표적 주변 세 곳에 박격 포격. 원이 사라지기 전에 이탈.' },
  ];
  const BOSS = [
    { k: 'b_drake', nm: '심연 비룡', mdl: 'm_drake', hp: 3000, dmg: 22, spd: 6, fly: 12, r: 3, hgt: 4.2, len: 9, item: 'drakegland', tint: '#3a1f33', d: '공중에서 화염탄 부채꼴 · 화염 숨결(띠 예고) · 급강하(원 예고).' },
    { k: 'b_titan', nm: '붕괴 거상', mdl: 'm_titan', hp: 3600, dmg: 20, spd: 3, r: 2.8, hgt: 7, item: 'titancore', tint: '#4a3a2a', d: '연속 레이저 띠 · 플레이어 주변 미사일 낙하 · 발 구르기 고리.' },
    { k: 'b_queen', nm: '군락 여왕', mdl: 'm_spider', hp: 2800, dmg: 22, spd: 6.5, r: 2.6, hgt: 2.6, len: 6, item: 'queenvenom', tint: '#5a1418', d: '도약 내려찍기(큰 원) · 새끼 포식체 소환 · 독 구체.' },
    { k: 'b_lord', nm: '늪의 군주', mdl: 'm_brute', hp: 4000, dmg: 30, spd: 3.5, r: 2.6, hgt: 8, item: 'lordheart', tint: '#1f3a33', d: '퍼지는 충격 고리(점프로 회피) · 앞쪽 내려찍기 · 바위 투척.' },
  ];
  const ELITE = [
    { k: 'blaze', nm: '작열', col: '#ff7a2e', d: '체력 ×4, 피해 ×2. 적중 시 연소.' },
    { k: 'glacial', nm: '한랭', col: '#8fd8ff', d: '체력 ×4, 피해 ×2. 적중 시 둔화, 사망 시 냉기 폭발(원 예고).' },
    { k: 'volt', nm: '과전', col: '#c6a2ff', d: '체력 ×4, 피해 ×2. 공격 위치에 지연 낙뢰(원 예고).' },
  ];
  const EKX = {}; ENEMY.forEach((e, i) => { e.i = i; EKX[e.k] = i; });
  BOSS.forEach((b, i) => { b.i = 100 + i; b.boss = 1; });
  const etype = (ty) => (ty >= 100 ? BOSS[ty - 100] : ENEMY[ty]);

  /* ======================= 구역 ======================= */
  const THEMES = [
    { k: 'ash', nm: '잿빛 평원', sky: [0x1a1418, 0x7a4a36], fog: 0x5a3a30, fogD: 0.012, sun: 0xffc59a, sunDir: [0.6, 0.35, -0.5], rim: 0x9ab8ff, lo: 0x4a3c36, hi: 0x8a7258, cliff: 0x3a302c, flora: 'spike', glow: 0xff7a3a, planet: 0xd27a4a, enemies: ['crawler', 'stalker', 'wasp', 'walker', 'bomber', 'horn', 'brute', 'heavy'] },
    { k: 'marsh', nm: '청록 습지', sky: [0x08161a, 0x2c6a66], fog: 0x1c4a48, fogD: 0.016, sun: 0xbfffe8, sunDir: [-0.4, 0.5, -0.6], rim: 0xffb37a, lo: 0x1e3a34, hi: 0x3e6a52, cliff: 0x1a2a28, flora: 'bulb', glow: 0x4affd0, planet: 0x8ad0c0, enemies: ['crawler', 'stalker', 'skull', 'tendril', 'drakeling', 'brute', 'wasp', 'bomber'] },
    { k: 'crystal', nm: '결정 협곡', sky: [0x0e0a1c, 0x4a3a7a], fog: 0x2a2248, fogD: 0.013, sun: 0xd8c8ff, sunDir: [0.3, 0.6, 0.6], rim: 0x6affd8, lo: 0x2c2840, hi: 0x5a5478, cliff: 0x221e32, flora: 'shard', glow: 0xb48aff, planet: 0x9a8ae0, enemies: ['skull', 'drone', 'walker', 'horn', 'stalker', 'heavy', 'drakeling', 'crawler'] },
    { k: 'rust', nm: '녹슨 고원', sky: [0x1c0e0a, 0x8a4a2a], fog: 0x6a3a24, fogD: 0.011, sun: 0xffd8a8, sunDir: [-0.6, 0.3, 0.4], rim: 0x8ad8ff, lo: 0x4a2e22, hi: 0x8a5a3a, cliff: 0x3a221a, flora: 'wreck', glow: 0xffb04a, planet: 0xe0a06a, enemies: ['drone', 'walker', 'bomber', 'heavy', 'stalker', 'horn', 'crawler', 'tendril'] },
    { k: 'abyss', nm: '심연 해안', sky: [0x02040c, 0x14244a], fog: 0x0c1830, fogD: 0.017, sun: 0x9ab8ff, sunDir: [0.5, 0.45, 0.5], rim: 0xff8ad8, lo: 0x141c2c, hi: 0x2c3a52, cliff: 0x0e1420, flora: 'bulb', glow: 0x5a8aff, planet: 0x6a8ad8, enemies: ['skull', 'wasp', 'tendril', 'drakeling', 'brute', 'drone', 'heavy', 'stalker'] },
  ];
  /* 난이도 단계(시간 비례) — 9단계 */
  const TIERS = ['고요', '동요', '경계', '위험', '격화', '치명', '붕괴', '종말', '심연'];

  /* ======================= 지형 (씨앗 → 결정적) ======================= */
  const GN = 2 * RW + 1;   // 1m 격자
  function genStage(seed, theme, n) {
    const R = prng(seed), T = THEMES[theme];
    const isl = [], ramps = [], rocks = [];
    const nI = 6 + Math.floor(R() * 3);
    for (let i = 0; i < nI; i++) {
      let x, z, ok, g = 0;
      do { const a = R() * TAU, d = 14 + R() * (RW - 26); x = Math.cos(a) * d; z = Math.sin(a) * d; ok = isl.every((o) => hyp(o.x - x, o.z - z) > o.r + 8); } while (!ok && ++g < 30);
      const r = 7 + R() * 10, H = 2.6 + R() * (i < 2 ? 3 : 6.5);
      isl.push({ x, z, r, H, w: 1.4 + R() * 1.2, ph: R() * TAU, wob: 0.12 + R() * 0.12 });
    }
    // 경사로: 섬마다 바깥쪽으로 1~2개
    for (const o of isl) {
      const nR = o.H > 5 ? 2 : 1;
      for (let k = 0; k < nR; k++) {
        const a = Math.atan2(-o.z, -o.x) + (k ? Math.PI * (0.6 + R() * 0.8) : (R() - 0.5) * 1.2);
        const len = o.H / 0.42;
        const sx = o.x + Math.cos(a) * (o.r - 1.5), sz = o.z + Math.sin(a) * (o.r - 1.5);
        ramps.push({ x0: sx, z0: sz, x1: sx + Math.cos(a) * len, z1: sz + Math.sin(a) * len, H: o.H, w: 3.2 + R() * 1.2 });
      }
    }
    const base = (x, z) => 0.9 * Math.sin(x * 0.07 + seed % 7) * Math.cos(z * 0.06 + (seed % 11)) + 0.5 * Math.sin((x + z) * 0.13 + 1.3) + 0.25 * Math.sin(x * 0.31 - z * 0.27);
    const hAt = (x, z) => {
      let h = base(x, z);
      for (const o of isl) {
        const dx = x - o.x, dz = z - o.z, d = hyp(dx, dz);
        if (d > o.r * 1.3 + o.w + 2) continue;
        const a = Math.atan2(dz, dx), rr = o.r * (1 + o.wob * Math.sin(a * 3 + o.ph) + o.wob * 0.5 * Math.sin(a * 5 - o.ph));
        const v = o.H * sstep(rr + o.w, rr, d) + 0.25 * Math.sin(x * 0.5) * Math.sin(z * 0.45) * (d < rr ? 1 : 0);
        if (v > h) h = Math.max(h, v + base(x, z) * 0.3);
      }
      for (const p of ramps) {
        const vx = p.x1 - p.x0, vz = p.z1 - p.z0, L2 = vx * vx + vz * vz, t = clamp(((x - p.x0) * vx + (z - p.z0) * vz) / L2, 0, 1);
        const px = p.x0 + vx * t, pz = p.z0 + vz * t, d = hyp(x - px, z - pz);
        if (d > p.w) continue;
        const v = p.H * (1 - t) * sstep(p.w, p.w * 0.55, d) + base(x, z) * 0.2;
        if (v > h) h = v;
      }
      const dc = hyp(x, z);
      if (dc > RW - 6) h -= (dc - (RW - 6)) * 1.6;   // 가장자리 낭떠러지
      return h;
    };
    const hf = new Float32Array(GN * GN);
    for (let j = 0; j < GN; j++) for (let i = 0; i < GN; i++) hf[j * GN + i] = hAt(i - RW, j - RW);
    const S = { seed, theme, R, isl, ramps, rocks, hf, T, n: n || 1 };
    // 바위 기둥(엄폐) — 평지 · 섬 위
    const nRk = 16 + Math.floor(R() * 10);
    for (let i = 0; i < nRk; i++) {
      const a = R() * TAU, d = 6 + R() * (RW - 14), x = Math.cos(a) * d, z = Math.sin(a) * d;
      if (rocks.some((o) => hyp(o.x - x, o.z - z) < o.r + 4)) continue;
      rocks.push({ x, z, r: 0.8 + R() * 1.6, h: 2.5 + R() * 7, tilt: (R() - 0.5) * 0.3, rot: R() * TAU, y: hOf(S, x, z) });
    }
    // 식물 · 장식(화면 전용 — 충돌 없음)
    S.flora = [];
    for (let i = 0; i < 260; i++) { const a = R() * TAU, d = Math.sqrt(R()) * (RW - 4), x = Math.cos(a) * d, z = Math.sin(a) * d; S.flora.push([x, z, 0.5 + R() * 1.4, R() * TAU, R()]); }
    buildNav(S);
    placeObjects(S);
    return S;
  }
  function hOf(S, x, z) {
    const fx = clamp(x + RW, 0, GN - 1.001), fz = clamp(z + RW, 0, GN - 1.001), i = Math.floor(fx), j = Math.floor(fz), u = fx - i, v = fz - j, hf = S.hf, k = j * GN + i;
    return (hf[k] * (1 - u) + hf[k + 1] * u) * (1 - v) + (hf[k + GN] * (1 - u) + hf[k + GN + 1] * u) * v;
  }
  /* 길찾기 격자(2m): 걸을 수 있는 칸 + 오르막 한도 1.3m */
  const NN = Math.ceil(2 * RW / CELL);
  function buildNav(S) {
    const ok = new Uint8Array(NN * NN), hh = new Float32Array(NN * NN);
    for (let j = 0; j < NN; j++) for (let i = 0; i < NN; i++) {
      const x = -RW + (i + 0.5) * CELL, z = -RW + (j + 0.5) * CELL, k = j * NN + i;
      hh[k] = hOf(S, x, z);
      ok[k] = hyp(x, z) < RW - 7 && !S.rocks.some((o) => hyp(o.x - x, o.z - z) < o.r + 0.6) ? 1 : 0;
      if (ok[k]) { const s = Math.abs(hOf(S, x + 0.9, z) - hOf(S, x - 0.9, z)) + Math.abs(hOf(S, x, z + 0.9) - hOf(S, x, z - 0.9)); if (s > 2.4) ok[k] = 0; }
    }
    S.nav = { ok, hh };
  }
  const cellOf = (x, z) => { const i = clamp(Math.floor((x + RW) / CELL), 0, NN - 1), j = clamp(Math.floor((z + RW) / CELL), 0, NN - 1); return j * NN + i; };
  const cellX = (k) => -RW + ((k % NN) + 0.5) * CELL, cellZ = (k) => -RW + (Math.floor(k / NN) + 0.5) * CELL;
  const NB8 = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
  /* 목표까지 거리장(BFS) — 적 추적 · 봇 이동에 공통 */
  function flowField(S, x, z, out) {
    const { ok, hh } = S.nav, N = NN * NN, d = out || new Int16Array(N), q = new Int32Array(N);
    d.fill(-1);
    let k0 = cellOf(x, z);
    if (!ok[k0]) { let best = -1, bd = 1e9; for (let r = 1; r < 4 && best < 0; r++) for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) { const i = (k0 % NN) + di, j = Math.floor(k0 / NN) + dj; if (i < 0 || j < 0 || i >= NN || j >= NN) continue; const kk = j * NN + i; if (ok[kk] && di * di + dj * dj < bd) { bd = di * di + dj * dj; best = kk; } } if (best >= 0) k0 = best; }
    let qh = 0, qt = 0; d[k0] = 0; q[qt++] = k0;
    while (qh < qt) {
      const c = q[qh++], ci = c % NN, cj = (c - ci) / NN, dc = d[c];
      for (const [a, b] of NB8) {
        const i = ci + a, j = cj + b; if (i < 0 || j < 0 || i >= NN || j >= NN) continue;
        const n = j * NN + i; if (d[n] >= 0 || !ok[n]) continue;
        if (a && b && (!ok[cj * NN + i] || !ok[j * NN + ci])) continue;
        if (hh[c] - hh[n] > 1.3) continue;   // n에서 c로 오를 수 있어야 함
        d[n] = dc + (a && b ? 3 : 2); q[qt++] = n;
      }
    }
    return d;
  }
  function flowStep(S, d, x, z) {
    const c = cellOf(x, z), ci = c % NN, cj = (c - ci) / NN;
    let best = -1, bv = d[c] >= 0 ? d[c] : 1e9;
    for (const [a, b] of NB8) { const i = ci + a, j = cj + b; if (i < 0 || j < 0 || i >= NN || j >= NN) continue; const n = j * NN + i; if (d[n] >= 0 && d[n] < bv) { bv = d[n]; best = n; } }
    return best < 0 ? null : [cellX(best), cellZ(best)];
  }
  /* 상호작용 물건 배치 */
  const IA = {
    chest: { nm: '보급 상자', base: 25, d: '일반 79% · 희귀 20% · 전설 1%.' },
    big: { nm: '대형 보급 상자', base: 50, d: '희귀 80% · 전설 20%.' },
    vault: { nm: '봉인 금고', base: 400, d: '전설 아이템 확정.' },
    eqb: { nm: '장비 보관함', base: 25, d: '무작위 장비. 지닌 장비와 교체.' },
    chance: { nm: '확률 제단', base: 17, d: '45% 확률로 아이템. 사용할 때마다 비용 ×1.4, 성공 2회까지.' },
    combat: { nm: '전투 제단', base: 0, d: '무료. 정예 무리 소환, 모두 처치 시 자금 보상.' },
    printw: { nm: '복제기(일반)', base: 0, d: '지닌 일반 아이템 1개를 표시된 아이템으로 교환.' },
    printg: { nm: '복제기(희귀)', base: 0, d: '지닌 희귀 아이템 1개를 표시된 아이템으로 교환.' },
    lunar: { nm: '균열 포드', base: 1, d: '균열 파편 1개. 저주 아이템 1개.' },
  };
  const IAK = Object.keys(IA);
  function placeObjects(S) {
    const R = S.R, out = [];
    const spot = (minD, avoid) => {
      for (let g = 0; g < 80; g++) {
        const a = R() * TAU, d = Math.sqrt(R()) * (RW - 10), x = Math.cos(a) * d, z = Math.sin(a) * d, k = cellOf(x, z);
        if (!S.nav.ok[k]) continue;
        if (out.some((o) => hyp(o.x - x, o.z - z) < minD)) continue;
        if (avoid && hyp(avoid[0] - x, avoid[1] - z) < avoid[2]) continue;
        return [x, z];
      }
      return null;
    };
    const sp = spot(0) || [0, 0];
    S.spawn = { x: sp[0], z: sp[1] };
    const tp = spot(10, [sp[0], sp[1], 40]) || spot(10, [sp[0], sp[1], 24]) || spot(5) || [sp[0] + 20, sp[1]];
    S.tele = { x: tp[0], z: tp[1], y: hOf(S, tp[0], tp[1]) };
    const add = (k, n) => { for (let i = 0; i < n; i++) { const p = spot(4.5, [S.tele.x, S.tele.z, 6]); if (p) out.push({ k, x: p[0], z: p[1], y: hOf(S, p[0], p[1]), yaw: R() * TAU }); } };
    const pm = 0.75 + 0.25 * S.n;
    add('chest', Math.round((9 + Math.floor(R() * 3)) * pm)); add('big', 2 + (S.n >= 3 ? 1 : 0)); add('eqb', 1 + (R() < 0.5 ? 1 : 0)); add('chance', 1 + (R() < 0.5 ? 1 : 0)); add('combat', 1);
    add(R() < 0.6 ? 'printw' : 'printg', 1); if (R() < 0.6) add('lunar', 1); if (R() < 0.15) add('vault', 1);
    for (const o of out) if (o.k === 'printw' || o.k === 'printg') { const p = POOL[o.k === 'printw' ? 'w' : 'g']; o.item = p[Math.floor(R() * p.length)]; }
    S.ia = out;
  }

  /* ======================= 난이도 ======================= */
  const DIFF = { calm: 1, std: 2, harsh: 3 };
  /* 계수 = (인원 계수 + 분 × 0.0506 × 난이도 × 인원^0.2) × 1.15^(완료 구역 수) */
  function coeffOf(rt, si, n, dv) { const pf = 1 + 0.3 * (n - 1); return (pf + (rt / 60) * 0.0506 * dv * Math.pow(n, 0.2)) * Math.pow(1.15, si); }
  function enemyLv(c, n) { return Math.max(1, 1 + (c - (1 + 0.3 * (n - 1))) / 0.33); }
  /* 단계 막대: 표준 난이도 3.2분마다 한 단계 — 9단계 */
  function tierOf(rt, dv) { const x = (rt / 60) * dv / 2 / 3.2; const i = Math.min(TIERS.length - 1, Math.floor(x)); return { i, f: i >= TIERS.length - 1 ? 1 : x - i, nm: TIERS[i] }; }

  /* ======================= 확률 (행운) ======================= */
  function roll(p, ch) {
    if (ch <= 0) return false; if (ch >= 1) return true;
    const luck = (p.it[IX.clover] || 0) - (p.it[IX.purity] || 0);
    if (luck > 0) { for (let i = 0; i <= luck; i++) if (Math.random() < ch) return true; return false; }
    if (luck < 0) { for (let i = 0; i <= -luck; i++) if (Math.random() >= ch) return false; return true; }
    return Math.random() < ch;
  }

  /* ======================= 능력치 ======================= */
  function calcStats(p) {
    const it = p.it, sv = SURV[p.sv], lv = p.lv, n = (k) => it[IX[k]] || 0;
    const S = p.S || (p.S = {});
    S.dmg = sv.dmg * (1 + 0.2 * (lv - 1)) * Math.pow(2, n('glass'));
    S.mhp = (sv.hp * (1 + 0.3 * (lv - 1)) + (p.infHP || 0)) * (1 + 0.25 * n('lordheart')) * Math.pow(0.5, n('glass'));
    S.regen = n('corpse') ? 0 : (1 + 0.8 * n('regen')) * (1 + 0.2 * (lv - 1)) + 1.5 * n('lordheart');
    S.crit = 1 + 10 * n('crit') + 5 * (n('critheal') ? 1 : 0) + 5 * (n('pred') ? 1 : 0);
    S.critMul = 2 + n('critdmg');
    S.aspd = 1 + 0.15 * n('aspd') + 0.075 * n('mocha');
    S.mspd = 1 + 0.14 * n('mspd') + 0.07 * n('mocha');
    S.armor = SURV[p.sv].armor + 15 * n('armor');
    S.shMax = S.mhp * 0.08 * n('shield');
    S.jumps = 1 + n('jumps');
    S.cdMul = Math.pow(0.75, n('alien'));
    S.cdFlat = n('purity') ? 1 + n('purity') : 0;
    S.healMul = (1 + n('rack')) * (1 + n('corpse'));
    S.eqCdMul = Math.pow(0.85, n('fuel')) / (1 + 0.5 * n('gesture'));
    S.eqMax = 1 + n('fuel');
    S.secMax = 1 + n('backup');
    S.shurMax = n('shuriken');
    return S;
  }
  const skCd = (p, slot) => { const b = SURV[p.sv].sk[slot][1]; if (slot === 0) return b / dynAspd(p); return Math.max(0.5, b * p.S.cdMul - p.S.cdFlat); };
  const skMax = (p, slot) => SURV[p.sv].sk[slot][2] + (slot === 1 ? p.S.secMax - 1 : 0);
  function dynAspd(p) { const b = p.bf; let a = p.S.aspd + 0.12 * (p.pred ? p.pred.length : 0); if (b.bz > 0) a += 0.5; if (b.wh > 0) a += 0.7; return a; }
  function dynMspd(W, p) {
    const b = p.bf, it = p.it; let m = p.S.mspd;
    if (it[IX.oocspd] && W.t - p.combatT > 1) m += 0.3 * it[IX.oocspd];
    if (b.bz > 0) m += 0.5; if (b.wh > 0) m += 0.7; if (b.ck > 0) m += 0.4;
    if (p.slowT > W.t) m *= 0.5;
    return m;
  }
  function dynArmor(W, p) {
    let a = p.S.armor;
    if (p.it[IX.buckler] && hyp(p.vx, p.vz) > 1) a += 30 * p.it[IX.buckler];
    if (p.it[IX.opal] && W.t - p.hitT > 7) a += 100 * p.it[IX.opal];
    return a;
  }
  const itemStr = (it) => { let s = ''; for (let i = 0; i < NIT; i++) if (it[i]) s += i.toString(36).padStart(2, '0') + Math.min(1295, it[i]).toString(36).padStart(2, '0'); return s; };
  const itemArr = (s) => { const a = new Array(NIT).fill(0); s = String(s || ''); for (let k = 0; k + 3 < s.length; k += 4) { const i = parseInt(s.slice(k, k + 2), 36), c = parseInt(s.slice(k + 2, k + 4), 36); if (i >= 0 && i < NIT && c > 0) a[i] = c; } return a; };
  const itemCount = (it) => it.reduce((a, b) => a + b, 0) - (it[IX.diospent] || 0);

  /* ======================= 세계 ======================= */
  function newPlayer(W, s, c, sp) {
    const a = (s / Math.max(1, W.n)) * TAU;
    const p = { s, sv: c.sv, x: sp.x + Math.cos(a) * 2.5, z: sp.z + Math.sin(a) * 2.5, y: 0, vx: 0, vy: 0, vz: 0, yaw: a, pitch: 0, gr: 0, jl: 0,
      lv: c.lv || 1, xp: c.xp || 0, money: c.$ || 0, shards: c.sh || 0, it: itemArr(c.it), infHP: c.inf || 0, eq: c.eq == null ? -1 : c.eq,
      hp: 1, sh: 0, bar: 0, cd: [0, 0, 0, 0], ch: [1, 1, 1, 1], act: null, inv: 0, ward: 0, dead: 0, deadT: 0, bf: { bz: 0, wh: 0, oc: 0, ck: 0 },
      pred: [], combatT: -9, hitT: -9, stillT: 0, medQ: [], killT: [], shur: [], bandCd: 0, razorCd: 0, cloakCd: 0, slowT: 0, burnT: 0, frost: [], frostT: 0,
      ax: 0, ay: 0, az: 1, tx: 0, ty: 0, tz: 0, eqCd: 0, eqCh: 1, kills: c.k || 0, dd: c.dd || 0, dt: c.dt || 0, deaths: c.de || 0, picks: c.pk || 0,
      fireT: -9, shotN: 0, inE: null, inQ: null, teslaT: 0, titanT: 0, fungT: 0, combo: 0, comboT: 0, held: 0 };
    p.y = hOf(W.S, p.x, p.z) + 24 + s * 1.5;   // 하늘에서 낙하
    calcStats(p);
    p.hp = p.S.mhp; p.sh = p.S.shMax;
    p.ch = [1, skMax(p, 1), 1, skMax(p, 3)];
    p.eqCh = p.eq >= 0 ? p.S.eqMax : 0;
    return p;
  }
  function makeWorld(st, opt) {
    opt = opt || {};
    const S = genStage(st.ss, st.th, st.n);
    const W = { st, S, host: opt.host !== false, n: st.n, t: -2.5, rt0: st.rt || 0, si: st.si, dv: DIFF[st.diff] || 2, len: st.len,
      pl: [], en: [], pr: [], tg: [], tu: [], dc: [], domes: [], rains: [], bombs: [], fx: [], logs: [], nid: 1, flows: [],
      tp: { ph: 0, ch: 0, boss: [], bossK: -1, readyT: 0, by: -1 }, dir: { cred: 28, waveT: 4.5 }, combat: null, end: null };
    W.c0 = coeffOf(W.rt0, W.si, W.n, W.dv);
    W.ia = S.ia.map((o, i) => ({ i, k: o.k, x: o.x, y: o.y, z: o.z, yaw: o.yaw, item: o.item == null ? -1 : o.item, used: 0, uses: 0,
      cost: o.k === 'lunar' ? 1 : Math.round(IA[o.k].base * Math.pow(W.c0, 1.25)) }));
    W.pool = THEMES[st.th].enemies.map((k) => EKX[k]);
    const carry = st.carry || [];
    for (let s = 0; s < W.n; s++) W.pl.push(newPlayer(W, s, Object.assign({ sv: st.sv[s] >= 0 ? st.sv[s] : 0 }, carry[s] || {}), S.spawn));
    return W;
  }
  const rtOf = (W) => W.rt0 + Math.max(0, W.t);
  const coeff = (W) => coeffOf(rtOf(W), W.si, W.n, W.dv);
  const alivePl = (W) => W.pl.filter((p) => !p.dead);
  function fx(W, a) { if (W.fx.length < 500) W.fx.push(a); }
  function log(W, s, txt, col) { W.logs.push([s, txt, col || '', W.t]); if (W.logs.length > 40) W.logs.shift(); }

  /* ======================= 회복 · 피격 ======================= */
  function healP(W, p, amt) {
    if (p.dead || !(amt > 0)) return;
    amt *= p.S.healMul;
    const room = p.S.mhp - p.hp;
    if (amt > room) { const over = amt - Math.max(0, room); p.hp = p.S.mhp; if (p.it[IX.aegis]) p.bar = Math.min(p.S.mhp, p.bar + over * 0.5 * p.it[IX.aegis]); }
    else p.hp += amt;
  }
  function inDome(W, x, z) { for (const d of W.domes) if (hyp(d.x - x, d.z - z) < d.r) return true; return false; }
  function hurtP(W, p, amt, src) {
    if (p.dead || !(amt > 0) || p.inv > W.t || p.ward > W.t || W.t < 0) return 0;
    const it = p.it;
    if (it[IX.block] && Math.random() < 1 - 1 / (1 + 0.15 * it[IX.block])) { fx(W, ['blk', p.s, p.x, p.y + 1.2, p.z]); return 0; }
    let d = amt * 100 / (100 + Math.max(0, dynArmor(W, p)));
    if (inDome(W, p.x, p.z)) d *= 0.5;
    p.hitT = W.t; p.combatT = W.t; p.dt += d;
    if (it[IX.medkit]) p.medQ.push(W.t + 2);
    if (it[IX.crown] && p.money > 0) p.money = Math.max(0, p.money - Math.floor(p.money * Math.min(1, d / p.S.mhp)));
    let r = d;
    const b = Math.min(p.bar, r); p.bar -= b; r -= b;
    const sh = Math.min(p.sh, r); p.sh -= sh; r -= sh;
    p.hp -= r;
    fx(W, ['hurt', p.s, Math.round(d)]);
    if (it[IX.razor] && W.t > p.razorCd) {
      p.razorCd = W.t + 0.5; let k = 5 + 2 * (it[IX.razor] - 1); const rg = 25 + 10 * (it[IX.razor] - 1);
      for (const e of W.en) { if (k <= 0) break; if (e.dead || e.bur || hyp(e.x - p.x, e.z - p.z) > rg) continue; k--; fx(W, ['zap', p.x, p.y + 1, p.z, e.x, e.y + e.hgt * 0.5, e.z, 1]); dealDmg(W, p.s, e, p.S.dmg * 1.6, { pc: 0.5, crit: false, mask: M_RAZ }); }
    }
    if (it[IX.cloak] && p.hp > 0 && p.hp < p.S.mhp * 0.25 && W.t > p.cloakCd) { p.bf.ck = 3; p.cloakCd = W.t + 30 / (1 + 0.5 * (it[IX.cloak] - 1)); fx(W, ['cloak', p.s]); }
    if (src && src.el === 0) p.burnT = W.t + 3;
    if (src && src.el === 1) p.slowT = W.t + 2;
    if (p.hp <= 0) {
      if (it[IX.dio]) { it[IX.dio]--; it[IX.diospent] = (it[IX.diospent] || 0) + 1; calcStats(p); p.hp = p.S.mhp; p.inv = W.t + 3; fx(W, ['revive', p.s, p.x, p.y, p.z]); log(W, p.s, '소생 기억체 사용 · 체력 전부 회복', '#e5534b'); }
      else { p.hp = 0; p.dead = 1; p.deadT = W.t; p.deaths++; p.act = null; fx(W, ['die', p.s, p.x, p.y, p.z]); }
    }
    return d;
  }

  /* ======================= 피해 (아이템 효과 연쇄) ======================= */
  const M_CHAIN = 1, M_MISS = 2, M_BEH = 4, M_STICK = 8, M_BAND = 16, M_DRK = 32, M_RAZ = 64;
  function dealDmg(W, s, e, amt, o) {
    if (!e || e.dead || e.bur || !(amt > 0)) return 0;
    const p = W.pl[s]; if (!p) return 0;
    o = o || {};
    const it = p.it, S = p.S, pc = o.pc == null ? 1 : o.pc, mask = o.mask || 0;
    const crit = o.crit != null ? o.crit : roll(p, (S.crit + (p.bf.oc > 0 ? 100 : 0)) / 100);
    let d = amt;
    if (crit) d *= S.critMul;
    if (it[IX.focus] && hyp(e.x - p.x, e.z - p.z) < 13) d *= 1 + 0.2 * it[IX.focus];
    if (it[IX.crowbar] && e.hp >= e.mhp * 0.9) d *= 1 + 0.75 * it[IX.crowbar];
    if (it[IX.bossdmg] && e.boss) d *= 1 + 0.2 * it[IX.bossdmg];
    if (!isFinite(d)) d = 0;
    e.hp -= d; e.lastHit = s; e.hitT = W.t; p.dd += d;
    if (!o.dot) p.combatT = W.t;
    if (e.aggro == null || Math.random() < 0.12) e.aggro = s;
    fx(W, ['dmg', e.id, e.x, e.y + e.hgt, e.z, Math.round(d), crit ? 1 : 0, s, o.dot ? 1 : 0]);
    if (pc > 0) {
      const n = (k) => it[IX[k]] || 0;
      if (n('leech')) healP(W, p, 2 * n('leech') * pc);
      if (crit && n('critheal')) healP(W, p, 8 + 4 * (n('critheal') - 1));
      if (crit && n('pred')) { p.pred.push(W.t + 3); if (p.pred.length > 2 * n('pred')) p.pred.shift(); }
      if (n('slowhit')) { e.slowT = Math.max(e.slowT, W.t + 2 * n('slowhit')); e.slowK = 0.4; }
      if (n('bleed') && roll(p, 0.1 * n('bleed') * pc)) e.dots.push({ k: 'b', t: 3, dps: S.dmg * 0.8, s, tick: 0 });
      if (n('queenvenom') && roll(p, 0.1 * pc)) e.dots.push({ k: 'v', t: 5, dps: e.mhp * 0.01 * n('queenvenom') * (e.boss ? 0.25 : 1), s, tick: 0 });
      if (n('sticky') && !(mask & M_STICK) && roll(p, 0.05 * n('sticky') * pc)) W.bombs.push({ e: e.id, t: W.t + 1.5, dmg: d * 1.8, s, r: 3, mask: mask | M_STICK });
      if (n('chill') && roll(p, 0.06 * n('chill') * pc)) freezeE(W, e, 1.5);
      if (n('crown') && roll(p, 0.3 * pc)) p.money += 2 + (n('crown') - 1);
      if (n('chain') && !(mask & M_CHAIN) && roll(p, 0.25 * pc)) chainLight(W, s, e, 3 + 2 * (n('chain') - 1), d * 0.8, mask | M_CHAIN);
      if (n('missile') && !(mask & M_MISS) && roll(p, 0.1 * n('missile') * pc)) spawnMissile(W, s, p.x, p.y + 2, p.z, e.id, d * 3, mask | M_MISS);
      if (n('drakegland') && o.prim && !(mask & M_DRK) && roll(p, 0.15 * pc)) spawnPr(W, { k: 'fireball', own: 0, s, x: p.x, y: p.y + 1.6, z: p.z, hom: e.id, sp: 30, t: 3, dmg: S.dmg * (2.5 + 1.5 * (n('drakegland') - 1)), rad: 3, pc: 0.5, mask: mask | M_DRK, burn: 1 });
      if ((n('fireband') || n('iceband')) && !(mask & M_BAND) && d >= S.dmg * 4 && W.t > p.bandCd) {
        p.bandCd = W.t + 10;
        if (n('fireband')) { fx(W, ['boom', e.x, e.y + 1, e.z, 3, 'f']); explode(W, s, e.x, e.y, e.z, 3, d * 3 * n('fireband'), { pc: 0.5, mask: mask | M_BAND, crit: false, burn: 1 }); }
        if (n('iceband')) { fx(W, ['boom', e.x, e.y + 1, e.z, 3.5, 'i']); explode(W, s, e.x, e.y, e.z, 3.5, d * 2.5 * n('iceband'), { pc: 0.5, mask: mask | M_BAND, crit: false, slow: 3 }); }
      }
      if (n('behemoth') && !(mask & M_BEH)) { const r = 4 + 2.5 * (n('behemoth') - 1); fx(W, ['boom', e.x, e.y + e.hgt * 0.5, e.z, r, 'b']); explode(W, s, e.x, e.y, e.z, r, d * 0.6, { pc: 0.5, mask: mask | M_BEH, crit: false }); }
    }
    if (o.burn && !e.dead) burnE(W, p, e, S.dmg);
    if (o.slow) { e.slowT = Math.max(e.slowT, W.t + o.slow); e.slowK = 0.2; }
    if (o.stun && !e.boss) { e.stunT = Math.max(e.stunT, W.t + o.stun); }
    if (e.hp <= 0 && !e.dead) killE(W, e, s);
    return d;
  }
  function burnE(W, p, e, base) { const ig = p.it[IX.igni] || 0; e.dots.push({ k: 'f', t: 3 * (ig ? 1.5 : 1), dps: base * 0.5 * (1 + ig), s: p.s, tick: 0 }); }
  function freezeE(W, e, t) { if (e.boss) { e.slowT = Math.max(e.slowT, W.t + t * 2); e.slowK = 0.3; } else { e.frzT = Math.max(e.frzT, W.t + t); e.act = null; } }
  function explode(W, s, x, y, z, r, dmg, o) {
    o = o || {};
    for (const e of W.en) {
      if (e.dead || e.bur) continue;
      const dy = (e.y + e.hgt * 0.5) - y;
      if (hyp(e.x - x, e.z - z) - e.r > r || Math.abs(dy) > r + e.hgt * 0.5) continue;
      dealDmg(W, s, e, dmg, o);
    }
  }
  function chainLight(W, s, e0, k, dmg, mask) {
    const hit = new Set([e0.id]); let cur = e0;
    for (let i = 0; i < k; i++) {
      let best = null, bd = 20;
      for (const e of W.en) { if (e.dead || e.bur || hit.has(e.id)) continue; const d = hyp(e.x - cur.x, e.z - cur.z); if (d < bd) { bd = d; best = e; } }
      if (!best) break;
      hit.add(best.id);
      fx(W, ['zap', cur.x, cur.y + cur.hgt * 0.5, cur.z, best.x, best.y + best.hgt * 0.5, best.z, 0]);
      dealDmg(W, s, best, dmg, { pc: 0.2, mask, crit: false });
      cur = best;
    }
  }
  function killE(W, e, s) {
    e.dead = 1; e.deadT = W.t; e.hp = 0; e.act = null;
    const c = coeff(W), T = etype(e.ty), val = (e.boss ? 300 : T.cost) * (e.el >= 0 ? 4 : 1) * (e.minion ? 0.3 : 1);
    const money = Math.max(1, Math.round(val * 0.26 * c / (0.6 + 0.4 * W.n))), xp = val * 0.5 * Math.sqrt(c);
    for (const p of W.pl) if (!p.dead) { p.money += money; gainXP(W, p, xp); }
    fx(W, ['kill', e.id, e.x, e.y + e.hgt * 0.5, e.z, e.ty, e.boss ? 1 : 0, e.el]);
    const p = W.pl[s];
    if (p && !p.dead) {
      const n = (k) => p.it[IX[k]] || 0;
      p.kills++;
      if (n('gas')) { const r = 12 + 4 * (n('gas') - 1); fx(W, ['boom', e.x, e.y + 0.5, e.z, r, 'f']); explode(W, s, e.x, e.y, e.z, r, p.S.dmg * (1.5 + 0.75 * (n('gas') - 1)), { pc: 0, crit: false, burn: 1 }); }
      if (n('wisp')) W.bombs.push({ x: e.x, y: e.y + e.hgt * 0.5, z: e.z, t: W.t + 0.5, dmg: p.S.dmg * (3.5 + 2.8 * (n('wisp') - 1)), s, r: 12 + 2.4 * (n('wisp') - 1), mask: 0, wisp: 1 });
      if (n('bounty')) p.money += Math.round((2 + 2 * (n('bounty') - 1)) * c);
      if (n('infusion')) { const cap = 100 * n('infusion'); if (p.infHP < cap) { p.infHP++; const o = p.S.mhp; calcStats(p); p.hp += p.S.mhp - o; } }
      if (n('topaz')) p.bar = Math.min(p.S.mhp, p.bar + 15 * n('topaz'));
      if (n('bando') && Math.random() < 1 - 1 / (1 + 0.18 * n('bando'))) { for (let k = 1; k < 4; k++) { p.ch[k] = skMax(p, k); p.cd[k] = 0; } fx(W, ['reset', p.s]); }
      if (n('berserk')) { p.killT.push(W.t); p.killT = p.killT.filter((t) => W.t - t < 4); if (p.killT.length >= 3) { p.bf.bz = 6 + 4 * (n('berserk') - 1); p.killT.length = 0; } }
      if (n('dagger')) for (let k = 0; k < 3; k++) spawnPr(W, { k: 'dagger', own: 0, s, x: e.x, y: e.y + e.hgt + 0.5, z: e.z, vx: (Math.random() - 0.5) * 8, vy: 6, vz: (Math.random() - 0.5) * 8, sp: 28, t: 4, dmg: p.S.dmg * 1.5 * n('dagger'), pc: 0.5, seek: 1, delay: 0.3 });
      if (n('frost')) { p.frost.push(W.t + 6); if (p.frost.length > 5 * n('frost')) p.frost.shift(); }
      if (Math.random() < 0.01 * (e.el >= 0 ? 3 : 1)) { p.shards++; log(W, p.s, '균열 파편 +1', '#6aa6ff'); }
    }
    if (e.el === 1) addTg(W, { k: 'c', x: e.x, z: e.z, r: 6, t: 1.2, dmg: e.dmg * 0.8, own: -1, el: 1 });
    if (e.boss) { W.tp.bossK = e.ty; for (const q of W.pl) if (!q.dead) q.shards++; }
    if (W.combat && W.combat.ids.includes(e.id)) { W.combat.ids = W.combat.ids.filter((i) => i !== e.id); if (!W.combat.ids.length) { const rw = Math.round(40 * c); for (const q of W.pl) if (!q.dead) q.money += rw; log(W, -1, '전투 제단 정리 · 자금 +' + rw, '#e8c547'); W.combat = null; } }
  }
  const xpNeed = (lv) => Math.round(20 * Math.pow(1.55, lv - 1));
  function gainXP(W, p, x) {
    p.xp += x;
    let up = 0;
    while (p.xp >= xpNeed(p.lv) && p.lv < 99) { p.xp -= xpNeed(p.lv); p.lv++; up++; }
    if (up) { const o = p.S.mhp; calcStats(p); p.hp = Math.min(p.S.mhp, p.hp + (p.S.mhp - o) + p.S.mhp * 0.1); fx(W, ['lvup', p.s, p.lv]); }
  }

  /* ======================= 투사체 · 예고 ======================= */
  const PR_CAP = 260;
  function spawnPr(W, o) {
    if (W.pr.length >= PR_CAP) { const i = W.pr.findIndex((q) => q.own === 0 && q.k !== 'mine'); if (i < 0) return null; W.pr.splice(i, 1); }
    const q = Object.assign({ id: W.nid++, own: 0, s: 0, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, t: 3, dmg: 0, rad: 0, pc: 1, g: 0, hr: 0.4, mask: 0, hit: null }, o);
    if (q.sp && !q.vx && !q.vy && !q.vz) {
      let tx = q.tx, ty = q.ty, tz = q.tz;
      const tgt = q.hom != null ? (q.own ? W.pl[q.hom] : W.en.find((e) => e.id === q.hom)) : null;
      if (tgt) { tx = tgt.x; ty = tgt.y + (q.own ? 1.1 : tgt.hgt * 0.5); tz = tgt.z; }
      if (tx != null) { const dx = tx - q.x, dy = ty - q.y, dz = tz - q.z, l = Math.hypot(dx, dy, dz) || 1; q.vx = dx / l * q.sp; q.vy = dy / l * q.sp; q.vz = dz / l * q.sp; }
    }
    W.pr.push(q);
    return q;
  }
  function spawnMissile(W, s, x, y, z, eid, dmg, mask) {
    const a = Math.random() * TAU;
    return spawnPr(W, { k: 'missile', own: 0, s, x, y, z, vx: Math.cos(a) * 5, vy: 9, vz: Math.sin(a) * 5, sp: 30, seek: 1, hom: eid, t: 5, dmg, pc: 1, mask, delay: 0.25 });
  }
  function addTg(W, o) { const q = Object.assign({ id: W.nid++, k: 'c', x: 0, z: 0, r: 3, w: 2, t: 1, dmg: 0, own: -1, el: -1, hitS: 0 }, o); q.T = q.t; q.y = hOf(W.S, q.x, q.z); W.tg.push(q); return q; }
  const nearestEnemy = (W, x, z, maxD, filt) => { let b = null, bd = maxD; for (const e of W.en) { if (e.dead || e.bur || (filt && !filt(e))) continue; const d = hyp(e.x - x, e.z - z); if (d < bd) { bd = d; b = e; } } return b; };
  function enemyById(W, id) { for (const e of W.en) if (e.id === id) return e; return null; }
  function stepPr(W, dt) {
    const out = [];
    for (const q of W.pr) {
      q.t -= dt;
      if (q.delay > 0) { q.delay -= dt; q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt; q.vy -= 12 * dt; out.push(q); continue; }
      if (q.k === 'mine') { stepMine(W, q, dt); if (q.t > 0 && !q.gone) out.push(q); continue; }
      if (q.k === 'blade') { stepBlade(W, q, dt); if (q.t > 0 && !q.gone) out.push(q); continue; }
      // 유도
      if (q.seek || q.hom != null) {
        let tg = null;
        if (q.own) tg = W.pl[q.hom] && !W.pl[q.hom].dead ? W.pl[q.hom] : null;
        else { tg = q.hom != null ? enemyById(W, q.hom) : null; if ((!tg || tg.dead || tg.bur) && q.seek) { tg = nearestEnemy(W, q.x, q.z, 40); q.hom = tg ? tg.id : null; } }
        if (tg && !tg.dead) {
          const ty = tg.y + (q.own ? 1.0 : tg.hgt * 0.5), dx = tg.x - q.x, dy = ty - q.y, dz = tg.z - q.z, l = Math.hypot(dx, dy, dz) || 1;
          const sp = q.sp || Math.hypot(q.vx, q.vy, q.vz), k = Math.min(1, dt * (q.turn || 6));
          q.vx += (dx / l * sp - q.vx) * k; q.vy += (dy / l * sp - q.vy) * k; q.vz += (dz / l * sp - q.vz) * k;
        }
      }
      if (q.g) q.vy -= q.g * dt;
      const ox = q.x, oy = q.y, oz = q.z;
      q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt;
      const gy = hOf(W.S, q.x, q.z);
      let hitNow = false;
      if (q.own === 0) {
        for (const e of W.en) {
          if (e.dead || e.bur || (q.hitSet && q.hitSet.has(e.id))) continue;
          const cy = e.y + e.hgt * 0.5, rr = e.r + q.hr + (e.boss ? 0.6 : 0);
          if (segSphere(ox, oy, oz, q.x, q.y, q.z, e.x, cy, e.z, rr, e.hgt * 0.5)) { prHit(W, q, e); hitNow = true; break; }
        }
      } else {
        if (q.k !== 'spit' && q.k !== 'boulder' && q.k !== 'shell') {
          for (const p of W.pl) {
            if (p.dead) continue;
            if (segSphere(ox, oy, oz, q.x, q.y, q.z, p.x, p.y + 1, p.z, 0.75 + q.hr, 0.6)) { const src = enemyById(W, q.src); hurtP(W, p, q.dmg, src); fx(W, ['phit', q.x, q.y, q.z, q.k]); hitNow = true; break; }
          }
          if (!hitNow) for (const d of W.domes) if (hyp(d.x - q.x, d.z - q.z) < d.r) { hitNow = true; fx(W, ['pop', q.x, q.y, q.z]); break; }
          if (!hitNow) for (const t of W.tu) if (hyp(t.x - q.x, t.z - q.z) < 0.9 && Math.abs(q.y - t.y - 0.8) < 1) { t.hp -= q.dmg; hitNow = true; break; }
        }
      }
      if (!hitNow && q.y <= gy) {
        if (q.k === 'gren' && !q.bounced) { q.bounced = 1; q.y = gy + 0.05; q.vy = Math.abs(q.vy) * 0.45; q.vx *= 0.6; q.vz *= 0.6; }
        else { if (q.own === 0) prHit(W, q, null); else fx(W, ['phit', q.x, gy, q.z, q.k]); hitNow = true; }
      }
      if (!hitNow && hyp(q.x, q.z) > RW + 10) hitNow = true;
      if (!hitNow && q.t <= 0 && q.own === 0 && q.rad > 0) { prHit(W, q, null); hitNow = true; }
      if (!hitNow && q.t > 0) out.push(q);
    }
    W.pr = out;
  }
  function segSphere(ax, ay, az, bx, by, bz, cx, cy, cz, r, hh) {
    const dx = bx - ax, dy = by - ay, dz = bz - az, L2 = dx * dx + dy * dy + dz * dz || 1e-6;
    const t = clamp(((cx - ax) * dx + (cy - ay) * dy + (cz - az) * dz) / L2, 0, 1);
    const px = ax + dx * t - cx, pz = az + dz * t - cz, py = ay + dy * t - cy;
    const vy = Math.max(0, Math.abs(py) - (hh || 0));
    return px * px + pz * pz + vy * vy < r * r;
  }
  function prHit(W, q, e) {
    const o = { pc: q.pc, mask: q.mask, burn: q.burn, stun: q.stun, crit: q.crit };
    if (q.rad > 0) { fx(W, ['boom', q.x, q.y, q.z, q.rad, q.k === 'fireball' ? 'f' : 'e']); explode(W, q.s, q.x, q.y, q.z, q.rad, q.dmg, o); }
    else if (e) { fx(W, ['phit', q.x, q.y, q.z, q.k]); dealDmg(W, q.s, e, q.dmg, o); }
    else fx(W, ['phit', q.x, q.y, q.z, q.k]);
  }
  function stepMine(W, q, dt) {
    q.arm = (q.arm || 0) + dt;
    if (q.arm < 0.6) return;
    const e = nearestEnemy(W, q.x, q.z, 3.2, (e) => Math.abs(e.y - q.y) < 4 || e.fly);
    if (e) { prHit(W, Object.assign({}, q, { rad: 5 }), null); q.gone = 1; }
  }
  function stepBlade(W, q, dt) {
    let e = enemyById(W, q.hom);
    if (!e || e.dead || e.bur) { e = nearestEnemy(W, q.x, q.z, 20, (x) => !q.hitSet.has(x.id)); if (!e) { q.gone = 1; return; } q.hom = e.id; }
    const ty = e.y + e.hgt * 0.5, dx = e.x - q.x, dy = ty - q.y, dz = e.z - q.z, l = Math.hypot(dx, dy, dz) || 1, st = 55 * dt;
    if (l <= st + e.r) {
      q.x = e.x; q.y = ty; q.z = e.z; q.hitSet.add(e.id); q.n--;
      dealDmg(W, q.s, e, q.dmg, { pc: 0.8 });
      fx(W, ['phit', q.x, q.y, q.z, 'blade']);
      if (q.n <= 0) { q.gone = 1; return; }
      const nx = nearestEnemy(W, q.x, q.z, 20, (x) => !q.hitSet.has(x.id));
      if (!nx) { q.gone = 1; return; }
      q.hom = nx.id;
    } else { q.vx = dx / l * 55; q.vy = dy / l * 55; q.vz = dz / l * 55; q.x += q.vx * dt; q.y += q.vy * dt; q.z += q.vz * dt; }
  }
  function stepTg(W, dt) {
    const out = [];
    for (const g of W.tg) {
      if (g.k === 'ring') {
        g.t -= dt;
        if (g.t <= 0) {
          g.rr = (g.rr || 0) + 11 * dt;
          for (const p of W.pl) {
            if (p.dead || (g.hitS & (1 << p.s))) continue;
            const d = hyp(p.x - g.x, p.z - g.z), air = p.y - hOf(W.S, p.x, p.z) > 0.7;
            if (Math.abs(d - g.rr) < 1.0 && !air) { g.hitS |= 1 << p.s; hurtP(W, p, g.dmg, enemyById(W, g.own)); }
          }
          if (g.rr > g.r) continue;
        }
        out.push(g); continue;
      }
      if (g.trk != null) {   // 추적 조준선(레이저): 고정 전까지 대상 따라감
        const e = enemyById(W, g.own), p = W.pl[g.trk];
        if (!e || e.dead || e.frzT > W.t || e.stunT > W.t) continue;
        g.x = e.x; g.z = e.z; g.y0 = e.y + e.hgt * 0.5;
        if (g.t > 0.3 && p && !p.dead) { const dx = p.x - e.x, dz = p.z - e.z, l = hyp(dx, dz) || 1; g.x2 = e.x + dx / l * g.len; g.z2 = e.z + dz / l * g.len; }
      }
      g.t -= dt;
      if (g.t > 0) { out.push(g); continue; }
      if (g.own >= 0) { const e = enemyById(W, g.own); if (g.needAlive && (!e || e.dead || e.frzT > W.t || e.stunT > W.t)) continue; }
      fx(W, ['tgx', g.k, g.x, g.z, g.x2 || 0, g.z2 || 0, g.r, g.w, g.el, g.fx || '']);
      if (g.dmg > 0) {
        const src = g.own >= 0 ? enemyById(W, g.own) : (g.el >= 0 ? { el: g.el } : null);
        for (const p of W.pl) {
          if (p.dead) continue;
          let inside = false;
          if (g.k === 'c') inside = hyp(p.x - g.x, p.z - g.z) < g.r + 0.3 && p.y - hOf(W.S, p.x, p.z) < g.r;
          else if (g.k === 'l') inside = segDist(p.x, p.z, g.x, g.z, g.x2, g.z2) < g.w / 2 + 0.35 && p.y - hOf(W.S, p.x, p.z) < 4;
          if (inside) hurtP(W, p, g.dmg, src);
        }
        if (g.k === 'c') for (const t of W.tu) if (hyp(t.x - g.x, t.z - g.z) < g.r) t.hp -= g.dmg;
      }
      if (g.then) g.then(W, g);
    }
    W.tg = out;
  }
  function segDist(px, pz, ax, az, bx, bz) { const dx = bx - ax, dz = bz - az, L2 = dx * dx + dz * dz || 1e-6, t = clamp(((px - ax) * dx + (pz - az) * dz) / L2, 0, 1); return hyp(ax + dx * t - px, az + dz * t - pz); }

  /* ======================= 이동 (지형 · 바위 · 경계) ======================= */
  function rockPush(W, b, r) {
    for (const o of W.S.rocks) {
      const dx = b.x - o.x, dz = b.z - o.z, d = hyp(dx, dz), m = o.r + r;
      if (d < m && b.y < o.y + o.h) { const k = (m - d) / (d || 1); b.x += dx * k; b.z += dz * k; }
    }
    const dc = hyp(b.x, b.z), lim = RW - 4;
    if (dc > lim) { b.x *= lim / dc; b.z *= lim / dc; }
  }
  /* 지상 이동: 오르막 기울기 0.9 넘으면 막힘(벽), 공중에선 발밑보다 높은 칸으로 못 들어감 */
  function moveBody(W, b, dx, dz, r) {
    const S = W.S;
    const tryMove = (mx, mz) => {
      const nx = b.x + mx, nz = b.z + mz, gy = hOf(S, nx, nz), d = hyp(mx, mz);
      if (b.gr) { if (gy - b.y > Math.max(0.25, 0.9 * d)) return false; }
      else if (gy > b.y + 0.05) return false;
      b.x = nx; b.z = nz; return true;
    };
    if (!tryMove(dx, dz)) { if (!tryMove(dx, 0)) tryMove(0, dz); }
    rockPush(W, b, r);
  }
  function groundStep(W, b, dt) {
    const gy = hOf(W.S, b.x, b.z);
    if (b.gr) {
      if (gy < b.y - 0.55) { b.gr = 0; b.vy = 0; }
      else { b.y = gy; b.vy = 0; return false; }
    }
    b.vy -= GRAV * dt; b.y += b.vy * dt;
    if (b.y <= gy) { const v = b.vy; b.y = gy; b.vy = 0; b.gr = 1; return v < -2 ? v : true; }
    return false;
  }

  /* ======================= 적 ======================= */
  const MAXE = 48;   // 동시에 살아 있는 적 상한(감독이 넘기지 않음)
  function spawnEnemy(W, ty, x, z, o) {
    o = o || {};
    const T = etype(ty), c = coeff(W), lvl = enemyLv(c, W.n), el = o.el == null ? -1 : o.el;
    const hpM = (1 + 0.3 * (lvl - 1)) * (el >= 0 ? 4 : 1) * (T.boss ? 1 + 0.35 * (W.n - 1) : 1);
    const gy = hOf(W.S, x, z);
    const e = { id: W.nid++, ty, x, z, y: gy + (T.fly || 0), vx: 0, vy: 0, vz: 0, yaw: Math.random() * TAU, hp: T.hp * hpM, mhp: T.hp * hpM, lvl, el, boss: T.boss ? 1 : 0,
      dmg: T.dmg * (1 + 0.2 * (lvl - 1)) * (el >= 0 ? 2 : 1), spd: T.spd * (T.boss ? 1 : 0.9 + Math.random() * 0.2), r: T.r, hgt: T.hgt, fly: T.fly || 0, gr: 1,
      act: null, cd: 1 + Math.random() * 1.5, tgt: -1, tgtT: 0, aggro: null, slowT: 0, slowK: 1, stunT: 0, frzT: 0, dots: [], dead: 0, deadT: 0, hitT: -9,
      bur: T.at === 'burrow' ? 1 : 0, emT: 0, stuckT: 0, lx: x, lz: z, minion: o.minion ? 1 : 0, pat: 0, spawnT: W.t };
    if (e.fly) e.y = gy + e.fly + 4;
    W.en.push(e);
    fx(W, ['spawn', e.id, x, e.y, z, ty, el]);
    return e;
  }
  /* 표적: 살아 있는 플레이어 · 포탑 · 허상 — 허상이 있으면 우선 */
  function pickTarget(W, e) {
    let best = null, bv = 1e9;
    for (const d of W.dc) { const v = hyp(d.x - e.x, d.z - e.z) - 40; if (v < bv) { bv = v; best = { x: d.x, y: d.y, z: d.z, k: 'dc', ref: d }; } }
    for (const p of W.pl) {
      if (p.dead) continue;
      let v = hyp(p.x - e.x, p.z - e.z) + (p.bf.ck > 0 ? 60 : 0);
      if (e.aggro === p.s) v -= 8;
      if (v < bv) { bv = v; best = { x: p.x, y: p.y, z: p.z, k: 'p', ref: p }; }
    }
    for (const t of W.tu) { const v = hyp(t.x - e.x, t.z - e.z) + 4; if (v < bv) { bv = v; best = { x: t.x, y: t.y, z: t.z, k: 'tu', ref: t }; } }
    return best;
  }
  function hurtTarget(W, tg, dmg, e) {
    if (!tg) return;
    if (tg.k === 'p') hurtP(W, tg.ref, dmg, e);
    else if (tg.k === 'tu') tg.ref.hp -= dmg * 0.8;
  }
  function meleeHit(W, e, range, arc, dmg) {
    const fx_ = Math.sin(e.yaw), fz = Math.cos(e.yaw);
    for (const p of W.pl) {
      if (p.dead) continue;
      const dx = p.x - e.x, dz = p.z - e.z, d = hyp(dx, dz);
      if (d > range + e.r + 0.4 || Math.abs(p.y - e.y) > 3 + e.hgt * 0.3) continue;
      if ((dx * fx_ + dz * fz) / (d || 1) < Math.cos(arc / 2)) continue;
      hurtP(W, p, dmg, e);
    }
    for (const t of W.tu) if (hyp(t.x - e.x, t.z - e.z) < range + e.r + 0.4) t.hp -= dmg * 0.8;
  }
  function voltMark(W, e, x, z) { if (e.el === 2) addTg(W, { k: 'c', x, z, r: 2.5, t: 1.0, dmg: e.dmg * 0.5, own: -1, el: 2, fx: 'volt' }); }
  function faceTo(e, x, z, k) { let d = Math.atan2(x - e.x, z - e.z) - e.yaw; d = Math.atan2(Math.sin(d), Math.cos(d)); e.yaw += clamp(d, -k, k); }
  function flowFor(W, s) {
    let f = W.flows[s];
    if (!f) f = W.flows[s] = { d: new Int16Array(NN * NN), t: -9 };
    const p = W.pl[s];
    if (W.t - f.t > 0.7 && p) { flowField(W.S, p.x, p.z, f.d); f.t = W.t; }
    return f.d;
  }
  function stepEnemy(W, e, dt) {
    const T = etype(e.ty);
    if (e.dead) return;
    // 지속 피해
    for (const d of e.dots) {
      d.t -= dt; d.tick -= dt;
      if (d.tick <= 0) { d.tick += 0.25; dealDmg(W, d.s, e, d.dps * 0.25, { pc: 0, crit: false, dot: 1 }); if (e.dead) return; }
    }
    if (e.dots.length) e.dots = e.dots.filter((d) => d.t > 0);
    if (e.frzT > W.t || e.stunT > W.t) { if (e.act && e.act.k !== 'dive' && e.act.k !== 'leap') e.act = null; if (!e.fly) groundStepE(W, e, dt); return; }
    // 표적
    e.tgtT -= dt;
    if (e.tgtT <= 0 || !e.tg || (e.tg.k === 'p' && e.tg.ref.dead) || (e.tg.k === 'tu' && e.tg.ref.hp <= 0) || (e.tg.k === 'dc' && e.tg.ref.t <= 0)) { e.tg = pickTarget(W, e); e.tgtT = 0.6 + Math.random() * 0.4; }
    const tg = e.tg;
    if (tg) { tg.x = tg.ref.x; tg.y = tg.ref.y; tg.z = tg.ref.z; }
    const slow = e.slowT > W.t ? e.slowK : 1;
    if (e.boss) { stepBoss(W, e, dt, tg, slow); return; }
    if (e.act) { runAct(W, e, dt, tg, slow); if (!e.fly && e.act && !e.act.air) groundStepE(W, e, dt); else if (!e.fly && !e.act) groundStepE(W, e, dt); return; }
    if (!tg) { if (!e.fly) groundStepE(W, e, dt); return; }
    const dx = tg.x - e.x, dz = tg.z - e.z, d = hyp(dx, dz);
    e.cd -= dt;
    // 땅속(지하 촉수)
    if (e.bur) {
      if (d < 2.2) { e.act = { k: 'emerge', t: T.wu }; addTg(W, { k: 'c', x: e.x, z: e.z, r: 2.6, t: T.wu, dmg: e.dmg, own: e.id }); return; }
      moveToward(W, e, tg, d, T.spd * 1.0 * slow, dt, true);
      return;
    }
    if (e.cd <= 0 && d < T.rg + (T.at === 'melee' || T.at === 'lunge' ? e.r : 0) && Math.abs(tg.y - e.y) < (e.fly ? 30 : 6)) { startAttack(W, e, T, tg); return; }
    // 이동: 원거리는 사거리 안 적당한 거리에서 멈춤
    const keep = T.at === 'orb' || T.at === 'laser' || T.at === 'burst' || T.at === 'spit' || T.at === 'mortar' ? T.rg * 0.6 : 0;
    if (d > keep) moveToward(W, e, tg, d, T.spd * slow * (e.spd / T.spd), dt, false);
    else { faceTo(e, tg.x, tg.z, 6 * dt); if (!e.fly) groundStepE(W, e, dt); else hover(W, e, dt, e.x, e.z); }
  }
  function hover(W, e, dt, x, z) { const gy = hOf(W.S, x, z), ty = gy + e.fly + Math.sin(W.t * 1.3 + e.id) * 0.4; e.y += (ty - e.y) * Math.min(1, dt * 2); }
  function moveToward(W, e, tg, d, sp, dt, under) {
    let gx = tg.x, gz = tg.z;
    if (!e.fly && tg.k === 'p' && d > 6) { const st = flowStep(W.S, flowFor(W, tg.ref.s), e.x, e.z); if (st) { gx = st[0]; gz = st[1]; } }
    const dx = gx - e.x, dz = gz - e.z, l = hyp(dx, dz) || 1;
    faceTo(e, gx, gz, 8 * dt);
    const vx = dx / l * sp, vz = dz / l * sp;
    if (e.fly) {
      e.x += vx * dt; e.z += vz * dt; rockPush(W, e, e.r * 0.5);
      hover(W, e, dt, e.x, e.z);
    } else if (under) { e.x += vx * dt; e.z += vz * dt; e.y = hOf(W.S, e.x, e.z) - 0.6; }
    else {
      const ox = e.x, oz = e.z;
      moveBody(W, e, vx * dt, vz * dt, e.r * 0.8);
      groundStepE(W, e, dt);
      // 막히면 도약
      if (hyp(e.x - ox, e.z - oz) < sp * dt * 0.25) { e.stuckT += dt; if (e.stuckT > 1.4 && e.gr) { e.vy = 11; e.gr = 0; e.jx = dx / l * 5; e.jz = dz / l * 5; e.stuckT = 0; } } else e.stuckT = 0;
    }
  }
  function groundStepE(W, e, dt) {
    if (e.fly) return;
    if (!e.gr && e.jx) { e.x += e.jx * dt; e.z += e.jz * dt; rockPush(W, e, e.r * 0.8); }
    const l = groundStep(W, e, dt);
    if (l) e.jx = e.jz = 0;
  }
  function startAttack(W, e, T, tg) {
    const at = T.at;
    e.cd = T.cd * (0.85 + Math.random() * 0.3);
    faceTo(e, tg.x, tg.z, 9);
    const dx = tg.x - e.x, dz = tg.z - e.z, l = hyp(dx, dz) || 1, ux = dx / l, uz = dz / l;
    if (at === 'lunge') e.act = { k: 'wu', t: T.wu, next: 'lunge', ux, uz };
    else if (at === 'melee') e.act = { k: 'wu', t: T.wu, next: 'melee' };
    else if (at === 'dive') { const tx = tg.x, tz = tg.z; e.act = { k: 'wu', t: T.wu, next: 'dive', tx, tz, ty: tg.y + 1 }; addTg(W, { k: 'l', x: e.x, z: e.z, x2: tx + ux * 3, z2: tz + uz * 3, w: 1.6, t: T.wu, dmg: 0, own: e.id, warn: 1 }); }
    else if (at === 'orb') e.act = { k: 'wu', t: T.wu, next: 'orb' };
    else if (at === 'laser') { const tgp = tg.k === 'p' ? tg.ref.s : -1; const g = addTg(W, { k: 'l', x: e.x, z: e.z, x2: tg.x, z2: tg.z, w: 1.4, t: T.wu, dmg: e.dmg, own: e.id, trk: tgp >= 0 ? tgp : null, len: 44, needAlive: 1, fx: 'laser' }); g.len = 44; e.act = { k: 'wu', t: T.wu, next: 'none' }; voltMark(W, e, tg.x, tg.z); }
    else if (at === 'burst') e.act = { k: 'wu', t: T.wu, next: 'burst', n: 3 };
    else if (at === 'fuse') { e.act = { k: 'fuse', t: T.wu }; addTg(W, { k: 'c', x: e.x, z: e.z, r: 4.5, t: T.wu, dmg: e.dmg, own: e.id, fx: 'blast', then: (W2) => { const q = enemyById(W2, e.id); if (q && !q.dead) { q.dead = 1; q.deadT = W2.t; q.hp = 0; fx(W2, ['kill', q.id, q.x, q.y + 0.5, q.z, q.ty, 0, q.el]); } } }); }
    else if (at === 'charge') { e.act = { k: 'wu', t: T.wu, next: 'charge', ux, uz }; addTg(W, { k: 'l', x: e.x, z: e.z, x2: e.x + ux * 20, z2: e.z + uz * 20, w: 2.4, t: T.wu, dmg: 0, own: e.id, warn: 1 }); }
    else if (at === 'spit') {
      const p = tg.ref, lx = tg.x + (p.vx || 0) * 0.7, lz = tg.z + (p.vz || 0) * 0.7;
      e.act = { k: 'wu', t: T.wu, next: 'spit', lx, lz };
    }
    else if (at === 'slam') { const fx_ = e.x + ux * 3, fz = e.z + uz * 3; e.act = { k: 'wu', t: T.wu, next: 'none' }; addTg(W, { k: 'c', x: fx_, z: fz, r: 5, t: T.wu, dmg: e.dmg, own: e.id, needAlive: 1, fx: 'slam' }); voltMark(W, e, tg.x, tg.z); }
    else if (at === 'mortar') {
      e.act = { k: 'wu', t: T.wu, next: 'none' };
      for (let k = 0; k < 3; k++) { const a = Math.random() * TAU, r = k ? 3 + Math.random() * 3 : 0; addTg(W, { k: 'c', x: tg.x + Math.cos(a) * r, z: tg.z + Math.sin(a) * r, r: 3.5, t: T.wu + k * 0.2, dmg: e.dmg, own: e.id, fx: 'shell' }); }
    }
    else if (at === 'burrow') e.act = { k: 'wu', t: 0.5, next: 'melee' };
  }
  function runAct(W, e, dt, tg, slow) {
    const a = e.act, T = etype(e.ty);
    a.t -= dt * (slow < 1 ? 0.7 : 1);
    if (a.k === 'wu') {
      if (tg && a.next !== 'charge' && a.next !== 'dive') faceTo(e, tg.x, tg.z, 5 * dt);
      if (e.fly) hover(W, e, dt, e.x, e.z);
      if (a.t > 0) return;
      const n = a.next;
      e.act = null;
      if (n === 'lunge') { const sp = 15; e.act = { k: 'lunge', t: 0.38, vx: Math.sin(e.yaw) * sp, vz: Math.cos(e.yaw) * sp, hit: 0 }; }
      else if (n === 'melee') { meleeHit(W, e, T.rg, 1.9, e.dmg); fx(W, ['swing', e.id]); if (tg) voltMark(W, e, tg.x, tg.z); e.act = { k: 'rc', t: 0.35 }; }
      else if (n === 'dive') { const dx = a.tx - e.x, dy = a.ty - e.y, dz = a.tz - e.z, l = Math.hypot(dx, dy, dz) || 1; e.act = { k: 'dive', t: Math.min(1.2, (l + 3) / 22), vx: dx / l * 22, vy: dy / l * 22, vz: dz / l * 22, hit: 0, air: 1 }; }
      else if (n === 'orb') { if (tg) { spawnPr(W, { k: 'orb', own: 1, src: e.id, x: e.x, y: e.y + e.hgt * 0.5, z: e.z, sp: 13, hom: tg.k === 'p' ? tg.ref.s : null, tx: tg.x, ty: tg.y + 1, tz: tg.z, turn: 1.2, t: 5, dmg: e.dmg, hr: 0.5 }); voltMark(W, e, tg.x, tg.z); } e.act = { k: 'rc', t: 0.3 }; }
      else if (n === 'burst') { e.act = { k: 'burst', t: 0, n: 3 }; }
      else if (n === 'charge') { e.act = { k: 'charge', t: 1.0, vx: Math.sin(e.yaw) * 20, vz: Math.cos(e.yaw) * 20, hitS: 0 }; }
      else if (n === 'spit') {
        const sx = e.x, sy = e.y + e.hgt * 0.4, sz = e.z, ft = 1.1;
        spawnPr(W, { k: 'spit', own: 1, src: e.id, x: sx, y: sy, z: sz, vx: (a.lx - sx) / ft, vz: (a.lz - sz) / ft, vy: (hOf(W.S, a.lx, a.lz) - sy) / ft + 0.5 * 14 * ft, g: 14, t: ft + 0.2, dmg: 0 });
        addTg(W, { k: 'c', x: a.lx, z: a.lz, r: 3, t: ft, dmg: e.dmg, own: -1, el: e.el, fx: 'fire' });
        voltMark(W, e, a.lx, a.lz); e.act = { k: 'rc', t: 0.4 };
      }
      return;
    }
    if (a.k === 'lunge') {
      const ox = e.x, oz = e.z;
      moveBody(W, e, a.vx * dt, a.vz * dt, e.r * 0.8); void ox; void oz;
      if (!a.hit) for (const p of W.pl) if (!p.dead && hyp(p.x - e.x, p.z - e.z) < e.r + 0.9 && Math.abs(p.y - e.y) < 2) { a.hit = 1; hurtP(W, p, e.dmg, e); }
      if (a.t <= 0) e.act = { k: 'rc', t: 0.35 };
      return;
    }
    if (a.k === 'dive') {
      e.x += a.vx * dt; e.y += a.vy * dt; e.z += a.vz * dt;
      const gy = hOf(W.S, e.x, e.z); if (e.y < gy + 0.6) e.y = gy + 0.6;
      if (!a.hit) for (const p of W.pl) if (!p.dead && Math.hypot(p.x - e.x, p.y + 1 - e.y, p.z - e.z) < 1.4) { a.hit = 1; hurtP(W, p, e.dmg, e); }
      if (a.t <= 0) e.act = { k: 'rc', t: 0.6, air: 1 };
      return;
    }
    if (a.k === 'burst') {
      a.t -= dt;
      if (a.t <= 0 && tg) { a.t = 0.15; a.n--; const sp = (Math.random() - 0.5) * 0.08; const dx = tg.x - e.x, dz = tg.z - e.z, l = hyp(dx, dz) || 1, c = Math.cos(sp), s = Math.sin(sp); spawnPr(W, { k: 'bolt', own: 1, src: e.id, x: e.x, y: e.y + e.hgt * 0.75, z: e.z, sp: 34, tx: e.x + (dx * c - dz * s) / l * 40, ty: tg.y + 1, tz: e.z + (dx * s + dz * c) / l * 40, t: 2.2, dmg: e.dmg, hr: 0.3 }); fx(W, ['eshot', e.id]); }
      if (a.n <= 0 || !tg) { e.act = { k: 'rc', t: 0.4 }; if (tg) voltMark(W, e, tg.x, tg.z); }
      return;
    }
    if (a.k === 'charge') {
      moveBody(W, e, a.vx * dt, a.vz * dt, e.r * 0.8);
      for (const p of W.pl) if (!p.dead && !(a.hitS & (1 << p.s)) && hyp(p.x - e.x, p.z - e.z) < e.r + 1.0 && Math.abs(p.y - e.y) < 2.5) { a.hitS |= 1 << p.s; hurtP(W, p, e.dmg, e); }
      if (a.t <= 0) e.act = { k: 'rc', t: 0.6 };
      return;
    }
    if (a.k === 'emerge') { if (a.t <= 0) { e.bur = 0; e.emT = W.t; e.cd = 0.6; e.act = null; fx(W, ['emerge', e.id, e.x, e.y, e.z]); } return; }
    if (a.k === 'fuse') return;
    if (a.k === 'rc') {
      if (e.fly) hover(W, e, dt, e.x, e.z);
      if (a.t <= 0) { e.act = null; if (T.at === 'burrow' && !e.bur && W.t - e.emT > 5 && (!tg || hyp(tg.x - e.x, tg.z - e.z) > 6)) { e.bur = 1; fx(W, ['burrow', e.id]); } }
      return;
    }
    if (a.t <= 0) e.act = null;
  }

  /* ======================= 보스 ======================= */
  function stepBoss(W, e, dt, tg, slow) {
    const T = etype(e.ty);
    e.cd -= dt * slow;
    if (e.act) {
      const a = e.act; a.t -= dt;
      if (a.k === 'leap') {
        const k = clamp(1 - a.t / a.T, 0, 1);
        e.x = lerp(a.x0, a.x1, k); e.z = lerp(a.z0, a.z1, k); e.y = lerp(a.y0, a.y1, k) + Math.sin(k * Math.PI) * 9;
        if (a.t <= 0) { e.y = hOf(W.S, e.x, e.z); e.act = { k: 'rc', t: 0.6 }; }
        return;
      }
      if (a.k === 'dive') {
        const k = clamp(1 - a.t / a.T, 0, 1);
        e.x = lerp(a.x0, a.x1, k); e.z = lerp(a.z0, a.z1, k); e.y = lerp(a.y0, a.y1 + 1.5, k * k);
        if (a.t <= 0) e.act = { k: 'rise', t: 1.6 };
        return;
      }
      if (a.k === 'rise') { hover(W, e, dt * 0.8, e.x, e.z); if (a.t <= 0) e.act = null; return; }
      if (a.k === 'volley' && a.t <= 0 && tg) {
        const base = Math.atan2(tg.x - e.x, tg.z - e.z);
        for (let i = -2; i <= 2; i++) { const an = base + i * 0.18; spawnPr(W, { k: e.ty === 102 ? 'venom' : 'fireorb', own: 1, src: e.id, x: e.x, y: e.y + T.hgt * 0.4, z: e.z, sp: 18, tx: e.x + Math.sin(an) * 40, ty: tg.y + 1, tz: e.z + Math.cos(an) * 40, t: 4, dmg: e.dmg * 0.8, hr: 0.6 }); }
        e.act = { k: 'rc', t: 0.6 };
        return;
      }
      if (e.fly) hover(W, e, dt, e.x, e.z); else groundStepE(W, e, dt);
      if (a.t <= 0) e.act = null;
      return;
    }
    if (!tg) { if (e.fly) hover(W, e, dt, e.x, e.z); else groundStepE(W, e, dt); return; }
    const dx = tg.x - e.x, dz = tg.z - e.z, d = hyp(dx, dz), ux = dx / (d || 1), uz = dz / (d || 1);
    faceTo(e, tg.x, tg.z, 2.5 * dt);
    if (e.cd <= 0) {
      e.pat = (e.pat + 1 + Math.floor(Math.random() * 2)) % 3;
      e.cd = 2.6 + Math.random() * 1.2;
      const k = e.ty - 100;
      if (k === 0) {   // 심연 비룡
        if (e.pat === 0) e.act = { k: 'volley', t: 0.7 };
        else if (e.pat === 1) { e.act = { k: 'wu', t: 1.3 }; addTg(W, { k: 'l', x: e.x, z: e.z, x2: e.x + ux * 26, z2: e.z + uz * 26, w: 5, t: 1.3, dmg: e.dmg * 1.4, own: e.id, needAlive: 1, fx: 'breath' }); }
        else { const T2 = 1.4; addTg(W, { k: 'c', x: tg.x, z: tg.z, r: 6, t: T2, dmg: e.dmg * 1.5, own: e.id, fx: 'slam' }); e.act = { k: 'dive', t: T2, T: T2, x0: e.x, z0: e.z, y0: e.y, x1: tg.x, z1: tg.z, y1: hOf(W.S, tg.x, tg.z) }; }
      } else if (k === 1) {   // 붕괴 거상
        if (e.pat === 0) { e.act = { k: 'wu', t: 1.9 }; for (let i = -1; i <= 1; i++) { const an = Math.atan2(ux, uz) + i * 0.38; addTg(W, { k: 'l', x: e.x, z: e.z, x2: e.x + Math.sin(an) * 42, z2: e.z + Math.cos(an) * 42, w: 2.2, t: 1.0 + (i + 1) * 0.35, dmg: e.dmg * 1.2, own: e.id, needAlive: 1, fx: 'laser' }); } }
        else if (e.pat === 1) { e.act = { k: 'wu', t: 1.0 }; for (const p of W.pl) if (!p.dead) for (let j = 0; j < 3; j++) { const a = Math.random() * TAU, r = j ? 2.5 + Math.random() * 3 : 0; addTg(W, { k: 'c', x: p.x + Math.cos(a) * r, z: p.z + Math.sin(a) * r, r: 3, t: 1.5 + j * 0.25, dmg: e.dmg, own: -1, fx: 'shell' }); } }
        else { e.act = { k: 'wu', t: 1.2 }; addTg(W, { k: 'c', x: e.x, z: e.z, r: 9, t: 1.2, dmg: e.dmg * 1.6, own: e.id, needAlive: 1, fx: 'slam' }); }
      } else if (k === 2) {   // 군락 여왕
        if (e.pat === 0) { const T2 = 1.25; addTg(W, { k: 'c', x: tg.x, z: tg.z, r: 7, t: T2, dmg: e.dmg * 1.5, own: e.id, fx: 'slam' }); e.act = { k: 'leap', t: T2, T: T2, x0: e.x, z0: e.z, y0: e.y, x1: tg.x, z1: tg.z, y1: hOf(W.S, tg.x, tg.z) }; }
        else if (e.pat === 1) { const mins = W.en.filter((q) => q.minion && !q.dead).length; if (mins < 8) for (let i = 0; i < 3; i++) { const a = Math.random() * TAU; spawnEnemy(W, EKX.crawler, e.x + Math.cos(a) * 3, e.z + Math.sin(a) * 3, { minion: 1 }); } e.act = { k: 'wu', t: 0.8 }; }
        else e.act = { k: 'volley', t: 0.6 };
      } else {   // 늪의 군주
        if (e.pat === 0) { e.act = { k: 'wu', t: 1.3 }; addTg(W, { k: 'ring', x: e.x, z: e.z, r: 32, t: 1.0, dmg: e.dmg * 1.2, own: e.id, fx: 'ring' }); }
        else if (e.pat === 1) { e.act = { k: 'wu', t: 1.3 }; addTg(W, { k: 'c', x: e.x + ux * 5, z: e.z + uz * 5, r: 8, t: 1.2, dmg: e.dmg * 1.6, own: e.id, needAlive: 1, fx: 'slam' }); }
        else { e.act = { k: 'wu', t: 0.9 }; const lx = tg.x, lz = tg.z, ft = 1.6; spawnPr(W, { k: 'boulder', own: 1, src: e.id, x: e.x, y: e.y + T.hgt * 0.8, z: e.z, vx: (lx - e.x) / ft, vz: (lz - e.z) / ft, vy: (hOf(W.S, lx, lz) - e.y - T.hgt * 0.8) / ft + 0.5 * 14 * ft, g: 14, t: ft + 0.1, dmg: 0 }); addTg(W, { k: 'c', x: lx, z: lz, r: 4, t: ft, dmg: e.dmg * 1.2, own: -1, fx: 'slam' }); }
      }
      return;
    }
    // 이동
    const want = e.fly ? 14 : 6;
    if (d > want) {
      if (e.fly) { e.x += ux * T.spd * slow * dt; e.z += uz * T.spd * slow * dt; rockPush(W, e, 0.5); hover(W, e, dt, e.x, e.z); }
      else { moveToward(W, e, tg, d, T.spd * slow, dt, false); }
    } else if (e.fly) hover(W, e, dt, e.x, e.z); else groundStepE(W, e, dt);
  }

  /* ======================= 감독(적 출현) ======================= */
  function spawnSpot(W, ax, az, d0, d1, fly) {
    for (let g = 0; g < 14; g++) {
      const a = Math.random() * TAU, d = d0 + Math.random() * (d1 - d0), x = ax + Math.cos(a) * d, z = az + Math.sin(a) * d;
      if (hyp(x, z) > RW - 8) continue;
      if (!fly && !W.S.nav.ok[cellOf(x, z)]) continue;
      return [x, z];
    }
    return null;
  }
  function stepDirector(W, dt) {
    if (W.t < 4 || W.end) return;
    const D = W.dir, c = coeff(W), tpOn = W.tp.ph === 1;
    D.cred += dt * (0.55 + 0.5 * c) * (0.8 + 0.35 * (W.n - 1)) * (tpOn ? 1.7 : 1) * (W.len === '1' ? 1.25 : 1);
    D.waveT -= dt;
    if (D.waveT > 0) return;
    D.waveT = (tpOn ? 2.5 : 4) + Math.random() * (tpOn ? 3 : 5);
    let alive = 0; for (const e of W.en) if (!e.dead) alive++;
    if (alive >= Math.min(MAXE, 12 + 7 * W.n + 4 * W.si + (tpOn ? 8 : 0))) return;
    const lvl = enemyLv(c, W.n);
    const cands = W.pool.filter((ty) => ENEMY[ty].lv <= Math.max(1, lvl * 0.9 + W.si * 0.6 + 0.5) && ENEMY[ty].cost <= D.cred);
    if (!cands.length) return;
    cands.sort((a, b) => ENEMY[b].cost - ENEMY[a].cost);
    const ty = cands[Math.min(cands.length - 1, Math.floor(Math.random() * Math.min(3, cands.length)))];
    const T = ENEMY[ty];
    let el = -1;
    if ((lvl >= 4 || W.si >= 2) && D.cred >= T.cost * 4 && Math.random() < 0.3) el = Math.floor(Math.random() * ELITE.length);
    const unit = T.cost * (el >= 0 ? 4 : 1);
    const ps = alivePl(W); if (!ps.length) return;
    const an = ps[Math.floor(Math.random() * ps.length)];
    let k = 0;
    while (D.cred >= unit && k < 6 && alive < MAXE) {
      const sp = spawnSpot(W, an.x, an.z, 16, 32, !!T.fly);
      if (!sp) break;
      spawnEnemy(W, ty, sp[0], sp[1], { el });
      D.cred -= unit; k++; alive++;
    }
  }

  /* ======================= 플레이어: 조준 · 사격 ======================= */
  const muzzle = (p) => [p.x + Math.sin(p.yaw + 0.5) * 0.35, p.y + 1.4, p.z + Math.cos(p.yaw + 0.5) * 0.35];
  function aimDir(p) {
    const m = muzzle(p); let dx = p.tx - m[0], dy = p.ty - m[1], dz = p.tz - m[2]; let l = Math.hypot(dx, dy, dz);
    if (!(l > 1.5)) { dx = Math.sin(p.yaw); dy = 0; dz = Math.cos(p.yaw); l = 1; }
    return [dx / l, dy / l, dz / l];
  }
  /* 즉발 사격: 지형에 막힘(2m 간격 표본), 적 구 · 적 구체(파괴 가능) */
  function rayCast(W, ox, oy, oz, dx, dy, dz, range, pierce) {
    let end = range;
    for (let t = 2; t < range; t += 2) { if (oy + dy * t < hOf(W.S, ox + dx * t, oz + dz * t)) { end = t - 1; break; } }
    const hits = [];
    for (const e of W.en) {
      if (e.dead || e.bur) continue;
      const cx = e.x - ox, cy = e.y + e.hgt * 0.5 - oy, cz = e.z - oz, t = cx * dx + cy * dy + cz * dz;
      if (t < 0 || t > end + e.r) continue;
      const px = cx - dx * t, py = cy - dy * t, pz = cz - dz * t, rr = e.r + 0.25 + (e.boss ? 0.5 : 0), hy = Math.max(0, Math.abs(py) - e.hgt * 0.35);
      if (px * px + pz * pz + hy * hy < rr * rr) hits.push([t, e]);
    }
    hits.sort((a, b) => a[0] - b[0]);
    if (!pierce && hits.length) { end = hits[0][0]; hits.length = 1; }
    // 적 구체(해골 망령) 파괴
    for (const q of W.pr) if (q.own === 1 && q.k === 'orb') { const cx = q.x - ox, cy = q.y - oy, cz = q.z - oz, t = cx * dx + cy * dy + cz * dz; if (t > 0 && t < end) { const px = cx - dx * t, py = cy - dy * t, pz = cz - dz * t; if (px * px + py * py + pz * pz < 0.8) { q.t = 0; fx(W, ['pop', q.x, q.y, q.z]); } } }
    return { hits, end };
  }
  function shoot(W, p, mult, o) {
    o = o || {};
    const m = muzzle(p), d = aimDir(p), sp = o.spread || 0;
    let dx = d[0], dy = d[1], dz = d[2];
    if (sp) { dx += (Math.random() - 0.5) * sp; dy += (Math.random() - 0.5) * sp; dz += (Math.random() - 0.5) * sp; const l = Math.hypot(dx, dy, dz); dx /= l; dy /= l; dz /= l; }
    const r = rayCast(W, m[0], m[1], m[2], dx, dy, dz, o.range || 90, o.pierce);
    fx(W, ['tr', p.s, m[0], m[1], m[2], m[0] + dx * r.end, m[1] + dy * r.end, m[2] + dz * r.end, o.kind || 0]);
    if (W.host && o.atk !== false) for (const [, e] of r.hits) dealDmg(W, p.s, e, p.S.dmg * mult, { pc: o.pc == null ? 1 : o.pc, stun: o.stun, prim: o.prim });
    return r;
  }
  /* 근접 부채꼴 */
  function slash(W, p, mult, range, arc, o) {
    o = o || {};
    const fx_ = Math.sin(p.yaw), fz = Math.cos(p.yaw);
    fx(W, ['slash', p.s, p.x, p.y + 1.1, p.z, p.yaw, range, o.kind || 0]);
    if (!W.host || o.atk === false) return;
    for (const e of W.en) {
      if (e.dead || e.bur) continue;
      const dx = e.x - p.x, dz = e.z - p.z, d = hyp(dx, dz);
      if (d > range + e.r || e.y - p.y > 3.2 + (e.fly ? 2 : 0) || p.y - e.y > 3) continue;
      if (d > 1 && (dx * fx_ + dz * fz) / d < Math.cos(arc / 2)) continue;
      dealDmg(W, p.s, e, p.S.dmg * mult, { pc: o.pc == null ? 1 : o.pc, prim: o.prim });
    }
  }
  function coneTarget(W, p, maxD, cosMin) {
    const m = muzzle(p), d = aimDir(p); let best = null, bv = -1;
    for (const e of W.en) {
      if (e.dead || e.bur) continue;
      const cx = e.x - m[0], cy = e.y + e.hgt * 0.5 - m[1], cz = e.z - m[2], l = Math.hypot(cx, cy, cz);
      if (l > maxD) continue;
      const c = (cx * d[0] + cy * d[1] + cz * d[2]) / (l || 1);
      if (c < cosMin) continue;
      const v = c - l / maxD * 0.15;
      if (v > bv) { bv = v; best = e; }
    }
    return best;
  }
  function aimPoint(W, p, maxD) {
    const m = muzzle(p), d = aimDir(p);
    let t = Math.min(maxD, Math.hypot(p.tx - m[0], p.ty - m[1], p.tz - m[2]) || maxD);
    const r = rayCast(W, m[0], m[1], m[2], d[0], d[1], d[2], t, false);
    t = Math.min(t, r.end);
    const x = m[0] + d[0] * t, z = m[2] + d[2] * t;
    return [x, hOf(W.S, x, z), z];
  }
  function moveDir(p, inp) { const l = hyp(inp.mx || 0, inp.mz || 0); if (l > 0.2) return [inp.mx / l, inp.mz / l]; return [Math.sin(p.yaw), Math.cos(p.yaw)]; }

  /* ======================= 생존자 스킬 ======================= */
  /* mode: 'H' 이 기기가 움직이고 판정(로컬 · 호스트의 봇) · 'G' 게스트 자기 캐릭터(움직임 · 화면만) · 'R' 호스트가 게스트 캐릭터 판정(위치는 게스트가 보냄) */
  function useSkill(W, p, slot, inp, mode) {
    const mv = mode !== 'R', S = p.S, k = SURV[p.sv].k, atk = W.host && mode !== 'G';
    p.combatT = W.t; p.fireT = W.t; p.lastSk = slot;
    const md = moveDir(p, inp);
    fx(W, ['sk', p.s, slot]);
    if (k === 'scout') {
      if (slot === 0) { p.shotN++; shoot(W, p, 1.0, { spread: 0.012, prim: 1, kind: p.shotN & 1 }); }
      else if (slot === 1) shoot(W, p, 3.0, { pierce: 1, kind: 2 });
      else if (slot === 2) { if (mv) p.act = { k: 'roll', t: 0.4, vx: md[0] * 13, vz: md[1] * 13 }; if (atk || mode === 'H') p.inv = Math.max(p.inv, W.t + 0.38); }
      else p.act = { k: 'sup', t: 0.7, n: 8, it: 0, lock: 1 };
    } else if (k === 'gunner') {
      const m = muzzle(p), d = aimDir(p);
      if (slot === 0) { if (atk) spawnPr(W, { k: 'rocket', own: 0, s: p.s, x: m[0], y: m[1], z: m[2], vx: d[0] * 52, vy: d[1] * 52, vz: d[2] * 52, t: 2.5, dmg: S.dmg * 2.2, rad: 3.5, pc: 0.8, prim: 1 }); fx(W, ['muz', p.s, 1]); }
      else if (slot === 1) { if (atk) spawnPr(W, { k: 'shock', own: 0, s: p.s, x: m[0], y: m[1], z: m[2], vx: d[0] * 42, vy: d[1] * 42, vz: d[2] * 42, t: 2.5, dmg: S.dmg * 4, rad: 5, pc: 1, stun: 1 }); fx(W, ['muz', p.s, 2]); }
      else if (slot === 2) { if (mv) { p.act = { k: 'jet', t: 3, vy: 15, vx: md[0] * 11, vz: md[1] * 11, air: 1 }; p.gr = 0; } else p.act = { k: 'jet', t: 3 }; }
      else p.act = { k: 'barr', t: 1.2, n: 10, it: 0, lock: 1, pt: aimPoint(W, p, 70) };
    } else if (k === 'engi') {
      const m = muzzle(p), d = aimDir(p);
      if (slot === 0) { if (atk) for (const off of [-0.07, 0.07]) { const c = Math.cos(off), s = Math.sin(off); spawnPr(W, { k: 'gren', own: 0, s: p.s, x: m[0], y: m[1], z: m[2], vx: (d[0] * c - d[2] * s) * 30, vy: d[1] * 30 + 4, vz: (d[0] * s + d[2] * c) * 30, g: 20, t: 1.2, dmg: S.dmg * 1.6, rad: 3, pc: 0.6, prim: 1 }); } fx(W, ['muz', p.s, 3]); }
      else if (slot === 1) { if (atk) { const pt = aimPoint(W, p, 22); const mines = W.pr.filter((q) => q.k === 'mine' && q.s === p.s); if (mines.length >= 6) mines[0].t = 0; spawnPr(W, { k: 'mine', own: 0, s: p.s, x: pt[0], y: pt[1] + 0.1, z: pt[2], t: 40, dmg: S.dmg * 3, rad: 5, pc: 1 }); } }
      else if (slot === 2) { if (atk) W.domes.push({ x: p.x, z: p.z, y: p.y, r: 7, t: 8, s: p.s }); }
      else { if (atk) { const mine = W.tu.filter((t) => t.s === p.s); if (mine.length >= 2) mine[0].hp = 0; const fx_ = p.x + Math.sin(p.yaw) * 2, fz = p.z + Math.cos(p.yaw) * 2; W.tu.push({ id: W.nid++, s: p.s, x: fx_, z: fz, y: hOf(W.S, fx_, fz), hp: 220 * (1 + 0.3 * (p.lv - 1)), mhp: 220 * (1 + 0.3 * (p.lv - 1)), t: 0.5, yaw: p.yaw }); } }
    } else if (k === 'tracker') {
      const m = muzzle(p), d = aimDir(p);
      if (slot === 0) { if (atk) { const e = coneTarget(W, p, 60, Math.cos(0.44)); spawnPr(W, { k: 'arrow', own: 0, s: p.s, x: m[0], y: m[1], z: m[2], vx: d[0] * 70, vy: d[1] * 70, vz: d[2] * 70, sp: 70, hom: e ? e.id : null, turn: 14, t: 1.6, dmg: S.dmg * 1.5, pc: 1, prim: 1, hr: 0.5 }); } fx(W, ['muz', p.s, 4]); }
      else if (slot === 1) { if (atk) { const e = coneTarget(W, p, 45, Math.cos(0.6)) || nearestEnemy(W, p.x, p.z, 25); spawnPr(W, { k: 'blade', own: 0, s: p.s, x: m[0], y: m[1], z: m[2], hom: e ? e.id : null, n: 6, t: 4, dmg: S.dmg * 2.8, hitSet: new Set() }); } }
      else if (slot === 2) {
        if (mv) {
          const ox = p.x, oz = p.z; let dist = 14;
          while (dist > 2) { const nx = ox + md[0] * dist, nz = oz + md[1] * dist; if (hOf(W.S, nx, nz) - p.y < 2.5 && hyp(nx, nz) < RW - 5) { p.x = nx; p.z = nz; break; } dist -= 2; }
          p.y = Math.max(p.y, hOf(W.S, p.x, p.z)); rockPush(W, p, 0.45);
          fx(W, ['blink', p.s, ox, p.y, oz, p.x, p.z]);
        }
        if (atk || mode === 'H') p.inv = Math.max(p.inv, W.t + 0.3);
      }
      else { if (atk) { const pt = aimPoint(W, p, 50); W.rains.push({ x: pt[0], z: pt[2], y: pt[1], r: 7, t: 6, tick: 0, s: p.s }); } }
    } else {   // 파쇄병
      if (slot === 0) {
        if (W.t - p.comboT > 1.0) p.combo = 0;
        const c = p.combo; p.combo = (c + 1) % 3; p.comboT = W.t;
        slash(W, p, c === 2 ? 2.6 : 1.3, 3.2, 2.1, { prim: 1, kind: c, atk });
        if (mv && c === 2) { p.vx += Math.sin(p.yaw) * 7; p.vz += Math.cos(p.yaw) * 7; }
      } else if (slot === 1) { slash(W, p, 4.0, 3.6, 2.4, { kind: 3, atk }); if (mv) { p.vy = 10.5; p.gr = 0; } }
      else if (slot === 2) { if (mv) p.act = { k: 'dash', t: 0.26, vx: md[0] * 62, vz: md[1] * 62, hitS: new Set() }; else p.act = { k: 'dash', t: 0.3, hitS: new Set() }; if (atk || mode === 'H') p.inv = Math.max(p.inv, W.t + 0.32); }
      else {
        const list = W.en.filter((e) => !e.dead && !e.bur && hyp(e.x - p.x, e.z - p.z) < 25).sort((a, b) => hyp(a.x - p.x, a.z - p.z) - hyp(b.x - p.x, b.z - p.z)).slice(0, 5).map((e) => e.id);
        p.act = { k: 'blitz', t: 0.2 + list.length * 0.16, ids: list, it: 0.05, lock: 1 };
        if (atk || mode === 'H') p.inv = Math.max(p.inv, W.t + 0.25 + list.length * 0.16);
      }
    }
  }
  /* 진행 중 동작(연사 · 포격 · 돌진 · 난무 등) */
  function runPAct(W, p, inp, dt, mode) {
    const a = p.act; if (!a) return;
    const atk = W.host && mode !== 'G';
    a.t -= dt;
    if (a.k === 'sup') { a.it -= dt; if (a.it <= 0 && a.n > 0) { a.it += 0.08; a.n--; p.shotN++; shoot(W, p, 1.2, { spread: 0.02, stun: 0.4, kind: p.shotN & 1 }); } if (a.n <= 0) p.act = null; return; }
    if (a.k === 'barr') { a.it -= dt; if (a.it <= 0 && a.n > 0) { a.it += 0.09; a.n--; if (atk) { const pt = a.pt, j = 3.5, tx = pt[0] + (Math.random() - 0.5) * j * 2, tz = pt[2] + (Math.random() - 0.5) * j * 2, sx = p.x - Math.sin(p.yaw) * 1.5, sy = p.y + 3.2, sz = p.z - Math.cos(p.yaw) * 1.5; spawnPr(W, { k: 'rocket', own: 0, s: p.s, x: sx, y: sy, z: sz, sp: 46, tx, ty: hOf(W.S, tx, tz), tz, t: 3, dmg: p.S.dmg * 2.5, rad: 3, pc: 0.6 }); } fx(W, ['muz', p.s, 1]); } if (a.n <= 0) p.act = null; return; }
    if (a.k === 'blitz') {
      a.it -= dt;
      if (a.it <= 0 && a.ids.length) {
        a.it += 0.16; const id = a.ids.shift(), e = enemyById(W, id);
        if (e && !e.dead) { fx(W, ['slash', p.s, e.x, e.y + e.hgt * 0.5, e.z, Math.random() * TAU, 2.5, 4]); if (atk) for (let k = 0; k < 3; k++) dealDmg(W, p.s, e, p.S.dmg * 2.0, { pc: 1 }); }
      }
      if (a.t <= 0) p.act = null; return;
    }
    if (a.k === 'dash') {
      if (atk) for (const e of W.en) { if (e.dead || e.bur || a.hitS.has(e.id)) continue; if (hyp(e.x - p.x, e.z - p.z) < e.r + 2 && Math.abs(e.y - p.y) < 3) { a.hitS.add(e.id); dealDmg(W, p.s, e, p.S.dmg * (a.eq ? 5 : 3), { pc: 1 }); } }
      if (a.t <= 0) { p.act = null; p.vx *= 0.15; p.vz *= 0.15; } return;
    }
    if (a.k === 'roll') { if (a.t <= 0) { p.act = null; p.vx *= 0.4; p.vz *= 0.4; } return; }
    if (a.k === 'jet') {
      if (a.t < 2.85 && p.gr) {
        fx(W, ['boom', p.x, p.y + 0.3, p.z, 5, 'e']);
        if (atk) explode(W, p.s, p.x, p.y, p.z, 5, p.S.dmg * 3, { pc: 1 });
        p.act = null;
      } else if (a.t <= 0) p.act = null;
      return;
    }
    if (a.t <= 0) p.act = null;
  }

  /* ======================= 장비 ======================= */
  function useEquip(W, p, inp, mode) {
    if (p.eq < 0 || p.eqCh <= 0) return false;
    const E = EQUIP[p.eq], atk = W.host && mode !== 'G', mv = mode !== 'R', S = p.S;
    p.eqCh--; if (p.eqCd <= 0) p.eqCd = E.cd * S.eqCdMul;
    fx(W, ['eq', p.s, p.eq]);
    const k = E.k;
    if (k === 'dash') { if (mv) { const md = [Math.sin(p.yaw), Math.cos(p.yaw)]; p.act = { k: 'dash', t: 0.45, vx: md[0] * 66, vz: md[1] * 66, hitS: new Set(), eq: 1 }; } else p.act = { k: 'dash', t: 0.5, hitS: new Set(), eq: 1 }; if (atk || mode === 'H') p.inv = Math.max(p.inv, W.t + 0.5); return true; }
    if (!atk) return true;
    if (k === 'stim') healP(W, p, S.mhp * 0.5);
    else if (k === 'strike') { const pt = aimPoint(W, p, 80); addTg(W, { k: 'c', x: pt[0], z: pt[2], r: 8, t: 1.5, dmg: 0, own: -1, fx: 'strike', ally: 1, then: (W2, g) => { fx(W2, ['boom', g.x, g.y + 1, g.z, 8, 'e']); explode(W2, p.s, g.x, g.y, g.z, 8, S.dmg * 25, { pc: 1 }); } }); }
    else if (k === 'ward') p.ward = W.t + 3;
    else if (k === 'barrage') for (let i = 0; i < 12; i++) { const e = nearestEnemy(W, p.x, p.z, 60); spawnMissile(W, p.s, p.x, p.y + 2, p.z, e ? e.id : null, S.dmg * 3, 0).seek = 1; }
    else if (k === 'capacitor') { const e = coneTarget(W, p, 80, Math.cos(0.5)) || nearestEnemy(W, p.x, p.z, 40); if (e) { fx(W, ['bolt', e.x, e.y, e.z]); dealDmg(W, p.s, e, S.dmg * 30, { pc: 1 }); } }
    else if (k === 'cryo') { fx(W, ['boom', p.x, p.y + 1, p.z, 14, 'i']); for (const e of W.en) if (!e.dead && !e.bur && hyp(e.x - p.x, e.z - p.z) < 14) { freezeE(W, e, 3); dealDmg(W, p.s, e, S.dmg * 2, { pc: 1 }); } }
    else if (k === 'decoy') W.dc.push({ x: p.x, y: p.y, z: p.z, t: 8, s: p.s });
    else if (k === 'warhorn') { for (const q of W.pl) if (!q.dead) q.bf.wh = 8; }
    else if (k === 'ocular') p.bf.oc = 8;
    return true;
  }

  /* ======================= 플레이어 한 걸음 ======================= */
  const IDLE = { mx: 0, mz: 0, j: 0, b: 0, e: 0, q: 0, tx: 0, ty: 0, tz: 0 };
  function stepPlayer(W, p, inp, dt, mode) {
    inp = inp || IDLE;
    if (p.dead) return;
    if (p.inE == null) p.inE = inp.e; if (p.inQ == null) p.inQ = inp.q;   // 구역이 바뀌어도 누른 횟수를 이어받아 바로 발동하지 않게
    const S = p.S, mv = mode !== 'R';
    if (inp.tx != null && (inp.tx || inp.tz)) { p.tx = inp.tx; p.ty = inp.ty; p.tz = inp.tz; }
    if (mode !== 'R') { const d = aimDir(p); if (hyp(d[0], d[2]) > 0.05 && (p.act ? !(p.act.vx != null && p.act.k !== 'jet') : true)) p.yaw = Math.atan2(d[0], d[2]); else if (p.act && p.act.vx != null && hyp(p.act.vx, p.act.vz) > 1) p.yaw = Math.atan2(p.act.vx, p.act.vz); }
    // 재사용 대기
    p.cd[0] -= dt;
    for (let k = 1; k < 4; k++) { const mx = skMax(p, k); if (p.ch[k] < mx) { p.cd[k] -= dt; if (p.cd[k] <= 0) { p.ch[k]++; p.cd[k] = p.ch[k] < mx ? skCd(p, k) : 0; } } else { p.ch[k] = mx; p.cd[k] = 0; } }
    if (p.eq >= 0) { if (p.eqCh < S.eqMax) { p.eqCd -= dt; if (p.eqCd <= 0) { p.eqCh++; p.eqCd = p.eqCh < S.eqMax ? EQUIP[p.eq].cd * S.eqCdMul : 0; } } else { p.eqCh = Math.min(p.eqCh, S.eqMax); p.eqCd = 0; } }
    // 스킬
    const lock = p.act && p.act.lock;
    if (W.t >= 0 && !lock) {
      const b = inp.b || 0;
      if (b & 1 && p.cd[0] <= 0) { useSkill(W, p, 0, inp, mode); p.cd[0] = skCd(p, 0); if (W.host && mode !== 'G' && p.it[IX.shuriken]) shurikenFire(W, p); }
      for (let k = 1; k < 4; k++) if (b & (1 << k) && p.ch[k] > 0 && !(p.act && p.act.lock)) { if (k === 2 && p.act && (p.act.k === 'roll' || p.act.k === 'dash' || p.act.k === 'jet')) continue; useSkill(W, p, k, inp, mode); p.ch[k]--; if (p.cd[k] <= 0) p.cd[k] = skCd(p, k); }
    }
    runPAct(W, p, inp, dt, mode);
    // 장비 · 상호작용(누른 횟수가 바뀌면 한 번)
    if (inp.q !== p.inQ) { p.inQ = inp.q; if (W.t >= 0) useEquip(W, p, inp, mode); }
    else if (p.it[IX.gesture] && p.eq >= 0 && p.eqCh > 0 && W.t > 1 && mode !== 'G') useEquip(W, p, inp, mode);
    if (inp.e !== p.inE) { p.inE = inp.e; if (W.host && mode !== 'G') interact(W, p); }
    if (mv) movePlayer(W, p, inp, dt);
  }
  function movePlayer(W, p, inp, dt) {
    const S = p.S, a = p.act;
    const sp = SURV[p.sv].spd * dynMspd(W, p);
    let wx = inp.mx || 0, wz = inp.mz || 0; const wl = hyp(wx, wz); if (wl > 1) { wx /= wl; wz /= wl; }
    if (a && a.vx != null && a.k !== 'jet') { p.vx = a.vx; p.vz = a.vz; }
    else { const acc = (p.gr ? 55 : 20) * dt; p.vx += clamp(wx * sp - p.vx, -acc, acc); p.vz += clamp(wz * sp - p.vz, -acc, acc); }
    if (a && a.k === 'jet' && a.vy) { p.vy = a.vy; p.vx = a.vx; p.vz = a.vz; a.vy = 0; p.gr = 0; }
    if (inp.j && W.t >= -0.5) {
      if (p.gr) { p.vy = 9.6; p.gr = 0; p.jl = S.jumps - 1; fx(W, ['jump', p.s]); }
      else if (p.jl > 0) { p.jl--; p.vy = 9; fx(W, ['jump', p.s, 1]); }
    }
    moveBody(W, p, p.vx * dt, p.vz * dt, 0.45);
    const l = groundStep(W, p, dt);
    if (l) { p.jl = S.jumps - 1; if (l !== true && l < -6) fx(W, ['land', p.s, p.x, p.y, p.z, -l]); }
    p.stillT = wl < 0.1 && p.gr ? p.stillT + dt : 0;
  }
  function shurikenFire(W, p) {
    const n = p.it[IX.shuriken];
    p.shur = p.shur.filter((t) => t > W.t);
    if (p.shur.length >= n) return;
    p.shur.push(W.t + 1);
    const e = coneTarget(W, p, 60, 0.7) || nearestEnemy(W, p.x, p.z, 30); if (!e) return;
    const m = muzzle(p);
    spawnPr(W, { k: 'shur', own: 0, s: p.s, x: m[0], y: m[1], z: m[2], sp: 50, hom: e.id, turn: 10, t: 2, dmg: p.S.dmg * 4, pc: 1 });
  }

  /* ======================= 아이템 지급 · 상호작용 ======================= */
  function rollRar(R, w) { const r = R(); let a = 0; for (const k in w) { a += w[k]; if (r < a) return k; } return Object.keys(w)[0]; }
  function giveItem(W, p, idx, how) {
    p.it[idx] = (p.it[idx] || 0) + 1; p.picks++;
    const it = ITEMS[idx];
    if (it.k === 'shield') p.sh += p.S.mhp * 0.08;
    const oldMax = p.S.mhp; calcStats(p); if (p.S.mhp > oldMax) p.hp += p.S.mhp - oldMax; p.hp = Math.min(p.hp, p.S.mhp);
    if (it.k === 'backup') p.ch[1] = Math.min(skMax(p, 1), p.ch[1] + 1);
    if (it.k === 'fuel') p.eqCh = Math.min(p.S.eqMax, p.eqCh + 1);
    fx(W, ['pick', p.s, idx, p.it[idx]]);
    log(W, p.s, it.nm + (p.it[idx] > 1 ? ' ×' + p.it[idx] : '') + ' — ' + it.d, RAR[it.r] ? RAR[it.r].col : '');
    void how;
  }
  function randItem(rar) { const p = POOL[rar]; return p[Math.floor(Math.random() * p.length)]; }
  function nearIA(W, p) {
    let best = null, bd = 3.4;
    for (const o of W.ia) { if (o.used) continue; const d = hyp(o.x - p.x, o.z - p.z); if (d < bd && Math.abs(o.y - p.y) < 3) { bd = d; best = o; } }
    const T = W.S.tele; if (W.tp.ph !== 1 && W.tp.ph !== 2 && hyp(T.x - p.x, T.z - p.z) < 5.5) return { k: 'tele', x: T.x, z: T.z };
    if (W.ret && hyp(W.ret.x - p.x, W.ret.z - p.z) < 3.4) return { k: 'ret', x: W.ret.x, z: W.ret.z };
    return best;
  }
  function iaLabel(W, o, p) {
    if (!o) return null;
    if (o.k === 'tele') return W.tp.ph === 0 ? ['전송기 활성화', '충전 시작 · 보스 출현'] : W.tp.ph === 3 ? [lastStage(W) ? '귀환' : '다음 구역으로', W.tp.ph === 3 ? '남은 ' + Math.ceil(W.tp.readyT) + '초 뒤 자동 이동' : ''] : ['전송기', ''];
    if (o.k === 'ret') return ['귀환 신호', '원정 종료 · 귀환'];
    const I = IA[o.k];
    if (o.k === 'printw' || o.k === 'printg') { const it = ITEMS[o.item]; return [I.nm + ' → ' + it.nm, p && !p.it.some((c, i) => c > 0 && ITEMS[i].r === (o.k === 'printw' ? 'w' : 'g')) ? '교환할 아이템 없음' : '지닌 ' + RAR[o.k === 'printw' ? 'w' : 'g'].nm + ' 1개 소모']; }
    if (o.k === 'combat') return [I.nm, '정예 무리 소환'];
    if (o.k === 'lunar') return [I.nm, '균열 파편 ' + o.cost];
    return [I.nm, '자금 ' + o.cost];
  }
  const lastStage = (W) => W.len !== 'inf' && W.si + 1 >= (+W.len || 5);
  function interact(W, p) {
    const o = nearIA(W, p); if (!o) return false;
    const R = Math.random;
    if (o.k === 'tele') {
      if (W.tp.ph === 0) startTele(W, p.s);
      else if (W.tp.ph === 3) W.end = { k: lastStage(W) ? 'win' : 'next', by: p.s };
      return true;
    }
    if (o.k === 'ret') { W.end = { k: 'win', by: p.s }; return true; }
    const cost = o.cost;
    if (o.k === 'lunar') { if (p.shards < cost) { fx(W, ['deny', p.s]); return false; } p.shards -= cost; o.used = 1; giveItem(W, p, randItem('l'), 'pod'); fx(W, ['open', o.i]); return true; }
    if (o.k === 'printw' || o.k === 'printg') {
      const rar = o.k === 'printw' ? 'w' : 'g';
      const own = []; p.it.forEach((c, i) => { if (c > 0 && ITEMS[i].r === rar && i !== o.item) for (let k = 0; k < c; k++) own.push(i); });
      if (!own.length) { fx(W, ['deny', p.s]); return false; }
      const give = own[Math.floor(R() * own.length)];
      p.it[give]--; calcStats(p); giveItem(W, p, o.item, 'print'); fx(W, ['open', o.i]);
      return true;
    }
    if (o.k === 'combat') { o.used = 1; const ids = []; const c = coeff(W); let cred = 60 * c; const ty = W.pool[Math.floor(R() * W.pool.length)], T = ENEMY[ty]; const el = c >= 1.6 ? Math.floor(R() * ELITE.length) : -1; for (let k = 0; k < 6 && cred > 0; k++) { const sp = spawnSpot(W, o.x, o.z, 6, 14, !!T.fly); if (!sp) break; ids.push(spawnEnemy(W, ty, sp[0], sp[1], { el: k < 1 ? el : -1 }).id); cred -= T.cost * (k < 1 && el >= 0 ? 4 : 1); } W.combat = { ids }; fx(W, ['open', o.i]); log(W, p.s, '전투 제단 작동 · 정예 무리 출현', '#e8c547'); return true; }
    if (p.money < cost) { fx(W, ['deny', p.s]); return false; }
    p.money -= cost; fx(W, ['open', o.i]);
    if (o.k === 'chest') { o.used = 1; giveItem(W, p, randItem(rollRar(R, { w: 0.79, g: 0.2, r: 0.01 })), 'chest'); }
    else if (o.k === 'big') { o.used = 1; giveItem(W, p, randItem(rollRar(R, { g: 0.8, r: 0.2 })), 'chest'); }
    else if (o.k === 'vault') { o.used = 1; giveItem(W, p, randItem('r'), 'chest'); }
    else if (o.k === 'eqb') { o.used = 1; let e; do { e = Math.floor(R() * EQUIP.length); } while (e === p.eq && EQUIP.length > 1); p.eq = e; p.eqCh = p.S.eqMax; p.eqCd = 0; fx(W, ['pickE', p.s, e]); log(W, p.s, '장비 · ' + EQUIP[e].nm + ' — ' + EQUIP[e].d, '#f0a040'); }
    else if (o.k === 'chance') {
      o.uses++; o.cost = Math.round(o.cost * 1.4);
      if (R() < 0.45) { o.wins = (o.wins || 0) + 1; giveItem(W, p, randItem(rollRar(R, { w: 0.72, g: 0.21, r: 0.07 })), 'chance'); if (o.wins >= 2) o.used = 1; }
      else { log(W, p.s, '확률 제단 · 실패', '#8a8f99'); fx(W, ['fail', o.i]); }
    }
    return true;
  }
  function startTele(W, s) {
    const tp = W.tp; tp.ph = 1; tp.ch = 0; tp.by = s;
    const R = prng((W.st.ss ^ 0x5bd1e995) >>> 0);
    const nB = Math.min(3, 1 + Math.floor(W.si / 5) + (W.n >= 3 ? 1 : 0));
    const bt = BOSS[W.st.boss != null ? W.st.boss : Math.floor(R() * BOSS.length)];
    for (let i = 0; i < nB; i++) {
      const sp = spawnSpot(W, W.S.tele.x, W.S.tele.z, 12, 22, !!bt.fly) || [W.S.tele.x + 15, W.S.tele.z];
      tp.boss.push(spawnEnemy(W, bt.i, sp[0], sp[1], { el: W.si >= 5 && i ? Math.floor(R() * 3) : -1 }).id);
    }
    W.dir.cred += 80 * coeff(W);
    fx(W, ['tele', 1]);
    log(W, -1, '전송기 활성화 · ' + bt.nm + ' 출현', '#e8c547');
  }
  const TPR = 16;
  function stepTele(W, dt) {
    const tp = W.tp, T = W.S.tele;
    if (tp.ph === 1) {
      let any = false; for (const p of W.pl) if (!p.dead && hyp(p.x - T.x, p.z - T.z) < TPR) any = true;
      if (any) tp.ch = Math.min(1, tp.ch + dt / (W.len === '1' ? 35 : 60));
      if (tp.ch >= 1) { tp.ph = 2; fx(W, ['tele', 2]); }
    }
    if (tp.ph === 2) {
      const alive = tp.boss.some((id) => { const e = enemyById(W, id); return e && !e.dead; });
      if (!alive) {
        tp.ph = 3; tp.readyT = 25; fx(W, ['tele', 3]);
        const B = BOSS.find((b) => b.i === tp.bossK) || BOSS[0];
        for (const p of W.pl) if (!p.dead) giveItem(W, p, Math.random() < 0.15 ? IX[B.item] : randItem('g'), 'boss');
        if (W.len === 'inf' && W.si % 5 === 4) W.ret = { x: T.x + 6, z: T.z + 3, y: hOf(W.S, T.x + 6, T.z + 3) };
        // 남은 적 정리
        for (const e of W.en) if (!e.dead && !e.boss) e.hp = Math.min(e.hp, e.mhp * 0.3);
      }
    }
    if (tp.ph === 3) { tp.readyT -= dt; if (tp.readyT <= 0 && !W.end) W.end = { k: lastStage(W) ? 'win' : 'next', by: -1 }; }
  }

  /* ======================= 주기 효과 · 보조물 ======================= */
  function stepPlayerHost(W, p, dt) {
    if (p.dead) return;
    const S = p.S, it = p.it, n = (k) => it[IX[k]] || 0;
    if (p.hp < S.mhp) p.hp = Math.min(S.mhp, p.hp + S.regen * S.healMul * dt);
    if (S.shMax > 0 && W.t - p.hitT > 7) p.sh = Math.min(S.shMax, p.sh + S.shMax * dt * 2); if (p.sh > S.shMax) p.sh = S.shMax;
    if (p.bar > 0) p.bar = Math.max(0, p.bar - (S.mhp * 0.02 + p.bar * 0.04) * dt);
    if (p.medQ.length && p.medQ[0] <= W.t) { p.medQ.shift(); healP(W, p, 20 + S.mhp * 0.05 * n('medkit')); }
    for (const k in p.bf) if (p.bf[k] > 0) p.bf[k] -= dt;
    if (p.pred.length && p.pred[0] < W.t) p.pred = p.pred.filter((t) => t > W.t);
    if (p.burnT > W.t) { p.burnTick = (p.burnTick || 0) - dt; if (p.burnTick <= 0) { p.burnTick = 0.5; hurtP(W, p, S.mhp * 0.02, null); } }
    if (n('fungus') && p.stillT > 1) { p.fungT -= dt; if (p.fungT <= 0) { p.fungT = 0.5; const r = 3 + 1.5 * (n('fungus') - 1); for (const q of W.pl) if (!q.dead && hyp(q.x - p.x, q.z - p.z) < r) healP(W, q, q.S.mhp * (0.045 + 0.0225 * (n('fungus') - 1)) * 0.5); fx(W, ['fung', p.s, r]); } }
    if (n('tesla')) { p.teslaT += dt; const on = (p.teslaT % 20) < 10; if (on && (p.teslaT % 0.5) < dt) { let k = 3 + 2 * (n('tesla') - 1); for (const e of W.en) { if (k <= 0) break; if (e.dead || e.bur || hyp(e.x - p.x, e.z - p.z) > 35) continue; k--; fx(W, ['zap', p.x, p.y + 1.6, p.z, e.x, e.y + e.hgt * 0.5, e.z, 2]); dealDmg(W, p.s, e, S.dmg * 2, { pc: 0.3, crit: false }); } } }
    if (n('titancore')) { p.titanT += dt; if (p.titanT >= 10) { p.titanT = 0; for (let k = 0; k < 4 + 2 * (n('titancore') - 1); k++) { const e = nearestEnemy(W, p.x, p.z, 30); if (!e) break; spawnMissile(W, p.s, p.x, p.y + 2, p.z, e.id, S.dmg * 3, 0); } } }
    if (p.frost.length) { p.frost = p.frost.filter((t) => t > W.t); p.frostT -= dt; if (p.frostT <= 0 && p.frost.length) { p.frostT = 0.25; const r = 6 + 1.5 * p.frost.length; for (const e of W.en) if (!e.dead && !e.bur && hyp(e.x - p.x, e.z - p.z) < r) dealDmg(W, p.s, e, S.dmg * 1.5 * 0.25, { pc: 0.2, crit: false, dot: 1 }); } }
  }
  function stepAux(W, dt) {
    // 포탑
    for (const t of W.tu) {
      const p = W.pl[t.s]; if (!p || p.dead) { t.hp = 0; continue; }
      t.t -= dt;
      const e = nearestEnemy(W, t.x, t.z, 40); if (!e) continue;
      t.yaw = Math.atan2(e.x - t.x, e.z - t.z);
      if (t.t <= 0) {
        t.t = 0.25 / dynAspd(p);
        const ox = t.x, oy = t.y + 1.1, oz = t.z, dx = e.x - ox, dy = e.y + e.hgt * 0.5 - oy, dz = e.z - oz, l = Math.hypot(dx, dy, dz) || 1;
        fx(W, ['tr', -1 - t.s, ox, oy, oz, e.x, e.y + e.hgt * 0.5, e.z, 5]);
        dealDmg(W, t.s, e, p.S.dmg * 0.7, { pc: 1 }); void l; void dx; void dy; void dz;
      }
    }
    W.tu = W.tu.filter((t) => t.hp > 0);
    for (const d of W.dc) d.t -= dt; W.dc = W.dc.filter((d) => d.t > 0);
    for (const d of W.domes) d.t -= dt; W.domes = W.domes.filter((d) => d.t > 0);
    for (const r of W.rains) {
      r.t -= dt; r.tick -= dt;
      if (r.tick <= 0) { r.tick += 0.3; for (const e of W.en) if (!e.dead && !e.bur && hyp(e.x - r.x, e.z - r.z) < r.r + e.r) dealDmg(W, r.s, e, W.pl[r.s].S.dmg * 0.9, { pc: 0.2 }); }
    }
    W.rains = W.rains.filter((r) => r.t > 0);
    const keep = [];
    for (const b of W.bombs) {
      if (b.t > W.t) { keep.push(b); continue; }
      let x = b.x, y = b.y, z = b.z;
      if (b.e != null) { const e = enemyById(W, b.e); if (!e) continue; x = e.x; y = e.y + e.hgt * 0.5; z = e.z; }
      fx(W, ['boom', x, y, z, b.r, b.wisp ? 'w' : 'e']);
      explode(W, b.s, x, y, z, b.r, b.dmg, { pc: b.wisp ? 1 : 0.5, mask: b.mask, crit: false });
    }
    W.bombs = keep;
  }
  /* 적끼리 겹침 풀기(격자 버킷) */
  function separate(W) {
    const m = new Map();
    for (const e of W.en) { if (e.dead || e.bur) continue; const k = Math.floor(e.x / 3) * 1000 + Math.floor(e.z / 3); let a = m.get(k); if (!a) m.set(k, a = []); a.push(e); }
    for (const e of W.en) {
      if (e.dead || e.bur || e.boss) continue;
      const cx = Math.floor(e.x / 3), cz = Math.floor(e.z / 3);
      for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
        const a = m.get((cx + i) * 1000 + cz + j); if (!a) continue;
        for (const o of a) {
          if (o === e || o.fly !== e.fly) continue;
          const dx = e.x - o.x, dz = e.z - o.z, d = hyp(dx, dz), mm = (e.r + o.r) * 0.8;
          if (d < mm && d > 0.001) { const k = (mm - d) / d * 0.25; e.x += dx * k; e.z += dz * k; }
        }
      }
    }
  }

  /* ======================= 세계 한 걸음 ======================= */
  /* inputOf(s, p) → 입력(이 기기가 움직이는 자리) · 'R'(호스트가 판정만 하는 게스트 자리) · null(움직이지 않음) */
  function worldStep(W, dt, inputOf) {
    W.t += dt;
    for (const p of W.pl) {
      const v = inputOf(p.s, p);
      if (v === 'R') { if (W.host && p.rin) stepPlayer(W, p, p.rin, dt, 'R'); }
      else if (v) stepPlayer(W, p, v, dt, W.host ? 'H' : 'G');
    }
    if (!W.host) return;
    for (const p of W.pl) stepPlayerHost(W, p, dt);
    for (const e of W.en) stepEnemy(W, e, dt);
    if ((W.stepN = (W.stepN || 0) + 1) % 2 === 0) separate(W);
    W.en = W.en.filter((e) => !e.dead || W.t - e.deadT < 1.5);
    stepPr(W, dt);
    stepTg(W, dt);
    stepAux(W, dt);
    stepDirector(W, dt);
    stepTele(W, dt);
    if (!W.end && W.t > 1 && W.pl.every((p) => p.dead)) { W.loseT = (W.loseT || 0) + dt; if (W.loseT > 2.5) W.end = { k: 'lose' }; }
  }

  /* ======================= 봇 (상황 점수 + 씨앗 버릇) ======================= */
  function habits(seed, s) {
    const R = prng((seed ^ Math.imul(s + 1, 2654435761)) >>> 0);
    const h = { rng: 11 + R() * 12, greed: 0.5 + R() * 0.7, gamble: R(), risk: R(), flip: 1.4 + R() * 2.6, aimJ: R(), eqU: R(), side: R() < 0.5 ? 1 : -1, vs: (R() * 1e9) | 0, bold: R() };
    return h;
  }
  const AILV = {
    1: { noise: 0.1, react: 0.6, dodge: 0.3, sk: 0.45, eff: 0.65, lead: 0 },
    2: { noise: 0.04, react: 0.3, dodge: 0.68, sk: 0.8, eff: 0.9, lead: 0.5 },
    3: { noise: 0.012, react: 0.12, dodge: 0.93, sk: 1, eff: 1, lead: 1 },
  };
  /* 아이템 선호(봇마다 다름, 같은 판 안에서는 일정) */
  function itemVal(h, idx) { const it = ITEMS[idx]; const r = prng((h.vs ^ Math.imul(idx + 7, 40503)) >>> 0)(); return r * 0.6 + ({ w: 0.1, g: 0.3, r: 0.6, b: 0.5, l: 0.2, x: -1 })[it.r]; }
  function inDanger(W, p) {
    let best = null;
    for (const g of W.tg) {
      if (g.ally || (g.dmg <= 0 && !g.warn)) continue;
      let ins = false, ex = 0, ez = 0;
      if (g.k === 'c') { const d = hyp(p.x - g.x, p.z - g.z); if (d < g.r + 1.2) { ins = true; ex = (p.x - g.x) / (d || 1); ez = (p.z - g.z) / (d || 1); } }
      else if (g.k === 'l') { const d = segDist(p.x, p.z, g.x, g.z, g.x2, g.z2); if (d < g.w / 2 + 1.2) { ins = true; const vx = g.x2 - g.x, vz = g.z2 - g.z, l = hyp(vx, vz) || 1; const side = ((p.x - g.x) * -vz + (p.z - g.z) * vx) >= 0 ? 1 : -1; ex = -vz / l * side; ez = vx / l * side; } }
      else if (g.k === 'ring') { const d = hyp(p.x - g.x, p.z - g.z), rr = g.t > 0 ? 0 : g.rr || 0; if (rr < d && d - rr < 4) { ins = true; ex = 0; ez = 0; best = { g, ex, ez, jump: 1 }; continue; } }
      if (ins && (!best || g.t < best.g.t)) best = { g, ex, ez };
    }
    return best;
  }
  function aiInput(W, p, lv, hab) {
    const A = p.ai || (p.ai = { goal: null, gk: '', fd: new Int16Array(NN * NN), fT: -9, tgt: null, tT: 0, sideT: 0, side: hab.side, eC: 0, qC: 0, stT: 0, lx: p.x, lz: p.z, ox: 0, oy: 0, oz: 0, dodge: {}, skT: 0, claim: -1 });
    const Lv = AILV[lv] || AILV[2], S = p.S, sv = SURV[p.sv].k, melee = sv === 'breaker';
    const inp = { mx: 0, mz: 0, j: 0, b: 0, e: A.eC, q: A.qC, tx: p.tx, ty: p.ty, tz: p.tz };
    if (p.dead) return inp;
    // --- 표적 ---
    A.tT -= DT;
    if (A.tT <= 0) {
      A.tT = Lv.react * (0.7 + Math.random() * 0.6);
      let best = null, bv = 1e9;
      for (const e of W.en) {
        if (e.dead || e.bur) continue;
        const d = Math.hypot(e.x - p.x, (e.y - p.y) * 0.5, e.z - p.z);
        if (d > (melee ? 30 : 48)) continue;
        let v = d - (e.boss ? 10 : 0) - (e.tg && e.tg.ref === p ? 6 : 0) + (e.hp / e.mhp) * 4 - (W.tp.ph === 1 && e.boss ? 6 : 0);
        if (A.tgt === e.id) v -= 5;
        if (v < bv) { bv = v; best = e; }
      }
      A.tgt = best ? best.id : null;
      const n = Lv.noise * (0.6 + hab.aimJ * 0.8);
      A.ox = (Math.random() - 0.5) * 2 * n; A.oy = (Math.random() - 0.5) * 2 * n; A.oz = (Math.random() - 0.5) * 2 * n;
    }
    const tgt = A.tgt != null ? enemyById(W, A.tgt) : null;
    let near = 0; for (const e of W.en) if (!e.dead && !e.bur && hyp(e.x - p.x, e.z - p.z) < 16) near++;
    const hpF = (p.hp + p.sh) / (S.mhp + S.shMax);
    // --- 목표(전리품 · 전송기) ---
    const T = W.S.tele, tp = W.tp;
    const humans = W.humans || 0;
    const lootT = (W.len === '1' ? 75 : 150) * hab.greed * (lv === 1 ? 1.25 : 1) * (humans ? 1.6 : 1);
    let goal = null, gk = '', wantE = false;
    if (tp.ph === 1 || tp.ph === 2) {
      const d = hyp(p.x - T.x, p.z - T.z);
      if (d > TPR - 4) { goal = [T.x, T.z]; gk = 'tp'; }
    } else {
      let ia = null, scout = null;
      const left = W.ia.some((o) => !o.used && (o.k === 'chest' || o.k === 'big'));
      if (tp.ph === 0 && W.t < lootT || tp.ph === 3 && tp.readyT > 14) ia = pickLoot(W, p, hab, Lv, A);
      // 살 돈이 없으면: 적과 싸우며 아직 안 연 상자 쪽으로(자금이 모이면 바로 열도록)
      if (!ia && tp.ph === 0 && W.t < lootT && left) {
        if (tgt && hyp(tgt.x - p.x, tgt.z - p.z) < 30) scout = 'fight';
        else { let bd = 1e9; for (const o of W.ia) { if (o.used || (o.k !== 'chest' && o.k !== 'big')) continue; const d = hyp(o.x - p.x, o.z - p.z) + (o.i % 7) * hab.greed; if (d < bd) { bd = d; scout = o; } } }
      }
      if (ia) { goal = [ia.x, ia.z]; gk = 'ia' + ia.i; A.claim = ia.i; W.claims = W.claims || {}; W.claims[ia.i] = [p.s, W.t]; if (hyp(ia.x - p.x, ia.z - p.z) < 2.6) wantE = true; }
      else if (scout === 'fight') { goal = null; }
      else if (scout) { if (hyp(scout.x - p.x, scout.z - p.z) > 5) { goal = [scout.x, scout.z]; gk = 'sc' + scout.i; } }
      else if (W.ret && (hab.risk < 0.45 || hpF < 0.4 || W.pl.some((q) => q.dead))) { goal = [W.ret.x, W.ret.z]; gk = 'ret'; if (hyp(W.ret.x - p.x, W.ret.z - p.z) < 2.6) wantE = true; }
      else {
        goal = [T.x, T.z]; gk = 'tp';
        const d = hyp(T.x - p.x, T.z - p.z);
        if (d < 4.5) {
          if (tp.ph === 3) wantE = !humans || tp.readyT < 15;
          else if (tp.ph === 0) wantE = !humans || W.t > lootT * 1.8;
          if (!wantE) goal = null;
        }
      }
    }
    if (wantE && Math.random() < 0.15) A.eC++;
    inp.e = A.eC;
    // --- 이동 벡터 ---
    let mx = 0, mz = 0;
    if (goal) {
      if (A.gk !== gk || W.t - A.fT > 1.5) { flowField(W.S, goal[0], goal[1], A.fd); A.fT = W.t; A.gk = gk; }
      const dG = hyp(goal[0] - p.x, goal[1] - p.z);
      let st = dG > 3 ? flowStep(W.S, A.fd, p.x, p.z) : null;
      const gx = (st ? st[0] : goal[0]) - p.x, gz = (st ? st[1] : goal[1]) - p.z, gl = hyp(gx, gz) || 1;
      const w = dG > 1.2 ? 1 : 0;
      mx += gx / gl * w; mz += gz / gl * w;
    }
    if (tgt) {
      const dx = tgt.x - p.x, dz = tgt.z - p.z, d = hyp(dx, dz) || 1, ux = dx / d, uz = dz / d;
      A.sideT -= DT; if (A.sideT <= 0) { A.sideT = hab.flip * (0.6 + Math.random() * 0.8); if (Math.random() < 0.5) A.side = -A.side; }
      const wc = goal ? 0.55 : 1;
      if (melee) { if (d > 2.6) { mx += ux * wc; mz += uz * wc; } else { mx += -uz * A.side * 0.5 * wc; mz += ux * A.side * 0.5 * wc; } }
      else {
        const want = tgt.boss ? hab.rng + 4 : hab.rng;
        if (d < want - 4 || (hpF < 0.35 && d < want + 4)) { mx -= ux * wc; mz -= uz * wc; }
        else if (d > want + 8 && !goal) { mx += ux * 0.7; mz += uz * 0.7; }
        mx += -uz * A.side * 0.6 * wc; mz += ux * A.side * 0.6 * wc;
      }
    }
    // --- 회피 ---
    const dg = inDanger(W, p);
    if (dg) {
      const g = dg.g;
      if (A.dodge[g.id] == null) A.dodge[g.id] = Math.random() < Lv.dodge * (0.75 + hab.bold * 0.3) ? 1 : 0;
      if (A.dodge[g.id]) {
        if (dg.jump) inp.j = p.gr ? 1 : 0;
        else { mx = dg.ex * 2.2 + mx * 0.3; mz = dg.ez * 2.2 + mz * 0.3; if (g.t < 0.5 && Math.random() < Lv.sk && (sv === 'scout' || sv === 'tracker' || sv === 'breaker') && p.ch[2] > 0) inp.b |= 4; }
      }
    }
    // 막힘 → 점프
    const mv = hyp(p.x - A.lx, p.z - A.lz); A.lx = p.x; A.lz = p.z;
    if (hyp(mx, mz) > 0.3 && mv < 0.02 && p.gr) { A.stT += DT; if (A.stT > 0.6) { inp.j = 1; A.stT = 0; if (Math.random() < 0.4) A.side = -A.side; } } else A.stT = 0;
    const ml = hyp(mx, mz); if (ml > 1) { mx /= ml; mz /= ml; }
    inp.mx = mx; inp.mz = mz;
    // --- 조준 · 사격 ---
    if (tgt) {
      const d = hyp(tgt.x - p.x, tgt.z - p.z), lead = Lv.lead * Math.min(0.4, d / 70);
      const ty = tgt.y + tgt.hgt * 0.5;
      inp.tx = tgt.x + (tgt.vx || 0) * lead + A.ox * d; inp.ty = ty + A.oy * d; inp.tz = tgt.z + (tgt.vz || 0) * lead + A.oz * d;
      const range = melee ? 3.8 + tgt.r : sv === 'engi' ? 34 : 60;
      if (d < range) inp.b |= 1;
      A.skT -= DT;
      if (A.skT <= 0) {
        A.skT = 0.25 + (1 - Lv.sk) * 0.6;
        const many = near >= 3 || tgt.boss;
        if (Math.random() < Lv.sk) {
          if (sv === 'scout') { if (d < 60) inp.b |= 2; if (many && d < 45) inp.b |= 8; }
          else if (sv === 'gunner') { if (d < 45) inp.b |= 2; if (many && d < 60) inp.b |= 8; if (hpF < 0.4 && near >= 2 && Math.random() < 0.5) inp.b |= 4; }
          else if (sv === 'engi') { if (d < 20 && p.ch[1] > 0 && near >= 1) inp.b |= 2; if (hpF < 0.65 && near >= 2) inp.b |= 4; if (W.tu.filter((t) => t.s === p.s).length < 2 && (near >= 2 || tgt.boss)) inp.b |= 8; }
          else if (sv === 'tracker') { if (d < 40) inp.b |= 2; if (many && d < 50) inp.b |= 8; if (near >= 3 && hpF < 0.6) inp.b |= 4; }
          else { if (d < 3.8 + tgt.r) inp.b |= 2; if (d > 5 && d < 15) inp.b |= 4; if (near >= 2 || tgt.boss) inp.b |= 8; }
        }
        // 장비
        if (p.eq >= 0 && p.eqCh > 0 && Math.random() < 0.4 + hab.eqU * 0.5) {
          const E = EQUIP[p.eq].k;
          const use = E === 'stim' ? hpF < 0.45 : E === 'ward' ? hpF < 0.4 && near >= 2 : E === 'decoy' ? hpF < 0.5 && near >= 3 : E === 'dash' ? dg && hpF < 0.5 : many;
          if (use) A.qC++;
        }
      }
    } else {
      // 표적 없음: 이동 방향을 바라봄
      if (hyp(mx, mz) > 0.2) { inp.tx = p.x + mx * 10; inp.ty = p.y + 1.4; inp.tz = p.z + mz * 10; }
      if (p.eq >= 0 && p.eqCh > 0 && EQUIP[p.eq].k === 'stim' && hpF < 0.35) A.qC++;
    }
    inp.q = A.qC;
    return inp;
  }
  function pickLoot(W, p, hab, Lv, A) {
    let best = null, bv = -1e9;
    const claims = W.claims || {};
    for (const o of W.ia) {
      if (o.used) continue;
      const cl = claims[o.i]; if (cl && cl[0] !== p.s && W.t - cl[1] < 2) continue;
      const d = hyp(o.x - p.x, o.z - p.z);
      let v = -d * (0.6 + (1 - Lv.eff) * Math.random());
      if (o.k === 'chest' || o.k === 'big' || o.k === 'vault') { if (p.money < o.cost) continue; v += o.k === 'chest' ? 30 : o.k === 'big' ? 45 : 80; }
      else if (o.k === 'eqb') { if (p.money < o.cost || (p.eq >= 0 && hab.eqU > 0.4)) continue; v += 22; }
      else if (o.k === 'chance') { if (p.money < o.cost * 1.8 || hab.gamble < 0.35) continue; v += 15 + hab.gamble * 15; }
      else if (o.k === 'lunar') { if (p.shards < 1 || hab.risk < 0.45) continue; v += 20; }
      else if (o.k === 'combat') { if (hab.risk < 0.55 || W.t > 90 || p.hp < p.S.mhp * 0.7) continue; v += 10; }
      else if (o.k === 'printw' || o.k === 'printg') {
        const rar = o.k === 'printw' ? 'w' : 'g'; let worst = 9;
        p.it.forEach((c, i) => { if (c > 0 && ITEMS[i].r === rar && i !== o.item) worst = Math.min(worst, itemVal(hab, i)); });
        if (worst > 8 || itemVal(hab, o.item) < worst + 0.15) continue; v += 18;
      }
      if (v > bv) { bv = v; best = o; }
    }
    return best;
  }

  /* ======================= 원정 진행(상태) ======================= */
  const LENS = { inf: '무한 순환', 5: '5구역', 3: '3구역', 1: '1구역' };
  function setStage(st) {
    st.th = st.order[st.si % THEMES.length];
    st.ss = 1 + Math.floor(Math.random() * 2e9);
    st.boss = Math.floor(prng(st.ss)() * BOSS.length);
    st.ph = 'play'; st.seq = (st.seq || 0) + 1;
    return st;
  }
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = Math.random;
    const len = ['inf', '5', '3', '1'].includes(String(opts.len)) ? String(opts.len) : 'inf';
    const diff = DIFF[opts.diff] ? opts.diff : 'std';
    let order = shuffle(prng(1 + Math.floor(R() * 2e9)), [0, 1, 2, 3, 4]);
    const sIdx = THEMES.findIndex((t) => t.k === opts.start);
    if (sIdx >= 0) order = [sIdx].concat(order.filter((x) => x !== sIdx));
    const st = { v: 1, rid: 1 + Math.floor(R() * 1e6), seed: 1 + Math.floor(R() * 2e9), n, nm: players.map((p) => String(p.name || '').slice(0, 12)), ai: players.map((p) => (p.ai ? 1 : 0)),
      ph: 'pick', sv: Array(n).fill(-1), len, diff, si: 0, order, rt: 0, carry: [], seq: 0, hist: [], res: null };
    for (let s = 0; s < n; s++) if (players[s].ai) st.sv[s] = aiPick(st, s);
    if (st.sv.every((v) => v >= 0)) setStage(st);
    return st;
  }
  function aiPick(st, s) { const h = habits(st.seed, s); return Math.floor(prng((h.vs ^ 977) >>> 0)() * SURV.length); }
  function pickSv(st, s, v) { const ns = JSON.parse(JSON.stringify(st)); if (ns.ph !== 'pick') return ns; ns.sv[s] = clamp(v | 0, 0, SURV.length - 1); ns.seq++; if (ns.sv.every((x) => x >= 0)) setStage(ns); return ns; }
  function forcePick(st) { const ns = JSON.parse(JSON.stringify(st)); for (let s = 0; s < ns.n; s++) if (ns.sv[s] < 0) ns.sv[s] = aiPick(ns, s); return setStage(ns); }
  function carryOf(W) { return W.pl.map((p) => ({ it: itemStr(p.it), eq: p.eq, lv: p.lv, xp: Math.round(p.xp), $: Math.round(p.money), sh: p.shards, inf: p.infHP, k: p.kills, dd: Math.round(p.dd), dt: Math.round(p.dt), de: p.deaths, pk: p.picks })); }
  /* 구역 끝 → 다음 상태 (호스트) */
  function endStage(st, W) {
    const ns = JSON.parse(JSON.stringify(st)), k = W.end ? W.end.k : 'next';
    ns.carry = carryOf(W);
    ns.rt = Math.round(rtOf(W) * 10) / 10;
    ns.hist.push([ns.si, ns.th, Math.round(Math.max(0, W.t)), k === 'lose' ? 0 : 1]);
    if (k === 'next') { ns.si++; return setStage(ns); }
    ns.ph = 'done'; ns.win = k === 'win' ? 1 : 0; ns.cleared = ns.si + (k === 'win' ? 1 : 0); ns.seq++;
    return ns;
  }
  const fmtT = (s) => { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  function result(s) {
    if (!s || s.ph !== 'done') return null;
    const nm = (i) => (s.nm && s.nm[i]) || ((i + 1) + '번');
    const C = s.carry || [];
    const loops = Math.floor(s.cleared / 5);
    const title = s.win ? '귀환 완료' : '원정 실패';
    const hl = [];
    hl.push('통과 구역 ' + s.cleared + (loops ? ' · 순환 ' + loops : '') + ' · 원정 시간 ' + fmtT(s.rt) + ' · 최종 단계 「' + tierOf(s.rt, DIFF[s.diff] || 2).nm + '」');
    let bestK = -1, bk = -1; C.forEach((c, i) => { if ((c.k || 0) > bk) { bk = c.k || 0; bestK = i; } });
    if (bestK >= 0) hl.push('최다 처치 ' + nm(bestK) + ' · ' + bk);
    let bestI = -1, bi = -1; C.forEach((c, i) => { const n = itemCount(itemArr(c.it)); if (n > bi) { bi = n; bestI = i; } });
    if (bestI >= 0) hl.push('최다 아이템 ' + nm(bestI) + ' · ' + bi + '개');
    return {
      winners: s.win ? [...Array(s.n).keys()] : [], title,
      text: s.win ? '전원 귀환. 쌓은 아이템은 이번 원정에서만 유효.' : '전원 쓰러짐.',
      highlights: hl,
      stats: [
        { label: '생존자', values: [...Array(s.n).keys()].map((i) => (SURV[s.sv[i]] || SURV[0]).nm) },
        { label: '처치', values: C.map((c) => c.k || 0) },
        { label: '준 피해', values: C.map((c) => c.dd || 0) },
        { label: '받은 피해', values: C.map((c) => c.dt || 0), low: true },
        { label: '아이템', values: C.map((c) => itemCount(itemArr(c.it))) },
        { label: '레벨', values: C.map((c) => c.lv || 1) },
        { label: '쓰러짐', values: C.map((c) => c.de || 0), low: true },
      ],
    };
  }
  function hint(st, seat) {
    if (!st) return null;
    if (st.ph === 'pick') return ['생존자 선택', '카드를 눌러 생존자 선택. 같은 생존자를 여럿이 골라도 됨.', '모든 생존자 처음부터 사용 가능.'];
    if (st.ph === 'done') return null;
    const T = THEMES[st.th] || THEMES[0];
    const out = ['구역 ' + (st.si + 1) + ' · ' + T.nm + (st.si >= 5 ? ' (순환 ' + Math.floor(st.si / 5) + ')' : '')];
    out.push('상자 · 제단을 열어 아이템 수집 → 전송기 활성화 → 충전 범위 안에서 버티며 보스 처치 → 다음 구역.');
    out.push('시간이 흐를수록 난이도 단계 상승. 너무 오래 머물면 적이 강해짐.');
    out.push('쓰러진 동료는 다음 구역에서 복귀(소생 기억체가 있으면 즉시).');
    if (seat >= 0 && st.sv) { const S = SURV[st.sv[seat]]; if (S) out.push(S.nm + ': ' + S.sk.map((k) => k[0]).join(' · ')); }
    return out.slice(0, 6);
  }

  /* ======================= 네트워크 묶기 ======================= */
  const r1 = (v) => Math.round(v * 10), r2 = (v) => Math.round(v * 100);
  const PRK = ['rocket', 'shock', 'gren', 'mine', 'arrow', 'blade', 'missile', 'dagger', 'fireball', 'shur', 'orb', 'bolt', 'spit', 'boulder', 'fireorb', 'venom', 'shell'];
  const PRX = {}; PRK.forEach((k, i) => { PRX[k] = i; });
  const ACTK = ['', 'roll', 'sup', 'jet', 'barr', 'dash', 'blitz'];
  const FXK = ['', 'laser', 'slam', 'shell', 'fire', 'blast', 'breath', 'ring', 'strike', 'volt'];
  function pFlags(W, p) { return (p.dead ? 1 : 0) | (p.inv > W.t ? 2 : 0) | (p.ward > W.t ? 4 : 0) | (p.bf.ck > 0 ? 8 : 0) | (p.gr ? 16 : 0) | (p.bf.bz > 0 ? 32 : 0) | (p.bf.wh > 0 ? 64 : 0) | (p.bf.oc > 0 ? 128 : 0) | (p.burnT > W.t ? 256 : 0) | (p.slowT > W.t ? 512 : 0); }
  function packHost(W, evs) {
    const t = W.t;
    const pl = W.pl.map((p) => [r1(p.x), r1(p.y), r1(p.z), Math.round(p.yaw * 50), Math.round(p.hp), Math.round(p.S.mhp), Math.round(p.sh), Math.round(p.S.shMax), Math.round(p.bar), p.lv, Math.round(p.xp / xpNeed(p.lv) * 100), Math.round(p.money), p.shards, pFlags(W, p), p.eq, p.eqCh, r1(Math.max(0, p.eqCd)), ACTK.indexOf(p.act ? p.act.k : ''), r1(p.vx), r1(p.vz), p.ch[1], p.ch[2], p.ch[3], r1(p.cd[1]), r1(p.cd[2]), r1(p.cd[3])]);
    // 적: 플레이어에 가까운 순 48
    const ps = alivePl(W).length ? alivePl(W) : W.pl;
    const dmin = (e) => { let m = 1e9; for (const p of ps) { const d = hyp(e.x - p.x, e.z - p.z); if (d < m) m = d; } return m - (e.boss ? 200 : 0); };
    let ens = W.en.filter((e) => !e.dead || t - e.deadT < 1.2);
    if (ens.length > 48) ens = ens.map((e) => [dmin(e), e]).sort((a, b) => a[0] - b[0]).slice(0, 48).map((a) => a[1]);
    const en = ens.map((e) => [e.id, e.ty, r1(e.x), r1(e.y), r1(e.z), Math.round(e.yaw * 50), Math.round(clamp(e.hp / e.mhp, 0, 1) * 100), e.act ? (e.act.k === 'wu' || e.act.k === 'fuse' || e.act.k === 'emerge' ? 1 : 2) : 0, e.el, (e.bur ? 1 : 0) | (e.dead ? 2 : 0) | (e.frzT > t ? 4 : 0) | (e.stunT > t ? 8 : 0) | (e.boss ? 16 : 0) | (e.minion ? 32 : 0), e.lvl | 0]);
    let prs = W.pr;
    if (prs.length > 40) prs = prs.filter((q) => q.own === 1).concat(prs.filter((q) => q.own === 0)).slice(0, 40);
    const pr = prs.map((q) => [q.id, PRX[q.k] | 0, r1(q.x), r1(q.y), r1(q.z), r1(q.vx), r1(q.vy), r1(q.vz)]);
    const tg = W.tg.slice(0, 24).map((g) => [g.id, g.k === 'c' ? 0 : g.k === 'l' ? 1 : 2, r1(g.x), r1(g.z), r1(g.x2 || 0), r1(g.z2 || 0), r1(g.r), r1(g.w), r2(Math.max(0, g.t)), r2(g.T), FXK.indexOf(g.fx || '') | 0, r1(g.rr || 0), (g.warn ? 1 : 0) | (g.ally ? 2 : 0), g.el]);
    let ia = ''; for (const o of W.ia) ia += o.used ? '1' : '0';
    return {
      k: 'i' + W.st.rid + '_' + W.si, t: r2(t), pl, en, pr, tg, ia, ic: W.ia.map((o) => o.cost),
      tp: [W.tp.ph, Math.round(W.tp.ch * 1000), r1(Math.max(0, W.tp.readyT)), W.tp.bossK, W.ret ? 1 : 0],
      tu: W.tu.map((u) => [u.id, u.s, r1(u.x), r1(u.y), r1(u.z), Math.round(u.yaw * 50), Math.round(u.hp / u.mhp * 100)]),
      dm: W.domes.map((d) => [r1(d.x), r1(d.y), r1(d.z), r1(d.r), r1(d.t)]), rn: W.rains.map((r) => [r1(r.x), r1(r.y), r1(r.z), r1(r.r), r1(r.t)]), dc: W.dc.map((d) => [r1(d.x), r1(d.y), r1(d.z)]),
      iv: W.pl.map((p) => itemStr(p.it)), ev: evs || [], c100: Math.round(coeff(W) * 100),
    };
  }
  /* 게스트: 호스트 묶음 풀기(자기 자리 위치는 그대로 두고 체력 · 자금 · 상태만) */
  function applyHost(W, hs, me) {
    if (!hs) return;
    if (typeof hs.t === 'number') { const tt = hs.t / 100; if (Math.abs(tt - W.t) > 0.5) W.t = tt; else W.t += (tt - W.t) * 0.1; }
    if (Array.isArray(hs.pl)) hs.pl.forEach((a, s) => {
      const p = W.pl[s]; if (!p || !Array.isArray(a)) return;
      if (s !== me) { p.nx = a[0] / 10; p.ny = a[1] / 10; p.nz = a[2] / 10; p.yaw = a[3] / 50; p.vx = a[18] / 10; p.vz = a[19] / 10; p.actK = ACTK[a[17]] || ''; if (p.snapT == null) { p.x = p.nx; p.y = p.ny; p.z = p.nz; } p.snapT = performanceNow(); }
      p.hp = a[4]; p.S.mhp = a[5]; p.sh = a[6]; p.S.shMax = a[7]; p.bar = a[8]; p.lv = a[9]; p.xpF = a[10] / 100; p.money = a[11]; p.shards = a[12];
      const f = a[13]; p.dead = f & 1; p.inv = f & 2 ? W.t + 0.2 : 0; p.ward = f & 4 ? W.t + 0.2 : 0; p.bf.ck = f & 8 ? 0.2 : 0; if (s !== me) p.gr = f & 16 ? 1 : 0; p.bf.bz = f & 32 ? 0.2 : 0; p.bf.wh = f & 64 ? 0.2 : 0; p.bf.oc = f & 128 ? 0.2 : 0; p.burnT = f & 256 ? W.t + 0.2 : 0; p.slowT = f & 512 ? W.t + 0.2 : 0;
      p.eq = a[14]; p.eqCh = a[15]; p.eqCd = a[16] / 10;
      if (s !== me) { p.ch[1] = a[20]; p.ch[2] = a[21]; p.ch[3] = a[22]; }
    });
    if (Array.isArray(hs.iv)) hs.iv.forEach((s, i) => { const p = W.pl[i]; if (p && typeof s === 'string' && s !== p.ivS) { p.ivS = s; p.it = itemArr(s); const keep = { mhp: p.S.mhp, shMax: p.S.shMax }; calcStats(p); Object.assign(p.S, keep); } });
    if (Array.isArray(hs.en)) {
      const old = new Map(W.en.map((e) => [e.id, e])), now = performanceNow();
      W.en = hs.en.map((a) => {
        let e = old.get(a[0]);
        const T = etype(a[1]);
        if (!e) e = { id: a[0], ty: a[1], x: a[2] / 10, y: a[3] / 10, z: a[4] / 10, yaw: a[5] / 50, r: T.r, hgt: T.hgt, fly: T.fly || 0, boss: T.boss ? 1 : 0, dots: [], mhp: 1 };
        e.nx = a[2] / 10; e.ny = a[3] / 10; e.nz = a[4] / 10; e.nyaw = a[5] / 50; e.hpF = a[6] / 100; e.hp = e.hpF; e.mhp = 1; e.ast = a[7]; e.el = a[8];
        const f = a[9]; e.bur = f & 1; if ((f & 2) && !e.dead) { e.dead = 1; e.deadT = W.t; } e.frz = f & 4; e.stun = f & 8; e.minion = f & 32 ? 1 : 0; e.lvl = a[10] || 1; e.snapT = now;
        return e;
      });
    }
    if (Array.isArray(hs.pr)) W.pr = hs.pr.map((a) => ({ id: a[0], k: PRK[a[1]], x: a[2] / 10, y: a[3] / 10, z: a[4] / 10, vx: a[5] / 10, vy: a[6] / 10, vz: a[7] / 10, own: a[1] >= PRX.orb ? 1 : 0, g: a[1] === PRX.spit || a[1] === PRX.boulder || a[1] === PRX.gren ? (a[1] === PRX.gren ? 20 : 14) : 0 }));
    if (Array.isArray(hs.tg)) W.tg = hs.tg.map((a) => ({ id: a[0], k: ['c', 'l', 'ring'][a[1]], x: a[2] / 10, z: a[3] / 10, x2: a[4] / 10, z2: a[5] / 10, r: a[6] / 10, w: a[7] / 10, t: a[8] / 100, T: a[9] / 100, fx: FXK[a[10]], rr: a[11] / 10, warn: a[12] & 1, ally: a[12] & 2, el: a[13], y: hOf(W.S, a[2] / 10, a[3] / 10) }));
    if (typeof hs.ia === 'string') for (let i = 0; i < W.ia.length && i < hs.ia.length; i++) W.ia[i].used = hs.ia[i] === '1' ? 1 : 0;
    if (Array.isArray(hs.ic)) hs.ic.forEach((c, i) => { if (W.ia[i]) W.ia[i].cost = c; });
    if (Array.isArray(hs.tp)) { W.tp.ph = hs.tp[0]; W.tp.ch = hs.tp[1] / 1000; W.tp.readyT = hs.tp[2] / 10; W.tp.bossK = hs.tp[3]; if (hs.tp[4] && !W.ret) { const T = W.S.tele; W.ret = { x: T.x + 6, z: T.z + 3, y: hOf(W.S, T.x + 6, T.z + 3) }; } }
    if (Array.isArray(hs.tu)) W.tu = hs.tu.map((a) => ({ id: a[0], s: a[1], x: a[2] / 10, y: a[3] / 10, z: a[4] / 10, yaw: a[5] / 50, hp: a[6], mhp: 100 }));
    if (Array.isArray(hs.dm)) W.domes = hs.dm.map((a) => ({ x: a[0] / 10, y: a[1] / 10, z: a[2] / 10, r: a[3] / 10, t: a[4] / 10 }));
    if (Array.isArray(hs.rn)) W.rains = hs.rn.map((a) => ({ x: a[0] / 10, y: a[1] / 10, z: a[2] / 10, r: a[3] / 10, t: a[4] / 10 }));
    if (Array.isArray(hs.dc)) W.dc = hs.dc.map((a) => ({ x: a[0] / 10, y: a[1] / 10, z: a[2] / 10, t: 1 }));
    if (hs.c100) W.cRemote = hs.c100 / 100;
  }
  const performanceNow = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
  function packGuest(W, p, inp, ctr) {
    return { p: [r1(p.x), r1(p.y), r1(p.z), r1(p.vx), r1(p.vy), r1(p.vz), Math.round(p.yaw * 50), p.gr ? 1 : 0, ACTK.indexOf(p.act ? p.act.k : '')], b: inp.b | 0, e: ctr.e, q: ctr.q, a: [r1(p.tx), r1(p.ty), r1(p.tz)], ev: ctr.ev || [] };
  }
  function ingestGuest(W, s, o) {
    const p = W.pl[s]; if (!p || !o || !Array.isArray(o.p)) return;
    const a = o.p;
    p.x = a[0] / 10; p.y = a[1] / 10; p.z = a[2] / 10; p.vx = a[3] / 10; p.vy = a[4] / 10; p.vz = a[5] / 10; p.yaw = a[6] / 50; p.gr = a[7] ? 1 : 0;
    p.rin = { mx: 0, mz: 0, j: 0, b: o.b | 0, e: o.e | 0, q: o.q | 0, tx: o.a ? o.a[0] / 10 : p.tx, ty: o.a ? o.a[1] / 10 : p.ty, tz: o.a ? o.a[2] / 10 : p.tz };
    if (p.rin.tx || p.rin.tz) { p.tx = p.rin.tx; p.ty = p.rin.ty; p.tz = p.rin.tz; }
  }

  /* ======================= 아이콘(직접 그린 SVG — 24×24, currentColor) ======================= */
  const s_ = (d, w) => '<path d="' + d + '" fill="none" stroke="currentColor" stroke-width="' + (w || 2) + '" stroke-linecap="round" stroke-linejoin="round"/>';
  const f_ = (d, o) => '<path d="' + d + '" fill="currentColor"' + (o ? ' opacity="' + o + '"' : '') + '/>';
  const GLY = {
    scope: s_('M12 4v4M12 16v4M4 12h4M16 12h4') + '<circle cx="12" cy="12" r="6" fill="none" stroke="currentColor" stroke-width="2"/>',
    mag: f_('M8 4h8v4H8zM7 9h10v11H7z') + f_('M9 11h6v1.6H9zM9 14h6v1.6H9z', 0.4),
    boot: f_('M8 3h5v9l6 3v4H5v-4l3-2z'),
    moss: f_('M4 18c2-6 5-8 8-8s6 2 8 8z') + f_('M8 9a2 2 0 104 0 2 2 0 10-4 0M13 6a1.6 1.6 0 103.2 0 1.6 1.6 0 10-3.2 0', 0.7),
    fang: f_('M6 4h12l-3 8-3 8-3-8z') + f_('M10 6h4l-2 5z', 0.35),
    shield: f_('M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6z'),
    plate: f_('M5 5h14v14H5z', 0.85) + s_('M5 10h14M5 15h14', 1.5),
    cross: f_('M10 4h4v6h6v4h-6v6h-4v-6H4v-4h6z'),
    lens: '<circle cx="12" cy="12" r="7" fill="none" stroke="currentColor" stroke-width="2"/>' + f_('M12 8a4 4 0 110 8 4 4 0 010-8z', 0.6),
    bomb: f_('M11 8a6 6 0 110 12 6 6 0 010-12z') + s_('M14 8l3-4M17 4l2 1'),
    hook: s_('M12 3v10a4 4 0 11-8 0M12 3l3 3', 2.4),
    jet: f_('M9 3h6v12H9z') + f_('M9 16l3 6 3-6z', 0.6),
    hour: s_('M7 3h10M7 21h10M8 3c0 5 8 5 8 9s-8 4-8 9M16 3c0 5-8 5-8 9s8 4 8 9'),
    wing: f_('M3 14c4-8 10-10 18-10-2 4-6 6-10 6 3 1 6 1 8 0-3 4-8 6-16 4z'),
    spike: f_('M12 2l3 10-3 10-3-10z') + f_('M2 12l10-3 10 3-10 3z', 0.5),
    flame: f_('M12 2c2 4 6 6 6 11a6 6 0 01-12 0c0-3 2-4 3-7 1 2 2 3 3 3 0-2 0-4 0-7z'),
    chip: f_('M6 6h12v12H6z') + s_('M3 9h3M3 15h3M18 9h3M18 15h3M9 3v3M15 3v3M9 18v3M15 18v3', 1.6),
    clip: f_('M8 3h8v18H8z', 0.85) + s_('M10 7h4M10 11h4M10 15h4', 1.5),
    fiber: s_('M4 6c4 3 12-3 16 0M4 12c4 3 12-3 16 0M4 18c4 3 12-3 16 0'),
    spore: '<circle cx="12" cy="13" r="5" fill="currentColor"/>' + f_('M6 6a1.5 1.5 0 103 0 1.5 1.5 0 10-3 0M15 4a1.5 1.5 0 103 0 1.5 1.5 0 10-3 0M18 10a1.2 1.2 0 102.4 0 1.2 1.2 0 10-2.4 0', 0.6),
    hammer: f_('M4 5h12v5H4z') + f_('M10 10h3v11h-3z', 0.75),
    gem: f_('M7 4h10l4 5-9 12L3 9z') + s_('M3 9h18M12 21L9 9l3-5 3 5z', 1),
    shell: f_('M12 4c6 0 9 5 9 10H3c0-5 3-10 9-10z') + s_('M12 4v10M7 6l2 8M17 6l-2 8', 1.2),
    vial: f_('M10 3h4v6l4 10a2 2 0 01-2 2H8a2 2 0 01-2-2l4-10z'),
    ember: f_('M12 3c3 5 5 7 5 11a5 5 0 01-10 0c0-4 2-6 5-11z', 0.6) + f_('M12 11c1.5 2 2.5 3 2.5 5a2.5 2.5 0 01-5 0c0-2 1-3 2.5-5z'),
    bolt: f_('M13 2L5 14h6l-2 8 8-12h-6z'),
    missile: f_('M18 3l3 3-11 11-3-3z') + f_('M7 14l-4 1 2 2-2 4 4-2 2 2 1-4z', 0.6),
    burst: f_('M12 2l2 6 6-2-3 5 5 3-6 1 1 6-5-4-5 4 1-6-6-1 5-3-3-5 6 2z'),
    scythe: s_('M6 21L14 6', 2.4) + f_('M14 6c3-3 7-3 8 1-3-1-6 0-8 3z'),
    cell: f_('M7 5h10v15H7z', 0.85) + f_('M10 2h4v3h-4z') + s_('M12 9l-2 4h4l-2 4', 1.6),
    eye: f_('M2 12c4-6 16-6 20 0-4 6-16 6-20 0z', 0.5) + '<circle cx="12" cy="12" r="3.4" fill="currentColor"/>',
    flake: s_('M12 3v18M4 7.5l16 9M4 16.5l16-9M10 4l2 2 2-2M10 20l2-2 2 2'),
    ringf: '<circle cx="12" cy="13" r="6" fill="none" stroke="currentColor" stroke-width="3"/>' + f_('M12 2c1.4 2 3 3 3 5a3 3 0 01-6 0c0-2 1.6-3 3-5z'),
    ringi: '<circle cx="12" cy="13" r="6" fill="none" stroke="currentColor" stroke-width="3"/>' + s_('M12 2v8M9 4l6 4M15 4l-6 4', 1.4),
    heart: f_('M12 21l-8-8a5 5 0 017-7l1 1 1-1a5 5 0 017 7z'),
    wire: s_('M3 12l3-3 3 6 3-6 3 6 3-6 3 3'),
    buckler: '<circle cx="12" cy="12" r="8" fill="currentColor" opacity=".85"/>' + s_('M12 4v16M4 12h16', 1.4),
    circuit: s_('M4 6h6v6h6v6h4M10 12H4M16 6h4', 1.8) + f_('M8.5 4.5h3v3h-3zM14.5 10.5h3v3h-3z'),
    pauldron: f_('M3 14c0-6 4-10 9-10s9 4 9 10l-3 2c-1-4-3-6-6-6s-5 2-6 6z'),
    star: f_('M12 2l2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z'),
    cloak: f_('M12 3c4 0 6 4 6 8v10l-3-2-3 2-3-2-3 2V11c0-4 2-8 6-8z', 0.8) + f_('M9 10h2v2H9zM13 10h2v2h-2z', 0.9),
    spiral: s_('M12 12a2 2 0 102-2 4 4 0 10-4 4 6 6 0 106-6 8 8 0 10-8 8'),
    core: f_('M12 3l8 9-8 9-8-9z', 0.85) + f_('M12 8l4 4-4 4-4-4z'),
    nuke: '<circle cx="12" cy="12" r="3" fill="currentColor"/>' + f_('M12 2a10 10 0 018.7 5l-5.2 3a4 4 0 00-3.5-2zM20.7 17a10 10 0 01-17.4 0l5.2-3a4 4 0 007 0zM3.3 7A10 10 0 0112 2v6a4 4 0 00-3.5 2z', 0.75),
    cool: f_('M12 2a7 7 0 017 7c0 3-2 5-3 7h-8c-1-2-3-4-3-7a7 7 0 017-7z', 0.85) + f_('M9 18h6v3H9z'),
    frost: f_('M12 2l2 7 7 3-7 3-2 7-2-7-7-3 7-3z', 0.8) + '<circle cx="12" cy="12" r="2" fill="currentColor"/>',
    dagger: f_('M12 2l2 4v9h-4V6z') + f_('M7 15h10v2H7zM11 17h2v5h-2z', 0.7),
    coil: s_('M8 3h8M8 21h8M8 6c8 0 8 3 0 3s-8 3 0 3 8 3 0 3-8 3 0 3', 1.8),
    rack: f_('M5 3h3v18H5zM16 3h3v18h-3z', 0.6) + f_('M8 7h8v2H8zM8 11h8v2H8zM8 15h8v2H8z'),
    aegis: f_('M12 3l8 4v5c0 5-4 8-8 10-4-2-8-5-8-10V7z', 0.55) + f_('M12 7l4 2v3c0 3-2 5-4 6-2-1-4-3-4-6V9z'),
    mult: s_('M6 6l12 12M18 6L6 18', 3),
    flame2: f_('M12 2c3 4 7 7 7 12a7 7 0 01-14 0c0-3 1-5 3-7 0 2 1 3 2 4 0-4 1-6 2-9z'),
    salvo: f_('M5 4h4v11H5zM10 2h4v13h-4zM15 4h4v11h-4z') + f_('M4 17h16v4H4z', 0.6),
    venom: f_('M12 3c3 5 6 8 6 12a6 6 0 01-12 0c0-4 3-7 6-12z', 0.8) + f_('M10 14a1.5 1.5 0 103 0 1.5 1.5 0 10-3 0'),
    heart2: f_('M12 21l-8-8a5 5 0 017-7l1 1 1-1a5 5 0 017 7z', 0.6) + f_('M12 17l-4-4a2.5 2.5 0 013.5-3.5l.5.5.5-.5A2.5 2.5 0 0116 13z'),
    glass: f_('M8 3h8l-1 7a3 3 0 01-6 0z', 0.6) + s_('M12 13v6M8 21h8M10 5l4 4', 1.6),
    rot: f_('M4 20c0-6 3-10 8-10s8 4 8 10z', 0.6) + f_('M9 6a2 2 0 104 0 2 2 0 10-4 0M14 3a1.4 1.4 0 102.8 0 1.4 1.4 0 10-2.8 0'),
    seal: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2"/>' + f_('M12 6l1.6 4.4L18 12l-4.4 1.6L12 18l-1.6-4.4L6 12l4.4-1.6z'),
    crown: f_('M3 8l4 4 5-7 5 7 4-4-2 11H5z') + s_('M10 12l2 3', 1.2),
    hand: f_('M8 21v-9L5 9a1.4 1.4 0 012-2l2 2V4a1.4 1.4 0 013 0v6h1V3a1.4 1.4 0 013 0v7h1V5a1.4 1.4 0 013 0v10a6 6 0 01-6 6z'),
    syringe: s_('M4 20l4-4M7 13l4 4M8 12l7-7 4 4-7 7zM16 4l4 4M18 2l4 4', 1.8),
    strike: '<circle cx="12" cy="14" r="5" fill="none" stroke="currentColor" stroke-width="2"/>' + f_('M11 2h2v10h-2z') + s_('M7 21l10-14', 1.2),
    ward: f_('M12 3l8 4v5c0 5-4 8-8 10-4-2-8-5-8-10V7z', 0.35) + s_('M12 3l8 4v5c0 5-4 8-8 10-4-2-8-5-8-10V7z', 2),
    dash: f_('M10 6h10l-4 6 4 6H10l-4-6z') + s_('M2 9h4M3 15h3', 1.6),
    decoy: f_('M12 3a3 3 0 110 6 3 3 0 010-6zM7 10h10l-1 11H8z', 0.55) + s_('M5 21h14', 1.4),
    horn: f_('M3 10h4l10-6v16L7 14H3z') + s_('M19 8c2 2 2 6 0 8', 1.6),
  };
  function iconSVG(gly, col, bg, size, border) {
    const sz = size || 28;
    return '<svg viewBox="0 0 28 28" width="' + sz + '" height="' + sz + '" style="color:' + col + ';display:block"><rect x="1" y="1" width="26" height="26" rx="5" fill="' + (bg || '#11141a') + '" stroke="' + (border || col) + '" stroke-opacity=".75" stroke-width="1.4"/><g transform="translate(2 2)">' + (GLY[gly] || GLY.core) + '</g></svg>';
  }
  const itemIcon = (idx, size) => { const it = ITEMS[idx], R_ = RAR[it.r] || { col: '#777', dim: '#222' }; return iconSVG(it.ic, R_.col, '#11141a', size, R_.col); };
  const equipIcon = (idx, size) => iconSVG(EQUIP[idx].ic, '#f0a040', '#14110c', size, '#f0a040');
  /* 생존자 · 적 실루엣 */
  const SV_SIL = 'M12 2.5a2.6 2.6 0 110 5.2 2.6 2.6 0 010-5.2zM8 8.6h8l1.4 7h-2.2L14 22h-4l-1.2-6.4H6.6z';
  const EN_SIL = {
    lunge: 'M4 15c3-5 13-5 16 0l2 4-3-2-2 3-2-3-2 3-2-3-2 3-2-3-3 2z', melee: 'M10 3a3 3 0 114 0l1 3h3l-2 8 1 8h-3l-2-6-2 6H7l1-8-2-8h3z', dive: 'M3 10l7 1 2-5 2 5 7-1-6 4 1 7-4-4-4 4 1-7z',
    orb: 'M12 3a7 7 0 017 7c0 3-1 4-3 5v4l-2-2-2 2-2-2-2 2v-4c-2-1-3-2-3-5a7 7 0 017-7z', laser: 'M4 10h16v5H4zM8 15l-2 5M16 15l2 5M10 6h4v4h-4z', burst: 'M8 4h8v7H8zM9 11l-4 10M15 11l4 10M12 11v10', fuse: 'M7 9a5 5 0 1110 0v5H7zM6 14h12l-2 6H8z',
    charge: 'M4 10c0-4 3-6 7-6h4l5-2-2 4c2 1 3 3 3 5v5H4zM6 16v5M10 16v5M15 16v5M19 16v5', burrow: 'M11 22c0-8 2-15 6-19-1 6-2 13 0 19z', spit: 'M2 12l6-3 4-5 2 5 8 1-8 3-2 6-3-5z', slam: 'M9 2h6v5l4 2v8h-3v5h-3v-5h-2v5H8v-5H5V9l4-2z', mortar: 'M4 8h16v9H4zM6 17v4M18 17v4M14 4h6v4h-6z',
  };

  /* ======================= 규칙 · 도감 ======================= */
  const RULES = [
    { h: '목표', p: ['외계 구역에 내려 적을 처치하고 자금을 모아 상자 · 제단을 열어 아이템을 쌓음.', '구역마다 전송기를 찾아 활성화 → 충전 범위(반경 16m) 안에서 버티며 보스 처치 → 다음 구역.', '다섯 구역을 지나면 처음 구역 종류로 돌아가 순환. 순환할수록 적이 강해짐.', '「원정 길이」가 정해져 있으면 마지막 구역의 전송기로 귀환하면 성공. 무한 순환은 5구역마다 전송기 옆 「귀환 신호」로 끝낼 수 있음. 전원이 쓰러지면 실패.'] },
    { h: '시간과 난이도', p: ['원정 시간이 흐를수록 화면 위 난이도 단계가 오름(고요 → 동요 → 경계 → 위험 → 격화 → 치명 → 붕괴 → 종말 → 심연).', '난이도 계수 = (인원 계수 + 분 × 0.0506 × 난이도 값 × 인원^0.2) × 1.15^(지난 구역 수). 적 레벨 · 체력 · 피해와 상자 가격이 계수에 따라 오름.', '오래 머물수록 아이템은 늘지만 적도 강해짐 — 균형이 핵심.'] },
    { h: '아이템', p: ['상한 없이 중첩. 설명의 괄호 수치는 「추가 1개당」.', '확률 효과는 공격마다의 「효과 계수」를 곱함(연사 1.0 · 유탄 0.8 · 장판류 0.2 등).', '등급: 일반(흰색) · 희귀(초록) · 전설(빨강) · 보스(노랑, 보스 처치 보상) · 저주(파랑, 장점과 단점이 함께 있음 — 균열 포드에서 균열 파편으로).', '장비(주황)는 1개만 지님. 장비 보관함에서 교체.'] },
    { h: '상호작용', p: Object.keys(IA).map((k) => IA[k].nm + ' — ' + IA[k].d).concat(['가격은 구역 시작 시점의 난이도 계수에 맞춰 정해짐.']) },
    { h: '조작 — PC', p: ['WASD 이동 · Space 점프 · 마우스를 움직이면 바로 조준(Esc: 마우스 풀기).', '왼쪽 클릭 주무기 · 오른쪽 클릭 보조 · Shift 유틸 · R 특수 · E 상호작용 · Q 장비 · Tab 소지품.', '게임패드: 왼쪽 스틱 이동 · 오른쪽 스틱 조준 · RT 주무기 · LT 보조 · B 유틸 · Y 특수 · X 상호작용 · LB 장비 · A 점프. 키는 「⌨ 조작 설정」에서 변경.'] },
    { h: '조작 — 모바일(가로)', p: ['왼쪽 아래 끌기 이동 · 오른쪽 빈 화면 끌기 조준.', '오른쪽 버튼: 주무기(크게) · 보조 · 유틸 · 특수 · 점프 · 장비. 상호작용 버튼은 물건 가까이에서 나타남.', '조준 보조: 화면 가운데 가까운 적을 자동으로 겨눔. 「자동 사격」을 켜면 겨눈 적이 있을 때 주무기 자동 발사.'] },
    { h: '생존자 (5)', p: SURV.map((s) => s.nm + ' — ' + s.d + ' 스킬: ' + s.sk.map((k) => k[0]).join(' · ')).concat(['모든 생존자 처음부터 사용 가능. 같은 생존자를 여럿이 골라도 됨.']) },
    { h: '적과 예고', p: ['공격 전에 예고가 보임: 바닥의 붉은 원 · 띠, 조준선, 몸의 빛. 예고가 끝나는 순간 범위 안이면 피해.', '정예(작열 · 한랭 · 과전)는 체력 4배 · 피해 2배와 특수 효과. 원정 후반이나 3구역부터 나타남.', '보스 4종은 전송기를 켜면 나타나며 처치 시 아이템 보상(15% 확률로 그 보스의 보스 아이템).'] },
    { h: '협동 · 쓰러짐', p: ['1~4명. 온라인 · LAN은 기기마다 한 명. 빈자리는 AI 동료(자리마다 쉬움 · 보통 · 어려움).', '처치 자금은 살아 있는 모두가 똑같이 받음. 상자에서 나온 아이템은 연 사람의 것.', '쓰러지면 관전 — 다음 구역에서 복귀. 소생 기억체가 있으면 그 자리에서 즉시 소생.', 'AI 동료는 상황에 따라 엄호 거리 · 회피 · 상자 선택 · 장비 사용을 판단하고, 동료마다 성향(욕심 · 도박 · 위험 감수 · 선호 거리)이 다름. 사람이 함께하면 전송기는 사람이 켤 때까지 기다리는 편.'] },
    { h: '그래픽', p: ['설정 화면 「그래픽 품질(이 기기)」: 낮음(폰 기본) · 보통 · 높음. 끊기면 낮음 권장.'] },
    { h: '만든 사람', p: ['게임 설계 · 코드 · 지형 · 아이콘 · 글: 한판 라운지(직접 제작).', '애니메이션 모델: Quaternius (quaternius.com) — 생존자 몸(SWAT · Astronaut · Worker · Punk · Hoodie Character), 적(Spider · Wasp · Ghost Skull · Robot Enemy 계열 · Alien · Blue Demon · Tentacle · Dragon). poly.pizza 배포 CC0 1.0. 색 · 크기 · 동작 선택은 게임에 맞게 가공.', '3D 엔진: three.js (MIT). 효과음 · 음악: 앱 합성음.', '체계 참고: Risk of Rain 2 (Hopoo Games) — 장르 체계만 참고, 이름 · 아이템 · 적 · 글 · 그림은 쓰지 않음. 자세한 출처: app/assets/itemstack/CREDITS.txt'] },
  ];
  const CONTROLS = [
    { id: 'up', label: '앞으로', keys: ['KeyW', 'ArrowUp'], pad: ['ly-', 'up'] },
    { id: 'down', label: '뒤로', keys: ['KeyS', 'ArrowDown'], pad: ['ly+', 'down'] },
    { id: 'left', label: '왼쪽', keys: ['KeyA', 'ArrowLeft'], pad: ['lx-', 'left'] },
    { id: 'right', label: '오른쪽', keys: ['KeyD', 'ArrowRight'], pad: ['lx+', 'right'] },
    { id: 'jump', label: '점프', keys: ['Space'], pad: ['a'] },
    { id: 'prim', label: '주무기(마우스 왼쪽과 같음)', keys: ['KeyJ'], pad: ['rt'] },
    { id: 'sec', label: '보조(마우스 오른쪽과 같음)', keys: ['KeyK'], pad: ['lt'] },
    { id: 'util', label: '유틸', keys: ['ShiftLeft', 'ShiftRight'], pad: ['b'] },
    { id: 'spec', label: '특수', keys: ['KeyR'], pad: ['y'] },
    { id: 'use', label: '상호작용', keys: ['KeyE'], pad: ['x'] },
    { id: 'equip', label: '장비', keys: ['KeyQ'], pad: ['lb'] },
    { id: 'inv', label: '소지품 보기', keys: ['Tab'], pad: ['back'] },
    { id: 'aimL', label: '조준 왼쪽', keys: [], pad: ['rx-'] },
    { id: 'aimR', label: '조준 오른쪽', keys: [], pad: ['rx+'] },
    { id: 'aimU', label: '조준 위', keys: [], pad: ['ry-'] },
    { id: 'aimD', label: '조준 아래', keys: [], pad: ['ry+'] },
  ];
  const enIcon = (T, col) => '<svg viewBox="0 0 24 24" width="28" height="28" style="display:block"><rect width="24" height="24" rx="5" fill="#15121a"/><path d="' + (EN_SIL[T.at] || EN_SIL.slam) + '" fill="' + col + '"/></svg>';
  const codex = [
    { h: '생존자', p: ['모두 처음부터 사용 가능. 레벨이 오를 때마다 체력 +30% · 피해 +20%(기본값 기준).'], rows: SURV.map((s) => ({ icon: '<svg viewBox="0 0 24 24" width="28" height="28" style="display:block"><rect width="24" height="24" rx="5" fill="#15121a"/><path d="' + SV_SIL + '" fill="' + s.col + '"/></svg>', name: s.nm, tag: s.role + ' · 체력 ' + s.hp + ' · 방어 ' + s.armor, desc: s.d + ' — ' + s.sk.map((k, i) => ['주무기', '보조', '유틸', '특수'][i] + ' 「' + k[0] + '」 ' + k[3] + (i ? ' 재사용 ' + k[1] + '초' + (k[2] > 1 ? ' · 충전 ' + k[2] : '') : '')).join(' / ') })) },
  ];
  for (const r of RORDER) codex.push({ h: RAR[r].nm + ' 아이템', p: [{ w: '상자에서 가장 흔함.', g: '대형 상자 · 보스 보상.', r: '드묾. 상자 1% · 대형 상자 20% · 봉인 금고 · 확률 제단.', b: '보스 처치 시 15% 확률로 그 보스의 아이템.', l: '균열 포드(균열 파편 1개). 장점과 단점이 함께 있음.' }[r]], rows: POOL[r].map((i) => ({ icon: itemIcon(i, 28), name: ITEMS[i].nm, tag: RAR[r].nm, desc: ITEMS[i].d })) });
  codex.push({ h: '장비', p: ['1개만 지님. Q · 장비 버튼으로 사용 후 재사용 대기.'], rows: EQUIP.map((e, i) => ({ icon: equipIcon(i, 28), name: e.nm, tag: '장비 · ' + e.cd + '초', desc: e.d })) });
  codex.push({ h: '적', p: ['레벨 = 1 + (난이도 계수 − 인원 계수) ÷ 0.33. 레벨마다 체력 +30% · 피해 +20%.'], rows: ENEMY.map((e) => ({ icon: enIcon(e, '#c86a5a'), name: e.nm, tag: (e.fly ? '공중' : '지상') + ' · 체력 ' + e.hp + ' · 피해 ' + e.dmg + ' · 등장 ' + e.lv + '레벨~', desc: e.d })) });
  codex.push({ h: '보스', p: ['전송기를 켜면 출현. 인원이 많을수록 체력 증가, 순환할수록 마릿수 증가.'], rows: BOSS.map((b) => ({ icon: enIcon({ at: b.fly ? 'spit' : 'slam' }, '#e8c547'), name: b.nm, tag: '보스 · 체력 ' + b.hp + ' · 보상 「' + ITEMS[IX[b.item]].nm + '」', desc: b.d })) });
  codex.push({ h: '정예 · 구역', p: ['구역은 원정마다 순서가 섞이고(「첫 구역」 옵션), 지형은 매번 새로 생성.'], rows: ELITE.map((e) => ({ icon: '<svg viewBox="0 0 24 24" width="28" height="28" style="display:block"><rect width="24" height="24" rx="5" fill="#15121a"/><circle cx="12" cy="12" r="7" fill="none" stroke="' + e.col + '" stroke-width="3"/></svg>', name: '정예 · ' + e.nm, tag: '정예', desc: e.d }))
    .concat(THEMES.map((t) => ({ icon: '<svg viewBox="0 0 24 24" width="28" height="28" style="display:block"><rect width="24" height="24" rx="5" fill="#' + t.sky[1].toString(16).padStart(6, '0') + '"/><path d="M0 18l6-6 4 3 6-7 8 10v6H0z" fill="#' + t.cliff.toString(16).padStart(6, '0') + '"/><circle cx="17" cy="6" r="3" fill="#' + t.planet.toString(16).padStart(6, '0') + '"/></svg>', name: t.nm, tag: '구역', desc: '출현 적: ' + t.enemies.map((k) => ENEMY[EKX[k]].nm).join(' · ') }))) });

  /* ======================= 홈 미리보기(640×360) ======================= */
  function preview(cv) {
    const g = cv.getContext('2d'), w = cv.width, h = cv.height, R = prng(20261119);
    const sky = g.createLinearGradient(0, 0, 0, h); sky.addColorStop(0, '#05070e'); sky.addColorStop(0.55, '#2b2440'); sky.addColorStop(0.75, '#6a3a3a'); sky.addColorStop(1, '#140c10'); g.fillStyle = sky; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 90; i++) { g.fillStyle = 'rgba(255,255,255,' + (0.2 + R() * 0.5) + ')'; g.fillRect(R() * w, R() * h * 0.45, 1.2, 1.2); }
    // 큰 행성
    const px = w * 0.72, py = h * 0.26, pr = h * 0.2;
    const pg = g.createRadialGradient(px - pr * 0.4, py - pr * 0.4, pr * 0.1, px, py, pr); pg.addColorStop(0, '#e6a87a'); pg.addColorStop(0.7, '#8a4a3a'); pg.addColorStop(1, '#2a1418');
    g.fillStyle = pg; g.beginPath(); g.arc(px, py, pr, 0, TAU); g.fill();
    g.strokeStyle = 'rgba(255,210,170,.35)'; g.lineWidth = 2; g.beginPath(); g.ellipse(px, py, pr * 1.7, pr * 0.32, -0.25, 0, TAU); g.stroke();
    // 고원 실루엣(겹)
    const layer = (y0, amp, col, rim) => { g.fillStyle = col; g.beginPath(); g.moveTo(0, h); let x = 0; g.lineTo(0, y0); while (x < w) { const nx = x + 30 + R() * 70, ny = y0 - (R() < 0.45 ? amp * (0.4 + R() * 0.6) : R() * amp * 0.25); g.lineTo(x + 6, ny); g.lineTo(nx - 6, ny); g.lineTo(nx, y0 - R() * amp * 0.15); x = nx; } g.lineTo(w, h); g.fill(); if (rim) { g.strokeStyle = rim; g.lineWidth = 1.2; g.stroke(); } };
    layer(h * 0.62, h * 0.18, '#1d1626', 'rgba(255,170,130,.25)');
    const fog = g.createLinearGradient(0, h * 0.5, 0, h * 0.8); fog.addColorStop(0, 'rgba(120,70,80,0)'); fog.addColorStop(1, 'rgba(120,70,80,.45)'); g.fillStyle = fog; g.fillRect(0, h * 0.5, w, h * 0.3);
    layer(h * 0.8, h * 0.16, '#100c14', 'rgba(140,190,255,.3)');
    // 전송기 빛기둥
    const bx = w * 0.3; const bg = g.createLinearGradient(bx - 12, 0, bx + 12, 0); bg.addColorStop(0, 'rgba(255,200,120,0)'); bg.addColorStop(0.5, 'rgba(255,210,140,.55)'); bg.addColorStop(1, 'rgba(255,200,120,0)');
    g.fillStyle = bg; g.fillRect(bx - 12, 0, 24, h * 0.66);
    g.fillStyle = '#ffd59a'; g.beginPath(); g.ellipse(bx, h * 0.66, 26, 6, 0, 0, TAU); g.fill();
    // 생존자 실루엣 · 적
    const fig = (x, y, s, col) => { g.save(); g.translate(x, y); g.scale(s / 24, s / 24); g.translate(-12, -22); g.fillStyle = col; g.fill(new Path2D(SV_SIL)); g.restore(); };
    fig(w * 0.5, h * 0.93, 70, '#0a0a10'); fig(w * 0.58, h * 0.95, 64, '#0a0a10');
    g.strokeStyle = 'rgba(140,200,255,.6)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(w * 0.5 + 12, h * 0.8); g.lineTo(w * 0.86, h * 0.7); g.stroke();
    for (const [x, y, s] of [[0.86, 0.72, 46], [0.8, 0.76, 30], [0.93, 0.78, 34]]) { g.save(); g.translate(w * x, h * y); g.scale(s / 24, s / 24); g.translate(-12, -12); g.fillStyle = '#05040a'; g.fill(new Path2D(EN_SIL.lunge)); g.restore(); g.fillStyle = 'rgba(255,90,60,.9)'; g.fillRect(w * x - 2, h * y - s * 0.12, 4, 2); }
    // 아이템 막대
    const its = ['crit', 'chain', 'behemoth', 'missile', 'gas', 'aspd'];
    its.forEach((k, i) => { const it = ITEMS[IX[k]], c = RAR[it.r].col; g.fillStyle = 'rgba(10,12,18,.8)'; g.strokeStyle = c; g.lineWidth = 2; g.beginPath(); g.rect(18 + i * 40, h - 52, 32, 32); g.fill(); g.stroke(); g.save(); g.translate(18 + i * 40 + 4, h - 48); g.fillStyle = c; g.strokeStyle = c; const tmp = GLY[it.ic].match(/d="([^"]+)"/g) || []; for (const m of tmp) { const p = new Path2D(m.slice(3, -1)); if (/stroke=/.test(GLY[it.ic]) && !/fill="currentColor"/.test(GLY[it.ic])) g.stroke(p); else g.fill(p); } g.restore(); });
  }

  /* ======================= 그래픽 단계 · 불러오기 ======================= */
  const GTIERS = [
    { id: 'low', nm: '낮음', tip: '폰 권장 — 그림자 없음 · 화면 배율 낮게 · 가까운 적만 정밀 동작', pr: 1, shadow: 0, aa: false },
    { id: 'mid', nm: '보통', tip: '가까운 곳 그림자 · 계단 현상 줄임', pr: 1.5, shadow: 1024, aa: true },
    { id: 'high', nm: '높음', tip: 'PC 권장 — 부드러운 그림자 · 고운 화면 · 식물 많이', pr: 2, shadow: 2048, aa: true },
  ];
  const store = { get(k, d) { try { const v = localStorage.getItem('itemstack.' + k); return v == null ? d : v; } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('itemstack.' + k, v); } catch (e) {} } };
  function touchOnly() { try { if (L && L.touchOnly) return !!L.touchOnly(); return typeof matchMedia === 'function' && matchMedia('(pointer:coarse)').matches; } catch (e) { return false; } }   // 갤럭시(S펜)는 any-pointer:fine도 true — 코어 판정(주 포인터·실제 터치)을 따른다
  function gfxTier() { const v = store.get('gfx', ''); return GTIERS.some((t) => t.id === v) ? v : (touchOnly() ? 'low' : 'mid'); }
  const scripts = {};
  function loadScript(src) {
    if (!scripts[src]) scripts[src] = new Promise((ok, no) => {
      const el = document.createElement('script'); el.src = src; el.async = true;
      el.onload = () => ok(); el.onerror = () => { delete scripts[src]; no(new Error('불러오기 실패: ' + src)); };
      document.head.appendChild(el);
    });
    return scripts[src];
  }
  function loadCore() { return (G.THREE ? Promise.resolve() : loadScript('assets/hyperrace/lib/three.min.js')).then(() => loadScript('assets/itemstack/view.js')); }
  function loadPack(key) { if (G.IS_PACK && G.IS_PACK[key]) return Promise.resolve(); return loadScript('assets/itemstack/pk_' + key + '.js'); }
  function webglOK() { try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch (e) { return false; } }

  const API = { DT, RW, TPR, MAXE, ITEMS, IX, NIT, RAR, RORDER, POOL, EQUIP, EX, SURV, SVX, ENEMY, BOSS, ELITE, etype, THEMES, TIERS, IA, GTIERS, GLY, LENS,
    clamp, lerp, hyp, prng, shuffle, genStage, hOf, makeWorld, worldStep, stepPlayer, aiInput, habits, calcStats, coeff, coeffOf, tierOf, enemyLv, nearIA, iaLabel, lastStage,
    init, pickSv, forcePick, endStage, result, hint, packHost, applyHost, packGuest, ingestGuest, itemStr, itemArr, itemCount, itemIcon, equipIcon, iconSVG, xpNeed, skCd, skMax,
    spawnEnemy, startTele, store, gfxTier, touchOnly, loadPack, IDLE, muzzle, aimDir, rayCast, coneTarget, ACTK, PRK, FXK, rtOf, alivePl, enemyById, segDist, SV_SIL, cellOf, flowField, NN };

  function mount(root, api) {
    const h = L.h;
    let view = null, dead = false, last = null, lastPrev = null;
    const box = h('div', { style: { position: 'absolute', inset: '0', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '12px', background: 'radial-gradient(circle at 50% 40%,#2a2034,#07060b)', color: 'var(--ink)', zIndex: 5, textAlign: 'center', padding: '16px' } });
    const t1 = h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '26px', letterSpacing: '2px' }, text: '균열 원정대' });
    const t2 = h('div', { class: 'muted', style: { fontSize: '13px' }, text: '3D 엔진 불러오는 중' });
    const bar = h('div', { style: { width: '220px', height: '4px', borderRadius: '2px', background: 'rgba(255,255,255,.12)', overflow: 'hidden' } }, h('div', { style: { width: '8%', height: '100%', background: '#d8b070', transition: 'width .2s' } }));
    box.append(t1, t2, bar);
    root.append(box);
    const prog = (f, txt) => { if (bar.firstChild) bar.firstChild.style.width = Math.round(clamp(f, 0.05, 1) * 100) + '%'; if (txt) t2.textContent = txt; };
    if (!webglOK()) prog(1, '이 기기(브라우저)에서는 3D 그래픽(WebGL)을 켤 수 없어요.');
    else loadCore().then(() => {
      if (dead) return;
      prog(0.3, '모델 불러오는 중');
      view = G.IS_VIEW.mount(root, api, API, { progress: prog, ready() { box.remove(); } });
      if (last) view.update(last, lastPrev);
    }).catch((e) => { prog(1, '3D 파일을 불러오지 못했어요. (' + (e && e.message || e) + ')'); });
    return {
      update(s, p) { last = s; lastPrev = p; if (view) view.update(s, p); },
      destroy() { dead = true; if (view) view.destroy(); box.remove(); },
      pause() { if (view && view.pause) view.pause(); },
      resume() { if (view && view.resume) view.resume(); },
    };
  }

  const ICON = '<path d="M28 4 L33 20 L28 26 L23 20 Z" fill="currentColor"/><path d="M28 26 L31 40 L28 52 L25 40 Z" fill="currentColor" opacity=".55"/><rect x="6" y="38" width="12" height="12" rx="2" fill="currentColor"/><rect x="38" y="38" width="12" height="12" rx="2" fill="currentColor"/><rect x="6" y="24" width="12" height="12" rx="2" fill="currentColor" opacity=".7"/><rect x="38" y="24" width="12" height="12" rx="2" fill="currentColor" opacity=".7"/><rect x="38" y="10" width="12" height="12" rx="2" fill="currentColor" opacity=".45"/>';

  if (L) L.register({
    id: 'itemstack', name: '균열 원정대', tag: '3D 협동 슈터 로그라이크', cat: '아케이드', icon: ICON, tint: '#2a1a2e',
    blurb: '1~4명이 외계 구역을 돌며 시간이 갈수록 강해지는 적을 상대하는 3D 협동 슈터. 상자 · 제단에서 상한 없이 중첩되는 아이템 60종을 모아 전송기를 충전하고 보스를 쓰러뜨려 다음 구역으로.',
    time: '15–40분', landscape: true, realtime: true, aiDelay: 0, mood: 'tension', ambient: 'wind', sidePanel: false, undo: false,
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2,
    options: [
      { id: 'len', label: '원정 길이', tip: '몇 구역을 지나면 귀환(성공)인지. 무한 순환은 5구역마다 「귀환 신호」로 끝낼 수 있음. 1구역은 짧은 판.', choices: [{ v: 'inf', label: '무한 순환' }, { v: '5', label: '5구역' }, { v: '3', label: '3구역' }, { v: '1', label: '1구역(짧게)' }], def: 'inf' },
      { id: 'diff', label: '난이도', tip: '시간에 따른 난이도 상승 속도. 표준 = 3.2분마다 한 단계.', choices: [{ v: 'calm', label: '완만', tip: '상승 속도 ×0.5' }, { v: 'std', label: '표준' }, { v: 'harsh', label: '가혹', tip: '상승 속도 ×1.5' }], def: 'std' },
      { id: 'start', label: '첫 구역', tip: '첫 구역 종류. 무작위면 원정마다 다름(지형은 언제나 새로 생성).', choices: [{ v: 'rnd', label: '무작위' }].concat(THEMES.map((t) => ({ v: t.k, label: t.nm }))), def: 'rnd' },
    ],
    setupExtra(opts, ctx) {
      const wrap = L.h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', alignItems: 'center', margin: '6px 0' } });
      const draw = () => {
        wrap.innerHTML = '';
        wrap.append(L.h('span', { class: 'muted', style: { fontSize: '13px', margin: '0 4px 0 2px' }, text: '그래픽 품질(이 기기)' }));
        for (const t of GTIERS) wrap.append(L.h('button', { class: 'btn sm' + (gfxTier() === t.id ? ' primary' : ''), title: t.tip, style: { minHeight: '44px' }, text: t.nm, onclick() { store.set('gfx', t.id); draw(); } }));
        // 마우스 감도(이 기기, PC) — 시점 돌리기
        if (!touchOnly()) { const sv = +store.get('sens', 1); wrap.append(L.h('span', { class: 'muted', style: { fontSize: '13px', margin: '0 4px 0 10px' }, text: '마우스 감도' })); for (const [v, nm] of [[0.6, '낮게'], [1, '보통'], [1.5, '높게'], [2.2, '아주 높게']]) wrap.append(L.h('button', { class: 'btn sm' + (Math.abs(sv - v) < 0.01 ? ' primary' : ''), style: { minHeight: '44px' }, text: nm, onclick() { store.set('sens', v); draw(); } })); }
      };
      draw(); void opts; void ctx;
      return wrap;
    },
    controls: CONTROLS,
    quick: ['적을 처치해 자금 획득 → 상자 · 제단에서 아이템 수집(상한 없이 중첩)', '전송기 활성화 → 범위 안에서 충전하며 보스 처치 → 다음 구역', '시간이 흐를수록 난이도 단계 상승 — 머무는 시간과 아이템 사이의 균형', '모바일: 왼쪽 끌기 이동 · 오른쪽 끌기 조준 · 오른쪽 버튼 스킬 / PC: WASD · 마우스 · Shift · R · E · Q'],
    rules: RULES,
    codex,
    preview,
    hint,
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result,
    mount,
    _t: API,
  });
  G.ITEMSTACK = API;
  if (typeof module === 'object' && module) module.exports = API;
})();
