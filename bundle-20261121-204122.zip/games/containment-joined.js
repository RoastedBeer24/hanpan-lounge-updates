(function () {
  'use strict';
  const L = window.Lounge, U = L.util || {};
  const ID = 'containment', AS = 'assets/containment/';
  const ART = true;    // false면 코드 도형만 쓰고 그림 파일을 찾지 않는다
  /* 그림 크게 보기 — 게임 안과 도감(게임 밖)에서 같이 쓴다. 아무 데나 누르면 닫힌다 */
  const zoom = (src, cap) => {
    const d = document, o = d.createElement('div'), im = d.createElement('img');
    o.style.cssText = 'position:fixed;inset:0;z-index:9999;background:rgba(6,8,10,.92);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:14px;cursor:zoom-out';
    im.alt = ''; im.src = src; im.style.cssText = 'max-width:100%;max-height:calc(100% - 44px);border-radius:10px;object-fit:contain;box-shadow:0 0 0 1px #33404a';
    o.append(im);
    if (cap) { const c = d.createElement('div'); c.textContent = cap; c.style.cssText = 'color:#f0ead8;font-size:15px;text-align:center'; o.append(c); }
    const close = () => { o.remove(); };
    o.onclick = close; o.oncontextmenu = (e) => { e.preventDefault(); close(); }; d.body.append(o);
  };
  if (L) L._ctZoom = zoom;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const rnd = (n) => Math.floor(Math.random() * n);
  const pickOf = (a) => a[rnd(a.length)];
  const shuf = (a) => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1), t = a[i]; a[i] = a[j]; a[j] = t; } return a; };
  const r1 = (v) => Math.round(v * 10) / 10;

  /* ================= 자료(고정) ================= */
  const STN = ['담력', '신중', '공감', '절제'];
  const STD = ['억제 작업과 제압, 최대 체력.', '관찰 작업.', '교감 작업과 공황 직원 진정.', '급양 작업, 최대 정신.'];
  const WORKS = [
    { id: 'obs', n: '관찰', st: 1, c: '#7fa3c7', d: '격리창 너머에서 살피고 기록한다. 관찰 수치를 절반 더 얻는다.' },
    { id: 'tlk', n: '교감', st: 2, c: '#69b3a6', d: '말을 걸거나 곁에 머문다.' },
    { id: 'feed', n: '급양', st: 3, c: '#d2b04c', d: '이형체가 요구하는 것을 정해진 양만큼 넣어 준다.' },
    { id: 'sup', n: '억제', st: 0, c: '#c8695c', d: '구속구와 격벽을 조여 힘으로 눌러 둔다.' },
  ];
  /* 등급 5단계(사용자 지정 이름). 등급에 걸린 수치는 전부 이 표 한 곳:
     en 작업 에너지(8칸 모두 성공) · dmg 작업 피해 기준 · atk 탈주체 공격 기준 · hp 탈주체 체력 · hit 한 번에 치는 직원 수 · pen 칸 성공률 감점
     pc/rc/bc 열람 비용(선호 · 수칙 · 탈주 정보) · w/a 추출 비용 [관찰, 에너지] · lim 추출 한도 */
  const GR = [null,
    { n: 'ZAYIN', c: '#7fb56b', en: 5, dmg: 6, atk: 7, hp: 42, hit: 1, pen: 0, pc: 2, rc: 5, bc: 3, w: [7, 10], a: [9, 12], lim: 3 },
    { n: 'TETH', c: '#5f9fd6', en: 7, dmg: 9, atk: 10, hp: 62, hit: 1, pen: 0.045, pc: 2, rc: 6, bc: 3, w: [9, 13], a: [11, 15], lim: 3 },
    { n: 'HE', c: '#d2b04c', en: 10, dmg: 12, atk: 13, hp: 84, hit: 2, pen: 0.09, pc: 3, rc: 8, bc: 4, w: [12, 17], a: [14, 19], lim: 2 },
    { n: 'WAW', c: '#a878d8', en: 14, dmg: 16, atk: 17, hp: 108, hit: 2, pen: 0.135, pc: 4, rc: 10, bc: 5, w: [15, 22], a: [17, 24], lim: 2 },
    { n: 'ALEPH', c: '#d0505a', en: 19, dmg: 21, atk: 22, hp: 134, hit: 3, pen: 0.18, pc: 5, rc: 12, bc: 6, w: [18, 28], a: [20, 30], lim: 1 },
  ];
  const TIER = GR, GRN = {};
  GR.forEach((g, i) => { if (g) GRN[g.n] = i; });
  const X_COST = [16, 30], X_MIN = 3;   // 장신구 [관찰, 에너지] · 장신구가 나오는 가장 낮은 등급(HE)
  const E_OUT = GR.map((g) => (g ? g.en : 0)), DMG = GR.map((g) => (g ? g.dmg : 0)), BR_ATK = GR.map((g) => (g ? g.atk : 0));
  const PF_P = [0.22, 0.46, 0.68], PF_N = ['기피', '보통', '선호'];
  const GRADE = ['나쁨', '보통', '좋음'];
  const DTN = { h: '체력', s: '정신', b: '체력 · 정신' };
  /* 시간: 1틱 = 0.25초. 하루 = 6차 × 20초(정규 근무). 작업 = 결과 칸 8개 */
  const TK = 0.25, SEG = 80, TURNS = 6, NB = 8, BOX_T = 5, GOOD = 6, BAD = 3, BOXD = 0.16;
  const SPD = 23, LIFT = 5, PANIC = 3;            // 걷기 px/틱(초당 92px) · 승강기 한 층 틱 · 공황 차 수
  const HIT_T = 8, HIT_K = 0.3, BR_T = 12, BR_K = 0.5, BR_SPD = 8, REACH = 30;
  /* 시설 치수(로직과 화면이 같이 씀): 층(= 구역)마다 격리실 PER칸, 왼쪽 승강기, 맨 위층 왼쪽 휴게실.
     PER · FW는 판의 길이에 따라 달라서 setLay(S)가 맞춘다(판 하나만 도는 게임이라 모듈 변수로 둔다). */
  const RW = 150, RH = 124, RP = 162, X0 = 86, CH = 58, FH = 198, EX = 42, LX0 = -196, LX1 = -16;
  let PER = 4, FW = X0 + PER * RP;
  const LEN = { S: { days: 5, floors: 2, per: 4, qm: 1.2, n: '짧게' }, M: { days: 8, floors: 2, per: 6, qm: 0.93, n: '보통' }, L: { days: 12, floors: 3, per: 6, qm: 1, n: '길게' } };
  const setLay = (S) => { PER = (S && S.per) || 4; FW = X0 + PER * RP; };
  const openDay = (f) => (f <= 0 ? 1 : f * PER - 1);   // 그 층이 열리는 날(이형체 수 = 2 + 날이 위층들을 다 채운 다음 날)
  const ZONE = ['접수 구역', '보존 구역', '심층 구역', '봉인 구역'];
  const roomF = (ri) => Math.floor(ri / PER), roomX = (ri) => X0 + (ri % PER) * RP + RW / 2;
  const ALERT = [{ n: '평시', c: '#69b3a6' }, { n: '주의', c: '#d2b04c' }, { n: '경계', c: '#dd7d43' }, { n: '비상', c: '#d0505a' }];

  /* 키워드 — 장비 · 특성의 반복 효과. 「키워드: 수치」 */
  const KW = {
    pow: { n: '위력', d: '제압 때 주는 피해 +N.' },
    grd: { n: '방호', d: '받는 체력 피해 −N%.' },
    shd: { n: '차폐', d: '받는 정신 피해 −N%.' },
    abs: { n: '흡수', d: '제압 중 8초마다 체력 +N.' },
    clm: { n: '진정', d: '작업이 나쁨이 아니면 정신 +N.' },
    vit: { n: '견고', d: '최대 체력 +N.' },
    mnd: { n: '평정', d: '최대 정신 +N.' },
    foc: { n: '집중', d: '적힌 작업의 성공률 +N%p.' },
    rec: { n: '기록', d: '작업마다 관찰 수치 +N.' },
    hrv: { n: '수확', d: '작업으로 얻는 에너지 +N%.' },
    spd: { n: '신속', d: '이동 속도 +N%.' },
    hst: { n: '숙련', d: '작업 속도 +N%.' },
    reg: { n: '재생', d: '차가 넘어갈 때마다 체력 +N.' },
    wil: { n: '의지', d: '차가 넘어갈 때마다 정신 +N.' },
    lck: { n: '가호', d: '하루 한 번, 체력이 0이 될 피해를 1로 버틴다.' },
  };
  const kwText = (k) => (k[0] === 'foc' ? '집중(' + WORKS[k[2]].n + '): ' + k[1] : k[0] === 'lck' ? KW.lck.n : KW[k[0]].n + ': ' + k[1]);
  const SLOT_N = { w: '무기', a: '방호구', x: '장신구' }, SLOT_K = { w: 'wp', a: 'ar', x: 'ac' };

  /* ================= 등록부 (docs/CONTAINMENT.md) =================
     요소는 전부 여기 등록된 것으로 돌아간다: 수칙 ctRule · 탈주 양상 ctBreach · 이변 ctBurst · 이형체 ctAb(+ 그 장비) · 사건 ctEvent · 강화 ctUp.
     등록 조각(rules · gauge · ab_* · events · upgrades)은 이 조각 바로 뒤에 불린다 → 불러올 때 바로 계산되는 값에는 이 조각의 이름만 쓰고,
     시뮬 쪽 이름(bump · hurt · evAdd · passiveHit …)은 갈고리(함수) 몸 안에서만 쓴다. 잘못 쓴 요소는 ctWarn으로 콘솔에 알리고 건너뛴다. */
  const ENT = [], ENT_ID = {}, RULES = {}, BK = {}, BURST = {}, GEAR = {}, EVENTS = [], UPS = [], CT_WARN = [];
  const ctWarn = (m) => { CT_WARN.push(m); try { console.warn('[격리 시설 관리] ' + m); } catch (e) {} };
  const RULE_HOOKS = ['workStart', 'anyStart', 'workEnd', 'otherBad', 'otherBreach', 'grief', 'seg'];
  const AB_HOOKS = ['onPlace', 'onDayStart', 'onWorkStart', 'onBox', 'onWorkEnd', 'onSeg', 'onTick', 'onGaugeFull', 'onBreach', 'onRecontain'];
  /* 수칙 종류: ctRule(id, { n 이름, d 설명, chk?(S, R, ri, st, w, turn) → 위반?, 갈고리…(RULE_HOOKS) }) — chk가 있으면 「출입」, 없으면 「상시」 */
  function ctRule(id, d) {
    if (!id || RULES[id]) return ctWarn('수칙 ' + id + ': id가 없거나 겹침');
    if (!d || !d.n || !d.d) return ctWarn('수칙 ' + id + ': n(이름) · d(설명)가 필요');
    if (!d.chk && !RULE_HOOKS.some((k) => typeof d[k] === 'function')) return ctWarn('수칙 ' + id + ': chk도 갈고리도 없음');
    Object.keys(d).forEach((k) => { if (typeof d[k] === 'function' && k !== 'chk' && k !== 'ai' && !RULE_HOOKS.includes(k)) ctWarn('수칙 ' + id + ': 모르는 갈고리 ' + k); });
    d.id = id; d.pas = d.chk ? 0 : 1; RULES[id] = d;
  }
  /* 탈주 양상: ctBreach(id, { n, d, goal?(S, b) → 쫓을 직원, speed? 배수, stirMid? 차 중간에도 자극, chaseStop? 닿으면 멈춤(기본 true), seg?(S, b) }) */
  function ctBreach(id, d) { if (!id || BK[id] || !d || !d.n || !d.d) return ctWarn('탈주 양상 ' + id + ': id 겹침 또는 n · d 빠짐'); d.id = id; BK[id] = d; }
  /* 이변 종류: ctBurst(id, { d(v) → 설명 글, run(S, ri, v, alive) → 기록에 붙일 글 }) */
  function ctBurst(id, d) { if (!id || BURST[id] || !d || typeof d.d !== 'function' || typeof d.run !== 'function') return ctWarn('이변 ' + id + ': id 겹침 또는 d(v) · run 빠짐'); d.id = id; BURST[id] = d; }
  function ctEvent(d) { if (!d || !d.n || !d.d || !d.fx) return ctWarn('사건: n · d · fx가 필요 (' + (d && d.n) + ')'); EVENTS.push(d); }
  function ctUp(d) { if (!d || !d.id || !d.n || !d.d || !(d.mx > 0) || !(d.c > 0) || UPS.some((u) => u.id === d.id)) return ctWarn('강화: id · n · d · mx · c가 필요하거나 id 겹침 (' + (d && d.id) + ')'); UPS.push(d); }
  const kwOk = (who, list) => (Array.isArray(list) ? list : []).filter((k) => { const ok = Array.isArray(k) && KW[k[0]] && typeof k[1] === 'number' && (k[0] !== 'foc' || (k[2] >= 0 && k[2] < 4)); if (!ok) ctWarn(who + ': 모르는 키워드 ' + JSON.stringify(k)); return ok; });
  /* 이형체: ctAb({ id, no, name, grade, hue, look, logs[2], pref{obs,tlk,feed,sup}, dmg 'h'|'s'|'b', gauge, rules[], breach '양상' | burst ['종류', 값] | burst { d, run },
       gear { w[이름, 위력, 키워드], a[이름, 방호, 차폐, 키워드], x?[이름, 키워드] }, glyph, img?, hooks? })  — 번호(도감 · 저장의 e)는 등록 순서 */
  function ctAb(d) {
    const who = '이형체 ' + (d && d.id);
    if (!d || !d.id || !d.no || !d.name) return ctWarn(who + ': id · no · name이 필요');
    if (ENT_ID[d.id] != null) return ctWarn(who + ': id 겹침');
    const tier = GRN[d.grade]; if (!tier) return ctWarn(who + ': 모르는 등급 ' + d.grade + ' (' + Object.keys(GRN).join(' · ') + ')');
    if (!d.look || !Array.isArray(d.logs) || d.logs.length < 2) return ctWarn(who + ': look과 logs 두 개가 필요');
    const pf = d.pref ? WORKS.map((W) => d.pref[W.id]) : [];
    if (pf.length !== 4 || pf.some((v) => !(v === 0 || v === 1 || v === 2)) || !pf.includes(2)) return ctWarn(who + ': pref는 obs · tlk · feed · sup에 0 · 1 · 2, 선호(2)가 하나는 있어야 함');
    if (!DTN[d.dmg]) return ctWarn(who + ': dmg는 h · s · b');
    if (!(d.gauge >= 2 && d.gauge <= 8)) return ctWarn(who + ': gauge(게이지 한계)는 2 ~ 8');
    const rules = (d.rules || []).filter((k) => { if (!RULES[k]) ctWarn(who + ': 모르는 수칙 ' + k + ' — 뺌'); return !!RULES[k]; }).slice(0, 3);
    if ((d.rules || []).length > 3) ctWarn(who + ': 수칙은 셋까지');
    if (!!d.breach === !!d.burst) return ctWarn(who + ': breach(탈주 양상)와 burst(이변) 중 하나만');
    if (d.breach && !BK[d.breach]) return ctWarn(who + ': 모르는 탈주 양상 ' + d.breach);
    let bu = null;
    if (d.burst) {
      if (Array.isArray(d.burst)) { if (!BURST[d.burst[0]]) return ctWarn(who + ': 모르는 이변 ' + d.burst[0]); bu = { k: d.burst[0], v: d.burst[1] || 0 }; }
      else if (typeof d.burst.run === 'function' && d.burst.d) { const k = '_' + d.id; BURST[k] = { id: k, d: () => d.burst.d, run: d.burst.run }; bu = { k, v: 0 }; }
      else return ctWarn(who + ': burst는 [종류, 값] 또는 { d, run }');
    }
    const g = d.gear || {};
    if (!Array.isArray(g.w) || !g.w[0] || !Array.isArray(g.a) || !g.a[0]) return ctWarn(who + ': gear.w[이름, 위력, 키워드] · gear.a[이름, 방호, 차폐, 키워드]가 필요');
    if (g.x && tier < X_MIN) ctWarn(who + ': 장신구는 ' + GR[X_MIN].n + ' 이상에서만 쓰는 것이 원칙');
    const hooks = d.hooks || null;
    if (hooks) Object.keys(hooks).forEach((k) => { if (!AB_HOOKS.includes(k)) ctWarn(who + ': 모르는 갈고리 ' + k + ' (' + AB_HOOKS.join(' · ') + ')'); });
    const i = ENT.length, G = GR[tier];
    const E = { id: d.id, no: d.no, n: d.name, tier, pf: pf.join(''), dt: d.dmg, gm: d.gauge, esc: d.breach ? 1 : 0, bk: d.breach || null, bu, rules, hu: d.hue == null ? 200 : d.hue,
      look: d.look, desc: d.logs[0], log: d.logs[1], gl: d.glyph || '<circle cx="24" cy="30" r="14" fill="currentColor"/>', img: d.img === false ? '' : (d.img || d.id), hooks, note: d.note || '' };
    ENT.push(E); ENT_ID[d.id] = i;
    GEAR[i + 'w'] = { key: i + 'w', ei: i, slot: 'w', n: g.w[0], dt: d.dmg, kw: [['pow', g.w[1] || 0]].concat(kwOk(who, g.w[2])), pt: G.w[0], cost: G.w[1], lim: G.lim };
    GEAR[i + 'a'] = { key: i + 'a', ei: i, slot: 'a', n: g.a[0], kw: [].concat(g.a[1] ? [['grd', g.a[1]]] : [], g.a[2] ? [['shd', g.a[2]]] : [], kwOk(who, g.a[3])), pt: G.a[0], cost: G.a[1], lim: G.lim };
    if (g.x) GEAR[i + 'x'] = { key: i + 'x', ei: i, slot: 'x', n: g.x[0], kw: kwOk(who, g.x[1]), pt: X_COST[0], cost: X_COST[1], lim: 1 };
  }
  const gearText = (G) => (G.slot === 'w' ? DTN[G.dt] + ' 피해 · ' : '') + G.kw.map(kwText).join(' · ');
  const weakOf = (E) => (E.dt === 'h' ? 's' : E.dt === 's' ? 'h' : null);
  const buText = (E) => '이변: ' + BURST[E.bu.k].d(E.bu.v);
  /* chk(S, R, ri, st, w, turn): 이 작업이 수칙을 어기는가(작업을 시작할 때 판정 — 위반이면 성공률 −20%p, 게이지 +2).
     갈고리(i = 그 이형체의 몇 번째 수칙, ri = 그 방 번호): seg(S, R, i, ri, T) 차가 넘어갈 때 · workStart(S, R, i, ri, st, a) 이 방 작업 시작 ·
     anyStart(S, R, i, ri, st, tri) 어느 방에서든 작업 시작 · workEnd(S, R, i, ri, st, a, gr) → 게이지 변화량 · otherBad(S, R, i, ri, src) 다른 방 작업이 나쁨 ·
     otherBreach(S, R, i, ri, src) 다른 이형체 탈주 · grief(S, R, i, ri) 직원이 공황 · 사망. 상시 수칙의 발동은 passiveHit(S, R, i, ri, 글, 게이지)로.
     ai(S, R, ri, st, w, T, gLeft, lv) → 점수: 봇 · 추천 지시가 「지금 이 방에 이 작업을 하고 싶은 정도」에 더하는 값(밝혀진 수칙만 불림). */
  ctRule('neglect', { n: '방치 금지', d: '두 차 연속으로 아무도 작업하지 않으면 게이지 +1.',
    ai: (S, R) => (R.idle >= 1 ? 5 : 0),
    seg(S, R, i, ri) { if (R.idle >= 1) { passiveHit(S, R, i, ri, '두 차 연속 방치.', 1); R.idle = 0; } } });
  ctRule('norepeat', { n: '같은 직원 연속 금지', d: '직전에 작업한 직원이 다시 들어가면 위반.', chk: (S, R, ri, st) => R.ls === st.id });
  ctRule('feed1', { n: '급양은 하루 한 번', d: '같은 날 두 번째 급양부터 위반.', chk: (S, R, ri, st, w) => w === 2 && R.df >= 1 });
  ctRule('nosame', { n: '같은 작업 연속 금지', d: '직전과 같은 종류의 작업을 하면 위반.', chk: (S, R, ri, st, w) => R.lw === w });
  ctRule('full', { n: '다친 직원 출입 금지', d: '체력이 가득 차지 않은 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.hp < hpMax(st) - 0.5 });
  ctRule('even', { n: '짝수 차 출입 금지', d: '2 · 4 · 6차에 작업을 시작하면 위반.', chk: (S, R, ri, st, w, t) => t % 2 === 0 });
  ctRule('noobs', { n: '관찰 금지', d: '관찰 작업을 하면 위반.', chk: (S, R, ri, st, w) => w === 0 });
  ctRule('onlyone', { n: '하루 한 사람 전담', d: '그날 처음 들어간 직원이 아닌 사람이 들어가면 위반.', chk: (S, R, ri, st) => R.ds.length > 0 && R.ds[0] !== st.id });
  ctRule('noweapon', { n: '무기 반입 금지', d: '무기를 장착한 직원이 들어가면 위반.', chk: (S, R, ri, st) => !!st.wp });
  ctRule('sane', { n: '지친 직원 출입 금지', d: '정신이 절반에 못 미치는 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.sp * 2 < spMax(st) });
  ctRule('envy', { n: '옆방 동시 작업 금지', d: '같은 층 옆방에서 작업이 진행 중일 때 들어가면 위반.', chk: (S, R, ri) => S.staff.some((o) => !o.dead && o.a && o.a.k === 'w' && o.a.ph === 1 && roomF(o.a.r) === roomF(ri) && Math.abs(o.a.r - ri) === 1) });
  ctRule('first', { n: '첫 차 작업 필수', d: '1차가 끝날 때까지 아무도 작업하지 않으면 게이지 +2.',
    ai: (S, R, ri, st, w, T) => (T === 1 && R.dn === 0 ? 8 : 0),
    seg(S, R, i, ri, T) { if (T === 1 && R.dn === 0) passiveHit(S, R, i, ri, '첫 차 미작업.', 2); } });
  ctRule('brave', { n: '담력 3 이상만', d: '담력이 3에 못 미치는 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.st[0] < 3 });
  ctRule('mark', { n: '향이 밴 직원', d: '이 방에서 작업한 직원이 같은 날 다른 방에 들어가면 그 방 게이지 +1.',
    ai: (S, R, ri, st, w, T, gLeft, lv) => (st.mk !== ri && lv >= 2 ? -2.5 : 0),
    workStart(S, R, i, ri, st) { st.mk = ri; },
    anyStart(S, R, i, ri, st, tri) { if (st.mk !== ri || tri === ri) return; bump(S, tri, 1); R.vio[i]++; if (!ruleKnown(R, i) && R.vio[i] >= 2) R.rv[i] = 1; evAdd(S, 'warn', ENT[S.rooms[tri].e].no + ' ' + (ruleKnown(R, i) ? ENT[R.e].no + '의 향에 동요' : '원인 미확인의 동요') + '. 게이지 +1.', tri); } });
  ctRule('clock', { n: '번지는 금', d: '차가 넘어갈 때마다 게이지 +1. 작업이 좋음이면 −2, 보통이면 −1.',
    ai: (S, R, ri, st, w, T, gLeft) => 3 + (gLeft <= 2 ? 6 : 0),
    seg(S, R, i, ri) { bump(S, ri, 1); R.vio[i]++; if (!ruleKnown(R, i) && R.vio[i] >= 3) { R.rv[i] = 1; evAdd(S, 'warn', ENT[R.e].no + ' 사례 대조로 수칙 확인: ' + RULES.clock.n + '.', ri); } },
    workEnd(S, R, i, ri, st, a, gr) { return -gr; } });
  ctRule('max3', { n: '하루 세 번까지', d: '같은 날 네 번째 작업부터 위반.', chk: (S, R) => R.dn >= 3 });
  ctRule('grief', { n: '울음에 반응', d: '시설에서 직원이 공황에 빠지거나 숨지면 게이지 +2.',
    grief(S, R, i, ri) { passiveHit(S, R, i, ri, '울음에 반응.', 2); } });
  ctRule('nosup', { n: '억제 금지', d: '억제 작업을 하면 위반.', chk: (S, R, ri, st, w) => w === 3 });
  ctRule('noise', { n: '소란에 예민', d: '다른 이형체가 탈주 중이면 차가 넘어갈 때마다 게이지 +1.',
    seg(S, R, i, ri) { if (S.br.some((b) => b.r !== ri)) passiveHit(S, R, i, ri, '소란에 반응.', 1); } });
  ctRule('elite', { n: '숙련자만', d: '능력치 합이 10에 못 미치는 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.st[0] + st.st[1] + st.st[2] + st.st[3] < 10 });
  ctRule('calm', { n: '근심 없는 직원 출입 금지', d: '정신이 가득 찬 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.sp >= spMax(st) - 0.5 });
  ctRule('once', { n: '직원마다 하루 한 번', d: '같은 날 이미 들어갔던 직원이 다시 들어가면 위반.', chk: (S, R, ri, st) => R.ds.includes(st.id) });
  ctRule('late', { n: '늦은 작업 금지', d: '5차부터 작업을 시작하면 위반.', chk: (S, R, ri, st, w, t) => t >= 5 });
  ctRule('early', { n: '이른 작업 금지', d: '1 · 2차에 작업을 시작하면 위반.', chk: (S, R, ri, st, w, t) => t <= 2 });
  ctRule('odd', { n: '홀수 차 출입 금지', d: '1 · 3 · 5차에 작업을 시작하면 위반.', chk: (S, R, ri, st, w, t) => t % 2 === 1 });
  ctRule('hungry', { n: '오전 급양 필수', d: '3차가 끝날 때까지 급양을 한 번도 받지 못하면 게이지 +2.',
    ai: (S, R, ri, st, w, T) => (w === 2 && R.df === 0 && T <= 3 ? 7 : 0),
    seg(S, R, i, ri, T) { if (T === 3 && R.df === 0) passiveHit(S, R, i, ri, '오전 급양 누락.', 2); } });
  ctRule('crowd', { n: '혼잡 금지', d: '작업을 시작할 때 같은 층에 다른 직원이 둘 이상 있으면 위반.', chk: (S, R, ri, st) => S.staff.filter((o) => !o.dead && o.id !== st.id && o.f === roomF(ri) && o.x > 0).length >= 2 });
  ctRule('meek', { n: '대담한 직원 출입 금지', d: '담력이 4 이상인 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.st[0] >= 4 });
  ctRule('lonely', { n: '인기척 필요', d: '차가 넘어갈 때 같은 층에 직원이 한 명도 없으면 게이지 +1.',
    ai: () => 0.8,
    seg(S, R, i, ri) { if (!S.staff.some((s) => !s.dead && s.f === roomF(ri) && s.x > 0)) passiveHit(S, R, i, ri, '인기척 없음.', 1); } });
  ctRule('twice', { n: '같은 작업은 하루 두 번까지', d: '같은 날 같은 종류의 작업을 세 번째 하면 위반.', chk: (S, R, ri, st, w) => R.dk[w] >= 2 });
  ctRule('samerole', { n: '같은 직책 연속 금지', d: '직전에 작업한 직원과 직책이 같으면 위반.', chk: (S, R, ri, st) => R.lr === st.role });
  ctRule('hurt', { n: '성한 직원 출입 금지', d: '체력이 가득 찬 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.hp >= hpMax(st) - 0.5 });
  ctRule('min2', { n: '하루 두 번 이상', d: '6차가 끝날 때까지 작업이 두 번에 못 미치면 게이지 +2.',
    ai: (S, R, ri, st, w, T) => (R.dn < 2 && T >= 2 ? 5 : 0),
    seg(S, R, i, ri, T) { if (T === TURNS && R.dn < 2) passiveHit(S, R, i, ri, '하루 작업 부족.', 2); } });
  ctRule('noarmor', { n: '방호구 반입 금지', d: '방호구를 장착한 직원이 들어가면 위반.', chk: (S, R, ri, st) => !!st.ar });
  ctRule('fail', { n: '실패에 민감', d: '다른 격리실의 작업이 나쁨으로 끝날 때마다 게이지 +1.',
    otherBad(S, R, i, ri) { passiveHit(S, R, i, ri, '다른 방의 실패에 반응.', 1); } });
  ctRule('worked', { n: '일한 직원만', d: '그날 아직 어떤 작업도 하지 않은 직원이 들어가면 위반.', chk: (S, R, ri, st) => !st.dl.length });
  ctRule('fresh', { n: '첫 방문만', d: '그날 다른 격리실에서 이미 작업한 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.dl.some((r) => r !== ri) });
  ctRule('empath', { n: '공감 3 이상만', d: '공감이 3에 못 미치는 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.st[2] < 3 });
  ctRule('sync', { n: '탈주에 동조', d: '다른 이형체가 격리를 벗어날 때마다 게이지 +2.',
    otherBreach(S, R, i, ri) { passiveHit(S, R, i, ri, '탈주에 동조.', 2); } });
  ctRule('steady', { n: '하루 한 가지 작업', d: '그날 처음 한 작업과 다른 종류의 작업을 하면 위반.', chk: (S, R, ri, st, w) => R.fw >= 0 && R.fw !== w });
  ctRule('noguard', { n: '경비 출입 금지', d: '경비 직책의 직원이 들어가면 위반.', chk: (S, R, ri, st) => st.role === 0 });
  ctRule('quota', { n: '마감 뒤 출입 금지', d: '그날 에너지 목표를 채운 뒤에 작업을 시작하면 위반.', chk: (S) => S.en >= S.quota });
  ctRule('obsfirst', { n: '관찰 먼저', d: '그날 이 방의 첫 작업이 관찰이 아니면 위반.', chk: (S, R, ri, st, w) => R.dn === 0 && w !== 0 });
  ctRule('balance', { n: '한쪽만 든 직원 금지', d: '무기와 방호구 중 하나만 장착한 직원이 들어가면 위반.', chk: (S, R, ri, st) => !!st.wp !== !!st.ar });
  /* 탈주 양상 — goal(S, b): 쫓을 직원(없으면 떠돈다) · speed: 걸음 배수 · stirMid: 차 중간에도 격리실 자극 · chaseStop: 칠 상대가 닿으면 멈춤 ·
     seg(S, b): 차가 넘어갈 때(층 옮기기 등). b = { r 방, hp, mx, f 층, x, tf · tx 가려는 곳 } */
  ctBreach('hunt', { n: '추적', d: '같은 층의 가장 가까운 직원을 쫓아가 친다.', chaseStop: true,
    goal: (S, b) => S.staff.filter((st) => attackable(st) && st.f === b.f).sort((p, q) => Math.abs(p.x - b.x) - Math.abs(q.x - b.x))[0],
    seg(S, b) { if (!S.staff.some((st) => attackable(st) && st.f === b.f)) { const fl = S.staff.filter(attackable).map((st) => st.f); if (fl.length) { b.tf = pickOf(fl); b.tx = EX + 40; } } } });
  ctBreach('roam', { n: '배회', d: '직원을 쫓지 않고 복도를 떠돌며, 차마다 두 번 격리실을 자극한다.', speed: 1.3, stirMid: true, chaseStop: false,
    seg(S, b) { if (Math.random() < 0.5) { b.tf = clamp(b.f + (Math.random() < 0.5 ? -1 : 1), 0, S.fo - 1); b.tx = X0 + rnd(FW - X0 - 20); } } });
  ctBreach('stalk', { n: '집요', d: '정신이 가장 낮은 직원을 층을 넘어 쫓아간다.', chaseStop: true,
    goal: (S, b) => S.staff.filter((st) => attackable(st) && !st.pn).sort((p, q) => p.sp - q.sp)[0] });

  /* 이변 종류 — d(v): 설명 글 · run(S, ri, v, alive): 일으키고, 근무 기록에 붙일 글을 돌려준다 */
  const drain = (S, n) => { n = Math.min(Math.floor(S.en), n); S.en -= n; return ' 에너지 −' + n + '.'; };
  const stirAll = (S, ri) => { S.rooms.forEach((o, i) => { if (i !== ri) bump(S, i, 1); }); return ' 다른 모든 이형체 게이지 +1.'; };
  const allSp = (S, alive, v) => { let t = ' 전 직원 정신 −' + v + '.'; alive.forEach((s) => { const x = hurt(S, s, v, 's'); if (/공황/.test(x)) t += ' ' + s.n + ' 공황.'; }); return t; };
  ctBurst('en', { d: (v) => '에너지 −' + v + '.', run: (S, ri, v) => drain(S, v) });
  ctBurst('sp', { d: (v) => '전 직원 정신 −' + v + '.', run: (S, ri, v, alive) => allSp(S, alive, v) });
  ctBurst('hp', { d: (v) => '무작위 직원 2명 체력 −' + v + '.', run: (S, ri, v, alive) => shuf(alive).slice(0, 2).map((s) => ' ' + hurt(S, s, v, 'h')).join('') });
  ctBurst('stir', { d: () => '다른 모든 이형체의 게이지 +1.', run: (S, ri) => stirAll(S, ri) });
  ctBurst('heart', { d: (v) => '다른 모든 이형체의 게이지 +1, 에너지 −' + v + '.', run: (S, ri, v) => drain(S, v) + stirAll(S, ri) });
  ctBurst('pull', { d: (v) => '정신이 가장 낮은 직원 공황, 전 직원 정신 −' + v + '.',
    run(S, ri, v, alive) { let t = ''; const lo = alive.filter((s) => !s.pn).sort((a, b) => a.sp - b.sp)[0]; if (lo) t += ' ' + hurt(S, lo, 999, 's'); return t + allSp(S, alive, v); } });
  ctBurst('tm', { d: () => '시설 시계가 한 차 앞당겨진다.', run(S) { S.t += SEG; S.turn = turnOf(S); return ' 시계가 한 차 앞당겨짐.'; } });
  ctBurst('flood', { d: (v) => '전 직원 체력 −' + v + ', 에너지 −12.',
    run(S, ri, v, alive) { let t = drain(S, 12) + ' 전 직원 체력 −' + v + '.'; alive.forEach((s) => { const x = hurt(S, s, v, 'h'); if (/사망/.test(x)) t += ' ' + s.n + ' 사망.'; }); return t; } });
  ctBurst('judge', { d: (v) => '체력이 가장 낮은 직원 체력 −' + v + ', 전 직원 정신 −' + Math.round(v / 2) + '.',
    run(S, ri, v, alive) { let t = ''; const lo = alive.slice().sort((a, b) => a.hp - b.hp)[0]; if (lo) t += ' ' + hurt(S, lo, v, 'h'); alive.forEach((s) => hurt(S, s, v / 2, 's')); return t + ' 전 직원 정신 −' + Math.round(v / 2) + '.'; } });
  /* 직원 — 직책 4(주 능력치) × 얼굴 4 = 16명. 호출 부호와 얼굴이 한 쌍(얼굴 번호 = 직책 × 4 + 순번) */
  const ROLES = [
    { n: '경비', c: '#b0584c', calls: ['빗장', '철문', '말뚝', '모루'] },
    { n: '기록', c: '#6585a6', calls: ['돋보기', '먹줄', '색인', '초침'] },
    { n: '상담', c: '#5a9d88', calls: ['찻잔', '담요', '손난로', '맞장구'] },
    { n: '급양', c: '#b89650', calls: ['국자', '저울', '곳간', '주전자'] },
  ];
  const FACE_N = (fc) => ROLES[fc >> 2].calls[fc & 3];
  const TRAITS = {
    dull: { n: '둔감', d: '받는 정신 피해 −25%.' },
    tough: { n: '굳은살', d: '받는 체력 피해 −25%.' },
    careful: { n: '꼼꼼함', d: '기록: 1 (작업마다 관찰 수치 +1).' },
    quick: { n: '손이 빠름', d: '수확: 15 (작업 에너지 +15%).' },
    timid: { n: '조심성', d: '작업 성공률 +5%p, 받는 정신 피해 +25%.' },
    night: { n: '야근 체질', d: '4차부터 작업 성공률 +8%p.' },
    heal: { n: '회복이 빠름', d: '휴식과 하루 끝 회복량 +50%.' },
    brawl: { n: '몸싸움', d: '위력: 4 (제압 피해 +4).' },
    steady: { n: '침착함', d: '하루 한 번, 정신이 0이 될 때 1로 버틴다.' },
    swift: { n: '발이 빠름', d: '신속: 30 (이동 속도 +30%).' },
    plain: { n: '무던함', d: '특별한 성질 없음. 채용 비용 −4.' },
  };
  const TRK = Object.keys(TRAITS);

  /* 시설 강화 — 판 안에서만. 비용 = c × (단계 + 1) */
  ctUp({ id: 'med', n: '의무실', mx: 3, c: 12, d: '하루 끝 회복 +15%p.' });
  ctUp({ id: 'lounge', n: '휴게실', mx: 3, c: 10, d: '휴식 회복 +10%p(차마다).' });
  ctUp({ id: 'wall', n: '격벽 보강', mx: 2, c: 22, d: '모든 이형체의 게이지 한계 +1.' });
  ctUp({ id: 'lens', n: '관찰 장비', mx: 2, c: 10, d: '관찰 작업마다 관찰 수치 +2.' });
  ctUp({ id: 'gen', n: '발전 효율', mx: 3, c: 14, d: '작업 에너지 +10%.' });
  ctUp({ id: 'alarm', n: '경보망', mx: 3, c: 12, d: '탈주한 이형체의 체력 −12%, 자극 차단 30%.' });
  ctUp({ id: 'gym', n: '훈련장', mx: 2, c: 12, d: '능력치 성장에 필요한 경험 −1.' });
  ctUp({ id: 'sed', n: '진정제 비축', mx: 3, c: 12, d: '받는 정신 피해 −10%.' });
  ctUp({ id: 'dorm', n: '숙소 증설', mx: 3, c: 14, d: '직원 정원 +1.' });
  ctUp({ id: 'manual', n: '작업 지침서', mx: 3, c: 16, d: '모든 작업 성공률 +3%p.' });
  ctUp({ id: 'lift', n: '승강기 개량', mx: 2, c: 10, d: '승강기 이동 시간 −30%.' });
  const upLv = (S, id) => (S.up && S.up[id]) || 0;
  const upCost = (S, U_) => U_.c * (upLv(S, U_.id) + 1);

  /* 사건 — 2일째부터 아침마다 하나 */
  ctEvent({ n: '순간 정전', d: '모든 이형체의 게이지 +1로 하루를 시작한다.', fx: { g: 1 } });
  ctEvent({ n: '본부 감사', d: '오늘 목표량 +15%. 달성하면 비축 에너지 +16.', fx: { q: 1.15, qr: 16 } });
  ctEvent({ n: '보급 지연', d: '오늘 휴식 회복량이 절반이 된다.', fx: { rest: 0.5 } });
  ctEvent({ n: '위문품 도착', d: '전 직원 정신 +10.', fx: { sp: 10 } });
  ctEvent({ n: '습한 날', d: '오늘 급양 성공률 −10%p.', fx: { wk: [2, -0.1] } });
  ctEvent({ n: '고요한 밤', d: '모든 이형체의 게이지 −1로 하루를 시작한다.', fx: { g: -1 } });
  ctEvent({ n: '장비 점검일', d: '오늘 제압 피해 +25%.', fx: { sup: 1.25 } });
  ctEvent({ n: '관찰 주간', d: '오늘 작업마다 관찰 수치 +2.', fx: { rec: 2 } });
  ctEvent({ n: '환기 고장', d: '오늘 차가 넘어갈 때마다 전 직원 정신 −1.', fx: { spTick: 1 } });
  ctEvent({ n: '야근 수당', d: '오늘 목표 초과분의 비축 환산이 두 배.', fx: { surplus: 2 } });
  ctEvent({ n: '뒤숭숭한 소문', d: '무작위 직원 1명이 정신 −10으로 하루를 시작한다.', fx: { oneSp: 10 } });
  ctEvent({ n: '미세한 진동', d: '무작위 이형체 하나의 게이지 +2.', fx: { oneG: 2 } });
  ctEvent({ n: '구속구 교체', d: '오늘 억제 성공률 +10%p.', fx: { wk: [3, 0.1] } });
  ctEvent({ n: '면담의 날', d: '오늘 교감 성공률 +10%p.', fx: { wk: [1, 0.1] } });
  ctEvent({ n: '만월', d: 'WAW · ALEPH 등급의 게이지 +1. 오늘 작업 에너지 +20%.', fx: { gHi: 1, en: 1.2 } });
  ctEvent({ n: '배급 삭감', d: '비축 에너지 −12.', fx: { bud: -12 } });
  ctEvent({ n: '맑은 날', d: '오늘 관찰 성공률 +10%p.', fx: { wk: [0, 0.1] } });
  ctEvent({ n: '특별 지원', d: '비축 에너지 +14.', fx: { bud: 14 } });
  ctEvent({ n: '승강기 점검', d: '오늘 승강기 이동이 두 배 느리다.', fx: { lift: 2 } });
  ctEvent({ n: '분주한 날', d: '오늘 직원 이동 속도 +25%.', fx: { spd: 1.25 } });
  const evFx = (S, k) => (S.evt != null && EVENTS[S.evt].fx[k]) || 0;
  ctAb({
    id: 'c01', no: 'C-01', name: '젖은 우산', grade: 'ZAYIN', hue: 205,
    look: '접힌 채 벽에 세워 둔 검은 우산. 끝에서 물이 떨어진다.',
    logs: [
      '맑은 날에도 마르지 않는다. 물받이를 비우는 동안은 조용하다. 물받이가 넘치면 아래층 배전반이 젖는다.',
      '물받이에 고인 물을 분석한 결과는 빗물이었다. 이 격리실 위로는 지하 사십 미터의 암반뿐이다.',
    ],
    pref: { obs: 1, tlk: 0, feed: 2, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['neglect'],
    burst: ['en', 10],
    gear: {
      w: ['살대 창', 4, [['hrv', 5]]],
      a: ['방수 외투', 10, 6, []],
    },
    glyph: '<path d="M24 8v44m0 0q0 6-5 6" fill="none" stroke="currentColor" stroke-width="3"/><path d="M24 12l-7 30h14z" fill="currentColor"/><circle cx="24" cy="60" r="1.6" fill="currentColor"/>',
  });
  ctAb({
    id: 'c02', no: 'C-02', name: '대답하는 서랍', grade: 'ZAYIN', hue: 32,
    look: '세 칸짜리 낡은 서랍장. 물으면 쪽지가 한 장 들어 있다.',
    logs: [
      '질문을 소리 내어 말하고 서랍을 열면 답이 적힌 쪽지가 있다. 같은 사람이 거듭 물으면 쪽지는 그 사람에 관한 내용으로 바뀐다.',
      '맨 아래 칸은 한 번도 열리지 않았다. 열쇠 구멍 안쪽에서 종이 넘기는 소리가 난다.',
    ],
    pref: { obs: 2, tlk: 1, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['norepeat'],
    burst: ['sp', 6],
    gear: {
      w: ['손잡이 곤봉', 3, [['rec', 1]]],
      a: ['색인 조끼', 0, 12, []],
    },
    glyph: '<rect x="9" y="12" width="30" height="44" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><path d="M9 27h30M9 41h30" stroke="currentColor" stroke-width="2.5"/><path d="M20 20h8M20 34h8M20 48h8" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c03', no: 'C-03', name: '온실의 손님', grade: 'TETH', hue: 130,
    look: '잎을 몸에 감고 의자에 앉은 사람 모양의 덩굴. 눈을 뜨지 않는다.',
    logs: [
      '물과 볕을 주면 얌전히 앉아 있다. 하루에 두 번 물을 받으면 뿌리가 화분 밖으로 나온다.',
      '잎 사이로 드러난 손목에는 병원 인식표가 감겨 있다. 적힌 병동은 존재하지 않는다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 2, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['feed1'],
    breach: 'roam',
    gear: {
      w: ['덩굴 채찍', 5, [['abs', 1]]],
      a: ['잎맥 장갑', 8, 0, [['vit', 6]]],
    },
    glyph: '<circle cx="24" cy="16" r="7" fill="currentColor"/><path d="M24 23q-10 10-6 24h12q4-14-6-24z" fill="currentColor"/><path d="M14 50h20l-3 10H17z" fill="currentColor" opacity=".7"/>',
  });
  ctAb({
    id: 'c04', no: 'C-04', name: '세는 아이', grade: 'ZAYIN', hue: 265,
    look: '벽을 보고 서서 숫자를 세는 작은 형체.',
    logs: [
      '무엇을 세는지는 확인되지 않았다. 같은 일이 연달아 반복되면 처음부터 다시 세기 시작하고, 그때마다 목소리가 커진다.',
      '세는 숫자가 한 번 끊긴 적이 있다. 그날 시설 출입 명부에서 한 줄이 사라졌다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 3,
    rules: ['nosame'],
    breach: 'stalk',
    gear: {
      w: ['셈 막대', 4, [['foc', 5, 0]]],
      a: ['눈금 완장', 0, 8, [['mnd', 6]]],
    },
    glyph: '<circle cx="24" cy="22" r="7" fill="currentColor"/><path d="M15 58l3-26h12l3 26z" fill="currentColor"/><path d="M6 10v48" stroke="currentColor" stroke-width="2" opacity=".6"/>',
  });
  ctAb({
    id: 'c05', no: 'C-05', name: '잔불 고양이', grade: 'ZAYIN', hue: 18,
    look: '재 속에서 숨 쉬는 고양이 모양의 불씨.',
    logs: [
      '곁에 앉아 있으면 불이 잦아든다. 피 냄새가 나는 사람이 들어오면 털을 세우고 불이 커진다.',
      '불씨의 온도는 측정할 때마다 체온과 같다. 재는 사람의 체온이다.',
    ],
    pref: { obs: 0, tlk: 2, feed: 1, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['full'],
    breach: 'hunt',
    gear: {
      w: ['부지깽이', 6, []],
      a: ['재 묻은 앞치마', 14, 0, []],
    },
    glyph: '<path d="M12 50q-2-16 6-22l-3-9 7 5h4l7-5-3 9q8 6 6 22z" fill="currentColor"/><path d="M36 48q8-2 6-12" fill="none" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c06', no: 'C-06', name: '조용한 라디오', grade: 'ZAYIN', hue: 185,
    look: '전원이 뽑힌 진공관 라디오. 가끔 방송이 나온다.',
    logs: [
      '방송은 짝수 차에만 나온다. 방송 중에 방에 있던 사람은 내용을 기억하지 못하지만 그날 잠을 자지 못한다.',
      '방송에서 불린 이름을 받아 적은 기록은 모두 백지로 발견되었다. 받아 적은 직원은 손이 저리다고 했다.',
    ],
    pref: { obs: 2, tlk: 0, feed: 1, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['even'],
    burst: ['sp', 8],
    gear: {
      w: ['안테나 봉', 4, [['clm', 1]]],
      a: ['귀마개 두건', 0, 16, []],
    },
    glyph: '<rect x="8" y="24" width="32" height="26" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="18" cy="37" r="6" fill="currentColor"/><path d="M29 32h7M29 38h7M29 44h7" stroke="currentColor" stroke-width="2"/><path d="M34 24L42 8" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c07', no: 'C-07', name: '거울 속 하객', grade: 'HE', hue: 220,
    look: '전신 거울 안에만 비치는 예복 차림의 사람.',
    logs: [
      '거울 밖에는 아무도 없다. 잔을 채워 두면 거울 속 잔이 비워진다. 오래 마주 보면 거울 속에 선 자리가 바뀐다.',
      '거울 속 연회장에는 빈자리가 하나 있다. 이름표의 글자는 좌우가 뒤집히지 않은 채 읽힌다.',
    ],
    pref: { obs: 0, tlk: 1, feed: 2, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['noobs', 'twice'],
    breach: 'stalk',
    gear: {
      w: ['거울 날', 8, []],
      a: ['예복 조끼', 5, 15, []],
    },
    glyph: '<rect x="10" y="6" width="28" height="52" rx="12" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="24" cy="24" r="5" fill="currentColor"/><path d="M16 50q0-18 8-18t8 18z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c08', no: 'C-08', name: '낯가리는 신부', grade: 'HE', hue: 300,
    look: '면사포를 쓴 형체. 얼굴은 확인되지 않았다.',
    logs: [
      '그날 처음 들어온 사람을 기억한다. 다른 사람이 들어오면 면사포 아래에서 소리가 난다.',
      '부케의 꽃은 직원이 드나든 횟수만큼 시들었다. 남은 꽃은 다섯 송이다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 3,
    rules: ['onlyone', 'empath'],
    breach: 'hunt',
    gear: {
      w: ['부케 철사', 7, [['clm', 2]]],
      a: ['면사포 망토', 0, 18, [['mnd', 8]]],
    },
    glyph: '<circle cx="24" cy="17" r="6" fill="currentColor"/><path d="M24 8q-16 6-16 50h32q0-44-16-50z" fill="currentColor" opacity=".55"/><path d="M18 58l2-32h8l2 32z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c09', no: 'C-09', name: '바늘 재단사', grade: 'TETH', hue: 350,
    look: '제 몸의 솔기를 꿰매고 있는 마네킹.',
    logs: [
      '구속구를 조이면 바느질을 멈춘다. 날붙이를 든 사람이 들어오면 그것을 제 도구로 여기고 가져가려 한다.',
      '솔기를 따라 꿰맨 실은 사람의 머리카락이다. 색은 매주 달라진다.',
    ],
    pref: { obs: 1, tlk: 0, feed: 1, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['noweapon', 'steady'],
    breach: 'hunt',
    gear: {
      w: ['재단 가위', 10, []],
      a: ['누빔 작업복', 20, 0, []],
    },
    glyph: '<circle cx="24" cy="12" r="5" fill="currentColor"/><path d="M15 20h18l-3 18 4 20H14l4-20z" fill="currentColor"/><path d="M8 30l32-8" stroke="currentColor" stroke-width="1.6"/>',
  });
  ctAb({
    id: 'c10', no: 'C-10', name: '빈 새장', grade: 'TETH', hue: 48,
    look: '새가 없는 놋쇠 새장. 안에서 노랫소리가 난다.',
    logs: [
      '노래에 맞장구를 치면 소리가 낮아진다. 지친 사람이 들으면 새장 문을 열어 주려 한다.',
      '노래의 가사를 옮겨 적으면 받아 적은 사람의 어릴 적 주소가 된다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['sane', 'lonely'],
    breach: 'roam',
    gear: {
      w: ['새장 살 투창', 7, [['foc', 6, 1]]],
      a: ['깃털 목도리', 0, 14, [['clm', 1]]],
    },
    glyph: '<path d="M10 54V28q0-16 14-16t14 16v26z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M17 54V20M24 54V12M31 54V20M10 54h28" stroke="currentColor" stroke-width="2"/><circle cx="24" cy="8" r="3" fill="none" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c11', no: 'C-11', name: '시샘하는 초상', grade: 'TETH', hue: 285,
    look: '금테 액자 속의 인물화. 눈이 문 쪽을 향해 있다.',
    logs: [
      '천으로 덮어 두면 잠잠하다. 옆방에 사람이 드나드는 소리가 나면 액자가 벽을 긁는다.',
      '초상의 배경에 그려진 창밖 풍경이 이 시설의 정문으로 바뀌어 있다. 언제부터인지는 알 수 없다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 0, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['envy', 'fail'],
    burst: ['stir', 1],
    gear: {
      w: ['액자 모서리', 6, [['foc', 6, 3]]],
      a: ['덮개 천 망토', 8, 12, []],
    },
    glyph: '<rect x="8" y="8" width="32" height="48" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="24" cy="26" r="6" fill="currentColor"/><path d="M14 52q0-14 10-14t10 14z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c12', no: 'C-12', name: '검은 우체통', grade: 'TETH', hue: 8,
    look: '검게 칠한 우체통. 아침마다 편지가 한 통 들어 있다.',
    logs: [
      '편지의 수신인은 늘 시설 직원이다. 아침에 수거하지 않으면 편지가 스스로 수신인을 찾아간다.',
      '편지의 소인은 모두 내일 날짜다. 내용은 수신인만 읽을 수 있고, 읽은 사람은 답장을 쓰려 한다.',
    ],
    pref: { obs: 2, tlk: 0, feed: 2, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 3,
    rules: ['first', 'min2'],
    burst: ['hp', 10],
    gear: {
      w: ['인장 망치', 8, [['rec', 1]]],
      a: ['배달 가방끈', 12, 0, [['hrv', 5]]],
    },
    glyph: '<path d="M12 58V22q0-12 12-12t12 12v36z" fill="currentColor"/><path d="M16 26h16" stroke="#000" stroke-opacity=".6" stroke-width="3"/><path d="M8 58h32" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c13', no: 'C-13', name: '등불지기', grade: 'HE', hue: 40,
    look: '두건을 깊이 쓴 형체. 발치에 등이 하나 놓여 있다.',
    logs: [
      '등을 누가 켰는지는 확인되지 않았다. 형체의 그림자는 등 반대편이 아니라 문 쪽으로 진다. 겁먹은 사람 앞에서는 등을 들어 올린다.',
      '등의 기름은 줄지 않는다. 그 대신 방에 들어간 사람의 그림자가 조금씩 옅어진다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 0, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'b', gauge: 4,
    rules: ['brave', 'late'],
    breach: 'stalk',
    gear: {
      w: ['등 걸이 철퇴', 13, []],
      a: ['그을린 외투', 18, 10, []],
      x: ['꺼지지 않는 등', [['wil', 2], ['shd', 6]]],
    },
    glyph: '<circle cx="22" cy="9" r="5" fill="currentColor"/><path d="M14 16h16l4 44H10z" fill="currentColor"/><path d="M34 22v12" stroke="currentColor" stroke-width="2"/><rect x="30" y="34" width="8" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c14', no: 'C-14', name: '향기 남기는 것', grade: 'HE', hue: 320,
    look: '머리가 있어야 할 자리에 흰 꽃이 핀 형체.',
    logs: [
      '마주 앉았던 사람에게는 하루 동안 향이 남는다. 다른 이형체들은 그 향을 싫어한다.',
      '향을 맡은 직원들은 서로 다른 냄새를 말한다. 공통점은 장례식에서 맡았다는 것이다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['mark', 'crowd'],
    breach: 'roam',
    gear: {
      w: ['꽃대 세검', 11, [['clm', 2]]],
      a: ['향낭 목걸이', 0, 22, [['mnd', 8]]],
      x: ['마른 꽃잎 브로치', [['clm', 2], ['mnd', 6]]],
    },
    glyph: '<path d="M24 4l4 8 8-2-4 8 6 6-9 1-5 8-5-8-9-1 6-6-4-8 8 2z" fill="currentColor"/><path d="M16 60l3-28h10l3 28z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c15', no: 'C-15', name: '유리 속 나비', grade: 'WAW', hue: 175,
    look: '유리구 안에서 빛나는 나비. 유리에 가는 금이 가 있다.',
    logs: [
      '금은 시간이 갈수록 번진다. 빛을 넣어 주거나 덮개를 조이면 금이 메워진다. 유리가 깨지면 빛이 배관을 타고 시설 전체로 번진다.',
      '금이 번진 모양을 겹쳐 놓으면 시설 배관도와 일치한다. 아직 금이 닿지 않은 구역은 한 곳이다.',
    ],
    pref: { obs: 1, tlk: 0, feed: 2, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 5,
    rules: ['clock', 'noarmor'],
    burst: ['heart', 14],
    gear: {
      w: ['유리 조각 단도', 12, [['hrv', 6]]],
      a: ['날개 무늬 흉갑', 24, 0, [['vit', 8]]],
      x: ['유리 날개 핀', [['hrv', 10]]],
    },
    glyph: '<circle cx="24" cy="30" r="19" fill="none" stroke="currentColor" stroke-width="3"/><path d="M24 30q-12-14-13 0 1 10 13 3 12 7 13-3-1-14-13 0z" fill="currentColor"/><path d="M12 56h24" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c16', no: 'C-16', name: '우는 벽지', grade: 'HE', hue: 250,
    look: '무늬가 얼굴처럼 보이는 낡은 벽지. 밤에 젖는다.',
    logs: [
      '달래면 무늬가 흐려진다. 시설 어딘가에서 사람이 무너지면 벽 전체가 따라 운다.',
      '벽지를 뜯어낸 자리에는 같은 벽지가 있다. 일곱 겹까지 확인한 뒤 조사를 중단했다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['max3', 'grief'],
    burst: ['sp', 12],
    gear: {
      w: ['도배 칼', 10, [['foc', 8, 1]]],
      a: ['무늬 없는 덧옷', 0, 24, []],
      x: ['젖은 손수건', [['wil', 3]]],
    },
    glyph: '<rect x="6" y="6" width="36" height="52" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17" cy="24" r="3" fill="currentColor"/><circle cx="31" cy="24" r="3" fill="currentColor"/><path d="M17 30v12M31 30v16" stroke="currentColor" stroke-width="2"/><path d="M17 42q7-5 14 0" fill="none" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c17', no: 'C-17', name: '귀 기울이는 사슴', grade: 'WAW', hue: 160,
    look: '뿔에 방울을 단 흰 사슴. 늘 귀를 세우고 있다.',
    logs: [
      '조용히 지켜보는 동안은 움직이지 않는다. 구속하려 들거나 시설이 소란해지면 방울이 울린다.',
      '방울 소리가 들린 날에는 시설 밖 숲에서도 같은 소리가 돌아온다. 숲에 사슴은 없다.',
    ],
    pref: { obs: 2, tlk: 1, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 3,
    rules: ['nosup', 'noise'],
    breach: 'roam',
    gear: {
      w: ['뿔 가지 창', 14, [['abs', 2]]],
      a: ['방울 뗀 안장천', 16, 12, []],
      x: ['놋쇠 방울', [['spd', 15]]],
    },
    glyph: '<path d="M18 22l-6-14m6 14l-2-16m12 16l6-14m-6 14l2-16" stroke="currentColor" stroke-width="2.4" fill="none"/><path d="M16 22h12l2 12q8 2 8 12v12h-5V48H17v10h-5V40z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c18', no: 'C-18', name: '마지막 관객', grade: 'WAW', hue: 275,
    look: '빈 객석 한가운데 앉은 가면. 박수 소리가 난다.',
    logs: [
      '방에 들어온 사람을 무대에 선 사람으로 대한다. 서툰 사람이 서면 자리에서 일어난다.',
      '박수 소리는 객석 전체에서 난다. 좌석 수를 세어 보면 셀 때마다 한 자리가 는다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['elite', 'norepeat', 'sync'],
    breach: 'stalk',
    gear: {
      w: ['지휘봉', 15, [['clm', 3]]],
      a: ['암막 망토', 10, 28, []],
      x: ['반쪽 가면', [['foc', 6, 0], ['foc', 6, 1]]],
    },
    glyph: '<path d="M12 12h24v18q0 14-12 14T12 30z" fill="currentColor"/><path d="M17 24h5M26 24h5" stroke="#000" stroke-opacity=".7" stroke-width="3"/><path d="M8 58q0-10 16-10t16 10z" fill="currentColor" opacity=".6"/>',
  });
  ctAb({
    id: 'c19', no: 'C-19', name: '달 없는 우물', grade: 'ALEPH', hue: 215,
    look: '격리실 바닥에 난 우물. 수면에 아무것도 비치지 않는다.',
    logs: [
      '수위를 재는 동안은 잔잔하다. 근심 없는 얼굴이 들여다보면 수면이 올라온다. 오래 비워 두어도 올라온다.',
      '추를 내려 깊이를 쟀으나 줄이 모자랐다. 감아 올린 줄 끝에는 매듭이 하나 더 지어져 있었다.',
    ],
    pref: { obs: 2, tlk: 0, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['calm', 'neglect', 'early'],
    burst: ['pull', 8],
    gear: {
      w: ['두레박 사슬', 14, [['hrv', 8]]],
      a: ['추 달린 장화', 14, 20, [['mnd', 10]]],
      x: ['검은 물 한 병', [['reg', 3], ['wil', 2]]],
    },
    glyph: '<ellipse cx="24" cy="40" rx="17" ry="8" fill="none" stroke="currentColor" stroke-width="3"/><ellipse cx="24" cy="40" rx="11" ry="4" fill="currentColor"/><path d="M8 40V26M40 40V26M8 14h32M24 14v18" stroke="currentColor" stroke-width="2.4"/>',
  });
  ctAb({
    id: 'c20', no: 'C-20', name: '흰 서기', grade: 'WAW', hue: 200,
    look: '흰 옷을 입고 명부를 쓰는 형체. 펜을 멈추지 않는다.',
    logs: [
      '명부에는 시설 직원의 호출 부호가 적혀 있다. 하루에 같은 사람을 두 번 보면 그 줄에 선을 긋는다.',
      '명부의 첫 장은 이 시설이 지어지기 전의 날짜로 시작한다. 마지막 장은 아직 비어 있다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 2, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'b', gauge: 3,
    rules: ['once', 'balance', 'grief'],
    breach: 'hunt',
    gear: {
      w: ['깃펜 단검', 17, [['rec', 1]]],
      a: ['백지 가운', 22, 22, []],
      x: ['지워진 이름표', [['lck', 1]]],
    },
    glyph: '<circle cx="24" cy="12" r="6" fill="currentColor"/><path d="M12 60l4-40h16l4 40z" fill="currentColor"/><path d="M34 30l8-12" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c21', no: 'C-21', name: '멈춘 괘종시계', grade: 'ZAYIN', hue: 30,
    look: '추가 멈춘 채 서 있는 키 큰 괘종시계. 바늘은 움직인다.',
    logs: [
      '태엽을 감지 않아도 바늘이 돈다. 낮 동안은 조용하다. 근무가 끝나 갈 무렵 문을 열면 종이 울리고, 종소리를 들은 사람은 제 나이를 잠시 잊는다.',
      '시계가 가리키는 시각은 시설 시계보다 늘 조금 앞선다. 차이는 날마다 일 분씩 벌어지고 있다.',
    ],
    pref: { obs: 2, tlk: 1, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['late'],
    burst: ['sp', 6],
    gear: {
      w: ['시계추 철퇴', 4, [['hst', 6]]],
      a: ['태엽 조끼', 0, 10, [['spd', 8]]],
    },
    glyph: '<rect x="13" y="6" width="22" height="54" rx="2" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="24" cy="19" r="7" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M24 19v-5M24 19l3 2M24 30v16" stroke="currentColor" stroke-width="2"/><circle cx="24" cy="49" r="3.5" fill="currentColor"/>',
  });
  ctAb({
    id: 'c22', no: 'C-22', name: '식지 않는 찻잔', grade: 'ZAYIN', hue: 22,
    look: '받침 위에 놓인 찻잔. 김이 끊이지 않는다.',
    logs: [
      '차는 식지 않고 줄지도 않는다. 하루의 절반이 지나기 전에 새 차를 따라 주어야 한다. 잊으면 김이 환기구를 타고 올라가 배전실 계기판을 흐린다.',
      '찻잔을 비우려던 직원은 잔이 손에서 떨어지지 않았다고 진술했다. 잔은 스스로 받침으로 돌아갔다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 2, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['hungry'],
    burst: ['en', 10],
    gear: {
      w: ['찻숟가락 단검', 3, [['clm', 1]]],
      a: ['김 서린 앞치마', 6, 8, []],
    },
    glyph: '<path d="M10 34h24q0 16-12 16T10 34z" fill="currentColor"/><path d="M34 37q8 0 6 6t-8 4" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M6 54h32" stroke="currentColor" stroke-width="3"/><path d="M17 28q-3-5 0-9t0-9M26 28q-3-5 0-9t0-9" fill="none" stroke="currentColor" stroke-width="2" opacity=".7"/>',
  });
  ctAb({
    id: 'c23', no: 'C-23', name: '접힌 종이학', grade: 'ZAYIN', hue: 55,
    look: '선반에 앉은 종이학들. 아무도 접지 않았는데 수가 는다.',
    logs: [
      '종이는 시설의 폐기 서류다. 조용할 때는 날개를 접고 있다. 복도에 발소리가 겹치면 한꺼번에 날아오른다.',
      '펼쳐 본 한 마리의 안쪽에는 아직 작성되지 않은 다음 주 근무표가 인쇄되어 있었다.',
    ],
    pref: { obs: 2, tlk: 0, feed: 1, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['crowd'],
    breach: 'roam',
    gear: {
      w: ['종이 날 부채', 4, [['spd', 10]]],
      a: ['접지 조끼', 6, 6, []],
    },
    glyph: '<path d="M6 40l18-8 18-18-8 22 8 14-18-8-10 8z" fill="currentColor"/><path d="M24 32l10 4" stroke="#000" stroke-opacity=".4" stroke-width="2"/>',
  });
  ctAb({
    id: 'c24', no: 'C-24', name: '눈 감은 인형', grade: 'TETH', hue: 335,
    look: '흔들의자에 앉은 도자기 인형. 눈꺼풀이 닫혀 있다.',
    logs: [
      '곁에서 낮은 소리로 말을 걸면 의자가 천천히 흔들린다. 겁이 없는 사람이 들어오면 눈을 뜬다. 눈을 뜬 뒤의 기록은 남아 있지 않다.',
      '의자는 아무도 없는 밤에도 흔들린다. 흔들리는 횟수는 그날 방에 들어온 사람의 수와 같다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 3,
    rules: ['meek'],
    breach: 'stalk',
    gear: {
      w: ['도자기 파편', 5, []],
      a: ['레이스 덧소매', 0, 12, [['clm', 1]]],
    },
    glyph: '<circle cx="24" cy="18" r="8" fill="currentColor"/><path d="M19 18h4M26 18h4" stroke="#000" stroke-opacity=".6" stroke-width="2"/><path d="M14 52l4-24h12l4 24z" fill="currentColor"/><path d="M8 58q16-8 32 0" fill="none" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c25', no: 'C-25', name: '길 잃은 장화', grade: 'ZAYIN', hue: 95,
    look: '젖은 고무장화 한 켤레. 주인은 없다.',
    logs: [
      '혼자 두면 문 쪽으로 한 걸음씩 옮겨 간다. 복도에 인기척이 있는 동안은 제자리에 선다. 발자국은 늘 바깥을 향해 찍힌다.',
      '장화 속의 물은 바닷물로 확인되었다. 이 시설에서 가장 가까운 바다는 사백 킬로미터 밖이다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 0, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['lonely'],
    breach: 'roam',
    gear: {
      w: ['징 박힌 뒤축', 6, []],
      a: ['고무 덧신', 12, 0, [['spd', 8]]],
    },
    glyph: '<path d="M10 10h10v30h10q6 0 6 8v6H10z" fill="currentColor"/><path d="M24 14h8v22" fill="none" stroke="currentColor" stroke-width="3" opacity=".6"/>',
  });
  ctAb({
    id: 'c26', no: 'C-26', name: '덜 마른 그림', grade: 'ZAYIN', hue: 195,
    look: '이젤에 놓인 풍경화. 물감이 마르지 않는다.',
    logs: [
      '그려진 것은 이 시설의 복도다. 같은 손길이 거듭 닿으면 그림 속 복도에 사람이 하나씩 늘어난다. 늘어난 사람의 차림은 그날 근무자와 같다.',
      '그림 속 복도 끝의 문은 실제 시설에는 없는 문이다. 지난달보다 조금 열려 있다.',
    ],
    pref: { obs: 2, tlk: 1, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['twice'],
    burst: ['sp', 7],
    gear: {
      w: ['팔레트 나이프', 4, [['rec', 1]]],
      a: ['물감 묻은 덧옷', 4, 10, []],
    },
    glyph: '<rect x="9" y="8" width="30" height="30" fill="none" stroke="currentColor" stroke-width="3"/><path d="M12 32l8-10 6 6 5-8 5 12z" fill="currentColor"/><path d="M14 38l-6 22M34 38l6 22M24 38v20" stroke="currentColor" stroke-width="2.4"/>',
  });
  ctAb({
    id: 'c27', no: 'C-27', name: '뒤집힌 모래시계', grade: 'TETH', hue: 42,
    look: '모래가 아래에서 위로 오르는 모래시계.',
    logs: [
      '모래가 다 오르면 스스로 뒤집힌다. 아침에는 모래가 가장 빠르게 오른다. 그때 가까이 있던 사람은 하루가 짧았다고 말한다.',
      '모래알을 세려던 기록 직원은 같은 숫자를 세 번 적었다. 본인은 한 번만 적었다고 기억한다.',
    ],
    pref: { obs: 2, tlk: 0, feed: 1, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['early', 'nosame'],
    burst: ['tm', 1],
    gear: {
      w: ['유리 목 곤봉', 7, [['hst', 8]]],
      a: ['모래 주머니 조끼', 14, 0, [['hst', 6]]],
    },
    glyph: '<path d="M12 8h24M12 56h24" stroke="currentColor" stroke-width="3"/><path d="M14 8q0 16 10 24-10 8-10 24h20q0-16-10-24 10-8 10-24z" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M17 12h14l-7 12z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c28', no: 'C-28', name: '입 없는 합창단', grade: 'HE', hue: 255,
    look: '보면대 앞에 선 빈 예복 일곱 벌. 숨을 들이쉬는 소리가 난다.',
    logs: [
      '노래는 들리지 않는다. 지휘하듯 손을 들어 주면 숨소리가 가지런해진다. 같은 직책의 사람이 연달아 서면 그를 지휘자로 여기고 따라 나선다.',
      '악보는 백지다. 그런데도 일곱 벌은 같은 박자에 악보를 넘긴다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['samerole', 'neglect'],
    breach: 'hunt',
    gear: {
      w: ['보면대 창', 8, [['foc', 6, 1]]],
      a: ['합창 예복', 4, 14, []],
    },
    glyph: '<path d="M6 58V30q0-6 5-6t5 6v28zM19 58V24q0-6 5-6t5 6v34zM32 58V30q0-6 5-6t5 6v28z" fill="currentColor"/><path d="M8 14h32" stroke="currentColor" stroke-width="2" opacity=".6"/>',
  });
  ctAb({
    id: 'c29', no: 'C-29', name: '소금 기둥', grade: 'TETH', hue: 205,
    look: '사람 키만 한 소금 결정 기둥. 꼭대기가 뒤를 돌아보듯 틀어져 있다.',
    logs: [
      '습기를 막아 주면 형태를 유지한다. 다친 데 없는 사람이 들어오면 표면에서 소금이 일어난다. 날린 소금은 가장 가까운 살갗에 붙는다.',
      '기둥이 돌아보는 방향을 따라가면 직원 숙소의 한 침대에 닿는다. 그 침대는 삼 년째 비어 있다.',
    ],
    pref: { obs: 1, tlk: 0, feed: 1, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['hurt', 'feed1'],
    burst: ['hp', 10],
    gear: {
      w: ['암염 망치', 9, []],
      a: ['소금 절인 가죽옷', 18, 0, [['vit', 6]]],
    },
    glyph: '<path d="M18 60l-2-30q-2-14 6-20 8-2 10 8l-4 4q4 6 2 14l-2 24z" fill="currentColor"/><path d="M10 60h28" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c30', no: 'C-30', name: '받는 이 없는 전화', grade: 'TETH', hue: 0,
    look: '선이 끊긴 낡은 전화기. 하루에 몇 번 벨이 울린다.',
    logs: [
      '받으면 숨소리만 들리다 끊긴다. 하루에 두 번은 받아 주어야 한다. 받지 않은 날에는 직원 숙소의 전화가 대신 울린다.',
      '통화 기록 장치에는 받은 직원의 목소리만 남는다. 직원은 아무 말도 하지 않았다고 진술했다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 3,
    rules: ['min2', 'norepeat'],
    burst: ['sp', 9],
    gear: {
      w: ['수화기 줄 올가미', 6, [['foc', 6, 1]]],
      a: ['교환수 머리띠', 0, 14, [['mnd', 6]]],
    },
    glyph: '<rect x="12" y="8" width="24" height="40" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="24" cy="24" r="7" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="24" cy="24" r="2" fill="currentColor"/><path d="M36 14q8 2 6 14t-6 30" fill="none" stroke="currentColor" stroke-width="2.4"/>',
  });
  ctAb({
    id: 'c31', no: 'C-31', name: '빈 잠수복', grade: 'HE', hue: 28,
    look: '구리 잠수 헬멧을 쓴 빈 옷. 안에는 물만 차 있다.',
    logs: [
      '헬멧 유리 안쪽에서 김이 서린다. 공기 호스를 조여 두면 움직이지 않는다. 두꺼운 옷을 입은 사람을 보면 같은 처지로 여기고 따라가려 한다.',
      '호스의 반대쪽 끝은 벽 속으로 이어진다. 끝까지 따라가 본 조사는 승인되지 않았다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 0, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['noarmor', 'lonely'],
    breach: 'hunt',
    gear: {
      w: ['납 추 사슬', 10, []],
      a: ['구리 흉판', 22, 0, []],
    },
    glyph: '<circle cx="24" cy="16" r="10" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="24" cy="16" r="4.5" fill="currentColor"/><path d="M12 60l2-30h20l2 30z" fill="currentColor"/><path d="M34 14q10-2 8-12" fill="none" stroke="currentColor" stroke-width="2.4"/>',
  });
  ctAb({
    id: 'c32', no: 'C-32', name: '벽 속의 이웃', grade: 'TETH', hue: 270,
    look: '격리실 안쪽 벽에 난 낡은 나무 문. 건너편에서 두드린다.',
    logs: [
      '문 너머는 설계도에 없는 공간이다. 두드림에 같은 박자로 답하면 잠잠해진다. 시설 어디선가 일이 틀어지면 두드림이 빨라지고, 다른 방들이 그 박자를 따라 한다.',
      '문틈으로 밀어 넣은 쪽지는 다음 날 답장과 함께 돌아왔다. 답장의 필체는 쪽지를 쓴 직원의 것이었다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['fail', 'even'],
    burst: ['stir', 1],
    gear: {
      w: ['문고리 너클', 7, [['clm', 2]]],
      a: ['방음 누비옷', 6, 14, []],
    },
    glyph: '<rect x="6" y="6" width="36" height="52" fill="none" stroke="currentColor" stroke-width="2" opacity=".6"/><rect x="17" y="30" width="14" height="18" rx="1" fill="currentColor"/><circle cx="28" cy="39" r="1.4" fill="#000" fill-opacity=".6"/><path d="M12 22h4M20 18h4M30 22h4" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c33', no: 'C-33', name: '재의 정원사', grade: 'HE', hue: 15,
    look: '타 버린 화단을 돌보는 재로 된 형체. 전지가위를 쥐고 있다.',
    logs: [
      '화단에는 아무것도 자라지 않는다. 씨앗을 건네면 받아서 심는다. 그날 아직 아무 일도 하지 않은 사람의 손을 보면 가지로 여기고 다듬으려 한다.',
      '심은 씨앗은 싹트지 않는다. 다만 화단의 재는 날마다 한 줌씩 늘어난다. 어디서 오는 재인지는 확인되지 않았다.',
    ],
    pref: { obs: 1, tlk: 0, feed: 2, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['worked', 'noweapon'],
    breach: 'hunt',
    gear: {
      w: ['전지가위', 13, [['abs', 1]]],
      a: ['그을린 작업 장갑', 20, 6, []],
      x: ['탄 씨앗 주머니', [['reg', 3]]],
    },
    glyph: '<circle cx="22" cy="11" r="6" fill="currentColor"/><path d="M12 60l4-40h12l4 40z" fill="currentColor"/><path d="M32 26l10-8M32 26l10 4" stroke="currentColor" stroke-width="2.4"/>',
  });
  ctAb({
    id: 'c34', no: 'C-34', name: '열두 번째 의자', grade: 'HE', hue: 345,
    look: '촛불이 놓인 원탁과 둘러선 의자들. 한 자리만 비어 있다.',
    logs: [
      '열한 자리에는 앉았던 흔적이 있다. 들어온 사람에게 빈자리를 권한다. 다른 방에 먼저 들렀다 온 사람은 손님으로 대하지 않는다. 자리가 찬 뒤의 일은 확인되지 않았다.',
      '열한 자리 앞의 접시에는 이름이 새겨져 있다. 그중 넷은 퇴직자 명단과 일치한다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['fresh', 'crowd'],
    burst: ['pull', 8],
    gear: {
      w: ['의자 다리 곤봉', 11, [['foc', 8, 1]]],
      a: ['식탁보 망토', 6, 20, [['mnd', 8]]],
      x: ['열두 번째 냅킨', [['clm', 3]]],
    },
    glyph: '<ellipse cx="24" cy="40" rx="18" ry="7" fill="currentColor"/><path d="M19 12h10v18H19zM19 12v-6M29 12v-6" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M24 47v12" stroke="currentColor" stroke-width="3"/>',
  });
  ctAb({
    id: 'c35', no: 'C-35', name: '눈먼 등대', grade: 'WAW', hue: 225,
    look: '불이 꺼진 채 도는 등대 등명기. 빛이 없는데 그림자가 돈다.',
    logs: [
      '렌즈가 한 바퀴 돌 때마다 방 안의 그림자가 한 번 쓸려 간다. 홀수 차에는 그 그림자가 문 앞을 지난다. 그림자에 닿은 사람은 방향을 잃고, 렌즈가 멎으면 시설의 다른 것들이 깨어난다.',
      '렌즈의 회전 주기는 시설 상공을 지나는 무언가의 주기와 일치한다. 무엇인지는 기록에서 삭제되었다.',
    ],
    pref: { obs: 2, tlk: 1, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'b', gauge: 4,
    rules: ['odd', 'sane'],
    burst: ['heart', 14],
    gear: {
      w: ['렌즈 조각 창', 12, [['hrv', 6]]],
      a: ['등대지기 외투', 16, 12, []],
      x: ['등명기 조각', [['rec', 2], ['spd', 8]]],
    },
    glyph: '<path d="M18 60l3-34h6l3 34z" fill="currentColor"/><rect x="17" y="14" width="14" height="12" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M15 14l9-8 9 8zM4 16l12 4M44 16l-12 4" fill="none" stroke="currentColor" stroke-width="2.2"/>',
  });
  ctAb({
    id: 'c36', no: 'C-36', name: '양 떼 없는 목자', grade: 'WAW', hue: 80,
    look: '굽은 지팡이를 짚은 키 큰 형체. 얼굴이 있을 자리를 양털이 덮고 있다.',
    logs: [
      '양은 한 마리도 없다. 다정하게 대하는 사람은 양으로 여겨 곁에 둔다. 다른 것이 우리를 벗어나면 잃은 양을 찾으러 나선다.',
      '목자가 세는 수는 날마다 하나씩 준다. 지금 수는 이 시설의 직원 수와 같다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'b', gauge: 4,
    rules: ['empath', 'sync'],
    breach: 'stalk',
    gear: {
      w: ['목자의 지팡이', 13, [['clm', 2]]],
      a: ['양털 조끼', 14, 14, []],
      x: ['양털 타래', [['grd', 8], ['shd', 8]]],
    },
    glyph: '<circle cx="22" cy="12" r="7" fill="currentColor" opacity=".7"/><path d="M12 60l4-40h12l4 40z" fill="currentColor"/><path d="M36 60V14q0-8 6-6" fill="none" stroke="currentColor" stroke-width="2.6"/>',
  });
  ctAb({
    id: 'c37', no: 'C-37', name: '실 끊긴 꼭두각시', grade: 'WAW', hue: 300,
    look: '천장으로 줄이 뻗은 나무 인형. 줄 끝은 보이지 않는다.',
    logs: [
      '줄을 당기는 쪽은 확인되지 않았다. 하루에 한 가지 동작만 익힌다. 다른 동작을 시키면 줄이 엉킨다. 제복 입은 사람을 보면 줄을 그쪽으로 옮겨 매려 한다.',
      '줄 하나를 잘랐을 때, 같은 시각 위층 경비 직원의 왼팔이 한동안 들리지 않았다.',
    ],
    pref: { obs: 1, tlk: 1, feed: 0, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 3,
    rules: ['steady', 'noguard'],
    breach: 'hunt',
    gear: {
      w: ['조종 막대', 14, [['hst', 8]]],
      a: ['줄 감는 완갑', 20, 8, [['spd', 10]]],
      x: ['끊긴 줄 한 가닥', [['hst', 15]]],
    },
    glyph: '<path d="M14 2v14M24 2v10M34 2v14" stroke="currentColor" stroke-width="1.6"/><circle cx="24" cy="18" r="6" fill="currentColor"/><path d="M16 26h16l-2 16 4 16h-6l-4-12-4 12h-6l4-16z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c38', no: 'C-38', name: '밀물', grade: 'ALEPH', hue: 210,
    look: '문틈으로 들고 나는 검은 물. 수위표의 눈금이 날마다 달라진다.',
    logs: [
      '달과 무관하게 차오르고 빠진다. 수문을 조이는 동안은 빠진다. 그날 할 몫을 다 채운 뒤에도 문을 여는 사람이 있으면 물은 그것을 초대로 여긴다.',
      '물이 빠진 자리에는 젖은 신발 자국이 남는다. 자국의 수는 물이 든 횟수만큼 늘어난다. 나가는 방향의 자국은 없다.',
    ],
    pref: { obs: 1, tlk: 0, feed: 1, sup: 2 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'b', gauge: 4,
    rules: ['quota', 'neglect', 'hungry'],
    burst: ['flood', 9],
    gear: {
      w: ['수문 손잡이', 15, [['hrv', 8]]],
      a: ['밀랍 먹인 장화', 18, 16, [['vit', 8]]],
      x: ['수위표 조각', [['hrv', 8], ['reg', 2]]],
    },
    glyph: '<path d="M4 30q6-8 10 0t10 0 10 0 10 0v30H4z" fill="currentColor"/><path d="M38 6v20M34 10h8M34 16h8M34 22h8" stroke="currentColor" stroke-width="2"/>',
  });
  ctAb({
    id: 'c39', no: 'C-39', name: '이름 없는 행렬', grade: 'ALEPH', hue: 265,
    look: '관 곁을 지키는 검은 옷의 행렬. 누구의 장례인지는 적혀 있지 않다.',
    logs: [
      '행렬은 방 안을 돌 뿐 나아가지 않는다. 먼저 관의 명패를 확인하고 조의를 표해야 한다. 명패는 늘 비어 있다. 시설에서 사람이 무너지면 행렬은 그 이름을 받으러 나선다.',
      '관의 무게는 잴 때마다 다르다. 가장 최근의 값은 지난주 퇴근하지 않은 직원의 체중과 같았다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'b', gauge: 3,
    rules: ['obsfirst', 'grief', 'once'],
    breach: 'stalk',
    gear: {
      w: ['관 못 망치', 16, [['abs', 2]]],
      a: ['상복 두루마기', 12, 26, []],
      x: ['빈 명패', [['lck', 1], ['wil', 2]]],
    },
    glyph: '<path d="M8 24h32l-3 10H11z" fill="currentColor"/><path d="M12 34v24M22 34v24M34 34v24" stroke="currentColor" stroke-width="3"/><circle cx="12" cy="18" r="3.4" fill="currentColor"/><circle cx="22" cy="16" r="3.4" fill="currentColor"/><circle cx="34" cy="18" r="3.4" fill="currentColor"/>',
  });
  ctAb({
    id: 'c40', no: 'C-40', name: '기운 저울', grade: 'ALEPH', hue: 50,
    look: '사람 키만 한 놋쇠 접시저울. 빈 접시인데 한쪽으로 기울어 있다.',
    logs: [
      '무엇을 달고 있는지는 확인되지 않았다. 들어온 사람을 반대편 접시에 올려놓고 잰다. 한쪽 손만 채운 사람은 기운 것으로 본다. 하루에 달 수 있는 횟수는 정해져 있다.',
      '기운 쪽 접시 아래 바닥이 조금씩 패고 있다. 보이지 않는 그것은 해마다 무거워진다.',
    ],
    pref: { obs: 2, tlk: 0, feed: 1, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['balance', 'max3', 'elite'],
    burst: ['judge', 12],
    gear: {
      w: ['저울추', 17, [['foc', 8, 0]]],
      a: ['수평 어깨끈', 20, 20, [['mnd', 8]]],
      x: ['영점 추', [['foc', 5, 0], ['foc', 5, 1], ['foc', 5, 2], ['foc', 5, 3]]],
    },
    glyph: '<path d="M24 6v50M12 60h24M6 18l36-6" stroke="currentColor" stroke-width="3"/><path d="M6 18l-4 14h8zM42 12l-4 20h8z" fill="currentColor"/>',
  });
  ctAb({
    id: 'c41', no: 'C-41', name: '되감기는 필름', grade: 'TETH', hue: 38,
    look: '혼자 도는 낡은 영사기. 벽에 비친 장면이 거꾸로 흐른다.',
    logs: [
      '비치는 것은 이 격리실의 어제다. 곁에서 끝까지 지켜본 사람은 마음이 가라앉는다고 말한다. 중간에 눈을 돌리면 필름이 한 칸 더 감긴다.',
      '필름 통에는 날짜가 적혀 있지 않다. 감긴 길이를 재면 시설이 운영된 날수보다 사흘이 길다.',
    ],
    pref: { obs: 2, tlk: 1, feed: 0, sup: 1 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 's', gauge: 4,
    rules: ['norepeat', 'late'],
    burst: { d: '오늘 모은 에너지의 4분의 1이 사라진다(되감김).', run(S) { const n = Math.floor(S.en / 4); S.en -= n; return ' 장면이 되감김. 에너지 −' + n + '.'; } },
    gear: {
      w: ['필름 통 원반', 7, [['rec', 1]]],
      a: ['영사 기사의 앞치마', 0, 14, [['clm', 1]]],
    },
    glyph: '<circle cx="16" cy="18" r="9" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="34" cy="14" r="6" fill="none" stroke="currentColor" stroke-width="3"/><rect x="10" y="28" width="26" height="16" rx="2" fill="currentColor"/><path d="M36 32l8-5v18l-8-5zM18 44l-4 16M28 44l4 16" stroke="currentColor" stroke-width="2.6" fill="none"/>',
    hooks: {
      // 끝까지 지켜본 사람은 마음이 가라앉는다 / 눈을 돌리면 한 칸 더 감긴다
      onWorkEnd(S, R, ri, st, a, gr) {
        if (gr === 2) { st.sp = Math.min(spMax(st), st.sp + 4); evAdd(S, 'info', st.n + ', 장면을 끝까지 지켜봄. 정신 +4.', ri); }
        else if (gr === 0 && R.pt > 0) { const n = Math.min(R.pt, 3); R.pt -= n; evAdd(S, 'warn', 'C-41 필름이 감김. 관찰 수치 −' + n + '.', ri); }
      },
    },
  });
  ctAb({
    id: 'c42', no: 'C-42', name: '주인 없는 외투', grade: 'HE', hue: 215,
    look: '옷걸이에 걸린 두꺼운 겨울 외투. 소매 안에서 김이 난다.',
    logs: [
      '사람이 가까이 있는 동안은 얌전히 걸려 있다. 복도가 붐빌수록 조용해진다. 혼자 남으면 소매가 문손잡이 쪽으로 뻗는다.',
      '주머니에서 나온 것은 식당 영수증 한 장이다. 날짜는 이 구역이 개방된 날이고, 인원은 「한 명 더」라고 적혀 있다.',
    ],
    pref: { obs: 1, tlk: 2, feed: 1, sup: 0 },   // 2 선호 · 1 보통 · 0 기피
    dmg: 'h', gauge: 4,
    rules: ['lonely', 'nosup'],
    breach: 'hunt',
    gear: {
      w: ['옷걸이 갈고리', 10, [['spd', 8]]],
      a: ['안감 덧댄 외투', 18, 6, [['vit', 6]]],
      x: ['떨어진 단추', [['reg', 2]]],
    },
    glyph: '<path d="M24 6q-5 0-5 5l-9 6v37h10V30h8v24h10V17l-9-6q0-5-5-5z" fill="currentColor"/><path d="M24 12v40" stroke="#000" stroke-opacity=".5" stroke-width="2"/>',
    hooks: {
      // 복도가 붐빌수록 조용해진다: 차가 넘어갈 때 같은 층에 직원이 셋 이상이면 게이지 −1
      onSeg(S, R, ri) { if (R.g > 0 && S.staff.filter((s) => !s.dead && s.f === roomF(ri) && s.x > 0).length >= 3) { bump(S, ri, -1); evAdd(S, 'info', 'C-42 인기척에 잠잠해짐. 게이지 −1.', ri); } },
      // 벗어나면 먼저 몸을 불린다: 탈주 직후 체력 +20%
      onBreach(S, R, ri, b) { b.mx = Math.round(b.mx * 1.2); b.hp = b.mx; },
    },
  });

  /* ================= 계산 ================= */
  const kwSum = (st, k, w) => {
    let n = 0;
    for (const key of [st.wp, st.ar, st.ac]) if (key && GEAR[key]) for (const x of GEAR[key].kw) if (x[0] === k && (k !== 'foc' || x[2] === w)) n += x[1];
    return n;
  };
  function hpMax(st) { return 26 + 6 * st.st[0] + kwSum(st, 'vit'); }
  function spMax(st) { return 26 + 6 * st.st[3] + kwSum(st, 'mnd'); }
  const avail = (st) => !st.dead && !st.pn;
  const living = (S) => S.staff.filter((s) => !s.dead);
  const staffCap = (S) => 5 + upLv(S, 'dorm');
  const ruleKnown = (R, i) => !!R.rv[i];
  const prefKnown = (R, w) => !!R.un.p[w];
  const gMax = (S, R) => ENT[R.e].gm + upLv(S, 'wall');
  const brOf = (S, ri) => S.br.find((b) => b.r === ri);
  const brHp = (S, E) => Math.round(GR[E.tier].hp * (1 - 0.12 * upLv(S, 'alarm')));
  const hireCost = (S, c) => 16 + 2 * S.day - (c.tr === 'plain' ? 4 : 0);
  const roomsOpen = (S) => S.fo * PER;
  const occupied = (S) => S.rooms.filter((R) => R.e != null);
  const turnOf = (S) => Math.floor(S.t / SEG) + 1;
  const speedOf = (S, st) => SPD * (1 + (kwSum(st, 'spd') + (st.tr === 'swift' ? 30 : 0)) / 100) * (evFx(S, 'spd') || 1);
  const liftT = (S) => Math.max(1, Math.round(LIFT * (1 - 0.3 * upLv(S, 'lift')) * (evFx(S, 'lift') || 1)));
  const restX = (st) => LX0 + 20 + ((st.id - 1) % 8) * 21;
  const inLounge = (st) => st.f === 0 && st.x < 0;
  const frac = (s) => Math.min(s.hp / hpMax(s), s.sp / spMax(s));
  const alertOf = (S) => (S.br.length >= 2 ? 3 : S.br.length ? 2 : (S.rooms.some((R) => R.e != null && !R.out && R.g >= gMax(S, R) - 1) || S.staff.some((s) => !s.dead && s.pn)) ? 1 : 0);
  const gearFree = (S, g) => (S.gear[g] || 0) - S.staff.filter((s) => !s.dead && s[SLOT_K[GEAR[g].slot]] === g).length;
  /* 정보 열람 비용(관찰 수치) */
  const unlCost = (R, k) => { const G = GR[ENT[R.e].tier]; return k === 'p' ? G.pc : k === 'r' ? G.rc : k === 'b' ? G.bc : [2, 4][R.un.j] || 0; };
  const binom = (n, k) => { let c = 1; for (let i = 0; i < k; i++) c = c * (n - i) / (i + 1); return c; };
  const pLe = (p, k) => { let s = 0; for (let i = 0; i <= k; i++) s += binom(NB, i) * Math.pow(p, i) * Math.pow(1 - p, NB - i); return s; };
  const pBad = (p) => pLe(p, BAD), pGood = (p) => 1 - pLe(p, GOOD - 1);

  /* 이 작업이 어기는 수칙 번호들(출입 수칙만). onlyKnown이면 밝혀진 것만. turn: 작업을 시작할 차 */
  function vioList(S, ri, st, w, onlyKnown, turn) {
    const R = S.rooms[ri], E = ENT[R.e], out = [], t = turn || turnOf(S);
    E.rules.forEach((k, i) => { const r = RULES[k]; if (r.chk && (!onlyKnown || ruleKnown(R, i)) && r.chk(S, R, ri, st, w, t)) out.push(i); });
    return out;
  }
  function workP(S, ri, st, w, nv, pfAs, turn) {
    const R = S.rooms[ri], E = ENT[R.e], pf = pfAs != null ? pfAs : +E.pf[w];
    let p = PF_P[pf] + (st.st[WORKS[w].st] - 2) * 0.07 - GR[E.tier].pen + upLv(S, 'manual') * 0.03 + kwSum(st, 'foc', w) / 100;
    const wk = evFx(S, 'wk'); if (wk && wk[0] === w) p += wk[1];
    if (st.tr === 'timid') p += 0.05;
    if (st.tr === 'night' && (turn || turnOf(S)) >= 4) p += 0.08;
    if (nv) p -= 0.2;
    return clamp(p, 0.05, 0.95);
  }
  function energyOf(S, R, st) {
    return E_OUT[ENT[R.e].tier] * (1 + 0.1 * upLv(S, 'gen')) * (1 + (kwSum(st, 'hrv') + (st.tr === 'quick' ? 15 : 0)) / 100) * (evFx(S, 'en') || 1);
  }
  const QF = 2.6;
  function quotaOf(S) {
    const n = living(S).length, es = occupied(S).map((R) => E_OUT[ENT[R.e].tier]).sort((a, b) => b - a).slice(0, Math.max(2, n));
    return Math.round(es.reduce((a, b) => a + b, 0) * QF * (LEN[S.len].qm || 1) * (evFx(S, 'q') || 1)) + 3 * S.day;
  }
  const dmgAfter = (S, st, n, type) => {
    if (type === 'h') return Math.max(1, Math.round(n * (1 - Math.min(80, kwSum(st, 'grd')) / 100) * (st.tr === 'tough' ? 0.75 : 1)));
    return Math.max(1, Math.round(n * (1 - Math.min(80, kwSum(st, 'shd')) / 100) * (1 - 0.1 * upLv(S, 'sed')) * (st.tr === 'dull' ? 0.75 : st.tr === 'timid' ? 1.25 : 1)));
  };
  function supPower(S, st) { return 5 + 2 * st.st[0] + kwSum(st, 'pow') + (st.tr === 'brawl' ? 4 : 0); }
  function supMult(st, E) { const t = st.wp ? GEAR[st.wp].dt : 'h', wk = weakOf(E); return t === 'b' ? 1.1 : wk === t ? 1.3 : E.dt === t ? 0.75 : 1; }
  function eta(S, st, tf, tx) { const d = st.f === tf ? Math.abs(st.x - tx) : Math.abs(st.x - EX) + Math.abs(tx - EX); return d / speedOf(S, st) + Math.abs(st.f - tf) * liftT(S); }

  /* ================= 진행 ================= */
  function freeFace(S, role) {
    const used = S.staff.map((s) => s.fc).concat((S.hire || []).map((c) => c.fc));
    let c = [0, 1, 2, 3].map((k) => role * 4 + k).filter((f) => !used.includes(f));
    if (!c.length) { const alive = living(S).map((s) => s.fc).concat((S.hire || []).map((x) => x.fc)); c = [0, 1, 2, 3].map((k) => role * 4 + k).filter((f) => !alive.includes(f)); }
    return c.length ? pickOf(c) : -1;
  }
  function mkStaff(S, role, tr, fc, stv) {
    const st = stv ? stv.slice() : [1, 1, 1, 1].map(() => 1 + rnd(2)); if (!stv) st[role] = 3;
    const again = S.staff.filter((s) => s.fc === fc).length;
    const o = { id: S.sid++, n: FACE_N(fc) + (again ? ' ' + (again + 1) : ''), role, fc, st, xp: [0, 0, 0, 0], tr: tr || pickOf(TRK), wp: null, ar: null, ac: null, pn: 0, mk: -1, dead: 0, sd: 0, lk: 0, hp: 0, sp: 0, f: 0, x: 0, lt: 0, a: null, q: null, dl: [], wx: 0 };
    o.hp = hpMax(o); o.sp = spMax(o); o.x = restX(o);
    return o;
  }
  function mkRoom() { return { e: null, g: 0, pt: 0, un: { p: [0, 0, 0, 0], b: 0, j: 0 }, ls: -1, lw: -1, lr: -1, dn: 0, df: 0, ds: [], dk: [0, 0, 0, 0], fw: -1, de: 0, idle: 0, out: 0, wk: -1, vio: [0, 0, 0], rv: [0, 0, 0], wc: [0, 0, 0] }; }
  function place(S, ei, hint) {
    const i = S.rooms.findIndex((r, k) => r.e == null && k < roomsOpen(S)); if (i < 0) return -1;
    S.rooms[i] = Object.assign(mkRoom(), { e: ei });
    if (hint) S.rooms[i].un.p[ENT[ei].pf.indexOf('2')] = 1;
    abHook(S, i, 'onPlace');
    return i;
  }
  function genCand(S) {
    const have = occupied(S).map((R) => R.e), f = S.days > 1 ? (S.day - 1) / (S.days - 1) : 0;
    const tw = [0, Math.max(0, 1 - 2.8 * f), Math.max(0.1, 1 - Math.abs(f - 0.25) * 2.6), Math.max(0.05, 1 - Math.abs(f - 0.5) * 2.4), f > 0.3 ? (f - 0.2) * 1.5 : 0, f > 0.55 ? (f - 0.5) * 1.4 : 0];   // 날이 갈수록 높은 등급
    const pool = ENT.map((E, i) => i).filter((i) => !have.includes(i)), out = [];
    while (out.length < 3 && pool.length) {
      const ws = pool.map((i) => tw[ENT[i].tier] + 0.02); let x = Math.random() * ws.reduce((a, b) => a + b, 0), k = 0;
      while (k < ws.length - 1 && (x -= ws[k]) > 0) k++;
      out.push(pool.splice(k, 1)[0]);
    }
    return out;
  }
  function genHire(S) {
    S.hire = []; const out = [];
    for (const role of shuf([0, 1, 2, 3])) {
      if (out.length >= 3) break;
      const fc = freeFace(S, role); if (fc < 0) continue;
      const st = [1, 1, 1, 1].map(() => 1 + rnd(2)); st[role] = 3;
      out.push({ role, st, tr: pickOf(TRK), fc }); S.hire = out;
    }
    return out;
  }
  const evAdd = (S, c, t, r) => { S.last.ev.push({ c, t, r: r == null ? -1 : r }); S.log.push([S.day, S.turn, c, t]); if (S.log.length > 44) S.log.splice(0, S.log.length - 44); };
  const fx = (S, o) => { if (S.last.fx.length < 60) S.last.fx.push(o); };

  function bump(S, ri, n) { const R = S.rooms[ri]; if (R.e == null || R.out) return; R.g = Math.max(0, R.g + n); }
  function passiveHit(S, R, i, ri, txt, n) {
    const E = ENT[R.e]; R.vio[i]++; bump(S, ri, n);
    if (!ruleKnown(R, i) && R.vio[i] >= 2) { R.rv[i] = 1; evAdd(S, 'warn', E.no + ' ' + txt + ' 게이지 +' + n + '. 사례 대조로 수칙 확인: ' + RULES[E.rules[i]].n + '.', ri); }
    else evAdd(S, 'warn', E.no + ' ' + (ruleKnown(R, i) ? txt : '원인 미확인의 동요.') + ' 게이지 +' + n + '.', ri);
  }
  /* 수칙 k를 가진 격리 중인 방마다 fn(R, i, ri) */
  /* 갈고리 부르기 — 수칙(격리 중인 모든 방의 모든 수칙 중 그 갈고리가 있는 것) · 이형체(그 방 이형체의 고유 갈고리). 요소 쪽 오류가 판을 멈추지 않게 감싼다 */
  function ruleHook(S, name, except, a, b, c) {
    S.rooms.forEach((R, ri) => {
      if (R.e == null || R.out || ri === except) return;
      ENT[R.e].rules.forEach((k, i) => { const r = RULES[k]; if (r[name]) { try { r[name](S, R, i, ri, a, b, c); } catch (err) { ctWarn('수칙 ' + k + '.' + name + ': ' + err.message); } } });
    });
  }
  function abHook(S, ri, name, a, b, c) {
    const R = S.rooms[ri]; if (!R || R.e == null) return undefined;
    const h = ENT[R.e].hooks; if (!h || !h[name]) return undefined;
    try { return h[name](S, R, ri, a, b, c); } catch (err) { ctWarn('이형체 ' + ENT[R.e].id + '.' + name + ': ' + err.message); return undefined; }
  }
  function popQ(st) { st.a = st.q || null; st.q = null; }
  function dropAct(S, st) {
    const a = st.a;
    if (a && a.k === 'w' && a.ph === 1) { const R = S.rooms[a.r]; R.wk = -1; if (R.e != null && !R.out) { bump(S, a.r, 1); evAdd(S, 'warn', ENT[R.e].no + ' 작업 중단. 게이지 +1.', a.r); } }
    st.a = null; st.q = null;
  }
  function hurt(S, st, n, type) {
    if (st.dead || n <= 0) return '';
    let dh = 0, ds = 0;
    if (type === 'h') dh = dmgAfter(S, st, n, 'h'); else if (type === 's') ds = dmgAfter(S, st, n, 's'); else { dh = dmgAfter(S, st, n * 0.7, 'h'); ds = dmgAfter(S, st, n * 0.7, 's'); }
    if (dh >= st.hp && !st.lk && kwSum(st, 'lck')) { st.lk = 1; dh = Math.max(0, Math.ceil(st.hp) - 1); }
    st.hp -= dh; st.sp -= ds;
    fx(S, { k: 'dmg', s: st.id, h: dh, m: ds });
    let t = st.n + (dh ? ' 체력 −' + dh : '') + (dh && ds ? ',' : '') + (ds ? ' 정신 −' + ds : '') + '.';
    if (st.hp <= 0) {
      st.hp = 0; dropAct(S, st); st.dead = 1; st.pn = 0; S.stat.lost++;
      t += ' ' + st.n + ' 사망.';
      S.staff.forEach((o) => { if (!o.dead) o.sp = Math.max(1, o.sp - 4); });
      S._grief = 1; fx(S, { k: 'dead', s: st.id });
    } else if (st.sp <= 0) {
      if (st.tr === 'steady' && !st.sd) { st.sd = 1; st.sp = 1; t += ' 침착함으로 버팀.'; }
      else if (!st.pn) { st.sp = 0; dropAct(S, st); st.pn = PANIC; st.wx = st.x; t += ' ' + st.n + ' 공황.'; S._grief = 1; S.stat.panic++; fx(S, { k: 'panic', s: st.id }); }
      else st.sp = 0;
    }
    return t;
  }
  function gainXp(S, st, k) {
    if (st.st[k] >= 5) return '';
    st.xp[k]++;
    if (st.xp[k] >= Math.max(1, 2 * st.st[k] - upLv(S, 'gym'))) { st.xp[k] = 0; st.st[k]++; if (k === 0) st.hp += 6; if (k === 3) st.sp += 6; return ' ' + st.n + ' ' + STN[k] + ' ' + st.st[k] + '.'; }
    return '';
  }
  const near = (a, b) => Math.abs(a - b) <= 0.6;
  function stepMove(S, o, tf, tx, sp) {
    if (o.f !== tf) {
      if (!near(o.x, EX)) { o.x = r1(o.x + clamp(EX - o.x, -sp, sp)); o.lt = 0; return false; }
      o.x = EX; o.lt = (o.lt || 0) + 1; if (o.lt >= liftT(S)) { o.f += tf > o.f ? 1 : -1; o.lt = 0; } return false;
    }
    o.lt = 0;
    if (!near(o.x, tx)) o.x = r1(o.x + clamp(tx - o.x, -sp, sp));
    if (near(o.x, tx)) { o.x = tx; return true; }
    return false;
  }

  function startWork(S, st, a) {
    const ri = a.r, R = S.rooms[ri], E = ENT[R.e], w = a.w, T = turnOf(S);
    const vio = vioList(S, ri, st, w, false, T);
    R.wk = st.id; a.ph = 1; a.t = 0; a.b = ''; a.en = 0; a.nv = vio.length; a.p = Math.round(workP(S, ri, st, w, vio.length, null, T) * 100) / 100;
    fx(S, { k: 'start', r: ri, s: st.id });
    vio.forEach((i) => {
      R.vio[i]++; R.pt += 1; bump(S, ri, 2);
      const kn = ruleKnown(R, i);
      if (!kn && R.vio[i] >= 2) { R.rv[i] = 1; evAdd(S, 'warn', E.no + ' 수칙 위반. 게이지 +2. 사례 대조로 수칙 확인: ' + RULES[E.rules[i]].n + '.', ri); }
      else evAdd(S, 'warn', E.no + ' 수칙 위반' + (kn ? '(' + RULES[E.rules[i]].n + ')' : '(원인 미확인)') + '. 게이지 +2.', ri);
    });
    ruleHook(S, 'anyStart', -1, st, ri);
    E.rules.forEach((k, i) => { if (RULES[k].workStart) RULES[k].workStart(S, R, i, ri, st, a); });
    abHook(S, ri, 'onWorkStart', st, a);
    R.ls = st.id; R.lw = w; R.lr = st.role; R.dn++; if (w === 2) R.df++; if (!R.ds.includes(st.id)) R.ds.push(st.id); R.dk[w]++; if (R.fw < 0) R.fw = w; R.idle = -1;
    if (!st.dl.includes(ri)) st.dl.push(ri);
  }
  function finishWork(S, st, a) {
    const ri = a.r, R = S.rooms[ri], E = ENT[R.e], W = WORKS[a.w], pf = +E.pf[a.w];
    let s = 0; for (const c of a.b) if (c === '1') s++;
    const gr = s >= GOOD ? 2 : s <= BAD ? 0 : 1;
    let g = 0, t = st.n + ', ' + E.no + ' ' + W.n + ' ' + GRADE[gr] + '(' + s + '/' + NB + '). 에너지 +' + Math.round(a.en) + '.';
    const pts = Math.round(s * (a.w === 0 ? 1.5 : 1)) + (a.w === 0 ? 2 * upLv(S, 'lens') : 0) + kwSum(st, 'rec') + (st.tr === 'careful' ? 1 : 0) + evFx(S, 'rec');
    R.pt += pts; t += ' 관찰 수치 +' + pts + '.';
    if (gr > 0) {
      if (gr === 2 && pf === 2) g -= 1;
      const c = kwSum(st, 'clm'); if (c) st.sp = Math.min(spMax(st), st.sp + c);
      t += gainXp(S, st, W.st);
    } else {
      g += 1 + (pf === 0 ? 1 : 0);
      ruleHook(S, 'otherBad', ri, ri);
    }
    E.rules.forEach((k, i) => { if (RULES[k].workEnd) g += RULES[k].workEnd(S, R, i, ri, st, a, gr) || 0; });
    g += abHook(S, ri, 'onWorkEnd', st, a, gr) || 0;
    if (g) t += ' 게이지 ' + (g > 0 ? '+' : '−') + Math.abs(g) + '.';
    R.g = Math.max(0, R.g + g); R.wc[gr]++; S.dd[gr]++;
    evAdd(S, gr === 2 ? 'ok' : gr === 1 ? 'info' : 'bad', t, ri);
    fx(S, { k: 'done', r: ri, g: gr, e: Math.round(a.en) });
    R.wk = -1; popQ(st);
  }
  function breach(S, ri) {
    const R = S.rooms[ri], E = ENT[R.e], mx = brHp(S, E);
    S.staff.forEach((st) => { if (!st.dead && st.a && st.a.k === 'w' && st.a.r === ri) { st.a = null; st.q = null; } if (st.q && st.q.k === 'w' && st.q.r === ri) st.q = null; });
    R.out = 1; R.g = 0; R.wk = -1; S.br.push({ r: ri, hp: mx, mx, f: roomF(ri), x: roomX(ri), lt: 0, tx: roomX(ri), tf: roomF(ri), cd: 0 }); S.stat.esc++;
    evAdd(S, 'bad', E.no + ' ' + E.n + ' 격리 이탈. ' + ZONE[roomF(ri)] + ' 복도.', ri); fx(S, { k: 'breach', r: ri });
    ruleHook(S, 'otherBreach', ri, ri);
    abHook(S, ri, 'onBreach', S.br[S.br.length - 1]);
  }
  function burst(S, ri) {
    const R = S.rooms[ri], E = ENT[R.e], B = E.bu, alive = living(S);
    R.g = 0; S.stat.burst++; fx(S, { k: 'burst', r: ri });
    let t = E.no + ' ' + E.n + ' 이변 발생.';
    t += BURST[B.k].run(S, ri, B.v, alive) || '';
    evAdd(S, 'bad', t, ri);
  }
  function restAmt(S, st) { return (0.35 + 0.1 * upLv(S, 'lounge')) * (evFx(S, 'rest') || 1) * (st.tr === 'heal' ? 1.5 : 1); }
  const attackable = (st) => !st.dead && st.x > 0 && !(st.a && st.a.k === 'w' && st.a.ph === 1);

  function tickStaff(S, st) {
    if (st.pn) {   // 공황: 복도를 헤맨다
      if (inLounge(st)) st.wx = X0 + rnd(FW - X0);
      if (stepMove(S, st, st.f, st.wx, SPD * 0.5)) st.wx = X0 + rnd(FW - X0 - 20);
      return;
    }
    const a = st.a; if (!a) return;
    const sp = speedOf(S, st);
    if (a.k === 'w') {
      const R = S.rooms[a.r];
      if (!R || R.e == null || R.out) { popQ(st); return; }
      if (a.ph === 0) { if (stepMove(S, st, roomF(a.r), roomX(a.r), sp) && R.wk < 0) startWork(S, st, a); return; }
      a.t += 1 + kwSum(st, 'hst') / 100;
      if (a.t >= BOX_T) {
        a.t -= BOX_T;
        const ok = Math.random() < a.p; a.b += ok ? '1' : '0';
        fx(S, { k: 'box', r: a.r, ok: ok ? 1 : 0 });
        if (ok) { const e = energyOf(S, R, st) / NB; a.en += e; S.en += e; S.stat.en += e; R.de += e; }
        else { hurt(S, st, DMG[ENT[R.e].tier] * BOXD, ENT[R.e].dt); if (st.a !== a) return; }
        abHook(S, a.r, 'onBox', st, a, ok); if (st.a !== a) return;
        if (a.b.length >= NB) finishWork(S, st, a);
      }
    } else if (a.k === 's') {
      const b = brOf(S, a.r); if (!b) { popQ(st); return; }
      const off = 14 + (st.id % 3) * 8, tx = clamp(b.x + (st.id % 2 ? -off : off), 4, FW - 4);
      if (st.f !== b.f || Math.abs(st.x - tx) > 6) stepMove(S, st, b.f, tx, sp);
      if (st.f === b.f && Math.abs(st.x - b.x) <= REACH + 6) {
        a.cd = (a.cd || 0) + 1;
        if (a.cd >= HIT_T) {
          a.cd = 0;
          const E = ENT[S.rooms[b.r].e], d = Math.max(1, Math.round((supPower(S, st) + rnd(4)) * HIT_K * supMult(st, E) * (evFx(S, 'sup') || 1)));
          b.hp -= d; fx(S, { k: 'hit', r: b.r, d });
          const ab = kwSum(st, 'abs'); if (ab) st.hp = Math.min(hpMax(st), st.hp + ab / 4);
        }
      }
    } else if (a.k === 'c') {
      const t = S.staff.find((o) => o.id === a.s); if (!t || t.dead || !t.pn) { popQ(st); return; }
      if (st.f === t.f && Math.abs(st.x - t.x) <= 22) {
        a.t = (a.t || 0) + 1;
        if (a.t >= 12) {
          if (Math.random() < 0.45 + 0.12 * st.st[2]) { t.pn = 0; t.sp = Math.round(spMax(t) * 0.4); evAdd(S, 'ok', st.n + ', ' + t.n + ' 진정 완료.' + gainXp(S, st, 2)); fx(S, { k: 'calm', s: t.id }); popQ(st); }
          else { a.t = 0; a.n = (a.n || 0) + 1; evAdd(S, 'bad', st.n + ', ' + t.n + ' 진정 실패.'); if (a.n >= 2) popQ(st); }
        }
      } else stepMove(S, st, t.f, t.x, sp);
    } else if (a.k === 'r') {
      if (stepMove(S, st, 0, restX(st), sp)) {
        const r = restAmt(S, st) / SEG;
        st.hp = Math.min(hpMax(st), st.hp + hpMax(st) * r); st.sp = Math.min(spMax(st), st.sp + spMax(st) * r);
        if (st.hp >= hpMax(st) && st.sp >= spMax(st) && st.q) popQ(st);
      }
    } else if (a.k === 'm') {
      if (stepMove(S, st, a.f, a.x, sp)) popQ(st);
    } else st.a = null;
  }
  function tickBreach(S, b) {
    const R = S.rooms[b.r], E = ENT[R.e], K = BK[E.bk] || BK.hunt;
    if (b.hp <= 0) {
      R.out = 0; R.g = 0; R.pt += 4; R.idle = 0; b.done = 1;
      let t = E.no + ' 제압. 재격리 완료. 관찰 수치 +4.';
      S.staff.forEach((st) => { if (!st.dead && st.a && st.a.k === 's' && st.a.r === b.r) { t += gainXp(S, st, 0); popQ(st); } });
      evAdd(S, 'ok', t, b.r); fx(S, { k: 'recon', r: b.r }); abHook(S, b.r, 'onRecontain'); return;
    }
    b.cd++;
    const tg = S.staff.filter((st) => attackable(st) && st.f === b.f && Math.abs(st.x - b.x) <= REACH + 14);
    if (tg.length) {
      if (b.cd >= BR_T) {
        b.cd = 0; const n = GR[E.tier].hit; let t = '';
        tg.sort((p, q) => Math.abs(p.x - b.x) - Math.abs(q.x - b.x)).slice(0, n).forEach((st) => { const x = hurt(S, st, BR_ATK[E.tier] * BR_K, E.dt); if (/사망|공황/.test(x)) t += ' ' + x; });
        fx(S, { k: 'atk', r: b.r });
        if (t) evAdd(S, 'bad', E.no + '의 공격.' + t, b.r);
      }
      if (K.chaseStop !== false) return;
    }
    const goal = K.goal ? K.goal(S, b) : null;
    if (goal) { b.tf = goal.f; b.tx = goal.x; }
    if (stepMove(S, b, b.tf, clamp(b.tx, 6, FW - 6), BR_SPD * (K.speed || 1)) && !goal) { b.tx = X0 + rnd(FW - X0 - 20); b.tf = b.f; }
  }
  function stir(S, b) {
    const R = S.rooms[b.r], E = ENT[R.e], nearR = [];
    S.rooms.forEach((o, i) => { if (o.e != null && !o.out && roomF(i) === b.f) nearR.push(i); });
    if (nearR.length && Math.random() >= 0.3 * upLv(S, 'alarm')) { const i = pickOf(nearR); bump(S, i, 1); evAdd(S, 'warn', E.no + ', ' + ZONE[b.f] + '에서 ' + ENT[S.rooms[i].e].no + ' 자극. 게이지 +1.', i); }
  }
  /* 차가 넘어갈 때(T = 방금 끝난 차) */
  function segEnd(S, T) {
    const st1 = evFx(S, 'spTick') + (alertOf(S) >= 3 ? 2 : 0);
    living(S).forEach((s) => {
      const rg = kwSum(s, 'reg'), wl = kwSum(s, 'wil');
      if (rg) s.hp = Math.min(hpMax(s), s.hp + rg); if (wl && !s.pn) s.sp = Math.min(spMax(s), s.sp + wl);
      if (st1 && !s.pn) hurt(S, s, st1, 's');
    });
    S.staff.forEach((st) => {
      if (st.dead || !st.pn) return;
      if (st.pn < PANIC) {
        const x = Math.random(), occ = []; S.rooms.forEach((R, i) => { if (R.e != null && !R.out && roomF(i) === st.f) occ.push(i); });
        if (x < 0.3 && occ.length) { const i = pickOf(occ); bump(S, i, 1); evAdd(S, 'warn', st.n + ', 공황 상태로 ' + ENT[S.rooms[i].e].no + ' 격리실 문을 건드림. 게이지 +1.', i); }
        else if (x < 0.5) { const o = S.staff.filter((q) => !q.dead && q.id !== st.id && q.f === st.f && q.x > 0); if (o.length) evAdd(S, 'bad', st.n + ', 공황 상태로 동료를 밀침. ' + hurt(S, pickOf(o), 5, 'h')); }
      }
      st.pn--; if (st.pn <= 0 && !st.dead) { st.pn = 0; st.sp = Math.round(spMax(st) * 0.3); evAdd(S, 'info', st.n + ' 공황에서 회복.'); fx(S, { k: 'calm', s: st.id }); }
    });
    S.rooms.forEach((R, ri) => {
      if (R.e == null || R.out) return;
      const E = ENT[R.e];
      E.rules.forEach((k, i) => { if (RULES[k].seg) { try { RULES[k].seg(S, R, i, ri, T); } catch (err) { ctWarn('수칙 ' + k + '.seg: ' + err.message); } } });
      abHook(S, ri, 'onSeg', T);
      R.idle = R.idle < 0 ? 0 : R.idle + 1;
    });
    S.br.forEach((b) => { stir(S, b); const K = BK[ENT[S.rooms[b.r].e].bk]; if (K.seg) K.seg(S, b); });
    if (T === TURNS && S.br.length) evAdd(S, 'warn', '정규 근무 종료. 탈주한 이형체를 재격리할 때까지 연장 근무.');
  }
  function gameOver(S, win, title, text) { S.over = { win: win ? 1 : 0, title, text }; S.ph = 'end'; }
  function tick(S) {
    if (S.ph !== 'day' || S.over) return;
    setLay(S);
    S.t++; S.turn = turnOf(S);
    S._grief = 0;
    for (const st of S.staff) if (!st.dead) tickStaff(S, st);
    for (const b of S.br) tickBreach(S, b);
    S.br = S.br.filter((b) => !b.done);
    S.br.forEach((b) => { if (BK[ENT[S.rooms[b.r].e].bk].stirMid && S.t % SEG === SEG / 2) stir(S, b); });
    S.rooms.forEach((R, ri) => { if (R.e != null && !R.out && ENT[R.e].hooks && ENT[R.e].hooks.onTick) abHook(S, ri, 'onTick'); });
    if (S.t % SEG === 0) segEnd(S, S.t / SEG);
    if (S._grief) ruleHook(S, 'grief', -1);
    delete S._grief;
    for (let pass = 0; pass < 2; pass++) S.rooms.forEach((R, ri) => {
      if (R.e == null || R.out || R.g < gMax(S, R)) return;
      if (abHook(S, ri, 'onGaugeFull') === true) { R.g = Math.min(R.g, gMax(S, R) - 1); return; }   // 갈고리가 true를 돌려주면 스스로 처리한 것
      if (ENT[R.e].esc) breach(S, ri); else burst(S, ri);
    });
    S.turn = turnOf(S);
    if (!living(S).length) return gameOver(S, false, '직원 전원 손실', '남은 직원이 없다. 시설은 봉쇄되었다.');
    if (S.br.length >= 3) return gameOver(S, false, '동시 탈주 3건', '세 개체가 동시에 격리를 벗어났다. 시설은 봉쇄되었다.');
    if (S.t >= TURNS * SEG && !S.br.length) endDay(S);
  }

  function endDay(S) {
    const met = S.en >= S.quota, lines = [], used = Math.ceil(S.t / SEG), en = Math.floor(S.en);
    S.stat.days = S.day;
    if (met) {
      const early = Math.max(0, TURNS - used), sur = Math.floor((en - S.quota) / 4) * (evFx(S, 'surplus') || 1), base = 10 + 2 * occupied(S).length, qr = evFx(S, 'qr');
      S.bud += base + early * 3 + sur + qr;
      lines.push('목표 달성: 에너지 ' + en + ' / ' + S.quota + '.', '비축 에너지 +' + (base + early * 3 + sur + qr) + ' (기본 ' + base + (early ? ' · 조기 마감 ' + early * 3 : '') + (sur ? ' · 초과분 ' + sur : '') + (qr ? ' · 감사 통과 ' + qr : '') + ').');
    } else {
      S.warn++; S.bud += 6;
      lines.push('목표 미달: 에너지 ' + en + ' / ' + S.quota + '.', '본부 경고 ' + S.warn + ' / 3. 비축 에너지 +6.');
      if (S.warn >= 3) { evAdd(S, 'bad', '본부 경고 3회 누적.'); return gameOver(S, false, '본부 경고 3회', '목표 미달이 세 번 쌓였다. 본부가 시설 운영권을 회수했다.'); }
    }
    if (S.day >= S.days) { evAdd(S, 'ok', '마지막 근무일 종료.'); return gameOver(S, true, '운영 기간 만료', S.days + '일의 운영을 마쳤다. 시설은 다음 관리자에게 인계된다.'); }
    const h = 0.35 + 0.15 * upLv(S, 'med');
    S.staff.forEach((st) => {
      if (st.dead) return;
      const a = h * (st.tr === 'heal' ? 1.5 : 1);
      if (st.pn) { st.pn = 0; st.sp = Math.round(spMax(st) * 0.4); }
      st.hp = Math.min(hpMax(st), st.hp + Math.round(hpMax(st) * a)); st.sp = Math.min(spMax(st), st.sp + Math.round(spMax(st) * a)); st.mk = -1; st.sd = 0; st.lk = 0;
      st.a = null; st.q = null; st.f = 0; st.x = restX(st); st.lt = 0;
    });
    S.rooms.forEach((R) => { R.wk = -1; });
    lines.push('작업 ' + (S.dd[0] + S.dd[1] + S.dd[2]) + '회 — 좋음 ' + S.dd[2] + ' · 보통 ' + S.dd[1] + ' · 나쁨 ' + S.dd[0] + '.', '직원 회복 ' + Math.round(h * 100) + '%. 이형체의 게이지는 그대로 남는다.');
    S.sum = lines; genHire(S); S.ph = 'night';
    evAdd(S, 'day', S.day + '일째 마감. ' + lines[0]);
  }
  function startDay(S) {
    S.day++; S.t = 0; S.turn = 1; S.en = 0; S.sum = null; S.dd = [0, 0, 0];
    S.rooms.forEach((R) => { R.dn = 0; R.df = 0; R.ds = []; R.dk = [0, 0, 0, 0]; R.fw = -1; R.de = 0; R.wc = [0, 0, 0]; });
    S.staff.forEach((st) => { st.dl = []; });
    let fo = 0; for (let f = 0; f < S.floors; f++) if (openDay(f) <= S.day) fo++;
    S.evt = rnd(EVENTS.length);
    const F = EVENTS[S.evt].fx, occ = []; S.rooms.forEach((R, i) => { if (R.e != null) occ.push(i); });
    evAdd(S, 'day', S.day + '일째. 사건: ' + EVENTS[S.evt].n + ' — ' + EVENTS[S.evt].d);
    if (fo > S.fo) { S.fo = fo; evAdd(S, 'day', ZONE[fo - 1] + ' 개방. 격리실 ' + PER + '칸 추가.'); fx(S, { k: 'zone', f: fo - 1 }); }
    if (F.g) occ.forEach((i) => { const R = S.rooms[i]; R.g = clamp(R.g + F.g, 0, gMax(S, R) - 1); });
    if (F.gHi) occ.forEach((i) => { const R = S.rooms[i]; if (ENT[R.e].tier >= 4) R.g = clamp(R.g + 1, 0, gMax(S, R) - 1); });
    if (F.oneG && occ.length) { const R = S.rooms[pickOf(occ)]; R.g = clamp(R.g + F.oneG, 0, gMax(S, R) - 1); }
    if (F.sp) living(S).forEach((s) => { s.sp = Math.min(spMax(s), s.sp + F.sp); });
    if (F.oneSp) { const a = living(S); if (a.length) { const s = pickOf(a); s.sp = Math.max(1, s.sp - F.oneSp); } }
    if (F.bud) S.bud = Math.max(0, S.bud + F.bud);
    S.rooms.forEach((R, i) => { if (R.e != null) abHook(S, i, 'onDayStart'); });
    enterDay(S);
  }
  function enterDay(S) {
    if (S.rooms.some((R, i) => R.e == null && i < roomsOpen(S))) { S.cand = genCand(S); if (S.cand.length) { S.ph = 'pick'; return; } }
    S.ph = 'day'; S.quota = quotaOf(S);
  }

  function init(players, opts) {
    const len = LEN[(opts && opts.len)] ? opts.len : 'M', C = LEN[len];
    PER = C.per; FW = X0 + PER * RP;
    const S = { v: 3, seed: 1 + rnd(1e6), len, per: C.per, days: C.days, floors: C.floors, fo: 1, day: 1, t: 0, turn: 1, ph: 'pick', en: 0, quota: 0, bud: 20, warn: 0,
      rooms: [], staff: [], sid: 1, br: [], up: {}, gear: {}, cand: [], hire: [], evt: null, log: [], last: { id: 0, ev: [], fx: [] }, sum: null, over: null, dd: [0, 0, 0],
      stat: { en: 0, esc: 0, burst: 0, lost: 0, panic: 0, days: 0, gear: 0 } };
    for (let i = 0; i < C.floors * PER; i++) S.rooms.push(mkRoom());
    const t1 = shuf(ENT.map((E, i) => i).filter((i) => ENT[i].tier === 1));
    place(S, t1[0], true); place(S, t1[1], true);
    for (let r = 0; r < 4; r++) S.staff.push(mkStaff(S, r, null, r * 4 + rnd(4)));
    evAdd(S, 'day', '1일째. 제3 보관동 운영 개시. 직원 ' + S.staff.length + '명, 이형체 2건 인수.');
    enterDay(S);
    return S;
  }
  const actor = (S) => (S.over ? null : 0);

  /* 지시 · 그 밖의 행동(틱이 아닌 것). 안 되면 throw */
  function order(S, o) {
    if (S.ph !== 'day') throw new Error('근무 중이 아님');
    const st = S.staff.find((x) => x.id === o.s); if (!st || st.dead) throw new Error('직원 없음');
    if (st.pn) throw new Error('공황 상태');
    let A = null;
    if (o.k === 'w') { const R = S.rooms[o.r]; if (!R || R.e == null || R.out || !(o.w >= 0 && o.w < 4)) throw new Error('작업 불가'); A = { k: 'w', r: o.r | 0, w: o.w | 0, ph: 0 }; }
    else if (o.k === 's') { if (!brOf(S, o.r)) throw new Error('탈주 중이 아님'); A = { k: 's', r: o.r | 0, cd: 0 }; }
    else if (o.k === 'c') { const t = S.staff.find((x) => x.id === o.c); if (!t || t.dead || !t.pn || t.id === st.id) throw new Error('진정 불가'); A = { k: 'c', s: t.id, t: 0 }; }
    else if (o.k === 'r') A = { k: 'r' };
    else if (o.k === 'm') { const f = clamp(o.f | 0, 0, S.fo - 1); A = { k: 'm', f, x: r1(clamp(+o.x || 0, f === 0 ? LX0 + 10 : 6, FW - 6)) }; }
    else if (o.k === 'x') { if (st.a && st.a.k === 'w' && st.a.ph === 1) { st.q = null; return; } st.a = null; st.q = null; return; }
    else throw new Error('모르는 지시');
    if (st.a && st.a.k === 'w' && st.a.ph === 1) st.q = A; else { st.a = A; st.q = null; }
  }
  function act(S, a) {
    setLay(S);
    if (S.over) throw new Error('끝난 판');
    if (!a || !a.t) throw new Error('행동 없음');
    if (a.t === 'pick') {
      if (S.ph !== 'pick' || !(a.i >= 0 && a.i < S.cand.length)) throw new Error('고를 수 없음');
      const ei = S.cand[a.i], ri = place(S, ei, true); S.cand = [];
      evAdd(S, 'info', ENT[ei].no + ' ' + ENT[ei].n + ' 인수. ' + TIER[ENT[ei].tier].n + ' 등급.', ri);
      S.ph = 'day'; S.quota = quotaOf(S);
    } else if (a.t === 'ord') order(S, a);
    else if (a.t === 'auto') { if (S.ph !== 'day') throw new Error('근무 중이 아님'); planOrders(S, 3, habits(S.seed), true).forEach((o) => { try { order(S, o); } catch (e) {} }); }
    else if (a.t === 'end') {
      if (S.ph !== 'day' || S.en < S.quota || S.br.length) throw new Error('아직 마감할 수 없음');
      endDay(S);
    } else if (a.t === 'unl') {
      const R = S.rooms[a.r]; if (!R || R.e == null || S.ph === 'end') throw new Error('열람 불가');
      const E = ENT[R.e], c = unlCost(R, a.k);
      if (a.k === 'p') { if (!(a.i >= 0 && a.i < 4) || R.un.p[a.i]) throw new Error('이미 열람'); }
      else if (a.k === 'r') { if (!(a.i >= 0 && a.i < E.rules.length) || R.rv[a.i]) throw new Error('이미 열람'); }
      else if (a.k === 'b') { if (R.un.b) throw new Error('이미 열람'); }
      else if (a.k === 'j') { if (R.un.j >= 2) throw new Error('이미 열람'); }
      else throw new Error('모르는 항목');
      if (R.pt < c) throw new Error('관찰 수치 부족');
      R.pt -= c;
      if (a.k === 'p') R.un.p[a.i] = 1; else if (a.k === 'r') R.rv[a.i] = 1; else if (a.k === 'b') R.un.b = 1; else R.un.j++;
    } else if (a.t === 'ext') {
      const G = GEAR[a.g]; if (!G || S.ph === 'end') throw new Error('추출 불가');
      const R = S.rooms.find((r) => r.e === G.ei); if (!R || R.out) throw new Error('격리 중이 아님');
      if ((S.gear[a.g] || 0) >= G.lim) throw new Error('수량 한도');
      if (R.pt < G.pt || S.bud < G.cost) throw new Error('자원 부족');
      R.pt -= G.pt; S.bud -= G.cost; S.gear[a.g] = (S.gear[a.g] || 0) + 1; S.stat.gear++;
      evAdd(S, 'info', ENT[G.ei].no + '에서 ' + G.n + ' 추출.', S.rooms.indexOf(R));
    } else if (a.t === 'equip') {
      const G = GEAR[a.g], st = S.staff.find((o) => o.id === a.s && !o.dead); if (!G || !st || S.ph === 'end') throw new Error('장착 불가');
      if (st.a && st.a.k === 'w' && st.a.ph === 1) throw new Error('작업 중');
      const k = SLOT_K[G.slot]; if (st[k] === a.g) return; if (gearFree(S, a.g) < 1) throw new Error('남은 것이 없음');
      st[k] = a.g; st.hp = Math.min(st.hp, hpMax(st)); st.sp = Math.min(st.sp, spMax(st));
    } else if (a.t === 'uneq') {
      const st = S.staff.find((o) => o.id === a.s && !o.dead), k = SLOT_K[a.slot]; if (!st || !k || S.ph === 'end') throw new Error('해제 불가');
      if (st.a && st.a.k === 'w' && st.a.ph === 1) throw new Error('작업 중');
      st[k] = null; st.hp = Math.min(st.hp, hpMax(st)); st.sp = Math.min(st.sp, spMax(st));
    } else if (a.t === 'hire') {
      const c = S.hire[a.i]; if (S.ph !== 'night' || !c) throw new Error('채용 불가');
      const cost = hireCost(S, c); if (S.bud < cost || living(S).length >= staffCap(S)) throw new Error('채용 불가');
      S.bud -= cost; S.hire.splice(a.i, 1); S.staff.push(mkStaff(S, c.role, c.tr, c.fc, c.st));
    } else if (a.t === 'up') {
      const u = UPS.find((x) => x.id === a.id); if (S.ph !== 'night' || !u || upLv(S, u.id) >= u.mx || S.bud < upCost(S, u)) throw new Error('강화 불가');
      S.bud -= upCost(S, u); S.up[u.id] = upLv(S, u.id) + 1;
    } else if (a.t === 'next') {
      if (S.ph !== 'night') throw new Error('아직 근무 중');
      startDay(S);
    } else throw new Error('모르는 행동');
  }
  function apply(S, seat, a) {
    if (S.over) throw new Error('끝난 판');
    S.last = { id: S.last.id + 1, ev: [], fx: [] };
    if (a && a.t === 'tick') {
      if (S.ph !== 'day') throw new Error('근무 중이 아님');
      (a.o || []).forEach((o) => { try { act(S, o); } catch (e) {} });
      for (let i = 0, n = clamp(a.n | 0, 1, 80); i < n && S.ph === 'day'; i++) tick(S);
    } else act(S, a);
    return S;
  }

  /* ================= AI · 추천 지시 ================= */
  function habits(seed) { let x = seed | 0; const r = () => { x = (x * 1103515245 + 12345) & 0x7fffffff; return x / 0x7fffffff; }; return { care: 0.8 + r() * 0.6, fear: 0.8 + r() * 0.6, curio: 0.6 + r() * 1.2, rest: 0.32 + r() * 0.12, thrift: r(), upOrd: r(), greed: r(), arm: r() }; }
  /* 지금 손이 빈 직원들에게 줄 지시 목록. 밝혀진 정보만 쓴다. idleOnly: 쉬는 직원은 건드리지 않음(사람의 「추천」) */
  function planOrders(S, lv, hb, idleOnly) {
    const out = [], used = {}, T = turnOf(S), noise = lv === 1 ? 6 : lv === 2 ? 2 : 0.4;
    const cand = S.staff.filter((st) => avail(st) && (!st.a || (!idleOnly && st.a.k === 'r' && inLounge(st) && frac(st) > 0.78 && !st.q)));
    const take = (st, o) => { o.t = 'ord'; o.s = st.id; out.push(o); used[st.id] = 1; };
    const restTh = hb.rest * (S.br.length ? 0.7 : 1);
    cand.forEach((st) => { if (frac(st) < restTh) { if (!st.a) take(st, { k: 'r' }); else used[st.id] = 1; } });
    // 제압
    S.br.slice().sort((a, b) => a.hp - b.hp).forEach((b) => {
      const E = ENT[S.rooms[b.r].e], on = S.staff.filter((s) => !s.dead && s.a && s.a.k === 's' && s.a.r === b.r);
      let dps = on.reduce((n, s) => n + supPower(S, s) * supMult(s, E), 0), n = on.length; const max = lv === 1 ? 2 : 4, need = b.hp * 1.1 + 14;
      const c = cand.filter((s) => !used[s.id] && s.hp > BR_ATK[E.tier] * BR_K * 3 && (E.dt === 'h' || s.sp > BR_ATK[E.tier] * BR_K * 3)).sort((x, y) => supPower(S, y) * supMult(y, E) - supPower(S, x) * supMult(x, E));
      for (const st of c) { if (n >= max || (dps >= need && n >= 1)) break; take(st, { k: 's', r: b.r }); dps += supPower(S, st) * supMult(st, E); n++; }
    });
    // 진정
    const pn = S.staff.filter((s) => !s.dead && s.pn >= 2 && !S.staff.some((o) => o.a && o.a.k === 'c' && o.a.s === s.id));
    if (pn.length && lv >= 2) { const c = cand.filter((s) => !used[s.id]).sort((x, y) => y.st[2] - x.st[2])[0]; if (c && c.st[2] >= 2) take(c, { k: 'c', c: pn[0].id }); }
    // 작업: (직원, 방, 작업) 점수가 가장 높은 것부터
    const over = S.en >= S.quota, roomUsed = {};
    S.staff.forEach((s) => { if (s.dead) return; if (s.a && s.a.k === 'w') roomUsed[s.a.r] = 1; if (s.q && s.q.k === 'w') roomUsed[s.q.r] = 1; });
    for (;;) {
      let best = null, bs = lv === 1 ? -2 : 0.5;
      cand.forEach((st) => {
        if (used[st.id]) return;
        S.rooms.forEach((R, ri) => {
          if (R.e == null || R.out || roomUsed[ri]) return;
          const E = ENT[R.e], D = DMG[E.tier], gLeft = gMax(S, R) - R.g, et = eta(S, st, roomF(ri), roomX(ri)), tA = Math.floor((S.t + et) / SEG) + 1;
          const worst = NB * BOXD * D * (E.dt === 'b' ? 0.7 : 1) * 0.75;
          if (lv >= 2 && ((E.dt !== 's' && st.hp <= worst + 1) || (E.dt !== 'h' && st.sp <= worst + 1))) return;
          for (let w = 0; w < 4; w++) {
            const kn = prefKnown(R, w), pf = kn ? +E.pf[w] : 1, v = vioList(S, ri, st, w, true, tA);
            if (v.length && (lv >= 2 || Math.random() < 0.6)) continue;
            const p = workP(S, ri, st, w, v.length, pf, tA), en = energyOf(S, R, st), bad = pBad(p);
            let sc = (over ? 0.15 : 1) * p * en;
            sc -= (1 - p) * NB * BOXD * D * 0.33 * hb.care * (frac(st) < 0.55 ? 1.6 : 1);
            const failAdd = 1 + (kn && pf === 0 ? 1 : 0);
            if (gLeft <= failAdd) sc -= bad * (E.esc ? 8 + 5 * E.tier : 5 + 2.5 * E.tier) * hb.fear;
            else if (gLeft <= failAdd + 1) sc -= bad * 3 * hb.fear;
            if (kn && pf === 2 && R.g > 0) sc += pGood(p) * (gLeft <= 2 ? 6 : 2);
            if (!kn) sc += 0.6 * hb.curio;
            if (w === 0 && R.pt < 12 && (R.rv.slice(0, E.rules.length).some((x) => !x) || R.un.p.some((x) => !x))) sc += 1.8 * hb.curio;
            E.rules.forEach((k, i) => {
              if (!ruleKnown(R, i)) return;
              if (RULES[k].ai) sc += RULES[k].ai(S, R, ri, st, w, T, gLeft, lv) || 0;   // 수칙이 알려 주는 「지금 이 작업을 하고 싶은 정도」
            });
            if (st.mk >= 0 && st.mk !== ri && lv >= 2) sc -= 5;
            sc -= et / SEG * 1.5;
            sc += (Math.random() - 0.5) * noise;
            if (sc > bs) { bs = sc; best = { st, ri, w }; }
          }
        });
      });
      if (!best) break;
      take(best.st, { k: 'w', r: best.ri, w: best.w }); roomUsed[best.ri] = 1;
    }
    cand.forEach((st) => { if (!used[st.id] && !st.a && (frac(st) < 0.98 || (S.br.length && !inLounge(st)))) take(st, { k: 'r' }); });
    return out;
  }
  /* 관찰 수치 · 비축 에너지 쓰기(열람 · 추출 · 장착). 한 번에 하나 */
  function aiSpend(S, lv, hb) {
    const alive = living(S);
    for (const g in S.gear) if (gearFree(S, g) > 0) {
      const G = GEAR[g], k = SLOT_K[G.slot], c = alive.filter((s) => !s[k] && !(s.a && s.a.k === 'w' && s.a.ph === 1)).sort((a, b) => (G.slot === 'w' ? b.st[0] - a.st[0] : a.hp + a.sp - b.hp - b.sp))[0];
      if (c) return { t: 'equip', g, s: c.id };
    }
    for (let ri = 0; ri < S.rooms.length; ri++) {
      const R = S.rooms[ri]; if (R.e == null) continue;
      const E = ENT[R.e];
      for (let i = 0; i < E.rules.length; i++) if (!R.rv[i]) { if (R.pt >= unlCost(R, 'r')) return { t: 'unl', r: ri, k: 'r', i }; if (lv >= 2) break; }
      if (R.rv.slice(0, E.rules.length).some((x) => !x) && lv >= 2) continue;
      for (let w = 0; w < 4; w++) if (!R.un.p[w] && R.pt >= unlCost(R, 'p')) return { t: 'unl', r: ri, k: 'p', i: w };
      if (R.un.p.some((x) => !x)) continue;
      if (lv === 1) continue;
      const keep = Math.round(hb.thrift * 6) + (S.ph === 'day' ? 14 : 0);
      for (const sl of (hb.arm < 0.5 ? ['w', 'a', 'x'] : ['a', 'w', 'x'])) {
        const g = R.e + sl, G = GEAR[g]; if (!G || R.out) continue;
        if ((S.gear[g] || 0) < G.lim && R.pt >= G.pt && S.bud - keep >= G.cost && alive.some((s) => !s[SLOT_K[sl]])) return { t: 'ext', g };
      }
      if (!R.un.b && R.pt >= unlCost(R, 'b') + 6) return { t: 'unl', r: ri, k: 'b' };
    }
    return null;
  }
  function ai(S, seat, lv) {
    setLay(S);
    lv = lv || 2; const hb = habits(S.seed);
    if (S.ph === 'pick') {
      const sc = S.cand.map((ei) => { const E = ENT[ei]; return (hb.fear > 1.1 ? -E.tier * 2 : E.tier * (lv === 1 ? 2 : 0.6)) - (lv >= 2 && E.tier >= 5 && living(S).length < 5 ? 3 : 0) + (E.esc ? 0 : 0.5) + Math.random() * (lv === 3 ? 0.6 : 2); });
      return { t: 'pick', i: sc.indexOf(Math.max.apply(null, sc)) };
    }
    if (S.ph === 'day') {
      const T = turnOf(S), risky = S.rooms.some((R) => R.e != null && !R.out && R.g >= gMax(S, R) - 1);
      if (S.en >= S.quota && !S.br.length && (lv === 1 || hb.greed < 0.55 || risky || T >= 4)) return { t: 'end' };
      const o = planOrders(S, lv, hb), sp = aiSpend(S, lv, hb); if (sp) o.push(sp);
      return { t: 'tick', n: lv === 1 ? 12 : 8, o };
    }
    if (S.ph === 'night') {
      const alive = living(S), occ = occupied(S).length, keep = lv === 1 ? 0 : Math.round(hb.thrift * 6);
      const sp = aiSpend(S, lv, hb); if (sp) return sp;
      if (alive.length < staffCap(S) && S.hire.length && (alive.length < Math.min(occ + 1, 4 + Math.floor(S.day / 2)) || alive.length < 4)) {
        const i = S.hire.map((c, k) => [c.st.reduce((a, b) => a + b, 0) + (c.tr === 'plain' ? -1 : 0), k]).sort((a, b) => b[0] - a[0])[0][1];
        if (S.bud >= hireCost(S, S.hire[i])) return { t: 'hire', i };
      }
      const ord = (hb.upOrd < 0.33 ? ['manual', 'med', 'wall', 'gen', 'sed', 'dorm', 'lounge', 'alarm', 'lens', 'gym', 'lift'] : hb.upOrd < 0.66 ? ['med', 'sed', 'manual', 'dorm', 'wall', 'alarm', 'gen', 'lounge', 'lift', 'gym', 'lens'] : ['gen', 'manual', 'dorm', 'med', 'lens', 'wall', 'sed', 'lift', 'gym', 'alarm', 'lounge']);
      for (const id of (lv === 1 ? ord.slice().reverse() : ord)) { const u = UPS.find((x) => x.id === id); if (upLv(S, id) < u.mx && S.bud - keep >= upCost(S, u) && (id !== 'dorm' || alive.length >= staffCap(S))) return { t: 'up', id }; }
      return { t: 'next' };
    }
    return null;
  }

  function result(S) {
    if (!S.over) return null;
    const hl = [];
    if (S.over.win) hl.push(S.stat.lost ? '잃은 직원 ' + S.stat.lost + '명' : '직원 손실 없이 인계');
    hl.push('이형체 ' + occupied(S).length + '건 관리 · 추출한 장비 ' + S.stat.gear + '점');
    return { winners: S.over.win ? [0] : [], title: S.over.title, text: S.over.text, highlights: hl,
      stats: [{ label: '근무일', value: (S.over.win ? S.days : S.day) + ' / ' + S.days }, { label: '생산한 에너지', value: Math.round(S.stat.en) }, { label: '탈주', value: S.stat.esc + '건' }, { label: '이변', value: S.stat.burst + '건' }, { label: '공황', value: S.stat.panic + '건' }, { label: '잃은 직원', value: S.stat.lost + '명' }, { label: '본부 경고', value: S.warn + ' / 3' }] };
  }

  /* ================= 화면 ================= */
  const CSS = `
.ct{position:absolute;inset:0;display:flex;flex-direction:column;background:#0b0f13;color:#dfe3e0;font:14px/1.45 var(--f-body,sans-serif);word-break:keep-all;user-select:none;-webkit-user-select:none;overflow:hidden}
.ct *{box-sizing:border-box}
.ct button{font:inherit;color:inherit;cursor:pointer}
.ct-top{flex:none;height:50px;display:flex;align-items:center;gap:8px;padding:0 58px 0 10px;background:#141a20;border-bottom:1px solid #2a333b;white-space:nowrap}
.ct-day{display:flex;flex-direction:column;line-height:1.15;font-size:12px;color:#93a0a6;min-width:74px}.ct-day b{font-size:16px;color:#f0ead8;font-variant-numeric:tabular-nums}
.ct-clk{display:flex;gap:3px;align-items:center}.ct-clk i{width:20px;height:12px;border-radius:3px;background:#263039;overflow:hidden;position:relative}.ct-clk i b{position:absolute;left:0;top:0;bottom:0;background:#7fa3c7}.ct-clk i.ot b{background:#d0505a}
.ct-en{position:relative;flex:1;min-width:160px;height:26px;border-radius:6px;background:#222a32;overflow:hidden;border:1px solid #33404a}
.ct-en>i{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#3f7f86,#69b3a6)}.ct-en>i.full{background:linear-gradient(90deg,#8a7a3a,#e3ae45)}
.ct-en>span{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:13px;font-variant-numeric:tabular-nums;color:#fff;text-shadow:0 1px 2px #000}
.ct-chip{display:inline-flex;align-items:center;gap:5px;height:32px;padding:0 9px;border-radius:6px;background:#1d242b;border:1px solid #2f3942;font-size:13px;color:#c9d2d4}.ct-chip b{color:#f0ead8;font-variant-numeric:tabular-nums}
.ct-chip.al{font-weight:700;border-color:currentColor}
.ct-warnp{display:inline-flex;gap:3px}.ct-warnp i{width:9px;height:9px;border-radius:50%;border:1px solid #6b7780}.ct-warnp i.on{background:#ee6a55;border-color:#ee6a55}
.ct-btn{min-height:36px;min-width:40px;padding:0 11px;border-radius:7px;border:1px solid #3a4650;background:#252e36;font-size:13px;white-space:nowrap;position:relative}
.ct-btn:hover:not(:disabled){background:#2f3a44;border-color:#55626b}.ct-btn:disabled{opacity:.4;cursor:default}
.ct-btn.on{border-color:#e3ae45;color:#f3d588;background:#2b2a22}
.ct-btn.pri{background:#e3ae45;border-color:#e3ae45;color:#22190a;font-weight:700}.ct-btn.pri:hover:not(:disabled){background:#f0c060}
.ct-btn.warn{border-color:#ee6a55;color:#f3b0a4}.ct-btn.sm{min-height:30px;padding:0 8px;font-size:12px}
.ct-top .ct-btn{height:40px;min-width:54px;padding:9px 12px 0}.ct-selbar .ct-btn{padding:6px 16px 0 8px}
.ct-mid{flex:1;min-height:0;position:relative}
.ct-mid canvas{position:absolute;inset:0;width:100%;height:100%;display:block;cursor:default}
.ct-feed{position:absolute;left:10px;bottom:8px;width:min(430px,42%);display:flex;flex-direction:column;gap:3px;pointer-events:none;z-index:3}
.ct-feed div{font-size:12.5px;line-height:1.35;padding:3px 8px;border-radius:5px;background:rgba(12,16,20,.72);color:#c9d2d4;border-left:3px solid #55626b;pointer-events:auto;cursor:pointer;transition:opacity .4s}
.ct-feed .ok{border-color:#69b3a6}.ct-feed .bad{border-color:#ee6a55;color:#f3b9ad}.ct-feed .warn{border-color:#e3ae45;color:#ecd08a}.ct-feed .day{border-color:#f0ead8;color:#f0ead8}
.ct-ps{position:absolute;left:12px;top:10px;padding:5px 14px;border-radius:16px;background:rgba(227,174,69,.92);color:#22190a;font-weight:700;font-size:13px;z-index:3;pointer-events:none}
.ct-selbar{position:absolute;left:12px;top:46px;display:flex;gap:6px;align-items:center;padding:5px 8px;border-radius:9px;background:rgba(20,26,32,.9);border:1px solid #3a4650;z-index:4;font-size:13px}
.ct-pn{position:absolute;top:8px;bottom:8px;width:400px;display:flex;flex-direction:column;background:rgba(22,28,34,.97);border:1px solid #3a4650;border-radius:10px;z-index:6;overflow:hidden;box-shadow:0 8px 30px rgba(0,0,0,.5)}
.ct-pn.r{right:8px}.ct-pn.l{left:8px}.ct-pn.mod{z-index:26}
.ct-pnh{display:flex;gap:10px;padding:10px;border-bottom:1px solid #2a333b;background:#1a2128}
.ct-th{position:relative;flex:none;border-radius:6px;overflow:hidden;background:radial-gradient(ellipse at 50% -6%,hsl(var(--hu) 16% 40%),hsl(205 16% 17%) 62%,hsl(208 20% 10%));color:hsl(var(--hu) 24% 80%)}
.ct-th svg{position:absolute;inset:8%;width:84%;height:84%}.ct-th img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 18%}.ct-th.z{cursor:zoom-in}
.ct-no{font:12px var(--f-mono,monospace);color:#93a0a6;display:flex;align-items:center;gap:6px}
.ct-tier{font:12px var(--f-body,sans-serif);padding:0 6px;border-radius:4px;border:1px solid currentColor;line-height:17px}
.ct-nm{font-size:17px;font-weight:700;color:#f0ead8;line-height:1.25}
.ct-g{display:flex;gap:3px;align-items:center;font-size:12px;color:#93a0a6}.ct-g i{width:12px;height:12px;border-radius:2px;border:1px solid #55626b}.ct-g i.on{background:#e3ae45;border-color:#e3ae45}.ct-g.hot i.on{background:#ee6a55;border-color:#ee6a55}
.ct-pt{color:#9cc3e6;font-weight:700;font-variant-numeric:tabular-nums}
.ct-tabs{display:flex;gap:4px;padding:6px 8px 0}.ct-tabs button{flex:1;min-height:34px;border-radius:7px 7px 0 0;border:1px solid #33404a;border-bottom:0;background:#161c22;font-size:13px;color:#93a0a6}.ct-tabs button.on{color:#f3d588;background:#232b33;border-color:#7d6a36}
.ct-pnb{flex:1;min-height:0;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:8px;background:#232b33;border-top:1px solid #33404a}
.ct-pnb::-webkit-scrollbar,.ct-scroll::-webkit-scrollbar{width:8px}.ct-pnb::-webkit-scrollbar-thumb,.ct-scroll::-webkit-scrollbar-thumb{background:#3a4650;border-radius:4px}
.ct-pnb>*,.ct-scroll>*{flex:none}
.ct-wk{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.ct-wb{min-height:62px;border-radius:8px;border:1px solid #3a4650;border-left:4px solid var(--wc);background:#1b2229;padding:6px 9px;text-align:left;display:flex;flex-direction:column;gap:1px;font-size:12.5px;position:relative}
.ct-wb:hover{background:#27313a}.ct-wb.on{border-color:#e3ae45;background:#2b2a22}
.ct-wb .t{display:flex;justify-content:space-between;align-items:baseline;font-size:15px;font-weight:700;color:#f0ead8}
.ct-wb .t em{font:700 15px var(--f-mono,monospace);font-style:normal;color:#8fd0c0}.ct-wb .t em.q{color:#93a0a6;font:400 12px var(--f-body,sans-serif)}
.ct-v{color:#ee6a55;font-weight:700}.ct-pf2{color:#8fd0c0}.ct-pf0{color:#f09a88}.ct-pf1,.ct-pfq{color:#93a0a6}
.ct-row{display:flex;gap:9px;align-items:center;padding:6px 8px;border:1px solid #2f3942;border-radius:8px;background:#1b2229;font-size:12.5px;text-align:left;width:100%;min-height:52px}
button.ct-row:hover:not(:disabled){background:#27313a;border-color:#55626b}.ct-row.on{border-color:#e3ae45}.ct-row:disabled{opacity:.45;cursor:default}
.ct-row .x{flex:1;min-width:0}.ct-row .x b{font-size:14px;color:#f0ead8}.ct-row .x div{color:#aab5b9}.ct-row .p{font:700 16px var(--f-mono,monospace);color:#8fd0c0;min-width:44px;text-align:right}
.ct-face{position:relative;flex:none;border-radius:8px;overflow:hidden;background:#2a333b;border:2px solid var(--rc,#55626b)}.ct-face img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.ct-face svg{position:absolute;inset:10%;width:80%;height:80%}.ct-face.dead img{filter:grayscale(1) brightness(.5)}
.ct-bars{display:flex;flex-direction:column;gap:2px}.ct-bars i{display:block;height:5px;border-radius:2px;background:#333d45;overflow:hidden}.ct-bars i b{display:block;height:100%}.ct-bars .hp b{background:#c8695c}.ct-bars .sp b{background:#6e9fd0}
.ct-sec{font-size:12px;color:#93a0a6;letter-spacing:.04em;margin-top:4px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #33404a;padding-bottom:3px}
.ct-doc p{margin:0 0 6px;font-size:13.5px;color:#d5dbd8;line-height:1.55}.ct-doc p.m{color:#93a0a6}
.ct-it{display:flex;gap:8px;align-items:center;padding:5px 8px;border-radius:6px;background:#1b2229;border:1px solid #2f3942;font-size:13px;min-height:38px}
.ct-it .x{flex:1;min-width:0}.ct-it .x b{color:#f3d588}.ct-it.lock{border-style:dashed;color:#7d8a91}
.ct-bot{flex:none;height:104px;display:flex;gap:6px;padding:6px 10px;background:#141a20;border-top:1px solid #2a333b;overflow-x:auto;align-items:stretch}
.ct-st{flex:none;width:200px;display:flex;gap:8px;padding:5px 7px;border-radius:9px;border:1px solid #2f3942;border-left:4px solid var(--rc);background:#1b2229;text-align:left;align-items:center;position:relative}
.ct-st:hover{background:#232c34}.ct-st.on{border-color:#e3ae45;background:#2b2a22;box-shadow:0 0 0 1px #e3ae45 inset}
.ct-st.pn{border-color:#ee6a55;background:#2c1e1d}.ct-st.dead{opacity:.42}
.ct-st .i{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px;font-size:12px;line-height:1.2}
.ct-st .n{font-weight:700;font-size:14px;color:#f0ead8;white-space:nowrap;display:flex;gap:5px;align-items:baseline}.ct-st .n small{font-weight:400;font-size:11.5px;color:#93a0a6}
.ct-st .a{color:#93a0a6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ct-st .a.set{color:#8fd0c0}.ct-st .a.bad{color:#f09a88}
.ct-gp{position:absolute;right:5px;top:5px;display:flex;gap:2px}.ct-gp i{width:9px;height:9px;border-radius:2px;border:1px solid rgba(0,0,0,.5)}.ct-gp i.x{border-radius:50%}
.ct-num{position:absolute;left:3px;top:1px;font:11px var(--f-mono,monospace);color:#7d8a91}
.ct-ov{position:absolute;inset:0;background:rgba(6,8,10,.72);display:flex;align-items:center;justify-content:center;z-index:20;padding:18px}
.ct-ov.art{background:linear-gradient(rgba(10,13,16,.28),rgba(10,13,16,.28)),url(assets/containment/cell.webp) center/cover #0b0f13}
.ct-sheet{width:min(880px,100%);max-height:100%;overflow-y:auto;background:#1a2027;border:1px solid #33404a;border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:10px}
.ct-sheet h3{margin:0;font:400 20px var(--f-display,sans-serif);color:#f0ead8}.ct-sheet p{margin:0;font-size:14px;color:#c4cdd0}.ct-sheet p.m{color:#93a0a6;font-size:13px}
.ct-cands{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.ct-cand{display:flex;flex-direction:column;gap:7px;padding:10px;border:1px solid #33404a;border-radius:10px;background:#1b2229;font-size:13px;color:#b8c2c5}
.ct-cand:hover{border-color:#7d6a36}.ct-cand .ct-th{width:100%;aspect-ratio:4/3}.ct-cand .ct-th img{object-position:50% 22%}
.ct-night{display:grid;grid-template-columns:330px 1fr;gap:14px;width:min(1180px,100%);height:min(640px,100%)}
.ct-col{background:#1a2027;border:1px solid #33404a;border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:8px;min-height:0}
.ct-scroll{flex:1;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:6px;padding-right:4px}
.ct-grid2{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.ct-kv{display:grid;grid-template-columns:auto 1fr;gap:3px 12px;font-size:13px;margin:0}.ct-kv dt{color:#93a0a6}.ct-kv dd{margin:0;color:#dfe3e0}
.ct-por{position:relative;flex:none;aspect-ratio:3/4;border-radius:8px;overflow:hidden;background:radial-gradient(ellipse at 50% 0,#33404a,#1a2027 70%);cursor:zoom-in}.ct-por img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 8%}.ct-por svg{position:absolute;inset:14%;width:72%;height:72%}
.ct-tip{position:absolute;left:50%;bottom:14px;transform:translateX(-50%);max-width:560px;padding:10px 14px;border-radius:10px;background:rgba(20,26,32,.95);border:1px solid #7d6a36;z-index:5;font-size:13px;color:#dfe3e0;line-height:1.6;cursor:pointer}
.ct-cx{display:grid;grid-template-columns:minmax(260px,38%) 1fr;gap:12px;min-height:420px}.ct-cxg{display:grid;grid-template-columns:repeat(4,1fr);grid-auto-rows:142px;gap:6px;align-content:start;overflow-y:auto;max-height:70vh}
.ct-cxc{position:relative;height:100%;padding:0;border-radius:6px;border:1px solid #33404a;overflow:hidden;padding:0;background:#141a1f}.ct-cxc.on{border-color:#e3ae45;box-shadow:0 0 0 1px #e3ae45}.ct-cxc span{position:absolute;left:0;right:0;bottom:0;font:11px var(--f-mono,monospace);background:rgba(0,0,0,.6);color:#dfe3e0;text-align:center}
`;
  const ROLE_GL = ['<path d="M16 25l4 1.5v3q0 3-4 4.5-4-1.5-4-4.5v-3z" fill="#f3ead8" opacity=".85"/>', '<circle cx="16" cy="30" r="3.4" fill="none" stroke="#f3ead8" stroke-width="1.6" opacity=".85"/>', '<path d="M12.5 28.5q3.5-3 7 0v3q-3.5 3-7 0z" fill="#f3ead8" opacity=".85"/>', '<path d="M11.5 28h9q0 5-4.5 5t-4.5-5z" fill="#f3ead8" opacity=".85"/>'];
  const figSVG = (role, dead) => '<svg viewBox="0 0 32 40" aria-hidden="true"><circle cx="16" cy="10" r="7" fill="' + (dead ? '#6b747b' : '#d9cdb8') + '"/><path d="M4 40q0-18 12-18t12 18z" fill="' + (dead ? '#59626a' : ROLES[role].c) + '"/>' + ROLE_GL[role] + '</svg>';
  const QGL = '<path d="M17 24q0-9 7-9t7 8q0 5-7 9v6" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="24" cy="48" r="3" fill="currentColor"/>';
  const f2 = (n) => (n < 10 ? '0' : '') + n;
  const faceSrc = (fc, pn) => AS + 'f' + f2(fc) + (pn ? 'p' : '') + '.webp', porSrc = (fc, pn) => AS + 's' + f2(fc) + (pn ? 'p' : '') + '.webp';
  const glSrc = (E, hid) => 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 64" color="hsl(' + E.hu + ',26%,72%)">' + (hid ? QGL : E.gl) + '</svg>');
  function thumbHTML(E, hidden) {
    return '<svg viewBox="0 0 48 64" aria-hidden="true">' + (hidden ? QGL : E.gl) + '</svg>' + (ART && !hidden && E.img ? '<img alt="" decoding="async" src="' + AS + E.img + '.webp" onerror="this.remove()">' : '');
  }
  const faceHTML = (st) => figSVG(st.role, st.dead) + (ART ? '<img alt="" decoding="async" src="' + faceSrc(st.fc, st.pn) + '" onerror="this.remove()">' : '');
  /* 본 기록(도감용) — 이 기기에 남는다. 능력치와 무관, 열람한 항목만 */
  const SEENK = 'lounge.containment.seen2';
  const seenGet = () => { try { return JSON.parse(localStorage.getItem(SEENK) || '{}') || {}; } catch (e) { return {}; } };
  function seenPut(S) {
    try {
      const o = seenGet(); let ch = 0;
      S.rooms.forEach((R) => {
        if (R.e == null) return; const E = ENT[R.e], c = o[E.id] || { j: 0, p: [0, 0, 0, 0], r: [0, 0, 0], b: 0, g: 0 };
        const n = { j: Math.max(c.j, R.un.j), p: c.p.map((v, i) => v || R.un.p[i]), r: c.r.map((v, i) => v || R.rv[i] || 0), b: c.b || R.un.b, g: c.g || (['w', 'a', 'x'].some((s) => S.gear[R.e + s]) ? 1 : 0) };
        if (JSON.stringify(n) !== JSON.stringify(o[E.id])) { o[E.id] = n; ch = 1; }
      });
      if (ch) localStorage.setItem(SEENK, JSON.stringify(o));
    } catch (e) {}
  }
  /* 이형체 기록 문서 — 게임 안(열람 단추 있음)과 도감(본 것만)에서 같이 쓴다. K = { j, p[4], r[n], b }, live = { S, R, ri, unl(k, i) } */
  function docBody(E, K, live) {
    const h = L.h, box = h('div', { class: 'ct-doc', style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
    const sec = (t) => box.append(h('div', { class: 'ct-sec' }, h('span', { text: t })));
    const lockRow = (label, k, i) => {
      const r = h('div', { class: 'ct-it lock' }, h('div', { class: 'x', text: label }));
      if (live) { const c = unlCost(live.R, k); r.append(h('button', { class: 'ct-btn sm', type: 'button', disabled: live.R.pt < c || !live.can, text: '열람 · 관찰 ' + c, onclick: () => live.unl(k, i) })); }
      else r.append(h('span', { text: '미확인' }));
      return r;
    };
    sec('겉모습'); box.append(h('p', { text: E.look }));
    box.append(h('p', { class: 'm', text: '등급 ' + TIER[E.tier].n + ' · 작업 칸마다 에너지 ' + r1(E_OUT[E.tier] / NB) + '(최대 ' + E_OUT[E.tier] + ') · 피해 유형: ' + DTN[E.dt] + '(실패 칸마다 ' + r1(DMG[E.tier] * BOXD) + ') · 게이지 한계 ' + E.gm }));
    sec('관찰 일지');
    if (K.j >= 1) box.append(h('p', { text: '[일지 1] ' + E.desc })); else box.append(lockRow('일지 1', 'j', 0));
    if (K.j >= 2) box.append(h('p', { text: '[일지 2] ' + E.log })); else if (K.j >= 1 || !live) box.append(lockRow('일지 2', 'j', 1));
    sec('작업 선호');
    WORKS.forEach((W, w) => {
      if (K.p[w]) { const pf = +E.pf[w]; box.append(h('div', { class: 'ct-it' }, h('div', { class: 'x' }, h('b', { text: W.n }), ' — ', h('span', { class: 'ct-pf' + pf, text: PF_N[pf] + ' (기본 성공률 ' + Math.round((PF_P[pf] - (E.tier - 1) * 0.06) * 100) + '%)' })))); }
      else box.append(lockRow(W.n + ' 선호', 'p', w));
    });
    sec('관리 수칙');
    E.rules.forEach((k, i) => {
      if (K.r[i]) box.append(h('div', { class: 'ct-it' }, h('div', { class: 'x' }, h('b', { text: (i + 1) + '. ' + RULES[k].n }), h('div', { text: RULES[k].d + (RULES[k].pas ? '' : ' (위반: 성공률 −20%p, 게이지 +2)') }))));
      else box.append(lockRow('수칙 ' + (i + 1), 'r', i));
    });
    sec('게이지가 다 차면');
    if (K.b) box.append(h('div', { class: 'ct-it' }, h('div', { class: 'x' }, E.esc ? [h('b', { text: '탈주 — ' + BK[E.bk].n }), h('div', { text: BK[E.bk].d + ' 체력 ' + (live ? brHp(live.S, E) : GR[E.tier].hp) + ' · 3초마다 ' + GR[E.tier].hit + '명에게 ' + DTN[E.dt] + ' 피해 ' + r1(BR_ATK[E.tier] * BR_K) + (weakOf(E) ? ' · ' + DTN[weakOf(E)] + ' 무기에 약함(×1.3), ' + DTN[E.dt] + ' 무기에 강함(×0.75)' : ' · 약점 없음') })] : [h('b', { text: '이변' }), h('div', { text: BURST[E.bu.k].d(E.bu.v) + ' 격리실을 벗어나지는 않는다.' })])));
    else box.append(lockRow('탈주 · 이변 정보', 'b', 0));
    return box;
  }


  /* ---- 도감(게임 밖): 이형체마다 기록 문서. 판에서 열람한 항목만 보인다(본 기록). 수치는 자료에서 자동 생성 ---- */
  function codexFn(el) {
    const h = L.h, seen = seenGet();
    el.innerHTML = '';
    const wrap = h('div', { class: 'ct', style: { position: 'relative', inset: 'auto', background: 'transparent', overflow: 'visible', gap: '10px' } }, h('style', { text: CSS }));
    const tabs = h('div', { class: 'ct-tabs', style: { padding: 0 } }), body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    wrap.append(tabs, body); el.append(wrap);
    let tab = 0, cur = Math.max(0, ENT.findIndex((E) => seen[E.id]));
    const row = (name, tag, desc, icon) => h('div', { class: 'ct-row', style: { minHeight: '44px' } }, icon || null, h('div', { class: 'x' }, h('b', { text: name + ' ' }), h('span', { style: { color: '#93a0a6' }, text: tag }), h('div', { text: desc })));
    const note = (t) => h('p', { style: { margin: 0, fontSize: '13px', color: '#aab5b9' }, text: t });
    const TABS = ['이형체', '작업 · 직원', '추출 장비', '키워드 · 수칙', '사건 · 강화'];
    function draw() {
      tabs.innerHTML = ''; TABS.forEach((n, i) => tabs.append(h('button', { class: tab === i ? 'on' : '', type: 'button', style: { minHeight: '44px' }, text: n, onclick: () => { tab = i; draw(); } })));
      body.innerHTML = '';
      if (tab === 0) {
        const n = ENT.filter((E) => seen[E.id]).length;
        body.append(note('이형체 ' + ENT.length + '건 중 ' + n + '건 확인. 판에서 인수한 적이 있어야 문서가 열리고, 그 판에서 관찰 수치로 열람한 항목만 여기 남아요(기록일 뿐, 다음 판에 주는 이점은 없어요).'));
        const grid = h('div', { class: 'ct-cxg' }), doc = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px', minWidth: 0 } });
        ENT.forEach((E, i) => { const c = h('button', { class: 'ct-cxc' + (i === cur ? ' on' : ''), type: 'button', title: seen[E.id] ? E.no + ' ' + E.n : E.no + ' 미확인', onclick: () => { cur = i; draw(); } }); c.innerHTML = '<div class="ct-th" style="--hu:' + E.hu + ';position:absolute;inset:0;border-radius:0">' + thumbHTML(E, !seen[E.id]) + '</div><span>' + E.no + '</span>'; grid.append(c); });
        const E = ENT[cur], K = seen[E.id];
        if (!K) doc.append(h('div', { class: 'ct-nm', text: E.no + ' 미확인' }), note('등급 ' + TIER[E.tier].n + '. 인수한 기록이 없음.'));
        else {
          const th = h('div', { class: 'ct-th z', style: { '--hu': E.hu, width: '240px', height: '320px' } }); th.innerHTML = thumbHTML(E); th.onclick = () => { const im = th.querySelector('img'); if (im) zoom(im.src, E.no + ' ' + E.n); };
          doc.append(h('div', { style: { display: 'flex', gap: '12px' } }, th, h('div', { style: { flex: 1, minWidth: 0 } }, h('div', { class: 'ct-no' }, E.no, h('span', { class: 'ct-tier', style: { color: TIER[E.tier].c }, text: TIER[E.tier].n }), h('span', { text: E.esc ? '탈주형' : '이변형' })), h('div', { class: 'ct-nm', style: { fontSize: '20px' }, text: E.n }), note('수칙 ' + E.rules.length + '건 · 장비 ' + ['w', 'a', 'x'].filter((s) => GEAR[cur + s]).length + '종'))), docBody(E, K, null));
          doc.append(h('div', { class: 'ct-sec' }, h('span', { text: '추출 장비' })));
          if (K.g) ['w', 'a', 'x'].forEach((s) => { const G = GEAR[cur + s]; if (G) doc.append(h('div', { class: 'ct-it' }, h('div', { class: 'x' }, h('b', { text: G.n }), ' ' + SLOT_N[s] + ' · 한도 ' + G.lim + '점', h('div', { text: gearText(G) + ' · 관찰 ' + G.pt + ' · 에너지 ' + G.cost })))); });
          else doc.append(h('div', { class: 'ct-it lock' }, h('div', { class: 'x', text: '이 이형체에서 장비를 추출한 기록이 없음.' })));
        }
        body.append(h('div', { class: 'ct-cx' }, grid, doc));
      } else if (tab === 1) {
        body.append(note('작업은 결과 칸 ' + NB + '개로 진행돼요. 칸마다 성공률 = 선호(선호 ' + Math.round(PF_P[2] * 100) + '% · 보통 ' + Math.round(PF_P[1] * 100) + '% · 기피 ' + Math.round(PF_P[0] * 100) + '%) + (직원의 해당 능력치 − 2) × 7%p − (등급 − 1) × 6%p. 성공 칸마다 에너지와 관찰 수치, 실패 칸마다 직원이 피해. 성공 ' + GOOD + '칸 이상 = 좋음, ' + BAD + '칸 이하 = 나쁨(게이지 +1, 기피 작업이면 +2).'));
        WORKS.forEach((W) => body.append(row(W.n, STN[W.st], W.d + ' ' + STN[W.st] + '이 높을수록 잘 돼요.', h('i', { style: { width: '10px', height: '34px', background: W.c, borderRadius: '3px', flex: 'none' } }))));
        body.append(note('직원 16명 — 직책마다 4명. 호출 부호와 얼굴은 한 쌍이에요. 최대 체력 = 26 + 담력 × 6, 최대 정신 = 26 + 절제 × 6. 정원 5명(숙소 증설로 늘어남).'));
        const g = h('div', { class: 'ct-grid2' });
        for (let fc = 0; fc < 16; fc++) { const st = { role: fc >> 2, fc, dead: 0, pn: 0 }, f = h('span', { class: 'ct-face', style: { width: '88px', height: '88px', '--rc': ROLES[st.role].c, cursor: 'zoom-in' }, onclick: () => zoom(porSrc(fc), FACE_N(fc) + ' · ' + ROLES[st.role].n) }); f.innerHTML = faceHTML(st); g.append(row(FACE_N(fc), ROLES[st.role].n, '주 능력치 ' + STN[st.role] + ' 3으로 시작.', f)); }
        body.append(g, note('특성 — 직원마다 하나.')); TRK.forEach((k) => body.append(row(TRAITS[k].n, '특성', TRAITS[k].d)));
      } else if (tab === 2) {
        body.append(note('이형체마다 무기 하나 · 방호구 하나(' + GR[X_MIN].n + ' 이상은 장신구도)를 추출할 수 있어요. 모두 ' + Object.keys(GEAR).length + '종. 그 이형체의 관찰 수치와 비축 에너지를 쓰고, 수량 한도가 있어요(' + GR.slice(1).map((g) => g.n + ' ' + g.lim).join(' · ') + '점, 장신구 1점). 장비 등급은 나온 이형체의 등급과 같아요. 판이 끝나면 사라져요. 무기에는 피해 유형이 있어 탈주체의 약점(×1.3) · 내성(×0.75)에 걸려요. 여기에는 한 번이라도 추출해 본 이형체의 장비만 적혀요.'));
        let n = 0;
        ENT.forEach((E, i) => { if (!seen[E.id] || !seen[E.id].g) return; ['w', 'a', 'x'].forEach((s) => { const G = GEAR[i + s]; if (!G) return; n++; body.append(row(G.n, SLOT_N[s] + ' · ' + E.no + ' ' + E.n, gearText(G) + ' · 관찰 ' + G.pt + ' · 에너지 ' + G.cost + ' · 한도 ' + G.lim + '점', h('i', { style: { width: '16px', height: '16px', borderRadius: s === 'x' ? '50%' : '3px', background: 'hsl(' + E.hu + ',55%,66%)', flex: 'none' } }))); }); });
        if (!n) body.append(h('div', { class: 'ct-it lock' }, h('div', { class: 'x', text: '아직 추출한 장비가 없어요.' })));
      } else if (tab === 3) {
        body.append(note('키워드 — 장비와 특성에서 되풀이되는 효과. 「키워드: 수치」로 적어요.'));
        Object.keys(KW).forEach((k) => body.append(row(KW[k].n, '키워드', KW[k].d + ' 쓰는 장비 ' + Object.keys(GEAR).filter((g) => GEAR[g].kw.some((x) => x[0] === k)).length + '종.')));
        body.append(note('관리 수칙 ' + Object.keys(RULES).length + '가지 — 어느 이형체의 수칙인지는 그 이형체의 기록에서 열람해야 해요. 「출입」 수칙을 어기면 그 작업의 성공률 −20%p, 게이지 +2.'));
        Object.keys(RULES).forEach((k) => body.append(row(RULES[k].n, RULES[k].pas ? '상시' : '출입', RULES[k].d)));
        body.append(note('탈주 양상 — 탈주형 이형체가 복도에서 하는 행동.')); Object.keys(BK).forEach((k) => body.append(row(BK[k].n, '탈주 양상', BK[k].d)));
      } else {
        body.append(note('사건 — 2일째부터 아침마다 하나(' + EVENTS.length + '가지).')); EVENTS.forEach((e) => body.append(row(e.n, '사건', e.d)));
        body.append(note('시설 강화 — 하루를 마감한 뒤 비축 에너지로. 비용 = 기본 비용 × (지금 단계 + 1). 이 판 안에서만 이어져요.')); UPS.forEach((u) => body.append(row(u.n, '최대 ' + u.mx + '단계', '단계마다 ' + u.d + ' 기본 비용 ' + u.c + '.')));
        body.append(note('구역 — 짧게: 2구역 × 격리실 4칸(3일째에 둘째 구역) · 보통: 2구역 × 6칸(5일째) · 길게: 3구역 × 6칸(5 · 11일째). 구역 이름은 ' + ZONE.slice(0, 3).join(' · ') + '.'));
      }
    }
    draw();
  }
  function preview(cv) {
    const c = cv.getContext('2d'), W = cv.width, H = cv.height;
    c.fillStyle = '#0b0f13'; c.fillRect(0, 0, W, H);
    for (let f = 0; f < 2; f++) {
      const y = 30 + f * 160;
      c.fillStyle = '#1a2229'; c.fillRect(20, y + 100, 600, 40); c.fillStyle = '#2c3740'; c.fillRect(20, y + 136, 600, 4);
      for (let k = 0; k < 4; k++) {
        const x = 70 + k * 138, hot = f === 1 && k === 2, hu = ENT[(f * 4 + k) * 5 % ENT.length].hu;
        c.fillStyle = 'hsl(' + hu + ' 22% 16%)'; c.fillRect(x, y, 124, 100); c.strokeStyle = hot ? '#ee6a55' : '#3a4650'; c.lineWidth = 2; c.strokeRect(x, y, 124, 100);
        c.fillStyle = 'hsl(' + hu + ' 30% 60%)'; c.beginPath(); c.arc(x + 62, y + 44, 13, 0, 7); c.fill(); c.fillRect(x + 48, y + 58, 28, 28);
        for (let i = 0; i < 4; i++) { c.fillStyle = i < (f + k) % 4 ? (hot ? '#ee6a55' : '#e3ae45') : '#2c363e'; c.fillRect(x + 6 + i * 13, y + 86, 10, 10); }
      }
      for (let k = 0; k < 3; k++) { const x = 110 + k * 170 + f * 60; c.fillStyle = ROLES[(k + f) % 4].c; c.beginPath(); c.moveTo(x - 10, y + 134); c.lineTo(x - 7, y + 112); c.lineTo(x + 7, y + 112); c.lineTo(x + 10, y + 134); c.fill(); c.fillStyle = '#d9cdb8'; c.beginPath(); c.arc(x, y + 104, 9, 0, 7); c.fill(); }
    }
    c.fillStyle = '#e3ae45'; c.fillRect(20, 8, 330, 10); c.fillStyle = '#222a32'; c.fillRect(350, 8, 270, 10);
  }
  const ICON = '<rect x="9" y="10" width="38" height="36" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M28 10v36M9 28h38" stroke="currentColor" stroke-width="2.5"/><circle cx="18.5" cy="19" r="3.5" fill="currentColor"/><circle cx="37.5" cy="37" r="3.5" fill="currentColor"/><path d="M33 16l9 6" stroke="currentColor" stroke-width="3"/>';
  function hintOf(S) {
    if (S.ph === 'pick') return ['새 이형체를 하나 골라 인수해요.', '등급이 높을수록 에너지도 피해도 커요. 선호 작업 하나만 미리 알려 줘요.'];
    if (S.ph === 'night') return ['하루를 마감했어요. 비축 에너지 ' + S.bud + '.', '채용 · 시설 강화 · 기록 열람 · 장비 추출을 마친 뒤 다음 날을 시작해요.'];
    const hot = S.rooms.filter((R) => R.e != null && !R.out && R.g >= gMax(S, R) - 1).map((R) => ENT[R.e].no);
    return ['격리실 → 작업 → 직원 순서로 눌러 보내요. Space로 멈추고 흘려요.', '에너지 ' + Math.floor(S.en) + ' / ' + S.quota + ' · ' + (S.turn > TURNS ? '연장 근무' : S.turn + ' / ' + TURNS + '차') + ' · 경보 ' + ALERT[alertOf(S)].n, S.br.length ? '탈주 중: ' + S.br.map((b) => ENT[S.rooms[b.r].e].no).join(', ') + ' — 직원을 고르고 탈주체를 오른쪽 누르기. 셋이 동시에 나오면 져요.' : '탈주 중인 이형체 없음.', hot.length ? '게이지가 한 칸 남은 이형체: ' + hot.join(', ') : '게이지가 위험한 이형체 없음.', '수칙을 모르는 이형체는 격리실 창의 「기록」에서 관찰 수치로 열람해요.'];
  }

  const def = {
    id: ID, name: '격리 시설 관리', tag: '시설 운영 · 실시간', cat: '보드', time: '20–60분', mood: 'tension', ambient: false,
    blurb: '정체 모를 「이형체」를 가둔 지하 시설의 관리자가 되어, 직원을 격리실에 보내 작업하고 에너지를 모아요. 이형체마다 지켜야 할 수칙이 다르고, 어기거나 실패가 쌓이면 격리를 벗어나요. 관찰 수치로 기록을 열람하고 고유 장비를 추출해요.',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, save: true, undo: false, realtime: true, landscape: true, pcOnly: true, contextMenu: true, sidePanel: false,
    saveLabel: (S) => S.day + '/' + S.days + '일째 · 직원 ' + living(S).length + '명 · 이형체 ' + occupied(S).length + '건',
    options: [{ id: 'len', label: '길이', def: 'M', tip: '길수록 구역이 더 열리고 높은 등급이 들어와요.', choices: [
      { v: 'S', label: '짧게 · 5일', tip: '2구역 · 격리실 8칸, 20분 안팎' }, { v: 'M', label: '보통 · 8일', tip: '2구역 · 격리실 12칸, 35분 안팎' }, { v: 'L', label: '길게 · 12일', tip: '3구역 · 격리실 18칸, 60분 안팎' }] }],
    icon: ICON, tint: '#24363b', preview,
    controls: [
      { id: 'pause', label: '일시정지 · 재개', keys: ['Space'], pad: ['start'] },
      { id: 'sp1', label: '배속 1×', keys: ['Digit1'], pad: [] }, { id: 'sp2', label: '배속 2×', keys: ['Digit2'], pad: [] }, { id: 'sp3', label: '배속 3×', keys: ['Digit3'], pad: [] },
      { id: 'next', label: '다음 직원', keys: ['Tab'], pad: ['rb'] }, { id: 'prev', label: '이전 직원', keys: ['KeyQ'], pad: ['lb'] }, { id: 'all', label: '직원 모두 고르기', keys: ['KeyT'], pad: [] },
      { id: 'w0', label: '관찰 보내기(격리실 창)', keys: ['KeyZ'], pad: [] }, { id: 'w1', label: '교감 보내기', keys: ['KeyX'], pad: [] }, { id: 'w2', label: '급양 보내기', keys: ['KeyC'], pad: [] }, { id: 'w3', label: '억제 보내기', keys: ['KeyV'], pad: [] },
      { id: 'rest', label: '고른 직원 휴식', keys: ['KeyF'], pad: ['x'] }, { id: 'stop', label: '고른 직원 멈춤', keys: ['KeyH'], pad: [] },
      { id: 'auto', label: '추천 지시', keys: ['KeyG'], pad: ['y'] }, { id: 'end', label: '하루 마감 · 다음 날', keys: ['Enter'], pad: ['a'] }, { id: 'log', label: '근무 기록', keys: ['KeyL'], pad: ['back'] }, { id: 'home', label: '시점 맞춤', keys: ['KeyR'], pad: ['rs'] },
      { id: 'camL', label: '시점 왼쪽', keys: ['KeyA', 'ArrowLeft'], pad: ['lx-'] }, { id: 'camR', label: '시점 오른쪽', keys: ['KeyD', 'ArrowRight'], pad: ['lx+'] }, { id: 'camU', label: '시점 위', keys: ['KeyW', 'ArrowUp'], pad: ['ly-'] }, { id: 'camD', label: '시점 아래', keys: ['KeyS', 'ArrowDown'], pad: ['ly+'] },
    ],
    quick: [
      '직원을 격리실에 보내 작업하고, 에너지를 그날 목표량만큼 모으면 하루를 마감할 수 있어요.',
      '격리실을 누르고 → 작업(관찰 · 교감 · 급양 · 억제)을 고르고 → 보낼 직원을 눌러요. Space로 시간을 멈추고, 멈춘 동안에도 지시할 수 있어요.',
      '작업이 나쁘게 끝나거나 수칙을 어기면 게이지가 차고, 다 차면 이형체가 격리를 벗어나요. 마지막 날까지 시설을 지키면 이겨요.',
    ],
    rules: [
      { h: '목표', p: ['혼자 하는 실시간 시설 운영 게임이에요(PC 전용). 정체 모를 「이형체」를 가둔 지하 시설을 맡아, 정해진 날수(짧게 5일 · 보통 8일 · 길게 12일)를 버티면 이겨요.', '지는 경우는 셋이에요. ① 세 이형체가 동시에 탈주 ② 직원이 한 명도 남지 않음 ③ 본부 경고 3회(그날 목표량을 못 채우면 경고 1회).'] },
      { h: '하루의 흐름', p: ['하루는 6차, 한 차는 20초예요(위쪽 시계). 시간은 실시간으로 흐르고, Space로 멈출 수 있어요. 멈춘 동안에도 지시는 다 돼요. 배속은 1 · 2 · 3.', '에너지가 목표량에 닿으면 「마감」 단추가 켜져요. 일찍 마감하면 남은 차만큼, 더 일하면 초과분만큼 비축 에너지를 받아요. 6차가 끝나면 저절로 마감돼요(못 채웠으면 본부 경고).', '탈주한 이형체가 있으면 다시 가둘 때까지 연장 근무를 해요.', '아침마다 새 이형체를 셋 중 하나 골라 들여요. 이형체가 늘면 새 구역이 열려요(짧게 3일째 · 보통 5일째 · 길게 5 · 11일째). 2일째부터는 사건도 하나 일어나요.'] },
      { h: '작업', p: ['격리실을 누르면 창이 떠요. 작업을 고르고, 보낼 직원을 누르면 걸어가서 작업해요. 직원을 먼저 고른 뒤 격리실을 오른쪽 누르기 해도 돼요(그러면 작업 단추에 그 직원의 성공률이 보여요).', '작업은 넷이에요. 관찰(신중) · 교감(공감) · 급양(절제) · 억제(담력). 괄호 안 능력치가 높은 직원일수록 잘해요.', '작업은 결과 칸 8개가 하나씩 차오르며 진행돼요. 초록 칸 = 성공(에너지 + 관찰 수치), 붉은 칸 = 실패(직원이 체력이나 정신 피해).', '성공 6칸 이상이면 「좋음」(선호 작업이면 게이지 −1), 3칸 이하면 「나쁨」(게이지 +1, 기피 작업이면 +2)이에요.', '예시: 「온실의 손님」은 급양을 좋아해요. 절제 3인 급양 직원을 보내면 칸마다 성공률이 70%를 넘어요.'] },
      { h: '기록 열람과 관찰 수치', p: ['이형체마다 기록 문서가 있어요: 겉모습, 관찰 일지, 작업 선호, 관리 수칙, 탈주 · 이변 정보. 처음에는 대부분 가려져 있어요.', '작업의 성공 칸마다 그 이형체의 「관찰 수치」가 쌓여요(관찰 작업은 1.5배). 격리실 창의 「기록」에서 관찰 수치를 써서 항목을 하나씩 열람해요.', '선호를 열람하면 성공률이 보이고, 수칙을 열람하면 위반이 될 지시에 붉게 「위반」이 떠요. 모르는 수칙도 두 번 어기면 사례를 대조해 밝혀져요.', '수칙을 어기고 작업을 시작하면 성공률이 20%p 떨어지고 게이지가 2 올라요. 차가 넘어갈 때 판정되는 수칙도 있어요(예: 두 차 동안 방치하면 게이지 +1).'] },
      { h: '장비 추출', p: ['격리실 창의 「추출」에서 그 이형체의 고유 장비를 만들어요. 그 이형체의 관찰 수치와 비축 에너지가 들고, 이형체마다 만들 수 있는 수가 정해져 있어요.', '무기(제압 피해) · 방호구(받는 피해 감소) · 장신구(HE 등급부터)가 있고, 직원 한 명이 종류마다 하나씩 장착해요. 장착한 장비는 단면도의 직원 모습과 아래 초상 옆에 색으로 보여요.', '장비는 이 판 안에서만 남아요.'] },
      { h: '탈주와 제압', p: ['게이지가 다 차면 탈주형 이형체는 격리실을 벗어나 복도를 돌아다녀요. 가까운 직원을 치고, 차가 넘어갈 때마다 같은 층 격리실을 자극해요. 격리실 안에서 작업 중인 직원과 휴게실의 직원은 안전해요.', '직원을 고르고(끌어서 여럿을 한꺼번에 고를 수 있어요) 탈주체를 오른쪽 누르기 하면 제압하러 가요. 체력을 0으로 만들면 다시 가둬요.', '이변형 이형체는 걸어 나오지 않고 「이변」을 일으켜요(전 직원 정신 감소, 에너지 손실 등).', '경보 단계: 평시 → 주의(게이지 한 칸 남음 · 공황) → 경계(탈주 1건) → 비상(탈주 2건, 차마다 전 직원 정신 −2). 3건이면 져요.'] },
      { h: '직원', p: ['체력이 0이 되면 그 직원을 잃어요. 정신이 0이 되면 3차 동안 공황에 빠져 지시를 듣지 않고, 문을 건드리거나 동료를 밀쳐요.', '공황 직원은 다른 직원을 고른 뒤 그 직원을 오른쪽 누르기 하면 진정시키러 가요(공감이 높을수록 잘 돼요).', '휴게실(맨 위층 왼쪽)을 오른쪽 누르기 하거나 F를 누르면 쉬러 가요. 쉬는 동안 체력과 정신이 차올라요.', '하루가 끝나면 모두 조금 회복해요. 마감 뒤에는 비축 에너지로 새 직원을 채용하고 시설을 강화해요. 직원은 16명이 있고 호출 부호마다 얼굴이 정해져 있어요.'] },
      { h: '조작', p: ['왼쪽 누르기: 격리실 · 직원 고르기 / 빈 곳에서 끌기: 직원 여럿 고르기 / Shift + 누르기: 더 고르기.', '오른쪽 누르기: 고른 직원에게 지시(격리실 = 작업, 탈주체 = 제압, 공황 직원 = 진정, 휴게실 = 휴식, 복도 = 이동). 고른 것이 없으면 창 닫기.', '휠: 확대 · 축소 / 가운데 단추나 오른쪽 단추로 끌기 · WASD · 화살표: 시점 이동 / R: 시점 맞춤.', 'Space 정지 · 1 2 3 배속 · Tab 다음 직원 · T 모두 고르기 · Z X C V 작업 보내기 · F 휴식 · G 추천 지시 · Enter 마감 · L 기록(조작 설정에서 바꿀 수 있어요).'] },
      { h: 'AI', p: ['AI 자리로 두면 AI가 판을 끝까지 운영해요. 난이도는 쉬움 · 보통 · 어려움. 어려움은 밝혀진 수칙을 빠짐없이 지키고 위험한 지시를 피해요. 판마다 조심성과 씀씀이가 조금씩 달라요.'] },
      { h: '만든 것', p: ['직원을 보내 작업하고 실패하면 탈주한다는 틀, 정보 열람과 장비 추출은 「Lobotomy Corporation」(Project Moon)을 참고했어요. 이형체 · 이름 · 수칙 · 수치는 모두 이 게임에서 새로 만든 것이에요.', '이형체 · 직원 초상 · 시설 배경 그림은 이 PC의 그림 생성 도구(WAI-illustrious-SDXL v17 + 림버스 컴퍼니풍 그림체 LoRA)로 만들었어요. 그림체만 빌렸고 원작 인물 · 장면은 그리지 않았어요. 장비 표시와 작은 인물은 코드로 그렸어요.'] },
    ],
    hint: (S) => hintOf(S),
    init, actor, apply, ai, result, mount, _logic: { tick, act },
  };
  // 등급 설명은 등급 표(GR)에서 자동으로
  def.rules.splice(1, 0, { h: '등급', p: ['이형체는 다섯 등급이에요: ' + GR.slice(1).map((g) => g.n).join(' → ') + '. 뒤로 갈수록 에너지도 피해도 커지고 수칙이 많아져요. 장비의 등급은 그것이 나온 이형체의 등급과 같아요.',
    GR.slice(1).map((g) => g.n + ': 작업 에너지 최대 ' + g.en + ' · 실패 칸 피해 ' + r1(g.dmg * BOXD) + ' · 탈주체 체력 ' + g.hp).join(' / '), '날이 갈수록 높은 등급이 후보로 나와요. ALEPH는 판의 뒤쪽에서만 보여요.'] });
  def.codex = codexFn;
  L.register(def);
  function mount(root, api) {
    const h = L.h, doc = root.ownerDocument;
    const styleEl = h('style', { text: CSS }); doc.head.append(styleEl);
    const el = h('div', { class: 'ct' }); root.append(el);
    const top = h('div', { class: 'ct-top' }), mid = h('div', { class: 'ct-mid' }), bot = h('div', { class: 'ct-bot' });
    const cv = h('canvas'), feed = h('div', { class: 'ct-feed' }), psEl = h('div', { class: 'ct-ps', hidden: true }), selbar = h('div', { class: 'ct-selbar', hidden: true });
    mid.append(cv, feed, psEl, selbar); el.append(top, mid, bot);
    const ctx = cv.getContext('2d');
    let S = null, dead = false, raf = 0, lastT = 0, acc = 0, paused = true, speed = 1, aiAcc = 0, aiWait = 0, saveT = 0;
    let sel = [], panel = null, pnEl = null, pnSig = '', ov = null, ovKind = '', ntab = 0, lastPh = '', lastEv = -1, tipEl = null;
    const cam = { x: 0, y: 0, z: 1, fit: 1, w: 800, h: 500, dpr: 1, tx: null, ty: null, user: false };
    const prev = {}, fl = [], rings = [], flash = {}, imgs = {};
    let uiHeld = false;
    let drag = null, hover = null, stripSig = '', topSig = '', dayIntro = 0;
    const isAI = () => !!(api.players[0] && api.players[0].ai), lvAI = () => (api.players[0] && api.players[0].lv) || 2;
    const mine = () => !!S && !S.over && !isAI();
    const dspd = () => (L.debug && L.debug.speed) || 1;
    const sfx = (n, o) => { if (dspd() > 2) return; try { api.sfx(n, o); } catch (e) {} };
    const byId = (id) => S.staff.find((s) => s.id === id);
    const img = (src) => { let o = imgs[src]; if (!o) { o = imgs[src] = { im: new Image(), ok: false, bad: false }; o.im.onload = () => { o.ok = true; }; o.im.onerror = () => { o.bad = true; }; o.im.src = src; } return o; };
    const entImg = (E) => { const o = ART && E.img ? img(AS + E.img + '.webp') : null; return o && o.ok ? o.im : img(glSrc(E)).im; };
    const zoomable = (d, cap) => { d.classList.add('z'); d.addEventListener('click', (e) => { const im = d.querySelector('img'); if (im) { e.stopPropagation(); zoom(im.currentSrc || im.src, cap); } }); return d; };
    const thumb = (E, w, hgt) => { const d = h('div', { class: 'ct-th', style: { '--hu': E.hu, width: w + 'px', height: hgt + 'px' } }); d.innerHTML = thumbHTML(E); return d; };
    const face = (st, sz) => { const d = h('span', { class: 'ct-face' + (st.dead ? ' dead' : ''), style: { width: sz + 'px', height: sz + 'px', '--rc': ROLES[st.role].c } }); d.innerHTML = faceHTML(st); return d; };
    const bars = (st) => h('span', { class: 'ct-bars' }, h('i', { class: 'hp' }, h('b', { style: { width: Math.max(0, st.hp / hpMax(st) * 100) + '%' } })), h('i', { class: 'sp' }, h('b', { style: { width: Math.max(0, st.sp / spMax(st) * 100) + '%' } })));
    const kbd = (id) => { try { return (L.ui && L.ui.keyLabel && L.ui.keyLabel(ID, id)) || ''; } catch (e) { return ''; } };
    const tipOf = (t, id) => { const k = kbd(id); return k ? t + ' [' + k + ']' : t; };

    /* ---- 진행 ---- */
    function doAct(a, quiet) {
      if (!S || S.over) return false;
      try { act(S, a); } catch (e) { if (!quiet) { try { api.toast(e.message); } catch (x) {} } return false; }
      after(); return true;
    }
    function human(a, quiet) { if (!mine()) return false; return doAct(a, quiet); }
    function after() {
      consume();
      if (S.ph !== lastPh || S.over) phaseChanged();
      pnSig = ''; stripSig = ''; topSig = '';
    }
    function phaseChanged() {
      const was = lastPh; lastPh = S.ph;
      seenPut(S);
      if (S.ph === 'day' && was !== 'day') { paused = !isAI(); dayIntro = 1; cam.user = false; fitCam(); sel = []; if (dspd() <= 2) { try { api.banner(S.day + '일째 근무', { sub: S.evt != null ? '사건: ' + EVENTS[S.evt].n : '목표 에너지 ' + S.quota, small: true, ms: 1400 }); } catch (e) {} } }
      if (S.ph !== 'day') { sel = []; }
      renderOv();
      try { api.setState(S); } catch (e) {}
    }
    function consume() {
      if (!S || S.last.id === lastEv) return; lastEv = S.last.id;
      const L_ = S.last;
      L_.ev.forEach((e) => {
        const d = h('div', { class: e.c, text: e.t }); d.onclick = () => d.remove(); feed.append(d);
        while (feed.children.length > 5) feed.firstChild.remove();
        setTimeout(() => { d.style.opacity = '0'; setTimeout(() => d.remove(), 450); }, e.c === 'bad' || e.c === 'warn' ? 6500 : 4200);
        if (e.r >= 0) flash[e.r] = { c: e.c, t: 1 };
      });
      (L_.fx || []).forEach((e) => {
        if (e.k === 'box') { if (e.ok) sfx('tick', { vol: 0.35 }); else sfx('thud', { vol: 0.3 }); }
        else if (e.k === 'dmg') { const st = byId(e.s); if (st) floatAt(st, (e.h ? '−' + e.h : '') + (e.h && e.m ? ' ' : '') + (e.m ? '−' + e.m : ''), e.h ? '#f09a88' : '#9cc3e6'); }
        else if (e.k === 'hit') { const b = brOf(S, e.r); if (b) { fl.push({ f: b.f, x: b.x + (Math.random() - 0.5) * 30, dy: -64, t: 0, txt: '−' + e.d, c: '#f3d588' }); rings.push({ f: b.f, x: b.x, t: 0, c: '243,213,136', r: 26 }); sfx('hit', { vol: 0.3 }); } }
        else if (e.k === 'atk') { const b = brOf(S, e.r); if (b) rings.push({ f: b.f, x: b.x, t: 0, c: '238,106,85', r: 46 }); sfx('thud', { vol: 0.5 }); }
        else if (e.k === 'start') sfx('click', { vol: 0.3 });
        else if (e.k === 'done') { fl.push({ f: roomF(e.r), x: roomX(e.r), dy: -(CH + RH * 0.55), t: 0, txt: GRADE[e.g] + ' · 에너지 +' + e.e, c: e.g === 2 ? '#8fd0c0' : e.g === 1 ? '#dfe3e0' : '#f09a88', big: 1 }); sfx(e.g === 0 ? 'warn' : 'chip', { vol: 0.6 }); }
        else if (e.k === 'breach') { sfx('warn'); try { api.buzz(40, 'alert'); } catch (x) {} if (mine() && !paused && dspd() <= 2) { /* 탈주가 나면 화면을 그쪽으로 */ focus(roomF(e.r), roomX(e.r)); } }
        else if (e.k === 'burst') sfx('thud'); else if (e.k === 'recon') sfx('win', { vol: 0.5 }); else if (e.k === 'panic') sfx('lose', { vol: 0.5 }); else if (e.k === 'zone') { cam.user = false; fitCam(); }
      });
      L_.ev = []; L_.fx = [];
    }
    const floatAt = (st, txt, c) => { const p = posOf(st); fl.push({ f: p.f, x: p.x, dy: p.in ? -(CH + 40) : -58, t: 0, txt, c }); };
    function stepSim(n) {
      for (const st of S.staff) prev['s' + st.id] = { f: st.f, x: st.x };
      for (const b of S.br) prev['b' + b.r] = { f: b.f, x: b.x };
      for (let i = 0; i < n && S.ph === 'day' && !S.over; i++) {
        if (isAI() && ++aiAcc >= (lvAI() === 1 ? 12 : 8)) { aiAcc = 0; aiStep(); if (S.ph !== 'day') break; }
        tick(S);
      }
      after();
    }
    function aiStep() {
      let a = null; try { a = ai(S, 0, lvAI()); } catch (e) { console.error('AI error', e); }
      if (!a) return;
      if (a.t === 'tick') (a.o || []).forEach((o) => { try { act(S, o); } catch (e) {} }); else { try { act(S, a); } catch (e) { console.error('AI act', e); } }
    }
    function frame(t) {
      if (dead) return; raf = requestAnimationFrame(frame);
      const dt = Math.max(0, Math.min(0.1, (t - (lastT || t)) / 1000)); lastT = t;
      if (!S) return;
      const blocked = !!doc.querySelector('.overlay[data-core]:not(.result), .overlay.rules-ov, .overlay.rotate-ov');
      if (!S.over && !blocked) {
        if (S.ph === 'day') {
          if (!paused) { acc += dt * speed * dspd() / TK; const n = Math.min(60, Math.floor(acc)); if (n > 0) { acc -= n; stepSim(n); } }
        } else if (isAI()) { aiWait += dt * dspd(); if (aiWait > 0.45) { aiWait = 0; aiStep(); after(); } }
      }
      camStep(dt); draw(t, dt); hud(t);
    }

    /* ---- 시점 ---- */
    const WB = () => ({ x0: LX0 - 14, x1: FW + 18 + (panel && !panel.mod && S && S.ph === 'day' ? 412 / cam.z : 0), y0: -12, y1: (S ? S.floors : 2) * FH + 6 });   // 오른쪽 창이 열려 있으면 그만큼 더 밀 수 있게
    function resize() {
      const r = mid.getBoundingClientRect(); if (!r.width || !r.height) return;
      cam.dpr = clamp((window.devicePixelRatio || 1) * (r.width * r.height > 2.6e6 ? 1 : 1.5), 2, 3); cam.w = r.width; cam.h = r.height;
      cv.width = Math.round(r.width * cam.dpr); cv.height = Math.round(r.height * cam.dpr);
      if (!cam.user) fitCam();
    }
    function fitCam() {
      if (!S) return; const b = WB(), openH = S.fo * FH + 18;
      cam.fit = Math.min(cam.w / (b.x1 - b.x0), cam.h / (b.y1 - b.y0));
      cam.z = clamp(Math.min(cam.w / (b.x1 - b.x0), cam.h / openH), 0.5, 2.2);
      cam.x = (b.x0 + b.x1) / 2; cam.y = b.y0 + Math.max(openH, cam.h / cam.z) / 2 - (cam.h / cam.z > openH ? (cam.h / cam.z - openH) / 2 : 0); cam.tx = cam.ty = null; clampCam();
    }
    function clampCam() {
      const b = WB(), hw = cam.w / cam.z / 2, hh = cam.h / cam.z / 2;
      cam.x = (b.x1 - b.x0) <= hw * 2 ? (b.x0 + b.x1) / 2 : clamp(cam.x, b.x0 + hw, b.x1 - hw);
      cam.y = (b.y1 - b.y0) <= hh * 2 ? (b.y0 + b.y1) / 2 : clamp(cam.y, b.y0 + hh, b.y1 - hh);
    }
    const sx = (wx) => (wx - cam.x) * cam.z + cam.w / 2, sy = (wy) => (wy - cam.y) * cam.z + cam.h / 2;
    const wx_ = (px) => (px - cam.w / 2) / cam.z + cam.x, wy_ = (py) => (py - cam.h / 2) / cam.z + cam.y;
    function focus(f, x) { cam.tx = x; cam.ty = f * FH + FH / 2; cam.user = true; }
    function camStep(dt) {
      const ax = api.input.axis('camL', 'camR'), ay = api.input.axis('camU', 'camD');
      if ((ax || ay) && !ov) { cam.x += ax * 620 * dt / cam.z; cam.y += ay * 620 * dt / cam.z; cam.tx = cam.ty = null; cam.user = true; }
      if (cam.tx != null) { const k = Math.min(1, dt * 7); cam.x += (cam.tx - cam.x) * k; cam.y += (cam.ty - cam.y) * k; if (Math.abs(cam.tx - cam.x) < 1 && Math.abs(cam.ty - cam.y) < 1) cam.tx = cam.ty = null; }
      clampCam();
    }
    /* 화면에 그릴 자리(틱 사이 보간). in: 격리실 안에서 작업 중 */
    function posOf(o, key) {
      const p = prev[key || 's' + o.id], k = paused ? 1 : clamp(acc, 0, 1);
      let x = o.x; if (p && p.f === o.f && Math.abs(p.x - o.x) < 60) x = p.x + (o.x - p.x) * k;
      const working = o.a && o.a.k === 'w' && o.a.ph === 1;
      return { f: o.f, x, in: working, lift: o.lt > 0 };
    }
    const feetY = (f) => f * FH + 10 + RH + CH - 7;

    /* ---- 그리기 ---- */
    const FONT = '"IBM Plex Sans KR", "Malgun Gothic", sans-serif';
    function draw(t, dt) {
      const z = cam.z, c = ctx;
      c.setTransform(cam.dpr, 0, 0, cam.dpr, 0, 0); c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high'; c.fillStyle = '#0b0f13'; c.fillRect(0, 0, cam.w, cam.h);
      if (!S) return;
      const b = WB(), fs = (px) => Math.max(11, Math.round(px * Math.min(1.5, Math.max(0.8, z))));
      // 암반
      c.fillStyle = '#10151a'; c.fillRect(sx(b.x0), sy(b.y0), (b.x1 - b.x0) * z, (b.y1 - b.y0) * z);
      // 승강기
      c.fillStyle = '#161d24'; c.fillRect(sx(EX - 26), sy(0), 52 * z, S.floors * FH * z);
      c.strokeStyle = '#2a343d'; c.lineWidth = 1; c.strokeRect(sx(EX - 26), sy(0), 52 * z, S.floors * FH * z);
      for (let f = 0; f < S.floors; f++) {
        const y0 = f * FH + 10, open = f < S.fo, cy = y0 + RH;
        // 복도
        c.fillStyle = open ? '#1a2229' : '#11161b'; c.fillRect(sx(f === 0 ? LX0 : EX - 26), sy(cy), ((f === 0 ? -LX0 : 26 - EX) + FW + 8) * z, CH * z);
        c.fillStyle = open ? '#2c3740' : '#1a2026'; c.fillRect(sx(f === 0 ? LX0 : EX - 26), sy(cy + CH - 5), ((f === 0 ? -LX0 : 26 - EX) + FW + 8) * z, 5 * z);
        // 승강기 문
        c.fillStyle = open ? '#27323b' : '#171d22'; c.fillRect(sx(EX - 18), sy(cy + 6), 36 * z, (CH - 11) * z);
        c.strokeStyle = '#3a4650'; c.beginPath(); c.moveTo(sx(EX), sy(cy + 6)); c.lineTo(sx(EX), sy(cy + CH - 5)); c.stroke();
        c.fillStyle = open ? '#9aa7ad' : '#4a555c'; c.font = '700 ' + fs(12) + 'px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'top';
        c.fillText('B' + (f + 1), sx(EX - 22), sy(y0 + 4)); c.font = fs(12) + 'px ' + FONT; c.fillText(ZONE[f].slice(0, 2), sx(EX - 22), sy(y0 + 4) + fs(12) + 4);
        if (!open) {
          c.fillStyle = 'rgba(8,10,12,.55)'; c.fillRect(sx(X0 - 6), sy(y0), (FW - X0 + 14) * z, (RH + CH) * z);
          c.fillStyle = '#5d6a72'; c.font = fs(14) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle';
          c.fillText('미개방 — ' + openDay(f) + '일째에 열림', sx(X0 + (FW - X0) / 2), sy(y0 + RH / 2));
        }
        if (f === 0) {   // 휴게실
          c.fillStyle = '#1c262b'; c.fillRect(sx(LX0), sy(y0 + 34), (LX1 - LX0 + 6) * z, (RH - 34) * z);
          c.strokeStyle = '#3d5a55'; c.lineWidth = 1.5; c.strokeRect(sx(LX0), sy(y0 + 34), (LX1 - LX0 + 6) * z, (RH - 34 + CH) * z);
          c.fillStyle = '#7fb5a6'; c.font = '700 ' + fs(12) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'top'; c.fillText('휴게실', sx((LX0 + LX1) / 2), sy(y0 + 40));
          c.fillStyle = '#5d7a74'; c.font = fs(11) + 'px ' + FONT; c.fillText('쉬면 회복 · 안전', sx((LX0 + LX1) / 2), sy(y0 + 40) + fs(12) + 4);
        }
      }
      // 격리실
      S.rooms.forEach((R, ri) => { if (roomF(ri) < S.fo) drawRoom(c, R, ri, t, fs); });
      // 직원 · 탈주체
      S.staff.forEach((st) => { if (!st.dead) drawStaff(c, st, t, fs); });
      S.br.forEach((bz) => drawBreach(c, bz, t, fs));
      // 떠오르는 글자
      for (let i = fl.length - 1; i >= 0; i--) {
        const o = fl[i]; o.t += dt; if (o.t > 1.4) { fl.splice(i, 1); continue; }
        c.globalAlpha = Math.min(1, (1.4 - o.t) * 2.5); c.font = '700 ' + fs(o.big ? 15 : 13) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle';
        const X = sx(o.x), Y = sy(feetY(o.f) + o.dy - o.t * 22);
        c.lineWidth = 3; c.strokeStyle = 'rgba(8,10,12,.85)'; c.strokeText(o.txt, X, Y); c.fillStyle = o.c; c.fillText(o.txt, X, Y);
      }
      for (let i = rings.length - 1; i >= 0; i--) { const o = rings[i]; o.t += dt * 2.6; if (o.t >= 1) { rings.splice(i, 1); continue; } c.globalAlpha = 1 - o.t; c.lineWidth = 3; c.strokeStyle = 'rgba(' + o.c + ',1)'; c.beginPath(); c.arc(sx(o.x), sy(feetY(o.f) - 26), (10 + o.r * o.t) * z, 0, 7); c.stroke(); }
      c.globalAlpha = 1;
      // 끌어서 고르기
      if (drag && drag.box) { c.strokeStyle = '#e3ae45'; c.fillStyle = 'rgba(227,174,69,.12)'; c.lineWidth = 1; const x = Math.min(drag.x0, drag.x), y = Math.min(drag.y0, drag.y), w = Math.abs(drag.x - drag.x0), hh = Math.abs(drag.y - drag.y0); c.fillRect(x, y, w, hh); c.strokeRect(x, y, w, hh); }
      // 경보 테두리(천천히 맥동)
      const al = alertOf(S);
      if (al >= 2 && S.ph === 'day') { const a = (0.16 + 0.1 * Math.sin(t / 520)) * (al === 3 ? 1.5 : 1) * (L.fx ? L.fx() : 1); const g = c.createRadialGradient(cam.w / 2, cam.h / 2, Math.min(cam.w, cam.h) * 0.42, cam.w / 2, cam.h / 2, Math.max(cam.w, cam.h) * 0.72); g.addColorStop(0, 'rgba(208,80,90,0)'); g.addColorStop(1, 'rgba(208,80,90,' + a + ')'); c.fillStyle = g; c.fillRect(0, 0, cam.w, cam.h); }
      for (const k in flash) { flash[k].t -= dt * 1.1; if (flash[k].t <= 0) delete flash[k]; }
    }
    function drawRoom(c, R, ri, t, fs) {
      const z = cam.z, f = roomF(ri), x0 = roomX(ri) - RW / 2, y0 = f * FH + 10, X = sx(x0), Y = sy(y0), W = RW * z, H = RH * z;
      if (X > cam.w || X + W < 0 || Y > cam.h || Y + H + CH * z < 0) return;
      c.fillStyle = '#12181d'; c.fillRect(X, Y, W, H);
      const selR = panel && panel.r === ri, hov = hover && hover.k === 'room' && hover.r === ri;
      if (R.e == null) {
        c.strokeStyle = '#2a343d'; c.setLineDash([5, 4]); c.lineWidth = 1; c.strokeRect(X + 0.5, Y + 0.5, W - 1, H - 1); c.setLineDash([]);
        c.fillStyle = '#4f5b63'; c.font = fs(12) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('빈 격리실', X + W / 2, Y + H / 2);
        return;
      }
      const E = ENT[R.e], gm = gMax(S, R), hot = !R.out && R.g >= gm - 1, im = entImg(E);
      if (im && im.complete && im.naturalWidth) {
        const iw = im.naturalWidth, ih = im.naturalHeight, isGl = im.src.slice(0, 5) === 'data:';
        if (isGl) { const hh = H * 0.72, ww = hh * 0.75; c.globalAlpha = R.out ? 0.25 : 0.9; c.drawImage(im, X + (W - ww) / 2, Y + H * 0.2, ww, hh); c.globalAlpha = 1; }
        else { const sh = iw * RH / RW, syy = Math.max(0, (ih - sh) * 0.2); if (R.out) c.filter = 'grayscale(.9) brightness(.8)'; c.drawImage(im, 0, syy, iw, Math.min(sh, ih), X, Y, W, H); c.filter = 'none'; }
      }
      // 위 이름 띠
      const lh = fs(12) + 8; c.fillStyle = 'rgba(10,13,16,.78)'; c.fillRect(X, Y, W, lh);
      c.fillStyle = TIER[E.tier].c; c.fillRect(X, Y, 4 * z + 2, lh);
      c.font = '700 ' + fs(12) + 'px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'middle'; c.fillStyle = '#f0ead8';
      const gw = c.measureText(TIER[E.tier].n).width + 8;   // 오른쪽 끝에 등급 이름
      c.textAlign = 'right'; c.fillStyle = TIER[E.tier].c; c.font = '700 ' + fs(10.5) + 'px ' + FONT; c.fillText(TIER[E.tier].n, X + W - 5, Y + lh / 2 + 1);
      c.font = '700 ' + fs(12) + 'px ' + FONT; c.textAlign = 'left'; c.fillStyle = '#f0ead8';
      let nm = E.no + ' ' + E.n; while (c.measureText(nm).width > W - 12 * z - 6 - gw && nm.length > 5) nm = nm.slice(0, -1);
      c.fillText(nm, X + 4 * z + 7, Y + lh / 2 + 1);
      // 아래: 게이지 칸 + 관찰 수치
      const ps = Math.max(8, 10 * z), gy = Y + H - ps - 5;
      c.fillStyle = 'rgba(10,13,16,.7)'; c.fillRect(X, gy - 4, W, ps + 9);
      for (let i = 0; i < gm; i++) { c.fillStyle = i < R.g ? (hot ? '#ee6a55' : '#e3ae45') : '#2c363e'; c.fillRect(X + 6 + i * (ps + 3), gy, ps, ps); }
      c.fillStyle = '#9cc3e6'; c.font = '700 ' + fs(11) + 'px ' + FONT; c.textAlign = 'right'; c.fillText('관찰 ' + Math.floor(R.pt), X + W - 6, gy + ps / 2 + 1);
      // 작업 중: 결과 칸
      const wk = R.wk >= 0 ? byId(R.wk) : null;
      if (wk && wk.a && wk.a.k === 'w' && wk.a.ph === 1) {
        const a = wk.a, bw = (W - 14) / NB, by = Y + lh + 4, bh = Math.max(9, 11 * z);
        c.fillStyle = 'rgba(10,13,16,.72)'; c.fillRect(X, Y + lh, W, bh + 8 + fs(11) + 4);
        for (let i = 0; i < NB; i++) { const ch = a.b[i]; c.fillStyle = ch === '1' ? '#69b3a6' : ch === '0' ? '#d0505a' : '#2c363e'; c.fillRect(X + 7 + i * bw, by, bw - 2, bh); if (i === a.b.length) { c.fillStyle = WORKS[a.w].c; c.fillRect(X + 7 + i * bw, by, (bw - 2) * clamp(a.t / BOX_T, 0, 1), bh); } }
        c.font = fs(11) + 'px ' + FONT; c.textAlign = 'left'; c.textBaseline = 'top'; c.fillStyle = WORKS[a.w].c; c.fillText(WORKS[a.w].n + ' · ' + wk.n + ' · ' + Math.round(a.p * 100) + '%' + (a.nv ? ' · 위반' : ''), X + 7, by + bh + 3);
      }
      if (R.out) { c.fillStyle = 'rgba(208,80,90,.16)'; c.fillRect(X, Y, W, H); c.fillStyle = '#f3b0a4'; c.font = '700 ' + fs(15) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('탈주 중', X + W / 2, Y + H / 2); }
      // 테두리
      const fz = flash[ri];
      c.lineWidth = selR ? 3 : hot || R.out ? 2 : 1.5;
      c.strokeStyle = selR ? '#e3ae45' : R.out ? '#ee6a55' : hot ? 'rgba(238,106,85,' + (0.6 + 0.4 * Math.sin(t / 380)) + ')' : hov ? '#8a97a0' : '#3a4650';
      c.strokeRect(X + 0.5, Y + 0.5, W - 1, H - 1);
      if (fz) { c.globalAlpha = Math.min(1, fz.t) * 0.85; c.lineWidth = 4; c.strokeStyle = fz.c === 'ok' ? '#69b3a6' : fz.c === 'bad' ? '#ee6a55' : fz.c === 'warn' ? '#e3ae45' : '#7fa3c7'; c.strokeRect(X + 2, Y + 2, W - 4, H - 4); c.globalAlpha = 1; }
      // 문
      c.fillStyle = R.out ? '#5a2a2a' : '#2f3a43'; c.fillRect(sx(roomX(ri) - 11), sy(y0 + RH), 22 * z, 7 * z);
      // 가는 중 · 기다리는 직원 표시
      const coming = S.staff.filter((s) => !s.dead && s.a && s.a.k === 'w' && s.a.r === ri && s.a.ph === 0);
      if (coming.length) { c.font = fs(11) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'top'; c.fillStyle = WORKS[coming[0].a.w].c; c.fillText('▼ ' + WORKS[coming[0].a.w].n + (coming.length > 1 ? ' +' + (coming.length - 1) : ''), sx(roomX(ri)), sy(y0 + RH + 8)); }
    }
    function drawFace(c, st, X, Y, r) {
      const o = ART ? img(faceSrc(st.fc, st.pn)) : null;
      c.save(); c.beginPath(); c.arc(X, Y, r, 0, 7); c.closePath(); c.fillStyle = '#d9cdb8'; c.fill();
      if (o && o.ok) { c.clip(); c.drawImage(o.im, X - r, Y - r, r * 2, r * 2); }
      c.restore();
    }
    function drawStaff(c, st, t, fs) {
      const z = cam.z, p = posOf(st), isSel = sel.includes(st.id);
      let X, Y, k = 1;
      if (p.in) { const ri = st.a.r; X = sx(roomX(ri) - RW / 2 + 24); Y = sy(roomF(ri) * FH + 10 + RH - 18); k = 0.8; }
      else { X = sx(p.x); Y = sy(feetY(p.f)); }
      if (X < -40 || X > cam.w + 40 || Y < -20 || Y > cam.h + 80) return;
      const u = z * k, moving = !p.in && prev['s' + st.id] && Math.abs(prev['s' + st.id].x - st.x) > 0.5 && !paused, bob = moving ? Math.sin(t / 110 + st.id) * 1.5 * u : 0;
      const bh = 26 * u, bw = 20 * u, hr = 12.5 * u, col = ROLES[st.role].c;
      if (p.lift) c.globalAlpha = 0.55;
      if (isSel) { c.strokeStyle = '#e3ae45'; c.lineWidth = 2; c.beginPath(); c.ellipse(X, Y, 17 * u, 5 * u, 0, 0, 7); c.stroke(); }
      // 몸(방호구: 옷 테두리 색, 무기: 손의 도구, 장신구: 가슴의 점)
      c.fillStyle = col; c.beginPath(); c.moveTo(X - bw / 2, Y); c.lineTo(X - bw * 0.38, Y - bh + bob); c.lineTo(X + bw * 0.38, Y - bh + bob); c.lineTo(X + bw / 2, Y); c.closePath(); c.fill();
      if (st.ar) { c.strokeStyle = 'hsl(' + ENT[GEAR[st.ar].ei].hu + ',55%,68%)'; c.lineWidth = 2.2 * u; c.stroke(); }
      if (st.wp) { const hu = ENT[GEAR[st.wp].ei].hu; c.strokeStyle = 'hsl(' + hu + ',60%,74%)'; c.lineWidth = 2.6 * u; c.beginPath(); c.moveTo(X + bw * 0.62, Y - 3 * u); c.lineTo(X + bw * 0.62, Y - bh - 6 * u + bob); c.stroke(); c.fillStyle = 'hsl(' + hu + ',60%,74%)'; c.fillRect(X + bw * 0.62 - 3 * u, Y - bh - 9 * u + bob, 6 * u, 5 * u); }
      if (st.ac) { c.fillStyle = 'hsl(' + ENT[GEAR[st.ac].ei].hu + ',70%,78%)'; c.beginPath(); c.arc(X, Y - bh * 0.55 + bob, 2.8 * u, 0, 7); c.fill(); }
      drawFace(c, st, X, Y - bh - hr * 0.72 + bob, hr);
      c.lineWidth = 1.6 * u; c.strokeStyle = st.pn ? '#ee6a55' : col; c.beginPath(); c.arc(X, Y - bh - hr * 0.72 + bob, hr, 0, 7); c.stroke();
      c.globalAlpha = 1;
      if (p.in) return;
      // 머리 위: 체력 · 정신 막대
      const top = Y - bh - hr * 1.72 - 9 * u, w = 26 * u;
      c.fillStyle = '#1b2229'; c.fillRect(X - w / 2, top, w, 3 * u + 1); c.fillRect(X - w / 2, top + 4 * u + 1, w, 3 * u + 1);
      c.fillStyle = '#c8695c'; c.fillRect(X - w / 2, top, w * clamp(st.hp / hpMax(st), 0, 1), 3 * u + 1);
      c.fillStyle = '#6e9fd0'; c.fillRect(X - w / 2, top + 4 * u + 1, w * clamp(st.sp / spMax(st), 0, 1), 3 * u + 1);
      if (st.pn) { c.fillStyle = '#ee6a55'; c.font = '700 ' + fs(11) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'bottom'; c.fillText('공황', X, top - 2); }
      else if (st.a && st.a.k === 's' && !p.in) { c.fillStyle = '#f3d588'; c.font = '700 ' + fs(11) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'bottom'; c.fillText('제압', X, top - 2); }
      else if (st.a && st.a.k === 'r' && inLounge(st) && frac(st) < 0.995) { c.fillStyle = '#7fb5a6'; c.font = fs(11) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'bottom'; c.fillText('휴식', X, top - 2); }
      if (!p.in && (isSel || (hover && hover.k === 'staff' && hover.id === st.id) || (z >= 1.15 && !inLounge(st)))) { c.font = fs(11) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'top'; c.lineWidth = 3; c.strokeStyle = 'rgba(8,10,12,.9)'; c.strokeText(st.n, X, Y + 3); c.fillStyle = isSel ? '#f3d588' : '#c9d2d4'; c.fillText(st.n, X, Y + 3); }
    }
    function drawBreach(c, b, t, fs) {
      const z = cam.z, R = S.rooms[b.r], E = ENT[R.e], p = posOf(b, 'b' + b.r), X = sx(p.x), Y = sy(feetY(p.f)), r = 22 * z, cy = Y - r - 4 * z;
      const im = entImg(E), pulse = 1 + 0.05 * Math.sin(t / 300);
      c.save(); c.beginPath(); c.arc(X, cy, r * pulse, 0, 7); c.closePath(); c.fillStyle = '#2a1414'; c.fill(); c.clip();
      if (im && im.complete && im.naturalWidth) { const iw = im.naturalWidth, ih = im.naturalHeight; if (im.src.slice(0, 5) === 'data:') c.drawImage(im, X - r * 0.7, cy - r * 0.9, r * 1.4, r * 1.8); else { const s = Math.min(iw, ih) * 0.7; c.drawImage(im, (iw - s) / 2, Math.max(0, (ih - s) * 0.18), s, s, X - r * pulse, cy - r * pulse, r * 2 * pulse, r * 2 * pulse); } }
      c.restore();
      c.lineWidth = 3; c.strokeStyle = '#ee6a55'; c.beginPath(); c.arc(X, cy, r * pulse, 0, 7); c.stroke();
      const w = 54 * z, top = cy - r - 12 * z;
      c.fillStyle = '#1b2229'; c.fillRect(X - w / 2, top, w, 6 * z); c.fillStyle = '#ee6a55'; c.fillRect(X - w / 2, top, w * clamp(b.hp / b.mx, 0, 1), 6 * z);
      c.font = '700 ' + fs(11) + 'px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'bottom'; c.lineWidth = 3; c.strokeStyle = 'rgba(8,10,12,.9)'; c.strokeText(E.no + ' ' + Math.max(0, b.hp) + '/' + b.mx, X, top - 2); c.fillStyle = '#f3b0a4'; c.fillText(E.no + ' ' + Math.max(0, b.hp) + '/' + b.mx, X, top - 2);
    }

    /* ---- 위 막대 · 아래 직원 띠 ---- */
    const stLabel = (st) => {
      if (st.dead) return ['사망', 'bad']; if (st.pn) return ['공황 · ' + st.pn + '차 남음', 'bad'];
      const a = st.a, q = st.q ? ' → 다음 있음' : '';
      if (!a) return [inLounge(st) ? '휴게실 대기' : '대기', ''];
      if (a.k === 'r') return [inLounge(st) ? (frac(st) >= 0.995 ? '휴게실 대기' : '휴식 중') : '휴게실로 이동', 'set'];
      if (a.k === 'm') return ['이동 중', 'set']; if (a.k === 'c') return ['진정시키는 중', 'set'];
      const E = ENT[S.rooms[a.r].e]; if (!E) return ['대기', ''];
      if (a.k === 's') return ['제압 ' + E.no, 'set'];
      return [E.no + ' ' + WORKS[a.w].n + (a.ph ? ' ' + a.b.length + '/' + NB : ' 이동') + q, 'set'];
    };
    function hud(t) {
      const T = S.ph === 'day' ? Math.min(S.turn, 99) : 0, en = Math.floor(S.en), al = alertOf(S), ev = S.evt != null ? EVENTS[S.evt] : null;
      const sig = [S.ph, S.day, S.fo, en >= S.quota, S.quota, S.bud, S.warn, al, paused, speed, S.br.length, S.evt, isAI()].join('|');
      if (sig !== topSig && !uiHeld) {
        topSig = sig; top.innerHTML = '';
        const clk = h('span', { class: 'ct-clk', title: '하루 = 6차(차마다 20초). 차가 넘어갈 때 수칙 · 탈주체 행동이 판정돼요.' }); for (let i = 0; i < TURNS; i++) clk.append(h('i', {}, h('b')));
        const wp = h('span', { class: 'ct-warnp' }); for (let i = 0; i < 3; i++) wp.append(h('i', { class: i < S.warn ? 'on' : '' }));
        const enEl = h('div', { class: 'ct-en', title: '오늘의 에너지 / 목표량' }, h('i', { class: en >= S.quota && S.quota ? 'full' : '', style: { width: (S.quota ? Math.min(100, en / S.quota * 100) : 0) + '%' } }), h('span', { text: S.ph === 'day' ? '에너지 ' + en + ' / ' + S.quota : S.ph === 'night' ? '근무 마감' : '인수 대기' }));
        const B = (txt, id, fn, cls, title) => { const b = h('button', { class: 'ct-btn ' + (cls || ''), type: 'button', text: txt, title: tipOf(title || txt, id), onclick: (e) => { e.currentTarget.blur(); fn(); } }); if (id) b.setAttribute('data-action', id); return b; };
        top.append(h('div', { class: 'ct-day' }, h('span', {}, h('b', { text: S.day + ' / ' + S.days }), '일째'), h('span', { class: 'ct-dt', text: '' })), clk, enEl,
          h('span', { class: 'ct-chip', title: '비축 에너지 — 채용 · 강화 · 장비 추출에 써요' }, '비축 ', h('b', { text: '' + S.bud })),
          h('span', { class: 'ct-chip', title: '본부 경고 — 목표 미달마다 1회, 3회면 패배' }, '경고 ', wp),
          h('span', { class: 'ct-chip al', style: { color: ALERT[al].c }, title: '경보 단계 — 주의: 게이지 한 칸 남음 · 공황 / 경계: 탈주 1건 / 비상: 탈주 2건(차마다 전 직원 정신 −2). 3건이면 패배', text: '경보 ' + ALERT[al].n }),
          ev ? h('span', { class: 'ct-chip', title: ev.d, style: { maxWidth: '170px', overflow: 'hidden', textOverflow: 'ellipsis' }, text: '사건: ' + ev.n }) : '');
        if (S.ph === 'day' && mine()) {
          top.append(B(paused ? '▶ 재개' : '⏸ 정지', 'pause', togglePause, paused ? 'pri' : '', '일시정지 · 재개'),
            B('1×', 'sp1', () => setSpeed(1), speed === 1 ? 'on' : ''), B('2×', 'sp2', () => setSpeed(2), speed === 2 ? 'on' : ''), B('3×', 'sp3', () => setSpeed(3), speed === 3 ? 'on' : ''),
            B('추천', 'auto', () => { if (human({ t: 'auto' })) sfx('click'); }, '', '손이 빈 직원에게 추천 지시'),
            B('마감', 'end', endDayAsk, en >= S.quota && !S.br.length ? 'pri' : '', '하루 마감(목표를 채운 뒤)'));
        }
        top.append(B('기록', 'log', logSheet, '', '근무 기록'));
        try { window.dispatchEvent(new Event('lounge-keys')); } catch (e) {}
      }
      const dtEl = top.querySelector('.ct-dt'); if (dtEl) dtEl.textContent = S.ph === 'day' ? (T > TURNS ? '연장 근무' : T + '차 · ' + Math.ceil((SEG - S.t % SEG) * TK) + '초') : S.ph === 'night' ? '마감' : '';
      const cells = top.querySelectorAll('.ct-clk i'); cells.forEach((c, i) => { const v = S.ph !== 'day' ? 0 : i < T - 1 ? 1 : i === T - 1 ? (S.t % SEG) / SEG : 0; c.firstChild.style.width = (T > TURNS ? 100 : v * 100) + '%'; c.className = T > TURNS ? 'ot' : ''; });
      const fillEl = top.querySelector('.ct-en>i'), spanEl = top.querySelector('.ct-en>span'); if (fillEl && S.ph === 'day') { fillEl.style.width = (S.quota ? Math.min(100, S.en / S.quota * 100) : 0) + '%'; const tx = '에너지 ' + en + ' / ' + S.quota; if (spanEl.textContent !== tx) spanEl.textContent = tx; }
      psEl.hidden = !(S.ph === 'day' && paused && mine() && !ov);
      if (!psEl.hidden) psEl.textContent = dayIntro ? '일시정지 — 지시를 내린 뒤 ' + (kbd('pause') || 'Space') + '로 근무 시작' : '일시정지 중 — 지시는 계속 내릴 수 있어요';
      strip(); renderPanel(); renderSel();
    }
    function strip() {
      const sig = S.staff.map((st) => [st.id, st.dead, st.pn, Math.ceil(st.hp), Math.ceil(st.sp), stLabel(st)[0], st.wp, st.ar, st.ac, sel.includes(st.id)].join(',')).join('|');
      if (sig === stripSig || uiHeld) return; stripSig = sig;
      const keep = bot.scrollLeft; bot.innerHTML = '';
      S.staff.forEach((st, i) => {
        const lb = stLabel(st), gp = h('span', { class: 'ct-gp' });
        ['wp', 'ar', 'ac'].forEach((k) => { if (st[k]) gp.append(h('i', { class: k === 'ac' ? 'x' : '', title: SLOT_N[GEAR[st[k]].slot] + ': ' + GEAR[st[k]].n + ' — ' + gearText(GEAR[st[k]]), style: { background: 'hsl(' + ENT[GEAR[st[k]].ei].hu + ',55%,66%)' } })); });
        const b = h('button', { class: 'ct-st' + (sel.includes(st.id) ? ' on' : '') + (st.pn ? ' pn' : '') + (st.dead ? ' dead' : ''), type: 'button', style: { '--rc': ROLES[st.role].c }, title: st.n + ' · ' + ROLES[st.role].n + ' — 누르면 선택, 두 번 누르면 상세',
          onclick: (e) => { e.currentTarget.blur(); pickStaff(st.id, e.shiftKey || e.ctrlKey, true); }, ondblclick: () => staffSheet(st.id), oncontextmenu: (e) => { e.preventDefault(); if (st.pn && sel.length) { const s0 = sel.map(byId).find((o) => o && avail(o) && o.id !== st.id); if (s0) orderOne(s0, { k: 'c', c: st.id }); } else staffSheet(st.id); } },
          face(st, 80), h('span', { class: 'i' }, h('span', { class: 'n' }, st.n, h('small', { text: ROLES[st.role].n })), bars(st), h('span', { class: 'a ' + lb[1], text: lb[0] }), h('span', { style: { color: '#7d8a91', fontSize: '11px' }, text: st.dead ? '' : '체력 ' + Math.ceil(st.hp) + ' · 정신 ' + Math.ceil(st.sp) })), gp, h('span', { class: 'ct-num', text: '' + (i + 1) }));
        bot.append(b);
      });
      bot.scrollLeft = keep;
    }
    function renderSel() {
      const list = sel.map(byId).filter((s) => s && !s.dead);
      const show = S.ph === 'day' && mine() && list.length && !ov;
      const sig = show ? list.map((s) => s.id).join(',') : '';
      if (selbar._sig === sig) return; selbar._sig = sig; selbar.hidden = !show; if (!show) return;
      selbar.innerHTML = '';
      const B = (t, id, fn) => { const b = h('button', { class: 'ct-btn sm', type: 'button', text: t, title: tipOf(t, id), onclick: (e) => { e.currentTarget.blur(); fn(); } }); if (id) b.setAttribute('data-action', id); return b; };
      selbar.append(h('span', { style: { color: '#f3d588', fontWeight: 700 }, text: list.length === 1 ? list[0].n : list.length + '명 선택' }), h('span', { style: { color: '#93a0a6' }, title: '오른쪽 누르기: 격리실 = 작업, 탈주체 = 제압, 공황 직원 = 진정, 휴게실 = 휴식, 복도 = 이동', text: '오른쪽 누르기로 지시' }),
        B('휴식', 'rest', () => orderSel({ k: 'r' })), B('멈춤', 'stop', () => orderSel({ k: 'x' })), list.length === 1 ? B('상세', '', () => staffSheet(list[0].id)) : '');
      try { window.dispatchEvent(new Event('lounge-keys')); } catch (e) {}
    }

    /* ---- 지시 ---- */
    function togglePause() { if (!mine() || S.ph !== 'day') return; paused = !paused; dayIntro = 0; topSig = ''; sfx('click'); }
    function setSpeed(n) { speed = n; topSig = ''; if (paused && mine() && S.ph === 'day') { paused = false; dayIntro = 0; } }
    function endDayAsk() { if (!mine() || S.ph !== 'day') return; if (S.en < S.quota) { api.toast('에너지 목표를 채워야 마감할 수 있어요'); return; } if (S.br.length) { api.toast('탈주한 이형체를 먼저 다시 가둬야 해요'); return; } human({ t: 'end' }); }
    function pickStaff(id, add, fromStrip) {
      const st = byId(id); if (!st || st.dead) return;
      if (add) { if (sel.includes(id)) sel = sel.filter((x) => x !== id); else sel.push(id); }
      else { if (fromStrip && sel.length === 1 && sel[0] === id) { const p = posOf(st); focus(p.f, p.x); } sel = [id]; }
      stripSig = ''; pnSig = ''; sfx('click', { vol: 0.5 });
    }
    function orderOne(st, o, quiet) { const ok = human(Object.assign({ t: 'ord', s: st.id }, o), quiet); if (ok) sfx('pop', { vol: 0.5 }); return ok; }
    function orderSel(o) { let n = 0; sel.map(byId).forEach((st, i) => { if (st && avail(st)) { const q = Object.assign({}, o); if (o.k === 'm') q.x = o.x + (i - (sel.length - 1) / 2) * 16; if (orderOne(st, q, true)) n++; } }); return n; }
    function sendWork(ri, w, st) {
      if (!st) { const c = sel.map(byId).filter((s) => s && avail(s)); st = c[0]; }
      if (!st) { panel = { r: ri, tab: 0, w }; pnSig = ''; return; }
      if (orderOne(st, { k: 'w', r: ri, w })) { if (panel && panel.r === ri) panel.w = null; pnSig = ''; }
    }
    function openRoom(ri, tab, modal) { const R = S.rooms[ri]; if (!R || R.e == null) return; panel = { r: ri, tab: tab || 0, w: null, mod: !!modal }; pnSig = ''; sfx('click', { vol: 0.5 });
      if (!modal && S.ph === 'day') { const edge = cam.w - 420 - RW * cam.z / 2 - 8, X = sx(roomX(ri)); if (X > edge) { cam.tx = cam.x + (X - edge) / cam.z; cam.ty = cam.y; cam.user = true; } }   // 창에 가리는 방이면 시설을 왼쪽으로 민다
    }
    function closePanel() { if (panel) { panel = null; pnSig = ''; } }

    /* ---- 격리실 창(작업 · 기록 · 추출) ---- */
    function renderPanel() {
      if (!panel || !S.rooms[panel.r] || S.rooms[panel.r].e == null) { if (pnEl) { pnEl.remove(); pnEl = null; } panel = null; return; }
      const ri = panel.r, R = S.rooms[ri], E = ENT[R.e], b = brOf(S, ri), can = mine();
      const selS = sel.map(byId).filter((s) => s && avail(s));
      const sig = [ri, panel.tab, panel.w, panel.eq, R.g, Math.floor(R.pt), R.out, R.wk, b ? b.hp : '', JSON.stringify(R.un), R.rv.join(''), S.bud, selS.map((s) => s.id).join(','), S.turn, JSON.stringify(S.gear), S.staff.map((s) => (s.dead ? 'x' : s.pn ? 'p' : (s.a ? s.a.k + (s.a.ph || 0) + (s.a.r == null ? '' : s.a.r) : '-')) + Math.round(frac(s) * 10) + (s.wp || '') + (s.ar || '') + (s.ac || '')).join(''), S.ph, can].join('|');
      if ((sig === pnSig || uiHeld) && pnEl) return; pnSig = sig;
      const keepScroll = pnEl && pnEl._b ? pnEl._b.scrollTop : 0, sameTab = pnEl && pnEl._k === ri + ':' + panel.tab + ':' + panel.w;
      if (pnEl) pnEl.remove();
      pnEl = h('div', { class: 'ct-pn r' + (panel.mod ? ' mod' : '') }); pnEl._k = ri + ':' + panel.tab + ':' + panel.w;
      pnEl.addEventListener('contextmenu', (e) => { e.preventDefault(); if (panel.w != null || panel.eq) { panel.w = null; panel.eq = null; pnSig = ''; } else closePanel(); });
      const gm = gMax(S, R), g = h('div', { class: 'ct-g' + (R.g >= gm - 1 ? ' hot' : '') }); for (let i = 0; i < gm; i++) g.append(h('i', { class: i < R.g ? 'on' : '' })); g.append(h('span', { text: ' 게이지 ' + R.g + ' / ' + gm }));
      pnEl.append(h('div', { class: 'ct-pnh' }, zoomable(thumb(E, 117, 156), E.no + ' ' + E.n),
        h('div', { style: { flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: '4px' } }, h('div', { class: 'ct-no' }, E.no, h('span', { class: 'ct-tier', style: { color: TIER[E.tier].c }, text: TIER[E.tier].n }), h('span', { text: DTN[E.dt] + ' 피해' })), h('div', { class: 'ct-nm', text: E.n }), g, h('div', { style: { fontSize: '13px' } }, '관찰 수치 ', h('span', { class: 'ct-pt', text: '' + Math.floor(R.pt) }))),
        h('button', { class: 'ct-btn sm', type: 'button', text: '✕', title: '닫기 [Esc]', style: { alignSelf: 'flex-start' }, onclick: closePanel })));
      const tabs = h('div', { class: 'ct-tabs' }); [b ? '제압' : '작업', '기록', '추출'].forEach((n, i) => tabs.append(h('button', { class: panel.tab === i ? 'on' : '', type: 'button', text: n, onclick: () => { panel.tab = i; panel.w = null; panel.eq = null; pnSig = ''; } })));
      const body = h('div', { class: 'ct-pnb' }); pnEl._b = body; pnEl.append(tabs, body);
      if (panel.tab === 0) (b ? tabBreach : tabWork)(body, ri, R, E, b, can, selS);
      else if (panel.tab === 1) body.append(docBody(E, { j: R.un.j, p: R.un.p, r: R.rv, b: R.un.b }, { S, R, ri, can: can, unl: (k, i) => { if (human({ t: 'unl', r: ri, k, i })) { sfx('chip', { vol: 0.5 }); seenPut(S); } } }));
      else tabGear(body, ri, R, E, can);
      mid.append(pnEl); if (sameTab) body.scrollTop = keepScroll;
      try { window.dispatchEvent(new Event('lounge-keys')); } catch (e) {}
    }
    const staffRow = (st, mid_, right, on, fn, dis) => h('button', { class: 'ct-row' + (on ? ' on' : ''), type: 'button', disabled: !!dis, onclick: fn }, face(st, 64), h('div', { class: 'x' }, h('b', { text: st.n + ' ' }), h('span', { style: { color: ROLES[st.role].c }, text: ROLES[st.role].n }), h('div', {}, mid_), bars(st)), right);
    function tabWork(body, ri, R, E, b, can, selS) {
      const one = selS.length ? selS[0] : null, wkS = R.wk >= 0 ? byId(R.wk) : null;
      if (S.ph !== 'day') { body.append(h('p', { class: 'ct-doc', style: { margin: 0, color: '#93a0a6' }, text: '근무 시간에만 작업을 지시할 수 있어요. 기록 열람과 장비 추출은 지금도 돼요.' })); return; }
      if (wkS) body.append(h('div', { class: 'ct-it' }, h('div', { class: 'x', text: '작업 중: ' + wkS.n + ' — ' + WORKS[wkS.a.w].n + ' ' + wkS.a.b.length + ' / ' + NB + '칸' })));
      body.append(h('div', { class: 'ct-sec' }, h('span', { text: one ? one.n + '에게 시킬 작업' : '작업을 고르면 보낼 직원이 나와요' })));
      const grid = h('div', { class: 'ct-wk' });
      WORKS.forEach((W, w) => {
        const kn = prefKnown(R, w), pf = +E.pf[w], v = one ? vioList(S, ri, one, w, true) : [], p = one ? workP(S, ri, one, w, v.length, kn ? null : 1) : 0;
        const bt = h('button', { class: 'ct-wb' + (panel.w === w ? ' on' : ''), type: 'button', style: { '--wc': W.c }, title: W.d, onclick: () => { if (!can) return; if (one) sendWork(ri, w, one); else { panel.w = w; pnSig = ''; } } },
          h('div', { class: 't' }, h('span', { text: W.n }), one ? h('em', { class: kn ? '' : 'q', text: kn ? Math.round(p * 100) + '%' : '?%' }) : h('em', { class: 'q', text: STN[W.st] })),
          h('div', {}, h('span', { class: kn ? 'ct-pf' + pf : 'ct-pfq', text: kn ? PF_N[pf] : '선호 미확인' }), one ? ' · ' + STN[W.st] + ' ' + one.st[W.st] : ''),
          v.length ? h('div', { class: 'ct-v', text: '위반: ' + v.map((i) => RULES[E.rules[i]].n).join(', ') }) : null);
        bt.setAttribute('data-action', 'w' + w); grid.append(bt);
      });
      body.append(grid);
      const unk = E.rules.filter((k, i) => !ruleKnown(R, i)).length;
      if (unk) body.append(h('div', { style: { fontSize: '12.5px', color: '#e8c36a' }, text: '미확인 수칙 ' + unk + '건 — 「기록」에서 관찰 수치로 열람해요.' }));
      if (panel.w != null && !one) {
        const w = panel.w, W = WORKS[w];
        body.append(h('div', { class: 'ct-sec' }, h('span', { text: W.n + ' — 보낼 직원' }), h('button', { class: 'ct-btn sm', type: 'button', text: '← 작업 다시 고르기', onclick: () => { panel.w = null; pnSig = ''; } })));
        const rows = living(S).map((st) => { const kn = prefKnown(R, w), v = avail(st) ? vioList(S, ri, st, w, true) : [], p = workP(S, ri, st, w, v.length, kn ? null : 1); return { st, kn, v, p, ok: avail(st) }; }).sort((a, c) => (c.ok - a.ok) || (a.v.length - c.v.length) || (c.p - a.p));
        rows.forEach((o) => { const st = o.st, lb = stLabel(st); body.append(staffRow(st, [STN[W.st] + ' ' + st.st[W.st] + ' · ' + lb[0], o.v.length ? h('span', { class: 'ct-v', text: ' · 위반' }) : null], h('span', { class: 'p', style: o.v.length ? { color: '#f09a88' } : {}, text: o.kn ? Math.round(o.p * 100) + '%' : '?%' }), false, () => sendWork(ri, w, st), !o.ok || !can)); });
      }
    }
    function tabBreach(body, ri, R, E, b, can, selS) {
      body.append(h('div', { class: 'ct-it', style: { borderColor: '#ee6a55' } }, h('div', { class: 'x' }, h('b', { style: { color: '#f3b0a4' }, text: '탈주 중 — 체력 ' + Math.max(0, b.hp) + ' / ' + b.mx }), h('div', { text: R.un.b ? BK[E.bk].n + ': ' + BK[E.bk].d : '행동 양상 미확인(「기록」에서 열람).' }))));
      if (selS.length) body.append(h('button', { class: 'ct-btn pri', type: 'button', text: '선택한 ' + selS.length + '명 제압 보내기', disabled: !can, onclick: () => { orderSel({ k: 's', r: ri }); } }));
      body.append(h('div', { class: 'ct-sec' }, h('span', { text: '제압조 — 누르면 보내요' })));
      living(S).slice().sort((a, c) => supPower(S, c) * supMult(c, E) - supPower(S, a) * supMult(a, E)).forEach((st) => {
        const on = st.a && st.a.k === 's' && st.a.r === ri, m = supMult(st, E);
        body.append(staffRow(st, ['위력 ' + supPower(S, st) + (m !== 1 && R.un.b ? ' ×' + m : '') + ' · ' + stLabel(st)[0]], h('span', { class: 'p', style: { fontSize: '13px', color: on ? '#f3d588' : '#93a0a6' }, text: on ? '출동' : '보내기' }), on, () => orderOne(st, on ? { k: 'x' } : { k: 's', r: ri }), !avail(st) || !can));
      });
    }
    function tabGear(body, ri, R, E, can) {
      body.append(h('div', { style: { fontSize: '12.5px', color: '#93a0a6' }, text: '이 이형체의 관찰 수치와 비축 에너지를 들여 장비를 추출해요. 이 판 안에서만 남아요. 비축 ' + S.bud + ' · 관찰 ' + Math.floor(R.pt) }));
      ['w', 'a', 'x'].forEach((sl) => {
        const g = R.e + sl, G = GEAR[g]; if (!G) return;
        const made = S.gear[g] || 0, free = gearFree(S, g), hu = E.hu;
        const row = h('div', { class: 'ct-it', style: { alignItems: 'flex-start', flexDirection: 'column', gap: '5px' } },
          h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center', width: '100%' } }, h('i', { style: { width: '14px', height: '14px', borderRadius: sl === 'x' ? '50%' : '3px', background: 'hsl(' + hu + ',55%,66%)', flex: 'none' } }), h('div', { class: 'x' }, h('b', { text: G.n }), ' ', h('span', { style: { color: '#93a0a6' }, text: SLOT_N[sl] + ' · ' + made + ' / ' + G.lim + '점' }))),
          h('div', { style: { color: '#c9d2d4' }, text: gearText(G) }),
          h('div', { style: { display: 'flex', gap: '6px', width: '100%' } },
            h('button', { class: 'ct-btn sm', type: 'button', style: { flex: 1 }, disabled: !can || made >= G.lim || R.pt < G.pt || S.bud < G.cost || !!R.out, text: made >= G.lim ? '수량 한도' : '추출 · 관찰 ' + G.pt + ' · 에너지 ' + G.cost, onclick: () => { if (human({ t: 'ext', g })) { sfx('chip'); seenPut(S); } } }),
            h('button', { class: 'ct-btn sm' + (panel.eq === g ? ' on' : ''), type: 'button', disabled: !can || !made, text: '장착 (남은 ' + free + ')', onclick: () => { panel.eq = panel.eq === g ? null : g; pnSig = ''; } })));
        body.append(row);
        if (panel.eq === g) living(S).forEach((st) => { const k = SLOT_K[sl], on = st[k] === g; body.append(staffRow(st, [st[k] ? '지금: ' + GEAR[st[k]].n : '빈 칸'], h('span', { class: 'p', style: { fontSize: '13px', color: on ? '#f3d588' : '#93a0a6' }, text: on ? '해제' : '장착' }), on, () => { human(on ? { t: 'uneq', s: st.id, slot: sl } : { t: 'equip', g, s: st.id }); }, !can || (!on && free < 1))); });
      });
    }

    /* ---- 창(전체) ---- */
    function closeOv() { if (ov) { ov.remove(); ov = null; ovKind = ''; } }
    function sheet(kind, ...kids) {
      closeOv(); ovKind = kind;
      const sh = h('div', { class: 'ct-sheet' }, ...kids);
      ov = h('div', { class: 'ct-ov', onclick: (e) => { if (e.target === ov && kind === 'x') { closeOv(); renderOv(); } }, oncontextmenu: (e) => { e.preventDefault(); if (kind === 'x') { closeOv(); renderOv(); } } }, sh);
      el.append(ov); return sh;
    }
    const closeBtn = (t) => h('button', { class: 'ct-btn', type: 'button', text: t || '닫기', onclick: () => { closeOv(); renderOv(); } });
    function logSheet() {
      const box = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px', fontSize: '13px' } });
      S.log.slice().reverse().forEach((x) => box.append(h('div', { style: { color: x[2] === 'ok' ? '#8fd0c0' : x[2] === 'bad' ? '#f09a88' : x[2] === 'warn' ? '#e8c36a' : x[2] === 'day' ? '#f0ead8' : '#b8c2c5' }, text: (x[2] === 'day' ? '' : x[0] + '일 ' + x[1] + '차 · ') + x[3] })));
      sheet('x', h('h3', { text: '근무 기록' }), box, closeBtn());
    }
    function staffSheet(id) {
      const st = byId(id); if (!st) return;
      const R_ = ROLES[st.role], por = h('div', { class: 'ct-por', style: { width: '360px', alignSelf: 'flex-start' } }); por.innerHTML = figSVG(st.role, st.dead) + (ART ? '<img alt="" src="' + porSrc(st.fc, st.pn) + '" onerror="this.remove()">' : ''); por.onclick = () => { const im = por.querySelector('img'); if (im) zoom(im.src, st.n + ' · ' + R_.n); };
      const dl = h('dl', { class: 'ct-kv' }), kv = (k, v) => dl.append(h('dt', { text: k }), h('dd', {}, v));
      kv('직책', R_.n + ' (주 능력치 ' + STN[st.role] + ')');
      kv('상태', stLabel(st)[0]);
      kv('체력 · 정신', Math.ceil(st.hp) + ' / ' + hpMax(st) + ' · ' + Math.ceil(st.sp) + ' / ' + spMax(st));
      STN.forEach((n, k) => kv(n, st.st[k] + (st.st[k] < 5 ? '  (경험 ' + st.xp[k] + ' / ' + Math.max(1, 2 * st.st[k] - upLv(S, 'gym')) + ')' : '  (최대)') + ' — ' + STD[k]));
      kv('특성', TRAITS[st.tr].n + ' — ' + TRAITS[st.tr].d);
      kv('제압 위력', '' + supPower(S, st));
      const gearBox = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
      ['w', 'a', 'x'].forEach((sl) => {
        const k = SLOT_K[sl], cur = st[k], opts = Object.keys(S.gear).filter((g) => GEAR[g].slot === sl && gearFree(S, g) > 0 && g !== cur);
        const row = h('div', { class: 'ct-it', style: { flexWrap: 'wrap' } }, h('div', { class: 'x' }, h('b', { text: SLOT_N[sl] + ': ' + (cur ? GEAR[cur].n : '없음') }), cur ? h('div', { text: gearText(GEAR[cur]) + ' (' + ENT[GEAR[cur].ei].no + ')' }) : null),
          cur && mine() && !st.dead ? h('button', { class: 'ct-btn sm', type: 'button', text: '해제', onclick: () => { human({ t: 'uneq', s: st.id, slot: sl }); staffSheet(id); } }) : null);
        gearBox.append(row);
        if (mine() && !st.dead) opts.forEach((g) => gearBox.append(h('button', { class: 'ct-row', type: 'button', style: { minHeight: '40px', marginLeft: '14px', width: 'calc(100% - 14px)' }, onclick: () => { human({ t: 'equip', g, s: st.id }); staffSheet(id); } }, h('i', { style: { width: '12px', height: '12px', borderRadius: '3px', background: 'hsl(' + ENT[GEAR[g].ei].hu + ',55%,66%)', flex: 'none' } }), h('div', { class: 'x' }, h('b', { text: '장착: ' + GEAR[g].n }), h('div', { text: gearText(GEAR[g]) + ' · 남은 ' + gearFree(S, g) })))));
      });
      sheet('x', h('div', { style: { display: 'flex', gap: '16px' } }, por, h('div', { style: { flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: '10px' } }, h('h3', { text: st.n + (st.dead ? ' (사망)' : st.pn ? ' (공황)' : '') }), dl, h('div', { class: 'ct-sec' }, h('span', { text: '장비 — 이형체에서 추출한 것' })), gearBox, closeBtn())));
    }
    function pickView() {
      const grid = h('div', { class: 'ct-cands' });
      S.cand.forEach((ei, i) => {
        const E = ENT[ei], pw = E.pf.indexOf('2'), th = h('div', { class: 'ct-th', style: { '--hu': E.hu } }); th.innerHTML = thumbHTML(E); zoomable(th, E.no + ' ' + E.n);
        grid.append(h('div', { class: 'ct-cand' }, th,
          h('div', { class: 'ct-no' }, E.no, h('span', { class: 'ct-tier', style: { color: TIER[E.tier].c }, text: TIER[E.tier].n }), h('span', { text: E.esc ? '탈주형' : '이변형' })),
          h('div', { class: 'ct-nm', text: E.n }), h('div', { style: { minHeight: '40px' }, text: E.look }),
          h('div', { text: '에너지 최대 ' + E_OUT[E.tier] + ' · ' + DTN[E.dt] + ' 피해 · 게이지 한계 ' + E.gm + ' · 수칙 ' + E.rules.length + '건' }),
          h('div', { style: { color: '#8fd0c0' }, text: '사전 정보: 선호 작업 — ' + WORKS[pw].n }),
          h('button', { class: 'ct-btn pri', type: 'button', disabled: !mine(), text: '인수', onclick: () => { if (human({ t: 'pick', i })) sfx('chip'); } })));
      });
      closeOv(); ovKind = 'pick';
      ov = h('div', { class: 'ct-ov' + (ART ? ' art' : '') }, h('div', { class: 'ct-sheet', style: { width: 'min(980px,100%)' } }, h('h3', { text: S.day + '일째 — 새 이형체 인수' }), h('p', { class: 'm', text: '셋 중 하나를 골라 빈 격리실에 들여요. 등급이 높을수록 에너지도 피해도 커요. 나머지 정보는 작업으로 관찰 수치를 모아 열람해요.' }), grid));
      el.append(ov);
    }
    function nightView() {
      const tabsN = ['채용', '시설 강화', '이형체 · 추출', '직원 · 장비'], can = mine();
      const left = h('div', { class: 'ct-col' }, h('h3', { style: { margin: 0, font: '400 20px var(--f-display,sans-serif)', color: '#f0ead8' }, text: S.day + '일째 마감 정산' }));
      (S.sum || []).forEach((t, i) => left.append(h('p', { style: { margin: 0, fontSize: '13.5px', color: i === 0 ? '#f3d588' : '#c4cdd0' }, text: t })));
      const tb = h('div', { class: 'ct-scroll' });
      S.rooms.forEach((R) => { if (R.e == null) return; const E = ENT[R.e]; tb.append(h('div', { class: 'ct-it', style: { minHeight: '34px' } }, h('div', { class: 'x', text: E.no + ' ' + E.n }), h('span', { style: { color: '#8fd0c0' }, text: '에너지 ' + Math.round(R.de) }), h('span', { style: { color: '#93a0a6', fontSize: '12px' }, text: R.wc[2] + ' · ' + R.wc[1] + ' · ' + R.wc[0] }))); });
      left.append(h('div', { class: 'ct-sec' }, h('span', { text: '이형체별 생산 (좋음 · 보통 · 나쁨)' })), tb, h('div', { class: 'ct-chip', style: { justifyContent: 'center' } }, '비축 에너지 ', h('b', { text: '' + S.bud })),
        (() => { const b = h('button', { class: 'ct-btn pri', type: 'button', style: { minHeight: '46px', fontSize: '15px' }, disabled: !can, text: (S.day + 1) + '일째 시작', onclick: () => { if (human({ t: 'next' })) sfx('go'); } }); b.setAttribute('data-action', 'end'); return b; })());
      const right = h('div', { class: 'ct-col' }), tabs = h('div', { class: 'ct-tabs', style: { padding: 0 } });
      tabsN.forEach((n, i) => tabs.append(h('button', { class: ntab === i ? 'on' : '', type: 'button', text: n, onclick: () => { ntab = i; renderOv(); } })));
      const list = h('div', { class: 'ct-scroll' }); right.append(tabs, list);
      if (ntab === 0) {
        list.append(h('p', { class: 'ct-doc', style: { margin: 0, fontSize: '13px', color: '#93a0a6' }, text: '직원 ' + living(S).length + ' / ' + staffCap(S) + '명. 채용한 직원은 내일부터 일해요.' }));
        if (!S.hire.length) list.append(h('div', { class: 'ct-it lock' }, h('div', { class: 'x', text: '오늘은 지원자가 없어요.' })));
        S.hire.forEach((c, i) => {
          const cost = hireCost(S, c), fake = { role: c.role, fc: c.fc, dead: 0, pn: 0 }, f = face(fake, 112); f.style.cursor = 'zoom-in'; f.onclick = () => zoom(porSrc(c.fc), FACE_N(c.fc) + ' · ' + ROLES[c.role].n);
          list.append(h('div', { class: 'ct-row', style: { minHeight: '84px' } }, f, h('div', { class: 'x' }, h('b', { text: FACE_N(c.fc) + ' ' }), h('span', { style: { color: ROLES[c.role].c }, text: ROLES[c.role].n }), h('div', { text: STN.map((n, k) => n + ' ' + c.st[k]).join(' · ') }), h('div', { text: TRAITS[c.tr].n + ' — ' + TRAITS[c.tr].d })),
            h('button', { class: 'ct-btn', type: 'button', disabled: !can || S.bud < cost || living(S).length >= staffCap(S), text: '채용 · ' + cost, onclick: () => { if (human({ t: 'hire', i })) { sfx('chip'); renderOv(); } } })));
        });
      } else if (ntab === 1) {
        const g = h('div', { class: 'ct-grid2' });
        UPS.forEach((u) => { const lv = upLv(S, u.id), cost = upCost(S, u); g.append(h('div', { class: 'ct-row' }, h('div', { class: 'x' }, h('b', { text: u.n + ' ' + lv + ' / ' + u.mx }), h('div', { text: u.d })), h('button', { class: 'ct-btn sm', type: 'button', disabled: !can || lv >= u.mx || S.bud < cost, text: lv >= u.mx ? '완료' : '강화 · ' + cost, onclick: () => { if (human({ t: 'up', id: u.id })) { sfx('chip'); renderOv(); } } }))); });
        list.append(g);
      } else if (ntab === 2) {
        list.append(h('p', { class: 'ct-doc', style: { margin: 0, fontSize: '13px', color: '#93a0a6' }, text: '이형체를 누르면 기록 열람 · 장비 추출 창이 열려요.' }));
        const g = h('div', { class: 'ct-grid2' });
        S.rooms.forEach((R, ri) => { if (R.e == null) return; const E = ENT[R.e], lock = E.rules.filter((k, i) => !R.rv[i]).length + R.un.p.filter((x) => !x).length; g.append(h('button', { class: 'ct-row', type: 'button', onclick: () => { openRoom(ri, 1, true); } }, thumb(E, 72, 96), h('div', { class: 'x' }, h('b', { text: E.no + ' ' + E.n }), h('div', {}, '관찰 수치 ', h('span', { class: 'ct-pt', text: '' + Math.floor(R.pt) }), ' · 미열람 ' + lock + '건 · 게이지 ' + R.g + '/' + gMax(S, R))))); });
        list.append(g);
      } else {
        const g = h('div', { class: 'ct-grid2' });
        S.staff.forEach((st) => { if (st.dead) return; g.append(staffRow(st, [STN.map((n, k) => n[0] + st.st[k]).join(' ') + ' · ' + TRAITS[st.tr].n, h('div', { text: ['wp', 'ar', 'ac'].map((k) => (st[k] ? GEAR[st[k]].n : '—')).join(' / ') })], h('span', { class: 'p', style: { fontSize: '12px', color: '#93a0a6' }, text: '상세' }), false, () => staffSheet(st.id))); });
        list.append(g);
      }
      closeOv(); ovKind = 'night';
      ov = h('div', { class: 'ct-ov' + (ART ? ' art' : '') }, h('div', { class: 'ct-night' }, left, right)); el.append(ov);
      try { window.dispatchEvent(new Event('lounge-keys')); } catch (e) {}
    }
    function renderOv() {
      if (!S) return;
      if (S.over) { closeOv(); closePanel(); return; }
      if (S.ph === 'pick') pickView(); else if (S.ph === 'night') nightView(); else if (ovKind !== 'x') closeOv();
    }

    /* ---- 마우스 ---- */
    const local = (e) => { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
    function hit(px, py) {
      const wx = wx_(px), wy = wy_(py);
      for (const b of S.br) { const p = posOf(b, 'b' + b.r), cy = feetY(p.f) - 26; if (Math.hypot(wx - p.x, wy - cy) <= 26) return { k: 'breach', r: b.r }; }
      for (const st of S.staff) {
        if (st.dead) continue; const p = posOf(st);
        const X = p.in ? roomX(st.a.r) - RW / 2 + 24 : p.x, Y = p.in ? roomF(st.a.r) * FH + 10 + RH - 18 : feetY(p.f);
        if (Math.abs(wx - X) <= 15 && wy <= Y + 4 && wy >= Y - 56) return { k: 'staff', id: st.id };
      }
      const f = Math.floor(wy / FH); if (f < 0 || f >= S.fo) return null;
      const ly = wy - f * FH;
      if (ly >= 10 && ly <= 10 + RH) { for (let k = 0; k < PER; k++) { const ri = f * PER + k, x0 = roomX(ri) - RW / 2; if (wx >= x0 && wx <= x0 + RW) return { k: 'room', r: ri }; } if (f === 0 && wx >= LX0 && wx <= LX1 + 6 && ly >= 44) return { k: 'lounge' }; }
      if (ly > 10 + RH && ly <= 10 + RH + CH) { if (f === 0 && wx < 0) return { k: 'lounge' }; if (wx >= 0 && wx <= FW) return { k: 'floor', f, x: wx }; }
      return null;
    }
    function onDown(e) {
      if (!S || ov) return; const p = local(e);
      drag = { b: e.button, x0: p.x, y0: p.y, x: p.x, y: p.y, cx: cam.x, cy: cam.y, moved: false, box: false };
      try { cv.setPointerCapture(e.pointerId); } catch (x) {}
      if (e.button === 1) e.preventDefault();
    }
    function onMove(e) {
      if (!S) return; const p = local(e);
      if (!drag) { const hv = ov ? null : hit(p.x, p.y); hover = hv; cv.style.cursor = hv && (hv.k === 'room' || hv.k === 'staff' || hv.k === 'breach') ? 'pointer' : 'default'; return; }
      drag.x = p.x; drag.y = p.y;
      if (!drag.moved && Math.hypot(p.x - drag.x0, p.y - drag.y0) > 6) { drag.moved = true; if (drag.b === 0 && mine() && S.ph === 'day') drag.box = true; }
      if (drag.moved && !drag.box) { cam.x = drag.cx - (p.x - drag.x0) / cam.z; cam.y = drag.cy - (p.y - drag.y0) / cam.z; cam.tx = cam.ty = null; cam.user = true; clampCam(); cv.style.cursor = 'grabbing'; }
    }
    function onUp(e) {
      if (!drag || !S) return; const d = drag; drag = null; cv.style.cursor = 'default';
      if (d.box) {
        const x0 = wx_(Math.min(d.x0, d.x)), x1 = wx_(Math.max(d.x0, d.x)), y0 = wy_(Math.min(d.y0, d.y)), y1 = wy_(Math.max(d.y0, d.y));
        const got = S.staff.filter((st) => { if (!avail(st)) return false; const p = posOf(st), X = p.in ? roomX(st.a.r) - RW / 2 + 24 : p.x, Y = (p.in ? roomF(st.a.r) * FH + 10 + RH - 18 : feetY(p.f)) - 26; return X >= x0 && X <= x1 && Y >= y0 - 26 && Y <= y1 + 26; }).map((st) => st.id);
        sel = e.shiftKey ? sel.concat(got.filter((id) => !sel.includes(id))) : got; stripSig = ''; pnSig = ''; if (got.length) sfx('click', { vol: 0.5 });
        return;
      }
      if (d.moved) return;
      const hv = hit(d.x, d.y);
      if (d.b === 0) {
        if (!hv || hv.k === 'floor' || hv.k === 'lounge') { if (sel.length || panel) { sel = []; closePanel(); stripSig = ''; } return; }
        if (hv.k === 'staff') { pickStaff(hv.id, e.shiftKey || e.ctrlKey); return; }
        if (hv.k === 'room' && S.rooms[hv.r].e != null) { openRoom(hv.r, 0); return; }
        if (hv.k === 'breach') { openRoom(hv.r, 0); return; }
      } else if (d.b === 2) {
        const list = sel.map(byId).filter((s) => s && avail(s));
        if (!mine() || S.ph !== 'day' || !list.length || !hv) { if (panel) closePanel(); else if (sel.length) { sel = []; stripSig = ''; } return; }
        if (hv.k === 'breach' || (hv.k === 'room' && S.rooms[hv.r].out)) { if (orderSel({ k: 's', r: hv.r })) fl.push({ f: roomF(hv.r), x: wx_(d.x), dy: -40, t: 0, txt: '제압', c: '#f3d588' }); }
        else if (hv.k === 'room') { if (S.rooms[hv.r].e != null) { openRoom(hv.r, 0); } }
        else if (hv.k === 'staff') { const t = byId(hv.id); if (t.pn) { const s0 = list.find((o) => o.id !== t.id); if (s0) orderOne(s0, { k: 'c', c: t.id }); } }
        else if (hv.k === 'lounge') orderSel({ k: 'r' });
        else if (hv.k === 'floor') { if (orderSel({ k: 'm', f: hv.f, x: hv.x })) fl.push({ f: hv.f, x: hv.x, dy: -8, t: 0.7, txt: '▾', c: '#e3ae45' }); }
      }
    }
    function onWheel(e) {
      if (!S || ov) return; e.preventDefault();
      const p = local(e), wx = wx_(p.x), wy = wy_(p.y), z = clamp(cam.z * (e.deltaY < 0 ? 1.12 : 1 / 1.12), Math.min(0.5, cam.fit), 2.6);
      cam.z = z; cam.x = wx - (p.x - cam.w / 2) / z; cam.y = wy - (p.y - cam.h / 2) / z; cam.tx = cam.ty = null; cam.user = true; clampCam();
    }
    function onDbl(e) { if (!S || ov) return; const p = local(e), hv = hit(p.x, p.y); if (hv && hv.k === 'staff') staffSheet(hv.id); }
    cv.addEventListener('pointerdown', onDown); cv.addEventListener('pointermove', onMove); cv.addEventListener('pointerup', onUp); cv.addEventListener('pointercancel', () => { drag = null; });
    cv.addEventListener('wheel', onWheel, { passive: false }); cv.addEventListener('dblclick', onDbl); cv.addEventListener('contextmenu', (e) => e.preventDefault());
    cv.addEventListener('auxclick', (e) => e.preventDefault());

    /* ---- 키보드 ---- */
    const offIn = api.input.on((type, id) => {
      if (type !== 'down' || !S || S.over) return;
      if (id === 'log') { if (ovKind === 'x') { closeOv(); renderOv(); } else if (!ov || S.ph !== 'day') logSheet(); return; }
      if (S.ph === 'night') { if (id === 'end' && mine() && ovKind === 'night') { if (human({ t: 'next' })) sfx('go'); } return; }
      if (S.ph !== 'day' || !mine() || ov) return;
      if (id === 'pause') togglePause(); else if (id === 'sp1') setSpeed(1); else if (id === 'sp2') setSpeed(2); else if (id === 'sp3') setSpeed(3);
      else if (id === 'next' || id === 'prev') { const a = S.staff.filter(avail); if (!a.length) return; const i = a.findIndex((s) => s.id === sel[0]); const n = a[(i + (id === 'next' ? 1 : a.length - 1) + a.length) % a.length]; sel = [n.id]; const p = posOf(n); focus(p.f, p.x); stripSig = ''; pnSig = ''; }
      else if (id === 'all') { sel = S.staff.filter(avail).map((s) => s.id); stripSig = ''; pnSig = ''; }
      else if (id === 'rest') { if (orderSel({ k: 'r' })) sfx('pop', { vol: 0.5 }); } else if (id === 'stop') orderSel({ k: 'x' });
      else if (id === 'auto') { if (human({ t: 'auto' })) sfx('click'); } else if (id === 'end') endDayAsk();
      else if (/^w[0-3]$/.test(id)) { if (panel && panel.tab === 0 && !brOf(S, panel.r)) sendWork(panel.r, +id[1]); }
      else if (id === 'home') { cam.user = false; fitCam(); }
    });
    function onKey(e) {
      if (!S || e.defaultPrevented) return;
      if (doc.querySelector('.overlay[data-core]:not(.result)')) return;
      if (e.code === 'Escape') {
        if (ovKind === 'x') { closeOv(); renderOv(); } else if (panel) { if (panel.w != null || panel.eq) { panel.w = null; panel.eq = null; pnSig = ''; } else closePanel(); } else if (sel.length) { sel = []; stripSig = ''; } else return;
        e.preventDefault();
      } else if (/^Digit[1-9]$/.test(e.code) && (e.altKey || e.ctrlKey) && S.ph === 'day') { const st = S.staff[+e.code.slice(5) - 1]; if (st && !st.dead) { pickStaff(st.id, false, true); e.preventDefault(); } }
    }
    window.addEventListener('keydown', onKey, true);
    const holdOn = (e) => { if (e.target !== cv) uiHeld = true; }, holdOff = () => { setTimeout(() => { uiHeld = false; }, 0); };
    el.addEventListener('click', () => { const a = doc.activeElement; if (a && a.tagName === 'BUTTON' && el.contains(a)) a.blur(); });
    el.addEventListener('pointerdown', holdOn, true); window.addEventListener('pointerup', holdOff, true); window.addEventListener('pointercancel', holdOff, true);
    const ro = new ResizeObserver(resize); ro.observe(mid); window.addEventListener('resize', resize);
    function showTip() {
      if (tipEl || !mine()) return;
      let seen = false; try { seen = !!localStorage.getItem('lounge.containment.tip2'); } catch (e) {}
      if (seen || (L.debug && L.debug.noTut)) return;
      tipEl = h('div', { class: 'ct-tip', onclick: () => { tipEl.remove(); tipEl = null; try { localStorage.setItem('lounge.containment.tip2', '1'); } catch (e) {} } },
        h('b', { style: { color: '#f3d588' }, text: '처음이라면' }), h('br'), '① 격리실을 누르고 → 작업을 고르고 → 보낼 직원을 눌러요. 직원을 먼저 고르고 격리실을 오른쪽 누르기 해도 돼요.', h('br'), '② ' + (kbd('pause') || 'Space') + '로 시간을 멈추거나 흘려요. 멈춘 동안에도 지시할 수 있어요.', h('br'), '③ 작업으로 모은 관찰 수치로 「기록」에서 선호와 수칙을 열람하고, 「추출」에서 장비를 만들어요.', h('br'), h('span', { style: { color: '#93a0a6' }, text: '눌러서 닫기 · F1 규칙' }));
      mid.append(tipEl);
    }
    raf = requestAnimationFrame(frame);
    if (L.debug) window.__ct = { roomXY: (ri) => [sx(roomX(ri)), sy(roomF(ri) * FH + 10 + RH / 2)], xy: (f, x) => [sx(x), sy(feetY(f) - 20)], cam, sel: () => sel, paused: () => paused, drag: () => drag };

    return {
      update(state) {
        if (state && state.v !== 3) { try { api.toast('저장한 판이 옛 방식이라 새 판으로 시작해요'); } catch (e) {} const fresh = init(api.players, { len: state.len }); setTimeout(() => { try { api.setState(fresh); } catch (e) {} }, 0); return; }
        const first = !S; S = state; setLay(S);
        if (first) { lastEv = S.last ? S.last.id : -1; lastPh = S.ph; paused = !isAI(); dayIntro = 1; resize(); fitCam(); renderOv(); seenPut(S); showTip(); }
        else if (S.ph !== lastPh) { lastPh = S.ph; renderOv(); }
        if (S.over) { closeOv(); closePanel(); }
        topSig = ''; stripSig = ''; pnSig = '';
      },
      saveState() { return S && !S.over ? { v: 3 } : false; },
      loadState() {},
      destroy() { dead = true; cancelAnimationFrame(raf); window.removeEventListener('keydown', onKey, true); window.removeEventListener('pointerup', holdOff, true); window.removeEventListener('pointercancel', holdOff, true); window.removeEventListener('resize', resize); ro.disconnect(); if (offIn) offIn(); styleEl.remove(); el.remove(); },
    };
  }
})();
(function () {  // 배포용 줄 → 조각:줄 (tools/parts_join.js가 만든 표)
  const P = window.CONTAINMENT_PARTS || (window.CONTAINMENT_PARTS = {}), M = [[1,"containment",0],[3,"base",2],[146,"rules",2],[215,"gauge",2],[241,"staff",2],[264,"upgrades",2],[279,"events",2],[301,"ab_01",2],[318,"ab_02",2],[335,"ab_03",2],[352,"ab_04",2],[369,"ab_05",2],[386,"ab_06",2],[403,"ab_07",2],[420,"ab_08",2],[437,"ab_09",2],[454,"ab_10",2],[471,"ab_11",2],[488,"ab_12",2],[505,"ab_13",2],[523,"ab_14",2],[541,"ab_15",2],[559,"ab_16",2],[577,"ab_17",2],[595,"ab_18",2],[613,"ab_19",2],[631,"ab_20",2],[649,"ab_21",2],[666,"ab_22",2],[683,"ab_23",2],[700,"ab_24",2],[717,"ab_25",2],[734,"ab_26",2],[751,"ab_27",2],[768,"ab_28",2],[785,"ab_29",2],[802,"ab_30",2],[819,"ab_31",2],[836,"ab_32",2],[853,"ab_33",2],[871,"ab_34",2],[889,"ab_35",2],[907,"ab_36",2],[925,"ab_37",2],[943,"ab_38",2],[961,"ab_39",2],[979,"ab_40",2],[997,"ab_41",2],[1021,"ab_42",2],[1045,"sim",2],[1554,"ai",2],[1674,"view_top",2],[1812,"codex",2],[1891,"def",2],[1935,"view_main",2],[2031,"view_draw",2],[2221,"view_hud",2],[2310,"view_panel",2],[2383,"view_sheets",2],[2475,"view_input",2]], N = 2592;
  P.where = function (x) {
    const one = (ln) => { ln = +ln; let m = null; for (const e of M) if (e[0] <= ln) m = e; return m && m[1] !== 'containment' && ln < N ? m[1] + '.js:' + (ln - m[0] + m[2]) : 'containment.js'; };
    return typeof x === 'number' ? one(x) : String(x).replace(/containment-joined\.js:(\d+)/g, (_, ln) => 'containment/' + one(ln));
  };
})();
//# sourceURL=games/containment-joined.js
