/* 님 타입 제로 (nimzero) — 0·1·2·3 카드를 번갈아 내어 합계를 쌓는 심리전. 합계가 9를 넘게 만든 사람이 진다.
   한 벌 40장(0~3 각 10장), 각자 4장. 손패가 다 떨어지면 합계는 그대로 두고 남은 더미에서 다시 4장씩.
   판돈: 한 판 1에서 시작, 손패를 다시 받을 때마다 +1, 카드를 내며 「올림」을 걸면 +1(한 판에 한 사람 한 번).
   넘긴 사람이 판돈만큼 칩을 잃고, 칩이 다 떨어지면 탈락. 마지막까지 칩이 남은 사람이 승리.
   상태는 JSON. 숨김 정보는 손패(h)와 더미 순서(deck)뿐 — 나온 카드 수(seen)는 공개 정보다. */
(function () {
  const L = window.Lounge;
  const ID = 'nimzero';
  const LIMIT = 9, HAND = 4, EACH = 10;

  /* ---------- 작은 도우미 ---------- */
  function hash() {   // 결정적 0~1 (판 시드 버릇)
    let h = 2166136261 >>> 0;
    for (let i = 0; i < arguments.length; i++) {
      let x = (arguments[i] | 0) >>> 0;
      for (let j = 0; j < 4; j++) { h ^= x & 255; h = Math.imul(h, 16777619) >>> 0; x >>>= 8; }
    }
    h ^= h >>> 13; h = Math.imul(h, 0x5bd1e995) >>> 0; h ^= h >>> 15;
    return (h >>> 0) / 4294967296;
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function freshDeck() { const d = []; for (let v = 0; v < 4; v++) for (let i = 0; i < EACH; i++) d.push(v); return shuffle(d); }
  const aliveOf = (s) => { const a = []; for (let i = 0; i < s.n; i++) if (s.scores[i] > 0) a.push(i); return a; };
  function nextAlive(s, seat) { for (let k = 1; k <= s.n; k++) { const j = (seat + k) % s.n; if (s.scores[j] > 0) return j; } return seat; }
  const countsOf = (hand) => { const c = [0, 0, 0, 0]; for (const v of hand) c[v]++; return c; };

  /* ---------- 시작 · 나누기 ---------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const chips = clamp(+opts.chips || 8, 1, 20) | 0;
    const s = {
      v: 1, n, c0: chips, up: opts.raise === 'off' ? 0 : 1,
      sd: (Math.random() * 1e9) | 0, eid: 0,
      scores: Array(n).fill(chips),          // 칩(core 정보판이 자동으로 보여 준다)
      deck: [], seen: [0, 0, 0, 0], h: Array.from({ length: n }, () => []),
      rd: 0, dl: 0, tot: 0, stake: 1, turn: 0, pile: [], rs: Array(n).fill(0),
      out: [], ph: 'play', win: -1, last: null, lg: [],
      st: { b: Array(n).fill(0), u: Array(n).fill(0), z: Array(n).fill(0), mx: Array(n).fill(0) },
      nm: players.map((p, i) => String((p && p.name) || ('자리 ' + (i + 1))).slice(0, 14)),
    };
    newRound(s, 0);
    return s;
  }
  /* 살아 있는 자리마다 4장. 더미가 모자라면 40장을 모두 모아 새로 섞는다 → 섞었으면 1 */
  function deal(s) {
    const al = aliveOf(s);
    let shuf = 0;
    if (s.deck.length < al.length * HAND) { s.deck = freshDeck(); s.seen = [0, 0, 0, 0]; shuf = 1; }
    for (let i = 0; i < s.n; i++) s.h[i] = [];
    for (const i of al) s.h[i] = s.deck.splice(s.deck.length - HAND, HAND).sort((a, b) => a - b);
    return shuf;
  }
  function newRound(s, first) {
    s.rd++; s.dl = 1; s.tot = 0; s.stake = 1; s.pile = []; s.rs = Array(s.n).fill(0);
    const shuf = deal(s);
    s.turn = first;
    return shuf;
  }

  /* ---------- 차례 · 행동 ---------- */
  function actor(s) { return s.ph === 'over' ? null : s.turn; }

  function apply(s, seat, a) {
    if (!a || typeof a !== 'object' || a.t !== 'play') throw new Error('bad action');
    if (s.ph === 'over' || s.turn !== seat) throw new Error('not your turn');
    const c = a.c | 0;
    const hand = s.h[seat];
    const ix = hand.indexOf(c);
    if (ix < 0) throw new Error('card not in hand');
    const bust = s.tot + c > LIMIT;
    let up = 0;
    if (a.up && s.up && !s.rs[seat] && !bust) { up = 1; s.rs[seat] = 1; s.stake++; s.st.u[seat]++; }
    hand.splice(ix, 1);
    s.seen[c]++;
    if (c === 0) s.st.z[seat]++;
    const t0 = s.tot;
    s.tot += c;
    s.pile.push([seat, c]);
    s.eid++;
    const last = { id: s.eid, s: seat, c, t0, t1: s.tot, up, stake: s.stake, rd: s.rd, hc: s.h.map((x) => x.length), seen: s.seen.slice(), dk: s.deck.length, rs: s.rs.slice() };
    if (bust) {
      const pay = Math.min(s.stake, s.scores[seat]);
      last.b = { l: seat, pay, h: s.h.map((x) => x.slice()), ch0: s.scores.slice(), pile: s.pile.slice(), el: 0 };
      s.scores[seat] -= pay;
      s.st.b[seat]++; s.st.mx[seat] = Math.max(s.st.mx[seat], pay);
      s.lg.push([s.rd, seat, pay, s.tot]); if (s.lg.length > 12) s.lg.shift();
      // 남은 손패는 공개하고 버린다(나온 카드로 센다)
      for (let i = 0; i < s.n; i++) { for (const v of s.h[i]) s.seen[v]++; s.h[i] = []; }
      if (s.scores[seat] <= 0) { s.out.push(seat); last.b.el = 1; }
      const al = aliveOf(s);
      if (al.length <= 1) { s.ph = 'over'; s.win = al.length ? al[0] : seat; s.turn = -1; s.last = last; return s; }
      const first = s.scores[seat] > 0 ? seat : nextAlive(s, seat);
      const shuf = newRound(s, first);
      last.d = { re: 0, shuf, first, rd: s.rd };
    } else if (s.h.every((x) => x.length === 0)) {
      // 손패 소진: 합계는 그대로, 다시 4장씩. 판돈 +1
      s.dl++; s.stake++;
      const shuf = deal(s);
      s.turn = nextAlive(s, seat);
      last.d = { re: 1, shuf, first: s.turn, rd: s.rd, stake: s.stake };
    } else {
      s.turn = nextAlive(s, seat);
    }
    s.last = last;
    return s;
  }

  /* ---------- 결과 ---------- */
  function result(s) {
    if (s.ph !== 'over' || s.win < 0) return null;
    const nmOf = (i) => (s.nm && s.nm[i]) || ('자리 ' + (i + 1));
    const stats = [
      { label: '남은 칩', values: s.scores.slice() },
      { label: '넘긴 판', values: s.st.b.slice(), low: true },
      { label: '낸 0 카드', values: s.st.z.slice(), best: false },
    ];
    if (s.up) stats.push({ label: '판돈 올림', values: s.st.u.slice(), best: false });
    stats.push({ label: '한 판 최대 손실', values: s.st.mx.slice(), unit: '칩', best: false });
    const hl = [];
    if (s.n > 2 && s.out.length) hl.push('탈락 순서: ' + s.out.map(nmOf).join(' → '));
    const big = Math.max.apply(null, s.st.mx), bi = s.st.mx.indexOf(big);
    if (big >= 3) hl.push('가장 큰 한 판: ' + nmOf(bi) + ' −' + big + '칩');
    return {
      winners: [s.win],
      title: nmOf(s.win) + ' 승리',
      text: s.rd + '판 · 남은 칩 ' + s.scores[s.win],
      stats, highlights: hl,
    };
  }

  /* ======================= AI ======================= */
  /* 이 자리에서 아직 못 본 카드(남의 손 + 더미) 종류별 수 */
  function unseenOf(s, seat) {
    const u = [0, 0, 0, 0];
    for (let v = 0; v < 4; v++) u[v] = EACH - s.seen[v];
    for (const c of s.h[seat]) u[c]--;
    return u;
  }
  /* N장 중 쓸 수 있는 카드가 g장일 때, k장 손에 쓸 카드가 한 장도 없을 확률 */
  function pNone(N, g, k) {
    if (k <= 0) return 0;
    let p = 1;
    for (let i = 0; i < k; i++) { const d = N - i; if (d <= 0) break; p *= Math.max(0, N - g - i) / d; }
    return p;
  }
  function habits(s, seat) {
    return {
      push: hash(s.sd, seat, 21),    // 합계를 밀어 올리는 버릇
      hoard: hash(s.sd, seat, 22),   // 0을 끝까지 쥐는 버릇
      bold: hash(s.sd, seat, 23),    // 판돈을 쉽게 올리는 버릇
      bluff: hash(s.sd, seat, 24),   // 근거 없이 올리는 버릇
    };
  }
  const styleOf = (seat) => { try { return (L.aiStyle && L.aiStyle(seat)) || 'bal'; } catch (e) { return 'bal'; } };

  /* 어려움: 못 본 카드를 상대 손에 여러 번 나눠 보고(올린 자리는 0을 더 쥐었다고 봄),
     그때마다 이번 손패가 끝날 때까지 서로 최선으로 두는 수를 따져 「내가 넘길 확률」을 카드별로 구한다 */
  function think(s, seat, samples) {
    const order = [seat];
    for (let j = nextAlive(s, seat); j !== seat; j = nextAlive(s, j)) order.push(j);
    const k = order.length;
    const u = unseenOf(s, seat);
    const pool = [];
    for (let v = 0; v < 4; v++) for (let i = 0; i < u[v]; i++) pool.push(v);
    const mine = countsOf(s.h[seat]);
    const cands = [0, 1, 2, 3].filter((v) => mine[v] > 0);
    const acc = [0, 0, 0, 0];
    let W = 0;
    const sizes = order.map((o) => s.h[o].length);
    const need = sizes.reduce((a, b) => a + b, 0) - sizes[0];
    const hs = order.map(() => [0, 0, 0, 0]);
    let deckC = [0, 0, 0, 0], deckN = 0, memo = null;
    const evenLeaf = Array(k).fill(1 / k);

    function leaf(tot, ti) {
      // 손패를 다시 받은 직후: 차례인 사람부터 「낼 카드가 없을」 확률을 차례로 매긴다
      const slack = LIMIT - tot;
      if (slack >= 3) return evenLeaf;
      let g = 0, N = deckN;
      if (N < k * HAND) { N = 40; g = (slack + 1) * EACH; } else for (let v = 0; v <= slack; v++) g += deckC[v];
      const stuck = pNone(N, g, HAND);
      const vec = Array(k).fill(0);
      let live = 1;
      for (let i = 0; i < k; i++) { const m = (ti + i) % k; vec[m] = live * stuck; live *= 1 - stuck; }
      for (let i = 0; i < k; i++) vec[i] += live / k;
      return vec;
    }
    function solve(tot, ti) {
      const h = hs[ti];
      if (h[0] + h[1] + h[2] + h[3] === 0) return leaf(tot, ti);
      let key = tot * 4 + ti;
      for (let i = 0; i < k; i++) { const x = hs[i]; key = key * 625 + x[0] + 5 * x[1] + 25 * x[2] + 125 * x[3]; }
      const got = memo.get(key);
      if (got) return got;
      let best = 2, sum = null, cnt = 0;
      const nt = (ti + 1) % k;
      for (let v = 0; v < 4; v++) {
        if (!h[v]) continue;
        let vec;
        if (tot + v > LIMIT) { vec = Array(k).fill(0); vec[ti] = 1; }
        else { h[v]--; vec = solve(tot + v, nt); h[v]++; }
        const mv = vec[ti];
        if (mv < best - 1e-9) { best = mv; sum = vec.slice(); cnt = 1; }
        else if (mv < best + 1e-9) { for (let i = 0; i < k; i++) sum[i] += vec[i]; cnt++; }
      }
      if (cnt > 1) for (let i = 0; i < k; i++) sum[i] /= cnt;
      memo.set(key, sum);
      return sum;
    }

    for (let it = 0; it < samples; it++) {
      // 필요한 만큼만 섞어 뽑는다
      for (let i = 0; i < need && i < pool.length - 1; i++) { const j = i + ((Math.random() * (pool.length - i)) | 0); const t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
      let p = 0, w = 1;
      for (let i = 0; i < 4; i++) hs[0][i] = mine[i];
      for (let oi = 1; oi < k; oi++) {
        const hh = hs[oi]; hh[0] = hh[1] = hh[2] = hh[3] = 0;
        for (let c = 0; c < sizes[oi]; c++) hh[pool[p++]]++;
        if (s.rs[order[oi]] && sizes[oi] > 0) w *= [0.6, 1, 1.45, 1.8, 2][hh[0]];
      }
      deckC = u.slice(); deckN = 0;
      for (let oi = 1; oi < k; oi++) for (let v = 0; v < 4; v++) deckC[v] -= hs[oi][v];
      for (let v = 0; v < 4; v++) deckN += deckC[v];
      memo = new Map();
      for (const c of cands) {
        let loss;
        if (s.tot + c > LIMIT) loss = 1;
        else { hs[0][c]--; loss = solve(s.tot + c, 1 % k)[0]; hs[0][c]++; }
        acc[c] += w * loss;
      }
      W += w;
    }
    return cands.map((c) => ({ c, loss: acc[c] / (W || 1) }));
  }

  /* 보통: 한 수 앞만 본다 — 다음 사람이 막힐 확률, 그 합계가 내게 돌아왔을 때 내가 낼 카드가 있는지 */
  function glance(s, seat) {
    const u = unseenOf(s, seat);
    const N = u[0] + u[1] + u[2] + u[3];
    const nx = nextAlive(s, seat);
    const mine = countsOf(s.h[seat]);
    const out = [];
    for (let c = 0; c < 4; c++) {
      if (!mine[c]) continue;
      const t = s.tot + c;
      if (t > LIMIT) { out.push({ c, loss: 1 }); continue; }
      const slack = LIMIT - t;
      let g = 0; for (let v = 0; v <= Math.min(3, slack); v++) g += u[v];
      const kNext = s.h[nx].length || HAND;
      const stuck = pNone(N, g, kNext);
      const rest = mine.slice(); rest[c]--;
      const left = rest[0] + rest[1] + rest[2] + rest[3];
      let mySafe = 0.5;
      if (left > 0) { mySafe = 0; for (let v = 0; v <= Math.min(3, slack); v++) if (rest[v]) mySafe = 1; }
      // 여유가 넉넉할 때는 큰 수부터 털고, 0은 아낀다
      const dump = slack >= 3 ? 0.04 * c : 0;
      const keep0 = c === 0 && left > 0 && mine[1] + mine[2] + mine[3] > 0 && s.tot + Math.min.apply(null, [1, 2, 3].filter((v) => mine[v])) <= LIMIT ? 0.18 : 0;
      const sc = stuck * 0.9 + mySafe * 0.55 + dump - keep0;
      out.push({ c, loss: clamp(0.6 - sc * 0.5, 0.02, 0.98) });
    }
    return out;
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'over' || s.turn !== seat) return null;
    const hand = s.h[seat];
    if (!hand.length) return null;
    const hb = habits(s, seat), st = styleOf(seat);
    const mine = countsOf(hand);
    const safe = [0, 1, 2, 3].filter((v) => mine[v] > 0 && s.tot + v <= LIMIT);
    if (!safe.length) return { t: 'play', c: hand[0] };            // 낼 수 있는 카드가 없다 — 가장 작은 수
    const al = aliveOf(s).length;
    const slack = LIMIT - s.tot;
    let pick, myLoss = 1 / al;

    if (lv <= 1) {
      // 쉬움: 넘기지만 않게, 나머지는 버릇대로. 0을 일찍 써 버리곤 한다
      const w = safe.map((v) => (v === 0 ? 0.9 + (1 - hb.hoard) * 0.9 : 1 + hb.push * v * 0.5) * (0.6 + Math.random() * 0.8));
      let bi = 0; for (let i = 1; i < w.length; i++) if (w[i] > w[bi]) bi = i;
      pick = safe[bi];
    } else {
      const ev = lv >= 3 ? think(s, seat, al <= 2 ? 90 : al === 3 ? 60 : 40) : glance(s, seat);
      const T = lv >= 3 ? 0.02 : 0.1;
      let best = -1e9;
      for (const e of ev) {
        if (e.loss >= 1) continue;
        // 버릇 · 성향은 비슷한 수 사이에서만 저울을 기울인다
        let sc = -e.loss;
        const lean = lv >= 3 ? 0.012 : 0.05;
        sc += lean * (hb.push - 0.5) * e.c + lean * (hb.hoard - 0.5) * (e.c === 0 ? -1.5 : 0);
        if (st === 'agg') sc += lean * 0.5 * e.c; else if (st === 'def') sc -= lean * 0.5 * e.c;
        sc += (Math.random() - 0.5) * 2 * T;
        if (sc > best) { best = sc; pick = e.c; myLoss = e.loss; }
      }
      if (pick == null) pick = safe[0];
    }

    /* 판돈 올림: 내가 넘길 확률이 고르게 나눈 몫보다 얼마나 낮은가 + 칩 사정 + 버릇 */
    let up = 0;
    if (s.up && !s.rs[seat]) {
      const zeros = mine[0] - (pick === 0 ? 1 : 0);
      if (lv <= 1) {
        up = Math.random() < (zeros >= 2 ? 0.22 : 0.04 + hb.bluff * 0.05) ? 1 : 0;
      } else {
        const base = 1 / al;
        let edge;
        if (lv >= 3) edge = base - myLoss;
        else edge = (zeros >= 2 ? 0.14 : zeros === 1 ? 0.02 : -0.12) + (slack <= 4 ? 0.05 : -0.04);
        let margin = 0.16 - hb.bold * 0.1;
        if (st === 'gamble' || st === 'agg') margin -= 0.03; else if (st === 'def') margin += 0.04;
        const me = s.scores[seat];
        if (me <= s.stake + 1) margin += 0.07;                       // 지면 끝나는 판은 조심
        const lead = Math.max.apply(null, s.scores.filter((_, i) => i !== seat));
        if (me < lead) margin -= 0.03;                               // 뒤지고 있으면 승부를 건다
        if (hand.length <= 1) margin += 0.05;                        // 곧 다시 받는다 — 근거가 옅다
        if (edge > margin + (Math.random() - 0.5) * 0.06) up = 1;
        else if (Math.random() < hb.bluff * (lv >= 3 ? 0.035 : 0.05) && myLoss < 0.6 && slack >= 2) up = 1;   // 드문 허세
      }
    }
    return up ? { t: 'play', c: pick, up: 1 } : { t: 'play', c: pick };
  }

  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'over') return -1;
    const slack = LIMIT - s.tot;
    return 720 + Math.random() * 480 + (slack <= 2 ? 380 : 0) + (lv <= 1 ? 120 : 0);
  }

  /* ---------- 상황 도움말 ---------- */
  function hint(s, seat) {
    if (s.ph === 'over') return null;
    const out = [];
    const slack = LIMIT - s.tot;
    out.push(s.rd + '판 · 합계 ' + s.tot + ' · 판돈 ' + s.stake);
    out.push(slack > 0 ? '지금 낼 수 있는 수는 ' + Math.min(3, slack) + ' 이하입니다.' : '합계가 9입니다. 0만 낼 수 있습니다.');
    if (seat >= 0 && s.h[seat] && s.h[seat].length) {
      const u = unseenOf(s, seat);
      out.push('내 패를 빼고 아직 안 나온 카드 — 0: ' + u[0] + '장 · 1: ' + u[1] + '장 · 2: ' + u[2] + '장 · 3: ' + u[3] + '장');
      const safe = s.h[seat].filter((c) => c <= slack);
      if (!safe.length) out.push('낼 수 있는 카드가 없습니다. 어느 것을 내도 넘깁니다.');
      else if (s.h[seat].indexOf(0) >= 0) out.push('0은 합계를 올리지 않습니다. 합계가 9에 닿은 뒤를 위해 아껴 두는 편이 좋습니다.');
    }
    out.push('손패가 모두 떨어지면 합계는 그대로 두고 4장씩 다시 받습니다. 그때 판돈이 1 오릅니다.');
    if (s.up) out.push('카드를 내며 판돈을 1 올릴 수 있습니다(한 판에 한 번).');
    return out.slice(0, 6);
  }

  /* ======================= 소리(WebAudio 합성) ======================= */
  const Snd = {
    ac: null,
    ctx() {
      if (!this.ac) { try { this.ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { this.ac = null; } }
      if (this.ac && this.ac.state === 'suspended') { try { this.ac.resume(); } catch (e) {} }
      return this.ac;
    },
    vol() { try { return L.audio && L.audio.sfx ? L.audio.sfx() : 0.6; } catch (e) { return 0.6; } },
    tone(f, dur, g, type, f2, at) {
      const ac = this.ac, t0 = ac.currentTime + 0.01 + (at || 0), o = ac.createOscillator(), gn = ac.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f, t0);
      if (f2) o.frequency.exponentialRampToValueAtTime(f2, t0 + dur);
      gn.gain.setValueAtTime(0.0001, t0); gn.gain.exponentialRampToValueAtTime(g, t0 + 0.012); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(gn); gn.connect(ac.destination); o.start(t0); o.stop(t0 + dur + 0.03);
    },
    /* 합계가 오를수록 높아지는 음. 7부터는 낮은 박동이 따라붙는다 */
    step(tot) {
      const v = this.vol(); if (v <= 0.001) return;
      const ac = this.ctx(); if (!ac) return;
      const t = clamp(tot, 0, LIMIT);
      this.tone(196 * Math.pow(2, t / 9), 0.16, v * 0.16, 'triangle');
      if (t >= 7) { const g = v * (t >= 9 ? 0.5 : t === 8 ? 0.38 : 0.26); this.tone(62, 0.18, g, 'sine', 36, 0.1); this.tone(54, 0.18, g * 0.65, 'sine', 32, 0.27); }
    },
    bust() {
      const v = this.vol(); if (v <= 0.001) return;
      const ac = this.ctx(); if (!ac) return;
      this.tone(110, 0.5, v * 0.3, 'sawtooth', 41); this.tone(58, 0.6, v * 0.5, 'sine', 30);
    },
    raise() {
      const v = this.vol(); if (v <= 0.001) return;
      const ac = this.ctx(); if (!ac) return;
      this.tone(1320, 0.07, v * 0.07, 'square', 1760); this.tone(1760, 0.09, v * 0.06, 'square', 2200, 0.07);
    },
  };

  /* ======================= 스타일 ======================= */
  const CSS = `
.nz{position:absolute;inset:0;overflow:hidden;color:#ece3d1;font-family:var(--f-body);user-select:none;-webkit-user-select:none;word-break:keep-all;
 background:radial-gradient(120% 80% at 50% 42%,#1b2a27 0%,#11181a 55%,#07090b 100%)}
.nz *{box-sizing:border-box}
.nz-in{position:absolute;top:0;bottom:0;left:50%;width:100%;max-width:560px;transform:translateX(-50%);display:flex;flex-direction:column;padding:6px 8px calc(8px + env(safe-area-inset-bottom,0px));gap:6px}
.nz.shake .nz-in{animation:nzShake .42s}
@keyframes nzShake{0%,100%{transform:translateX(-50%)}20%{transform:translateX(calc(-50% - 7px * var(--fx,1)))}45%{transform:translateX(calc(-50% + 6px * var(--fx,1)))}70%{transform:translateX(calc(-50% - 3px * var(--fx,1)))}}
.nz-flash{position:absolute;inset:0;pointer-events:none;z-index:6;background:radial-gradient(ellipse 80% 60% at 50% 45%,rgba(190,40,30,.5),rgba(120,10,10,.15) 70%,transparent);opacity:0}
.nz.shake .nz-flash{animation:nzFl .7s}
@keyframes nzFl{0%{opacity:0}15%{opacity:calc(.9 * var(--fx,1))}100%{opacity:0}}
.nz-ops{display:flex;gap:6px;padding-right:50px;min-height:74px}
.nz-ops.all{padding-right:50px}
.nz-op{flex:1 1 0;min-width:0;border-radius:10px;border:1px solid #ffffff1c;background:#0b0f11c0;padding:5px 7px;display:flex;flex-direction:column;gap:3px;transition:border-color .2s,box-shadow .2s}
.nz-op.on{border-color:var(--c);box-shadow:0 0 0 1px var(--c),0 0 14px -2px var(--c)}
.nz-op.out{opacity:.45}
.nz-op.lost{border-color:#e0533f;box-shadow:0 0 0 1px #e0533f}
.nz-nm{display:flex;align-items:center;gap:5px;font-size:13px;font-weight:700;line-height:17px;min-width:0}
.nz-nm span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}
.nz-d{flex:none;width:9px;height:9px;border-radius:50%;background:var(--c)}
.nz-ln{display:flex;align-items:center;gap:6px;min-height:18px}
.nz-chip{display:inline-flex;align-items:center;gap:4px;font:700 14px var(--f-mono);color:#f0d48a;line-height:18px}
.nz-chip i{width:12px;height:12px;border-radius:50%;background:radial-gradient(circle,#e8c46a 0 32%,#8d6421 36% 58%,#e8c46a 62%)}
.nz-chip.z{color:#a89c88}.nz-chip.z i{filter:grayscale(1) brightness(.6)}
.nz-up{font-size:12px;line-height:16px;padding:0 5px;border-radius:5px;border:1px solid #e3ae4588;color:#f0d48a;white-space:nowrap}
.nz-gone{font-size:12px;color:#b3a794}
.nz-mini{display:flex;gap:3px;align-items:center;min-height:28px}
.nz-bk{width:15px;height:21px;border-radius:3px;border:1px solid #c9a25399;background:repeating-linear-gradient(45deg,#3a1418 0 3px,#2a0d11 3px 6px)}
.nz-c{position:relative;flex:none;border-radius:8%/6%;display:grid;place-items:center;font-family:var(--f-display);font-weight:400;line-height:1;
 background:linear-gradient(160deg,#f6efdf,#ddd2ba);color:#1b1a20;box-shadow:0 2px 6px #000a,inset 0 0 0 1px #0003}
.nz-c[data-v="0"]{background:linear-gradient(160deg,#23202a,#0c0b10);color:#e8c46a;box-shadow:0 2px 6px #000a,inset 0 0 0 1px #c9a25388}
.nz-c[data-v="2"]{color:#3a2c62}.nz-c[data-v="3"]{color:#8a231c}
.nz-c.s{width:20px;height:28px;font-size:15px;border-radius:3px}
.nz-tb{position:relative;flex:1 1 auto;min-height:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;border-radius:16px;padding:6px 8px;
 background:radial-gradient(ellipse 75% 70% at 50% 45%,#1f4a3e 0%,#143229 60%,#0c1e19 100%);box-shadow:inset 0 0 0 3px #2a1a10,inset 0 0 0 4px #6b4a2466,inset 0 0 40px #000b}
.nz-hd{display:flex;gap:8px;align-items:center;justify-content:center;flex-wrap:wrap;font-size:13px;color:#d9ceb6;line-height:18px}
.nz-hd b{font:700 14px var(--f-mono);color:#f0d48a}
.nz-hd .sep{width:1px;height:12px;background:#ffffff33}
.nz-hd .stk.hi b{color:#ff9a7a}
.nz-totw{display:flex;align-items:baseline;gap:8px;--tc:#ece3d1}
.nz-totw.w{--tc:#e9b54e}.nz-totw.h{--tc:#f0705a}.nz-totw.x{--tc:#ff4d3a}
.nz-totw .lb{font-size:13px;color:#cdc2aa}
.nz-tot{font:400 var(--tf,62px)/1 var(--f-display);color:var(--tc);text-shadow:0 2px 0 #0008,0 0 22px color-mix(in srgb,var(--tc) 35%,transparent);min-width:1.1em;text-align:center}
.nz-tot.tick{animation:nzTick .32s}
@keyframes nzTick{0%{transform:scale(1.28)}100%{transform:scale(1)}}
.nz-totw.h .nz-tot{animation:nzBeat 1s infinite}
.nz-totw.h .nz-tot.tick{animation:nzTick .32s}
@keyframes nzBeat{0%,100%{transform:scale(1)}12%{transform:scale(1.05)}24%{transform:scale(1)}36%{transform:scale(1.035)}48%{transform:scale(1)}}
.nz-totw .of{font:600 18px var(--f-mono);color:#b9ae97}
.nz-g{display:flex;gap:4px;width:min(100%,300px)}
.nz-g i{flex:1;height:10px;border-radius:3px;background:#00000066;box-shadow:inset 0 0 0 1px #ffffff14;transition:background .2s}
.nz-g i.f{background:#cdb87a}.nz-g i.f.w{background:#e9b54e}.nz-g i.f.h{background:#f0705a;box-shadow:0 0 8px #f0705a99}
.nz-sl{font-size:13px;color:#d9ceb6;line-height:17px;min-height:17px;text-align:center}
.nz-sl.h{color:#ffab98}
.nz-pile{display:flex;flex-wrap:wrap;justify-content:center;align-content:center;gap:4px 0;min-height:46px;max-width:100%;padding:0 8px}
.nz-pc{position:relative;margin:0 -4px;padding-bottom:5px}
.nz-pc .nz-c{width:var(--pw,30px);height:calc(var(--pw,30px) * 1.4);font-size:calc(var(--pw,30px) * .73);border-radius:4px}
.nz-pc::after{content:"";position:absolute;left:5px;right:5px;bottom:0;height:3px;border-radius:2px;background:var(--c)}
.nz-pc.new .nz-c{box-shadow:0 0 0 2px #f0d48a,0 0 12px #f0d48a88}
.nz-pc.drop{animation:nzDrop .36s cubic-bezier(.2,.8,.3,1)}
@keyframes nzDrop{0%{transform:translateY(var(--dy,-40px)) scale(1.5);opacity:0}100%{transform:none;opacity:1}}
.nz-pe{font-size:13px;color:#b9c7bf}
.nz-note{position:absolute;left:50%;bottom:6px;transform:translateX(-50%);max-width:92%;padding:4px 10px;border-radius:9px;background:rgba(8,10,12,.72);border:1px solid #d4ad5c55;
 font-size:13px;line-height:18px;color:#f2e9d6;text-align:center;pointer-events:none;opacity:0;z-index:5;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nz-note.on{animation:nzNote 1.5s forwards}
.nz-note.r{border-color:#e0533f99;color:#ffc9bd}
@keyframes nzNote{0%{opacity:0}10%{opacity:1}80%{opacity:1}100%{opacity:0}}
.nz-cnt{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}
.nz-ct{display:flex;align-items:center;gap:5px;border-radius:8px;background:#0b0f11c0;border:1px solid #ffffff18;padding:4px 5px;min-width:0}
.nz-ct .nz-c{width:20px;height:28px;font-size:16px;border-radius:3px}
.nz-ct .r{display:flex;flex-direction:column;gap:3px;min-width:0;flex:1}
.nz-pp{display:grid;grid-template-columns:repeat(5,6px);gap:2px}
.nz-pp i{width:6px;height:6px;border-radius:1.5px;background:#e9dfca}
.nz-pp i.s{background:#ffffff1f}
.nz-pp i.m{background:transparent;box-shadow:inset 0 0 0 1.5px #e3ae45}
.nz-ct b{font:600 12px var(--f-body);color:#d9ceb6;line-height:14px;white-space:nowrap}
.nz-ct b em{font:700 13px var(--f-mono);font-style:normal;color:#f2e9d6}
.nz-ct.lo b em{color:#ff9a7a}
.nz-me{border-radius:12px;border:1px solid #ffffff1c;background:#0b0f11c0;padding:6px 8px 8px;display:flex;flex-direction:column;gap:5px;transition:border-color .2s,box-shadow .2s}
.nz-me.on{border-color:var(--c);box-shadow:0 0 0 1px var(--c),0 0 16px -3px var(--c)}
.nz-me.lost{border-color:#e0533f;box-shadow:0 0 0 1px #e0533f}
.nz-me[hidden],.nz-btn[hidden]{display:none}
.nz-who{display:flex;align-items:center;gap:8px;min-height:20px}
.nz-who .nz-nm{font-size:14px;flex:0 1 auto}
.nz-tip{flex:1;text-align:right;font-size:13px;color:#d9ceb6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:18px}
.nz-tip b{color:#f0d48a}.nz-tip.r,.nz-tip.r b{color:#ffab98}
.nz-hand{display:flex;justify-content:center;gap:8px;height:calc(var(--hw,70px) * 1.36 + 12px);align-items:flex-end;touch-action:manipulation}
.nz-hand .nz-c{width:var(--hw,70px);height:calc(var(--hw,70px) * 1.36);font-size:calc(var(--hw,70px) * .62);border:0;padding:0;cursor:pointer;transition:transform .14s,filter .14s,box-shadow .14s}
.nz-hand .nz-c::before{content:attr(data-v);position:absolute;left:7%;top:5%;font-size:calc(var(--hw,70px) * .2);opacity:.8}
.nz-hand .nz-c.sel{transform:translateY(-12px);box-shadow:0 0 0 2px #f0d48a,0 0 18px #f0d48aaa,0 8px 14px #000c}
.nz-hand .nz-c.bad{filter:saturate(.6) brightness(.72)}
.nz-hand .nz-c.bad.sel{box-shadow:0 0 0 2px #f0705a,0 0 18px #f0705aaa,0 8px 14px #000c;filter:none}
.nz-hand .nz-c .x{position:absolute;left:0;right:0;bottom:5%;text-align:center;font:600 12px var(--f-body);color:#b3261c}
.nz-hand .nz-c[data-v="0"] .x{color:#ff9a7a}
.nz-hand.lock .nz-c{cursor:default}
.nz-hand.lock .nz-c.bad{filter:none}
.nz-hand .nz-c.in{animation:nzIn .34s backwards}
@keyframes nzIn{0%{transform:translateY(26px);opacity:0}100%{transform:none;opacity:1}}
.nz-hand .nz-bk{width:var(--hw,70px);height:calc(var(--hw,70px) * 1.36);border-radius:6px}
.nz-hand .emp{align-self:center;font-size:13px;color:#b3a794}
.nz-act{display:flex;gap:8px;min-height:48px}
.nz-btn{flex:1 1 0;min-height:48px;min-width:0;border-radius:10px;border:1px solid #d4ad5c99;background:linear-gradient(#2c2620,#191511);color:#f4e6c4;font:700 15px var(--f-body);cursor:pointer;padding:2px 8px;line-height:1.15}
.nz-btn.pri{flex:1.5 1 0;background:linear-gradient(#caa04a,#8d6421);color:#1a1006;border-color:#f0d48a}
.nz-btn.pri.r{background:linear-gradient(#c45a48,#7d2a20);color:#fff3ea;border-color:#f0a08f}
.nz-btn.tog.on{background:linear-gradient(#5a3d14,#3a270c);border-color:#f0d48a;color:#ffe6a6;box-shadow:inset 0 0 0 1px #f0d48a}
.nz-btn:disabled,.nz-btn.pri:disabled{cursor:default;background:#12100e;border:1px dashed #5f5045;color:#a89c88;box-shadow:none}
.nz-btn:not(:disabled):active{transform:scale(.97)}
@media (prefers-reduced-motion:reduce){.nz-totw.h .nz-tot{animation:none}}
html.no-anim .nz-totw.h .nz-tot{animation:none}`;

  /* ======================= 화면 ======================= */
  function mount(root, api) {
    const h = L.h;
    if (!document.getElementById('nz-css')) { const st = document.createElement('style'); st.id = 'nz-css'; st.textContent = CSS; document.head.appendChild(st); }
    const spd = () => Math.max(0.25, (L.debug && L.debug.speed) || 1) * ((L.speed && L.speed()) || 1);
    const NM = (i) => (api.players[i] && api.players[i].name) || ('자리 ' + (i + 1));
    const COL = (i) => (api.players[i] && api.players[i].color) || '#d4ad5c';

    const ops = h('div', { class: 'nz-ops' });
    const hd = h('div', { class: 'nz-hd' });
    const totEl = h('div', { class: 'nz-tot', text: '0' });
    const totW = h('div', { class: 'nz-totw' }, h('span', { class: 'lb', text: '합계' }), totEl, h('span', { class: 'of', text: '/ 9' }));
    const gauge = h('div', { class: 'nz-g', 'aria-hidden': 'true' }, Array.from({ length: LIMIT }, () => h('i')));
    const slackEl = h('div', { class: 'nz-sl' });
    const pileEl = h('div', { class: 'nz-pile' });
    const noteEl = h('div', { class: 'nz-note', role: 'status' });
    const tb = h('div', { class: 'nz-tb' }, hd, totW, gauge, slackEl, pileEl, noteEl);
    const cnt = h('div', { class: 'nz-cnt' });
    const whoEl = h('div', { class: 'nz-who' });
    const handEl = h('div', { class: 'nz-hand' });
    const upBtn = h('button', { class: 'nz-btn tog', type: 'button', 'data-action': 'up', onclick: () => toggleUp() });
    const playBtn = h('button', { class: 'nz-btn pri', type: 'button', 'data-action': 'play', onclick: () => playSel() });
    const actEl = h('div', { class: 'nz-act' }, upBtn, playBtn);
    const meEl = h('div', { class: 'nz-me' }, whoEl, handEl, actEl);
    const el = h('div', { class: 'nz' }, h('div', { class: 'nz-in' }, ops, tb, cnt, meEl), h('div', { class: 'nz-flash' }));
    root.appendChild(el);

    let cur = null, seenId = -1, sel = -1, upOn = false, sent = false, animating = false, lastBot = -1, lastVM = null, dead = false;
    let timers = [], noteT = 0, sumId = -1;

    function later(ms, fn) { const id = setTimeout(() => { timers = timers.filter((x) => x !== id); if (!dead) fn(); }, ms / spd()); timers.push(id); }
    function clearTimers() { timers.forEach(clearTimeout); timers = []; }

    function fit() {
      const r = el.getBoundingClientRect();
      const w = Math.min(r.width, 560), hh = r.height;
      const hw = clamp(Math.min((w - 16 - 16 - 24) / 4, hh * 0.155), 50, 92);
      el.style.setProperty('--hw', hw.toFixed(1) + 'px');
      el.style.setProperty('--tf', (hh < 600 ? 48 : hh >= 760 ? 84 : 62) + 'px');
      el.style.setProperty('--pw', (hh >= 760 ? 40 : 30) + 'px');
    }
    const onResize = () => fit();
    window.addEventListener('resize', onResize);

    function note(text, red) {
      noteEl.textContent = text;
      noteEl.classList.toggle('r', !!red);
      noteEl.classList.remove('on'); void noteEl.offsetWidth; noteEl.classList.add('on');
      clearTimeout(noteT); noteT = setTimeout(() => noteEl.classList.remove('on'), 1550);
    }
    const hideNote = () => { noteEl.classList.remove('on'); };
    el.addEventListener('pointerdown', hideNote);

    /* 아래쪽에 손패를 보여 줄 자리(-1 = 관전) */
    function bottomSeat() {
      const mine = api.mySeats();
      if (!mine.length) return -1;
      if (mine.length === 1) return mine[0];
      if (cur && cur.ph !== 'over' && api.canAct(cur.turn)) lastBot = cur.turn;
      if (lastBot < 0 || mine.indexOf(lastBot) < 0) lastBot = mine[0];
      return lastBot;
    }
    const canSee = (seat) => seat >= 0 && api.viewer() === seat;
    const myTurn = (me) => !!cur && cur.ph !== 'over' && me >= 0 && cur.turn === me && api.canAct(me) && canSee(me) && !animating && !sent;

    function finalVM(s) {
      return { tot: s.tot, pile: s.pile, hc: s.h.map((x) => x.length), hands: s.h, ch: s.scores, stake: s.stake, turn: s.ph === 'over' ? -1 : s.turn, dk: s.deck.length, seen: s.seen, rd: s.rd, rs: s.rs, reveal: false, loser: -1, over: s.ph === 'over' };
    }
    function stageVM(s, a) {
      return { tot: a.t1, pile: a.b ? a.b.pile : s.pile, hc: a.hc, hands: a.b ? a.b.h : a.d ? null : s.h, ch: a.b ? a.b.ch0 : s.scores, stake: a.stake, turn: -1, dk: a.dk, seen: a.seen, rd: a.rd, rs: a.rs, reveal: false, loser: -1, over: false };
    }

    function chipEl(n) { return h('span', { class: 'nz-chip' + (n <= 0 ? ' z' : ''), title: '칩' }, h('i'), String(n)); }
    function cardEl(v, cls) { return h('div', { class: 'nz-c' + (cls ? ' ' + cls : ''), 'data-v': v, text: String(v) }); }

    function render(vm, fxo) {
      fxo = fxo || {};
      lastVM = vm;
      const me = bottomSeat();
      const n = api.players.length;
      /* 위: 상대들(관전이면 모두) */
      const seats = [];
      if (me < 0) for (let i = 0; i < n; i++) seats.push(i);
      else for (let k = 1; k < n; k++) seats.push((me + k) % n);
      ops.innerHTML = '';
      seats.forEach((i) => {
        const gone = vm.ch[i] <= 0 && !(vm.loser === i) && !(vm.hands && vm.hands[i] && vm.hands[i].length);
        const d = h('div', { class: 'nz-op' + (vm.turn === i ? ' on' : '') + (gone ? ' out' : '') + (vm.loser === i ? ' lost' : ''), style: { '--c': COL(i) } },
          h('div', { class: 'nz-nm' }, h('i', { class: 'nz-d' }), h('span', { text: NM(i) })),
          h('div', { class: 'nz-ln' }, chipEl(vm.ch[i]), vm.rs[i] ? h('span', { class: 'nz-up', text: '올림' }) : null));
        const mini = h('div', { class: 'nz-mini' });
        if (gone) mini.append(h('span', { class: 'nz-gone', text: '탈락' }));
        else if (vm.reveal && vm.hands && vm.hands[i] && vm.hands[i].length) vm.hands[i].forEach((v) => mini.append(cardEl(v, 's')));
        else for (let k = 0; k < vm.hc[i]; k++) mini.append(h('i', { class: 'nz-bk' }));
        d.append(mini);
        ops.append(d);
      });
      /* 가운데: 판 정보 · 합계 · 눈금 · 낸 카드 */
      hd.innerHTML = '';
      hd.append(h('span', null, h('b', { text: String(vm.rd) }), '판'), h('i', { class: 'sep' }),
        h('span', { class: 'stk' + (vm.stake >= 3 ? ' hi' : '') }, '판돈 ', h('b', { text: String(vm.stake) })), h('i', { class: 'sep' }),
        h('span', null, '더미 ', h('b', { text: String(vm.dk) }), '장'));
      const t = vm.tot, lvl = t > LIMIT ? 'x' : t >= 8 ? 'h' : t >= 6 ? 'w' : '';
      totW.className = 'nz-totw' + (lvl ? ' ' + lvl : '');
      if (totEl.textContent !== String(t)) { totEl.textContent = String(t); totEl.classList.remove('tick'); void totEl.offsetWidth; totEl.classList.add('tick'); }
      for (let i = 0; i < LIMIT; i++) gauge.children[i].className = i < t ? 'f' + (t > LIMIT || i >= 7 ? ' h' : i >= 5 ? ' w' : '') : '';
      const slack = LIMIT - t;
      slackEl.className = 'nz-sl' + (slack <= 1 ? ' h' : '');
      slackEl.textContent = t > LIMIT ? '9를 넘겼습니다' : slack === 0 ? '여유 없음 — 0만 낼 수 있습니다' : '여유 ' + slack + ' — ' + Math.min(3, slack) + ' 이하만 안전';
      pileEl.innerHTML = '';
      if (!vm.pile.length) pileEl.append(h('span', { class: 'nz-pe', text: '아직 낸 카드가 없습니다' }));
      vm.pile.forEach((pc, i) => {
        const isNew = i === vm.pile.length - 1;
        const w = h('div', { class: 'nz-pc' + (isNew ? ' new' : '') + (isNew && fxo.drop ? ' drop' : ''), style: { '--c': COL(pc[0]), '--dy': pc[0] === me ? '46px' : '-46px' }, title: NM(pc[0]) }, cardEl(pc[1]));
        pileEl.append(w);
      });
      /* 남은 카드(내 패 제외) */
      const mineSee = me >= 0 && (canSee(me) || vm.reveal) && vm.hands && vm.hands[me] ? vm.hands[me] : [];
      const mc = countsOf(mineSee);
      cnt.innerHTML = '';
      for (let v = 0; v < 4; v++) {
        const left = EACH - vm.seen[v] - mc[v];
        const pp = h('div', { class: 'nz-pp', 'aria-hidden': 'true' });
        for (let k = 0; k < EACH; k++) pp.append(h('i', { class: k < left ? '' : k < left + mc[v] ? 'm' : 's' }));
        cnt.append(h('div', { class: 'nz-ct' + (left <= 2 ? ' lo' : ''), title: v + ' 카드 — 안 나온 ' + left + '장' }, cardEl(v), h('div', { class: 'r' }, pp, h('b', null, '남은 ', h('em', { text: String(left) })))));
      }
      /* 아래: 내 자리 */
      meEl.hidden = me < 0;
      if (me >= 0) {
        const mt = myTurn(me) && !fxo.lock;
        meEl.className = 'nz-me' + (vm.turn === me ? ' on' : '') + (vm.loser === me ? ' lost' : '');
        meEl.style.setProperty('--c', COL(me));
        const hand = vm.hands && vm.hands[me] ? vm.hands[me] : [];
        const see = canSee(me) || vm.reveal;
        if (sel >= hand.length) sel = -1;
        if (!mt) { sel = -1; }
        const tip = h('div', { class: 'nz-tip' });
        if (vm.over) tip.textContent = '';
        else if (mt) {
          if (sel < 0) tip.append(h('b', { text: '내 차례' }), ' · 낼 카드를 고르십시오');
          else { const c = hand[sel], nt = vm.tot + c; if (nt > LIMIT) { tip.classList.add('r'); tip.append(String(c) + ' → 합계 ', h('b', { text: String(nt) }), ' · 9를 넘깁니다'); } else tip.append(String(c) + ' → 합계 ', h('b', { text: String(nt) }), nt === LIMIT ? ' · 다음은 0만 가능' : ''); }
        } else if (vm.turn >= 0 && vm.turn !== me) tip.textContent = NM(vm.turn) + ' 차례';
        else if (vm.turn === me && !see) tip.textContent = '가림막을 걷으면 손패가 보입니다';
        whoEl.innerHTML = '';
        whoEl.append(h('div', { class: 'nz-nm' }, h('i', { class: 'nz-d' }), h('span', { text: NM(me) })), chipEl(vm.ch[me]));
        if (vm.rs[me]) whoEl.append(h('span', { class: 'nz-up', text: '올림' }));
        whoEl.append(tip);
        handEl.innerHTML = '';
        handEl.className = 'nz-hand' + (mt ? '' : ' lock');
        if (vm.ch[me] <= 0 && !hand.length) handEl.append(h('span', { class: 'emp', text: vm.over ? '' : '탈락 — 관전 중' }));
        else if (!see) { for (let k = 0; k < vm.hc[me]; k++) handEl.append(h('i', { class: 'nz-bk' })); if (!vm.hc[me]) handEl.append(h('span', { class: 'emp', text: '손패 없음' })); }
        else if (!hand.length) handEl.append(h('span', { class: 'emp', text: vm.over ? '' : '손패 없음' }));
        else hand.forEach((c, i) => {
          const bad = vm.tot + c > LIMIT;
          const b = h('button', { class: 'nz-c' + (sel === i ? ' sel' : '') + (bad && !vm.reveal ? ' bad' : '') + (fxo.deal ? ' in' : ''), type: 'button', 'data-v': c, 'data-i': i, 'aria-label': c + ' 카드' + (bad ? ' (넘김)' : ''), style: fxo.deal ? { animationDelay: (i * 60) + 'ms' } : null, onclick: () => tapCard(i) }, String(c), bad && !vm.reveal ? h('span', { class: 'x', text: '넘김' }) : null);
          handEl.append(b);
        });
        /* 단추 */
        const canUp = mt && cur.up && !cur.rs[me];
        if (!canUp) upOn = false;
        upBtn.hidden = !(cur && cur.up);
        upBtn.disabled = !canUp;
        upBtn.className = 'nz-btn tog' + (upOn ? ' on' : '');
        upBtn.textContent = cur && cur.rs[me] ? '이번 판 올림 완료' : upOn ? '판돈 +1 걸림' : '판돈 올리기 +1';
        upBtn.setAttribute('aria-pressed', upOn ? 'true' : 'false');
        const selBad = mt && sel >= 0 && vm.tot + hand[sel] > LIMIT;
        playBtn.disabled = !(mt && sel >= 0);
        playBtn.className = 'nz-btn pri' + (selBad ? ' r' : '');
        playBtn.textContent = !mt ? (vm.over ? '종료' : '대기') : sel < 0 ? '카드 선택' : selBad ? hand[sel] + ' 내기 — 넘김' : hand[sel] + ' 내기' + (upOn ? ' · 판돈 +1' : '');
      }
    }

    function rerender() { if (lastVM) render(lastVM); }
    function tapCard(i) {
      const me = bottomSeat();
      if (!myTurn(me)) return;
      if (sel === i) { playSel(); return; }
      sel = i; api.sfx('tick'); rerender();
    }
    function toggleUp() {
      const me = bottomSeat();
      if (!myTurn(me) || !cur.up || cur.rs[me]) return;
      upOn = !upOn; api.sfx('click'); rerender();
    }
    function playSel() {
      const me = bottomSeat();
      if (!myTurn(me) || sel < 0) return;
      const hand = cur.h[me];
      if (sel >= hand.length) return;
      const a = { t: 'play', c: hand[sel] };
      if (upOn) a.up = 1;
      sel = -1; upOn = false;
      if (api.online && !api.isHost) { sent = true; rerender(); }
      api.buzz(12, 'ui');
      api.actAs(me, a);
    }

    function finish() {
      clearTimers();
      el.classList.remove('shake');
      if (animating) { animating = false; api.setBusy(false); }
    }

    function animate(s) {
      const a = s.last;
      animating = true; api.setBusy(true);
      const A = stageVM(s, a);
      render(A, { drop: true, lock: true });
      api.sfx('card'); Snd.step(a.t1);
      if (a.up) { Snd.raise(); note(NM(a.s) + ' — 판돈 올림 · 이제 ' + a.stake); }
      let t = 430;
      if (a.b) {
        later(t, () => {
          A.reveal = true; A.loser = a.b.l;
          render(A, { lock: true });
          try { el.style.setProperty('--fx', String(L.fx ? L.fx() : 1)); } catch (e) {}
          el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
          Snd.bust(); api.sfx(api.canAct(a.b.l) ? 'lose' : 'thud'); api.buzz(60, 'hit');
          note(NM(a.b.l) + ' 넘김 — 칩 −' + a.b.pay + (a.b.el ? ' · 탈락' : ''), true);
        });
        t += 1500;
        later(t, () => { A.ch = s.scores; render(A, { lock: true }); api.sfx('chip'); });
        t += s.ph === 'over' ? 300 : 450;
      }
      if (a.d && s.ph !== 'over') {
        later(t, () => {
          el.classList.remove('shake');
          const F = finalVM(s); F.turn = -1;
          render(F, { deal: true, lock: true });
          api.sfx('whoosh');
          if (a.d.re) note('손패 소진 — 4장씩 다시 받습니다 · 판돈 ' + a.d.stake + (a.d.shuf ? ' · 새 벌' : ''));
          else note(a.d.rd + '판 — ' + NM(a.d.first) + ' 선' + (a.d.shuf ? ' · 새 벌을 섞었습니다' : ''));
        });
        t += 520;
      }
      later(t, () => { animating = false; el.classList.remove('shake'); render(finalVM(cur)); api.setBusy(false); });
    }

    function update(s, prev) {
      if (!s) return;
      cur = s; sent = false;
      fit();
      const fresh = !!(s.last && s.last.id !== seenId);
      if (seenId >= 0 && fresh && prev && prev !== s) {
        if (animating) finish();
        seenId = s.last.id; sel = -1; upOn = false;
        animate(s);
        return;
      }
      if (animating && !fresh) return;                      // 연출 중 다시 그리기 요청은 건너뜀
      if (animating) finish();
      const first = seenId < 0;
      seenId = s.last ? s.last.id : 0;
      render(finalVM(s));
      if (first && !s.last && s.ph !== 'over') note('1판 — ' + NM(s.turn) + ' 선');
      else if (prev === s && s.last && sumId !== s.last.id && api.mySeats().length > 1 && s.ph !== 'over') {
        // 한 폰 돌려하기: 가림막을 걷은 사람에게 직전에 있었던 일을 짧게 알린다
        const a = s.last; sumId = a.id;
        note(a.b ? '직전 — ' + NM(a.b.l) + ' 넘김 · 칩 −' + a.b.pay : '직전 — ' + NM(a.s) + ': ' + a.c + (a.up ? ' · 판돈 올림' : ''), !!a.b);
      }
    }

    /* PC 단축키 · 오른쪽 클릭 취소 */
    let offIn = null;
    try {
      if (api.input && api.input.on) offIn = api.input.on((type, id) => {
        if (type !== 'down' || !cur) return;
        const me = bottomSeat();
        if (!myTurn(me)) return;
        const m = /^c([1-4])$/.exec(id);
        if (m) { const i = +m[1] - 1; if (i < cur.h[me].length) { if (sel !== i) { sel = i; api.sfx('tick'); rerender(); } } }
        else if (id === 'play') playSel();
        else if (id === 'up') toggleUp();
      });
    } catch (e) {}
    const onCancel = (e) => { if (sel >= 0 || upOn) { sel = -1; upOn = false; rerender(); e.preventDefault(); } };
    window.addEventListener('lounge-cancel', onCancel);

    fit();
    return {
      update,
      destroy() {
        dead = true;
        clearTimers(); clearTimeout(noteT);
        if (animating) { animating = false; api.setBusy(false); }
        window.removeEventListener('resize', onResize);
        window.removeEventListener('lounge-cancel', onCancel);
        if (offIn) { try { offIn(); } catch (e) {} }
        el.remove();
      },
    };
  }

  /* ======================= 규칙 · 등록 ======================= */
  const ICON = '<g fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round">' +
    '<rect x="9" y="13" width="22" height="31" rx="3" transform="rotate(-10 20 28)"/>' +
    '<rect x="25" y="11" width="22" height="31" rx="3" transform="rotate(9 36 26)" fill="currentColor" fill-opacity=".12"/></g>' +
    '<ellipse cx="36" cy="26.5" rx="5.2" ry="7.4" fill="none" stroke="currentColor" stroke-width="2.8" transform="rotate(9 36 26)"/>' +
    '<path d="M14 23 v10 M18 22.3 v10 M22 21.6 v10" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" transform="rotate(-10 20 28)"/>';

  const RULES = [
    { h: '목표', p: ['카드를 번갈아 내며 합계를 쌓습니다. 합계가 9를 넘게 만든 사람이 그 판을 집니다.', '진 사람은 판돈만큼 칩을 잃습니다. 칩이 다 떨어지면 탈락, 마지막까지 칩이 남은 사람이 승리합니다.'] },
    { h: '카드', p: ['카드는 0 · 1 · 2 · 3 네 종류, 각 10장으로 모두 40장입니다.', '각자 4장씩 받습니다. 손패는 본인만 봅니다.'] },
    { h: '차례에 할 일', p: ['손패에서 한 장을 가운데에 냅니다. 낸 수가 합계에 더해집니다.', '0은 합계를 올리지 않습니다. 합계가 9에 닿으면 0만이 안전합니다.', '낼 수 있는 카드가 없어도 한 장은 내야 합니다. 그때 넘기게 됩니다.'] },
    { h: '손패가 떨어지면', p: ['모두의 손패가 떨어질 때까지 아무도 넘기지 않았다면, 합계는 그대로 둔 채 남은 더미에서 4장씩 다시 받습니다.', '이때 판돈이 1 오릅니다. 오래 버틴 판일수록 잃는 것도 큽니다.'] },
    { h: '판돈', p: ['판마다 판돈은 1에서 시작합니다.', '카드를 낼 때 「판돈 올리기」를 켜면 판돈이 1 오릅니다. 한 판에 한 사람이 한 번만 쓸 수 있습니다.', '올림은 공개됩니다. 자신 있다는 신호일 수도, 허세일 수도 있습니다.', '칩은 가진 만큼만 잃습니다.'] },
    { h: '남은 카드 세기', p: ['한 벌은 다 쓸 때까지 판을 넘겨 가며 이어 씁니다. 판이 끝나면 남은 손패도 공개하고 버립니다.', '화면 아래 「남은」 칸은 내 패를 빼고 아직 나오지 않은 장수입니다. 0이 몇 장 남았는지가 승부를 가릅니다.', '더미가 모자라면 40장을 모두 모아 새로 섞습니다. 남은 장수도 처음으로 돌아갑니다.'] },
    { h: '선', p: ['첫 판의 차례는 무작위입니다(설정에서 자리 순서로 바꿀 수 있습니다).', '다음 판은 직전 판에서 진 사람부터 냅니다. 그 사람이 탈락했다면 다음 사람부터.'] },
    { h: '예시 한 판', p: ['둘이서, 합계 0에서 시작. 가의 손패는 0 · 2 · 3 · 3, 나의 손패는 0 · 1 · 1 · 2.', '가 3(합계 3) → 나 2(5) → 가 3(8) → 나 1(9).', '합계 9. 이제 0만 안전합니다. 가 0(9) → 나 0(9).', '가의 손에는 2만 남았습니다. 2를 내어 합계 11 — 가가 넘겼고, 판돈만큼 칩을 잃습니다.'] },
    { h: '조작', p: ['카드를 눌러 고르고, 「내기」를 누르거나 고른 카드를 한 번 더 누릅니다.', '넘기게 되는 카드는 어둡게, 「넘김」으로 표시됩니다.', 'PC: 1~4 카드 고르기, 스페이스 내기, R 판돈 올리기.'] },
    { h: '인원 · AI', p: ['2~4명. 한 폰으로 돌려 할 때는 차례마다 가림막이 손패를 가립니다.', 'AI 난이도는 자리마다 쉬움 · 보통 · 어려움으로 고를 수 있습니다. 어려움은 남은 카드를 세어 상대가 막힐 확률까지 따집니다.'] },
  ];

  L.register({
    id: ID, name: '님 타입 제로', tag: '카드 심리전', cat: '카드', hidden: true, undo: false,
    icon: ICON, tint: '#123a31', time: '5–10분',
    blurb: '0 · 1 · 2 · 3 카드를 번갈아 내어 합계를 쌓는다. 9를 넘기는 쪽이 진다. 남은 카드를 세는 사람이 이긴다.',
    quick: [
      '0~3 카드를 차례대로 한 장씩 내고, 낸 수를 합계에 더합니다.',
      '합계가 9를 넘게 만든 사람이 판돈만큼 칩을 잃습니다. 0은 합계를 올리지 않습니다.',
      '종류마다 10장뿐입니다. 남은 장수를 세어 상대의 손을 읽고, 마지막까지 칩을 지키면 승리.',
    ],
    rules: RULES,
    tutorial: [
      { text: '차례대로 카드를 한 장씩 냅니다. 낸 수는 합계에 더해지고, 합계가 9를 넘게 만든 사람이 판돈만큼 칩을 잃습니다.', sel: '.nz-tb' },
      { text: '손패는 4장. 0은 합계를 올리지 않는 카드입니다. 합계가 9에 닿은 뒤에는 0만이 안전합니다.', sel: '.nz-hand' },
      { text: '카드는 종류마다 10장뿐입니다. 내 패를 빼고 아직 나오지 않은 장수가 여기에 보입니다.', sel: '.nz-cnt' },
      { text: '자신이 있다면 카드를 내며 판돈을 올릴 수 있습니다. 한 판에 한 번, 모두에게 공개됩니다.', sel: '.nz-act' },
    ],
    options: [
      { id: 'chips', label: '시작 칩', tip: '칩이 다 떨어지면 탈락합니다. 많을수록 긴 승부.', choices: [{ v: 5, label: '5개 · 짧게' }, { v: 8, label: '8개' }, { v: 12, label: '12개 · 길게' }], def: 8 },
      { id: 'raise', label: '판돈 올리기', tip: '카드를 내며 판돈을 1 올립니다. 한 판에 한 사람 한 번.', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔' }], def: 'on' },
    ],
    controls: [
      { id: 'c1', label: '첫째 카드 고르기', keys: ['Digit1', 'Numpad1'] },
      { id: 'c2', label: '둘째 카드 고르기', keys: ['Digit2', 'Numpad2'] },
      { id: 'c3', label: '셋째 카드 고르기', keys: ['Digit3', 'Numpad3'] },
      { id: 'c4', label: '넷째 카드 고르기', keys: ['Digit4', 'Numpad4'] },
      { id: 'play', label: '고른 카드 내기', keys: ['Space'] },
      { id: 'up', label: '판돈 올리기', keys: ['KeyR'] },
    ],
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, aiDelay: 900,
    init, actor, apply, ai, aiDelayFor, result, hint, mount,
    panelInfo(s) { return [{ label: '판', value: String(s.rd) }, { label: '합계', value: s.tot + ' / 9' }, { label: '판돈', value: String(s.stake) }, { label: '더미', value: s.deck.length + '장' }]; },
    _t: { think, glance, unseenOf },
  });
})();
