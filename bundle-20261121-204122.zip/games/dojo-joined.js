(function () {
  'use strict';
  const L = (typeof window !== 'undefined' && window.Lounge) || {};
  const ID = 'dojo';
  const SEASONS = ['봄', '여름', '가을', '겨울'];
  const SEASON_HAN = ['春', '夏', '秋', '冬'];

  /* 능력 넷: 기(技, 기술) · 력(力, 힘) · 속(速, 빠르기) · 심(心, 마음) */
  const STATS = ['기', '력', '속', '심'];
  const STAT_HAN = ['技', '力', '速', '心'];
  const STAT_D = ['칼을 다루는 정확함. 받아치기와 허초에 쓰인다.', '칼에 실리는 힘과 버티는 몸. 선수에 쓰인다.',
    '발과 손의 빠르기. 선수와 허초에 쓰인다.', '흔들리지 않는 마음. 받아치기와 기다림에 쓰인다.'];

  /* 수 셋. 선은 허를, 후는 선을, 허는 후를 이긴다(a가 b를 이김 ⇔ b === (a + 2) % 3). */
  const STANCES = [
    { k: '선', han: '先', n: '선수', v: '먼저 친다', u: [2, 1], d: '상대보다 먼저 칼을 낸다. 받아치려 기다리는 상대에게는 막히고, 허초를 쓰는 상대는 먼저 벤다. 속·력을 쓴다.' },
    { k: '후', han: '後', n: '응수', v: '받아친다', u: [0, 3], d: '들어오는 칼을 받아 넘기고 친다. 선수에는 강하고, 허초에는 끌려 나온다. 기·심을 쓴다.' },
    { k: '허', han: '虛', n: '허초', v: '흘린다', u: [0, 2], d: '치는 척 흘려 상대의 응수를 끌어낸다. 응수에는 강하고, 곧장 들어오는 선수에는 늦는다. 기·속을 쓴다.' },
  ];
  const beats = (a, b) => b === (a + 2) % 3;
  const TARGETS = [['머리', '손목'], ['손목', '허리'], ['허리', '목 찌름']];

  /* 병기 다섯. mod = 수별 보정(선·후·허), 숙련에 비례(0.4 + 0.6 × 숙련/100). first = 첫 합에만 더하는 보정. */
  const WEAPONS = [
    { n: '장검', han: '長劍', role: '검객', mod: [3, 3, 3], d: '가장 흔한 길이의 양날 검. 어느 수에도 치우치지 않는다.' },
    { n: '쌍검', han: '雙劍', role: '쌍검수', mod: [9, -5, 4], d: '두 자루를 함께 쓴다. 먼저 치는 수에 강하고 받는 수에 약하다.' },
    { n: '창', han: '槍', role: '창잡이', mod: [2, 8, -4], d: '긴 자루로 거리를 쥔다. 받아치는 수에 강하고 흘리는 수에 둔하다.' },
    { n: '발도', han: '拔刀', role: '발도가', mod: [3, 3, -2], first: [11, 0, 0], d: '칼집에서 뽑는 한 번에 모든 것을 건다. 첫 합의 선수가 가장 무섭다.' },
    { n: '단검', han: '短劍', role: '단검잡이', mod: [-3, 4, 9], d: '짧은 칼로 파고든다. 허초와 받아치기에 능하고 정면 승부에 약하다.' },
  ];

  /* 기술: 숙련이 문턱(30·60·90)에 닿으면 저절로 익힌다. s = 수(−1이면 모든 수), c = 조건. */
  const TECH_C = { all: '언제나', first: '첫 합에서', after: '한 판을 딴 바로 다음 합에서', behind: '지고 있을 때', ahead: '앞서 있을 때', tie: '점수가 같을 때' };
  const TECHS = [
    { w: 0, m: 30, n: '정면 내려베기', s: 0, b: 4, c: 'all', d: '머리 위에서 곧게 내려친다. 가장 오래된 첫 동작.' },
    { w: 0, m: 60, n: '흘려 받기', s: 1, b: 5, c: 'all', d: '칼등으로 상대의 칼을 흘려보내고 그 틈에 들어간다.' },
    { w: 0, m: 90, n: '세 번 베기', s: -1, b: 5, c: 'behind', d: '밀릴 때 끊이지 않고 세 번을 잇는다.' },
    { w: 1, m: 30, n: '엇갈려 베기', s: 0, b: 4, c: 'all', d: '두 칼이 서로 다른 높이로 들어간다.' },
    { w: 1, m: 60, n: '이어 베기', s: 0, b: 7, c: 'after', d: '한 판을 딴 기세를 그대로 다음 칼에 싣는다.' },
    { w: 1, m: 90, n: '돌아 베기', s: 2, b: 6, c: 'all', d: '몸을 돌려 한 칼은 보이고 한 칼은 숨긴다.' },
    { w: 2, m: 30, n: '거리 재기', s: 2, b: 5, c: 'all', d: '창끝을 흔들어 상대의 걸음을 묶는다.' },
    { w: 2, m: 60, n: '꿰뚫기', s: 1, b: 5, c: 'all', d: '들어오는 상대를 창끝으로 맞이한다.' },
    { w: 2, m: 90, n: '휘감아 떨구기', s: 1, b: 6, c: 'behind', d: '상대의 칼을 감아 바닥으로 떨군다.' },
    { w: 3, m: 30, n: '한 줄기 빛', s: 0, b: 8, c: 'first', d: '뽑는 순간이 곧 베는 순간이다.' },
    { w: 3, m: 60, n: '칼집의 틈', s: 1, b: 5, c: 'after', d: '칼을 거둔 듯 보이는 순간에 다시 뽑는다.' },
    { w: 3, m: 90, n: '거꾸로 뽑기', s: 0, b: 6, c: 'behind', d: '칼날을 뒤로 하여 뽑아 상대의 짐작을 벗어난다.' },
    { w: 4, m: 30, n: '파고들기', s: 2, b: 4, c: 'all', d: '상대의 품 안으로 한 걸음 더 들어간다.' },
    { w: 4, m: 60, n: '손목 끊기', s: 1, b: 5, c: 'all', d: '칼을 쥔 손목만을 노린다.' },
    { w: 4, m: 90, n: '그림자 걸음', s: 2, b: 7, c: 'tie', d: '발소리 없이 옆으로 비켜 선다.' },
  ];

  /* 검풍(도장의 류파): sb = 수별 보정, tr = 효과가 1.2배인 수련, 그 밖의 특징 */
  const STYLES = [
    { n: '유수검', han: '流水', sb: [0, 5, 0], tr: 3, x: '', d: '물은 다투지 않고 이긴다. 받아치는 수를 높이 친다. 명상의 성과가 크다.' },
    { n: '뇌전검', han: '雷電', sb: [4, 0, 0], tr: 2, x: 'first', d: '먼저 닿는 칼이 이긴다. 선수가 강하고 첫 합에서 더 강하다. 단련의 성과가 크다.' },
    { n: '운무검', han: '雲霧', sb: [0, 0, 5], tr: 0, x: '', d: '보이는 칼은 미끼다. 허초를 높이 친다. 형 수련의 성과가 크다.' },
    { n: '반석검', han: '盤石', sb: [2, 2, 2], tr: 2, x: 'late', d: '흔들리지 않는 몸이 마지막에 남는다. 셋째 합부터 모든 수가 강해지고, 수련 중 잘 다치지 않는다.' },
    { n: '명경검', han: '明鏡', sb: [1, 1, 1], tr: 1, x: 'read', d: '맑은 거울은 상대를 비춘다. 시합에서 상대가 고른 수의 경향이 더 또렷하게 보이고, 대련의 성과가 크다.' },
  ];

  /* 수련 여섯: g = 능력별 성장 비율(기·력·속·심), ms = 숙련 성장, mo = 사기, lo = 충성, inj = 부상 확률 */
  const TRAIN = [
    { n: '형', han: '型', g: [1, 0, 0, 0.3], ms: 0.3, mo: -2, lo: 0, inj: 0, d: '정해진 동작을 수천 번 되풀이한다. 기가 오르고 심이 조금 오른다.' },
    { n: '대련', han: '對鍊', g: [0.5, 0, 0.6, 0], ms: 0.6, mo: -3, lo: 0, inj: 0.08, d: '실제로 맞서 겨룬다. 기·속과 숙련이 오르지만 다치기 쉽고 지친다.' },
    { n: '단련', han: '鍛鍊', g: [0, 1, 0.4, 0], ms: 0, mo: -3, lo: 0, inj: 0.05, d: '바위를 지고 산길을 오른다. 력과 속이 오른다. 조금 다치기 쉽다.' },
    { n: '명상', han: '瞑想', g: [0, 0, 0, 1], ms: 0, mo: 6, lo: 2, inj: 0, d: '새벽마다 앉아 숨을 고른다. 심과 사기, 충성이 오른다.' },
    { n: '병기', han: '兵器', g: [0.2, 0, 0, 0], ms: 2.4, mo: -1, lo: 0, inj: 0.02, d: '제 병기만을 붙들고 다룬다. 숙련이 크게 올라 기술을 익힌다.' },
    { n: '휴식', han: '休息', g: [0, 0, 0, 0], ms: 0, mo: 12, lo: 1, inj: 0, d: '마루를 떠나 쉰다. 사기가 크게 오르고 부상이 빨리 낫는다.' },
  ];

  /* 시설 넷. 단계 0~3, 단계를 올리는 값은 FAC_COST[다음 단계] */
  const FAC = [
    { n: '수련장', han: '道場', d: '제자가 설 마루. 단계마다 정원이 2명, 모든 수련 성과가 5% 늘어난다.', e: (v) => '정원 ' + cap(v) + '명' + (v ? ' · 수련 +' + (v * 5) + '%' : '') },
    { n: '목욕간', han: '浴間', d: '지친 몸을 푸는 곳. 단계마다 부상 위험이 줄고, 부상이 빨리 낫고, 사기가 오른다.', e: (v) => (v ? '부상 위험 −' + (v * 20) + '% · 사기 +' + (v * 2) + '/계절' : '효과 없음') },
    { n: '서고', han: '書庫', d: '오래된 검보를 모아 둔 방. 형과 명상의 성과가 늘고, 1단계부터 제자의 성장 곡선이 곧바로 보인다.', e: (v) => (v ? '형·명상 +' + (v * 15) + '% · 성장 곡선 보임' : '효과 없음') },
    { n: '대장간', han: '鍛冶', d: '칼을 벼리고 손보는 곳. 병기 수련 성과가 늘고, 시합 때 병기의 힘이 오른다.', e: (v) => (v ? '병기 수련 +' + (v * 20) + '% · 시합 힘 +' + v : '효과 없음') },
  ];
  const FAC_COST = [0, 24, 42, 66];
  const cap = (lv) => 3 + 2 * lv;

  /* 성장 곡선: f(n) = n번째 수련 계절의 성장 배율, pot = 잠재력 보정 */
  const CURVES = [
    { n: '조숙', han: '早熟', pot: -4, d: '일찍 피고 일찍 멈춘다. 처음 여섯 계절 동안 빠르게 오른다.' },
    { n: '대기만성', han: '晩成', pot: 8, d: '늦게 트이지만 끝이 높다. 처음 여섯 계절은 더디고, 셋째 해부터 크게 오른다.' },
    { n: '정체형', han: '停滯', pot: -10, d: '빠르게 오르다가 어느 선에서 멈춘다. 다섯 계절 뒤로는 거의 오르지 않는다.' },
    { n: '꾸준함', han: '恒常', pot: 0, d: '해마다 비슷하게 오른다.' },
  ];
  const curveF = (c, n) => c === 0 ? (n < 6 ? 1.55 : n < 12 ? 0.75 : 0.35) : c === 1 ? (n < 6 ? 0.5 : n < 12 ? 1.15 : 1.6) : c === 2 ? (n < 5 ? 1.45 : 0.25) : 1;

  /* 성향: pref = 즐겨 쓰는 수(−1 없음). 즐겨 쓰는 수를 고르면 힘 +3. */
  const TEMPERS = [
    { n: '성급함', pref: 0, d: '먼저 치고 싶어 한다. 선수를 즐겨 쓰고, 이기고 지는 데 따라 사기가 크게 흔들린다.' },
    { n: '신중함', pref: 1, d: '상대가 먼저 움직이기를 기다린다. 응수를 즐겨 쓴다.' },
    { n: '꾀가 많음', pref: 2, d: '정면으로 부딪치지 않는다. 허초를 즐겨 쓴다.' },
    { n: '침착함', pref: -1, d: '어느 수에도 치우치지 않는다. 지고 있어도 흔들리지 않는다.' },
    { n: '오만함', pref: 0, d: '제 실력을 안다. 가장 강한데도 시합에 나가지 못하면 충성이 크게 떨어진다.' },
    { n: '충직함', pref: -1, d: '한번 정한 스승을 쉽게 떠나지 않는다. 충성이 잘 떨어지지 않는다.' },
    { n: '변덕스러움', pref: -1, d: '어느 수가 나올지 저도 모른다. 사기가 오르내림이 크다.' },
    { n: '승부욕', pref: -1, d: '지고 있을 때 더 강해진다. 도장이 약하면 떠날 생각을 한다.' },
  ];

  /* 재능: g = 능력별 성장 배율, ms = 숙련 배율, inj = 부상 배율, duel = 시합 힘, big = 큰 무대(천하 대회·도장 깨기) 힘 */
  const TALENTS = [
    { n: '없음', d: '눈에 띄는 재능은 없다.' },
    { n: '타고난 눈', g: [1.35, 1, 1, 1], d: '기가 빨리 오른다.' },
    { n: '강골', g: [1, 1.35, 1, 1], inj: 0.6, d: '력이 빨리 오르고 잘 다치지 않는다.' },
    { n: '바람 같은 발', g: [1, 1, 1.35, 1], d: '속이 빨리 오른다.' },
    { n: '고요한 마음', g: [1, 1, 1, 1.35], mof: 35, d: '심이 빨리 오르고, 사기가 35 아래로 잘 내려가지 않는다.' },
    { n: '손이 빠름', ms: 1.5, d: '숙련이 빨리 올라 기술을 일찍 익힌다.' },
    { n: '실전 감각', duel: 3, d: '시합에서 모든 수의 힘 +3.' },
    { n: '큰 무대 체질', big: 5, d: '천하 대회와 도장 깨기에서 모든 수의 힘 +5.' },
    { n: '약한 몸', inj: 1.8, d: '남보다 잘 다친다.' },
    { n: '게으름', g: [0.75, 0.75, 1, 1], d: '형과 단련의 성과가 적다.' },
  ];

  /* 이름 조각 — 사람 이름 없이, 내력·모습·버릇으로 부른다 */
  const EPI_A = ['늦깎이', '말 없는', '장터 출신', '외눈의', '왼손잡이', '대장간집', '뱃사공 출신', '절에서 온', '몰락한 집안의', '키 큰',
    '눈 밝은', '성미 급한', '웃지 않는', '북방에서 온', '바닷가', '산골', '서생 출신', '상처 많은', '흰 띠의', '붉은 끈의',
    '맨발의', '떠돌던', '과묵한', '마을 어귀의', '나무꾼 출신', '소금 장수 집', '글 읽던', '역참 출신', '약초꾼', '머리 짧은',
    '검은 소매의', '흉터 있는', '셋째 아들', '고아 출신', '부잣집', '어부 집', '늦게 일어나는', '목소리 큰', '손 큰', '그림 그리던',
    '절름발이였던', '피리 부는', '비단 장수 집', '관아 하인 출신', '먼 길 온', '등 굽은', '눈썹 짙은', '손가락 긴', '말수 적은', '나룻가'];
  const EPI_B = ['수련생', '제자', '젊은이', '문하생', '아이', '떠돌이'];
  const NPC_DOJOS = ['청류관', '흑풍당', '백학문', '철산관', '월하당', '송운문', '적양관', '무영당', '홍엽관', '한설문', '금강관', '운산당', '석등관', '현무당', '은월문', '녹수관'];
  const MASTERS = ['외팔의 노검객', '눈먼 사범', '붉은 소매의 사범', '돌부처 사범', '말 없는 창술가', '늙은 발도가', '백발의 여사범', '칼자국의 사범',
    '떠돌다 돌아온 사범', '무관 출신 사범', '절에서 내려온 사범', '젊은 사범', '진 적 없는 사범', '술 끊은 사범', '북방의 노장', '목소리 낮은 사범'];
  const OUTSIDERS = ['북방의', '남쪽 항구의', '관동의', '변방의', '도성의', '산사의', '이름 없는', '유랑하는', '섬에서 온', '국경의', '고갯마루의', '강 건너'];

  const josa = (w, a, b) => { const c = String(w || '').charCodeAt(String(w || '').length - 1); return c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b; };
  const roJ = (w) => { const t = String(w == null ? '' : w), c = t.charCodeAt(t.length - 1), k = c >= 0xac00 && c <= 0xd7a3 ? (c - 0xac00) % 28 : /[036]$/.test(t) ? 1 : 0; return k && k !== 8 ? '으로' : '로'; };   // 받침(ㄹ 제외) 뒤 '으로' · 숫자 0·3·6도

  /* 명성 → 도장의 이름값 */
  const FAME = [[0, '이름 없는 도장'], [40, '동네 도장'], [90, '고을에 알려진 도장'], [160, '이름난 도장'], [260, '명문'], [400, '천하의 명문']];
  const fameOf = (r) => { let t = FAME[0][1]; for (const [v, n] of FAME) if (r >= v) t = n; return t; };

  /* 칭호(맨 위부터 맞는 것 하나) — d = 끝난 도장, n = 판 길이(년) */
  const TITLES = [
    { n: '천하제일 도장', c: (d) => d.rec.nw >= 2, t: '두 번의 천하 대회를 가져간 이름은 오래 남는다. 도성의 무관들이 이 마루를 찾아오기 시작했다.' },
    { n: '천하에 이름을 올린 도장', c: (d) => d.rec.nw >= 1, t: '도성에서 열린 시합의 마지막 자리에 이 도장의 제자가 서 있었다. 쇠락했다는 말은 이제 아무도 하지 않는다.' },
    { n: '현판을 모은 도장', c: (d) => d.sb.length >= 2, t: '마루 벽에 남의 현판이 여럿 걸렸다. 두려워하는 이도, 노리는 이도 늘었다.' },
    { n: '고을의 패자', c: (d, n) => d.rec.rw >= Math.max(2, Math.ceil(n / 2)), t: '가을이면 고을 사람들은 이 도장의 제자가 우승할 것이라 여긴다. 그 짐작이 틀린 해는 드물었다.' },
    { n: '명검을 길러 낸 도장', c: (d) => d.rec.best >= 80, t: '제자 하나가 스승을 넘어섰다. 도장의 이름보다 그 제자의 이름이 먼저 불린다.' },
    { n: '다시 일어선 도장', c: (d) => d.rep >= 150, t: '비가 새던 마루에 다시 발소리가 가득하다. 문 앞을 기웃거리는 아이들이 늘었다.' },
    { n: '사람이 남는 도장', c: (d) => d.rec.left === 0 && d.ds.length >= 4, t: '떠난 제자가 하나도 없었다. 우승기보다 귀한 것을 지켰다고 말하는 이들도 있다.' },
    { n: '현판을 잃은 도장', c: (d) => d.lost >= 0, t: '현판이 걸려 있던 자리에 못 자국만 남았다. 남은 제자들은 그 자리를 오래 바라본다.' },
    { n: '조용히 버틴 도장', c: (d) => d.rep >= 60, t: '크게 이름을 떨치지는 못했으나 문을 닫지도 않았다. 마루는 여전히 아침마다 닦인다.' },
    { n: '이름만 남은 도장', c: () => true, t: '현판은 그대로 걸려 있다. 다만 그 이름을 기억하는 이가 많지 않다.' },
  ];

  /* 작은 그림(직접 그린 벡터, CC0) — 24×24 viewBox, currentColor 선 */
  const ICON = {
    sword: '<path d="M5 19 L17 7 M15 5 L19 9 M7 15 L9 17 M4 20 L6 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    dual: '<path d="M4 18 L15 7 M9 18 L20 7 M13 5 L17 9 M18 5 L22 9" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    spear: '<path d="M3 21 L18 6 M18 6 L21 3 L20 8 Z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/>',
    draw: '<path d="M4 19 L13 10 M13 10 L19 4 M10 13 L14 17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M5 20 L10 15" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" opacity=".55"/>',
    knife: '<path d="M7 17 L15 9 M13 7 L17 11 M6 18 L8 20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
    coin: '<circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="1.6"/><rect x="9.5" y="9.5" width="5" height="5" fill="none" stroke="currentColor" stroke-width="1.4"/>',
    seal: '<rect x="5" y="5" width="14" height="14" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M9 9h6M9 12h6M9 15h6" stroke="currentColor" stroke-width="1.3"/>',
    hall: '<path d="M3 10 L12 4 L21 10 M5 10 V19 H19 V10 M10 19 V14 H14 V19" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    bath: '<path d="M4 13 H20 V16 Q20 19 17 19 H7 Q4 19 4 16 Z M8 10 Q7 8 8 6 M12 10 Q11 8 12 6 M16 10 Q15 8 16 6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
    book: '<path d="M4 6 Q8 4 12 6 Q16 4 20 6 V18 Q16 16 12 18 Q8 16 4 18 Z M12 6 V18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    forge: '<path d="M4 14 H17 L20 11 H14 V9 H6 Q4 9 4 11 Z M8 14 V18 M14 14 V18 M6 18 H16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    person: '<circle cx="12" cy="7" r="3" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M6 20 Q6 12 12 12 Q18 12 18 20" fill="none" stroke="currentColor" stroke-width="1.6"/>',
    scroll: '<path d="M6 5 H17 V17 Q17 20 14 20 H6 Q9 20 9 17 V8 Q9 5 6 5 Q3 5 3 8 H9" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/>',
    flag: '<path d="M6 21 V4 M6 4 H18 L15 8 L18 12 H6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
    hand: '<path d="M7 20 V11 M7 11 Q12 9 17 11 V16 Q17 20 13 20 H7 M10 10 V5 M13 10 V4 M16 11 V6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>',
    door: '<path d="M5 20 V5 H19 V20 M3 20 H21 M12 5 V20" fill="none" stroke="currentColor" stroke-width="1.6"/>',
  };
  const W_ICON = ['sword', 'dual', 'spear', 'draw', 'knife'];
  const F_ICON = ['hall', 'bath', 'book', 'forge'];
  const svgI = (k, sz) => '<svg viewBox="0 0 24 24" width="' + (sz || 20) + '" height="' + (sz || 20) + '" aria-hidden="true">' + (ICON[k] || '') + '</svg>';
  const R = Math.random;
  const ri = (n) => Math.floor(R() * n);
  const pick = (a) => a[ri(a.length)];
  const chance = (p) => R() < p;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const avg = (a) => a.reduce((x, y) => x + y, 0) / (a.length || 1);
  const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = ri(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const tOf = (s) => (s.yr - 1) * 4 + s.se;
  const rating = (d) => Math.round(avg(d.st) + (d.m || 0) * 0.06);
  const healthy = (dj) => dj.ds.filter((d) => !d.inj && !d.away);
  const byRating = (a) => a.slice().sort((x, y) => rating(y) - rating(x));
  const findD = (dj, id) => dj.ds.find((d) => d.id === id) || null;
  const capOf = (dj) => cap(dj.fac[0]);
  const techsOf = (f) => TECHS.filter((T) => T.w === f.w && (f.m || 0) >= T.m);

  /* ---------------- 이름 · 제자 ---------------- */
  function epithet(s, w) {
    for (let k = 0; k < 40; k++) {
      const a = pick(EPI_A), b = chance(0.58) ? WEAPONS[w].role : pick(EPI_B);
      const n = a + ' ' + b;
      if (!s.used.includes(n)) { s.used.push(n); if (s.used.length > 120) s.used.splice(0, 30); return n; }
    }
    return pick(EPI_A) + ' ' + WEAPONS[w].role + ' ' + (s.nid % 9 + 1);
  }
  /* q: 0~1 바탕 자질. o.age · o.w · o.lift(현재 능력 보정) */
  function genDisc(s, q, o) {
    o = o || {};
    const age = o.age || 13 + ri(14);
    const w = o.w != null ? o.w : ri(5);
    const cv = ri(4), tp = ri(8), ta = chance(0.6) ? 1 + ri(TALENTS.length - 1) : 0;
    const base = 52 + q * 34 + CURVES[cv].pot;
    const pot = STATS.map(() => clamp(Math.round(base + R() * 18 - 9), 38, 99));
    const grown = Math.min(1, (age - 13) / 14);
    const st = pot.map((p) => r1(clamp(p * (0.26 + 0.12 * R() + grown * 0.2) + (o.lift || 0), 8, p)));
    return { id: s.nid++, n: o.n || epithet(s, w), age, w, st, pot, m: Math.round(4 + R() * 16 + (age - 13) * 1.4), cv, tp, ta,
      mo: 55 + ri(20), lo: o.lo || 45 + ri(25), inj: 0, ex: 0, wn: 0, ls: 0, rv: 0, tr: 0, nt: o.nt || 0 };
  }
  function genMaster(s, n, lvl) {
    const w = ri(5), age = 52 + ri(12);
    const b = 50 + lvl * 6 + R() * 6;
    return { n, age, w, st: STATS.map(() => r1(clamp(b + R() * 12 - 6, 30, 95))), pot: [99, 99, 99, 99], m: 70 + ri(25), cv: 3, tp: ri(8), ta: 0, mo: 60, lo: 100, inj: 0, ex: 40, wn: 0, ls: 0, rv: 1 };
  }
  function habits() {
    return { agg: r1(0.15 + R() * 0.7), thr: r1(0.2 + R() * 0.6), care: r1(0.2 + R() * 0.6), show: r1(R()), sty: ri(5), fac: [R(), R(), R(), R()].map(r1), fw: ri(5) };
  }
  const freshRec = (rep) => ({ rw: 0, nw: 0, cw: 0, cl: 0, best: 0, left: 0, peak: rep, sr: rep });

  /* ---------------- 시작 ---------------- */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const yrs = clamp(+opts.len || 5, 2, 8);
    const total = clamp(Math.max(n + 2, +opts.city || 6), 4, 8);
    const s = { v: 1, yr: 1, se: 0, len: yrs, n, ph: 'plan', seq: 0, nid: 1,
      pn: players.map((p) => p.name), ai: players.map((p) => !!p.ai), lv: players.map((p) => (p.ai ? p.lv || 2 : 2)),
      hab: players.map(habits), dm: opts.duel === 'auto' ? 1 : 0,
      dj: [], pl: players.map(() => null), mq: [], B: null, news: [], bl: [], last: { id: 0 }, used: [], semi: [] };
    const names = shuffle(NPC_DOJOS.slice()), masters = shuffle(MASTERS.slice());
    const T = yrs * 4;
    for (let i = 0; i < total; i++) {
      const own = i < n ? i : -1;
      const lvl = own >= 0 ? 0 : 1 + (i % 3);
      const dj = { nm: names[i], own, st: own >= 0 ? -1 : ri(5), mst: genMaster(s, own >= 0 ? '늙은 사범' : masters[i], own >= 0 ? 0 : lvl),
        ds: [], rep: own >= 0 ? 12 : 20 + lvl * 18 + ri(15), $: 40, fac: own >= 0 ? [1, 0, 0, 0] : [lvl, lvl - 1, lvl - 1, lvl - 1], pat: 0,
        sb: [], lost: -1, lvl, agg: r1(0.2 + R() * 0.6), cd: {}, cand: [], ev: null, rp: [], gone: [], rec: null, sx: -1, fw: ri(5) };
      if (own >= 0) {
        dj.mst.age = 60 + ri(5);
        dj.ds.push(genDisc(s, 0.25, { age: 24 + ri(5), lift: 6 }));
        dj.ds.push(genDisc(s, 0.45, { age: 14 + ri(3) }));
        dj.sx = Math.round(T * 0.5) + ri(3);
      } else {
        const k = 3 + lvl - (total > 6 ? 1 : 0);
        for (let j = 0; j < k; j++) dj.ds.push(genDisc(s, 0.2 + lvl * 0.1 + R() * 0.15, { w: chance(0.6) ? dj.fw : ri(5), lift: 2 + lvl * 3 + ri(5), age: 17 + ri(12) }));
      }
      dj.rec = freshRec(dj.rep);
      s.dj.push(dj);
    }
    startSeason(s, true);
    return s;
  }

  /* ---------------- 계절 시작: 입문자 · 사건 ---------------- */
  function genCands(s, dj) {
    const k = s.se === 0 ? 3 : 2;
    const q0 = clamp(0.2 + dj.rep / 350, 0.2, 0.85);
    dj.cand = [];
    for (let i = 0; i < k; i++) dj.cand.push(genDisc(s, clamp(q0 + R() * 0.4 - 0.1, 0, 1)));
  }
  function startSeason(s, first) {
    const t = tOf(s);
    s.pl = s.pl.map(() => null);
    s.ph = 'plan';
    for (const dj of s.dj) {
      if (dj.own < 0) continue;
      genCands(s, dj);
      dj.ev = first ? null : genEvent(s, dj, t);
    }
  }
  function genEvent(s, dj, t) {
    if (dj.sx >= 0 && t >= dj.sx && dj.ds.length) return { k: 'retire' };
    // 다른 도장의 도전장: 강한 도장일수록, 현판을 가진 도장일수록 자주
    if (t >= 3 && chance(0.16)) {
      const npcs = s.dj.map((x, i) => i).filter((i) => s.dj[i].own < 0 && healthy(s.dj[i]).length >= 2);
      if (npcs.length) {
        const holder = npcs.find((i) => dj.sb.includes(i));
        const x = holder != null && chance(0.6) ? holder : pick(npcs);
        return { k: 'chal', x };
      }
    }
    if (!chance(0.55)) return null;
    const ok = EVENTS.filter((E) => E.op && E.k !== 'chal' && (!E.ok || E.ok(s, dj)) && (!E.need || healthy(dj).length >= E.need) && (!E.npc || npcList(s).length) && !(dj.evh || []).includes(E.k));
    if (!ok.length) return null;
    const tot = ok.reduce((a, E) => a + (E.w || 1), 0);
    let r = R() * tot, E = ok[0];
    for (const e of ok) { r -= e.w || 1; if (r <= 0) { E = e; break; } }
    const ev = { k: E.k };
    dj.evh = (dj.evh || []).concat(E.k).slice(-3);   // 같은 사건이 잇달아 나오지 않게
    if (E.need) {
      const pool = shuffle(healthy(dj).slice());
      if (E.pickA) pool.sort(E.pickA);
      ev.a = pool[0].id; if (E.need > 1) ev.b = pool[1].id;
    }
    if (E.npc) { const npcs = s.dj.map((x, i) => i).filter((i) => s.dj[i].own < 0); ev.x = pick(npcs); }
    if (E.k === 'returnee') ev.g = dj.gone.length - 1;
    return ev;
  }

  /* ---------------- 사건 ---------------- */
  const nmOf = (dj, id) => { const d = findD(dj, id); return d ? d.n : '그 제자'; };
  const each = (dj, f) => dj.ds.forEach(f);
  const bump = (d, k, v) => { d[k] = clamp(Math.round(d[k] + v), 0, 100); };
  const addSt = (d, i, v) => { d.st[i] = r1(clamp(d.st[i] + v, 0, Math.max(d.pot[i], d.st[i]))); };
  function leave(s, dj, d, why, toNpc) {
    dj.ds = dj.ds.filter((x) => x !== d);
    dj.rec.left++;
    if (toNpc != null && toNpc >= 0) {
      const o = s.dj[toNpc];
      const nd = JSON.parse(JSON.stringify(d)); nd.lo = 60; nd.mo = 60; nd.inj = 0; nd.away = 0; nd.bt = dj.nm;
      if (o.ds.length < 7) o.ds.push(nd);
      rp(dj, d.n + josa(d.n, '은', '는') + ' ' + o.nm + roJ(o.nm) + ' 갔다. ' + why);
      news(s, dj.nm + '의 ' + d.n + josa(d.n, '이', '가') + ' ' + o.nm + roJ(o.nm) + ' 옮겼다.');
    } else {
      rp(dj, d.n + josa(d.n, '이', '가') + ' 도장을 떠났다. ' + why);
      dj.gone.push(JSON.parse(JSON.stringify(d))); if (dj.gone.length > 3) dj.gone.shift();
    }
  }
  const rp = (dj, line) => { if (dj.own >= 0) { dj.rp.push(line); if (dj.rp.length > 40) dj.rp.shift(); } };
  const news = (s, line) => { s.news.push(SEASONS[s.se] + ' · ' + line); if (s.news.length > 16) s.news.shift(); };
  const npcList = (s) => s.dj.map((x, i) => i).filter((i) => s.dj[i].own < 0);

  const EVENTS = [
    { k: 'quarrel', h: '두 제자의 다툼', need: 2, w: 1.2,
      tx: (s, dj, e) => nmOf(dj, e.a) + josa(nmOf(dj, e.a), '과', '와') + ' ' + nmOf(dj, e.b) + josa(nmOf(dj, e.b), '이', '가') + ' 수련 방식을 두고 언성을 높였다. 마루의 공기가 무겁다.',
      op: [
        { t: (s, dj, e) => nmOf(dj, e.a) + '의 편을 든다', h: '한쪽의 충성이 오르고, 다른 쪽은 충성과 사기가 떨어진다',
          fx(s, dj, e) { const a = findD(dj, e.a), b = findD(dj, e.b); if (a) bump(a, 'lo', 12); if (b) { bump(b, 'lo', -12); bump(b, 'mo', -8); } rp(dj, '한쪽 편을 들었다. 마루에 남은 침묵이 길다.'); },
          ai: (s, dj, e) => { const a = findD(dj, e.a), b = findD(dj, e.b); return a && b ? (rating(a) - rating(b)) / 6 - (b.lo < 40 ? 4 : 0) : 0; } },
        { t: () => '둘 다 꾸짖는다', h: '둘의 사기가 떨어지고 충성은 조금 오른다',
          fx(s, dj, e) { [e.a, e.b].forEach((id) => { const d = findD(dj, id); if (d) { bump(d, 'mo', -6); bump(d, 'lo', 4); } }); rp(dj, '둘을 함께 꾸짖었다. 둘은 말없이 마루를 닦았다.'); }, ai: () => 1 },
        { t: () => '대련으로 가린다', h: '이긴 쪽은 사기가 오르고 진 쪽은 떨어진다. 다칠 수도 있다',
          fx(s, dj, e) { const a = findD(dj, e.a), b = findD(dj, e.b); if (!a || !b) return; const [w, l] = rating(a) + R() * 12 > rating(b) + R() * 12 ? [a, b] : [b, a];
            bump(w, 'mo', 8); bump(l, 'mo', -8); addSt(w, 0, 1); addSt(l, 0, 1); if (chance(0.15)) l.inj = 1;
            rp(dj, '대련 끝에 ' + w.n + josa(w.n, '이', '가') + ' 이겼다.' + (l.inj ? ' ' + l.n + josa(l.n, '은', '는') + ' 팔을 다쳤다.' : '')); }, ai: () => 0.5 },
      ] },
    { k: 'wanderer', h: '떠돌이 무사', w: 1,
      tx: () => '비에 젖은 떠돌이 무사가 하룻밤 묵기를 청했다. 칼집이 오래 닳아 있다.',
      op: [
        { t: () => '재워 준다', h: '냥 −3 · 제자 하나가 가르침을 얻는다 · 명성이 조금 오른다',
          fx(s, dj) { dj.$ -= 3; dj.rep += 2; const d = pick(dj.ds); if (d) { addSt(d, 0, 2); d.m = Math.min(100, d.m + 6); rp(dj, '떠돌이 무사는 새벽에 ' + d.n + '에게 칼 잡는 법 하나를 일러 주고 떠났다.'); } }, ai: (s, dj) => (dj.$ > 10 ? 3 : -1) },
        { t: () => '돌려보낸다', h: '아무 일도 없다', fx(s, dj) { rp(dj, '떠돌이 무사는 말없이 빗속으로 돌아갔다.'); }, ai: () => 0 },
      ] },
    { k: 'merchant', h: '상인 조합의 청', w: 1,
      tx: () => '상인 조합이 잔칫날 검무를 청해 왔다. 사례는 넉넉하나, 도장의 격을 낮춘다는 말도 돈다.',
      op: [
        { t: () => '받아들인다', h: '냥 +14 · 명성 −4', fx(s, dj) { dj.$ += 14; dj.rep = Math.max(0, dj.rep - 4); rp(dj, '잔칫상 앞에서 검무를 추었다. 사례는 두둑했다.'); }, ai: (s, dj) => (dj.$ < 25 ? 6 : 2) - dj.rep / 80 },
        { t: () => '거절한다', h: '명성 +2', fx(s, dj) { dj.rep += 2; rp(dj, '정중히 거절했다. 고을에 말이 돌았다.'); }, ai: () => 1.5 },
      ] },
    { k: 'hidden', h: '숨긴 부상', need: 1, w: 1,
      tx: (s, dj, e) => nmOf(dj, e.a) + josa(nmOf(dj, e.a), '이', '가') + ' 발목을 절면서도 수련을 쉬지 않는다.',
      op: [
        { t: () => '쉬게 한다', h: '이번 계절 휴식 · 사기가 조금 떨어진다', fx(s, dj, e) { const d = findD(dj, e.a); if (d) { d.fr = 1; bump(d, 'mo', -3); rp(dj, d.n + '에게 쉬라고 일렀다.'); } }, ai: () => 2 },
        { t: () => '모른 척한다', h: '크게 다칠 수도, 버텨 낼 수도 있다',
          fx(s, dj, e) { const d = findD(dj, e.a); if (!d) return; if (chance(0.5)) { d.inj = 2; rp(dj, d.n + '의 발목이 끝내 꺾였다.'); } else { bump(d, 'lo', 6); bump(d, 'mo', 6); rp(dj, d.n + josa(d.n, '은', '는') + ' 끝내 버텨 냈다.'); } }, ai: (s, dj) => (s.hab[dj.own] ? s.hab[dj.own].care < 0.4 ? 1.5 : 0 : 0) },
      ] },
    { k: 'escort', h: '관아의 호위 의뢰', need: 1, w: 1,
      tx: () => '관아에서 호송길의 호위를 구한다. 제자 한 명을 보내면 값을 치르겠다고 한다.',
      op: [
        { t: (s, dj, e) => nmOf(dj, e.a) + josa(nmOf(dj, e.a), '을', '를') + ' 보낸다', h: '냥 +12 · 이번 계절 그 제자의 수련 없음 · 실전 경험 · 다칠 수 있다',
          fx(s, dj, e) { const d = findD(dj, e.a); if (!d) return; dj.$ += 12; d.away = 1; addSt(d, 0, 1); addSt(d, 2, 1); d.m = Math.min(100, d.m + 4); if (chance(0.2)) d.inj = 1;
            rp(dj, d.n + josa(d.n, '이', '가') + ' 호송길에서 돌아왔다.' + (d.inj ? ' 어깨에 상처가 있었다.' : '')); }, ai: (s, dj) => (dj.$ < 30 ? 5 : 1.5) },
        { t: () => '거절한다', h: '아무 일도 없다', fx() {}, ai: () => 1 },
      ] },
    { k: 'roof', h: '낡은 지붕', w: 0.8,
      tx: () => '장마가 지나자 마루 위 지붕이 내려앉기 시작했다.',
      op: [
        { t: () => '고친다', h: '냥 −10', fx(s, dj) { dj.$ -= 10; rp(dj, '지붕을 고쳤다.'); }, ai: (s, dj) => (dj.$ >= 14 ? 3 : -2) },
        { t: () => '미룬다', h: '모든 제자의 사기 −6', fx(s, dj) { each(dj, (d) => bump(d, 'mo', -6)); rp(dj, '빗물이 마루에 고였다. 제자들의 낯빛이 어둡다.'); }, ai: () => 1 },
      ] },
    { k: 'manual', h: '검보 매물', w: 0.8,
      tx: () => '고서점에 오래된 검보 한 권이 나왔다. 값이 만만치 않다.',
      op: [
        { t: () => '사들인다', h: '냥 −14 · 모든 제자의 기 +1, 숙련 +4', fx(s, dj) { dj.$ -= 14; each(dj, (d) => { addSt(d, 0, 1); d.m = Math.min(100, d.m + 4); }); rp(dj, '검보를 들였다. 밤마다 등잔불 아래 제자들이 모였다.'); }, ai: (s, dj) => (dj.$ >= 22 ? dj.ds.length * 0.9 : -3) },
        { t: () => '넘긴다', h: '아무 일도 없다', fx() {}, ai: () => 1 },
      ] },
    { k: 'homecall', h: '고향의 부름', need: 1, w: 0.9,
      tx: (s, dj, e) => nmOf(dj, e.a) + '의 집에서 기별이 왔다. 가세가 기울어 돌아와 일을 도우라는 것이다.',
      op: [
        { t: () => '돈을 보태 붙잡는다', h: '냥 −10 · 그 제자의 충성이 크게 오른다', fx(s, dj, e) { const d = findD(dj, e.a); dj.$ -= 10; if (d) { bump(d, 'lo', 18); rp(dj, d.n + josa(d.n, '은', '는') + ' 남기로 했다.'); } },
          ai: (s, dj, e) => { const d = findD(dj, e.a); return d && dj.$ >= 14 ? rating(d) / 10 : -2; } },
        { t: () => '보내 준다', h: '그 제자가 떠난다 · 명성 +3', fx(s, dj, e) { const d = findD(dj, e.a); dj.rep += 3; if (d) { leave(s, dj, d, '고향으로 돌아갔다.'); dj.rec.left--; } }, ai: () => 2 },
      ] },
    { k: 'poach', h: '다른 도장의 회유', need: 1, npc: 1, w: 1, pickA: (a, b) => rating(b) - rating(a),
      tx: (s, dj, e) => s.dj[e.x].nm + '에서 ' + nmOf(dj, e.a) + '에게 사람을 보냈다. 더 나은 대우를 약속했다고 한다.',
      op: [
        { t: () => '대우를 올린다', h: '냥 −8 · 그 제자의 충성이 크게 오른다', fx(s, dj, e) { const d = findD(dj, e.a); dj.$ -= 8; if (d) { bump(d, 'lo', 18); rp(dj, d.n + josa(d.n, '은', '는') + ' 남겠다고 했다.'); } },
          ai: (s, dj, e) => { const d = findD(dj, e.a); return d && dj.$ >= 10 ? rating(d) / 8 - d.lo / 20 : -2; } },
        { t: () => '그냥 둔다', h: '충성이 낮으면 떠날 수 있다', fx(s, dj, e) { const d = findD(dj, e.a); if (!d) return; if (d.lo < 50 && chance(0.8 - d.lo / 100)) leave(s, dj, d, '회유에 넘어갔다.', e.x); else { bump(d, 'lo', 6); rp(dj, d.n + josa(d.n, '은', '는') + ' 사람을 돌려보냈다.'); } },
          ai: (s, dj, e) => { const d = findD(dj, e.a); return d ? (d.lo - 45) / 6 : 0; } },
      ] },
    { k: 'brawl', h: '장터의 소란', need: 1, w: 0.9,
      tx: (s, dj, e) => nmOf(dj, e.a) + josa(nmOf(dj, e.a), '이', '가') + ' 장터에서 시비 끝에 칼을 뽑았다. 다친 사람은 없으나 소문이 빠르다.',
      op: [
        { t: () => '엄하게 꾸짖는다', h: '그 제자의 사기 −10 · 명성 +1', fx(s, dj, e) { const d = findD(dj, e.a); if (d) bump(d, 'mo', -10); dj.rep += 1; rp(dj, '엄하게 꾸짖었다.'); }, ai: () => 1.5 },
        { t: () => '감싼다', h: '명성 −5 · 그 제자의 충성 +10', fx(s, dj, e) { const d = findD(dj, e.a); if (d) bump(d, 'lo', 10); dj.rep = Math.max(0, dj.rep - 5); rp(dj, '제자를 감쌌다. 고을의 눈길이 차가워졌다.'); },
          ai: (s, dj, e) => { const d = findD(dj, e.a); return d ? (60 - d.lo) / 10 : 0; } },
      ] },
    { k: 'insight', h: '새벽의 깨달음', need: 1, w: 0.9, pickA: (a, b) => b.st[3] - a.st[3],
      tx: (s, dj, e) => '새벽 명상 끝에 ' + nmOf(dj, e.a) + josa(nmOf(dj, e.a), '이', '가') + ' 오래 막혀 있던 동작 하나를 풀었다.',
      op: [
        { t: () => '모두에게 보이게 한다', h: '모든 제자의 기 +1 · 그 제자의 사기 +5', fx(s, dj, e) { each(dj, (d) => addSt(d, 0, 1)); const d = findD(dj, e.a); if (d) bump(d, 'mo', 5); rp(dj, '깨달음을 모두와 나누었다.'); }, ai: (s, dj) => dj.ds.length * 0.7 },
        { t: () => '혼자 다듬게 한다', h: '그 제자의 기 +3 · 숙련 +6', fx(s, dj, e) { const d = findD(dj, e.a); if (d) { addSt(d, 0, 3); d.m = Math.min(100, d.m + 6); rp(dj, d.n + josa(d.n, '이', '가') + ' 홀로 그 동작을 다듬었다.'); } }, ai: () => 2.5 },
      ] },
    { k: 'famine', h: '흉년', w: 0.7,
      tx: () => '흉년이 들어 수업료를 미루는 집이 늘었다.',
      op: [
        { t: () => '미뤄 준다', h: '이번 계절 수업료 절반 · 모든 제자의 충성 +6', fx(s, dj) { dj.fam = 1; each(dj, (d) => bump(d, 'lo', 6)); rp(dj, '수업료를 미뤄 주었다.'); }, ai: (s, dj) => (dj.$ > 25 ? 3 : 0) },
        { t: () => '제때 받는다', h: '모든 제자의 충성 −6', fx(s, dj) { each(dj, (d) => bump(d, 'lo', -6)); rp(dj, '수업료를 제때 받았다. 몇몇 집에서 볼멘소리가 났다.'); }, ai: (s, dj) => (dj.$ < 15 ? 3 : 1) },
      ] },
    { k: 'smith', h: '떠돌이 대장장이', w: 0.8,
      tx: () => '떠돌이 대장장이가 도장의 병기를 손봐 주겠다고 한다.',
      op: [
        { t: () => '맡긴다', h: '냥 −8 · 모든 제자의 숙련 +6', fx(s, dj) { dj.$ -= 8; each(dj, (d) => (d.m = Math.min(100, d.m + 6))); rp(dj, '병기를 맡겼다. 날이 고르게 섰다.'); }, ai: (s, dj) => (dj.$ >= 16 ? dj.ds.length * 0.8 : -2) },
        { t: () => '사양한다', h: '아무 일도 없다', fx() {}, ai: () => 1 },
      ] },
    { k: 'visit', h: '다른 도장 사범의 방문', npc: 1, w: 0.8,
      tx: (s, dj, e) => s.dj[e.x].nm + '의 사범이 예고 없이 마루를 둘러보고 갔다.',
      op: [
        { t: () => '차를 대접한다', h: '명성 +2', fx(s, dj) { dj.rep += 2; rp(dj, '차 한 잔을 나누었다. 오간 말은 많지 않았다.'); }, ai: () => 2 },
        { t: () => '제자의 솜씨를 보인다', h: '우리 제자가 더 강하면 명성 +6, 약하면 −4',
          fx(s, dj, e) { const a = byRating(dj.ds)[0], b = byRating(s.dj[e.x].ds)[0]; if (a && (!b || rating(a) + R() * 8 > rating(b) + R() * 8)) { dj.rep += 6; rp(dj, a.n + '의 솜씨에 그 사범이 고개를 끄덕였다.'); } else { dj.rep = Math.max(0, dj.rep - 4); rp(dj, '그 사범은 웃음만 남기고 돌아갔다.'); } },
          ai: (s, dj, e) => { const a = byRating(dj.ds)[0], b = byRating(s.dj[e.x].ds)[0]; return a && b ? (rating(a) - rating(b)) / 3 + 1 : -1; } },
      ] },
    { k: 'orphan', h: '문 앞의 아이', w: 0.6, ok: (s, dj) => dj.ds.length < capOf(dj),
      tx: () => '새벽, 도장 문 앞에 아이 하나가 웅크리고 있었다.',
      op: [
        { t: () => '거둔다', h: '어린 제자 하나 · 수업료 없음 · 충성이 높다', fx(s, dj) { if (dj.ds.length >= capOf(dj)) { rp(dj, '자리가 없어 아이를 관아에 맡겼다.'); return; } const d = genDisc(s, 0.25 + R() * 0.6, { age: 12, lo: 85, nt: 1 }); dj.ds.push(d); rp(dj, '아이를 거두었다. ' + d.n + '(이)라 불리게 되었다.'); }, ai: (s, dj) => (dj.ds.length < capOf(dj) - 1 ? 2.5 : 0) },
        { t: () => '관아에 맡긴다', h: '아무 일도 없다', fx(s, dj) { rp(dj, '아이를 관아에 맡겼다.'); }, ai: () => 1 },
      ] },
    { k: 'unrest', h: '마루의 불만', w: 1.6, ok: (s, dj) => dj.ds.length >= 2 && avg(dj.ds.map((d) => d.mo)) < 40,
      tx: () => '제자들 사이에 불만이 돈다. 마루를 닦는 손이 느려졌다.',
      op: [
        { t: () => '잔치를 연다', h: '냥 −8 · 모든 제자의 사기 +12', fx(s, dj) { dj.$ -= 8; each(dj, (d) => bump(d, 'mo', 12)); rp(dj, '잔치를 열었다. 오랜만에 웃음소리가 났다.'); }, ai: (s, dj) => (dj.$ >= 12 ? 4 : -1) },
        { t: () => '더 엄하게 다스린다', h: '모든 제자의 사기 −4 · 기 +1 · 충성 −4', fx(s, dj) { each(dj, (d) => { bump(d, 'mo', -4); bump(d, 'lo', -4); addSt(d, 0, 1); }); rp(dj, '수련을 더 엄하게 했다.'); }, ai: () => 0.5 },
      ] },
    { k: 'returnee', h: '떠났던 제자', w: 0.7, ok: (s, dj) => dj.gone.length > 0 && dj.ds.length < capOf(dj),
      tx: (s, dj, e) => '예전에 떠났던 ' + (dj.gone[e.g] ? dj.gone[e.g].n : '제자') + josa(dj.gone[e.g] ? dj.gone[e.g].n : '제자', '이', '가') + ' 도장 문을 두드렸다. 몰라보게 야위었다.',
      op: [
        { t: () => '받아들인다', h: '그 제자가 돌아온다(자리 필요)', fx(s, dj, e) { const g = dj.gone[e.g]; if (!g || dj.ds.length >= capOf(dj)) return; dj.gone.splice(e.g, 1); g.lo = 70; g.mo = 50; g.inj = 0; g.away = 0; dj.ds.push(g); rp(dj, g.n + josa(g.n, '이', '가') + ' 다시 마루에 섰다.'); },
          ai: (s, dj, e) => (dj.gone[e.g] ? rating(dj.gone[e.g]) / 12 : 0) },
        { t: () => '돌려보낸다', h: '아무 일도 없다', fx(s, dj, e) { dj.gone.splice(e.g, 1); rp(dj, '문을 열지 않았다.'); }, ai: () => 1 },
      ] },
    { k: 'patronson', h: '후원자의 부탁', w: 0.7, ok: (s, dj) => dj.pat > 0,
      tx: () => '후원자가 제 아들을 맡기고 싶다고 한다. 재주는 없어 보인다.',
      op: [
        { t: () => '받아들인다', h: '재주 없는 제자 하나(자리 필요) · 냥 +6', fx(s, dj) { if (dj.ds.length >= capOf(dj)) { rp(dj, '자리가 없어 받지 못했다.'); return; } dj.$ += 6; const d = genDisc(s, 0.05, { age: 16 + ri(4), lo: 60 }); d.ta = 9; dj.ds.push(d); rp(dj, '후원자의 아들을 받았다. ' + d.n + '(이)라 불린다.'); }, ai: (s, dj) => (dj.ds.length < capOf(dj) - 1 ? 2 : -1) },
        { t: () => '정중히 거절한다', h: '후원자가 떠날 수 있다', fx(s, dj) { if (chance(0.4)) { dj.pat--; rp(dj, '후원자 하나가 발길을 끊었다.'); } else rp(dj, '후원자는 서운한 기색을 감추었다.'); }, ai: () => 0.5 },
      ] },
    { k: 'chal', h: '도전장',
      tx: (s, dj, e) => s.dj[e.x].nm + '에서 도전장을 보냈다. 세 판 승부에 이 도장의 현판을 걸라는 것이다.',
      op: [
        { t: () => '응한다', h: '이번 계절 세 판 승부 · 지면 현판을 잃는다', fx(s, dj, e) { dj.acc = e.x; }, ai: (s, dj, e) => winEst(s, s.dj.indexOf(dj), e.x) * 10 - 4 },
        { t: () => '거절한다', h: '명성 −8 · 모든 제자의 사기 −4', fx(s, dj, e) { dj.rep = Math.max(0, dj.rep - 8); each(dj, (d) => bump(d, 'mo', -4)); rp(dj, s.dj[e.x].nm + '의 도전을 거절했다. 고을에 말이 돌았다.'); news(s, dj.nm + josa(dj.nm, '이', '가') + ' ' + s.dj[e.x].nm + '의 도전을 거절했다.'); }, ai: () => 1 },
      ] },
    { k: 'retire', h: '사범의 은퇴',
      tx: () => '사범이 마루에 서는 날이 줄었다. 이번 계절을 끝으로 물러나겠다며, 뒤를 이을 사람을 정하라 한다.' },
  ];
  const EV = {}; EVENTS.forEach((E) => (EV[E.k] = E));

  function succeed(s, dj, id) {
    const d = findD(dj, id) || byRating(dj.ds)[0];
    if (!d) return;
    const old = dj.mst;
    dj.ds = dj.ds.filter((x) => x !== d);
    dj.mst = Object.assign({}, d, { lo: 100, inj: 0, away: 0, heir: 1 });
    dj.sx = -1;
    dj.rep += Math.round(rating(d) / 10);
    rp(dj, old.n + josa(old.n, '이', '가') + ' 물러나고 ' + d.n + josa(d.n, '이', '가') + ' 도장을 이었다.');
    news(s, dj.nm + '의 사범 자리를 ' + d.n + josa(d.n, '이', '가') + ' 이었다.');
    const r0 = rating(d);
    for (const x of dj.ds.slice()) {
      bump(x, 'mo', -5);
      if (rating(x) > r0 + 4 && x.lo < 65 && chance(0.5)) {
        const npcs = npcList(s);
        leave(s, dj, x, '끝내 고개를 숙이지 않았다.', npcs.length && chance(0.6) ? pick(npcs) : -1);
      } else if (x.tp === 4) bump(x, 'lo', -15);
    }
  }

  /* ---------------- 수련 · 살림 ---------------- */
  function trainOne(s, dj, d, k) {
    const rpLine = [];
    if (d.away) { d.away = 0; return null; }
    if (d.inj || d.fr) k = 5;
    d.fr = 0;
    const T = TRAIN[k], ta = TALENTS[d.ta] || TALENTS[0];
    d.tr = k;
    const own = dj.own >= 0;
    const facHall = 1 + 0.05 * dj.fac[0];
    const styleB = dj.st >= 0 && STYLES[dj.st].tr === k ? 1.2 : 1;
    const seasonB = (s.se === 1 && k === 2) || (s.se === 3 && k === 3) ? 1.2 : 1;
    const libB = k === 0 || k === 3 ? 1 + 0.15 * dj.fac[2] : 1;
    const ageB = d.age <= 18 ? 1.15 : d.age <= 25 ? 1 : d.age <= 32 ? 0.8 : 0.55;
    const moB = 0.6 + d.mo / 125;
    const g = 7.2 * curveF(d.cv, d.ex) * facHall * styleB * seasonB * libB * ageB * moB * (own ? 1 : 0.62);
    const before = d.st.slice(), m0 = d.m;
    for (let i = 0; i < 4; i++) {
      if (!T.g[i]) continue;
      const room = clamp((d.pot[i] - d.st[i]) / 25, 0, 1);
      addSt(d, i, g * T.g[i] * (ta.g ? ta.g[i] : 1) * room * (0.8 + R() * 0.4));
    }
    if (T.ms) d.m = Math.min(100, r1(d.m + g * T.ms * (ta.ms || 1) * (1 + 0.2 * dj.fac[3]) * (0.8 + R() * 0.4)));
    if (k !== 5) d.ex++;
    bump(d, 'mo', T.mo + dj.fac[1] * 2 + (d.tp === 6 ? ri(9) - 4 : 0));
    if (ta.mof && d.mo < ta.mof) d.mo = ta.mof;
    bump(d, 'lo', T.lo);
    // 부상
    if (T.inj && !d.inj) {
      const p = T.inj * (ta.inj || 1) * (1 - 0.2 * dj.fac[1]) * (dj.st === 3 ? 0.75 : 1) * (d.mo < 30 ? 1.3 : 1);
      if (chance(p)) { d.inj = chance(0.25) ? 3 : 1 + ri(2); rpLine.push('다쳤다(' + d.inj + '계절)'); }
    } else if (d.inj && k === 5) {
      d.inj = Math.max(0, d.inj - 1 - (dj.fac[1] >= 2 && chance(0.5) ? 1 : 0));
      if (!d.inj) rpLine.push('부상이 나았다');
    }
    // 성장 곡선은 두 계절을 지켜보면(또는 서고가 있으면) 드러난다
    if (!d.rv && (d.ex >= 2 || dj.fac[2] > 0)) { d.rv = 1; if (own) rpLine.push('성장 곡선: ' + CURVES[d.cv].n); }
    // 기술
    const newT = TECHS.filter((Tc) => Tc.w === d.w && m0 < Tc.m && d.m >= Tc.m);
    for (const Tc of newT) rpLine.push('「' + Tc.n + '」' + josa(Tc.n, '을', '를') + ' 익혔다');
    const dl = d.st.map((v, i) => Math.round(v) - Math.round(before[i]));
    const gain = dl.map((v, i) => (v > 0 ? STATS[i] + ' +' + v : '')).filter(Boolean);
    if (Math.round(d.m) > Math.round(m0)) gain.push('숙련 +' + (Math.round(d.m) - Math.round(m0)));
    return { k, gain, extra: rpLine };
  }

  function finances(s, dj) {
    const fam = dj.fam ? 0.5 : 1; dj.fam = 0;
    const per = 2 + Math.min(4, dj.rep / 70);
    const tu = Math.round(dj.ds.filter((d) => !d.nt).length * per * fam);
    const pat = dj.pat * 5;
    const up = Math.round(3 + dj.fac.reduce((a, b) => a + b, 0) * 1.5 + dj.ds.length);
    dj.$ += tu + pat - up;
    rp(dj, '살림 — 수업료 +' + tu + (pat ? ' · 후원 +' + pat : '') + ' · 살림살이 −' + up + ' = ' + (tu + pat - up >= 0 ? '+' : '−') + Math.abs(tu + pat - up) + '냥');
  }

  /* ---------------- 계절 처리 ---------------- */
  function resolveSeason(s) {
    const t = tOf(s);
    s.bl = [];
    const chals = [];
    for (const dj of s.dj) if (dj.own >= 0) dj.rp = [];
    for (let seat = 0; seat < s.n; seat++) {
      const P = s.pl[seat], dj = s.dj[seat];
      if (dj.st < 0) { dj.st = P.style >= 0 && P.style < 5 ? P.style : 0; rp(dj, '검풍을 「' + STYLES[dj.st].n + '」으로 정했다.'); }
      // 병기 바꾸기
      for (const id in P.wch || {}) { const d = findD(dj, +id), w = P.wch[id]; if (d && w >= 0 && w < 5 && w !== d.w) { d.w = w; d.m = Math.round(d.m * 0.35); rp(dj, d.n + josa(d.n, '이', '가') + ' 병기를 ' + WEAPONS[w].n + roJ(WEAPONS[w].n) + ' 바꾸었다.'); } }
      // 내보내기
      if (P.dis != null) { const d = findD(dj, P.dis); if (d) { dj.ds = dj.ds.filter((x) => x !== d); dj.rec.out = (dj.rec.out || 0) + 1; each(dj, (x) => bump(x, 'lo', -2)); rp(dj, d.n + josa(d.n, '을', '를') + ' 내보냈다. 남은 제자들이 말없이 짐 싸는 것을 지켜보았다.'); } }
      // 사건
      if (dj.ev) {
        const E = EV[dj.ev.k];
        if (dj.ev.k === 'retire') succeed(s, dj, P.ev);
        else if (E && E.op) { const o = E.op[clamp(P.ev | 0, 0, E.op.length - 1)]; o.fx(s, dj, dj.ev); }
        dj.ev = null;
      }
      // 일 두 가지
      for (const a of (P.acts || []).slice(0, 2)) doAct(s, seat, dj, a, chals);
    }
    // 수련
    for (let i = 0; i < s.dj.length; i++) {
      const dj = s.dj[i];
      const plan = dj.own >= 0 ? s.pl[dj.own].tr || {} : npcTrain(s, i);
      const lines = [];
      for (const d of dj.ds.slice()) {
        const k = plan[d.id] != null ? clamp(plan[d.id] | 0, 0, 5) : d.tr || 0;
        const r = trainOne(s, dj, d, k);
        if (r && dj.own >= 0) lines.push(d.n + ' · ' + TRAIN[r.k].n + (r.gain.length ? ' — ' + r.gain.join(' · ') : ' — 변화 없음') + (r.extra.length ? ' · ' + r.extra.join(' · ') : ''));
      }
      if (dj.own >= 0) { dj.rp.push(...lines); finances(s, dj); }
      else npcSeason(s, i);
    }
    // 시합 줄 세우기
    s.mq = [];
    for (const c of chals) s.mq.push(c);
    for (let i = 0; i < s.n; i++) {
      const dj = s.dj[i];
      if (dj.acc != null) { const m = mkChal(s, dj.acc, i); if (m) s.mq.push(m); dj.acc = null; }
    }
    if (t >= 2 && chance(0.15)) {   // 다른 도장끼리의 도장 깨기(소식으로만)
      const np = npcList(s).filter((i) => healthy(s.dj[i]).length >= 2);
      if (np.length >= 2) { shuffle(np); const m = mkChal(s, np[0], np[1]); if (m) s.mq.push(m); }
    }
    if (s.se === 2) s.mq.push(mkTour(s, 'r'));
    if (s.se === 3) s.mq.push(mkTour(s, 'n'));
    advance(s);
  }

  function doAct(s, seat, dj, a, chals) {
    if (!a || typeof a !== 'object') return;
    const t = tOf(s);
    if (a.k === 'rec') {
      const c = dj.cand[a.c];
      if (!c) return;
      if (dj.ds.length >= capOf(dj)) { rp(dj, '자리가 모자라 ' + c.n + josa(c.n, '을', '를') + ' 돌려보냈다.'); return; }
      dj.cand[a.c] = null;
      dj.ds.push(c); rp(dj, c.n + josa(c.n, '이', '가') + ' 입문했다.');
    } else if (a.k === 'bld') {
      const f = a.f | 0; if (f < 0 || f > 3 || dj.fac[f] >= 3) return;
      const cost = FAC_COST[dj.fac[f] + 1];
      if (dj.$ < cost) { rp(dj, '돈이 모자라 ' + FAC[f].n + ' 공사를 미뤘다.'); return; }
      dj.$ -= cost; dj.fac[f]++;
      rp(dj, FAC[f].n + josa(FAC[f].n, '을', '를') + ' ' + dj.fac[f] + '단계로 손보았다(−' + cost + '냥).');
    } else if (a.k === 'show') {
      const top = byRating(dj.ds).slice(0, 3);
      const q = top.length ? avg(top.map(rating)) : 20;
      const gain = Math.round(5 + q / 6 + dj.rep / 30);
      const rg = 2 + (q >= 55 ? 2 : 0) + (q >= 70 ? 2 : 0);
      dj.$ += gain; dj.rep += rg;
      rp(dj, '장터에서 시범을 보였다. +' + gain + '냥 · 명성 +' + rg);
    } else if (a.k === 'pat') {
      const p = clamp(0.25 + dj.rep / 250 - dj.pat * 0.15, 0.1, 0.85);
      if (dj.pat < 3 && chance(p)) { dj.pat++; rp(dj, '후원자를 얻었다. 계절마다 5냥을 보내기로 했다.'); }
      else rp(dj, '후원자를 찾아다녔으나 빈손으로 돌아왔다.');
    } else if (a.k === 'chal') {
      const x = a.d | 0;
      if (!chalOk(s, seat, x)) return;
      dj.cd[x] = t + 4; dj.cd.a = t + 2;
      const m = mkChal(s, seat, x);
      if (m) chals.push(m);
    }
  }
  function chalOk(s, seat, x) {
    const dj = s.dj[seat];
    return tOf(s) >= 1 && x >= 0 && x < s.dj.length && x !== seat && !(dj.cd[x] > tOf(s)) && !(dj.cd.a > tOf(s)) && healthy(dj).length >= 3;
  }
  function lineup(dj, need) {
    const h = byRating(healthy(dj)).slice(0, 3);
    const refs = h.map((d) => d.id).reverse();   // 선봉 · 중견 · 대장(가장 강한 제자)
    while (need && refs.length < 3) refs.push(-1);   // 모자라면 사범이 나선다
    return refs;
  }
  function mkChal(s, a, b) {
    const A = s.dj[a], B = s.dj[b];
    const la = lineup(A, true), lb = lineup(B, true);
    if (healthy(A).length < 2) return null;
    return { k: 'c', a, b, f: [la, lb], w: [] };
  }

  /* ---------------- 대회 ---------------- */
  function genOutsider(s, tier) {
    const lvlT = tier === 'n' ? 46 + s.yr * 4.5 : 32 + s.yr * 4.5;
    const w = ri(5);
    const st = STATS.map(() => r1(clamp(lvlT + R() * 14 - 7, 15, 96)));
    return { n: pick(OUTSIDERS) + ' ' + WEAPONS[w].role, dn: tier === 'n' ? '타지의 고수' : '떠돌이 무사', w, st, pot: st.slice(), m: clamp(Math.round(lvlT + R() * 20), 10, 100), tp: ri(8), ta: chance(0.3) ? 6 : 0, mo: 60, inj: 0, sty: ri(5), forge: tier === 'n' ? 2 : 1 };
  }
  function champOf(s, i) {
    const dj = s.dj[i];
    const h = healthy(dj);
    if (!h.length) return null;
    if (dj.own >= 0) { const P = s.pl[dj.own]; const c = P && P.ch != null ? h.find((d) => d.id === P.ch) : null; if (c) return c.id; }
    return byRating(h)[0].id;
  }
  function mkTour(s, k) {
    const ent = [], out = [];
    let cands = k === 'r' ? s.dj.map((x, i) => i) : s.semi.slice();
    for (const i of cands) { const c = champOf(s, i); if (c != null && ent.length < 8) ent.push({ d: i, i: c }); }
    while (ent.length < 8) { out.push(genOutsider(s, k)); ent.push({ o: out.length - 1 }); }
    shuffle(ent);
    return { k, ent, out, br: [ent.map((x, i) => i)], r: 0, bi: 0 };
  }
  const RLAB = { 8: '8강', 4: '4강', 2: '결승' };

  /* ---------------- 시합 진행 ---------------- */
  function fighter(s, ref, m) {
    if (ref.o != null) { const f = m.out[ref.o]; return Object.assign({ dojo: -1 }, f); }
    const dj = s.dj[ref.d];
    const x = ref.i < 0 ? dj.mst : findD(dj, ref.i);
    if (!x) return null;
    return Object.assign({}, x, { dojo: ref.d, sty: dj.st, forge: dj.fac[3], dn: dj.nm, master: ref.i < 0 });
  }
  function boutOf(s, m) {
    if (m.k === 'c') {
      const wa = m.w.filter((x) => x === 0).length, wb = m.w.length - wa;
      if (wa >= 2 || wb >= 2 || m.w.length >= 3) return null;
      const i = m.w.length;
      return { lab: s.dj[m.a].nm + ' 대 ' + s.dj[m.b].nm + ' · ' + ['선봉', '중견', '대장'][i], f: [{ d: m.a, i: m.f[0][i] }, { d: m.b, i: m.f[1][i] }], big: 1 };
    }
    const r = m.br[m.r];
    if (r.length <= 1) return null;
    const ea = m.ent[r[m.bi * 2]], eb = m.ent[r[m.bi * 2 + 1]];
    return { lab: (m.k === 'r' ? '고을 대회' : '천하 대회') + ' · ' + RLAB[r.length], f: [ea, eb], big: m.k === 'n' ? 1 : 0, ti: [r[m.bi * 2], r[m.bi * 2 + 1]] };
  }
  function seatOf(s, ref) {
    if (ref.o != null) return -1;
    const own = s.dj[ref.d].own;
    return own >= 0 && !s.ai[own] && !s.dm ? own : -1;
  }
  /* 맞을 수 없는 제자(떠남·부상)는 같은 도장의 다른 사람으로, 없으면 사범으로 */
  function fixRef(s, ref, m) {
    if (ref.o != null) return ref;
    const dj = s.dj[ref.d];
    if (ref.i < 0) return ref;
    const d = findD(dj, ref.i);
    if (d && !d.inj) return ref;
    const used = m && m.k === 'c' ? m.f.flat() : [];
    const alt = byRating(healthy(dj)).find((x) => !used.includes(x.id));
    return { d: ref.d, i: alt ? alt.id : -1 };
  }
  function newBout(s, m, b) {
    b.f = b.f.map((r) => fixRef(s, r, m));
    if (m.k === 'c') { const i = m.w.length; m.f[0][i] = b.f[0].i; m.f[1][i] = b.f[1].i; }
    const fa = fighter(s, b.f[0], m), fb = fighter(s, b.f[1], m);
    return Object.assign(b, { id: ++s.seq, sd: [seatOf(s, b.f[0]), seatOf(s, b.f[1])], sc: [0, 0], ex: [], pk: [null, null], au: [0, 0], mo: 0, lp: -1,
      nm: [fa.n, fb.n], dn: [fa.dn, fb.dn], w: [fa.w, fb.w], tp: [fa.tp, fb.tp] });
  }
  function advance(s) {
    for (let guard = 0; guard < 200; guard++) {
      if (s.B) return;
      const m = s.mq[0];
      if (!m) { finishSeason(s); return; }
      const b = boutOf(s, m);
      if (!b) { finalize(s, m); s.mq.shift(); continue; }
      newBout(s, m, b);
      if (b.sd[0] >= 0 || b.sd[1] >= 0) { s.B = b; s.ph = 'duel'; return; }
      while (endOf(b) < 0) {
        const sa = stanceAI(s, b, 0, sideLv(s, b, 0)), sb = stanceAI(s, b, 1, sideLv(s, b, 1));
        exchange(s, b, sa, sb);
      }
      closeBout(s, b);
    }
  }
  function sideLv(s, b, side) {
    const ref = b.f[side];
    if (ref.o != null) { const m = s.mq[0]; return m && m.k === 'n' ? 3 : 2; }
    const dj = s.dj[ref.d];
    if (dj.own >= 0) return b.au[side] ? 2 : s.lv[dj.own];
    return dj.lvl >= 3 ? 3 : 2;
  }
  function ctxOf(b, side) {
    const o = 1 - side;
    return { n: b.ex.length, sc: [b.sc[side], b.sc[o]], after: b.lp === side, big: !!b.big, mo: b.mo === side + 1 ? 1 : 0 };
  }
  function power(f, st, c) {
    const S = STANCES[st];
    let p = (f.st[S.u[0]] + f.st[S.u[1]]) / 2;
    const W = WEAPONS[f.w], mf = 0.4 + 0.6 * (f.m || 0) / 100;
    p += W.mod[st] * mf;
    if (c.n === 0 && W.first) p += W.first[st] * mf;
    p += f.forge || 0;
    if (f.sty >= 0) { const Y = STYLES[f.sty]; p += Y.sb[st]; if (Y.x === 'first' && c.n === 0 && st === 0) p += 3; if (Y.x === 'late' && c.n >= 2) p += 3; }
    for (const T of techsOf(f)) if ((T.s < 0 || T.s === st) && condOk(T.c, c)) p += T.b;
    if (TEMPERS[f.tp].pref === st) p += 3;
    if (f.tp === 7 && c.sc[0] < c.sc[1]) p += 4;
    const ta = TALENTS[f.ta] || TALENTS[0];
    if (ta.duel) p += ta.duel;
    if (ta.big && c.big) p += ta.big;
    p += ((f.mo == null ? 60 : f.mo) - 55) / 10;
    if (f.inj) p -= 10;
    if (c.mo) p += 3;
    return p;
  }
  function condOk(k, c) { return k === 'all' || (k === 'first' && c.n === 0) || (k === 'after' && c.after) || (k === 'behind' && c.sc[0] < c.sc[1]) || (k === 'ahead' && c.sc[0] > c.sc[1]) || (k === 'tie' && c.sc[0] === c.sc[1]); }
  function exProb(pa, pb, sa, sb) {
    if (sa !== sb) {
      if (beats(sa, sb)) return [clamp(0.58 + (pa - pb) / 70, 0.25, 0.9), clamp(0.1 + (pb - pa) / 200, 0.03, 0.2)];
      const q = exProb(pb, pa, sb, sa); return [q[1], q[0]];
    }
    const lg = 1 / (1 + Math.exp(-(pa - pb) / 10));
    if (sa === 0) return [0.7 * lg, 0.7 * (1 - lg)];
    if (sa === 1) return [0.04, 0.04];
    return [0.3 * lg, 0.3 * (1 - lg)];
  }
  function bfighters(s, b) { const m = s.mq[0]; return [fighter(s, b.f[0], m), fighter(s, b.f[1], m)]; }
  function exchange(s, b, sa, sb) {
    const [fa, fb] = bfighters(s, b);
    const pa = power(fa, sa, ctxOf(b, 0)), pb = power(fb, sb, ctxOf(b, 1));
    const [qa, qb] = exProb(pa, pb, sa, sb);
    const r = R();
    const res = r < qa ? 1 : r < qa + qb ? 2 : 0;
    let mo = res;
    if (!res && sa === 1 && sb === 1) mo = fa.st[3] + R() * 10 > fb.st[3] + R() * 10 ? 1 : 2;
    b.mo = mo; b.lp = res ? res - 1 : -1;
    if (res) b.sc[res - 1]++;
    const tg = res ? ri(2) : 0;
    b.ex.push('' + sa + sb + res + tg + (mo || 0));
    return { sa, sb, res, tg, mo, pa: Math.round(pa), pb: Math.round(pb) };
  }
  /* 끝났으면 이긴 쪽(0·1), 아니면 −1. 여섯 합이 지나면 판정 */
  function endOf(b) {
    if (b.sc[0] >= 2) return 0;
    if (b.sc[1] >= 2) return 1;
    if (b.ex.length < 6) return -1;
    if (b.sc[0] !== b.sc[1]) return b.sc[0] > b.sc[1] ? 0 : 1;
    let adv = 0;
    for (const e of b.ex) { const sa = +e[0], sb = +e[1]; if (beats(sa, sb)) adv++; else if (beats(sb, sa)) adv--; }
    if (adv) return adv > 0 ? 0 : 1;
    return b.tie != null ? b.tie : (b.tie = ri(2));
  }
  function closeBout(s, b) {
    const w = endOf(b), m = s.mq[0];
    b.win = w;
    b.dec = b.sc[0] < 2 && b.sc[1] < 2 ? 1 : 0;
    const fs = [0, 1].map((i) => (b.f[i].o != null ? null : (b.f[i].i < 0 ? s.dj[b.f[i].d].mst : findD(s.dj[b.f[i].d], b.f[i].i))));
    fs.forEach((x, i) => {
      if (!x) return;
      if (i === w) { x.wn = (x.wn || 0) + 1; x.mo = clamp(x.mo + (x.tp === 0 ? 10 : 6), 0, 100); }
      else { x.ls = (x.ls || 0) + 1; x.mo = clamp(x.mo - (x.tp === 0 ? 10 : 6), 0, 100); if (!x.heir && x.lo < 100 && chance(0.12)) x.inj = Math.max(x.inj || 0, 1); }
    });
    s.bl.push({ l: b.lab, n: b.nm, dn: b.dn, d: b.f.map((r) => (r.o != null ? -1 : r.d)), ex: b.ex.map((e) => e.slice(0, 3)).join(','), w, dec: b.dec });
    if (s.bl.length > 24) s.bl.shift();
    if (m.k === 'c') m.w.push(w);
    else {   // 대회: br[r] = r번째 회전에 남은 엔트리 번호들. 이긴 쪽을 다음 회전 줄에 쌓는다
      if (!m.br[m.r + 1]) m.br[m.r + 1] = [];
      m.br[m.r + 1].push(b.ti[w]);
      m.bi++;
      if (m.bi * 2 >= m.br[m.r].length) { m.r++; m.bi = 0; }
    }
    s.B = null;
    s.ph = 'plan';
  }

  function finalize(s, m) {
    if (m.k === 'c') {
      const wa = m.w.filter((x) => x === 0).length, wb = m.w.length - wa;
      const A = s.dj[m.a], B = s.dj[m.b];
      if (wa > wb) {
        const take = Math.round(B.rep * 0.1) + 8;
        B.rep = Math.max(0, B.rep - take); A.rep += 15 + Math.round(take * 0.6);
        A.rec.cw++; B.rec.cl++;
        // 현판: 이미 남의 손에 있으면 그 현판을 빼앗아 오고, 내 현판이면 되찾는다
        const holder = s.dj.findIndex((x) => x.sb.includes(m.b));
        if (holder >= 0) s.dj[holder].sb = s.dj[holder].sb.filter((x) => x !== m.b);
        if (B.lost === m.a || m.b === m.a) { /* 없음 */ }
        if (A.lost === m.b) { A.lost = -1; B.sb = B.sb.filter((x) => x !== m.a); rp(A, '빼앗겼던 현판을 되찾았다.'); }
        A.sb.push(m.b); B.lost = m.a;
        B.pat = B.pat > 0 && chance(0.4) ? B.pat - 1 : B.pat;
        each(A, (d) => bump(d, 'mo', 6)); each(B, (d) => { bump(d, 'mo', -10); bump(d, 'lo', -5); });
        rp(A, B.nm + '의 현판을 떼어 왔다(' + wa + ' 대 ' + wb + '). 명성 +' + (15 + Math.round(take * 0.6)));
        rp(B, A.nm + '에 ' + wb + ' 대 ' + wa + roJ(wa) + ' 졌다. 현판을 내주었다. 명성 −' + take);
        news(s, A.nm + josa(A.nm, '이', '가') + ' ' + B.nm + '의 현판을 떼어 갔다.');
      } else {
        A.rep = Math.max(0, A.rep - 15); if (A.own >= 0) A.$ -= 8; B.rep += 12; A.rec.cl++;
        each(A, (d) => bump(d, 'mo', -6)); each(B, (d) => bump(d, 'mo', 5));
        rp(A, B.nm + '에서 ' + wa + ' 대 ' + wb + roJ(wb) + ' 물러났다. 명성 −15' + (A.own >= 0 ? ' · 사죄금 −8냥' : ''));
        rp(B, A.nm + '의 도전을 ' + wb + ' 대 ' + wa + roJ(wa) + ' 막아 냈다. 명성 +12');
        news(s, B.nm + josa(B.nm, '이', '가') + ' ' + A.nm + '의 도전을 막아 냈다.');
      }
      return;
    }
    // 대회 순위
    const elim = {};   // 엔트리 번호 → 올라간 가장 높은 회전(0 = 8강 탈락 … 3 = 우승)
    m.br.forEach((r, ri_) => r.forEach((e) => (elim[e] = ri_)));
    const champ = m.br[m.br.length - 1][0];
    elim[champ] = 3;
    const REW = m.k === 'r' ? [[3, 0], [10, 6], [20, 12], [36, 24]] : [[8, 4], [22, 14], [42, 30], [80, 60]];
    const PL = ['8강', '4강', '준우승', '우승'];
    if (m.k === 'r') s.semi = [];
    m.ent.forEach((ref, ei) => {
      if (ref.o != null) return;
      const lvl = ei === champ ? 3 : elim[ei];
      const dj = s.dj[ref.d];
      if (m.k === 'r' && lvl >= 1) s.semi.push(ref.d);
      dj.rep += Math.round(REW[lvl][0] * (dj.own >= 0 ? 1 : 0.6));
      if (dj.own >= 0) dj.$ += REW[lvl][1];
      if (lvl === 3) { if (m.k === 'r') dj.rec.rw++; else dj.rec.nw++; }
      const f = ref.i < 0 ? dj.mst : findD(dj, ref.i);
      rp(dj, (m.k === 'r' ? '고을 대회' : '천하 대회') + ' — ' + (f ? f.n : '출전자') + ' ' + PL[lvl] + ' · 명성 +' + Math.round(REW[lvl][0] * (dj.own >= 0 ? 1 : 0.6)) + (dj.own >= 0 && REW[lvl][1] ? ' · +' + REW[lvl][1] + '냥' : ''));
    });
    const ce = m.ent[champ];
    const cn = ce.o != null ? m.out[ce.o].n : (ce.i < 0 ? s.dj[ce.d].mst.n : (findD(s.dj[ce.d], ce.i) || { n: '?' }).n);
    news(s, (m.k === 'r' ? '고을 대회' : '천하 대회') + ' 우승 — ' + (ce.o != null ? m.out[ce.o].dn : s.dj[ce.d].nm) + '의 ' + cn);
    s.lastTour = { k: m.k, ent: m.ent.map((r) => (r.o != null ? { n: m.out[r.o].n, dn: m.out[r.o].dn, d: -1 } : { n: (r.i < 0 ? s.dj[r.d].mst : findD(s.dj[r.d], r.i) || { n: '?' }).n, dn: s.dj[r.d].nm, d: r.d })), br: m.br };
  }

  function finishSeason(s) {
    s.ph = 'plan';
    for (let i = 0; i < s.dj.length; i++) {
      const dj = s.dj[i];
      if (dj.own >= 0) {
        // 빚
        if (dj.$ < 0) { dj.rep = Math.max(0, dj.rep - 3); each(dj, (d) => { bump(d, 'mo', -6); bump(d, 'lo', -4); }); rp(dj, '빚이 쌓였다. 제자들의 눈치가 달라졌다.'); }
        if (dj.$ < -40 && dj.ds.length) { const d = dj.ds.slice().sort((a, b) => a.lo - b.lo)[0]; leave(s, dj, d, '살림이 어려워 떠났다.'); }
        // 충성 흐름 · 떠남
        const rank = s.dj.filter((x) => x.rep > dj.rep).length;
        for (const d of dj.ds.slice()) {
          let dl = 0;
          if (d.mo > 60) dl += 2; else if (d.mo < 30) dl -= 4;
          if (rank < s.dj.length / 2) dl += 1;
          if (d.tp === 5) dl = Math.max(dl, 0) + 1;
          if (d.tp === 7 && rank >= s.dj.length / 2) dl -= 2;
          bump(d, 'lo', dl);
          if (d.tp === 5 && d.lo < 50) d.lo = 50;
          d.mo = clamp(Math.round(d.mo + (60 - d.mo) * 0.08), 0, 100);
          if (d.lo < 22 && chance(0.35 + (d.mo < 30 ? 0.2 : 0))) {
            const strong = rating(d) >= avg(dj.ds.map(rating));
            const np = npcList(s);
            leave(s, dj, d, '오래 마음이 떠나 있었다.', strong && np.length && chance(0.5) ? pick(np) : -1);
          }
        }
        // 후원자는 명성이 크게 떨어지면 떠난다
        if (dj.pat && dj.rep < dj.rec.peak * 0.6 && chance(0.3)) { dj.pat--; rp(dj, '후원자 하나가 발길을 끊었다.'); }
      }
      // 명성: 강한 제자가 이름을 알린다 · 조금씩 잊힌다
      const best = dj.ds.length ? Math.max(...dj.ds.map(rating)) : 0;
      dj.rep += Math.round(clamp((best - 45) / 8, 0, 4) * (dj.own >= 0 ? 1 : 0.5));
      if (dj.rep > 20) dj.rep = Math.round(dj.rep * 0.98);
      dj.rec.best = Math.max(dj.rec.best, best);
      dj.rec.peak = Math.max(dj.rec.peak, dj.rep);
    }
    // 해가 바뀜
    if (s.se === 3) {
      for (const dj of s.dj) {
        dj.mst.age++;
        if (dj.mst.age > 55 && !dj.mst.heir) dj.mst.st = dj.mst.st.map((v) => r1(Math.max(20, v - 1.2)));
        for (const d of dj.ds.slice()) {
          d.age++;
          if (d.age > 30) d.st = d.st.map((v) => r1(Math.max(10, v - (d.age > 34 ? 1.5 : 0.6))));
          if (d.age > 33 && chance(0.12)) { if (dj.own >= 0) { leave(s, dj, d, '검을 내려놓고 고향으로 돌아갔다.'); dj.rec.left--; } else dj.ds = dj.ds.filter((x) => x !== d); }
        }
      }
    }
    s.se++;
    if (s.se > 3) { s.se = 0; s.yr++; }
    if (s.yr > s.len) { s.ph = 'end'; s.yr = s.len; s.se = 3; s.over = 1; s.B = null; return; }
    startSeason(s, false);
  }

  /* NPC 도장: 수련은 AI가 고르고, 자리가 비면 새 제자를 받는다 */
  function npcSeason(s, i) {
    const dj = s.dj[i];
    const want = 3 + dj.lvl;
    if (dj.ds.length < want && chance(0.45)) dj.ds.push(genDisc(s, clamp(0.18 + dj.lvl * 0.1 + R() * 0.2, 0, 1), { w: chance(0.6) ? dj.fw : ri(5), age: 15 + ri(8), lift: 2 + dj.lvl * 3 }));
    for (const d of dj.ds) { d.lo = 70; }
  }

  /* ---------------- 승부 예상(사람에게 보이는 값 · AI 판단) ---------------- */
  function boutP(ra, rb) { return 1 / (1 + Math.exp(-(ra - rb) / 7)); }
  function winEst(s, a, b) {
    const A = s.dj[a], B = s.dj[b];
    const ra = lineup(A, true).map((id) => rating(id < 0 ? A.mst : findD(A, id)));
    const rb = lineup(B, true).map((id) => rating(id < 0 ? B.mst : findD(B, id)));
    const p = [0, 1, 2].map((i) => boutP(ra[i] || 20, rb[i] || 20));
    return p[0] * p[1] + p[0] * (1 - p[1]) * p[2] + (1 - p[0]) * p[1] * p[2];
  }

  /* ---------------- core 규약 ---------------- */
  function actor(s) {
    if (s.ph === 'end') return null;
    if (s.ph === 'plan') { const a = []; for (let i = 0; i < s.n; i++) if (!s.pl[i]) a.push(i); return a.length ? a : null; }
    if (s.ph === 'duel' && s.B) { const b = s.B, a = []; for (let k = 0; k < 2; k++) if (b.sd[k] >= 0 && b.pk[k] == null && !b.au[k] && !a.includes(b.sd[k])) a.push(b.sd[k]); return a.length ? a : null; }
    return null;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (s.ph === 'plan') {
      if (a.t !== 'plan') throw new Error('not plan phase');
      if (s.pl[seat]) throw new Error('already planned');
      const dj = s.dj[seat];
      const P = { tr: {}, acts: [], ch: null, ev: 0, style: -1, wch: {}, dis: null };
      if (a.tr && typeof a.tr === 'object') for (const d of dj.ds) if (a.tr[d.id] != null) P.tr[d.id] = clamp(a.tr[d.id] | 0, 0, 5);
      if (a.wch && typeof a.wch === 'object') for (const d of dj.ds) if (a.wch[d.id] != null) P.wch[d.id] = clamp(a.wch[d.id] | 0, 0, 4);
      if (Array.isArray(a.acts)) {
        const seen = {};
        for (const x of a.acts.slice(0, 2)) {
          if (!x || !['rec', 'bld', 'show', 'pat', 'chal'].includes(x.k)) continue;
          const key = x.k + ':' + (x.c != null ? x.c : x.f != null ? x.f : x.d != null ? x.d : '');
          if (seen[key] || (x.k === 'chal' && seen.chal) || ((x.k === 'show' || x.k === 'pat') && seen[x.k])) continue;
          seen[key] = 1; if (x.k === 'chal') seen.chal = 1; if (x.k === 'show' || x.k === 'pat') seen[x.k] = 1;
          P.acts.push({ k: x.k, c: x.c | 0, f: x.f | 0, d: x.d | 0 });
        }
      }
      if (a.ch != null) P.ch = a.ch | 0;
      if (a.ev != null) P.ev = a.ev | 0;
      if (a.dis != null && findD(dj, a.dis | 0) && !(dj.ev && (dj.ev.a === (a.dis | 0) || dj.ev.b === (a.dis | 0)))) P.dis = a.dis | 0;
      if (dj.ev && dj.ev.k === 'retire' && !findD(dj, P.ev)) { const b = byRating(dj.ds)[0]; P.ev = b ? b.id : 0; }
      P.style = a.style != null ? clamp(a.style | 0, 0, 4) : -1;
      s.pl[seat] = P;
      s.last = { id: ++s.seq, k: 'plan', seat };
      if (s.pl.every(Boolean)) {
        const t0 = tOf(s);
        resolveSeason(s);
        s.last = { id: ++s.seq, k: 'season', t: t0 };
      }
      return s;
    }
    if (s.ph === 'duel') {
      const b = s.B;
      if (!b) throw new Error('no bout');
      const sides = [0, 1].filter((k) => b.sd[k] === seat && b.pk[k] == null && !b.au[k]);
      if (!sides.length) throw new Error('not your bout');
      const side = sides[0];
      if (a.t === 'auto') b.au[side] = 1;
      else if (a.t === 'st') { const v = a.v | 0; if (v < 0 || v > 2) throw new Error('bad stance'); b.pk[side] = v; }
      else throw new Error('bad duel action');
      // 아직 고를 사람이 남았으면 기다림
      if ([0, 1].some((k) => b.sd[k] >= 0 && b.pk[k] == null && !b.au[k])) { s.last = { id: ++s.seq, k: 'pick' }; return s; }
      const t0 = tOf(s);
      const picks = [0, 1].map((k) => (b.pk[k] != null ? b.pk[k] : stanceAI(s, b, k, sideLv(s, b, k))));
      const ex = exchange(s, b, picks[0], picks[1]);
      const info = { bid: b.id, lab: b.lab, nm: b.nm, dn: b.dn, w: b.w, sd: b.sd, sc: b.sc.slice(), n: b.ex.length, ex, fin: -1, dec: 0 };
      b.pk = [null, null];
      // 사람이 모두 맡겼으면 끝까지
      const humansLeft = () => [0, 1].some((k) => b.sd[k] >= 0 && !b.au[k]);
      if (endOf(b) < 0 && !humansLeft()) { while (endOf(b) < 0) exchange(s, b, stanceAI(s, b, 0, sideLv(s, b, 0)), stanceAI(s, b, 1, sideLv(s, b, 1))); info.sc = b.sc.slice(); info.skip = 1; }
      if (endOf(b) >= 0) { closeBout(s, b); info.fin = b.win; info.dec = b.dec; info.sc = b.sc.slice(); advance(s); }
      s.last = { id: ++s.seq, k: 'ex', b: info, t: t0 };
      return s;
    }
    throw new Error('game over');
  }

  function finalScore(s, dj) { return dj.rep + dj.sb.length * 15 - (dj.lost >= 0 ? 15 : 0); }
  function titleOf(s, dj) { return TITLES.find((T) => T.c(dj, s.len)); }
  function result(s) {
    if (s.ph !== 'end') return null;
    const sc = s.dj.map((dj) => finalScore(s, dj));
    const order = s.dj.map((x, i) => i).sort((a, b) => sc[b] - sc[a]);
    const players = order.filter((i) => i < s.n);
    let winners;
    if (s.n === 1) winners = order[0] === 0 ? [0] : [];
    else { const top = sc[players[0]]; winners = players.filter((i) => sc[i] === top); }
    const T = s.dj.slice(0, s.n).map((dj) => titleOf(s, dj));
    const me = winners.length ? winners[0] : players[0];
    const cityRank = order.indexOf(me) + 1;
    return {
      winners,
      title: winners.length ? T[winners[0]].n : '고을 ' + cityRank + '위',   // 도장 이름 · 칭호는 아래 강조 줄에(제목 줄바꿈 방지)
      text: T[me].t,
      highlights: s.dj.slice(0, s.n).map((dj, i) => dj.nm + ' · ' + T[i].n).concat(s.n === 1 ? ['고을 ' + s.dj.length + '개 도장 가운데 ' + cityRank + '위'] : []).slice(0, 4),
      stats: [
        { label: '최종 명성', values: s.dj.slice(0, s.n).map((dj) => String(finalScore(s, dj))) },
        { label: '고을 대회 우승', values: s.dj.slice(0, s.n).map((dj) => String(dj.rec.rw)) },
        { label: '천하 대회 우승', values: s.dj.slice(0, s.n).map((dj) => String(dj.rec.nw)) },
        { label: '가진 현판', values: s.dj.slice(0, s.n).map((dj) => String(dj.sb.length)) },
        { label: '도장 깨기 승·패', values: s.dj.slice(0, s.n).map((dj) => dj.rec.cw + '·' + dj.rec.cl) },
        { label: '가장 강했던 제자', values: s.dj.slice(0, s.n).map((dj) => String(dj.rec.best)) },
        { label: '떠난 제자', values: s.dj.slice(0, s.n).map((dj) => String(dj.rec.left)), low: true },
      ],
    };
  }

  function hint(s, seat) {
    if (s.ph === 'end') return null;
    const me = seat >= 0 ? seat : 0;
    const dj = s.dj[me];
    if (s.ph === 'duel' && s.B) {
      const b = s.B, side = b.sd[0] === me ? 0 : b.sd[1] === me ? 1 : -1;
      const L0 = [b.lab, '선(先)은 허(虛)를, 후(後)는 선을, 허는 후를 이깁니다. 먼저 두 판을 따면 승리, 여섯 합이 지나면 판정.'];
      if (side >= 0) {
        const [fa, fb] = bfighters(s, b), me_ = side ? fb : fa, op = side ? fa : fb;
        const pw = [0, 1, 2].map((k) => Math.round(power(me_, k, ctxOf(b, side))));
        L0.push('지금 내 힘 — 선 ' + pw[0] + ' · 후 ' + pw[1] + ' · 허 ' + pw[2] + '. 이기는 수를 고르면 힘이 낮아도 유리합니다.');
        L0.push('상대 성향: ' + TEMPERS[op.tp].n + (TEMPERS[op.tp].pref >= 0 ? ' — ' + STANCES[TEMPERS[op.tp].pref].n + '를 즐겨 씀' : ' — 즐겨 쓰는 수 없음') + '. 이번 시합에서 상대가 낸 수는 아래 기록에 남습니다.');
        L0.push('「맡긴다」를 누르면 제자가 남은 합을 스스로 치릅니다.');
      } else L0.push('다른 도장의 시합을 지켜보는 중입니다.');
      return L0;
    }
    if (s.pl[me]) return ['이번 계절의 계획을 냈습니다.', '다른 도장이 정하기를 기다리는 중입니다.'];
    const L0 = [s.yr + '년 ' + SEASONS[s.se] + ' — 계절마다 제자의 수련 하나와 도장의 일 두 가지를 정합니다.'];
    if (dj.st < 0) L0.push('먼저 도장의 검풍을 고르십시오. 검풍마다 강한 수와 성과가 큰 수련이 다릅니다.');
    if (dj.ev) L0.push('사건 「' + EV[dj.ev.k].h + '」에 답해야 계절을 보낼 수 있습니다.');
    if (s.se === 2) L0.push('이번 가을은 고을 대회입니다. 출전할 제자를 고르십시오.');
    if (s.se === 3) L0.push(s.semi.includes(me) ? '이번 겨울은 천하 대회입니다. 출전할 제자를 고르십시오.' : '이번 겨울 천하 대회에는 고을 대회 4강만 나갑니다.');
    const inj = dj.ds.filter((d) => d.inj).length;
    if (inj) L0.push('다친 제자 ' + inj + '명은 저절로 쉽니다.');
    if (dj.$ < 10) L0.push('돈이 모자랍니다. 시범 공연이나 후원자 찾기로 살림을 메우십시오.');
    L0.push('명성이 곧 점수입니다. 대회와 도장 깨기에서 이기면 크게 오릅니다.');
    return L0.slice(0, 6);
  }
  /* 모든 판단은 그때그때 점수로 정하고, 도장마다 판 시작 때 정해진 버릇(hab)과 core 성향을 조금 덧칠한다. */
  const styleOf = (seat) => { try { return (L.aiStyle && L.aiStyle(seat)) || 'bal'; } catch (e) { return 'bal'; } };

  /* ---------- 시합: 상대가 낼 수의 확률 ---------- */
  function oppModel(s, b, side, lv) {
    const o = 1 - side;
    const pref = TEMPERS[b.tp[o]].pref;
    const q = [1, 1, 1];
    if (pref >= 0) q[pref] += lv >= 2 ? 1.1 : 1.6;   // 쉬움은 성향만 믿는다
    if (b.tp[o] === 6) { q[0] = q[1] = q[2] = 1; }
    if (lv >= 2) {
      const wt = lv >= 3 ? 0.9 : 0.5;
      for (const e of b.ex) q[+e[o]] += wt;
      const last = b.ex[b.ex.length - 1];
      if (lv >= 3 && last) {
        const op = +last[o], res = +last[2];
        // 한 판을 딴 수는 다시 내기 쉽고, 맞은 사람은 방금 진 수를 이기는 수로 바꾸기 쉽다
        if (res === o + 1) q[op] += 0.8;
        else if (res === side + 1) q[(+last[side] + 1) % 3] += 0.7;
      }
    }
    const t = q[0] + q[1] + q[2];
    return q.map((v) => v / t);
  }
  function stanceAI(s, b, side, lv) {
    const [fa, fb] = bfighters(s, b);
    const me = side ? fb : fa, op = side ? fa : fb;
    const myDojo = b.f[side].d != null ? s.dj[b.f[side].d] : null;
    const read = lv + (myDojo && myDojo.st === 4 ? 1 : 0);
    const q = oppModel(s, b, side, Math.min(3, read));
    const cMe = ctxOf(b, side), cOp = ctxOf(b, 1 - side);
    const myP = [0, 1, 2].map((k) => power(me, k, cMe)), opP = [0, 1, 2].map((k) => power(op, k, cOp));
    const danger = b.sc[1 - side] >= 1 ? 1.3 : 1;   // 한 판만 더 내주면 지는 상황에서는 맞지 않는 쪽에 무게
    const ev = [0, 1, 2].map((k) => { let v = 0; for (let o = 0; o < 3; o++) { const [w, l] = exProb(myP[k], opP[o], k, o); v += q[o] * (w - l * danger); } return v; });
    const pref = TEMPERS[me.tp].pref;
    if (pref >= 0) ev[pref] += lv === 1 ? 0.14 : lv === 2 ? 0.05 : 0.02;
    if (me.tp === 6) for (let k = 0; k < 3; k++) ev[k] += Math.random() * 0.2;
    if (lv >= 3 && Math.random() < 0.12) return ri(3);   // 읽히지 않으려 가끔 섞는다
    const T = lv === 1 ? 0.35 : lv === 2 ? 0.13 : 0.06;
    const mx = Math.max(...ev), w = ev.map((v) => Math.exp((v - mx) / T)), tot = w[0] + w[1] + w[2];
    let r = Math.random() * tot;
    for (let k = 0; k < 3; k++) { r -= w[k]; if (r <= 0) return k; }
    return 2;
  }

  /* ---------- 수련 ---------- */
  function trainUtil(s, dj, d, k, lv, champ) {
    const T = TRAIN[k], ta = TALENTS[d.ta] || TALENTS[0];
    const g = 7.2 * curveF(d.cv, d.ex) * (dj.st >= 0 && STYLES[dj.st].tr === k ? 1.2 : 1) * ((k === 0 || k === 3) ? 1 + 0.15 * dj.fac[2] : 1) * (0.6 + d.mo / 125);
    let v = 0;
    for (let i = 0; i < 4; i++) if (T.g[i]) v += g * T.g[i] * (ta.g ? ta.g[i] : 1) * clamp((d.pot[i] - d.st[i]) / 25, 0, 1) / 4;
    if (T.ms) {
      const mg = Math.min(100 - d.m, g * T.ms * (ta.ms || 1) * (1 + 0.2 * dj.fac[3]));
      v += mg * (lv >= 3 ? 0.1 : 0.06);
      if (lv >= 2) { const nt = TECHS.find((Tc) => Tc.w === d.w && d.m < Tc.m && d.m + mg >= Tc.m); if (nt) v += lv >= 3 ? 2.2 : 1.2; }
    }
    v += T.mo * (d.mo < 35 ? 0.09 : d.mo < 55 ? 0.035 : 0.008);
    if (d.lo < 35) v += T.lo * 0.35;
    if (T.inj) v -= T.inj * (ta.inj || 1) * (1 - 0.2 * dj.fac[1]) * (lv >= 3 && champ ? 30 : 11);
    return v;
  }
  function trainChoice(s, dj, d, lv, champ) {
    if (d.inj) return 5;
    if (lv === 1 && Math.random() < 0.4) return ri(5);
    const nz = lv === 1 ? 0.7 : lv === 2 ? 0.45 : 0.08;
    let best = 0, bv = -1e9;
    for (let k = 0; k < 6; k++) { const v = trainUtil(s, dj, d, k, lv, champ) + (Math.random() - 0.5) * nz; if (v > bv) { bv = v; best = k; } }
    return best;
  }
  function npcTrain(s, i) {
    const dj = s.dj[i], o = {};
    for (const d of dj.ds) o[d.id] = trainChoice(s, dj, d, 2, false);
    return o;
  }

  /* ---------- 출전 제자 ---------- */
  function duelValue(dj, d) {
    const f = Object.assign({}, d, { sty: dj.st, forge: dj.fac[3] });
    const c = { n: 1, sc: [0, 0], after: false, big: false, mo: 0 };
    return avg([0, 1, 2].map((k) => power(f, k, c)));
  }
  function champFor(s, dj, lv) {
    const h = healthy(dj);
    if (!h.length) return null;
    const by = lv >= 3 ? h.slice().sort((a, b) => duelValue(dj, b) - duelValue(dj, a)) : byRating(h);
    return (lv === 1 && by[1] && Math.random() < 0.5 ? by[1] : by[0]).id;
  }

  /* ---------- 도장의 일 ---------- */
  function candValue(s, dj, c, lv, left) {
    if (!c) return -99;
    if (lv === 1) return rating(c) / 9 + Math.random() * 2;
    const pot = avg(c.pot);
    let v = (pot - 52) / 5 + (c.age <= 17 ? 1 : c.age >= 25 ? -1 : 0) + (c.ta && c.ta < 8 ? 0.8 : c.ta >= 8 ? -1 : 0) + 1.5;
    if (lv >= 3 && c.rv) v += c.cv === 1 ? (left > 10 ? 1.5 : -1.5) : c.cv === 0 ? (left < 10 ? 1.2 : 0) : c.cv === 2 ? -0.8 : 0;
    if (lv >= 3) v += (rating(c) - 30) / 12;
    if (dj.ds.length < 3) v += 4;
    return v * clamp(left / 10, 0.3, 1.2);
  }
  function facValue(s, dj, f, lv, h, left) {
    const free = capOf(dj) - dj.ds.length;
    let v;
    if (f === 0) v = free <= 0 ? 5 + (dj.cand.filter(Boolean).length ? 1 : 0) : free === 1 ? 2.5 : 0.8;
    else if (f === 1) v = 1.2 + dj.ds.filter((d) => d.inj).length * 1.4 + (avg(dj.ds.map((d) => d.mo)) < 45 ? 1 : 0);
    else if (f === 2) v = 1.6 + dj.ds.length * 0.4;
    else v = 1.5 + dj.ds.length * 0.35 + (lv >= 3 ? 1 : 0);
    v *= 0.7 + 0.6 * h.fac[f];
    v *= clamp(left / 8, 0.2, 1.4);
    if (lv === 1) v = 2 + Math.random() * 3;
    return v - FAC_COST[dj.fac[f] + 1] / 10 * (0.5 + h.thr);
  }
  function chalValue(s, seat, x, lv, h) {
    const dj = s.dj[seat], T = s.dj[x];
    let pw = winEst(s, seat, x);
    if (lv === 2) pw = clamp(pw + (Math.random() - 0.5) * 0.24, 0, 1);
    if (lv === 1) pw = clamp(0.5 + (dj.rep - T.rep) / 200 + (Math.random() - 0.4) * 0.5, 0, 1);
    let gain = 15 + (T.rep * 0.1 + 8) * 0.6 + (dj.lost === x ? 15 : 0) + (T.sb.length ? 5 : 0);
    if (T.own >= 0 && lv >= 2) gain += 6;   // 경쟁하는 사람 도장의 명성을 깎는 값
    if (lv >= 3 && !dj.sb.includes(x)) gain += 12;   // 끝까지 지키면 현판 하나에 +15
    const loss = 15 + 4 + 4;
    const sty = styleOf(seat);
    const agg = h.agg + (sty === 'agg' ? 0.2 : sty === 'def' ? -0.2 : sty === 'gamble' ? 0.15 : 0) + (lv >= 3 ? 0.25 : 0);   // 어려움은 승산이 있으면 망설이지 않는다
    const burnt = lv >= 2 ? Math.max(0, dj.rec.cl - dj.rec.cw) * 0.6 + (dj.$ < 10 ? 1 : 0) : 0;   // 잇달아 졌거나 돈이 없으면 몸을 사린다
    return (pw * gain - (1 - pw) * loss) / 6 * (0.5 + agg) - burnt;
  }
  function planFor(s, seat, lv) {
    const dj = s.dj[seat], h = s.hab[seat] || habits();
    const left = s.len * 4 - tOf(s);
    const P = { t: 'plan', tr: {}, acts: [], ch: null, ev: 0 };
    if (dj.st < 0) {
      const ws = [0, 0, 0, 0, 0]; dj.ds.forEach((d) => ws[d.w]++);
      const strong = [0, 1, 2].map((k) => dj.ds.reduce((a, d) => a + WEAPONS[d.w].mod[k], 0));
      const best = strong.indexOf(Math.max(...strong));
      P.style = Math.random() < 0.5 ? h.sty : best === 0 ? 1 : best === 1 ? 0 : 2;
    }
    if (dj.ev) {
      const E = EV[dj.ev.k];
      if (dj.ev.k === 'retire') {
        const sc = (d) => (lv === 1 ? Math.random() * 50 : rating(d) + d.lo * (lv >= 3 ? 0.3 : 0.15) - (lv >= 3 ? Math.max(0, d.age - 24) * 0.6 : 0) + (lv >= 3 && d.rv && d.cv === 1 ? 4 : 0));
        P.ev = dj.ds.slice().sort((a, b) => sc(b) - sc(a))[0].id;
      } else if (E && E.op) {
        let bi = 0, bv = -1e9;
        E.op.forEach((o, i) => { const v = (o.ai ? o.ai(s, dj, dj.ev) : 0) + (Math.random() - 0.5) * (lv === 1 ? 6 : lv === 2 ? 1.5 : 0.4); if (v > bv) { bv = v; bi = i; } });
        P.ev = bi;
      }
    }
    // 출전
    const tourSoon = s.se === 2 || (s.se === 3 && s.semi.includes(seat));
    if (tourSoon) P.ch = champFor(s, dj, lv);
    const champNext = s.se === 1 ? champFor(s, dj, lv) : P.ch;
    for (const d of dj.ds) P.tr[d.id] = trainChoice(s, dj, d, lv, d.id === champNext);
    // 일 두 가지
    const opts = [];
    let free = capOf(dj) - dj.ds.length;
    // 자리가 찼고 훨씬 나은 입문자가 있으면 가장 기대가 낮은 제자를 내보낸다(쉬움은 하지 않음)
    if (lv >= 2 && free <= 0 && dj.ds.length >= 3) {
      const keep = (d) => avg(d.pot) * (d.cv === 2 && d.ex >= 5 ? 0.85 : 1) + rating(d) * 0.3 - Math.max(0, d.age - 28) * 1.5;
      const worst = dj.ds.filter((d) => !(dj.ev && (dj.ev.a === d.id || dj.ev.b === d.id))).sort((a, b) => keep(a) - keep(b))[0];
      const bestC = dj.cand.filter(Boolean).sort((a, b) => avg(b.pot) - avg(a.pot))[0];
      if (worst && bestC && avg(bestC.pot) + rating(bestC) * 0.3 > keep(worst) + (lv >= 3 ? 9 : 10) && left > 6) { P.dis = worst.id; free = 1; delete P.tr[worst.id]; }
    }
    dj.cand.forEach((c, i) => { if (c && free > 0) opts.push({ a: { k: 'rec', c: i }, v: candValue(s, dj, c, lv, left), cost: 0 }); });
    for (let f = 0; f < 4; f++) if (dj.fac[f] < 3) opts.push({ a: { k: 'bld', f }, v: facValue(s, dj, f, lv, h, left), cost: FAC_COST[dj.fac[f] + 1] });
    opts.push({ a: { k: 'show' }, v: 1.6 + (dj.$ < 15 ? 4 : dj.$ < 35 ? 2 : 0.4) + h.show * 0.8 + (lv >= 3 && left <= 2 ? 1 : 0), cost: 0 });
    if (dj.pat < 3) { const p = clamp(0.25 + dj.rep / 250 - dj.pat * 0.15, 0.1, 0.85); opts.push({ a: { k: 'pat' }, v: Math.min(5, p * left * 0.45) - (lv === 1 ? 0 : 0.3), cost: 0 }); }
    if (healthy(dj).length >= 3) for (let x = 0; x < s.dj.length; x++) if (chalOk(s, seat, x)) opts.push({ a: { k: 'chal', d: x }, v: chalValue(s, seat, x, lv, h), cost: 0 });
    const nz = lv === 1 ? 2.5 : lv === 2 ? 1.3 : 0.25;
    opts.forEach((o) => (o.v += (Math.random() - 0.5) * nz));
    opts.sort((a, b) => b.v - a.v);
    const reserve = lv === 1 ? -20 : lv === 2 ? 4 : 8 + 4 * h.thr;
    let money = dj.$, recs = 0;
    for (const o of opts) {
      if (P.acts.length >= 2 || o.v <= 0) break;
      const a = o.a;
      if (a.k === 'chal' && P.acts.some((x) => x.k === 'chal')) continue;
      if ((a.k === 'show' || a.k === 'pat') && P.acts.some((x) => x.k === a.k)) continue;
      if (a.k === 'rec' && recs >= free) continue;
      if (o.cost && money - o.cost < reserve) continue;
      money -= o.cost; if (a.k === 'rec') recs++;
      P.acts.push(a);
    }
    return P;
  }

  function ai(s, seat, lv) {
    lv = lv || s.lv[seat] || 2;
    if (s.ph === 'plan') return s.pl[seat] ? null : planFor(s, seat, lv);
    if (s.ph === 'duel' && s.B) {
      const b = s.B;
      const side = b.sd[0] === seat && b.pk[0] == null && !b.au[0] ? 0 : b.sd[1] === seat && b.pk[1] == null && !b.au[1] ? 1 : -1;
      if (side < 0) return null;
      return { t: 'st', v: stanceAI(s, b, side, lv) };
    }
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'plan') return s.pl[seat] ? -1 : 500 + (lv === 1 ? 500 : lv === 2 ? 250 : 0) + seat * 120;
    if (s.ph === 'duel') return 700;
    return -1;
  }
  /* 먹 번지는 산 겹(결정적 시드) — 시합 화면 · 위 막대 · 미리보기가 같이 쓴다 */
  function hills(ctx, W, H, seed, o) {
    o = o || {};
    let sd = seed || 11;
    const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
    const layers = o.layers || [[0.42, 0.10, 0.16], [0.55, 0.16, 0.24], [0.7, 0.26, 0.4]];
    for (const [base, amp, alpha] of layers) {
      const ph = [rnd() * 6, rnd() * 6, rnd() * 6], fr = [1.3 + rnd(), 3 + rnd() * 2, 7 + rnd() * 3];
      const g = ctx.createLinearGradient(0, H * (base - amp), 0, H);
      g.addColorStop(0, 'rgba(34,31,26,' + alpha + ')'); g.addColorStop(0.45, 'rgba(34,31,26,' + alpha * 0.45 + ')'); g.addColorStop(1, 'rgba(34,31,26,0)');
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(0, H);
      for (let x = 0; x <= W; x += 4) {
        const u = x / W;
        const y = H * (base - amp * (0.55 * Math.sin(u * fr[0] * 3.1 + ph[0]) * 0.5 + 0.5) - amp * 0.35 * (Math.sin(u * fr[1] * 3.1 + ph[1]) * 0.5 + 0.5) - amp * 0.12 * Math.sin(u * fr[2] * 3.1 + ph[2]));
        ctx.lineTo(x, y);
      }
      ctx.lineTo(W, H); ctx.closePath(); ctx.fill();
    }
  }
  /* 먹 실루엣 한 사람: dir = 1(오른쪽을 봄)/−1, p = {dx, arm, lean, crouch, arm2} */
  function fighterDraw(x, cx, gy, sc, dir, w, p, alpha) {
    x.save(); x.translate(cx + p.dx * dir * sc, gy); x.scale(dir * sc, sc);
    x.globalAlpha = alpha == null ? 1 : alpha;
    const ink = 'rgba(30,27,23,.92)';
    const cr = p.crouch || 0, lean = p.lean || 0;
    const hipY = -48 + cr * 10, shY = -86 + cr * 14;
    // 하카마(넓은 바지)
    x.fillStyle = ink;
    x.beginPath(); x.moveTo(-6 + lean * 4, hipY); x.lineTo(8 + lean * 4, hipY); x.lineTo(22 + cr * 6, 0); x.lineTo(4, 0); x.lineTo(1, -10); x.lineTo(-2, 0); x.lineTo(-18 - cr * 6, 0); x.closePath(); x.fill();
    // 몸통
    x.beginPath(); x.moveTo(-7 + lean * 4, hipY); x.quadraticCurveTo(-9 + lean * 10, (hipY + shY) / 2, -6 + lean * 16, shY); x.lineTo(8 + lean * 16, shY); x.quadraticCurveTo(10 + lean * 10, (hipY + shY) / 2, 9 + lean * 4, hipY); x.closePath(); x.fill();
    // 머리 · 상투
    const hx = 1 + lean * 18, hy = shY - 11;
    x.beginPath(); x.arc(hx, hy, 7.2, 0, 6.3); x.fill();
    x.beginPath(); x.ellipse(hx - 3, hy - 7, 3.2, 2.4, -0.5, 0, 6.3); x.fill();
    // 팔과 병기
    const sx = 4 + lean * 16, sy = shY + 4;
    const arm = p.arm == null ? -0.5 : p.arm;
    const ax = sx + Math.cos(arm) * 22, ay = sy + Math.sin(arm) * 22;
    x.strokeStyle = ink; x.lineWidth = 6; x.lineCap = 'round';
    x.beginPath(); x.moveTo(sx, sy); x.lineTo(ax, ay); x.stroke();
    const blade = (ang, len, lw) => { x.lineWidth = lw; x.beginPath(); x.moveTo(ax - Math.cos(ang) * 6, ay - Math.sin(ang) * 6); x.lineTo(ax + Math.cos(ang) * len, ay + Math.sin(ang) * len); x.stroke(); };
    if (w === 2) { blade(arm, 64, 2.2); x.beginPath(); x.moveTo(ax + Math.cos(arm) * 64, ay + Math.sin(arm) * 64); x.lineTo(ax + Math.cos(arm - 0.12) * 54, ay + Math.sin(arm - 0.12) * 54); x.lineTo(ax + Math.cos(arm + 0.12) * 54, ay + Math.sin(arm + 0.12) * 54); x.fill(); x.lineWidth = 2.2; x.beginPath(); x.moveTo(ax, ay); x.lineTo(ax - Math.cos(arm) * 26, ay - Math.sin(arm) * 26); x.stroke(); }
    else if (w === 4) blade(arm, 20, 2.6);
    else if (w === 1) { blade(arm, 34, 2.2); const a2 = p.arm2 == null ? arm + 0.9 : p.arm2; const bx = sx - 4 + Math.cos(a2) * 18, by = sy + 2 + Math.sin(a2) * 18; x.lineWidth = 5; x.beginPath(); x.moveTo(sx - 4, sy + 2); x.lineTo(bx, by); x.stroke(); x.lineWidth = 2.2; x.beginPath(); x.moveTo(bx, by); x.lineTo(bx + Math.cos(a2) * 32, by + Math.sin(a2) * 32); x.stroke(); }
    else blade(arm, w === 3 ? 44 : 46, 2.4);
    if (w === 3) { x.lineWidth = 4.5; x.beginPath(); x.moveTo(-2, hipY + 2); x.lineTo(-30, hipY + 12); x.stroke(); }
    x.restore();
  }

  /* ---------- 미리보기(640×360) ---------- */
  function preview(cnv) {
    const c = cnv.getContext('2d'), W = cnv.width, H = cnv.height;
    c.fillStyle = '#e4ddcc'; c.fillRect(0, 0, W, H);
    hills(c, W, H * 0.82, 31);
    const gy = H * 0.82;
    c.fillStyle = 'rgba(34,31,26,.8)'; c.fillRect(0, gy, W, 4);
    c.fillStyle = 'rgba(34,31,26,.07)'; c.fillRect(0, gy + 4, W, H - gy);
    fighterDraw(c, W * 0.56, gy, 1.25, 1, 0, { dx: 0, arm: -1.7, lean: 0.1, crouch: 0.1 });
    fighterDraw(c, W * 0.84, gy, 1.25, -1, 2, { dx: 0, arm: -0.25, lean: 0, crouch: 0.35 });
    c.fillStyle = '#221f1a'; c.textBaseline = 'alphabetic';
    c.font = '64px DojoBrush, DojoHan, "Song Myung", serif'; c.fillText('검술 도장', 34, 122);
    c.font = '18px DojoText, "Gowun Batang", serif'; c.fillStyle = '#4a443a';
    c.fillText('쇠락한 도장을 맡아 제자를 기르고', 36, 162); c.fillText('시합과 도장 깨기로 이름을 되찾는다', 36, 188);
    c.fillStyle = '#9b2d22'; c.fillRect(36, 214, 44, 44);
    c.fillStyle = '#f3e9d6'; c.font = '30px DojoBrush, DojoHan, "Song Myung", serif'; c.textAlign = 'center'; c.fillText('道', 58, 247); c.textAlign = 'left';
  }

  /* ---------- 규칙 그림 ---------- */
  const FIG_RPS = '<svg viewBox="0 0 340 130" xmlns="http://www.w3.org/2000/svg" font-family="serif">' +
    '<g fill="none" stroke="#776f60" stroke-width="1.6"><path d="M150 40 L102 96" marker-end="url(#a)"/><path d="M118 104 L222 104" marker-end="url(#a)"/><path d="M238 96 L190 40" marker-end="url(#a)"/></g>' +
    '<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="#776f60"/></marker></defs>' +
    '<g font-size="26" text-anchor="middle" fill="#221f1a"><text x="170" y="34">後</text><text x="92" y="116">先</text><text x="248" y="116">虛</text></g>' +
    '<g font-size="11" text-anchor="middle" fill="#4a443a"><text x="170" y="14">응수 · 받아친다</text><text x="60" y="128">선수 · 먼저 친다</text><text x="282" y="128">허초 · 흘린다</text>' +
    '<text x="112" y="62">後가 先을 이김</text><text x="170" y="96">先이 虛를 이김</text><text x="236" y="62">虛가 後를 이김</text></g></svg>';

  /* ---------- 도감 ---------- */
  const sv = (k) => svgI(k, 26);
  const condTxt = (T) => TECH_C[T.c] + ' ' + (T.s < 0 ? '모든 수' : STANCES[T.s].n) + ' 힘 +' + T.b;
  function codex() {
    return [
      { h: '수', p: ['합마다 두 사람이 동시에 수 하나를 고른다. 이기는 수를 고른 쪽이 크게 유리하고, 같은 수끼리는 힘으로 겨룬다.', '힘 = 그 수에 쓰는 능력 둘의 평균 + 병기 보정(숙련에 비례) + 검풍 + 기술 + 성향 + 사기 등.'],
        rows: STANCES.map((S_) => ({ icon: '<span style="font:26px DojoBrush,DojoHan,serif">' + S_.han + '</span>', name: S_.n + ' — ' + S_.v, tag: STATS[S_.u[0]] + '·' + STATS[S_.u[1]], desc: S_.d })) },
      { h: '검풍', p: ['첫 봄에 도장마다 하나를 고른다. 판 끝까지 바뀌지 않는다.'],
        rows: STYLES.map((Y) => ({ icon: '<span style="font:20px DojoBrush,DojoHan,serif">' + Y.han + '</span>', name: Y.n, tag: '수 보정 ' + STANCES.map((S_, k) => S_.han + (Y.sb[k] >= 0 ? '+' : '') + Y.sb[k]).join(' ') + ' · ' + TRAIN[Y.tr].n + ' 성과 ×1.2', desc: Y.d })) },
      { h: '병기', p: ['병기마다 수별 보정이 다르다. 보정은 숙련에 비례한다(숙련 0이면 40%, 100이면 100%).'],
        rows: WEAPONS.map((W, wi) => ({ icon: sv(W_ICON[wi]), name: W.n + ' ' + W.han, tag: STANCES.map((S_, k) => S_.han + (W.mod[k] >= 0 ? '+' : '') + W.mod[k]).join(' ') + (W.first ? ' · 첫 합 先+' + W.first[0] : ''), desc: W.d + ' 이 병기를 쓰는 제자는 「' + W.role + '」' + josa(W.role, '이라', '라') + ' 불리기도 한다.' })) },
      { h: '기술', p: ['병기 숙련이 30·60·90에 닿으면 저절로 익힌다. 병기 수련으로 숙련이 가장 빨리 오른다.'],
        rows: TECHS.map((T) => ({ icon: sv(W_ICON[T.w]), name: T.n, tag: WEAPONS[T.w].n + ' · 숙련 ' + T.m, desc: condTxt(T) + '. ' + T.d })) },
      { h: '수련', p: ['계절마다 제자 한 명에 하나. 성과는 성장 곡선 · 나이 · 사기 · 시설 · 검풍 · 계절(여름 단련, 겨울 명상 ×1.2)에 따라 달라진다. 능력은 잠재에 가까울수록 더디게 오른다.'],
        rows: TRAIN.map((T) => ({ icon: '<span style="font:20px DojoBrush,DojoHan,serif">' + T.han + '</span>', name: T.n, tag: (T.inj ? '부상 ' + Math.round(T.inj * 100) + '% · ' : '') + '사기 ' + (T.mo >= 0 ? '+' : '') + T.mo, desc: T.d })) },
      { h: '시설', p: ['도장의 일 하나로 한 단계씩 올린다(최대 3단계). 단계마다 계절 살림살이가 1.5냥 는다.'],
        rows: FAC.map((F, fi) => ({ icon: sv(F_ICON[fi]), name: F.n + ' ' + F.han, tag: '1단계 ' + FAC_COST[1] + ' · 2단계 ' + FAC_COST[2] + ' · 3단계 ' + FAC_COST[3] + '냥', desc: F.d + ' 3단계: ' + F.e(3) + '.' })) },
      { h: '성향', p: ['즐겨 쓰는 수가 있는 성향은 그 수를 고르면 힘 +3. 상대의 성향은 시합 화면에 늘 보인다.'],
        rows: TEMPERS.map((T) => ({ icon: sv('person'), name: T.n, tag: T.pref >= 0 ? STANCES[T.pref].n + '를 즐겨 씀' : '즐겨 쓰는 수 없음', desc: T.d })) },
      { h: '재능 · 성장', p: ['재능은 없거나 하나. 성장 곡선은 두 계절을 지켜보면, 또는 서고가 있으면 드러난다.'],
        rows: TALENTS.slice(1).map((T) => ({ icon: sv('scroll'), name: T.n, tag: '재능', desc: T.d })).concat(CURVES.map((C) => ({ icon: '<span style="font:18px DojoBrush,DojoHan,serif">' + C.han + '</span>', name: C.n, tag: '성장 곡선 · 잠재 ' + (C.pot >= 0 ? '+' : '') + C.pot, desc: C.d }))) },
      { h: '고을의 도장', p: ['판마다 아래 이름 가운데 몇이 고을에 자리 잡는다. 사람이 맡지 않은 도장은 셋 가운데 한 격을 가진다.', '격이 높을수록 시작 명성·제자 수·시설이 크다. 이들도 수련하고, 새 제자를 받고, 서로와 사람의 도장에 도전장을 보낸다.'],
        rows: [['작은 도장', 1], ['중견 도장', 2], ['오래된 명가', 3]].map(([n, l]) => ({ icon: sv('seal'), name: n, tag: '격 ' + l, desc: '제자 ' + (3 + l) + '명 안팎 · 시작 명성 ' + (20 + l * 18) + '~' + (34 + l * 18) + ' · 시설 ' + l + '·' + (l - 1) + '·' + (l - 1) + '·' + (l - 1) + '단계' }))
          .concat(NPC_DOJOS.map((n) => ({ icon: '<span style="font:20px DojoBrush,DojoHan,serif">' + n[0] + '</span>', name: n, tag: '도장 이름', desc: '사범은 판마다 다르다 — ' + MASTERS[NPC_DOJOS.indexOf(n)] + ' 같은 이가 맡는다.' }))) },
      { h: '사건', p: ['계절마다 도장에 일이 생기기도 한다. 답을 고르기 전에 무엇이 바뀌는지 보인다.'],
        rows: EVENTS.filter((E) => E.op).map((E) => ({ icon: sv('scroll'), name: E.h, tag: '사건', desc: E.op.map((o) => '「' + o.t({ dj: [{ nm: '어느 도장' }] }, { ds: [], gone: [] }, { a: -1, b: -1, x: 0, g: 0 }) + '」 ' + o.h).join(' / ') })) },
    ];
  }

  const RULES = [
    { h: '목표', p: ['비가 새는 낡은 도장을 이어받았습니다. 정해진 햇수(기본 5년) 동안 제자를 받아 기르고, 대회와 도장 깨기에 나가 명성을 쌓습니다.',
      '마지막 겨울이 지났을 때 명성이 가장 높은 도장이 이깁니다. 가진 현판 하나에 +15, 내 현판을 빼앗긴 채면 −15.',
      '혼자 할 때는 고을의 모든 도장 가운데 1위가 되어야 이깁니다. 끝나면 도장의 걸음에 맞는 칭호가 붙습니다.'] },
    { h: '계절마다 할 일', p: ['한 해는 봄·여름·가을·겨울 네 계절. 모든 도장이 같은 계절을 동시에 정하고, 모두 내면 계절이 흘러갑니다.',
      '① 제자마다 수련 하나 — 형·대련·단련·명상·병기·휴식. 고르면 예상 성장이 바로 보입니다.',
      '② 도장의 일 두 가지 — 입문자 받기 · 시설 손보기 · 시범 공연 · 후원자 찾기 · 도장 깨기 가운데서. 입문자와 시설은 두 번 골라도 됩니다.',
      '③ 사건이 생겼으면 답을 고릅니다. ④ 가을(고을 대회)·겨울(천하 대회)에는 출전할 제자를 고릅니다.',
      '첫 봄에는 도장의 검풍을 먼저 정합니다.'] },
    { h: '제자', p: ['능력 넷: 기(技, 정확함) · 력(力, 힘) · 속(速, 빠르기) · 심(心, 흔들리지 않음). 실력은 넷의 평균에 숙련을 조금 더한 값입니다.',
      '잠재: 능력마다 오를 수 있는 끝(막대 위의 세로 금). 끝에 가까울수록 더디게 오릅니다.',
      '성장 곡선: 조숙(일찍 피고 멈춤) · 대기만성(늦게 트이고 끝이 높음) · 정체형(빨리 오르다 멈춤) · 꾸준함. 두 계절을 지켜보거나 서고를 두면 드러납니다.',
      '성향은 즐겨 쓰는 수와 마음의 버릇을, 재능은 잘 오르는 능력이나 시합의 강점을 정합니다.',
      '사기가 높을수록 잘 자라고 시합에서 힘이 납니다. 충성이 바닥이면 떠나고, 강한 제자는 다른 도장으로 가기도 합니다.',
      '숙련이 30·60·90에 닿으면 그 병기의 기술을 저절로 익힙니다. 다친 제자는 낫기까지 쉬어야 합니다.',
      '자리가 모자라면 제자 창에서 한 계절에 한 명을 내보낼 수 있습니다.'] },
    { h: '시합', p: ['합마다 두 사람이 동시에 수를 고릅니다. 先(선수, 먼저 친다)은 虛(허초)를, 後(응수, 받아친다)는 先을, 虛는 後를 이깁니다.',
      '이기는 수를 고른 쪽이 크게 유리합니다. 같은 수끼리는 힘으로 겨룹니다. 수 버튼 아래에 지금 내 힘이 보입니다.',
      '먼저 두 판을 따면 이깁니다. 여섯 합이 지나면 딴 판 수, 그다음 유리했던 합 수로 판정합니다.',
      '상대의 성향과 이번 시합에서 낸 수가 화면에 남습니다. 버릇을 읽는 것이 승부입니다.',
      '「맡긴다」를 누르면 남은 합을 제자가 스스로 치릅니다. 옵션 「시합 진행: 제자에게 맡기기」면 모든 시합이 저절로 진행됩니다.'], fig: { svg: FIG_RPS, cap: '수 셋의 관계' } },
    { h: '대회와 도장 깨기', p: ['가을 — 고을 대회: 고을의 모든 도장이 한 명씩, 모자라면 떠돌이 무사가 채워 여덟 명이 겨룹니다. 우승 명성 +36 · 24냥.',
      '겨울 — 천하 대회: 그해 고을 대회 4강에 든 도장과 타지의 고수 넷. 우승 명성 +80 · 60냥.',
      '도장 깨기: 세 판 승부(선봉·중견·대장). 이기면 그 도장의 현판을 떼어 오고 명성을 빼앗습니다. 지면 명성 −15와 사죄금 8냥. 같은 도장에는 네 계절, 다른 도장에는 두 계절이 지나야 다시 도전할 수 있습니다.',
      '다른 도장도 도전장을 보냅니다. 응하면 현판을 걸고, 거절하면 명성이 깎입니다. 빼앗긴 현판은 그 도장을 꺾으면 되찾습니다.'] },
    { h: '사범과 후계', p: ['늙은 사범은 판의 절반쯤에서 물러납니다. 제자 가운데 한 명을 골라 도장을 잇게 합니다.',
      '이어받은 제자는 사범이 되어 도장 깨기에서 제자가 모자랄 때 나섭니다. 그보다 강하고 충성이 낮은 제자는 고개를 숙이지 않고 떠날 수 있습니다.'] },
    { h: '살림', p: ['계절마다 제자의 수업료(명성이 높을수록 많음)와 후원금이 들어오고, 살림살이(기본 3 + 시설 + 제자 수)가 나갑니다.',
      '시범 공연은 돈과 명성을 조금, 후원자는 계절마다 5냥을 줍니다(최대 셋).',
      '빚을 지면 제자의 사기와 충성이 떨어지고, 빚이 깊으면 제자가 떠납니다.'] },
    { h: '조작', p: ['제자 카드를 누르면 자세한 창(병기 바꾸기·내보내기). 아래 여섯 칸으로 수련을 고릅니다.',
      '도장의 일 버튼을 누르면 고르는 창이 열립니다. 고른 일은 아래 목록에서 ×로 뺍니다.',
      '시합: 수 버튼(先·後·虛)을 누르면 그 수를 바로 냅니다. 버튼마다 지금 그 수의 힘이 적혀 있습니다.',
      '아래 「고을」은 모든 도장의 순위와 지난 대회, 「기록」은 지난 계절의 일과 시합(다시 보기)입니다.',
      'PC: Space 계절을 보낸다 · 1·2·3 先·後·虛를 낸다 · C 고을 · R 기록.'] },
    { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있습니다. 어려움은 성장과 승산을 꼼꼼히 따지고, 시합에서 상대의 버릇을 더 잘 읽습니다.',
      'AI 도장마다 도전을 즐기는 정도·씀씀이·좋아하는 시설 같은 버릇이 판마다 달라집니다.'] },
    { h: '만든 사람', p: ['제목 글꼴: Song Myung — The SongMyung Project Authors, SIL Open Font License 1.1 (Google Fonts). 이 게임에 쓰는 글자만 남긴 부분 글꼴.',
      '본문 글꼴: Gowun Batang — The Gowun Batang Project Authors, SIL Open Font License 1.1 (Google Fonts). 이 게임에 쓰는 글자만 남긴 부분 글꼴.',
      '먹 산수·실루엣·아이콘·종이 결: 이 게임을 위해 코드로 직접 그렸습니다(CC0). 효과음은 앱의 합성음입니다.'] },
  ];

  /* 글꼴 선언은 게임 밖(도감·미리보기)에서도 쓰이게 문서에 한 번 둔다 */
  try {
    if (typeof document !== 'undefined' && !document.getElementById('dojo-fonts')) {
      const st = document.createElement('style'); st.id = 'dojo-fonts';
      st.textContent = ['brush:DojoBrush', 'text:DojoText', 'han:DojoHan'].map((x) => { const [f, n] = x.split(':'); return '@font-face{font-family:"' + n + '";src:url("assets/dojo/' + f + '.woff2") format("woff2");font-display:swap}'; }).join(' ');
      document.head.append(st);
    }
  } catch (e) { /* 글꼴이 없어도 기본 명조로 그린다 */ }

  L.register({
    id: ID, name: '검술 도장', tag: '도장 경영·육성', cat: '전략', time: '30–60분',
    blurb: '쇠락한 검술 도장을 맡아 제자를 받고 수련을 짭니다. 가을의 고을 대회, 겨울의 천하 대회, 현판을 건 도장 깨기를 치르며 명성을 되찾습니다. 1~4명이 같은 고을의 다른 도장을 맡아 겨룹니다.',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, fixedOrder: true, undo: false, save: true, mood: 'calm', ambient: 'wind',
    saveLabel: (s) => s.yr + '년째 ' + SEASONS[s.se] + ' · ' + (s.dj[0] ? s.dj[0].nm + ' 명성 ' + s.dj[0].rep : ''),
    icon: '<path d="M30 8a20 20 0 1 0 19 15" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><path d="M15 43 L43 15" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M17 34 L24 41" stroke="currentColor" stroke-width="4.5" stroke-linecap="round"/><rect x="40" y="38" width="10" height="10" fill="currentColor"/>',
    tint: '#3a2622',
    quick: [
      '계절마다 제자의 수련 하나와 도장의 일 두 가지를 정합니다. 모든 도장이 동시에 정합니다.',
      '가을 고을 대회, 겨울 천하 대회, 현판을 건 도장 깨기 — 시합은 합마다 先·後·虛 가운데 하나를 고르는 수 싸움입니다.',
      '정해진 햇수가 지나면 명성이 가장 높은 도장이 이깁니다. 혼자면 고을 1위가 목표입니다.',
    ],
    rules: RULES,
    tutorial: [
      { sel: '.dj-top', text: '도장의 이름과 살림. 냥은 돈, 명성은 점수입니다. 아래 가는 줄은 남은 계절입니다.' },
      { sel: '.dj-dcard', text: '제자 카드. 누르면 자세히 봅니다. 아래 여섯 칸에서 이번 계절의 수련을 고르면 예상 성장이 보입니다.' },
      { sel: '.dj-actbox', text: '도장의 일 두 가지. 입문자를 받고, 시설을 손보고, 돈을 벌고, 다른 도장에 도전합니다.' },
      { sel: '.dj-go', text: '다 정했으면 계절을 보냅니다. 모든 도장이 내면 계절이 흐르고 기록이 펼쳐집니다.' },
    ],
    controls: [
      { id: 'go', label: '계절을 보낸다', keys: ['Space'], pad: ['a'] },
      { id: 's0', label: '先 선수를 낸다', keys: ['Digit1'], pad: ['left'] },
      { id: 's1', label: '後 응수를 낸다', keys: ['Digit2'], pad: ['up'] },
      { id: 's2', label: '虛 허초를 낸다', keys: ['Digit3'], pad: ['right'] },
    ],
    options: [
      { id: 'len', label: '판 길이', tip: '몇 해 동안 도장을 꾸리는지. 한 해는 네 계절, 가을·겨울마다 대회.', choices: [{ v: '3', label: '짧게 3년' }, { v: '5', label: '보통 5년' }, { v: '8', label: '길게 8년' }], def: '5' },
      { id: 'city', label: '고을의 도장', tip: '사람이 맡은 도장을 포함한 고을의 도장 수. 나머지는 AI 도장.', choices: [{ v: '4', label: '넷' }, { v: '6', label: '여섯' }, { v: '8', label: '여덟' }], def: '6' },
      { id: 'duel', label: '시합 진행', tip: '사람이 맡은 제자의 시합을 합마다 고를지, 제자에게 맡길지.', choices: [{ v: 'pick', label: '합마다 고르기', tip: '수 싸움을 직접 한다' }, { v: 'auto', label: '제자에게 맡기기', tip: '경영만 한다 · 기록에서 다시 보기' }], def: 'pick' },
    ],
    init, actor, apply, ai, aiDelayFor, result, hint, mount, preview, codex: codex(),
    onCancel() { const e = new Event('lounge-cancel', { cancelable: true }); window.dispatchEvent(e); return e.defaultPrevented; },
    panelInfo(s, seat) {
      if (!s || !s.dj) return null;
      const dj = s.dj[seat >= 0 ? seat : 0]; if (!dj) return null;
      return [{ label: '계절', value: s.yr + '년째 ' + SEASONS[s.se] }, { label: '냥', value: String(dj.$) }, { label: '명성', value: dj.rep + ' · ' + fameOf(dj.rep) }, { label: '제자', value: dj.ds.length + '/' + capOf(dj) }, { label: '검풍', value: dj.st >= 0 ? STYLES[dj.st].n : '미정' }, { label: '현판', value: String(dj.sb.length) + (dj.lost >= 0 ? ' · 잃음' : '') }];
    },
    _t: { rating, winEst, power, exProb, stanceAI },
  });
  function mount(root, api) {
    const h = L.h;
    const spd = () => Math.max(0.2, ((L.debug && L.debug.speed) || 1) * ((L.speed && L.speed()) || 1));
    const fx = () => (L.fx ? L.fx() : 1);
    const ASSET = 'assets/dojo/';
    const CSS = `
@font-face{font-family:"DojoBrush";src:url("${ASSET}brush.woff2") format("woff2");font-display:swap}
@font-face{font-family:"DojoText";src:url("${ASSET}text.woff2") format("woff2");font-display:swap}
@font-face{font-family:"DojoHan";src:url("${ASSET}han.woff2") format("woff2");font-display:swap}
.dj{word-break:keep-all;overflow-wrap:break-word;--p0:#e4ddcc;--p1:#d8cfbb;--p2:#cbc0a8;--ink:#221f1a;--ink2:#4a443a;--mute:#5a5346;--line:rgba(34,31,26,.2);--red:#9b2d22;--redw:rgba(155,45,34,.1);
  position:absolute;inset:0;display:flex;flex-direction:column;color:var(--ink);background:var(--p0);font:14px/1.5 "DojoText","DojoHan","Gowun Batang","Nanum Myeongjo","Noto Serif KR",serif;overflow:hidden;user-select:none;-webkit-user-select:none}
.dj *{box-sizing:border-box}
.dj .br{font-family:"DojoBrush","DojoHan","Song Myung","DojoText",serif;font-weight:400;letter-spacing:.02em}
.dj-paper{position:absolute;inset:0;pointer-events:none;opacity:.55;background-size:256px 256px}
.dj-top{position:relative;flex:none;padding:8px 56px 6px 12px;border-bottom:1px solid var(--line);background:linear-gradient(#e4ddcc00,#e4ddccee 70%),var(--hills) center 30%/cover no-repeat}
.dj-top .r1{display:flex;align-items:center;gap:10px;min-height:44px}
.dj-seal{flex:none;width:40px;height:40px;border-radius:3px;background:var(--red);color:#f3e9d6;display:grid;place-items:center;font-size:24px;line-height:1;box-shadow:inset 0 0 0 2px rgba(243,233,214,.35)}
.dj-seal.sm{width:28px;height:28px;font-size:17px}
.dj-seal.npc{background:var(--ink2)}
.dj-nm{font-size:22px;line-height:1.1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dj-sub{font-size:12.5px;color:var(--mute);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dj-top .r2{display:flex;flex-wrap:wrap;gap:4px 12px;margin-top:4px;font-size:13px;color:var(--ink2)}
.dj-top .r2 b{font-weight:400;color:var(--ink);font-variant-numeric:tabular-nums}
.dj-prog{display:flex;gap:2px;margin-top:6px;height:4px}
.dj-prog i{flex:1;background:var(--line)}
.dj-prog i.on{background:var(--ink2)}.dj-prog i.now{background:var(--red)}
.dj-main{position:relative;flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;touch-action:pan-y;padding:10px 12px 18px;-webkit-overflow-scrolling:touch}
.dj-now{font-size:13px;color:var(--ink2);margin:2px 0 10px;padding-left:10px;border-left:2px solid var(--red)}
.dj-h{display:flex;align-items:baseline;gap:8px;margin:16px 0 8px;font-size:18px}
.dj-h small{font-family:"DojoText","DojoHan",serif;font-size:12.5px;color:var(--mute)}
.dj-card{position:relative;background:rgba(255,251,240,.42);border:1px solid var(--line);border-radius:4px;padding:10px;margin-bottom:8px}
.dj-card.sel{border-color:var(--red);box-shadow:inset 0 0 0 1px var(--red)}
.dj-card.need{border-color:var(--red);border-left-width:3px}
.dj-card.flash{animation:djFlash .9s 2}
@keyframes djFlash{50%{background:rgba(155,45,34,.16)}}
.dj-ev h4{margin:0 0 4px;font-size:18px}
.dj-ev p{margin:0 0 8px;color:var(--ink2)}
.dj-opt{display:block;width:100%;text-align:left;min-height:48px;margin:6px 0 0;padding:7px 10px;border:1px solid var(--line);border-radius:4px;background:rgba(255,251,240,.6);color:var(--ink);font:inherit;cursor:pointer}
.dj-opt b{display:block;font-weight:400;font-size:15px}
.dj-opt span{display:block;font-size:13px;color:var(--ink2);line-height:1.4}
.dj-opt.on{border-color:var(--red);background:var(--redw);box-shadow:inset 3px 0 0 var(--red)}
.dj-opt:disabled{background:transparent;border-style:dashed;color:var(--mute);cursor:default}
.dj-opt:disabled b{color:var(--mute)}
.dj-opt:active:not(:disabled),.dj-act:active:not(:disabled),.dj-chip:active:not(:disabled),.dj-btn:active:not(:disabled),.dj-ch button:active{filter:brightness(.9)}
.dj-d{display:flex;gap:10px;align-items:flex-start;cursor:pointer}
.dj-por{flex:none;width:46px;height:56px;border-radius:3px;background:rgba(34,31,26,.06);overflow:hidden}
.dj-por svg{display:block}
.dj-dt{flex:1;min-width:0}
.dj-dn{display:flex;align-items:baseline;gap:6px}
.dj-dn .br{font-size:17px;line-height:1.2;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dj-rt{font-size:20px;font-variant-numeric:tabular-nums;color:var(--ink)}
.dj-rt small{font-size:12px;color:var(--mute);margin-right:3px}
.dj-dm{font-size:12.5px;color:var(--ink2);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dj-sts{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:4px}
.dj-st{font-size:13px;color:var(--ink);font-variant-numeric:tabular-nums;white-space:nowrap}
.dj-bar{position:relative;height:4px;background:var(--line);margin-top:2px}
.dj-bar i{position:absolute;left:0;top:0;bottom:0;background:var(--ink2)}
.dj-bar u{position:absolute;top:-3px;width:2px;height:10px;background:var(--red)}
.dj-mm{display:flex;gap:4px 10px;margin-top:4px;font-size:12.5px;color:var(--ink2);flex-wrap:wrap}
.dj-mm .bad{color:var(--red);font-weight:700}
.dj-tr{display:grid;grid-template-columns:repeat(6,1fr);gap:4px;margin-top:8px}
.dj-chip{min-height:44px;border:1px solid rgba(34,31,26,.35);border-radius:3px;background:rgba(255,251,240,.55);color:var(--ink);font:inherit;font-size:14px;padding:0 2px;cursor:pointer}
.dj-chip.on{background:var(--ink);color:var(--p0);border-color:var(--ink)}
.dj-chip:disabled{background:transparent;border-style:dashed;color:var(--mute);cursor:default}
.dj-chip.on:disabled{opacity:1;background:var(--ink2);color:var(--p0);border-style:solid;border-color:var(--ink2)}
.dj-gain{margin-top:5px;font-size:13px;color:var(--ink2);min-height:18px}
.dj-gain .w{color:var(--red);font-weight:700}
.dj-acts{display:grid;grid-template-columns:1fr 1fr;gap:6px}
.dj-act{min-height:56px;border:1px solid rgba(34,31,26,.35);border-radius:4px;background:rgba(255,251,240,.55);font:inherit;color:var(--ink);text-align:left;padding:6px 8px 6px 34px;position:relative;cursor:pointer}
.dj-act svg{position:absolute;left:8px;top:50%;transform:translateY(-50%);color:var(--ink2)}
.dj-act b{display:block;font-weight:400;font-size:15px}
.dj-act span{display:block;font-size:12.5px;color:var(--ink2);line-height:1.3}
.dj-act:disabled{background:transparent;border-style:dashed;color:var(--mute);cursor:default}
.dj-act:disabled span,.dj-act:disabled svg{color:var(--mute)}
.dj-picked{display:flex;flex-direction:column;gap:6px;margin:8px 0 2px}
.dj-pk{display:flex;align-items:center;gap:8px;padding:4px 4px 4px 10px;border:1px solid var(--red);border-radius:4px;background:var(--redw);min-height:48px}
.dj-pk div{flex:1;min-width:0;font-size:14px}
.dj-pk div span{display:block;font-size:12.5px;color:var(--ink2)}
.dj-x{flex:none;width:44px;height:44px;border:0;background:none;font:inherit;font-size:20px;color:var(--ink2);cursor:pointer}
.dj-ch{display:flex;flex-wrap:wrap;gap:6px}
.dj-ch button{min-height:44px;padding:4px 10px;border:1px solid rgba(34,31,26,.35);border-radius:3px;background:rgba(255,251,240,.55);font:inherit;color:var(--ink);cursor:pointer;max-width:100%}
.dj-ch button.on{border-color:var(--red);background:var(--redw);box-shadow:inset 0 -3px 0 var(--red);font-weight:700}
.dj-ch button:disabled{border-style:dashed;color:var(--ink2);cursor:default}
.dj-news{font-size:13px;color:var(--ink2);line-height:1.6}
.dj-news div{border-bottom:1px dotted var(--line);padding:3px 0}
.dj-bot{flex:none;display:flex;gap:6px;padding:8px 12px calc(8px + env(safe-area-inset-bottom));border-top:1px solid var(--line);background:rgba(216,207,187,.6)}
.dj-btn{min-height:46px;padding:0 14px;border:1px solid var(--ink2);border-radius:4px;background:transparent;color:var(--ink);font:inherit;font-size:15px;cursor:pointer}
.dj-btn.pri{flex:1;background:var(--ink);color:var(--p0);border-color:var(--ink)}
.dj-btn.pri.red{background:var(--red);border-color:var(--red);color:#f6eedd}
.dj-btn:disabled{cursor:default;border-style:dashed}
.dj-btn.pri:disabled,.dj-btn.pri.red:disabled{background:var(--p2);color:var(--ink2);border-color:var(--ink2)}
.dj-wait{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}
.dj-wait span{font-size:13px;padding:4px 10px;border:1px solid var(--line);border-radius:3px}
.dj-wait span.ok{border-color:var(--ink2);color:var(--ink)}
.dj-wait span.no{color:var(--mute);border-style:dashed}
.dj-tabs{display:flex;gap:6px;margin-bottom:8px}
.dj-tabs button{flex:1;min-height:44px;border:1px solid var(--line);border-radius:3px;background:none;font:inherit;color:var(--ink2);cursor:pointer}
.dj-tabs button.on{border-color:var(--ink);color:var(--ink);box-shadow:inset 0 -2px 0 var(--red)}
.dj-shade{position:absolute;inset:0;z-index:40;background:rgba(20,18,15,.38);display:flex;align-items:flex-end;justify-content:center}
.dj-sheet{position:relative;width:100%;max-width:560px;max-height:88%;display:flex;flex-direction:column;background:var(--p0);border-top:2px solid var(--ink);box-shadow:0 -8px 30px rgba(0,0,0,.25)}
.dj-sheet header{display:flex;align-items:center;gap:8px;padding:10px 6px 8px 14px;border-bottom:1px solid var(--line)}
.dj-sheet header h3{flex:1;margin:0;font-size:20px;font-weight:400;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dj-sheet .bd{overflow-y:auto;touch-action:pan-y;padding:10px 14px 16px}
.dj-sheet .ft{display:flex;gap:6px;padding:8px 14px calc(10px + env(safe-area-inset-bottom));border-top:1px solid var(--line)}
.dj-kv{display:grid;grid-template-columns:auto 1fr;gap:3px 12px;font-size:13.5px;margin:6px 0}
.dj-kv dt{color:var(--mute)}.dj-kv dd{margin:0}
.dj-tbl{width:100%;border-collapse:collapse;font-size:13px}
.dj-tbl td{padding:6px 4px;border-bottom:1px solid var(--line);vertical-align:middle}
.dj-tbl td.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
.dj-rpl{font-size:13px;line-height:1.55;color:var(--ink2);margin:0;padding:0;list-style:none}
.dj-rpl li{padding:4px 0;border-bottom:1px dotted var(--line)}
.dj-rpl li.hd{color:var(--ink);border-bottom:0;padding-top:10px;font-family:"DojoBrush","DojoHan","DojoText",serif;font-size:16px}
.dj-exs{display:inline-flex;gap:3px;margin-left:4px;vertical-align:middle}
.dj-exs i{font-style:normal;font-size:11px;padding:0 3px;border:1px solid var(--line);border-radius:2px;color:var(--mute)}
.dj-exs i.a{color:var(--ink);border-color:var(--ink2)}.dj-exs i.b{color:var(--red);border-color:var(--red)}
.dj-duel{position:absolute;inset:0;z-index:30;display:none;flex-direction:column;background:var(--p0)}
.dj-duel.on{display:flex}
.dj-dh{flex:none;padding:10px 56px 4px 12px;text-align:left}
.dj-dh .br{font-size:19px;line-height:1.2}
.dj-dh .dj-sub{margin-top:1px}
.dj-pl{flex:none;display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:4px 12px}
.dj-pt{min-width:0}
.dj-pt.r{text-align:right}
.dj-pt .br{font-size:16px;line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dj-pt .dj-sub{font-size:12.5px;white-space:normal}
.dj-pt.me .br{color:var(--red)}
.dj-pt.me .dj-sub::before{content:'우리 · ';color:var(--red)}
.dj-pips{display:flex;gap:5px;margin-top:3px}
.dj-pt.r .dj-pips{justify-content:flex-end}
.dj-pips i{width:12px;height:12px;border-radius:50%;border:1.5px solid var(--ink2)}
.dj-pips i.on{background:var(--red);border-color:var(--red)}
.dj-cv{position:relative;flex:1;min-height:150px}
.dj-cv canvas{position:absolute;inset:0;width:100%;height:100%}
.dj-log{flex:none;padding:4px 14px;min-height:64px;font-size:13.5px;line-height:1.45;color:var(--mute)}
.dj-log div{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.dj-log div:last-child{color:var(--ink)}
.dj-ctl{flex:none;padding:6px 12px calc(10px + env(safe-area-inset-bottom));border-top:1px solid var(--line)}
.dj-opp{font-size:13px;color:var(--ink2);margin-bottom:6px;line-height:1.45}
.dj-sts3{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.dj-sb{min-height:76px;border:1px solid var(--ink2);border-radius:4px;background:rgba(255,251,240,.6);font:inherit;color:var(--ink);cursor:pointer;padding:4px 2px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px}
.dj-sb .br{font-size:26px;line-height:1}
.dj-sb span{font-size:13px;color:var(--ink);line-height:1.25}
.dj-sb em{font-style:normal;font-size:12.5px;color:var(--ink2);font-variant-numeric:tabular-nums}
.dj-sb.on{background:var(--ink);color:var(--p0)}.dj-sb.on span,.dj-sb.on em{color:var(--p1)}
.dj-sb:disabled{border-style:dashed;color:var(--mute);cursor:default}
.dj-sb.on:disabled{color:var(--p0);border-style:solid}
.dj-sb:active:not(:disabled){background:var(--ink);color:var(--p0)}
.dj-sb:active:not(:disabled) span,.dj-sb:active:not(:disabled) em{color:var(--p1)}
.dj-row{display:flex;gap:6px;align-items:center;margin-top:6px}
.dj-row .dj-sub{flex:1;white-space:normal}
.dj-cur{position:absolute;inset:0;z-index:45;background:var(--p0);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center}
.dj-cur .br{font-size:24px}
@media (min-width:700px){.dj-main{padding:14px max(20px,calc((100% - 760px) / 2)) 24px}.dj-acts{grid-template-columns:repeat(3,1fr)}.dj-top{padding-left:max(12px,calc((100% - 760px) / 2))}.dj-bot{padding-inline:max(12px,calc((100% - 760px) / 2))}}
`;
    const styleEl = h('style', { text: CSS });
    document.head.append(styleEl);

    /* ---------- 종이 결 · 먹 산 ---------- */
    function paperURL() {
      try {
        const c = document.createElement('canvas'); c.width = c.height = 256;
        const x = c.getContext('2d'), im = x.createImageData(256, 256);
        let sd = 7;
        const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
        for (let i = 0; i < im.data.length; i += 4) { const v = 128 + (rnd() - 0.5) * 60; im.data[i] = v; im.data[i + 1] = v - 4; im.data[i + 2] = v - 14; im.data[i + 3] = 22; }
        x.putImageData(im, 0, 0);
        x.strokeStyle = 'rgba(90,80,60,.10)'; x.lineWidth = 0.6;
        for (let i = 0; i < 70; i++) { const a = rnd() * 6.28, l = 6 + rnd() * 24, px = rnd() * 256, py = rnd() * 256; x.beginPath(); x.moveTo(px, py); x.quadraticCurveTo(px + Math.cos(a + 0.6) * l * 0.5, py + Math.sin(a + 0.6) * l * 0.5, px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke(); }
        return c.toDataURL();
      } catch (e) { return ''; }
    }
    function hillsURL(w, hh) {
      try { const c = document.createElement('canvas'); c.width = w; c.height = hh; hills(c.getContext('2d'), w, hh, 23, { layers: [[0.75, 0.35, 0.10], [0.9, 0.3, 0.14]] }); return c.toDataURL(); } catch (e) { return ''; }
    }

    /* ---------- 제자 초상(먹 실루엣, 시드는 id) ---------- */
    function figSVG(d, w, hh) {
      const id = (d && d.id) || 1;
      let sd = id * 7919 + 13;
      const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
      const tone = 0.62 + rnd() * 0.3, hair = ri3(rnd), wt = d ? d.w : 0;
      const ink = 'rgba(34,31,26,' + tone.toFixed(2) + ')';
      const hairP = hair === 0 ? '<ellipse cx="23" cy="9" rx="4" ry="3.2" fill="' + ink + '"/>' : hair === 1 ? '<path d="M15 15 Q23 5 31 15 L31 19 Q23 12 15 19Z" fill="' + ink + '"/>' : '<path d="M16 17 Q23 8 30 17 L33 26 Q29 20 28 18 Q23 13 18 18 Z" fill="' + ink + '"/>';
      const wp = wt === 0 ? '<path d="M36 3 L14 52" stroke="' + ink + '" stroke-width="1.7"/><path d="M31 9 L38 12" stroke="' + ink + '" stroke-width="2.4"/>'
        : wt === 1 ? '<path d="M10 4 L38 50 M36 4 L8 50" stroke="' + ink + '" stroke-width="1.5"/><path d="M8 9 L14 5 M32 5 L38 9" stroke="' + ink + '" stroke-width="2.2"/>'
        : wt === 2 ? '<path d="M38 0 L38 56" stroke="' + ink + '" stroke-width="1.5"/><path d="M38 0 L36 6 L40 6 Z" fill="' + ink + '"/>'
        : wt === 3 ? '<path d="M8 40 L40 28" stroke="' + ink + '" stroke-width="3" stroke-linecap="round"/><path d="M8 40 L12 38" stroke="' + ink + '" stroke-width="4"/>'
        : '<path d="M36 30 L42 44" stroke="' + ink + '" stroke-width="1.8"/><path d="M34 32 L39 29" stroke="' + ink + '" stroke-width="2"/>';
      return '<svg viewBox="0 0 46 56" width="' + (w || 46) + '" height="' + (hh || 56) + '" aria-hidden="true">' + wp +
        '<circle cx="23" cy="19" r="7.5" fill="' + ink + '"/>' + hairP +
        '<path d="M6 56 Q7 34 17 29 L23 36 L29 29 Q39 34 40 56 Z" fill="' + ink + '"/>' +
        '<path d="M17 29 L23 42 L29 29" fill="none" stroke="rgba(228,221,204,.55)" stroke-width="1.2"/></svg>';
    }
    function ri3(rnd) { return Math.floor(rnd() * 3); }

    /* ---------- 상태 ---------- */
    let S = null, curSeat = null, lastId = -1, draft = {}, sheetEl = null, destroyed = false, lastRenderT = '';
    const R0 = h('div', { class: 'dj' });
    const paper = h('div', { class: 'dj-paper' });
    const pu = paperURL(); if (pu) paper.style.backgroundImage = 'url(' + pu + ')';
    const top = h('div', { class: 'dj-top' });
    const hu = hillsURL(400, 90); if (hu) top.style.setProperty('--hills', 'url(' + hu + ')');
    const main = h('div', { class: 'dj-main' });
    const bot = h('div', { class: 'dj-bot' });
    const duel = h('div', { class: 'dj-duel' });
    R0.append(paper, top, main, bot, duel);
    root.append(R0);

    const mySeats = () => api.mySeats();
    function viewSeat() {
      const m = mySeats();
      if (!S) return 0;
      if (curSeat != null && m.includes(curSeat)) return curSeat;
      if (m.length) {
        const act = actor(S);
        const want = Array.isArray(act) ? m.find((x) => act.includes(x)) : null;
        return want != null ? want : m[0];
      }
      return 0;
    }
    const canPlan = (seat) => S && S.ph === 'plan' && api.canAct(seat) && !S.pl[seat];
    const keyOf = (seat) => seat + ':' + tOf(S);
    function D(seat) {
      const k = keyOf(seat);
      if (!draft[k]) {
        const dj = S.dj[seat];
        const tr = {}; dj.ds.forEach((d) => (tr[d.id] = d.inj ? 5 : d.tr || 0));
        let ch = null;
        const hl = byRating(healthy(dj));
        if (hl.length) ch = hl[0].id;
        draft[k] = { tr, acts: [], ch, ev: dj.ev ? (dj.ev.k === 'retire' ? (byRating(dj.ds)[0] || {}).id : null) : null, style: dj.st < 0 ? null : dj.st, wch: {}, dis: null };
        for (const kk in draft) if (kk !== k && kk.split(':')[1] !== String(tOf(S))) delete draft[kk];
      }
      return draft[k];
    }

    /* ---------- 위 막대 ---------- */
    function renderTop(seat) {
      const dj = S.dj[seat];
      const T = S.len * 4, now = tOf(S);
      const rank = S.dj.filter((x) => finalScore(S, x) > finalScore(S, dj)).length + 1;
      const prog = h('div', { class: 'dj-prog' });
      for (let i = 0; i < T; i++) prog.append(h('i', { class: i < now ? 'on' : i === now && S.ph !== 'end' ? 'now' : '' }));
      top.replaceChildren(
        h('div', { class: 'r1' },
          h('div', { class: 'dj-seal br', text: dj.nm[0] }),
          h('div', { style: { minWidth: 0, flex: 1 } },
            h('div', { class: 'dj-nm br', text: dj.nm }),
            h('div', { class: 'dj-sub', text: (S.ph === 'end' ? '마지막 겨울을 보냈다' : S.yr + '년째 ' + SEASONS[S.se] + ' · 남은 계절 ' + (T - now)) + ' · ' + (S.pn[seat] || '') + (dj.st >= 0 ? ' · ' + STYLES[dj.st].n : '') }))),
        h('div', { class: 'r2' },
          h('span', null, '냥 ', h('b', { text: String(dj.$) })),
          h('span', null, '명성 ', h('b', { text: String(dj.rep) }), ' · ' + fameOf(dj.rep)),
          h('span', null, '제자 ', h('b', { text: dj.ds.length + '/' + capOf(dj) })),
          h('span', null, '고을 ', h('b', { text: rank + '위' })),
          dj.sb.length ? h('span', null, '현판 ', h('b', { text: String(dj.sb.length) })) : null,
          dj.lost >= 0 ? h('span', { style: { color: 'var(--red)' }, text: '현판 잃음' }) : null),
        prog);
    }

    /* ---------- 예상 성장(보여 주기용 기대값) ---------- */
    function expect(dj, d, k) {
      const T = TRAIN[k], ta = TALENTS[d.ta] || TALENTS[0];
      if (d.inj) k = 5;
      const g = 7.2 * curveF(d.cv, d.ex) * (1 + 0.05 * dj.fac[0]) * (dj.st >= 0 && STYLES[dj.st].tr === k ? 1.2 : 1) * ((S.se === 1 && k === 2) || (S.se === 3 && k === 3) ? 1.2 : 1) * ((k === 0 || k === 3) ? 1 + 0.15 * dj.fac[2] : 1) * (d.age <= 18 ? 1.15 : d.age <= 25 ? 1 : d.age <= 32 ? 0.8 : 0.55) * (0.6 + d.mo / 125);
      const st = [0, 1, 2, 3].map((i) => (T.g[i] ? g * T.g[i] * (ta.g ? ta.g[i] : 1) * Math.max(0, Math.min(1, (d.pot[i] - d.st[i]) / 25)) : 0));
      const m = T.ms ? Math.min(100 - d.m, g * T.ms * (ta.ms || 1) * (1 + 0.2 * dj.fac[3])) : 0;
      const inj = T.inj ? T.inj * (ta.inj || 1) * (1 - 0.2 * dj.fac[1]) * (dj.st === 3 ? 0.75 : 1) * (d.mo < 30 ? 1.3 : 1) : 0;
      return { st, m, mo: T.mo + dj.fac[1] * 2, inj };
    }
    function gainLine(dj, d, k) {
      if (d.inj) return h('div', { class: 'dj-gain' }, '부상 — ' + d.inj + '계절 동안 쉰다');
      const e = expect(dj, d, k), parts = [];
      e.st.forEach((v, i) => { if (v >= 0.5) parts.push(STATS[i] + ' +' + Math.round(v)); });
      if (e.m >= 0.5) parts.push('숙련 +' + Math.round(e.m));
      if (e.mo) parts.push('사기 ' + (e.mo > 0 ? '+' : '−') + Math.abs(e.mo));
      if (!parts.length && k !== 5) parts.push('거의 오르지 않는다');
      const el = h('div', { class: 'dj-gain' }, '예상 ' + parts.join(' · '));
      if (e.inj >= 0.03) el.append(h('span', { class: 'w', text: ' · 부상 ' + Math.round(e.inj * 100) + '%' }));
      const nt = TECHS.find((Tc) => Tc.w === d.w && d.m < Tc.m && d.m + e.m >= Tc.m);
      if (nt) el.append(h('span', { class: 'w', text: ' · 「' + nt.n + '」' }));
      return el;
    }

    /* ---------- 제자 카드 ---------- */
    function statBlock(d, showPot) {
      return h('div', { class: 'dj-sts' }, ...d.st.map((v, i) => h('div', { class: 'dj-st' },
        STATS[i] + ' ' + Math.round(v),
        h('div', { class: 'dj-bar' }, h('i', { style: { width: Math.min(100, v) + '%' } }), showPot ? h('u', { style: { left: Math.min(99, d.pot[i]) + '%' } }) : null))));
    }
    function moodLine(d) {
      return h('div', { class: 'dj-mm' },
        h('span', { class: d.mo < 35 ? 'bad' : '', text: '사기 ' + d.mo }),
        h('span', { class: d.lo < 35 ? 'bad' : '', text: '충성 ' + d.lo }),
        h('span', { text: '숙련 ' + Math.round(d.m) }),
        d.inj ? h('span', { class: 'bad', text: '부상 ' + d.inj + '계절' }) : null,
        d.wn || d.ls ? h('span', { text: d.wn + '승 ' + d.ls + '패' }) : null);
    }
    const curveTxt = (dj, d) => (d.rv || dj.fac[2] > 0 ? CURVES[d.cv].n : '성장 미상');
    function discCard(seat, d, i) {
      const dj = S.dj[seat], dr = canPlan(seat) ? D(seat) : null;
      const k = dr ? (d.inj ? 5 : dr.tr[d.id] != null ? dr.tr[d.id] : d.tr || 0) : d.tr || 0;
      const w = dr && dr.wch[d.id] != null ? dr.wch[d.id] : d.w;
      const card = h('div', { class: 'dj-card dj-dcard' + (dr && dr.dis === d.id ? ' sel' : '') });
      const head = h('div', { class: 'dj-d', onclick: () => discSheet(seat, d.id) },
        h('div', { class: 'dj-por', html: figSVG(d) }),
        h('div', { class: 'dj-dt' },
          h('div', { class: 'dj-dn' }, h('div', { class: 'br', text: d.n }), h('div', { class: 'dj-rt' }, h('small', { text: '실력' }), String(rating(d)))),
          h('div', { class: 'dj-dm', text: WEAPONS[w].n + (w !== d.w ? '(바꿈)' : '') + ' · ' + d.age + '세 · ' + TEMPERS[d.tp].n + ' · ' + curveTxt(dj, d) + (d.ta ? ' · ' + TALENTS[d.ta].n : '') }),
          statBlock(d), moodLine(d)));
      card.append(head);
      if (dr && dr.dis === d.id) { card.append(h('div', { class: 'dj-gain' }, h('span', { class: 'w', text: '이번 계절에 내보낸다 — 제자 창에서 되돌릴 수 있다' }))); return card; }
      const row = h('div', { class: 'dj-tr' });
      TRAIN.forEach((T, ti) => row.append(h('button', { class: 'dj-chip' + (k === ti ? ' on' : ''), disabled: !dr || (d.inj && ti !== 5) ? true : null, text: d.inj && ti === 5 ? '요양' : T.n, 'aria-label': T.n + ' — ' + T.d,
        onclick: (e) => { e.stopPropagation(); dr.tr[d.id] = ti; api.sfx('click'); render(); } })));
      card.append(row);
      if (dr) card.append(gainLine(dj, d, k));
      else card.append(h('div', { class: 'dj-gain', text: '지난 수련 · ' + TRAIN[d.tr || 0].n }));
      return card;
    }

    /* ---------- 창(시트) ---------- */
    function sheet(title, body, foot, o) {
      closeSheet();
      const close = () => closeSheet();
      const sh = h('div', { class: 'dj-sheet', onclick: (e) => e.stopPropagation() },
        h('header', null, o && o.seal ? h('div', { class: 'dj-seal sm br', text: o.seal }) : null, h('h3', { class: 'br', text: title }), h('button', { class: 'dj-x', 'aria-label': '닫기', text: '×', onclick: close })),
        h('div', { class: 'bd' }, body),
        foot ? h('div', { class: 'ft' }, foot) : null);
      sheetEl = h('div', { class: 'dj-shade', onclick: close }, sh);
      R0.append(sheetEl);
      return sh;
    }
    function closeSheet() { if (sheetEl) { sheetEl.remove(); sheetEl = null; } }

    function discSheet(seat, id) {
      const dj = S.dj[seat], d = findD(dj, id);
      if (!d) return;
      const dr = canPlan(seat) ? D(seat) : null;
      const body = h('div');
      body.append(h('div', { class: 'dj-d', style: { cursor: 'default' } }, h('div', { class: 'dj-por', style: { width: '60px', height: '72px' }, html: figSVG(d, 60, 72) }),
        h('div', { class: 'dj-dt' }, h('div', { class: 'dj-dm', text: d.age + '세 · ' + WEAPONS[d.w].n + ' · 실력 ' + rating(d) + (d.bt ? ' · ' + d.bt + '에서 옴' : '') }), statBlock(d, true), moodLine(d))));
      const kv = h('dl', { class: 'dj-kv' });
      const add = (k, v) => kv.append(h('dt', { text: k }), h('dd', { text: v }));
      add('성향', TEMPERS[d.tp].n + ' — ' + TEMPERS[d.tp].d);
      add('재능', TALENTS[d.ta].n + ' — ' + TALENTS[d.ta].d);
      add('성장', d.rv || dj.fac[2] > 0 ? CURVES[d.cv].n + ' — ' + CURVES[d.cv].d : '아직 모른다. 두 계절을 지켜보거나 서고를 두면 드러난다.');
      add('잠재', '막대 위의 세로 금이 능력마다 오를 수 있는 끝이다. 끝에 가까울수록 더디게 오른다.');
      add('수련한 계절', d.ex + '계절' + (d.nt ? ' · 수업료를 받지 않는 제자' : ''));
      const tl = TECHS.filter((T) => T.w === d.w).map((T) => (d.m >= T.m ? '「' + T.n + '」' : '(숙련 ' + T.m + ') ' + T.n)).join(' · ');
      add('기술', tl);
      body.append(kv);
      if (dr) {
        body.append(h('div', { class: 'dj-h br', text: '병기 바꾸기' }), h('div', { class: 'dj-sub', style: { whiteSpace: 'normal' }, text: '바꾸면 숙련이 3분의 1로 줄고, 익힌 기술도 새 병기의 것으로 바뀐다.' }));
        const ch = h('div', { class: 'dj-ch', style: { marginTop: '6px' } });
        const cur = dr.wch[d.id] != null ? dr.wch[d.id] : d.w;
        WEAPONS.forEach((W, wi) => ch.append(h('button', { class: wi === cur ? 'on' : '', text: W.n, onclick: () => { if (wi === d.w) delete dr.wch[d.id]; else dr.wch[d.id] = wi; api.sfx('click'); discSheet(seat, id); render(); } })));
        body.append(ch);
      }
      const foot = [];
      if (dr) {
        const out = dr.dis === d.id;
        foot.push(h('button', { class: 'dj-btn', text: out ? '내보내지 않는다' : '내보낸다', onclick: () => {
          if (out) { dr.dis = null; closeSheet(); render(); return; }
          if (dj.ev && (dj.ev.a === d.id || dj.ev.b === d.id)) { api.toast('사건에 얽힌 제자는 이번 계절에 내보낼 수 없다'); return; }
          confirmBox('「' + d.n + '」' + josa(d.n, '을', '를') + ' 내보낸다', '계절을 보내면 도장을 떠나고 돌아오지 않는다. 남은 제자들의 충성이 조금 떨어진다. 한 계절에 한 명만.', '내보낸다', () => { dr.dis = d.id; render(); });
        } }));
      }
      foot.push(h('button', { class: 'dj-btn pri', text: '닫는다', onclick: closeSheet }));
      sheet(d.n, body, foot);
    }
    function confirmBox(title, text, ok, fn) {
      sheet(title, h('p', { style: { margin: '4px 0', color: 'var(--ink2)' }, text }), [h('button', { class: 'dj-btn', text: '그만둔다', onclick: closeSheet }), h('button', { class: 'dj-btn pri red', text: ok, onclick: () => { closeSheet(); fn(); } })]);
    }
    const potWord = (c, dj) => { const p = avg(c.pot); return dj.fac[2] > 0 ? '잠재 ' + Math.round(p) : p >= 78 ? '자질 상' : p >= 66 ? '자질 중' : '자질 하'; };
    function candSheet(seat) {
      const dj = S.dj[seat], dr = D(seat);
      const body = h('div');
      const free = capOf(dj) - dj.ds.length + (dr.dis != null ? 1 : 0) - dr.acts.filter((a) => a.k === 'rec').length;
      body.append(h('div', { class: 'dj-now', text: '문 앞에 선 사람들. 자리 ' + Math.max(0, free) + '개 남음. 받으면 계절마다 수업료를 낸다. 봄에는 셋, 다른 계절에는 둘이 찾아온다.' }));
      dj.cand.forEach((c, ci) => {
        if (!c) return;
        const taken = dr.acts.some((a) => a.k === 'rec' && a.c === ci);
        const card = h('div', { class: 'dj-card' + (taken ? ' sel' : '') },
          h('div', { class: 'dj-d', style: { cursor: 'default' } }, h('div', { class: 'dj-por', html: figSVG(c) }),
            h('div', { class: 'dj-dt' },
              h('div', { class: 'dj-dn' }, h('div', { class: 'br', text: c.n }), h('div', { class: 'dj-rt' }, h('small', { text: '실력' }), String(rating(c)))),
              h('div', { class: 'dj-dm', text: WEAPONS[c.w].n + ' · ' + c.age + '세 · ' + TEMPERS[c.tp].n + ' · ' + potWord(c, dj) + (dj.fac[2] > 0 ? ' · ' + CURVES[c.cv].n : '') }),
              h('div', { class: 'dj-dm', text: TALENTS[c.ta].n === '없음' ? '눈에 띄는 재능 없음' : '재능 · ' + TALENTS[c.ta].n + ' — ' + TALENTS[c.ta].d }),
              statBlock(c, dj.fac[2] > 0))));
        card.append(h('button', { class: 'dj-opt' + (taken ? ' on' : ''), disabled: !taken && (free <= 0 || dr.acts.length >= 2) ? true : null,
          html: '<b>' + (taken ? '받기로 했다 — 다시 누르면 취소' : '받는다') + '</b>',
          onclick: () => { if (taken) dr.acts = dr.acts.filter((a) => !(a.k === 'rec' && a.c === ci)); else dr.acts.push({ k: 'rec', c: ci }); api.sfx('click'); candSheet(seat); render(); } }));
        body.append(card);
      });
      if (!dj.cand.some(Boolean)) body.append(h('p', { text: '이번 계절에는 더 찾아온 사람이 없다.' }));
      sheet('입문을 청하는 사람', body, [h('button', { class: 'dj-btn pri', text: '닫는다', onclick: closeSheet })]);
    }
    const plannedCost = (dj, dr, skip) => dr.acts.reduce((a, x) => a + (x !== skip && x.k === 'bld' ? FAC_COST[dj.fac[x.f] + 1] : 0), 0);
    function facSheet(seat) {
      const dj = S.dj[seat], dr = D(seat);
      const body = h('div');
      body.append(h('div', { class: 'dj-now', text: '한 계절에 한 단계씩, 일 하나를 쓴다. 단계가 오르면 살림살이도 조금 는다. 지금 ' + dj.$ + '냥.' }));
      FAC.forEach((F, fi) => {
        const lv = dj.fac[fi], picked = dr.acts.find((a) => a.k === 'bld' && a.f === fi);
        const cost = lv < 3 ? FAC_COST[lv + 1] : 0;
        const afford = dj.$ - plannedCost(dj, dr, picked) >= cost;
        body.append(h('div', { class: 'dj-card' + (picked ? ' sel' : '') },
          h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, h('span', { html: svgI(F_ICON[fi], 22) }), h('b', { class: 'br', style: { fontWeight: 400, fontSize: '17px', flex: 1 }, text: F.n + ' ' + F.han }), h('span', { class: 'dj-sub', text: lv + '/3단계' })),
          h('div', { class: 'dj-sub', style: { whiteSpace: 'normal', margin: '4px 0' }, text: F.d }),
          h('div', { class: 'dj-dm', text: '지금 · ' + F.e(lv) + (lv < 3 ? '  →  ' + F.e(lv + 1) : '') }),
          h('button', { class: 'dj-opt' + (picked ? ' on' : ''), disabled: !picked && (lv >= 3 || !afford || dr.acts.length >= 2) ? true : null,
            html: '<b>' + (lv >= 3 ? '더 손볼 데가 없다' : picked ? '손보기로 했다 — 다시 누르면 취소' : '손본다 · ' + cost + '냥') + '</b>' + (!picked && lv < 3 && !afford ? '<span>돈이 모자란다</span>' : ''),
            onclick: () => { if (picked) dr.acts = dr.acts.filter((a) => a !== picked); else dr.acts.push({ k: 'bld', f: fi }); api.sfx('click'); facSheet(seat); render(); } })));
      });
      sheet('시설', body, [h('button', { class: 'dj-btn pri', text: '닫는다', onclick: closeSheet })]);
    }
    const chanceWord = (p) => (p >= 0.68 ? '승산 높음' : p >= 0.52 ? '해 볼 만함' : p >= 0.36 ? '반반 아래' : '승산 낮음');
    function lineupText(x) { return lineup(x, true).map((id) => rating(id < 0 ? x.mst : findD(x, id))).join(' · '); }
    function chalSheet(seat) {
      const dj = S.dj[seat], dr = D(seat);
      const body = h('div');
      body.append(h('div', { class: 'dj-now', text: '세 판 승부(선봉·중견·대장). 이기면 그 도장의 현판을 떼어 오고 명성을 빼앗는다. 지면 명성 −15, 사죄금 −8냥. 같은 도장에는 네 계절, 다른 도장에는 두 계절이 지나야 다시 도전할 수 있다.' }));
      if (healthy(dj).length < 3) body.append(h('p', { style: { color: 'var(--red)' }, text: '성한 제자가 셋 있어야 도전할 수 있다.' }));
      const t = tOf(S);
      S.dj.forEach((x, xi) => {
        if (xi === seat) return;
        const ok = chalOk(S, seat, xi);
        const picked = dr.acts.find((a) => a.k === 'chal' && a.d === xi);
        const p = winEst(S, seat, xi);
        const cdTxt = dj.cd[xi] > t ? (dj.cd[xi] - t) + '계절 뒤 가능' : dj.cd.a > t ? (dj.cd.a - t) + '계절 뒤 가능' : t < 1 ? '여름부터 가능' : '';
        body.append(h('div', { class: 'dj-card' + (picked ? ' sel' : '') },
          h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, h('div', { class: 'dj-seal sm br' + (x.own < 0 ? ' npc' : ''), text: x.nm[0] }),
            h('div', { style: { flex: 1, minWidth: 0 } }, h('div', { class: 'br', style: { fontSize: '17px' }, text: x.nm }), h('div', { class: 'dj-sub', text: (x.own >= 0 ? S.pn[x.own] : x.mst.n) + ' · ' + (x.st >= 0 ? STYLES[x.st].n : '검풍 미정') + ' · 명성 ' + x.rep + (dj.lost === xi ? ' · 우리 현판을 가짐' : '') })),
            h('div', { class: 'dj-sub', style: { textAlign: 'right' }, text: chanceWord(p) })),
          h('div', { class: 'dj-dm', style: { marginTop: '4px' }, text: '상대 출전 실력 ' + lineupText(x) + '  /  우리 ' + lineupText(dj) }),
          h('button', { class: 'dj-opt' + (picked ? ' on' : ''), disabled: !picked && (!ok || dr.acts.length >= 2 || dr.acts.some((a) => a.k === 'chal')) ? true : null,
            html: '<b>' + (picked ? '도전하기로 했다 — 다시 누르면 취소' : '도전장을 보낸다') + '</b>' + (cdTxt ? '<span>' + cdTxt + '</span>' : ''),
            onclick: () => { if (picked) dr.acts = dr.acts.filter((a) => a !== picked); else dr.acts.push({ k: 'chal', d: xi }); api.sfx('click'); chalSheet(seat); render(); } })));
      });
      sheet('도장 깨기', body, [h('button', { class: 'dj-btn pri', text: '닫는다', onclick: closeSheet })]);
    }
    function citySheet() {
      const seat = viewSeat();
      const order = S.dj.map((x, i) => i).sort((a, b) => finalScore(S, S.dj[b]) - finalScore(S, S.dj[a]));
      const tb = h('table', { class: 'dj-tbl' });
      order.forEach((i, r) => {
        const x = S.dj[i];
        const best = byRating(x.ds).slice(0, 3).map(rating).join(' · ');
        tb.append(h('tr', null,
          h('td', { class: 'n', text: (r + 1) + '' }),
          h('td', null, h('div', { class: 'dj-seal sm br' + (x.own < 0 ? ' npc' : ''), text: x.nm[0] })),
          h('td', null, h('div', { class: 'br', style: { fontSize: '16px' }, text: x.nm + (i === seat ? ' (우리)' : '') }),
            h('div', { class: 'dj-sub', style: { whiteSpace: 'normal' }, text: (x.own >= 0 ? S.pn[x.own] : x.mst.n) + ' · ' + (x.st >= 0 ? STYLES[x.st].n : '검풍 미정') + ' · 제자 ' + x.ds.length + (best ? ' (' + best + ')' : '') + (x.sb.length ? ' · 현판 ' + x.sb.map((j) => S.dj[j].nm).join('·') : '') + (x.lost >= 0 ? ' · 현판 잃음' : '') })),
          h('td', { class: 'n', text: String(finalScore(S, x)) })));
      });
      const body = h('div', null, h('div', { class: 'dj-now', text: '마지막 겨울이 지났을 때의 명성(현판 하나에 +15, 잃으면 −15)으로 순위를 매긴다.' }), tb);
      if (S.lastTour) body.append(tourBox(S.lastTour));
      if (S.news.length) body.append(h('div', { class: 'dj-h br', text: '고을 소식' }), h('div', { class: 'dj-news' }, ...S.news.slice().reverse().map((n) => h('div', { text: n }))));
      sheet('고을의 도장', body, [h('button', { class: 'dj-btn pri', text: '닫는다', onclick: closeSheet })]);
    }
    function tourBox(T) {
      const box = h('div');
      box.append(h('div', { class: 'dj-h br' }, (T.k === 'r' ? '지난 고을 대회' : '지난 천하 대회'), h('small', { text: '대진' })));
      const names = ['8강', '4강', '결승', '우승'];
      T.br.forEach((r, ri_) => {
        const line = h('div', { class: 'dj-news' });
        line.append(h('div', null, h('b', { style: { fontWeight: 400, color: 'var(--ink)' }, text: names[ri_] + ' — ' }), r.map((e) => T.ent[e].n + '(' + T.ent[e].dn + ')').join(' / ')));
        box.append(line);
      });
      return box;
    }
    function exGlyph(ex) {
      const w = h('span', { class: 'dj-exs' });
      String(ex).split(',').filter(Boolean).forEach((e) => w.append(h('i', { class: e[2] === '1' ? 'a' : e[2] === '2' ? 'b' : '', text: STANCES[+e[0]].han + STANCES[+e[1]].han })));
      return w;
    }
    function reportSheet(seat, auto) {
      const dj = S.dj[seat];
      const ul = h('ul', { class: 'dj-rpl' });
      const pt = tOf(S) - (S.ph === 'end' ? 0 : 1);
      const yy = Math.floor(Math.max(0, pt) / 4) + 1, ss = Math.max(0, pt) % 4;
      if (!dj.rp.length && !S.bl.length) ul.append(h('li', { text: '아직 지난 계절의 기록이 없다.' }));
      const lines = dj.rp.slice();
      const train = lines.filter((l) => l.includes(' · ') && TRAIN.some((T) => l.includes(' · ' + T.n)));
      const other = lines.filter((l) => !train.includes(l));
      if (other.length) { ul.append(h('li', { class: 'hd', text: '도장' })); other.forEach((l) => ul.append(h('li', { text: l }))); }
      if (train.length) { ul.append(h('li', { class: 'hd', text: '수련' })); train.forEach((l) => ul.append(h('li', { text: l }))); }
      const mine = S.bl.filter((b) => b.d.includes(seat));
      const rest = S.bl.filter((b) => !b.d.includes(seat));
      if (mine.length || rest.length) ul.append(h('li', { class: 'hd', text: '시합' }));
      const boutLi = (b) => {
        const li = h('li', null, b.l + ' — ', h('span', { style: { color: b.w === 0 ? 'var(--ink)' : 'var(--mute)' }, text: b.n[0] }), ' 대 ', h('span', { style: { color: b.w === 1 ? 'var(--ink)' : 'var(--mute)' }, text: b.n[1] }), ' · ' + b.n[b.w] + ' 승' + (b.dec ? '(판정)' : ''), exGlyph(b.ex));
        if (b.ex) li.append(h('button', { class: 'dj-btn', style: { minHeight: '44px', padding: '0 10px', marginLeft: '6px', fontSize: '12px' }, text: '다시 보기', onclick: () => { closeSheet(); replay(b); } }));
        return li;
      };
      mine.forEach((b) => ul.append(boutLi(b)));
      if (rest.length) { const det = h('details', null, h('summary', { style: { minHeight: '44px', lineHeight: '44px', cursor: 'pointer', color: 'var(--ink2)' }, text: '다른 도장의 시합 ' + rest.length }), ...rest.map(boutLi)); ul.append(h('li', null, det)); }
      sheet(yy + '년째 ' + SEASONS[ss] + '의 기록', ul, [h('button', { class: 'dj-btn pri', text: auto ? '다음 계절로' : '닫는다', onclick: closeSheet })], { seal: SEASON_HAN[ss] });
    }

    /* ---------- 계획 화면 ---------- */
    function evCard(seat) {
      const dj = S.dj[seat], ev = dj.ev, E = EV[ev.k], dr = canPlan(seat) ? D(seat) : null;
      const card = h('div', { class: 'dj-card dj-ev dj-need-ev' + (dr && dr.ev == null ? ' need' : '') }, h('h4', { class: 'br', text: E.h }), h('p', { text: E.tx(S, dj, ev) }));
      if (ev.k === 'retire') {
        card.append(h('div', { class: 'dj-sub', style: { whiteSpace: 'normal' }, text: '이어받은 제자는 사범이 되어 도장 깨기의 마지막 자리를 지킨다. 그보다 강하고 충성이 낮은 제자는 떠날 수도 있다.' }));
        byRating(dj.ds).forEach((d) => card.append(h('button', { class: 'dj-opt' + (dr && dr.ev === d.id ? ' on' : ''), disabled: !dr ? true : null,
          html: '<b>' + d.n + '</b><span>실력 ' + rating(d) + ' · ' + d.age + '세 · 충성 ' + d.lo + ' · ' + TEMPERS[d.tp].n + '</span>', onclick: () => { dr.ev = d.id; api.sfx('click'); render(); } })));
        return card;
      }
      E.op.forEach((o, oi) => card.append(h('button', { class: 'dj-opt' + (dr && dr.ev === oi ? ' on' : ''), disabled: !dr ? true : null,
        html: '<b>' + o.t(S, dj, ev) + '</b><span>' + o.h + '</span>', onclick: () => { dr.ev = oi; api.sfx('click'); render(); } })));
      return card;
    }
    function styleCard(seat) {
      const dr = canPlan(seat) ? D(seat) : null;
      const card = h('div', { class: 'dj-card dj-ev dj-need-st' + (dr && dr.style == null ? ' need' : '') }, h('h4', { class: 'br', text: '도장의 검풍' }), h('p', { text: '스승이 남긴 것은 낡은 마루와 이름 하나. 이 도장이 어떤 칼을 쓸지 먼저 정한다. 판 끝까지 바뀌지 않는다.' }));
      STYLES.forEach((Y, yi) => card.append(h('button', { class: 'dj-opt' + (dr && dr.style === yi ? ' on' : ''), disabled: !dr ? true : null,
        html: '<b>' + Y.n + ' ' + Y.han + '</b><span>' + Y.d + '</span>', onclick: () => { dr.style = yi; api.sfx('click'); render(); } })));
      return card;
    }
    function champCard(seat) {
      const dj = S.dj[seat], dr = canPlan(seat) ? D(seat) : null;
      const nat = S.se === 3;
      const box = h('div');
      box.append(h('div', { class: 'dj-h br' }, nat ? '천하 대회 출전' : '고을 대회 출전', h('small', { text: nat ? '고을 대회 4강 · 타지의 고수 넷' : '고을의 모든 도장과 떠돌이 무사' })));
      const ch = h('div', { class: 'dj-ch' });
      byRating(healthy(dj)).forEach((d) => ch.append(h('button', { class: dr && dr.ch === d.id ? 'on' : '', disabled: !dr ? true : null, text: d.n + ' ' + rating(d), onclick: () => { dr.ch = d.id; api.sfx('click'); render(); } })));
      if (!healthy(dj).length) ch.append(h('span', { class: 'dj-sub', text: '나설 수 있는 제자가 없다.' }));
      box.append(ch, h('div', { class: 'dj-sub', style: { whiteSpace: 'normal', marginTop: '4px' }, text: '수련은 시합 전에 치른다. 출전할 제자가 이번 계절에 다치면 다음으로 강한 제자가 나간다.' }));
      return box;
    }
    const ACTS = [
      { k: 'rec', n: '입문자 받기', ic: 'door', sub: (dj, dr) => dj.cand.filter(Boolean).length + '명이 기다림', open: candSheet },
      { k: 'bld', n: '시설 손보기', ic: 'hall', sub: (dj) => '수련장·목욕간·서고·대장간', open: facSheet },
      { k: 'show', n: '시범 공연', ic: 'flag', sub: (dj) => { const top = byRating(dj.ds).slice(0, 3); const q = top.length ? avg(top.map(rating)) : 20; return '약 +' + Math.round(5 + q / 6 + dj.rep / 30) + '냥 · 명성 +' + (2 + (q >= 55 ? 2 : 0) + (q >= 70 ? 2 : 0)); } },
      { k: 'pat', n: '후원자 찾기', ic: 'hand', sub: (dj) => (dj.pat >= 3 ? '후원자가 이미 셋' : '될 확률 ' + Math.round(clamp(0.25 + dj.rep / 250 - dj.pat * 0.15, 0.1, 0.85) * 100) + '% · 계절마다 +5냥') },
      { k: 'chal', n: '도장 깨기', ic: 'sword', sub: (dj) => (healthy(dj).length < 3 ? '성한 제자 셋 필요' : '현판을 걸고 세 판 승부'), open: chalSheet },
    ];
    function actLabel(dj, a) {
      if (a.k === 'rec') { const c = dj.cand[a.c]; return ['입문 — ' + (c ? c.n : '?'), c ? WEAPONS[c.w].n + ' · ' + c.age + '세' : '']; }
      if (a.k === 'bld') return ['시설 — ' + FAC[a.f].n + ' ' + (dj.fac[a.f] + 1) + '단계', '−' + FAC_COST[dj.fac[a.f] + 1] + '냥'];
      if (a.k === 'show') return ['시범 공연', ACTS[2].sub(dj)];
      if (a.k === 'pat') return ['후원자 찾기', ACTS[3].sub(dj)];
      if (a.k === 'chal') return ['도장 깨기 — ' + S.dj[a.d].nm, chanceWord(winEst(S, viewSeat(), a.d))];
      return [a.k, ''];
    }
    function actBox(seat) {
      const dj = S.dj[seat], dr = canPlan(seat) ? D(seat) : null;
      const box = h('div', { class: 'dj-actbox' });
      box.append(h('div', { class: 'dj-h br' }, '도장의 일', h('small', { text: dr ? '두 가지 · ' + dr.acts.length + '/2' : '' })));
      if (!dr) { box.append(h('div', { class: 'dj-sub', text: '계획을 낸 뒤에는 고칠 수 없다.' })); return box; }
      const g = h('div', { class: 'dj-acts' });
      ACTS.forEach((A) => {
        const full = dr.acts.length >= 2;
        const done = (A.k === 'show' || A.k === 'pat') && dr.acts.some((a) => a.k === A.k);
        const dis = (!A.open && (full || done)) || (A.k === 'pat' && dj.pat >= 3) || (A.k === 'chal' && healthy(dj).length < 3);
        g.append(h('button', { class: 'dj-act', disabled: dis ? true : null, html: svgI(A.ic, 20) + '<b>' + A.n + '</b><span>' + A.sub(dj, dr) + '</span>',
          onclick: () => { api.sfx('click'); if (A.open) A.open(seat); else { dr.acts.push({ k: A.k }); render(); } } }));
      });
      box.append(g);
      if (dr.acts.length) {
        const pk = h('div', { class: 'dj-picked' });
        dr.acts.forEach((a) => { const [t1, t2] = actLabel(dj, a); pk.append(h('div', { class: 'dj-pk' }, h('div', null, t1, h('span', { text: t2 })), h('button', { class: 'dj-x', 'aria-label': '빼기', text: '×', onclick: () => { dr.acts = dr.acts.filter((x) => x !== a); api.sfx('click'); render(); } }))); });
        box.append(pk);
      }
      return box;
    }
    function missing(seat) {
      const dj = S.dj[seat], dr = D(seat);
      if (dj.st < 0 && dr.style == null) return '검풍을 먼저 정한다';
      if (dj.ev && dr.ev == null) return '사건에 먼저 답한다';
      return '';
    }
    function submit(seat) {
      const m = missing(seat);
      if (m) {   // 빠진 것이 화면 밖에 있으면 그 자리로 데려가 깜박여 보인다
        const el = main.querySelector(S.dj[seat].st < 0 && D(seat).style == null ? '.dj-need-st' : '.dj-need-ev');
        if (el) { el.scrollIntoView({ block: 'start', behavior: 'smooth' }); el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
        api.toast(m); api.sfx('tick'); return;
      }
      const dr = D(seat), dj = S.dj[seat];
      const a = { t: 'plan', tr: dr.tr, acts: dr.acts, ch: dr.ch, ev: dr.ev == null ? 0 : dr.ev, wch: dr.wch, dis: dr.dis };
      if (dj.st < 0) a.style = dr.style;
      api.sfx('chip'); api.buzz(12, 'ui');
      api.actAs(seat, a);
    }
    function render() {
      if (!S || destroyed) return;
      const seat = viewSeat(), dj = S.dj[seat];
      renderTop(seat);
      const tNow = tOf(S) + ':' + S.ph;
      const sc = tNow !== lastRenderT ? 0 : main.scrollTop;   // 새 계절은 맨 위(검풍·사건 카드)부터
      lastRenderT = tNow;
      main.replaceChildren();
      const m = mySeats();
      if (m.length > 1 && S.ph === 'plan') {
        const tabs = h('div', { class: 'dj-tabs' });
        m.forEach((x) => tabs.append(h('button', { class: x === seat ? 'on' : '', text: S.dj[x].nm + (S.pl[x] ? ' · 냄' : ''), onclick: () => { curSeat = x; closeSheet(); render(); } })));
        main.append(tabs);
      }
      if (S.ph === 'end') {
        const T = titleOf(S, dj);
        main.append(h('div', { class: 'dj-card dj-ev' }, h('h4', { class: 'br', text: T.n }), h('p', { text: T.t }), h('div', { class: 'dj-sub', style: { whiteSpace: 'normal' }, text: '최종 명성 ' + finalScore(S, dj) + ' · 고을 대회 우승 ' + dj.rec.rw + ' · 천하 대회 우승 ' + dj.rec.nw + ' · 현판 ' + dj.sb.length })));
      } else {
        const planning = canPlan(seat);
        let now;
        if (!api.canAct(seat)) now = mySeats().length ? '다른 도장의 계획을 기다린다.' : '지켜보는 중. ' + S.dj[seat].nm + '의 마루.';
        else if (S.pl[seat]) now = '이번 계절의 계획을 냈다. 다른 도장을 기다린다.';
        else if (dj.st < 0) now = '먼저 검풍을 정하고, 제자 수련과 도장의 일 둘을 고른다.';
        else now = '제자마다 수련 하나, 도장의 일 둘을 고른 뒤 계절을 보낸다.';
        main.append(h('div', { class: 'dj-now', text: now }));
        if (S.pl.some(Boolean) || S.pl[seat]) {
          const w = h('div', { class: 'dj-wait' });
          S.pl.forEach((p, i) => w.append(h('span', { class: p ? 'ok' : 'no', text: S.dj[i].nm + (p ? ' · 냄' : ' · 정하는 중') })));
          main.append(w);
        }
        if (dj.st < 0) main.append(styleCard(seat));
        if (dj.ev) main.append(evCard(seat));
        if (S.se === 2 || (S.se === 3 && S.semi.includes(seat))) main.append(champCard(seat));
        else if (S.se === 3) main.append(h('div', { class: 'dj-sub', style: { whiteSpace: 'normal', margin: '6px 0' }, text: '이번 겨울의 천하 대회에는 고을 대회 4강에 든 도장만 나간다.' }));
        main.append(h('div', { class: 'dj-h br' }, '제자', h('small', { text: dj.ds.length + '/' + capOf(dj) + ' · 누르면 자세히' })));
        const dsBox = h('div', { class: 'dj-ds' });
        dj.ds.forEach((d, i) => dsBox.append(discCard(seat, d, i)));
        if (!dj.ds.length) dsBox.append(h('div', { class: 'dj-card', text: '마루가 비었다. 입문자를 받는다.' }));
        main.append(dsBox);
        main.append(actBox(seat));
        main.append(h('div', { class: 'dj-h br' }, '사범', h('small', { text: '도장 깨기에서 제자가 모자라면 나선다' })),
          h('div', { class: 'dj-card' }, h('div', { class: 'dj-d', style: { cursor: 'default' } }, h('div', { class: 'dj-por', html: figSVG({ id: 999 + seat, w: dj.mst.w }) }),
            h('div', { class: 'dj-dt' }, h('div', { class: 'dj-dn' }, h('div', { class: 'br', text: dj.mst.n }), h('div', { class: 'dj-rt' }, h('small', { text: '실력' }), String(rating(dj.mst)))),
              h('div', { class: 'dj-dm', text: WEAPONS[dj.mst.w].n + ' · ' + dj.mst.age + '세 · ' + TEMPERS[dj.mst.tp].n + (dj.sx >= 0 ? ' · 머지않아 물러날 나이' : '') }), statBlock(dj.mst)))));
        if (S.news.length) main.append(h('div', { class: 'dj-h br', text: '고을 소식' }), h('div', { class: 'dj-news' }, ...S.news.slice(-4).reverse().map((n) => h('div', { text: n }))));
        if (planning) void 0;
      }
      main.scrollTop = sc;
      renderBot(seat);
    }
    function renderBot(seat) {
      const planning = canPlan(seat);
      const miss = planning ? missing(seat) : '';
      bot.replaceChildren(
        h('button', { class: 'dj-btn', text: '고을', 'data-key': 'KeyC', onclick: citySheet }),
        h('button', { class: 'dj-btn', text: '기록', 'data-key': 'KeyR', onclick: () => reportSheet(seat) }),
        h('button', { class: 'dj-btn pri red dj-go', 'data-action': 'go', disabled: !planning ? true : null, text: S.ph === 'end' ? '끝' : !planning ? (S.pl[seat] ? '기다리는 중' : '—') : miss || '계절을 보낸다', onclick: () => submit(seat) }));
    }

    /* ---------- 시합 화면 ---------- */
    const dh = h('div', { class: 'dj-dh' }), plates = h('div', { class: 'dj-pl' }), cvBox = h('div', { class: 'dj-cv' }), logEl = h('div', { class: 'dj-log' }), ctl = h('div', { class: 'dj-ctl' });
    duel.append(dh, plates, cvBox, logEl, ctl);
    const cv = U_canvas(cvBox);
    function U_canvas(box) { const c = h('canvas'); box.append(c); return c; }
    const exQ = [];
    let anim = null, sel = null, loopStop = null, shown = null, logLines = [], curtainOK = {}, pendingReport = false, bgCache = null;
    function sizeCv() {
      const r = cvBox.getBoundingClientRect(), dpr = Math.min(2.5, window.devicePixelRatio || 1);
      const W = Math.max(10, Math.round(r.width)), H = Math.max(10, Math.round(r.height));
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); bgCache = null; }
      return { W, H, dpr };
    }
    function bg(W, H, dpr) {
      if (bgCache && bgCache.W === W && bgCache.H === H) return bgCache.c;
      const c = document.createElement('canvas'); c.width = Math.round(W * dpr); c.height = Math.round(H * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      x.fillStyle = '#e4ddcc'; x.fillRect(0, 0, W, H);
      hills(x, W, H * 0.8, 31);
      const gy = H * 0.8;
      // 땅: 마른 붓 한 획
      x.fillStyle = 'rgba(34,31,26,.75)';
      x.beginPath(); x.moveTo(-10, gy + 1);
      for (let i = 0; i <= 40; i++) { const u = i / 40; x.lineTo(u * (W + 20) - 10, gy - 2 * Math.sin(u * 9) - (u < 0.1 ? (0.1 - u) * 20 : 0)); }
      for (let i = 40; i >= 0; i--) { const u = i / 40; x.lineTo(u * (W + 20) - 10, gy + 3 + 2.5 * Math.sin(u * 13 + 1) * (1 - Math.abs(u - 0.5))); }
      x.closePath(); x.fill();
      const gg = x.createLinearGradient(0, gy, 0, H); gg.addColorStop(0, 'rgba(34,31,26,.1)'); gg.addColorStop(1, 'rgba(34,31,26,0)');
      x.fillStyle = gg; x.fillRect(0, gy + 4, W, H - gy);
      // 소나무 한 그루(왼쪽 위)
      x.strokeStyle = 'rgba(34,31,26,.55)'; x.lineWidth = 3; x.lineCap = 'round';
      x.beginPath(); x.moveTo(W * 0.06, gy); x.quadraticCurveTo(W * 0.1, gy - H * 0.3, W * 0.05, gy - H * 0.55); x.stroke();
      x.fillStyle = 'rgba(34,31,26,.45)';
      [[0.05, 0.55, 26], [0.12, 0.44, 20], [0.02, 0.4, 16]].forEach(([u, v, r]) => { x.beginPath(); x.ellipse(W * u, gy - H * v, r, r * 0.35, -0.1, 0, 6.3); x.fill(); });
      bgCache = { W, H, c };
      return c;
    }
    /* 수별 움직임(t: 0~1 한 합) */
    function poseOf(st, t, res, side) {
      const e = (a, b) => Math.max(0, Math.min(1, (t - a) / (b - a)));
      const ease = (u) => u * u * (3 - 2 * u);
      let dx = 0, arm = -0.5, lean = 0, crouch = 0, arm2 = null;
      const hit = res === side + 1, got = res && !hit;
      if (st === 0) {   // 선: 들어 올렸다가 달려 들며 내려 벤다
        const up = ease(e(0.08, 0.3)), go = ease(e(0.3, 0.56)), back = ease(e(0.72, 1));
        dx = go * 50 - back * 50; arm = -0.5 - up * 1.1 + go * 1.9 - back * 0.8; lean = go * 0.5 - back * 0.5; arm2 = arm + 0.8;
      } else if (st === 1) {   // 후: 기다렸다가 받아 넘기며 옆으로 벤다
        const wait = ease(e(0.1, 0.4)), go = ease(e(0.46, 0.6)), back = ease(e(0.74, 1));
        dx = -wait * 8 + go * 44 - back * 36; arm = -0.5 + wait * 0.6 - go * 0.9 + back * 0.8; crouch = wait * 0.5 - back * 0.5; lean = go * 0.35 - back * 0.35; arm2 = arm + 1.1;
      } else {   // 허: 칼끝을 흔들며 비켜 섰다가 파고든다
        const f1 = Math.sin(e(0.08, 0.4) * Math.PI * 2) * 0.4, go = ease(e(0.42, 0.6)), back = ease(e(0.74, 1));
        dx = e(0.1, 0.35) * 14 + go * 34 - back * 48; arm = -0.3 + f1 - go * 0.2 + back * 0.0; crouch = 0.35 * e(0.1, 0.35) - back * 0.35; lean = go * 0.3 - back * 0.3; arm2 = arm + 0.6;
      }
      if (got) lean -= ease(e(0.58, 0.7)) * 0.25 * (1 - ease(e(0.8, 1)));
      return { dx, arm, lean, crouch: Math.max(0, crouch), arm2 };
    }
    function stroke(x, x0, y0, x1, y1, wmax, prog, col) {   // 붓 한 획(가운데가 굵고 끝이 가늚)
      const n = 18, pts = [];
      for (let i = 0; i <= n * prog; i++) { const u = i / n; pts.push([x0 + (x1 - x0) * u, y0 + (y1 - y0) * u + Math.sin(u * 3.1) * -6, Math.sin(Math.min(1, u * 1.15) * Math.PI) * wmax + 0.6]); }
      if (pts.length < 2) return;
      x.fillStyle = col; x.beginPath();
      for (let i = 0; i < pts.length; i++) { const [px, py, ww] = pts[i]; x.lineTo(px, py - ww / 2); }
      for (let i = pts.length - 1; i >= 0; i--) { const [px, py, ww] = pts[i]; x.lineTo(px, py + ww / 2); }
      x.closePath(); x.fill();
    }
    function drawDuel(t, info) {
      const { W, H, dpr } = sizeCv();
      const x = cv.getContext('2d');
      x.setTransform(dpr, 0, 0, dpr, 0, 0);
      x.drawImage(bg(W, H, dpr), 0, 0, W, H);
      const gy = H * 0.8, sc = Math.max(0.6, Math.min(1.5, Math.min(W / 330, H / 190)));
      const now = performance.now() / 1000;
      const ws = info ? info.w : [0, 0];
      let pa, pb;
      if (info && info.ex && t != null) { pa = poseOf(info.ex.sa, t, info.ex.res, 0); pb = poseOf(info.ex.sb, t, info.ex.res, 1); }
      else { const br = Math.sin(now * 1.6) * 0.04; pa = { dx: 0, arm: -0.5 + br, lean: 0, crouch: 0.1 }; pb = { dx: 0, arm: -0.5 - br, lean: 0, crouch: 0.1 }; }
      const gap = (W * 0.4 - (pa.dx + pb.dx) * sc) / sc;   // 두 사람이 겹치지 않게
      if (gap < 44) { const k = Math.max(0, (W * 0.4 / sc - 44) / Math.max(1, pa.dx + pb.dx)); pa.dx *= k; pb.dx *= k; }
      fighterDraw(x, W * 0.3, gy, sc, 1, ws[0], pa);
      fighterDraw(x, W * 0.7, gy, sc, -1, ws[1], pb);
      if (info && info.ex && t != null && t > 0.5) {
        const res = info.ex.res, u = Math.min(1, (t - 0.5) / 0.14), fade = 1 - Math.max(0, (t - 0.82) / 0.18);
        const mid = W / 2;
        if (res) {
          const loserRight = res === 1;
          const cx = loserRight ? W * 0.7 - 6 * sc : W * 0.3 + 6 * sc;
          const ty = gy - sc * (info.ex.tg === 0 ? ([86, 62, 50][loserRight ? info.ex.sa : info.ex.sb]) : ([70, 52, 40][loserRight ? info.ex.sa : info.ex.sb]));
          const d = loserRight ? 1 : -1;
          stroke(x, cx - 46 * sc * d, ty - 20 * sc, cx + 40 * sc * d, ty + 16 * sc, 7 * sc, u, 'rgba(25,22,19,' + (0.9 * fade) + ')');
          if (u >= 1) { x.fillStyle = 'rgba(25,22,19,' + 0.6 * fade + ')'; for (let i = 0; i < 7; i++) { const a = i * 2.1 + info.ex.tg, r = (8 + i * 3) * sc * (t - 0.6) * 3; x.beginPath(); x.arc(cx + Math.cos(a) * r, ty + Math.sin(a) * r * 0.6, 1.4 + (i % 3), 0, 6.3); x.fill(); } }
        } else {
          stroke(x, mid - 28 * sc, gy - 92 * sc, mid + 26 * sc, gy - 50 * sc, 4 * sc, u, 'rgba(25,22,19,' + 0.7 * fade + ')');
          stroke(x, mid + 26 * sc, gy - 94 * sc, mid - 24 * sc, gy - 52 * sc, 4 * sc, u, 'rgba(25,22,19,' + 0.7 * fade + ')');
        }
        if (res && t > 0.62) {   // 한 판: 붉은 낙관
          const k = Math.min(1, (t - 0.62) / 0.1), sx = res === 1 ? W * 0.3 : W * 0.7;
          x.save(); x.globalAlpha = 0.9 * k; x.fillStyle = '#9b2d22'; x.translate(sx, gy - 140 * sc); x.rotate(-0.06);
          const s2 = 30 * sc; x.fillRect(-s2 / 2, -s2 / 2, s2, s2);
          x.fillStyle = '#f2e8d4'; x.font = Math.round(19 * sc) + 'px DojoBrush, DojoHan, "Song Myung", serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('一本', 0, 1 * sc); x.restore();
        }
      }
      // 수 표시(공개)
      if (info && info.ex && t != null && t > 0.04) {
        x.save(); x.globalAlpha = Math.min(1, (t - 0.04) / 0.1) * (1 - Math.max(0, (t - 0.9) / 0.1));
        x.fillStyle = 'rgba(34,31,26,.85)'; x.font = Math.round(30 * sc) + 'px DojoBrush, DojoHan, "Song Myung", serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
        x.fillText(STANCES[info.ex.sa].han, W * 0.3, gy - 172 * sc > 18 ? gy - 172 * sc : 22);
        x.fillText(STANCES[info.ex.sb].han, W * 0.7, gy - 172 * sc > 18 ? gy - 172 * sc : 22);
        x.restore();
      }
    }
    function exLine(info) {
      const e = info.ex, A = info.nm[0], B = info.nm[1], n = '제' + info.n + '합 — ';
      const W_ = e.res === 1 ? A : B, Lz = e.res === 1 ? B : A;
      const tgN = (st) => TARGETS[st][e.tg];
      if (e.res) {
        const ws = e.res === 1 ? e.sa : e.sb, ls = e.res === 1 ? e.sb : e.sa;
        if (beats(ws, ls)) return n + (ws === 0 ? '흘리려던 칼보다 ' + W_ + '의 칼이 먼저 닿았다. ' : ws === 1 ? W_ + josa(W_, '이', '가') + ' 들어오는 칼을 받아 넘기고 쳤다. ' : W_ + '의 허초에 ' + Lz + '의 응수가 끌려 나왔다. ') + tgN(ws) + ', 한 판.';
        if (beats(ls, ws)) return n + '밀리던 ' + W_ + josa(W_, '이', '가') + ' 엇갈리며 ' + tgN(ws) + josa(tgN(ws), '을', '를') + ' 거두었다. 한 판.';
        return n + (ws === 0 ? '두 칼이 함께 나갔다. 반 박자 빠른 쪽은 ' + W_ + '. ' : '허초가 엇갈린 틈으로 ' + W_ + josa(W_, '이', '가') + ' 먼저 파고들었다. ') + tgN(ws) + ', 한 판.';
      }
      if (e.sa === 1 && e.sb === 1) return n + '둘 다 움직이지 않았다. 숨소리만 길어졌다. 기세는 ' + (e.mo === 1 ? A : B) + '에게 기울었다.';
      if (e.sa === e.sb) return n + (e.sa === 0 ? '칼과 칼이 부딪쳐 손끝만 저렸다.' : '서로의 허초가 허공에서 엇갈렸다.');
      const ws = beats(e.sa, e.sb) ? A : B;
      return n + ws + josa(ws, '이', '가') + ' 틈을 보았으나 칼끝이 닿지 않았다.';
    }
    function platesFor(nm, dn, w, tp, sc, mine) {
      const pt = (i) => h('div', { class: 'dj-pt' + (i ? ' r' : '') + (mine === i ? ' me' : '') },
        h('div', { class: 'br', text: nm[i] }),
        h('div', { class: 'dj-sub', text: dn[i] + ' · ' + WEAPONS[w[i]].n + (tp ? ' · ' + TEMPERS[tp[i]].n : '') }),
        h('div', { class: 'dj-pips' }, h('i', { class: sc[i] >= 1 ? 'on' : '' }), h('i', { class: sc[i] >= 2 ? 'on' : '' })));
      plates.replaceChildren(pt(0), pt(1));
    }
    function sideOf(b) { const m = mySeats(); return b.sd[0] >= 0 && m.includes(b.sd[0]) && b.pk[0] == null && !b.au[0] ? 0 : b.sd[1] >= 0 && m.includes(b.sd[1]) && b.pk[1] == null && !b.au[1] ? 1 : -1; }
    function renderDuel() {
      const b = S.B;
      if (anim) return;   // 애니메이션 중에는 끝난 뒤 다시 그린다
      if (!b || S.ph !== 'duel') { if (!replaying) hideDuel(); return; }
      showDuel();
      if (shown !== b.id) { shown = b.id; logLines = []; sel = null; curtainOK = {}; api.sfx('whoosh'); }
      dh.replaceChildren(h('div', { class: 'br', text: b.lab }), h('div', { class: 'dj-sub', text: '제' + (b.ex.length + 1) + '합 · 먼저 두 판 · 여섯 합이 지나면 판정' }));
      const meSide = b.sd[0] >= 0 && mySeats().includes(b.sd[0]) ? 0 : b.sd[1] >= 0 && mySeats().includes(b.sd[1]) ? 1 : -1;
      platesFor(b.nm, b.dn, b.w, b.tp, b.sc, meSide);
      logEl.replaceChildren(...logLines.slice(-2).map((l) => h('div', { text: l })));
      ctl.replaceChildren();
      const side = sideOf(b);
      if (side < 0) {
        const waiting = [0, 1].filter((k) => b.sd[k] >= 0 && b.pk[k] == null && !b.au[k]).map((k) => S.pn[b.sd[k]]);
        ctl.append(h('div', { class: 'dj-opp', text: meSide >= 0 ? '수를 냈다. 상대를 기다린다.' : waiting.length ? waiting.join(' · ') + ' 님이 수를 고르는 중.' : '지켜보는 중.' }));
        return;
      }
      const seat = b.sd[side];
      const both = b.sd[0] >= 0 && b.sd[1] >= 0 && b.sd[0] !== b.sd[1] && api.canAct(b.sd[0]) && api.canAct(b.sd[1]);
      if (both && !curtainOK[seat]) {
        const cur = h('div', { class: 'dj-cur' }, h('div', { class: 'br', text: S.pn[seat] + '의 차례' }), h('div', { class: 'dj-sub', style: { whiteSpace: 'normal' }, text: '상대는 화면을 보지 않는다. 수를 고르면 다시 가려진다.' }),
          h('button', { class: 'dj-btn pri', style: { minWidth: '160px' }, text: '내가 고른다', onclick: () => { curtainOK[seat] = 1; cur.remove(); renderDuel(); } }));
        ctl.append(h('div', { class: 'dj-opp', text: '' }));
        duel.append(cur);
        return;
      }
      const [fa, fb] = bfighters(S, b), me = side ? fb : fa, op = side ? fa : fb;
      const pw = [0, 1, 2].map((k) => Math.round(power(me, k, ctxOf(b, side))));
      const cnt = [0, 0, 0]; b.ex.forEach((e) => cnt[+e[1 - side]]++);
      const pref = TEMPERS[op.tp].pref;
      const opp = h('div', { class: 'dj-opp' }, '상대 · ' + TEMPERS[op.tp].n + (pref >= 0 ? '(' + STANCES[pref].n + '를 즐겨 씀)' : '') + ' · 이번 시합 ' + STANCES.map((S_, k) => S_.han + ' ' + cnt[k]).join(' · '));
      const myDj = b.f[side].d != null ? S.dj[b.f[side].d] : null;
      if (myDj && myDj.st === 4) { const q = oppModel(S, b, side, 3); opp.append(h('br'), '명경 — 다음 수 짐작 ' + STANCES.map((S_, k) => S_.han + ' ' + Math.round(q[k] * 100) + '%').join(' · ')); }
      ctl.append(opp);
      const row = h('div', { class: 'dj-sts3' });
      const done = sel && sel.seat === seat && sel.n === b.ex.length && sel.id === b.id;
      STANCES.forEach((S_, k) => row.append(h('button', { class: 'dj-sb' + (done && sel.k === k ? ' on' : ''), disabled: done ? true : null, 'data-action': 's' + k,
        onclick: () => pickStance(seat, k) },
        h('div', { class: 'br', text: S_.han }), h('span', { text: S_.n + ' · ' + S_.v }), h('em', { text: '힘 ' + pw[k] }))));
      ctl.append(row);
      ctl.append(h('div', { class: 'dj-row' }, h('div', { class: 'dj-sub', text: '先은 虛를, 後는 先을, 虛는 後를 이긴다.' }),
        h('button', { class: 'dj-btn', 'data-action': 'auto', text: '맡긴다', onclick: () => confirmBox('제자에게 맡긴다', '남은 합을 제자가 제 성향대로 치른다. 이 시합에서는 되돌릴 수 없다.', '맡긴다', () => { api.actAs(seat, { t: 'auto' }); }) })));
    }
    function pickStance(seat, k) {   // 한 번 누르면 바로 낸다(두 번 누르기 없앰) — 누른 단추는 잠깐 눌린 모양으로 남는다
      const b = S && S.B;
      if (!b || (sel && sel.seat === seat && sel.n === b.ex.length && sel.id === b.id)) return;
      sel = { seat, k, n: b.ex.length, id: b.id }; api.sfx('chip'); api.buzz(14, 'ui');
      ctl.querySelectorAll('.dj-sb').forEach((b, i) => { b.disabled = true; if (i === k) b.classList.add('on'); });
      api.actAs(seat, { t: 'st', v: k });
    }
    function showDuel() { duel.classList.add('on'); startLoop(); }
    function hideDuel() { duel.classList.remove('on'); duel.querySelectorAll('.dj-cur').forEach((e) => e.remove()); shown = null; stopLoop(); }
    function startLoop() {
      if (loopStop) return;
      let raf = 0;
      const f = () => { if (destroyed) return; if (!anim) drawDuel(null, S && S.B ? { w: S.B.w } : replaying ? { w: replaying.w } : null); raf = requestAnimationFrame(f); };
      raf = requestAnimationFrame(f);
      loopStop = () => cancelAnimationFrame(raf);
    }
    function stopLoop() { if (loopStop) { loopStop(); loopStop = null; } }
    /* 한 합 재생 → 끝나면 done() */
    function playEx(info, done) {
      showDuel();
      duel.querySelectorAll('.dj-cur').forEach((e) => e.remove());
      dh.replaceChildren(h('div', { class: 'br', text: info.lab }), h('div', { class: 'dj-sub', text: '제' + info.n + '합' }));
      const prevSc = info.sc.slice(); if (info.ex.res && !info.skip) prevSc[info.ex.res - 1]--;
      const mine = info.sd ? (mySeats().includes(info.sd[0]) ? 0 : mySeats().includes(info.sd[1]) ? 1 : -1) : -1;
      platesFor(info.nm, info.dn, info.w, null, info.skip ? info.sc : prevSc, mine);
      ctl.replaceChildren(h('div', { class: 'dj-opp', text: '' }));
      const dur = 1700 / spd() / (1 + exQ.length);   // 밀린 합이 있으면 빨리
      const t0 = performance.now();
      let hitPlayed = false;
      const A = { done };
      anim = A;
      api.setBusy(true);
      api.sfx('whoosh');
      const step = () => {
        if (destroyed || anim !== A) return;
        const t = Math.min(1, (performance.now() - t0) / dur);
        drawDuel(t, info);
        if (!hitPlayed && t > 0.55) { hitPlayed = true; if (info.ex.res) { api.sfx('hit'); if (mine >= 0) api.buzz(info.ex.res === mine + 1 ? 18 : 30, 'hit'); } else api.sfx('thud'); platesFor(info.nm, info.dn, info.w, null, info.sc, mine); }
        if (t < 1) { A.raf = requestAnimationFrame(step); return; }
        logLines.push(exLine(info));
        if (info.skip) logLines.push('남은 합은 제자들이 스스로 치렀다.');
        if (info.fin >= 0) logLines.push(info.nm[info.fin] + ' 승' + (info.dec ? '(판정)' : '') + ' — ' + info.sc[0] + ' 대 ' + info.sc[1]);
        logEl.replaceChildren(...logLines.slice(-2).map((l) => h('div', { text: l })));
        const hold = info.fin >= 0 ? 1100 / spd() : 150 / spd();
        if (info.fin >= 0) { api.sfx(mine < 0 ? 'pop' : info.fin === mine ? 'win' : 'lose'); }
        A.to = setTimeout(() => { if (anim !== A) return; anim = null; api.setBusy(false); if (A.done) A.done(); }, exQ.length ? hold / 3 : hold);
      };
      A.raf = requestAnimationFrame(step);
    }
    /* 기록의 시합 다시 보기(이 기기에서만) */
    let replaying = null;
    function replay(bl) {
      if (anim || (S && S.ph === 'duel')) return;
      const exs = String(bl.ex).split(',').filter(Boolean);
      const me_ = replaying = { w: [0, 0] };
      logLines = [];
      const sc = [0, 0];
      let i = 0;
      const next = () => {
        if (replaying !== me_) return;
        if (i >= exs.length || destroyed) { replaying = null; pump(); setTimeout(() => { if (!anim && !(S && S.ph === 'duel')) hideDuel(); }, 900 / spd()); return; }
        const e = exs[i++];
        const res = +e[2];
        if (res) sc[res - 1]++;
        const fin = i >= exs.length ? bl.w : -1;
        playEx({ lab: bl.l + ' · 다시 보기', nm: bl.n, dn: bl.dn, w: [0, 0], sd: null, sc: sc.slice(), n: i, ex: { sa: +e[0], sb: +e[1], res, tg: 0, mo: 0 }, fin, dec: bl.dec }, next);
      };
      next();
    }

    /* ---------- 상태 받기 ---------- */
    function onState(s, prev) {
      S = s;
      const L0 = s.last || {};
      const seasonChanged = prev && (tOf(prev) !== tOf(s) || (prev.ph !== 'end' && s.ph === 'end'));
      if (L0.id !== lastId) {
        lastId = L0.id;
        if (L0.k === 'ex' && L0.b && prev) {
          stopReplay();
          sel = null;
          exQ.push({ info: L0.b, season: seasonChanged });
          render();
          pump();
          return;
        }
      }
      if (seasonChanged) { closeSheet(); if (!anim) autoReport(); else pendingReport = true; }
      render();
      renderDuel();
    }
    function stopReplay() {
      if (!replaying) return;
      replaying = null;
      if (anim) { cancelAnimationFrame(anim.raf); clearTimeout(anim.to); anim = null; api.setBusy(false); }
    }
    function pump() {
      if (anim || replaying || !exQ.length) return;
      const it = exQ.shift();
      if (it.season) pendingReport = true;
      playEx(it.info, () => { if (exQ.length) { pump(); return; } renderDuel(); render(); if (pendingReport) { pendingReport = false; autoReport(); } });
    }
    function autoReport() {
      const m = mySeats();
      if (!m.length || !S) return;
      const seat = viewSeat();
      if (S.dj[seat].rp.length || S.bl.some((b) => b.d.includes(seat))) reportSheet(seat, true);
    }

    /* PC 단축키(def.controls) */
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !S) return;
      if (S.ph === 'duel' && S.B && !anim) {
        const side = sideOf(S.B); if (side < 0) return;
        const seat = S.B.sd[side];
        if (id === 's0' || id === 's1' || id === 's2') pickStance(seat, +id[1]);
        return;
      }
      if (id === 'go' && !sheetEl) { const seat = viewSeat(); if (canPlan(seat)) submit(seat); }
    }) : null;
    const onCancel = (e) => { if (sheetEl) { closeSheet(); e.preventDefault(); } };
    window.addEventListener('lounge-cancel', onCancel);
    const onResize = () => { bgCache = null; };
    window.addEventListener('resize', onResize);

    return {
      update(s, prev) { onState(s, prev); },
      destroy() {
        destroyed = true;
        stopLoop();
        if (anim) { cancelAnimationFrame(anim.raf); clearTimeout(anim.to); anim = null; }
        api.setBusy(false);
        if (offIn) offIn();
        window.removeEventListener('lounge-cancel', onCancel);
        window.removeEventListener('resize', onResize);
        R0.remove(); styleEl.remove();
      },
    };
  }
})();
(function () {  // 배포용 줄 → 조각:줄 (tools/parts_join.js가 만든 표)
  const P = window.DOJO_PARTS || (window.DOJO_PARTS = {}), M = [[1,"dojo",0],[3,"data",2],[171,"engine",2],[1060,"ai",2],[1260,"def",2],[1457,"view",2]], N = 2416;
  P.where = function (x) {
    const one = (ln) => { ln = +ln; let m = null; for (const e of M) if (e[0] <= ln) m = e; return m && m[1] !== 'dojo' && ln < N ? m[1] + '.js:' + (ln - m[0] + m[2]) : 'dojo.js'; };
    return typeof x === 'number' ? one(x) : String(x).replace(/dojo-joined\.js:(\d+)/g, (_, ln) => 'dojo/' + one(ln));
  };
})();
//# sourceURL=games/dojo-joined.js
