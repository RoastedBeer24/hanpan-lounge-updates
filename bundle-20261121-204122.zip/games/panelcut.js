/* 컷 바꾸기 — 느와르 만화의 칸 순서를 바꿔 결말을 바꾸는 1인 퍼즐.
   규칙은 결정적: 같은 배열이면 같은 결과. 진행(연 단계 · 통과 표시 · 최소 수)은 localStorage에만 남는다(능력치 없음). */
(function () {
  const L = window.Lounge, U = L.util;
  const KEY = 'lounge.panelcut';
  function store() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }

  /*__STAGES__*/
  // 장: t 이름, n 단계 수, rule 새 규칙, rule2 첫 단계 안내, lines 단계마다 한 줄, end 장을 마친 뒤 한 줄
  const CHAPTERS = [
    {"n":5,"t":"골목","rule":"칸 맞바꾸기","rule2":"칸을 끌어 다른 칸 위에 놓으면 자리가 바뀐다. 불빛을 피해 갈 순서를 찾는다.","lines":["자정이 지났다. 장부는 외투 안주머니에 있다.","골목 끝에 손전등 불빛이 하나 더 보였다.","비상계단은 녹이 슬었지만 아직 버틴다.","누군가 호각을 불었다. 멀지 않은 곳이다.","이 골목만 벗어나면 여관이 나온다."],"end":"골목을 빠져나왔다. 불 꺼진 여관의 뒷문이 열려 있었다."},
    {"n":5,"t":"여관","rule":"칸 뒤집기 · 못 박힌 칸","rule2":"둥근 화살표가 있는 칸은 그 표시를 눌러 좌우로 뒤집는다. 못 박힌 칸은 움직이지 않는다.","lines":["복도에는 발소리를 삼키는 낡은 융단이 깔려 있다.","순찰은 창밖을 보고 있다. 혹은 이쪽을.","거울에 비친 복도는 방향이 반대다.","위층 어딘가에서 문이 닫혔다.","뒷계단은 창고 쪽 골목으로 이어진다."],"end":"여관을 나섰다. 길 건너 창고의 셔터가 반쯤 내려와 있었다."},
    {"n":5,"t":"창고","rule":"열쇠와 잠긴 문","rule2":"열쇠를 먼저 지나야 잠긴 문이 열린다. 열쇠 하나에 문 하나.","lines":["열쇠는 늘 문에서 가장 먼 곳에 걸려 있다.","상자 사이로 손전등 불빛이 천천히 지나갔다.","자물쇠는 새것이다. 누군가 서둘러 바꿔 달았다.","열쇠보다 문이 많다. 어느 문을 열지 정해야 한다.","창고 뒤편으로 술집의 네온이 비쳤다."],"end":"창고를 지나왔다. 술집 뒷문에는 빈 병 상자가 쌓여 있었다."},
    {"n":5,"t":"술집 뒷문","rule":"빈 병","rule2":"병을 먼저 주우면, 이쪽을 보는 순찰 하나의 시선을 돌릴 수 있다.","lines":["빈 병 하나면 한 사람의 고개를 돌릴 수 있다.","유리 깨지는 소리는 골목에서 멀리 간다.","병은 넉넉하지 않다. 누구에게 쓸지 골라야 한다.","안에서는 아직 음악이 흘러나온다.","철길 쪽에서 기적 소리가 났다."],"end":"술집을 뒤로했다. 조차장의 신호등이 붉게 깜박였다."},
    {"n":5,"t":"조차장","rule":"번갈아 도는 순찰","rule2":"양쪽 화살표가 붙은 순찰은 칸마다 돌아선다. 어느 자리에 놓느냐에 따라 보는 쪽이 달라진다.","lines":["조차장의 순찰은 정해진 박자로 돌아선다.","하나, 둘. 등을 보일 때만 움직인다.","화차 사이는 좁고, 박자는 어긋나지 않는다.","신호등이 바뀌었다. 순찰은 다시 돌아섰다.","선로 끝에 변전소의 불빛이 보인다."],"end":"선로를 건넜다. 변전소 담장 위로 낮은 소리가 울렸다."},
    {"n":5,"t":"변전소","rule":"차단기 · 감시 장치 · 승강기","rule2":"차단기를 먼저 지나면 전기가 끊겨 감시 장치가 꺼진다. 승강기도 함께 선다.","lines":["붉은 점 하나가 복도를 내려다보고 있다.","차단기를 내리면 건물 전체가 숨을 죽인다.","어둠은 승강기도 멈춰 세운다.","다시 올리면 모든 것이 다시 본다.","담장 너머에서 누군가 기다리고 있다."],"end":"변전소를 나왔다. 가로등 아래 회색 모자가 서 있었다."},
    {"n":5,"t":"동행","rule":"두 사람","rule2":"칸마다 검은 외투가 먼저, 회색 모자가 뒤따라 지나간다. 둘 다 빠져나가야 한다.","lines":["회색 모자는 말이 없다. 따라오기만 한다.","앞사람이 치운 길은 뒷사람에게도 열려 있다.","둘이 가는 길은 달라도 닿는 곳은 같다.","소품은 주운 사람만 쓴다. 누가 줍느냐가 문제다.","부두까지는 두 블록이 남았다."],"end":"두 사람은 부두에 닿았다. 첫 배까지는 아직 시간이 남았다."},
    {"n":5,"t":"부두","rule":"다시 읽기","rule2":"「멈춤」 칸 앞에서 재생이 한 번 선다. 그때 지나온 칸을 뒤로 옮겨 다시 쓸 수 있다.","lines":["한 번 지나온 길은 이미 치워진 길이다.","같은 창고를 두 번 지나도 아무도 묻지 않는다.","쓰러진 순찰은 다시 일어나지 않았다.","안개가 끼면 부두는 어디나 같은 모양이다.","기중기 위에서 불빛이 움직였다."],"end":"부두 창고를 벗어났다. 남은 길은 지붕 위뿐이다."},
    {"n":5,"t":"옥상","rule":"사다리","rule2":"사다리는 앞길이 막혔을 때만 탄다. 트여 있으면 그냥 지나간다.","lines":["막히지 않은 길에서는 사다리를 보지 않는다.","지붕 위는 바람이 세다. 발밑은 불빛이다.","길이 막혀야 다른 길이 보인다.","굴뚝 그림자가 순찰의 등을 가렸다.","선착장의 등이 지붕 끝에서 내려다보인다."],"end":"지붕에서 내려섰다. 선착장에는 배 한 척이 묶여 있었다."},
    {"n":5,"t":"첫 배","rule":"모든 규칙","rule2":"지금까지의 것이 모두 나온다.","lines":["매표소는 닫혀 있다. 표는 필요 없다.","선창의 순찰은 오늘따라 많다.","뱃고동이 한 번 울렸다. 두 번 울리면 떠난다.","트랩 앞에 마지막 불빛이 서 있다.","밧줄이 풀리고 있다."],"end":"트랩을 올랐다. 밧줄이 물에 떨어지는 소리가 났다."},
  ];
  // 단계: p 칸(처음 배열), a 들어서는 층(사람마다 U 위 · D 아래), g 나가야 하는 층(* 아무 층), cp 멈춤 자리, m 최소 수(검증기가 계산)
  const STAGES = [
    {"p":["=...=/=.G.=","#...=/=.A.#","=...=/=...="],"a":"D","g":"*","m":1},
    {"p":["=...=/=.G.=","#...=/=..g=","=..V=/#...="],"a":"U","g":"D","m":1},
    {"p":["#G..=/=.g.=","=...=/=..G=","=g..#/=...=","=...=/=g.A="],"a":"D","g":"U","m":2},
    {"p":["=.G.=/=g..=","=.G.=/=...=","=...=/=.A.=","=..V=/=.G.="],"a":"U","g":"U","m":2},
    {"p":["=...=/=..G=","=g.V=/=...=","#.g.=/=g..=","=...=/=A..=","=...=/#.GA="],"a":"D","g":"D","m":3},
    {"p":["=...=/=...=!","=...=/=.G.=~","=...=/=..g=!"],"a":"D","g":"*","m":1},
    {"p":["=.G.=/=A..=~","#..G=/=..G=~","=...=/=.A.#~","=..g=/=...#"],"a":"D","g":"U","m":2},
    {"p":["=...=/=.g.#","=...=/#.gA#~","=.g.#/=..G=~","=..V=/=...=~"],"a":"U","g":"D","m":2},
    {"p":["=G..=/=...=","=..G#/=.G.=~","=V..=/=...=~","=...=/=..G=","=..G=/#.g.=~"],"a":"D","g":"U","m":3},
    {"p":["=GV.=/#...=~","=.G.=/=...=","=.V.=/=...=","#...=/=g..=~","=.g.=/=...#~"],"a":"U","g":"U","m":3},
    {"p":["=...=/=.D.=","=...=/=.k.=","=...=/=..g="],"a":"D","g":"*","m":1},
    {"p":["=.D.=/=k.D=~","=..V=/=.G.=~","#..G#/=...=","=g..=/=..A="],"a":"D","g":"*","m":2},
    {"p":["=..V=/=...=","=...=/=.DA=","=...#/=DG.=~","=...=/=.AG=~","=...#/=.kG=~"],"a":"D","g":"U","m":3},
    {"p":["=D..=/=.g.=~","=...=/=G..=","=g..=/=.D.#~","=...=/=k..=","=.DV=/=...=~"],"a":"D","g":"U","m":3},
    {"p":["#.D.=/=GD.=~","#..k=/=Ak.=","#.Vk=/=...=~","=...=/#...=","=V..=/=...=~"],"a":"D","g":"*","m":4},
    {"p":["=...=/=.G.=","=...=/=b..=","=...#/=...="],"a":"D","g":"*","m":1},
    {"p":["=..b=/=A..=~","=G.D=/=.AG#","=..k=/=.A.#~","=..G=/#...=~"],"a":"D","g":"U","m":2},
    {"p":["=..V=/=...=~","=.DG=/=...#","=.V.=/=k..=","=V..=/=...=","=...=/=b..="],"a":"D","g":"U","m":3},
    {"p":["=.V.=/=...#~","=V..#/=.g.=~","=...=/=A..#","=...#/=b.G=","=...#/=..G=~"],"a":"U","g":"U","m":3},
    {"p":["=..b=/=.G.=","#..b=/=...=~","#G..=/=GA.=","=...=/=.A.=~","=..G=/=.A.=~"],"a":"D","g":"*","m":4},
    {"p":["=...=/=.T.=","=...=/=...=","#...#/=.t.="],"a":"D","g":"*","m":1},
    {"p":["=...#/=k..=","#t..=/=tA.=","=.V.=/=D.t=~","=..b=/=A..=~"],"a":"U","g":"D","m":2},
    {"p":["=...=/=T.A=~","=...=/=G..=~","=..D=/#..T=","=Tk.=/=...#","=.k.=/=...#~"],"a":"D","g":"*","m":3},
    {"p":["=.gV=/=...=~","=.V.=/#...=","=..b=/=...=~","=.t.#/=...=","=..V=/=.t.="],"a":"U","g":"U","m":3},
    {"p":["=..g=/=T..=~","=..T=/#A..=","=V..=/=...=~","=..g#/=G..=","=..t=/=A.b=~","=V..#/=...=!"],"a":"D","g":"D","m":4},
    {"p":["=...=/=.C.=","=...=/=S..=","=...=/=...="],"a":"D","g":"*","m":1},
    {"p":["=.E.=/=TE.=~","=...=/=S.T=","=..V=/#...=","=...=/#...="],"a":"D","g":"D","m":2},
    {"p":["=..E=/=S.E=~","=..k=/=...=","#T..=/=..A=","=V..=/=.DC=","=.k.=/=...="],"a":"U","g":"U","m":3},
    {"p":["=.ES=/=.E.=","=...=/=TA.=~","=G..=/=C.k=","=CE.#/=.E.=~","=E..=/=E..="],"a":"D","g":"*","m":3},
    {"p":["=E.C=/#Ek.=","=VC.=/=.D.=~","#G.E=/=C.E=","=.S.=/=T..=","#Eg.=/=E..=","=.V.=/=...=~"],"a":"D","g":"D","m":4},
    {"p":["=.G.=/=..g=","=.V.=/=...=","=...=/=...="],"a":"UD","g":"**","m":1},
    {"p":["=k.b=/=...=","=.g.=/=...#~","=VG.#/#..G=","=..T=/=...#"],"a":"UU","g":"D*","m":2},
    {"p":["#.T.=/=A..=","=bG.=/=...#","=...=/=.A.=~","=...=/=D..="],"a":"UD","g":"U*","m":3},
    {"p":["#...=/=..b=","=...=/#A..#","=..T=/=.A.=","=g..=/=...=","=.G.=/=k.A=~"],"a":"UD","g":"U*","m":3},
    {"p":["=T..=/=..T=","=V..=/=..D=","=...=/=A..=","=..V#/=k..=~","#D.T=/=.A.=~"],"a":"UD","g":"*D","m":4},
    {"p":["=...=/=.G.=","=...=/=.g.=","=...=/=...="],"a":"D","g":"*","cp":2,"m":2},
    {"p":["=...=/=.A.=!~","#...=/=.b.=","=VG.=/=.G.=~","=.T.=/=...#"],"a":"U","g":"D","cp":2,"m":2},
    {"p":["=...=/=G..=","=...=/=kA.=~","=...#/=G..=~","=.TD=/=...=~","=...#/=k..="],"a":"D","g":"*","cp":3,"m":3},
    {"p":["#...=/=.T.=~","=..k=/=DA.=~","=..G=/=...#~","=.G.=/=..A=","=b..=/=...#"],"a":"U","g":"D","cp":3,"m":4},
    {"p":["#.G.=/=...=~","#...=/=A.T#~","=G..=/=b..=","=..V=/#.T.#","=...=/=.AG#~"],"a":"U","g":"U","cp":3,"m":4},
    {"p":["=H..=/=H.G=","=..G=/=...=","#...=/=...="],"a":"D","g":"U","m":1},
    {"p":["=..H=/=..H=","=.SH=/=..H#","=...#/=T.S=","=.G.=/#..g#~"],"a":"D","g":"U","m":2},
    {"p":["=gb.=/=...=","=..V#/#.G.=~","=.H.=/#.H.=~","#...=/=..G=","#..T=/=g..="],"a":"D","g":"*","m":3},
    {"p":["=TH.#/=GH.=~","=...=/=..A#","=.kT=/#...=~","=HD.=/=H.G=!","#.HD=/=.H.="],"a":"U","g":"*","m":4},
    {"p":["=..G=/#A..=","=...=/=...=~","=.TH#/=.TH=","=.b.=/=...=","=.SH=/#..H=~","=.V.=/=k..="],"a":"D","g":"D","m":4},
    {"p":["=.E.=/=DE.#","=..H=/=g.H=","=..G=/=Ab.=!~","=..k=/=..G=","=..E=/=.gE=~"],"a":"U","g":"*","cp":3,"m":3},
    {"p":["=ET.=/=Eb.#~","=E..#/=E..=","=.Vk=/=...=","=Vg.=/#.GS=","=.Gb=/=...=~"],"a":"D","g":"*","m":4},
    {"p":["=.b.=/=...#~","=...#/=D..=","=.E.=/=.ED=~","=T..=/#...=","=...#/=.A.=~","=T.k=/=.A.="],"a":"U","g":"*","m":4},
    {"p":["#.E.=/=.EG=~","=S..=/=...#","=...#/=.T.=","#..H=/=..H=","=E..=/=ED.=","#.SH=/=b.H#~"],"a":"U","g":"U","m":5},
    {"p":["=tD.=/#...=","=...=/=k..=","#...=/=.A.#~","=..G=/#G..=~","#VT.=/=...=~","=.E.=/=.EG#"],"a":"U","g":"U","m":5},
  ];

  /* ================= 규칙(순수 로직) ================= */
  // 칸 글: "위층/아래층" + 표시(! 못 박힘, ~ 뒤집을 수 있음). 층 = 왼쪽 벽, 자리 1·2·3, 오른쪽 벽.
  // = 트임  # 벽 | G 이쪽을 보는 순찰  g 등 돌린 순찰  T·t 번갈아 도는 순찰 | C 감시 장치 | k 열쇠  b 병  D 잠긴 문
  // S 차단기  E 승강기 | A 오르는 계단(아래층에 적음)  V 내려가는 계단(위층에 적음) | H 사다리
  const PCACHE = {};
  function parse(str) {
    if (PCACHE[str]) return PCACHE[str];
    const m = /^([^!~]+)([!~]*)$/.exec(str), ln = m[1].split('/'), f = [];
    const open = [[ln[0][0] === '=', ln[0][4] === '='], [ln[1][0] === '=', ln[1][4] === '=']];
    for (let x = 1; x <= 3; x++) {
      const c = [ln[0][x], ln[1][x]];
      if (c[0] === 'H' || c[1] === 'H') { f.push({ t: 'H', lane: -1, x }); continue; }
      if (c[0] === 'E' || c[1] === 'E') { f.push({ t: 'E', lane: -1, x }); continue; }
      for (let l = 0; l < 2; l++) {
        const ch = c[l];
        if (ch === '.') continue;
        if (ch === 'G' || ch === 'g') f.push({ t: 'g', lane: l, x, dir: ch === 'G' ? 'L' : 'R', alt: 0 });
        else if (ch === 'T' || ch === 't') f.push({ t: 'g', lane: l, x, dir: ch === 'T' ? 'L' : 'R', alt: 1 });
        else if (ch === 'A' || ch === 'V') f.push({ t: 'st', lane: l, x });
        else f.push({ t: ch, lane: l, x });
      }
    }
    f.forEach((q, i) => { q.i = i; });
    const p = { open, f, pin: m[2].indexOf('!') >= 0, fl: m[2].indexOf('~') >= 0, src: str, m: null, mir: 0 };
    p.m = { open: [[open[0][1], open[0][0]], [open[1][1], open[1][0]]], pin: p.pin, fl: p.fl, src: str, mir: 1,
      f: f.map((q) => { const r = Object.assign({}, q); r.x = 4 - q.x; if (q.t === 'g') r.dir = q.dir === 'L' ? 'R' : 'L'; if (q.t === 'st') r.lane = 1 - q.lane; return r; }) };
    return (PCACHE[str] = p);
  }
  const eff = (p, flip) => (flip ? p.m : p);
  const faceL = (g, slot) => (g.dir === 'L') !== !!(g.alt && (slot & 1));
  const OFF = { g: 0.3, D: 0.22, st: 0.36, C: 0.12 };

  function arrive(E, pi, W, lane, x, slot) { // 층을 바꿔 내려선 자리가 등 돌린 순찰의 앞이면 들킨다
    for (const g of E.f) if (g.t === 'g' && g.lane === lane && g.x < x && !(W.dyn[pi] & (1 << g.i)) && !faceL(g, slot)) return g;
    return null;
  }
  function walk(E, pi, W, a, slot, ev, who, x0, dry) {
    let lane = a.l, x = x0 || 0, vx = x;
    const F = (why, fx, fl, fi) => { if (ev) ev.push({ s: slot, w: who, k: 'fail', why, x: fx, l: fl, f: fi }); return { slot, who, why, x: fx, lane: fl, f: fi, pi }; };
    const mv = (to) => { if (ev && to > vx) ev.push({ s: slot, w: who, k: 'mv', l: lane, x0: vx, x1: to }); if (to > vx) vx = to; };
    if (!x0) {
      if (ev) ev.push({ s: slot, w: who, k: 'in', l: lane });
      if (!E.open[lane][0]) return F('wall', 0, lane, -1);
    }
    for (;;) {
      let f = null;
      for (const g of E.f) if (g.x > x && (g.lane === lane || g.lane < 0) && (!f || g.x < f.x)) f = g;
      if (!f) break;
      x = f.x;
      const bit = 1 << f.i, on = W.dyn[pi] & bit;
      if (f.t === 'g') {
        if (on) continue;
        if (faceL(f, slot)) {
          if (a.b > 0) { mv(x - 0.75); a.b--; W.dyn[pi] |= bit; if (ev) ev.push({ s: slot, w: who, k: 'bt', l: lane, x, f: f.i }); mv(x - OFF.g); if (ev) ev.push({ s: slot, w: who, k: 'ko', l: lane, x, f: f.i }); }
          else { mv(x - 0.7); return F('seen', x, lane, f.i); }
        } else { mv(x - OFF.g); W.dyn[pi] |= bit; if (ev) ev.push({ s: slot, w: who, k: 'ko', l: lane, x, f: f.i }); }
      } else if (f.t === 'C') {
        if (W.pw) { mv(x - OFF.C); return F('cam', x, lane, f.i); }
      } else if (f.t === 'k' || f.t === 'b') {
        if (!on) { mv(x); W.dyn[pi] |= bit; if (f.t === 'k') a.k++; else a.b++; if (ev) ev.push({ s: slot, w: who, k: 'pk', l: lane, x, f: f.i, it: f.t }); }
      } else if (f.t === 'D') {
        if (!on) {
          mv(x - OFF.D);
          if (a.k > 0) { a.k--; W.dyn[pi] |= bit; if (ev) ev.push({ s: slot, w: who, k: 'dr', l: lane, x, f: f.i }); }
          else return F('locked', x, lane, f.i);
        }
      } else if (f.t === 'S') {
        mv(x); W.pw = W.pw ? 0 : 1; W.dyn[pi] ^= bit; if (ev) ev.push({ s: slot, w: who, k: 'sw', l: lane, x, f: f.i, pw: W.pw });
      } else if (f.t === 'E' || f.t === 'st' || f.t === 'H') {
        if (f.t === 'E' && !W.pw) continue;
        if (f.t === 'H') {
          if (dry) continue;
          const W2 = { dyn: W.dyn.slice(), pw: W.pw }, a2 = { l: lane, k: a.k, b: a.b };
          if (!walk(E, pi, W2, a2, slot, null, who, x, true)) continue;
        }
        const nl = 1 - lane;
        if (f.t === 'st') { mv(x - OFF.st); if (ev) ev.push({ s: slot, w: who, k: 'st', l: lane, l1: nl, x }); vx = x + OFF.st; }
        else { mv(x); if (ev) ev.push({ s: slot, w: who, k: f.t === 'E' ? 'el' : 'ld', l: lane, l1: nl, x, f: f.i }); }
        lane = nl;
        const g = arrive(E, pi, W, lane, x, slot);
        if (g) return F('seen', g.x, lane, g.i);
      }
    }
    if (!E.open[lane][1]) { mv(3.7); return F('dead', 4, lane, -1); }
    mv(4); a.l = lane;
    return null;
  }
  // W = { ar, fl, dyn, pw, ac } 를 직접 바꾼다. 막히면 그 까닭을 돌려준다.
  function runSeg(T, W, from, to, ev) {
    for (let slot = from; slot < to; slot++) {
      const pi = W.ar[slot], E = eff(T.P[pi], W.fl[pi]);
      for (let w = 0; w < W.ac.length; w++) { const r = walk(E, pi, W, W.ac[w], slot, ev, w); if (r) return r; }
    }
    if (to === T.n) for (let w = 0; w < W.ac.length; w++) {
      const g = T.goal[w];
      if (g >= 0 && W.ac[w].l !== g) { if (ev) ev.push({ s: T.n - 1, w, k: 'fail', why: 'exit', x: 4, l: W.ac[w].l, f: -1 }); return { slot: T.n - 1, who: w, why: 'exit', x: 4, lane: W.ac[w].l, f: -1, pi: W.ar[T.n - 1] }; }
    }
    return null;
  }
  const LN = { U: 0, D: 1, '*': -1 };
  const TCACHE = {};
  function prepData(d, idx) {
    const P = d.p.map(parse), a = d.a.split('').map((c) => LN[c]);
    let g = (d.g || '').split('').map((c) => LN[c]); while (g.length < a.length) g.push(-1);
    return { idx, P, n: P.length, cp: d.cp | 0, start: a, goal: g };
  }
  function prep(idx) { return TCACHE[idx] || (TCACHE[idx] = prepData(STAGES[idx], idx)); }
  function world0(T) { return { ph: 0, ar: T.P.map((_, i) => i), fl: T.P.map(() => 0), dyn: T.P.map(() => 0), pw: 1, ac: T.start.map((l) => ({ l, k: 0, b: 0 })) }; }
  const cloneW = (W) => ({ ph: W.ph, ar: W.ar.slice(), fl: W.fl.slice(), dyn: W.dyn.slice(), pw: W.pw, ac: W.ac.map((a) => ({ l: a.l, k: a.k, b: a.b })) });
  // 재생 한 번: { ok, done, W(다음 세계), fail }
  function play(T, W0, ev) {
    const W = cloneW(W0);
    const from = W.ph ? T.cp : 0, to = (!W.ph && T.cp) ? T.cp : T.n;
    const fail = runSeg(T, W, from, to, ev);
    if (fail) return { ok: false, fail };
    if (to === T.n) return { ok: true, done: true, W };
    W.ph = 1; return { ok: true, done: false, W };
  }
  const wkey = (W) => W.ph + '|' + W.ar.join('') + '|' + W.fl.join('') + (W.ph ? '|' + W.dyn.join('.') + '|' + W.pw + '|' + W.ac.map((a) => '' + a.l + a.k + a.b).join('.') : '');
  function moves(T, W) {
    const out = [];
    for (let i = 0; i < T.n; i++) {
      const pi = T.P[W.ar[i]];
      if (pi.fl) out.push({ t: 'flip', a: i });
      if (pi.pin) continue;
      for (let j = i + 1; j < T.n; j++) if (!T.P[W.ar[j]].pin) out.push({ t: 'swap', a: i, b: j });
    }
    return out;
  }
  function doMove(W, m) {
    const N = cloneW(W);
    if (m.t === 'flip') { const pi = N.ar[m.a]; N.fl[pi] = N.fl[pi] ? 0 : 1; }
    else { const t = N.ar[m.a]; N.ar[m.a] = N.ar[m.b]; N.ar[m.b] = t; }
    return N;
  }
  // 가장 짧은 풀이(옮기기 · 뒤집기 · 재생의 차례). 없으면 null. 재생은 수로 세지 않는다.
  const SOLC = new Map();
  function solve(T, W0) {
    const k0 = T.idx + ':' + wkey(W0);
    if (T.idx >= 0 && SOLC.has(k0)) return SOLC.get(k0);
    const seen = new Map(); seen.set(wkey(W0), null);
    let q = [W0], res = null;
    const back = (W, tail) => { let k = wkey(W); for (;;) { const p = seen.get(k); if (!p) break; tail.unshift(p.m); k = p.k; } return tail; };
    outer: while (q.length) {
      const nq = [];
      for (let i = 0; i < q.length; i++) {
        const W = q[i], r = play(T, W, null);
        if (r.ok && r.done) { res = back(W, [{ t: 'play' }]); break outer; }
        if (r.ok) { const k2 = wkey(r.W); if (!seen.has(k2)) { seen.set(k2, { k: wkey(W), m: { t: 'play' } }); q.push(r.W); } }
      }
      for (const W of q) {
        const k = wkey(W);
        for (const m of moves(T, W)) { const N = doMove(W, m), k2 = wkey(N); if (!seen.has(k2)) { seen.set(k2, { k, m }); nq.push(N); } }
      }
      q = nq;
    }
    if (T.idx >= 0) {
      if (SOLC.size > 600) SOLC.clear();
      SOLC.set(k0, res);
      if (res) { let W = W0; for (let i = 0; i < res.length - 1; i++) { W = res[i].t === 'play' ? play(T, W, null).W : doMove(W, res[i]); SOLC.set(T.idx + ':' + wkey(W), res.slice(i + 1)); } }
    }
    return res;
  }
  const nMoves = (path) => (path ? path.filter((m) => m.t !== 'play').length : -1);

  /*__DEF__*/
  /* ================= 판 상태 ================= */
  function chapterOf(idx) { let a = 0; for (let c = 0; c < CHAPTERS.length; c++) { if (idx < a + CHAPTERS[c].n) return { c, k: idx - a, n: CHAPTERS[c].n, first: a }; a += CHAPTERS[c].n; } return { c: 0, k: 0, n: 1, first: 0 }; }
  function newStage(s, idx) {
    const T = prep(idx), W = world0(T);
    s.st = idx; s.ph = 0; s.ar = W.ar; s.fl = W.fl; s.dyn = W.dyn; s.pw = 1; s.ac = W.ac;
    s.mv = 0; s.tr = 0; s.hu = s.hu | 0; s.won = 0; s.fin = 0; s.hint = null; s.cpa = null;
    s.last = { id: ((s.last && s.last.id) | 0) + 1, t: 'new' };
    return s;
  }
  const WHY = {
    seen: '순찰의 불빛 안으로 걸어 들어갔다.',
    cam: '감시 장치가 켜져 있었다.',
    locked: '문은 잠겨 있었고 열쇠는 없었다.',
    wall: '이 층으로는 들어설 길이 없다.',
    dead: '막다른 벽이다. 다음 칸으로 이어지지 않는다.',
    exit: '끝까지 왔지만 출구는 다른 층에 있다.',
  };
  const NAMES = ['검은 외투', '회색 모자'];

  const def = {
    id: 'panelcut', name: '컷 바꾸기', tag: '만화 칸 퍼즐', cat: '보드',
    blurb: '한 쪽의 만화 칸을 맞바꾸고 뒤집어 도주극의 결말을 바꾼다. 검은 외투가 순찰을 피해 마지막 칸을 빠져나가면 통과.',
    tint: '#2c3444', time: '단계마다 1–3분',
    icon: '<rect x="7" y="9" width="19" height="16" rx="1.5" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="30" y="9" width="19" height="16" rx="1.5" fill="currentColor" opacity=".5"/><rect x="7" y="30" width="19" height="17" rx="1.5" fill="currentColor" opacity=".5"/><rect x="30" y="30" width="19" height="17" rx="1.5" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M13 21v-6l3 2M16 15l-3 6" fill="none" stroke="currentColor" stroke-width="2"/><path d="M35 43h9M41 39l4 4-4 4" fill="none" stroke="currentColor" stroke-width="2.2"/>',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, noAI: true, hidden: false, aiDelay: 520, undo: false,
    controls: [
      { id: 'left', label: '칸 고르기 ←', keys: ['ArrowLeft', 'KeyA'], pad: ['left'] },
      { id: 'right', label: '칸 고르기 →', keys: ['ArrowRight', 'KeyD'], pad: ['right'] },
      { id: 'up', label: '칸 고르기 ↑', keys: ['ArrowUp', 'KeyW'], pad: ['up'] },
      { id: 'down', label: '칸 고르기 ↓', keys: ['ArrowDown', 'KeyS'], pad: ['down'] },
      { id: 'ok', label: '집기 · 맞바꾸기', keys: ['Space', 'Enter'], pad: ['a'] },
      { id: 'flip', label: '뒤집기', keys: ['KeyF'], pad: ['x'] },
      { id: 'play', label: '재생', keys: ['KeyP'], pad: ['start'] },
      { id: 'hint', label: '힌트', keys: ['KeyH'], pad: ['y'] },
      { id: 'reset', label: '처음 배열로', keys: ['KeyR'], pad: ['back'] },
      { id: 'speed', label: '재생 속도', keys: ['KeyT'], pad: ['rb'] },
    ],
    quick: [
      '목표: 검은 외투가 첫 칸부터 마지막 칸까지 붙잡히지 않고 지나가게 한다.',
      '칸을 끌어 다른 칸 위에 놓으면 두 칸이 자리를 바꾼다. 다 놓았으면 「재생」.',
      '막히면 어느 칸에서 왜 막혔는지 표시된다. 배열을 고쳐 다시 재생한다.',
    ],
    rules: [
      { h: '읽는 순서', p: [
        '칸은 번호 순서대로 읽힌다. 검은 외투는 1번 칸의 왼쪽에서 들어와 오른쪽으로 걷고, 다음 칸의 같은 층으로 넘어간다.',
        '칸마다 위층과 아래층이 있다. 칸 가장자리가 벽으로 막힌 층으로는 들어가거나 나갈 수 없다.',
        '마지막 칸 오른쪽의 노란 표시가 출구다. 표시가 한 층에만 있으면 그 층으로 나가야 한다.',
      ] },
      { h: '칸 바꾸기', p: [
        '칸을 끌어 다른 칸 위에 놓으면 두 칸이 자리를 바꾼다. 칸을 누르고 다른 칸을 눌러도 같다.',
        '오른쪽 위에 둥근 화살표가 있는 칸은 그 표시를 누르면 좌우로 뒤집힌다. 순찰이 보는 방향, 계단의 방향, 벽의 위치가 함께 뒤집힌다.',
        '위쪽에 못이 박힌 칸은 옮길 수 없다.',
        '수는 맞바꾸기와 뒤집기만 센다. 재생은 몇 번을 해도 된다.',
      ] },
      { h: '순찰', p: [
        '불빛을 이쪽(왼쪽)으로 비추는 순찰이 있는 층으로 가면 붙잡힌다.',
        '등을 돌린 순찰은 뒤에서 제압하고 지나간다. 쓰러진 순찰은 그 뒤로도 쓰러져 있다.',
        '머리 위에 양쪽 화살표가 있는 순찰은 칸마다 돌아선다. 그 칸이 홀수 번째 자리냐 짝수 번째 자리냐에 따라 보는 방향이 바뀌고, 칸을 옮기면 그림도 바로 바뀐다.',
        '계단이나 사다리로 층을 바꿔 내려선 자리가 등 돌린 순찰의 앞쪽이면 들킨다.',
      ] },
      { h: '계단 · 사다리 · 승강기', p: [
        '계단을 만나면 반드시 오르내린다. 뒤집으면 오르는 계단이 내려가는 계단이 된다.',
        '사다리는 앞길이 막혔을 때만 탄다. 앞이 트여 있으면 그냥 지나간다.',
        '승강기는 전기가 들어와 있을 때만 움직인다. 타면 다른 층으로 옮겨진다.',
      ] },
      { h: '소품', p: [
        '열쇠: 지나가며 줍는다. 잠긴 문 하나를 열고 없어진다. 열린 문은 계속 열려 있다.',
        '병: 지나가며 줍는다. 이쪽을 보는 순찰을 만나면 던져서 시선을 돌리고 지나간다. 한 번 쓰면 없어진다.',
        '차단기: 지나가며 내린다. 전기가 끊기면 감시 장치가 꺼지고 승강기가 선다. 한 번 더 지나가면 다시 켜진다.',
        '감시 장치: 전기가 들어와 있으면 그 층을 지날 수 없다. 병으로는 속일 수 없다.',
      ] },
      { h: '동행 · 다시 읽기', p: [
        '회색 모자가 함께 가는 단계에서는 칸마다 검은 외투가 먼저, 회색 모자가 뒤이어 지나간다. 두 사람 모두 빠져나가야 한다. 앞사람이 쓰러뜨린 순찰과 열어 둔 문은 뒷사람에게도 그대로다.',
        '「멈춤」 표시가 있는 단계에서는 그 칸 앞에서 재생이 한 번 멈춘다. 이때 이미 지나온 칸을 뒤쪽으로 옮겨 다시 쓸 수 있다. 쓰러진 순찰, 열린 문, 주운 소품은 그대로 남는다.',
      ] },
      { h: '도움', p: [
        '힌트: 다음에 옮기거나 뒤집을 칸을 하나 알려 준다. 횟수 제한은 없다.',
        '되감기: 막힌 칸의 처음부터 다시 보여 준다. 속도: 재생 빠르기를 바꾼다.',
        '단계: 통과한 단계와 열린 단계를 고른다. 막힌 단계는 건너뛸 수 있다.',
        '진행은 이 기기에 저장된다.',
      ] },
      { h: '예시', p: [
        '1번 칸에 이쪽을 보는 순찰, 2번 칸에 오르는 계단이 있다면: 두 칸을 맞바꿔 먼저 계단으로 위층에 오른 뒤 순찰의 머리 위를 지나간다.',
      ] },
      { h: '조작(PC)', p: ['마우스로 칸을 끌거나 누른다. 방향키로 칸을 고르고 Space로 집기 · 맞바꾸기, F 뒤집기, P 재생, H 힌트, R 처음 배열, T 속도.'] },
    ],
    tutorial: [
      { text: '칸은 번호 순서대로 읽힌다. 검은 외투는 왼쪽에서 들어와 오른쪽으로 걷는다.' },
      { text: '칸을 끌어 다른 칸 위에 놓으면 두 칸이 자리를 바꾼다. 불빛이 이쪽을 향한 순찰은 피해야 한다.' },
      { text: '배열을 마쳤으면 「재생」. 막히면 어디서 왜 막혔는지 표시된다.', sel: '.pc-bar' },
    ],

    init(players, opts) {
      const o = store();
      const op = U.clamp ? U.clamp(o.op | 0 || 1, 1, STAGES.length) : Math.max(1, Math.min(STAGES.length, o.op | 0 || 1));
      let cur = o.cur | 0; if (cur < 0 || cur >= op) cur = op - 1;
      return newStage({ op, hu: 0, last: null }, cur);
    },
    actor(s) { return s.end ? null : 0; },
    apply(s, seat, a) {
      if (!a || s.end) throw new Error('bad');
      const T = prep(s.st), t = a.t, id = s.last.id + 1;
      if (t === 'swap') {
        const i = a.a | 0, j = a.b | 0;
        if (s.won || i === j || i < 0 || j < 0 || i >= T.n || j >= T.n) throw new Error('bad slot');
        if (T.P[s.ar[i]].pin || T.P[s.ar[j]].pin) throw new Error('pinned');
        const x = s.ar[i]; s.ar[i] = s.ar[j]; s.ar[j] = x; s.mv++; s.hint = null;
        s.last = { id, t: 'swap', a: i, b: j };
      } else if (t === 'flip') {
        const i = a.a | 0;
        if (s.won || i < 0 || i >= T.n || !T.P[s.ar[i]].fl) throw new Error('no flip');
        const pi = s.ar[i]; s.fl[pi] = s.fl[pi] ? 0 : 1; s.mv++; s.hint = null;
        s.last = { id, t: 'flip', a: i };
      } else if (t === 'play') {
        if (s.won) throw new Error('won');
        const pre = cloneW(s), r = play(T, s, null);
        s.last = { id, t: 'play', pre, ok: r.ok ? 1 : 0, done: r.done ? 1 : 0, fail: r.fail || null };
        s.hint = null;
        if (!r.ok) s.tr++;
        else {
          if (!r.done) s.cpa = { ar: pre.ar, fl: pre.fl };
          s.ph = r.W.ph; s.dyn = r.W.dyn; s.pw = r.W.pw; s.ac = r.W.ac;
          if (r.done) { s.won = 1; s.op = Math.max(s.op, Math.min(STAGES.length, s.st + 2)); }
        }
      } else if (t === 'rw') {
        if (!s.ph || s.won || !s.cpa) throw new Error('no checkpoint');
        const W = world0(T);
        s.ph = 0; s.ar = s.cpa.ar; s.fl = s.cpa.fl; s.dyn = W.dyn; s.pw = 1; s.ac = W.ac; s.cpa = null; s.hint = null;
        s.last = { id, t: 'rw' };
      } else if (t === 'reset') {
        newStage(s, s.st); s.last.t = 'reset';
      } else if (t === 'hint') {
        if (s.won) throw new Error('won');
        const p = solve(T, cloneW(s));
        s.hu++;
        s.hint = !p ? { k: s.ph ? 'rw' : 'reset' } : p[0].t === 'play' ? { k: 'play' } : { k: p[0].t, a: p[0].a, b: p[0].b };
        s.last = { id, t: 'hint' };
      } else if (t === 'skip') {
        if (s.st + 1 >= STAGES.length) throw new Error('last');
        s.op = Math.max(s.op, s.st + 2); newStage(s, s.st + 1); s.last.t = 'skip';
      } else if (t === 'next') {
        if (!s.won) throw new Error('not yet');
        if (s.st + 1 >= STAGES.length) { s.fin = 1; s.last = { id, t: 'fin' }; } else newStage(s, s.st + 1);
      } else if (t === 'go') {
        const n = a.n | 0;
        if (n < 0 || n >= s.op || n >= STAGES.length) throw new Error('locked');
        newStage(s, n);
      } else if (t === 'end') {
        if (!s.won) throw new Error('not yet');
        s.end = 1;
      } else throw new Error('unknown');
      return s;
    },
    ai(s, seat, lv) {
      if (s.won) return { t: 'end' };
      const T = prep(s.st), p = solve(T, cloneW(s));
      if (!p) return { t: s.ph ? 'rw' : 'reset' };
      const w = lv >= 3 ? 0 : lv === 2 ? 0.12 : 0.3;
      if (s.mv < 10 && Math.random() < w) {
        if (s.tr < 2 && Math.random() < 0.4) return { t: 'play' };
        const ms = moves(T, s); if (ms.length) return ms[Math.floor(Math.random() * ms.length)];
      }
      return p[0];
    },
    result(s) {
      if (!s.end) return null;
      const c = chapterOf(s.st), par = STAGES[s.st].m | 0;
      return { winners: [0], title: (c.c + 1) + '장 ' + (c.k + 1) + '번 통과', text: CHAPTERS[c.c].t + ' — ' + s.mv + '수 만에 빠져나갔다.',
        stats: [{ label: '옮긴 수', value: String(s.mv) }, { label: '최소 수', value: String(par) }, { label: '막힌 횟수', value: String(s.tr) }, { label: '힌트', value: String(s.hu) }] };
    },

    mount(root, api) {
      const cvs = U.canvas(root), cv = cvs.cv, ctx = cvs.ctx;
      const SP = () => (L.debug && L.debug.speed) || 1;
      const FXK = () => (L.fx ? L.fx() : 1);
      const isAI = !!(api.players[0] && api.players[0].ai);
      const FD = '"Black Han Sans","IBM Plex Sans KR",sans-serif', FB = '"IBM Plex Sans KR",system-ui,sans-serif', FM = '"IBM Plex Mono",monospace';
      let S = null, T = null, LAY = null, dirty = true, now = 0, stop = null;
      let sel = -1, kcur = -1, press = null, drag = null, PB = null, hold = null, slide = {}, flipA = {}, nudge = null, winT = 0, msg = null, flash = 0;
      let spd = [1, 2, 4].indexOf(store().sp) >= 0 ? store().sp : 1;

      /* ---------- 아래 막대 · 자막 ---------- */
      const SVG = (d, fill) => '<svg viewBox="0 0 24 24" width="20" height="20" fill="' + (fill ? 'currentColor' : 'none') + '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>';
      const bar = L.h('div', { class: 'pc-bar', style: { position: 'absolute', left: '0', right: '0', bottom: '0', display: 'flex', gap: '5px', padding: '6px 8px 10px', justifyContent: 'center', zIndex: 5, maxWidth: '720px', margin: '0 auto' } });
      const mkBtn = (svg, lab, fn, flex, primary) => {
        const b = L.h('button', { class: 'btn sm' + (primary ? ' primary' : ''), style: { flex: (flex || 1) + ' 1 0', minWidth: '44px', minHeight: '54px', padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '2px', lineHeight: '1.1' }, onclick: (e) => { e.stopPropagation(); fn(); } });
        const i = L.h('span', { html: svg, style: { height: '20px', display: 'flex', alignItems: 'center', fontFamily: FM, fontSize: '15px' } }), t = L.h('span', { style: { fontSize: '12px', whiteSpace: 'nowrap' }, text: lab });
        b.append(i, t); bar.append(b); return { b, t, i };
      };
      const act = (a) => { if (!S || PB || !api.canAct(0)) return false; clearHold(); api.act(a); return true; };
      const bList = mkBtn(SVG('<rect x="4" y="4" width="6.5" height="6.5"/><rect x="13.5" y="4" width="6.5" height="6.5"/><rect x="4" y="13.5" width="6.5" height="6.5"/><rect x="13.5" y="13.5" width="6.5" height="6.5"/>'), '단계', () => openPicker());
      const bReset = mkBtn(SVG('<path d="M5 12a7 7 0 1 0 2.2-5.1"/><path d="M5 4v4h4"/>'), '처음', () => { if (!S) return; sel = -1; act(S.ph ? { t: 'rw' } : { t: 'reset' }); });
      const bHint = mkBtn(SVG('<circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.6a2.5 2.5 0 1 1 3.6 2.3c-.8.5-1.2 1-1.2 1.9"/><path d="M12 17v.2"/>'), '힌트', () => act({ t: 'hint' }));
      const bSpd = mkBtn('1×', '속도', () => { spd = spd === 1 ? 2 : spd === 2 ? 4 : 1; const o = store(); o.sp = spd; save(o); refreshBar(); });
      const bRw = mkBtn(SVG('<path d="M11 6l-7 6 7 6z"/><path d="M20 6l-7 6 7 6z"/>', 1), '되감기', () => rewind());
      const bPlay = mkBtn(SVG('<path d="M7 4.5l12 7.5-12 7.5z"/>', 1), '재생', () => { sel = -1; act({ t: 'play' }); }, 1.7, true);
      bList.b.dataset.action = 'list'; bReset.b.dataset.action = 'reset'; bHint.b.dataset.action = 'hint'; bSpd.b.dataset.action = 'speed'; bRw.b.dataset.action = 'rewind'; bPlay.b.dataset.action = 'play';
      const cap = L.h('div', { class: 'pc-cap', style: { position: 'absolute', left: '0', right: '0', bottom: '76px', padding: '0 14px', minHeight: '40px', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '2px', textAlign: 'center', pointerEvents: 'none', zIndex: 4, wordBreak: 'keep-all', lineHeight: '1.38' } });
      const capA = L.h('div', { style: { fontSize: '13px', color: '#b9aec4' } }), capB = L.h('div', { style: { fontSize: '13.5px', color: '#f2e9d8', fontWeight: '500' } });
      cap.append(capA, capB);
      root.append(cap, bar);

      let ov = null;
      function closeOv() { if (ov) { ov.remove(); ov = null; } }
      function sheet(children, low) {
        closeOv();
        ov = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'flex', alignItems: low ? 'flex-end' : 'center', justifyContent: 'center', padding: low ? '0 8px 8px' : '16px', background: low ? 'transparent' : 'rgba(10,8,15,.62)', pointerEvents: low ? 'none' : 'auto' }, onpointerdown: (e) => { if (e.target === ov && !low) closeOv(); } });
        const sh = L.h('div', { class: 'sheet', style: { maxHeight: '88%', gap: '10px', pointerEvents: 'auto', padding: low ? '14px 16px' : '18px', boxShadow: '0 -6px 24px rgba(0,0,0,.45)' } });
        children.forEach((c) => c && sh.append(c));
        ov.append(sh); root.append(ov);
      }
      function openPicker() {
        if (!S || PB) return;
        const o = store(), done = o.done || {}, best = o.best || {};
        const box = L.h('div', { style: { overflowY: 'auto', maxHeight: '56vh', display: 'flex', flexDirection: 'column', gap: '10px' } });
        let idx = 0;
        CHAPTERS.forEach((c, ci) => {
          const first = idx, open = first < S.op;
          box.append(L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '8px', opacity: open ? '1' : '.5' } },
            L.h('span', { style: { fontFamily: FD, fontSize: '17px' }, text: (ci + 1) + '장 ' + c.t }), L.h('span', { class: 'muted', style: { fontSize: '12px' }, text: open ? c.rule : '아직 열리지 않음' })));
          const grid = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: '6px' } });
          for (let k = 0; k < c.n; k++, idx++) {
            const n = idx, ok = n < S.op, cur = n === S.st;
            const b = L.h('button', { class: 'btn sm' + (cur ? ' primary' : ''), disabled: !ok, style: { minHeight: '50px', padding: '2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', lineHeight: '1.15', opacity: ok ? '1' : '.35' }, onclick: () => { closeOv(); sel = -1; act({ t: 'go', n }); } });
            b.append(L.h('span', { class: 'mono', style: { fontSize: '16px' }, text: String(k + 1) }), L.h('span', { style: { fontSize: '12px', opacity: '.85' }, text: done[n] ? (best[n] != null ? best[n] + '수' : '통과') : ok ? '—' : '잠김' }));
            grid.append(b);
          }
          box.append(grid);
        });
        const nDone = Object.keys(done).length;
        sheet([L.h('h2', { text: '단계', style: { fontSize: '24px' } }),
          L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: '통과 ' + nDone + ' / ' + STAGES.length + ' · 숫자 아래는 가장 적게 옮긴 수' }), box,
          L.h('div', { style: { display: 'flex', gap: '8px' } },
            S.st + 1 < STAGES.length && !S.won ? L.h('button', { class: 'btn ghost', style: { minHeight: '48px', flex: '1' }, text: '이 단계 건너뛰기', onclick: () => { closeOv(); sel = -1; act({ t: 'skip' }); } }) : null,
            L.h('button', { class: 'btn', style: { minHeight: '48px', flex: '1' }, text: '닫기', onclick: closeOv }))]);
        setTimeout(() => { const c = box.querySelector('.primary'); if (c && c.scrollIntoView) c.scrollIntoView({ block: 'center' }); }, 0);
      }
      function winPanel() {
        if (!S || !S.won) return;
        const par = STAGES[S.st].m | 0, c = chapterOf(S.st), last = S.st + 1 >= STAGES.length;
        const endCh = c.k === c.n - 1;
        sheet([
          L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '10px', flexWrap: 'wrap' } },
            L.h('span', { style: { fontFamily: FD, fontSize: '22px' }, text: '통과' }),
            L.h('span', { class: 'mono', style: { fontSize: '14px' }, text: S.mv + '수' + (par ? ' · 최소 ' + par + '수' : '') })),
          endCh ? L.h('p', { style: { margin: 0, fontSize: '13px', lineHeight: '1.45', color: '#cfc5d8', wordBreak: 'keep-all' }, text: CHAPTERS[c.c].end }) : null,
          L.h('div', { style: { display: 'flex', gap: '8px' } },
            L.h('button', { class: 'btn', 'data-action': 'again', style: { minHeight: '48px', flex: '1' }, text: '다시', onclick: () => { closeOv(); api.act({ t: 'reset' }); } }),
            L.h('button', { class: 'btn primary', 'data-action': 'next', style: { minHeight: '48px', flex: '2', fontSize: '16px' }, text: last ? '마지막 쪽' : endCh ? '다음 장' : '다음 단계', onclick: () => { closeOv(); api.act({ t: 'next' }); } }))], true);
      }
      function finPanel() {
        sheet([L.h('h2', { text: '끝', style: { fontSize: '26px' } }),
          L.h('p', { style: { margin: 0, fontSize: '14px', lineHeight: '1.55', wordBreak: 'keep-all' }, text: '배는 안개 속으로 들어갔다. 검은 외투는 난간에 기대어 장부를 꺼냈다가, 펴 보지 않고 도로 넣었다. 도시는 뒤에 남았다.' }),
          L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: '모든 단계를 지났다. 단계 창에서 더 적은 수로 다시 풀 수 있다.' }),
          L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '단계 고르기', onclick: () => openPicker() }),
          L.h('button', { class: 'btn primary', style: { minHeight: '50px' }, text: '마치기', onclick: () => { closeOv(); api.act({ t: 'end' }); } })]);
      }
      function setCap() {
        if (!S) return;
        const c = chapterOf(S.st), C = CHAPTERS[c.c];
        let a = C.lines[c.k] || '', b = '';
        if (msg) b = msg;
        else if (hold) { const f = hold.fail; a = (f.s + 1) + '번 칸에서 막힘'; b = (S.ac.length > 1 ? NAMES[f.w] + ' — ' : '') + WHY[f.why]; }
        else if (PB) b = '';
        else if (S.won) b = '';
        else if (S.hint) {
          const h = S.hint;
          b = h.k === 'play' ? '이 배열이면 된다. 재생한다.' : h.k === 'swap' ? (h.a + 1) + '번 칸과 ' + (h.b + 1) + '번 칸을 맞바꾼다.' : h.k === 'flip' ? (h.a + 1) + '번 칸을 뒤집는다.' : h.k === 'rw' ? '여기서는 길이 없다. 「처음」으로 멈춤 앞 장면으로 돌아간다.' : '처음 배열로 돌아간다.';
        } else if (S.ph) b = '멈춤. 지나온 칸도 뒤로 옮겨 다시 쓸 수 있다.';
        else if (c.k === 0 && S.mv === 0 && S.tr === 0) b = C.rule2 || '';
        else if (S.tr >= 3 && S.mv < 40) b = '막히면 힌트를 쓰거나 단계 창에서 건너뛸 수 있다.';
        capA.textContent = a; capB.textContent = b;
        capA.style.color = hold ? '#e58a74' : '#b9aec4';
      }
      function refreshBar() {
        if (!S) return;
        const dis = (b, v) => { b.b.disabled = !v; b.b.style.opacity = v ? '1' : '.4'; };
        const edit = !PB && !S.won && api.canAct(0);
        dis(bList, !PB); dis(bReset, edit && (S.mv > 0 || S.ph || S.tr > 0)); dis(bHint, edit); dis(bSpd, true); dis(bRw, !PB && !!hold); dis(bPlay, edit);
        bReset.t.textContent = S.ph ? '멈춤 앞' : '처음';
        bSpd.i.textContent = spd + '×';
        bPlay.t.textContent = S.ph ? '이어 재생' : '재생';
        bPlay.b.style.boxShadow = S.hint && S.hint.k === 'play' && edit ? '0 0 0 3px rgba(219,162,58,.55)' : '';
        bReset.b.style.boxShadow = S.hint && (S.hint.k === 'rw' || S.hint.k === 'reset') && edit ? '0 0 0 3px rgba(219,162,58,.55)' : '';
        setCap(); dirty = true;
      }
      function say(t, ms) { msg = t; setCap(); const m = t; setTimeout(() => { if (msg === m) { msg = null; setCap(); } }, ms || 1500); }

      /* ---------- 배치 ---------- */
      function layout() {
        if (!T) return;
        const W = cvs.w, H = cvs.h, g = 9, pad = 11;
        const ax = 6, ay = 50, aw = W - 12, ah = H - 76 - 66 - ay;
        let best = null;
        for (let cols = 1; cols <= Math.min(3, T.n); cols++) {
          const rows = Math.ceil(T.n / cols);
          let w = (aw - 2 * pad - (cols - 1) * g) / cols, h = (ah - 2 * pad - (rows - 1) * g) / rows;
          w = Math.min(w, h * 1.62, 440); h = Math.min(h, w / 0.95); w = Math.min(w, h * 1.62);
          if (w < 60) continue;
          const sc = w * h * (cols === 2 ? 1.02 : 1);
          if (!best || sc > best.sc) best = { sc, cols, rows, w, h };
        }
        const b = best, pw = b.cols * b.w + (b.cols - 1) * g + 2 * pad, ph = b.rows * b.h + (b.rows - 1) * g + 2 * pad;
        const px = Math.round(ax + (aw - pw) / 2), py = Math.round(ay + Math.max(0, (ah - ph) / 2) * 0.6);
        const slots = [];
        for (let i = 0; i < T.n; i++) { const r = Math.floor(i / b.cols), c = i % b.cols; slots.push({ x: px + pad + c * (b.w + g), y: py + pad + r * (b.h + g), w: b.w, h: b.h }); }
        LAY = { page: { x: px, y: py, w: pw, h: ph }, slots, cols: b.cols, rows: b.rows };
        dirty = true;
      }
      cvs.onresize = layout;
      const slotAt = (p) => { if (!LAY) return -1; for (let i = 0; i < LAY.slots.length; i++) { const r = LAY.slots[i]; if (p.x >= r.x - 4 && p.x <= r.x + r.w + 4 && p.y >= r.y - 4 && p.y <= r.y + r.h + 4) return i; } return -1; };

      /* ---------- 그림 ---------- */
      const INK = '#17141c', PAPER = '#e9e0cb', AMBER = '#dba23a', RED = '#b8412c', GUARD = '#27344c', GREY = '#6b7482';
      const PAL = [['#b7bab5', '#a3a8a6'], ['#c2b6a2', '#ad9f8b'], ['#a9b2ac', '#94a09a'], ['#bfae9e', '#a8968a'], ['#aab1bd', '#959daa'],
        ['#a4b3b5', '#8fa0a3'], ['#b9b3a6', '#a39d90'], ['#a6adb9', '#9198a6'], ['#b5b0bd', '#9f9aa9'], ['#c0b9a8', '#a9a391']];
      function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath(); }
      function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
      // 사람 그림자: kind 0 검은 외투, 1 회색 모자, 2 순찰
      function person(x, fy, hgt, dir, kind, ph, down, alpha) {
        ctx.save(); ctx.translate(x, fy); if (alpha != null) ctx.globalAlpha *= alpha;
        if (down) { ctx.translate(dir * hgt * 0.1 * down, 0); ctx.rotate(dir * down * Math.PI * 0.47); }
        ctx.scale(dir, 1);
        const h = hgt, col = kind === 0 ? INK : kind === 1 ? GREY : GUARD;
        ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineCap = 'round';
        const sw = Math.sin(ph) * h * 0.13;
        ctx.lineWidth = Math.max(2, h * 0.085);
        ctx.beginPath(); ctx.moveTo(-h * 0.03, -h * 0.4); ctx.lineTo(sw, -h * 0.04); ctx.moveTo(h * 0.03, -h * 0.4); ctx.lineTo(-sw, -h * 0.04); ctx.stroke();
        ctx.beginPath();
        if (kind === 2) { ctx.moveTo(-h * 0.11, -h * 0.76); ctx.lineTo(h * 0.11, -h * 0.76); ctx.lineTo(h * 0.1, -h * 0.36); ctx.lineTo(-h * 0.1, -h * 0.36); }
        else { ctx.moveTo(-h * 0.12, -h * 0.77); ctx.lineTo(h * 0.12, -h * 0.77); ctx.lineTo(h * 0.17, -h * 0.26); ctx.lineTo(-h * 0.19, -h * 0.26); }
        ctx.closePath(); ctx.fill();
        if (kind === 1) { ctx.strokeStyle = INK; ctx.lineWidth = 1; ctx.stroke(); }
        ctx.beginPath(); ctx.arc(0, -h * 0.86, h * 0.1, 0, 7); ctx.fill();
        if (kind === 2) { // 모자챙
          ctx.fillRect(-h * 0.11, -h * 0.99, h * 0.22, h * 0.08); ctx.fillRect(0, -h * 0.935, h * 0.19, h * 0.035);
          ctx.fillStyle = AMBER; ctx.fillRect(h * 0.02, -h * 0.68, h * 0.05, h * 0.05);
        } else { // 중절모
          ctx.fillRect(-h * 0.2, -h * 0.955, h * 0.4, h * 0.04); ctx.fillRect(-h * 0.11, -h * 1.06, h * 0.22, h * 0.12);
          ctx.fillStyle = kind === 0 ? RED : PAPER; ctx.fillRect(-h * 0.1, -h * 0.795, h * 0.2, h * 0.055);
        }
        ctx.restore();
      }
      function keyIcon(x, y, s) { ctx.strokeStyle = AMBER; ctx.fillStyle = AMBER; ctx.lineWidth = 1.8 * s; ctx.beginPath(); ctx.arc(x - 3.5 * s, y, 3 * s, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.moveTo(x - 0.5 * s, y); ctx.lineTo(x + 7 * s, y); ctx.moveTo(x + 4 * s, y); ctx.lineTo(x + 4 * s, y + 3 * s); ctx.moveTo(x + 6.6 * s, y); ctx.lineTo(x + 6.6 * s, y + 2.6 * s); ctx.stroke(); }
      function bottleIcon(x, y, s) { ctx.fillStyle = AMBER; ctx.fillRect(x - 2.6 * s, y - 9 * s, 5.2 * s, 9 * s); ctx.fillRect(x - 1.1 * s, y - 13.5 * s, 2.2 * s, 5 * s); ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.fillRect(x - 1.6 * s, y - 7.5 * s, 1.2 * s, 5 * s); }
      function halo(x, y, r) { ctx.fillStyle = 'rgba(244,236,214,.62)'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }

      function drawPanel(R, pi, flip, V, slot, o) {
        const P = T.P[pi], E = eff(P, flip), dyn = V.dyn[pi], pw = V.pw;
        const x = R.x, y = R.y, w = R.w, h = R.h, pal = PAL[chapterOf(T.idx).c % PAL.length];
        const mid = y + h * 0.48, fy = [mid, y + h * 0.955], top = [y, mid + 3], LH = h * 0.455, u = w / 4, s = Math.max(0.8, LH / 48);
        const PX = (v) => x + u * v, PH = LH * 0.76;
        ctx.save(); rr(x, y, w, h, 4); ctx.clip();
        ctx.fillStyle = pal[0]; ctx.fillRect(x, y, w, h * 0.48); ctx.fillStyle = pal[1]; ctx.fillRect(x, mid, w, h * 0.52);
        // 배경: 블라인드 창 · 등
        const hs = hash(P.src), mx = (v) => (flip ? 4 - v : v);
        const wxs = [0.55 + (hs % 3) * 0.5, 2.6 + ((hs >>> 3) % 3) * 0.4];
        ctx.fillStyle = 'rgba(244,236,214,.42)';
        for (let k = 0; k < 2; k++) { const cx = PX(mx(wxs[k])), ww = u * 0.52, wh = LH * 0.42, wy = y + LH * 0.2; ctx.fillRect(cx - ww / 2, wy, ww, wh); }
        ctx.fillStyle = pal[0];
        for (let k = 0; k < 2; k++) { const cx = PX(mx(wxs[k])), ww = u * 0.52, wh = LH * 0.42, wy = y + LH * 0.2; for (let q = 1; q < 5; q++) ctx.fillRect(cx - ww / 2, wy + wh * q / 5 - 0.8, ww, 1.6); }
        const lx = PX(mx(1.2 + ((hs >>> 6) % 4) * 0.55));
        ctx.fillStyle = 'rgba(244,236,214,.13)'; ctx.beginPath(); ctx.moveTo(lx, top[1] + LH * 0.16); ctx.lineTo(lx - u * 0.42, fy[1]); ctx.lineTo(lx + u * 0.42, fy[1]); ctx.closePath(); ctx.fill();
        ctx.fillStyle = INK; ctx.fillRect(lx - 0.7, top[1], 1.4, LH * 0.1); ctx.fillRect(lx - 4 * s, top[1] + LH * 0.1, 8 * s, 3 * s);
        ctx.fillStyle = 'rgba(23,20,28,.13)'; for (let q = 0; q < 4; q++) { const bx = x + ((hs >>> (q * 4)) % 97) / 97 * w * 0.8, by = top[1] + LH * (0.25 + 0.15 * q); ctx.fillRect(bx, by, w * 0.12, 1.5); }
        // 바닥
        ctx.fillStyle = INK; ctx.fillRect(x, mid, w, 3); ctx.fillRect(x, fy[1], w, h);
        // 벽 · 트인 곳
        for (let l = 0; l < 2; l++) for (let e = 0; e < 2; e++) {
          const ex = e ? x + w : x;
          if (!E.open[l][e]) { ctx.fillStyle = INK; ctx.fillRect(e ? ex - 10 : ex, top[l], 10, fy[l] - top[l]); ctx.fillStyle = 'rgba(244,236,214,.16)'; for (let q = 1; q < 4; q++) ctx.fillRect(e ? ex - 10 : ex, top[l] + (fy[l] - top[l]) * q / 4, 10, 1); }
          else { const cy = fy[l] - LH * 0.42, cx = e ? ex - 9 : ex + 4; ctx.fillStyle = 'rgba(23,20,28,.5)'; ctx.beginPath(); ctx.moveTo(cx, cy - 4); ctx.lineTo(cx + 5, cy); ctx.lineTo(cx, cy + 4); ctx.closePath(); ctx.fill(); }
        }
        // 물건
        const ov2 = (o && o.ov) || null;
        for (const f of E.f) {
          const fx = PX(f.x), on = dyn & (1 << f.i), kk = pi + ':' + f.i;
          if (f.t === 'st') {
            const up = f.lane === 1, x0 = fx - u * 0.36, x1 = fx + u * 0.36, n = 5;
            ctx.fillStyle = INK; ctx.beginPath();
            if (up) { ctx.moveTo(x0, fy[1]); for (let q = 0; q < n; q++) { const sx = x0 + (x1 - x0) * (q + 1) / n, sy = fy[1] + (fy[0] - fy[1]) * (q + 1) / n; ctx.lineTo(x0 + (x1 - x0) * q / n, sy); ctx.lineTo(sx, sy); } ctx.lineTo(x1, fy[1]); }
            else { ctx.moveTo(x1, fy[1]); for (let q = 0; q < n; q++) { const sx = x1 + (x0 - x1) * (q + 1) / n, sy = fy[1] + (fy[0] - fy[1]) * (q + 1) / n; ctx.lineTo(x1 + (x0 - x1) * q / n, sy); ctx.lineTo(sx, sy); } ctx.lineTo(x0, fy[1]); }
            ctx.closePath(); ctx.fill();
          } else if (f.t === 'H') {
            const lw = u * 0.11; ctx.strokeStyle = INK; ctx.lineWidth = 2.2;
            ctx.beginPath(); ctx.moveTo(fx - lw, fy[1]); ctx.lineTo(fx - lw, fy[0] - LH * 0.3); ctx.moveTo(fx + lw, fy[1]); ctx.lineTo(fx + lw, fy[0] - LH * 0.3); ctx.stroke();
            ctx.lineWidth = 1.6; ctx.beginPath(); for (let yy = fy[1] - 5; yy > fy[0] - LH * 0.28; yy -= Math.max(5, LH * 0.14)) { ctx.moveTo(fx - lw, yy); ctx.lineTo(fx + lw, yy); } ctx.stroke();
          } else if (f.t === 'E') {
            const ew = u * 0.3;
            ctx.fillStyle = 'rgba(23,20,28,.22)'; ctx.fillRect(fx - ew, y + 2, ew * 2, fy[1] - y - 2);
            ctx.strokeStyle = INK; ctx.lineWidth = 2;
            for (let l = 0; l < 2; l++) { const ty = fy[l] - LH * 0.8; ctx.strokeRect(fx - ew + 1, ty, ew * 2 - 2, LH * 0.8); ctx.beginPath(); ctx.moveTo(fx, ty); ctx.lineTo(fx, fy[l]); ctx.stroke();
              ctx.fillStyle = pw ? AMBER : 'rgba(23,20,28,.45)'; const ay = ty - 5 * s, d = l ? -1 : 1; ctx.beginPath(); ctx.moveTo(fx - 4 * s, ay - d * 2 * s); ctx.lineTo(fx + 4 * s, ay - d * 2 * s); ctx.lineTo(fx, ay + d * 3 * s); ctx.closePath(); ctx.fill(); }
          } else if (f.t === 'g') {
            const l = f.lane, gy = fy[l];
            let down = on ? 1 : 0, left = faceL(f, slot);
            if (ov2 && ov2.turn[kk]) left = false;
            if (ov2 && ov2.ko[kk] != null) down = ov2.ko[kk];
            const dir = left ? -1 : 1;
            if (down < 0.5) {
              const seen = o && o.seen === kk;
              ctx.fillStyle = seen ? 'rgba(200,60,40,.6)' : 'rgba(226,170,60,' + (0.55 * (1 - down * 2)) + ')';
              ctx.beginPath(); ctx.moveTo(fx + dir * PH * 0.14, gy - PH * 0.6); ctx.lineTo(fx + dir * u * 0.92, gy - PH * 0.95); ctx.lineTo(fx + dir * u * 0.92, gy); ctx.lineTo(fx + dir * PH * 0.3, gy); ctx.closePath(); ctx.fill();
            }
            person(fx, gy, PH, dir, 2, 0, down);
            if (f.alt && down < 0.5) { // 번갈아 도는 표시
              const ay = gy - PH * 1.17, r = 3.1 * s;
              ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(fx, ay, r * 2.1, 0, 7); ctx.fill();
              ctx.fillStyle = AMBER;
              ctx.beginPath(); ctx.moveTo(fx - r * 1.55, ay); ctx.lineTo(fx - r * 0.25, ay - r * 0.9); ctx.lineTo(fx - r * 0.25, ay + r * 0.9); ctx.closePath(); ctx.fill();
              ctx.beginPath(); ctx.moveTo(fx + r * 1.55, ay); ctx.lineTo(fx + r * 0.25, ay - r * 0.9); ctx.lineTo(fx + r * 0.25, ay + r * 0.9); ctx.closePath(); ctx.fill();
            }
          } else if (f.t === 'C') {
            const l = f.lane, cy = top[l] + 2;
            if (pw) { ctx.fillStyle = (o && o.seen === kk) ? 'rgba(200,60,40,.6)' : 'rgba(184,65,44,.3)'; ctx.beginPath(); ctx.moveTo(fx, cy + 6 * s); ctx.lineTo(fx - u * 0.44, fy[l]); ctx.lineTo(fx + u * 0.44, fy[l]); ctx.closePath(); ctx.fill(); }
            ctx.fillStyle = INK; ctx.fillRect(fx - 1, cy - 2, 2, 4 * s); ctx.fillRect(fx - 6 * s, cy + 2 * s, 12 * s, 6.5 * s);
            ctx.fillStyle = pw ? '#e4553a' : '#6d6a70'; ctx.beginPath(); ctx.arc(fx, cy + 5.2 * s, 2 * s, 0, 7); ctx.fill();
          } else if (f.t === 'k') {
            if (!on) { const ky = fy[f.lane] - LH * 0.5; halo(fx, ky, 10 * s); ctx.fillStyle = INK; ctx.fillRect(fx - 0.8, ky - 13 * s, 1.6, 6 * s); keyIcon(fx - 1.5 * s, ky, s * 1.05); }
          } else if (f.t === 'b') {
            const by = fy[f.lane]; ctx.fillStyle = INK; ctx.fillRect(fx - 8 * s, by - 9 * s, 16 * s, 9 * s); ctx.fillStyle = 'rgba(244,236,214,.25)'; ctx.fillRect(fx - 8 * s, by - 5 * s, 16 * s, 1);
            if (!on) { halo(fx, by - 16 * s, 9 * s); bottleIcon(fx, by - 9 * s, s); }
          } else if (f.t === 'D') {
            const l = f.lane, dw = u * 0.13, t0 = fy[l] - LH * 0.9, opn = ov2 && ov2.door[kk] != null ? ov2.door[kk] : (on ? 1 : 0);
            ctx.fillStyle = INK; ctx.fillRect(fx - dw - 2, t0 - 3, dw * 2 + 4, 3); ctx.fillRect(fx - dw - 2, t0, 2, LH * 0.9); ctx.fillRect(fx + dw, t0, 2, LH * 0.9);
            const dwv = dw * 2 * (1 - 0.82 * opn);
            ctx.fillStyle = '#2b2230'; ctx.fillRect(fx + dw - dwv, t0, dwv, LH * 0.9);
            if (opn < 0.5) { ctx.strokeStyle = 'rgba(244,236,214,.22)'; ctx.lineWidth = 1; ctx.strokeRect(fx - dw + 2.5, t0 + 3, dw * 2 - 5, LH * 0.38); ctx.strokeRect(fx - dw + 2.5, t0 + LH * 0.48, dw * 2 - 5, LH * 0.36);
              ctx.fillStyle = AMBER; ctx.beginPath(); ctx.arc(fx + dw * 0.45, t0 + LH * 0.5, 2.3 * s, 0, 7); ctx.fill(); ctx.fillRect(fx + dw * 0.45 - 0.9 * s, t0 + LH * 0.5, 1.8 * s, 4 * s); }
          } else if (f.t === 'S') {
            const by = fy[f.lane] - LH * 0.62; ctx.fillStyle = INK; ctx.fillRect(fx - 6.5 * s, by - 8 * s, 13 * s, 17 * s); ctx.fillRect(fx - 0.8, by + 9 * s, 1.6, LH * 0.62 - 9 * s);
            ctx.strokeStyle = pw ? AMBER : '#8a8790'; ctx.lineWidth = 2.4 * s; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(fx, by + 1 * s); ctx.lineTo(fx + 4.5 * s, by + (pw ? -5.5 : 6.5) * s); ctx.stroke();
            ctx.fillStyle = pw ? AMBER : '#8a8790'; ctx.beginPath(); ctx.arc(fx - 3 * s, by - 4.5 * s, 1.5 * s, 0, 7); ctx.fill();
          }
        }
        if (!pw) { ctx.fillStyle = 'rgba(14,14,34,.3)'; ctx.fillRect(x, y, w, h); }
        if (o && o.read) { ctx.fillStyle = 'rgba(23,20,28,.16)'; ctx.fillRect(x, y, w, h); }
        ctx.restore();
        ctx.lineWidth = 2.5; ctx.strokeStyle = INK; rr(x, y, w, h, 4); ctx.stroke();
        // 번호
        ctx.fillStyle = INK; rr(x - 1, y - 9, 20, 18, 3); ctx.fill();
        ctx.fillStyle = PAPER; ctx.font = '700 12px ' + FM; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(slot + 1), x + 9, y + 0.5);
        if (P.pin) { const nx = x + w / 2, ny = y + 1; ctx.fillStyle = '#3a3340'; ctx.beginPath(); ctx.arc(nx, ny + 3, 6.5, 0, 7); ctx.fill(); ctx.fillStyle = '#c9c3b4'; ctx.beginPath(); ctx.arc(nx, ny + 3, 4.2, 0, 7); ctx.fill(); ctx.fillStyle = '#6f6a72'; ctx.beginPath(); ctx.arc(nx + 1, ny + 4, 1.6, 0, 7); ctx.fill(); }
        if (P.fl) { const cx = x + w - 13, cy = y + 13, glow = o && o.flipGlow;
          ctx.fillStyle = glow ? AMBER : PAPER; ctx.beginPath(); ctx.arc(cx, cy, 10, 0, 7); ctx.fill(); ctx.strokeStyle = INK; ctx.lineWidth = 1.5; ctx.stroke();
          ctx.lineWidth = 1.8; ctx.beginPath(); ctx.moveTo(cx - 5.5, cy); ctx.lineTo(cx + 5.5, cy); ctx.moveTo(cx - 2.5, cy - 3); ctx.lineTo(cx - 5.5, cy); ctx.lineTo(cx - 2.5, cy + 3); ctx.moveTo(cx + 2.5, cy - 3); ctx.lineTo(cx + 5.5, cy); ctx.lineTo(cx + 2.5, cy + 3); ctx.stroke(); }
        return { fy, LH, u, PH, s };
      }
      const geo = (R) => { const mid = R.y + R.h * 0.48, LH = R.h * 0.455; return { fy: [mid, R.y + R.h * 0.955], LH, u: R.w / 4, PH: LH * 0.76, s: Math.max(0.8, LH / 48) }; };
      const ease = (t) => (t < 0 ? 0 : t > 1 ? 1 : t * t * (3 - 2 * t));

      function drawActor(w, pos, inv) {
        const R = LAY.slots[pos.slot]; if (!R || pos.hide) return;
        const g = geo(R), xx = R.x + g.u * U.clamp(pos.x, 0.3, 3.7), fyv = g.fy[0] + (g.fy[1] - g.fy[0]) * pos.ly;
        ctx.save(); rr(R.x, R.y, R.w, R.h, 4); ctx.clip();
        person(xx, fyv, g.PH, 1, w, pos.ph || 0, 0, pos.a == null ? 1 : pos.a);
        let ix = xx - (inv.k + inv.b - 1) * 5 * g.s;
        for (let q = 0; q < inv.k; q++, ix += 10 * g.s) { ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(ix, fyv - g.PH * 1.25, 6.5 * g.s, 0, 7); ctx.fill(); keyIcon(ix - 1.2 * g.s, fyv - g.PH * 1.25, g.s * 0.62); }
        for (let q = 0; q < inv.b; q++, ix += 10 * g.s) { ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(ix, fyv - g.PH * 1.25, 6.5 * g.s, 0, 7); ctx.fill(); bottleIcon(ix, fyv - g.PH * 1.25 + 4.6 * g.s, g.s * 0.62); }
        ctx.restore();
      }

      function draw() {
        cvs.clear();
        if (!S || !LAY) return;
        const W = cvs.w, c = chapterOf(S.st), C = CHAPTERS[c.c];
        // 머리글
        ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
        ctx.fillStyle = '#f2e9d8'; ctx.font = '17px ' + FD; const title = (c.c + 1) + '장 ' + C.t; ctx.fillText(title, 12, 22);
        const tw = ctx.measureText(title).width;
        ctx.fillStyle = '#b9aec4'; ctx.font = '500 13px ' + FM; ctx.fillText((c.k + 1) + ' / ' + c.n, 20 + tw, 21);
        ctx.font = '12.5px ' + FB; ctx.fillStyle = '#b9aec4';
        ctx.fillText('옮긴 수 ' + S.mv + ' · 최소 ' + (STAGES[S.st].m | 0) + (S.pw || PB ? '' : ' · 전기 끊김'), 12, 41);
        // 쪽
        const pg = LAY.page;
        ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(pg.x + 2, pg.y + 4, pg.w, pg.h, 5); ctx.fill();
        ctx.fillStyle = PAPER; rr(pg.x, pg.y, pg.w, pg.h, 5); ctx.fill();
        const V = PB ? PB.vw : hold ? hold.vw : S, ar = S.ar, n = T.n;
        const from = (PB ? PB.pre.ph : hold ? hold.pre.ph : S.ph) ? T.cp : 0;
        // 멈춤 표시
        const hint = !PB && !hold && S.hint ? S.hint : null, pulse = 0.55 + 0.45 * Math.sin(now / 320);
        let dragPi = -1, overSlot = -1;
        if (drag) { dragPi = ar[drag.i]; overSlot = drag.over; }
        for (let i = 0; i < n; i++) {
          const pi = ar[i]; if (pi === dragPi) continue;
          let R = LAY.slots[i], a = 1;
          const sl = slide[pi];
          if (sl) { const t = ease(sl.t); R = { x: sl.x + (R.x - sl.x) * t, y: sl.y + (R.y - sl.y) * t, w: R.w, h: R.h }; }
          if (drag && i === overSlot) { R = LAY.slots[drag.i]; a = 0.82; }
          if (nudge && nudge.i === i) R = { x: R.x + Math.sin(nudge.t * 18) * 4 * (1 - nudge.t), y: R.y, w: R.w, h: R.h };
          const fa = flipA[pi];
          ctx.save(); ctx.globalAlpha = a;
          let fl = S.fl[pi];
          if (fa != null) { const k = Math.abs(Math.cos(Math.PI * ease(fa))); if (fa < 0.5) fl = fl ? 0 : 1; ctx.translate(R.x + R.w / 2, 0); ctx.scale(Math.max(0.02, k), 1); ctx.translate(-(R.x + R.w / 2), 0); }
          const slotShown = drag && i === overSlot ? drag.i : i;
          drawPanel(R, pi, fl, V, slotShown, { ov: PB ? PB.ov : hold ? hold.ov : null, seen: hold ? hold.seen : null, read: S.ph && !PB && i < T.cp, flipGlow: hint && hint.k === 'flip' && hint.a === i && pulse > 0.5 });
          ctx.restore();
          if (!PB && (sel === i || kcur === i)) { ctx.strokeStyle = sel === i ? AMBER : '#f2e9d8'; ctx.lineWidth = sel === i ? 4 : 2; rr(R.x - 3, R.y - 3, R.w + 6, R.h + 6, 6); ctx.stroke(); }
          if (hint && hint.k === 'swap' && (hint.a === i || hint.b === i)) { ctx.strokeStyle = 'rgba(219,162,58,' + (0.35 + 0.6 * pulse) + ')'; ctx.lineWidth = 4; ctx.setLineDash([9, 6]); rr(R.x - 3, R.y - 3, R.w + 6, R.h + 6, 6); ctx.stroke(); ctx.setLineDash([]); }
        }
        if (T.cp) { const R = LAY.slots[T.cp]; ctx.fillStyle = AMBER; rr(R.x + 24, R.y - 9, 40, 18, 3); ctx.fill(); ctx.fillStyle = INK; ctx.font = '700 12px ' + FB; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('멈춤', R.x + 44, R.y + 0.5); }
        // 들머리 · 출구 표시
        const R0 = LAY.slots[from], RN = LAY.slots[n - 1], g0 = geo(R0), gN = geo(RN);
        for (let w = 0; w < T.goal.length; w++) for (let l = 0; l < 2; l++) {
          if (T.goal[w] >= 0 && T.goal[w] !== l) continue;
          const any = T.goal[w] < 0, gy = gN.fy[l] - gN.LH * 0.42 + (T.goal.length > 1 ? (w ? 7 : -7) : 0), gx = RN.x + RN.w + 1;
          ctx.globalAlpha = any ? 0.6 : 1;
          ctx.fillStyle = w ? GREY : AMBER; ctx.strokeStyle = INK; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(gx - 3, gy - 6.5); ctx.lineTo(gx + 6.5, gy); ctx.lineTo(gx - 3, gy + 6.5); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.globalAlpha = 1;
        }
        // 인물
        if (PB) { for (let w = 0; w < PB.pos.length; w++) drawActor(w, PB.pos[w], PB.inv[w]); drawFx(PB); }
        else if (hold) { for (let w = 0; w < hold.pos.length; w++) drawActor(w, hold.pos[w], hold.inv[w]); }
        else if (!S.won || true) {
          const same = S.ac.length > 1 && S.ac[0].l === S.ac[1].l;
          for (let w = S.ac.length - 1; w >= 0; w--) {
            const a = S.ac[w];
            if (S.won) drawActor(w, { slot: n - 1, x: 3.78 - (same && w ? 0.5 : 0), ly: a.l }, { k: 0, b: 0 });
            else drawActor(w, { slot: from, x: 0.34 + (same && !w ? 0.5 : 0), ly: a.l }, { k: a.k, b: a.b });
          }
        }
        // 막힌 자리
        if (hold) {
          const f = hold.fail, R = LAY.slots[f.s], g = geo(R), fx = R.x + g.u * U.clamp(f.x, 0.5, 3.5), fyv = g.fy[f.l] - g.PH * 0.5;
          const k = ease((now - hold.t0) / 260);
          ctx.strokeStyle = RED; ctx.lineWidth = 4; rr(R.x - 3, R.y - 3, R.w + 6, R.h + 6, 6); ctx.stroke();
          ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(fx, fyv, g.PH * (1.4 - 0.65 * k), 0, 7); ctx.stroke();
          ctx.lineWidth = 3.5; ctx.lineCap = 'round'; const q = g.PH * 0.2; ctx.beginPath(); ctx.moveTo(fx - q, fyv - q); ctx.lineTo(fx + q, fyv + q); ctx.moveTo(fx + q, fyv - q); ctx.lineTo(fx - q, fyv + q); ctx.stroke();
        }
        // 끄는 칸
        if (drag) {
          const R = LAY.slots[drag.i], x = drag.x - drag.ox, y = drag.y - drag.oy;
          if (overSlot >= 0) { const Ro = LAY.slots[overSlot]; ctx.strokeStyle = AMBER; ctx.lineWidth = 4; rr(Ro.x - 3, Ro.y - 3, Ro.w + 6, Ro.h + 6, 6); ctx.stroke(); }
          ctx.save(); ctx.fillStyle = 'rgba(0,0,0,.4)'; rr(x + 3, y + 8, R.w, R.h, 5); ctx.fill();
          ctx.translate(x + R.w / 2, y + R.h / 2); ctx.scale(1.04, 1.04); ctx.translate(-R.w / 2, -R.h / 2);
          drawPanel({ x: 0, y: 0, w: R.w, h: R.h }, dragPi, S.fl[dragPi], V, overSlot >= 0 ? overSlot : drag.i, null);
          ctx.restore();
        }
        if (flash > 0) { ctx.fillStyle = 'rgba(184,65,44,' + (0.22 * flash * FXK()) + ')'; ctx.fillRect(0, 0, W, cvs.h); }
        if (winT > 0) { const k = ease(winT); ctx.strokeStyle = 'rgba(219,162,58,' + (1 - k) + ')'; ctx.lineWidth = 5; rr(pg.x - 6 * k, pg.y - 6 * k, pg.w + 12 * k, pg.h + 12 * k, 6); ctx.stroke(); }
      }
      function drawFx(pb) { // 던진 병 · 주운 물건
        const e = pb.cur; if (!e) return;
        const R = LAY.slots[e.s], g = geo(R), u = pb.u;
        if (e.k === 'bt') { const x0 = R.x + g.u * (e.x - 0.75), x1 = R.x + g.u * Math.min(3.85, e.x + 0.7), fyv = g.fy[e.l], t = Math.min(1, u / 0.6);
          if (t < 1) { const bx = x0 + (x1 - x0) * t, by = fyv - g.PH * 0.7 - Math.sin(t * Math.PI) * g.LH * 0.35 + t * g.PH * 0.6; ctx.save(); ctx.translate(bx, by); ctx.rotate(t * 7); bottleIcon(0, 5 * g.s, g.s * 0.8); ctx.restore(); }
          else { const k = (u - 0.6) / 0.4; ctx.strokeStyle = 'rgba(219,162,58,' + (1 - k) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x1, fyv - 3, 4 + 10 * k, Math.PI, 0); ctx.stroke(); } }
        else if (e.k === 'pk') { const fx = R.x + g.u * e.x, fyv = g.fy[e.l] - g.LH * 0.5 - u * g.LH * 0.3; ctx.globalAlpha = 1 - u; if (e.it === 'k') keyIcon(fx, fyv, g.s); else bottleIcon(fx, fyv + 6 * g.s, g.s); ctx.globalAlpha = 1; }
      }

      /* ---------- 재생 ---------- */
      const DUR = (e) => (e.k === 'mv' ? 250 * (e.x1 - e.x0) : e.k === 'in' ? 110 : e.k === 'st' ? 520 : e.k === 'ld' ? 470 : e.k === 'el' ? 600 : e.k === 'ko' ? 400 : e.k === 'bt' ? 620 : e.k === 'pk' ? 190 : e.k === 'dr' ? 380 : e.k === 'sw' ? 300 : 0);
      function mkPB(pre, ev) {
        const from = pre.ph ? T.cp : 0;
        return { pre, vw: cloneW(pre), ev, i: 0, t: 0, u: 0, cur: null, ov: { turn: {}, ko: {}, door: {} },
          pos: pre.ac.map((a, w) => ({ slot: from, x: 0.34 + (pre.ac.length > 1 && pre.ac[0].l === pre.ac[1].l && !w ? 0.5 : 0), ly: a.l, ph: 0 })), inv: pre.ac.map((a) => ({ k: a.k, b: a.b })) };
      }
      function part(pb, e, u) { // 사건 e가 u(0~1)만큼 진행된 모습
        const p = pb.pos[e.w], pi = pb.pre.ar[e.s], kk = pi + ':' + e.f;
        if (e.k === 'in') { p.slot = e.s; p.x = 0; p.ly = e.l; p.a = u; }
        else if (e.k === 'mv') { p.a = 1; p.x = e.x0 + (e.x1 - e.x0) * u; p.ph = (e.x0 + (e.x1 - e.x0) * u) * 7.5; }
        else if (e.k === 'st') { p.x = e.x - OFF.st + 2 * OFF.st * u; p.ly = e.l + (e.l1 - e.l) * u; p.ph = u * 9; }
        else if (e.k === 'ld') { p.ly = e.l + (e.l1 - e.l) * ease(u); p.ph = u * 12; }
        else if (e.k === 'el') { p.a = u < 0.25 ? 1 - u * 3 : u > 0.75 ? 0.25 + (u - 0.75) * 3 : 0.25; p.ly = e.l + (e.l1 - e.l) * ease((u - 0.2) / 0.6); }
        else if (e.k === 'ko') { pb.ov.ko[kk] = ease(u); }
        else if (e.k === 'bt') { if (u > 0.62) pb.ov.turn[kk] = 1; }
        else if (e.k === 'dr') { pb.ov.door[kk] = ease(u); }
      }
      function finish(pb, e, quiet) { // 사건의 결과를 화면 세계에 반영
        const pi = pb.pre.ar[e.s], bit = e.f >= 0 ? 1 << e.f : 0, kk = pi + ':' + e.f;
        part(pb, e, 1);
        if (e.k === 'ko') { pb.vw.dyn[pi] |= bit; delete pb.ov.ko[kk]; delete pb.ov.turn[kk]; if (!quiet) { api.sfx('thud'); api.buzz(15); } }
        else if (e.k === 'bt') { pb.inv[e.w].b--; if (!quiet) api.sfx('pop'); }
        else if (e.k === 'in') { if (!quiet) api.sfx('tick', { vol: 0.35 }); }
        else if (e.k === 'pk') { pb.vw.dyn[pi] |= bit; if (e.it === 'k') pb.inv[e.w].k++; else pb.inv[e.w].b++; if (!quiet) api.sfx('chip'); }
        else if (e.k === 'dr') { pb.vw.dyn[pi] |= bit; delete pb.ov.door[kk]; pb.inv[e.w].k--; if (!quiet) api.sfx('click'); }
        else if (e.k === 'sw') { pb.vw.dyn[pi] ^= bit; pb.vw.pw = e.pw; if (!quiet) api.sfx('tick'); }
        else if (e.k === 'st' || e.k === 'ld' || e.k === 'el') { pb.pos[e.w].ly = e.l1; pb.pos[e.w].a = 1; }
      }
      function startPB(last) {
        const ev = []; play(T, last.pre, ev);
        PB = mkPB(last.pre, ev); PB.ok = last.ok; PB.done = last.done;
        hold = null; sel = -1; drag = null; press = null; msg = null;
        api.setBusy(true); refreshBar();
      }
      function stepPB(dt) {
        const pb = PB; pb.t += dt * spd * SP();
        for (;;) {
          const e = pb.ev[pb.i];
          if (!e) return endPB();
          if (e.k === 'fail') return endPB(e);
          const d = DUR(e);
          if (pb.t >= d) { pb.t -= d; finish(pb, e); pb.i++; continue; }
          pb.cur = e; pb.u = d ? pb.t / d : 1; part(pb, e, pb.u); break;
        }
      }
      function endPB(fail) {
        const pb = PB; PB = null;
        if (fail) {
          hold = { pre: pb.pre, vw: pb.vw, ov: pb.ov, pos: pb.pos, inv: pb.inv, ev: pb.ev, fail, t0: now, busy: now + 650 / SP(), seen: (fail.why === 'seen' || fail.why === 'cam') ? pb.pre.ar[fail.s] + ':' + fail.f : null };
          flash = 1; api.sfx('warn'); api.buzz(40);
        } else if (pb.done) {
          winT = 0.001; api.sfx('win'); api.buzz(50);
          if (!isAI && api.canAct(0)) {
            const o = store(); o.done = o.done || {}; o.best = o.best || {};
            o.done[S.st] = 1; if (o.best[S.st] == null || S.mv < o.best[S.st]) o.best[S.st] = S.mv;
            o.op = Math.max(o.op | 0, S.op); o.cur = Math.min(STAGES.length - 1, S.st + 1); save(o);
            api.best('done', Object.keys(o.done).length, { label: '통과한 단계', unit: '단계' });
          }
          hold = null; setTimeout(() => { api.setBusy(false); if (S && S.won && !isAI) winPanel(); }, 520 / SP());
        } else { api.sfx('tick'); api.setBusy(false); }
        refreshBar();
      }
      function clearHold() { if (hold) { if (hold.busy) api.setBusy(false); hold = null; setCap(); refreshBar(); } }
      function rewind() {
        if (!hold || PB) return;
        const h = hold, idx = Math.max(0, h.ev.findIndex((e) => e.s === h.fail.s));
        const pb = mkPB(h.pre, h.ev);
        for (let i = 0; i < idx; i++) finish(pb, h.ev[i], true);
        pb.i = idx; pb.ok = 0; pb.done = 0;
        if (h.busy) h.busy = 0; else api.setBusy(true);
        hold = null; PB = pb; refreshBar();
      }

      /* ---------- 입력 ---------- */
      const pinned = (i) => T.P[S.ar[i]].pin;
      const canEdit = () => S && !PB && !S.won && !ov && api.canAct(0);
      function tapSlot(i, corner) {
        const P = T.P[S.ar[i]];
        if (corner && P.fl) { sel = -1; act({ t: 'flip', a: i }); return; }
        if (P.pin) { nudge = { i, t: 0 }; api.sfx('tick'); say('못 박힌 칸은 옮길 수 없다.'); return; }
        if (sel < 0) { sel = i; api.sfx('click'); }
        else if (sel === i) { sel = -1; api.sfx('tick'); }
        else { const a = sel; sel = -1; act({ t: 'swap', a, b: i }); }
        dirty = true;
      }
      const onDown = (e) => {
        if (!canEdit()) return;
        const p = cvs.local(e), i = slotAt(p);
        clearHold(); kcur = -1;
        if (i < 0) { sel = -1; dirty = true; return; }
        press = { i, x: p.x, y: p.y, id: e.pointerId };
        try { cv.setPointerCapture(e.pointerId); } catch (er) {}
      };
      const onMove = (e) => {
        if (!press && !drag) { if (e.pointerType === 'mouse') { const i = canEdit() ? slotAt(cvs.local(e)) : -1; cv.style.cursor = i >= 0 && !pinned(i) ? 'grab' : ''; } return; }
        const p = cvs.local(e);
        if (press && !drag && Math.hypot(p.x - press.x, p.y - press.y) > 8) {
          if (pinned(press.i)) { nudge = { i: press.i, t: 0 }; say('못 박힌 칸은 옮길 수 없다.'); press = null; return; }
          const R = LAY.slots[press.i];
          drag = { i: press.i, x: p.x, y: p.y, ox: press.x - R.x, oy: press.y - R.y, over: -1 }; sel = -1; press = null; api.sfx('click');
        }
        if (drag) { drag.x = p.x; drag.y = p.y; const R = LAY.slots[drag.i]; const j = slotAt({ x: p.x - drag.ox + R.w / 2, y: p.y - drag.oy + R.h / 2 }); drag.over = j >= 0 && j !== drag.i && !pinned(j) ? j : -1; dirty = true; }
      };
      const onUp = (e) => {
        if (drag) { const d = drag; drag = null; dirty = true; if (d.over >= 0) { noSlide = d; act({ t: 'swap', a: d.i, b: d.over }); } else api.sfx('tick'); }
        else if (press) { const p = cvs.local(e), R = LAY.slots[press.i], i = press.i; press = null; tapSlot(i, p.x > R.x + R.w - 44 && p.y < R.y + 44); }
      };
      const onCancel = () => { drag = null; press = null; dirty = true; };
      let noSlide = null;
      cv.addEventListener('pointerdown', onDown); cv.addEventListener('pointermove', onMove); cv.addEventListener('pointerup', onUp); cv.addEventListener('pointercancel', onCancel);
      const onCx = (e) => { if (!ov && (sel >= 0 || drag)) { sel = -1; drag = null; press = null; dirty = true; e.preventDefault(); } };
      window.addEventListener('lounge-cancel', onCx);
      const offIn = api.input ? api.input.on((type, id) => {
        if (type !== 'down' || !S || ov) return;
        if (id === 'speed') { bSpd.b.click(); return; }
        if (!canEdit()) return;
        if (id === 'play') { sel = -1; act({ t: 'play' }); }
        else if (id === 'hint') act({ t: 'hint' });
        else if (id === 'reset') bReset.b.click();
        else if (id === 'left' || id === 'right' || id === 'up' || id === 'down') {
          clearHold();
          if (kcur < 0) kcur = sel >= 0 ? sel : 0;
          else { const c = LAY.cols, d = id === 'left' ? -1 : id === 'right' ? 1 : id === 'up' ? -c : c; if (kcur + d >= 0 && kcur + d < T.n) kcur += d; }
          dirty = true;
        } else if (id === 'ok') { if (kcur < 0) kcur = 0; else tapSlot(kcur, false); dirty = true; }
        else if (id === 'flip') { const i = kcur >= 0 ? kcur : sel; if (i >= 0 && T.P[S.ar[i]].fl) { sel = -1; act({ t: 'flip', a: i }); } }
      }) : null;

      function frame(dt) {
        now += dt;
        let live = dirty; dirty = false;
        if (PB) { stepPB(dt); live = true; }
        if (hold) { if (hold.busy && now >= hold.busy) { hold.busy = 0; api.setBusy(false); } if (now - hold.t0 < 400) live = true; }
        for (const k in slide) { slide[k].t += dt / 190; if (slide[k].t >= 1) delete slide[k]; live = true; }
        for (const k in flipA) { flipA[k] += dt / 240; if (flipA[k] >= 1) delete flipA[k]; live = true; }
        if (nudge) { nudge.t += dt / 320; if (nudge.t >= 1) nudge = null; live = true; }
        if (flash > 0) { flash = Math.max(0, flash - dt / 380); live = true; }
        if (winT > 0) { winT += dt / 700; if (winT >= 1) winT = 0; live = true; }
        if (S && S.hint && !PB) live = true;
        if (live) draw();
      }
      stop = U.loop((dt) => frame(Math.min(dt * 1000, 50)));

      return {
        update(s, prev) {
          const fresh = !S, stChanged = !S || S.st !== s.st || !T;
          S = s; T = prep(s.st);
          if (stChanged || !LAY) layout();
          const L0 = s.last || {}, P = prev && prev.last;
          if (prev && prev !== s && P && L0.id !== P.id) {
            if (L0.t === 'swap') {
              const pa = s.ar[L0.a], pb = s.ar[L0.b], Ra = LAY.slots[L0.a], Rb = LAY.slots[L0.b];
              if (noSlide && noSlide.i === L0.a && noSlide.over === L0.b) { slide[pb] = { x: noSlide.x - noSlide.ox, y: noSlide.y - noSlide.oy, t: 0 }; slide[pa] = { x: (Ra.x + Rb.x) / 2, y: (Ra.y + Rb.y) / 2, t: 0 }; }
              else { slide[pa] = { x: Rb.x, y: Rb.y, t: 0 }; slide[pb] = { x: Ra.x, y: Ra.y, t: 0 }; }
              noSlide = null; api.sfx('card'); api.buzz(10);
            } else if (L0.t === 'flip') { flipA[s.ar[L0.a]] = 0; api.sfx('whoosh'); api.buzz(10); }
            else if (L0.t === 'play') startPB(L0);
            else if (L0.t === 'hint') api.sfx('tick');
            else if (L0.t === 'fin') { closeOv(); if (!isAI) finPanel(); }
            else if (L0.t === 'new' || L0.t === 'reset' || L0.t === 'skip' || L0.t === 'rw') {
              sel = -1; kcur = -1; drag = null; press = null; hold = null; PB = null; slide = {}; flipA = {}; msg = null; api.setBusy(false); closeOv();
              if (L0.t !== 'reset' && L0.t !== 'rw' && !isAI) { const o = store(); o.cur = s.st; o.op = Math.max(o.op | 0, s.op); save(o); }
              if (L0.t === 'rw') api.sfx('whoosh');
            }
          }
          if (fresh && !isAI) { const o = store(); o.cur = s.st; save(o); if (s.won) winPanel(); }
          refreshBar();
        },
        destroy() {
          window.removeEventListener('lounge-cancel', onCx); if (stop) stop();
          cv.removeEventListener('pointerdown', onDown); cv.removeEventListener('pointermove', onMove); cv.removeEventListener('pointerup', onUp); cv.removeEventListener('pointercancel', onCancel);
          if (offIn) offIn(); closeOv(); bar.remove(); cap.remove(); api.setBusy(false); cvs.destroy();
        },
      };
    },
    _t: { parse, eff, play, solve, prepData, prep, world0, doMove, moves, wkey, nMoves, STAGES, CHAPTERS, runSeg, cloneW },
  };
  L.register(def);
})();
