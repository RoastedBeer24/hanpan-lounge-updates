/* 점 잇기 상자 — dots and boxes on a chalkboard with brass studs.
   Turn: draw one line between two neighbouring dots. Closing a box (its 4th side) claims it and you must draw again.
   Most boxes wins. Boards: 네모 / 십자 / 구멍 (holes = no box there; lines around a hole are still playable). */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------------- boards ---------------- */
  const SHAPES = [{ id: 'rect', name: '네모' }, { id: 'plus', name: '십자' }, { id: 'holes', name: '구멍' }, { id: 'hex', name: '육각' }];
  const SHAPE_NAME = { rect: '네모', plus: '십자', holes: '구멍', hex: '육각' };
  function boardSpec(shape, size) {
    const si = size === 's' ? 0 : size === 'l' ? 2 : 1;
    let R, C, hole = () => false;
    if (shape === 'hex') { R = [3, 5, 7][si]; C = [3, 4, 4][si]; }
    else if (shape === 'plus') {
      const N = [4, 6, 7][si], k = [1, 2, 2][si];
      R = C = N; hole = (r, c) => (r < k || r >= N - k) && (c < k || c >= N - k);
    } else if (shape === 'holes') {
      const N = [4, 5, 7][si];
      const H = [['1,1', '1,2', '2,1', '2,2'], ['1,1', '1,3', '3,1', '3,3'], ['1,1', '1,5', '5,1', '5,5', '3,3']][si];
      R = C = N; hole = (r, c) => H.indexOf(r + ',' + c) >= 0;
    } else { R = C = [3, 5, 7][si]; }
    let bx = '';
    for (let r = 0; r < R; r++) for (let c = 0; c < C; c++) bx += hole(r, c) ? '#' : '.';
    return { R, C, bx };
  }

  /* geometry (cached per board). K = sides per cell (4 square / 6 hex). Vertices in board units (edge length 1):
     VX/VY; ends[l*2..] = the line's two vertices; bl[b*K+j] = cell's lines; lb[l*2..] = the line's two cells (-1 = none) */
  const geoCache = {};
  function geo(s) {
    const hex = s.sh === 'hex';
    const mask = s.bx.replace(/[^#]/g, '.');
    const key = (hex ? 'h' : 'q') + s.R + 'x' + s.C + ':' + mask;
    if (geoCache[key]) return geoCache[key];
    return (geoCache[key] = finishGeo(hex ? hexGeo(s.R, s.C) : sqGeo(s.R, s.C, mask)));
  }
  function sqGeo(R, C, mask) {
    const NB = R * C, HN = (R + 1) * C, NL = HN + R * (C + 1), NV = (R + 1) * (C + 1);
    const has = new Uint8Array(NB);
    for (let b = 0; b < NB; b++) has[b] = mask[b] === '#' ? 0 : 1;
    const box = (r, c) => (r < 0 || c < 0 || r >= R || c >= C || !has[r * C + c] ? -1 : r * C + c);
    const lb = new Int16Array(NL * 2), ex = new Uint8Array(NL), ends = new Int16Array(NL * 2);
    for (let l = 0; l < NL; l++) {
      let a, b, r1, c1, r2, c2;
      if (l < HN) { const r = (l / C) | 0, c = l % C; a = box(r - 1, c); b = box(r, c); r1 = r; c1 = c; r2 = r; c2 = c + 1; }
      else { const k = l - HN, r = (k / (C + 1)) | 0, c = k % (C + 1); a = box(r, c - 1); b = box(r, c); r1 = r; c1 = c; r2 = r + 1; c2 = c; }
      lb[l * 2] = a; lb[l * 2 + 1] = b; ex[l] = a >= 0 || b >= 0 ? 1 : 0;
      ends[l * 2] = r1 * (C + 1) + c1; ends[l * 2 + 1] = r2 * (C + 1) + c2;
    }
    const bl = new Int16Array(NB * 4), CX = new Float32Array(NB), CY = new Float32Array(NB);
    for (let b = 0; b < NB; b++) {
      const r = (b / C) | 0, c = b % C;
      bl[b * 4] = r * C + c; bl[b * 4 + 1] = (r + 1) * C + c; bl[b * 4 + 2] = HN + r * (C + 1) + c; bl[b * 4 + 3] = HN + r * (C + 1) + c + 1;
      CX[b] = c + 0.5; CY[b] = r + 0.5;
    }
    const VX = new Float32Array(NV), VY = new Float32Array(NV);
    for (let v = 0; v < NV; v++) { VX[v] = v % (C + 1); VY[v] = (v / (C + 1)) | 0; }
    return { K: 4, R, C, NB, NL, NV, has, lb, ex, ends, bl, CX, CY, VX, VY, W: C, H: R };
  }
  /* honeycomb: R rows × C cells, pointy-top hexes, odd rows shifted right by half a cell */
  function hexGeo(R, C) {
    const NB = R * C, S3 = Math.sqrt(3), vmap = new Map(), VXa = [], VYa = [], emap = new Map(), lbA = [], enA = [];
    const bl = new Int16Array(NB * 6), CX = new Float32Array(NB), CY = new Float32Array(NB);
    for (let b = 0; b < NB; b++) {
      const r = (b / C) | 0, c = b % C, cx = S3 * (c + 0.5 * (r & 1)) + S3 / 2, cy = 1.5 * r + 1;
      CX[b] = cx; CY[b] = cy;
      const vs = [];
      for (let i = 0; i < 6; i++) {
        const a = ((-90 + 60 * i) * Math.PI) / 180, x = cx + Math.cos(a), y = cy + Math.sin(a);
        const k = Math.round(x * 100) + ',' + Math.round(y * 100);
        let id = vmap.get(k); if (id === undefined) { id = VXa.length; vmap.set(k, id); VXa.push(x); VYa.push(y); }
        vs.push(id);
      }
      for (let i = 0; i < 6; i++) {
        const v1 = vs[i], v2 = vs[(i + 1) % 6], ek = Math.min(v1, v2) + '-' + Math.max(v1, v2);
        let e = emap.get(ek);
        if (e === undefined) { e = enA.length / 2; emap.set(ek, e); enA.push(v1, v2); lbA.push(b, -1); } else lbA[e * 2 + 1] = b;
        bl[b * 6 + i] = e;
      }
    }
    const NL = enA.length / 2, NV = VXa.length;
    const has = new Uint8Array(NB).fill(1), ex = new Uint8Array(NL).fill(1);
    let W = 0, H = 0; for (let v = 0; v < NV; v++) { W = Math.max(W, VXa[v]); H = Math.max(H, VYa[v]); }
    return { K: 6, R, C, NB, NL, NV, has, lb: Int16Array.from(lbA), ex, ends: Int16Array.from(enA), bl, CX, CY, VX: Float32Array.from(VXa), VY: Float32Array.from(VYa), W, H };
  }
  function finishGeo(G) {
    const dotOn = new Uint8Array(G.NV);
    for (let l = 0; l < G.NL; l++) if (G.ex[l]) { dotOn[G.ends[l * 2]] = 1; dotOn[G.ends[l * 2 + 1]] = 1; }
    // zobrist keys for the AI's search memo (deterministic)
    const Z1 = new Int32Array(G.NL), Z2 = new Int32Array(G.NL);
    let t = 12345 + G.NL * 7 + G.K;
    const rnd = () => { t = (Math.imul(t, 1103515245) + 12345) | 0; return t; };
    for (let l = 0; l < G.NL; l++) { Z1[l] = rnd() ^ (rnd() << 7); Z2[l] = rnd() ^ (rnd() >>> 3); }
    let nBoxes = 0; for (let b = 0; b < G.NB; b++) nBoxes += G.has[b];
    return Object.assign(G, { dotOn, Z1, Z2, nBoxes });
  }

  /* ---------------- rules ---------------- */
  function init(players, opts) {
    opts = opts || {};
    let shape = opts.shape || 'rand';
    if (shape === 'rand') shape = SHAPES[Math.floor(Math.random() * SHAPES.length)].id;
    const size = opts.size || 'm';
    const sp = boardSpec(shape, size);
    const s = { n: players.length, R: sp.R, C: sp.C, sh: shape, sz: size, bx: sp.bx, ln: '', sc: players.map(() => 0), turn: 0, tl: [], tp: -1, k: 0, last: null, seq: 0, g: Math.floor(Math.random() * 1e6) };
    const g = geo(s);
    let ln = ''; for (let l = 0; l < g.NL; l++) ln += g.ex[l] ? '0' : '-';
    s.ln = ln;
    return s;
  }
  function done(s) { return s.bx.indexOf('.') < 0; }
  function actor(s) { return done(s) ? null : s.turn; }
  function sidesOf(s, g, b) { let k = 0; for (let j = 0; j < g.K; j++) if (s.ln[g.bl[b * g.K + j]] === '1') k++; return k; }
  function apply(s, seat, a) {
    if (done(s)) throw new Error('game over');
    if (seat !== s.turn) throw new Error('not your turn');
    const g = geo(s);
    const l = a && a.l;
    if (!Number.isInteger(l) || l < 0 || l >= g.NL || s.ln[l] !== '0') throw new Error('bad line');
    s.ln = s.ln.slice(0, l) + '1' + s.ln.slice(l + 1);
    if (s.tp !== seat) { s.tl = []; s.tp = seat; s.k = 0; }
    s.tl.push(l);
    const got = [];
    for (let j = 0; j < 2; j++) {
      const b = g.lb[l * 2 + j];
      if (b >= 0 && s.bx[b] === '.' && sidesOf(s, g, b) === g.K) got.push(b);
    }
    let bx = s.bx;
    for (const b of got) bx = bx.slice(0, b) + seat + bx.slice(b + 1);
    s.bx = bx;
    s.sc[seat] += got.length;
    s.k = (s.k || 0) + got.length;
    if (!s.ks) s.ks = s.sc.map(() => 0); // per-seat result stat: most boxes in one turn
    s.ks[seat] = Math.max(s.ks[seat], s.k);
    s.seq++;
    s.last = { id: s.seq, s: seat, l, b: got, k: s.k };
    if (!got.length) s.turn = (s.turn + 1) % s.n;
    return s;
  }
  function result(s) {
    if (!done(s)) return null;
    const best = Math.max.apply(null, s.sc);
    const winners = []; s.sc.forEach((v, i) => { if (v === best) winners.push(i); });
    const total = s.sc.reduce((a, b) => a + b, 0);
    const stats = [{ label: '상자', values: s.sc.map(String) }, { label: '한 차례 최다', values: s.sc.map((_, i) => String(s.ks ? s.ks[i] : 0)) },
      { label: '차지 비율', values: s.sc.map((v) => (total ? Math.round((v / total) * 100) : 0) + '%') }];
    return { winners, stats, text: (winners.length > 1 ? '공동 1등 · ' : '') + '상자 ' + best + '개 · 점수 ' + s.sc.join(' : ') + ' (전체 ' + total + ')' };
  }

  /* ---------------- AI ---------------- */
  // working board: D[l] 1 = drawn or not a line; S[b] = sides drawn (existing, unowned boxes only matter)
  function work(s, g) {
    const D = new Uint8Array(g.NL), S = new Int8Array(g.NB);
    for (let l = 0; l < g.NL; l++) D[l] = s.ln[l] === '0' ? 0 : 1;
    for (let b = 0; b < g.NB; b++) if (g.has[b]) { let k = 0; for (let j = 0; j < g.K; j++) k += D[g.bl[b * g.K + j]]; S[b] = k; } else S[b] = 9;
    return { D, S };
  }
  const across = (g, l, b) => (g.lb[l * 2] === b ? g.lb[l * 2 + 1] : g.lb[l * 2]);
  function drawL(g, W, l) { W.D[l] = 1; for (let j = 0; j < 2; j++) { const b = g.lb[l * 2 + j]; if (b >= 0) W.S[b]++; } }
  function undrawL(g, W, l) { W.D[l] = 0; for (let j = 0; j < 2; j++) { const b = g.lb[l * 2 + j]; if (b >= 0) W.S[b]--; } }
  function maxSides(g, W, l) { let m = -1; for (let j = 0; j < 2; j++) { const b = g.lb[l * 2 + j]; if (b >= 0 && W.S[b] > m) m = W.S[b]; } return m; }
  function freeLines(g, W) { const o = []; for (let l = 0; l < g.NL; l++) if (!W.D[l]) o.push(l); return o; }
  function capLines(g, W) { const o = []; for (let l = 0; l < g.NL; l++) if (!W.D[l] && maxSides(g, W, l) === g.K - 1) o.push(l); return o; }
  function safeLines(g, W) { const o = []; for (let l = 0; l < g.NL; l++) if (!W.D[l] && maxSides(g, W, l) <= g.K - 3) o.push(l); return o; }
  function openLine(g, W, b) { for (let j = 0; j < g.K; j++) { const l = g.bl[b * g.K + j]; if (!W.D[l]) return l; } return -1; }
  function pick(a) { return a[Math.floor(Math.random() * a.length)]; }

  /* how many boxes the next player grabs if they simply take everything after line l */
  function giveaway(g, W, l) {
    const D = W.D.slice(), S = W.S.slice(), V = { D, S };
    drawL(g, V, l);
    let n = 0; const st = [];
    for (let j = 0; j < 2; j++) { const b = g.lb[l * 2 + j]; if (b >= 0 && S[b] === g.K - 1) st.push(b); }
    while (st.length) {
      const b = st.pop(); if (S[b] !== 3) continue;
      const m = openLine(g, V, b); if (m < 0) continue;
      drawL(g, V, m);
      for (let j = 0; j < 2; j++) { const x = g.lb[m * 2 + j]; if (x < 0) continue; if (S[x] === g.K) n++; else if (S[x] === g.K - 1) st.push(x); }
    }
    return n;
  }

  /* split the board into chains and loops (boxes with 2–3 sides drawn); junction boxes (≤1 side) act as ground */
  function decompose(g, W) {
    const seen = new Uint8Array(g.NB), comps = [];
    const chainy = (b) => b >= 0 && (W.S[b] === g.K - 2 || W.S[b] === g.K - 1);
    for (let b0 = 0; b0 < g.NB; b0++) {
      if (!g.has[b0] || seen[b0] || !chainy(b0)) continue;
      const boxes = [b0]; seen[b0] = 1; let loop = true;
      for (let i = 0; i < boxes.length; i++) {
        const b = boxes[i];
        if (W.S[b] === g.K - 1) loop = false;
        for (let j = 0; j < g.K; j++) {
          const l = g.bl[b * g.K + j]; if (W.D[l]) continue;
          const o = across(g, l, b);
          if (chainy(o)) { if (!seen[o]) { seen[o] = 1; boxes.push(o); } } else loop = false;
        }
      }
      comps.push({ n: boxes.length, loop: loop && boxes.length >= 4, boxes });
    }
    return comps;
  }
  /* value for the player who must open a component (simple loony-endgame model), memoised */
  const FM = new Map();
  function fval(ch, lp) {
    if (!ch.length && !lp.length) return 0;
    const key = ch.join(',') + '|' + lp.join(',');
    const m = FM.get(key); if (m !== undefined) return m;
    let best = -Infinity;
    for (let i = 0; i < ch.length; i++) {
      if (i && ch[i] === ch[i - 1]) continue;
      const n = ch[i], f = fval(ch.slice(0, i).concat(ch.slice(i + 1)), lp);
      const v = n <= 2 ? -n - f : Math.min(-n - f, -n + 4 + f);
      if (v > best) best = v;
    }
    for (let i = 0; i < lp.length; i++) {
      if (i && lp[i] === lp[i - 1]) continue;
      const n = lp[i], f = fval(ch, lp.slice(0, i).concat(lp.slice(i + 1)));
      const v = Math.min(-n - f, -n + 8 + f);
      if (v > best) best = v;
    }
    if (FM.size > 60000) FM.clear();
    FM.set(key, best);
    return best;
  }
  function fOf(comps) {
    const ch = [], lp = [];
    for (const c of comps) (c.loop ? lp : ch).push(c.n);
    ch.sort((a, b) => a - b); lp.sort((a, b) => a - b);
    return fval(ch, lp);
  }

  /* lv3: when a capture is the last 2 boxes of a chain (or last 4 of a loop) — maybe leave them (double-dealing) */
  function ddPattern(g, W, l) {
    let A = -1;
    for (let j = 0; j < 2; j++) { const b = g.lb[l * 2 + j]; if (b >= 0 && W.S[b] === g.K - 1) { if (A >= 0) return null; A = b; } }
    if (A < 0) return null;
    const B = across(g, l, A);
    if (B < 0 || W.S[B] !== g.K - 2) return null;
    let L2 = -1; for (let j = 0; j < g.K; j++) { const m = g.bl[B * g.K + j]; if (!W.D[m] && m !== l) L2 = m; }
    if (L2 < 0) return null;
    const X = across(g, L2, B);
    if (X < 0 || W.S[X] <= g.K - 3) return { dd: L2, boxes: [A, B], cost: 2 };
    if (W.S[X] !== g.K - 2) return null;
    let L3 = -1; for (let j = 0; j < g.K; j++) { const m = g.bl[X * g.K + j]; if (!W.D[m] && m !== L2) L3 = m; }
    if (L3 < 0) return null;
    const Dd = across(g, L3, X);
    if (Dd >= 0 && W.S[Dd] === g.K - 1 && Dd !== A) return { dd: L2, boxes: [A, B, X, Dd], cost: 4 };
    return null;
  }
  function closeBoxes(g, W, boxes) { const V = { D: W.D.slice(), S: W.S.slice() }; for (const b of boxes) for (let j = 0; j < g.K; j++) { const m = g.bl[b * g.K + j]; if (!V.D[m]) drawL(g, V, m); } return V; }

  /* lv3 safe-move phase: search who will be forced to open the first chain (memo + node/time budget) */
  function safeSearch(g, W, list) {
    const memo = new Map(); let nodes = 0, abort = false, h1 = 0, h2 = 0;
    const t0 = Date.now();
    function V() {
      if (abort) return 0;
      if (++nodes > 60000 || ((nodes & 511) === 0 && Date.now() - t0 > 220)) { abort = true; return 0; }
      const key = h1 + ':' + h2;
      const m = memo.get(key); if (m !== undefined) return m;
      const sl = safeLines(g, W);
      let v;
      if (!sl.length) v = fOf(decompose(g, W));
      else {
        v = -Infinity;
        for (const l of sl) { drawL(g, W, l); h1 ^= g.Z1[l]; h2 ^= g.Z2[l]; const c = -V(); undrawL(g, W, l); h1 ^= g.Z1[l]; h2 ^= g.Z2[l]; if (c > v) v = c; if (abort) break; }
      }
      memo.set(key, v);
      return v;
    }
    const order = U.shuffle(list.slice());
    let best = -Infinity, bestL = -1;
    for (const l of order) {
      drawL(g, W, l); h1 ^= g.Z1[l]; h2 ^= g.Z2[l];
      const v = -V();
      undrawL(g, W, l); h1 ^= g.Z1[l]; h2 ^= g.Z2[l];
      if (abort) return -1;
      if (v > best) { best = v; bestL = l; }
    }
    return bestL;
  }

  /* lv3 forced phase: open the component that costs least (long-chain rule), 2-chains with the middle line */
  function openingLine(g, W, c) {
    const inC = new Set(c.boxes);
    if (c.loop) { const b = c.boxes[0]; for (let j = 0; j < g.K; j++) { const l = g.bl[b * g.K + j]; if (!W.D[l]) return l; } }
    if (c.n === 2) { const b = c.boxes[0]; for (let j = 0; j < g.K; j++) { const l = g.bl[b * g.K + j]; if (!W.D[l] && across(g, l, b) === c.boxes[1]) return l; } }
    let jl = -1;
    for (const b of c.boxes) for (let j = 0; j < g.K; j++) {
      const l = g.bl[b * g.K + j]; if (W.D[l]) continue;
      const o = across(g, l, b);
      if (o < 0) return l; // ground end first
      if (!inC.has(o) && jl < 0) jl = l;
    }
    if (jl >= 0) return jl;
    for (const b of c.boxes) { const l = openLine(g, W, b); if (l >= 0) return l; }
    return -1;
  }

  function minGive(g, W, lines) {
    let best = Infinity, out = [];
    for (const l of lines) { const v = giveaway(g, W, l); if (v < best) { best = v; out = [l]; } else if (v === best) out.push(l); }
    return out;
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    const g = geo(s), W = work(s, g);
    const all = freeLines(g, W);
    if (!all.length) return null;
    const caps = capLines(g, W);
    const safe = safeLines(g, W);
    // 성향: 공격형은 상자를 놓치지 않고, 수비형은 안전한 선을 고집, 도박형은 가끔 위험한 선을 그냥 긋는다
    const sty = (L.aiStyle && L.aiStyle(seat)) || 'bal';
    if (sty === 'gamble' && !caps.length && safe.length && Math.random() < (lv >= 3 ? 0.08 : 0.15)) return { l: pick(all) };
    if (lv <= 1) {
      if (caps.length && Math.random() < (sty === 'agg' ? 0.95 : sty === 'def' ? 0.45 : 0.6)) return { l: pick(caps) };
      if (safe.length && Math.random() < (sty === 'def' ? 0.9 : sty === 'gamble' ? 0.3 : 0.5)) return { l: pick(safe) };
      return { l: pick(all) };
    }
    if (lv === 2) {
      if (caps.length) return { l: pick(caps) };
      if (safe.length) return { l: pick(safe) };
      // forced: give the fewest boxes; a 2-box chain is opened at random (no special trick)
      return { l: pick(minGive(g, W, all)) };
    }
    /* lv 3 */
    if (caps.length) {
      const plain = [], pats = [];
      for (const l of caps) { const p = ddPattern(g, W, l); if (p) pats.push({ l, p }); else plain.push(l); }
      if (plain.length) {
        // prefer captures that close two boxes at once, then any
        const dbl = plain.filter((l) => { let k = 0; for (let j = 0; j < 2; j++) { const b = g.lb[l * 2 + j]; if (b >= 0 && W.S[b] === g.K - 1) k++; } return k === 2; });
        return { l: pick(dbl.length ? dbl : plain) };
      }
      const { l, p } = pats[0];
      const rest = closeBoxes(g, W, p.boxes);
      if (safeLines(g, rest).length) return { l };
      const comps = decompose(g, rest);
      if (!comps.length) return { l };
      const f = fOf(comps);
      return { l: f < -p.cost ? p.dd : l };
    }
    if (safe.length) {
      if (safe.length <= 16) { const l = safeSearch(g, W, safe); if (l >= 0) return { l }; }
      return { l: pick(safe) };
    }
    // forced: choose which chain/loop to hand over
    const comps = decompose(g, W);
    if (comps.length) {
      let best = -Infinity, bestC = null;
      for (let i = 0; i < comps.length; i++) {
        const c = comps[i], rest = comps.slice(0, i).concat(comps.slice(i + 1));
        const f = fOf(rest), n = c.n;
        const v = c.loop ? Math.min(-n - f, -n + 8 + f) : n <= 2 ? -n - f : Math.min(-n - f, -n + 4 + f);
        if (v > best || (v === best && bestC && n < bestC.n)) { best = v; bestC = c; }
      }
      const l = openingLine(g, W, bestC);
      if (l >= 0 && !W.D[l]) return { l };
    }
    return { l: pick(minGive(g, W, all)) };
  }
  function aiDelayFor(s, seat, lv) {
    const g = geo(s);
    let cap = false;
    if (s.last && s.last.s === seat && s.last.b.length) cap = true;
    else for (let b = 0; b < g.NB && !cap; b++) if (g.has[b] && s.bx[b] === '.' && sidesOf(s, g, b) === g.K - 1) cap = true;
    if (cap) return lv <= 1 ? 520 : 380;
    return lv <= 1 ? 950 : lv === 2 ? 760 : 640;
  }

  /* ---------------- view ---------------- */
  /* one short, unique mark per player: first letter, else last letter (AI 1 → 1), else any letter, else seat number */
  function marksFor(players) {
    const nm = players.map((p) => (p.name || '').replace(/\s+/g, '').toUpperCase() || '?');
    const out = new Array(players.length).fill(null), used = new Set();
    const firsts = nm.map((x) => x[0]);
    nm.forEach((x, i) => { if (firsts.filter((f) => f === x[0]).length === 1) { out[i] = x[0]; used.add(x[0]); } });
    const rest = nm.map((x, i) => i).filter((i) => out[i] == null);
    const lasts = rest.map((i) => nm[i].slice(-1));
    rest.forEach((i, k) => { const c = lasts[k]; if (!used.has(c) && lasts.filter((x) => x === c).length === 1) { out[i] = c; used.add(c); } });
    nm.forEach((x, i) => {
      if (out[i] != null) return;
      for (const c of x + '123456789') if (!used.has(c)) { out[i] = c; used.add(c); break; }
    });
    return out;
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, g = null, G = null;
    let sel = -1, hov = -1, downSel = -1, dragging = false, pending = false, pendT = 0;
    const onCancelEv = (e) => { if (sel >= 0) { sel = -1; refresh(); e.preventDefault(); } };
    window.addEventListener('lounge-cancel', onCancelEv);
    let anim = null, fx = [], stopLoop = null, watchdog = 0, shownKey = '', busy = false;
    const cache = document.createElement('canvas'), cctx = cache.getContext('2d');
    const dotC = document.createElement('canvas');
    let cacheKey = '';
    const marks = marksFor(api.players);
    const col = (k) => (api.players[k] && api.players[k].color) || '#ccc';
    const nm = (k) => (api.players[k] && api.players[k].name) || '?';

    /* HUD */
    const top = L.h('div', { class: 'hud top dt-top', style: { gap: '6px', flexWrap: 'nowrap', padding: '8px 8px' } });
    const hud = L.h('div', { class: 'hud bottom', style: { flexWrap: 'nowrap', alignItems: 'stretch', padding: '8px 10px' } });
    const info = L.h('div', { class: 'panel dt-info', style: { flex: '1 1 auto', minWidth: '0', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '2px', minHeight: '52px', padding: '6px 10px' } });
    const evLine = L.h('div', { style: { fontSize: '12px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
    const hint = L.h('div', { style: { fontSize: '13.5px', fontWeight: 700, lineHeight: 1.3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
    info.append(evLine, hint);
    const cancelBtn = L.h('button', { 'data-key': 'Escape', class: 'btn ghost', 'aria-label': '선택 취소', text: '✕', style: { minWidth: '48px', fontSize: '18px', padding: '0 10px' }, onclick() { if (sel >= 0) { sel = -1; api.sfx('click'); refresh(); } } });
    const drawBtn = L.h('button', { 'data-key': 'Enter', class: 'btn primary dt-draw', text: '긋기', style: { minWidth: '72px' }, onclick() { commit(); } });
    hud.append(info, cancelBtn, drawBtn);
    root.append(top, hud);
    // invisible box over the canvas board, so the first-play tutorial can spotlight it
    const spBoard = L.h('div', { class: 'dt-board', 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(spBoard);

    const TOPH = 54, BOTH = 84;
    function layout() {
      if (!g) return;
      const availW = cv.w - 28, availH = cv.h - TOPH - BOTH - 24;
      const gap = Math.max(18, Math.min(availW / (g.W + 0.9), availH / (g.H + 0.9), 76));
      const bw = g.W * gap, bh = g.H * gap;
      G = { gap, ox: (cv.w - bw) / 2, oy: TOPH + 12 + Math.max(0, (availH - bh) / 2) + gap * 0.45, m: gap * 0.42, fr: Math.max(7, gap * 0.2) };
      G.oy = Math.min(G.oy, cv.h - BOTH - 12 - bh - gap * 0.45);
      G.oy = Math.max(G.oy, TOPH + 8 + gap * 0.45);
      const pd = Math.round(gap * 0.3);
      Object.assign(spBoard.style, { left: Math.round(G.ox - pd) + 'px', top: Math.round(G.oy - pd) + 'px', width: Math.round(bw + pd * 2) + 'px', height: Math.round(bh + pd * 2) + 'px' });
      cacheKey = '';
    }
    const dx = (c) => G.ox + c * G.gap, dy = (r) => G.oy + r * G.gap;
    cv.onresize = () => { layout(); draw(); };

    function lcg(seed) { let t = seed | 0; return () => { t = (Math.imul(t, 1664525) + 1013904223) | 0; return ((t >>> 8) & 0xffff) / 65536; }; }
    function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
    function unionPath(c, pad, rad) {
      c.beginPath();
      for (let b = 0; b < g.NB; b++) {
        if (!g.has[b]) continue;
        if (g.K === 6) { hexPath(c, b, G.gap + pad * 1.155, false); continue; }
        const r = (b / g.C) | 0, cc = b % g.C;
        const x = dx(cc) - pad, y = dy(r) - pad, w = G.gap + pad * 2;
        if (c.roundRect) c.roundRect(x, y, w, w, rad); else c.rect(x, y, w, w);
      }
    }
    /* hex cell outline (pointy top) of circumradius rad px around the cell centre */
    function hexPath(c, b, rad, begin) {
      if (begin) c.beginPath();
      const cx = dx(g.CX[b]), cy = dy(g.CY[b]);
      for (let i = 0; i < 6; i++) { const a = ((-90 + 60 * i) * Math.PI) / 180; const x = cx + Math.cos(a) * rad, y = cy + Math.sin(a) * rad; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
      c.closePath();
    }
    function cellFill(c, b, k) { if (g.K === 6) hexPath(c, b, G.gap * 0.8 * k, true); else { const w = G.gap * 0.74 * k, cx = dx(g.CX[b]), cy = dy(g.CY[b]); rr(c, cx - w / 2, cy - w / 2, w, w, G.gap * 0.1); } }
    function ensureCache() {
      const key = cv.w + 'x' + cv.h + ':' + G.gap.toFixed(2) + ':' + st.bx.replace(/[^#]/g, '.');
      if (key === cacheKey) return;
      cacheKey = key;
      const dpr = cv.dpr;
      cache.width = Math.round(cv.w * dpr); cache.height = Math.round(cv.h * dpr);
      const c = cctx; c.setTransform(dpr, 0, 0, dpr, 0, 0);
      const bg = c.createLinearGradient(0, 0, 0, cv.h); bg.addColorStop(0, '#1e1729'); bg.addColorStop(1, '#110d18');
      c.fillStyle = bg; c.fillRect(0, 0, cv.w, cv.h);
      const m = G.m, fr = G.fr;
      // drop shadow
      c.save(); c.translate(3, 6); unionPath(c, m + fr, fr + 6); c.fillStyle = 'rgba(0,0,0,.45)'; c.fill(); c.restore();
      // wooden frame following the board shape
      const x0 = dx(0) - m - fr, y0 = dy(0) - m - fr, x1 = dx(g.W) + m + fr, y1 = dy(g.H) + m + fr;
      const wood = c.createLinearGradient(x0, y0, x1, y1);
      wood.addColorStop(0, '#8a5a2e'); wood.addColorStop(0.45, '#6b4222'); wood.addColorStop(1, '#4e2f17');
      unionPath(c, m + fr, fr + 6); c.fillStyle = wood; c.fill();
      c.save(); unionPath(c, m + fr, fr + 6); c.clip();
      const rn = lcg(77);
      c.strokeStyle = 'rgba(30,15,5,.28)'; c.lineWidth = 1;
      for (let k = 0; k < 60; k++) { const y = y0 + rn() * (y1 - y0); c.beginPath(); c.moveTo(x0, y); c.bezierCurveTo(x0 + (x1 - x0) * 0.3, y + (rn() - 0.5) * 6, x0 + (x1 - x0) * 0.7, y + (rn() - 0.5) * 6, x1, y + (rn() - 0.5) * 4); c.stroke(); }
      c.restore();
      unionPath(c, m + 1.5, 6); c.fillStyle = '#2a1a0e'; c.fill();
      // slate
      const sl = c.createRadialGradient((x0 + x1) / 2, (y0 + y1) * 0.45, 10, (x0 + x1) / 2, (y0 + y1) / 2, Math.max(x1 - x0, y1 - y0) * 0.75);
      sl.addColorStop(0, '#2f4a40'); sl.addColorStop(0.6, '#243a32'); sl.addColorStop(1, '#1a2b25');
      unionPath(c, m, 5); c.fillStyle = sl; c.fill();
      c.save(); unionPath(c, m, 5); c.clip();
      // chalk smudges
      const rs = lcg(31 + g.NB);
      for (let k = 0; k < 26; k++) {
        const x = x0 + rs() * (x1 - x0), y = y0 + rs() * (y1 - y0), r = 14 + rs() * 40;
        const gr = c.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(235,240,230,.045)'); gr.addColorStop(1, 'rgba(235,240,230,0)');
        c.fillStyle = gr; c.fillRect(x - r, y - r, r * 2, r * 2);
      }
      c.strokeStyle = 'rgba(235,240,230,.04)'; c.lineWidth = 6; c.lineCap = 'round';
      for (let k = 0; k < 7; k++) { const x = x0 + rs() * (x1 - x0), y = y0 + rs() * (y1 - y0); c.beginPath(); c.arc(x, y, 20 + rs() * 50, rs() * 6, rs() * 6 + 1.2); c.stroke(); }
      // faint guides for every playable line
      c.strokeStyle = 'rgba(235,240,230,.09)'; c.lineWidth = 1.2; c.setLineDash([2, 5]);
      c.beginPath();
      for (let l = 0; l < g.NL; l++) { if (!g.ex[l]) continue; const p = lineXY(l); c.moveTo(p[0], p[1]); c.lineTo(p[2], p[3]); }
      c.stroke(); c.setLineDash([]);
      c.restore();
      // holes: recessed wood pockets with hatching
      const outside = new Uint8Array(g.NB), q = [];
      for (let b = 0; b < g.NB; b++) { const r = (b / g.C) | 0, cc = b % g.C; if (!g.has[b] && (r === 0 || cc === 0 || r === g.R - 1 || cc === g.C - 1)) { outside[b] = 1; q.push(b); } }
      while (q.length) { const b = q.pop(), r = (b / g.C) | 0, cc = b % g.C; for (const [nr, nc] of [[r - 1, cc], [r + 1, cc], [r, cc - 1], [r, cc + 1]]) { if (nr < 0 || nc < 0 || nr >= g.R || nc >= g.C) continue; const nb = nr * g.C + nc; if (!g.has[nb] && !outside[nb]) { outside[nb] = 1; q.push(nb); } } }
      // interior holes: one recessed wooden pocket (neighbouring hole cells merge)
      const isIn = (r, cc) => r >= 0 && cc >= 0 && r < g.R && cc < g.C && !g.has[r * g.C + cc] && !outside[r * g.C + cc];
      const ins = G.gap * 0.16, rects = [];
      for (let b = 0; b < g.NB; b++) {
        if (g.has[b] || outside[b]) continue;
        const r = (b / g.C) | 0, cc = b % g.C;
        const xa = dx(cc) + (isIn(r, cc - 1) ? 0 : ins), xb = dx(cc + 1) - (isIn(r, cc + 1) ? 0 : ins);
        const ya = dy(r) + (isIn(r - 1, cc) ? 0 : ins), yb = dy(r + 1) - (isIn(r + 1, cc) ? 0 : ins);
        rects.push([xa, ya, xb - xa, yb - ya]);
      }
      if (rects.length) {
        const pocket = () => { c.beginPath(); for (const q of rects) c.rect(q[0], q[1], q[2], q[3]); };
        pocket(); c.fillStyle = '#3a2414'; c.fill();
        c.save(); pocket(); c.clip();
        c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 2;
        const X0 = dx(0), X1 = dx(g.W), Y0 = dy(0), Y1 = dy(g.H), span = Y1 - Y0;
        c.beginPath(); for (let t = X0 - span; t < X1 + span; t += 7) { c.moveTo(t, Y0); c.lineTo(t - span, Y1); } c.stroke();
        for (const q of rects) {
          const r0 = Math.round((q[1] - dy(0)) / G.gap - 0.2), c0 = Math.round((q[0] - dx(0)) / G.gap - 0.2);
          if (isIn(r0 - 1, c0)) continue; // shade only the top edge of the pocket
          const sh = c.createLinearGradient(0, q[1], 0, q[1] + G.gap * 0.3); sh.addColorStop(0, 'rgba(0,0,0,.5)'); sh.addColorStop(1, 'rgba(0,0,0,0)');
          c.fillStyle = sh; c.fillRect(q[0], q[1], q[2], G.gap * 0.3);
        }
        c.restore();
      }
      // brass dot sprite
      const R = Math.max(4.2, G.gap * 0.1), S = Math.ceil((R + 4) * 2);
      dotC.width = Math.round(S * dpr); dotC.height = Math.round(S * dpr);
      const d = dotC.getContext('2d'); d.setTransform(dpr, 0, 0, dpr, 0, 0); d.clearRect(0, 0, S, S);
      d.fillStyle = 'rgba(0,0,0,.45)'; d.beginPath(); d.arc(S / 2 + 0.8, S / 2 + 1.6, R + 0.6, 0, 7); d.fill();
      const bg2 = d.createRadialGradient(S / 2 - R * 0.35, S / 2 - R * 0.4, R * 0.1, S / 2, S / 2, R);
      bg2.addColorStop(0, '#fff4c8'); bg2.addColorStop(0.35, '#e8b84c'); bg2.addColorStop(0.8, '#a8741f'); bg2.addColorStop(1, '#6e4a12');
      d.fillStyle = bg2; d.beginPath(); d.arc(S / 2, S / 2, R, 0, 7); d.fill();
      d.strokeStyle = 'rgba(60,35,5,.7)'; d.lineWidth = 0.8; d.stroke();
      G.dotS = S;
    }

    function lineXY(l) { const a = g.ends[l * 2], b = g.ends[l * 2 + 1]; return [dx(g.VX[a]), dy(g.VY[a]), dx(g.VX[b]), dy(g.VY[b])]; }
    function chalkLine(x1, y1, x2, y2, color, w, alpha) {
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.28)'; ctx.lineWidth = w + 1.5;
      ctx.beginPath(); ctx.moveTo(x1 + 0.8, y1 + 1.4); ctx.lineTo(x2 + 0.8, y2 + 1.4); ctx.stroke();
      ctx.strokeStyle = color; ctx.lineWidth = w;
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = Math.max(1, w * 0.3);
      const hz = Math.abs(y2 - y1) < 1;
      ctx.beginPath(); ctx.moveTo(x1 + (hz ? 0 : -w * 0.18), y1 + (hz ? -w * 0.18 : 0)); ctx.lineTo(x2 + (hz ? 0 : -w * 0.18), y2 + (hz ? -w * 0.18 : 0)); ctx.stroke();
      // 분필 결: 선 위에 옅은 빈틈 몇 점(좌표로 정해져 매번 같은 모양)
      const len = Math.hypot(x2 - x1, y2 - y1), n = Math.floor(len / 5);
      if (n > 1) {
        let h = ((x1 * 73856093) ^ (y1 * 19349663) ^ (x2 * 83492791)) | 0;
        ctx.fillStyle = 'rgba(30,48,40,.24)';
        for (let i = 0; i < n; i++) {
          h = (Math.imul(h, 1664525) + 1013904223) | 0; const r1 = ((h >>> 8) & 255) / 255;
          h = (Math.imul(h, 1664525) + 1013904223) | 0; const r2 = ((h >>> 8) & 255) / 255;
          if (r1 < 0.45) continue;
          const t = (i + r2) / n, px = x1 + (x2 - x1) * t, py = y1 + (y2 - y1) * t, o = (r2 - 0.5) * w * 0.6;
          ctx.fillRect(px + (hz ? 0 : o) - 0.6, py + (hz ? o : 0) - 0.6, 1.2 + r1, 1.2);
        }
      }
      ctx.globalAlpha = 1;
    }
    function boxRect(b) { return [dx(g.CX[b]) - G.gap / 2, dy(g.CY[b]) - G.gap / 2]; }
    function drawBox(b, owner, sc, alpha) {
      const [x, y] = boxRect(b), gp = G.gap, ins = gp * 0.13, w = (gp - ins * 2) * sc;
      const cx = x + gp / 2, cy = y + gp / 2;
      ctx.globalAlpha = alpha;
      cellFill(ctx, b, sc); ctx.fillStyle = col(owner); ctx.globalAlpha = alpha * 0.62; ctx.fill();
      // 분필 빗금 + 안쪽 빛
      ctx.save(); ctx.clip();
      ctx.globalAlpha = alpha * 0.22; ctx.strokeStyle = '#fbf5e6'; ctx.lineWidth = Math.max(1, gp * 0.025);
      ctx.beginPath(); for (let k = -gp; k < gp; k += gp * 0.16) { ctx.moveTo(cx + k - gp / 2, cy + gp / 2); ctx.lineTo(cx + k + gp / 2, cy - gp / 2); } ctx.stroke();
      const ig = ctx.createRadialGradient(cx - gp * 0.15, cy - gp * 0.2, gp * 0.05, cx, cy, gp * 0.6);
      ig.addColorStop(0, 'rgba(255,255,255,.28)'); ig.addColorStop(1, 'rgba(0,0,0,.18)');
      ctx.globalAlpha = alpha; ctx.fillStyle = ig; ctx.fillRect(cx - gp, cy - gp, gp * 2, gp * 2);
      ctx.restore(); cellFill(ctx, b, sc);
      ctx.globalAlpha = alpha * 0.9; ctx.lineWidth = Math.max(1, gp * 0.03); ctx.strokeStyle = col(owner); ctx.stroke();
      ctx.globalAlpha = alpha;
      ctx.font = Math.round(gp * 0.44 * sc) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillText(marks[owner] || '?', cx + 1, cy + 2.5);
      ctx.fillStyle = '#fbf5e6'; ctx.fillText(marks[owner] || '?', cx, cy + 1.5);
      ctx.globalAlpha = 1;
    }
    /* boxes a line would close / give away right now */
    function preview(l) {
      let cap = [], danger = false;
      for (let j = 0; j < 2; j++) {
        const b = g.lb[l * 2 + j]; if (b < 0 || st.bx[b] !== '.') continue;
        const k = sidesOf(st, g, b);
        if (k === g.K - 1) cap.push(b); else if (k === g.K - 2) danger = true;
      }
      return { cap, danger: danger && !cap.length };
    }

    function draw(now) {
      cv.clear();
      if (!st || !G) return;
      now = now || performance.now();
      ensureCache();
      ctx.drawImage(cache, 0, 0, cv.w, cv.h);
      const lw = Math.max(3.2, G.gap * 0.085);
      const animL = anim ? anim.l : -1, animB = anim ? anim.b : null;
      // owned boxes
      for (let b = 0; b < g.NB; b++) {
        const o = st.bx[b];
        if (o === '.' || o === '#') continue;
        if (animB && animB.indexOf(b) >= 0) continue;
        drawBox(b, +o, 1, 1);
      }
      // capture preview of the selected line
      const myT = myTurn();
      if (sel >= 0 && myT) {
        const pv = preview(sel), pulse = 0.5 + 0.5 * Math.sin(now / 160);
        for (const b of pv.cap) {
          const [x, y] = boxRect(b);
          ctx.globalAlpha = 0.18 + pulse * 0.16; ctx.fillStyle = col(st.turn); cellFill(ctx, b, 1); ctx.fill();
          ctx.globalAlpha = 0.9; ctx.fillStyle = '#fbf5e6'; ctx.font = '700 ' + Math.round(G.gap * 0.3) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText('+1', x + G.gap / 2, y + G.gap / 2); ctx.globalAlpha = 1;
        }
      }
      // drawn lines
      const tl = st.tl || [], lastL = st.last ? st.last.l : -1;
      for (let l = 0; l < g.NL; l++) {
        if (st.ln[l] !== '1' || l === animL || tl.indexOf(l) >= 0) continue;
        const p = lineXY(l); chalkLine(p[0], p[1], p[2], p[3], '#ece6d6', lw);
      }
      // the latest turn's lines in that player's colour
      for (const l of tl) {
        if (l === animL || st.ln[l] !== '1') continue;
        const p = lineXY(l);
        if (l === lastL) { ctx.save(); ctx.shadowColor = col(st.tp); ctx.shadowBlur = 10; chalkLine(p[0], p[1], p[2], p[3], col(st.tp), lw + 1); ctx.restore(); }
        else chalkLine(p[0], p[1], p[2], p[3], col(st.tp), lw, 0.85);
      }
      // animating line
      if (anim) {
        const t = U.clamp((now - anim.t0) * L.debug.speed / LINE_MS, 0, 1), e = 1 - (1 - t) * (1 - t);
        const p = lineXY(anim.l);
        chalkLine(p[0], p[1], p[0] + (p[2] - p[0]) * e, p[1] + (p[3] - p[1]) * e, col(anim.s), lw + 1);
        if (t < 1 && Math.random() < 0.7) dust(p[0] + (p[2] - p[0]) * e, p[1] + (p[3] - p[1]) * e, 1, ['#ece6d6', col(anim.s)], now, 0.5);
        if (anim.b.length) {
          const tb0 = ((now - anim.t0) * L.debug.speed - LINE_MS) / POP_MS;
          if (tb0 > 0 && tb0 < 1.6) for (const b of anim.b) { // 둘러치는 빛 고리
            const [x, y] = boxRect(b); ctx.save(); ctx.globalAlpha = Math.max(0, 1 - tb0 / 1.6) * 0.8; ctx.strokeStyle = col(anim.s); ctx.lineWidth = 2.5;
            ctx.shadowColor = col(anim.s); ctx.shadowBlur = 12; cellFill(ctx, b, 0.9 + tb0 * 0.35); ctx.stroke(); ctx.restore();
          }
          const tb = U.clamp(((now - anim.t0) * L.debug.speed - LINE_MS) / POP_MS, 0, 1);
          if (tb > 0) for (const b of anim.b) { const sc = tb < 0.7 ? 0.5 + (tb / 0.7) * 0.62 : 1.12 - ((tb - 0.7) / 0.3) * 0.12; drawBox(b, anim.s, sc, Math.min(1, tb * 2.2)); }
        }
      }
      // hover / selection
      if (myT && hov >= 0 && hov !== sel && st.ln[hov] === '0') { const p = lineXY(hov); chalkLine(p[0], p[1], p[2], p[3], '#ece6d6', lw, 0.32); }
      if (myT && sel >= 0 && st.ln[sel] === '0') {
        const p = lineXY(sel), pulse = 0.55 + 0.45 * Math.sin(now / 140);
        ctx.save(); ctx.setLineDash([lw * 1.6, lw * 1.2]);
        ctx.shadowColor = col(st.turn); ctx.shadowBlur = 12;
        chalkLine(p[0], p[1], p[2], p[3], col(st.turn), lw + 1.5, 0.55 + pulse * 0.45);
        ctx.restore();
        ctx.strokeStyle = col(st.turn); ctx.lineWidth = 2; ctx.globalAlpha = 0.7;
        for (const [x, y] of [[p[0], p[1]], [p[2], p[3]]]) { ctx.beginPath(); ctx.arc(x, y, Math.max(8, G.gap * 0.2), 0, 7); ctx.stroke(); }
        ctx.globalAlpha = 1;
      }
      // brass dots
      const S = G.dotS;
      for (let v = 0; v < g.NV; v++) if (g.dotOn[v]) ctx.drawImage(dotC, dx(g.VX[v]) - S / 2, dy(g.VY[v]) - S / 2, S, S);
      // floating streak numbers
      for (let i = fx.length - 1; i >= 0; i--) {
        const f = fx[i];
        if (f.p) {
          const tt = (now - f.t0) * L.debug.speed / 1000;
          if (tt >= f.life) { fx.splice(i, 1); continue; }
          const k = tt / f.life; ctx.globalAlpha = (1 - k) * 0.85; ctx.fillStyle = f.c;
          ctx.beginPath(); ctx.arc(f.x + f.vx * tt, f.y + f.vy * tt + 60 * tt * tt, f.r * (1 - k * 0.5), 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          continue;
        }
        const t = (now - f.t0) * L.debug.speed / 800;
        if (t >= 1) { fx.splice(i, 1); continue; }
        ctx.globalAlpha = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3;
        ctx.font = '700 ' + Math.round(Math.max(14, G.gap * 0.34)) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const y = f.y - t * G.gap * 0.6;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(20,12,28,.85)'; ctx.strokeText(f.text, f.x, y);
        ctx.fillStyle = f.c; ctx.fillText(f.text, f.x, y);
        ctx.globalAlpha = 1;
      }
    }
    const LINE_MS = 170, POP_MS = 260;
    function dust(x, y, n, cols, now, life) {
      for (let k = 0; k < n; k++) { const a = Math.random() * Math.PI * 2, v = 10 + Math.random() * 40; fx.push({ p: 1, x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 10, r: 0.8 + Math.random() * 1.6, c: cols[k % cols.length], t0: now, life: (life || 0.6) * (0.6 + Math.random() * 0.8) }); }
    }

    /* loop only while something moves */
    function needLoop() { return !!anim || fx.length > 0 || (sel >= 0 && myTurn()); }
    function kick() {
      if (needLoop() && !stopLoop) stopLoop = U.loop((dt, now) => { tickAnim(now); draw(now); if (!needLoop()) { stopLoop(); stopLoop = null; } });
      if (!stopLoop) draw();
    }
    function tickAnim(now) {
      if (!anim) return;
      const total = LINE_MS + (anim.b.length ? POP_MS : 0);
      const el = (now - anim.t0) * L.debug.speed;
      if (!anim.popped && anim.b.length && el >= LINE_MS) {
        anim.popped = true;
        api.sfx(anim.k >= 3 ? 'chip' : 'pop');
        if (api.canAct(anim.s)) api.buzz(anim.b.length > 1 ? 25 : 15);
        anim.b.forEach((b) => { const [x, y] = boxRect(b); dust(x + G.gap / 2, y + G.gap / 2, 12, [col(anim.s), '#fbf5e6', '#e3ae45'], now, 0.8); });
        anim.b.forEach((b, i) => { const [x, y] = boxRect(b); fx.push({ x: x + G.gap / 2, y: y + G.gap * 0.35, text: '+' + (anim.k - anim.b.length + i + 1), c: col(anim.s), t0: now }); });
      }
      if (el >= total) finishAnim();
    }
    function finishAnim() {
      if (!anim) return;
      const a = anim; anim = null;
      clearTimeout(watchdog);
      if (a.k >= 3 && a.b.length && a.last) api.toast(nm(a.s) + ' 연속 ' + a.k + '개!');
      if (st && done(st)) { // 마지막 상자: 이긴 쪽 상자마다 분필 가루가 터진다
        const sc = {}; for (let b = 0; b < g.NB; b++) { const o = st.bx[b]; if (o !== '.' && o !== '#') sc[o] = (sc[o] || 0) + 1; }
        const top = Math.max(0, ...Object.values(sc)), now = performance.now();
        for (let b = 0; b < g.NB; b++) { const o = st.bx[b]; if (o !== '.' && o !== '#' && sc[o] === top) { const [x, y] = boxRect(b); dust(x + G.gap / 2, y + G.gap / 2, 5, [col(+o), '#fbf5e6', '#f6d27a'], now + b * 6, 1.1); } }
        api.sfx('whoosh'); kick();
      }
      if (busy) { busy = false; api.setBusy(false); }
      refresh();
    }
    function startAnim(last, s) {
      anim = { l: last.l, b: last.b.slice(), s: last.s, k: last.k || 0, t0: performance.now(), popped: false, last: false };
      // toast only once the streak ends (turn passes) — otherwise a long chain would spam
      anim.last = anim.k >= 3 && (done(s) || chainEnds(s, last.s));
      api.sfx('tick');
      if (!busy) { busy = true; api.setBusy(true); }
      clearTimeout(watchdog);
      watchdog = setTimeout(finishAnim, (LINE_MS + POP_MS) / L.debug.speed + 900);
      kick();
    }
    /* no more box to close for this player → the streak is over */
    function chainEnds(s, seat) {
      for (let b = 0; b < g.NB; b++) if (g.has[b] && s.bx[b] === '.' && sidesOf(s, g, b) === g.K - 1) return false;
      return true;
    }

    function myTurn() { if (!st || anim || pending) return false; const a = actor(st); return a != null && api.canAct(a); }
    function hit(x, y) {
      if (!G) return -1;
      let best = -1, bd = G.gap * 0.56;
      for (let l = 0; l < g.NL; l++) {
        if (st.ln[l] !== '0') continue;
        const p = lineXY(l);
        const vx = p[2] - p[0], vy = p[3] - p[1];
        const t = U.clamp(((x - p[0]) * vx + (y - p[1]) * vy) / (vx * vx + vy * vy), 0, 1);
        const d = Math.hypot(x - (p[0] + vx * t), y - (p[1] + vy * t));
        if (d < bd) { bd = d; best = l; }
      }
      return best;
    }
    function choose(l) { if (l !== sel) { sel = l; if (l >= 0) { api.sfx('tick'); api.buzz(8); } refresh(); } }
    function commit() {
      if (!myTurn() || sel < 0 || st.ln[sel] !== '0') return;
      const l = sel; sel = -1; hov = -1;
      pending = true; clearTimeout(pendT); pendT = setTimeout(() => { pending = false; refresh(); }, 3000);
      api.buzz(12);
      api.act({ l });
      refresh();
    }
    function onDown(e) {
      if (!myTurn()) return;
      const p = cv.local(e);
      downSel = sel; dragging = true;
      const l = hit(p.x, p.y);
      if (l >= 0 && l !== sel) { sel = l; kick(); }
      try { cv.cv.setPointerCapture(e.pointerId); } catch (_) {}
    }
    function onMove(e) {
      if (!st || !G) return;
      const p = cv.local(e);
      if (dragging) { const l = hit(p.x, p.y); if (l >= 0 && l !== sel) { sel = l; refresh(); } return; }
      if (e.pointerType === 'mouse' && myTurn()) { const l = hit(p.x, p.y); if (l !== hov) { hov = l; cv.cv.style.cursor = l >= 0 ? 'pointer' : ''; draw(); } }
    }
    function onUp(e) {
      if (!dragging) return;
      dragging = false;
      if (!myTurn()) return;
      const p = cv.local(e);
      let l = hit(p.x, p.y); if (l < 0) l = sel;
      if (l >= 0 && l === downSel) { sel = l; commit(); return; }
      if (l >= 0) { sel = -1; choose(l); } else refresh();
    }
    function onCancel() { dragging = false; }
    function onLeave() { if (hov >= 0) { hov = -1; draw(); } }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('pointerleave', onLeave);
    /* keyboard (PC): arrows move the selection, Enter/Space draws, Esc cancels */
    function onKey(e) {
      if (!myTurn() || e.altKey || e.ctrlKey || e.metaKey) return;
      const tg = e.target && e.target.tagName; if (tg === 'INPUT' || tg === 'TEXTAREA') return;
      const k = e.key;
      if (k === 'Enter' || k === ' ') { if (sel >= 0) { e.preventDefault(); commit(); } return; }
      if (k === 'Escape') { if (sel >= 0) { e.preventDefault(); sel = -1; refresh(); } return; }   // consumed → core won't treat Esc as 'back'
      const dir = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[k];
      if (!dir) return;
      e.preventDefault();
      let ox, oy;
      if (sel >= 0) { const p = lineXY(sel); ox = (p[0] + p[2]) / 2; oy = (p[1] + p[3]) / 2; }
      else { ox = dx(g.W / 2); oy = dy(g.H / 2); }
      let best = -1, bs = Infinity;
      for (let l = 0; l < g.NL; l++) {
        if (st.ln[l] !== '0' || l === sel) continue;
        const p = lineXY(l), mx = (p[0] + p[2]) / 2 - ox, my = (p[1] + p[3]) / 2 - oy;
        const along = mx * dir[0] + my * dir[1];
        if (sel >= 0 ? along < G.gap * 0.2 : along < -G.gap * 0.01) continue;
        const side = Math.abs(mx * dir[1] - my * dir[0]);
        const sc = along + side * 2.2;
        if (sc < bs) { bs = sc; best = l; }
      }
      if (best >= 0) choose(best);
    }
    window.addEventListener('keydown', onKey);

    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      const cur = actor(st);
      for (let i = 0; i < st.n; i++) {
        const on = cur === i;
        top.append(L.h('div', { class: 'turn', style: { flex: '1 1 0', minWidth: '0', maxWidth: 'none', justifyContent: 'center', gap: '5px', padding: '4px 8px 4px 5px', borderColor: on ? col(i) : '', boxShadow: on ? '0 0 0 1px ' + col(i) + ' inset' : '', opacity: on || cur == null ? 1 : 0.72 } },
          L.h('span', { style: { display: 'inline-grid', placeItems: 'center', width: '22px', height: '22px', flex: 'none', borderRadius: '6px', background: col(i), color: '#1b1426', fontFamily: 'var(--f-display)', fontSize: '13px', lineHeight: 1 }, text: marks[i] }),
          L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', minWidth: '0', fontWeight: 600 }, text: nm(i) }),
          L.h('b', { class: 'mono', style: { flex: 'none', fontSize: '15px', color: on ? col(i) : 'var(--ink)' }, text: String(st.sc[i]) })));
      }
    }
    function refresh() {
      if (!st) return;
      const left = (st.bx.match(/\./g) || []).length;
      const l = st.last;
      if (l) evLine.textContent = nm(l.s) + (l.b.length ? ' · 상자 +' + l.b.length + (l.k >= 2 ? ' (연속 ' + l.k + ')' : '') : ' · 선 긋기') + '  ·  남은 상자 ' + left;
      else evLine.textContent = '판: ' + (SHAPE_NAME[st.sh] || '') + ' · 상자 ' + g.nBoxes + '개';
      const cur = actor(st);
      const mine = cur != null && api.canAct(cur);
      let txt = '', color = 'var(--muted)';
      if (cur == null) txt = '게임 끝!';
      else if (!mine) txt = nm(cur) + ' 차례' + (l && l.s === cur && l.b.length ? ' · 한 번 더' : '');
      else {
        let humans = 0; for (let i = 0; i < st.n; i++) if (api.canAct(i)) humans++;
        const who = humans > 1 ? nm(cur) + ' · ' : '';
        const again = l && l.s === cur && l.b.length ? '한 번 더! ' : '';
        color = 'var(--brass)';
        if (sel < 0 || st.ln[sel] !== '0') txt = who + (again ? '한 번 더! 그을 선을 톡' : '그을 선을 톡 → 한 번 더 톡');
        else {
          const pv = preview(sel);
          if (pv.cap.length) { txt = who + '상자 ' + pv.cap.length + '개 닫혀요! 한 번 더 톡'; color = '#7fe0a8'; }
          else if (pv.danger) { txt = who + '⚠ 상대에게 상자를 줘요'; color = 'var(--coral)'; }
          else txt = who + '한 번 더 톡 또는 「긋기」';
        }
      }
      hint.textContent = txt; hint.style.color = color;
      const show = mine;
      cancelBtn.hidden = !show; drawBtn.hidden = !show;
      drawBtn.disabled = !myTurn() || sel < 0;
      cancelBtn.disabled = sel < 0;
      cv.cv.style.cursor = myTurn() ? '' : 'default';
      renderTop();
      kick();
    }

    return {
      update(next, prev) {
        const first = !st;
        st = next;
        if (first || !g || geo(next) !== g) { g = geo(next); layout(); }
        pending = false; clearTimeout(pendT);
        if (sel >= 0 && st.ln[sel] !== '0') sel = -1;
        if (actor(st) == null || !api.canAct(actor(st))) { sel = -1; hov = -1; }
        const key = next.last ? next.g + ':' + next.last.id : next.g + ':0';
        if (next.last && key !== shownKey && prev && prev !== next && !first) {
          shownKey = key;
          if (anim) finishAnim();
          startAnim(next.last, next);
        } else shownKey = key;
        refresh();
      },
      destroy() {
        if (stopLoop) stopLoop(); stopLoop = null;
        clearTimeout(watchdog); clearTimeout(pendT); window.removeEventListener('lounge-cancel', onCancelEv);
        if (busy) { busy = false; api.setBusy(false); }
        window.removeEventListener('keydown', onKey);
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onCancel); cv.cv.removeEventListener('pointerleave', onLeave);
        cv.destroy(); top.remove(); hud.remove();
      },
    };
  }

  L.register({
    id: 'dots', name: '점 잇기 상자', tag: '선 긋기 땅따먹기', cat: '보드',
    blurb: '점과 점 사이에 선을 하나씩! 상자의 네 번째 선을 그으면 내 상자가 되고 한 번 더 그어요. 상자를 가장 많이 가지면 승리.',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false,
    tint: '#1f5446',
    icon: '<rect x="12" y="12" width="16" height="16" fill="currentColor" opacity=".35"/><path d="M12 12H28V28H12Z M28 12H44 M28 28V44" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="12" cy="12" r="3.6" fill="currentColor"/><circle cx="28" cy="12" r="3.6" fill="currentColor"/><circle cx="44" cy="12" r="3.6" fill="currentColor"/><circle cx="12" cy="28" r="3.6" fill="currentColor"/><circle cx="28" cy="28" r="3.6" fill="currentColor"/><circle cx="44" cy="28" r="3.6" fill="currentColor"/><circle cx="12" cy="44" r="3.6" fill="currentColor"/><circle cx="28" cy="44" r="3.6" fill="currentColor"/><circle cx="44" cy="44" r="3.6" fill="currentColor"/>',
    options: [
      { id: 'size', label: '판 크기', def: 'm', choices: [{ v: 's', label: '작게' }, { v: 'm', label: '보통' }, { v: 'l', label: '크게' }] },
      { id: 'shape', label: '판 모양', tip: '점이 놓인 모양. 구멍·십자는 막힌 칸이 있어요.', def: 'rand', choices: SHAPES.map((x) => ({ v: x.id, label: x.name })).concat([{ v: 'rand', label: '무작위' }]) },
    ],
    quick: [
      '점과 점 사이에 선을 그어 네모 상자를 만들어요. 상자를 가장 많이 가진 사람이 이겨요.',
      '내 차례: 바로 옆 두 점 사이에 선 1개를 그어요(탭 → 한 번 더 탭 또는 「긋기」).',
      '상자의 네 번째 변을 그으면 그 상자는 내 것 + 한 번 더 그어요. 세 번째 변을 그어 주면 남 좋은 일!',
    ],
    rules: [
      { h: '그림으로 보기', fig: [{"svg": "<svg viewBox=\"0 0 340 110\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"110\" rx=\"10\" fill=\"#1f2a24\"/><path d=\"M30 20L70 20\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M30 20L30 60\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M70 20L70 60\" stroke=\"#e3ae45\" stroke-width=\"4\" stroke-dasharray=\"5 4\"/><circle cx=\"30\" cy=\"20\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"30\" cy=\"60\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"70\" cy=\"20\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"70\" cy=\"60\" r=\"4.5\" fill=\"#fff\"/><text x=\"50\" y=\"82\" font-size=\"11\" fill=\"#f3ead2\" text-anchor=\"middle\">셋째 변은</text><text x=\"50\" y=\"97\" font-size=\"11\" fill=\"#f2a0a0\" text-anchor=\"middle\">상대에게 선물</text><path d=\"M150 20L190 20\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M150 20L150 60\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M190 20L190 60\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M150 60L190 60\" stroke=\"#e3ae45\" stroke-width=\"4\" stroke-dasharray=\"5 4\"/><circle cx=\"150\" cy=\"20\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"150\" cy=\"60\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"190\" cy=\"20\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"190\" cy=\"60\" r=\"4.5\" fill=\"#fff\"/><text x=\"170\" y=\"82\" font-size=\"11\" fill=\"#f3ead2\" text-anchor=\"middle\">넷째 변 →</text><text x=\"170\" y=\"97\" font-size=\"11\" fill=\"#9fd59f\" text-anchor=\"middle\">상자는 내 것!</text><rect x=\"270\" y=\"20\" width=\"40\" height=\"40\" fill=\"#e3ae45\" opacity=\".7\"/><path d=\"M270 20L310 20\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M270 20L270 60\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M310 20L310 60\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><path d=\"M270 60L310 60\" stroke=\"#e8dcc0\" stroke-width=\"4\" stroke-linecap=\"round\"/><circle cx=\"270\" cy=\"20\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"270\" cy=\"60\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"310\" cy=\"20\" r=\"4.5\" fill=\"#fff\"/><circle cx=\"310\" cy=\"60\" r=\"4.5\" fill=\"#fff\"/><text x=\"290\" y=\"46\" font-size=\"14\" fill=\"#1f2a24\" text-anchor=\"middle\" font-weight=\"700\">+1</text><text x=\"290\" y=\"82\" font-size=\"11\" fill=\"#f3ead2\" text-anchor=\"middle\">닫으면 한 번</text><text x=\"290\" y=\"97\" font-size=\"11\" fill=\"#f3ead2\" text-anchor=\"middle\">더 그어요</text></svg>", "cap": "상자의 셋째 변을 그으면 상대가 넷째 변으로 가져가요"}] },
      { h: '목표', p: [
        '점과 점 사이에 선을 그어 상자(네모 칸)를 만들어요.',
        '모든 상자가 주인을 찾으면 끝. 상자가 가장 많은 사람이 이기고, 같으면 공동 1등이에요.'] },
      { h: '차례에 할 일', p: [
        '바로 옆 두 점 사이(가로 또는 세로)에 선을 딱 하나 그어요. 넘길 수는 없어요.',
        '그 선으로 상자의 네 번째 변이 채워지면 그 상자는 내 것! 내 색과 글자가 칠해지고, 한 번 더 그어요.',
        '상자를 못 닫으면 다음 사람 차례예요. 선 하나로 상자 두 개가 한꺼번에 닫히면 둘 다 내 거예요.'] },
      { h: '작전', p: [
        '어떤 상자에 변이 세 개면, 다음 사람이 네 번째를 그어 가져가요. 그래서 세 번째 변은 되도록 긋지 마세요.',
        '피할 곳이 없어지면 누군가는 세 번째 변을 그어야 해요. 그때는 상자가 가장 적게 이어진 곳을 내주세요.',
        '상자를 하나 가져가면 또 그을 수 있어서, 여러 개를 줄줄이(사슬) 가져갈 수 있어요.'] },
      { h: '판', p: [
        '판 크기: 작게 · 보통 · 크게. 판 모양: 네모 · 십자 · 구멍 · 육각 · 무작위(기본).',
        '네모: 3×3 / 5×5 / 7×7 상자. 십자: 네 귀퉁이가 없는 판. 구멍: 군데군데 상자가 없는 칸(나무 무늬)이 있어요. 구멍 둘레의 선도 그을 수 있어요.',
        '육각: 벌집 모양 판(9 / 20 / 28칸). 칸의 변이 6개라서 여섯 번째 변을 그은 사람이 그 칸을 가져요. 다섯 번째 변을 그어 주면 상대가 가져가요.'] },
      { h: '조작', p: [
        '그을 선 근처를 톡 → 선이 깜빡이며 미리 보여요. 같은 곳을 한 번 더 톡하거나 「긋기」를 누르면 그어져요. ✕는 취소.',
        '누른 채로 손가락을 움직이면 선택이 따라와요. 닫히는 상자에는 +1, 세 번째 변이 되는 선이면 아래에 경고가 떠요.',
        'PC: 클릭 두 번, 또는 방향키로 고르고 Enter. 방금 차례에 그은 선은 그 사람 색으로 보여요.'] },
      { h: '예시', p: [
        '어떤 상자에 세 변이 그어져 있으면 → 마지막 변을 그어 가져가고 → 또 그어요. 옆 상자도 세 변이면 또 가져가요.',
        '반대로 내가 상자의 세 번째 변을 그으면 → 다음 사람이 그 상자를 가져가요. 조심!'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움: 아무 데나 긋고 상자도 가끔 놓쳐요. 보통: 상자는 꼭 챙기고, 어쩔 수 없을 때만 세 번째 변을 그어요. 어려움: 긴 사슬을 누가 열게 될지 계산하고, 마지막 두 칸을 일부러 넘겨 주도권을 잡는 작전도 써요.'] },
    ],
    tutorial: [
      { sel: '.dt-board', text: '점과 점 사이에 선을 하나씩 번갈아 그어요. 그을 선 근처를 톡 하면 깜빡이며 미리 보여요. 한 번 더 톡(또는 「긋기」)하면 그어져요.' },
      { sel: '.dt-board', text: '상자의 네 번째 변을 그으면 그 상자는 내 것! 내 색으로 칠해지고 한 번 더 그어요. 그래서 세 번째 변은 되도록 긋지 마세요. 상대가 가져가요.' },
      { sel: '.dt-info', text: '여기에 지금 할 일이 보여요. 고른 선이 상자를 닫으면 +1, 세 번째 변이 되면 경고가 떠요.' },
      { sel: '.dt-top', text: '위에는 사람마다 가진 상자 수가 보여요. 상자가 다 차면 가장 많은 사람이 승리! 시작!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { geo, boardSpec, work, decompose, fval, fOf, ddPattern, giveaway, safeLines, capLines, sidesOf },
  });
})();
