/* 보물 사냥 주사위 모험 — 차례마다 던전으로 내려가며 주사위로 방을 돌파하는 운 시험 게임(독자 디자인). */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- 데이터 ---------- */
  // 주사위 면: 0 검, 1 방패, 2 횃불, 3 열쇠, 4 보물, 5 해골. 8면 주사위.
  const FN = ['검', '방패', '횃불', '열쇠', '보물', '해골'];
  const DIE = [0, 0, 1, 2, 3, 4, 4, 5];
  const ND = 6;
  const FDESC = [
    '괴물 방에서 가장 많이 필요해요. 주사위 8면 중 2면.',
    '함정을 막아요. 방에 필요 없으면 같은 굴림의 해골 1개를 막아 줘요. 8면 중 1면.',
    '어둠을 밝혀요. 8면 중 1면.',
    '잠긴 궤짝·금고·성소를 열어요. 8면 중 1면.',
    '나오는 즉시 전리품 금화 +1. 그 주사위는 다시 굴릴 수 있어요. 8면 중 2면.',
    '저주! 이번 탐험의 해골이 3개가 되면 도망쳐서 전리품을 모두 잃어요. 그 방을 나갈 때까지 그 주사위는 못 써요. 8면 중 1면.',
  ];
  // q: [검, 방패, 횃불, 열쇠], g: 보상, w: 던전별 가중치 [묘지, 거미굴, 왕릉, 신전, 대장간], mn: 나오는 최소 층
  const ROOMS = [
    { n: '해골 병사', c: '괴물', q: [2, 0, 0, 0], g: 2, w: [5, 3, 3, 2, 3], mn: 1, e: 'skull' },
    { n: '거미 여왕의 둥지', c: '괴물', q: [1, 0, 1, 0], g: 2, w: [2, 6, 2, 1, 1], mn: 1, e: 'spider' },
    { n: '숨 막히는 어둠 통로', c: '통로', q: [0, 0, 2, 0], g: 1, w: [3, 5, 2, 3, 1], mn: 1, e: 'torch' },
    { n: '잠긴 궤짝', c: '보물', q: [0, 0, 0, 1], g: 3, w: [3, 2, 5, 4, 4], mn: 1, e: 'chest' },
    { n: '화살 함정', c: '함정', q: [0, 2, 0, 0], g: 1, w: [2, 2, 4, 1, 3], mn: 1, e: 'arrow', tr: 1 },
    { n: '가시 구덩이', c: '함정', q: [0, 1, 1, 0], g: 2, w: [2, 3, 3, 2, 3], mn: 1, e: 'spikes', tr: 1 },
    { n: '울부짖는 망령', c: '괴물', q: [2, 1, 0, 0], g: 4, w: [4, 2, 3, 3, 1], mn: 2, e: 'eye' },
    { n: '봉인된 금고', c: '보물', q: [0, 0, 0, 2], g: 5, w: [2, 1, 4, 3, 3], mn: 2, e: 'chest' },
    { n: '유물 성소', c: '유물', q: [0, 0, 1, 1], g: 1, w: [2, 2, 3, 3, 3], mn: 2, e: 'gem', rl: 1 },
    { n: '핏빛 샘', c: '쉼터', q: [0, 0, 0, 0], g: 0, w: [2, 2, 2, 3, 1], mn: 2, e: 'drop', hl: 1 },
    { n: '뼈 거인', c: '괴물', q: [3, 0, 0, 0], g: 6, w: [3, 2, 2, 1, 2], mn: 3, e: 'golem' },
    { n: '물에 잠긴 회랑', c: '통로', q: [0, 1, 1, 0], g: 1, w: [0, 0, 0, 5, 0], mn: 1, e: 'wave' },
    { n: '산호 보물고', c: '보물', q: [0, 0, 1, 1], g: 4, w: [0, 0, 0, 4, 0], mn: 2, e: 'chest' },
    { n: '심해 뱀', c: '괴물', q: [2, 0, 1, 0], g: 4, w: [0, 0, 0, 4, 1], mn: 2, e: 'serpent' },
    { n: '쇳물 수로', c: '함정', q: [0, 2, 0, 0], g: 2, w: [0, 0, 0, 0, 3], mn: 1, e: 'flame', tr: 1 },
    { n: '대장장이의 금고', c: '보물', q: [0, 1, 0, 1], g: 4, w: [0, 0, 0, 1, 3], mn: 2, e: 'anvil' },
    { n: '불꽃 골렘', c: '괴물', q: [3, 0, 1, 0], g: 6, w: [0, 0, 0, 0, 3], mn: 3, e: 'golem' },
    { n: '심연의 군주', c: '우두머리', q: [3, 1, 1, 0], g: 10, w: [1, 1, 1, 1, 1], mn: 5, e: 'crown' },
  ];
  const RELICS = [
    { n: '수호의 부적', d: '탐험마다 처음 나온 해골 1개를 무시해요.', e: 'amulet' },
    { n: '탐욕의 잔', d: '귀환해서 전리품을 챙길 때 금화 +2.', e: 'cup' },
    { n: '검은 횃불', d: '횃불 면을 검 대신 쓸 수도 있어요.', e: 'torch' },
    { n: '도둑의 열쇠꾸러미', d: '모든 방의 열쇠 요구가 1 줄어요.', e: 'key' },
    { n: '망자의 투구', d: '해골 4개까지 버텨요(4개째에 도망).', e: 'helm' },
    { n: '거울 방패', d: '남는 방패 1개가 해골 2개를 막아요.', e: 'shield' },
    { n: '사냥꾼의 활', d: '열쇠 면을 검 대신 쓸 수도 있어요.', e: 'bow' },
    { n: '낡은 보물 지도', d: '방을 돌파할 때마다 보상 금화 +1.', e: 'map' },
    { n: '불꽃 망토', d: '함정·열기로 붙는 해골(방패가 없을 때 +1)을 받지 않아요.', e: 'cloak' },
    { n: '물의 정령 병', d: '밀물에 전리품이 떠내려가지 않고, 쉼터 샘에서 해골을 2개 지워요.', e: 'flask' },
    { n: '자석 반지', d: '한 굴림에 보물 면이 2개 이상이면 전리품 +1 더.', e: 'ring' },
    { n: '탐험가의 밧줄', d: '방에서 후퇴해도 전리품을 모두 챙겨요(보통은 절반).', e: 'rope' },
  ];
  const DUNGEONS = [
    { n: '무너진 묘지', d: '해골 병사와 망령이 많은 균형 잡힌 던전.' },
    { n: '거미 굴', d: '거미 둥지와 어둠 통로가 많아요. 횃불이 중요해요.' },
    { n: '잊힌 왕릉', d: '궤짝·금고·함정이 많아요. 열쇠와 방패가 중요해요.' },
    { n: '침수된 신전', d: '보물고와 샘이 많지만 「밀물」: 3층부터 방에 들어설 때마다 전리품 1이 떠내려가요.', hz: 'flood' },
    { n: '불타는 대장간', d: '함정과 골렘이 많고 「열기」: 한 방에서 5번째 굴림부터 방패가 하나도 없으면 해골 +1.', hz: 'heat' },
  ];
  const DG_ID = ['crypt', 'nest', 'tomb', 'flood', 'forge'];
  const GOALS = { g30: 30, g50: 50 };
  const MAXR = 25;

  /* ---------- 규칙 ---------- */
  const has = (s, seat, r) => s.rel[seat].indexOf(r) >= 0;
  const limitOf = (s, seat) => (has(s, seat, 4) ? 4 : 3);
  function newTurn(s) { s.ph = 'go'; s.dp = 0; s.lo = 0; s.sk = 0; s.am = 0; s.rm = null; s.dz = [0, 0, 0, 0, 0, 0]; s.rr = 0; }
  function init(players, opts) {
    const o = opts || {};
    let dg = DG_ID.indexOf(o.dg); if (dg < 0) dg = Math.floor(Math.random() * DUNGEONS.length);
    const goal = o.goal === 'r8' ? 0 : GOALS[o.goal] || 30;
    const s = { n: players.length, nm: players.map((p) => String(p.name || '').slice(0, 10)), dg, goal, mr: goal ? MAXR : 8, rd: 1, t: 0, gd: players.map(() => 0), rel: players.map(() => []), seq: 0, last: null, ov: 0 };
    newTurn(s);
    return s;
  }
  function actor(s) { return s.ov ? null : s.t; }
  function pickRoom(dg, dp) {
    let tot = 0; const c = [];
    ROOMS.forEach((r, i) => { if (dp >= r.mn && !(r.hl && dp < 2)) { tot += r.w[dg]; c.push([i, r.w[dg]]); } });
    let x = Math.random() * tot;
    for (const [i, w] of c) { x -= w; if (x < 0) return i; }
    return c[0][0];
  }
  function makeRoom(s, seat, i, dp) {
    const R = ROOMS[i], q = R.q.slice();
    const ex = Math.floor((dp - 1) / 3);
    if (ex > 0 && !R.hl) { let p = 0; for (let k = 1; k < 4; k++) if (q[k] > q[p]) p = k; q[p] += ex; }
    if (has(s, seat, 3)) q[3] = Math.max(0, q[3] - 1);
    while (q[0] + q[1] + q[2] + q[3] > 5) { let p = 0; for (let k = 1; k < 4; k++) if (q[k] > q[p]) p = k; q[p]--; }
    return { i, q, q0: q.slice(), g: R.g ? R.g + Math.floor((dp - 1) / 2) : 0 };
  }
  // 굴림 해석(apply와 AI 시뮬레이션이 같이 씀). c = {q, dz, sk, am, lo, rr, tr}; faces = 굴린 주사위 면(ix 순서)
  function resolve(c, rel, ix, faces) {
    const ev = ix.map(() => 0);
    const wild = rel.indexOf(2) >= 0, mirror = rel.indexOf(5) >= 0, amulet = rel.indexOf(0) >= 0, bow = rel.indexOf(6) >= 0, cloak = rel.indexOf(8) >= 0, magnet = rel.indexOf(10) >= 0;
    let gems = 0, shields = 0, tp = 0;
    // 1) 정확히 맞는 면 고정
    faces.forEach((f, j) => { if (f < 4 && c.q[f] > 0) { c.q[f]--; ev[j] = 1; } });
    // 2) 검은 횃불: 남는 횃불로 검 채우기
    if (wild) faces.forEach((f, j) => { if (!ev[j] && f === 2 && c.q[0] > 0) { c.q[0]--; ev[j] = 1; } });
    if (bow) faces.forEach((f, j) => { if (!ev[j] && f === 3 && c.q[0] > 0) { c.q[0]--; ev[j] = 1; } });
    faces.forEach((f, j) => { if (!ev[j] && f === 4) { gems++; ev[j] = 2; } if (!ev[j] && f === 1) shields++; });
    if (magnet && gems >= 2) gems++;
    const noShield = !faces.some((f) => f === 1);
    let ht = 0;
    if (c.tr && c.rr === 0 && noShield) tp = 1;
    if (c.hz === 'heat' && c.rr >= 4 && noShield) { tp++; ht = 1; }
    if (cloak) { tp = 0; ht = 0; }
    let block = shields * (mirror ? 2 : 1);
    faces.forEach((f, j) => {
      if (f !== 5) return;
      if (block > 0) { block--; ev[j] = 4; return; }
      if (amulet && !c.am) { c.am = 1; ev[j] = 5; return; }
      ev[j] = 3; c.sk++;
    });
    c.sk += tp; c.lo += gems; c.rr++;
    ix.forEach((d, j) => { c.dz[d] = faces[j] + (ev[j] === 1 ? 10 : ev[j] === 3 ? 20 : 0); });
    return { ev, tp, gems, ht };
  }
  const reqLeft = (q) => q[0] + q[1] + q[2] + q[3];
  const freeDice = (dz) => { const o = []; dz.forEach((v, i) => { if (v < 10) o.push(i); }); return o; };
  const rollFace = () => DIE[Math.floor(Math.random() * DIE.length)];

  function endTurn(s) {
    newTurn(s);
    s.t = (s.t + 1) % s.n;
    if (s.t === 0) {
      if ((s.goal && s.gd.some((g) => g >= s.goal)) || s.rd >= s.mr) { s.ov = 1; return; }
      s.rd++;
    }
  }
  function bankAmt(s, seat) { return s.lo + (has(s, seat, 1) && s.lo > 0 ? 2 : 0); }
  // per-seat result stats: [deepest floor, safe returns, escapes]
  function kst(s) { if (!s.ks) s.ks = s.gd.map(() => [0, 0, 0]); return s.ks; }
  function apply(s, seat, a) {
    if (s.ov || seat !== s.t || !a) throw new Error('not your turn');
    const L0 = { id: ++s.seq, s: seat };
    if (a.t === 'd') {
      if (s.ph !== 'go') throw new Error('not now');
      s.dp++;
      kst(s)[seat][0] = Math.max(s.ks[seat][0], s.dp);
      const i = pickRoom(s.dg, s.dp);
      s.rm = makeRoom(s, seat, i, s.dp); s.rr = 0; s.dz = [0, 0, 0, 0, 0, 0];
      L0.k = 'D';
      if (DUNGEONS[s.dg].hz === 'flood' && s.dp >= 3 && s.lo > 0 && !has(s, seat, 9)) { s.lo--; L0.fl = 1; }
      if (ROOMS[i].hl) { const hv = has(s, seat, 9) ? 2 : 1; L0.hl = Math.min(s.sk, hv); s.sk = Math.max(0, s.sk - hv); s.ph = 'go'; s.rm.cl = 1; }
      else if (reqLeft(s.rm.q) === 0) { const g = s.rm.g + (has(s, seat, 7) ? 1 : 0); s.lo += g; s.ph = 'go'; s.rm.cl = 1; L0.gl = g; }
      else s.ph = 'rm';
      s.last = L0; return s;
    }
    if (a.t === 'b') {
      if (s.ph !== 'go' || s.dp < 1) throw new Error('not now');
      const amt = bankAmt(s, seat);
      s.gd[seat] += amt;
      Object.assign(L0, { k: 'B', gl: amt, dp: s.dp }); kst(s)[seat][1]++;
      s.last = L0; endTurn(s); return s;
    }
    if (a.t === 'x') {
      if (s.ph !== 'rm') throw new Error('not now');
      const amt = has(s, seat, 11) ? s.lo : Math.floor(s.lo / 2);
      s.gd[seat] += amt;
      Object.assign(L0, { k: 'T', gl: amt, lo: s.lo });
      s.last = L0; endTurn(s); return s;
    }
    if (a.t === 'r') {
      if (s.ph !== 'rm') throw new Error('not now');
      const ix = freeDice(s.dz);
      if (!ix.length) throw new Error('no dice');
      const faces = ix.map(rollFace);
      const c = { q: s.rm.q, dz: s.dz, sk: s.sk, am: s.am, lo: s.lo, rr: s.rr, tr: ROOMS[s.rm.i].tr, hz: DUNGEONS[s.dg].hz };
      const r = resolve(c, s.rel[seat], ix, faces);
      s.sk = c.sk; s.am = c.am; s.lo = c.lo; s.rr = c.rr;
      Object.assign(L0, { k: 'R', ix, f: faces, ev: r.ev, tp: r.tp, ht: r.ht, res: 0 });
      if (s.sk >= limitOf(s, seat)) { kst(s)[seat][2]++; L0.res = 2; L0.lo = s.lo; s.last = L0; endTurn(s); return s; }
      if (reqLeft(s.rm.q) === 0) {
        L0.res = 1; L0.gl = s.rm.g + (has(s, seat, 7) ? 1 : 0); s.lo += L0.gl; s.rm.cl = 1; s.ph = 'go';
        if (ROOMS[s.rm.i].rl) {
          const own = s.rel[seat], pool = [];
          for (let k = 0; k < RELICS.length; k++) if (own.indexOf(k) < 0) pool.push(k);
          if (pool.length) { const k = pool[Math.floor(Math.random() * pool.length)]; if (own.length >= 2) own.shift(); own.push(k); L0.rl = k; }
        }
        s.last = L0; return s;
      }
      if (!freeDice(s.dz).length) { kst(s)[seat][2]++; L0.res = 3; L0.lo = s.lo; s.last = L0; endTurn(s); return s; }
      s.last = L0; return s;
    }
    throw new Error('bad action');
  }
  function result(s) {
    if (!s.ov) return null;
    const best = Math.max(...s.gd);
    const winners = s.gd.map((g, i) => (g === best ? i : -1)).filter((i) => i >= 0);
    const order = s.gd.map((g, i) => [g, i]).sort((a, b) => b[0] - a[0]);
    const ks = s.ks || s.gd.map(() => [0, 0, 0]);
    const stats = [{ label: '최대 층', values: ks.map((k) => k[0] + '층') }, { label: '무사 귀환', values: ks.map((k) => String(k[1])) },
      { label: '도망', values: ks.map((k) => String(k[2])) }, { label: '유물', values: s.rel.map((r) => String(r.length)) }];
    return { winners, stats, title: null, text: order.map(([g, i]) => ((s.nm && s.nm[i]) || (i + 1) + '번') + ' ' + g + '금화').join(' · ') };
  }

  /* ---------- AI (위험 계산) ---------- */
  function simRoom(q, dz, sk, am, rr, tr, rel, lim, lo, hz) {
    const c = { q: q.slice(), dz: dz.slice(), sk, am, lo, rr, tr, hz };
    for (let n = 0; n < 40; n++) {
      const ix = freeDice(c.dz);
      if (!ix.length) return null;
      resolve(c, rel, ix, ix.map(rollFace));
      if (c.sk >= lim) return null;
      if (reqLeft(c.q) === 0) return c;
    }
    return null;
  }
  // 한 층 더 내려갔다가 바로 귀환할 때의 기대 전리품
  function evDescend(s, seat, sims) {
    const rel = s.rel[seat], lim = limitOf(s, seat), bonus = has(s, seat, 1) ? 2 : 0, hz = DUNGEONS[s.dg].hz, map = has(s, seat, 7) ? 1 : 0;
    const lo0 = Math.max(0, s.lo - (hz === 'flood' && s.dp + 1 >= 3 && s.lo > 0 && !has(s, seat, 9) ? 1 : 0));
    let tot = 0;
    for (let k = 0; k < sims; k++) {
      const rm = makeRoom(s, seat, pickRoom(s.dg, s.dp + 1), s.dp + 1);
      const R = ROOMS[rm.i];
      if (R.hl) { tot += lo0 + bonus + (s.sk > 0 ? 1.5 : 0.3); continue; }
      const c = simRoom(rm.q, [0, 0, 0, 0, 0, 0], s.sk, s.am, 0, R.tr, rel, lim, lo0, hz);
      if (c) tot += c.lo + rm.g + map + bonus + (R.rl ? 4 : 0);
    }
    return tot / sims;
  }
  function evContinue(s, seat, sims) {
    const rel = s.rel[seat], lim = limitOf(s, seat), bonus = has(s, seat, 1) ? 2 : 0;
    let tot = 0;
    for (let k = 0; k < sims; k++) {
      const c = simRoom(s.rm.q, s.dz, s.sk, s.am, s.rr, ROOMS[s.rm.i].tr, rel, lim, s.lo, DUNGEONS[s.dg].hz);
      if (c) tot += c.lo + s.rm.g + (has(s, seat, 7) ? 1 : 0) + bonus;
    }
    return tot / sims;
  }
  // 점수 상황에 따른 욕심(필요한 만큼 더 모으기)
  function urge(s, seat) {
    const me = s.gd[seat], best = Math.max(...s.gd.filter((_, i) => i !== seat));
    const lastRound = s.goal ? s.gd.some((g) => g >= s.goal) || s.rd >= s.mr : s.rd >= s.mr;
    const need = s.goal && !lastRound ? s.goal - me : best - me + 1;
    return { need, lastRound };
  }
  function ai(s, seat, lv) {
    const bonus = has(s, seat, 1) ? 2 : 0;
    const lim = limitOf(s, seat);
    if (s.ph === 'go') {
      if (s.dp === 0) return { t: 'd' };
      const bank = s.lo + (s.lo > 0 ? bonus : 0);
      const u = urge(s, seat);
      if (lv === 1) {
        const p = s.sk >= lim - 1 ? 0.45 : s.lo >= 8 ? 0.5 : 0.8;
        return { t: Math.random() < p ? 'd' : 'b' };
      }
      if (u.lastRound && seat === s.n - 1 && bank < u.need) return { t: 'd' }; // 마지막 차례: 이길 때까지
      if (s.goal && !u.lastRound && bank >= u.need) return { t: 'b' };
      const ev = evDescend(s, seat, lv === 3 ? 260 : 60);
      const margin = lv === 3 ? 0.15 : (Math.random() - 0.5) * 4;
      return { t: ev > bank + margin ? 'd' : 'b' };
    }
    // 방 안
    if (lv === 1 || s.lo < 2) return { t: 'r' };
    const keep = has(s, seat, 11) ? s.lo : Math.floor(s.lo / 2);
    if (s.sk < lim - 1) return { t: 'r' };
    const ev = evContinue(s, seat, lv === 3 ? 200 : 50);
    return { t: ev + (lv === 2 ? 1 : 0) >= keep ? 'r' : 'x' };
  }
  function aiDelayFor(s, seat, lv) { return (s.ph === 'rm' ? 650 : 800) + (lv === 1 ? 200 : 0); }

  /* ---------- 그림 ---------- */
  const EMB = {
    sword: [['M12 1.5L14.2 4V15H9.8V4Z M5.5 15H18.5V17.2H5.5Z M10.9 17.2H13.1V21H10.9Z M9.6 21H14.4V23H9.6Z', 'f']],
    shield: [['M12 2L20.5 5V11C20.5 16.2 16.8 20.2 12 22.2C7.2 20.2 3.5 16.2 3.5 11V5Z M12 5V19.5C15.5 17.8 17.8 14.8 17.8 11V7Z', 'f']],
    torch: [['M12 1.5C15.4 5.6 16.4 8 15.6 10C15 11.6 13.6 12.4 12 12.4C10.4 12.4 9 11.6 8.4 10C7.6 8 8.6 5.6 12 1.5Z M12 6C13.3 7.8 13.6 9 13 10C12.7 10.6 12.4 10.8 12 10.8C11.6 10.8 11.3 10.6 11 10C10.4 9 10.7 7.8 12 6Z M8.6 13.2H15.4L13.6 22.5H10.4Z', 'f']],
    key: [['M7.5 3a5.5 5.5 0 1 1 0 11a5.5 5.5 0 1 1 0-11z M7.5 6.2a2.3 2.3 0 1 0 0 4.6a2.3 2.3 0 1 0 0-4.6z M12.5 7.6H22.5V9.9H12.5Z M19.2 9.9H21.6V13.4H19.2Z M15.6 9.9H18V12.4H15.6Z', 'f']],
    gem: [['M6.5 3H17.5L22 9L12 22L2 9Z M7.6 4.6L5 8.6H9.8Z M16.4 4.6L14.2 8.6H19Z M11 4.6L9.6 8.4H14.4L13 4.6Z', 'f']],
    skull: [['M12 1.8C6.8 1.8 3.6 5.4 3.6 10C3.6 13.2 5.2 15.3 7 16.4V20.4H17V16.4C18.8 15.3 20.4 13.2 20.4 10C20.4 5.4 17.2 1.8 12 1.8Z M8.7 8.2a2.3 2.3 0 1 1 0 4.6a2.3 2.3 0 1 1 0-4.6z M15.3 8.2a2.3 2.3 0 1 1 0 4.6a2.3 2.3 0 1 1 0-4.6z M12 13.4L13.2 15.8H10.8Z M9.6 17.6H10.8V20.4H9.6Z M13.2 17.6H14.4V20.4H13.2Z', 'f']],
    spider: [['M12 12L3 5 M12 12L2 11 M12 12L3 18 M12 12L21 5 M12 12L22 11 M12 12L21 18 M12 12L7 22 M12 12L17 22', 's'], ['M12 7a3 3 0 1 1 0 6a3 3 0 1 1 0-6z M12 11a4.2 5 0 1 1 0 10a4.2 5 0 1 1 0-10z', 'f']],
    chest: [['M3 10H21V20.5H3Z M3 9C3 5.4 6 4 12 4C18 4 21 5.4 21 9Z M10 11.5H14V16H10Z', 'f']],
    arrow: [['M2 12H16 M2 8.5L5.5 12L2 15.5', 's'], ['M15.5 7.5L22.5 12L15.5 16.5Z', 'f']],
    spikes: [['M2 20L5 9L8 20L11 6L14 20L17 9L20 20L22 20V22.5H2Z', 'f']],
    eye: [['M1.8 12C6 4.8 18 4.8 22.2 12C18 19.2 6 19.2 1.8 12Z M12 8.4a3.6 3.6 0 1 1 0 7.2a3.6 3.6 0 1 1 0-7.2z M12 10.6a1.4 1.4 0 1 0 0 2.8a1.4 1.4 0 1 0 0-2.8z', 'f']],
    drop: [['M12 2C16 8 19 11 19 15a7 7 0 0 1-14 0C5 11 8 8 12 2Z', 'f']],
    golem: [['M5 3.5H19V20.5H5Z M7.8 8.5H11V11.5H7.8Z M13 8.5H16.2V11.5H13Z M8 14.5H16V16.6H8Z', 'f']],
    crown: [['M3 17.5L1.8 6.5L8 10.8L12 3.5L16 10.8L22.2 6.5L21 17.5Z M3 19H21V21.5H3Z', 'f']],
    amulet: [['M6 2L12 9L18 2', 's'], ['M12 9.5L18 15.5L12 22L6 15.5Z M12 12.8L15 15.6L12 18.6L9 15.6Z', 'f']],
    cup: [['M4 3H20C20 9 16.8 12.5 13.2 13.2V18H17V21H7V18H10.8V13.2C7.2 12.5 4 9 4 3Z', 'f']],
    helm: [['M12 2C6.5 2 3.5 6 3.5 11V21H9V15H15V21H20.5V11C20.5 6 17.5 2 12 2Z M11 5H13V13H11Z', 'f']],
    wave: [['M2 8C5 5 7 5 9.5 8S14 11 16.5 8S20 5 22 8 M2 14C5 11 7 11 9.5 14S14 17 16.5 14S20 11 22 14 M2 20C5 17 7 17 9.5 20S14 23 16.5 20S20 17 22 20', 's']],
    serpent: [['M4 20C4 14 10 14 10 10C10 6 6 6 6 4 M10 10C10 14 16 14 16 18C16 20 18 21 20 20', 's'], ['M17 2.5a3.2 2.6 0 1 1 0 5.2a3.2 2.6 0 1 1 0-5.2z', 'f']],
    flame: [['M12 1.5C14 6 18.5 8 18.5 14A6.5 6.5 0 0 1 5.5 14C5.5 10.5 7.5 9 8.5 6.5C9.5 9 10.5 10 11.5 10C11.5 7 11 4.5 12 1.5Z M12 13C13.5 15 14.5 16 14.5 17.5A2.5 2.5 0 0 1 9.5 17.5C9.5 16 10.5 15 12 13Z', 'f']],
    anvil: [['M2 6H17C17 9 19.5 10 22 10V11.5C18 11.5 16 12.5 15 14H9C8 12 6 11 4 10.5Z M9 14H15V17H9Z M5.5 17H18.5V21H5.5Z', 'f']],
    bow: [['M6 2C15 6 15 18 6 22 M6 2V22 M4 12H21', 's'], ['M21 12L17.5 9.5V14.5Z', 'f']],
    map: [['M2 5L8 3L16 5L22 3V19L16 21L8 19L2 21Z M8 3V19 M16 5V21', 's']],
    cloak: [['M12 2C9.5 2 8 3.5 8 5.5L3 21H21L16 5.5C16 3.5 14.5 2 12 2Z M12 7L9.5 19H14.5Z', 'f']],
    flask: [['M9 2H15V4H14V9L19.5 19C20.3 20.5 19.3 22 17.6 22H6.4C4.7 22 3.7 20.5 4.5 19L10 9V4H9Z M7.5 15L6 18.5C5.8 19.2 6.1 19.6 6.8 19.6H17.2C17.9 19.6 18.2 19.2 18 18.5L16.5 15Z', 'f']],
    ring: [['M12 7.5a7.2 7.2 0 1 1 0 14.4a7.2 7.2 0 1 1 0-14.4z M12 10.2a4.5 4.5 0 1 0 0 9a4.5 4.5 0 1 0 0-9z M9 2H15L16.5 4.5L12 8L7.5 4.5Z', 'f']],
    rope: [['M12 3a4 4 0 1 1 0 8a4 4 0 1 1 0-8z M12 11C8 13 8 16 12 17S16 20 12 22', 's']],
    door: [['M4 22V9C4 4.6 7.6 2 12 2C16.4 2 20 4.6 20 9V22Z M7 20V9.5C7 6.6 9.2 4.8 12 4.8C14.8 4.8 17 6.6 17 9.5V20Z', 'f']],
  };
  const FACE_E = ['sword', 'shield', 'torch', 'key', 'gem', 'skull'];
  const FACE_C = ['#d8d2c4', '#8fb3c9', '#f0a04b', '#d9b45a', '#6fd3a8', '#e04a3f'];
  const svgOf = (e, col) => '<svg viewBox="0 0 24 24" width="100%" height="100%">' + EMB[e].map(([d, m]) => m === 's'
    ? '<path d="' + d + '" fill="none" stroke="' + (col || 'currentColor') + '" stroke-width="2" stroke-linecap="round"/>'
    : '<path d="' + d + '" fill="' + (col || 'currentColor') + '" fill-rule="evenodd"/>').join('') + '</svg>';
  const P2 = {};
  function emb(ctx, e, x, y, size, col) {
    const list = EMB[e]; if (!list) return;
    if (!P2[e]) P2[e] = list.map(([d, m]) => [new Path2D(d), m]);
    ctx.save(); ctx.translate(x - size / 2, y - size / 2); ctx.scale(size / 24, size / 24);
    for (const [p, m] of P2[e]) {
      if (m === 's') { ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.stroke(p); }
      else { ctx.fillStyle = col; ctx.fill(p, 'evenodd'); }
    }
    ctx.restore();
  }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  const ROOM_C = { '괴물': '#9b2f2a', '통로': '#a36a2a', '보물': '#c9a24a', '함정': '#6f7d8c', '유물': '#7d5cc4', '쉼터': '#b3333d', '우두머리': '#d4443a' };

  function mount(root, api) {
    let st = null, ds = null, shown = 0, anim = null, pending = false, time = 0, shake = 0;
    const sp = () => Math.max(0.1, (L.debug && L.debug.speed) || 1);
    const wrap = L.h('div', { style: { position: 'absolute', inset: '0', display: 'flex', flexDirection: 'column', gap: '6px', padding: '6px 8px 8px', background: 'radial-gradient(120% 80% at 50% 30%, #231c1a 0%, #0f0c0b 75%)' } });
    const bar = L.h('div', { class: 'dq-players', style: { flex: 'none', display: 'grid', gap: '4px' } });
    const cvBox = L.h('div', { class: 'dq-cv', style: { flex: '1 1 auto', minHeight: '260px', position: 'relative' } });
    const hint = L.h('div', { style: { flex: 'none', minHeight: '20px', textAlign: 'center', fontSize: '13px', fontWeight: 700, color: '#b9ab94' } });
    const b1 = L.h('button', { class: 'btn', 'data-action': 'back', style: { flex: '1 1 0', minHeight: '54px', fontSize: '15px', lineHeight: '1.15' }, onclick: () => press(1) });
    const b2 = L.h('button', { class: 'btn primary', 'data-action': 'go', style: { flex: '1.25 1 0', minHeight: '54px', fontSize: '16px', lineHeight: '1.15' }, onclick: () => press(2) });
    const btns = L.h('div', { class: 'dq-btns', style: { flex: 'none', display: 'flex', gap: '8px' } }, b1, b2);
    wrap.append(bar, cvBox, hint, btns);
    root.append(wrap);
    const cv = U.canvas(cvBox), ctx = cv.ctx;

    const setBusy = (b) => api.setBusy(b);
    const mine = () => st && !st.ov && api.canAct(st.t);
    const ready = () => mine() && !anim && !pending;
    function send(a) { pending = true; api.act(a); setTimeout(() => { if (pending) { pending = false; refresh(); } }, 3000); refresh(); }
    function press(k) {
      if (!ready()) return;
      api.buzz(12);
      if (st.ph === 'go') {
        if (k === 2) { api.sfx('whoosh'); send({ t: 'd' }); }
        else if (st.dp > 0) { api.sfx('chip'); send({ t: 'b' }); }
      } else {
        if (k === 2) { api.sfx('roll'); send({ t: 'r' }); }
        else send({ t: 'x' });
      }
    }
    let offK = null;
    if (api.input) offK = api.input.on((type, id) => { if (type !== 'down') return; if (id === 'go') press(2); if (id === 'back') press(1); });

    function refresh() {
      const s = ds || st; if (!s) return;
      bar.innerHTML = '';
      bar.style.gridTemplateColumns = 'repeat(' + Math.min(3, s.n) + ', minmax(0,1fr))';
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i], on = i === s.t && !s.ov;
        const rel = L.h('span', { style: { display: 'inline-flex', gap: '2px', marginLeft: 'auto', flex: 'none' } });
        s.rel[i].forEach((k) => { const ic = L.h('span', { style: { width: '15px', height: '15px', display: 'inline-block', color: '#b79cf0' } }); ic.innerHTML = svgOf(RELICS[k].e); rel.append(ic); });
        bar.append(L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', minWidth: '0', padding: '5px 7px', borderRadius: '9px', background: on ? 'rgba(201,162,74,.16)' : 'rgba(255,255,255,.04)', border: '1px solid ' + (on ? '#c9a24a' : 'rgba(255,255,255,.07)') } },
          L.h('span', { class: 'dot', style: { '--c': p.color, flex: 'none' } }),
          L.h('span', { style: { fontSize: '12px', fontWeight: 700, color: '#e8dcc6', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', minWidth: '0' }, text: p.name }),
          L.h('b', { class: 'mono', style: { fontSize: '13px', color: '#e3ae45', flex: 'none' }, text: String(s.gd[i]) }), rel));
      }
      const m = mine();
      btns.style.visibility = m ? 'visible' : 'hidden';
      hint.textContent = '';
      if (st.ov) { hint.textContent = '탐험 끝'; return; }
      if (!m) { hint.textContent = api.players[st.t].name + ' 탐험 중…'; return; }
      const lim = limitOf(st, st.t);
      const dis = !ready();
      if (st.ph === 'go') {
        b2.innerHTML = st.dp === 0 ? '던전 입장 ▼' : '더 깊이 ▼<br><small style="opacity:.75">지하 ' + (st.dp + 1) + '층</small>';
        b1.innerHTML = '귀환 ⌂<br><small style="opacity:.8">금화 +' + bankAmt(st, st.t) + ' 챙기기</small>';
        b1.style.visibility = st.dp > 0 ? 'visible' : 'hidden';
        hint.textContent = st.dp === 0 ? '던전에 들어가 보물을 찾으세요' : '해골 ' + st.sk + '/' + lim + ' · 더 내려갈까요, 돌아갈까요?';
        hint.style.color = st.sk >= lim - 1 && st.dp > 0 ? '#e66a5a' : '#b9ab94';
      } else {
        b2.innerHTML = '주사위 굴리기 (' + freeDice(st.dz).length + ')';
        b1.innerHTML = '후퇴<br><small style="opacity:.8">금화 +' + Math.floor(st.lo / 2) + ' (반만)</small>';
        b1.style.visibility = 'visible';
        hint.textContent = '방의 요구를 모두 채우면 돌파!';
        hint.style.color = '#b9ab94';
      }
      b1.disabled = b2.disabled = dis;
    }

    /* ---- 캔버스 ---- */
    let bg = null;
    function buildBg() {
      const w = cv.w, h = cv.h;
      bg = document.createElement('canvas'); bg.width = Math.round(w * cv.dpr); bg.height = Math.round(h * cv.dpr);
      const b = bg.getContext('2d'); b.scale(cv.dpr, cv.dpr);
      const g = b.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#1d1715'); g.addColorStop(1, '#0d0a09');
      rr(b, 0, 0, w, h, 14); b.fillStyle = g; b.fill(); b.save(); b.clip();
      // 돌벽
      let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
      b.strokeStyle = 'rgba(0,0,0,.45)'; b.lineWidth = 1.5;
      const bh = 22;
      for (let y = 0, row = 0; y < h; y += bh, row++) {
        b.beginPath(); b.moveTo(0, y); b.lineTo(w, y); b.stroke();
        for (let x = (row % 2) * 24 - 24; x < w; x += 48) { b.beginPath(); b.moveTo(x, y); b.lineTo(x, y + bh); b.stroke(); b.fillStyle = 'rgba(255,240,220,' + (rnd() * 0.025).toFixed(3) + ')'; b.fillRect(x + 1, y + 1, 46, bh - 2); }
      }
      const v = b.createRadialGradient(w / 2, h * 0.35, 20, w / 2, h * 0.4, Math.max(w, h) * 0.75);
      v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(1, 'rgba(0,0,0,.7)'); b.fillStyle = v; b.fillRect(0, 0, w, h);
      b.restore();
    }
    cv.onresize = () => { buildBg(); };
    buildBg();

    function geo() {
      const w = cv.w, h = cv.h;
      const trayH = Math.min(h * 0.36, 200);
      const ds = Math.min(62, (w - 60) / 3 * 0.72, (trayH - 30) / 2 * 0.8);
      return { w, h, roomH: h - trayH, trayY: h - trayH, trayH, ds };
    }
    function diePos(G, i) {
      const col = i % 3, row = Math.floor(i / 3);
      const gap = G.ds * 0.4, tw = G.ds * 3 + gap * 2;
      return { x: G.w / 2 - tw / 2 + G.ds / 2 + col * (G.ds + gap), y: G.trayY + G.trayH / 2 - (G.ds + gap * 0.6) / 2 + row * (G.ds + gap * 0.6) + 8 };
    }
    function drawDie(x, y, sz, face, status, glow, rot) {
      ctx.save(); ctx.translate(x, y); if (rot) ctx.rotate(rot);
      const r = sz * 0.2;
      ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 8; ctx.shadowOffsetY = 3;
      const g = ctx.createLinearGradient(0, -sz / 2, 0, sz / 2);
      if (status === 2) { g.addColorStop(0, '#3a1311'); g.addColorStop(1, '#1e0807'); }
      else { g.addColorStop(0, '#e9e0cd'); g.addColorStop(1, '#b7aa90'); }
      rr(ctx, -sz / 2, -sz / 2, sz, sz, r); ctx.fillStyle = g; ctx.fill();
      ctx.shadowColor = 'transparent';
      ctx.lineWidth = status === 1 ? 3 : 1.5;
      ctx.strokeStyle = status === 1 ? '#e3ae45' : status === 2 ? '#a3241d' : 'rgba(40,25,10,.6)'; ctx.stroke();
      if (glow) { ctx.lineWidth = 3; ctx.strokeStyle = glow; ctx.globalAlpha = 0.9; rr(ctx, -sz / 2 - 3, -sz / 2 - 3, sz + 6, sz + 6, r + 3); ctx.stroke(); ctx.globalAlpha = 1; }
      if (face >= 0) {
        const col = status === 2 ? '#e04a3f' : face === 5 ? '#7a1712' : face === 0 ? '#3b3530' : face === 1 ? '#2d4c63' : face === 2 ? '#a3501a' : face === 3 ? '#7a5a16' : '#16765a';
        emb(ctx, FACE_E[face], 0, 0, sz * 0.62, col);
      }
      ctx.restore();
    }

    function draw() {
      const s = ds || st; if (!s) return;
      const G = geo();
      cv.clear();
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 10, (Math.random() - 0.5) * shake * 10);
      if (bg) ctx.drawImage(bg, 0, 0, G.w, G.h);
      const lim = limitOf(s, s.t);
      // 상단 정보
      ctx.textBaseline = 'middle';
      ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#9c8e78'; ctx.textAlign = 'left';
      ctx.fillText(DUNGEONS[s.dg].n + ' · ' + (s.goal ? '목표 ' + s.goal : s.mr + '라운드') + ' · ' + s.rd + '라운드', 12, 16);
      ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#e8dcc6';
      ctx.fillText(s.dp ? '지하 ' + s.dp + '층' : '던전 입구', 12, 38);
      // 전리품
      emb(ctx, 'gem', 20, 62, 18, '#6fd3a8');
      ctx.font = '700 17px "IBM Plex Mono", monospace'; ctx.fillStyle = '#e3ae45'; ctx.fillText(String(s.lo), 33, 63);
      ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#9c8e78'; ctx.fillText('전리품', 33 + 14 + 8 * String(s.lo).length, 63);
      // 해골 소켓
      for (let k = 0; k < lim; k++) {
        const x = G.w - 22 - (lim - 1 - k) * 30, y = 26;
        const on = k < s.sk;
        ctx.beginPath(); ctx.arc(x, y, 13, 0, 7); ctx.fillStyle = on ? 'rgba(160,30,25,.55)' : 'rgba(255,255,255,.05)'; ctx.fill();
        ctx.lineWidth = 1.5; ctx.strokeStyle = on ? '#e04a3f' : 'rgba(255,255,255,.15)'; ctx.stroke();
        emb(ctx, 'skull', x, y, 18, on ? '#ffb4a8' : 'rgba(255,255,255,.18)');
      }
      ctx.textAlign = 'right'; ctx.font = '600 11px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#9c8e78';
      ctx.fillText(s.sk >= lim - 1 && s.dp ? '한 개만 더 나오면 도망!' : '해골 ' + lim + '개면 도망', G.w - 10, 52);
      // 방
      const cx = G.w / 2, top = 76, rh = G.roomH - top - 6;
      let slide = 0;
      if (anim && anim.k === 'D') slide = Math.max(0, 1 - anim.t / anim.dur);
      ctx.save(); ctx.globalAlpha = 1 - slide; ctx.translate(0, slide * 30);
      const dh = Math.max(60, Math.min(rh - 92, G.w * 0.5 * 1.15)), dw = dh / 1.15;
      const dy = top + 4;
      const flick = 0.8 + 0.2 * Math.sin(time * 9) * Math.sin(time * 5.3);
      const rm = s.rm, R = rm ? ROOMS[rm.i] : null;
      const tone = R ? ROOM_C[R.c] : '#6a5a48';
      // 문틀
      const grd = ctx.createRadialGradient(cx, dy + dh * 0.55, 4, cx, dy + dh * 0.55, dw * 0.8);
      grd.addColorStop(0, R ? 'rgba(' + (R.c === '보물' ? '201,162,74' : R.c === '유물' ? '125,92,196' : '170,50,40') + ',' + (0.35 * flick).toFixed(2) + ')' : 'rgba(240,160,75,' + (0.25 * flick).toFixed(2) + ')');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = grd; ctx.fillRect(cx - dw, dy - 10, dw * 2, dh + 20);
      emb(ctx, 'door', cx, dy + dh / 2, Math.max(dw, dh), '#3a302a');
      ctx.save(); ctx.beginPath(); ctx.ellipse(cx, dy + dh * 0.62, dw * 0.3, dh * 0.34, 0, 0, 7); ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fill(); ctx.restore();
      if (R) emb(ctx, R.e, cx, dy + dh * 0.58, Math.min(dw, dh) * 0.42, R.hl ? '#c23a40' : tone === '#c9a24a' ? '#e3c26a' : '#d8cdb8');
      else { emb(ctx, 'torch', cx - dw * 0.62, dy + dh * 0.45, 26, 'rgba(240,160,75,' + flick.toFixed(2) + ')'); emb(ctx, 'torch', cx + dw * 0.62, dy + dh * 0.45, 26, 'rgba(240,160,75,' + flick.toFixed(2) + ')'); emb(ctx, 'skull', cx, dy + dh * 0.6, Math.min(dw, dh) * 0.3, '#6a5a48'); }
      // 이름·태그
      const ny = dy + dh + 16;
      ctx.textAlign = 'center';
      ctx.font = '22px "Black Han Sans", sans-serif'; ctx.fillStyle = '#efe3cb';
      ctx.fillText(R ? R.n : '어둠 속 계단', cx, ny);
      ctx.font = '600 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = R ? tone : '#9c8e78';
      const tag = R ? (R.c + (R.hl ? ' · 해골 1개 회복' : R.rl ? ' · 유물 + 금화 ' + rm.g : ' · 보상 금화 ' + rm.g) + (R.tr ? ' · 첫 굴림에 방패 없으면 해골 +1' : '') + (DUNGEONS[s.dg].hz === 'heat' && !R.hl ? ' · 5번째 굴림부터 열기' : '')) : '내려가면 방이 나타나요';
      ctx.fillText(tag, cx, ny + 20);
      // 요구 소켓
      if (rm && !R.hl) {
        const need = []; for (let f = 0; f < 4; f++) for (let k = 0; k < rm.q0[f]; k++) need.push([f, k < rm.q0[f] - rm.q[f]]);
        const sz = 30, gap = 6, tw = need.length * (sz + gap) - gap;
        need.forEach(([f, ok], j) => {
          const x = cx - tw / 2 + j * (sz + gap) + sz / 2, y = ny + 46;
          rr(ctx, x - sz / 2, y - sz / 2, sz, sz, 7); ctx.fillStyle = ok ? 'rgba(201,162,74,.28)' : 'rgba(0,0,0,.45)'; ctx.fill();
          ctx.lineWidth = 1.5; ctx.strokeStyle = ok ? '#e3ae45' : 'rgba(255,255,255,.18)'; ctx.stroke();
          emb(ctx, FACE_E[f], x, y, 20, ok ? FACE_C[f] : 'rgba(216,205,184,.35)');
        });
        if (rm.cl) { ctx.save(); ctx.translate(cx, dy + dh * 0.5); ctx.rotate(-0.2); ctx.font = '30px "Black Han Sans", sans-serif'; ctx.fillStyle = 'rgba(227,174,69,.92)'; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 4; ctx.strokeText('돌파!', 0, 0); ctx.fillText('돌파!', 0, 0); ctx.restore(); }
      }
      ctx.restore();
      // 주사위 받침
      rr(ctx, 10, G.trayY + 4, G.w - 20, G.trayH - 10, 14);
      const tg = ctx.createLinearGradient(0, G.trayY, 0, G.h); tg.addColorStop(0, '#2a1f1a'); tg.addColorStop(1, '#170f0c');
      ctx.fillStyle = tg; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#4a3626'; ctx.stroke();
      const showDice = s.ph === 'rm' || (anim && anim.k === 'R') || (s.rm && s.rm.cl && !ROOMS[s.rm.i].hl);
      for (let i = 0; i < ND; i++) {
        const p = diePos(G, i);
        let v = s.dz[i], face = v % 10, status = Math.floor(v / 10), glow = null, rot = 0, sz = G.ds, yy = p.y;
        if (!showDice || (s.rr === 0 && !(anim && anim.k === 'R'))) face = -1;
        if (anim && anim.k === 'R') {
          const j = anim.L.ix.indexOf(i);
          if (j >= 0) {
            const tt = anim.t / anim.roll;
            if (tt < 1) { face = Math.floor((time * 18 + i * 3) % 6); status = 0; rot = Math.sin(time * 20 + i) * 0.5 * (1 - tt); yy -= Math.abs(Math.sin(tt * Math.PI * 2.5)) * 22 * (1 - tt); }
            else {
              const ev = anim.L.ev[j];
              face = anim.L.f[j]; status = ev === 1 ? 1 : ev === 3 ? 2 : 0;
              glow = ev === 2 ? '#6fd3a8' : ev === 3 ? '#e04a3f' : ev === 4 ? '#8fb3c9' : ev === 5 ? '#b79cf0' : null;
              const pop = Math.max(0, 1 - (anim.t - anim.roll) * 4 * sp());
              sz *= 1 + pop * 0.15;
            }
          }
        }
        drawDie(p.x, yy, sz, face, status, glow, rot);
        if (anim && anim.k === 'R' && anim.t >= anim.roll) {
          const j = anim.L.ix.indexOf(i);
          if (j >= 0) {
            const ev = anim.L.ev[j], lab = ev === 2 ? '+1' : ev === 4 ? '막음' : ev === 5 ? '부적' : '';
            if (lab) { ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = ev === 2 ? '#6fd3a8' : ev === 4 ? '#8fb3c9' : '#b79cf0'; ctx.fillText(lab, p.x, p.y - G.ds / 2 - 10 - (anim.t - anim.roll) * 20); }
          }
        }
      }
      if (!showDice) {
        ctx.fillStyle = 'rgba(10,6,5,.55)'; rr(ctx, 10, G.trayY + 4, G.w - 20, G.trayH - 10, 14); ctx.fill();
        ctx.textAlign = 'center'; ctx.font = '700 14px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#b9ab94';
        ctx.fillText(s.dp === 0 ? '주사위 ' + ND + '개로 방을 돌파해요' : '다음 방으로 가거나 귀환하세요', G.w / 2, G.trayY + G.trayH / 2);
      }
      // 큰 알림
      if (anim && anim.msg && anim.t > (anim.k === 'R' ? anim.roll : 0)) {
        const a = Math.min(1, (anim.t - (anim.k === 'R' ? anim.roll : 0)) * 5 * sp());
        ctx.fillStyle = 'rgba(0,0,0,' + (0.55 * a).toFixed(2) + ')'; ctx.fillRect(0, G.h * 0.36, G.w, 74);
        ctx.textAlign = 'center'; ctx.globalAlpha = a;
        ctx.font = '28px "Black Han Sans", sans-serif'; ctx.fillStyle = anim.mc; ctx.fillText(anim.msg, G.w / 2, G.h * 0.36 + 28);
        ctx.font = '600 13px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#e8dcc6'; ctx.fillText(anim.sub || '', G.w / 2, G.h * 0.36 + 56);
        ctx.globalAlpha = 1;
      }
      if (anim && anim.red) { ctx.fillStyle = 'rgba(180,20,15,' + (0.35 * Math.max(0, 1 - anim.t / anim.dur)).toFixed(2) + ')'; ctx.fillRect(0, 0, G.w, G.h); }
      ctx.restore();
    }

    function startAnim(s, prev) {
      const Lt = s.last, nm = api.players[Lt.s] ? api.players[Lt.s].name : '';
      const k = Lt.k;
      const a = { k, L: Lt, t: 0, roll: 0, dur: 0.5, after: s };
      if (k === 'R') {
        a.roll = 0.7; a.dur = 1.15; ds = prev || s;
        if (Lt.res === 2 || Lt.res === 3) { a.msg = Lt.res === 3 ? '갇혔다! 도망쳐요' : '해골의 저주! 도망쳐요'; a.sub = '전리품 ' + Lt.lo + '을(를) 잃었어요'; a.mc = '#e04a3f'; a.dur = 2.0; a.bust = 1; }
        else if (Lt.res === 1) { a.msg = '돌파!'; a.sub = '금화 +' + Lt.gl + (Lt.rl != null ? ' · 유물 「' + RELICS[Lt.rl].n + '」' : ''); a.mc = '#e3ae45'; a.dur = 1.6; }
        else if (Lt.ht) { a.msg = '열기!'; a.sub = '방패가 없어 해골 +' + Lt.tp; a.mc = '#ff8a3c'; a.dur = 1.6; }
        else if (Lt.tp) { a.msg = '함정 발동!'; a.sub = '방패가 없어 해골 +1'; a.mc = '#e66a5a'; a.dur = 1.6; }
      } else if (k === 'D') { a.dur = 0.45; if (s.rm && ROOMS[s.rm.i].hl) { a.msg = '핏빛 샘'; a.sub = Lt.hl ? '해골 ' + Lt.hl + '개가 사라졌어요' : '마셔도 아무 일 없어요'; a.mc = '#e66a5a'; a.dur = 1.3; }
        else if (Lt.fl) { a.msg = '밀물!'; a.sub = '전리품 1이 떠내려갔어요'; a.mc = '#5ab4e6'; a.dur = 1.3; } }
      else if (k === 'B') { a.msg = '무사 귀환'; a.sub = nm + ' 금화 +' + Lt.gl; a.mc = '#e3ae45'; a.dur = 1.3; ds = prev || s; }
      else if (k === 'T') { a.msg = '후퇴'; a.sub = '전리품 반만 챙김 · 금화 +' + Lt.gl; a.mc = '#b9ab94'; a.dur = 1.2; ds = prev || s; }
      anim = a;
      if (k !== 'R') { if (k === 'D') { ds = s; api.sfx('whoosh'); } else api.sfx(k === 'B' ? 'win' : 'thud'); }
      else api.sfx('roll');
      setBusy(true);
    }
    function animEvents(a, t0, t1) {
      if (a.k === 'R' && t0 < a.roll && t1 >= a.roll) {
        const ev = a.L.ev;
        if (a.bust) { api.sfx('lose'); api.buzz(60); shake = L.fx(); a.red = 1; }
        else if (a.L.res === 1) { api.sfx('win'); api.buzz(25); }
        else if (ev.indexOf(3) >= 0 || a.L.tp) { api.sfx('hit'); api.buzz(30); shake = 0.6 * L.fx(); }
        else if (ev.indexOf(1) >= 0) api.sfx('tick');
        if (ev.indexOf(2) >= 0) api.sfx('chip');
        if (!a.bust && a.L.res !== 1) ds = a.after;
      }
    }
    const stopLoop = U.loop((dt) => {
      time += dt;
      if (shake > 0) shake = Math.max(0, shake - dt * 2.5);
      if (anim) {
        const t0 = anim.t; anim.t += dt * sp();
        animEvents(anim, t0, anim.t);
        if (anim.k === 'R' && anim.L.res === 1 && t0 < anim.roll && anim.t >= anim.roll) ds = anim.after;
        if (anim.t >= anim.dur) { ds = anim.after; anim = null; setBusy(false); refresh(); }
      }
      draw();
    });

    return {
      update(s, prev) {
        st = s; pending = false;
        if (s.last && s.last.id !== shown) {
          const first = !shown; shown = s.last.id;
          if (!first && prev && prev !== s) startAnim(s, prev); else ds = s;
        } else if (!anim) ds = s;
        refresh();
      },
      destroy() { stopLoop(); if (offK) offK(); cv.destroy(); setBusy(false); wrap.remove(); },
    };
  }

  /* ---------- 도감 ---------- */
  const codex = [
    { h: '주사위 면', p: ['주사위 6개, 각 주사위는 8면이에요: 검 2 · 방패 1 · 횃불 1 · 열쇠 1 · 보물 2 · 해골 1.'],
      rows: [0, 1, 2, 3, 4, 5].map((f) => ({ icon: svgOf(FACE_E[f], FACE_C[f]), name: FN[f], tag: (DIE.filter((x) => x === f).length) + '/8', desc: FDESC[f] })) },
    { h: '방', p: ['요구는 지하 4층·7층…마다 가장 많은 기호가 1개씩 늘고(최대 5개), 보상은 2층마다 +1이에요.'],
      rows: ROOMS.map((r) => ({ icon: svgOf(r.e, ROOM_C[r.c]), name: r.n, tag: r.c + ' · ' + r.mn + '층부터',
        desc: (r.hl ? '들어서면 해골 1개가 사라져요.' : '요구: ' + r.q.map((v, f) => (v ? FN[f] + ' ' + v : '')).filter(Boolean).join(' · ') + ' · 보상 금화 ' + r.g + (r.rl ? ' + 유물 1개' : '')) + (r.tr ? ' · 첫 굴림에 방패가 하나도 없으면 해골 +1.' : '') +
          ' · 자주 나오는 곳: ' + DUNGEONS.map((d, i) => [d.n, r.w[i]]).sort((a, b) => b[1] - a[1])[0][0] })) },
    { h: '유물', p: ['유물 성소를 돌파하면 12가지 중 하나를 얻어요(이 판에서만). 최대 2개까지 들고, 3번째를 얻으면 가장 오래된 것을 버려요.'],
      rows: RELICS.map((r) => ({ icon: svgOf(r.e, '#b79cf0'), name: r.n, tag: '유물', desc: r.d })) },
    { h: '던전', p: ['설정의 「던전」에서 고르거나 무작위(기본)로 정해져요. 던전마다 잘 나오는 방이 달라요.'], rows: DUNGEONS.map((d, di) => ({ icon: svgOf(d.hz === 'flood' ? 'wave' : d.hz === 'heat' ? 'flame' : 'door', '#a38a6a'), name: d.n, tag: d.hz ? '던전 · 위험' : '던전', desc: d.d + ' 자주 나오는 방: ' + ROOMS.map((r) => [r.n, r.w[di]]).sort((x, y) => y[1] - x[1]).slice(0, 3).map((x) => x[0]).join(', ') + '.' })) },
  ];

  L.register({
    id: 'dicequest', name: '보물 사냥 주사위 모험', tag: '운 시험 던전', cat: '보드',
    tint: '#4a1814',
    icon: '<path d="M10 50V26C10 15 18 8 28 8C38 8 46 15 46 26V50Z" fill="none" stroke="currentColor" stroke-width="3"/><rect x="17" y="30" width="16" height="16" rx="3" fill="currentColor" transform="rotate(-12 25 38)"/><circle cx="21" cy="35" r="1.8" fill="#4a1814"/><circle cx="28" cy="40" r="1.8" fill="#4a1814"/><path d="M38 30c-3 0-5 2-5 5 0 2 1 3 2 3.5V41h6v-2.5c1-.5 2-1.5 2-3.5 0-3-2-5-5-5z" fill="currentColor" opacity=".8"/>',
    blurb: '주사위로 던전의 방을 하나씩 돌파하며 보물을 모아요. 더 내려갈수록 보물은 커지지만, 해골이 3개 나오면 전리품을 다 잃고 도망쳐요!',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 3, aiDelay: 800,
    options: [
      { id: 'goal', label: '승리 조건', tip: '어떻게 이기는지.', choices: [{ v: 'g30', label: '금화 30 먼저' }, { v: 'g50', label: '금화 50 먼저' }, { v: 'r8', label: '8라운드 최다', tip: '8라운드 뒤 금화가 가장 많은 사람.' }], def: 'g30' },
      { id: 'dg', label: '던전', choices: [{ v: 'rand', label: '무작위' }, { v: 'crypt', label: '무너진 묘지' }, { v: 'nest', label: '거미 굴' }, { v: 'tomb', label: '잊힌 왕릉' }, { v: 'flood', label: '침수된 신전' }, { v: 'forge', label: '불타는 대장간' }], def: 'rand' },
    ],
    quick: [
      '내 차례에 던전으로 내려가 주사위를 굴려 방의 요구(검·방패·횃불·열쇠)를 채우면 돌파, 보물을 얻어요.',
      '방을 돌파할 때마다 「더 깊이」 내려가거나 「귀환」해서 전리품을 금화로 챙겨요.',
      '이번 탐험에서 해골이 3개 나오면 도망 — 전리품을 모두 잃어요. 목표 금화를 먼저 모으면 승리!',
    ],
    rules: [
      { h: '목표', p: ['금화를 모아요. 설정한 목표(기본 30)에 누가 닿으면 그 라운드를 끝까지 하고, 금화가 가장 많은 사람이 이겨요.', '「8라운드 최다」는 8라운드 뒤 금화가 가장 많은 사람이 이겨요.'] },
      { h: '차례에 할 일', p: [
        '「던전 입장」을 누르면 지하 1층 방이 나타나요. 방마다 필요한 기호(예: 검 2개)가 있어요.',
        '「주사위 굴리기」: 아직 안 쓴 주사위를 모두 굴려요. 필요한 기호가 나온 주사위는 그 방에 고정돼요.',
        '보물 면은 바로 전리품 +1. 해골 면은 해골 +1(그 방에서 그 주사위는 못 씀).',
        '필요한 기호를 다 채우면 돌파! 보상 금화가 전리품에 더해지고 주사위 6개가 모두 돌아와요.',
        '그다음 「더 깊이」(다음 층 방) 또는 「귀환」(전리품을 금화로 챙기고 차례 끝)을 골라요.',
        '방 안에서 「후퇴」하면 전리품의 반만 챙기고 차례가 끝나요.'] },
      { h: '해골과 방패', p: [
        '해골은 한 번의 탐험 동안 계속 쌓여요. 3개가 되면 도망쳐서 이번 전리품을 모두 잃어요.',
        '방에 필요 없는 방패가 나오면 같은 굴림의 해골 1개를 막아 줘요.',
        '함정 방은 첫 굴림에 방패가 하나도 없으면 해골 +1. 굴릴 주사위가 하나도 안 남아도 도망이에요.',
        '핏빛 샘(2층부터)을 만나면 해골 1개가 사라져요.'] },
      { h: '던전 5곳', p: [
        '무너진 묘지 · 거미 굴 · 잊힌 왕릉 · 침수된 신전 · 불타는 대장간. 던전마다 잘 나오는 방이 달라요.',
        '침수된 신전 「밀물」: 지하 3층부터 방에 들어설 때마다 전리품 1이 떠내려가요. 대신 보물고와 샘이 많아요.',
        '불타는 대장간 「열기」: 한 방에서 5번째 굴림부터, 굴린 주사위에 방패가 하나도 없으면 해골 +1. 함정도 많아서 방패가 아주 중요해요.'] },
      { h: '깊이와 유물', p: [
        '깊이 내려갈수록 방이 어려워지고 보상이 커져요. 5층부터는 심연의 군주(금화 10+)가 나올 수 있어요.',
        '유물 성소를 돌파하면 유물 12가지 중 하나를 얻어요. 이 판에서만 쓰이고 최대 2개까지 들 수 있어요. 자세한 건 「📖 도감」.'] },
      { h: '예시', p: ['해골 병사(검 2) 방에서 굴림: 검·보물·해골·방패·횃불·열쇠 → 검 1개 고정, 전리품 +1, 방패가 해골을 막아요. 다시 굴려 검이 하나 더 나오면 돌파, 금화 +2!'] },
      { h: '조작', p: ['아래 버튼 두 개로 해요. PC: Space = 굴리기·더 깊이, Backspace = 귀환·후퇴.'] },
      { h: 'AI 난이도', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움은 위험을 계산해서 멈출 때를 골라요.'] },
    ],
    tutorial: [
      { sel: '.dq-cv', text: '위는 지금 방과 필요한 기호, 오른쪽 위는 해골 칸이에요. 해골 칸이 다 차면 도망쳐요!' },
      { sel: '.dq-btns', text: '굴려서 기호를 채우면 돌파. 돌파 뒤엔 더 내려갈지, 귀환해서 금화를 챙길지 골라요.' },
      { sel: '.dq-players', text: '모두의 금화와 유물이 여기 보여요.' },
      { text: '도망치면 이번 탐험의 전리품을 모두 잃어요(방에서 「후퇴」하면 절반만). 기본은 금화 30을 먼저 모으면 승리! 승리 조건은 설정에서 바꿀 수 있어요.' },
    ],
    controls: [
      { id: 'go', label: '굴리기 / 더 깊이', keys: ['Space'], pad: ['a'] },
      { id: 'back', label: '귀환 / 후퇴', keys: ['Backspace'], pad: ['b'] },
    ],
    codex,
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { ROOMS, RELICS, resolve },
  });
})();
