/* 보물섬 땅파기 — 지뢰찾기식 숫자 힌트로 보물을 파내는 섬 보드게임. 맵 9가지(지형은 맵 모양 + 시드, 보물·함정은 매 판 무작위).
   지도(보물·함정·도구 배치)는 시드로 만들어 상태에 가볍게 뒤섞어(hx) 넣고, 화면은 파낸 칸(dg/hn)만 그려요.
   apply에는 무작위가 없어요(시드만 init에서 뽑음) — 같은 시드·같은 수순이면 항상 같은 결과. */
(function () {
  const L = window.Lounge, U = L.util;
  const SPD = () => ((L.debug && L.debug.speed) || 1) * (L.speed ? (L.speed() || 1) : 1);

  /* ---------------- codes ---------------- */
  // 0 빈 땅, 1 동전(2점), 2 금괴(5점), 3 보물상자(10점), 4 해골 함정(−4점), 5 늪(다음 차례 쉼), 6 탐지기, 7 삽, 8 지도 조각,
  // 9 독침 함정(−2점, 다음 차례까지 도구 못 씀), 10 저주 상자(점수 맞바꾸기), 11 동굴 붕괴(옆 4칸이 묻힘), 12 미믹 상자(−3점, 숫자엔 보물로 잡힘)
  const VAL = [0, 2, 5, 10];
  const TRAP_PTS = 4, DART_PTS = 2, MIMIC_PTS = 3, CURSE_PTS = 3, CURSE_SOLO = 5;
  const NAME = ['빈 땅', '동전 주머니', '금괴', '보물상자', '해골 함정', '모래 늪', '탐지기', '삽', '지도 조각', '독침 함정', '저주 상자', '동굴 붕괴', '미믹 상자'];
  const TRAP_ORDER = [4, 5, 9, 12, 11, 10]; // 함정 종류는 이 순서로 돌아가며 정해져요(개수는 모두에게 공개)
  const isT = (c) => c >= 1 && c <= 3;
  const isTL = (c) => isT(c) || c === 12; // 숫자·탐지기·지도에 '보물'로 잡히는 것
  const isTrap = (c) => c === 4 || c === 5 || c >= 9;
  const DIG = (ch) => ch === '.' || ch === ',' || ch === ':'; // 맨땅 · 젖은 모래(강가) · 자갈땅(바위 옆)
  const A64 = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_';

  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const hsh = (sd, i) => (Math.imul((sd ^ Math.imul(i + 1, 0x9E3779B1)) >>> 0, 0x85EBCA6B) >>> 26) & 63;
  const encC = (sd, i, c) => A64[(c * 7 + hsh(sd, i)) & 63];
  const decC = (sd, i, ch) => (((A64.indexOf(ch) - hsh(sd, i)) & 63) * 55) & 63;

  /* ---------------- maps ----------------
     지형 글자: '~' 바다, '.' 팔 수 있는 땅, '#' 바위, 'T' 나무, 'B' 다리, 'L' 용암, 'F' 얼음 호수, 'W' 웅덩이·석호,
     'P' 돌기둥, 'H' 무너진 벽(해골섬은 이빨). '.'만 팔 수 있고, '~'만 탐지기 가운데로 못 골라요.
     맵마다 모양 규칙은 같지만 시드로 매번 조금씩 달라지고, 보물·함정·도구는 '.' 칸 중에서 매 판 무작위로 묻혀요. */
  const MAPS = [null,
    { k: 'sand', name: '모래섬' },
    { k: 'jungle', name: '정글섬' },
    { k: 'volcano', name: '화산섬' },
    { k: 'snow', name: '눈꽃섬' },
    { k: 'arch', name: '다리 군도' },
    { k: 'ruins', name: '유적섬' },
    { k: 'swamp', name: '안개 늪' },
    { k: 'atoll', name: '산호 환초' },
    { k: 'skull', name: '해골섬' },
    { k: 'wild', name: '원시섬' },
  ];
  const MAPN = MAPS.length - 1;
  const mapOf = (s) => MAPS[s.mp] || MAPS[1];

  function mkNoise(R, n, per) {
    const gN = Math.ceil(n / per) + 2, gr = [];
    for (let i = 0; i < gN * gN; i++) gr.push(R() - 0.5);
    const sm = (t) => t * t * (3 - 2 * t);
    return (x, y) => {
      const fx = x / per, fy = y / per, ix = Math.floor(fx), iy = Math.floor(fy), tx = sm(fx - ix), ty = sm(fy - iy);
      const g = (a, b) => gr[(b % gN) * gN + (a % gN)];
      return U.lerp(U.lerp(g(ix, iy), g(ix + 1, iy), tx), U.lerp(g(ix, iy + 1), g(ix + 1, iy + 1), tx), ty);
    };
  }
  // keep the largest 4-connected piece of non-sea (bridges, lagoons count as land); returns its size
  function prune(a, n) {
    const comp = new Int16Array(n * n).fill(-1); let best = -1, bestN = 0, k = 0;
    for (let i = 0; i < n * n; i++) {
      if (a[i] === '~' || comp[i] >= 0) continue;
      const q = [i]; comp[i] = k; let cnt = 0;
      while (q.length) {
        const v = q.pop(); cnt++; const x = v % n, y = (v / n) | 0;
        if (x > 0 && a[v - 1] !== '~' && comp[v - 1] < 0) { comp[v - 1] = k; q.push(v - 1); }
        if (x < n - 1 && a[v + 1] !== '~' && comp[v + 1] < 0) { comp[v + 1] = k; q.push(v + 1); }
        if (y > 0 && a[v - n] !== '~' && comp[v - n] < 0) { comp[v - n] = k; q.push(v - n); }
        if (y < n - 1 && a[v + n] !== '~' && comp[v + n] < 0) { comp[v + n] = k; q.push(v + n); }
      }
      if (cnt > bestN) { bestN = cnt; best = k; }
      k++;
    }
    for (let i = 0; i < n * n; i++) if (a[i] !== '~' && comp[i] !== best) a[i] = '~';
    return bestN;
  }
  const UV = (n, x, y) => [(x + 0.5 - n / 2) / (n / 2), (y + 0.5 - n / 2) / (n / 2)];
  // grow an island: f(x,y,u,v) small = inland. Raise the waterline until the island covers `target` of the grid.
  function grow(n, f, target) {
    for (let thr = 0.78; ; thr += 0.03) {
      const a = new Array(n * n);
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const edge = x === 0 || y === 0 || x === n - 1 || y === n - 1;
        const [u, v] = UV(n, x, y);
        a[y * n + x] = !edge && f(x, y, u, v) < thr ? '.' : '~';
      }
      if (prune(a, n) >= n * n * target || thr > 1.8) return a;
    }
  }
  // turn the `frac` best-scoring dirt cells into `ch` (clustered when the score is a noise field)
  function pickTop(a, n, frac, score, ch, ok) {
    const c = [];
    for (let i = 0; i < n * n; i++) if (a[i] === '.' && (!ok || ok(i))) c.push([score(i % n, (i / n) | 0), i]);
    c.sort((p, q) => q[0] - p[0]);
    const m = Math.round(c.length * frac);
    for (let k = 0; k < m; k++) a[c[k][1]] = ch;
  }
  function scatter(a, R, p, ch, ok) { for (let i = 0; i < a.length; i++) if (a[i] === '.' && R() < p && (!ok || ok(i))) a[i] = ch; }
  const nbr4 = (a, n, i) => { const x = i % n, y = (i / n) | 0; return [x > 0 ? a[i - 1] : '~', x < n - 1 ? a[i + 1] : '~', y > 0 ? a[i - n] : '~', y < n - 1 ? a[i + n] : '~']; };
  const inland = (a, n, i) => nbr4(a, n, i).every((ch) => ch !== '~');
  const nearB = (a, n, i) => nbr4(a, n, i).includes('B');

  const SHAPES = {
    sand(R, n, fs) { // 동그란 모래섬 + 바위 (기존 맵)
      const nz = mkNoise(R, n, 3);
      const a = grow(n, (x, y, u, v) => Math.hypot(u, v) + nz(x, y) * 0.55, 0.5);
      scatter(a, R, 0.07 * fs, '#');
      return a;
    },
    jungle(R, n, fs) { // 큰 섬을 가로지르는 강 + 다리, 빽빽한 나무
      const nz = mkNoise(R, n, 3), nz2 = mkNoise(R, n, 2);
      const a = grow(n, (x, y, u, v) => Math.hypot(u * 0.96, v * 0.9) + nz(x, y) * 0.5, 0.56);
      const c = (n - 1) / 2, A = n * 0.1, ph = R() * 6.283, y0 = c + (R() - 0.5) * n * 0.14, ry = [];
      for (let x = 0; x < n; x++) ry.push(Math.max(2, Math.min(n - 3, Math.round(y0 + A * Math.sin((x / n) * 5.4 + ph)))));
      for (let x = 0; x < n; x++) {
        const p = x ? ry[x - 1] : ry[x];
        for (let y = Math.min(p, ry[x]); y <= Math.max(p, ry[x]); y++) a[y * n + x] = '~';
      }
      const cand = [];
      for (let x = 2; x < n - 2; x++) { const y = ry[x]; if (ry[x - 1] === y && ry[x + 1] === y && a[(y - 1) * n + x] === '.' && a[(y + 1) * n + x] === '.') cand.push(x); }
      const want = n >= 12 ? 2 : 1, got = [];
      while (cand.length && got.length < want) { const x = cand.splice(Math.floor(R() * cand.length), 1)[0]; if (got.every((g) => Math.abs(g - x) >= 3)) got.push(x); }
      got.forEach((x) => { a[ry[x] * n + x] = 'B'; });
      prune(a, n);
      pickTop(a, n, 0.12 * fs, (x, y) => nz2(x, y) + R() * 0.3, 'T', (i) => !nearB(a, n, i));
      return a;
    },
    volcano(R, n, fs) { // 가운데 분화구(용암)와 바위 능선, 바다로 흐르는 용암 줄기
      const nz = mkNoise(R, n, 3);
      const a = grow(n, (x, y, u, v) => Math.hypot(u, v) + nz(x, y) * 0.35, 0.54);
      const c = (n - 1) / 2, rc = n >= 14 ? 1.6 : n >= 12 ? 1.2 : 0.8;
      for (let i = 0; i < n * n; i++) {
        if (a[i] === '~') continue;
        const d = Math.hypot((i % n) - c, ((i / n) | 0) - c);
        if (d <= rc) a[i] = 'L'; else if (d <= rc + 1.3 && R() < 0.5 * fs) a[i] = '#';
      }
      const th = R() * 6.283; let px = -1, py = -1;
      for (let t = rc; t < n; t += 0.3) {
        const x = Math.round(c + Math.cos(th) * t + Math.sin(t * 1.4) * 0.45), y = Math.round(c + Math.sin(th) * t);
        if (x < 0 || y < 0 || x >= n || y >= n || a[y * n + x] === '~') break;
        if (px >= 0 && px !== x && py !== y && a[py * n + x] !== '~') a[py * n + x] = 'L';
        a[y * n + x] = 'L'; px = x; py = y;
      }
      scatter(a, R, 0.03 * fs, '#');
      return a;
    },
    snow(R, n, fs) { // 들쭉날쭉한 해안, 얼음 호수, 눈 덮인 전나무
      const nz = mkNoise(R, n, 3), nz2 = mkNoise(R, n, 2);
      const a = grow(n, (x, y, u, v) => Math.hypot(u, v) + nz(x, y) * 0.6 + nz2(x, y) * 0.35, 0.52);
      const inner = []; for (let i = 0; i < n * n; i++) if (a[i] === '.' && nbList(n).n8[i].every((j) => a[j] !== '~')) inner.push(i);
      if (inner.length) {
        const size = Math.round(n * n * 0.045 * fs), q = [inner[Math.floor(R() * inner.length)]]; let made = 0;
        while (q.length && made < size) {
          const i = q.splice(Math.floor(R() * q.length), 1)[0];
          if (a[i] !== '.' || !inland(a, n, i)) continue;
          a[i] = 'F'; made++;
          const x = i % n, y = (i / n) | 0;
          for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const xx = x + dx, yy = y + dy; if (xx > 0 && yy > 0 && xx < n - 1 && yy < n - 1) q.push(yy * n + xx); }
        }
      }
      pickTop(a, n, 0.08 * fs, (x, y) => nz2(x + 7, y + 3) + R() * 0.3, 'T');
      scatter(a, R, 0.03 * fs, '#');
      return a;
    },
    arch(R, n, fs) { // 십자 물길로 나뉜 네 섬을 나무다리로 이어요
      const nz = mkNoise(R, n, 3), nz2 = mkNoise(R, n, 2);
      const a = grow(n, (x, y, u, v) => Math.max(Math.abs(u), Math.abs(v)) * 0.45 + Math.hypot(u, v) * 0.55 + nz(x, y) * 0.7, 0.6);
      const c = (n - 1) / 2;
      const cx = Math.round(c + (R() - 0.5) * n * 0.16), cy = Math.round(c + (R() - 0.5) * n * 0.16);
      const vx = [], hy = []; let w1 = cx, w2 = cy;
      for (let t = 0; t < n; t++) {
        if (R() < 0.3) w1 = Math.max(cx - 1, Math.min(cx + 1, w1 + (R() < 0.5 ? -1 : 1)));
        if (R() < 0.3) w2 = Math.max(cy - 1, Math.min(cy + 1, w2 + (R() < 0.5 ? -1 : 1)));
        vx.push(w1); hy.push(w2);
      }
      for (let t = 0; t < n; t++) {
        a[t * n + vx[t]] = '~'; if (t && vx[t] !== vx[t - 1]) a[t * n + vx[t - 1]] = '~';
        a[hy[t] * n + t] = '~'; if (t && hy[t] !== hy[t - 1]) a[hy[t - 1] * n + t] = '~';
      }
      for (let i = 0; i < n * n; i++) if (a[i] === '.' && nbr4(a, n, i).includes('~') && nz2(i % n, (i / n) | 0) > 0.22) a[i] = '_';
      for (let i = 0; i < n * n; i++) if (a[i] === '_') a[i] = '~';
      // one bridge on each of the four arms of the cross
      const arms = [[], [], [], []];
      for (let t = 1; t < n - 1; t++) {
        const x = vx[t];
        if (t !== hy[x] && vx[t - 1] === x && vx[t + 1] === x && a[t * n + x - 1] === '.' && a[t * n + x + 1] === '.') arms[t < cy ? 0 : 1].push(t * n + x);
        const y = hy[t];
        if (t !== vx[y] && hy[t - 1] === y && hy[t + 1] === y && a[(y - 1) * n + t] === '.' && a[(y + 1) * n + t] === '.') arms[t < cx ? 2 : 3].push(y * n + t);
      }
      arms.forEach((l) => { if (l.length) a[l[Math.floor(R() * l.length)]] = 'B'; });
      prune(a, n);
      pickTop(a, n, 0.05 * fs, (x, y) => nz2(x + 5, y + 9) + R() * 0.4, 'T', (i) => !nearB(a, n, i));
      scatter(a, R, 0.035 * fs, '#', (i) => !nearB(a, n, i));
      return a;
    },
    ruins(R, n, fs) { // 네모난 섬, 가운데 무너진 신전 벽과 돌기둥 줄
      const nz = mkNoise(R, n, 3);
      const a = grow(n, (x, y, u, v) => Math.pow(Math.pow(Math.abs(u), 4) + Math.pow(Math.abs(v), 4), 0.25) + nz(x, y) * 0.35, 0.56);
      const c = (n - 1) / 2, hs = n >= 14 ? 2.5 : 1.5;
      const door = [0, 1, 2, 3].map(() => (R() < 0.5 ? -0.5 : 0.5)); // one gap in each temple wall
      for (let i = 0; i < n * n; i++) {
        if (a[i] !== '.') continue;
        const x = i % n, y = (i / n) | 0, dx = x - c, dy = y - c, ch = Math.max(Math.abs(dx), Math.abs(dy));
        if (ch === hs) { // temple walls (some fallen)
          const side = dy === -hs ? 0 : dy === hs ? 1 : dx === -hs ? 2 : 3, along = side < 2 ? dx : dy;
          if (along !== door[side] && R() < 0.8 * fs) a[i] = 'H';
        } else if (ch === hs + 2 && (x + y) % 2 === 0 && R() < 0.85 * fs) a[i] = 'P'; // colonnade around it
      }
      scatter(a, R, 0.02 * fs, '#');
      return a;
    },
    swamp(R, n, fs) { // 질척한 섬 곳곳의 웅덩이와 마른 나무
      const nz = mkNoise(R, n, 3), nz2 = mkNoise(R, n, 2);
      const a = grow(n, (x, y, u, v) => Math.hypot(u * 0.92, v) + nz(x, y) * 0.65, 0.56);
      pickTop(a, n, 0.11 * fs, (x, y) => nz2(x, y) + R() * 0.15, 'W');
      scatter(a, R, 0.05 * fs, 'T');
      return a;
    },
    atoll(R, n, fs, k) { // 고리 모양 산호섬, 가운데 석호와 바다로 트인 물길
      const nz = mkNoise(R, n, 3), th = R() * 6.283;
      const R0 = 0.62, w = (n <= 10 ? 0.24 : 0.2) + k * 0.03;
      const a = new Array(n * n);
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const [u, v] = UV(n, x, y), d = Math.hypot(u, v), i = y * n + x;
        const edge = x === 0 || y === 0 || x === n - 1 || y === n - 1;
        let ch = '~';
        if (!edge) {
          if (Math.abs(d - R0) + nz(x, y) * 0.18 < w) ch = '.';
          else if (d < R0) ch = n >= 12 && d < 0.13 ? '.' : 'W';
          let da = Math.abs(Math.atan2(v, u) - th); if (da > Math.PI) da = 2 * Math.PI - da;
          if (d > R0 - w - 0.05 && da * d < 0.11) ch = '~';
        }
        a[i] = ch;
      }
      prune(a, n);
      pickTop(a, n, 0.06 * fs, (x, y) => R(), 'T');
      scatter(a, R, 0.035 * fs, '#');
      return a;
    },
    skull(R, n, fs) { // 해골 모양 섬: 눈·코 구덩이, 이빨, 비석
      const nz = mkNoise(R, n, 3);
      const a = new Array(n * n);
      let teethY = -1;
      for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
        const [u, v] = UV(n, x, y), i = y * n + x, e = nz(x, y) * 0.12;
        const edge = x === 0 || y === 0 || x === n - 1 || y === n - 1;
        const cran = Math.hypot(u, (v + 0.14) * 1.08) + e < 0.8;
        const jaw = v > 0.2 && v < 0.86 + e && Math.abs(u) < 0.52 - Math.max(0, v - 0.6) * 0.9;
        let ch = !edge && (cran || jaw) ? '.' : '~';
        if (ch === '.' && Math.hypot(Math.abs(u) - 0.33, v + 0.1) < 0.21) ch = 'W';
        if (ch === '.' && Math.hypot(u * 1.5, v - 0.22) < 0.15) ch = 'W';
        a[i] = ch;
        if (teethY < 0 && v >= 0.44) teethY = y;
      }
      if (teethY > 0) for (let x = 0; x < n; x++) { const [u] = UV(n, x, teethY), i = teethY * n + x; if (a[i] === '.' && Math.abs(u) < 0.42 && x % 2 === 0) a[i] = 'H'; }
      prune(a, n);
      scatter(a, R, 0.035 * fs, '#');
      scatter(a, R, 0.025 * fs, 'T');
      return a;
    },
  };
  /* 원시섬: 판마다 모양(둥근·길쭉·초승달·쌍둥이)부터 새로 만들고, 강 · 야자 숲 · 바위 무더기를 놓아요.
     강가 칸은 젖은 모래(','), 바위 옆 칸은 자갈땅(':') — 둘 다 팔 수 있지만 파는 느낌이 달라요. */
  SHAPES.wild = function (R, n, fs) {
    const nz = mkNoise(R, n, 3), nz2 = mkNoise(R, n, 2), kind = Math.floor(R() * 4), th = R() * 6.283, ct = Math.cos(th), st = Math.sin(th);
    const ox = Math.cos(th) * 0.55, oy = Math.sin(th) * 0.55;
    const a = grow(n, (x, y, u, v) => {
      if (kind === 1) { const uu = u * ct + v * st, vv = -u * st + v * ct; return Math.hypot(uu * 0.72, vv * 1.5) + nz(x, y) * 0.45; }
      if (kind === 2) { const d2 = Math.hypot(u - ox, v - oy); return Math.hypot(u, v) + nz(x, y) * 0.4 + (d2 < 0.5 ? (0.5 - d2) * 2.4 : 0); }
      if (kind === 3) { const px = ct * 0.4, py = st * 0.4; return Math.min(Math.hypot(u - px, v - py), Math.hypot(u + px, v + py)) * 1.4 + nz(x, y) * 0.4; }
      return Math.hypot(u, v) + nz(x, y) * 0.55;
    }, 0.56);
    // 강: 섬을 가로질러 구불구불(1칸 폭). 바다와 이어진 칸은 바다 그대로
    const hor = R() < 0.5, c0 = (n - 1) / 2 + (R() - 0.5) * n * 0.3, A = n * (0.08 + R() * 0.06), ph = R() * 6.283, fq = 3.5 + R() * 3;
    let prev = -1;
    for (let t = 0; t < n; t++) {
      const w = Math.max(1, Math.min(n - 2, Math.round(c0 + A * Math.sin((t / n) * fq + ph))));
      const lo = prev < 0 ? w : Math.min(prev, w), hi = prev < 0 ? w : Math.max(prev, w);
      for (let k = lo; k <= hi; k++) { const i = hor ? k * n + t : t * n + k; if (a[i] === '.') a[i] = 'R'; }
      prev = w;
    }
    prune(a, n);
    // 야자 숲(뭉쳐서) · 바위 무더기
    pickTop(a, n, 0.1 * fs, (x, y) => nz2(x, y) + R() * 0.25, 'T', (i) => !nbr4(a, n, i).includes('R'));
    const land = []; for (let i = 0; i < n * n; i++) if (a[i] === '.') land.push(i);
    const piles = 2 + Math.floor(R() * 3);
    for (let k = 0; k < piles && land.length; k++) {
      const c = land[Math.floor(R() * land.length)]; if (a[c] !== '.') continue;
      a[c] = '#';
      for (const j of nbList(n).n8[c]) if (a[j] === '.' && R() < 0.3 * fs) a[j] = '#';
    }
    scatter(a, R, 0.015 * fs, '#');
    return a;
  };
  function soils(a, n, R) { // 강가 → 젖은 모래, 바위 옆 → 자갈땅 (판다는 규칙에 영향)
    const b = a.slice();
    for (let i = 0; i < n * n; i++) {
      if (a[i] !== '.') continue;
      const nb = nbr4(a, n, i);
      if (nb.includes('R')) b[i] = ',';
      else if (nb.includes('#') && R() < 0.7) b[i] = ':';
    }
    return b;
  }
  const FLIP = { skull: 'x', jungle: 'xyt', arch: 'xyt', swamp: 'xyt', wild: 'xyt' };

  const TRAPS = { 1: 4, 2: 7, 3: 10 };
  const LIMIT = { 10: 14, 12: 18, 14: 22 };

  /* ---------------- generation (deterministic from seed) ---------------- */
  function terrain(R, n, mp) {
    const key = (MAPS[mp] || MAPS[1]).k, fl = FLIP[key] || 'xy';
    const minD = Math.round(n * n * 0.3);
    let a = null;
    for (let k = 0; k < 10; k++) {
      const fs = (n === 10 ? 0.8 : 1) * Math.max(0.3, 1 - k * 0.15);
      a = SHAPES[key](R, n, fs, k);
      prune(a, n);
      if (a.filter((ch) => ch === '.').length >= minD) break;
    }
    if (key === 'wild') a = soils(a, n, R);
    // random mirror / transpose so the same map looks a little different every game
    const fx = fl.includes('x') && R() < 0.5, fy = fl.includes('y') && R() < 0.5, tp = fl.includes('t') && R() < 0.5;
    const b = new Array(n * n);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      let sx = fx ? n - 1 - x : x, sy = fy ? n - 1 - y : y;
      if (tp) { const t = sx; sx = sy; sy = t; }
      b[y * n + x] = a[sy * n + sx];
    }
    return b;
  }
  function gen(seed, size, trapLv, tools, mp) {
    const R = prng(seed), n = size;
    const tr = terrain(R, n, mp || 1);
    const dig = []; for (let i = 0; i < n * n; i++) if (DIG(tr[i])) dig.push(i);
    for (let i = dig.length - 1; i > 0; i--) { const j = Math.floor(R() * (i + 1)); [dig[i], dig[j]] = [dig[j], dig[i]]; }
    const D = dig.length;
    const T = Math.round(D * 0.14), chest = Math.max(1, Math.round(T * 0.15)), gold = Math.round(T * 0.35), coin = T - chest - gold;
    const trapN = Math.max(1, Math.round((TRAPS[trapLv] || 7) * D / 82));
    const toolEach = tools ? Math.max(1, Math.round(D / 42)) : 0;
    const hid = new Array(n * n).fill(0);
    let p = 0;
    const put = (code, cnt) => { for (let i = 0; i < cnt; i++) hid[dig[p++]] = code; };
    put(3, chest); put(2, gold); put(1, coin);
    // 함정은 공정하게: 서로 붙지 않게(둘레 8칸에 다른 함정 없음), 동굴 붕괴는 보물상자 옆에 두지 않고 옆에 팔 땅이 2칸 넘게
    const tc = { 4: 0, 5: 0, 9: 0, 10: 0, 11: 0, 12: 0 }, nb = nbList(n), rest = dig.slice(p);
    const ok = (i, code, strict) => {
      if (hid[i]) return false;
      if (!strict) return true;
      if (nb.n8[i].some((j) => isTrap(hid[j]))) return false;
      if (code === 11) { const x = i % n, y = (i / n) | 0, n4 = [x > 0 ? i - 1 : -1, x < n - 1 ? i + 1 : -1, y > 0 ? i - n : -1, y < n - 1 ? i + n : -1].filter((j) => j >= 0 && DIG(tr[j])); if (n4.length < 2 || n4.some((j) => hid[j] === 3)) return false; }
      return true;
    };
    for (let k = 0; k < trapN; k++) {
      const code = TRAP_ORDER[k % TRAP_ORDER.length];
      let at = rest.find((i) => ok(i, code, true)); if (at == null) at = rest.find((i) => ok(i, code, false));
      if (at == null) break;
      hid[at] = code; tc[code]++;
    }
    const left = rest.filter((i) => !hid[i]); let q = 0;
    for (const code of [6, 7, 8]) for (let k = 0; k < toolEach && q < left.length; k++) hid[left[q++]] = code;
    return { tr: tr.join(''), hid, T, trapN, toolEach, D, tc };
  }

  /* ---------------- helpers ---------------- */
  function nbrs(N, i, self) {
    const x = i % N, y = (i / N) | 0, out = [];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      if (!dx && !dy && !self) continue;
      const xx = x + dx, yy = y + dy;
      if (xx >= 0 && yy >= 0 && xx < N && yy < N) out.push(yy * N + xx);
    }
    return out;
  }
  const NB = {}; // cache per size
  function nbList(N) {
    if (!NB[N]) { NB[N] = { n8: [], n9: [] }; for (let i = 0; i < N * N; i++) { NB[N].n8.push(nbrs(N, i, false)); NB[N].n9.push(nbrs(N, i, true)); } }
    return NB[N];
  }
  const code = (s, i) => decC(s.sd, i, s.hx[i]);
  // dg: '.' 안 판 칸, 'x' 무너져 묻힌 칸, 그 밖엔 나온 것(36진 한 글자)
  const dugCode = (s, i) => { const ch = s.dg[i]; return ch === '.' ? -1 : ch === 'x' ? -2 : parseInt(ch, 36); };
  const setCh = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);
  const undug = (s, i) => DIG(s.tr[i]) && s.dg[i] === '.';
  const foundCount = (s) => s.f.length;
  function treasuresIn(s, cells) { let c = 0; for (const j of cells) if (isTL(code(s, j))) c++; return c; }
  const allFound = (s) => s.f.length + (s.lost || 0) >= s.tot[0];
  const mimicN = (s) => (s.tc ? s.tc[12] || 0 : 0);

  /* ---------------- core logic ---------------- */
  function init(players, opts) {
    opts = opts || {};
    const size = [10, 12, 14].includes(opts.size) ? opts.size : 12;
    const trapLv = [1, 2, 3].includes(opts.traps) ? opts.traps : 2;
    const tools = opts.tools === 0 ? 0 : 1;
    const sd = opts.seed != null ? opts.seed >>> 0 : (Math.random() * 2 ** 31) >>> 0;
    // 맵: 0 = 무작위 (시드로 고름 → 매 판 달라요)
    const mp = opts.map >= 1 && opts.map <= MAPN ? opts.map | 0 : 1 + (Math.imul(sd ^ 0x5bd1e995, 0x27d4eb2d) >>> 7) % MAPN;
    return build(players.map((p) => p.name), size, trapLv, tools, sd, mp);
  }
  function build(names, size, trapLv, tools, sd, mp) {
    mp = mp || 1;
    const g = gen(sd, size, trapLv, tools, mp);
    const n = names.length;
    let hx = '';
    for (let i = 0; i < size * size; i++) hx += encC(sd, i, g.hid[i]);
    return {
      n, nm: names.map((x) => String(x || '').slice(0, 10)), N: size, sd, mp, tr: g.tr, hx,
      dg: '.'.repeat(size * size), hn: '.'.repeat(size * size),
      pts: Array(n).fill(0), tl: Array.from({ length: n }, () => [0, 0, 0]), skp: Array(n).fill(0), tn: Array(n).fill(0),
      t: 0, dl: 1, dd: 0, lim: LIMIT[size], tot: [g.T, g.trapN, g.toolEach], tk: tools, f: [], sc: [], rw: [], seq: 0, last: null, end: 0,
      tc: g.tc, psn: Array(n).fill(0), ks: Array(n).fill(0), cv: [], lost: 0, wb: 0,
    };
  }

  function actor(s) { return s.end ? null : s.t; }
  function checkEnd(s) {
    if (allFound(s) || s.tn.every((x) => x >= s.lim)) { s.end = 1; return true; }
    for (let i = 0; i < s.N * s.N; i++) if (undug(s, i)) return false;
    s.end = 1; return true;
  }
  function endTurn(s, ev) {
    s.tn[s.t]++; s.dl = 1; s.dd = 0; s.wb = 0;
    if (s.psn && s.psn[s.t] > 0) s.psn[s.t]--;
    if (checkEnd(s)) return;
    let nx = s.t;
    for (let g = 0; g < 50; g++) {
      nx = (nx + 1) % s.n;
      if (s.skp[nx]) {
        s.skp[nx] = 0; s.tn[nx]++;
        (ev.sk = ev.sk || []).push(nx);
        if (checkEnd(s)) return;
        continue;
      }
      if (s.tn[nx] >= s.lim) continue;
      break;
    }
    s.t = nx;
  }

  function apply(s, seat, a) {
    if (s.end) throw new Error('game over');
    if (seat !== s.t) throw new Error('not your turn');
    if (!a || typeof a.a !== 'string') throw new Error('bad action');
    const NN = s.N * s.N, nb = nbList(s.N);
    if (a.a === 'dig') {
      const i = a.i | 0;
      if (i < 0 || i >= NN || !undug(s, i)) throw new Error('cannot dig');
      const c = code(s, i), soil = s.tr[i];
      s.dg = setCh(s.dg, i, c.toString(36));
      s.dd++; s.dl--;
      const ev = { id: ++s.seq, k: 'dig', s: seat, i, c };
      let stop = false;
      if (!s.ks) s.ks = s.pts.map(() => 0);
      if (isTrap(c)) s.ks[seat]++;
      if (isT(c)) { s.pts[seat] += VAL[c]; s.f.push([i, seat]); }
      else if (c === 4) s.pts[seat] -= TRAP_PTS;
      else if (c === 5) { stop = true; if (s.tn[seat] + 1 < s.lim) s.skp[seat] = 1; else ev.nf = 1; }
      else if (c === 9) { s.pts[seat] -= DART_PTS; if (!s.psn) s.psn = s.pts.map(() => 0); s.psn[seat] = 2; }
      else if (c === 10) { // 저주: 가장 낮은 다른 사람과 점수를 맞바꿔요(내가 가장 낮으면 −3점)
        let j = -1; for (let k = 0; k < s.n; k++) if (k !== seat && (j < 0 || s.pts[k] < s.pts[j])) j = k;
        if (j >= 0 && s.pts[j] < s.pts[seat]) { const t = s.pts[j]; s.pts[j] = s.pts[seat]; s.pts[seat] = t; ev.sw = j; }
        else { s.pts[seat] -= s.n > 1 ? CURSE_PTS : CURSE_SOLO; ev.sw = -1; }
      } else if (c === 11) { // 동굴 붕괴: 위·아래·옆 안 판 땅이 흙에 묻혀요(속은 모두에게 보여요)
        const x = i % s.N, y = (i / s.N) | 0, out = [];
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const xx = x + dx, yy = y + dy, j = yy * s.N + xx;
          if (xx < 0 || yy < 0 || xx >= s.N || yy >= s.N || !undug(s, j)) continue;
          const cj = code(s, j); s.dg = setCh(s.dg, j, 'x'); if (!s.cv) s.cv = []; s.cv.push([j, cj]); out.push(j);
          if (isT(cj)) s.lost = (s.lost || 0) + 1;
        }
        ev.cv = out;
      } else if (c === 12) { s.pts[seat] -= MIMIC_PTS; stop = true; }
      else { if (c >= 6) s.tl[seat][c - 6]++; if (soil !== ':') s.hn = setCh(s.hn, i, String(treasuresIn(s, nb.n8[i]))); }
      // 땅 느낌: 젖은 모래는 부드러워 한 번 더(차례에 한 번), 자갈땅은 힘들어서 이번 차례 끝
      if (!stop && soil === ',' && !s.wb) { s.wb = 1; s.dl++; ev.wet = 1; }
      else if (!stop && soil === ':' && s.dl > 0) { s.dl = 0; ev.rk = 1; }
      s.last = ev;
      if (allFound(s)) { s.tn[s.t]++; s.end = 1; return s; }
      if (s.dl <= 0 || stop) endTurn(s, ev); // 늪·미믹은 그 자리에서 차례 끝
      else if (checkEnd(s)) { /* nothing left to dig */ }
      return s;
    }
    if ((a.a === 'shovel' || a.a === 'scan' || a.a === 'map') && s.psn && s.psn[seat]) throw new Error('poisoned');
    if (a.a === 'shovel') {
      if (s.tl[seat][1] <= 0 || s.dd > 0 || s.dl !== 1) throw new Error('no shovel');
      s.tl[seat][1]--; s.dl = 2;
      s.last = { id: ++s.seq, k: 'shovel', s: seat };
      return s;
    }
    if (a.a === 'scan') {
      const i = a.i | 0;
      if (s.tl[seat][0] <= 0 || i < 0 || i >= NN || s.tr[i] === '~') throw new Error('bad scan');
      s.tl[seat][0]--;
      const cnt = treasuresIn(s, nb.n9[i]);
      s.sc.push([i, cnt]);
      s.last = { id: ++s.seq, k: 'scan', s: seat, i, n: cnt };
      return s;
    }
    if (a.a === 'map') {
      const r = a.r | 0;
      if (s.tl[seat][2] <= 0 || r < 0 || r >= s.N || s.rw.some((x) => x[0] === r)) throw new Error('bad map');
      s.tl[seat][2]--;
      const cells = []; for (let x = 0; x < s.N; x++) cells.push(r * s.N + x);
      const cnt = treasuresIn(s, cells);
      s.rw.push([r, cnt]);
      s.last = { id: ++s.seq, k: 'map', s: seat, r, n: cnt };
      return s;
    }
    throw new Error('unknown action');
  }

  function result(s) {
    if (!s.end) return null;
    const best = Math.max(...s.pts);
    const order = s.pts.map((p, i) => i).sort((a, b) => s.pts[b] - s.pts[a]);
    const winners = order.filter((i) => s.pts[i] === best);
    const left = s.tot[0] - s.f.length - (s.lost || 0);
    const lines = order.map((i, r) => `${r + 1}위 ${s.nm[i]} ${s.pts[i]}점`);
    lines.push(left ? `남은 보물 ${left}개는 섬에 묻힌 채 끝났어요.` : s.lost ? `동굴이 무너져 보물 ${s.lost}개는 영영 묻혔어요.` : '보물을 모두 찾았어요!');
    const fd = (i, c) => s.f.filter((f) => f[1] === i && (c == null || code(s, f[0]) === c)).length;
    const stats = [{ label: '찾은 보물', values: s.pts.map((_, i) => String(fd(i))) }, { label: '보물상자', values: s.pts.map((_, i) => String(fd(i, 3))) },
      { label: '밟은 함정', values: s.pts.map((_, i) => String(s.ks ? s.ks[i] : 0)) }];
    const res = { winners, stats, text: lines.join('\n') };
    if (s.n === 1) res.title = `${s.pts[0]}점`;
    return res;
  }

  /* ---------------- AI (public info only) ---------------- */
  function knowledge(s) {
    const NN = s.N * s.N, nb = nbList(s.N);
    const unk = []; const isU = new Uint8Array(NN);
    for (let i = 0; i < NN; i++) if (undug(s, i)) { unk.push(i); isU[i] = 1; }
    const knownT = new Uint8Array(NN); for (const [i] of s.f) knownT[i] = 1;
    for (let i = 0; i < NN; i++) if (dugCode(s, i) === 12) knownT[i] = 1; // 판 미믹도 숫자엔 '보물'
    for (const [j, cj] of s.cv || []) if (isTL(cj)) knownT[j] = 1; // 묻힌 칸은 속이 공개돼요
    const cons = []; // {v:[cells], t:target, row:bool}
    const mk = (cells, cnt, row) => {
      const v = []; let t = cnt;
      for (const j of cells) { if (knownT[j]) t--; else if (isU[j]) v.push(j); }
      if (v.length) cons.push({ v, t: Math.max(0, Math.min(v.length, t)), row });
    };
    for (let i = 0; i < NN; i++) if (s.hn[i] !== '.') mk(nb.n8[i], +s.hn[i], false);
    for (const [i, c] of s.sc) mk(nb.n9[i], c, false);
    for (const [r, c] of s.rw) { const cells = []; for (let x = 0; x < s.N; x++) cells.push(r * s.N + x); mk(cells, c, true); }
    let kn = 0; for (let i = 0; i < NN; i++) if (knownT[i]) kn++;
    const R = s.tot[0] + mimicN(s) - kn;
    return { unk, isU, cons, R };
  }
  function ipf(p, cons, R, unk, iters) {
    for (let it = 0; it < iters; it++) {
      for (const c of cons) {
        let sum = 0; for (const j of c.v) sum += p[j];
        if (sum <= 1e-9) { if (c.t > 0) for (const j of c.v) p[j] = c.t / c.v.length; continue; }
        const f = c.t / sum;
        for (const j of c.v) p[j] = Math.min(1, p[j] * f);
      }
      let sum = 0; for (const j of unk) sum += p[j];
      if (sum > 1e-9) { const f = R / sum; for (const j of unk) p[j] = Math.min(1, p[j] * f); }
    }
  }
  function probsSimple(s, K) {
    const p = new Float64Array(s.N * s.N);
    const dens = K.unk.length ? K.R / K.unk.length : 0;
    for (const j of K.unk) p[j] = dens;
    ipf(p, K.cons, K.R, K.unk, 4);
    return p;
  }
  function probsLocal(s, K) { // 보통: each cell judged only by the hints right next to it
    const p = new Float64Array(s.N * s.N);
    const dens = K.unk.length ? K.R / K.unk.length : 0;
    const sum = new Float64Array(s.N * s.N), cnt = new Uint8Array(s.N * s.N), zero = new Uint8Array(s.N * s.N), one = new Uint8Array(s.N * s.N);
    for (const c of K.cons) {
      const r = c.t / c.v.length;
      for (const j of c.v) { if (c.t === 0) zero[j] = 1; if (c.t === c.v.length) one[j] = 1; if (!c.row) { sum[j] += r; cnt[j]++; } }
    }
    for (const j of K.unk) p[j] = zero[j] ? 0 : one[j] ? 1 : cnt[j] ? sum[j] / cnt[j] : dens;
    return p;
  }
  function lchoose(n, k) { if (k < 0 || k > n) return -Infinity; let r = 0; for (let i = 1; i <= k; i++) r += Math.log((n - k + i) / i); return r; }
  function probsExact(s, K) {
    const NN = s.N * s.N;
    const local = K.cons.filter((c) => !c.row);
    // components of frontier vars
    const varC = new Map(); const comps = [];
    const parent = new Map();
    const find = (x) => { while (parent.get(x) !== x) { parent.set(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
    for (const c of local) for (const j of c.v) if (!parent.has(j)) parent.set(j, j);
    for (const c of local) for (let k = 1; k < c.v.length; k++) { const a = find(c.v[0]), b = find(c.v[k]); if (a !== b) parent.set(a, b); }
    for (const j of parent.keys()) { const r = find(j); if (!varC.has(r)) { varC.set(r, comps.length); comps.push({ vars: [], cons: [] }); } comps[varC.get(r)].vars.push(j); }
    for (const c of local) comps[varC.get(find(c.v[0]))].cons.push(c);
    const exact = []; const approxVars = [];
    let budget = 250000;
    for (const comp of comps) {
      if (comp.vars.length > 24) { approxVars.push(...comp.vars); continue; }
      const vars = comp.vars, idx = new Map(vars.map((v, i) => [v, i]));
      const cs = comp.cons.map((c) => ({ v: c.v.map((j) => idx.get(j)), t: c.t }));
      const byVar = vars.map(() => []); cs.forEach((c, ci) => c.v.forEach((v) => byVar[v].push(ci)));
      const sum = new Int16Array(cs.length), rem = cs.map((c) => c.v.length);
      const asg = new Int8Array(vars.length);
      const cnt = new Map(); // k -> {w, ones:Float64Array}
      let nodes = 0, ok = true;
      const rec = (d, k) => {
        if (++nodes > budget) { ok = false; return; }
        if (d === vars.length) {
          let e = cnt.get(k); if (!e) { e = { w: 0, ones: new Float64Array(vars.length) }; cnt.set(k, e); }
          e.w++; for (let i = 0; i < vars.length; i++) if (asg[i]) e.ones[i]++;
          return;
        }
        for (const val of [0, 1]) {
          let good = true;
          for (const ci of byVar[d]) { const ns = sum[ci] + val, nr = rem[ci] - 1; if (ns > cs[ci].t || ns + nr < cs[ci].t) { good = false; break; } }
          if (!good || k + val > K.R) continue;
          asg[d] = val; for (const ci of byVar[d]) { sum[ci] += val; rem[ci]--; }
          rec(d + 1, k + val);
          for (const ci of byVar[d]) { sum[ci] -= val; rem[ci]++; }
          if (!ok) return;
        }
        asg[d] = 0;
      };
      rec(0, 0);
      budget -= nodes;
      if (!ok || !cnt.size) { approxVars.push(...vars); continue; }
      exact.push({ vars, cnt });
    }
    // pool = everything else (unconstrained + approximated components)
    const inExact = new Set(); exact.forEach((e) => e.vars.forEach((v) => inExact.add(v)));
    const pool = K.unk.filter((j) => !inExact.has(j));
    const F = pool.length;
    // convolution of exact components (log-space weights)
    const conv = (list) => { let d = new Map([[0, 0]]); for (const e of list) { const nd = new Map(); for (const [k1, w1] of d) for (const [k2, ent] of e.cnt) { const k = k1 + k2; if (k > K.R) continue; const w = w1 + Math.log(ent.w); nd.set(k, nd.has(k) ? logAdd(nd.get(k), w) : w); } d = nd; } return d; };
    const p = new Float64Array(NN);
    const total = conv(exact);
    let Z = -Infinity, poolE = 0;
    const terms = [];
    for (const [k, w] of total) { const lw = w + lchoose(F, K.R - k); if (lw === -Infinity) continue; terms.push([k, lw]); Z = logAdd(Z, lw); }
    if (Z === -Infinity) return probsSimple(s, K); // inconsistent (should not happen) → fallback
    for (const [k, lw] of terms) poolE += Math.exp(lw - Z) * (K.R - k);
    for (const j of pool) p[j] = F ? poolE / F : 0;
    exact.forEach((e, ei) => {
      const others = conv(exact.filter((_, x) => x !== ei));
      const marg = new Float64Array(e.vars.length);
      for (const [k2, ent] of e.cnt) for (const [k1, w1] of others) {
        const lw = w1 + lchoose(F, K.R - k1 - k2); if (lw === -Infinity) continue;
        const f = Math.exp(lw - Z);
        for (let i = 0; i < e.vars.length; i++) marg[i] += f * ent.ones[i];
      }
      e.vars.forEach((v, i) => { p[v] = Math.min(1, marg[i]); });
    });
    // refine approximated vars with local + row constraints, keep exact ones fixed-ish
    if (approxVars.length || K.cons.some((c) => c.row)) {
      const fixed = new Set(inExact);
      for (let it = 0; it < 6; it++) for (const c of K.cons) {
        let sumF = 0, sumA = 0; const free = [];
        for (const j of c.v) { if (fixed.has(j) && !c.row) sumF += p[j]; else { sumA += p[j]; free.push(j); } }
        const need = c.t - sumF;
        if (!free.length) continue;
        if (sumA <= 1e-9) { if (need > 0) for (const j of free) p[j] = need / free.length; continue; }
        const f = Math.max(0, need) / sumA;
        for (const j of free) p[j] = Math.min(1, p[j] * f);
      }
    }
    return p;
  }
  function logAdd(a, b) { if (a === -Infinity) return b; if (b === -Infinity) return a; const m = Math.max(a, b); return m + Math.log(Math.exp(a - m) + Math.exp(b - m)); }

  function remainingInfo(s, K, seat) {
    // expected value of a remaining 'treasure-like' cell (미믹 포함), traps/tools left (public counts)
    const nT = [0, 0, 0, 0]; const all = s.tot[0];
    const chest = Math.max(1, Math.round(all * 0.15)), gold = Math.round(all * 0.35), coin = all - chest - gold;
    const gone = {}; // 판 것 + 묻힌 것(공개)
    for (let i = 0; i < s.N * s.N; i++) { const c = dugCode(s, i); if (c >= 0) gone[c] = (gone[c] || 0) + 1; }
    for (const [, cj] of s.cv || []) gone[cj] = (gone[cj] || 0) + 1;
    nT[1] = coin - (gone[1] || 0); nT[2] = gold - (gone[2] || 0); nT[3] = chest - (gone[3] || 0);
    const mim = Math.max(0, mimicN(s) - (gone[12] || 0));
    const R = nT[1] + nT[2] + nT[3] + mim;
    const avg = R ? (nT[1] * 2 + nT[2] * 5 + nT[3] * 10 - mim * (MIMIC_PTS + 1.2)) / R : 0;
    // 함정(미믹 빼고) 종류별로 남은 수 × 벌칙 크기
    const tc = s.tc || { 4: Math.ceil(s.tot[1] / 2), 5: Math.floor(s.tot[1] / 2) };
    let minO = Infinity; for (let k = 0; k < s.n; k++) if (k !== seat) minO = Math.min(minO, s.pts[k]);
    const pen = { 4: TRAP_PTS, 5: s.tn[seat] + 1 >= s.lim ? 0 : 1.6, 9: DART_PTS + 0.6, 10: s.n === 1 ? CURSE_SOLO : s.pts[seat] > minO ? s.pts[seat] - minO : CURSE_PTS, 11: 0.8 };
    let trapsLeft = 0, penSum = 0;
    for (const c of [4, 5, 9, 10, 11]) { const l = Math.max(0, (tc[c] || 0) - (gone[c] || 0)); trapsLeft += l; penSum += l * pen[c]; }
    let toolsDug = 0; for (const c of [6, 7, 8]) toolsDug += gone[c] || 0;
    return { avg, trapsLeft, pen: trapsLeft ? penSum / trapsLeft : 0, toolsLeft: s.tot[2] * 3 - toolsDug };
  }
  function bestDig(s, seat, lv, p, K) {
    const info = remainingInfo(s, K, seat);
    const nonT = Math.max(1, K.unk.length - K.R);
    let best = K.unk[0], bs = -1e9;
    // AI 성향: 도박형은 함정 위험을 덜 따지고 보물 확률 높은 칸에 덤빔, 수비형은 위험한 칸을 더 피함
    const sty = (L.aiStyle && L.aiStyle(seat)) || 'bal', on = Math.random() < 0.7;
    const trapK = !on ? 1 : sty === 'gamble' ? 0.5 : sty === 'agg' ? 0.8 : sty === 'def' ? 1.4 : 1;
    for (const j of K.unk) {
      const pt = p[j];
      const rest = 1 - pt;
      const qTrap = rest * info.trapsLeft / nonT, qTool = rest * info.toolsLeft / nonT;
      let ev = pt * info.avg - qTrap * info.pen * trapK + qTool * 1.5;
      const soil = s.tr[j];
      if (soil === ',' && !s.wb && lv >= 2) ev += 0.6; // 젖은 모래: 한 번 더 팔 수 있어요
      if (soil === ':' && lv >= 2) ev -= s.dl >= 2 && s.dd === 0 ? 1.2 : 0.15; // 자갈땅: 삽 차례가 끝나고 숫자도 안 나와요
      if (lv === 3 && pt > 0.02 && pt < 0.98) { // small bonus for informative digs next to unknowns
        let u = 0; for (const k of nbList(s.N).n8[j]) if (K.isU[k]) u++;
        ev += 0.04 * u * (1 - Math.abs(0.5 - pt) * 2) * (s.n > 1 ? 0.5 : 1);
      }
      if (lv === 2) ev += (Math.random() - 0.5) * 0.5;
      if (ev > bs) { bs = ev; best = j; }
    }
    return { i: best, ev: bs };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.end || seat !== s.t) return null;
    const K = knowledge(s);
    if (!K.unk.length) return null;
    const tl = (s.psn && s.psn[seat]) ? [0, 0, 0] : s.tl[seat]; // 독침에 맞으면 도구를 못 써요
    if (lv === 1) {
      if (tl[1] > 0 && s.dd === 0 && s.dl === 1 && Math.random() < 0.5) return { a: 'shovel' };
      if (tl[0] > 0 && Math.random() < 0.15) return { a: 'scan', i: K.unk[U.rand(K.unk.length)] };
      if (tl[2] > 0 && Math.random() < 0.15) { const rows = [...Array(s.N).keys()].filter((r) => !s.rw.some((x) => x[0] === r)); if (rows.length) return { a: 'map', r: rows[U.rand(rows.length)] }; }
      if (Math.random() < 0.55) return { a: 'dig', i: K.unk[U.rand(K.unk.length)] };
      const p = probsSimple(s, K);
      let best = K.unk[0], bs = -1;
      for (const j of K.unk) { const v = p[j] + Math.random() * 0.35; if (v > bs) { bs = v; best = j; } }
      return { a: 'dig', i: best };
    }
    const p = lv === 3 ? probsExact(s, K) : probsLocal(s, K);
    if (tl[1] > 0 && s.dd === 0 && s.dl === 1) return { a: 'shovel' };
    const bd = bestDig(s, seat, lv, p, K);
    let maxP = 0; for (const j of K.unk) maxP = Math.max(maxP, p[j]);
    if (tl[0] > 0 && (lv === 2 ? Math.random() < 0.35 : maxP < 0.6)) {
      // detector: centre with the most uncertainty in its 3×3
      let bi = -1, bv = -1;
      for (let i = 0; i < s.N * s.N; i++) {
        if (s.tr[i] === '~') continue;
        let v = 0; for (const j of nbList(s.N).n9[i]) if (K.isU[j]) v += p[j] * (1 - p[j]) + p[j] * 0.3;
        if (lv === 2) v += Math.random() * 0.3;
        if (v > bv) { bv = v; bi = i; }
      }
      if (bi >= 0 && bv > 0.4) return { a: 'scan', i: bi };
    }
    if (tl[2] > 0 && (lv === 2 ? Math.random() < 0.3 : maxP < 0.5)) {
      let br = -1, bv = -1;
      for (let r = 0; r < s.N; r++) {
        if (s.rw.some((x) => x[0] === r)) continue;
        let v = 0; for (let x = 0; x < s.N; x++) { const j = r * s.N + x; if (K.isU[j]) v += p[j] * (1 - p[j]); }
        if (v > bv) { bv = v; br = r; }
      }
      if (br >= 0 && bv > 0.5) return { a: 'map', r: br };
    }
    return { a: 'dig', i: bd.i };
  }
  function aiDelayFor(s, seat, lv) { return lv === 1 ? 750 : lv === 3 ? 420 : 560; }

  /* ---------------- view ---------------- */
  const HINTC = ['#000', '#5bb3e6', '#5fd3a0', '#e8c04e', '#ee6a55', '#b48cf0', '#f07fb8', '#f2e9d8', '#f2e9d8'];
  // 맵별 색·질감. gr = 땅 그라데이션(위/아래 RGB), pit = 판 구덩이(테두리/가운데/가장자리), tree = 나무 모양
  const TH = {
    sand: { sea: ['#123a4f', '#0b2636'], wave: 'rgba(160,220,240,.10)', halo: 'rgba(90,190,200,.20)', foam: '240,250,245', gr: [[230, 208, 154], [208, 184, 128]], vr: 16, sp: 'rgba(120,90,50,.25)', line: 'rgba(120,85,40,.18)', pit: ['#c9a56b', '#7a5a34', '#a8834f'], rock: ['#a9a3b0', '#5b5563'], tree: 'palm' },
    jungle: { sea: ['#0d3a3c', '#062226'], wave: 'rgba(150,230,200,.10)', halo: 'rgba(70,180,140,.24)', foam: '220,245,225', gr: [[116, 166, 78], [86, 134, 58]], vr: 14, sp: 'rgba(40,80,25,.35)', line: 'rgba(30,60,20,.24)', pit: ['#6b5434', '#2c2014', '#4d3b24'], rock: ['#8f9a8a', '#4b5548'], tree: 'leaf' },
    volcano: { sea: ['#1e1c28', '#0b0b12'], wave: 'rgba(240,160,130,.08)', halo: 'rgba(210,90,60,.16)', foam: '225,215,210', gr: [[110, 99, 96], [82, 73, 71]], vr: 12, sp: 'rgba(20,14,14,.4)', line: 'rgba(15,8,8,.3)', pit: ['#4a3c38', '#1a1210', '#382c28'], rock: ['#4a4248', '#18141a'], tree: 'dead' },
    snow: { sea: ['#14304a', '#091a2b'], wave: 'rgba(200,230,255,.12)', halo: 'rgba(170,215,240,.24)', foam: '250,252,255', gr: [[242, 247, 252], [210, 223, 236]], vr: 8, sp: 'rgba(150,180,215,.4)', line: 'rgba(90,120,160,.22)', pit: ['#b7c6d4', '#36343c', '#66626c'], rock: ['#eef6ff', '#8eb1cc'], tree: 'pine' },
    arch: { sea: ['#0f5470', '#08304a'], wave: 'rgba(170,240,250,.12)', halo: 'rgba(80,215,205,.28)', foam: '245,252,250', gr: [[198, 206, 130], [170, 180, 102]], vr: 16, sp: 'rgba(90,100,40,.3)', line: 'rgba(70,80,30,.22)', pit: ['#b59a62', '#5e4528', '#8d7244'], rock: ['#b0aab4', '#5f5968'], tree: 'palm' },
    ruins: { sea: ['#1a3542', '#0e1f28'], wave: 'rgba(170,210,220,.09)', halo: 'rgba(110,180,180,.18)', foam: '235,240,235', gr: [[192, 182, 158], [164, 154, 132]], vr: 12, sp: 'rgba(80,70,50,.3)', line: 'rgba(70,60,45,.5)', pit: ['#8a7a5c', '#33281a', '#5e4f38'], rock: ['#cfc3a8', '#7f745e'], tree: 'leaf' },
    swamp: { sea: ['#24311f', '#10170e'], wave: 'rgba(190,210,160,.07)', halo: 'rgba(120,150,80,.20)', foam: '190,205,170', gr: [[114, 112, 68], [88, 86, 52]], vr: 12, sp: 'rgba(40,40,20,.38)', line: 'rgba(30,30,10,.3)', pit: ['#4c4228', '#1a160c', '#362e1a'], rock: ['#7d806e', '#3d4034'], tree: 'dead' },
    atoll: { sea: ['#0a4270', '#04203d'], wave: 'rgba(180,230,255,.12)', halo: 'rgba(90,230,220,.32)', foam: '250,255,255', gr: [[246, 236, 208], [228, 214, 180]], vr: 10, sp: 'rgba(190,160,110,.32)', line: 'rgba(150,120,70,.16)', pit: ['#d8c090', '#86683c', '#b89a66'], rock: ['#f4a0a0', '#c0566a'], tree: 'palm' },
    wild: { sea: ['#0e4a5c', '#06283a'], wave: 'rgba(170,235,240,.11)', halo: 'rgba(80,205,190,.26)', foam: '245,252,248', gr: [[214, 196, 140], [188, 168, 112]], vr: 16, sp: 'rgba(110,85,45,.28)', line: 'rgba(110,80,40,.18)', pit: ['#b8955c', '#5e4426', '#8f7042'], rock: ['#a6a0a8', '#56505c'], tree: 'palm' },
    skull: { sea: ['#251a35', '#100a19'], wave: 'rgba(200,170,240,.08)', halo: 'rgba(150,110,200,.18)', foam: '215,205,232', gr: [[172, 166, 170], [142, 136, 144]], vr: 12, sp: 'rgba(60,40,70,.32)', line: 'rgba(40,25,50,.3)', pit: ['#7a7076', '#1e1622', '#4e4450'], rock: ['#9a94a0', '#55505c'], tree: 'dead' },
  };
  const hash01 = (i, k) => ((Math.imul(i + 1, 2654435761) ^ Math.imul(k + 7, 40503)) >>> 0) / 4294967296;
  function rrp(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  // one tile of a smooth blob: square where it touches the same liquid, rounded/expanded (e) on open sides
  function blobTile(g, x, y, c, s, e, r) {
    const l = x - (s[3] ? 0.5 : e), t = y - (s[0] ? 0.5 : e), R2 = x + c + (s[1] ? 0.5 : e), b = y + c + (s[2] ? 0.5 : e);
    const tl = !s[0] && !s[3] ? r : 0, tr = !s[0] && !s[1] ? r : 0, br = !s[2] && !s[1] ? r : 0, bl = !s[2] && !s[3] ? r : 0;
    g.beginPath(); g.moveTo(l + tl, t);
    g.arcTo(R2, t, R2, b, tr); g.arcTo(R2, b, l, b, br); g.arcTo(l, b, l, t, bl); g.arcTo(l, t, R2, t, tl);
    g.closePath(); g.fill();
  }
  function dot(g, x, y, r) { g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); }

  /* -- ground (one land cell) -- */
  function paintGround(g, T, k, x, y, c, i, dug) {
    if (dug) {
      g.fillStyle = T.pit[0]; g.fillRect(x, y, c + 0.5, c + 0.5);
      const gr = g.createRadialGradient(x + c / 2, y + c / 2, c * 0.1, x + c / 2, y + c / 2, c * 0.55);
      gr.addColorStop(0, T.pit[1]); gr.addColorStop(1, T.pit[2]);
      g.fillStyle = gr; g.beginPath(); g.ellipse(x + c / 2, y + c / 2 + c * 0.03, c * 0.42, c * 0.38, 0, 0, 7); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 1; g.stroke();
      // a few clods thrown on the rim
      g.fillStyle = T.pit[2];
      for (let q = 0; q < 3; q++) { const a = hash01(i, q + 20) * 6.28; dot(g, x + c / 2 + Math.cos(a) * c * 0.44, y + c / 2 + Math.sin(a) * c * 0.42, c * 0.05); }
      return;
    }
    const h = hash01(i, 1), v = (h - 0.5) * T.vr, a = T.gr[0], b = T.gr[1];
    const gr = g.createLinearGradient(x, y, x, y + c);
    gr.addColorStop(0, `rgb(${a[0] + v | 0},${a[1] + v | 0},${a[2] + v | 0})`); gr.addColorStop(1, `rgb(${b[0] + v | 0},${b[1] + v | 0},${b[2] + v | 0})`);
    g.fillStyle = gr; g.fillRect(x, y, c + 0.5, c + 0.5);
    const H = (n) => hash01(i, n), lw = Math.max(1, c * 0.05);
    if (k === 'ruins') { // paving slab with bevel, cracks and moss
      g.strokeStyle = 'rgba(255,250,235,.28)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + 1.5, y + c - 2); g.lineTo(x + 1.5, y + 1.5); g.lineTo(x + c - 2, y + 1.5); g.stroke();
      g.strokeStyle = 'rgba(60,50,35,.35)'; g.beginPath(); g.moveTo(x + c - 1.5, y + 2); g.lineTo(x + c - 1.5, y + c - 1.5); g.lineTo(x + 2, y + c - 1.5); g.stroke();
      if (h > 0.8) { g.strokeStyle = 'rgba(60,50,35,.45)'; g.beginPath(); g.moveTo(x + c * (0.2 + H(3) * 0.6), y + 2); g.lineTo(x + c * (0.3 + H(7) * 0.4), y + c * (0.3 + H(8) * 0.4)); g.lineTo(x + 2, y + c * (0.3 + H(4) * 0.6)); g.stroke(); }
      if (H(5) > 0.7) { g.fillStyle = 'rgba(96,140,70,.55)'; const mx = x + (H(6) > 0.5 ? c * 0.2 : c * 0.8), my = y + c * 0.82; dot(g, mx, my, c * 0.11); dot(g, mx + c * 0.1, my - c * 0.05, c * 0.07); }
      return;
    }
    g.fillStyle = T.sp;
    for (let q = 0; q < 3; q++) dot(g, x + c * H(q + 3), y + c * H(q + 9), c * 0.035);
    if (k === 'sand' || k === 'arch') {
      if (h > 0.78) tuft(g, x + c * 0.3, y + c * 0.72, c, k === 'arch' ? 'rgba(60,120,50,.8)' : 'rgba(70,130,60,.75)', lw);
      else if (h < 0.05) shell(g, x + c * 0.65, y + c * 0.6, c);
    } else if (k === 'jungle') {
      if (h > 0.45) { tuft(g, x + c * 0.28, y + c * 0.75, c, 'rgba(40,95,30,.8)', lw); if (h > 0.75) tuft(g, x + c * 0.72, y + c * 0.45, c, 'rgba(50,110,35,.75)', lw); }
      if (H(12) < 0.1) { g.fillStyle = H(13) > 0.5 ? '#e8505a' : '#f2c94c'; for (let q = 0; q < 5; q++) { const an = q * 1.257; dot(g, x + c * 0.62 + Math.cos(an) * c * 0.06, y + c * 0.32 + Math.sin(an) * c * 0.06, c * 0.045); } g.fillStyle = '#fff3c4'; dot(g, x + c * 0.62, y + c * 0.32, c * 0.035); }
    } else if (k === 'volcano') {
      if (h < 0.22) { g.strokeStyle = 'rgba(25,15,15,.55)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + c * H(14), y + c * 0.15); g.lineTo(x + c * (0.3 + H(18) * 0.4), y + c * (0.4 + H(19) * 0.2)); g.lineTo(x + c * 0.85, y + c * H(15)); g.stroke(); }
      if (h > 0.82) { g.fillStyle = 'rgba(255,120,50,.35)'; dot(g, x + c * 0.7, y + c * 0.3, c * 0.09); g.fillStyle = '#ffb04a'; dot(g, x + c * 0.7, y + c * 0.3, c * 0.035); }
    } else if (k === 'snow') {
      g.fillStyle = 'rgba(160,190,220,.22)'; g.fillRect(x, y + c * 0.84, c + 0.5, c * 0.16);
      if (h > 0.66) { g.strokeStyle = 'rgba(255,255,255,.95)'; g.lineWidth = 1; const sx = x + c * H(16), sy = y + c * (0.2 + H(17) * 0.5), r = c * 0.07; g.beginPath(); g.moveTo(sx - r, sy); g.lineTo(sx + r, sy); g.moveTo(sx, sy - r); g.lineTo(sx, sy + r); g.stroke(); }
    } else if (k === 'swamp') {
      if (h > 0.8) { g.strokeStyle = 'rgba(40,38,20,.4)'; g.lineWidth = 1; g.beginPath(); g.ellipse(x + c * 0.55, y + c * 0.6, c * 0.22, c * 0.09, 0, 0, 7); g.stroke(); }
      if (h < 0.14) { g.strokeStyle = 'rgba(70,90,40,.9)'; g.lineWidth = lw; g.beginPath(); g.moveTo(x + c * 0.3, y + c * 0.85); g.lineTo(x + c * 0.28, y + c * 0.35); g.moveTo(x + c * 0.4, y + c * 0.85); g.lineTo(x + c * 0.44, y + c * 0.42); g.stroke(); g.fillStyle = '#5a3a1e'; g.fillRect(x + c * 0.25, y + c * 0.3, c * 0.07, c * 0.16); }
    } else if (k === 'atoll') {
      if (h < 0.07) starfish(g, x + c * 0.6, y + c * 0.55, c * 0.17);
      else if (h > 0.88) shell(g, x + c * 0.4, y + c * 0.6, c);
    } else if (k === 'skull') {
      if (h < 0.07) { g.strokeStyle = '#e8e0cf'; g.lineWidth = Math.max(1.5, c * 0.07); g.beginPath(); g.moveTo(x + c * 0.3, y + c * 0.65); g.lineTo(x + c * 0.7, y + c * 0.45); g.stroke(); g.fillStyle = '#e8e0cf'; for (const [px, py] of [[0.3, 0.65], [0.7, 0.45]]) { dot(g, x + c * px - c * 0.03, y + c * py - c * 0.04, c * 0.05); dot(g, x + c * px + c * 0.03, y + c * py + c * 0.04, c * 0.05); } }
      if (h > 0.8) { g.strokeStyle = 'rgba(40,25,50,.45)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + c * 0.15, y + c * 0.3); g.lineTo(x + c * 0.45, y + c * 0.45); g.lineTo(x + c * 0.55, y + c * 0.8); g.stroke(); }
    }
    g.strokeStyle = T.line; g.lineWidth = 1; g.strokeRect(x + 0.5, y + 0.5, c - 1, c - 1);
  }
  function tuft(g, gx, gy, c, col, lw) { g.strokeStyle = col; g.lineWidth = lw; g.beginPath(); g.moveTo(gx, gy); g.lineTo(gx - c * 0.08, gy - c * 0.2); g.moveTo(gx, gy); g.lineTo(gx + c * 0.02, gy - c * 0.25); g.moveTo(gx, gy); g.lineTo(gx + c * 0.1, gy - c * 0.18); g.stroke(); }
  function shell(g, sx, sy, c) {
    g.fillStyle = '#fbf1e2'; g.beginPath(); g.arc(sx, sy, c * 0.1, Math.PI, 0); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(180,130,100,.7)'; g.lineWidth = 0.8; g.beginPath(); for (let q = -2; q <= 2; q++) { g.moveTo(sx, sy); g.lineTo(sx + q * c * 0.045, sy - c * 0.09); } g.stroke();
  }
  function starfish(g, sx, sy, r) {
    g.fillStyle = '#ef7e6a'; g.beginPath();
    for (let q = 0; q < 10; q++) { const a = -Math.PI / 2 + q * Math.PI / 5, rr = q % 2 ? r * 0.42 : r; g.lineTo(sx + Math.cos(a) * rr, sy + Math.sin(a) * rr); }
    g.closePath(); g.fill(); g.fillStyle = 'rgba(255,220,200,.7)'; dot(g, sx, sy, r * 0.15);
  }

  /* -- liquids (lava, ice lake, pools/lagoon): drawn as one rounded blob, then per-cell details -- */
  function liqStyle(k, ch) {
    if (ch === 'R') return ['#e9dcb0', '#3f9fb8'];
    if (ch === 'L') return ['#2a120c', '#ff6a20'];
    if (ch === 'F') return ['#ffffff', '#b8e1f3'];
    if (k === 'atoll') return ['#fff6dc', '#5fd3cf'];
    if (k === 'skull') return ['#6a4a8a', '#130c1c'];
    return ['#3a3620', '#3b4d2b'];
  }
  function paintLiquid(g, k, ch, x, y, c, i) {
    const h = hash01(i, 2), H = (n) => hash01(i, n);
    if (ch === 'L') {
      const gr = g.createRadialGradient(x + c / 2, y + c / 2, 0, x + c / 2, y + c / 2, c * 0.5);
      gr.addColorStop(0, 'rgba(255,214,90,.95)'); gr.addColorStop(1, 'rgba(255,140,40,0)');
      g.fillStyle = gr; g.fillRect(x, y, c, c);
      g.fillStyle = 'rgba(60,20,12,.85)'; // small cooled crust plates
      for (let q = 0; q < 2; q++) {
        const px = x + c * (0.15 + H(q + 30) * 0.6), py = y + c * (0.15 + H(q + 32) * 0.6), s = c * (0.1 + H(q + 34) * 0.08);
        g.beginPath(); g.moveTo(px - s, py - s * 0.4); g.lineTo(px - s * 0.2, py - s); g.lineTo(px + s, py - s * 0.3); g.lineTo(px + s * 0.6, py + s * 0.8); g.lineTo(px - s * 0.7, py + s * 0.6); g.closePath(); g.fill();
      }
      g.strokeStyle = 'rgba(255,240,170,.8)'; g.lineWidth = Math.max(1, c * 0.035); g.beginPath();
      g.moveTo(x + c * H(36), y + c * 0.2); g.lineTo(x + c * 0.5, y + c * H(37)); g.lineTo(x + c * H(38), y + c * 0.85); g.stroke();
    } else if (ch === 'R') { // river: current lines
      g.strokeStyle = 'rgba(220,245,255,.45)'; g.lineWidth = Math.max(1, c * 0.04);
      g.beginPath(); g.moveTo(x + c * 0.15, y + c * (0.3 + h * 0.2)); g.quadraticCurveTo(x + c * 0.5, y + c * (0.15 + h * 0.2), x + c * 0.85, y + c * (0.35 + h * 0.2)); g.stroke();
      if (h > 0.5) { g.beginPath(); g.moveTo(x + c * 0.25, y + c * 0.72); g.quadraticCurveTo(x + c * 0.5, y + c * 0.6, x + c * 0.7, y + c * 0.75); g.stroke(); }
    } else if (ch === 'F') {
      g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = Math.max(1, c * 0.05);
      if (h > 0.35) { g.beginPath(); g.moveTo(x + c * 0.2, y + c * 0.55); g.lineTo(x + c * 0.5, y + c * 0.25); g.moveTo(x + c * 0.35, y + c * 0.7); g.lineTo(x + c * 0.6, y + c * 0.45); g.stroke(); }
      if (h < 0.4) { g.strokeStyle = 'rgba(70,120,160,.5)'; g.lineWidth = 1; g.beginPath(); g.moveTo(x + c * 0.1, y + c * 0.3); g.lineTo(x + c * 0.45, y + c * 0.5); g.lineTo(x + c * 0.4, y + c * 0.9); g.moveTo(x + c * 0.45, y + c * 0.5); g.lineTo(x + c * 0.9, y + c * 0.6); g.stroke(); }
    } else if (k === 'atoll') { // lagoon
      g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1;
      g.beginPath(); g.arc(x + c * (0.3 + h * 0.4), y + c * 0.5, c * 0.2, Math.PI * 1.1, Math.PI * 1.9); g.stroke();
      if (h > 0.6) { g.fillStyle = 'rgba(240,120,130,.55)'; dot(g, x + c * 0.25, y + c * 0.75, c * 0.06); dot(g, x + c * 0.32, y + c * 0.8, c * 0.04); }
      else if (h < 0.2) { g.fillStyle = 'rgba(255,255,255,.25)'; dot(g, x + c * 0.6, y + c * 0.3, c * 0.12); }
    } else if (k === 'skull') { // bottomless pit
      if (h > 0.8) { g.fillStyle = 'rgba(255,70,90,.75)'; dot(g, x + c * 0.4, y + c * 0.5, c * 0.04); dot(g, x + c * 0.6, y + c * 0.5, c * 0.04); }
      else if (h < 0.25) { g.strokeStyle = 'rgba(150,110,200,.35)'; g.lineWidth = 1; g.beginPath(); g.arc(x + c / 2, y + c / 2, c * 0.22, 0, 7); g.stroke(); }
    } else { // swamp pool
      if (h > 0.5) {
        g.fillStyle = '#6f9a44'; g.beginPath(); g.moveTo(x + c * 0.45, y + c * 0.5); g.arc(x + c * 0.45, y + c * 0.5, c * 0.2, 0.5, Math.PI * 2 - 0.1); g.closePath(); g.fill();
        if (h > 0.8) { g.fillStyle = '#f0a6c4'; dot(g, x + c * 0.5, y + c * 0.45, c * 0.06); }
      }
      g.fillStyle = 'rgba(200,220,170,.35)'; dot(g, x + c * 0.75, y + c * 0.25, c * 0.04); dot(g, x + c * 0.2, y + c * 0.8, c * 0.03);
    }
  }

  /* -- standing features -- */
  function shadow(g, x, y, c, w) { g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(x + c * 0.52, y + c * 0.8, c * w, c * 0.12, 0, 0, 7); g.fill(); }
  function paintRock(g, T, k, x, y, c, i) {
    const h = hash01(i, 4);
    if (k === 'skull') { // tombstone
      shadow(g, x, y, c, 0.32);
      g.fillStyle = '#8d8796'; rrp(g, x + c * 0.25, y + c * 0.2, c * 0.5, c * 0.62, c * 0.22); g.fill();
      g.fillStyle = '#6c6676'; g.fillRect(x + c * 0.25, y + c * 0.62, c * 0.5, c * 0.2);
      g.strokeStyle = '#3b3546'; g.lineWidth = Math.max(1, c * 0.06); g.beginPath(); g.moveTo(x + c / 2, y + c * 0.3); g.lineTo(x + c / 2, y + c * 0.58); g.moveTo(x + c * 0.38, y + c * 0.4); g.lineTo(x + c * 0.62, y + c * 0.4); g.stroke();
      return;
    }
    if (k === 'atoll') { // coral head
      g.strokeStyle = h > 0.5 ? '#f08a8a' : '#e9a0d0'; g.lineCap = 'round'; g.lineWidth = Math.max(2, c * 0.11);
      g.beginPath(); const bx = x + c / 2, by = y + c * 0.8;
      g.moveTo(bx, by); g.lineTo(bx, by - c * 0.4); g.moveTo(bx, by - c * 0.2); g.lineTo(bx - c * 0.22, by - c * 0.45); g.moveTo(bx, by - c * 0.25); g.lineTo(bx + c * 0.24, by - c * 0.5); g.moveTo(bx - c * 0.12, by - c * 0.33); g.lineTo(bx - c * 0.3, by - c * 0.3);
      g.stroke(); g.lineCap = 'butt';
      return;
    }
    if (k === 'ruins') { // fallen blocks
      shadow(g, x, y, c, 0.36);
      g.fillStyle = '#b3a78c'; g.fillRect(x + c * 0.14, y + c * 0.48, c * 0.42, c * 0.3);
      g.fillStyle = '#c9bea4'; g.save(); g.translate(x + c * 0.62, y + c * 0.45); g.rotate(0.35 + h * 0.4); g.fillRect(-c * 0.18, -c * 0.14, c * 0.36, c * 0.28); g.restore();
      g.strokeStyle = 'rgba(60,50,35,.5)'; g.lineWidth = 1; g.strokeRect(x + c * 0.14, y + c * 0.48, c * 0.42, c * 0.3);
      return;
    }
    shadow(g, x, y, c, 0.38);
    const gr = g.createRadialGradient(x + c * 0.4, y + c * 0.35, c * 0.05, x + c / 2, y + c / 2, c * 0.5);
    gr.addColorStop(0, T.rock[0]); gr.addColorStop(1, T.rock[1]);
    g.fillStyle = gr; g.beginPath();
    g.moveTo(x + c * 0.15, y + c * 0.75); g.lineTo(x + c * (0.2 + h * 0.06), y + c * 0.35); g.lineTo(x + c * 0.48, y + c * (0.14 + h * 0.06)); g.lineTo(x + c * 0.78, y + c * 0.3); g.lineTo(x + c * 0.86, y + c * 0.72); g.closePath(); g.fill();
    g.strokeStyle = 'rgba(30,25,35,.6)'; g.lineWidth = 1; g.stroke();
    if (k === 'snow') { g.fillStyle = '#ffffff'; g.beginPath(); g.moveTo(x + c * 0.24, y + c * 0.36); g.lineTo(x + c * 0.48, y + c * 0.17); g.lineTo(x + c * 0.76, y + c * 0.31); g.quadraticCurveTo(x + c * 0.5, y + c * 0.42, x + c * 0.24, y + c * 0.36); g.fill(); }
    else if (k === 'volcano') { g.strokeStyle = 'rgba(255,110,40,.85)'; g.lineWidth = Math.max(1, c * 0.04); g.beginPath(); g.moveTo(x + c * 0.35, y + c * 0.7); g.lineTo(x + c * 0.48, y + c * 0.45); g.lineTo(x + c * 0.62, y + c * 0.55); g.stroke(); }
    else if (k === 'swamp' || k === 'jungle') { g.fillStyle = 'rgba(90,130,60,.7)'; dot(g, x + c * 0.4, y + c * 0.3, c * 0.08); dot(g, x + c * 0.52, y + c * 0.26, c * 0.06); }
  }
  function paintTree(g, T, k, x, y, c, i) {
    const h = hash01(i, 6), bx = x + c / 2, by = y + c * 0.82;
    const kind = T.tree;
    if (kind === 'leaf') {
      shadow(g, x, y, c, 0.44);
      g.fillStyle = '#5a3d22'; g.fillRect(bx - c * 0.05, by - c * 0.3, c * 0.1, c * 0.3);
      const cols = ['#1f4f22', '#2f6e2c', '#4b9a3a'];
      const blobs = [[-0.18, -0.42, 0.27], [0.18, -0.4, 0.26], [0, -0.58, 0.28], [0, -0.36, 0.3]];
      cols.forEach((col, ci) => { g.fillStyle = col; blobs.forEach(([dx, dy, r]) => dot(g, bx + c * (dx - ci * 0.03), by + c * (dy - ci * 0.05), c * r * (1 - ci * 0.28))); });
      if (h > 0.6) { g.fillStyle = '#e8505a'; dot(g, bx + c * 0.14, by - c * 0.48, c * 0.045); dot(g, bx - c * 0.1, by - c * 0.38, c * 0.04); }
    } else if (kind === 'palm') {
      shadow(g, x, y, c, 0.3);
      const lean = (h - 0.5) * 0.5, tx = bx + c * lean * 0.6, ty = by - c * 0.62;
      g.strokeStyle = '#8b6234'; g.lineWidth = Math.max(2, c * 0.1); g.lineCap = 'round';
      g.beginPath(); g.moveTo(bx, by); g.quadraticCurveTo(bx + c * lean * 0.1, by - c * 0.35, tx, ty); g.stroke();
      g.strokeStyle = '#2f7a3a'; g.lineWidth = Math.max(2, c * 0.09);
      for (let q = 0; q < 6; q++) { const a = -Math.PI / 2 + (q - 2.5) * 0.62; g.beginPath(); g.moveTo(tx, ty); g.quadraticCurveTo(tx + Math.cos(a) * c * 0.3, ty + Math.sin(a) * c * 0.3 - c * 0.1, tx + Math.cos(a) * c * 0.44, ty + Math.sin(a) * c * 0.34 + c * 0.08); g.stroke(); }
      g.lineCap = 'butt'; g.fillStyle = '#6b4a22'; dot(g, tx - c * 0.05, ty + c * 0.05, c * 0.05); dot(g, tx + c * 0.05, ty + c * 0.06, c * 0.05);
    } else if (kind === 'pine') {
      shadow(g, x, y, c, 0.32);
      g.fillStyle = '#5a3d22'; g.fillRect(bx - c * 0.05, by - c * 0.14, c * 0.1, c * 0.14);
      for (let q = 0; q < 3; q++) {
        const w = c * (0.36 - q * 0.08), ty = by - c * (0.12 + q * 0.2), hh = c * 0.32;
        g.fillStyle = '#2b5a46'; g.beginPath(); g.moveTo(bx - w, ty); g.lineTo(bx, ty - hh); g.lineTo(bx + w, ty); g.closePath(); g.fill();
        g.fillStyle = '#f4f9ff'; g.beginPath(); g.moveTo(bx - w * 0.45, ty - hh * 0.55); g.lineTo(bx, ty - hh); g.lineTo(bx + w * 0.45, ty - hh * 0.55); g.quadraticCurveTo(bx, ty - hh * 0.45, bx - w * 0.45, ty - hh * 0.55); g.fill();
      }
    } else { // dead tree / mangrove
      shadow(g, x, y, c, 0.3);
      g.strokeStyle = k === 'skull' ? '#2c2232' : '#3d3224'; g.lineCap = 'round'; g.lineWidth = Math.max(2, c * 0.09);
      g.beginPath(); g.moveTo(bx, by); g.lineTo(bx - c * 0.03, by - c * 0.45); g.lineTo(bx - c * 0.22, by - c * 0.66);
      g.moveTo(bx - c * 0.03, by - c * 0.4); g.lineTo(bx + c * 0.2, by - c * 0.62); g.lineTo(bx + c * 0.3, by - c * 0.58);
      g.moveTo(bx - c * 0.12, by - c * 0.55); g.lineTo(bx - c * 0.28, by - c * 0.5); g.stroke();
      g.lineWidth = Math.max(1, c * 0.04);
      if (k === 'swamp') { g.strokeStyle = 'rgba(120,150,80,.85)'; g.beginPath(); g.moveTo(bx + c * 0.18, by - c * 0.6); g.lineTo(bx + c * 0.17, by - c * 0.38); g.moveTo(bx - c * 0.2, by - c * 0.62); g.lineTo(bx - c * 0.21, by - c * 0.42); g.stroke(); }
      g.lineCap = 'butt';
    }
  }
  function paintPillar(g, x, y, c, i) {
    const h = hash01(i, 7), broken = h < 0.35;
    g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(x + c * 0.62, y + c * 0.72, c * 0.32, c * 0.16, -0.3, 0, 7); g.fill();
    g.fillStyle = '#9d927a'; g.fillRect(x + c * 0.16, y + c * 0.58, c * 0.68, c * 0.24); // plinth
    const top = broken ? y + c * 0.3 : y + c * 0.05;
    const gr = g.createLinearGradient(x + c * 0.28, 0, x + c * 0.72, 0);
    gr.addColorStop(0, '#b8ad92'); gr.addColorStop(0.4, '#efe6cf'); gr.addColorStop(1, '#9a8f76');
    g.fillStyle = gr; g.fillRect(x + c * 0.28, top, c * 0.44, y + c * 0.62 - top);
    g.strokeStyle = 'rgba(90,80,60,.45)'; g.lineWidth = 1; g.beginPath();
    for (let q = 1; q < 4; q++) { const lx = x + c * (0.28 + q * 0.11); g.moveTo(lx, top + 2); g.lineTo(lx, y + c * 0.6); } g.stroke();
    if (broken) { g.fillStyle = '#d8ceb4'; g.beginPath(); g.moveTo(x + c * 0.28, top); g.lineTo(x + c * 0.4, top - c * 0.08); g.lineTo(x + c * 0.52, top + c * 0.02); g.lineTo(x + c * 0.62, top - c * 0.1); g.lineTo(x + c * 0.72, top); g.closePath(); g.fill(); }
    else { g.fillStyle = '#d8ceb4'; g.fillRect(x + c * 0.22, top - c * 0.02, c * 0.56, c * 0.1); }
    if (h > 0.7) { g.fillStyle = 'rgba(96,140,70,.7)'; dot(g, x + c * 0.32, y + c * 0.55, c * 0.07); }
  }
  function paintWall(g, k, x, y, c, i) {
    const h = hash01(i, 8);
    if (k === 'skull') { // tooth
      g.fillStyle = 'rgba(0,0,0,.3)'; rrp(g, x + c * 0.16, y + c * 0.1, c * 0.72, c * 0.86, c * 0.2); g.fill();
      const gr = g.createLinearGradient(x, y, x + c, y);
      gr.addColorStop(0, '#d9d0bd'); gr.addColorStop(0.45, '#fffaf0'); gr.addColorStop(1, '#c7bda8');
      g.fillStyle = gr; rrp(g, x + c * 0.12, y + c * 0.04, c * 0.72, c * 0.86, c * 0.22); g.fill();
      g.strokeStyle = 'rgba(60,40,50,.6)'; g.lineWidth = 1; g.stroke();
      return;
    }
    g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(x + c * 0.08, y + c * 0.3, c * 0.92, c * 0.62);
    const top = y + c * (0.08 + h * 0.18);
    g.fillStyle = '#b7aa8c'; g.fillRect(x, top, c + 0.5, y + c * 0.84 - top);
    g.fillStyle = '#d3c7aa'; g.fillRect(x, top, c + 0.5, c * 0.1);
    g.strokeStyle = 'rgba(70,60,45,.55)'; g.lineWidth = 1; g.beginPath();
    for (let yy = top + c * 0.22, r = 0; yy < y + c * 0.82; yy += c * 0.22, r++) { g.moveTo(x, yy); g.lineTo(x + c, yy); const off = r % 2 ? c * 0.25 : c * 0.65; g.moveTo(x + off, yy); g.lineTo(x + off, yy - c * 0.22); }
    g.stroke();
    if (h > 0.6) { g.fillStyle = 'rgba(96,140,70,.75)'; dot(g, x + c * 0.2, top + c * 0.04, c * 0.08); dot(g, x + c * 0.32, top + c * 0.02, c * 0.06); }
  }
  function paintBridge(g, x, y, c, horiz) {
    g.save(); g.translate(x + c / 2, y + c / 2); if (!horiz) g.rotate(Math.PI / 2);
    const L2 = c * 0.56, W2 = c * 0.3;
    g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(-L2, -W2 + c * 0.1, L2 * 2, W2 * 2);
    g.fillStyle = '#9c7444'; g.fillRect(-L2, -W2, L2 * 2, W2 * 2);
    g.strokeStyle = 'rgba(60,40,20,.7)'; g.lineWidth = 1; g.beginPath();
    for (let q = -L2 + c * 0.16; q < L2; q += c * 0.16) { g.moveTo(q, -W2); g.lineTo(q, W2); } g.stroke();
    g.strokeStyle = '#d9c39a'; g.lineWidth = Math.max(1, c * 0.04);
    g.beginPath(); g.moveTo(-L2, -W2); g.lineTo(L2, -W2); g.moveTo(-L2, W2); g.lineTo(L2, W2); g.stroke();
    g.fillStyle = '#5a3d22'; for (const px of [-L2, L2]) for (const py of [-W2, W2]) dot(g, px, py, c * 0.06);
    g.restore();
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, B = null, sel = -1, mode = 'dig', waitSeq = -1, waitUntil = 0, dead = false;
    const onCancelEv = (e) => { if (sel >= 0 || mode !== 'dig') { sel = -1; mode = 'dig'; renderHud(); e.preventDefault(); } };
    window.addEventListener('lounge-cancel', onCancelEv);
    let anim = null, parts = [], pops = [], shake = 0, busyT = 0, stopLoop = null;
    let marks = new Map(); // 내 메모 (이 기기에만): 1 = ✕ 피할 칸, 2 = ★ 노릴 칸
    let layer = null, layerKey = '', lava = [], smokeAt = null, seaG = null, seaKey = '';
    const fog = {};

    const chips = L.h('div', { class: 'tr-chips', style: { display: 'flex', gap: '5px', flexWrap: 'wrap', justifyContent: 'center', width: '100%' } });
    const info = L.h('div', { class: 'mono tr-info', style: { fontSize: '11.5px', fontWeight: 600, color: 'var(--muted)', textAlign: 'center', marginTop: '4px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%' } });
    const top = L.h('div', { class: 'hud top', style: { padding: '6px 8px', flexDirection: 'column', gap: '0' } }, chips, info);
    const hint = L.h('div', { class: 'tr-hint', style: { fontSize: '12.5px', fontWeight: 700, textAlign: 'center', minHeight: '17px', lineHeight: 1.35, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
    const row = L.h('div', { class: 'tr-row', style: { display: 'flex', gap: '6px', flexWrap: 'nowrap' } });
    const panel = L.h('div', { class: 'panel', style: { padding: '7px 8px', width: '100%', maxWidth: '420px', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: '6px' } }, hint, row);
    const bot = L.h('div', { class: 'hud bottom', style: { padding: '6px 8px' } }, panel);
    root.append(top, bot);
    const bs = { minHeight: '44px', flex: '1 1 0', padding: '4px 4px', fontSize: '12.5px', whiteSpace: 'nowrap' };
    const scanBtn = L.h('button', { 'data-action': 'scan', class: 'btn sm', style: bs, onclick: () => toggleMode('scan') });
    const shovBtn = L.h('button', { 'data-action': 'shovel', class: 'btn sm', style: bs, onclick: onShovel });
    const mapBtn = L.h('button', { 'data-action': 'map', class: 'btn sm', style: bs, onclick: () => toggleMode('map') });
    const goBtn = L.h('button', { 'data-action': 'go', class: 'btn primary sm tr-go', style: Object.assign({}, bs, { flex: '1.4 1 0', fontSize: '13.5px' }), onclick: onGo });
    row.append(scanBtn, shovBtn, mapBtn, goBtn);

    const color = (i) => (api.players[i] ? api.players[i].color : L.COLORS[i % 6]);
    const myTurn = () => !!st && !st.end && api.canAct(st.t);
    const locked = () => st && st.seq === waitSeq && performance.now() < waitUntil;
    const theme = () => TH[mapOf(st).k] || TH.sand;
    function send(a) { waitSeq = st.seq; waitUntil = performance.now() + 3000; api.act(a); }

    function layout() {
      const t = top.offsetHeight + 4, b = bot.offsetHeight + 4;
      const W = cv.w, H = cv.h - t - b;
      const N = st.N;
      // fit the island's bounding box (plus a little sea), not the whole square
      let x0 = N, y0 = N, x1 = 0, y1 = 0;
      for (let i = 0; i < N * N; i++) if (st.tr[i] !== '~') { const x = i % N, y = (i / N) | 0; x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
      const cw = x1 - x0 + 1, ch = y1 - y0 + 1;
      const c = Math.floor(Math.min((W - 20) / (cw + 0.6), (H - 16) / (ch + 0.6), 52));
      B = { c, x: Math.round((W - c * cw) / 2) - x0 * c, y: Math.round(t + (H - c * ch) / 2) - y0 * c, N, bx: x0, by: y0, bw: cw, bh: ch };
    }
    const cellXY = (i) => [B.x + (i % B.N) * B.c, B.y + ((i / B.N) | 0) * B.c];
    function hitCell(x, y) {
      const cx = Math.floor((x - B.x) / B.c), cy = Math.floor((y - B.y) / B.c);
      if (cx < 0 || cy < 0 || cx >= B.N || cy >= B.N) return -1;
      return cy * B.N + cx;
    }

    function toggleMode(m) {
      if (!myTurn() || locked()) return;
      mode = mode === m ? 'dig' : m; sel = -1; api.sfx('click'); renderHud();
    }
    function onShovel() {
      if (!myTurn() || locked() || (st.psn && st.psn[st.t]) || st.tl[st.t][1] <= 0 || st.dd > 0 || st.dl !== 1) return;
      api.buzz(12); send({ a: 'shovel' }); renderHud();
    }
    function canTarget(i) {
      if (i < 0) return false;
      if (mode === 'dig') return undug(st, i);
      if (mode === 'scan') return st.tr[i] !== '~';
      if (mode === 'map') return !st.rw.some((x) => x[0] === ((i / st.N) | 0));
      return false;
    }
    function onGo() {
      if (!myTurn() || locked() || sel < 0 || !canTarget(sel)) return;
      api.buzz(15);
      if (mode === 'dig') send({ a: 'dig', i: sel });
      else if (mode === 'scan') send({ a: 'scan', i: sel });
      else send({ a: 'map', r: (sel / st.N) | 0 });
      sel = -1; mode = 'dig'; renderHud();
    }
    function tap(x, y) {
      if (!myTurn() || locked() || anim) return;
      const i = hitCell(x, y);
      if (!canTarget(i)) { if (sel >= 0) { sel = -1; renderHud(); } return; }
      if (i === sel || (mode === 'map' && sel >= 0 && ((sel / st.N) | 0) === ((i / st.N) | 0))) { onGo(); return; }
      sel = i; api.sfx('tick'); api.buzz(6); renderHud();
    }
    function toggleMark(i) {
      if (!st || st.end || i < 0 || !undug(st, i)) return false;
      const m = ((marks.get(i) || 0) + 1) % 3;
      if (m) marks.set(i, m); else marks.delete(i);
      api.sfx('click'); api.buzz(18);
      return true;
    }

    function renderHud() {
      if (!st) return;
      chips.innerHTML = '';
      for (let i = 0; i < st.n; i++) {
        const cur = !st.end && st.t === i;
        const t = st.tl[i];
        const tools = st.tk ? ` ${t[0] ? '◎' + t[0] : ''}${t[1] ? ' ⛏' + t[1] : ''}${t[2] ? ' ▤' + t[2] : ''}` : '';
        chips.append(L.h('span', { class: 'turn', style: { borderColor: cur ? color(i) : '', opacity: cur || st.end ? 1 : 0.7, maxWidth: st.n > 2 ? '46%' : '48%' } },
          L.h('span', { class: 'dot', style: { '--c': color(i) } }),
          L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' }, text: st.nm[i] }),
          L.h('b', { class: 'mono', style: { color: 'var(--brass)' }, text: String(st.pts[i]) }),
          tools ? L.h('span', { class: 'mono', style: { fontSize: '11px', color: 'var(--muted)' }, text: tools }) : null,
          st.skp[i] ? L.h('span', { style: { fontSize: '11px', color: 'var(--coral)' }, text: '쉼' }) : null,
          st.psn && st.psn[i] ? L.h('span', { style: { fontSize: '11px', color: '#7bd35a' }, text: '독' }) : null));
      }
      const left = st.tot[0] - st.f.length;
      info.textContent = `${mapOf(st).name} · 차례 ${Math.min(st.lim, st.tn[st.t] + (st.end ? 0 : 1))}/${st.lim} · 남은 보물 ${left - (st.lost || 0)}/${st.tot[0]} · 함정 ${st.tot[1]}`;
      const me = myTurn();
      const t = st.tl[st.t], pz = !!(st.psn && st.psn[st.t]);
      scanBtn.textContent = `◎ 탐지기 ${t[0]}`; scanBtn.disabled = !me || t[0] <= 0 || pz; scanBtn.classList.toggle('primary', mode === 'scan');
      shovBtn.textContent = st.dl === 2 ? '⛏ 두 번 파기' : `⛏ 삽 ${t[1]}`; shovBtn.disabled = !me || t[1] <= 0 || st.dd > 0 || st.dl !== 1 || pz; shovBtn.classList.toggle('primary', st.dl === 2);
      mapBtn.textContent = `▤ 지도 ${t[2]}`; mapBtn.disabled = !me || t[2] <= 0 || pz; mapBtn.classList.toggle('primary', mode === 'map');
      [scanBtn, shovBtn, mapBtn].forEach((b) => { b.style.display = st.tk ? '' : 'none'; });
      goBtn.textContent = mode === 'scan' ? '여기 탐지' : mode === 'map' ? '이 줄 보기' : st.dl >= 2 ? `파기 (${st.dl}번 남음)` : '파기';
      goBtn.disabled = !me || sel < 0 || !canTarget(sel) || locked();
      let txt = '';
      if (st.end) txt = '게임 끝!';
      else if (me) {
        if (mode === 'scan') txt = sel >= 0 ? '한 번 더 탭하면 탐지해요' : '탐지기: 가운데 칸 → 3×3 보물 수';
        else if (mode === 'map') txt = sel >= 0 ? '한 번 더 탭하면 이 줄을 봐요' : '지도 조각: 줄을 고르면 보물 수';
        else if (st.dl >= 2 || st.dd > 0) txt = st.dd ? '한 칸 더 파세요' : '삽 — 이번 차례에 두 칸을 파요';
        else if (pz && sel < 0) txt = '독침 때문에 이번 차례엔 도구를 못 써요';
        else txt = sel >= 0 ? '한 번 더 탭하면 파요 · 밀어서 옮기기' : '팔 칸을 탭 · 숫자 = 둘레 8칸 보물 수';
      } else txt = `${st.nm[st.t]} 차례 · 칸을 꾹 누르면 메모`;
      hint.textContent = txt; hint.style.color = me ? 'var(--ink)' : 'var(--muted)';
    }

    /* --- drawing --- */
    function rr(x, y, w, h, r) { rrp(ctx, x, y, w, h, r); }
    function drawSea(now) {
      const W = cv.w, H = cv.h, T = theme();
      const key = H + T.sea[0];
      if (seaKey !== key) { seaG = ctx.createLinearGradient(0, 0, 0, H); seaG.addColorStop(0, T.sea[0]); seaG.addColorStop(1, T.sea[1]); seaKey = key; }
      ctx.fillStyle = seaG; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = T.wave; ctx.lineWidth = 1.5;
      for (let y = 10; y < H; y += 22) {
        ctx.beginPath();
        for (let x = 0; x <= W; x += 12) { const yy = y + Math.sin(x / 26 + now / 900 + y) * 2.5; x ? ctx.lineTo(x, yy) : ctx.moveTo(x, yy); }
        ctx.stroke();
      }
      const k = mapOf(st).k;
      if (k === 'snow') { // drifting ice floes
        for (let j = 0; j < 8; j++) {
          const s = 8 + hash01(j, 31) * 14, x = ((hash01(j, 32) * (W + 80) + now * 0.006 * (0.5 + hash01(j, 33))) % (W + 80)) - 40, y = hash01(j, 34) * H;
          ctx.fillStyle = 'rgba(120,170,210,.5)'; ctx.beginPath(); ctx.ellipse(x + 1, y + 3, s, s * 0.45, 0, 0, 7); ctx.fill();
          ctx.fillStyle = 'rgba(240,248,255,.9)'; ctx.beginPath(); ctx.moveTo(x - s, y); ctx.lineTo(x - s * 0.3, y - s * 0.4); ctx.lineTo(x + s * 0.8, y - s * 0.3); ctx.lineTo(x + s, y + s * 0.15); ctx.lineTo(x - s * 0.2, y + s * 0.35); ctx.closePath(); ctx.fill();
        }
      } else if (k === 'atoll' || k === 'arch') { // sun glints
        ctx.fillStyle = '#ffffff';
        for (let j = 0; j < 16; j++) {
          const a = Math.pow(Math.max(0, Math.sin(now / 520 + j * 1.7)), 6); if (a < 0.05) continue;
          const x = hash01(j, 41) * W, y = hash01(j, 42) * H, r = 2.5 + hash01(j, 43) * 2.5;
          ctx.globalAlpha = a * 0.8; ctx.beginPath(); ctx.moveTo(x - r, y); ctx.lineTo(x, y - r * 0.35); ctx.lineTo(x + r, y); ctx.lineTo(x, y + r * 0.35); ctx.closePath(); ctx.fill();
        }
        ctx.globalAlpha = 1;
      } else if (k === 'volcano') { // red glow on the water around the island
        const cx = B.x + (B.bx + B.bw / 2) * B.c, cy = B.y + (B.by + B.bh / 2) * B.c, r = Math.max(B.bw, B.bh) * B.c * 0.75;
        const gr = ctx.createRadialGradient(cx, cy, r * 0.3, cx, cy, r);
        gr.addColorStop(0, `rgba(255,80,30,${0.16 + 0.04 * Math.sin(now / 700)})`); gr.addColorStop(1, 'rgba(255,80,30,0)');
        ctx.fillStyle = gr; ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
      }
    }
    function paintIsland(g) {
      const c = B.c, N = st.N, tr = st.tr, T = theme(), k = mapOf(st).k;
      const at = (x, y) => (x < 0 || y < 0 || x >= N || y >= N ? '~' : tr[y * N + x]);
      const solid = (ch) => ch !== '~' && ch !== 'B';
      g.fillStyle = T.halo;
      for (let i = 0; i < N * N; i++) if (solid(tr[i])) { const [x, y] = cellXY(i); rrp(g, x - c * 0.35, y - c * 0.35, c * 1.7, c * 1.7, c * 0.6); g.fill(); }
      g.fillStyle = `rgba(${T.foam},.5)`;
      for (let i = 0; i < N * N; i++) if (solid(tr[i])) { const [x, y] = cellXY(i); rrp(g, x - c * 0.12, y - c * 0.12, c * 1.24, c * 1.24, c * 0.4); g.fill(); }
      lava = [];
      if (k === 'jungle') { // river water between two banks reads as a river, not open sea
        g.fillStyle = 'rgba(70,165,170,.55)';
        for (let i = 0; i < N * N; i++) {
          if (tr[i] !== '~') continue;
          const x0 = i % N, y0 = (i / N) | 0, nb = [at(x0 - 1, y0), at(x0 + 1, y0), at(x0, y0 - 1), at(x0, y0 + 1)].filter((ch) => ch !== '~').length;
          if (nb >= 2) { const [x, y] = cellXY(i); rrp(g, x - c * 0.05, y - c * 0.05, c * 1.1, c * 1.1, c * 0.35); g.fill(); }
        }
      }
      for (let i = 0; i < N * N; i++) {
        const ch = tr[i]; if (!solid(ch)) continue;
        const [x, y] = cellXY(i);
        const dug = DIG(ch) && st.dg[i] !== '.' && st.dg[i] !== 'x';
        paintGround(g, T, k, x, y, c, i, dug);
        if (!dug && ch === ',') { // 젖은 모래: 짙은 색 + 물결
          g.fillStyle = 'rgba(70,110,120,.32)'; g.fillRect(x, y, c + 0.5, c + 0.5);
          g.strokeStyle = 'rgba(230,250,255,.5)'; g.lineWidth = 1; g.beginPath();
          for (let q = 0; q < 2; q++) { const yy = y + c * (0.35 + q * 0.3); g.moveTo(x + c * 0.18, yy); g.quadraticCurveTo(x + c * 0.35, yy - c * 0.08, x + c * 0.5, yy); g.quadraticCurveTo(x + c * 0.65, yy + c * 0.08, x + c * 0.82, yy); }
          g.stroke();
        } else if (!dug && ch === ':') { // 자갈땅: 작은 돌
          for (let q = 0; q < 6; q++) { g.fillStyle = q % 2 ? 'rgba(120,112,120,.85)' : 'rgba(170,164,170,.85)'; dot(g, x + c * (0.15 + hash01(i, q + 70) * 0.7), y + c * (0.15 + hash01(i, q + 80) * 0.7), c * (0.05 + hash01(i, q + 90) * 0.04)); }
        }
      }
      // liquids: a rim pass and a water pass of overlapping rounded tiles → one smooth blob, then details
      for (const lq of ['L', 'F', 'W', 'R']) {
        const cells = []; for (let i = 0; i < N * N; i++) if (tr[i] === lq) cells.push(i);
        if (!cells.length) continue;
        const [rim, fill] = liqStyle(k, lq);
        const same = (i) => { const x0 = i % N, y0 = (i / N) | 0; return [at(x0, y0 - 1) === lq, at(x0 + 1, y0) === lq, at(x0, y0 + 1) === lq, at(x0 - 1, y0) === lq]; };
        g.fillStyle = rim; for (const i of cells) { const [x, y] = cellXY(i); blobTile(g, x, y, c, same(i), c * 0.12, c * 0.45); }
        g.fillStyle = fill; for (const i of cells) { const [x, y] = cellXY(i); blobTile(g, x, y, c, same(i), 0, c * 0.36); }
        for (const i of cells) { const [x, y] = cellXY(i); paintLiquid(g, k, lq, x, y, c, i); if (lq === 'L') lava.push(i); }
      }
      // standing things in row order (lower rows overlap upper ones)
      for (let i = 0; i < N * N; i++) {
        const ch = tr[i], [x, y] = cellXY(i);
        if (ch === '#') paintRock(g, T, k, x, y, c, i);
        else if (ch === 'T') paintTree(g, T, k, x, y, c, i);
        else if (ch === 'P') paintPillar(g, x, y, c, i);
        else if (ch === 'H') paintWall(g, k, x, y, c, i);
        else if (ch === 'B') { const x0 = i % N, y0 = (i / N) | 0; paintBridge(g, x, y, c, at(x0 - 1, y0) !== '~' && at(x0 + 1, y0) !== '~'); }
      }
      // crater = lava cells nearest the middle → smoke source
      smokeAt = null;
      if (lava.length) {
        const cc = (N - 1) / 2; let sx = 0, sy = 0, m = 0;
        lava.forEach((i) => { const x0 = i % N, y0 = (i / N) | 0; if (Math.hypot(x0 - cc, y0 - cc) < 2) { sx += x0; sy += y0; m++; } });
        if (m) smokeAt = [B.x + (sx / m + 0.5) * c, B.y + (sy / m + 0.5) * c];
      }
    }
    function islandLayer() {
      const key = [cv.w, cv.h, cv.dpr, B.c, B.x, B.y, st.sd, st.mp, st.dg].join('|');
      if (layer && key === layerKey) return layer;
      if (!layer) layer = document.createElement('canvas');
      const pw = Math.round(cv.w * cv.dpr), ph = Math.round(cv.h * cv.dpr);
      if (layer.width !== pw || layer.height !== ph) { layer.width = pw; layer.height = ph; }
      const g = layer.getContext('2d');
      g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, pw, ph); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      paintIsland(g);
      layerKey = key;
      return layer;
    }
    function fogSprite(rgb) {
      if (fog[rgb]) return fog[rgb];
      const s = document.createElement('canvas'); s.width = s.height = 96;
      const g = s.getContext('2d'), gr = g.createRadialGradient(48, 48, 0, 48, 48, 48);
      gr.addColorStop(0, `rgba(${rgb},1)`); gr.addColorStop(1, `rgba(${rgb},0)`);
      g.fillStyle = gr; g.fillRect(0, 0, 96, 96);
      return (fog[rgb] = s);
    }
    function drawFx(now) {
      const k = mapOf(st).k, W = cv.w, H = cv.h, c = B.c;
      if (lava.length) { // lava breathes
        ctx.fillStyle = '#ffd860';
        for (const i of lava) { const [x, y] = cellXY(i); ctx.globalAlpha = 0.16 + 0.14 * Math.sin(now / 380 + i * 1.7); dotC(x + c / 2, y + c / 2, c * 0.42); }
        ctx.globalAlpha = 1;
      }
      if (smokeAt) {
        for (let j = 0; j < 4; j++) {
          const p = (now / 2600 + j / 4) % 1;
          ctx.fillStyle = `rgba(80,72,74,${(0.4 * (1 - p)).toFixed(3)})`;
          dotC(smokeAt[0] + Math.sin(p * 5 + j) * c * 0.35 + p * c * 0.8, smokeAt[1] - p * c * 3.2, c * (0.25 + p * 0.6));
        }
      }
      if (k === 'snow') {
        ctx.fillStyle = 'rgba(255,255,255,.85)';
        for (let j = 0; j < 46; j++) {
          const sp = 0.018 + hash01(j, 3) * 0.03;
          const x = (hash01(j, 1) * W + Math.sin(now / 1500 + j) * 14 + W) % W, y = (hash01(j, 2) * H + now * sp) % H;
          dotC(x, y, 1 + hash01(j, 4) * 1.8);
        }
      } else if (k === 'swamp' || k === 'skull') {
        const spr = fogSprite(k === 'swamp' ? '205,220,190' : '175,145,220');
        ctx.globalAlpha = k === 'swamp' ? 0.16 : 0.13;
        for (let j = 0; j < 5; j++) {
          const r = W * (0.35 + hash01(j, 51) * 0.2), dir = j % 2 ? 1 : -1;
          const x = ((hash01(j, 52) * (W + 2 * r) + dir * now * 0.012) % (W + 2 * r) + (W + 2 * r)) % (W + 2 * r) - r;
          const y = B.y + (B.by + hash01(j, 53) * B.bh) * c;
          ctx.drawImage(spr, x - r, y - r * 0.5, r * 2, r);
        }
        ctx.globalAlpha = 1;
        if (k === 'swamp') { // fireflies
          for (let j = 0; j < 7; j++) {
            const a = Math.max(0, Math.sin(now / 420 + j * 2.1)); if (a < 0.1) continue;
            const x = B.x + (B.bx + hash01(j, 61) * B.bw) * c + Math.sin(now / 1700 + j * 3) * c, y = B.y + (B.by + hash01(j, 62) * B.bh) * c + Math.cos(now / 1900 + j) * c * 0.6;
            ctx.globalAlpha = a * 0.25; ctx.fillStyle = '#e8f27a'; dotC(x, y, 5); ctx.globalAlpha = a; dotC(x, y, 1.8);
          }
          ctx.globalAlpha = 1;
        }
      }
    }
    function dotC(x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); }
    function drawItem(cd, cx, cy, sz, owner) {
      ctx.save(); ctx.translate(cx, cy);
      if (cd === 1) { // coin pouch
        ctx.fillStyle = '#8a5a2b'; ctx.beginPath(); ctx.ellipse(0, sz * 0.12, sz * 0.32, sz * 0.28, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#6d4520'; ctx.fillRect(-sz * 0.1, -sz * 0.22, sz * 0.2, sz * 0.12);
        ctx.fillStyle = '#f4cf57'; ctx.beginPath(); ctx.arc(sz * 0.12, sz * 0.12, sz * 0.12, 0, 7); ctx.fill();
        ctx.strokeStyle = '#a07a1a'; ctx.lineWidth = 1; ctx.stroke();
      } else if (cd === 2) { // gold bars
        ctx.fillStyle = '#f2c94c';
        for (const [dx, dy] of [[-0.18, 0.12], [0.18, 0.12], [0, -0.1]]) { ctx.beginPath(); ctx.moveTo(sz * (dx - 0.2), sz * (dy + 0.1)); ctx.lineTo(sz * (dx - 0.13), sz * (dy - 0.08)); ctx.lineTo(sz * (dx + 0.13), sz * (dy - 0.08)); ctx.lineTo(sz * (dx + 0.2), sz * (dy + 0.1)); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#a77d14'; ctx.lineWidth = 1; ctx.stroke(); }
      } else if (cd === 3) { // chest
        ctx.fillStyle = '#7a4520'; rr(-sz * 0.36, -sz * 0.08, sz * 0.72, sz * 0.4, sz * 0.05); ctx.fill();
        ctx.fillStyle = '#93582a'; ctx.beginPath(); ctx.moveTo(-sz * 0.36, -sz * 0.08); ctx.quadraticCurveTo(0, -sz * 0.4, sz * 0.36, -sz * 0.08); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#f2c94c'; ctx.fillRect(-sz * 0.36, -sz * 0.1, sz * 0.72, sz * 0.06); ctx.fillRect(-sz * 0.05, -sz * 0.12, sz * 0.1, sz * 0.18);
        ctx.fillStyle = '#ffe9a0'; ctx.beginPath(); ctx.arc(sz * 0.2, -sz * 0.28, sz * 0.05, 0, 7); ctx.fill();
      } else if (cd === 4) { // skull
        ctx.fillStyle = '#efe6d6'; ctx.beginPath(); ctx.arc(0, -sz * 0.05, sz * 0.27, 0, 7); ctx.fill(); ctx.fillRect(-sz * 0.15, sz * 0.1, sz * 0.3, sz * 0.16);
        ctx.fillStyle = '#2a1f2e'; ctx.beginPath(); ctx.arc(-sz * 0.1, -sz * 0.05, sz * 0.07, 0, 7); ctx.arc(sz * 0.1, -sz * 0.05, sz * 0.07, 0, 7); ctx.fill();
        ctx.fillRect(-sz * 0.02, sz * 0.12, sz * 0.04, sz * 0.12);
      } else if (cd === 5) { // swamp
        ctx.fillStyle = '#4c6b3a'; ctx.beginPath(); ctx.ellipse(0, sz * 0.06, sz * 0.38, sz * 0.26, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#7fa55a'; for (const [dx, dy, r] of [[-0.12, 0, 0.07], [0.12, 0.08, 0.05], [0.05, -0.08, 0.04]]) { ctx.beginPath(); ctx.arc(sz * dx, sz * dy, sz * r, 0, 7); ctx.fill(); }
      } else if (cd === 6) { // detector
        ctx.strokeStyle = '#5bb3e6'; ctx.lineWidth = Math.max(1.5, sz * 0.07);
        ctx.beginPath(); ctx.arc(0, 0, sz * 0.26, 0, 7); ctx.stroke(); ctx.beginPath(); ctx.arc(0, 0, sz * 0.12, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(sz * 0.22, -sz * 0.14); ctx.stroke();
      } else if (cd === 7) { // shovel
        ctx.rotate(-0.6); ctx.fillStyle = '#9a7a52'; ctx.fillRect(-sz * 0.03, -sz * 0.36, sz * 0.06, sz * 0.42);
        ctx.fillStyle = '#c8ccd4'; ctx.beginPath(); ctx.moveTo(-sz * 0.13, sz * 0.05); ctx.lineTo(sz * 0.13, sz * 0.05); ctx.lineTo(0, sz * 0.34); ctx.closePath(); ctx.fill();
      } else if (cd === 9) { // poison dart trap
        ctx.strokeStyle = '#4a3a2a'; ctx.lineWidth = Math.max(1.5, sz * 0.06); ctx.beginPath(); ctx.moveTo(-sz * 0.3, sz * 0.25); ctx.lineTo(sz * 0.3, sz * 0.25); ctx.stroke();
        ctx.fillStyle = '#7bd35a';
        for (const dx of [-0.18, 0, 0.18]) { ctx.beginPath(); ctx.moveTo(sz * dx, -sz * 0.3); ctx.lineTo(sz * (dx - 0.05), sz * 0.22); ctx.lineTo(sz * (dx + 0.05), sz * 0.22); ctx.closePath(); ctx.fill(); }
        ctx.fillStyle = '#c8f08a'; ctx.beginPath(); ctx.arc(0, -sz * 0.33, sz * 0.05, 0, 7); ctx.fill();
      } else if (cd === 10) { // cursed box
        ctx.fillStyle = '#3b2450'; rr(-sz * 0.32, -sz * 0.12, sz * 0.64, sz * 0.4, sz * 0.05); ctx.fill();
        ctx.fillStyle = '#56346f'; ctx.fillRect(-sz * 0.34, -sz * 0.2, sz * 0.68, sz * 0.1);
        ctx.strokeStyle = '#c38cff'; ctx.lineWidth = Math.max(1, sz * 0.04); ctx.beginPath(); ctx.arc(0, sz * 0.08, sz * 0.1, 0, 7); ctx.moveTo(-sz * 0.12, sz * 0.08); ctx.lineTo(sz * 0.12, sz * 0.08); ctx.stroke();
        ctx.fillStyle = 'rgba(195,140,255,.5)'; ctx.beginPath(); ctx.arc(-sz * 0.2, -sz * 0.3, sz * 0.05, 0, 7); ctx.arc(sz * 0.15, -sz * 0.36, sz * 0.04, 0, 7); ctx.fill();
      } else if (cd === 11) { // cave-in: tumbled rocks
        ctx.fillStyle = '#5b5560'; for (const [dx, dy, r] of [[-0.15, 0.1, 0.17], [0.15, 0.12, 0.15], [0, -0.1, 0.16]]) { ctx.beginPath(); ctx.arc(sz * dx, sz * dy, sz * r, 0, 7); ctx.fill(); }
        ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-sz * 0.28, -sz * 0.25); ctx.lineTo(-sz * 0.18, -sz * 0.35); ctx.moveTo(sz * 0.25, -sz * 0.2); ctx.lineTo(sz * 0.33, -sz * 0.32); ctx.stroke();
      } else if (cd === 12) { // mimic: chest with teeth and an eye
        ctx.fillStyle = '#7a4520'; rr(-sz * 0.36, -sz * 0.02, sz * 0.72, sz * 0.34, sz * 0.05); ctx.fill();
        ctx.fillStyle = '#93582a'; ctx.save(); ctx.translate(-sz * 0.36, -sz * 0.06); ctx.rotate(-0.35); ctx.fillRect(0, -sz * 0.18, sz * 0.72, sz * 0.18); ctx.restore();
        ctx.fillStyle = '#8b1e2a'; ctx.fillRect(-sz * 0.32, -sz * 0.06, sz * 0.64, sz * 0.08);
        ctx.fillStyle = '#f4efe2'; for (let q = 0; q < 5; q++) { const tx = -sz * 0.28 + q * sz * 0.14; ctx.beginPath(); ctx.moveTo(tx, -sz * 0.04); ctx.lineTo(tx + sz * 0.05, sz * 0.06); ctx.lineTo(tx + sz * 0.1, -sz * 0.04); ctx.fill(); }
        ctx.fillStyle = '#ffd34d'; ctx.beginPath(); ctx.arc(sz * 0.05, -sz * 0.24, sz * 0.06, 0, 7); ctx.fill(); ctx.fillStyle = '#1a0f0f'; ctx.fillRect(sz * 0.04, -sz * 0.29, sz * 0.02, sz * 0.1);
      } else if (cd === 8) { // map piece
        ctx.rotate(0.1); ctx.fillStyle = '#efe0b8'; ctx.beginPath(); ctx.moveTo(-sz * 0.3, -sz * 0.22); ctx.lineTo(sz * 0.25, -sz * 0.26); ctx.lineTo(sz * 0.3, sz * 0.2); ctx.lineTo(-sz * 0.26, sz * 0.26); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#c0392b'; ctx.lineWidth = Math.max(1.2, sz * 0.05); ctx.beginPath(); ctx.moveTo(sz * 0.05, -sz * 0.03); ctx.lineTo(sz * 0.17, sz * 0.09); ctx.moveTo(sz * 0.17, -sz * 0.03); ctx.lineTo(sz * 0.05, sz * 0.09); ctx.stroke();
      }
      ctx.restore();
      if (owner != null) { ctx.beginPath(); ctx.arc(cx + sz * 0.33, cy - sz * 0.33, Math.max(3, sz * 0.1), 0, 7); ctx.fillStyle = color(owner); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1; ctx.stroke(); }
    }
    function drawMark(m, x, y, c) {
      const cx = x + c / 2, cy = y + c / 2, r = c * 0.24;
      ctx.fillStyle = 'rgba(20,15,25,.45)'; dotC(cx, cy, r * 1.25);
      if (m === 1) {
        ctx.strokeStyle = '#ff7a64'; ctx.lineWidth = Math.max(2, c * 0.09); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(cx - r * 0.7, cy - r * 0.7); ctx.lineTo(cx + r * 0.7, cy + r * 0.7); ctx.moveTo(cx + r * 0.7, cy - r * 0.7); ctx.lineTo(cx - r * 0.7, cy + r * 0.7); ctx.stroke(); ctx.lineCap = 'butt';
      } else {
        ctx.fillStyle = '#ffd35a'; ctx.beginPath();
        for (let q = 0; q < 10; q++) { const a = -Math.PI / 2 + q * Math.PI / 5, rr2 = q % 2 ? r * 0.45 : r; ctx.lineTo(cx + Math.cos(a) * rr2, cy + Math.sin(a) * rr2); }
        ctx.closePath(); ctx.fill();
      }
    }
    function drawDug() {
      const c = B.c, N = st.N;
      const own = {}; st.f.forEach(([i, s]) => { own[i] = s; });
      for (let i = 0; i < N * N; i++) {
        if (st.dg[i] === '.') { const m = marks.get(i); if (m) { const [x, y] = cellXY(i); drawMark(m, x, y, c); } continue; }
        if (anim && anim.i === i && !anim.revealed) continue;
        if (st.dg[i] === 'x') { // 무너져 묻힌 칸: 흙더미 + 속에 있던 것(흐리게)
          const [x, y] = cellXY(i), e = (st.cv || []).find((v) => v[0] === i), T = theme();
          ctx.fillStyle = T.pit[2]; ctx.beginPath(); ctx.ellipse(x + c / 2, y + c * 0.6, c * 0.44, c * 0.3, 0, 0, 7); ctx.fill();
          ctx.fillStyle = 'rgba(80,72,80,.9)'; for (let q = 0; q < 4; q++) dotC(x + c * (0.25 + hash01(i, q + 40) * 0.5), y + c * (0.45 + hash01(i, q + 50) * 0.3), c * 0.09);
          if (e && e[1]) { ctx.globalAlpha = 0.5; drawItem(e[1], x + c / 2, y + c * 0.42, c * 0.7); ctx.globalAlpha = 1; }
          continue;
        }
        const cd = dugCode(st, i);
        const [x, y] = cellXY(i);
        const pop = pops.find((p) => p.i === i);
        let sc = 1;
        if (pop) { const t = Math.min(1, (performance.now() - pop.t0) / pop.dur); sc = t < 0.6 ? 0.3 + (t / 0.6) * 1.05 : 1.35 - (t - 0.6) / 0.4 * 0.35; }
        if (cd >= 1) drawItem(cd, x + c / 2, y + c / 2, c * sc, isT(cd) ? own[i] : null);
        const hn = st.hn[i];
        if (hn !== '.' && (cd === 0 || cd >= 6)) {
          const v = +hn;
          if (cd === 0) {
            if (v > 0) { ctx.font = `700 ${Math.round(c * 0.58)}px "IBM Plex Mono", monospace`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fillText(hn, x + c / 2 + 1, y + c / 2 + 2); ctx.fillStyle = HINTC[v]; ctx.fillText(hn, x + c / 2, y + c / 2 + 1); }
          } else { // tool tile: small hint in the corner
            ctx.font = `700 ${Math.round(c * 0.34)}px "IBM Plex Mono", monospace`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillStyle = 'rgba(20,15,25,.75)'; ctx.beginPath(); ctx.arc(x + c * 0.8, y + c * 0.8, c * 0.19, 0, 7); ctx.fill();
            ctx.fillStyle = v ? HINTC[v] : '#cfc4b0'; ctx.fillText(hn, x + c * 0.8, y + c * 0.82);
          }
        }
      }
      // where the last dig happened (in the digger's colour)
      const ev = st.last;
      if (ev && ev.k === 'dig' && !(anim && anim.i === ev.i)) {
        const [x, y] = cellXY(ev.i);
        ctx.strokeStyle = color(ev.s); ctx.lineWidth = 2; rr(x + 1.5, y + 1.5, c - 3, c - 3, c * 0.18); ctx.stroke();
      }
    }
    function badge(x, y, text, bg, fg) {
      ctx.font = `700 ${Math.max(10, Math.round(B.c * 0.38))}px "IBM Plex Mono", monospace`;
      const w = ctx.measureText(text).width + 8, h = Math.max(14, B.c * 0.48);
      ctx.fillStyle = bg; rr(x - w / 2, y - h / 2, w, h, h / 2); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, x, y + 0.5);
    }
    function rowSpan(r) {
      let a = B.N, b = -1; for (let x = 0; x < B.N; x++) if (st.tr[r * B.N + x] !== '~') { a = Math.min(a, x); b = Math.max(b, x); }
      if (b < 0) { a = 0; b = B.N - 1; }
      return [B.x + a * B.c, B.x + (b + 1) * B.c];
    }
    function remainIn(cells, total) { let f = 0; const set = new Set(cells); st.f.forEach(([i]) => { if (set.has(i)) f++; }); return total - f; }
    function drawHints(now) {
      const c = B.c, N = st.N, nb = nbList(N);
      st.rw.forEach(([r, n]) => {
        const cells = []; for (let x = 0; x < N; x++) cells.push(r * N + x);
        const y = B.y + r * c;
        const [rx0, rx1] = rowSpan(r); ctx.fillStyle = 'rgba(232,192,78,.12)'; ctx.fillRect(rx0, y, rx1 - rx0, c);
        ctx.strokeStyle = 'rgba(232,192,78,.65)'; ctx.setLineDash([4, 3]); ctx.lineWidth = 1.5; ctx.strokeRect(rx0 + 1, y + 1, rx1 - rx0 - 2, c - 2); ctx.setLineDash([]);
        badge(rx0 - c * 0.1, y + c / 2, '▤' + remainIn(cells, n), '#e8c04e', '#2a1f12');
      });
      st.sc.forEach(([i, n]) => {
        const [x, y] = cellXY(i);
        ctx.strokeStyle = '#5bb3e6'; ctx.lineWidth = 2; ctx.setLineDash([5, 3]);
        ctx.strokeRect(x - c + 1.5, y - c + 1.5, c * 3 - 3, c * 3 - 3); ctx.setLineDash([]);
        badge(x + c / 2, y - c + 2, '◎' + remainIn(nb.n9[i], n), '#5bb3e6', '#0d2230');
      });
    }
    function drawSel(now) {
      if (sel < 0 || !myTurn()) return;
      const c = B.c; const [x, y] = cellXY(sel);
      const pulse = 0.6 + 0.4 * Math.sin(now / 150);
      ctx.lineWidth = 2.5; ctx.strokeStyle = `rgba(255,214,110,${pulse.toFixed(3)})`;
      if (mode === 'scan') { ctx.fillStyle = 'rgba(91,179,230,.2)'; ctx.fillRect(x - c, y - c, c * 3, c * 3); ctx.strokeStyle = `rgba(91,179,230,${pulse.toFixed(3)})`; ctx.strokeRect(x - c, y - c, c * 3, c * 3); }
      else if (mode === 'map') { const [rx0, rx1] = rowSpan((sel / B.N) | 0); ctx.fillStyle = 'rgba(232,192,78,.2)'; ctx.fillRect(rx0, y, rx1 - rx0, c); ctx.strokeRect(rx0, y, rx1 - rx0, c); }
      else {
        ctx.fillStyle = 'rgba(255,230,150,.22)'; ctx.fillRect(x, y, c, c);
        ctx.strokeRect(x + 1, y + 1, c - 2, c - 2);
        // tiny shovel ghost
        ctx.globalAlpha = 0.85; drawItem(7, x + c / 2, y + c / 2 - c * 0.15, c * 0.8); ctx.globalAlpha = 1;
      }
    }
    function drawAnim(now) {
      if (!anim) return;
      const c = B.c; const [x, y] = cellXY(anim.i);
      const t = Math.min(1, (now - anim.t0) / anim.dur);
      if (t < 0.55) { // shovel stabs twice
        const k = (t / 0.55) * 2 % 1;
        const dy = Math.sin(k * Math.PI) * c * 0.35;
        ctx.save(); ctx.translate(x + c * 0.55, y - c * 0.1 + dy); drawItem(7, 0, 0, c * 1.2); ctx.restore();
      }
    }
    function drawParts(dt) {
      if (parts.length && parts.some((p) => p.life <= 0)) parts = parts.filter((p) => p.life > 0);
      for (const p of parts) {
        p.life -= dt; p.vy += 520 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
        ctx.globalAlpha = Math.max(0, Math.min(1, p.life / 0.4));
        ctx.fillStyle = p.col; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    function burst(i, n, cols, speed) {
      const c = B.c; const [x, y] = cellXY(i);
      for (let k = 0; k < n; k++) {
        const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.2, v = (0.4 + Math.random()) * speed;
        parts.push({ x: x + c / 2, y: y + c / 2, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0.5 + Math.random() * 0.4, r: 1.2 + Math.random() * c * 0.07, col: cols[k % cols.length] });
      }
    }
    let lastT = performance.now();
    function frame(now) {
      if (!st || dead) return;
      const dt = Math.min(0.05, (now - lastT) / 1000) * SPD(); lastT = now;
      cv.clear();
      if (!B) layout();
      ctx.save();
      if (shake > 0) { ctx.translate((Math.random() - 0.5) * shake * 8, (Math.random() - 0.5) * shake * 8); shake = Math.max(0, shake - dt * 3); }
      drawSea(now);
      ctx.drawImage(islandLayer(), 0, 0, cv.w, cv.h);
      drawFx(now);
      drawHints(now);
      drawDug();
      drawSel(now);
      drawAnim(now);
      drawParts(dt);
      ctx.restore();
      if (pops.length) pops = pops.filter((p) => now - p.t0 < p.dur);
    }

    function setBusyFor(ms) { api.setBusy(true); clearTimeout(busyT); busyT = setTimeout(() => api.setBusy(false), ms); }
    function onEvent(s, prev) {
      const ev = s.last, sp = SPD();
      if (!ev) return;
      if (ev.k === 'dig') {
        marks.delete(ev.i);
        const dur = 520 / sp;
        const my = anim = { i: ev.i, t0: performance.now(), dur, revealed: false };
        setBusyFor(dur + 260 / sp);
        api.sfx('roll');
        const T = theme(), dirt = [T.pit[0], T.pit[2], T.pit[0]];
        setTimeout(() => { if (!dead) burst(ev.i, 14, dirt, 160); }, dur * 0.25);
        setTimeout(() => {
          if (dead) return;
          if (anim === my) anim = null;
          burst(ev.i, 10, dirt, 120);
          const c = ev.c;
          if (isT(c)) {
            pops.push({ i: ev.i, t0: performance.now(), dur: 520 / sp });
            burst(ev.i, 16, ['#f4cf57', '#fff2b0', '#e3ae45'], 220);
            api.sfx(c === 3 ? 'win' : 'pop'); api.buzz(c === 3 ? 40 : 20);
            api.toast(`${s.nm[ev.s]}: ${NAME[c]} +${VAL[c]}점`);
          } else if (c === 4) { shake = L.fx(); api.sfx('lose'); api.buzz(60); api.toast(`해골 함정! −${TRAP_PTS}점`); }
          else if (c === 9) { shake = L.fx() * 0.5; api.sfx('hit'); api.buzz(40); burst(ev.i, 12, ['#7bd35a', '#c8f08a'], 180); api.toast(`독침! −${DART_PTS}점 · ${s.nm[ev.s]} 다음 차례까지 도구 못 씀`); }
          else if (c === 10) { api.sfx('lose'); api.buzz(50); burst(ev.i, 16, ['#c38cff', '#56346f'], 200); api.toast(ev.sw >= 0 ? `저주 상자! ${s.nm[ev.s]} ↔ ${s.nm[ev.sw]} 점수가 뒤바뀌었어요` : `저주 상자! −${s.n > 1 ? CURSE_PTS : CURSE_SOLO}점`); }
          else if (c === 11) { shake = L.fx(); api.sfx('thud'); api.buzz(70); const cvs = ev.cv || []; cvs.forEach((j) => burst(j, 10, ['#5b5560', '#8f8790'], 140)); const lostT = cvs.filter((j) => (s.cv || []).some((v) => v[0] === j && isT(v[1]))).length; api.toast(`동굴 붕괴! 옆 ${cvs.length}칸이 묻혔어요` + (lostT ? ` (보물 ${lostT}개도…)` : '')); }
          else if (c === 12) { shake = L.fx() * 0.7; api.sfx('lose'); api.buzz(60); api.toast(`미믹 상자! 콱 물려서 −${MIMIC_PTS}점, 차례 끝`); }
          else if (c === 5) { api.sfx('thud'); api.buzz(40); api.toast(ev.nf ? '모래 늪! (마지막 차례라 쉬지 않아요)' : `모래 늪! ${s.nm[ev.s]} 다음 차례 쉼`); }
          else if (c >= 6) { pops.push({ i: ev.i, t0: performance.now(), dur: 420 / sp }); api.sfx('chip'); api.toast(`${NAME[c]} 획득!`); }
          else api.sfx('thud');
          if (ev.wet) setTimeout(() => !dead && api.toast('젖은 모래라 쉽게 팠어요 — 한 칸 더!'), 300 / sp);
          if (ev.rk) setTimeout(() => !dead && api.toast('자갈땅이 단단해서 차례가 끝났어요'), 300 / sp);
          if (ev.sk && ev.sk.length) setTimeout(() => !dead && api.toast(ev.sk.map((i) => s.nm[i]).join(', ') + ' 차례를 쉬어요'), 600 / sp);
        }, dur);
      } else if (ev.k === 'scan') { api.sfx('chip'); api.toast(`탐지기: 둘레 3×3에 보물 ${ev.n}개`); }
      else if (ev.k === 'map') { api.sfx('card'); api.toast(`지도 조각: ${ev.r + 1}번째 줄에 보물 ${ev.n}개`); }
      else if (ev.k === 'shovel') { api.sfx('whoosh'); api.toast('삽! 이번 차례 두 칸'); }
    }
    function update(s, prev) {
      const first = !st || (prev && (prev.N !== s.N || prev.sd !== s.sd));
      st = s;
      if (first) { B = null; sel = -1; mode = 'dig'; marks = new Map(); layerKey = ''; if (!s.seq) api.toast(`맵: ${mapOf(s).name}`); }
      if (prev && prev !== s && s.last && (!prev.last || prev.last.id !== s.last.id)) onEvent(s, prev);
      if (prev !== s && prev && prev.seq !== s.seq) { sel = -1; if (s.t !== prev.t) mode = 'dig'; }
      if (s.end) { sel = -1; mode = 'dig'; }
      renderHud();
      layout();
    }

    // input: tap = 고르기(같은 칸 한 번 더 = 확정), 누른 채 밀기 = 고른 칸 옮기기, 꾹 누르기 = 메모(✕ → ★ → 없음)
    let down = null, lpT = 0;
    function onDown(e) {
      if (!st || !B) return;
      const p = cv.local(e);
      down = { x: p.x, y: p.y, drag: false, lp: false, i: hitCell(p.x, p.y) };
      clearTimeout(lpT);
      lpT = setTimeout(() => { if (down && !down.drag && toggleMark(down.i)) down.lp = true; }, 460);
    }
    function onMove(e) {
      if (!down) return;
      const p = cv.local(e);
      if (!down.drag && Math.hypot(p.x - down.x, p.y - down.y) > 12) { down.drag = true; clearTimeout(lpT); }
      if (down.drag && !down.lp && myTurn() && !locked() && !anim) {
        const i = hitCell(p.x, p.y);
        if (canTarget(i) && i !== sel && !(mode === 'map' && sel >= 0 && ((sel / st.N) | 0) === ((i / st.N) | 0))) { sel = i; api.sfx('tick'); renderHud(); }
      }
    }
    function onUp(e) {
      clearTimeout(lpT);
      if (!down) return;
      const d = down; down = null;
      if (d.lp || d.drag) return;
      const p = cv.local(e); tap(p.x, p.y);
    }
    function onCancel() { clearTimeout(lpT); down = null; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('contextmenu', (e) => e.preventDefault());
    cv.onresize = () => { if (st) layout(); };
    cv.cv._cell = (i) => { const [x, y] = cellXY(i); return [x + B.c / 2, y + B.c / 2]; }; // test hook
    stopLoop = U.loop((dt, now) => frame(now));

    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down') return;
      const b = [...document.querySelectorAll('[data-action="' + id + '"]')].find((x) => !x.disabled && x.getClientRects().length);
      if (b) b.click();
    }) : null;
    const noFocus = (e) => { const b = e.target && e.target.closest && e.target.closest('button[data-action]'); if (b) e.preventDefault(); };   // 마우스로 누른 버튼에 포커스가 남아 Space/Enter 단축키를 가로채지 않게
    document.addEventListener('mousedown', noFocus, true);
    return {
      update,
      destroy() { if (offKeys) offKeys(); document.removeEventListener('mousedown', noFocus, true);
        dead = true; window.removeEventListener('lounge-cancel', onCancelEv); if (stopLoop) stopLoop(); clearTimeout(busyT); clearTimeout(lpT); api.setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onCancel);
        top.remove(); bot.remove(); cv.destroy(); layer = null;
      },
    };
  }

  L.register({
    id: 'treasure', name: '보물섬 땅파기', tag: '추리 땅파기', cat: '보드',
    blurb: '번갈아 섬의 땅을 한 칸씩 파요. 숫자는 둘레 8칸에 묻힌 보물 수 — 추리해서 보물을 캐고 함정 6종은 피하세요. 정글·화산·설원·유적, 판마다 새로 만드는 원시섬까지 맵 10가지.',
    controls: [
      { id: 'go', label: '파기 · 여기 탐지 · 확정', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'scan', label: '탐지기', keys: ['KeyQ'], pad: ['x'] },
      { id: 'shovel', label: '삽', keys: ['KeyE'], pad: ['y'] },
      { id: 'map', label: '지도', keys: ['KeyM'], pad: ['b'] },
    ],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, aiDelay: 560,
    tint: '#1f5560',
    icon: '<path d="M6 40c8-10 36-10 44 0-6 6-38 6-44 0z" fill="currentColor" opacity=".55"/><rect x="18" y="20" width="20" height="14" rx="2" fill="currentColor"/><path d="M18 22c0-8 20-8 20 0z" fill="currentColor"/><rect x="26" y="22" width="4" height="6" fill="#1f5560"/><path d="M40 8l8 8M44 12l-6 6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    options: [
      { id: 'map', label: '맵', choices: [{ v: 0, label: '무작위' }].concat(MAPS.slice(1).map((m, i) => ({ v: i + 1, label: m.name }))), def: 0 },
      { id: 'size', label: '섬 크기', choices: [{ v: 10, label: '작게 10×10' }, { v: 12, label: '보통 12×12' }, { v: 14, label: '크게 14×14' }], def: 12 },
      { id: 'traps', label: '함정 수', tip: '섬에 숨긴 함정 수.', choices: [{ v: 1, label: '적게' }, { v: 2, label: '보통' }, { v: 3, label: '많이' }], def: 2 },
      { id: 'tools', label: '도구', tip: '특별한 도구가 나와 쓸 수 있어요.', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
    ],
    quick: [
      '섬 땅속에 묻힌 보물(동전 2점 · 금괴 5점 · 보물상자 10점)을 파서 점수를 가장 많이 모으면 이겨요.',
      '내 차례: 땅 한 칸을 탭하고 한 번 더 탭(또는 「파기」)해서 파요.',
      '빈 땅의 숫자 = 둘레 8칸에 묻힌 보물 수. 숫자로 추리해서 보물은 캐고 함정은 피하세요!',
    ],
    rules: [
      { h: '그림으로 보기', fig: [{"svg": "<svg viewBox=\"0 0 340 134\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"134\" rx=\"10\" fill=\"#1f2a24\"/><rect x=\"30\" y=\"12\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><circle cx=\"47\" cy=\"29\" r=\"8\" fill=\"#f2c94c\" opacity=\".6\"/><rect x=\"66\" y=\"12\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><rect x=\"102\" y=\"12\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><rect x=\"30\" y=\"48\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><rect x=\"66\" y=\"48\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#e8d6a8\"/><text x=\"83\" y=\"72\" font-size=\"18\" fill=\"#2b5fa8\" text-anchor=\"middle\" font-weight=\"700\">2</text><rect x=\"102\" y=\"48\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><rect x=\"30\" y=\"84\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><rect x=\"66\" y=\"84\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><circle cx=\"83\" cy=\"101\" r=\"8\" fill=\"#f2c94c\" opacity=\".6\"/><rect x=\"102\" y=\"84\" width=\"34\" height=\"34\" rx=\"4\" fill=\"#5f8d3e\"/><rect x=\"27\" y=\"9\" width=\"114\" height=\"114\" fill=\"none\" stroke=\"#e3ae45\" stroke-dasharray=\"4 3\" stroke-width=\"2\"/><text x=\"156\" y=\"40\" font-size=\"12\" fill=\"#f3ead2\" text-anchor=\"start\">숫자 2 = 둘레 8칸(점선 안)에</text><text x=\"156\" y=\"58\" font-size=\"12\" fill=\"#f3ead2\" text-anchor=\"start\">보물이 2개 묻혀 있어요</text><text x=\"156\" y=\"84\" font-size=\"12\" fill=\"#9fd59f\" text-anchor=\"start\">0이면 둘레엔 보물 없음</text><text x=\"156\" y=\"102\" font-size=\"12\" fill=\"#f2a0a0\" text-anchor=\"start\">미믹 상자도 보물로 세요</text></svg>", "cap": "금색 동그라미는 예시 — 실제론 숫자로 추리해요"}] },
      { h: '목표', p: [
        '섬 땅속에 보물이 묻혀 있어요: 동전 주머니 2점 · 금괴 5점 · 보물상자 10점.',
        '돌아가며 땅을 한 칸씩 파서 점수를 모아요. 끝났을 때 점수가 가장 높은 사람이 이겨요.',
        '혼자 하면 점수 도전이에요.'] },
      { h: '준비 (자동)', p: [
        '섬 맵이 정해지고 보물 · 함정 · 도구가 매 판 무작위로 묻혀요. 땅속은 아무도 몰라요.',
        '위쪽 줄에 맵 이름 · 내 차례 수 · 남은 보물 · 함정 수가 보여요.'] },
      { h: '차례에 할 일', p: [
        '① 팔 칸을 탭해요(고른 칸에 표시가 떠요).',
        '② 같은 칸을 한 번 더 탭하거나 「파기」를 눌러요. 그러면 차례가 끝나요.',
        '③ 나온 것: 보물이면 점수! 빈 땅이면 숫자 힌트, 함정이면 벌칙, 도구면 내 것이 돼요.',
        '팔 수 있는 건 맨땅(모래·흙·눈·돌바닥)뿐이에요. 바다 · 바위 · 나무 · 용암 · 얼음 · 웅덩이 · 기둥 · 벽 · 다리는 못 파요.'] },
      { h: '숫자 힌트 읽기', p: [
        '빈 땅을 파면 숫자가 나와요 = 그 칸 둘레 8칸에 묻힌 보물 수예요(함정 · 도구는 세지 않아요).',
        '이미 파낸 보물도 숫자에 들어가요.',
        '0이면 둘레에 보물이 없어요. 숫자가 큰 곳 근처를 노려 보세요.',
        '도구가 나온 칸도 모서리에 같은 숫자 힌트가 보여요. 보물 · 함정 칸에는 숫자가 없어요.'] },
      { h: '점수·승리', p: [
        '보물을 모두 찾거나, 모두가 정해진 차례를 다 쓰면 끝나요.',
        '한 사람 차례 수: 10×10 섬 14번 · 12×12 섬 18번 · 14×14 섬 22번.',
        '점수가 가장 높은 사람이 이겨요(같으면 공동 승리).'] },
      { h: '함정 6가지', p: [
        `💀 해골 함정: ${TRAP_PTS}점을 잃어요(점수가 0 아래로 내려갈 수 있어요).`,
        '🟢 모래 늪: 그 자리에서 차례가 끝나고, 다음 차례를 한 번 쉬어요(쉰 차례도 쓴 것으로 쳐요).',
        `🗡️ 독침 함정: ${DART_PTS}점을 잃고, 다음 내 차례가 끝날 때까지 도구(탐지기·삽·지도)를 못 써요.`,
        `🟣 저주 상자: 점수가 가장 낮은 다른 사람과 내 점수를 맞바꿔요. 내가 가장 낮으면 ${CURSE_PTS}점만 잃어요(혼자 하면 ${CURSE_SOLO}점). 앞서 있을수록 무서워요!`,
        '🪨 동굴 붕괴: 바로 위·아래·옆의 안 판 땅이 흙에 묻혀 아무도 못 파요. 묻힌 칸 속은 모두에게 보여 줘요(보물이면 영영 사라져요).',
        `👅 미믹 상자: 보물상자인 척하는 괴물! 물려서 ${MIMIC_PTS}점을 잃고 차례가 끝나요. 조심: 숫자 · 탐지기 · 지도는 미믹도 '보물'로 세요.`,
        '함정은 서로 붙어 있지 않게(둘레 8칸에 다른 함정 없음) 묻혀요. 동굴 붕괴는 보물상자 바로 옆에 묻히지 않아요.',
        '함정 수는 옵션(적게 · 보통 · 많이)이고 섬 크기에 맞춰 조정돼요. 종류는 해골 → 늪 → 독침 → 미믹 → 붕괴 → 저주 차례로 돌아가며 정해져요(함정 수가 적으면 앞쪽 것만).'] },
      { h: '땅 종류 (원시섬)', p: [
        '원시섬은 판마다 모양(둥근 · 길쭉 · 초승달 · 쌍둥이 섬)부터 새로 만들어요. 강 · 야자 숲 · 바위 무더기가 생겨요.',
        '💧 젖은 모래(강가, 물결 무늬): 부드러워서 파고 나서 한 칸 더 팔 수 있어요(차례에 한 번만).',
        '🪨 자갈땅(바위 옆, 돌 무늬): 단단해서 파면 그 차례가 바로 끝나요(삽 · 젖은 모래 덤도 끝). 빈 땅이어도 숫자가 안 나와요.',
        '강 · 야자 · 바위는 못 파요. 탐지기는 강 위에도 쓸 수 있어요.'] },
      { h: '도구 (옵션, 기본 켬)', p: [
        '땅에서 도구가 나오면 내 것이 돼요. 쓰는 건 공짜예요(차례를 쓰지 않아요). 이름표 옆에 가진 도구 수가 보여요.',
        '◎ 탐지기: 버튼을 누르고 칸을 골라 「여기 탐지」 → 그 칸을 가운데로 3×3 안의 보물 수를 알려 줘요(파란 점선).',
        '⛏ 삽: 차례 처음(파기 전)에 누르면 이번 차례에 두 칸을 파요.',
        '▤ 지도 조각: 버튼을 누르고 가로줄을 골라 「이 줄 보기」 → 그 줄의 보물 수를 알려 줘요(노란 줄). 이미 본 줄은 다시 못 골라요.',
        '도구로 얻은 정보는 모두에게 보여요.'] },
      { h: '맵', p: [
        '모래섬 · 정글섬(강·다리·나무) · 화산섬(용암) · 눈꽃섬(얼음 호수·전나무) · 다리 군도(물길로 나뉜 섬) · 유적섬(신전 벽·돌기둥) · 안개 늪(웅덩이) · 산호 환초(가운데 석호) · 해골섬(구덩이·이빨) · 원시섬(판마다 새로 만드는 섬), 모두 10가지.',
        '「무작위」(기본)는 매 판 다른 맵이에요. 같은 맵도 섬 모양이 판마다 조금씩 달라요.'] },
      { h: '조작', p: [
        '칸 탭 → 고르기, 한 번 더 탭(또는 「파기」) → 파기. 누른 채 밀면 고른 칸을 옮겨요(손을 떼도 파지 않아요).',
        '칸을 꾹 누르면 메모: ✕(피할 칸) → ★(노릴 칸) → 지우기. 메모는 이 폰에만 보여요.',
        '방금 판 칸은 판 사람 색 테두리로 보여요. 아래 안내 줄이 지금 할 일을 알려 줘요.'] },
      { h: '예시', p: [
        '내가 판 칸에서 「2」가 나왔어요 → 둘레 8칸 중 2칸에 보물이 있어요.',
        '그 옆 칸에서는 「0」이 나왔어요 → 그 칸 둘레엔 보물이 없어요. 두 칸이 겹치지 않는 쪽을 노려요.',
        '노린 칸을 탭 → 한 번 더 탭 → 금괴! +5점.'] },
      { h: 'AI 난이도', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 반쯤 아무 데나 파고, 보통은 주변 숫자로 확률을 어림하며, 어려움은 숫자들을 함께 풀어 정확한 확률과 기대 점수로 골라요.'] },
    ],
    tutorial: [
      { text: '섬 땅속에 보물이 묻혀 있어요. 동전 2점 · 금괴 5점 · 보물상자 10점! 번갈아 한 칸씩 파서 점수를 모아요.' },
      { sel: '.tr-chips', text: '이름표에 각자 점수와 가진 도구가 보여요. 테두리가 빛나는 사람이 지금 차례예요.' },
      { sel: '.tr-info', text: '맵 이름 · 내 차례 수(정해진 횟수) · 남은 보물 · 함정 수예요. 차례를 다 쓰거나 보물이 다 나오면 끝나요.' },
      { text: '팔 칸을 탭하고, 한 번 더 탭하면 파요. 빈 땅에서 나온 숫자는 둘레 8칸에 묻힌 보물 수예요. 숫자를 보고 추리하세요!' },
      { text: '함정도 묻혀 있어요: 해골 −4점, 모래 늪은 한 차례 쉼, 독침·저주 상자·동굴 붕괴·미믹 상자까지! 미믹은 숫자에 보물로 잡혀요. 피할 칸은 꾹 눌러 ✕ 메모(이 폰에만 보여요).' },
      { sel: '.tr-row', text: '땅에서 얻은 도구는 여기서 써요(공짜): ◎ 탐지기 3×3 보물 수 · ⛏ 삽 두 칸 파기 · ▤ 지도 한 줄 보물 수. 「파기」로 파요.' },
      { sel: '.tr-hint', text: '막히면 이 안내 줄을 보세요. 지금 할 일을 알려 줘요. 그럼 파 볼까요?' },
    ],
    codex: [
      { h: '보물', p: ['점수가 되는 것들이에요. 개수는 섬 크기에 맞춰 정해져요(보물상자 15% · 금괴 35% · 나머지 동전).'], rows: [1, 2, 3].map((c) => ({ icon: ['', '💰', '🪙', '🧰'][c], name: NAME[c], tag: '+' + VAL[c] + '점', desc: c === 3 ? '가장 값진 보물. 동굴 붕괴는 상자 바로 옆엔 묻히지 않아요.' : c === 2 ? '중간 보물.' : '가장 흔한 보물.' })) },
      { h: '함정', p: ['함정끼리는 둘레 8칸 안에 붙어 묻히지 않아요. 종류별 개수는 정해진 순서로 나뉘어 모두가 같은 조건이에요.'], rows: [
        { icon: '💀', name: NAME[4], tag: '−' + TRAP_PTS + '점', desc: '가장 흔한 함정이에요.' },
        { icon: '🟢', name: NAME[5], tag: '한 차례 쉼', desc: '그 자리에서 차례가 끝나고 다음 차례를 쉬어요.' },
        { icon: '🗡️', name: NAME[9], tag: '−' + DART_PTS + '점 · 도구 봉인', desc: '다음 내 차례가 끝날 때까지 탐지기·삽·지도를 못 써요.' },
        { icon: '👅', name: NAME[12], tag: '−' + MIMIC_PTS + '점 · 차례 끝', desc: '숫자·탐지기·지도에는 보물처럼 잡혀요. 숫자가 큰 곳도 방심 금물!' },
        { icon: '🪨', name: NAME[11], tag: '옆 4칸 묻힘', desc: '위·아래·옆의 안 판 땅이 묻혀 못 파요. 묻힌 칸 속은 공개돼요.' },
        { icon: '🟣', name: NAME[10], tag: '점수 맞바꾸기', desc: '가장 낮은 다른 사람과 점수를 바꿔요. 내가 가장 낮으면 −' + CURSE_PTS + '점(혼자면 −' + CURSE_SOLO + '점).' },
      ] },
      { h: '도구', p: ['땅에서 나오면 내 것이 되고, 쓰는 데 차례를 쓰지 않아요.'], rows: [
        { icon: '◎', name: NAME[6], tag: '3×3', desc: '고른 칸을 가운데로 3×3 안의 보물 수(미믹 포함)를 알려 줘요.' },
        { icon: '⛏', name: NAME[7], tag: '두 칸', desc: '차례 처음에 쓰면 이번 차례에 두 칸을 파요.' },
        { icon: '▤', name: NAME[8], tag: '한 줄', desc: '가로줄 하나의 보물 수(미믹 포함)를 알려 줘요.' },
      ] },
      { h: '땅', p: ['팔 수 있는 땅과 못 파는 지형이에요.'], rows: [
        { icon: '🏝️', name: '맨땅', tag: '보통', desc: '모래 · 흙 · 눈 · 돌바닥. 한 칸 파면 차례 끝.' },
        { icon: '💧', name: '젖은 모래', tag: '원시섬 강가', desc: '파고 나서 한 칸 더(차례에 한 번).' },
        { icon: '🪨', name: '자갈땅', tag: '원시섬 바위 옆', desc: '파면 차례가 바로 끝나고, 빈 땅이어도 숫자가 안 나와요.' },
        { icon: '🌴', name: '나무 · 바위 · 강 · 용암 · 얼음 · 웅덩이 · 기둥 · 벽 · 다리', tag: '못 파요', desc: '탐지기는 바다만 빼고 어디든 가운데로 고를 수 있어요.' },
      ] },
      { h: '맵', p: ['「무작위」(기본)는 매 판 다른 맵. 같은 맵도 판마다 모양이 조금씩 달라요.'], rows: MAPS.slice(1).map((m) => ({ icon: '🗺️', name: m.name, tag: m.k === 'wild' ? '판마다 새로' : '고정 모양 + 변형', desc: { sand: '둥근 모래섬과 바위.', jungle: '섬을 가르는 강과 다리, 빽빽한 나무.', volcano: '가운데 분화구와 용암 줄기.', snow: '얼음 호수와 눈 덮인 전나무.', arch: '십자 물길로 나뉜 네 섬과 다리.', ruins: '무너진 신전 벽과 돌기둥.', swamp: '웅덩이와 마른 나무.', atoll: '고리 모양 산호섬, 가운데 석호.', skull: '해골 모양 섬: 눈·코 구덩이, 이빨.', wild: '둥근·길쭉·초승달·쌍둥이 중 하나로 새로 만들고, 강·야자 숲·바위 무더기 · 젖은 모래 · 자갈땅이 생겨요.' }[m.k] })) },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { gen, terrain, MAPS, build, code, knowledge, probsExact, probsSimple, nbList, decC, encC },
  });
})();
