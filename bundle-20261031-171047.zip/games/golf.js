/* 미니 골프 — 무작위 생성 코스(6/9/18홀) 또는 기본 6홀. 결정적 고정 스텝 물리: apply가 끝까지 시뮬레이션하고, 뷰는 last.pre+last.shot을 재생한다. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* invisible box over a canvas region so the first-play tutorial (sel) can spotlight it.
     set(x, y, w, h) in stage px; set(null) takes it out of the DOM (the tutorial then shows no ring). */
  function tutSpot(root, cls) {
    const e = L.h('div', { class: 'tut-spot ' + cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', left: '0px', top: '0px', width: '0px', height: '0px' } });
    let key = '';
    const set = (x, y, w, h) => {
      if (x == null || !(w > 0 && h > 0)) { if (e.parentNode) e.remove(); key = ''; return; }
      if (!e.parentNode) root.append(e);
      const v = [x, y, w, h].map(Math.round), k = v.join(',');
      if (k === key) return; key = k;
      Object.assign(e.style, { left: v[0] + 'px', top: v[1] + 'px', width: v[2] + 'px', height: v[3] + 'px' });
    };
    set.el = e;
    return set;
  }

  /* ---------- course (400×700 units) ---------- */
  const CW = 400, CH = 700, BR = 7, CR = 11, WT = 5; // ball radius, cup radius, inner wall half thickness
  const DT = 1 / 240, VMAX = 640, MU = 120, KD = 0.3, MAXT = 14, VCUP = 210, PULL = 2400, MAXK = 7;
  // windmill: per-step rotation (ω = 1.5 rad/s) as literals so every engine gets bit-identical results.
  // The start phase of each shot is random (drawn in apply) and travels in the shot as a rounded direction [cos, sin],
  // normalised here with sqrt/÷ only, so the host's result and every replay are identical.
  const MC = 0.9999804688135782, MS = 0.006249959309975306;
  function millDir(m) {
    const c = m ? +m[0] : 1, s = m ? +m[1] : 0, l = Math.sqrt(c * c + s * s);
    return l > 1e-6 ? [c / l, s / l] : [1, 0];
  }
  const r4 = (v) => Math.round(v * 10000) / 10000;
  function randMill() { const a = Math.random() * Math.PI; return [r4(Math.cos(a)), r4(Math.sin(a))]; } // the bar is symmetric: half a turn covers every pose
  const HOLES = [
    { name: '첫 퍼팅', par: 2, tee: [200, 615], cup: [200, 105],
      poly: [[110, 40], [290, 40], [330, 120], [330, 600], [290, 665], [110, 665], [70, 600], [70, 120]],
      walls: [[150, 380, 205, 345], [250, 250, 290, 275]], posts: [[200, 210, 12]] },
    { name: '모래 굽이', par: 3, tee: [100, 615], cup: [305, 115],
      poly: [[40, 670], [160, 670], [160, 260], [370, 260], [370, 40], [130, 40], [40, 130]],
      walls: [[230, 260, 230, 200]], posts: [],
      sand: [[215, 125, 42, 28], [100, 300, 34, 22]] },
    { name: '외나무다리', par: 3, tee: [200, 620], cup: [275, 110],
      poly: [[60, 40], [340, 40], [340, 670], [60, 670]],
      walls: [[60, 470, 130, 470], [270, 470, 340, 470]], posts: [[200, 190, 11], [130, 150, 9]],
      water: [[60, 290, 182, 420], [218, 290, 340, 420]], bridge: [182, 290, 218, 420] },
    { name: '기울어진 언덕', par: 3, tee: [200, 625], cup: [115, 115],
      poly: [[60, 40], [340, 40], [340, 670], [60, 670]],
      walls: [[60, 200, 160, 200], [230, 200, 230, 130]], posts: [],
      slope: [[60, 250, 340, 470, 105, 0]], water: [[300, 300, 340, 430]], sand: [[300, 110, 30, 22]] },
    { name: '풍차', par: 3, tee: [200, 625], cup: [200, 100],
      poly: [[60, 670], [340, 670], [340, 430], [252, 385], [252, 275], [340, 235], [340, 40], [60, 40], [60, 235], [148, 275], [148, 385], [60, 430]],
      walls: [], posts: [[120, 160, 10], [280, 160, 10]],
      mill: [200, 330, 46] },
    { name: '지그재그', par: 4, tee: [95, 610], cup: [300, 105],
      poly: [[40, 40], [360, 40], [360, 670], [40, 670]],
      walls: [[40, 505, 275, 505], [125, 300, 360, 300], [300, 670, 360, 612], [40, 100, 100, 40]], posts: [[200, 590, 10]],
      sand: [[85, 400, 30, 40]], slope: [[150, 40, 360, 200, 0, 70]] },
  ];
  function prep(h) {
    h.segs = [];
    const P = h.poly;
    for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length]; addSeg(h, a[0], a[1], b[0], b[1], 0); }
    h.walls.forEach((w) => addSeg(h, w[0], w[1], w[2], w[3], WT));
    h.sand = h.sand || []; h.water = h.water || []; h.slope = h.slope || []; h.posts = h.posts || [];
    return h;
  }
  HOLES.forEach(prep);
  function addSeg(h, ax, ay, bx, by, th) { const dx = bx - ax, dy = by - ay; h.segs.push({ ax, ay, bx, by, dx, dy, l2: dx * dx + dy * dy, rr: BR + th }); }
  const inRect = (q, x, y) => x >= q[0] && x <= q[2] && y >= q[1] && y <= q[3];
  const inEll = (e, x, y) => { const u = (x - e[0]) / e[2], v = (y - e[1]) / e[3]; return u * u + v * v <= 1; };
  function inSand(h, x, y) { for (const e of h.sand) if (inEll(e, x, y)) return true; return false; }
  function inWater(h, x, y) { for (const q of h.water) if (inRect(q, x, y)) return true; return false; }
  const r1 = (v) => Math.round(v * 10) / 10;

  /* ---------- deterministic simulation (+ − × ÷ √ only) ---------- */
  function Sim(hi, pre, shot) {
    this.h = hi;
    this.x = pre[0]; this.y = pre[1]; this.vx = shot.vx; this.vy = shot.vy;
    const p = millDir(shot.m); this.mc = p[0]; this.ms = p[1];
    this.n = 0; this.done = false; this.res = 'rest'; this.bounce = 0; this.cupT = 0; this.sandT = 0;
  }
  Sim.prototype.step = function () {
    const h = this.h;
    let vx = this.vx, vy = this.vy, x = this.x, y = this.y;
    // windmill rotation (direction vector rotated by fixed literal per step)
    if (h.mill) { const c = this.mc, s = this.ms; this.mc = c * MC - s * MS; this.ms = s * MC + c * MS; }
    const sp = Math.sqrt(vx * vx + vy * vy);
    if (sp < 3 && !this.cupT) { this.vx = 0; this.vy = 0; this.done = true; return; }
    // forces
    let mu = MU, kd = KD;
    if (inSand(h, x, y)) { mu = MU * 5.5; kd = 1.6; this.sandT = 1; }
    for (const q of h.slope) if (x >= q[0] && x <= q[2] && y >= q[1] && y <= q[3]) { vx += q[4] * DT; vy += q[5] * DT; }
    const s2 = Math.sqrt(vx * vx + vy * vy);
    if (s2 > 0) { let ns = (s2 - mu * DT) * (1 - kd * DT); if (ns < 0) ns = 0; const f = ns / s2; vx *= f; vy *= f; }
    // cup
    const cx = h.cup[0] - x, cy = h.cup[1] - y, cd2 = cx * cx + cy * cy;
    this.cupT = 0;
    if (cd2 < CR * CR) {
      const cd = Math.sqrt(cd2);
      if (cd > 0.01) { vx += cx / cd * PULL * DT; vy += cy / cd * PULL * DT; }
      this.cupT = 1;
      const s3 = Math.sqrt(vx * vx + vy * vy);
      if (cd < CR * 0.55 && s3 < VCUP) { this.x = h.cup[0]; this.y = h.cup[1]; this.vx = 0; this.vy = 0; this.done = true; this.res = 'cup'; return; }
    }
    x += vx * DT; y += vy * DT;
    // walls
    for (let k = 0; k < h.segs.length; k++) {
      const s = h.segs[k];
      let t = ((x - s.ax) * s.dx + (y - s.ay) * s.dy) / s.l2;
      if (t < 0) t = 0; else if (t > 1) t = 1;
      const qx = s.ax + s.dx * t, qy = s.ay + s.dy * t, ex = x - qx, ey = y - qy, d2 = ex * ex + ey * ey;
      if (d2 >= s.rr * s.rr || d2 < 1e-12) continue;
      const d = Math.sqrt(d2), nx = ex / d, ny = ey / d, vn = vx * nx + vy * ny;
      if (vn < 0) { vx -= 1.78 * vn * nx; vy -= 1.78 * vn * ny; this.bounce++; }
      x = qx + nx * s.rr; y = qy + ny * s.rr;
    }
    for (let k = 0; k < h.posts.length; k++) {
      const p = h.posts[k], ex = x - p[0], ey = y - p[1], rr = p[2] + BR, d2 = ex * ex + ey * ey;
      if (d2 >= rr * rr || d2 < 1e-12) continue;
      const d = Math.sqrt(d2), nx = ex / d, ny = ey / d, vn = vx * nx + vy * ny;
      if (vn < 0) { vx -= 1.85 * vn * nx; vy -= 1.85 * vn * ny; this.bounce++; }
      x = p[0] + nx * rr; y = p[1] + ny * rr;
    }
    if (h.mill) {
      const m = h.mill, hub = 9 + BR;
      let ex = x - m[0], ey = y - m[1], d2 = ex * ex + ey * ey;
      if (d2 < hub * hub && d2 > 1e-12) { const d = Math.sqrt(d2), nx = ex / d, ny = ey / d, vn = vx * nx + vy * ny; if (vn < 0) { vx -= 1.7 * vn * nx; vy -= 1.7 * vn * ny; } x = m[0] + nx * hub; y = m[1] + ny * hub; }
      // rotating bar: segment m ± l·u, angular velocity 1.5 rad/s
      const ux = this.mc, uy = this.ms, l = m[2];
      let t = (x - m[0]) * ux + (y - m[1]) * uy;
      if (t < -l) t = -l; else if (t > l) t = l;
      const qx = m[0] + ux * t, qy = m[1] + uy * t;
      ex = x - qx; ey = y - qy; d2 = ex * ex + ey * ey;
      const rr = BR + 4;
      if (d2 < rr * rr && d2 > 1e-12) {
        const d = Math.sqrt(d2), nx = ex / d, ny = ey / d;
        const bvx = -1.5 * (qy - m[1]), bvy = 1.5 * (qx - m[0]);
        const rn = (vx - bvx) * nx + (vy - bvy) * ny;
        if (rn < 0) { vx -= 1.75 * rn * nx; vy -= 1.75 * rn * ny; this.bounce++; }
        x = qx + nx * rr; y = qy + ny * rr;
      }
    }
    this.x = x; this.y = y; this.vx = vx; this.vy = vy;
    this.n++;
    if (inWater(h, x, y)) { this.done = true; this.res = 'water'; this.vx = 0; this.vy = 0; return; }
    if (this.n > MAXT / DT) { this.done = true; this.vx = 0; this.vy = 0; }
  };
  Sim.prototype.run = function () { while (!this.done) this.step(); return this; };
  Sim.prototype.end = function () { return [r1(this.x), r1(this.y)]; };
  function simulate(hi, pre, shot) { return new Sim(hi, pre, shot).run(); }

  /* ---------- state ---------- */
  const dist = (p, c) => Math.sqrt((p[0] - c[0]) * (p[0] - c[0]) + (p[1] - c[1]) * (p[1] - c[1]));
  function init(players, opts) {
    const n = players.length;
    const nh = { 6: 6, 9: 9, 18: 18 }[opts && opts.holes] || 9;
    const cs = opts && opts.course === 'classic' ? null : makeCourse((Math.random() * 2147483647) | 0, nh);
    const C = courseOf({ cs });
    return { n, cs, nm: players.map((p) => String(p.name || '').slice(0, 10)), h: 0, ph: 'p', p: players.map(() => C[0].tee.slice()), d: players.map(() => 0), k: players.map(() => 0),
      sc: players.map(() => []), w: players.map(() => 0), o: players.map((_, i) => i), seq: 0, last: null };
  }
  function actor(s) {
    if (s.ph === 'e') return null;
    if (s.ph === 'c') return s.o[0];
    const cup = courseOf(s)[s.h].cup;
    let best = null, bd = -1;
    for (const i of s.o) { if (s.d[i]) continue; const dd = dist(s.p[i], cup); if (dd > bd + 0.05) { bd = dd; best = i; } }
    return best;
  }
  function apply(s, seat, a) {
    if (actor(s) !== seat) throw new Error('not your turn');
    if (s.ph === 'c') {
      if (!a || a.type !== 'ok') throw new Error('bad action');
      s.h++; s.ph = 'p';
      s.p = s.p.map(() => courseOf(s)[s.h].tee.slice()); s.d = s.d.map(() => 0); s.k = s.k.map(() => 0);
      return s;
    }
    if (!a || a.type !== 'putt') throw new Error('bad action');
    const ang = +a.a, pw = +a.p;
    if (!isFinite(ang) || !isFinite(pw) || pw <= 0) throw new Error('bad shot');
    const p = U.clamp(pw, 0.02, 1);
    const pre = s.p[seat].slice(), C = courseOf(s);
    const shot = { vx: r1(Math.cos(ang) * p * VMAX), vy: r1(Math.sin(ang) * p * VMAX) };
    if (C[s.h].mill) shot.m = randMill();
    const r = simulate(C[s.h], pre, shot);
    const hole = s.h;
    s.k[seat]++;
    let ev = r.res;
    if (r.res === 'water') { s.k[seat]++; s.p[seat] = pre; if (s.w) s.w[seat]++; }
    else s.p[seat] = r.end();
    if (r.res === 'cup') { s.d[seat] = 1; }
    else if (s.k[seat] >= MAXK) { s.k[seat] = MAXK; s.d[seat] = 1; ev = ev === 'water' ? 'wmax' : 'max'; }
    s.seq++;
    s.last = { id: s.seq, seat, h: hole, pre, shot, ev, end: r.res === 'cup' ? 0 : r.end(), k: s.k[seat], sand: r.sandT };
    if (s.d.every((x) => x)) {
      s.sc.forEach((row, i) => row.push(s.k[i]));
      const prevO = s.o.slice();
      s.o = prevO.slice().sort((x, y) => s.k[x] - s.k[y] || prevO.indexOf(x) - prevO.indexOf(y));
      s.ph = s.h >= C.length - 1 ? 'e' : 'c';
    }
    return s;
  }
  const total = (row) => row.reduce((a, b) => a + b, 0);
  function result(s) {
    if (s.ph !== 'e') return null;
    const tot = s.sc.map(total), best = Math.min(...tot);
    const C = courseOf(s), par = C.reduce((a, h) => a + h.par, 0);
    const winners = tot.map((t, i) => (t === best ? i : -1)).filter((i) => i >= 0);
    const fmt = (t) => t - par === 0 ? 'E' : (t > par ? '+' : '') + (t - par);
    const lines = s.o.slice().sort((a, b) => tot[a] - tot[b]).map((i) => ((s.nm && s.nm[i]) || (i + 1) + '번') + ' · ' + tot[i] + '타 (' + fmt(tot[i]) + ')');
    const cnt = (i, f) => s.sc[i].filter((k, j) => f(k, C[j].par)).length, one = s.n === 1;
    const row = (label, fn) => (one ? { label, value: fn(0) } : { label, values: s.sc.map((_, i) => fn(i)) });
    const stats = [
      row('타수 (파 ' + par + ')', (i) => tot[i] + ' (' + fmt(tot[i]) + ')'),
      row('홀인원', (i) => cnt(i, (k) => k === 1) + '번'),
      row('버디 이상', (i) => cnt(i, (k, p) => k < p) + '홀'),
      row('파', (i) => cnt(i, (k, p) => k === p) + '홀'),
      row('보기 이하', (i) => cnt(i, (k, p) => k > p) + '홀'),
      row('홀당 평균', (i) => (tot[i] / Math.max(1, s.sc[i].length)).toFixed(1) + '타'),
    ];
    if (s.w) stats.push(row('물에 빠짐', (i) => s.w[i] + '번'));
    return { winners, title: winners.length > 1 ? '공동 우승' : undefined, text: (s.cs ? '생성 ' : '기본 ') + C.length + '홀 · 파 ' + par + '\n' + lines.join('\n'), stats };
  }

  /* ---------- AI: geodesic distance field per hole ---------- */
  const GS = 5, GX = CW / GS, GY = CH / GS;
  function inPoly(P, x, y) {
    let c = false;
    for (let i = 0, j = P.length - 1; i < P.length; j = i++) {
      const a = P[i], b = P[j];
      if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
    }
    return c;
  }
  function field(h) {
    if (h._f) return h._f;
    const N = GX * GY, ok = new Uint8Array(N), f = new Float64Array(N).fill(1e9);
    for (let j = 0; j < GY; j++) for (let i = 0; i < GX; i++) {
      const x = i * GS + GS / 2, y = j * GS + GS / 2;
      if (!inPoly(h.poly, x, y) || inWater(h, x, y)) continue;
      let bad = false;
      for (const s of h.segs) {
        let t = ((x - s.ax) * s.dx + (y - s.ay) * s.dy) / s.l2; t = Math.max(0, Math.min(1, t));
        const ex = x - s.ax - s.dx * t, ey = y - s.ay - s.dy * t;
        if (ex * ex + ey * ey < (s.rr - 1) * (s.rr - 1)) { bad = true; break; }
      }
      for (const p of h.posts) if (Math.hypot(x - p[0], y - p[1]) < p[2] + BR - 1) bad = true;
      if (!bad) ok[j * GX + i] = 1;
    }
    // Dijkstra from the cup
    const heap = [];
    const push = (c, d) => { heap.push([d, c]); let i = heap.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (heap[p][0] <= heap[i][0]) break; [heap[p], heap[i]] = [heap[i], heap[p]]; i = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === i) break; [heap[m], heap[i]] = [heap[i], heap[m]]; i = m; } } return top; };
    const ci = Math.floor(h.cup[0] / GS), cj = Math.floor(h.cup[1] / GS);
    f[cj * GX + ci] = 0; push(cj * GX + ci, 0);
    const NB = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]];
    while (heap.length) {
      const [d, c] = pop();
      if (d > f[c]) continue;
      const i = c % GX, j = (c / GX) | 0;
      for (const nb of NB) {
        const ii = i + nb[0], jj = j + nb[1];
        if (ii < 0 || jj < 0 || ii >= GX || jj >= GY) continue;
        const cc = jj * GX + ii;
        if (!ok[cc]) continue;
        const nd = d + nb[2] * GS * (inSand(h, ii * GS + 2.5, jj * GS + 2.5) ? 1.6 : 1);
        if (nd < f[cc]) { f[cc] = nd; push(cc, nd); }
      }
    }
    Object.defineProperty(h, '_f', { value: f, enumerable: false });
    return f;
  }
  function geo(h, x, y) {
    const f = field(h);
    const i = Math.floor(x / GS), j = Math.floor(y / GS);
    let best = 1e9;
    for (let r = 0; r <= 3 && best >= 1e9; r++) {
      for (let dj = -r; dj <= r; dj++) for (let di = -r; di <= r; di++) {
        const ii = i + di, jj = j + dj;
        if (ii < 0 || jj < 0 || ii >= GX || jj >= GY) continue;
        const v = f[jj * GX + ii];
        if (v < 1e9) best = Math.min(best, v + Math.hypot(di, dj) * GS);
      }
    }
    return best < 1e9 ? best : 2000;
  }
  const STROKE = 95;
  // the windmill phase is random per shot, so the AI judges a shot by its average over a few bar poses
  const AIPH = [[1, 0], [0.7071, 0.7071], [0, 1], [-0.7071, 0.7071]];
  function evalShot(s, seat, ang, p) { return evalH(courseOf(s)[s.h], s.p[seat], ang, p, AIPH); }
  function evalH(h, pre, ang, p, PH) {
    if (!h.mill) return evalOne(h, pre, ang, p, null);
    let t = 0;
    for (const m of PH) { const v = evalOne(h, pre, ang, p, m); t += v < -500 ? -250 : v; }
    return t / PH.length;
  }
  function evalOne(h, pre, ang, p, m) {
    const shot = { vx: r1(Math.cos(ang) * p * VMAX), vy: r1(Math.sin(ang) * p * VMAX), m };
    const r = simulate(h, pre, shot);
    if (r.res === 'cup') return -1000;
    if (r.res === 'water') return geo(h, pre[0], pre[1]) + STROKE * 1.2;
    let g = geo(h, r.x, r.y);
    if (inSand(h, r.x, r.y)) g += 30;
    if (g < 40) g = g * 0.6; // tap-in range
    return g;
  }
  /* per-seat level: 1 쉬움 = shaky stroke (casual ~+1/hole), full but quick search, no refinement; 2 보통; 3 어려움 = steady stroke, more refining */
  const GLV = { 1: { nz: 3.4, ms: 40, ref: 0, refK: 0 }, 2: { nz: 1, ms: 95, ref: 6, refK: 6 }, 3: { nz: 0.55, ms: 140, ref: 8, refK: 9 } };
  function ai(s, seat, lv) {
    if (s.ph === 'c') return { type: 'ok' };
    const K = GLV[lv] || GLV[2];
    const t0 = Date.now(), h = courseOf(s)[s.h], me = s.p[seat];
    field(h);
    const g0 = geo(h, me[0], me[1]);
    const direct = Math.atan2(h.cup[1] - me[1], h.cup[0] - me[0]);
    const dCup = dist(me, h.cup);
    const pDirect = Math.sqrt(2 * MU * 1.15 * dCup + 60 * 60) / VMAX;
    const cands = [];
    for (let i = -6; i <= 6; i++) for (const m of [0.85, 1, 1.15, 1.35]) cands.push([direct + i * 0.025, pDirect * m]);
    for (let i = 0; i < 36; i++) for (const p of [0.35, 0.55, 0.75, 0.95]) cands.push([i * Math.PI / 18 + (Math.random() - 0.5) * 0.08, p]);
    for (let i = 0; i < 20; i++) cands.push([Math.random() * Math.PI * 2, 0.2 + Math.random() * 0.8]);
    const scored = [];
    for (const c of cands) {
      if (Date.now() - t0 > K.ms && scored.length > 20) break;
      c[1] = U.clamp(c[1], 0.05, 1);
      scored.push({ a: c[0], p: c[1], v: evalShot(s, seat, c[0], c[1]) });
    }
    scored.sort((x, y) => x.v - y.v);
    // refine the best few, valuing robustness (average of a jittered pair)
    let best = null;
    for (const c of scored.slice(0, Math.max(1, K.ref))) {
      for (let k = 0; k < K.refK; k++) {
        if (Date.now() - t0 > K.ms + 45 + (lv === 3 ? 60 : 0)) break;
        const a = c.a + (Math.random() - 0.5) * 0.06, p = U.clamp(c.p * (1 + (Math.random() - 0.5) * 0.12), 0.05, 1);
        const v = (evalShot(s, seat, a, p) * 2 + evalShot(s, seat, a + 0.012, p) + evalShot(s, seat, a - 0.012, p)) / 4;
        if (!best || v < best.v) best = { a, p, v };
      }
      const v = (c.v * 2 + evalShot(s, seat, c.a + 0.012, c.p) + evalShot(s, seat, c.a - 0.012, c.p)) / 4;
      if (!best || v < best.v) best = { a: c.a, p: c.p, v };
    }
    if (!best || best.v > g0 + 50) best = best || { a: direct, p: pDirect };
    const far = U.clamp(dist(me, h.cup) / 300, 0.35, 1), noise = (0.03 * far + 0.006) * K.nz, pn = (0.07 * far + 0.02) * K.nz;
    return { type: 'putt', a: best.a + (Math.random() + Math.random() - 1) * noise, p: U.clamp(best.p * (1 + (Math.random() + Math.random() - 1) * pn), 0.03, 1) };
  }

  /* ---------- procedural course ----------
     genHole(seed, i, att) is pure integer arithmetic (seeded PRNG, integer coordinates), so every device builds the
     same layout. Only the host validates (solve): it keeps the first attempt the solver can hole in ≤ 4 strokes and
     stores that attempt number and the par in state.cs = {g:1, s:seed, a:[attempt…], p:[par…]} — guests never re-solve. */
  function prng(a) {
    return function () { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const NOUN = { st: '곧은 길', L: '굽은 길', hg: '잘록 허리', z3: '세 굽이', z4: '네 굽이', z5: '다섯 굽이', U: '말굽', S: '뱀길' };
  let SHAPE_W = ['st', 'st', 'L', 'L', 'hg', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'z3', 'z4', 'S', 'z5', 'z5', 'z5']; // weights: a mix of short and long holes
  function genHole(seed, i, att) {
    const R = prng((Math.imul(seed | 0, 31) + Math.imul(i + 1, 7919) + Math.imul(att + 1, 104729)) | 0);
    const ri = (a, b) => a + Math.floor(R() * (b - a + 1)), chance = (p) => R() < p;
    const shape = SHAPE_W[ri(0, SHAPE_W.length - 1)];
    const h = { poly: null, tee: null, cup: null, walls: [], posts: [], sand: [], water: [], slope: [] };
    if (shape === 'st') {
      const x0 = ri(50, 100), x1 = ri(300, 350);
      h.poly = [[x0, 40], [x1, 40], [x1, 670], [x0, 670]];
      h.tee = [ri(x0 + 40, x1 - 40), 620]; h.cup = [ri(x0 + 40, x1 - 40), ri(90, 150)];
    } else if (shape === 'L') {
      const w = ri(110, 150), bh = ri(150, 210);
      h.poly = [[40, 670], [40 + w, 670], [40 + w, 40 + bh], [360, 40 + bh], [360, 40], [40, 40]];
      if (chance(0.5)) { h.poly[5] = [40, 40 + ri(50, 80)]; h.poly.push([40 + ri(50, 80), 40]); }
      h.tee = [40 + (w >> 1), 620]; h.cup = [ri(270, 320), 40 + ri(50, bh - 50)];
      if (chance(0.4)) h.walls.push([40 + w, 40 + bh, 40 + w + ri(30, 60), 40 + bh - ri(30, 60)]);
    } else if (shape === 'z3' || shape === 'z4' || shape === 'z5') { // three to five baffles to weave through
      const n = +shape[1], top = [0, 0, 0, ri(220, 260), ri(170, 200), ri(145, 160)][n], bot = n === 5 ? ri(565, 580) : ri(520, 560), first = chance(0.5);
      h.poly = [[40, 40], [360, 40], [360, 670], [40, 670]];
      for (let k = 0; k < n; k++) {
        const y = Math.round(bot - (bot - top) * k / (n - 1)), g = n === 3 ? ri(66, 80) : ri(80, 100);
        if ((k % 2 === 0) === first) h.walls.push([40, y, 360 - g, y]); else h.walls.push([40 + g, y, 360, y]);
      }
      h.tee = [ri(90, 310), 620]; h.cup = [ri(90, 310), ri(80, top - 70)];
    } else if (shape === 'U') { // up one side, round the end of a long divider, back down the other
      const dy = ri(120, 170), dx = ri(185, 215);
      h.poly = [[40, 40], [360, 40], [360, 670], [40, 670]];
      h.walls.push([dx, 670, dx, dy]);
      const cap = ri(30, 50); h.walls.push([dx - cap, dy, dx + cap, dy]); // a T-cap: no easy bank shot round the end
      h.tee = [ri(85, dx - 50), 620]; h.cup = [ri(dx + 50, 315), ri(470, 620)];
    } else if (shape === 'S') { // a divider from each end: up, across, down, across, up
      const a = ri(130, 150), b = ri(250, 270), t1 = ri(170, 220), t2 = ri(490, 540);
      h.poly = [[40, 40], [360, 40], [360, 670], [40, 670]];
      h.walls.push([a, 670, a, t1], [b, 40, b, t2]);
      h.tee = [ri(75, a - 35), 620]; h.cup = [ri(b + 35, 325), ri(90, 200)];
    } else {
      const hw = ri(46, 64), p0 = ri(270, 320), p1 = p0 + ri(90, 120);
      h.poly = [[60, 670], [340, 670], [340, p1 + 45], [200 + hw, p1], [200 + hw, p0], [340, p0 - 40], [340, 40], [60, 40], [60, p0 - 40], [200 - hw, p0], [200 - hw, p1], [60, p1 + 45]];
      h.tee = [ri(110, 290), 625]; h.cup = [ri(110, 290), ri(90, 150)];
      if (chance(0.55)) h.mill = [200, (p0 + p1) >> 1, hw - 6];
    }
    const mir = chance(0.5);
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const q of h.poly) { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); }
    // a point is free for a feature when it is inside the course, away from the tee, cup, edges and other things
    const blocks = [];
    const near = (x, y, r) => {
      if (D2(x, y, h.tee) < sq(r + 55) || D2(x, y, h.cup) < sq(r + 45)) return true;
      for (const b of blocks) if (D2(x, y, b) < sq(r + b[2])) return true;
      if (h.mill && D2(x, y, h.mill) < sq(r + h.mill[2] + 30)) return true;
      return false;
    };
    const free = (x, y, r) => {
      if (!inPoly(h.poly, x, y) || near(x, y, r)) return false;
      for (let k = 0; k < h.poly.length; k++) { const a = h.poly[k], b = h.poly[(k + 1) % h.poly.length]; if (segD(a, b, x, y) < sq(r + 12)) return false; }
      for (const w of h.walls) if (segD([w[0], w[1]], [w[2], w[3]], x, y) < sq(r + 30)) return false;
      return true;
    };
    const spot = (r) => { for (let t = 0; t < 30; t++) { const x = ri(x0 + 20, x1 - 20), y = ri(y0 + 20, y1 - 20); if (free(x, y, r)) return [x, y]; } return null; };
    const tags = [];
    // water: a side pool, or (straight course) a moat crossed by a bridge
    if (chance(shape === 'st' ? 0.5 : 0.3)) {
      if (shape === 'st' && chance(0.5)) {
        const wy = ri(300, 420), wh = ri(80, 120), bw = ri(40, 56), bx = ri(x0 + 30, x1 - 30 - bw);
        h.water.push([x0, wy, bx, wy + wh], [bx + bw, wy, x1, wy + wh]); h.bridge = [bx, wy, bx + bw, wy + wh];
        blocks.push([bx + bw / 2, wy + wh / 2, wh / 2 + 10]);
        tags.push('다리');
      } else {
        const ww = ri(45, 75), wy = ri(y0 + 150, y1 - 270), wh = ri(90, 160), left = chance(0.5);
        const q = left ? [x0, wy, x0 + ww, wy + wh] : [x1 - ww, wy, x1, wy + wh];
        if (!near((q[0] + q[2]) / 2, (q[1] + q[3]) / 2, wh / 2 + 20)) { h.water.push(q); blocks.push([(q[0] + q[2]) / 2, (q[1] + q[3]) / 2, wh / 2 + 10]); tags.push('연못'); }
      }
    }
    if (chance(0.4)) {
      const sy = ri(y0 + 130, y1 - 250), sh = ri(110, 190), v = chance(0.5) ? [(chance(0.5) ? 1 : -1) * ri(60, 110), 0] : [0, (chance(0.5) ? 1 : -1) * ri(40, 70)];
      h.slope.push([x0, sy, x1, sy + sh, v[0], v[1]]); tags.push('비탈');
    }
    const ns = ri(0, 2);
    for (let k = 0; k < ns; k++) { const rx = ri(25, 42), ry = ri(18, 28), p = spot(rx); if (p) { h.sand.push([p[0], p[1], rx, ry]); blocks.push([p[0], p[1], rx + 10]); if (!k) tags.push('모래'); } }
    const busy = shape[0] === 'z' || shape === 'S', np = busy ? ri(0, 1) : ri(0, 3);
    for (let k = 0; k < np; k++) { const r = ri(9, 13), p = spot(r + 18); if (p) { h.posts.push([p[0], p[1], r]); blocks.push([p[0], p[1], r + 30]); if (k === 1) tags.push('기둥'); } }
    if (!busy) {
      const nw = ri(0, 2), D = [[1, 0], [0, 1], [1, 1], [1, -1]];
      for (let k = 0; k < nw; k++) {
        const p = spot(50); if (!p) continue;
        const d = D[ri(0, 3)], l = ri(24, 42), a = [p[0] - d[0] * l, p[1] - d[1] * l], b = [p[0] + d[0] * l, p[1] + d[1] * l];
        if (!inPoly(h.poly, a[0], a[1]) || !inPoly(h.poly, b[0], b[1])) continue;
        h.walls.push([a[0], a[1], b[0], b[1]]); blocks.push([p[0], p[1], l + 25]); if (!k) tags.push('담장');
      }
    }
    if (h.mill) tags.unshift('풍차');
    if (mir) {
      const M = (q) => [400 - q[0]].concat(q.slice(1));
      h.poly = h.poly.map(M); h.tee = M(h.tee); h.cup = M(h.cup);
      h.walls = h.walls.map((w) => [400 - w[0], w[1], 400 - w[2], w[3]]);
      h.posts = h.posts.map(M); h.sand = h.sand.map(M);
      h.water = h.water.map((q) => [400 - q[2], q[1], 400 - q[0], q[3]]);
      if (h.bridge) { const b = h.bridge; h.bridge = [400 - b[2], b[1], 400 - b[0], b[3]]; }
      h.slope = h.slope.map((q) => [400 - q[2], q[1], 400 - q[0], q[3], -q[4], q[5]]);
      if (h.mill) h.mill = M(h.mill);
    }
    h.name = (tags.length ? tags[0] + ' ' : '') + NOUN[shape];
    h.par = 3;
    return prep(h);
  }
  function segD(a, b, x, y) {
    const dx = b[0] - a[0], dy = b[1] - a[1], l2 = dx * dx + dy * dy;
    let t = l2 ? ((x - a[0]) * dx + (y - a[1]) * dy) / l2 : 0; t = Math.max(0, Math.min(1, t));
    const ex = x - a[0] - dx * t, ey = y - a[1] - dy * t;
    return ex * ex + ey * ey; // squared (exact arithmetic only, so every device places features alike)
  }
  const sq = (v) => v * v, D2 = (x, y, p) => (x - p[0]) * (x - p[0]) + (y - p[1]) * (y - p[1]);
  /* solver: a steady, no-noise golfer (coarse fan of shots + refinement, windmill judged over two poses).
     Returns the strokes it needed (1–4), or 0 when the hole is unfair / unplayable. */
  const SPH = [[1, 0], [0, 1]];
  function solve(h, nz, lim) {
    lim = lim || 4;
    field(h);
    if (geo(h, h.tee[0], h.tee[1]) >= 2000) return 0;
    let p = h.tee.slice();
    for (let k = 1; k <= lim; k++) {
      const dir = Math.atan2(h.cup[1] - p[1], h.cup[0] - p[0]), dc = dist(p, h.cup);
      const pd = Math.sqrt(2 * MU * 1.15 * dc + 3600) / VMAX, c = [];
      for (let i = -4; i <= 4; i++) for (const m of [0.9, 1, 1.15, 1.35]) c.push([dir + i * 0.03, pd * m]);
      for (let i = 0; i < 16; i++) for (const q of [0.4, 0.65, 0.95]) c.push([i * Math.PI / 8 + 0.1, q]);
      let sc = c.map(([a, q]) => { q = Math.min(1, Math.max(0.05, q)); return { a, q, v: evalH(h, p, a, q, SPH) }; }).sort((x, y) => x.v - y.v);
      const top = sc.slice(0, 4);
      for (const t of top) for (let j = 0; j < 6; j++) { const a = t.a + (j - 2.5) * 0.012, q = Math.min(1, Math.max(0.05, t.q * (1 + ((j % 3) - 1) * 0.06))); sc.push({ a, q, v: evalH(h, p, a, q, SPH) }); }
      sc.sort((x, y) => x.v - y.v);
      const b = sc[0];
      if (!nz && b.v < -500) return k;
      if (nz) { const far = Math.min(1, Math.max(0.35, dc / 300)); b.a += (Math.random() + Math.random() - 1) * (0.03 * far + 0.006) * nz; b.q = Math.min(1, b.q * (1 + (Math.random() + Math.random() - 1) * (0.07 * far + 0.02) * nz)); }
      const r = simulate(h, p, { vx: r1(Math.cos(b.a) * b.q * VMAX), vy: r1(Math.sin(b.a) * b.q * VMAX), m: SPH[0] });
      if (r.res === 'cup') return k;
      if (r.res !== 'water') p = r.end();
    }
    return 0;
  }
  let PA = 0.78, PB = 0.38; // par = round(noisy mean × PA + PB), fitted on ~200 holes against 보통/어려움 AI games
  function makeCourse(seed, n) {
    const a = [], p = [];
    for (let i = 0; i < n; i++) {
      let att = 0, par = 3;
      for (; att < 40; att++) {
        const h = genHole(seed, i, att);
        // par: an ordinary player's score. The noisy solver (보통 AI's stroke noise; a miss in 7 counts as 8) reads the
        // green worse than a person/보통 AI does, and more so on long holes, so the mean is scaled down (PA, PB) — calibrated against AI games:
        // 보통 ≈ par, 어려움 a little under, 쉬움 over. 2 tries first; a 3rd only when they disagree (keeps building quick).
        const r0 = solve(h, 1, 7) || 8, r1 = solve(h, 1, 7) || 8;
        if (r0 === 8 && r1 === 8) continue; // unplayable or far too luck-dependent
        let sum = r0 + r1, nt = 2;
        if (r0 !== r1) { sum += solve(h, 1, 7) || 8; nt = 3; }
        if (sum / nt > 6) continue; // too luck-dependent for an ordinary player
        par = Math.max(2, Math.min(5, Math.round(sum / nt * PA + PB))); break;
      }
      if (att >= 40) { att = 0; par = 5; } // practically never; keep the game going
      a.push(att); p.push(par);
    }
    return { g: 1, s: seed, a, p };
  }
  const cCache = new Map();
  function courseOf(s) {
    const cs = s && s.cs;
    if (!cs || !cs.g) return HOLES;
    const key = cs.s + ':' + cs.a.join(',');
    let C = cCache.get(key);
    if (!C) {
      C = cs.a.map((att, i) => { const h = genHole(cs.s, i, att); h.par = cs.p[i]; return h; });
      if (cCache.size > 6) cCache.clear();
      cCache.set(key, C);
    }
    // pars come from the state (a guest never re-solves)
    C.forEach((h, i) => { h.par = cs.p[i]; });
    return C;
  }

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let HS = HOLES, bestDone = false;
    let st = null, prevSt = null, G = null, dirty = true;
    let sim = null, simAcc = 0, animLast = null, shownSeq = -1, trail = [], sparks = [], others = null;
    let drag = null, cardEl = null, cardKey = '', cardTimer = 0, lastBounce = 0, millIdle = null;
    let feltPat = null, sentAt = 0, finTimer = 0, animTimer = 0;
    let guideLong = false, lastPw = {}, lastTick = -1, wasCancel = false;
    try { guideLong = !!U.store.get('golf.guide', false); } catch (e) {}
    const top = L.h('div', { class: 'hud top', style: { gap: '6px', padding: '8px 10px', flexWrap: 'nowrap' } });
    const bot = L.h('div', { class: 'hud bottom gf-bar', style: { padding: '8px 10px' } });
    root.append(top, bot);
    // invisible boxes over the ball / cup for the first-play tutorial spotlight
    const spBall = tutSpot(root, 'gf-ball'), spCup = tutSpot(root, 'gf-cup');

    // camera: fit the current hole's bounding box (plus the wood border) into the free area between the HUD bars
    function layout() {
      const w = cv.w, hh = cv.h, topH = 58, botH = 64, hi = viewHole();
      const P = HS[hi].poly, M = 16;
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      for (const q of P) { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); }
      x0 -= M; y0 -= M; x1 += M; y1 += M;
      const k = Math.max(0.1, Math.min((w - 12) / (x1 - x0), (hh - topH - botH) / (y1 - y0), 1.6));
      G = { k, hi, ox: (w - (x1 - x0) * k) / 2 - x0 * k, oy: topH + (hh - topH - botH - (y1 - y0) * k) / 2 - y0 * k };
      if (!feltPat) feltPat = makeNoise();
      dirty = true;
    }
    function makeNoise() {
      const c = document.createElement('canvas'); c.width = 80; c.height = 80;
      const g = c.getContext('2d'), im = g.createImageData(80, 80);
      for (let i = 0; i < im.data.length; i += 4) { const n = Math.random(); const v = n < 0.5 ? 0 : 255; im.data[i] = v; im.data[i + 1] = v; im.data[i + 2] = v; im.data[i + 3] = Math.floor(Math.abs(n - 0.5) * 30); }
      g.putImageData(im, 0, 0);
      return ctx.createPattern(c, 'repeat');
    }
    const viewHole = () => (sim ? animLast.h : st ? Math.min(st.h, HS.length - 1) : 0);
    cv.onresize = layout; layout();
    const TX = (x) => G.ox + x * G.k, TY = (y) => G.oy + y * G.k;

    function color(i) { return api.players[i] ? api.players[i].color : '#fff'; }

    /* ---- HUD ---- */
    function toPar(i) {
      const done = st.sc[i].length; if (!done) return '';
      const d = total(st.sc[i]) - HS.slice(0, done).reduce((a, h) => a + h.par, 0);
      return '(' + (d === 0 ? 'E' : (d > 0 ? '+' : '') + d) + ')';
    }
    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      const cur = sim ? animLast.seat : actor(st);
      for (let i = 0; i < st.n; i++) {
        const p = api.players[i], on = cur === i && st.ph === 'p';
        const tot = total(st.sc[i]) + (st.ph === 'p' ? st.k[i] : 0);
        top.append(L.h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '5px 8px', display: 'flex', flexDirection: 'column', gap: '1px',
          borderColor: on ? p.color : '', boxShadow: on ? '0 0 0 1px ' + p.color : 'none', opacity: on || st.ph !== 'p' ? 1 : 0.72 } },
        L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden' } },
          L.h('span', { class: 'dot', style: { '--c': p.color } }), L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' }, text: p.name })),
        L.h('div', { class: 'mono', style: { fontSize: '12px', display: 'flex', gap: '6px', whiteSpace: 'nowrap' } },
          L.h('span', { style: { color: st.d[i] && st.ph === 'p' ? '#5fd3a0' : 'var(--ink)' }, text: (st.ph === 'p' ? (st.d[i] ? '✓' : '') + st.k[i] + '타' : '') }),
          L.h('span', { class: 'muted', text: '합 ' + tot + ' ' + toPar(i) }))));
      }
    }
    let botKey = '';
    function renderBot() {
      if (!st) { bot.innerHTML = ''; return; }
      const hi = viewHole(), h = HS[hi];
      const a = sim ? animLast.seat : actor(st);
      const mine = st.ph === 'p' && a != null && !sim && api.canAct(a);
      let msg = '';
      if (st.ph === 'p' && a != null && !sim) msg = mine ? '뒤로 끌어 놓기 · 빈 곳에서 해도 돼요' : api.players[a].name + (api.players[a].ai ? ' 생각 중…' : ' 차례');
      const stroke = st.ph === 'p' && a != null ? (sim ? animLast.k : st.k[a] + 1) : 0;
      const key = [hi, msg, stroke, a, mine, guideLong].join('|');
      if (key === botKey) return;
      botKey = key;
      bot.innerHTML = '';
      const info = L.h('div', { class: 'panel', style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: 700, minWidth: 0, flex: '1 1 auto', padding: '6px 10px' } },
        L.h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1, flex: 'none' } },
          L.h('span', { style: { fontFamily: 'var(--f-display)', fontSize: '20px', fontWeight: 400, color: 'var(--brass)' }, text: (hi + 1) + '번' }),
          L.h('span', { class: 'mono', style: { fontSize: '11px', marginTop: '3px' }, text: '파 ' + h.par })),
        L.h('div', { style: { display: 'flex', flexDirection: 'column', minWidth: 0, gap: '2px' } },
          L.h('span', { style: { whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } },
            stroke ? L.h('span', { class: 'dot', style: { '--c': color(a), display: 'inline-block', marginRight: '5px' } }) : null,
            h.name, stroke ? L.h('span', { class: 'mono', style: { marginLeft: '6px', color: 'var(--ink)' }, text: stroke + '타째' }) : null),
          msg ? L.h('span', { class: 'muted', style: { fontWeight: 500, fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, text: msg }) : null));
      bot.append(info);
      if (mine) bot.append(L.h('button', { class: 'btn sm' + (guideLong ? ' primary' : ''), 'data-action': 'guide', style: { flex: 'none', minHeight: '44px', minWidth: '64px', padding: '0 10px', fontSize: '12px', lineHeight: 1.15 },
        'aria-label': '조준선 길이', onclick() { guideLong = !guideLong; U.store.set('golf.guide', guideLong); api.sfx('click'); api.buzz(8); botKey = ''; renderBot(); dirty = true; } },
        L.h('span', { html: '조준선<br>' + (guideLong ? '길게' : '짧게') })));
      bot.style.flexWrap = 'nowrap';
    }

    /* ---- scorecard ---- */
    function showCard() {
      const key = st.ph + ':' + st.h;
      if (st.ph !== 'c') { if (cardEl) { cardEl.remove(); cardEl = null; } cardKey = ''; return; }
      if (cardKey === key && cardEl) return;
      cardKey = key;
      if (cardEl) cardEl.remove();
      const c0 = HS.length > 9 && st.h >= 9 ? 9 : 0, CS = HS.slice(c0, c0 + 9), pars = HS.map((h) => h.par);
      const th = (t, extra) => L.h('th', { style: Object.assign({ padding: '4px 3px', fontWeight: 700, fontSize: '11px', color: 'var(--muted)' }, extra || {}), text: t });
      const td = (t, extra) => L.h('td', { class: 'mono', style: Object.assign({ padding: '5px 3px', textAlign: 'center', fontSize: '13px' }, extra || {}), text: t });
      const rows = [L.h('tr', null, th('홀', { textAlign: 'left' }), CS.map((_, j) => th(String(c0 + j + 1), { color: c0 + j === st.h ? 'var(--brass)' : 'var(--muted)' })), th('합'))];
      rows.push(L.h('tr', { style: { borderBottom: '1px solid var(--line)' } }, th('파', { textAlign: 'left' }), CS.map((h) => td(String(h.par), { color: 'var(--muted)' })), td(String(pars.reduce((a, b) => a + b, 0)), { color: 'var(--muted)' })));
      for (const i of st.o) {
        const p = api.players[i];
        rows.push(L.h('tr', null,
          L.h('td', { style: { padding: '5px 3px', maxWidth: '78px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: '13px', fontWeight: 700 } },
            L.h('span', { class: 'dot', style: { '--c': p.color, display: 'inline-block', marginRight: '4px' } }), p.name),
          CS.map((h, j) => {
            const hi = c0 + j, v = st.sc[i][hi];
            if (v == null) return td('·', { color: 'var(--muted)' });
            const diff = v - h.par;
            return td(String(v), { color: diff < 0 ? '#5fd3a0' : diff > 0 ? '#ee6a55' : 'var(--ink)', fontWeight: diff < 0 ? 700 : 500 });
          }),
          td(String(total(st.sc[i])), { fontWeight: 700 })));
      }
      const nx = actor(st);
      const can = nx != null && api.canAct(nx);
      const btn = L.h('button', { class: 'btn primary block', 'data-action': 'next', style: { minHeight: '48px' }, text: st.h + 2 <= HS.length ? (st.h + 2) + '번 홀로 · 파 ' + HS[st.h + 1].par : '다음', onclick(e) { if (e.currentTarget.disabled) return; e.currentTarget.disabled = true; api.sfx('click'); api.buzz(10); if (!api.isHost) sentAt = performance.now(); api.act({ type: 'ok' }); } });
      cardEl = L.h('div', { class: 'overlay', style: { zIndex: 15, alignItems: 'flex-end', background: 'rgba(10,8,15,.45)', backdropFilter: 'none' } }, L.h('div', { class: 'sheet', style: { gap: '10px', padding: '16px' } },
        L.h('span', { class: 'label', text: '스코어카드' }),
        L.h('h2', { style: { fontSize: '24px' }, text: (st.h + 1) + '번 홀 끝' }),
        L.h('div', { style: { overflowX: 'auto' } }, L.h('table', { style: { width: '100%', borderCollapse: 'collapse' } }, rows)),
        can ? btn : L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: api.players[nx].name + (api.players[nx].ai ? '이(가) 곧 다음 홀로 넘어가요' : ' 님이 다음 홀을 시작해요') })));
      root.append(cardEl);
      // keep the card on screen for a moment before an AI dismisses it
      if (nx != null && api.players[nx].ai) {
        api.setBusy(true);
        clearTimeout(cardTimer);
        cardTimer = setTimeout(() => api.setBusy(false), 1500 / L.debug.speed);
      }
    }

    /* ---- drawing ---- */
    function pathPoly(P) { ctx.beginPath(); P.forEach((q, i) => (i ? ctx.lineTo(TX(q[0]), TY(q[1])) : ctx.moveTo(TX(q[0]), TY(q[1])))); ctx.closePath(); }
    function drawWall(ax, ay, bx, by, th) {
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = th * 2 * G.k + 2;
      ctx.beginPath(); ctx.moveTo(TX(ax) + 2, TY(ay) + 3); ctx.lineTo(TX(bx) + 2, TY(by) + 3); ctx.stroke();
      ctx.strokeStyle = '#8a5326'; ctx.lineWidth = th * 2 * G.k;
      ctx.beginPath(); ctx.moveTo(TX(ax), TY(ay)); ctx.lineTo(TX(bx), TY(by)); ctx.stroke();
      ctx.strokeStyle = '#c4874a'; ctx.lineWidth = th * 0.8 * G.k;
      ctx.beginPath(); ctx.moveTo(TX(ax), TY(ay) - 1); ctx.lineTo(TX(bx), TY(by) - 1); ctx.stroke();
    }
    function arrow(x, y, ax, ay, s) {
      const l = Math.hypot(ax, ay), ux = ax / l, uy = ay / l, nx = -uy, ny = ux;
      ctx.beginPath();
      ctx.moveTo(TX(x - ux * s + nx * s * 0.7), TY(y - uy * s + ny * s * 0.7));
      ctx.lineTo(TX(x), TY(y));
      ctx.lineTo(TX(x - ux * s - nx * s * 0.7), TY(y - uy * s - ny * s * 0.7));
      ctx.stroke();
    }
    function drawHole(hi, t) {
      const h = HS[hi], k = G.k;
      // wood border + shadow
      ctx.save(); ctx.lineJoin = 'round';
      pathPoly(h.poly); ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.translate(3, 6); ctx.lineWidth = 22 * k; ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.stroke(); ctx.fill(); ctx.translate(-3, -6);
      pathPoly(h.poly); ctx.lineWidth = 22 * k; ctx.strokeStyle = '#7a4520'; ctx.stroke();
      ctx.lineWidth = 15 * k; ctx.strokeStyle = '#a8673a'; ctx.stroke();
      ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,220,170,.35)'; ctx.setLineDash([10, 14]); ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]);
      // carpet
      pathPoly(h.poly);
      const g = ctx.createLinearGradient(0, TY(0), 0, TY(CH));
      g.addColorStop(0, '#56c25a'); g.addColorStop(1, '#3a9e45');
      ctx.fillStyle = g; ctx.fill();
      ctx.save(); ctx.clip();
      if (feltPat) { ctx.fillStyle = feltPat; ctx.fillRect(TX(0), TY(0), CW * k, CH * k); }
      // mowing stripes
      ctx.fillStyle = 'rgba(255,255,255,.045)';
      for (let y = 0; y < CH; y += 80) ctx.fillRect(TX(0), TY(y), CW * k, 40 * k);
      // slope zones
      for (const q of h.slope) {
        ctx.fillStyle = 'rgba(20,60,20,.16)'; ctx.fillRect(TX(q[0]), TY(q[1]), (q[2] - q[0]) * k, (q[3] - q[1]) * k);
        ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        const off = ((t || 0) * 18) % 40;
        for (let y = q[1] + 22; y < q[3] - 8; y += 44) for (let x = q[0] + 22; x < q[2] - 8; x += 44) {
          const ux = q[4] / Math.hypot(q[4], q[5]), uy = q[5] / Math.hypot(q[4], q[5]);
          const ox = ((x - q[0] + off * ux) % (q[2] - q[0] - 8)) + q[0], oy = ((y - q[1] + off * uy) % (q[3] - q[1] - 8)) + q[1];
          arrow(ux ? ox : x, uy ? oy : y, q[4], q[5], 6);
        }
      }
      // sand
      for (const e of h.sand) {
        ctx.fillStyle = '#d9b874'; ctx.beginPath(); ctx.ellipse(TX(e[0]), TY(e[1]), e[2] * k + 3, e[3] * k + 3, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#ecd59a'; ctx.beginPath(); ctx.ellipse(TX(e[0]), TY(e[1]), e[2] * k, e[3] * k, 0, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(150,110,50,.35)';
        for (let i = 0; i < 26; i++) { const a = i * 2.39996, r = Math.sqrt(i / 26) * 0.85; ctx.fillRect(TX(e[0] + Math.cos(a) * e[2] * r), TY(e[1] + Math.sin(a) * e[3] * r), 1.4, 1.4); }
      }
      // water
      for (const q of h.water) {
        const wg = ctx.createLinearGradient(0, TY(q[1]), 0, TY(q[3]));
        wg.addColorStop(0, '#2f7fc1'); wg.addColorStop(1, '#1d5c9a');
        ctx.fillStyle = '#1b4f86'; ctx.fillRect(TX(q[0]) - 2, TY(q[1]) - 2, (q[2] - q[0]) * k + 4, (q[3] - q[1]) * k + 4);
        ctx.fillStyle = wg; ctx.fillRect(TX(q[0]), TY(q[1]), (q[2] - q[0]) * k, (q[3] - q[1]) * k);
        ctx.strokeStyle = 'rgba(255,255,255,.28)'; ctx.lineWidth = 1.5;
        for (let y = q[1] + 14; y < q[3] - 6; y += 22) {
          ctx.beginPath();
          for (let x = q[0] + 6; x < q[2] - 6; x += 4) { const yy = y + Math.sin(x * 0.12 + (t || 0) * 2 + y) * 2.5; x === q[0] + 6 ? ctx.moveTo(TX(x), TY(yy)) : ctx.lineTo(TX(x), TY(yy)); }
          ctx.stroke();
        }
      }
      if (h.bridge) {
        const b = h.bridge;
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fillRect(TX(b[0]) - 3, TY(b[1]) - 2, (b[2] - b[0]) * k + 6, (b[3] - b[1]) * k + 4);
        for (let y = b[1]; y < b[3]; y += 10) {
          ctx.fillStyle = ((y - b[1]) / 10) % 2 ? '#b07a45' : '#c18a52';
          ctx.fillRect(TX(b[0]) - 2, TY(y), (b[2] - b[0]) * k + 4, 10 * k - 1);
        }
        ctx.fillStyle = '#6a3c1a'; ctx.fillRect(TX(b[0]) - 3, TY(b[1]), 2.5, (b[3] - b[1]) * k); ctx.fillRect(TX(b[2]) + 0.5, TY(b[1]), 2.5, (b[3] - b[1]) * k);
      }
      ctx.restore();
      ctx.restore();
      // tee mat
      ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(TX(h.tee[0] - 18), TY(h.tee[1] - 12), 36 * k, 24 * k, 4) : ctx.rect(TX(h.tee[0] - 18), TY(h.tee[1] - 12), 36 * k, 24 * k); ctx.fill();
      // inner walls & posts
      h.walls.forEach((w) => drawWall(w[0], w[1], w[2], w[3], WT));
      h.posts.forEach((p) => {
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(TX(p[0]) + 2, TY(p[1]) + 3, p[2] * k, 0, 7); ctx.fill();
        ctx.fillStyle = '#8a5326'; ctx.beginPath(); ctx.arc(TX(p[0]), TY(p[1]), p[2] * k, 0, 7); ctx.fill();
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(TX(p[0]), TY(p[1]), p[2] * k * 0.55, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.arc(TX(p[0]) - p[2] * k * 0.2, TY(p[1]) - p[2] * k * 0.2, p[2] * k * 0.2, 0, 7); ctx.fill();
      });
      // cup
      const c = h.cup;
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.beginPath(); ctx.arc(TX(c[0]), TY(c[1]), (CR + 1.8) * k, 0, 7); ctx.fill();
      ctx.fillStyle = '#0d0a10'; ctx.beginPath(); ctx.arc(TX(c[0]), TY(c[1]), CR * k, 0, 7); ctx.fill();
    }
    function drawFlag(hi, col) {
      const c = HS[hi].cup, k = G.k, x = TX(c[0]) + 1, y = TY(c[1]);
      const hgt = 46 * k;
      ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 14 * k, y + 6 * k); ctx.stroke();
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, y - hgt); ctx.stroke();
      ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x, y - hgt); ctx.lineTo(x + 22 * k, y - hgt + 8 * k); ctx.lineTo(x, y - hgt + 16 * k); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawMill(hi, mc, ms) {
      const m = HS[hi].mill; if (!m) return;
      const k = G.k, l = m[2];
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 8 * k + 2;
      ctx.beginPath(); ctx.moveTo(TX(m[0] - mc * l) + 2, TY(m[1] - ms * l) + 4); ctx.lineTo(TX(m[0] + mc * l) + 2, TY(m[1] + ms * l) + 4); ctx.stroke();
      ctx.strokeStyle = '#d24b3c'; ctx.lineWidth = 8 * k;
      ctx.beginPath(); ctx.moveTo(TX(m[0] - mc * l), TY(m[1] - ms * l)); ctx.lineTo(TX(m[0] + mc * l), TY(m[1] + ms * l)); ctx.stroke();
      ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2.5 * k; ctx.setLineDash([5 * k, 6 * k]);
      ctx.beginPath(); ctx.moveTo(TX(m[0] - mc * l * 0.95), TY(m[1] - ms * l * 0.95)); ctx.lineTo(TX(m[0] + mc * l * 0.95), TY(m[1] + ms * l * 0.95)); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = '#6a3c1a'; ctx.beginPath(); ctx.arc(TX(m[0]), TY(m[1]), 9 * k, 0, 7); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(TX(m[0]), TY(m[1]), 4.5 * k, 0, 7); ctx.fill();
    }
    function drawBall(x, y, col, alpha, ring) {
      const k = G.k, r = BR * k;
      ctx.globalAlpha = alpha;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(TX(x) + r * 0.3, TY(y) + r * 0.45, r, r * 0.8, 0, 0, 7); ctx.fill();
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(TX(x), TY(y), r, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 1.5; ctx.stroke();
      const sh = ctx.createRadialGradient(TX(x) - r * 0.35, TY(y) - r * 0.4, 0, TX(x), TY(y), r);
      sh.addColorStop(0, 'rgba(255,255,255,.7)'); sh.addColorStop(0.4, 'rgba(255,255,255,0)'); sh.addColorStop(1, 'rgba(0,0,0,.25)');
      ctx.fillStyle = sh; ctx.beginPath(); ctx.arc(TX(x), TY(y), r, 0, 7); ctx.fill();
      if (ring) { ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.globalAlpha = alpha * 0.6; ctx.beginPath(); ctx.arc(TX(x), TY(y), r + 5 + ring, 0, 7); ctx.stroke(); }
      ctx.globalAlpha = 1;
    }
    const CANCEL = 22;
    /* distance from (x, y) (canvas px) along unit (ux, uy) to the edge of the phone screen — the finger can keep pulling
       over the HUD bars and the app header, but not past the glass */
    function screenRoom(x, y, ux, uy) {
      const r = cv.cv.getBoundingClientRect(), x0 = -r.left, y0 = -r.top, x1 = (window.innerWidth || cv.w) - r.left, y1 = (window.innerHeight || cv.h) - r.top;
      let t = 1e9;
      if (ux > 1e-6) t = Math.min(t, (x1 - x) / ux); else if (ux < -1e-6) t = Math.min(t, (x0 - x) / ux);
      if (uy > 1e-6) t = Math.min(t, (y1 - y) / uy); else if (uy < -1e-6) t = Math.min(t, (y0 - y) / uy);
      return Math.max(0, t);
    }
    function aimInfo() {
      if (!drag || !drag.vec) return null;
      const L2 = Math.hypot(drag.vec[0], drag.vec[1]);
      // full power needs ~h·0.22 of pull; when the screen edge comes sooner in this direction (ball near an edge),
      // the scale shrinks so 100% is reached just before the edge (never below 56px of travel)
      let maxPx = Math.min(170, Math.max(120, cv.h * 0.22));
      if (L2 > 1) maxPx = U.clamp(screenRoom(drag.ox, drag.oy, drag.vec[0] / L2, drag.vec[1] / L2) - CANCEL, 56, maxPx);
      if (L2 < CANCEL) return { cancel: true };
      return { ang: Math.atan2(-drag.vec[1], -drag.vec[0]), p: Math.round(Math.min(1, (L2 - CANCEL + 4) / maxPx) * 100) / 100, L2 };
    }
    /* straight guide to the first wall / post, plus the direction it bounces off (long guide mode) */
    function rayHit(hi, x, y, dx, dy) {
      const h = HS[hi];
      let best = 900, nx = 0, ny = 0;
      for (const sg of h.segs) {
        // ray vs segment, offset by the collision radius along the normal approximated by testing the centre line
        const ex = sg.dx, ey = sg.dy, den = dx * ey - dy * ex;
        if (Math.abs(den) < 1e-9) continue;
        const fx = sg.ax - x, fy = sg.ay - y;
        const t = (fx * ey - fy * ex) / den, u = (fx * dy - fy * dx) / den;
        if (t > 0 && u >= 0 && u <= 1) {
          const tt = t - sg.rr / Math.max(0.2, Math.abs((dx * ey - dy * ex) / Math.sqrt(sg.l2)));
          if (tt < best) { best = tt; const l = Math.sqrt(sg.l2); nx = -ey / l; ny = ex / l; if (nx * dx + ny * dy > 0) { nx = -nx; ny = -ny; } }
        }
      }
      for (const q of h.posts) {
        const fx = x - q[0], fy = y - q[1], rr = q[2] + BR, b = fx * dx + fy * dy, c = fx * fx + fy * fy - rr * rr, d = b * b - c;
        if (d >= 0) { const t = -b - Math.sqrt(d); if (t > 0 && t < best) { best = t; const cx = x + dx * t - q[0], cy = y + dy * t - q[1], l = Math.hypot(cx, cy) || 1; nx = cx / l; ny = cy / l; } }
      }
      return { t: Math.max(12, best), nx, ny };
    }
    function draw(now) {
      cv.clear();
      if (!st || !G) return;
      const hi = viewHole(), t = (now || 0) / 1000;
      drawHole(hi, t);
      const a = sim ? animLast.seat : actor(st);
      if (!G || G.hi !== hi) { layout(); }
      // windmill: during a replay the exact simulated pose; otherwise it idles (its pose when you putt is random)
      if (HS[hi].mill) {
        if (sim) drawMill(hi, sim.mc, sim.ms);
        else drawMill(hi, Math.cos(t * 1.5), Math.sin(t * 1.5));
      }
      drawFlag(hi, a != null && api.players[a] ? color(a) : '#e3ae45');
      { const c = HS[hi].cup; spCup(TX(c[0]) - 26, TY(c[1]) - 34, 52, 60); }
      if (!sim && st.ph === 'p' && a != null && st.p[a]) spBall(TX(st.p[a][0]) - 28, TY(st.p[a][1]) - 28, 56, 56); else spBall(null);
      // trail
      if (trail.length > 1 && animLast) {
        ctx.lineCap = 'round';
        for (let i = 1; i < trail.length; i++) {
          ctx.strokeStyle = color(animLast.seat); ctx.globalAlpha = (i / trail.length) * 0.45; ctx.lineWidth = BR * G.k * 1.1 * (i / trail.length);
          ctx.beginPath(); ctx.moveTo(TX(trail[i - 1][0]), TY(trail[i - 1][1])); ctx.lineTo(TX(trail[i][0]), TY(trail[i][1])); ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
      // balls
      const balls = [];
      if (sim) {
        if (others) others.forEach((p, i) => { if (p && i !== animLast.seat) balls.push([i, p[0], p[1]]); });
        if (sim.res !== 'cup') balls.push([animLast.seat, sim.x, sim.y]);
      } else if (st.ph === 'p') {
        for (let i = 0; i < st.n; i++) if (!st.d[i]) balls.push([i, st.p[i][0], st.p[i][1]]);
      }
      // current actor drawn last
      balls.sort((x, y) => (x[0] === a) - (y[0] === a));
      for (const b of balls) {
        const isA = b[0] === a;
        drawBall(b[1], b[2], color(b[0]), isA ? 1 : 0.85, isA && !sim && st.ph === 'p' ? 1.5 + Math.sin(t * 4) * 1.5 : 0);
      }
      // aim
      const ai2 = aimInfo();
      if (drag && st.ph === 'p' && a != null && !sim) {
        // cancel zone around the press point
        ctx.strokeStyle = ai2 && ai2.cancel ? 'rgba(238,106,85,.9)' : 'rgba(255,255,255,.25)'; ctx.lineWidth = 1.5; ctx.setLineDash([3, 4]);
        ctx.beginPath(); ctx.arc(drag.ox, drag.oy, CANCEL, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      }
      if (ai2 && !ai2.cancel && st.ph === 'p' && a != null) {
        const b = st.p[a], dx = Math.cos(ai2.ang), dy = Math.sin(ai2.ang);
        const rh = guideLong ? rayHit(hi, b[0], b[1], dx, dy) : null;
        const len = rh ? rh.t : 30 + ai2.p * 190;
        ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 2.2; ctx.setLineDash([2, 7]); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(TX(b[0] + dx * (BR + 4)), TY(b[1] + dy * (BR + 4))); ctx.lineTo(TX(b[0] + dx * len), TY(b[1] + dy * len)); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.beginPath(); ctx.arc(TX(b[0] + dx * len), TY(b[1] + dy * len), 3, 0, 7); ctx.fill();
        if (rh && len < 899 && (rh.nx || rh.ny)) { // first bounce: same rule as the sim (normal part × 0.78)
          const vn = dx * rh.nx + dy * rh.ny; let rx = dx - 1.78 * vn * rh.nx, ry = dy - 1.78 * vn * rh.ny; const rl = Math.hypot(rx, ry) || 1; rx /= rl; ry /= rl;
          const hx = b[0] + dx * len, hy = b[1] + dy * len, l2 = Math.min(110, rayHit(hi, hx + rx * 2, hy + ry * 2, rx, ry).t);
          ctx.strokeStyle = 'rgba(255,255,255,.45)'; ctx.lineWidth = 1.8; ctx.setLineDash([2, 7]);
          ctx.beginPath(); ctx.moveTo(TX(hx), TY(hy)); ctx.lineTo(TX(hx + rx * l2), TY(hy + ry * l2)); ctx.stroke(); ctx.setLineDash([]);
        }
        // pull band from ball to finger
        ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(TX(b[0]), TY(b[1])); ctx.lineTo(TX(b[0]) - dx * Math.min(80, 16 + ai2.p * 64), TY(b[1]) - dy * Math.min(80, 16 + ai2.p * 64)); ctx.stroke();
        // gauge ring around ball (+ this player's last putt marker)
        const r = BR * G.k + 13;
        ctx.lineWidth = 6; ctx.lineCap = 'butt';
        ctx.strokeStyle = 'rgba(23,19,31,.6)'; ctx.beginPath(); ctx.arc(TX(b[0]), TY(b[1]), r, -Math.PI / 2, Math.PI * 1.5); ctx.stroke();
        ctx.strokeStyle = ai2.p < 0.5 ? '#5fd3a0' : ai2.p < 0.8 ? '#e3ae45' : '#ee6a55';
        ctx.beginPath(); ctx.arc(TX(b[0]), TY(b[1]), r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * ai2.p); ctx.stroke();
        const lp = lastPw[a];
        if (lp) { const q = -Math.PI / 2 + Math.PI * 2 * lp; ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(TX(b[0]) + Math.cos(q) * (r - 6), TY(b[1]) + Math.sin(q) * (r - 6)); ctx.lineTo(TX(b[0]) + Math.cos(q) * (r + 6), TY(b[1]) + Math.sin(q) * (r + 6)); ctx.stroke(); }
        // big readout at the top of the course area (never under the finger)
        const bx = TX(HS[hi].cup[0]) < cv.w / 2 ? cv.w - 78 : 78, by = 84;
        ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx - 70, by - 20, 140, 40, 12) : ctx.rect(bx - 70, by - 20, 140, 40); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#f2e9d8'; ctx.font = '700 22px "IBM Plex Mono", monospace'; ctx.fillText(Math.round(ai2.p * 100) + '%', bx - (lp ? 18 : 0), by + 1);
        if (lp) { ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px "IBM Plex Mono", monospace'; ctx.fillText('전 ' + Math.round(lp * 100), bx + 40, by + 2); }
      } else if (ai2 && ai2.cancel && drag.started) {
        const bx = TX(HS[hi].cup[0]) < cv.w / 2 ? cv.w - 78 : 78, by = 84;
        ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx - 70, by - 20, 140, 40, 12) : ctx.rect(bx - 70, by - 20, 140, 40); ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1.2; ctx.stroke();
        ctx.fillStyle = '#ee6a55'; ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('놓으면 취소', bx, by + 1);
      }
      // sparkles
      sparks = sparks.filter((s) => s.t < 1);
      for (const s of sparks) {
        ctx.globalAlpha = 1 - s.t; ctx.fillStyle = s.c;
        const x = TX(s.x + s.vx * s.t * 40), y = TY(s.y + s.vy * s.t * 40 + s.t * s.t * 12), z = 3 * (1 - s.t) + 1;
        ctx.beginPath(); ctx.moveTo(x, y - z * 1.6); ctx.lineTo(x + z * 0.5, y); ctx.lineTo(x, y + z * 1.6); ctx.lineTo(x - z * 0.5, y); ctx.closePath(); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    /* ---- input: slingshot ---- */
    // sentAt: an online guest waits for the host's answer after a putt (prevents sending a second putt)
    function canHuman() { return st && !sim && st.ph === 'p' && actor(st) != null && api.canAct(actor(st)) && !(sentAt && performance.now() - sentAt < 5000); }
    cv.cv.addEventListener('pointerdown', (ev) => {
      if (!canHuman() || drag) return; // a second finger never restarts the pull
      const p = cv.local(ev), b = st.p[actor(st)];
      const bx = TX(b[0]), by = TY(b[1]);
      const near = Math.hypot(p.x - bx, p.y - by) < 60;
      drag = { id: ev.pointerId, ox: near ? bx : p.x, oy: near ? by : p.y, vec: [0, 0], started: false };
      lastTick = -1; wasCancel = true;
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      api.buzz(8);
      dirty = true;
    });
    cv.cv.addEventListener('pointermove', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const p = cv.local(ev);
      drag.vec = [p.x - drag.ox, p.y - drag.oy];
      if (Math.hypot(drag.vec[0], drag.vec[1]) > CANCEL) drag.started = true;
      const info = aimInfo();
      if (info) {
        if (info.cancel !== wasCancel && drag.started) { wasCancel = !!info.cancel; api.buzz(info.cancel ? 20 : 8); }
        const tk = info.cancel ? -1 : Math.floor(info.p * 10);
        if (tk !== lastTick && tk >= 0) api.sfx('tick');
        lastTick = tk;
      }
      dirty = true;
    });
    cv.cv.addEventListener('pointerup', (ev) => {
      if (!drag || drag.id !== ev.pointerId) return;
      const info = aimInfo(), drag0 = drag; drag = null; dirty = true;
      if (!canHuman() || !info) return;
      if (info.cancel) { if (drag0.started) { api.sfx('click'); api.toast('취소'); } return; }
      api.sfx('hit'); api.buzz(15);
      if (!api.isHost) sentAt = performance.now();
      api.act({ type: 'putt', a: info.ang, p: info.p });
    });
    cv.cv.addEventListener('pointercancel', (ev) => { if (drag && drag.id === ev.pointerId) { drag = null; dirty = true; } });

    /* 내 최고 기록: 이 기기의 사람 자리만, 코스·홀 수별로 파 대비 타수(낮을수록 좋음) */
    function saveBest(s) {
      const par = HS.reduce((a, h) => a + h.par, 0), gen = !!(s.cs && s.cs.g);
      for (let i = 0; i < s.n; i++) {
        const p = api.players[i];
        if (!p || p.ai || p.local === false || s.sc[i].length !== HS.length) continue;
        const v = total(s.sc[i]) - par;
        if (api.best((gen ? 'g' : 'c') + HS.length, v, { label: (gen ? '생성 ' : '기본 ') + HS.length + '홀 파 대비', lower: true, unit: '타' })) api.toast('🏆 새 최고 기록! 파 대비 ' + (v > 0 ? '+' : '') + v + '타');
      }
    }

    /* ---- animation ---- */
    function startAnim(last, next) {
      // other balls only move on their own putts, so their positions in the new state are the ones during this
      // shot (works even if an intermediate state was skipped online). Holed / capped balls are hidden.
      others = next.h === last.h ? next.p.map((p, i) => (next.d[i] && i !== last.seat ? 0 : p)) : null;
      clearTimeout(finTimer); clearTimeout(animTimer);
      sim = new Sim(HS[last.h], last.pre, last.shot);
      simAcc = 0; trail = [[sim.x, sim.y]]; animLast = last; lastBounce = 0;
      api.setBusy(true);
      if (cardEl) { cardEl.remove(); cardEl = null; cardKey = ''; }
      // rAF pauses in a background tab: make sure the replay (and the busy flag) still finishes
      const mine = sim, dur = new Sim(HS[last.h], last.pre, last.shot).run().n * DT;
      animTimer = setTimeout(() => { if (sim === mine && !sim.done) { sim.run(); finishAnim(); } }, (dur / L.debug.speed) * 1000 + 2500);
    }
    function finishAnim() {
      clearTimeout(animTimer);
      const l = animLast, s = sim;
      if (l.ev === 'cup') {
        for (let i = 0; i < 18; i++) { const a = i / 18 * Math.PI * 2; sparks.push({ x: s.x, y: s.y, vx: Math.cos(a) * (0.6 + (i % 3) * 0.3), vy: Math.sin(a) * (0.6 + (i % 3) * 0.3), t: 0, c: i % 2 ? '#e3ae45' : color(l.seat) }); }
      }
      announce(l);
      clearTimeout(finTimer);
      finTimer = setTimeout(() => {
        if (sim !== s) return; // a newer shot already took over
        sim = null; animLast = null; trail = []; others = null;
        api.setBusy(false);
        renderTop(); renderBot(); showCard(); dirty = true;
      }, (l.ev === 'cup' ? 650 : l.ev === 'water' || l.ev === 'wmax' ? 500 : 180) / L.debug.speed);
    }
    function announce(l) {
      const nm = api.players[l.seat].name, par = HS[l.h].par;
      if (l.ev === 'cup') {
        const d = l.k - par;
        const word = l.k === 1 ? '홀인원!' : d <= -3 ? '알바트로스!' : d === -2 ? '이글!' : d === -1 ? '버디!' : d === 0 ? '파' : d === 1 ? '보기' : d === 2 ? '더블 보기' : '+' + d;
        api.toast(nm + ' · ' + word); api.sfx(d <= 0 ? 'win' : 'pop');
        if (l.k === 1 || d <= -2) { setTimeout(() => api.sfx('pop'), 140); api.haptic('win', [35, 50, 35, 50, 80]); } else if (d < 0) api.haptic('hit', [25, 40, 30]);
        if (l.k === 1 || d <= -2) { const s = sim || { x: HS[l.h].cup[0], y: HS[l.h].cup[1] }; for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2 + 0.2; sparks.push({ x: s.x, y: s.y, vx: Math.cos(a) * 1.5, vy: Math.sin(a) * 1.5, t: 0, c: '#f2e9d8' }); } }
      } else if (l.ev === 'water') { api.toast('풍덩! 벌타 +1 · 제자리에서 다시'); api.sfx('lose'); }
      else if (l.ev === 'max' || l.ev === 'wmax') { api.toast(nm + ' · 7타로 마무리'); api.sfx('thud'); }
      else if (l.sand) api.sfx('thud');
    }
    let animT = 0;
    const stop = U.loop((dt, now) => {
      animT = now;
      if (sim && !sim.done) {
        // slow-mo as a hole-in-one / eagle ball rolls up to the cup (playback rate only)
        let slow = 1;
        if (animLast && animLast.ev === 'cup' && (animLast.k === 1 || animLast.k - HS[animLast.h].par <= -2)) {
          const cp = HS[animLast.h].cup; if (Math.hypot(sim.x - cp[0], sim.y - cp[1]) < 70) slow = 0.35;
        }
        simAcc += dt * L.debug.speed * slow;
        let n = 0;
        while (simAcc >= DT && !sim.done && n < 2000) {
          sim.step(); simAcc -= DT; n++;
          if (sim.n % 6 === 0) { trail.push([sim.x, sim.y]); if (trail.length > 40) trail.shift(); }
        }
        if (sim.bounce > lastBounce) { lastBounce = sim.bounce; api.sfx('bounce'); }
        if (sim.done) { trail.push([sim.x, sim.y]); finishAnim(); }
        dirty = true;
      }
      if (sparks.length) { sparks.forEach((s) => (s.t += dt * 1.6 * L.debug.speed)); dirty = true; }
      const hi = viewHole(), h = HS[hi];
      if (h.water.length || h.slope.length || drag || (st && st.ph === 'p' && !sim)) dirty = true;
      if (dirty) { dirty = false; draw(now); }
    });
    void millIdle; void animT;

    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down') return;
      const b = [...document.querySelectorAll('[data-action="' + id + '"]')].find((x) => !x.disabled && x.getClientRects().length);
      if (b) b.click();
    }) : null;
    const noFocus = (e) => { const b = e.target && e.target.closest && e.target.closest('button[data-action]'); if (b) e.preventDefault(); };   // 마우스로 누른 버튼에 포커스가 남아 Space/Enter 단축키를 가로채지 않게
    document.addEventListener('mousedown', noFocus, true);
    return {
      update(next, prev) {
        prevSt = prev; st = next;
        { const c = courseOf(next); if (c !== HS) { HS = c; layout(); } }
        if (next.ph === 'e' && !bestDone) { bestDone = true; saveBest(next); }
        if (prev !== next) sentAt = 0;
        const key = next.last ? next.last.id + ':' + next.last.shot.vx + ':' + next.last.shot.vy : '';
        // a shot from an earlier hole (guest that skipped states) is not replayed over the new hole
        const stale = next.last && next.ph === 'p' && next.last.h !== next.h;
        if (next.last && key !== shownSeq && prev && prev !== next && !stale) {
          shownSeq = key;
          lastPw[next.last.seat] = Math.min(1, Math.round(Math.hypot(next.last.shot.vx, next.last.shot.vy) / VMAX * 100) / 100);
          startAnim(next.last, next);
        } else {
          shownSeq = key;
          if (!sim) showCard();
        }
        renderTop(); renderBot(); dirty = true;
      },
      destroy() { if (offKeys) offKeys(); document.removeEventListener('mousedown', noFocus, true); stop(); clearTimeout(cardTimer); clearTimeout(finTimer); clearTimeout(animTimer); cv.destroy(); top.remove(); bot.remove(); spBall.el.remove(); spCup.el.remove(); if (cardEl) cardEl.remove(); api.setBusy(false); },
    };
  }

  L.register({
    id: 'golf', name: '미니 골프', tag: '퍼팅',
    blurb: '판마다 새로 만들어지는 코스(6·9·18홀) 미니 골프. 공을 뒤로 끌었다 놓아 퍼팅하고, 컵에서 먼 사람부터 칩니다. 물에 빠지면 벌타 1타. 모든 홀 합계 타수가 가장 적으면 승리.',
    options: [
      { id: 'course', label: '코스', tip: '홀 모양.', choices: [{ v: 'gen', label: '무작위 생성', tip: '판마다 새로 만든 홀.' }, { v: 'classic', label: '기본 6홀', tip: '정해진 기본 6홀.' }], def: 'gen' },
      { id: 'holes', label: '홀 수', choices: [{ v: 6, label: '6홀' }, { v: 9, label: '9홀' }, { v: 18, label: '18홀' }], def: 9 },
    ],
    controls: [
      { id: 'next', label: '다음 홀', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'guide', label: '조준선 길이', keys: ['KeyG'], pad: ['y'] },
    ],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 650,
    quick: [
      '모든 홀에서 공을 컵에 넣는 데 쓴 타수(친 횟수)를 모두 더해, 가장 적은 사람이 이겨요.',
      '내 차례: 화면을 누르고 치고 싶은 쪽의 반대로 끌었다 놓아요(새총처럼). 많이 끌수록 세게 쳐요.',
      '컵에서 가장 먼 공부터 쳐요. 물에 빠지면 벌타 1타, 한 홀은 최대 7타예요.',
    ],
    rules: [
      { h: '목표', p: ['1–4명이 하는 미니 골프예요. 코스는 기본이 「무작위 생성」이라 판마다 새 홀이 나와요(6·9·18홀 중 고르기). 「기본 6홀」(파 합계 18)도 고를 수 있어요.',
        '「타수」는 공을 친 횟수예요. 모든 홀 타수를 모두 더해 가장 적은 사람이 이기고, 같으면 공동 우승이에요.',
        '「파」는 그 홀의 기준 타수예요. 위쪽 이름표의 (E)는 파와 같음, (-1)은 파보다 1타 적음, (+2)는 2타 많음이에요.'] },
      { h: '차례에 할 일', p: ['① 매 홀 모두 티(출발점)에서 시작해요.',
        '② 컵에서 가장 먼 공을 가진 사람이 쳐요. 거리가 같으면 지난 홀을 적은 타수로 끝낸 사람이 먼저예요(첫 홀은 자리 순서).',
        '③ 한 번 치고, 다시 가장 먼 사람이 쳐요. 컵에 넣은 사람은 그 홀이 끝나요.',
        '④ 모두 홀아웃하면 스코어카드가 떠요. 그 홀을 가장 적은 타수로 끝낸 사람이 「다음 홀」을 눌러요.',
        '공끼리는 부딪히지 않아요.'] },
      { h: '조작 (손가락)', p: ['① 화면을 누르세요. 공 가까이를 누르면 공을 직접 잡아당기는 것 같고, 빈 곳을 눌러도 돼요(누른 곳을 기준으로 끈 만큼 쳐요).',
        '② 치고 싶은 방향의 반대쪽으로 끄세요. 새총과 같아요: 아래로 끌면 위로 굴러가요.',
        '③ 많이 끌수록 세게 쳐요. 화면 위쪽에 세기가 %로 크게 보여요. 공 둘레 게이지의 흰 눈금은 내 지난 퍼팅 세기예요.',
        '④ 손가락을 떼면 쳐요. 누른 자리의 점선 원 안으로 되돌아와 떼면 취소예요(「놓으면 취소」).',
        '공이 화면 가장자리에 붙어 있어도 괜찮아요: 화면 끝까지 끌면 100%가 되도록 세기 눈금이 저절로 맞춰져요. 넉넉하게 끌고 싶으면 공에서 먼 빈 곳을 눌러 끌어요.',
        '아래 「조준선」 버튼: 짧게(세기만큼) 또는 길게(첫 벽까지 + 튕겨 나갈 방향을 흐리게).',
        '화면은 지금 홀에 맞춰 자동으로 확대돼요. 아래 막대에 홀 번호, 파, 지금 몇 타째인지 나와요.'] },
      { h: '벌타와 제한', p: ['물에 빠지면 벌타 1타가 붙어 그 샷까지 2타가 되고, 쳤던 자리에서 다시 쳐요.',
        '한 홀은 최대 7타예요. 7타째에도 컵에 못 넣으면 그 홀은 7타로 끝나요.'] },
      { h: '코스', p: ['무작위 생성: 짧은 홀(곧은 길·굽은 길·잘록 허리)부터 긴 홀(말굽·세~다섯 굽이·뱀길)까지, 모양에 벽, 기둥, 모래, 물(다리), 경사, 풍차가 섞여 나와요. 만들 때마다 컴퓨터가 직접 쳐 보고 보통 실력으로 넣을 수 있는 홀만 남겨요. 파(2–5)도 그 결과로 정해져서, 보통 실력이면 파 언저리가 나와요.', '홀 수는 6·9·18홀. 18홀이면 스코어카드는 앞 9홀/뒤 9홀로 나눠 보여요.', '내 최고 기록(파 대비 타수)이 코스 종류·홀 수별로 이 기기에 남아요(사람 자리만).', '기본 6홀 —', '1번 첫 퍼팅(파 2): 나무 벽과 기둥.', '2번 모래 굽이(파 3): ㄱ자 코스와 벙커. 모래에서는 공이 금방 멈춰요.', '3번 외나무다리(파 3): 물 사이의 좁은 다리를 건너요.', '4번 기울어진 언덕(파 3): 화살표 방향으로 공이 흐르는 경사, 오른쪽에 물.', '5번 풍차(파 3): 가운데에서 계속 도는 날개. 칠 때마다 날개가 어느 위치에서 출발할지는 무작위예요.', '6번 지그재그(파 4): 벽 사이를 지그재그로, 모래와 경사도 있어요.'] },
      { h: '예시', p: ['파 3 홀에서 2번 만에 넣으면 2타 → 파보다 1타 적어요(-1).',
        '3번 홀 첫 샷이 물에 빠짐 → 1타 + 벌타 1 = 2타. 같은 자리에서 3타째를 쳐서 다리를 건너고, 4타째에 넣으면 그 홀은 4타예요.',
        '마지막 홀이 끝나고 나 20타, 친구 22타 → 타수가 적은 내가 우승!'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(퍼팅 정확도와 길 읽기 실력이 달라요).'] },
    ],
    tutorial: [
      { sel: '.gf-ball', text: '이게 내 공이에요. 모든 홀에서 공을 컵에 넣는 데 친 횟수(타수)가 가장 적으면 이겨요.' },
      { sel: '.gf-cup', text: '깃발이 꽂힌 곳이 컵이에요. 여기에 공을 넣으면 이 홀은 끝!' },
      { sel: '.gf-ball', text: '치기: 화면을 누르고 가고 싶은 쪽의 반대로 끌었다 떼세요(새총처럼). 아래로 끌면 위로 굴러가요. 많이 끌수록 세요.' },
      { sel: '.gf-ball', text: '공에서 먼 빈 곳을 눌러 끌어도 돼요. 누른 자리로 되돌아와 떼면 취소예요. 물에 빠지면 벌타 1타!' },
      { sel: '.gf-bar', text: '아래 막대에 홀 번호 · 파(기준 타수) · 지금 몇 타째인지 나와요. 「조준선」 버튼으로 조준선을 길게 볼 수도 있어요.' },
    ],
    init, actor, apply, ai, result, mount,
    _sim: { setShapes(a) { SHAPE_W = a; }, setPar(a, b) { PA = a; PB = b; }, Sim, simulate, HOLES, genHole, solve, makeCourse, courseOf },
  });
})();
