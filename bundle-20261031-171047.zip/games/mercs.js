/* 용병단 오토배틀러 — 상점에서 용병을 사서 배치하면 전투는 자동. 마지막까지 살아남는 용병단이 승리. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ───────── 데이터 ───────── */
  const ORG = [
    { n: '북방 전사단', c: '#8fb4d8', th: [2, 4], d: ['(2) 전사단 체력 +250', '(4) 전사단 체력 +550, 아군 전체 체력 +150'] },
    { n: '사막 상회', c: '#e0b25a', th: [2, 4], d: ['(2) 전투가 끝날 때마다 금화 +1', '(4) 금화 +3, 상회 공격력 +8%'] },
    { n: '망령 군단', c: '#9fd3a4', th: [2, 4], d: ['(2) 망령 흡혈 35%, 체력 +100', '(4) 망령 흡혈 55%, 체력 +250, 아군 전체 흡혈 15%'] },
    { n: '기계 길드', c: '#c9a07a', th: [2, 4], d: ['(2) 길드 방어·마법 저항 +40, 체력 +100', '(4) 길드 방어·마법 저항 +80, 체력 +250'] },
    { n: '심연 교단', c: '#b38ae0', th: [2, 4], d: ['(2) 아군 전체 시작 마나 +15', '(4) 시작 마나 +15, 교단 주문력 +40%'] },
    { n: '야수 부족', c: '#d8806a', th: [2, 4], d: ['(2) 부족 공격 속도 +25%', '(4) 부족 공격 속도 +50%'] },
    { n: '역병 의회', c: '#a9bf5c', th: [2, 4], d: ['(2) 의회 용병의 공격마다 대상 최대 체력 3% 마법 피해', '(4) 의회 4.5%, 적 전체가 받는 회복·흡혈 -40%'] },
  ];
  const CLS = [
    { n: '방패병', ab: '철벽', ad: '자신에게 보호막을 두르고 근처 아군에게도 절반을 나눠 줘요.', th: [2, 4], d: ['(2) 방패병 방어 +25', '(4) 방패병 방어 +60, 아군 전체 방어 +15'],
      hp: 780, atk: 48, as: 0.6, rng: 1, ar: 40, mr: 30, mm: 80, pw: 230, mv: 0.5, g: 'M12 2.5 L19.5 5.5 V11 C19.5 15.8 16.3 19.6 12 21.5 C7.7 19.6 4.5 15.8 4.5 11 V5.5 Z M12 6 V18 M8 10 H16' },
    { n: '궁수', ab: '연사', ad: '가까운 적 셋에게 화살을 한 번에 날려요.', th: [2, 4], d: ['(2) 궁수 공격 속도 +15%', '(4) 궁수 공격 속도 +35%'],
      hp: 460, atk: 52, as: 0.68, rng: 4, ar: 20, mr: 20, mm: 70, pw: 110, mv: 0.5, g: 'M7 3 C15 6.5 15 17.5 7 21 M7 3 V21 M4 12 H19 M16 9 L19.5 12 L16 15' },
    { n: '마법사', ab: '화염 폭발', ad: '대상과 그 둘레 한 칸의 적 모두에게 마법 피해.', th: [2, 4], d: ['(2) 마법사 주문력 +50%', '(4) 마법사 주문력 +110%'],
      hp: 510, atk: 42, as: 0.65, rng: 3, ar: 20, mr: 25, mm: 55, pw: 190, mv: 0.5, g: 'M6 21 L14.5 9.5 M17 3 L18.3 6.2 L21.5 7.5 L18.3 8.8 L17 12 L15.7 8.8 L12.5 7.5 L15.7 6.2 Z' },
    { n: '암살자', ab: '급소 찌르기', ad: '전투 시작 때 적 뒷줄로 뛰어들고, 체력 절반 아래인 적에게 두 배 피해.', th: [2, 4], d: ['(2) 암살자 치명 확률 20%', '(4) 암살자 치명 35%, 치명 피해 2배'],
      hp: 520, atk: 60, as: 0.78, rng: 1, ar: 20, mr: 20, mm: 60, pw: 230, mv: 0.4, g: 'M12 2 L14.5 14 H9.5 Z M6.5 14 H17.5 M12 14 V21.5' },
    { n: '사제', ab: '치유의 기도', ad: '체력 비율이 가장 낮은 아군을 크게 치유해요.', th: [2, 4], d: ['(2) 아군 전체 초당 체력 회복 30', '(4) 초당 회복 70'],
      hp: 560, atk: 40, as: 0.65, rng: 3, ar: 25, mr: 30, mm: 60, pw: 300, mv: 0.5, g: 'M6 3 H18 C18 9.5 15.3 12 12 12 C8.7 12 6 9.5 6 3 Z M12 12 V19 M8 21 H16' },
    { n: '기수', ab: '돌격', ad: '대상을 들이받아 피해를 주고 1.5초 기절시켜요.', th: [2, 4], d: ['(2) 기수 체력 +220, 공격력 +20', '(4) 기수 체력 +480, 공격력 +45'],
      hp: 690, atk: 58, as: 0.7, rng: 1, ar: 30, mr: 20, mm: 80, pw: 160, mv: 0.3, g: 'M3.5 20.5 L16 8 M13.5 3.5 H20.5 V10.5 Z M6 13.5 L10.5 18' },
    { n: '저주술사', ab: '쇠약의 저주', ad: '대상과 그 둘레 한 칸의 적에게 마법 피해를 주고 방어·마법 저항을 25씩 깎아요(전투 끝까지).', th: [2, 4], d: ['(2) 전투 시작 때 적 전체 방어·마법 저항 -15', '(4) 적 전체 방어·마법 저항 -40, 저주술사 주문력 +40%'],
      hp: 580, atk: 44, as: 0.65, rng: 2, ar: 20, mr: 30, mm: 65, pw: 165, mv: 0.5, g: 'M3 12 C7 6.5 17 6.5 21 12 C17 17.5 7 17.5 3 12 Z M12 9.5 A2.5 2.5 0 1 0 12.01 9.5 M12 2.5 V5.5 M12 18.5 V21.5' },
  ];
  const MCL = { n: '괴물', g: 'M4 5 L8.5 15 L12 7 L15.5 15 L20 5 M7 19 H17' };
  // 용병 40종: 앞 30종은 출신 o(0~5), k(0~4) → 직업 (o+k)%6, 가격 k+1. 뒤 10종(역병 의회·저주술사 추가)은 아래 NEWU에 직접.
  const UN = [
    '서리방패', '얼음뼈 사수', '눈보라 술사', '백야의 칼', '서리 대사제',
    '모래바람 궁수', '신기루 술사', '전갈 독침', '오아시스 사제', '황금 낙타기수',
    '무덤 점술사', '그림자 송곳', '썩은 성가자', '백골 기사', '망자의 성벽',
    '톱날 쥐', '수리 자동인형', '증기 돌격차', '강철 수문장', '천둥 포수',
    '심연 복사', '악몽 기수', '촉수 수호자', '공허 사냥꾼', '심연의 눈',
    '늑대 기수', '곰가죽 수호자', '매눈 사냥꾼', '피뿔 주술사', '검은 표범',
  ];
  const UNITS = UN.map((n, i) => { const o = Math.floor(i / 5), k = i % 5; return { n, o, c: (o + k) % 6, cost: k + 1 }; });
  const NEWU = [ // [이름, 출신, 직업, 가격]
    ['부리가면 의원', 6, 4, 1], ['곡하는 망령', 2, 6, 1], ['고름 투척병', 6, 1, 2], ['서리 저주꾼', 0, 6, 2], ['역병 전령', 6, 6, 3],
    ['독 거래상', 1, 3, 3], ['썩은 거인', 6, 0, 4], ['침묵의 사도', 4, 6, 4], ['창백한 역병군주', 6, 6, 5], ['파쇄 공성기', 3, 2, 5],
  ];
  NEWU.forEach(([n, o, c, cost]) => UNITS.push({ n, o, c, cost }));
  const NU = UNITS.length; // 40 — 괴물 종류 번호는 NU부터
  // 괴물 6종 (중립 라운드)
  const MON = [
    { n: '시궁쥐 떼', hp: 300, atk: 28, as: 0.8, rng: 1, ar: 5, mr: 5 },
    { n: '굶주린 늑대', hp: 520, atk: 45, as: 0.9, rng: 1, ar: 15, mr: 10 },
    { n: '무덤 구울', hp: 850, atk: 70, as: 0.75, rng: 1, ar: 30, mr: 20 },
    { n: '바위 골렘', hp: 2000, atk: 95, as: 0.5, rng: 1, ar: 80, mr: 40 },
    { n: '늪 히드라', hp: 3200, atk: 150, as: 0.8, rng: 2, ar: 60, mr: 60 },
    { n: '잿빛 비룡', hp: 5200, atk: 230, as: 0.7, rng: 2, ar: 80, mr: 80 },
  ];
  const TCH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrst'; // 0~39 용병, 40~45 괴물
  const CELLC = 'abcdefghijklmnopqrstuvwxyzAB';        // 판 28칸 (7열 × 4줄, 0줄 = 앞줄)
  const COLS = 7, ROWS = 4;
  const POOL = [0, 18, 15, 12, 9, 6];
  const ODDS = [null, [100, 0, 0, 0, 0], [100, 0, 0, 0, 0], [75, 25, 0, 0, 0], [55, 30, 15, 0, 0], [45, 33, 20, 2, 0],
    [25, 40, 30, 5, 0], [19, 30, 35, 15, 1], [16, 20, 35, 25, 4], [9, 15, 30, 30, 16]];
  const XPN = [0, 2, 2, 6, 10, 20, 36, 56, 80, 0]; // 레벨 l → l+1에 필요한 경험치
  const SM = [0, 1, 1.8, 3.24];

  // 아이템: 부품 6 + 완성 21
  const COMP = [
    { n: '녹슨 대검', a: '검', d: '공격력 +18' },
    { n: '사냥꾼 깃', a: '깃', d: '공격 속도 +15%' },
    { n: '사슬 갑옷', a: '갑', d: '방어 +25' },
    { n: '그림자 망토', a: '망', d: '마법 저항 +25' },
    { n: '뼈 지팡이', a: '장', d: '주문력 +20%' },
    { n: '거인의 허리띠', a: '띠', d: '체력 +200' },
  ];
  const SP = {
    crit: '치명 확률 +25% (치명 피해 1.8배)', frenzy: '공격할 때마다 공격 속도 +6% (최대 +60%)', thorn: '받은 근접 피해의 30%를 되돌려 줌',
    ls: '흡혈 25%', burn: '공격마다 대상 최대 체력 3% 마법 피해', sunder: '공격마다 대상 방어 -4 (쌓임)', splash: '공격이 옆 칸 적에게 40% 튐',
    shield: '전투 시작 때 보호막 350', stun: '공격의 20% 확률로 1초 기절', regen: '초당 최대 체력 2% 회복', rev: '한 번 쓰러지면 체력 40%로 일어남', mana: '시작 마나 +40, 주문력 +15%',
  };
  const FULL = [
    [0, 0, '처형인의 대검', 'crit'], [0, 1, '광전사 도끼', 'frenzy'], [0, 2, '가시 철퇴', 'thorn'], [0, 3, '그림자 낫', 'ls'], [0, 4, '룬 새김 검', 'burn'], [0, 5, '거인 학살자', 'sunder'],
    [1, 1, '질풍의 활', 'frenzy'], [1, 2, '파쇄 석궁', 'sunder'], [1, 3, '독사의 송곳', 'burn'], [1, 4, '번개 부적', 'splash'], [1, 5, '사냥꾼의 맹세', 'ls'],
    [2, 2, '강철 성채', 'thorn'], [2, 3, '맹세자의 갑주', 'shield'], [2, 4, '서리 왕관', 'stun'], [2, 5, '수호자의 맹세', 'regen'],
    [3, 3, '망령 수의', 'rev'], [3, 4, '금지된 서책', 'mana'], [3, 5, '저주받은 허리띠', 'shield'],
    [4, 4, '심연의 홀', 'mana'], [4, 5, '피의 성배', 'ls'], [5, 5, '거인의 심장', 'regen'],
  ];
  const FCH = 'abcdefghijklmnopqrstu';

  // 강화(판 안에서만): 3·10·17라운드 뒤에 셋 중 하나. r = 등급(1 은빛 · 2 금빛 · 3 무지개), 같은 고르기에서는 모두 같은 등급.
  const AUG = [
    { n: '두둑한 금고', r: 1, k: '경제', d: '이자 상한 +2 (최대 7◉)', ic: 2 },
    { n: '전리품 자루', r: 1, k: '경제', d: '바로 금화 +8', g: 8 },
    { n: '훈련 교본', r: 1, k: '경제', d: '바로 경험치 +8', xp: 8 },
    { n: '상회 계약서', r: 2, k: '경제', d: '바로 금화 +15', g: 15 },
    { n: '정기 배당', r: 2, k: '경제', d: '라운드마다 금화 +1', inc: 1 },
    { n: '사관학교', r: 2, k: '경제', d: '라운드마다 경험치 +2 더', xr: 2 },
    { n: '연전의 기세', r: 2, k: '경제', d: '연승·연패 보너스가 있으면 +1 더', sb: 1 },
    { n: '왕실 후원', r: 3, k: '경제', d: '바로 금화 +22, 이자 상한 +2', g: 22, ic: 2 },
    { n: '황금 손', r: 3, k: '경제', d: '바로 금화 +6, 라운드마다 금화 +2', g: 6, inc: 2 },
    { n: '방패벽', r: 1, k: '전투', d: '맨 앞줄 용병 방어·마법 저항 +25', fr: 25 },
    { n: '전쟁 북', r: 1, k: '전투', d: '아군 전체 공격 속도 +10%', as: 0.1 },
    { n: '심연의 속삭임', r: 1, k: '전투', d: '아군 전체 시작 마나 +25', mn: 25 },
    { n: '철의 전열', r: 2, k: '전투', d: '맨 앞줄 용병 방어·마법 저항 +50, 체력 +150', fr: 50, frh: 150 },
    { n: '피의 맹약', r: 2, k: '전투', d: '아군 전체 흡혈 12%', ls: 0.12 },
    { n: '거인의 피', r: 2, k: '전투', d: '아군 전체 체력 +180', hp: 180 },
    { n: '전장의 군주', r: 3, k: '전투', d: '아군 전체 체력 +250, 공격력 +20%', hp: 250, atk: 0.2 },
    { n: '대장장이 상자', r: 1, k: '아이템', d: '무작위 부품 2개', it: 2 },
    { n: '보물 창고', r: 2, k: '아이템', d: '무작위 부품 4개', it: 4 },
    { n: '장인의 손길', r: 2, k: '아이템', d: '무작위 완성 아이템 1개 + 부품 1개', fi: 1, it: 1 },
    { n: '전설의 무기고', r: 3, k: '아이템', d: '무작위 완성 아이템 2개', fi: 2 },
    { n: '신병 모집', r: 1, k: '용병', d: '무작위 2◉ 용병 2명', un: [2, 2] },
    { n: '정예 계약', r: 2, k: '용병', d: '무작위 4◉ 용병 1명 + 3◉ 용병 1명', un: [4, 3] },
    { n: '쌍둥이 계약', r: 2, k: '용병', d: '무작위 3◉ 용병 ★2 한 명', u2: 3 },
    { n: '전설의 계약', r: 3, k: '용병', d: '무작위 5◉ 용병 1명 + 4◉ 용병 1명', un: [5, 4] },
  ];
  ORG.forEach((O, k) => AUG.push({ n: O.n.split(' ')[0] + ' 문장', r: 1, k: '특성', d: O.n + ' 수 +1 (판에 1명 이상 있을 때)', to: k }));
  CLS.forEach((C, k) => AUG.push({ n: C.n + ' 문장', r: 2, k: '특성', d: C.n + ' 수 +1 (판에 1명 이상 있을 때)', tc: k }));
  const ACH = TCH; // 강화 번호 → 글자
  const AG_AT = { 4: 0, 11: 1, 18: 2 }; // 이 라운드가 시작될 때(=3·10·17라운드 뒤) 고르기
  const AG_TIER = [[50, 40, 10], [30, 50, 20], [20, 50, 30]];
  const augs = (g) => (g || '').split('').map((c) => AUG[ACH.indexOf(c)]).filter(Boolean);
  function augEff(g) {
    const e = { ic: 0, inc: 0, xr: 0, sb: 0, fr: 0, frh: 0, as: 0, mn: 0, ls: 0, hp: 0, atk: 0 };
    augs(g).forEach((A) => { for (const k in e) if (A[k]) e[k] += A[k]; });
    return e;
  }
  function combine(a, b) { const x = Math.min(a, b), y = Math.max(a, b); return FULL.findIndex((f) => f[0] === x && f[1] === y); }
  function itemName(ch) { if (ch >= '0' && ch <= '5') return COMP[+ch].n; const k = FCH.indexOf(ch); return k >= 0 ? FULL[k][2] : ''; }
  function itemDesc(ch) {
    if (ch >= '0' && ch <= '5') return COMP[+ch].d + ' · 부품 두 개를 합치면 완성 아이템';
    const f = FULL[FCH.indexOf(ch)]; return COMP[f[0]].d + ', ' + COMP[f[1]].d + ' · ' + SP[f[3]];
  }
  function itemAbbr(ch) { if (ch >= '0' && ch <= '5') return COMP[+ch].a; const f = FULL[FCH.indexOf(ch)]; return f ? f[2][0] : '?'; }

  /* ───────── 작은 도구 ───────── */
  function rng(seed) { let a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const rnd = (n) => Math.floor(Math.random() * n);
  // 유닛 토큰: 종류 문자 + 별(1~3) + 아이템 문자('-' 없음)
  function parseBoard(str) { const m = {}; for (let i = 0; i + 3 < str.length; i += 4) m[CELLC.indexOf(str[i])] = { t: TCH.indexOf(str[i + 1]), st: +str[i + 2], it: str[i + 3] }; return m; }
  function packBoard(m) { let s = ''; for (let c = 0; c < 28; c++) if (m[c]) s += CELLC[c] + TCH[m[c].t] + m[c].st + m[c].it; return s; }
  function parseBench(str) { const a = []; for (let i = 0; i < 8; i++) { const t = str.substr(i * 3, 3); a.push(t[0] === '.' || !t ? null : { t: TCH.indexOf(t[0]), st: +t[1], it: t[2] }); } return a; }
  function packBench(a) { return a.map((u) => (u ? TCH[u.t] + u.st + u.it : '...')).join(''); }
  function boardCount(p) { return p.b.length / 4; }
  function unitVal(u) { return UNITS[u.t].cost * Math.pow(3, u.st - 1); }
  function sellVal(u) { const c = UNITS[u.t].cost; return u.st === 1 ? c : c * Math.pow(3, u.st - 1) - (c > 1 ? 1 : 0); }

  function traitCounts(board, g) { // board map → [org6, cls6] (같은 종류는 한 번만 셈), g = 강화(문장 +1)
    const seen = {}, o = ORG.map(() => 0), c = CLS.map(() => 0);
    for (const k in board) { const u = board[k]; if (u.t >= NU || seen[u.t]) continue; seen[u.t] = 1; o[UNITS[u.t].o]++; c[UNITS[u.t].c]++; }
    augs(g).forEach((A) => { if (A.to != null && o[A.to]) o[A.to]++; if (A.tc != null && c[A.tc]) c[A.tc]++; });
    return { o, c };
  }
  function tier(cnt, th) { return cnt >= th[1] ? 2 : cnt >= th[0] ? 1 : 0; }

  /* ───────── 전투 시뮬 (결정적: 시드 rng만 씀) ───────── */
  const DT = 0.1, MAXT = 300;
  function mkUnit(u, cell, side, tr, idx, E) {
    const r = Math.floor(cell / COLS), cc = cell % COLS;
    const x = side === 0 ? cc : COLS - 1 - cc, y = side === 0 ? 4 + r : 3 - r;
    const U0 = { side, idx, t: u.t, st: u.st, it: u.it, x, y, ox: x, oy: y, crit: 0, cx: 1.5, ls: 0, hr: 1, regen: 0, sh: 0, mana: 0, ap: 1, stun: 0, cd: 0.3, mvc: 0, tg: -1, alive: true, fr: 0, frm: 0, burn: 0, sun: 0, spl: 0, thorn: 0, stc: 0, rev: 0, armd: 0 };
    if (u.t >= NU) {
      const M = MON[u.t - NU], sc = u.st;
      Object.assign(U0, { cls: -1, org: -1, mhp: M.hp * sc, atk: M.atk * sc, as: M.as, rng: M.rng, ar: M.ar, mr: M.mr, mm: 9999, pw: 0, mv: 0.55 });
    } else {
      const D = UNITS[u.t], C = CLS[D.c], cm = 1 + 0.24 * (D.cost - 1), sm = SM[u.st];
      Object.assign(U0, { cls: D.c, org: D.o, cost: D.cost, mhp: C.hp * cm * sm, atk: C.atk * cm * sm, as: C.as, rng: C.rng, ar: C.ar, mr: C.mr, mm: C.mm, pw: C.pw * cm * sm, mv: C.mv });
      const it = u.it, add = (k) => { if (k === 0) U0.atk += 18; else if (k === 1) U0.as *= 1.15; else if (k === 2) U0.ar += 25; else if (k === 3) U0.mr += 25; else if (k === 4) U0.ap += 0.2; else if (k === 5) U0.mhp += 200; };
      if (it >= '0' && it <= '5') add(+it);
      else if (FCH.indexOf(it) >= 0) {
        const f = FULL[FCH.indexOf(it)]; add(f[0]); add(f[1]);
        const s = f[3];
        if (s === 'crit') { U0.crit += 0.25; U0.cx = Math.max(U0.cx, 1.8); } else if (s === 'frenzy') U0.frm = 0.6; else if (s === 'thorn') U0.thorn = 0.3;
        else if (s === 'ls') U0.ls += 0.25; else if (s === 'burn') U0.burn = 0.03; else if (s === 'sunder') U0.sun = 4; else if (s === 'splash') U0.spl = 0.4;
        else if (s === 'shield') U0.sh += 350; else if (s === 'stun') U0.stc = 0.2; else if (s === 'regen') U0.regen += 0.02 * U0.mhp; else if (s === 'rev') U0.rev = 1;
        else if (s === 'mana') { U0.mana += 40; U0.ap += 0.15; }
      }
      // 시너지
      const o = tr.o, c = tr.c, to = (k) => tier(o[k], ORG[k].th), tc = (k) => tier(c[k], CLS[k].th);
      if (to(0) && D.o === 0) U0.mhp += to(0) === 2 ? 550 : 250; if (to(0) === 2) U0.mhp += 150;
      if (to(1) === 2 && D.o === 1) U0.atk *= 1.08;
      if (to(2) && D.o === 2) { U0.ls += to(2) === 2 ? 0.55 : 0.35; U0.mhp += to(2) === 2 ? 250 : 100; } if (to(2) === 2) U0.ls += 0.15;
      if (to(3) && D.o === 3) { const v = to(3) === 2 ? 80 : 40; U0.ar += v; U0.mr += v; U0.mhp += to(3) === 2 ? 250 : 100; }
      if (to(4)) U0.mana += 15; if (to(4) === 2 && D.o === 4) U0.ap += 0.4;
      if (to(5) && D.o === 5) U0.as *= to(5) === 2 ? 1.5 : 1.25;
      if (tc(0) && D.c === 0) U0.ar += tc(0) === 2 ? 60 : 25; if (tc(0) === 2) U0.ar += 15;
      if (tc(1) && D.c === 1) U0.as *= tc(1) === 2 ? 1.35 : 1.15;
      if (tc(2) && D.c === 2) U0.ap += tc(2) === 2 ? 1.1 : 0.5;
      if (tc(3) && D.c === 3) { U0.crit += tc(3) === 2 ? 0.35 : 0.2; if (tc(3) === 2) U0.cx = Math.max(U0.cx, 2); }
      if (tc(4)) U0.regen += tc(4) === 2 ? 70 : 30;
      if (tc(5) && D.c === 5) { U0.mhp += tc(5) === 2 ? 480 : 220; U0.atk += tc(5) === 2 ? 45 : 20; }
      if (to(6) && D.o === 6) U0.burn += to(6) === 2 ? 0.045 : 0.03;
      if (tc(6) === 2 && D.c === 6) U0.ap += 0.4;
      if (E) { // 강화
        U0.mhp += E.hp; U0.atk *= 1 + E.atk; U0.as *= 1 + E.as; U0.ls += E.ls; U0.mana += E.mn;
        if (r === 0) { U0.ar += E.fr; U0.mr += E.fr; U0.mhp += E.frh; }
      }
    }
    U0.hp = U0.mhp; U0.mana = Math.min(U0.mana, U0.mm - 1);
    return U0;
  }
  // A, B: 판 문자열 (B가 괴물 판일 수도). 반환 {w: 0 A승 / 1 B승 / 2 무승부, sv: 이긴 쪽 남은 별 합, fr?: 기록}
  function fight(bA, bB, seed, rec, gA, gB) {
    const R = rng(seed);
    const mA = parseBoard(bA), mB = parseBoard(bB), tA = traitCounts(mA, gA), tB = traitCounts(mB, gB), eA = augEff(gA), eB = augEff(gB);
    const us = [];
    for (const k in mA) us.push(mkUnit(mA[k], +k, 0, tA, us.length, eA));
    for (const k in mB) us.push(mkUnit(mB[k], +k, 1, tB, us.length, eB));
    // 상대 쪽에 거는 시너지: 저주술사(방어·마저 깎기), 역병 의회 4(회복 줄이기)
    [tA, tB].forEach((T, sd) => {
      const hx = tier(T.c[6], CLS[6].th), pl = tier(T.o[6], ORG[6].th);
      if (!hx && pl < 2) return;
      us.forEach((v) => { if (v.side === sd) return; if (hx) { const d = hx === 2 ? 40 : 15; v.ar = Math.max(0, v.ar - d); v.mr = Math.max(0, v.mr - d); } if (pl === 2) v.hr = 0.6; });
    });
    const occ = {}; const key = (x, y) => x + y * 8;
    us.forEach((u) => { occ[key(u.x, u.y)] = u; });
    const frames = rec ? [] : null, events = rec ? [] : null;
    let t = 0, w = 2;
    let ev = null;
    const dist = (a, b) => Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
    const free = (x, y) => x >= 0 && x < COLS && y >= 0 && y < 8 && !occ[key(x, y)];
    function setPos(u, x, y) { delete occ[key(u.x, u.y)]; u.x = x; u.y = y; occ[key(x, y)] = u; }
    function snap() { frames.push(us.map((u) => [u.x, u.y, Math.max(0, Math.round(u.hp)), Math.round(u.sh), u.alive ? 1 : 0, Math.round(u.mana * 100 / u.mm)])); }
    function kill(u) {
      if (u.rev) { u.rev = 0; u.hp = u.mhp * 0.4; if (ev) ev.push(['rev', u.idx]); return; }
      u.alive = false; u.hp = 0; delete occ[key(u.x, u.y)]; if (ev) ev.push(['die', u.idx]);
    }
    function dmg(src, tgt, amt, magic, tag) {
      if (!tgt.alive) return 0;
      const res = magic ? tgt.mr : Math.max(0, tgt.ar - tgt.armd);
      let d = amt * 100 / (100 + res) * (t > 180 ? 1 + (t - 180) * 0.04 : 1); // 18초가 넘으면 점점 격해짐
      const raw = d;
      if (tgt.sh > 0) { const s = Math.min(tgt.sh, d); tgt.sh -= s; d -= s; }
      tgt.hp -= d;
      tgt.mana = Math.min(tgt.mm, tgt.mana + Math.min(8, raw / 25));
      if (src && src.alive && src.ls && !magic) src.hp = Math.min(src.mhp, src.hp + raw * src.ls * src.hr);
      if (ev && tag) ev.push(['d', tgt.idx, Math.round(raw), tag]);
      if (tgt.hp <= 0) kill(tgt);
      return raw;
    }
    function nearestEnemy(u) {
      let best = null, bd = 99;
      for (const v of us) if (v.alive && v.side !== u.side) { const d = dist(u, v) + (v.idx * 0.001); if (d < bd) { bd = d; best = v; } }
      return best;
    }
    // 암살자: 적 뒷줄로 도약
    us.forEach((u) => {
      if (u.cls !== 3) return;
      const enemies = us.filter((v) => v.side !== u.side);
      if (!enemies.length) return;
      const back = u.side === 0 ? Math.min(...enemies.map((v) => v.y)) : Math.max(...enemies.map((v) => v.y));
      const tg = enemies.filter((v) => v.y === back).sort((a, b) => Math.abs(a.x - u.x) - Math.abs(b.x - u.x))[0];
      const yy = tg.y + (u.side === 0 ? -1 : 1);
      const cand = [[tg.x, yy], [tg.x - 1, yy], [tg.x + 1, yy], [tg.x - 1, tg.y], [tg.x + 1, tg.y], [tg.x - 2, yy], [tg.x + 2, yy]];
      for (const [x, y] of cand) if (free(x, y)) { setPos(u, x, y); u.tg = tg.idx; break; }
    });
    if (rec) snap();
    for (; t < MAXT; t++) {
      ev = rec ? [] : null;
      for (const u of us) {
        if (!u.alive) continue;
        if (u.regen) u.hp = Math.min(u.mhp, u.hp + u.regen * DT * u.hr);
        if (u.stun > 0) { u.stun -= DT; continue; }
        let tg = u.tg >= 0 ? us[u.tg] : null;
        if (!tg || !tg.alive) { tg = nearestEnemy(u); u.tg = tg ? tg.idx : -1; }
        if (!tg) break;
        const d = dist(u, tg);
        if (d <= u.rng) {
          u.cd -= DT;
          if (u.cd <= 0) {
            u.cd += 1 / (u.as * (1 + u.fr));
            if (u.frm) u.fr = Math.min(u.frm, u.fr + 0.06);
            if (u.mana >= u.mm) { cast(u, tg); u.mana = 0; continue; }
            let a = u.atk, tag = u.rng > 1 ? 'ar' : 'm';
            if (u.crit && R() < u.crit) { a *= u.cx; tag = 'c'; }
            const raw = dmg(u, tg, a, false, tag);
            if (u.thorn === 0 && tg.thorn && u.rng <= 1 && tg.alive) dmg(tg, u, raw * tg.thorn, true, null);
            if (u.burn) dmg(u, tg, tg.mhp * u.burn, true, null);
            if (u.sun) tg.armd = Math.min(tg.ar, tg.armd + u.sun);
            if (u.stc && R() < u.stc) tg.stun = Math.max(tg.stun, 1);
            if (u.spl) for (const v of us) if (v.alive && v.side !== u.side && v !== tg && dist(v, tg) <= 1) dmg(u, v, u.atk * u.spl, false, null);
            u.mana = Math.min(u.mm, u.mana + 10);
          }
        } else {
          u.mvc -= DT;
          if (u.mvc <= 0) {
            u.mvc = u.mv;
            let bx = -1, by = -1, bdd = d;
            for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
              if (!dx && !dy) continue; const nx = u.x + dx, ny = u.y + dy;
              if (!free(nx, ny)) continue;
              const nd = Math.max(Math.abs(nx - tg.x), Math.abs(ny - tg.y)) + (Math.abs(nx - tg.x) + Math.abs(ny - tg.y)) * 0.01;
              if (nd < bdd) { bdd = nd; bx = nx; by = ny; }
            }
            if (bx >= 0) setPos(u, bx, by); else { const alt = nearestEnemy(u); if (alt && alt !== tg && R() < 0.5) u.tg = alt.idx; }
          }
        }
      }
      function cast(u, tg) {
        const p = u.pw * u.ap;
        if (ev) ev.push(['cast', u.idx, tg.idx]);
        if (u.cls === 0) { u.sh += p; for (const v of us) if (v.alive && v.side === u.side && v !== u && dist(u, v) <= 1) v.sh += p * 0.5; }
        else if (u.cls === 1) { const es = us.filter((v) => v.alive && v.side !== u.side).sort((a, b) => dist(u, a) - dist(u, b) || a.idx - b.idx).slice(0, 3); es.forEach((v) => dmg(u, v, p * 0.85 + u.atk * 0.3, false, 'ab')); }
        else if (u.cls === 2) { for (const v of us) if (v.alive && v.side !== u.side && dist(v, tg) <= 1) dmg(u, v, p, true, 'ab'); }
        else if (u.cls === 3) dmg(u, tg, (p + u.atk) * (tg.hp < tg.mhp / 2 ? 2 : 1), false, 'ab');
        else if (u.cls === 4) { let lo = null; for (const v of us) if (v.alive && v.side === u.side && (!lo || v.hp / v.mhp < lo.hp / lo.mhp)) lo = v; if (lo) { lo.hp = Math.min(lo.mhp, lo.hp + p * lo.hr); if (ev) ev.push(['heal', lo.idx, Math.round(p)]); } }
        else if (u.cls === 5) { dmg(u, tg, p + u.atk * 0.5, false, 'ab'); if (tg.alive) tg.stun = Math.max(tg.stun, 1.5); }
        else if (u.cls === 6) { for (const v of us) if (v.alive && v.side !== u.side && dist(v, tg) <= 1) { dmg(u, v, p * 0.85, true, 'ab'); v.armd = Math.min(v.ar, v.armd + 25); v.mr = Math.max(0, v.mr - 25); } }
      }
      if (rec) { snap(); events.push(ev); }
      const aA = us.some((u) => u.alive && u.side === 0), aB = us.some((u) => u.alive && u.side === 1);
      if (!aA || !aB) { w = aA ? 0 : aB ? 1 : 2; break; }
    }
    let sv = 0;
    if (w < 2) us.forEach((u) => { if (u.alive && u.side === w) sv += u.t >= NU ? 1 : u.st; });
    const out = { w, sv, t: Math.min(t + 1, MAXT) };
    if (rec) { out.fr = frames; out.ev = events; out.us = us.map((u) => ({ side: u.side, t: u.t, st: u.st, it: u.it, mhp: u.mhp, cls: u.cls, org: u.org })); }
    return out;
  }

  /* ───────── 라운드 구성 ───────── */
  function isPve(rd) { return rd <= 2 || (rd >= 8 && (rd - 8) % 6 === 0); }
  function monsterBoard(rd) {
    // 앞줄 가운데부터 채움 (괴물 판은 상대 쪽이라 거울로 그려짐)
    const M0 = NU, L0 = rd <= 1 ? [[M0, 1], [M0, 1]] : rd === 2 ? [[M0 + 1, 1], [M0, 1], [M0, 1]] : null;
    let list = L0;
    if (!list) {
      const k = Math.floor((rd - 8) / 6); // 0,1,2,3…
      const kinds = [[[2, 1], [2, 1], [1, 1], [1, 1]], [[3, 1], [2, 1], [2, 1], [1, 1], [1, 1]], [[4, 1], [3, 1], [2, 1], [2, 1]], [[5, 1], [4, 1], [3, 1]]];
      list = kinds[Math.min(k, 3)].map(([t, s]) => [M0 + t, s * (k > 3 ? 1 + (k - 3) * 0.6 : 1)]);
    }
    const cells = [3, 2, 4, 1, 5, 10, 9, 11];
    let s = '';
    list.forEach(([t, sc], i) => { s += CELLC[cells[i]] + TCH[t] + Math.min(9, Math.round(sc)) + '-'; });
    return s;
  }
  function baseDmg(rd) { return rd < 6 ? 2 : Math.min(15, 3 + Math.floor((rd - 6) / 3)); }

  /* ───────── 상태 ───────── */
  function poolLeft(s) {
    const used = new Array(NU).fill(0);
    s.p.forEach((p) => {
      if (p.h <= 0) return;
      const m = parseBoard(p.b); for (const k in m) used[m[k].t] += Math.pow(3, m[k].st - 1);
      parseBench(p.n).forEach((u) => { if (u) used[u.t] += Math.pow(3, u.st - 1); });
      for (const ch of p.s) if (ch !== '.') used[TCH.indexOf(ch)]++;
    });
    return UNITS.map((u, i) => Math.max(0, POOL[u.cost] - used[i]));
  }
  function rollShop(s, i) {
    const p = s.p[i]; p.s = '.....';
    const left = poolLeft(s);
    let out = '';
    for (let k = 0; k < 5; k++) {
      const od = ODDS[p.l]; let r = rnd(100), cost = 1;
      for (let c = 0; c < 5; c++) { if (r < od[c]) { cost = c + 1; break; } r -= od[c]; }
      let cands = UNITS.map((u, j) => (u.cost === cost ? j : -1)).filter((j) => j >= 0 && left[j] > 0);
      if (!cands.length) cands = UNITS.map((u, j) => j).filter((j) => left[j] > 0);
      if (!cands.length) { out += '.'; continue; }
      const tot = cands.reduce((a, j) => a + left[j], 0); let q = rnd(tot), pick = cands[0];
      for (const j of cands) { if (q < left[j]) { pick = j; break; } q -= left[j]; }
      left[pick]--; out += TCH[pick];
    }
    p.s = out;
  }
  function init(players, opts) {
    const s = { rd: 1, p: players.map((pl) => ({ h: 100, g: 4, l: 2, x: 0, w: 0, b: '', n: '.'.repeat(24), s: '.....', i: '', k: 0, r: 0, pl: 0, a: '', o: '', m: 0 })), seq: 0, last: null, over: 0, nm: players.map((pl, i) => String(pl.name || ('용병단 ' + (i + 1))).slice(0, 8)), win: -1, opp: players.map(() => -1), gs: -1, ga: -1 };
    s.p.forEach((p, i) => rollShop(s, i));
    return s;
  }
  /* 강화 */
  function offerAugs(s) {
    const tw = AG_TIER[AG_AT[s.rd]]; let r = rnd(100), tr = 1;
    for (let q = 0; q < 3; q++) { if (r < tw[q]) { tr = q + 1; break; } r -= tw[q]; }
    alive(s).forEach((i) => {
      const p = s.p[i];
      const c = AUG.map((A, j) => (A.r === tr && p.a.indexOf(ACH[j]) < 0 ? j : -1)).filter((j) => j >= 0);
      U.shuffle(c); p.o = c.slice(0, 3).map((j) => ACH[j]).join('');
    });
  }
  function grantUnit(s, p, cost, st) {
    const left = poolLeft(s), need = st === 2 ? 3 : 1;
    let c = UNITS.map((u, j) => (u.cost === cost && left[j] >= need ? j : -1)).filter((j) => j >= 0);
    if (!c.length) c = UNITS.map((u, j) => (u.cost === cost ? j : -1)).filter((j) => j >= 0);
    const t = c[rnd(c.length)], bench = parseBench(p.n), e = bench.findIndex((u) => !u);
    if (e < 0) { p.g += cost * need; return; }
    bench[e] = { t, st, it: '-' }; p.n = packBench(bench); tryMerge(p);
  }
  function takeAug(s, i, k) {
    const p = s.p[i], ch = p.o[k]; if (!ch) throw new Error('aug');
    const A = AUG[ACH.indexOf(ch)];
    p.a += ch; p.o = '';
    if (A.g) p.g += A.g;
    if (A.xp) addXp(p, A.xp);
    for (let q = 0; q < (A.fi || 0); q++) p.i += FCH[rnd(21)];
    for (let q = 0; q < (A.it || 0); q++) p.i += String(rnd(6));
    if (p.i.length > 8) p.i = p.i.slice(0, 8);
    (A.un || []).forEach((c) => grantUnit(s, p, c, 1));
    if (A.u2) grantUnit(s, p, A.u2, 2);
  }
  // AI: 지금 가진 용병 구성에 맞는 강화를 고름
  function aiAug(s, i, lv) {
    const p = s.p[i]; if (lv === 1) return rnd(p.o.length);
    const m = {}; let n = 0; const b = parseBoard(p.b); for (const k in b) m[n++] = b[k]; parseBench(p.n).forEach((u) => { if (u) m[n++] = u; });
    const tr = traitCounts(m), late = s.rd >= 15;
    let bi = 0, bv = -1e9;
    p.o.split('').forEach((ch, k) => {
      const A = AUG[ACH.indexOf(ch)]; let v = 3;
      if (A.to != null || A.tc != null) { const c = A.to != null ? tr.o[A.to] : tr.c[A.tc]; v = c === 0 ? 0 : (c === 1 || c === 3) ? 8 : c === 2 ? 4 : 2; }
      else if (A.k === '경제') v = late ? 2 : (A.ic || A.inc || A.xr ? 6 : 5);
      else if (A.k === '전투') v = late ? 7 : 5;
      else if (A.k === '아이템') v = 5 + (A.fi || 0);
      else if (A.k === '용병') v = late ? 6 : 4;
      if (lv === 2) v += rnd(3);
      if (v > bv) { bv = v; bi = k; }
    });
    return bi;
  }
  function alive(s) { return s.p.map((p, i) => (p.h > 0 ? i : -1)).filter((i) => i >= 0); }
  function actor(s) { if (s.over) return null; const a = alive(s).filter((i) => !s.p[i].r); return a.length ? a : null; }

  // 3개 → ★ 합치기 (판 우선)
  function tryMerge(p, out) {
    let again = true;
    while (again) {
      again = false;
      const board = parseBoard(p.b), bench = parseBench(p.n);
      const locs = [];
      for (const k in board) locs.push({ w: 'b', k: +k, u: board[k] });
      bench.forEach((u, k) => { if (u) locs.push({ w: 'n', k, u }); });
      const grp = {};
      locs.forEach((L0) => { if (L0.u.st < 3) { const id = L0.u.t * 4 + L0.u.st; (grp[id] = grp[id] || []).push(L0); } });
      for (const id in grp) {
        const g = grp[id]; if (g.length < 3) continue;
        const three = g.slice(0, 3), keep = three[0];
        const items = three.map((x) => x.u.it).filter((c) => c !== '-');
        const nu = { t: keep.u.t, st: keep.u.st + 1, it: items.length ? items.shift() : '-' };
        three.forEach((x) => { if (x.w === 'b') delete board[x.k]; else bench[x.k] = null; });
        if (keep.w === 'b') board[keep.k] = nu; else bench[keep.k] = nu;
        items.forEach((c) => { if (p.i.length < 8) p.i += c; });
        p.b = packBoard(board); p.n = packBench(bench);
        if (out) out.push(nu);
        again = true; break;
      }
    }
  }
  function getLoc(p, loc) { if (loc[0] === 'b') return parseBoard(p.b)[+loc.slice(1)] || null; return parseBench(p.n)[+loc.slice(1)] || null; }
  function setLoc(p, loc, u) {
    if (loc[0] === 'b') { const m = parseBoard(p.b), c = +loc.slice(1); if (u) m[c] = u; else delete m[c]; p.b = packBoard(m); }
    else { const a = parseBench(p.n); a[+loc.slice(1)] = u; p.n = packBench(a); }
  }
  function validLoc(loc) { if (typeof loc !== 'string') return false; const k = +loc.slice(1); return (loc[0] === 'b' && k >= 0 && k < 28) || (loc[0] === 'n' && k >= 0 && k < 8); }

  function doBuy(s, i, k) {
    const p = s.p[i], ch = p.s[k];
    if (ch == null || ch === '.') throw new Error('empty');
    const t = TCH.indexOf(ch), cost = UNITS[t].cost;
    if (p.g < cost) throw new Error('gold');
    const bench = parseBench(p.n); let slot = bench.findIndex((u) => !u);
    if (slot < 0) {
      // 자리 없어도 바로 ★2가 되면 살 수 있음
      const board = parseBoard(p.b); let have = 0;
      for (const q in board) if (board[q].t === t && board[q].st === 1) have++;
      bench.forEach((u) => { if (u && u.t === t && u.st === 1) have++; });
      if (have < 2) throw new Error('bench full');
      p.g -= cost; p.s = p.s.slice(0, k) + '.' + p.s.slice(k + 1);
      const locs = [];
      for (const q in board) if (board[q].t === t && board[q].st === 1) locs.push({ w: 'b', k: +q, u: board[q] });
      bench.forEach((u, q) => { if (u && u.t === t && u.st === 1) locs.push({ w: 'n', k: q, u }); });
      const keepL = locs[0], gone = locs[1];
      const its = [keepL.u.it, gone.u.it].filter((c) => c !== '-');
      const nu = { t, st: 2, it: its.length ? its.shift() : '-' };
      its.forEach((c) => { if (p.i.length < 8) p.i += c; });
      if (gone.w === 'b') delete board[gone.k]; else bench[gone.k] = null;
      if (keepL.w === 'b') board[keepL.k] = nu; else bench[keepL.k] = nu;
      p.b = packBoard(board); p.n = packBench(bench);
      const got = [nu]; tryMerge(p, got); return got;
    }
    p.g -= cost; p.s = p.s.slice(0, k) + '.' + p.s.slice(k + 1);
    bench[slot] = { t, st: 1, it: '-' }; p.n = packBench(bench);
    const got = []; tryMerge(p, got); return got;
  }
  function apply(s, seat, a) {
    if (s.over) throw new Error('over');
    const p = s.p[seat];
    if (!p || p.h <= 0 || p.r) throw new Error('not active');
    if (!a || typeof a !== 'object') throw new Error('bad');
    if (p.o && a.t !== 'aug' && a.t !== 'auto') throw new Error('pick augment first');
    switch (a.t) {
      case 'aug': { if (!p.o) throw new Error('no offer'); const k = a.k | 0; if (k < 0 || k >= p.o.length) throw new Error('k'); takeAug(s, seat, k); s.seq++; s.ev = { id: s.seq, s: seat, k: 'aug', u: p.a.slice(-1) }; return s; }
      case 'buy': { const k = a.k | 0; if (k < 0 || k > 4) throw new Error('k'); const got = doBuy(s, seat, k); s.seq++; s.ev = { id: s.seq, s: seat, k: got.length ? 'merge' : 'buy', u: got.length ? TCH[got[got.length - 1].t] + got[got.length - 1].st : '' }; break; }
      case 'mv': {
        if (!validLoc(a.f) || !validLoc(a.to) || a.f === a.to) throw new Error('loc');
        const u = getLoc(p, a.f); if (!u) throw new Error('nothing');
        const v = getLoc(p, a.to);
        if (a.to[0] === 'b' && a.f[0] === 'n' && !v && boardCount(p) >= p.l) throw new Error('cap');
        setLoc(p, a.f, null); setLoc(p, a.to, u); if (v) setLoc(p, a.f, v);
        break;
      }
      case 'sell': {
        if (!validLoc(a.f)) throw new Error('loc');
        const u = getLoc(p, a.f); if (!u) throw new Error('nothing');
        p.g += sellVal(u); if (u.it !== '-') { if (p.i.length < 8) p.i += u.it; }
        setLoc(p, a.f, null); break;
      }
      case 'item': {
        const k = a.k | 0; const ch = p.i[k]; if (!ch) throw new Error('item');
        if (!validLoc(a.to)) throw new Error('loc');
        const u = getLoc(p, a.to); if (!u) throw new Error('nobody');
        if (u.it === '-') u.it = ch;
        else if (u.it >= '0' && u.it <= '5' && ch >= '0' && ch <= '5') u.it = FCH[combine(+u.it, +ch)];
        else throw new Error('slot full');
        p.i = p.i.slice(0, k) + p.i.slice(k + 1); setLoc(p, a.to, u); break;
      }
      case 'mix': { // 보관함 부품 둘 합치기
        const x = a.a | 0, y = a.b | 0; const cx = p.i[x], cy = p.i[y];
        if (x === y || !(cx >= '0' && cx <= '5') || !(cy >= '0' && cy <= '5')) throw new Error('mix');
        const f = FCH[combine(+cx, +cy)]; const arr = p.i.split(''); arr[x] = f; arr.splice(y, 1); p.i = arr.join(''); break;
      }
      case 'roll': if (p.g < 2) throw new Error('gold'); p.g -= 2; rollShop(s, seat); break;
      case 'xp': if (p.g < 4 || p.l >= 9) throw new Error('xp'); p.g -= 4; addXp(p, 4); break;
      case 'lock': p.k = p.k ? 0 : 1; break;
      case 'ready': p.r = 1; break;
      case 'auto': if (p.o) takeAug(s, seat, aiAug(s, seat, Math.max(1, Math.min(3, a.lv | 0 || 2)))); aiTurn(s, seat, Math.max(1, Math.min(3, a.lv | 0 || 2))); p.r = 1; break;
      default: throw new Error('bad action');
    }
    if (alive(s).every((i) => s.p[i].r)) resolveRound(s);
    return s;
  }
  function addXp(p, n) { p.x += n; while (p.l < 9 && p.x >= XPN[p.l]) { p.x -= XPN[p.l]; p.l++; } if (p.l >= 9) p.x = 0; }
  // 판이 비었으면 대기석에서 자동으로 채움(레벨만큼), 넘치면 대기석으로
  function autoFill(p) {
    const board = parseBoard(p.b), bench = parseBench(p.n);
    let cnt = Object.keys(board).length;
    while (cnt > p.l) { const k = Object.keys(board).map(Number).sort((a, b) => b - a)[0]; const e = bench.findIndex((u) => !u); if (e >= 0) bench[e] = board[k]; else p.g += sellVal(board[k]); delete board[k]; cnt--; }
    while (cnt < p.l) {
      const bi = bench.findIndex((u) => u); if (bi < 0) break;
      const u = bench[bi]; const front = UNITS[u.t] && [0, 3, 5].includes(UNITS[u.t].c);
      const order = front ? [3, 2, 4, 1, 5, 0, 6, 10, 9, 11] : [24, 23, 25, 22, 26, 17, 16, 18, 21, 27];
      let c = order.find((q) => !board[q]); if (c == null) c = [...Array(28).keys()].find((q) => !board[q]);
      board[c] = u; bench[bi] = null; cnt++;
    }
    p.b = packBoard(board); p.n = packBench(bench);
  }
  function resolveRound(s) {
    const al = alive(s), rd = s.rd, pv = isPve(rd);
    al.forEach((i) => autoFill(s.p[i]));
    const bd = s.p.map((p) => (p.h > 0 ? p.b : '')), ag = s.p.map((p) => (p.h > 0 ? p.a : ''));
    const sd = rnd(1e9);
    const pr = [];
    if (pv) al.forEach((a) => pr.push([a, -1, 0]));
    else {
      let best = null, bs = 1e9;
      for (let tr = 0; tr < 12; tr++) {
        const o = U.shuffle(al.slice()); let sc = 0;
        for (let q = 0; q + 1 < o.length; q += 2) if (s.opp[o[q]] === o[q + 1] || s.opp[o[q + 1]] === o[q]) sc++;
        if (o.length % 2 && o[o.length - 1] === s.ga) sc++; // 같은 용병단이 그림자와 두 번 연속 싸우지 않게
        if (sc < bs) { bs = sc; best = o; } if (!sc) break;
      }
      for (let q = 0; q + 1 < best.length; q += 2) pr.push([best[q], best[q + 1], 0]);
      if (best.length % 2) {
        // 그림자: 살아 있는 다른 용병단의 이번 판. 직전 그림자와 같은 곳은 피하고, 체력이 비슷할수록 잘 뽑혀요. 자기 그림자와는 안 싸워요.
        const a = best[best.length - 1]; let others = al.filter((x) => x !== a);
        if (others.length > 1) others = others.filter((x) => x !== s.gs);
        const wt = others.map((x) => 1 / (1 + Math.abs(s.p[x].h - s.p[a].h) / 10)), tot = wt.reduce((u, v) => u + v, 0);
        let q = Math.random() * tot, b = others[0];
        for (let k = 0; k < others.length; k++) { if (q < wt[k]) { b = others[k]; break; } q -= wt[k]; }
        pr.push([a, b, 1]); s.gs = b; s.ga = a;
      } else s.ga = -1;
    }
    const res = [];
    pr.forEach(([a, b, gh], q) => {
      const bB = b < 0 ? monsterBoard(rd) : bd[b];
      const f = fight(bd[a], bB, sd + q * 7919, false, ag[a], b < 0 ? '' : ag[b]);
      const dm = (f.w === 2 ? baseDmg(rd) : baseDmg(rd) + f.sv);
      const da = f.w === 0 ? 0 : (b < 0 || gh ? Math.max(1, Math.ceil(dm / 2)) : dm), db = (b >= 0 && !gh && f.w !== 1) ? dm : 0;
      res.push([f.w, da, db]);
      const A = s.p[a]; A.h -= da; streak(A, f.w === 0);
      if (b >= 0 && !gh) { const B = s.p[b]; B.h -= db; streak(B, f.w === 1); s.opp[a] = b; s.opp[b] = a; }
      if (f.w === 0) A.g += 1; if (b >= 0 && !gh && f.w === 1) s.p[b].g += 1;
      if (b < 0) { A.i = (A.i + String(rnd(6)) + (f.w === 0 && rd >= 8 ? String(rnd(6)) : '')).slice(0, 8); }
    });
    s.seq++;
    s.last = { id: s.seq, rd, pv: pv ? 1 : 0, pr, rs: res, bd, sd };
    if (ag.some(Boolean)) s.last.ag = ag;
    // 탈락
    const dead = al.filter((i) => s.p[i].h <= 0);
    const still = al.length - dead.length;
    dead.sort((x, y) => s.p[x].h - s.p[y].h).forEach((i, k) => { s.p[i].pl = still + dead.length - k; s.p[i].h = 0; });
    const nowAlive = alive(s);
    if (nowAlive.length <= 1 || s.rd >= 45) {
      s.over = 1;
      let w = nowAlive.length ? nowAlive.sort((x, y) => s.p[y].h - s.p[x].h)[0] : dead.sort((x, y) => s.p[x].pl - s.p[y].pl)[0];
      s.win = w; s.p[w].pl = 1;
      nowAlive.filter((i) => i !== w).sort((x, y) => s.p[y].h - s.p[x].h).forEach((i, k) => { s.p[i].pl = k + 2; });
      return;
    }
    s.rd++;
    nowAlive.forEach((i) => {
      const p = s.p[i];
      const tr = traitCounts(parseBoard(p.b), p.a);
      const desert = tier(tr.o[1], ORG[1].th);
      const E = augEff(p.a), sbn = strBonus(p.w);
      const inc = 5 + Math.min(5 + E.ic, Math.floor(p.g / 10)) + sbn + (sbn ? E.sb : 0) + E.inc + (desert === 2 ? 3 : desert ? 1 : 0);
      p.g += inc; addXp(p, 2 + E.xr);
      if (!p.k) rollShop(s, i); p.k = 0; p.r = 0;
    });
    if (AG_AT[s.rd] != null) offerAugs(s);
  }
  function streak(p, won) { if (won) p.w = p.w > 0 ? p.w + 1 : 1; else p.w = p.w < 0 ? p.w - 1 : -1; if (p.w > p.m) p.m = p.w; }
  function strBonus(w) { const a = Math.abs(w); return a >= 5 ? 3 : a >= 4 ? 2 : a >= 2 ? 1 : 0; }
  function result(s) {
    if (!s.over) return null;
    const order = s.p.map((p, i) => i).sort((a, b) => s.p[a].pl - s.p[b].pl);
    return { winners: [s.win], title: '최후의 용병단', text: order.slice(0, 4).map((i, k) => (k + 1) + '위 ' + (s.nm ? s.nm[i] : '#' + (i + 1))).join(' · ') + ' — ' + s.rd + '라운드까지 버텼어요.',
      stats: [{ label: '순위', values: s.p.map((p, i) => (i === s.win ? 1 : p.pl || '-') + '위') }, { label: '남은 체력', values: s.p.map((p) => String(Math.max(0, p.h))) }, { label: '레벨', values: s.p.map((p) => String(p.l)) }] };
  }

  /* ───────── AI ───────── */
  function unitScore(t, st, tr, lv, focus) {
    const D = UNITS[t];
    let v = D.cost * SM[st] * 2;
    if (lv >= 2) { v += (tr.o[D.o] >= 1 ? 1.5 : 0) + (tr.c[D.c] >= 1 ? 1.5 : 0); }
    if (lv >= 3 && focus) { if (focus.o === D.o) v += 3; if (focus.c === D.c) v += 3; }
    return v;
  }
  function aiTurn(s, i, lv0) {
    const p = s.p[i], lv = lv0 === 3 ? 2 : lv0;
    const owned = () => { const a = []; const b = parseBoard(p.b); for (const k in b) a.push(b[k]); parseBench(p.n).forEach((u) => u && a.push(u)); return a; };
    const allTr = () => { const m = {}; owned().forEach((u, k) => { m[k] = u; }); return traitCounts(m); };
    let focus = null;
    if (lv0 === 3 && s.rd >= 5) { // 어려움: 가장 많이 모인 출신·직업 하나씩을 목표로(동률이면 단계에 더 가까운 쪽)
      const tr = allTr(), best = (arr, TH) => { let bi = 0, bv = -1; arr.forEach((c, k) => { const v = c + (c === TH[k].th[1] - 1 ? 0.5 : 0) + k * 0.001; if (v > bv) { bv = v; bi = k; } }); return bi; };
      focus = { o: best(tr.o, ORG), c: best(tr.c, CLS) };
    }
    const cnt = (t) => owned().filter((u) => u.t === t).reduce((a, u) => a + Math.pow(3, u.st - 1), 0);
    // 경제: 레벨 올리기
    const wantL = lv === 1 ? 2 + Math.floor(s.rd / 4) : lv === 2 ? 3 + Math.floor(s.rd / 3.5) : (s.rd >= 18 ? 8 : s.rd >= 14 ? 7 : s.rd >= 10 ? 6 : s.rd >= 7 ? 5 : s.rd >= 4 ? 4 : 3);
    const keep = lv === 1 ? 0 : lv === 2 ? (s.rd > 4 ? 20 : 0) : (s.rd > 4 ? 20 : 0);
    let guard = 0;
    while (p.l < Math.min(9, wantL) && p.g >= 4 && (p.g - 4 >= Math.min(keep, 30) || lv === 1 || p.h < 40) && guard++ < 20) { p.g -= 4; addXp(p, 4); }
    // 사기 + 새로고침
    for (let pass = 0; pass < 6; pass++) {
      const tr = allTr();
      for (let k = 0; k < 5; k++) {
        const ch = p.s[k]; if (ch === '.') continue;
        const t = TCH.indexOf(ch), D = UNITS[t];
        if (p.g < D.cost) continue;
        const c = cnt(t);
        let want;
        if (lv === 1) want = Math.random() < 0.55;
        else { const sc = unitScore(t, 1, tr, lv0, focus) + (c >= 1 ? 4 : 0) + (c >= 2 ? 4 : 0); want = sc >= (lv === 3 ? 6 : 5) || c >= 1 || boardCount(p) + parseBench(p.n).filter(Boolean).length < p.l; }
        if (!want) continue;
        if (lv >= 2 && p.g - D.cost < keep && c < 1 && owned().length >= p.l) continue;
        if (!parseBench(p.n).some((u) => !u)) { if (!sellWorst(p, lv, focus, t)) continue; }
        try { doBuy(s, i, k); } catch (e) { /* 자리 없음 등 */ }
      }
      const rollOK = lv === 1 ? (p.g >= 6 && Math.random() < 0.25) : lv === 2 ? p.g >= keep + 4 && pass < 2 : ((p.g >= keep + 6 && pass < 3) || (p.h < 45 && p.g >= 2 && pass < 5));
      if (!rollOK || p.g < 2) break;
      p.g -= 2; rollShop(s, i);
    }
    if (lv === 3 && p.g >= 8) p.k = 0;
    // 배치
    if (lv0 === 3) {
      // 어려움: 배치 후보 몇 개를 다른 용병단 판과 미리 싸워 보고 가장 나은 것을 고름
      const foes = alive(s).filter((j) => j !== i && s.p[j].b).map((j) => [s.p[j].b, s.p[j].a]).slice(0, 3);
      if (isPve(s.rd + 0) || !foes.length) foes.push([monsterBoard(s.rd), '']);
      let best = null, bv = -1e9;
      for (let k = 0; k < 6; k++) {
        const q = JSON.parse(JSON.stringify(p)); arrange(q, k % 2 ? 2 : 3, focus, k < 2 ? 0 : k * 1.5);
        let v = 0; foes.forEach((fb, z) => { const f = fight(q.b, fb[0], 1000 + z * 31 + k, false, p.a, fb[1]); v += f.w === 0 ? 10 + f.sv : f.w === 2 ? 3 : -f.sv; });
        if (v > bv) { bv = v; best = q; }
      }
      p.b = best.b; p.n = best.n; p.g = best.g;
    } else arrange(p, lv, focus);
    // 아이템
    while (p.i.length) {
      const board = parseBoard(p.b), keys = Object.keys(board).map(Number);
      if (!keys.length) break;
      const ch = p.i[0];
      if (lv >= 2) { // 부품 둘이면 먼저 합침
        const comps = p.i.split('').map((c, k) => (c >= '0' && c <= '5' ? k : -1)).filter((k) => k >= 0);
        if (comps.length >= 2) { const f = FCH[combine(+p.i[comps[0]], +p.i[comps[1]])]; const arr = p.i.split(''); arr[comps[0]] = f; arr.splice(comps[1], 1); p.i = arr.join(''); continue; }
      }
      const isComp = ch >= '0' && ch <= '5';
      const cand = keys.filter((k) => board[k].it === '-' || (isComp && board[k].it >= '0' && board[k].it <= '5'));
      if (!cand.length) break;
      if (lv >= 2 && isComp && p.i.length === 1 && s.rd < 20 && !cand.some((k) => board[k].it >= '0' && board[k].it <= '5')) {
        // 부품 하나는 아껴 두되, 합칠 짝이 판에 있으면 줌
        break;
      }
      const k = lv === 1 ? cand[rnd(cand.length)] : cand.sort((a, b) => unitVal(board[b]) - unitVal(board[a]))[0];
      const u = board[k];
      u.it = u.it === '-' ? ch : FCH[combine(+u.it, +ch)];
      p.i = p.i.slice(1); p.b = packBoard(board);
    }
  }
  function sellWorst(p, lv, focus, exceptT) {
    const bench = parseBench(p.n), board = parseBoard(p.b), tr = traitCounts(board);
    let worst = -1, wv = 1e9;
    bench.forEach((u, k) => { if (!u || u.t === exceptT) return; const v = unitScore(u.t, u.st, tr, lv, focus); if (v < wv) { wv = v; worst = k; } });
    if (worst < 0 || wv > 7) return false;
    const u = bench[worst]; p.g += sellVal(u); if (u.it !== '-' && p.i.length < 8) p.i += u.it; bench[worst] = null; p.n = packBench(bench); return true;
  }
  function arrange(p, lv, focus, noise) {
    const board = parseBoard(p.b), bench = parseBench(p.n);
    const all = []; for (const k in board) all.push(board[k]); bench.forEach((u) => u && all.push(u));
    // 시너지를 보며 고르기 (보통·어려움), 쉬움은 비싼 순 + 약간 무작위
    let chosen = [];
    if (lv === 1) chosen = all.slice().sort((a, b) => unitVal(b) - unitVal(a) + (Math.random() - 0.5) * 4).slice(0, p.l);
    else {
      const pool = all.slice();
      while (chosen.length < p.l && pool.length) {
        const m = {}; chosen.forEach((u, k) => { m[k] = u; }); const tr = traitCounts(m, p.a);
        let bi = 0, bv = -1e9;
        pool.forEach((u, k) => {
          const D = UNITS[u.t]; const dup = chosen.some((c) => c.t === u.t);
          let v = unitVal(u) * 2 + (dup ? -3 : 0);
          const no = tr.o[D.o] + 1, nc = tr.c[D.c] + 1;
          if (!dup) { if (ORG[D.o].th.includes(no)) v += lv === 3 ? 5 : 3; if (CLS[D.c].th.includes(nc)) v += lv === 3 ? 5 : 3; if (focus && (focus.o === D.o || focus.c === D.c)) v += 2; }
          if (u.it !== '-') v += 2;
          if (noise) v += (Math.random() - 0.5) * noise;
          if (v > bv) { bv = v; bi = k; }
        });
        chosen.push(pool.splice(bi, 1)[0]);
      }
    }
    const nb = {}, rest = all.filter((u) => !chosen.includes(u));
    const front = [3, 2, 4, 1, 5, 0, 6], mid = [10, 9, 11, 8, 12, 7, 13], back = [24, 23, 25, 22, 26, 21, 27, 17, 16, 18, 15, 19];
    const take = (arr) => { const c = arr.find((q) => !nb[q]); return c != null ? c : [...Array(28).keys()].find((q) => !nb[q]); };
    chosen.sort((a, b) => unitVal(b) - unitVal(a)).forEach((u) => {
      const c = UNITS[u.t].c;
      let cell;
      if (lv === 1 && Math.random() < 0.4) cell = take([...Array(28).keys()].sort(() => Math.random() - 0.5));
      else if (c === 0 || c === 5) cell = take(front);
      else if (c === 3) cell = take(front);
      else if (c === 4) cell = take(back);
      else if (c === 6) cell = take(mid);
      else cell = take(back);
      nb[cell] = u;
    });
    const nbench = new Array(8).fill(null); rest.forEach((u, k) => { if (k < 8) nbench[k] = u; else p.g += sellVal(u); });
    p.b = packBoard(nb); p.n = packBench(nbench);
  }
  function ai(s, seat, lv) { return { t: 'auto', lv: lv || 2 }; } // 강화 고르기도 'auto' 안에서 (aiAug)
  function aiDelayFor(s, seat, lv) { return (lv === 3 ? 1200 : lv === 1 ? 2600 : 1800) + rnd(1500); }

  /* ───────── 그림 ───────── */
  const PATHS = {};
  function glyph(cls) { const k = cls < 0 ? 'm' : cls; if (!PATHS[k]) PATHS[k] = new Path2D(cls < 0 ? MCL.g : CLS[cls].g); return PATHS[k]; }
  function tokenColors(t) { if (t >= NU) return ['#5a2a2a', '#c45a4a']; const D = UNITS[t]; return [['#3b3326', '#2d2a3a', '#2b3a2f', '#3a2e24', '#2e2440', '#3e2622', '#2f3424'][D.o], ORG[D.o].c]; }
  const COSTC = ['', '#8c8c8c', '#5ea86a', '#4a8fd0', '#b55ed8', '#e3ae45'];
  function drawToken(ctx, x, y, sz, u, opt) {
    const t = u.t, [bg, rim] = tokenColors(t), cls = t >= NU ? -1 : UNITS[t].c;
    const r = sz * 0.42;
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.beginPath(); ctx.ellipse(x, y + r * 0.85, r * 0.9, r * 0.32, 0, 0, 7); ctx.fill();
    const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.4, r * 0.1, x, y, r);
    g.addColorStop(0, shade(bg, 30)); g.addColorStop(1, bg);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
    ctx.lineWidth = Math.max(2, sz * 0.06); ctx.strokeStyle = t >= NU ? rim : COSTC[UNITS[t].cost]; ctx.stroke();
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.beginPath(); ctx.arc(x, y, r - ctx.lineWidth - sz * 0.03, 0, 7); ctx.stroke();
    // 직업 문양
    const gs = r * 1.15 / 24;
    ctx.translate(x - 12 * gs, y - 12 * gs - r * 0.05); ctx.scale(gs, gs);
    ctx.strokeStyle = rim; ctx.lineWidth = 2.1; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.stroke(glyph(cls));
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.restore(); ctx.save();
    const dpr = ctx.getTransform ? null : null; // (자리 표시용)
    ctx.restore();
    // 별
    const st = u.st || 1;
    if (t < NU) {
      ctx.fillStyle = st === 3 ? '#ffd76a' : st === 2 ? '#d9dce6' : '#b07a4a';
      for (let k = 0; k < st; k++) star(ctx, x + (k - (st - 1) / 2) * r * 0.48, y - r * 1.02, r * 0.2);
    }
    if (u.it && u.it !== '-') {
      const isz = r * 0.62; const ix = x + r * 0.55, iy = y + r * 0.45;
      ctx.fillStyle = u.it >= '0' && u.it <= '5' ? '#3a3448' : '#5a3a1a'; ctx.strokeStyle = u.it >= '0' && u.it <= '5' ? '#9a8fb0' : '#e3ae45'; ctx.lineWidth = 1.5;
      rr(ctx, ix - isz / 2, iy - isz / 2, isz, isz, 3); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 ' + Math.round(isz * 0.62) + 'px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(itemAbbr(u.it), ix, iy + 1);
    }
  }
  function shade(hex, d) { const n = parseInt(hex.slice(1), 16); const c = (v) => Math.max(0, Math.min(255, v + d)); return 'rgb(' + c(n >> 16) + ',' + c((n >> 8) & 255) + ',' + c(n & 255) + ')'; }
  function star(ctx, x, y, r) { ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, q = i % 2 ? r * 0.45 : r; ctx.lineTo(x + Math.cos(a) * q, y + Math.sin(a) * q); } ctx.closePath(); ctx.fill(); }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function itemTile(ctx, x, y, sz, ch, hi) {
    const comp = ch >= '0' && ch <= '5';
    ctx.fillStyle = comp ? '#2e2840' : '#4a3018'; ctx.strokeStyle = hi ? '#ffd76a' : comp ? '#8f84a8' : '#e3ae45'; ctx.lineWidth = hi ? 2.5 : 1.5;
    rr(ctx, x, y, sz, sz, 6); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#f2e9d8'; ctx.font = '700 ' + Math.round(sz * 0.46) + 'px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(itemAbbr(ch), x + sz / 2, y + sz / 2 + 1);
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let bestDone = 0, st = null, Lo = null, drag = null, tip = null, rep = null, shown = 0, flash = null, spd = 1, stop = null, shk = 0;
    try { spd = +localStorage.getItem('lounge.mercs.spd') || 1; } catch (e) { /* 없음 */ }
    function me() { const v = api.viewer(); if (v >= 0) return v; const m = api.mySeats ? api.mySeats() : []; return m.length ? m[0] : -1; }
    function viewSeat() { const m = me(); if (m >= 0 && st.p[m].h > 0) return m; if (m >= 0 && st.over) return m; const a = alive(st); return m >= 0 && !a.length ? m : (a.length ? (m >= 0 ? a[0] : a[0]) : 0); }
    function canPlay() { const m = me(); return m >= 0 && st && !st.over && st.p[m].h > 0 && !st.p[m].r && !rep && api.canAct(m); }

    function layout() { layout0(0, 0, 0); const ex = cv.h - 2 - (Lo.btn.y + Lo.btn.h); if (ex > 4) { const sa = Math.min(22, ex * 0.3), ba = Math.min(8, ex * 0.1); layout0(Math.max(0, (ex - sa - ba) / 2), sa, ba); } }
    function layout0(top, shopAdd, btnAdd) {
      const W = cv.w, H = cv.h, pad = 6;
      let y = 4;
      const info = { y, h: 30 }; y += 32;
      const strip = { y, h: 26 }; y += 28;
      const syn = { y, h: 58 }; y += 60 + top * 0.5;
      const shopH = Math.min(96, Math.max(78, H * 0.12)) + shopAdd, btnH = 50 + btnAdd;
      const benchS = Math.min(56, (W - pad * 2) / 8);
      const itemH = 38;
      const rest = H - y - top * 0.5 - shopH - btnH - benchS - itemH - 16;
      const cell = Math.max(30, Math.min((W - pad * 2) / COLS, rest / ROWS));
      const bw = cell * COLS, bx = (W - bw) / 2;
      const board = { x: bx, y, c: cell, w: bw, h: cell * ROWS }; y += cell * ROWS + 4 + top * 0.5;
      const items = { x: pad, y, h: itemH, s: 34 }; y += itemH + 2;
      const bench = { x: (W - benchS * 8) / 2, y, s: benchS }; y += benchS + 6;
      const shop = { x: pad, y, w: W - pad * 2, h: shopH, cw: (W - pad * 2 - 4 * 4) / 5 }; y += shopH + 4;
      const btn = { x: pad, y, w: W - pad * 2, h: Math.min(btnH, H - y - 2) };
      // 전투: syn~btn 영역
      const fTop = syn.y + 20, fBot = btn.y - 4;
      const fc = Math.min((W - pad * 2) / COLS, (fBot - fTop) / 8);
      const field = { x: (W - fc * COLS) / 2, y: fTop + ((fBot - fTop) - fc * 8) / 2, c: fc };
      Lo = { W, H, info, strip, syn, board, items, bench, shop, btn, field };
      const bw4 = (btn.w - 3 * 6) / 4;
      Lo.btns = [
        { id: 'roll', x: btn.x, w: bw4 * 0.95 }, { id: 'xp', x: btn.x + bw4 * 0.95 + 6, w: bw4 * 1.05 }, { id: 'lock', x: btn.x + bw4 * 2 + 12, w: bw4 * 0.7 }, { id: 'ready', x: btn.x + bw4 * 2.7 + 18, w: bw4 * 1.3 },
      ];
    }
    cv.onresize = () => { layout(); };
    layout();

    function cellAt(x, y) { const B = Lo.board; if (x < B.x || x >= B.x + B.w || y < B.y || y >= B.y + B.h) return -1; return Math.floor((y - B.y) / B.c) * COLS + Math.floor((x - B.x) / B.c); }
    function dropCell(x, y) { const B = Lo.board, m = B.c * 0.45; if (x < B.x - m || x >= B.x + B.w + m || y < B.y - m || y >= B.y + B.h + m * 0.6) return -1; const cx = Math.max(0, Math.min(COLS - 1, Math.floor((x - B.x) / B.c))), cy = Math.max(0, Math.min(ROWS - 1, Math.floor((y - B.y) / B.c))); return cy * COLS + cx; }
    function dropBench(x, y) { const B = Lo.bench; if (y < B.y - 10 || y > B.y + B.s + 12 || x < B.x - 10 || x >= B.x + B.s * 8 + 10) return -1; return Math.max(0, Math.min(7, Math.floor((x - B.x) / B.s))); }
    function dropTarget(x, y) { const c = dropCell(x, y); if (c >= 0) return 'b' + c; const b = dropBench(x, y); return b >= 0 ? 'n' + b : null; }
    function benchAt(x, y) { const B = Lo.bench; if (y < B.y || y > B.y + B.s || x < B.x || x >= B.x + B.s * 8) return -1; return Math.floor((x - B.x) / B.s); }
    function shopAt(x, y) { const S = Lo.shop; if (y < S.y || y > S.y + S.h || x < S.x || x > S.x + S.w) return -1; return Math.min(4, Math.floor((x - S.x) / (S.cw + 4))); }
    function itemAt(x, y) { const I = Lo.items; if (y < I.y || y > I.y + I.h) return -1; const k = Math.floor((x - I.x) / (I.s + 6)); const p = st.p[me()]; return p && k >= 0 && k < p.i.length && x - I.x - k * (I.s + 6) <= I.s ? k : -1; }
    function synAt(x, y) { if (!Lo.synHit) return null; return Lo.synHit.find((h) => x >= h.x && x <= h.x + h.w && y >= h.y && y <= h.y + h.h) || null; }
    function btnAt(x, y) { const B = Lo.btn; if (y < B.y || y > B.y + B.h) return null; return Lo.btns.find((b) => x >= b.x && x <= b.x + b.w) || null; }
    function pressBtn(id) {   // 상점 버튼(탭·단축키 공용)
      const m = me(), p = m >= 0 ? st.p[m] : null;
      if (!p || !canPlay()) return;
        if (id === 'roll') { if (p.g < 2) { api.toast('금화가 모자라요'); return; } api.act({ t: 'roll' }); api.sfx('card'); }
        else if (id === 'xp') { if (p.l >= 9) { api.toast('최고 레벨이에요'); return; } if (p.g < 4) { api.toast('금화가 모자라요'); return; } const l0 = p.l; api.act({ t: 'xp' }); api.sfx('tick'); if (st.p[m].l > l0) { api.toast('레벨 ' + st.p[m].l + '! 이제 ' + st.p[m].l + '명까지 세울 수 있어요'); api.sfx('win'); } }
        else if (id === 'lock') { api.act({ t: 'lock' }); api.sfx('click'); api.toast(st.p[m].k ? '상점 잠금 — 다음 라운드에도 그대로' : '잠금 풀림'); }
        else if (id === 'ready') { api.act({ t: 'ready' }); api.sfx('whoosh'); }
    }
    function repBtnAt(x, y) { if (!Lo.repBtns) return null; return Lo.repBtns.find((b) => x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) || null; }

    function act(a, okSfx) {
      const m = me(); if (m < 0) return false;
      const before = JSON.stringify(st.p[m]);
      api.act(a);
      return before;
    }

    function pressRep(id) { if (!rep) return; if (id === 'skip') rep.t = 1e9; else { spd = spd >= 4 ? 1 : spd * 2; try { localStorage.setItem('lounge.mercs.spd', spd); } catch (e) { /* 없음 */ } } api.sfx('click'); }
    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down' || !st) return;
      if (id === 'spd' || id === 'skip') pressRep(id); else if (!rep) pressBtn(id);
    }) : null;
    let down = null;
    function pdown(ev) {
      if (!st) return; const P = cv.local(ev);
      if (rep) { const b = repBtnAt(P.x, P.y); if (b) { if (b.id === 'skip') rep.t = 1e9; else { spd = spd >= 4 ? 1 : spd * 2; try { localStorage.setItem('lounge.mercs.spd', spd); } catch (e) { /* 없음 */ } } api.sfx('click'); } return; }
      down = { x: P.x, y: P.y, moved: false };
      if (!canPlay()) { return; }
      const p = st.p[me()];
      if (p.o) return;
      const c = cellAt(P.x, P.y);
      if (c >= 0 && parseBoard(p.b)[c]) { drag = { kind: 'u', f: 'b' + c, u: parseBoard(p.b)[c], x: P.x, y: P.y }; return; }
      const b = benchAt(P.x, P.y);
      if (b >= 0 && parseBench(p.n)[b]) { drag = { kind: 'u', f: 'n' + b, u: parseBench(p.n)[b], x: P.x, y: P.y }; return; }
      const it = itemAt(P.x, P.y);
      if (it >= 0) { drag = { kind: 'i', k: it, ch: p.i[it], x: P.x, y: P.y }; return; }
    }
    function pmove(ev) { if (!down) return; const P = cv.local(ev); if (Math.hypot(P.x - down.x, P.y - down.y) > 8) down.moved = true; if (drag) { drag.x = P.x; drag.y = P.y; } }
    function pup(ev) {
      if (!down || !st) { down = null; drag = null; return; }
      const P = cv.local(ev), moved = down.moved; down = null;
      const d = drag; drag = null;
      const m = me(), p = m >= 0 ? st.p[m] : null;
      if (p && p.o && canPlay()) {
        const h = (Lo.augHit || []).find((q) => P.x >= q.x && P.x <= q.x + q.w && P.y >= q.y && P.y <= q.y + q.h);
        if (h) { const A = AUG[ACH.indexOf(p.o[h.k])]; api.act({ t: 'aug', k: h.k }); api.sfx('win'); api.buzz(20); api.toast('강화 「' + A.n + '」'); }
        return;
      }
      if (!moved && P.y >= Lo.info.y && P.y <= Lo.info.y + Lo.info.h) { const vp = st.p[viewSeat()]; tip = tip && tip.kind === 'aug' ? null : { kind: 'aug', g: vp ? vp.a : '' }; return; }
      if (d && moved && canPlay()) {
        if (d.kind === 'u') {
          const sh = P.y >= Lo.shop.y - 4 && P.y <= Lo.shop.y + Lo.shop.h + 4;
          if (sh) { api.act({ t: 'sell', f: d.f }); api.sfx('chip'); api.toast('판매 +' + sellVal(d.u) + '금화'); return; }
          let to = dropTarget(P.x, P.y); const c = to && to[0] === 'b' ? +to.slice(1) : -1;
          if (to && to !== d.f) {
            if (to[0] === 'b' && d.f[0] === 'n' && !parseBoard(p.b)[c] && boardCount(p) >= p.l) { api.toast('판에는 레벨만큼(' + p.l + '명)만 세울 수 있어요'); api.buzz(30); return; }
            api.act({ t: 'mv', f: d.f, to }); api.sfx('click'); return;
          }
          return;
        }
        if (d.kind === 'i') {
          const ik = itemAt(P.x, P.y);
          if (ik >= 0 && ik !== d.k) { const a = p.i[ik]; if (a >= '0' && a <= '5' && d.ch >= '0' && d.ch <= '5') { api.act({ t: 'mix', a: ik, b: d.k }); api.sfx('pop'); api.toast(FULL[combine(+a, +d.ch)][2] + ' 완성!'); } else api.toast('부품끼리만 합칠 수 있어요'); return; }
          const loc = dropTarget(P.x, P.y); if (!loc) return;
          const u = getLoc(p, loc); if (!u) return;
          if (u.it !== '-' && !(u.it >= '0' && u.it <= '5' && d.ch >= '0' && d.ch <= '5')) { api.toast('아이템 칸이 찼어요'); return; }
          const full = u.it !== '-';
          api.act({ t: 'item', k: d.k, to: loc }); api.sfx(full ? 'pop' : 'chip');
          if (full) api.toast(FULL[combine(+u.it, +d.ch)][2] + ' 완성!');
          return;
        }
      }
      // 탭
      if (tip && tip.sellR && canPlay()) { const r = tip.sellR; if (P.x >= r.x && P.x <= r.x + r.w && P.y >= r.y && P.y <= r.y + r.h && getLoc(p, tip.f)) { api.act({ t: 'sell', f: tip.f }); api.sfx('chip'); api.toast('판매 +' + sellVal(tip.u) + '금화'); tip = null; return; } }
      const sb = synAt(P.x, P.y); if (sb) { tip = { kind: 'trait', o: sb.o, k: sb.k }; return; }
      if (tip) { tip = null; if (!moved) return; }
      if (!canPlay()) {
        const c = cellAt(P.x, P.y); const vp = st.p[viewSeat()]; if (c >= 0 && vp && parseBoard(vp.b)[c]) tip = { kind: 'u', u: parseBoard(vp.b)[c] };
        return;
      }
      const bt = btnAt(P.x, P.y);
      if (bt) {
        pressBtn(bt.id);
        return;
      }
      const sk = shopAt(P.x, P.y);
      if (sk >= 0) {
        const ch = p.s[sk]; if (ch === '.') return;
        const t = TCH.indexOf(ch);
        if (p.g < UNITS[t].cost) { api.toast('금화가 모자라요'); api.buzz(30); return; }
        const before = p.n + p.b;
        api.act({ t: 'buy', k: sk });
        const after = st.p[m];
        if (after.n + after.b === before) { api.toast('대기석이 꽉 찼어요 — 하나 팔아 주세요'); api.buzz(30); return; }
        if (st.ev && st.ev.k === 'merge' && st.ev.s === m) { api.sfx('pop'); api.buzz(20); const u = st.ev.u; flash = { txt: UNITS[TCH.indexOf(u[0])].n + ' ★' + u[1] + '!', t: 0 }; }
        else api.sfx('chip');
        return;
      }
      const c = cellAt(P.x, P.y); if (c >= 0 && parseBoard(p.b)[c]) { tip = { kind: 'u', u: parseBoard(p.b)[c], f: 'b' + c }; return; }
      const b = benchAt(P.x, P.y); if (b >= 0 && parseBench(p.n)[b]) { tip = { kind: 'u', u: parseBench(p.n)[b], f: 'n' + b }; return; }
      const ik = itemAt(P.x, P.y); if (ik >= 0) { tip = { kind: 'i', ch: p.i[ik] }; return; }
    }
    cv.cv.addEventListener('pointerdown', pdown); window.addEventListener('pointermove', pmove); window.addEventListener('pointerup', pup);

    /* 전투 재생 */
    function startReplay(last) {
      const v = viewSeat0(last);
      const q = last.pr.findIndex((r) => r[0] === v || (r[1] === v && !r[2]));
      if (q < 0) return;
      const [a, b, gh] = last.pr[q];
      const flip = b === v && !gh; // 내가 B쪽이면 뒤집어 보이기: A↔B 바꿔서 같은 결과가 안 나오므로, 그대로 두고 화면만 뒤집음
      const bB = b < 0 ? monsterBoard(last.rd) : last.bd[b];
      const ag = last.ag || [];
      const f = fight(last.bd[a], bB, last.sd + q * 7919, true, ag[a] || '', b < 0 ? '' : ag[b] || '');
      rep = { f, t: 0, a, b, gh, flip, rd: last.rd, pv: last.pv, res: last.rs[q], me: v, end: 0, disp: f.us.map(() => null), fx: [] };
      api.setBusy(true);
    }
    function viewSeat0(last) { const m = me(); if (m >= 0 && last.bd[m]) return m; const fst = last.pr[0]; return fst ? fst[0] : 0; }

    let prevT = 0;
    stop = U.loop((dt) => { draw(Math.min(0.05, dt > 1 ? dt / 1000 : dt)); });

    function draw(dt) {
      if (!st || !Lo) return;
      const W = cv.w, H = cv.h; if (W !== Lo.W || H !== Lo.H) layout();
      ctx.clearRect(0, 0, W, H);
      const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#1a1420'); bg.addColorStop(1, '#0f0c14');
      ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      drawInfo();
      if (rep) { const k = shk > 0 ? (shk -= dt, 3.5 * (L.fx ? L.fx() : 1) * Math.min(1, shk / 0.22)) : 0; ctx.save(); if (k > 0) ctx.translate((Math.random() - 0.5) * k, (Math.random() - 0.5) * k); drawReplay(dt); ctx.restore(); } else drawBuy();
      if (flash) { flash.t += dt; const a = Math.max(0, 1 - flash.t / 1.4); ctx.globalAlpha = a; ctx.fillStyle = '#ffd76a'; ctx.font = '26px "Black Han Sans",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(flash.txt, W / 2, Lo.board.y + Lo.board.h / 2 - flash.t * 20); ctx.globalAlpha = 1; if (a <= 0) flash = null; }
      if (tip) drawTip();
    }
    function txt(s, x, y, size, col, al, font) { ctx.fillStyle = col || '#f2e9d8'; ctx.font = (font || '600 ') + size + 'px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = al || 'left'; ctx.textBaseline = 'middle'; ctx.fillText(s, x, y); }
    function drawInfo() {
      const vs = viewSeat(), p = st.p[vs], I = Lo.info, W = Lo.W;
      ctx.fillStyle = '#221c2e'; rr(ctx, 6, I.y, W - 12, I.h, 8); ctx.fill();
      const y = I.y + I.h / 2;
      const intr = Math.min(5 + augEff(p.a).ic, Math.floor(p.g / 10));
      txt('❤ ' + Math.max(0, p.h), 14, y, 14, p.h < 30 ? '#ee6a55' : '#f2e9d8', 'left', '700 ');
      txt('◉ ' + p.g, 70, y, 14, '#e3ae45', 'left', '700 ');
      txt('+' + intr, 70 + ctx.measureText('◉ ' + p.g).width + 18, y, 10, '#ab9fb8');
      const lvS = 'Lv' + p.l + (p.l < 9 ? ' ' + p.x + '/' + XPN[p.l] : '');
      txt(lvS, W * 0.46, y, 13, '#f2e9d8', 'center', '700 ');
      if (p.a) { ctx.font = '700 13px "IBM Plex Sans KR",sans-serif'; txt('✦' + p.a.length, W * 0.46 + ctx.measureText(lvS).width / 2 + 8, y, 12, '#c9a0f0', 'left', '700 '); }
      const wS = p.w >= 2 ? '연승' + p.w : p.w <= -2 ? '연패' + (-p.w) : '';
      txt((isPve(st.rd) ? '괴물 ' : '') + st.rd + 'R' + (wS ? ' · ' + wS : ''), W - 14, y, 12, isPve(st.rd) ? '#d8806a' : '#ab9fb8', 'right', '700 ');
      // 선수 띠
      const S = Lo.strip, n = st.p.length, cw = (W - 12) / n;
      st.p.forEach((q, i) => {
        const x = 6 + i * cw, pl = api.players[i];
        ctx.globalAlpha = q.h > 0 ? 1 : 0.35;
        ctx.fillStyle = i === vs ? '#3a3050' : '#1d1828'; rr(ctx, x + 1, S.y, cw - 2, S.h, 6); ctx.fill();
        ctx.fillStyle = pl ? pl.color : '#888'; ctx.beginPath(); ctx.arc(x + 9, S.y + S.h / 2, 4.5, 0, 7); ctx.fill();
        txt(q.h > 0 ? String(q.h) : q.pl + '위', x + 16, S.y + S.h / 2, 11, q.r && q.h > 0 && !rep ? '#9fd3a4' : '#f2e9d8', 'left', '700 ');
        ctx.fillStyle = '#ee6a55'; ctx.fillRect(x + 4, S.y + S.h - 4, (cw - 8) * Math.max(0, q.h) / 100, 2);
        ctx.globalAlpha = 1;
      });
    }
    function drawSyn(board, g) {
      const tr = traitCounts(board, g), list = [];
      tr.o.forEach((c, k) => { if (c) list.push({ o: 1, k, c, t: tier(c, ORG[k].th), th: ORG[k].th, n: ORG[k].n, col: ORG[k].c }); });
      tr.c.forEach((c, k) => { if (c) list.push({ o: 0, k, c, t: tier(c, CLS[k].th), th: CLS[k].th, n: CLS[k].n, col: '#e3ae45' }); });
      list.sort((a, b) => b.t - a.t || b.c - a.c);
      const S = Lo.syn, W = Lo.W, per = 4, cw = (W - 12 - 3 * 4) / per, ch = 18;
      Lo.synHit = [];
      if (!list.length) { txt('용병을 판에 세우면 시너지가 여기 보여요', W / 2, S.y + S.h / 2, 11, '#6f6580', 'center'); return; }
      const more = list.length > 12 ? list.length - 11 : 0;
      list.slice(0, more ? 11 : 12).forEach((L0, i) => {
        const x = 6 + (i % per) * (cw + 4), y = S.y + Math.floor(i / per) * (ch + 2);
        ctx.fillStyle = L0.t ? (L0.t === 2 ? '#4a3a1a' : '#2e2a3e') : '#1b1724'; rr(ctx, x, y, cw, ch, 5); ctx.fill();
        ctx.strokeStyle = L0.t ? L0.col : '#3a3348'; ctx.lineWidth = L0.t === 2 ? 2 : 1; ctx.stroke();
        const next = L0.th.find((v) => v > L0.c);
        txt(L0.n.replace(' ', ''), x + 5, y + ch / 2, 10, L0.t ? '#f2e9d8' : '#8a7f99', 'left', '700 ');
        txt(L0.c + '/' + (next || L0.th[1]), x + cw - 4, y + ch / 2, 10, L0.t ? L0.col : '#8a7f99', 'right', '700 ');
        Lo.synHit.push({ x, y, w: cw, h: ch, o: L0.o, k: L0.k });
      });
      if (more) { const x = 6 + 3 * (cw + 4), y = S.y + 2 * (ch + 2); ctx.fillStyle = '#1b1724'; rr(ctx, x, y, cw, ch, 5); ctx.fill(); txt('+' + more + ' (1명)', x + cw / 2, y + ch / 2, 10, '#8a7f99', 'center', '700 '); }
    }
    function cellRect(B, c) { return { x: B.x + (c % COLS) * B.c, y: B.y + Math.floor(c / COLS) * B.c }; }
    function drawTable(x, y, w, h) {
      const g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, '#2a2230'); g.addColorStop(1, '#1d1822');
      ctx.fillStyle = '#3a2618'; rr(ctx, x - 5, y - 5, w + 10, h + 10, 8); ctx.fill();
      ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
    }
    function drawBuy() {
      const m = me(), vs = viewSeat(), p = st.p[vs], mine = m >= 0 && vs === m;
      const board = parseBoard(p.b), bench = parseBench(p.n);
      drawSyn(board, p.a);
      const B = Lo.board;
      drawTable(B.x, B.y, B.w, B.h);
      for (let c = 0; c < 28; c++) {
        const R = cellRect(B, c), r = Math.floor(c / COLS);
        ctx.fillStyle = (c % COLS + r) % 2 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.12)'; ctx.fillRect(R.x, R.y, B.c, B.c);
      }
      ctx.strokeStyle = 'rgba(227,174,69,.25)'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(B.x, B.y + 0.5); ctx.lineTo(B.x + B.w, B.y + 0.5); ctx.stroke(); ctx.setLineDash([]);
      txt('▲ 앞줄 (적 쪽)', B.x + 4, B.y + 8, 9, 'rgba(227,174,69,.55)');
      const cnt = Object.keys(board).length;
      txt(cnt + '/' + p.l + '명', B.x + B.w - 4, B.y + B.h - 8, 10, cnt > p.l ? '#ee6a55' : cnt < p.l ? '#9fd3a4' : 'rgba(242,233,216,.5)', 'right', '700 ');
      const mg = {}; if (mine && !p.o) { const own = Object.values(board).concat(bench.filter(Boolean)); for (const ch of p.s) { if (ch === '.') continue; const t = TCH.indexOf(ch); if (own.filter((u) => u.t === t && u.st === 1).length >= 2) mg[t] = 1; } }
      const pulse = 0.55 + 0.45 * Math.sin(performance.now() / 220);
      const ring = (x, y, r) => { ctx.strokeStyle = 'rgba(255,215,106,' + pulse + ')'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.stroke(); };
      for (const k in board) { if (drag && drag.kind === 'u' && drag.f === 'b' + k) continue; const R = cellRect(B, +k); if (mg[board[k].t] && board[k].st === 1) ring(R.x + B.c / 2, R.y + B.c / 2 + 2, B.c * 0.48); drawToken(ctx, R.x + B.c / 2, R.y + B.c / 2 + 2, B.c, board[k]); }
      // 아이템
      const I = Lo.items;
      if (p.i.length) {
        for (let k = 0; k < p.i.length; k++) { if (drag && drag.kind === 'i' && drag.k === k) continue; itemTile(ctx, I.x + k * (I.s + 6), I.y + 2, I.s, p.i[k]); }
        if (p.i.length <= 4) txt('끌어서 용병에게 주기', I.x + p.i.length * (I.s + 6) + 4, I.y + I.h / 2, 10, '#8a7f99');
      } else txt('아이템 보관함 — 괴물 라운드에서 얻어요', I.x + 2, I.y + I.h / 2, 10, '#5f566e');
      // 대기석
      const Bn = Lo.bench;
      for (let k = 0; k < 8; k++) {
        const x = Bn.x + k * Bn.s;
        ctx.fillStyle = '#1e1928'; rr(ctx, x + 2, Bn.y, Bn.s - 4, Bn.s, 6); ctx.fill(); ctx.strokeStyle = '#332b42'; ctx.lineWidth = 1; ctx.stroke();
        if (bench[k] && mg[bench[k].t] && bench[k].st === 1) ring(x + Bn.s / 2, Bn.y + Bn.s / 2 + 2, Bn.s * 0.46);
        if (bench[k] && !(drag && drag.kind === 'u' && drag.f === 'n' + k)) drawToken(ctx, x + Bn.s / 2, Bn.y + Bn.s / 2 + 2, Bn.s * 0.95, bench[k]);
      }
      // 상점 (판매 표시)
      const S = Lo.shop, sellMode = drag && drag.kind === 'u' && down && down.moved;
      if (sellMode) {
        ctx.fillStyle = drag.y >= S.y - 4 ? '#5a2020' : '#3a1a1a'; rr(ctx, S.x, S.y, S.w, S.h, 10); ctx.fill();
        ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 2; ctx.stroke();
        txt('여기에 놓으면 판매  +' + sellVal(drag.u) + ' ◉', S.x + S.w / 2, S.y + S.h / 2, 15, '#f2e9d8', 'center', '700 ');
      } else {
        const sp = mine ? p : null;
        for (let k = 0; k < 5; k++) {
          const x = S.x + k * (S.cw + 4), ch = p.s[k];
          ctx.fillStyle = '#221c2e'; rr(ctx, x, S.y, S.cw, S.h, 8); ctx.fill();
          if (ch === '.' || ch == null) { ctx.strokeStyle = '#2e2640'; ctx.lineWidth = 1; ctx.stroke(); continue; }
          const t = TCH.indexOf(ch), D = UNITS[t], can = p.g >= D.cost;
          ctx.strokeStyle = COSTC[D.cost]; ctx.lineWidth = 2; ctx.stroke();
          const owned = Object.values(board).concat(bench.filter(Boolean)).filter((u) => u.t === t && u.st === 1).length;
          ctx.globalAlpha = can ? 1 : 0.45;
          drawToken(ctx, x + S.cw / 2, S.y + S.h * 0.36, Math.min(S.cw * 0.8, S.h * 0.5), { t, st: 1, it: '-' });
          const nm = D.n.length > 5 && S.cw < 72 ? D.n.replace(' ', '\n') : D.n;
          const lines = nm.split('\n');
          lines.forEach((ln, li) => txt(ln, x + S.cw / 2, S.y + S.h * 0.7 + li * 11 - (lines.length - 1) * 5, 10, '#f2e9d8', 'center', '700 '));
          txt(ORG[D.o].n.split(' ')[0] + '·' + CLS[D.c].n, x + S.cw / 2, S.y + S.h - 8, 9, '#ab9fb8', 'center');
          txt(D.cost + '◉', x + S.cw - 5, S.y + 9, 11, '#e3ae45', 'right', '700 ');
          ctx.globalAlpha = 1;
          if (owned >= 2) { ctx.strokeStyle = 'rgba(255,215,106,' + pulse + ')'; ctx.lineWidth = 3; rr(ctx, x + 1, S.y + 1, S.cw - 2, S.h - 2, 8); ctx.stroke(); txt('★2 합체', x + 5, S.y + 9, 9, '#ffd76a', 'left', '700 '); }
          else if (owned === 1) txt('보유 1', x + 5, S.y + 9, 9, '#9fd3a4', 'left', '700 ');
        }
        if (p.k) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.setLineDash([6, 4]); rr(ctx, S.x - 2, S.y - 2, S.w + 4, S.h + 4, 10); ctx.stroke(); ctx.setLineDash([]); const lw = 160; ctx.fillStyle = '#4a3a1a'; rr(ctx, S.x + S.w / 2 - lw / 2, S.y - 9, lw, 16, 8); ctx.fill(); txt('🔒 잠김 · 다음 라운드에도 유지', S.x + S.w / 2, S.y - 1, 9, '#ffd76a', 'center', '700 '); }
      }
      // 버튼
      const Bt = Lo.btn;
      if (m >= 0 && st.p[m].h > 0 && st.p[m].r) {
        ctx.fillStyle = '#221c2e'; rr(ctx, Bt.x, Bt.y, Bt.w, Bt.h, 10); ctx.fill();
        const waiting = alive(st).filter((i) => !st.p[i].r).length;
        txt('준비 완료 — 다른 용병단 ' + waiting + '곳을 기다리는 중…', Bt.x + Bt.w / 2, Bt.y + Bt.h / 2, 13, '#ab9fb8', 'center', '600 ');
      } else if (m >= 0 && st.p[m].h <= 0) {
        txt(st.p[m].pl + '위로 탈락 — 남은 싸움을 지켜봐요', Bt.x + Bt.w / 2, Bt.y + Bt.h / 2, 13, '#ab9fb8', 'center');
      } else if (canPlay()) {
        Lo.btns.forEach((b) => {
          const lab = b.id === 'roll' ? ['↻ 새로', '2◉'] : b.id === 'xp' ? ['⬆ 경험치', p.l >= 9 ? '최고' : '4◉'] : b.id === 'lock' ? [p.k ? '🔒' : '🔓', p.k ? '잠김' : '잠금'] : ['전투 ▶', '준비'];
          const dis = (b.id === 'roll' && p.g < 2) || (b.id === 'xp' && (p.g < 4 || p.l >= 9));
          ctx.fillStyle = b.id === 'ready' ? '#e3ae45' : b.id === 'lock' && p.k ? '#4a3a1a' : '#2e2640';
          ctx.globalAlpha = dis ? 0.45 : 1;
          rr(ctx, b.x, Bt.y, b.w, Bt.h, 10); ctx.fill();
          const ink = b.id === 'ready' ? '#1a1420' : '#f2e9d8';
          txt(lab[0], b.x + b.w / 2, Bt.y + Bt.h * 0.38, 13, ink, 'center', '700 ');
          txt(lab[1], b.x + b.w / 2, Bt.y + Bt.h * 0.72, 10, b.id === 'ready' ? '#3a2a10' : '#e3ae45', 'center', '700 ');
          ctx.globalAlpha = 1;
          if (L.ui && L.ui.drawKeyBadge) L.ui.drawKeyBadge(ctx, b.x + b.w - 2, Bt.y + Bt.h - 2, L.ui.keyLabel('mercs', b.id), 0.85);
        });
      }
      Lo.augHit = null;
      if (mine && p.o && canPlay()) drawAugPick(p);
      // 끄는 중
      if (drag && down && down.moved) {
        if (drag.kind === 'u') {
          hiTarget(drag.x, drag.y, p, 'u');
          drawToken(ctx, drag.x, drag.y - 18, B.c * 1.1, drag.u);
        } else { hiTarget(drag.x, drag.y, p, 'i'); itemTile(ctx, drag.x - 18, drag.y - 40, 36, drag.ch, true); }
      }
    }
    function hiTarget(x, y, p, kind) {
      if (kind === 'u' && y >= Lo.shop.y - 4) return;
      const to = dropTarget(x, y); if (!to) return;
      const B = Lo.board, Bn = Lo.bench, k = +to.slice(1);
      const R = to[0] === 'b' ? { x: cellRect(B, k).x, y: cellRect(B, k).y, s: B.c } : { x: Bn.x + k * Bn.s, y: Bn.y, s: Bn.s };
      const occ = getLoc(p, to);
      let ok = true;
      if (kind === 'u' && to[0] === 'b' && drag.f[0] === 'n' && !occ && boardCount(p) >= p.l) ok = false;
      if (kind === 'i') ok = !!occ && (occ.it === '-' || (occ.it >= '0' && occ.it <= '5' && drag.ch >= '0' && drag.ch <= '5'));
      const col = ok ? '#ffd76a' : '#ee6a55';
      ctx.fillStyle = ok ? 'rgba(255,215,106,.18)' : 'rgba(238,106,85,.18)'; ctx.fillRect(R.x + 1, R.y + 1, R.s - 2, R.s - 2);
      ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.strokeRect(R.x + 1.5, R.y + 1.5, R.s - 3, R.s - 3);
      if (kind === 'u' && occ && to !== drag.f) txt('⇄', R.x + R.s - 8, R.y + 9, 11, col, 'center', '700 ');
    }
    const RCOL = [null, '#b9c3cf', '#e3ae45', '#c9a0f0'], RNM = [null, '은빛', '금빛', '무지개'];
    function wrapTxt(str, w, size) { ctx.font = '500 ' + size + 'px "IBM Plex Sans KR",sans-serif'; const out = []; let cur = ''; for (const c of str) { if (ctx.measureText(cur + c).width > w) { out.push(cur); cur = ''; } cur += c; } out.push(cur); return out; }
    function drawAugPick(p) {
      const W = Lo.W, top = Lo.syn.y, bot = Lo.btn.y + Lo.btn.h;
      ctx.fillStyle = 'rgba(12,9,18,.94)'; rr(ctx, 6, top, W - 12, bot - top, 12); ctx.fill();
      const A0 = AUG[ACH.indexOf(p.o[0])], col = RCOL[A0.r];
      txt('✦ 강화 고르기 — ' + RNM[A0.r] + ' 등급', W / 2, top + 22, 16, col, 'center', '700 ');
      txt('이번 판에서만 효과가 이어져요 · 하나를 탭하세요', W / 2, top + 44, 11, '#ab9fb8', 'center');
      const n = p.o.length, gap = 10, y0 = top + 60, ch = Math.min(120, (bot - y0 - 10 - gap * (n - 1)) / n);
      Lo.augHit = [];
      for (let k = 0; k < n; k++) {
        const A = AUG[ACH.indexOf(p.o[k])], x = 16, y = y0 + k * (ch + gap), w = W - 32;
        ctx.fillStyle = '#221c2e'; rr(ctx, x, y, w, ch, 12); ctx.fill(); ctx.strokeStyle = RCOL[A.r]; ctx.lineWidth = 2; ctx.stroke();
        txt(A.n, x + 14, y + 20, 16, '#f2e9d8', 'left', '700 ');
        txt(A.k, x + w - 12, y + 20, 11, RCOL[A.r], 'right', '700 ');
        wrapTxt(A.d, w - 28, 13).slice(0, 3).forEach((ln, i) => txt(ln, x + 14, y + 44 + i * 18, 13, '#d8cfe0', 'left', '500 '));
        Lo.augHit.push({ x, y, w, h: ch, k });
      }
    }
    function drawReplay(dt) {
      const R0 = rep, f = R0.f, F = Lo.field, W = Lo.W;
      const sp = spd * SPD();
      if (!R0.end) R0.t += dt * sp;
      const fi = Math.min(f.fr.length - 1, Math.floor(R0.t / DT));
      const frac = Math.min(1, R0.t / DT - fi);
      const done = R0.t / DT >= f.fr.length - 1;
      // 상대 이름
      const top = R0.flip ? R0.a : R0.b, bot = R0.flip ? R0.b : R0.a;
      const topName = R0.b < 0 ? '중립 괴물' : (R0.gh && top === R0.b ? '그림자: ' : '') + (api.players[top] ? api.players[top].name : '');
      const botName = api.players[bot] ? api.players[bot].name : '';
      txt('⚔ ' + topName, 10, Lo.syn.y + 9, 13, '#ee6a55', 'left', '700 ');
      txt(R0.res[0] === 2 ? '' : '', W - 10, Lo.syn.y + 9, 11, '#ab9fb8', 'right');
      drawTable(F.x, F.y, F.c * COLS, F.c * 8);
      for (let y = 0; y < 8; y++) for (let x = 0; x < COLS; x++) { ctx.fillStyle = (x + y) % 2 ? 'rgba(255,255,255,.03)' : 'rgba(0,0,0,.12)'; ctx.fillRect(F.x + x * F.c, F.y + y * F.c, F.c, F.c); }
      ctx.strokeStyle = 'rgba(238,106,85,.3)'; ctx.beginPath(); ctx.moveTo(F.x, F.y + F.c * 4); ctx.lineTo(F.x + F.c * COLS, F.y + F.c * 4); ctx.stroke();
      const fr = f.fr[fi], nx = f.fr[Math.min(f.fr.length - 1, fi + 1)];
      const pos = (x, y) => (R0.flip ? { x: F.x + (COLS - 1 - x + 0.5) * F.c, y: F.y + (7 - y + 0.5) * F.c } : { x: F.x + (x + 0.5) * F.c, y: F.y + (y + 0.5) * F.c });
      // 이벤트 → 효과
      if (!R0.end && R0.lastFi !== fi) {
        for (let q = (R0.lastFi == null ? 0 : R0.lastFi); q < fi; q++) {
          (f.ev[q] || []).forEach((e) => {
            if (e[0] === 'd' || e[0] === 'heal') R0.fx.push({ k: e[0], tag: e[3], u: e[1], v: e[2], t: 0, src: null });
            if (e[0] === 'cast') { R0.fx.push({ k: 'cast', u: e[1], t: 0 }); }
            if (e[0] === 'die') { shk = 0.22; if (Math.random() < 0.7) api.sfx('thud'); }
          });
          if ((f.ev[q] || []).some((e) => e[0] === 'cast')) api.sfx('whoosh');
        }
        R0.lastFi = fi;
        if (R0.fx.length > 60) R0.fx.splice(0, R0.fx.length - 60);
      }
      f.us.forEach((u, k) => {
        const a = fr[k], b = nx[k];
        if (!a[4] && !b[4]) return;
        const P = pos(a[0], a[1]), Q = pos(b[0], b[1]);
        const tgt = { x: P.x + (Q.x - P.x) * frac, y: P.y + (Q.y - P.y) * frac };
        let d = R0.disp[k];
        if (!d) d = R0.disp[k] = { x: tgt.x, y: tgt.y };
        const kk = Math.min(1, dt * sp * 8); d.x += (tgt.x - d.x) * kk; d.y += (tgt.y - d.y) * kk;
        if (!b[4] && fi === f.fr.length - 1) return;
        const sz = F.c;
        drawToken(ctx, d.x, d.y, sz, u);
        // 체력/마나
        const hw = sz * 0.8, hx = d.x - hw / 2, hy = d.y - sz * 0.62;
        ctx.fillStyle = 'rgba(0,0,0,.7)'; ctx.fillRect(hx - 1, hy - 1, hw + 2, 9);
        const mine = (u.side === 0) !== R0.flip;
        ctx.fillStyle = mine ? '#6fcf7a' : '#ee6a55'; ctx.fillRect(hx, hy, hw * Math.max(0, a[2]) / u.mhp, 5);
        if (a[3] > 0) { ctx.fillStyle = '#e8e8f0'; ctx.fillRect(hx, hy, Math.min(hw, hw * a[3] / u.mhp), 2); }
        ctx.fillStyle = '#6a9cf0'; ctx.fillRect(hx, hy + 5.5, hw * a[5] / 100, 2);
      });
      // 효과 그리기
      R0.fx = R0.fx.filter((e) => {
        e.t += dt * Math.min(sp, 3);
        const d = R0.disp[e.u]; if (!d) return false;
        if (e.k === 'cast') { const a = 1 - e.t / 0.5; if (a <= 0) return false; ctx.strokeStyle = 'rgba(179,138,224,' + a + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(d.x, d.y, F.c * (0.4 + e.t), 0, 7); ctx.stroke(); return true; }
        const a = 1 - e.t / 0.8; if (a <= 0) return false;
        if (e.k === 'd' && e.tag !== 'ab' && e.tag !== 'c') { ctx.fillStyle = 'rgba(255,240,220,' + a * 0.5 + ')'; ctx.beginPath(); ctx.arc(d.x + (e.v % 7) - 3, d.y - 4, F.c * 0.12 * (1 + e.t), 0, 7); ctx.fill(); if (sp <= 2 && e.v >= 30) { ctx.globalAlpha = a * 0.85; txt(String(e.v), d.x + (e.v % 9) - 4, d.y - F.c * 0.35 - e.t * 18, 10, '#f2e9d8', 'center', '700 '); ctx.globalAlpha = 1; } return true; }
        ctx.globalAlpha = a;
        txt((e.k === 'heal' ? '+' : '') + e.v, d.x, d.y - F.c * 0.5 - e.t * 26, e.tag === 'c' ? 15 : 13, e.k === 'heal' ? '#6fcf7a' : e.tag === 'c' ? '#ffd76a' : '#c9a7ff', 'center', '800 ');
        ctx.globalAlpha = 1; return true;
      });
      txt('▼ ' + botName, 10, F.y + F.c * 8 + 10, 12, '#9fd3a4', 'left', '700 ');
      // 버튼
      const Bt = Lo.btn, bw = (Bt.w - 8) / 2;
      Lo.repBtns = [{ id: 'spd', x: Bt.x, y: Bt.y, w: bw, h: Bt.h }, { id: 'skip', x: Bt.x + bw + 8, y: Bt.y, w: bw, h: Bt.h }];
      if (!done) {
        Lo.repBtns.forEach((b) => { ctx.fillStyle = '#2e2640'; rr(ctx, b.x, b.y, b.w, b.h, 10); ctx.fill(); txt(b.id === 'spd' ? '⏩ ×' + spd + ' 빠르게' : '⏭ 결과 보기', b.x + b.w / 2, b.y + b.h / 2, 14, '#f2e9d8', 'center', '700 ');  if (L.ui && L.ui.drawKeyBadge) L.ui.drawKeyBadge(ctx, b.x + b.w - 2, b.y + b.h - 2, L.ui.keyLabel('mercs', b.id), 0.85); });
      }
      if (done) {
        if (!R0.end) {
          R0.end = 1; R0.endT = 0;
          const myWin = (R0.res[0] === 0 && R0.me === R0.a) || (R0.res[0] === 1 && R0.me === R0.b);
          const mine = R0.me === R0.a || R0.me === R0.b;
          if (mine && me() >= 0) { api.sfx(myWin ? 'win' : R0.res[0] === 2 ? 'tick' : 'lose'); if (!myWin) api.buzz(40); }
        }
        R0.endT += dt;
        const myIsA = R0.me === R0.a;
        const w = R0.res[0], dmg = myIsA ? R0.res[1] : R0.res[2];
        const won = (w === 0 && myIsA) || (w === 1 && !myIsA);
        ctx.fillStyle = 'rgba(10,8,14,.72)'; rr(ctx, 20, F.y + F.c * 3, W - 40, F.c * 2, 14); ctx.fill();
        txt(w === 2 ? '무승부' : won ? '승리!' : '패배', W / 2, F.y + F.c * 3.75, 30, w === 2 ? '#e3ae45' : won ? '#9fd3a4' : '#ee6a55', 'center', '400 ');
        ctx.font = '30px "Black Han Sans",sans-serif';
        txt(dmg ? '체력 -' + dmg : R0.pv && w === 0 ? '아이템 부품 획득' : '피해 없음', W / 2, F.y + F.c * 4.5, 14, '#f2e9d8', 'center', '700 ');
        if (R0.endT > 1.4 / Math.min(2, SPD())) { rep = null; Lo.repBtns = null; api.setBusy(false); }
      }
    }
    function drawTip() {
      const W = Lo.W, x = 10, y = Lo.syn.y, w = W - 20;
      let lines = [], title = '', col = '#e3ae45';
      if (tip.kind === 'u') {
        const u = tip.u;
        if (u.t >= NU) { const M = MON[u.t - NU]; title = M.n; lines = ['체력 ' + M.hp * u.st + ' · 공격 ' + M.atk * u.st]; }
        else {
          const D = UNITS[u.t], C = CLS[D.c], cm = 1 + 0.24 * (D.cost - 1), sm = SM[u.st];
          title = D.n + ' ★' + u.st + '  (' + D.cost + '◉)'; col = ORG[D.o].c;
          lines = [ORG[D.o].n + ' · ' + C.n, '체력 ' + Math.round(C.hp * cm * sm) + ' · 공격 ' + Math.round(C.atk * cm * sm) + ' · 사거리 ' + C.rng + ' · 방어 ' + C.ar,
            '「' + C.ab + '」 ' + C.ad];
          if (u.it !== '-') lines.push('아이템: ' + itemName(u.it) + ' — ' + itemDesc(u.it));
          if (!tip.f) lines.push('판매 ' + sellVal(u) + '◉ (상점 칸으로 끌기)');
        }
      } else if (tip.kind === 'i') { title = itemName(tip.ch); lines = [itemDesc(tip.ch)]; }
      else if (tip.kind === 'aug') { title = '✦ 강화'; col = '#c9a0f0'; lines = augs(tip.g).map((A) => A.n + ' — ' + A.d); if (!lines.length) lines = ['아직 강화가 없어요. 3·10·17라운드가 끝나면 셋 중 하나를 골라요.']; }
      else { const T = tip.o ? ORG[tip.k] : CLS[tip.k]; title = T.n + '  (' + T.th.join(' / ') + '명)'; col = tip.o ? T.c : '#e3ae45'; lines = T.d.slice(); if (!tip.o) lines.push('기술 「' + T.ab + '」 ' + T.ad);
        const vp = st.p[viewSeat()], have = {}; if (vp) { const bd = parseBoard(vp.b); for (const q in bd) have[bd[q].t] = 1; }
        lines.push('용병: ' + UNITS.map((D, j) => ((tip.o ? D.o : D.c) === tip.k ? (have[j] ? '✔' : '') + D.n + '(' + D.cost + '◉)' : '')).filter(Boolean).join(', ')); }
      // 줄바꿈
      ctx.font = '500 12px "IBM Plex Sans KR",sans-serif';
      const wrapped = [];
      lines.forEach((ln) => { let cur = ''; for (const chh of ln) { if (ctx.measureText(cur + chh).width > w - 24) { wrapped.push(cur); cur = ''; } cur += chh; } wrapped.push(cur); });
      const sellB = tip.kind === 'u' && tip.f && canPlay() && tip.u.t < NU;
      const h = 34 + wrapped.length * 17 + 6 + (sellB ? 52 : 0);
      ctx.fillStyle = 'rgba(20,16,28,.96)'; rr(ctx, x, y, w, h, 12); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.stroke();
      txt(title, x + 12, y + 17, 15, col, 'left', '700 ');
      wrapped.forEach((ln, i) => txt(ln, x + 12, y + 38 + i * 17, 12, '#f2e9d8', 'left', '500 '));
      txt('탭하면 닫혀요', x + w - 10, y + 17, 9, '#8a7f99', 'right');
      tip.sellR = null;
      if (sellB) { const r = { x: x + 12, y: y + h - 52, w: w - 24, h: 44 }; tip.sellR = r; ctx.fillStyle = '#5a2020'; rr(ctx, r.x, r.y, r.w, r.h, 10); ctx.fill(); ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 1.5; ctx.stroke(); txt('바로 판매  +' + sellVal(tip.u) + ' ◉', r.x + r.w / 2, r.y + r.h / 2, 14, '#f2e9d8', 'center', '700 '); }
    }

    return {
      update(s, prev) {
        st = s;
        if (s.last && s.last.id !== shown) {
          const first = !prev || prev === s && !shown;
          shown = s.last.id;
          if (!first || (prev && prev !== s)) { tip = null; drag = null; startReplay(s.last); }
        }
        const m = me();
        if (m >= 0 && api.best && !bestDone && s.p[m] && s.p[m].pl && (api.mySeats ? api.mySeats() : [m]).includes(m)) {
          bestDone = 1; const P = s.p[m];
          const nr = api.best('rank', P.pl, { label: '최고 순위', lower: true, unit: '위' });
          const ns = P.m >= 2 && api.best('streak', P.m, { label: '최고 연승', unit: '연승' });
          if (nr || ns) api.toast('🏆 새 최고 기록! ' + (nr ? P.pl + '위' : '') + (nr && ns ? ' · ' : '') + (ns ? P.m + '연승' : ''));
        }
      },
      destroy() { if (offKeys) offKeys(); stop && stop(); cv.cv.removeEventListener('pointerdown', pdown); window.removeEventListener('pointermove', pmove); window.removeEventListener('pointerup', pup); api.setBusy(false); cv.destroy(); },
    };
  }

  /* ───────── 도감 ───────── */
  function svgOf(cls, col) { const d = cls < 0 ? MCL.g : CLS[cls].g; return '<svg viewBox="0 0 24 24" width="28" height="28"><circle cx="12" cy="12" r="11" fill="#221c2e" stroke="' + col + '" stroke-width="1.2"/><path d="' + d + '" transform="translate(3.6 3.6) scale(.7)" fill="none" stroke="' + col + '" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'; }
  function codex() {
    return [
      { h: '용병', p: ['가격(◉)이 높을수록 강해요. 같은 용병 3명 → ★2 (능력치 1.8배), ★2 셋 → ★3. 체력·공격은 ★1 기준.'],
        rows: UNITS.map((D, i) => { const C = CLS[D.c], cm = 1 + 0.24 * (D.cost - 1); return { icon: svgOf(D.c, ORG[D.o].c), name: D.n + ' · ' + D.cost + '◉', tag: ORG[D.o].n + ' · ' + C.n, desc: '체력 ' + Math.round(C.hp * cm) + ' · 공격 ' + Math.round(C.atk * cm) + ' · 사거리 ' + C.rng + ' · 「' + C.ab + '」 ' + C.ad }; }).sort((a, b) => a.name.split('·')[1].localeCompare(b.name.split('·')[1])) },
      { h: '특성', p: ['판에 세운 서로 다른 용병 수로 단계가 켜져요. 출신 ' + ORG.length + '개 + 직업 ' + CLS.length + '개.'],
        rows: ORG.map((O) => ({ icon: '<svg viewBox="0 0 24 24" width="28" height="28"><path d="M12 2 L21 7 V17 L12 22 L3 17 V7 Z" fill="#221c2e" stroke="' + O.c + '" stroke-width="2"/></svg>', name: O.n, tag: '출신 · 용병 ' + UNITS.filter((u) => ORG[u.o] === O).map((u) => u.n).join(', '), desc: O.d.join(' / ') }))
          .concat(CLS.map((C, k) => ({ icon: svgOf(k, '#e3ae45'), name: C.n, tag: '직업 · 기술 「' + C.ab + '」', desc: C.d.join(' / ') + ' · ' + C.ad }))) },
      { h: '아이템', p: ['괴물 라운드에서 부품을 얻어요. 부품 두 개를 한 용병에게 주거나(또는 보관함에서 서로 겹치면) 완성 아이템이 돼요. 용병마다 한 칸.'],
        rows: COMP.map((c, k) => ({ icon: '🜨', name: c.n, tag: '부품', desc: c.d }))
          .concat(FULL.map((f) => ({ icon: '✦', name: f[2], tag: COMP[f[0]].n + ' + ' + COMP[f[1]].n, desc: COMP[f[0]].d + ', ' + COMP[f[1]].d + ' · ' + SP[f[3]] }))) },
      { h: '강화', p: ['3·10·17라운드가 끝나면 모두 같은 등급(은빛·금빛·무지개)의 강화 셋 중 하나를 골라요. 효과는 이번 판에서만 이어져요. 뒤로 갈수록 높은 등급이 잘 나와요.'],
        rows: AUG.map((A) => ({ icon: ['', '◇', '◆', '✦'][A.r], name: A.n, tag: ['', '은빛', '금빛', '무지개'][A.r] + ' · ' + A.k, desc: A.d })).sort((a, b) => a.tag.localeCompare(b.tag)) },
      { h: '괴물', p: ['1·2라운드와 8라운드부터 6라운드마다 모두가 괴물과 싸워요. 지면 피해가 절반.'],
        rows: MON.map((M) => ({ icon: svgOf(-1, '#c45a4a'), name: M.n, tag: '중립 괴물', desc: '체력 ' + M.hp + ' · 공격 ' + M.atk + ' · 사거리 ' + M.rng })) },
    ];
  }

  L.register({
    id: 'mercs', name: '용병단 오토배틀러', tag: '오토배틀러', cat: '보드',
    blurb: '상점에서 용병을 사서 판에 세우면 전투는 저절로. 같은 용병 셋을 모아 별을 올리고, 시너지를 맞춰 마지막까지 살아남으세요.',
    controls: [
      { id: 'ready', label: '전투 ▶ 준비', keys: ['Space', 'Enter'], pad: ['a'] },
      { id: 'roll', label: '↻ 상점 새로', keys: ['KeyR'], pad: ['x'] },
      { id: 'xp', label: '⬆ 경험치', keys: ['KeyF'], pad: ['y'] },
      { id: 'lock', label: '🔒 상점 잠금', keys: ['KeyQ'], pad: ['lb'] },
      { id: 'spd', label: '⏩ 빠르게', keys: ['KeyS'], pad: ['rb'] },
      { id: 'skip', label: '⏭ 결과 보기', keys: ['KeyE'], pad: ['b'] },
    ],
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 8, fixedOrder: true,
    realtimeIf: () => true, // 모두 동시에 사는 게임이라 한 폰에 한 명(나 + AI), 친구와는 온라인/LAN
    tint: '#4a1f24',
    icon: '<path d="M28 6 L44 12 V26 C44 36 37 44 28 48 C19 44 12 36 12 26 V12 Z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M20 20 L36 36 M36 20 L20 36" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><circle cx="28" cy="28" r="4" fill="currentColor"/><path d="M18 52 H38" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" opacity=".6"/>',
    quick: ['목표: 체력 100을 지키며 마지막까지 살아남는 용병단이 우승해요.', '라운드마다 상점에서 용병을 사고, 판에 세운 뒤 「전투 ▶」를 눌러요.', '전투는 자동! 지면 남은 적 수만큼 체력이 깎여요.'],
    rules: [
      { h: '목표', p: ['2~8개 용병단이 싸워요. 체력이 0이 되면 탈락, 마지막 하나가 우승이에요.'] },
      { h: '라운드에 할 일 (모두 동시에)', p: ['상점 카드를 탭하면 대기석으로 사요. 용병을 끌어서 판(7×4칸)에 세우세요. 판에는 레벨만큼만 설 수 있어요.',
        '↻ 새로(2◉): 상점 바꾸기 · ⬆ 경험치(4◉): 레벨 올리기 · 🔓 잠금: 다음 라운드에도 상점 그대로.', '팔기: 용병을 상점 칸으로 끌어 놓거나, 용병을 탭해서 「바로 판매」를 누르면 금화를 돌려받아요. 상점에서 금빛으로 깜빡이는 카드는 사면 바로 ★2로 합쳐져요(합쳐질 용병도 함께 깜빡여요).', '다 했으면 「전투 ▶」. 모두 준비되면 전투가 시작돼요.'] },
      { h: '금화', p: ['라운드마다 기본 5 + 이자(10◉마다 1, 최대 5) + 연승·연패 보너스(2연속 +1, 4연속 +2, 5연속 +3) + 이기면 1.', '예시: 금화 34◉, 3연승 → 5 + 3 + 1 + 1 = 10◉을 받아요.'] },
      { h: '강화', p: ['3·10·17라운드가 끝나면 강화 셋 중 하나를 골라요(모두 동시에). 경제(금화·이자 상한)·전투(특성 +1, 앞줄 방어 등)·아이템(부품)·용병(무료 용병) 네 갈래. 이번 판에서만 효과가 있어요.',
        '위쪽 정보 줄을 탭하면 내 강화(✦)를 볼 수 있어요. 전체 목록은 📖 도감.'] },
      { h: '별 올리기', p: ['같은 용병 ★1 셋이 모이면 저절로 ★2(약 1.8배), ★2 셋이면 ★3이 돼요. 대기석이 꽉 차도 바로 합쳐지는 용병은 살 수 있어요.'] },
      { h: '시너지', p: ['용병 40종마다 출신(북방 전사단·사막 상회·망령 군단·기계 길드·심연 교단·야수 부족·역병 의회)과 직업(방패병·궁수·마법사·암살자·사제·기수·저주술사)이 있어요.',
        '저주술사는 적 전체의 방어·마법 저항을 깎고, 역병 의회는 공격마다 최대 체력 비례 피해를 줘요(4명이면 적의 회복도 줄여요).',
        '판에 서로 다른 용병 2명·4명이 같은 특성이면 효과가 켜져요. 위쪽 시너지 칸을 탭하면 설명이 나와요.'] },
      { h: '전투', p: ['앞줄(위쪽)이 적과 가까워요. 방패병·기수는 앞, 저주술사는 가운데, 궁수·마법사·사제는 뒤가 좋아요. 암살자는 시작하자마자 적 뒷줄로 뛰어들어요.',
        '공격하면 마나가 차고, 가득 차면 직업 기술을 써요. 상대는 매 라운드 무작위로 정해져요.',
        '남은 용병단이 홀수면 한 곳은 「그림자: (용병단 이름)」과 싸워요 — 살아 있는 다른 용병단의 이번 판 그대로예요(체력이 비슷한 곳이 잘 뽑히고, 같은 그림자·같은 대상이 연달아 나오지 않아요). 그림자에게 지면 피해가 절반, 그림자 주인은 피해를 받지 않아요.',
        '지면 체력 -(기본 피해 + 살아남은 적의 별 합). 기본 피해는 라운드가 갈수록 커져요.'] },
      { h: '괴물 라운드와 아이템', p: ['1·2라운드, 그리고 8라운드부터 6라운드마다 괴물과 싸우고 아이템 부품을 얻어요(8라운드부터 이기면 하나 더).',
        '부품을 용병에게 끌어 주세요. 부품을 가진 용병에게 부품을 하나 더 주거나, 보관함에서 부품끼리 겹치면 완성 아이템이 돼요. 자세한 건 📖 도감.'] },
      { h: '조작', p: ['탭: 사기 / 용병·아이템 설명 보기. 끌기: 배치·자리 바꾸기·팔기·아이템 주기. 전투 중 「⏩ 빠르게」(×1→×2→×4)·「⏭ 결과 보기」.',
        '한 폰에서는 나 혼자 + AI로 해요. 친구와는 온라인/LAN으로 한 폰에 한 명씩. AI 난이도는 자리마다 쉬움·보통·어려움.'] },
    ],
    tutorial: [
      { text: '상점 카드(아래)를 탭하면 용병을 사서 대기석에 둬요.' },
      { text: '대기석의 용병을 위쪽 판으로 끌어 세우세요. 앞줄이 적과 가까워요. 판에는 레벨만큼만 설 수 있어요.' },
      { text: '같은 용병 셋이 모이면 ★2로 합쳐져요. 위쪽 칸은 시너지 — 같은 특성 2명·4명이면 강해져요.' },
      { text: '다 했으면 「전투 ▶」! 전투는 자동이에요. 지면 체력이 깎이고, 마지막까지 버티면 우승.' },
    ],
    codex: codex(),
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { fight, parseBoard, monsterBoard, UNITS, traits: (b) => { const t = traitCounts(parseBoard(b)); return t.o.map((c, k) => [ORG[k].n, c, tier(c, ORG[k].th)]).concat(t.c.map((c, k) => [CLS[k].n, c, tier(c, CLS[k].th)])); } },
  });
})();
