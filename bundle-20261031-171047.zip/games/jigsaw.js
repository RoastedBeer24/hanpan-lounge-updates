/* 직소 퍼즐 — 혼자 맞추는 조각 그림 퍼즐.
   그림: 무작위 생성(시드 고정 → 같은 시드면 같은 그림) 또는 내 사진(기기 안에서만 쓰고 절대 올리지 않음).
   조각 위치는 상태(2.5KB 제한)에 넣지 않고 뷰가 들고 localStorage에 저장(이어 하기). 상태에는 판 설정·완료 여부만.
   모델: 그룹 = {x,y,r,lk,p:[조각]} — 그룹 안 조각은 모두 같은 원점(x,y)·회전 r을 공유(조각 위치 = 원점 + R(r)·(c·S, r·S)).
   그래서 이웃 조각 붙이기 = 「같은 r이고 원점이 가까움」, 판에 맞추기 = 「r=0이고 원점이 (0,0) 근처」. */
(function () {
  const L = window.Lounge, U = L.util;
  /* ---------- 오늘의 퍼즐 (날짜 YYYYMMDD 씨앗 → 모두 같은 퍼즐). 기록·연속 일수는 이 기기에만, 지난 7일치만 남김 ---------- */
  function mkDaily(gid, short, fmt, lower) {
    const SK = 'lounge.daily.' + gid;
    const ymd = (d) => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
    const toD = (n) => new Date(Math.floor(n / 10000), Math.floor(n / 100) % 100 - 1, n % 100, 12);
    const shift = (n, k) => { const d = toD(n); d.setDate(d.getDate() + k); return ymd(d); };
    const rd = () => { try { return JSON.parse(localStorage.getItem(SK) || '{}') || {}; } catch (e) { return {}; } };
    const wr = (o) => { try { localStorage.setItem(SK, JSON.stringify(o)); } catch (e) {} };
    const D = {
      today: () => ymd(new Date()),
      md: (n) => (Math.floor(n / 100) % 100) + '/' + (n % 100),
      long: (n) => (Math.floor(n / 100) % 100) + '월 ' + (n % 100) + '일',
      seed(n) { let h = (n >>> 0) ^ 0x9e3779b9; h = Math.imul(h ^ (h >>> 16), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; },
      score: (n) => { const o = rd(); return o.done ? o.done[n] : undefined; },
      streak() { const o = rd(), t = D.today(); return o.last && (o.last === t || o.last === shift(t, -1)) ? o.st | 0 : 0; },
      prune() {
        const o = rd(), cut = shift(D.today(), -6);
        if (o.done) for (const k in o.done) if (+k < cut) delete o.done[k];
        wr(o);
        try { const all = U.store.get('best.' + gid, {}); let ch = 0; for (const k in all) if (/^d\d{8}$/.test(k) && +k.slice(1) < cut) { delete all[k]; ch = 1; } if (ch) U.store.set('best.' + gid, all); } catch (e) {}
      },
      /* 완료 기록 → 새 최고면 true */
      complete(n, sc, api) {
        const o = rd(); o.done = o.done || {};
        const old = o.done[n], first = old == null;
        if (first || (lower ? sc < old : sc > old)) o.done[n] = sc;
        if (first) { o.st = o.last === shift(n, -1) ? (o.st | 0) + 1 : o.last === n ? o.st | 0 || 1 : 1; if (!o.last || n > o.last) o.last = n; }
        wr(o);
        if (api) api.best('d' + n, sc, { label: '오늘의 퍼즐 ' + D.md(n), lower: !!lower, unit: fmt === 'time' ? '' : fmt, fmt: fmt === 'time' ? 'time' : '' });
        D.prune();
        return !first && o.done[n] === sc && sc !== old;
      },
      text(n) {
        const sc = D.score(n);
        const v = fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt;
        return '한판 라운지 ' + short + ' ' + D.md(n) + ' ✓ ' + v + ' · 연속 ' + Math.max(1, D.streak()) + '일';
      },
      share(n, api) {
        const t = D.text(n), ok = () => api && api.toast('복사했어요: ' + t);
        const fb = () => { try { const ta = L.h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); ok(); } catch (e) { if (api) api.toast(t); } };
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb(); } catch (e) { fb(); }
      },
      fmtScore(sc) { return sc == null ? '' : fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt; },
      /* 단계/모드 고르기 맨 위에 넣는 큰 카드 */
      card(onPlay, api, sub) {
        const n = D.today(), sc = D.score(n), st = D.streak();
        const box = L.h('div', { class: 'daily-card', style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '12px', borderRadius: '14px', border: '2px solid var(--brass,#e3ae45)', background: 'linear-gradient(135deg,rgba(227,174,69,.22),rgba(227,174,69,.06))' } });
        const head = L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } });
        head.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', lineHeight: '1.2' } },
          L.h('b', { style: { fontSize: '18px' }, text: '📅 오늘의 퍼즐' }),
          L.h('span', { class: 'muted', style: { fontSize: '13px' }, text: D.long(n) + (sub ? ' · ' + sub : '') })),
          L.h('div', { style: { textAlign: 'right', lineHeight: '1.2', fontSize: '13px' } },
            L.h('div', { style: { fontSize: '15px', fontWeight: '700', color: sc != null ? '#8fd14f' : 'inherit' }, text: sc != null ? '완료 ✓' : '미완료' }),
            L.h('div', { class: 'muted', text: '🔥 연속 ' + st + '일' })));
        box.append(head);
        if (sc != null) box.append(L.h('div', { style: { fontSize: '13px' }, text: '오늘 최고 ' + D.fmtScore(sc) }));
        const row = L.h('div', { style: { display: 'flex', gap: '6px' } });
        row.append(L.h('button', { class: 'btn primary', style: { flex: '1', minHeight: '48px' }, text: sc != null ? '다시 도전 ▶' : '도전하기 ▶', onclick: () => onPlay(n) }));
        if (sc != null) row.append(L.h('button', { class: 'btn', style: { flex: '0 0 auto', minHeight: '48px', padding: '0 14px' }, text: '📋 공유', onclick: () => D.share(n, api) }));
        box.append(row);
        return box;
      },
    };
    return D;
  }
  const S = 100;                       // world units per piece
  const KEY = 'lounge.jigsaw.save', PKEY = 'lounge.jigsaw.photo';
  const GRID = { 24: [4, 6], 48: [6, 8], 96: [8, 12], 150: [10, 15], 300: [15, 20] };
  const ARTS = ['mount', 'geo', 'glass', 'stars', 'city'];
  const DAILY = mkDaily('jigsaw', '직소', 'time', true);
  /* 오늘의 퍼즐: 96조각 · 회전 없음 · 날짜로 그림 종류와 씨앗을 정함(세로 배치 고정 → 누구나 같은 조각) */
  function dailyCfg(dy) { const sd = DAILY.seed(dy); return { n: 96, rot: 0, art: ARTS[sd % ARTS.length], sd: (sd >>> 1) || 1 }; }
  const ART_NAME = { mount: '산과 노을', geo: '기하 추상', glass: '스테인드글라스', stars: '별바다', city: '밤의 도시', photo: '내 사진' };

  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const lsGet = (k) => { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
  const lsDel = (k) => { try { localStorage.removeItem(k); } catch (e) {} };

  /* ---------- cut generation (pure) ---------- */
  function gridFor(n, portrait, aspect) {
    if (aspect) { // photo: follow its shape
      let c = Math.max(2, Math.round(Math.sqrt(n * aspect))), r = Math.max(2, Math.round(n / c));
      return [c, r];
    }
    const g = GRID[n] || GRID[48];
    return portrait ? [g[0], g[1]] : [g[1], g[0]];
  }
  function makeCut(cols, rows, sd) {
    const r = prng(sd ^ 0x5bd1e995), j = 0.045;
    const mk = () => ({ f: r() < 0.5 ? 1 : -1, t: 0.085 + r() * 0.025, a: (r() * 2 - 1) * j, b: (r() * 2 - 1) * j, c: (r() * 2 - 1) * j, d: (r() * 2 - 1) * j, e: (r() * 2 - 1) * j });
    const H = [], V = [];
    for (let i = 0; i < (rows - 1) * cols; i++) H.push(mk());   // between row y and y+1 at column x: H[y*cols+x]
    for (let i = 0; i < rows * (cols - 1); i++) V.push(mk());   // between col x and x+1 at row y: V[y*(cols-1)+x]
    return { cols, rows, H, V };
  }
  /* 10 points of an edge from A to B in global orientation; f=+1 bumps toward +y (horizontal edge) / +x (vertical edge) */
  function edgePts(ax, ay, bx, by, P, vertical) {
    const len = Math.hypot(bx - ax, by - ay), ux = (bx - ax) / len, uy = (by - ay) / len;
    const nx = -uy, ny = ux, sg = vertical ? -P.f : P.f;
    const t = P.t, b = P.b, c = P.c, d = P.d;
    const q = [[0, 0], [0.2, P.a], [0.5 + b + d, -t + c], [0.5 - t + b, t + c], [0.5 - 2 * t + b - d, 3 * t + c], [0.5 + 2 * t + b - d, 3 * t + c],
      [0.5 + t + b, t + c], [0.5 + b + d, -t + c], [0.8, P.e], [1, 0]];
    return q.map(([u, v]) => [ax + ux * u * len + nx * v * sg * len, ay + uy * u * len + ny * v * sg * len]);
  }
  /* outline of piece id as list of segments: ['L',x,y] or ['C',x1,y1,x2,y2,x,y] starting at its top-left corner (global coords) */
  function pieceOutline(cut, id) {
    const { cols, rows, H, V } = cut, cx = id % cols, cy = (id / cols) | 0;
    const x0 = cx * S, y0 = cy * S, x1 = x0 + S, y1 = y0 + S, out = [];
    const add = (pts, rev) => { const p = rev ? pts.slice().reverse() : pts; for (let k = 1; k < 10; k += 3) out.push(['C', p[k][0], p[k][1], p[k + 1][0], p[k + 1][1], p[k + 2][0], p[k + 2][1]]); };
    if (cy === 0) out.push(['L', x1, y0]); else add(edgePts(x0, y0, x1, y0, H[(cy - 1) * cols + cx], false), false);
    if (cx === cols - 1) out.push(['L', x1, y1]); else add(edgePts(x1, y0, x1, y1, V[cy * (cols - 1) + cx], true), false);
    if (cy === rows - 1) out.push(['L', x0, y1]); else add(edgePts(x0, y1, x1, y1, H[cy * cols + cx], false), true);
    if (cx === 0) out.push(['L', x0, y0]); else add(edgePts(x0, y0, x0, y1, V[cy * (cols - 1) + cx - 1], true), true);
    return out;
  }
  const isEdge = (cut, id) => { const x = id % cut.cols, y = (id / cut.cols) | 0; return x === 0 || y === 0 || x === cut.cols - 1 || y === cut.rows - 1; };

  /* ---------- group model (pure) ---------- */
  function rotV(x, y, r) { return r === 0 ? [x, y] : r === 1 ? [-y, x] : r === 2 ? [-x, -y] : [y, -x]; }
  function pieceCenter(cut, g, id) {
    const [lx, ly] = rotV(((id % cut.cols) + 0.5) * S, (((id / cut.cols) | 0) + 0.5) * S, g.r);
    return [g.x + lx, g.y + ly];
  }
  function setCenter(cut, g, id, px, py) { // move group so piece id is centered at (px,py)
    const [lx, ly] = rotV(((id % cut.cols) + 0.5) * S, (((id / cut.cols) | 0) + 0.5) * S, g.r);
    g.x = px - lx; g.y = py - ly;
  }
  function rotateGroup(cut, g, id) { // 90° about piece id
    const [px, py] = pieceCenter(cut, g, id);
    g.r = (g.r + 1) & 3; setCenter(cut, g, id, px, py);
  }
  function groupOf(M) { const o = new Array(M.cut.cols * M.cut.rows); M.gs.forEach((g, i) => g.p.forEach((id) => { o[id] = i; })); return o; }
  /* drop group gi: join neighbours with same rotation and nearby origin, then lock to the board. → {g, joined, locked} */
  function snap(M, gi, tol) {
    const cut = M.cut, cols = cut.cols, n = cols * cut.rows;
    let g = M.gs[gi], joined = 0, locked = false, again = true;
    while (again) {
      again = false;
      const own = groupOf(M), me = M.gs.indexOf(g);
      for (const id of g.p) {
        const x = id % cols, nb = [x > 0 ? id - 1 : -1, x < cols - 1 ? id + 1 : -1, id - cols, id + cols];
        for (const k of nb) {
          if (k < 0 || k >= n || own[k] === me) continue;
          const h = M.gs[own[k]];
          if (h.r !== g.r || Math.hypot(h.x - g.x, h.y - g.y) > tol) continue;
          h.p.push(...g.p); M.gs.splice(me, 1);
          // keep merged group on top of z-order
          M.gs.splice(M.gs.indexOf(h), 1); M.gs.push(h);
          if (h.lk) locked = true;
          g = h; joined++; again = true; break;
        }
        if (again) break;
      }
    }
    if (!g.lk && g.r === 0 && Math.hypot(g.x, g.y) <= tol) { g.x = 0; g.y = 0; g.lk = 1; locked = true; }
    if (g.lk) { // merge all locked groups into one
      for (let i = M.gs.length - 1; i >= 0; i--) { const h = M.gs[i]; if (h !== g && h.lk) { g.p.push(...h.p); M.gs.splice(i, 1); } }
      M.gs.splice(M.gs.indexOf(g), 1); M.gs.unshift(g); // board group at the bottom
    }
    return { g, joined, locked };
  }
  const solvedM = (M) => M.gs.length === 1 && M.gs[0].lk === 1;
  const placedCount = (M) => { const g = M.gs.find((q) => q.lk); return g ? g.p.length : 0; };

  /* lay out loose single pieces in tray cells around the board; aspect = view w/h */
  function trayCells(cut, aspect, need) {
    const FW = cut.cols * S, FH = cut.rows * S, C = S * 1.5, pad = S * 0.45;
    let area = (FW + 2 * pad) * (FH + 2 * pad) + need * C * C * 1.1;
    let W = Math.sqrt(area * aspect), Hh = area / W;
    if (W < FW + 2 * pad) { W = FW + 2 * pad; Hh = area / W; }
    if (Hh < FH + 2 * pad) { Hh = FH + 2 * pad; W = area / Hh; }
    for (let tries = 0; tries < 60; tries++) {
      const x0 = -(W - FW) / 2, y0 = aspect < 1 ? -pad : -(Hh - FH) / 2;
      const nx = Math.floor(W / C), ny = Math.floor(Hh / C), cells = [];
      const ox = x0 + (W - nx * C) / 2, oy = y0 + (Hh - ny * C) / 2;
      for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
        const cx = ox + (i + 0.5) * C, cy = oy + (j + 0.5) * C;
        if (cx > -pad - C / 2 && cx < FW + pad + C / 2 && cy > -pad - C / 2 && cy < FH + pad + C / 2) continue;
        cells.push([cx, cy]);
      }
      if (cells.length >= need) {
        // nearest-to-board first
        cells.sort((a, b) => dBox(a, FW, FH) - dBox(b, FW, FH));
        return { cells, box: [x0, y0, W, Hh] };
      }
      if (aspect < 1) Hh += C; else W += C;
    }
    return null;
  }
  function dBox(p, FW, FH) { const dx = Math.max(0, -p[0], p[0] - FW), dy = Math.max(0, -p[1], p[1] - FH); return dx * dx + dy * dy * 1.05 + p[0] * 1e-6; }
  function newModel(cut, rot, aspect, rng) {
    const n = cut.cols * cut.rows, M = { cut, gs: [] };
    for (let id = 0; id < n; id++) M.gs.push({ x: 0, y: 0, r: rot ? (rng() * 4) | 0 : 0, lk: 0, p: [id] });
    const T = trayCells(cut, aspect, n);
    const ids = []; for (let i = 0; i < n; i++) ids.push(i);
    for (let i = n - 1; i > 0; i--) { const j = (rng() * (i + 1)) | 0; const t = ids[i]; ids[i] = ids[j]; ids[j] = t; }
    ids.forEach((id, k) => { const c = T.cells[k]; setCenter(cut, M.gs[id], id, c[0] + (rng() - 0.5) * S * 0.3, c[1] + (rng() - 0.5) * S * 0.3); });
    // random z-order
    for (let i = n - 1; i > 0; i--) { const j = (rng() * (i + 1)) | 0; const t = M.gs[i]; M.gs[i] = M.gs[j]; M.gs[j] = t; }
    return M;
  }
  function sortTray(M, aspect) { // single loose pieces → neat rows, edges first
    const loose = M.gs.filter((g) => !g.lk && g.p.length === 1);
    const T = trayCells(M.cut, aspect, M.gs.filter((g) => !g.lk).reduce((a, g) => a + g.p.length, 0));
    if (!T) return;
    const multi = M.gs.filter((g) => !g.lk && g.p.length > 1);
    const used = T.cells.filter((c) => !multi.some((g) => g.p.some((id) => { const q = pieceCenter(M.cut, g, id); return Math.abs(q[0] - c[0]) < S && Math.abs(q[1] - c[1]) < S; })));
    loose.sort((a, b) => (isEdge(M.cut, b.p[0]) - isEdge(M.cut, a.p[0])));
    loose.forEach((g, k) => { const c = used[k] || T.cells[k % T.cells.length]; setCenter(M.cut, g, g.p[0], c[0], c[1]); });
  }

  /* ---------- procedural art ---------- */
  const hsl = (h, s, l, a) => 'hsla(' + (((h % 360) + 360) % 360).toFixed(0) + ',' + s.toFixed(0) + '%,' + l.toFixed(0) + '%,' + (a == null ? 1 : a) + ')';
  function ridge(r, n, rough) {
    const a = new Array(n + 1).fill(0); a[0] = r(); a[n] = r();
    (function sub(i, j, amp) { if (j - i < 2) return; const m = (i + j) >> 1; a[m] = (a[i] + a[j]) / 2 + (r() * 2 - 1) * amp; sub(i, m, amp * rough); sub(m, j, amp * rough); })(0, n, 0.5);
    return a;
  }
  function grain(ctx, W, H, r, amt) {
    const g = document.createElement('canvas'); g.width = g.height = 128;
    const x = g.getContext('2d'), d = x.createImageData(128, 128);
    for (let i = 0; i < d.data.length; i += 4) { const v = (r() * 255) | 0; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
    x.putImageData(d, 0, 0);
    ctx.save(); ctx.globalAlpha = amt; ctx.globalCompositeOperation = 'overlay'; ctx.fillStyle = ctx.createPattern(g, 'repeat'); ctx.fillRect(0, 0, W, H); ctx.restore();
  }
  function artMount(ctx, W, H, r) {
    const h0 = r() * 360, dark = r() < 0.5;
    const sky = ctx.createLinearGradient(0, 0, 0, H * 0.62);
    sky.addColorStop(0, hsl(h0 + 210, 50, dark ? 9 : 22)); sky.addColorStop(0.55, hsl(h0 + 300, 50, dark ? 30 : 48)); sky.addColorStop(1, hsl(h0 + 15, 85, dark ? 58 : 72));
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
    if (dark) for (let i = 0; i < W * H / 2500; i++) { ctx.fillStyle = 'rgba(255,255,240,' + (r() * 0.7).toFixed(2) + ')'; ctx.fillRect(r() * W, r() * H * 0.4, 1 + r() * 1.6, 1 + r() * 1.6); }
    const sx = W * (0.2 + r() * 0.6), sy = H * (0.3 + r() * 0.12), sr = W * (0.06 + r() * 0.05);
    let g = ctx.createRadialGradient(sx, sy, 0, sx, sy, sr * 7);
    g.addColorStop(0, hsl(h0 + 30, 100, 85, 0.7)); g.addColorStop(1, hsl(h0 + 30, 100, 70, 0));
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = hsl(h0 + 40, 100, 92); ctx.beginPath(); ctx.arc(sx, sy, sr, 0, 7); ctx.fill();
    for (let i = 0; i < 14; i++) { // cloud streaks
      const cy = H * (0.05 + r() * 0.42), cx = r() * W, cw = W * (0.2 + r() * 0.5), ch = H * (0.006 + r() * 0.018);
      ctx.fillStyle = hsl(h0 + 330 + r() * 40, 60, dark ? 40 + r() * 20 : 65 + r() * 20, 0.25 + r() * 0.35);
      ctx.beginPath(); ctx.ellipse(cx, cy, cw / 2, ch, 0, 0, 7); ctx.fill();
    }
    const layers = 6, water = r() < 0.55, base = water ? 0.74 : 0.98;
    for (let k = 0; k < layers; k++) {
      const t = k / (layers - 1), seg = 256, a = ridge(r, seg, 0.52 + r() * 0.08);
      const yb = H * (0.42 + t * (base - 0.42)), amp = H * (0.12 + 0.1 * (1 - t));
      ctx.beginPath(); ctx.moveTo(0, H);
      for (let i = 0; i <= seg; i++) ctx.lineTo(i / seg * W, yb - a[i] * amp);
      ctx.lineTo(W, H); ctx.closePath();
      const lg = ctx.createLinearGradient(0, yb - amp, 0, yb + H * 0.1);
      lg.addColorStop(0, hsl(h0 + 230 + t * 20, 30 + t * 10, 55 - t * 47)); lg.addColorStop(1, hsl(h0 + 250, 30, 40 - t * 36));
      ctx.fillStyle = lg; ctx.fill();
      // mist above next layer
      const mg = ctx.createLinearGradient(0, yb - amp * 0.2, 0, yb + amp * 0.3);
      mg.addColorStop(0, hsl(h0 + 15, 60, 70, 0)); mg.addColorStop(1, hsl(h0 + 15, 60, 70, 0.22 * (1 - t)));
      ctx.fillStyle = mg; ctx.fillRect(0, yb - amp * 0.2, W, amp * 0.5);
    }
    if (water) {
      const wy = H * 0.74, wg = ctx.createLinearGradient(0, wy, 0, H);
      wg.addColorStop(0, hsl(h0 + 10, 60, dark ? 35 : 55)); wg.addColorStop(1, hsl(h0 + 230, 45, 8));
      ctx.fillStyle = wg; ctx.fillRect(0, wy, W, H - wy);
      for (let i = 0; i < 160; i++) { const y = wy + Math.pow(r(), 1.5) * (H - wy), w = W * (0.02 + r() * 0.12) * (1 + (y - wy) / H * 3), x = sx + (r() - 0.5) * W * 0.5 * (1 + (y - wy) / (H - wy));
        ctx.fillStyle = hsl(h0 + 35, 100, 85, 0.15 + r() * 0.4); ctx.fillRect(x - w / 2, y, w, 1 + r() * 2.5); }
      for (let i = 0; i < 40; i++) { ctx.fillStyle = 'rgba(0,0,0,' + (0.1 + r() * 0.15).toFixed(2) + ')'; ctx.fillRect(r() * W, wy + r() * (H - wy), W * (0.05 + r() * 0.2), 1.5); }
      // shore with pines
      ctx.fillStyle = hsl(h0 + 240, 35, 5);
      ctx.beginPath(); ctx.moveTo(0, wy); for (let x = 0; x <= W; x += W / 60) ctx.lineTo(x, wy - H * 0.01 * r()); ctx.lineTo(W, wy + 4); ctx.lineTo(0, wy + 4); ctx.fill();
      for (let i = 0; i < 70; i++) { const x = r() * W, th = H * (0.01 + r() * 0.035); if (r() < 0.4) continue;
        ctx.beginPath(); ctx.moveTo(x, wy - th); ctx.lineTo(x - th * 0.22, wy + 2); ctx.lineTo(x + th * 0.22, wy + 2); ctx.fill(); }
    }
    grain(ctx, W, H, r, 0.12);
  }
  function artGeo(ctx, W, H, r) {
    const pals = [['#1f2a44', '#c8553d', '#f2d0a4', '#588b8b', '#f28f3b', '#ffd5c2'], ['#0b132b', '#3a506b', '#5bc0be', '#e0a458', '#f4e9cd', '#a63d40'],
      ['#2b2d42', '#8d99ae', '#edf2f4', '#ef233c', '#d6a62e', '#3d5a80'], ['#22223b', '#4a4e69', '#9a8c98', '#c9ada7', '#f2e9e4', '#bc4b51'], ['#132a13', '#31572c', '#ecf39e', '#e09f3e', '#9e2a2b', '#f5ebe0']];
    const P = pals[(r() * pals.length) | 0], pick = () => P[(r() * P.length) | 0];
    ctx.fillStyle = P[4]; ctx.fillRect(0, 0, W, H);
    const cells = [];
    (function split(x, y, w, h, d) {
      if (d > 4 || (w * h < W * H / 40 && r() < 0.6) || w < W / 10 || h < H / 12) { cells.push([x, y, w, h]); return; }
      if (w > h * (0.7 + r() * 0.6)) { const k = w * (0.3 + r() * 0.4); split(x, y, k, h, d + 1); split(x + k, y, w - k, h, d + 1); }
      else { const k = h * (0.3 + r() * 0.4); split(x, y, w, k, d + 1); split(x, y + k, w, h - k, d + 1); }
    })(0, 0, W, H, 0);
    for (const [x, y, w, h] of cells) {
      ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
      let c1 = pick(), c2 = pick(); while (c2 === c1) c2 = pick();
      ctx.fillStyle = c1; ctx.fillRect(x, y, w, h);
      const m = (r() * 7) | 0, mn = Math.min(w, h);
      ctx.fillStyle = c2; ctx.strokeStyle = c2;
      if (m === 0) { const cx = r() < 0.5 ? x : x + w, cy = r() < 0.5 ? y : y + h; for (let k = 6; k > 0; k--) { ctx.fillStyle = k % 2 ? c2 : c1; ctx.beginPath(); ctx.arc(cx, cy, mn * k / 5, 0, 7); ctx.fill(); } }
      else if (m === 1) { ctx.beginPath(); ctx.arc(x + w / 2, y + h / 2, mn * 0.38, 0, 7); ctx.fill(); ctx.fillStyle = pick(); ctx.beginPath(); ctx.arc(x + w / 2, y + h / 2, mn * 0.38, -Math.PI / 2, Math.PI / 2); ctx.fill(); }
      else if (m === 2) { const k = 6 + ((r() * 8) | 0); ctx.lineWidth = Math.max(w, h) / k / 2; for (let i = -k; i < 2 * k; i++) { ctx.beginPath(); ctx.moveTo(x + i * w / k, y); ctx.lineTo(x + i * w / k + h, y + h); ctx.stroke(); } }
      else if (m === 3) { ctx.beginPath(); ctx.moveTo(x, y + h); ctx.lineTo(x + w * r(), y); ctx.lineTo(x + w, y + h); ctx.fill(); ctx.fillStyle = pick(); ctx.beginPath(); ctx.arc(x + w * 0.7, y + h * 0.3, mn * 0.15, 0, 7); ctx.fill(); }
      else if (m === 4) { const g = mn / 6; for (let yy = y + g / 2; yy < y + h; yy += g) for (let xx = x + g / 2; xx < x + w; xx += g) { ctx.beginPath(); ctx.arc(xx, yy, g * 0.28, 0, 7); ctx.fill(); } }
      else if (m === 5) { ctx.beginPath(); ctx.arc(x + w / 2, y + h, Math.min(w / 2, h), Math.PI, 0); ctx.fill(); ctx.fillStyle = pick(); ctx.beginPath(); ctx.arc(x + w / 2, y + h, Math.min(w / 2, h) * 0.55, Math.PI, 0); ctx.fill(); }
      else { const g = ctx.createLinearGradient(x, y, x + w, y + h); g.addColorStop(0, c1); g.addColorStop(1, c2); ctx.fillStyle = g; ctx.fillRect(x, y, w, h);
        ctx.fillStyle = pick(); ctx.fillRect(x + w * 0.2, y + h * 0.2, w * 0.6, h * 0.6 * r()); }
      ctx.restore();
      ctx.strokeStyle = P[0]; ctx.lineWidth = Math.max(3, W / 220); ctx.strokeRect(x, y, w, h);
    }
    grain(ctx, W, H, r, 0.16);
  }
  function artGlass(ctx, W, H, r, n) {
    const k = Math.max(70, Math.min(320, Math.round(n * 1.4))), pts = [];
    const cx = W * (0.3 + r() * 0.4), cy = H * (0.3 + r() * 0.3), h0 = r() * 360;
    for (let i = 0; i < k; i++) {
      if (i < k * 0.35) { const a = r() * Math.PI * 2, d = Math.sqrt(r()) * Math.min(W, H) * 0.32; pts.push([cx + Math.cos(a) * d, cy + Math.sin(a) * d]); }
      else pts.push([r() * W, r() * H]);
    }
    ctx.fillStyle = '#0d0a10'; ctx.fillRect(0, 0, W, H);
    const lw = Math.max(3, W / 170);
    for (let i = 0; i < k; i++) {
      let poly = [[0, 0], [W, 0], [W, H], [0, H]];
      const [px, py] = pts[i];
      for (let j = 0; j < k && poly.length; j++) {
        if (j === i) continue;
        const [qx, qy] = pts[j], mx = (px + qx) / 2, my = (py + qy) / 2, nx = qx - px, ny = qy - py;
        if ((mx - px) * (mx - px) + (my - py) * (my - py) > 0.6 * W * W) continue;
        const np = [];
        for (let a = 0; a < poly.length; a++) {
          const A = poly[a], B = poly[(a + 1) % poly.length];
          const da = (A[0] - mx) * nx + (A[1] - my) * ny, db = (B[0] - mx) * nx + (B[1] - my) * ny;
          if (da <= 0) np.push(A);
          if ((da <= 0) !== (db <= 0)) { const t = da / (da - db); np.push([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t]); }
        }
        poly = np;
      }
      if (poly.length < 3) continue;
      const d = Math.hypot(px - cx, py - cy) / Math.max(W, H), ang = Math.atan2(py - cy, px - cx);
      const inner = d < 0.26, hue = inner ? h0 + Math.round(ang / (Math.PI / 4)) * 45 : h0 + 180 + (py / H) * 70 + (r() - 0.5) * 40;
      const sat = 55 + r() * 35, lit = inner ? 40 + r() * 20 : 22 + r() * 30;
      const g = ctx.createRadialGradient(px, py, 0, px, py, W / 7);
      g.addColorStop(0, hsl(hue, sat, lit + 22)); g.addColorStop(1, hsl(hue, sat, lit - 8));
      ctx.beginPath(); poly.forEach((q, a) => (a ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath();
      ctx.fillStyle = g; ctx.fill();
      ctx.lineJoin = 'round'; ctx.lineWidth = lw; ctx.strokeStyle = '#141015'; ctx.stroke();
      ctx.lineWidth = lw * 0.3; ctx.strokeStyle = 'rgba(255,255,255,.12)'; ctx.stroke();
    }
    ctx.strokeStyle = '#141015'; ctx.lineWidth = lw * 2;
    ctx.beginPath(); ctx.arc(cx, cy, Math.min(W, H) * 0.34, 0, 7); ctx.stroke();
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 4; i++) { const x = W * r(); const g = ctx.createLinearGradient(x, 0, x + W * 0.3, H); g.addColorStop(0, 'rgba(255,240,200,.10)'); g.addColorStop(1, 'rgba(255,240,200,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + W * 0.1, 0); ctx.lineTo(x + W * 0.5, H); ctx.lineTo(x + W * 0.25, H); ctx.fill(); }
    ctx.restore();
    grain(ctx, W, H, r, 0.14);
  }
  function artStars(ctx, W, H, r) {
    const bg = ctx.createLinearGradient(0, 0, W, H); bg.addColorStop(0, '#05040d'); bg.addColorStop(1, '#0c0b1f');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
    const h1 = r() * 360, h2 = h1 + 120 + r() * 120;
    // nebula along a curve
    const ax = r() * W, ay = 0, bx = r() * W, by = H, mx = r() * W, my = H * r();
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 160; i++) {
      const t = r(), x = (1 - t) * (1 - t) * ax + 2 * t * (1 - t) * mx + t * t * bx + (r() - 0.5) * W * 0.5, y = (1 - t) * (1 - t) * ay + 2 * t * (1 - t) * my + t * t * by + (r() - 0.5) * H * 0.2;
      const rr = W * (0.05 + r() * 0.22), g = ctx.createRadialGradient(x, y, 0, x, y, rr), hu = r() < 0.5 ? h1 : h2;
      g.addColorStop(0, hsl(hu + r() * 30, 80, 50, 0.04 + r() * 0.09)); g.addColorStop(1, hsl(hu, 80, 40, 0));
      ctx.fillStyle = g; ctx.fillRect(x - rr, y - rr, rr * 2, rr * 2);
    }
    ctx.restore();
    for (let i = 0; i < 60; i++) { // dust lanes
      const x = r() * W, y = r() * H, rr = W * (0.03 + r() * 0.1), g = ctx.createRadialGradient(x, y, 0, x, y, rr);
      g.addColorStop(0, 'rgba(3,2,8,' + (0.2 + r() * 0.3).toFixed(2) + ')'); g.addColorStop(1, 'rgba(3,2,8,0)'); ctx.fillStyle = g; ctx.fillRect(x - rr, y - rr, rr * 2, rr * 2);
    }
    const N = W * H / 300;
    for (let i = 0; i < N; i++) { const b = Math.pow(r(), 3); ctx.fillStyle = hsl(r() < 0.5 ? 220 : 40, 60, 70 + b * 30, 0.3 + b * 0.7); const s = 0.6 + b * 2; ctx.fillRect(r() * W, r() * H, s, s); }
    for (let i = 0; i < 26; i++) { const x = r() * W, y = r() * H, s = W * (0.006 + r() * 0.012), hu = r() < 0.5 ? 210 : 30;
      const g = ctx.createRadialGradient(x, y, 0, x, y, s * 5); g.addColorStop(0, hsl(hu, 80, 95, 1)); g.addColorStop(0.15, hsl(hu, 80, 75, 0.6)); g.addColorStop(1, hsl(hu, 80, 60, 0));
      ctx.fillStyle = g; ctx.fillRect(x - s * 5, y - s * 5, s * 10, s * 10);
      ctx.strokeStyle = hsl(hu, 80, 90, 0.5); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x - s * 8, y); ctx.lineTo(x + s * 8, y); ctx.moveTo(x, y - s * 8); ctx.lineTo(x, y + s * 8); ctx.stroke(); }
    if (r() < 0.75) { // planet
      const pr = W * (0.12 + r() * 0.16), px = W * (0.15 + r() * 0.7), py = H * (0.55 + r() * 0.35), hu = r() * 360;
      ctx.save(); ctx.beginPath(); ctx.arc(px, py, pr, 0, 7); ctx.clip();
      const g = ctx.createRadialGradient(px - pr * 0.4, py - pr * 0.4, pr * 0.1, px, py, pr); g.addColorStop(0, hsl(hu, 50, 62)); g.addColorStop(1, hsl(hu + 20, 50, 12));
      ctx.fillStyle = g; ctx.fillRect(px - pr, py - pr, pr * 2, pr * 2);
      for (let i = 0; i < 14; i++) { ctx.fillStyle = hsl(hu + (r() - 0.5) * 40, 45, 30 + r() * 30, 0.25); ctx.fillRect(px - pr, py - pr + r() * pr * 2, pr * 2, pr * (0.03 + r() * 0.1)); }
      const sh = ctx.createLinearGradient(px - pr, py - pr, px + pr, py + pr); sh.addColorStop(0.45, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,0,.85)'); ctx.fillStyle = sh; ctx.fillRect(px - pr, py - pr, pr * 2, pr * 2);
      ctx.restore();
      ctx.strokeStyle = hsl(hu + 30, 40, 75, 0.55); ctx.lineWidth = pr * 0.05;
      ctx.beginPath(); ctx.ellipse(px, py, pr * 1.7, pr * 0.32, -0.35, Math.PI * 0.95, Math.PI * 2.05); ctx.stroke();
    }
    grain(ctx, W, H, r, 0.08);
  }
  function artCity(ctx, W, H, r) {
    const h0 = 200 + r() * 60, horizon = H * 0.66;
    const sky = ctx.createLinearGradient(0, 0, 0, horizon);
    sky.addColorStop(0, hsl(h0 + 20, 60, 8)); sky.addColorStop(0.6, hsl(h0 + 70, 45, 22)); sky.addColorStop(1, hsl(20 + r() * 20, 80, 50));
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, horizon);
    for (let i = 0; i < W * H / 3000; i++) { ctx.fillStyle = 'rgba(255,255,255,' + (r() * 0.6).toFixed(2) + ')'; ctx.fillRect(r() * W, r() * horizon * 0.5, 1.4, 1.4); }
    const mx = W * (0.15 + r() * 0.7), my = H * (0.12 + r() * 0.15), mr = W * 0.05;
    const mg = ctx.createRadialGradient(mx, my, 0, mx, my, mr * 6); mg.addColorStop(0, 'rgba(255,240,210,.35)'); mg.addColorStop(1, 'rgba(255,240,210,0)');
    ctx.fillStyle = mg; ctx.fillRect(0, 0, W, horizon);
    ctx.fillStyle = '#f4ead2'; ctx.beginPath(); ctx.arc(mx, my, mr, 0, 7); ctx.fill();
    ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.beginPath(); ctx.arc(mx + mr * 0.3, my - mr * 0.2, mr * 0.25, 0, 7); ctx.arc(mx - mr * 0.35, my + mr * 0.3, mr * 0.15, 0, 7); ctx.fill();
    for (let i = 0; i < 10; i++) { ctx.fillStyle = hsl(h0 + 90, 30, 30 + r() * 20, 0.25); ctx.beginPath(); ctx.ellipse(r() * W, horizon * (0.2 + r() * 0.6), W * (0.1 + r() * 0.3), H * 0.01, 0, 0, 7); ctx.fill(); }
    const winCols = ['#ffd27a', '#ffb45c', '#fff1c4', '#9fd8ff', '#ff8f6b'];
    for (let layer = 0; layer < 3; layer++) {
      const lit = [28, 16, 7][layer], hMax = H * [0.32, 0.4, 0.46][layer];
      let x = -r() * W * 0.05;
      while (x < W) {
        const bw = W * (0.05 + r() * 0.09) * (1 + layer * 0.25), bh = hMax * (0.35 + r() * 0.65), top = horizon - bh;
        ctx.fillStyle = hsl(h0 + 20, 25, lit + r() * 4);
        ctx.fillRect(x, top, bw, bh + 2);
        const st = r();
        if (st < 0.3) ctx.fillRect(x + bw * 0.2, top - bh * 0.08, bw * 0.6, bh * 0.08 + 1);
        else if (st < 0.45) { ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x + bw / 2, top - bw * 0.5); ctx.lineTo(x + bw, top); ctx.fill(); }
        if (r() < 0.35) { ctx.fillRect(x + bw * 0.48, top - bh * 0.18, Math.max(1.5, bw * 0.03), bh * 0.18); ctx.fillStyle = '#ff4040'; ctx.fillRect(x + bw * 0.47, top - bh * 0.19, 3, 3); }
        if (layer > 0) {
          const ww = Math.max(2, bw / (6 + ((r() * 5) | 0))), wh = ww * 1.3, wc = winCols[(r() * winCols.length) | 0], dens = 0.15 + r() * 0.5;
          for (let yy = top + wh; yy < horizon - wh; yy += wh * 1.9) for (let xx = x + ww * 0.6; xx < x + bw - ww; xx += ww * 1.7)
            if (r() < dens) { ctx.fillStyle = wc; ctx.globalAlpha = 0.5 + r() * 0.5; ctx.fillRect(xx, yy, ww, wh); }
          ctx.globalAlpha = 1;
        }
        x += bw + (layer === 2 ? -bw * 0.1 : W * 0.005 * r());
      }
      const fg = ctx.createLinearGradient(0, horizon - hMax * 0.3, 0, horizon); fg.addColorStop(0, hsl(25, 70, 50, 0)); fg.addColorStop(1, hsl(25, 70, 50, 0.12 * (2 - layer)));
      ctx.fillStyle = fg; ctx.fillRect(0, horizon - hMax * 0.3, W, hMax * 0.3);
    }
    // water reflection: flipped strips with ripple
    const rh = H - horizon;
    for (let y = 0; y < rh; y += 3) {
      const sy = horizon - y * 1.0 - 3, off = Math.sin(y * 0.15 + r()) * (2 + y * 0.04);
      if (sy < 0) break;
      ctx.drawImage(ctx.canvas, 0, sy, W, 3, off, horizon + y, W, 3);
    }
    const wg = ctx.createLinearGradient(0, horizon, 0, H); wg.addColorStop(0, 'rgba(8,12,30,.35)'); wg.addColorStop(1, 'rgba(4,6,16,.85)');
    ctx.fillStyle = wg; ctx.fillRect(0, horizon, W, rh);
    for (let i = 0; i < 120; i++) { ctx.fillStyle = 'rgba(255,220,160,' + (r() * 0.25).toFixed(2) + ')'; ctx.fillRect(r() * W, horizon + r() * rh, W * (0.01 + r() * 0.05), 1.2); }
    grain(ctx, W, H, r, 0.1);
  }
  function makeArt(kind, W, H, sd, n) {
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const ctx = c.getContext('2d'), r = prng(sd);
    ({ mount: artMount, geo: artGeo, glass: artGlass, stars: artStars, city: artCity }[kind] || artMount)(ctx, W, H, r, n);
    return c;
  }

  const fmtT = (s) => { s = Math.floor(s); const h = (s / 3600) | 0, m = ((s % 3600) / 60) | 0, x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };

  const def = {
    id: 'jigsaw', name: '직소 퍼즐', tag: '조각 그림 맞추기', cat: '보드',
    blurb: '흩어진 조각을 끌어다 그림을 완성해요. 무작위로 그려지는 그림이나 내 사진으로 24~300조각까지.',
    tint: '#3b2b52',
    icon: '<path d="M8 12h12a5 5 0 1 1 8 0h12v12a5 5 0 1 0 0 8v12H28a5 5 0 1 0-8 0H8V32a5 5 0 1 1 0-8z" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"/><path d="M44 30h4v16H32v-4" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" opacity=".6"/>',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, noAI: true, hidden: false, aiDelay: 260,
    options: [
      { id: 'src', label: '그림', tip: '어떤 그림으로 맞출지.', choices: [{ v: 'gen', label: '무작위 생성' }, { v: 'photo', label: '내 사진', tip: '내 기기의 사진을 골라 조각내요.' }, { v: 'day', label: '📅 오늘의 퍼즐', tip: '날마다 모두 같은 퍼즐.' }], def: 'gen' },
      { id: 'art', label: '그림 종류', choices: [{ v: 'rand', label: '무작위' }, { v: 'mount', label: '산과 노을' }, { v: 'geo', label: '기하 추상' }, { v: 'glass', label: '스테인드글라스' }, { v: 'stars', label: '별바다' }, { v: 'city', label: '밤의 도시' }], def: 'rand' },
      { id: 'n', label: '조각 수', choices: [{ v: 24, label: '24' }, { v: 48, label: '48' }, { v: 96, label: '96' }, { v: 150, label: '150' }, { v: 300, label: '300' }], def: 48 },
      { id: 'rot', label: '조각 회전', tip: '켜면 조각이 돌아가 있어 돌려 맞춰야 해요.', choices: [{ v: 0, label: '끔' }, { v: 1, label: '켬' }], def: 0 },
    ],
    controls: [
      { id: 'zin', label: '확대', keys: ['Equal', 'NumpadAdd'], pad: ['rb'] },
      { id: 'zout', label: '축소', keys: ['Minus', 'NumpadSubtract'], pad: ['lb'] },
      { id: 'fit', label: '전체 보기', keys: ['KeyF'], pad: ['y'] },
      { id: 'edge', label: '테두리만', keys: ['KeyE'], pad: ['x'] },
      { id: 'sort', label: '조각 정리', keys: ['KeyS'], pad: ['b'] },
      { id: 'prev', label: '미리보기', keys: ['KeyP'], pad: ['back'] },
    ],
    quick: [
      '목표: 흩어진 조각을 모두 맞춰 그림 한 장을 완성하기!',
      '조각을 끌어다 놓아요. 맞는 자리나 맞는 이웃 조각 가까이 놓으면 「착」 붙어요. 붙은 조각은 함께 움직여요.',
      '두 손가락으로 확대·이동, 빈 곳을 끌면 화면 이동. 빨리 끝낼수록 좋은 기록이에요.',
    ],
    rules: [
      { h: '목표', p: ['가운데 판(액자) 안에 모든 조각을 제자리에 맞추면 완성이에요. 걸린 시간이 기록돼요.'] },
      { h: '그림으로 보기', fig: [{ svg: "<svg viewBox=\"0 0 340 120\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"120\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"20\" y=\"14\" width=\"150\" height=\"92\" rx=\"4\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"22\" y=\"16\" width=\"48\" height=\"44\" rx=\"2\" fill=\"#4a8fe0\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"72\" y=\"16\" width=\"48\" height=\"44\" rx=\"2\" fill=\"#4cc27a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"22\" y=\"62\" width=\"48\" height=\"42\" rx=\"2\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"72\" y=\"62\" width=\"48\" height=\"42\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><path d=\"M240 70 Q170 110 100 86\" stroke=\"#e3ae45\" stroke-width=\"2.5\" fill=\"none\" stroke-dasharray=\"5 4\"/><rect x=\"220\" y=\"46\" width=\"48\" height=\"42\" rx=\"3\" fill=\"#e0a94a\" stroke=\"#111\" stroke-width=\"1\"/><text x=\"290\" y=\"20\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">제자리 근처에</text><text x=\"290\" y=\"36\" font-size=\"11\" fill=\"#9fd59f\" text-anchor=\"middle\" font-weight=\"400\">놓으면 착!</text><text x=\"250\" y=\"112\" font-size=\"11\" fill=\"#b9b0a0\" text-anchor=\"middle\" font-weight=\"400\">맞는 이웃 조각끼리도 붙어요</text></svg>", cap: "조각을 끌어 제자리에" }] },
      { h: '조각 옮기기', p: [
        '조각을 손가락으로 끌어요. 판의 제자리 가까이 놓으면 판에 고정되고, 옆에 이어질 조각 가까이 놓으면 서로 붙어요.',
        '붙은 조각 덩어리는 한꺼번에 움직여요. 판에 고정된 조각은 더 이상 움직이지 않아요.',
        '조각 회전을 켜면 조각이 돌아간 채로 흩어져요. 조각을 「톡」 누르면 90° 돌아가요. 똑바로 서야 붙어요.',
      ] },
      { h: '도움 버튼', p: [
        '👁 미리보기: 완성 그림을 보여 줘요. 판에 흐리게 깔아 둘 수도 있어요.',
        '▢ 테두리: 가장자리 조각(평평한 변이 있는 조각)만 보여 줘요. 테두리부터 맞추면 쉬워요.',
        '▤ 정리: 흩어진 낱개 조각을 판 둘레에 줄 맞춰 늘어놓아요(테두리 조각 먼저).',
        '⤢ 전체: 모든 조각이 보이게 화면을 맞춰요.',
      ] },
      { h: '그림', p: [
        '무작위 생성: 산과 노을·기하 추상·스테인드글라스·별바다·밤의 도시 중에서 매번 새 그림이 그려져요.',
        '내 사진: 폰의 사진(갤러리·카메라)을 골라 퍼즐로 만들어요. 사진은 이 기기 안에서만 쓰이고 어디에도 올라가지 않아요.',
      ] },
      { h: '오늘의 퍼즐', p: ['「그림」에서 「📅 오늘의 퍼즐」을 고르면 매일 하나씩 정해진 그림 96조각(회전 없음)을 맞춰요. 날짜가 같으면 누구나 같은 그림·같은 조각이에요.', '빨리 맞출수록 좋은 기록. 하루씩 이어서 맞추면 🔥 연속 일수가 올라가고, 「📋 공유」로 그림 없이 결과를 복사할 수 있어요. 조각 수별 최고 기록과는 따로예요.'] },
      { h: '저장·기록', p: [
        '맞추던 퍼즐은 자동 저장돼요. 같은 그림·조각 수·회전 설정으로 다시 열면 「이어 하기」를 고를 수 있어요.',
        '조각 수(와 회전)마다 가장 빠른 시간이 최고 기록으로 남아요.',
      ] },
      { h: '조작(PC)', p: ['마우스로 끌기, 휠로 확대. = / - 확대·축소 · F 전체 · E 테두리 · S 정리 · P 미리보기.'] },
    ],
    tutorial: [
      { text: '조각을 끌어서 가운데 판의 제자리나 이웃 조각 가까이에 놓으면 착 붙어요.' },
      { text: '두 손가락으로 벌리면 확대, 빈 곳을 끌면 화면이 움직여요.' },
      { text: '막히면 아래 버튼: 미리보기 · 테두리 조각만 · 조각 정리 · 전체 보기.', sel: '.jg-bar' },
    ],

    init(players, opts) {
      opts = opts || {};
      const n = GRID[opts.n] ? +opts.n : 48;
      let art = opts.art && ARTS.includes(opts.art) ? opts.art : ARTS[(Math.random() * ARTS.length) | 0];
      if (opts.src === 'day') { const dy = opts._day || DAILY.today(), c = dailyCfg(dy); return { n: c.n, rot: 0, src: 'gen', dy, art: c.art, sd: c.sd, pl: 0, end: 0, sec: 0, last: { id: 0 } }; }
      return { n, rot: opts.rot ? 1 : 0, src: opts.src === 'photo' ? 'photo' : 'gen', art, sd: (Math.random() * 2147483647) | 0, pl: 0, end: 0, sec: 0, last: { id: 0 } };
    },
    actor(s) { return s.end ? null : 0; },
    apply(s, seat, a) {
      if (!a || s.end) throw new Error('bad');
      if (a.t === 'auto') { // demo/AI: one piece flies home
        s.pl++; s.last = { id: s.last.id + 1, t: 'auto' };
        if (s.pl >= s.n) { s.end = 1; s.sec = Math.round(s.n * 4.2); }
      } else if (a.t === 'win') {
        s.end = 1; s.sec = Math.max(0, Math.round(+a.sec || 0)); s.pl = s.n; s.last = { id: s.last.id + 1, t: 'win' };
      } else throw new Error('unknown');
      return s;
    },
    ai(s) { return { t: 'auto' }; },
    result(s) {
      if (!s.end) return null;
      return { winners: [0], title: s.dy ? '오늘의 퍼즐 ' + DAILY.md(s.dy) + ' 완성!' : '퍼즐 완성!', text: s.n + '조각' + (s.rot ? '(회전)' : '') + ' · ' + fmtT(s.sec),
        stats: [{ label: '조각', value: s.n + '조각' + (s.rot ? ' · 회전' : '') }, { label: '그림', value: ART_NAME[s.src === 'photo' ? 'photo' : s.art] || '' }, { label: '걸린 시간', value: fmtT(s.sec) }, { label: '조각당', value: (s.sec / Math.max(1, s.n)).toFixed(1) + '초' }] };
    },

    mount(root, api) {
      const cvs = U.canvas(root), cv = cvs.cv, ctx = cvs.ctx;
      const SP = () => (L.debug && L.debug.speed) || 1;
      const isAI = () => !!(api.players[0] && api.players[0].ai);
      let S0 = null, M = null, cut = null, art = null, bmp = [], meta = null; // meta: {src,n,rot,art,sd,cols,rows,ppp}
      let cam = { x: 0, y: 0, z: 1 }, elapsed = 0, edgeOnly = false, ghost = false, dirty = true, hudT = 0, saveT = 0;
      let fly = null, celebrate = null, parts = [], finished = false, ready = false, flashes = [];
      const TOP = 44, BOT = 74;
      const view = () => ({ x: 0, y: TOP, w: cvs.w, h: Math.max(80, cvs.h - TOP - BOT) });

      /* ---------- DOM: bar + overlays ---------- */
      const bar = L.h('div', { class: 'jg-bar', style: { position: 'absolute', left: '0', right: '0', bottom: '0', display: 'flex', gap: '6px', padding: '8px 8px 10px', zIndex: 5 } });
      const mkBtn = (ic, lab, fn) => {
        const b = L.h('button', { class: 'btn sm', style: { flex: '1 1 0', minWidth: '0', minHeight: '54px', padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1px', lineHeight: '1.1' }, onclick: (e) => { e.stopPropagation(); fn(); } });
        const t = L.h('span', { style: { fontSize: '11.5px', whiteSpace: 'nowrap' }, text: lab });
        b.append(L.h('span', { style: { fontSize: '18px' }, text: ic }), t); bar.append(b); return { b, t };
      };
      const bPrev = mkBtn('👁', '미리보기', () => openPreview());
      const bEdge = mkBtn('▢', '테두리', () => toggleEdge());
      const bSort = mkBtn('▤', '정리', () => doSort());
      const bFit = mkBtn('⤢', '전체', () => { fitAll(); dirty = true; });
      bPrev.b.dataset.action = 'prev'; bEdge.b.dataset.action = 'edge'; bSort.b.dataset.action = 'sort'; bFit.b.dataset.action = 'fit';
      root.append(bar);
      let ov = null;
      function closeOv() { if (ov) { ov.remove(); ov = null; } }
      function panel(children, closable) {
        closeOv();
        ov = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', background: 'rgba(10,8,15,.66)' }, onpointerdown: (e) => { if (closable && e.target === ov) closeOv(); } });
        const sh = L.h('div', { class: 'sheet', style: { maxHeight: '90%', gap: '12px', width: '100%', maxWidth: '420px' } });
        children.forEach((c) => c && sh.append(c));
        ov.append(sh); root.append(ov);
        return sh;
      }
      const bigBtn = (text, fn, cls) => L.h('button', { class: 'btn' + (cls ? ' ' + cls : ''), style: { minHeight: '52px', fontSize: '16px' }, text, onclick: fn });
      function refreshBar() {
        const on = ready && !finished;
        [bPrev, bEdge, bSort, bFit].forEach((q) => { q.b.disabled = !on; q.b.style.opacity = on ? '1' : '.45'; });
        bEdge.b.style.outline = edgeOnly ? '2px solid var(--brass)' : 'none'; bEdge.t.textContent = edgeOnly ? '테두리만' : '테두리';
      }
      function openPreview() {
        if (!art) return;
        const w = Math.min(cvs.w - 64, 388), hh = Math.min(cvs.h * 0.5, w * art.height / art.width), ww = hh * art.width / art.height;
        const c = L.h('canvas', { style: { width: ww + 'px', height: hh + 'px', alignSelf: 'center', borderRadius: '6px', boxShadow: '0 6px 20px rgba(0,0,0,.5)' } });
        c.width = Math.round(ww * 2); c.height = Math.round(hh * 2); c.getContext('2d').drawImage(art, 0, 0, c.width, c.height);
        panel([L.h('h2', { text: '완성 그림' }), L.h('p', { class: 'muted', style: { margin: 0 }, text: (ART_NAME[meta.art] || '') + ' · ' + meta.cols + '×' + meta.rows + ' = ' + meta.cols * meta.rows + '조각' }), c,
          bigBtn(ghost ? '판에 흐리게 깔기: 켬' : '판에 흐리게 깔기: 끔', () => { ghost = !ghost; dirty = true; closeOv(); }, ghost ? 'primary' : ''),
          bigBtn('닫기', closeOv, 'ghost')], true);
      }
      function toggleEdge() { edgeOnly = !edgeOnly; dirty = true; refreshBar(); api.sfx('tick'); }
      function doSort() { if (!M) return; sortTray(M, view().w / view().h); api.sfx('whoosh'); dirty = true; save(); }

      /* ---------- build ---------- */
      function build(m, savedGs, savedT, imgCanvas) {
        meta = m; cut = makeCut(m.cols, m.rows, m.sd);
        const W = m.cols * m.ppp, H = m.rows * m.ppp;
        if (m.src === 'photo') {
          art = document.createElement('canvas'); art.width = W; art.height = H;
          const iw = imgCanvas.width, ih = imgCanvas.height, a = m.cols / m.rows;
          let sw = iw, sh = iw / a; if (sh > ih) { sh = ih; sw = ih * a; }
          art.getContext('2d').drawImage(imgCanvas, (iw - sw) / 2, (ih - sh) / 2, sw, sh, 0, 0, W, H);
        } else art = makeArt(m.art, W, H, m.sd, m.cols * m.rows);
        // piece bitmaps (with tab margin + baked shadow)
        const k = m.ppp / S, mg = Math.ceil(S * 0.42 * k), bs = Math.ceil(m.ppp + mg * 2);
        bmp = [];
        for (let id = 0; id < m.cols * m.rows; id++) {
          const c = document.createElement('canvas'); c.width = c.height = bs;
          const x = c.getContext('2d'), px = (id % m.cols) * S, py = ((id / m.cols) | 0) * S, ol = pieceOutline(cut, id);
          x.setTransform(k, 0, 0, k, mg - px * k, mg - py * k);
          const path = () => { x.beginPath(); x.moveTo(px, py); for (const q of ol) if (q[0] === 'L') x.lineTo(q[1], q[2]); else x.bezierCurveTo(q[1], q[2], q[3], q[4], q[5], q[6]); x.closePath(); };
          path(); x.save(); x.shadowColor = 'rgba(0,0,0,.45)'; x.shadowBlur = 4; x.shadowOffsetX = 1.5; x.shadowOffsetY = 2.5; x.fillStyle = '#000'; x.fill(); x.restore();
          x.save(); path(); x.clip();
          x.setTransform(1, 0, 0, 1, 0, 0); x.drawImage(art, -px * k + mg, -py * k + mg);
          x.setTransform(k, 0, 0, k, mg - px * k, mg - py * k);
          x.lineWidth = 2.4 / 1; x.strokeStyle = 'rgba(255,255,255,.28)'; x.translate(1.2, 1.2); path(); x.stroke();
          x.translate(-2.4, -2.4); x.strokeStyle = 'rgba(0,0,0,.35)'; path(); x.stroke(); x.restore();
          x.setTransform(k, 0, 0, k, mg - px * k, mg - py * k); path(); x.lineWidth = 0.8; x.strokeStyle = 'rgba(0,0,0,.45)'; x.stroke();
          bmp.push(c);
        }
        meta.mg = mg / k; meta.bs = bs / k; // world units
        if (savedGs) M = { cut, gs: savedGs };
        else M = newModel(cut, m.rot, view().w / view().h, prng(m.sd ^ 0x9e3779b9));
        elapsed = savedT || 0; ready = true; finished = false; fitAll(); dirty = true; refreshBar(); save();
        if (solvedM(M)) finish(true);
      }
      function ppp(cols) { return Math.max(90, Math.min(180, Math.floor(1500 / cols))); }

      /* ---------- save / resume ---------- */
      function save() {
        if (!M || isAI() || finished) return;
        const gs = M.gs.map((g) => ({ x: Math.round(g.x), y: Math.round(g.y), r: g.r, lk: g.lk, p: g.p }));
        lsSet(KEY, { v: 1, dy: meta.dy || 0, src: meta.src, n: meta.n, rot: meta.rot, art: meta.art, sd: meta.sd, cols: meta.cols, rows: meta.rows, ppp: meta.ppp, t: Math.round(elapsed), gs, pc: placedCount(M) });
      }
      function loadPhoto(cb) {
        const d = lsGet(PKEY); if (!d || !d.u) return cb(null);
        const im = new Image(); im.onload = () => cb(im); im.onerror = () => cb(null); im.src = d.u;
      }
      let memPhoto = null;
      function startFresh() {
        const portrait = view().w < view().h;
        if (S0.src === 'photo') return askPhoto();
        const [c, r] = gridFor(S0.n, S0.dy ? true : portrait);
        build({ src: 'gen', dy: S0.dy || 0, n: S0.n, rot: S0.rot, art: S0.art, sd: S0.sd, cols: c, rows: r, ppp: ppp(c) });
      }
      function startWithPhoto(img) {
        const [c, r] = gridFor(S0.n, true, img.width / img.height);
        build({ src: 'photo', n: S0.n, rot: S0.rot, art: 'photo', sd: S0.sd, cols: c, rows: r, ppp: ppp(c) }, null, 0, img);
      }
      const fileIn = L.h('input', { type: 'file', accept: 'image/*', style: { display: 'none' } });
      root.append(fileIn);
      fileIn.addEventListener('change', () => {
        const f = fileIn.files && fileIn.files[0]; fileIn.value = '';
        if (!f) return;
        const url = URL.createObjectURL(f), im = new Image();
        im.onload = () => {
          URL.revokeObjectURL(url);
          const k = Math.min(1, 1600 / Math.max(im.width, im.height)), c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(im.width * k)); c.height = Math.max(1, Math.round(im.height * k));
          c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
          memPhoto = c;
          let ok = false;
          for (const q of [0.82, 0.7, 0.55]) { try { const u = c.toDataURL('image/jpeg', q); if (u.length < 1800000 && lsSet(PKEY, { u })) { ok = true; break; } } catch (e) {} }
          if (!ok) { lsDel(PKEY); api.toast('사진이 커서 이어 하기용으로는 저장하지 못했어요(지금 판은 그대로 돼요)'); }
          closeOv(); startWithPhoto(c);
        };
        im.onerror = () => { URL.revokeObjectURL(url); api.toast('이 사진은 열 수 없어요'); };
        im.src = url;
      });
      function askPhoto() {
        const kids = [L.h('h2', { text: '내 사진으로 퍼즐' }), L.h('p', { class: 'muted', style: { margin: 0 }, text: '사진은 이 기기 안에서만 쓰이고 어디에도 올라가지 않아요.' }),
          bigBtn('📷 사진 고르기', () => fileIn.click(), 'primary')];
        const d = lsGet(PKEY);
        if (d && d.u) kids.push(bigBtn('지난번 사진 다시 쓰기', () => loadPhoto((im) => { if (im) { closeOv(); startWithPhoto(im); } else api.toast('저장된 사진을 열 수 없어요'); })));
        kids.push(bigBtn('무작위 그림으로 하기', () => { closeOv(); S0 = Object.assign({}, S0, { src: 'gen' }); startFresh(); }, 'ghost'));
        panel(kids, false);
      }
      function begin() {
        if (isAI()) { S0 = Object.assign({}, S0, { src: 'gen' }); return startFresh(); }
        const sv = lsGet(KEY);
        if (S0.dy) return dailyIntro(sv && sv.v === 1 && sv.dy === S0.dy && sv.sd === S0.sd && Array.isArray(sv.gs) && sv.cols * sv.rows === sv.gs.reduce((a, g) => a + g.p.length, 0) ? sv : null);
        const ok = sv && sv.v === 1 && !sv.dy && sv.n === S0.n && sv.rot === S0.rot && sv.src === S0.src && Array.isArray(sv.gs) && sv.cols * sv.rows === sv.gs.reduce((a, g) => a + g.p.length, 0);
        if (!ok) return startFresh();
        const resume = () => {
          closeOv();
          if (sv.src === 'photo') loadPhoto((im) => { if (!im) { api.toast('저장된 사진이 없어 새로 시작해요'); return startFresh(); } build(sv, sv.gs, sv.t, im); });
          else build(sv, sv.gs, sv.t);
        };
        panel([L.h('h2', { text: '하던 퍼즐이 있어요' }),
          L.h('p', { style: { margin: 0, fontSize: '15px' }, text: (ART_NAME[sv.art] || '') + ' · ' + sv.cols * sv.rows + '조각 · ' + (sv.pc | 0) + '개 맞춤 · ' + fmtT(sv.t || 0) }),
          bigBtn('▶ 이어 하기', resume, 'primary'), bigBtn('새로 시작', () => { closeOv(); lsDel(KEY); startFresh(); })], false);
      }

      function dailyIntro(sv) {
        DAILY.prune();
        const card = DAILY.card(() => { closeOv(); if (sv) lsDel(KEY); startFresh(); }, api, '96조각 · ' + (ART_NAME[S0.art] || ''));
        const kids = [card, L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: '오늘은 누구나 같은 그림·같은 조각이에요. 빨리 맞출수록 좋은 기록!' })];
        if (sv) kids.splice(1, 0, bigBtn('▶ 이어 하기 (' + (sv.pc | 0) + '개 · ' + fmtT(sv.t || 0) + ')', () => { closeOv(); build(sv, sv.gs, sv.t); }, 'primary'));
        panel(kids, false);
      }
      function dailyDone(sec) {
        const sc = DAILY.score(S0.dy);
        panel([L.h('h2', { text: '오늘의 퍼즐 완성! 🎉' }),
          L.h('p', { style: { margin: 0, fontSize: '16px' }, text: fmtT(sec) + (sc != null ? ' · 오늘 최고 ' + fmtT(sc) : '') + ' · 🔥 연속 ' + DAILY.streak() + '일' }),
          bigBtn('📋 결과 공유(복사)', () => DAILY.share(S0.dy, api), 'primary'),
          bigBtn('마치기', () => { closeOv(); api.act({ t: 'win', sec }); })], false);
      }

      /* ---------- camera ---------- */
      function bounds() {
        let x0 = 0, y0 = 0, x1 = cut.cols * S, y1 = cut.rows * S;
        for (const g of M.gs) for (const id of g.p) { const [x, y] = pieceCenter(cut, g, id); x0 = Math.min(x0, x - S * 0.7); y0 = Math.min(y0, y - S * 0.7); x1 = Math.max(x1, x + S * 0.7); y1 = Math.max(y1, y + S * 0.7); }
        return [x0, y0, x1, y1];
      }
      function fitRect(x0, y0, x1, y1, inst) {
        const v = view(), z = Math.min(v.w / (x1 - x0), v.h / (y1 - y0)) * 0.97;
        const t = { z, x: (x0 + x1) / 2 - (v.x + v.w / 2) / z, y: (y0 + y1) / 2 - (v.y + v.h / 2) / z };
        if (inst === false) camAnim = { from: Object.assign({}, cam), to: t, t: 0 }; else cam = t;
      }
      let camAnim = null;
      function fitAll(anim) { if (!M) return; const b = bounds(); fitRect(b[0], b[1], b[2], b[3], anim ? false : true); }
      const zLim = () => { const v = view(), b = M ? bounds() : [0, 0, 1000, 1000]; return [Math.min(v.w / (b[2] - b[0]), v.h / (b[3] - b[1])) * 0.6, 2.6]; };
      function zoomAt(sx, sy, f) {
        const [a, b] = zLim(), nz = U.clamp(cam.z * f, a, b);
        const wx = cam.x + sx / cam.z, wy = cam.y + sy / cam.z;
        cam.z = nz; cam.x = wx - sx / nz; cam.y = wy - sy / nz; dirty = true;
      }
      const toW = (sx, sy) => [cam.x + sx / cam.z, cam.y + sy / cam.z];

      /* ---------- drawing ---------- */
      function drawGroup(g, lift) {
        const k = cam.z, half = meta.bs / 2;
        for (const id of g.p) {
          const [wx, wy] = pieceCenter(cut, g, id), sx = (wx - cam.x) * k, sy = (wy - cam.y) * k, d = half * k;
          if (sx < -d || sy < -d || sx > cvs.w + d || sy > cvs.h + d) continue;
          const b = bmp[id];
          if (g.r === 0 && !lift) ctx.drawImage(b, sx - d, sy - d, 2 * d, 2 * d);
          else { ctx.save(); ctx.translate(sx, sy - (lift ? 3 : 0)); ctx.rotate(g.r * Math.PI / 2); if (lift) ctx.scale(1.03, 1.03); ctx.drawImage(b, -d, -d, 2 * d, 2 * d); ctx.restore(); }
        }
      }
      function visible(g) { return !edgeOnly || g.lk || g.p.some((id) => isEdge(cut, id)); }
      function frame(dt) {
        const W = cvs.w, H = cvs.h;
        if (!ready) {
          ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, W, H);
          return;
        }
        if (!finished && !ov) { elapsed += dt; hudT += dt; if (hudT > 0.5) { hudT = 0; dirty = true; } saveT += dt; if (saveT > 6) { saveT = 0; save(); } }
        if (camAnim) { camAnim.t = Math.min(1, camAnim.t + dt * 2.2 * SP()); const e = camAnim.t * camAnim.t * (3 - 2 * camAnim.t), a = camAnim.from, b = camAnim.to;
          cam = { x: a.x + (b.x - a.x) * e, y: a.y + (b.y - a.y) * e, z: a.z + (b.z - a.z) * e }; if (camAnim.t >= 1) camAnim = null; dirty = true; }
        if (drag && autoPan) { cam.x += autoPan[0] * dt * 600 / cam.z; cam.y += autoPan[1] * dt * 600 / cam.z; moveDrag(lastPt[0], lastPt[1]); dirty = true; }
        if (fly) {
          fly.t = Math.min(1, fly.t + dt * SP() / 0.42); const e = 1 - Math.pow(1 - fly.t, 3);
          fly.g.x = fly.fx + (0 - fly.fx) * e; fly.g.y = fly.fy + (0 - fly.fy) * e; dirty = true;
          if (fly.t >= 1) { const g = fly.g; fly = null; const res = snap(M, M.gs.indexOf(g), 1); api.setBusy(false); onSnap(res, g); }
        }
        if (!dirty && !parts.length && !celebrate && !flashes.length) return;
        dirty = false;
        // table
        const bg = ctx.createRadialGradient(W / 2, H * 0.4, 0, W / 2, H * 0.4, Math.max(W, H) * 0.8);
        bg.addColorStop(0, '#2c3a33'); bg.addColorStop(1, '#141b18');
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        // board
        const k = cam.z, bx = -cam.x * k, by = -cam.y * k, bw = cut.cols * S * k, bh = cut.rows * S * k;
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(bx - 6, by - 6 + 3, bw + 12, bh + 12);
        ctx.fillStyle = '#5a3d26'; ctx.fillRect(bx - 6, by - 6, bw + 12, bh + 12);
        ctx.fillStyle = '#1d1712'; ctx.fillRect(bx, by, bw, bh);
        if (ghost) { ctx.globalAlpha = 0.28; ctx.drawImage(art, bx, by, bw, bh); ctx.globalAlpha = 1; }
        else { ctx.strokeStyle = 'rgba(227,174,69,.07)'; ctx.lineWidth = 1; ctx.beginPath();
          for (let i = 1; i < cut.cols; i++) { ctx.moveTo(bx + i * S * k, by); ctx.lineTo(bx + i * S * k, by + bh); }
          for (let j = 1; j < cut.rows; j++) { ctx.moveTo(bx, by + j * S * k); ctx.lineTo(bx + bw, by + j * S * k); } ctx.stroke(); }
        for (const g of M.gs) { if (g === dragG || !visible(g)) continue; drawGroup(g, false); }
        if (dragG) drawGroup(dragG, true);
        // snap flashes
        for (let i = flashes.length - 1; i >= 0; i--) {
          const f = flashes[i]; f.l -= dt * SP(); if (f.l <= 0) { flashes.splice(i, 1); continue; }
          ctx.strokeStyle = 'rgba(255,226,150,' + (f.l / 0.4).toFixed(2) + ')'; ctx.lineWidth = 3;
          for (const id of f.ids) { const g = M.gs.find((q) => q.p.includes(id)); if (!g) continue; const [wx, wy] = pieceCenter(cut, g, id); const d = S * 0.5 * k * (1.25 - f.l / 0.4 * 0.25);
            ctx.strokeRect((wx - cam.x) * k - d, (wy - cam.y) * k - d, d * 2, d * 2); }
        }
        if (celebrate) {
          celebrate.t += dt * SP(); const t = celebrate.t;
          ctx.globalAlpha = U.clamp(t / 0.8, 0, 1); ctx.drawImage(art, bx, by, bw, bh); ctx.globalAlpha = 1;
          const sx = bx - bw + (bw * 3) * U.clamp((t - 0.4) / 1.2, 0, 1);
          ctx.save(); ctx.beginPath(); ctx.rect(bx, by, bw, bh); ctx.clip();
          const g = ctx.createLinearGradient(sx - 80, by, sx + 80, by + bh * 0.3); g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,250,230,' + (0.45 * L.fx()).toFixed(3) + ')'); g.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = g; ctx.fillRect(bx, by, bw, bh); ctx.restore();
          ctx.strokeStyle = 'rgba(227,174,69,' + (0.5 + 0.5 * Math.sin(t * 6)).toFixed(2) + ')'; ctx.lineWidth = 3; ctx.strokeRect(bx - 6, by - 6, bw + 12, bh + 12);
          if (t > 2.4 && !celebrate.done) { celebrate.done = 1; celebrate.cb(); }
        }
        for (let i = parts.length - 1; i >= 0; i--) {
          const q = parts[i]; q.l -= dt * SP(); if (q.l <= 0) { parts.splice(i, 1); continue; }
          q.vy += 260 * dt * SP(); q.x += q.vx * dt * SP(); q.y += q.vy * dt * SP();
          ctx.globalAlpha = Math.min(1, q.l / 0.5); ctx.fillStyle = q.c; ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.l * 7); ctx.fillRect(-q.s / 2, -q.s / 3, q.s, q.s * 0.6); ctx.restore();
        }
        ctx.globalAlpha = 1;
        // HUD
        const g2 = ctx.createLinearGradient(0, 0, 0, TOP); g2.addColorStop(0, 'rgba(15,12,20,.92)'); g2.addColorStop(1, 'rgba(15,12,20,.7)');
        ctx.fillStyle = g2; ctx.fillRect(0, 0, W, TOP);
        const pc = placedCount(M), tot = cut.cols * cut.rows;
        ctx.fillStyle = '#f2e9d8'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.font = '600 18px "IBM Plex Mono", monospace';
        ctx.fillText('⏱ ' + fmtT(elapsed), 12, TOP / 2 - 2);
        ctx.textAlign = 'right'; ctx.fillText(pc + ' / ' + tot, W - 12, TOP / 2 - 2);
        ctx.font = '12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'center';
        ctx.fillText((meta.dy ? '📅 오늘 ' + DAILY.md(meta.dy) + ' · ' : '') + (ART_NAME[meta.art] || '') + (meta.rot ? ' · 회전' : '') + (edgeOnly ? ' · 테두리만' : ''), W / 2, TOP / 2 - 2);
        ctx.fillStyle = 'rgba(255,255,255,.08)'; ctx.fillRect(0, TOP - 3, W, 3);
        ctx.fillStyle = '#e3ae45'; ctx.fillRect(0, TOP - 3, W * pc / tot, 3);
        if (parts.length || celebrate || flashes.length) dirty = true;
      }

      /* ---------- completion ---------- */
      function confetti() {
        const cols = ['#e3ae45', '#ee6a55', '#f2e9d8', '#5cc8f2', '#8fd14f', '#c58cf0'];
        for (let i = 0; i < 120; i++) parts.push({ x: Math.random() * cvs.w, y: -20 - Math.random() * 200, vx: (Math.random() - 0.5) * 80, vy: 40 + Math.random() * 120, l: 2 + Math.random() * 1.5, s: 5 + Math.random() * 6, c: cols[i % cols.length] });
      }
      function finish(silent) {
        if (finished) return;
        finished = true; refreshBar(); edgeOnly = false; dragG = null; drag = null;
        const human = !isAI() && api.canAct(0);
        if (human) lsDel(KEY);
        api.setBusy(true);
        fitRect(-S * 0.3, -S * 0.3, cut.cols * S + S * 0.3, cut.rows * S + S * 0.3, false);
        if (!silent) { api.sfx('win'); api.buzz(80); }
        confetti();
        celebrate = { t: 0, cb: () => {
          api.setBusy(false);
          if (human && S0 && !S0.end && S0.dy) {
            const sec = Math.max(1, Math.round(elapsed));
            if (DAILY.complete(S0.dy, sec, api)) api.toast('오늘 최고 기록! ' + fmtT(sec));
            dailyDone(sec);
          } else if (human && S0 && !S0.end) {
            const sec = Math.round(elapsed), key = 'p' + meta.cols * meta.rows + (meta.rot ? 'r' : '');
            if (api.best && api.best(key, sec, { label: meta.cols * meta.rows + '조각' + (meta.rot ? '·회전' : ''), lower: true, fmt: 'time' })) api.toast('새 최고 기록! ' + fmtT(sec));
            api.act({ t: 'win', sec });
          }
        } };
        dirty = true;
      }
      function onSnap(res, g) {
        if (res.joined || res.locked) {
          flashes.push({ ids: g.p.slice(), l: 0.4 });
          api.sfx(res.locked ? 'pop' : 'click'); api.buzz(res.locked ? 20 : 12);
        }
        dirty = true;
        if (solvedM(M)) finish(false);
      }

      /* ---------- input ---------- */
      const pts = new Map();
      let drag = null, dragG = null, pinch = null, pan = null, autoPan = null, lastPt = [0, 0];
      function hitGroup(wx, wy) {
        for (let i = M.gs.length - 1; i >= 0; i--) {
          const g = M.gs[i]; if (g.lk || !visible(g)) continue;
          for (const id of g.p) { const [x, y] = pieceCenter(cut, g, id); if (Math.abs(x - wx) < S * 0.56 && Math.abs(y - wy) < S * 0.56) return { g, id }; }
        }
        return null;
      }
      function moveDrag(sx, sy) {
        const [wx, wy] = toW(sx, sy); dragG.x = wx - drag.ox; dragG.y = wy - drag.oy;
      }
      // 오른쪽 클릭 = 취소: 집은 조각을 원래 자리로
      const onCx = (e) => { if (!drag || !dragG) return; dragG.x = drag.gx; dragG.y = drag.gy; drag = null; dragG = null; autoPan = null; dirty = true; e.preventDefault(); };
      window.addEventListener('lounge-cancel', onCx);
      function endDrag() {
        if (!drag) return;
        const g = dragG, moved = drag.moved;
        drag = null; dragG = null; autoPan = null;
        if (!moved && meta.rot && Date.now() - g._t0 < 400) { rotateGroup(cut, g, g._id); api.sfx('tick'); }
        const tol = Math.max(S * 0.22, 16 / cam.z);
        const res = snap(M, M.gs.indexOf(g), tol);
        onSnap(res, res.g); save();
      }
      const canPlay = () => ready && !finished && !fly && !ov && api.canAct(0) && !isAI();
      function onDown(e) {
        if (!canPlay()) return;
        const p = cvs.local(e); pts.set(e.pointerId, [p.x, p.y]);
        try { cv.setPointerCapture(e.pointerId); } catch (er) {}
        if (pts.size === 2) {
          if (drag) endDrag();
          pan = null;
          const [a, b] = [...pts.values()];
          pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), mx: (a[0] + b[0]) / 2, my: (a[1] + b[1]) / 2 };
          return;
        }
        if (pts.size > 2) return;
        if (p.y < TOP) return;
        const [wx, wy] = toW(p.x, p.y), h = hitGroup(wx, wy);
        if (h) {
          dragG = h.g; drag = { ox: wx - h.g.x, oy: wy - h.g.y, sx: p.x, sy: p.y, moved: false, gx: h.g.x, gy: h.g.y };
          h.g._t0 = Date.now(); h.g._id = h.id;
          M.gs.splice(M.gs.indexOf(h.g), 1); M.gs.push(h.g); api.sfx('tick'); dirty = true;
        } else pan = { x: p.x, y: p.y };
      }
      function onMove(e) {
        if (!pts.has(e.pointerId)) return;
        const p = cvs.local(e); pts.set(e.pointerId, [p.x, p.y]); lastPt = [p.x, p.y];
        if (pinch && pts.size >= 2) {
          const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]), mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
          cam.x -= (mx - pinch.mx) / cam.z; cam.y -= (my - pinch.my) / cam.z;
          if (pinch.d > 10) zoomAt(mx, my, d / pinch.d);
          pinch = { d, mx, my }; dirty = true; return;
        }
        if (drag) {
          if (Math.hypot(p.x - drag.sx, p.y - drag.sy) > 6) drag.moved = true;
          moveDrag(p.x, p.y);
          const v = view(), e2 = 28;
          autoPan = (p.x < e2 || p.x > v.w - e2 || p.y < v.y + e2 || p.y > v.y + v.h - e2) ? [p.x < e2 ? -1 : p.x > v.w - e2 ? 1 : 0, p.y < v.y + e2 ? -1 : p.y > v.y + v.h - e2 ? 1 : 0] : null;
          dirty = true;
        } else if (pan) { cam.x -= (p.x - pan.x) / cam.z; cam.y -= (p.y - pan.y) / cam.z; pan = { x: p.x, y: p.y }; dirty = true; }
      }
      function onUp(e) {
        if (!pts.has(e.pointerId)) return;
        pts.delete(e.pointerId);
        if (pinch) { if (pts.size < 2) pinch = null; if (pts.size === 1) { const q = [...pts.values()][0]; pan = { x: q[0], y: q[1] }; } return; }
        if (drag) endDrag();
        pan = null;
      }
      function onWheel(e) { if (!ready || ov) return; e.preventDefault(); const p = cvs.local(e); zoomAt(p.x, p.y, Math.pow(1.0018, -e.deltaY)); }
      cv.addEventListener('pointerdown', onDown); cv.addEventListener('pointermove', onMove);
      cv.addEventListener('pointerup', onUp); cv.addEventListener('pointercancel', onUp);
      cv.addEventListener('wheel', onWheel, { passive: false });
      const offIn = api.input ? api.input.on((type, id) => {
        if (type !== 'down' || !ready || finished || ov && id !== 'prev') return;
        const v = view();
        if (id === 'zin') zoomAt(v.w / 2, v.y + v.h / 2, 1.25); else if (id === 'zout') zoomAt(v.w / 2, v.y + v.h / 2, 0.8);
        else if (id === 'fit') { fitAll(); dirty = true; } else if (id === 'edge') toggleEdge(); else if (id === 'sort') doSort();
        else if (id === 'prev') { if (ov) closeOv(); else openPreview(); }
      }) : null;
      const onVis = () => { if (document.hidden) save(); };
      document.addEventListener('visibilitychange', onVis);
      let lw = 0, lh = 0;
      const stop = U.loop((dt) => { if (cvs.w !== lw || cvs.h !== lh) { lw = cvs.w; lh = cvs.h; if (M) fitAll(); dirty = true; } frame(dt); });

      function aiPlace() { // fly one loose piece (or group) home
        const loose = M.gs.filter((g) => !g.lk);
        if (!loose.length) return;
        // prefer pieces touching the placed area, else edges
        const placed = new Set((M.gs.find((g) => g.lk) || { p: [] }).p), cols = cut.cols;
        const touch = (g) => g.p.some((id) => [id - 1, id + 1, id - cols, id + cols].some((k) => placed.has(k)));
        const pool = loose.filter(touch);
        const g = (pool.length ? pool : loose.filter((q) => q.p.some((id) => isEdge(cut, id))).concat(loose))[0];
        const id = g.p[0], c = pieceCenter(cut, g, id);
        g.r = 0; setCenter(cut, g, id, c[0], c[1]);
        M.gs.splice(M.gs.indexOf(g), 1); M.gs.push(g);
        fly = { g, t: 0, fx: g.x, fy: g.y }; api.setBusy(true); api.sfx('whoosh');
      }

      return {
        update(s, prev) {
          const first = !S0; S0 = s;
          if (first) { begin(); return; }
          const L0 = s.last || {}, P = prev && prev.last;
          if (prev && P && L0.id !== P.id && L0.t === 'auto' && ready && !finished) {
            if (fly) { const g = fly.g; g.x = 0; g.y = 0; fly = null; api.setBusy(false); onSnap(snap(M, M.gs.indexOf(g), 1), g); }
            if (!finished) aiPlace();
          }
        },
        destroy() {
          save(); stop();
          cv.removeEventListener('pointerdown', onDown); cv.removeEventListener('pointermove', onMove);
          cv.removeEventListener('pointerup', onUp); cv.removeEventListener('pointercancel', onUp); cv.removeEventListener('wheel', onWheel);
          document.removeEventListener('visibilitychange', onVis);
          window.removeEventListener('lounge-cancel', onCx); if (offIn) offIn(); closeOv(); bar.remove(); fileIn.remove(); api.setBusy(false); cvs.destroy();
          bmp = []; art = null; memPhoto = null;
        },
      };
    },
  };
  def._daily = DAILY; def._dailyCfg = dailyCfg; def._makeCut = makeCut; def._outline = pieceOutline; def._snap = snap; def._newModel = newModel; def._sortTray = sortTray;
  def._pieceCenter = pieceCenter; def._rotateGroup = rotateGroup; def._solved = solvedM; def._edgePts = edgePts; def._trayCells = trayCells;
  L.register(def);
})();
