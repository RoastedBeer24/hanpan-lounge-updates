/* 수족관 경영 (aquarium) — 실제 바다·민물 생물을 모아 수조 생태(온도·염도·함께 살 수 있는지·수조 크기)를 맞추고
   손님을 맞는 하루 단위 경영 게임. 혼자 또는 2~4명이 각자 수족관을 운영해 점수(순자산·평판·전시 매력·종 다양성)를 겨룬다.
   구조: 순수 로직(init/actor/apply/ai/result — 하루 계획은 모두 동시에, 모두 「하루 시작」하면 하루를 시뮬레이션)
         + 뷰(DOM 화면 + 수조 캔버스, 생물 그림은 assets/aquarium/sp.webp — 출처는 assets/aquarium/CREDITS.txt). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util, h = L.h;
  const ID = 'aquarium';
  const ASSET = 'assets/aquarium/';
  const SPD = () => ((L.debug && L.debug.speed) || 1) * (L.speed ? (L.speed() || 1) : 1);

  /* ===================== 종 데이터 (tools: test-output/aquarium/py/gen.py 가 채움) =====================
     key|이름|학명|사는 곳|최저℃|최고℃|최저 염도‰|최고 염도‰|크기cm|성격(0 순함 1 보통 2 사나움)|사냥(0 없음 1 물고기 2 물고기+무척추 3 무척추)
     |특징 글자|최소 수조 L|값(원)|인기|기르기 어려움|먹이|한 줄 설명|움직임(0 헤엄 1 바닥 기어 2 붙어 삶 3 둥둥 4 느릿 5 물가)|그림 x,y,w,h|그림 방향(1=왼쪽 봄) */
  // <SPDATA>
  const SPD_RAW = `
clown|흰동가리|Amphiprion ocellaris|reef|24|28|30|36|8|1|0|KP|75|25000|8|1|잡식|말미잘 촉수 사이에서 살아요. 무리에서 가장 큰 개체가 암컷이 돼요.|0|0,0,235,150|0
tomato|토마토흰동가리|Amphiprion frenatus|reef|24|28|30|36|14|2|0|KPT|110|20000|6|1|잡식|흰동가리 무리 중 성질이 사나운 편이라 다른 흰동가리와 싸워요.|0|1452,760,240,137|0
btang|남양쥐돔|Paracanthurus hepatus|reef|24|28|30|36|31|1|0|Pg|500|150000|9|2|초식(해조류)|'블루탱'으로 잘 알려졌어요. 꼬리자루에 칼날처럼 날카로운 가시가 있어요.|0|726,1305,240,115|1
ytang|노랑양쥐돔|Zebrasoma flavescens|reef|24|28|30|36|20|1|0|Pg|380|120000|8|2|초식(해조류)|하와이 산호초에 많이 살아요. 이끼를 열심히 뜯어 먹어요.|0|237,0,235,150|1
pbtang|파우더블루탱|Acanthurus leucosternon|reef|24|28|30|36|23|2|0|PgT|500|180000|8|3|초식(해조류)|인도양에 살아요. 다른 쥐돔류와 자주 다퉈요.|0|474,0,200,150|1
emperor|옹달샘돔|Pomacanthus imperator|reef|24|27|30|36|40|1|0|PR|800|400000|10|2|잡식(해면·산호)|어릴 땐 파란 바탕에 흰 고리 무늬, 크면 노란 줄무늬로 바뀌어요.|0|676,0,194,150|1
lion|점쏠배감펭|Pterois volitans|reef|22|28|30|36|38|1|2|v|450|80000|9|1|육식|지느러미 가시에 독이 있어요. 대서양에선 외래종으로 퍼졌어요.|0|872,0,151,150|1
mandarin|만다린피시|Synchiropus splendidus|reef|24|27|30|36|7|0|0|Pyh|300|50000|9|3|요각류(작은 갑각류)|작은 요각류만 먹어서 오래된 바위가 많은 수조가 필요해요.|0|1025,0,131,150|0
gramma|로열그라마|Gramma loreto|reef|24|27|30|36|8|1|0|PTh|110|40000|7|1|육식(플랑크톤)|보라와 노랑 두 빛깔로 반씩 나뉜 몸이에요. 바위 동굴을 좋아해요.|0|968,1747,240,93|1
chromis|그린크로미스|Chromis viridis|reef|24|27|30|36|8|0|0|S|150|12000|5|1|플랑크톤|산호 위에서 떼를 지어 다니다가 놀라면 산호 가지 사이로 숨어요.|0|242,1047,240,128|1
damsel|흰줄자리돔|Dascyllus aruanus|reef|24|28|30|36|10|2|0|T|100|10000|4|1|잡식|작지만 영역 다툼이 아주 심해요.|0|1181,908,239,130|1
bdamsel|파랑자리돔|Chrysiptera cyanea|reef|24|28|30|36|8|2|0|P|100|10000|5|1|잡식|선명한 파란색이에요. 작아도 성질은 사나워요.|0|939,908,240,131|1
cleanerw|청줄청소놀래기|Labroides dimidiatus|reef|24|28|30|36|14|0|0|cy|200|30000|6|3|기생충|다른 물고기 몸의 기생충을 떼어 먹는 '청소부'예요.|0|379,1935,240,67|1
anthias|금강바리|Pseudanthias squamipinnis|reef|24|27|30|36|15|0|0|sP|400|40000|7|2|동물성 플랑크톤|암컷 무리 가운데 우두머리가 수컷으로 바뀌어요.|0|1694,1535,240,102|0
heni|두동가리돔|Heniochus acuminatus|reef|22|27|30|36|25|0|0|sR|500|60000|7|2|잡식|등지느러미가 깃발처럼 길어요. 깃대돔과 닮았어요.|0|0,760,240,146|1
auriga|가시나비고기|Chaetodon auriga|reef|24|27|30|36|23|0|0|R|400|50000|7|2|잡식(산호 폴립)|눈을 가리는 검은 띠와 꼬리 쪽 가짜 눈점이 있어요.|0|484,760,240,145|0
boxfish|노랑거북복|Ostracion cubicus|reef|22|27|30|36|45|0|0|Kvy|500|70000|8|3|잡식|상자 같은 단단한 몸이에요. 놀라면 피부에서 독을 내요.|4|242,1845,240,86|1
dogface|별점복|Arothron nigropunctatus|reef|24|27|30|36|33|1|3|RKv|500|90000|8|2|잡식(조개·게)|강아지 같은 얼굴로 인기가 많아요. 몸에 독이 있어요.|0|1650,1178,240,116|1
ctrig|파랑쥐치|Balistoides conspicillum|reef|24|27|30|36|50|2|2|RP|1000|250000|9|2|육식(게·조개)|배의 흰 점무늬가 화려해요. 성질이 아주 사나워요.|0|1158,0,197,150|0
picasso|피카소쥐치|Rhinecanthus aculeatus|reef|24|27|30|36|30|2|3|R|500|70000|7|1|육식(게·조개)|얼굴의 무늬가 추상화처럼 생겼어요.|0|1694,760,240,137|0
snowmor|눈송이곰치|Echidna nebulosa|reef|24|27|30|36|75|1|2|h|400|60000|7|1|육식(갑각류)|바위틈에 몸을 숨기고 머리만 내밀어요.|0|1664,908,240,129|0
harlefile|주둥이쥐치|Oxymonacanthus longirostris|reef|24|27|30|36|12|0|0|PRy|200|50000|7|3|산호 폴립|돌산호 폴립만 쪼아 먹어서 기르기 매우 어려워요.|0|0,1305,240,116|1
sleeper|금줄망둑|Valenciennea strigata|reef|24|27|30|36|18|1|0|T|200|30000|5|2|모래 속 작은 동물|모래를 입에 넣고 아가미로 걸러 먹어요.|0|726,1643,240,100|0
firegoby|불꽃망둑|Nemateleotris magnifica|reef|24|27|30|36|9|0|0|Pyh|75|25000|6|1|플랑크톤|위험을 느끼면 굴로 쏙 숨어요.|0|1694,1047,240,125|0
foxface|여우얼굴|Siganus vulpinus|reef|24|27|30|36|25|1|0|vg|400|60000|6|1|초식(해조류)|여우 같은 얼굴에 지느러미 가시엔 독이 있어요.|0|968,1047,240,127|1
ggrouper|대왕바리|Epinephelus lanceolatus|reef|24|28|30|36|270|1|2||8000|3000000|10|2|육식|산호초에서 가장 큰 경골어류 가운데 하나예요.|0|1357,0,193,150|1
btshark|흑기흉상어|Carcharhinus melanopterus|reef|24|28|30|36|160|1|1|X|8000|2500000|10|2|육식|지느러미 끝이 검어요. 얕은 산호초를 헤엄쳐요.|0|1314,2006,217,42|0
bamboo|얼룩대나무상어|Chiloscyllium punctatum|reef|24|28|30|36|105|0|2|XKh|2000|300000|9|1|육식(새우·작은 물고기)|바닥에서 지내는 순한 상어예요. 알을 낳아요.|0|1210,1535,240,103|0
blsray|꽁지가오리|Taeniura lymma|reef|24|28|30|36|70|0|3|XPy|2000|400000|9|3|육식(게·새우)|몸에 파란 점이 있는 가오리예요. 꼬리에 독가시가 있어요.|0|1210,1047,240,126|0
napoleon|큰양놀래기|Cheilinus undulatus|reef|24|28|30|36|200|1|2|r|8000|5000000|10|2|육식(조개·성게)|흔히 '나폴레옹피시'라 불러요. 이마가 혹처럼 솟는 멸종위기종이에요.|0|1676,1423,240,106|0
gturtle|푸른바다거북|Chelonia mydas|reef|22|28|30|36|120|0|0|Kr|8000|8000000|10|2|초식(해초)|다 자라면 해초를 주로 먹어요. 멸종위기종이에요.|0|726,760,240,145|0
cshrimp|청소새우|Lysmata amboinensis|reef|24|28|30|36|6|0|0|ci|40|25000|6|1|잡식|물고기 입속까지 들어가 청소해 줘요.|1|1552,0,203,150|0
bshrimp|줄무늬산호새우|Stenopus hispidus|reef|24|28|30|36|6|1|0|iTc|40|20000|6|1|잡식|흰 더듬이와 빨간 줄무늬가 화려해요.|1|1757,0,111,150|0
mageane|큰말미잘|Heteractis magnifica|reef|24|27|30|36|50|0|0|C|300|120000|8|3|광합성·작은 동물|촉수가 가득한 큰 말미잘이에요. 흰동가리와 함께 살아요.|2|968,1178,196,120|0
clam|긴자이언트조개|Tridacna maxima|reef|24|28|30|36|35|0|0|Ci|110|150000|8|2|광합성(공생 조류)|외투막 속 공생 조류가 만든 양분으로 자라요.|2|242,1423,240,109|0
acro|사슴뿔산호|Acropora cervicornis|reef|25|28|32|36|50|0|0|Ci|200|80000|7|3|광합성(공생 조류)|사슴뿔처럼 가지를 뻗는 돌산호예요. 멸종위기종이에요.|2|1870,0,129,150|0
hammer|망치산호|Euphyllia ancora|reef|24|27|32|36|30|0|0|Ci|110|70000|7|2|광합성(공생 조류)|폴립 끝이 망치 모양이에요.|2|0,152,174,150|0
leather|가죽산호|Sarcophyton glaucum|reef|24|28|30|36|40|0|0|Ci|110|40000|6|1|광합성(공생 조류)|뼈대 없이 가죽처럼 말랑한 연산호예요.|2|726,1178,240,122|0
bstar|푸른불가사리|Linckia laevigata|reef|24|27|30|36|30|0|0|iy|200|40000|7|3|바닥의 막·찌꺼기|온몸이 새파란 불가사리예요.|1|176,152,156,150|0
urchin|가시왕관성게|Diadema setosum|reef|24|28|30|36|20|0|0|igv|110|20000|5|1|초식(해조류)|아주 긴 가시는 잘 부러지고 찔리면 아파요.|1|334,152,148,150|0
flashf|발광눈금돔|Anomalops katoptron|deep|22|26|30|36|35|0|0|sWh|300|150000|8|3|플랑크톤|눈 밑의 발광 기관을 깜빡이며 어두운 바다에서 신호를 보내요.|0|242,1178,240,124|0
rockbream|돌돔|Oplegnathus fasciatus|kor|12|25|30|35|50|1|3|L|1000|150000|7|2|육식(게·성게)|이빨이 새부리처럼 붙어 있어 성게 껍데기도 깨요.|0|484,152,211,150|1
rockfish|조피볼락|Sebastes schlegelii|kor|10|22|30|35|60|1|2|Lh|800|40000|5|1|육식|알이 아닌 새끼를 낳아요. '우럭'이라고도 불러요.|0|1452,1535,240,103|1
flounder|넙치|Paralichthys olivaceus|kor|10|24|30|35|80|1|1|LW|1500|50000|6|1|육식|어릴 땐 눈이 양쪽에 있다가 자라며 왼쪽으로 몰려요. '광어'예요.|1|242,1305,240,116|1
redbream|참돔|Pagrus major|kor|12|26|30|35|100|1|2|Ls|2000|80000|6|1|육식(새우·게)|붉은 몸에 파란 점이 반짝여요.|0|484,1047,240,128|0
tiger|자주복|Takifugu rubripes|kor|12|25|30|35|70|1|3|LvR|1500|100000|8|2|육식(게·조개)|몸에 테트로도톡신이라는 강한 독이 있어요.|0|726,1845,240,77|1
filefish|쥐치|Stephanolepis cirrhifer|kor|14|26|30|35|25|0|0|LR|300|20000|5|1|잡식|입을 쭉 내밀어 해파리도 먹어요.|0|968,1643,218,100|1
greenling|쥐노래미|Hexagrammos otakii|kor|8|20|30|35|50|1|2|L|600|30000|5|1|육식|우리 바다 바위 해안에 흔한 물고기예요.|0|0,1643,240,102|1
seabass|농어|Lateolabrax japonicus|kor|10|25|3|35|100|1|1|L|3000|60000|6|1|육식|바다와 강어귀를 오가며 살아요.|0|1188,1643,240,99|0
jackm|전갱이|Trachurus japonicus|kor|15|25|30|35|35|0|0|SL|2000|5000|4|1|플랑크톤·작은 물고기|옆구리에 단단한 비늘(모비늘)이 줄지어 있어요.|0|726,1423,240,107|1
sardine|정어리|Sardinops melanostictus|kor|10|24|30|35|24|0|0|SL|2000|3000|5|1|플랑크톤|수천 마리가 한 몸처럼 회오리 떼를 만들어요.|0|242,2006,240,53|0
mackerel|고등어|Scomber japonicus|kor|12|24|30|35|50|0|1|SL|6000|8000|5|1|육식(작은 물고기)|쉬지 않고 헤엄쳐야 숨을 쉬어요.|0|0,1747,240,96|1
kobudai|혹돔|Semicossyphus reticulatus|kor|13|25|30|35|100|1|3|LW|3000|500000|8|2|육식(조개·게)|다 자란 수컷 이마에 커다란 혹이 솟아요.|0|726,1535,240,104|1
nibbler|벵에돔|Girella punctata|kor|12|25|30|35|45|0|0|Lg|1000|50000|5|1|잡식(해조류)|갯바위 낚시로 인기가 많은 물고기예요.|0|484,1305,240,116|1
devilsc|쑤기미|Inimicus japonicus|kor|15|25|30|35|25|1|2|LvWh|200|50000|6|1|육식|바위처럼 생겼고 등 가시에 강한 독이 있어요.|1|0,1535,240,106|1
seahorse|해마|Hippocampus haema|kor|10|24|30|35|12|0|0|KLy|75|40000|9|3|육식(작은 새우)|꼬리로 해초를 감고 서서 헤엄쳐요.|4|697,152,97,150|1
octo|참문어|Octopus vulgaris|kor|10|25|30|35|90|1|2|hWi|400|80000|9|2|육식(게·조개)|빨판 달린 팔 여덟 개로 병뚜껑도 여는 영리한 동물이에요.|1|796,152,128,150|0
bluecrab|꽃게|Portunus trituberculatus|kor|10|27|25|35|25|2|2|iL|200|15000|4|1|육식|맨 뒷다리가 노처럼 넓적해 헤엄을 잘 쳐요.|1|926,152,175,150|0
seastar|아무르불가사리|Asterias amurensis|kor|5|20|28|35|40|0|3|iL|100|5000|4|1|육식(조개)|조개를 감싸 위를 뒤집어 넣어 소화해요.|1|1103,152,186,150|0
squirt|멍게|Halocynthia roretzi|kor|5|20|30|35|15|0|0|iL|60|5000|3|1|여과 섭식|물을 빨아들여 플랑크톤을 걸러 먹어요.|2|697,908,240,136|0
seacuke|돌기해삼|Apostichopus japonicus|kor|5|20|30|35|30|0|0|iL|100|10000|3|1|바닥 찌꺼기|위험하면 내장을 뱉고 다시 만들어 내요.|1|1291,152,226,150|0
houndsh|까치상어|Triakis scyllium|kor|10|24|30|35|150|0|2|XL|4000|300000|8|1|육식(게·작은 물고기)|몸에 검은 점이 흩어진 순한 상어예요.|0|863,1935,240,66|0
skate|홍어|Okamejei kenojei|kor|10|20|30|35|50|0|3|XL|2000|150000|7|2|육식(새우·게)|바닥에 납작 붙어 지내는 가오리 무리예요.|1|1519,152,111,150|0
conger|붕장어|Conger myriaster|kor|12|24|30|35|100|0|2|hL|800|30000|5|1|육식|낮에는 모래나 바위틈에 숨어 있어요.|0|1597,1747,240,89|0
damselk|자리돔|Chromis notata|kor|15|26|30|35|15|0|0|SL|300|5000|5|1|플랑크톤|제주 바다에 떼로 살아요. '자리물회'로 유명해요.|0|968,1305,240,115|0
spcrab|키다리게|Macrocheira kaempferi|deep|10|16|30|35|370|0|0|iWr|2000|1000000|10|2|잡식(죽은 생물)|다리를 펴면 3.7m에 이르는 세계에서 가장 큰 게예요.|1|1632,152,206,150|0
isopod|대왕구족충|Bathynomus giganteus|deep|4|12|30|36|40|0|0|iW|300|500000|9|2|죽은 생물|몇 년 동안 먹지 않고 버틴 기록이 있어요.|1|242,1535,240,106|0
nautilus|황제앵무조개|Nautilus pompilius|deep|16|21|30|36|20|0|0|iWy|400|400000|9|3|육식(죽은 생물·갑각류)|껍데기 속 방에 기체를 채워 떠오르고 가라앉아요.|4|1840,152,165,150|1
gpocto|문어|Enteroctopus dofleini|deep|7|13|30|35|400|1|2|hWi|3000|600000|10|2|육식(게·조개)|세계에서 가장 큰 문어로 50kg을 넘기도 해요.|1|0,304,202,150|0
wolfeel|늑대장어|Anarrhichthys ocellatus|deep|6|12|30|35|240|0|3|hW|2000|400000|8|2|육식(성게·게)|무서운 얼굴과 달리 순하고 사람을 잘 알아봐요.|1|0,1178,240,125|1
chimaera|은상어|Chimaera phantasma|deep|8|15|30|35|100|0|3|XWy|3000|800000|9|3|육식(갑각류)|상어와 먼 친척인 연골어류예요. 등에 독가시가 있어요.|0|204,304,175,150|1
hagfish|먹장어|Eptatretus burgeri|deep|10|18|30|35|60|0|0|Wh|300|20000|5|1|죽은 생물|위협을 받으면 끈적한 점액을 한가득 뿜어내요.|1|968,1535,240,104|0
kingcrab|왕게|Paralithodes camtschaticus|deep|2|10|30|35|180|0|3|i|1500|300000|8|2|육식(조개·성게)|게처럼 보이지만 소라게와 더 가까운 친척이에요.|1|0,908,240,137|0
snowcrab|대게|Chionoecetes opilio|deep|0|6|30|35|90|0|3|i|500|80000|6|2|육식(조개·갯지렁이)|다리가 대나무 마디처럼 곧게 뻗어서 대게라 불러요.|1|381,304,170,150|0
anglerf|황아귀|Lophius litulon|deep|8|18|30|35|150|0|1|W|2000|100000|7|2|육식|머리 위 낚싯대 같은 가시로 먹이를 꾀어요.|1|553,304,221,150|0
gentoo|젠투펭귄|Pygoscelis papua|pole|0|10|28|36|90|0|1|AKs|6000|3000000|10|2|물고기·크릴|펭귄 가운데 가장 빠르게 헤엄쳐요. 시속 36km예요.|5|776,304,105,150|0
kingpen|임금펭귄|Aptenodytes patagonicus|pole|0|10|28|36|95|0|1|AKs|6000|4000000|10|2|물고기·오징어|황제펭귄 다음으로 큰 펭귄이에요.|5|883,304,115,150|0
otter|해달|Enhydra lutris|pole|5|15|28|36|130|0|3|AK|6000|4000000|10|3|조개·성게·게|배 위에 돌을 올려 조개를 깨 먹어요.|5|1000,304,124,150|0
seal|점박이물범|Phoca largha|pole|0|15|28|36|170|0|1|AKL|6000|3000000|10|2|물고기|백령도에 찾아오는 천연기념물이에요.|5|1126,304,126,150|0
clione|무각거북고둥|Clione limacina|pole|-1|8|30|35|3|0|0|KWiy|40|30000|9|3|바다나비(작은 고둥)|'바다의 천사'라 불리지만 사냥할 땐 머리에서 촉수가 튀어나와요.|3|1254,304,81,150|0
spiny|가시도치|Eumicrotremus orbis|pole|2|10|30|35|13|0|0|KWy|75|80000|9|3|작은 갑각류|탁구공처럼 동그란 몸에 작은 가시가 덮여 있어요.|4|1210,1305,240,113|0
cod|대구|Gadus macrocephalus|pole|2|12|30|35|120|0|1|s|3000|100000|5|1|육식|입이 커서 '대구(大口)'라는 이름이 붙었어요.|0|0,1845,240,88|1
pshrimp|북쪽분홍새우|Pandalus eous|pole|0|8|30|35|12|0|0|Si|60|3000|4|1|잡식|'단새우'라는 이름으로 많이 먹어요. 자라며 수컷에서 암컷이 돼요.|1|0,1047,240,129|0
gurchin|말똥성게|Strongylocentrotus intermedius|pole|0|15|30|35|8|0|0|ig|60|5000|3|1|초식(다시마)|다시마 같은 해조류를 먹어요.|1|1337,304,182,150|0
moonj|보름달물해파리|Aurelia aurita|jel|9|25|25|36|30|0|0|J|300|10000|8|1|플랑크톤|몸에 네 개의 동그란 생식소가 보름달처럼 비쳐요.|3|1521,304,119,150|0
nettle|태평양쐐기해파리|Chrysaora fuscescens|jel|10|18|30|35|50|0|0|Jv|300|40000|8|2|플랑크톤|금빛 몸에 길고 붉은 촉수가 늘어져요.|3|1642,304,116,150|0
spotj|점박이해파리|Phyllorhiza punctata|jel|20|28|25|36|50|0|0|J|300|50000|8|2|플랑크톤·공생 조류|흰 점무늬가 흩어진 반구 모양 해파리예요.|3|1760,304,141,150|0
goldj|황금해파리|Mastigias papua|jel|24|28|30|36|20|0|0|JC|300|60000|8|2|광합성(공생 조류)|팔라우 호수에선 해를 따라 매일 호수를 건너요.|3|0,456,147,150|0
lionj|사자갈기해파리|Cyanea capillata|jel|4|14|30|35|200|0|0|JvW|300|200000|9|3|육식(다른 해파리)|촉수가 30m를 넘기도 하는 가장 큰 해파리 무리예요.|3|149,456,151,150|0
nomura|노무라입깃해파리|Nemopilema nomurai|jel|15|25|30|35|200|0|0|JvL|300|300000|8|3|플랑크톤|우리 바다에 떼로 몰려오는 큰 해파리예요. 무게가 200kg까지 나가요.|3|302,456,99,150|0
pelagia|야광원양해파리|Pelagia noctiluca|jel|13|20|33|37|10|0|0|Jv|300|60000|8|3|플랑크톤|자극을 받으면 몸에서 푸른빛이 나요.|3|403,456,99,150|0
angel|엔젤피시|Pterophyllum scalare|amz|24|30|0|1|15|1|1|P|110|8000|7|1|잡식|다 자라면 네온테트라를 잡아먹기도 해요.|0|504,456,111,150|1
discus|디스커스|Symphysodon aequifasciatus|amz|26|31|0|1|20|0|0|sPy|250|80000|9|3|잡식|부모가 몸에서 내는 점액으로 새끼를 먹여 키워요.|0|617,456,151,150|0
neon|네온테트라|Paracheirodon innesi|amz|20|26|0|1|3.5|0|0|SP|40|1000|5|1|잡식|몸 옆의 파란 줄이 빛을 받아 반짝여요.|0|0,1935,135,69|0
cardinal|카디널테트라|Paracheirodon axelrodi|amz|23|29|0|1|4|0|0|SP|60|2000|6|1|잡식|네온테트라와 닮았지만 배 전체가 빨개요.|0|1408,1178,240,117|1
rummy|러미노즈테트라|Hemigrammus bleheri|amz|23|27|0|1|5|0|0|S|75|2500|5|2|잡식|코끝이 빨개요. 물이 나빠지면 색이 옅어져요.|0|968,1845,240,76|1
piranha|붉은배피라냐|Pygocentrus nattereri|amz|24|28|0|1|33|1|1|sv|400|30000|8|1|육식|날카로운 이빨이 있지만 사실 겁이 많아 무리 지어 다녀요.|0|484,1178,240,124|0
arapaima|피라루쿠|Arapaima gigas|amz|24|30|0|1|300|1|1|r|8000|2000000|10|2|육식|공기 호흡을 해서 물 위로 숨 쉬러 올라와요.|0|1105,1935,240,65|0
arowana|실버아로와나|Osteoglossum bicirrhosum|amz|24|30|0|1|90|1|1||1000|100000|8|1|육식(곤충·물고기)|물 위로 뛰어올라 나뭇가지의 곤충을 잡아요.|0|137,1935,240,68|0
motoro|모토로가오리|Potamotrygon motoro|amz|24|29|0|1|50|0|2|Xv|1500|500000|9|2|육식(작은 물고기·새우)|강에 사는 민물 가오리예요. 꼬리에 독가시가 있어요.|0|770,456,224,150|0
cory|청동코리도라스|Corydoras aeneus|amz|22|26|0|1|7|0|0|sK|60|3000|5|1|잡식(바닥 먹이)|바닥을 콕콕 쪼아 남은 먹이를 먹어요.|1|1452,1047,240,126|0
oscar|오스카|Astronotus ocellatus|amz|22|28|0|1|35|2|1||400|15000|7|1|육식|주인을 알아보는 영리한 물고기로 알려져 있어요.|0|996,456,240,150|1
eel|전기뱀장어|Electrophorus electricus|amz|24|28|0|1|200|1|1|vW|2000|500000|9|2|육식|수백 볼트의 강한 전기를 내서 사냥하고 몸을 지켜요.|0|1533,2006,240,39|0
redtail|붉은꼬리메기|Phractocephalus hemioliopterus|amz|20|28|0|1|130|1|1||4000|150000|8|1|육식|꼬리가 빨간 큰 메기예요. 무엇이든 삼켜요.|0|484,2006,240,53|0
hatchet|마블해칫|Carnegiella strigata|amz|24|28|0|1|3.5|0|0|SyW|60|4000|5|2|곤충|배가 도끼날처럼 볼록해요. 물 위로 뛰어올라요.|0|484,1643,240,101|0
apisto|아가시지아피스토|Apistogramma agassizii|amz|23|29|0|1|8|1|0|TP|60|15000|6|2|잡식|수컷의 꼬리지느러미가 불꽃처럼 뾰족해요.|0|1210,2006,102,47|1
payara|파야라|Hydrolycus scomberoides|amz|24|28|0|1|110|1|1|W|4000|400000|8|2|육식|아래턱에 송곳니처럼 긴 이빨 두 개가 있어요.|0|1672,1643,240,98|1
yellab|옐로우랩|Labidochromis caeruleus|afr|24|28|0|1|10|1|0|P|200|6000|6|1|잡식|말라위 호수에 사는 샛노란 시클리드예요.|0|968,1423,240,107|0
peacock|피콕시클리드|Aulonocara nyassae|afr|24|28|0|1|15|1|0|P|250|10000|7|1|잡식|머리의 감각 구멍으로 모래 속 작은 동물의 움직임을 느껴 찾아요.|0|484,1747,240,95|1
dolphin|블루돌핀시클리드|Cyrtocara moorii|afr|24|28|0|1|20|1|0|PW|400|20000|7|1|잡식|이마가 돌고래처럼 불룩 솟아요.|0|1238,456,236,150|0
frontosa|프론토사|Cyphotilapia frontosa|afr|24|27|0|1|35|1|1||800|60000|8|2|육식|탕가니카 호수 깊은 곳에 살아요. 이마에 혹이 있어요.|0|242,760,240,146|1
tropheus|트로페우스|Tropheus duboisi|afr|24|27|0|1|12|2|0|gP|300|25000|7|2|초식(이끼)|어릴 땐 검은 몸에 흰 물방울무늬가 있어요.|0|1476,456,227,150|0
brichardi|브리샤르디|Neolamprologus brichardi|afr|22|25|0|1|9|1|0|T|100|8000|5|1|잡식|형·누나 물고기가 동생들을 함께 돌봐요.|0|242,908,240,137|0
cuckoo|뻐꾸기메기|Synodontis multipunctatus|afr|23|27|0|1|15|0|0|s|200|30000|6|1|잡식|다른 시클리드에게 알을 맡기는 '탁란'을 해요.|0|1166,1178,240,118|1
bfly|민물나비고기|Pantodon buchholzi|afr|24|30|0|1|12|0|1|W|150|12000|6|1|곤충·작은 물고기|가슴지느러미를 날개처럼 펴고 물 위로 뛰어요.|0|1210,1747,143,93|0
elephant|코끼리주둥이고기|Gnathonemus petersii|afr|23|28|0|1|35|0|0|Wyh|300|25000|8|3|작은 벌레|약한 전기를 내서 주변을 느껴요.|0|484,1845,240,79|0
betta|베타|Betta splendens|asia|24|30|0|1|6.5|2|0|1P|20|10000|8|1|육식(작은 벌레)|수컷끼리 만나면 싸워서 '싸움 물고기'라 불려요.|0|1705,456,192,150|1
zebra|제브라다니오|Danio rerio|asia|18|26|0|1|4|0|0|S|40|1000|4|1|잡식|과학 실험에 많이 쓰이는 작은 물고기예요.|0|0,2006,240,56|0
pearl|진주구라미|Trichopodus leerii|asia|24|28|0|1|12|0|0|P|110|6000|6|1|잡식|몸에 진주 같은 점무늬가 가득해요. 공기를 들이마셔요.|0|1422,908,240,130|1
tbarb|수마트라|Puntigrus tetrazona|asia|20|26|0|1|7|1|0|S|75|2000|5|1|잡식|다른 물고기의 긴 지느러미를 물어뜯기도 해요.|0|0,608,235,150|0
rasbora|라스보라|Trigonostigma heteromorpha|asia|22|27|0|1|4.5|0|0|S|40|2000|5|1|잡식|몸 뒤쪽에 검은 삼각형 무늬가 있어요.|0|242,1747,240,96|0
asarow|아시아아로와나|Scleropages formosus|asia|24|30|0|1|90|2|1|Pr|1500|3000000|10|2|육식|국제 거래가 엄격히 제한되는 멸종위기종이에요.|0|1430,1643,240,99|1
datnoid|타이거피시|Datnioides microlepis|asia|22|28|0|5|45|1|1||1000|150000|7|2|육식|호랑이 같은 굵은 줄무늬가 있어요.|0|237,608,237,150|1
amano|야마토새우|Caridina multidentata|asia|20|27|0|1|5|0|0|igs|20|2000|4|1|이끼·찌꺼기|수조의 이끼를 열심히 먹는 청소부예요.|1|484,1423,240,108|1
cherry|체리새우|Neocaridina davidi|asia|18|27|0|1|3|0|0|igSK|20|1000|5|1|이끼·찌꺼기|빨간 몸이 앵두처럼 예뻐요.|1|484,908,211,137|0
kuhli|쿨리로치|Pangio kuhlii|asia|24|30|0|1|10|0|0|hsW|60|2000|4|1|잡식(바닥)|뱀처럼 길쭉한 미꾸라지 무리예요.|1|968,2006,240,50|0
goldfish|금붕어|Carassius auratus|tmp|10|24|0|1|20|0|0|KP|75|3000|6|1|잡식|천 년 넘게 사람이 길러 온 관상어예요.|0|1694,1305,240,110|0
koi|비단잉어|Cyprinus rubrofuscus|tmp|4|28|0|1|90|0|0|KP|3000|200000|8|1|잡식|수십 년을 사는 오래 사는 물고기예요.|0|726,1047,240,128|1
axolotl|아홀로틀|Ambystoma mexicanum|tmp|14|20|0|1|25|0|0|KWy|75|20000|9|2|육식(벌레)|어른이 돼도 아가미를 단 채 물속에서 살아요.|4|476,608,215,150|0
kkeokji|꺽지|Coreoperca herzi|tmp|12|24|0|1|20|1|1|Lh|150|20000|6|1|육식|우리나라에만 사는 고유종으로 바위틈을 지켜요.|0|693,608,208,150|0
gaksi|각시붕어|Rhodeus uyekii|tmp|8|24|0|1|6|0|0|sLP|60|5000|6|1|잡식|살아 있는 조개 속에 알을 낳아요.|0|1452,1845,240,70|0
pirami|피라미|Zacco platypus|tmp|8|25|0|1|15|0|0|SL|150|3000|4|1|잡식|여름이면 수컷 몸이 무지갯빛으로 물들어요.|0|1210,1423,222,107|1
medaka|송사리|Oryzias sinensis|tmp|5|30|0|10|3.5|0|0|SLK|20|500|4|1|잡식|논과 도랑에 떼 지어 사는 작은 물고기예요.|0|903,608,185,150|0
mandarinf|쏘가리|Siniperca scherzeri|tmp|12|25|0|1|50|1|1|LP|600|80000|8|2|육식|황금빛 몸에 표범 무늬가 있어 '강의 왕'이라 불려요.|0|1434,1423,240,107|1
catfish|메기|Silurus asotus|tmp|10|28|0|1|60|1|1|LWh|600|20000|5|1|육식|긴 수염으로 어두운 물속에서 먹이를 찾아요.|0|1589,1935,240,57|1
loach|미꾸리|Misgurnus anguillicaudatus|tmp|5|28|0|1|15|0|0|Ls|60|1000|3|1|잡식(바닥)|창자로도 숨을 쉬어 물 위로 공기를 마시러 올라와요.|1|726,2006,240,52|1
lenok|열목어|Brachymystax lenok tsinlingensis|tmp|2|15|0|1|70|1|1|Lr|1000|150000|7|2|육식|여름에도 20℃를 넘지 않는 차가운 계곡에 살아요.|0|1210,1845,240,71|0
snakeh|가물치|Channa argus|tmp|10|28|0|1|85|2|1|L|1000|30000|6|1|육식|공기를 직접 들이마셔 진흙 속에서도 버텨요.|0|1347,1935,240,61|1
masu|산천어|Oncorhynchus masou|tmp|4|16|0|1|40|1|1|L|800|30000|6|1|육식(곤충·작은 물고기)|바다로 가지 않고 계곡에 남은 송어예요.|0|1694,1845,240,70|1
dongsa|동사리|Odontobutis platycephala|tmp|8|25|0|1|20|1|1|Lh|150|5000|4|1|육식|우리나라 고유종으로 바위 밑에 숨어 먹이를 기다려요.|0|1355,1747,240,90|1
budeul|버들붕어|Macropodus ocellatus|tmp|10|26|0|1|7|1|0|LT|40|5000|5|1|잡식|수컷이 물 위에 거품집을 지어 알을 지켜요.|0|484,1535,240,106|1
gspuffer|점박이초록복|Dichotomyctere nigroviridis|mang|24|28|5|30|17|2|3|vKR|150|10000|7|2|육식(달팽이·새우)|어릴 땐 민물에도 살지만 크면 바닷물이 필요해요.|0|1090,608,214,150|0
mono|은빛모노|Monodactylus argenteus|mang|24|28|5|35|27|0|0|s|400|10000|5|1|잡식|은빛으로 납작하고 둥근 몸이에요.|0|1306,608,212,150|1
scat|납작돔|Scatophagus argus|mang|24|28|5|30|38|0|0|sg|400|10000|5|1|잡식|무엇이든 잘 먹는 청소부 물고기예요.|0|1520,608,171,150|1
archer|물총고기|Toxotes jaculatrix|mang|25|30|2|20|30|0|1|sW|300|20000|8|1|곤충·작은 물고기|입으로 물을 쏘아 나뭇잎 위의 벌레를 떨어뜨려요.|0|0,1423,240,110|0
mudsk|말뚝망둥어|Periophthalmus modestus|mang|15|30|5|30|10|1|0|LWm|75|5000|7|1|작은 벌레·게|물 밖에서 가슴지느러미로 기어 다녀요.|1|621,1935,240,67|1
jjang|짱뚱어|Boleophthalmus pectinirostris|mang|18|30|5|30|20|1|0|LWmT|100|8000|7|1|돌말(규조류)|갯벌 위를 뛰어다니며 짝을 찾아요.|1|242,1643,240,102|0
jeel|뱀장어|Anguilla japonica|mang|10|28|0|35|100|1|1|Lh|600|50000|5|1|육식|먼 바다에서 태어나 강을 거슬러 올라와 자라요.|0|1210,760,240,138|1
barra|바라문디|Lates calcarifer|mang|24|30|0|35|120|1|1||2000|50000|7|1|육식|자라면서 수컷에서 암컷으로 바뀌어요.|0|1452,1305,240,112|0
hscrab|세가시투구게|Tachypleus tridentatus|mang|20|30|20|35|60|0|0|iWr|600|200000|9|2|조개·갯지렁이|공룡보다 먼저 나타난 '살아 있는 화석'이에요. 피가 파래요.|1|968,760,240,143|0
fiddler|농게|Tubuca arcuata|mang|20|30|10|35|4|0|0|iLWm|60|3000|6|1|갯벌의 유기물|수컷은 한쪽 집게발만 아주 커요.|1|1693,608,199,150|0
mullet|숭어|Mugil cephalus|mang|10|28|0|36|60|0|0|S|3000|10000|4|1|잡식(바닥 유기물)|물 위로 높이 뛰어오르는 모습으로 유명해요.|0|726,1747,240,95|0
`;
  const ATL = { w: 2048, h: 2062, v: 58439 };
  // </SPDATA>

  const SP = SPD_RAW.trim().split('\n').filter(Boolean).map((ln, i) => {
    const p = ln.split('|');
    const fl = p[11];
    const o = { i, key: p[0], ko: p[1], sci: p[2], zone: p[3], tmin: +p[4], tmax: +p[5], smin: +p[6], smax: +p[7], size: +p[8], aggr: +p[9], pred: +p[10], fl,
      minL: +p[12], price: +p[13], ap: +p[14], care: +p[15], diet: p[16], fact: p[17], mv: +p[18] || 0, box: (p[19] || '0,0,0,0').split(',').map(Number), flip: +p[20] || 0 };
    o.inv = fl.includes('i'); o.coral = fl.includes('C'); o.jelly = fl.includes('J'); o.land = fl.includes('A');
    o.school = fl.includes('S') ? 6 : fl.includes('s') ? 3 : 0; o.terr = fl.includes('T'); o.solo = fl.includes('1');
    o.nip = fl.includes('R'); o.clean = fl.includes('c'); o.graze = fl.includes('g'); o.hide = fl.includes('h'); o.shy = fl.includes('y');
    o.mud = fl.includes('m'); o.rare = fl.includes('r');
    o.ld = Math.pow(o.size, 1.7) / 20 * (o.coral || o.jelly ? 0.3 : 1) * (o.inv && !o.coral ? 0.5 : 1);
    return o;
  });
  const SPK = {}; SP.forEach((s) => { SPK[s.key] = s; });

  const ZN = {
    reef: { n: '산호초 바다', ic: '🐠', dec: 1, T: 26, S: 34, th: '산호초 수조', c1: '#1b7fb0', c2: '#0b3558' },
    kor: { n: '우리 바다', ic: '🌊', dec: 3, T: 17, S: 33, th: '우리 바다 수조', c1: '#2c6f86', c2: '#0e2c3c' },
    deep: { n: '심해', ic: '🌑', dec: 6, T: 10, S: 34, th: '심해 수조', c1: '#13294a', c2: '#03070f' },
    pole: { n: '극지 바다', ic: '🧊', dec: 7, T: 4, S: 34, th: '극지 바다', c1: '#6aa2c4', c2: '#163a55' },
    jel: { n: '해파리', ic: '🎐', dec: 0, T: 18, S: 33, th: '해파리관', c1: '#1a4a8a', c2: '#050f24' },
    amz: { n: '아마존 강', ic: '🌿', dec: 2, T: 27, S: 0, th: '아마존 강 수조', c1: '#6b6a2e', c2: '#1f2610' },
    afr: { n: '아프리카 호수', ic: '⛰️', dec: 3, T: 26, S: 0, th: '아프리카 호수 수조', c1: '#3a86a8', c2: '#123447' },
    asia: { n: '아시아 열대 강', ic: '🎋', dec: 2, T: 26, S: 0, th: '아시아 강 수조', c1: '#4f7f3a', c2: '#15260f' },
    tmp: { n: '온대 강·계곡', ic: '🏞️', dec: 4, T: 16, S: 0, th: '우리 강 수조', c1: '#4d8a73', c2: '#132a22' },
    mang: { n: '맹그로브 갯벌', ic: '🌳', dec: 5, T: 26, S: 15, th: '맹그로브 수조', c1: '#66704a', c2: '#1c2112' },
  };
  const ZK = Object.keys(ZN);
  const DEC = ['맨바닥', '산호 모래·바위', '수초·유목', '바위 더미', '자갈·강돌', '맹그로브 뿌리·갯벌', '어두운 심해 바위', '얼음 바위'];
  const TK = [
    { n: '소형 수조', v: 60, w: 60, cost: 300000, d: '작은 물고기·새우·산호 몇 종' },
    { n: '중형 수조', v: 200, w: 90, cost: 1200000, d: '작은 무리와 중간 크기 물고기' },
    { n: '대형 수조', v: 600, w: 150, cost: 4000000, d: '큰 물고기 몇 마리, 큰 무리' },
    { n: '초대형 수조', v: 2000, w: 250, cost: 15000000, d: '작은 상어·가오리·큰 물고기' },
    { n: '대수조(터널)', v: 8000, w: 600, cost: 60000000, one: 1, d: '손님이 터널로 지나가며 보는 거대한 수조. 한 곳에 1개' },
    { n: '해파리 원형 수조', v: 300, w: 100, cost: 6000000, jel: 1, d: '물이 빙글빙글 돌아 해파리가 바닥·벽에 걸리지 않아요. 해파리만' },
    { n: '물가 사육장', v: 6000, w: 600, cost: 40000000, land: 1, d: '뭍과 물이 함께 있는 곳. 펭귄·해달·물범만' },
  ];
  const HT = 1, CH = 2, LT = 4, SK = 8, BK = 16;
  const EQ = [
    { b: HT, n: '히터', ic: '🔥', c: 100000, d: '물을 25~32℃로 데울 수 있어요' },
    { b: CH, n: '냉각기', ic: '❄️', c: 600000, d: '물을 0~19℃로 식힐 수 있어요' },
    { b: LT, n: '산호 조명', ic: '💡', c: 400000, d: '산호·말미잘·조개가 빛으로 양분을 만들어요' },
    { b: SK, n: '단백질 스키머', ic: '🧪', c: 300000, d: '바닷물(염도 20‰ 이상)에서 거를 수 있는 양 +25%' },
    { b: BK, n: '비상 전원', ic: '🔋', c: 200000, d: '정전 때도 온도·여과가 그대로' },
  ];
  const FILT = [0, 200000, 600000];   // 여과기 Lv2, Lv3 올리기 값(×수조 크기 배율)
  const ST = [
    { n: '사육사', ic: '🧽', w: 120000, d: '1명이 수조 3개를 맡아 물갈이·청소. 못 맡은 수조는 물이 빨리 나빠져요' },
    { n: '수의사', ic: '🩺', w: 200000, d: '1명이 수조 4개를 맡아 병을 막고 고쳐요. 생물이 더 빨리 회복해요' },
    { n: '해설사', ic: '🎤', w: 120000, d: '손님 만족·기념품 매출이 올라요. 수학여행 날 특히 인기' },
    { n: '홍보 담당', ic: '📣', w: 150000, d: '손님이 늘어요(한 명 더할수록 효과는 줄어요)' },
  ];
  const EV = {
    none: { n: '평범한 날', ic: '☀️', d: '특별한 일이 없어요.' },
    rain: { n: '비 오는 날', ic: '☔', d: '실내 나들이 손님이 25% 늘어요.' },
    trip: { n: '수학여행 날', ic: '🎒', d: '학생 단체 손님 +30%. 종이 다양하고 해설사가 있으면 좋아하고, 비싼 표는 싫어해요.' },
    out: { n: '정전', ic: '⚡', d: '비상 전원이 없는 수조는 온도가 실내 온도(22℃) 쪽으로 4℃ 움직이고 물이 나빠져요.' },
    heat: { n: '폭염', ic: '🔥', d: '냉각기가 없는 수조는 물이 3℃ 따뜻해져요.' },
    cold: { n: '한파', ic: '🥶', d: '히터가 없는 수조는 물이 3℃ 차가워져요. 손님 −15%.' },
    flu: { n: '질병 유행', ic: '🦠', d: '수조에 병이 생길 확률이 3배예요. 수의사가 있으면 많이 막아요.' },
    tv: { n: '방송 취재', ic: '📺', d: '가장 멋진 수조를 가진 수족관이 평판 +8.' },
    food: { n: '먹이 값 오름', ic: '🦐', d: '오늘 먹이 값이 2배예요.' },
    rare: { n: '희귀종 들어옴', ic: '💎', d: '시장에 희귀한 생물이 많이 나와요.' },
    fest: { n: '바다 축제', ic: '🎉', d: '도시에 축제가 열려 손님이 40% 늘어요.' },
  };
  const EV_POOL = [['none', 30], ['rain', 10], ['trip', 9], ['out', 7], ['heat', 6], ['cold', 6], ['flu', 7], ['tv', 7], ['food', 6], ['rare', 7], ['fest', 5]];
  const TR = {
    K: { n: '귀여운 생물', ic: '🥰' }, X: { n: '상어·가오리', ic: '🦈' }, W: { n: '신기한 생물', ic: '👽' }, P: { n: '화려한 빛깔', ic: '🌈' },
    J: { n: '해파리', ic: '🎐' }, B: { n: '커다란 생물', ic: '🐋' }, L: { n: '우리 토종', ic: '🏡' }, D: { n: '심해·극지', ic: '🌑' },
  };
  const TRK = Object.keys(TR);
  const DAYN = ['월', '화', '수', '목', '금', '토', '일'];
  const AGGR = ['순함', '보통', '사나움'];
  const PREDN = ['사냥 안 함', '작은 물고기를 잡아먹음', '작은 물고기·새우·게를 잡아먹음', '새우·게·조개를 잡아먹음'];
  const ROOM = 22;
  const MAXSL = 12;

  /* ===================== 공용 계산 ===================== */
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const rnd = (n) => Math.floor(Math.random() * n);
  const vfOf = (t) => Math.max(1, Math.pow(TK[t].v / 200, 0.75));
  const hasTag = (s, k) => (k === 'J' ? s.zone === 'jel' : k === 'B' ? s.size >= 100 : k === 'D' ? s.zone === 'deep' || s.zone === 'pole' : s.fl.includes(k));
  const isWeekend = (d) => d % 7 === 6 || d % 7 === 0;
  const dayName = (d) => DAYN[(d - 1) % 7];
  function won(v, short) {
    const neg = v < 0, a = Math.abs(v);
    let s;
    if (a >= 1e8) s = (a / 1e8).toFixed(a >= 1e9 ? 1 : 2).replace(/\.?0+$/, '') + '억';
    else if (a >= 1e4) s = Math.round(a / 1e4).toLocaleString('ko-KR') + '만';
    else s = Math.round(a).toLocaleString('ko-KR');
    return (neg ? '−' : '') + s + (short ? '' : '원');
  }
  const tLo = (tk) => (tk.e & CH ? 0 : 20), tHi = (tk) => (tk.e & HT ? 32 : 24);
  function loadOf(tk) { let s = 0; tk.g.forEach((g) => { s += g[1] * SP[g[0]].ld; }); return s; }
  function capOf(tk) { return TK[tk.t].v / 8 * [1, 1.5, 2][tk.f - 1] * ((tk.e & SK) && tk.S >= 20 ? 1.25 : 1); }
  function fitsSmall(prey, big) { return prey.size <= big.size * 0.35; }
  /* P가 Q를 잡아먹나 */
  function canEat(P, Q) {
    if (P === Q || P.land || Q.land) return false;
    if (Q.coral || Q.jelly) return false;
    if (!Q.inv) return (P.pred === 1 || P.pred === 2) && fitsSmall(Q, P);
    return (P.pred === 2 || P.pred === 3) && Q.size <= P.size * 0.6 && Q.key !== 'squirt';
  }
  const lineOf = (s) => `${s.tmin}~${s.tmax}℃ · ${salTxt(s.smin, s.smax)}`;
  function salTxt(a, b) { if (b <= 1) return '민물'; if (a >= 28) return '바닷물'; return `염도 ${a}~${b}‰`; }
  function salName(S) { return S <= 1 ? '민물' : S < 25 ? '기수' : '바닷물'; }

  /* q가 s를 괴롭히나: 사나운(2) 생물은 덩치가 절반 이상인 상대를, 보통(1) 생물은 1.5배 이상 작은 순한 물고기를. 산호는 안 괴롭힘 */
  function bullies(q, s) {
    if (q === s || s.coral) return false;
    if (q.aggr === 2) return s.aggr < 2 && q.size >= s.size * 0.5;
    if (q.aggr === 1) return s.aggr === 0 && !s.inv && q.size >= s.size * 1.5;
    return false;
  }
  /* 한 무리(g)가 이 수조에서 받는 스트레스: [{p: 깎이는 건강, w: 까닭, k: 종류}] */
  function stressOf(tk, gi, Ta) {
    const g = tk.g[gi], s = SP[g[0]], T = TK[tk.t], out = [];
    const temp = Ta == null ? tk.T : Ta;
    const dt = temp < s.tmin ? s.tmin - temp : temp > s.tmax ? temp - s.tmax : 0;
    if (dt > 0) out.push({ p: 4 + 7 * dt, w: temp < s.tmin ? `물이 너무 차가워요 (알맞은 온도 ${s.tmin}~${s.tmax}℃)` : `물이 너무 따뜻해요 (알맞은 온도 ${s.tmin}~${s.tmax}℃)`, k: 'temp' });
    const ds = tk.S < s.smin ? s.smin - tk.S : tk.S > s.smax ? tk.S - s.smax : 0;
    if (ds > 0) out.push({ p: 4 + 3.5 * ds, w: tk.S < s.smin ? `물이 너무 싱거워요 (${salTxt(s.smin, s.smax)})` : `물이 너무 짜요 (${salTxt(s.smin, s.smax)})`, k: 'sal' });
    if (s.minL > T.v) out.push({ p: Math.min(25, 4 + 8 * (s.minL / T.v - 1)), w: `수조가 너무 좁아요 (적어도 ${s.minL.toLocaleString()}L)`, k: 'size' });
    if (s.coral && !(tk.e & LT)) out.push({ p: 8, w: '산호 조명이 없어 빛이 모자라요', k: 'light' });
    if (s.jelly && !T.jel) out.push({ p: 20, w: '해파리 원형 수조가 아니라 몸이 다쳐요', k: 'tank' });
    if (s.hide && tk.c === 0) out.push({ p: 4, w: '숨을 곳이 없어요 (꾸밈 필요)', k: 'hide' });
    if (s.mud && tk.c !== 5) out.push({ p: 6, w: '갯벌 바닥이 필요해요', k: 'hide' });
    if (s.key === 'mandarin' && tk.c !== 1) out.push({ p: 6, w: '먹이(요각류)가 사는 산호 바위가 없어요', k: 'food' });
    if (s.school && g[1] < s.school) out.push({ p: 4, w: `무리가 작아 불안해요 (${s.school}마리 이상)`, k: 'school' });
    if (s.solo && g[1] > 1) out.push({ p: 15, w: '같은 종끼리 심하게 싸워요 (1마리만)', k: 'fight' });
    else if (s.terr && g[1] > 2) out.push({ p: Math.min(15, 4 * (g[1] - 2)), w: '같은 종끼리 자리 다툼을 해요 (2마리까지)', k: 'fight' });
    if (tk.q < 60) out.push({ p: (60 - tk.q) / 3, w: '물이 더러워요', k: 'water' });
    tk.g.forEach((o, j) => {
      if (j === gi) return;
      const q = SP[o[0]];
      if (bullies(q, s)) out.push({ p: (q.aggr - s.aggr) * 3 * (s.shy ? 2 : 1), w: `${q.ko}에게 괴롭힘을 당해요`, k: 'bully' });
      else if (s.shy && q.aggr >= 1 && !q.inv && q.size >= s.size * 0.5 && !s.coral) out.push({ p: 3, w: `${q.ko} 때문에 먹이를 못 먹어요`, k: 'bully' });
      if (q.nip && (s.coral || (s.inv && s.mv === 2) || s.key === 'clam' || s.key === 'bstar')) out.push({ p: 10, w: `${q.ko}가 쪼아 먹어요`, k: 'nip' });
    });
    return out;
  }
  /* 이 수조에 종 s를 넣으면? [{lv: 2 안 됨 | 1 주의, w}] — 화면 안내와 AI가 같이 쓴다 */
  function compat(tk, s, addN) {
    const T = TK[tk.t], out = [];
    const n = addN || 1;
    if (T.jel && s.zone !== 'jel') out.push({ lv: 2, w: '해파리 원형 수조에는 해파리만 넣어요' });
    if (s.jelly && !T.jel) out.push({ lv: 2, w: '해파리 원형 수조가 필요해요' });
    if (T.land && !s.land) out.push({ lv: 2, w: '물가 사육장에는 펭귄·해달·물범만 살아요' });
    if (s.land && !T.land) out.push({ lv: 2, w: '물가 사육장이 필요해요 (뭍과 물이 함께)' });
    const dt = tk.T < s.tmin ? s.tmin - tk.T : tk.T > s.tmax ? tk.T - s.tmax : 0;
    if (dt > 0) out.push({ lv: dt >= 3 ? 2 : 1, w: `온도가 안 맞아요 (${s.tmin}~${s.tmax}℃, 지금 ${tk.T}℃)` });
    const ds = tk.S < s.smin ? s.smin - tk.S : tk.S > s.smax ? tk.S - s.smax : 0;
    if (ds > 0) out.push({ lv: ds >= 5 ? 2 : 1, w: `염도가 안 맞아요 (${salTxt(s.smin, s.smax)}, 지금 ${tk.S}‰)` });
    if (s.minL > T.v) out.push({ lv: s.minL > T.v * 2 ? 2 : 1, w: `수조가 좁아요 (적어도 ${s.minL.toLocaleString()}L)` });
    if (s.coral && !(tk.e & LT)) out.push({ lv: 1, w: '산호 조명이 필요해요' });
    if (s.hide && tk.c === 0) out.push({ lv: 1, w: '숨을 곳이 필요해요 (꾸밈)' });
    if (s.mud && tk.c !== 5) out.push({ lv: 1, w: '갯벌 바닥이 필요해요' });
    if (s.key === 'mandarin' && tk.c !== 1) out.push({ lv: 1, w: '산호 바위 꾸밈이 필요해요 (먹이)' });
    const own = tk.g.find((g) => g[0] === s.i);
    const tot = (own ? own[1] : 0) + n;
    if (s.solo && tot > 1) out.push({ lv: 2, w: '같은 종끼리 싸워요 (1마리만)' });
    else if (s.terr && tot > 2) out.push({ lv: 1, w: '같은 종은 2마리까지' });
    if (s.school && tot < s.school) out.push({ lv: 1, w: `${s.school}마리 이상 무리로 넣어 주세요` });
    tk.g.forEach((g) => {
      const q = SP[g[0]];
      if (q === s) return;
      if (canEat(q, s)) out.push({ lv: 2, w: `${q.ko}에게 잡아먹혀요` });
      if (canEat(s, q)) out.push({ lv: 2, w: `${q.ko}를 잡아먹어요` });
      if (s.nip && (q.coral || (q.inv && q.mv === 2) || q.key === 'clam' || q.key === 'bstar')) out.push({ lv: 1, w: `${q.ko}를 쪼아 먹어요` });
      if (q.nip && (s.coral || (s.inv && s.mv === 2) || s.key === 'clam' || s.key === 'bstar')) out.push({ lv: 1, w: `${q.ko}가 쪼아 먹어요` });
      if (bullies(s, q)) out.push({ lv: 1, w: `${q.ko}를 괴롭혀요` });
      if (bullies(q, s)) out.push({ lv: 1, w: `${q.ko}에게 괴롭힘당해요` });
    });
    if (loadOf(tk) + s.ld * n > capOf(tk)) out.push({ lv: 1, w: '수조가 꽉 차요 (물이 빨리 더러워져요)' });
    return out;
  }
  const worst = (cs) => cs.reduce((m, c) => Math.max(m, c.lv), 0);

  /* 수조 하나의 전시 매력 */
  function tankTheme(tk) {
    if (!tk || !tk.g.length) return null;
    const z = SP[tk.g[0][0]].zone;
    if (!tk.g.every((g) => SP[g[0]].zone === z)) return null;
    const T = TK[tk.t];
    if (T.jel || T.land) { if (T.land && z !== 'pole') return null; return z; }
    if (tk.g.length < 2) return null;
    return tk.c === ZN[z].dec ? z : null;
  }
  function tankA(tk, trend) {
    if (!tk || !tk.g.length) return 0;
    let a = 0;
    tk.g.forEach((g) => {
      const s = SP[g[0]];
      const n = g[1];
      const cnt = s.school ? 1.3 * Math.pow(Math.min(n, 40), 0.45) : Math.pow(n, 0.5);
      let v = Math.pow(s.ap, 1.5) * cnt * (0.3 + 0.7 * g[2] / 100);
      if (trend && hasTag(s, trend)) v *= 1.6;
      a += v;
    });
    a *= Math.pow(TK[tk.t].v / 60, 0.22);
    if (tankTheme(tk)) a *= 1.35;
    if (tk.g.every((g) => SP[g[0]].fl.includes('L'))) a *= 1.1;
    if (tk.z > 0) a *= 0.8;
    if (tk.q < 40) a *= 0.85;
    return a;
  }
  function hallA(p, trend) {
    let a = 0;
    const sp = new Set(), th = new Set();
    p.tk.forEach((tk) => { if (!tk) return; a += tankA(tk, trend); tk.g.forEach((g) => sp.add(g[0])); const z = tankTheme(tk); if (z) th.add(z); });
    return a + sp.size * 2 + th.size * 8;
  }
  const speciesCount = (p) => { const s = new Set(); p.tk.forEach((tk) => tk && tk.g.forEach((g) => s.add(g[0]))); return s.size; };
  const tankCount = (p) => p.tk.filter(Boolean).length;
  const optPrice = (A) => 6000 + 300 * Math.sqrt(Math.max(0, A));
  function priceF(price, A, trip) { return clamp(Math.exp(-(trip ? 1.8 : 1.2) * (price / optPrice(A) - 1)), 0.05, 3); }
  const mkMult = (m) => 1 + 0.25 * (1 - Math.pow(0.7, m)) / 0.3;
  function assetsOf(p) {
    let v = 0;
    p.tk.forEach((tk) => {
      if (!tk) return;
      const vf = vfOf(tk.t);
      v += TK[tk.t].cost;
      EQ.forEach((e) => { if (tk.e & e.b) v += e.c * vf; });
      for (let f = 2; f <= tk.f; f++) v += FILT[f - 1] * vf;
      tk.g.forEach((g) => { v += SP[g[0]].price * g[1]; });
    });
    return v;
  }
  function scoreOf(s, p) {
    const worth = p.m + 0.5 * assetsOf(p);
    const wp = Math.round((worth - s.M0) / 1e6);
    const rp = Math.round(p.rep * 3);
    const ep = Math.round(Math.sqrt(Math.max(0, p.A || 0)) * 4);
    const dp = speciesCount(p) * 3;
    return { worth, wp, rp, ep, dp, tot: wp + rp + ep + dp };
  }
  function dailyCostEst(s, p) {
    let c = 0;
    p.st.forEach((n, r) => { c += n * ST[r].w; });
    p.tk.forEach((tk) => { if (tk) c += powerOf(tk) + foodOf(tk, 1); });
    return c;
  }
  function powerOf(tk) {
    const vf = vfOf(tk.t);
    return vf * (5000 + (tk.e & HT ? Math.max(0, tk.T - ROOM) * 3000 : 0) + (tk.e & CH ? Math.max(0, ROOM - tk.T) * 5000 : 0) + (tk.e & LT ? 10000 : 0) + (tk.e & SK ? 2000 : 0) + tk.f * 1000);
  }
  function foodOf(tk, mult) { let f = 0; tk.g.forEach((g) => { f += g[1] * SP[g[0]].ld * 300; }); return f * mult; }

  /* ===================== 시장 · 일정 ===================== */
  function genMarket(s) {
    const ev = s.ev[s.d];
    const mk = {};
    SP.forEach((sp) => {
      let pr, st;
      if (sp.rare) { pr = ev === 'rare' ? 0.6 : 0.14; st = 1 + rnd(2); }
      else if (sp.price > 100000) { pr = ev === 'rare' ? 0.8 : 0.45; st = 2 + rnd(3); }
      else if (sp.price > 20000) { pr = 0.7; st = 99; }
      else { pr = 1; st = 99; }
      if (s.d === 1 && sp.price <= 100000 && !sp.rare) pr = 1;
      if (Math.random() < pr) mk[sp.i] = st;
    });
    return mk;
  }
  function pickW(pool) { let t = 0; pool.forEach((x) => { t += x[1]; }); let r = Math.random() * t; for (const x of pool) { r -= x[1]; if (r <= 0) return x[0]; } return pool[0][0]; }

  /* ===================== init ===================== */
  function init(players, opts) {
    opts = opts || {};
    const D = clamp(+opts.days || 15, 5, 40);
    const M0 = { low: 20000000, mid: 40000000, high: 80000000 }[opts.money] || 40000000;
    const evOn = opts.ev !== 'off';
    const ev = [null, 'none'], tr = [null];
    for (let d = 2; d <= D + 1; d++) ev.push(evOn ? pickW(EV_POOL) : 'none');
    for (let d = 1; d <= D + 1; d++) tr.push(TRK[rnd(TRK.length)]);
    const s = {
      v: 1, d: 1, D, M0, ph: 'plan', ev, tr, mk: null, lid: 0, last: null,
      P: players.map((p) => ({ n: p.name, m: M0, m0: M0, rep: 30, tk: [null, null, null, null, null, null], sl: 6, st: [1, 0, 0, 0], pr: 10000, rd: 0, lg: [], rp: null, A: 0, tv: 0, ti: 0, dead: 0 })),
    };
    s.mk = genMarket(s);
    return s;
  }
  function actor(s) { return s.ph === 'plan' ? s.P.map((_, i) => i) : null; }

  /* ===================== 행동 ===================== */
  function pay(p, c) { if (p.m < c) throw new Error('돈이 모자라요'); p.m -= c; }
  function tankAt(p, k) { const tk = p.tk[k]; if (!tk) throw new Error('수조 없음'); return tk; }
  function doOp(s, seat, a) {
    const p = s.P[seat];
    switch (a.a) {
      case 'tank': {
        const k = a.k == null ? p.tk.findIndex((x, i) => !x && i < p.sl) : a.k;
        const t = a.t | 0;
        if (!TK[t] || k < 0 || k >= p.sl || p.tk[k]) throw new Error('자리 없음');
        if (TK[t].one && p.tk.some((x) => x && x.t === t)) throw new Error('1개만');
        pay(p, TK[t].cost);
        const z = a.z && ZN[a.z] ? a.z : null;
        p.tk[k] = { t, T: TK[t].land ? 20 : 22, S: 0, c: 0, e: 0, f: 1, q: 100, z: 0, g: [], d: s.d, pT: 22, pS: 0 };
        if (z) p.tk[k].az = z;
        return k;
      }
      case 'sell': {
        const tk = tankAt(p, a.k);
        const back = tk.d === s.d ? 1 : 0.5;
        let v = TK[tk.t].cost;
        const vf = vfOf(tk.t);
        EQ.forEach((e) => { if (tk.e & e.b) v += e.c * vf; });
        v *= back;
        tk.g.forEach((g) => { v += SP[g[0]].price * g[1] * (g[3] === s.d ? 1 : 0.5); });
        p.m += Math.round(v);
        p.tk[a.k] = null;
        return;
      }
      case 'temp': {
        const tk = tankAt(p, a.k);
        const v = Math.round(+a.v);
        if (!(v >= tLo(tk) && v <= tHi(tk))) throw new Error('온도 범위 밖');
        tk.T = v; return;
      }
      case 'sal': {
        const tk = tankAt(p, a.k);
        const v = Math.round(+a.v);
        if (!(v >= 0 && v <= 40)) throw new Error('염도 범위 밖');
        tk.S = v; return;
      }
      case 'dec': {
        const tk = tankAt(p, a.k);
        const v = a.v | 0;
        if (v < 0 || v >= DEC.length || v === tk.c) throw new Error('꾸밈');
        if (TK[tk.t].jel) throw new Error('해파리 수조는 꾸밈 없음');
        pay(p, v === 0 ? 0 : Math.round(50000 * vfOf(tk.t)));
        tk.c = v; return;
      }
      case 'eq': {
        const tk = tankAt(p, a.k);
        const e = EQ.find((x) => x.b === a.b);
        if (!e || (tk.e & e.b)) throw new Error('장비');
        pay(p, Math.round(e.c * vfOf(tk.t)));
        tk.e |= e.b; return;
      }
      case 'filt': {
        const tk = tankAt(p, a.k);
        if (tk.f >= 3) throw new Error('최고 단계');
        pay(p, Math.round(FILT[tk.f] * vfOf(tk.t)));
        tk.f++; return;
      }
      case 'buy': {
        const tk = tankAt(p, a.k);
        const sp = SP[a.s];
        const n = a.n | 0;
        if (!sp || n < 1 || n > 50) throw new Error('생물');
        const st = s.mk[sp.i];
        if (st == null || st < n) throw new Error('시장에 없음');
        if (TK[tk.t].jel && sp.zone !== 'jel') throw new Error('해파리만');
        if (TK[tk.t].land !== undefined && !!TK[tk.t].land !== sp.land) throw new Error('사육장');
        if (!TK[tk.t].land && sp.land) throw new Error('사육장 필요');
        pay(p, sp.price * n);
        if (st < 99) s.mk[sp.i] = st - n;
        const g = tk.g.find((x) => x[0] === sp.i);
        if (g) { g[2] = Math.round((g[2] * g[1] + 90 * n) / (g[1] + n)); g[1] += n; g[3] = s.d; }
        else { if (tk.g.length >= 12) throw new Error('한 수조에 12종까지'); tk.g.push([sp.i, n, 90, s.d]); }
        return;
      }
      case 'rm': {
        const tk = tankAt(p, a.k);
        const gi = tk.g.findIndex((x) => x[0] === a.s);
        if (gi < 0) throw new Error('없음');
        const g = tk.g[gi];
        const n = Math.min(g[1], Math.max(1, a.n | 0));
        p.m += Math.round(SP[g[0]].price * n * (g[3] === s.d ? 1 : 0.5));
        g[1] -= n;
        if (g[1] <= 0) tk.g.splice(gi, 1);
        return;
      }
      case 'staff': {
        const r = a.r | 0, d = a.d > 0 ? 1 : -1;
        if (!ST[r]) throw new Error('직원');
        const v = p.st[r] + d;
        if (v < 0 || v > 8) throw new Error('인원');
        p.st[r] = v; return;
      }
      case 'price': {
        const v = Math.round(+a.v / 1000) * 1000;
        if (!(v >= 3000 && v <= 60000)) throw new Error('가격');
        p.pr = v; return;
      }
      case 'expand': {
        if (p.sl >= MAXSL) throw new Error('더 못 넓혀요');
        pay(p, expandCost(p));
        p.sl += 2;
        while (p.tk.length < p.sl) p.tk.push(null);
        return;
      }
      default: throw new Error('모르는 행동');
    }
  }
  const expandCost = (p) => 10000000 * (1 + (p.sl - 6) / 2);

  function apply(s, seat, a) {
    if (s.ph !== 'plan' || !a) throw new Error('지금은 못 해요');
    const p = s.P[seat];
    if (!p) throw new Error('자리');
    if (a.a === 'plan') {
      if (p.rd) throw new Error('이미 준비');
      (a.ops || []).slice(0, 200).forEach((op) => { try { doOp(s, seat, op); } catch (e) { /* 시장이 바뀌었으면 건너뜀 */ } });
      p.rd = 1;
    } else if (a.a === 'ready') { p.rd = 1; }
    else if (a.a === 'unready') { p.rd = 0; }
    else { if (p.rd) throw new Error('준비를 취소하고 바꿔요'); doOp(s, seat, a); }
    if (s.P.every((q) => q.rd)) simDay(s);
    return s;
  }

  /* ===================== 하루 시뮬레이션 ===================== */
  function simDay(s) {
    const d = s.d, ev = s.ev[d] || 'none', trend = s.tr[d];
    const np = s.P.length;
    const R = s.P.map(() => ({ lg: [], dead: 0, eaten: 0, sick: 0, food: 0, power: 0 }));
    s.P.forEach((p, pi) => {
      const r = R[pi];
      const log = (t) => { if (r.lg.length < 14) r.lg.push(t); };
      let ti = 0;
      const keepCover = p.st[0] * 3, vetCover = p.st[1] * 4;
      p.tk.forEach((tk, k) => {
        if (!tk) return;
        ti++;
        const nm = `${k + 1}번 수조`;
        const kept = ti <= keepCover, vet = ti <= vetCover;
        let Ta = tk.T;
        if (ev === 'out' && !(tk.e & BK)) Ta += clamp(ROOM - Ta, -4, 4);
        if (ev === 'heat' && !(tk.e & CH)) Ta += 3;
        if (ev === 'cold' && !(tk.e & HT)) Ta -= 3;
        tk.Ta = Ta;
        const ld = loadOf(tk), cp = capOf(tk), ratio = ld / cp;
        const target = ratio <= 1 ? 100 - 35 * ratio : Math.max(0, 65 - 45 * (ratio - 1));
        let q = tk.q + (target - tk.q) * 0.5;
        if (!kept && tk.g.length) q -= 10;
        if (ev === 'out' && !(tk.e & BK)) q -= 15;
        if (tk.g.some((g) => SP[g[0]].graze)) q += 3;
        tk.q = Math.round(clamp(q, 0, 100));
        if (!kept && tk.g.length && tk.q < 70) log(`🧽 ${nm}: 사육사가 모자라 물갈이를 못 했어요`);
        // 병
        if (tk.z > 0) { tk.z = Math.max(0, tk.z - (vet ? 2 : 1)); if (!tk.z) log(`💊 ${nm}: 병이 나았어요`); }
        else if (tk.g.length) {
          let pr = 0.01 + Math.max(0, 70 - tk.q) / 250 + (ratio > 1 ? 0.05 : 0) + (tk.g.some((g) => g[3] === d) && !vet ? 0.03 : 0);
          if (ev === 'flu') pr *= 3;
          if (vet) pr *= 0.4;
          if (tk.g.some((g) => SP[g[0]].clean)) pr *= 0.6;
          if (Math.random() < pr) { tk.z = 3 + rnd(3); r.sick++; log(`🦠 ${nm}: 병이 돌기 시작했어요${vet ? '' : ' (수의사가 있으면 빨리 나아요)'}`); }
        }
        // 건강
        const why = {};
        tk.g.forEach((g, gi) => {
          const s0 = SP[g[0]];
          const st = stressOf(tk, gi, Ta);
          if (g[3] < d && (Math.abs(tk.T - tk.pT) > 3 || Math.abs(tk.S - tk.pS) > 5)) st.push({ p: 10, w: '물이 갑자기 바뀌어 놀랐어요', k: 'shock' });
          if (tk.z > 0) st.push({ p: 10 * (s0.care >= 3 ? 1.5 : 1), w: '병에 걸렸어요', k: 'sick' });
          let pen = 0; st.forEach((x) => { pen += x.p; });
          if (s0.care >= 3) pen *= 1.3;
          /* 건강은 「버틸 수 있는 수준」(100 − 스트레스×4) 쪽으로 움직인다. 작은 불편은 조금 낮은 건강으로 버티고, 큰 문제는 0 아래로 → 죽음 */
          const target = 100 - pen * 4;
          let nh = g[2] + (target - g[2]) * 0.4;
          if (vet && nh < target) nh += 3;
          g[2] = Math.round(clamp(nh, -50, 100));
          g[4] = target < -100 ? 1 : 0;   // 아주 나쁜 물(민물고기를 바닷물에 등) → 한꺼번에 많이 죽음
          if (st.length) { st.sort((x, y) => y.p - x.p); why[g[0]] = st[0].w; }
        });
        // 잡아먹기
        tk.g.forEach((P) => {
          tk.g.forEach((Q) => {
            if (P === Q || Q[1] <= 0 || P[1] <= 0) return;
            if (!canEat(SP[P[0]], SP[Q[0]])) return;
            let e = 0; for (let i = 0; i < P[1]; i++) if (Math.random() < 0.55) e++;
            e = Math.min(e, Q[1]);
            if (e) { Q[1] -= e; r.eaten += e; log(`🍴 ${nm}: ${SP[P[0]].ko}가 ${SP[Q[0]].ko} ${e}마리를 잡아먹었어요`); }
          });
        });
        // 죽음
        tk.g.forEach((g) => {
          let die = 0;
          if (g[1] > 0 && g[2] <= 0) { die = Math.min(g[1], Math.max(1, Math.ceil(g[1] * (g[4] ? 0.6 : 0.25)))); g[2] = 30; }
          else if (g[1] > 0 && g[2] < 25 && Math.random() < (25 - g[2]) / 60) die = 1;
          if (die) {
            g[1] -= die; r.dead += die;
            log(`💀 ${nm}: ${SP[g[0]].ko} ${die}마리가 죽었어요 — ${why[g[0]] || '몸이 약해졌어요'}`);
          } else if (g[1] > 0 && g[2] < 40 && why[g[0]]) log(`⚠️ ${nm}: ${SP[g[0]].ko} 상태가 나빠요 — ${why[g[0]]}`);
        });
        tk.g = tk.g.filter((g) => g[1] > 0);
        tk.g.forEach((g) => { g.length = 4; });
        r.food += foodOf(tk, ev === 'food' ? 2 : 1);
        r.power += powerOf(tk);
        tk.pT = tk.T; tk.pS = tk.S;
      });
      p.A = hallA(p, trend);
      p.tk.forEach((tk, k) => {
        if (!tk) return;
        const z = tankTheme(tk);
        if (z && tk.th !== z) log(`⭐ ${k + 1}번 수조: 「${ZN[z].th}」 테마 완성! 손님이 더 좋아해요`);
        tk.th = z || null;
      });
    });
    // 손님 나누기
    /* 손님: 수족관마다 올 만한 손님(pot) → 다른 수족관이 끄는 손님만큼 나눠 가짐 */
    let M = (1 + 0.03 * (d - 1));
    if (isWeekend(d)) M *= 1.35;
    M *= { rain: 1.25, trip: 1.3, fest: 1.4, cold: 0.85 }[ev] || 1;
    const W = s.P.map((p) => {
      if (!tankCount(p)) return 0;
      let w = (40 + 0.35 * Math.pow(Math.max(0, p.A), 0.85)) * (0.4 + p.rep / 80) * priceF(p.pr, p.A, ev === 'trip') * mkMult(p.st[3]) * M;
      if (ev === 'trip') w *= 1 + Math.min(speciesCount(p), 30) / 60 + Math.min(p.st[2], 2) * 0.1;
      return w;
    });
    const CAP = 3000 * M;
    const sumW = W.reduce((a, b) => a + b, 0);
    let bestTank = null;
    s.P.forEach((p, pi) => p.tk.forEach((tk, k) => { if (!tk) return; const a = tankA(tk, trend); if (!bestTank || a > bestTank.a) bestTank = { a, pi, k }; }));
    s.P.forEach((p, pi) => {
      const r = R[pi];
      const vis = Math.round(W[pi] / (1 + (sumW - W[pi]) / CAP));
      const sickT = p.tk.filter((tk) => tk && tk.z > 0).length;
      const themes = new Set(p.tk.map(tankTheme).filter(Boolean)).size;
      const fair = Math.log(optPrice(p.A) / p.pr);
      let sat = 55 + 25 * Math.tanh(1.5 * fair) + Math.min(12, p.st[2] * 4) * (ev === 'trip' ? 1.5 : 1) + 3 * Math.min(themes, 4) - 5 * sickT - 2 * Math.min(6, r.dead + r.eaten);
      if (vis > p.tk.reduce((a, tk) => a + (tk ? 20 * Math.sqrt(TK[tk.t].v) : 0), 0)) sat -= 10;   // 붐빔
      sat = clamp(Math.round(sat), 0, 100);
      const ticket = vis * p.pr;
      const shop = Math.round(vis * (1200 + 30 * sat) * (1 + 0.15 * Math.min(p.st[2], 3)));
      const wages = p.st.reduce((a, n, i) => a + n * ST[i].w, 0);
      const food = Math.round(r.food), power = Math.round(r.power);
      const mBefore = p.m;
      p.m += ticket + shop - food - power - wages;
      let dr = (sat - 55) / 6 - Math.min(8, 0.7 * (r.dead + r.eaten));
      if (!tankCount(p)) dr = -1;
      if (ev === 'tv' && bestTank && bestTank.pi === pi) { dr += 8; r.lg.unshift(`📺 방송에 ${bestTank.k + 1}번 수조가 나왔어요! 평판 +8`); }
      dr = clamp(dr, -10, 12);
      const rep0 = p.rep;
      p.rep = clamp(Math.round((p.rep + dr) * 10) / 10, 0, 100);
      if (p.m < 0) r.lg.unshift('🚨 돈이 마이너스예요! 생물을 팔거나 직원을 줄여 보세요');
      p.tv += vis; p.ti += ticket + shop; p.dead += r.dead + r.eaten;
      p.rp = { d, vis, ticket, shop, food, power, wages, buy: p.m0 - mBefore, net: p.m - p.m0, sat, rep: Math.round((p.rep - rep0) * 10) / 10, A: Math.round(p.A), dead: r.dead, eaten: r.eaten, ev };
      p.lg = r.lg;
    });
    s.last = { id: ++s.lid, d };
    if (d >= s.D) {
      s.ph = 'end';
      s.P.forEach((p) => { p.sc = scoreOf(s, p); });
    } else {
      s.d = d + 1;
      s.mk = genMarket(s);
      s.P.forEach((p) => { p.rd = 0; p.m0 = p.m; });
    }
  }

  /* ===================== AI ===================== */
  function aiStyle(seat) { return (L.aiStyle && L.aiStyle(seat)) || 'bal'; }
  function aiPlan(s0, seat, lv) {
    const s = U.clone(s0), p = s.P[seat], ops = [];
    const sty = aiStyle(seat);
    const tryOp = (op) => { try { const r = doOp(s, seat, op); ops.push(op); return r == null ? true : r; } catch (e) { return false; } };
    const today = s.ev[s.d], trend = s.tr[s.d];
    const reserveDays = { agg: 2, def: 5, gamble: 2, bal: 3 }[sty] || 3;
    const reserve = () => dailyCostEst(s, p) * reserveDays + 1000000;
    const free = () => p.m - reserve();
    const noise = lv === 1 ? 0.6 : lv === 2 ? 0.25 : 0.08;
    const zoneOf = (tk) => {
      if (tk.az) return tk.az;
      const c = {}; tk.g.forEach((g) => { const z = SP[g[0]].zone; c[z] = (c[z] || 0) + 1; });
      let b = null; Object.keys(c).forEach((z) => { if (!b || c[z] > c[b]) b = z; });
      return b;
    };
    // 1) 문제 있는 무리 빼기
    {
      p.tk.forEach((tk, k) => {
        if (!tk) return;
        tk.g.slice().forEach((g, gi) => {
          const st = stressOf(tk, tk.g.indexOf(g));
          const pen = st.reduce((a, x) => a + (x.k === 'water' || x.k === 'sick' ? 0 : x.p), 0);
          if (pen >= [0, 16, 12, 10][lv] && g[2] < [0, 35, 55, 65][lv]) tryOp({ a: 'rm', k, s: g[0], n: g[1] });
        });
        if (lv >= 2) tk.g.slice().forEach((P) => tk.g.forEach((Q) => { if (P !== Q && canEat(SP[P[0]], SP[Q[0]])) tryOp({ a: 'rm', k, s: P[0], n: P[1] }); }));
      });
    }
    // 2) 장비 맞추기 · 온도·염도 맞추기
    const fitTank = (tk, k) => {
      const z = zoneOf(tk);
      if (!z) return;
      if (tk.g.length) {
        let lo = -99, hi = 99, slo = 0, shi = 40;
        tk.g.forEach((g) => { const q = SP[g[0]]; lo = Math.max(lo, q.tmin); hi = Math.min(hi, q.tmax); slo = Math.max(slo, q.smin); shi = Math.min(shi, q.smax); });
        const tt = lo <= hi ? Math.round((lo + hi) / 2) : ZN[z].T;
        const ss = slo <= shi ? clamp(ZN[z].S, slo, shi) : ZN[z].S;
        if (tt > 24 && !(tk.e & HT)) tryOp({ a: 'eq', k, b: HT });
        if (tt < 20 && !(tk.e & CH)) tryOp({ a: 'eq', k, b: CH });
        if (tk.T !== clamp(tt, tLo(tk), tHi(tk))) tryOp({ a: 'temp', k, v: clamp(tt, tLo(tk), tHi(tk)) });
        if (tk.S !== ss) tryOp({ a: 'sal', k, v: ss });
      } else {
        const tt = ZN[z].T;
        if (tt > 24 && !(tk.e & HT)) tryOp({ a: 'eq', k, b: HT });
        if (tt < 20 && !(tk.e & CH)) tryOp({ a: 'eq', k, b: CH });
        tryOp({ a: 'temp', k, v: clamp(tt, tLo(tk), tHi(tk)) });
        tryOp({ a: 'sal', k, v: ZN[z].S });
      }
      if (!TK[tk.t].jel && !TK[tk.t].land && tk.c !== ZN[z].dec && (lv >= 2 || Math.random() < 0.5)) tryOp({ a: 'dec', k, v: ZN[z].dec });
      if ((z === 'reef' || tk.g.some((g) => SP[g[0]].coral)) && !(tk.e & LT) && free() > 0) tryOp({ a: 'eq', k, b: LT });
      if (lv >= 2 && tk.S >= 20 && !(tk.e & SK) && loadOf(tk) > capOf(tk) * 0.6 && free() > 0) tryOp({ a: 'eq', k, b: SK });
      if (lv >= 2 && loadOf(tk) > capOf(tk) * 0.75 && tk.f < 3 && free() > FILT[tk.f] * vfOf(tk.t)) tryOp({ a: 'filt', k });
      if (lv === 3 && s.ev[s.d] === 'out' && !(tk.e & BK) && tk.g.length && free() > 0) tryOp({ a: 'eq', k, b: BK });
    };
    p.tk.forEach((tk, k) => { if (tk) fitTank(tk, k); });
    // 3) 새 수조
    const nt = () => tankCount(p);
    const used = new Set(p.tk.filter(Boolean).map(zoneOf).filter(Boolean));
    const mkList = Object.keys(s.mk).map(Number).filter((i) => s.mk[i] > 0);
    for (let tries = 0; tries < 2; tries++) {
      if (p.tk.findIndex((x, i) => !x && i < p.sl) < 0) break;
      const budget = free() * (sty === 'agg' || sty === 'gamble' ? 0.75 : 0.6);
      if (budget < TK[0].cost * 3) break;
      const opts = [];
      TK.forEach((T, t) => {
        if (T.cost > budget * 0.7) return;
        if (T.one && p.tk.some((x) => x && x.t === t)) return;
        ZK.forEach((z) => {
          if (T.jel && z !== 'jel') return;
          if (T.land && z !== 'pole') return;
          if (!T.jel && !T.land && z === 'jel') return;
          const cands = mkList.map((i) => SP[i]).filter((q) => q.zone === z && q.minL <= T.v && (!!T.land === q.land) && (T.jel ? true : !q.jelly) && q.price * (q.school || 1) < budget - T.cost);
          if (!cands.length) return;
          let val = cands.reduce((a, q) => a + Math.pow(q.ap, 1.5), 0) / Math.sqrt(cands.length) * Math.pow(T.v / 60, 0.22) * Math.min(4, cands.length) / 4;
          if (used.has(z)) val *= 0.5;
          if (trend && cands.some((q) => hasTag(q, trend))) val *= 1.15;
          val *= 1 - noise / 2 + Math.random() * noise;
          val /= Math.pow(T.cost, lv === 3 ? 0.18 : 0.12);
          opts.push({ t, z, val });
        });
      });
      if (!opts.length) break;
      opts.sort((a, b) => b.val - a.val);
      const o = lv === 1 && Math.random() < 0.4 ? opts[rnd(opts.length)] : opts[0];
      const k = tryOp({ a: 'tank', t: o.t, z: o.z });
      if (k === false) break;
      used.add(o.z);
      fitTank(p.tk[k], k);
    }
    // 4) 생물 채우기
    const fillTo = lv === 1 ? 1.05 : lv === 2 ? 0.85 : 0.8;
    p.tk.forEach((tk, k) => {
      if (!tk) return;
      const z = zoneOf(tk);
      for (let it = 0; it < 6; it++) {
        if (free() <= 0) return;
        const room = capOf(tk) * fillTo - loadOf(tk);
        if (room <= 0) return;
        let cands = mkList.map((i) => SP[i]).filter((q) => (s.mk[q.i] || 0) > 0 && (lv === 1 && Math.random() < 0.15 ? true : !z || q.zone === z));
        const scored = [];
        cands.forEach((q) => {
          let n = q.school ? (q.school === 6 ? 8 + (lv === 3 ? 4 : 0) : 4) : q.solo ? 1 : q.terr ? 2 : q.size < 12 ? 3 : q.size < 40 ? 2 : 1;
          const own = tk.g.find((g) => g[0] === q.i);
          if (own) { if (q.solo || (q.terr && own[1] >= 2)) return; n = q.school ? Math.max(0, q.school + 4 - own[1]) : 1; if (!n || own[1] >= 12) return; }
          n = Math.min(n, s.mk[q.i]);
          while (n > 1 && q.ld * n > room) n--;
          if (n < 1 || q.ld * n > room * 1.2) return;
          if (q.price * n > free()) return;
          const cs = compat(tk, q, n);
          const w = worst(cs);
          if (w === 2 && !(lv === 1 && Math.random() < 0.04)) return;
          if (lv >= 2 && cs.some((c) => c.lv === 1 && !/꽉 차/.test(c.w) && !(lv === 2 && /조명|숨을|갯벌/.test(c.w)))) return;
          let val = Math.pow(q.ap, 1.5) * (q.school ? 1.3 * Math.pow(n, 0.45) : Math.pow(n, 0.5)) * (trend && hasTag(q, trend) ? 1.3 : 1);
          val /= Math.pow(q.price * n + 20000, sty === 'gamble' ? 0.15 : 0.3);
          val *= 1 - noise / 2 + Math.random() * noise;
          if (q.care === 3 && lv < 3) val *= 0.6;
          scored.push({ q, n, val });
        });
        if (!scored.length) return;
        scored.sort((a, b) => b.val - a.val);
        const c = scored[0];
        if (!tryOp({ a: 'buy', k, s: c.q.i, n: c.n })) return;
        if (!tk.az) tk.az = c.q.zone;
        fitTank(tk, k);
      }
    });
    // 5) 직원
    const n2 = nt();
    const want = [Math.max(1, Math.ceil(n2 / 3)), lv === 1 ? 0 : n2 >= 3 ? Math.ceil(n2 / 4) + (lv === 3 && s.ev[s.d + 1] === 'flu' ? 1 : 0) : 0,
      n2 >= 4 ? (lv === 3 && today === 'trip' ? 2 : 1) : 0, lv >= 2 && p.m > 30000000 ? (lv === 3 ? 2 : 1) : 0];
    want.forEach((w, r) => { let g = 0; while (p.st[r] < w && g++ < 8) tryOp({ a: 'staff', r, d: 1 }); while (p.st[r] > w && g++ < 16) tryOp({ a: 'staff', r, d: -1 }); });
    // 6) 넓히기
    if (lv >= 2 && p.tk.findIndex((x, i) => !x && i < p.sl) < 0 && p.sl < MAXSL && free() > expandCost(p) * 2.5) tryOp({ a: 'expand' });
    // 7) 입장료
    const A = hallA(p, trend);
    let pr = optPrice(A) * (lv === 3 ? (np(s) > 1 ? 0.95 : 1.02) : 1);
    if (today === 'trip') pr *= 0.9;
    pr *= 1 - noise / 2 + Math.random() * noise;
    if (lv === 1 && Math.random() < 0.3) pr = 7000 + rnd(14) * 1000;
    tryOp({ a: 'price', v: clamp(Math.round(pr / 1000) * 1000, 3000, 60000) });
    return { a: 'plan', ops };
  }
  const np = (s) => s.P.length;

  /* ===================== 결과 ===================== */
  /* 등급: 15일 기준 S 1400 · A 1100 · B 800 · C 500 (기간이 길수록 돈이 불어나니 (기간/15)^1.4 배) */
  function grade(sc, D) { const k = Math.pow(D / 15, 1.4); return sc >= 1400 * k ? 'S' : sc >= 1100 * k ? 'A' : sc >= 800 * k ? 'B' : sc >= 500 * k ? 'C' : 'D'; }
  function result(s) {
    if (s.ph !== 'end') return null;
    const sc = s.P.map((p) => (p.sc || scoreOf(s, p)).tot);
    const best = Math.max(...sc);
    const winners = sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const solo = s.P.length === 1;
    const S = s.P.map((p) => p.sc || scoreOf(s, p));
    const hl = [];
    let bt = null;
    s.P.forEach((p, pi) => p.tk.forEach((tk, k) => { if (!tk) return; const a = tankA(tk, null); if (!bt || a > bt.a) bt = { a, pi, k, z: tankTheme(tk) }; }));
    if (bt) hl.push(`가장 멋진 수조: ${s.P[bt.pi].n}의 ${bt.k + 1}번 수조${bt.z ? ` (「${ZN[bt.z].th}」)` : ''}`);
    const most = s.P.reduce((b, p, i) => (speciesCount(p) > speciesCount(s.P[b]) ? i : b), 0);
    hl.push(`가장 많은 종: ${s.P[most].n} ${speciesCount(s.P[most])}종`);
    return {
      winners,
      title: solo ? `${grade(best, s.D)} 등급 수족관!` : `${winners.map((i) => s.P[i].n).join(', ')} 우승!`,
      text: solo ? `${s.D}일 동안 점수 ${best}점` : `${s.D}일 경영 끝 — 최고 점수 ${best}점`,
      highlights: hl,
      stats: [
        { label: '점수', values: S.map((x) => x.tot) },
        { label: '순자산 점수', values: S.map((x) => x.wp) },
        { label: '평판 점수', values: S.map((x) => x.rp) },
        { label: '전시 점수', values: S.map((x) => x.ep) },
        { label: '종 다양성 점수', values: S.map((x) => x.dp) },
        { label: '누적 손님', values: s.P.map((p) => p.tv), unit: '명' },
        { label: '잃은 생물', values: s.P.map((p) => p.dead), low: true, unit: '마리' },
      ],
    };
  }

  /* ===================== 상황 도움말 ===================== */
  function problemsOf(p) {
    const out = [];
    p.tk.forEach((tk, k) => {
      if (!tk) return;
      let bad = 0, warn = 0;
      tk.g.forEach((g, gi) => { const st = stressOf(tk, gi); const pen = st.reduce((a, x) => a + x.p, 0); if (pen >= 10) bad++; else if (pen > 0) warn++; });
      if (tk.z > 0) out.push({ k, lv: 2, t: `${k + 1}번 수조에 병이 돌아요` });
      if (bad) out.push({ k, lv: 2, t: `${k + 1}번 수조: 힘들어하는 생물 ${bad}종` });
      else if (warn) out.push({ k, lv: 1, t: `${k + 1}번 수조: 조금 불편한 생물 ${warn}종` });
      if (loadOf(tk) > capOf(tk)) out.push({ k, lv: 1, t: `${k + 1}번 수조가 꽉 찼어요 (여과기·수조 키우기)` });
    });
    return out;
  }
  function hint(s, seat) {
    if (s.ph !== 'plan') return null;
    const p = s.P[seat >= 0 ? seat : 0];
    const lines = [`${s.d}일째(${dayName(s.d)}) 계획 중 — 오늘: ${EV[s.ev[s.d]].ic} ${EV[s.ev[s.d]].n}`];
    if (!tankCount(p)) lines.push('빈 칸 「＋ 수조 놓기」로 수조부터 사세요. 처음엔 중형 수조가 무난해요.');
    else if (!p.tk.some((tk) => tk && tk.g.length)) lines.push('수조를 눌러 「＋ 생물 넣기」로 생물을 넣어요. ✓ 표시가 잘 맞는 생물이에요.');
    problemsOf(p).slice(0, 3).forEach((x) => lines.push((x.lv === 2 ? '❗ ' : '⚠️ ') + x.t));
    const nx = s.ev[s.d + 1];
    if (nx && s.d < s.D) lines.push(`내일 예보: ${EV[nx].ic} ${EV[nx].n} — ${EV[nx].d}`);
    lines.push('다 했으면 ▶ 하루 시작. 모두 누르면 하루가 지나가요.');
    return lines.slice(0, 6);
  }

  /* ===================== 화면 ===================== */
  const CSS = `
.aq{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 80% at 50% 0%,#123a5a 0%,#081a2b 55%,#050e18 100%);color:var(--ink);font-family:var(--f-body);overflow:hidden;-webkit-user-select:none;user-select:none}
.aq button{font-family:inherit}
.aq-top{flex:none;padding:6px 56px 4px 8px;display:flex;flex-direction:column;gap:5px}
.aq-stats{display:flex;gap:5px;align-items:center;overflow:hidden}
.aq-pill{display:inline-flex;align-items:center;gap:3px;padding:3px 8px;border-radius:999px;background:rgba(255,255,255,.09);font-size:12.5px;white-space:nowrap;flex:none}
.aq-pill b{font-family:var(--f-mono);font-weight:600}
.aq-pill.neg b{color:var(--coral)}
.aq-ev{display:flex;gap:5px;overflow-x:auto;scrollbar-width:none;margin-right:-48px;padding-right:8px}
.aq-ev::-webkit-scrollbar{display:none}
.aq-chip{flex:none;min-height:32px;padding:3px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.06);color:inherit;font-size:12px;cursor:pointer;white-space:nowrap}
.aq-chip.on{background:var(--brass);color:#1b1206;border-color:var(--brass);font-weight:700}
.aq-who{flex:none;margin:0 8px 4px;padding:6px 10px;border-radius:10px;background:rgba(227,174,69,.16);border:1px solid rgba(227,174,69,.4);font-size:13px;display:flex;gap:8px;align-items:center;justify-content:space-between}
.aq-main{flex:1;overflow-y:auto;padding:4px 8px 12px;display:grid;grid-template-columns:1fr 1fr;gap:8px;align-content:start;grid-auto-rows:max-content;overscroll-behavior:contain}
.aq-card{position:relative;border-radius:12px;overflow:hidden;background:#0b2436;border:1px solid rgba(255,255,255,.13);cursor:pointer;min-height:44px;text-align:left;padding:0;color:inherit}
.aq-card canvas{display:block;width:100%;aspect-ratio:16/10;background:#082033}
.aq-cf{padding:4px 7px 6px;font-size:12px;line-height:1.35}
.aq-cf .nm{display:flex;gap:4px;align-items:center;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aq-cf .sub{color:var(--muted);font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aq-badge{position:absolute;top:5px;left:5px;display:flex;gap:3px}
.aq-badge span{background:rgba(0,0,0,.55);border-radius:8px;padding:1px 5px;font-size:11.5px}
.aq-card.empty{display:flex;align-items:center;justify-content:center;flex-direction:column;gap:4px;aspect-ratio:16/12.5;border-style:dashed;background:rgba(255,255,255,.03);font-size:13px;color:var(--muted)}
.aq-card.empty b{font-size:24px;color:var(--ink)}
.aq-card.lock{opacity:.8}
.aq-bot{flex:none;display:flex;gap:6px;padding:6px 8px calc(6px + env(safe-area-inset-bottom,0px));background:rgba(0,0,0,.4);border-top:1px solid rgba(255,255,255,.08)}
.aq-bot .btn{min-height:50px;padding:4px 4px;font-size:12.5px;flex:1;flex-direction:column;gap:0;line-height:1.15}
.aq-bot .btn i{font-style:normal;font-size:18px}
.aq-bot .aq-go{flex:1.7;font-size:15px}
.aq-sheet{position:absolute;inset:0;z-index:20;background:#081a29;display:flex;flex-direction:column}
.aq-sh-h{flex:none;display:flex;align-items:center;gap:6px;padding:6px 56px 6px 6px;min-height:56px;border-bottom:1px solid rgba(255,255,255,.08)}
.aq-sh-h h3{margin:0;flex:1;min-width:0;font-family:var(--f-display);font-size:19px;font-weight:400;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aq-back{flex:none;min-width:44px;height:44px;border-radius:12px;border:0;background:rgba(255,255,255,.09);color:inherit;font-size:22px;cursor:pointer}
.aq-sh-b{flex:1;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:10px;overscroll-behavior:contain}
.aq-sh-b>*{flex:none}
.aq-sh-f{flex:none;padding:8px 10px calc(8px + env(safe-area-inset-bottom,0px));display:flex;gap:8px;border-top:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.25)}
.aq-sh-f .btn{flex:1;min-height:48px}
.aq-big{width:100%;aspect-ratio:16/9;border-radius:12px;display:block;background:#082033;border:1px solid rgba(255,255,255,.12)}
.aq-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.aq-row .lab{min-width:44px;color:var(--muted);font-size:13px}
.aq-step{display:inline-flex;align-items:center;gap:4px}
.aq-step .btn{min-width:44px;min-height:44px;padding:0 10px;font-size:18px}
.aq-step b{min-width:58px;text-align:center;font-family:var(--f-mono);font-size:17px}
.aq-box{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:9px 10px;display:flex;flex-direction:column;gap:8px}
.aq-box h4{margin:0;font-size:14px;display:flex;justify-content:space-between;gap:6px;align-items:center}
.aq-box h4 small{font-weight:400;color:var(--muted);font-size:12px}
.aq-chips{display:flex;gap:6px;flex-wrap:wrap}
.aq-chips .btn{min-height:44px;padding:4px 10px;font-size:13px;font-weight:600}
.aq-chips .btn.on{background:var(--brass);color:#1b1206;border-color:var(--brass)}
.aq-chips .btn.own{background:rgba(110,200,140,.18);border-color:rgba(110,200,140,.5)}
.aq-hscroll{display:flex;gap:6px;overflow-x:auto;padding-bottom:2px;scrollbar-width:thin}
.aq-hscroll .btn{flex:none}
.aq-sp{display:flex;gap:8px;align-items:center;padding:6px;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)}
.aq-sp .pic{flex:none;width:68px;height:46px;border-radius:9px;background-color:rgba(120,180,220,.12);cursor:pointer;display:flex;align-items:center;justify-content:center;overflow:hidden}
.aq-sp .tx{flex:1;min-width:0;font-size:12.5px;line-height:1.35}
.aq-sp .tx b{font-size:14px}
.aq-sp .tx .m{color:var(--muted);font-size:11.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.aq-sp .tx .w{font-size:11.5px}
.aq-sp .bt{flex:none;display:flex;gap:4px}
.aq-sp .bt .btn{min-width:44px;min-height:44px;padding:0 8px;font-size:13px}
.aq-ok{color:#7fdc9a}.aq-warn{color:#f2c45a}.aq-bad{color:#ff8a7a}
.aq-bar{height:6px;border-radius:3px;background:rgba(255,255,255,.12);overflow:hidden;margin-top:3px}
.aq-bar i{display:block;height:100%;border-radius:3px}
.aq-kv{display:grid;grid-template-columns:1fr auto;gap:3px 10px;font-size:13.5px}
.aq-kv span:nth-child(2n){font-family:var(--f-mono);text-align:right}
.aq-log{font-size:13px;line-height:1.5;display:flex;flex-direction:column;gap:3px}
.aq-note{font-size:12.5px;color:var(--muted);line-height:1.5;margin:0}
.aq-day{position:absolute;inset:0;z-index:25;background:rgba(3,10,20,.82);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;pointer-events:none}
.aq-day .sun{font-size:44px}
.aq-day h2{margin:0;font-family:var(--f-display);font-weight:400;font-size:26px}
.aq-day .prog{width:70%;height:8px;border-radius:4px;background:rgba(255,255,255,.15);overflow:hidden}
.aq-day .prog i{display:block;height:100%;width:0;background:var(--brass)}
.aq-day .crowd{font-size:20px;letter-spacing:2px;height:28px;overflow:hidden;width:80%;text-align:center}
.aq-day .cnt{font-family:var(--f-mono);font-size:22px}
.aq-rank{display:flex;flex-direction:column;gap:6px}
.aq-rk{display:flex;gap:8px;align-items:center;padding:8px;border-radius:12px;background:rgba(255,255,255,.05);min-height:44px;border:1px solid transparent;cursor:pointer;color:inherit;text-align:left;width:100%}
.aq-rk.me{border-color:rgba(227,174,69,.6)}
.aq-rk .sc{font-family:var(--f-mono);font-size:18px;margin-left:auto}
.aq-cx{display:flex;width:66px;height:44px;align-items:center;justify-content:center}
.cx-row:has(.aq-cx) .cx-ic{width:72px;height:50px;background:rgba(120,180,220,.12)}
.aq-pop{position:absolute;inset:0;z-index:30;background:rgba(0,0,0,.55);display:flex;align-items:flex-end;justify-content:center}
.aq-pop>div{width:100%;max-width:520px;max-height:85%;overflow-y:auto;background:#0d2335;border-radius:16px 16px 0 0;padding:12px;display:flex;flex-direction:column;gap:8px}
.aq-pop .pic{width:100%;height:150px;display:flex;align-items:center;justify-content:center;background-color:rgba(120,180,220,.1);border-radius:12px}
`;
  function injectCSS() {
    if (document.getElementById('aq-css')) return;
    const st = document.createElement('style');
    st.id = 'aq-css'; st.textContent = CSS;
    document.head.appendChild(st);
  }

  /* 그림 */
  const IMG = { sp: null, bg: null, ok: false, bgok: false };
  function loadImgs() {
    if (IMG.sp) return;
    IMG.sp = new Image(); IMG.sp.onload = () => { IMG.ok = true; }; IMG.sp.src = ASSET + 'sp.webp' + (ATL.v ? '?v=' + ATL.v : '');
    IMG.bg = new Image(); IMG.bg.onload = () => { IMG.bgok = true; }; IMG.bg.src = ASSET + 'bg.webp' + (ATL.v ? '?v=' + ATL.v : '');
  }
  /* DOM 그림(배경 이미지로 아틀라스 한 칸) */
  /* 그림 칸 하나만 딱 맞는 크기의 안쪽 요소(옆 그림이 비치지 않게), 모두 오른쪽을 보도록 */
  function picCss(s, W, H) {
    const [x, y, w, hh] = s.box;
    if (!w) return 'display:none';
    const k = Math.min(W / w, H / hh);
    return `display:block;width:${(w * k).toFixed(1)}px;height:${(hh * k).toFixed(1)}px;background:url(${ASSET}sp.webp${ATL.v ? '?v=' + ATL.v : ''}) ${(-x * k).toFixed(1)}px ${(-y * k).toFixed(1)}px/${(ATL.w * k).toFixed(1)}px ${(ATL.h * k).toFixed(1)}px no-repeat;${s.flip ? 'transform:scaleX(-1)' : ''}`;
  }
  function picBox(s, W, H, onclick) {
    const box = h('div', { class: 'pic', onclick });
    box.innerHTML = `<i style="${picCss(s, W, H)}"></i>`;
    return box;
  }

  /* 수조 그리기 — 물고기 움직임은 화면에서만(상태와 무관한 장식) */
  const BGW = 480, BGH = 300;   // bg.webp: 꾸밈 1~7번 배경 사진을 세로로
  function makeSwim(tk) {
    const T = TK[tk.t], f = [];
    tk.g.forEach((g) => {
      const s = SP[g[0]];
      const tiny = s.size < 8;
      const n = Math.min(g[1], s.mv === 2 ? 3 : tiny ? 14 : s.size < 25 ? 8 : 4);
      for (let i = 0; i < n; i++) {
        const fx = { s, x: 0.1 + Math.random() * 0.8, y: 0.15 + Math.random() * 0.65, vx: (Math.random() < 0.5 ? -1 : 1), vy: 0, ty: 0.2 + Math.random() * 0.6, ph: Math.random() * 6.28, sp: 0.5 + Math.random() * 0.6, land: false };
        if (s.mv === 1 || s.mv === 2) fx.y = 0.84 + Math.random() * 0.08;
        if (s.mv === 2) { fx.x = 0.08 + ((i * 0.37 + g[0] * 0.13) % 0.84); fx.vx = 1; }
        if (s.mv === 5 && i % 2 === 0) { fx.land = true; fx.x = 0.06 + Math.random() * 0.34; fx.y = 0.26; }
        f.push(fx);
      }
    });
    f.sort((a, b) => (a.s.mv === 2 ? -1 : 0) - (b.s.mv === 2 ? -1 : 0));
    return { sig: sigOf(tk), f, T, bub: Array.from({ length: 6 }, () => ({ x: Math.random(), y: Math.random(), s: 0.5 + Math.random() })) };
  }
  const sigOf = (tk) => tk.t + ':' + tk.c + ':' + tk.g.map((g) => g[0] + 'x' + g[1]).join(',');
  function stepSwim(sw, dt) {
    sw.f.forEach((f) => {
      const s = f.s;
      f.ph += dt * (s.mv === 3 ? 1.6 : 3) * f.sp;
      if (s.mv === 2) return;
      if (f.land) { if (Math.random() < dt * 0.05) { f.land = false; f.y = 0.45; } return; }
      const spd = s.mv === 0 ? (0.03 + 0.05 / Math.sqrt(Math.max(2, s.size) / 4)) * f.sp : s.mv === 1 ? 0.012 * f.sp : s.mv === 3 ? 0.008 : s.mv === 4 ? 0.012 : 0.05;
      f.x += f.vx * spd * dt;
      if (f.x < 0.06) { f.x = 0.06; f.vx = 1; } else if (f.x > 0.94) { f.x = 0.94; f.vx = -1; }
      if (Math.random() < dt * 0.15) f.vx = -f.vx;
      if (s.mv === 0 || s.mv === 4 || s.mv === 5) {
        if (Math.random() < dt * 0.3) f.ty = 0.18 + Math.random() * 0.62;
        f.y += (f.ty - f.y) * dt * 0.4;
        if (s.mv === 5 && sw.T.land && f.x < 0.42 && f.y < 0.45 && Math.random() < dt * 0.1) { f.land = true; f.y = 0.26; }
      } else if (s.mv === 3) { f.y = clamp(f.y + Math.sin(f.ph * 0.5) * dt * 0.02, 0.12, 0.8); }
    });
    sw.bub.forEach((b) => { b.y -= dt * 0.12 * b.s; if (b.y < 0) { b.y = 1; b.x = Math.random(); } });
  }
  function drawTank(ctx, W, H, tk, sw, t, big) {
    ctx.save();
    const T = TK[tk.t];
    const z = tankTheme(tk) || (tk.g.length ? SP[tk.g[0][0]].zone : null);
    const zc = z ? ZN[z] : { c1: tk.S > 20 ? '#1e6d98' : '#3c6a52', c2: '#08182a' };
    // 배경 사진(꾸밈별)
    const bgI = T.jel ? -1 : tk.c;
    const gr = ctx.createLinearGradient(0, 0, 0, H);
    gr.addColorStop(0, zc.c1); gr.addColorStop(1, zc.c2);
    ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
    if (bgI > 0 && IMG.bgok) {
      ctx.globalAlpha = 0.9;
      const sw2 = BGW, sh2 = BGH, k = Math.max(W / sw2, H / sh2);
      ctx.drawImage(IMG.bg, 0, (bgI - 1) * BGH, BGW, BGH, (W - sw2 * k) / 2, (H - sh2 * k) / 2, sw2 * k, sh2 * k);
      ctx.globalAlpha = 1;
      ctx.fillStyle = 'rgba(5,20,40,.18)'; ctx.fillRect(0, 0, W, H);
    }
    if (T.land) {   // 뭍
      ctx.fillStyle = 'rgba(230,240,248,.92)';
      ctx.beginPath(); ctx.moveTo(0, H * 0.34); ctx.lineTo(W * 0.38, H * 0.34); ctx.quadraticCurveTo(W * 0.46, H * 0.36, W * 0.44, H * 0.5); ctx.lineTo(0, H * 0.5); ctx.closePath(); ctx.fill();
    }
    // 빛줄기
    ctx.globalAlpha = 0.07;
    ctx.fillStyle = '#fff';
    for (let i = 0; i < 3; i++) { const x = ((i * 0.37 + t * 0.01) % 1) * W; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + W * 0.08, 0); ctx.lineTo(x - W * 0.1, H); ctx.lineTo(x - W * 0.2, H); ctx.fill(); }
    ctx.globalAlpha = 1;
    // 생물
    const tw = T.w;
    if (IMG.ok) {
      sw.f.forEach((f) => {
        const s = f.s, [bx, by, bw, bh] = s.box;
        if (!bw) return;
        let len = W * s.size / tw;
        len = clamp(len, W * (big ? 0.05 : 0.07), W * (s.mv === 2 ? 0.3 : 0.5));
        const k = len / Math.max(bw, bh * 0.8);
        let dw = bw * k, dh = bh * k;
        let x = f.x * W, y = f.y * H;
        if (s.mv === 1 || s.mv === 2) y = H * 0.94 - dh / 2;
        if (f.land) y = H * 0.34 - dh / 2 + Math.sin(f.ph) * 1.5;
        ctx.save();
        ctx.translate(x, y + (s.mv === 0 ? Math.sin(f.ph) * 1.2 : s.mv === 4 ? Math.sin(f.ph * 0.6) * 2.5 : 0));
        let dir = f.vx < 0 ? -1 : 1;
        if (s.flip) dir = -dir;
        if (s.mv === 2) dir = s.flip ? -1 : 1;
        let sy = 1;
        if (s.mv === 3) sy = 1 + Math.sin(f.ph * 2) * 0.08;
        if (s.mv === 2) ctx.rotate(Math.sin(f.ph * 0.4) * 0.02);
        ctx.scale(dir, sy);
        if (s.mv === 3) ctx.globalAlpha = 0.88;
        ctx.drawImage(IMG.sp, bx, by, bw, bh, -dw / 2, -dh / 2, dw, dh);
        ctx.restore();
      });
    }
    // 거품
    ctx.fillStyle = 'rgba(255,255,255,.35)';
    sw.bub.forEach((b) => { ctx.beginPath(); ctx.arc(W * (0.85 + b.x * 0.1), b.y * H, 1.2 * b.s * (big ? 1.6 : 1), 0, 7); ctx.fill(); });
    // 물 상태
    if (tk.q < 50) { ctx.fillStyle = `rgba(90,80,30,${(50 - tk.q) / 120})`; ctx.fillRect(0, 0, W, H); }
    if (tk.z > 0) { ctx.fillStyle = 'rgba(80,140,40,.18)'; ctx.fillRect(0, 0, W, H); }
    if (T.jel) {   // 원형 수조 테두리
      const r = Math.min(W, H) * 0.62;
      const g2 = ctx.createRadialGradient(W / 2, H / 2, r * 0.6, W / 2, H / 2, Math.max(W, H) * 0.75);
      g2.addColorStop(0, 'rgba(0,0,0,0)'); g2.addColorStop(1, 'rgba(0,0,10,.7)');
      ctx.fillStyle = g2; ctx.fillRect(0, 0, W, H);
    }
    if (!tk.g.length) {
      ctx.fillStyle = 'rgba(255,255,255,.65)'; ctx.font = `${big ? 16 : 12}px ${'IBM Plex Sans KR'}, sans-serif`; ctx.textAlign = 'center';
      ctx.fillText('비어 있어요', W / 2, H / 2);
    }
    // 유리
    const gl = ctx.createLinearGradient(0, 0, W, H);
    gl.addColorStop(0, 'rgba(255,255,255,.10)'); gl.addColorStop(0.4, 'rgba(255,255,255,0)');
    ctx.fillStyle = gl; ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  function mount(root, api) {
    injectCSS(); loadImgs();
    let S = null, sheet = null, dayOv = null, dead = false, lastId = null, showSeat = null, bestDone = false;
    const swims = {};
    const cvs = [];   // {cv, k, seat, big}
    const el = h('div', { class: 'aq' });
    root.appendChild(el);
    const top = h('div', { class: 'aq-top' });
    const who = h('div', { class: 'aq-who', hidden: true });
    const main = h('div', { class: 'aq-main' });
    const bot = h('div', { class: 'aq-bot' });
    el.append(top, who, main, bot);

    const mine = () => api.mySeats();
    /* 이 화면에서 지금 계획하는 자리: 아직 준비 안 한 내 자리 중 첫째 → 없으면 내 첫 자리 → 관전이면 0 */
    function curSeat() {
      if (showSeat != null && S && S.P[showSeat]) return showSeat;
      const m = mine();
      if (!S) return m[0] || 0;
      const nr = m.find((i) => !S.P[i].rd);
      if (nr != null) return nr;
      return m.length ? m[0] : 0;
    }
    const canEdit = (seat) => S && S.ph === 'plan' && api.canAct(seat) && !S.P[seat].rd && showSeat == null;
    function act(seat, a) {
      if (!canEdit(seat) && !(a.a === 'ready' || a.a === 'unready')) return;
      if (mine().length > 1) api.actAs(seat, a); else api.act(a);
      api.sfx('click');
    }

    /* ---------- 위쪽 ---------- */
    function renderTop() {
      const seat = curSeat(), p = S.P[seat];
      const today = S.ev[S.d], nx = S.ev[S.d + 1], tr = S.tr[S.d];
      top.innerHTML = '';
      top.append(
        h('div', { class: 'aq-stats' },
          h('span', { class: 'aq-pill' }, '📅 ', h('b', { text: `${Math.min(S.d, S.D)}/${S.D}` }), `일 ${dayName(Math.min(S.d, S.D))}`),
          h('span', { class: 'aq-pill' + (p.m < 0 ? ' neg' : '') }, '💰', h('b', { text: won(p.m, true) })),
          h('span', { class: 'aq-pill' }, '⭐', h('b', { text: String(Math.round(p.rep)) })),
          p.rp ? h('span', { class: 'aq-pill' }, '👥', h('b', { text: String(p.rp.vis) })) : null),
        h('div', { class: 'aq-ev' },
          h('button', { class: 'aq-chip', text: `오늘 ${EV[today].ic} ${EV[today].n}${isWeekend(S.d) ? ' · 주말' : ''}`, onclick: () => api.toast(`${EV[today].ic} ${EV[today].n}: ${EV[today].d}${isWeekend(S.d) ? ' 주말이라 손님 +35%.' : ''}`) }),
          h('button', { class: 'aq-chip', text: `인기 ${TR[tr].ic} ${TR[tr].n}`, onclick: () => api.toast(`오늘 손님은 「${TR[tr].n}」을 좋아해요. 이런 생물의 전시 매력 ×1.6`) }),
          nx && S.d < S.D ? h('button', { class: 'aq-chip', text: `내일 ${EV[nx].ic} ${EV[nx].n}`, onclick: () => api.toast(`내일 예보 ${EV[nx].ic} ${EV[nx].n}: ${EV[nx].d}`) }) : null));
      who.hidden = true;
      if (showSeat != null) {
        who.hidden = false; who.innerHTML = '';
        who.append(h('span', { text: `👀 ${S.P[showSeat].n}의 수족관 보는 중` }), h('button', { class: 'btn sm', text: '내 수족관', onclick() { showSeat = null; render(); } }));
      } else if (mine().length > 1 && S.ph === 'plan') {
        who.hidden = false; who.innerHTML = '';
        who.append(h('span', { text: S.P[seat].rd ? `✓ 모두 준비됨 — 기다리는 중` : `🙋 ${S.P[seat].n} 차례 계획 중` }));
      }
    }
    /* ---------- 수조 목록 ---------- */
    function renderMain() {
      const seat = curSeat(), p = S.P[seat];
      const keep = main.scrollTop;
      main.innerHTML = '';
      cvs.splice(0, cvs.length, ...cvs.filter((c) => c.big));
      for (let k = 0; k < p.sl; k++) {
        const tk = p.tk[k];
        if (!tk) {
          const b = h('button', { class: 'aq-card empty', onclick: () => { if (canEdit(seat)) openBuyTank(k); else api.toast('지금은 바꿀 수 없어요'); } }, h('b', { text: '＋' }), h('span', { text: '수조 놓기' }));
          main.append(b); continue;
        }
        const cv = h('canvas');
        const th = tankTheme(tk);
        const pr = problemsOf({ tk: [tk] });
        const bad = pr.some((x) => x.lv === 2), warn = pr.length > 0;
        const avgH = tk.g.length ? Math.round(tk.g.reduce((a, g) => a + g[2] * g[1], 0) / tk.g.reduce((a, g) => a + g[1], 0)) : 100;
        const card = h('button', { class: 'aq-card', onclick: () => openTank(k) }, cv,
          h('div', { class: 'aq-badge' }, h('span', { text: String(k + 1) }), bad ? h('span', { text: '❗' }) : warn ? h('span', { text: '⚠️' }) : null, tk.z > 0 ? h('span', { text: '🦠' }) : null),
          h('div', { class: 'aq-cf' },
            h('div', { class: 'nm' }, th ? h('span', { text: ZN[th].ic }) : null, h('span', { text: th ? ZN[th].th : TK[tk.t].n })),
            h('div', { class: 'sub', text: `${tk.T}℃ · ${tk.S}‰ · ${tk.g.reduce((a, g) => a + g[1], 0)}마리 · ❤${avgH}` })));
        main.append(card);
        cvs.push({ cv, k, seat, big: false });
      }
      if (p.sl < MAXSL) main.append(h('button', { class: 'aq-card empty lock', onclick: () => { if (!canEdit(seat)) return; confirmBox(`전시관을 넓힐까요? 수조 자리 2칸 · ${won(expandCost(p))}`, () => act(seat, { a: 'expand' })); } }, h('b', { text: '🏗' }), h('span', { text: `전시관 넓히기 ${won(expandCost(p), true)}` })));
      main.scrollTop = keep;
    }
    /* ---------- 아래 버튼 ---------- */
    function renderBot() {
      const seat = curSeat(), p = S.P[seat];
      bot.innerHTML = '';
      const editable = S.ph === 'plan' && api.canAct(seat) && showSeat == null;
      bot.append(
        h('button', { class: 'btn aq-mk-btn', onclick: () => openMarket(null) }, h('i', { text: '🛒' }), '시장'),
        h('button', { class: 'btn aq-st-btn', onclick: () => openStaff() }, h('i', { text: '🎫' }), '요금·직원'),
        h('button', { class: 'btn aq-rk-btn', onclick: () => openRank() }, h('i', { text: '🏆' }), '순위'));
      if (editable && !p.rd) bot.append(h('button', { class: 'btn primary aq-go', onclick: () => startDay(seat) }, `▶ 하루 시작`));
      else if (editable && p.rd) bot.append(h('button', { class: 'btn aq-go', onclick: () => act(seat, { a: 'unready' }) }, h('span', { text: '⏳ 기다리는 중' }), h('small', { text: '눌러서 계획 다시' })));
      else bot.append(h('button', { class: 'btn aq-go', disabled: true, text: S.ph === 'end' ? '경영 끝' : '보는 중' }));
    }
    function startDay(seat) {
      const p = S.P[seat];
      const pr = problemsOf(p).filter((x) => x.lv === 2);
      const go = () => { act(seat, { a: 'ready' }); api.buzz(15, 'ui'); };
      if (!tankCount(p)) return confirmBox('수조가 하나도 없어요. 손님이 오지 않아요. 그래도 하루를 보낼까요?', go);
      if (pr.length) return confirmBox(`문제가 있어요: ${pr.slice(0, 2).map((x) => x.t).join(', ')}. 그래도 시작할까요?`, go);
      go();
    }
    function confirmBox(text, ok) {
      const ov = h('div', { class: 'aq-pop', onclick: (e) => { if (e.target === ov) ov.remove(); } },
        h('div', null, h('p', { style: { margin: '4px 0 6px', lineHeight: 1.5 }, text }),
          h('div', { class: 'aq-row' }, h('button', { class: 'btn', style: { flex: 1 }, text: '아니요', onclick: () => ov.remove() }),
            h('button', { class: 'btn primary', style: { flex: 1 }, text: '네', onclick: () => { ov.remove(); ok(); } }))));
      el.append(ov);
    }

    /* ---------- 시트 공통 ---------- */
    function openSheet(kind, arg, title) {
      const old = sheet;
      closeSheet();
      const prev = old ? (old.kind !== kind ? { kind: old.kind, arg: old.arg } : old.prev) : null;
      const body = h('div', { class: 'aq-sh-b' }), foot = h('div', { class: 'aq-sh-f', hidden: true });
      const head = h('div', { class: 'aq-sh-h' }, h('button', { class: 'aq-back', 'aria-label': '뒤로', 'data-key': 'Escape', text: '‹', onclick: () => backSheet() }), h('h3', { text: title }));
      const o = h('div', { class: 'aq-sheet' }, head, body, foot);
      el.append(o);
      sheet = { kind, arg, o, body, foot, head, prev };
      return sheet;
    }
    function closeSheet() {
      if (!sheet) return;
      sheet.o.remove(); sheet = null;
      cvs.splice(0, cvs.length, ...cvs.filter((c) => !c.big));
    }
    function backSheet() {
      const pv = sheet && sheet.prev;
      closeSheet();
      if (pv) { if (pv.kind === 'tank') openTank(pv.arg); }
      render();
    }
    function refreshSheet() {
      if (!sheet) return;
      const sc = sheet.body.scrollTop;
      const { kind, arg, prev } = sheet;
      if (kind === 'tank') { const p = S.P[curSeat()]; if (!p.tk[arg]) { closeSheet(); return; } openTank(arg, true); }
      else if (kind === 'market') openMarket(arg, true);
      else if (kind === 'staff') openStaff(true);
      else if (kind === 'rank') openRank(true);
      else if (kind === 'buytank') openBuyTank(arg, true);
      else return;
      if (sheet) { sheet.body.scrollTop = sc; if (prev) sheet.prev = prev; }
    }
    window.addEventListener('lounge-cancel', onCancel);
    function onCancel(e) { if (sheet) { e.preventDefault(); backSheet(); } }
    /* PC: Esc = 열린 창 닫기(없으면 core 게임 메뉴), Enter = 결과 창 닫기 */
    function onKey(e) {
      if (e.repeat || /INPUT|TEXTAREA/.test((e.target && e.target.tagName) || '')) return;
      const pop = el.querySelector('.aq-pop');
      if (e.key === 'Escape') {
        if (pop) { e.preventDefault(); e.stopPropagation(); pop.remove(); return; }
        if (sheet) { e.preventDefault(); e.stopPropagation(); backSheet(); }
      } else if (e.key === 'Enter' && sheet && sheet.kind === 'report' && !pop) {
        e.preventDefault(); e.stopPropagation();
        const b = sheet.foot.querySelector('.btn.primary'); if (b) b.click();
      }
    }
    window.addEventListener('keydown', onKey, true);

    /* ---------- 수조 사기 ---------- */
    function openBuyTank(k, re) {
      const seat = curSeat(), p = S.P[seat];
      const sh = openSheet('buytank', k, `${k + 1}번 자리에 수조 놓기`);
      sh.body.append(h('p', { class: 'aq-note', text: '수조가 클수록 큰 생물과 많은 생물을 넣을 수 있고 손님도 더 좋아해요. 해파리와 펭귄·해달·물범은 전용 수조가 필요해요.' }));
      TK.forEach((T, t) => {
        const has = T.one && p.tk.some((x) => x && x.t === t);
        const ok = p.m >= T.cost && !has;
        sh.body.append(h('div', { class: 'aq-sp' },
          h('div', { class: 'pic', style: { display: 'grid', placeItems: 'center', fontSize: '24px' }, text: T.jel ? '🎐' : T.land ? '🐧' : ['▫️', '◽', '◻️', '⬜', '🌊'][t] }),
          h('div', { class: 'tx' }, h('b', { text: T.n }), h('div', { class: 'm', text: `${T.v.toLocaleString()}L · ${won(T.cost)}` }), h('div', { class: 'w', style: { color: 'var(--muted)' }, text: has ? '이미 있어요 (1개만)' : T.d })),
          h('div', { class: 'bt' }, h('button', { class: 'btn primary', disabled: !ok, text: '사기', onclick: () => { act(seat, { a: 'tank', k, t }); closeSheet(); setTimeout(() => { if (S.P[seat].tk[k]) openTank(k); }, 60); } }))));
      });
    }

    /* ---------- 수조 자세히 ---------- */
    function openTank(k, re) {
      const seat = curSeat(), p = S.P[seat], tk = p.tk[k];
      if (!tk) return;
      const ed = canEdit(seat);
      const T = TK[tk.t], vf = vfOf(tk.t);
      const th = tankTheme(tk);
      const sh = openSheet('tank', k, `${k + 1}번 · ${th ? ZN[th].th : T.n}`);
      const cv = h('canvas', { class: 'aq-big' });
      sh.body.append(cv);
      cvs.push({ cv, k, seat, big: true });
      const ld = loadOf(tk), cp = capOf(tk);
      const lr = ld / cp;
      sh.body.append(h('div', { class: 'aq-box' },
        h('h4', null, h('span', { text: `${T.n} ${T.v.toLocaleString()}L` }), h('small', { text: th ? `⭐ 테마 완성 ×1.35` : '같은 곳 생물 2종 이상 + 알맞은 꾸밈 → 테마' })),
        h('div', { class: 'aq-kv' },
          h('span', { text: '💧 물 깨끗함' }), h('span', { class: tk.q < 50 ? 'aq-bad' : tk.q < 70 ? 'aq-warn' : 'aq-ok', text: `${tk.q}%` }),
          h('span', { text: '⚖️ 생물 양 / 거를 수 있는 양' }), h('span', { class: lr > 1 ? 'aq-bad' : lr > 0.85 ? 'aq-warn' : 'aq-ok', text: `${Math.round(lr * 100)}%` }),
          h('span', { text: '✨ 전시 매력' }), h('span', { text: String(Math.round(tankA(tk, S.tr[S.d]))) }),
          tk.z > 0 ? h('span', { class: 'aq-bad', text: '🦠 병' }) : null, tk.z > 0 ? h('span', { class: 'aq-bad', text: `${tk.z}일쯤 남음` }) : null)));
      // 물
      const water = h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: '🌡️ 물 맞추기' }), h('small', { text: `실내 ${ROOM}℃ · 히터 ${tk.e & HT ? '있음' : '없음'} · 냉각기 ${tk.e & CH ? '있음' : '없음'}` })));
      const step = (lab, val, unit, dn, up, okDn, okUp) => h('div', { class: 'aq-row' }, h('span', { class: 'lab', text: lab }),
        h('span', { class: 'aq-step' }, h('button', { class: 'btn', disabled: !ed || !okDn, text: '−', onclick: dn }), h('b', { text: val + unit }), h('button', { class: 'btn', disabled: !ed || !okUp, text: '＋', onclick: up })));
      water.append(step('온도', tk.T, '℃', () => act(seat, { a: 'temp', k, v: tk.T - 1 }), () => act(seat, { a: 'temp', k, v: tk.T + 1 }), tk.T > tLo(tk), tk.T < tHi(tk)));
      if (ed && (!(tk.e & HT) || !(tk.e & CH))) water.append(h('p', { class: 'aq-note', text: `히터 없이 최고 24℃, 냉각기 없이 최저 20℃까지예요.` }));
      water.append(step('염도', tk.S, '‰', () => act(seat, { a: 'sal', k, v: tk.S - 1 }), () => act(seat, { a: 'sal', k, v: tk.S + 1 }), tk.S > 0, tk.S < 40));
      water.append(h('div', { class: 'aq-chips' }, ...[[0, '민물 0'], [15, '기수 15'], [33, '바닷물 33']].map(([v, l]) => h('button', { class: 'btn' + (tk.S === v ? ' on' : ''), disabled: !ed, text: l, onclick: () => act(seat, { a: 'sal', k, v }) }))));
      if (tk.g.some((g) => g[3] < S.d) && ed) water.append(h('p', { class: 'aq-note', text: '생물이 있을 때 하루에 온도 3℃·염도 5‰보다 크게 바꾸면 생물이 놀라요.' }));
      sh.body.append(water);
      // 꾸밈
      if (!T.jel) {
        const dc = h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: '⛰️ 꾸밈' }), h('small', { text: `바꾸기 ${won(Math.round(50000 * vf))}` })));
        dc.append(h('div', { class: 'aq-hscroll' }, ...DEC.map((n, v) => h('button', { class: 'btn sm' + (tk.c === v ? ' on' : ''), style: tk.c === v ? { background: 'var(--brass)', color: '#1b1206' } : {}, disabled: !ed || tk.c === v, text: n, onclick: () => act(seat, { a: 'dec', k, v }) }))));
        const zs = ZK.filter((z) => ZN[z].dec === tk.c && z !== 'jel').map((z) => ZN[z].n);
        dc.append(h('p', { class: 'aq-note', text: tk.c ? `어울리는 곳: ${zs.join(', ') || '없음'}` : '숨을 곳이 필요한 생물은 꾸밈이 있어야 해요.' }));
        sh.body.append(dc);
      }
      // 장비
      const eq = h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: '🔧 장비' }), h('small', { text: `여과기 Lv${tk.f}` })));
      const chips = h('div', { class: 'aq-chips' });
      EQ.forEach((e) => {
        const own = tk.e & e.b, c = Math.round(e.c * vf);
        chips.append(h('button', { class: 'btn' + (own ? ' own' : ''), disabled: !ed || !!own || p.m < c, text: own ? `${e.ic} ${e.n} ✓` : `${e.ic} ${e.n} ${won(c, true)}`, title: e.d, onclick: () => confirmBox(`${e.n}: ${e.d}. ${won(c)}에 살까요?`, () => act(seat, { a: 'eq', k, b: e.b })) }));
      });
      if (tk.f < 3) { const c = Math.round(FILT[tk.f] * vf); chips.append(h('button', { class: 'btn', disabled: !ed || p.m < c, text: `🌀 여과기 Lv${tk.f + 1} ${won(c, true)}`, onclick: () => act(seat, { a: 'filt', k }) })); }
      eq.append(chips, h('p', { class: 'aq-note', text: '여과기 Lv2 ×1.5, Lv3 ×2만큼 생물을 더 감당해요. 장비마다 전기값이 들어요.' }));
      sh.body.append(eq);
      // 생물
      const lst = h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: `🐟 생물 ${tk.g.length}종` }), h('small', { text: `먹이 ${won(foodOf(tk, 1))}/일` })));
      tk.g.forEach((g, gi) => {
        const s = SP[g[0]];
        const st = stressOf(tk, gi);
        st.sort((a, b) => b.p - a.p);
        const hc = g[2] > 66 ? '#6fd38f' : g[2] > 35 ? '#f2c45a' : '#ff7a6a';
        const sell = Math.round(s.price * (g[3] === S.d ? 1 : 0.5));
        lst.append(h('div', { class: 'aq-sp' },
          picBox(s, 66, 44, () => speciesPop(s)),
          h('div', { class: 'tx' }, h('b', { text: `${s.ko} ×${g[1]}` }),
            h('div', { class: 'aq-bar' }, h('i', { style: { width: Math.max(0, g[2]) + '%', background: hc } })),
            h('div', { class: 'w ' + (st.length ? (st[0].p >= 10 ? 'aq-bad' : 'aq-warn') : 'aq-ok'), text: st.length ? st.slice(0, 2).map((x) => x.w).join(' · ') : '잘 지내요' })),
          h('div', { class: 'bt' }, h('button', { class: 'btn', disabled: !ed, title: `1마리 팔기 (+${won(sell)})`, text: '−1', onclick: () => act(seat, { a: 'rm', k, s: s.i, n: 1 }) }),
            h('button', { class: 'btn', disabled: !ed || !(S.mk[s.i] > 0) || p.m < s.price, title: `1마리 더 (${won(s.price)})`, text: '＋1', onclick: () => act(seat, { a: 'buy', k, s: s.i, n: 1 }) }))));
      });
      if (!tk.g.length) lst.append(h('p', { class: 'aq-note', text: '아직 생물이 없어요. 「＋ 생물 넣기」를 눌러요.' }));
      sh.body.append(lst);
      if (ed) {
        let refund = TK[tk.t].cost; EQ.forEach((e) => { if (tk.e & e.b) refund += e.c * vf; }); refund *= tk.d === S.d ? 1 : 0.5;
        tk.g.forEach((g) => { refund += SP[g[0]].price * g[1] * (g[3] === S.d ? 1 : 0.5); });
        sh.body.append(h('button', { class: 'btn ghost', style: { color: 'var(--coral)' }, text: `수조 팔기 (+${won(Math.round(refund))})`, onclick: () => confirmBox(`${k + 1}번 수조를 생물까지 모두 팔까요? (+${won(Math.round(refund))}${tk.d === S.d ? '' : ', 산 값의 절반'})`, () => { act(seat, { a: 'sell', k }); closeSheet(); render(); }) }));
        sh.foot.hidden = false;
        sh.foot.append(h('button', { class: 'btn primary aq-add', text: '＋ 생물 넣기', onclick: () => openMarket(k) }));
      }
    }

    /* ---------- 시장 ---------- */
    let mkZone = 'all', mkFit = true;
    function openMarket(k, re) {
      const seat = curSeat(), p = S.P[seat];
      const ed = canEdit(seat);
      let tk = k != null ? p.tk[k] : null;
      if (k != null && !tk) k = null;
      const sh = openSheet('market', k, k != null ? `🛒 ${k + 1}번 수조에 넣기` : '🛒 오늘의 시장');
      if (k != null && !re) { const z = tankTheme(tk) || (tk.g.length ? SP[tk.g[0][0]].zone : null); mkZone = z || 'all'; if (TK[tk.t].jel) mkZone = 'jel'; if (TK[tk.t].land) mkZone = 'pole'; }
      // 수조 고르기
      const tks = p.tk.map((x, i) => (x ? i : -1)).filter((i) => i >= 0);
      if (tks.length) {
        sh.body.append(h('div', { class: 'aq-hscroll' }, h('span', { class: 'aq-note', style: { alignSelf: 'center', flex: 'none' }, text: '넣을 수조' }),
          ...tks.map((i) => h('button', { class: 'btn sm' + (i === k ? ' on' : ''), style: i === k ? { background: 'var(--brass)', color: '#1b1206', minHeight: '44px' } : { minHeight: '44px' }, text: `${i + 1}번`, onclick: () => { sheet.arg = i; openMarket(i); } }))));
      } else sh.body.append(h('p', { class: 'aq-note', text: '수조가 없어요. 먼저 빈 칸에 수조를 놓아요. 지금은 구경만 할 수 있어요.' }));
      sh.body.append(h('div', { class: 'aq-hscroll' },
        h('button', { class: 'btn sm', style: mkZone === 'all' ? { background: 'var(--brass)', color: '#1b1206', minHeight: '44px' } : { minHeight: '44px' }, text: '전체', onclick: () => { mkZone = 'all'; openMarket(k, true); } }),
        ...ZK.map((z) => h('button', { class: 'btn sm', style: mkZone === z ? { background: 'var(--brass)', color: '#1b1206', minHeight: '44px' } : { minHeight: '44px' }, text: `${ZN[z].ic} ${ZN[z].n}`, onclick: () => { mkZone = z; openMarket(k, true); } }))));
      if (tk) sh.body.append(h('label', { class: 'aq-row', style: { minHeight: '44px', fontSize: '13px' } }, h('input', { type: 'checkbox', checked: mkFit, style: { width: '22px', height: '22px' }, onchange: (e) => { mkFit = e.target.checked; openMarket(k, true); } }), '이 수조에 넣을 수 있는 것만 (✗ 숨기기)'));
      const list = SP.filter((s) => S.mk[s.i] != null && (mkZone === 'all' || s.zone === mkZone));
      const rows = [];
      list.forEach((s) => {
        const cs = tk ? compat(tk, s, s.school || 1) : [];
        const w = worst(cs);
        if (tk && mkFit && w === 2) return;
        rows.push({ s, cs, w });
      });
      rows.sort((a, b) => a.w - b.w || a.s.price - b.s.price);
      sh.body.append(h('p', { class: 'aq-note', text: `오늘 나온 생물 ${list.length}종${tk && mkFit ? ` · 넣을 수 있는 것 ${rows.length}종` : ''}. 그림을 누르면 자세히 봐요.` }));
      rows.slice(0, 120).forEach(({ s, cs, w }) => {
        const st = S.mk[s.i];
        const n1 = s.school || 1;
        const tag = tk ? (w === 2 ? '✗ ' : w === 1 ? '⚠ ' : '✓ ') + (cs.length ? cs[0].w : '잘 맞아요') : lineOf(s);
        const canBuy = (n) => ed && tk && st >= n && p.m >= s.price * n;
        sh.body.append(h('div', { class: 'aq-sp' },
          picBox(s, 66, 44, () => speciesPop(s)),
          h('div', { class: 'tx' }, h('b', { text: s.ko }), ' ', h('span', { class: 'm', text: `${ZN[s.zone].ic} ${s.size}cm · ${won(s.price, true)}${st < 99 ? ` · 남은 ${st}` : ''}` }),
            h('div', { class: 'm', text: tk ? lineOf(s) + ` · ${s.minL.toLocaleString()}L 이상` : `${s.minL.toLocaleString()}L 이상 · ${AGGR[s.aggr]}${s.pred ? ' · 사냥함' : ''}` }),
            h('div', { class: 'w ' + (tk ? (w === 2 ? 'aq-bad' : w === 1 ? 'aq-warn' : 'aq-ok') : ''), text: tag })),
          h('div', { class: 'bt' },
            h('button', { class: 'btn' + (w === 0 && tk ? ' primary' : ''), disabled: !canBuy(1), text: '×1', onclick: () => buy(s, 1) }),
            n1 > 1 ? h('button', { class: 'btn', disabled: !canBuy(n1), text: '×' + n1, onclick: () => buy(s, n1) }) : null)));
      });
      if (!rows.length) sh.body.append(h('p', { class: 'aq-note', text: tk ? '이 수조에 맞는 생물이 오늘은 없어요. 다른 곳을 고르거나 물 온도·염도를 바꿔 보세요.' : '없어요.' }));
      function buy(s, n) {
        const cs = compat(tk, s, n);
        const w = worst(cs);
        const go = () => { act(seat, { a: 'buy', k, s: s.i, n }); api.sfx('pop'); };
        if (w === 2) confirmBox(`${s.ko}: ${cs.filter((c) => c.lv === 2).map((c) => c.w).join(', ')}. 그래도 넣을까요?`, go);
        else go();
      }
    }

    /* ---------- 생물 자세히 ---------- */
    function speciesPop(s) {
      const ov = h('div', { class: 'aq-pop', onclick: (e) => { if (e.target === ov) ov.remove(); } },
        h('div', null,
          picBox(s, Math.min(480, el.clientWidth - 40), 140),
          h('div', null, h('b', { style: { fontSize: '18px' }, text: s.ko }), ' ', h('i', { style: { color: 'var(--muted)' }, text: s.sci })),
          h('p', { class: 'aq-note', style: { color: 'var(--ink)' }, text: s.fact }),
          h('div', { class: 'aq-kv' }, ...speciesKV(s).flatMap(([a, b]) => [h('span', { text: a }), h('span', { text: b })])),
          h('button', { class: 'btn', text: '닫기', onclick: () => ov.remove() })));
      el.append(ov);
    }

    /* ---------- 요금·직원 ---------- */
    function openStaff() {
      const seat = curSeat(), p = S.P[seat], ed = canEdit(seat);
      const sh = openSheet('staff', null, '🎫 요금·직원');
      const A = hallA(p, S.tr[S.d]);
      const pb = h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: '입장료' }), h('small', { text: `손님이 적당하다고 느끼는 값 ≈ ${won(Math.round(optPrice(A) / 1000) * 1000)}` })));
      pb.append(h('div', { class: 'aq-row' }, h('span', { class: 'aq-step' },
        h('button', { class: 'btn', disabled: !ed || p.pr <= 3000, text: '−', onclick: () => act(seat, { a: 'price', v: p.pr - 1000 }) }),
        h('b', { style: { minWidth: '92px' }, text: won(p.pr) }),
        h('button', { class: 'btn', disabled: !ed || p.pr >= 60000, text: '＋', onclick: () => act(seat, { a: 'price', v: p.pr + 1000 }) })),
        h('button', { class: 'btn sm', disabled: !ed, style: { minHeight: '44px' }, text: '추천 값', onclick: () => act(seat, { a: 'price', v: clamp(Math.round(optPrice(A) / 1000) * 1000, 3000, 60000) }) })));
      pb.append(h('p', { class: 'aq-note', text: '비싸면 손님이 줄고 만족도도 떨어져요. 전시가 멋질수록 비싸도 와요. 다른 수족관과 손님을 나눠요.' }));
      sh.body.append(pb);
      const sb = h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: '직원' }), h('small', { text: `수조 ${tankCount(p)}개` })));
      ST.forEach((r, i) => {
        sb.append(h('div', { class: 'aq-sp' },
          h('div', { class: 'pic', style: { display: 'grid', placeItems: 'center', fontSize: '26px' }, text: r.ic }),
          h('div', { class: 'tx' }, h('b', { text: `${r.n} ${p.st[i]}명` }), h('div', { class: 'm', text: `하루 ${won(r.w)}` }), h('div', { class: 'w', style: { color: 'var(--muted)' }, text: r.d })),
          h('div', { class: 'bt' }, h('button', { class: 'btn', disabled: !ed || p.st[i] <= 0, text: '−', onclick: () => act(seat, { a: 'staff', r: i, d: -1 }) }),
            h('button', { class: 'btn', disabled: !ed || p.st[i] >= 8, text: '＋', onclick: () => act(seat, { a: 'staff', r: i, d: 1 }) }))));
      });
      const need = Math.ceil(tankCount(p) / 3);
      if (p.st[0] < need) sb.append(h('p', { class: 'aq-note aq-warn', text: `사육사가 ${need}명 있어야 모든 수조를 돌봐요.` }));
      sh.body.append(sb);
      const c = dailyCostEst(S, p);
      sh.body.append(h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: '하루 운영비 (예상)' }), h('small', { text: won(Math.round(c)) })),
        h('div', { class: 'aq-kv' },
          h('span', { text: '직원 월급' }), h('span', { text: won(p.st.reduce((a, n, i) => a + n * ST[i].w, 0)) }),
          h('span', { text: '전기 (히터·냉각기·조명)' }), h('span', { text: won(Math.round(p.tk.reduce((a, tk) => a + (tk ? powerOf(tk) : 0), 0))) }),
          h('span', { text: '먹이' }), h('span', { text: won(Math.round(p.tk.reduce((a, tk) => a + (tk ? foodOf(tk, 1) : 0), 0))) }))));
    }

    /* ---------- 순위 ---------- */
    function openRank() {
      const sh = openSheet('rank', null, '🏆 순위');
      const me = mine();
      const rows = S.P.map((p, i) => ({ p, i, sc: S.ph === 'end' && p.sc ? p.sc : scoreOf(S, p) })).sort((a, b) => b.sc.tot - a.sc.tot);
      const box = h('div', { class: 'aq-rank' });
      rows.forEach((r, n) => {
        box.append(h('button', { class: 'aq-rk' + (me.includes(r.i) ? ' me' : ''), onclick: () => { showSeat = me.includes(r.i) ? null : r.i; closeSheet(); render(); } },
          h('span', { text: ['🥇', '🥈', '🥉', '4'][n] || String(n + 1) }),
          h('span', { class: 'dot', style: { '--c': (api.players[r.i] || {}).color || '#888' } }),
          h('div', { style: { minWidth: 0 } }, h('b', { text: r.p.n + (r.p.rd && S.ph === 'plan' ? ' ✓' : '') }),
            h('div', { class: 'aq-note', text: `💰${won(r.p.m, true)} ⭐${Math.round(r.p.rep)} · 수조 ${tankCount(r.p)} · ${speciesCount(r.p)}종 · 어제 👥${r.p.rp ? r.p.rp.vis : 0}` })),
          h('span', { class: 'sc', text: String(r.sc.tot) })));
      });
      sh.body.append(box, h('p', { class: 'aq-note', text: '이름을 누르면 그 수족관을 구경해요.' }));
      const meP = S.P[me.length ? me[0] : 0], sc = scoreOf(S, meP);
      sh.body.append(h('div', { class: 'aq-box' }, h('h4', null, h('span', { text: `${meP.n} 점수 내역` }), h('small', { text: `${sc.tot}점` })),
        h('div', { class: 'aq-kv' },
          h('span', { text: '💰 순자산 (돈 + 시설·생물 값의 절반 − 시작 자금) 100만 원당 1점' }), h('span', { text: String(sc.wp) }),
          h('span', { text: '⭐ 평판 × 3' }), h('span', { text: String(sc.rp) }),
          h('span', { text: '✨ 전시 매력 (√매력 × 4)' }), h('span', { text: String(sc.ep) }),
          h('span', { text: '🐠 기르는 종 수 × 3' }), h('span', { text: String(sc.dp) }))));
    }

    /* ---------- 하루 결과 ---------- */
    function openReport(seat) {
      const p = S.P[seat], r = p.rp;
      if (!r) return;
      const sh = openSheet('report', seat, `📋 ${r.d}일째 결과`);
      sh.body.append(h('div', { class: 'aq-box', style: { alignItems: 'center' } },
        h('div', { style: { fontSize: '13px', color: 'var(--muted)' }, text: `${EV[r.ev].ic} ${EV[r.ev].n}${isWeekend(r.d) ? ' · 주말' : ''}` }),
        h('div', { style: { fontSize: '30px', fontFamily: 'var(--f-mono)' }, text: `👥 ${r.vis.toLocaleString()}명` }),
        h('div', { class: r.net >= 0 ? 'aq-ok' : 'aq-bad', style: { fontSize: '18px', fontFamily: 'var(--f-mono)' }, text: `${r.net >= 0 ? '+' : ''}${won(r.net)}` }),
        h('div', { style: { fontSize: '13px' }, text: `만족 ${r.sat} · 평판 ${r.rep >= 0 ? '+' : ''}${r.rep} → ⭐${Math.round(p.rep)}` })));
      sh.body.append(h('div', { class: 'aq-box' }, h('h4', { text: '돈' }), h('div', { class: 'aq-kv' },
        h('span', { text: '🎫 입장료' }), h('span', { class: 'aq-ok', text: '+' + won(r.ticket) }),
        h('span', { text: '🛍 기념품' }), h('span', { class: 'aq-ok', text: '+' + won(r.shop) }),
        h('span', { text: '🛒 오늘 산 것 (판 것 뺀)' }), h('span', { class: r.buy > 0 ? 'aq-bad' : 'aq-ok', text: (r.buy > 0 ? '−' : '+') + won(Math.abs(r.buy)) }),
        h('span', { text: '🦐 먹이' }), h('span', { class: 'aq-bad', text: '−' + won(r.food) }),
        h('span', { text: '⚡ 전기' }), h('span', { class: 'aq-bad', text: '−' + won(r.power) }),
        h('span', { text: '🧑‍🔧 직원' }), h('span', { class: 'aq-bad', text: '−' + won(r.wages) }))));
      const lg = h('div', { class: 'aq-log' });
      (p.lg.length ? p.lg : ['😊 별일 없이 지나갔어요']).forEach((t) => lg.append(h('div', { text: t })));
      sh.body.append(h('div', { class: 'aq-box' }, h('h4', { text: '수족관 소식' }), lg));
      if (S.P.length > 1) {
        const rk = S.P.map((q, i) => ({ q, i })).sort((a, b) => (b.q.rp ? b.q.rp.vis : 0) - (a.q.rp ? a.q.rp.vis : 0));
        sh.body.append(h('div', { class: 'aq-box' }, h('h4', { text: '오늘 손님 순위' }), h('div', { class: 'aq-kv' }, ...rk.flatMap((x) => [h('span', { text: x.q.n }), h('span', { text: `${x.q.rp ? x.q.rp.vis : 0}명 · ⭐${Math.round(x.q.rep)}` })]))));
      }
      sh.foot.hidden = false;
      sh.foot.append(h('button', { class: 'btn primary', 'data-key': 'Enter', text: S.ph === 'end' ? '결과 보기' : `${S.d}일째 계획하기`, onclick: () => { closeSheet(); render(); if (holdBusy) { holdBusy = false; api.setBusy(false); } } }));
    }

    /* ---------- 하루 연출 ---------- */
    let holdBusy = false, dayT = 0;
    function playDay(st) {
      const m = mine();
      const seat = m.length ? m[0] : 0;
      const p = st.P[seat], r = p.rp;
      if (!r) return;
      api.setBusy(true);
      if (dayOv) dayOv.remove();
      const prog = h('i'), cnt = h('div', { class: 'cnt', text: '0명' }), crowd = h('div', { class: 'crowd' });
      dayOv = h('div', { class: 'aq-day' }, h('div', { class: 'sun', text: EV[r.ev].ic }), h('h2', { text: `${r.d}일째 영업 중…` }), crowd, h('div', { class: 'prog' }, prog), cnt);
      el.append(dayOv);
      const dur = 1700 / SPD();
      const t0 = performance.now();
      const ppl = ['🧑', '👩', '👨‍👩‍👧', '🧒', '👵', '🧑‍🎓', '👫'];
      api.sfx('whoosh');
      clearInterval(dayT);
      dayT = setInterval(() => {
        const k = Math.min(1, (performance.now() - t0) / dur);
        prog.style.width = (k * 100) + '%';
        cnt.textContent = `👥 ${Math.round(r.vis * k).toLocaleString()}명`;
        const n = Math.round(k * 12);
        if (crowd.textContent.length / 2 < n) crowd.textContent += ppl[rnd(ppl.length)];
        if (k >= 1) {
          clearInterval(dayT);
          if (dayOv) { dayOv.remove(); dayOv = null; }
          api.sfx(r.net >= 0 ? 'chip' : 'thud');
          if (m.length && !dead) {
            openReport(seat);
            if (st.ph === 'end') { holdBusy = true; setTimeout(() => { if (holdBusy) { holdBusy = false; api.setBusy(false); } }, 9000 / SPD()); return; }   // 마지막 날 결과를 잠깐 보여 준 뒤 최종 결과
          } else api.toast(`${r.d}일째: ${p.n} 손님 ${r.vis}명 · ${r.net >= 0 ? '+' : ''}${won(r.net)}`);
          api.setBusy(false);
        }
      }, 50);
    }

    /* ---------- 그리기 루프 ---------- */
    let raf = 0, lastT = performance.now();
    function frame(now) {
      raf = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - lastT) / 1000); lastT = now;
      if (!S || document.hidden) return;
      const coverFull = sheet && sheet.kind !== 'tank';
      cvs.forEach((c) => {
        if (coverFull) return;
        if (sheet && !c.big) return;
        const p = S.P[c.seat], tk = p && p.tk[c.k];
        if (!tk) return;
        const key = c.seat + ':' + c.k;
        let sw = swims[key];
        if (!sw || sw.sig !== sigOf(tk)) sw = swims[key] = makeSwim(tk);
        if (!c.big) stepSwim(sw, dt);
        else stepSwim(sw, dt * 0.5);
        const r = c.cv.getBoundingClientRect();
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        const W = Math.max(10, Math.round(r.width)), H = Math.max(10, Math.round(r.height));
        if (c.cv.width !== Math.round(W * dpr) || c.cv.height !== Math.round(H * dpr)) { c.cv.width = Math.round(W * dpr); c.cv.height = Math.round(H * dpr); }
        const ctx = c.cv.getContext('2d');
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        drawTank(ctx, W, H, tk, sw, now / 1000, c.big);
      });
    }
    raf = requestAnimationFrame(frame);

    function render() {
      if (!S) return;
      renderTop(); renderMain(); renderBot();
    }
    return {
      update(st, prev) {
        S = st;
        if (showSeat != null && !S.P[showSeat]) showSeat = null;
        render();
        if (sheet && sheet.kind !== 'report') refreshSheet();
        if (st.last && st.last.id !== lastId) {
          const first = lastId === null && prev == null;
          lastId = st.last.id;
          if (!first) { if (sheet && sheet.kind !== 'report') closeSheet(); render(); playDay(st); }
          if (!first && st.ph === 'end' && !bestDone) {
            bestDone = true;
            mine().forEach((i) => { const p = st.P[i]; if (p && p.sc && api.best) api.best(`score${st.D}`, p.sc.tot, { label: `최고 점수 (${st.D}일)`, unit: '점' }); });
          }
        }
      },
      destroy() {
        dead = true;
        cancelAnimationFrame(raf); clearInterval(dayT);
        window.removeEventListener('lounge-cancel', onCancel);
        window.removeEventListener('keydown', onKey, true);
        api.setBusy(false);
        el.remove();
      },
    };
  }

  /* ===================== 도감 ===================== */
  function speciesKV(s) {
    return [
      ['학명', s.sci], ['사는 곳', `${ZN[s.zone].ic} ${ZN[s.zone].n}`], ['알맞은 물', lineOf(s)], ['크기', `${s.size}cm`],
      ['최소 수조', `${s.minL.toLocaleString()}L`], ['성격', AGGR[s.aggr]], ['사냥', PREDN[s.pred]], ['먹이', s.diet],
      ['기르기', ['', '쉬움', '보통', '어려움'][s.care]], ['값', won(s.price)], ['인기', '★'.repeat(Math.round(s.ap / 2)) + ` (${s.ap})`],
      ['특징', traitTxt(s) || '—'],
    ];
  }
  function traitTxt(s) {
    const t = [];
    if (s.school === 6) t.push('6마리 이상 무리'); else if (s.school === 3) t.push('3마리 이상 무리');
    if (s.solo) t.push('같은 종 1마리만'); else if (s.terr) t.push('같은 종 2마리까지');
    if (s.nip) t.push('산호·무척추 쪼아 먹음');
    if (s.coral) t.push('산호 조명 필요');
    if (s.jelly) t.push('해파리 수조 필요');
    if (s.land) t.push('물가 사육장 필요');
    if (s.clean) t.push('청소부(병 줄임)');
    if (s.graze) t.push('이끼 먹음(물 +)');
    if (s.hide) t.push('숨을 곳 필요');
    if (s.mud) t.push('갯벌 바닥 필요');
    if (s.shy) t.push('예민함');
    if (s.fl.includes('v')) t.push('독·조심');
    if (s.fl.includes('L')) t.push('우리 토종');
    if (s.rare) t.push('희귀');
    return t.join(' · ');
  }
  function buildCodex() {
    const secs = ZK.map((z) => ({
      h: `${ZN[z].ic} ${ZN[z].n}`,
      p: [`${ZN[z].th}: ${ZN[z].n} 생물을 2종 이상, 꾸밈 「${DEC[ZN[z].dec]}」${z === 'jel' ? '(해파리 원형 수조)' : z === 'pole' ? '(펭귄·해달·물범은 물가 사육장)' : ''}으로 모으면 테마 완성(매력 ×1.35). 보통 ${ZN[z].T}℃ · ${salName(ZN[z].S)}.`],
      rows: SP.filter((s) => s.zone === z).map((s) => ({
        icon: `<i class="aq-cx"><i style="${picCss(s, 64, 42)}"></i></i>`,
        name: s.ko, tag: `${s.size}cm · ${won(s.price, true)}`,
        desc: `${s.sci} · ${lineOf(s)} · 최소 ${s.minL.toLocaleString()}L · ${AGGR[s.aggr]}${s.pred ? ' · ' + PREDN[s.pred] : ''} · 먹이 ${s.diet}${traitTxt(s) ? ' · ' + traitTxt(s) : ''} — ${s.fact}`,
      })),
    }));
    secs.push({ h: '🏗 수조·장비', p: ['수조 값은 시작 값, 장비 값은 수조가 클수록 비싸져요(크기 배율). 팔면 절반을 돌려받아요(그날 산 것은 전부).'],
      rows: TK.map((T) => ({ icon: T.jel ? '🎐' : T.land ? '🐧' : '🐟', name: T.n, tag: `${T.v.toLocaleString()}L · ${won(T.cost, true)}`, desc: T.d }))
        .concat(EQ.map((e) => ({ icon: e.ic, name: e.n, tag: `${won(e.c, true)}부터`, desc: e.d })))
        .concat([{ icon: '🌀', name: '여과기', tag: 'Lv1~3', desc: '물을 걸러요. Lv2는 1.5배, Lv3은 2배만큼 생물을 감당해요.' }])
        .concat(DEC.slice(1).map((d, i) => ({ icon: '⛰️', name: d, tag: '꾸밈', desc: `숨을 곳이 돼요. 어울리는 곳: ${ZK.filter((z) => ZN[z].dec === i + 1 && z !== 'jel').map((z) => ZN[z].n).join(', ')}` }))) });
    secs.push({ h: '🧑‍🔧 직원', rows: ST.map((r) => ({ icon: r.ic, name: r.n, tag: `하루 ${won(r.w, true)}`, desc: r.d })) });
    secs.push({ h: '📅 사건·인기', p: ['사건은 하루 전에 예보돼요. 인기 생물은 날마다 바뀌어요.'],
      rows: Object.keys(EV).map((k) => ({ icon: EV[k].ic, name: EV[k].n, tag: '사건', desc: EV[k].d }))
        .concat(TRK.map((k) => ({ icon: TR[k].ic, name: TR[k].n, tag: '인기', desc: '이날은 이런 생물의 전시 매력이 1.6배' }))) });
    return secs;
  }

  /* ===================== 규칙 그림 ===================== */
  const FIG_TANK = `<svg viewBox="0 0 340 110" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif" font-size="12">
<rect x="6" y="8" width="150" height="90" rx="8" fill="#1b7fb0"/><rect x="6" y="80" width="150" height="18" rx="4" fill="#d8c79a"/>
<text x="16" y="28" fill="#fff">26℃ · 33‰</text><text x="16" y="48" fill="#fff">🐠 흰동가리 ×2 ✓</text><text x="16" y="66" fill="#fff">💡 산호 조명 ✓</text>
<rect x="184" y="8" width="150" height="90" rx="8" fill="#6b6a2e"/><text x="194" y="28" fill="#fff">27℃ · 0‰ (민물)</text>
<text x="194" y="48" fill="#fff">🐟 네온테트라 ×8</text><text x="194" y="66" fill="#ffb3a6">✗ 엔젤피시에게</text><text x="194" y="82" fill="#ffb3a6">   잡아먹혀요</text></svg>`;

  L.register({
    id: ID, name: '수족관 경영', tag: '생태 경영', cat: '전략', icon: '<path d="M8 14h40v32H8z" fill="none" stroke="currentColor" stroke-width="3"/><path d="M14 34c4-6 10-6 14 0-4 6-10 6-14 0zm14 0l5-4v8z" fill="currentColor"/><path d="M38 44c0-6 2-10 4-12M44 44c0-4-1-7-3-9" stroke="currentColor" stroke-width="2.5" fill="none"/><circle cx="36" cy="22" r="2" fill="currentColor"/><circle cx="40" cy="27" r="1.5" fill="currentColor"/>',
    tint: '#0f4a66',
    blurb: '실제 바다·민물 생물 152종을 모아 수조 온도·염도·궁합을 맞추고, 손님을 끌어 가장 멋진 수족관을 만들어요.',
    time: '20–40분', minPlayers: 1, maxPlayers: 4, defaultPlayers: 2,
    fixedOrder: true, undo: false, save: true, mood: 'sea', ambient: 'harbor',
    saveLabel: (s) => `${Math.min(s.d, s.D)}/${s.D}일째`,
    aiDelay: 1400,
    aiDelayFor(s, seat, lv) { return s.ph === 'plan' && !s.P[seat].rd ? (lv === 3 ? 900 : lv === 1 ? 1800 : 1300) : -1; },
    options: [
      { id: 'days', label: '경영 기간', tip: '며칠 동안 운영할지. 길수록 큰 수조·희귀종까지 키울 수 있어요.', choices: [{ v: 10, label: '10일', tip: '짧게(15분쯤)' }, { v: 15, label: '15일', tip: '보통(25분쯤)' }, { v: 20, label: '20일' }, { v: 30, label: '30일', tip: '길게' }], def: 15 },
      { id: 'money', label: '시작 자금', tip: '처음에 가진 돈', choices: [{ v: 'low', label: '빠듯 2천만', tip: '작은 수조부터 차근차근' }, { v: 'mid', label: '보통 4천만' }, { v: 'high', label: '넉넉 8천만', tip: '처음부터 큰 수조' }], def: 'mid' },
      { id: 'ev', label: '사건', tip: '정전·폭염·질병 유행·수학여행 같은 날이 생겨요(하루 전에 예보).', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔', tip: '날마다 평범한 날' }], def: 'on' },
    ],
    quick: [
      '실제 생물을 사서 수조에 넣고, 손님을 모아 돈·평판을 벌어요.',
      '날마다 수조·생물·장비를 사고 온도·염도·입장료를 맞춘 뒤 「▶ 하루 시작」.',
      '생물마다 맞는 온도·염도·수조 크기가 있고, 큰 물고기는 작은 물고기를 잡아먹어요.',
      '마지막 날 점수(순자산·평판·전시 매력·종 수)가 가장 높으면 이겨요.',
    ],
    rules: [
      { h: '목표', p: ['정해진 날(기본 15일) 동안 수족관을 운영해 점수를 가장 많이 얻어요. 혼자 할 때는 점수에 따라 S~D 등급이 나와요.'] },
      { h: '하루에 할 일', p: ['① 빈 칸에 수조를 놓아요. ② 수조를 눌러 온도·염도·꾸밈·장비를 맞추고 「＋ 생물 넣기」로 생물을 넣어요. ③ 「요금·직원」에서 입장료와 직원을 정해요. ④ 「▶ 하루 시작」. 모두 누르면 하루가 지나가고 결과가 나와요.',
        '모두 동시에 계획해요. 「하루 시작」을 누른 뒤에도 다른 사람을 기다리는 동안 눌러서 계획을 다시 할 수 있어요.'] },
      { h: '물 맞추기', p: ['생물마다 알맞은 온도(℃)와 염도(‰, 바닷물 짠 정도: 민물 0 · 기수 5~20 · 바닷물 30~36)가 있어요. 벗어나면 건강이 줄고, 0이 되면 죽어요.',
        '히터가 있어야 25℃ 넘게, 냉각기가 있어야 19℃ 아래로 맞출 수 있어요(실내 22℃).', '생물이 있는 수조의 물을 하루에 3℃·5‰보다 크게 바꾸면 생물이 놀라요.'], fig: FIG_TANK },
      { h: '함께 살 수 있나', p: ['큰 육식 물고기는 입에 들어가는 작은 물고기(몸길이 약 ⅓ 이하)를 잡아먹어요. 게·새우를 먹는 생물도 있어요.',
        '사나운 생물은 순한 생물을 괴롭혀요. 「산호·무척추 쪼아 먹음」 생물은 산호와 같이 두면 안 돼요.',
        '무리 생활하는 물고기는 6마리(또는 3마리) 이상, 「같은 종 1마리만」 생물(베타 등)은 혼자 둬요.',
        '수조가 「최소 수조」보다 작으면 생물이 힘들어요. 해파리는 해파리 원형 수조, 펭귄·해달·물범은 물가 사육장이 필요해요.',
        '시장에서 수조를 고르면 ✓ 잘 맞음 · ⚠ 주의 · ✗ 안 됨(까닭)을 바로 보여 줘요.'] },
      { h: '물·병', p: ['생물이 많을수록 물이 빨리 더러워져요. 여과기를 올리거나(Lv3 = 2배) 바닷물 수조엔 스키머를 달아요. 사육사 1명이 수조 3개를 돌봐요.',
        '물이 더러우면 병이 잘 생겨요. 수의사 1명이 수조 4개를 맡아 병을 막고 빨리 고쳐요. 청소새우·청소놀래기는 병을 줄여요.'] },
      { h: '손님·돈', p: ['손님은 전시 매력이 높고 평판이 좋고 입장료가 알맞은 수족관으로 와요. 여럿이 하면 한 도시의 손님을 나눠 가져요.',
        '전시 매력: 인기 높은 생물·건강한 생물·큰 수조일수록 높아요. 같은 곳(산호초·아마존 등) 생물 2종 이상 + 어울리는 꾸밈 = 테마 완성(×1.35).',
        '주말엔 손님 +35%. 날마다 「인기 생물」이 바뀌어요(그런 생물 매력 ×1.6).',
        '수입: 입장료 + 기념품. 지출: 생물·장비 산 값, 먹이, 전기(히터·냉각기·조명), 직원 월급.', '생물이 죽거나 잡아먹히면 평판이 떨어져요.'] },
      { h: '점수', p: ['점수 = 순자산(돈 + 시설·생물 값의 절반 − 시작 자금, 100만 원당 1점) + 평판×3 + 전시 매력(√매력×4) + 기르는 종 수×3.'] },
      { h: '사건', p: ['하루 전에 예보돼요: 비(손님+), 수학여행(손님+, 다양한 종·해설사 좋아함), 정전(비상 전원 없으면 온도·물 나빠짐), 폭염(냉각기 없으면 +3℃), 한파(히터 없으면 −3℃), 질병 유행, 방송 취재(가장 멋진 수조 평판+8), 먹이 값 오름, 희귀종 들어옴, 바다 축제.'] },
      { h: '조작', p: ['수조 카드를 누르면 자세히 보기. 생물 그림을 누르면 생물 정보. 오른쪽 클릭·‹ = 뒤로. 📖 도감에서 152종 생물을 모두 볼 수 있어요.', 'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
      { h: '그림 출처', p: ['생물 그림은 위키미디어 공용의 퍼블릭 도메인·CC 라이선스 그림(옛 박물학 도판 등)을 배경을 지워 썼어요. 자세한 출처는 assets/aquarium/CREDITS.txt.'] },
    ],
    tutorial: [
      { text: '수족관 경영에 어서 오세요! 실제 생물을 모아 수조를 꾸미고 손님을 받아요.' },
      { text: '빈 칸을 눌러 수조를 놓아요. 처음엔 중형 수조(200L)가 무난해요.', sel: '.aq-card.empty' },
      { text: '수조를 누르면 온도·염도·장비를 맞추고 「＋ 생물 넣기」로 생물을 넣어요. ✓ 표시가 잘 맞는 생물이에요.' },
      { text: '입장료와 직원은 여기서. 사육사가 없으면 물이 더러워져요.', sel: '.aq-st-btn' },
      { text: '다 했으면 「▶ 하루 시작」! 모두 누르면 하루가 지나가요.', sel: '.aq-go' },
    ],
    hint,
    panelInfo(s, seat) {
      const p = s.P[seat >= 0 ? seat : 0];
      return [{ label: '돈', value: won(p.m, true) }, { label: '평판', value: String(Math.round(p.rep)) }, { label: '수조', value: String(tankCount(p)) }, { label: '종', value: String(speciesCount(p)) }];
    },
    codex: buildCodex(),
    init, actor, apply, result,
    ai(s, seat, lv) { if (s.ph !== 'plan' || s.P[seat].rd) return null; return aiPlan(s, seat, lv || 2); },
    mount,
    preview(cv) {
      const ctx = cv.getContext('2d');
      const g = ctx.createLinearGradient(0, 0, 0, 360); g.addColorStop(0, '#1b7fb0'); g.addColorStop(1, '#06223a');
      ctx.fillStyle = g; ctx.fillRect(0, 0, 640, 360);
      ctx.fillStyle = '#d9c99c'; ctx.fillRect(0, 320, 640, 40);
      ctx.font = '64px sans-serif'; ctx.fillText('🐠', 120, 160); ctx.fillText('🐡', 380, 230); ctx.fillText('🎐', 500, 120); ctx.fillText('🐚', 60, 330); ctx.fillText('🦈', 240, 280);
    },
    _t: { SP, ZN, TK, compat, stressOf, canEat, scoreOf, hallA, tankA, aiPlan, simDay, doOp },
  });
  injectCSS();
})();
