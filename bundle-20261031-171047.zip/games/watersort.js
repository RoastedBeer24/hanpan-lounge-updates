/* 물병 색 정리 — 혼자 즐기는 색 물 붓기 퍼즐.
   Levels come from a seeded generator: random deal → DFS solver must find a solution (else next attempt), so every level
   is solvable and level N is always the same. Board = array of strings (bottom→top, chars 'a'..'l'), capacity 4.
   Progress (current level, max cleared, best moves) lives in localStorage — progress only, no power. */
(function () {
  const L = window.Lounge, U = L.util;
  /* ---------- 오늘의 퍼즐 (날짜 YYYYMMDD 씨앗 → 모두 같은 퍼즐). 기록·연속 일수는 이 기기에만, 지난 7일치만 남김 ---------- */
  function mkDaily(gid, short, fmt, lower) {
    const SK = 'lounge.daily.' + gid;
    const ymd = (d) => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
    const toD = (n) => new Date(Math.floor(n / 10000), Math.floor(n / 100) % 100 - 1, n % 100, 12);
    const shift = (n, k) => { const d = toD(n); d.setDate(d.getDate() + k); return ymd(d); };
    const rd = () => { try { return JSON.parse(localStorage.getItem(SK) || '{}') || {}; } catch (e) { return {}; } };
    const wr = (o) => { try { localStorage.setItem(SK, JSON.stringify(o)); } catch (e) {} };
    const D = {
      today: () => ymd(new Date()),
      md: (n) => (Math.floor(n / 100) % 100) + '/' + (n % 100),
      long: (n) => (Math.floor(n / 100) % 100) + '월 ' + (n % 100) + '일',
      seed(n) { let h = (n >>> 0) ^ 0x9e3779b9; h = Math.imul(h ^ (h >>> 16), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; },
      score: (n) => { const o = rd(); return o.done ? o.done[n] : undefined; },
      streak() { const o = rd(), t = D.today(); return o.last && (o.last === t || o.last === shift(t, -1)) ? o.st | 0 : 0; },
      prune() {
        const o = rd(), cut = shift(D.today(), -6);
        if (o.done) for (const k in o.done) if (+k < cut) delete o.done[k];
        wr(o);
        try { const all = U.store.get('best.' + gid, {}); let ch = 0; for (const k in all) if (/^d\d{8}$/.test(k) && +k.slice(1) < cut) { delete all[k]; ch = 1; } if (ch) U.store.set('best.' + gid, all); } catch (e) {}
      },
      /* 완료 기록 → 새 최고면 true */
      complete(n, sc, api) {
        const o = rd(); o.done = o.done || {};
        const old = o.done[n], first = old == null;
        if (first || (lower ? sc < old : sc > old)) o.done[n] = sc;
        if (first) { o.st = o.last === shift(n, -1) ? (o.st | 0) + 1 : o.last === n ? o.st | 0 || 1 : 1; if (!o.last || n > o.last) o.last = n; }
        wr(o);
        if (api) api.best('d' + n, sc, { label: '오늘의 퍼즐 ' + D.md(n), lower: !!lower, unit: fmt === 'time' ? '' : fmt, fmt: fmt === 'time' ? 'time' : '' });
        D.prune();
        return !first && o.done[n] === sc && sc !== old;
      },
      text(n) {
        const sc = D.score(n);
        const v = fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt;
        return '한판 라운지 ' + short + ' ' + D.md(n) + ' ✓ ' + v + ' · 연속 ' + Math.max(1, D.streak()) + '일';
      },
      share(n, api) {
        const t = D.text(n), ok = () => api && api.toast('복사했어요: ' + t);
        const fb = () => { try { const ta = L.h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); ok(); } catch (e) { if (api) api.toast(t); } };
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb(); } catch (e) { fb(); }
      },
      fmtScore(sc) { return sc == null ? '' : fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt; },
      /* 단계/모드 고르기 맨 위에 넣는 큰 카드 */
      card(onPlay, api, sub) {
        const n = D.today(), sc = D.score(n), st = D.streak();
        const box = L.h('div', { class: 'daily-card', style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '12px', borderRadius: '14px', border: '2px solid var(--brass,#e3ae45)', background: 'linear-gradient(135deg,rgba(227,174,69,.22),rgba(227,174,69,.06))' } });
        const head = L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } });
        head.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', lineHeight: '1.2' } },
          L.h('b', { style: { fontSize: '18px' }, text: '📅 오늘의 퍼즐' }),
          L.h('span', { class: 'muted', style: { fontSize: '13px' }, text: D.long(n) + (sub ? ' · ' + sub : '') })),
          L.h('div', { style: { textAlign: 'right', lineHeight: '1.2', fontSize: '13px' } },
            L.h('div', { style: { fontSize: '15px', fontWeight: '700', color: sc != null ? '#8fd14f' : 'inherit' }, text: sc != null ? '완료 ✓' : '미완료' }),
            L.h('div', { class: 'muted', text: '🔥 연속 ' + st + '일' })));
        box.append(head);
        if (sc != null) box.append(L.h('div', { style: { fontSize: '13px' }, text: '오늘 최고 ' + D.fmtScore(sc) }));
        const row = L.h('div', { style: { display: 'flex', gap: '6px' } });
        row.append(L.h('button', { class: 'btn primary', style: { flex: '1', minHeight: '48px' }, text: sc != null ? '다시 도전 ▶' : '도전하기 ▶', onclick: () => onPlay(n) }));
        if (sc != null) row.append(L.h('button', { class: 'btn', style: { flex: '0 0 auto', minHeight: '48px', padding: '0 14px' }, text: '📋 공유', onclick: () => D.share(n, api) }));
        box.append(row);
        return box;
      },
    };
    return D;
  }
  const CAP = 4;
  const COLS = ['#e8433a', '#f39a2b', '#f2d43a', '#8fd14f', '#2fa35a', '#2bb9a8', '#5cc8f2', '#3b6fe0', '#8a55d6', '#ec6fb4', '#8d5a33', '#d9d4c7'];
  const SYMS = ['●', '▲', '■', '◆', '★', '✚', '✖', '○', '♥', '▼', '◐', '☾'];
  const KEY = 'lounge.watersort';

  function store() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }

  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const colorsFor = (lv) => Math.min(12, 3 + Math.floor((lv - 1) / 3));

  /* ---------- rules ---------- */
  const top = (s) => s[s.length - 1];
  function run(s) { let n = 0; const c = top(s); for (let i = s.length - 1; i >= 0 && s[i] === c; i--) n++; return n; }
  const full1 = (s) => s.length === CAP && run(s) === CAP;
  function canPour(b, i, j) {
    if (i === j || b[i] === undefined || b[j] === undefined) return false;
    const s = b[i], t = b[j];
    if (!s.length || t.length >= CAP || full1(s)) return false;
    return !t.length || top(t) === top(s);
  }
  function pour(b, i, j) { const s = b[i], n = Math.min(run(s), CAP - b[j].length); b[j] += s.slice(s.length - n); b[i] = s.slice(0, s.length - n); return n; }
  const solved = (b) => b.every((s) => !s.length || full1(s));

  /* ---------- solver (DFS + visited) → list of [i,j] or null ---------- */
  function solve(b0, limit) {
    const b = b0.slice(), seen = new Set(), path = [];
    let nodes = 0;
    function moves() {
      const out = [], late = [];
      let firstEmpty = -1;
      for (let j = 0; j < b.length; j++) if (!b[j].length) { firstEmpty = j; break; }
      for (let i = 0; i < b.length; i++) {
        const s = b[i]; if (!s.length || full1(s)) continue;
        const r = run(s);
        for (let j = 0; j < b.length; j++) {
          if (j === i) continue;
          const t = b[j];
          if (!t.length) { if (j === firstEmpty && r < s.length) late.push([i, j]); continue; }
          if (t.length >= CAP || top(t) !== top(s)) continue;
          // prefer moves that move the whole run
          if (CAP - t.length >= r) out.unshift([i, j]); else out.push([i, j]);
        }
      }
      return out.concat(late);
    }
    function rec() {
      if (solved(b)) return true;
      if (++nodes > limit) return false;
      const k = b.slice().sort().join('|');
      if (seen.has(k)) return false;
      seen.add(k);
      for (const [i, j] of moves()) {
        const si = b[i], sj = b[j];
        pour(b, i, j); path.push([i, j]);
        if (rec()) return true;
        path.pop(); b[i] = si; b[j] = sj;
        if (nodes > limit) return false;
      }
      return false;
    }
    return rec() ? path : null;
  }

  const enc = (p) => p.map(([i, j]) => String.fromCharCode(65 + i, 65 + j)).join('');
  /* next planned move: reuse the stored plan if it still fits, else solve fresh → {a,b,pl} or null */
  function plan(s) {
    if (s.pl && s.pl.length >= 2) {
      const i = s.pl.charCodeAt(0) - 65, j = s.pl.charCodeAt(1) - 65;
      if (canPour(s.b, i, j)) return { a: i, b: j, pl: s.pl.slice(2) };
    }
    const p = solve(s.b, 60000);
    if (!p || !p.length) return null;
    return { a: p[0][0], b: p[0][1], pl: enc(p.slice(1)) };
  }

  const DLV = 25; // 오늘의 퍼즐 = 25단계 난이도(11색)
  const DAILY = mkDaily('watersort', '물병', '수', true);
  function gen(lv, seed) {
    const k = colorsFor(lv);
    for (let at = 0; at < 200; at++) {
      const r = prng(seed ? (seed + at * 104729) >>> 0 : lv * 7919 + at * 104729 + 17);
      const units = [];
      for (let c = 0; c < k; c++) for (let q = 0; q < CAP; q++) units.push(String.fromCharCode(97 + c));
      for (let i = units.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = units[i]; units[i] = units[j]; units[j] = t; }
      const b = [];
      for (let c = 0; c < k; c++) b.push(units.slice(c * CAP, c * CAP + CAP).join(''));
      if (b.some((s) => run(s) >= 3)) continue; // too easy / pre-sorted
      b.push('', '');
      if (solve(b, 40000)) return b;
    }
    return null;
  }

  function newLevel(s, lv, dy) {
    s.dy = dy || 0;
    let b = s.dy ? gen(DLV, DAILY.seed(s.dy)) : gen(lv);
    if (!b) { lv = 1; b = gen(1); s.dy = 0; }
    if (s.dy) lv = DLV;
    s.lv = lv; s.b = b; s.m = 0; s.u = []; s.ul = 5; s.x = 0; s.h = 3; s.hint = null; s.won = 0; s.end = 0; s.pl = '';
    s.last = { id: (s.last ? s.last.id : 0) + 1, t: 'new' };
    return s;
  }

  const def = {
    id: 'watersort', name: '물병 색 정리', tag: '색 물 붓기 퍼즐', cat: '아케이드',
    blurb: '병을 눌러 다른 병에 색 물을 부어요. 한 병에 한 가지 색만 꽉 차게 모으면 단계 통과! 단계는 끝없이 이어져요.',
    tint: '#164a63',
    icon: '<path d="M10 14h10v30a5 5 0 0 1-10 0z" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M23 14h10v30a5 5 0 0 1-10 0z" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M36 14h10v30a5 5 0 0 1-10 0z" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="11.5" y="34" width="7" height="10" fill="currentColor"/><rect x="24.5" y="26" width="7" height="8" fill="currentColor" opacity=".55"/><rect x="24.5" y="34" width="7" height="10" fill="currentColor"/><rect x="37.5" y="38" width="7" height="6" fill="currentColor" opacity=".55"/><path d="M15 8q6-4 12 2" fill="none" stroke="currentColor" stroke-width="2.5"/>',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, noAI: true, hidden: false, aiDelay: 450,
    controls: [
      { id: 'undo', label: '되돌리기', keys: ['KeyZ', 'Backspace'], pad: ['b'] },
      { id: 'reset', label: '다시 하기', keys: ['KeyR'], pad: ['back'] },
      { id: 'hint', label: '힌트', keys: ['KeyH'], pad: ['y'] },
      { id: 'extra', label: '빈 병 더하기', keys: ['KeyE'], pad: ['x'] },
    ],
    quick: [
      '목표: 병마다 한 가지 색만 4칸 꽉 차게 모으기!',
      '병을 누르고 → 다른 병을 누르면 맨 위 같은 색 물이 넘어가요. 받는 병이 비었거나 맨 위가 같은 색이어야 해요.',
      '막히면 되돌리기(단계마다 5번)·다시 하기·빈 병 더하기(1번)·힌트(3번)를 써요. 단계는 끝없이 어려워져요.',
    ],
    rules: [
      { h: '목표', p: ['모든 병이 「한 가지 색으로 꽉 찬 병」이나 「빈 병」이 되면 그 단계 통과예요.'] },
      { h: '그림으로 보기', fig: [{ svg: "<svg viewBox=\"0 0 340 130\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"130\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"20\" y=\"18\" width=\"34\" height=\"92\" rx=\"8\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"23\" y=\"88\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4a8fe0\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"23\" y=\"66\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"23\" y=\"44\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><text x=\"80\" y=\"64\" font-size=\"22\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">→</text><rect x=\"100\" y=\"18\" width=\"34\" height=\"92\" rx=\"8\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"103\" y=\"88\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4cc27a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"103\" y=\"66\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><text x=\"60\" y=\"124\" font-size=\"12\" fill=\"#9fd59f\" text-anchor=\"middle\" font-weight=\"400\">O 맨 위가 같은 색</text><rect x=\"190\" y=\"18\" width=\"34\" height=\"92\" rx=\"8\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"193\" y=\"88\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4a8fe0\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"193\" y=\"66\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><text x=\"250\" y=\"64\" font-size=\"22\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">→</text><rect x=\"270\" y=\"18\" width=\"34\" height=\"92\" rx=\"8\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"273\" y=\"88\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"273\" y=\"66\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4cc27a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"273\" y=\"44\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4a8fe0\" stroke=\"none\" stroke-width=\"1\"/><text x=\"270\" y=\"124\" font-size=\"12\" fill=\"#f2a0a0\" text-anchor=\"middle\" font-weight=\"400\">X 맨 위 색이 달라요</text></svg>", cap: "맨 위 색이 같거나 빈 병에만 부을 수 있어요" }, { svg: "<svg viewBox=\"0 0 340 130\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"130\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"60\" y=\"18\" width=\"34\" height=\"92\" rx=\"8\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"63\" y=\"88\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4a8fe0\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"63\" y=\"66\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"63\" y=\"44\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><text x=\"130\" y=\"64\" font-size=\"22\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">→</text><rect x=\"160\" y=\"18\" width=\"34\" height=\"92\" rx=\"8\" fill=\"none\" stroke=\"#cfd6e4\" stroke-width=\"2\"/><rect x=\"163\" y=\"88\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4cc27a\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"163\" y=\"66\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#4a8fe0\" stroke=\"none\" stroke-width=\"1\"/><rect x=\"163\" y=\"44\" width=\"28\" height=\"20\" rx=\"3\" fill=\"#e0524a\" stroke=\"none\" stroke-width=\"1\"/><text x=\"250\" y=\"50\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"start\" font-weight=\"400\">빈칸이 1칸뿐이면</text><text x=\"250\" y=\"68\" font-size=\"11\" fill=\"#e3ae45\" text-anchor=\"start\" font-weight=\"400\">빨강 1칸만 옮겨요</text><text x=\"170\" y=\"124\" font-size=\"12\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">받을 병의 빈칸만큼만 부어져요</text></svg>", cap: "부을 수 있는 만큼만 옮겨져요" }] },
      { h: '붓는 법', p: [
        '물을 줄 병을 누르면 살짝 들려요. 이어서 받을 병을 누르면 부어요.',
        '받을 병이 비어 있거나, 맨 위 색이 같아야 부을 수 있어요. 맨 위에 붙은 같은 색은 들어갈 만큼 한꺼번에 넘어가요.',
        '예시: 맨 위에 빨강 2칸 → 맨 위가 빨강이고 빈칸이 1칸인 병에 부으면 1칸만 넘어가요.',
      ] },
      { h: '도움 기능', p: [
        '↶ 되돌리기: 한 단계에 5번까지. ⟲ 다시 하기: 처음 모습으로(수 세기도 처음부터).',
        '＋ 빈 병: 단계마다 1번, 빈 병을 하나 더 줘요. 💡 힌트: 단계마다 3번, 좋은 한 수를 깜빡여 알려 줘요.',
        '◐ 무늬: 색마다 모양을 그려 줘요(색 구분이 어려울 때).',
      ] },
      { h: '단계', p: [
        '모든 단계는 반드시 풀 수 있게 만들어져요. 단계가 오를수록 색과 병이 늘어나요(최대 12색).',
        '지금 단계와 단계별 최고 기록(가장 적은 수)이 이 폰에 저장돼요. 「단계」 버튼으로 깬 단계를 다시 할 수 있어요.',
      ] },
      { h: '오늘의 퍼즐', p: ['「단계」 버튼 맨 위 카드에서 매일 하나씩 새 퍼즐(25단계 급, 11색)을 풀 수 있어요. 날짜가 같으면 누구나 같은 퍼즐이에요.', '하루씩 이어서 풀면 🔥 연속 일수가 올라가요. 오늘 기록은 「📋 공유」로 퍼즐 내용 없이 복사할 수 있어요. 단계 진행과는 따로예요.'] },
      { h: '조작(PC)', p: ['마우스로 병을 눌러요. Z 되돌리기 · R 다시 · H 힌트 · E 빈 병.'] },
    ],
    tutorial: [
      { text: '병을 하나 누르면 들려요. 다른 병을 누르면 맨 위 색 물이 넘어가요.' },
      { text: '받는 병은 비었거나 맨 위가 같은 색이어야 해요. 한 병에 한 색을 4칸 모으세요!' },
      { text: '막히면 아래 버튼: 되돌리기 · 다시 · 빈 병 · 힌트 · 단계 고르기 · 무늬(색 구분 도움).', sel: '.ws-bar' },
    ],

    init(players, opts) {
      const st = store();
      const mx = Math.max(0, st.max | 0);
      let lv = Math.max(1, st.cur | 0 || 1);
      if (lv > mx + 1) lv = mx + 1;
      return newLevel({ mx, last: null }, lv);
    },
    actor(s) { return s.end ? null : 0; },
    apply(s, seat, a) {
      if (!a || s.end) throw new Error('bad');
      const t = a.t;
      if (t === 'pour') {
        if (s.won) throw new Error('won');
        const i = a.a | 0, j = a.b | 0;
        if (!canPour(s.b, i, j)) throw new Error('illegal');
        s.u.push(s.b.join(',')); if (s.u.length > 5) s.u.shift();
        const c = top(s.b[i]);
        const n = pour(s.b, i, j);
        s.m++; s.hint = null;
        if (typeof a.pl === 'string' && a.pl.length < 600) s.pl = a.pl;
        else if (s.pl && s.pl.charCodeAt(0) - 65 === i && s.pl.charCodeAt(1) - 65 === j) s.pl = s.pl.slice(2);
        else s.pl = '';
        s.last = { id: s.last.id + 1, t: 'pour', a: i, b: j, n, c, done: full1(s.b[j]) ? 1 : 0 };
        if (solved(s.b)) { s.won = 1; if (!s.dy && s.lv > s.mx) s.mx = s.lv; }
      } else if (t === 'undo') {
        if (s.won || !s.ul || !s.u.length) throw new Error('no undo');
        const nb = s.u.pop().split(',');
        while (nb.length < s.b.length) nb.push('');
        s.b = nb; s.ul--; s.m++; s.hint = null; s.pl = '';
        s.last = { id: s.last.id + 1, t: 'undo' };
      } else if (t === 'reset') {
        const keepX = 0;
        newLevel(s, s.lv, s.dy); s.x = keepX;
        s.last.t = 'reset';
      } else if (t === 'extra') {
        if (s.won || s.x) throw new Error('used');
        s.x = 1; s.b.push(''); s.pl = ''; s.u = s.u.map((q) => q + ',');
        s.last = { id: s.last.id + 1, t: 'extra' };
      } else if (t === 'hint') {
        if (s.won || !s.h) throw new Error('no hint');
        const p = plan(s);
        s.h--;
        s.hint = p ? [p.a, p.b] : [-1, -1];
        s.pl = p ? String.fromCharCode(65 + p.a, 65 + p.b) + p.pl : '';
        s.last = { id: s.last.id + 1, t: 'hint' };
      } else if (t === 'next') {
        if (!s.won) throw new Error('not yet');
        if (s.dy) newLevel(s, s.rl || 1); else newLevel(s, s.lv + 1);
      } else if (t === 'go') {
        const n = a.n | 0;
        if (n < 1 || n > s.mx + 1) throw new Error('locked');
        newLevel(s, n);
      } else if (t === 'daily') {
        const d = a.d | 0;
        if (d < 20000101 || d > 29991231) throw new Error('bad date');
        if (!s.dy) s.rl = s.lv;
        newLevel(s, DLV, d);
      } else if (t === 'end') {
        if (!s.won) throw new Error('not yet');
        s.end = 1;
      } else throw new Error('unknown');
      return s;
    },
    ai(s) {
      if (s.won) return { t: 'end' };
      const p = plan(s);
      if (p) return { t: 'pour', a: p.a, b: p.b, pl: p.pl };
      if (!s.x) return { t: 'extra' };
      return { t: 'reset' };
    },
    result(s) {
      if (!s.end) return null;
      return { winners: [0], title: s.dy ? '오늘의 퍼즐 ' + DAILY.md(s.dy) + ' 완료!' : s.lv + '단계 통과!', text: s.m + '수 만에 정리했어요.',
        stats: [{ label: '수', value: String(s.m) }, { label: '색 · 병', value: colorsFor(s.lv) + '색 · ' + s.b.length + '병' }, { label: '힌트 사용', value: (3 - s.h) + '번' }, { label: '되돌리기 사용', value: (5 - s.ul) + '번' }, { label: '빈 병 더하기', value: s.x ? '썼어요' : '안 썼어요' }] };
    },

    mount(root, api) {
      const cvs = U.canvas(root), cv = cvs.cv, ctx = cvs.ctx;
      const SP = () => (L.debug && L.debug.speed) || 1;
      let S = null, sel = -1, anim = null, parts = [], shakes = {}, rafStop = null, now = 0, lastWin = 0;
      let sym = !!store().sym;
      const bar = L.h('div', { class: 'ws-bar', style: { position: 'absolute', left: '0', right: '0', bottom: '0', display: 'flex', gap: '5px', padding: '8px 8px 10px', justifyContent: 'center', zIndex: 5 } });
      const mkBtn = (ic, lab, fn) => {
        const b = L.h('button', { class: 'btn sm', style: { flex: '1 1 0', minWidth: '0', minHeight: '52px', padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1px', lineHeight: '1.1' }, onclick: (e) => { e.stopPropagation(); fn(); } });
        const i = L.h('span', { style: { fontSize: '18px' }, text: ic }), t = L.h('span', { style: { fontSize: '11px', whiteSpace: 'nowrap' }, text: lab });
        b.append(i, t); bar.append(b); return { b, t };
      };
      const act = (a) => { if (api.canAct(0)) api.act(a); };
      const bUndo = mkBtn('↶', '되돌리기', () => act({ t: 'undo' }));
      const bReset = mkBtn('⟲', '다시', () => { sel = -1; act({ t: 'reset' }); });
      const bExtra = mkBtn('＋', '빈 병', () => act({ t: 'extra' }));
      const bHint = mkBtn('💡', '힌트', () => act({ t: 'hint' }));
      bUndo.b.dataset.action = 'undo'; bReset.b.dataset.action = 'reset'; bExtra.b.dataset.action = 'extra'; bHint.b.dataset.action = 'hint';
      const bLv = mkBtn('▦', '단계', () => openPicker());
      const bSym = mkBtn('◐', '무늬', () => { sym = !sym; const o = store(); o.sym = sym ? 1 : 0; save(o); refreshBar(); });
      root.append(bar);
      let ov = null;
      function closeOv() { if (ov) { ov.remove(); ov = null; } }
      function panel(children) {
        closeOv();
        ov = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', background: 'rgba(10,8,15,.6)' }, onpointerdown: (e) => { if (e.target === ov) closeOv(); } });
        const sh = L.h('div', { class: 'sheet', style: { maxHeight: '86%', gap: '12px' } });
        children.forEach((c) => c && sh.append(c));
        ov.append(sh); root.append(ov);
      }
      function openPicker() {
        if (!S) return;
        const st = store(), best = st.best || {};
        const grid = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(54px,1fr))', gap: '6px', overflowY: 'auto', maxHeight: '52vh' } });
        for (let n = 1; n <= S.mx + 1; n++) {
          const cur = n === S.lv;
          const b = L.h('button', { class: 'btn sm' + (cur ? ' primary' : ''), style: { minHeight: '54px', padding: '2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', lineHeight: '1.1' }, onclick: () => { closeOv(); sel = -1; act({ t: 'go', n }); } });
          b.append(L.h('span', { class: 'mono', style: { fontSize: '17px' }, text: String(n) }), L.h('span', { style: { fontSize: '10px', opacity: '.8' }, text: best[n] ? best[n] + '수' : n > S.mx ? '새 단계' : '✓' }));
          grid.append(b);
        }
        panel([DAILY.card((d) => { closeOv(); sel = -1; act({ t: 'daily', d }); }, api, '11색 · 25단계 급'), L.h('h2', { text: '단계 고르기' }), L.h('p', { class: 'muted', style: { margin: 0 }, text: '깬 단계는 다시 할 수 있어요. 숫자 아래는 최고 기록(가장 적은 수).' }), grid,
          L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '닫기', onclick: closeOv })]);
        setTimeout(() => { const c = grid.querySelector('.primary'); if (c && c.scrollIntoView) c.scrollIntoView({ block: 'center' }); }, 0);
      }
      function winPanel() {
        if (S.dy) {
          const sc = DAILY.score(S.dy);
          return panel([L.h('h2', { text: '오늘의 퍼즐 완료! 🎉' }),
            L.h('p', { style: { margin: 0, fontSize: '16px' }, text: S.m + '수' + (sc != null ? ' · 오늘 최고 ' + sc + '수' : '') + ' · 🔥 연속 ' + DAILY.streak() + '일' }),
            L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '📋 결과 공유(복사)', onclick: () => DAILY.share(S.dy, api) }),
            L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '단계로 돌아가기 ▶', onclick: () => { closeOv(); act({ t: 'next' }); } }),
            L.h('button', { 'data-action': 'reset', class: 'btn ghost', style: { minHeight: '48px' }, text: '다시 도전', onclick: () => { closeOv(); act({ t: 'reset' }); } })]);
        }
        const st = store(), b = (st.best || {})[S.lv];
        panel([L.h('h2', { text: S.lv + '단계 통과! 🎉' }),
          L.h('p', { style: { margin: 0, fontSize: '16px' }, text: S.m + '수' + (b ? ' · 최고 기록 ' + b + '수' : '') }),
          L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '다음 단계 ▶', onclick: () => { closeOv(); act({ t: 'next' }); } }),
          L.h('button', { 'data-action': 'reset', class: 'btn', style: { minHeight: '48px' }, text: '이 단계 다시', onclick: () => { closeOv(); act({ t: 'reset' }); } }),
          L.h('button', { class: 'btn ghost', style: { minHeight: '48px' }, text: '단계 고르기', onclick: () => openPicker() })]);
      }
      function refreshBar() {
        if (!S) return;
        const dis = (b, v) => { b.b.disabled = !v; b.b.style.opacity = v ? '1' : '.4'; };
        bUndo.t.textContent = '되돌리기 ' + S.ul; dis(bUndo, !S.won && S.ul > 0 && S.u.length > 0);
        bExtra.t.textContent = S.x ? '빈 병 ✓' : '빈 병 1'; dis(bExtra, !S.won && !S.x);
        bHint.t.textContent = '힌트 ' + S.h; dis(bHint, !S.won && S.h > 0);
        dis(bReset, true); dis(bLv, true);
        bSym.t.textContent = sym ? '무늬 켬' : '무늬 끔'; bSym.b.style.outline = sym ? '2px solid var(--brass)' : 'none';
      }

      /* ---------- layout ---------- */
      let LAY = null;
      function layout(n) {
        const W = cvs.w, H = cvs.h;
        const topY = 64, botY = H - 78;
        const rows = n <= 6 ? 1 : 2, per = Math.ceil(n / rows);
        const cellW = (W - 16) / per;
        const bw = Math.min(58, cellW - 12);
        const availH = (botY - topY) / rows;
        const uh = Math.max(18, Math.min(40, (availH - 60) / (CAP + 0.8), bw * 0.85));
        const bh = uh * CAP + uh * 0.8;
        const pos = [];
        const blockH = rows * (bh + 46);
        const y0 = topY + Math.max(0, (botY - topY - blockH) / 2) + 34;
        for (let i = 0; i < n; i++) {
          const r = Math.floor(i / per), inRow = r === rows - 1 ? n - per * (rows - 1) : per, c = i - r * per;
          const rowW = inRow * cellW;
          const x = (W - rowW) / 2 + cellW * (c + 0.5);
          pos.push({ x, y: y0 + r * (bh + 46) }); // y = top of bottle
        }
        LAY = { n, bw, uh, bh, pos, W, H };
      }

      /* ---------- drawing ---------- */
      function bottlePath(x, y, bw, bh) {
        const r = bw * 0.42, lip = 4;
        ctx.beginPath();
        ctx.moveTo(x - bw / 2 - lip, y);
        ctx.lineTo(x + bw / 2 + lip, y);
        ctx.lineTo(x + bw / 2, y + 6);
        ctx.lineTo(x + bw / 2, y + bh - r);
        ctx.arc(x, y + bh - r, bw / 2, 0, Math.PI, false);
        ctx.lineTo(x - bw / 2, y + 6);
        ctx.closePath();
      }
      function drawBottle(i, segs, ox, oy, ang, glow) {
        const { bw, uh, bh } = LAY, p = LAY.pos[i];
        const x = p.x + ox, y = p.y + oy;
        ctx.save();
        ctx.translate(x, y + bh / 2); ctx.rotate(ang); ctx.translate(-x, -(y + bh / 2));
        // shadow
        ctx.fillStyle = 'rgba(0,0,0,.28)';
        ctx.beginPath(); ctx.ellipse(x, p.y + bh + 6, bw * 0.55, 5, 0, 0, Math.PI * 2); if (!ang) ctx.fill();
        bottlePath(x, y, bw, bh);
        ctx.fillStyle = 'rgba(255,255,255,.05)'; ctx.fill();
        ctx.save(); ctx.clip();
        let h = 0;
        for (const sg of segs) {
          const hh = sg[1] * uh; if (hh <= 0.01) continue;
          const yy = y + bh - h - hh;
          const col = COLS[sg[0].charCodeAt(0) - 97];
          ctx.fillStyle = col; ctx.fillRect(x - bw / 2 - 2, yy, bw + 4, hh + 0.6);
          ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fillRect(x - bw / 2, yy, bw, Math.min(3, hh));
          if (sym && hh > uh * 0.55) {
            const units = Math.round(sg[1]);
            ctx.fillStyle = 'rgba(20,14,26,.72)'; ctx.font = Math.round(uh * 0.5) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            for (let q = 0; q < units; q++) ctx.fillText(SYMS[sg[0].charCodeAt(0) - 97], x, yy + hh - (q + 0.5) * uh);
          }
          h += hh;
        }
        // glass highlight
        const g = ctx.createLinearGradient(x - bw / 2, 0, x + bw / 2, 0);
        g.addColorStop(0, 'rgba(255,255,255,.22)'); g.addColorStop(0.25, 'rgba(255,255,255,.04)'); g.addColorStop(0.8, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.18)');
        ctx.fillStyle = g; ctx.fillRect(x - bw / 2 - 4, y, bw + 8, bh + 4);
        ctx.restore();
        bottlePath(x, y, bw, bh);
        ctx.lineWidth = glow ? 3 : 2;
        ctx.strokeStyle = glow || 'rgba(242,233,216,.7)'; ctx.stroke();
        ctx.restore();
        return { x, y };
      }
      function segsOf(s) { const out = []; for (const ch of s) { const l = out[out.length - 1]; if (l && l[0] === ch) l[1]++; else out.push([ch, 1]); } return out; }
      function pourMouth(i, ox, oy, ang) {
        const { bw, bh } = LAY, p = LAY.pos[i];
        const x = p.x + ox, cy = p.y + oy + bh / 2;
        const side = ang > 0 ? 1 : -1;
        const lx = side * (bw / 2 + 3), ly = -bh / 2;
        return { x: x + lx * Math.cos(ang) - ly * Math.sin(ang), y: cy + lx * Math.sin(ang) + ly * Math.cos(ang) };
      }

      function frame(dt) {
        now += dt;
        if (!S) return;
        if (!LAY || LAY.n !== S.b.length || LAY.W !== cvs.w || LAY.H !== cvs.h) layout(S.b.length);
        const W = cvs.w, H = cvs.h;
        // background
        const bg = ctx.createLinearGradient(0, 0, 0, H);
        bg.addColorStop(0, '#1b2236'); bg.addColorStop(1, '#17131f');
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        ctx.fillStyle = 'rgba(227,174,69,.10)'; ctx.fillRect(0, LAY.pos[0].y + LAY.bh + 8, W, 4);
        // header
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.font = (S.dy ? '21px' : '26px') + ' "Black Han Sans", sans-serif'; ctx.fillText(S.dy ? '오늘의 퍼즐 ' + DAILY.md(S.dy) : S.lv + '단계', 16, 30);
        ctx.textAlign = 'right'; ctx.font = '15px "IBM Plex Mono", monospace'; ctx.fillStyle = '#ab9fb8';
        const best = S.dy ? DAILY.score(S.dy) : (store().best || {})[S.lv];
        ctx.fillText(S.m + '수' + (best ? '  최고 ' + best : ''), W - 16, 24);
        ctx.font = '12px "IBM Plex Sans KR", sans-serif';
        ctx.fillText(colorsFor(S.lv) + '색 · 병 ' + S.b.length + '개', W - 16, 44);

        // animation state
        let A = anim, f = 0;
        if (A) { A.t += dt * SP() / A.dur; if (A.t >= 1) { anim = A = null; api.setBusy(false); } }
        const n = S.b.length;
        const ph = A ? A.t : 0;
        for (let i = 0; i < n; i++) {
          if (A && i === A.a) continue;
          let segs;
          if (A && i === A.b) {
            f = U.clamp((ph - 0.3) / 0.45, 0, 1);
            segs = segsOf(A.pre[i]); const l = segs[segs.length - 1];
            if (l && l[0] === A.c) l[1] += A.n * f; else segs.push([A.c, A.n * f]);
          } else segs = segsOf(A ? A.cur[i] : S.b[i]);
          let ox = 0;
          if (shakes[i]) { const k = (now - shakes[i]) / 300; if (k > 1) delete shakes[i]; else ox = Math.sin(k * 30) * 6 * (1 - k) * L.fx(); }
          let oy = i === sel ? -16 : 0;
          let glow = i === sel ? '#e3ae45' : null;
          if (S.hint && !A && (i === S.hint[0] || i === S.hint[1])) {
            const pulse = 0.5 + 0.5 * Math.sin(now / 160);
            glow = 'rgba(120,230,255,' + (0.4 + 0.6 * pulse).toFixed(2) + ')';
            if (i === S.hint[0]) oy -= 4 * pulse;
          }
          drawBottle(i, segs, ox, oy, 0, glow);
          if (S.b[i].length === CAP && full1(S.b[i]) && !(A && i === A.b)) { // cork
            const p = LAY.pos[i]; ctx.fillStyle = '#b07a43';
            ctx.fillRect(p.x - LAY.bw * 0.32, p.y + oy - 8, LAY.bw * 0.64, 10);
            ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(p.x - LAY.bw * 0.32, p.y + oy - 8, LAY.bw * 0.64, 2);
          }
        }
        if (A) {
          const pa = LAY.pos[A.a], pb = LAY.pos[A.b];
          const side = pb.x >= pa.x ? -1 : 1; // stand beside target, tilt toward it
          const tx = pb.x + side * (LAY.bw * 0.95) - pa.x, ty = pb.y - LAY.bh * 0.62 - pa.y;
          const e = (k) => k * k * (3 - 2 * k);
          let m = ph < 0.25 ? e(ph / 0.25) : ph < 0.8 ? 1 : 1 - e((ph - 0.8) / 0.2);
          const ang = -side * (ph < 0.25 ? e(ph / 0.25) : ph < 0.8 ? 1 : 1 - e((ph - 0.8) / 0.2)) * 1.25;
          const fs = U.clamp((ph - 0.3) / 0.45, 0, 1);
          const segs = segsOf(A.pre[A.a]); const l = segs[segs.length - 1]; l[1] -= A.n * fs;
          drawBottle(A.a, segs, tx * m, ty * m - (1 - m) * 16 * (ph < 0.5 ? 1 : 0), ang, null);
          if (ph > 0.28 && ph < 0.78) {
            const mo = pourMouth(A.a, tx * m, ty * m, ang);
            const pbTop = pb.y + LAY.bh - (A.pre[A.b].length + A.n * fs) * LAY.uh;
            ctx.strokeStyle = COLS[A.c.charCodeAt(0) - 97]; ctx.lineWidth = Math.max(4, LAY.bw * 0.14); ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(mo.x, mo.y); ctx.quadraticCurveTo(pb.x, mo.y, pb.x, pbTop); ctx.stroke();
          }
          if (A.done && ph > 0.75 && !A.burst) { A.burst = 1; burst(pb.x, pb.y + 10, A.c, 18); api.sfx('pop'); api.buzz(15); }
        }
        // particles
        for (let k = parts.length - 1; k >= 0; k--) {
          const q = parts[k]; q.l -= dt * SP();
          if (q.l <= 0) { parts.splice(k, 1); continue; }
          q.vy += 0.0009 * dt * SP(); q.x += q.vx * dt * SP(); q.y += q.vy * dt * SP();
          ctx.globalAlpha = Math.min(1, q.l / 400); ctx.fillStyle = q.c;
          ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.l / 90); ctx.fillRect(-q.s / 2, -q.s / 3, q.s, q.s * 0.66); ctx.restore();
        }
        ctx.globalAlpha = 1;
        if (S.won && !A) {
          ctx.fillStyle = '#e3ae45'; ctx.textAlign = 'center'; ctx.font = '30px "Black Han Sans", sans-serif';
          ctx.fillText('정리 완료!', W / 2, 78 + Math.sin(now / 200) * 3);
        }
      }
      function burst(x, y, c, k) {
        for (let i = 0; i < k; i++) {
          const a = Math.random() * Math.PI * 2, v = 0.08 + Math.random() * 0.22;
          parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.2, l: 600 + Math.random() * 500, s: 4 + Math.random() * 5, c: typeof c === 'string' && c.length === 1 ? COLS[c.charCodeAt(0) - 97] : c });
        }
      }
      function confetti() {
        for (let i = 0; i < 90; i++) parts.push({ x: Math.random() * cvs.w, y: -10 - Math.random() * 120, vx: (Math.random() - 0.5) * 0.12, vy: 0.05 + Math.random() * 0.15, l: 1600 + Math.random() * 1200, s: 5 + Math.random() * 6, c: COLS[i % 12] });
      }

      /* ---------- input ---------- */
      function hit(px, py) {
        if (!LAY) return -1;
        let best = -1, bd = 1e9;
        for (let i = 0; i < LAY.n; i++) {
          const p = LAY.pos[i];
          const dx = Math.abs(px - p.x), inY = py > p.y - 40 && py < p.y + LAY.bh + 24;
          const half = Math.max(LAY.bw / 2 + 6, 24);
          if (dx < half && inY && dx < bd) { bd = dx; best = i; }
        }
        return best;
      }
      function tapBottle(i) {
        if (!S || S.won || !api.canAct(0)) return;
        const b = S.b;
        if (sel < 0) {
          if (!b[i].length || full1(b[i])) { shakes[i] = now; api.sfx('tick'); return; }
          sel = i; api.sfx('click'); return;
        }
        if (sel === i) { sel = -1; api.sfx('tick'); return; }
        if (canPour(b, sel, i)) { const a = sel; sel = -1; api.act({ t: 'pour', a, b: i }); return; }
        if (b[i].length && !full1(b[i])) { sel = i; api.sfx('click'); return; }
        shakes[i] = now; api.buzz(30); api.sfx('thud'); sel = -1;
      }
      const onDown = (e) => { if (ov) return; const p = cvs.local(e); const i = hit(p.x, p.y); if (i >= 0) tapBottle(i); else sel = -1; };
      cv.addEventListener('pointerdown', onDown);
      const onCx = (e) => { if (!ov && sel >= 0) { sel = -1; api.sfx('tick'); e.preventDefault(); } };
      window.addEventListener('lounge-cancel', onCx);
      const offIn = api.input ? api.input.on((type, id) => {
        if (type !== 'down' || !S) return;
        if (id === 'undo') act({ t: 'undo' }); else if (id === 'reset') act({ t: 'reset' }); else if (id === 'hint') act({ t: 'hint' }); else if (id === 'extra') act({ t: 'extra' });
      }) : null;

      rafStop = U.loop((dt) => frame(Math.min(dt * 1000, 50)));

      return {
        update(s, prev) {
          const fresh = !S;
          S = s;
          const L0 = s.last || {}, P = prev && prev.last;
          if (prev && prev !== s && P && L0.id !== P.id) {
            if (L0.t === 'pour') {
              if (anim) api.setBusy(false);
              anim = { t: 0, dur: 820, a: L0.a, b: L0.b, n: L0.n, c: L0.c, done: L0.done, pre: prev.b.slice(), cur: s.b };
              api.setBusy(true); api.sfx('chip');
            } else if (L0.t === 'undo') api.sfx('whoosh');
            else if (L0.t === 'extra') { api.sfx('pop'); api.toast('빈 병이 하나 생겼어요'); }
            else if (L0.t === 'hint') { if (s.hint && s.hint[0] < 0) api.toast('여기서는 길이 없어요. 되돌리기나 다시 하기를 써 보세요'); else api.sfx('tick'); }
            else if (L0.t === 'new' || L0.t === 'reset') { sel = -1; anim = null; api.setBusy(false); closeOv(); }
            if (L0.t === 'new' && !s.dy) { const o = store(); o.cur = s.lv; save(o); }
          }
          if (fresh) { DAILY.prune(); const o = store(); o.cur = s.lv; save(o); if (o.max && L.best) L.best.set('watersort', 'lv', o.max | 0, { label: '최고 단계', unit: '단계' }); }
          if (s.won && lastWin !== L0.id && prev && !prev.won) {
            lastWin = L0.id;
            if (s.dy) {
              if (api.canAct(0) && !api.players[0].ai && DAILY.complete(s.dy, s.m, api)) api.toast('오늘 최고 기록!');
              setTimeout(() => { if (!S || !S.won) return; confetti(); api.sfx('win'); api.buzz(60); if (api.canAct(0) && !api.players[0].ai) winPanel(); }, 760 / SP());
              refreshBar(); return;
            }
            const o = store(); o.best = o.best || {};
            const ob = o.best[s.lv]; if (!ob || s.m < ob) { o.best[s.lv] = s.m; if (ob) api.toast('새 최고 기록!'); }
            o.max = Math.max(o.max | 0, s.lv); o.cur = s.lv + 1; save(o);
            if (api.canAct(0)) api.best('lv', o.max, { label: '최고 단계', unit: '단계' });
            setTimeout(() => { if (!S || !S.won) return; confetti(); api.sfx('win'); api.buzz(60); if (api.canAct(0) && !api.players[0].ai) winPanel(); }, 760 / SP());
          }
          refreshBar();
        },
        destroy() { window.removeEventListener('lounge-cancel', onCx); if (rafStop) rafStop(); cv.removeEventListener('pointerdown', onDown); if (offIn) offIn(); closeOv(); bar.remove(); api.setBusy(false); cvs.destroy(); },
      };
    },
  };
  def._solve = solve; def._gen = gen; def._daily = DAILY;
  L.register(def);
})();
