/* 나라 퀴즈 여행 — 단서(국기·인사말·음식·명소·수도…)를 보고 세계 지도에 모두 동시에 핀을 꽂는 위치 퀴즈.
   거리(대권 거리)로 점수, 맞는 나라를 찍으면 보너스. 힌트를 더 열수록 그 판 점수 배율이 줄어든다.
   지도: Natural Earth 1:110m 나라 경계(퍼블릭 도메인)를 단순화·압축해 넣음(오프라인). 국기는 코드로 단순하게 그림. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ───────── 지도 자료: {ADM0_A3: [표시 경도, 표시 위도, 이름, '고리 고리…'(폴리라인 인코딩, 0.1° 단위)]} ───────── */
  const MAP = {"FJI":[178,-17.8,"피지","ooB`I?HXF@GOC inB|IECED@JL@HA@IGE joB~HBJ?I"],"TZA":[35,-6.1,"탄자니아","eTPkAj@AJ[RHVAJKDADDJ?NM^GBNJTFJ?DDL?D@VEL@DYJOPCh@QHWJKBKAIBQI?SU@GBC?GEA?KFKGAU?"],"SAH":[-12.6,24,"서사하라","lDiP?b@`A?Ap@R@BHC\\lA?DDAGk@ACGGGE[[UIWEAEOOAQ@ECK??K"],"CAN":[-101.9,60.3,"캐나다","vkAs]v@[b@GJQAKVIBOVM?III?K`@M`@c@\\QJIRDRJ\\URER??{De@B_@HS@QGWE]@]G_@EMFMCEIM@_@P[MANWCGEW@_@Fm@F[BSAYHZHc@Bu@AQCSJUIRGKGi@AOBSJUAa@H_@C]?BKQC_@F?PKOO?ISTKVGAUWMY@SH[TPHe@B@R[OWLDLQLUMMQAUy@BYHAHNJMH@Hd@LZ@TEDHPPDFVLZ@NF@JTBXNRTFN@V]@Q`@[Ce@FSFMHWDUFu@B@NERMT]ROEIUH]LK_@GUMKM@MLQVMWUHQD]MEu@FQCi@PEFc@??PEVQBOJ[KSUKG_A`AFLYHQJ_@DMDGNMBGDAVZL`@DVP`@@j@Cp@@NLXFr@l@OCa@Yg@O]AQHPJKd@YHa@CSUALKFVJl@JPFVNLA@Qc@Ot@BLK?[FELBDCNLDNFFLB@DbA?^RDFd@?H@CBAFXHTBTHD?DA@EMQEKHa@RIACFABC?CH@AADA@EdA[PD\\ENBRG`@CDABKF??FnN? ns@af@MG[??BVHL? zp@ol@TIAGu@?c@J?Dh@ATB dq@ye@GEG?CBFJFADE ny@{m@JFZAVCII[CQD ry@mo@n@ABCg@?MB n{@gp@WFBD\\BNCHG?GY@ bv@om@rAGFK@IRGh@ATGGGg@@UDg@?QFDDc@Hw@@_@CiA?SFEFLBZDXCx@B pdA{o@[BDDd@DZEOG jdAgp@YBVB^??CSC va@a_@V\\MGKDDDQDGESFDLMCIVHNF@LCCOBCVPJ?MIRCz@?@EKGFCOKS_@MKOEI? ls@ug@m@J?HOAMFPD\\EJGRHZHFIX@OICOEQM?CHIC fp@gl@SEk@H[FAHe@ESLo@FQFQPb@Ho@J]D]P]?DL`@VVG^SX@@JSJ[HGBKRDLXCp@Oq@ZAFt@Gh@KVIEEx@S?Dx@BPGMMmACDEGIWSJO\\Ih@EMCTMP?NGHDb@BfAEjAGNGSGZ?DSOQSGs@ENJOLQOs@Ia@T@J `z@im@i@?e@B\\PVBTNTAJO?III xkAqn@a@Oi@K]?[A@LNFP?d@F^B |qAw`@SADTONF?JGDIJE@I?E |`Aqp@}AHMHGF^A^El@ASEVC dlAi]H@`@GDGPE@ETCDI?Es@HQNSF |jAom@[Bq@?i@LhARXL?Fr@HHGl@KUUQMRK jbAkn@QCS?CHJHbA@p@H\\?BEi@IxABZC[SQEw@Fc@Ja@?ZQQGU@EH paAul@UFQ`@eAR@F^@KFDDfAGT@d@DtADJIXEP@VOk@C[?YCd@CfA@HGm@G^?`@EOMMGu@KSBHFm@EYHWIQFOPIGLSQA v}@ml@TMUGWBc@CEDRH_@FBP`@FPALEp@O?E raA_m@Y?OBPJ\\M p|@}n@OF?JHL^@TC?I^?@MU?]E[? ~z@kq@MESAFCm@AYJaAFOJWFZDb@Lb@@h@ATIAEOEd@?TEJI fx@er@{AG]GW@UDOK}@C}@AI@y@AkCBi@@e@D@Bn@Hp@BPBk@?nAP`@Nf@BLBz@@[@LBOHPD^DHFZDCBa@??Bt@Jr@Ex@BbAC@Ic@CHMMAs@HXM`@COGc@CEEZGFKeAB_@Gl@AdA@b@GNGVE ~m@ci@LDT?BIGIQCOD?F d{@mj@MFLDXEN@ZGQEMG_@F hg@e^EAYDUF?BH?XE ~f@k\\EFOBQ?HFF?VGDE"],"USA":[-97.5,39.5,"미국","vkAs]gP??GG?CJE@a@BSFOC]DQEeAZADE@@@IA?BCBG@@BSHI`@DJLPADE@E?UIUCYI@GBCIAe@?EG_@ScA?AEMCGGEOOMEBMCGD?ZMJADRHh@JLN?JEHG?@EEB@Dx@FND]CEBZDL??CDDE@BLLN@EHECHCB?FNV@AEKHG@QBHCJLAMD?PE@EXLNRDLJH?HF@DTLRTBLCLENIL?HGT?TDJD@HA@GFER_@BGEMDINOFCRHLKJCT@PAN@F@CD?FCBB@FAFBL?LKP@LC\\DPNRFHHDF?LAHCDF@\\KHUJKPYLGN?JNNEJEHS\\W`@??Hv@?jAWACn@BBIJKHA@EJADCRABC@KRSN[?CVWBOHICO?QDOGQCc@B[JYAC]FIPEEBO b`BqKKJPJBC?CBGCE?CA? n`B_LFBDEAAE@ ~`BgL?@H??A vaBqLEFF?BE rbB{LABB@DCCA `gBwd@O@AFJ@XG v~Agc@K@IDd@PHEBIQE hjB{f@KBKAODS@NDVGP@BA"],"KAZ":[68.7,49.1,"카자흐스탄","su@w]NLN?@RHHf@ELb@JBd@FQ`@LDAJLCHG|@AF@ZGJB@J`@EJ@BFd@PHLD?DGXABOH?ASVMx@BPQr@Wr@JAhAH?LMLEVBFD@CEGBGVEFQJE?ES@?MQCO@CQBMR@NCh@JHCAIJKN?NMIOBCMUUJAMi@U]?cATUG_@AWJEE[?EI^MQGBESELMGEkAGICq@GQGc@BETSEYF@HS?q@SFDYNk@p@KIYJ]EIBIJMBGFYA"],"UZB":[64,41.7,"우즈베키스탄","_b@yX@iAs@Ks@VQPy@CWL@RI?CNY@EFE?IMYMKCE@PLOFMEWHXNVA@ECIZDDJHJNADHOBCLJTLEJ??KXGRIb@WHSFCR@FC@OZKNJPFCH"],"PNG":[143.9,-5.7,"파푸아뉴기니","cwAr@gAXWRCJ_@JEHP@CLQJKTK??FMBDBUF@DL@BEd@EXWJOXIZJANNDHATA?_A k~AhAGDAHDDFSROLECCYL q}ArBTHH?ZKAEQBIACIA?AHK?EGIE@KKACB?JDJH@ w_BhBWV@DD@FGHKBOCA"],"IDN":[101.9,-1,"인도네시아","cwAr@?`CPORCBDX?GOMEDUHOd@QN?\\SDHF@BG?GNIUEM?@E\\?FKPCFI[CIE_@FGf@UJOUUKQ?_@L cmApDAHLLND@CAEGK {rAhC@OGMCD?H uhAqAJPMP@HUPV@DL?PPL@RF\\@ETFFKLAHEVFFIL?NA@YHEHO@QAQKMALMHMCK@KIIAQDOCI[GGGUU? {oAv@UDENNIh@?CK inAjALCBGSACF }nAk@AJK@AF@NHA@LGHD@FKDYCO ykAQW?SMABNRLBRCp@BBLQPKGc@G?HHCFJPFSXBDQV?JJDFEIORFBEAGLKASLDAr@JBFEEQBSF?DMGMAMMg@QMOD ejAlEXMQCQJ@B yjAhDM?QG@H\\DZA?GOC }hAfDKACFb@DJ?GIIAEE ybA~BAFe@@EGc@FGL]BWJTFTIf@?v@MFBb@GBIP?MSW@OD g`ATALGHM@ILBV@^T?NQXOV[Xi@NQL_@PMHONKRU@IK@_@BQPYTQTU?OLKNMHFNKF"],"ARG":[-64.2,-33.5,"아르헨티나","zi@z_@QVYJ[DHHP?JE^? ~b@zQHb@?RBDBTYPBLMF@HPX\\Hf@BTACJBNCHJDTBPGFDARMDIGEJPDNJ@RDHP?NJDLSLSBFPVJJVPFFFETMHZCn@AFK?ML?DE@UOGEM@IIOEY@KIC@GHCEGFGBUGCBYIe@KEDS?QMM?OKS?QDCFa@KU@QEQMSMKDGCE?a@UIES@EOQYDKLGOW?g@d@O@WNSFCFR\\i@FOAQOCQICIJ?N^RTR"],"CHL":[-72.3,-38.2,"칠레","zi@z_@?l@_@?DFNDTANERAXKRIZWQB[LYFIIEMSG nj@~IILALKFFRKTGZMCADDRTH?`@BDEFLJLRDPAPJTG`@EB?PJR?NLL?PERJDHd@CXFBCTGFDFIBAFHBAJDXHNAHDLNFATEDM??LGJaADP?XJBPF@VGl@WFMEKHK@a@GSUO\\EQOEa@WFIi@LEDXJCKaAIKDS@UGAY_AI]D]EO@WKYO{BD}@IC"],"COD":[23.5,-1.9,"콩고 민주 공화국","iQxACP@HCJKJIVFA^DDLEFDj@QJECATNALQNCBIJDNAFIT??ENAXB?WDG@KAKBG?KV?AGH?@BJ@FNHCRDJQJYx@?TB@ECAAIACGCE@EGI?ADGB[]?OGSUSAECM?KAOIWAYGIKE[L]DGMI@UIGBE?CEGAYBGAKNG@ECI@ICEFOL?VG@LJJR@NBF?LDD?JB@@HEH"],"SOM":[45.2,3.6,"소말리아","_Y`@JO?iAU[MAQMY?w@{@U]?e@[EGEG?@ZBDBTTn@P\\f@n@dAr@TVBH"],"KEN":[37.9,0.5,"케냐","oW|AZS@KjAk@?SOUEMHa@HKYYIB?HGFM?WNK?QBEGQIGFM?PT?hAKNLFDFD@BLDFBJ"],"SDN":[29.3,16.3,"수단","kNcDTO@ECG?GJK@MFE?KBEF?GO@GEEBCM[Q@?wAU??g@mF?ERBBARGVQJHJL@DDJj@AF@NFRJHJVFDDR?P?OB?@OHG@MAOH??BJ?CDAJRXJ@NKFB@DHB?BR?BCL?D@DALOL@DHDPJD"],"TCD":[18.6,15.1,"차드","{MgKAnAPALZCBDDAFFNG?CD?JGD?DL@HFLTPHRAD@AFPLXFFEBDN@AEFUHCHICIG@QAJQ?YFMAGJA?KHGIYWQAYGi@CGFE?EFEB_@SImAd@"],"HTI":[-72.2,19.3,"아이티","xk@iKAH@FBBCD?DLCT?FBJEAGa@DGEHG?GJACEK?"],"DOM":[-70.7,19.1,"도미니카 공화국","xk@gJ?EBECCAG@IACO?KDC?CDK?@DI?IFFFHCN?@BF?BCD@FLDC"],"RUS":[44.7,58.2,"러시아","unBmk@YG?LT? u]_\\HJPBRRQP@LUVJFBBF?LKPEDGRCJ@@AZIl@G@BXQVGNIMCOOHG[G?EPBAGIEQACEBKGI?E\\EJ?JINBVG?CFGNA@EECJIZ?BBF?HSCAO@GEDCLCACFCJKCE@IRCH@BCREDK@GHEGEDQMK@CUIRI{@e@GI\\MGKPMMQTUQO^MCMq@ISEa@Ju@BkAVOF?LTH^DxAOLB_@LA\\i@JAIJIMEo@JOEJMm@SQ@QDKMNKIKLKw@DIJV@?JMD_@CCKoB[O@RJW@MEe@A]GUJWKTKKGy@F[DgATMIRI@EVAGGJO?Ec@QMQMCu@BCJRNMDELBZUJHLd@ZU@GEUEEIQIJIGMTABIOSXOc@MBMIAIJFRU@HMa@Gi@?c@HPO@Sc@Eo@@i@ANKWKU?g@Is@CECu@AOBk@Ie@?CISGo@Ga@DZDm@@CHSCy@?k@HOFBHhANNDu@FQCILIE_@C_ABCHsA@AMiA@_@JIJJFWN_@FSS_@Fa@Ee@FMEa@@NQ[GsDJQJs@NoACg@@OF@NWD[Cc@Ac@Be@Ac@PWENMIG}@Di@Ay@H[F?nAXHXAQHKNIDAFDDb@Cv@LP@z@ZFFZMr@NHGPHZCDLVRAFUB@ZR@FNGF`@JFT\\BDTZPFMRiAI[QK?G_@EeAk@c@OO]V@JPr@TNYr@Fp@^OLhAD?M\\CXHz@A`ADlCtA_@@IJSBKIU@[TAPNR@VF^\\ZFL`Ax@ZJJ?JIZL@FBC?II?CWDQQEWBMSEUGGIQ^DPF\\?FQVM`@GFQZi@NG\\Er@BNHID?HHFPR?HZJVGV@HEJA\\Lj@Fj@CJIRIRAj@DZGBOh@ETGTRGJPL\\ER?LIR?PE\\Hd@NZDJKX@FGLCHKHC\\DXKJHj@q@XOGEp@RR?AIXGRDDUb@CPFp@FHBjAFFDMLRDCDPF_@LDHZ?DDVK^@TFbAU\\?h@T@LTKLTCBHNOLO?KJ@H sy@sq@i@Eg@Jm@PDPh@@v@C`@GNMXC g_Aqp@s@JDFpBFe@YOA wuAqn@u@?gAHNNhA?^Bf@MIK s{Aan@q@BTF^Ad@GEE mvA{l@QGYA[FADfAA _[kq@eACCDKEQA]BFBj@B@@VBTCKG eM}`@z@ACI[E]D@D m`@am@o@QDIm@IaAMaAAa@Gg@AMFLDbCP|@R|@d@CPe@NJ@~@CDGb@E@ISC@Kg@O ixAq`@GR@PGTU`@\\EJZQT?LNKJLBOAS@UCMA[JQA[QIFGIC hlB_i@@JMDDOu@Bg@PRH^@@PFBP?NEXEBIRAV@HECGVBIHJF?oAq@N tnBik@X@?MAAQ?[D@B {Sw[ECSBEDIDSABFTBXHJCCGREACSG"],"BHS":[-77.1,26.4,"바하마","jp@wOW??BTB ro@{OOFBLBAAIHG zo@wNE?GP?HD@BKFE"],"FLK":[-58.7,-51.6,"포클랜드 제도","fe@j_@WKQDKGOFDFZDFGPH"],"NOR":[9.7,61.4,"노르웨이","mHyp@GE]AyATp@FHNPBHNV?h@KQE\\Ef@QNOw@EID mRoj@p@HGMXG\\FHLRHREX@VKJDJ?@Ld@CDJP?`@b@\\ZEFDFRALRAXKHDVNLHHJKf@VZBXIFUDm@QKu@Qe@SuAaAwAg@k@I_@@]Oe@?c@C}@LXD cPaq@\\Jx@@x@CBCZATG}@E[BSEq@D mNuo@j@Hb@EMCJGi@CGF"],"GRL":[-39.3,74.3,"그린란드","f\\sr@cAKeA?YEeAA_D@}BNd@FvD@IBeAA}@De@EOFTHs@E_BG{@BKFpALHB~@Bm@@f@X?VWJ\\@`@De@HCPT?YPj@@WFFDv@BYL?Ff@GHD[BYJEN`@Bf@QEJVJqA@jB^z@FT?RFZRj@LbAHPL?LHJ^NGNRb@Z@\\Qf@?PILS`@WHMBQZQGMLGSW]EGGCOr@JVE@MGIS?g@Br@QR@NEUQJGf@a@XG?Gt@Kh@AdB@x@Qs@Eg@ArACl@GAGuCSGGt@EOGeAM]AHIo@C}@C}@?UDs@IuBLn@I"],"ATF":[69.1,-49.3,"프랑스령 남방 및 남극","aj@j]MDQBABDF^@?KCG"],"TLS":[125.9,-8.8,"동티모르","cmApDACOEUAE@DDd@L?E"],"ZAF":[23.7,-29.7,"남아프리카 공화국","eIzPIIGDCFUBI?QI?iAE@KR@JCDMASMCIICQFO?MCCOKAKSQO[MQBGAI@Mh@@T?DHAD?DL?DKJKACIM?D^DHPJV`@d@`@LFTFH@@BJAHBTCJ@F?TFN@JFH?FEDAHG?@BCAKFMEC?MTc@ cQbQHGFDJDHLMLGACEIAIO"],"LSO":[28.2,-29.5,"레소토","cQbQEDHNH@BDF@LMIMSK"],"MEX":[-102.3,23.9,"멕시코","dhAiSo@C@BkAVw@??Ia@?]VIRKDODKOO?MFQXKJIT]JGAJ^Bd@CHEHCNMLCJGHUBGH{@OKGEK?OCEc@I[?EB?HJHBLC@FVDCF?DJBAB?ABd@??HH?UP@DV?HNAB@JVUHENEJ@XFZGPINATITM^GFGTKLUEA@ECE?EL[PSRMHMPG@CAKHEJIBMJ?RU@EHMFOAGNGD@JE@FCV[ZCFA?CJWTERKP?HI?OP?BHF@?DKJKXMAOBIVO@BBELCJKI?GG?ILMJEVg@"],"URY":[-56,-33,"우루과이","~b@zQKASNG?c@TKLHHEJFJTJNCH@PIL@JKAKCE?SCS"],"BRA":[-49.6,-12.1,"브라질","j`@bTDKIIJMb@UF?ROJ@o@m@_@S?OHKHBEU?KFCDBF?BYBELEFBRC?[DIEC?KCGCOBKJE@GCKf@?DWC?BYJEJ?FELCFGTATQAc@X@ZNDDV?J@FA?]NJP?FKJ?CIJKFQEC?GKE@ICGAGWMOCAAQ?I_ABKFE?MICC@AGJA?Ke@?GECDCJCCKJOAAEWGAGME?CPA@K?MFEC?]DECc@IGG@EI?CB@FEBEFDFBNGRKHI?ACMCGCY@ACBCAEG@IASFEEC@CBI?EGGMISG?Ol@IBALNNEDc@@?ROKy@RIHBJWEe@H]?]NYTMDQ?GFIb@F`@d@f@LVLND@DLAd@Fj@DFBXRX@RPHBJT?\\FNFTDTNPR@LAJBRBHLHTb@^VFR"],"BOL":[-64.6,-16.7,"볼리비아","lj@zEW?EE[OYA@b@UPU@GFMBGDK?KDCXB?EVg@?BJAFKDCJBNBF?JDB?EPIPAb@DHP?JFT@CV?FNJMXENPLBF[JUGSJG@MHMKUFOCG@EGI?_@CE"],"PER":[-72.9,-13,"페루","tj@tAP?@@NBVL@FBFAHJD?FDBGPKJBHK?GJQ?OK?\\G@KAO^BD?^FHADBFGNP^HBRI@Gd@Sb@UNMFOAENYd@kAFIFMLMLGEGHSEMOKAFDDADGAGBGHKIAKMQWGUSEMBMEAMFEHGDKRO@ICG@K?OFLRE@"],"COL":[-73.2,3.4,"콜롬비아","xh@YBBBKBEFDd@??JK@@FBAHB?LGDCJH~@HIDAMSNGJ?FAHBNAJSFEDILGD@PKD@NADGB?RK@EGA@IEEIAOUFECKBQCCBQFIAIG@CEDKACK@MMGACWKIK?ACO@WOGGG?EDBDLBBHLJ@NDHI@AHEB?F?JC@CDYAK@MPa@CGBFP@LCLED?BHHGBCD"],"PAN":[-80.4,8.7,"파나마","jo@mD@BEJBDFA@HDEBKCCBABEHEH@BDJD@BIJFBH@BK@BDABGTC@B@AAKCABC?GGAEF?BI?EBIASGEEUBGBGD"],"CRI":[-84.1,10.1,"코스타리카","pr@_EF@?FCBB@@JHCBEAGRI@EDCADBBBCFA@CAMBAEEMBCAE@CBE@CCEHGF"],"NIC":[-85.1,12.7,"니카라과","hs@yEBBNGB@LC@@f@c@ACCBGAAEC?@II?CCEBKKACCCIBQGG?BDAFDL?V@@@LBBAD"],"HND":[-86.9,14.8,"온두라스","|r@kHF?PFHCBB@BJJDCBBH?AHB?@DD?BEDAAGBABAFBJIDAEE@GYOS@I?GCK@GAKBSH"],"SLV":[-88.9,13.7,"엘살바도르","zv@_HE@KHGCGBBLJANEH?DC?CKE@C"],"GTM":[-90.5,15,"과테말라","rx@aHAK@CIOW?AETQI??Ie@?@d@E?EBACEBRJAFDDB?ABJD?BHCJ?HC"],"BLZ":[-88.7,17.2,"벨리즈","tv@cJ@CC?C@EKGBBLAJBHBB@@BDD??U"],"VEN":[-64.6,7.2,"베네수엘라","|d@gBADFFb@HDB\\EB?GD?LAJQ@?BLD@FVF@DN@JKDSBEFCII?CDEBMAMGQFC`@BLQJAX@BEBA?K?GDC@IHAEIAOMKCIMC@DH@EF?JHHGNG?EOFE?OWG@GGGELM@MH?Dg@?IFO@KE?Co@ANDEHO?OHANI?GBNJ?FEFB@LBAHDB"],"GUY":[-58.9,5.1,"가이아나","hb@e@N?FBLB@BH?JIFSCOEGDGDCAGBCH?LOEC@IMCCADG?GOKMFKL?HG?SNBPJD?B@HGNE?AH"],"SUR":[-55.9,4.1,"수리남","`a@m@JCH@FA@DCB@BHALQ@ID?FOAI?CKECQWBACO?SBHPALGJDP"],"FRA":[2.6,46.7,"프랑스","h_@sAHRFLDFH?BCBADDFCCGEQFK@MIQUFUN {B}]ID[BHL@LDBHAABNJ?FIAEF?DEFFDELIB@FPJd@E\\D@JVBTIFBb@GFGIKCg@RUNI\\G@MYCa@DDWQHm@OEOQCCDG?WPIAUJ mDsYMGCNFNFCDM"],"ECU":[-78.2,-1.3,"에콰도르","bn@BCLDLTRVFLP@JJHFIFCF@@EEE@GIMBIFHJICC@QECCKGM@GWKSJC?EFO@EAID"],"PRI":[-66.5,18.2,"푸에르토리코","lh@qJI@CBBBZ@?IAA"],"JAM":[-77.3,18.1,"자메이카","no@qJM@IBCDL?DBJCHEAEG?"],"CUB":[-78,21.3,"쿠바","lr@oMa@@QDGFSAc@XQB@DO?MF@BXBLA\\@MIFEJ?FEBKJ?PCDCXCFCGCRALHF?BDF@HAKECGGCYE"],"ZWE":[29.9,-18.9,"짐바브웨","oR|LHAF@PCJINADK?GFATUP_@a@B][EAAGKGOA?FQ?GBEBG@ID?X@L@LCD@JB@DL"],"BWA":[24.2,-22.1,"보츠와나","kQxLZLPNJRJ@BNLBN?PGHBBHRLL@BEAKJSDA?{@S??eAOA]EGFKGQCC?Q^UTG@?FEJO@"],"NAM":[17.1,-20.6,"나미비아","mKnN?hAPHH?TCBGFEHHLOFMN_A?W@KPWNe@NQ@OUGM@KFsAAMHo@@s@KM@GDPBJFFG\\DN@?dAR?"],"SEN":[-14.8,15.1,"세네갈","lIoGFOHEGCMWGGI@ICI?WJWZEVEDALLADBLEl@?VB@OQ@OGGBG?ICBEFBD?FED?BD"],"MLI":[-2,18.7,"말리","dFwF@MDEDWGCAKG?KDKCG?ACqA?CMBARmD_@?eCvAEHSFAJUA?l@JL@Jj@DFDX@BCJ@PFBFNF@DFBHCDD@LNN?DDFAJLD@GH@BDL?DC@@DE?E@AB@?ECELQB?PHFAFEH@"],"MRT":[-9.7,19.6,"모리타니","tIcLEEmA?B]CISA@q@aA??]kAn@^?SlDC@BLpA?@BF?JBJEF?@JFBV[VKH?HBHAFF?KCICQD]AIBI"],"BEN":[2.4,10.3,"베냉","u@}BNBDMAm@BC@IJMAIEACGIAKKE?OH?FCJBFABNRBJ?J"],"NER":[9.5,17.4,"니제르","iHiMC^GD?DGDBFFh@@XVPHXIF?JK@@FD@?DB?LUB?NJNEHADBJAJFH@VIHBH?FGRGRBDB@HDF@PNID?DD?MVE?GJM@GAIKAGEk@EAKKM?m@[Gy@g@cAe@_@HIH"],"NGA":[7.5,9.4,"나이지리아","u@}B?k@CKOS@CCGBKAYEGAIECSCSFGFI?ICWHIAKGK@ECI@ODOKC?MTC?GFBHNNNh@JFHXJFJIF@JHD@L^RFFAFDNAHKFMLML?"],"CMR":[12.5,4.6,"카메룬","aHaGGL?XKPP@FABHIHIBGTJXDB?\\IH?DGJIDAL@J^I|AACOFKHCBIBAESGQEAKIGAKHKGIYKGOi@OOCIFG?E"],"TGO":[1.1,8.8,"토고","Q{E@HKLAHCB@l@ELNBHS@ICQBG@]FI?E"],"GHA":[-1,7.7,"가나","?{E?DGHA\\CFBPAHIR|@VPEAGFQCUGOFk@AKi@@GC"],"CIV":[-5.6,7.5,"코트디부아르","~CkEAAEBM?CEIAAFMEGBCFIBEEI?MDCZFNBTGP@F`@CVB`@LBAAYFGDADECG@IAEA??KIEHWAE"],"GIN":[-10,10.6,"기니","pG{FI?MDECM@?DIAGDG@QIC?MPBD?DCAA@?DEDB@@DIVHD?JF?BFD?BCAGHKLB@SHMN?D@B@DHHFPSHEBMDAGIE?ME@EAA"],"GNB":[-14.5,12.2,"기니비사우","lIwFWCc@?@HADLDD?FHJIF?BIDC"],"LBR":[-9.5,6.4,"라이베리아","fDyC?NBFEDE@GF@XD?RGb@YJMEKQSGAIJ@FCBE?CG"],"SLE":[-11.8,8.6,"시에라리온","fGqDIGEICAEAO?ILAREAPRDJRIHIBG"],"BFA":[-1.4,12.7,"부르키나파소","jBoE@KEG?EOOAMEEIBGCAEOGCGQGKACBM?@HAFKL?FWD?LDDH@BFD@XAFBh@AAZLEH?DDHCBG"],"CAF":[20.9,7,"중앙아프리카 공화국","cPgBF@XCF@BDD?FCTHHAFL\\EZMJDFH?LZCJHHP@MHEFK?EHI?]ECISOACEGDYGQM@GEAS@QIMUIGMAAFKJ?FBFAD_@V?DUREJMD"],"COG":[15.9,0.1,"콩고 공화국","qJeA@JHV@N?JBL@DTRFR?NZ\\FC@EH?DFLILJNSOKFKEEMAAIIHQ@EIAM@MHKIWDCL@DIAIW@_@HAKIQKIM@"],"GAB":[11.8,-0.4,"가봉","aFm@I?K@KAA?@HEHMAEBHVIJAL@LDHPAHI@HL@DDGJNJ`@e@JSMi@c@A"],"GNQ":[9,2.3,"적도 기니","_Em@a@??Vb@@BC"],"ZMB":[26.4,-14.7,"잠비아","eRdDi@PGHENFTCNDFDPIDz@NALN@JF@FD@\\Z`@CJELANBX[?_Ai@?@ECGBIAI@EG@?DU?GHO@KECHOBMPO@@UDBPKEk@DGEM_@E"],"MWI":[33.6,-13.4,"말라위","oSvDQBKNEXDNEXE?GDGLAXHBDLJK@MCI?GFCD@TOEQEGBOGUDO"],"MOZ":[37.8,-13.9,"모잠비크","sTdFMAWDEAM?EEK?UGOKCHAbACHLZJJh@PTTF@LNFB@LINCNC?@R@FCB@FHFf@PFDAFC@@HL?DWAULi@SWEMCAAKBEC[?YHEFADCFCP?@U{@OKHEAGB?FBHALKJEMIC@YFMFED?DY"],"SWZ":[31.5,-26.5,"에스와티니","aStOBHJ@JK?EEME?I@CH"],"AGO":[18,-12.2,"앙골라","cG~AFB@B@HB@DOMK uFxBUCy@?KXKPSEIBGOKAACI?@FW??JCF@JAJEF?VYCG?AD@HCHBFADh@??~@YZb@Fn@ALIrA@JGLATF@KKm@IYQUAM?KDEHWEKHa@HK"],"BDI":[29.9,-3.3,"부룬디","aRn@?FCBAFRTH??WDIK@EK"],"ISR":[34.8,30.9,"이스라엘","iUmSBDDABJC@BB@BIA?FH^Ja@EE@AK]G?ACC??F@B"],"LBN":[36,34.1,"레바논","kUySB?@BF?GOIMG?CFHF"],"MDG":[46.7,-18.6,"마다가스카르","}]xFKTAVEFDNDKBDCN@FDB@Pl@hC`@LZKBI@QFO?MAOIA?GIMAMHU?QEIAMI?SGG?[WEI@GG@IMAKEI"],"PSX":[35.3,32,"팔레스타인","cUuRH@ACCCBACKE@?J"],"GMB":[-15,13.6,"감비아","lIoGU?CEE?GDE?GCCDHBF?FCNFPA"],"TUN":[9,33.7,"튀니지","}D}QFc@LG?CNK@OKKEOBQCIUGM@?HOGABHH?HEB@PLHCHK?CHGB@LZRAF@H"],"DZA":[2.8,27.4,"알제리","lDcP?[_@Oe@GEIWGAMIAIGYCCGDCDS@KFMSIUCKGSEaAEIBSGS?GBM?BHCPDNJJANOJ?BMFMt@AFDd@AJFFKL?HGHICOHGJbAd@x@f@ZFT@@KRGDIdCwA"],"JOR":[36.4,30.8,"요르단","eUgSCEUFg@UGVBBf@HSRDBBDN@BFFDTC@AKm@"],"ARE":[54.5,23.5,"아랍에미리트","g_@cNCA?DOC[@i@g@CFANH?@JCBHB?FDF?FBBz@IFS"],"QAT":[51.1,25.2,"카타르","w^oN@MEIEAED?JBJD?"],"KWT":[47.3,29.4,"쿠웨이트","_]wQCH@BELL@BIPAMS"],"IRQ":[43.3,33.1,"이라크","oWcSFWk@SGW@OICIKICU@GDICKVMDAJJFBLMRWHIN@LE??HKJXCLRd@Av@g@\\M"],"OMN":[57.3,22.1,"오만","oa@eM?GEG?GICBCAKI?GLKDYDOPEB?BHPFDFLHABD@HAJ@BH?JD@HBBJ?FD?FHBJ?JDH?Tm@{@SMg@ eb@aOBGEEA@@F"],"VUT":[166.9,-15.4,"바누아투","ogB|HKJD@DG ggBxHBE?OIDCNDA"],"KHM":[104.5,12.6,"캄보디아","c_AsFDWMOYCQ@OFIMQFCL@V`@LGJR@PFNAFK"],"THA":[101.1,15.5,"태국","w`A}GPAXBLNEVPGP?COP?@TNl@?NM?GPCPIHKBIHDFJ@@INGB@FEBIRUBJ@KAKEQSg@FQ@SLOBIECGQR[HOGCIUMAIGKCGDAJM?DTAPSKEBKACEO@MNARON@P"],"LAO":[102.5,19.4,"라오스","cbA{GPGHLNGEGAQNO@SLONABDJ@DCRJ@QEUL?@KFECGQKABI?@UICKNGPW?GPJDDDWJ]h@MLEL"],"MMR":[95.8,21.6,"미얀마","q}@wKJBHFL@HTFBINSZFPDBCHMNARGPRf@@OEMFKAUFIHq@FOb@VVEEYBQNWCEJCLO@OGB?MIE@GCE?UOBIO?IKO@KYMMB?KEC@GK?EJIB?^RN@VUCCRKBDNWHOC?FPJ"],"VNM":[105.4,21.7,"베트남","e`AqEQGSAFKa@MAWBMCSDMLM\\i@VKEEKEFQV?FQJOICc@AOKIFQB@JGFUBZPNPBLa@n@QJKNGd@@`@NLVJNPVPFKEM"],"PRK":[126.4,39.9,"조선민주주의인민공화국","spAoYCBFALL?LHBJHJBHB?H@@QJ@BT@FHH??@HC@@D@@CHCEGCC@AEK@CJAFCOMUIMMGDQ?@I]GGK"],"KOR":[128.1,36.4,"대한민국","{mAqV?AI?GIUAACQVEJ?VFHPBNFP@@ICOHSOC"],"MNG":[104.2,46,"몽골","{u@y]SCe@O]IQDS?MHS?]DQMFKUSUFi@DCN[Fk@ES@SHKHk@Bk@G]MK@IDWAVb@CFKCSBOGOFQL@DNA\\@LDLL\\FRH^EJJINLDLHVF\\?^FTHHEV?\\KRCXBf@CV?HKHQJCVKr@EDGGWLOZGPI"],"IND":[79.4,22.7,"인도","y{@uPAFDB?JLCXLAJJN?HHNNC?TBDAFHDJ_@B?BJHIEKG?IQJAd@C@MF?NGFJMJJDBFKDBJGLAN@FL?VB?NHHZLVV`@X?FZJH@DNEh@FP?`@J@FNEDPDFJFDPQPo@N[He@P[L_A?WBSZJLAXWGGDETQKMk@?BOHI@OLGUUW@SUMSQS?MQKNIN]IG_@BUCQOUV@NGH?HLACTo@XJHFP_AZ[BKHe@DQ?AGBKAIKCARQFMC_@@AMFEOAQMWMODMIILFF"],"BGD":[89.7,24.2,"방글라데시","}x@wL?LFCANDIDSFKP?AFDJHC@@LC@OFMCKJECGKELKGKOFG?ALe@BK@HPF?DJIHCKC?"],"BTN":[90,27.5,"부탄","ix@kPGD@L^ALBPG?CMMIEMBK@"],"NPL":[83.6,28.3,"네팔","av@mP@HCJ@FP?d@EJIZC~@[GQSMODSJKBEHOBOFWB"],"PAK":[68.5,29.3,"파키스탄","so@eUPNTB^CHFO\\OHPJ?LPRLRRTVATTMFANIHCNj@?JLNCDOLM`BDGU[K@GFC@QPGPU_@HUCIBEEK@YGAOIKO?AEOAE@GE?KGKKEFKS?EE@GIIDQIGm@EUEMFEN"],"AFG":[66.5,34.2,"아프가니스탄","qh@kVK?SFOEE@EGK?EIGGIB@DE@@NGFOEMIa@@CDTDl@DHFEPHHAFDDR?GJJDFJ?JFDDAN@@DN?HJ@NXFJADDHCTB^IQQ@MNA?MFOIIHCMg@SFOACIOAIECOQCAGID"],"TJK":[72.6,38.2,"타지키스탄","ki@eVKUBMNCEIO@IKEK[EBHADG?FDRC@JSAYDe@ACPGAKB@FCJ`@ALHNDFGAODAAEHCFFDHJ?DFDAND"],"KGZ":[74.5,41.7,"키르기스스탄","kk@mYCGKAa@DAKKC[FGA}@@IFMBBB^HDFX@FLRCLBRHCBDDd@@XER@AKSBGEO@YOVILDNGQM"],"TKM":[58.7,39.9,"투르크메니스탄","y_@cYGEWCMDML_@?BIQGOK[JANGBSAGBIRc@VSHYF?JNE@FPBBNHDN@BHN@RG@OL?VQNATILAFBLALJPBBMCUNEEML?CQSDOGLKDINB@N"],"IRN":[54.9,32.2,"이란","k]uQJK?ID?AMHOVILSCMKG@KLEVg@CEDUMECFIFKBGAWMGAEDFHKHE?ELQBMH]B]EACQCMKM@GCM@UHO@WPM?ANLf@IBHHGN?LO@ALPPQTQFAPGBAFZJFTpAKFYHAN@RHVEROREZk@H@LE"],"SYR":[38.3,35,"시리아","iUmSGUIGBGF?@OCGKI?IGBUEIBO?WG_@AHJHBANFVrAh@"],"ARM":[44.8,40.5,"아르메니아","a\\gWF@FOF?DCB?FELEAGBG[ACBGBBBIFDDQF"],"SWE":[19,65.9,"스웨덴","{Eyc@IIOMEWJI@YMSS@EGDG][a@c@Q?EKe@BAMK?y@VA\\EF`@DRLCJfA`@LZMLSHPTTDF`@HPVAJNV?DQNU"],"BLR":[28.4,53.8,"벨라루스","sPcb@SDCBIASBAHBDKJGB@BMBEBFDNAB@IRP@DB?HFAP?DCFBFCx@EL?JDH??GDIKC?GDG?GS?SGEIOG@GKC"],"UKR":[32.1,49.7,"우크라이나","{Rq_@G?CC[?KHDBADO@GF?BWFOCKHK?]D?DFHCJBDP@HD@FN@JDR@ND?JDERCDB`@E?GR@DJNLHCFBHCEAGM?ACAA@O?BAACDCBGDC?EFEFANEXDDBRDHEXAFB@EHCIMC@DIQOIAAEHQI?KEM?y@DGBGCEBQ?G@?IEC"],"POL":[19.5,52,"폴란드","uMu`@?FEF?FJBEH?FIP@DH@PNEHVILBHAJBHGFBHKN??GLABDHC?ELAHEFKAGDIDGECDKMEw@OSBADoA@I@"],"AUT":[14.1,47.5,"오스트리아","sIa]@FJ?CBHNP?HDj@GBERBB@\\EAC?CEAIDAEQ@MCI?EBAA@MEAGIMDKGG?MDIAIB@@"],"HUN":[19.4,47.1,"헝가리","yLg]IBADJBTZNBJATFPCRIBEBAEKBCK?AGQDOAAC[CEEE?UD"],"MDA":[28.5,47.4,"몰도바","sOc]QEODG@GD?DEBCFEB@BC@B@JA@AB@?@FLD@@G?QVY"],"ROU":[25,45.7,"루마니아","sPm[IBGCIB?DHBDABVJANGTDHB\\?NCF@FKCCBAFBHE@GJC@EJGOCU[SGY@IDSEECG?E@WX?P"],"LTU":[24.1,55.1,"리투아니아","qOwa@AFNFDHRFR?DEHA?EAE\\EBOUEa@?SAABI@"],"LVA":[25.5,57.1,"라트비아","aP}b@IDAFEJ`@JRIHA@CR@`@?TD?OIKQGONO?COQCYH"],"EST":[25.9,58.7,"에스토니아","oPed@ABLJEPFDN?XIPBAKD@LE@KYEYASBUA"],"DEU":[9.7,51,"독일","yGs`@EJDBEFEH@FGJF@DABBd@JENUJFHD@AL@@DCH?LBPA@DHED@TEBBN?AMIMZCHE?GBCCMBUK?CEEQBGCCO?CBMIBG@KOBKC?FUB@FUCIEUF"],"BGR":[25.2,42.5,"불가리아","eMsZCFGAOB]?ICUEOFK@JFDLEJPARD?HP@LGNDL?@MHEAC@ACEGEHG@G"],"GRC":[21.7,39.5,"그리스","mOaU@D\\@?CVCCGID_@?@B kMyXM?OEMFQA?IIBDLB@VAVBMJH@J?HIBBCJKHFBSN?HPCEHJ@GPL?NGJ]PS?EGIAEEC?CMAGCI?CC"],"TUR":[34.5,39.3,"터키","_[gVHBFETAHB^@VFN?HCTDFC?HJHDIGGJ@PCLJ\\@NITABFLBRKT?JSLIIOJIUQ]AGMe@@WKWEa@?a@L[FWCQ@WISASHCF@FMDGDLDETBDKN iOcYSEQ@AFQDBBV@VNFGACCAEM"],"ALB":[20.1,40.7,"알바니아","cLoX?BDB@DFHBA?CJG@GCS@C@EGIABEAGFAD@FAF"],"HRV":[16.4,45.8,"크로아티아","kIa\\SHQBEAKLFDFCL?PAH?BBDCBFMNWRQD@B^MPENMCAHG?GJADFDE?GM?CAM@?CGAAG"],"CHE":[7.5,46.7,"스위스","_Eu\\?B@BGBI??FHBLABFH?BCHFH?HCDGH@?GOK@CI@ECO?CC"],"LUX":[6.1,49.7,"룩셈부르크","wBi^CB?FH?AK"],"BEL":[4.8,50.8,"벨기에","{Bw^BLB?@JPIH@VQF?BEOCM?SCKH"],"NLD":[5.6,52.4,"네덜란드","iCm`@CFDPBDJ?CTVMRBL?IEQ][G"],"PRT":[-8.3,39.6,"포르투갈","rDeYMGEHYAEHHD?N@@@HF@GJDJGDHL?DFDHCH@CO@KHABEAMGGCS?GBE"],"ESP":[-3.5,40.1,"스페인","tCeV?EIMFEEKFKGAAIAA?OIEDIX@DILF?MFG[MiADo@?GFc@FGCUHWC?JPLXB@DJJFNGJJFBLLBLLl@?JFFFHADGDI"],"IRL":[-7.8,53.1,"아일랜드","zBu`@CLNPb@JZAOUHSi@WCHBHK?"],"NCL":[165.1,-21.1,"누벨칼레도니","sfBdLYTFBVMLKJMBEI?SL"],"SLB":[159.2,-8,"솔로몬 제도","idBpEEDL?FKKB adB~DBBLQBKE?GN qcBdETABCAGMBEB wbB~CEHNGPMCAGD eaBjCGDB@FCFG?C"],"NZL":[172.8,-39.8,"뉴질랜드","qmB`XPVNF@EFAIODKTGAGMEAO?KFM?CVYHMG?KHMDEPMRAMGDCNODK@KGI@BPDJNADDAH aiBfZ[UIMEECIMIGNOGCF?HRVHFGHN?NDP`@XLP?JETABEIOYSKC"],"AUS":[134,-24.1,"오스트레일리아","i{AnXK@AVFD@NDELLPAJO@MJO?IM@SDIA ymAbSRHPDBHDF\\@PCZBJHD?RJZA^O?KIACCAU@KHSBK?IFM?EFGBOHOBGIFFQIDEF?IN[AKCCAI@KGMALGMQEGGOGIAC@OEKACEE?I?UEIIEIIIAQMQGPICFIEIIBAMIIEGIC?EG@?CSEMHKJW@BKIOGC@EGKKEI@QC?INEKCKDKFOBEAKDKCG?CAIHDHFFD?AFLRADOJODWPE?IDCDQDMEGSG[BYCOAC@EG[GEEHAJC@AFEHARELMEON@FCPAHE@EP@HELUHYP@BKLGRGCGHCCCTg@b@CN?VIN@PFZ?HBLFRNFLXDPFHBL@RJFT?PFTNZKAIHBPLz@OJKFYHGRAEIBMHLPBKKAKGI@MNPJDFNNG?KJMHGCCXKL?RIb@@n@L"],"LKA":[80.7,7.6,"스리랑카","cr@uCBRFDPBFOB[G_@MHIL"],"CHN":[106.3,32.5,"중화인민공화국","mcAkJNE@QIGUEK?CFFFDJ eq@mY@KMEPa@e@GKCMc@g@DIIASO?OMGACLQH[FMNFVEFs@DWJKBIPIJW?g@BYCSB]JW?IDUI_@G]?WGMIMEHOKK_@DSI]GMMME]AO@AEPMNGNFRCJBBGWc@WF[K?IQSIG?IHEOIWA[A]DOF[h@GPa@FWLGP]?QG_@EHPFFDTLRVCPDEPBVH??HJKFJ\\FAHP?FELLTHNLZDNFRDIIBGOKJINDVLJJR@HHKJOB?HOBUMQFM?AJZBHJPHHLSHGRY`@?NJBCJKDF^J@\\n@PVv@`@T@JHFEJFZHRBFTH?DMEGZEF@TCFGAKPCHGNJb@@RFATH?@KNBVIEOJCBSTBAWSO?_@HCDKJ?TAGGHMLHNEVLPLN@FCJALCHDLL@OJBl@ENGNCDIJCRKNEFBn@YBUM@?IFIAOTW^GDOLGBEBKAGJCF@BQEEBCSIMCSBGMYAEG_@I"],"TWN":[120.9,23.7,"중화민국","ckAgNTn@HO@OKQOOID"],"ITA":[11.1,44.7,"이탈리아","oEi\\K@CASCCD[D@HCFNANDAH@DEHQHINUNO?EDDB_@JQHABBFJINAHJOF@HH@HNF@CQCCLSFCDGJCHGLA`@ULIDSXIHBHFH@AGHCDMGEDG?EIBI?IGCBI?CGM@IC gHyVMADNADBHNGd@KCIU@ mDqXIEKL@XH?FDFE?WBK"],"DNK":[9,56,"덴마크","eEka@JBNCFI?SGKQAGCOE@HBDADI@BFDANL wFab@EHJNTK@G"],"GBR":[-2.1,54.4,"영국","zBu`@NCJ?CIBIQASJ |@k`@CKLKVCDEGGDEJH?SHIESOOO?W?TRi@ABNPPS@SXM@Q^WB@JHDEHNHZ?`@DHCJHPALDJC]SQC^CDGUEJICM"],"ISL":[-18.7,64.8,"아이슬란드","`Hqh@BLULXLjAPpAISGj@Ic@C?Eh@CKM_@A]L]KYD_@I"],"AZE":[47.2,40.4,"아제르바이잔","_\\eYE@MJG?CCKGSVI@EBN@FVDB?HD?JIGIDEF@VL?MPGEEHGCCFCBCCCODI?AAHI y[eWJCHGBGC?EBG??B"],"GEO":[43.7,41.9,"조지아","_XcZACm@F[HA@KASBEFKBDBIH@@H?NEBBZ@RIR@AIBKJGJA"],"PHL":[122.5,11.2,"필리핀","ojA}FHOQ@EDBP skAgECEAKK?BJOQ@PFDDLDDJM _nAgDAVDPFSFHENDFVKDMEIJGDFHALJBEGOWMEHOECIM?@OOHAH aiAyDXPIMYYISCNLJ mkAkJ@FELBNJFBNCNK@GAYH@JEB@HNIFKBFLKPBHEAGECDE@FHKBG?SGFA_@EQK?KDEE gkAcF@IKDK??FHHJD?I mmAsFEVNEEPHD?MDABKK@?GJOQ@"],"MYS":[113.8,2.5,"말레이시아","q}@aCCAOFAHKAEGE@KJGJ?L@HCPGDEP?DL@h@_@@IJK@QFIAM uhAqAPCT?FTFFHZNBPEH@JHJALBLI@MMDOCCO_@GW[IHCEG?CUMMIOG?IHAF]J@FL?CH"],"BRN":[114.6,4.4,"브루나이","egAkBBTF?BDHIGG"],"SVN":[14.9,46.1,"슬로베니아","sGa\\O@IEQ?CCC@CDND@FF@?BLAB@L?CABG"],"FIN":[27.3,63.3,"핀란드","{Pej@BL_@LPNUTLPQLFJ]LFHz@d@b@@bAJJKRECSFQGKQK{@Y@GZIDG@]x@WKEWJYASDSIIM]GYF"],"SVK":[19,48.7,"슬로바키아","cMu]HLB@TED?DDZB@BN@FAHC@GCEOACAAEGCE@GCIFKCI@MC"],"CZE":[15.4,49.9,"체코","kH}^IDM@?DIBCEM@?FO?IHD?FB@DB@N@@BHCH@LEF?JFb@QDOe@KCCE@"],"ERI":[38.3,15.8,"에리트레아","wU_H@GKk@EEMAIKKVEPe@Z[\\IDDBF?\\_@PGL?BCJBJIDN"],"JPN":[138.4,36.1,"일본","uwAoWPR?TFNCHHLXFb@@ZTLE?Ob@BTHV?SNL^JHHGCQJEFMSEIKSIMMg@EUBSc@MHg@[MWBWGKUCIZ kyAoZMGCTZDPR^MHTT?BSIMUAE[EOUTOD wqA}SIKKBGIMDCDJJFEHBDJJE"],"PRY":[-60.1,-21.7,"파라과이","jc@rKEH?ZSBGCMDCDCXG?ECGB?JHf@PNN@h@GS]BGRGVONAd@a@GU?KIQc@EQ@QH"],"YEM":[45.9,15.3,"예멘","o_@{JUl@LDBNr@PPLN?HFLBT@BDD?@DH?D@L?DKAKFSDGCA@GAC?GGG@GEIGD[AWBEAEFICMUQG"],"SAU":[44.7,23.8,"사우디아라비아","{TkQUBGECGOACEECRSg@ICCWD]Lw@f@w@BCHMAGPIBCFMF?F@FADEDEHEBE?K^{@HCCILLf@z@Rx@FPFLTHBDGD@VCZ@FEDHAFFFBIDE?GHEJQDOLMFALS?YJUHGHCDK?CDIDCFOT]H?CQ"],"CYN":[33.7,35.2,"북키프로스","mS}TCEO?QELHA@H@@CB?D@"],"CYP":[33.1,34.9,"키프로스","mS}TMAABIA?@RFHABG"],"MAR":[-7.2,31.7,"모로코","j@_UGLAJEREBBFXBHFH@@LVFDHd@F^N?T@??JJ?DBPAN@DND@HVZTDZFFBFj@@?IGEEI?EEMKMEAEK?IGMKEMSIGQAOMIEOOBYI[KKc@QSa@M?KHSASB"],"EGY":[29.4,26.2,"이집트","aVwLlF??oCDOEMBGGIY?o@LWKQAMBEHCGODO?ICK`@DFFXDBNOL]@@GT[r@MTQTB@?LWP"],"LBY":[18,26.6,"리비아","sNwL?f@T?@F|CkAb@PHI^IFKNIHBFI?IJMGG?_@CQFYICAI@G[SAMWDGAOBYFIPm@JUHICIIDOEGOIKA[BEFa@DEDFHCFDLEN?dA"],"ETH":[39.1,8,"에티오피아","{\\_Dv@z@X?PLL@BDL?FGPHDFPCJ?VOL?FG?IHCJUFCBGHIJAEKI?CE?QESGEKWKIGSAOWBEOKHKCCBM?QF]^LPAHO?CBBDUZ_AV"],"DJI":[42.5,12,"지부티","oYyFG?ECCD?FJDGBDJBCN?@IEI"],"SOL":[46.7,9.4,"소말릴란드","q]cF?d@T\\P?~@WT[IQGBCFGHq@Gc@KI?"],"UGA":[32.9,2,"우간다","eTP|@@RFBA?MCGAOKSMKFA?WGEMBOCM?KGIJI`@DLNT"],"RWA":[30.1,-1.9,"르완다","_RTGJ?JD@JADJJAAICA?KEEC@"],"BIH":[18.1,44.1,"보스니아 헤르체고비나","sJuYPEVSLOCGEBCCI?Q@M?GBG?DHIF@FNF"],"MKD":[21.6,41.6,"북마케도니아","_MmYIDALFBH?FBL@FE@GAGA@AEUC"],"SRB":[20.8,44.2,"세르비아","wJu[OEK@KFADKBAFIDGCC@BBCBDBAFIFFDBDA@@BN@CIRKB@@DB@?ATKEAAGHGEIF?GEDE"],"MNE":[19.1,42.8,"몬테네그로","qKsYD@@CFHADBADEFCCMIEUJ?@"],"KOS":[20.9,42.6,"코소보","{KeY@EFGGEAECASJBHN@@D"],"TTO":[-60.9,11,"트리니다드 토바고","pe@wEOA?NP@@ACE"],"SDS":[30.4,7.2,"남수단","gReANMDGHBHADBFANWLEDKTS?EVOKEEQEIMAMNE@EAM?CBS??CICAEGCOJKASY@KBEK??CI?@NALIFANC??NBDH?DJK@IHCFGBKTd@`@L?NBLC"]};

  /* ───────── 나라 자료: id;이름;수도;대륙;난이도 등급;수도 위도,경도;국기;인사말;음식;명소;특징 ───────── */
  const RAW = `KOR;대한민국;서울;AS;1;37.57,126.98;f:fff|Y;안녕하세요 (한국어);김치·비빔밥;경복궁;한글을 쓰는 나라, K-팝으로 유명
PRK;북한;평양;AS;2;39.03,125.75;H:6,1,16,1,6:024fa2,fff,ed1c27,fff,024fa2|C:fff:.33:.5:.17|S:ed1c27:.33:.5:.16;안녕하십니까 (조선말);평양냉면;주체사상탑;세계에서 가장 폐쇄적인 나라로 꼽힘
JPN;일본;도쿄;AS;1;35.68,139.69;f:fff|C:bc002d:.5:.5:.3;곤니치와 (일본어);스시·라멘;후지산;벚꽃과 신칸센의 섬나라
CHN;중국;베이징;AS;1;39.9,116.4;f:de2910|S:ffde00:.17:.25:.15|S:ffde00:.33:.1:.05|S:ffde00:.4:.2:.05|S:ffde00:.4:.35:.05|S:ffde00:.33:.45:.05;니하오 (중국어);베이징 덕·마파두부;만리장성;인구가 아주 많고 판다가 사는 나라
MNG;몽골;울란바토르;AS;2;47.92,106.92;v:c4272f,015197,c4272f|R:f9cf02:.12:.3:.09:.45;센 배노 (몽골어);허르헉 (돌구이 양고기);칭기즈칸 기마상;유목민의 이동식 집 '게르'
VNM;베트남;하노이;AS;1;21.03,105.85;f:da251d|S:ff0:.5:.5:.3;신 짜오 (베트남어);쌀국수(퍼)·반미;하롱베이;오토바이가 아주 많은 S자 모양 나라
LAO;라오스;비엔티안;AS;3;17.97,102.6;H:1,2,1:ce1126,002868,ce1126|C:fff:.5:.5:.2;사바이디 (라오어);랍 (다진 고기 무침);루앙프라방;동남아시아의 유일한 내륙국
KHM;캄보디아;프놈펜;AS;2;11.56,104.92;H:1,2,1:032ea1,e00025,032ea1|P:fff:.32,.66,.36,.4,.42,.46,.46,.32,.5,.24,.54,.32,.58,.46,.64,.4,.68,.66;쭘 리업 쑤어 (크메르어);아목 (생선 커리찜);앙코르와트;국기에 사원이 그려진 나라
THA;태국;방콕;AS;1;13.75,100.5;H:1,1,2,1,1:a51931,f4f5f8,2d2a4a,f4f5f8,a51931;사와디캅 (태국어);팟타이·똠얌꿍;왓 아룬 (새벽 사원);한 번도 식민지가 된 적 없는 동남아 왕국
MMR;미얀마;네피도;AS;2;19.75,96.1;h:fecb00,34b233,ea2839|S:fff:.5:.55:.35;밍글라바 (미얀마어);모힝가 (생선 국수);쉐다곤 파고다;수도를 양곤에서 네피도로 옮긴 나라
MYS;말레이시아;쿠알라룸푸르;AS;1;3.14,101.69;h:c00,fff,c00,fff,c00,fff,c00,fff,c00,fff,c00,fff,c00,fff|R:010066:0:0:.5:.57|M:fc0:010066:.17:.28:.17|S:fc0:.33:.28:.1;슬라맛 다탕 (말레이어);나시르막;페트로나스 트윈 타워;반도와 보르네오섬 두 부분으로 나뉜 나라
IDN;인도네시아;자카르타;AS;1;-6.2,106.85;h:ce1126,fff;슬라맛 파기 (인도네시아어);나시고렝·사테;보로부두르;섬이 1만 7천 개가 넘는 나라
PHL;필리핀;마닐라;AS;1;14.6,120.98;h:0038a8,ce1126|T:fff:.43|S:fcd116:.15:.5:.1;마간당 우마가 (필리핀어);아도보;초콜릿 힐;7천 개가 넘는 섬, 농구를 사랑하는 나라
BRN;브루나이;반다르스리브가완;AS;3;4.89,114.94;f:f7e017|P:fff:0,.2,1,.62,1,.8,0,.38|P:000:0,.38,1,.8,1,.93,0,.51|C:cf1126:.5:.5:.16;슬라맛 파기 (말레이어);암부얏 (사고 녹말 요리);오마르 알리 사이푸딘 모스크;보르네오섬의 작은 석유 왕국
TLS;동티모르;딜리;AS;3;-8.56,125.57;f:dc241f|T:ffc726:.5|T:000:.33|S:fff:.11:.5:.1;본디아 (테툼어);생선과 옥수수 요리;크리스투 레이 동상;21세기에 처음 독립한 나라
SGP;싱가포르;싱가포르;AS;1;1.29,103.85;h:ef3340,fff|M:fff:ef3340:.17:.25:.15|S:fff:.3:.25:.05;헬로 / 슬라맛 파기 (영어·말레이어);칠리 크랩·치킨라이스;마리나 베이 샌즈;도시 하나가 곧 나라인 도시국가
IND;인도;뉴델리;AS;1;28.61,77.21;h:f93,fff,128807|C:008:.5:.5:.13|C:fff:.5:.5:.11|C:008:.5:.5:.03;나마스테 (힌디어);커리·탄두리 치킨;타지마할;요가와 발리우드 영화의 나라
PAK;파키스탄;이슬라마바드;AS;2;33.69,73.06;f:01411c|R:fff:0:0:.25:1|M:fff:01411c:.62:.5:.27|S:fff:.74:.37:.08;아살람 알라이쿰 (우르두어);비리야니;바드샤히 모스크;세계 두 번째 높은 산 K2가 있는 나라
BGD;방글라데시;다카;AS;2;23.81,90.41;f:006a4e|C:f42a41:.45:.5:.3;노모슈카르 (벵골어);힐사 생선 커리;순다르반스 맹그로브 숲;인구 밀도가 매우 높은 강의 나라
NPL;네팔;카트만두;AS;2;27.72,85.32;x|P:003893:0,0,.92,.5,.42,.5,.95,1,0,1|P:dc143c:.04,.07,.8,.46,.32,.46,.84,.96,.04,.96|C:fff:.22:.37:.07|C:fff:.22:.76:.09;나마스테 (네팔어);달밧 (콩 수프와 밥);에베레스트산;세계에서 유일하게 네모가 아닌 국기
BTN;부탄;팀푸;AS;3;27.47,89.64;f:ff4e12|P:ffd520:0,0,1,0,0,1|C:fff:.5:.5:.16;쿠주장포 (종카어);에마 다치 (고추 치즈 조림);탁상 사원 (호랑이 둥지);국민총행복(GNH)을 중시하는 나라
LKA;스리랑카;스리자야와르데네푸라코테;AS;2;6.9,79.9;f:ffb700|R:005641:.04:.08:.12:.84|R:ff5b00:.17:.08:.12:.84|R:8d153a:.33:.08:.63:.84;아유보완 (싱할라어);코투 로티;시기리야 바위 요새;홍차(실론티)로 유명한 섬나라
AFG;아프가니스탄;카불;AS;3;34.53,69.17;v:000,be0000,007a36|C:fff:.5:.5:.15;살람 (다리어);카불리 팔라우 (볶음밥);반디아미르 호수;힌두쿠시 산맥이 지나는 내륙국
IRN;이란;테헤란;AS;2;35.69,51.39;h:239f40,fff,da0000|C:da0000:.5:.5:.1;살럼 (페르시아어);케밥 쿠비데·사프란 밥;페르세폴리스;옛 이름은 페르시아
IRQ;이라크;바그다드;AS;2;33.31,44.36;h:ce1126,fff,000|R:007a3d:.33:.43:.34:.14;마르하바 (아랍어);마스구프 (잉어 구이);바빌론 유적;티그리스강과 유프라테스강 사이 메소포타미아
SYR;시리아;다마스쿠스;AS;3;33.51,36.29;h:007a3d,fff,000|S:ce1126:.3:.5:.1|S:ce1126:.5:.5:.1|S:ce1126:.7:.5:.1;마르하바 (아랍어);키베 (고기 완자 튀김);팔미라 유적;수도가 세계에서 가장 오래된 도시 중 하나
LBN;레바논;베이루트;AS;2;33.89,35.5;H:1,2,1:ed1c24,fff,ed1c24|P:00a651:.5,.3,.62,.66,.38,.66;마르하바 (아랍어);타불레·후무스;바알베크 유적;국기에 삼나무가 있는 나라
ISR;이스라엘;예루살렘;AS;2;31.77,35.21;H:1,1,5,1,1:fff,0038b8,fff,0038b8,fff|P:0038b8:.5,.32,.59,.58,.41,.58|P:0038b8:.5,.68,.59,.42,.41,.42|P:fff:.5,.38,.55,.55,.45,.55|P:fff:.5,.62,.55,.45,.45,.45;샬롬 (히브리어);팔라펠;통곡의 벽;몸이 둥둥 뜨는 사해가 있는 나라
JOR;요르단;암만;AS;2;31.95,35.93;h:000,fff,007a3d|T:ce1126:.5|S:fff:.17:.5:.07;마르하바 (아랍어);만사프 (양고기 요구르트 밥);페트라;붉은 바위를 깎아 만든 고대 도시가 있는 나라
SAU;사우디아라비아;리야드;AS;1;24.71,46.68;f:006c35|R:fff:.25:.34:.5:.1|R:fff:.3:.62:.4:.04;아살라무 알라이쿰 (아랍어);캅사 (향신료 밥);메카의 카바;사막 위 석유 대국
YEM;예멘;사나;AS;3;15.37,44.19;h:ce1126,fff,000;마르하바 (아랍어);살타 (돌냄비 스튜);시밤 (흙벽돌 고층 도시);모카 커피의 고향
OMN;오만;무스카트;AS;3;23.59,58.41;h:fff,db161b,008000|R:db161b:0:0:.27:1;마르하바 (아랍어);슈와 (땅속에서 익힌 양고기);술탄 카부스 그랜드 모스크;아라비아반도 동쪽 끝 왕국
ARE;아랍에미리트;아부다비;AS;1;24.45,54.38;h:00732f,fff,000|R:f00:0:0:.25:1;마르하바 (아랍어);마크부스 (향신료 밥);부르즈 할리파;일곱 토후국이 모인 나라
QAT;카타르;도하;AS;2;25.29,51.53;f:8a1538|P:fff:0,0,.3,0,.36,.055,.3,.11,.36,.166,.3,.222,.36,.277,.3,.333,.36,.388,.3,.444,.36,.5,.3,.555,.36,.611,.3,.666,.36,.722,.3,.777,.36,.833,.3,.888,.36,.944,.3,1,0,1;마르하바 (아랍어);마흐부스 (향신료 밥);이슬람 미술관;2022 월드컵 개최국
KWT;쿠웨이트;쿠웨이트시티;AS;3;29.38,47.99;h:007a3d,fff,ce1126|P:000:0,0,.25,.33,.25,.67,0,1;마르하바 (아랍어);마크부스 (향신료 밥);쿠웨이트 타워;작지만 석유 매장량이 큰 나라
BHR;바레인;마나마;AS;3;26.23,50.59;f:ce1126|P:fff:0,0,.25,0,.33,.1,.25,.2,.33,.3,.25,.4,.33,.5,.25,.6,.33,.7,.25,.8,.33,.9,.25,1,0,1;마르하바 (아랍어);마크부스 (향신료 밥);사막의 생명의 나무;페르시아만의 섬나라, F1 그랑프리 개최
TUR;튀르키예;앙카라;AS;1;39.93,32.86;f:e30a17|M:fff:e30a17:.33:.5:.25|S:fff:.54:.5:.1;메르하바 (튀르키예어);케밥·바클라바;카파도키아;유럽과 아시아에 걸친 나라
ARM;아르메니아;예레반;AS;3;40.18,44.51;h:d90012,0033a0,f2a800;바레브 (아르메니아어);호로바츠 (꼬치구이);게하르트 수도원;처음으로 기독교를 국교로 삼은 나라
AZE;아제르바이잔;바쿠;AS;3;40.41,49.87;h:00b5e2,ef3340,509e2f|M:fff:ef3340:.46:.5:.14|S:fff:.57:.5:.06;살람 (아제르바이잔어);플로브 (볶음밥);불꽃 타워;'불의 나라'라 불리는 카스피해 연안국
GEO;조지아;트빌리시;AS;3;41.72,44.79;f:fff|+:f00:.2|R:f00:.17:.12:.06:.16|R:f00:.14:.17:.12:.06|R:f00:.77:.12:.06:.16|R:f00:.74:.17:.12:.06|R:f00:.17:.72:.06:.16|R:f00:.14:.77:.12:.06|R:f00:.77:.72:.06:.16|R:f00:.74:.77:.12:.06;가마르조바 (조지아어);하차푸리 (치즈 빵);게르게티 삼위일체 교회;와인을 처음 빚은 곳으로 꼽히는 나라
KAZ;카자흐스탄;아스타나;AS;2;51.17,71.43;f:00afca|C:fec50c:.5:.45:.18|R:fec50c:.05:.1:.05:.8;살레메트시즈 베 (카자흐어);베시바르막 (고기 국수);바이코누르 우주기지;세계에서 가장 넓은 내륙국
UZB;우즈베키스탄;타슈켄트;AS;2;41.3,69.24;H:10,1,10,1,10:0099b5,ce1126,fff,ce1126,1eb53a|M:fff:0099b5:.12:.16:.1;아살로무 알라이쿰 (우즈베크어);플로프 (볶음밥);사마르칸트 레기스탄;실크로드 오아시스 도시들
TKM;투르크메니스탄;아시가바트;AS;3;37.95,58.38;f:00843d|R:d22630:.12:0:.16:1|M:fff:00843d:.4:.22:.1;살람 (투르크멘어);플로프·쇼를로 (볶음밥);다르바자 가스 분화구 ('지옥의 문');흰 대리석 건물이 가득한 사막 수도
KGZ;키르기스스탄;비슈케크;AS;3;42.87,74.59;f:e8112d|C:ffef00:.5:.5:.24|C:e8112d:.5:.5:.13;살라맛스즈브 (키르기스어);베시바르막 (고기 국수);이식쿨 호수;국토 대부분이 산인 나라
TJK;타지키스탄;두샨베;AS;3;38.56,68.79;H:2,3,2:cc0000,fff,006600|C:f8c300:.5:.5:.1;살롬 (타지크어);오시 (볶음밥);파미르 고원;'세계의 지붕' 파미르가 있는 나라
MDV;몰디브;말레;AS;2;4.18,73.51;f:d21034|R:007e3a:.25:.25:.5:.5|M:fff:007e3a:.5:.5:.15;아살람 알라이쿰 (디베히어);가루디야 (참치 수프);바다 위 수상 빌라;해발 고도가 가장 낮은 나라
CYP;키프로스;니코시아;AS;3;35.17,33.36;f:fff|P:d57800:.25,.4,.45,.28,.75,.3,.68,.48,.5,.55,.32,.52|R:4e5b31:.42:.66:.16:.04;야수 (그리스어);할루미 치즈;아프로디테의 바위;지중해 동쪽의 섬나라, EU 회원국
RUS;러시아;모스크바;EU;1;55.76,37.62;h:fff,0039a6,d52b1e;즈드라스트부이쩨 (러시아어);보르시·블리니;붉은 광장;세계에서 가장 넓은 나라
NOR;노르웨이;오슬로;EU;1;59.91,10.75;f:ba0c2f|N:fff:.25|N:00205b:.125;헤이 (노르웨이어);연어·브루노스트 (갈색 치즈);피오르;오로라와 피오르의 나라
SWE;스웨덴;스톡홀름;EU;1;59.33,18.07;f:006aa7|N:fecc00:.2;헤이 (스웨덴어);미트볼 (셰트불라르);바사 박물관;노벨상 시상식이 열리는 나라
FIN;핀란드;헬싱키;EU;1;60.17,24.94;f:fff|N:002f6c:.27;모이 (핀란드어);연어 수프·카렐리아 파이;산타클로스 마을 (로바니에미);사우나와 호수가 아주 많은 나라
DNK;덴마크;코펜하겐;EU;1;55.68,12.57;f:c8102e|N:fff:.2;하이 (덴마크어);스뫼레브뢰 (오픈 샌드위치);인어공주 동상;레고가 태어난 나라
ISL;아이슬란드;레이캬비크;EU;2;64.15,-21.94;f:02529c|N:fff:.25|N:dc1e35:.12;할로 (아이슬란드어);하칼 (삭힌 상어);블루 라군;화산과 빙하의 섬
GBR;영국;런던;EU;1;51.51,-0.13;U;헬로 (영어);피시 앤드 칩스;빅벤;잉글랜드·스코틀랜드·웨일스·북아일랜드가 모인 나라
IRL;아일랜드;더블린;EU;2;53.35,-6.26;v:169b62,fff,ff883e;디아 기트 (아일랜드어);아이리시 스튜;모허 절벽;'에메랄드 섬', 성 패트릭의 날
FRA;프랑스;파리;EU;1;48.86,2.35;v:002395,fff,ed2939;봉주르 (프랑스어);바게트·크루아상;에펠탑;와인과 치즈, 패션의 나라
ESP;스페인;마드리드;EU;1;40.42,-3.7;H:1,2,1:aa151b,f1bf00,aa151b|R:aa151b:.25:.36:.09:.28;올라 (스페인어);파에야;사그라다 파밀리아;플라멩코와 낮잠(시에스타)
PRT;포르투갈;리스본;EU;1;38.72,-9.14;V:2,3:060,f00|C:ff0:.4:.5:.2|C:f00:.4:.5:.12;올라 (포르투갈어);에그타르트 (파스텔 드 나타);벨렝 탑;대항해 시대를 연 나라
ITA;이탈리아;로마;EU;1;41.9,12.5;v:009246,fff,ce2b37;차오 (이탈리아어);피자·파스타;콜로세움;장화 모양 반도의 나라
DEU;독일;베를린;EU;1;52.52,13.4;h:000,d00,ffce00;구텐 탁 (독일어);소시지·프레첼;브란덴부르크 문;맥주 축제 옥토버페스트
NLD;네덜란드;암스테르담;EU;1;52.37,4.9;h:ae1c28,fff,21468b;할로 (네덜란드어);하링 (절인 청어)·스트룹와플;잔세스칸스 풍차 마을;튤립과 자전거, 국토의 1/4이 바다보다 낮음
BEL;벨기에;브뤼셀;EU;2;50.85,4.35;v:000,fdda24,ef3340;봉주르 / 할로 (프랑스어·네덜란드어);와플·감자튀김;그랑플라스 광장;초콜릿과 오줌싸개 동상
LUX;룩셈부르크;룩셈부르크;EU;3;49.61,6.13;h:ed2939,fff,00a1de;모이엔 (룩셈부르크어);주드 마트 가르데보우넨 (훈제 돼지목살과 콩);보크 포대;1인당 소득이 아주 높은 작은 대공국
CHE;스위스;베른;EU;1;46.95,7.45;f:d52b1e|R:fff:.42:.2:.16:.6|R:fff:.3:.4:.4:.2;그뤼에치 (스위스 독일어);퐁뒤·라클레트;마터호른;시계와 알프스, 영세 중립국
AUT;오스트리아;빈;EU;1;48.21,16.37;h:ed2939,fff,ed2939;그뤼스 고트 (독일어);비너 슈니첼;쇤브룬 궁전;모차르트의 나라, 음악의 도시
POL;폴란드;바르샤바;EU;2;52.23,21.01;h:fff,dc143c;지엔 도브리 (폴란드어);피에로기 (만두);바벨 성 (크라쿠프);쇼팽과 퀴리 부인의 고향
CZE;체코;프라하;EU;2;50.08,14.44;h:fff,d7141a|T:11457e:.5;도브리 덴 (체코어);스비치코바 (소고기 크림 소스);카를교;맥주를 아주 많이 마시는 나라
SVK;슬로바키아;브라티슬라바;EU;3;48.15,17.11;h:fff,0b4ea2,ee1c25|R:fff:.18:.22:.24:.5|R:ee1c25:.2:.24:.2:.44|R:fff:.29:.3:.02:.3|R:fff:.25:.36:.1:.03;도브리 덴 (슬로바키아어);브린조베 할루슈키 (양젖 치즈 뇨키);스피시 성;성(城)이 아주 많은 나라
HUN;헝가리;부다페스트;EU;2;47.5,19.04;h:ce2939,fff,477050;요 너포트 (헝가리어);굴라시;도나우강변 국회의사당;온천이 많은 나라, 루빅 큐브의 고향
SVN;슬로베니아;류블랴나;EU;3;46.06,14.51;h:fff,00f,f00|P:00f:.2,.22,.36,.22,.36,.5,.28,.58,.2,.5|P:fff:.22,.47,.28,.36,.34,.47;즈드라보 (슬로베니아어);포티차 (견과 롤케이크);블레드 호수;국토의 절반 이상이 숲
HRV;크로아티아;자그레브;EU;2;45.81,15.98;h:f00,fff,171796|R:fff:.42:.27:.16:.38|R:f00:.42:.27:.04:.06|R:f00:.5:.27:.04:.06|R:f00:.46:.39:.04:.06|R:f00:.54:.39:.04:.06|R:f00:.42:.51:.04:.06|R:f00:.5:.51:.04:.06;도바르 단 (크로아티아어);페카 (철뚜껑 구이);두브로브니크 성벽;넥타이가 처음 생긴 나라
BIH;보스니아 헤르체고비나;사라예보;EU;3;43.86,18.41;f:002395|P:fecb00:.27,0,.75,0,.75,1|S:fff:.2:.1:.05|S:fff:.3:.27:.05|S:fff:.4:.44:.05|S:fff:.5:.61:.05|S:fff:.6:.78:.05;즈드라보 (보스니아어);체바피 (작은 소시지 구이);모스타르 다리;1984년 동계 올림픽이 열린 나라
SRB;세르비아;베오그라드;EU;3;44.79,20.45;h:c6363c,0c4076,fff|R:c6363c:.24:.25:.13:.48|R:fff:.29:.3:.03:.28;즈드라보 (세르비아어);플레스카비차 (패티 구이);베오그라드 요새;테니스 스타 조코비치의 나라
MNE;몬테네그로;포드고리차;EU;3;42.44,19.26;f:d3ae3b|R:c40308:.04:.06:.92:.88|C:d3ae3b:.5:.5:.2;도바르 단 (몬테네그로어);카차막 (옥수수 죽);코토르 만;'검은 산'이라는 뜻의 나라
MKD;북마케도니아;스코페;EU;3;42.0,21.43;f:d20000|P:ffe600:0,0,.15,0,.5,.45|P:ffe600:1,0,.85,0,.5,.45|P:ffe600:0,1,.15,1,.5,.55|P:ffe600:1,1,.85,1,.5,.55|P:ffe600:0,.42,0,.58,.5,.5|P:ffe600:1,.42,1,.58,.5,.5|P:ffe600:.45,0,.55,0,.5,.5|P:ffe600:.45,1,.55,1,.5,.5|C:d20000:.5:.5:.2|C:ffe600:.5:.5:.16;즈드라보 (마케도니아어);타프체 그라프체 (콩 요리);오흐리드 호수;알렉산드로스 대왕 동상이 서 있는 나라
ALB;알바니아;티라나;EU;3;41.33,19.82;f:e41e20|P:000:.5,.2,.62,.3,.78,.25,.66,.45,.58,.55,.62,.8,.5,.7,.38,.8,.42,.55,.34,.45,.22,.25,.38,.3;퍼르셴데티에 (알바니아어);타베 코시 (요구르트 양고기 구이);베라트 (천 개 창문의 도시);국기에 머리 둘 달린 독수리
GRC;그리스;아테네;EU;1;37.98,23.73;h:0d5eaf,fff,0d5eaf,fff,0d5eaf,fff,0d5eaf,fff,0d5eaf|R:0d5eaf:0:0:.37:.555|R:fff:.148:0:.074:.555|R:fff:0:.222:.37:.111;야수 (그리스어);기로스·무사카;파르테논 신전;올림픽이 처음 열린 나라
BGR;불가리아;소피아;EU;3;42.7,23.32;h:fff,00966e,d62612;즈드라베이 (불가리아어);쇼프스카 샐러드·요구르트;릴라 수도원;고개를 저으면 '네', 끄덕이면 '아니요'
ROU;루마니아;부쿠레슈티;EU;2;44.43,26.1;v:002b7f,fcd116,ce1126;부나 지우아 (루마니아어);사르말레 (양배추말이);브란 성 (드라큘라 성);드라큘라 전설의 트란실바니아
MDA;몰도바;키시너우;EU;3;47.01,28.86;v:0046ae,ffd200,cc092f|R:a0522d:.43:.36:.14:.28;부나 지우아 (루마니아어);마말리가 (옥수수죽);크리코바 지하 와인 저장고;지하 와인 저장고 길이가 수십 km
UKR;우크라이나;키이우;EU;2;50.45,30.52;h:0057b7,ffd700;도브리 덴 (우크라이나어);보르시·바레니키;키이우 페체르스크 대수도원;유럽의 곡창지대, 해바라기 밭
BLR;벨라루스;민스크;EU;3;53.9,27.56;H:2,1:c8313e,4aa657|R:fff:0:0:.1:1|R:c8313e:.03:.1:.04:.8;도브리 지젠 (벨라루스어);드라니키 (감자전);미르 성;국토의 40%가 숲
LTU;리투아니아;빌뉴스;EU;3;54.69,25.28;h:fdb913,006a44,c1272d;라바 디에나 (리투아니아어);체펠리나이 (감자 만두);트라카이 성;발트 3국 중 가장 남쪽
LVA;라트비아;리가;EU;3;56.95,24.11;H:2,1,2:9e3039,fff,9e3039;라브디엔 (라트비아어);회색 완두콩과 베이컨;리가 구시가지;발트 3국의 가운데
EST;에스토니아;탈린;EU;3;59.44,24.75;h:0072ce,000,fff;테레 (에스토니아어);검은 호밀빵 (레입);탈린 구시가지;스카이프가 태어난 디지털 강국
MLT;몰타;발레타;EU;3;35.9,14.51;v:fff,cf142b|R:aaa:.06:.06:.1:.15;본주 (몰타어);파스티치 (치즈 파이);발레타 성벽 도시;지중해 한가운데 작은 섬나라
AND;안도라;안도라라베야;EU;3;42.51,1.52;v:10069f,fedf00,d50032|R:c7b37f:.44:.36:.12:.28;본 디아 (카탈루냐어);에스쿠데야 (고기 스튜);피레네 산맥 스키장;프랑스와 스페인 사이 산악 소국
MCO;모나코;모나코;EU;2;43.73,7.42;h:ce1126,fff;봉주르 (프랑스어);바르바주앙 (튀김 만두);몬테카를로 카지노;F1 시가지 경주, 두 번째로 작은 나라
LIE;리히텐슈타인;파두츠;EU;3;47.14,9.52;h:002b7f,ce1126|R:ffd83d:.15:.13:.12:.14;그뤼에치 (독일어);캐스크뇌플리 (치즈 수제비);파두츠 성;스위스와 오스트리아 사이 내륙국
SMR;산마리노;산마리노;EU;3;43.94,12.45;h:fff,5eb6e4|C:e8c06a:.5:.5:.15;차오 (이탈리아어);토르타 트레 몬티 (와플 케이크);티타노산의 세 탑;현존하는 가장 오래된 공화국
VAT;바티칸;바티칸;EU;2;41.9,12.45;v:ffe000,fff|C:cfcfcf:.75:.5:.15;살베 (라틴어·이탈리아어);로마식 파스타;성 베드로 대성당;세계에서 가장 작은 나라
MAR;모로코;라바트;AF;1;34.02,-6.83;f:c1272d|S:006233:.5:.5:.24;살람 (아랍어);타진·쿠스쿠스;마라케시 제마 엘프나 광장;지브롤터 해협 건너 유럽과 마주한 나라
DZA;알제리;알제;AF;2;36.75,3.06;v:006233,fff|M:d21034:fff:.5:.5:.25|S:d21034:.58:.5:.1;살람 (아랍어);쿠스쿠스;타실리나제르 암각화;아프리카에서 가장 넓은 나라
TUN;튀니지;튀니스;AF;2;36.81,10.18;f:e70013|C:fff:.5:.5:.26|M:e70013:fff:.49:.5:.19|S:e70013:.56:.5:.1;아슬레마 (튀니지 아랍어);브리크 (달걀 튀김 파이);카르타고 유적;아프리카 대륙 가장 북쪽 끝
LBY;리비아;트리폴리;AF;3;32.89,13.19;H:1,2,1:e70013,000,239e46|M:fff:000:.48:.5:.15|S:fff:.58:.5:.05;마르하바 (아랍어);바진 (보릿가루 반죽);렙티스 마그나 유적;국토 대부분이 사하라 사막
EGY;이집트;카이로;AF;1;30.04,31.24;h:ce1126,fff,000|R:c09300:.45:.4:.1:.2;아흘란 (아랍어);코샤리 (쌀·면·콩 요리);기자의 피라미드;나일강 문명의 나라
SDN;수단;하르툼;AF;3;15.5,32.56;h:d21034,fff,000|T:007229:.33;살람 알레쿰 (아랍어);풀 메담스 (콩 요리);메로에 피라미드;피라미드 수가 이집트보다 많은 나라
SDS;남수단;주바;AF;3;4.85,31.58;H:6,1,6,1,6:000,fff,da121a,fff,078930|T:0f47af:.35|S:fcdd09:.12:.5:.1;헬로 (영어);키스라 (수수 전병);수드 습지;2011년 독립한 가장 젊은 나라 중 하나
ETH;에티오피아;아디스아바바;AF;2;9.03,38.74;h:078930,fcdd09,da121a|C:0f47af:.5:.5:.25|S:fcdd09:.5:.5:.15;셀람 (암하라어);인제라 (발효 빵)·도로 와트;랄리벨라 암굴 교회;커피의 고향, 1년이 13달인 달력
ERI;에리트레아;아스마라;AF;3;15.33,38.93;f:4189dd|P:12ad2b:0,0,1,0,1,.5|T:ea0437:1|C:ffc726:.24:.5:.17|C:ea0437:.24:.5:.13;셀람 (티그리냐어);지그니 (매운 스튜)·인제라;아스마라 아르데코 거리;이탈리아식 옛 건물이 남은 수도
DJI;지부티;지부티;AF;3;11.59,43.15;h:6ab2e7,12ad2b|T:fff:.45|S:d7141a:.15:.5:.08;살람 (아랍어);스쿠데카리스 (양고기 밥);아살 호수;홍해 입구의 항구 국가
SOM;소말리아;모가디슈;AF;3;2.05,45.32;f:4189dd|S:fff:.5:.5:.25;이스카 와란 (소말리어);바리스 (향신료 밥);라스 길 동굴 벽화;'아프리카의 뿔' 끝에 있는 나라
KEN;케냐;나이로비;AF;1;-1.29,36.82;H:6,1,6,1,6:000,fff,b00,fff,060|P:b00:.5,.15,.58,.3,.6,.5,.58,.7,.5,.85,.42,.7,.4,.5,.42,.3|R:000:.475:.25:.05:.5;잠보 (스와힐리어);우갈리·냐마 초마;마사이마라 국립보호구;마라톤 강국, 사파리 여행지
UGA;우간다;캄팔라;AF;3;0.35,32.58;h:000,fcdc04,d90000,000,fcdc04,d90000|C:fff:.5:.5:.2|C:888:.5:.5:.1;올리 오탸 (루간다어);마토케 (초록 바나나 찜);머치슨 폭포;나일강의 발원지 빅토리아 호수
RWA;르완다;키갈리;AF;3;-1.95,30.06;H:2,1,1:00a1de,fad201,20603d|C:e5be01:.82:.27:.1;무라호 (키냐르완다어);이소본도 (카사바잎 스튜);화산 국립공원 (마운틴 고릴라);'천 개 언덕의 나라'
BDI;부룬디;기테가;AF;3;-3.43,29.93;f:1eb53a|P:ce1126:0,0,1,0,.5,.5|P:ce1126:0,1,1,1,.5,.5|X:fff:.12|C:fff:.5:.5:.25|S:ce1126:.5:.4:.05|S:ce1126:.44:.56:.05|S:ce1126:.56:.56:.05;아마호로 (키룬디어);브로셰트 (꼬치구이);탕가니카 호수;2019년 수도를 기테가로 옮긴 나라
TZA;탄자니아;도도마;AF;2;-6.16,35.75;f:1eb53a|P:00a3dd:1,0,1,1,0,1|D:fcd116:.32|D:000:.22;잠보 (스와힐리어);필라우 (향신료 밥);킬리만자로산;아프리카 최고봉과 잔지바르섬
MOZ;모잠비크;마푸투;AF;3;-25.97,32.57;H:6,1,6,1,6:009a44,fff,000,fff,fce100|T:d21034:.4|S:fce100:.14:.5:.12;올라 (포르투갈어);피리피리 치킨;모잠비크섬;국기에 소총이 그려진 나라
MWI;말라위;릴롱궤;AF;3;-13.96,33.79;h:000,ce1126,339e35|C:ce1126:.5:.33:.13;모니 (치체와어);은시마 (옥수수죽)·참보 생선;말라위 호수;'아프리카의 따뜻한 심장'
ZMB;잠비아;루사카;AF;3;-15.39,28.32;f:198a00|R:de2010:.6:.4:.13:.6|R:000:.73:.4:.13:.6|R:ef7d00:.86:.4:.14:.6;무와폴레니 (벰바어);은시마 (옥수수죽);빅토리아 폭포;구리 광산 강국
ZWE;짐바브웨;하라레;AF;3;-17.83,31.05;h:319208,ffd200,de2010,000,de2010,ffd200,319208|T:fff:.45|S:de2010:.15:.5:.1;망와나니 (쇼나어);사자 (옥수수죽);그레이트 짐바브웨 유적;돌로 쌓은 옛 도시 유적이 이름이 된 나라
BWA;보츠와나;가보로네;AF;3;-24.65,25.91;H:9,1,4,1,9:75aadb,fff,000,fff,75aadb;두멜라 (츠와나어);세스와 (찢은 고기);오카방고 삼각주;코끼리가 가장 많은 나라
NAM;나미비아;빈트후크;AF;3;-22.56,17.08;f:003580|P:009543:1,0,1,1,0,1|D:fff:.32|D:d21034:.24|C:ffce00:.17:.28:.1;할로 (아프리칸스어);브라이 (바비큐);소수스블레이 붉은 모래언덕;세계에서 가장 오래된 사막, 나미브
ZAF;남아프리카 공화국;프리토리아;AF;1;-25.75,28.19;h:e03c31,001489|P:fff:0,0,.18,0,.55,.38,1,.38,1,.62,.55,.62,.18,1,0,1|P:007749:0,.12,.48,.45,1,.45,1,.55,.48,.55,0,.88|P:ffb81c:0,.2,.4,.5,0,.8|P:000:0,.26,.32,.5,0,.74;사우보나 (줄루어);브라이·보보티;테이블 마운틴;공식 언어가 12개인 '무지개 나라'
LSO;레소토;마세루;AF;3;-29.31,27.48;H:3,4,3:00209f,fff,009543|P:000:.5,.32,.6,.6,.4,.6;루멜라 (소토어);파파 (옥수수죽);말레추냐네 폭포;남아공에 완전히 둘러싸인 산악 왕국
SWZ;에스와티니;음바바네;AF;3;-26.31,31.14;H:3,1,6,1,3:3e5eb9,ffd900,b10c0c,ffd900,3e5eb9|P:fff:.3,.5,.5,.36,.7,.5,.5,.64|P:000:.5,.36,.7,.5,.5,.64;사우보나 (스와티어);옥수수죽과 고기 스튜;믈릴와네 야생동물 보호구;왕이 다스리는 남아프리카의 작은 왕국
MDG;마다가스카르;안타나나리보;AF;2;-18.88,47.51;h:fc3d32,007e3a|R:fff:0:0:.33:1;살라마 (말라가시어);로마자바 (고기 채소 국);바오바브 거리;여우원숭이(리머)의 섬
AGO;앙골라;루안다;AF;3;-8.84,13.23;h:cc092f,000|C:ffcb00:.5:.5:.15|C:cc092f:.5:.5:.11;올라 (포르투갈어);무암바 드 갈리냐 (닭 스튜);칼란둘라 폭포;석유와 다이아몬드 대국
COD;콩고 민주 공화국;킨샤사;AF;2;-4.32,15.31;f:007fff|D:f7d618:.3|D:ce1021:.2|S:f7d618:.15:.22:.13;음보테 (링갈라어);품부 (카사바잎 요리);비룽가 국립공원;아프리카에서 두 번째로 넓은 나라, 콩고강
COG;콩고 공화국;브라자빌;AF;3;-4.26,15.24;f:009543|P:dc241f:1,0,1,1,0,1|D:fbde4a:.3;음보테 (링갈라어);사카사카 (카사바잎 요리);오잘라 국립공원;강 건너 이웃 나라 수도와 마주 보는 수도
GAB;가봉;리브르빌;AF;3;0.39,9.45;h:009e60,fcd116,3a75c4;봉주르 (프랑스어);풀레 니엠브웨 (야자 소스 닭);로페 국립공원;국토의 85%가 열대우림
GNQ;적도 기니;말라보;AF;3;3.75,8.78;h:3e9a00,fff,e32118|T:0073ce:.25;올라 (스페인어);생선과 카사바 요리;비오코섬 화산;아프리카 유일의 스페인어 공용 국가
CMR;카메룬;야운데;AF;2;3.85,11.5;v:007a5e,ce1126,fcd116|S:fcd116:.5:.5:.15;봉주르 (프랑스어);은돌레 (쓴잎 땅콩 스튜);카메룬산;'아프리카의 축소판'이라 불리는 나라
CAF;중앙아프리카 공화국;방기;AF;3;4.39,18.56;h:003082,fff,289728,ffce00|R:d21034:.42:0:.16:1|S:ffce00:.15:.12:.08;발라오 (상고어);고조 (카사바 반죽);장가상가 국립공원;아프리카 대륙 한가운데 내륙국
TCD;차드;은자메나;AF;3;12.13,15.06;v:002664,fecb00,c60c30;봉주르 (프랑스어);불 (수수죽);차드호;루마니아와 국기가 거의 같은 나라
NER;니제르;니아메;AF;3;13.51,2.11;h:e05206,fff,0db02b|C:e05206:.5:.5:.12;산누 (하우사어);킬리시 (말린 고기);아가데즈 대모스크;국토의 80%가 사하라 사막
NGA;나이지리아;아부자;AF;1;9.06,7.49;v:008751,fff,008751;산누 (하우사어);졸로프 라이스;주마 바위;아프리카 인구 1위, '날리우드' 영화
BEN;베냉;포르토노보;AF;3;6.5,2.6;h:fcd116,e8112d|R:008751:0:0:.4:1;봉주르 (프랑스어);파트 (옥수수 반죽);강비에 수상 마을;부두교가 시작된 나라
TGO;토고;로메;AF;3;6.13,1.22;h:006a4e,ffce00,006a4e,ffce00,006a4e|R:d21034:0:0:.4:.6|S:fff:.2:.3:.15;봉주르 (프랑스어);푸푸 (얌 반죽);쿠타마쿠 (흙집 마을);좁고 길쭉한 서아프리카 나라
GHA;가나;아크라;AF;1;5.6,-0.19;h:ce1126,fcd116,006b3f|S:000:.5:.5:.15;아쿠아바 (아칸어);졸로프 라이스·푸푸;케이프코스트 성;카카오(초콜릿 원료) 주요 생산국
CIV;코트디부아르;야무수크로;AF;2;6.82,-5.28;v:f77f00,fff,009e60;봉주르 (프랑스어);아티에케 (카사바 쿠스쿠스);평화의 성모 대성당;세계 1위 카카오 생산국
LBR;라이베리아;몬로비아;AF;3;6.3,-10.8;h:bf0a30,fff,bf0a30,fff,bf0a30,fff,bf0a30,fff,bf0a30,fff,bf0a30|R:002868:0:0:.42:.455|S:fff:.21:.227:.15;헬로 (영어);팜 버터 수프;사포 국립공원;미국의 해방 노예들이 세운 나라
SLE;시에라리온;프리타운;AF;3;8.48,-13.23;h:1eb53a,fff,0072c6;쿠셰 (크리오어);카사바잎 스튜;티와이섬 야생동물 보호구;다이아몬드 산지
GIN;기니;코나크리;AF;3;9.64,-13.58;v:ce1126,fcd116,009460;봉주르 (프랑스어);땅콩 소스 쌀밥;님바산;보크사이트(알루미늄 원료) 매장량 세계 최대
GNB;기니비사우;비사우;AF;3;11.86,-15.6;h:fcd116,009e49|R:ce1126:0:0:.33:1|S:000:.165:.5:.12;올라 (포르투갈어);칼두 데 마페 (땅콩 스튜);비자고스 제도;섬이 88개, 캐슈너트 수출국
SEN;세네갈;다카르;AF;2;14.72,-17.47;v:00853f,fdef42,e31b23|S:00853f:.5:.5:.15;나앙가 데프 (월로프어);티에부디엔 (생선 쌀밥);고레섬;아프리카 대륙 가장 서쪽 끝
GMB;감비아;반줄;AF;3;13.45,-16.58;H:6,1,4,1,6:ce1126,fff,0c1c8c,fff,3a7728;나앙가 데프 (월로프어);도모다 (땅콩 스튜);쿤타 킨테섬;강을 따라 길쭉한, 아프리카 본토에서 가장 작은 나라
MLI;말리;바마코;AF;3;12.64,-8.0;v:14b53a,fcd116,ce1126;이니체 (밤바라어);티가디게나 (땅콩 스튜);젠네 대모스크 (흙 건축);전설의 사막 도시 팀북투
MRT;모리타니;누악쇼트;AF;3;18.07,-15.96;H:1,6,1:d01c1f,00a95c,d01c1f|M:ffd700:00a95c:.5:.55:.22|S:ffd700:.5:.3:.07;살람 (아랍어);티에부디엔 (생선 쌀밥);리샤트 구조 ('사하라의 눈');철광석 열차가 사막을 달리는 나라
BFA;부르키나파소;와가두구;AF;3;12.37,-1.52;h:ef2b2d,009e49|S:fcd116:.5:.5:.15;봉주르 (프랑스어);토 (수수 반죽);티에벨레 색칠한 집;'정직한 사람들의 나라'라는 뜻
MUS;모리셔스;포트루이스;AF;3;-20.16,57.5;h:ea2839,1a206d,ffd500,00a551;봉주르 (모리셔스 크레올어);돌 푸리 (콩 밀전병);르몬 브라방산·7색 흙;멸종한 새 도도의 고향
SYC;세이셸;빅토리아;AF;3;-4.62,55.45;f:003f87|P:fcd856:0,1,.33,0,.67,0|P:d62828:0,1,.67,0,1,0,1,.33|P:fff:0,1,1,.33,1,.67|P:007a3d:0,1,1,.67,1,1;봉주르 (세이셸 크레올어);생선 커리;발레드메 자연보호구 (코코 드 메르 야자);아프리카에서 인구가 가장 적은 나라
CPV;카보베르데;프라이아;AF;3;14.93,-23.51;H:6,1,1,1,3:003893,fff,cf2027,fff,003893|C:f7d116:.37:.62:.2|C:003893:.37:.62:.16;올라 (포르투갈어);카추파 (옥수수콩 스튜);포구 화산;대서양의 섬나라, 모르나 음악
CAN;캐나다;오타와;NA;1;45.42,-75.7;V:1,2,1:d52b1e,fff,d52b1e|P:d52b1e:.5,.18,.56,.33,.65,.28,.61,.53,.69,.5,.56,.68,.52,.68,.52,.84,.48,.84,.48,.68,.44,.68,.31,.5,.39,.53,.35,.28,.44,.33;헬로 / 봉주르 (영어·프랑스어);푸틴·메이플 시럽;나이아가라 폭포;두 번째로 넓은 나라, 단풍잎
USA;미국;워싱턴 D.C.;NA;1;38.9,-77.04;US;헬로 (영어);햄버거·핫도그;자유의 여신상;50개 주가 모인 나라
MEX;멕시코;멕시코시티;NA;1;19.43,-99.13;v:006847,fff,ce1126|C:8c5a2b:.5:.5:.12;올라 (스페인어);타코;치첸이트사;아즈텍과 마야 문명의 땅
GTM;과테말라;과테말라시티;NA;3;14.63,-90.51;v:4997d0,fff,4997d0|C:6c8f3f:.5:.5:.12;올라 (스페인어);페피안 (고기 스튜);티칼 마야 유적;화산이 많은 마야의 땅
BLZ;벨리즈;벨모판;NA;3;17.25,-88.76;H:1,8,1:ce1126,003f87,ce1126|C:fff:.5:.5:.26;헬로 (영어);라이스 앤드 빈스;그레이트 블루홀;중앙아메리카에서 유일하게 영어가 공용어
SLV;엘살바도르;산살바도르;NA;3;13.69,-89.22;h:0047ab,fff,0047ab|C:ffcc00:.5:.5:.1;올라 (스페인어);푸푸사 (속을 채운 옥수수전);산타아나 화산;중앙아메리카에서 가장 작은 나라
HND;온두라스;테구시갈파;NA;3;14.07,-87.19;h:00bce4,fff,00bce4|S:00bce4:.5:.5:.06|S:00bce4:.36:.42:.05|S:00bce4:.64:.42:.05|S:00bce4:.36:.58:.05|S:00bce4:.64:.58:.05;올라 (스페인어);발레아다 (밀전병 콩 요리);코판 마야 유적;카리브해 로아탄섬의 다이빙
NIC;니카라과;마나과;NA;3;12.11,-86.24;h:0067c6,fff,0067c6|P:3a9b3a:.5,.38,.57,.6,.43,.6;올라 (스페인어);가요 핀토 (콩밥);오메테페섬 (호수 위 화산섬);'호수와 화산의 나라'
CRI;코스타리카;산호세;NA;2;9.93,-84.08;H:1,1,2,1,1:002b7f,fff,ce1126,fff,002b7f;올라 (스페인어);가요 핀토 (콩밥);아레날 화산;군대가 없는 나라, '푸라 비다(순수한 삶)'
PAN;파나마;파나마시티;NA;2;8.98,-79.52;f:fff|R:d21034:.5:0:.5:.5|R:005293:0:.5:.5:.5|S:005293:.25:.25:.1|S:d21034:.75:.75:.1;올라 (스페인어);산코초 (닭고기 수프);파나마 운하;두 대양을 잇는 운하의 나라
CUB;쿠바;아바나;NA;2;23.11,-82.37;h:002a8f,fff,002a8f,fff,002a8f|T:cf142b:.43|S:fff:.15:.5:.1;올라 (스페인어);로파 비에하 (찢은 소고기);아바나 구시가지와 클래식 카;카리브해에서 가장 큰 섬나라
JAM;자메이카;킹스턴;NA;2;18.0,-76.79;f:009b3a|P:000:0,0,.5,.5,0,1|P:000:1,0,.5,.5,1,1|X:fed100:.13;와 관 (자메이카 크리올어);저크 치킨;던스 리버 폭포;레게 음악과 육상 단거리 강국
HTI;아이티;포르토프랭스;NA;3;18.54,-72.34;h:00209f,d21034|R:fff:.38:.35:.24:.3;보주 (아이티 크레올어);그리오 (돼지고기 튀김);라페리에르 요새;최초의 흑인 공화국 (1804년 독립)
DOM;도미니카 공화국;산토도밍고;NA;2;18.47,-69.9;f:fff|R:002d62:0:0:.45:.42|R:ce1126:.55:0:.45:.42|R:ce1126:0:.58:.45:.42|R:002d62:.55:.58:.45:.42;올라 (스페인어);망구 (으깬 플랜틴);푼타카나 해변;야구 선수를 많이 배출한 섬나라
BHS;바하마;나소;NA;3;25.05,-77.34;h:00abc9,fae042,00abc9|T:000:.35;헬로 (영어);콘치 프리터 (소라 튀김);돼지 해변 (빅 메이저 케이);700개 섬, 수영하는 돼지
TTO;트리니다드 토바고;포트오브스페인;NA;3;10.66,-61.51;f:ce1126|d:fff:.36|d:000:.27;헬로 (영어);더블스 (병아리콩 샌드);피치 레이크 (천연 아스팔트 호수);스틸 드럼과 칼립소 음악
BRB;바베이도스;브리지타운;NA;3;13.1,-59.62;v:00267f,ffc726,00267f|P:000:.5,.28,.54,.42,.58,.32,.56,.5,.52,.5,.52,.72,.48,.72,.48,.5,.44,.5,.42,.32,.46,.42;헬로 (영어);쿠쿠와 날치;해리슨 동굴;리한나의 고향, 럼주의 섬
COL;콜롬비아;보고타;SA;1;4.71,-74.07;H:2,1,1:fcd116,003893,ce1126;올라 (스페인어);반데하 파이사 (고기 모둠 접시);카르타헤나 성곽 도시;커피와 에메랄드의 나라
VEN;베네수엘라;카라카스;SA;2;10.48,-66.9;h:ffcc00,00247d,cf142b|S:fff:.36:.52:.03|S:fff:.4:.44:.03|S:fff:.45:.39:.03|S:fff:.5:.37:.03|S:fff:.55:.39:.03|S:fff:.6:.44:.03|S:fff:.64:.52:.03;올라 (스페인어);아레파 (옥수수빵);앙헬 폭포;세계에서 가장 높은 폭포가 있는 나라
GUY;가이아나;조지타운;SA;3;6.8,-58.16;f:009e49|T:fff:1|T:fcd116:.94|T:000:.5|T:ce1126:.44;헬로 (영어);페퍼팟 (고기 스튜);카이에투르 폭포;남아메리카에서 유일하게 영어가 공용어
SUR;수리남;파라마리보;SA;3;5.85,-55.2;H:2,1,4,1,2:377e3f,fff,b40a2d,fff,377e3f|S:ecc81d:.5:.5:.18;할로 (네덜란드어);로티 (커리와 밀전병);파라마리보 목조 역사 지구;남아메리카에서 유일하게 네덜란드어가 공용어
ECU;에콰도르;키토;SA;2;-0.18,-78.47;H:2,1,1:ffdd00,034ea2,ed1c24|C:8a6e3a:.5:.5:.12;올라 (스페인어);세비체·쿠이 (기니피그 구이);갈라파고스 제도;적도가 지나는 나라
PER;페루;리마;SA;1;-12.05,-77.04;v:d91023,fff,d91023;올라 (스페인어);세비체 (회 무침);마추픽추;잉카 제국의 중심
BRA;브라질;브라질리아;SA;1;-15.79,-47.88;f:009c3b|P:ffdf00:.5,.1,.92,.5,.5,.9,.08,.5|C:002776:.5:.5:.22;올라 (포르투갈어);슈하스쿠·페이조아다;리우데자네이루 예수상;축구와 아마존, 삼바 카니발
BOL;볼리비아;수크레;SA;2;-19.05,-65.26;h:d52b1e,f9e300,007934;올라 (스페인어);살테냐 (육즙 만두빵);우유니 소금사막;정부는 라파스에 있는, 바다 없는 고원 나라
PRY;파라과이;아순시온;SA;3;-25.26,-57.58;h:d52b1e,fff,0038a8|C:fd0:.5:.5:.1;음바에이차파 (과라니어);소파 파라과야 (옥수수빵);이타이푸 댐;국기 앞뒤 무늬가 다른 나라
URY;우루과이;몬테비데오;SA;2;-34.9,-56.16;h:fff,0038a8,fff,0038a8,fff,0038a8,fff,0038a8,fff|R:fff:0:0:.4:.555|C:fcd116:.2:.28:.12;올라 (스페인어);치비토 (스테이크 샌드위치)·아사도;콜로니아 델 사크라멘토;첫 월드컵 개최·우승국
ARG;아르헨티나;부에노스아이레스;SA;1;-34.6,-58.38;h:74acdf,fff,74acdf|C:f6b40e:.5:.5:.1;올라 (스페인어);아사도 (숯불 소고기);이과수 폭포;탱고와 축구의 나라
CHL;칠레;산티아고;SA;1;-33.45,-70.67;h:fff,d52b1e|R:0039a6:0:0:.33:.5|S:fff:.165:.25:.12;올라 (스페인어);엠파나다 (속을 채운 빵);이스터섬 모아이;세계에서 가장 길쭉한 나라
AUS;오스트레일리아;캔버라;OC;1;-35.28,149.13;f:00008b|U:.5|S:fff:.25:.75:.12|S:fff:.75:.22:.05|S:fff:.63:.48:.05|S:fff:.87:.42:.05|S:fff:.75:.82:.06;굿다이 (호주 영어);미트 파이·베지마이트;시드니 오페라 하우스;캥거루와 코알라
NZL;뉴질랜드;웰링턴;OC;1;-41.29,174.78;f:00247d|U:.5|S:cc142b:.75:.25:.06|S:cc142b:.66:.47:.06|S:cc142b:.86:.42:.05|S:cc142b:.75:.78:.07;키아 오라 (마오리어);항이 (땅속 찜 요리);밀퍼드 사운드;양이 사람보다 많은 나라
PNG;파푸아뉴기니;포트모르즈비;OC;3;-9.44,147.18;f:000|P:ce1126:0,0,1,0,1,1|S:fff:.25:.6:.06|S:fff:.33:.75:.05|S:fff:.17:.75:.05|S:fff:.25:.88:.05|C:fcd116:.7:.3:.1;구데 (톡피신어);무무 (땅속 찜 요리);코코다 트랙;언어가 800개가 넘는 나라
FJI;피지;수바;OC;2;-18.14,178.44;f:68bfe5|U:.5|R:fff:.64:.28:.2:.38|R:ce1126:.64:.28:.2:.08;불라 (피지어);코코다 (코코넛 생선회);마마누카 제도;럭비를 사랑하는 남태평양 섬나라
SLB;솔로몬 제도;호니아라;OC;3;-9.43,159.95;f:0051ba|P:215b33:0,1,1,0,1,1|D:fcd116:.12|S:fff:.12:.12:.05|S:fff:.28:.12:.05|S:fff:.12:.32:.05|S:fff:.28:.32:.05|S:fff:.2:.22:.05;할로 (솔로몬 피진어);포이 (토란 반죽);과달카날섬;제2차 세계대전의 큰 전투지
VUT;바누아투;포트빌라;OC;3;-17.73,168.32;h:d21034,009543|T:000:.45|R:000:.3:.44:.7:.12|R:fdce12:.3:.47:.7:.06;할로 (비슬라마어);랍랍 (얌 푸딩);야수르 화산;번지점프의 원조 '나골' 의식
WSM;사모아;아피아;OC;3;-13.83,-171.76;f:ce1126|R:002b7f:0:0:.5:.5|S:fff:.25:.12:.05|S:fff:.16:.27:.05|S:fff:.34:.25:.05|S:fff:.25:.4:.06;탈로파 (사모아어);팔루사미 (코코넛 크림 토란잎);토 수아 해구 (바다 구멍);날짜 변경선 서쪽으로 옮겨 간 나라
TON;통가;누쿠알로파;OC;3;-21.14,-175.2;f:c10000|R:fff:0:0:.42:.5|R:c10000:.17:.08:.08:.34|R:c10000:.08:.21:.26:.08;말로 에 렐레이 (통가어);오타 이카 (생선회);하아모가 아 마우이 (돌 문);태평양에 남은 폴리네시아 왕국`;
  const CONT = { AS: '아시아', EU: '유럽', AF: '아프리카', NA: '북아메리카', SA: '남아메리카', OC: '오세아니아' };
  const CONT_C = { AS: [34, 90], EU: [50, 15], AF: [3, 20], NA: [30, -90], SA: [-15, -60], OC: [-25, 140] };
  const C = RAW.trim().split('\n').map((ln) => {
    const f = ln.split(';'); const ll = f[5].split(',').map(Number);
    return { id: f[0], n: f[1], cap: f[2], ct: f[3], tier: +f[4], la: ll[0], lo: ll[1], flag: f[6], hi: f[7], food: f[8], sight: f[9], fact: f[10] };
  });
  const CI = {}; C.forEach((c, i) => { CI[c.id] = i; });

  /* 명소: [이름, 나라 id(,다른 나라 id), 위도, 경도, 설명] */
  const LM = [
    ['에펠탑', 'FRA', 48.858, 2.294, '1889년 만국박람회 때 세운 324m 철탑'],
    ['몽생미셸', 'FRA', 48.636, -1.511, '밀물 때면 바다 위 섬이 되는 바위산 수도원'],
    ['콜로세움', 'ITA', 41.89, 12.492, '검투사 경기가 열리던 고대 원형 경기장'],
    ['피사의 사탑', 'ITA', 43.723, 10.396, '기울어진 채 800년 넘게 서 있는 하얀 종탑'],
    ['사그라다 파밀리아', 'ESP', 41.404, 2.174, '140년 넘게 짓고 있는 옥수수 모양 첨탑의 성당'],
    ['알함브라 궁전', 'ESP', 37.176, -3.588, '이슬람 왕조가 남긴 언덕 위 붉은 궁전'],
    ['빅벤', 'GBR', 51.5, -0.124, '강가 국회의사당 옆의 커다란 시계탑'],
    ['스톤헨지', 'GBR', 51.179, -1.826, '들판에 둥글게 세운 거대한 선사 시대 돌기둥'],
    ['노이슈반슈타인 성', 'DEU', 47.557, 10.749, '동화 속 성의 모델이 된 산 위의 하얀 성'],
    ['브란덴부르크 문', 'DEU', 52.516, 13.378, '분단과 통일의 상징인 기둥 열두 개의 문'],
    ['파르테논 신전', 'GRC', 37.971, 23.726, '언덕 위에 선 아테나 여신의 대리석 신전'],
    ['산토리니', 'GRC', 36.42, 25.43, '파란 둥근 지붕과 하얀 집들이 절벽에 붙은 화산섬'],
    ['붉은 광장', 'RUS', 55.754, 37.621, '양파 모양 돔의 성당과 성벽이 둘러싼 광장'],
    ['바이칼호', 'RUS', 53.5, 108.0, '세계에서 가장 깊고 오래된 호수'],
    ['마터호른', 'CHE', 45.976, 7.658, '피라미드처럼 뾰족하게 솟은 알프스 봉우리'],
    ['모허 절벽', 'IRL', 52.972, -9.43, '대서양을 향해 200m 깎아지른 절벽'],
    ['카를교', 'CZE', 50.086, 14.411, '성인 조각상 30개가 늘어선 옛 돌다리'],
    ['블레드 호수', 'SVN', 46.364, 14.094, '호수 한가운데 작은 섬 위에 교회가 있는 풍경'],
    ['두브로브니크 성벽', 'HRV', 42.641, 18.108, '바다를 향한 성벽으로 둘러싸인 \'아드리아해의 진주\''],
    ['게이랑에르 피오르', 'NOR', 62.1, 7.2, '빙하가 깎은 깊고 좁은 바다 골짜기와 폭포'],
    ['할슈타트', 'AUT', 47.562, 13.649, '산과 호수 사이에 그림처럼 놓인 작은 마을'],
    ['블루 라군', 'ISL', 63.88, -22.449, '검은 용암 지대 한가운데 하늘색 온천'],
    ['기자의 피라미드', 'EGY', 29.979, 31.134, '사막 위 세 개의 거대한 왕의 무덤과 스핑크스'],
    ['아부심벨 신전', 'EGY', 22.337, 31.626, '바위를 깎아 만든 거대한 파라오 석상 넷'],
    ['킬리만자로산', 'TZA', -3.068, 37.356, '적도 가까이 있는데도 꼭대기에 눈이 덮인 산'],
    ['빅토리아 폭포', 'ZMB,ZWE', -17.925, 25.857, '\'천둥 치는 연기\'라 불리는 1.7km 너비의 폭포'],
    ['테이블 마운틴', 'ZAF', -33.963, 18.403, '꼭대기가 탁자처럼 평평한 바닷가 산'],
    ['제마 엘프나 광장', 'MAR', 31.626, -7.989, '뱀 부리는 사람과 노점이 가득한 붉은 도시의 광장'],
    ['젠네 대모스크', 'MLI', 13.905, -4.555, '세계에서 가장 큰 흙벽돌 건축물'],
    ['랄리벨라 암굴 교회', 'ETH', 12.032, 39.041, '바위를 통째로 파 내려가 만든 교회들'],
    ['마사이마라', 'KEN', -1.5, 35.14, '누 떼가 강을 건너 대이동하는 초원'],
    ['바오바브 거리', 'MDG', -20.251, 44.419, '거대한 바오바브나무가 줄지어 선 흙길'],
    ['소수스블레이', 'NAM', -24.73, 15.29, '붉은 모래언덕과 말라 죽은 나무들의 사막'],
    ['페트라', 'JOR', 30.329, 35.444, '붉은 사암 절벽을 깎아 만든 고대 도시'],
    ['사해', 'ISR,JOR', 31.5, 35.5, '몸이 저절로 둥둥 뜨는 아주 짠 호수'],
    ['부르즈 할리파', 'ARE', 25.197, 55.274, '828m, 세계에서 가장 높은 빌딩'],
    ['아야 소피아', 'TUR', 41.009, 28.98, '성당이었다가 모스크가 된 1500년 된 거대한 돔 건물'],
    ['카파도키아', 'TUR', 38.643, 34.828, '버섯 모양 바위 위로 열기구가 뜨는 골짜기'],
    ['페르세폴리스', 'IRN', 29.935, 52.891, '고대 페르시아 제국의 의식용 수도 유적'],
    ['레기스탄 광장', 'UZB', 39.655, 66.976, '푸른 타일 신학교 세 채가 둘러싼 실크로드 광장'],
    ['타지마할', 'IND', 27.175, 78.042, '왕비를 기리며 지은 하얀 대리석 무덤'],
    ['에베레스트산', 'NPL,CHN', 27.988, 86.925, '세계에서 가장 높은 산 (8,849m)'],
    ['시기리야', 'LKA', 7.957, 80.76, '200m 바위 꼭대기에 세운 옛 왕궁'],
    ['만리장성 (바다링)', 'CHN', 40.359, 116.02, '산 능선을 따라 끝없이 이어진 옛 성벽'],
    ['자금성', 'CHN', 39.916, 116.397, '황제가 살던 붉은 벽 노란 지붕의 거대한 궁궐'],
    ['후지산', 'JPN', 35.361, 138.727, '눈 덮인 원뿔 모양의 화산, 나라의 상징'],
    ['경복궁', 'KOR', 37.58, 126.977, '조선 왕조가 처음 세운 궁궐'],
    ['앙코르와트', 'KHM', 13.412, 103.867, '정글 속에 숨어 있던 거대한 돌 사원'],
    ['하롱베이', 'VNM', 20.91, 107.18, '에메랄드빛 바다 위 수천 개의 석회암 섬'],
    ['쉐다곤 파고다', 'MMR', 16.798, 96.149, '금으로 덮인 거대한 불탑'],
    ['보로부두르', 'IDN', -7.608, 110.204, '세계에서 가장 큰 불교 사원'],
    ['페트로나스 트윈 타워', 'MYS', 3.158, 101.712, '88층 쌍둥이 빌딩과 그 사이 구름다리'],
    ['마리나 베이 샌즈', 'SGP', 1.283, 103.86, '빌딩 세 채 꼭대기에 배 모양 수영장'],
    ['자유의 여신상', 'USA', 40.689, -74.045, '횃불을 높이 든 거대한 구리 여신상'],
    ['그랜드 캐니언', 'USA', 36.1, -112.1, '강이 수백만 년 동안 깎아 만든 거대한 협곡'],
    ['골든게이트교', 'USA', 37.819, -122.479, '안개 속 붉은 주황빛 현수교'],
    ['나이아가라 폭포', 'CAN,USA', 43.079, -79.075, '두 나라 국경에 걸친 말발굽 모양 폭포'],
    ['치첸이트사', 'MEX', 20.683, -88.569, '계단식 피라미드 \'엘 카스티요\'가 있는 마야 유적'],
    ['티칼', 'GTM', 17.222, -89.623, '정글 위로 솟은 마야 피라미드들'],
    ['파나마 운하', 'PAN', 9.08, -79.68, '두 대양을 잇는 갑문식 운하'],
    ['마추픽추', 'PER', -13.163, -72.545, '구름 속 산꼭대기에 지은 잉카의 도시'],
    ['예수 그리스도상', 'BRA', -22.952, -43.211, '바닷가 산 위에서 두 팔을 벌린 거대한 석상'],
    ['이과수 폭포', 'ARG,BRA', -25.686, -54.444, '275개 물줄기가 쏟아지는 거대한 폭포'],
    ['우유니 소금사막', 'BOL', -20.134, -67.489, '비가 오면 하늘이 거울처럼 비치는 소금 평원'],
    ['앙헬 폭포', 'VEN', 5.967, -62.535, '높이 979m, 세계에서 가장 높은 폭포'],
    ['갈라파고스 제도', 'ECU', -0.95, -90.97, '다윈이 진화론의 영감을 얻은 섬들'],
    ['모아이 석상 (이스터섬)', 'CHL', -27.121, -109.366, '태평양 외딴섬에 늘어선 거대한 얼굴 석상'],
    ['페리토 모레노 빙하', 'ARG', -50.496, -73.137, '호수로 무너져 내리는 거대한 빙하'],
    ['시드니 오페라 하우스', 'AUS', -33.857, 151.215, '조개껍데기 모양 지붕의 바닷가 공연장'],
    ['울루루', 'AUS', -25.344, 131.036, '사막 한가운데 솟은 거대한 붉은 바위'],
    ['그레이트 배리어 리프', 'AUS', -18.29, 147.7, '2,300km 넘게 이어진 세계 최대 산호초'],
    ['밀퍼드 사운드', 'NZL', -44.641, 167.897, '폭포가 쏟아지는 깊은 피오르'],
  ].map((a) => ({ n: a[0], ids: a[1].split(','), la: a[2], lo: a[3], d: a[4] }));

  /* ───────── 지도 디코딩 · 지리 계산 ───────── */
  const SH = {};       // id → [[ [lon,lat]… ], …]
  function decRing(s) {
    const out = []; let i = 0, x = 0, y = 0, k = 0, nx = 0;
    while (i < s.length) {
      let r = 0, sh = 0, b;
      do { b = s.charCodeAt(i++) - 63; r |= (b & 31) << sh; sh += 5; } while (b >= 32);
      const v = r & 1 ? ~(r >> 1) : r >> 1;
      if (k++ % 2 === 0) nx = v; else { x += nx; y += v; out.push([x / 10, y / 10]); }
    }
    return out;
  }
  function shape(id) {
    if (SH[id] !== undefined) return SH[id];
    const m = MAP[id];
    return (SH[id] = m && m[3] ? m[3].split(' ').map(decRing) : null);
  }
  const D2R = Math.PI / 180;
  function dist(la1, lo1, la2, lo2) {
    const a = Math.sin((la2 - la1) * D2R / 2) ** 2 + Math.cos(la1 * D2R) * Math.cos(la2 * D2R) * Math.sin((lo2 - lo1) * D2R / 2) ** 2;
    return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(Math.max(0, 1 - a)));
  }
  function inCountry(id, la, lo) {
    const rs = shape(id);
    if (!rs) { const c = C[CI[id]]; return !!c && dist(la, lo, c.la, c.lo) < 120; }
    let ins = false;
    for (const r of rs) {
      for (let i = 0, j = r.length - 1; i < r.length; j = i++) {
        const xi = r[i][0], yi = r[i][1], xj = r[j][0], yj = r[j][1];
        if ((yi > la) !== (yj > la) && lo < (xj - xi) * (la - yi) / (yj - yi) + xi) ins = !ins;
      }
    }
    return ins;
  }
  function distToCountry(id, la, lo) {
    if (inCountry(id, la, lo)) return 0;
    const rs = shape(id); const c = C[CI[id]];
    if (!rs) return c ? Math.max(0, dist(la, lo, c.la, c.lo) - 30) : 20000;
    let best = 1e9;
    for (const r of rs) for (const p of r) { const d = dist(la, lo, p[1], p[0]); if (d < best) best = d; }
    return best;
  }
  function countryCenter(id) {
    const m = MAP[id]; const c = C[CI[id]];
    return m && m[3] ? [m[1], m[0]] : [c.la, c.lo];
  }
  /* 어느 나라 위인지(결과 표시용) */
  function countryAt(la, lo) {
    for (const id in MAP) if (MAP[id][3] && inCountry(id, la, lo)) return id;
    for (const c of C) if (!MAP[c.id] && dist(la, lo, c.la, c.lo) < 120) return c.id;
    return null;
  }
  function nameOf(id) { const c = C[CI[id]]; return c ? c.n : (MAP[id] ? MAP[id][2] : '?'); }

  /* ───────── 국기 그리기(캔버스·SVG 공용 기본 도형) ───────── */
  function flagPrims(spec, w, h) {
    const P = [];
    const col = (c) => (c === 'none' ? 'none' : '#' + c);
    const parts = spec.split('|');
    const base = parts[0];
    const rect = (x, y, ww, hh, c) => P.push(['r', x, y, ww, hh, c]);
    const poly = (pts, c) => P.push(['p', pts, c]);
    const circ = (x, y, r, c) => P.push(['c', x, y, r, c]);
    const band = (x1, y1, x2, y2, t, c) => {   // 두께 t인 띠(다각형)
      const dx = x2 - x1, dy = y2 - y1, l = Math.hypot(dx, dy) || 1, nx = -dy / l * t / 2, ny = dx / l * t / 2;
      poly([x1 + nx, y1 + ny, x2 + nx, y2 + ny, x2 - nx, y2 - ny, x1 - nx, y1 - ny], c);
    };
    const star = (cx, cy, r, c, rot) => {
      const pts = []; rot = rot || -Math.PI / 2;
      for (let i = 0; i < 10; i++) { const rr = i % 2 ? r * 0.4 : r, a = rot + i * Math.PI / 5; pts.push(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); }
      poly(pts, c);
    };
    const stripes = (cols, ws, vert) => {
      const tot = ws.reduce((a, b) => a + b, 0); let acc = 0;
      cols.forEach((c, i) => {
        const a = acc / tot, b = (acc + ws[i]) / tot; acc += ws[i];
        if (vert) rect(a * w, 0, (b - a) * w + 0.3, h, col(c)); else rect(0, a * h, w, (b - a) * h + 0.3, col(c));
      });
    };
    const union = (s) => {
      const W = w * s, H = h * s;
      P.push(['clip', 0, 0, W, H]);
      rect(0, 0, W, H, '#012169');
      band(0, 0, W, H, H * 0.2, '#fff'); band(0, H, W, 0, H * 0.2, '#fff');
      band(0, 0, W, H, H * 0.07, '#c8102e'); band(0, H, W, 0, H * 0.07, '#c8102e');
      rect(W / 2 - H * 0.17, 0, H * 0.34, H, '#fff'); rect(0, H / 2 - H * 0.17, W, H * 0.34, '#fff');
      rect(W / 2 - H * 0.1, 0, H * 0.2, H, '#c8102e'); rect(0, H / 2 - H * 0.1, W, H * 0.2, '#c8102e');
      P.push(['unclip']);
    };
    const b = base.split(':');
    if (b[0] === 'f') rect(0, 0, w, h, col(b[1]));
    else if (b[0] === 'h' || b[0] === 'v') { const cs = b[1].split(','); stripes(cs, cs.map(() => 1), b[0] === 'v'); }
    else if (b[0] === 'H' || b[0] === 'V') stripes(b[2].split(','), b[1].split(',').map(Number), b[0] === 'V');
    else if (b[0] === 'U') union(1);
    else if (b[0] === 'US') {
      const cs = []; for (let i = 0; i < 13; i++) cs.push(i % 2 ? 'fff' : 'b22234');
      stripes(cs, cs.map(() => 1), false);
      rect(0, 0, w * 0.4, h * 7 / 13, '#3c3b6e');
      for (let r = 0; r < 5; r++) for (let c = 0; c < 6; c++) circ(w * 0.4 * (c + 0.5) / 6, h * 7 / 13 * (r + 0.5) / 5, h * 0.018, '#fff');
    }
    for (let i = 1; i < parts.length; i++) {
      const o = parts[i].split(':'), k = o[0], n = o.slice(2).map(Number);
      const c = col(o[1] || 'fff');
      if (k === 'C') circ(n[0] * w, n[1] * h, n[2] * h, c);
      else if (k === 'S') star(n[0] * w, n[1] * h, n[2] * h, c);
      else if (k === 'M') {   // 초승달: col, bg, x, y, r
        const bg = col(o[2]), x = +o[3] * w, y = +o[4] * h, r = +o[5] * h;
        circ(x, y, r, c); circ(x + r * 0.3, y, r * 0.8, bg);
      } else if (k === 'N') { const t = n[0] * h; rect(w * 0.36 - t / 2, 0, t, h, c); rect(0, h / 2 - t / 2, w, t, c); }
      else if (k === '+') { const t = n[0] * h; rect(w / 2 - t / 2, 0, t, h, c); rect(0, h / 2 - t / 2, w, t, c); }
      else if (k === 'X') { const t = n[0] * h; band(0, 0, w, h, t, c); band(0, h, w, 0, t, c); }
      else if (k === 'D') band(0, h, w, 0, n[0] * h, c);
      else if (k === 'd') band(0, 0, w, h, n[0] * h, c);
      else if (k === 'T') poly([0, 0, n[0] * w, h / 2, 0, h], c);
      else if (k === 'R') rect(n[0] * w, n[1] * h, n[2] * w, n[3] * h, c);
      else if (k === 'P') { const q = o[2].split(',').map(Number); poly(q.map((v, j) => (j % 2 ? v * h : v * w)), c); }
      else if (k === 'U') union(+o[1] || 0.5);
      else if (k === 'Y') {   // 태극 + 4괘(단순화)
        const cx = w / 2, cy = h / 2, r = h * 0.25, a0 = Math.atan2(2, 3);   // 기울기
        circ(cx, cy, r, '#cd2e3a');
        const pts = []; for (let j = 0; j <= 24; j++) { const a = a0 + Math.PI * j / 24; pts.push(cx + Math.cos(a) * r, cy + Math.sin(a) * r); }
        poly(pts, '#0047a0');
        circ(cx - Math.cos(a0) * r / 2, cy - Math.sin(a0) * r / 2, r / 2, '#cd2e3a');
        circ(cx + Math.cos(a0) * r / 2, cy + Math.sin(a0) * r / 2, r / 2, '#0047a0');
        const tri = (ang, pat) => {   // pat: 3줄, 1=이어진 막대, 0=끊긴 막대
          const ux = Math.cos(ang), uy = Math.sin(ang), px = -uy, py = ux, d0 = h * 0.36, bw = h * 0.25, bt = h * 0.042;
          pat.forEach((s, j) => {
            const d = d0 + j * bt * 1.5, mx = cx + ux * d, my = cy + uy * d;
            if (s) band(mx - px * bw / 2, my - py * bw / 2, mx + px * bw / 2, my + py * bw / 2, bt, '#000');
            else { const g = bw * 0.06; band(mx - px * bw / 2, my - py * bw / 2, mx - px * g, my - py * g, bt, '#000'); band(mx + px * g, my + py * g, mx + px * bw / 2, my + py * bw / 2, bt, '#000'); }
          });
        };
        tri(Math.PI + a0, [1, 1, 1]); tri(a0, [0, 0, 0]); tri(-a0, [0, 1, 0]); tri(Math.PI - a0, [1, 0, 1]);
      }
    }
    return P;
  }
  function drawFlag(ctx, spec, x, y, w, h) {
    const P = flagPrims(spec, w, h);
    ctx.save(); ctx.translate(x, y);
    ctx.beginPath(); ctx.rect(0, 0, w, h); ctx.clip();
    let clipped = false;
    for (const p of P) {
      if (p[0] === 'clip') { ctx.save(); clipped = true; ctx.beginPath(); ctx.rect(p[1], p[2], p[3], p[4]); ctx.clip(); continue; }
      if (p[0] === 'unclip') { if (clipped) ctx.restore(); clipped = false; continue; }
      const c = p[0] === 'p' ? p[2] : p[5] || p[4];
      if (c === 'none') continue;
      ctx.fillStyle = p[0] === 'r' ? p[5] : p[0] === 'c' ? p[4] : p[2];
      ctx.beginPath();
      if (p[0] === 'r') ctx.rect(p[1], p[2], p[3], p[4]);
      else if (p[0] === 'c') ctx.arc(p[1], p[2], p[3], 0, Math.PI * 2);
      else { const q = p[1]; ctx.moveTo(q[0], q[1]); for (let i = 2; i < q.length; i += 2) ctx.lineTo(q[i], q[i + 1]); ctx.closePath(); }
      ctx.fill();
    }
    if (clipped) ctx.restore();
    ctx.restore();
  }
  function flagSVG(spec) {
    const w = 30, h = 20; const P = flagPrims(spec, w, h); const f = (v) => +v.toFixed(2);
    let s = '<svg viewBox="0 0 30 20" xmlns="http://www.w3.org/2000/svg" style="width:30px;height:20px;border-radius:2px">';
    let open = false, k = 0;
    for (const p of P) {
      if (p[0] === 'clip') { const id = 'gqc' + (k++) + Math.random().toString(36).slice(2, 6); s += '<clipPath id="' + id + '"><rect x="0" y="0" width="' + f(p[3]) + '" height="' + f(p[4]) + '"/></clipPath><g clip-path="url(#' + id + ')">'; open = true; continue; }
      if (p[0] === 'unclip') { if (open) s += '</g>'; open = false; continue; }
      if (p[0] === 'r') s += '<rect x="' + f(p[1]) + '" y="' + f(p[2]) + '" width="' + f(p[3]) + '" height="' + f(p[4]) + '" fill="' + p[5] + '"/>';
      else if (p[0] === 'c') s += '<circle cx="' + f(p[1]) + '" cy="' + f(p[2]) + '" r="' + f(p[3]) + '" fill="' + p[4] + '"/>';
      else s += '<polygon points="' + p[1].map(f).join(',') + '" fill="' + p[2] + '"/>';
    }
    if (open) s += '</g>';
    return s + '</svg>';
  }

  /* ───────── 문제 · 단서 ───────── */
  const KIND = { c: '나라 찾기', p: '수도 찾기', l: '명소 찾기' };
  /* 단서 목록(어려운 것 → 쉬운 것). 마지막 단서는 '정답급'이라 어려움에선 빠진다 */
  function clues(q) {
    if (q.k === 'l') {
      const m = LM[q.i], c = C[CI[m.ids[0]]];
      return [
        { l: '설명', t: m.d },
        { l: '대륙', t: CONT[c.ct] },
        { l: '나라 국기', f: c.flag },
        { l: '명소 이름', t: m.n },
        { l: '나라', t: m.ids.map(nameOf).join(' · ') },
      ];
    }
    const c = C[q.i];
    if (q.k === 'p') return [
      { l: '수도', t: c.cap },
      { l: '대륙', t: CONT[c.ct] },
      { l: '인사말', t: c.hi },
      { l: '국기', f: c.flag },
      { l: '나라', t: c.n },
    ];
    return [
      { l: '인사말', t: c.hi },
      { l: '음식', t: c.food },
      { l: '특징', t: c.fact },
      { l: '명소', t: c.sight },
      { l: '국기', f: c.flag },
      { l: '대륙', t: CONT[c.ct] },
      { l: '수도', t: c.cap },
    ];
  }
  const maxClues = (s, q) => clues(q).length - (s.df === 3 ? 1 : 0);
  const startClues = (s) => (s.df === 1 ? 2 : 1);
  const mult = (s, q, shown) => Math.max(0.4, 1 - 0.1 * (shown - startClues(s)));
  function answerOf(q) {
    if (q.k === 'l') { const m = LM[q.i]; return { la: m.la, lo: m.lo, ids: m.ids, name: m.n, sub: m.ids.map(nameOf).join(' · ') }; }
    const c = C[q.i];
    if (q.k === 'p') return { la: c.la, lo: c.lo, ids: [c.id], name: c.cap, sub: c.n + '의 수도' };
    const cc = countryCenter(c.id);
    return { la: cc[0], lo: cc[1], ids: [c.id], name: c.n, sub: CONT[c.ct] + ' · 수도 ' + c.cap, area: true };
  }
  /* 점수: 나라 찾기 = 나라 안이면 거리 0(최고점), 밖이면 국경까지 거리. 수도·명소 = 지점까지 거리 + 맞는 나라 보너스 */
  function scoreGuess(q, la, lo, m) {
    const a = answerOf(q);
    /* 지도가 단순화돼 해안·섬이 조금 어긋나므로 국경에서 30km 안(명소·수도는 그 지점 100km 안)도 '맞는 나라'로 친다 */
    const edge = Math.min(...a.ids.map((id) => distToCountry(id, la, lo)));
    if (a.area) {
      const d = edge <= 30 ? 0 : edge;
      return { d: Math.round(d), ok: d === 0, p: Math.round(5000 * Math.exp(-d / 1500) * m) };
    }
    const d = dist(la, lo, a.la, a.lo);
    const ok = edge <= 30 || d <= 100;
    return { d: Math.round(d), ok, p: Math.round((4500 * Math.exp(-d / 1000) + (ok ? 500 : 0)) * m) };
  }

  function pool(opts) {
    const df = +opts.diff || 2, area = opts.area || 'all';
    const tierOk = (t) => (df === 1 ? t <= 1 : df === 2 ? t <= 2 : true);
    const ctOk = (ct) => area === 'all' || ct === area || (area === 'AM' && (ct === 'NA' || ct === 'SA'));
    let cs = C.map((c, i) => i).filter((i) => tierOk(C[i].tier) && ctOk(C[i].ct));
    if (cs.length < 12) cs = C.map((c, i) => i).filter((i) => ctOk(C[i].ct));
    let ls = LM.map((m, i) => i).filter((i) => ctOk(C[CI[LM[i].ids[0]]].ct));
    if (!ls.length) ls = LM.map((m, i) => i);
    return { cs, ls };
  }
  function makeQuestions(opts, R) {
    const { cs, ls } = pool(opts);
    const mode = opts.mode || 'mix';
    const csq = U.shuffle(cs.slice()), lsq = U.shuffle(ls.slice());
    const used = new Set(), out = [];
    let ci = 0, li = 0;
    for (let r = 0; r < R; r++) {
      let k = mode === 'mix' ? ['c', 'p', 'l'][r % 3] : mode;
      if (k === 'l') {
        let tries = 0;
        while (tries++ < lsq.length && used.has(LM[lsq[li % lsq.length]].ids[0])) li++;
        const i = lsq[li++ % lsq.length]; used.add(LM[i].ids[0]); out.push({ k, i });
      } else {
        let tries = 0;
        while (tries++ < csq.length && used.has(C[csq[ci % csq.length]].id)) ci++;
        const i = csq[ci++ % csq.length]; used.add(C[i].id); out.push({ k, i });
      }
    }
    if (mode === 'mix') return U.shuffle(out);
    return out;
  }

  /* ───────── 순수 로직 ───────── */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, R = +opts.rounds || 5;
    const s = {
      n, nm: players.map((p, i) => String(p.name || '자리 ' + (i + 1)).slice(0, 16)), R, r: 0, df: +opts.diff || 2, ph: 'g',
      qs: makeQuestions(opts, R),
      sh: [], pin: [], rd: [], tot: Array(n).fill(0), hist: [], seq: 0,
    };
    newRound(s);
    return s;
  }
  function newRound(s) {
    s.sh = Array(s.n).fill(startClues(s)); s.pin = Array(s.n).fill(null); s.rd = Array(s.n).fill(false);
  }
  function actor(s) {
    if (s.ph === 'g') { const a = []; for (let i = 0; i < s.n; i++) if (!s.pin[i]) a.push(i); return a; }
    if (s.ph === 'r') { const a = []; for (let i = 0; i < s.n; i++) if (!s.rd[i]) a.push(i); return a; }
    return null;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const q = s.qs[s.r];
    if (a.t === 'hint') {
      if (s.ph !== 'g' || s.pin[seat]) throw new Error('not now');
      if (s.sh[seat] >= maxClues(s, q)) throw new Error('no more hints');
      s.sh[seat]++;
      return s;
    }
    if (a.t === 'pin') {
      if (s.ph !== 'g' || s.pin[seat]) throw new Error('not now');
      const la = +a.la, lo = +a.lo;
      if (!isFinite(la) || !isFinite(lo) || la < -90 || la > 90 || lo < -180 || lo > 180) throw new Error('bad pin');
      s.pin[seat] = [Math.round(la * 100) / 100, Math.round(lo * 100) / 100];
      if (s.pin.every(Boolean)) {
        const res = s.pin.map((p, i) => { const g = scoreGuess(q, p[0], p[1], mult(s, q, s.sh[i])); return [p[0], p[1], g.d, g.p, g.ok ? 1 : 0, s.sh[i] - startClues(s)]; });
        res.forEach((g, i) => { s.tot[i] += g[3]; });
        s.hist.push(res);
        s.ph = 'r'; s.rd = Array(s.n).fill(false); s.seq++;
      }
      return s;
    }
    if (a.t === 'next') {
      if (s.ph !== 'r') throw new Error('not now');
      s.rd[seat] = true;
      if (s.rd.every(Boolean)) {
        if (s.r + 1 >= s.R) { s.ph = 'e'; }
        else { s.r++; s.ph = 'g'; newRound(s); }
        s.seq++;
      }
      return s;
    }
    throw new Error('unknown action');
  }
  function gauss() { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  function offset(la, lo, km) {   // km 표준편차로 흩뿌리기
    const dla = gauss() * km / 111, dlo = gauss() * km / (111 * Math.max(0.2, Math.cos(la * D2R)));
    return [U.clamp(la + dla, -56, 82), ((lo + dlo + 540) % 360) - 180];
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'r') return s.rd[seat] ? null : { t: 'next' };
    if (s.ph !== 'g' || s.pin[seat]) return null;
    const q = s.qs[s.r];
    const shown = s.sh[seat], extra = shown - startClues(s);
    const hintP = [0, 0.5, 0.35, 0.22][lv] * Math.pow(0.6, extra);
    if (shown < maxClues(s, q) && Math.random() < hintP) return { t: 'hint' };
    const a = answerOf(q);
    const tier = q.k === 'l' ? 1 : C[q.i].tier;
    const know = U.clamp([0, 0.22, 0.48, 0.72][lv] + 0.09 * shown + (tier === 1 ? 0.12 : tier === 3 ? -0.15 : 0), 0.05, 0.97);
    let p;
    if (Math.random() < know) p = offset(a.la, a.lo, [0, 650, 300, 90][lv] * (a.area ? 0.6 : 1));
    else {
      const ct = q.k === 'l' ? C[CI[a.ids[0]]].ct : C[q.i].ct;
      const sameCont = Math.random() < [0, 0.45, 0.7, 0.88][lv] + 0.04 * shown;
      const keys = Object.keys(CONT_C);
      const cc = CONT_C[sameCont ? ct : keys[U.rand(keys.length)]];
      p = offset(cc[0], cc[1], 1400);
    }
    return { t: 'pin', la: p[0], lo: p[1] };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'r') return 2200;
    return [0, 2600, 2100, 1600][lv || 2] + Math.random() * 1800;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const best = Math.max(...s.tot);
    const winners = s.tot.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    const avgD = s.tot.map((_, i) => Math.round(s.hist.reduce((a, h) => a + h[i][2], 0) / s.hist.length));
    const oks = s.tot.map((_, i) => s.hist.reduce((a, h) => a + h[i][4], 0));
    const hints = s.tot.map((_, i) => s.hist.reduce((a, h) => a + h[i][5], 0));
    let bestG = null;
    s.hist.forEach((h, r) => h.forEach((g, i) => { if (!bestG || g[2] < bestG.d) bestG = { d: g[2], i, r }; }));
    const highlights = [];
    if (bestG) highlights.push('가장 가까운 핀: ' + (bestG.d < 1 ? '정확히 맞힘' : L.fmt ? L.fmt.num(bestG.d) + 'km' : bestG.d + 'km') + ' (' + (bestG.r + 1) + '라운드, ' + (s.nm ? s.nm[bestG.i] : '자리 ' + (bestG.i + 1)) + ')');
    return {
      winners, title: '여행 끝!',
      text: s.R + '라운드 · 만점 ' + (s.R * 5000).toLocaleString() + '점',
      highlights,
      stats: [
        { label: '총점', values: s.tot.slice() },
        { label: '평균 거리', values: avgD, unit: 'km', low: true },
        { label: '맞힌 나라', values: oks },
        { label: '더 연 힌트', values: hints, low: true },
      ],
    };
  }
  function hint(s, seat) {
    if (!s || s.ph === 'e') return null;
    const q = s.qs[s.r];
    const lines = [(s.r + 1) + '/' + s.R + '라운드 · ' + KIND[q.k]];
    if (s.ph === 'g') {
      lines.push(q.k === 'c' ? '그 나라 땅 안을 찍으면 5,000점 만점이에요.' : '정확한 지점에 가까울수록 점수가 높고, 맞는 나라 안이면 +500점이에요.');
      if (seat >= 0) lines.push('힌트를 하나 더 열 때마다 이번 판 점수가 10%씩 줄어요(최소 40%). 지금 배율 ' + Math.round(mult(s, q, s.sh[seat]) * 100) + '%.');
      lines.push('두 손가락으로 지도를 벌려 확대하고, 한 번 톡 눌러 핀을 꽂은 뒤 「여기로 정하기」.');
    } else lines.push('모두의 핀과 정답 위치를 확인하고 「다음」을 눌러요.');
    return lines;
  }

  /* ───────── 화면 ───────── */
  const CSS = `
.gq{position:absolute;inset:0;display:flex;flex-direction:column;background:#0f1c26;color:var(--ink);font-family:var(--f-body)}
.gq-top{flex:none;display:flex;align-items:center;gap:6px;padding:6px 56px 4px 10px;min-height:40px;box-sizing:border-box}
.gq-rd{font-family:var(--f-display);font-size:16px;color:var(--brass);white-space:nowrap}
.gq-kind{font-size:12px;font-weight:700;padding:2px 8px;border-radius:999px;background:#1e3a4c;color:#bfe3f5;white-space:nowrap}
.gq-pl{display:flex;gap:4px;flex:1;min-width:0;overflow:hidden;justify-content:flex-end}
.gq-chip{display:flex;align-items:center;gap:3px;font-size:11.5px;padding:2px 6px;border-radius:999px;background:rgba(255,255,255,.07);white-space:nowrap;max-width:96px;overflow:hidden}
.gq-chip .dot{width:9px;height:9px;flex:none}.gq-chip b{font-family:var(--f-mono);font-weight:600}
.gq-chip.done{background:rgba(95,211,160,.18)}
.gq-clue{flex:none;max-height:34%;overflow:auto;padding:4px 10px 6px;display:flex;flex-direction:column;gap:5px}
.gq-c{display:flex;align-items:center;gap:8px;background:#172a37;border-radius:10px;padding:6px 9px;font-size:14px;line-height:1.35}
.gq-c .lb{flex:none;font-size:11px;font-weight:700;color:#8fc3dd;min-width:42px}
.gq-c canvas{flex:none;width:60px;height:40px;border-radius:3px;box-shadow:0 1px 4px rgba(0,0,0,.5)}
.gq-c.new{animation:gqIn .35s ease}
@keyframes gqIn{from{transform:translateY(-6px);opacity:0}to{transform:none;opacity:1}}
.gq-hb{min-height:44px;font-size:14px}
.gq-mapw{position:relative;flex:1 1 auto;min-height:120px;overflow:hidden;touch-action:none}
.gq-mapw canvas{position:absolute;inset:0;width:100%;height:100%;touch-action:none}
.gq-zoom{position:absolute;right:8px;bottom:8px;display:flex;flex-direction:column;gap:6px;z-index:2}
.gq-zoom .btn{width:44px;height:44px;min-height:44px;padding:0;font-size:20px;border-radius:12px;background:rgba(20,32,44,.85)}
.gq-tip{position:absolute;left:8px;bottom:8px;right:60px;font-size:12px;color:#cfe3ef;pointer-events:none;text-shadow:0 1px 3px #000}
.gq-bot{flex:none;display:flex;gap:8px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));align-items:center}
.gq-bot .btn{flex:1;min-height:48px;font-size:16px}
.gq-wait{flex:1;text-align:center;font-size:13px;color:var(--muted)}
.gq-res{flex:none;max-height:38%;overflow:auto;padding:4px 10px 6px;display:flex;flex-direction:column;gap:4px}
.gq-ans{display:flex;align-items:center;gap:8px;background:#1d3442;border-radius:10px;padding:7px 10px}
.gq-ans .nm{font-family:var(--f-display);font-size:19px;color:#ffe08a;line-height:1.15}
.gq-ans .sb{font-size:12px;color:#a9c9da}
.gq-ans canvas{flex:none;width:48px;height:32px;border-radius:3px}
.gq-row{display:flex;align-items:center;gap:6px;font-size:13px;padding:3px 6px;border-radius:8px;background:rgba(255,255,255,.04)}
.gq-row .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.gq-row .km{font-family:var(--f-mono);font-size:12px;color:#a9c9da;white-space:nowrap}
.gq-row .pt{font-family:var(--f-mono);font-weight:700;color:#ffe08a;min-width:56px;text-align:right}
.gq-ok{font-size:11px;font-weight:800;color:#5fd3a0}
.gq-cov{position:absolute;inset:0;z-index:20;background:#0b141b;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;padding:20px;text-align:center}
.gq-cov .big{font-family:var(--f-display);font-size:24px}
.gq-cov .btn{min-height:48px;min-width:200px;font-size:16px}
.gq-cov .lst{display:flex;flex-direction:column;gap:8px;width:min(280px,90%)}
.gq-land .gq-wrap{flex-direction:row}
`;
  let cssOn = false;
  function addCSS() { if (cssOn) return; cssOn = true; document.head.append(L.h('style', { text: CSS, id: 'gq-css' })); }

  /* 투영: 밀러 원통 도법(경도 그대로, 위도는 Y로) */
  const PY = (lat) => 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * U.clamp(lat, -85, 85) * D2R)) / D2R;
  const IPY = (y) => (2.5 * Math.atan(Math.exp(0.8 * y * D2R)) - 0.625 * Math.PI) / D2R;
  const LAT0 = -58, LAT1 = 84, Y0 = PY(LAT0), Y1 = PY(LAT1);
  let PATHS = null;
  function buildPaths() {
    if (PATHS) return PATHS;
    PATHS = {};
    for (const id in MAP) {
      const rs = shape(id); if (!rs) continue;
      const p = new Path2D();
      for (const r of rs) { r.forEach((q, i) => { const x = q[0], y = -PY(q[1]); if (i) p.lineTo(x, y); else p.moveTo(x, y); }); p.closePath(); }
      PATHS[id] = p;
    }
    return PATHS;
  }
  const hue = (id) => { let h = 0; for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) % 997; return h; };

  function mount(root, api) {
    addCSS();
    const h = L.h;
    const el = h('div', { class: 'gq' });
    const top = h('div', { class: 'gq-top' });
    const panel = h('div', { class: 'gq-clue' });
    const mapw = h('div', { class: 'gq-mapw' });
    const cv = h('canvas');
    const tip = h('div', { class: 'gq-tip' });
    const zIn = h('button', { class: 'btn', 'aria-label': '확대', text: '+', 'data-key': 'Equal' });
    const zOut = h('button', { class: 'btn', 'aria-label': '축소', text: '−', 'data-key': 'Minus' });
    const zAll = h('button', { class: 'btn', 'aria-label': '전체 지도', text: '⤢', 'data-key': 'Digit0' });
    mapw.append(cv, tip, h('div', { class: 'gq-zoom' }, zIn, zOut, zAll));
    const bot = h('div', { class: 'gq-bot' });
    el.append(top, panel, mapw, bot);
    root.append(el);
    const ctx = cv.getContext('2d');
    let W = 0, H = 0, dpr = 1;
    const view = { cx: 10, cy: 25, z: 1 };
    let st = null, cur = -1, chosen = -1, temp = null, dirty = true, raf = 0, dead = false, lastSeq = -1, lastRound = -1, revealAt = 0, coverEl = null;
    let shownCount = {};

    const mySeats = () => api.mySeats();
    const multiLocal = () => !api.online && mySeats().length > 1;

    function minZ() { return Math.min(W / 360, H / (Y1 - Y0)); }
    function clampView() {
      const zmin = minZ(); view.z = U.clamp(view.z, zmin, 80);
      const halfW = W / 2 / view.z, halfH = H / 2 / view.z;
      view.cx = 180 - halfW < -180 + halfW ? 0 : U.clamp(view.cx, -180 + halfW, 180 - halfW);
      view.cy = Y1 - halfH < Y0 + halfH ? (Y0 + Y1) / 2 : U.clamp(view.cy, Y0 + halfH, Y1 - halfH);
    }
    function fitAll() { view.z = minZ(); view.cx = 0; view.cy = (Y0 + Y1) / 2; clampView(); dirty = true; }
    function fitPts(pts) {
      let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      pts.forEach(([la, lo]) => { const y = PY(la); x0 = Math.min(x0, lo); x1 = Math.max(x1, lo); y0 = Math.min(y0, y); y1 = Math.max(y1, y); });
      const pad = 0.25, wx = Math.max(12, (x1 - x0) * (1 + pad * 2)), wy = Math.max(10, (y1 - y0) * (1 + pad * 2));
      view.z = Math.min(W / wx, H / wy); view.cx = (x0 + x1) / 2; view.cy = (y0 + y1) / 2; clampView(); dirty = true;
    }
    const toScr = (la, lo) => [(lo - view.cx) * view.z + W / 2, (view.cy - PY(la)) * view.z + H / 2];
    const toGeo = (x, y) => [IPY(view.cy - (y - H / 2) / view.z), (x - W / 2) / view.z + view.cx];

    function resize() {
      const r = mapw.getBoundingClientRect();
      if (!r.width || !r.height) return;
      const first = !W;
      const oldMin = W ? minZ() : 0, wasMin = W && view.z <= oldMin * 1.01;
      W = r.width; H = r.height; dpr = Math.min(3, window.devicePixelRatio || 1);
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      if (first || wasMin) fitAll(); else clampView();
      dirty = true;
    }
    const ro = new ResizeObserver(resize); ro.observe(mapw);
    window.addEventListener('resize', resize);

    /* 지도 그리기 */
    function draw() {
      if (!W) return;
      const paths = buildPaths();
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#173a52'); g.addColorStop(1, '#0f2a3d');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.save();
      ctx.translate(W / 2 - view.cx * view.z, H / 2 + view.cy * view.z); ctx.scale(view.z, view.z);
      // 경위선
      ctx.lineWidth = 0.6 / view.z; ctx.strokeStyle = 'rgba(160,210,235,.10)'; ctx.beginPath();
      for (let lo = -180; lo <= 180; lo += 30) { ctx.moveTo(lo, -Y1); ctx.lineTo(lo, -Y0); }
      for (let la = -60; la <= 80; la += 20) { ctx.moveTo(-180, -PY(la)); ctx.lineTo(180, -PY(la)); }
      ctx.stroke();
      ctx.strokeStyle = 'rgba(255,220,140,.16)'; ctx.beginPath(); ctx.moveTo(-180, 0); ctx.lineTo(180, 0); ctx.stroke();
      const rev = st && (st.ph === 'r' || st.ph === 'e');
      const ans = rev ? answerOf(st.qs[Math.min(st.r, st.qs.length - 1)]) : null;
      for (const id in paths) {
        const hh = hue(id);
        const isAns = ans && ans.ids.includes(id);
        ctx.fillStyle = isAns ? '#e9b949' : `hsl(${70 + (hh % 60)},${18 + (hh % 13)}%,${44 + (hh % 9)}%)`;
        ctx.fill(paths[id], 'evenodd');
      }
      ctx.lineWidth = 0.7 / view.z; ctx.strokeStyle = 'rgba(25,40,30,.85)';
      for (const id in paths) ctx.stroke(paths[id]);
      ctx.restore();
      // 지도에 없는 작은 나라: 점
      for (const c of C) if (!MAP[c.id]) {
        const [x, y] = toScr(c.la, c.lo); if (x < -5 || y < -5 || x > W + 5 || y > H + 5) continue;
        const isAns = ans && ans.ids.includes(c.id);
        ctx.fillStyle = isAns ? '#e9b949' : '#a7b98f'; ctx.strokeStyle = 'rgba(25,40,30,.9)'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(x, y, Math.max(2.2, Math.min(5, view.z * 0.35)), 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      }
      // 핀
      const pins = [];
      if (st && st.ph === 'g') {
        const vs = viewSeat();
        if (vs >= 0 && st.pin[vs]) pins.push([st.pin[vs][0], st.pin[vs][1], vs]);
        else if (vs >= 0 && temp) pins.push([temp[0], temp[1], vs, 1]);
      } else if (rev) {
        const hr = st.hist[st.ph === 'e' ? st.hist.length - 1 : st.r];
        const t = Math.min(1, (performance.now() - revealAt) / (700 / (L.debug.speed || 1)));
        if (hr && ans) {
          const [ax, ay] = toScr(ans.la, ans.lo);
          hr.forEach((g, i) => {
            const [x, y] = toScr(g[0], g[1]);
            ctx.strokeStyle = api.players[i] ? api.players[i].color : '#fff'; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
            ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + (ax - x) * t, y + (ay - y) * t); ctx.stroke(); ctx.setLineDash([]);
            pins.push([g[0], g[1], i]);
          });
          if (t < 1) dirty = true;
          // 정답 별
          ctx.save(); ctx.translate(ax, ay);
          ctx.fillStyle = '#ffe08a'; ctx.strokeStyle = '#5a3a00'; ctx.lineWidth = 2;
          ctx.beginPath(); for (let k = 0; k < 10; k++) { const r = k % 2 ? 5 : 12, a = -Math.PI / 2 + k * Math.PI / 5; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.restore();
        }
      }
      pins.forEach(([la, lo, i, tmp]) => {
        const [x, y] = toScr(la, lo);
        const c = api.players[i] ? api.players[i].color : '#fff';
        ctx.save(); ctx.translate(x, y);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(0, 0, 6, 2.5, 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = c; ctx.strokeStyle = tmp ? '#fff' : '#111'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.bezierCurveTo(-3, -9, -10, -13, -10, -22); ctx.arc(0, -22, 10, Math.PI, 0); ctx.bezierCurveTo(10, -13, 3, -9, 0, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.font = '700 11px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(String(i + 1), 0, -22);
        ctx.restore();
      });
    }
    function loop() { if (dead) return; if (dirty) { dirty = false; draw(); } raf = requestAnimationFrame(loop); }
    raf = requestAnimationFrame(loop);

    /* 조작: 끌기·두 손가락 확대·휠·톡 누르기 */
    const ptrs = new Map(); let moved = false, pinch = null, downAt = null;
    const loc = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
    function zoomAt(f, x, y) {
      const [la, lo] = toGeo(x, y); const Y = PY(la);
      view.z *= f; clampView();
      view.cx = lo - (x - W / 2) / view.z; view.cy = Y + (y - H / 2) / view.z; clampView(); dirty = true;
    }
    cv.addEventListener('pointerdown', (e) => {
      try { cv.setPointerCapture(e.pointerId); } catch (er) {}
      ptrs.set(e.pointerId, loc(e));
      if (ptrs.size === 1) { moved = false; downAt = loc(e); }
      if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), m: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2] }; moved = true; }
    });
    cv.addEventListener('pointermove', (e) => {
      if (!ptrs.has(e.pointerId)) return;
      const p = loc(e), old = ptrs.get(e.pointerId); ptrs.set(e.pointerId, p);
      if (ptrs.size === 1) {
        if (downAt && Math.hypot(p[0] - downAt[0], p[1] - downAt[1]) > 7) moved = true;
        if (moved) { view.cx -= (p[0] - old[0]) / view.z; view.cy += (p[1] - old[1]) / view.z; clampView(); dirty = true; }
      } else if (ptrs.size === 2 && pinch) {
        const [a, b] = [...ptrs.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]), m = [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
        view.cx -= (m[0] - pinch.m[0]) / view.z; view.cy += (m[1] - pinch.m[1]) / view.z;
        if (pinch.d > 10) zoomAt(d / pinch.d, m[0], m[1]);
        pinch = { d, m }; clampView(); dirty = true;
      }
    });
    const up = (e) => {
      if (!ptrs.has(e.pointerId)) return;
      const p = ptrs.get(e.pointerId); ptrs.delete(e.pointerId);
      if (ptrs.size < 2) pinch = null;
      if (ptrs.size === 0 && !moved && e.type === 'pointerup') tapAt(p[0], p[1]);
    };
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    cv.addEventListener('wheel', (e) => { e.preventDefault(); const p = loc(e); zoomAt(Math.exp(-e.deltaY * 0.0015), p[0], p[1]); }, { passive: false });
    cv.addEventListener('dblclick', (e) => { const p = loc(e); zoomAt(2, p[0], p[1]); });
    zIn.onclick = () => zoomAt(1.6, W / 2, H / 2);
    zOut.onclick = () => zoomAt(1 / 1.6, W / 2, H / 2);
    zAll.onclick = () => fitAll();

    function viewSeat() {
      if (!st) return -1;
      if (st.ph === 'g') { if (multiLocal()) return cur; const m = mySeats(); return m.length ? m[0] : -1; }
      return -1;
    }
    function canPin() { const v = viewSeat(); return st && st.ph === 'g' && v >= 0 && !st.pin[v] && api.canAct(v); }
    function tapAt(x, y) {
      if (!canPin()) return;
      const [la, lo] = toGeo(x, y);
      if (la < LAT0 - 0.5 || la > LAT1 + 0.5 || lo < -180 || lo > 180) return;
      temp = [la, lo]; dirty = true; api.sfx('pop'); api.buzz(8, 'ui');
      renderBottom();
    }

    /* 위쪽: 라운드·참가자 칩 */
    function renderTop() {
      top.textContent = '';
      const q = st.qs[Math.min(st.r, st.qs.length - 1)];
      top.append(h('span', { class: 'gq-rd', text: (Math.min(st.r, st.R - 1) + 1) + '/' + st.R }), h('span', { class: 'gq-kind', text: KIND[q.k] }));
      const pl = h('div', { class: 'gq-pl' });
      api.players.forEach((p, i) => {
        const done = st.ph === 'g' ? !!st.pin[i] : st.ph === 'r' ? st.rd[i] : true;
        pl.append(h('span', { class: 'gq-chip' + (done ? ' done' : ''), title: p.name },
          h('span', { class: 'dot', style: { '--c': p.color } }),
          h('b', { text: st.tot[i] >= 10000 ? (st.tot[i] / 1000).toFixed(1) + 'k' : String(st.tot[i]) }),
          st.ph === 'g' && st.pin[i] ? h('span', { text: '✓' }) : null));
      });
      top.append(pl);
    }
    function flagCanvas(spec, w, hh) {
      const c = h('canvas'); const d = Math.min(3, window.devicePixelRatio || 1);
      c.width = Math.round(w * d); c.height = Math.round(hh * d);
      const x = c.getContext('2d'); x.scale(d, d); drawFlag(x, spec, 0, 0, w, hh);
      return c;
    }
    /* 가운데 위: 단서 / 결과 */
    function renderPanel() {
      panel.textContent = ''; panel.className = 'gq-clue';
      const q = st.qs[Math.min(st.r, st.qs.length - 1)];
      if (st.ph === 'g') {
        const v = viewSeat();
        if (v < 0) {
          const list = clues(q).slice(0, startClues(st));
          list.forEach((c) => panel.append(clueEl(c, false)));
          panel.append(h('div', { class: 'gq-c', style: { justifyContent: 'center', color: 'var(--muted)' }, text: '모두 핀을 꽂는 중…' }));
          return;
        }
        const all = clues(q), n = st.sh[v], key = st.r + ':' + v;
        const prevN = shownCount[key] || 0; shownCount[key] = n;
        all.slice(0, n).forEach((c, i) => panel.append(clueEl(c, prevN && i >= prevN)));
        if (!st.pin[v]) {
          const left = maxClues(st, q) - n;
          const m = Math.round(mult(st, q, n) * 100);
          if (left > 0) {
            const nx = all[n];
            panel.append(h('button', { class: 'btn gq-hb', 'data-key': 'KeyH', onclick: () => { api.sfx('click'); api.actAs(v, { t: 'hint' }); } },
              '💡 힌트: ' + nx.l + ' 열기 (' + m + '%→' + Math.max(40, m - 10) + '%) · 남은 ' + left));
          } else panel.append(h('div', { class: 'muted', style: { fontSize: '12px', textAlign: 'center' }, text: '힌트를 다 열었어요 · 이번 판 점수 ' + m + '%' }));
        }
        if (prevN && n > prevN) setTimeout(() => { panel.scrollTop = panel.scrollHeight; }, 0);
      } else {
        panel.className = 'gq-res';
        const hr = st.hist[st.ph === 'e' ? st.hist.length - 1 : st.r];
        const a = answerOf(q);
        const fl = q.k === 'l' ? C[CI[a.ids[0]]].flag : C[q.i].flag;
        panel.append(h('div', { class: 'gq-ans' }, flagCanvas(fl, 48, 32),
          h('div', {}, h('div', { class: 'nm', text: '정답: ' + a.name }), h('div', { class: 'sb', text: a.sub }))));
        const order = hr.map((g, i) => i).sort((x, y) => hr[y][3] - hr[x][3]);
        order.forEach((i) => {
          const g = hr[i], p = api.players[i];
          const at = countryAt(g[0], g[1]);
          panel.append(h('div', { class: 'gq-row' },
            h('span', { class: 'dot', style: { '--c': p.color } }),
            h('span', { class: 'nm', text: (i + 1) + '. ' + p.name + (at && !g[4] ? ' · ' + nameOf(at) : '') }),
            g[4] ? h('span', { class: 'gq-ok', text: '나라 ✓' }) : null,
            h('span', { class: 'km', text: g[2] < 1 ? '정답 안' : L.fmt.num(g[2]) + 'km' }),
            h('span', { class: 'pt', text: '+' + L.fmt.num(g[3]) })));
        });
      }
    }
    function clueEl(c, isNew) {
      return h('div', { class: 'gq-c' + (isNew ? ' new' : '') }, h('span', { class: 'lb', text: c.l }),
        c.f ? flagCanvas(c.f, 60, 40) : h('span', { text: c.t }));
    }
    /* 아래: 정하기 / 다음 */
    function renderBottom() {
      bot.textContent = '';
      if (st.ph === 'g') {
        const v = viewSeat();
        if (v >= 0 && !st.pin[v]) {
          const b = h('button', { class: 'btn primary', 'data-key': 'Enter', onclick: () => {
            if (!temp) return;
            api.sfx('chip'); api.buzz(20, 'ui');
            const t = temp; temp = null;
            if (multiLocal()) cur = -1;
            api.actAs(v, { t: 'pin', la: t[0], lo: t[1] });
          } }, temp ? '📍 여기로 정하기' : '지도를 눌러 핀을 꽂으세요');
          b.disabled = !temp;
          bot.append(b);
        } else {
          const wait = st.pin.map((p, i) => (p ? -1 : i)).filter((i) => i >= 0).map((i) => api.players[i].name);
          bot.append(h('div', { class: 'gq-wait', text: wait.length ? '기다리는 중: ' + wait.join(', ') : '' }));
        }
        tip.textContent = canPin() && !temp ? '두 손가락으로 확대 · 끌어서 이동 · 톡 눌러 핀' : '';
      } else if (st.ph === 'r') {
        const mine = mySeats().filter((i) => !st.rd[i]);
        if (mine.length) {
          bot.append(h('button', { class: 'btn primary', 'data-key': 'Enter', onclick: () => { api.sfx('click'); mine.forEach((i) => api.actAs(i, { t: 'next' })); } },
            st.r + 1 >= st.R ? '🏁 최종 결과 보기' : '다음 라운드 ▶'));
        } else {
          const wait = st.rd.map((r, i) => (r ? -1 : i)).filter((i) => i >= 0).map((i) => api.players[i].name);
          bot.append(h('div', { class: 'gq-wait', text: wait.length ? '기다리는 중: ' + wait.join(', ') : '' }));
        }
        tip.textContent = '';
      } else { tip.textContent = ''; }
    }
    /* 한 폰 여럿: 누가 찍을지 고르고, 다른 사람은 가리기 */
    function renderCover() {
      if (coverEl) { coverEl.remove(); coverEl = null; }
      if (!st || st.ph !== 'g' || !multiLocal()) return;
      if (cur >= 0 && !st.pin[cur]) return;
      cur = -1;
      const todo = mySeats().filter((i) => !st.pin[i]);
      if (!todo.length) return;
      if (chosen >= 0 && todo.includes(chosen)) {
        const p = api.players[chosen];
        coverEl = h('div', { class: 'gq-cov' },
          h('span', { class: 'dot', style: { '--c': p.color, width: '18px', height: '18px' } }),
          h('div', { class: 'big', text: p.name + ' 차례' }),
          h('div', { class: 'muted', text: '다른 사람은 화면을 보지 마세요' }),
          h('button', { class: 'btn primary', onclick: () => { cur = chosen; chosen = -1; temp = null; api.sfx('click'); refresh(); } }, '단서 보기'),
          h('button', { class: 'btn ghost', onclick: () => { chosen = -1; renderCover(); } }, '다른 사람 고르기'));
      } else {
        coverEl = h('div', { class: 'gq-cov' },
          h('div', { class: 'big', text: '누가 핀을 꽂을까요?' }),
          h('div', { class: 'muted', text: '한 사람씩 폰을 받아 몰래 찍어요' }),
          h('div', { class: 'lst' }, ...todo.map((i) => h('button', { class: 'btn', onclick: () => { chosen = i; api.sfx('click'); renderCover(); } },
            h('span', { class: 'dot', style: { '--c': api.players[i].color } }), ' ' + api.players[i].name))));
      }
      el.append(coverEl);
    }
    function refresh() {
      renderTop(); renderPanel(); renderBottom(); renderCover(); dirty = true;
    }
    function update(s, prev) {
      st = s; if (!s) return;
      if (s.r !== lastRound || (prev && prev.ph !== s.ph)) {
        if (s.ph === 'g' && s.r !== lastRound) { temp = null; cur = -1; chosen = -1; fitAll(); if (lastRound >= 0) api.round && api.round((s.r + 1) + '라운드', KIND[s.qs[s.r].k]); }
        lastRound = s.r;
      }
      if (s.seq !== lastSeq) {
        if ((s.ph === 'r' || s.ph === 'e') && prev && prev.ph === 'g') {
          revealAt = performance.now();
          const hr = s.hist[s.hist.length - 1], a = answerOf(s.qs[s.r]);
          if (W) fitPts(hr.map((g) => [g[0], g[1]]).concat([[a.la, a.lo]]));
          const me = mySeats();
          if (me.length) { const best = Math.max(...me.map((i) => hr[i][3])); api.sfx(best >= 3500 ? 'win' : best >= 1500 ? 'chip' : 'thud'); }
        }
        lastSeq = s.seq;
      }
      if (s.ph === 'g' && cur >= 0 && s.pin[cur]) cur = -1;
      refresh();
    }
    return {
      update,
      destroy() {
        dead = true; cancelAnimationFrame(raf); ro.disconnect(); window.removeEventListener('resize', resize);
        if (coverEl) coverEl.remove(); el.remove();
      },
    };
  }

  /* ───────── 도감 ───────── */
  function codexTabs() {
    const tabs = Object.keys(CONT).map((k) => ({
      h: CONT[k],
      p: [CONT[k] + ' ' + C.filter((c) => c.ct === k).length + '개 나라 · 국기는 단순하게 다시 그린 그림이에요.'],
      rows: C.filter((c) => c.ct === k).sort((a, b) => a.n.localeCompare(b.n, 'ko')).map((c) => ({
        icon: flagSVG(c.flag), name: c.n, tag: '수도 ' + c.cap,
        desc: '인사 ' + c.hi + ' · 음식 ' + c.food + ' · 명소 ' + c.sight + ' · ' + c.fact + ' · ' + ['', '잘 알려진 나라', '보통', '어려운 나라'][c.tier],
      })),
    }));
    tabs.push({
      h: '명소', p: ['명소 찾기에 나오는 ' + LM.length + '곳'],
      rows: LM.map((m) => ({ icon: '📍', name: m.n, tag: m.ids.map(nameOf).join(' · '), desc: m.d + ' · 위도 ' + m.la.toFixed(1) + ', 경도 ' + m.lo.toFixed(1) })),
    });
    return tabs;
  }

  L.register({
    id: 'geoquiz', name: '나라 퀴즈 여행', tag: '세계 지도 퀴즈', cat: '파티',
    blurb: '국기·인사말·음식·명소 단서를 보고 세계 지도에 모두 동시에 핀을 꽂아요. 가까울수록 높은 점수!',
    minPlayers: 1, maxPlayers: 6, defaultPlayers: 2, time: '5–15분',
    hidden: false, undo: false, aiDelay: 2000,
    icon: '<circle cx="28" cy="30" r="17" fill="none" stroke="currentColor" stroke-width="3"/><path d="M11 30h34M28 13c-7 8-7 26 0 34M28 13c7 8 7 26 0 34" fill="none" stroke="currentColor" stroke-width="2.4"/><path d="M40 6c-5 0-8 4-8 8 0 6 8 13 8 13s8-7 8-13c0-4-3-8-8-8z" fill="currentColor"/><circle cx="40" cy="14" r="3" fill="#000" opacity=".45"/>',
    tint: '#1f4c63',
    options: [
      { id: 'mode', label: '문제 종류', tip: '무엇의 위치를 찾을지 골라요.', def: 'mix', choices: [
        { v: 'mix', label: '섞어서', tip: '나라·수도·명소 문제가 골고루 나와요.' },
        { v: 'c', label: '나라', tip: '단서를 보고 그 나라 땅을 찍어요. 나라 안이면 만점.' },
        { v: 'p', label: '수도', tip: '수도 이름을 보고 그 도시 위치를 찍어요.' },
        { v: 'l', label: '명소', tip: '유명한 장소 설명을 보고 그곳을 찍어요.' }] },
      { id: 'rounds', label: '라운드', tip: '몇 문제를 풀지 정해요.', def: 5, choices: [{ v: 5, label: '5판' }, { v: 10, label: '10판' }] },
      { id: 'diff', label: '단서 난이도', tip: '처음 보이는 단서 수와 나오는 나라 범위가 달라져요.', def: 2, choices: [
        { v: 1, label: '쉬움', tip: '잘 알려진 나라만, 단서 2개로 시작해요.' },
        { v: 2, label: '보통', tip: '보통 나라까지, 단서 1개로 시작해요.' },
        { v: 3, label: '어려움', tip: '모든 나라, 단서 1개로 시작하고 정답급 마지막 단서(수도·나라 이름)는 안 나와요.' }] },
      { id: 'area', label: '출제 지역', tip: '문제가 나올 대륙을 골라요(지도는 늘 세계 전체).', def: 'all', choices: [
        { v: 'all', label: '전 세계' }, { v: 'AS', label: '아시아' }, { v: 'EU', label: '유럽' }, { v: 'AF', label: '아프리카' },
        { v: 'AM', label: '아메리카' }, { v: 'OC', label: '오세아니아', tip: '나라가 적어서 난이도와 상관없이 모든 나라가 나와요.' }] },
    ],
    quick: [
      '단서(국기·인사말·음식·명소·수도 등)를 보고 정답 위치를 세계 지도에 찍어요.',
      '모두 동시에 몰래 찍어요. 힌트를 더 열면 그 판 점수가 10%씩 줄어요.',
      '가까울수록 점수가 높고(한 판 최대 5,000점), 총점이 가장 높으면 우승!',
    ],
    rules: [
      { h: '목표', p: ['라운드마다 나오는 단서를 보고 정답 위치에 가장 가깝게 핀을 꽂아 총점을 가장 높게 모으세요.'] },
      { h: '차례에 할 일', p: [
        '차례 없이 모두 동시에 합니다. 단서를 읽고, 지도를 톡 눌러 핀을 꽂은 뒤 「여기로 정하기」를 누르세요.',
        '「💡 힌트 더 보기」를 누르면 다음 단서가 열려요. 하나 열 때마다 이번 판 점수가 10%씩 줄어요(최소 40%).',
        '모두 정하면 정답과 모든 핀이 지도에 나타나요. 「다음 라운드」를 누르면 다음 문제.',
      ] },
      { h: '문제 종류', p: [
        '나라 찾기: 인사말 → 음식 → 특징 → 명소 → 국기 → 대륙 → 수도 순으로 단서가 열려요. 그 나라 땅 안을 찍으면 5,000점, 밖이면 국경까지 거리만큼 깎여요.',
        '수도 찾기: 수도 이름 → 대륙 → 인사말 → 국기 → 나라 이름. 도시 위치까지 거리로 점수(최대 4,500) + 맞는 나라 안이면 +500.',
        '명소 찾기: 설명 → 대륙 → 국기 → 명소 이름 → 나라 이름. 점수는 수도 찾기와 같아요.',
      ] },
      { h: '점수·승리', p: [
        '거리가 0km면 만점, 1,000km 떨어지면 약 1/3로 줄어요(나라 찾기는 1,500km 기준으로 더 너그러워요).',
        '예시: 수도 찾기에서 정답 도시와 300km 떨어졌지만 맞는 나라 안 → 약 3,330 + 500 = 3,830점(힌트를 하나 더 열었다면 ×90%).',
        '마지막 라운드 뒤 총점이 가장 높은 사람이 우승해요. 동점이면 함께 우승.',
      ] },
      { h: '조작', p: [
        '두 손가락 벌리기·오므리기 = 확대·축소, 끌기 = 이동, 톡 = 핀 꽂기(다시 누르면 옮겨져요). 오른쪽 아래 +, −, ⤢(전체 지도) 버튼도 있어요.',
        'PC: 마우스 휠로 확대, 더블클릭으로 크게 확대, H = 힌트, Enter = 정하기·다음.',
      ] },
      { h: '여럿이 하기', p: [
        '한 폰으로 여럿이면 「누가 핀을 꽂을까요?」에서 이름을 누르고, 그 사람만 화면을 보며 몰래 찍어요.',
        '온라인·LAN에서는 각자 폰에서 동시에 찍어요. 정하기 전까지 남의 핀은 보이지 않아요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(어려울수록 더 정확하고 힌트를 덜 써요).',
      ] },
      { h: '지도·자료', p: [
        '나라 경계는 Natural Earth 1:110m 자료(퍼블릭 도메인, naturalearthdata.com)를 단순하게 줄여 넣었어요. 아주 작은 나라(싱가포르·몰타 등)는 점으로 보여요.',
        '분쟁 지역의 경계는 그 자료를 그대로 따른 것이며 어떤 입장을 뜻하지 않아요. 국기는 게임용으로 단순하게 다시 그린 그림이에요.',
      ] },
    ],
    tutorial: [
      { text: '위쪽에 단서가 나와요. 이 단서로 어느 곳인지 맞혀 보세요.', sel: '.gq-clue' },
      { text: '지도를 두 손가락으로 벌려 확대하고, 톡 눌러 핀을 꽂아요.', sel: '.gq-mapw' },
      { text: '자신 있으면 「여기로 정하기」! 모르겠으면 힌트를 더 열 수 있지만 점수가 조금 줄어요.', sel: '.gq-bot' },
    ],
    get codex() { return codexTabs(); },
    init, actor, apply, ai, aiDelayFor, result, hint, mount,
    _t: { C, LM, MAP, inCountry, distToCountry, scoreGuess, answerOf, clues, flagPrims, countryAt },
  });
})();
