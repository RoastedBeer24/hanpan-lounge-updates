/* 세계 땅따먹기 — 32칸 주사위 보드: 땅 사기·건물 올리기·통행료·인수·독점 승리. (오리지널 보드/카드) */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- board ---------- */
  const N = 32, START = 300, SAL = 30, JF = 20, DON = 25, ISLE = 8, TRAVEL = 16, GIVE = 24;
  const GC = ['#a06a44', '#4aaed6', '#c35ea8', '#e8892f', '#d8433a', '#dcbc32', '#3c9e5b', '#3d5fc6'];
  const GP = [10, 12, 14, 17, 20, 23, 26, 30];
  const CITY = [['하노이', '마닐라', '방콕'], ['리마', '보고타', '키토'], ['카이로', '나이로비', '튀니스'], ['아테네', '로마', '이스탄불'],
    ['리스본', '마드리드', '파리'], ['프라하', '빈', '베를린'], ['시드니', '싱가포르', '서울'], ['런던', '도쿄', '뉴욕']];
  const BC = [1, 0.5, 0.75, 1, 1.25];           // cost of each tier (× price): 땅, 별장, 빌딩, 호텔, 랜드마크
  const TM = [0.3, 1, 2.3, 4, 6];               // toll of each tier (× price)
  const TIER = ['땅', '별장', '빌딩', '호텔', '랜드마크'];
  const T = [];  // {k:'s'|'c'|'k'|'j'|'v'|'d', n, g, p}
  const GT = []; // group → tile indices
  for (let sd = 0; sd < 4; sd++) {
    const b = sd * 8;
    T[b] = [{ k: 's', n: '출발' }, { k: 'j', n: '무인도' }, { k: 'v', n: '세계 여행' }, { k: 'd', n: '기부' }][sd];
    T[b + 4] = { k: 'k', n: '행운 카드' };
    for (let h = 0; h < 2; h++) {
      const g = sd * 2 + h; GT[g] = [];
      for (let k = 0; k < 3; k++) { const i = b + 1 + h * 4 + k; T[i] = { k: 'c', n: CITY[g][k], g, p: GP[g] + (k === 2 ? 2 : 0) }; GT[g].push(i); }
    }
  }
  const LINE = [0, 1, 2, 3].map((sd) => GT[sd * 2].concat(GT[sd * 2 + 1]));
  const CARDS = [
    ['보너스', '은행에서 30만을 받아요'], ['복권 당첨', '50만 당첨!'], ['여행 지원금', '20만을 받아요'], ['과속 벌금', '15만을 내요'],
    ['건물 수리', '건물 한 단계마다 4만씩 내요'], ['한턱 내기', '다른 사람 모두에게 10만씩'], ['출발로!', '출발 칸으로 가요'], ['표류', '무인도로 바로 가요'],
    ['여행 초대장', '세계 여행 칸으로 가요'], ['뒤로 세 칸', '세 칸 뒤로 가요'], ['탈출권', '무인도에서 바로 나와요 (보관)'], ['할인 쿠폰', '다음 통행료가 반값 (보관)'],
    ['기부 행사', '기부 칸으로 가요'], ['급행 열차', '다섯 칸 앞으로 가요'],
  ];
  const cost = (i, lv) => Math.round(T[i].p * BC[lv]);
  const invested = (i, lv) => { let c = 0; for (let k = 0; k <= lv; k++) c += cost(i, k); return c; };
  const upCost = (i, from, to) => { let c = 0; for (let k = from + 1; k <= to; k++) c += cost(i, k); return c; };

  /* ---------- state helpers ---------- */
  const own = (s, i) => (s.o[i] === '.' ? -1 : +s.o[i]);
  const lvl = (s, i) => +s.v[i];
  function setT(s, i, ow, lv) {
    s.o = s.o.slice(0, i) + (ow < 0 ? '.' : String(ow)) + s.o.slice(i + 1);
    s.v = s.v.slice(0, i) + String(ow < 0 ? 0 : lv) + s.v.slice(i + 1);
  }
  const hasSet = (s, g, seat) => GT[g].every((i) => own(s, i) === seat);
  function toll(s, i) {
    const ow = own(s, i); if (ow < 0) return 0;
    const b = Math.round(T[i].p * TM[lvl(s, i)]);
    return hasSet(s, T[i].g, ow) ? b * 2 : b;
  }
  const sellVal = (s, i) => Math.floor(invested(i, lvl(s, i)) / 2);
  const takeCost = (s, i) => Math.round(invested(i, lvl(s, i)) * s.to / 10);
  function upOpts(s, i) {
    const c = lvl(s, i);
    if (c >= 3) return s.lm && c === 3 ? [4] : [];
    const r = []; for (let k = c + 1; k <= 3; k++) r.push(k); return r;
  }
  const canUp = (s, seat, i) => upOpts(s, i).some((lv) => upCost(i, lvl(s, i), lv) <= s.m[seat]);
  const owned = (s, seat) => { const r = []; for (let i = 0; i < N; i++) if (own(s, i) === seat) r.push(i); return r; };
  const liquid = (s, seat) => s.m[seat] + owned(s, seat).reduce((a, i) => a + sellVal(s, i), 0);
  const worth = (s, seat) => s.m[seat] + owned(s, seat).reduce((a, i) => a + invested(i, lvl(s, i)), 0);
  const alive = (s) => s.a.map((x, i) => (x ? i : -1)).filter((i) => i >= 0);
  const others = (s, seat) => alive(s).filter((i) => i !== seat);

  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const z = () => Array(n).fill(0);
    return {
      n, nm: players.map((p) => String(p.name || '').slice(0, 10)),
      o: '.'.repeat(N), v: '0'.repeat(N), m: Array(n).fill(START), p: z(), j: z(), tv: z(), k: z(), cp: z(), a: Array(n).fill(1),
      t: 0, ph: 'R', dbl: 0, ag: 0, r: 1,
      R: [0, 20, 30].includes(opts.tl) ? opts.tl : 30, mo: opts.mo === 0 ? 0 : 1, to: [0, 15, 20].includes(opts.to) ? opts.to : 20, lm: opts.lm === 0 ? 0 : 1,
      tr: null, tn: 0, tc: z().map(() => -9), tl: null,
      dk: deck(), di: 0, dt: null, last: null, seq: 0, w: null, why: '', bk: 0,
    };
  }
  function deck() { const a = CARDS.map((_, i) => i); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a.map((c) => c.toString(36)).join(''); }
  function actor(s) { return s.w ? null : s.tr ? s.tr.w : s.t; }

  /* ---------- money ---------- */
  const Q = (s, op) => { s.last.q.push(op); };
  function xfer(s, from, to, amt, why, silent) {
    if (amt <= 0) return;
    if (from >= 0) s.m[from] -= amt; else s.bk -= amt; // bk = what the bank has taken in, net
    if (to >= 0) s.m[to] += amt; else s.bk += amt;
    if (!silent) Q(s, ['$', from, to, amt, why]);
  }
  /* pay `amt` to `to` (seat, −1 bank, −2 = split among everyone else). true if paid now. Otherwise the payer is either
     in the debt phase (must sell land) or bankrupt. */
  function charge(s, seat, to, amt, why) {
    if (amt <= 0) return true;
    if (s.m[seat] >= amt) { payTo(s, seat, to, amt, why); return true; }
    if (liquid(s, seat) < amt) { bankrupt(s, seat, to); return false; }
    s.dt = { a: amt, c: to, y: why }; s.ph = 'D';
    return false;
  }
  function payTo(s, seat, to, amt, why) {
    if (to === -2) { const os = others(s, seat), e = Math.round(amt / Math.max(1, os.length)); os.forEach((o) => xfer(s, seat, o, e, why)); }
    else xfer(s, seat, to, amt, why);
  }
  function bankrupt(s, seat, to) {
    owned(s, seat).forEach((i) => { xfer(s, -1, seat, sellVal(s, i), 'x', true); setT(s, i, -1, 0); });
    const c = s.m[seat];
    if (to >= 0) xfer(s, seat, to, c, 'z', true);
    else if (to === -2) { const os = others(s, seat); const e = Math.floor(c / os.length); os.forEach((o) => xfer(s, seat, o, e, 'z', true)); xfer(s, seat, -1, s.m[seat], 'z', true); }
    else xfer(s, seat, -1, c, 'z', true);
    s.a[seat] = 0; s.j[seat] = 0; s.tv[seat] = 0; s.k[seat] = 0; s.cp[seat] = 0; s.dt = null;
    Q(s, ['Z', seat, to, c]);
    const al = alive(s);
    if (al.length === 1) { s.w = al; s.why = 'last'; }
  }
  function sell(s, seat, i) {
    xfer(s, -1, seat, sellVal(s, i), 'x'); setT(s, i, -1, 0); Q(s, ['X', seat, i]);
  }

  /* ---------- turn flow ---------- */
  function finish(s) {
    if (s.w) return;
    const seat = s.t;
    if (s.a[seat] && s.ag && !s.j[seat] && !s.tv[seat]) { s.ag = 0; s.ph = 'R'; return; }
    endTurn(s);
  }
  function endTurn(s) {
    s.ag = 0; s.dbl = 0; s.dt = null; s.tn = 0; s.tr = null;
    let t = s.t;
    for (let c = 0; c < s.n; c++) { t = (t + 1) % s.n; if (s.a[t]) break; }
    if (t <= s.t) s.r++;
    s.t = t;
    s.ph = s.tv[t] ? 'V' : 'R';
    const cap = s.R || 100;
    if (s.r > cap) endByWorth(s);
  }
  function endByWorth(s) {
    const al = alive(s), ws = al.map((i) => worth(s, i)), mx = Math.max(...ws);
    s.w = al.filter((i, k) => ws[k] === mx); s.why = 'cap';
  }
  function checkMono(s, seat) {
    if (!s.mo || s.w) return;
    if (LINE.some((ln) => ln.every((i) => own(s, i) === seat))) { s.w = [seat]; s.why = 'line'; }
    else if (GT.filter((_, g) => hasSet(s, g, seat)).length >= 3) { s.w = [seat]; s.why = 'triple'; }
    if (s.w) Q(s, ['W', seat, s.why]);
  }
  function goIsle(s, seat) {
    if (s.p[seat] !== ISLE) Q(s, ['j', seat, s.p[seat], ISLE]);
    s.p[seat] = ISLE; s.j[seat] = 3; s.ag = 0; s.dbl = 0;
    Q(s, ['J', seat]);
  }
  function walk(s, seat, n) {
    let pos = s.p[seat];
    Q(s, ['w', seat, pos, n]);
    for (let k = 0; k < n; k++) { pos = (pos + 1) % N; if (pos === 0) xfer(s, -1, seat, SAL, 's'); }
    s.p[seat] = pos;
    land(s, seat);
  }
  function back(s, seat, n) {
    const pos = s.p[seat];
    Q(s, ['b', seat, pos, n]);
    s.p[seat] = (pos - n + N) % N;
    land(s, seat);
  }
  function land(s, seat) {
    const i = s.p[seat], tl = T[i];
    if (tl.k === 'c') {
      const ow = own(s, i);
      if (ow < 0) { if (s.m[seat] >= tl.p) { s.ph = 'B'; return; } return finish(s); }
      if (ow === seat) { if (canUp(s, seat, i)) { s.ph = 'U'; return; } return finish(s); }
      let amt = toll(s, i);
      if (s.cp[seat]) { s.cp[seat]--; amt = Math.ceil(amt / 2); Q(s, ['C', seat]); }
      if (!s.ks) s.ks = s.m.map(() => [0, 0]); // per-seat result stats: [tolls received, tolls paid]
      const paid = liquid(s, seat) >= amt ? amt : Math.max(0, liquid(s, seat)); s.ks[ow][0] += paid; s.ks[seat][1] += paid;
      if (!charge(s, seat, ow, amt, 't')) { if (s.ph !== 'D') finish(s); return; }
      if (s.to && lvl(s, i) < 4 && s.m[seat] >= takeCost(s, i)) { s.ph = 'X'; return; }
      return finish(s);
    }
    if (tl.k === 'k') return drawCard(s, seat);
    if (tl.k === 'j') { goIsle(s, seat); return finish(s); }
    if (tl.k === 'v') { s.tv[seat] = 1; s.ag = 0; Q(s, ['V', seat]); return finish(s); }
    if (tl.k === 'd') { if (!charge(s, seat, -1, DON, 'd')) { if (s.ph !== 'D') finish(s); return; } return finish(s); }
    finish(s);
  }
  function drawCard(s, seat) {
    const c = parseInt(s.dk[s.di], 36);
    s.di++; if (s.di >= s.dk.length) { s.dk = deck(); s.di = 0; }
    Q(s, ['c', c]);
    const fwdTo = (to) => walk(s, seat, (to - s.p[seat] + N) % N);
    const pay = (to, amt) => { if (!charge(s, seat, to, amt, 'c')) { if (s.ph !== 'D') finish(s); return; } finish(s); };
    switch (c) {
      case 0: xfer(s, -1, seat, 30, 'c'); return finish(s);
      case 1: xfer(s, -1, seat, 50, 'c'); return finish(s);
      case 2: xfer(s, -1, seat, 20, 'c'); return finish(s);
      case 3: return pay(-1, 15);
      case 4: return pay(-1, 4 * owned(s, seat).reduce((a, i) => a + lvl(s, i), 0));
      case 5: return pay(-2, 10 * others(s, seat).length);
      case 6: return fwdTo(0);
      case 7: goIsle(s, seat); return finish(s);
      case 8: return fwdTo(TRAVEL);
      case 9: return back(s, seat, 3);
      case 10: s.k[seat] = Math.min(3, s.k[seat] + 1); return finish(s);
      case 11: s.cp[seat] = Math.min(3, s.cp[seat] + 1); return finish(s);
      case 12: return fwdTo(GIVE);
      default: return walk(s, seat, 5);
    }
  }
  function roll(s, seat, fromIsle) {
    const d1 = 1 + Math.floor(Math.random() * 6), d2 = 1 + Math.floor(Math.random() * 6), dbl = d1 === d2;
    Q(s, ['d', d1, d2]);
    if (s.j[seat]) {
      if (dbl) { s.j[seat] = 0; s.ag = 0; Q(s, ['E', seat, 1]); return walk(s, seat, d1 + d2); }
      s.j[seat]--;
      if (!s.j[seat]) { s.ag = 0; Q(s, ['E', seat, 0]); return walk(s, seat, d1 + d2); }
      Q(s, ['S', seat, s.j[seat]]);
      return endTurn(s);
    }
    if (dbl) {
      s.dbl++;
      if (s.dbl >= 3) { goIsle(s, seat); return endTurn(s); }
      s.ag = 1;
    } else s.ag = 0;
    walk(s, seat, d1 + d2);
  }

  function apply(s, seat, a) {
    if (s.w || !a) throw new Error('not your turn');
    if (s.tr) {
      if (seat !== s.tr.w) throw new Error('not your turn');
      s.seq++; s.last = { id: s.seq, s: seat, q: [] };
      tradeAct(s, seat, a); return s;
    }
    if (seat !== s.t || !s.a[seat]) throw new Error('not your turn');
    s.seq++; s.last = { id: s.seq, s: seat, q: [] };
    const i = s.p[seat];
    switch (a.t) {
      case 'roll':
        if (s.ph !== 'R') throw new Error('not rolling now');
        roll(s, seat); break;
      case 'pay':
        if (s.ph !== 'R' || !s.j[seat] || s.m[seat] < JF) throw new Error('cannot pay');
        xfer(s, seat, -1, JF, 'f'); s.j[seat] = 0; Q(s, ['E', seat, 2]); roll(s, seat); break;
      case 'card':
        if (s.ph !== 'R' || !s.j[seat] || !s.k[seat]) throw new Error('no card');
        s.k[seat]--; s.j[seat] = 0; Q(s, ['E', seat, 3]); roll(s, seat); break;
      case 'tv': {
        const to = a.to | 0;
        if (s.ph !== 'V' || !(to >= 0 && to < N) || to === TRAVEL || a.to !== to) throw new Error('bad travel');
        s.tv[seat] = 0; s.ag = 0; walk(s, seat, (to - i + N) % N); break;
      }
      case 'buy': {
        const lv = a.lv;
        if (s.ph !== 'B' || ![0, 1, 2].includes(lv)) throw new Error('bad buy');
        const c = invested(i, lv);
        if (c > s.m[seat]) throw new Error('no money');
        xfer(s, seat, -1, c, 'b'); setT(s, i, seat, lv); Q(s, ['B', seat, i, lv]);
        checkMono(s, seat); finish(s); break;
      }
      case 'up': {
        const lv = a.lv, cur = lvl(s, i);
        if (s.ph !== 'U' || !upOpts(s, i).includes(lv)) throw new Error('bad build');
        const c = upCost(i, cur, lv);
        if (c > s.m[seat]) throw new Error('no money');
        xfer(s, seat, -1, c, 'b'); setT(s, i, seat, lv); Q(s, ['B', seat, i, lv]);
        finish(s); break;
      }
      case 'take': {
        if (s.ph !== 'X') throw new Error('bad takeover');
        const c = takeCost(s, i), ow = own(s, i);
        if (c > s.m[seat] || ow < 0 || ow === seat || lvl(s, i) >= 4) throw new Error('no money');
        xfer(s, seat, ow, c, 'k'); setT(s, i, seat, lvl(s, i)); Q(s, ['K', seat, i, ow]);
        checkMono(s, seat);
        if (!s.w && canUp(s, seat, i)) s.ph = 'U'; else finish(s);
        break;
      }
      case 'offer': {
        if (s.ph !== 'R' || (s.tn || 0) >= TMAX) throw new Error('no trade now');
        const tr = normTrade(s, seat, a.to, a.og, a.om, a.rg, a.rm);
        if (!tr) throw new Error('bad trade');
        s.tn = (s.tn || 0) + 1; if (s.tc) s.tc[seat] = s.r; tr.c = 0; tr.w = tr.b; s.tr = tr;
        break;
      }
      case 'pass':
        if (!['B', 'U', 'X'].includes(s.ph)) throw new Error('nothing to pass');
        finish(s); break;
      case 'sell': {
        if (s.ph !== 'D' || own(s, a.i) !== seat) throw new Error('bad sell');
        sell(s, seat, a.i); settleDebt(s, seat); break;
      }
      case 'auto': {
        if (s.ph !== 'D') throw new Error('no debt');
        while (s.m[seat] < s.dt.a) { const k = sellPick(s, seat, 2); if (k < 0) break; sell(s, seat, k); }
        settleDebt(s, seat); break;
      }
      default: throw new Error('unknown action');
    }
    return s;
  }
  function settleDebt(s, seat) {
    if (s.m[seat] < s.dt.a) return;
    const d = s.dt; s.dt = null;
    payTo(s, seat, d.c, d.a, d.y);
    finish(s);
  }

  /* ---------- trading (public; proposer a <-> target b, one counter round) ---------- */
  const TMAX = 2; // proposals per turn
  function normTrade(s, a, b, ag, am, bg, bm) {
    b = b | 0;
    if (b === a || !(b >= 0 && b < s.n) || !s.a[a] || !s.a[b]) return null;
    const lst = (x, ow) => { if (!Array.isArray(x) || x.length > 12) return null; const r = [...new Set(x.map((v) => v | 0))].sort((p, q) => p - q); return r.every((i) => i >= 0 && i < N && T[i].k === 'c' && own(s, i) === ow) ? r : null; };
    const A = lst(ag || [], a), B = lst(bg || [], b), M1 = Math.max(0, Math.round(+am || 0)), M2 = Math.max(0, Math.round(+bm || 0));
    if (!A || !B || M1 > s.m[a] || M2 > s.m[b]) return null;
    if ((!A.length && !M1) || (!B.length && !M2)) return null; // both sides must give something
    return { a, b, ag: A, am: M1, bg: B, bm: M2 };
  }
  function doTrade(s, tr) {
    tr.ag.forEach((i) => setT(s, i, tr.b, lvl(s, i))); tr.bg.forEach((i) => setT(s, i, tr.a, lvl(s, i)));
    xfer(s, tr.a, tr.b, tr.am, 'r', true); xfer(s, tr.b, tr.a, tr.bm, 'r', true);
  }
  function tradeAct(s, seat, a) {
    const tr = s.tr;
    if (a.t === 'tacc') {
      const ok = normTrade(s, tr.a, tr.b, tr.ag, tr.am, tr.bg, tr.bm);
      s.tr = null;
      if (!ok) { Q(s, ['N', seat, 2]); s.tl = [tr.a, tr.b, 2]; return; }
      doTrade(s, ok); Q(s, ['R', ok.a, ok.b, ok.ag, ok.am, ok.bg, ok.bm]); s.tl = [tr.a, tr.b, 1];
      checkMono(s, ok.a); checkMono(s, ok.b);
    } else if (a.t === 'trej') {
      s.tr = null; Q(s, ['N', seat, 0]); s.tl = [tr.a, tr.b, 0];
    } else if (a.t === 'tctr') {
      if (tr.c || seat !== tr.b) throw new Error('no counter');
      const nt = normTrade(s, tr.a, tr.b, a.ag, a.am, a.bg, a.bm);
      if (!nt) throw new Error('bad trade');
      nt.c = 1; nt.w = tr.a; s.tr = nt; Q(s, ['N', seat, 1]);
    } else throw new Error('answer the trade');
  }
  const GSUM = GT.map((g) => g.reduce((a, i) => a + T[i].p, 0));
  function winsNow(s, seat) { return !!s.mo && (LINE.some((ln) => ln.every((k) => own(s, k) === seat)) || GT.filter((_, g) => hasSet(s, g, seat)).length >= 3); }
  function posVal(s, seat) { // rough position value: cash + buildings + set/monopoly potential
    let v = s.m[seat];
    owned(s, seat).forEach((i) => { v += invested(i, lvl(s, i)) * 0.9; });
    let sets = 0;
    GT.forEach((g, gi) => { const c = g.filter((i) => own(s, i) === seat).length; if (c === 3) { v += GSUM[gi] * 1.2 + 30; sets++; } else if (c === 2) v += GSUM[gi] * 0.3; });
    if (s.mo && sets === 2) v += 45;
    if (s.mo) LINE.forEach((ln) => { if (ln.filter((k) => own(s, k) === seat).length === 5) v += 45; });
    return v;
  }
  /* how good trade tr is for seat (positive = good), lv-dependent: monopoly value, cash needs, rank */
  function evalTrade(s, tr, seat, lv) {
    const o = seat === tr.a ? tr.b : tr.a;
    const c = { o: s.o, v: s.v, m: s.m.slice(), bk: s.bk, mo: s.mo, p: s.p, a: s.a, n: s.n, to: s.to, lm: s.lm, r: s.r };
    doTrade(c, tr);
    if (winsNow(c, seat)) return 1e6;
    if (winsNow(c, o)) return -1e6;
    const dMe = posVal(c, seat) - posVal(s, seat), dO = posVal(c, o) - posVal(s, o);
    let k = 0;
    if (lv === 2) k = 0.4;
    else if (lv >= 3) { const al = alive(s), best = al.reduce((x, i) => (worth(s, i) > worth(s, x) ? i : x), al[0]); k = best === o ? 1 : best === seat ? 0.45 : 0.65; }
    let g = dMe - k * dO;
    if (lv >= 2) { const res = reserve(s, seat, lv), before = Math.max(0, res - s.m[seat]), after = Math.max(0, res - c.m[seat]); g -= (after - before) * 0.7; }
    return g;
  }
  const TH = [0, 0, 4, 8];
  function aiAnswer(s, seat, lv) {
    const tr = s.tr, g = evalTrade(s, tr, seat, lv);
    if (lv === 1) return g > -10 + (Math.random() - 0.5) * 30 && g > -1e5 ? { t: 'tacc' } : { t: 'trej' };
    if (g >= TH[lv]) return { t: 'tacc' };
    if (!tr.c && seat === tr.b && g > -90) { // counter: ask the proposer for more cash
      const k = lv === 2 ? 1.4 : 1.6;
      let need = Math.ceil((TH[lv] - g) / k / 5) * 5 + 5;
      const nt = { a: tr.a, b: tr.b, ag: tr.ag, am: tr.am, bg: tr.bg, bm: tr.bm };
      const cut = Math.min(nt.bm, need); nt.bm -= cut; need -= cut;
      nt.am += need;
      if (nt.am <= s.m[tr.a] && (nt.ag.length || nt.am) && (nt.bg.length || nt.bm) && evalTrade(s, nt, seat, lv) >= TH[lv]) return { t: 'tctr', ag: nt.ag, am: nt.am, bg: nt.bg, bm: nt.bm };
    }
    return { t: 'trej' };
  }
  /* AI proposes a trade that completes one of its sets (rarely, with a cooldown) */
  function aiPropose(s, seat, lv) {
    if (lv < 2 || s.j[seat] || (s.tn || 0) > 0 || !s.tc || s.r - s.tc[seat] < 3 || Math.random() < 0.4) return null;
    const res = reserve(s, seat, lv);
    for (let g = 0; g < GT.length; g++) {
      const mine = GT[g].filter((i) => own(s, i) === seat);
      if (mine.length !== 2) continue;
      const i = GT[g].find((k) => own(s, k) !== seat), o = own(s, i);
      if (o < 0 || lvl(s, i) >= 4 || !s.a[o]) continue;
      const price = Math.ceil((invested(i, lvl(s, i)) * 1.35 + 15) / 5) * 5;
      let tr = null;
      if (s.m[seat] - price >= res * 0.7) tr = { a: seat, b: o, ag: [], am: price, bg: [i], bm: 0 };
      else { // sweeten with a lone city the other player may want
        const cnt = (j, who) => GT[T[j].g].filter((k) => own(s, k) === who).length;
        const lone = owned(s, seat).filter((j) => T[j].g !== g && cnt(j, seat) === 1 && lvl(s, j) < 3).sort((x, y) => cnt(y, o) - cnt(x, o));
        if (lone.length) { const j = lone[0], cash = Math.max(0, Math.min(s.m[seat] - res * 0.5, price - invested(j, lvl(s, j)))); tr = { a: seat, b: o, ag: [j], am: Math.floor(cash / 5) * 5, bg: [i], bm: 0 }; }
      }
      if (!tr || evalTrade(s, tr, seat, lv) < TH[lv]) continue;
      return { t: 'offer', to: o, og: tr.ag, om: tr.am, rg: tr.bg, rm: 0 };
    }
    return null;
  }

  function result(s) {
    if (!s.w) return null;
    const why = { last: '마지막까지 남았어요', line: '한 줄(라인)을 모두 차지했어요', triple: '색깔 세트 3개를 모았어요', cap: '턴이 끝나 자산이 가장 많아요' }[s.why] || '';
    const rank = Array.from({ length: s.n }, (_, i) => i).sort((a, b) => (s.a[b] - s.a[a]) || worth(s, b) - worth(s, a));
    const lines = rank.map((i) => (s.a[i] ? s.nm[i] + ' · 자산 ' + worth(s, i) + '만' : s.nm[i] + ' · 파산'));
    const ks = s.ks || s.m.map(() => [0, 0]);
    const lands = (i) => { let c = 0; for (let k = 0; k < N; k++) if (own(s, k) === i) c++; return c; };
    const stats = [{ label: '땅', values: s.m.map((_, i) => (s.a[i] ? lands(i) + '곳' : '파산')) }, { label: '총자산', values: s.m.map((_, i) => (s.a[i] ? worth(s, i) + '만' : '0')) },
      { label: '받은 통행료', values: ks.map((k) => k[0] + '만') }, { label: '낸 통행료', values: ks.map((k) => k[1] + '만') }];
    return {
      winners: s.w.slice(), stats,
      title: s.why === 'line' ? '라인 독점!' : s.why === 'triple' ? '트리플 독점!' : null,
      text: why + '\n' + lines.join('\n'),
    };
  }

  /* ---------- AI ---------- */
  const PD = [0, 0, 1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1].map((x) => x / 36);
  function oppMax(s, seat) { let m = 0; for (let i = 0; i < N; i++) { const ow = own(s, i); if (ow >= 0 && ow !== seat) m = Math.max(m, toll(s, i)); } return m; }
  function danger(s, seat, from) { // [expected toll, max toll] within one roll
    let e = 0, mx = 0;
    for (let d = 2; d <= 12; d++) {
      const i = (from + d) % N, ow = own(s, i);
      if (ow >= 0 && ow !== seat) { const t = toll(s, i); e += PD[d] * t; mx = Math.max(mx, t); }
    }
    return [e, mx];
  }
  // 성향: 공격형은 현금을 덜 남기고 사들이고, 수비형은 넉넉히 남기고, 도박형은 그때그때
  function reserve(s, seat, lv) {
    const sty = (L.aiStyle && L.aiStyle(seat)) || 'bal';
    const k = sty === 'agg' ? 0.6 : sty === 'def' ? 1.4 : sty === 'gamble' ? 0.3 + Math.random() * 1.2 : 1;
    return reserve0(s, seat, lv) * k;
  }
  function reserve0(s, seat, lv) {
    if (lv <= 1) return 0;
    const om = oppMax(s, seat);
    if (lv === 2) return NK.a + NK.c * om;
    const [, mx] = danger(s, seat, s.p[seat]);
    return HK.a + HK.b * mx + HK.c * om;
  }
  /* how much owning tile i is worth to seat beyond its toll (sets, blocking, monopolies) */
  const NK = { a: 25, c: 0.4, x: 15 };
  const HK = { a: 0, b: 0.3, c: 0, d: 0.5, e: 0.8, x: 0, u: 0.8, t1: 1, t2: 1.3 }; // 어려움 tuning (self-play vs 보통)
  function setValue(s, seat, i) {
    const g = T[i].g, mine = GT[g].filter((k) => own(s, k) === seat).length;
    const opp = {}; GT[g].forEach((k) => { const o = own(s, k); if (o >= 0 && o !== seat) opp[o] = (opp[o] || 0) + 1; });
    let v = 0;
    if (mine === 2) v += 3; else if (mine === 1) v += 1;
    if (Object.values(opp).some((c) => c === 2)) v += 1.5;
    if (s.mo) {
      const sets = GT.filter((_, gg) => hasSet(s, gg, seat)).length;
      if (mine === 2 && sets >= 2) v += 6; // a third set wins
      const ln = LINE[Math.floor(i / 8)], have = ln.filter((k) => own(s, k) === seat).length;
      if (have === 5) v += 8; else if (have >= 4) v += 1;
      // block an opponent's monopoly
      for (const o in opp) { const oh = ln.filter((k) => own(s, k) === +o).length; if (oh >= 4) v += 3; }
    }
    return v;
  }
  function winsIfOwned(s, seat, i) {
    if (!s.mo) return false;
    const o = s.o; s.o = s.o.slice(0, i) + seat + s.o.slice(i + 1);
    const w = LINE.some((ln) => ln.every((k) => own(s, k) === seat)) || GT.filter((_, g) => hasSet(s, g, seat)).length >= 3;
    s.o = o; return w;
  }
  function sellPick(s, seat, lv) {
    const mine = owned(s, seat);
    if (!mine.length) return -1;
    if (lv <= 1) return mine[Math.floor(Math.random() * mine.length)];
    const need = s.dt ? s.dt.a - s.m[seat] : 0;
    const keep = (i) => toll(s, i) + (hasSet(s, T[i].g, seat) ? 40 : 0) + (lv >= 3 ? setValue(s, seat, i) * 5 : 0);
    if (lv >= 3) { // one sale that covers the debt and loses the least
      const cover = mine.filter((i) => sellVal(s, i) >= need).sort((a, b) => keep(a) - keep(b));
      if (cover.length) return cover[0];
    }
    return mine.sort((a, b) => keep(a) / (sellVal(s, a) + 1) - keep(b) / (sellVal(s, b) + 1))[0];
  }
  function travelPick(s, seat, lv) {
    const cands = []; for (let i = 0; i < N; i++) if (i !== TRAVEL) cands.push(i);
    if (lv <= 1) return cands[Math.floor(Math.random() * cands.length)];
    const res = reserve(s, seat, lv);
    let best = 0, bv = -1e9;
    for (const i of cands) {
      const tl = T[i]; let v = i < TRAVEL ? SAL : 0, m = s.m[seat] + v;
      if (tl.k === 'c') {
        const ow = own(s, i);
        if (ow < 0) v += m - tl.p >= res * 0.6 ? tl.p * 0.6 + (lv >= 3 ? setValue(s, seat, i) * 10 + (winsIfOwned(s, seat, i) ? 500 : 0) : 0) : -2;
        else if (ow === seat) v += canUp(s, seat, i) ? 8 + T[i].p * 0.3 : 0;
        else v -= toll(s, i) * 1.2 - (lv >= 3 && s.to && m - toll(s, i) >= takeCost(s, i) + res && setValue(s, seat, i) >= 3 ? 30 : 0);
      } else if (tl.k === 'k') v += 4;
      else if (tl.k === 'd') v -= DON;
      else if (tl.k === 'j') v -= lv >= 3 && oppMax(s, seat) > s.m[seat] * 0.5 ? -5 : 12;
      if (v > bv) { bv = v; best = i; }
    }
    return best;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.tr) return aiAnswer(s, seat, lv);
    const i = s.p[seat], m = s.m[seat], noise = lv === 1 ? Math.random() : 0;
    switch (s.ph) {
      case 'R': {
        const pr = aiPropose(s, seat, lv); if (pr) return pr;
        if (s.j[seat]) {
          const res = reserve(s, seat, lv);
          if (lv === 1) return m >= JF ? { t: 'pay' } : { t: 'roll' };
          const wantOut = lv === 2 ? s.r < 20 : oppMax(s, seat) < m * 0.45 && s.r < 25;
          if (wantOut && s.k[seat]) return { t: 'card' };
          if (wantOut && m - JF >= res) return { t: 'pay' };
          return { t: 'roll' };
        }
        return { t: 'roll' };
      }
      case 'V': return { t: 'tv', to: travelPick(s, seat, lv) };
      case 'B': {
        if (winsIfOwned(s, seat, i)) return { t: 'buy', lv: 0 };
        const res = reserve(s, seat, lv);
        if (lv === 1) { for (let k = 2; k >= 0; k--) if (invested(i, k) <= m) return { t: 'buy', lv: k }; return { t: 'pass' }; }
        let need = res;
        if (lv >= 3) { const sv = setValue(s, seat, i); need = res * (sv >= 3 ? HK.d : sv >= 1 ? HK.e : 1); }
        if (m - invested(i, 0) < need) return { t: 'pass' };
        const extra = lv >= 3 && hasSetAfter(s, seat, i) ? 0 : lv >= 3 ? HK.x : NK.x;
        for (let k = 2; k >= 1; k--) if (m - invested(i, k) >= need + extra) return { t: 'buy', lv: k };
        return { t: 'buy', lv: 0 };
      }
      case 'U': {
        const opts = upOpts(s, i).filter((k) => upCost(i, lvl(s, i), k) <= m);
        if (lv === 1) return { t: 'up', lv: opts[opts.length - 1] };
        const res = reserve(s, seat, lv) * (lv >= 3 && hasSet(s, T[i].g, seat) ? HK.u : 1);
        for (let k = opts.length - 1; k >= 0; k--) if (m - upCost(i, lvl(s, i), opts[k]) >= res) return { t: 'up', lv: opts[k] };
        return { t: 'pass' };
      }
      case 'X': {
        const c = takeCost(s, i);
        if (winsIfOwned(s, seat, i)) return { t: 'take' };
        if (lv === 1) return { t: 'take' };
        const res = reserve(s, seat, lv);
        if (lv === 2) return (hasSetAfter(s, seat, i) && m - c >= res) || m - c >= res * 2.5 + 60 ? { t: 'take' } : { t: 'pass' };
        const sv = setValue(s, seat, i);
        return sv >= 3 && m - c >= res * HK.t1 ? { t: 'take' } : { t: 'pass' }; // only when it completes/blocks a set or a monopoly
      }
      case 'D': return lv === 2 ? { t: 'auto' } : { t: 'sell', i: sellPick(s, seat, lv) };
    }
    return null;
  }
  function hasSetAfter(s, seat, i) { return GT[T[i].g].every((k) => k === i || own(s, k) === seat); }
  function aiDelayFor(s, seat, lv) { return s.ph === 'R' && !s.j[seat] ? 380 : lv === 1 ? 650 : lv === 3 ? 380 : 500; }

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root);
    const ctx = cv.ctx;
    const h = L.h, SP = () => L.debug.speed || 1;
    let st = null, D = null, G = null, boardImg = null, boardKey = '';
    let run = null, wd = 0, busy = false, pending = false, time = 0, sel = -1;
    let dice = [5, 2], diceT = -1, card = null, msg = null, floats = [], pops = [];
    const toastQ = []; let toastT = 0;
    const setBusy = (b) => { busy = b; api.setBusy(b); };
    const fmt = (v) => v + '만';
    const nm = (i) => (api.players[i] ? api.players[i].name : 'P' + (i + 1));
    const col = (i) => (api.players[i] ? api.players[i].color : '#999');

    /* ---- DOM ---- */
    const top = h('div', { class: 'hud top lg-top', style: { gap: '5px', flexWrap: 'nowrap', padding: '6px 8px', alignItems: 'stretch' } });
    const hint = h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, minHeight: '48px', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', fontWeight: 700, padding: '6px 10px', lineHeight: 1.25 } });
    const btns = h('div', { style: { display: 'flex', gap: '6px', flex: 'none' } });
    const bar = h('div', { class: 'hud bottom lg-bar', style: { flexWrap: 'nowrap', gap: '8px', padding: '6px 8px 10px', alignItems: 'stretch' } }, hint, btns);
    const sheet = h('div', { class: 'panel', style: { position: 'absolute', left: '8px', right: '8px', bottom: '8px', zIndex: 5, display: 'none', flexDirection: 'column', gap: '8px', padding: '10px 12px 12px', borderRadius: '16px', maxHeight: '62%', overflowY: 'auto', boxShadow: '0 -8px 30px rgba(0,0,0,.45)' } });
    // tutorial spotlight targets (invisible): the whole board, and the 출발 corner with the first cities
    const boardMark = h('div', { class: 'lg-board', style: { position: 'absolute', pointerEvents: 'none' } });
    const startMark = h('div', { class: 'lg-start', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(boardMark, startMark, top, bar, sheet);

    function act(a) {
      if (pending || run || !st || !api.canAct(st.tr ? st.tr.w : st.t)) return;
      pending = true; api.sfx('click'); api.buzz(12);
      api.act(a);
      setTimeout(() => { if (pending) { pending = false; refresh(); } }, 3000);
      refresh();
    }
    const mine = () => st && !st.w && !st.tr && !run && !pending && api.canAct(st.t);

    /* ---- geometry ---- */
    function layout() {
      const W = cv.w, H = cv.h, topH = 60, botH = 70;
      const S = Math.max(220, Math.min(W - 8, H - topH - botH - 8, 620));
      const free = H - topH - botH - S, bx = Math.round((W - S) / 2), by = Math.round(topH + Math.max(0, Math.min(free / 2, free - 110)));
      G = { W, H, S, bx, by, c: S / 10 };
      Object.assign(boardMark.style, { left: bx + 'px', top: by + 'px', width: S + 'px', height: S + 'px' });
      Object.assign(startMark.style, { left: (bx + S * 0.55) + 'px', top: (by + S * 0.85) + 'px', width: (S * 0.45) + 'px', height: (S * 0.15) + 'px' });
      boardKey = '';
    }
    function rect(i) { // tile rect in board coords + side (0 bottom, 1 left, 2 top, 3 right)
      const S = G.S, c = G.c, k = 1.5 * c, sd = Math.floor(i / 8), j = i % 8;
      if (j === 0) return [[S - k, S - k], [0, S - k], [0, 0], [S - k, 0]][sd].concat([k, k, sd, 1]);
      if (sd === 0) return [S - k - j * c, S - k, c, k, 0, 0];
      if (sd === 1) return [0, S - k - j * c, k, c, 1, 0];
      if (sd === 2) return [k + (j - 1) * c, 0, c, k, 2, 0];
      return [S - k, k + (j - 1) * c, k, c, 3, 0];
    }
    function center(i) { const r = rect(i); return { x: G.bx + r[0] + r[2] / 2, y: G.by + r[1] + r[3] / 2 }; }
    function spot(i) { // where tokens stand: on the inner edge of the tile so names and tolls stay readable
      const r = rect(i), c = center(i), k = G.c * 1.02;
      if (r[5]) { const sx = i === 0 || i === 24 ? -1 : 1, sy = i === 0 || i === 8 ? -1 : 1; return { x: c.x + sx * k * 0.62, y: c.y + sy * k * 0.62 }; }
      return [{ x: c.x, y: c.y - k }, { x: c.x + k, y: c.y }, { x: c.x, y: c.y + k }, { x: c.x - k, y: c.y }][r[4]];
    }
    function tileAt(x, y) {
      x -= G.bx; y -= G.by;
      for (let i = 0; i < N; i++) { const r = rect(i); if (x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]) return i; }
      return -1;
    }
    function rr(c, x, y, w, hh, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, hh, r); else c.rect(x, y, w, hh); }
    function shade(hex, amt) {
      const n = parseInt(hex.slice(1), 16);
      const r = U.clamp((n >> 16) + amt, 0, 255), g = U.clamp(((n >> 8) & 255) + amt, 0, 255), b = U.clamp((n & 255) + amt, 0, 255);
      return 'rgb(' + r + ',' + g + ',' + b + ')';
    }
    const FONT = (w, px, fam) => w + ' ' + px + 'px ' + (fam || '"IBM Plex Sans KR", system-ui, sans-serif');

    /* ---- board image (re-rendered when ownership changes) ---- */
    function buildBoard() {
      const key = D.o + D.v + G.S;
      if (key === boardKey && boardImg) return;
      boardKey = key;
      const S = G.S, c = G.c, pad = 6, size = S + pad * 2;
      const cvs = boardImg && boardImg.c.width === Math.round(size * cv.dpr) ? boardImg.c : document.createElement('canvas');
      cvs.width = Math.round(size * cv.dpr); cvs.height = Math.round(size * cv.dpr);
      const b = cvs.getContext('2d');
      b.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      b.translate(pad, pad);
      b.fillStyle = 'rgba(0,0,0,.5)'; rr(b, 2, 6, S, S, 10); b.fill();
      // frame + felt centre
      const fg = b.createLinearGradient(0, 0, S, S); fg.addColorStop(0, '#3a2a1c'); fg.addColorStop(1, '#22170f');
      b.fillStyle = fg; rr(b, 0, 0, S, S, 10); b.fill();
      const k = 1.5 * c;
      const cg = b.createRadialGradient(S / 2, S / 2, S * 0.05, S / 2, S / 2, S * 0.5);
      cg.addColorStop(0, '#1f6e57'); cg.addColorStop(1, '#0f4334');
      b.fillStyle = cg; b.fillRect(k, k, S - 2 * k, S - 2 * k);
      const R = rng(11);
      for (let q = 0; q < 700; q++) { b.fillStyle = R() < 0.5 ? 'rgba(0,0,0,.08)' : 'rgba(255,255,255,.05)'; b.fillRect(k + R() * (S - 2 * k), k + R() * (S - 2 * k), 1.2, 1.2); }
      // compass rose watermark
      b.save(); b.translate(S / 2, S / 2); b.strokeStyle = 'rgba(227,174,69,.13)'; b.lineWidth = 2;
      b.beginPath(); b.arc(0, 0, S * 0.27, 0, 7); b.stroke(); b.beginPath(); b.arc(0, 0, S * 0.2, 0, 7); b.stroke();
      for (let q = 0; q < 8; q++) { const a = q * Math.PI / 4, l = q % 2 ? S * 0.2 : S * 0.31; b.beginPath(); b.moveTo(0, 0); b.lineTo(Math.cos(a) * l, Math.sin(a) * l); b.stroke(); }
      b.restore();
      for (let i = 0; i < N; i++) drawTile(b, i);
      b.strokeStyle = '#e3ae45'; b.lineWidth = 1.5; rr(b, 0.75, 0.75, S - 1.5, S - 1.5, 10); b.stroke();
      b.strokeStyle = 'rgba(227,174,69,.55)'; b.lineWidth = 1; b.strokeRect(k, k, S - 2 * k, S - 2 * k);
      boardImg = { c: cvs, size, pad };
    }
    function fitText(b, t, maxW, px, weight, fam) {
      let p = px; b.font = FONT(weight, p, fam);
      while (p > 7 && b.measureText(t).width > maxW) { p -= 0.5; b.font = FONT(weight, p, fam); }
      return p;
    }
    function drawTile(b, i) {
      const [x, y, w, hh, sd, corner] = rect(i), tl = T[i], c = G.c, ins = 1;
      b.save(); b.translate(x, y);
      b.fillStyle = '#efe5cf'; b.fillRect(ins, ins, w - 2 * ins, hh - 2 * ins);
      b.fillStyle = 'rgba(120,90,50,.08)'; b.fillRect(ins, hh * 0.6, w - 2 * ins, hh * 0.4 - ins);
      b.fillStyle = '#2a1d12'; b.textAlign = 'center'; b.textBaseline = 'middle';
      if (tl.k === 'c') {
        const ow = own(D, i), lv = lvl(D, i), band = Math.round(c * 0.36);
        // band on the inner edge
        let bx = 0, by = 0, bw = w, bh = band;
        if (sd === 0) { by = 0; } else if (sd === 2) { by = hh - band; } else if (sd === 1) { bx = w - band; bw = band; bh = hh; } else { bx = 0; bw = band; bh = hh; }
        if (ow >= 0) { b.fillStyle = col(ow); b.globalAlpha = 0.3; b.fillRect(ins, ins, w - 2 * ins, hh - 2 * ins); b.globalAlpha = 1; }
        b.fillStyle = GC[tl.g]; b.fillRect(bx + ins, by + ins, bw - 2 * ins, bh - 2 * ins);
        // buildings in the band
        if (lv > 0) {
          const vert = sd === 1 || sd === 3, n = 1, cx = bx + bw / 2, cy = by + bh / 2;
          for (let q = 0; q < n; q++) {
            const off = (q - (n - 1) / 2) * band * 0.85;
            const px = cx + (vert ? 0 : off), py = cy + (vert ? off : 0);
            building(b, px, py, band * 0.5, lv);
          }
        }
        // text area
        let tx = x, ty = y; const ax = sd === 1 ? 0 : sd === 3 ? band : 0, ay = sd === 0 ? band : 0;
        const aw = sd === 1 || sd === 3 ? w - band : w, ah = sd === 0 || sd === 2 ? hh - band : hh;
        const npx = Math.min(11, c * 0.29), nmS = tl.n, two = nmS.length >= 4 && fitText(b, nmS, aw - 3, npx, '700') < Math.min(8.5, npx * 0.8);
        b.fillStyle = '#2a1d12';
        if (two) {
          const p = fitText(b, nmS.slice(0, 2), aw - 4, Math.min(npx, ah * 0.27), '700');
          b.fillText(nmS.slice(0, 2), ax + aw / 2, ay + ah * 0.06 + p * 0.6); b.fillText(nmS.slice(2), ax + aw / 2, ay + ah * 0.06 + p * 1.65);
        } else { fitText(b, nmS, aw - 3, npx, '700'); b.fillText(nmS, ax + aw / 2, ay + ah * (sd === 1 || sd === 3 ? 0.36 : 0.38)); }
        const val = ow >= 0 ? toll(D, i) : tl.p;
        b.font = FONT('700', Math.min(10.5, c * 0.27), '"IBM Plex Mono", monospace');
        b.fillStyle = ow >= 0 ? shade(col(ow), -90) : '#6e5a44';
        b.fillText(String(val), ax + aw / 2, ay + ah * (two ? 0.84 : sd === 1 || sd === 3 ? 0.74 : 0.8));
        if (ow >= 0) { b.strokeStyle = col(ow); b.lineWidth = 2; b.strokeRect(ins + 1, ins + 1, w - 2 * ins - 2, hh - 2 * ins - 2); }
      } else if (tl.k === 'k') {
        const cx = w / 2, cy = hh * 0.42, cw = Math.min(w, hh) * 0.42;
        b.save(); b.translate(cx, cy); b.rotate(-0.12);
        b.fillStyle = '#e3ae45'; rr(b, -cw / 2, -cw * 0.65, cw, cw * 1.3, 3); b.fill();
        b.strokeStyle = '#7a5310'; b.lineWidth = 1.2; b.stroke();
        b.fillStyle = '#5a3a08'; b.font = FONT('700', cw * 0.8, '"Black Han Sans", sans-serif'); b.fillText('?', 0, 1);
        b.restore();
        b.fillStyle = '#7a5310'; fitText(b, '행운 카드', w - 4, Math.min(9.5, c * 0.25), '700'); b.fillText('행운 카드', w / 2, hh * 0.84);
      } else {
        // corners
        const cx = w / 2, cy = h2 => hh * h2, s = w;
        const C = { s: ['#c8432f', '출발'], j: ['#2f7d8c', '무인도'], v: ['#3d5fc6', '세계 여행'], d: ['#8c4a9e', '기부'] }[tl.k];
        b.fillStyle = C[0]; b.globalAlpha = 0.16; b.fillRect(ins, ins, w - 2 * ins, hh - 2 * ins); b.globalAlpha = 1;
        b.strokeStyle = C[0]; b.fillStyle = C[0]; b.lineWidth = Math.max(2, s * 0.05); b.lineCap = 'round'; b.lineJoin = 'round';
        const ic = s * 0.17, iy = cy(0.33);
        if (tl.k === 's') { b.beginPath(); b.moveTo(cx + ic, iy); b.lineTo(cx - ic, iy); b.moveTo(cx - ic + ic * 0.6, iy - ic * 0.6); b.lineTo(cx - ic, iy); b.lineTo(cx - ic + ic * 0.6, iy + ic * 0.6); b.stroke(); }
        if (tl.k === 'j') { b.beginPath(); b.ellipse(cx, iy + ic * 0.8, ic * 1.2, ic * 0.35, 0, 0, 7); b.fill(); b.beginPath(); b.moveTo(cx, iy + ic * 0.6); b.quadraticCurveTo(cx + ic * 0.2, iy - ic * 0.2, cx - ic * 0.1, iy - ic * 0.8); b.stroke(); for (const a of [-2.6, -1.9, -1.2, -0.5]) { b.beginPath(); b.moveTo(cx - ic * 0.1, iy - ic * 0.8); b.quadraticCurveTo(cx + Math.cos(a) * ic * 0.6, iy - ic * 0.8 + Math.sin(a) * ic * 0.6 - ic * 0.2, cx + Math.cos(a) * ic, iy - ic * 0.8 - Math.sin(a) * -ic * 0.5); b.stroke(); } }
        if (tl.k === 'v') { b.beginPath(); b.arc(cx, iy, ic, 0, 7); b.stroke(); b.beginPath(); b.ellipse(cx, iy, ic * 0.45, ic, 0, 0, 7); b.stroke(); b.beginPath(); b.moveTo(cx - ic, iy); b.lineTo(cx + ic, iy); b.stroke(); }
        if (tl.k === 'd') { b.beginPath(); b.moveTo(cx, iy + ic * 0.9); b.bezierCurveTo(cx - ic * 1.4, iy - ic * 0.1, cx - ic * 0.6, iy - ic * 1.2, cx, iy - ic * 0.4); b.bezierCurveTo(cx + ic * 0.6, iy - ic * 1.2, cx + ic * 1.4, iy - ic * 0.1, cx, iy + ic * 0.9); b.fill(); }
        b.fillStyle = shade(C[0], -40); fitText(b, C[1], w - 6, Math.min(13, c * 0.33), '400', '"Black Han Sans", "IBM Plex Sans KR", sans-serif');
        b.fillText(C[1], cx, cy(0.66));
        fitText(b, 'x', w, Math.min(9, c * 0.22), '700', '"IBM Plex Mono", monospace'); b.fillStyle = 'rgba(42,29,18,.7)';
        const sub = { s: '+' + SAL + '만', j: '탈출 ' + JF + '만', v: '어디든', d: DON + '만' }[tl.k];
        fitText(b, sub, w - 6, Math.min(9, c * 0.22), '700', '"IBM Plex Mono", monospace'); b.fillText(sub, cx, cy(0.86));
      }
      b.strokeStyle = 'rgba(60,40,20,.55)'; b.lineWidth = 1; b.strokeRect(0.5, 0.5, w - 1, hh - 1);
      b.restore();
    }
    function building(b, x, y, r, lv) {
      b.save(); b.translate(x, y);
      b.fillStyle = lv === 4 ? '#ffd76a' : '#fff8e6'; b.strokeStyle = 'rgba(30,20,10,.85)'; b.lineWidth = 1;
      const win = (x0, y0, w0, h0) => { b.fillStyle = '#4a6a8a'; b.fillRect(x0, y0, w0, h0); };
      if (lv === 1) { // cottage: pitched roof + door
        b.beginPath(); b.moveTo(-r * 0.8, r); b.lineTo(-r * 0.8, -r * 0.05); b.lineTo(r * 0.8, -r * 0.05); b.lineTo(r * 0.8, r); b.closePath(); b.fill(); b.stroke();
        b.fillStyle = '#b8462e'; b.beginPath(); b.moveTo(-r * 1.05, 0); b.lineTo(0, -r * 1.05); b.lineTo(r * 1.05, 0); b.closePath(); b.fill(); b.stroke();
        b.fillStyle = '#6a4424'; b.fillRect(-r * 0.22, r * 0.35, r * 0.44, r * 0.65);
      } else if (lv === 2) { // tower block: tall with window rows
        b.fillRect(-r * 0.62, -r * 1.05, r * 1.24, r * 2.05); b.strokeRect(-r * 0.62, -r * 1.05, r * 1.24, r * 2.05);
        for (let q = 0; q < 3; q++) { win(-r * 0.4, -r * 0.8 + q * r * 0.6, r * 0.28, r * 0.3); win(r * 0.12, -r * 0.8 + q * r * 0.6, r * 0.28, r * 0.3); }
      } else if (lv === 3) { // grand hotel: wide body, red cornice, flag
        b.fillRect(-r * 1.05, -r * 0.7, r * 2.1, r * 1.7); b.strokeRect(-r * 1.05, -r * 0.7, r * 2.1, r * 1.7);
        b.fillStyle = '#c8432f'; b.fillRect(-r * 1.15, -r * 0.95, r * 2.3, r * 0.36); b.strokeRect(-r * 1.15, -r * 0.95, r * 2.3, r * 0.36);
        for (let q = 0; q < 3; q++) win(-r * 0.8 + q * r * 0.6, -r * 0.35, r * 0.35, r * 0.35);
        b.fillStyle = '#6a4424'; b.fillRect(-r * 0.2, r * 0.3, r * 0.4, r * 0.7);
      } else { b.beginPath(); for (let q = 0; q < 10; q++) { const a = -Math.PI / 2 + q * Math.PI / 5, rr2 = q % 2 ? r * 0.55 : r * 1.35; b.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); } b.closePath(); b.fill(); b.stroke(); }
      b.restore();
    }
    function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

    /* ---- display model ---- */
    function snap(s) { D = s ? JSON.parse(JSON.stringify({ o: s.o, v: s.v, p: s.p, m: s.m, a: s.a, j: s.j, r: s.r, R: s.R, mo: s.mo, n: s.n })) : null; D && (D.pos = D.p.map((i) => { const c = spot(i); return [c.x, c.y]; })); }
    const tokPos = (seat) => (D && D.pos && D.pos[seat]) || [0, 0];

    /* ---- animation runner ---- */
    function start(next, prev) {
      if (run) finishRun(true);
      snap(prev);
      run = { q: next.last.q.slice(), k: -1, t: 0, dur: 0, op: null, seat: next.last.s };
      setBusy(true);
      clearTimeout(wd);
      wd = setTimeout(() => finishRun(), 12000 / SP() + 2000);
      nextOp();
    }
    function nextOp() {
      for (;;) {
        run.k++;
        if (run.k >= run.q.length) return finishRun();
        const op = run.q[run.k];
        run.op = op; run.t = 0; run.dur = beginOp(op);
        if (run.dur > 0) return;
      }
    }
    const HOP = 0.13;
    function beginOp(op) {
      const sp = SP();
      switch (op[0]) {
        case 'd': diceT = 0; dice = [op[1], op[2]]; api.sfx('roll'); api.buzz(12); return 0.62 / sp;
        case 'w': case 'b': run.path = []; for (let k = 1; k <= op[3]; k++) run.path.push((op[2] + (op[0] === 'w' ? k : -k) + N * 4) % N); run.from = op[2]; run.hop = 0; return op[3] * HOP / sp;
        case 'j': run.path = [op[3]]; run.from = op[2]; run.hop = 0; api.sfx('whoosh'); return 0.45 / sp;
        case '$': {
          const [, f, t, a, y] = op;
          if (f >= 0) { D.m[f] -= a; floatAt(f, '−' + fmt(a), '#ff8a75'); }
          if (t >= 0) { D.m[t] += a; floatAt(t, '+' + fmt(a), '#7fe0a8'); }
          if (y === 't') { api.sfx('chip'); api.buzz(25); say(nm(f) + ' → ' + nm(t) + ' 통행료 ' + fmt(a), true); }
          else if (y === 's') { api.sfx('chip'); say(nm(t) + ' 출발 통과 · 월급 +' + fmt(a)); }
          else if (y === 'k') { api.sfx('chip'); }
          else api.sfx('chip');
          refreshTop();
          return (y === 't' ? 0.5 : 0.22) / sp;
        }
        case 'B': { const [, s2, i, lv] = op; setT(D, i, s2, lv); pops.push({ i, t: 0, col: col(s2) }); api.sfx('pop'); api.buzz(10); say(nm(s2) + ' · ' + T[i].n + ' ' + (lv === 0 ? '구매' : TIER[lv] + ' 건설')); refreshTop(); return 0.32 / sp; }
        case 'K': { const [, s2, i, o] = op; setT(D, i, s2, lvl(D, i)); pops.push({ i, t: 0, col: col(s2) }); api.sfx('hit'); api.buzz(30); say(nm(s2) + '이(가) ' + nm(o) + '의 ' + T[i].n + ' 인수!', true); refreshTop(); return 0.5 / sp; }
        case 'X': { const [, s2, i] = op; setT(D, i, -1, 0); api.sfx('card'); say(nm(s2) + ' · ' + T[i].n + ' 매각'); refreshTop(); return 0.3 / sp; }
        case 'c': card = { c: op[1], t: 0 }; api.sfx('card'); api.buzz(10); return 1.15 / sp;
        case 'J': api.sfx('thud'); api.buzz(30); say(nm(op[1]) + ' 무인도에 갇혔어요', true); D.j[op[1]] = 3; refreshTop(); return 0.35 / sp;
        case 'E': D.j[op[1]] = 0; say(nm(op[1]) + ' 무인도 탈출' + ['', ' (더블!)', ' (20만 냄)', ' (탈출권)'][op[2]]); refreshTop(); return 0.2 / sp;
        case 'S': D.j[op[1]] = op[2]; say(nm(op[1]) + ' 무인도 · ' + op[2] + '턴 남음'); refreshTop(); return 0.3 / sp;
        case 'V': api.sfx('whoosh'); say(nm(op[1]) + ' 다음 차례에 원하는 곳으로 여행'); return 0.3 / sp;
        case 'C': say(nm(op[1]) + ' 할인 쿠폰 사용 · 통행료 반값'); return 0.2 / sp;
        case 'Z': D.a[op[1]] = 0; D.m[op[1]] = 0; owned(D, op[1]).forEach((i) => setT(D, i, -1, 0)); if (op[2] >= 0 && op[3] > 0) { D.m[op[2]] += op[3]; floatAt(op[2], '+' + fmt(op[3]), '#7fe0a8'); } api.sfx('lose'); api.buzz(60); say(nm(op[1]) + ' 파산!', true); refreshTop(); return 0.7 / sp;
        case 'R': {
          const [, a, b2, ag, am, bg, bm] = op;
          ag.forEach((i) => { setT(D, i, b2, lvl(D, i)); pops.push({ i, t: 0, col: col(b2) }); });
          bg.forEach((i) => { setT(D, i, a, lvl(D, i)); pops.push({ i, t: 0, col: col(a) }); });
          if (am) { D.m[a] -= am; D.m[b2] += am; floatAt(a, '−' + fmt(am), '#ff8a75'); floatAt(b2, '+' + fmt(am), '#7fe0a8'); }
          if (bm) { D.m[b2] -= bm; D.m[a] += bm; floatAt(b2, '−' + fmt(bm), '#ff8a75'); floatAt(a, '+' + fmt(bm), '#7fe0a8'); }
          api.sfx('chip'); api.buzz(20); say(nm(a) + ' ↔ ' + nm(b2) + ' 거래 성사!', true); refreshTop(); return 0.6 / sp;
        }
        case 'N': say(nm(op[1]) + ([': 거래 거절', ': 역제안을 보냈어요', ' · 거래 무산(조건이 바뀌었어요)'][op[2]]), op[2] !== 1); api.sfx(op[2] === 1 ? 'card' : 'click'); return 0.25 / sp;
        case 'W': api.sfx('win'); say(nm(op[1]) + (op[2] === 'line' ? ' 라인 독점!' : ' 트리플 독점!'), true); return 0.5 / sp;
      }
      return 0;
    }
    function stepRun(dt) {
      if (!run || !run.op) return;
      run.t += dt;
      const op = run.op;
      if ((op[0] === 'w' || op[0] === 'b') && run.path.length) {
        const per = HOP / SP(), k = Math.min(run.path.length - 1, Math.floor(run.t / per));
        while (run.hop <= k) { const to = run.path[run.hop]; D.p[op[1]] = to; run.hop++; api.sfx('tick'); }
        const f = Math.min(1, (run.t - k * per) / per), a = spot(k === 0 ? run.from : run.path[k - 1]), b = spot(run.path[k]);
        D.pos[op[1]] = [U.lerp(a.x, b.x, f), U.lerp(a.y, b.y, f) - Math.sin(f * Math.PI) * G.c * 0.45];
      } else if (op[0] === 'j') {
        const f = Math.min(1, run.t / run.dur), a = spot(run.from), b = spot(op[3]);
        D.pos[op[1]] = [U.lerp(a.x, b.x, f), U.lerp(a.y, b.y, f) - Math.sin(f * Math.PI) * G.S * 0.25];
        if (f >= 1) D.p[op[1]] = op[3];
      }
      if (run.t >= run.dur) {
        if (op[0] === 'w' || op[0] === 'b' || op[0] === 'j') { const to = op[0] === 'j' ? op[3] : run.path[run.path.length - 1]; D.p[op[1]] = to; const c = spot(to); D.pos[op[1]] = [c.x, c.y]; api.sfx('thud'); }
        if (op[0] === 'c') card = null;
        nextOp();
      }
    }
    function finishRun(silent) {
      if (!run) return;
      run = null; clearTimeout(wd); card = null; diceT = diceT >= 0 ? 99 : diceT;
      snap(st);
      setBusy(false);
      refresh();
    }
    function floatAt(seat, text, color) {
      const p = tokPos(seat);
      floats.push({ x: p[0], y: p[1] - G.c * 0.5, text, color, t: 0 });
      const el = top.querySelector('[data-seat="' + seat + '"]');
      if (el) { el.animate && el.animate([{ transform: 'scale(1.06)' }, { transform: 'scale(1)' }], { duration: 260 }); }
    }
    function say(text, big) {
      msg = { text, t: 0 };
      if (big) { toastQ.push(text); }
    }

    /* ---- HUD ---- */
    function refreshTop() {
      top.innerHTML = '';
      const s = D || st; if (!s) return;
      const cur = run ? run.seat : st && !st.w ? st.t : -1;
      for (let i = 0; i < s.n; i++) {
        const on = cur === i, dead = !s.a[i];
        const nTiles = owned(s, i).length;
        top.append(h('button', { 'data-seat': i, class: 'panel', 'aria-label': nm(i) + ' 땅 목록', onclick: () => playerSheet(i), style: {
          flex: '1 1 0', minWidth: 0, padding: '5px 7px', display: 'flex', flexDirection: 'column', gap: '2px', textAlign: 'left', color: 'var(--ink)', cursor: 'pointer',
          opacity: dead ? 0.4 : on || cur < 0 ? 1 : 0.72, borderColor: on ? col(i) : '', boxShadow: on ? '0 0 0 1.5px ' + col(i) + ' inset' : '', minHeight: '48px', font: 'inherit' } },
          h('div', { style: { display: 'flex', alignItems: 'center', gap: '4px', fontSize: '11.5px', fontWeight: 700, minWidth: 0, width: '100%' } },
            h('span', { class: 'dot', style: { '--c': col(i), flex: 'none' } }),
            h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: '1 1 auto', minWidth: 0 }, text: nm(i) }),
            s.j[i] && !dead ? h('span', { style: { flex: 'none', fontSize: '10px', color: '#7fd0de' }, text: '섬' + s.j[i] }) : null),
          h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '4px', justifyContent: 'space-between', width: '100%' } },
            h('b', { class: 'mono', style: { fontSize: s.n > 3 ? '13px' : '15px', color: dead ? 'var(--muted)' : 'var(--brass)' }, text: dead ? '파산' : String(s.m[i]) }),
            h('span', { class: 'mono', style: { fontSize: '10.5px', color: 'var(--muted)', flex: 'none' }, text: dead ? '' : '땅' + nTiles }))));
      }
    }
    function button(text, sub, onclick, opts) {
      opts = opts || {};
      return h('button', { class: 'btn' + (opts.primary ? ' primary' : '') + (opts.ghost ? ' ghost' : ''), 'data-action': opts.act || null, disabled: opts.disabled || null, onclick, style: { flexDirection: 'column', gap: '1px', padding: '6px 12px', minHeight: '48px', lineHeight: 1.15, flex: opts.flex || 'none', minWidth: opts.minW || '0' } },
        h('span', { style: { fontSize: '14px' }, text }), sub ? h('span', { class: 'mono', style: { fontSize: '11px', fontWeight: 500, opacity: 0.85 }, text: sub }) : null);
    }
    function refresh() {
      refreshTop();
      hint.innerHTML = ''; btns.innerHTML = ''; sheet.style.display = 'none'; sheet.innerHTML = '';
      bar.style.display = '';
      if (!st) return;
      const seat = st.t, me = mine(), p = st.m[seat];
      let text, c2 = 'var(--ink)';
      if (st.w) text = '경기 끝';
      else if (st.tr && !run) {
        const tr = st.tr;
        if (api.canAct(tr.w) && !pending) { tradeAnswerSheet(); return; }
        text = nm(tr.w) + (tr.c ? ' · 역제안 검토 중' : ' · 거래 제안 검토 중'); c2 = 'var(--muted)';
        btns.append(button('제안 보기', null, () => tradeView(), {}));
      }
      else if (run) text = nm(run.seat) + ' 진행 중…';
      else if (!api.canAct(seat)) { text = nm(seat) + ' ' + ({ R: '주사위 차례', V: '여행지 고르는 중', B: '땅 살지 고민 중', U: '건설 고민 중', X: '인수 고민 중', D: '빚 정리 중' }[st.ph] || ''); c2 = 'var(--muted)'; }
      else if (pending) text = '…';
      else if (st.ph === 'R') {
        if (st.j[seat]) {
          text = '무인도 ' + st.j[seat] + '턴 남음 · 더블이면 탈출';
          btns.append(button('굴리기', '더블 노리기', () => act({ t: 'roll' }), { primary: true, act: 'roll' }));
          if (st.k[seat]) btns.append(button('탈출권', '보유 ' + st.k[seat], () => act({ t: 'card' })));
          else btns.append(button('탈출', JF + '만', () => act({ t: 'pay' }), { disabled: p < JF }));
        } else {
          text = st.dbl ? '더블! 한 번 더 굴려요' : '주사위를 굴리세요';
          btns.append(button('주사위 굴리기', null, () => act({ t: 'roll' }), { primary: true, minW: '110px', act: 'roll' }));
        }
        if ((st.tn || 0) < TMAX && others(st, seat).length) btns.prepend(button('거래', (TMAX - (st.tn || 0)) + '회', () => tradeCompose(seat, null, null), { act: 'trade' }));
      } else if (st.ph === 'V') {
        text = sel >= 0 ? T[sel].n + '(으)로 갈까요?' : '여행 갈 칸을 판에서 누르세요';
        if (sel >= 0) btns.append(button('여행 가기', sel < TRAVEL ? '출발 지나 +' + SAL : null, () => { const to = sel; sel = -1; act({ t: 'tv', to }); }, { primary: true, act: 'roll' }));
      } else { decisionSheet(); }
      hint.append(h('span', { class: 'dot', style: { '--c': col(st.w ? st.w[0] : seat), flex: 'none' } }), h('span', { style: { color: c2 }, text }));
    }
    function tileHead(i, extra, line) {
      const tl = T[i], ow = own(st, i);
      return h('div', { style: { display: 'flex', alignItems: 'center', gap: '10px' } },
        h('span', { style: { width: '14px', alignSelf: 'stretch', minHeight: '34px', borderRadius: '4px', background: GC[tl.g], flex: 'none' } }),
        h('div', { style: { flex: '1 1 auto', minWidth: 0 } },
          h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '22px', lineHeight: 1.1 }, text: tl.n }),
          h('div', { class: 'muted', style: { fontSize: '12px' }, text: line || (ow >= 0 ? nm(ow) + '의 ' + TIER[lvl(st, i)] : '빈 땅 · 땅값 ' + fmt(tl.p)) + (ow >= 0 && hasSet(st, tl.g, ow) ? ' · 세트 ×2' : '') })),
        extra || null);
    }
    function decisionSheet() {
      const seat = st.t, i = st.p[seat], m = st.m[seat];
      bar.style.display = 'none'; sheet.style.display = 'flex';
      const money = h('span', { class: 'mono', style: { fontSize: '12px', color: 'var(--brass)', flex: 'none', textAlign: 'right' }, text: '현금 ' + fmt(m) });
      const setX = (lv) => { // resulting toll when this seat owns i at lv
        const o2 = st.o, v2 = st.v; setT(st, i, seat, lv); const t = toll(st, i); st.o = o2; st.v = v2; return t;
      };
      const grid = h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(72px,1fr))', gap: '6px' } });
      const opt = (label, c, t, a, primary) => grid.append(h('button', { class: 'btn' + (primary ? ' primary' : ''), 'data-action': primary ? 'ok' : null, disabled: c > m ? true : null, onclick: () => act(a), style: { flexDirection: 'column', gap: '2px', minHeight: '58px', padding: '6px 8px', lineHeight: 1.15 } },
        h('span', { style: { fontSize: '14px' }, text: label }),
        h('span', { class: 'mono', style: { fontSize: '11.5px' }, text: fmt(c) }),
        h('span', { style: { fontSize: '10.5px', fontWeight: 500, opacity: 0.85, whiteSpace: 'nowrap' }, text: '통행 ' + fmt(t) })));
      if (st.ph === 'B') {
        sheet.append(tileHead(i, money));
        for (let lv = 0; lv <= 2; lv++) opt(lv ? '땅+' + TIER[lv] : '땅만', invested(i, lv), setX(lv), { t: 'buy', lv }, lv === 0);
        sheet.append(grid);
      } else if (st.ph === 'U') {
        const cur = lvl(st, i);
        sheet.append(tileHead(i, money, '내 땅 · 지금 통행료 ' + fmt(toll(st, i))));
        upOpts(st, i).forEach((lv, q) => opt(TIER[lv] + (lv === 4 ? '' : '까지'), upCost(i, cur, lv), setX(lv), { t: 'up', lv }, q === 0));
        sheet.append(grid);
        if (cur === 3) sheet.append(h('div', { class: 'muted', style: { fontSize: '11.5px' }, text: '랜드마크는 남이 인수할 수 없어요.' }));
      } else if (st.ph === 'X') {
        const ow = own(st, i), c = takeCost(st, i);
        sheet.append(tileHead(i, money, nm(ow) + '에게 ' + fmt(c) + ' 주고 건물째 인수할까요?'));
        opt('인수하기', c, setX(lvl(st, i)), { t: 'take' }, true);
        sheet.append(grid);
      } else if (st.ph === 'D') {
        const need = st.dt.a - m;
        sheet.append(h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '8px' } },
          h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '22px' }, text: '돈이 모자라요' }),
          h('span', { class: 'mono', style: { fontSize: '12px', color: 'var(--coral)' }, text: '갚을 돈 ' + fmt(st.dt.a) + ' · 부족 ' + fmt(need) })),
        h('div', { class: 'muted', style: { fontSize: '12px' }, text: '땅을 은행에 팔아(들인 돈의 절반) 갚아요. 다 팔아도 모자라면 파산.' }),
        button('알아서 정리', '싼 땅부터 팔기', () => act({ t: 'auto' }), { primary: true, flex: '1 1 auto' }));
        const list = h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5px' } });
        owned(st, seat).sort((a, b) => sellVal(st, a) - sellVal(st, b)).forEach((k) => list.append(h('button', { class: 'btn', onclick: () => act({ t: 'sell', i: k }), style: { justifyContent: 'space-between', minHeight: '44px', padding: '4px 8px', gap: '4px', fontSize: '12.5px' } },
          h('span', { style: { display: 'flex', alignItems: 'center', gap: '5px', minWidth: 0, overflow: 'hidden', whiteSpace: 'nowrap' } }, h('span', { style: { width: '7px', height: '22px', borderRadius: '2px', background: GC[T[k].g], flex: 'none' } }), T[k].n + (lvl(st, k) ? '·' + TIER[lvl(st, k)] : '')),
          h('span', { class: 'mono', style: { flex: 'none', color: sellVal(st, k) >= need ? '#7fe0a8' : 'var(--ink)' }, text: '+' + sellVal(st, k) }))));
        sheet.append(list);
        return;
      }
      grid.append(h('button', { class: 'btn ghost', 'data-action': 'pass', onclick: () => act({ t: 'pass' }), style: { minHeight: '58px', padding: '6px 8px' } }, h('span', { style: { fontSize: '14px' }, text: '패스' })));
    }
    /* ---- trading UI ---- */
    const tileLine = (k) => T[k].n + (lvl(st, k) ? '·' + TIER[lvl(st, k)] : '');
    function tradeSummary(tr) {
      const side = (who, tiles, cash) => h('div', { class: 'panel', style: { flex: '1 1 0', minWidth: 0, padding: '6px 8px', display: 'flex', flexDirection: 'column', gap: '3px', fontSize: '12.5px' } },
        h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontWeight: 700 } }, h('span', { class: 'dot', style: { '--c': col(who), flex: 'none' } }), h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: nm(who) + ' 줌' })),
        ...tiles.map((k) => h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', whiteSpace: 'nowrap', overflow: 'hidden' } }, h('span', { style: { width: '7px', height: '16px', borderRadius: '2px', background: GC[T[k].g], flex: 'none' } }), tileLine(k))),
        cash ? h('div', { class: 'mono', style: { color: 'var(--brass)' }, text: '현금 ' + fmt(cash) }) : null,
        !tiles.length && !cash ? h('div', { class: 'muted', text: '없음' }) : null);
      return h('div', { style: { display: 'flex', gap: '6px' } }, side(tr.a, tr.ag, tr.am), side(tr.b, tr.bg, tr.bm));
    }
    function setNote(tr, seat) { // which colour sets this trade completes for seat
      const o2 = st.o; tr.ag.forEach((i) => setT(st, i, tr.b, lvl(st, i))); tr.bg.forEach((i) => setT(st, i, tr.a, lvl(st, i)));
      const done = GT.map((_, g) => g).filter((g) => hasSet(st, g, seat) && GT[g].some((i) => o2[i] !== String(seat)));
      st.o = o2; return done;
    }
    function tradeAnswerSheet() {
      const tr = st.tr, me = tr.w, other = me === tr.a ? tr.b : tr.a;
      bar.style.display = 'none'; sheet.style.display = 'flex';
      const mySets = setNote(tr, me), theirSets = setNote(tr, other);
      sheet.append(h('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '8px' } },
        h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '21px' }, text: tr.c ? nm(other) + '의 역제안' : nm(other) + '의 거래 제안' }),
        h('span', { class: 'mono', style: { fontSize: '12px', color: 'var(--brass)' }, text: '내 현금 ' + fmt(st.m[me]) })),
        tradeSummary(tr));
      const notes = [];
      if (mySets.length) notes.push('받으면 내 세트 완성: ' + mySets.map((g) => T[GT[g][0]].n + ' 색').join(', '));
      if (theirSets.length) notes.push('상대 세트 완성: ' + theirSets.map((g) => T[GT[g][0]].n + ' 색').join(', '));
      if (notes.length) sheet.append(h('div', { style: { fontSize: '12px', color: '#ffd76a' }, text: notes.join(' · ') }));
      const row = h('div', { style: { display: 'flex', gap: '6px' } });
      row.append(button('수락', null, () => act({ t: 'tacc' }), { primary: true, flex: '1 1 0' }));
      if (!tr.c && me === tr.b) row.append(button('역제안', '한 번만', () => tradeCompose(me, other, tr), { flex: '1 1 0' }));
      row.append(button('거절', null, () => act({ t: 'trej' }), { ghost: true, flex: '1 1 0' }));
      sheet.append(row);
      hint.append(h('span', { text: '거래 응답' }));
    }
    function tradeView() { if (st && st.tr) modal(h('h2', { text: st.tr.c ? '역제안' : '거래 제안' }), tradeSummary(st.tr)); }
    /* composer: me proposes to tgt (or counters `base` when given) */
    function tradeCompose(me, tgt, base) {
      api.sfx('click');
      const ot = others(st, me);
      const S2 = { tgt: tgt != null ? tgt : ot[0], give: new Set(), get: new Set(), gm: 0, rm: 0 };
      if (base) { S2.give = new Set(base.bg); S2.get = new Set(base.ag); S2.gm = base.bm; S2.rm = base.am; }
      const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px', overflowY: 'auto', minHeight: 0 } });
      const sendBtn = h('button', { class: 'btn primary block', style: { minHeight: '48px' } });
      const chip = (k, on, fn) => h('button', { class: 'btn' + (on ? ' primary' : ''), onclick: fn, style: { minHeight: '44px', padding: '4px 8px', justifyContent: 'flex-start', gap: '6px', fontSize: '12.5px', overflow: 'hidden', whiteSpace: 'nowrap' } },
        h('span', { style: { width: '7px', height: '20px', borderRadius: '2px', background: GC[T[k].g], flex: 'none' } }), h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' }, text: tileLine(k) }));
      const stepper = (label, key, max) => h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
        h('span', { style: { flex: '1 1 auto', fontSize: '13px' }, text: label }),
        h('button', { class: 'btn', style: { minWidth: '44px', minHeight: '44px', padding: 0 }, text: '−10', onclick: () => { S2[key] = Math.max(0, S2[key] - 10); draw2(); } }),
        h('b', { class: 'mono', style: { minWidth: '52px', textAlign: 'center', color: 'var(--brass)' }, text: fmt(S2[key]) }),
        h('button', { class: 'btn', style: { minWidth: '44px', minHeight: '44px', padding: 0 }, text: '+10', onclick: () => { S2[key] = Math.min(max, S2[key] + 10); draw2(); } }));
      function section(title, seat, set) {
        const list = owned(st, seat);
        const grid = h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5px' } });
        list.forEach((k) => grid.append(chip(k, set.has(k), () => { set.has(k) ? set.delete(k) : set.add(k); draw2(); })));
        return [h('div', { style: { fontWeight: 700, fontSize: '13px', display: 'flex', alignItems: 'center', gap: '6px' } }, h('span', { class: 'dot', style: { '--c': col(seat) } }), title),
          list.length ? grid : h('div', { class: 'muted', style: { fontSize: '12px' }, text: '가진 도시가 없어요' })];
      }
      function draw2() {
        body.innerHTML = '';
        if (!base) {
          const tabs = h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } });
          ot.forEach((o) => tabs.append(h('button', { class: 'btn' + (o === S2.tgt ? ' primary' : ''), style: { minHeight: '44px', flex: '1 1 0', minWidth: 0 }, onclick: () => { if (o !== S2.tgt) { S2.tgt = o; S2.get.clear(); S2.rm = 0; } draw2(); } },
            h('span', { class: 'dot', style: { '--c': col(o), flex: 'none' } }), h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: nm(o) }))));
          body.append(h('div', { class: 'muted', style: { fontSize: '12px' }, text: '누구와 거래할까요?' }), tabs);
        }
        S2.gm = Math.min(S2.gm, st.m[me]); S2.rm = Math.min(S2.rm, st.m[S2.tgt]);
        body.append(...section('내가 줄 것', me, S2.give), stepper('+ 내 현금 (' + fmt(st.m[me]) + ' 중)', 'gm', st.m[me]),
          ...section(nm(S2.tgt) + '에게 받을 것', S2.tgt, S2.get), stepper('+ 상대 현금 (' + fmt(st.m[S2.tgt]) + ' 중)', 'rm', st.m[S2.tgt]));
        const ok = (S2.give.size || S2.gm) && (S2.get.size || S2.rm);
        sendBtn.disabled = ok ? null : true; sendBtn.textContent = ok ? (base ? '역제안 보내기' : '제안 보내기') : '양쪽 모두 무언가를 넣어 주세요';
      }
      sendBtn.onclick = () => {
        const give = [...S2.give], get = [...S2.get];
        closeInfo();
        if (base) act({ t: 'tctr', ag: get, am: S2.rm, bg: give, bm: S2.gm });
        else act({ t: 'offer', to: S2.tgt, og: give, om: S2.gm, rg: get, rm: S2.rm });
      };
      draw2();
      modal(h('h2', { text: base ? '역제안 만들기' : '거래 제안' }), h('div', { class: 'muted', style: { fontSize: '12px', marginTop: '-6px' }, text: '건물이 있으면 건물째 넘어가요. 거래는 모두에게 공개돼요.' }), body, sendBtn);
    }

    /* info sheets */
    let info = null;
    // 오른쪽 클릭 = 취소: 정보 창 닫기 → 고른 여행 칸 해제
    const onCx = (e) => {
      if (info) { closeInfo(); e.preventDefault(); return; }
      if (sel >= 0) { sel = -1; refresh(); e.preventDefault(); }
    };
    window.addEventListener('lounge-cancel', onCx);
    function closeInfo() { if (info) { info.remove(); info = null; } }
    function modal(...kids) {
      closeInfo();
      const box = h('div', { class: 'sheet', style: { gap: '10px', maxHeight: '80%' } }, ...kids, h('button', { class: 'btn block', text: '닫기', onclick: closeInfo }));
      info = h('div', { class: 'overlay', style: { alignItems: 'flex-end', zIndex: 8 } }, box);
      info.addEventListener('click', (e) => { if (e.target === info) closeInfo(); });
      root.append(info);
    }
    function tileSheet(i) {
      const tl = T[i]; if (!st) return;
      api.sfx('click');
      if (tl.k !== 'c') {
        const txt = { s: '지나가거나 멈추면 월급 ' + fmt(SAL) + '을 받아요.', j: '갇히면 3턴 동안 못 움직여요. 더블이 나오거나 ' + fmt(JF) + '을 내거나 탈출권을 쓰면 나와요. 3번째 턴에는 그 주사위로 나가요.', v: '멈추면 다음 차례에 주사위 대신 원하는 칸으로 가요(출발을 지나면 월급).', d: '멈추면 은행에 ' + fmt(DON) + '을 기부해요.', k: '행운 카드를 한 장 뽑아요. 돈을 받거나 내거나, 다른 칸으로 가요.' }[tl.k];
        return modal(h('h2', { text: tl.n }), h('p', { class: 'muted', style: { margin: 0 }, text: txt }));
      }
      const ow = own(st, i), lv = lvl(st, i);
      const rows = TIER.map((nmT, k) => {
        if (k === 4 && !st.lm) return null;
        const tN = Math.round(tl.p * TM[k]);
        return h('div', { style: { display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '10px', padding: '4px 6px', borderRadius: '8px', background: ow >= 0 && k === lv ? 'color-mix(in srgb,' + col(ow) + ' 25%, transparent)' : '' } },
          h('span', { text: nmT }), h('span', { class: 'mono muted', text: '비용 ' + cost(i, k) }), h('span', { class: 'mono', text: '통행 ' + tN }));
      });
      modal(tileHead(i), h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', fontSize: '13px' } }, rows),
        h('p', { class: 'muted', style: { margin: 0, fontSize: '12px' }, text: '같은 색 3칸을 모두 가지면 통행료 2배.' + (ow >= 0 ? ' 현재 통행료 ' + fmt(toll(st, i)) + (st.to && lv < 4 ? ' · 인수가 ' + fmt(takeCost(st, i)) : '') + ' · 매각가 ' + fmt(sellVal(st, i)) : '') }));
    }
    function playerSheet(seat) {
      if (!st) return;
      api.sfx('click');
      const list = owned(st, seat);
      const sets = GT.filter((_, g) => hasSet(st, g, seat)).length;
      modal(h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span', { class: 'dot', style: { '--c': col(seat), width: '16px', height: '16px' } }), h('h2', { text: nm(seat) })),
        h('div', { class: 'mono', style: { fontSize: '13px' }, text: '현금 ' + fmt(st.m[seat]) + ' · 총자산 ' + fmt(worth(st, seat)) + ' · 세트 ' + sets + (st.k[seat] ? ' · 탈출권 ' + st.k[seat] : '') + (st.cp[seat] ? ' · 쿠폰 ' + st.cp[seat] : '') }),
        list.length ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px', overflowY: 'auto' } }, list.map((k) => h('button', { class: 'btn sm', onclick: () => tileSheet(k), style: { justifyContent: 'space-between' } },
          h('span', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span', { style: { width: '10px', height: '20px', borderRadius: '3px', background: GC[T[k].g] } }), T[k].n + ' · ' + TIER[lvl(st, k)]),
          h('span', { class: 'mono', text: '통행 ' + toll(st, k) })))) : h('p', { class: 'muted', style: { margin: 0 }, text: !st.a[seat] ? '파산했어요.' : '아직 땅이 없어요.' }));
    }

    /* ---- input ---- */
    function onDown(ev) {
      if (!G) return;
      const p = cv.local(ev), i = tileAt(p.x, p.y);
      if (i < 0) {
        const inBoard = p.x > G.bx && p.x < G.bx + G.S && p.y > G.by && p.y < G.by + G.S;
        if (inBoard && mine() && st.ph === 'R' && !st.j[st.t]) act({ t: 'roll' });
        return;
      }
      if (mine() && st.ph === 'V') { if (i === TRAVEL) { api.toast('세계 여행 칸은 고를 수 없어요'); return; } sel = sel === i ? -1 : i; api.sfx('click'); api.buzz(8); refresh(); return; }
      tileSheet(i);
    }
    cv.cv.addEventListener('pointerdown', onDown);

    /* ---- drawing ---- */
    function drawDie(x, y, sz, v, rot) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(ctx, -sz / 2 + 3, -sz / 2 + 5, sz, sz, sz * 0.2); ctx.fill();
      const g = ctx.createLinearGradient(-sz / 2, -sz / 2, sz / 2, sz / 2); g.addColorStop(0, '#fffaf0'); g.addColorStop(1, '#e2d6bd');
      ctx.fillStyle = g; rr(ctx, -sz / 2, -sz / 2, sz, sz, sz * 0.2); ctx.fill();
      ctx.strokeStyle = 'rgba(60,40,20,.5)'; ctx.lineWidth = 1; ctx.stroke();
      const P = { 1: [[0, 0]], 2: [[-1, -1], [1, 1]], 3: [[-1, -1], [0, 0], [1, 1]], 4: [[-1, -1], [1, -1], [-1, 1], [1, 1]], 5: [[-1, -1], [1, -1], [0, 0], [-1, 1], [1, 1]], 6: [[-1, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [1, 1]] }[v];
      ctx.fillStyle = v === 1 ? '#c8432f' : '#2a1d12';
      P.forEach(([a, b]) => { ctx.beginPath(); ctx.arc(a * sz * 0.26, b * sz * 0.26, sz * (v === 1 ? 0.12 : 0.085), 0, 7); ctx.fill(); });
      ctx.restore();
    }
    function drawToken(x, y, c, r, on) {
      ctx.save();
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 1, y + r * 0.85, r * 0.9, r * 0.35, 0, 0, 7); ctx.fill();
      // pawn: base + body + head
      ctx.fillStyle = shade(c, -50); ctx.beginPath(); ctx.ellipse(x, y + r * 0.7, r * 0.85, r * 0.32, 0, 0, 7); ctx.fill();
      const g = ctx.createLinearGradient(x - r, y - r, x + r, y + r); g.addColorStop(0, shade(c, 60)); g.addColorStop(0.5, c); g.addColorStop(1, shade(c, -40));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.moveTo(x - r * 0.75, y + r * 0.7); ctx.quadraticCurveTo(x - r * 0.25, y, x - r * 0.3, y - r * 0.35); ctx.lineTo(x + r * 0.3, y - r * 0.35); ctx.quadraticCurveTo(x + r * 0.25, y, x + r * 0.75, y + r * 0.7); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = 'rgba(20,10,20,.75)'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.beginPath(); ctx.arc(x, y - r * 0.62, r * 0.42, 0, 7); ctx.fill(); ctx.stroke();
      if (on) { ctx.strokeStyle = '#ffe9a8'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x - r * 0.12, y - r * 0.72, r * 0.18, 3.6, 5.2); ctx.stroke(); }
      ctx.restore();
    }
    function draw(dt) {
      cv.clear();
      if (!G || !D) return;
      buildBoard();
      ctx.drawImage(boardImg.c, G.bx - boardImg.pad, G.by - boardImg.pad, boardImg.size, boardImg.size);
      const c = G.c, S = G.S, cx = G.bx + S / 2, cy = G.by + S / 2;
      // travel selection highlights
      if (st && mine() && st.ph === 'V') {
        const pulse = 0.5 + 0.5 * Math.sin(time * 5);
        for (let i = 0; i < N; i++) { if (i === TRAVEL) continue; const r = rect(i); ctx.fillStyle = i === sel ? 'rgba(227,174,69,.45)' : 'rgba(227,174,69,' + (0.1 + 0.14 * pulse) + ')'; ctx.fillRect(G.bx + r[0], G.by + r[1], r[2], r[3]); ctx.strokeStyle = i === sel ? '#ffd76a' : 'rgba(227,174,69,' + (0.45 + 0.4 * pulse) + ')'; ctx.lineWidth = i === sel ? 4 : 2.5; ctx.strokeRect(G.bx + r[0] + 2, G.by + r[1] + 2, r[2] - 4, r[3] - 4); }
      }
      // current decision tile highlight
      if (st && !run && !st.w && ['B', 'U', 'X'].includes(st.ph)) {
        const r = rect(st.p[st.t]); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.strokeRect(G.bx + r[0] + 1.5, G.by + r[1] + 1.5, r[2] - 3, r[3] - 3);
      }
      // pops on build
      pops = pops.filter((p) => (p.t += dt) < 0.6);
      pops.forEach((p) => { const r = rect(p.i), f = p.t / 0.6; ctx.strokeStyle = p.col; ctx.globalAlpha = 1 - f; ctx.lineWidth = 3; const e = f * c * 0.4; ctx.strokeRect(G.bx + r[0] - e, G.by + r[1] - e, r[2] + 2 * e, r[3] + 2 * e); ctx.globalAlpha = 1; });
      // centre: title, round
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(242,233,216,.22)'; ctx.font = FONT('400', Math.round(S * 0.075), '"Black Han Sans", "IBM Plex Sans KR", sans-serif');
      ctx.fillText('세계 땅따먹기', cx, G.by + 1.5 * c + S * 0.08);
      ctx.fillStyle = 'rgba(242,233,216,.6)'; ctx.font = FONT('600', Math.round(Math.max(10, S * 0.032)), '"IBM Plex Mono", monospace');
      ctx.fillText((D.R ? D.r + ' / ' + D.R + ' 턴' : D.r + ' 턴') + (D.mo ? ' · 독점 승리' : ''), cx, G.by + 1.5 * c + S * 0.14);
      // dice
      const dz = Math.max(30, S * 0.12);
      let rolling = diceT >= 0 && diceT < 0.62 / SP();
      if (diceT >= 0) diceT += dt;
      const show = rolling ? [1 + Math.floor(time * 23) % 6, 1 + Math.floor(time * 17 + 3) % 6] : dice;
      const f = rolling ? diceT / (0.62 / SP()) : 1;
      for (let k = 0; k < 2; k++) {
        const ox = (k ? 1 : -1) * dz * 0.68, bounce = rolling ? Math.abs(Math.sin(f * Math.PI * 3)) * (1 - f) * dz * 0.9 : 0;
        drawDie(cx + ox, cy - dz * 0.05 - bounce, dz, show[k], rolling ? (1 - f) * (k ? 5 : -6) : (k ? 0.08 : -0.06));
      }
      if (!rolling && diceT >= 0 && dice[0] === dice[1]) { ctx.fillStyle = '#e3ae45'; ctx.font = FONT('400', Math.round(S * 0.045), '"Black Han Sans", sans-serif'); ctx.fillText('더블!', cx, cy - dz * 0.85); }
      if (!rolling && diceT >= 0) { ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.font = FONT('700', Math.round(S * 0.04), '"IBM Plex Mono", monospace'); ctx.fillText('= ' + (dice[0] + dice[1]), cx, cy + dz * 0.8); }
      // message line
      if (msg) {
        msg.t += dt;
        ctx.globalAlpha = Math.min(1, Math.max(0, 4 - msg.t));
        const px = fitText(ctx, msg.text, S - 3 * c - 16, Math.round(Math.max(11, S * 0.036)), '700');
        const mw = ctx.measureText(msg.text).width + px * 1.4; // dark pill keeps the line readable over the felt and money pops
        ctx.fillStyle = 'rgba(16,12,22,.55)'; rr(ctx, cx - mw / 2, cy + dz * 1.45 - px * 0.95, mw, px * 1.9, px * 0.95); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.fillText(msg.text, cx, cy + dz * 1.45);
        ctx.globalAlpha = 1;
        if (msg.t > 4) msg = null;
      }
      // hint for roll tap
      if (st && mine() && st.ph === 'R' && !st.j[st.t] && !msg) {
        ctx.fillStyle = 'rgba(227,174,69,' + (0.55 + 0.35 * Math.sin(time * 4)) + ')'; ctx.font = FONT('700', Math.round(Math.max(11, S * 0.034)));
        ctx.fillText('판을 눌러도 굴려요', cx, cy + dz * 1.45);
      }
      // tokens
      const groups = {};
      for (let i = 0; i < D.n; i++) if (D.a[i]) { const k = D.p[i]; (groups[k] = groups[k] || []).push(i); }
      const tr = Math.max(7.5, c * 0.27);
      const order = []; for (let i = 0; i < D.n; i++) if (D.a[i]) order.push(i);
      const movingSeat = run && run.op && 'wbj'.includes(run.op[0]) ? run.op[1] : -1;
      order.sort((a, b) => (a === movingSeat) - (b === movingSeat));
      order.forEach((i) => {
        let [x, y] = D.pos[i];
        if (i !== movingSeat) {
          const g = groups[D.p[i]], k = g.indexOf(i), n = g.length, cc = spot(D.p[i]);
          x = cc.x + (n > 1 ? ((k % 2) - 0.5) * tr * 1.25 : 0); y = cc.y + (n > 2 ? (Math.floor(k / 2) - 0.5) * tr * 1.2 : 0) + tr * 0.1;
          D.pos[i] = [cc.x, cc.y];
        }
        drawToken(x, y, col(i), tr, st && st.t === i && !st.w);
      });
      // floats
      floats = floats.filter((f2) => (f2.t += dt) < 1.2);
      floats.forEach((f2) => {
        ctx.globalAlpha = 1 - f2.t / 1.2; ctx.font = FONT('700', Math.round(Math.max(13, S * 0.045)), '"IBM Plex Mono", monospace');
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(20,12,24,.85)'; ctx.strokeText(f2.text, f2.x, f2.y - f2.t * c * 1.2);
        ctx.fillStyle = f2.color; ctx.fillText(f2.text, f2.x, f2.y - f2.t * c * 1.2); ctx.globalAlpha = 1;
      });
      // card popup
      if (card) {
        card.t += dt;
        const a = Math.min(1, card.t * 6 * SP()), w = Math.min(S * 0.56, 230), hh = w * 0.62;
        ctx.save(); ctx.translate(cx, cy); ctx.scale(0.7 + 0.3 * a, 0.7 + 0.3 * a); ctx.globalAlpha = a;
        ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, -w / 2 + 4, -hh / 2 + 6, w, hh, 12); ctx.fill();
        const g = ctx.createLinearGradient(0, -hh / 2, 0, hh / 2); g.addColorStop(0, '#f6d27a'); g.addColorStop(1, '#d9a23c');
        ctx.fillStyle = g; rr(ctx, -w / 2, -hh / 2, w, hh, 12); ctx.fill();
        ctx.strokeStyle = '#7a5310'; ctx.lineWidth = 2; rr(ctx, -w / 2 + 5, -hh / 2 + 5, w - 10, hh - 10, 8); ctx.stroke();
        ctx.fillStyle = '#5a3a08'; ctx.font = FONT('700', 11); ctx.fillText('행운 카드', 0, -hh * 0.3);
        const [t1, t2] = CARDS[card.c];
        fitText(ctx, t1, w - 20, Math.round(w * 0.11), '400', '"Black Han Sans", "IBM Plex Sans KR", sans-serif'); ctx.fillStyle = '#3a2405'; ctx.fillText(t1, 0, -hh * 0.04);
        fitText(ctx, t2, w - 20, 12, '600'); ctx.fillText(t2, 0, hh * 0.25);
        ctx.restore();
      }
    }
    const stopLoop = U.loop((dt, now) => {
      time = now / 1000;
      if (run) stepRun(dt);
      if (toastQ.length && now > toastT) { api.toast(toastQ.shift()); toastT = now + 900; }
      draw(dt);
    });
    cv.onresize = () => { layout(); if (D) { snap(run ? D : st); } };
    layout();

    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down') return;
      const b = [...document.querySelectorAll('[data-action="' + id + '"]')].find((x) => !x.disabled && x.getClientRects().length);
      if (b) b.click();
    }) : null;
    const noFocus = (e) => { const b = e.target && e.target.closest && e.target.closest('button[data-action]'); if (b) e.preventDefault(); };   // 마우스로 누른 버튼에 포커스가 남아 Space/Enter 단축키를 가로채지 않게
    document.addEventListener('mousedown', noFocus, true);
    return {
      update(next, prev) {
        const was = st;
        st = next;
        pending = false;
        if (next && next.t !== (was && was.t)) sel = -1;
        if (!G) layout();
        if (next && next.last && prev && prev !== next && (!prev.last || prev.last.id !== next.last.id) && next.last.q.length) start(next, prev);
        else if (!run) snap(next);
        if (!next || !next.last || (prev && prev.seq > next.seq)) { dice = [5, 2]; diceT = -1; }
        refresh();
      },
      destroy() { if (offKeys) offKeys(); document.removeEventListener('mousedown', noFocus, true);
        window.removeEventListener('lounge-cancel', onCx); 
        stopLoop(); clearTimeout(wd);
        cv.cv.removeEventListener('pointerdown', onDown);
        closeInfo(); cv.destroy(); top.remove(); bar.remove(); sheet.remove(); boardMark.remove(); startMark.remove();
        if (busy) api.setBusy(false);
      },
    };
  }

  const ICON = '<rect x="6" y="6" width="44" height="44" rx="5" fill="none" stroke="currentColor" stroke-width="3"/><rect x="15" y="15" width="26" height="26" rx="2" fill="none" stroke="currentColor" stroke-width="2" opacity=".55"/><path d="M6 15h9M41 15h9M6 41h9M41 41h9M15 6v9M41 6v9M15 41v9M41 41v9" stroke="currentColor" stroke-width="2" opacity=".55"/><path d="M25 35V19l9 3.5-9 3.5" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><rect x="31" y="30" width="8" height="8" rx="2" fill="currentColor"/>';

  L.register({
    id: 'landgrab', name: '세계 땅따먹기', tag: '주사위 부동산', cat: '보드', icon: ICON, tint: '#2f4a6e',
    blurb: '주사위로 세계를 돌며 도시를 사고 별장·빌딩·호텔을 올려 통행료를 받아요. 남을 모두 파산시키거나 한 줄·세 세트를 독점하면 승리.',
    controls: [
      { id: 'roll', label: '주사위 굴리기 · 여행 가기', keys: ['Space'], pad: ['a'] },
      { id: 'ok', label: '기본 선택(땅 사기·짓기·인수)', keys: ['Enter'], pad: ['x'] },
      { id: 'pass', label: '패스', keys: ['KeyP'], pad: ['b'] },
      { id: 'trade', label: '거래', keys: ['KeyT'], pad: ['y'] },
    ],
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 3, aiDelay: 450,
    options: [
      { id: 'tl', label: '턴 제한', tip: '정한 턴이 지나면 자산이 가장 많은 사람이 승리.', choices: [{ v: 20, label: '20턴' }, { v: 30, label: '30턴' }, { v: 0, label: '없음' }], def: 30 },
      { id: 'mo', label: '독점 승리', tip: '같은 색 줄·지역을 모두 가지면 바로 승리.', choices: [{ v: 1, label: '라인·트리플' }, { v: 0, label: '없음' }], def: 1 },
      { id: 'to', label: '인수', tip: '남의 땅에 서면 값을 치르고 빼앗을 수 있어요.', choices: [{ v: 20, label: '2배 값' }, { v: 15, label: '1.5배 값' }, { v: 0, label: '없음' }], def: 20 },
      { id: 'lm', label: '랜드마크', tip: '땅에 가장 높은 건물인 랜드마크를 지을 수 있어요.', choices: [{ v: 1, label: '있음' }, { v: 0, label: '없음' }], def: 1 },
    ],
    quick: [
      '도시를 사고 건물을 올려, 남이 내 땅에 멈추면 통행료를 받아요.',
      '내 차례: 주사위 두 개를 굴려 그만큼 가요. 빈 도시면 살 수 있고, 남의 땅이면 통행료를 내요.',
      '남을 모두 파산시키거나, 한 줄(6도시)·색 세트 3개를 모으거나, 30턴 뒤 자산 1등이면 승리!',
    ],
    rules: [
      { h: '목표', p: [
        '주사위로 세계 판을 돌며 도시를 사고 건물을 올려요. 다른 사람이 내 도시에 멈추면 통행료를 받아요.',
        '이기는 방법은 셋이에요.',
        '① 다른 사람이 모두 파산하면 승리.',
        '② 독점 승리(설정, 기본 켬): 한 줄(판 한 변의 도시 6칸)을 모두 갖거나, 색깔 세트(같은 색 3도시) 3개를 모으면 바로 승리.',
        '③ 턴 제한(기본 30턴, 모두 한 번씩 = 1턴)이 끝나면 총자산(현금 + 땅·건물에 들인 돈)이 가장 많은 사람이 승리. 「없음」이어도 100턴이 지나면 이렇게 끝내요.'] },
      { h: '그림으로 보기', fig: [{ svg: "<svg viewBox=\"0 0 340 124\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"124\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"20\" y=\"20\" width=\"90\" height=\"70\" rx=\"6\" fill=\"#3a6ea5\" stroke=\"#e3ae45\" stroke-width=\"2\"/><text x=\"65\" y=\"44\" font-size=\"12\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"700\">파란 도시</text><text x=\"65\" y=\"64\" font-size=\"12\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">🏨 호텔</text><text x=\"65\" y=\"82\" font-size=\"10\" fill=\"#b9b0a0\" text-anchor=\"middle\" font-weight=\"400\">주인: 상대</text><text x=\"135\" y=\"58\" font-size=\"22\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">→</text><text x=\"160\" y=\"40\" font-size=\"12\" fill=\"#f2e9d8\" text-anchor=\"start\" font-weight=\"400\">내가 멈추면 통행료를 내요</text><text x=\"160\" y=\"60\" font-size=\"12\" fill=\"#e3ae45\" text-anchor=\"start\" font-weight=\"400\">건물이 클수록 비싸요</text><text x=\"160\" y=\"80\" font-size=\"12\" fill=\"#f2a0a0\" text-anchor=\"start\" font-weight=\"400\">같은 색 3도시 = 통행료 2배</text><text x=\"170\" y=\"112\" font-size=\"11.5\" fill=\"#9fd59f\" text-anchor=\"middle\" font-weight=\"400\">낸 뒤엔 2배 값을 주고 「인수」할 수도 있어요</text></svg>", cap: "남의 도시에 멈추면 통행료" }, { svg: "<svg viewBox=\"0 0 340 96\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"96\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"14\" y=\"28\" width=\"56\" height=\"40\" rx=\"5\" fill=\"#4a5568\" stroke=\"#0005\" stroke-width=\"1\"/><text x=\"42\" y=\"53\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"700\">빈 땅</text><rect x=\"78\" y=\"28\" width=\"56\" height=\"40\" rx=\"5\" fill=\"#556b8a\" stroke=\"#0005\" stroke-width=\"1\"/><text x=\"106\" y=\"53\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"700\">🏠 별장</text><rect x=\"142\" y=\"28\" width=\"56\" height=\"40\" rx=\"5\" fill=\"#3a6ea5\" stroke=\"#0005\" stroke-width=\"1\"/><text x=\"170\" y=\"53\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"700\">🏢 빌딩</text><rect x=\"206\" y=\"28\" width=\"56\" height=\"40\" rx=\"5\" fill=\"#6b4aa5\" stroke=\"#0005\" stroke-width=\"1\"/><text x=\"234\" y=\"53\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"700\">🏨 호텔</text><rect x=\"270\" y=\"28\" width=\"56\" height=\"40\" rx=\"5\" fill=\"#a54a6e\" stroke=\"#0005\" stroke-width=\"1\"/><text x=\"298\" y=\"53\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"700\">🗼 랜드</text><text x=\"170\" y=\"18\" font-size=\"11.5\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">건물을 올릴수록 통행료가 커져요</text><text x=\"170\" y=\"86\" font-size=\"11\" fill=\"#e3ae45\" text-anchor=\"middle\" font-weight=\"400\">→ → → →</text></svg>", cap: "별장 → 빌딩 → 호텔 → 랜드마크" }] },
      { h: '준비', p: [
        '판은 32칸이에요. 모두 오른쪽 아래 「출발」 칸에서 현금 300만으로 시작해요.',
        '도시는 8가지 색, 색마다 3도시예요. 뒤쪽(판 한 바퀴의 끝)으로 갈수록 비싸요(10만 ~ 32만).'] },
      { h: '차례에 할 일', p: [
        '① 「주사위 굴리기」: 두 주사위의 합만큼 시계 방향으로 가요.',
        '② 멈춘 칸에 따라 해요: 빈 도시 → 살지 고르기 · 내 도시 → 건물 올리기 · 남의 도시 → 통행료 내기(그다음 인수 고르기) · 특수 칸 → 그 칸의 일.',
        '더블(두 눈이 같음)이면 한 번 더 굴려요. 한 차례에 더블이 세 번 나오면 무인도로 가요.',
        '출발 칸을 지나가거나 멈추면 월급 30만을 받아요.'] },
      { h: '땅과 건물', p: [
        '건물은 땅 → 별장 → 빌딩 → 호텔 → 랜드마크 순서예요. 높을수록 통행료가 커요.',
        '빈 도시에 멈추면 「땅만」 · 「땅+별장」 · 「땅+빌딩」(별장 포함) 중에서 골라 한 번에 살 수 있어요.',
        '내 도시에 다시 멈추면 호텔까지 올릴 수 있어요(한 번에 여러 단계도 가능).',
        '랜드마크(설정, 기본 있음): 호텔이 있는 내 도시에 다시 멈추면 올릴 수 있어요. 통행료가 가장 크고, 남이 인수할 수 없어요.',
        '같은 색 3도시를 모두 가지면 그 도시들 통행료가 2배예요.',
        '건설비(땅값 대비): 땅 1배 · 별장 +0.5배 · 빌딩 +0.75배 · 호텔 +1배 · 랜드마크 +1.25배.',
        '통행료(땅값 대비): 땅 0.3배 · 별장 1배 · 빌딩 2.3배 · 호텔 4배 · 랜드마크 6배.'] },
      { h: '통행료와 인수', p: [
        '남의 도시에 멈추면 주인에게 통행료를 내요.',
        '인수(설정, 기본 2배): 통행료를 낸 뒤, 그 도시에 들인 돈의 2배(또는 1.5배)를 주인에게 주고 건물째 가져올 수 있어요. 랜드마크는 인수 못 해요.',
        '인수한 뒤 돈이 있으면 바로 건물을 더 올릴 수도 있어요.'] },
      { h: '거래', p: [
        '내 차례에 주사위를 굴리기 전 「거래」를 눌러 한 사람에게 제안할 수 있어요(한 차례에 2번까지).',
        '줄 것(내 도시·현금)과 받을 것(상대 도시·현금)을 고르고 「제안 보내기」. 양쪽 모두 무언가를 넣어야 해요.',
        '상대는 수락·거절, 또는 조건을 바꿔 한 번만 「역제안」할 수 있어요. 역제안은 처음 제안한 사람이 수락이나 거절만 해요.',
        '건물이 있는 도시는 건물째 넘어가요. 거래로 세트·한 줄이 완성되면 독점 승리도 바로 확인해요.',
        '거래는 모두에게 공개돼요. AI도 가끔 세트를 맞추려고 제안해 와요.'] },
      { h: '특수 칸', p: [
        '무인도(왼쪽 아래): 갇혀요. 다음 내 차례마다 굴려서 더블이면 그 수만큼 나가요(이때는 한 번 더 굴리지 않아요). 세 번째 차례에는 무엇이 나오든 나가요.',
        '무인도에서 20만을 내거나 「탈출권」을 쓰면 바로 나가서 평소처럼 굴려요.',
        '세계 여행(왼쪽 위): 다음 차례에 주사위 대신 판에서 원하는 칸을 골라 가요(출발을 지나면 월급).',
        '기부(오른쪽 위): 은행에 25만을 내요.',
        '행운 카드(각 변 가운데): 한 장 뽑아요. 돈 받기(30·50·20만), 벌금 15만, 건물 수리비(단계마다 4만), 모두에게 10만씩, 출발·무인도·세계 여행·기부 칸으로 이동, 세 칸 뒤로, 다섯 칸 앞으로, 무인도 탈출권(보관), 통행료 반값 쿠폰(보관).'] },
      { h: '빚과 파산', p: [
        '낼 돈이 모자라면 내 도시를 은행에 팔아 갚아요. 파는 값 = 그 도시에 들인 돈의 절반.',
        '팔 도시를 직접 고르거나 「알아서 정리」를 눌러요.',
        '다 팔아도 모자라면 파산이에요. 남은 돈은 받을 사람에게 가고, 내 도시는 모두 빈 땅이 돼요.'] },
      { h: '조작', p: [
        '「주사위 굴리기」를 누르거나 판 가운데를 톡 치면 굴려요.',
        '사기·건설·인수는 아래에서 올라오는 창에서 비용과 결과 통행료를 보고 골라요. 안 사려면 「패스」.',
        '위쪽 사람 칸을 누르면 그 사람의 도시 목록, 판의 칸을 누르면 그 칸의 건설비·통행료를 볼 수 있어요.', '도시 칸 색띠의 그림이 건물 단계예요: 집(별장) · 높은 건물(빌딩) · 빨간 지붕(호텔) · 금별(랜드마크).'] },
      { h: '예시 (돈의 흐름)', p: [
        '리스본(땅값 20만)에 멈췄어요. 「땅+빌딩」을 골라 땅 20 + 별장 10 + 빌딩 15 = 45만을 은행에 내요. 내 현금 300 → 255만.',
        '상대가 리스본에 멈추면 통행료 46만(20 × 2.3)을 나에게 줘요. 리스본·마드리드·파리를 다 가졌다면 2배인 92만!',
        '상대가 통행료를 낸 뒤 돈이 넉넉하면, 90만(들인 45만의 2배)을 나에게 주고 리스본을 건물째 가져갈 수 있어요(인수).',
        '내가 지키면: 다음에 리스본에 다시 멈췄을 때 호텔(+20만)을 올리면 통행료가 80만이 돼요.',
        '돈이 모자랄 때 리스본(들인 돈 45만)을 은행에 팔면 22만을 받아요.'] },
      { h: 'AI 난이도', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '거래도 난이도마다 달라요: 쉬움은 대충 판단하고, 보통은 자기 이익과 현금 여유를 보고, 어려움은 1등에게 유리한 거래를 특히 꺼리고 역제안으로 값을 올려요.', '쉬움은 돈이 있으면 다 사고 다 지어요. 보통은 통행료에 대비해 현금을 남겨요. 어려움은 다음 주사위로 밟을 수 있는 통행료, 세트 완성과 독점 위협을 따져 사고 짓고, 꼭 필요한 땅만 인수해요.'] },
    ],
    tutorial: [
      { sel: '.lg-board', text: '세계를 도는 32칸 판이에요. 모두 현금 300만으로 출발해, 주사위 두 개의 합만큼 시계 방향으로 돌아요.' },
      { sel: '.lg-start', text: '오른쪽 아래가 「출발」이에요. 지나갈 때마다 월급 30만! 빈 도시 칸의 숫자는 땅값(단위 만)이고, 빈 도시에 멈추면 살 수 있어요.' },
      { sel: '.lg-bar', text: '내 차례엔 「주사위 굴리기」(또는 판 가운데 톡). 더블이면 한 번 더 굴려요. 사기·건설은 아래에 뜨는 창에서 골라요.' },
      { sel: '.lg-board', text: '남의 도시에 멈추면 통행료를 내요. 별장 → 빌딩 → 호텔 → 랜드마크로 올릴수록 통행료가 커지고, 같은 색 3도시를 모으면 2배!' },
      { sel: '.lg-board', text: '통행료를 낸 뒤엔 돈을 더 주고(들인 돈의 2배) 그 도시를 건물째 빼앗을 수도 있어요. 이걸 「인수」라고 해요.' },
      { sel: '.lg-top', text: '위쪽엔 사람마다 현금(만)과 가진 땅 수가 보여요. 누르면 그 사람의 도시 목록이 나와요.' },
      { sel: '.lg-board', text: '이기는 법: 모두를 파산시키기 · 한 변의 도시 6칸 독점 · 색 세트 3개 모으기 · 아니면 30턴 뒤 총자산 1등! 판의 칸을 누르면 값을 볼 수 있어요.' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { NK, HK, TM, BC, T, GT, LINE, CARDS, toll, invested, upCost, takeCost, sellVal, worth, liquid, owned, setT, own, lvl, START, SAL, JF, DON, N },
  });
})();
