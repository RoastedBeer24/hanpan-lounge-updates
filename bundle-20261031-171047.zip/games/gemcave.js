/* 보석 동굴 캐기 — grid cave digging (원작 없는 독자 디자인).
   흙을 파며 움직이고, 받침이 없으면 바위·보석이 떨어지고 둥근 것 위에서는 굴러요. 떨어지는 바위에 깔리면 끝.
   혼자: 손으로 만든 10단계 + 시드로 만드는 끝없는 단계(봇이 실제로 깨 보고 통과한 동굴만 씀), 목숨 3개.
   대전: 2–4명 실시간, 같은 동굴(좌우 대칭)에서 보석 많이 모으기. 한 기기에 한 명.
   Host-authoritative: the host (or local phone) steps the grid every TICK; guests publish their held direction,
   the host sends the cave (run-length string) + this tick's moves/events each tick (< 2 KB). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const TICK = 0.14;                       // seconds per grid step
  const CH = ' .#wo*xXmaFGHIBCDEpqrs%$&RvSTUdk';  // cell code → char (network/map)
  const E = 0, DI = 1, ST = 2, BW = 3, RK = 4, GM = 5, XC = 6, XO = 7, MG = 8, SL = 9, FF = 10, BG = 14, PL = 18, BX = 22;
  // round 26: 굴토끼(RB) · 거미줄(WB) · 수정 거미(SP) · 텔레포트 문 두 쌍(TA, TB) · 다이너마이트(DY 줍기, DL 불붙음)
  const RB = 25, WB = 26, SP = 27, TA = 28, TB = 29, DY = 30, DL = 31;
  const FUSE = Math.round(2.4 / TICK), WEB_STUCK = 3;
  const isDoor = (c) => c === TA || c === TB;
  const walkable = (c) => c === E || c === DI || c === GM || c === WB || c === DY;
  const isEn = (c) => c >= FF && c < PL, isPl = (c) => c >= PL && c < BX;
  const RESP = Math.round(3 / TICK), VS_TIME = 120, VS_AFTER_EXIT = 20, DEATH_COST = 3, EXIT_BONUS = 5;

  function rng(seed) {
    let a = (seed >>> 0) || 1;
    return function () { a = (a + 0x6D2B79F5) | 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function hash2(a, b) { let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x7F4A7C15, 0x85EBCA77)) >>> 0; h ^= h >>> 15; h = Math.imul(h, 0x2C1B3C6D) >>> 0; h ^= h >>> 12; return (h >>> 0) || 7; }

  /* ---------- hand-made stages ---------- */
  const STAGES = [
    { n: '첫 갱도', q: 8, t: 120, m: [
      '##############################',
      '#P.......*......o.....*......#',
      '#..o.....*...........o..*....#',
      '#..*.......oo......*.........#',
      '#.......*..**...........o....#',
      '#..o...........*.....*.......#',
      '#.....*....o.........o.......#',
      '#..........*...*.........*...#',
      '#...o..........o.............#',
      '#.....*...o...*.....*........#',
      '#..*..........o..........*...#',
      '#.........*......*....o......#',
      '#....o..........*........o...#',
      '#..*.....o....*.......*.....X#',
      '#............................#',
      '##############################'] },
    { n: '무너지는 비탈', q: 14, t: 130, m: [
      '##############################',
      '#P...o.o.o.o....oooo.........#',
      '#....*.*.*.*....o**o.....o...#',
      '#...............o**o....o*o..#',
      '#..oo....oo.....oooo...o***o.#',
      '#..**....**..............*...#',
      '#............................#',
      '#.ooo.......*..o..o..o.......#',
      '#.***.......*..*..*..*.......#',
      '#.......oo...................#',
      '#......o**o.......ooo.....*..#',
      '#.....o****o......***....***.#',
      '#............................#',
      '#..*...o.....o....*....o..X..#',
      '#............................#',
      '##############################'] },
    { n: '밀어붙이기', q: 12, t: 140, m: [
      '##############################',
      '#P.......#.......#...........#',
      '#........#...*...#....***....#',
      '#.  o  ..#..***..#...........#',
      '#........#...*...#..o........#',
      '#####.####.......####.###.####',
      '#...........o  ............. #',
      '#..*.*.*....##########..*.*..#',
      '#...........#*.*.*.*.#.......#',
      '#....o......#........#...o...#',
      '#...........###.o.####.......#',
      '#..***.......................#',
      '#.......oo....*.*....oo......#',
      '#..o...........*.........X...#',
      '#............................#',
      '##############################'] },
    { n: '불나방 둥지', q: 12, t: 140, m: [
      '##############################',
      '#P....*....o.o.o.......*.....#',
      '#..........o.o.o.............#',
      '#...*......     ......*......#',
      '#.........  F    .......o....#',
      '#..o.......     ..........*..#',
      '#......*.................o...#',
      '#....oooo.......*.....oooo...#',
      '#....     ..........       ..#',
      '#....  F  ...*.......   F  ..#',
      '#....     ...............  ..#',
      '#..*.........o..*.....*......#',
      '#......*.......o.............#',
      '#..o.......*.........*....X..#',
      '#............................#',
      '##############################'] },
    { n: '돌벌레 굴', q: 14, t: 150, m: [
      '##############################',
      '#P...*......*.......*........#',
      '#.......o.......o.......o....#',
      '#..*...      ...*...      .*.#',
      '#......  B   .......  B   ...#',
      '#..o...      ...o...      ...#',
      '#.....*..............*.......#',
      '#..*.*...o.....*.*.....o..*..#',
      '#.........   ......   .......#',
      '#...*.... B  ..*...  B ...*..#',
      '#.........   ......   .......#',
      '#..o..*........o.........o...#',
      '#.......*..*.......*..*......#',
      '#..*.........o.........*..X..#',
      '#............................#',
      '##############################'] },
    { n: '석벽 미로와 문', q: 14, t: 150, m: [
      '##############################',
      '#P....w.....*....w...*.......#',
      '#..d..w..ooo.....w..ooo..*...#',
      '#..*..w..***.T...w..***......#',
      '#.....w..........w...........#',
      '#wwww.wwwwwww..wwwwww.wwww.ww#',
      '#....*......o........*.......#',
      '#..ooo..*...*...ooo...d..*...#',
      '#..***..........***..........#',
      '#ww.wwwwwww.wwwwwwwww.wwwwww.#',
      '#.......*......o......*......#',
      '#..*.....oo....*...........*.#',
      '#........**.........o..*..T..#',
      '#..o..........*.............X#',
      '#.....*......................#',
      '##############################'] },
    { n: '마법의 석판', q: 14, t: 150, mw: 18, m: [
      '##############################',
      '#P...*...ooooo.ooooo....*....#',
      '#........ooooo.ooooo.........#',
      '#..*.....................*...#',
      '#....mmmmmmmmmmmmmmmmmmmm....#',
      '#....                    ....#',
      '#....                    ..*.#',
      '#....wwwwwwwwwwwwwwwwwwww....#',
      '#..*......*.......*..........#',
      '#......o.....*.......o.....*.#',
      '#..*.........................#',
      '#.....*..ooo....*....ooo.....#',
      '#........***.........***.....#',
      '#..o.........*...........X...#',
      '#............................#',
      '##############################'] },
    { n: '점액과 거미', q: 14, t: 150, m: [
      '##############################',
      '#P.....*.......*........*....#',
      '#..o.......o........o........#',
      '#.....*.......*.....R..*.....#',
      '#..*.....o.......*.......o...#',
      '#..........  a  .............#',
      '#....*.....     ........*....#',
      '#..o.......*........o........#',
      '#.......*.....ooo*.......*...#',
      '#..*.........o...............#',
      '#.....o.....*. S  *.....o....#',
      '#..*.....*....    ..*......*.#',
      '#....R....o.....*........o...#',
      '#..*........*.........*...X..#',
      '#............................#',
      '##############################'] },
    { n: '깊은 수직갱', q: 22, t: 180, m: [
      '####################################',
      '#P...o.o.o.......*......o...*......#',
      '#....*.*.*....oooo......o..........#',
      '#.............****....  F  ...*....#',
      '#..oo.....*.........    ...........#',
      '#..**..........*...........oo..*...#',
      '#.......wwwwwwwww.........****.....#',
      '#..*....w.......w..*...............#',
      '#.......w...*...w.......o..o..o....#',
      '#..o.......***.......*..*..*..*....#',
      '#......o.........o.................#',
      '#.....   B   ...........*......*...#',
      '#.....       ..*...o.......ooo.....#',
      '#..*...........*...*.......***.....#',
      '#......*..ooo..............   ..*..#',
      '#.........***......*....  F  ......#',
      '#..o...............................#',
      '#.......*.....o..*.....*......X....#',
      '#..................................#',
      '####################################'] },
    { n: '심연의 문', q: 24, t: 190, mw: 16, m: [
      '####################################',
      '#P......*....oooooooo.......*......#',
      '#..*.........o******o.........U....#',
      '#............oooooooo.....*........#',
      '#.....*....................  F  ...#',
      '#..mmmmmmmmmm.......*.......   ....#',
      '#..          ...o...........*......#',
      '#..          ..*.*.....ooo.........#',
      '#..wwwwwwwwww..........***...*.....#',
      '#......*..........*......R.........#',
      '#...o.......  a  .........o.o.o....#',
      '#..***......     ....*....*.*.*....#',
      '#.......*.d.......................*#',
      '#..*.....   B   ......*....oo......#',
      '#........       ...........**..*...#',
      '#..o.......*.......ooo.............#',
      '#...U.*.......*....***......*......#',
      '#..*.......o..............o....X...#',
      '#..................................#',
      '####################################'] },
  ];
  const HAND = STAGES.length;

  function parseMap(def) {
    const rows = def.m, h = rows.length, w = rows[0].length;
    const c = new Uint8Array(w * h), st = [];
    let ex = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const ch = rows[y][x] || '.', i = y * w + x;
      let v;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) v = ST;
      else if (ch === 'P') { v = E; st.push(i); }
      else if (ch === 'X') { v = XC; ex = i; }
      else if (ch === 'F') v = FF + 3;
      else if (ch === 'B') v = BG + 1;
      else { v = CH.indexOf(ch); if (v < 0 || (v >= FF && v < RB) || v === DL) v = DI; }
      c[i] = v;
    }
    return { w, h, c, st, ex, q: def.q, t: def.t, mw: def.mw || 15, name: def.n };
  }

  /* ---------- generator ---------- */
  function genCave(seed, diff, opt) {
    opt = opt || {};
    const R = rng(seed), vs = !!opt.vs;
    const w = vs ? 41 : Math.min(40, 30 + Math.floor(diff / 2) * 2), h = vs ? 22 : Math.min(22, 16 + Math.floor(diff / 3));
    const c = new Uint8Array(w * h).fill(DI);
    const at = (x, y) => y * w + x;
    const inner = (x, y) => x > 0 && y > 0 && x < w - 1 && y < h - 1;
    const xMax = vs ? (w - 1) / 2 : w - 1;      // vs: build the left half (+ centre column), then mirror
    const rockD = vs ? 0.12 : Math.min(0.15, 0.085 + diff * 0.004), gemD = vs ? 0.075 : 0.055, voidD = 0.045;
    for (let y = 1; y < h - 1; y++) for (let x = 1; x <= xMax && x < w - 1; x++) {
      const r = R();
      c[at(x, y)] = r < rockD ? RK : r < rockD + gemD ? GM : r < rockD + gemD + voidD ? E : DI;
    }
    // rock piles hiding gems
    const piles = 1 + Math.floor(R() * 3);
    for (let k = 0; k < piles; k++) {
      const x0 = 2 + Math.floor(R() * (xMax - 6)), y0 = 3 + Math.floor(R() * (h - 7)), pw = 2 + Math.floor(R() * 3);
      for (let x = x0; x < x0 + pw + 2 && x <= xMax; x++) { if (inner(x, y0 - 1)) c[at(x, y0 - 1)] = RK; if (inner(x, y0) && (x === x0 || x === x0 + pw + 1)) c[at(x, y0)] = RK; else if (inner(x, y0)) c[at(x, y0)] = GM; }
    }
    // stone walls
    if (diff >= 2) {
      const nw = Math.min(5, 1 + Math.floor(diff / 3));
      for (let k = 0; k < nw; k++) {
        const horiz = R() < 0.6, len = 4 + Math.floor(R() * 6);
        const x0 = 2 + Math.floor(R() * (xMax - 3)), y0 = 3 + Math.floor(R() * (h - 6)), gap = Math.floor(R() * len);
        for (let k2 = 0; k2 < len; k2++) {
          if (k2 === gap) continue;
          const x = horiz ? x0 + k2 : x0, y = horiz ? y0 : y0 + k2;
          if (inner(x, y) && x <= xMax) c[at(x, y)] = BW;
        }
      }
    }
    // enemy chambers
    const nE = vs ? 3 : Math.min(5, Math.floor((diff + 2) / 3));
    for (let k = 0; k < nE; k++) {
      const cw = 3 + Math.floor(R() * 3), chh = 2 + Math.floor(R() * 2);
      const x0 = 2 + Math.floor(R() * Math.max(1, xMax - cw - 3)), y0 = 4 + Math.floor(R() * Math.max(1, h - chh - 6));
      for (let y = y0; y < y0 + chh; y++) for (let x = x0; x < x0 + cw; x++) if (inner(x, y) && x <= xMax) c[at(x, y)] = E;
      const ex = x0 + Math.floor(cw / 2), ey = y0 + chh - 1;
      if (inner(ex, ey) && ex <= xMax) c[at(ex, ey)] = (diff >= 3 && R() < 0.4) ? BG + 1 : FF + 3;
      // a lid of rocks over some chambers (drop them to crush the enemy)
      if (R() < 0.6) for (let x = x0; x < x0 + cw; x++) if (inner(x, y0 - 2) && x <= xMax && c[at(x, y0 - 2)] !== ST) c[at(x, y0 - 2)] = RK;
    }
    // magic wall
    let mw = 15;
    if (!vs && diff >= 5 && R() < 0.55) {
      const len = 6 + Math.floor(R() * 6), x0 = 2 + Math.floor(R() * Math.max(1, w - len - 4)), y0 = 4 + Math.floor(R() * Math.max(1, h - 9));
      for (let x = x0; x < x0 + len; x++) {
        c[at(x, y0)] = MG; c[at(x, y0 + 1)] = E; c[at(x, y0 + 2)] = E;
        if (inner(x, y0 - 2) && R() < 0.6) c[at(x, y0 - 2)] = RK;
        if (inner(x, y0 + 3)) c[at(x, y0 + 3)] = BW;
      }
      mw = 14 + Math.floor(R() * 8);
    }
    // slime
    if (!vs && diff >= 7 && R() < 0.45) {
      const x = 4 + Math.floor(R() * (w - 8)), y = 5 + Math.floor(R() * (h - 9));
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) c[at(x + dx, y + dy)] = E;
      c[at(x, y)] = SL;
    }
    // round 26 — dynamite sticks (also in vs: built on the left half, mirrored)
    const nDy = vs ? 2 : diff >= 1 ? 1 + Math.floor(R() * 2) : 0;
    for (let k = 0; k < nDy; k++) { const x = 2 + Math.floor(R() * (xMax - 3)), y = 2 + Math.floor(R() * (h - 4)); if (inner(x, y) && c[at(x, y)] === DI) c[at(x, y)] = DY; }
    // 굴토끼: digs random tunnels (can undermine rocks)
    if (!vs && diff >= 3) {
      const nR = Math.min(3, Math.floor(diff / 3));
      for (let k = 0; k < nR; k++) { const x = 3 + Math.floor(R() * (w - 6)), y = 3 + Math.floor(R() * (h - 6)); if (c[at(x, y)] === DI || c[at(x, y)] === E) c[at(x, y)] = RB; }
    }
    // 수정 거미 in a small hollow (spins webs; crush it for 9 gems)
    if (!vs && diff >= 4 && R() < 0.65) {
      const x0 = 3 + Math.floor(R() * (w - 9)), y0 = 4 + Math.floor(R() * (h - 8));
      for (let y = y0; y < y0 + 2; y++) for (let x = x0; x < x0 + 4; x++) c[at(x, y)] = E;
      c[at(x0 + 1, y0 + 1)] = SP;
      if (R() < 0.6) for (let x = x0; x < x0 + 4; x++) if (inner(x, y0 - 2)) c[at(x, y0 - 2)] = RK;
    }
    // mirror for vs
    if (vs) for (let y = 1; y < h - 1; y++) for (let x = 1; x < (w - 1) / 2; x++) {
      let v = c[at(x, y)];
      if (v >= FF && v < BG) v = FF + ((v - FF) === 1 ? 3 : (v - FF) === 3 ? 1 : v - FF);
      else if (v >= BG && v < PL) v = BG + ((v - BG) === 1 ? 3 : (v - BG) === 3 ? 1 : v - BG);
      c[at(w - 1 - x, y)] = v;
    }
    // borders
    for (let x = 0; x < w; x++) { c[at(x, 0)] = ST; c[at(x, h - 1)] = ST; }
    for (let y = 0; y < h; y++) { c[at(0, y)] = ST; c[at(w - 1, y)] = ST; }
    // starts + exit
    const st = vs ? [at(1, 1), at(w - 2, 1), at(1, h - 2), at(w - 2, h - 2)] : [at(1, 1)];
    for (const s of st) {
      const sx = s % w, sy = (s / w) | 0;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) { const x = sx + dx, y = sy + dy; if (inner(x, y)) { const v = c[at(x, y)]; if (v === RK || isEn(v) || v === E || v === SL || v === MG || v === RB || v === SP) c[at(x, y)] = DI; } }
      c[s] = E;
    }
    let ex;
    if (vs) ex = at((w - 1) / 2, (h / 2) | 0);
    else ex = at(w - 3 - Math.floor(R() * 6), h - 2 - Math.floor(R() * 4));
    c[ex] = XC;
    if (c[ex - w] === RK) c[ex - w] = DI;
    // teleport doors: one pair (two at depth 9+), far apart, landing cells around each door kept open
    if (!vs && diff >= 5 && R() < 0.6) {
      const pairs = diff >= 9 && R() < 0.5 ? 2 : 1, sx0 = st[0] % w, sy0 = (st[0] / w) | 0;
      for (let pr = 0; pr < pairs; pr++) {
        const pos = [];
        for (let tries = 0; tries < 40 && pos.length < 2; tries++) {
          const x = 3 + Math.floor(R() * (w - 6)), y = 3 + Math.floor(R() * (h - 6)), i = at(x, y);
          if (Math.abs(x - sx0) + Math.abs(y - sy0) < 5 || Math.abs(x - ex % w) + Math.abs(y - ((ex / w) | 0)) < 3) continue;
          if (pos.length && Math.abs(x - pos[0] % w) < (w / 3)) continue;
          let ok = true; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const v = c[at(x + dx, y + dy)]; if (v === XC || isDoor(v) || v === ST) ok = false; }
          if (ok) pos.push(i);
        }
        if (pos.length < 2) break;
        for (const i of pos) { c[i] = pr ? TB : TA; for (const d of [-w, 1, w, -1]) if (c[i + d] !== ST && c[i + d] !== XC) c[i + d] = c[i + d] === GM ? GM : DI; if (c[i - w - w] === RK) c[i - w - w] = DI; }
      }
    }
    let gems = 0; for (let i = 0; i < c.length; i++) if (c[i] === GM) gems++;
    const q = vs ? Math.max(8, Math.round(gems * 0.3)) : Math.max(6, Math.round(gems * (0.4 + Math.min(0.15, diff * 0.006))));
    const t = vs ? VS_TIME : Math.min(210, 120 + diff * 6);
    return { w, h, c, st, ex, q, t, mw, name: '' };
  }

  /* ---------- world ---------- */
  function newWorld(cave, nPl, opt) {
    opt = opt || {};
    const n = cave.w * cave.h;
    const W = {
      w: cave.w, h: cave.h, g: Uint8Array.from(cave.c), f: new Uint8Array(n), dn: new Uint8Array(n),
      tick: 0, tl: Math.round(cave.t / TICK), q: cave.q, mw: 0, mwd: Math.round((cave.mw || 15) / TICK),
      slmax: Math.round((cave.w - 2) * (cave.h - 2) * 0.18), slp: 0.035, rs: (opt.seed >>> 0) || 12345,
      ex: cave.ex, xo: false, vs: !!opt.vs, pl: [], pend: [], ev: [], mv: [], firstOut: -1,
    };
    for (let s = 0; s < nPl; s++) {
      const st = cave.st[s % cave.st.length];
      W.g[st] = PL + s;
      W.pl.push({ i: st, a: 1, gm: 0, dn: 0, fc: 2, pu: 0, rt: 0, st, dd: 0, die: 0, dy: 0, sl: 0 });
    }
    // teleport door pairs: tp[door] = the other door of the same colour
    const tp = new Int32Array(n).fill(-1), seen = {};
    for (let i = 0; i < n; i++) { const c = W.g[i]; if (!isDoor(c)) continue; if (seen[c] != null) { tp[i] = seen[c]; tp[seen[c]] = i; seen[c] = null; } else seen[c] = i; }
    W.tp = tp;
    return W;
  }
  function nearDL(W, i) { const g = W.g, w = W.w; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const j = i + dy * w + dx; if (j >= 0 && j < g.length && g[j] === DL) return true; } return false; }
  function wrand(W) { W.rs = (W.rs + 0x6D2B79F5) | 0; let t = W.rs; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  function cloneW(W) {
    const C = Object.assign({}, W);
    C.g = W.g.slice(); C.f = W.f.slice(); C.ev = []; C.mv = []; C.pend = W.pend.map((p) => p.slice());
    C.pl = W.pl.map((p) => Object.assign({}, p));
    return C;
  }
  function offs(W) { return [-W.w, 1, W.w, -1]; }
  function mvCell(W, a, b) { W.g[b] = W.g[a]; W.g[a] = E; W.f[b] = W.f[a]; W.f[a] = 0; W.dn[b] = 1; W.mv.push(a, b); }

  function explode(W, c, prod) {
    const w = W.w, g = W.g, cx = c % w, cy = (c / w) | 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      const x = cx + dx, y = cy + dy;
      if (x < 0 || y < 0 || x >= w || y >= W.h) continue;
      const j = y * w + x, k = g[j];
      if (k === ST || k === XC || k === XO || isDoor(k)) continue;
      if (j !== c && k === DL) { W.pend.push([j, BX]); continue; } // 옆 다이너마이트도 곧 터짐
      if (isPl(k)) { const p = W.pl[k - PL]; if (p) { p.a = 0; p.rt = 0; p.die++; W.ev.push('k', j); } }
      else if (j !== c && isEn(k)) W.pend.push([j, k < BG ? BX + 1 : BX + 2]);
      g[j] = prod; W.f[j] = 0; W.dn[j] = 1;
    }
    W.ev.push('b', c);
  }
  function movePlayer(W, s, d) {
    const p = W.pl[s], g = W.g;
    if (!p || !p.a || p.dn) return;
    if (p.sl > 0) { p.sl--; p.pu = 0; return; }           // 거미줄에 걸려 잠깐 못 움직임
    if (d == null || d < 0) { p.pu = 0; return; }
    const o = offs(W);
    if (d >= 4) {                                            // 다이너마이트 놓기 (4 = 보는 쪽, 5..8 = 그 방향)
      const dir = d === 4 ? p.fc : (d - 5) & 3, j = p.i + o[dir], k = g[j];
      p.fc = dir; p.pu = 0;
      if (p.dy > 0 && (k === E || k === DI || k === WB)) { g[j] = DL; W.f[j] = FUSE; W.dn[j] = 1; p.dy--; W.ev.push('l', j); }
      return;
    }
    p.fc = d;
    const j = p.i + o[d], k = g[j];
    if (walkable(k)) {
      if (k === GM) { p.gm++; W.ev.push('g', j); } else if (k === DI) W.ev.push('d', j);
      else if (k === DY) { p.dy++; W.ev.push('y', j); }
      else if (k === WB) { p.sl = WEB_STUCK; W.ev.push('w', j); }
      g[j] = PL + s; g[p.i] = E; W.f[j] = 0; W.dn[j] = 1; W.mv.push(p.i, j); p.i = j; p.pu = 0;
    } else if (isDoor(k) && W.tp && W.tp[j] >= 0) {
      const dst = W.tp[j] + o[d], kd = g[dst];
      if (walkable(kd)) {
        if (kd === GM) { p.gm++; W.ev.push('g', dst); } else if (kd === DY) { p.dy++; W.ev.push('y', dst); }
        g[dst] = PL + s; g[p.i] = E; W.f[dst] = 0; W.dn[dst] = 1; W.ev.push('T', j, 'T', dst); p.i = dst; p.pu = 0;
      } else p.pu = 0;
    } else if (k === XO && p.gm >= W.q) {
      g[p.i] = E; W.mv.push(p.i, j); p.i = j; p.dn = 1; p.pu = 0; W.ev.push('x', j);
      if (W.vs) { p.gm += EXIT_BONUS; if (W.firstOut < 0) { W.firstOut = s; W.tl = Math.min(W.tl, Math.round(VS_AFTER_EXIT / TICK)); } }
    } else if (k === RK && (d === 1 || d === 3) && !W.f[j]) {
      const j2 = j + o[d];
      if (g[j2] === E) {
        p.pu++;
        if (p.pu >= 2) { mvCell(W, j, j2); g[j] = PL + s; g[p.i] = E; W.dn[j] = 1; W.mv.push(p.i, j); p.i = j; p.pu = 0; W.ev.push('p', j2); }
      } else p.pu = 0;
    } else p.pu = 0;
  }
  function fallObj(W, i, c) {
    const g = W.g, f = W.f, w = W.w, b = i + w, bc = g[b];
    if (bc === E || bc === WB) { mvCell(W, i, b); f[b] = 1; return; }
    if (f[i]) {
      if (bc === RB) { g[b] = GM; f[b] = 0; W.dn[b] = 1; f[i] = 0; W.ev.push('R', b); return; } // 굴토끼가 깔리면 보석 1개
      if (bc === SP) { explode(W, b, BX + 1); return; }                                         // 수정 거미 → 보석 3×3
      if (isPl(bc)) {
        const s = bc - PL, p = W.pl[s];
        if (c === GM) { g[i] = E; f[i] = 0; if (p) p.gm++; W.ev.push('g', b); }
        else explode(W, b, BX);
        return;
      }
      if (isEn(bc)) { explode(W, b, bc < BG ? BX + 1 : BX + 2); return; }
      if (bc === MG && W.mw >= 0) {
        if (W.mw === 0) { W.mw = W.mwd; W.ev.push('M', b); }
        const b2 = b + w;
        if (b2 < g.length && g[b2] === E) { g[b2] = c === RK ? GM : RK; f[b2] = 1; W.dn[b2] = 1; W.ev.push('m', b2); }
        g[i] = E; f[i] = 0;
        return;
      }
    }
    if (bc === RK || bc === GM || bc === BW) {
      if (g[i - 1] === E && g[b - 1] === E) { mvCell(W, i, i - 1); f[i - 1] = 1; return; }
      if (g[i + 1] === E && g[b + 1] === E) { mvCell(W, i, i + 1); f[i + 1] = 1; return; }
    }
    if (f[i]) { f[i] = 0; W.ev.push(c === RK ? 't' : 'c', i); }
  }
  function enemyStep(W, i, c) {
    const g = W.g, o = offs(W), ff = c < BG, base = ff ? FF : BG, d = c - base;
    for (let k = 0; k < 4; k++) {
      const v = g[i + o[k]];
      if ((isPl(v) && W.pl[v - PL] && W.pl[v - PL].a) || v === SL) { explode(W, i, ff ? BX + 1 : BX + 2); return; }
    }
    const turn = ff ? (d + 3) % 4 : (d + 1) % 4;
    if (g[i + o[turn]] === E) { const j = i + o[turn]; mvCell(W, i, j); g[j] = base + turn; }
    else if (g[i + o[d]] === E) { mvCell(W, i, i + o[d]); }
    else g[i] = base + (ff ? (d + 1) % 4 : (d + 3) % 4);
  }
  function rabbitStep(W, i) {
    const g = W.g, o = offs(W), k0 = (wrand(W) * 4) | 0;
    for (let t = 0; t < 4; t++) {
      const j = i + o[(k0 + t) & 3], v = g[j];
      if (v === E || v === DI) { if (v === DI) W.ev.push('h', j); mvCell(W, i, j); return; }
    }
  }
  function spiderStep(W, i) {
    const g = W.g, o = offs(W), k0 = (wrand(W) * 4) | 0;
    for (let t = 0; t < 4; t++) {
      const j = i + o[(k0 + t) & 3], v = g[j];
      if (v === E || v === WB) { mvCell(W, i, j); if (wrand(W) < 0.4) g[i] = WB; return; }
    }
  }
  function respawn(W, s) {
    const p = W.pl[s], w = W.w, g = W.g;
    const sx = p.st % w, sy = (p.st / w) | 0;
    for (let r = 0; r < 12; r++) {
      for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        if (nearDL(W, (sy + dy) * w + sx + dx)) continue;
        const x = sx + dx, y = sy + dy;
        if (x < 1 || y < 1 || x >= w - 1 || y >= W.h - 1) continue;
        const j = y * w + x;
        if (g[j] !== E && g[j] !== DI) continue;
        const up = g[j - w];
        if (up === RK || up === GM) continue;
        let bad = false;
        for (let yy = -2; yy <= 2 && !bad; yy++) for (let xx = -2; xx <= 2; xx++) { const k = j + yy * w + xx; if (k >= 0 && k < g.length && isEn(g[k])) { bad = true; break; } }
        if (bad) continue;
        g[j] = PL + s; W.f[j] = 0; W.dn[j] = 1; p.i = j; p.a = 1; p.rt = 0; p.pu = 0; p.fc = 2; W.ev.push('r', j);
        return true;
      }
    }
    return false;
  }
  function step(W, inp) {
    const w = W.w, g = W.g, f = W.f, dn = W.dn, n = w * W.h;
    W.ev.length = 0; W.mv.length = 0; dn.fill(0); W.tick++;
    for (let i = 0; i < n; i++) { const c = g[i]; if (c >= BX && c <= BX + 2) { g[i] = c === BX ? E : c === BX + 1 ? GM : RK; f[i] = 0; dn[i] = 1; } }
    if (W.pend.length) { const pe = W.pend; W.pend = []; for (const q of pe) { const k = g[q[0]]; if (k !== ST && k !== XC && k !== XO) explode(W, q[0], q[1]); } }
    for (let s = 0; s < W.pl.length; s++) movePlayer(W, s, inp ? inp[s] : -1);
    let slc = 0, slg = false;
    const o = offs(W);
    for (let i = w; i < n - w; i++) {
      if (dn[i]) continue;
      const c = g[i];
      if (c === RK || c === GM) fallObj(W, i, c);
      else if (c >= FF && c < PL) enemyStep(W, i, c);
      else if (c === SL) {
        slc++;
        for (let k = 0; k < 4; k++) { const v = g[i + o[k]]; if (v === E || v === DI) { slg = true; break; } }
        if (wrand(W) < W.slp) { const k = (wrand(W) * 4) | 0, j = i + o[k]; if (g[j] === E || g[j] === DI) { g[j] = SL; dn[j] = 1; } }
      }
      else if (c === RB) { if ((W.tick + i) % 2 === 0) rabbitStep(W, i); }
      else if (c === SP) { if ((W.tick + i) % 3 === 0) spiderStep(W, i); }
      else if (c === DL) { if (f[i] > 1) f[i]--; else { f[i] = 0; explode(W, i, BX); } }
    }
    if (slc > 0 && (slc >= W.slmax || !slg)) {
      const to = slc >= W.slmax ? RK : GM;
      for (let i = 0; i < n; i++) if (g[i] === SL) { g[i] = to; f[i] = 0; }
      W.ev.push(to === GM ? 's' : 'S', 0);
    }
    if (W.mw > 0) { W.mw--; if (W.mw === 0) W.mw = -1; }
    if (!W.xo && W.pl.some((p) => p.gm >= W.q)) { W.xo = true; if (g[W.ex] === XC) g[W.ex] = XO; W.ev.push('o', W.ex); }
    if (W.xo && g[W.ex] === XC) g[W.ex] = XO;
    if (W.vs) for (let s = 0; s < W.pl.length; s++) {
      const p = W.pl[s];
      if (p.a || p.dn) continue;
      if (p.rt === 0) p.gm = Math.max(0, p.gm - DEATH_COST);
      p.rt++;
      if (p.rt >= RESP) respawn(W, s);
    }
    W.tl--;
  }
  // solo: 'clear' | 'dead' | 'time' | null ; vs: true when over
  function soloOutcome(W) { const p = W.pl[0]; if (p.dn) return 'clear'; if (!p.a) return 'dead'; if (W.tl <= 0) return 'time'; return null; }
  function vsOver(W) { if (W.tl <= 0) return true; return W.pl.every((p) => p.dn); }

  /* ---------- bot ---------- */
  function distField(W, s, wantExit, out, exitOnly) {
    const w = W.w, g = W.g, n = w * W.h, o = offs(W);
    const dist = out && out.length === n ? out : new Int16Array(n);
    dist.fill(-1);
    const danger = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      const c = g[i];
      if (isEn(c)) { danger[i] = 1; for (let k = 0; k < 4; k++) { const j = i + o[k]; if (j >= 0 && j < n) { danger[j] = 1; const j2 = j + o[k]; if (j2 >= 0 && j2 < n) danger[j2] = 1; } } }
      else if ((c === RK || c === GM) && W.f[i] && i + w < n) { danger[i + w] = 1; if (i + 2 * w < n) danger[i + 2 * w] = 1; }
      else if (c === DL) for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const j = i + dy * w + dx; if (j >= 0 && j < n) danger[j] = 1; }
    }
    const qa = new Int32Array(n);
    let qh = 0, qt = 0;
    for (let i = 0; i < n; i++) {
      const c = g[i];
      if (((c === GM || c === DY) && !danger[i] && !exitOnly) || (wantExit && c === XO)) { dist[i] = 0; qa[qt++] = i; }
    }
    const tp = W.tp;
    const me = PL + s;
    while (qh < qt) {
      const i = qa[qh++], d = dist[i] + 1;
      for (let k = 0; k < 4; k++) {
        const j = i + o[k];
        if (j < 0 || j >= n || dist[j] >= 0 || danger[j]) continue;
        const c = g[j];
        if (c === E || c === DI || c === GM || c === WB || c === DY || c === me) { dist[j] = d; qa[qt++] = j; }
      }
      if (tp) for (let k = 0; k < 4; k++) { // through a door: from a, stepping k into door D, you land at partner(D) + o[k] = i
        const q = i - o[k], P = q >= 0 && q < n ? tp[q] : -1;
        if (P < 0) continue;
        const a = P - o[k];
        if (a < 0 || a >= n || dist[a] >= 0 || danger[a]) continue;
        const c = g[a];
        if (c === E || c === DI || c === GM || c === WB || c === DY || c === me) { dist[a] = d; qa[qt++] = a; }
      }
    }
    return dist;
  }
  function survives(W, s, d, depth, dist) {
    const C = cloneW(W), o = offs(W), inp = C.pl.map(() => -1);
    inp[s] = d;
    step(C, inp);
    for (let k = 1; k < depth; k++) {
      const p = C.pl[s];
      if (!p.a || p.dn) break;
      let bd = -1, bv = dist[p.i] >= 0 ? dist[p.i] : 9999;
      for (let q = 0; q < 4; q++) { const j = p.i + o[q], v = dist[j]; if (v >= 0 && v < bv) { bv = v; bd = q; } }
      inp[s] = bd; step(C, inp);
    }
    const p = C.pl[s];
    if (p.dn) return true;
    if (!p.a) return false;
    for (let q = 0; q < 4; q++) if (isEn(C.g[p.i + o[q]])) return false;
    return true;
  }
  function botDir(W, s, lv, mem) {
    const p = W.pl[s];
    if (!p || !p.a || p.dn) return -1;
    mem = mem || {};
    lv = lv || 2;
    const rnd = mem.rnd || Math.random;
    if (lv === 1 && rnd() < 0.28) return -1;           // beginner hesitates
    if (lv === 2 && rnd() < 0.06) return -1;
    const o = offs(W);
    if (p.sl > 0) return -1;
    if (nearDL(W, p.i)) { const e = escapeDir(W, s); if (e >= 0) { mem.last = e; return e; } }
    let wantExit = W.xo && p.gm >= W.q;
    if (wantExit && W.vs) {
      const best = Math.max(...W.pl.map((q, k) => (k === s ? -1 : q.gm)));
      const tLeft = W.tl * TICK;
      if (lv === 1) wantExit = true;
      else if (lv === 2) wantExit = p.gm >= best + 6 || tLeft < 35;
      else { let left = 0; for (let i = 0; i < W.g.length; i++) if (W.g[i] === GM) left++; wantExit = tLeft < 25 || (p.gm + EXIT_BONUS > best && tLeft < 40) || (p.gm >= best + 3 && left < 8); }
    }
    mem.df = distField(W, s, wantExit, mem.df, wantExit && (!W.vs || W.tl * TICK < 30));
    let dist = mem.df;
    if (dist[p.i] < 0 && wantExit) dist = mem.df = distField(W, s, true, mem.df, false);
    if (dist[p.i] < 0 && W.xo && p.gm >= W.q && !wantExit) dist = mem.df = distField(W, s, true, mem.df);
    const cands = [];
    for (let d = 0; d < 4; d++) {
      const j = p.i + o[d], c = W.g[j];
      let v = dist[j] >= 0 ? dist[j] : 5000;
      if (c === RK && (d === 1 || d === 3) && W.g[j + o[d]] === E) v = dist[p.i] < 0 ? 900 : 6000;
      else if (isDoor(c) && W.tp[j] >= 0) { const l = W.tp[j] + o[d]; if (!walkable(W.g[l])) continue; v = dist[l] >= 0 ? dist[l] : 5000; }
      else if (c === DL) continue;
      else if (!(walkable(c) || (c === XO && p.gm >= W.q))) continue;
      cands.push([d, v]);
    }
    const here = dist[p.i] >= 0 ? dist[p.i] + 0.5 : 4000;
    if (dist[p.i] < 0) {
      // no safe target reachable: wander toward the nearest gem by straight-line distance, digging
      let gx = -1, gy = -1, bd = 1e9; const px = p.i % W.w, py = (p.i / W.w) | 0;
      for (let i = 0; i < W.g.length; i++) if (W.g[i] === GM || (W.xo && p.gm >= W.q && W.g[i] === XO)) { const dd = Math.abs(i % W.w - px) + Math.abs(((i / W.w) | 0) - py); if (dd < bd) { bd = dd; gx = i % W.w; gy = (i / W.w) | 0; } }
      for (const cd of cands) {
        if (cd[1] >= 900 && cd[1] < 1000) continue;
        const j = p.i + o[cd[0]], x = j % W.w, y = (j / W.w) | 0;
        cd[1] = 1000 + (gx >= 0 ? Math.abs(x - gx) + Math.abs(y - gy) : 0) + rnd() * 3 + (mem.last === ((cd[0] + 2) % 4) ? 2 : 0);
      }
    }
    cands.push([-1, here]);
    cands.sort((a, b) => a[1] - b[1]);
    // stuck: no gem for long → random burst
    if (mem.gm !== p.gm) { mem.gm = p.gm; mem.idle = 0; } else mem.idle = (mem.idle || 0) + 1;
    // stuck with dynamite in the pocket: blast a wall/rock next to me, then run (escape logic above)
    if (lv >= 2 && p.dy > 0 && (dist[p.i] < 0 || mem.idle > 90) && (mem.boom || 0) <= W.tick) {
      const bd = blastDir(W, s);
      if (bd >= 0) { mem.boom = W.tick + FUSE + 8; mem.idle = 0; return 5 + bd; }
    }
    if (mem.idle > 160 && rnd() < 0.5) { for (let k = cands.length - 1; k > 0; k--) { const r = (rnd() * (k + 1)) | 0; const t = cands[k]; cands[k] = cands[r]; cands[r] = t; } if (mem.idle > 200) mem.idle = 0; }
    const noise = lv === 1 ? 0.18 : lv === 2 ? 0.04 : 0;
    if (noise && rnd() < noise && cands.length > 2) { const r = 1 + ((rnd() * (cands.length - 1)) | 0); const t = cands[0]; cands[0] = cands[r]; cands[r] = t; }
    const depth = lv === 1 ? 1 : lv === 2 ? 3 : 5;
    for (const cd of cands) {
      if (lv === 1 && rnd() < 0.15) { mem.last = cd[0]; return cd[0]; }       // sometimes skips the safety look
      if (survives(W, s, cd[0], depth, dist)) { mem.last = cd[0]; return cd[0]; }
    }
    return -1;
  }

  function escapeDir(W, s) { // BFS to the nearest cell outside every lit dynamite's 3×3 blast
    const p = W.pl[s], g = W.g, n = g.length, o = offs(W), from = new Int16Array(n).fill(-1), qa = [p.i];
    from[p.i] = 4;
    for (let h = 0; h < qa.length && h < 200; h++) {
      const i = qa[h];
      if (i !== p.i && !nearDL(W, i)) { let c = i; while (from[c] < 4 && c - o[from[c]] !== p.i) c -= o[from[c]]; return from[c] < 4 ? from[c] : -1; }
      for (let k = 0; k < 4; k++) {
        const j = i + o[k];
        if (j < 0 || j >= n || from[j] >= 0) continue;
        const c = g[j], up = g[j - W.w];
        if (!walkable(c)) continue;
        if ((up === RK || up === GM) && W.f[j - W.w]) continue;
        from[j] = k; qa.push(j);
      }
    }
    return -1;
  }
  function blastDir(W, s) { // a neighbour where a stick would break brick/rock, with a way out that isn't through the blast
    const p = W.pl[s], g = W.g, o = offs(W), w = W.w;
    for (let d = 0; d < 4; d++) {
      const j = p.i + o[d], c = g[j];
      if (!(c === E || c === DI || c === WB)) continue;
      if (g[j - w] === RK) continue;
      let hit = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const v = g[j + dy * w + dx]; if (v === BW || v === RK) hit++; }
      if (!hit) continue;
      // escape route: a walkable cell 2+ away from j reachable from my side
      let out = false;
      for (let k = 0; k < 4 && !out; k++) { if (k === d) continue; const a = p.i + o[k]; if (!walkable(g[a]) && g[a] !== E) continue; for (let k2 = 0; k2 < 4; k2++) { const b2 = a + o[k2]; if (b2 !== p.i && walkable(g[b2]) && Math.max(Math.abs(b2 % w - j % w), Math.abs(((b2 / w) | 0) - ((j / w) | 0))) >= 2) { out = true; break; } } }
      if (out) return d;
    }
    return -1;
  }

  /* ---------- solo stage factory (validated by the bot) ---------- */
  const stageCache = {};
  function playTest(cave, seed, maxTicks) {
    const W = newWorld(cave, 1, { seed });
    const mem = { rnd: rng(seed ^ 0x55aa) };
    const lim = maxTicks || W.tl + 5;
    let lastG = 0, lastT = 0;
    for (let t = 0; t < lim; t++) {
      step(W, [botDir(W, 0, 3, mem)]);
      if (W.pl[0].gm !== lastG) { lastG = W.pl[0].gm; lastT = t; } else if (t - lastT > 220) return { ok: false, gm: lastG };
      const r = soloOutcome(W);
      if (r) return r === 'clear' ? { ok: true, ticks: W.tick, gm: W.pl[0].gm } : { ok: false, gm: W.pl[0].gm };
    }
    return { ok: false, gm: W.pl[0].gm };
  }
  function stageCave(n) {
    if (stageCache[n]) return stageCache[n];
    let cave;
    if (n <= HAND) cave = parseMap(STAGES[n - 1]);
    else {
      const diff = n - HAND;
      let bestFail = null;
      for (let k = 0; k < 10 && !cave; k++) {
        const d2 = k < 6 ? diff : Math.max(0, diff - (k - 5) * 2);
        const c = genCave(hash2(n, k), d2, {});
        const r = playTest(c, hash2(n, 99));
        if (r.ok) { cave = c; if (r.ticks > c.t / TICK * 0.8) c.t = Math.min(240, c.t + 30); }
        else if (!bestFail || r.gm > bestFail.r.gm) bestFail = { c, r };
      }
      if (!cave) { // by construction: the bot reached this many gems — make that the quota and open the exit early
        cave = bestFail.c; cave.q = Math.max(1, Math.min(cave.q, bestFail.r.gm - 1)); cave.t += 40;
      }
      cave.name = '깊이 ' + n;
    }
    stageCache[n] = cave;
    return cave;
  }
  function vsCave(seed, n) { return genCave(seed, 4, { vs: true, n }); }

  /* ---------- network encoding ---------- */
  function rle(g) {
    let out = '', i = 0;
    const n = g.length;
    while (i < n) {
      const c = g[i]; let j = i + 1;
      while (j < n && g[j] === c && j - i < 999) j++;
      const run = j - i, ch = CH[c];
      out += run >= 3 ? run + ch : run === 2 ? ch + ch : ch;
      i = j;
    }
    return out;
  }
  function unrle(s, out) {
    let k = 0, num = 0;
    for (let i = 0; i < s.length && k < out.length; i++) {
      const ch = s.charCodeAt(i);
      if (ch >= 48 && ch <= 57) { num = num * 10 + ch - 48; continue; }
      const v = Math.max(0, CH.indexOf(s[i])), r = num || 1;
      for (let q = 0; q < r && k < out.length; q++) out[k++] = v;
      num = 0;
    }
    return out;
  }
  const b36 = (v) => { const s = Math.max(0, v | 0).toString(36); return s.length < 2 ? '0' + s : s.slice(-2); };
  function encMoves(W) {
    let s = '';
    for (let k = 0; k < W.mv.length; k += 2) {
      const a = W.mv[k], d = W.mv[k + 1] - a;
      s += b36(a) + (d === -W.w ? 'u' : d === 1 ? 'r' : d === W.w ? 'd' : 'l');
    }
    return s;
  }
  function encEv(W) { let s = ''; for (let k = 0; k < W.ev.length; k += 2) s += W.ev[k] + b36(W.ev[k + 1]); return s.slice(0, 400); }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    const vs = o.mode === 'vs' || players.length > 1;
    return {
      rid: 1 + U.rand(99999), n: players.length, m: vs ? 'v' : 's',
      nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      sd: 1 + U.rand(2147483646), ph: vs ? 'count' : 'pick',
      stg: 0, at: 0, lf: 3, cl: 0, sc: 0, top: 0, res: null,
    };
  }
  // 첫 판 조작 안내(이 기기에서 한 번만, 탭하거나 4.5초 뒤 사라짐)
  function firstHint(root, api, id, lines) {
    if (!api.mySeats || !api.mySeats().length) return null;
    const k = 'lounge.hint.' + id;
    try { if (localStorage.getItem(k)) return null; localStorage.setItem(k, '1'); } catch (e) { return null; }
    const el = L.h('div', { style: 'position:absolute;left:50%;top:18%;transform:translateX(-50%);z-index:20;width:min(320px,calc(100% - 32px));box-sizing:border-box;background:rgba(14,10,20,.9);border:1.5px solid rgba(227,174,69,.6);border-radius:16px;padding:10px 14px;color:#f2e9d8;font:600 13px/1.5 "IBM Plex Sans KR",system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.6);cursor:pointer;min-height:44px;pointer-events:auto' },
      L.h('div', { style: 'font:400 17px "Black Han Sans",sans-serif;color:#e3ae45;margin-bottom:2px', text: '조작 방법' }),
      ...lines.map((t) => L.h('div', { text: '· ' + t })),
      L.h('div', { style: 'margin-top:4px;font-size:11px;opacity:.65;text-align:right', text: '탭해서 닫기' }));
    let tm = 0; const close = () => { clearTimeout(tm); el.remove(); };
    el.addEventListener('pointerdown', (e) => { e.stopPropagation(); close(); });
    tm = setTimeout(close, 4500); root.appendChild(el);
    return close;
  }
  function result(s) {
    if (!s || s.ph !== 'done') return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    if (s.m === 's') {
      return {
        winners: s.cl > 0 ? [0] : [],
        title: s.cl > 0 ? '탐사 끝 · ' + s.cl + '단계 돌파' : '탐사 끝',
        text: (s.top ? '가장 깊이 간 곳: ' + s.top + '단계' : '아직 돌파한 단계가 없어요') + '\n모은 점수 ' + (s.sc | 0) + '점',
        stats: [{ label: '돌파한 단계', value: String(s.cl | 0) }, { label: '가장 깊은 단계', value: String(s.top | 0) }, { label: '점수', value: String(s.sc | 0) }, { label: '도전 횟수', value: String((s.at | 0) + 1) }],
      };
    }
    const res = Array.isArray(s.res) ? s.res : [];
    if (!res.length) return { winners: [], title: '무승부', text: '' };
    const top = res[0][1];
    const win = res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  보석 ' + r[1] + (r[2] ? ' · 탈출' : ''));
    return { winners: win, title: win.length > 1 ? '공동 1위!' : nm(win[0]) + ' 승리!', text: lines.join('\n'),
      stats: [{ label: '모은 보석', values: Array.from({ length: s.n || res.length }, (_, i) => { const r = res.find((x) => x[0] === i); return r ? String(r[1]) : '-'; }) },
        { label: '탈출', values: Array.from({ length: s.n || res.length }, (_, i) => { const r = res.find((x) => x[0] === i); return r && r[2] ? '○' : '✕'; }) }] };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
.gc-pad{position:absolute;bottom:14px;width:168px;height:168px;z-index:5;touch-action:none;user-select:none;-webkit-user-select:none;border-radius:50%}
.gc-pad.r{right:12px}.gc-pad.l{left:12px}
.gc-pad i{position:absolute;width:56px;height:56px;border-radius:14px;background:rgba(30,24,36,.62);border:1px solid rgba(242,233,216,.22);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 3px 8px rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;color:rgba(242,233,216,.8);font:700 20px/1 system-ui;font-style:normal;pointer-events:none}
.gc-pad i.on{background:rgba(227,174,69,.42);border-color:rgba(227,174,69,.8);color:#fff}
.gc-pad .u{left:56px;top:0}.gc-pad .d{left:56px;bottom:0}.gc-pad .lf{left:0;top:56px}.gc-pad .rt{right:0;top:56px}
.gc-chip{position:absolute;z-index:6;appearance:none;border:1px solid rgba(242,233,216,.2);background:rgba(23,19,31,.8);color:var(--ink,#f2e9d8);border-radius:12px;min-height:44px;min-width:44px;padding:4px 10px;font:700 12px/1.2 "IBM Plex Sans KR",system-ui,sans-serif;display:flex;align-items:center;justify-content:center;gap:5px;cursor:pointer;touch-action:manipulation;user-select:none}
.gc-chip:active{transform:scale(.95)}
.gc-bomb{min-width:64px;min-height:52px;font-size:15px;border-color:rgba(238,106,85,.55);background:rgba(60,22,20,.82)}
.gc-ov{position:absolute;inset:0;z-index:8;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(10,7,14,.55)}
.gc-card{width:100%;max-width:380px;max-height:100%;overflow:auto;background:linear-gradient(180deg,#2a2233,#1c1724);border:1px solid rgba(227,174,69,.35);border-radius:18px;padding:16px;box-shadow:0 18px 50px rgba(0,0,0,.6);color:var(--ink,#f2e9d8);font-family:"IBM Plex Sans KR",system-ui,sans-serif}
.gc-card h3{margin:0 0 4px;font:400 22px/1.2 "Black Han Sans",sans-serif;color:var(--brass,#e3ae45);letter-spacing:.5px}
.gc-card p{margin:4px 0;font-size:13px;line-height:1.5;color:var(--muted,#ab9fb8)}
.gc-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:7px;margin:10px 0;max-height:300px;overflow:auto;padding:2px}
.gc-st{appearance:none;min-height:52px;border-radius:12px;border:1px solid rgba(242,233,216,.18);background:#2e2640;color:#f2e9d8;font:700 16px/1 "IBM Plex Mono",monospace;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;cursor:pointer;padding:2px}
.gc-st small{font:600 9px/1 "IBM Plex Sans KR",sans-serif;color:#ab9fb8}
.gc-st.cur{border-color:#e3ae45;background:#3d3046;box-shadow:0 0 0 1px #e3ae45 inset}
.gc-st:disabled{opacity:.35;cursor:default}
.gc-row{display:flex;gap:8px;margin-top:12px}.gc-row .btn{flex:1;min-height:48px}
.gc-stat{display:flex;justify-content:space-between;font:600 13px/1.9 "IBM Plex Sans KR",sans-serif;border-bottom:1px dashed rgba(242,233,216,.12)}
.gc-stat b{font-family:"IBM Plex Mono",monospace;color:#f2e9d8}
`;
  const DIRK = ['up', 'right', 'down', 'left'];

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    const mySeat = () => { const m = api.mySeats ? api.mySeats() : [0]; return m.length ? m[0] : -1; };
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const isAI = (s) => !!P(s).ai || !!(L.debug && L.debug.autoplay && s === mySeat());
    let st = null, key = null, W = null, cave = null, phase = 'wait', cd = 0, acc = 0, banner = null;
    let aiMem = [], parts = [], pops = [], flashes = [], shake = 0, sfxT = {};
    let lives = 3, curStage = 1, runScore = 0, cleared = 0, topStage = 0, endSent = false, readyT = 0;
    // guest view model
    let G = null, lastQ = -1, gTickAt = 0, gDur = TICK * 1000;
    const remB = {}, remBB = {}; // last tap / dynamite seq seen per remote seat
    let hsQ = 0;
    let cfg = { pad: 'r' };
    try { const c = JSON.parse(localStorage.getItem('lounge.gemcave.cfg') || 'null'); if (c && ['r', 'l', 'n'].includes(c.pad)) cfg.pad = c.pad; } catch (e) {}

    /* ---------- sprites ---------- */
    let cs = 32, spr = {};
    function mk(fn, v) {
      const c = document.createElement('canvas'); const px = Math.max(8, Math.round(cs * cv.dpr));
      c.width = px; c.height = px; const g = c.getContext('2d'); g.scale(px / cs, px / cs); fn(g, cs, v); return c;
    }
    function speck(g, s, R, n, cols, rmax) { for (let k = 0; k < n; k++) { g.fillStyle = cols[(R() * cols.length) | 0]; const r = 0.4 + R() * rmax; g.beginPath(); g.arc(R() * s, R() * s, r, 0, 7); g.fill(); } }
    function buildSprites() {
      cs = Math.max(26, Math.min(48, Math.floor(Math.min(cv.w / 11, cv.h / 14))));
      spr = {};
      spr.dirt = [0, 1, 2, 3].map((v) => mk((g, s) => {
        const R = rng(101 + v * 7);
        const gr = g.createLinearGradient(0, 0, s, s); gr.addColorStop(0, '#5a3f2b'); gr.addColorStop(1, '#3f2b1e');
        g.fillStyle = gr; g.fillRect(0, 0, s, s);
        speck(g, s, R, 26, ['#2c1d13', '#6e5038', '#4a3323', '#7a5a3e'], s * 0.05);
        for (let k = 0; k < 2; k++) { g.fillStyle = 'rgba(150,130,110,.35)'; g.beginPath(); g.ellipse(R() * s, R() * s, s * 0.07, s * 0.05, R() * 3, 0, 7); g.fill(); }
        g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 1; g.beginPath(); g.moveTo(0, s * (0.3 + R() * 0.4)); g.quadraticCurveTo(s * 0.5, s * R(), s, s * (0.3 + R() * 0.4)); g.stroke();
      }));
      spr.void = [0, 1].map((v) => mk((g, s) => {
        const R = rng(303 + v);
        g.fillStyle = '#100c12'; g.fillRect(0, 0, s, s);
        speck(g, s, R, 6, ['#1b161d', '#0a080b'], s * 0.06);
      }));
      spr.steel = [0, 1].map((v) => mk((g, s) => {
        const R = rng(505 + v);
        const gr = g.createLinearGradient(0, 0, 0, s); gr.addColorStop(0, '#3b3842'); gr.addColorStop(1, '#232129');
        g.fillStyle = gr; g.fillRect(0, 0, s, s);
        g.fillStyle = 'rgba(255,255,255,.07)'; g.fillRect(0, 0, s, 2); g.fillRect(0, 0, 2, s);
        g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(0, s - 2, s, 2); g.fillRect(s - 2, 0, 2, s);
        g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = 1.2; g.beginPath();
        let x = s * (0.2 + R() * 0.6), y = 0; g.moveTo(x, y);
        for (let k = 0; k < 3; k++) { x += (R() - 0.5) * s * 0.4; y += s / 3; g.lineTo(x, y); }
        g.stroke();
        speck(g, s, R, 8, ['#4a4652', '#1a181e'], s * 0.04);
      }));
      spr.brick = mk((g, s) => {
        g.fillStyle = '#2a211b'; g.fillRect(0, 0, s, s);
        const rows = [[0, 0.5, 1], [-0.25, 0.25, 0.75, 1.25]];
        for (let r = 0; r < 2; r++) {
          const y = r * s / 2 + 1, hh = s / 2 - 2;
          const xs = rows[r];
          for (let k = 0; k < xs.length - 1; k++) {
            const x0 = Math.max(0, xs[k] * s + 1), x1 = Math.min(s, xs[k + 1] * s - 1);
            const gr = g.createLinearGradient(0, y, 0, y + hh); gr.addColorStop(0, '#7b6551'); gr.addColorStop(1, '#4e3e31');
            g.fillStyle = gr; g.fillRect(x0, y, x1 - x0, hh);
            g.fillStyle = 'rgba(255,240,220,.1)'; g.fillRect(x0, y, x1 - x0, 1.2);
          }
        }
      });
      spr.rock = [0, 1].map((v) => mk((g, s) => {
        const R = rng(707 + v * 13);
        g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(s * 0.52, s * 0.9, s * 0.38, s * 0.08, 0, 0, 7); g.fill();
        g.beginPath();
        const N = 9;
        for (let k = 0; k <= N; k++) { const a = k / N * Math.PI * 2, r = s * (0.42 + (R() - 0.5) * 0.07); const x = s / 2 + Math.cos(a) * r, y = s * 0.52 + Math.sin(a) * r * 0.92; k ? g.lineTo(x, y) : g.moveTo(x, y); }
        g.closePath();
        const gr = g.createRadialGradient(s * 0.38, s * 0.34, s * 0.04, s * 0.5, s * 0.55, s * 0.5);
        gr.addColorStop(0, '#b3aa9b'); gr.addColorStop(0.45, '#7d756a'); gr.addColorStop(1, '#3a352f');
        g.fillStyle = gr; g.fill();
        g.strokeStyle = 'rgba(20,16,12,.6)'; g.lineWidth = 1; g.stroke();
        g.strokeStyle = 'rgba(30,24,20,.55)'; g.lineWidth = 1.1; g.beginPath();
        g.moveTo(s * (0.3 + R() * 0.2), s * 0.3); g.lineTo(s * 0.5, s * 0.5); g.lineTo(s * (0.55 + R() * 0.2), s * 0.72); g.stroke();
        speck(g, s, R, 7, ['rgba(255,255,255,.12)', 'rgba(0,0,0,.2)'], s * 0.03);
      }));
      spr.gem = [0, 1, 2].map((v) => mk((g, s) => {
        const cols = [['#5ef0e0', '#18a3a0', '#0b5a63'], ['#8fd7ff', '#3a86d8', '#173f7e'], ['#7af5b0', '#1fae6b', '#0d5a3a']][v];
        const cx = s / 2, cy = s * 0.5, r = s * 0.36;
        g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(cx, s * 0.88, r * 0.8, s * 0.06, 0, 0, 7); g.fill();
        const pts = [[cx, cy - r], [cx + r * 0.85, cy - r * 0.25], [cx + r * 0.6, cy + r * 0.75], [cx - r * 0.6, cy + r * 0.75], [cx - r * 0.85, cy - r * 0.25]];
        const tri = (a, b, col) => { g.fillStyle = col; g.beginPath(); g.moveTo(cx, cy); g.lineTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.closePath(); g.fill(); };
        tri(pts[0], pts[1], cols[0]); tri(pts[1], pts[2], cols[1]); tri(pts[2], pts[3], cols[2]); tri(pts[3], pts[4], cols[1]); tri(pts[4], pts[0], cols[0]);
        g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 0.8; g.beginPath(); pts.forEach((p, k) => (k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.closePath(); g.stroke();
        g.fillStyle = 'rgba(255,255,255,.75)'; g.beginPath(); g.moveTo(cx - r * 0.3, cy - r * 0.55); g.lineTo(cx - r * 0.05, cy - r * 0.62); g.lineTo(cx - r * 0.35, cy - r * 0.2); g.closePath(); g.fill();
      }, v));
      spr.door = [0, 1].map((v) => mk((g, s) => {
        g.fillStyle = '#26222b'; g.fillRect(0, 0, s, s);
        g.fillStyle = '#4a4350'; g.beginPath(); g.moveTo(s * 0.1, s); g.lineTo(s * 0.1, s * 0.4); g.arc(s / 2, s * 0.4, s * 0.4, Math.PI, 0); g.lineTo(s * 0.9, s); g.closePath(); g.fill();
        const gr = g.createLinearGradient(0, s * 0.1, 0, s);
        if (v) { gr.addColorStop(0, '#ffe7a8'); gr.addColorStop(1, '#e39a2d'); } else { gr.addColorStop(0, '#0d0a0f'); gr.addColorStop(1, '#1c1820'); }
        g.fillStyle = gr; g.beginPath(); g.moveTo(s * 0.22, s); g.lineTo(s * 0.22, s * 0.42); g.arc(s / 2, s * 0.42, s * 0.28, Math.PI, 0); g.lineTo(s * 0.78, s); g.closePath(); g.fill();
        if (!v) { g.strokeStyle = '#6d6470'; g.lineWidth = 2; for (let k = 0; k < 3; k++) { const x = s * (0.32 + k * 0.18); g.beginPath(); g.moveTo(x, s * 0.2 + (k === 1 ? 0 : s * 0.05)); g.lineTo(x, s); g.stroke(); } }
      }));
      spr.magic = [0, 1].map((v) => mk((g, s) => {
        g.fillStyle = v ? '#2b1f3e' : '#231e2c'; g.fillRect(0, 0, s, s);
        g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(0, 0, s, 2);
        g.strokeStyle = v ? '#c49bff' : '#5a4f6b'; g.lineWidth = 1.6; g.beginPath();
        g.moveTo(s * 0.5, s * 0.15); g.lineTo(s * 0.5, s * 0.85); g.moveTo(s * 0.25, s * 0.35); g.lineTo(s * 0.5, s * 0.55); g.lineTo(s * 0.75, s * 0.35);
        g.moveTo(s * 0.3, s * 0.8); g.lineTo(s * 0.7, s * 0.8); g.stroke();
        g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(0, s - 2, s, 2);
      }));
      spr.web = mk((g, s) => {
        g.strokeStyle = 'rgba(236,232,246,.55)'; g.lineWidth = 0.9;
        const cx = s / 2, cy = s / 2;
        g.beginPath(); for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4 + 0.2; g.moveTo(cx, cy); g.lineTo(cx + Math.cos(a) * s * 0.55, cy + Math.sin(a) * s * 0.55); } g.stroke();
        g.strokeStyle = 'rgba(236,232,246,.4)';
        for (const r of [0.14, 0.26, 0.38]) { g.beginPath(); for (let k = 0; k <= 8; k++) { const a = k * Math.PI / 4 + 0.2, x = cx + Math.cos(a) * s * r, y = cy + Math.sin(a) * s * r; k ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); }
      });
      spr.dyn = mk((g, s) => {
        g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(s * 0.5, s * 0.88, s * 0.3, s * 0.06, 0, 0, 7); g.fill();
        for (let k = 0; k < 3; k++) {
          const x = s * (0.24 + k * 0.17), gr = g.createLinearGradient(x, 0, x + s * 0.16, 0);
          gr.addColorStop(0, '#7a1c16'); gr.addColorStop(0.45, '#d8483a'); gr.addColorStop(1, '#5e1410');
          g.fillStyle = gr; g.fillRect(x, s * 0.34, s * 0.16, s * 0.5);
        }
        g.fillStyle = '#c9b48a'; g.fillRect(s * 0.22, s * 0.52, s * 0.56, s * 0.08);
        g.strokeStyle = '#d9cfb8'; g.lineWidth = 1.4; g.beginPath(); g.moveTo(s * 0.5, s * 0.34); g.quadraticCurveTo(s * 0.56, s * 0.18, s * 0.7, s * 0.16); g.stroke();
      });
      spr.slime = [0, 1].map((v) => mk((g, s) => {
        g.fillStyle = '#100c12'; g.fillRect(0, 0, s, s);
        const gr = g.createRadialGradient(s * 0.4, s * 0.35, 1, s / 2, s / 2, s * 0.62);
        gr.addColorStop(0, '#9ed14a'); gr.addColorStop(0.6, '#557f1e'); gr.addColorStop(1, '#2c4511');
        g.fillStyle = gr; g.beginPath();
        for (let k = 0; k <= 12; k++) { const a = k / 12 * Math.PI * 2, r = s * (0.5 + Math.sin(a * 3 + v * 1.7) * 0.05); const x = s / 2 + Math.cos(a) * r, y = s / 2 + Math.sin(a) * r; k ? g.lineTo(x, y) : g.moveTo(x, y); }
        g.fill();
        g.fillStyle = 'rgba(230,255,180,.45)'; g.beginPath(); g.arc(s * (0.3 + v * 0.3), s * 0.35, s * 0.07, 0, 7); g.arc(s * 0.62, s * (0.68 - v * 0.2), s * 0.045, 0, 7); g.fill();
      }, v));
    }

    /* ---------- DOM: pad, chips, overlays ---------- */
    const pad = L.h('div', { class: 'gc-pad ' + (cfg.pad === 'l' ? 'l' : 'r') });
    const padB = [L.h('i', { class: 'u', text: '▲' }), L.h('i', { class: 'rt', text: '▶' }), L.h('i', { class: 'd', text: '▼' }), L.h('i', { class: 'lf', text: '◀' })];
    padB.forEach((b) => pad.appendChild(b));
    root.appendChild(pad);
    const padChip = L.h('button', { class: 'gc-chip', style: { left: '10px', bottom: '14px' }, onclick() { cfg.pad = cfg.pad === 'r' ? 'l' : cfg.pad === 'l' ? 'n' : 'r'; try { localStorage.setItem('lounge.gemcave.cfg', JSON.stringify(cfg)); } catch (e) {} syncPad(); api.sfx('click'); } });
    root.appendChild(padChip);
    const retryChip = L.h('button', { class: 'gc-chip', 'data-action': 'retry', 'aria-label': '다시 하기', style: { right: '8px', top: '3px' }, text: '↺ 다시', onclick() { soloRetry(); } });
    root.appendChild(retryChip);
    let bombSeq = 0, bombPend = false;
    const bombChip = L.h('button', { class: 'gc-chip gc-bomb', 'data-action': 'bomb', 'aria-label': '다이너마이트 놓기', style: { left: '10px', bottom: '70px', display: 'none' }, onclick() { pressBomb(); } });
    root.appendChild(bombChip);
    const hintOff = firstHint(root, api, 'gemcave', ['방향 패드(또는 화면 밀기·방향키)로 파며 움직여요', '보석을 다 모으면 출구가 열려요', '바위 바로 밑에서 아래로 계속 가면 깔려요!']);
    function pressBomb() { if (phase !== 'play') return; bombPend = true; bombSeq = (bombSeq + 1) % 1000; api.buzz(12); api.sfx('click'); }
    let ov = null;
    function closeOv() { if (ov) { ov.remove(); ov = null; } }
    function showOv(card) { closeOv(); ov = L.h('div', { class: 'gc-ov' }, card); root.appendChild(ov); }
    function syncPad() {
      const me = mySeat();
      const playing = me >= 0 && !isAI(me) && ['play', 'ready', 'count'].includes(phase);
      pad.className = 'gc-pad ' + (cfg.pad === 'l' ? 'l' : 'r');
      pad.style.display = playing && cfg.pad !== 'n' ? '' : 'none';
      padChip.style.display = playing ? '' : 'none';
      padChip.style.left = cfg.pad === 'l' ? 'auto' : '10px';
      padChip.style.right = cfg.pad === 'l' ? '10px' : 'auto';
      padChip.textContent = cfg.pad === 'n' ? '✋ 밀기만' : '✚ 패드';
      retryChip.style.display = st && st.m === 's' && playing && (phase === 'play' || phase === 'ready') ? '' : 'none';
      syncBomb();
    }
    let bombShown = -2;
    function syncBomb() {
      const me = mySeat(), q = VM && me >= 0 && VM.pl[me], n = q && q.a && !q.dn ? q.dy | 0 : 0;
      const on = n > 0 && me >= 0 && !isAI(me) && phase === 'play';
      const v = on ? n * 10 + (cfg.pad === 'l' ? 1 : 0) : -1;
      if (v === bombShown) return;
      bombShown = v;
      bombChip.style.display = on ? '' : 'none';
      bombChip.style.left = cfg.pad === 'l' ? 'auto' : '10px';
      bombChip.style.right = cfg.pad === 'l' ? '10px' : 'auto';
      bombChip.textContent = '💣 ' + n;
    }

    /* ---------- input ---------- */
    const inp = api.input || null;
    let padDir = -1, swDir = -1, tapDir = -1, tapSeq = 0, keyDir = -1;
    const ptr = { id: null, kind: '', x0: 0, y0: 0 };
    function setTap(d) { if (d >= 0) { tapDir = d; tapSeq = (tapSeq + 1) % 1000; } }
    function padFromEv(e) {
      const r = pad.getBoundingClientRect(), x = e.clientX - r.left - r.width / 2, y = e.clientY - r.top - r.height / 2;
      if (Math.hypot(x, y) < 14) return -1;
      return Math.abs(x) > Math.abs(y) ? (x > 0 ? 1 : 3) : (y > 0 ? 2 : 0);
    }
    function showPad() { padB.forEach((b, k) => b.classList.toggle('on', heldDir() === k)); }
    pad.addEventListener('pointerdown', (e) => { e.preventDefault(); try { pad.setPointerCapture(e.pointerId); } catch (x) {} ptr.id = e.pointerId; ptr.kind = 'pad'; const d = padFromEv(e); if (d >= 0 && d !== padDir) { padDir = d; setTap(d); api.buzz(8); } showPad(); });
    pad.addEventListener('pointermove', (e) => { if (ptr.id !== e.pointerId || ptr.kind !== 'pad') return; const d = padFromEv(e); if (d !== padDir) { padDir = d; if (d >= 0) { setTap(d); api.buzz(6); } } showPad(); });
    const padUp = (e) => { if (ptr.id !== e.pointerId) return; padDir = -1; ptr.id = null; showPad(); };
    pad.addEventListener('pointerup', padUp); pad.addEventListener('pointercancel', padUp);
    const cvEl = cv.cv;
    const onDown = (e) => { if (ov) return; ptr.id = e.pointerId; ptr.kind = 'sw'; ptr.x0 = e.clientX; ptr.y0 = e.clientY; swDir = -1; try { cvEl.setPointerCapture(e.pointerId); } catch (x) {} };
    const onMove = (e) => {
      if (ptr.id !== e.pointerId || ptr.kind !== 'sw') return;
      const dx = e.clientX - ptr.x0, dy = e.clientY - ptr.y0, m = Math.hypot(dx, dy);
      let d = swDir;
      if (m > 16) d = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0);
      else if (m < 8) d = -1;
      if (m > 70) { const k = (m - 50) / m; ptr.x0 += dx * k; ptr.y0 += dy * k; } // origin follows the finger: reversing is quick
      if (d !== swDir) { swDir = d; if (d >= 0) setTap(d); }
    };
    const onUp = (e) => { if (ptr.id !== e.pointerId) return; swDir = -1; ptr.id = null; };
    cvEl.addEventListener('pointerdown', onDown); cvEl.addEventListener('pointermove', onMove);
    cvEl.addEventListener('pointerup', onUp); cvEl.addEventListener('pointercancel', onUp);
    let keyOrder = [];
    const offIn = inp && inp.on ? inp.on((type, id) => {
      const d = DIRK.indexOf(id);
      if (d >= 0) {
        keyOrder = keyOrder.filter((k) => k !== d);
        if (type === 'down') { keyOrder.push(d); setTap(d); }
      } else if (id === 'retry' && type === 'down') soloRetry();
      else if (id === 'bomb' && type === 'down') pressBomb();
    }) : null;
    function heldDir() {
      if (padDir >= 0) return padDir;
      if (swDir >= 0) return swDir;
      if (inp) {
        for (let k = keyOrder.length - 1; k >= 0; k--) if (inp.held(DIRK[keyOrder[k]])) return keyOrder[k];
        keyOrder = keyOrder.filter((d) => inp.held(DIRK[d]));
        const ax = inp.axis('left', 'right'), ay = inp.axis('up', 'down');
        if (Math.abs(ax) > 0.5 || Math.abs(ay) > 0.5) return Math.abs(ax) > Math.abs(ay) ? (ax > 0 ? 1 : 3) : (ay > 0 ? 2 : 0);
      }
      return -1;
    }
    function takeMyDir() { if (bombPend) { bombPend = false; return 4; } const h = heldDir(); const d = h >= 0 ? h : tapDir; tapDir = -1; return d; }

    /* ---------- sounds / fx ---------- */
    function sfx(n, gap) { const t = performance.now(); if (sfxT[n] && t - sfxT[n] < (gap || 60)) return; sfxT[n] = t; api.sfx(n); }
    function cellXY(i, w) { return [(i % w + 0.5) * cs, (((i / w) | 0) + 0.5) * cs]; }
    function burst(i, w, cols, n, sp) {
      const [x, y] = cellXY(i, w);
      for (let k = 0; k < n; k++) { const a = Math.random() * 6.283, v = (0.3 + Math.random()) * (sp || 60); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 20, t: 0.35 + Math.random() * 0.35, c: cols[(Math.random() * cols.length) | 0], r: 1 + Math.random() * 2 }); }
      if (parts.length > 400) parts.splice(0, parts.length - 400);
    }
    function onEvents(evs, w, me) {
      for (let k = 0; k < evs.length; k++) {
        const t = evs[k][0], i = evs[k][1];
        if (t === 'g') { burst(i, w, ['#bffcf3', '#5ef0e0', '#ffffff'], 7, 55); const pi = nearPl(i); if (pi === me) { sfx('pop', 40); api.buzz(8); const [x, y] = cellXY(i, w); pops.push({ x, y, t: 0.8, text: '+1', c: '#9ff5e8' }); } else sfx('chip', 120); }
        else if (t === 'd') { if (nearPl(i) === me) burst(i, w, ['#6e5038', '#3f2b1e', '#8a6a4a'], 3, 30); }
        else if (t === 't') { sfx('thud', 90); burst(i + w, w, ['#7d756a', '#4a4540'], 3, 25); if (onScreen(i, w)) shake = Math.max(shake, 0.12); }
        else if (t === 'c') sfx('tick', 80);
        else if (t === 'b') { sfx('hit', 60); api.buzz(30); shake = Math.max(shake, 0.6); const [x, y] = cellXY(i, w); flashes.push({ x, y, t: 0.45 }); burst(i, w, ['#ffd27a', '#ff7b3a', '#fff2c0', '#6b4a3a'], 22, 120); }
        else if (t === 'k') { const pi = nearPl(i, true); if (pi === me) { sfx('lose', 200); api.buzz(140); } }
        else if (t === 'x') { sfx('win', 300); burst(i, w, ['#ffe7a8', '#e3ae45', '#fff'], 18, 80); }
        else if (t === 'o') { sfx('whoosh', 300); api.toast('출구가 열렸어요!'); }
        else if (t === 'p') sfx('roll', 120);
        else if (t === 'm') { burst(i, w, ['#c49bff', '#ffffff', '#7af5e0'], 6, 40); sfx('tick', 50); }
        else if (t === 'M') { api.toast('마법 석판이 깨어났어요'); sfx('whoosh', 200); }
        else if (t === 's') { api.toast('점액이 갇혀 보석으로 굳었어요!'); sfx('win', 200); }
        else if (t === 'S') { api.toast('점액이 너무 커져 바위로 굳었어요'); sfx('thud', 200); }
        else if (t === 'r') { burst(i, w, ['#f2e9d8', '#e3ae45'], 10, 50); }
        else if (t === 'h') { if (onScreen(i, w)) burst(i, w, ['#6e5038', '#8a6a4a'], 2, 25); }
        else if (t === 'R') { sfx('chip', 120); burst(i, w, ['#d8c7b0', '#9ff5e8'], 9, 50); }
        else if (t === 'w') { if (nearPl(i) === me) { sfx('tick', 120); api.buzz(14); const [x, y] = cellXY(i, w); pops.push({ x, y, t: 0.7, text: '끈끈!', c: '#e8e2f2' }); } burst(i, w, ['#f2eefa', '#c9c2d8'], 5, 30); }
        else if (t === 'T') { sfx('whoosh', 150); burst(i, w, ['#7af5e0', '#e070ff', '#ffffff'], 10, 60); }
        else if (t === 'y') { if (nearPl(i) === me) { sfx('pop', 60); api.buzz(10); const [x, y] = cellXY(i, w); pops.push({ x, y, t: 0.8, text: '+💣', c: '#ffb4a6' }); } }
        else if (t === 'l') { sfx('tick', 60); burst(i, w, ['#ffd27a', '#ff7b3a'], 4, 30); }
      }
    }
    let VM = null; // what to draw
    function nearPl(i, dead) { if (!VM) return -1; for (let s = 0; s < VM.pl.length; s++) { const p = VM.pl[s]; if (p.i === i && (dead || p.a)) return s; } return -1; }
    function onScreen(i, w) { const [x, y] = cellXY(i, w); return x + cam.x > -cs && x + cam.x < cv.w + cs && y + cam.y > -cs && y + cam.y < cv.h + cs; }

    /* ---------- lifecycle ---------- */
    const cam = { x: 0, y: 0, ok: false };
    function vmFromWorld() {
      VM = { w: W.w, h: W.h, g: W.g, mvFrom: VM && VM.mvFrom && VM.mvFrom.length === W.g.length ? VM.mvFrom : new Int16Array(W.g.length).fill(-1), pl: W.pl, xo: W.xo, mw: W.mw, tl: W.tl, q: W.q, vs: W.vs, f: W.f };
    }
    function setMoves(VMx, mv) { VMx.mvFrom.fill(-1); for (let k = 0; k < mv.length; k += 2) VMx.mvFrom[mv[k + 1]] = mv[k]; }
    function curKey() { return st ? st.rid + '.' + st.m + '.' + (st.m === 's' ? st.stg + '.' + st.at : 'v') : null; }
    function startWorld() {
      if (st.m === 's') { cave = stageCave(st.stg); W = newWorld(cave, 1, { seed: hash2(st.stg, st.at + 7) }); }
      else { cave = vsCave(st.sd, st.n); W = newWorld(cave, st.n, { seed: st.sd, vs: true }); }
      aiMem = W.pl.map((_, s) => ({ rnd: Math.random }));
      vmFromWorld(); setMoves(VM, []);
      parts = []; pops = []; flashes = []; acc = 0; cam.ok = false; endSent = false;
      G = null; lastQ = -1;
      if (st.m === 's') { phase = 'ready'; readyT = 1.6; }
      else { phase = st.ph === 'play' ? 'play' : 'count'; cd = 3; }
      closeOv(); syncPad();
    }

    /* ---------- solo flow ---------- */
    function unlocked() { let m = 0; try { const b = L.best.all('gemcave'); if (b && b.max) m = b.max.v | 0; } catch (e) {} return Math.max(1, m + 1); }
    function stageBest(n) { try { const b = L.best.all('gemcave'); return b && b['s' + n] ? b['s' + n].v : 0; } catch (e) { return 0; } }
    function showPicker() {
      phase = 'pick'; syncPad();
      const un = unlocked(), max = Math.max(HAND, un);
      const grid = L.h('div', { class: 'gc-grid' });
      let curBtn = null;
      for (let k = 1; k <= max + (un >= HAND ? 0 : 0); k++) {
        const ok = k <= un, b = stageBest(k);
        const btn = L.h('button', { class: 'gc-st' + (k === un ? ' cur' : ''), disabled: !ok, 'aria-label': k + '단계', onclick() { api.sfx('click'); beginRun(k); } },
          String(k), L.h('small', { text: !ok ? '🔒' : b ? b + '점' : k <= HAND ? '손수' : '새 굴' }));
        if (k === un) curBtn = btn;
        grid.appendChild(btn);
      }
      showOv(L.h('div', { class: 'gc-card' },
        L.h('h3', { text: '어느 갱도로 갈까요?' }),
        L.h('p', { text: '목숨 3개로 출발해요. 단계를 깨면 바로 다음 단계로 내려가요. 1~10단계는 손수 만든 굴, 그 뒤로는 끝없이 새 굴이 나와요.' }),
        grid,
        L.h('div', { class: 'gc-row' }, L.h('button', { class: 'btn primary', text: un + '단계부터 ▶', onclick() { api.sfx('click'); beginRun(un); } }))));
      if (curBtn) setTimeout(() => { try { curBtn.scrollIntoView({ block: 'nearest' }); } catch (e) {} }, 0);
    }
    function beginRun(n) {
      lives = 3; runScore = st.sc | 0; cleared = st.cl | 0; topStage = st.top | 0;
      api.setState(Object.assign({}, st, { ph: 'play', stg: n, at: (st.at | 0) + 1, lf: lives }));
    }
    function soloRetry() {
      if (!st || st.m !== 's' || !W || !(phase === 'play' || phase === 'ready')) return;
      api.sfx('click');
      soloEnd('retry');
    }
    function stageScore(Wd) { const p = Wd.pl[0]; return p.gm * 10 + Math.max(0, p.gm - Wd.q) * 10 + Math.max(0, Math.round(Wd.tl * TICK)) * 2; }
    function soloEnd(why) {
      if (phase !== 'play' && phase !== 'ready') return;
      const human = !isAI(0);
      if (why === 'clear') {
        phase = 'clear'; syncPad();
        const sc = stageScore(W), n = st.stg, p = W.pl[0];
        runScore += sc; cleared++; topStage = Math.max(topStage, n);
        let rec = false;
        if (human) { rec = api.best('s' + n, sc, { label: n + '단계 최고 점수', unit: '점' }); api.best('max', n, { label: '가장 깊이 간 단계', unit: '단계' }); }
        api.sfx('win'); api.buzz(40);
        setTimeout(() => { try { stageCave(n + 1); } catch (e) {} }, 80); // build (and bot-check) the next cave while the card is up
        const next = () => api.setState(Object.assign({}, st, { stg: n + 1, at: (st.at | 0) + 1, cl: cleared, sc: runScore, top: topStage, lf: lives }));
        if (!human) { setTimeout(() => { if (cleared >= 3) finishRun(); else next(); }, 900 / SPD()); return; }
        showOv(L.h('div', { class: 'gc-card' },
          L.h('h3', { text: n + '단계 돌파!' + (rec ? ' 🏆' : '') }),
          L.h('div', { class: 'gc-stat' }, '모은 보석', L.h('b', { text: p.gm + ' / ' + W.q })),
          L.h('div', { class: 'gc-stat' }, '남은 시간', L.h('b', { text: Math.round(W.tl * TICK) + '초' })),
          L.h('div', { class: 'gc-stat' }, '이번 점수', L.h('b', { text: sc + '점' + (rec ? ' (최고!)' : '') })),
          L.h('div', { class: 'gc-stat' }, '목숨', L.h('b', { text: '⛑'.repeat(lives) })),
          L.h('div', { class: 'gc-row' },
            L.h('button', { class: 'btn', text: '그만하기', onclick() { api.sfx('click'); cleared; finishRun(); } }),
            L.h('button', { class: 'btn primary', text: (n + 1) + '단계 ▶', onclick() { api.sfx('click'); next(); } }))));
        return;
      }
      lives--;
      phase = 'fail'; syncPad();
      const msg = why === 'time' ? '시간이 다 됐어요' : why === 'retry' ? '처음부터 다시' : '깔려 버렸어요';
      if (lives <= 0) { setTimeout(() => finishRun(), (human ? 1300 : 600) / SPD()); api.toast(msg + ' · 목숨을 다 썼어요'); return; }
      const again = () => api.setState(Object.assign({}, st, { at: (st.at | 0) + 1, lf: lives, cl: cleared, sc: runScore, top: topStage }));
      if (!human) { setTimeout(again, 700 / SPD()); return; }
      if (why === 'retry') { api.toast('다시 도전 · 남은 목숨 ' + lives); again(); return; }
      setTimeout(() => {
        if (phase !== 'fail') return;
        showOv(L.h('div', { class: 'gc-card' },
          L.h('h3', { text: msg }),
          L.h('p', { text: '남은 목숨 ' + lives + '개. 같은 굴을 처음부터 다시 해요.' }),
          L.h('div', { class: 'gc-row' },
            L.h('button', { class: 'btn', text: '그만하기', onclick() { api.sfx('click'); finishRun(); } }),
            L.h('button', { class: 'btn primary', text: '다시 ▶', onclick() { api.sfx('click'); again(); } }))));
      }, 900);
    }
    function finishRun() {
      if (endSent) return; endSent = true; closeOv(); phase = 'end'; syncPad();
      api.setState(Object.assign({}, st, { ph: 'done', cl: cleared, sc: runScore, top: topStage, lf: lives }));
    }

    /* ---------- vs flow (host) ---------- */
    function vsFinish() {
      if (endSent) return; endSent = true; phase = 'end';
      const res = W.pl.map((p, s) => [s, p.gm, p.dn ? 1 : 0]).sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
      const me = mySeat();
      if (me >= 0 && !isAI(me)) api.best('vs', W.pl[me].gm, { label: '대전 최다 보석', unit: '개' });
      setTimeout(() => api.setState(Object.assign({}, st, { ph: 'done', res })), 1200 / SPD());
    }

    /* ---------- tick (host / local) ---------- */
    function doTick() {
      const inpA = W.pl.map(() => -1), me = mySeat();
      let rem = null;
      if (api.online && api.isHost) { try { rem = api.net.remote(); } catch (e) { rem = null; } }
      for (let s = 0; s < W.pl.length; s++) {
        const p = api.players[s];
        if (!p) continue;
        if (isAI(s)) inpA[s] = botDir(W, s, p.ai ? (p.lv || 2) : 3, aiMem[s]);
        else if (s === me) inpA[s] = takeMyDir();
        else if (rem && rem[s] && rem[s].k === key) {
          const o = rem[s]; let d = o.d >= 0 && o.d < 4 ? o.d : -1;
          if (o.b !== remB[s]) { if (d < 0 && o.t >= 0 && o.t < 4) d = o.t; remB[s] = o.b; }
          if ((o.bb | 0) !== (remBB[s] | 0)) { d = 4; remBB[s] = o.bb | 0; }
          inpA[s] = d;
        }
      }
      step(W, inpA);
      const evs = []; for (let k = 0; k < W.ev.length; k += 2) evs.push([W.ev[k], W.ev[k + 1]]);
      vmFromWorld(); setMoves(VM, W.mv);
      onEvents(evs, W.w, me);
      if (W.tl > 0 && W.tl * TICK <= 10 && Math.round(W.tl * TICK * 10) % 10 === 0 && Math.abs(W.tl * TICK - Math.round(W.tl * TICK)) < TICK / 2) sfx('tick', 500);
      if (api.online && api.isHost) {
        hsQ = (hsQ + 1) % 100000;
        try {
          api.net.hostSend({ k: key, q: hsQ, w: W.w, g: rle(W.g), m: encMoves(W), e: encEv(W), p: W.pl.map((p) => [p.i, p.gm, p.a, p.dn, p.fc, p.dy | 0]), tl: W.tl, xo: W.xo ? 1 : 0, mw: W.mw, qq: W.q });
        } catch (e) {}
      }
      if (st.m === 's') { const r = soloOutcome(W); if (r) soloEnd(r); }
      else if (vsOver(W)) vsFinish();
    }

    /* ---------- guest ---------- */
    let pubT = 0, lastSig = '';
    function pollGuest(now) {
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || hs.k !== key || hs.q === lastQ || !W) return;
      lastQ = hs.q;
      if (!G) G = { w: W.w, h: W.h, g: new Uint8Array(W.g.length), mvFrom: new Int16Array(W.g.length).fill(-1), pl: [], xo: false, mw: 0, tl: 0, q: W.q, vs: true, f: new Uint8Array(W.g.length) };
      unrle(String(hs.g || ''), G.g);
      G.mvFrom.fill(-1);
      const m = String(hs.m || '');
      for (let k = 0; k + 3 <= m.length; k += 3) {
        const a = parseInt(m.slice(k, k + 2), 36), c = m[k + 2];
        const b = a + (c === 'u' ? -G.w : c === 'r' ? 1 : c === 'd' ? G.w : -1);
        if (b >= 0 && b < G.g.length) G.mvFrom[b] = a;
      }
      G.pl = (Array.isArray(hs.p) ? hs.p : []).map((q) => ({ i: q[0] | 0, gm: q[1] | 0, a: q[2] | 0, dn: q[3] | 0, fc: q[4] | 0, dy: q[5] | 0 }));
      G.xo = !!hs.xo; G.mw = hs.mw | 0; G.tl = hs.tl | 0; G.q = hs.qq | 0 || G.q;
      const dt = now - gTickAt; if (gTickAt && dt > 40 && dt < 600) gDur = gDur * 0.7 + dt * 0.3;
      gTickAt = now;
      VM = G;
      const e = String(hs.e || ''), evs = [];
      for (let k = 0; k + 3 <= e.length; k += 3) evs.push([e[k], parseInt(e.slice(k + 1, k + 3), 36)]);
      onEvents(evs, G.w, mySeat());
    }
    function publish(rdt) {
      const s = mySeat();
      if (s < 0) return;
      pubT -= rdt;
      const d = heldDir();
      const sig = d + '|' + tapSeq + '|' + bombSeq;
      if (sig === lastSig && pubT > 0) return;
      lastSig = sig; pubT = 0.25;
      try { api.net.publish({ k: key, d, b: tapSeq, t: tapDir, bb: bombSeq }); } catch (e) {}
      bombPend = false;
      tapDir = -1;
    }

    /* ---------- main loop ---------- */
    let tPrev = 0, tickAt = 0;
    function frame(rdt, now) {
      if (!st) return;
      const dt = Math.min(0.1, rdt) * SPD();
      if (st.ph === 'pick' || !W) { draw(now, 0); return; }
      if (phase === 'ready') { readyT -= dt; if (readyT <= 0) { phase = 'play'; api.sfx('pop'); syncPad(); } }
      if (phase === 'count') {
        const a = Math.ceil(cd); cd -= dt; const b = Math.ceil(cd);
        if (a !== b && b > 0) api.sfx('tick');
        if (cd <= 0) { phase = 'play'; syncPad(); api.sfx('pop'); api.buzz(20); if (host() && st.ph === 'count') api.setState(Object.assign({}, st, { ph: 'play' })); }
      }
      let k = 1;
      if (host()) {
        if (phase === 'play' && st.ph !== 'done') {
          acc += dt;
          let guard = 0;
          while (acc >= TICK && guard++ < 4 && phase === 'play') { acc -= TICK; doTick(); tickAt = now; }
          if (acc > TICK * 4) acc = 0;
          k = Math.min(1, acc / TICK);
        }
      } else {
        pollGuest(now);
        if (phase === 'play') publish(rdt);
        k = Math.min(1, (now - gTickAt) / Math.max(60, gDur));
      }
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; p.vy += 140 * rdt; p.vx *= 0.96; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = pops.length - 1; i >= 0; i--) { pops[i].t -= rdt; pops[i].y -= 26 * rdt; if (pops[i].t <= 0) pops.splice(i, 1); }
      for (let i = flashes.length - 1; i >= 0; i--) { flashes[i].t -= rdt; if (flashes[i].t <= 0) flashes.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 2.5);
      if (pad.style.display !== 'none') showPad();
      syncBomb();
      draw(now, k, rdt);
      void tPrev; void tickAt;
    }

    /* ---------- drawing ---------- */
    function objPos(i, k, w) {
      const fr = VM.mvFrom[i];
      let x = i % w, y = (i / w) | 0;
      if (fr >= 0 && k < 1) { const fx = fr % w, fy = (fr / w) | 0; x = fx + (x - fx) * k; y = fy + (y - fy) * k; }
      return [x * cs, y * cs];
    }
    function drawFirefly(x, y, d, t, s) {
      const cx = x + s / 2, cy = y + s / 2, fl = Math.abs(Math.sin(t * 14 + x * 0.1)) * 0.6 + 0.4;
      const gl = ctx.createRadialGradient(cx, cy, 1, cx, cy, s * 0.8); gl.addColorStop(0, 'rgba(255,150,60,.45)'); gl.addColorStop(1, 'rgba(255,90,30,0)');
      ctx.fillStyle = gl; ctx.fillRect(cx - s, cy - s, s * 2, s * 2);
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(d * Math.PI / 2);
      for (const sd of [-1, 1]) {
        const wg = ctx.createLinearGradient(0, 0, sd * s * 0.45, 0); wg.addColorStop(0, '#ffcf6b'); wg.addColorStop(0.6, '#f0642a'); wg.addColorStop(1, '#6a1d10');
        ctx.fillStyle = wg; ctx.beginPath(); ctx.ellipse(sd * s * 0.22, -s * 0.04, s * 0.24 * fl + s * 0.04, s * 0.3, sd * 0.4, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(60,15,8,.6)'; ctx.beginPath(); ctx.arc(sd * s * 0.24, -s * 0.06, s * 0.05, 0, 7); ctx.fill();
      }
      ctx.fillStyle = '#2a1712'; ctx.beginPath(); ctx.ellipse(0, s * 0.02, s * 0.08, s * 0.26, 0, 0, 7); ctx.fill();
      ctx.strokeStyle = '#f7c56a'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(-s * 0.03, -s * 0.22); ctx.lineTo(-s * 0.12, -s * 0.38); ctx.moveTo(s * 0.03, -s * 0.22); ctx.lineTo(s * 0.12, -s * 0.38); ctx.stroke();
      ctx.restore();
    }
    function drawBug(x, y, d, t, s) {
      const cx = x + s / 2, cy = y + s / 2;
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(d * Math.PI / 2);
      const lg = Math.sin(t * 16 + x) * s * 0.05;
      ctx.strokeStyle = '#1d2228'; ctx.lineWidth = 2;
      for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(-s * 0.2, k * s * 0.13); ctx.lineTo(-s * 0.4, k * s * 0.16 + (k ? lg : -lg)); ctx.moveTo(s * 0.2, k * s * 0.13); ctx.lineTo(s * 0.4, k * s * 0.16 - (k ? lg : -lg)); ctx.stroke(); }
      for (let k = 0; k < 3; k++) {
        const yy = s * (0.18 - k * 0.16), r = s * (0.22 - k * 0.02);
        const gr = ctx.createRadialGradient(-r * 0.3, yy - r * 0.3, 1, 0, yy, r * 1.1); gr.addColorStop(0, '#9aa7b3'); gr.addColorStop(1, '#3a4450');
        ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(0, yy, r, s * 0.11, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(10,12,16,.6)'; ctx.lineWidth = 1; ctx.stroke();
      }
      ctx.fillStyle = '#d14b3a'; ctx.beginPath(); ctx.arc(-s * 0.07, -s * 0.24, s * 0.035, 0, 7); ctx.arc(s * 0.07, -s * 0.24, s * 0.035, 0, 7); ctx.fill();
      ctx.restore();
    }
    function drawDoor(x, y, v, t, s) {
      const cx = x + s / 2, cy = y + s / 2, col = v ? ['#e070ff', '#7a2a9a'] : ['#7af5e0', '#1a7f78'];
      ctx.fillStyle = '#2a2530'; ctx.beginPath(); ctx.arc(cx, cy, s * 0.46, 0, 7); ctx.fill();
      const gr = ctx.createRadialGradient(cx, cy, 1, cx, cy, s * 0.42); gr.addColorStop(0, '#fff'); gr.addColorStop(0.35, col[0]); gr.addColorStop(1, col[1]);
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(cx, cy, s * 0.38, 0, 7); ctx.fill();
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(t * (v ? -2.2 : 2.2));
      ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1.6;
      for (let k = 0; k < 3; k++) { ctx.rotate(Math.PI * 2 / 3); ctx.beginPath(); ctx.arc(s * 0.1, 0, s * 0.2, -1.2, 0.9); ctx.stroke(); }
      ctx.restore();
      ctx.strokeStyle = 'rgba(180,170,190,.6)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(cx, cy, s * 0.46, 0, 7); ctx.stroke();
    }
    function drawLit(x, y, f, t, s) {
      ctx.drawImage(spr.dyn, x, y, s, s);
      const fast = f > 0 && f < FUSE * 0.4, blink = Math.sin(t * (fast ? 40 : 18)) > 0;
      const sx2 = x + s * 0.7, sy2 = y + s * 0.16;
      const gl = ctx.createRadialGradient(sx2, sy2, 1, sx2, sy2, s * 0.35); gl.addColorStop(0, 'rgba(255,230,140,.95)'); gl.addColorStop(1, 'rgba(255,120,40,0)');
      ctx.fillStyle = gl; ctx.fillRect(sx2 - s * 0.35, sy2 - s * 0.35, s * 0.7, s * 0.7);
      if (blink) { ctx.fillStyle = 'rgba(255,90,60,.28)'; ctx.fillRect(x, y, s, s); }
      if (Math.random() < 0.5) parts.push({ x: sx2, y: sy2, vx: (Math.random() - 0.5) * 50, vy: -Math.random() * 40, t: 0.25, c: '#ffd27a', r: 1.2 });
    }
    function drawRabbit(x, y, i, t, s, fr) {
      const cx = x + s / 2, cy = y + s * 0.56, left = fr >= 0 && fr - i === 1;
      const hop = fr >= 0 ? Math.abs(Math.sin(t * 14)) * s * 0.06 : 0;
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(cx, y + s * 0.9, s * 0.26, s * 0.06, 0, 0, 7); ctx.fill();
      ctx.save(); ctx.translate(cx, cy - hop); if (left) ctx.scale(-1, 1);
      const gr = ctx.createRadialGradient(-s * 0.08, -s * 0.08, 1, 0, 0, s * 0.34); gr.addColorStop(0, '#d8c7b0'); gr.addColorStop(1, '#7d6a55');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(-s * 0.04, s * 0.06, s * 0.27, s * 0.22, 0, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.arc(s * 0.18, -s * 0.08, s * 0.14, 0, 7); ctx.fill();
      ctx.fillStyle = '#a89279';
      ctx.beginPath(); ctx.ellipse(s * 0.12, -s * 0.3, s * 0.045, s * 0.14, -0.25, 0, 7); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s * 0.22, -s * 0.3, s * 0.045, s * 0.14, 0.2, 0, 7); ctx.fill();
      ctx.fillStyle = '#1b1612'; ctx.beginPath(); ctx.arc(s * 0.23, -s * 0.1, s * 0.03, 0, 7); ctx.fill();
      ctx.strokeStyle = '#e8e2d6'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(s * 0.3, s * 0.02); ctx.lineTo(s * 0.38, s * 0.12); ctx.moveTo(s * 0.26, s * 0.03); ctx.lineTo(s * 0.3, s * 0.14); ctx.stroke();
      ctx.fillStyle = '#efe6d8'; ctx.beginPath(); ctx.arc(-s * 0.3, s * 0.02, s * 0.06, 0, 7); ctx.fill();
      ctx.restore();
    }
    function drawSpider(x, y, t, s) {
      const cx = x + s / 2, cy = y + s / 2, lg = Math.sin(t * 10 + x) * s * 0.04;
      ctx.strokeStyle = '#9b8fc4'; ctx.lineWidth = 1.5;
      for (let k = 0; k < 4; k++) for (const sd of [-1, 1]) {
        const ay = cy + (k - 1.5) * s * 0.1, kx = cx + sd * s * 0.26, ky = ay - s * 0.12 + (k % 2 ? lg : -lg);
        ctx.beginPath(); ctx.moveTo(cx + sd * s * 0.08, ay); ctx.lineTo(kx, ky); ctx.lineTo(cx + sd * s * 0.42, ay + s * 0.14); ctx.stroke();
      }
      const gr = ctx.createRadialGradient(cx - s * 0.06, cy - s * 0.04, 1, cx, cy + s * 0.06, s * 0.24); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.4, '#b9a6ff'); gr.addColorStop(1, '#4b3a8a');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.moveTo(cx, cy - s * 0.05); ctx.lineTo(cx + s * 0.17, cy + s * 0.1); ctx.lineTo(cx, cy + s * 0.32); ctx.lineTo(cx - s * 0.17, cy + s * 0.1); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#5ef0e0'; ctx.beginPath(); ctx.arc(cx, cy - s * 0.12, s * 0.1, 0, 7); ctx.fill();
      ctx.fillStyle = '#ee6a55'; ctx.fillRect(cx - s * 0.05, cy - s * 0.15, s * 0.03, s * 0.03); ctx.fillRect(cx + s * 0.02, cy - s * 0.15, s * 0.03, s * 0.03);
    }
    function drawMiner(x, y, s, col, fc, t, mine, moving) {
      const cx = x + s / 2, bob = moving ? Math.abs(Math.sin(t * 18)) * s * 0.04 : 0, cy = y + s / 2 - bob;
      const fx = fc === 1 ? 1 : fc === 3 ? -1 : 0;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(cx, y + s * 0.92, s * 0.26, s * 0.06, 0, 0, 7); ctx.fill();
      // body
      ctx.fillStyle = '#3a3329'; ctx.beginPath(); ctx.moveTo(cx - s * 0.22, cy + s * 0.38); ctx.lineTo(cx - s * 0.18, cy - s * 0.02); ctx.lineTo(cx + s * 0.18, cy - s * 0.02); ctx.lineTo(cx + s * 0.22, cy + s * 0.38); ctx.closePath(); ctx.fill();
      ctx.fillStyle = col; ctx.globalAlpha = 0.85; ctx.fillRect(cx - s * 0.18, cy + s * 0.08, s * 0.36, s * 0.07); ctx.globalAlpha = 1;
      // pick
      ctx.save(); ctx.translate(cx + (fx || 1) * s * 0.2, cy + s * 0.12); ctx.rotate((fx || 1) * (moving ? -0.6 + Math.sin(t * 18) * 0.4 : -0.3));
      ctx.strokeStyle = '#7a5a3a'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0, s * 0.12); ctx.lineTo(0, -s * 0.2); ctx.stroke();
      ctx.strokeStyle = '#b8b2a8'; ctx.lineWidth = 2.2; ctx.beginPath(); ctx.moveTo(-s * 0.13, -s * 0.16); ctx.quadraticCurveTo(0, -s * 0.26, s * 0.13, -s * 0.16); ctx.stroke();
      ctx.restore();
      // head
      ctx.fillStyle = '#c99a78'; ctx.beginPath(); ctx.arc(cx + fx * s * 0.03, cy - s * 0.13, s * 0.13, 0, 7); ctx.fill();
      ctx.fillStyle = '#1b1612'; if (fc !== 0) { ctx.fillRect(cx + fx * s * 0.07 - (fx ? 0 : s * 0.06), cy - s * 0.15, s * 0.035, s * 0.035); if (!fx) ctx.fillRect(cx + s * 0.03, cy - s * 0.15, s * 0.035, s * 0.035); }
      // helmet
      const hg = ctx.createLinearGradient(0, cy - s * 0.38, 0, cy - s * 0.14); hg.addColorStop(0, '#fff'); hg.addColorStop(0.25, col); hg.addColorStop(1, shade(col, -0.45));
      ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(cx, cy - s * 0.17, s * 0.17, Math.PI, 0); ctx.fill();
      ctx.fillRect(cx - s * 0.22, cy - s * 0.19, s * 0.44, s * 0.05);
      // lamp
      const lx = cx + fx * s * 0.1, ly = cy - s * 0.27;
      ctx.fillStyle = '#fff6cf'; ctx.beginPath(); ctx.arc(lx, ly, s * 0.05, 0, 7); ctx.fill();
      if (fc !== 2) {
        const dx = fx || 0, dy = fc === 0 ? -1 : 0;
        const lg2 = ctx.createRadialGradient(lx, ly, 1, lx + dx * s * 0.5, ly + dy * s * 0.5, s * 0.6);
        lg2.addColorStop(0, 'rgba(255,240,190,.32)'); lg2.addColorStop(1, 'rgba(255,240,190,0)');
        ctx.fillStyle = lg2; ctx.beginPath(); ctx.arc(lx + dx * s * 0.4, ly + dy * s * 0.4, s * 0.6, 0, 7); ctx.fill();
      }
      if (mine && VM && VM.vs) { ctx.strokeStyle = 'rgba(242,233,216,.7)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(cx - 4, y - 6); ctx.lineTo(cx, y - 1); ctx.lineTo(cx + 4, y - 6); ctx.stroke(); }
    }
    function shade(hex, a) {
      const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return hex;
      const v = parseInt(m[1], 16); let r = v >> 16, g = (v >> 8) & 255, b = v & 255;
      const f = (c) => Math.max(0, Math.min(255, Math.round(a < 0 ? c * (1 + a) : c + (255 - c) * a)));
      return 'rgb(' + f(r) + ',' + f(g) + ',' + f(b) + ')';
    }
    function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function pill(x, y, w, h, fill, stroke) { rr(x, y, w, h, h / 2); ctx.fillStyle = fill; ctx.fill(); if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = 1; ctx.stroke(); } }
    function fmtT(sec) { sec = Math.max(0, Math.ceil(sec)); return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'); }

    function draw(now, k, rdt) {
      const t = now / 1000;
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      ctx.fillStyle = '#0b080d'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!VM || !W) { drawIdle(t); return; }
      const w = VM.w, h = VM.h, g = VM.g;
      // camera target
      const me = mySeat();
      let fs = me >= 0 && me < VM.pl.length ? me : 0;
      if (me < 0 || (VM.pl[fs] && !VM.pl[fs].a && !VM.pl[fs].dn)) { /* keep */ }
      const tp = VM.pl[fs];
      let tx = w * cs / 2, ty = h * cs / 2;
      if (tp) { const [px, py] = objPos(tp.i, k, w); tx = px + cs / 2; ty = py + cs / 2; }
      const padOn = pad.style.display !== 'none';
      const top = 48, bot = cv.h - (padOn ? 110 : 6);
      const fit = (v, lo, hi, total) => { // screen offset so that world coord v sits mid-area, map kept inside [lo,hi]
        const area = hi - lo;
        if (total <= area) return lo + (area - total) / 2;
        return Math.min(lo, Math.max(hi - total, (lo + hi) / 2 - v));
      };
      const wantX = fit(tx, 0, cv.w, w * cs), wantY = fit(ty, top, bot, h * cs);
      if (!cam.ok) { cam.x = wantX; cam.y = wantY; cam.ok = true; }
      else { const a = 1 - Math.exp(-(rdt || 0.016) * 7); cam.x += (wantX - cam.x) * a; cam.y += (wantY - cam.y) * a; }
      const fxk = typeof L.fx === 'function' ? L.fx() : 1, shk = shake * 8 * fxk;
      const sx = shk > 0 ? (Math.random() - 0.5) * shk : 0, sy = shk > 0 ? (Math.random() - 0.5) * shk : 0;
      const ox = Math.round(cam.x + sx), oy = Math.round(cam.y + sy);
      ctx.save(); ctx.translate(ox, oy);
      const x0 = Math.max(0, Math.floor(-ox / cs) - 1), x1 = Math.min(w - 1, Math.ceil((cv.w - ox) / cs) + 1);
      const y0 = Math.max(0, Math.floor(-oy / cs) - 1), y1 = Math.min(h - 1, Math.ceil((cv.h - oy) / cs) + 1);
      // pass 1: ground & static
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const i = y * w + x, c = g[i], px = x * cs, py = y * cs, hv = (x * 7 + y * 13) & 3;
        if (c === DI) ctx.drawImage(spr.dirt[hv], px, py, cs, cs);
        else if (c === ST) ctx.drawImage(spr.steel[hv & 1], px, py, cs, cs);
        else if (c === BW) ctx.drawImage(spr.brick, px, py, cs, cs);
        else if (c === MG) { ctx.drawImage(spr.magic[VM.mw > 0 ? 1 : 0], px, py, cs, cs); if (VM.mw > 0) { ctx.fillStyle = 'rgba(196,155,255,' + (0.15 + 0.15 * Math.sin(t * 8 + x)) + ')'; ctx.fillRect(px, py, cs, cs); } }
        else if (c === XC || c === XO) { ctx.drawImage(spr.door[c === XO ? 1 : 0], px, py, cs, cs); if (c === XO) { const gl = ctx.createRadialGradient(px + cs / 2, py + cs / 2, 2, px + cs / 2, py + cs / 2, cs * 1.4); gl.addColorStop(0, 'rgba(255,220,140,' + (0.35 + 0.15 * Math.sin(t * 5)) + ')'); gl.addColorStop(1, 'rgba(255,200,100,0)'); ctx.fillStyle = gl; ctx.fillRect(px - cs, py - cs, cs * 3, cs * 3); } }
        else if (c === SL) ctx.drawImage(spr.slime[((t * 3 + x + y) | 0) & 1], px, py, cs, cs);
        else {
          ctx.drawImage(spr.void[hv & 1], px, py, cs, cs);
          if (c === WB) ctx.drawImage(spr.web, px, py, cs, cs);
          else if (isDoor(c)) drawDoor(px, py, c === TA ? 0 : 1, t, cs);
          else if (c === DY) ctx.drawImage(spr.dyn, px, py, cs, cs);
          else if (c === DL) drawLit(px, py, VM.f ? VM.f[i] : 0, t, cs);
        }
      }
      // pass 2: movers
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const i = y * w + x, c = g[i];
        if (c === RK || c === GM) {
          const [px, py] = objPos(i, k, w);
          if (c === RK) ctx.drawImage(spr.rock[(x * 3 + y) & 1], px, py, cs, cs);
          else {
            const v = (x * 5 + y * 3) % 3;
            ctx.drawImage(spr.gem[v], px, py, cs, cs);
            const tw = Math.sin(t * 2.2 + x * 1.7 + y * 2.3);
            if (tw > 0.85) { const a = (tw - 0.85) / 0.15; ctx.strokeStyle = 'rgba(255,255,255,' + a + ')'; ctx.lineWidth = 1.2; const gx = px + cs * 0.38, gy = py + cs * 0.3, r = cs * 0.16 * a; ctx.beginPath(); ctx.moveTo(gx - r, gy); ctx.lineTo(gx + r, gy); ctx.moveTo(gx, gy - r); ctx.lineTo(gx, gy + r); ctx.stroke(); }
          }
        } else if (c >= FF && c < BG) { const [px, py] = objPos(i, k, w); drawFirefly(px, py, c - FF, t, cs); }
        else if (c >= BG && c < PL) { const [px, py] = objPos(i, k, w); drawBug(px, py, c - BG, t, cs); }
        else if (c === RB) { const [px, py] = objPos(i, k, w); drawRabbit(px, py, i, t, cs, VM.mvFrom[i]); }
        else if (c === SP) { const [px, py] = objPos(i, k, w); drawSpider(px, py, t, cs); }
        else if (c >= BX && c <= BX + 2) { const px = x * cs, py = y * cs; ctx.fillStyle = c === BX + 1 ? 'rgba(120,255,230,.55)' : c === BX + 2 ? 'rgba(200,190,170,.6)' : 'rgba(255,170,80,.7)'; ctx.beginPath(); ctx.arc(px + cs / 2, py + cs / 2, cs * (0.4 + Math.random() * 0.15), 0, 7); ctx.fill(); }
      }
      // players
      for (let s = 0; s < VM.pl.length; s++) {
        const p = VM.pl[s];
        if (!p.a || p.dn) continue;
        const [px, py] = objPos(p.i, k, w);
        drawMiner(px, py, cs, P(s).color, p.fc, t, s === me, VM.mvFrom[p.i] >= 0 && k < 1);
      }
      // fx
      for (const p of parts) { ctx.globalAlpha = Math.min(1, p.t * 3); ctx.fillStyle = p.c; ctx.fillRect(p.x - p.r / 2, p.y - p.r / 2, p.r, p.r); }
      ctx.globalAlpha = 1;
      for (const f of flashes) { const a = f.t / 0.45 * fxk; if (a <= 0.01) continue; const gr = ctx.createRadialGradient(f.x, f.y, 2, f.x, f.y, cs * 2.2); gr.addColorStop(0, 'rgba(255,240,200,' + a + ')'); gr.addColorStop(1, 'rgba(255,120,40,0)'); ctx.fillStyle = gr; ctx.fillRect(f.x - cs * 2.2, f.y - cs * 2.2, cs * 4.4, cs * 4.4); }
      ctx.font = '700 13px ' + MONO; ctx.textAlign = 'center';
      for (const p of pops) { ctx.globalAlpha = Math.min(1, p.t * 2); ctx.fillStyle = p.c; ctx.fillText(p.text, p.x, p.y - cs * 0.4); }
      ctx.globalAlpha = 1;
      ctx.restore();
      // darkness: lamp around me
      if (tp && (tp.a || tp.dn)) {
        const [px, py] = objPos(tp.i, k, w);
        const sxp = px + cs / 2 + ox, syp = py + cs / 2 + oy, R = Math.max(cv.w, cv.h) * 0.62;
        const gr = ctx.createRadialGradient(sxp, syp, cs * 2.2, sxp, syp, R);
        gr.addColorStop(0, 'rgba(6,4,10,0)'); gr.addColorStop(0.55, 'rgba(6,4,10,.28)'); gr.addColorStop(1, 'rgba(6,4,10,.78)');
        ctx.fillStyle = gr; ctx.fillRect(0, 0, cv.w, cv.h);
      }
      drawHud(t);
    }
    function drawIdle(t) {
      ctx.fillStyle = '#0b080d'; ctx.fillRect(0, 0, cv.w, cv.h);
      void t;
    }
    function drawHud(t) {
      const me = mySeat(), fs = me >= 0 ? me : 0, p = VM.pl[fs];
      const secs = Math.max(0, VM.tl * TICK);
      ctx.textBaseline = 'middle';
      // top bar background
      const gr = ctx.createLinearGradient(0, 0, 0, 46); gr.addColorStop(0, 'rgba(8,6,10,.85)'); gr.addColorStop(1, 'rgba(8,6,10,0)');
      ctx.fillStyle = gr; ctx.fillRect(0, 0, cv.w, 50);
      if (!VM.vs) {
        const got = p ? p.gm : 0, ok = got >= VM.q;
        pill(8, 7, 108, 32, ok ? 'rgba(227,174,69,.25)' : 'rgba(30,24,36,.85)', ok ? 'rgba(227,174,69,.8)' : 'rgba(242,233,216,.15)');
        ctx.drawImage(spr.gem[0], 12, 9, 28, 28);
        ctx.font = '700 15px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = ok ? '#ffd98a' : '#f2e9d8';
        ctx.fillText(got + '/' + VM.q, 42, 24);
        const low = secs <= 15;
        pill(cv.w / 2 - 38, 7, 76, 32, low ? 'rgba(238,106,85,.3)' : 'rgba(30,24,36,.85)', low ? 'rgba(238,106,85,.8)' : 'rgba(242,233,216,.15)');
        ctx.textAlign = 'center'; ctx.fillStyle = low ? '#ffb4a6' : '#f2e9d8'; ctx.font = '700 15px ' + MONO;
        ctx.fillText('⏱' + fmtT(secs), cv.w / 2, 24);
        ctx.textAlign = 'left'; ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#ab9fb8';
        ctx.fillText((st.stg || 1) + '단계 · 목숨 ' + '●'.repeat(Math.max(0, lives)) + '○'.repeat(Math.max(0, 3 - lives)), 12, 50);
        if (ok && p && !p.dn && phase === 'play') { ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(255,217,138,' + (0.6 + 0.4 * Math.sin(t * 5)) + ')'; ctx.fillText('출구로 가세요!', cv.w / 2, 50); }
      } else {
        const n = VM.pl.length, cw = Math.min(84, (cv.w - 90) / n);
        for (let s = 0; s < n; s++) {
          const q = VM.pl[s], x = 6 + s * (cw + 4);
          pill(x, 7, cw, 32, s === me ? 'rgba(227,174,69,.22)' : 'rgba(30,24,36,.85)', s === me ? 'rgba(227,174,69,.75)' : 'rgba(242,233,216,.12)');
          ctx.fillStyle = P(s).color; ctx.beginPath(); ctx.arc(x + 14, 23, 6, 0, 7); ctx.fill();
          ctx.font = '700 14px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = q.dn ? '#ffd98a' : q.a ? '#f2e9d8' : '#776b80';
          ctx.fillText((q.dn ? '★' : '') + q.gm, x + 24, 24);
        }
        const low = secs <= 15;
        pill(cv.w - 76, 7, 70, 32, low ? 'rgba(238,106,85,.3)' : 'rgba(30,24,36,.85)', low ? 'rgba(238,106,85,.8)' : 'rgba(242,233,216,.15)');
        ctx.textAlign = 'center'; ctx.fillStyle = low ? '#ffb4a6' : '#f2e9d8'; ctx.font = '700 15px ' + MONO; ctx.fillText(fmtT(secs), cv.w - 41, 24);
        ctx.font = '600 11px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'left';
        ctx.fillText(VM.xo ? '출구 열림 · 보석 ' + VM.q + '개 넘으면 탈출 가능' : '보석 ' + VM.q + '개 먼저 모으면 출구가 열려요', 8, 52);
        if (p && !p.a && !p.dn && phase === 'play') { ctx.font = '400 22px ' + DISP; ctx.textAlign = 'center'; ctx.fillStyle = '#ee6a55'; ctx.fillText('깔렸어요! 곧 다시 출발 (−' + DEATH_COST + ')', cv.w / 2, cv.h * 0.4); }
      }
      // center banners
      ctx.textAlign = 'center';
      if (phase === 'ready' && st.m === 's') {
        ctx.fillStyle = 'rgba(8,6,10,.6)'; ctx.fillRect(0, cv.h * 0.32, cv.w, 96);
        ctx.font = '400 30px ' + DISP; ctx.fillStyle = '#e3ae45'; ctx.fillText((st.stg || 1) + '단계', cv.w / 2, cv.h * 0.32 + 34);
        ctx.font = '600 14px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText((cave && cave.name ? cave.name + ' · ' : '') + '보석 ' + VM.q + '개 모으고 출구로', cv.w / 2, cv.h * 0.32 + 70);
      } else if (phase === 'count') {
        ctx.font = '400 64px ' + DISP; ctx.fillStyle = '#e3ae45'; ctx.fillText(String(Math.max(1, Math.ceil(cd))), cv.w / 2, cv.h * 0.38);
        ctx.font = '600 14px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText('보석을 가장 많이 모으세요 · 바위 조심!', cv.w / 2, cv.h * 0.38 + 50);
        if (me >= 0 && !isAI(me)) { ctx.fillStyle = '#ab9fb8'; ctx.font = '600 12px ' + FONT; ctx.fillText('화면을 밀거나 패드를 누르고 있으면 계속 가요', cv.w / 2, cv.h * 0.38 + 74); }
      } else if (phase === 'end' && st.m === 'v') {
        ctx.font = '400 34px ' + DISP; ctx.fillStyle = '#e3ae45'; ctx.fillText('끝!', cv.w / 2, cv.h * 0.4);
      }
    }

    cv.onresize = () => { buildSprites(); cam.ok = false; };
    buildSprites();
    syncPad();
    const stopLoop = U.loop(frame);

    function update(s, prev) {
      st = s;
      const nk = curKey();
      if (s.ph === 'done') { closeOv(); phase = 'end'; syncPad(); return; }
      syncPad();
      if (s.m === 's' && s.ph === 'pick') {
        if (phase !== 'pick') {
          if (isAI(0)) { if (host()) setTimeout(() => { if (st && st.ph === 'pick') beginRun(1); }, 300); phase = 'pick'; }
          else if (host()) showPicker();
        }
        return;
      }
      if (s.m === 's') { lives = s.lf; runScore = s.sc | 0; cleared = s.cl | 0; topStage = s.top | 0; }
      if (nk !== key) { key = nk; startWorld(); }
      else if (s.m === 'v' && s.ph === 'play' && phase === 'count' && !host()) { /* guest keeps own countdown */ }
      syncPad();
      void prev;
    }
    return {
      update,
      destroy() { if (hintOff) hintOff(); stopLoop(); if (offIn) offIn(); cv.destroy(); closeOv(); pad.remove(); padChip.remove(); retryChip.remove(); bombChip.remove(); styleEl.remove(); },
    };
  }

  /* ======================= codex ======================= */
  const svgI = (inner) => '<svg viewBox="0 0 32 32" width="32" height="32">' + inner + '</svg>';
  const CODEX = [
    { h: '동굴', p: ['동굴을 이루는 것들이에요. 무게가 있는 것(바위·보석)은 받침이 없으면 떨어져요.'], rows: [
      { icon: svgI('<rect x="2" y="2" width="28" height="28" rx="3" fill="#4d3626"/><circle cx="10" cy="12" r="2" fill="#7a5a3e"/><circle cx="21" cy="20" r="2.5" fill="#2c1d13"/>'), name: '흙', tag: '파는 것', desc: '지나가면 파여서 빈 칸이 돼요. 바위·보석을 받쳐 주는 받침이에요.' },
      { icon: svgI('<rect x="2" y="2" width="28" height="28" rx="3" fill="#2e2b35"/><path d="M14 2l-3 10 5 8-2 10" stroke="#111" stroke-width="1.5" fill="none"/>'), name: '암반', tag: '못 부숨', desc: '무엇으로도 부서지지 않는 벽. 동굴 테두리도 암반이에요.' },
      { icon: svgI('<rect x="2" y="2" width="28" height="28" fill="#2a211b"/><rect x="3" y="3" width="12" height="12" fill="#6b5645"/><rect x="17" y="3" width="12" height="12" fill="#6b5645"/><rect x="9" y="17" width="14" height="12" fill="#6b5645"/>'), name: '석벽', tag: '둥근 윗면', desc: '지나갈 수 없지만 폭발에는 부서져요. 위의 바위·보석이 옆으로 굴러떨어져요.' },
      { icon: svgI('<rect x="2" y="2" width="28" height="28" fill="#2b1f3e"/><path d="M16 6v20M9 11l7 6 7-6M10 25h12" stroke="#c49bff" stroke-width="2" fill="none"/>'), name: '마법 석판', tag: '바위↔보석', desc: '떨어지는 바위가 닿으면 깨어나서, 위에서 떨어진 바위는 아래로 보석이 되어 나오고 보석은 바위가 돼요. 깨어난 뒤 잠시 뒤엔 영영 잠들어요. 아래 칸이 막혀 있으면 사라져요.' },
      { icon: svgI('<rect x="2" y="2" width="28" height="28" fill="#4a4350"/><path d="M8 30V14a8 8 0 0116 0v16z" fill="#f0b24a"/>'), name: '출구', tag: '목표', desc: '모아야 할 보석 수를 채우면 열려요(빛이 나요). 들어가면 단계 돌파.' },
    ] },
    { h: '떨어지는 것', p: ['바위와 보석은 아래가 비면 떨어지고, 다른 바위·보석·석벽 위에서는 옆이 비어 있으면 굴러떨어져요.'], rows: [
      { icon: svgI('<circle cx="16" cy="17" r="12" fill="#7d756a"/><circle cx="12" cy="12" r="4" fill="#b3aa9b"/>'), name: '바위', tag: '무거움', desc: '떨어지는 바위에 맞으면 깔려요(폭발). 옆에 빈 칸이 있으면 옆으로 밀 수 있어요(두 번 밀기). 떨어지는 바위로 적을 깔면 적이 터져요.' },
      { icon: svgI('<path d="M16 4l11 8-4 14H9L5 12z" fill="#5ef0e0"/><path d="M16 4l-11 8 11 4z" fill="#18a3a0"/>'), name: '보석', tag: '+1', desc: '지나가면 주워요. 떨어지는 보석은 머리 위로 떨어져도 그냥 주워져요(안 다쳐요).' },
    ] },
    { h: '동굴 생물', p: ['적에게 바로 옆(위·아래·좌·우)으로 닿으면 그 자리에서 터져요. 터지면 3×3칸이 날아가요.'], rows: [
      { icon: svgI('<ellipse cx="9" cy="15" rx="7" ry="9" fill="#f0642a"/><ellipse cx="23" cy="15" rx="7" ry="9" fill="#f0642a"/><ellipse cx="16" cy="16" rx="2.5" ry="9" fill="#2a1712"/>'), name: '불나방', tag: '터지면 보석', desc: '빈 칸을 따라 왼쪽 벽을 짚으며 날아다녀요. 떨어지는 바위로 깔면 3×3칸이 보석 9개로 바뀌어요!' },
      { icon: svgI('<ellipse cx="16" cy="10" rx="7" ry="4" fill="#5a6672"/><ellipse cx="16" cy="17" rx="8" ry="4" fill="#6a7682"/><ellipse cx="16" cy="24" rx="7" ry="4" fill="#5a6672"/>'), name: '돌벌레', tag: '터지면 바위', desc: '오른쪽 벽을 짚으며 기어다녀요. 깔리거나 닿아서 터지면 3×3칸이 바위 덩어리로 굳어요.' },
      { icon: svgI('<path d="M4 18c0-8 6-12 12-12s12 4 12 12-6 10-12 10S4 26 4 18z" fill="#6f9a2a"/><circle cx="12" cy="13" r="2" fill="#e6ffb4"/>'), name: '점액', tag: '번짐', desc: '흙과 빈 칸으로 조금씩 번져요. 사방이 막혀 더 못 번지면 전부 보석으로 굳고, 너무 커지면 바위로 굳어요. 닿은 적은 터져요.' },
      { icon: svgI('<ellipse cx="14" cy="20" rx="9" ry="7" fill="#a8927a"/><circle cx="22" cy="15" r="5" fill="#a8927a"/><ellipse cx="20" cy="7" rx="1.6" ry="5" fill="#8d785f"/><ellipse cx="24" cy="7" rx="1.6" ry="5" fill="#8d785f"/>'), name: '굴토끼', tag: '굴 파기 · 무해', desc: '흙과 빈 칸을 이리저리 파고 다녀요(0.28초에 한 칸). 닿아도 안 다치지만 길을 막고, 바위 밑을 파서 바위를 떨어뜨리기도 해요. 떨어지는 바위에 깔리면 보석 1개가 남아요.' },
      { icon: svgI('<path d="M6 10l6 6M26 10l-6 6M5 18h7M27 18h-7M7 26l6-5M25 26l-6-5" stroke="#9b8fc4" stroke-width="2"/><path d="M16 12l6 6-6 9-6-9z" fill="#b9a6ff"/><circle cx="16" cy="11" r="3.5" fill="#5ef0e0"/>'), name: '수정 거미', tag: '거미줄 · 터지면 보석', desc: '빈 칸으로만 천천히 다니며(0.42초에 한 칸) 지나간 자리에 거미줄을 쳐요. 닿아도 안 다쳐요. 떨어지는 바위로 깔면 터지며 3×3칸이 보석으로 바뀌어요(광부가 옆에 있으면 위험).' },
      { icon: svgI('<rect x="2" y="2" width="28" height="28" fill="#100c12"/><path d="M16 16L4 6M16 16l12-10M16 16L4 27M16 16l12 11M16 16V3M16 16v13" stroke="#ece8f6" stroke-width="1"/><circle cx="16" cy="16" r="5" fill="none" stroke="#ece8f6"/><circle cx="16" cy="16" r="10" fill="none" stroke="#ece8f6" opacity=".7"/>'), name: '거미줄', tag: '느려짐', desc: '걸어 들어가면 ' + (WEB_STUCK * TICK).toFixed(2).replace(/0$/, '') + '초 동안 꼼짝 못 해요(줄은 걷혀요). 떨어지는 바위·보석은 거미줄을 뚫고 떨어져요.' },
    ] },
    { h: '장치', p: ['5단계부터 나오는 장치예요. 끝없는 굴에도 깊이에 따라 나와요.'], rows: [
      { icon: svgI('<circle cx="16" cy="16" r="13" fill="#2a2530"/><circle cx="16" cy="16" r="10" fill="#7af5e0"/><path d="M10 16a6 6 0 0112 0" stroke="#fff" stroke-width="2" fill="none"/>'), name: '텔레포트 문', tag: '같은 색 둘이 한 쌍', desc: '문으로 걸어 들어가면 같은 색 다른 문의 반대편으로 나와요(들어간 방향 그대로). 나올 칸이 바위·벽 등으로 막혀 있으면 못 들어가요. 문은 폭발에도 안 부서지고, 바위는 통과하지 못해요.' },
      { icon: svgI('<rect x="8" y="11" width="5" height="16" fill="#d8483a"/><rect x="13.5" y="11" width="5" height="16" fill="#b63a2e"/><rect x="19" y="11" width="5" height="16" fill="#d8483a"/><rect x="7" y="17" width="18" height="3" fill="#c9b48a"/><path d="M16 11q2-5 6-5" stroke="#d9cfb8" stroke-width="1.5" fill="none"/>'), name: '다이너마이트', tag: '줍고 놓기', desc: '지나가면 주워요(여러 개 가능). 「💣」 버튼(PC: 스페이스·E)으로 보는 쪽 칸에 놓으면 ' + (FUSE * TICK).toFixed(1) + '초 뒤 3×3칸이 터져요. 석벽·바위·흙을 날려 길을 뚫지만 광부도 휘말리면 끝! 다른 다이너마이트를 건드리면 같이 터져요. 암반·출구·문은 안 부서져요.' },
    ] },
  ];

  /* ======================= register ======================= */
  L.register({
    id: 'gemcave', name: '보석 동굴 캐기', tag: '굴 파기 퍼즐 액션', cat: '아케이드',
    blurb: '흙을 파며 보석을 모으고 출구로! 받침을 파내면 바위가 떨어져요. 혼자 끝없는 단계, 또는 2–4명 실시간 보석 쟁탈전.',
    tint: '#3b2a1c',
    icon: '<rect x="4" y="34" width="48" height="18" rx="3" fill="currentColor" opacity=".35"/><circle cx="18" cy="24" r="10" fill="currentColor" opacity=".7"/><path d="M38 10l9 7-3 12h-12l-3-12z" fill="currentColor"/><path d="M38 10l-9 7 9 3z" fill="#3b2a1c" opacity=".5"/><path d="M8 50l14-14M18 36l6 0" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'mode', label: '방식', tip: '혼자 또는 대전.', choices: [{ v: 'solo', label: '혼자 · 단계 도전', tip: '혼자 단계를 하나씩 깨요.' }, { v: 'vs', label: '대전 · 보석 쟁탈', tip: '2–4명이 실시간으로 보석을 더 많이 모으기.' }], def: 'solo' },
    ],
    controls: [
      { id: 'up', label: '위로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'bomb', label: '다이너마이트 놓기', keys: ['Space', 'KeyE'], pad: ['a'] },
      { id: 'retry', label: '다시 하기(혼자)', keys: ['KeyR'], pad: ['back'] },
    ],
    quick: [
      '흙을 파며 다니면서 보석을 모아요. 정한 개수를 채우면 출구가 열려요.',
      '바위·보석은 아래가 비면 떨어지고, 둥근 것 위에선 옆으로 굴러요. 떨어지는 바위에 깔리면 끝!',
      '혼자: 출구로 나가면 단계 돌파. 대전: 시간이 끝날 때 보석이 가장 많은 사람이 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '광부가 되어 동굴을 파 내려가요. 흙 칸으로 움직이면 흙이 파이고, 보석 칸으로 가면 보석을 주워요.',
        '화면 위에 「모은 보석 / 필요한 수」가 보여요. 필요한 수를 채우면 출구가 빛나며 열려요. 출구로 들어가면 단계 돌파!',
      ] },
      { h: '떨어지는 바위와 보석', p: [
        '바위·보석은 바로 아래가 빈 칸이면 떨어져요. 바위·보석·석벽 위에 얹혀 있으면 옆과 옆 아래가 비었을 때 굴러떨어져요.',
        '떨어지고 있는 바위가 광부 위로 떨어지면 깔려요(폭발). 그냥 얹혀 있던 바위는 바로 밑에 서 있어도 괜찮아요.',
        '예시: 바위 바로 밑의 흙을 파고 들어간 다음 그대로 아래로 또 내려가면, 바위가 따라 떨어져 깔려요. 파고 들어갔으면 옆으로 비켜요!',
        '떨어지는 보석은 머리에 맞아도 그냥 주워져요.',
        '바위 옆에 빈 칸이 있으면 옆으로 밀 수 있어요. 같은 쪽으로 계속 누르면 두 번째에 밀려요.',
      ] },
      { h: '동굴 생물', p: [
        '불나방과 돌벌레는 빈 칸을 따라 움직여요. 바로 옆에 닿으면 터져서 3×3칸이 날아가요(광부도 위험!).',
        '떨어지는 바위로 깔면: 불나방은 보석 9개로, 돌벌레는 바위 덩어리로 바뀌어요.',
        '점액은 천천히 번져요. 갇히면 보석으로, 너무 커지면 바위로 굳어요. 마법 석판은 위에서 떨어진 바위를 보석으로(보석은 바위로) 바꿔 아래로 내보내요. 자세한 건 📖 도감.',
        '굴토끼는 흙을 마구 파고 다녀요. 닿아도 괜찮지만 바위 밑을 파 버리면 바위가 떨어지니 조심! 깔린 굴토끼는 보석 1개가 돼요.',
        '수정 거미는 빈 칸을 다니며 거미줄을 쳐요. 거미줄에 들어가면 잠깐(약 0.4초) 못 움직여요. 떨어지는 바위로 깔면 보석 9개!',
      ] },
      { h: '장치 (텔레포트 문 · 다이너마이트)', p: [
        '텔레포트 문: 같은 색 문 두 개가 한 쌍이에요. 걸어 들어가면 다른 문의 반대편으로 같은 방향 그대로 나와요. 나올 곳이 막혔으면 못 들어가요.',
        '다이너마이트: 지나가면 주워요. 갖고 있으면 「💣 개수」 버튼이 나와요(PC: 스페이스·E, 게임패드 A). 누르면 바라보는 칸에 놓이고 ' + (FUSE * TICK).toFixed(1) + '초 뒤 3×3칸이 터져요.',
        '예시: 석벽에 막혔다 → 벽 옆 흙에 다이너마이트를 놓고 두 칸 이상 물러나요 → 쾅! 벽이 뚫려요. 머리 위 바위도 같이 떨어질 수 있어요.',
      ] },
      { h: '혼자 · 단계 도전', p: [
        '목숨 3개로 출발해요. 1~10단계는 손수 만든 굴(6단계 문·다이너마이트, 8단계 거미·굴토끼, 10단계 전부), 11단계부터는 끝없이 새 굴이 만들어져요(컴퓨터가 미리 깨 보고 통과한 굴만 나와요).',
        '깔리거나 시간이 다 되면 목숨 하나를 잃고 같은 굴을 처음부터 다시 해요. 꽉 막혔으면 「↺ 다시」(PC: R).',
        '점수 = 보석×10 + 필요 수를 넘긴 보석×10 + 남은 시간×2. 단계마다 최고 점수와 가장 깊이 간 단계가 🏆 기록에 남아요. 깬 단계까지는 처음 화면에서 골라 다시 할 수 있어요.',
      ] },
      { h: '대전 · 보석 쟁탈 (2–4명)', p: [
        '2명 이상이면 방식과 상관없이 대전이 돼요(혼자 단계 도전은 1명일 때만).',
        '모두 같은 좌우 대칭 동굴의 네 귀퉁이에서 출발해 2분 동안 보석을 모아요. 한 기기에 한 명(친구와는 온라인/LAN), 빈 자리는 AI.',
        '누군가 정한 수만큼 보석을 모으면 가운데 출구가 열려요. 정한 수 이상 가진 사람이 출구로 나가면 보석 +' + EXIT_BONUS + '개, 그 뒤 남은 시간은 최대 ' + VS_AFTER_EXIT + '초로 줄어요.',
        '깔리면 보석 ' + DEATH_COST + '개를 잃고 3초 뒤 출발점 근처에서 다시 나와요. 끝났을 때 보석이 가장 많은 사람이 승리.',
      ] },
      { h: '조작', p: [
        '화면 아무 데나 누른 채 밀면 그 방향으로 계속 가요(떼면 멈춤). 짧게 밀면 한 칸.',
        '오른쪽 아래 십자 패드: 누르고 있으면 계속 가고, 손가락을 미끄러뜨려 방향을 바꿔요. 왼쪽 아래 칩으로 패드를 왼쪽/오른쪽/끄기로 바꿔요.',
        'PC: 방향키·WASD, R = 다시 하기. 게임패드 십자키·왼스틱. 키는 「⌨ 조작 설정」에서 바꿔요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(어려움일수록 위험을 잘 피하고 출구 타이밍을 잘 재요).',
      ] },
    ],
    codex: CODEX,
    init, result,
    actor() { return null; },
    apply(s) { return s; },
    ai() { return null; },
    mount,
    _eng: { TICK, CH, STAGES, RB, WB, SP, TA, TB, DY, DL, parseMap, genCave, newWorld, step, botDir, soloOutcome, vsOver, stageCave, vsCave, rle, unrle, playTest, encMoves, encEv, hash2 },
  });
})();
