/* 요리 대작전 — realtime cooking race (1–4). Every player runs an identical kitchen (same layout, same order sequence)
   for a few minutes: take ingredients, chop, fry, boil, bake, plate and serve before the order tickets run out.
   Controls are tap-only: tap a station and the chef walks there by himself and does the obvious thing.
   Each kitchen is simulated on the device that owns it (no lag for your own chef); the host runs the AI kitchens,
   keeps the game clock and collects scores. One person per phone; friends play through online/LAN rooms. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= data ======================= */
  const GW = 7, GH = 9, NT = GW * GH;
  const srt = (s) => s.split('').sort().join('');
  // items: code -> [name, color]. Codes are single characters (latin = the original set, hangul = added later).
  // raw things come out of crates; prepared things come out of a board or a cooker. x = burnt, 목 = firewood (camp kitchen)
  const IT = {
    b: ['빵', '#d9a35b'], m: ['생고기', '#e07a7a'], l: ['양상추', '#7cc35a'], t: ['토마토', '#e5483b'], c: ['치즈', '#f2c94c'],
    r: ['쌀', '#efe9dc'], f: ['생선', '#8fb3c9'], u: ['오이', '#4f9d4a'], n: ['김', '#2f4a36'], p: ['생면', '#f0d78a'],
    d: ['도우', '#ecd3a4'], g: ['떡', '#f4efe6'], j: ['고추장', '#b8322a'], e: ['계란', '#fbf3e4'], o: ['양파', '#b07cc6'],
    a: ['반죽', '#f1dcae'], s: ['딸기', '#e8394f'], k: ['감자', '#c8a06a'],
    M: ['패티', '#7a4a2a'], L: ['썬 양상추', '#7cc35a'], T: ['썬 토마토', '#e5483b'], R: ['밥', '#f6f3ea'], F: ['회', '#f08a5d'],
    U: ['썬 오이', '#6fbf5a'], P: ['삶은 면', '#f0d78a'], O: ['썬 양파', '#c99be0'], E: ['계란프라이', '#ffd84a'], A: ['팬케이크', '#e0a050'],
    S: ['썬 딸기', '#e8394f'], K: ['썬 감자', '#ecd9a0'], V: ['감자튀김', '#f2c14e'], J: ['생선구이', '#b07a4a'],
    Q: ['토마토 수프', '#d8432f'], Y: ['양파 수프', '#a8693a'], G: ['떡볶이', '#d0402c'], N: ['라면', '#e0703a'],
    Z: ['치즈 피자', '#f2c94c'], X: ['감자 그라탕', '#e8b04a'], x: ['탄 음식', '#2a2420'],
    // added raw
    닭: ['생닭', '#f0b2a6'], 새: ['생새우', '#b9c4cc'], 우: ['우유', '#f4f6fa'], 밀: ['밀가루', '#efe6d2'], 바: ['바나나', '#f5d33a'],
    춘: ['춘장', '#3a2416'], 소: ['소시지', '#d4705a'], 파: ['대파', '#6fbf4a'], 두: ['두부', '#f6f1e2'], 치: ['김치', '#d8432f'],
    된: ['된장', '#8a5a2a'], 피: ['피망', '#3f9a3a'], 징: ['오징어', '#f2d6c4'], 펄: ['타피오카 펄', '#3a2a2a'], 찻: ['찻잎', '#5a8a3a'],
    인: ['파인애플', '#f2c230'], 동: ['우동면', '#f4ecd6'], 삼: ['삼겹살', '#f0a9a0'], 구: ['고구마', '#9a4a6a'], 마: ['마시멜로', '#fbf4f0'],
    카: ['카레 블록', '#c88a2a'], 크: ['생크림', '#fffaf0'], 초: ['초콜릿', '#5a3420'], 얼: ['얼음', '#cfeaf6'], 팥: ['팥', '#8a2a32'],
    원: ['원두', '#6a4024'], 레: ['레몬', '#f7e04a'], 양: ['양념 소스', '#c8321e'], 탕: ['탕수 소스', '#f08a3a'], 또: ['또르티야', '#efd9a0'],
    국: ['쌀국수면', '#f6f2e6'], 버: ['양송이', '#d9c4a8'], 어: ['어묵', '#e8b878'], 목: ['장작', '#8a5a32'],
    // added prepared
    육: ['썬 고기', '#d86a6a'], 쪽: ['썬 파', '#7cc35a'], 판: ['썬 두부', '#f6f1e2'], 링: ['썬 피망', '#4fb04a'], 조: ['썬 레몬', '#f7e04a'],
    송: ['썬 양송이', '#d9c4a8'], 살: ['썬 닭고기', '#f0b2a6'], 덩: ['반죽 덩이', '#f1dcae'], 가: ['커피 가루', '#5a3420'], 빙: ['간 얼음', '#e8f6fc'],
    굽: ['구운 소시지', '#a8452e'], 킨: ['후라이드 치킨', '#d9902e'], 튀: ['새우튀김', '#e8a83a'], 까: ['튀긴 고기', '#c98a3a'], 깡: ['오징어튀김', '#e8b04a'],
    말: ['김말이 튀김', '#c99040'], 짜: ['짜장 소스', '#3a2416'], 뽕: ['짬뽕 국물', '#c8321e'], 데: ['데친 새우', '#f08a6a'], 장: ['된장국', '#a8743a'],
    란: ['삶은 계란', '#f6efe0'], 드: ['우동', '#e8d8b0'], 커: ['카레', '#d8a02a'], 프: ['감자 수프', '#f2e2b0'], 떡: ['떡국', '#f4efe6'],
    찌: ['김치찌개', '#c8321e'], 묵: ['어묵탕', '#e8c890'], 쌀: ['쌀국수', '#e8dcc0'], 림: ['크림 소스', '#f6efe0'], 스: ['양송이 수프', '#e0d0b0'],
    시: ['케이크 시트', '#f0c870'], 쿠: ['초코 쿠키', '#b07a40'], 만: ['고기 만두', '#f6f0e4'], 하: ['새우 만두', '#f4e8e0'], 찐: ['찐빵', '#faf6ee'],
    찜: ['계란찜', '#ffd84a'], 꼬: ['닭꼬치', '#b0602a'], 꽂: ['소떡소떡', '#c8402a'], 꿰: ['소고기 꼬치', '#8a4424'], 불: ['불고기', '#7a3a1e'],
    오: ['오징어 구이', '#d8803a'], 애: ['파인애플 꼬치', '#f2b030'], 겹: ['구운 삼겹살', '#c87a50'], 군: ['군고구마', '#6a2a3a'], 멜: ['구운 마시멜로', '#e8b070'],
    테: ['스테이크', '#6a2e1a'], 숯: ['닭구이', '#b8702a'], 케: ['케밥 고기', '#9a5a2a'], 팟: ['팟타이', '#e0a050'], 티: ['밀크티', '#c8a07a'],
    무: ['딸기 스무디', '#f07a8a'], 셰: ['바나나 셰이크', '#f6e08a'], 휘: ['휘핑크림', '#fffaf0'], 아: ['아이스 커피', '#4a2a1a'],
  };
  /* board work (one raw thing -> one prepared thing, the chef works on it): 도마 썰기 · 반죽대 반죽 · 분쇄기 갈기 */
  const WKP = { cut: { n: '도마', v: '썰기', ing: '써는 중', t: 1.6 }, knead: { n: '반죽대', v: '반죽', ing: '반죽하는 중', t: 2.2 }, grind: { n: '분쇄기', v: '갈기', ing: '가는 중', t: 1.8 } };
  const WORK = {}, WK = {};
  [['cut', 'lL tT fF uU oO sS kK m육 파쪽 두판 피링 레조 버송 닭살'], ['knead', '밀덩'], ['grind', '원가 얼빙']]
    .forEach(([kd, s]) => s.split(' ').forEach((p) => { WORK[p[0]] = p[1]; WK[p[0]] = kd; }));
  const CHOP_T = { f: 2.2, k: 2.0, 닭: 2.0 };
  /* cookers: one = takes exactly one thing; otherwise a recipe (multiset) that starts cooking when complete. nob = never burns */
  const CKP = {
    pan: { n: '팬', one: 1, cook: 5, safe: 5 }, fry: { n: '튀김기', one: 1, cook: 6, safe: 6 },
    pot: { n: '냄비', cook: 8, safe: 7 }, oven: { n: '오븐', cook: 9, safe: 6 }, steam: { n: '찜기', cook: 7, safe: 8 },
    grill: { n: '석쇠', cook: 6, safe: 5 }, mix: { n: '믹서', cook: 3, safe: 1e9, nob: 1 },
  };
  const ONE = {}, REC = { pot: {}, oven: {}, steam: {}, grill: {}, mix: {} };
  [['pan', 'mM eE aA fJ 소굽'], ['fry', 'KV 닭킨 새튀 육까 징깡 n말']].forEach(([ck, s]) => s.split(' ').forEach((p) => { ONE[p[0]] = [ck, p[1]]; }));
  const RECS = {
    pot: 'r>R p>P TTT>Q OOO>Y ggj>G jp>N O춘>짜 Oj새>뽕 새>데 된판>장 e>란 동쪽>드 KO카>커 K우>프 ge>떡 치판>찌 어쪽>묵 국육>쌀 크송>림 송송우>스',
    oven: 'Tcd>Z Kc>X 덩e>시 덩초>쿠',
    steam: '덩육>만 덩새>하 덩팥>찐 ee>찜',
    grill: '살쪽>꼬 g소>꽂 링육>꿰 O육>불 징>오 인>애 삼>겹 구>군 마>멜 m>테 닭>숯 육>케 국새>팟',
    mix: '우찻>티 s우>무 바우>셰 크>휘 가얼>아',
  };
  const SRC = {}; // prepared code -> [work kind or cooker, source chars]
  for (const k in WORK) SRC[WORK[k]] = [WK[k], k];
  for (const k in ONE) SRC[ONE[k][1]] = [ONE[k][0], k];
  for (const ck in RECS) RECS[ck].split(' ').forEach((p) => { const [a, b] = p.split('>'), key = srt(a); REC[ck][key] = b; SRC[b] = [ck, key]; });
  const isOne = (ck) => !!(CKP[ck] && CKP[ck].one);
  const WARN = 3, FIRE_T = 4;
  const WASH = 1.3, EXT = 1.2, RET = 6, WALK = 4.2, SLIDE = 5.4, BELT_V = 1.1, MAXQ = 3, MAX_ORD = 4, BOOST = 0.17;
  const DOOR_P = 7, ISL_DWELL = 2.4, ISL_MOVE = 0.7, MOUSE_V = 2.1, PLATES = 4;
  const FUEL_T = 42, REGROW = 3.5, NIGHT_P = 12, NIGHT_LV = [0.6, 1, 1.6], LURCH_A = 0.9;

  const DISH = {};
  [['burger', '햄버거', 'Mb'], ['cburger', '치즈버거', 'Mbc'], ['vburger', '야채버거', 'LMTb'], ['fries', '감자튀김', 'V'],
    ['salad', '샐러드', 'LT'], ['csalad', '오이 샐러드', 'LTU'], ['tsoup', '토마토 수프', 'Q'], ['osoup', '양파 수프', 'Y'],
    ['nigiri', '생선 초밥', 'FR'], ['cmaki', '오이 마키', 'RUn'], ['fmaki', '생선 마키', 'FRn'], ['gfish', '생선구이 정식', 'JR'],
    ['kimbap', '김밥', 'RUn'], ['onigiri', '주먹밥', 'Rn'], ['tteok', '떡볶이', 'G'], ['ramen', '라면', 'N'],
    ['pizza', '치즈 피자', 'Z'], ['tpasta', '토마토 파스타', 'PT'], ['cpasta', '치즈 파스타', 'Pc'], ['gratin', '감자 그라탕', 'X'],
    ['bibim', '비빔밥', 'ELRU'], ['vbibim', '야채 비빔밥', 'LRU'], ['eggrice', '계란밥', 'ER'],
    ['pancake', '팬케이크', 'A'], ['spancake', '딸기 팬케이크', 'AS'], ['etoast', '계란 토스트', 'Eb'], ['ctoast', '치즈 토스트', 'Ebc'],
    // added
    ['fchicken', '후라이드 치킨', '킨'], ['ychicken', '양념치킨', '킨양'], ['tempura', '새우튀김', '튀'], ['chburger', '치킨버거', 'bL킨'],
    ['jjajang', '짜장면', 'P짜'], ['jjamppong', '짬뽕', 'P뽕'], ['tangsu', '탕수육', '까탕'], ['kkanshow', '깐쇼새우', '튀탕'],
    ['hotdog', '핫도그', 'b굽'], ['dakkochi', '닭꼬치', '꼬'], ['sotteok', '소떡소떡', '꽂'],
    ['ebi', '새우 초밥', 'R데'], ['tamago', '계란 초밥', 'ERn'], ['miso', '된장국', '장'],
    ['beefsk', '소고기 꼬치', '꿰'], ['squid', '오징어 구이', '오'], ['pinesk', '파인애플 꼬치', '애'], ['bubble', '버블티', '티펄'],
    ['dosirak', '추억의 도시락', 'ER굽'], ['begg', '삶은 계란', '란'], ['udon', '우동', '드'],
    ['ssam', '삼겹살 쌈', '겹l'], ['goguma', '군고구마', '군'], ['mallow', '마시멜로 구이', '멜'],
    ['curry', '카레라이스', '커R'], ['psoup', '감자 수프', '프'], ['smoothie', '딸기 스무디', '무'], ['shake', '바나나 셰이크', '셰'],
    ['scake', '딸기 케이크', '시휘s'], ['cookie', '초코 쿠키', '쿠'], ['patbing', '팥빙수', '빙팥'], ['chocobing', '초코 빙수', '빙초휘'],
    ['americano', '아이스 아메리카노', '아'], ['latte', '아이스 라떼', '아우'], ['lemonade', '레몬에이드', '조얼'],
    ['kimchijj', '김치찌개', '찌'], ['bulgogi', '불고기 정식', '불R'], ['tteokguk', '떡국', '떡'], ['kfried', '김치볶음밥', 'ER치'],
    ['eomuk', '어묵탕', '묵'], ['squidfry', '오징어튀김', '깡'], ['rabokki', '라볶이', 'GP'], ['gimmari', '김말이 튀김', '말'],
    ['taco', '타코', '또숯T'], ['kebab', '케밥', '또케L'], ['pho', '쌀국수', '쌀'], ['padthai', '팟타이', '팟'],
    ['steak', '스테이크 정식', '테스'], ['cpasta2', '크림 파스타', 'P림'], ['msoup', '양송이 수프', '스'], ['ssalad', '스테이크 샐러드', '테L'],
    ['mandu', '고기 만두', '만'], ['hagao', '새우 만두', '하'], ['jjinppang', '찐빵', '찐'], ['gyeranjjim', '계란찜', '찜'],
  ].forEach(([id, n, c]) => { DISH[id] = { id, n, c: srt(c) }; });
  const isWork = (kd) => !!WKP[kd];
  function stepsOf(c) { const s = SRC[c]; if (!s) return 0; let n = 1; for (const ch of s[1]) n += stepsOf(ch); return n; }
  function cookOf(c) { const s = SRC[c]; if (!s) return 0; let m = 0; for (const ch of s[1]) m = Math.max(m, cookOf(ch)); return (isWork(s[0]) ? 0 : CKP[s[0]].cook) + m; }
  function rawOf(c) { const s = SRC[c]; if (!s) return c; let o = ''; for (const ch of s[1]) o += rawOf(ch); return o; }
  for (const id in DISH) {
    const D = DISH[id], c = D.c;
    let st = 0, ck = 0, raw = '';
    for (const ch of c) { st += stepsOf(ch); ck = Math.max(ck, cookOf(ch)); raw += rawOf(ch); }
    D.steps = st; D.raw = raw;
    D.pts = Math.round((5 + 8 * raw.length + 5 * st) / 5) * 5;
    D.lim = Math.round(32 + 8 * raw.length + 6 * st + ck);
  }

  /* menus: 4 dishes each. Crate ingredients, cooker and board kinds are worked out from the dishes unless given.
     Limits (so every kitchen can cook every menu): ≤ 7 raw ingredients, ≤ 3 cooker kinds, ≤ 2 board kinds,
     and no recipe of one cooker kind inside another one of the same kind (it would start cooking too early). */
  const MENUS = [
    { id: 'burger', n: '버거 가게', ing: 'bmltck', d: ['burger', 'cburger', 'vburger', 'fries'] },
    { id: 'soup', n: '샐러드·수프', ing: 'ltuo', heat: ['pot', 'pot', 'pot'], d: ['salad', 'csalad', 'tsoup', 'osoup'] },
    { id: 'sushi', n: '스시 바', ing: 'rfun', heat: ['pot', 'pot', 'pan'], d: ['nigiri', 'cmaki', 'fmaki', 'gfish'] },
    { id: 'snack', n: '분식집', ing: 'nrugjp', heat: ['pot', 'pot', 'pot'], d: ['kimbap', 'onigiri', 'tteok', 'ramen'] },
    { id: 'italy', n: '피자·파스타', ing: 'dtcpk', heat: ['oven', 'oven', 'pot'], d: ['pizza', 'tpasta', 'cpasta', 'gratin'] },
    { id: 'korean', n: '한식당', ing: 'relugj', heat: ['pot', 'pot', 'pan'], d: ['bibim', 'vbibim', 'eggrice', 'tteok'] },
    { id: 'brunch', n: '브런치 카페', ing: 'asbec', heat: ['pan', 'pan', 'pan'], d: ['pancake', 'spancake', 'etoast', 'ctoast'] },
    { id: 'chicken', n: '치킨집', d: ['fchicken', 'ychicken', 'tempura', 'chburger'] },
    { id: 'china', n: '중국집', d: ['jjajang', 'jjamppong', 'tangsu', 'kkanshow'] },
    { id: 'street', n: '길거리 음식', d: ['hotdog', 'fries', 'dakkochi', 'sotteok'] },
    { id: 'kaiten', n: '회전 초밥', d: ['nigiri', 'ebi', 'tamago', 'miso'] },
    { id: 'night', n: '야시장', d: ['beefsk', 'squid', 'pinesk', 'bubble'] },
    { id: 'train', n: '기차 도시락', d: ['dosirak', 'kimbap', 'begg', 'udon'] },
    { id: 'camp', n: '캠핑 바비큐', d: ['ssam', 'goguma', 'mallow', 'ramen'] },
    { id: 'space', n: '우주 식당', d: ['curry', 'psoup', 'smoothie', 'shake'] },
    { id: 'dessert', n: '디저트 가게', d: ['scake', 'cookie', 'patbing', 'chocobing'] },
    { id: 'cafe', n: '카페', d: ['americano', 'latte', 'smoothie', 'lemonade'] },
    { id: 'baekban', n: '백반집', d: ['kimchijj', 'bulgogi', 'tteokguk', 'kfried'] },
    { id: 'pocha', n: '분식 포차', d: ['eomuk', 'squidfry', 'rabokki', 'gimmari'] },
    { id: 'world', n: '세계 여행', d: ['taco', 'kebab', 'pho', 'padthai'] },
    { id: 'steak', n: '스테이크 하우스', d: ['steak', 'cpasta2', 'msoup', 'ssalad'] },
    { id: 'dimsum', n: '딤섬 가게', d: ['mandu', 'hagao', 'jjinppang', 'gyeranjjim'] },
    { id: 'mix', n: '섞어 차림', mix: 1, d: [] },
  ];
  const MIX_MI = MENUS.length - 1, MAX_ING = 7;
  function menuInfo(dl) { // what a list of dishes needs
    const need = new Set(), ready = new Set(), raw = [], ckW = {}, wkW = {}, recK = {};
    const add = (c) => {
      if (need.has(c)) return;
      need.add(c);
      const s = SRC[c];
      if (!s) { raw.push(c); return; }
      if (!isWork(s[0]) && !isOne(s[0])) (recK[s[0]] = recK[s[0]] || []).push(s[1]);
      for (const ch of s[1]) add(ch);
    };
    const weigh = (c) => { const s = SRC[c]; if (!s) return; const wk = isWork(s[0]), W = wk ? wkW : ckW; W[s[0]] = (W[s[0]] || 0) + (wk ? WKP[s[0]].t : CKP[s[0]].cook) / 5; for (const ch of s[1]) weigh(ch); };
    dl.forEach((d) => { for (const ch of DISH[d].c) { ready.add(ch); add(ch); weigh(ch); } });
    let clash = false;
    for (const ck in recK) for (const a of recK[ck]) for (const b of recK[ck]) if (a !== b && msub(a, b)) clash = true;
    return { need, ready, raw, ckW, wkW, recK, clash };
  }
  const byWeight = (W) => Object.keys(W).sort((a, b) => W[b] - W[a] || (a < b ? -1 : 1));
  function fillSlots(kinds, n) { const out = kinds.slice(0, n); for (let i = 0; out.length < n; i++) out.push(kinds[i % kinds.length]); return out; }
  function buildMenu(M) {
    const I = menuInfo(M.d);
    M.need = I.need; M.ready = I.ready; M.recK = I.recK; M.clash = I.clash;
    M.res = {}; for (const ck in I.recK) { M.res[ck] = {}; for (const k of I.recK[ck]) M.res[ck][k] = REC[ck][k]; }
    if (!M.ing) M.ing = I.raw.join('');
    M.raw = I.raw;
    const cks = byWeight(I.ckW), wks = byWeight(I.wkW), base = cks.length ? cks : ['pan'];
    M.heat = (M.heat ? M.heat.slice(0, 3) : fillSlots(base, 3)).concat([base[0]]); // 4th slot for kitchens with four cookers
    M.work = fillSlots(wks.length ? wks : ['cut'], 3);
    M.dl = M.d.map((d) => DISH[d].c);
    return M;
  }
  MENUS.forEach((M) => { if (!M.mix) buildMenu(M); });
  /* 섞어 차림: four dishes from all menus, picked from the match seed so every device builds the same menu */
  const MIX_CACHE = new Map();
  function mixMenu(sd) {
    sd = sd >>> 0;
    if (MIX_CACHE.has(sd)) return MIX_CACHE.get(sd);
    const seen = new Set(), pool = [];
    for (const id in DISH) { const c = DISH[id].c; if (!seen.has(c)) { seen.add(c); pool.push(id); } }
    const ord = pool.map((id, i) => [hash32(sd, 4000 + i), id]).sort((a, b) => a[0] - b[0]).map((x) => x[1]);
    let pick = [];
    for (let st = 0; st < ord.length && pick.length < 4; st++) { // greedy from a few starting points until four dishes fit together
      pick = [];
      for (let q = 0; q < ord.length && pick.length < 4; q++) {
        const id = ord[(st + q) % ord.length], I = menuInfo(pick.concat(id));
        if (I.raw.length > MAX_ING || Object.keys(I.ckW).length > 3 || Object.keys(I.wkW).length > 2 || I.clash) continue;
        pick.push(id);
      }
    }
    const M = buildMenu({ id: 'mix', n: '섞어 차림', mix: 1, d: pick });
    if (MIX_CACHE.size > 20) MIX_CACHE.clear();
    MIX_CACHE.set(sd, M);
    return M;
  }
  const menuOf = (mi, sd) => (mi === MIX_MI ? mixMenu(sd) : MENUS[mi] || MENUS[0]);

  /* kitchens 7×9. # wall · . floor · ~ ice · = rail · | door · o mouse hole · * magic portal (pairs)
     C crate · _ counter · B board (kind from the menu) · H cooker (kind from the menu) · S sink · P plates · D dirty plates
     W window · T trash · <>^v belt · L firewood pile. pal = colour theme, menu = the menu that suits it (shown as 추천) */
  const KITCHENS = [
    { id: 'basic', n: '동네 식당', sub: '넓고 반듯한 기본 주방', start: [3, 5], menu: 'burger',
      map: ['#CCCCC#', 'C.....W', 'C....._', 'B.__..H', 'B.....H', '_.....H', '_.....S', 'P.....D', '#__T__#'] },
    { id: 'split', n: '칸막이 주방', sub: '가운데 칸막이. 조리대 위로 넘기거나 아래로 돌아가요', start: [2, 4], lim: 1.15, menu: 'soup',
      map: ['#CC#CC#', 'C.._..C', 'B.._..H', 'B.._..H', '_.._..H', 'P.._..W', 'S.._.._', 'D.....C', '#T__###'] },
    { id: 'belt', n: '컨베이어 주방', sub: '완성 요리는 아래 컨베이어에 올리면 창구로 실려 가요', start: [3, 5], menu: 'sushi',
      map: ['#CCCCC#', 'C.....C', 'B.....H', 'B..__.H', '_.....H', 'T....._', 'P.....S', '_.....D', '>>>>>>W'] },
    { id: 'island', n: '움직이는 조리대', sub: '가운데 레일 위 화구 조리대가 좌우로 오가요', start: [3, 6], menu: 'italy',
      isl: { y: 4, a: 1, b: 4, s: 'H_', p0: 2 }, lim: 1.1,
      map: ['#CCCCC#', 'C.....C', '_.....W', 'T....._', 'H=====H', '_....._', 'B.....S', 'P.....D', '#__B__#'] },
    { id: 'ice', n: '얼음 주방', sub: '파란 얼음 위에서는 멈추지 못하고 쭉 미끄러져요', start: [1, 7], menu: 'brunch',
      map: ['#CCCCC#', 'C.....C', 'B.~~~.H', 'B.~~~.H', 'T.~_~.H', '_.~~~._', 'P.~~~.S', '_.....D', '#__W__#'] },
    { id: 'door', n: '자동문 주방', sub: '두 자동문이 번갈아 열리고 닫혀요', start: [3, 6], lim: 1.1, menu: 'korean',
      map: ['#CCCCC#', 'C.....C', 'B.....T', 'B.._.._', '##|_|##', 'H.....W', 'H....._', 'H.....S', '#P_D__#'] },
    { id: 'mouse', n: '쥐 소동 주방', sub: '쥐가 조리대 위 음식을 훔쳐 가요. 쥐를 톡 눌러 쫓아요', start: [2, 4], mouse: 1, menu: 'snack',
      map: ['#CCCCC#', 'C.....C', '_.._.._', 'B.._..H', 'B.....H', 'o.._..H', 'S.._..o', 'D....._', '#PT_W_#'] },
    { id: 'fire', n: '불꽃 주방', sub: '화력이 세서 빨리 익고 그만큼 빨리 타요', start: [3, 5], heat: 1.5, menu: 'chicken',
      map: ['#CCCCC#', 'C.....C', 'H.....B', 'H.._..B', 'H.._..T', '_....._', 'P.....S', '_.....D', '#__W__#'] },
    { id: 'truck', n: '푸드트럭', sub: '한 사람만 지나가는 좁은 통로가 고리처럼 이어져요', start: [1, 4], pal: 'truck', menu: 'street', lim: 1.1,
      map: ['#CCCCC#', 'C.....C', 'B._#_.H', 'B._#_.H', 'T._#_.H', '_._#_._', 'P._#_.S', '_.....D', '#W__###'] },
    { id: 'kaiten', n: '회전 초밥집', sub: '손님은 가운데! 완성 접시를 회전 레일에 올리면 빙글 돌아 손님에게 가요', start: [3, 6], pal: 'kaiten', loop: 1, menu: 'kaiten',
      map: ['#CCCCC#', 'C.....C', 'B.....H', 'B.>>v.H', '_.^Wv.H', 'T.^<<._', 'P.....S', '_.....D', '#_____#'] },
    { id: 'night', n: '야시장 포장마차', sub: '불 세기가 약·중·강으로 계속 바뀌어요. 강불이면 빨리 익고 빨리 타요', start: [3, 4], pal: 'night', night: 1, menu: 'night',
      map: ['#CCCCC#', 'C.....C', 'H.....B', 'H.._..B', '_.._..T', 'H.._.._', 'H.....S', 'P.....D', '#_W___#'] },
    { id: 'train', n: '기차 식당칸', sub: '덜컹! 기차가 흔들리면 요리사가 잠깐 휘청이며 멈춰요', start: [3, 4], pal: 'train', lurch: 1, menu: 'train',
      map: ['#CCCCC#', 'C.....C', 'B.....H', '_..#..H', 'B.....H', '_..#.._', 'T.....S', 'P.....D', '#__W__#'] },
    { id: 'camp', n: '캠핑장', sub: '모닥불이 점점 꺼져요. 장작 더미에서 장작을 가져와 넣어요', start: [3, 4], pal: 'camp', wood: 1, menu: 'camp',
      map: ['#CCCCC#', 'C.....C', 'B.....L', 'B.H.H._', '_.....T', '_.H.H._', 'P.....S', '_.....D', '#__W__#'] },
    { id: 'space', n: '우주 정거장', sub: '무중력! 조리대에 둔 물건이 가끔 둥실 떠서 다른 조리대로 가요', start: [3, 5], pal: 'space', float: 1, menu: 'space',
      map: ['#CCCCC#', 'C.....C', 'B.._..H', 'B.....H', '_._._.H', 'T....._', 'P.._..S', '_.....D', '#__W__#'] },
    { id: 'magic', n: '마법사 주방', sub: '위아래 방은 마법 문으로만 이어져요. 밟으면 순간이동!', start: [2, 3], pal: 'magic', menu: 'dimsum',
      map: ['#CCCCC#', 'C.....C', 'B..*..H', 'B.....H', '###_###', 'T.....H', 'P..*..S', '_.....D', '#__W__#'] },
    { id: 'garden', n: '텃밭 주방', sub: '재료를 따면 다시 자랄 때까지 잠깐(3.5초) 기다려야 해요', start: [3, 4], pal: 'garden', regrow: 1, menu: 'baekban',
      map: ['#__W__#', 'P.....S', 'B.....D', 'B.C.C.H', '_.....H', 'C.C.C.H', '_.....T', 'C.....C', '#_____#'] },
  ];
  KITCHENS.forEach((KD) => { KD.mi = MENUS.findIndex((M) => M.id === KD.menu); });
  // solo star scaling: how many points the 보통 AI makes here compared with the average (measured, 3-minute games)
  const KIT_F = { basic: 0.94, split: 0.69, belt: 0.99, island: 0.88, ice: 1.12, door: 0.88, mouse: 0.97, fire: 1.09, truck: 1.0, kaiten: 1.06, night: 1.06, train: 0.93, camp: 1.06, space: 1.03, magic: 1.18, garden: 1.13 };
  const MENU_F = { burger: 1.08, soup: 1.04, sushi: 1.02, snack: 1.1, italy: 0.93, korean: 1.02, brunch: 1.12, chicken: 1.08, china: 0.88, street: 0.92, kaiten: 0.97, night: 1.04, train: 0.99, camp: 0.99, space: 0.95, dessert: 1.0, cafe: 1.15, baekban: 0.82, pocha: 0.92, world: 1.09, steak: 0.93, dimsum: 0.98, mix: 0.98 };
  KITCHENS.forEach((KD) => { KD.f = KIT_F[KD.id] || 1; });
  MENUS.forEach((M) => { M.f = MENU_F[M.id] || 1; });
  const PAL = {
    def: { f1: '#e7d8bb', f2: '#efe3c9', w1: '#3b2a3a', w2: '#4a3548', ln: 'rgba(150,120,80,.18)' },
    truck: { f1: '#c9ccd3', f2: '#d6d9df', w1: '#a8402e', w2: '#c8553e', ln: 'rgba(80,90,110,.3)' },
    kaiten: { f1: '#dcc29a', f2: '#e6cea8', w1: '#2c3a4e', w2: '#3c4c64', ln: 'rgba(120,90,50,.22)' },
    night: { f1: '#7a6c86', f2: '#857892', w1: '#1f1828', w2: '#2c2238', ln: 'rgba(30,20,40,.25)' },
    train: { f1: '#c9a26c', f2: '#d4b07c', w1: '#2a4a3a', w2: '#3a6450', ln: 'rgba(110,70,30,.25)' },
    camp: { f1: '#8bb562', f2: '#95bf6b', w1: '#2e4f2a', w2: '#3d6634', ln: 'rgba(40,80,30,.18)' },
    space: { f1: '#9aa4b8', f2: '#a6b0c4', w1: '#151a2c', w2: '#20263c', ln: 'rgba(40,50,80,.35)' },
    magic: { f1: '#a998c8', f2: '#b4a4d2', w1: '#2a1f40', w2: '#3a2c58', ln: 'rgba(60,40,100,.25)' },
    garden: { f1: '#c9b48a', f2: '#d3bf96', w1: '#3e5a2c', w2: '#507238', ln: 'rgba(110,80,40,.22)' },
  };

  /* ======================= helpers ======================= */
  function msub(a, b) { // multiset a ⊆ b
    if (a.length > b.length) return false;
    const c = {}; for (const ch of b) c[ch] = (c[ch] | 0) + 1;
    for (const ch of a) { if (!c[ch]) return false; c[ch]--; }
    return true;
  }
  function mdiff(b, a) { const arr = b.split(''); for (const ch of a) { const k = arr.indexOf(ch); if (k >= 0) arr.splice(k, 1); } return arr.join(''); }
  function hash32(a, b) {
    let h = (Math.imul(a | 0, 0x9E3779B1) ^ Math.imul((b | 0) + 0x632BE5AB, 0x85EBCA77)) >>> 0;
    h ^= h >>> 16; h = Math.imul(h, 0x7feb352d) >>> 0; h ^= h >>> 15; h = Math.imul(h, 0x846ca68b) >>> 0; h ^= h >>> 16;
    return h >>> 0;
  }
  const DIRS = [[0, 1], [-1, 0], [1, 0], [0, -1]]; // down, left, right, up
  const tx = (i) => i % GW, ty = (i) => (i / GW) | 0;
  function nb(i, d) { const x = tx(i) + DIRS[d][0], y = ty(i) + DIRS[d][1]; return x < 0 || y < 0 || x >= GW || y >= GH ? -1 : y * GW + x; }
  const isPlate = (th) => th[0] === '@', isDirty = (th) => th[0] === '%', isItem = (th) => th.length === 1 && th !== '@';
  const dn = (th) => (isDirty(th) ? (parseInt(th.slice(1), 10) || 0) : 0);
  const addP = (pl, x) => '@' + srt(pl.slice(1) + x);
  const nameOf = (c) => (IT[c] ? IT[c][0] : c);

  /* order sequence (same for everyone): easy dishes first, then the whole menu, harder dishes more often later on */
  function genSeq(M, sd) {
    const byPts = M.d.slice().sort((a, b) => DISH[a].pts - DISH[b].pts || (a < b ? -1 : 1)), n = byPts.length, out = [];
    for (let k = 0; k < 90; k++) {
      let r;
      if (k < 2) r = byPts[hash32(sd, k) % 2];
      else if (k < 6) r = byPts[hash32(sd, k + 7) % Math.max(2, n - 1)];
      else if (k >= 10 && hash32(sd, k + 55) % 10 < 3) r = byPts[n - 1 - hash32(sd, k + 77) % 2];
      else r = M.d[hash32(sd, k + 7) % n];
      if (r === out[k - 1] && (r === out[k - 2] || hash32(sd, k + 99) % 3 === 0)) r = M.d[(M.d.indexOf(r) + 1 + hash32(sd, k + 3) % (n - 1)) % n];
      out.push(r);
    }
    return out;
  }
  const gapAt = (t) => Math.max(14, 23 - t / 22);

  /* ======================= kitchen ======================= */
  const newCooker = (S, ck, KD) => Object.assign(S, { ck, cc: '', cr: '', fire: 0, fx: 0, wn: 0 }, KD.wood && !CKP[ck].nob ? { fu: 1 } : {});
  function newKitchen(ki, mi, sd, T, wash) {
    const KD = KITCHENS[ki] || KITCHENS[0], M = menuOf(mi, sd);
    const K = {
      ki, mi, KD, M, T, wash: !!wash, heat: KD.heat || 1, t: 0, sd: sd >>> 0, g: [], st: [], at: new Int16Array(NT).fill(-1),
      ord: [], seq: genSeq(M, sd), ok: 0, nextT: 1, sc: 0, sv: 0, ex: 0, tips: 0, ret: [], ev: [], heats: [], belts: [], doors: [], holes: [],
      lastBoost: -9, il: null, dr: null, mo: null, moT: 16 + (sd % 6), moN: 0, plates: -1, sink: -1, dirty: -1, win: -1, trash: [], woods: [],
      pt: null, nv: null, lu: null, flt: null,
    };
    let ci = 0, hi = 0, bi = 0;
    const portals = [];
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const c = KD.map[y][x], i = y * GW + x;
      if ('.~=|#o *'.includes(c)) { K.g[i] = c === ' ' ? '#' : c; if (c === '|') K.doors.push(i); if (c === 'o') K.holes.push(i); if (c === '*') portals.push(i); continue; }
      K.g[i] = 'X';
      const S = { ty: c, x, y, th: '', cp: 0 };
      if (c === 'C') { if (ci < M.ing.length) { S.ing = M.ing[ci++]; S.cd = 0; } else S.ty = '_'; }
      if (c === 'B') S.wk = M.work[bi++ % M.work.length];
      if (c === 'H') newCooker(S, M.heat[hi++] || M.heat[0], KD);
      if (c === 'P') S.n = wash ? PLATES : 99;
      if (c === 'S' || c === 'D') S.n = 0;
      if ('<>^v'.includes(c)) { const d = '<>^v'.indexOf(c); S.ty = 'belt'; S.dx = [-1, 1, 0, 0][d]; S.dy = [0, 0, -1, 1][d]; S.off = 0; S.bad = 0; }
      K.st.push(S);
    }
    if (portals.length === 2) K.pt = { [portals[0]]: portals[1], [portals[1]]: portals[0] };
    if (KD.isl) {
      const I = KD.isl;
      K.il = { p: I.p0, q: I.p0, f: 0, w: ISL_DWELL, dir: 1 };
      for (let k = 0; k < I.s.length; k++) {
        const c = I.s[k], S = { ty: c, x: I.p0 + k, y: I.y, th: '', cp: 0, isl: k + 1 };
        if (c === 'H') newCooker(S, M.heat[hi++] || M.heat[0], KD);
        K.st.push(S);
      }
    }
    if (K.doors.length) K.dr = { o: 0, t: 0 };
    if (KD.night) K.nv = { t: 0, i: 0, lv: 1, nx: NIGHT_LV[hash32(sd, 701) % 3], w: 0 };
    if (KD.lurch) K.lu = { t: 9 + hash32(sd, 801) % 4, a: 0, w: 0, d: 1, n: 0 };
    if (KD.float) K.flt = { t: 8 + hash32(sd, 901) % 4, n: 0, an: null };
    K.st.forEach((S, si) => {
      if (S.ty === 'H') K.heats.push(si);
      else if (S.ty === 'P') K.plates = si;
      else if (S.ty === 'S') K.sink = si;
      else if (S.ty === 'D') K.dirty = si;
      else if (S.ty === 'W') K.win = si;
      else if (S.ty === 'T') K.trash.push(si);
      else if (S.ty === 'L') K.woods.push(si);
    });
    // belt order: from the tile next to the window backwards
    const belts = K.st.map((S, si) => (S.ty === 'belt' ? si : -1)).filter((si) => si >= 0);
    K.belts = belts.sort((a, b) => beltRank(K, b) - beltRank(K, a));
    if (KD.loop && K.win >= 0) { const W = K.st[K.win]; K.belts.forEach((si) => { const S = K.st[si]; S.nw = Math.abs(S.x - W.x) + Math.abs(S.y - W.y) === 1 ? 1 : 0; }); }
    rebuildAt(K);
    const s0 = KD.start[1] * GW + KD.start[0];
    K.ch = { ti: s0, ni: -1, u: 0, sl: 0, path: [], q: [], cur: null, h: '', dir: 0, work: null, wait: 0, act: 0, fail: 0, wk: 0 };
    return K;
  }
  function beltRank(K, si) { // distance (in belt steps) from the start of the belt line
    let n = 0, S = K.st[si];
    for (let g = 0; g < 20; g++) {
      const px = S.x - S.dx, py = S.y - S.dy;
      const j = K.st.findIndex((Q) => Q.ty === 'belt' && Q.x === px && Q.y === py);
      if (j < 0) break; n++; S = K.st[j];
    }
    return n;
  }
  function islMoving(K) { return K.il && (K.il.q !== K.il.p); }
  function rebuildAt(K) {
    K.at.fill(-1);
    K.st.forEach((S, si) => {
      if (S.isl) { if (islMoving(K)) return; S.x = K.il.p + S.isl - 1; }
      K.at[S.y * GW + S.x] = si;
    });
  }
  function islCovers(K, i) {
    if (!K.il || ty(i) !== K.KD.isl.y) return false;
    const len = K.KD.isl.s.length, a = Math.min(K.il.p, K.il.q), b = Math.max(K.il.p, K.il.q) + len - 1, x = tx(i);
    return x >= a && x <= b;
  }
  const doorOpen = (K, i) => !!K.dr && K.doors[K.dr.o] === i;
  function walk(K, i) {
    if (i < 0) return false;
    const c = K.g[i];
    if (c === '.' || c === '~' || c === '*') return true;
    if (c === '=') return !islCovers(K, i);
    if (c === '|') return doorOpen(K, i);
    return false;
  }
  const chefOn = (K, i) => K.ch.ti === i || K.ch.ni === i;

  /* ----- path finding (Dijkstra over stoppable tiles; ice slides until blocked) ----- */
  function moveFrom(K, i, d) {
    const n = nb(i, d);
    if (n < 0 || !walk(K, n)) return null;
    if (K.g[n] === '*' && K.pt) return [K.pt[n], 1.4]; // magic portal: step in, come out at the other one
    if (K.g[n] !== '~') return [n, 1];
    let c = n, len = 1;
    while (K.g[c] === '~') { const nx = nb(c, d); if (nx < 0 || !walk(K, nx)) break; c = nx; len++; }
    return [c, len * WALK / SLIDE];
  }
  function dijkstra(K, from, noSlide) {
    const dist = new Float64Array(NT).fill(Infinity), prev = new Int16Array(NT).fill(-1), pd = new Int8Array(NT), done = new Uint8Array(NT);
    dist[from] = 0;
    for (;;) {
      let u = -1, bd = Infinity;
      for (let i = 0; i < NT; i++) if (!done[i] && dist[i] < bd) { bd = dist[i]; u = i; }
      if (u < 0) break;
      done[u] = 1;
      for (let d = 0; d < 4; d++) {
        let m;
        if (noSlide) { const n = nb(u, d); m = n >= 0 && walk(K, n) ? [n, 1] : null; } else m = moveFrom(K, u, d);
        if (!m) continue;
        const nd = bd + m[1];
        if (nd < dist[m[0]] - 1e-9) { dist[m[0]] = nd; prev[m[0]] = u; pd[m[0]] = d; }
      }
    }
    return { dist, prev, pd };
  }
  function pathSteps(K, D, from, goal) { // -> [{i, s}] s=1 while the slide continues past this tile
    const hops = [];
    for (let c = goal, g = 0; c !== from && c >= 0 && g < 80; c = D.prev[c], g++) hops.push([D.prev[c], D.pd[c]]);
    hops.reverse();
    const out = [];
    for (const [a, d] of hops) {
      const n = nb(a, d);
      if (K.g[n] !== '~') { out.push({ i: n, s: 0 }); continue; }
      let c = n; const seq = [n];
      while (K.g[c] === '~') { const nx = nb(c, d); if (nx < 0 || !walk(K, nx)) break; c = nx; seq.push(nx); }
      seq.forEach((i, k) => out.push({ i, s: k < seq.length - 1 ? 1 : 0 }));
    }
    return out;
  }
  function goalTiles(K, tg) {
    if (tg.f != null) return walk(K, tg.f) ? [tg.f] : [];
    const S = K.st[tg.s];
    if (!S) return null;
    if (S.isl && islMoving(K)) return [];
    const i = S.y * GW + S.x, out = [];
    for (let d = 0; d < 4; d++) { const n = nb(i, d); if (n >= 0 && walk(K, n) && K.g[n] !== '*') out.push(n); }
    return out;
  }
  function stDist(K, D, si) {
    const g = goalTiles(K, { s: si });
    let b = Infinity;
    if (g) for (const i of g) if (D.dist[i] < b) b = D.dist[i];
    return b;
  }

  /* ----- rules: what a tap on a station does with what the chef holds ----- */
  function fits(K, c, x) { if (!K.M.ready.has(x)) return false; const s = srt(c + x); return K.M.dl.some((dc) => msub(s, dc)); }
  // can `s` go into a cooker of kind ck (on the way to a recipe of this menu)? needF: only recipes whose result is wanted
  function acceptsCook(K, ck, s, needF) {
    s = srt(s);
    if (isOne(ck)) { const o = s.length === 1 && ONE[s]; return !!o && o[0] === ck && K.M.need.has(o[1]) && (!needF || needF(o[1])); }
    return (K.M.recK[ck] || []).some((k) => msub(s, k) && (!needF || needF(K.M.res[ck][k])));
  }
  function resultOf(K, S) {
    if (!S.cc) return undefined;
    if (isOne(S.ck)) { const o = ONE[S.cc]; return o && o[0] === S.ck && K.M.need.has(o[1]) ? o[1] : undefined; }
    const r = K.M.res[S.ck]; return r ? r[S.cc] : undefined;
  }
  const cooking = (K, S) => S.ty === 'H' && !!S.cc && !S.cr && !!resultOf(K, S);
  const canWork = (S, x) => S.ty === 'B' && !!x && !!WORK[x] && WK[x] === S.wk;
  const lit = (S) => S.fu == null || S.fu > 0;
  function findOrder(K, c) {
    let b = -1, bt = Infinity;
    K.ord.forEach((o, i) => { if (DISH[o.d].c === c) { const rem = o.lim - (K.t - o.t0); if (rem < bt) { bt = rem; b = i; } } });
    return b;
  }
  const chopT = (x) => CHOP_T[x] || (WKP[WK[x]] ? WKP[WK[x]].t : 1.6);
  function interact(K, si, run) {
    const S = K.st[si], C = K.ch, h = C.h;
    if (!S) return { ok: false, why: '' };
    const R = (k, f, w) => { if (run && f) f(); return { ok: true, k, w }; };
    const N = (why) => ({ ok: false, why });
    const item = isItem(h), plate = isPlate(h), dirty = isDirty(h), empty = !h;
    const pl = K.st[K.plates];
    switch (S.ty) {
      case 'C':
        if (S.cd > 0 && (empty || plate)) return N('다시 자라는 중이에요');
        if (empty) return R('pick', () => { C.h = S.ing; if (K.KD.regrow) S.cd = REGROW; });
        if (h === S.ing) return R('put', () => { C.h = ''; S.cd = 0; });
        if (plate && fits(K, h.slice(1), S.ing)) return R('plate', () => { C.h = addP(h, S.ing); if (K.KD.regrow) S.cd = REGROW; });
        return N(plate ? '이 접시엔 안 맞아요' : '손이 꽉 찼어요');
      case 'B':
        if (S.th && canWork(S, S.th)) return R('chop', null, 'chop');
        if (!S.th && (plate || dirty)) return N(WKP[S.wk].n + '엔 재료만 올려요');
        if (!S.th && empty) return N(WKP[S.wk].v + '할 재료를 들고 와요');
        if (!S.th && item) return R('put', () => { S.th = h; C.h = ''; S.cp = 0; }, canWork(S, h) ? 'chop' : null);
      // falls through: a board with a prepared item behaves like a counter
      case '_': case 'belt': {
        const th = S.th;
        if (S.ty === 'belt' && plate && !th && findOrder(K, h.slice(1)) < 0 && run) K.ev.push({ k: 'warn2', s: si });
        if (empty && th) return R('pick', () => { C.h = th; S.th = ''; S.cp = 0; S.bad = 0; });
        if (!empty && !th) return R('put', () => { S.th = h; C.h = ''; S.off = 0; S.bad = 0; });
        if (plate && isItem(th) && fits(K, h.slice(1), th)) return R('plate', () => { C.h = addP(h, th); S.th = ''; });
        if (item && isPlate(th) && fits(K, th.slice(1), h)) return R('plate', () => { S.th = addP(th, h); C.h = ''; });
        if (dirty && isDirty(th)) return R('put', () => { S.th = '%' + (dn(th) + dn(h)); C.h = ''; });
        if (plate && isItem(th) || item && isPlate(th)) return N('이 접시엔 안 맞아요');
        return N('자리가 차 있어요');
      }
      case 'H':
        if (S.fire) return R('ext', null, 'ext');
        if (h === '목') return S.fu != null ? R('fuel', () => { S.fu = 1; C.h = ''; }) : N('장작은 모닥불에 넣어요');
        if (S.cr) {
          if (empty) return R('pick', () => { C.h = S.cr; S.cr = ''; S.cp = 0; S.wn = 0; });
          if (plate && S.cr !== 'x' && fits(K, h.slice(1), S.cr)) return R('plate', () => { C.h = addP(h, S.cr); S.cr = ''; S.cp = 0; S.wn = 0; });
          return N(S.cr === 'x' ? '빈손으로 꺼내서 버려요' : plate ? '이 접시엔 안 맞아요' : '빈손이나 접시로 꺼내요');
        }
        if (cooking(K, S)) return N(CKP[S.ck].nob ? '가는 중이에요' : '익는 중이에요');
        if (item && acceptsCook(K, S.ck, S.cc + h)) return R('cook', () => { S.cc = srt(S.cc + h); S.cp = 0; C.h = ''; });
        if (empty && S.cc) return R('pick', () => { C.h = S.cc[S.cc.length - 1]; S.cc = S.cc.slice(0, -1); S.cp = 0; });
        if (item) return N(CKP[S.ck].n + '에 안 맞는 재료예요');
        return N(empty ? '재료를 들고 와요' : '손에 든 걸 먼저 내려놔요');
      case 'L':
        if (empty) return R('pick', () => { C.h = '목'; });
        if (h === '목') return R('put', () => { C.h = ''; });
        return N('손에 든 걸 먼저 내려놔요');
      case 'T':
        if (item) return R('trash', () => { C.h = ''; });
        if (plate && h.length > 1) return R('trash', () => { C.h = '@'; });
        return N(dirty ? '더러운 접시는 개수대로' : plate ? '빈 접시예요' : '버릴 게 없어요');
      case 'P':
        if (h === '@' && K.wash) return R('put', () => { C.h = ''; S.n++; });
        if (S.n <= 0 && (empty || item)) return N('깨끗한 접시가 없어요. 설거지해요');
        if (empty) return R('pick', () => { C.h = '@'; if (K.wash) S.n--; });
        if (item && fits(K, '', h)) return R('plate', () => { C.h = '@' + h; if (K.wash) S.n--; });
        return N(item ? '접시에 못 담는 재료예요' : '손이 꽉 찼어요');
      case 'D':
        if (empty && S.n > 0) return R('pick', () => { C.h = '%' + S.n; S.n = 0; });
        if (dirty) return R('put', () => { S.n += dn(h); C.h = ''; });
        return N(S.n > 0 ? '손에 든 걸 먼저 내려놔요' : '더러운 접시가 없어요');
      case 'S':
        if (dirty) return R('wash', () => { S.n += dn(h); C.h = ''; }, 'wash');
        if (S.n > 0) return R('wash', null, 'wash');
        return N('씻을 접시가 없어요');
      case 'W': {
        if (!plate) return N(item ? '접시에 담아야 해요' : '완성된 요리를 가져와요');
        if (h.length === 1) return N('빈 접시예요');
        const oi = findOrder(K, h.slice(1));
        if (oi < 0) return N('주문에 없는 요리예요');
        return R('serve', () => { serve(K, oi, si); C.h = ''; });
      }
    }
    return N('');
  }
  function serve(K, oi, si) {
    const o = K.ord[oi], D = DISH[o.d];
    const rem = Math.max(0, o.lim - (K.t - o.t0)), tip = Math.round(D.pts * 0.5 * rem / o.lim);
    K.sc += D.pts + tip; K.sv++; K.tips += tip;
    K.ord.splice(oi, 1);
    if (K.wash) K.ret.push(K.t + RET);
    K.ev.push({ k: 'serve', d: o.d, pts: D.pts, tip, s: si });
  }

  /* ----- chef ----- */
  function tapK(K, tg) {
    const C = K.ch;
    if (K.t >= K.T) return 'end';
    if (C.work) {
      if (tg.s != null && tg.s === C.work.s) { boost(K); return 'boost'; }
      C.work.brk = 1;
    }
    if (tg.f != null) { C.q.length = 0; C.cur = tg; C.wait = 0; return 'go'; }
    if (tg.s === K.win && K.belts.length) { // the window is behind the conveyor: aim for the nearest free belt tile instead
      const D = dijkstra(K, C.ti);
      let b = -1, bd = Infinity;
      for (const si of K.belts) { if (K.st[si].th) continue; const d = stDist(K, D, si); if (d < bd) { bd = d; b = si; } }
      if (b >= 0) tg = { s: b };
    }
    const last = C.q.length ? C.q[C.q.length - 1] : C.cur;
    if (last && last.s === tg.s && !C.work) return 'dup';
    if (C.q.length >= MAXQ) C.q.pop();
    C.q.push(tg);
    return 'q';
  }
  function cancelK(K) { const C = K.ch; C.q.length = 0; C.cur = null; if (C.work) C.work.brk = 1; }
  function boost(K) {
    const w = K.ch.work;
    if (!w || K.t - K.lastBoost < 0.07) return;
    K.lastBoost = K.t;
    const S = K.st[w.s];
    if (w.k === 'ext') S.fx += BOOST; else S.cp += BOOST;
    K.ev.push({ k: 'boost', s: w.s });
  }
  function faceTo(K, si) {
    const S = K.st[si], C = K.ch, dx = S.x - tx(C.ti), dy = S.y - ty(C.ti);
    C.dir = dy > 0 ? 0 : dx < 0 ? 1 : dx > 0 ? 2 : 3;
  }
  function arrive(K) {
    const C = K.ch, tg = C.cur;
    C.cur = null;
    if (tg.f != null) return;
    faceTo(K, tg.s);
    const r = interact(K, tg.s, true);
    C.act = 0.22;
    if (!r.ok) { C.fail = 1; K.ev.push({ k: 'fail', s: tg.s, why: r.why }); return; }
    if (r.k !== 'serve') K.ev.push({ k: r.k, s: tg.s });
    if (r.w) { C.work = { s: tg.s, k: r.w, brk: 0 }; if (r.w === 'ext') K.st[tg.s].fx = 0; }
  }
  function doWork(K, dt) { // true when the chef is free again
    const C = K.ch, w = C.work, S = K.st[w.s];
    if (w.brk || !S) { C.work = null; return true; }
    C.wk += dt;
    if (w.k === 'chop') {
      if (!S.th || !canWork(S, S.th)) { C.work = null; return true; }
      S.cp += dt;
      if (S.cp >= chopT(S.th)) { S.th = WORK[S.th]; S.cp = 0; C.work = null; K.ev.push({ k: 'chopped', s: w.s }); return true; }
    } else if (w.k === 'wash') {
      if (S.n <= 0) { C.work = null; return true; }
      S.cp += dt;
      if (S.cp >= WASH) {
        S.cp = 0; S.n--; K.st[K.plates].n++; K.ev.push({ k: 'washed', s: w.s });
        if (S.n <= 0) { C.work = null; return true; }
      }
    } else if (w.k === 'ext') {
      if (!S.fire) { C.work = null; return true; }
      S.fx += dt;
      if (S.fx >= EXT) { S.fire = 0; S.cc = ''; S.cr = ''; S.cp = 0; S.fx = 0; S.wn = 0; C.work = null; K.ev.push({ k: 'out', s: w.s }); return true; }
    }
    return false;
  }
  function chefStep(K, dt) {
    const C = K.ch;
    if (C.act > 0) C.act -= dt;
    if (C.fail > 0) C.fail -= dt;
    if (C.work && !doWork(K, dt)) return;
    if (K.lu && K.lu.a > 0) return; // the train lurches: hold on for a moment
    let budget = dt;
    for (let guard = 0; guard < 12 && budget > 1e-9; guard++) {
      if (C.ni >= 0) {
        const sp = K.g[C.ni] === '~' || K.g[C.ti] === '~' ? SLIDE : WALK;
        const need = (1 - C.u) / sp;
        if (budget < need) { C.u += budget * sp; C.wk += budget; return; }
        budget -= need; C.wk += need;
        C.ti = C.ni; C.ni = -1; C.u = 0;
        if (K.pt && K.g[C.ti] === '*') { // magic portal
          const from = C.ti; C.ti = K.pt[from]; C.path.length = 0; C.sl = 0;
          K.ev.push({ k: 'tp', a: from, b: C.ti });
          if (C.cur && C.cur.f != null && (C.cur.f === from || C.cur.f === C.ti)) C.cur = null;
        }
        if (K.mo && K.mo.st !== 'flee' && Math.hypot(K.mo.x - tx(C.ti) - 0.5, K.mo.y - ty(C.ti) - 0.5) < 1.1) shoo(K, 1);
      }
      if (C.sl && C.path.length) { const s = C.path.shift(); setNext(K, s); continue; }
      C.sl = 0;
      if (!C.cur && C.q.length) { C.cur = C.q.shift(); C.wait = 0; }
      if (!C.cur) return;
      const goals = goalTiles(K, C.cur);
      if (goals === null) { C.cur = null; continue; }
      if (goals.includes(C.ti)) { C.wait = 0; arrive(K); if (C.work) return; continue; }
      const D = dijkstra(K, C.ti);
      let g = -1, bd = Infinity;
      for (const i of goals) if (D.dist[i] < bd) { bd = D.dist[i]; g = i; }
      if (g < 0) {
        C.wait += budget;
        if (C.wait > 3.5) { C.fail = 1; K.ev.push({ k: 'fail', s: C.cur.s != null ? C.cur.s : -1, why: '갈 수 없어요' }); C.cur = null; C.wait = 0; }
        return;
      }
      C.wait = 0;
      C.path = pathSteps(K, D, C.ti, g);
      if (!C.path.length) { arrive(K); if (C.work) return; continue; }
      setNext(K, C.path.shift());
    }
  }
  function setNext(K, s) {
    const C = K.ch;
    const dx = tx(s.i) - tx(C.ti), dy = ty(s.i) - ty(C.ti);
    C.dir = dy > 0 ? 0 : dx < 0 ? 1 : dx > 0 ? 2 : 3;
    C.ni = s.i; C.u = 0; C.sl = s.s;
  }

  /* ----- world ----- */
  function stepHeat(K, dt) {
    for (const si of K.heats) {
      const S = K.st[si], P = CKP[S.ck], r = P.nob ? 1 : K.heat;
      if (S.fire) { S.ft = (S.ft || 0) + dt; continue; }
      if (S.fu != null) { // campfire: burns down; nothing cooks (or burns) on a dead fire
        if (S.fu <= 0) continue;
        S.fu = Math.max(0, S.fu - dt / FUEL_T);
        if (S.fu <= 0) K.ev.push({ k: 'fireout', s: si });
      }
      if (!S.cr && S.cc) {
        const out = resultOf(K, S);
        if (!out) continue;
        S.cp += dt * r;
        if (S.cp >= P.cook) { S.cr = out; S.cc = ''; S.cp = 0; S.wn = 0; K.ev.push({ k: 'done', s: si }); }
      } else if (S.cr && S.cr !== 'x') {
        if (P.nob) continue;
        S.cp += dt * r;
        if (S.cp >= P.safe + WARN) { S.cr = 'x'; S.cp = 0; S.wn = 0; K.ev.push({ k: 'burn', s: si }); }
        else if (S.cp >= P.safe && !S.wn) { S.wn = 1; K.ev.push({ k: 'warn', s: si }); }
      } else if (S.cr === 'x') {
        S.cp += dt * r;
        if (S.cp >= FIRE_T) { S.fire = 1; S.ft = 0; S.cr = ''; S.cc = ''; S.cp = 0; S.fx = 0; K.ev.push({ k: 'fire', s: si }); }
      }
    }
  }
  function stepNight(K, dt) { // night market: the flame level changes every 12 s (warning 2 s before)
    const N = K.nv;
    N.t += dt;
    if (!N.w && N.t >= NIGHT_P - 2) { N.w = 1; if (N.nx !== N.lv) K.ev.push({ k: 'heatW', lv: N.nx }); }
    if (N.t >= NIGHT_P) {
      N.t = 0; N.i++; N.w = 0;
      const ch = N.nx !== N.lv;
      N.lv = N.nx; N.nx = NIGHT_LV[hash32(K.sd, 702 + N.i) % 3]; K.heat = N.lv;
      if (ch) K.ev.push({ k: 'heat', lv: N.lv });
    }
  }
  function stepLurch(K, dt) { // dining car: every 10–13 s the train lurches (1.3 s warning) and the chef stops for a moment
    const U = K.lu;
    if (U.a > 0) U.a = Math.max(0, U.a - dt);
    if (!U.w && K.t >= U.t - 1.3) { U.w = 1; K.ev.push({ k: 'lurchW' }); }
    if (K.t >= U.t) {
      U.a = LURCH_A; U.w = 0; U.n++; U.d = hash32(K.sd, 810 + U.n) % 2 ? 1 : -1;
      U.t = K.t + 10 + hash32(K.sd, 820 + U.n) % 4;
      K.ev.push({ k: 'lurch' });
    }
  }
  function stepFloat(K, dt) { // space station: now and then something on a counter floats over to another counter
    const F = K.flt;
    if (F.an) { F.an.t -= dt; if (F.an.t <= 0) F.an = null; }
    if (K.t < F.t) return;
    F.n++;
    const h = hash32(K.sd, 950 + F.n);
    F.t = K.t + 9 + h % 4;
    if (K.t > K.T - 3) return;
    const src = [], dst = [];
    K.st.forEach((S, si) => { if (S.ty === '_' && !S.isl) (S.th ? src : dst).push(si); });
    if (!src.length || !dst.length) return;
    const a = src[(h >>> 4) % src.length], b = dst[(h >>> 12) % dst.length], A = K.st[a], B = K.st[b];
    B.th = A.th; A.th = ''; A.cp = 0; B.cp = 0;
    F.an = { a, b, t: 1.1 };
    K.ev.push({ k: 'float', s: b });
  }
  function stepOrders(K) {
    for (let i = K.ord.length - 1; i >= 0; i--) {
      const o = K.ord[i];
      if (K.t - o.t0 >= o.lim) { K.ord.splice(i, 1); K.ex++; K.sc = Math.max(0, K.sc - 10); K.ev.push({ k: 'expire', d: o.d }); }
    }
    if (!K.ord.length && K.nextT > K.t + 2) K.nextT = K.t + 2;
    else if (K.ord.length === 1 && K.nextT > K.t + 6) K.nextT = K.t + 6;
    if (K.t >= K.nextT) {
      if (K.ord.length < MAX_ORD && K.t < K.T - 4) {
        const d = K.seq[K.ok % K.seq.length];
        K.ord.push({ d, t0: K.t, lim: Math.round(DISH[d].lim * (K.KD.lim || 1)), k: K.ok++ });
        K.ev.push({ k: 'order', d });
        K.nextT = K.t + gapAt(K.t);
      } else K.nextT = K.t + 1;
    }
    for (let i = K.ret.length - 1; i >= 0; i--) if (K.t >= K.ret[i]) { K.ret.splice(i, 1); K.st[K.dirty].n++; K.ev.push({ k: 'ret', s: K.dirty }); }
  }
  function stepBelt(K, dt) {
    for (const si of K.belts) {
      const S = K.st[si];
      if (!S.th) continue;
      if (S.off < 1) { S.off = Math.min(1, S.off + dt * BELT_V); continue; }
      if (S.nw && isPlate(S.th) && S.th.length > 1) { // loop rail: the customer in the middle takes a dish they ordered
        const oi = findOrder(K, S.th.slice(1));
        if (oi >= 0) { serve(K, oi, K.win); S.th = ''; S.off = 0; continue; }
      }
      const ni = (S.y + S.dy) * GW + S.x + S.dx;
      const nj = ni >= 0 && ni < NT ? K.at[ni] : -1, N = nj >= 0 ? K.st[nj] : null;
      if (N && N.ty === 'belt') { if (!N.th) { N.th = S.th; N.off = 0; N.bad = 0; S.th = ''; S.off = 0; } }
      else if (N && N.ty === 'W') {
        if (S.bad) continue;
        const oi = isPlate(S.th) && S.th.length > 1 ? findOrder(K, S.th.slice(1)) : -1;
        if (oi >= 0) { serve(K, oi, nj); S.th = ''; S.off = 0; } else { S.bad = 1; K.ev.push({ k: 'fail', s: si, why: '주문에 없는 요리예요' }); }
      }
    }
  }
  function stepDoors(K, dt) {
    const D = K.dr;
    D.t += dt;
    if (D.t >= DOOR_P) {
      const closing = K.doors[D.o];
      if (chefOn(K, closing) || (K.mo && K.mo.ti === closing)) return;
      D.o = 1 - D.o; D.t = 0; K.ev.push({ k: 'door' });
    }
  }
  function stepIsland(K, dt) {
    const I = K.il, cfg = K.KD.isl;
    if (I.q === I.p) {
      I.w -= dt;
      if (I.w > 0) return;
      let q = I.p + I.dir;
      if (q < cfg.a || q > cfg.b) { I.dir = -I.dir; q = I.p + I.dir; }
      const C = K.ch, len = cfg.s.length;
      for (let x = q; x < q + len; x++) {
        const i = cfg.y * GW + x;
        if (chefOn(K, i) || (K.mo && K.mo.ti === i)) { I.w = 0.25; return; }
      }
      if (C.work && K.st[C.work.s].isl) { I.w = 0.25; return; }
      I.q = q; I.f = 0; rebuildAt(K); K.ev.push({ k: 'isl' });
    } else {
      I.f += dt / ISL_MOVE;
      if (I.f >= 1) { I.p = I.q; I.f = 0; I.w = ISL_DWELL; rebuildAt(K); }
    }
  }
  function mousePath(K, from, goals) {
    const D = dijkstra(K, from, true);
    let g = -1, bd = Infinity;
    for (const i of goals) if (D.dist[i] < bd) { bd = D.dist[i]; g = i; }
    if (g < 0) return null;
    const out = [];
    for (let c = g, k = 0; c !== from && k < 80; c = D.prev[c], k++) out.push(c);
    return out.reverse();
  }
  function stepMouse(K, dt) {
    let mo = K.mo;
    if (!mo) {
      if (K.t < K.moT || !K.holes.length || K.t > K.T - 6) return;
      const tg = [];
      K.st.forEach((S, si) => { if ((S.ty === '_' || S.ty === 'B') && isItem(S.th)) tg.push(si); });
      const hk = hash32(K.sd, 500 + K.moN++);
      if (!tg.length) { K.moT = K.t + 4; return; }
      const hole = K.holes[hk % K.holes.length];
      let home = -1;
      for (let d = 0; d < 4; d++) { const n = nb(hole, d); if (n >= 0 && walk(K, n)) home = n; }
      const si = tg[(hk >>> 8) % tg.length];
      const path = home >= 0 ? mousePath(K, home, goalTiles(K, { s: si }) || []) : null;
      if (!path) { K.moT = K.t + 4; return; }
      K.mo = mo = { ti: home, x: tx(home) + 0.5, y: ty(home) + 0.5, hole, home, path, tgt: si, st: 'go', item: '', t: 0, dir: 0 };
      K.ev.push({ k: 'mouse' });
      return;
    }
    if (mo.st === 'nib') {
      mo.t -= dt;
      if (mo.t > 0) return;
      const S = K.st[mo.tgt];
      if (S && isItem(S.th)) { mo.item = S.th; S.th = ''; S.cp = 0; K.ev.push({ k: 'steal', s: mo.tgt, it: mo.item }); }
      mo.st = 'back'; mo.path = mousePath(K, mo.ti, [mo.home]) || [];
      return;
    }
    const sp = mo.st === 'flee' ? MOUSE_V * 2 : MOUSE_V;
    let b = dt * sp;
    while (b > 0) {
      if (!mo.path.length) {
        if (mo.st === 'go') { mo.st = 'nib'; mo.t = 0.7; return; }
        if (mo.st === 'back' && mo.item) K.ev.push({ k: 'lost', it: mo.item });
        K.mo = null; K.moT = K.t + 15 + hash32(K.sd, 900 + K.moN) % 9;
        return;
      }
      const nx = tx(mo.path[0]) + 0.5, ny = ty(mo.path[0]) + 0.5, d = Math.hypot(nx - mo.x, ny - mo.y);
      if (Math.abs(nx - mo.x) > 0.01) mo.dir = nx > mo.x ? 2 : 1; else mo.dir = ny > mo.y ? 0 : 3;
      if (d <= b) { mo.x = nx; mo.y = ny; mo.ti = mo.path.shift(); b -= d; if (mo.st === 'go' && !walk(K, mo.ti)) { mo.path = mousePath(K, mo.ti, [mo.home]) || []; mo.st = 'back'; } }
      else { mo.x += (nx - mo.x) / d * b; mo.y += (ny - mo.y) / d * b; b = 0; }
    }
    const C = K.ch;
    if (mo.st !== 'flee' && Math.hypot(mo.x - tx(C.ti) - 0.5, mo.y - ty(C.ti) - 0.5) < 0.8) shoo(K, 1);
  }
  function shoo(K, byChef) {
    const mo = K.mo;
    if (!mo || mo.st === 'flee') return false;
    if (mo.item) { const S = K.st[mo.tgt]; if (S && !S.th) { S.th = mo.item; S.cp = 0; } mo.item = ''; }
    mo.st = 'flee'; mo.path = mousePath(K, mo.ti, [mo.home]) || [];
    K.ev.push({ k: 'shoo', chef: !!byChef });
    return true;
  }
  function stepK(K, dt) {
    if (K.t >= K.T) return;
    dt = Math.min(dt, K.T - K.t);
    K.t += dt;
    if (K.il) stepIsland(K, dt);
    if (K.dr) stepDoors(K, dt);
    chefStep(K, dt);
    if (K.belts.length) stepBelt(K, dt);
    if (K.holes.length) stepMouse(K, dt);
    if (K.nv) stepNight(K, dt);
    if (K.lu) stepLurch(K, dt);
    if (K.flt) stepFloat(K, dt);
    if (K.KD.regrow) for (const S of K.st) if (S.cd > 0) S.cd = Math.max(0, S.cd - dt);
    stepHeat(K, dt);
    stepOrders(K);
    if (K.ev.length > 60) K.ev.splice(0, K.ev.length - 60);
  }

  /* ======================= AI chef ======================= */
  function supplyOf(K) {
    const sup = {}, onPl = {};
    const add = (c, n, pl) => { sup[c] = (sup[c] | 0) + (n || 1); if (pl) onPl[c] = (onPl[c] | 0) + 1; };
    const th = (x) => { if (!x) return; if (isPlate(x)) { for (const ch of x.slice(1)) add(ch, 1, 1); } else if (isItem(x) && x !== 'x' && x !== '목') add(x); };
    th(K.ch.h);
    for (const S of K.st) {
      if (S.ty === 'H') {
        if (S.fire) continue;
        if (S.cr && S.cr !== 'x') add(S.cr);
        else if (cooking(K, S)) add(resultOf(K, S));
        else for (const ch of S.cc) add(ch);
      } else if (S.th) th(S.th);
    }
    if (K.mo && K.mo.item) th(K.mo.item);
    return { sup, onPl };
  }
  function analyse(K, dishes) {
    const { sup, onPl } = supplyOf(K);
    const use = {}, req = {}, fetch = {}, top = {};
    function need(c, n) {
      const have = (sup[c] | 0) - (use[c] | 0), u = Math.min(have, n);
      use[c] = (use[c] | 0) + u;
      const rem = n - u;
      if (rem <= 0) return;
      req[c] = (req[c] | 0) + rem;
      const s = SRC[c];
      if (!s) { fetch[c] = (fetch[c] | 0) + rem; return; }
      for (const ch of s[1]) need(ch, rem);
    }
    for (const d of dishes) for (const ch of DISH[d].c) { top[ch] = (top[ch] | 0) + 1; need(ch, 1); }
    return { sup, onPl, use, req, fetch, top };
  }
  function plateTarget(K, c, ords) {
    let best = null, bm = 99;
    for (const o of ords) { const dc = DISH[o.d].c; if (!msub(c, dc)) continue; const miss = dc.length - c.length; if (miss < bm) { bm = miss; best = o.d; } }
    return best;
  }
  const toBurn = (K, S) => (CKP[S.ck].nob ? 1e9 : (CKP[S.ck].safe + WARN - S.cp) / (K.heat * (S.fu === 0 ? 0.01 : 1)));
  const AI_LV = {
    1: { delay: [0.75, 1.25], boost: 0, cons: 1, rescue: 0, mouse: 3.5, slip: 0.09, wood: 0.1 },
    2: { delay: [0.28, 0.5], boost: 0.33, cons: 2, rescue: 2.2, mouse: 1.6, slip: 0, wood: 0.22 },
    3: { delay: [0.07, 0.16], boost: 0.13, cons: 4, rescue: 4.5, mouse: 0.6, slip: 0, wood: 0.32 },
  };
  function aiThink(K, mem, lv, dt, rnd) {
    const P = AI_LV[lv] || AI_LV[2], C = K.ch;
    rnd = rnd || Math.random;
    if (K.t >= K.T) return;
    if (K.mo && K.mo.st !== 'flee') { mem.mt = mem.mt == null ? P.mouse * (0.7 + rnd() * 0.6) : mem.mt - dt; if (mem.mt <= 0) { shoo(K); mem.mt = null; } }
    else mem.mt = null;
    if (C.work) {
      if (P.boost) { mem.bt = (mem.bt || 0) - dt; if (mem.bt <= 0) { mem.bt = P.boost * (0.8 + rnd() * 0.4); boost(K); } }
      if (lv >= 2 && C.work.k !== 'ext') { // leave the board/sink when something is about to burn or catches fire
        let D = null;
        for (const si of K.heats) {
          const S = K.st[si];
          if (S.fire) { C.work.brk = 1; break; }
          if (!S.cr || S.cr === 'x' || toBurn(K, S) > P.rescue + 3) continue;
          if (!D) D = dijkstra(K, C.ti);
          if (toBurn(K, S) < P.rescue * 0.6 + stDist(K, D, si) / WALK * 1.25 + 0.8) { C.work.brk = 1; mem.cd = 0; break; }
        }
      }
      return;
    }
    if (C.cur || C.q.length) return;
    mem.cd = (mem.cd || 0) - dt;
    if (mem.cd > 0) return;
    if (mem.k == null) mem.k = 0.85 + rnd() * 0.3; // a little personality per chef
    mem.cd = (P.delay[0] + rnd() * (P.delay[1] - P.delay[0])) * mem.k;
    let s = aiDecide(K, mem, lv, P, rnd);
    const sig = s + '|' + C.h;
    mem.same = sig === mem.sig ? (mem.same | 0) + 1 : 0; mem.sig = sig;
    if (mem.same > 6) { // stuck: drop whatever we hold
      mem.same = 0;
      const D = dijkstra(K, C.ti);
      if (C.h && !isDirty(C.h)) { const tr = nearest(K, D, K.trash, (si) => interact(K, si, false).ok); if (tr >= 0) s = tr; }
    }
    if (s == null || s < 0) return;
    tapK(K, { s });
  }
  function nearest(K, D, list, okf) {
    let b = -1, bd = Infinity;
    for (const si of list) { if (okf && !okf(si)) continue; const d = stDist(K, D, si); if (d < bd) { bd = d; b = si; } }
    return b;
  }
  function aiDecide(K, mem, lv, P, rnd) {
    const C = K.ch, h = C.h, M = K.M, ST = K.st;
    const D = dijkstra(K, C.ti);
    const can = (si) => interact(K, si, false).ok;
    const near = (list) => nearest(K, D, list, can);
    const idx = (f) => { const out = []; ST.forEach((S, si) => { if (f(S, si)) out.push(si); }); return out; };
    const crateOk = (si) => !(ST[si].cd > 0) || ST[si].cd < stDist(K, D, si) / WALK + 0.3; // garden: regrown by the time we get there
    // 0. fire!
    let s = near(K.heats.filter((si) => ST[si].fire));
    if (s >= 0) return s;
    const ords = K.ord.slice().sort((a, b) => (a.lim - (K.t - a.t0)) - (b.lim - (K.t - b.t0)));
    const cons = ords.slice(0, P.cons);
    const A = analyse(K, cons.map((o) => o.d)), AA = analyse(K, ords.map((o) => o.d));
    const useful = (c) => (A.use[c] | 0) > 0 || (AA.use[c] | 0) > 0;
    const needs = (code) => (A.req[code] | 0) > 0 || (AA.req[code] | 0) > 0;
    const slots = idx((S) => S.ty === '_' || S.ty === 'B' || S.ty === 'belt');
    const counters = idx((S) => S.ty === '_');
    const freeCounter = () => { const fc = near(counters.filter((si) => !ST[si].th)); return fc >= 0 ? fc : near(idx((S) => S.ty === 'B' && !S.th)); };
    const inTransit = (si) => ST[si].ty === 'belt' && !ST[si].bad;
    const plates = K.st[K.plates];
    const plateFree = plates.n > 0;
    const serveSpot = () => { const w = K.win >= 0 && stDist(K, D, K.win) < Infinity ? K.win : -1; return w >= 0 ? w : near(K.belts.filter((si) => !ST[si].th)); };
    const idle = (S) => !S.cc && !S.cr && !S.fire;
    const freeOne = (x) => K.heats.filter((si) => ST[si].ck === ONE[x][0] && idle(ST[si]));
    const boardFor = (x) => idx((S) => S.ty === 'B' && !S.th && S.wk === WK[x]);
    const multiOk = (S, x) => !isOne(S.ck) && !S.cr && !S.fire && !cooking(K, S) && acceptsCook(K, S.ck, S.cc + x, needs);
    // plates waiting on counters and what they want
    const cPlates = slots.filter((si) => isPlate(ST[si].th) && !inTransit(si)).map((si) => ({ si, c: ST[si].th.slice(1), tgt: plateTarget(K, ST[si].th.slice(1), ords) }));
    const growsTo = (c) => ords.some((o) => msub(c, DISH[o.d].c));
    const plateNeeds = (x) => cPlates.filter((p) => fits(K, p.c, x) && growsTo(srt(p.c + x))).sort((a, b) => b.c.length - a.c.length).map((p) => p.si);
    // what the plates already waiting on counters still miss (and everything that leads to it): finish those first
    const PM = new Set();
    const pmAdd = (c) => { if (PM.has(c)) return; PM.add(c); const q = SRC[c]; if (q) for (const ch of q[1]) pmAdd(ch); };
    for (const p of cPlates) if (p.tgt) for (const ch of mdiff(DISH[p.tgt].c, p.c)) pmAdd(ch);
    const coldFire = (S) => S.fu != null && (S.cc || (S.cr && S.cr !== 'x')) && S.fu < P.wood;

    /* ---- hand: firewood ---- */
    if (h === '목') {
      const busy = (S) => (S.cc || S.cr ? 0 : 1);
      const lows = K.heats.filter((si) => ST[si].fu != null && ST[si].fu < 0.9).sort((a, b) => busy(ST[a]) - busy(ST[b]) || ST[a].fu - ST[b].fu);
      if (lows.length) { s = near([lows[0]]); if (s >= 0) return s; s = near(lows); if (s >= 0) return s; }
      return near(K.woods.concat(K.trash));
    }
    /* ---- hand: dirty plates ---- */
    if (isDirty(h)) return near([K.sink]);
    /* ---- hand: plate ---- */
    if (isPlate(h)) {
      const c = h.slice(1);
      if (c && findOrder(K, c) >= 0) return serveSpot();
      const tg = plateTarget(K, c, ords);
      if (!tg) return c ? near(K.trash) : (K.wash ? near([K.plates]) : freeCounter());
      const miss = mdiff(DISH[tg].c, c);
      const src = [];
      for (const x of new Set(miss)) {
        if (!fits(K, c, x)) continue;
        K.heats.forEach((si) => { if (ST[si].cr === x) src.push(si); });
        slots.forEach((si) => { if (ST[si].th === x && !inTransit(si)) src.push(si); });
        if (!SRC[x] && M.ready.has(x)) idx((S, si) => S.ty === 'C' && S.ing === x && crateOk(si)).forEach((si) => src.push(si));
      }
      const hot = src.filter((si) => ST[si].ty === 'H' && toBurn(K, ST[si]) < Math.max(2, P.rescue) + (P.rescue ? stDist(K, D, si) / WALK : 0));
      s = near(hot.length ? hot : src);
      if (s >= 0) return s;
      return freeCounter();
    }
    /* ---- hand: item ---- */
    if (isItem(h)) {
      const x = h;
      if (x === 'x') return near(K.trash);
      // a cooker already collecting this recipe
      const partial = K.heats.filter((si) => { const S = ST[si]; return S.cc && multiOk(S, x); });
      s = near(partial);
      if (s >= 0 && useful(x)) return s;
      const partialAny = partial.length > 0 && useful(x);
      const direct = (A.top[x] | 0) > (A.onPl[x] | 0) || (AA.top[x] | 0) > (AA.onPl[x] | 0);
      if (M.ready.has(x) && direct) {
        s = near(plateNeeds(x));
        if (s >= 0) return s;
        if (plateFree && useful(x)) return near([K.plates]) >= 0 ? K.plates : freeCounter();
      }
      const dests = [];
      if (WORK[x] && needs(WORK[x])) boardFor(x).forEach((si) => dests.push(si));
      if (ONE[x] && needs(ONE[x][1])) freeOne(x).forEach((si) => dests.push(si));
      if (!partialAny) K.heats.forEach((si) => { const S = ST[si]; if (!S.cc && multiOk(S, x)) dests.push(si); });
      const warm = dests.filter((si) => ST[si].ty !== 'H' || ST[si].fu == null || ST[si].fu > 0.15);
      s = near(warm.length ? warm : dests);
      if (s >= 0 && P.rescue && ST[s].ty === 'B') { // about to chop far away while something is nearly done: put this down and save the food
        const urgent = K.heats.some((si) => { const S = ST[si]; return S.cr && S.cr !== 'x' && toBurn(K, S) < P.rescue + (stDist(K, D, s) + stDist(K, D, si)) / WALK * 1.25 + chopT(x); });
        if (urgent) { const fc = near(counters.filter((si) => !ST[si].th)); if (fc >= 0 && stDist(K, D, fc) < stDist(K, D, s)) return fc; }
      }
      if (s >= 0 && ST[s].ty === 'H' && !isOne(ST[s].ck) && !PM.has(x) && lv >= 2) { // keep the cooker free for what a waiting plate misses
        const S0 = ST[s], better = counters.some((si) => { const y = ST[si].th; return isItem(y) && PM.has(y) && acceptsCook(K, S0.ck, y, needs); });
        if (better) { const fc = near(counters.filter((si) => !ST[si].th)); if (fc >= 0) return fc; }
      }
      if (s >= 0 && useful(x)) return s;
      if (M.ready.has(x) && useful(x)) { s = near(plateNeeds(x)); if (s >= 0) return s; if (plateFree) return K.plates; }
      if (!useful(x) && (lv >= 2 || rnd() < 0.5)) return near(K.trash);
      s = freeCounter();
      return s >= 0 ? s : near(K.trash);
    }
    /* ---- empty hands ---- */
    s = near(K.heats.filter((si) => ST[si].cr === 'x'));
    if (s >= 0) return s;
    s = near(K.belts.filter((si) => ST[si].bad || (ST[si].th && !isPlate(ST[si].th)) || (K.KD.loop && isPlate(ST[si].th) && !plateTarget(K, ST[si].th.slice(1), ords))));
    if (s >= 0) return s;
    s = near(slots.filter((si) => isPlate(ST[si].th) && !inTransit(si) && ST[si].th.length > 1 && findOrder(K, ST[si].th.slice(1)) >= 0));
    if (s >= 0) return s;
    if (P.rescue) {
      s = near(K.heats.filter((si) => { const S = ST[si]; return S.cr && S.cr !== 'x' && toBurn(K, S) < P.rescue + stDist(K, D, si) / WALK * 1.25 + 0.5; }));
      if (s >= 0) return s;
    }
    if (K.woods.length && K.heats.some((si) => coldFire(ST[si]))) { s = near(K.woods); if (s >= 0) return s; }
    const placeFor = (x) => plateNeeds(x).length > 0 || plateFree || !K.M.ready.has(x);
    s = near(K.heats.filter((si) => { const S = ST[si]; return S.cr && S.cr !== 'x' && useful(S.cr) && placeFor(S.cr); }));
    if (s >= 0) return s;
    s = near(idx((S) => S.ty === 'B' && canWork(S, S.th) && useful(S.th)));
    if (s >= 0) return s;
    s = near(idx((S) => S.ty === 'B' && isItem(S.th) && !canWork(S, S.th) && useful(S.th) && placeFor(S.th)));
    if (s >= 0) return s;
    // raw / prepared items lying around that can move on now
    const movable = (x) => {
      if (!useful(x)) return false;
      if (WORK[x] && needs(WORK[x]) && boardFor(x).length) return true;
      if (ONE[x] && needs(ONE[x][1]) && freeOne(x).length) return true;
      if (K.heats.some((si) => multiOk(ST[si], x))) return true;
      return M.ready.has(x) && (plateNeeds(x).length > 0 || plateFree);
    };
    const mv = counters.filter((si) => isItem(ST[si].th) && ST[si].th !== 'x' && ST[si].th !== '목' && movable(ST[si].th));
    s = near(mv.filter((si) => PM.has(ST[si].th)));
    if (s < 0) s = near(mv);
    if (s >= 0) return s;
    // two cookers each holding part of one recipe → move the smaller part over; useless partial contents → take out
    const parts = K.heats.filter((si) => { const S = ST[si]; return !isOne(S.ck) && S.cc && !S.cr && !S.fire && !cooking(K, S); });
    for (const a of parts) for (const b of parts) {
      if (a === b || ST[a].ck !== ST[b].ck || ST[a].cc.length > ST[b].cc.length) continue;
      if ((M.recK[ST[a].ck] || []).some((k) => msub(srt(ST[a].cc + ST[b].cc), k)) && stDist(K, D, a) < Infinity) return a;
    }
    s = near(parts.filter((si) => ![...ST[si].cc].some((ch) => useful(ch))));
    if (s >= 0) return s;
    // clean plates
    if (K.wash && plates.n <= 0) {
      if (ST[K.sink].n > 0) return K.sink;
      if (ST[K.dirty].n > 0) return near([K.dirty]);
    }
    // fetch a raw ingredient (long cooking chains first)
    if (P.slip && rnd() < P.slip) { const cr = idx((S) => S.ty === 'C'); return cr[(rnd() * cr.length) | 0]; }
    const pickFetch = (F) => {
      let best = -1, bs = -1e9;
      for (const x in F) {
        if (F[x] <= 0) continue;
        const crates = idx((S, si) => S.ty === 'C' && S.ing === x && crateOk(si));
        if (!crates.length) continue;
        // where will it go?
        let room = false, pri = 0;
        const w = WORK[x];
        if (w && needs(w)) { room = room || boardFor(x).length > 0; pri = Math.max(pri, 1 + cookOf(w) * 0.1); }
        for (const par of [ONE[x] && ONE[x][1], w && ONE[w] && ONE[w][1]]) if (par && needs(par)) pri = Math.max(pri, 2);
        if (ONE[x] && needs(ONE[x][1])) { room = room || freeOne(x).length > 0; pri = Math.max(pri, 2); }
        if (K.heats.some((si) => multiOk(ST[si], x))) { room = true; pri = Math.max(pri, 3); }
        if (M.ready.has(x) && !SRC[x]) { room = room || plateNeeds(x).length > 0 || plateFree; pri = Math.max(pri, 0.5); }
        if (!room && !counters.some((si) => !ST[si].th)) continue;
        const sc = pri * 10 + (A.fetch[x] ? 5 : 0) + (PM.has(x) ? 12 : 0) - stDist(K, D, crates[0]) * 0.3 + (room ? 4 : 0);
        if (sc > bs) { bs = sc; best = near(crates); }
      }
      return best;
    };
    s = pickFetch(A.fetch);
    if (s < 0) s = pickFetch(AA.fetch);
    if (s >= 0) return s;
    // tidy: plates with no future, wash ahead, keep the campfires going
    s = near(slots.filter((si) => isPlate(ST[si].th) && ST[si].th.length > 1 && !inTransit(si) && !plateTarget(K, ST[si].th.slice(1), ords)));
    if (s >= 0 && ords.length) return s;
    if (K.wash && plates.n < 3) {
      if (ST[K.sink].n > 0) return K.sink;
      if (ST[K.dirty].n > 0) return near([K.dirty]);
    }
    if (K.woods.length && lv >= 2 && K.heats.some((si) => ST[si].fu != null && ST[si].fu < P.wood * 0.8)) return near(K.woods);
    return null;
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    return {
      rid: 1 + U.rand(99999), n: players.length, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      T: [120, 180, 240].includes(o.time) ? o.time : 180, w: o.wash === 0 ? 0 : 1,
      ph: 'pick', pk: -1, pm: -1, km: -1, mn: -1, sd: 1 + U.rand(2147483646), res: null,
    };
  }
  function startMatch(s, rnd) {
    const r = rnd || Math.random;
    const km = s.pk >= 0 ? s.pk : Math.floor(r() * KITCHENS.length), mn = s.pm >= 0 ? s.pm : Math.floor(r() * MENUS.length);
    return Object.assign({}, s, { ph: 'play', km, mn });
  }
  function finish(s, rows) { // rows: [[seat, score, served, expired]]
    const res = rows.slice().sort((a, b) => b[1] - a[1] || b[2] - a[2] || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  // solo stars: points per 3 minutes, scaled by how hard the kitchen / menu is (measured with the AI chefs)
  const STAR = [190, 350, 480];
  function starNeed(s) { const k = ((s.T || 180) / 180) * ((KITCHENS[s.km] || {}).f || 1) * ((MENUS[s.mn] || {}).f || 1); return STAR.map((v) => Math.round(v * k / 10) * 10); }
  function starsOf(s, sc) { return starNeed(s).filter((v) => sc >= v).length; }
  function result(s) {
    const r = result0(s);
    if (r) { // res rows [seat, score, served, missed]
      const by = []; s.res.forEach((x) => { if (Array.isArray(x)) by[x[0]] = x; });
      const col = (fm) => Array.from({ length: s.n }, (_, i) => (by[i] ? fm(by[i]) : '-'));
      r.stats = [{ label: '점수', values: col((x) => (x[1] | 0) + '점') }, { label: '완성한 주문', values: col((x) => (x[2] | 0) + '개') }, { label: '놓친 주문', values: col((x) => (x[3] | 0) + '개') }];
    }
    return r;
  }
  function result0(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const head = (KITCHENS[s.km] ? KITCHENS[s.km].n : '') + ' · ' + (MENUS[s.mn] ? MENUS[s.mn].n : '');
    if (s.n === 1) {
      const r = s.res[0], st = starsOf(s, r[1]);
      return { winners: st > 0 ? [r[0]] : [], title: st ? '별 ' + st + '개!' : '아쉬워요', text: head + '\n' + '★'.repeat(st) + '☆'.repeat(3 - st) + '  ' + r[1] + '점\n요리 ' + r[2] + '개 · 놓친 주문 ' + r[3] + '개' };
    }
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · 요리 ' + r[2] + '개');
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + lines.join('\n') };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const TAU = Math.PI * 2;
  function rrect(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
  function E(g, x, y, rx, ry, col, rot) { g.beginPath(); g.ellipse(x, y, Math.max(0.1, rx), Math.max(0.1, ry), rot || 0, 0, TAU); if (col) { g.fillStyle = col; g.fill(); } }
  function Ci(g, x, y, r, col) { E(g, x, y, r, r, col); }
  function RR(g, x, y, w, h, r, col) { rrect(g, x, y, w, h, r); g.fillStyle = col; g.fill(); }
  function LN(g, pts, col, w) { g.beginPath(); g.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.strokeStyle = col; g.lineWidth = w; g.lineCap = 'round'; g.lineJoin = 'round'; g.stroke(); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return hex;
    const n = parseInt(m[1], 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return hex;
    const n = parseInt(m[1], 16), f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }
  function bowl(g, k, soup, rim) {
    E(g, 0, k * 0.12, k * 0.9, k * 0.62, rim || '#f4ead8');
    E(g, 0, k * 0.02, k * 0.78, k * 0.48, soup);
    E(g, 0, k * 0.5, k * 0.5, k * 0.16, 'rgba(0,0,0,.12)');
  }
  /* ---- art helpers for the added items (all drawn with canvas shapes, centred at 0,0, k = half size) ---- */
  function PG(g, pts, col) { g.beginPath(); g.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i], pts[i + 1]); g.closePath(); g.fillStyle = col; g.fill(); }
  function RT(g, x, y, rot, f) { g.save(); g.translate(x, y); g.rotate(rot); f(); g.restore(); }
  function cupPath(g, k) { g.beginPath(); g.moveTo(-k * 0.5, -k * 0.74); g.lineTo(k * 0.5, -k * 0.74); g.lineTo(k * 0.38, k * 0.82); g.lineTo(-k * 0.38, k * 0.82); g.closePath(); }
  function glass(g, k, layers, o) { // layers: [[top y (×k), colour], ...] from the top down
    o = o || {};
    if (o.straw) LN(g, [k * 0.1, -k * 0.4, k * 0.38, -k * 1.02], o.straw, k * (o.fat ? 0.17 : 0.09));
    cupPath(g, k); g.fillStyle = 'rgba(226,238,246,.92)'; g.fill();
    g.save(); cupPath(g, k); g.clip();
    for (const [y, col] of layers) { g.fillStyle = col; g.fillRect(-k, y * k, k * 2, k * 2); }
    if (o.ice) for (const [x, y] of [[-0.18, -0.38], [0.16, -0.24], [-0.05, -0.08]]) { RR(g, x * k - k * 0.15, y * k - k * 0.15, k * 0.3, k * 0.3, k * 0.07, 'rgba(240,250,255,.55)'); }
    if (o.pearls) for (let i = 0; i < 9; i++) Ci(g, (-0.26 + (i % 5) * 0.13) * k, (0.66 - ((i / 5) | 0) * 0.13 - (i % 2) * 0.04) * k, k * 0.075, '#2a1a1a');
    g.restore();
    LN(g, [-k * 0.5, -k * 0.74, k * 0.5, -k * 0.74], 'rgba(255,255,255,.95)', k * 0.06);
    E(g, -k * 0.27, k * 0.02, k * 0.05, k * 0.42, 'rgba(255,255,255,.4)');
    if (o.top === 'cream') { E(g, 0, -k * 0.74, k * 0.48, k * 0.16, '#fffaf0'); E(g, 0, -k * 0.86, k * 0.32, k * 0.14, '#fffaf0'); Ci(g, 0, -k * 0.98, k * 0.1, '#fffaf0'); }
    if (o.top === 'lemon') { Ci(g, k * 0.42, -k * 0.72, k * 0.2, '#f2d02a'); Ci(g, k * 0.42, -k * 0.72, k * 0.15, '#fbf0a0'); }
    if (o.top === 'berry') { E(g, k * 0.42, -k * 0.74, k * 0.16, k * 0.2, '#e0303f'); LN(g, [k * 0.42, -k * 0.94, k * 0.5, -k * 1.02], '#3f8a2e', k * 0.07); }
  }
  function lump(g, x, y, r, col, dk) { // bumpy fried piece
    g.beginPath();
    for (let i = 0; i <= 14; i++) { const a = i / 14 * TAU, rr = r * (0.84 + 0.16 * Math.sin(i * 2.7 + x * 3)); i ? g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.86) : g.moveTo(x + rr, y); }
    g.fillStyle = dk || shade(col, -0.3); g.fill();
    g.save(); g.translate(-r * 0.06, -r * 0.08); g.beginPath();
    for (let i = 0; i <= 14; i++) { const a = i / 14 * TAU, rr = r * 0.8 * (0.84 + 0.16 * Math.sin(i * 2.7 + x * 3)); i ? g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * 0.86) : g.moveTo(x + rr, y); }
    g.fillStyle = col; g.fill(); g.restore();
    for (let i = 0; i < 4; i++) Ci(g, x + Math.cos(i * 1.9 + x) * r * 0.45, y + Math.sin(i * 1.9 + x) * r * 0.35, r * 0.08, 'rgba(255,240,190,.7)');
  }
  function skewer(g, k, pcs) { // pcs: [colour, 'r'ound | 's'quare]
    LN(g, [-k * 0.95, k * 0.8, k * 0.95, -k * 0.8], '#c8a070', k * 0.08);
    const n = pcs.length;
    pcs.forEach(([col, sh], i) => {
      const f = (i + 0.5) / n, x = -k * 0.62 + f * k * 1.24, y = k * 0.52 - f * k * 1.04;
      if (sh === 's') RT(g, x, y, -0.7, () => { RR(g, -k * 0.2, -k * 0.19, k * 0.4, k * 0.38, k * 0.08, shade(col, -0.25)); RR(g, -k * 0.2, -k * 0.21, k * 0.4, k * 0.34, k * 0.08, col); });
      else { E(g, x, y, k * 0.22, k * 0.19, shade(col, -0.25)); E(g, x - k * 0.02, y - k * 0.02, k * 0.2, k * 0.17, col); }
      LN(g, [x - k * 0.1, y - k * 0.04, x + k * 0.04, y + k * 0.1], 'rgba(40,20,10,.45)', k * 0.04);
    });
  }
  function noodles(g, k, col, n, w, y0, sp) { for (let i = 0; i < n; i++) { const y = y0 + i * sp; LN(g, [-k * 0.55, y, -k * 0.25, y - k * 0.1, k * 0.05, y + k * 0.06, k * 0.32, y - k * 0.08, k * 0.55, y + k * 0.03], i % 2 ? shade(col, -0.12) : col, w); } }
  function bottle(g, k, col, cap) {
    RR(g, -k * 0.4, -k * 0.35, k * 0.8, k * 1.15, k * 0.22, col); RR(g, -k * 0.16, -k * 0.62, k * 0.32, k * 0.3, k * 0.06, col);
    PG(g, [-k * 0.12, -k * 0.62, k * 0.12, -k * 0.62, k * 0.04, -k * 0.95, -k * 0.04, -k * 0.95], cap || '#f2e9d8');
    RR(g, -k * 0.3, -k * 0.05, k * 0.6, k * 0.42, k * 0.08, '#f6ecd8'); Ci(g, 0, k * 0.16, k * 0.12, col);
    E(g, -k * 0.24, -k * 0.15, k * 0.06, k * 0.16, 'rgba(255,255,255,.4)');
  }
  function carton(g, k, band) {
    RR(g, -k * 0.45, -k * 0.35, k * 0.9, k * 1.15, k * 0.06, '#f4f6fa'); PG(g, [-k * 0.45, -k * 0.35, 0, -k * 0.78, k * 0.45, -k * 0.35], '#dde3ec');
    RR(g, -k * 0.08, -k * 0.95, k * 0.16, k * 0.2, k * 0.03, '#dde3ec'); RR(g, -k * 0.45, k * 0.05, k * 0.9, k * 0.34, 0, band);
    Ci(g, 0, k * 0.22, k * 0.1, '#fff');
  }
  function jar(g, k, body, lid) { RR(g, -k * 0.55, -k * 0.45, k * 1.1, k * 1.25, k * 0.25, body); RR(g, -k * 0.6, -k * 0.75, k * 1.2, k * 0.36, k * 0.1, lid); RR(g, -k * 0.38, -k * 0.15, k * 0.76, k * 0.5, k * 0.08, '#f2e9d8'); Ci(g, 0, k * 0.1, k * 0.13, body); }
  function dumpling(g, x, y, r, col, fill) {
    g.beginPath(); g.moveTo(x - r, y + r * 0.35); g.quadraticCurveTo(x, y - r * 1.25, x + r, y + r * 0.35); g.quadraticCurveTo(x, y + r * 0.75, x - r, y + r * 0.35); g.closePath(); g.fillStyle = col; g.fill();
    g.strokeStyle = 'rgba(150,125,95,.75)'; g.lineWidth = Math.max(0.8, r * 0.1); g.stroke();
    if (fill) E(g, x, y + r * 0.05, r * 0.4, r * 0.25, fill);
    for (let i = -1; i <= 1; i++) LN(g, [x + i * r * 0.3, y - r * 0.38, x + i * r * 0.36, y - r * 0.08], 'rgba(150,130,110,.5)', r * 0.08);
  }
  function soupBowl(g, k, soup, rim) { bowl(g, k, soup, rim || '#f4ead8'); }
  function stew(g, k, soup) { E(g, 0, k * 0.15, k * 0.92, k * 0.62, '#2a2226'); E(g, 0, k * 0.05, k * 0.8, k * 0.5, '#3a3036'); E(g, 0, k * 0.02, k * 0.68, k * 0.4, soup); RR(g, -k * 1.0, -k * 0.02, k * 0.2, k * 0.12, k * 0.05, '#2a2226'); RR(g, k * 0.8, -k * 0.02, k * 0.2, k * 0.12, k * 0.05, '#2a2226'); }
  function cubes(g, k, col, pts, sz) { for (const [x, y] of pts) { RR(g, x * k - sz * k, y * k - sz * k, sz * 2 * k, sz * 2 * k, sz * 0.4 * k, shade(col, -0.12)); RR(g, x * k - sz * k, y * k - sz * k * 1.1, sz * 2 * k, sz * 1.8 * k, sz * 0.4 * k, col); } }
  function riceMound(g, x, y, rx, ry, col) { E(g, x, y, rx, ry, col || '#fbf9f2'); for (let i = 0; i < 6; i++) E(g, x + (i - 2.5) * rx * 0.3, y - ry * 0.2 - (i % 3) * ry * 0.2, rx * 0.12, ry * 0.08, 'rgba(220,214,200,.9)', i); }

  const ART = {
    // added raw things
    닭: (g, k) => { LN(g, [k * 0.15, k * 0.15, k * 0.62, k * 0.62], '#efe6d6', k * 0.2); Ci(g, k * 0.72, k * 0.58, k * 0.11, '#efe6d6'); Ci(g, k * 0.58, k * 0.74, k * 0.11, '#efe6d6');
      E(g, -k * 0.14, -k * 0.14, k * 0.6, k * 0.48, '#d98a7c', -0.78); E(g, -k * 0.2, -k * 0.2, k * 0.47, k * 0.35, '#f4b8ab', -0.78); E(g, -k * 0.34, -k * 0.34, k * 0.15, k * 0.08, 'rgba(255,255,255,.45)', -0.78); },
    새: (g, k) => { g.beginPath(); g.arc(0, -k * 0.05, k * 0.5, -Math.PI * 0.95, Math.PI * 0.5); g.lineCap = 'round'; g.strokeStyle = '#8fa2b0'; g.lineWidth = k * 0.4; g.stroke(); g.strokeStyle = '#c3d0d8'; g.lineWidth = k * 0.22; g.stroke();
      for (let i = 0; i < 5; i++) { const a = -Math.PI * 0.8 + i * 0.5; LN(g, [Math.cos(a) * k * 0.32, -k * 0.05 + Math.sin(a) * k * 0.32, Math.cos(a) * k * 0.68, -k * 0.05 + Math.sin(a) * k * 0.68], '#7d909e', k * 0.05); }
      PG(g, [0, k * 0.42, -k * 0.35, k * 0.75, k * 0.2, k * 0.78], '#8fa2b0'); Ci(g, -k * 0.5, -k * 0.12, k * 0.06, '#1d2a33'); LN(g, [-k * 0.55, -k * 0.2, -k * 0.85, -k * 0.65], '#8fa2b0', k * 0.04); },
    우: (g, k) => carton(g, k, '#4a8ad8'),
    크: (g, k) => { carton(g, k, '#e3ae45'); E(g, 0, k * 0.22, k * 0.22, k * 0.08, '#fff'); },
    밀: (g, k) => { g.beginPath(); g.moveTo(-k * 0.5, -k * 0.42); g.quadraticCurveTo(-k * 0.78, k * 0.35, -k * 0.55, k * 0.82); g.lineTo(k * 0.55, k * 0.82); g.quadraticCurveTo(k * 0.78, k * 0.35, k * 0.5, -k * 0.42); g.closePath(); g.fillStyle = '#eee4cf'; g.fill();
      E(g, 0, -k * 0.55, k * 0.36, k * 0.18, '#ddd0b2'); LN(g, [-k * 0.3, -k * 0.42, k * 0.3, -k * 0.42], '#a87a48', k * 0.09);
      LN(g, [0, k * 0.65, 0, -k * 0.05], '#c9a24a', k * 0.06); for (let i = 0; i < 3; i++) { E(g, -k * 0.1, k * (0.05 + i * 0.17), k * 0.08, k * 0.05, '#c9a24a', 0.6); E(g, k * 0.1, k * (0.05 + i * 0.17), k * 0.08, k * 0.05, '#c9a24a', -0.6); } },
    바: (g, k) => { g.beginPath(); g.arc(0, -k * 0.75, k * 1.15, 0.2 * Math.PI, 0.8 * Math.PI); g.arc(0, -k * 1.15, k * 1.2, 0.76 * Math.PI, 0.24 * Math.PI, true); g.closePath(); g.fillStyle = '#f2cc2a'; g.fill();
      g.beginPath(); g.arc(0, -k * 0.75, k * 1.08, 0.25 * Math.PI, 0.75 * Math.PI); g.strokeStyle = 'rgba(255,250,200,.6)'; g.lineWidth = k * 0.06; g.stroke();
      Ci(g, Math.cos(0.2 * Math.PI) * k * 1.12, -k * 0.75 + Math.sin(0.2 * Math.PI) * k * 1.12, k * 0.08, '#5a3a1a'); Ci(g, Math.cos(0.8 * Math.PI) * k * 1.12, -k * 0.75 + Math.sin(0.8 * Math.PI) * k * 1.12, k * 0.07, '#6a5a2a'); },
    춘: (g, k) => jar(g, k, '#2e1c12', '#8a6a3a'),
    된: (g, k) => { E(g, 0, k * 0.15, k * 0.72, k * 0.62, '#6a3c1e'); E(g, 0, -k * 0.38, k * 0.55, k * 0.16, '#4a2a14'); E(g, 0, -k * 0.42, k * 0.46, k * 0.11, '#a8743a'); RR(g, -k * 0.3, k * 0.0, k * 0.6, k * 0.38, k * 0.06, '#f2e9d8'); Ci(g, 0, k * 0.19, k * 0.1, '#8a5a2a'); },
    소: (g, k) => { for (const [x, y] of [[-0.05, -0.22], [0.05, 0.25]]) RT(g, x * k, y * k, -0.35, () => { RR(g, -k * 0.75, -k * 0.2, k * 1.5, k * 0.4, k * 0.2, '#b85a46'); RR(g, -k * 0.72, -k * 0.2, k * 1.44, k * 0.3, k * 0.15, '#e07a62'); E(g, -k * 0.3, -k * 0.1, k * 0.25, k * 0.05, 'rgba(255,220,210,.6)'); }); },
    파: (g, k) => RT(g, 0, 0, -0.7, () => { RR(g, -k * 0.95, -k * 0.13, k * 0.85, k * 0.26, k * 0.12, '#f4f2e4'); RR(g, -k * 0.15, -k * 0.16, k * 1.1, k * 0.14, k * 0.07, '#4f9d3a'); RR(g, -k * 0.15, 0.0, k * 1.05, k * 0.14, k * 0.07, '#6fbf4a'); LN(g, [-k * 0.95, -k * 0.05, -k * 1.05, -k * 0.1], '#e8e0c8', k * 0.05); }),
    두: (g, k) => { PG(g, [-k * 0.65, -k * 0.2, 0, -k * 0.55, k * 0.65, -k * 0.2, 0, k * 0.12], '#fffdf6'); PG(g, [-k * 0.65, -k * 0.2, 0, k * 0.12, 0, k * 0.72, -k * 0.65, k * 0.38], '#ece3cf'); PG(g, [0, k * 0.12, k * 0.65, -k * 0.2, k * 0.65, k * 0.38, 0, k * 0.72], '#dcd0b8'); },
    치: (g, k) => { E(g, 0, k * 0.35, k * 0.85, k * 0.42, '#efe6d6'); for (const [x, y, r] of [[-0.35, 0.05, 0.6], [0.25, 0.0, -0.5], [0, -0.25, 0.2], [0.4, 0.25, 0.9], [-0.3, 0.3, -0.8]]) { E(g, x * k, y * k, k * 0.36, k * 0.18, '#d8432f', r); LN(g, [x * k - k * 0.2 * Math.cos(r), y * k - k * 0.2 * Math.sin(r), x * k + k * 0.2 * Math.cos(r), y * k + k * 0.2 * Math.sin(r)], '#f6d8c0', k * 0.06); } },
    피: (g, k) => { for (const x of [-0.3, 0.3, 0]) E(g, x * k, k * 0.12, k * 0.38, k * 0.6, x ? '#2f8a2e' : '#3fa03a'); E(g, -k * 0.15, -k * 0.1, k * 0.08, k * 0.28, 'rgba(255,255,255,.35)'); RR(g, -k * 0.08, -k * 0.72, k * 0.16, k * 0.25, k * 0.05, '#2a5a1e'); },
    징: (g, k) => { PG(g, [0, -k * 0.95, k * 0.42, -k * 0.2, k * 0.3, k * 0.25, -k * 0.3, k * 0.25, -k * 0.42, -k * 0.2], '#f0cdb8'); PG(g, [0, -k * 0.95, k * 0.5, -k * 0.65, k * 0.25, -k * 0.5], '#e8bca4'); PG(g, [0, -k * 0.95, -k * 0.5, -k * 0.65, -k * 0.25, -k * 0.5], '#e8bca4');
      for (let i = 0; i < 6; i++) { const x = (i - 2.5) * k * 0.12; LN(g, [x, k * 0.25, x + Math.sin(i) * k * 0.15, k * 0.6, x - Math.sin(i) * k * 0.1, k * 0.9], '#e8b8a0', k * 0.08); }
      Ci(g, -k * 0.14, k * 0.1, k * 0.06, '#2a1a1a'); Ci(g, k * 0.14, k * 0.1, k * 0.06, '#2a1a1a'); },
    펄: (g, k) => { E(g, 0, k * 0.2, k * 0.85, k * 0.52, '#e9dcc4'); E(g, 0, k * 0.08, k * 0.72, k * 0.38, '#c9b89a'); for (let i = 0; i < 11; i++) Ci(g, (((i * 37) % 11) / 11 - 0.5) * k * 1.1, k * (-0.08 + ((i * 5) % 4) * 0.08), k * 0.1, '#2a1a1a'); },
    찻: (g, k) => { for (const [x, y, r] of [[-0.25, 0.1, -0.6], [0.25, 0.05, 0.6], [0, -0.3, 0]]) RT(g, x * k, y * k, r, () => { E(g, 0, 0, k * 0.2, k * 0.45, '#4f8a32'); LN(g, [0, -k * 0.38, 0, k * 0.38], '#2f5a1e', k * 0.04); }); },
    인: (g, k) => { for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + (i - 2) * 0.35; PG(g, [Math.cos(a) * k * 0.1, -k * 0.45, Math.cos(a) * k * 0.55, -k * 0.45 + Math.sin(a) * k * 0.55, Math.cos(a) * k * 0.1 + k * 0.08, -k * 0.45], '#3f8a2e'); }
      E(g, 0, k * 0.22, k * 0.52, k * 0.68, '#d99a22'); E(g, 0, k * 0.2, k * 0.46, k * 0.62, '#f2c230');
      for (let i = -2; i <= 2; i++) { LN(g, [i * k * 0.2 - k * 0.3, -k * 0.3, i * k * 0.2 + k * 0.3, k * 0.75], 'rgba(160,100,20,.5)', k * 0.04); LN(g, [i * k * 0.2 + k * 0.3, -k * 0.3, i * k * 0.2 - k * 0.3, k * 0.75], 'rgba(160,100,20,.5)', k * 0.04); } },
    동: (g, k) => { for (let i = 0; i < 5; i++) LN(g, [-k * 0.8, -k * 0.4 + i * k * 0.2, -k * 0.3, -k * 0.48 + i * k * 0.2, k * 0.3, -k * 0.34 + i * k * 0.2, k * 0.8, -k * 0.42 + i * k * 0.2], i % 2 ? '#e6dcc0' : '#f8f2e2', k * 0.17); RR(g, -k * 0.12, -k * 0.6, k * 0.24, k * 1.1, k * 0.05, '#3a6ab0'); },
    삼: (g, k) => { RR(g, -k * 0.85, -k * 0.5, k * 1.7, k * 1.0, k * 0.12, '#e8a098'); for (let i = 0; i < 4; i++) RR(g, -k * 0.85, -k * 0.38 + i * k * 0.24, k * 1.7, k * 0.09, k * 0.04, '#fbf1ec'); RR(g, -k * 0.85, -k * 0.5, k * 1.7, k * 0.14, k * 0.06, '#c97a70'); },
    구: (g, k) => { E(g, 0, 0, k * 0.85, k * 0.42, '#7a3352', -0.4); E(g, -k * 0.05, -k * 0.05, k * 0.75, k * 0.32, '#9a4a6a', -0.4); for (const [x, y] of [[-0.3, 0.05], [0.2, -0.15], [0.4, 0.05]]) Ci(g, x * k, y * k, k * 0.04, '#5a2038'); LN(g, [k * 0.75, -k * 0.38, k * 0.95, -k * 0.5], '#7a3352', k * 0.06); },
    마: (g, k) => { for (const [x, y] of [[-0.4, 0.2], [0.4, 0.2], [0, -0.25]]) { RR(g, x * k - k * 0.3, y * k - k * 0.25, k * 0.6, k * 0.55, k * 0.2, '#f0dde0'); E(g, x * k, y * k - k * 0.22, k * 0.3, k * 0.12, '#fffafa'); } },
    카: (g, k) => { RR(g, -k * 0.7, -k * 0.6, k * 1.4, k * 1.2, k * 0.1, '#e8a020'); RR(g, -k * 0.5, -k * 0.3, k * 1.0, k * 0.7, k * 0.06, '#7a4a18'); for (let i = 1; i < 3; i++) { LN(g, [-k * 0.5 + i * k * 0.33, -k * 0.3, -k * 0.5 + i * k * 0.33, k * 0.4], '#5a3410', k * 0.04); } LN(g, [-k * 0.5, k * 0.05, k * 0.5, k * 0.05], '#5a3410', k * 0.04); RR(g, -k * 0.7, -k * 0.6, k * 1.4, k * 0.2, k * 0.08, '#c8321e'); },
    초: (g, k) => RT(g, 0, 0, -0.25, () => { RR(g, -k * 0.6, -k * 0.8, k * 1.2, k * 1.6, k * 0.08, '#4a2814'); for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) RR(g, -k * 0.5 + j * k * 0.52, -k * 0.7 + i * k * 0.36, k * 0.46, k * 0.3, k * 0.05, '#6a3a20'); RR(g, -k * 0.62, k * 0.25, k * 1.24, k * 0.6, k * 0.06, '#c8321e'); RR(g, -k * 0.62, k * 0.2, k * 1.24, k * 0.1, 0, '#d7dde4'); }),
    얼: (g, k) => { for (const [x, y] of [[-0.35, 0.2], [0.35, 0.25], [0, -0.3]]) { RR(g, x * k - k * 0.3, y * k - k * 0.3, k * 0.6, k * 0.6, k * 0.12, '#a8d4ea'); RR(g, x * k - k * 0.26, y * k - k * 0.3, k * 0.5, k * 0.48, k * 0.1, '#dff2fb'); LN(g, [x * k - k * 0.15, y * k - k * 0.15, x * k, y * k - k * 0.2], '#fff', k * 0.05); } },
    팥: (g, k) => { E(g, 0, k * 0.2, k * 0.85, k * 0.52, '#e9dcc4'); E(g, 0, k * 0.06, k * 0.72, k * 0.38, '#6a1a22'); for (let i = 0; i < 10; i++) E(g, (((i * 37) % 10) / 10 - 0.45) * k * 1.1, k * (-0.1 + ((i * 3) % 4) * 0.07), k * 0.09, k * 0.06, '#9a2a36', i); },
    원: (g, k) => { for (const [x, y, r] of [[-0.35, 0.15, 0.5], [0.35, 0.2, -0.4], [0, -0.3, 0.1]]) RT(g, x * k, y * k, r, () => { E(g, 0, 0, k * 0.3, k * 0.4, '#5a3018'); E(g, -k * 0.02, -k * 0.03, k * 0.26, k * 0.36, '#7a4424'); g.beginPath(); g.moveTo(0, -k * 0.32); g.quadraticCurveTo(k * 0.1, 0, 0, k * 0.32); g.strokeStyle = '#3a1c0c'; g.lineWidth = k * 0.06; g.stroke(); }); },
    레: (g, k) => { E(g, 0, 0, k * 0.72, k * 0.52, '#e8c820', -0.3); E(g, -k * 0.04, -k * 0.04, k * 0.66, k * 0.46, '#f7e04a', -0.3); Ci(g, k * 0.72 * Math.cos(-0.3), k * 0.72 * Math.sin(-0.3), k * 0.1, '#e8c820'); Ci(g, -k * 0.72 * Math.cos(-0.3), -k * 0.72 * Math.sin(-0.3), k * 0.1, '#e8c820'); E(g, -k * 0.25, -k * 0.2, k * 0.2, k * 0.08, 'rgba(255,255,255,.5)', -0.3); },
    양: (g, k) => bottle(g, k, '#c8321e', '#f2e9d8'),
    탕: (g, k) => bottle(g, k, '#f08a3a', '#f2e9d8'),
    또: (g, k) => { E(g, 0, k * 0.15, k * 0.9, k * 0.55, '#d4b070'); E(g, 0, 0, k * 0.9, k * 0.55, '#efd9a0'); for (const [x, y] of [[-0.4, -0.1], [0.2, 0.15], [0.45, -0.15], [-0.1, 0.25], [0.05, -0.3]]) E(g, x * k, y * k, k * 0.1, k * 0.06, '#c89a50'); },
    국: (g, k) => { for (let i = 0; i < 8; i++) LN(g, [-k * 0.8, -k * 0.35 + i * k * 0.1, -k * 0.3, -k * 0.4 + i * k * 0.1, k * 0.3, -k * 0.3 + i * k * 0.1, k * 0.8, -k * 0.36 + i * k * 0.1], i % 2 ? '#e2dccc' : '#fbf8f0', k * 0.07); RR(g, -k * 0.1, -k * 0.55, k * 0.2, k * 1.0, k * 0.04, '#3f9a5a'); },
    버: (g, k) => { RR(g, -k * 0.2, -k * 0.05, k * 0.4, k * 0.75, k * 0.12, '#f2e6d4'); g.beginPath(); g.ellipse(0, -k * 0.05, k * 0.72, k * 0.6, 0, Math.PI, 0); g.closePath(); g.fillStyle = '#b8936e'; g.fill(); E(g, -k * 0.25, -k * 0.35, k * 0.2, k * 0.1, 'rgba(255,255,255,.35)'); },
    어: (g, k) => { RR(g, -k * 0.8, -k * 0.55, k * 1.6, k * 1.1, k * 0.15, '#c8904a'); RR(g, -k * 0.74, -k * 0.5, k * 1.48, k * 0.98, k * 0.12, '#e8b878'); for (let i = 0; i < 3; i++) LN(g, [-k * 0.6, -k * 0.25 + i * k * 0.25, -k * 0.2, -k * 0.32 + i * k * 0.25, k * 0.2, -k * 0.2 + i * k * 0.25, k * 0.6, -k * 0.28 + i * k * 0.25], 'rgba(150,90,40,.45)', k * 0.06); },
    목: (g, k) => { for (const [x, y, r] of [[-0.05, 0.3, -0.15], [0.05, -0.15, 0.2]]) RT(g, x * k, y * k, r, () => { RR(g, -k * 0.85, -k * 0.22, k * 1.6, k * 0.44, k * 0.2, '#7a4a24'); LN(g, [-k * 0.5, -k * 0.08, k * 0.4, -k * 0.1], '#5a3418', k * 0.05); E(g, k * 0.75, 0, k * 0.14, k * 0.22, '#d9b07a'); E(g, k * 0.75, 0, k * 0.07, k * 0.12, '#a87a48'); }); },
    // added prepared things
    육: (g, k) => { for (let i = 0; i < 3; i++) RT(g, (i - 1) * k * 0.4, (i - 1) * k * 0.08, -0.4, () => { RR(g, -k * 0.18, -k * 0.6, k * 0.36, k * 1.2, k * 0.1, '#c95a5a'); LN(g, [-k * 0.1, -k * 0.5, k * 0.05, k * 0.5], '#fbe0e0', k * 0.06); }); },
    쪽: (g, k) => { for (let i = 0; i < 9; i++) { const x = (((i * 37) % 9) / 9 - 0.45) * k * 1.3, y = ((((i * 5) % 7) / 7) - 0.45) * k * 1.1; Ci(g, x, y, k * 0.15); g.strokeStyle = i % 3 ? '#5ea844' : '#e8f0d0'; g.lineWidth = k * 0.08; g.stroke(); } },
    판: (g, k) => cubes(g, k, '#fbf6ea', [[-0.35, 0.25], [0.35, 0.25], [-0.35, -0.3], [0.35, -0.3]], 0.26),
    링: (g, k) => { for (const [x, y] of [[-0.35, 0.15], [0.35, 0.1], [0, -0.32]]) { Ci(g, x * k, y * k, k * 0.32); g.strokeStyle = '#2f8a2e'; g.lineWidth = k * 0.12; g.stroke(); Ci(g, x * k + k * 0.05, y * k, k * 0.05, '#f2f0d0'); } },
    조: (g, k) => { for (const [x, y] of [[-0.32, 0.15], [0.32, -0.15]]) { Ci(g, x * k, y * k, k * 0.48, '#e8c820'); Ci(g, x * k, y * k, k * 0.4, '#fbf0a0'); for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; LN(g, [x * k, y * k, x * k + Math.cos(a) * k * 0.38, y * k + Math.sin(a) * k * 0.38], '#f7e04a', k * 0.05); } } },
    송: (g, k) => { for (const x of [-0.35, 0.35]) { g.beginPath(); g.ellipse(x * k, -k * 0.05, k * 0.36, k * 0.3, 0, Math.PI, 0); g.lineTo(x * k + k * 0.12, -k * 0.05); g.lineTo(x * k + k * 0.12, k * 0.5); g.lineTo(x * k - k * 0.12, k * 0.5); g.lineTo(x * k - k * 0.12, -k * 0.05); g.closePath(); g.fillStyle = '#e8d8c0'; g.fill(); g.strokeStyle = '#a8865e'; g.lineWidth = k * 0.05; g.stroke(); } },
    살: (g, k) => cubes(g, k, '#f2bcae', [[-0.32, 0.22], [0.32, 0.2], [0, -0.3]], 0.28),
    덩: (g, k) => { E(g, 0, k * 0.12, k * 0.8, k * 0.6, '#d9be8a'); E(g, -k * 0.04, 0, k * 0.74, k * 0.55, '#f1dcae'); E(g, -k * 0.25, -k * 0.22, k * 0.25, k * 0.12, 'rgba(255,255,255,.55)'); for (const [x, y] of [[0.3, 0.1], [-0.2, 0.25], [0.1, -0.3]]) Ci(g, x * k, y * k, k * 0.04, '#fffaf0'); },
    가: (g, k) => { E(g, 0, k * 0.3, k * 0.85, k * 0.35, '#3a1c0c'); g.beginPath(); g.moveTo(-k * 0.8, k * 0.32); g.quadraticCurveTo(0, -k * 0.8, k * 0.8, k * 0.32); g.closePath(); g.fillStyle = '#5a3420'; g.fill(); for (let i = 0; i < 8; i++) Ci(g, (((i * 37) % 8) / 8 - 0.45) * k, k * (0.1 - ((i * 3) % 4) * 0.1), k * 0.04, '#7a4a2a'); },
    빙: (g, k) => { E(g, 0, k * 0.45, k * 0.75, k * 0.3, '#a8c8e0'); g.beginPath(); g.moveTo(-k * 0.75, k * 0.45); g.quadraticCurveTo(-k * 0.5, -k * 0.75, 0, -k * 0.75); g.quadraticCurveTo(k * 0.5, -k * 0.75, k * 0.75, k * 0.45); g.closePath(); g.fillStyle = '#f2fafe'; g.fill(); for (let i = 0; i < 6; i++) Ci(g, (((i * 37) % 6) / 6 - 0.4) * k, k * (0.2 - ((i * 3) % 4) * 0.2), k * 0.05, '#cfe8f6'); },
    굽: (g, k) => { for (const [x, y] of [[-0.05, -0.22], [0.05, 0.25]]) RT(g, x * k, y * k, -0.35, () => { RR(g, -k * 0.75, -k * 0.2, k * 1.5, k * 0.4, k * 0.2, '#7a2a1a'); RR(g, -k * 0.72, -k * 0.2, k * 1.44, k * 0.32, k * 0.16, '#a8452e'); for (let i = -2; i <= 2; i++) LN(g, [i * k * 0.25 - k * 0.06, -k * 0.16, i * k * 0.25 + k * 0.06, k * 0.12], '#4a160c', k * 0.06); }); },
    킨: (g, k) => { lump(g, -k * 0.35, k * 0.2, k * 0.42, '#d9902e'); lump(g, k * 0.35, k * 0.22, k * 0.4, '#e09a34'); lump(g, 0, -k * 0.28, k * 0.42, '#d48a2a'); },
    튀: (g, k) => { for (const [y, r] of [[-0.25, -0.3], [0.25, -0.15]]) RT(g, 0, y * k, r, () => { PG(g, [k * 0.55, 0, k * 0.95, -k * 0.25, k * 0.92, k * 0.25], '#e0452e'); lump(g, -k * 0.05, 0, k * 0.32, '#e8a83a'); E(g, -k * 0.05, 0, k * 0.62, k * 0.24, '#e8a83a'); for (let i = 0; i < 4; i++) Ci(g, -k * 0.45 + i * k * 0.28, -k * 0.05, k * 0.05, 'rgba(255,240,190,.8)'); }); },
    까: (g, k) => { lump(g, -k * 0.38, k * 0.25, k * 0.3, '#c98a3a'); lump(g, k * 0.38, k * 0.22, k * 0.3, '#d0923e'); lump(g, -k * 0.2, -k * 0.3, k * 0.3, '#c48434'); lump(g, k * 0.28, -k * 0.28, k * 0.28, '#cc8e3a'); },
    깡: (g, k) => { for (const [x, y] of [[-0.35, 0.2], [0.35, 0.2], [0, -0.28]]) { Ci(g, x * k, y * k, k * 0.32); g.strokeStyle = '#b8782a'; g.lineWidth = k * 0.2; g.stroke(); g.strokeStyle = '#e8b04a'; g.lineWidth = k * 0.13; g.stroke(); } },
    말: (g, k) => { for (const [x, y] of [[-0.35, 0.25], [0.35, 0.25], [0, -0.25]]) RT(g, x * k, y * k, 0.3, () => { RR(g, -k * 0.38, -k * 0.2, k * 0.76, k * 0.4, k * 0.18, '#c9903e'); E(g, k * 0.34, 0, k * 0.08, k * 0.18, '#2f3a2a'); E(g, k * 0.34, 0, k * 0.04, k * 0.1, '#8a6a4a'); }); },
    짜: (g, k) => { soupBowl(g, k, '#2e1c12'); for (const [x, y] of [[-0.3, -0.05], [0.2, 0.05], [0.05, -0.18]]) RR(g, x * k, y * k, k * 0.14, k * 0.1, k * 0.03, '#c99be0'); },
    뽕: (g, k) => { soupBowl(g, k, '#c8321e', '#2e2a30'); E(g, -k * 0.25, -k * 0.05, k * 0.18, k * 0.1, '#2a2a3a'); Ci(g, k * 0.25, 0, k * 0.1, '#f2d6c4'); LN(g, [-k * 0.1, k * 0.1, k * 0.15, k * 0.12], '#7cc35a', k * 0.06); },
    데: (g, k) => { g.beginPath(); g.arc(0, -k * 0.05, k * 0.48, -Math.PI * 0.95, Math.PI * 0.5); g.lineCap = 'round'; g.strokeStyle = '#e06a4a'; g.lineWidth = k * 0.42; g.stroke(); g.strokeStyle = '#f8a888'; g.lineWidth = k * 0.2; g.stroke(); for (let i = 0; i < 5; i++) { const a = -Math.PI * 0.8 + i * 0.5; LN(g, [Math.cos(a) * k * 0.3, -k * 0.05 + Math.sin(a) * k * 0.3, Math.cos(a) * k * 0.66, -k * 0.05 + Math.sin(a) * k * 0.66], '#fff2ea', k * 0.05); } PG(g, [0, k * 0.42, -k * 0.35, k * 0.75, k * 0.2, k * 0.78], '#d8482e'); },
    장: (g, k) => { soupBowl(g, k, '#a8743a', '#3a2a24'); cubes(g, k, '#fbf6ea', [[-0.25, -0.05], [0.2, 0.05]], 0.11); LN(g, [k * 0.05, -k * 0.2, k * 0.3, -k * 0.15], '#5ea844', k * 0.06); },
    란: (g, k) => { E(g, -k * 0.35, 0, k * 0.36, k * 0.48, '#f6efe0'); E(g, -k * 0.42, -k * 0.15, k * 0.08, k * 0.14, 'rgba(255,255,255,.9)'); E(g, k * 0.35, k * 0.1, k * 0.38, k * 0.48, '#fbf8f0'); Ci(g, k * 0.35, k * 0.12, k * 0.22, '#f5b014'); Ci(g, k * 0.33, k * 0.08, k * 0.16, '#ffc928'); },
    드: (g, k) => { soupBowl(g, k, '#e8d8a8', '#3a2a24'); for (let i = 0; i < 3; i++) LN(g, [-k * 0.5, -k * 0.12 + i * k * 0.13, -k * 0.15, -k * 0.2 + i * k * 0.13, k * 0.15, -k * 0.08 + i * k * 0.13, k * 0.5, -k * 0.15 + i * k * 0.13], '#fbf6e8', k * 0.13); Ci(g, k * 0.3, -k * 0.15, k * 0.14, '#fff'); LN(g, [k * 0.22, -k * 0.15, k * 0.38, -k * 0.15], '#f07a8a', k * 0.04); for (const x of [-0.3, -0.15]) Ci(g, x * k, -k * 0.2, k * 0.05, '#5ea844'); },
    커: (g, k) => { soupBowl(g, k, '#d8a02a'); for (const [x, y, c] of [[-0.3, -0.05, '#ecd9a0'], [0.2, 0.05, '#e8803a'], [0.05, -0.2, '#c99be0']]) RR(g, x * k, y * k, k * 0.16, k * 0.13, k * 0.04, c); },
    프: (g, k) => { soupBowl(g, k, '#f2e2b0'); for (const [x, y] of [[-0.2, -0.05], [0.15, 0.02], [0, -0.15]]) Ci(g, x * k, y * k, k * 0.05, '#5ea844'); E(g, k * 0.15, -k * 0.12, k * 0.2, k * 0.08, 'rgba(255,255,255,.6)'); },
    떡: (g, k) => { soupBowl(g, k, '#efe6d2', '#3a2a24'); for (const [x, y, r] of [[-0.3, -0.02, 0.4], [0.15, 0.05, -0.3], [0, -0.15, 0.1], [0.32, -0.1, 0.8]]) E(g, x * k, y * k, k * 0.15, k * 0.09, '#fffdf8', r); LN(g, [-k * 0.2, k * 0.1, k * 0.1, k * 0.12], '#f5c020', k * 0.05); LN(g, [-k * 0.05, -k * 0.22, k * 0.2, -k * 0.2], '#2f4a36', k * 0.05); },
    찌: (g, k) => { stew(g, k, '#c8321e'); cubes(g, k, '#fbf6ea', [[-0.25, -0.02], [0.2, 0.05]], 0.11); E(g, k * 0.05, -k * 0.15, k * 0.18, k * 0.07, '#e86a3a'); },
    묵: (g, k) => { soupBowl(g, k, '#e8c890', '#e9dcc4'); for (const [x, r] of [[-0.25, -0.3], [0.2, 0.25]]) { LN(g, [x * k, k * 0.05, x * k + Math.sin(r) * k * 0.9, -k * 0.85], '#c8a070', k * 0.06); RT(g, x * k + Math.sin(r) * k * 0.45, -k * 0.38, r, () => { RR(g, -k * 0.16, -k * 0.3, k * 0.32, k * 0.55, k * 0.08, '#d09a50'); }); } },
    쌀: (g, k) => { soupBowl(g, k, '#ece0c4', '#f4ead8'); for (let i = 0; i < 4; i++) LN(g, [-k * 0.5, -k * 0.15 + i * k * 0.09, 0, -k * 0.2 + i * k * 0.09, k * 0.5, -k * 0.13 + i * k * 0.09], '#fffdf6', k * 0.05); E(g, k * 0.2, -k * 0.12, k * 0.2, k * 0.1, '#b8604a'); for (const [x, y] of [[-0.3, -0.18], [-0.15, -0.1]]) E(g, x * k, y * k, k * 0.1, k * 0.05, '#3f9a3a', 0.5); },
    림: (g, k) => { E(g, 0, k * 0.15, k * 0.85, k * 0.55, '#4a4652'); E(g, 0, k * 0.05, k * 0.72, k * 0.42, '#f6efe0'); for (const [x, y] of [[-0.25, 0], [0.2, -0.05]]) { E(g, x * k, y * k, k * 0.14, k * 0.09, '#c8a888'); } LN(g, [k * 0.7, k * 0.1, k * 1.0, k * 0.2], '#2a2730', k * 0.12); },
    스: (g, k) => { soupBowl(g, k, '#e0d0b0'); g.beginPath(); g.ellipse(0, -k * 0.05, k * 0.18, k * 0.13, 0, Math.PI, 0); g.closePath(); g.fillStyle = '#a8865e'; g.fill(); Ci(g, -k * 0.25, k * 0.02, k * 0.04, '#5ea844'); },
    시: (g, k) => { RR(g, -k * 0.8, -k * 0.2, k * 1.6, k * 0.75, k * 0.12, '#d9a040'); E(g, 0, k * 0.55, k * 0.8, k * 0.2, '#c08a30'); E(g, 0, -k * 0.2, k * 0.8, k * 0.28, '#f0c870'); E(g, -k * 0.25, -k * 0.25, k * 0.25, k * 0.07, 'rgba(255,255,255,.4)'); },
    쿠: (g, k) => { for (const [x, y] of [[-0.38, 0.22], [0.38, 0.22], [0, -0.28]]) { Ci(g, x * k, y * k, k * 0.38, '#9a6430'); Ci(g, x * k - k * 0.02, y * k - k * 0.02, k * 0.33, '#c08a48'); for (let i = 0; i < 3; i++) Ci(g, x * k + Math.cos(i * 2.1 + x) * k * 0.17, y * k + Math.sin(i * 2.1 + x) * k * 0.15, k * 0.06, '#4a2814'); } },
    만: (g, k) => { dumpling(g, -k * 0.38, k * 0.2, k * 0.4, '#f6f0e4'); dumpling(g, k * 0.38, k * 0.2, k * 0.4, '#f2ece0'); dumpling(g, 0, -k * 0.25, k * 0.4, '#faf6ee'); },
    하: (g, k) => { dumpling(g, -k * 0.38, k * 0.2, k * 0.4, 'rgba(244,236,226,.95)', '#f08a6a'); dumpling(g, k * 0.38, k * 0.2, k * 0.4, 'rgba(244,236,226,.95)', '#f08a6a'); dumpling(g, 0, -k * 0.25, k * 0.4, 'rgba(248,242,234,.95)', '#f08a6a'); },
    찐: (g, k) => { for (const [x, y] of [[-0.38, 0.15], [0.38, 0.15]]) { E(g, x * k, y * k + k * 0.15, k * 0.42, k * 0.18, '#c8b89c'); g.beginPath(); g.ellipse(x * k, y * k + k * 0.15, k * 0.42, k * 0.5, 0, Math.PI, 0); g.fillStyle = '#fbf8f2'; g.fill(); g.strokeStyle = 'rgba(150,125,95,.75)'; g.lineWidth = k * 0.06; g.stroke(); E(g, x * k - k * 0.12, y * k - k * 0.15, k * 0.1, k * 0.06, 'rgba(255,255,255,.9)'); } Ci(g, 0, -k * 0.45, k * 0.06, '#8a2a32'); },
    찜: (g, k) => { E(g, 0, k * 0.2, k * 0.85, k * 0.55, '#2a2226'); E(g, 0, k * 0.08, k * 0.72, k * 0.4, '#3a3036'); g.beginPath(); g.ellipse(0, k * 0.08, k * 0.66, k * 0.62, 0, Math.PI, 0); g.fillStyle = '#ffd84a'; g.fill(); E(g, 0, k * 0.08, k * 0.66, k * 0.18, '#f5c020'); for (const [x, y] of [[-0.2, -0.2], [0.15, -0.3], [0.3, -0.05]]) Ci(g, x * k, y * k, k * 0.05, '#5ea844'); },
    꼬: (g, k) => skewer(g, k, [['#b0602a', 's'], ['#6fbf4a', 'r'], ['#b0602a', 's'], ['#6fbf4a', 'r'], ['#b0602a', 's']]),
    꽂: (g, k) => skewer(g, k, [['#c8402a', 'r'], ['#fbf3e6', 's'], ['#c8402a', 'r'], ['#fbf3e6', 's'], ['#c8402a', 'r']]),
    꿰: (g, k) => skewer(g, k, [['#7a3a1e', 's'], ['#3f9a3a', 'r'], ['#7a3a1e', 's'], ['#3f9a3a', 'r'], ['#7a3a1e', 's']]),
    불: (g, k) => { for (let i = 0; i < 6; i++) RT(g, (((i * 37) % 6) / 6 - 0.42) * k * 1.2, (((i * 5) % 4) / 4 - 0.4) * k, i * 0.9, () => { RR(g, -k * 0.32, -k * 0.1, k * 0.64, k * 0.2, k * 0.08, i % 3 ? '#6a2e18' : '#8a4424'); }); for (const [x, y] of [[-0.3, 0.1], [0.3, -0.1]]) LN(g, [x * k - k * 0.12, y * k, x * k + k * 0.12, y * k + k * 0.05], '#c99be0', k * 0.08); for (let i = 0; i < 5; i++) E(g, (i - 2) * k * 0.2, (i % 2) * k * 0.2 - k * 0.1, k * 0.03, k * 0.018, '#fff6d8'); },
    오: (g, k) => { PG(g, [0, -k * 0.95, k * 0.45, -k * 0.2, k * 0.3, k * 0.3, -k * 0.3, k * 0.3, -k * 0.45, -k * 0.2], '#c8702a'); for (let i = 0; i < 3; i++) { LN(g, [-k * 0.3, -k * 0.5 + i * k * 0.25, k * 0.3, -k * 0.3 + i * k * 0.25], '#8a4418', k * 0.05); LN(g, [k * 0.3, -k * 0.5 + i * k * 0.25, -k * 0.3, -k * 0.3 + i * k * 0.25], '#8a4418', k * 0.05); } for (let i = 0; i < 5; i++) { const x = (i - 2) * k * 0.14; LN(g, [x, k * 0.3, x + Math.sin(i) * k * 0.15, k * 0.65, x, k * 0.9], '#b0602a', k * 0.09); } },
    애: (g, k) => skewer(g, k, [['#f2c230', 's'], ['#f2b030', 's'], ['#f2c230', 's'], ['#e8a828', 's']]),
    겹: (g, k) => { for (let i = 0; i < 3; i++) RT(g, (i - 1) * k * 0.38, (i - 1) * k * 0.1, -0.3, () => { RR(g, -k * 0.2, -k * 0.62, k * 0.4, k * 1.24, k * 0.08, '#a85a38'); for (let j = 0; j < 3; j++) RR(g, -k * 0.2, -k * 0.45 + j * k * 0.35, k * 0.4, k * 0.08, k * 0.03, '#f2d6b8'); LN(g, [-k * 0.18, -k * 0.2, k * 0.18, -k * 0.05], '#4a1e0c', k * 0.05); }); },
    군: (g, k) => { E(g, 0, 0, k * 0.85, k * 0.45, '#3a1424', -0.4); E(g, -k * 0.02, -k * 0.03, k * 0.75, k * 0.36, '#5a2034', -0.4); E(g, k * 0.05, -k * 0.08, k * 0.5, k * 0.18, '#f2b030', -0.4); E(g, k * 0.05, -k * 0.1, k * 0.36, k * 0.1, '#ffd060', -0.4); },
    멜: (g, k) => { LN(g, [-k * 0.9, k * 0.85, k * 0.5, -k * 0.55], '#c8a070', k * 0.07); for (const f of [0.35, 0.65]) { const x = -k * 0.9 + f * k * 1.4, y = k * 0.85 - f * k * 1.4; RT(g, x, y, -0.78, () => { RR(g, -k * 0.24, -k * 0.2, k * 0.48, k * 0.4, k * 0.16, '#c87a3a'); RR(g, -k * 0.22, -k * 0.2, k * 0.44, k * 0.28, k * 0.14, '#f0c890'); }); } },
    테: (g, k) => { E(g, 0, k * 0.1, k * 0.85, k * 0.6, '#3e1a0e'); E(g, -k * 0.03, 0, k * 0.8, k * 0.56, '#6a2e1a'); for (let i = -1; i <= 2; i++) LN(g, [i * k * 0.3 - k * 0.35, -k * 0.35, i * k * 0.3 - k * 0.05, k * 0.35], '#2a0e06', k * 0.07); E(g, k * 0.45, -k * 0.1, k * 0.15, k * 0.25, '#f2d6b8'); },
    숯: (g, k) => { LN(g, [k * 0.15, k * 0.15, k * 0.62, k * 0.62], '#efe6d6', k * 0.2); Ci(g, k * 0.72, k * 0.58, k * 0.11, '#efe6d6'); Ci(g, k * 0.58, k * 0.74, k * 0.11, '#efe6d6'); E(g, -k * 0.14, -k * 0.14, k * 0.6, k * 0.48, '#8a4a1a', -0.78); E(g, -k * 0.2, -k * 0.2, k * 0.47, k * 0.35, '#c8782a', -0.78); for (let i = -1; i <= 1; i++) LN(g, [-k * 0.45 + i * k * 0.2, -k * 0.05 + i * k * 0.2, -k * 0.05 + i * k * 0.2, -k * 0.45 + i * k * 0.2], '#5a2a0c', k * 0.05); },
    케: (g, k) => { for (let i = 0; i < 5; i++) RT(g, (((i * 3) % 5) / 5 - 0.4) * k * 1.1, (((i * 2) % 5) / 5 - 0.4) * k, i * 1.1, () => { RR(g, -k * 0.35, -k * 0.12, k * 0.7, k * 0.24, k * 0.1, i % 2 ? '#8a4a1e' : '#a8642a'); LN(g, [-k * 0.3, 0, k * 0.3, -k * 0.02], 'rgba(255,220,180,.4)', k * 0.04); }); },
    팟: (g, k) => { E(g, 0, k * 0.1, k * 0.85, k * 0.55, '#d8902e'); noodles(g, k, '#f0b860', 5, k * 0.1, -k * 0.25, k * 0.13); g.beginPath(); g.arc(-k * 0.2, -k * 0.15, k * 0.18, -2.8, 1.4); g.strokeStyle = '#f08a6a'; g.lineWidth = k * 0.12; g.stroke(); PG(g, [k * 0.35, -k * 0.3, k * 0.75, -k * 0.1, k * 0.4, k * 0.05], '#7cc35a'); for (let i = 0; i < 4; i++) Ci(g, (i - 1.5) * k * 0.25, k * 0.3, k * 0.05, '#c87a3a'); },
    티: (g, k) => glass(g, k, [[-0.5, '#c8a07a']], { straw: '#2a1a1a', fat: 1, pearls: 1 }),
    무: (g, k) => glass(g, k, [[-0.55, '#f07a8a']], { straw: '#f2e9d8', top: 'berry' }),
    셰: (g, k) => glass(g, k, [[-0.55, '#f6e08a']], { straw: '#4a8ad8', top: 'cream' }),
    휘: (g, k) => { E(g, 0, k * 0.45, k * 0.75, k * 0.3, '#e8e0d0'); E(g, 0, k * 0.3, k * 0.7, k * 0.3, '#fffaf0'); E(g, 0, 0, k * 0.52, k * 0.26, '#fffcf6'); E(g, 0, -k * 0.28, k * 0.34, k * 0.22, '#fffaf0'); Ci(g, k * 0.05, -k * 0.55, k * 0.14, '#fffcf6'); E(g, -k * 0.2, -k * 0.05, k * 0.15, k * 0.06, 'rgba(230,220,210,.8)'); },
    아: (g, k) => glass(g, k, [[-0.5, '#4a2a1a']], { straw: '#f2e9d8', ice: 1 }),
  };
  /* whole plated dishes that look better than a cluster of parts (key = sorted contents) */
  const DART = {};
  [
    ['아우', (g, k) => glass(g, k * 0.95, [[-0.5, '#6a3a1e'], [0.05, '#f2ebe0']], { straw: '#2a1a1a', ice: 1 })],
    ['티펄', (g, k) => glass(g, k * 0.95, [[-0.5, '#c8a07a']], { straw: '#2a1a1a', fat: 1, pearls: 1 })],
    ['조얼', (g, k) => glass(g, k * 0.95, [[-0.5, '#f8ec9a']], { straw: '#e5483b', ice: 1, top: 'lemon' })],
    ['빙팥', (g, k) => { ART['빙'](g, k); E(g, 0, -k * 0.55, k * 0.4, k * 0.2, '#7a1a26'); for (let i = 0; i < 5; i++) Ci(g, (i - 2) * k * 0.13, -k * 0.6 + (i % 2) * k * 0.06, k * 0.06, '#9a2a36'); RR(g, -k * 0.5, k * 0.0, k * 0.22, k * 0.14, k * 0.05, '#fbf3e6'); }],
    ['빙초휘', (g, k) => { ART['빙'](g, k); for (let i = 0; i < 3; i++) LN(g, [-k * 0.45, -k * 0.35 + i * k * 0.25, -k * 0.1, -k * 0.2 + i * k * 0.25, k * 0.2, -k * 0.38 + i * k * 0.25, k * 0.45, -k * 0.25 + i * k * 0.25], '#4a2814', k * 0.08); E(g, 0, -k * 0.72, k * 0.28, k * 0.16, '#fffaf0'); Ci(g, 0, -k * 0.85, k * 0.1, '#fffaf0'); }],
    ['s시휘', (g, k) => { RR(g, -k * 0.75, -k * 0.25, k * 1.5, k * 0.8, k * 0.12, '#f6efe0'); RR(g, -k * 0.75, k * 0.05, k * 1.5, k * 0.18, 0, '#f0c870'); RR(g, -k * 0.75, k * 0.32, k * 1.5, k * 0.14, 0, '#f0c870'); E(g, 0, -k * 0.25, k * 0.75, k * 0.25, '#fffaf0'); for (const x of [-0.45, 0, 0.45]) { E(g, x * k, -k * 0.38, k * 0.14, k * 0.17, '#e0303f'); LN(g, [x * k, -k * 0.55, x * k + k * 0.06, -k * 0.6], '#3f8a2e', k * 0.05); } }],
    ['P짜', (g, k) => { soupBowl(g, k, '#f0d78a', '#f4ead8'); noodles(g, k * 0.9, '#f6e094', 3, k * 0.1, -k * 0.2, k * 0.12); E(g, 0, -k * 0.08, k * 0.45, k * 0.25, '#2e1c12'); for (const [x, y] of [[-0.15, -0.12], [0.12, -0.05]]) RR(g, x * k, y * k, k * 0.1, k * 0.07, k * 0.02, '#c99be0'); LN(g, [k * 0.05, -k * 0.3, k * 0.35, -k * 0.25], '#5bab4f', k * 0.06); }],
    ['P뽕', (g, k) => { soupBowl(g, k, '#c8321e', '#2e2a30'); noodles(g, k * 0.85, '#f6e094', 2, k * 0.09, -k * 0.08, k * 0.12); E(g, -k * 0.28, -k * 0.12, k * 0.17, k * 0.09, '#2a2a3a'); Ci(g, k * 0.28, -k * 0.1, k * 0.09, '#f2d6c4'); LN(g, [-k * 0.05, -k * 0.2, k * 0.15, -k * 0.18], '#7cc35a', k * 0.06); }],
    ['까탕', (g, k) => { ART['까'](g, k); for (let i = 0; i < 3; i++) LN(g, [-k * 0.5, -k * 0.2 + i * k * 0.2, -k * 0.1, -k * 0.05 + i * k * 0.2, k * 0.3, -k * 0.25 + i * k * 0.2, k * 0.55, -k * 0.1 + i * k * 0.2], 'rgba(240,120,40,.85)', k * 0.1); }],
    ['탕튀', (g, k) => { ART['튀'](g, k); for (let i = 0; i < 2; i++) LN(g, [-k * 0.5, -k * 0.15 + i * k * 0.4, 0, -k * 0.3 + i * k * 0.4, k * 0.45, -k * 0.1 + i * k * 0.4], 'rgba(230,80,40,.85)', k * 0.12); }],
    ['양킨', (g, k) => { lump(g, -k * 0.35, k * 0.2, k * 0.42, '#c8321e', '#8a1a10'); lump(g, k * 0.35, k * 0.22, k * 0.4, '#d03a22', '#8a1a10'); lump(g, 0, -k * 0.28, k * 0.42, '#c02e1a', '#8a1a10'); for (let i = 0; i < 6; i++) E(g, (i - 2.5) * k * 0.2, (i % 2) * k * 0.3 - k * 0.1, k * 0.04, k * 0.022, '#fff6d8', i); }],
    ['b굽', (g, k) => RT(g, 0, 0, -0.25, () => { RR(g, -k * 0.8, -k * 0.15, k * 1.6, k * 0.5, k * 0.25, '#c98a3e'); RR(g, -k * 0.85, -k * 0.3, k * 1.7, k * 0.34, k * 0.17, '#a8452e'); LN(g, [-k * 0.6, -k * 0.16, -k * 0.4, -k * 0.24, -k * 0.2, -k * 0.12, 0, -k * 0.24, k * 0.2, -k * 0.12, k * 0.4, -k * 0.24, k * 0.6, -k * 0.14], '#f2c94c', k * 0.07); RR(g, -k * 0.8, -k * 0.05, k * 1.6, k * 0.4, k * 0.2, '#e3a75c'); })],
    ['R커', (g, k) => { riceMound(g, -k * 0.32, 0, k * 0.45, k * 0.38); E(g, k * 0.3, k * 0.05, k * 0.5, k * 0.38, '#d8a02a'); for (const [x, y, c] of [[0.2, 0, '#ecd9a0'], [0.45, 0.12, '#e8803a'], [0.35, -0.12, '#c99be0']]) RR(g, x * k, y * k, k * 0.13, k * 0.1, k * 0.03, c); }],
    ['P림', (g, k) => { E(g, 0, k * 0.05, k * 0.75, k * 0.48, '#f6efe0'); noodles(g, k * 0.9, '#f0d78a', 4, k * 0.1, -k * 0.2, k * 0.12); for (const [x, y] of [[-0.25, -0.05], [0.25, 0.08]]) E(g, x * k, y * k, k * 0.13, k * 0.08, '#c8a888'); E(g, 0, -k * 0.05, k * 0.35, k * 0.12, 'rgba(255,252,240,.7)'); }],
    ['GP', (g, k) => { drawItem(g, 'G', k * 2); noodles(g, k * 0.8, '#f6e094', 2, k * 0.09, -k * 0.05, k * 0.14); }],
    ['T또숯', (g, k) => { g.beginPath(); g.ellipse(0, k * 0.3, k * 0.85, k * 0.85, 0, Math.PI, 0); g.closePath(); g.fillStyle = '#d4b070'; g.fill(); for (const [x, c] of [[-0.4, '#c8782a'], [-0.12, '#7cc35a'], [0.15, '#e5483b'], [0.42, '#c8782a']]) E(g, x * k, -k * 0.2, k * 0.2, k * 0.17, c); g.beginPath(); g.ellipse(0, k * 0.3, k * 0.85, k * 0.5, 0, Math.PI, 0); g.closePath(); g.fillStyle = '#efd9a0'; g.fill(); for (const [x, y] of [[-0.4, 0.05], [0.3, -0.05]]) E(g, x * k, y * k, k * 0.08, k * 0.05, '#c89a50'); }],
    ['L또케', (g, k) => RT(g, 0, 0, -0.3, () => { RR(g, -k * 0.85, -k * 0.35, k * 1.7, k * 0.7, k * 0.35, '#efd9a0'); E(g, k * 0.8, 0, k * 0.16, k * 0.32, '#7cc35a'); E(g, k * 0.78, 0, k * 0.12, k * 0.24, '#9a5a2a'); for (let i = 0; i < 3; i++) LN(g, [-k * 0.6 + i * k * 0.4, -k * 0.3, -k * 0.5 + i * k * 0.4, k * 0.3], 'rgba(170,130,70,.5)', k * 0.04); })],
    ['l겹', (g, k) => { E(g, 0, k * 0.1, k * 0.85, k * 0.6, '#5ea844'); E(g, 0, k * 0.05, k * 0.7, k * 0.48, '#8fd06a'); LN(g, [0, -k * 0.4, 0, k * 0.5], '#c8e8a0', k * 0.06); RT(g, 0, -k * 0.05, -0.3, () => { RR(g, -k * 0.45, -k * 0.15, k * 0.9, k * 0.3, k * 0.08, '#a85a38'); RR(g, -k * 0.45, -k * 0.04, k * 0.9, k * 0.06, 0, '#f2d6b8'); }); Ci(g, k * 0.35, k * 0.25, k * 0.1, '#b8322a'); }],
    ['ER치', (g, k) => { riceMound(g, 0, k * 0.12, k * 0.75, k * 0.5, '#e8704a'); for (let i = 0; i < 6; i++) E(g, (i - 2.5) * k * 0.22, k * 0.15 + (i % 2) * k * 0.15, k * 0.08, k * 0.05, '#c8321e'); g.save(); g.translate(0, -k * 0.2); g.scale(0.55, 0.55); ART2E(g, k); g.restore(); }],
    ['R불', (g, k) => { riceMound(g, -k * 0.38, k * 0.05, k * 0.4, k * 0.34); g.save(); g.translate(k * 0.3, 0); g.scale(0.7, 0.7); ART['불'](g, k); g.restore(); }],
    ['ER굽', (g, k) => { RR(g, -k * 0.85, -k * 0.55, k * 1.7, k * 1.1, k * 0.12, '#3a5a8a'); RR(g, -k * 0.75, -k * 0.45, k * 1.5, k * 0.9, k * 0.08, '#f4ead8'); LN(g, [k * 0.05, -k * 0.45, k * 0.05, k * 0.45], '#3a5a8a', k * 0.06); riceMound(g, -k * 0.35, 0, k * 0.34, k * 0.36); Ci(g, -k * 0.35, 0, k * 0.07, '#c8321e'); g.save(); g.translate(k * 0.42, -k * 0.2); g.scale(0.38, 0.38); ART2E(g, k); g.restore(); RT(g, k * 0.42, k * 0.22, -0.2, () => { RR(g, -k * 0.28, -k * 0.09, k * 0.56, k * 0.18, k * 0.09, '#a8452e'); }); }],
    ['R데', (g, k) => { for (const x of [-0.4, 0.4]) { RR(g, x * k - k * 0.32, -k * 0.05, k * 0.64, k * 0.4, k * 0.18, '#fbf9f2'); RR(g, x * k - k * 0.36, -k * 0.3, k * 0.72, k * 0.32, k * 0.14, '#f08a6a'); for (let i = 0; i < 3; i++) LN(g, [x * k - k * 0.2 + i * k * 0.18, -k * 0.28, x * k - k * 0.15 + i * k * 0.18, -k * 0.02], '#fff2ea', k * 0.04); } }],
    ['ERn', (g, k) => { for (const x of [-0.4, 0.4]) { RR(g, x * k - k * 0.32, -k * 0.05, k * 0.64, k * 0.4, k * 0.18, '#fbf9f2'); RR(g, x * k - k * 0.36, -k * 0.32, k * 0.72, k * 0.34, k * 0.08, '#ffd84a'); RR(g, x * k - k * 0.09, -k * 0.34, k * 0.18, k * 0.72, k * 0.03, '#1f3326'); } }],
    ['스테', (g, k) => { g.save(); g.translate(-k * 0.2, k * 0.05); g.scale(0.75, 0.75); ART['테'](g, k); g.restore(); g.save(); g.translate(k * 0.5, -k * 0.3); g.scale(0.42, 0.42); ART['스'](g, k); g.restore(); }],
    ['L테', (g, k) => { drawItem(g, 'L', k * 1.5); for (let i = 0; i < 3; i++) RT(g, (i - 1) * k * 0.3, -k * 0.05, 0.3, () => { RR(g, -k * 0.12, -k * 0.3, k * 0.24, k * 0.6, k * 0.06, '#6a2e1a'); RR(g, -k * 0.08, -k * 0.26, k * 0.12, k * 0.52, k * 0.04, '#c86a5a'); }); }],
  ].forEach(([c, f]) => { DART[srt(c)] = f; });
  function ART2E(g, k) { drawItem(g, 'E', k * 2); }
  /* ingredient / dish art: centred at 0,0 in a box of size s */
  function drawItem(g, c, s) {
    const k = s / 2;
    switch (c) {
      case 'b': E(g, 0, k * 0.3, k * 0.88, k * 0.42, '#b46f32'); E(g, 0, k * 0.02, k * 0.88, k * 0.62, '#e3a75c'); E(g, -k * 0.25, -k * 0.24, k * 0.38, k * 0.18, 'rgba(255,240,210,.5)');
        for (const [x, y] of [[-0.45, -0.05], [0.1, -0.32], [0.42, -0.02], [-0.08, 0.12], [0.3, -0.24], [-0.32, -0.3]]) E(g, x * k, y * k, k * 0.08, k * 0.045, '#fff3d6', 0.4); break;
      case 'm': E(g, 0, 0, k * 0.84, k * 0.64, '#c95d5d'); E(g, -k * 0.04, -k * 0.05, k * 0.74, k * 0.54, '#e98585');
        LN(g, [-k * 0.5, -k * 0.1, -k * 0.1, -k * 0.25, k * 0.3, 0], '#fbe0e0', k * 0.1); LN(g, [-k * 0.3, k * 0.25, k * 0.2, k * 0.2], '#fbe0e0', k * 0.08); break;
      case 'M': E(g, 0, k * 0.1, k * 0.86, k * 0.56, '#4a2614'); E(g, 0, 0, k * 0.86, k * 0.54, '#7a4424');
        for (let i = -1; i <= 1; i++) LN(g, [-k * 0.5, i * k * 0.24 - k * 0.1, k * 0.5, i * k * 0.24 + k * 0.1], '#3a1c0c', k * 0.09);
        E(g, -k * 0.3, -k * 0.22, k * 0.22, k * 0.08, 'rgba(255,200,150,.3)'); break;
      case 'l': Ci(g, 0, 0, k * 0.82, '#4f9a3a'); Ci(g, -k * 0.08, -k * 0.06, k * 0.66, '#7cc35a'); Ci(g, -k * 0.12, -k * 0.12, k * 0.36, '#b4e58c');
        LN(g, [-k * 0.6, k * 0.1, -k * 0.2, k * 0.3, k * 0.2, k * 0.1], '#4f9a3a', k * 0.08); break;
      case 'L': for (let i = 0; i < 5; i++) { const y = (i - 2) * k * 0.26, x0 = -k * 0.7 + (i % 2) * k * 0.15; LN(g, [x0, y, x0 + k * 0.3, y - k * 0.14, x0 + k * 0.6, y + k * 0.08, x0 + k * 0.9, y - k * 0.1, x0 + k * 1.2, y + k * 0.05], i % 2 ? '#5ea844' : '#9edc72', k * 0.2); } break;
      case 't': Ci(g, 0, k * 0.06, k * 0.8, '#c8302a'); Ci(g, -k * 0.05, 0, k * 0.72, '#e5483b'); E(g, -k * 0.3, -k * 0.25, k * 0.2, k * 0.13, 'rgba(255,255,255,.45)', -0.5);
        for (let i = 0; i < 5; i++) { const a = i / 5 * TAU - Math.PI / 2; LN(g, [0, -k * 0.62, Math.cos(a) * k * 0.3, -k * 0.62 + Math.sin(a) * k * 0.2], '#3f8a2e', k * 0.14); } break;
      case 'T': for (const [x, y] of [[-0.3, 0.12], [0.3, -0.12]]) { Ci(g, x * k, y * k, k * 0.55, '#d0392f'); Ci(g, x * k, y * k, k * 0.43, '#f2705e'); for (let i = 0; i < 4; i++) { const a = i / 4 * TAU + 0.4; E(g, x * k + Math.cos(a) * k * 0.22, y * k + Math.sin(a) * k * 0.22, k * 0.08, k * 0.05, '#ffd9a0', a); } } break;
      case 'c': g.beginPath(); g.moveTo(-k * 0.8, k * 0.5); g.lineTo(k * 0.8, k * 0.5); g.lineTo(k * 0.55, -k * 0.55); g.closePath(); g.fillStyle = '#e8b53a'; g.fill();
        g.beginPath(); g.moveTo(-k * 0.8, k * 0.5); g.lineTo(k * 0.55, -k * 0.55); g.lineTo(k * 0.62, -k * 0.2); g.lineTo(-k * 0.6, k * 0.62); g.closePath(); g.fillStyle = '#f7d462'; g.fill();
        Ci(g, k * 0.1, k * 0.15, k * 0.12, '#d49a22'); Ci(g, k * 0.45, -k * 0.05, k * 0.09, '#d49a22'); Ci(g, -k * 0.3, k * 0.38, k * 0.08, '#d49a22'); break;
      case 'r': RR(g, -k * 0.62, -k * 0.5, k * 1.24, k * 1.3, k * 0.3, '#d9c9a4'); RR(g, -k * 0.62, -k * 0.5, k * 1.24, k * 0.5, k * 0.25, '#e8dcc0'); E(g, 0, -k * 0.55, k * 0.5, k * 0.2, '#fbf8ef');
        LN(g, [-k * 0.35, -k * 0.35, k * 0.35, -k * 0.35], '#8a6a3a', k * 0.12); for (let i = 0; i < 6; i++) E(g, (i - 2.5) * k * 0.17, -k * 0.6 + (i % 2) * k * 0.08, k * 0.06, k * 0.035, '#fff'); break;
      case 'R': E(g, 0, k * 0.22, k * 0.82, k * 0.5, '#3f6c9e'); E(g, 0, k * 0.12, k * 0.82, k * 0.32, '#5a8cc4'); E(g, 0, -k * 0.05, k * 0.66, k * 0.52, '#fbf9f2');
        for (let i = 0; i < 7; i++) E(g, (i - 3) * k * 0.17, -k * 0.15 - (i % 3) * k * 0.1, k * 0.07, k * 0.04, '#e9e4d6', i); break;
      case 'f': g.beginPath(); g.moveTo(k * 0.55, 0); g.lineTo(k * 0.95, -k * 0.38); g.lineTo(k * 0.95, k * 0.38); g.closePath(); g.fillStyle = '#6e93aa'; g.fill();
        E(g, -k * 0.1, 0, k * 0.72, k * 0.42, '#8fb3c9'); E(g, -k * 0.1, k * 0.15, k * 0.6, k * 0.2, '#d6e6ef'); Ci(g, -k * 0.5, -k * 0.08, k * 0.09, '#1d2a33'); LN(g, [-k * 0.3, -k * 0.3, -k * 0.25, k * 0.25], '#6e93aa', k * 0.06); break;
      case 'F': for (let i = 0; i < 3; i++) { g.save(); g.translate((i - 1) * k * 0.42, (i - 1) * k * 0.08); g.rotate(-0.35); RR(g, -k * 0.22, -k * 0.55, k * 0.44, k * 1.1, k * 0.16, '#f07a4a'); for (let j = 0; j < 3; j++) LN(g, [-k * 0.18, -k * 0.3 + j * k * 0.3, k * 0.18, -k * 0.38 + j * k * 0.3], '#ffd0b8', k * 0.07); g.restore(); } break;
      case 'J': g.beginPath(); g.moveTo(k * 0.55, 0); g.lineTo(k * 0.95, -k * 0.38); g.lineTo(k * 0.95, k * 0.38); g.closePath(); g.fillStyle = '#7a4a24'; g.fill();
        E(g, -k * 0.1, 0, k * 0.72, k * 0.42, '#b07a4a'); for (let i = -1; i <= 1; i++) LN(g, [i * k * 0.3 - k * 0.15, -k * 0.32, i * k * 0.3 + k * 0.05, k * 0.32], '#5a3418', k * 0.08);
        Ci(g, -k * 0.55, -k * 0.08, k * 0.08, '#1d1410'); E(g, k * 0.15, -k * 0.5, k * 0.2, k * 0.12, '#f6e27a'); break;
      case 'u': g.save(); g.rotate(-0.6); RR(g, -k * 0.95, -k * 0.27, k * 1.9, k * 0.54, k * 0.27, '#3d7d39'); RR(g, -k * 0.9, -k * 0.22, k * 1.8, k * 0.3, k * 0.15, '#5bab4f');
        for (let i = 0; i < 5; i++) Ci(g, (i - 2) * k * 0.35, k * 0.05 * (i % 2 ? 1 : -1), k * 0.05, '#2b5c28'); g.restore(); break;
      case 'U': for (const [x, y] of [[-0.42, 0.18], [0.4, 0.2], [0, -0.3]]) { Ci(g, x * k, y * k, k * 0.4, '#3d7d39'); Ci(g, x * k, y * k, k * 0.32, '#d8f0b0'); Ci(g, x * k, y * k, k * 0.13, '#b4dc88'); } break;
      case 'n': RR(g, -k * 0.75, -k * 0.75, k * 1.5, k * 1.5, k * 0.12, '#1f3326'); for (let i = 0; i < 4; i++) LN(g, [-k * 0.6, -k * 0.45 + i * k * 0.3, k * 0.6, -k * 0.5 + i * k * 0.3], '#365a42', k * 0.06); break;
      case 'p': for (let i = 0; i < 6; i++) LN(g, [-k * 0.8, -k * 0.35 + i * k * 0.14, k * 0.8, -k * 0.3 + i * k * 0.14], i % 2 ? '#e8c860' : '#f6e094', k * 0.12); RR(g, -k * 0.14, -k * 0.5, k * 0.28, k * 1.0, k * 0.06, '#c0392b'); break;
      case 'P': E(g, 0, k * 0.2, k * 0.8, k * 0.5, '#e6c870'); for (let i = 0; i < 5; i++) { const y = -k * 0.3 + i * k * 0.15; LN(g, [-k * 0.65, y, -k * 0.3, y - k * 0.12, 0, y + k * 0.06, k * 0.3, y - k * 0.1, k * 0.65, y + k * 0.04], i % 2 ? '#d9b44c' : '#f8e6a0', k * 0.11); } break;
      case 'd': E(g, 0, k * 0.12, k * 0.86, k * 0.5, '#cfae78'); E(g, 0, 0, k * 0.86, k * 0.5, '#ecd3a4'); for (const [x, y] of [[-0.3, -0.1], [0.2, 0.1], [0.4, -0.15], [-0.1, 0.2]]) Ci(g, x * k, y * k, k * 0.07, '#fff8ea'); break;
      case 'g': for (const [x, y, r] of [[-0.35, 0.25, 0.4], [0.3, 0.2, -0.3], [0, -0.3, 0.1]]) { g.save(); g.translate(x * k, y * k); g.rotate(r); RR(g, -k * 0.5, -k * 0.17, k * 1.0, k * 0.34, k * 0.17, '#d9d0c0'); RR(g, -k * 0.5, -k * 0.17, k * 1.0, k * 0.26, k * 0.13, '#fbf7ee'); g.restore(); } break;
      case 'j': RR(g, -k * 0.55, -k * 0.45, k * 1.1, k * 1.25, k * 0.25, '#a82a22'); RR(g, -k * 0.6, -k * 0.75, k * 1.2, k * 0.36, k * 0.1, '#4a2018'); RR(g, -k * 0.38, -k * 0.15, k * 0.76, k * 0.5, k * 0.08, '#f2e9d8');
        Ci(g, 0, k * 0.1, k * 0.14, '#c0392b'); break;
      case 'e': E(g, 0, k * 0.05, k * 0.6, k * 0.78, '#e8dccb'); E(g, -k * 0.04, 0, k * 0.55, k * 0.72, '#fdf8ee'); E(g, -k * 0.2, -k * 0.3, k * 0.14, k * 0.22, 'rgba(255,255,255,.9)'); break;
      case 'E': g.beginPath(); for (let i = 0; i <= 10; i++) { const a = i / 10 * TAU, r = k * (0.78 + 0.12 * Math.sin(i * 2.7)); i ? g.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.8) : g.moveTo(Math.cos(a) * r, Math.sin(a) * r * 0.8); } g.fillStyle = '#fffaf0'; g.fill();
        Ci(g, k * 0.05, 0, k * 0.34, '#f5b014'); Ci(g, k * 0.02, -k * 0.03, k * 0.3, '#ffc928'); Ci(g, -k * 0.06, -k * 0.11, k * 0.09, '#fff2b0'); break;
      case 'o': g.beginPath(); g.moveTo(0, -k * 0.85); g.quadraticCurveTo(k * 0.95, k * 0.1, 0, k * 0.75); g.quadraticCurveTo(-k * 0.95, k * 0.1, 0, -k * 0.85); g.fillStyle = '#9a5fb4'; g.fill();
        LN(g, [0, -k * 0.6, -k * 0.3, k * 0.4], '#c99be0', k * 0.08); LN(g, [0, -k * 0.6, k * 0.3, k * 0.4], '#c99be0', k * 0.08); LN(g, [0, -k * 0.85, k * 0.1, -k * 1.0], '#7a8a3a', k * 0.1); break;
      case 'O': for (const [x, y, r] of [[-0.3, 0.15, 0.5], [0.32, -0.1, 0.45], [0, -0.35, 0.3]]) { Ci(g, x * k, y * k, r * k); g.strokeStyle = '#a86cc4'; g.lineWidth = k * 0.16; g.stroke(); g.strokeStyle = '#e4c8f0'; g.lineWidth = k * 0.06; g.stroke(); } break;
      case 'a': E(g, 0, k * 0.25, k * 0.85, k * 0.55, '#7f97aa'); E(g, 0, 0, k * 0.85, k * 0.38, '#a9bccb'); E(g, 0, 0, k * 0.7, k * 0.28, '#f1dcae'); LN(g, [k * 0.1, -k * 0.05, k * 0.75, -k * 0.85], '#8a8794', k * 0.1);
        E(g, k * 0.18, -k * 0.12, k * 0.2, k * 0.12, '#cfc9d6'); break;
      case 'A': for (let i = 2; i >= 0; i--) { E(g, 0, i * k * 0.22 - k * 0.05, k * 0.82, k * 0.34, '#b06a24'); E(g, 0, i * k * 0.22 - k * 0.1, k * 0.8, k * 0.3, '#e7a556'); }
        RR(g, -k * 0.18, -k * 0.38, k * 0.36, k * 0.22, k * 0.05, '#ffe48a'); LN(g, [k * 0.5, -k * 0.12, k * 0.62, k * 0.3], '#8a4a12', k * 0.1); break;
      case 's': g.beginPath(); g.moveTo(0, k * 0.85); g.bezierCurveTo(-k * 0.95, k * 0.1, -k * 0.6, -k * 0.6, 0, -k * 0.45); g.bezierCurveTo(k * 0.6, -k * 0.6, k * 0.95, k * 0.1, 0, k * 0.85); g.fillStyle = '#e0303f'; g.fill();
        for (const [x, y] of [[-0.3, -0.1], [0.25, -0.15], [0, 0.15], [-0.18, 0.4], [0.2, 0.42], [0.42, 0.1], [-0.45, 0.15]]) E(g, x * k, y * k, k * 0.04, k * 0.07, '#ffe08a');
        for (let i = 0; i < 4; i++) { const a = -Math.PI / 2 + (i - 1.5) * 0.6; LN(g, [0, -k * 0.5, Math.cos(a) * k * 0.4, -k * 0.5 + Math.sin(a) * k * 0.25], '#3f8a2e', k * 0.14); } break;
      case 'S': for (const [x, y] of [[-0.35, 0.05], [0.35, 0.05]]) { E(g, x * k, y * k, k * 0.42, k * 0.55, '#e0303f'); E(g, x * k, y * k + k * 0.05, k * 0.25, k * 0.35, '#ffb0b8'); E(g, x * k, y * k + k * 0.08, k * 0.1, k * 0.2, '#fff0f0'); } break;
      case 'k': E(g, 0, 0, k * 0.82, k * 0.6, '#a87a48', -0.3); E(g, -k * 0.05, -k * 0.05, k * 0.74, k * 0.52, '#c9a06a', -0.3); for (const [x, y] of [[-0.3, -0.1], [0.25, 0.15], [0.4, -0.2], [-0.1, 0.3]]) Ci(g, x * k, y * k, k * 0.06, '#8a6038'); break;
      case 'K': for (let i = 0; i < 5; i++) { g.save(); g.translate((i - 2) * k * 0.3, (i % 2) * k * 0.15); g.rotate(0.25 * (i - 2)); RR(g, -k * 0.12, -k * 0.6, k * 0.24, k * 1.2, k * 0.06, '#e8d49a'); RR(g, -k * 0.12, -k * 0.6, k * 0.12, k * 1.2, k * 0.05, '#f6e8bc'); g.restore(); } break;
      case 'V': for (let i = 0; i < 6; i++) { g.save(); g.translate((i - 2.5) * k * 0.2, -k * 0.35); g.rotate((i - 2.5) * 0.12); RR(g, -k * 0.09, -k * 0.5, k * 0.18, k * 0.8, k * 0.05, i % 2 ? '#e8b030' : '#f6cf58'); g.restore(); }
        g.beginPath(); g.moveTo(-k * 0.7, -k * 0.2); g.lineTo(k * 0.7, -k * 0.2); g.lineTo(k * 0.52, k * 0.85); g.lineTo(-k * 0.52, k * 0.85); g.closePath(); g.fillStyle = '#d63a2a'; g.fill(); Ci(g, 0, k * 0.32, k * 0.2, '#f6cf58'); break;
      case 'Q': bowl(g, k, '#d8432f'); LN(g, [-k * 0.3, -k * 0.05, -k * 0.05, -k * 0.15, k * 0.2, 0, k * 0.35, -k * 0.1], '#fbe6d0', k * 0.1); Ci(g, k * 0.3, k * 0.1, k * 0.07, '#5fae4a'); break;
      case 'Y': bowl(g, k, '#a8693a', '#3d3a44'); E(g, 0, -k * 0.02, k * 0.5, k * 0.3, '#e3b45c'); for (const [x, y] of [[-0.2, 0], [0.15, -0.08], [0.05, 0.1]]) Ci(g, x * k, y * k, k * 0.08, '#c4893a'); break;
      case 'G': E(g, 0, k * 0.15, k * 0.92, k * 0.6, '#f2e9d8'); E(g, 0, k * 0.05, k * 0.8, k * 0.48, '#c9301e');
        for (const [x, y, r] of [[-0.35, 0, 0.5], [0.2, -0.1, -0.4], [0.05, 0.2, 0.1], [-0.1, -0.2, -0.9]]) { g.save(); g.translate(x * k, y * k); g.rotate(r); RR(g, -k * 0.28, -k * 0.09, k * 0.56, k * 0.18, k * 0.09, '#fbf3e6'); g.restore(); }
        Ci(g, k * 0.45, k * 0.1, k * 0.06, '#5fae4a'); Ci(g, -k * 0.5, k * 0.25, k * 0.05, '#5fae4a'); break;
      case 'N': bowl(g, k, '#d8582a', '#e9dcc4'); for (let i = 0; i < 3; i++) { const y = -k * 0.15 + i * k * 0.13; LN(g, [-k * 0.5, y, -k * 0.2, y - k * 0.1, k * 0.1, y + k * 0.05, k * 0.4, y - k * 0.08], '#f6dc8a', k * 0.09); }
        E(g, k * 0.32, -k * 0.12, k * 0.2, k * 0.14, '#fffaf0'); Ci(g, k * 0.32, -k * 0.12, k * 0.09, '#ffb820'); break;
      case 'Z': Ci(g, 0, 0, k * 0.9, '#c98a3e'); Ci(g, 0, 0, k * 0.76, '#d8432f'); for (const [x, y] of [[-0.3, -0.25], [0.3, -0.2], [0.05, 0.3], [-0.35, 0.25], [0.4, 0.25], [0, -0.45]]) E(g, x * k, y * k, k * 0.2, k * 0.15, '#f7d462', x * 3);
        for (let i = 0; i < 3; i++) { const a = i / 3 * Math.PI; LN(g, [Math.cos(a) * k * 0.76, Math.sin(a) * k * 0.76, -Math.cos(a) * k * 0.76, -Math.sin(a) * k * 0.76], 'rgba(120,60,20,.35)', k * 0.04); } break;
      case 'X': E(g, 0, k * 0.15, k * 0.92, k * 0.6, '#7a3f22'); E(g, 0, k * 0.05, k * 0.8, k * 0.5, '#e8b04a'); for (const [x, y] of [[-0.3, 0], [0.25, -0.12], [0.1, 0.22], [-0.05, -0.25], [0.45, 0.12]]) Ci(g, x * k, y * k, k * 0.1, '#b8742a'); break;
      case 'x': E(g, 0, k * 0.2, k * 0.8, k * 0.5, '#181412'); E(g, -k * 0.1, k * 0.1, k * 0.6, k * 0.38, '#2e2622'); Ci(g, k * 0.25, k * 0.05, k * 0.12, '#40342c');
        LN(g, [-k * 0.2, -k * 0.2, -k * 0.35, -k * 0.5, -k * 0.15, -k * 0.75], 'rgba(160,150,150,.7)', k * 0.1); LN(g, [k * 0.2, -k * 0.15, k * 0.35, -k * 0.45, k * 0.2, -k * 0.7], 'rgba(160,150,150,.6)', k * 0.08); break;
      default: if (ART[c]) ART[c](g, k); else Ci(g, 0, 0, k * 0.6, IT[c] ? IT[c][1] : '#888');
    }
  }
  /* a plate with contents (special looks for burgers, toast, sushi, rolls, pancakes) */
  function drawPlate(g, c, s, dirty) {
    const k = s / 2;
    E(g, 0, k * 0.16, k * 0.94, k * 0.66, dirty ? '#a59c90' : '#d9d2c4');
    E(g, 0, k * 0.08, k * 0.94, k * 0.64, dirty ? '#c9c0b0' : '#fbf7ef');
    E(g, 0, k * 0.08, k * 0.66, k * 0.42, dirty ? '#bdb2a0' : '#efe8da');
    if (dirty) { E(g, -k * 0.2, k * 0.05, k * 0.2, k * 0.1, '#8a6a4a'); E(g, k * 0.25, k * 0.15, k * 0.14, k * 0.07, '#9a7a3a'); return; }
    if (!c) return;
    const has = (x) => c.includes(x);
    const only = (set) => [...c].every((x) => set.includes(x));
    g.save(); g.translate(0, -k * 0.05);
    const art = DART[c];
    if (art) { art(g, k * 0.92); g.restore(); return; }
    if (has('b') && only('bMcLT킨')) { // burger stack / bread
      if (!has('M') && !has('L') && !has('T') && !has('킨')) { drawItem(g, 'b', k * 1.3); if (has('c')) { g.translate(k * 0.3, k * 0.1); drawItem(g, 'c', k * 0.8); } }
      else {
        let y = k * 0.3;
        E(g, 0, y, k * 0.72, k * 0.24, '#b46f32'); E(g, 0, y - k * 0.05, k * 0.72, k * 0.2, '#d99a52'); y -= k * 0.16;
        if (has('L')) { for (let i = 0; i < 5; i++) Ci(g, (i - 2) * k * 0.3, y + (i % 2) * k * 0.04, k * 0.16, '#79c255'); y -= k * 0.08; }
        if (has('M')) { E(g, 0, y, k * 0.74, k * 0.2, '#5a2e16'); E(g, 0, y - k * 0.04, k * 0.7, k * 0.15, '#7a4424'); y -= k * 0.14; }
        if (has('킨')) { E(g, 0, y, k * 0.8, k * 0.22, '#a8641a'); E(g, 0, y - k * 0.04, k * 0.76, k * 0.17, '#e09a34'); for (let i = 0; i < 5; i++) Ci(g, (i - 2) * k * 0.3, y - k * 0.06, k * 0.04, '#fbe0a0'); y -= k * 0.16; }
        if (has('c')) { g.beginPath(); g.moveTo(-k * 0.7, y); g.lineTo(k * 0.7, y); g.lineTo(k * 0.5, y + k * 0.18); g.lineTo(-k * 0.2, y + k * 0.12); g.closePath(); g.fillStyle = '#f7d050'; g.fill(); y -= k * 0.06; }
        if (has('T')) { E(g, -k * 0.28, y, k * 0.3, k * 0.1, '#e5483b'); E(g, k * 0.28, y, k * 0.3, k * 0.1, '#e5483b'); y -= k * 0.08; }
        if (has('b')) { E(g, 0, y - k * 0.1, k * 0.76, k * 0.4, '#e3a75c'); E(g, -k * 0.2, y - k * 0.24, k * 0.3, k * 0.12, 'rgba(255,240,210,.5)'); for (const x of [-0.35, 0, 0.3]) E(g, x * k, y - k * 0.2 + Math.abs(x) * k * 0.2, k * 0.06, k * 0.035, '#fff3d6'); }
      }
    } else if (has('b') && only('bEc')) { // toast
      RR(g, -k * 0.6, -k * 0.5, k * 1.2, k * 1.0, k * 0.3, '#c9893e'); RR(g, -k * 0.52, -k * 0.42, k * 1.04, k * 0.84, k * 0.24, '#f2d49a');
      if (has('c')) { g.save(); g.rotate(0.2); RR(g, -k * 0.42, -k * 0.38, k * 0.84, k * 0.7, k * 0.06, '#f7d050'); g.restore(); }
      if (has('E')) { g.save(); g.scale(0.62, 0.62); drawItem(g, 'E', s); g.restore(); }
    } else if (only('FR') && has('R') && has('F')) { // nigiri
      for (const x of [-0.4, 0.4]) { RR(g, x * k - k * 0.32, -k * 0.05, k * 0.64, k * 0.4, k * 0.18, '#fbf9f2'); RR(g, x * k - k * 0.36, -k * 0.28, k * 0.72, k * 0.32, k * 0.14, '#f07a4a'); LN(g, [x * k - k * 0.15, -k * 0.24, x * k + k * 0.05, -k * 0.04], '#ffd0b8', k * 0.06); }
    } else if (has('n') && has('R') && only('nRUF')) { // rolls or rice ball
      if (c.length === 2) { g.beginPath(); g.moveTo(0, -k * 0.62); g.quadraticCurveTo(k * 0.75, k * 0.42, k * 0.05, k * 0.42); g.quadraticCurveTo(-k * 0.75, k * 0.42, 0, -k * 0.62); g.fillStyle = '#fbf9f2'; g.fill(); RR(g, -k * 0.28, k * 0.05, k * 0.56, k * 0.4, k * 0.06, '#1f3326'); }
      else for (const [x, y] of [[-0.42, 0.12], [0.42, 0.12], [0, -0.25]]) { Ci(g, x * k, y * k, k * 0.36, '#1f3326'); Ci(g, x * k, y * k, k * 0.29, '#fbf9f2'); Ci(g, x * k, y * k, k * 0.12, has('F') ? '#f07a4a' : '#5bab4f'); if (has('U') && has('F')) Ci(g, x * k + k * 0.08, y * k, k * 0.06, '#5bab4f'); }
    } else if (has('A') && only('AS')) {
      drawItem(g, 'A', k * 1.5);
      if (has('S')) { for (const [x, y] of [[-0.25, -0.3], [0.2, -0.38]]) { E(g, x * k, y * k, k * 0.16, k * 0.2, '#e0303f'); E(g, x * k, y * k + k * 0.03, k * 0.08, k * 0.11, '#ffb0b8'); } }
    } else if (c.length === 1) drawItem(g, c, k * 1.45);
    else { // cluster
      const n = c.length, sz = k * (n <= 2 ? 1.0 : n === 3 ? 0.88 : 0.78);
      for (let i = 0; i < n; i++) { const a = -Math.PI / 2 + (i / n) * TAU + (n === 2 ? Math.PI / 2 : 0), rr = n === 1 ? 0 : k * (n === 2 ? 0.34 : 0.38); g.save(); g.translate(Math.cos(a) * rr, Math.sin(a) * rr * 0.75); drawItem(g, c[i], sz); g.restore(); }
    }
    g.restore();
  }
  /* small station glyphs: cut / pan / pot / oven */
  function drawGlyph(g, kind, s) {
    const k = s / 2;
    if (kind === 'cut') { g.save(); g.rotate(-0.7); RR(g, -k * 0.2, -k * 0.95, k * 0.5, k * 1.2, k * 0.12, '#d7dde4'); RR(g, -k * 0.15, k * 0.2, k * 0.38, k * 0.75, k * 0.12, '#5a3a24'); g.restore(); }
    else if (kind === 'pan') { LN(g, [k * 0.3, k * 0.25, k * 0.95, k * 0.75], '#3a3a44', k * 0.24); Ci(g, -k * 0.15, -k * 0.1, k * 0.66, '#3a3a44'); Ci(g, -k * 0.15, -k * 0.1, k * 0.5, '#5a5a66'); }
    else if (kind === 'pot') { RR(g, -k * 0.75, -k * 0.35, k * 1.5, k * 1.05, k * 0.25, '#8d99a6'); RR(g, -k * 0.85, -k * 0.5, k * 1.7, k * 0.25, k * 0.1, '#b4c0cc'); RR(g, -k * 0.98, -k * 0.2, k * 0.3, k * 0.18, k * 0.06, '#5d6875'); RR(g, k * 0.68, -k * 0.2, k * 0.3, k * 0.18, k * 0.06, '#5d6875'); }
    else if (kind === 'oven') { RR(g, -k * 0.85, -k * 0.75, k * 1.7, k * 1.5, k * 0.2, '#4a4652'); RR(g, -k * 0.6, -k * 0.35, k * 1.2, k * 0.85, k * 0.12, '#f28a3a'); Ci(g, -k * 0.45, -k * 0.56, k * 0.1, '#d7dde4'); Ci(g, -k * 0.15, -k * 0.56, k * 0.1, '#d7dde4'); }
    else if (kind === 'knead') { g.save(); g.rotate(-0.5); RR(g, -k * 0.95, -k * 0.24, k * 1.9, k * 0.48, k * 0.24, '#e8c890'); RR(g, -k * 1.0, -k * 0.1, k * 0.25, k * 0.2, k * 0.08, '#8a5a32'); RR(g, k * 0.75, -k * 0.1, k * 0.25, k * 0.2, k * 0.08, '#8a5a32'); g.restore(); }
    else if (kind === 'grind') { PG(g, [-k * 0.7, -k * 0.8, k * 0.7, -k * 0.8, k * 0.3, -k * 0.1, -k * 0.3, -k * 0.1], '#9aa8b4'); RR(g, -k * 0.5, -k * 0.15, k * 1.0, k * 0.95, k * 0.15, '#5d6875'); LN(g, [0, -k * 0.95, 0, -k * 0.75, k * 0.45, -k * 0.95], '#d7dde4', k * 0.14); }
    else if (kind === 'fry') { RR(g, -k * 0.8, -k * 0.3, k * 1.6, k * 1.0, k * 0.15, '#9aa8b4'); RR(g, -k * 0.62, -k * 0.2, k * 1.24, k * 0.5, k * 0.1, '#f2c14e'); for (let i = 0; i < 3; i++) LN(g, [-k * 0.4 + i * k * 0.4, -k * 0.2, -k * 0.4 + i * k * 0.4, k * 0.3], '#5d6875', k * 0.08); LN(g, [k * 0.5, -k * 0.3, k * 0.95, -k * 0.85], '#3a3a44', k * 0.18); }
    else if (kind === 'steam') { E(g, 0, k * 0.35, k * 0.85, k * 0.35, '#b8864e'); RR(g, -k * 0.85, -k * 0.35, k * 1.7, k * 0.7, k * 0.1, '#d9a85e'); E(g, 0, -k * 0.35, k * 0.85, k * 0.32, '#e8c078'); for (let i = 0; i < 2; i++) LN(g, [-k * 0.85, -k * 0.05 + i * k * 0.25, k * 0.85, -k * 0.05 + i * k * 0.25], '#a8763e', k * 0.07); LN(g, [-k * 0.2, -k * 0.7, -k * 0.3, -k * 1.0], '#e8f0f4', k * 0.1); LN(g, [k * 0.2, -k * 0.7, k * 0.3, -k * 1.0], '#e8f0f4', k * 0.1); }
    else if (kind === 'grill') { RR(g, -k * 0.85, -k * 0.6, k * 1.7, k * 1.2, k * 0.15, '#2a2730'); for (let i = 0; i < 4; i++) LN(g, [-k * 0.6 + i * k * 0.4, -k * 0.5, -k * 0.6 + i * k * 0.4, k * 0.5], '#9aa8b4', k * 0.1); Ci(g, -k * 0.3, k * 0.2, k * 0.12, '#ff7a2a'); Ci(g, k * 0.3, -k * 0.1, k * 0.12, '#ffb02e'); }
    else if (kind === 'mix') { PG(g, [-k * 0.55, -k * 0.95, k * 0.55, -k * 0.95, k * 0.35, k * 0.25, -k * 0.35, k * 0.25], 'rgba(200,225,240,.95)'); PG(g, [-k * 0.45, -k * 0.45, k * 0.45, -k * 0.45, k * 0.33, k * 0.2, -k * 0.33, k * 0.2], '#f07a8a'); RR(g, -k * 0.6, k * 0.25, k * 1.2, k * 0.7, k * 0.15, '#4a4652'); Ci(g, 0, k * 0.6, k * 0.14, '#e3ae45'); }
  }
  /* cached sprites */
  const SPR = new Map();
  function sprite(key, px, dpr, fn) {
    px = Math.max(6, Math.round(px));
    const id = key + '|' + px + '|' + dpr;
    let c = SPR.get(id);
    if (c) return c;
    if (SPR.size > 600) SPR.clear();
    c = document.createElement('canvas');
    const pad = Math.ceil(px * 0.12) + 2, W = px + pad * 2;
    c.width = c.height = Math.ceil(W * dpr);
    const g = c.getContext('2d');
    g.scale(dpr, dpr); g.translate(W / 2, W / 2);
    g.shadowColor = 'rgba(20,10,20,.35)'; g.shadowBlur = Math.max(1, px * 0.06); g.shadowOffsetY = Math.max(0.5, px * 0.03);
    fn(g, px);
    c.cw = W;
    SPR.set(id, c);
    return c;
  }
  function blit(ctx, spr, x, y, scale) { const w = spr.cw * (scale || 1); ctx.drawImage(spr, x - w / 2, y - w / 2, w, w); }
  function thingSprite(th, px, dpr) {
    if (!th) return null;
    if (isPlate(th)) return sprite(th, px, dpr, (g, s) => drawPlate(g, th.slice(1), s));
    if (isDirty(th)) return sprite('%', px, dpr, (g, s) => drawPlate(g, '', s, 1));
    return sprite(th, px * 0.82, dpr, (g, s) => drawItem(g, th, s));
  }
  const dishSprite = (d, px, dpr) => sprite('@' + DISH[d].c, px, dpr, (g, s) => drawPlate(g, DISH[d].c, s));
  const glyphKind = (code) => (SRC[code] ? SRC[code][0] : null);

  /* static kitchen layer (floor, walls, counters, station bases) */
  function drawStatic(g, K, ts, thumb) {
    const W = GW * ts, H = GH * ts, pal = PAL[K.KD.pal] || PAL.def, pk = K.KD.pal;
    g.fillStyle = '#2a2030'; g.fillRect(0, 0, W, H);
    for (let y = 0; y < GH; y++) for (let x = 0; x < GW; x++) {
      const i = y * GW + x, c = K.g[i], X = x * ts, Y = y * ts;
      if (c === '.' || c === '=' || c === '|' || c === 'X' || c === '*') {
        g.fillStyle = (x + y) % 2 ? pal.f1 : pal.f2; g.fillRect(X, Y, ts, ts);
        if (!thumb) {
          g.fillStyle = pal.ln; g.fillRect(X, Y + ts - 1, ts, 1); g.fillRect(X + ts - 1, Y, 1, ts);
          if (pk === 'camp' && (x * 7 + y * 3) % 4 === 0) for (let q = 0; q < 3; q++) LN(g, [X + ts * (0.25 + q * 0.2), Y + ts * 0.8, X + ts * (0.22 + q * 0.2), Y + ts * 0.62], 'rgba(60,110,40,.55)', Math.max(1, ts * 0.04));
          if (pk === 'space') { g.strokeStyle = 'rgba(60,70,100,.35)'; g.lineWidth = 1; g.strokeRect(X + ts * 0.08, Y + ts * 0.08, ts * 0.84, ts * 0.84); Ci(g, X + ts * 0.15, Y + ts * 0.15, Math.max(0.8, ts * 0.03), 'rgba(50,60,90,.5)'); }
          if (pk === 'train' && x % 2 === 0) { g.fillStyle = 'rgba(140,40,30,.18)'; g.fillRect(X, Y, ts, ts); }
          if (pk === 'garden' && (x + y * 2) % 3 === 0) Ci(g, X + ts * 0.7, Y + ts * 0.3, Math.max(1, ts * 0.04), 'rgba(110,80,40,.45)');
        }
        if (c === '*') { for (let r = 3; r >= 1; r--) Ci(g, X + ts / 2, Y + ts / 2, ts * 0.13 * r, r % 2 ? '#7a4ac8' : '#c8a0ff'); }
      } else if (c === '~') {
        const gr = g.createLinearGradient(X, Y, X + ts, Y + ts); gr.addColorStop(0, '#d6f1fb'); gr.addColorStop(1, '#a6d8ee');
        g.fillStyle = gr; g.fillRect(X, Y, ts, ts);
        if (!thumb) { LN(g, [X + ts * 0.2, Y + ts * 0.7, X + ts * 0.45, Y + ts * 0.45], 'rgba(255,255,255,.8)', Math.max(1, ts * 0.05)); LN(g, [X + ts * 0.55, Y + ts * 0.3, X + ts * 0.7, Y + ts * 0.15], 'rgba(255,255,255,.6)', Math.max(1, ts * 0.04)); g.strokeStyle = 'rgba(90,160,200,.35)'; g.lineWidth = 1; g.strokeRect(X + 0.5, Y + 0.5, ts - 1, ts - 1); }
      } else if (c === '#' || c === 'o') {
        g.fillStyle = pal.w1; g.fillRect(X, Y, ts, ts);
        g.fillStyle = pal.w2; g.fillRect(X, Y, ts, ts * 0.18);
        if (!thumb) {
          g.fillStyle = 'rgba(0,0,0,.18)'; for (let r = 0; r < 3; r++) g.fillRect(X, Y + ts * (0.18 + r * 0.28), ts, 1);
          if (pk === 'space') for (let q = 0; q < 3; q++) Ci(g, X + ts * ((x * 13 + q * 29) % 10) / 10, Y + ts * (0.3 + ((y * 7 + q * 17) % 7) / 10), Math.max(0.8, ts * 0.025), '#f2e9d8');
          if (pk === 'camp') { Ci(g, X + ts * 0.5, Y + ts * 0.45, ts * 0.38, '#2a5a26'); Ci(g, X + ts * 0.35, Y + ts * 0.35, ts * 0.2, '#3d7434'); }
          if (pk === 'train') { RR(g, X + ts * 0.15, Y + ts * 0.25, ts * 0.7, ts * 0.45, ts * 0.08, '#9ac8e0'); RR(g, X + ts * 0.15, Y + ts * 0.25, ts * 0.7, ts * 0.12, ts * 0.06, '#c8e4f2'); }
          if (pk === 'magic') { Ci(g, X + ts * 0.5, Y + ts * 0.55, ts * 0.06, '#c8a0ff'); Ci(g, X + ts * 0.25, Y + ts * 0.8, ts * 0.04, '#f2e9d8'); }
          if (pk === 'night') { Ci(g, X + ts * 0.5, Y + ts * 0.55, ts * 0.16, (x + y) % 2 ? '#e8503a' : '#ffb04a'); RR(g, X + ts * 0.42, Y + ts * 0.32, ts * 0.16, ts * 0.08, ts * 0.02, '#2a1a1a'); }
        }
        if (c === 'o') { g.beginPath(); g.ellipse(X + ts / 2, Y + ts * 0.98, ts * 0.26, ts * 0.32, 0, Math.PI, 0); g.fillStyle = '#0d080c'; g.fill(); }
      }
      if (c === '=') { // rail
        g.fillStyle = 'rgba(90,80,90,.35)'; for (let k = 0; k < 3; k++) g.fillRect(X + ts * (0.12 + k * 0.32), Y + ts * 0.2, ts * 0.1, ts * 0.6);
        g.fillStyle = '#8a8794'; g.fillRect(X, Y + ts * 0.28, ts, Math.max(1, ts * 0.06)); g.fillRect(X, Y + ts * 0.66, ts, Math.max(1, ts * 0.06));
      }
    }
    K.st.forEach((S) => { if (!S.isl) drawStationBase(g, S, S.x * ts, S.y * ts, ts, thumb, K); });
    g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2; g.strokeRect(1, 1, W - 2, H - 2);
  }
  function counterTop(g, X, Y, ts, col) {
    RR(g, X + 1, Y + 1, ts - 2, ts - 2, ts * 0.1, '#6e4426');
    RR(g, X + 1, Y + 1, ts - 2, ts - 2 - ts * 0.1, ts * 0.1, col || '#b9844e');
    g.fillStyle = 'rgba(255,230,190,.16)'; g.fillRect(X + ts * 0.12, Y + ts * 0.14, ts * 0.76, Math.max(1, ts * 0.03));
  }
  function drawStationBase(g, S, X, Y, ts, thumb, K) {
    const cx = X + ts / 2, cy = Y + ts / 2;
    switch (S.ty) {
      case '_': counterTop(g, X, Y, ts); break;
      case 'C': if (K && K.KD.regrow) { // garden bed
          RR(g, X + 1, Y + 1, ts - 2, ts - 2, ts * 0.12, '#5a3a1e'); RR(g, X + ts * 0.08, Y + ts * 0.08, ts * 0.84, ts * 0.76, ts * 0.1, '#7a5230');
          if (!thumb) for (let q = 0; q < 3; q++) LN(g, [X + ts * 0.14, Y + ts * (0.28 + q * 0.2), X + ts * 0.86, Y + ts * (0.28 + q * 0.2)], 'rgba(40,20,10,.3)', Math.max(1, ts * 0.03));
        } else {
          counterTop(g, X, Y, ts, '#a87444');
          RR(g, X + ts * 0.1, Y + ts * 0.1, ts * 0.8, ts * 0.72, ts * 0.08, '#7a4a24'); RR(g, X + ts * 0.14, Y + ts * 0.14, ts * 0.72, ts * 0.6, ts * 0.06, '#c8945a');
          g.fillStyle = 'rgba(90,50,20,.35)'; g.fillRect(X + ts * 0.14, Y + ts * 0.34, ts * 0.72, Math.max(1, ts * 0.04)); g.fillRect(X + ts * 0.14, Y + ts * 0.54, ts * 0.72, Math.max(1, ts * 0.04));
        }
        if (S.ing && !thumb && !(K && K.KD.regrow)) { Ci(g, cx, cy - ts * 0.02, ts * 0.27, '#f6ecd8'); g.save(); g.translate(cx, cy - ts * 0.02); drawItem(g, S.ing, ts * 0.42); g.restore(); }
        else if (S.ing) { Ci(g, cx, cy, ts * 0.22, IT[S.ing][1]); }
        break;
      case 'B': counterTop(g, X, Y, ts);
        if (S.wk === 'knead') { // marble slab + rolling pin
          RR(g, X + ts * 0.12, Y + ts * 0.15, ts * 0.76, ts * 0.62, ts * 0.1, '#a8a4b0'); RR(g, X + ts * 0.14, Y + ts * 0.16, ts * 0.72, ts * 0.56, ts * 0.09, '#e8e6ee');
          if (!thumb) { E(g, X + ts * 0.35, Y + ts * 0.45, ts * 0.12, ts * 0.06, 'rgba(255,255,255,.7)'); g.save(); g.translate(X + ts * 0.74, Y + ts * 0.26); g.rotate(-0.6); RR(g, -ts * 0.16, -ts * 0.045, ts * 0.32, ts * 0.09, ts * 0.045, '#e8c890'); RR(g, -ts * 0.24, -ts * 0.025, ts * 0.08, ts * 0.05, ts * 0.02, '#8a5a32'); RR(g, ts * 0.16, -ts * 0.025, ts * 0.08, ts * 0.05, ts * 0.02, '#8a5a32'); g.restore(); }
        } else if (S.wk === 'grind') { // grinder
          RR(g, X + ts * 0.14, Y + ts * 0.18, ts * 0.72, ts * 0.6, ts * 0.1, '#4d5866'); RR(g, X + ts * 0.18, Y + ts * 0.22, ts * 0.64, ts * 0.5, ts * 0.08, '#8a96a4');
          if (!thumb) { Ci(g, X + ts * 0.5, Y + ts * 0.47, ts * 0.17, '#5d6875'); Ci(g, X + ts * 0.5, Y + ts * 0.47, ts * 0.1, '#c9d3dc'); for (let q = 0; q < 6; q++) { const a = q / 6 * TAU; LN(g, [X + ts * 0.5, Y + ts * 0.47, X + ts * (0.5 + Math.cos(a) * 0.15), Y + ts * (0.47 + Math.sin(a) * 0.15)], '#5d6875', Math.max(1, ts * 0.025)); } LN(g, [X + ts * 0.72, Y + ts * 0.2, X + ts * 0.85, Y + ts * 0.08], '#d7dde4', Math.max(1.5, ts * 0.05)); }
        } else {
          RR(g, X + ts * 0.13, Y + ts * 0.16, ts * 0.74, ts * 0.6, ts * 0.12, '#c99a62'); RR(g, X + ts * 0.15, Y + ts * 0.17, ts * 0.7, ts * 0.54, ts * 0.11, '#ecc995');
          if (!thumb) { g.save(); g.translate(X + ts * 0.8, Y + ts * 0.22); g.rotate(0.6); RR(g, -ts * 0.04, -ts * 0.02, ts * 0.08, ts * 0.22, ts * 0.03, '#d7dde4'); RR(g, -ts * 0.035, -ts * 0.14, ts * 0.07, ts * 0.12, ts * 0.03, '#4a2c18'); g.restore(); }
        }
        break;
      case 'L': // firewood pile
        RR(g, X + 1, Y + 1, ts - 2, ts - 2, ts * 0.12, '#4a6a34');
        for (const [yy, xs] of [[0.7, [0.28, 0.5, 0.72]], [0.5, [0.39, 0.61]], [0.3, [0.5]]]) for (const xx of xs) { Ci(g, X + ts * xx, Y + ts * yy, ts * 0.12, '#7a4a24'); Ci(g, X + ts * xx, Y + ts * yy, ts * 0.08, '#d9b07a'); Ci(g, X + ts * xx, Y + ts * yy, ts * 0.03, '#a87a48'); }
        break;
      case 'H':
        if (S.fu != null) { // campfire ring
          Ci(g, cx, cy + ts * 0.05, ts * 0.44, 'rgba(40,30,20,.35)');
          for (let q = 0; q < 9; q++) { const a = q / 9 * TAU; E(g, cx + Math.cos(a) * ts * 0.38, cy + ts * 0.05 + Math.sin(a) * ts * 0.34, ts * 0.09, ts * 0.07, q % 2 ? '#8a8794' : '#a8a4b0'); }
          Ci(g, cx, cy + ts * 0.05, ts * 0.28, '#2a2220');
          break;
        }
        if (S.ck === 'mix') { counterTop(g, X, Y, ts, '#9aa8b4'); RR(g, X + ts * 0.22, Y + ts * 0.5, ts * 0.56, ts * 0.32, ts * 0.08, '#4a4652'); break; }
        RR(g, X + 1, Y + 1, ts - 2, ts - 2, ts * 0.1, '#2d2a33'); RR(g, X + 2, Y + 2, ts - 4, ts - 4 - ts * 0.08, ts * 0.1, '#4d4957');
        if (S.ck === 'fry') { RR(g, X + ts * 0.12, Y + ts * 0.14, ts * 0.76, ts * 0.66, ts * 0.08, '#8a96a4'); RR(g, X + ts * 0.17, Y + ts * 0.2, ts * 0.66, ts * 0.52, ts * 0.06, '#b8822a'); break; }
        if (S.ck === 'grill') { RR(g, X + ts * 0.1, Y + ts * 0.12, ts * 0.8, ts * 0.7, ts * 0.08, '#1a1418'); for (let q = 0; q < 6; q++) Ci(g, X + ts * (0.25 + (q % 3) * 0.25), Y + ts * (0.35 + ((q / 3) | 0) * 0.25), ts * 0.08, q % 2 ? '#6a2a1a' : '#8a3a1e'); break; }
        if (S.ck === 'oven') {
          RR(g, X + ts * 0.12, Y + ts * 0.14, ts * 0.76, ts * 0.66, ts * 0.08, '#2a2730'); RR(g, X + ts * 0.2, Y + ts * 0.32, ts * 0.6, ts * 0.38, ts * 0.06, '#1a1418');
          if (!thumb) for (let k = 0; k < 3; k++) Ci(g, X + ts * (0.3 + k * 0.2), Y + ts * 0.22, ts * 0.04, '#c9c4d0');
        } else { Ci(g, cx, cy, ts * 0.36, '#2b2830'); g.beginPath(); g.arc(cx, cy, ts * 0.27, 0, TAU); g.strokeStyle = '#6a3a2a'; g.lineWidth = Math.max(1, ts * 0.04); g.stroke(); }
        break;
      case 'S': counterTop(g, X, Y, ts, '#9aa8b4');
        RR(g, X + ts * 0.14, Y + ts * 0.2, ts * 0.72, ts * 0.56, ts * 0.12, '#6c8193'); RR(g, X + ts * 0.18, Y + ts * 0.26, ts * 0.64, ts * 0.46, ts * 0.1, '#8fc3dc');
        if (!thumb) { LN(g, [X + ts * 0.5, Y + ts * 0.06, X + ts * 0.5, Y + ts * 0.2, X + ts * 0.58, Y + ts * 0.24], '#c9d3dc', Math.max(1.5, ts * 0.06)); E(g, X + ts * 0.4, Y + ts * 0.42, ts * 0.12, ts * 0.05, 'rgba(255,255,255,.5)'); }
        break;
      case 'P': counterTop(g, X, Y, ts, '#b98b5a'); RR(g, X + ts * 0.12, Y + ts * 0.62, ts * 0.76, ts * 0.12, ts * 0.04, '#8a5a32'); break;
      case 'D': counterTop(g, X, Y, ts, '#a07850'); RR(g, X + ts * 0.12, Y + ts * 0.14, ts * 0.76, ts * 0.66, ts * 0.08, '#7d8794');
        if (!thumb) { g.fillStyle = 'rgba(255,255,255,.15)'; for (let k = 0; k < 4; k++) g.fillRect(X + ts * 0.16, Y + ts * (0.2 + k * 0.14), ts * 0.68, Math.max(1, ts * 0.03)); }
        break;
      case 'T': counterTop(g, X, Y, ts);
        RR(g, X + ts * 0.2, Y + ts * 0.18, ts * 0.6, ts * 0.62, ts * 0.1, '#4f5866'); RR(g, X + ts * 0.16, Y + ts * 0.14, ts * 0.68, ts * 0.14, ts * 0.06, '#6b7584');
        if (!thumb) { g.fillStyle = '#3d4450'; for (let k = 0; k < 3; k++) g.fillRect(X + ts * (0.32 + k * 0.13), Y + ts * 0.36, Math.max(1, ts * 0.04), ts * 0.36); }
        break;
      case 'W':
        RR(g, X + 1, Y + 1, ts - 2, ts - 2, ts * 0.12, '#e3ae45'); RR(g, X + ts * 0.1, Y + ts * 0.1, ts * 0.8, ts * 0.8, ts * 0.1, '#2a1f2e');
        if (!thumb) {
          g.beginPath(); g.arc(cx, cy + ts * 0.1, ts * 0.22, Math.PI, 0); g.fillStyle = '#f2d27a'; g.fill();
          RR(g, cx - ts * 0.3, cy + ts * 0.1, ts * 0.6, ts * 0.07, ts * 0.03, '#c99030'); Ci(g, cx, cy - ts * 0.15, ts * 0.05, '#f2d27a');
          E(g, cx - ts * 0.08, cy - ts * 0.02, ts * 0.06, ts * 0.04, 'rgba(255,255,255,.6)');
        }
        break;
      case 'belt':
        if (S.dy) { g.fillStyle = '#26232c'; g.fillRect(X + ts * 0.08, Y, ts * 0.84, ts); g.fillStyle = '#8a8794'; g.fillRect(X + ts * 0.06, Y, Math.max(1, ts * 0.05), ts); g.fillRect(X + ts * 0.89, Y, Math.max(1, ts * 0.05), ts); }
        else { g.fillStyle = '#26232c'; g.fillRect(X, Y + ts * 0.08, ts, ts * 0.84); g.fillStyle = '#8a8794'; g.fillRect(X, Y + ts * 0.06, ts, Math.max(1, ts * 0.05)); g.fillRect(X, Y + ts * 0.89, ts, Math.max(1, ts * 0.05)); }
        break;
    }
  }
  const CSS = `
.ck-pick{position:absolute;inset:0;z-index:8;padding:10px 12px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,.35),rgba(23,19,31,.95) 30%);display:flex;flex-direction:column;gap:6px;overflow-y:auto;overscroll-behavior:contain;user-select:none;-webkit-user-select:none;touch-action:pan-y}
.ck-pick .sp{flex:1 1 0;min-height:0}
.ck-pick h3{margin:0;font-family:var(--f-display,"Black Han Sans"),sans-serif;font-weight:400;font-size:20px;color:var(--ink,#f2e9d8)}
.ck-pick .lb{font-size:12px;font-weight:700;color:var(--brass,#e3ae45);margin-top:2px}
.ck-pick .sub{font-size:12px;color:var(--muted,#ab9fb8);min-height:32px;line-height:1.35}
.ck-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(58px,1fr));gap:5px}
.ck-tk{appearance:none;border:1.5px solid rgba(242,233,216,.14);background:rgba(46,38,64,.92);color:var(--ink,#f2e9d8);border-radius:12px;padding:4px 2px 5px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;font:700 10.5px/1.15 "IBM Plex Sans KR",system-ui,sans-serif;min-height:54px;cursor:pointer;touch-action:manipulation;word-break:keep-all;text-align:center}
.ck-tk:active{transform:scale(.96)}
.ck-tk canvas{display:block}
.ck-tk.on{border-color:var(--brass,#e3ae45);background:rgba(227,174,69,.22)}
.ck-tk:disabled{opacity:.85;cursor:default}
.ck-tk.rec::after{content:'추천';position:absolute;top:2px;right:3px;font:800 9px/1 "IBM Plex Sans KR",system-ui,sans-serif;color:#17131f;background:var(--brass,#e3ae45);border-radius:6px;padding:2px 3px}
.ck-tk{position:relative}
.ck-pick .go{position:sticky;bottom:0;padding-top:6px;background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.97) 30%)}
.ck-tk .q{font-family:var(--f-display,"Black Han Sans"),sans-serif;font-size:22px;height:34px;display:grid;place-items:center;color:var(--brass,#e3ae45)}
`;
  const CKV = { pan: '팬에 굽기', fry: '튀김기에 튀기기', pot: '냄비', oven: '오븐', steam: '찜기', grill: '석쇠에 굽기', mix: '믹서에 갈기' };
  function howTo(c) {
    const s = SRC[c];
    if (!s) return '상자에서 꺼내 바로';
    if (isWork(s[0])) return nameOf(s[1]) + ' → ' + WKP[s[0]].n + '에서 ' + WKP[s[0]].v;
    if (isOne(s[0])) { const w = SRC[s[1]]; return (w ? nameOf(w[1]) + ' ' + (isWork(w[0]) ? WKP[w[0]].v : '') + ' → ' : nameOf(s[1]) + ' → ') + CKV[s[0]]; }
    const cnt = {}; for (const ch of s[1]) cnt[ch] = (cnt[ch] | 0) + 1;
    const sub = (ch) => { const q = SRC[ch]; return q && (q[0] === 'knead' || q[0] === 'grind') ? '(' + nameOf(q[1]) + ' ' + WKP[q[0]].v + ')' : ''; };
    return Object.keys(cnt).map((ch) => nameOf(ch) + sub(ch) + (cnt[ch] > 1 ? ' ' + cnt[ch] + '개' : '')).join(' + ') + ' → ' + CKV[s[0]];
  }

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const DPR = () => Math.min(2.5, cv.dpr || 1);
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    let st = null, key = null, tl = -3, endWait = 0, endSeen = false, hostT = 0, pick = null, pickRid = -1;
    let KS = [], mem = [], view = 0, lay = null, stat = null, statKey = '', prevK = null, prevKey = '';
    let parts = [], floats = [], ripples = [], tipBox = null, shake = 0, dispSc = 0, scPop = 0, lastBeep = 0;
    const remote = {}, cardT = {}, lastS = {};
    let pubT = 0, lastSig = '';

    const curKey = () => (st && st.km >= 0 ? st.rid + '.' + st.km + '.' + st.mn : null);
    function ensureMatch() {
      if (!st || st.ph === 'pick' || st.km < 0) return;
      const k = curKey();
      if (k === key) return;
      key = k;
      KS = []; mem = [];
      for (let s = 0; s < st.n; s++) { KS[s] = simHere(s) ? newKitchen(st.km, st.mn, st.sd, st.T, st.w) : null; mem[s] = {}; }
      const m = mine(), fst = KS.findIndex(Boolean);
      view = m.length ? m[0] : (fst >= 0 ? fst : 0);
      parts = []; floats = []; ripples = []; tipBox = null; dispSc = 0; endWait = 0; endSeen = false;
      for (const x in remote) delete remote[x];
      for (const x in cardT) delete cardT[x];
      tl = st.ph === 'done' ? st.T : -3;
      stat = null; layout();
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const hudH = 40, railH = Math.round(U.clamp(h * 0.125, 68, 100)), hintH = 30;
      const top = hudH + railH + 6, availH = h - top - hintH - 4, availW = w - 8;
      const ts = Math.max(18, Math.floor(Math.min(availW / GW, availH / GH)));
      const kw = ts * GW, kh = ts * GH;
      lay = { w, h, hudH, railH, hintH, ts, kw, kh, ox: Math.round((w - kw) / 2), oy: Math.round(top + Math.max(0, (availH - kh) * 0.3)), railY: hudH };
      stat = null;
    }
    cv.onresize = layout;
    function staticFor(K) {
      const sk = (K === prevK ? 'p' + prevKey : key + '.' + view) + '|' + lay.ts + '|' + DPR();
      if (stat && statKey === sk) return stat;
      const c = document.createElement('canvas'), d = DPR();
      c.width = Math.ceil(lay.kw * d); c.height = Math.ceil(lay.kh * d);
      const g = c.getContext('2d'); g.scale(d, d);
      drawStatic(g, K, lay.ts, false);
      stat = c; statKey = sk;
      return c;
    }

    /* ----- picker ----- */
    function thumbK(ki, w, h) {
      const c = L.h('canvas'), d = Math.min(2, window.devicePixelRatio || 1);
      c.width = w * d; c.height = h * d; c.style.width = w + 'px'; c.style.height = h + 'px';
      const g = c.getContext('2d'), ts = Math.min(w / GW, h / GH);
      g.scale(d, d); g.translate((w - ts * GW) / 2, (h - ts * GH) / 2);
      const K = newKitchen(ki, Math.max(0, KITCHENS[ki].mi), 1, 60, 1);
      drawStatic(g, K, ts, true);
      if (K.il) K.st.forEach((S) => { if (S.isl) drawStationBase(g, S, S.x * ts, S.y * ts, ts, true, K); });
      return c;
    }
    function thumbM(mi, w) {
      const c = L.h('canvas'), d = Math.min(2, window.devicePixelRatio || 1), s = w / 2;
      c.width = w * d; c.height = w * d; c.style.width = w + 'px'; c.style.height = w + 'px';
      const g = c.getContext('2d'); g.scale(d, d);
      (MENUS[mi].mix ? mixMenu(17) : MENUS[mi]).d.forEach((id, k) => { g.save(); g.translate((k % 2 + 0.5) * s, ((k / 2 | 0) + 0.5) * s); drawPlate(g, DISH[id].c, s * 0.95); g.restore(); });
      return c;
    }
    function buildPicker() {
      if (pick) return;
      const canPick = host() && (mine().length > 0 || !api.online);
      const sub = L.h('div', { class: 'sub' }), gk = L.h('div', { class: 'ck-grid' }), gm = L.h('div', { class: 'ck-grid' }), kb = [], mb = [];
      const set = (patch) => { if (!canPick || !st || st.ph !== 'pick') return; api.sfx('click'); const n = Object.assign({}, st, patch); try { localStorage.setItem('lounge.cooking.pick', JSON.stringify({ pk: n.pk, pm: n.pm })); } catch (e) {} api.setState(n); };
      const mk = (grid, arr, id, label, art, onPick) => {
        const b = L.h('button', { class: 'ck-tk', type: 'button', 'aria-label': label, disabled: !canPick }, art, L.h('span', { text: label }));
        b.onclick = onPick; arr.push({ id, b }); grid.append(b);
      };
      mk(gk, kb, -1, '무작위', L.h('div', { class: 'q', text: '?' }), () => set({ pk: -1 }));
      KITCHENS.forEach((K, i) => mk(gk, kb, i, K.n, thumbK(i, 34, 42), () => set({ pk: i })));
      mk(gm, mb, -1, '무작위', L.h('div', { class: 'q', text: '?' }), () => set({ pm: -1 }));
      MENUS.forEach((M, i) => mk(gm, mb, i, M.n, thumbM(i, 32), () => set({ pm: i })));
      const go = L.h('button', { class: 'btn primary block', text: '시작', onclick() { if (!st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(15); api.setState(startMatch(st)); } });
      const el = L.h('div', { class: 'ck-pick' }, L.h('div', { class: 'sp' }), L.h('h3', { text: '주방과 메뉴 고르기' }), sub,
        L.h('div', { class: 'lb', text: '주방 ' + KITCHENS.length + '곳' }), gk, L.h('div', { class: 'lb', text: '메뉴 ' + (MENUS.length - 1) + '가지 + 섞어 차림' }), gm,
        L.h('div', { class: 'go' }, canPick ? go : L.h('div', { class: 'sub', text: '호스트가 고르는 중…' })));
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el, sub, kb, mb };
      syncPicker();
    }
    function syncPicker() {
      if (!pick || !st) return;
      pick.kb.forEach(({ id, b }) => b.classList.toggle('on', id === st.pk));
      pick.mb.forEach(({ id, b }) => { b.classList.toggle('on', id === st.pm); b.classList.toggle('rec', st.pk >= 0 && id === KITCHENS[st.pk].mi); });
      const kt = st.pk >= 0 ? KITCHENS[st.pk].n + ' — ' + KITCHENS[st.pk].sub : '무작위 주방 — 시작할 때 정해져요';
      const mt = st.pm < 0 ? '무작위 메뉴' : MENUS[st.pm].mix ? '섞어 차림: 모든 메뉴에서 네 가지를 골라 섞어요(판마다 달라요)' : MENUS[st.pm].n + ': ' + MENUS[st.pm].d.map((d) => DISH[d].n).join(', ');
      pick.sub.textContent = kt + ' · ' + mt;
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } }
    function hostPickFlow(rdt) {
      if (!host() || !st || st.ph !== 'pick') return;
      if (pickRid !== st.rid) {
        pickRid = st.rid; hostT = 0;
        if (mine().length) {
          let sv = null; try { sv = JSON.parse(localStorage.getItem('lounge.cooking.pick') || 'null'); } catch (e) { sv = null; }
          if (sv && (sv.pk !== st.pk || sv.pm !== st.pm)) {
            const pk = sv.pk >= -1 && sv.pk < KITCHENS.length ? sv.pk | 0 : -1, pm = sv.pm >= -1 && sv.pm < MENUS.length ? sv.pm | 0 : -1;
            api.setState(Object.assign({}, st, { pk, pm })); return;
          }
        }
      }
      if (!mine().length || auto()) { hostT += rdt * SPD(); if (hostT > 1.2) { hostT = -1e9; api.setState(startMatch(st)); } }
    }

    /* ----- input ----- */
    const chefPos = (K) => { const C = K.ch, a = C.ti, b = C.ni >= 0 ? C.ni : C.ti; return { x: tx(a) + (tx(b) - tx(a)) * C.u + 0.5, y: ty(a) + (ty(b) - ty(a)) * C.u + 0.5 }; };
    const islX = (K) => K.il.p + (K.il.q - K.il.p) * K.il.f;
    const stPos = (K, S) => (S.isl ? { x: islX(K) + S.isl - 1, y: S.y } : { x: S.x, y: S.y });
    function stationAtF(K, fx, fy) {
      if (K.il) for (let si = 0; si < K.st.length; si++) { const S = K.st[si]; if (!S.isl) continue; const p = stPos(K, S); if (fx >= p.x && fx < p.x + 1 && fy >= p.y && fy < p.y + 1) return si; }
      const i = (fy | 0) * GW + (fx | 0);
      return K.at[i];
    }
    const canCtl = () => isMine(view) && !auto() && !!KS[view];
    function cardAt(x) { const n = MAX_ORD, cw = (lay.w - 16 - (n - 1) * 6) / n; const i = Math.floor((x - 8) / (cw + 6)); return i >= 0 && i < n ? i : -1; }
    function onDown(e) {
      if (!st || !lay) return;
      const p = cv.local(e);
      e.preventDefault();
      const hadTip = tipBox ? tipBox.d : null; tipBox = null;
      const K = KS[view];
      if (p.y >= lay.railY && p.y < lay.railY + lay.railH) {
        const i = cardAt(p.x);
        if (K && i >= 0 && K.ord[i] && !(hadTip && hadTip === K.ord[i].d)) { tipBox = { d: K.ord[i].d, t: 6 }; tipIdx = i; api.sfx('click'); }
        return;
      }
      if (p.y < lay.hudH) { if (!mine().length && key) { const idx = KS.map((k, s) => (k ? s : -1)).filter((s) => s >= 0); if (idx.length > 1) { view = idx[(idx.indexOf(view) + 1) % idx.length]; stat = null; api.sfx('click'); } } return; }
      if (hadTip) return;
      if (!K || !canCtl() || tl < 0 || tl >= st.T) return;
      const fx = (p.x - lay.ox) / lay.ts, fy = (p.y - lay.oy) / lay.ts;
      if (fx < 0 || fy < 0 || fx >= GW || fy >= GH) return;
      if (K.mo && K.mo.st !== 'flee' && Math.hypot(fx - K.mo.x, fy - K.mo.y) < 0.8) { shoo(K); api.buzz(15); return; }
      const C = K.ch, cp = chefPos(K);
      if (Math.hypot(fx - cp.x, fy - cp.y) < 0.4 && (C.q.length || C.cur || C.work)) { cancelK(K); floats.push({ x: cp.x, y: cp.y - 0.6, text: '예약 취소', col: '#f2e9d8', t: 0.9, T: 0.9 }); api.sfx('click'); return; }
      const si = stationAtF(K, fx, fy);
      let r = null, rx = Math.floor(fx) + 0.5, ry = Math.floor(fy) + 0.5;
      if (si >= 0) { r = tapK(K, { s: si }); const q = stPos(K, K.st[si]); rx = q.x + 0.5; ry = q.y + 0.5; }
      else { const i = (fy | 0) * GW + (fx | 0); if (K.g[i] === '.' || K.g[i] === '~' || K.g[i] === '=' || K.g[i] === '|') r = tapK(K, { f: i }); }
      tapFx(r, rx, ry);
    }
    function tapFx(r, rx, ry) {
      if (!r) return;
      ripples.push({ x: rx, y: ry, t: 0.35, T: 0.35, col: r === 'boost' ? '#ffe08a' : Pl(view).color });
      if (r === 'boost') { api.buzz(6); } else { api.sfx('click'); api.buzz(8); }
    }
    cv.cv.addEventListener('pointerdown', onDown);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- keyboard / gamepad (api.input, rebindable in 「⌨ 조작 설정」) -----
       ↑↓←→ (WASD, left stick) walk one tile per press, holding keeps walking (ice still slides);
       작업 = the same as tapping the station the chef faces (again while chopping = 연타); 연타 = boost the current work only;
       주문 = show the next order ticket's recipe (cycles, then closes). Touch stays exactly as it is. */
    const KDIR = { down: 0, left: 1, right: 2, up: 3 };
    let kbT = null, kbUsed = false, kbLast = null, tipIdx = -1;
    const kbReady = () => !!st && !!lay && canCtl() && tl >= 0 && tl < st.T;
    function kbStep(d) {
      const K = KS[view], C = K.ch;
      let base = C.ni >= 0 ? C.ni : C.ti;
      if (C.cur && C.cur === kbT && C.cur.f != null) base = C.cur.f;
      const m = moveFrom(K, base, d);
      if (!m) { if (C.ni < 0 && !C.cur && !C.q.length && !C.work) C.dir = d; return false; }
      tapK(K, { f: m[0] }); kbT = C.cur;
      return true;
    }
    function heldDir() {
      if (kbLast && api.input.held(kbLast)) return KDIR[kbLast];
      for (const id in KDIR) if (api.input.held(id)) return KDIR[id];
      return -1;
    }
    function kbTick() { // keep walking while a direction is held
      if (!api.input || !kbReady()) return;
      const d = heldDir(); if (d < 0) return;
      const C = KS[view].ch;
      if (C.work || C.q.length) return;
      if ((!C.cur && C.ni < 0) || (C.cur && C.cur === kbT && C.ni === C.cur.f && C.u > 0.85 && !C.sl)) kbStep(d);
    }
    const facedTile = (K) => { const C = K.ch; return nb(C.ni >= 0 ? C.ni : C.ti, C.dir); };
    function kbAct(onlyBoost) {
      const K = KS[view], C = K.ch;
      if (onlyBoost) {
        if (!C.work) return;
        const q = stPos(K, K.st[C.work.s]);
        tapFx(tapK(K, { s: C.work.s }), q.x + 0.5, q.y + 0.5);
        return;
      }
      const i = facedTile(K);
      if (i < 0) return;
      const fx = tx(i) + 0.5, fy = ty(i) + 0.5;
      if (K.mo && K.mo.st !== 'flee' && Math.hypot(fx - K.mo.x, fy - K.mo.y) < 0.9) { shoo(K); api.buzz(15); return; }
      const si = stationAtF(K, fx, fy);
      if (si == null || si < 0) { const p = chefPos(K); floats.push({ x: p.x, y: p.y - 0.75, text: '조리대 쪽을 보고 눌러요', col: '#ffd0c4', t: 1.1, T: 1.1, bub: 1 }); api.sfx('click'); return; }
      const q = stPos(K, K.st[si]);
      tapFx(tapK(K, { s: si }), q.x + 0.5, q.y + 0.5);
    }
    function kbOrder() {
      const K = KS[view];
      if (!K || !st || st.ph === 'pick' || tl >= st.T) return;
      tipIdx = tipBox ? tipIdx + 1 : 0;
      if (tipIdx >= K.ord.length) { tipBox = null; tipIdx = -1; api.sfx('click'); return; }
      tipBox = { d: K.ord[tipIdx].d, t: 6 }; api.sfx('click');
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'order') { kbOrder(); return; }
      if (!kbReady()) return;
      kbUsed = true;
      if (id in KDIR) { kbLast = id; kbStep(KDIR[id]); }
      else if (id === 'act') kbAct(false);
      else if (id === 'boost') kbAct(true);
    }) : () => {};

    /* ----- effects ----- */
    const lastSfx = {};
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function burst(x, y, col, n, sp, kind, life) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.35 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * 0.3, t: life || 0.5, T: life || 0.5, c: col, k: kind || 'dot', r: 0.05 + Math.random() * 0.05 }); }
      if (parts.length > 260) parts.splice(0, parts.length - 260);
    }
    function stCenter(K, si) { const S = K.st[si]; if (!S) return chefPos(K); const p = stPos(K, S); return { x: p.x + 0.5, y: p.y + 0.5 }; }
    function onEvents(K) {
      const C = K.ch, me = isMine(view) || !mine().length;
      for (const e of K.ev) {
        const c = e.s != null && e.s >= 0 ? stCenter(K, e.s) : chefPos(K), S = e.s >= 0 ? K.st[e.s] : null;
        switch (e.k) {
          case 'pick': case 'put': case 'plate': sfx(e.k === 'pick' ? 'tick' : 'card', 40); burst(c.x, c.y, '#fff3cf', 4, 1.2, 'dot', 0.3); break;
          case 'cook': sfx('roll', 40); burst(c.x, c.y, '#fff3cf', 5, 1.2, 'dot', 0.3); break;
          case 'trash': sfx('thud', 40); burst(c.x, c.y, '#8a8794', 6, 1.4, 'dot', 0.4); break;
          case 'boost': if (S && S.ty === 'B') { sfx('tick', 30); burst(c.x, c.y - 0.05, IT[S.th] ? IT[S.th][1] : '#fff', 3, 1.6, 'bit', 0.35); } else if (S && S.ty === 'S') burst(c.x, c.y, '#bfe8ff', 3, 1.4, 'dot', 0.35); break;
          case 'chopped': sfx('pop', 30); burst(c.x, c.y, IT[S && S.th] ? IT[S.th][1] : '#fff', 9, 2, 'bit', 0.45); if (me) api.buzz(12); break;
          case 'done': sfx('pop', 50); burst(c.x, c.y - 0.2, '#9fe8a8', 8, 1.5, 'star', 0.6); if (me) api.buzz(12); break;
          case 'warn': sfx('tick', 50); break;
          case 'burn': sfx('thud', 50); burst(c.x, c.y, '#5a5050', 10, 0.8, 'smoke', 1.2); floats.push({ x: c.x, y: c.y - 0.5, text: '탔어요!', col: '#ff9a7a', t: 1.2, T: 1.2 }); if (me) api.buzz(30); break;
          case 'fire': sfx('whoosh', 50); floats.push({ x: c.x, y: c.y - 0.6, text: '불이야! 눌러서 꺼요', col: '#ffb04a', t: 1.8, T: 1.8 }); shake = Math.min(1, shake + 0.5); if (me) api.buzz([40, 40, 60]); break;
          case 'out': sfx('whoosh', 50); burst(c.x, c.y, '#e8f0f4', 14, 1.4, 'steam', 0.9); break;
          case 'ext': sfx('whoosh', 80); break;
          case 'serve': {
            const D = DISH[e.d];
            sfx('win', 80); setTimeout(() => api.sfx('chip'), 120);
            burst(c.x, c.y, '#ffd86a', 12, 2.4, 'coin', 0.8);
            floats.push({ x: c.x, y: c.y - 0.4, text: '+' + D.pts, col: '#ffe08a', t: 1.3, T: 1.3, big: 1 });
            if (e.tip > 0) floats.push({ x: c.x, y: c.y + 0.1, text: '팁 +' + e.tip, col: '#9fe8a8', t: 1.5, T: 1.5 });
            scPop = 1; if (me) api.buzz(30);
            break;
          }
          case 'expire': sfx('lose', 80); floats.push({ x: GW / 2, y: -0.4, text: DISH[e.d].n + ' 주문 놓침 −10', col: '#ff8a7a', t: 1.8, T: 1.8, rail: 1 }); if (me) api.buzz(40); break;
          case 'order': sfx('bounce', 60); break;
          case 'fail': { sfx('hit', 80); const p = chefPos(K); if (e.why) floats.push({ x: p.x, y: p.y - 0.75, text: e.why, col: '#ffd0c4', t: 1.4, T: 1.4, bub: 1 }); if (me) api.buzz(25); break; }
          case 'warn2': floats.push({ x: c.x, y: c.y - 0.5, text: '주문에 없는 요리예요', col: '#ffd0c4', t: 1.2, T: 1.2, bub: 1 }); break;
          case 'washed': sfx('bounce', 40); burst(c.x, c.y, '#bfe8ff', 8, 1.6, 'dot', 0.5); break;
          case 'ret': sfx('tick', 100); break;
          case 'door': sfx('roll', 100); break;
          case 'isl': sfx('roll', 150); break;
          case 'mouse': sfx('chip', 100); if (K.mo) floats.push({ x: K.mo.x, y: K.mo.y - 0.5, text: '쥐다! 톡 눌러요', col: '#f2e9d8', t: 1.6, T: 1.6 }); break;
          case 'steal': sfx('thud', 80); floats.push({ x: c.x, y: c.y - 0.5, text: '쥐가 물어 가요!', col: '#ff9a7a', t: 1.4, T: 1.4 }); if (me) api.buzz(30); break;
          case 'shoo': sfx('pop', 60); if (K.mo) floats.push({ x: K.mo.x, y: K.mo.y - 0.4, text: '찍!', col: '#f2e9d8', t: 0.9, T: 0.9 }); break;
          case 'fuel': sfx('thud', 60); burst(c.x, c.y, '#ffb02e', 12, 1.8, 'dot', 0.5); break;
          case 'fireout': if (me) { sfx('lose', 200); floats.push({ x: c.x, y: c.y - 0.6, text: '모닥불이 꺼졌어요', col: '#ffd0c4', t: 1.4, T: 1.4 }); } break;
          case 'tp': { sfx('whoosh', 80); const a = { x: tx(e.a) + 0.5, y: ty(e.a) + 0.5 }, b = { x: tx(e.b) + 0.5, y: ty(e.b) + 0.5 }; burst(a.x, a.y, '#c8a0ff', 10, 1.6, 'star', 0.5); burst(b.x, b.y, '#f2e0ff', 10, 1.6, 'star', 0.5); break; }
          case 'heatW': floats.push({ x: GW / 2, y: -0.4, text: '곧 불이 ' + (e.lv > 1.2 ? '세져요! (강불)' : e.lv < 0.8 ? '약해져요 (약불)' : '보통이 돼요 (중불)'), col: '#ffd08a', t: 1.8, T: 1.8, rail: 1 }); sfx('tick', 100); break;
          case 'heat': sfx('whoosh', 100); burst(GW / 2, GH / 2, e.lv > 1.2 ? '#ff7a2a' : e.lv < 0.8 ? '#6ab0ff' : '#ffb02e', 14, 3, 'dot', 0.6); break;
          case 'lurchW': floats.push({ x: GW / 2, y: -0.4, text: '덜컹! 곧 흔들려요', col: '#ffd08a', t: 1.3, T: 1.3, rail: 1 }); sfx('tick', 100); break;
          case 'lurch': sfx('thud', 100); shake = Math.min(1, shake + 0.8); if (me) api.buzz(40); break;
          case 'float': { sfx('whoosh', 150); const p = stCenter(K, e.s); floats.push({ x: p.x, y: p.y - 0.5, text: '둥실~', col: '#cfe8ff', t: 1.1, T: 1.1 }); break; }
        }
      }
      K.ev.length = 0;
    }
    function ambient(K, rdt) { // steam, sizzle, smoke, fire sparks; warning beeps
      let warn = false;
      for (const si of K.heats) {
        const S = K.st[si], c = stCenter(K, si);
        if (S.fire) { if (Math.random() < rdt * 14) parts.push({ x: c.x + (Math.random() - 0.5) * 0.5, y: c.y - 0.1, vx: (Math.random() - 0.5) * 0.4, vy: -1.4 - Math.random(), t: 0.6, T: 0.6, c: Math.random() < 0.5 ? '#ffb02e' : '#ff5a2a', k: 'flame', r: 0.12 }); continue; }
        if (S.fu === 0) continue;
        if (cooking(K, S)) {
          if (S.ck === 'mix') continue;
          if (isOne(S.ck) && Math.random() < rdt * 10) parts.push({ x: c.x + (Math.random() - 0.5) * 0.4, y: c.y - 0.05, vx: (Math.random() - 0.5) * 1.2, vy: -0.8 - Math.random() * 0.6, t: 0.3, T: 0.3, c: '#fff6d0', k: 'dot', r: 0.03 });
          if (!isOne(S.ck) && Math.random() < rdt * 4) parts.push({ x: c.x + (Math.random() - 0.5) * 0.3, y: c.y - 0.2, vx: (Math.random() - 0.5) * 0.2, vy: -0.5, t: 1.1, T: 1.1, c: '#f2f6f8', k: 'steam', r: 0.1 });
        } else if (S.cr === 'x') { if (Math.random() < rdt * 5) parts.push({ x: c.x + (Math.random() - 0.5) * 0.3, y: c.y - 0.2, vx: (Math.random() - 0.5) * 0.2, vy: -0.45, t: 1.3, T: 1.3, c: '#4a4040', k: 'smoke', r: 0.12 }); }
        else if (S.cr && !CKP[S.ck].nob && S.cp >= CKP[S.ck].safe) { warn = true; if (Math.random() < rdt * 3) parts.push({ x: c.x, y: c.y - 0.2, vx: (Math.random() - 0.5) * 0.2, vy: -0.4, t: 1, T: 1, c: '#7a7070', k: 'smoke', r: 0.08 }); }
      }
      if (warn && (isMine(view) || !mine().length)) { lastBeep -= rdt; if (lastBeep <= 0) { lastBeep = 0.45; api.sfx('tick'); } }
    }

    /* ----- online ----- */
    function scoreRow(s) {
      if (st && st.ph === 'done' && Array.isArray(st.res)) { const r = st.res.find((x) => x[0] === s); if (r) return [r[1], r[2], r[3]]; }
      const K = KS[s]; if (K) return [K.sc, K.sv, K.ex];
      const r = remote[s]; return r ? [r.sc, r.sv, r.ex] : [0, 0, 0];
    }
    function pollNet() {
      if (!api.online || !key) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) { const s = +k, o = rem[k]; if (!(s >= 0 && s < st.n) || KS[s] || !o || o.k !== key) continue; remote[s] = { sc: o.sc | 0, sv: o.sv | 0, ex: o.ex | 0, f: o.f | 0 }; }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key) return;
        if (typeof hs.t === 'number' && isFinite(hs.t) && st.ph === 'play') { const d = hs.t - tl; if (Math.abs(d) > 0.6) tl = hs.t; else tl += d * 0.05; }
        if (Array.isArray(hs.s)) hs.s.forEach((a, s) => { if (KS[s] || !Array.isArray(a)) return; remote[s] = { sc: a[0] | 0, sv: a[1] | 0, ex: a[2] | 0, f: 0 }; });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.25;
          const s = []; for (let i = 0; i < st.n; i++) s.push(scoreRow(i));
          api.net.hostSend({ k: key, t: Math.round(tl * 100) / 100, s });
        } else {
          const m = mine()[0], K = m != null ? KS[m] : null;
          if (!K) return;
          const f = K.t >= K.T - 1e-6 ? 1 : 0, sig = K.sc + '|' + K.sv + '|' + K.ex + '|' + f;
          if (sig === lastSig && pubT > 0) return;
          lastSig = sig; pubT = 0.5;
          api.net.publish({ k: key, sc: K.sc, sv: K.sv, ex: K.ex, f });
        }
      } catch (e) {}
    }
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play' || tl < st.T) return;
      endWait += rdt;
      let ready = true;
      if (api.online) for (let s = 0; s < st.n; s++) if (!KS[s] && !(remote[s] && remote[s].f)) ready = false;
      if ((ready && endWait > 1.3) || endWait > 4.5) {
        const rows = []; for (let s = 0; s < st.n; s++) { const r = scoreRow(s); rows.push([s, r[0], r[1], r[2]]); }
        endWait = -1e9;
        api.setState(finish(st, rows));
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) { draw(now); return; }
      const dt = rdt * SPD();
      if (st.ph === 'pick') { if (!pick) buildPicker(); hostPickFlow(rdt); } else if (pick) dropPicker();
      ensureMatch();
      if (key && st.ph !== 'pick') {
        const was = tl;
        if (st.ph === 'play') tl += dt;
        pollNet();
        if (was < 0) { const a = Math.ceil(-was), b = Math.ceil(-tl); if (tl < 0 && a !== b) api.sfx('tick'); if (tl >= 0) { api.sfx('pop'); api.buzz(20); } }
        const target = U.clamp(tl, 0, st.T);
        kbTick();
        KS.forEach((K, s) => {
          if (!K) return;
          const p = api.players[s], bot = p && (p.ai || (auto() && isMine(s)));
          let n = 0;
          while (K.t < target - 1e-6 && n < 240) { const h = Math.min(1 / 30, target - K.t); if (bot) aiThink(K, mem[s], p.ai ? (p.lv || 2) : 2, h); stepK(K, h); n++; }
          if (s !== view) K.ev.length = 0;
          if (lastS[s] != null && K.sc > lastS[s] && s !== view) floats.push({ hud: s, text: '+' + (K.sc - lastS[s]), col: '#ffe08a', t: 1.2, T: 1.2 });
          lastS[s] = K.sc;
        });
        for (const s in remote) { const r = remote[s]; if (lastS[s] != null && r.sc > lastS[s]) floats.push({ hud: +s, text: '+' + (r.sc - lastS[s]), col: '#ffe08a', t: 1.2, T: 1.2 }); lastS[s] = r.sc; }
        if (was >= st.T - 5 && was < st.T && Math.ceil(st.T - was) !== Math.ceil(st.T - tl) && tl < st.T) api.sfx('tick');
        if (tl >= st.T && !endSeen) { endSeen = true; api.sfx('whoosh'); api.buzz([30, 40, 30]); tipBox = null; }
        hostEnd(rdt);
        const K = KS[view];
        if (K) { onEvents(K); if (tl >= 0 && tl < st.T) ambient(K, rdt); }
      }
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; if (q.k === 'coin' || q.k === 'bit') q.vy += 5 * rdt; else { q.vx *= 0.96; q.vy *= 0.97; } if (q.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      for (let i = ripples.length - 1; i >= 0; i--) { ripples[i].t -= rdt; if (ripples[i].t <= 0) ripples.splice(i, 1); }
      if (tipBox) { tipBox.t -= rdt; if (tipBox.t <= 0) tipBox = null; }
      shake = Math.max(0, shake - rdt * 2.5); scPop = Math.max(0, scPop - rdt * 2.5);
      publish(rdt);
      draw(now);
    }
    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function ring(x, y, r, f, col, w) { ctx.beginPath(); ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + TAU * U.clamp(f, 0, 1)); ctx.strokeStyle = col; ctx.lineWidth = w || 3; ctx.lineCap = 'round'; ctx.stroke(); }
    function ringBg(x, y, r, w) { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.strokeStyle = 'rgba(20,14,24,.55)'; ctx.lineWidth = (w || 3) + 2; ctx.stroke(); }
    function badge(x, y, r, col, glyph) {
      Ci(ctx, x, y, r + 1.5, 'rgba(20,14,24,.6)'); Ci(ctx, x, y, r, col);
      if (glyph === 'ok') LN(ctx, [x - r * 0.45, y, x - r * 0.1, y + r * 0.38, x + r * 0.5, y - r * 0.4], '#fff', Math.max(1.5, r * 0.28));
      else if (glyph) txt(glyph, x, y + 0.5, '#fff', '800 ' + Math.round(r * 1.4) + 'px ' + FONT);
    }
    function drawChef(K, x, y, ts, col, now) {
      const C = K.ch, d = C.dir, moving = C.ni >= 0, work = C.work, s = ts;
      const bob = moving ? Math.abs(Math.sin(C.wk * 13)) * s * 0.05 : 0;
      const sliding = moving && (K.g[C.ni] === '~' || K.g[C.ti] === '~');
      E(ctx, x, y + s * 0.32, s * 0.3, s * 0.1, 'rgba(30,15,20,.28)');
      const by = y - bob + s * 0.06;
      // feet
      if (!sliding) { const ph = moving ? Math.sin(C.wk * 13) : 0; E(ctx, x - s * 0.11, by + s * 0.25 + ph * s * 0.03, s * 0.07, s * 0.05, '#3a2a30'); E(ctx, x + s * 0.11, by + s * 0.25 - ph * s * 0.03, s * 0.07, s * 0.05, '#3a2a30'); }
      // body (coat) + apron
      E(ctx, x, by + s * 0.08, s * 0.24, s * 0.22, '#f4efe6');
      ctx.save(); ctx.beginPath(); ctx.ellipse(x, by + s * 0.08, s * 0.24, s * 0.22, 0, 0, TAU); ctx.clip();
      ctx.fillStyle = col; ctx.fillRect(x - s * (d === 3 ? 0.05 : 0.17), by + s * 0.06, s * (d === 3 ? 0.1 : 0.34), s * 0.3);
      ctx.restore();
      if (d !== 3) { Ci(ctx, x, by + s * 0.0, s * 0.025, '#c9bfae'); Ci(ctx, x, by + s * 0.08, s * 0.025, '#c9bfae'); }
      // arms / hands
      const hold = !!C.h, wkA = work ? Math.sin(C.wk * (work.k === 'chop' ? 30 : 18)) : 0;
      const hx = d === 1 ? -0.16 : d === 2 ? 0.16 : 0, hy = d === 3 ? -0.12 : 0.06;
      const handY = by + s * (hold ? hy : 0.12) + (work ? wkA * s * 0.06 : 0);
      Ci(ctx, x - s * 0.22 + (hold ? s * (0.07 + hx) : 0), handY, s * 0.06, '#f2c9a0');
      Ci(ctx, x + s * 0.22 + (hold ? s * (-0.07 + hx) : 0), handY - (work ? wkA * s * 0.08 : 0), s * 0.06, '#f2c9a0');
      // head
      const hyy = by - s * 0.22;
      Ci(ctx, x, hyy, s * 0.17, '#f2c9a0');
      if (d === 3) Ci(ctx, x, hyy + s * 0.02, s * 0.16, '#5a3a2a');
      else {
        const ex = d === 1 ? -0.05 : d === 2 ? 0.05 : 0;
        const blink = (now / 1000 + view) % 3.7 < 0.12;
        if (blink) { LN(ctx, [x + s * (ex - 0.09), hyy + s * 0.02, x + s * (ex - 0.03), hyy + s * 0.02], '#2a1a1a', 1.5); LN(ctx, [x + s * (ex + 0.03), hyy + s * 0.02, x + s * (ex + 0.09), hyy + s * 0.02], '#2a1a1a', 1.5); }
        else { Ci(ctx, x + s * (ex - 0.06), hyy + s * 0.02, s * 0.028, '#2a1a1a'); Ci(ctx, x + s * (ex + 0.06), hyy + s * 0.02, s * 0.028, '#2a1a1a'); }
        E(ctx, x + s * (ex - 0.1), hyy + s * 0.07, s * 0.035, s * 0.022, 'rgba(240,120,110,.55)'); E(ctx, x + s * (ex + 0.1), hyy + s * 0.07, s * 0.035, s * 0.022, 'rgba(240,120,110,.55)');
        if (C.fail > 0) LN(ctx, [x + s * (ex - 0.04), hyy + s * 0.1, x + s * ex, hyy + s * 0.08, x + s * (ex + 0.04), hyy + s * 0.1], '#2a1a1a', 1.2);
        else { ctx.beginPath(); ctx.arc(x + s * ex, hyy + s * 0.07, s * 0.035, 0.2, Math.PI - 0.2); ctx.strokeStyle = '#2a1a1a'; ctx.lineWidth = 1.2; ctx.stroke(); }
      }
      // hat
      RR(ctx, x - s * 0.15, hyy - s * 0.2, s * 0.3, s * 0.1, s * 0.03, '#ffffff');
      ctx.fillStyle = col; ctx.fillRect(x - s * 0.15, hyy - s * 0.13, s * 0.3, s * 0.035);
      Ci(ctx, x - s * 0.09, hyy - s * 0.25, s * 0.09, '#ffffff'); Ci(ctx, x + s * 0.09, hyy - s * 0.25, s * 0.09, '#ffffff'); Ci(ctx, x, hyy - s * 0.3, s * 0.1, '#ffffff');
      E(ctx, x - s * 0.04, hyy - s * 0.32, s * 0.05, s * 0.03, 'rgba(230,220,210,.9)');
      // held thing
      if (C.h) {
        const ix = x + s * (d === 1 ? -0.2 : d === 2 ? 0.2 : 0), iy = d === 3 ? hyy - s * 0.42 : by + s * 0.02;
        const spr = thingSprite(C.h, s * (isPlate(C.h) || isDirty(C.h) ? 0.6 : 0.52), DPR());
        if (spr) blit(ctx, spr, ix, iy);
        if (isDirty(C.h) && dn(C.h) > 1) badge(ix + s * 0.22, iy - s * 0.1, s * 0.1, '#7d8794', String(dn(C.h)));
      }
      if (work && work.k === 'chop') { // knife flash
        const S = K.st[work.s], p = stPos(K, S), kx = lay.ox + (p.x + 0.5) * ts, ky = lay.oy + (p.y + 0.5) * ts;
        ctx.save(); ctx.translate(kx + ts * 0.18, ky - ts * 0.05 - Math.abs(wkA) * ts * 0.12); ctx.rotate(-0.5 + wkA * 0.3);
        RR(ctx, -ts * 0.03, -ts * 0.18, ts * 0.06, ts * 0.2, ts * 0.02, '#e6ebf0'); RR(ctx, -ts * 0.03, 0, ts * 0.06, ts * 0.12, ts * 0.02, '#4a2c18'); ctx.restore();
      }
      if (C.cur && C.wait > 0.4) txt('…', x, hyy - s * 0.5, '#f2e9d8', '800 ' + Math.round(s * 0.3) + 'px ' + FONT);
    }
    function drawDoor(K, i, k, ts) {
      const X = lay.ox + tx(i) * ts, Y = lay.oy + ty(i) * ts, D = K.dr, open = doorOpen(K, i);
      const a = Math.min(1, D.t / 0.25), op = open ? a : 1 - a; // 1 = fully open
      const warn = open && D.t > DOOR_P - 1.3 && Math.floor(D.t * 6) % 2 === 0;
      const w = ts * (1 - op * 0.82);
      RR(ctx, X + 1, Y + ts * 0.1, w - 2, ts * 0.8, ts * 0.06, '#8a5a32');
      ctx.fillStyle = '#e3ae45'; for (let s = 0; s < 3; s++) ctx.fillRect(X + 1, Y + ts * (0.2 + s * 0.25), Math.max(0, w - 2), Math.max(1, ts * 0.06));
      RR(ctx, X + ts * 0.82, Y + ts * 0.1, ts * 0.17, ts * 0.8, ts * 0.04, '#5a3a24');
      if (warn) { rrect(ctx, X + 2, Y + 2, ts - 4, ts - 4, ts * 0.1); ctx.strokeStyle = '#ffb04a'; ctx.lineWidth = 3; ctx.stroke(); }
      if (!open && op < 0.05) { Ci(ctx, X + ts * 0.5, Y + ts * 0.5, ts * 0.12, 'rgba(20,14,24,.5)'); LN(ctx, [X + ts * 0.42, Y + ts * 0.5, X + ts * 0.58, Y + ts * 0.5], '#ff8a7a', 2); }
    }
    function flame(x, y, h, w, col) { ctx.beginPath(); ctx.moveTo(x - w, y); ctx.quadraticCurveTo(x - w * 1.1, y - h * 0.4, x, y - h); ctx.quadraticCurveTo(x + w * 1.1, y - h * 0.4, x + w, y); ctx.closePath(); ctx.fillStyle = col; ctx.fill(); }
    function contents(S, cx, cy, ts, dpr, r) { // loose things inside a recipe cooker
      const n = S.cc.length;
      for (let k = 0; k < n; k++) { const a = -Math.PI / 2 + k / Math.max(1, n) * TAU; blit(ctx, thingSprite(S.cc[k], ts * 0.32, dpr), cx + (n > 1 ? Math.cos(a) * r * 0.42 : 0), cy + (n > 1 ? Math.sin(a) * r * 0.42 : 0)); }
    }
    function drawCookware(K, S, cx, cy, ts, now) {
      const r = ts * 0.34, dpr = DPR(), P = CKP[S.ck], ckg = cooking(K, S);
      // fire under it: a campfire (size = fuel left) or the night-market burner (size = flame level)
      if (S.fu != null) {
        if (S.fu > 0) { const f = 0.35 + 0.65 * S.fu, t = now / 110; for (let k = 0; k < 5; k++) flame(cx + (k - 2) * ts * 0.1, cy + ts * 0.3, ts * f * (0.42 + 0.12 * Math.sin(t + k * 1.9)), ts * 0.07, k % 2 ? '#ff7a2a' : '#ffc24a'); }
        LN(ctx, [cx - ts * 0.3, cy + ts * 0.3, cx + ts * 0.3, cy + ts * 0.2], '#5a3418', ts * 0.09); LN(ctx, [cx - ts * 0.3, cy + ts * 0.2, cx + ts * 0.3, cy + ts * 0.3], '#6a4020', ts * 0.09);
      } else if (K.nv && !P.nob && S.ck !== 'oven') {
        const n = 10, L0 = ts * (0.03 + 0.06 * K.heat), col = K.heat > 1.2 ? '#ff5a2a' : K.heat < 0.8 ? '#6ab0ff' : '#ffb02e';
        for (let k = 0; k < n; k++) { const a = k / n * TAU + now / 900, fl = L0 * (0.8 + 0.3 * Math.sin(now / 70 + k)); LN(ctx, [cx + Math.cos(a) * r * 1.02, cy + Math.sin(a) * r * 1.02, cx + Math.cos(a) * (r * 1.02 + fl), cy + Math.sin(a) * (r * 1.02 + fl)], col, Math.max(1.5, ts * 0.05)); }
      }
      if (S.ck === 'pan' || S.ck === 'fry') {
        if (S.ck === 'pan') {
          LN(ctx, [cx + r * 0.6, cy + r * 0.6, cx + r * 1.12, cy + r * 1.12], '#2a2a30', ts * 0.09);
          Ci(ctx, cx, cy, r, '#24242a'); Ci(ctx, cx, cy, r * 0.85, ckg ? '#4a3a34' : '#3a3a42'); E(ctx, cx - r * 0.35, cy - r * 0.4, r * 0.3, r * 0.12, 'rgba(255,255,255,.12)');
        } else {
          RR(ctx, cx - r * 1.05, cy - r * 0.95, r * 2.1, r * 1.9, r * 0.25, '#5d6875'); RR(ctx, cx - r * 0.88, cy - r * 0.78, r * 1.76, r * 1.56, r * 0.2, ckg ? '#e0a030' : '#c8902a');
          for (let k = 0; k < 4; k++) LN(ctx, [cx - r * 0.65 + k * r * 0.43, cy - r * 0.7, cx - r * 0.65 + k * r * 0.43, cy + r * 0.7], 'rgba(60,60,70,.45)', Math.max(1, ts * 0.025));
          LN(ctx, [cx + r * 0.9, cy - r * 0.9, cx + r * 1.3, cy - r * 1.3], '#2a2a30', ts * 0.08);
          if (ckg) for (let k = 0; k < 4; k++) { const a = now / 160 + k * 1.7; Ci(ctx, cx + Math.cos(a * 1.3) * r * 0.55, cy + Math.sin(a) * r * 0.5, r * (0.07 + 0.04 * Math.sin(a * 4)), 'rgba(255,240,200,.75)'); }
        }
        const th = S.cr || S.cc;
        if (th) { const sp = thingSprite(th, ts * 0.52, dpr); const j = ckg ? Math.sin(now / 60) * 0.6 : 0; blit(ctx, sp, cx + j, cy); }
      } else if (S.ck === 'pot') {
        RR(ctx, cx - r * 1.15, cy - r * 0.18, r * 0.3, r * 0.3, r * 0.08, '#5d6875'); RR(ctx, cx + r * 0.85, cy - r * 0.18, r * 0.3, r * 0.3, r * 0.08, '#5d6875');
        Ci(ctx, cx, cy, r, '#7d8996'); Ci(ctx, cx, cy, r * 0.84, S.cc || S.cr ? (S.cr ? '#c9b8a0' : '#86b9d6') : '#4a525e');
        if (ckg) for (let k = 0; k < 3; k++) { const a = now / 300 + k * 2.1; Ci(ctx, cx + Math.cos(a) * r * 0.45, cy + Math.sin(a * 1.3) * r * 0.4, r * (0.08 + 0.05 * Math.sin(a * 3)), 'rgba(255,255,255,.55)'); }
        if (S.cr) blit(ctx, thingSprite(S.cr, ts * 0.56, dpr), cx, cy - ts * 0.04);
        else if (S.cc) contents(S, cx, cy, ts, dpr, r);
      } else if (S.ck === 'steam') {
        Ci(ctx, cx, cy, r * 1.05, '#a8763e'); Ci(ctx, cx, cy, r * 0.9, '#d9a85e');
        if (ckg) { // lid on
          Ci(ctx, cx, cy, r * 0.82, '#e8c078'); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI; LN(ctx, [cx + Math.cos(a) * r * 0.8, cy + Math.sin(a) * r * 0.8, cx - Math.cos(a) * r * 0.8, cy - Math.sin(a) * r * 0.8], 'rgba(150,100,50,.4)', Math.max(1, ts * 0.025)); }
          Ci(ctx, cx, cy, r * 0.15, '#a8763e');
        } else {
          Ci(ctx, cx, cy, r * 0.8, '#f2e6c8');
          if (S.cr) blit(ctx, thingSprite(S.cr, ts * 0.56, dpr), cx, cy - ts * 0.03); else if (S.cc) contents(S, cx, cy, ts, dpr, r);
        }
      } else if (S.ck === 'grill') {
        const glow = ckg ? 0.5 + 0.2 * Math.sin(now / 140) : 0.25;
        RR(ctx, cx - r * 1.05, cy - r * 0.95, r * 2.1, r * 1.9, r * 0.2, 'rgba(255,110,40,' + glow.toFixed(2) + ')');
        for (let k = 0; k < 5; k++) LN(ctx, [cx - r * 0.85, cy - r * 0.7 + k * r * 0.35, cx + r * 0.85, cy - r * 0.7 + k * r * 0.35], '#8a8794', Math.max(1.5, ts * 0.04));
        if (S.cr) blit(ctx, thingSprite(S.cr, ts * 0.56, dpr), cx, cy - ts * 0.03); else if (S.cc) contents(S, cx, cy, ts, dpr, r);
      } else if (S.ck === 'mix') {
        const sp = ckg ? Math.sin(now / 40) * 0.8 : 0;
        ctx.beginPath(); ctx.moveTo(cx - r * 0.75 + sp, cy - r * 1.0); ctx.lineTo(cx + r * 0.75 + sp, cy - r * 1.0); ctx.lineTo(cx + r * 0.5, cy + r * 0.45); ctx.lineTo(cx - r * 0.5, cy + r * 0.45); ctx.closePath();
        ctx.fillStyle = 'rgba(210,232,244,.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(120,140,160,.8)'; ctx.lineWidth = Math.max(1, ts * 0.03); ctx.stroke();
        if (ckg) { const col = IT[resultOf(K, S)] ? IT[resultOf(K, S)][1] : '#f07a8a'; for (let k = 0; k < 3; k++) { const a = now / 70 + k * 2.1; Ci(ctx, cx + Math.cos(a) * r * 0.3, cy - r * 0.25 + Math.sin(a) * r * 0.2, r * 0.22, hexA(col, 0.85)); } }
        else if (S.cr) blit(ctx, thingSprite(S.cr, ts * 0.5, dpr), cx, cy - ts * 0.1);
        else if (S.cc) { const n = S.cc.length; for (let k = 0; k < n; k++) blit(ctx, thingSprite(S.cc[k], ts * 0.28, dpr), cx + (k - (n - 1) / 2) * ts * 0.17, cy - ts * 0.12); }
      } else { // oven
        const glow = ckg ? 0.55 + 0.25 * Math.sin(now / 120) : S.cr ? 0.25 : 0;
        if (glow) RR(ctx, cx - ts * 0.3, cy - ts * 0.18, ts * 0.6, ts * 0.38, ts * 0.06, 'rgba(255,140,40,' + glow.toFixed(2) + ')');
        const th = S.cr || S.cc;
        if (S.cr) blit(ctx, thingSprite(S.cr, ts * 0.56, dpr), cx, cy - ts * 0.08);
        else if (th) { const n = th.length; for (let k = 0; k < n; k++) blit(ctx, thingSprite(th[k], ts * 0.3, dpr), cx + (k - (n - 1) / 2) * ts * 0.2, cy + ts * 0.02); }
      }
      // need dots for a recipe cooker still collecting
      if (!isOne(S.ck) && S.cc && !ckg) {
        const ks = (K.M.recK[S.ck] || []).filter((k) => msub(S.cc, k)).sort((a, b) => a.length - b.length);
        if (ks.length) { const need = ks[0].length; for (let k = 0; k < need; k++) Ci(ctx, cx + (k - (need - 1) / 2) * ts * 0.13, cy + ts * 0.4, ts * 0.045, k < S.cc.length ? '#ffe08a' : 'rgba(20,14,24,.55)'); }
      }
      // status
      const bx = cx + ts * 0.3, by = cy - ts * 0.3;
      if (ckg) { ringBg(cx, cy, ts * 0.42, 3); ring(cx, cy, ts * 0.42, S.cp / P.cook, S.fu === 0 ? '#8a8794' : '#7fe08a', 3); }
      else if (S.cr && S.cr !== 'x') {
        if (P.nob || S.cp < P.safe) badge(bx, by, ts * 0.12, '#3fae5a', 'ok');
        else { const f = (S.cp - P.safe) / WARN; ringBg(cx, cy, ts * 0.42, 3); ring(cx, cy, ts * 0.42, f, '#ff5a3a', 3); if (Math.floor(now / 160) % 2 === 0) badge(bx, by, ts * 0.13, '#e8402a', '!'); }
      }
      if (S.fire) {
        const t = now / 90;
        for (let k = 0; k < 5; k++) flame(cx + (k - 2) * ts * 0.13, cy + ts * 0.2, ts * (0.55 + 0.15 * Math.sin(t + k * 1.7)), ts * 0.09, k % 2 ? '#ff7a2a' : '#ffc24a');
        if (K.ch.work && K.ch.work.k === 'ext' && K.st[K.ch.work.s] === S) { ringBg(cx, cy, ts * 0.42, 3); ring(cx, cy, ts * 0.42, S.fx / EXT, '#bfe8ff', 3); }
      }
      // campfire fuel bar (+ a blinking log when it is out)
      if (S.fu != null) {
        const w = ts * 0.7, x0 = cx - w / 2, y0 = cy + ts * 0.42;
        RR(ctx, x0 - 1, y0 - 1, w + 2, ts * 0.09 + 2, ts * 0.05, 'rgba(20,14,24,.7)');
        if (S.fu > 0) RR(ctx, x0, y0, w * S.fu, ts * 0.09, ts * 0.045, S.fu > 0.5 ? '#7fe08a' : S.fu > 0.22 ? '#ffd24a' : '#ff6a3a');
        if (S.fu < 0.22 && Math.floor(now / 250) % 2 === 0) { Ci(ctx, cx - ts * 0.3, cy - ts * 0.3, ts * 0.15, '#2a1f2e'); g2log(cx - ts * 0.3, cy - ts * 0.3, ts * 0.22); }
      }
    }
    function g2log(x, y, s) { ctx.save(); ctx.translate(x, y); drawItem(ctx, '목', s); ctx.restore(); }
    function drawKitchen(K, now) {
      const { ts, ox, oy } = lay, dpr = DPR(), C = K.ch, playing = tl >= 0 && tl < st.T;
      ctx.drawImage(staticFor(K), ox, oy, lay.kw, lay.kh);
      const X = (x) => ox + x * ts, Y = (y) => oy + y * ts;
      // belts
      if (K.belts.length) {
        const o = (K.t * BELT_V) % 1;
        ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = Math.max(1.5, ts * 0.05);
        for (const si of K.belts) {
          const S = K.st[si], dx = S.dx, dy = S.dy, px = -dy, py = dx;
          for (let k = 0; k < 2; k++) {
            const f = ((k * 0.5 + o) % 1) * 0.64 - 0.32, x = X(S.x) + ts * (0.5 + f * dx), y = Y(S.y) + ts * (0.5 + f * dy);
            ctx.beginPath(); ctx.moveTo(x - ts * 0.08 * dx + ts * 0.16 * px, y - ts * 0.08 * dy + ts * 0.16 * py); ctx.lineTo(x + ts * 0.06 * dx, y + ts * 0.06 * dy); ctx.lineTo(x - ts * 0.08 * dx - ts * 0.16 * px, y - ts * 0.08 * dy - ts * 0.16 * py); ctx.stroke();
          }
        }
      }
      if (K.pt) for (const i in K.pt) { // magic portals swirl
        const x = X(tx(+i)) + ts / 2, y = Y(ty(+i)) + ts / 2, a0 = now / 400;
        for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(x, y, ts * (0.14 + k * 0.1), a0 * (k % 2 ? -1 : 1) + k, a0 * (k % 2 ? -1 : 1) + k + 3.6); ctx.strokeStyle = k % 2 ? 'rgba(255,240,255,.75)' : 'rgba(200,160,255,.85)'; ctx.lineWidth = Math.max(1.5, ts * 0.05); ctx.stroke(); }
      }
      if (K.nv) { // night market: current flame level on the corner sign
        const x = X(0) + ts / 2, y = Y(0) + ts / 2, lv = K.heat, col = lv > 1.2 ? '#ff5a2a' : lv < 0.8 ? '#6ab0ff' : '#ffb02e';
        Ci(ctx, x, y, ts * 0.44, K.nv.w && Math.floor(now / 200) % 2 ? '#5a2a1a' : 'rgba(20,14,24,.9)');
        flame(x, y + ts * 0.05, ts * (0.18 + 0.16 * lv), ts * 0.13, col);
        txt(lv > 1.2 ? '강' : lv < 0.8 ? '약' : '중', x, y + ts * 0.24, '#fff', '800 ' + Math.round(ts * 0.26) + 'px ' + FONT);
      }
      if (K.KD.regrow) for (const S of K.st) if (S.ty === 'C' && S.ing) { // garden beds: crop on top, regrowing ring
        const cx = X(S.x) + ts / 2, cy = Y(S.y) + ts / 2, f = S.cd > 0 ? 1 - S.cd / REGROW : 1;
        for (let q = 0; q < 3; q++) LN(ctx, [cx + (q - 1) * ts * 0.22, cy + ts * 0.3, cx + (q - 1) * ts * 0.22 + ts * 0.04, cy + ts * (0.3 - 0.2 * f)], '#5ea844', Math.max(1.5, ts * 0.05));
        if (f >= 1) { Ci(ctx, cx, cy - ts * 0.05, ts * 0.27, 'rgba(246,236,216,.92)'); blit(ctx, sprite(S.ing, ts * 0.42, dpr, (g, s2) => drawItem(g, S.ing, s2)), cx, cy - ts * 0.05); }
        else { ringBg(cx, cy, ts * 0.3, 3); ring(cx, cy, ts * 0.3, f, '#7fe08a', 3); blit(ctx, sprite(S.ing, ts * 0.28 * (0.4 + 0.6 * f), dpr, (g, s2) => drawItem(g, S.ing, s2)), cx, cy - ts * 0.02); }
      }
      K.doors.forEach((i, k) => drawDoor(K, i, k, ts));
      // island platform
      if (K.il) {
        const ix = islX(K), len = K.KD.isl.s.length, y = K.KD.isl.y;
        RR(ctx, X(ix) + 2, Y(y) + ts * 0.86, ts * len - 4, ts * 0.12, ts * 0.04, '#55505e');
        for (let k = 0; k < len * 2; k++) Ci(ctx, X(ix) + ts * (0.25 + k * 0.5), Y(y) + ts * 0.94, ts * 0.05, '#2a2730');
        K.st.forEach((S) => { if (S.isl) drawStationBase(ctx, S, X(ix + S.isl - 1), Y(y), ts, false, K); });
      }
      // highlights: where the thing in hand can go now
      if (canCtl() && playing && !C.work) {
        const a = 0.45 + 0.35 * Math.sin(now / 180);
        for (let si = 0; si < K.st.length; si++) {
          const S = K.st[si];
          if (S.ty === '_' || S.ty === 'belt' || S.ty === 'D' && !C.h) continue;
          const r = interact(K, si, false);
          if (!r.ok) continue;
          const kd = r.k;
          let on = kd === 'cook' || kd === 'serve' || kd === 'wash' || kd === 'ext' || kd === 'plate' || (kd === 'chop' && (!!C.h || S.cp > 0)) || (kd === 'put' && S.ty === 'B' && canWork(S, C.h)) || kd === 'fuel' || (kd === 'pick' && S.ty === 'L' && K.heats.some((hi) => K.st[hi].fu != null && K.st[hi].fu < 0.3)) || (kd === 'trash' && (C.h === 'x' || isPlate(C.h) && !plateTgt(K, C.h.slice(1)))) || (kd === 'pick' && S.ty === 'H' && !!S.cr) || (kd === 'put' && S.ty === 'D');
          if (S.ty === 'C' && kd === 'plate') on = true;
          if (!on) continue;
          const p = stPos(K, S);
          rrect(ctx, X(p.x) + 2, Y(p.y) + 2, ts - 4, ts - 4, ts * 0.14);
          ctx.strokeStyle = 'rgba(255,214,110,' + a.toFixed(2) + ')'; ctx.lineWidth = Math.max(2, ts * 0.06); ctx.stroke();
        }
        // plates on counters that could take the item in hand
        if (isItem(C.h)) for (const S of K.st) if ((S.ty === '_' || S.ty === 'B') && isPlate(S.th) && fits(K, S.th.slice(1), C.h)) { rrect(ctx, X(S.x) + 2, Y(S.y) + 2, ts - 4, ts - 4, ts * 0.14); ctx.strokeStyle = 'rgba(255,214,110,' + a.toFixed(2) + ')'; ctx.lineWidth = Math.max(2, ts * 0.06); ctx.stroke(); }
      }
      // contents
      for (let si = 0; si < K.st.length; si++) {
        const S = K.st[si], p = stPos(K, S), cx = X(p.x) + ts / 2, cy = Y(p.y) + ts / 2;
        switch (S.ty) {
          case '_': case 'B': if (S.th) {
            let fx = 0, fy = 0;
            const an = K.flt && K.flt.an;
            if (an && an.b === si) { const A0 = K.st[an.a], u = an.t / 1.1, e = u * u * (3 - 2 * u); fx = (A0.x - S.x) * ts * e; fy = (A0.y - S.y) * ts * e - Math.sin((1 - u) * Math.PI) * ts * 0.5; }
            blit(ctx, thingSprite(S.th, ts * (isPlate(S.th) || isDirty(S.th) ? 0.8 : 0.66), dpr), cx + fx, cy - ts * 0.03 + fy + (K.flt ? Math.sin(now / 500 + si) * ts * 0.03 : 0));
            if (S.ty === 'B' && canWork(S, S.th) && S.cp > 0) { ringBg(cx, cy, ts * 0.4, 3); ring(cx, cy, ts * 0.4, S.cp / chopT(S.th), '#ffe08a', 3); }
            if (isDirty(S.th) && dn(S.th) > 1) badge(cx + ts * 0.3, cy - ts * 0.28, ts * 0.12, '#7d8794', String(dn(S.th)));
          } break;
          case 'belt': if (S.th) {
            blit(ctx, thingSprite(S.th, ts * (isPlate(S.th) ? 0.8 : 0.62), dpr), cx + S.dx * (S.off - 0.5) * ts, cy + S.dy * (S.off - 0.5) * ts);
            if (S.bad) badge(cx + ts * 0.3, cy - ts * 0.3, ts * 0.12, '#e8402a', '×');
          } break;
          case 'H': drawCookware(K, S, cx, cy, ts, now); break;
          case 'P': { const n = K.wash ? Math.min(S.n, 4) : 3; for (let k = 0; k < n; k++) blit(ctx, sprite('@', ts * 0.72, dpr, (g, s) => drawPlate(g, '', s)), cx, cy + ts * 0.08 - k * ts * 0.07);
            if (K.wash) badge(cx + ts * 0.32, cy - ts * 0.3, ts * 0.13, S.n > 0 ? '#5a8a5a' : '#a04040', String(S.n)); break; }
          case 'D': if (S.n > 0) { for (let k = 0; k < Math.min(S.n, 4); k++) blit(ctx, thingSprite('%1', ts * 0.68, dpr), cx, cy + ts * 0.06 - k * ts * 0.07); badge(cx + ts * 0.32, cy - ts * 0.3, ts * 0.13, '#7d8794', String(S.n)); } break;
          case 'S': if (S.n > 0) {
            blit(ctx, thingSprite('%1', ts * 0.58, dpr), cx, cy + ts * 0.02); badge(cx + ts * 0.32, cy - ts * 0.3, ts * 0.13, '#5a7a9a', String(S.n));
            if (S.cp > 0) { ringBg(cx, cy, ts * 0.4, 3); ring(cx, cy, ts * 0.4, S.cp / WASH, '#9fdcff', 3); }
          } break;
        }
      }
      // queue markers
      const qs = (C.cur && C.cur.s != null ? [C.cur] : []).concat(C.q.filter((q) => q.s != null));
      if (canCtl()) qs.forEach((q, k) => {
        const S = K.st[q.s]; if (!S) return;
        const p = stPos(K, S), x = X(p.x) + ts * 0.18, y = Y(p.y) + ts * 0.18;
        Ci(ctx, x, y, ts * 0.13, 'rgba(20,14,24,.7)'); Ci(ctx, x, y, ts * 0.11, Pl(view).color);
        txt(String(k + 1), x, y + 0.5, '#17131f', '800 ' + Math.round(ts * 0.16) + 'px ' + MONO);
      });
      if (kbUsed && canCtl() && playing && !C.work) { // keyboard: show which station 작업 will use
        const fi = facedTile(K), fsi = fi >= 0 ? stationAtF(K, tx(fi) + 0.5, ty(fi) + 0.5) : -1;
        if (fsi != null && fsi >= 0) {
          const p = stPos(K, K.st[fsi]);
          ctx.setLineDash([ts * 0.14, ts * 0.09]); rrect(ctx, X(p.x) + 3, Y(p.y) + 3, ts - 6, ts - 6, ts * 0.12);
          ctx.strokeStyle = hexA(Pl(view).color, 0.9); ctx.lineWidth = Math.max(2, ts * 0.05); ctx.stroke(); ctx.setLineDash([]);
        }
      }
      if (C.cur && C.cur.f != null && canCtl()) { const x = X(tx(C.cur.f)) + ts / 2, y = Y(ty(C.cur.f)) + ts / 2; E(ctx, x, y + ts * 0.2, ts * 0.22, ts * 0.08, hexA(Pl(view).color, 0.5)); }
      for (const r of ripples) { const f = 1 - r.t / r.T; ctx.beginPath(); ctx.arc(X(r.x), Y(r.y), ts * (0.2 + f * 0.35), 0, TAU); ctx.strokeStyle = hexA(r.col, (1 - f) * 0.9); ctx.lineWidth = 3; ctx.stroke(); }
      // mouse
      if (K.mo) {
        const m = K.mo, x = X(m.x), y = Y(m.y), fl = m.dir === 1 ? -1 : 1, s = ts;
        ctx.save(); ctx.translate(x, y + s * 0.12); if (m.dir === 1 || m.dir === 2) ctx.scale(fl, 1);
        LN(ctx, [-s * 0.2, s * 0.02, -s * 0.36, -s * 0.06, -s * 0.42, s * 0.06], '#d9a0a8', s * 0.03);
        E(ctx, 0, 0, s * 0.2, s * 0.13, '#8a8794'); Ci(ctx, s * 0.16, -s * 0.06, s * 0.09, '#9a97a4'); Ci(ctx, s * 0.12, -s * 0.15, s * 0.05, '#d9a0a8'); Ci(ctx, s * 0.21, -s * 0.13, s * 0.05, '#d9a0a8');
        Ci(ctx, s * 0.2, -s * 0.07, s * 0.018, '#111'); Ci(ctx, s * 0.26, -s * 0.03, s * 0.022, '#e07a8a');
        if (m.item) blit(ctx, thingSprite(m.item, s * 0.36, dpr), s * 0.3, s * 0.02);
        ctx.restore();
        if (canCtl() && m.st !== 'flee') { ctx.beginPath(); ctx.arc(x, y + s * 0.1, s * (0.36 + 0.05 * Math.sin(now / 120)), 0, TAU); ctx.strokeStyle = 'rgba(255,214,110,.6)'; ctx.lineWidth = 2; ctx.stroke(); }
      }
      // chef
      const cp = chefPos(K);
      drawChef(K, X(cp.x), Y(cp.y), ts, Pl(view).color, now);
      // particles
      for (const q of parts) {
        const f = q.t / q.T, x = X(q.x), y = Y(q.y);
        if (q.k === 'steam' || q.k === 'smoke') { Ci(ctx, x, y, ts * q.r * (1.6 - f * 0.6), hexA(q.c, 0.45 * f)); }
        else if (q.k === 'flame') Ci(ctx, x, y, ts * q.r * f, hexA(q.c, 0.9));
        else if (q.k === 'coin') { E(ctx, x, y, ts * 0.07, ts * 0.07 * Math.abs(Math.sin(q.t * 12)) + 1, '#e3ae45'); }
        else if (q.k === 'star') { ctx.save(); ctx.translate(x, y); ctx.rotate(q.t * 6); ctx.fillStyle = hexA(q.c, f); ctx.fillRect(-ts * 0.04, -ts * 0.04, ts * 0.08, ts * 0.08); ctx.restore(); }
        else Ci(ctx, x, y, Math.max(1, ts * q.r * (0.5 + f * 0.5)), hexA(q.c, Math.min(1, f * 1.5)));
      }
      for (const fl of floats) {
        if (fl.hud != null || fl.rail) continue;
        const f = fl.t / fl.T, x = X(fl.x), y = Y(fl.y) - (1 - f) * ts * 0.5;
        const font = (fl.big ? '800 ' + Math.round(ts * 0.42) : '700 ' + Math.round(Math.max(12, ts * 0.27))) + 'px ' + FONT;
        ctx.globalAlpha = Math.min(1, f * 2.5);
        if (fl.bub) { ctx.font = font; const w = ctx.measureText(fl.text).width + 14, bx = U.clamp(x, lay.ox + w / 2 + 2, lay.ox + lay.kw - w / 2 - 2); RR(ctx, bx - w / 2, y - ts * 0.2, w, ts * 0.4, ts * 0.12, 'rgba(23,19,31,.88)'); txt(fl.text, bx, y, fl.col, font); }
        else { ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(23,19,31,.8)'; ctx.font = font; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; const bx = U.clamp(x, lay.ox + 30, lay.ox + lay.kw - 30); ctx.strokeText(fl.text, bx, y); txt(fl.text, bx, y, fl.col, font); }
        ctx.globalAlpha = 1;
      }
    }
    function drawHud(now) {
      const w = lay.w, y = lay.hudH / 2, K = KS[view];
      // timer
      const rem = st ? Math.max(0, st.T - U.clamp(tl, 0, st.T)) : 0, m = Math.floor(Math.ceil(rem) / 60), s = Math.ceil(rem) % 60;
      const low = rem <= 30 && tl >= 0 && rem > 0, pulse = low ? 1 + 0.08 * Math.abs(Math.sin(now / 160)) : 1;
      RR(ctx, 8, y - 14, 66, 28, 14, low ? '#7a2a24' : '#2e2640'); rrect(ctx, 8, y - 14, 66, 28, 14); ctx.strokeStyle = low ? '#ff8a6a' : 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      txt(m + ':' + String(s).padStart(2, '0'), 41, y + 1, low ? '#ffe0d8' : '#f2e9d8', '700 ' + Math.round(15 * pulse) + 'px ' + MONO);
      // my score
      const mySc = scoreRow(view)[0];
      dispSc += (mySc - dispSc) * 0.2; if (Math.abs(mySc - dispSc) < 0.5) dispSc = mySc;
      const sx = 84;
      Ci(ctx, sx + 10, y, 9 + scPop * 3, '#e3ae45'); Ci(ctx, sx + 10, y, 6 + scPop * 2, '#f6d27a'); txt('₩', sx + 10, y + 0.5, '#8a5a12', '800 9px ' + FONT);
      txt(String(Math.round(dispSc)), sx + 24, y + 1, '#ffe08a', '800 ' + Math.round(19 + scPop * 4) + 'px ' + MONO, 'left');
      ctx.font = '800 19px ' + MONO; let rx = sx + 30 + ctx.measureText(String(Math.round(dispSc))).width;
      if (!isMine(view) && key) { txt(fitText(name(view), 60, '600 11px ' + FONT), rx + 4, y + 1, Pl(view).color, '600 11px ' + FONT, 'left'); ctx.font = '600 11px ' + FONT; rx += 8 + Math.min(60, ctx.measureText(name(view)).width); }
      // others or stars
      if (!st) return;
      if (st.n === 1) {
        const need = starNeed(st);
        for (let i = 0; i < 3; i++) { const x = w - 18 - (2 - i) * 24, on = mySc >= need[i]; star(x, y - 3, 9, on ? '#ffd24a' : 'rgba(242,233,216,.18)'); txt(String(need[i]), x, y + 12, on ? '#ffe08a' : '#8a7f98', '600 9px ' + MONO); }
        return;
      }
      const others = []; for (let i = 0; i < st.n; i++) if (i !== view) others.push(i);
      let x = w - 8;
      const showName = (w - rx - 10) / Math.max(1, others.length) > 82;
      for (let j = others.length - 1; j >= 0; j--) {
        const i = others[j], sc = String(scoreRow(i)[0]);
        ctx.font = '700 14px ' + MONO; const sw = ctx.measureText(sc).width;
        const nmT = showName ? fitText(name(i), 40, '600 11px ' + FONT) : ''; ctx.font = '600 11px ' + FONT; const nw = nmT ? ctx.measureText(nmT).width + 4 : 0;
        const bw = 18 + nw + sw + 8;
        RR(ctx, x - bw, y - 12, bw, 24, 12, 'rgba(46,38,64,.85)');
        Ci(ctx, x - bw + 11, y, 5, Pl(i).color);
        if (nmT) txt(nmT, x - bw + 19, y + 1, '#ab9fb8', '600 11px ' + FONT, 'left');
        txt(sc, x - 6, y + 1, '#f2e9d8', '700 14px ' + MONO, 'right');
        for (const fl of floats) if (fl.hud === i) { const f = fl.t / fl.T; ctx.globalAlpha = Math.min(1, f * 2); txt(fl.text, x - bw / 2, y + 22 - (1 - f) * 6, fl.col, '800 12px ' + MONO); ctx.globalAlpha = 1; }
        x -= bw + 5;
        if (x < rx + 20) break;
      }
    }
    function star(x, y, r, col) {
      ctx.beginPath();
      for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; i ? ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr) : ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); }
      ctx.closePath(); ctx.fillStyle = col; ctx.fill();
    }
    function drawRail(K, now) {
      const n = MAX_ORD, gap = 6, cw = (lay.w - 16 - (n - 1) * gap) / n, ch = lay.railH - 6, y0 = lay.railY + 2, dpr = DPR();
      const held = K && isPlate(K.ch.h) ? K.ch.h.slice(1) : null;
      for (let i = 0; i < n; i++) {
        const x = 8 + i * (cw + gap), o = K && K.ord[i];
        if (!o) { rrect(ctx, x, y0, cw, ch, 10); ctx.strokeStyle = 'rgba(242,233,216,.08)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1; ctx.stroke(); ctx.setLineDash([]); continue; }
        if (cardT[o.k] == null) cardT[o.k] = now;
        const ap = U.clamp((now - cardT[o.k]) / 260, 0, 1), sl = (1 - ap) * (1 - ap) * 40;
        const D = DISH[o.d], f = U.clamp(1 - (K.t - o.t0) / o.lim, 0, 1);
        const urg = f < 0.25, col = f > 0.5 ? '#5fbf6a' : f > 0.25 ? '#e8b440' : '#e8503a';
        const jx = urg ? Math.sin(now / 45) * 1.2 : 0;
        ctx.save(); ctx.translate(sl + jx, 0); ctx.globalAlpha = ap;
        RR(ctx, x, y0 + 2, cw, ch, 10, 'rgba(10,6,12,.4)');
        RR(ctx, x, y0, cw, ch, 10, '#f6ecd8');
        ctx.save(); rrect(ctx, x, y0, cw, ch, 10); ctx.clip(); ctx.fillStyle = col; ctx.fillRect(x, y0 + ch - 6, cw * f, 6); ctx.fillStyle = 'rgba(0,0,0,.08)'; ctx.fillRect(x + cw * f, y0 + ch - 6, cw * (1 - f), 6); ctx.restore();
        const isz = Math.min(ch * 0.44, cw * 0.5);
        blit(ctx, dishSprite(o.d, isz, dpr), x + cw / 2 - 4, y0 + isz * 0.56);
        txt('+' + D.pts, x + cw - 5, y0 + 9, '#8a5a12', '700 10px ' + MONO, 'right');
        const nf = ctx.measureText ? (() => { for (const fs of [11, 10, 9]) { ctx.font = '800 ' + fs + 'px ' + FONT; if (ctx.measureText(D.n).width <= cw - 6) return '800 ' + fs + 'px ' + FONT; } return '800 9px ' + FONT; })() : '';
        txt(fitText(D.n, cw - 6, nf), x + cw / 2, y0 + isz + 5, '#2a1f2e', nf);
        // components
        const comp = D.c, m = comp.length, csz = Math.min(ch - isz - 22, 21, (cw - 10) / m - 2), cy = y0 + ch - 7 - csz / 2 - 1;
        let have = held && msub(held, comp) ? held : '';
        for (let k = 0; k < m; k++) {
          const cx = x + cw / 2 + (k - (m - 1) / 2) * (csz + 2);
          const got = have.includes(comp[k]); if (got) have = have.replace(comp[k], '');
          Ci(ctx, cx, cy, csz / 2 + 1, got ? '#cdeccf' : '#e9dcc4');
          blit(ctx, sprite(comp[k], csz * 0.82, dpr, (g, s) => drawItem(g, comp[k], s)), cx, cy);
          const gk = glyphKind(comp[k]);
          if (gk && csz >= 15) { ctx.save(); ctx.translate(cx + csz * 0.38, cy - csz * 0.38); Ci(ctx, 0, 0, csz * 0.24, '#2a1f2e'); drawGlyph(ctx, gk, csz * 0.36); ctx.restore(); }
          if (got) LN(ctx, [cx - 3, cy + 1, cx - 1, cy + 3, cx + 3, cy - 2], '#2e8a3e', 1.6);
        }
        ctx.restore();
      }
      if (K && K.ord[0] && L.ui.keyLabel) L.ui.drawKeyBadge(ctx, 8 + cw - 2, y0 + ch - 8, L.ui.keyLabel('cooking', 'order'), 0.85);   // 주문 레시피 보기 단축키
      for (const fl of floats) if (fl.rail) { const f = fl.t / fl.T; ctx.globalAlpha = Math.min(1, f * 2); RR(ctx, lay.w / 2 - 90, lay.railY + lay.railH / 2 - 13, 180, 26, 13, 'rgba(23,19,31,.9)'); txt(fl.text, lay.w / 2, lay.railY + lay.railH / 2, fl.col, '700 12.5px ' + FONT); ctx.globalAlpha = 1; break; }
    }
    function plateTgt(K, c) { return plateTarget(K, c, K.ord.slice().sort((a, b) => (a.lim - (K.t - a.t0)) - (b.lim - (K.t - b.t0)))); }
    function hintFor(K) {
      const C = K.ch, h = C.h, M = K.M;
      if (C.work) return C.work.k === 'chop' ? [(WKP[(K.st[C.work.s] || {}).wk] || WKP.cut).ing + '… ', kbUsed ? '연타 키' : (WKP[(K.st[C.work.s] || {}).wk] || WKP.cut).n + '를 톡톡', ' 누르면 더 빨리!'] : C.work.k === 'wash' ? ['설거지 중… ', kbUsed ? '연타 키' : '개수대를 톡톡', ' 누르면 더 빨리!'] : ['불 끄는 중…', '', ''];
      if (K.heats.some((si) => K.st[si].fire)) return ['불이 났어요! ', '불난 화구', '를 눌러 꺼요'];
      if (K.lu && (K.lu.a > 0 || K.lu.w)) return ['덜컹! ', '기차가 흔들려요', ' — 잠깐 멈춰요'];
      if (!h) {
        if (K.woods.length && K.heats.some((si) => { const S = K.st[si]; return S.fu != null && S.fu < 0.25 && (S.cc || S.cr || S.fu === 0); })) return ['모닥불이 꺼져 가요! ', '장작 더미', '에서 장작을 가져와요'];
        if (K.heats.some((si) => K.st[si].cr === 'x')) return ['탄 음식을 빈손으로 꺼내 ', '쓰레기통', '에'];
        if (K.heats.some((si) => K.st[si].cr)) return ['다 익었어요! 빈손으로 꺼내거나 ', '접시', '를 들고 가요'];
        if (K.mo && K.mo.st !== 'flee') return ['쥐다! ', '쥐를 톡', ' 눌러 쫓아요'];
        if (!K.ord.length) return ['곧 주문이 들어와요', '', ''];
        if (K.wash && K.st[K.plates].n <= 0 && (K.st[K.dirty].n > 0 || K.st[K.sink].n > 0)) return ['깨끗한 접시가 없어요. ', '더러운 접시', '를 개수대로'];
        return ['주문표를 보고 ', '재료 상자', '를 눌러요 (주문표를 누르면 만드는 법)'];
      }
      if (h === 'x') return ['탄 음식은 ', '쓰레기통', '으로'];
      if (isDirty(h)) return ['더러운 접시 → ', '개수대', '에서 씻어요'];
      if (isPlate(h)) {
        const c = h.slice(1);
        if (c && findOrder(K, c) >= 0) return ['완성! ', K.win >= 0 && K.belts.length === 0 ? '창구(종)' : K.KD.loop ? '회전 레일' : '컨베이어', '로 내요'];
        if (!c) return ['빈 접시: ', '재료 상자나 익은 요리', '를 눌러 담아요'];
        const tg = plateTgt(K, c);
        if (!tg) return ['주문에 없는 조합이에요. ', '쓰레기통', '에 비워요'];
        return [DISH[tg].n + ' 만들기: ', [...mdiff(DISH[tg].c, c)].map(nameOf).join(' + '), ' 더 담아요'];
      }
      if (h === '목') return ['장작 → ', '불이 약한 모닥불', '에 넣어요'];
      const st2 = [];
      if (WORK[h] && M.need.has(WORK[h])) st2.push(WKP[WK[h]].n + '에서 ' + WKP[WK[h]].v);
      if (ONE[h] && M.need.has(ONE[h][1])) st2.push(CKV[ONE[h][0]]);
      for (const ck in M.recK) if (M.recK[ck].some((k) => k.includes(h))) st2.push(CKP[ck].n + '에 넣기');
      if (M.ready.has(h)) st2.push('접시에 담기');
      return [nameOf(h) + ' → ', st2.join(' 또는 ') || '필요 없으면 쓰레기통', ''];
    }
    function drawHint(K) {
      if (!canCtl() || tl < 0 || tl >= st.T) return;
      const parts3 = hintFor(K), y = Math.min(lay.h - lay.hintH / 2 - 2, lay.oy + lay.kh + lay.hintH / 2 + 4), font = '600 12.5px ' + FONT, fontB = '800 12.5px ' + FONT;
      ctx.font = font; const w0 = ctx.measureText(parts3[0]).width, w2 = ctx.measureText(parts3[2]).width; ctx.font = fontB; const w1 = ctx.measureText(parts3[1]).width;
      let sc = 1; const tot = w0 + w1 + w2, maxW = lay.w - 20; if (tot > maxW) sc = maxW / tot;
      ctx.save(); ctx.translate(lay.w / 2, y); ctx.scale(sc, sc);
      let x = -tot / 2;
      txt(parts3[0], x, 0, '#d9cfe0', font, 'left'); x += w0;
      txt(parts3[1], x, 0, '#ffd66e', fontB, 'left'); x += w1;
      txt(parts3[2], x, 0, '#d9cfe0', font, 'left');
      ctx.restore();
    }
    function drawTip(K) {
      if (!tipBox) return;
      const D = DISH[tipBox.d], comps = [...new Set(D.c)], dpr = DPR();
      const lh = 26, w = Math.min(lay.w - 24, 340), h = 40 + comps.length * lh, x = (lay.w - w) / 2, y = lay.railY + lay.railH + 4;
      ctx.globalAlpha = Math.min(1, tipBox.t * 3);
      RR(ctx, x, y + 3, w, h, 14, 'rgba(0,0,0,.35)'); RR(ctx, x, y, w, h, 14, '#2e2640'); rrect(ctx, x, y, w, h, 14); ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke();
      txt(D.n + ' 만드는 법', x + 14, y + 18, '#ffe08a', '800 14px ' + FONT, 'left');
      txt('+' + D.pts + '점', x + w - 14, y + 18, '#ab9fb8', '700 12px ' + MONO, 'right');
      comps.forEach((c, k) => {
        const cy = y + 40 + k * lh + lh / 2 - 4, cnt = [...D.c].filter((q) => q === c).length;
        blit(ctx, sprite(c, 20, dpr, (g, s) => drawItem(g, c, s)), x + 24, cy);
        txt(fitText(nameOf(c) + (cnt > 1 ? ' ×' + cnt : '') + ': ' + howTo(c), w - 50, '600 12px ' + FONT), x + 40, cy, '#f2e9d8', '600 12px ' + FONT, 'left');
      });
      ctx.globalAlpha = 1;
    }
    function drawOverlay(K, now) {
      if (!st || st.ph === 'pick') return;
      const cx = lay.w / 2, cy = lay.oy + lay.kh * 0.42;
      if (tl < 0) {
        ctx.fillStyle = 'rgba(23,19,31,.72)'; ctx.fillRect(0, lay.railY, lay.w, lay.h - lay.railY);
        const KD = KITCHENS[st.km], M = menuOf(st.mn, st.sd);
        txt(M.n + ' · ' + KD.n, cx, cy - 110, '#ffe08a', '400 22px ' + DISP);
        txt(fitText(KD.sub, lay.w - 30, '600 12.5px ' + FONT), cx, cy - 84, '#d9cfe0', '600 12.5px ' + FONT);
        const n = Math.ceil(-tl), f = -tl - Math.floor(-tl);
        txt(String(n), cx, cy - 20, '#f2e9d8', '400 ' + Math.round(64 + f * 20) + 'px ' + DISP);
        txt('오늘의 메뉴', cx, cy + 34, '#ab9fb8', '700 12px ' + FONT);
        const iw = Math.min(84, (lay.w - 24) / 4);
        M.d.forEach((d, k) => { const x = cx + (k - 1.5) * iw; blit(ctx, dishSprite(d, iw * 0.6, DPR()), x, cy + 76); txt(fitText(DISH[d].n, iw - 4, '700 11px ' + FONT), x, cy + 112, '#f2e9d8', '700 11px ' + FONT); });
        if (isMine(view) && !auto()) txt('누르기만 하면 요리사가 알아서 움직여요', cx, cy + 140, '#ab9fb8', '600 12px ' + FONT);
      } else if (tl >= st.T || st.ph === 'done') {
        ctx.fillStyle = 'rgba(23,19,31,.6)'; ctx.fillRect(0, lay.railY, lay.w, lay.h - lay.railY);
        txt('끝!', cx, cy - 30, '#ffe08a', '400 54px ' + DISP);
        const r = scoreRow(view);
        txt((isMine(view) ? '내 점수 ' : name(view) + ' ') + r[0] + '점 · 요리 ' + r[1] + '개', cx, cy + 20, '#f2e9d8', '700 15px ' + FONT);
        if (st.ph !== 'done') txt('결과를 모으는 중…', cx, cy + 46, '#ab9fb8', '600 12px ' + FONT);
      }
    }
    function drawPickBg() {
      const ki = st.pk >= 0 ? st.pk : 0, mi = st.pm >= 0 ? st.pm : 0, pkKey = ki + '.' + mi;
      if (pkKey !== prevKey || !prevK) { prevK = newKitchen(ki, mi, 3, 60, 1); prevKey = pkKey; stat = null; }
      ctx.globalAlpha = st.pk >= 0 ? 0.9 : 0.35;
      ctx.drawImage(staticFor(prevK), lay.ox, lay.oy, lay.kw, lay.kh);
      ctx.globalAlpha = 1;
    }
    function draw(now) {
      const w = cv.w, h = cv.h;
      if (!lay || lay.w !== w || lay.h !== h) layout();
      cv.clear();
      if (!lay.bg) { lay.bg = ctx.createRadialGradient(w / 2, h * 0.45, 20, w / 2, h * 0.45, Math.max(w, h) * 0.75); lay.bg.addColorStop(0, '#2a2134'); lay.bg.addColorStop(1, '#141019'); }
      ctx.fillStyle = lay.bg; ctx.fillRect(0, 0, w, h);
      if (!st) return;
      if (st.ph === 'pick') { drawPickBg(); return; }
      const K = KS[view];
      if (!K) { drawHud(now); txt('주방을 준비하는 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      const sh = shake > 0 ? (Math.random() - 0.5) * shake * 6 * (L.fx ? L.fx() : 1) : 0;
      ctx.save(); ctx.translate(sh, 0);
      RR(ctx, lay.ox - 4, lay.oy - 4, lay.kw + 8, lay.kh + 8, 10, '#0e0b12');
      drawKitchen(K, now);
      ctx.restore();
      drawHud(now);
      drawRail(K, now);
      drawHint(K);
      drawTip(K);
      drawOverlay(K, now);
    }

    const stop = U.loop(frame);
    root._ck = { lay: () => lay, K: () => KS[view], tl: () => tl, tip: () => tipBox }; // test hook
    return {
      update(state) {
        st = state;
        if (!st) return;
        if (st.ph === 'pick') { key = null; KS = []; if (pick) syncPicker(); }
        else if (pick) dropPicker();
        if (st.ph === 'done' && key === curKey()) tl = Math.max(tl, st.T);
      },
      destroy() {
        stop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        dropPicker();
        cv.destroy(); styleEl.remove();
      },
    };
  }

  /* ======================= 도감 (게임 밖에서도 열려요 — 데이터 표에서 만들어요) ======================= */
  function cxCanvas(w, h, fn) {
    const c = L.h('canvas', { style: { width: w + 'px', height: h + 'px', display: 'block', flex: 'none' } }), d = Math.min(2, window.devicePixelRatio || 1);
    c.width = Math.round(w * d); c.height = Math.round(h * d);
    const g = c.getContext('2d'); g.scale(d, d);
    try { fn(g); } catch (e) { /* drawing is decoration only */ }
    return c;
  }
  const cxAt = (x, y, f) => (g) => { g.save(); g.translate(x, y); f(g); g.restore(); };
  function codex(el) {
    const h = L.h;
    const note = (t) => h('p', { class: 'note', style: { margin: 0, fontSize: '12.5px', color: 'var(--muted)', lineHeight: 1.5 }, text: t });
    const sub = (t) => h('div', { style: { margin: '8px 0 0', fontWeight: 800, fontSize: '14px', color: 'var(--brass)' }, text: t });
    const row = (ic, name, tag, ...desc) => h('div', { class: 'cx-row' },
      h('span', { class: 'cx-ic', style: { width: '48px', height: '48px', overflow: 'hidden' } }, ic),
      h('div', { class: 'cx-tx' }, h('div', { class: 'cx-nm' }, h('b', { text: name }), tag ? h('span', { class: 'cx-tag', text: tag }) : null), ...desc));
    const d = (t) => h('div', { class: 'cx-d', text: t });
    const plateC = (c, s) => cxCanvas(s, s, cxAt(s / 2, s / 2, (g) => drawPlate(g, c, s * 0.92)));
    const itemC = (c, s) => cxCanvas(s, s, cxAt(s / 2, s / 2, (g) => drawItem(g, c, s * 0.82)));
    const glyphC = (k, s) => cxCanvas(s, s, cxAt(s / 2, s / 2, (g) => drawGlyph(g, k, s * 0.7)));
    const menusOf = (id) => MENUS.filter((M) => !M.mix && M.d.indexOf(id) >= 0).map((M) => M.n);
    const uniq = (a) => [...new Set(a)];
    const names = (codes) => codes.map(nameOf).join(' · ');
    const CKN = Object.assign({}, ...Object.keys(CKP).map((k) => ({ [k]: CKP[k].n })), ...Object.keys(WKP).map((k) => ({ [k]: WKP[k].n })));
    const madeBy = (kd) => {
      const out = [];
      if (WKP[kd]) for (const k in WORK) { if (WK[k] === kd) out.push(WORK[k]); }
      else if (CKP[kd].one) { for (const k in ONE) if (ONE[k][0] === kd) out.push(ONE[k][1]); }
      else for (const k in REC[kd]) out.push(REC[kd][k]);
      return out;
    };
    const dishes = Object.keys(DISH);
    const tabs = [
      { h: '메뉴', n: MENUS.filter((M) => !M.mix).length, build(p) {
        p.append(note('시작 전에 메뉴를 골라요(기본 무작위). 메뉴마다 요리 4가지가 주문으로 들어와요. 재료 상자 · 화구 · 손질대는 메뉴에 맞게 바뀌어요.'));
        MENUS.forEach((M) => {
          if (M.mix) return;
          const s = 48, c = cxCanvas(s, s, (g) => M.d.forEach((id, k) => cxAt((k % 2 + 0.5) * s / 2, ((k / 2 | 0) + 0.5) * s / 2, (q) => drawPlate(q, DISH[id].c, s / 2 * 0.95))(g)));
          const kit = KITCHENS.filter((KD) => KD.menu === M.id).map((KD) => KD.n);
          p.append(row(c, M.n, kit.length ? '추천 주방: ' + kit.join(' · ') : '',
            d('요리: ' + M.d.map((id) => DISH[id].n).join(' · ')),
            d('재료 상자: ' + names(M.raw) + ' / 화구: ' + uniq(M.heat).map((k) => CKP[k].n).join(' · ') + ' / 손질대: ' + uniq(M.work).map((k) => WKP[k].n).join(' · '))));
        });
        p.append(row(h('span', { style: { fontSize: '24px' }, text: '🎲' }), '섞어 차림', '', d('모든 메뉴에서 함께 만들 수 있는 요리 4가지를 골라 섞어요. 판마다 달라요.')));
      } },
      { h: '요리', n: dishes.length, build(p) {
        p.append(note('점수 = 요리 점수 + 빨리 낸 팁(최대 절반). 주문 시간이 다 지나면 −10점. 손이 많이 가는 요리일수록 점수도 시간도 커요.'));
        dishes.forEach((id) => {
          const D = DISH[id], comps = uniq([...D.c]);
          const steps = comps.map((c) => {
            const cnt = [...D.c].filter((q) => q === c).length;
            return h('div', { style: { display: 'flex', alignItems: 'center', gap: '5px', fontSize: '12px', lineHeight: 1.35, color: 'var(--ink)', marginTop: '2px' } },
              itemC(c, 22), h('span', { style: { minWidth: 0 } }, h('b', { text: nameOf(c) + (cnt > 1 ? ' ×' + cnt : '') + ': ' }), howTo(c)));
          });
          const mn = menusOf(id);
          p.append(row(plateC(D.c, 46), D.n, '+' + D.pts + '점 · 주문 ' + D.lim + '초', ...steps, mn.length ? d('메뉴: ' + mn.join(' · ')) : null));
        });
      } },
      { h: '주방', n: KITCHENS.length, build(p) {
        p.append(note('시작 전에 주방을 골라요(기본 무작위). 모두 같은 주방, 같은 주문 순서로 겨뤄요. 주방을 고르면 어울리는 메뉴에 「추천」이 붙어요.'));
        KITCHENS.forEach((KD, ki) => {
          const c = cxCanvas(38, 48, (g) => {
            const ts = Math.min(38 / GW, 48 / GH); g.translate((38 - ts * GW) / 2, (48 - ts * GH) / 2);
            const K = newKitchen(ki, Math.max(0, KD.mi), 1, 60, 1);
            drawStatic(g, K, ts, true);
            if (K.il) K.st.forEach((S) => { if (S.isl) drawStationBase(g, S, S.x * ts, S.y * ts, ts, true, K); });
          });
          const ex = [];
          if (KD.heat) ex.push('익는 속도·타는 속도 ×' + KD.heat);
          if (KD.lim) ex.push('주문 시간 ×' + KD.lim);
          if (KD.night) ex.push('불 세기 ' + NIGHT_P + '초마다 바뀜');
          if (KD.wood) ex.push('모닥불 약 ' + FUEL_T + '초면 꺼져요');
          if (KD.regrow) ex.push('다시 자라는 데 ' + REGROW + '초');
          const M = MENUS[KD.mi];
          p.append(row(c, KD.n, M ? '추천: ' + M.n : '', d(KD.sub + (ex.length ? ' (' + ex.join(' · ') + ')' : ''))));
        });
      } },
      { h: '도구', n: Object.keys(WKP).length + Object.keys(CKP).length + 7, build(p) {
        p.append(sub('손질대 — 올려 두면 저절로 손질 (톡톡 연타하면 더 빨리)'));
        Object.keys(WKP).forEach((k) => p.append(row(glyphC(k, 40), WKP[k].n, WKP[k].v + ' · 약 ' + WKP[k].t + '초', d('만드는 것: ' + names(madeBy(k)))))) ;
        p.append(sub('화구 — 익히기'));
        Object.keys(CKP).forEach((k) => {
          const P = CKP[k];
          p.append(row(glyphC(k, 40), P.n, (P.one ? '하나만 넣어요' : '레시피대로 넣어요') + ' · ' + P.cook + '초',
            d(P.nob ? '타지 않아요.' : '다 익고 ' + P.safe + '초 뒤 「!」 경고, ' + WARN + '초 더 두면 타요. 탄 채 ' + FIRE_T + '초면 불이 나요(눌러서 꺼요).'),
            d('만드는 것: ' + names(madeBy(k)))));
        });
        p.append(sub('그 밖의 것'));
        [['📦', '재료 상자', '빈손으로 누르면 재료를 들어요. 같은 상자를 다시 누르면 도로 넣어요. 접시를 든 채 누르면 접시에 담겨요.'],
          ['▭', '조리대', '아무거나 내려놓는 곳. 접시를 두고 재료를 하나씩 올려 담아도 돼요.'],
          ['🍽', '접시 더미', '빈 접시를 들어요. 재료를 든 채 누르면 바로 접시에 담겨요. 설거지 켜기면 깨끗한 접시는 처음 ' + PLATES + '개.'],
          ['🧽', '개수대', '낸 접시는 ' + RET + '초 뒤 더러운 접시 자리로 돌아와요. 개수대로 가져가 씻어요(연타하면 빨라요).'],
          ['🛎', '창구', '완성 요리를 내는 곳. 주문표에 맞는 요리면 점수 + 팁.'],
          ['🗑', '쓰레기통', '탄 음식이나 잘못 든 것을 버려요. 접시째 버리면 접시는 남아요.'],
          ['🪵', '장작 더미', '캠핑장에만 있어요. 장작을 들고 꺼진 모닥불을 누르면 다시 활활!']]
          .forEach(([ic, n, t]) => p.append(row(h('span', { style: { fontSize: '24px' }, text: ic }), n, '', d(t))));
      } },
    ];
    const bar = h('div', { class: 'chips' }), pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } });
    const show = (k) => {
      pane.textContent = '';
      [...bar.children].forEach((b, i) => b.classList.toggle('on', i === k));
      tabs[k].build(pane);
      const sh = el.closest && el.closest('.sheet'); if (sh) sh.scrollTop = 0;
    };
    tabs.forEach((t, k) => bar.append(h('button', { class: 'btn sm', text: t.h + ' ' + t.n, onclick: () => show(k) })));
    el.append(bar, pane);
    show(0);
  }

  L.register({
    id: 'cooking', name: '요리 대작전', tag: '실시간 요리 경쟁', cat: '아케이드',
    blurb: '똑같은 주방, 똑같은 주문! 재료를 썰고 굽고 튀기고 끓여 접시에 담아 내요. 제일 많이 번 요리사가 승리. 주방 16곳 · 메뉴 22가지 · 요리 80가지 넘게.',
    tint: '#7a3a1e',
    icon: '<path d="M14 24a14 9 0 0 0 28 0z" fill="currentColor"/><rect x="12" y="23" width="32" height="4" rx="2" fill="currentColor"/><path d="M42 25l9-3" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M21 16c0-3 3-3 3-6M28 16c0-3 3-3 3-6M35 16c0-3 3-3 3-6" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/><rect x="10" y="38" width="36" height="5" rx="2.5" fill="currentColor"/><circle cx="20" cy="47" r="2.5" fill="currentColor"/><circle cx="36" cy="47" r="2.5" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'up', label: '위로 걷기', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 걷기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 걷기', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 걷기', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'act', label: '줍기·놓기 / 작업 (앞 조리대)', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'boost', label: '연타 (썰기·설거지·불 끄기)', keys: ['KeyK', 'ShiftLeft'], pad: ['x', 'rb'] },
      { id: 'order', label: '주문 레시피 보기 (다음)', keys: ['KeyE', 'KeyQ'], pad: ['y'] },
    ],
    options: [
      { id: 'time', label: '시간', choices: [{ v: 120, label: '2분' }, { v: 180, label: '3분' }, { v: 240, label: '4분' }], def: 180 },
      { id: 'wash', label: '설거지', tip: '켜면 쓴 접시를 씻어야 다시 쓸 수 있어요.', choices: [{ v: 1, label: '켜기' }, { v: 0, label: '끄기' }], def: 1 },
    ],
    quick: [
      '모두 똑같은 주방, 똑같은 주문! 주문표의 요리를 만들어 창구(종)에 내요.',
      '재료 상자·도마·화구·접시·창구를 톡 누르면 요리사가 알아서 걸어가 일해요.',
      '시간이 끝났을 때 점수(요리 + 빨리 낸 팁)가 가장 높으면 승리. 놓친 주문은 −10점.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 똑같은 주방에서, 똑같은 순서로 들어오는 주문을 요리해요.',
        '시간(기본 3분)이 끝났을 때 점수가 가장 높은 요리사가 승리!',
        '혼자 하면 점수에 따라 별을 0~3개 받아요(위쪽 오른쪽 별 아래 숫자가 기준 점수).',
      ] },
      { h: '조작 (누르기만!)', p: [
        '재료 상자·도마·화구·접시·창구를 톡 누르면 요리사가 알아서 걸어가 알맞은 일을 해요. 바닥을 누르면 그 자리로 가요.',
        '여러 곳을 차례로 누르면 3곳까지 예약돼요(번호 표시). 요리사를 누르면 예약이 취소돼요.',
        '도마에 재료를 놓으면 저절로 썰어요. 도마를 톡톡 연타하면 더 빨리 썰려요. 설거지·불 끄기도 같아요.',
        '썰거나 씻는 도중에 다른 곳을 누르면 바로 멈추고 가요(진행한 만큼은 남아요). 미리 예약해 둔 곳은 일을 끝낸 뒤에 가요.',
        '지금 든 것을 쓸 수 있는 곳은 노랗게 반짝여요. 맨 아래 안내줄이 다음 할 일을 알려 줘요. 주문표를 누르면 만드는 법이 나와요.',
        'PC 키보드·게임패드: 방향키·WASD·왼스틱으로 한 칸씩 걸어요(누르고 있으면 계속). 스페이스·J·Ⓐ = 바라보는 조리대(점선 테두리)에서 줍기·놓기·작업, K·Shift·Ⓧ = 연타, E·Q·Ⓨ = 주문 레시피 넘겨 보기. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '요리하는 법', p: [
        '빈손으로 재료 상자를 누르면 재료를 들어요(같은 상자를 다시 누르면 도로 넣어요). 손에는 한 번에 하나만 들 수 있어요.',
        '손질대 3가지: 도마 = 썰기, 반죽대 = 밀가루 반죽하기, 분쇄기 = 원두·얼음 갈기. 재료를 올려 두면 저절로 손질해요(톡톡 연타하면 더 빨리).',
        '한 개만 익히는 곳: 팬(굽기), 튀김기(튀기기). 재료 하나를 넣으면 바로 익기 시작해요.',
        '레시피대로 넣는 곳: 냄비·오븐·찜기·석쇠(꼬치)·믹서. 레시피 재료를 다 넣어야 익기 시작해요(예: 토마토 수프 = 썬 토마토 3개 → 냄비). 아래 점이 넣은 개수예요.',
        '다 익으면 초록 체크. 그대로 두면 빨간 「!」가 깜빡이다 타 버려요(탄 음식은 빈손으로 꺼내 쓰레기통에). 더 두면 불이 나요. 불난 곳을 누르면 꺼요. 믹서는 타지 않아요.',
        '접시 더미를 누르면 빈 접시를 들어요. 재료를 든 채 접시 더미를 누르면 바로 접시에 담겨요. 접시를 든 채 재료 상자·익은 요리·조리대 위 재료를 누르면 접시에 담겨요. 소스·토핑(양념 소스, 휘핑크림, 딸기 등)도 이렇게 얹어요.',
        '조리대 위에 접시를 두고 재료를 하나씩 올려도 돼요. 완성 요리를 창구(종)에 내면 끝. 주문에 없는 조합은 접시에 안 담겨요.',
        '설거지(켜기): 깨끗한 접시는 처음 4개. 낸 접시는 6초 뒤 더러운 접시 자리로 돌아와요. 개수대로 가져가 씻어요. 끄기면 접시가 무한이에요.',
      ] },
      { h: '점수 · 승리', p: [
        '요리를 내면 요리 점수를 받아요. 손이 많이 가는 요리일수록 점수가 커요(예: 햄버거 25점, 토마토 수프 50점 — 주문표 오른쪽 위 「+숫자」).',
        '팁: 주문표 시간이 많이 남았을 때 낼수록 더 받아요(최대 요리 점수의 절반).',
        '주문표의 시간이 다 지나면 그 주문은 사라지고 10점을 잃어요. 점수는 0 아래로 내려가지 않아요.',
        '주문은 쉬운 요리부터 들어오고, 시간이 지날수록 더 자주, 더 어려운 요리가 섞여 들어와요.',
      ] },
      { h: '메뉴 22가지 + 섞어 차림', p: [
        '주문표를 누르면 그 요리를 만드는 법이 그림과 함께 나와요. 외울 필요 없어요!',
        '버거 가게: 햄버거·치즈버거·야채버거·감자튀김(감자 썰기 → 튀김기). 샐러드·수프: 샐러드·오이 샐러드·토마토 수프·양파 수프.',
        '스시 바: 생선 초밥·오이 마키·생선 마키·생선구이 정식. 분식집: 김밥·주먹밥·떡볶이·라면.',
        '피자·파스타: 치즈 피자·토마토 파스타·치즈 파스타·감자 그라탕. 한식당: 비빔밥·야채 비빔밥·계란밥·떡볶이.',
        '브런치 카페: 팬케이크·딸기 팬케이크·계란 토스트·치즈 토스트. 치킨집: 후라이드 치킨·양념치킨·새우튀김·치킨버거.',
        '중국집: 짜장면·짬뽕·탕수육·깐쇼새우. 길거리 음식: 핫도그·감자튀김·닭꼬치·소떡소떡.',
        '회전 초밥: 생선 초밥·새우 초밥·계란 초밥·된장국. 야시장: 소고기 꼬치·오징어 구이·파인애플 꼬치·버블티.',
        '기차 도시락: 추억의 도시락·김밥·삶은 계란·우동. 캠핑 바비큐: 삼겹살 쌈·군고구마·마시멜로 구이·라면.',
        '우주 식당: 카레라이스·감자 수프·딸기 스무디·바나나 셰이크. 디저트 가게: 딸기 케이크·초코 쿠키·팥빙수·초코 빙수.',
        '카페: 아이스 아메리카노·아이스 라떼·딸기 스무디·레몬에이드. 백반집: 김치찌개·불고기 정식·떡국·김치볶음밥.',
        '분식 포차: 어묵탕·오징어튀김·라볶이·김말이 튀김. 세계 여행: 타코·케밥·쌀국수·팟타이.',
        '스테이크 하우스: 스테이크 정식(스테이크 + 양송이 수프)·크림 파스타·양송이 수프·스테이크 샐러드. 딤섬 가게: 고기 만두·새우 만두·찐빵·계란찜.',
        '섞어 차림: 모든 메뉴에서 네 가지를 골라 섞어요(판마다 달라요). 무작위(기본)는 메뉴 하나를 무작위로 골라요.',
      ] },
      { h: '주방 16곳', p: [
        '시작 전에 주방과 메뉴를 골라요(혼자면 내가, 온라인은 호스트). 기본은 둘 다 무작위. 주방을 고르면 어울리는 메뉴에 「추천」이 붙어요. 재료 상자·화구·손질대는 메뉴에 맞게 바뀌어요.',
        '동네 식당: 넓고 반듯한 기본 주방. 칸막이 주방: 가운데 칸막이 조리대 위로 물건을 넘기거나 아래 틈으로 돌아가요.',
        '컨베이어 주방: 창구에 직접 못 가요. 완성 요리를 맨 아래 컨베이어에 올리면 창구로 실려 가서 나가요.',
        '움직이는 조리대: 가운데 레일 위 화구 조리대가 좌우로 오가요. 길을 막기도 하고, 움직이는 동안은 쓸 수 없어요.',
        '얼음 주방: 파란 얼음에 올라서면 무언가에 막히거나 얼음이 끝날 때까지 미끄러져요. 길은 요리사가 알아서 찾아요.',
        '자동문 주방: 위아래 방 사이 문 두 개가 약 7초마다 번갈아 열려요(닫히기 전 깜빡임).',
        '쥐 소동 주방: 쥐구멍에서 쥐가 나와 조리대 위 음식을 물어 가요. 쥐를 톡 누르거나 요리사가 가까이 가면 놓고 도망가요.',
        '불꽃 주방: 화력이 세서 1.5배 빨리 익고 그만큼 빨리 타요.',
        '푸드트럭: 한 사람만 지나가는 좁은 통로가 고리처럼 이어져요. 가운데 조리대는 양쪽 통로에서 써요.',
        '회전 초밥집: 손님이 가운데 앉아 있어요. 완성 접시를 회전 레일에 올리면 빙글 돌다가 주문한 손님이 가져가요.',
        '야시장 포장마차: 불 세기가 12초마다 약·중·강으로 바뀌어요(왼쪽 위 표시, 바뀌기 2초 전 알림). 강불은 빨리 익고 빨리 타요.',
        '기차 식당칸: 10~13초마다 기차가 덜컹 흔들려요(1초 전 알림). 그때 요리사는 1초쯤 멈춰요. 손질·익히기는 계속돼요.',
        '캠핑장: 화구가 모닥불이에요. 모닥불은 약 40초면 다 타서 꺼지고, 꺼지면 익지 않아요(타지도 않아요). 장작 더미에서 장작을 들고 모닥불을 누르면 다시 활활!',
        '우주 정거장: 무중력이라 조리대에 둔 물건이 10초쯤마다 하나씩 둥실 떠서 다른 빈 조리대로 옮겨 가요(도마 위 물건은 그대로).',
        '마법사 주방: 위아래 방이 벽으로 나뉘어 있고 보라색 마법 문(순간이동)으로만 오가요. 가운데 조리대로 물건을 건넬 수도 있어요.',
        '텃밭 주방: 재료 상자가 텃밭이에요. 재료를 따면 다시 자랄 때까지 3.5초 기다려야 해요(초록 고리).',
      ] },
      { h: '팁', p: [
        '기다리는 동안 손을 놀리지 마세요. 냄비가 끓는 사이에 다음 재료를 썰어 둬요.',
        '시간이 가장 적게 남은 주문부터! 주문표 아래 막대가 짧고 빨간 것이 급해요.',
        '여러 곳을 미리 눌러 예약해 두면 요리사가 쉬지 않고 움직여요.',
        '다 익은 요리는 곧 타요. 초록 체크가 뜨면 바로 꺼내요.',
      ] },
      { h: '예시 — 햄버거 만들기', p: [
        '① 생고기 상자 톡 → 고기를 들어요. ② 팬(화구) 톡 → 고기를 올려 구워요.',
        '③ 기다리는 동안 접시 더미 톡 → 빈 접시를 들어요. ④ 빵 상자 톡 → 빵이 접시에 담겨요.',
        '⑤ 패티에 초록 체크가 뜨면 팬 톡 → 패티도 접시에 담겨 햄버거 완성! ⑥ 창구(종) 톡 → 25점 + 팁.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 요리해요. 혼자 하면 나머지 자리는 AI 요리사예요(각자 자기 주방, 주문 순서는 모두 같아요).',
        '친구와는 온라인·LAN 방으로: 각자 폰에서 자기 주방을 요리하고, 위쪽 줄에서 서로의 점수가 실시간으로 보여요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 느리고 가끔 엉뚱한 재료를 꺼내요. 어려움은 빠르게 연타하고 여러 주문을 한꺼번에 챙겨요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount, codex,
    _t: { drawItem, drawPlate, drawGlyph, IT, WORK, WK, WKP, ONE, REC, CKP, DISH, MENUS, KITCHENS, SRC, menuOf, mixMenu, menuInfo, MIX_MI, resultOf, cooking, canWork, starNeed, newKitchen, stepK, tapK, cancelK, interact, aiThink, aiDecide, analyse, dijkstra, pathSteps, goalTiles, walk, fits, acceptsCook, findOrder, shoo, startMatch, finish, starsOf, msub, srt, genSeq, GW, GH },
  });
})();
