/* 그림 로직 — 혼자 즐기는 숫자 그림 퍼즐(노노그램 방식).
   Two kinds of puzzles:
   - 그림 모음: 30 hand-drawn pixel pictures (original). If the line solver can't finish one alone, the fewest
     "given" cells (pre-marked, locked) are added deterministically so every picture is solvable by pure line logic.
   - 끝없는 퍼즐: seeded random grids 5×5 / 10×10 / 15×15 / 20×20 — kept only when the line solver solves them completely
     (so they are unique and need no guessing); level N of a size is always the same grid.
   State: g = string of cells '0' empty · '1' filled · '2' X. Solution is never in the state (derived from the key).
   Progress (solved pictures, endless level per size, in-progress grid) lives in localStorage — progress only. */
(function () {
  const L = window.Lounge, U = L.util;
  /* ---------- 오늘의 퍼즐 (날짜 YYYYMMDD 씨앗 → 모두 같은 퍼즐). 기록·연속 일수는 이 기기에만, 지난 7일치만 남김 ---------- */
  function mkDaily(gid, short, fmt, lower) {
    const SK = 'lounge.daily.' + gid;
    const ymd = (d) => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
    const toD = (n) => new Date(Math.floor(n / 10000), Math.floor(n / 100) % 100 - 1, n % 100, 12);
    const shift = (n, k) => { const d = toD(n); d.setDate(d.getDate() + k); return ymd(d); };
    const rd = () => { try { return JSON.parse(localStorage.getItem(SK) || '{}') || {}; } catch (e) { return {}; } };
    const wr = (o) => { try { localStorage.setItem(SK, JSON.stringify(o)); } catch (e) {} };
    const D = {
      today: () => ymd(new Date()),
      md: (n) => (Math.floor(n / 100) % 100) + '/' + (n % 100),
      long: (n) => (Math.floor(n / 100) % 100) + '월 ' + (n % 100) + '일',
      seed(n) { let h = (n >>> 0) ^ 0x9e3779b9; h = Math.imul(h ^ (h >>> 16), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; },
      score: (n) => { const o = rd(); return o.done ? o.done[n] : undefined; },
      streak() { const o = rd(), t = D.today(); return o.last && (o.last === t || o.last === shift(t, -1)) ? o.st | 0 : 0; },
      prune() {
        const o = rd(), cut = shift(D.today(), -6);
        if (o.done) for (const k in o.done) if (+k < cut) delete o.done[k];
        wr(o);
        try { const all = U.store.get('best.' + gid, {}); let ch = 0; for (const k in all) if (/^d\d{8}$/.test(k) && +k.slice(1) < cut) { delete all[k]; ch = 1; } if (ch) U.store.set('best.' + gid, all); } catch (e) {}
      },
      /* 완료 기록 → 새 최고면 true */
      complete(n, sc, api) {
        const o = rd(); o.done = o.done || {};
        const old = o.done[n], first = old == null;
        if (first || (lower ? sc < old : sc > old)) o.done[n] = sc;
        if (first) { o.st = o.last === shift(n, -1) ? (o.st | 0) + 1 : o.last === n ? o.st | 0 || 1 : 1; if (!o.last || n > o.last) o.last = n; }
        wr(o);
        if (api) api.best('d' + n, sc, { label: '오늘의 퍼즐 ' + D.md(n), lower: !!lower, unit: fmt === 'time' ? '' : fmt, fmt: fmt === 'time' ? 'time' : '' });
        D.prune();
        return !first && o.done[n] === sc && sc !== old;
      },
      text(n) {
        const sc = D.score(n);
        const v = fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt;
        return '한판 라운지 ' + short + ' ' + D.md(n) + ' ✓ ' + v + ' · 연속 ' + Math.max(1, D.streak()) + '일';
      },
      share(n, api) {
        const t = D.text(n), ok = () => api && api.toast('복사했어요: ' + t);
        const fb = () => { try { const ta = L.h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); ok(); } catch (e) { if (api) api.toast(t); } };
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb(); } catch (e) { fb(); }
      },
      fmtScore(sc) { return sc == null ? '' : fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt; },
      /* 단계/모드 고르기 맨 위에 넣는 큰 카드 */
      card(onPlay, api, sub) {
        const n = D.today(), sc = D.score(n), st = D.streak();
        const box = L.h('div', { class: 'daily-card', style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '12px', borderRadius: '14px', border: '2px solid var(--brass,#e3ae45)', background: 'linear-gradient(135deg,rgba(227,174,69,.22),rgba(227,174,69,.06))' } });
        const head = L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } });
        head.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', lineHeight: '1.2' } },
          L.h('b', { style: { fontSize: '18px' }, text: '📅 오늘의 퍼즐' }),
          L.h('span', { class: 'muted', style: { fontSize: '13px' }, text: D.long(n) + (sub ? ' · ' + sub : '') })),
          L.h('div', { style: { textAlign: 'right', lineHeight: '1.2', fontSize: '13px' } },
            L.h('div', { style: { fontSize: '15px', fontWeight: '700', color: sc != null ? '#8fd14f' : 'inherit' }, text: sc != null ? '완료 ✓' : '미완료' }),
            L.h('div', { class: 'muted', text: '🔥 연속 ' + st + '일' })));
        box.append(head);
        if (sc != null) box.append(L.h('div', { style: { fontSize: '13px' }, text: '오늘 최고 ' + D.fmtScore(sc) }));
        const row = L.h('div', { style: { display: 'flex', gap: '6px' } });
        row.append(L.h('button', { class: 'btn primary', style: { flex: '1', minHeight: '48px' }, text: sc != null ? '다시 도전 ▶' : '도전하기 ▶', onclick: () => onPlay(n) }));
        if (sc != null) row.append(L.h('button', { class: 'btn', style: { flex: '0 0 auto', minHeight: '48px', padding: '0 14px' }, text: '📋 공유', onclick: () => D.share(n, api) }));
        box.append(row);
        return box;
      },
    };
    return D;
  }
  const KEY = 'lounge.nonogram';
  const REV_MS = 2200;
  function store() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }

  const PAL = {
    k: '#2b2733', w: '#fbf8f1', r: '#e04a3f', o: '#f39a2b', y: '#f2c43a', g: '#5cb85c', G: '#2f7d4a', l: '#a6dc6e',
    b: '#3f86e0', B: '#26407a', c: '#7cc9ee', p: '#ec7fb6', v: '#8a5fd6', n: '#9a6337', N: '#5c3b22', s: '#b9b4ac',
    S: '#6f6a72', t: '#e8d2a6',
  };
  /* ---------- 그림 모음 (original pixel art) ---------- */
  const PICS = [
    ['하트', ['..rr..rr..', '.rwrrrrrr.', 'rwrrrrrrrr', 'rrrrrrrrrr', 'rrrrrrrrrr', '.rrrrrrrr.', '..rrrrrr..', '...rrrr...', '....rr....', '..........']],
    ['버섯', ['...rrrr...', '.rrwwrrrr.', 'rrwwrrrwwr', 'rrrrrrrwwr', 'rwwrrrrrrr', 'rrrrrrrrrr', '...tttt...', '...tttt...', '...tttt...', '..tttttt..']],
    ['고양이', ['o........o', 'oo......oo', 'oooooooooo', 'oykooooyko', 'oooooooooo', 'ooooppoooo', 'oooooooooo', '.oooooooo.', '..oooooo..', '..........']],
    ['나무', ['...gggg...', '..gggggg..', '.gggGgggg.', 'gggggggGgg', 'gGgggggggg', '.gggggGgg.', '..gggggg..', '....nn....', '....nn....', '..nnnnnn..']],
    ['집', ['....rr....', '...rrrr...', '..rrrrrr..', '.rrrrrrrr.', 'rrrrrrrrrr', '.tttttttt.', '.tbbttnnt.', '.tbbttnnt.', '.tttttnnt.', '.tttttnnt.']],
    ['물고기', ['..........', '....cc....', '...bbbb...', '.bbbbbbb.b', 'bbkbbbbbbb', 'bbbbbbbbbb', '.bbbbbbb.b', '...bbbb...', '....cc....', '..........']],
    ['별', ['....yy....', '....yy....', '...yyyy...', 'yyyyyyyyyy', '.yyyyyyyy.', '..yyyyyy..', '..yyyyyy..', '.yyy..yyy.', '.yy....yy.', 'y........y']],
    ['우산', ['....vv....', '..vvvvvv..', '.vvvvvvvv.', 'vvvvvvvvvv', 'v..v..v..v', '....k.....', '....k.....', '....k.....', '....k.k...', '.....k....']],
    ['커피잔', ['..s..s....', '...s..s...', '..s..s....', 'cccccccc..', 'cnnnnnnccc', 'cccccccc.c', 'cccccccccc', '.cccccc...', '..cccc....', 'ssssssss..']],
    ['열쇠', ['..........', '..........', '.yyy......', 'yy.yy.....', 'y...yyyyyy', 'yy.yy..y.y', '.yyy...y.y', '..........', '..........', '..........']],
    ['사과', ['.....n....', '.....ngg..', '.rrrrnrrr.', 'rrwrrrrrrr', 'rwrrrrrrrr', 'rrrrrrrrrr', 'rrrrrrrrrr', '.rrrrrrrr.', '.rrrrrrrr.', '..rr..rr..']],
    ['로켓', ['....rr....', '...ssss...', '...ssss...', '...sbbs...', '...sbbs...', '...ssss...', '..rssssr..', '.rrssssrr.', '.r.oooo.r.', '...o..o...']],
    ['나비', ['vv......vv', 'vvv.kk.vvv', 'vpvvkkvvpv', 'vvvvkkvvvv', '.vvvkkvvv.', '..vvkkvv..', '.vvvkkvvv.', 'vvpvkkvpvv', 'vvvv..vvvv', '.vv....vv.']],
    ['해', ['....yy....', '.y..yy..y.', '..yyyyyy..', '.yyooooyy.', 'yyooooooyy', 'yyooooooyy', '.yyooooyy.', '..yyyyyy..', '.y..yy..y.', '....yy....']],
    ['음표', ['...kkkkkkk', '...kkkkkkk', '...k.....k', '...k.....k', '...k.....k', '...k.....k', '.kkk...kkk', 'kkkk..kkkk', 'kkkk..kkkk', '.kk....kk.']],
    ['닻', ['....BB....', '...B..B...', '....BB....', '..BBBBBB..', '....BB....', '....BB....', 'B...BB...B', 'BB..BB..BB', '.BBBBBBBB.', '...BBBB...']],
    ['펭귄', ['...kkkk...', '..kkkkkk..', '..kwkkwk..', '..kkookk..', '.kkwwwwkk.', 'kkwwwwwwkk', 'kkwwwwwwkk', '.kwwwwwwk.', '..kwwwwk..', '..oo..oo..']],
    ['선인장', ['....gg....', '...gggg...', 'g..gggg...', 'g..gggg..g', 'ggggggg..g', '...ggggggg', '...gggg...', '...gggg...', '.nnnnnnnn.', '..nnnnnn..']],
    ['파랑새', ['..........', '...bbb....', '..bbkbb...', 'oobbbbb...', '..bbbbbb..', '..bcccbbbb', '..bccccbbb', '...bbbbbb.', '.....o.o..', '....oo.oo.']],
    ['왕관', ['y...yy...y', 'yy..yy..yy', 'yyy.yy.yyy', 'yyyyyyyyyy', 'yryyyyyyry', 'yyyybbyyyy', 'yyyyyyyyyy', '..........', '.yyyyyyyy.', '..........']],
    ['전구', ['...yyyy...', '..yyyyyy..', '.yyywyyyy.', '.yywyyyyy.', '.yyyyyyyy.', '..yyyyyy..', '...yyyy...', '...ssss...', '...SSSS...', '....ss....']],
    ['체리', ['......ggg.', '.....g.g..', '....g..g..', '...g...g..', '..g....g..', '.rrr..rrr.', 'rwrr..rwrr', 'rrrr..rrrr', 'rrrr..rrrr', '.rr....rr.']],
    ['고래', ['..........', '...c.c....', '....c.....', '..bbbbb..b', '.bbbbbbbbb', 'bkbbbbbbb.', 'bbbbbbbbb.', 'bcccccbb..', '.bbbbbb...', '..........']],
    ['트로피', ['.yyyyyyyy.', 'yyyyyyyyyy', 'y.yyyyyy.y', 'y.yyyyyy.y', '.yyyyyyyy.', '...yyyy...', '....yy....', '....yy....', '..nnnnnn..', '..nnnnnn..']],
    ['꽃', ['......ppp......', '...ppppppppp...', '..ppppppppppp..', '.ppppyyyyypppp.', '.pppyyyyyyyppp.', '.pppyyoyoyyppp.', '.pppyyyyyyyppp.', '..ppyyyyyyypp..', '...pppppppppp..', '.......g.......', '..gg...g...gg..', '...ggg.g.ggg...', '.....ggggg.....', '.......g.......', '...nnnnnnnnn...']],
    ['돛단배', ['.......k.......', '.......kw......', '......wkww.....', '.....wwkwww....', '....wwwkwwww...', '...wwwwkwwwww..', '..wwwwwkwwwwww.', '.......k.......', 'nnnnnnnnnnnnnnn', '.nnnnnnnnnnnnn.', '..nnnnnnnnnnn..', 'bbbbbbbbbbbbbbb', '.bbb.bbbb.bbbb.', 'bbbbbbbbbbbbbbb', '...............']],
    ['거북', ['...............', '......lll......', '.....lllll.....', 'll...GGGGG...ll', 'lll.GGgGgGG.lll', '.lGGgggGgggGGl.', '..GgggGGGgggG..', '..GGGGGgGGGGG..', '..GgggGGGgggG..', '.lGGgggGgggGGl.', 'lll.GGgGgGG.lll', 'll...GGGGG...ll', '......lll......', '.......l.......', '...............']],
    ['부엉이', ['..nn.......nn..', '..nnn.....nnn..', '..nnnnnnnnnnn..', '.nnwwwnnnwwwnn.', '.nwwkkwnwkkwwn.', '.nwwkkwnwkkwwn.', '.nnwwwnonwwwnn.', '.nnnnnnonnnnnn.', '.nntttttttttnn.', '.nntntntntntnn.', '.nntttttttttnn.', '..nntntntntnn..', '...nntttttnn...', '....oo...oo....', 'NNNNNNNNNNNNNNN']],
    ['등대', ['......yyy......', '....y.kkk.y....', '......rrr......', '.....kkkkk.....', '......rrr......', '......www......', '......rrr......', '.....wwwww.....', '.....rrrrr.....', '.....wwwww.....', '....rrrrrrr....', '....wwwnwww....', '...rrrrnrrrr...', '..sssssssssss..', 'bbbbbbbbbbbbbbb']],
    ['로봇', ['.......r.......', '.......s.......', '...sssssssss...', '...sSSSSSSSs...', '...sScSSScSs...', '...sSSSSSSSs...', '...sSrrrrrSs...', '...sssssssss...', '.....sssss.....', '.bsssssssssssb.', '.b.ssSyyySss.b.', '.b.sssssssss.b.', '...sssssssss...', '....ss...ss....', '...SSS...SSS...']],
    ['설산과 달', ['..........yy...', '.........yyyy..', '.........yyyy..', '..........yy...', '...............', '.....w.........', '....www.....w..', '...wwSSs...www.', '..wSSSSSs.wSSs.', '.SSSSSSSSsSSSSs', 'SSSSSSSSSSSSSSS', 'GGGSSSGGGGGSSGG', 'GGGGGGGGGGGGGGG', 'gGgGgGgGgGgGgGg', 'ggggggggggggggg']],
    ['찻주전자', ['......NN.......', '.....NnnN......', '....nnnnnn.....', '..nnnnnnnnnn...', '.nnttttttttnn..', 'nnnnnnnnnnnnnnn', 'n.nnnnnnnnnnn.n', 'n.nnnnnnnnnnn.n', '.nnnnnnnnnnnnn.', '..nnnnnnnnnnn..', '...nnnnnnnnn...', '....nnnnnnn....', '...............', '.sssssssssssss.', '...............']],
  ];

  /* 무작위 퍼즐용 색 팔레트 — 칸 덩어리(이웃한 칸끼리)마다 큰 것부터 차례로 배정 */
  const CPALS = [
    ['노을 하늘', ['#e8734a', '#f2b05e', '#b8496b', '#5a3e7a', '#f6d38a']],
    ['깊은 숲', ['#2f6b4a', '#5f9a58', '#a7c46b', '#7a5a3a', '#d8c27a']],
    ['바다 유리', ['#2c7da0', '#61a5c2', '#a9d6e5', '#1b4965', '#89c2b0']],
    ['가을 단풍', ['#c0392b', '#e67e22', '#d4a537', '#7b3f2a', '#9c6b3c']],
    ['새벽 안개', ['#6c7a99', '#a3b1c6', '#c9b8d8', '#4e5a75', '#e6d5c3']],
    ['사막 모래', ['#c98b54', '#e2b77d', '#a8583a', '#7d6b55', '#efd9a8']],
    ['밤의 도시', ['#3a3f8f', '#f2c14e', '#e2557a', '#5bc0be', '#22264f']],
    ['석류와 대리석', ['#9b2335', '#d9a5a0', '#5e4b56', '#c8bfb5', '#7d1f2c']],
    ['이끼 정원', ['#4f6d3a', '#8aa65b', '#c4c99a', '#3d4a2f', '#a68a64']],
    ['북극광', ['#3ddc97', '#4a8fe7', '#9d6bd6', '#1f3b5a', '#b8f2e6']],
  ];
  function compColors(sol, N, seed) {
    const pal = CPALS[seed % CPALS.length], comp = new Array(N * N).fill(-1), sizes = [];
    for (let i = 0; i < N * N; i++) {
      if (!sol[i] || comp[i] >= 0) continue;
      const id = sizes.length, st = [i]; comp[i] = id; let n = 0;
      while (st.length) {
        const j = st.pop(); n++; const r = Math.floor(j / N), c = j % N;
        for (const [rr, cc] of [[r - 1, c], [r + 1, c], [r, c - 1], [r, c + 1]]) {
          if (rr < 0 || cc < 0 || rr >= N || cc >= N) continue;
          const k = rr * N + cc; if (sol[k] && comp[k] < 0) { comp[k] = id; st.push(k); }
        }
      }
      sizes.push(n);
    }
    const order = sizes.map((n, i) => i).sort((a, b) => sizes[b] - sizes[a] || a - b), cof = [];
    order.forEach((id, rank) => { cof[id] = pal[1][(rank + seed) % pal[1].length]; });
    return { col: sol.map((v, i) => (v ? cof[comp[i]] : null)), name: pal[0] };
  }
  /* 색 → 회색(밝기) · 섞기: 완성 연출에서 흑백 → 색으로 */
  const rgbCache = {};
  function rgbOf(col) {
    if (rgbCache[col]) return rgbCache[col];
    let m, v = [44, 40, 56];
    if ((m = /^#([0-9a-f]{6})$/i.exec(col))) { const n = parseInt(m[1], 16); v = [n >> 16, (n >> 8) & 255, n & 255]; }
    return (rgbCache[col] = v);
  }
  function grayOf(col) { const [r, g, b] = rgbOf(col), y = Math.round(0.3 * r + 0.59 * g + 0.11 * b); return [y, y, y]; }
  function mixRGB(a, b, k) { return 'rgb(' + Math.round(a[0] + (b[0] - a[0]) * k) + ',' + Math.round(a[1] + (b[1] - a[1]) * k) + ',' + Math.round(a[2] + (b[2] - a[2]) * k) + ')'; }

  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ---------- clues & line solver ---------- */
  function runs(arr) { const out = []; let n = 0; for (const v of arr) { if (v === 1) n++; else if (n) { out.push(n); n = 0; } } if (n) out.push(n); return out; }
  function cluesOf(sol, N) {
    const rows = [], cols = [];
    for (let r = 0; r < N; r++) { const a = []; for (let c = 0; c < N; c++) a.push(sol[r * N + c]); rows.push(runs(a)); }
    for (let c = 0; c < N; c++) { const a = []; for (let r = 0; r < N; r++) a.push(sol[r * N + c]); cols.push(runs(a)); }
    return { rows, cols };
  }
  /* line: array of 0 unknown · 1 filled · 2 empty. Returns new array (deduced) or null if contradiction. */
  function solveLine(line, clue) {
    const n = line.length, k = clue.length, memo = new Map(), canF = new Uint8Array(n), canE = new Uint8Array(n);
    function rec(pos, j) {
      const key = pos * 32 + j;
      if (memo.has(key)) return memo.get(key);
      let ok = false;
      if (j === k) {
        ok = true;
        for (let i = pos; i < n; i++) if (line[i] === 1) { ok = false; break; }
        if (ok) for (let i = pos; i < n; i++) canE[i] = 1;
      } else if (pos < n) {
        if (line[pos] !== 1 && rec(pos + 1, j)) { canE[pos] = 1; ok = true; }
        const len = clue[j];
        if (pos + len <= n) {
          let fit = true;
          for (let i = pos; i < pos + len; i++) if (line[i] === 2) { fit = false; break; }
          if (fit && pos + len < n && line[pos + len] === 1) fit = false;
          if (fit) {
            const nx = pos + len < n ? pos + len + 1 : n;
            if (rec(nx, j + 1)) { for (let i = pos; i < pos + len; i++) canF[i] = 1; if (pos + len < n) canE[pos + len] = 1; ok = true; }
          }
        }
      }
      memo.set(key, ok);
      return ok;
    }
    if (!rec(0, 0)) return null;
    const out = line.slice();
    for (let i = 0; i < n; i++) {
      if (canF[i] && !canE[i]) out[i] = 1; else if (canE[i] && !canF[i]) out[i] = 2; else if (!canF[i] && !canE[i]) return null;
    }
    return out;
  }
  /* full grid line logic; g = array 0/1/2 (modified in place). Returns number of unknown cells left (−1 contradiction). */
  function solveGrid(g, cl, N) {
    const dirtyR = new Uint8Array(N).fill(1), dirtyC = new Uint8Array(N).fill(1);
    let any = true;
    while (any) {
      any = false;
      for (let r = 0; r < N; r++) {
        if (!dirtyR[r]) continue; dirtyR[r] = 0;
        const line = []; for (let c = 0; c < N; c++) line.push(g[r * N + c]);
        const o = solveLine(line, cl.rows[r]); if (!o) return -1;
        for (let c = 0; c < N; c++) if (o[c] !== line[c]) { g[r * N + c] = o[c]; dirtyC[c] = 1; any = true; }
      }
      for (let c = 0; c < N; c++) {
        if (!dirtyC[c]) continue; dirtyC[c] = 0;
        const line = []; for (let r = 0; r < N; r++) line.push(g[r * N + c]);
        const o = solveLine(line, cl.cols[c]); if (!o) return -1;
        for (let r = 0; r < N; r++) if (o[r] !== line[r]) { g[r * N + c] = o[r]; dirtyR[r] = 1; any = true; }
      }
    }
    let u = 0; for (const v of g) if (!v) u++;
    return u;
  }

  /* ---------- puzzle data by key ---------- */
  const cache = {};
  const SIZES = [5, 10, 15, 20];
  const DAILY = mkDaily('nonogram', '그림 로직', 'time', true);
  // 오늘의 퍼즐 크기: 주말(토·일) 15×15, 평일 10×10
  const dailyN = (n) => { const d = new Date(Math.floor(n / 10000), Math.floor(n / 100) % 100 - 1, n % 100, 12).getDay(); return d === 0 || d === 6 ? 15 : 10; };
  function genEndless(N, lv, seed) {
    for (let at = 0; at < 400; at++) {
      const r = prng(seed ? (seed + at * 104729) >>> 0 : N * 1000003 + lv * 7919 + at * 104729 + 11);
      const dens = 0.52 + r() * 0.12;
      const sol = [];
      for (let i = 0; i < N * N; i++) sol.push(r() < dens ? 1 : 0);
      const cl = cluesOf(sol, N);
      if (cl.rows.some((x) => !x.length) || cl.cols.some((x) => !x.length)) continue;
      const g = new Array(N * N).fill(0);
      if (solveGrid(g, cl, N) === 0) return { sol, cl, hue: Math.floor(r() * 360) };
    }
    return null;
  }
  function puzzle(key) {
    if (cache[key]) return cache[key];
    let P = null, m;
    if ((m = /^p(\d+)$/.exec(key))) {
      const pi = +m[1], pic = PICS[pi]; if (!pic) return null;
      const art = pic[1], N = art.length, sol = [], col = [];
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) { const ch = art[r][c]; sol.push(ch === '.' ? 0 : 1); col.push(ch === '.' ? null : PAL[ch]); }
      const cl = cluesOf(sol, N);
      // givens: add cells until line logic alone finishes the puzzle
      const giv = [];
      for (;;) {
        const g = new Array(N * N).fill(0);
        for (const i of giv) g[i] = sol[i] ? 1 : 2;
        if (solveGrid(g, cl, N) <= 0) break;
        const unk = []; for (let i = 0; i < N * N; i++) if (!g[i]) unk.push(i);
        const fil = unk.filter((i) => sol[i]);
        const pick = (fil.length ? fil : unk);
        giv.push(pick[Math.floor(pick.length / 2)]);
      }
      P = { key, N, sol, cl, col, giv, name: pic[0], pic: pi };
    } else if ((m = /^e(\d+)-(\d+)$/.exec(key))) {
      const N = +m[1], lv = +m[2];
      if (SIZES.indexOf(N) < 0 || lv < 1 || lv > 99999) return null;
      const e = genEndless(N, lv); if (!e) return null;
      const cc = compColors(e.sol, N, e.hue);
      P = { key, N, sol: e.sol, cl: e.cl, col: cc.col, cname: cc.name, giv: [], lv, size: N, hue: e.hue };
    } else if ((m = /^d(\d{8})$/.exec(key))) {
      const dy = +m[1]; if (dy < 20000101 || dy > 29991231) return null;
      const N = dailyN(dy), e = genEndless(N, 1, DAILY.seed(dy)); if (!e) return null;
      const cc = compColors(e.sol, N, e.hue);
      P = { key, N, sol: e.sol, cl: e.cl, col: cc.col, cname: cc.name, giv: [], dy, hue: e.hue };
    }
    if (P) { P.gset = new Set(P.giv); cache[key] = P; }
    return P;
  }
  function blankGrid(P) { const g = new Array(P.N * P.N).fill('0'); for (const i of P.giv) g[i] = P.sol[i] ? '1' : '2'; return g.join(''); }
  function lineOk(g, P, isRow, k) {
    const N = P.N, a = [];
    for (let i = 0; i < N; i++) a.push(g[isRow ? k * N + i : i * N + k] === '1' ? 1 : 0);
    const want = isRow ? P.cl.rows[k] : P.cl.cols[k], got = runs(a);
    return got.length === want.length && got.every((x, i) => x === want[i]);
  }
  function solvedAll(g, P) { for (let k = 0; k < P.N; k++) if (!lineOk(g, P, true, k) || !lineOk(g, P, false, k)) return false; return true; }
  function label(P) { return P.dy ? '오늘의 퍼즐 ' + DAILY.md(P.dy) : P.pic != null ? '그림 ' + (P.pic + 1) : P.N + '×' + P.N + ' · ' + P.lv + '번'; }

  function newPuzzle(s, key, strict) {
    const P = puzzle(key) || puzzle('p0');
    s.k = P.key; s.N = P.N; s.g = blankGrid(P); s.st = strict ? 1 : 0; s.lf = strict ? 3 : 0; s.mi = 0; s.h = 3;
    s.u = []; s.won = 0; s.lost = 0; s.end = 0;
    s.last = { id: (s.last ? s.last.id : 0) + 1, t: 'new' };
    return s;
  }
  const enc36 = (i) => (i < 36 ? '0' : '') + i.toString(36);
  function setCells(s, P, changes, list) { const g = s.g.split(''); for (const [i, v] of list) { if (g[i] !== v) { changes.push(enc36(i) + g[i]); g[i] = v; } } s.g = g.join(''); }
  function autoX(s, P, rowsTouched, colsTouched, changes) {
    const N = P.N, g = s.g.split(''), ax = [], done = [];
    const chk = (isRow, k) => {
      if (!lineOk(g, P, isRow, k)) return;
      done.push((isRow ? 'r' : 'c') + k);
      for (let i = 0; i < N; i++) { const q = isRow ? k * N + i : i * N + k; if (g[q] === '0') { changes.push(enc36(q) + '0'); g[q] = '2'; ax.push(q); } }
    };
    rowsTouched.forEach((r) => chk(true, r)); colsTouched.forEach((c) => chk(false, c));
    s.g = g.join('');
    return { ax, done };
  }
  function pushUndo(s, changes) {
    if (!changes.length) return;
    s.u.push(changes.join(''));
    let tot = s.u.reduce((a, x) => a + x.length, 0);
    while (s.u.length > 1 && (s.u.length > 40 || tot > 900)) { tot -= s.u[0].length; s.u.shift(); }
  }

  const def = {
    id: 'nonogram', name: '그림 로직', tag: '숫자 그림 퍼즐', cat: '보드',
    blurb: '줄마다 적힌 숫자만큼 칸을 칠해요. 다 맞히면 숨은 그림이 나타나요. 그림 모음 32개 + 끝없는 퍼즐.',
    tint: '#2c3d5c',
    icon: '<rect x="18" y="18" width="30" height="30" rx="2" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="21" y="21" width="7" height="7" fill="currentColor"/><rect x="29.5" y="21" width="7" height="7" fill="currentColor"/><rect x="29.5" y="29.5" width="7" height="7" fill="currentColor"/><rect x="38" y="29.5" width="7" height="7" fill="currentColor"/><rect x="21" y="38" width="7" height="7" fill="currentColor"/><path d="M39 39l5 5M44 39l-5 5" stroke="currentColor" stroke-width="2"/><text x="10" y="27" font-size="9" font-family="sans-serif" font-weight="700" fill="currentColor" text-anchor="middle">2</text><text x="10" y="36" font-size="9" font-family="sans-serif" font-weight="700" fill="currentColor" text-anchor="middle">2</text><text x="10" y="45" font-size="9" font-family="sans-serif" font-weight="700" fill="currentColor" text-anchor="middle">1</text><text x="24.5" y="13" font-size="9" font-family="sans-serif" font-weight="700" fill="currentColor" text-anchor="middle">2</text><text x="33" y="13" font-size="9" font-family="sans-serif" font-weight="700" fill="currentColor" text-anchor="middle">2</text><text x="41.5" y="13" font-size="9" font-family="sans-serif" font-weight="700" fill="currentColor" text-anchor="middle">1</text>',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, noAI: true, hidden: false, aiDelay: 350,
    options: [{ id: 'mist', label: '실수', tip: '틀린 칸을 칠할 때.', choices: [{ v: 'strict', label: '목숨 3개', tip: '틀리면 목숨 −1, 3번 틀리면 실패.' }, { v: 'free', label: '자유롭게', tip: '틀려도 계속, 다 맞으면 완성.' }], def: 'strict' }],
    controls: [
      { id: 'up', label: '위', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'fill', label: '칠하기', keys: ['Space', 'KeyJ'], pad: ['a'] },
      { id: 'mark', label: 'X 표시', keys: ['KeyX', 'KeyK'], pad: ['x'] },
      { id: 'mode', label: '칠하기/X 바꾸기', keys: ['KeyQ', 'Tab'], pad: ['y'] },
      { id: 'undo', label: '되돌리기', keys: ['KeyZ', 'Backspace'], pad: ['b'] },
      { id: 'hint', label: '힌트', keys: ['KeyH'], pad: ['rb'] },
      { id: 'zoom', label: '확대', keys: ['KeyE'], pad: ['lb'] },
    ],
    quick: [
      '숫자는 그 줄에 칠해진 칸 덩어리의 길이예요. 「3 1」 = 3칸 덩어리, 한 칸 이상 띄고, 1칸 덩어리.',
      '칸을 누르거나 끌어서 칠해요. 확실히 빈 칸은 X 모드로 표시해 두면 편해요.',
      '모든 줄을 맞히면 숨은 그림 완성! 목숨 3개 모드에선 틀린 칸을 칠하면 목숨이 줄어요.',
    ],
    rules: [
      { h: '목표', p: ['가로줄 왼쪽, 세로줄 위의 숫자에 맞게 칸을 칠해서 숨은 그림을 찾아요.'] },
      { h: '그림으로 보기', fig: [{ svg: "<svg viewBox=\"0 0 340 118\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"118\" rx=\"10\" fill=\"#1d2230\"/><text x=\"60\" y=\"29\" font-size=\"13\" fill=\"#e3ae45\" text-anchor=\"end\" font-weight=\"700\">3 1</text><rect x=\"70\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"92\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"114\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"136\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"158\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><text x=\"168\" y=\"29\" font-size=\"12\" fill=\"#999\" text-anchor=\"middle\" font-weight=\"400\">✕</text><rect x=\"180\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"202\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"224\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"246\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"268\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><text x=\"310\" y=\"29\" font-size=\"14\" fill=\"#9fd59f\" text-anchor=\"middle\" font-weight=\"700\">O</text><text x=\"60\" y=\"63\" font-size=\"13\" fill=\"#e3ae45\" text-anchor=\"end\" font-weight=\"700\">3 1</text><rect x=\"70\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"92\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"114\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"136\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"158\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"180\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"202\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"224\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"246\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"268\" y=\"48\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><text x=\"310\" y=\"63\" font-size=\"14\" fill=\"#f2a0a0\" text-anchor=\"middle\" font-weight=\"700\">X</text><text x=\"170\" y=\"98\" font-size=\"11.5\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">「3 1」 = 3칸 덩어리, 한 칸 이상 띄우고 1칸</text><text x=\"170\" y=\"112\" font-size=\"11\" fill=\"#b9b0a0\" text-anchor=\"middle\" font-weight=\"400\">붙어 버리면 4가 되어 틀려요</text></svg>", cap: "숫자 순서대로, 덩어리 사이엔 빈칸" }, { svg: "<svg viewBox=\"0 0 340 100\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"100\" rx=\"10\" fill=\"#1d2230\"/><text x=\"60\" y=\"29\" font-size=\"13\" fill=\"#e3ae45\" text-anchor=\"end\" font-weight=\"700\">8</text><rect x=\"70\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"92\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"114\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"136\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"158\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"180\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"202\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"224\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#2b3a55\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"246\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"268\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"#f2e9d8\" stroke=\"#555\" stroke-width=\"1\"/><rect x=\"114\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><rect x=\"136\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><rect x=\"158\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><rect x=\"180\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><rect x=\"202\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><rect x=\"224\" y=\"14\" width=\"20\" height=\"20\" rx=\"2\" fill=\"none\" stroke=\"#e3ae45\" stroke-width=\"2\"/><text x=\"170\" y=\"62\" font-size=\"11.5\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">10칸 줄에 8: 왼쪽 끝에 붙이든 오른쪽 끝에 붙이든</text><text x=\"170\" y=\"80\" font-size=\"11.5\" fill=\"#e3ae45\" text-anchor=\"middle\" font-weight=\"400\">가운데 6칸은 늘 겹쳐요 → 바로 칠해도 돼요</text></svg>", cap: "긴 숫자는 겹치는 칸부터" }] },
      { h: '숫자 읽기', p: [
        '숫자 하나 = 그 줄에 칠해진 칸이 붙어 있는 덩어리 하나. 숫자는 덩어리의 길이예요.',
        '숫자가 여럿이면 그 순서대로 덩어리가 있고, 덩어리 사이에는 빈칸이 한 칸 이상 있어요.',
        '예시: 10칸 줄에 「8」 → 어디에 두든 가운데 6칸은 꼭 칠해져요. 「0」이면 그 줄은 전부 빈칸.',
      ] },
      { h: '조작', p: [
        '칸을 누르면 칠하기, 끌면 한 줄로 여러 칸을 한 번에. 같은 칸을 다시 누르면 지워져요.',
        '아래 「■ 칠하기 / ✕ 표시」 버튼으로 모드를 바꿔요. X는 「여긴 빈칸」 메모예요.',
        '줄이 숫자대로 다 칠해지면 숫자가 흐려지고 남은 칸에 X가 자동으로 그려져요.',
        '15×15·20×20은 🔍 확대로 크게 볼 수 있어요. 확대했을 땐 숫자 띠를 끌거나 두 손가락으로 움직여요.',
      ] },
      { h: '실수 · 도움', p: [
        '목숨 3개(기본): 틀린 칸을 칠하면 그 칸에 빨간 X가 생기고 목숨 1개가 줄어요. 0개면 실패.',
        '자유롭게: 틀려도 알려 주지 않아요. 모든 줄이 맞으면 완성.',
        '💡 힌트: 퍼즐마다 3번, 한 칸의 정답을 보여 줘요. ↶ 되돌리기는 마음껏(목숨은 안 돌아와요).',
        '모든 퍼즐은 찍지 않고 논리만으로 풀 수 있어요. 그림 모음 몇 개는 처음부터 몇 칸이 표시되어 있어요.',
      ] },
      { h: '퍼즐', p: [
        '그림 모음 32개(10×10, 15×15)를 풀면 색이 있는 그림이 모여요. 끝없는 퍼즐은 5×5·10×10·15×15·20×20 크기별로 계속 이어져요.',
        '완성하면 흑백 그림이 천천히 색 그림으로 바뀌고 이름이 떠요. 끝없는 퍼즐·오늘의 퍼즐은 덩어리마다 어울리는 색 팔레트(노을 하늘·깊은 숲 등)가 자동으로 칠해져요.',
        '진행 상황과 풀다 만 판이 이 폰에 저장돼요. 「퍼즐」 버튼으로 골라요.',
      ] },
      { h: '오늘의 퍼즐', p: ['「퍼즐」 버튼 맨 위 카드에서 매일 하나씩 새 퍼즐(평일 10×10, 주말 15×15)을 풀어요. 날짜가 같으면 누구나 같은 퍼즐이고, 찍지 않고 풀 수 있게 검사돼요.', '푼 시간이 기록돼요. 하루씩 이어서 풀면 🔥 연속 일수가 올라가고, 「📋 공유」로 그림 없이 결과를 복사할 수 있어요. 그림 모음·끝없는 퍼즐 진행과는 따로예요.'] },
      { h: '조작(PC)', p: ['마우스 왼쪽 = 지금 모드, 오른쪽 = X. 방향키로 이동 · Space 칠하기 · X 표시 · Q 모드 · Z 되돌리기 · H 힌트 · E 확대.'] },
    ],
    tutorial: [
      { text: '숫자는 그 줄의 칠해진 덩어리 길이예요. 「2 1」이면 2칸, 빈칸, 1칸 순서.' },
      { text: '칸을 누르거나 한 줄로 끌어서 칠해요. 다시 누르면 지워져요.' },
      { text: '여기서 칠하기와 X(빈칸 메모)를 바꿔요. 힌트·되돌리기·퍼즐 고르기도 여기 있어요.', sel: '.ng-bar' },
    ],

    init(players, opts) {
      const strict = !opts || opts.mist !== 'free';
      const st = store();
      let key = typeof st.cur === 'string' && puzzle(st.cur) ? st.cur : 'p0';
      const s = newPuzzle({ last: null }, key, strict);
      const sv = st.sv;
      if (sv && sv.k === s.k && sv.st === s.st && typeof sv.g === 'string' && sv.g.length === s.g.length && /^[012]+$/.test(sv.g)) {
        s.g = sv.g; s.h = U.clamp(sv.h | 0, 0, 3); s.mi = sv.mi | 0;
        if (strict) s.lf = U.clamp(sv.lf == null ? 3 : sv.lf | 0, 1, 3);
        const P = puzzle(s.k); if (solvedAll(s.g, P)) s.g = blankGrid(P);
      }
      return s;
    },
    actor(s) { return s.end ? null : 0; },
    apply(s, seat, a) {
      if (!a || s.end) throw new Error('bad');
      const P = puzzle(s.k), N = P.N, t = a.t;
      if (t === 'paint') {
        if (s.won || s.lost) throw new Error('over');
        const v = String(a.v);
        if (!/^[012]$/.test(v) || !Array.isArray(a.c) || !a.c.length || a.c.length > N) throw new Error('bad');
        const list = [], rows = new Set(), cols = new Set();
        let err = -1;
        for (const q of a.c) {
          const i = q | 0;
          if (i < 0 || i >= N * N || P.gset.has(i)) continue;
          if (s.st && v === '1' && !P.sol[i]) { err = i; break; }
          if (s.st && s.g[i] === '1' && P.sol[i]) continue; // correct fills stay in strict mode
          list.push([i, v]); rows.add(Math.floor(i / N)); cols.add(i % N);
        }
        const changes = [];
        setCells(s, P, changes, list);
        if (err >= 0) {
          setCells(s, P, changes, [[err, '2']]); rows.add(Math.floor(err / N)); cols.add(err % N);
          s.mi++; s.lf = Math.max(0, s.lf - 1);
        }
        const ax = autoX(s, P, rows, cols, changes);
        pushUndo(s, changes);
        s.last = { id: s.last.id + 1, t: 'paint', v, n: list.length, err, ax: ax.ax, done: ax.done };
        if (err >= 0 && s.lf <= 0) s.lost = 1;
        else if (solvedAll(s.g, P)) s.won = 1;
      } else if (t === 'undo') {
        if (s.won || s.lost || !s.u.length) throw new Error('no undo');
        const e = s.u.pop(), g = s.g.split('');
        for (let p = e.length - 3; p >= 0; p -= 3) g[parseInt(e.substr(p, 2), 36)] = e[p + 2];
        s.g = g.join('');
        s.last = { id: s.last.id + 1, t: 'undo' };
      } else if (t === 'hint') {
        if (s.won || s.lost || !s.h) throw new Error('no hint');
        const g = s.g, wrong = [], unk = [];
        for (let i = 0; i < N * N; i++) {
          const want = P.sol[i] ? '1' : '2';
          if (g[i] !== '0' && g[i] !== want && (g[i] === '1' || P.sol[i])) wrong.push(i);
          else if (g[i] === '0' && P.sol[i]) unk.push(i);
        }
        // prefer a cell line logic can reach from the player's correct marks
        let pick = wrong.length ? wrong[0] : -1;
        if (pick < 0 && unk.length) {
          const kg = []; for (let i = 0; i < N * N; i++) { const want = P.sol[i] ? '1' : '2'; kg.push(g[i] === want ? (P.sol[i] ? 1 : 2) : 0); }
          const k0 = kg.slice(); solveGrid(kg, P.cl, N);
          const ded = unk.filter((i) => !k0[i] && kg[i] === 1);
          pick = (ded.length ? ded : unk)[Math.floor((ded.length ? ded : unk).length / 2)];
        }
        if (pick < 0) throw new Error('nothing');
        s.h--;
        const changes = [];
        setCells(s, P, changes, [[pick, P.sol[pick] ? '1' : '2']]);
        const ax = autoX(s, P, new Set([Math.floor(pick / N)]), new Set([pick % N]), changes);
        pushUndo(s, changes);
        s.last = { id: s.last.id + 1, t: 'hint', i: pick, ax: ax.ax, done: ax.done };
        if (solvedAll(s.g, P)) s.won = 1;
      } else if (t === 'reset') {
        newPuzzle(s, s.k, s.st); s.last.t = 'reset';
      } else if (t === 'go') {
        if (typeof a.k !== 'string' || !puzzle(a.k)) throw new Error('bad key');
        newPuzzle(s, a.k, s.st);
      } else if (t === 'end') {
        if (!s.won && !s.lost) throw new Error('not yet');
        s.end = 1;
      } else throw new Error('unknown');
      return s;
    },
    ai(s) {
      if (s.won || s.lost) return { t: 'end' };
      const P = puzzle(s.k), N = P.N, g = s.g;
      for (let i = 0; i < N * N; i++) {
        if (g[i] === '1' && !P.sol[i]) return { t: 'paint', c: [i], v: 0 };
        if (P.sol[i] && g[i] !== '1') {
          const c = [i], r = Math.floor(i / N);
          for (let j = i + 1; j < (r + 1) * N && P.sol[j] && g[j] !== '1'; j++) c.push(j);
          return { t: 'paint', c, v: 1 };
        }
      }
      return { t: 'end' };
    },
    result(s) {
      if (!s.end) return null;
      const P = puzzle(s.k);
      let filled = 0; for (let i = 0; i < P.N * P.N; i++) if (s.g[i] === '1') filled++;
      const stats = [{ label: '크기', value: P.N + '×' + P.N }, { label: '실수', value: s.st ? s.mi + '번' : '자유 모드' }, { label: '힌트 사용', value: (3 - s.h) + '번' }, { label: '칠한 칸', value: filled + '칸' }];
      if (s.lost) return { winners: [], title: '아쉬워요!', text: label(P) + ' — 목숨을 다 썼어요.', stats };
      return { winners: [0], title: (P.name ? '「' + P.name + '」 완성!' : label(P) + ' 완성!'), text: s.st ? '실수 ' + s.mi + '번' : '모든 줄을 맞혔어요.', stats };
    },

    mount(root, api) {
      const cvs = U.canvas(root), cv = cvs.cv, ctx = cvs.ctx;
      const SP = () => (L.debug && L.debug.speed) || 1;
      let S = null, P = null, rafStop = null, now = 0, lastWin = 0, dTime = 0;
      let mode = 1, zoom = 1, panX = 0, panY = 0, drag = null, cursor = null, kbd = false;
      const fx = { flash: {}, ax: {}, lines: {}, shake: 0, reveal: 0, revealAt: 0, hint: {} };
      let parts = [];

      /* ---------- bar ---------- */
      const bar = L.h('div', { class: 'ng-bar', style: { position: 'absolute', left: '0', right: '0', bottom: '0', display: 'flex', gap: '5px', padding: '8px 8px 10px', justifyContent: 'center', zIndex: 5 } });
      const mkBtn = (ic, lab, fn, grow) => {
        const b = L.h('button', { class: 'btn sm', style: { flex: (grow || 1) + ' 1 0', minWidth: '0', minHeight: '52px', padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1px', lineHeight: '1.1' }, onclick: (e) => { e.stopPropagation(); fn(); } });
        const i = L.h('span', { style: { fontSize: '18px' }, text: ic }), t = L.h('span', { style: { fontSize: '11px', whiteSpace: 'nowrap' }, text: lab });
        b.append(i, t); bar.append(b); return { b, i, t };
      };
      const act = (a) => { if (api.canAct(0)) api.act(a); };
      const bMode = mkBtn('■', '칠하기', () => toggleMode(), 1.4);
      const bUndo = mkBtn('↶', '되돌리기', () => act({ t: 'undo' }));
      const bHint = mkBtn('💡', '힌트 3', () => act({ t: 'hint' }));
      const bZoom = mkBtn('🔍', '확대', () => toggleZoom());
      const bPick = mkBtn('▦', '퍼즐', () => openPicker());
      bMode.b.dataset.action = 'mode'; bUndo.b.dataset.action = 'undo'; bHint.b.dataset.action = 'hint'; bZoom.b.dataset.action = 'zoom';
      root.append(bar);
      function toggleMode() { mode = mode === 1 ? 2 : 1; api.sfx('click'); refreshBar(); }
      function toggleZoom() { if (!LAY || !LAY.canZoom) return; zoom = zoom > 1 ? 1 : LAY.zMax; clampPan(); api.sfx('click'); refreshBar(); }
      function refreshBar() {
        if (!S) return;
        const dis = (b, v) => { b.b.disabled = !v; b.b.style.opacity = v ? '1' : '.4'; };
        const live = !S.won && !S.lost;
        bMode.i.textContent = mode === 1 ? '■' : '✕'; bMode.t.textContent = mode === 1 ? '칠하기' : 'X 표시';
        bMode.b.style.outline = '2px solid ' + (mode === 1 ? 'var(--brass)' : '#7cc9ee');
        dis(bMode, live);
        dis(bUndo, live && S.u.length > 0);
        bHint.t.textContent = '힌트 ' + S.h; dis(bHint, live && S.h > 0);
        bZoom.b.style.display = LAY && LAY.canZoom ? '' : 'none'; bZoom.t.textContent = zoom > 1 ? '전체 보기' : '확대';
        dis(bPick, true);
      }

      /* ---------- overlays ---------- */
      let ov = null;
      function closeOv() { if (ov) { ov.remove(); ov = null; } }
      function panel(children) {
        closeOv();
        ov = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', background: 'rgba(10,8,15,.6)' }, onpointerdown: (e) => { if (e.target === ov) closeOv(); } });
        const sh = L.h('div', { class: 'sheet', style: { maxHeight: '88%', gap: '10px', width: '100%', maxWidth: '420px' } });
        children.forEach((c) => c && sh.append(c));
        ov.append(sh); root.append(ov);
      }
      function thumb(pi, solved, size) {
        const c = document.createElement('canvas'), art = PICS[pi][1], N = art.length, d = Math.min(2, window.devicePixelRatio || 1);
        c.width = c.height = size * d; c.style.width = c.style.height = size + 'px';
        const x = c.getContext('2d'); x.scale(d, d);
        x.fillStyle = solved ? '#efe7d6' : '#2a2536'; x.fillRect(0, 0, size, size);
        if (solved) { const cs = size / N; for (let r = 0; r < N; r++) for (let q = 0; q < N; q++) { const ch = art[r][q]; if (ch !== '.') { x.fillStyle = PAL[ch]; x.fillRect(q * cs, r * cs, cs + 0.3, cs + 0.3); } } }
        else { x.fillStyle = '#6b6278'; x.font = '700 ' + Math.round(size * 0.42) + 'px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('?', size / 2, size / 2 + 1); }
        return c;
      }
      function openPicker(tab) {
        if (!S) return;
        const st = store(), pic = st.pic || {}, ep = st.e || {};
        tab = tab || (P && P.pic == null ? 'e' : 'p');
        const tabs = L.h('div', { style: { display: 'flex', gap: '6px' } });
        const mkTab = (id, txt) => tabs.append(L.h('button', { class: 'btn sm' + (tab === id ? ' primary' : ''), style: { flex: '1', minHeight: '46px' }, text: txt, onclick: () => openPicker(id) }));
        const nSolved = PICS.filter((_, i) => pic[i]).length;
        mkTab('p', '그림 모음 ' + nSolved + '/' + PICS.length); mkTab('e', '끝없는 퍼즐');
        let body;
        if (tab === 'p') {
          body = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(62px,1fr))', gap: '6px', overflowY: 'auto', maxHeight: '54vh', padding: '2px' } });
          PICS.forEach((pc, i) => {
            const cur = S.k === 'p' + i, ok = !!pic[i], N = pc[1].length;
            const b = L.h('button', { class: 'btn sm' + (cur ? ' primary' : ''), style: { minHeight: '78px', padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '3px', lineHeight: '1.1' }, onclick: () => { closeOv(); act({ t: 'go', k: 'p' + i }); } });
            b.append(thumb(i, ok, 40), L.h('span', { style: { fontSize: '10px', opacity: '.85', whiteSpace: 'nowrap' }, text: ok ? pc[0] : (i + 1) + ' · ' + N + '×' + N }));
            body.append(b);
          });
        } else {
          body = L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
          SIZES.forEach((N) => {
            const n = Math.max(1, ep[N] | 0 || 1), cur = P && P.size === N;
            const b = L.h('button', { class: 'btn' + (cur ? ' primary' : ''), style: { minHeight: '58px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 16px' }, onclick: () => { closeOv(); act({ t: 'go', k: 'e' + N + '-' + n }); } });
            b.append(L.h('span', { style: { fontSize: '18px', fontWeight: '700' }, text: N + '×' + N }), L.h('span', { style: { fontSize: '13px', opacity: '.85' }, text: (n > 1 ? (n - 1) + '개 풀었어요 · ' : '') + n + '번 퍼즐 ▶' }));
            body.append(b);
          });
          body.append(L.h('p', { class: 'muted', style: { margin: '2px 0 0', fontSize: '12px' }, text: '퍼즐은 끝없이 만들어지고, 모두 찍지 않고 풀 수 있게 검사돼요.' }));
        }
        panel([DAILY.card((d) => { closeOv(); act({ t: 'go', k: 'd' + d }); }, api, dailyN(DAILY.today()) + '×' + dailyN(DAILY.today()) + ' · 기록은 시간'), L.h('h2', { text: '퍼즐 고르기' }), tabs, body, L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '닫기', onclick: closeOv })]);
        setTimeout(() => { const c = body.querySelector('.primary'); if (c && c.scrollIntoView) c.scrollIntoView({ block: 'center' }); }, 0);
      }
      function nextKey() {
        const st = store();
        if (P.pic != null) {
          const pic = st.pic || {};
          for (let k = 1; k <= PICS.length; k++) { const i = (P.pic + k) % PICS.length; if (!pic[i]) return 'p' + i; }
          return 'p' + ((P.pic + 1) % PICS.length);
        }
        return 'e' + P.size + '-' + Math.max(P.lv + 1, (st.e || {})[P.size] | 0);
      }
      function winPanel() {
        if (P.dy) {
          const sc = DAILY.score(P.dy);
          return panel([L.h('h2', { text: '오늘의 퍼즐 완성! 🎉' }),
            L.h('p', { style: { margin: 0, fontSize: '15px', textAlign: 'center' }, text: DAILY.fmtScore(Math.round(dTime / 1000)) + (sc != null ? ' · 오늘 최고 ' + DAILY.fmtScore(sc) : '') + ' · 🔥 연속 ' + DAILY.streak() + '일' }),
            L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px', textAlign: 'center' }, text: (S.st ? '실수 ' + S.mi + '번' : '자유 모드') + ' · 힌트 ' + (3 - S.h) + '번 사용' }),
            L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '📋 결과 공유(복사)', onclick: () => DAILY.share(P.dy, api) }),
            L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '원래 퍼즐로 ▶', onclick: () => { closeOv(); const c = store().cur; act({ t: 'go', k: typeof c === 'string' && puzzle(c) ? c : 'p0' }); } }),
            L.h('button', { class: 'btn ghost', style: { minHeight: '48px' }, text: '퍼즐 고르기', onclick: () => openPicker() })]);
        }
        const items = [L.h('h2', { text: (P.name ? '「' + P.name + '」' : label(P)) + ' 완성!' })];
        if (P.cname) items.push(L.h('p', { style: { margin: 0, fontSize: '14px', textAlign: 'center', color: '#f2c14e' }, text: '색 이름: ' + P.cname }));
        if (P.pic != null) { const c = thumb(P.pic, true, 120); c.style.alignSelf = 'center'; c.style.borderRadius = '6px'; items.push(c); }
        items.push(L.h('p', { style: { margin: 0, fontSize: '15px', textAlign: 'center' }, text: (S.st ? '실수 ' + S.mi + '번' : '자유 모드') + ' · 힌트 ' + (3 - S.h) + '번 사용' }));
        items.push(L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '다음 퍼즐 ▶', onclick: () => { closeOv(); act({ t: 'go', k: nextKey() }); } }));
        items.push(L.h('button', { class: 'btn ghost', style: { minHeight: '48px' }, text: '퍼즐 고르기', onclick: () => openPicker() }));
        panel(items);
      }
      function losePanel() {
        panel([L.h('h2', { text: '목숨을 다 썼어요' }), L.h('p', { class: 'muted', style: { margin: 0 }, text: '틀린 칸은 빨간 X로 남아 있어요. 처음부터 다시 해 볼까요?' }),
          L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '다시 하기', onclick: () => { closeOv(); act({ t: 'reset' }); } }),
          L.h('button', { class: 'btn ghost', style: { minHeight: '48px' }, text: '퍼즐 고르기', onclick: () => openPicker() })]);
      }

      /* ---------- layout ---------- */
      // 행 숫자 칸 너비: 두 자리 수(10 이상)는 1.6칸 — '3 10'이 '310'처럼 붙어 보이지 않게
      const rwOf = (x) => { let w = 0; for (const v of x) w += v >= 10 ? 1.6 : 1; return w || 1; };
      let LAY = null;
      function layout() {
        const W = cvs.w, H = cvs.h, N = P.N;
        const top = 56, bot = H - 76;
        const mr = Math.max(1, ...P.cl.rows.map(rwOf)), mc = Math.max(1, ...P.cl.cols.map((x) => x.length));
        let cell = 10;
        for (let c = 48; c >= 10; c -= 0.5) {
          const sw = U.clamp(c * 0.62, 11, 19), sh = U.clamp(c * 0.6, 12, 19);
          if (mr * sw + 6 + N * c <= W - 14 && mc * sh + 6 + N * c <= bot - top - 6) { cell = c; break; }
        }
        const sw = U.clamp(cell * 0.62, 11, 19), sh = U.clamp(cell * 0.6, 12, 19);
        const cw = mr * sw + 6, ch = mc * sh + 6;
        const tw = cw + N * cell, th = ch + N * cell;
        const ox = Math.floor((W - tw) / 2), oy = Math.floor(top + Math.max(0, (bot - top - th) / 2));
        const zMax = Math.max(1, Math.min(3.4, 44 / cell));
        LAY = { W, H, N, cell, sw, sh, cw, ch, ox, oy, gx: ox + cw, gy: oy + ch, vw: N * cell, vh: N * cell, canZoom: cell < 30 && zMax > 1.2, zMax, top, bot, key: P.key };
        // zoomed viewport: clue strips stay; grid area can extend to screen edges
        LAY.vx1 = W - 6; LAY.vy1 = bot - 2;
        if (!LAY.canZoom) zoom = 1; else if (zoom > 1) zoom = LAY.zMax;
        clampPan();
      }
      function cz() { return LAY.cell * zoom; }
      function clampPan() {
        if (!LAY) return;
        if (zoom <= 1) { panX = panY = 0; return; }
        const full = LAY.N * cz(), vw = LAY.vx1 - LAY.gx, vh = LAY.vy1 - LAY.gy;
        panX = U.clamp(panX, Math.min(0, vw - full), 0); panY = U.clamp(panY, Math.min(0, vh - full), 0);
      }
      const cellX = (c) => LAY.gx + panX + c * cz(), cellY = (r) => LAY.gy + panY + r * cz();
      function cellAt(x, y) {
        const c = Math.floor((x - LAY.gx - panX) / cz()), r = Math.floor((y - LAY.gy - panY) / cz());
        if (x < LAY.gx - 2 || y < LAY.gy - 2) return null;
        if (r < 0 || c < 0 || r >= LAY.N || c >= LAY.N) return null;
        return { r, c };
      }
      function ensureVisible(r, c) {
        if (zoom <= 1) return;
        const s = cz(), vw = LAY.vx1 - LAY.gx, vh = LAY.vy1 - LAY.gy;
        if (c * s + panX < 0) panX = -c * s; if ((c + 1) * s + panX > vw) panX = vw - (c + 1) * s;
        if (r * s + panY < 0) panY = -r * s; if ((r + 1) * s + panY > vh) panY = vh - (r + 1) * s;
        clampPan();
      }

      /* ---------- drawing ---------- */
      function satisfied(isRow, k) { return lineOk(S.g, P, isRow, k); }
      function frame(dt) {
        now += dt;
        if (!S || !P) return;
        if (P.dy && !S.won && !S.lost) dTime += dt;
        if (!LAY || LAY.W !== cvs.w || LAY.H !== cvs.h || LAY.key !== P.key) { layout(); refreshBar(); }
        const W = cvs.w, H = cvs.h, N = P.N, s = cz();
        const bg = ctx.createLinearGradient(0, 0, 0, H);
        bg.addColorStop(0, '#1d2333'); bg.addColorStop(1, '#16131d');
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        // header
        ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8';
        ctx.font = '22px "Black Han Sans", sans-serif';
        ctx.fillText(S.won && P.name ? P.name : S.won && P.cname ? '「' + P.cname + '」' : label(P), 14, 24);
        ctx.font = '12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ab9fb8';
        ctx.fillText(P.pic != null ? '그림 모음 · ' + N + '×' + N : '끝없는 퍼즐', 14, 45);
        ctx.textAlign = 'right';
        if (S.st) {
          for (let i = 0; i < 3; i++) {
            const on = i < S.lf, x = W - 18 - (2 - i) * 24, y = 24;
            let k = 1; if (fx.lifeLost && i === S.lf && now - fx.lifeLost < 600) k = 1 + 0.5 * Math.sin((now - fx.lifeLost) / 600 * Math.PI);
            heart(x, y, 9 * k, on ? '#e8564b' : 'rgba(171,159,184,.28)');
          }
          ctx.fillStyle = '#ab9fb8'; ctx.font = '12px "IBM Plex Sans KR", sans-serif'; ctx.fillText('목숨', W - 14, 45);
        } else { ctx.fillStyle = '#ab9fb8'; ctx.font = '13px "IBM Plex Sans KR", sans-serif'; ctx.fillText('자유 모드', W - 14, 24); }

        const shx = fx.shake && now - fx.shake < 320 ? Math.sin((now - fx.shake) / 18) * 5 * (1 - (now - fx.shake) / 320) * L.fx() : 0;
        ctx.save(); ctx.translate(shx, 0);
        const gx = LAY.gx, gy = LAY.gy, x1 = Math.min(LAY.vx1, gx + panX + N * s), y1 = Math.min(LAY.vy1, gy + panY + N * s);
        const rev = S.won ? U.clamp((now - fx.revealAt) / (REV_MS / SP()), 0, 1) : 0;
        // highlight row/col under pointer/cursor
        const hc = drag ? drag.cur : kbd ? cursor : null;
        // clue strips
        ctx.fillStyle = 'rgba(255,255,255,.04)';
        ctx.fillRect(LAY.ox, gy, LAY.cw - 3, y1 - gy); ctx.fillRect(gx, LAY.oy, x1 - gx, LAY.ch - 3);
        const fz = Math.round(U.clamp(Math.min(LAY.sw, LAY.sh) * 0.86, 10, 16));
        ctx.font = '600 ' + fz + 'px "IBM Plex Mono", monospace'; ctx.textBaseline = 'middle'; ctx.textAlign = 'center';
        // grid clip region
        ctx.save(); ctx.beginPath(); ctx.rect(LAY.ox - 2, gy, LAY.cw + 2 + (x1 - gx), y1 - gy); ctx.clip();
        for (let r = 0; r < N; r++) {
          const y = cellY(r) + s / 2; if (y < gy - s || y > y1 + s) continue;
          const cl = P.cl.rows[r], ok = satisfied(true, r), arr = cl.length ? cl : [0];
          if (hc && hc.r === r) { ctx.fillStyle = 'rgba(227,174,69,.16)'; ctx.fillRect(LAY.ox, cellY(r), LAY.cw - 3, s); }
          const fl = fx.lines['r' + r]; if (fl && now - fl < 700) { ctx.fillStyle = 'rgba(166,220,110,' + (0.35 * (1 - (now - fl) / 700)).toFixed(3) + ')'; ctx.fillRect(LAY.ox, cellY(r), LAY.cw - 3 + (x1 - gx), s); }
          for (let i = arr.length - 1, off = 0; i >= 0; i--) {
            const wv = arr[i] >= 10 ? 1.6 : 1;
            ctx.fillStyle = ok ? 'rgba(242,233,216,.3)' : '#f2e9d8';
            ctx.fillText(String(arr[i]), gx - 6 - (off + wv / 2) * LAY.sw + 2, y + 1);
            off += wv;
          }
        }
        ctx.restore();
        ctx.save(); ctx.beginPath(); ctx.rect(gx, LAY.oy - 2, x1 - gx, LAY.ch + 2 + (y1 - gy)); ctx.clip();
        for (let c = 0; c < N; c++) {
          const x = cellX(c) + s / 2; if (x < gx - s || x > x1 + s) continue;
          const cl = P.cl.cols[c], ok = satisfied(false, c), arr = cl.length ? cl : [0];
          if (hc && hc.c === c) { ctx.fillStyle = 'rgba(227,174,69,.16)'; ctx.fillRect(cellX(c), LAY.oy, s, LAY.ch - 3); }
          const fl = fx.lines['c' + c]; if (fl && now - fl < 700) { ctx.fillStyle = 'rgba(166,220,110,' + (0.35 * (1 - (now - fl) / 700)).toFixed(3) + ')'; ctx.fillRect(cellX(c), LAY.oy, s, LAY.ch - 3 + (y1 - gy)); }
          for (let i = 0; i < arr.length; i++) {
            ctx.fillStyle = ok ? 'rgba(242,233,216,.3)' : '#f2e9d8';
            ctx.fillText(String(arr[i]), x, gy - 5 - (arr.length - 1 - i) * LAY.sh - LAY.sh / 2 + 2);
          }
        }
        ctx.restore();
        // cells
        ctx.save(); ctx.beginPath(); ctx.rect(gx, gy, x1 - gx, y1 - gy); ctx.clip();
        ctx.fillStyle = '#efe7d6'; ctx.fillRect(gx, gy, x1 - gx, y1 - gy);
        const pend = drag && drag.cells ? drag.cellSet : null;
        for (let r = 0; r < N; r++) {
          const y = cellY(r); if (y > y1 || y + s < gy) continue;
          for (let c = 0; c < N; c++) {
            const x = cellX(c); if (x > x1 || x + s < gx) continue;
            const i = r * N + c;
            let v = S.g[i];
            if (pend && pend.has(i)) v = String(drag.v);
            if (hc && (hc.r === r || hc.c === c) && !S.won) { ctx.fillStyle = 'rgba(227,174,69,.13)'; ctx.fillRect(x, y, s, s); }
            if (rev > 0) {
              // 1단계: 짙은 칸 → 흑백 그림, 2단계: 흑백 → 색 (왼쪽 위에서 대각선으로 번짐)
              const col = P.col[i];
              if (col) {
                const g1 = U.clamp(rev * 3 - (r + c) / (2 * N) * 0.6, 0, 1), k0 = U.clamp(rev * 2.2 - 0.7 - (r + c) / (2 * N) * 0.5, 0, 1);
                const k = k0 * k0 * (3 - 2 * k0), gr = grayOf(col);
                ctx.fillStyle = k > 0 ? mixRGB(gr, rgbOf(col), k) : mixRGB([44, 40, 56], gr, g1);
                ctx.fillRect(x - 0.3, y - 0.3, s + 0.6, s + 0.6);
              }
              continue;
            }
            const giv = P.gset.has(i);
            if (v === '1') {
              const fa = fx.flash[i]; let pad = 1;
              if (fa && now - fa < 160) pad = 1 + (s * 0.3) * (1 - (now - fa) / 160) * L.fx();
              ctx.fillStyle = giv ? '#4a4258' : '#2c2838';
              ctx.fillRect(x + pad, y + pad, s - pad * 2, s - pad * 2);
              ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fillRect(x + pad, y + pad, s - pad * 2, Math.max(1, s * 0.12));
              const hi = fx.hint[i]; if (hi && now - hi < 1400) { ctx.strokeStyle = 'rgba(124,201,238,' + (1 - (now - hi) / 1400).toFixed(2) + ')'; ctx.lineWidth = 3; ctx.strokeRect(x + 1.5, y + 1.5, s - 3, s - 3); }
            } else if (v === '2') {
              const err = fx.err && fx.err.i === i;
              const ea = fx.ax[i] ? U.clamp((now - fx.ax[i]) / 220, 0, 1) : 1;
              ctx.strokeStyle = err ? '#d6453a' : giv ? 'rgba(80,70,95,.55)' : 'rgba(80,70,95,' + (0.62 * ea).toFixed(2) + ')';
              ctx.lineWidth = err ? Math.max(2, s * 0.12) : Math.max(1.3, s * 0.07);
              const m = s * (err ? 0.2 : 0.28) + (1 - ea) * s * 0.15;
              ctx.beginPath(); ctx.moveTo(x + m, y + m); ctx.lineTo(x + s - m, y + s - m); ctx.moveTo(x + s - m, y + m); ctx.lineTo(x + m, y + s - m); ctx.stroke();
              if (err) { const k = now - fx.err.t; if (k < 600) { ctx.fillStyle = 'rgba(214,69,58,' + (0.35 * (1 - k / 600)).toFixed(2) + ')'; ctx.fillRect(x, y, s, s); } }
            }
            if (giv && v !== '0') { ctx.fillStyle = 'rgba(227,174,69,.9)'; ctx.beginPath(); ctx.arc(x + s - 4, y + 4, Math.max(1.5, s * 0.07), 0, 7); ctx.fill(); }
          }
        }
        // grid lines
        if (rev < 1) {
          ctx.globalAlpha = 1 - rev;
          for (let k = 0; k <= N; k++) {
            const bold = k % 5 === 0;
            ctx.strokeStyle = bold ? 'rgba(44,40,56,.75)' : 'rgba(44,40,56,.2)'; ctx.lineWidth = bold ? 1.6 : 1;
            const x = Math.round(cellX(k)) + 0.5, y = Math.round(cellY(k)) + 0.5;
            ctx.beginPath(); ctx.moveTo(x, gy); ctx.lineTo(x, y1); ctx.moveTo(gx, y); ctx.lineTo(x1, y); ctx.stroke();
          }
          ctx.globalAlpha = 1;
        }
        if (kbd && cursor && !S.won) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.strokeRect(cellX(cursor.c) + 1.5, cellY(cursor.r) + 1.5, s - 3, s - 3); }
        ctx.restore();
        const nm = S.won ? (P.name || P.cname) : null;
        if (nm && rev > 0.75) {
          const a = U.clamp((rev - 0.75) * 4, 0, 1), cy = Math.min(H - 80, y1 + 26);
          ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.font = '20px "Black Han Sans", sans-serif'; ctx.fillStyle = '#f2c14e';
          ctx.fillText('「' + nm + '」', (gx + x1) / 2, cy); ctx.globalAlpha = 1;
        }
        // board frame
        ctx.strokeStyle = S.won ? 'rgba(227,174,69,' + (0.5 + 0.5 * rev) + ')' : 'rgba(242,233,216,.55)'; ctx.lineWidth = 2;
        ctx.strokeRect(gx - 1, gy - 1, x1 - gx + 2, y1 - gy + 2);
        // zoom scroll indicators
        if (zoom > 1) {
          const full = N * s, vw = LAY.vx1 - gx, vh = LAY.vy1 - gy;
          ctx.fillStyle = 'rgba(227,174,69,.7)';
          if (full > vw) ctx.fillRect(gx + (-panX / full) * vw, y1 + 3, vw * vw / full, 3);
          if (full > vh) ctx.fillRect(x1 + 3 > W - 4 ? W - 4 : x1 + 2, gy + (-panY / full) * vh, 3, vh * vh / full);
        }
        // drag run counter
        if (drag && drag.cells && drag.cells.length > 1) {
          const last = drag.cells[drag.cells.length - 1], r = Math.floor(last / N), c = last % N;
          const bx = cellX(c) + s / 2, by = cellY(r) - 22;
          ctx.fillStyle = 'rgba(20,16,28,.88)'; rr(bx - 17, by - 13, 34, 24, 8); ctx.fill();
          ctx.fillStyle = drag.v === 2 ? '#7cc9ee' : '#e3ae45'; ctx.font = '700 15px "IBM Plex Mono", monospace'; ctx.textAlign = 'center';
          ctx.fillText(String(drag.cells.length), bx, by);
        }
        ctx.restore();
        // particles
        for (let k = parts.length - 1; k >= 0; k--) {
          const q = parts[k]; q.l -= dt * SP();
          if (q.l <= 0) { parts.splice(k, 1); continue; }
          q.vy += 0.0006 * dt * SP(); q.x += q.vx * dt * SP(); q.y += q.vy * dt * SP();
          ctx.globalAlpha = Math.min(1, q.l / 400); ctx.fillStyle = q.c;
          ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.l / 90); ctx.fillRect(-q.s / 2, -q.s / 3, q.s, q.s * 0.66); ctx.restore();
        }
        ctx.globalAlpha = 1;
      }
      function rr(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
      function heart(x, y, r, col) {
        ctx.fillStyle = col; ctx.beginPath();
        ctx.moveTo(x, y + r * 0.9);
        ctx.bezierCurveTo(x - r * 1.4, y - r * 0.1, x - r * 0.7, y - r * 1.2, x, y - r * 0.35);
        ctx.bezierCurveTo(x + r * 0.7, y - r * 1.2, x + r * 1.4, y - r * 0.1, x, y + r * 0.9);
        ctx.fill();
      }
      function confetti() {
        const cols = P.pic != null ? [...new Set(P.col.filter(Boolean))] : ['hsl(' + P.hue + ',62%,52%)', '#e3ae45', '#f2e9d8'];
        for (let i = 0; i < 80; i++) parts.push({ x: Math.random() * cvs.w, y: -10 - Math.random() * 120, vx: (Math.random() - 0.5) * 0.12, vy: 0.05 + Math.random() * 0.15, l: 1600 + Math.random() * 1200, s: 5 + Math.random() * 6, c: cols[i % cols.length] });
      }

      /* ---------- input ---------- */
      const ptrs = new Map();
      let pan = null;
      function startPaint(cell, m) {
        const i = cell.r * P.N + cell.c, cur = +S.g[i];
        drag = { start: cell, cur: cell, from: cur, v: cur === m ? 0 : m, cells: [], cellSet: new Set() };
        updDrag(cell);
      }
      function updDrag(cell) {
        const d = drag, N = P.N, a = d.start;
        let list;
        if (cell.r === a.r && cell.c === a.c) list = [a];
        else {
          if (!d.axis) d.axis = Math.abs(cell.c - a.c) >= Math.abs(cell.r - a.r) ? 'h' : 'v';
          list = [];
          if (d.axis === 'h') { const st = cell.c > a.c ? 1 : -1; for (let c = a.c; c !== cell.c + st; c += st) list.push({ r: a.r, c }); }
          else { const st = cell.r > a.r ? 1 : -1; for (let r = a.r; r !== cell.r + st; r += st) list.push({ r, c: a.c }); }
        }
        const prevN = d.cells.length;
        d.cells = list.map((q) => q.r * N + q.c).filter((i) => +S.g[i] === d.from && !P.gset.has(i));
        d.cellSet = new Set(d.cells);
        d.cur = list[list.length - 1];
        if (d.cells.length !== prevN) api.sfx('tick');
      }
      function endPaint() {
        const d = drag; drag = null;
        if (!d || !d.cells.length) return;
        act({ t: 'paint', c: d.cells, v: d.v });
      }
      const onDown = (e) => {
        if (ov || !S || !LAY) return;
        cv.setPointerCapture && cv.setPointerCapture(e.pointerId);
        const p = cvs.local(e); ptrs.set(e.pointerId, p);
        kbd = false;
        if (ptrs.size >= 2) { drag = null; pan = { x: avg().x, y: avg().y, px: panX, py: panY }; return; }
        if (S.won || S.lost || !api.canAct(0)) return;
        const cell = cellAt(p.x, p.y);
        if (cell) { startPaint(cell, e.button === 2 ? 2 : mode); e.preventDefault(); return; }
        if (zoom > 1) pan = { x: p.x, y: p.y, px: panX, py: panY };
      };
      function avg() { let x = 0, y = 0; for (const q of ptrs.values()) { x += q.x; y += q.y; } return { x: x / ptrs.size, y: y / ptrs.size }; }
      const onMove = (e) => {
        if (!ptrs.has(e.pointerId)) return;
        const p = cvs.local(e); ptrs.set(e.pointerId, p);
        if (pan) { const a = ptrs.size >= 2 ? avg() : p; panX = pan.px + (a.x - pan.x); panY = pan.py + (a.y - pan.y); clampPan(); return; }
        if (drag) {
          const N = P.N;
          const c = U.clamp(Math.floor((p.x - LAY.gx - panX) / cz()), 0, N - 1), r = U.clamp(Math.floor((p.y - LAY.gy - panY) / cz()), 0, N - 1);
          if (r !== drag.cur.r || c !== drag.cur.c || !drag.axis) updDrag({ r, c });
        }
      };
      const onUp = (e) => {
        if (!ptrs.has(e.pointerId)) return;
        ptrs.delete(e.pointerId);
        if (pan) { if (!ptrs.size) pan = null; return; }
        if (drag) endPaint();
      };
      const onCancel = (e) => { ptrs.delete(e.pointerId); drag = null; pan = null; };
      const onWheel = (e) => {
        if (!LAY || !LAY.canZoom) return;
        e.preventDefault();
        if (e.ctrlKey || Math.abs(e.deltaY) > 0 && zoom <= 1) { if ((e.deltaY < 0) !== (zoom > 1)) toggleZoom(); return; }
        panX -= e.deltaX; panY -= e.deltaY; clampPan();
      };
      const noCtx = (e) => e.preventDefault();
      cv.addEventListener('pointerdown', onDown); cv.addEventListener('pointermove', onMove);
      cv.addEventListener('pointerup', onUp); cv.addEventListener('pointercancel', onCancel);
      cv.addEventListener('wheel', onWheel, { passive: false }); cv.addEventListener('contextmenu', noCtx);
      cv.style.touchAction = 'none';

      let held = null;
      const onCx = (e) => { if (drag || held) { drag = null; held = null; e.preventDefault(); } };
      window.addEventListener('lounge-cancel', onCx);
      function keyPaint(m) {
        if (!S || S.won || S.lost || !cursor) return;
        const i = cursor.r * P.N + cursor.c, cur = +S.g[i];
        if (P.gset.has(i)) return;
        held = { m, from: cur, v: cur === m ? 0 : m };
        act({ t: 'paint', c: [i], v: held.v });
      }
      const offIn = api.input ? api.input.on((type, id) => {
        if (!S || ov) return;
        if (type === 'up') { if ((id === 'fill' && held && held.m === 1) || (id === 'mark' && held && held.m === 2)) held = null; return; }
        const mv = { up: [-1, 0], down: [1, 0], left: [0, -1], right: [0, 1] }[id];
        if (mv) {
          if (!kbd || !cursor) { kbd = true; cursor = cursor || { r: 0, c: 0 }; return; }
          cursor = { r: U.clamp(cursor.r + mv[0], 0, P.N - 1), c: U.clamp(cursor.c + mv[1], 0, P.N - 1) };
          ensureVisible(cursor.r, cursor.c);
          if (held && !S.won && !S.lost) { const i = cursor.r * P.N + cursor.c; if (+S.g[i] === held.from && !P.gset.has(i)) act({ t: 'paint', c: [i], v: held.v }); }
          return;
        }
        if (id === 'fill' || id === 'mark') { if (!kbd) { kbd = true; cursor = cursor || { r: 0, c: 0 }; } keyPaint(id === 'fill' ? 1 : 2); }
        else if (id === 'mode') toggleMode();
        else if (id === 'undo') act({ t: 'undo' });
        else if (id === 'hint') act({ t: 'hint' });
        else if (id === 'zoom') toggleZoom();
      }) : null;

      rafStop = U.loop((dt) => frame(Math.min(dt * 1000, 50)));

      function nonoBest(o) {
        if (!L.best) return;
        const n = Object.keys(o.pic || {}).length;
        if (n) L.best.set('nonogram', 'pics', n, { label: '푼 그림', unit: '장' });
        SIZES.forEach((N) => { const v = ((o.e || {})[N] | 0) - 1; if (v > 0) L.best.set('nonogram', 'e' + N, v, { label: '끝없는 ' + N + '×' + N + ' 최고', unit: '번' }); });
      }
      nonoBest(store());
      function persist(s) {
        if (puzzle(s.k).dy) return; // 오늘의 퍼즐은 진행·이어 하기와 따로
        const o = store();
        o.cur = s.k;
        if (s.won || s.lost) delete o.sv; else o.sv = { k: s.k, g: s.g, h: s.h, lf: s.lf, mi: s.mi, st: s.st };
        save(o);
      }

      return {
        update(s, prev) {
          const fresh = !S;
          S = s; P = puzzle(s.k);
          const L0 = s.last || {}, PL = prev && prev.last;
          if (fresh) { zoom = 1; panX = panY = 0; DAILY.prune(); }
          if (fresh || (L0.t === 'new' || L0.t === 'reset') && PL && L0.id !== PL.id) dTime = 0;
          if (prev && prev !== s && PL && L0.id !== PL.id) {
            if (L0.t === 'paint' || L0.t === 'hint') {
              const N = P.N;
              if (L0.t === 'paint') {
                if (L0.v === '1') { for (let i = 0; i < N * N; i++) if (s.g[i] === '1' && prev.g[i] !== '1') fx.flash[i] = now; api.sfx(L0.n ? 'chip' : 'tick'); }
                else if (L0.n) api.sfx(L0.v === '2' ? 'click' : 'tick');
              } else { fx.hint[L0.i] = now; api.sfx('pop'); }
              (L0.ax || []).forEach((i) => { fx.ax[i] = now; });
              (L0.done || []).forEach((k) => { if (!lineOk(prev.g, P, k[0] === 'r', +k.slice(1))) fx.lines[k] = now; });
              if ((L0.done || []).some((k) => fx.lines[k] === now)) api.sfx('bounce');
              if (L0.err >= 0) { fx.err = { i: L0.err, t: now }; fx.shake = now; fx.lifeLost = now; api.sfx('thud'); api.buzz(80); }
            } else if (L0.t === 'undo') api.sfx('whoosh');
            else if (L0.t === 'new' || L0.t === 'reset') { drag = null; closeOv(); fx.err = null; fx.flash = {}; fx.ax = {}; fx.lines = {}; fx.hint = {}; zoom = 1; panX = panY = 0; LAY = null; }
          }
          if (s.won && lastWin !== L0.id && prev && !prev.won) {
            lastWin = L0.id; fx.revealAt = now;
            if (P.dy) {
              if (api.canAct(0) && !api.players[0].ai && DAILY.complete(P.dy, Math.max(1, Math.round(dTime / 1000)), api)) api.toast('오늘 최고 기록!');
              api.sfx('pop');
              setTimeout(() => { if (!S || !S.won) return; confetti(); api.sfx('win'); api.buzz(60); if (api.canAct(0) && !api.players[0].ai) winPanel(); }, (REV_MS + 500) / SP());
              refreshBar(); return;
            }
            const o = store();
            if (P.pic != null) { o.pic = o.pic || {}; o.pic[P.pic] = 1; }
            else { o.e = o.e || {}; o.e[P.size] = Math.max(o.e[P.size] | 0, P.lv + 1); }
            save(o);
            if (api.canAct(0) && !api.players[0].ai) nonoBest(o);
            api.sfx('pop');
            setTimeout(() => { if (!S || !S.won) return; confetti(); api.sfx('win'); api.buzz(60); if (api.canAct(0) && !api.players[0].ai) winPanel(); }, (REV_MS + 500) / SP());
          }
          if (s.lost && prev && !prev.lost) { api.sfx('lose'); setTimeout(() => { if (S && S.lost && api.canAct(0) && !api.players[0].ai) losePanel(); }, 700 / SP()); }
          persist(s);
          refreshBar();
        },
        destroy() {
          if (rafStop) rafStop();
          cv.removeEventListener('pointerdown', onDown); cv.removeEventListener('pointermove', onMove);
          cv.removeEventListener('pointerup', onUp); cv.removeEventListener('pointercancel', onCancel);
          cv.removeEventListener('wheel', onWheel); cv.removeEventListener('contextmenu', noCtx);
          window.removeEventListener('lounge-cancel', onCx); if (offIn) offIn(); closeOv(); bar.remove(); api.setBusy(false); cvs.destroy();
        },
      };
    },
  };
  def._daily = DAILY; def._puzzle = puzzle; def._PICS = PICS; def._solveGrid = solveGrid;
  L.register(def);
})();
