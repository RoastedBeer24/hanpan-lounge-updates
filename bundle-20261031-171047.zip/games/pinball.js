/* 핀볼 대결 — realtime pinball score attack (1–4).
   Everyone plays an identical table (same layout, same mission order) at the same time with 3 balls; highest score wins.
   Each device simulates its own player's table (host/local also simulates the AI tables); scores are shared live
   (cooking.js pattern: guests publish {k,sc,b,f}, host sends {k,s:[[sc,b,f]..]}, host ends the match with setState).
   Physics: fixed 480 Hz sub-steps on a 10×18 table, ball radius 0.27 → the ball moves < 0.1 per step (no tunnelling).
   Flippers are kinematic capsules (surface velocity transferred on contact). Ramps are 2D: a mouth with a sensor line,
   then the ball rides a spline path drawn above the playfield and drops into an inlane. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;

  /* ======================= constants ======================= */
  const R = 0.27, GRAV = 19, VMAX = 46, HZ = 480, DT = 1 / HZ;
  const PF = 9.3, LX = 9.65, PLY = 17.3, SAVE_T = 8;
  const FL = 1.72, FR0 = 0.28, FR1 = 0.13, A_DN = 0.52, A_UP = -0.42, W_UP = 21, W_DN = 15;
  const FP = [[2.58, 15.55], [6.72, 15.55]];
  const FRAME = [0, 1].map((i) => { const c = Math.cos(A_DN), s = Math.sin(A_DN); return { px: FP[i][0], py: FP[i][1], dx: i ? -c : c, dy: s, nx: i ? -s : s, ny: -c }; });
  const GC = 11, GR = 20, LANES = [5.0, 6.1, 7.2], DC = 128, DRW = 14;
  const PTS = { bump: 100, sling: 30, drop: 500, dropAll: 3000, spin: 100, lane: 500, laneAll: 2500, ramp: 2000, orb: 1500, sau: 2500, tgt: 750, mag: 400, gear: 150 };
  const BON = { bump: 30, sling: 10, drop: 200, spin: 20, lane: 200, ramp: 600, orb: 400, sau: 500, tgt: 250, mag: 120, gear: 40 };
  const BRIDGE_CYC = 12, BRIDGE_OPEN = 5, BRIDGE_HOLD = 10;   // 증기 시계탑: the bridge ramp is down 5 s of every 12 s, or 10 s after the key target
  const fmt = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  function mkRng(seed) {
    let a = (seed >>> 0) || 0x9e3779b9;
    return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function catmull(p, n) {
    const out = [];
    for (let i = 0; i < p.length - 1; i++) {
      const p0 = p[Math.max(0, i - 1)], p1 = p[i], p2 = p[i + 1], p3 = p[Math.min(p.length - 1, i + 2)];
      for (let k = 0; k < n; k++) {
        const t = k / n, t2 = t * t, t3 = t2 * t, q = [0, 0];
        for (let j = 0; j < 2; j++) q[j] = 0.5 * ((2 * p1[j]) + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2 + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3);
        out.push(q);
      }
    }
    out.push(p[p.length - 1].slice());
    return out;
  }

  /* ======================= tables (original designs) ======================= */
  const TABLES = [
    {
      n: '해적 항구', sub: '통 범퍼 · 돛대 램프 · 보물 상자', lockTxt: '보물 상자에 넣으면 공 잠금',
      th: { bg: ['#12505a', '#06262d'], cab: '#3b2414', rail: '#d9b27a', railD: '#6d4a26', rub: '#f2e9d8', plast: '#c0692a', bumpC: '#e0892c', bumpR: '#5a2e14', bumpT: '#ffe9b8',
        fl: '#f4ead6', flR: '#d4402c', drop: '#e65a3a', stand: '#f0c040', ramp: 'rgba(255,214,150,.20)', rampE: '#e8c48a', apron: '#2c1b10', lbl: 'rgba(255,236,200,.62)', gi: '#ffcf7a',
        ins: { ramp: '#ffd34d', orb: '#6fe0ff', spin: '#6fe0ff', drop: '#ff6a4d', sau: '#ffae2e', tgt: '#9dff7a', lane: '#fff1a0', mult: '#ff7a4d', save: '#7dff9a', extra: '#ffd34d' } },
      missions: [['돛대 램프 3번', 'ramp', 3], ['통 범퍼 15번', 'bump', 15], ['대포알 타깃 모두', 'dropAll', 1], ['보물 상자 2번', 'sau', 2], ['물레 스피너 20번', 'spin', 20], ['갈매기 오빗 2번', 'orb', 2], ['깃발 타깃 4번', 'tgt', 4]],
      build(B) {
        B.bumper(3.8, 3.75); B.bumper(5.9, 3.6); B.bumper(4.85, 5.35);
        B.poly([[0.85, 9.7], [0.85, 5.4], [1.25, 4.25]], { e: 0.35 }); B.post(0.85, 9.7, 0.12); B.post(1.25, 4.25, 0.1);
        B.orbit(0, 9.35, 0.85, 9.35); B.spinner(0, 8.55, 0.85, 8.55);
        B.drop(0.97, 5.85, 0.97, 6.4, 2, 6.1); B.drop(0.97, 6.5, 0.97, 7.05, 2, 6.8); B.drop(0.97, 7.15, 0.97, 7.7, 2, 7.4);
        B.ramp(2.5, 7.25, -Math.PI / 2 - 0.25, [[2.35, 5.2], [3.3, 2.9], [5.6, 2.55], [7.6, 3.5], [8.35, 6.5], [8.25, 10.5], [8.21, 12.1]]);
        B.saucer(7.45, 6.7, -0.45, 0.89, 9);
        B.stand(9.2, 7.9, 9.2, 8.45, 8, 8.2); B.stand(9.2, 8.7, 9.2, 9.25, 8, 9);
      },
      ins: [{ x: 2.78, y: 9.25, a: -1.82, ev: 'ramp' }, { x: 1.35, y: 10.25, a: -2.0, ev: 'orb' }, { x: 1.75, y: 6.75, a: Math.PI, ev: 'drop' },
        { x: 6.95, y: 7.8, a: -1.13, ev: 'sau' }, { x: 8.5, y: 8.7, a: 0, ev: 'tgt' }],
      labels: [[2.9, 9.95, '돛대 램프'], [7.45, 6.0, '보물 상자'], [1.85, 5.35, '대포알'], [8.4, 9.75, '깃발']],
    },
    {
      n: '우주 정거장', sub: '쌍둥이 램프 · 블랙홀 · 운석 타깃', lockTxt: '블랙홀에 넣으면 공 잠금', holdDrops: true,
      th: { bg: ['#141a48', '#04051a'], cab: '#1c2040', rail: '#a9bde6', railD: '#3a4670', rub: '#e8f0ff', plast: '#3a6ad4', bumpC: '#39c6ff', bumpR: '#1d2a66', bumpT: '#e0f8ff',
        fl: '#eef3ff', flR: '#ff4fa0', drop: '#ff7a3a', stand: '#7cf7ff', ramp: 'rgba(140,220,255,.18)', rampE: '#9fe8ff', apron: '#10132c', lbl: 'rgba(200,230,255,.6)', gi: '#8fe8ff',
        ins: { ramp: '#7cf7ff', orb: '#c08cff', spin: '#c08cff', drop: '#ff8a4d', sau: '#ff4fd0', tgt: '#9dff7a', lane: '#e8fff0', mult: '#ff6aa0', save: '#7dff9a', extra: '#ffe27a' } },
      missions: [['램프 3번', 'ramp', 3], ['위성 범퍼 15번', 'bump', 15], ['운석 타깃 모두', 'dropAll', 1], ['블랙홀 2번', 'sau', 2], ['스피너 20번', 'spin', 20], ['궤도 오빗 2번', 'orb', 2], ['윗 레인 모두 켜기', 'laneAll', 1]],
      build(B) {
        B.bumper(3.45, 3.85); B.bumper(5.95, 3.85); B.bumper(4.7, 5.0);
        B.poly([[0.85, 9.7], [0.85, 5.4], [1.25, 4.25]], { e: 0.35 }); B.post(0.85, 9.7, 0.12); B.post(1.25, 4.25, 0.1);
        B.orbit(0, 9.35, 0.85, 9.35); B.spinner(0, 8.55, 0.85, 8.55);
        B.ramp(2.1, 7.0, -Math.PI / 2 - 0.3, [[1.95, 4.9], [2.9, 2.9], [5.2, 2.6], [7.4, 3.8], [8.3, 7.0], [8.21, 12.1]]);
        B.ramp(7.2, 7.0, -Math.PI / 2 + 0.3, [[7.35, 4.9], [6.4, 2.9], [4.1, 2.6], [1.9, 3.8], [1.15, 7.0], [1.09, 12.1]]);
        // chevron bank (peak in the middle) so a ball coming down from the black hole never rests on top of it
        [[3.45, 9.42, 3.95, 9.28], [4.05, 9.25, 4.55, 9.1], [4.75, 9.1, 5.25, 9.25], [5.35, 9.28, 5.85, 9.42]].forEach((q) => B.drop(q[0], q[1], q[2], q[3], (q[0] + q[2]) / 2, 10.2));
        B.post(4.65, 9.03, 0.08);   // apex post: no notch between the two middle targets
        B.saucer(4.65, 7.55, -0.3, -0.95, 11);
      },
      ins: [{ x: 2.38, y: 8.95, a: -1.87, ev: 'ramp' }, { x: 6.92, y: 8.95, a: -1.27, ev: 'ramp' }, { x: 1.3, y: 10.25, a: -2.0, ev: 'orb' },
        { x: 4.65, y: 10.0, a: -Math.PI / 2, ev: 'drop' }, { x: 4.65, y: 8.35, a: -Math.PI / 2, ev: 'sau' }],
      labels: [[2.4, 9.6, '왼 램프'], [6.9, 9.6, '오른 램프'], [4.65, 6.75, '블랙홀'], [4.65, 10.65, '운석']],
    },
    {
      n: '마법 서커스', sub: '대포 램프 · 마술 모자 · 외줄 오빗', lockTxt: '마술 모자에 넣으면 공 잠금',
      th: { bg: ['#6a1430', '#2c0614'], cab: '#3a0e1a', rail: '#e9b44a', railD: '#7a4a14', rub: '#fff4dc', plast: '#2a7ad4', bumpC: '#ff4f4f', bumpR: '#f2c04a', bumpT: '#fff3d6',
        fl: '#fff6e4', flR: '#2a8cff', drop: '#ffd34d', stand: '#7cf0ff', ramp: 'rgba(255,240,190,.20)', rampE: '#ffe6a0', apron: '#2a0a14', lbl: 'rgba(255,240,215,.62)', gi: '#ffe08a',
        ins: { ramp: '#ffe27a', orb: '#7cf0ff', spin: '#7cf0ff', drop: '#ffd34d', sau: '#ff7ad0', tgt: '#9dff7a', lane: '#fff6c0', mult: '#ff9a4d', save: '#7dff9a', extra: '#ffe27a' } },
      missions: [['대포 램프 3번', 'ramp', 3], ['풍선 범퍼 15번', 'bump', 15], ['곤봉 타깃 모두', 'dropAll', 1], ['마술 모자 2번', 'sau', 2], ['스피너 20번', 'spin', 20], ['외줄 오빗 2번', 'orb', 2], ['광대 타깃 4번', 'tgt', 4]],
      build(B) {
        B.bumper(2.45, 3.75); B.bumper(4.0, 3.35); B.bumper(3.25, 5.1);
        B.ramp(4.65, 7.3, -Math.PI / 2, [[4.7, 4.8], [5.6, 2.7], [7.3, 2.5], [8.0, 4.5], [7.9, 8.0], [8.2, 10.5], [8.21, 12.1]]);
        B.poly([[8.45, 9.7], [8.45, 5.4], [8.05, 4.25]], { e: 0.35 }); B.post(8.45, 9.7, 0.12); B.post(8.05, 4.25, 0.1);
        B.orbit(8.45, 9.35, PF, 9.35); B.spinner(8.45, 8.55, PF, 8.55);
        for (const x of [5.55, 6.15, 6.75]) B.drop(x, 5.6, x + 0.5, 5.6, x + 0.25, 6.4);
        B.poly([[5.4, 5.5], [6.4, 5.02], [7.4, 5.5]], { e: 0.35 });   // steep roof, no end posts: nothing for a ball to rest against
        B.saucer(1.3, 7.1, 0.45, 0.89, 9);
        B.stand(1.7, 9.8, 2.15, 9.4, 2.4, 9.9); B.stand(6.85, 8.95, 7.3, 9.35, 6.7, 9.6);
      },
      ins: [{ x: 4.65, y: 9.0, a: -Math.PI / 2, ev: 'ramp' }, { x: 7.95, y: 10.3, a: -1.14, ev: 'orb' }, { x: 6.4, y: 6.4, a: -Math.PI / 2, ev: 'drop' },
        { x: 2.0, y: 7.75, a: -2.43, ev: 'sau' }, { x: 2.5, y: 10.35, a: -2.4, ev: 'tgt' }, { x: 6.55, y: 9.75, a: -0.75, ev: 'tgt' }],
      labels: [[4.65, 9.65, '대포 램프'], [1.3, 6.35, '마술 모자'], [6.4, 4.95, '곤봉'], [7.95, 11.0, '외줄']],
    },
    {
      n: '심해 유적', sub: '돌고 있는 자석 · 유적 램프 · 봉인 문 멀티볼', lockTxt: '봉인 문에 넣으면 공 잠금',
      magJack: true, // 멀티볼 중에는 자석이 세지고, 자석을 스칠 때마다 작은 잭팟
      th: { bg: ['#0b3a4a', '#020d16'], cab: '#0d2129', rail: '#8fd6c8', railD: '#2a5a56', rub: '#e2f6f0', plast: '#1d8c7e', bumpC: '#3fe0c0', bumpR: '#0f3a40', bumpT: '#d8fff4',
        fl: '#eefaf6', flR: '#ff8a5a', drop: '#e8b24a', stand: '#ffcf6a', ramp: 'rgba(140,255,230,.16)', rampE: '#8ff0d8', apron: '#06161c', lbl: 'rgba(200,255,240,.6)', gi: '#7fffe0',
        ins: { ramp: '#7fffe0', orb: '#9fd0ff', spin: '#9fd0ff', drop: '#ffc24a', sau: '#ff7ad0', tgt: '#ffe27a', lane: '#e8fff6', mult: '#ff9a6a', save: '#7dff9a', extra: '#ffe27a', mag: '#c08cff' } },
      missions: [['유적 램프 3번', 'ramp', 3], ['자석 스치기 6번', 'mag', 6], ['유물 타깃 모두', 'dropAll', 1], ['봉인 문 2번', 'sau', 2], ['물레 스피너 20번', 'spin', 20], ['해류 오빗 2번', 'orb', 2], ['조개 범퍼 15번', 'bump', 15]],
      build(B) {
        B.bumper(3.0, 4.3); B.bumper(4.65, 3.35); B.bumper(6.3, 4.3);
        B.poly([[0.85, 9.7], [0.85, 5.4], [1.25, 4.25]], { e: 0.35 }); B.post(0.85, 9.7, 0.12); B.post(1.25, 4.25, 0.1);
        B.orbit(0, 9.35, 0.85, 9.35); B.spinner(0, 8.55, 0.85, 8.55);
        B.drop(0.97, 5.85, 0.97, 6.4, 2, 6.1); B.drop(0.97, 6.5, 0.97, 7.05, 2, 6.8); B.drop(0.97, 7.15, 0.97, 7.7, 2, 7.4);
        B.ramp(2.5, 7.25, -Math.PI / 2 - 0.25, [[2.35, 5.2], [3.3, 2.9], [5.6, 2.55], [7.6, 3.5], [8.35, 6.5], [8.25, 10.5], [8.21, 12.1]]);
        B.saucer(7.45, 6.7, -0.45, 0.89, 9);
        B.stand(9.2, 7.9, 9.2, 8.45, 8, 8.2); B.stand(9.2, 8.7, 9.2, 9.25, 8, 9);
        B.magnet(4.65, 8.6, 0.95, 1.25, 0); B.magnet(4.65, 8.6, 0.95, 1.25, Math.PI);
      },
      ins: [{ x: 2.78, y: 9.25, a: -1.82, ev: 'ramp' }, { x: 1.35, y: 10.25, a: -2.0, ev: 'orb' }, { x: 1.75, y: 6.75, a: Math.PI, ev: 'drop' },
        { x: 6.95, y: 7.8, a: -1.13, ev: 'sau' }, { x: 8.5, y: 8.7, a: 0, ev: 'tgt' }, { x: 4.65, y: 10.35, a: -Math.PI / 2, ev: 'mag' }],
      labels: [[2.9, 9.95, '유적 램프'], [7.45, 6.0, '봉인 문'], [1.85, 5.35, '유물'], [4.65, 11.0, '자석 고리']],
    },
    {
      n: '증기 시계탑', sub: '도는 톱니 · 시간 다리 램프 · 잭팟 순서', lockTxt: '문자판 구멍에 넣으면 공 잠금',
      seq: ['gear', 'ramp', 'tgt', 'sau', 'orb'], // 시계 잭팟: 불이 들어온 순서대로 맞히기
      th: { bg: ['#4a3216', '#160c04'], cab: '#2a1a0c', rail: '#e0b060', railD: '#6a4418', rub: '#f6e8cc', plast: '#9a5a1e', bumpC: '#d89a3a', bumpR: '#4a2c10', bumpT: '#fff0c8',
        fl: '#f8eedc', flR: '#3a8a8a', drop: '#e0a040', stand: '#9fe0d0', ramp: 'rgba(255,220,160,.18)', rampE: '#f0c878', apron: '#1c1006', lbl: 'rgba(255,236,200,.62)', gi: '#ffd690',
        ins: { ramp: '#ffd34d', orb: '#9fe0ff', spin: '#9fe0ff', drop: '#ffae4d', sau: '#ff8ad0', tgt: '#9fffd0', lane: '#fff1c0', mult: '#ff9a4d', save: '#7dff9a', extra: '#ffd34d', gear: '#ffc04a' } },
      missions: [['다리 램프 3번', 'ramp', 3], ['톱니 12번', 'gear', 12], ['추 타깃 모두', 'dropAll', 1], ['문자판 구멍 2번', 'sau', 2], ['스피너 20번', 'spin', 20], ['태엽 오빗 2번', 'orb', 2], ['열쇠 타깃 4번', 'tgt', 4]],
      build(B) {
        B.gear(3.0, 4.5, 0.48, 6); B.gear(6.3, 4.5, 0.48, -6); B.gear(4.65, 5.25, 0.4, 8);
        B.ramp(4.65, 7.3, -Math.PI / 2, [[4.7, 4.8], [5.6, 2.7], [7.3, 2.5], [8.0, 4.5], [7.9, 8.0], [8.2, 10.5], [8.21, 12.1]]);
        B.bridge(0);
        B.poly([[8.45, 9.7], [8.45, 5.4], [8.05, 4.25]], { e: 0.35 }); B.post(8.45, 9.7, 0.12); B.post(8.05, 4.25, 0.1);
        B.orbit(8.45, 9.35, PF, 9.35); B.spinner(8.45, 8.55, PF, 8.55);
        B.poly([[0.85, 9.7], [0.85, 5.4], [1.25, 4.25]], { e: 0.35 }); B.post(0.85, 9.7, 0.12); B.post(1.25, 4.25, 0.1);
        B.drop(0.97, 5.85, 0.97, 6.4, 2, 6.1); B.drop(0.97, 6.5, 0.97, 7.05, 2, 6.8); B.drop(0.97, 7.15, 0.97, 7.7, 2, 7.4);
        B.saucer(6.85, 9.0, -0.5, 0.87, 9);
        B.stand(1.7, 9.8, 2.15, 9.4, 2.4, 9.9); B.stand(2.3, 10.6, 2.75, 10.2, 3.0, 10.7);
      },
      ins: [{ x: 4.65, y: 9.0, a: -Math.PI / 2, ev: 'ramp' }, { x: 7.95, y: 10.3, a: -1.14, ev: 'orb' }, { x: 1.75, y: 6.75, a: Math.PI, ev: 'drop' },
        { x: 6.35, y: 9.9, a: -1.0, ev: 'sau' }, { x: 2.9, y: 11.3, a: -2.4, ev: 'tgt' }, { x: 4.65, y: 6.0, a: -Math.PI / 2, ev: 'gear' }],
      labels: [[4.65, 9.65, '시간 다리'], [6.85, 8.25, '문자판'], [1.85, 5.35, '추'], [7.95, 11.0, '태엽']],
    },
  ];

  /* ======================= table geometry ======================= */
  const DEFS = [];
  function getDef(ti) { return DEFS[ti] || (DEFS[ti] = buildDef(ti)); }
  function buildDef(ti) {
    const S = TABLES[ti];
    const D = { ti, S, th: S.th, segs: [], circ: [], lines: [], pts: [], ramps: [], drops: [], stands: [], bumpers: [], slings: [], saucer: null, spinner: null, orbit: null, mags: [], gears: [], bridge: -1 };
    const mkSeg = (ax, ay, bx, by, o) => { const s = Object.assign({ ax, ay, bx, by, e: 0.42, k: 'w', id: 0, nx: 0, ny: 0 }, o || {}); s.dx = bx - ax; s.dy = by - ay; s.l2 = s.dx * s.dx + s.dy * s.dy || 1e-9; return s; };
    const face = (s, px, py) => {
      let nx = -s.dy, ny = s.dx; const l = Math.hypot(nx, ny) || 1; nx /= l; ny /= l;
      if ((px - s.ax) * nx + (py - s.ay) * ny < 0) { nx = -nx; ny = -ny; }
      s.nx = nx; s.ny = ny; return s;
    };
    const B = {
      seg(ax, ay, bx, by, o) { const s = mkSeg(ax, ay, bx, by, o); D.segs.push(s); return s; },
      poly(p, o) { for (let i = 0; i + 1 < p.length; i++) B.seg(p[i][0], p[i][1], p[i + 1][0], p[i + 1][1], o); },
      post(x, y, r, o) { const c = Object.assign({ x, y, r: r || 0.1, e: 0.6, k: 'p', id: 0 }, o || {}); D.circ.push(c); return c; },
      bumper(x, y) { const c = B.post(x, y, 0.46, { k: 'b', id: D.bumpers.length, e: 0.5 }); D.bumpers.push(c); return c; },
      drop(ax, ay, bx, by, fx, fy) { const s = face(B.seg(ax, ay, bx, by, { k: 'd', id: D.drops.length, e: 0.35 }), fx, fy); D.drops.push(s); return s; },
      stand(ax, ay, bx, by, fx, fy) { const s = face(B.seg(ax, ay, bx, by, { k: 'st', id: D.stands.length, e: 0.45 }), fx, fy); D.stands.push(s); return s; },
      line(ax, ay, bx, by, k, id, fx, fy) { const s = face(mkSeg(ax, ay, bx, by, { k, id }), fx, fy); D.lines.push(s); return s; },
      orbit(ax, ay, bx, by) { B.line(ax, ay, bx, by, 'orb', 0, (ax + bx) / 2, ay - 1); D.orbit = { ax, ay, bx, by }; },
      spinner(ax, ay, bx, by) { B.line(ax, ay, bx, by, 'spin', 0, (ax + bx) / 2, ay - 1); D.spinner = { ax, ay, bx, by, x: (ax + bx) / 2, y: ay }; },
      saucer(x, y, kx, ky, ks) { const l = Math.hypot(kx, ky); D.saucer = { x, y, kx: kx / l, ky: ky / l, ks }; },
      // rotating magnet: circles (cx, cy) at radius rad, w rad/s, phase ph — pulls the ball (weaker than gravity, so it never holds it)
      magnet(cx, cy, rad, w, ph) { D.mags.push({ id: D.mags.length, cx, cy, rad, w, ph, r: 1.6, k: 12 }); },
      // spinning gear: a solid disc whose rim moves at w·r (tangential kick on contact)
      gear(x, y, r, w) { const c = B.post(x, y, r, { k: 'gr', id: D.gears.length, e: 0.45, w }); D.gears.push(c); return c; },
      bridge(id) { D.bridge = id; },
      ramp(cx, cy, ang, ctrl) {
        const ux = Math.cos(ang), uy = Math.sin(ang), qx = -uy, qy = ux, hw = 0.48;
        const P = (a, b) => [cx + ux * a + qx * b, cy + uy * a + qy * b];
        const l0 = P(-1.15, -hw), l1 = P(0.35, -hw), r0 = P(-1.15, hw), r1 = P(0.35, hw);
        B.seg(l0[0], l0[1], l1[0], l1[1], { e: 0.35 }); B.seg(r0[0], r0[1], r1[0], r1[1], { e: 0.35 });
        const ap = P(0.8, 0);   // peaked back so a ball landing on the ramp body always rolls off
        B.seg(l1[0], l1[1], ap[0], ap[1], { e: 0.3 }); B.seg(ap[0], ap[1], r1[0], r1[1], { e: 0.3 });
        B.post(l0[0], l0[1], 0.1); B.post(r0[0], r0[1], 0.1);
        const a = P(0, -hw), b = P(0, hw), id = D.ramps.length;
        B.line(a[0], a[1], b[0], b[1], 'ramp', id, cx + ux, cy + uy);
        const pts = catmull([[cx, cy]].concat(ctrl), 12);
        const cum = [0]; for (let i = 1; i < pts.length; i++) cum.push(cum[i - 1] + Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]));
        D.ramps.push({ id, pts, cum, len: cum[cum.length - 1], l0, l1, r0, r1, ap, ux, uy, cx, cy });
      },
    };
    // cabinet: side walls, top arch, shooter lane with a one-way gate at its top
    B.poly([[0, 18.9], [0, 4.6]]);
    const arc = []; for (let i = 0; i <= 32; i++) { const a = Math.PI + Math.PI * i / 32; arc.push([5 + 5 * Math.cos(a), 4.6 + 4.4 * Math.sin(a)]); }
    B.poly(arc, { e: 0.3 }); D.arc = arc;
    B.poly([[10, 4.6], [10, 18.9]]);
    B.seg(PF, 18.9, PF, 4.6); B.post(PF, 4.6, 0.06, { e: 0.3 });
    D.gate = face(B.seg(PF, 4.6, 9.94, 3.9, { k: 'g', e: 0.25 }), 9.5, 3.4);
    // top rollover lanes
    const archY = (x) => 4.6 - 4.4 * Math.sqrt(Math.max(0, 1 - ((x - 5) / 5) * ((x - 5) / 5)));
    const gy = [4.45, 5.55, 6.65, 7.75].map((x) => { const y0 = Math.max(2.3, archY(x) + 0.8); B.seg(x, y0, x, y0 + 1.0, { e: 0.4 }); B.post(x, y0, 0.09); B.post(x, y0 + 1.0, 0.09); return y0 + 0.5; });
    D.lanes = LANES.map((x, i) => ({ x, y: (gy[i] + gy[i + 1]) / 2 }));
    D.lanes.forEach((q, i) => D.pts.push({ k: 'lane', id: i, x: q.x, y: q.y, r: 0.32 }));
    // lower: outlane separators, inlane guides, slingshots, side deflectors (mirror about the playfield centre)
    for (const sd of [0, 1]) {
      const X = (x) => (sd ? PF - x : x);
      B.seg(X(0.68), 12.9, X(0.68), 16.6); B.post(X(0.68), 12.9, 0.12, { e: 0.7 });
      B.seg(X(0.68), 14.304, X(2.703), 15.299, { e: 0.25 });   // tangent to the flipper pivot → the ball rolls onto the flipper
      const a = [X(1.5), 12.35], b = [X(1.5), 13.6], c = [X(2.3), 14.15];
      B.seg(a[0], a[1], b[0], b[1], { e: 0.55 }); B.seg(b[0], b[1], c[0], c[1], { e: 0.5 });
      face(B.seg(c[0], c[1], a[0], a[1], { k: 'sl', id: sd, e: 0.6 }), 4.65, 13.2);
      B.post(a[0], a[1], 0.12, { e: 0.6 }); B.post(b[0], b[1], 0.12, { e: 0.5 }); B.post(c[0], c[1], 0.12, { e: 0.5 });
      B.seg(X(0), 10.9, X(0.92), 11.42, { e: 0.3 });
      D.slings.push({ a, b, c, sd });
    }
    S.build(B);
    // broad phase: 1×1 cells → collider indices
    const gs = [], gc = [];
    for (let i = 0; i < GC * GR; i++) { gs.push([]); gc.push([]); }
    const put = (arr, idx, x0, y0, x1, y1) => {
      const m = R + 0.15, c0 = U.clamp(Math.floor(x0 - m), 0, GC - 1), c1 = U.clamp(Math.floor(x1 + m), 0, GC - 1), r0 = U.clamp(Math.floor(y0 - m), 0, GR - 1), r1 = U.clamp(Math.floor(y1 + m), 0, GR - 1);
      for (let r = r0; r <= r1; r++) for (let c = c0; c <= c1; c++) arr[r * GC + c].push(idx);
    };
    D.segs.forEach((s, i) => put(gs, i, Math.min(s.ax, s.bx), Math.min(s.ay, s.by), Math.max(s.ax, s.bx), Math.max(s.ay, s.by)));
    D.circ.forEach((c, i) => put(gc, i, c.x - c.r, c.y - c.r, c.x + c.r, c.y + c.r));
    D.gs = gs; D.gc = gc;
    return D;
  }

  /* ======================= simulation ======================= */
  function newTable(ti, seed, nb) {
    const D = getDef(ti), r = mkRng((seed ^ 0x5bd1e995) >>> 0);
    const M = D.S.missions, order = M.map((_, i) => i);
    for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const t = order[i]; order[i] = order[j]; order[j] = t; }
    const T = {
      D, ti, r, nb: nb === 5 ? 5 : 3, t: 0, acc: 0, n: 0, sc: 0, ball: 1, ph: 'play', balls: [], bid: 0,
      fl: [{ a: A_DN, w: 0, up: false }, { a: A_DN, w: 0, up: false }],
      inp: { l: false, r: false, fire: -1, nudge: false }, pull: 0,
      mult: 1, bonus: 0, lanes: [0, 0, 0], drop: D.drops.map(() => 1), dropT: 0, spA: 0, spW: 0,
      fb: D.bumpers.map(() => -9), fsl: [-9, -9], fd: D.drops.map(() => -9), fst: D.stands.map(() => -9), fsau: -9, fl8: [-9, -9, -9], giT: -9,
      order, mi: 0, mk: 0, mp: 0, lockLit: false, locks: 0, multi: false, jack: 10000,
      sq: 0, sj: 20000, brT: 0, fg: D.gears.map(() => -9), fm: D.mags.map(() => -9),
      save: 0, saveArm: true, extra: 0, exG: false, tilt: 0, tilted: false, autoQ: 0, autoT: 0, man: false, manT: 0,
      sk: -1, skT: 0, bonT: 0, bonP: 0, ev: [], mq: [], ai: null, launchT: -9, overT: -1,
    };
    newBall(T, true);
    return T;
  }
  function mkBall(T, x, y) { return { id: ++T.bid, x, y, px: x, py: y, vx: 0, vy: 0, m: 'play', rp: -1, ri: 0, s: 0, rv: 0, ht: 0, nc: 0, still: 0, lm: 0 }; }
  function laneBall(T) { const b = mkBall(T, LX, PLY - R - 0.002); b.m = 'lane'; return b; }
  function newBall(T, first, again) {
    T.balls.push(laneBall(T)); T.man = true; T.manT = 0; T.saveArm = true; T.save = 0;
    T.mult = 1; T.bonus = 0; T.tilt = 0; T.tilted = false; T.multi = false; T.autoQ = 0; T.autoT = 0;
    T.sk = Math.floor(T.r() * 3); T.skT = 0;
    say(T, again ? '한 번 더! 공 ' + T.ball + ' 다시' : first ? '발사 준비!' : '공 ' + T.ball + ' / ' + T.nb, 1.8);
  }
  function magPos(T, m) { const a = m.ph + m.w * T.t; return [m.cx + Math.cos(a) * m.rad, m.cy + Math.sin(a) * m.rad]; }
  function bridgeOpen(T) { return T.brT > 0 || (T.t % BRIDGE_CYC) < BRIDGE_OPEN; }
  function E(T, k, x, y, p, id) { if (T.ev.length < 80) T.ev.push({ k, x: x || 0, y: y || 0, p: p || 0, id: id || 0 }); }
  function say(T, text, d) {
    if (T.mq.length >= 3) T.mq.splice(1, T.mq.length - 2);
    T.mq.push({ t: text, d: d || 1.5 });
  }
  function add(T, p, x, y) {
    if (T.tilted || T.ph !== 'play' || !p) return;
    T.sc += p;
    if (p >= 500 && x != null) E(T, 'pts', x, y, p);
  }
  function curMis(T) { const M = T.D.S.missions; return M[T.order[T.mi % M.length]]; }
  function misNeed(T) { const M = T.D.S.missions; return curMis(T)[2] * (1 + Math.floor(T.mk / M.length)); }
  function progress(T, k) {
    if (curMis(T)[1] !== k) return;
    T.mp++;
    if (T.mp < misNeed(T)) return;
    const award = 5000 * (T.mk + 1);
    T.mk++; T.mi++; T.mp = 0;
    T.sc += award; T.giT = T.t;
    say(T, '미션 성공! +' + fmt(award), 2); E(T, 'mission', 4.65, 8, award);
    if (T.mk === (T.nb === 5 ? 5 : 3) && !T.exG) { T.exG = true; T.extra++; say(T, '공 추가! 한 번 더', 2.2); E(T, 'extra', 4.65, 12.9); }
  }
  function feat(T, k, id, x, y) {
    E(T, k, x, y, 0, id);
    if (T.tilted || T.ph !== 'play') return;
    T.bonus += BON[k] || 0;
    add(T, PTS[k] || 0, x, y);
    if (k === 'drop') {
      T.fd[id] = T.t;
      if (T.drop.every((v) => !v)) feat(T, 'dropAll', 0, x, y);
    } else if (k === 'dropAll') {
      if (!T.multi && !T.lockLit) { T.lockLit = true; say(T, '잠금 준비! ' + T.D.S.lockTxt, 2.4); E(T, 'lockLit', x, y); }
      T.dropT = (T.D.S.holdDrops && T.lockLit) ? 0 : 1.3;
    } else if (k === 'sau') {
      if (!T.multi && T.lockLit) {
        T.locks++;
        if (T.locks >= 2) startMulti(T);
        else { say(T, '공 잠금 1 / 2', 1.6); E(T, 'lock', x, y); }
      }
    } else if (k === 'ramp' && T.multi) {
      T.sc += T.jack; T.giT = T.t; T.nj = (T.nj | 0) + 1;
      say(T, '잭팟! +' + fmt(T.jack), 2); E(T, 'jack', x, y, T.jack);
      T.jack += 5000;
    } else if (k === 'bump') T.fb[id] = T.t;
    else if (k === 'sling') T.fsl[id] = T.t;
    else if (k === 'tgt') { T.fst[id] = T.t; if (T.D.bridge >= 0) { if (!bridgeOpen(T)) say(T, '시간 다리가 내려와요!', 1.4); T.brT = BRIDGE_HOLD; E(T, 'bridge', x, y); } }
    else if (k === 'gear') T.fg[id] = T.t;
    else if (k === 'mag') { T.fm[id] = T.t; if (T.multi && T.D.S.magJack) { T.sc += 3000; T.giT = T.t; say(T, '자석 잭팟 +3,000', 1.2); E(T, 'pts', x, y, 3000); } }
    const SQ = T.D.S.seq;
    if (SQ && k === SQ[T.sq % SQ.length]) {
      T.sq++;
      if (T.sq % SQ.length === 0) {
        T.sc += T.sj; T.giT = T.t; T.nj = (T.nj | 0) + 1;
        say(T, '시계 잭팟! +' + fmt(T.sj), 2.2); E(T, 'jack', x, y, T.sj);
        T.sj += 10000;
      } else { add(T, 1000, x, y); say(T, '잭팟 순서 ' + (T.sq % SQ.length) + ' / ' + SQ.length, 1.0); }
    }
    progress(T, k);
  }
  function startMulti(T) {
    T.multi = true; T.nm = (T.nm | 0) + 1; T.locks = 0; T.lockLit = false; T.autoQ += 2; T.save = Math.max(T.save, 10); T.giT = T.t;
    if (T.D.S.holdDrops) T.dropT = 1.0;
    for (const b of T.balls) if (b.m === 'hold') b.ht = Math.max(b.ht, 1.8);
    say(T, '멀티볼! 램프 = 잭팟', 2.4); E(T, 'multi', 4.65, 8);
  }
  function lane(T, i, x, y) {
    if (T.tilted || T.ph !== 'play') return;
    if (T.skT > 0 && i === T.sk) { T.sc += 10000; T.giT = T.t; say(T, '스킬 샷! +10,000', 2); E(T, 'skill', x, y, 10000); }
    T.skT = 0; T.sk = -1;
    if (!T.lanes[i]) { T.lanes[i] = 1; T.fl8[i] = T.t; feat(T, 'lane', i, x, y); }
    else { add(T, 100); E(T, 'lane0', x, y); }
    if (T.lanes[0] && T.lanes[1] && T.lanes[2]) {
      T.lanes = [0, 0, 0]; T.fl8 = [T.t, T.t, T.t];
      if (T.mult < 5) T.mult++;
      say(T, '보너스 ×' + T.mult, 1.6);
      feat(T, 'laneAll', 0, 5, 2);
    }
  }
  function laneShift(T, i) {
    if (T.ph !== 'play') return;
    const a = T.lanes;
    T.lanes = i ? [a[2], a[0], a[1]] : [a[1], a[2], a[0]];
    if (T.man && T.sk >= 0) T.sk = (T.sk + (i ? 1 : 2)) % 3;
  }
  function onPlunger(T) {
    for (const b of T.balls) if (b.m === 'lane' && b.y > PLY - R - 0.15 && b.vy > -2) return b;
    return null;
  }
  function fire(T, p, auto) {
    const b = onPlunger(T);
    T.pull = 0;
    if (!b) return false;
    p = U.clamp(p, 0, 1);
    b.y = PLY - R - 0.002; b.vy = -(22 + 5.5 * p); b.vx = 0;   // the plunger snaps back carrying the ball
    if (!auto) T.man = false;
    T.manT = 0; T.launchT = T.t;
    E(T, 'launch', b.x, b.y, Math.round(p * 100));
    return true;
  }
  function nudge(T) {
    if (T.ph !== 'play' || T.tilted) return;
    for (const b of T.balls) if (b.m === 'play') { b.vy -= 2.8; b.vx += (b.x < 4.65 ? 1 : -1) * 1.1; b.still = 0; }
    T.tilt += 1; E(T, 'nudge');
    if (T.tilt >= 3.2) { T.tilted = true; T.save = 0; T.autoQ = 0; say(T, '기울임! TILT', 3); E(T, 'tilt', 4.65, 9); }
    else if (T.tilt >= 2) { say(T, '경고! 그만 흔들어요', 1.5); E(T, 'warn', 4.65, 9); }
  }
  function leftLane(T) {
    if (T.saveArm) { T.save = SAVE_T; T.saveArm = false; T.skT = T.sk >= 0 ? 3.5 : 0; }
  }
  function capture(T, b) {
    const S = T.D.saucer;
    for (const o of T.balls) if (o.m === 'hold') return;
    b.m = 'hold'; b.x = S.x; b.y = S.y; b.vx = 0; b.vy = 0; b.ht = 1.1; T.fsau = T.t;
    feat(T, 'sau', 0, S.x, S.y);
  }
  function kick(T, b) {
    const S = T.D.saucer;
    b.m = 'play'; b.vx = S.kx * S.ks; b.vy = S.ky * S.ks; b.nc = 0.6; b.px = b.x; b.py = b.y; b.lm = 0;
    E(T, 'kick', b.x, b.y);
  }
  function enterRamp(T, b, id) {
    b.m = 'ramp'; b.rp = id; b.s = 0; b.ri = 0; b.rv = U.clamp(Math.hypot(b.vx, b.vy) * 0.8, 9, 24);
    E(T, 'rampIn', b.x, b.y, 0, id);
  }
  function rideRamp(T, b) {
    const Rp = T.D.ramps[b.rp], f = b.s / Rp.len;
    b.rv += (f < 0.45 ? -7 : 6) * DT; if (b.rv < 7) b.rv = 7;
    b.s += b.rv * DT;
    const P = Rp.pts, C = Rp.cum;
    if (b.s >= Rp.len) {
      const a = P[P.length - 2], c = P[P.length - 1], dx = c[0] - a[0], dy = c[1] - a[1], l = Math.hypot(dx, dy) || 1, sp = Math.min(6, b.rv * 0.5);
      b.m = 'play'; b.x = c[0]; b.y = c[1]; b.px = b.x; b.py = b.y; b.vx = dx / l * sp; b.vy = dy / l * sp; b.lm = 0; b.still = 0;
      feat(T, 'ramp', b.rp, b.x, b.y - 1);
      return;
    }
    while (b.ri < C.length - 2 && C[b.ri + 1] < b.s) b.ri++;
    const i = b.ri, u = (b.s - C[i]) / ((C[i + 1] - C[i]) || 1);
    b.x = P[i][0] + (P[i + 1][0] - P[i][0]) * u; b.y = P[i][1] + (P[i + 1][1] - P[i][1]) * u;
  }

  function hitSeg(T, b, s) {
    if (s.k === 'd' && !T.drop[s.id]) return;
    let t = ((b.x - s.ax) * s.dx + (b.y - s.ay) * s.dy) / s.l2; t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = s.ax + s.dx * t, qy = s.ay + s.dy * t, ex = b.x - qx, ey = b.y - qy, d2 = ex * ex + ey * ey;
    if (d2 >= R * R) return;
    if (s.k === 'g' && (b.px - s.ax) * s.nx + (b.py - s.ay) * s.ny < R * 0.8) return; // one-way gate: only blocks from above
    let nx, ny;
    if (d2 > 1e-12) { const d = Math.sqrt(d2); nx = ex / d; ny = ey / d; } else { nx = s.nx || 0; ny = s.ny || -1; }
    b.x = qx + nx * R; b.y = qy + ny * R;
    const vn = b.vx * nx + b.vy * ny;
    if (vn >= 0) return;
    if (s.k === 'sl' && !T.tilted && nx * s.nx + ny * s.ny > 0.6 && -vn > 0.8) {
      const out = Math.max(-vn * 0.45, 0) + 9, vf = b.vx * s.nx + b.vy * s.ny;
      b.vx += s.nx * (out - vf); b.vy += s.ny * (out - vf);
      feat(T, 'sling', s.id, (s.ax + s.bx) / 2, (s.ay + s.by) / 2);
      return;
    }
    b.vx -= (1 + s.e) * vn * nx; b.vy -= (1 + s.e) * vn * ny;
    if (s.k === 'd') {
      if (-vn > 0.8 && (b.px - s.ax) * s.nx + (b.py - s.ay) * s.ny > 0) { T.drop[s.id] = 0; feat(T, 'drop', s.id, (s.ax + s.bx) / 2, (s.ay + s.by) / 2); }
    } else if (s.k === 'st') {
      if (-vn > 0.8 && T.t - T.fst[s.id] > 0.25) feat(T, 'tgt', s.id, (s.ax + s.bx) / 2, (s.ay + s.by) / 2);
    }
  }
  function hitCirc(T, b, c) {
    const ex = b.x - c.x, ey = b.y - c.y, d2 = ex * ex + ey * ey, lim = R + c.r;
    if (d2 >= lim * lim) return;
    const d = Math.sqrt(d2) || 1e-6, nx = ex / d, ny = ey / d;
    b.x = c.x + nx * lim; b.y = c.y + ny * lim;
    const vn = b.vx * nx + b.vy * ny;
    if (vn >= 0) return;
    if (c.k === 'gr') {
      b.vx -= (1 + c.e) * vn * nx; b.vy -= (1 + c.e) * vn * ny;
      const tv = c.w * c.r * 0.9, out = 2.5;   // rim speed drags the ball sideways, plus a small spring
      b.vx += -ny * tv + nx * out; b.vy += nx * tv + ny * out;
      if (T.t - T.fg[c.id] > 0.2 && -vn > 0.6) feat(T, 'gear', c.id, c.x, c.y);
      return;
    }
    if (c.k === 'b' && !T.tilted) {
      const out = Math.max(-vn * 0.5, 0) + 10.5;
      b.vx += nx * (out - vn); b.vy += ny * (out - vn);
      feat(T, 'bump', c.id, c.x, c.y);
      return;
    }
    b.vx -= (1 + c.e) * vn * nx; b.vy -= (1 + c.e) * vn * ny;
  }
  function hitFlip(T, b, i) {
    const f = T.fl[i], P = FP[i];
    const ca = Math.cos(f.a), sa = Math.sin(f.a), dx = i ? -ca : ca, dy = sa;
    const rx = b.x - P[0], ry = b.y - P[1];
    let t = (rx * dx + ry * dy) / FL; t = t < 0 ? 0 : t > 1 ? 1 : t;
    const qx = P[0] + dx * FL * t, qy = P[1] + dy * FL * t;
    const rr = FR0 + (FR1 - FR0) * t, ex = b.x - qx, ey = b.y - qy, d2 = ex * ex + ey * ey, lim = R + rr;
    if (d2 >= lim * lim) return;
    const d = Math.sqrt(d2) || 1e-6, nx = ex / d, ny = ey / d;
    b.x = qx + nx * lim; b.y = qy + ny * lim;
    const cx = qx + nx * rr - P[0], cy = qy + ny * rr - P[1], om = i ? -f.w : f.w;
    const sx = -om * cy, sy = om * cx;
    const rvx = b.vx - sx, rvy = b.vy - sy, vn = rvx * nx + rvy * ny;
    if (vn < 0) {
      const e = f.w !== 0 ? 0.32 : 0.2, tx = -ny, ty = nx, vt = (rvx * tx + rvy * ty) * 0.985, nvn = -vn * e;
      b.vx = sx + nx * nvn + tx * vt; b.vy = sy + ny * nvn + ty * vt;
    }
  }
  function sensors(T, b) {
    const D = T.D, LS = D.lines;
    for (let i = 0; i < LS.length; i++) {
      const s = LS[i];
      const sp = (b.px - s.ax) * s.nx + (b.py - s.ay) * s.ny, sc = (b.x - s.ax) * s.nx + (b.y - s.ay) * s.ny;
      if ((sp < 0) === (sc < 0)) continue;
      const t = ((b.x - s.ax) * s.dx + (b.y - s.ay) * s.dy) / s.l2;
      if (t < -0.05 || t > 1.05) continue;
      const vn = b.vx * s.nx + b.vy * s.ny;
      if (s.k === 'spin') { const w = Math.min(70, Math.abs(vn) * 3.2); if (w > T.spW) T.spW = w; E(T, 'spinIn'); continue; }
      if (sp >= 0) continue;
      if (s.k === 'orb') { if (vn > 4) feat(T, 'orb', 0, (s.ax + s.bx) / 2, s.ay); }
      else if (s.k === 'ramp' && b.m === 'play') {
        if (vn >= 10.5 && (s.id !== D.bridge || bridgeOpen(T))) { enterRamp(T, b, s.id); return; }
        b.x = b.px - s.nx * 0.005; b.y = b.py - s.ny * 0.005;
        b.vx -= 1.4 * vn * s.nx; b.vy -= 1.4 * vn * s.ny;
        E(T, 'rampFail', b.x, b.y);
      }
    }
    const PS = D.pts;
    for (let i = 0; i < PS.length; i++) {
      const q = PS[i], dx = b.x - q.x, dy = b.y - q.y, ins = dx * dx + dy * dy < q.r * q.r, bit = 1 << i;
      if (ins && !(b.lm & bit)) { b.lm |= bit; if (q.k === 'lane') lane(T, q.id, q.x, q.y); }
      else if (!ins && (b.lm & bit)) b.lm &= ~bit;
    }
    const S = D.saucer;
    if (S && b.m === 'play' && b.nc <= 0) {
      const dx = b.x - S.x, dy = b.y - S.y;
      if (dx * dx + dy * dy < 0.09 && b.vx * b.vx + b.vy * b.vy < 300) capture(T, b);
    }
  }
  function moveBall(T, b, fy) {
    if (b.m === 'ramp') { rideRamp(T, b); return; }
    if (b.m === 'hold') { b.ht -= DT; if (b.ht <= 0) kick(T, b); return; }
    b.px = b.x; b.py = b.y;
    b.vy += GRAV * DT;
    const sp2 = b.vx * b.vx + b.vy * b.vy;
    if (sp2 > VMAX * VMAX) { const k = VMAX / Math.sqrt(sp2); b.vx *= k; b.vy *= k; }
    b.x += b.vx * DT; b.y += b.vy * DT;
    const D = T.D;
    const cx = b.x < 0 ? 0 : b.x >= GC ? GC - 1 : b.x | 0, cy = b.y < 0 ? 0 : b.y >= GR ? GR - 1 : b.y | 0, ci = cy * GC + cx;
    const ls = D.gs[ci]; for (let i = 0; i < ls.length; i++) hitSeg(T, b, D.segs[ls[i]]);
    const lc = D.gc[ci]; for (let i = 0; i < lc.length; i++) hitCirc(T, b, D.circ[lc[i]]);
    if (b.y > 14.1 && b.x < PF) { hitFlip(T, b, 0); hitFlip(T, b, 1); }
    if (b.x > PF && b.y > fy - R) { b.y = fy - R; if (b.vy > 0) b.vy = b.vy > 1.5 ? -b.vy * 0.2 : 0; }
    if (b.m === 'lane' && (b.y < 4.3 || b.x < PF - 0.02)) { b.m = 'play'; leftLane(T); }
    else if (b.m === 'play' && b.x > PF + 0.05 && b.y > 4.8) b.m = 'lane';   // fell back into the shooter lane → it can be plunged again
    if (b.m === 'play' && D.mags.length) {
      for (const m of D.mags) {
        const p = magPos(T, m), dx = p[0] - b.x, dy = p[1] - b.y, d = Math.hypot(dx, dy);
        if (d < m.r && d > 1e-4) {
          const k = m.k * (T.multi && T.D.S.magJack ? 1.4 : 1) * (1 - d / m.r);
          b.vx += dx / d * k * DT; b.vy += dy / d * k * DT;
          if (d < 0.45 && T.t - T.fm[m.id] > 0.8) feat(T, 'mag', m.id, p[0], p[1]);
        }
      }
    }
    if (b.m === 'play') sensors(T, b);
    if (b.nc > 0) b.nc -= DT;
    if (b.m === 'play') {
      if (b.vx * b.vx + b.vy * b.vy < 0.16 && b.y < 14.1) {
        b.still += DT;
        if (b.still > 3) { b.still = 0; b.vx = (T.r() - 0.5) * 6; b.vy = -6 - T.r() * 4; E(T, 'search', b.x, b.y); }
      } else b.still = 0;
    }
  }
  function drained(T, b) {
    E(T, 'drain', b.x, 17.5);
    if (T.ph !== 'play') return;
    if (!T.tilted && T.save > 0) { T.autoQ++; say(T, '공 보호! 다시 발사', 1.6); E(T, 'save', 4.65, 14.35); return; }
    const live = T.balls.length + T.autoQ;
    if (live > 0) { if (T.multi && live <= 1) { T.multi = false; say(T, '멀티볼 끝', 1.2); } return; }
    endBall(T);
  }
  function endBall(T) {
    T.ph = 'bonus'; T.bonT = 2.6; T.multi = false; T.inp.l = T.inp.r = false;
    T.bonP = T.tilted ? 0 : T.bonus * T.mult;
    T.sc += T.bonP;
    T.bb = Math.max(T.bb | 0, T.sc - (T.b0 | 0)); T.b0 = T.sc; // best single ball (result stats)
    T.mq.length = 0;
    say(T, T.tilted ? '기울임 — 보너스 없음' : '보너스 ' + fmt(T.bonus) + ' × ' + T.mult + ' = ' + fmt(T.bonP), 2.5);
    E(T, 'bonus', 4.65, 12, T.bonP);
  }
  function nextBall(T) {
    const again = T.extra > 0;
    if (again) { T.extra--; E(T, 'again'); } else T.ball++;
    T.mq.length = 0;
    if (T.ball > T.nb) { T.ph = 'over'; T.overT = T.t; say(T, '게임 끝 · ' + fmt(T.sc) + '점', 1e9); E(T, 'over'); return; }
    T.ph = 'play';
    newBall(T, false, again);
  }
  function resetDrops(T) {
    for (const s of T.D.drops) for (const b of T.balls) {
      if (b.m !== 'play') continue;
      let t = ((b.x - s.ax) * s.dx + (b.y - s.ay) * s.dy) / s.l2; t = U.clamp(t, 0, 1);
      if (Math.hypot(b.x - s.ax - s.dx * t, b.y - s.ay - s.dy * t) < R + 0.05) { T.dropT = 0.2; return; }
    }
    T.drop = T.drop.map(() => 1); E(T, 'dropReset');
  }

  function sub(T) {
    T.t += DT; T.n++;
    if (T.ai && (T.n & 3) === 0) aiThink(T);
    if (T.mq.length) { T.mq[0].d -= DT; if (T.mq[0].d <= 0 && T.mq.length > 1) T.mq.shift(); else if (T.mq[0].d <= 0) T.mq.shift(); }
    if (T.ph === 'bonus') { T.bonT -= DT; if (T.bonT <= 0) nextBall(T); }
    for (let i = 0; i < 2; i++) {
      const f = T.fl[i], want = !T.tilted && T.ph === 'play' && (i ? T.inp.r : T.inp.l);
      if (want && !f.up) { f.up = true; E(T, 'flip', 0, 0, 0, i); laneShift(T, i); }
      else if (!want && f.up) f.up = false;
      if (f.up) { if (f.a > A_UP) { f.a -= W_UP * DT; f.w = -W_UP; if (f.a <= A_UP) { f.a = A_UP; f.w = 0; } } else f.w = 0; }
      else if (f.a < A_DN) { f.a += W_DN * DT; f.w = W_DN; if (f.a >= A_DN) { f.a = A_DN; f.w = 0; } } else f.w = 0;
    }
    if (T.ph === 'over') { T.balls.length = 0; return; }
    if (T.inp.fire >= 0) { const p = T.inp.fire; T.inp.fire = -1; if (T.man || T.autoT <= 0) fire(T, p, false); }
    if (T.ph === 'play' && T.autoQ > 0 && !T.balls.some((b) => b.m === 'lane')) { T.balls.push(laneBall(T)); T.autoQ--; T.autoT = 0.5; }
    if (T.autoT > 0) { T.autoT -= DT; if (T.autoT <= 0) fire(T, 0.72 + T.r() * 0.18, true); }
    if (T.inp.nudge) { T.inp.nudge = false; nudge(T); }
    if (T.tilt > 0) T.tilt = Math.max(0, T.tilt - 0.45 * DT);
    const fy = PLY + 0.6 * T.pull;
    const bs = T.balls;
    for (let k = 0; k < bs.length; k++) moveBall(T, bs[k], fy);
    if (bs.length > 1) {
      for (let i = 0; i < bs.length; i++) for (let j = i + 1; j < bs.length; j++) {
        const a = bs[i], c = bs[j];
        if ((a.m !== 'play' && a.m !== 'lane') || (c.m !== 'play' && c.m !== 'lane')) continue;
        const dx = c.x - a.x, dy = c.y - a.y, d2 = dx * dx + dy * dy;
        if (d2 >= 4 * R * R || d2 < 1e-12) continue;
        const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, pen = (2 * R - d) / 2;
        a.x -= nx * pen; a.y -= ny * pen; c.x += nx * pen; c.y += ny * pen;
        const vn = (c.vx - a.vx) * nx + (c.vy - a.vy) * ny;
        if (vn < 0) { const j2 = -0.95 * vn; a.vx -= nx * j2; a.vy -= ny * j2; c.vx += nx * j2; c.vy += ny * j2; }
      }
    }
    for (let k = bs.length - 1; k >= 0; k--) {
      const b = bs[k];
      if (b.y > 18.7) { bs.splice(k, 1); drained(T, b); }
      else if (!(b.x > -1 && b.x < 11 && b.y > -1.5)) { bs.splice(k, 1); E(T, 'lost'); if (T.ph === 'play') T.autoQ++; }
    }
    if (T.ph === 'play') {
      if (T.save > 0) T.save -= DT;
      if (T.skT > 0) { T.skT -= DT; if (T.skT <= 0) T.sk = -1; }
      if (T.dropT > 0) { T.dropT -= DT; if (T.dropT <= 0) resetDrops(T); }
      if (T.brT > 0) T.brT -= DT;
      if (!T.man && T.autoT <= 0 && onPlunger(T) && !T.balls.some((b) => b.m === 'lane' && b.vy < -1)) { T.manT += DT; if (T.manT > 0.4) T.man = true; } else T.manT = 0;
      if (T.balls.length === 0 && T.autoQ === 0) endBall(T);
    }
    if (T.spW > 0) {
      const a0 = T.spA; T.spA += T.spW * DT; T.spW = Math.max(0, T.spW - (3 + T.spW * 0.5) * DT);
      if (Math.floor(T.spA / Math.PI) !== Math.floor(a0 / Math.PI)) { const S = T.D.spinner; feat(T, 'spin', 0, S.x, S.y); }
    }
  }
  function stepT(T, dt, maxSteps) {
    T.acc += dt;
    let n = 0;
    const lim = maxSteps || 2400;
    while (T.acc >= DT && n < lim) { sub(T); T.acc -= DT; n++; }
    if (T.acc > DT * 4) T.acc = DT * 4;
    return n;
  }

  /* ======================= AI ======================= */
  const SIG = [0, 0.04, 0.022, 0.004], MISS = [0, 0.1, 0.05, 0.003], CRADLE = [0, 0, 0.35, 0.8];
  const PREF = ['ramp', 'sau', 'orb', 'drop', 'tgt', 'gear', 'mag', 'lane', 'bump', 'spin'];
  const aiF = () => ({ st: 0, t: 0, cd: 0, aim: 0.6, bid: -1, err: 0, miss: false, cr: false, rest: 0 });
  function aiInit(T, lv, seed) { T.ai = { lv: U.clamp(lv | 0 || 2, 1, 3), r: mkRng(seed), f: [aiF(), aiF()], plT: -1, nuT: 0 }; }
  function gauss(r) { return (r() + r() + r() + r() - 2) * 1.73; }
  function aiWant(T) {
    if (T.multi) return 'ramp';
    if (T.lockLit) return 'sau';
    const k = curMis(T)[1], SQ = T.D.S.seq;
    if (SQ && (k === 'bump' || k === 'spin' || k === 'laneAll')) return SQ[T.sq % SQ.length];   // passive mission → chase the jackpot order
    return k === 'dropAll' ? 'drop' : k === 'laneAll' ? 'lane' : k;
  }
  function chooseAim(T, A, i) {
    const lv = A.lv, r = A.r;
    if (lv === 1) return 0.3 + r() * 0.6;
    if (lv === 2 && r() < 0.5) return 0.45 + r() * 0.4;
    const P = PREP[T.ti];
    if (!P || !P.done) return 0.45 + r() * 0.4;
    const tb = P.shots[i], want = aiWant(T);
    let best = null;
    const runOf = (k) => { let bl = 0, bs = -1, cl = 0, cs = -1; tb.forEach((e, j) => { if (e.ev === k) { if (!cl) cs = j; cl++; if (cl > bl) { bl = cl; bs = cs; } } else cl = 0; }); return bl ? tb[bs + Math.floor((bl - 1) / 2)] : null; };
    best = runOf(want);
    if (!best) for (const k of PREF) { best = runOf(k); if (best) break; }
    if (!best) return 0.6;
    return best.u + (r() - 0.5) * (lv === 3 ? 0.02 : 0.06);
  }
  function aiPower(T, lv, r) {
    if (lv === 3) {
      const P = PREP[T.ti];
      if (P && P.done && T.sk >= 0) {
        const c = P.plunge.filter((e) => e.l === T.sk);
        if (c.length) return c[Math.floor(c.length / 2)].p + (r() - 0.5) * 0.035;
      }
      return 0.6 + r() * 0.3;
    }
    if (lv === 2 && r() < 0.35) { const P = PREP[T.ti]; if (P && P.done && T.sk >= 0) { const c = P.plunge.filter((e) => e.l === T.sk); if (c.length) return c[Math.floor(c.length / 2)].p + (r() - 0.5) * 0.06; } }
    return lv === 2 ? 0.45 + r() * 0.5 : 0.3 + r() * 0.7;
  }
  function aiPress(T, F, key, now, A) { T.inp[key] = true; F.st = 1; F.t = now + 0.16 + A.r() * 0.12; F.bid = -1; }
  function aiFlip(T, A, i) {
    const F = A.f[i], fr = FRAME[i], key = i ? 'r' : 'l', lv = A.lv, now = T.t;
    if (F.st === 1) { T.inp[key] = true; if (now >= F.t) { T.inp[key] = false; F.st = 0; F.cd = now + 0.1; } return; }
    if (F.st === 2) { // cradle: hold the flipper up until the ball settles in the corner
      T.inp[key] = true;
      const b = T.balls.find((x) => x.id === F.bid && x.m === 'play');
      if (!b || now - F.t > 2.2 || b.y < fr.py - 2.2) { F.st = 0; F.bid = -1; T.inp[key] = false; return; }
      F.rest = (Math.hypot(b.vx, b.vy) < 0.8 && Math.hypot(b.x - fr.px, b.y - fr.py) < FL + 0.4) ? F.rest + 4 * DT : 0;
      if (F.rest > 0.3) { F.aim = chooseAim(T, A, i); F.st = 3; F.t = now; T.inp[key] = false; }
      return;
    }
    if (F.st === 3) { // released from the cradle: flip when the ball rolls to the aim point
      T.inp[key] = false;
      const b = T.balls.find((x) => x.id === F.bid && x.m === 'play');
      if (!b || now - F.t > 1.6) { F.st = 0; F.bid = -1; return; }
      const rx = b.x - fr.px, ry = b.y - fr.py, u = (rx * fr.dx + ry * fr.dy) / FL, vd = b.vx * fr.dx + b.vy * fr.dy;
      if (now - F.t > 0.05 && (u + vd * 0.02 / FL >= F.aim || u > 0.95)) aiPress(T, F, key, now, A);
      return;
    }
    T.inp[key] = false;
    if (now < F.cd) return;
    // earliest ball to enter this flipper's sweep zone (short ballistic look-ahead)
    let best = null, bt = 9, bu = 0, bgap = 0, bvd = 0, bsp = 0;
    for (const b of T.balls) {
      if (b.m !== 'play' || b.y < fr.py - 7) continue;
      const vn0 = b.vx * fr.nx + b.vy * fr.ny;
      let x = b.x, y = b.y, vx = b.vx, vy = b.vy;
      for (let k = 0; k <= 28; k++) {
        const rx = x - fr.px, ry = y - fr.py, u = (rx * fr.dx + ry * fr.dy) / FL, dn = rx * fr.nx + ry * fr.ny;
        const gap = dn - (R + FR0 + (FR1 - FR0) * U.clamp(u, 0, 1));
        if (u > -0.05 && u < 1.04 && gap > -0.35 && gap < Math.max(0.07, 1.1 * u)) {
          if (k === 0 && vn0 > 2 && gap > 0.12) break;   // just shot away — leave it
          const te = k * 0.01;
          if (te < bt) { best = b; bt = te; bu = u; bgap = gap; bvd = vx * fr.dx + vy * fr.dy; bsp = Math.hypot(vx, vy); }
          break;
        }
        x += vx * 0.01; y += vy * 0.01; vy += GRAV * 0.01;
      }
    }
    if (!best) return;
    if (best.id !== F.bid) {
      F.bid = best.id; F.err = gauss(A.r) * SIG[lv]; F.miss = A.r() < MISS[lv]; F.cr = A.r() < CRADLE[lv]; F.aim = chooseAim(T, A, i);
    }
    if (F.miss) return;
    if (F.cr && bt > 0.04 && bt < 0.14 && bsp < 15 && bu > 0.15 && bu < 0.9) { F.st = 2; F.t = now; F.rest = 0; T.inp[key] = true; return; }
    if (bt === 0) {
      if (bgap < 0.1) { if (bu + bvd * 0.025 / FL >= F.aim || bu > 0.9) aiPress(T, F, key, now, A); }   // rolling on the flipper: wait for the aim spot
      else if (bu + bvd * 0.02 / FL >= F.aim - 0.15 || bu > 0.7 || bvd > 3) aiPress(T, F, key, now, A);   // flying through the sweep
      return;
    }
    if (bt < 0.02 + F.err) aiPress(T, F, key, now, A);
  }
  function aiThink(T) {
    const A = T.ai, lv = A.lv;
    if (T.ph !== 'play' || T.tilted) { T.inp.l = T.inp.r = false; A.f[0].st = A.f[1].st = 0; return; }
    if (T.man && onPlunger(T)) {
      if (A.plT < 0) A.plT = T.t + (lv === 1 ? 1.0 : 0.5) + A.r() * 0.9;
      else if (T.t >= A.plT) { A.plT = -1; T.inp.fire = aiPower(T, lv, A.r); }
    } else A.plT = -1;
    aiFlip(T, A, 0); aiFlip(T, A, 1);
    if (lv >= 2 && T.t > A.nuT && T.tilt < 1.1) {
      for (const b of T.balls) {
        if (b.m === 'play' && b.vy > 1 && b.y > 11.6 && b.y < 13.3 && (b.x < 0.75 || b.x > PF - 0.75)) {
          A.nuT = T.t + 1.5;
          if (lv === 3 || A.r() < 0.3) T.inp.nudge = true;
          break;
        }
      }
    }
  }

  /* AI calibration (deterministic sandbox runs, cached per table): which flipper spot hits which shot, which plunge
     power drops into which top lane. Built incrementally (a few sims per frame) so it never stalls a phone. */
  const PREP = [];
  const SHOT_EV = { ramp: 'ramp', rampIn: 'ramp', sau: 'sau', orb: 'orb', drop: 'drop', tgt: 'tgt', lane: 'lane', lane0: 'lane', bump: 'bump', spinIn: 'spin', gear: 'gear', mag: 'mag' };
  function prepJobs(ti) {
    const P = { done: false, shots: [[], []], plunge: [], jobs: [] };
    const rest = [null, null];
    for (let i = 0; i < 2; i++) {
      P.jobs.push(() => {
        const S = newTable(ti, 7), key = i ? 'r' : 'l', cu = Math.cos(A_UP), su = Math.sin(A_UP), ux = i ? -cu : cu, nx = i ? -su : su;
        S.balls = [mkBall(S, FP[i][0] + ux * FL * 0.6 + nx * 0.8, FP[i][1] + su * FL * 0.6 - cu * 0.8)]; S.man = false;
        S.fl[i].a = A_UP; S.fl[i].up = true; S.inp[key] = true;
        let still = 0;
        for (let k = 0; k < HZ * 3 && S.balls.length; k++) { sub(S); const b = S.balls[0]; if (b && Math.hypot(b.vx, b.vy) < 0.4) { if (++still > HZ * 0.3) break; } else still = 0; }
        rest[i] = S.balls[0] ? Object.assign({}, S.balls[0]) : null;
      });
      for (let u = 0.2; u < 0.96; u += 0.05) {
        const uu = Math.round(u * 100) / 100;
        P.jobs.push(() => {
          if (!rest[i]) { P.shots[i].push({ u: uu, ev: 'none' }); return; }
          const Q = newTable(ti, 7), fr = FRAME[i], key = i ? 'r' : 'l';
          Q.balls = [Object.assign({}, rest[i])]; Q.man = false; Q.fl[i].a = A_UP; Q.fl[i].up = true;
          Q.inp[key] = false; Q.ev.length = 0;
          let fired = -1, ev = 'drain';
          for (let k = 0; k < HZ * 4; k++) {
            sub(Q);
            const b = Q.balls[0];
            if (!b || Q.ph !== 'play') break;
            if (fired < 0) {
              if (k % 4 === 0) { const u2 = ((b.x - fr.px) * fr.dx + (b.y - fr.py) * fr.dy) / FL, vd = b.vx * fr.dx + b.vy * fr.dy; if (u2 + vd * 0.02 / FL >= uu || k > HZ * 1.5) { Q.inp[key] = true; fired = k; } }
              Q.ev.length = 0;
            } else {
              if (k - fired > HZ * 0.25) Q.inp[key] = false;
              const e = Q.ev.find((x) => SHOT_EV[x.k]);
              if (e) { ev = SHOT_EV[e.k]; break; }
              Q.ev.length = 0;
            }
          }
          P.shots[i].push({ u: uu, ev });
        });
      }
    }
    for (let p = 0; p <= 1.0001; p += 0.025) {
      const pp = Math.round(p * 1000) / 1000;
      P.jobs.push(() => {
        const Q = newTable(ti, 7); Q.ev.length = 0; Q.inp.fire = pp;
        let l = -1;
        for (let k = 0; k < HZ * 3.5; k++) { sub(Q); const e = Q.ev.find((x) => x.k === 'lane' || x.k === 'lane0'); if (e) { l = Q.D.pts.findIndex((q) => q.k === 'lane' && Math.abs(q.x - e.x) < 0.01); break; } Q.ev.length = 0; if (!Q.balls.length) break; }
        P.plunge.push({ p: pp, l });
      });
    }
    return P;
  }
  function prepAI(ti, budgetMs) {
    let P = PREP[ti];
    if (!P) P = PREP[ti] = prepJobs(ti);
    if (P.done) return true;
    const t0 = (typeof performance !== 'undefined' ? performance : Date).now();
    while (P.jobs.length) {
      P.jobs.shift()();
      if (budgetMs != null && (typeof performance !== 'undefined' ? performance : Date).now() - t0 > budgetMs) break;
    }
    if (!P.jobs.length) P.done = true;
    return P.done;
  }

  /* ======================= pure game interface ======================= */
  function init(players, opts) {
    const o = opts || {};
    const tb = Number.isInteger(o.table) && o.table >= 0 && o.table < TABLES.length ? o.table : U.rand(TABLES.length);
    return { rid: 1 + U.rand(99999), n: players.length, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)), tb, bl: o.balls === 5 ? 5 : 3, sd: 1 + U.rand(2147483646), ph: 'play', res: null };
  }
  function finish(s, rows) { // rows: [[seat, score]]
    const res = rows.slice().sort((a, b) => b[1] - a[1] || a[0] - b[0]);
    return Object.assign({}, s, { ph: 'done', res });
  }
  function statRows(s) { // res rows: [seat, score, jackpots, multiballs, best ball]
    const by = []; s.res.forEach((r) => { if (Array.isArray(r) && r[0] >= 0 && r[0] < s.n) by[r[0]] = r; });
    const col = (k, f) => Array.from({ length: s.n }, (_, i) => (by[i] ? f(by[i][k] | 0) : '-'));
    return [{ label: '점수', values: col(1, fmt) }, { label: '잭팟', values: col(2, (v) => v + '번') },
      { label: '멀티볼', values: col(3, (v) => v + '번') }, { label: '최고 공 하나', values: col(4, fmt) }];
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    const head = (TABLES[s.tb] ? TABLES[s.tb].n : '') + ' · 공 ' + (s.bl || 3) + '개';
    if (s.n === 1) { const r = s.res[0]; return { winners: [r[0]], title: fmt(r[1]) + '점!', text: head + '\n공 ' + (s.bl || 3) + '개로 ' + fmt(r[1]) + '점을 냈어요', stats: statRows(s) }; }
    const top = s.res[0][1], winners = s.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = s.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + fmt(r[1]) + '점');
    return { winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + lines.join('\n'), stats: statRows(s) };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const KC = () => { const v = L.ui && L.ui.ctlScale ? +L.ui.ctlScale() : 1; return v > 0 ? Math.min(v, 1.2) : 1; }; // 1.2 상한: 더 크면 흔들기 버튼이 배수구를 가림
  const CSS = `
.pb-btn{position:absolute;left:50%;transform:translateX(-50%);min-width:96px;height:44px;padding:0 16px;border-radius:22px;z-index:3;
  background:rgba(23,19,31,.78);color:var(--ink,#f2e9d8);border:1.5px solid rgba(227,174,69,.75);font:700 14px var(--f-body,sans-serif);
  box-shadow:0 2px 10px rgba(0,0,0,.45);touch-action:none;-webkit-user-select:none;user-select:none;cursor:pointer}
.pb-btn:active,.pb-btn.on{background:rgba(227,174,69,.9);color:#17131f}
.pb-btn[hidden]{display:none}
`;
  const KEYN = { ShiftLeft: '왼 Shift', ShiftRight: '오른 Shift', Slash: '/', Space: '스페이스', ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Enter: 'Enter' };
  const keyName = (c) => KEYN[c] || String(c || '').replace(/^Key/, '').replace(/^Digit/, '');

  /* first-play control hint (realtime): small card at match start, once per device */
  function tipOnce(root, api, id, lines) {
    try {
      if (L.debug && (L.debug.noTut || L.debug.autoplay)) return;
      if (!api.mySeats || !api.mySeats().length) return;
      const k = 'lounge.tip.' + id; if (localStorage.getItem(k)) return; localStorage.setItem(k, '1');
    } catch (e) { return; }
    const el = L.h('div', { style: { position: 'absolute', left: '50%', top: '24%', transform: 'translateX(-50%)', width: 'min(86%, 340px)', boxSizing: 'border-box', padding: '12px 14px', borderRadius: '12px',
      background: 'rgba(18,14,24,.9)', color: '#f2e9d8', border: '1px solid rgba(227,174,69,.6)', font: '500 13px/1.55 "IBM Plex Sans KR",system-ui,sans-serif', zIndex: 6, pointerEvents: 'none', transition: 'opacity .5s', boxShadow: '0 4px 18px rgba(0,0,0,.5)' } },
      L.h('div', { text: '처음이세요? 이렇게 조작해요', style: { fontWeight: '700', color: '#e3ae45', marginBottom: '4px' } }), lines.map((t) => L.h('div', { text: '· ' + t })));
    try { if (getComputedStyle(root).position === 'static') root.style.position = 'relative'; } catch (e) {}
    root.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; }, 7000); setTimeout(() => el.remove(), 7600);
  }
  function mount(root, api) {
    tipOnce(root, api, "pinball", ["화면 왼쪽·오른쪽을 누르면 그쪽 플리퍼가 올라가요(누르고 있으면 받쳐요)", "발사: 누른 채 아래로 끌었다 놓기 — 톡 누르면 알맞은 힘", "「흔들기」로 공을 살짝 튀겨요. 너무 자주 하면 기울임(TILT)", "PC: Z·/ 플리퍼, 스페이스 발사, X 흔들기"]);
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const DPR = () => Math.min(2.5, cv.dpr || 1);
    const Pl = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.nm && st.nm[s]) || Pl(s).name || (s + 1) + '번';
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    const auto = () => !!(L.debug && L.debug.autoplay);
    const fine = (() => { try { return matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP; } catch (e) { return false; } })();

    let st = null, key = null, TS = [], view = 0, lay = null, stat = null, rampL = null, sprites = null, statKey = '';
    let endWait = 0, ff = 1, overSeen = false, autoSwitchT = -1, pubT = 0, lastSig = '', shake = 0, warnT = 0, frameN = 0;
    let cdT = 0, endBan = 0, newBest = false;
    let parts = [], floats = [], hintT = 0, plHold = null, kHold = -1, lastSfx = {};
    const remote = {}, heard = {}, ptr = new Map();

    const curKey = () => (st ? st.rid + '.' + st.tb + '.' + (st.bl || 3) : null);
    const NB = () => (st && st.bl === 5 ? 5 : 3);
    function ensureMatch() {
      if (!st) return;
      const k = curKey();
      if (k === key) return;
      key = k;
      TS = [];
      for (let s = 0; s < st.n; s++) {
        if (!simHere(s)) { TS[s] = null; continue; }
        const T = newTable(st.tb, st.sd, st.bl);
        const p = api.players[s];
        if (p && p.ai) aiInit(T, p.lv || 2, (st.sd ^ (s * 7919 + 13)) >>> 0);
        else if (auto() && isMine(s)) aiInit(T, 3, (st.sd ^ (99 + s * 31)) >>> 0);
        TS[s] = T;
      }
      const m = mine(), fst = TS.findIndex(Boolean);
      view = m.length && TS[m[0]] ? m[0] : (fst >= 0 ? fst : 0);
      for (const x in remote) delete remote[x];
      parts = []; floats = []; endWait = 0; ff = 1; overSeen = false; autoSwitchT = -1; hintT = 0; plHold = null; kHold = -1;
      ptr.clear();
      stat = null; cdT = st.ph === 'play' ? 2.6 : 0; endBan = 0; newBest = false;
      if (st.ph === 'done') TS.forEach((T) => { if (T) { T.ph = 'over'; T.balls.length = 0; } });
      layout();
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const hudH = 44, dmdW = Math.min(w - 12, 470), dmdH = Math.round(U.clamp(dmdW * DRW / DC / 1.25, 26, 40));
      const top = hudH + dmdH + 8, avail = h - top - 4;
      const sc = Math.max(8, Math.min((w - 8) / 10.4, avail / 18.5));
      const ox = (w - 10 * sc) / 2, oy = top + 0.15 * sc + Math.max(0, (avail - 18.5 * sc) * 0.4);
      lay = { w, h, hudH, dmdH, dmdW, sc, ox, oy, dmdY: hudH + 2 };
      stat = null; rampL = null; sprites = null;
      placeButtons();
    }
    cv.onresize = layout;

    /* ----- DOM buttons: nudge / fast-forward ----- */
    const nudgeBtn = L.h('button', { 'data-action': 'nudge', class: 'pb-btn', type: 'button', text: '흔들기', 'aria-label': '테이블 흔들기' });
    const ffBtn = L.h('button', { 'data-action': 'ff', class: 'pb-btn', type: 'button', text: '▶▶ 빨리 보기', hidden: true });
    nudgeBtn.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); doNudge(); nudgeBtn.classList.add('on'); setTimeout(() => nudgeBtn.classList.remove('on'), 120); });
    ffBtn.addEventListener('pointerdown', (e) => { e.stopPropagation(); e.preventDefault(); ff = ff > 1 ? 1 : 6; api.sfx('click'); syncButtons(); });
    root.appendChild(nudgeBtn); root.appendChild(ffBtn);
    const offFF = api.input ? api.input.on((t, id) => { if (t === 'down' && id === 'ff' && !ffBtn.hidden && ffBtn.getClientRects().length) ffBtn.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true })); }) : null;
    function placeButtons() {
      if (!lay) return;
      const k = KC(), bh = Math.max(44, Math.round(44 * k));
      const y = Math.min(lay.h - bh - 6, lay.oy + 17.25 * lay.sc - (bh - 44) / 2);
      for (const b of [nudgeBtn, ffBtn]) { b.style.top = y + 'px'; b.style.height = bh + 'px'; b.style.borderRadius = (bh / 2) + 'px'; b.style.minWidth = '96px'; b.style.fontSize = Math.round(14 * Math.max(1, Math.min(1.3, k))) + 'px'; }
    }
    const onCtl = () => placeButtons(); window.addEventListener('lounge-ctl', onCtl);
    let btnSig = '';
    function syncButtons() {
      const T = myT();
      const showN = !!(T && canCtl() && T.ph === 'play');
      const anyAI = TS.some((X, s) => X && X.ph !== 'over' && !isMine(s));
      const myDone = !T || T.ph === 'over';
      const showF = myDone && anyAI && st && st.ph === 'play';
      const sig = (showN ? 1 : 0) + '|' + (showF ? 1 : 0) + '|' + ff;
      if (sig === btnSig) return;
      btnSig = sig;
      nudgeBtn.hidden = !showN; ffBtn.hidden = !showF;
      ffBtn.textContent = ff > 1 ? '▶ 보통 속도' : '▶▶ 빨리 보기';
    }

    /* ----- input ----- */
    function myT() { const m = mine()[0]; return m != null ? TS[m] : null; }
    function canCtl() { const m = mine()[0]; const T = m != null ? TS[m] : null; return !!T && view === m && T.ph !== 'over' && !auto(); }
    function waiting(T) { return !!(T && T.ph === 'play' && T.man && onPlunger(T) && !T.balls.some((b) => b.m === 'play' || b.m === 'ramp' || b.m === 'hold')); }
    function doNudge() {
      const T = myT();
      if (!T || !canCtl() || T.ph !== 'play') return;
      T.inp.nudge = true; shake = 1; api.buzz(25); sfx('thud', 80);
    }
    function onDown(e) {
      if (!lay || !st) return;
      e.preventDefault();
      const p = cv.local(e);
      if (p.y < lay.hudH) { tapChip(p.x); return; }
      if (!canCtl()) { if (p.y < lay.dmdY + lay.dmdH + 4) tapChip(-1); return; }
      const T = myT();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      if (waiting(T)) { const q = { k: 'P', y0: p.y, t0: performance.now(), dy: 0 }; ptr.set(e.pointerId, q); plHold = q; return; }
      const k = p.x < lay.w / 2 ? 'L' : 'R';
      ptr.set(e.pointerId, { k, y0: p.y, t0: performance.now(), nud: false });
      api.buzz(8);
    }
    function onMove(e) {
      const q = ptr.get(e.pointerId);
      if (!q) return;
      const p = cv.local(e);
      if (q.k === 'P') q.dy = Math.max(0, p.y - q.y0);
      else if (!q.nud && q.y0 - p.y > Math.max(36, lay.h * 0.06) && performance.now() - q.t0 < 280) { q.nud = true; doNudge(); }
    }
    function onUp(e) {
      const q = ptr.get(e.pointerId);
      if (!q) return;
      ptr.delete(e.pointerId);
      if (q.k === 'P') { if (plHold === q) plHold = null; releasePlunger(performance.now() - q.t0, q.dy); }
    }
    function pullOf(heldMs, dy) { return dy > 10 ? U.clamp(dy / (lay.sc * 3.2), 0, 1) : U.clamp((heldMs - 120) / 1100, 0, 1); }
    function releasePlunger(ms, dy) {
      const T = myT();
      if (!T || !canCtl()) return;
      const tap = ms < 220 && dy < 10;
      const pl = tap ? 0.45 : pullOf(ms, dy), p = pl < 0.8 ? 0.3 + 0.5 * pl : 0.7 + 1.5 * (pl - 0.8);   // the top-lane band gets most of the meter
      if (waiting(T)) { T.inp.fire = p; api.buzz(tap ? 15 : 10 + Math.round(pl * 25)); }
      T.pull = 0;
    }
    function tapChip(x) {
      if (!st || canCtl()) return;
      const n = st.n, cw = (lay.w - 8 - (n - 1) * 4) / n;
      let s = x < 0 ? -1 : Math.floor((x - 4) / (cw + 4));
      if (s < 0 || s >= n || !TS[s]) { // cycle
        const idx = TS.map((T, i) => (T ? i : -1)).filter((i) => i >= 0);
        if (idx.length < 2) return;
        s = idx[(idx.indexOf(view) + 1) % idx.length];
      }
      if (s === view) return;
      view = s; autoSwitchT = -2; api.sfx('click');
    }
    const offKeys = api.input && api.input.on ? api.input.on((type, id) => {
      const T = myT();
      if (!T || !canCtl()) return;
      if (id === 'plunge') {
        if (type === 'down') { if (waiting(T)) kHold = performance.now(); }
        else if (kHold >= 0) { const ms = performance.now() - kHold; kHold = -1; releasePlunger(ms, 0); }
      } else if (id === 'nudge' && type === 'down') doNudge();
      else if ((id === 'flipL' || id === 'flipR') && type === 'down') api.buzz(8);
    }) : null;
    function applyInput() {
      const T = myT();
      if (!T) return;
      if (T.ai) return;
      if (!canCtl()) { T.inp.l = T.inp.r = false; T.pull = 0; return; }
      let l = false, r = false;
      for (const q of ptr.values()) { if (q.k === 'L') l = true; else if (q.k === 'R') r = true; }
      const inp = api.input;
      if (inp && inp.held) { if (inp.held('flipL')) l = true; if (inp.held('flipR')) r = true; }
      T.inp.l = l; T.inp.r = r;
      const now = performance.now();
      if (waiting(T)) {
        if (plHold) T.pull = pullOf(now - plHold.t0, plHold.dy);
        else if (kHold >= 0) T.pull = pullOf(now - kHold, 0);
        else T.pull = 0;
      } else { T.pull = 0; if (plHold && !ptr.has(plHold)) plHold = null; }
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- effects ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 50)) return; lastSfx[n] = t; api.sfx(n); }
    function burst(x, y, col, n, sp, life) {
      for (let i = 0; i < n; i++) { const a = Math.random() * TAU, v = sp * (0.35 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: life, T: life, c: col }); }
      if (parts.length > 160) parts.splice(0, parts.length - 160);
    }
    function pop(x, y, text, col, big) { floats.push({ x, y, text, col: col || '#fff3c0', t: 1.1, T: 1.1, big: !!big }); if (floats.length > 14) floats.shift(); }
    function onEvents(T, me) {
      const th = T.D.th;
      for (const e of T.ev) {
        switch (e.k) {
          case 'flip': sfx('tick', 40); break;
          case 'bump': sfx('pop', 45); burst(e.x, e.y, th.bumpT, 7, 4, 0.35); if (me) api.buzz(12); break;
          case 'sling': sfx('hit', 50); burst(e.x, e.y, '#ffffff', 4, 3, 0.25); if (me) api.buzz(10); break;
          case 'drop': sfx('thud', 40); burst(e.x, e.y, th.drop, 6, 3, 0.4); if (me) api.buzz(14); break;
          case 'tgt': sfx('chip', 50); burst(e.x, e.y, th.stand, 5, 3, 0.35); if (me) api.buzz(10); break;
          case 'spin': sfx('tick', 35); break;
          case 'lane': sfx('chip', 60); burst(e.x, e.y, th.ins.lane, 6, 2.5, 0.4); break;
          case 'rampIn': sfx('roll', 80); break;
          case 'rampFail': sfx('thud', 80); break;
          case 'ramp': sfx('whoosh', 80); if (me) api.buzz(18); break;
          case 'orb': sfx('whoosh', 80); break;
          case 'sau': sfx('roll', 80); burst(e.x, e.y, th.ins.sau, 8, 2.5, 0.5); if (me) api.buzz(20); break;
          case 'kick': sfx('thud', 60); if (me) api.buzz(15); break;
          case 'launch': sfx('whoosh', 60); if (me) api.buzz(20); break;
          case 'drain': sfx('lose', 200); shake = Math.max(shake, 0.6); if (me) api.buzz(45); break;
          case 'save': sfx('pop', 100); pop(4.65, 13.6, '공 보호!', '#9dffb0', true); break;
          case 'mission': sfx('win', 150); burst(4.65, 8.6, '#ffe27a', 14, 4.5, 0.7); pop(4.65, 8.6, '미션 성공!', '#ffe27a', true); if (me) api.buzz([20, 30, 20]); break;
          case 'jack': sfx('win', 150); shake = Math.max(shake, 0.5); pop(e.x, e.y, '잭팟!', '#ffe27a', true); burst(e.x, e.y, '#ffe27a', 16, 5, 0.7); if (me) api.buzz([30, 30, 40]); break;
          case 'multi': sfx('win', 150); shake = Math.max(shake, 0.5); burst(4.65, 8.6, '#ff9ad8', 18, 5, 0.8); pop(4.65, 8.6, '멀티볼!', '#ff9ad8', true); if (me) api.buzz([40, 40, 40]); break;
          case 'skill': sfx('win', 150); pop(e.x, e.y + 0.8, '스킬 샷!', '#9dffb0', true); if (me) api.buzz([20, 20, 20]); break;
          case 'extra': sfx('win', 150); pop(4.65, 12.2, '공 추가!', '#ffe27a', true); break;
          case 'lockLit': sfx('chip', 100); pop(e.x, e.y, '잠금 준비!', '#ffcf7a'); break;
          case 'lock': sfx('chip', 100); pop(e.x, e.y - 0.6, '공 잠금!', '#ffcf7a'); break;
          case 'tilt': sfx('thud', 100); warnT = 1.5; shake = 1; if (me) api.buzz([60, 40, 60]); break;
          case 'warn': sfx('tick', 100); warnT = 0.8; if (me) api.buzz(30); break;
          case 'bonus': sfx('chip', 100); break;
          case 'over': sfx('whoosh', 100); break;
          case 'pts': pop(e.x, e.y, '+' + fmt(e.p), e.p >= 5000 ? '#ffe27a' : '#fff3c0', e.p >= 5000); break;
        }
      }
      T.ev.length = 0;
    }

    /* ----- online ----- */
    function scoreRow(s) {
      if (st && st.ph === 'done' && Array.isArray(st.res)) { const r = st.res.find((x) => x[0] === s); if (r) return [r[1], NB(), 1, r[2] | 0, r[3] | 0, r[4] | 0]; }
      const T = TS[s];
      if (T) return [T.sc, Math.min(T.nb, T.ball), T.ph === 'over' ? 1 : 0, T.nj | 0, T.nm | 0, T.bb | 0];
      const r = remote[s];
      return r ? [r.sc, r.b, r.f, r.x[0], r.x[1], r.x[2]] : [0, 1, 0, 0, 0, 0];
    }
    function pollNet() {
      if (!api.online || !key) return;
      const now = performance.now();
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (!rem || typeof rem !== 'object') return;
        for (const k in rem) {
          const s = +k, o = rem[k];
          if (!(s >= 0 && s < st.n) || TS[s] || !o || o.k !== key) continue;
          const x = Array.isArray(o.x) ? o.x : [];
          const v = { sc: Math.max(0, o.sc | 0), b: U.clamp(o.b | 0, 1, NB()), f: o.f ? 1 : 0, x: [x[0] | 0, x[1] | 0, x[2] | 0] };
          const old = remote[s];
          if (!old || old.sc !== v.sc || old.b !== v.b || old.f !== v.f) heard[s] = now;
          remote[s] = v;
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== key || !Array.isArray(hs.s)) return;
        hs.s.forEach((a, s) => { if (TS[s] || !Array.isArray(a)) return; remote[s] = { sc: a[0] | 0, b: a[1] | 0, f: a[2] ? 1 : 0, x: [a[3] | 0, a[4] | 0, a[5] | 0] }; });
      }
    }
    function publish(rdt) {
      if (!api.online || !key || !st) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 0.25;
          const s = []; for (let i = 0; i < st.n; i++) s.push(scoreRow(i));
          api.net.hostSend({ k: key, s });
        } else {
          const m = mine()[0], T = m != null ? TS[m] : null;
          if (!T) return;
          const f = T.ph === 'over' ? 1 : 0, sig = T.sc + '|' + T.ball + '|' + f + '|' + (T.nj | 0) + '|' + (T.nm | 0);
          if (sig === lastSig && pubT > 0) return;
          lastSig = sig; pubT = 0.6;
          api.net.publish({ k: key, sc: T.sc, b: Math.min(T.nb, T.ball), f, x: [T.nj | 0, T.nm | 0, T.bb | 0] });
        }
      } catch (e) {}
    }
    function hostEnd(rdt) {
      if (!host() || !st || st.ph !== 'play') return;
      let localDone = true, all = true;
      const now = performance.now();
      for (let s = 0; s < st.n; s++) {
        const T = TS[s];
        if (T) { if (T.ph !== 'over' || T.t - T.overT < 1.0) { localDone = false; all = false; } }
        else if (!(remote[s] && remote[s].f)) {
          // a guest that went silent for 40 s after everyone else finished counts as finished
          if (!(localDone && heard[s] && now - heard[s] > 40000)) all = false;
        }
      }
      if (!all) { endWait = 0; return; }
      endWait += rdt;
      if (endWait > 0.8) {
        const rows = []; for (let s = 0; s < st.n; s++) { const r = scoreRow(s); rows.push([s, r[0], r[3] | 0, r[4] | 0, r[5] | 0]); }
        endWait = -1e9;
        api.setState(finish(st, rows));
      }
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      frameN++;
      if (st && st.ph === 'play') ensureMatch();
      else if (st && st.ph === 'done' && key !== curKey()) ensureMatch();
      if (!st || !key) { draw(now); return; }
      // AI calibration in small slices
      if (TS.some((T) => T && T.ai && T.ai.lv >= 2)) prepAI(st.tb, 4);
      if (auto()) { const M0 = myT(); if (M0 && !M0.ai) aiInit(M0, 3, (st.sd ^ (99 + mine()[0] * 31)) >>> 0); }
      applyInput();
      const dt = rdt * SPD();
      if (cdT > 0 && st.ph === 'play') { const c0 = Math.ceil(cdT - 0.6); cdT -= rdt * SPD(); const c1 = Math.ceil(cdT - 0.6); if (c1 !== c0) sfx(c1 > 0 ? 'tick' : 'chip', 20); }
      const playing = st.ph === 'play' && cdT <= 0;
      TS.forEach((T, s) => {
        if (!T) return;
        if (playing) {
          const k = !isMine(s) || auto() ? ff : 1;
          stepT(T, dt * k, Math.ceil(HZ * 0.06 * SPD() * k) + 4);
        }
        if (s !== view) T.ev.length = 0;
      });
      pollNet();
      const V = TS[view];
      if (V) onEvents(V, isMine(view) || !mine().length);
      // my game over → watch someone still playing
      const M = myT();
      if (M && M.ph === 'over' && !overSeen) {
        overSeen = true; autoSwitchT = 2.8;
        endBan = 0.001;
        if (!auto() && !M.ai && api.best) { try { newBest = !!api.best('t' + st.tb + 'b' + NB(), M.sc, { label: TABLES[st.tb].n + ' · 공 ' + NB() + '개', unit: '점' }); } catch (e) {} if (newBest) { sfx('win', 100); api.buzz([30, 30, 30]); } }
      }
      if (autoSwitchT > 0) {
        autoSwitchT -= rdt;
        if (autoSwitchT <= 0) { const s = TS.findIndex((T, i) => T && T.ph !== 'over' && !isMine(i)); if (s >= 0) view = s; }
      }
      hostEnd(rdt);
      publish(rdt);
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vy += 6 * rdt; if (q.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= rdt; if (floats[i].t <= 0) floats.splice(i, 1); }
      if (endBan > 0) endBan += rdt;
      shake = Math.max(0, shake - rdt * 5); warnT = Math.max(0, warnT - rdt);
      if (V && isMine(view) && V.ph === 'play') hintT += rdt;
      syncButtons();
      draw(now);
    }

    /* ----- static layers (cached) ----- */
    function mkC(wc, hc) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(wc)); c.height = Math.max(1, Math.ceil(hc)); return c; }
    function playPath(g, D) {
      g.beginPath(); g.moveTo(0, 18.4);
      for (const p of D.arc) g.lineTo(p[0], p[1]);
      g.lineTo(10, 18.4); g.closePath();
    }
    function arrowPath(g, x, y, a, s) {
      const c = Math.cos(a), si = Math.sin(a), P = [[0.55, 0], [-0.4, -0.45], [-0.12, 0], [-0.4, 0.45]];
      g.beginPath();
      P.forEach((p, i) => { const X = x + (p[0] * c - p[1] * si) * s, Y = y + (p[0] * si + p[1] * c) * s; if (i) g.lineTo(X, Y); else g.moveTo(X, Y); });
      g.closePath();
    }
    const insCache = [];
    function insShapes(D) { // every light insert: {x,y,kind,ev,a,lab}
      if (insCache[D.ti]) return insCache[D.ti];
      const out = D.S.ins.map((q) => ({ x: q.x, y: q.y, kind: 'arr', ev: q.ev, a: q.a }));
      [3.75, 4.35, 4.95, 5.55].forEach((x, k) => out.push({ x, y: 13.45, kind: 'dot', ev: 'mult', v: k + 2, lab: (k + 2) + '×' }));
      out.push({ x: 4.65, y: 14.3, kind: 'pill', ev: 'save', lab: '공 보호' });
      out.push({ x: 4.65, y: 12.75, kind: 'dot', ev: 'extra', lab: '+1' });
      return (insCache[D.ti] = out);
    }
    function drawRail(g, s, th, w) {
      g.lineCap = 'round';
      g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = w + 0.06; g.beginPath(); g.moveTo(s.ax + 0.05, s.ay + 0.07); g.lineTo(s.bx + 0.05, s.by + 0.07); g.stroke();
      g.strokeStyle = th.railD; g.lineWidth = w; g.beginPath(); g.moveTo(s.ax, s.ay); g.lineTo(s.bx, s.by); g.stroke();
      g.strokeStyle = th.rail; g.lineWidth = w * 0.45; g.beginPath(); g.moveTo(s.ax - 0.015, s.ay - 0.02); g.lineTo(s.bx - 0.015, s.by - 0.02); g.stroke();
    }
    function drawArt(g, D) {
      const th = D.th, r = mkRng(31 + D.ti * 977);
      g.save();
      if (D.ti === 0) { // harbour: waves, compass rose, dotted treasure route
        g.strokeStyle = 'rgba(180,240,255,.07)'; g.lineWidth = 0.08;
        for (let k = 0; k < 12; k++) { const y = 5.2 + k * 1.05; g.beginPath(); for (let x = 0; x <= 9.4; x += 0.2) { const yy = y + Math.sin(x * 1.6 + k) * 0.12; if (x) g.lineTo(x, yy); else g.moveTo(x, yy); } g.stroke(); }
        const cx = 4.65, cy = 10.9;
        g.strokeStyle = 'rgba(255,230,180,.22)'; g.lineWidth = 0.05; g.beginPath(); g.arc(cx, cy, 1.25, 0, TAU); g.stroke(); g.beginPath(); g.arc(cx, cy, 1.05, 0, TAU); g.stroke();
        for (let k = 0; k < 8; k++) {
          const a = k * Math.PI / 4, l = k % 2 ? 0.7 : 1.15;
          g.fillStyle = k % 2 ? 'rgba(255,230,180,.12)' : 'rgba(255,230,180,.22)';
          g.beginPath(); g.moveTo(cx + Math.cos(a) * l, cy + Math.sin(a) * l); g.lineTo(cx + Math.cos(a + 0.35) * 0.22, cy + Math.sin(a + 0.35) * 0.22); g.lineTo(cx, cy); g.lineTo(cx + Math.cos(a - 0.35) * 0.22, cy + Math.sin(a - 0.35) * 0.22); g.closePath(); g.fill();
        }
        g.setLineDash([0.18, 0.16]); g.strokeStyle = 'rgba(255,210,140,.25)'; g.lineWidth = 0.06;
        g.beginPath(); g.moveTo(3.1, 12.4); g.bezierCurveTo(2.2, 10.6, 5.6, 9.6, 6.6, 8.2); g.stroke(); g.setLineDash([]);
        g.strokeStyle = 'rgba(255,120,90,.45)'; g.lineWidth = 0.09; g.beginPath(); g.moveTo(6.8, 7.75); g.lineTo(7.1, 8.05); g.moveTo(7.1, 7.75); g.lineTo(6.8, 8.05); g.stroke();
      } else if (D.ti === 1) { // space: stars, nebula, ringed planet, orbit ellipses
        const neb = (x, y, rad, col) => { const gr = g.createRadialGradient(x, y, 0, x, y, rad); gr.addColorStop(0, col); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(x - rad, y - rad, rad * 2, rad * 2); };
        neb(2.5, 6, 3.2, 'rgba(160,80,255,.16)'); neb(7.2, 11.5, 3, 'rgba(60,200,255,.12)'); neb(4.6, 3, 2.6, 'rgba(255,90,180,.10)');
        for (let k = 0; k < 140; k++) { const x = r() * 9.3, y = r() * 17, s = r() < 0.1 ? 0.05 : 0.025; g.fillStyle = 'rgba(255,255,255,' + (0.25 + r() * 0.5).toFixed(2) + ')'; g.fillRect(x, y, s, s); }
        g.strokeStyle = 'rgba(150,210,255,.14)'; g.lineWidth = 0.04;
        for (let k = 0; k < 3; k++) { g.beginPath(); g.ellipse(4.65, 11.1, 1.2 + k * 0.55, 0.45 + k * 0.2, -0.15, 0, TAU); g.stroke(); }
        const px = 4.65, py = 11.1, pg = g.createRadialGradient(px - 0.2, py - 0.25, 0.05, px, py, 0.6);
        pg.addColorStop(0, '#9fd4ff'); pg.addColorStop(1, '#2a3a8a'); g.fillStyle = pg; g.beginPath(); g.arc(px, py, 0.55, 0, TAU); g.fill();
        g.strokeStyle = 'rgba(255,220,150,.6)'; g.lineWidth = 0.07; g.beginPath(); g.ellipse(px, py, 0.95, 0.24, -0.3, 0, TAU); g.stroke();
      } else if (D.ti === 3) { // deep ruins: light shafts, broken columns, glyph ring, bubbles
        for (let k = 0; k < 5; k++) { const x = 1 + k * 2; g.fillStyle = 'rgba(160,255,230,.035)'; g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 0.8, 0); g.lineTo(x + 2.4, 18); g.lineTo(x + 1.2, 18); g.closePath(); g.fill(); }
        g.fillStyle = 'rgba(120,200,190,.08)';
        for (const [x, h] of [[1.9, 2.4], [7.3, 3.0], [3.1, 1.4], [6.2, 1.8]]) { g.fillRect(x - 0.3, 13 - h, 0.6, h); g.fillRect(x - 0.42, 13 - h - 0.18, 0.84, 0.18); }
        g.strokeStyle = 'rgba(190,140,255,.22)'; g.lineWidth = 0.05; g.beginPath(); g.arc(4.65, 8.6, 0.95, 0, TAU); g.stroke();
        g.strokeStyle = 'rgba(190,140,255,.1)'; g.lineWidth = 0.25; g.beginPath(); g.arc(4.65, 8.6, 1.35, 0, TAU); g.stroke();
        for (let k = 0; k < 12; k++) { const a = k * TAU / 12; g.fillStyle = 'rgba(200,170,255,.28)'; g.fillRect(4.65 + Math.cos(a) * 1.35 - 0.05, 8.6 + Math.sin(a) * 1.35 - 0.05, 0.1, 0.1); }
        for (let k = 0; k < 40; k++) { g.strokeStyle = 'rgba(200,255,245,' + (0.08 + r() * 0.15).toFixed(2) + ')'; g.lineWidth = 0.025; g.beginPath(); g.arc(r() * 9.3, 4 + r() * 13, 0.04 + r() * 0.09, 0, TAU); g.stroke(); }
      } else if (D.ti === 4) { // clock tower: big dial with roman ticks, background cogs, rivets
        const cx = 4.65, cy = 10.9;
        g.strokeStyle = 'rgba(255,220,150,.22)'; g.lineWidth = 0.06; g.beginPath(); g.arc(cx, cy, 1.5, 0, TAU); g.stroke(); g.beginPath(); g.arc(cx, cy, 1.25, 0, TAU); g.stroke();
        for (let k = 0; k < 12; k++) { const a = k * TAU / 12, l0 = k % 3 ? 1.3 : 1.18; g.lineWidth = k % 3 ? 0.04 : 0.08; g.beginPath(); g.moveTo(cx + Math.cos(a) * l0, cy + Math.sin(a) * l0); g.lineTo(cx + Math.cos(a) * 1.45, cy + Math.sin(a) * 1.45); g.stroke(); }
        g.strokeStyle = 'rgba(255,220,150,.35)'; g.lineWidth = 0.08; g.lineCap = 'round';
        g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + 0.55, cy - 0.65); g.moveTo(cx, cy); g.lineTo(cx - 0.2, cy + 0.95); g.stroke();
        const cog = (x, y, rad, n) => { g.beginPath(); for (let k = 0; k < n * 2; k++) { const a = k * Math.PI / n, l = k % 2 ? rad * 0.82 : rad; g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); } g.closePath(); g.stroke(); g.beginPath(); g.arc(x, y, rad * 0.3, 0, TAU); g.stroke(); };
        g.strokeStyle = 'rgba(255,200,120,.1)'; g.lineWidth = 0.06;
        cog(1.8, 12.4, 1.1, 12); cog(7.6, 12.0, 0.9, 10); cog(6.5, 6.6, 0.7, 8);
        for (let k = 0; k < 14; k++) { g.fillStyle = 'rgba(255,220,160,.2)'; g.beginPath(); g.arc(0.35 + (k % 2) * 8.6, 5.2 + Math.floor(k / 2) * 1.1, 0.05, 0, TAU); g.fill(); }
      } else { // circus: big-top stripes, ring, stars
        for (let k = 0; k < 18; k++) {
          const a0 = Math.PI * 0.08 + k * Math.PI * 0.84 / 18, a1 = a0 + Math.PI * 0.84 / 36;
          g.fillStyle = k % 2 ? 'rgba(255,240,215,.07)' : 'rgba(255,60,80,.07)';
          g.beginPath(); g.moveTo(4.65, -1.5); g.lineTo(4.65 + Math.cos(a0) * 22, -1.5 + Math.sin(a0) * 22); g.lineTo(4.65 + Math.cos(a1) * 22, -1.5 + Math.sin(a1) * 22); g.closePath(); g.fill();
        }
        g.strokeStyle = 'rgba(255,220,120,.35)'; g.lineWidth = 0.08; g.beginPath(); g.ellipse(4.65, 11.0, 1.6, 0.8, 0, 0, TAU); g.stroke();
        g.strokeStyle = 'rgba(255,220,120,.18)'; g.lineWidth = 0.22; g.beginPath(); g.ellipse(4.65, 11.0, 1.35, 0.62, 0, 0, TAU); g.stroke();
        const star = (x, y, s, col) => { g.fillStyle = col; g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, l = k % 2 ? s * 0.42 : s; if (k) g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); else g.moveTo(x + Math.cos(a) * l, y + Math.sin(a) * l); } g.closePath(); g.fill(); };
        for (let k = 0; k < 16; k++) star(0.6 + r() * 8.2, 5.5 + r() * 8.5, 0.08 + r() * 0.1, 'rgba(255,230,150,' + (0.15 + r() * 0.3).toFixed(2) + ')');
        star(4.65, 11.0, 0.45, 'rgba(255,220,120,.35)');
        for (let k = 0; k <= 24; k++) { const a = Math.PI + Math.PI * k / 24, x = 5 + 4.7 * Math.cos(a), y = 4.6 + 4.1 * Math.sin(a); g.fillStyle = 'rgba(255,230,160,.35)'; g.beginPath(); g.arc(x, y, 0.06, 0, TAU); g.fill(); }
      }
      g.restore();
    }
    function buildStatic(T) {
      const D = T.D, th = D.th, sc = lay.sc, d = DPR();
      const c = mkC(10.4 * sc * d, 18.5 * sc * d), g = c.getContext('2d');
      g.scale(sc * d, sc * d); g.translate(0.2, 0.15);
      // cabinet
      const wood = g.createLinearGradient(-0.2, 0, 10.2, 0); wood.addColorStop(0, th.cab); wood.addColorStop(0.5, '#000000'); wood.addColorStop(1, th.cab);
      g.fillStyle = th.cab; rr(g, -0.2, -0.15, 10.4, 18.5, 0.5); g.fill();
      // playfield
      g.save(); playPath(g, D); g.clip();
      const bg = g.createLinearGradient(0, 0, 0, 18.4); bg.addColorStop(0, th.bg[0]); bg.addColorStop(1, th.bg[1]);
      g.fillStyle = bg; g.fillRect(0, 0, 10, 18.4);
      drawArt(g, D);
      // fine grain
      const r = mkRng(7 + D.ti);
      for (let k = 0; k < 260; k++) { g.fillStyle = r() < 0.5 ? 'rgba(255,255,255,.025)' : 'rgba(0,0,0,.05)'; g.fillRect(r() * 10, r() * 18.4, 0.05 + r() * 0.12, 0.03); }
      // shooter lane
      g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(PF, 4.4, 0.7, 14);
      // vignette
      const vg = g.createRadialGradient(4.65, 9.5, 3, 4.65, 9.5, 11); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.45)');
      g.fillStyle = vg; g.fillRect(0, 0, 10, 18.4);
      // unlit inserts
      for (const q of insShapes(D)) insert(g, q, th, false, 0);
      // labels
      g.fillStyle = th.lbl; g.font = '700 0.3px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle';
      for (const l of D.S.labels) g.fillText(l[2], l[0], l[1]);
      g.font = '700 0.24px ' + FONT;
      D.lanes.forEach((q) => { g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(q.x, q.y, 0.2, 0, TAU); g.fill(); });
      // lower inlane blocks + apron
      for (const sd of [0, 1]) {
        const X = (x) => (sd ? PF - x : x);
        g.fillStyle = th.apron; g.beginPath(); g.moveTo(X(0.68), 14.304); g.lineTo(X(2.703), 15.299); g.lineTo(X(2.6), 16.2); g.lineTo(X(3.2), 17.2); g.lineTo(X(3.2), 18.6); g.lineTo(X(0.68), 18.6); g.closePath(); g.fill();
        g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = 0.04; g.stroke();
        g.fillStyle = 'rgba(0,0,0,.4)'; g.fillRect(sd ? PF - 0.68 : 0, 16.6, 0.68, 2);
      }
      g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(3.2, 17.2, 2.9, 1.4);
      g.fillStyle = th.lbl; g.font = '400 0.42px ' + DISP; g.fillText(D.S.n, 1.85, 17.6);
      g.fillText(D.S.n, PF - 1.85, 17.6);
      // saucer hole
      const S = D.saucer;
      if (S) {
        const hg = g.createRadialGradient(S.x, S.y, 0.02, S.x, S.y, 0.38); hg.addColorStop(0, '#000'); hg.addColorStop(0.7, '#0c0a10'); hg.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = hg; g.beginPath(); g.arc(S.x, S.y, 0.4, 0, TAU); g.fill();
        g.strokeStyle = th.rail; g.lineWidth = 0.05; g.beginPath(); g.arc(S.x, S.y, 0.33, 0, TAU); g.stroke();
      }
      // drop slots
      for (const s of D.drops) { g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 0.2; g.lineCap = 'butt'; g.beginPath(); g.moveTo(s.ax, s.ay); g.lineTo(s.bx, s.by); g.stroke(); }
      // bumper bases
      for (const b of D.bumpers) {
        g.fillStyle = 'rgba(0,0,0,.4)'; g.beginPath(); g.arc(b.x + 0.07, b.y + 0.1, b.r + 0.04, 0, TAU); g.fill();
        g.fillStyle = th.bumpR; g.beginPath(); g.arc(b.x, b.y, b.r, 0, TAU); g.fill();
        g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 0.04; g.beginPath(); g.arc(b.x, b.y, b.r - 0.03, 0, TAU); g.stroke();
      }
      // slingshot plastics
      for (const sl of D.slings) {
        g.fillStyle = th.plast; g.beginPath(); g.moveTo(sl.a[0], sl.a[1]); g.lineTo(sl.b[0], sl.b[1]); g.lineTo(sl.c[0], sl.c[1]); g.closePath(); g.fill();
        const cx = (sl.a[0] + sl.b[0] + sl.c[0]) / 3, cy = (sl.a[1] + sl.b[1] + sl.c[1]) / 3;
        g.fillStyle = 'rgba(255,255,255,.18)'; g.beginPath(); g.arc(cx, cy, 0.14, 0, TAU); g.fill();
        g.strokeStyle = th.rub; g.lineWidth = 0.1; g.lineJoin = 'round'; g.beginPath(); g.moveTo(sl.a[0], sl.a[1]); g.lineTo(sl.b[0], sl.b[1]); g.lineTo(sl.c[0], sl.c[1]); g.closePath(); g.stroke();
      }
      // ramp mouths (plastic under-bridge)
      for (const Rp of D.ramps) {
        g.fillStyle = 'rgba(0,0,0,.45)'; g.beginPath(); g.moveTo(Rp.l0[0], Rp.l0[1]); g.lineTo(Rp.l1[0], Rp.l1[1]); g.lineTo(Rp.ap[0], Rp.ap[1]); g.lineTo(Rp.r1[0], Rp.r1[1]); g.lineTo(Rp.r0[0], Rp.r0[1]); g.closePath(); g.fill();
      }
      // spinner bracket
      if (D.spinner) { const s = D.spinner; g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 0.04; g.beginPath(); g.moveTo(s.ax, s.ay); g.lineTo(s.bx, s.by); g.stroke(); }
      g.restore();
      // walls / rails / guides
      for (const s of D.segs) {
        if (s.k === 'd' || s.k === 'st' || s.k === 'sl') continue;
        if (s.k === 'g') { g.strokeStyle = th.rail; g.lineWidth = 0.05; g.lineCap = 'round'; g.beginPath(); g.moveTo(s.ax, s.ay); g.lineTo(s.bx, s.by); g.stroke(); continue; }
        drawRail(g, s, th, s.ax === s.bx && (s.ax === 0 || s.ax === 10) ? 0.16 : 0.13);
      }
      for (const c of D.circ) {
        if (c.k === 'b' || c.k === 'gr') continue;
        g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(c.x + 0.04, c.y + 0.06, c.r + 0.02, 0, TAU); g.fill();
        g.fillStyle = th.rub; g.beginPath(); g.arc(c.x, c.y, c.r, 0, TAU); g.fill();
        g.fillStyle = th.railD; g.beginPath(); g.arc(c.x, c.y, c.r * 0.45, 0, TAU); g.fill();
      }
      // outer frame shine
      g.save(); g.strokeStyle = th.rail; g.lineWidth = 0.08; playPath(g, D); g.stroke(); g.restore();
      // flipper pivots
      for (const P of FP) { g.fillStyle = '#2a2430'; g.beginPath(); g.arc(P[0], P[1], 0.2, 0, TAU); g.fill(); }
      // plunger housing
      g.fillStyle = '#16121c'; g.fillRect(PF + 0.04, 17.95, 0.62, 0.45);
      return c;
    }
    function rr(g, x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
    function insert(g, q, th, lit, blink) {
      const col = th.ins[q.ev] || '#fff';
      g.save();
      g.globalAlpha = lit ? 1 : 0.28;
      g.fillStyle = col;
      if (q.kind === 'arr') { arrowPath(g, q.x, q.y, q.a, 0.5); g.fill(); g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 0.03; g.stroke(); }
      else if (q.kind === 'dot') { g.beginPath(); g.arc(q.x, q.y, 0.22, 0, TAU); g.fill(); g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 0.03; g.stroke(); }
      else { rr(g, q.x - 0.5, q.y - 0.17, 1.0, 0.34, 0.17); g.fill(); g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 0.03; g.stroke(); }
      if (lit) { // shine
        g.globalAlpha = 0.35 + 0.35 * blink; g.fillStyle = '#ffffff';
        if (q.kind === 'arr') { arrowPath(g, q.x, q.y, q.a, 0.28); g.fill(); }
        else if (q.kind === 'dot') { g.beginPath(); g.arc(q.x - 0.05, q.y - 0.06, 0.09, 0, TAU); g.fill(); }
      }
      if (q.lab) { g.globalAlpha = lit ? 1 : 0.7; g.fillStyle = lit ? '#1a1018' : 'rgba(255,255,255,.75)'; g.font = '700 ' + (q.kind === 'pill' ? 0.22 : 0.2) + 'px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(q.lab, q.x, q.y + 0.01); }
      g.restore();
    }
    function buildRampLayer(T) {
      const D = T.D, th = D.th, sc = lay.sc, d = DPR();
      const c = mkC(10.4 * sc * d, 18.5 * sc * d), g = c.getContext('2d');
      g.scale(sc * d, sc * d); g.translate(0.2, 0.15);
      g.lineCap = 'round'; g.lineJoin = 'round';
      for (const Rp of D.ramps) {
        const P = Rp.pts;
        const path = (off) => {
          g.beginPath();
          for (let i = 0; i < P.length; i++) {
            const a = P[Math.max(0, i - 1)], b = P[Math.min(P.length - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1;
            const x = P[i][0] - dy / l * off, y = P[i][1] + dx / l * off;
            if (i) g.lineTo(x, y); else g.moveTo(x, y);
          }
        };
        g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 0.95; g.save(); g.translate(0.18, 0.26); path(0); g.stroke(); g.restore();
        g.strokeStyle = th.ramp; g.lineWidth = 0.9; path(0); g.stroke();
        g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = 0.3; path(-0.15); g.stroke();
        g.strokeStyle = th.rampE; g.lineWidth = 0.06; path(0.45); g.stroke(); path(-0.45); g.stroke();
        g.strokeStyle = 'rgba(255,255,255,.5)'; g.lineWidth = 0.02; path(0.43); g.stroke(); path(-0.47); g.stroke();
        // entrance flap
        g.strokeStyle = th.rampE; g.lineWidth = 0.08; g.beginPath(); g.moveTo(Rp.l1[0], Rp.l1[1]); g.lineTo(Rp.r1[0], Rp.r1[1]); g.stroke();
      }
      return c;
    }
    function buildSprites(T) {
      const th = T.D.th, sc = lay.sc, d = DPR();
      const ball = (() => {
        const px = Math.ceil(2 * R * sc * d) + 2, c = mkC(px, px), g = c.getContext('2d'), r = px / 2 - 1, cx = px / 2, cy = px / 2;
        const gr = g.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.05, cx, cy, r);
        gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.22, '#e9edf3'); gr.addColorStop(0.55, '#9aa3b2'); gr.addColorStop(0.82, '#525a6a'); gr.addColorStop(1, '#262a34');
        g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill();
        g.save(); g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.clip();
        g.fillStyle = 'rgba(30,24,40,.35)'; g.fillRect(cx - r, cy + r * 0.12, 2 * r, r * 0.3);   // horizon reflection
        g.fillStyle = 'rgba(255,214,150,.25)'; g.beginPath(); g.ellipse(cx + r * 0.25, cy + r * 0.72, r * 0.6, r * 0.22, 0, 0, TAU); g.fill();
        g.restore();
        g.fillStyle = 'rgba(255,255,255,.95)'; g.beginPath(); g.ellipse(cx - r * 0.34, cy - r * 0.4, r * 0.24, r * 0.15, -0.6, 0, TAU); g.fill();
        g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = Math.max(1, r * 0.06); g.beginPath(); g.arc(cx, cy, r - g.lineWidth / 2, 0, TAU); g.stroke();
        return c;
      })();
      const cap = (lit) => {
        const px = Math.ceil(0.9 * sc * d) + 2, c = mkC(px, px), g = c.getContext('2d'), r = px / 2 - 1, cx = px / 2, cy = px / 2;
        if (lit) { const gl = g.createRadialGradient(cx, cy, r * 0.3, cx, cy, r); gl.addColorStop(0, th.bumpT); gl.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gl; g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill(); }
        const rc = r * 0.78;
        const gr = g.createRadialGradient(cx - rc * 0.3, cy - rc * 0.35, rc * 0.1, cx, cy, rc);
        gr.addColorStop(0, lit ? '#ffffff' : th.bumpT); gr.addColorStop(0.5, th.bumpC); gr.addColorStop(1, 'rgba(0,0,0,.6)');
        g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, rc, 0, TAU); g.fill();
        g.fillStyle = lit ? '#ffffff' : 'rgba(255,255,255,.75)'; g.beginPath(); g.arc(cx, cy, rc * 0.45, 0, TAU); g.fill();
        g.fillStyle = th.bumpC; g.font = '700 ' + Math.round(rc * 0.6) + 'px ' + DISP; g.textAlign = 'center'; g.textBaseline = 'middle';
        g.fillText(['⚓', '✦', '★', '✺', '⚙'][T.D.ti] || '★', cx, cy + 1);
        return c;
      };
      return { ball, cap0: cap(false), cap1: cap(true) };
    }

    /* ----- DMD (dot-matrix display) ----- */
    const dmdS = mkC(DC, DRW), dg = dmdS.getContext('2d');
    let dmdBg = null, dmdMask = null, dmdSz = '';
    function dmdPrep(wpx, hpx) {
      const d = DPR(), sz = wpx + 'x' + hpx + 'x' + d;
      if (sz === dmdSz) return;
      dmdSz = sz;
      const W2 = Math.round(wpx * d), H2 = Math.round(hpx * d), pw = W2 / DC, ph = H2 / DRW, rad = Math.min(pw, ph) * 0.4;
      dmdBg = mkC(W2, H2); dmdMask = mkC(W2, H2);
      const b = dmdBg.getContext('2d'); b.fillStyle = '#140a06'; b.fillRect(0, 0, W2, H2);
      b.fillStyle = 'rgba(255,120,40,.10)';
      for (let y = 0; y < DRW; y++) for (let x = 0; x < DC; x++) { b.beginPath(); b.arc((x + 0.5) * pw, (y + 0.5) * ph, rad, 0, TAU); b.fill(); }
      const m = dmdMask.getContext('2d'); m.fillStyle = '#140a06'; m.fillRect(0, 0, W2, H2);
      m.globalCompositeOperation = 'destination-out';
      for (let y = 0; y < DRW; y++) for (let x = 0; x < DC; x++) { m.beginPath(); m.arc((x + 0.5) * pw, (y + 0.5) * ph, rad * 1.05, 0, TAU); m.fill(); }
    }
    function dmdText(T) {
      if (!T) return api.online ? '기다리는 중…' : '';
      if (T.mq.length) return T.mq[0].t;
      if (T.ph === 'over') return '게임 끝 · ' + fmt(T.sc) + '점';
      const m = curMis(T), cyc = Math.floor(T.t / 3.2) % 3;
      if (T.multi) return cyc === 2 ? '멀티볼 · 공 ' + T.ball + '/' + T.nb : '램프 = 잭팟 ' + fmt(T.jack);
      if (T.lockLit && cyc === 1) return T.D.S.lockTxt + ' (' + T.locks + '/2)';
      if (cyc === 0) return '공 ' + T.ball + ' / ' + T.nb + (T.mult > 1 ? ' · 보너스 ×' + T.mult : '') + (T.extra ? ' · 추가 공' : '');
      return '미션: ' + m[0] + ' (' + T.mp + '/' + misNeed(T) + ')';
    }
    function drawDMD(T, now) {
      const w = lay.dmdW, x = Math.round((lay.w - w) / 2), y = lay.dmdY, h = lay.dmdH;
      ctx.fillStyle = '#0b0608'; rr(ctx, x - 2, y - 2, w + 4, h + 4, 6); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1; ctx.stroke();
      dmdPrep(w, h);
      const text = dmdText(T);
      dg.clearRect(0, 0, DC, DRW);
      dg.font = '700 12px ' + FONT; dg.textBaseline = 'middle';
      const tw = dg.measureText(text).width;
      let tx = (DC - tw) / 2;
      if (tw > DC - 4) { const span = tw + 40, ofs = ((now / 1000) * 26) % span; tx = DC - ofs; if (tx < -tw + 4) tx += span; dg.fillStyle = '#ff9a2e'; dg.fillText(text, tx + span, DRW / 2 + 1); }
      dg.fillStyle = '#ff9a2e'; dg.fillText(text, tx, DRW / 2 + 1);
      ctx.drawImage(dmdBg, x, y, w, h);
      ctx.imageSmoothingEnabled = false; ctx.drawImage(dmdS, x, y, w, h); ctx.imageSmoothingEnabled = true;
      ctx.drawImage(dmdMask, x, y, w, h);
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) { ctx.font = font; ctx.fillStyle = col; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillText(t, x, y); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function drawHud() {
      const n = st.n, cw = (lay.w - 8 - (n - 1) * 4) / n, ch = lay.hudH - 8;
      let lead = -1, top = -1;
      for (let s = 0; s < n; s++) { const sc = scoreRow(s)[0]; if (sc > top) { top = sc; lead = s; } }
      for (let s = 0; s < n; s++) {
        const x = 4 + s * (cw + 4), y = 3, row = scoreRow(s), P = Pl(s);
        ctx.fillStyle = s === view ? 'rgba(227,174,69,.22)' : 'rgba(255,255,255,.06)'; rr(ctx, x, y, cw, ch, 8); ctx.fill();
        if (s === view) { ctx.strokeStyle = 'rgba(227,174,69,.85)'; ctx.lineWidth = 1.5; ctx.stroke(); }
        ctx.fillStyle = P.color || '#888'; rr(ctx, x + 4, y + 5, 4, ch - 10, 2); ctx.fill();
        const f1 = '600 11px ' + FONT;
        const balls = row[2] ? '끝' : '●'.repeat(Math.max(0, NB() - row[1] + 1)) + '○'.repeat(Math.max(0, row[1] - 1));
        ctx.font = '600 9px ' + FONT; const bw = ctx.measureText(balls).width;
        txt(fitText((top > 0 && s === lead && n > 1 ? '♛ ' : '') + name(s), cw - 22 - bw, f1), x + 12, y + 10, '#f2e9d8', f1, 'left');
        txt(balls, x + cw - 5, y + 10, row[2] ? '#ab9fb8' : '#e3ae45', '600 9px ' + FONT, 'right');
        const f2 = '700 ' + (cw < 80 ? 12 : 14) + 'px ' + MONO;
        txt(fitText(fmt(row[0]), cw - 16, f2), x + 12, y + ch - 9, '#fff6e0', f2, 'left');
      }
    }
    function drawFlipper(i, a, th) {
      const P = FP[i], c = Math.cos(a), s = Math.sin(a), dx = i ? -c : c, dy = s, tx = P[0] + dx * FL, ty = P[1] + dy * FL, ang = Math.atan2(dy, dx);
      const shape = (ox, oy) => {
        ctx.beginPath();
        ctx.arc(P[0] + ox, P[1] + oy, FR0, ang + Math.PI / 2, ang + Math.PI * 1.5);
        ctx.arc(tx + ox, ty + oy, FR1, ang - Math.PI / 2, ang + Math.PI / 2);
        ctx.closePath();
      };
      ctx.fillStyle = 'rgba(0,0,0,.4)'; shape(0.07, 0.11); ctx.fill();
      ctx.fillStyle = th.flR; shape(0, 0); ctx.fill();
      ctx.save(); ctx.translate(P[0], P[1]); ctx.rotate(ang);
      const gr = ctx.createLinearGradient(0, -FR0, 0, FR0); gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.5, th.fl); gr.addColorStop(1, '#b8ab98');
      ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(0, 0, FR0 - 0.06, Math.PI / 2, Math.PI * 1.5); ctx.arc(FL, 0, Math.max(0.04, FR1 - 0.06), -Math.PI / 2, Math.PI / 2); ctx.closePath(); ctx.fill();
      ctx.restore();
      ctx.fillStyle = '#c9c2b8'; ctx.beginPath(); ctx.arc(P[0], P[1], 0.1, 0, TAU); ctx.fill();
      ctx.fillStyle = '#5a5060'; ctx.beginPath(); ctx.arc(P[0], P[1], 0.04, 0, TAU); ctx.fill();
    }
    function segRect(s, thick, col) {
      ctx.strokeStyle = col; ctx.lineWidth = thick; ctx.lineCap = 'butt';
      ctx.beginPath(); ctx.moveTo(s.ax, s.ay); ctx.lineTo(s.bx, s.by); ctx.stroke();
    }
    function litOf(T, q, t) {
      const th = T.D.th, blink = 0.5 + 0.5 * Math.sin(t * 9), slow = 0.5 + 0.5 * Math.sin(t * 5);
      const want = curMis(T)[1], mw = want === 'dropAll' ? 'drop' : want;
      switch (q.ev) {
        case 'mult': return T.mult >= q.v ? [1, 0.6] : null;
        case 'save': return T.save > 0 ? (T.save > 2 || blink > 0.5 ? [1, blink] : null) : T.extra ? [1, 0.3] : null;
        case 'extra': return T.extra ? [1, slow] : null;
        case 'sau': if (T.lockLit) return blink > 0.35 ? [1, blink] : null; break;
        case 'ramp': if (T.multi) return blink > 0.3 ? [1, blink] : null; break;
        case 'mag': if (T.multi && T.D.S.magJack) return blink > 0.3 ? [1, blink] : null; break;
      }
      const SQ = T.D.S.seq;
      if (SQ && q.ev === SQ[T.sq % SQ.length]) return [1, 0.5 + 0.5 * Math.sin(t * 14)];
      if (q.ev === mw || (q.ev === 'orb' && mw === 'spin')) return slow > 0.3 ? [1, slow] : null;
      void th;
      return null;
    }
    function drawTable(T, now) {
      const D = T.D, th = D.th, sc = lay.sc, t = now / 1000;
      if (!stat || statKey !== key + '|' + sc + '|' + DPR()) { stat = buildStatic(T); rampL = buildRampLayer(T); sprites = buildSprites(T); statKey = key + '|' + sc + '|' + DPR(); }
      const fxk = L.fx ? L.fx() : 1, sx = shake > 0 ? Math.sin(now * 0.09) * shake * 3 * fxk : 0, sy = shake > 0 ? -shake * 2 * fxk : 0;
      const X0 = lay.ox - 0.2 * sc + sx, Y0 = lay.oy - 0.15 * sc + sy;
      ctx.drawImage(stat, X0, Y0, 10.4 * sc, 18.5 * sc);
      ctx.save();
      ctx.translate(lay.ox + sx, lay.oy + sy); ctx.scale(sc, sc);
      // lights
      for (const q of insShapes(D)) { const L2 = litOf(T, q, t); if (L2) insert(ctx, q, th, true, L2[1]); }
      // top lanes lamps
      D.lanes.forEach((q, i) => {
        const on = T.lanes[i], sk = T.sk === i && (T.man || T.skT > 0), fl = T.t - T.fl8[i] < 0.5;
        if (!on && !sk && !fl) return;
        ctx.fillStyle = sk ? (Math.sin(t * 12) > 0 ? '#9dffb0' : 'rgba(157,255,176,.25)') : th.ins.lane;
        ctx.globalAlpha = fl && !on ? 0.6 : 1;
        ctx.beginPath(); ctx.arc(q.x, q.y, 0.17, 0, TAU); ctx.fill(); ctx.globalAlpha = 1;
      });
      // drop targets & standups
      D.drops.forEach((s, i) => {
        if (!T.drop[i]) return;
        segRect(s, 0.16, th.drop);
        segRect(s, 0.05, 'rgba(255,255,255,.55)');
      });
      D.stands.forEach((s, i) => {
        const fl = T.t - T.fst[i] < 0.25;
        segRect(s, 0.14, fl ? '#ffffff' : th.stand);
        segRect(s, 0.04, 'rgba(0,0,0,.35)');
      });
      // spinner plate
      if (D.spinner) {
        const s = D.spinner, k = Math.abs(Math.cos(T.spA)), wv = 0.06 + 0.26 * k;
        ctx.fillStyle = k > 0.5 ? '#e6e9f0' : '#9aa1ad';
        ctx.fillRect(Math.min(s.ax, s.bx) + 0.06, s.y - wv / 2, Math.abs(s.bx - s.ax) - 0.12, wv);
      }
      // saucer glow
      if (D.saucer) {
        const S = D.saucer, held = T.balls.some((b) => b.m === 'hold'), fl = T.t - T.fsau < 0.6;
        if (held || fl || T.lockLit) { ctx.strokeStyle = th.ins.sau; ctx.globalAlpha = held || fl ? 0.9 : 0.4 + 0.4 * Math.sin(t * 8); ctx.lineWidth = 0.07; ctx.beginPath(); ctx.arc(S.x, S.y, 0.4, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; }
        for (let k = 0; k < 2; k++) { ctx.fillStyle = T.locks > k ? th.ins.sau : 'rgba(255,255,255,.12)'; ctx.beginPath(); ctx.arc(S.x - 0.12 + k * 0.24, S.y + 0.55, 0.07, 0, TAU); ctx.fill(); }
      }
      // sling flash
      D.slings.forEach((sl, i) => { if (T.t - T.fsl[i] < 0.12) { ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.12; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(sl.c[0], sl.c[1]); ctx.lineTo(sl.a[0], sl.a[1]); ctx.stroke(); } });
      // spinning gears
      D.gears.forEach((c) => {
        const fl = T.t - T.fg[c.id] < 0.15, n = 10, a0 = T.t * c.w;
        ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.arc(c.x + 0.07, c.y + 0.1, c.r + 0.06, 0, TAU); ctx.fill();
        ctx.beginPath();
        for (let k = 0; k < n * 4; k++) { const a = a0 + k * Math.PI / (n * 2), l = (k & 2) ? c.r * 0.86 : c.r + 0.07; ctx.lineTo(c.x + Math.cos(a) * l, c.y + Math.sin(a) * l); }
        ctx.closePath(); ctx.fillStyle = fl ? '#fff0c8' : th.bumpC; ctx.fill(); ctx.strokeStyle = th.bumpR; ctx.lineWidth = 0.04; ctx.stroke();
        ctx.fillStyle = th.bumpR; ctx.beginPath(); ctx.arc(c.x, c.y, c.r * 0.5, 0, TAU); ctx.fill();
        ctx.strokeStyle = th.bumpT; ctx.lineWidth = 0.05;
        for (let k = 0; k < 3; k++) { const a = a0 + k * TAU / 3; ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.lineTo(c.x + Math.cos(a) * c.r * 0.48, c.y + Math.sin(a) * c.r * 0.48); ctx.stroke(); }
        ctx.fillStyle = th.bumpT; ctx.beginPath(); ctx.arc(c.x, c.y, 0.07, 0, TAU); ctx.fill();
      });
      // rotating magnets
      D.mags.forEach((m) => {
        const p = magPos(T, m), fl = T.t - T.fm[m.id] < 0.3, hot = T.multi && D.S.magJack;
        const gl = ctx.createRadialGradient(p[0], p[1], 0.05, p[0], p[1], 0.75); gl.addColorStop(0, hot || fl ? 'rgba(200,150,255,.55)' : 'rgba(190,140,255,.28)'); gl.addColorStop(1, 'rgba(190,140,255,0)');
        ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(p[0], p[1], 0.75, 0, TAU); ctx.fill();
        const a = Math.atan2(p[1] - m.cy, p[0] - m.cx);
        ctx.save(); ctx.translate(p[0], p[1]); ctx.rotate(a + Math.PI / 2);
        ctx.lineWidth = 0.13; ctx.lineCap = 'butt';
        ctx.strokeStyle = '#d24a4a'; ctx.beginPath(); ctx.arc(0, 0, 0.2, Math.PI, Math.PI * 1.5); ctx.stroke();
        ctx.strokeStyle = '#4a7ad2'; ctx.beginPath(); ctx.arc(0, 0, 0.2, Math.PI * 1.5, TAU); ctx.stroke();
        ctx.fillStyle = '#e8e8f0'; ctx.fillRect(-0.27, -0.02, 0.14, 0.1); ctx.fillRect(0.13, -0.02, 0.14, 0.1);
        ctx.restore();
      });
      // timed bridge: a bar across the ramp mouth while it is up, a countdown arc while it is down
      if (D.bridge >= 0) {
        const Rp = D.ramps[D.bridge], open = bridgeOpen(T);
        if (!open) { ctx.strokeStyle = '#c0503a'; ctx.lineWidth = 0.14; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(Rp.l1[0], Rp.l1[1]); ctx.lineTo(Rp.r1[0], Rp.r1[1]); ctx.stroke(); ctx.strokeStyle = '#ffd8a0'; ctx.lineWidth = 0.04; ctx.stroke(); }
        const left = T.brT > 0 ? T.brT / BRIDGE_HOLD : open ? 1 - (T.t % BRIDGE_CYC) / BRIDGE_OPEN : (T.t % BRIDGE_CYC - BRIDGE_OPEN) / (BRIDGE_CYC - BRIDGE_OPEN);
        const bx = Rp.cx, by = Rp.cy + 1.75;
        ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.beginPath(); ctx.arc(bx, by, 0.26, 0, TAU); ctx.fill();
        ctx.strokeStyle = open ? '#9fffb0' : '#ff8a6a'; ctx.lineWidth = 0.07; ctx.beginPath(); ctx.arc(bx, by, 0.2, -Math.PI / 2, -Math.PI / 2 + TAU * U.clamp(left, 0, 1)); ctx.stroke();
      }
      // bumper caps
      D.bumpers.forEach((b, i) => {
        const lit = T.t - T.fb[i] < 0.14 || (curMis(T)[1] === 'bump' && Math.sin(t * 6 + i) > 0.6);
        const img = lit ? sprites.cap1 : sprites.cap0, s2 = lit ? 0.92 : 0.9;
        ctx.drawImage(img, b.x - s2 / 2, b.y - s2 / 2 - 0.04, s2, s2);
      });
      // plunger
      const fy = PLY + 0.6 * T.pull;
      ctx.strokeStyle = '#8c8f98'; ctx.lineWidth = 0.05; ctx.beginPath();
      for (let k = 0; k <= 8; k++) { const yy = fy + 0.1 + (18.25 - fy - 0.1) * k / 8; ctx.lineTo(LX + (k % 2 ? 0.16 : -0.16), yy); }
      ctx.stroke();
      ctx.fillStyle = '#d8d2c6'; rr(ctx, LX - 0.24, fy, 0.48, 0.13, 0.04); ctx.fill();
      if (isMine(view) && waiting(T)) {
        const h0 = 13.6, h1 = 16.4, f = T.pull;
        ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, LX - 0.13, h0, 0.26, h1 - h0, 0.13); ctx.fill();
        const gr = ctx.createLinearGradient(0, h1, 0, h0); gr.addColorStop(0, '#5ce08a'); gr.addColorStop(0.6, '#ffd34d'); gr.addColorStop(1, '#ff5a3a');
        ctx.fillStyle = gr; rr(ctx, LX - 0.1, h1 - (h1 - h0) * f, 0.2, Math.max(0.001, (h1 - h0) * f), 0.1); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.4 + 0.4 * Math.sin(t * 6)).toFixed(2) + ')'; arrowPath(ctx, LX, 12.9, Math.PI / 2, 0.42); ctx.fill();
      }
      // balls on the playfield (+ held / lane)
      const B = sprites.ball, d2 = 2 * R;
      for (const b of T.balls) {
        if (b.m === 'ramp') continue;
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(b.x + 0.09, b.y + 0.13, R * 0.95, R * 0.8, 0, 0, TAU); ctx.fill();
        if (b.m === 'hold') { ctx.globalAlpha = 0.75; ctx.drawImage(B, b.x - R * 0.9, b.y - R * 0.9, d2 * 0.9, d2 * 0.9); ctx.globalAlpha = 1; continue; }
        const v2 = b.vx * b.vx + b.vy * b.vy;
        if (v2 > 400) { ctx.globalAlpha = 0.18; ctx.drawImage(B, b.x - b.vx * 0.012 - R, b.y - b.vy * 0.012 - R, d2, d2); ctx.globalAlpha = 1; }
        ctx.drawImage(B, b.x - R, b.y - R, d2, d2);
      }
      // flippers
      drawFlipper(0, T.fl[0].a, th); drawFlipper(1, T.fl[1].a, th);
      ctx.restore();
      // ramps above the playfield, then balls riding them
      ctx.drawImage(rampL, X0, Y0, 10.4 * sc, 18.5 * sc);
      ctx.save(); ctx.translate(lay.ox + sx, lay.oy + sy); ctx.scale(sc, sc);
      for (const b of T.balls) {
        if (b.m !== 'ramp') continue;
        const Rp = D.ramps[b.rp], f = b.s / Rp.len, z = Math.sin(Math.PI * Math.min(1, f * 1.15)) * 0.12, s2 = d2 * (1 + z);
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(b.x + 0.2, b.y + 0.28, R, R * 0.8, 0, 0, TAU); ctx.fill();
        ctx.drawImage(B, b.x - s2 / 2, b.y - s2 / 2, s2, s2);
      }
      // particles
      for (const q of parts) { ctx.globalAlpha = Math.max(0, q.t / q.T); ctx.fillStyle = q.c; ctx.fillRect(q.x - 0.04, q.y - 0.04, 0.08, 0.08); }
      ctx.globalAlpha = 1;
      ctx.restore();
      // GI flash
      const gi = T.t - T.giT;
      if (gi < 0.5) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = (0.5 - gi) * 0.35 * (L.fx ? L.fx() : 1); ctx.fillStyle = th.gi; ctx.fillRect(lay.ox, lay.oy, 10 * sc, 18.4 * sc); ctx.restore(); }
      if (warnT > 0 || T.tilted) { ctx.save(); ctx.strokeStyle = 'rgba(255,70,50,' + (T.tilted ? 0.6 + 0.3 * Math.sin(t * 10) : warnT / 0.8 * 0.8).toFixed(2) + ')'; ctx.lineWidth = 6; ctx.strokeRect(lay.ox, lay.oy, 10 * sc, 18.4 * sc); ctx.restore(); }
      // floats
      for (const f of floats) {
        const k = 1 - f.t / f.T, px = lay.ox + f.x * sc, py = lay.oy + (f.y - k * 1.2) * sc;
        ctx.globalAlpha = Math.min(1, f.t / f.T * 2);
        const font = '800 ' + (f.big ? 20 : 14) + 'px ' + (f.big ? DISP : MONO);
        ctx.font = font; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,6,14,.8)'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.strokeText(f.text, px, py); txt(f.text, px, py, f.col, font);
      }
      ctx.globalAlpha = 1;
    }
    function drawHint(T) {
      if (!T || !isMine(view) || auto()) return;
      let msg = null;
      if (canCtl() && waiting(T)) msg = fine ? '누르고 있다 떼면 발사 · 화면을 아래로 끌어도 돼요' : '아래로 끌었다 놓으면 발사 · 톡 = 자동 발사';
      else if (canCtl() && T.ball === 1 && T.t - T.launchT < 6 && T.t - T.launchT > 0.3 && T.launchT > 0) {
        if (fine) { const b = (api.input && api.input.bindings) ? api.input.bindings() : []; const k = (id) => { const x = b.find((o) => o.id === id); return x && x.keys[0] ? keyName(x.keys[0]) : '?'; }; msg = '플리퍼 ' + k('flipL') + ' · ' + k('flipR') + ' · 흔들기 ' + k('nudge') + ' · 클릭도 돼요'; }
        else msg = '화면 왼쪽·오른쪽 누르기 = 플리퍼 · 위로 튕기기 = 흔들기';
      }
      if (!msg) return;
      const font = '600 12px ' + FONT;
      ctx.font = font;
      const w = Math.min(lay.w - 16, ctx.measureText(msg).width + 24), x = lay.w / 2 - w / 2, y = lay.oy + 12.2 * lay.sc;
      ctx.fillStyle = 'rgba(16,12,22,.82)'; rr(ctx, x, y - 14, w, 28, 14); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1; ctx.stroke();
      txt(fitText(msg, w - 16, font), lay.w / 2, y, '#f2e9d8', font);
    }
    function draw(now) {
      const w = cv.w, h = cv.h;
      ctx.fillStyle = '#120e18'; ctx.fillRect(0, 0, w, h);
      if (!st || !lay) return;
      if (!key) { txt('준비 중…', w / 2, h / 2, '#ab9fb8', '600 14px ' + FONT); return; }
      const T = TS[view];
      drawHud();
      drawDMD(T || null, now);
      if (T) { drawTable(T, now); drawHint(T); }
      else {
        txt(name(view) + ' 님의 테이블', w / 2, h * 0.45, '#f2e9d8', '700 16px ' + FONT);
        txt('각자 자기 폰에서 치고 있어요', w / 2, h * 0.45 + 24, '#ab9fb8', '500 13px ' + FONT);
      }
      if (cdT > 0 && st.ph === 'play') {
        const c = Math.ceil(cdT - 0.6), f = cdT - 0.6 - Math.floor(cdT - 0.6), lab = c > 0 ? String(c) : '시작!';
        ctx.fillStyle = 'rgba(10,8,16,.35)'; ctx.fillRect(0, lay.dmdY + lay.dmdH + 4, w, h);
        ctx.save(); ctx.globalAlpha = c > 0 ? Math.min(1, f * 3 + 0.3) : U.clamp(cdT * 2, 0, 1);
        txt(lab, w / 2, h * 0.5, '#e3ae45', (c > 0 ? 64 : 44) + 'px ' + DISP);
        txt(TABLES[st.tb].n + ' · 공 ' + NB() + '개', w / 2, h * 0.5 + 46, '#f2e9d8', '600 14px ' + FONT);
        ctx.restore();
      }
      const M2 = myT();
      if (M2 && view === mine()[0] && endBan > 0 && endBan < 2.8 && !auto()) {
        const a = U.clamp(endBan * 4, 0, 1) * U.clamp((2.8 - endBan) * 3, 0, 1), bw = Math.min(w - 32, 300), bh = newBest ? 92 : 76, by = h * 0.42 - bh / 2;
        ctx.save(); ctx.globalAlpha = a;
        ctx.fillStyle = 'rgba(18,14,24,.9)'; rr(ctx, w / 2 - bw / 2, by, bw, bh, 14); ctx.fill();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.stroke();
        txt('게임 끝', w / 2, by + 22, '#e3ae45', '24px ' + DISP);
        txt(fmt(M2.sc) + '점', w / 2, by + 52, '#f2e9d8', '700 20px ' + MONO);
        if (newBest) txt('🏆 최고 기록!', w / 2, by + 76, '#9dffb0', '700 13px ' + FONT);
        ctx.restore();
      }
      if (T && !isMine(view) && mine().length && TS[mine()[0]] && TS[mine()[0]].ph === 'over') {
        txt('관전 중: ' + name(view) + ' · 위 점수판을 눌러 바꾸기', w / 2, lay.dmdY + lay.dmdH + 12, 'rgba(242,233,216,.8)', '600 11px ' + FONT);
      } else if (T && !mine().length && st.n > 1) {
        txt('위 점수판을 누르면 다른 테이블을 봐요', w / 2, lay.dmdY + lay.dmdH + 12, 'rgba(242,233,216,.65)', '600 11px ' + FONT);
      }
    }

    const stop = U.loop(frame);
    layout();
    root._pb = { T: () => TS[view], TS: () => TS, lay: () => lay, view: () => view };   // test hook
    return {
      update(state) {
        st = state;
        if (!st) return;
        if (st.ph === 'done') TS.forEach((T) => { if (T && T.ph !== 'over') { T.ph = 'over'; T.balls.length = 0; } });
      },
      destroy() {
        stop();
        if (offKeys) try { offKeys(); } catch (e) {}
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        if (offFF) offFF(); nudgeBtn.remove(); ffBtn.remove(); window.removeEventListener('lounge-ctl', onCtl);
        cv.destroy(); styleEl.remove();
      },
    };
  }

  L.register({
    id: 'pinball', name: '핀볼 대결', tag: '실시간 핀볼 점수 대결', cat: '아케이드',
    blurb: '똑같은 핀볼 테이블에서 동시에! 공 3개(또는 5개)로 범퍼·램프·미션을 노려 가장 높은 점수를 내면 승리. 테이블 5가지.',
    tint: '#33246e',
    icon: '<circle cx="40" cy="13" r="7" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="21" cy="19" r="5" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="29" cy="31" r="4" fill="currentColor"/><path d="M7 41l17 7" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><path d="M49 41l-17 7" stroke="currentColor" stroke-width="5" stroke-linecap="round"/><path d="M5 52h46" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'table', label: '테이블', tip: '테이블마다 장치·미션이 달라요.', choices: [{ v: -1, label: '무작위' }].concat(TABLES.map((t, i) => ({ v: i, label: t.n }))), def: -1 },
      { id: 'balls', label: '공 개수', choices: [{ v: 3, label: '3개' }, { v: 5, label: '5개' }], def: 3 },
    ],
    controls: [
      { id: 'flipL', label: '왼쪽 플리퍼', keys: ['KeyZ', 'ShiftLeft'], pad: ['lb', 'lt'] },
      { id: 'flipR', label: '오른쪽 플리퍼', keys: ['Slash', 'ShiftRight'], pad: ['rb', 'rt'] },
      { id: 'plunge', label: '발사 (누르고 있다 떼기)', keys: ['Space', 'ArrowDown'], pad: ['a', 'down'] },
      { id: 'nudge', label: '흔들기', keys: ['KeyX', 'ArrowUp'], pad: ['y', 'up'] },
      { id: 'ff', label: '빨리 보기 켜고 끄기', keys: ['KeyF'] },
    ],
    quick: [
      '모두 똑같은 핀볼 테이블에서 동시에 쳐요. 공 3개(또는 5개)로 점수를 가장 많이 내면 승리.',
      '화면 왼쪽을 누르면 왼쪽 플리퍼, 오른쪽은 오른쪽 플리퍼. 발사는 아래로 끌었다 놓기(톡 = 자동 발사).',
      '공이 플리퍼 사이로 빠지면 공 하나를 잃어요. 범퍼·램프·미션을 노려 점수를 쌓아요.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 똑같은 테이블에서 동시에 쳐요. 공은 3개(설정에서 5개도 가능), 다 잃으면 끝.',
        '모두 끝났을 때 점수가 가장 높은 사람이 승리! 시간 제한은 없어요.',
        '위쪽 점수판에 모두의 점수와 남은 공(●)이 실시간으로 보여요. 그 아래 전광판에 미션과 소식이 나와요.',
      ] },
      { h: '조작 (터치)', p: [
        '플리퍼: 화면 왼쪽을 누르면 왼쪽 플리퍼, 오른쪽을 누르면 오른쪽 플리퍼. 누르고 있으면 플리퍼가 올라간 채로 공을 받쳐요.',
        '발사: 공이 오른쪽 발사대에 있을 때 화면을 누른 채 아래로 끌었다 놓아요(많이 끌수록, 오래 누를수록 세게). 톡 누르면 알맞은 힘으로 자동 발사.',
        '흔들기: 아래 「흔들기」 버튼이나, 플리퍼를 누른 손가락을 위로 튕기면 테이블이 흔들려 공이 살짝 튀어요.',
        '너무 자주 흔들면 「경고」, 계속하면 「기울임(TILT)」 — 플리퍼가 멈추고 그 공의 보너스가 없어져요.',
        'PC: Z·왼 Shift = 왼쪽, /·오른 Shift = 오른쪽 플리퍼, 스페이스·↓ = 발사(누르고 있다 떼기), X·↑ = 흔들기. 마우스 클릭도 돼요. 「⌨ 조작 설정」에서 키·패드를 바꿔요.',
      ] },
      { h: '점수', p: [
        '범퍼·슬링(플리퍼 위 삼각 고무)·타깃·스피너·램프·오빗(바깥 고리 길)·구멍마다 점수가 나요.',
        '맨 위 레인 3개를 모두 켜면 보너스 배수 +1(최대 5배). 플리퍼를 누르면 켜진 레인이 옆으로 옮겨가요.',
        '공을 잃으면 그 공 동안 모은 보너스 × 배수를 더해 줘요.',
        '스킬 샷: 발사할 때 초록으로 깜빡이는 윗 레인에 공이 바로 들어가면 10,000점. 발사 전에 플리퍼로 깜빡이는 레인을 옮길 수 있어요.',
      ] },
      { h: '미션 · 멀티볼', p: [
        '전광판에 미션이 나와요(예: 램프 3번). 깜빡이는 화살표가 목표예요. 성공하면 5,000점, 다음은 10,000점… 점점 커져요.',
        '미션 3개를 성공하면(공 5개 판은 5개) 「공 추가」 — 공을 잃어도 한 번 더 쳐요. 한 판에 한 번이에요.',
        '드롭 타깃(넘어지는 타깃)을 모두 넘어뜨리면 「잠금 준비」. 그다음 구멍에 공을 2번 넣으면 공 3개 멀티볼!',
        '멀티볼 중에는 램프가 잭팟: 10,000점부터 한 번마다 5,000점씩 커져요.',
        '공 보호: 발사하고 8초 안에 공을 잃으면 다시 줘요(아래 「공 보호」 불이 켜져 있는 동안). 멀티볼 시작 때도 10초.',
      ] },
      { h: '테이블 5가지 (기본 무작위)', p: [
        '해적 항구: 통 범퍼 3개, 왼쪽 돛대 램프, 왼쪽 고리 길(갈매기 오빗)과 스피너, 대포알 드롭 타깃, 오른쪽 보물 상자 구멍.',
        '우주 정거장: 서로 엇갈리는 램프 2개, 위성 범퍼, 가운데 운석 드롭 타깃. 운석을 모두 넘어뜨리면 뒤의 블랙홀 구멍이 열려요.',
        '마법 서커스: 왼쪽 위 풍선 범퍼 3개, 가운데 대포 램프, 오른쪽 외줄 오빗, 곤봉 드롭 타깃, 왼쪽 마술 모자 구멍.',
        '심해 유적: 가운데를 빙글빙글 도는 자석 2개가 지나가는 공을 끌어당겨 휘게 해요(붙잡지는 않아요). 자석을 스치면 점수. 유물 드롭 타깃을 모두 넘어뜨리고 봉인 문에 2번 넣으면 멀티볼 — 멀티볼 중에는 자석이 세지고, 스칠 때마다 3,000점 자석 잭팟!',
        '증기 시계탑: 범퍼 대신 도는 톱니 3개 — 맞으면 톱니가 도는 쪽으로 공을 휙 끌고 가요. 가운데 「시간 다리」 램프는 12초마다 5초만 내려와요(가운데 둥근 시계가 남은 시간). 막혀 있을 때는 튕겨 나와요. 왼쪽 열쇠 타깃을 맞히면 10초 동안 다리가 내려와요.',
        '시계 잭팟: 시계탑에는 「톱니 → 다리 램프 → 열쇠 타깃 → 문자판 구멍 → 태엽 오빗」 순서가 있어요. 지금 맞힐 곳이 빠르게 깜빡여요. 하나마다 1,000점, 5개를 다 맞히면 시계 잭팟 20,000점(다음은 30,000점…).',
        '설정에서 테이블(기본 무작위)과 공 개수(3개·5개)를 골라요. 모두 같은 테이블, 같은 미션 순서예요. 최고 기록은 테이블·공 개수마다 따로 남아요.',
      ] },
      { h: '팁', p: [
        '판이 시작하면 3·2·1 카운트다운 뒤에 쳐요. 혼자 친 점수는 테이블·공 개수별 「🏆 내 최고 기록」에 남아요.',
        '공이 오면 플리퍼를 누른 채로 받쳐 멈추게 한 뒤, 노릴 곳을 보고 한 번 떼었다 다시 눌러 쳐요.',
        '양쪽 플리퍼를 동시에 계속 치지 마세요. 공이 오는 쪽만 맞춰 누르는 게 더 정확해요.',
        '발사 후 8초는 공 보호 시간이에요. 이때는 과감하게 램프를 노려 보세요.',
        '공이 옆 통로로 빠지려 할 때 살짝 흔들면 살아날 때도 있어요. 단, 너무 자주는 금물!',
      ] },
      { h: '예시', p: [
        '발사대에서 아래로 끌었다 놓기 → 초록 레인에 쏙 = 스킬 샷 10,000점!',
        '→ 전광판 미션 「램프 3번」을 성공 = 5,000점 → 미션 3개 성공 = 공 추가(한 판에 한 번).',
        '→ 드롭 타깃을 모두 넘어뜨려 「잠금 준비」 → 구멍에 2번 넣으면 멀티볼, 램프마다 잭팟!',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 쳐요. 혼자 하면 나머지 자리는 AI예요(각자 자기 테이블). 내 공이 끝나면 AI 테이블을 구경하고 「빨리 보기」로 넘길 수 있어요.',
        '친구와는 온라인·LAN 방으로: 각자 폰에서 자기 테이블을 치고, 점수가 실시간으로 보여요. 모두 끝나면 결과가 나와요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 늦게 치거나 놓치고, 어려움은 공을 받쳐 멈춘 뒤 미션 목표를 노려 쳐요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { TABLES, getDef, newTable, stepT, sub, feat, progress, aiInit, aiThink, prepAI, PREP, fire, nudge, onPlunger, finish, curMis, misNeed, FRAME, FP, R, DT, HZ, PF },
  });
})();
