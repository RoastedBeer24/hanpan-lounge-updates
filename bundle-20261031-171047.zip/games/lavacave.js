/* 용암 동굴 탈출 — realtime co-op 2D platformer (1–4, one player per phone; local = me + AI partners).
   Coarse flow via state (api.setState): play(단계마다 key 바뀜) → … → done(모두 쓰러짐).
   The level is built deterministically from (lv, sd, n) so every device has the same geometry.
   Host/local runs the world sim (stepWorld); online guests simulate only their own body (client authority)
   and receive host snapshots (hostSend) for everything else. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ======================= constants ======================= */
  const GW = 14, CH = 10, PW = 0.7, PH = 0.95, CS = 0.96;
  const GRAV = 38, JV = 16, RUN = 6.5, ACC_G = 80, ACC_A = 44, DEC_G = 70, MAXF = 20, COY = 0.1, BUF = 0.13;
  const THROW = 21, VENT = 19, CLIMB = 4.4, POP = 13;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const NOIN = { l: 0, r: 0, j: 0, a: 0, d: 0 };
  const ROLES = [
    { nm: '횃불지기', ds: '머리 등불이 가장 밝아요' },
    { nm: '바위어깨', ds: '넓은 어깨, 동료를 잘 받쳐요' },
    { nm: '잿빛매', ds: '잿빛 목도리를 두른 날쌘 등반가' },
    { nm: '밧줄꾼', ds: '등에 밧줄 뭉치를 멘 길잡이' },
  ];
  function rng(seed) {
    let a = seed >>> 0;
    return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ======================= chunks =======================
     14×10, rows top→bottom. Row 0 is the "band" you stand on when you leave the chunk.
     # 바위  = 발판(아래에서 통과)  ~ 무너지는 발판  R 밧줄  v 증기 구멍  ^ 혼자일 때만 생기는 돌계단
     A/B 압력 발판 → a/b 문   q 발판 A가 눌린 동안 내려오는 밧줄   1/2/3 레버(순서) → s 문
     k 수정 열쇠 → K 수정 자물쇠   o 가벼운 돌덩이  O 무거운 바위(둘이 밀기)   T/t 승강기 아래/위
     H 사슬 고리   b 어깨 받쳐 주기 자리(AI 힌트)   S 시작 자리   E 출구 */
  const CHUNKS = {
    steps: { nm: '돌계단', r: [
      '#####===###==#',
      '#............#',
      '#.....===....#',
      '#............#',
      '#..====......#',
      '#............#',
      '#............#',
      '#.......====.#',
      '#............#',
      '#............#'] },
    zig: { nm: '갈지자 바위턱', r: [
      '#==########==#',
      '#............#',
      '#===......===#',
      '#............#',
      '#.....==.....#',
      '#............#',
      '#............#',
      '#=====..=====#',
      '#............#',
      '#............#'] },
    crumble: { nm: '무너지는 턱', r: [
      '######====####',
      '#............#',
      '#....~~~~....#',
      '#............#',
      '#~~~......~~~#',
      '#............#',
      '#............#',
      '#....~~~~....#',
      '#............#',
      '#............#'] },
    steps2: { nm: '좁은 턱', r: [
      '#==#########=#',
      '#............#',
      '#.=~.....~=..#',
      '#............#',
      '#....~~~~....#',
      '#............#',
      '#=~........~=#',
      '#............#',
      '#....====....#',
      '#............#'] },
    plate1: { nm: '압력 발판 문', r: [
      '########===###',
      '#......#.....#',
      '#......#.====#',
      '#......#.....#',
      '#......#..==.#',
      '#......a.....#',
      '#.A....a...A.#',
      '#======#######',
      '#............#',
      '#............#'] },
    rope1: { nm: '밧줄 굴뚝', r: [
      '####====######',
      '#####.R.######',
      '#####.R.######',
      '#####.R.######',
      '#####.R.######',
      '#####.R.######',
      '#####.R.######',
      '#####.R.######',
      '#.....R......#',
      '#............#'] },
    boost1: { nm: '어깨 위로', r: [
      '#=====########',
      '#.......######',
      '#..==...######',
      '#.A....q######',
      '######.q######',
      '######.q######',
      '######.q######',
      '######^q######',
      '######.q######',
      '#.....b......#'] },
    crate1: { nm: '돌덩이 발판', r: [
      '#########===##',
      '#.......#....#',
      '#.......#.==.#',
      '#.......#....#',
      '#.......#=..=#',
      '#.......a....#',
      '#..o.A..a..A.#',
      '#======#######',
      '#............#',
      '#............#'] },
    levers: { nm: '레버 순서', r: [
      '##########===#',
      '#..3.....s...#',
      '#.===.===#####',
      '#........#####',
      '#......1.#####',
      '#...=====#####',
      '#........#####',
      '#===.....#####',
      '#........#####',
      '#2...........#'] },
    vents: { nm: '증기 구멍', r: [
      '#####===######',
      '#............#',
      '#....===.....#',
      '#............#',
      '#............#',
      '#..===...===.#',
      '#............#',
      '#............#',
      '#............#',
      '#v..........v#'] },
    lift1: { nm: '승강기 굴', r: [
      '#===##########',
      '#......#######',
      '#....t.#######',
      '#####..#######',
      '#####..#######',
      '#####..#######',
      '#####..#######',
      '#####..#######',
      '#####..#######',
      '#....T.......#'] },
    key1: { nm: '수정 자물쇠', r: [
      '#####====#####',
      '#....KKKK....#',
      '#k...........#',
      '#===.====....#',
      '#............#',
      '#............#',
      '#........===.#',
      '#............#',
      '#....==......#',
      '#............#'] },
    heavy1: { nm: '무거운 바위', r: [
      '#########===##',
      '#.......#....#',
      '#.......#.==.#',
      '#.......#....#',
      '#.......#=..=#',
      '#......##....#',
      '#......O.....#',
      '#======#######',
      '#............#',
      '#............#'] },
    chain1: { nm: '흔들 사슬', r: [
      '#########====#',
      '#.....H......#',
      '#...........=#',
      '#............#',
      '#==.......####',
      '#.........####',
      '#.........####',
      '#===......####',
      '#.........####',
      '#............#'] },
    ropeplate: { nm: '발판 밧줄', r: [
      '#=====########',
      '#............#',
      '#..===.......#',
      '#..A...q.....#',
      '#######q######',
      '#######q######',
      '#######q######',
      '#######q######',
      '#######q######',
      '#......q..A..#'] },
    vent2: { nm: '증기 사다리', r: [
      '##==#######==#',
      '#............#',
      '#.==.....====#',
      '#............#',
      '#............#',
      '#............#',
      '#.......v....#',
      '#............#',
      '#....==......#',
      '#............#'] },
    lift2: { nm: '무너지는 승강장', r: [
      '##########===#',
      '#.........t..#',
      '#............#',
      '#~~~.........#',
      '#............#',
      '#.....~~.....#',
      '#............#',
      '#............#',
      '#..==........#',
      '#.........T..#'] },
    keyrope: { nm: '밧줄 끝 열쇠', r: [
      '####===#######',
      '#...KKK......#',
      '#...........k#',
      '#..=====.R.==#',
      '#........R...#',
      '#........R...#',
      '#........R...#',
      '#........R...#',
      '#.....===R...#',
      '#............#'] },
  };
  const START = ['#===##==##===#', '#............#', '#............#', '#..==....==..#', '#............#', '#.SSSS..SSSS.#', '##############'];
  const EXIT = ['##############', '#EEEEEEEEEEEE#', '#EEEEEEEEEEEE#', '#EEEEEEEEEEEE#'];
  const HAND = [
    { nm: '첫 숨', hint: '바위턱을 밟고 위로! 점프를 길게 누르면 더 높이 뛰어요.', c: ['steps', 'zig', 'steps'] },
    { nm: '무너지는 길', hint: '금 간 발판은 밟으면 곧 무너져요. 조금 뒤에 다시 생겨요.', c: ['crumble', 'steps2', 'zig', 'crumble'] },
    { nm: '압력 발판', hint: '발판을 누군가 밟고 있는 동안만 문이 열려요. 건너편에도 발판이 있어요.', c: ['steps', 'plate1', 'zig', 'plate1'] },
    { nm: '밧줄 굴뚝', hint: '밧줄에 뛰어들면 매달려요. 점프를 누르고 있으면 올라가요.', c: ['rope1', 'steps2', 'ropeplate'] },
    { nm: '어깨 위로', hint: '동료 머리 위에 올라서면 액션으로 던져 줄 수 있어요.', c: ['boost1', 'zig', 'boost1'] },
    { nm: '돌덩이', hint: '돌덩이를 밀어 발판에 올려 두면 문이 계속 열려 있어요.', c: ['crate1', 'steps', 'crate1', 'crumble'] },
    { nm: '레버 순서', hint: '레버는 Ⅰ→Ⅱ→Ⅲ 순서로! 틀리면 처음부터 다시예요.', c: ['levers', 'zig', 'levers'] },
    { nm: '증기 구멍', hint: '증기가 뿜어질 때 구멍 위에 서 있으면 높이 솟아올라요.', c: ['vents', 'crumble', 'vent2'] },
    { nm: '승강기', hint: '승강기는 저절로 오르내려요. 바닥에 내려왔을 때 올라타요.', c: ['lift1', 'steps2', 'lift2'] },
    { nm: '수정 열쇠', hint: '수정 열쇠를 들고 수정 자물쇠에 닿으면 열려요.', c: ['key1', 'zig', 'keyrope'] },
    { nm: '사슬과 바위', hint: '무거운 바위는 둘이 함께 밀어야 움직여요. 사슬은 놓을 때 점프!', c: ['heavy1', 'chain1', 'steps'] },
    { nm: '마그마 심장', hint: '지금까지 배운 것을 모두 써서 빠져나가요!', c: ['plate1', 'chain1', 'ropeplate', 'key1', 'heavy1'] },
  ];
  const POOL = Object.keys(CHUNKS);
  const BASIC = ['steps', 'zig', 'crumble', 'steps2'];

  function levelPlan(lv, sd) {
    if (lv < HAND.length) return { nm: HAND[lv].nm, hint: HAND[lv].hint, c: HAND[lv].c.slice() };
    const R = rng(sd * 7 + lv * 131);
    const cnt = Math.min(8, 5 + Math.floor((lv - HAND.length) / 3));
    const c = []; let last = '';
    for (let i = 0; i < cnt; i++) {
      let id; let g = 0;
      do { id = (i % 3 === 2 ? BASIC : POOL)[Math.floor(R() * (i % 3 === 2 ? BASIC.length : POOL.length))]; g++; } while (id === last && g < 9);
      c.push(id); last = id;
    }
    return { nm: '깊은 곳 ' + (lv - HAND.length + 1) + '층', hint: '처음 보는 길이에요. 힘을 모아 위로!', c };
  }
  function lvName(lv) { return lv < HAND.length ? (lv + 1) + '단계 · ' + HAND[lv].nm : '깊은 곳 ' + (lv - HAND.length + 1) + '층'; }
  function lavaRate(lv, sp) {
    const b = lv < HAND.length ? 0.2 + lv * 0.014 : Math.min(0.62, 0.36 + (lv - HAND.length) * 0.022);
    return b * [0.72, 1, 1.32][sp == null ? 1 : sp];
  }

  /* ======================= level build ======================= */
  function buildWorld(lv, sd, n, lives) {
    const plan = levelPlan(lv, sd);
    const rows = [], rc = [];
    EXIT.forEach((r) => { rows.push(r); rc.push(-1); });
    for (let ci = plan.c.length - 1; ci >= 0; ci--) CHUNKS[plan.c[ci]].r.forEach((r) => { rows.push(r); rc.push(ci); });
    START.forEach((r) => { rows.push(r); rc.push(plan.c.length); });
    const w = GW, h = rows.length;
    const W = {
      w, h, lv, nm: plan.nm, hint: plan.hint, plan: plan.c, rc, T: new Array(w * h).fill('.'), solo: n === 1,
      dg: {}, qg: {}, go: {}, gk: {}, lt: {}, sq: {}, sn: {}, lo: {}, cb: {}, bm: {}, crc: {},
      plates: [], doors: [], levers: [], keys: [], locks: [], cr: [], vents: [], lifts: [], chains: [], cps: [], spawns: [],
      liftE: {}, chE: {}, ps: [], t: 0, lava: h + 2, lr: 0, lives: lives, cp: 0, evs: [], evId: 0, clr: 0, done: 0, over: 0, gids: [],
      grace: 3.5, stat: { die: 0, tp: 0 },
    };
    const liftTmp = {};
    for (let y = 0; y < h; y++) {
      const row = rows[y];
      for (let x = 0; x < w; x++) {
        const c = row[x] || '#', i = y * w + x, ci = rc[y];
        const gid = (k) => ci * 8 + k;
        let t = c;
        if (c === 'S') { W.spawns.push({ x, y }); t = '.'; }
        else if (c === 'A' || c === 'B' || c === 'C') { const g = gid(c.charCodeAt(0) - 65); W.plates.push({ x, y, g, on: 0 }); W.gk[g] = 'p'; t = '.'; }
        else if (c === 'a' || c === 'c') { const g = gid(c.charCodeAt(0) - 97); W.dg[i] = g; W.doors.push({ x, y, g }); t = 'd'; }
        else if (c === 'q') { W.qg[i] = gid(0); t = 'q'; }
        else if (c === '1' || c === '2' || c === '3') { const g = gid(3); W.levers.push({ x, y, g, i: +c, on: 0 }); W.gk[g] = 'l'; W.sn[g] = Math.max(W.sn[g] || 0, +c); W.sq[g] = 0; t = '.'; }
        else if (c === 's') { const g = gid(3); W.dg[i] = g; W.doors.push({ x, y, g }); t = 'd'; }
        else if (c === 'K') { const g = gid(4); W.dg[i] = g; W.locks.push({ x, y, g }); t = 'd'; }
        else if (c === 'k') { const g = gid(4); W.keys.push({ x: x, y: y, sx: x, sy: y, g, h: -1, u: 0 }); W.gk[g] = 'k'; t = '.'; }
        else if (c === 'o' || c === 'O') { W.cr.push({ x: x + (1 - CS) / 2, y: y + 1 - CS, vx: 0, vy: 0, hv: c === 'O' ? 1 : 0, ldx: 0 }); t = '.'; }
        else if (c === 'T') { (liftTmp[ci] = liftTmp[ci] || {}).b = { x, y }; t = '.'; }
        else if (c === 't') { (liftTmp[ci] = liftTmp[ci] || {}).t = { x, y }; t = '.'; }
        else if (c === 'H') { W.chains.push({ ax: x + 0.5, ay: y + 0.5, L: 3, A: 1.0, w: 2.4, ph: (x * 1.7 + y * 0.9) % 6.28 }); t = '.'; }
        else if (c === 'b') { W.bm[i] = 1; t = '.'; }
        else if (c === 'v') W.vents.push({ x, y, ph: (x * 0.37 + y * 0.53) % 2.8 });
        W.T[i] = t;
      }
    }
    for (const k in liftTmp) {
      const o = liftTmp[k]; if (!o.b || !o.t) continue;
      W.lifts.push({ x: o.b.x, y0: o.t.y + 1, y1: o.b.y + 1, y: o.b.y + 1, dy: 0, ph: (o.b.x * 0.9) % 7 });
    }
    for (const d of W.doors) if (W.gk[d.g] == null) W.gk[d.g] = 'p';
    for (const l of W.locks) W.gk[l.g] = 'k';
    const gs = {}; [W.doors, W.locks].forEach((a) => a.forEach((d) => { gs[d.g] = 1; }));
    W.plates.forEach((p) => { gs[p.g] = 1; });
    W.gids = Object.keys(gs).map(Number);
    W.gids.forEach((g) => { W.go[g] = 0; W.lt[g] = 0; });
    W.grow = {}; [W.doors, W.locks, W.plates, W.levers].forEach((a) => a.forEach((o) => { const r = W.grow[o.g]; W.grow[o.g] = r == null ? o.y : Math.max(r, o.y); }));
    // lift & chain edges for the planner
    W.lifts.forEach((lf, li) => {
      const rb = lf.y1 - 1, rt = lf.y0 - 1;
      const from = [lf.x - 1, lf.x, lf.x + 1, lf.x + 2];
      from.forEach((fx) => { if (fx < 1 || fx > w - 2) return; const i = rb * w + fx; (W.liftE[i] = W.liftE[i] || []);
        for (let ty = rt - 3; ty <= rt; ty++) for (let tx = lf.x - 2; tx <= lf.x + 3; tx++) {
          const onCol = tx === lf.x || tx === lf.x + 1;
          if (tx >= 1 && tx <= w - 2 && (ty === rt ? !onCol : onCol)) W.liftE[i].push({ tx, ty, li, up: ty < rt ? 1 : 0, rt });
        } });
    });
    W.chains.forEach((c, ci) => {
      const ax = Math.floor(c.ax), ay = Math.floor(c.ay);
      for (let sy = ay + c.L - 1; sy <= ay + c.L; sy++) for (let sx = 1; sx < w - 1; sx++) {
        const d = sx - ax; if (Math.abs(d) < 1 || Math.abs(d) > 4) continue;
        const i = sy * w + sx;
        for (let ty = ay; ty <= ay + c.L + 1; ty++) for (let tx = 1; tx < w - 1; tx++) {
          const e = tx - ax; if (Math.sign(e) === Math.sign(d) || Math.abs(e) < 2 || Math.abs(e) > 6) continue;
          (W.chE[i] = W.chE[i] || []).push({ tx, ty, ci });
        }
      }
    });
    // checkpoints: start row, then every second chunk boundary (standing on the band below chunk ci)
    const sRow = W.spawns.length ? W.spawns[0].y : h - 2;
    W.cps.push({ row: sRow, xs: W.spawns.map((s) => s.x) });
    for (let ci = 1; ci < plan.c.length; ci += 2) {
      // band row of chunk ci-1 is its row 0 → rows index
      let bandRow = -1; for (let y = 0; y < h; y++) if (rc[y] === ci - 1) { bandRow = y; break; }
      if (bandRow < 1) continue;
      const sr = bandRow - 1, xs = [];
      for (let x = 1; x < w - 1; x++) if (!solidC(W, x, sr) && (solidC(W, x, bandRow) || onewayC(W, x, bandRow))) xs.push(x);
      if (xs.length) W.cps.push({ row: sr, xs });
    }
    W.cps.sort((a, b) => b.row - a.row);
    for (let i = 0; i < n; i++) {
      const s = W.spawns[i % Math.max(1, W.spawns.length)] || { x: 2 + i, y: h - 2 };
      W.ps.push(newP(s.x + 0.5 - PW / 2, s.y + 1 - PH));
    }
    W.lava = h + 5;
    return W;
  }
  function newP(x, y) {
    return { x, y, vx: 0, vy: 0, gr: 0, co: 0, jb: 0, jp: 0, ap: 0, cut: 0, on: -1, fc: 1, rp: 0, rd: 0, cn: -1, rg: 0, dead: 0, rt: 0, key: -1, ex: 0, ldx: 0, in: { l: 0, r: 0, j: 0, a: 0, d: 0 }, rem: 0, an: 0, anS: 0, fx: '', thr: 0 };
  }

  /* ======================= tiles ======================= */
  function solidC(W, cx, cy) {
    if (cx < 0 || cx >= W.w || cy < 0 || cy >= W.h) return true;
    const i = cy * W.w + cx, c = W.T[i];
    if (c === '#' || c === 'v') return true;
    if (c === '^') return W.solo;
    if (c === 'd') return !W.go[W.dg[i]];
    return false;
  }
  function onewayC(W, cx, cy) {
    if (cx < 0 || cx >= W.w || cy < 0 || cy >= W.h) return false;
    const i = cy * W.w + cx, c = W.T[i];
    if (c === '=') return true;
    if (c === '~') return !(W.cb[i] < 0);
    return false;
  }
  function isRope(W, cx, cy) {
    if (cx < 0 || cx >= W.w || cy < 0 || cy >= W.h) return false;
    const i = cy * W.w + cx, c = W.T[i];
    return c === 'R' || (c === 'q' && !!W.go[W.qg[i]]);
  }
  function liftY(lf, t) {
    const P = 7, u = (((t + lf.ph) % P) + P) % P / P;
    let k;
    if (u < 0.14) k = 0; else if (u < 0.5) k = (u - 0.14) / 0.36; else if (u < 0.64) k = 1; else k = 1 - (u - 0.64) / 0.36;
    k = k * k * (3 - 2 * k);
    return lf.y1 + (lf.y0 - lf.y1) * k;
  }
  function chainA(c, t) { return c.A * Math.sin(c.w * t + c.ph); }
  function chainEnd(c, t) { const a = chainA(c, t); return { x: c.ax + c.L * Math.sin(a), y: c.ay + c.L * Math.cos(a), a, av: c.A * c.w * Math.cos(c.w * t + c.ph) }; }
  function ventOn(W, v) { const u = (W.t + v.ph) % 2.8; return u < 0.95; }
  function ventWarn(W, v) { const u = (W.t + v.ph) % 2.8; return u > 2.25; }

  /* ======================= player physics ======================= */
  function movePlayer(W, p, i, dt) {
    const inp = p.in || NOIN;
    const jPress = inp.j && !p.jp, aPress = inp.a && !p.ap;
    const dir = (inp.r ? 1 : 0) - (inp.l ? 1 : 0);
    if (p.rg > 0) p.rg -= dt;
    if (dir) p.fc = dir;
    const ox = p.x;
    if (p.cn >= 0) {
      const c = W.chains[p.cn];
      if (!c) p.cn = -1;
      else {
        const e = chainEnd(c, W.t);
        p.vx = c.L * Math.cos(e.a) * e.av; p.vy = -c.L * Math.sin(e.a) * e.av;
        p.x = e.x - PW / 2; p.y = e.y - 0.3; p.gr = 0; p.on = -1;
        if (jPress || aPress) { p.cn = -1; p.rg = 0.45; p.vx *= 1.2; p.vy -= 8; p.cut = 0; p.fx = 'j'; }
      }
    } else if (p.rp) {
      const rc = Math.floor(p.x + PW / 2);
      p.x += (rc + 0.5 - PW / 2 - p.x) * Math.min(1, dt * 16);
      p.vx = 0; p.gr = 0; p.on = -1;
      if (!dir) p.rd = 0;
      if (dir && dir !== p.rd) { p.rp = 0; p.vx = dir * 5.5; p.vy = -10; p.rg = 0.3; p.cut = 0; p.fx = 'j'; }
      else if (aPress) { p.rp = 0; p.rg = 0.35; p.vy = 0; }
      else if (!isRope(W, rc, Math.floor(p.y + 0.3))) { p.rp = 0; p.rg = 0.2; }
      else {
        const vy = inp.j ? -CLIMB : inp.d ? CLIMB : 0;
        let ny = p.y + vy * dt;
        if (vy < 0) {
          if (solidC(W, rc, Math.floor(ny))) ny = p.y;
          else if (!isRope(W, rc, Math.floor(ny + 0.3))) { p.rp = 0; p.vy = -POP; p.cut = 0; p.rg = 0.3; p.fx = 'j'; }
        } else if (vy > 0) {
          const f = Math.floor(ny + PH);
          if (solidC(W, rc, f) || onewayC(W, rc, f)) { ny = f - PH; p.rp = 0; p.gr = 1; }
          else if (!isRope(W, rc, Math.floor(ny + 0.3))) p.rp = 0;
        }
        p.y = ny; if (p.rp) p.vy = vy;
      }
    } else {
      const tgt = dir * RUN;
      const acc = p.gr ? (dir ? ACC_G : DEC_G) : (dir ? ACC_A : 6);
      if (p.vx < tgt) p.vx = Math.min(tgt, p.vx + acc * dt); else if (p.vx > tgt) p.vx = Math.max(tgt, p.vx - acc * dt);
      p.vy = Math.min(MAXF, p.vy + GRAV * dt);
      if (jPress) p.jb = BUF; else if (p.jb > 0) p.jb -= dt;
      if (p.gr) p.co = COY; else if (p.co > 0) p.co -= dt;
      if (p.jb > 0 && p.co > 0) { p.vy = -JV; p.jb = 0; p.co = 0; p.gr = 0; p.cut = 1; p.on = -1; p.fx = 'j'; }
      if (!inp.j && p.cut && p.vy < 0) { p.vy *= 0.45; p.cut = 0; }
      if (p.vy >= 0) p.cut = 0;
      // riding
      if (p.gr && p.on >= 0) {
        if (p.on < 100) { const b = W.ps[p.on]; if (b && !b.dead) p.x += b.ldx || 0; }
        else if (p.on < 200) { const lf = W.lifts[p.on - 100]; if (lf) p.y += lf.dy; }
        else { const k = W.cr[p.on - 200]; if (k) p.x += k.ldx || 0; }
      }
      moveX(W, p, dt);
      moveY(W, p, i, dt);
      // vents
      if (W.vents.length) {
        const cx = Math.floor(p.x + PW / 2), f = p.y + PH;
        for (const v of W.vents) if (v.x === cx && f > v.y - 1.3 && f <= v.y + 0.05 && ventOn(W, v) && p.vy > -VENT * 0.6) { p.vy = -VENT; p.gr = 0; p.cut = 0; p.on = -1; p.fx = 'v'; }
      }
      // grab rope / chain
      if (!p.gr && p.rg <= 0) {
        const cx = Math.floor(p.x + PW / 2);
        if (!inp.d && isRope(W, cx, Math.floor(p.y + 0.3))) { p.rp = 1; p.rd = dir; p.vy = 0; p.vx = 0; p.fx = 'g'; }
        else for (let ci = 0; ci < W.chains.length; ci++) {
          const e = chainEnd(W.chains[ci], W.t);
          if (Math.hypot(p.x + PW / 2 - e.x, p.y + 0.3 - e.y) < 0.8) { p.cn = ci; p.fx = 'g'; break; }
        }
      }
    }
    p.jp = inp.j ? 1 : 0; p.ap = inp.a ? 1 : 0;
    p.ldx = p.x - ox;
  }
  function moveX(W, p, dt) {
    let nx = p.x + p.vx * dt;
    const y0 = Math.floor(p.y + 0.02), y1 = Math.floor(p.y + PH - 0.02);
    if (p.vx > 0) { const c = Math.floor(nx + PW); for (let y = y0; y <= y1; y++) if (solidC(W, c, y)) { nx = c - PW - 0.001; p.vx = 0; break; } }
    else if (p.vx < 0) { const c = Math.floor(nx); for (let y = y0; y <= y1; y++) if (solidC(W, c, y)) { nx = c + 1.001; p.vx = 0; break; } }
    for (const k of W.cr) {
      if (p.y + PH <= k.y + 0.08 || p.y >= k.y + CS - 0.02) continue;
      if (nx + PW <= k.x || nx >= k.x + CS) continue;
      if (p.x + PW / 2 < k.x + CS / 2) nx = Math.min(nx, k.x - PW - 0.001); else nx = Math.max(nx, k.x + CS + 0.001);
      p.vx = 0;
    }
    p.x = nx;
  }
  function moveY(W, p, i, dt) {
    const ny = p.y + p.vy * dt;
    const x0 = Math.floor(p.x + 0.03), x1 = Math.floor(p.x + PW - 0.03);
    if (p.vy < 0) {
      const r = Math.floor(ny); let hit = false;
      for (let x = x0; x <= x1; x++) if (solidC(W, x, r)) { hit = true; break; }
      if (hit) { p.y = r + 1.001; p.vy = 0; p.cut = 0; }
      else {
        let yy = ny;
        for (const k of W.cr) if (p.x + PW > k.x + 0.05 && p.x < k.x + CS - 0.05 && k.y + CS > ny && k.y + CS <= p.y + 0.06) { yy = Math.max(yy, k.y + CS + 0.001); p.vy = 0; }
        p.y = yy;
      }
      p.gr = 0; p.on = -1; return;
    }
    const pf = p.y + PH, nf = ny + PH;
    let best = Infinity, on = -1;
    for (let r = Math.ceil(pf - 0.004); r <= Math.floor(nf); r++) {
      for (let x = x0; x <= x1; x++) if (solidC(W, x, r) || onewayC(W, x, r)) { best = r; break; }
      if (best < Infinity) break;
    }
    for (let ci = 0; ci < W.cr.length; ci++) {
      const k = W.cr[ci], top = k.y;
      if (p.x + PW > k.x + 0.06 && p.x < k.x + CS - 0.06 && pf <= top + 0.04 && nf >= top && top < best) { best = top; on = 200 + ci; }
    }
    for (let li = 0; li < W.lifts.length; li++) {
      const lf = W.lifts[li], top = lf.y;
      if (p.x + PW > lf.x + 0.05 && p.x < lf.x + 2 - 0.05 && pf <= top + 0.06 + Math.max(0, -lf.dy) && nf >= top - 0.001 && top < best) { best = top; on = 100 + li; }
    }
    const cx = p.x + PW / 2;
    for (let j = 0; j < W.ps.length; j++) {
      if (j === i) continue; const q = W.ps[j]; if (q.dead || q.on === i) continue;
      const top = q.y;
      if (Math.abs(cx - (q.x + PW / 2)) < 0.6 && pf <= top + 0.05 && nf >= top && top < best) { best = top; on = j; }
    }
    if (best < Infinity) { p.y = best - PH; p.vy = 0; p.gr = 1; p.on = on; }
    else { p.y = ny; p.gr = 0; p.on = -1; }
  }

  /* ======================= world step (host) ======================= */
  function ev(W, type, s, x, y) { W.evId++; W.evs.push([W.evId, type, s, Math.round((x || 0) * 10), Math.round((y || 0) * 10)]); if (W.evs.length > 14) W.evs.shift(); }
  function doAction(W, i) {
    const p = W.ps[i]; if (!p || p.dead) return;
    for (let j = 0; j < W.ps.length; j++) {
      const q = W.ps[j];
      if (j !== i && !q.dead && q.on === i && q.gr) { q.vy = -THROW; q.gr = 0; q.on = -1; q.cut = 0; q.co = 0; q.thr = 1; ev(W, 't', j, q.x + PW / 2, q.y); return; }
    }
    const cx = p.x + PW / 2, cy = p.y + PH / 2;
    for (const lv of W.levers) if (Math.abs(lv.x + 0.5 - cx) < 0.95 && Math.abs(lv.y + 0.5 - cy) < 1.0) { pullLever(W, lv, i); return; }
  }
  function pullLever(W, lv, i) {
    if (W.go[lv.g] || lv.on) return;
    if (lv.i === (W.sq[lv.g] || 0) + 1) {
      lv.on = 1; W.sq[lv.g] = (W.sq[lv.g] || 0) + 1; ev(W, 'l', i, lv.x + 0.5, lv.y + 0.5);
      if (W.sq[lv.g] >= W.sn[lv.g]) { W.go[lv.g] = 1; ev(W, 'o', i, lv.x + 0.5, lv.y + 0.5); }
    } else {
      W.levers.forEach((o) => { if (o.g === lv.g) o.on = 0; }); W.sq[lv.g] = 0; ev(W, 'w', i, lv.x + 0.5, lv.y + 0.5);
    }
  }
  function planCell(W, p) {
    const c = cellOf(p);
    if (W.crc[c.y * W.w + c.x] !== undefined) { const k = W.cr[W.crc[c.y * W.w + c.x]]; c.x += (p.x + PW / 2 < k.x + CS / 2) ? -1 : 1; }
    return c;
  }
  function cellOf(p) { return { x: Math.floor(p.x + PW / 2), y: Math.floor(p.y + PH - 0.5) }; }
  function overl(ax, ay, aw, ah, bx, by, bw, bh) { return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by; }
  function bodyIn(W, x, y) {
    for (const p of W.ps) if (!p.dead && overl(p.x, p.y, PW, PH, x + 0.02, y + 0.02, 0.96, 0.96)) return true;
    for (const k of W.cr) if (overl(k.x, k.y, CS, CS, x + 0.02, y + 0.02, 0.96, 0.96)) return true;
    return false;
  }
  function platePressed(W, pl) {
    for (const p of W.ps) { if (p.dead) continue; const f = p.y + PH, c = p.x + PW / 2; if (f > pl.y + 0.55 && f < pl.y + 1.06 && c > pl.x - 0.1 && c < pl.x + 1.1) return true; }
    for (const k of W.cr) { const f = k.y + CS, c = k.x + CS / 2; if (f > pl.y + 0.55 && f < pl.y + 1.06 && c > pl.x && c < pl.x + 1) return true; }
    return false;
  }
  function stepCrates(W, dt) {
    for (let ci = 0; ci < W.cr.length; ci++) {
      const k = W.cr[ci], ox = k.x;
      const need = k.hv ? (W.solo ? 1 : 2) : 1;
      let mv = 0;
      for (const d of [1, -1]) {
        let cnt = 0, touch = 0;
        for (const p of W.ps) {
          if (p.dead || !p.gr || p.rp) continue;
          const pd = ((p.in && p.in.r) ? 1 : 0) - ((p.in && p.in.l) ? 1 : 0);
          if (pd !== d) continue;
          if (!(p.y < k.y + CS - 0.12 && p.y + PH > k.y + 0.12)) continue;
          const gap = d > 0 ? k.x - (p.x + PW) : p.x - (k.x + CS);
          if (gap > -0.06 && gap < 1.6) { cnt++; if (gap < 0.1) touch = 1; }
        }
        if (touch && cnt >= need) { mv = d; k.pz = cnt; break; }
      }
      k.mv = mv;
      if (mv) {
        const sp = k.hv ? 1.8 : 2.8;
        let nx = k.x + mv * sp * dt;
        const y0 = Math.floor(k.y + 0.03), y1 = Math.floor(k.y + CS - 0.03);
        const c = mv > 0 ? Math.floor(nx + CS) : Math.floor(nx);
        for (let y = y0; y <= y1; y++) if (solidC(W, c, y)) { nx = mv > 0 ? c - CS - 0.001 : c + 1.001; break; }
        for (let cj = 0; cj < W.cr.length; cj++) {
          if (cj === ci) continue; const o = W.cr[cj];
          if (overl(nx, k.y + 0.05, CS, CS - 0.1, o.x, o.y, CS, CS)) nx = mv > 0 ? Math.min(nx, o.x - CS - 0.001) : Math.max(nx, o.x + CS + 0.001);
        }
        k.x = nx;
      }
      // gravity
      k.vy = Math.min(MAXF, k.vy + GRAV * dt);
      const pf = k.y + CS, nf = pf + k.vy * dt;
      let best = Infinity;
      const x0 = Math.floor(k.x + 0.05), x1 = Math.floor(k.x + CS - 0.05);
      for (let r = Math.ceil(pf - 0.004); r <= Math.floor(nf); r++) {
        for (let x = x0; x <= x1; x++) if (solidC(W, x, r) || onewayC(W, x, r)) { best = r; break; }
        if (best < Infinity) break;
      }
      for (let cj = 0; cj < W.cr.length; cj++) {
        if (cj === ci) continue; const o = W.cr[cj];
        if (k.x + CS > o.x + 0.1 && k.x < o.x + CS - 0.1 && pf <= o.y + 0.04 && nf >= o.y && o.y < best) best = o.y;
      }
      for (const lf of W.lifts) if (k.x + CS > lf.x + 0.1 && k.x < lf.x + 1.9 && pf <= lf.y + 0.06 + Math.max(0, -lf.dy) && nf >= lf.y && lf.y < best) best = lf.y;
      if (best < Infinity) { k.y = best - CS; k.vy = 0; } else k.y = nf - CS;
      k.ldx = k.x - ox;
      // push players out
      for (const p of W.ps) {
        if (p.dead || p.rem) continue;
        if (overl(p.x, p.y + 0.1, PW, PH - 0.2, k.x, k.y, CS, CS)) {
          if (p.x + PW / 2 < k.x + CS / 2) { if (!solidC(W, Math.floor(k.x - PW - 0.01), Math.floor(p.y + 0.5))) p.x = k.x - PW - 0.001; }
          else if (!solidC(W, Math.floor(k.x + CS + PW + 0.01), Math.floor(p.y + 0.5))) p.x = k.x + CS + 0.001;
        }
      }
    }
  }
  function respawnAt(W, i) {
    const cp = W.cps[W.cp] || W.cps[0];
    const xs = cp.xs.length ? cp.xs : [2];
    const x = xs[(i * 3 + Math.floor(xs.length / 2)) % xs.length];
    const p = W.ps[i];
    Object.assign(p, newP(x + 0.5 - PW / 2, cp.row + 1 - PH), { rem: p.rem, an: p.an, anS: p.anS, in: p.in });
    if (W.lava < cp.row + 7) { W.lava = cp.row + 7; ev(W, 'c', i, 7, cp.row); }
    p.ign = W.t + 0.9;
    ev(W, 'r', i, p.x + PW / 2, p.y);
  }
  function stepWorld(W, dt) {
    if (W.over || W.done) return;
    W.t += dt;
    for (const lf of W.lifts) { const ny = liftY(lf, W.t); lf.dy = ny - lf.y; lf.y = ny; }
    stepCrates(W, dt);
    const n = W.ps.length;
    for (let i = 0; i < n; i++) {
      const p = W.ps[i];
      if (p.dead) {
        if (p.rt > 0) { p.rt -= dt; if (p.rt <= 0) { if (W.lives > 0) { W.lives--; respawnAt(W, i); } else p.rt = 0; } }
        continue;
      }
      if (!p.rem) { if (p.in.a && !p.ap) doAction(W, i); movePlayer(W, p, i, dt); }
      else if (p.an !== p.anS) { p.anS = p.an; doAction(W, i); }
      const c = cellOf(p);
      // crumble trigger
      if (p.gr && p.on < 0) {
        const fr = Math.floor(p.y + PH + 0.05);
        for (const x of [Math.floor(p.x + 0.05), Math.floor(p.x + PW - 0.05)]) {
          const ii = fr * W.w + x;
          if (W.T[ii] === '~' && W.cb[ii] == null) { W.cb[ii] = 0.7; ev(W, 'q', i, x + 0.5, fr); }
        }
      }
      // keys & locks
      for (let ki = 0; ki < W.keys.length; ki++) {
        const k = W.keys[ki]; if (k.u) continue;
        if (k.h === i) {
          k.x = p.x + PW / 2 - 0.5; k.y = p.y - 0.75;
          for (const lk of W.locks) if (lk.g === k.g && overl(p.x - 0.25, p.y - 0.25, PW + 0.5, PH + 0.5, lk.x, lk.y, 1, 1)) {
            W.lo[k.g] = 1; W.go[k.g] = 1; k.u = 1; k.h = -1; p.key = -1; ev(W, 'k', i, lk.x + 0.5, lk.y + 0.5); break;
          }
        } else if (k.h < 0 && p.key < 0 && overl(p.x, p.y, PW, PH, k.x + 0.15, k.y + 0.1, 0.7, 0.8)) { k.h = i; p.key = ki; ev(W, 'p', i, k.x + 0.5, k.y + 0.5); }
      }
      // checkpoints
      if (p.gr) for (let ci = W.cp + 1; ci < W.cps.length; ci++) if (c.y <= W.cps[ci].row) { W.cp = ci; ev(W, 'C', i, p.x, p.y); }
      p.ex = W.T[c.y * W.w + c.x] === 'E' || (c.y - 1 >= 0 && W.T[(c.y) * W.w + c.x] === 'E') ? 1 : 0;
      // lava
      if (p.y + PH * 0.55 > W.lava) {
        p.dead = 1; p.rt = 2.4; p.rp = 0; p.cn = -1; W.stat.die++;
        if (p.key >= 0) { const k = W.keys[p.key]; if (k) { k.h = -1; k.x = k.sx; k.y = k.sy; } p.key = -1; }
        ev(W, 'd', i, p.x + PW / 2, W.lava);
      }
    }
    // keys whose holder died
    for (const k of W.keys) if (!k.u && k.h >= 0 && W.ps[k.h] && W.ps[k.h].dead) { k.h = -1; k.x = k.sx; k.y = k.sy; }
    // plates & doors
    for (const pl of W.plates) pl.on = platePressed(W, pl) ? 1 : 0;
    for (const g of W.gids) {
      if (W.gk[g] !== 'p') continue;
      let any = false; for (const pl of W.plates) if (pl.g === g && pl.on) { any = true; break; }
      if (any) W.lt[g] = W.solo ? 6 : 0; else if (W.lt[g] > 0) W.lt[g] -= dt;
      let want = any || W.lt[g] > 0;
      if (!want && W.go[g]) { for (const d of W.doors) if (d.g === g && bodyIn(W, d.x, d.y)) { want = true; break; } }
      if (!!want !== !!W.go[g]) { W.go[g] = want ? 1 : 0; ev(W, want ? 'o' : 'x', -1, 0, 0); }
    }
    // crumble timers
    for (const k in W.cb) {
      const v = W.cb[k];
      if (v > 0) { const nv = v - dt; W.cb[k] = nv <= 0 ? -4.5 : nv; }
      else { const nv = v + dt; if (nv >= 0) { const ii = +k; if (bodyIn(W, ii % W.w, Math.floor(ii / W.w))) W.cb[k] = -0.2; else delete W.cb[k]; } else W.cb[k] = nv; }
    }
    // lava
    if (W.t > W.grace) {
      let low = -Infinity, anyEx = 0;
      for (const p of W.ps) if (!p.dead) { low = Math.max(low, p.y + PH); if (p.ex) anyEx = 1; }
      let r = W.lr;
      if (low > -Infinity && W.lava - low > 11) r *= 3.2;
      if (anyEx) r *= 0.5;
      W.lava -= r * dt;
    }
    // level end / wipe
    const alive = W.ps.filter((p) => !p.dead);
    if (alive.length && alive.every((p) => p.ex)) { W.clr += dt; if (W.clr > 0.7) W.done = 1; } else W.clr = 0;
    if (!alive.length && W.lives <= 0 && W.ps.every((p) => p.rt <= 0)) W.over = 1;
  }

  /* ======================= planner (AI) ======================= */
  function mkP(W, hyp) {
    const N = W.w * W.h, so = new Int8Array(N).fill(-1);
    const solid = (x, y) => {
      if (x < 0 || x >= W.w || y < 0 || y >= W.h) return true;
      const i = y * W.w + x; let v = so[i];
      if (v >= 0) return v === 1;
      const c = W.T[i];
      let s;
      if (c === 'd') { const g = W.dg[i]; s = !(W.go[g] || (hyp.g && hyp.g[g])) || !!(hyp.cl && hyp.cl[g]); }
      else s = solidC(W, x, y);
      if (!s) { const k = W.crc[i]; if (k !== undefined && !(hyp.ns && W.cr[k].hv)) s = true; }
      so[i] = s ? 1 : 0; return s;
    };
    const lavaRow = W.lava - 0.4;
    const op = (x, y) => !solid(x, y) && y + 1 < lavaRow;
    const supp = (x, y) => { if (y + 1 >= W.h) return true; const c = W.T[(y + 1) * W.w + x]; return solid(x, y + 1) || c === '=' || (c === '~' && !(W.cb[(y + 1) * W.w + x] < 0)); };
    const st = (x, y) => op(x, y) && supp(x, y);
    const rp = (x, y) => { if (!op(x, y)) return false; const i = y * W.w + x, c = W.T[i]; return c === 'R' || (c === 'q' && (W.go[W.qg[i]] || (hyp.g && hyp.g[W.qg[i]])) && !(hyp.cl && hyp.cl[W.qg[i]])); };
    const row = (y, a, b) => { const s = a < b ? 1 : -1; for (let x = a; x !== b + s; x += s) if (!op(x, y)) return false; return true; };
    const col = (x, a, b) => { for (let y = Math.min(a, b); y <= Math.max(a, b); y++) if (!op(x, y)) return false; return true; };
    const ow = (x, y) => { const c = W.T[y * W.w + x]; return c === '=' || (c === '~' && !(W.cb[y * W.w + x] < 0)); };
    const drop = (x, a, b) => { for (let y = a; y <= b; y++) if (!op(x, y) || (y > a && ow(x, y))) return false; return true; };
    return { op, st, rp, row, col, drop };
  }
  const UPM = [4, 3, 2];
  /* Test a hop with the real movement code (the way the AI performs it): from the tile centre,
     full run-up for long hops / standing for short ones, jump held, air-steer to the target.
     Cached per level unless a door, crumble or stone is in the way (those change). */
  function hopOK(W, x, y, tx, ty, rope, hyp) { return hopOff(W, x, y, tx, ty, rope, hyp) > -9; }
  // takeoff offset (tiles past the centre, toward the target) that works, or -9 if none
  function hopOff(W, x, y, tx, ty, rope, hyp) {
    const N = W.w * W.h, key = (y * W.w + x) * N + ty * W.w + tx;
    const e0 = W.hc && W.hc[key]; if (e0 && e0.v === undefined) return e0.o; // static hop: tested once
    let vol = false, sig = 0; const opn = [];
    for (let yy = Math.max(0, Math.min(y, ty) - 1); yy <= Math.min(W.h - 1, Math.max(y, ty) + 1); yy++) for (let xx = Math.min(x, tx); xx <= Math.max(x, tx); xx++) {
      const ii = yy * W.w + xx, c = W.T[ii];
      if (c === 'd' || c === '~') { vol = true; sig = sig * 3 + (c === 'd' ? (W.go[W.dg[ii]] ? 1 : 0) : (W.cb[ii] < 0 ? 2 : 0)) + 1; sig %= 1e15; }
      const gg = c === 'd' ? W.dg[ii] : c === 'q' ? W.qg[ii] : null;
      if (gg != null && hyp && hyp.g && hyp.g[gg] && !W.go[gg] && opn.indexOf(gg) < 0) opn.push(gg);
      if (c === 'q') { vol = true; sig = (sig * 3 + (W.go[W.qg[ii]] ? 1 : 0) + 1) % 1e15; }
    }
    const hc = opn.length ? (W.hch || (W.hch = {})) : (W.hc || (W.hc = {}));
    const e = hc[key];
    if (e !== undefined && (e.v === undefined || e.v === sig)) return e.o;
    // spread the testing over frames: past the budget, trust the shape check for now (not cached)
    if ((W.simN = (W.simN || 0) + 1) > 70) return 0;
    let o = -9;
    const far = Math.abs(tx - x) >= 2 || ty > y;
    opn.forEach((g) => { W.go[g] = 1; });
    try { for (const off of (far ? [0, 0.3, 0.55, 0.8, 1.0] : [0])) if (simHop(W, x, y, tx, ty, rope, off, far)) { o = off; break; } }
    finally { opn.forEach((g) => { W.go[g] = 0; }); }
    hc[key] = vol ? { o, v: sig } : { o };
    return o;
  }
  // leaving a rope sideways (fixed hop) or popping off its top — tested the same way
  function ropeHopOK(W, x, y, tx, ty, top) {
    const N = W.w * W.h, key = -((y * W.w + x) * N + ty * W.w + tx) - (top ? 0.5 : 0);
    const hc = W.hc || (W.hc = {});
    if (hc[key] !== undefined) return hc[key].o > -9;
    const sg = Math.sign(tx - x) || 0;
    const ok = simHop(W, x, y, tx, ty, false, 0, false, top ? { vx: 0, vy: -POP, y: y + 0.3 } : { vx: sg * 5.5, vy: -10, y: y + 0.05 });
    hc[key] = { o: ok ? 0 : -9 };
    return ok;
  }
  function simHop(W, x, y, tx, ty, rope, off, far, st) {
    const sg = Math.sign(tx - x) || 1;
    const ps = W.ps; W.ps = [];
    const q = st ? { x: x + 0.5 - PW / 2, y: st.y, vx: st.vx, vy: st.vy, gr: 0, on: -1, cut: 0 } : { x: x + 0.5 + sg * off - PW / 2, y: y + 1 - PH, vx: far ? sg * RUN : 0, vy: -JV, gr: 0, on: -1, cut: 0 };
    let ok = false;
    try {
      for (let k = 0; k < 96; k++) {
        const dt = 1 / 60, cx = q.x + PW / 2, gx = tx + 0.5;
        let dir = 0; const dp = gx - (cx + q.vx * Math.abs(q.vx) / (2 * ACC_A));
        if (Math.abs(gx - cx) > 0.08 || Math.abs(dp) > 0.13) dir = dp > 0 ? 1 : -1;
        const low = ty < y && q.y + PH > ty + 1.02;
        if (low && Math.abs(gx - cx) > 0.3) dir = gx > cx ? 1 : -1;
        if (dir && low && q.vy < 0) {
          const nc = dir > 0 ? Math.floor(q.x + PW + 0.06) : Math.floor(q.x - 0.06);
          for (let r = Math.floor(q.y + 0.02); r <= Math.floor(q.y + PH - 0.05); r++) if (solidC(W, nc, r)) { dir = 0; break; }
        }
        const tgt = dir * RUN, acc = dir ? ACC_A : 6;
        if (q.vx < tgt) q.vx = Math.min(tgt, q.vx + acc * dt); else if (q.vx > tgt) q.vx = Math.max(tgt, q.vx - acc * dt);
        q.vy = Math.min(MAXF, q.vy + GRAV * dt);
        moveX(W, q, dt); moveY(W, q, -1, dt);
        const c = cellOf(q);
        if (rope && c.x === tx && isRope(W, c.x, Math.floor(q.y + 0.3)) && Math.abs(Math.floor(q.y + 0.3) - ty) <= 1) { ok = true; break; }
        if (q.gr) { ok = c.y === ty && Math.abs(c.x - tx) <= (far ? 2 : 0); break; }
        if (q.y > W.h) break;
      }
    } finally { W.ps = ps; }
    return ok;
  }
  function edges(W, P, x, y, hyp, add) {
    const isStand = P.st(x, y), isRope = P.rp(x, y);
    if (isStand) {
      for (const d of [-1, 1]) {
        const nx = x + d;
        if (!P.op(nx, y)) continue;
        if (P.st(nx, y)) add(nx, y, 'walk', 1);
        else if (P.rp(nx, y)) add(nx, y, 'rope', 1.5);
        else {
          let fy = y + 1;
          while (fy < W.h && P.op(nx, fy) && !P.st(nx, fy) && !P.rp(nx, fy)) fy++;
          if (fy < W.h && P.op(nx, fy)) add(nx, fy, 'fall', 1 + (fy - y) * 0.2);
          // run off the edge and jump in coyote time (works under a low ceiling)
          if (P.op(nx, y - 1)) for (let a = 2; a <= 3; a++) {
            const tx = x + d * a;
            if (P.st(tx, y) && P.row(y, nx, tx) && P.row(y - 1, nx, tx)) add(tx, y, 'cjump', 1.7 + a * 0.3);
            if (P.st(tx, y - 1) && P.row(y - 1, nx, tx) && P.row(y - 2, nx, tx) && P.op(nx, y - 2)) add(tx, y - 1, 'cjump', 2 + a * 0.3);
          }
        }
      }
      for (let dy = 1; dy <= 3; dy++) {
        const ty = y - dy; if (!P.op(x, ty + 1)) break;
        const full = P.op(x, ty);
        const m = UPM[dy - 1];
        for (let dx = -m; dx <= m; dx++) {
          const tx = x + dx, s = P.st(tx, ty), r = P.rp(tx, ty);
          if (!s && !r) continue;
          if (dx === 0) { if (!full) continue; }
          else if (!((full && P.row(ty, x, tx) && (dy < 3 || Math.abs(dx) <= 1)) || (P.op(tx, ty + 1) && P.row(ty + 1, x, tx)))) continue;
          if (!hopOK(W, x, y, tx, ty, r && !s, hyp)) continue;
          add(tx, ty, r && !s ? 'rope' : 'jump', 1.4 + dy * 0.3 + Math.abs(dx) * 0.25);
        }
      }
      for (const s of [-1, 1]) for (let a = 2; a <= 4; a++) {
        const tx = x + s * a; if (!P.st(tx, y)) continue;
        if (!P.row(y, x, tx) || !P.row(y - 1, x, tx) || (a >= 3 && !P.row(y - 2, x, tx)) || !hopOK(W, x, y, tx, y, false, hyp)) continue;
        add(tx, y, 'jump', 1.3 + a * 0.3);
      }
      for (let dy = 1; dy <= 4; dy++) for (const s of [-1, 1]) for (let a = 2; a <= 5; a++) {
        const tx = x + s * a, ty = y + dy; if (!P.st(tx, ty)) continue;
        if (!P.row(y, x, tx) || !P.row(y - 1, x, tx) || (a >= 4 && !P.row(y - 2, x, tx)) || !P.drop(tx, y, ty) || !hopOK(W, x, y, tx, ty, false, hyp)) continue;
        add(tx, ty, 'jump', 1.3 + a * 0.3 + dy * 0.1);
      }
      if (y + 1 < W.h && W.T[(y + 1) * W.w + x] === 'v') {
        for (let dy = 1; dy <= 4; dy++) { const ty = y - dy; if (!P.op(x, ty)) break; for (let dx = -2; dx <= 2; dx++) { const tx = x + dx; if (P.st(tx, ty) && P.row(ty, x, tx)) add(tx, ty, 'vent', 2.5); } }
      }
      if (hyp.boost && W.bm[y * W.w + x]) {
        for (let dy = 1; dy <= 6; dy++) { const ty = y - dy; if (!P.op(x, ty)) break; for (let dx = -2; dx <= 2; dx++) { const tx = x + dx; if (P.st(tx, ty) && P.row(ty, x, tx)) add(tx, ty, 'boost', 8); } }
      }
      const le = W.liftE[y * W.w + x]; if (le) for (const e of le) if (P.st(e.tx, e.ty) && (!e.up || P.col(e.tx, e.ty, e.rt))) add(e.tx, e.ty, 'lift', 6, e.li);
      const ce = W.chE[y * W.w + x]; if (ce) for (const e of ce) if (P.st(e.tx, e.ty)) add(e.tx, e.ty, 'chain', 7, e.ci);
    }
    if (isRope) {
      if (P.rp(x, y - 1)) add(x, y - 1, 'climb', 1);
      if (P.rp(x, y + 1)) add(x, y + 1, 'cdown', 1);
      for (let dy = -1; dy <= 1; dy++) for (const dx of [-2, -1, 1, 2]) { const tx = x + dx, ty = y + dy; if (P.st(tx, ty) && P.row(ty, x, tx) && ropeHopOK(W, x, y, tx, ty)) add(tx, ty, 'roff', 1.6); }
      if (!P.rp(x, y - 1) && P.op(x, y - 1)) for (let ty = y - 2; ty <= y - 1; ty++) for (let dx = -2; dx <= 2; dx++) { const tx = x + dx; if (P.st(tx, ty) && P.op(x, ty) && P.row(ty, x, tx)) add(tx, ty, 'rtop', 2); }
    }
  }
  // Dijkstra; goal(x,y) → bool. Rows limited to [yMin, yMax].
  function findPath(W, sx, sy, goal, hyp, yMin, yMax) {
    const P = mkP(W, hyp), w = W.w, N = w * W.h;
    let x0 = sx, y0 = sy;
    while (y0 < W.h - 1 && P.op(x0, y0) && !P.st(x0, y0) && !P.rp(x0, y0)) y0++;
    if (!P.st(x0, y0) && !P.rp(x0, y0)) return null;
    const dist = new Float64Array(N).fill(1e9), prev = new Int32Array(N).fill(-1), et = new Array(N), ee = new Int16Array(N);
    const heap = []; const push = (i, d) => { heap.push([d, i]); let k = heap.length - 1; while (k > 0) { const p = (k - 1) >> 1; if (heap[p][0] <= heap[k][0]) break; const t = heap[p]; heap[p] = heap[k]; heap[k] = t; k = p; } };
    const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let k = 0; for (;;) { const l = 2 * k + 1, r = l + 1; let m = k; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === k) break; const t = heap[m]; heap[m] = heap[k]; heap[k] = t; k = m; } } return top; };
    const s0 = y0 * w + x0; dist[s0] = 0; push(s0, 0);
    const jf = W.jf; // hops that failed for real (learned this level)
    let found = -1, steps = 0;
    while (heap.length && steps < 4000) {
      const [d, u] = pop(); steps++;
      if (d > dist[u]) continue;
      const ux = u % w, uy = (u / w) | 0;
      if (goal(ux, uy)) { found = u; break; }
      edges(W, P, ux, uy, hyp, (nx, ny, t, c, e) => {
        if (ny < yMin || ny > yMax) return;
        if (jf) { const f = jf[u * N + ny * w + nx]; if (f) { if (f >= 3 && !hyp.nb) return; c += f * 2.5; } }
        const v = ny * w + nx, nd = d + c;
        if (nd < dist[v]) { dist[v] = nd; prev[v] = u; et[v] = t; ee[v] = e || 0; push(v, nd); }
      });
    }
    if (found < 0) return jf && W.jfN && !hyp.nb ? findPath(W, sx, sy, goal, Object.assign({}, hyp, { nb: 1 }), yMin, yMax) : null;
    const path = []; let u = found;
    while (u >= 0) { path.push({ x: u % w, y: (u / w) | 0, t: et[u] || 's', e: ee[u] }); if (u === s0) break; u = prev[u]; }
    path.reverse();
    return { path, cost: dist[found] };
  }
  const exitGoal = (W, cy) => (x, y) => W.T[y * W.w + x] === 'E' || y <= cy - 18;
  function needFor(W, i, c) {
    const yMin = Math.max(0, c.y - 30), yMax = Math.min(W.h - 1, c.y + 10);
    const g0 = exitGoal(W, c.y);
    let r = findPath(W, c.x, c.y, g0, {}, yMin, yMax);
    if (r) return { k: 'ok', path: r.path, cost: r.cost };
    const cand = W.gids.filter((g) => !W.go[g] && W.grow[g] >= c.y - 22 && W.grow[g] <= c.y + 10 && !(W.gk[g] === 'k' && W.keys.every((k) => k.g !== g || k.u)));
    cand.sort((a, b) => Math.abs(W.grow[a] - c.y) - Math.abs(W.grow[b] - c.y));
    const allG = {}; cand.forEach((g) => { allG[g] = 1; });
    const hv = W.cr.some((k) => k.hv);
    // a plate nobody here can reach yet (e.g. only via a shoulder boost) → look further along the path
    const rch = {};
    const plateOk = (g) => {
      if (W.gk[g] !== 'p') return true;
      if (rch[g] == null) { const tg = W.plates.filter((pl) => pl.g === g); rch[g] = !tg.length || W.plates.some((pl) => pl.g === g && pl.on) || W.ps.some((q) => !q.dead && !!pathTo(W, planCell(W, q), tg)); }
      return rch[g];
    };
    const firstNeed = (r) => {
      for (let a = 1; a < r.path.length; a++) {
        const nd = r.path[a], ii = nd.y * W.w + nd.x;
        const pv = r.path[a - 1];
        for (let yy = Math.min(pv.y, nd.y); yy <= Math.max(pv.y, nd.y); yy++) for (let xx = Math.min(pv.x, nd.x); xx <= Math.max(pv.x, nd.x); xx++) {
          const kk = yy * W.w + xx;
          for (const gg of [W.dg[kk], W.qg[kk]]) if (gg != null && !W.go[gg]) return plateOk(gg) ? { k: 'g', g: gg } : { k: 'skip', g: gg };
        }
        const ci = W.crc[ii]; if (ci !== undefined && W.cr[ci].hv) return { k: 'push' };
        if (nd.t === 'boost') { const b = r.path[a - 1]; return { k: 'boost', bx: b.x, by: b.y }; }
      }
      return null;
    };
    const duo = W.ps.filter((q) => !q.dead).length >= 2;
    for (let it = 0; it < 4; it++) {
      r = findPath(W, c.x, c.y, g0, { g: allG, ns: hv ? 1 : 0 }, yMin, yMax);
      if (!r && duo) r = findPath(W, c.x, c.y, g0, { g: allG, ns: hv ? 1 : 0, boost: 1 }, yMin, yMax);
      if (!r) break;
      const f = firstNeed(r);
      if (f && f.k === 'skip') { delete allG[f.g]; continue; }
      if (f) return Object.assign(f, { path: r.path, cost: r.cost });
      break;
    }
    return { k: 'none' };
  }
  function pathTo(W, c, targets, hyp) {
    const set = {}; targets.forEach((t) => { set[t.y * W.w + t.x] = 1; });
    const ys = targets.map((t) => t.y);
    const yMin = Math.max(0, Math.min(c.y, ...ys) - 6), yMax = Math.min(W.h - 1, Math.max(c.y, ...ys) + 8);
    return findPath(W, c.x, c.y, (x, y) => !!set[y * W.w + x], hyp || {}, yMin, yMax);
  }

  /* ======================= AI director + controller ======================= */
  function aiInit(W) {
    W.mem = W.ps.map(() => ({ path: null, pi: 0, task: null, stuck: 0, best: 1e9, rt: 0, jq: 0, hj: 0, react: 0, ride: 0, need: null, wait: 0, tpT: 0, lx: 0, ly: 0 }));
    W.dirT = 0; W.dirI = 0;
  }
  // humans: array of seat flags (1 = human)
  function director(W, hu, lvs, dt) {
    W.simN = 0;
    W.dirT -= dt; if (W.dirT > 0) return; W.dirT = 0.12;
    const n = W.ps.length;
    W.crc = {}; W.cr.forEach((k, ci) => { W.crc[Math.round(k.y) * W.w + Math.round(k.x)] = ci; });
    // one player per tick
    const i = W.dirI % n; W.dirI++;
    const p = W.ps[i], m = W.mem[i];
    if (p.dead) { m.need = null; m.path = null; m.task = null; return; }
    if (!p.gr && !p.rp && m.path) return; // plan from solid footing
    const c = planCell(W, p);
    m.need = needFor(W, i, c); m.cell = c;
    if (m.need.path) { const gs = {}; if (m.need.k === 'g') gs[m.need.g] = 1; const pth = m.need.path; for (let a = 1; a < pth.length; a++) { const pv = pth[a - 1], nd = pth[a]; for (let yy = Math.min(pv.y, nd.y); yy <= Math.max(pv.y, nd.y); yy++) for (let xx = Math.min(pv.x, nd.x); xx <= Math.max(pv.x, nd.x); xx++) { const kk = yy * W.w + xx; if (W.dg[kk] != null) gs[W.dg[kk]] = 1; if (W.qg[kk] != null) gs[W.qg[kk]] = 1; } } m.need.gs = gs; }
    // tasks for all AIs, using the latest needs
    assignTasks(W, hu, lvs);
    // path for this player
    if (!hu[i]) {
      const t = m.task;
      let r = null;
      if (t) r = pathTo(W, c, t.tg, t.hyp);
      if (t && !r) m.task = null;
      if (!t || !r) r = m.need && m.need.path ? { path: m.need.path, cost: m.need.cost } : null;
      setPath(m, r);
    }
  }
  function setPath(m, r) {
    if (!r) { m.path = null; return; }
    const key = r.path.length ? r.path[r.path.length - 1].x + ',' + r.path[r.path.length - 1].y : '';
    if (key !== m.goalKey) { m.goalKey = key; m.best = 1e9; m.stuck = 0; }
    if (r.cost < m.best - 0.4) { m.best = r.cost; m.stuck = 0; }
    m.path = r.path; m.pi = 0;
  }
  function assignTasks(W, hu, lvs) {
    const n = W.ps.length, M = W.mem;
    const ais = []; for (let i = 0; i < n; i++) if (!hu[i] && !W.ps[i].dead) ais.push(i);
    const old = M.map((m) => m.task);
    M.forEach((m, i) => { if (!hu[i]) m.task = null; });
    const busy = {};
    const near = (cands, tg, hyp) => {
      let best = null;
      for (const j of cands) {
        if (busy[j]) continue; const m = M[j];
        const c = planCell(W, W.ps[j]); // airborne: the planner drops to where we'd land
        // keep the previous holder when possible
        const prevSame = old[j] && old[j].tg && old[j].tg[0] && tg.some((t) => t.x === old[j].tg[0].x && t.y === old[j].tg[0].y);
        const d = Math.abs(c.x - tg[0].x) + Math.abs(c.y - tg[0].y) * 1.5 - (prevSame ? 6 : 0);
        if (best && d >= best.d) continue;
        const r = pathTo(W, c, tg, hyp); if (!r) continue;
        best = { j, d };
      }
      return best ? best.j : -1;
    };
    // group needs
    const needers = {};
    for (let i = 0; i < n; i++) { const nd = M[i].need; if (nd && nd.k === 'g' && !W.ps[i].dead) (needers[nd.g] = needers[nd.g] || []).push(i); }
    W.hold = W.hold || {};
    for (const g of W.gids) {
      if (W.gk[g] !== 'p') continue;
      const deps = []; for (let i = 0; i < n; i++) { const nd = M[i].need; if (!W.ps[i].dead && nd && nd.gs && nd.gs[g]) deps.push(i); }
      const others = (q) => deps.some((x) => x !== q);
      let j = W.hold[g];
      if (W.solo) { if (W.go[g] || !deps.length) { W.hold[g] = -1; continue; } }
      else if (!deps.length || (j >= 0 ? !others(j) : false)) { W.hold[g] = -1; continue; }
      // a human or a stone already holds it
      if (!(j >= 0) && W.plates.some((pl) => pl.g === g && pl.on)) continue;
      const tg = W.plates.filter((pl) => pl.g === g).map((pl) => ({ x: pl.x, y: pl.y }));
      if (!tg.length) continue;
      if (!(j >= 0 && !hu[j] && !W.ps[j].dead && !busy[j])) {
        let cands = (W.solo ? ais : ais.filter((q) => others(q))).filter((q) => !W.ps[q].rp);
        const free = cands.filter((q) => deps.indexOf(q) < 0);
        if (free.length) cands = free;
        j = near(cands, tg);
      }
      W.hold[g] = j;
      if (j >= 0) { M[j].task = { k: 'hold', g, tg }; busy[j] = 1; }
    }
    for (const gs in needers) {
      const g = +gs, ns = needers[g], kind = W.gk[g];
      if (W.go[g]) continue;
      if (kind === 'p') {
      } else if (kind === 'l') {
        const nx = (W.sq[g] || 0) + 1; const lv = W.levers.find((o) => o.g === g && o.i === nx); if (!lv) continue;
        const tg = [{ x: lv.x, y: lv.y }];
        const j = near(ais, tg);
        if (j >= 0) { M[j].task = { k: 'lever', g, tg, li: W.levers.indexOf(lv) }; busy[j] = 1; }
      } else if (kind === 'k') {
        const key = W.keys.find((k) => k.g === g && !k.u); if (!key) continue;
        if (key.h >= 0) {
          if (!hu[key.h] && !busy[key.h]) {
            const tg = []; W.locks.filter((l) => l.g === g).forEach((l) => { for (const [dx, dy] of [[-1, 0], [1, 0], [0, 1], [0, -1], [-1, 1], [1, 1]]) tg.push({ x: l.x + dx, y: l.y + dy }); });
            M[key.h].task = { k: 'lock', g, tg }; busy[key.h] = 1;
          }
        } else {
          const tg = [{ x: key.sx, y: key.sy }];
          const j = near(ais, tg);
          if (j >= 0) { M[j].task = { k: 'key', g, tg }; busy[j] = 1; }
        }
      }
    }
    // keys picked up by an AI with nothing else to do → bring it to the lock anyway
    W.keys.forEach((k) => {
      if (k.u || k.h < 0 || hu[k.h] || busy[k.h]) return;
      const tg = []; W.locks.filter((l) => l.g === k.g).forEach((l) => { for (const [dx, dy] of [[-1, 0], [1, 0], [0, 1], [0, -1], [-1, 1], [1, 1]]) tg.push({ x: l.x + dx, y: l.y + dy }); });
      if (tg.length) { M[k.h].task = { k: 'lock', g: k.g, tg }; busy[k.h] = 1; }
    });
    // boost needs
    const rid = {};
    for (let i = 0; i < n; i++) {
      const nd = M[i].need; if (!nd || nd.k !== 'boost' || W.ps[i].dead || (busy[i] && !hu[i])) continue;
      const tg = [{ x: nd.bx, y: nd.by }];
      const j = near(ais.filter((a) => a !== i && !rid[a] && planCell(W, W.ps[a]).y >= nd.by - 1), tg);
      if (j >= 0) { M[j].task = { k: 'boost', tg, rider: i }; busy[j] = 1; rid[i] = 1; }
    }
    // push needs (heavy stones): every AI that needs it, plus helpers for humans pushing
    const slots = {};
    const pushTask = (j, k, d) => {
      const kx = Math.round(k.x), ky = Math.round(k.y), ci = W.cr.indexOf(k);
      const sl = slots[ci] = (slots[ci] || 0) + 1;
      const tg = [{ x: kx - d * sl, y: ky }];
      M[j].task = { k: 'push', d, tg, ci }; busy[j] = 1;
    };
    for (let i = 0; i < n; i++) {
      const nd = M[i].need; if (!nd || nd.k !== 'push' || W.ps[i].dead) continue;
      let hit = null, d = 1;
      for (let a = 1; a < nd.path.length && !hit; a++) { const nn = nd.path[a]; const ci = W.crc[nn.y * W.w + nn.x]; if (ci !== undefined && W.cr[ci].hv) { hit = W.cr[ci]; d = Math.sign(nn.x - nd.path[a - 1].x) || 1; } }
      if (!hit) continue;
      if (!hu[i] && !busy[i]) pushTask(i, hit, d);
      // a partner joins
      const helpers = ais.filter((j) => !busy[j] && (lvs[j] || 2) >= 1);
      const j = near(helpers, [{ x: Math.round(hit.x) - d * 2, y: Math.round(hit.y) }]);
      if (j >= 0) pushTask(j, hit, d);
    }
    // a new job: drop the old route now (it may lead away), the planner gives a fresh one next
    const tk = (t) => (t ? t.k + (t.tg && t.tg[0] ? ':' + t.tg[0].x + ',' + t.tg[0].y : '') : '');
    for (const j of ais) if (tk(old[j]) !== tk(M[j].task) && M[j].task) { M[j].path = null; M[j].pi = 0; M[j].jq = 0; W.dirT = 0; W.dirI = j; }
  }
  function aiControl(W, i, lv, hu, dt) {
    const p = W.ps[i], m = W.mem[i], inp = p.in;
    inp.l = inp.r = inp.j = inp.a = inp.d = 0;
    if (p.dead) { m.stuck = 0; return; }
    const press = () => { if (!m.jq && m.hj <= 0) { markHop(W, m); m.jq = 1; m.react = lv === 1 ? 0.03 : 0.02; } };
    let dir = 0, hold = false, climb = false, down = false, act = false, waiting = false; m.gw = 0;
    const cx = p.x + PW / 2;
    // momentum-aware: aim with the position we'd coast to (air drag is weak, so brake early)
    const steer = (tx, dz) => { const dc = p.gr ? DEC_G : 6, br = p.gr ? ACC_G : ACC_A; const coast = p.vx * Math.abs(p.vx) / (2 * dc); const d = tx - cx, dp = tx - (cx + (p.gr ? coast : p.vx * Math.abs(p.vx) / (2 * br))); if (Math.abs(d) < (dz || 0.12) && Math.abs(dp) < (dz || 0.12) + 0.05) return 0; return dp > 0 ? 1 : -1; };
    const cell = planCell(W, p);
    // someone standing on my head?
    let rider = -1; for (let j = 0; j < W.ps.length; j++) if (j !== i && !W.ps[j].dead && W.ps[j].on === i && W.ps[j].gr) rider = j;
    if (rider >= 0) m.ride += dt; else m.ride = 0;
    if (p.gr) { m.lg = W.t; m.flung = 0; if (m.cj && p.vy >= 0) m.cj = 0; }
    // learn from hops that did not land where planned (the planner avoids them afterwards)
    if (m.hop) {
      if (!p.gr && !p.rp) m.hop.air = 1;
      else if (m.hop.air) {
        const hb = m.hop.b;
        if (cell.y > hb.y) { W.jf = W.jf || {}; W.jf[m.hop.k] = (W.jf[m.hop.k] || 0) + 1; W.jfN = (W.jfN || 0) + 1; }
        m.hop = null;
      }
      if (m.hop && W.t - m.hop.t > 2.5) m.hop = null;
    }
    const path = m.path;
    const atEnd = !path || path.length < 2 || m.pi >= path.length - 1;
    // humans ahead? follow, don't run away
    let hTop = Infinity; for (let j = 0; j < W.ps.length; j++) if (hu[j] && !W.ps[j].dead) hTop = Math.min(hTop, W.ps[j].y);
    let lowY = -Infinity; for (let j = 0; j < W.ps.length; j++) if (j !== i && !W.ps[j].dead && !W.ps[j].ex) lowY = Math.max(lowY, W.ps[j].y);
    if (p.cn < 0 && (p.gr || p.rp)) {
      for (let k = m.pi; k < Math.min(path ? path.length : 0, m.pi + 8); k++) if (path[k].x === cell.x && path[k].y === cell.y) { m.pi = k; break; }
    }
    // knocked off the planned route (missed hop, bumped): replan right away from here
    if (path && path[m.pi] && (p.gr || p.rp) && p.cn < 0 && p.on < 0 && (path[m.pi].x !== cell.x || path[m.pi].y < cell.y || path[m.pi].y > cell.y + 3)) {
      m.off = (m.off || 0) + dt;
      if (m.off > 0.18) { m.off = 0; m.path = null; m.pi = 0; W.dirT = 0; W.dirI = i; inp.l = inp.r = 0; return; }
    } else if (p.gr || p.rp) m.off = 0;
    const a = path && path[m.pi], b = path && path[m.pi + 1];
    if (m.task && atEnd && m.task.tg.some((t) => t.x === cell.x && t.y === cell.y)) {
      // at task target
      waiting = true;
      const tk = m.task;
      dir = steer(cell.x + 0.5, 0.18);
      if (tk.k === 'lever') { const lvr = W.levers[tk.li]; if (lvr && !lvr.on && p.gr && !m.lp) { act = true; m.lp = 1; } else m.lp = 0; }
      if (tk.k === 'push') { dir = tk.d; waiting = true; }
      if (tk.k === 'boost' && rider >= 0 && m.ride > (lv === 3 ? 0.2 : lv === 2 ? 0.4 : 0.8)) act = true;
      if (tk.k === 'hold' && rider >= 0 && m.ride > 0.6) act = true;
    } else if (p.ex && !m.task) {
      waiting = true; dir = 0;
    } else if (hTop < Infinity && !m.task && p.y < hTop - 8 && p.gr) {
      waiting = true; dir = 0;
    } else if (!m.task && p.gr && p.on < 0 && W.lava - (p.y + PH) > 6 && ((lowY > -Infinity && p.y < lowY - 6) || (b && leavesTeam(W, i, cell, b)))) {
      // stay with the team: a partner far below may need me on a plate / shoulder here
      waiting = true; dir = 0; m.gw = 1;
    } else if (b) {
      const tx = b.x + 0.5;
      const t = b.t;
      const blocked = !mkSolidFree(W, b.x, b.y) || gateShut(W, a, b);
      if (blocked) m.gw = 1;
      if (blocked && (t === 'walk' || t === 'fall' || t === 'jump' || t === 'rope' || t === 'climb' || t === 'cjump')) { waiting = true; if (p.gr || !p.rp) dir = steer(a.x + 0.5, 0.2); else climb = false; }
      else if (t === 'walk' || t === 'fall') { dir = steer(tx, 0.1); if (p.rp) { dir = steer(tx, 0.1); } }
      else if (t === 'jump' || t === 'rope') {
        if (p.rp) { if (b.y < cell.y) climb = true; else dir = steer(tx, 0.1); }
        else if (p.gr) {
          const dx = b.x - a.x, sgn = Math.sign(dx);
          if (dx === 0) { dir = steer(a.x + 0.5, 0.1); if (Math.abs(cx - (a.x + 0.5)) < 0.22 && Math.abs(p.vx) < 1.2) press(); }
          else {
            dir = sgn;
            const off = (cx - (a.x + 0.5)) * sgn, sp = p.vx * sgn;
            if (Math.abs(dx) >= 2 || b.y > a.y) {
              // long hops: full run-up, take off at the tested spot (centre or nearer the edge)
              const to = Math.max(0, hopOff(W, a.x, a.y, b.x, b.y, t === 'rope'));
              const rk = a.x + a.y * 100 + b.x * 1e4 + b.y * 1e6; if (m.ruK !== rk) { m.ruK = rk; m.ru = 0; }
              if (sp < RUN - 0.6 && off > to - 0.3 && !m.ru) dir = -sgn;
              if (off <= to - 0.3) m.ru = 1;
              if (m.ru && off < to - 0.03) dir = sgn;
              if (off > 1.6 || off < -1.2) dir = 0; // not at this hop's start: wait for a replan
              else if (off >= to - 0.03 && (sp >= RUN - 0.6 || off >= to + 0.12)) { press(); m.ru = 0; }
              else if (dir === -sgn && Math.abs(p.vx) < 0.05 && m.bk > 0.15) m.ru = 1;
              m.bk = dir === -sgn ? (m.bk || 0) + dt : 0;
            } else if (dx === 0 || Math.abs(off) < 0.15 || off > 0) { dir = steer(a.x + 0.5, 0.1); if (Math.abs(off) < 0.18 && Math.abs(p.vx) < 1.5) press(); }
          }
        } else if (m.ru && !m.jq && m.hj <= 0 && p.vy >= 0 && W.t - (m.lg || 0) < 0.08) {
          // ran past the edge for a far takeoff: jump in coyote time
          dir = Math.sign(b.x - a.x); press(); m.react = 0; m.ru = 0;
        } else {
          dir = steer(tx, 0.08); hold = b.y < a.y || t === 'rope';
          if (b.y < a.y && p.y + PH > b.y + 1.02 && Math.abs(tx - cx) > 0.3) dir = tx > cx ? 1 : -1;
          // still below the ledge: don't press into its side, rise first
          if (dir && b.y < a.y && p.y + PH > b.y + 1.02) {
            const nc = dir > 0 ? Math.floor(p.x + PW + 0.06) : Math.floor(p.x - 0.06);
            for (let r = Math.floor(p.y + 0.02); r <= Math.floor(p.y + PH - 0.05); r++) if (solidC(W, nc, r)) { dir = p.vy < 0 ? 0 : dir; break; }
          }
        }
      } else if (t === 'cjump') {
        const sg = Math.sign(b.x - a.x);
        if (p.gr && !m.cj) { dir = sg; m.cj = 0; }
        else if (!p.gr && !p.rp && !m.cj && p.vy >= 0) { m.cj = 1; dir = sg; m.react = 0; if (!m.jq && m.hj <= 0) { markHop(W, m); m.jq = 1; } }
        else { dir = steer(tx, 0.08); hold = true; }
      } else if (t === 'climb') { climb = true; }
      else if (t === 'cdown') { down = true; }
      else if (t === 'roff') {
        // climb to the top of this rope tile first (that's the hop the planner tested), then let go sideways
        if (p.rp && p.y + PH > a.y + 1.08 && isRope(W, a.x, Math.floor(p.y + 0.3 - 0.1))) { climb = true; dir = 0; }
        else if (p.rp) dir = steer(tx, 0.05) || (b.x > a.x ? 1 : -1); else dir = steer(tx, 0.08);
      }
      else if (t === 'rtop') { if (p.rp) climb = true; else { dir = steer(tx, 0.08); hold = true; } }
      else if (t === 'vent') { if (p.gr) { dir = steer(a.x + 0.5, 0.12); waiting = true; } else dir = steer(tx, 0.08); }
      else if (t === 'lift') {
        const lf = W.lifts[b.e]; const onL = p.on === 100 + b.e;
        if (onL) { if (Math.abs(lf.y - lf.y0) < 0.2) { dir = steer(tx, 0.1); if (b.y < lf.y0 - 1) press(); } else dir = steer(lf.x + 1, 0.15); waiting = true; }
        else if (p.gr && cell.y === lf.y1 - 1) { if (Math.abs(lf.y - lf.y1) < 0.25 && lf.dy <= 0.0001) dir = steer(lf.x + 1, 0.15); else { dir = steer(a.x + 0.5, 0.15); waiting = true; } }
        else if (!p.gr) dir = steer(tx, 0.1);
        else dir = steer(tx, 0.1);
      } else if (t === 'boost') {
        let bst = -1; for (let j = 0; j < W.ps.length; j++) { const q = W.ps[j]; if (j !== i && !q.dead && q.gr && Math.abs(q.x - p.x) < 1.2 && Math.abs(q.y - p.y) < 0.4) bst = j; }
        if (p.on >= 0 && p.on < 100) { waiting = true; dir = 0; }
        else if (!p.gr) { dir = p.vy < 0 ? steer(tx, 0.08) : steer(tx, 0.08); hold = true; }
        else if (bst >= 0) { const bx = W.ps[bst].x + PW / 2; dir = steer(bx, 0.15); if (Math.abs(bx - cx) < 0.35) press(); waiting = true; }
        else { waiting = true; dir = steer(a.x + 0.5, 0.2); }
      } else if (t === 'chain') {
        const c = W.chains[b.e];
        if (p.cn >= 0) {
          const e = chainEnd(c, W.t); const vx = c.L * Math.cos(e.a) * e.av, sg = Math.sign(tx - e.x);
          if (Math.sign(vx) === sg && (e.x - c.ax) * sg > 1.0 && Math.abs(vx) > 2.0) { press(); m.flung = 1; }
          waiting = true;
        } else if (p.gr) {
          const e = chainEnd(c, W.t);
          dir = steer(a.x + 0.5, 0.15);
          if (Math.hypot(e.x - cx, e.y - (p.y + 0.3)) < 2.0 && Math.abs(e.x - cx) < 1.6) { press(); dir = steer(e.x, 0.1); }
          waiting = true;
        } else { const e = chainEnd(c, W.t); dir = steer(m.flung ? tx : e.x, 0.08); hold = true; }
      }
    } else waiting = true;
    // throw a rider who climbed on me while I'm idle
    if (rider >= 0 && waiting && m.ride > 0.9) act = true;
    // airborne: don't drift under a ceiling while still rising past it
    if (dir && !p.gr && !p.rp && p.cn < 0 && p.vy < 2) {
      const nc = dir > 0 ? Math.floor(p.x + PW + 0.08) : Math.floor(p.x - 0.08);
      const r0 = Math.floor(p.y - 0.35), r1 = Math.floor(p.y + PH - 0.05);
      for (let r = r0; r <= r1; r++) if (solidC(W, nc, r) && r <= Math.floor(p.y + 0.1)) { dir = 0; break; }
    }
    // lv1: stutter
    // lv1: hesitates before each new move and dawdles on plain walks (but never mid-hop)
    if (lv === 1) {
      if (m.hk !== m.pi + ':' + (m.goalKey || '')) { m.hk = m.pi + ':' + (m.goalKey || ''); m.hes = p.gr && b && b.t !== 'walk' ? 0.12 + Math.random() * 0.3 : 0; }
      if (m.hes > 0 && p.gr && !m.jq && !m.ru) { m.hes -= dt; dir = 0; }
      else if (dir && p.gr && !m.ru && b && b.t === 'walk' && Math.random() < 0.12) dir = 0;
    }
    // jump queue: release one frame then press
    if (m.jq) {
      if (m.react > 0) { m.react -= dt; }
      else if (p.jp) { inp.j = 0; }
      else { inp.j = 1; m.jq = 0; m.hj = 0.42; }
    } else if (m.hj > 0) { m.hj -= dt; inp.j = 1; if (!p.gr && p.vy > 0) m.hj = 0; if (b && b.t === 'jump' && b.y > a.y && m.hj < 0.3) m.hj = 0; }
    if (hold && !p.gr && p.vy < 0) inp.j = 1;
    // already above the ledge we aim for: let go of jump so we don't sail through one-way floors
    if (b && a && !p.gr && !p.rp && p.cn < 0 && p.vy < 0 && b.y < a.y && (b.t === 'jump' || b.t === 'cjump') && ((p.y + PH < b.y + 1 - 0.25 && Math.abs(b.x + 0.5 - cx) < 0.45) || (p.y + PH < b.y + 1 - 0.6 && Math.abs(b.x + 0.5 - cx) < 1.3))) { inp.j = 0; m.hj = 0; }
    if (climb) inp.j = 1;
    inp.d = down ? 1 : 0;
    inp.l = dir < 0 ? 1 : 0; inp.r = dir > 0 ? 1 : 0;
    if (act && !p.ap) inp.a = 1;
    // stuck detection → catch up
    if ((p.gr || p.rp) && cell.y < (m.bestY == null ? 1e9 : m.bestY)) { m.bestY = cell.y; m.stuck = 0; }
    // progress = standing somewhere new (not just bouncing between the same tiles)
    if (p.gr || p.rp) { const vk = cell.y * W.w + cell.x, vs = m.vis || (m.vis = {}); if (!(W.t - (vs[vk] || -99) < 8)) m.stuck = Math.max(0, m.stuck - 1.5); vs[vk] = W.t; }
    if (waiting) m.stuck = Math.max(0, m.stuck - dt * 0.5); else m.stuck += dt;
    m.wait = waiting ? m.wait + dt : 0;
    const lim = lv === 1 ? 12 : 10; // last resort only
    let far = false;
    if (hTop < Infinity && p.y > hTop + 13) { m.tpT += dt; far = m.tpT > 2; } else m.tpT = 0;
    if (m.stuck > lim || far || (m.wait > 20 && !m.task && !m.gw && !p.ex)) { teleportAI(W, i, hu); m.stuck = 0; m.wait = 0; m.tpT = 0; }
  }
  // a closed door / missing rope anywhere on the hop (planner may assume it opens)
  function gateShut(W, a, b) {
    for (let yy = Math.min(a.y, b.y); yy <= Math.max(a.y, b.y); yy++) for (let xx = Math.min(a.x, b.x); xx <= Math.max(a.x, b.x); xx++) {
      const kk = yy * W.w + xx;
      if (W.dg[kk] != null && !W.go[W.dg[kk]]) return true;
      if (W.qg[kk] != null && !W.go[W.qg[kk]] && (b.t === 'rope' || b.t === 'climb')) return true;
    }
    return false;
  }
  // about to climb into the next section while a partner is still well below in this one (or lower)
  function leavesTeam(W, i, cell, b) {
    const sec = (y) => (y < EXIT.length ? -1 : Math.floor((y - EXIT.length) / CH)); // sections top→bottom
    const mine = sec(cell.y), nx = sec(b.y);
    if (nx >= mine) return false;
    for (let j = 0; j < W.ps.length; j++) {
      const q = W.ps[j]; if (j === i || q.dead || q.ex) continue;
      const qc = planCell(W, q);
      if (sec(qc.y) < mine) continue;
      if (qc.y > cell.y + 3) return true;
      // close by, but can they actually follow me up from where they stand (doors as they are now)?
      const m = W.mem[i]; const ck = j * 1e6 + qc.y * 1000 + qc.x * 30 + b.y;
      if (m.ltK !== ck || W.t - m.ltT > 0.5) { m.ltK = ck; m.ltT = W.t; const cl = {};
        for (const g of W.gids) if (W.gk[g] === 'p' && W.go[g]) { const on = W.plates.filter((pl) => pl.g === g && pl.on); if (on.length && on.every((pl) => Math.abs(q.x + PW / 2 - (pl.x + 0.5)) < 0.9 && Math.abs(q.y + PH - (pl.y + 1)) < 0.3)) cl[g] = 1; }
        m.ltV = !pathTo(W, qc, [{ x: b.x, y: b.y }], { cl }); }
      if (m.ltV) return true;
    }
    return false;
  }
  function markHop(W, m) {
    const a = m.path && m.path[m.pi], b = m.path && m.path[m.pi + 1];
    if (!a || !b || !/^(jump|cjump|rope|roff|rtop)$/.test(b.t)) { m.hop = null; return; }
    const N = W.w * W.h;
    m.hop = { b, k: (a.y * W.w + a.x) * N + b.y * W.w + b.x, t: W.t, air: 0 };
  }
  function mkSolidFree(W, x, y) { return !solidC(W, x, y) && W.crc[y * W.w + x] === undefined; }
  function teleportAI(W, i, hu) {
    const p = W.ps[i], m = W.mem[i];
    let best = -1, by = p.y - 1.5;
    for (let j = 0; j < W.ps.length; j++) { const q = W.ps[j]; if (j === i || q.dead || !q.gr) continue; if (q.y < by) { by = q.y; best = j; } }
    let tx = null, ty = null;
    if (best >= 0 && (hu[best] || !m.path || m.path.length < 3)) { const q = W.ps[best]; tx = q.x; ty = q.y; }
    else if (m.path && m.path.length >= 2) {
      let k = m.pi;
      for (let s = 0; s < 4 && k + 1 < m.path.length; s++) { if (m.path[k + 1].t === 'boost' || gateShut(W, m.path[k], m.path[k + 1])) break; k++; }
      if (k === m.pi && best >= 0) { const q = W.ps[best]; tx = q.x; ty = q.y; }
      else if (k !== m.pi) { const nd = m.path[k]; tx = nd.x + 0.5 - PW / 2; ty = nd.y + 1 - PH; }
    } else if (best >= 0) { const q = W.ps[best]; tx = q.x; ty = q.y; }
    if (tx == null) return;
    ev(W, 'T', i, p.x + PW / 2, p.y + PH / 2);
    p.x = tx; p.y = ty; p.vx = 0; p.vy = 0; p.rp = 0; p.cn = -1; p.gr = 0; p.on = -1;
    m.path = null; m.pi = 0; m.bestY = null; W.stat.tp++;
    W.dirT = 0; W.dirI = i;
    ev(W, 'T', i, p.x + PW / 2, p.y + PH / 2);
  }

  /* ======================= snapshot (online) ======================= */
  const r1 = (v) => Math.round(v * 20);
  function encWorld(W) {
    const cb = []; for (const k in W.cb) cb.push(+k, Math.round(W.cb[k] * 10));
    const go = W.gids.filter((g) => W.go[g]);
    return {
      t: Math.round(W.t * 100), lv: Math.round(W.lava * 100), li: W.lives, cp: W.cp,
      p: W.ps.map((p) => [r1(p.x), r1(p.y), Math.round(p.vx * 10), Math.round(p.vy * 10), (p.dead ? 1 : 0) | (p.gr ? 2 : 0) | (p.rp ? 4 : 0) | (p.fc < 0 ? 8 : 0) | (p.key >= 0 ? 16 : 0) | (p.cn >= 0 ? 32 : 0) | (p.ex ? 64 : 0), p.on]),
      c: W.cr.map((k) => [r1(k.x), r1(k.y), k.mv || 0]), g: go, cb,
      lvr: W.levers.map((o) => (o.on ? 1 : 0)).join(''), k: W.keys.map((k) => [r1(k.x), r1(k.y), k.h, k.u]),
      pl: W.plates.map((o) => (o.on ? 1 : 0)).join(''), cl: Math.round(W.clr * 10), ev: W.evs.slice(),
    };
  }
  function decWorld(W, s, mine) {
    W.t = (s.t || 0) / 100; W.lava = (s.lv || 0) / 100; W.lives = s.li | 0; W.cp = s.cp | 0;
    (s.p || []).forEach((a, i) => {
      const p = W.ps[i]; if (!p || i === mine) return;
      p.tx = a[0] / 20; p.ty = a[1] / 20; p.vx = a[2] / 10; p.vy = a[3] / 10;
      p.dead = a[4] & 1; p.gr = a[4] & 2 ? 1 : 0; p.rp = a[4] & 4 ? 1 : 0; p.fc = a[4] & 8 ? -1 : 1; p.key = a[4] & 16 ? 0 : -1; p.cn = a[4] & 32 ? 0 : -1; p.ex = a[4] & 64 ? 1 : 0; p.on = a[5];
      if (p.x == null || Math.hypot(p.tx - p.x, p.ty - p.y) > 3) { p.x = p.tx; p.y = p.ty; }
    });
    (s.c || []).forEach((a, i) => { const k = W.cr[i]; if (k) { k.tx = a[0] / 20; k.ty = a[1] / 20; k.mv = a[2]; if (Math.hypot(k.tx - k.x, k.ty - k.y) > 2) { k.x = k.tx; k.y = k.ty; } } });
    W.gids.forEach((g) => { W.go[g] = 0; }); (s.g || []).forEach((g) => { W.go[g] = 1; });
    W.cb = {}; const cb = s.cb || []; for (let i = 0; i + 1 < cb.length; i += 2) W.cb[cb[i]] = cb[i + 1] / 10;
    const lvr = s.lvr || ''; W.levers.forEach((o, i) => { o.on = lvr[i] === '1' ? 1 : 0; });
    const pl = s.pl || ''; W.plates.forEach((o, i) => { o.on = pl[i] === '1' ? 1 : 0; });
    (s.k || []).forEach((a, i) => { const k = W.keys[i]; if (k) { k.x = a[0] / 20; k.y = a[1] / 20; k.h = a[2]; k.u = a[3]; } });
    W.clr = (s.cl || 0) / 10;
    for (const lf of W.lifts) { const ny = liftY(lf, W.t); lf.dy = ny - lf.y; lf.y = ny; }
  }

  /* ======================= coarse state ======================= */
  function init(players, opts) {
    const o = opts || {};
    const n = players.length;
    const mode = o.mode === 'deep' ? 'deep' : 'camp';
    return {
      rid: 1 + U.rand(99999), n, hu: players.map((p) => (p && !p.ai ? 1 : 0)), nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      ph: 'play', mode, sp: [0, 1, 2].includes(o.lava) ? o.lava : 1, lv: mode === 'deep' ? HAND.length : 0, sd: 1 + U.rand(2147480000),
      lives: Math.min(7, 3 + n), clr: 0, die: 0, why: '',
    };
  }
  function nextLevel(st, lives, die) {
    st.lv++; st.clr++; st.sd = 1 + U.rand(2147480000); st.lives = Math.min(9, lives + 1); st.die += die | 0; return st;
  }
  function endRun(st, die) { st.ph = 'done'; st.die += die | 0; st.lives = 0; return st; }
  // 첫 판 조작 안내(이 기기에서 한 번만, 탭하거나 4.5초 뒤 사라짐)
  function firstHint(root, api, id, lines) {
    if (!api.mySeats || !api.mySeats().length) return null;
    const k = 'lounge.hint.' + id;
    try { if (localStorage.getItem(k)) return null; localStorage.setItem(k, '1'); } catch (e) { return null; }
    const el = L.h('div', { style: 'position:absolute;left:50%;top:18%;transform:translateX(-50%);z-index:20;width:min(320px,calc(100% - 32px));box-sizing:border-box;background:rgba(14,10,20,.9);border:1.5px solid rgba(227,174,69,.6);border-radius:16px;padding:10px 14px;color:#f2e9d8;font:600 13px/1.5 "IBM Plex Sans KR",system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.6);cursor:pointer;min-height:44px;pointer-events:auto' },
      L.h('div', { style: 'font:400 17px "Black Han Sans",sans-serif;color:#e3ae45;margin-bottom:2px', text: '조작 방법' }),
      ...lines.map((t) => L.h('div', { text: '· ' + t })),
      L.h('div', { style: 'margin-top:4px;font-size:11px;opacity:.65;text-align:right', text: '탭해서 닫기' }));
    let tm = 0; const close = () => { clearTimeout(tm); el.remove(); };
    el.addEventListener('pointerdown', (e) => { e.stopPropagation(); close(); });
    tm = setTimeout(close, 4500); root.appendChild(el);
    return close;
  }
  function result(st) {
    if (!st || st.ph !== 'done') return null;
    const all = Array.from({ length: st.n }, (_, i) => i);
    const esc = st.lv >= HAND.length;
    const text = '도달: ' + lvName(st.lv) + '\n빠져나온 단계 ' + st.clr + '개 · 쓰러진 횟수 ' + st.die;
    const stats = [{ label: '도달한 곳', value: lvName(st.lv) }, { label: '빠져나온 단계', value: String(st.clr | 0) }, { label: '쓰러진 횟수(모두)', value: String(st.die | 0) }];
    if (st.why === 'demo') return { winners: all, title: 'AI 탐험대 시연 끝', text, stats };
    if (esc && st.mode === 'camp') return { winners: all, title: '동굴 탈출 성공! 🔥', text: text + '\n12단계를 모두 지나 깊은 곳까지 버텼어요', stats };
    return { winners: esc ? all : [], title: esc ? '깊은 곳에서 멈췄어요' : '용암에 삼켜졌어요', text, stats };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const CSS = `
  .lc-ui{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body)}
  .lc-b{position:absolute;pointer-events:auto;border-radius:50%;border:2px solid rgba(255,190,120,.32);color:#f2e9d8;display:flex;flex-direction:column;align-items:center;justify-content:center;
    font:700 12px var(--f-body);user-select:none;-webkit-user-select:none;touch-action:none;box-shadow:0 4px 12px rgba(0,0,0,.55);background:radial-gradient(circle at 40% 32%,rgba(92,60,52,.92),rgba(34,22,24,.92))}
  .lc-b b{font-size:22px;line-height:1;margin-bottom:1px}
  .lc-b.on{transform:scale(.93);border-color:#ffb36b;background:radial-gradient(circle at 40% 32%,rgba(170,86,40,.95),rgba(70,30,20,.95))}
  .lc-jump{background:radial-gradient(circle at 40% 32%,rgba(196,96,40,.95),rgba(88,34,18,.95))}
  .lc-pad{position:absolute;pointer-events:auto;touch-action:none;display:flex;gap:8px}
  .lc-pad .lc-b{position:relative}
  .lc-ov{position:absolute;inset:0;pointer-events:none;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 18px;box-sizing:border-box}
  .lc-card{background:rgba(18,10,12,.86);border:1.5px solid rgba(255,140,70,.45);border-radius:16px;padding:14px 16px;max-width:340px;box-shadow:0 10px 30px rgba(0,0,0,.6)}
  .lc-card h2{font:24px var(--f-display);color:#ffb35c;margin:0 0 6px}
  .lc-card p{margin:0;color:#e9dccb;font-size:14px;line-height:1.5}
  .lc-card .cd{font:700 30px var(--f-mono);color:#ffd9a0;margin-top:8px}
  `;

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const styleEl = L.h('style', { text: CSS }); root.appendChild(styleEl);
    const ui = L.h('div', { class: 'lc-ui' }); root.appendChild(ui);
    const hintOff = firstHint(root, api, 'lavacave', ['◀ ▶ 걷기 · ⤒ 점프(밧줄 오르기)', '✋ 액션: 레버 당기기 · 동료 던져 올리기', '모두 맨 위 푸른 출구에 모이면 통과!']);
    const pad = L.h('div', { class: 'lc-pad' });
    const bL = L.h('div', { class: 'lc-b' }); bL.innerHTML = '<b>◀</b>';
    const bR = L.h('div', { class: 'lc-b' }); bR.innerHTML = '<b>▶</b>';
    pad.appendChild(bL); pad.appendChild(bR);
    const bJ = L.h('div', { class: 'lc-b lc-jump' }); bJ.innerHTML = '<b>⤒</b>점프';
    const bA = L.h('div', { class: 'lc-b' }); bA.innerHTML = '<b>✋</b>액션';
    const ov = L.h('div', { class: 'lc-ov' });
    bL.dataset.action = 'L'; bR.dataset.action = 'R'; bJ.dataset.action = 'J'; bA.dataset.action = 'A';
    ui.appendChild(pad); ui.appendChild(bJ); ui.appendChild(bA); ui.appendChild(ov);

    let st = null, key = null, W = null, phase = 'wait', cd = 0, acc = 0, sentEnd = false, endT = 0;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const mySeat = () => { const m = api.mySeats ? api.mySeats() : []; return m.length ? m[0] : -1; };
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const huArr = () => (st ? st.hu : []);
    const lvArr = () => api.players.map((p) => (p && p.lv) || 2);

    /* ----- input ----- */
    const touch = { l: 0, r: 0, j: 0, a: 0 };
    const input = { l: 0, r: 0, j: 0, a: 0, d: 0 };
    const inp = api.input || null;
    let padPid = -1;
    const padSet = (e) => {
      const r = pad.getBoundingClientRect(); const x = e.clientX - r.left;
      touch.l = x < r.width / 2 ? 1 : 0; touch.r = x >= r.width / 2 ? 1 : 0;
      bL.classList.toggle('on', !!touch.l); bR.classList.toggle('on', !!touch.r);
    };
    const padDown = (e) => { e.preventDefault(); padPid = e.pointerId; try { pad.setPointerCapture(e.pointerId); } catch (er) {} padSet(e); api.buzz && api.buzz(6); };
    const padMove = (e) => { if (e.pointerId === padPid) padSet(e); };
    const padUp = (e) => { if (e.pointerId !== padPid) return; padPid = -1; touch.l = touch.r = 0; bL.classList.remove('on'); bR.classList.remove('on'); };
    pad.addEventListener('pointerdown', padDown); pad.addEventListener('pointermove', padMove);
    pad.addEventListener('pointerup', padUp); pad.addEventListener('pointercancel', padUp); pad.addEventListener('lostpointercapture', padUp);
    const btn = (el, k) => {
      const dn = (e) => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (er) {} touch[k] = 1; el.classList.add('on'); api.buzz && api.buzz(8); };
      const up = () => { touch[k] = 0; el.classList.remove('on'); };
      el.addEventListener('pointerdown', dn); el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up); el.addEventListener('lostpointercapture', up);
    };
    btn(bJ, 'j'); btn(bA, 'a');
    const noCtx = (e) => e.preventDefault(); root.addEventListener('contextmenu', noCtx);
    function refreshInput() {
      const h = (id) => { try { return inp && inp.held && inp.held(id); } catch (e) { return false; } };
      input.l = touch.l || h('L') ? 1 : 0; input.r = touch.r || h('R') ? 1 : 0;
      input.j = touch.j || h('J') ? 1 : 0; input.a = touch.a || h('A') ? 1 : 0; input.d = h('D') ? 1 : 0;
      if (inp && inp.axis) { try { const ax = inp.axis('L', 'R'); if (ax < -0.35) input.l = 1; if (ax > 0.35) input.r = 1; } catch (e) {} }
    }
    const releaseAll = () => { touch.l = touch.r = touch.j = touch.a = 0; [bL, bR, bJ, bA].forEach((b) => b.classList.remove('on')); };
    window.addEventListener('blur', releaseAll);

    /* ----- layout ----- */
    let ts = 24, ox = 0, camY = 0, camInit = false;
    function layout() {
      const w = cv.w, h = cv.h;
      ts = Math.min(w / GW, h / 15);
      ox = Math.round((w - ts * GW) / 2);
      const bs = Math.round(clamp(Math.min(w, h) * 0.17, 56, 76));
      const g = 12;
      pad.style.left = g + 'px'; pad.style.bottom = g + 'px';
      [bL, bR].forEach((b) => { b.style.width = bs + 'px'; b.style.height = bs + 'px'; });
      bJ.style.width = bJ.style.height = Math.round(bs * 1.12) + 'px'; bJ.style.right = g + 'px'; bJ.style.bottom = g + 'px';
      bA.style.width = bA.style.height = Math.round(bs * 0.88) + 'px'; bA.style.right = Math.round(g + bs * 1.12 + 10) + 'px'; bA.style.bottom = Math.round(g + bs * 0.35) + 'px';
      staticCv = null;
    }
    cv.onresize = layout;

    /* ----- static layer ----- */
    let staticCv = null, sScale = 1;
    function buildStatic() {
      if (!W) return;
      sScale = Math.min(Math.max(1, ts * Math.min(2, cv.dpr || 1)), 44);
      const c = document.createElement('canvas'); c.width = Math.ceil(GW * sScale); c.height = Math.ceil(W.h * sScale);
      const g = c.getContext('2d'); const s = sScale; const R = rng(W.lv * 977 + 13);
      // back wall
      const bg = g.createLinearGradient(0, 0, 0, c.height);
      bg.addColorStop(0, '#20202a'); bg.addColorStop(0.12, '#17121a'); bg.addColorStop(1, '#100a0b');
      g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height);
      for (let k = 0; k < W.h * 2; k++) { const v = 22 + R() * 14 | 0; g.fillStyle = 'rgba(' + (v + 6) + ',' + v + ',' + (v - 2) + ',' + (0.18 + R() * 0.22) + ')'; const rx = R() * c.width, ry = R() * c.height, rr = s * (0.5 + R() * 1.6); g.beginPath(); g.ellipse(rx, ry, rr * 1.5, rr * 0.8, R() * 0.6 - 0.3, 0, 6.29); g.fill(); }
      g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = Math.max(1, s * 0.04);
      for (let k = 0; k < W.h; k++) { const yy = R() * c.height; g.beginPath(); g.moveTo(0, yy); for (let xx = 0; xx <= c.width; xx += s) g.lineTo(xx, yy + (R() - 0.5) * s * 0.5); g.stroke(); }
      for (let y = 0; y < W.h; y++) for (let x = 0; x < W.w; x++) {
        const t = W.T[y * W.w + x], X = x * s, Y = y * s;
        if (t === '#' || (t === '^' && W.solo)) {
          const sh = 30 + ((x * 7 + y * 13) % 9);
          g.fillStyle = t === '^' ? '#4a3a33' : 'rgb(' + (sh + 14) + ',' + (sh + 2) + ',' + (sh) + ')';
          g.fillRect(X, Y, s + 0.5, s + 0.5);
          g.fillStyle = 'rgba(0,0,0,.18)'; for (let k = 0; k < 2; k++) { g.fillRect(X + R() * s * 0.8, Y + R() * s * 0.8, s * (0.15 + R() * 0.25), Math.max(1, s * 0.04)); }
          g.fillStyle = 'rgba(255,255,255,.025)'; g.fillRect(X + R() * s * 0.5, Y + R() * s * 0.5, s * 0.45, s * 0.35);
          const open = (xx, yy) => { const tt = (xx < 0 || xx >= W.w || yy < 0 || yy >= W.h) ? '#' : W.T[yy * W.w + xx]; return !(tt === '#' || (tt === '^' && W.solo) || tt === 'v'); };
          if (open(x, y - 1)) { g.fillStyle = '#6b5246'; g.fillRect(X, Y, s + 0.5, s * 0.12); g.fillStyle = 'rgba(255,150,80,.25)'; g.fillRect(X, Y, s + 0.5, s * 0.04); }
          if (open(x, y + 1)) { g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(X, Y + s * 0.85, s + 0.5, s * 0.15); }
          if (open(x - 1, y)) { g.fillStyle = 'rgba(255,255,255,.04)'; g.fillRect(X, Y, s * 0.08, s); }
          if (open(x + 1, y)) { g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(X + s * 0.9, Y, s * 0.1, s); }
          if (t === '^') { g.strokeStyle = 'rgba(255,200,140,.35)'; g.lineWidth = s * 0.05; g.strokeRect(X + s * 0.1, Y + s * 0.1, s * 0.8, s * 0.8); }
        } else if (t === '=') {
          g.fillStyle = '#5a463d'; g.fillRect(X, Y, s + 0.5, s * 0.26);
          g.fillStyle = '#7c6152'; g.fillRect(X, Y, s + 0.5, s * 0.07);
          g.fillStyle = '#3a2c27'; g.beginPath(); g.moveTo(X + s * 0.15, Y + s * 0.26); g.lineTo(X + s * 0.3, Y + s * 0.48); g.lineTo(X + s * 0.45, Y + s * 0.26); g.moveTo(X + s * 0.6, Y + s * 0.26); g.lineTo(X + s * 0.72, Y + s * 0.4); g.lineTo(X + s * 0.85, Y + s * 0.26); g.fill();
        } else if (t === 'v') {
          g.fillStyle = '#3b2c28'; g.fillRect(X, Y, s + 0.5, s + 0.5);
          g.fillStyle = '#1a0f0c'; g.fillRect(X + s * 0.2, Y, s * 0.6, s * 0.25);
          g.fillStyle = 'rgba(255,120,40,.5)'; g.fillRect(X + s * 0.28, Y + s * 0.05, s * 0.44, s * 0.1);
        } else if (t === 'R') {
          ropeDraw(g, X + s / 2, Y, s);
        } else if (t === 'E') {
          g.fillStyle = 'rgba(150,190,230,' + (0.05 + (3 - (y % 4)) * 0.03) + ')'; g.fillRect(X, Y, s + 0.5, s + 0.5);
        }
      }
      // exit glow
      const eg = g.createLinearGradient(0, 0, 0, s * 5); eg.addColorStop(0, 'rgba(190,220,255,.45)'); eg.addColorStop(1, 'rgba(190,220,255,0)');
      g.fillStyle = eg; g.fillRect(s, 0, (GW - 2) * s, s * 5);
      staticCv = c;
    }
    function ropeDraw(g, x, y, s) {
      g.strokeStyle = '#a58457'; g.lineWidth = Math.max(1.5, s * 0.1);
      g.beginPath(); g.moveTo(x, y); g.lineTo(x, y + s + 0.5); g.stroke();
      g.strokeStyle = 'rgba(60,40,20,.6)'; g.lineWidth = Math.max(1, s * 0.05);
      for (let k = 0; k < 3; k++) { const yy = y + s * (0.15 + k * 0.33); g.beginPath(); g.moveTo(x - s * 0.06, yy); g.lineTo(x + s * 0.06, yy + s * 0.1); g.stroke(); }
    }

    /* ----- particles / fx ----- */
    const parts = [], floats = [], seenEv = {};
    let shake = 0, hintT = 0, hintTx = '';
    const sfx = (n) => { try { api.sfx(n); } catch (e) {} };
    function burst(x, y, col, nn, sp, life) { for (let k = 0; k < nn; k++) { const a = Math.random() * 6.28, v = (0.4 + Math.random()) * (sp || 3); if (parts.length > 220) parts.shift(); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 1, t: (life || 0.6) * (0.6 + Math.random() * 0.6), c: col, g: 1 }); } }
    function float(text, col, t) { floats.push({ text, col: col || '#f2e9d8', t: t || 1.6, T: t || 1.6 }); if (floats.length > 3) floats.shift(); }
    function onEvent(type, s, x, y) {
      const ms = mySeat(), mine = s === ms, nm = s >= 0 ? roleName(s) : '';
      if (type === 'd') { sfx('hit'); shake = Math.max(shake, mine ? 0.5 : 0.2); burst(x, y, '#ff7a2a', 18, 4, 0.8); if (mine) { api.buzz && api.buzz(140); float('용암에 빠졌어요! 체크포인트에서 다시', '#ff8a5a', 2); } else float(nm + ' 쓰러짐!', '#ff8a5a', 1.4); }
      else if (type === 'r') { sfx('pop'); burst(x, y, '#ffd28a', 12, 2.5, 0.6); }
      else if (type === 't') { sfx('whoosh'); burst(x, y + 0.9, '#f2e9d8', 8, 2, 0.4); if (mine) { api.buzz && api.buzz(30); } }
      else if (type === 'l') { sfx('click'); burst(x, y, '#ffd28a', 8, 2, 0.4); }
      else if (type === 'w') { sfx('thud'); float('순서가 틀렸어요! 레버가 모두 돌아갔어요', '#ff8a5a', 1.8); }
      else if (type === 'o') { sfx('chip'); }
      else if (type === 'x') { sfx('thud'); }
      else if (type === 'k') { sfx('win'); burst(x, y, '#9fe6ff', 22, 3.5, 0.9); float('수정 자물쇠가 풀렸어요!', '#9fe6ff', 1.6); }
      else if (type === 'p') { sfx('pop'); burst(x, y, '#9fe6ff', 10, 2, 0.5); if (mine) float('수정 열쇠! 자물쇠에 가져가요', '#9fe6ff', 1.6); }
      else if (type === 'C') { sfx('chip'); float('체크포인트!', '#ffd28a', 1.2); }
      else if (type === 'c') { float('용암이 잠시 가라앉았어요', '#ffb36b', 1.4); }
      else if (type === 'q') { sfx('tick'); }
      else if (type === 'T') { burst(x, y, '#cbbfd6', 8, 1.6, 0.5); }
    }
    function drainEvents(evs) {
      for (const e of evs || []) { if (!Array.isArray(e) || seenEv[e[0]]) continue; seenEv[e[0]] = 1; onEvent(e[1], e[2], e[3] / 10, e[4] / 10); }
      const ks = Object.keys(seenEv); if (ks.length > 90) for (const k of ks.slice(0, 45)) delete seenEv[k];
    }
    const roleName = (s) => ROLES[s % ROLES.length].nm;

    /* ----- round setup ----- */
    const curKey = () => (st && st.ph === 'play' ? st.rid + ':' + st.lv + ':' + st.sd : null);
    let netQ = 0, pubT = 0, lastHQ = -1, lastInSig = '', inT = 0, recBest = false;
    function startRoundView() {
      W = buildWorld(st.lv, st.sd, st.n, st.lives);
      W.lr = lavaRate(st.lv, st.sp);
      aiInit(W);
      const ms = mySeat();
      W.ps.forEach((p, i) => { p.rem = api.online && api.isHost && !simHere(i) ? 1 : 0; });
      phase = 'count'; cd = 2.6; sentEnd = false; endT = 0; camInit = false; parts.length = 0; floats.length = 0;
      staticCv = null; lastHQ = -1;
      for (const k in seenEv) delete seenEv[k];
      ov.innerHTML = '';
      const card = L.h('div', { class: 'lc-card' });
      card.appendChild(L.h('h2', { text: lvName(st.lv) }));
      card.appendChild(L.h('p', { text: W.hint }));
      const cdEl = L.h('div', { class: 'cd', text: '3' }); card.appendChild(cdEl);
      ov.appendChild(card); ov._cd = cdEl;
      if (ms >= 0 && !P(ms).ai && st.lv > 0 && !recBest) { try { api.best && api.best('lv', st.lv + 1, { label: '최고 도달 단계', unit: '단계' }); } catch (e) {} }
      recBest = false;
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k]; const p = W.ps[s];
        if (!p || !p.rem || !o || o.k !== key) continue;
        if (p.dead || (p.ign && W.t < p.ign)) { continue; }
        if (typeof o.x === 'number') { p.x = o.x / 20; p.y = o.y / 20; p.vx = (o.vx || 0) / 10; p.vy = (o.vy || 0) / 10; }
        const f = o.f | 0; p.gr = f & 2 ? 1 : 0; p.rp = f & 4 ? 1 : 0; p.fc = f & 8 ? -1 : 1; p.cn = f & 32 ? 0 : -1;
        p.on = o.on == null ? -1 : o.on;
        p.in.l = o.i & 1 ? 1 : 0; p.in.r = o.i & 2 ? 1 : 0; p.in.j = o.i & 4 ? 1 : 0; p.in.a = o.i & 8 ? 1 : 0;
        if (typeof o.an === 'number') p.an = o.an;
      }
    }
    let myAn = 0, guestDeadSeen = 0;
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastHQ) return;
      lastHQ = hs.q;
      const ms = mySeat();
      decWorld(W, hs.w || {}, ms);
      const me = W.ps[ms], a = hs.w && hs.w.p && hs.w.p[ms];
      if (me && a) {
        const dead = a[4] & 1;
        if (dead && !me.dead) { me.dead = 1; me.rp = 0; me.cn = -1; }
        if (!dead && me.dead) { me.dead = 0; me.x = a[0] / 20; me.y = a[1] / 20; me.vx = 0; me.vy = 0; }
        me.key = a[4] & 16 ? 0 : -1; me.ex = a[4] & 64 ? 1 : 0;
      }
      // throws aimed at me
      for (const e of hs.w.ev || []) {
        if (!Array.isArray(e) || seenEv[e[0]]) continue;
        if (e[1] === 't' && e[2] === ms && me && !me.dead) { me.vy = -THROW; me.gr = 0; me.on = -1; me.cut = 0; }
        if (e[1] === 'r' && e[2] === ms && me) { me.dead = 0; me.x = e[3] / 10 - PW / 2; me.y = (a ? a[1] / 20 : me.y); me.vx = me.vy = 0; me.rp = 0; me.cn = -1; }
      }
      drainEvents(hs.w.ev);
      if (hs.w) W.lives = hs.w.li | 0;
    }
    function publish(rdt) {
      if (!api.online || !W || !st || st.ph !== 'play') return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 12; netQ = (netQ + 1) % 100000;
          api.net.hostSend({ k: key, q: netQ, w: encWorld(W) });
        } else {
          const ms = mySeat(); if (ms < 0) return; const p = W.ps[ms]; if (!p) return;
          if (inT > 0) return; inT = 1 / 15;
          const f = (p.gr ? 2 : 0) | (p.rp ? 4 : 0) | (p.fc < 0 ? 8 : 0) | (p.cn >= 0 ? 32 : 0);
          api.net.publish({ k: key, q: (netQ = (netQ + 1) % 100000), x: r1(p.x), y: r1(p.y), vx: Math.round(p.vx * 10), vy: Math.round(p.vy * 10), f, on: p.on, i: (input.l ? 1 : 0) | (input.r ? 2 : 0) | (input.j ? 4 : 0) | (input.a ? 8 : 0), an: myAn });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    let lastLocalA = 0;
    function frame(dt) {
      if (!st || st.ph !== 'play' || !W) return;
      if (phase === 'count') {
        const pn = Math.ceil(cd); cd -= dt; const nn = Math.ceil(cd);
        if (ov._cd) ov._cd.textContent = String(Math.max(1, nn));
        if (nn !== pn && nn > 0) sfx('tick');
        if (cd <= 0) { phase = 'play'; ov.innerHTML = ''; sfx('pop'); api.buzz && api.buzz(20); hintT = 0; }
        return;
      }
      const ms = mySeat();
      if (host()) {
        pollHost();
        if (!W.done && !W.over) {
          const hu = huArr(), lvs = lvArr();
          W.ps.forEach((p, i) => {
            const pl = api.players[i];
            if (!pl || !simHere(i) || p.rem) return;
            if (pl.ai || (L.debug && L.debug.autoplay && i === ms)) aiControl(W, i, pl.ai ? (pl.lv || 2) : 2, hu, dt);
            else if (i === ms) { p.in.l = input.l; p.in.r = input.r; p.in.j = input.j; p.in.a = input.a; p.in.d = input.d; }
          });
          director(W, (L.debug && L.debug.autoplay) ? hu.map(() => 0) : hu, lvs, dt);
          const before = W.evId;
          const me = W.ps[ms]; const fx0 = me ? me.fx : '';
          stepWorld(W, dt);
          if (me && me.fx && me.fx !== fx0) { if (me.fx === 'j') sfx('bounce'); else if (me.fx === 'v') sfx('whoosh'); me.fx = ''; }
          if (W.evId !== before) drainEvents(W.evs);
        }
        if ((W.done || W.over) && !sentEnd) {
          if (!endT) { endT = W.done ? 1.4 : 2.0; if (W.done) { sfx('win'); api.buzz && api.buzz(40); float(lvName(st.lv) + ' 탈출!', '#ffd28a', 1.6); } else { sfx('lose'); } }
          endT -= dt;
          if (endT <= 0) {
            sentEnd = true;
            const ns = U.clone(st);
            if (W.done) { const nx = nextLevel(ns, W.lives, W.stat.die); if (!st.hu.some(Boolean) && nx.clr >= 3) { nx.ph = 'done'; nx.why = 'demo'; } api.setState(nx); }
            else { try { if (ms >= 0 && !P(ms).ai) api.best && api.best('lv', st.lv + 1, { label: '최고 도달 단계', unit: '단계' }); } catch (e) {} recBest = true; api.setState(endRun(ns, W.stat.die)); }
            return;
          }
        }
      } else {
        pollGuest();
        const me = W.ps[ms];
        if (me && !me.dead) {
          W.t += dt;
          for (const lf of W.lifts) { const ny = liftY(lf, W.t); lf.dy = ny - lf.y; lf.y = ny; }
          me.in.l = input.l; me.in.r = input.r; me.in.j = input.j; me.in.a = input.a; me.in.d = input.d;
          if (input.a && !lastLocalA) myAn++;
          const fx0 = me.fx;
          movePlayer(W, me, ms, dt);
          if (me.fx && me.fx !== fx0) { if (me.fx === 'j') sfx('bounce'); else if (me.fx === 'v') sfx('whoosh'); me.fx = ''; }
        }
        lastLocalA = input.a;
        // smooth others
        W.ps.forEach((p, i) => { if (i === ms || p.tx == null) return; p.x += (p.tx + p.vx * 0.04 - p.x) * 0.3; p.y += (p.ty + p.vy * 0.04 - p.y) * 0.3; });
        W.cr.forEach((k) => { if (k.tx == null) return; k.x += (k.tx - k.x) * 0.3; k.y += (k.ty - k.y) * 0.3; });
      }
      for (let i = parts.length - 1; i >= 0; i--) { const p = parts[i]; p.t -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 4 * dt * p.g; p.vx *= 0.97; if (p.t <= 0) parts.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= dt; if (floats[i].t <= 0) floats.splice(i, 1); }
      shake = Math.max(0, shake - dt * 2);
      // embers
      if (Math.random() < 0.5 && parts.length < 200) parts.push({ x: 1 + Math.random() * 12, y: W.lava - 0.1, vx: (Math.random() - 0.5) * 0.6, vy: -1 - Math.random() * 2.5, t: 1.5 + Math.random() * 2, c: '#ff9a3c', g: -0.1, em: 1 });
      // vent steam
      for (const v of W.vents) if (ventOn(W, v) && Math.random() < 0.7) parts.push({ x: v.x + 0.3 + Math.random() * 0.4, y: v.y, vx: (Math.random() - 0.5) * 0.8, vy: -6 - Math.random() * 4, t: 0.5 + Math.random() * 0.3, c: '#e9e2da', g: 0.5, st: 1 });
      // tips
      if (ms >= 0 && W.ps[ms] && !W.ps[ms].dead) tips(dt, W.ps[ms], ms);
    }
    let tipCd = 0;
    function tips(dt, me, ms) {
      tipCd -= dt; if (tipCd > 0) return; tipCd = 0.5;
      const c = cellOf(me);
      let t = '';
      for (const lv of W.levers) if (!lv.on && !W.go[lv.g] && Math.abs(lv.x - c.x) <= 1 && Math.abs(lv.y - c.y) <= 1) t = '✋ 액션: 레버 ' + ['', 'Ⅰ', 'Ⅱ', 'Ⅲ'][lv.i] + ' 당기기';
      for (let j = 0; j < W.ps.length; j++) if (j !== ms && !W.ps[j].dead && W.ps[j].on === ms) t = '✋ 액션: 머리 위 동료 던져 올리기';
      if (!t && me.rp) t = '점프 누르고 있기: 오르기 · ◀▶: 뛰어내리기';
      if (!t && me.cn >= 0) t = '점프: 사슬 놓고 날아가기';
      if (!t && me.key >= 0) t = '수정 열쇠를 수정 자물쇠에 대 보세요';
      if (!t && me.on >= 0 && me.on < 100) t = '동료가 ✋으로 던져 줄 수 있어요';
      if (!t) for (const k of W.cr) if (k.hv && Math.abs(k.x - me.x) < 1.6 && Math.abs(k.y - me.y) < 1 && !k.mv && !W.solo) t = '무거운 바위: 둘이 같은 쪽으로 밀어요';
      hintTx = t;
    }

    /* ----- draw ----- */
    function wx(x) { return ox + x * ts; }
    function draw(now) {
      const w = cv.w, h = cv.h;
      ctx.fillStyle = '#0d0708'; ctx.fillRect(0, 0, w, h);
      if (!W) return;
      if (!staticCv) buildStatic();
      const ms = mySeat();
      const me = W.ps[ms];
      // camera
      let fy;
      if (me && !me.dead) fy = me.y;
      else { const al = W.ps.filter((p) => !p.dead); fy = al.length ? Math.min(...al.map((p) => p.y)) : W.lava - 4; }
      const viewH = h / ts;
      const resv = ((parseFloat(bJ.style.height) || 66) + 24) / ts, topR = 46 / ts;
      let target = fy - topR - (viewH - resv - topR) * 0.58;
      target = clamp(target, -0.5 - topR, W.h - viewH + resv);
      if (!camInit) { camY = target; camInit = true; }
      camY += (target - camY) * 0.12;
      const fxk = typeof L.fx === 'function' ? L.fx() : 1, sx = shake > 0 ? (Math.random() - 0.5) * shake * 8 * fxk : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 8 * fxk : 0;
      ctx.save(); ctx.translate(sx, sy - camY * ts);
      // static
      const y0 = Math.max(0, Math.floor(camY) - 1), y1 = Math.min(W.h, Math.ceil(camY + viewH) + 1);
      if (staticCv) ctx.drawImage(staticCv, 0, y0 * sScale, staticCv.width, (y1 - y0) * sScale, ox, y0 * ts, GW * ts, (y1 - y0) * ts);
      const t = W.t;
      // dynamic tiles
      for (let y = y0; y < y1; y++) for (let x = 0; x < W.w; x++) {
        const i = y * W.w + x, c = W.T[i];
        if (c === '~') drawCrumble(x, y, W.cb[i]);
        else if (c === 'q' && W.go[W.qg[i]]) ropeDraw(ctx, wx(x + 0.5), y * ts, ts);
        else if (c === 'q') { ctx.fillStyle = 'rgba(165,132,87,.18)'; ctx.fillRect(wx(x + 0.47), y * ts, ts * 0.06, ts); }
        else if (c === 'd') drawDoor(x, y, W.dg[i], W.locks.some((l) => l.x === x && l.y === y));
      }
      for (const pl of W.plates) if (pl.y >= y0 - 1 && pl.y <= y1) drawPlate(pl);
      for (const lv of W.levers) if (lv.y >= y0 - 1 && lv.y <= y1) drawLever(lv);
      for (let ci = 1; ci < W.cps.length; ci++) drawCp(W.cps[ci], ci <= W.cp);
      for (const v of W.vents) if (ventWarn(W, v)) { ctx.fillStyle = 'rgba(255,140,60,' + (0.25 + 0.2 * Math.sin(now / 60)) + ')'; ctx.fillRect(wx(v.x + 0.2), v.y * ts - ts * 0.1, ts * 0.6, ts * 0.12); }
      for (const lf of W.lifts) drawLift(lf);
      for (const c of W.chains) drawChain(c, t);
      for (const k of W.cr) drawCrate(k);
      for (const k of W.keys) if (!k.u) drawKey(k, now);
      // players
      W.ps.forEach((p, i) => { if (!p.dead) drawPlayer(p, i, now, i === ms); });
      // particles
      for (const p of parts) {
        const a = clamp(p.t * 1.6, 0, 1);
        if (p.st) { ctx.fillStyle = 'rgba(233,226,218,' + (a * 0.35) + ')'; ctx.beginPath(); ctx.arc(wx(p.x), p.y * ts, ts * (0.25 + (0.8 - p.t) * 0.4), 0, 6.29); ctx.fill(); }
        else { ctx.globalAlpha = a; ctx.fillStyle = p.c; ctx.fillRect(wx(p.x) - 1.5, p.y * ts - 1.5, p.em ? 2.2 : 3, p.em ? 2.2 : 3); ctx.globalAlpha = 1; }
      }
      drawLava(now, y1);
      ctx.restore();
      // off-screen teammates
      W.ps.forEach((p, i) => {
        if (p.dead || i === ms) return;
        const py = (p.y - camY) * ts;
        if (py < 40 || py > h - 10) {
          const yy = py < 40 ? 48 : h - 104, xx = clamp(wx(p.x + PW / 2), 16, w - 16);
          ctx.fillStyle = P(i).color; ctx.beginPath();
          if (py < 40) { ctx.moveTo(xx, yy - 8); ctx.lineTo(xx - 7, yy + 4); ctx.lineTo(xx + 7, yy + 4); } else { ctx.moveTo(xx, yy + 8); ctx.lineTo(xx - 7, yy - 4); ctx.lineTo(xx + 7, yy - 4); }
          ctx.fill();
        }
      });
      drawHud(w, h, me);
    }
    function drawCrumble(x, y, s) {
      if (s < 0) { if (s > -0.6) { ctx.fillStyle = 'rgba(120,90,70,' + ((s + 0.6) * 1.2) + ')'; ctx.fillRect(wx(x), y * ts + (0.6 + s) * -ts, ts, ts * 0.2); } return; }
      const sh = s > 0 ? (Math.random() - 0.5) * ts * 0.08 : 0;
      const X = wx(x) + sh, Y = y * ts;
      ctx.fillStyle = s > 0 ? '#7a4f3a' : '#5b4236'; ctx.fillRect(X, Y, ts + 0.5, ts * 0.26);
      ctx.strokeStyle = s > 0 ? '#ffb070' : 'rgba(255,160,100,.45)'; ctx.lineWidth = 1.2;
      ctx.beginPath(); ctx.moveTo(X + ts * 0.2, Y); ctx.lineTo(X + ts * 0.35, Y + ts * 0.14); ctx.lineTo(X + ts * 0.3, Y + ts * 0.26); ctx.moveTo(X + ts * 0.7, Y); ctx.lineTo(X + ts * 0.6, Y + ts * 0.18); ctx.stroke();
    }
    function drawDoor(x, y, g, isLock) {
      const open = !!W.go[g]; const X = wx(x), Y = y * ts;
      if (isLock) {
        if (open) return;
        ctx.fillStyle = 'rgba(80,190,240,.28)'; ctx.fillRect(X, Y, ts + 0.5, ts + 0.5);
        ctx.fillStyle = '#7fd8ff'; ctx.beginPath(); ctx.moveTo(X + ts * 0.5, Y + ts * 0.1); ctx.lineTo(X + ts * 0.85, Y + ts * 0.5); ctx.lineTo(X + ts * 0.5, Y + ts * 0.9); ctx.lineTo(X + ts * 0.15, Y + ts * 0.5); ctx.closePath(); ctx.globalAlpha = 0.75; ctx.fill(); ctx.globalAlpha = 1;
        ctx.strokeStyle = 'rgba(200,240,255,.7)'; ctx.lineWidth = 1; ctx.strokeRect(X + 0.5, Y + 0.5, ts - 1, ts - 1);
        return;
      }
      const lever = W.gk[g] === 'l';
      const col = lever ? '#d9a441' : '#ff7a3a';
      if (open) { ctx.fillStyle = 'rgba(30,18,16,.6)'; ctx.fillRect(X + ts * 0.05, Y, ts * 0.9, ts * 0.12); ctx.fillStyle = col; ctx.globalAlpha = 0.3; ctx.fillRect(X + ts * 0.05, Y, ts * 0.9, ts * 0.05); ctx.globalAlpha = 1; return; }
      ctx.fillStyle = '#2b1f1d'; ctx.fillRect(X + ts * 0.08, Y, ts * 0.84, ts + 0.5);
      ctx.fillStyle = '#55433b'; for (let k = 0; k < 3; k++) ctx.fillRect(X + ts * (0.16 + k * 0.27), Y, ts * 0.13, ts + 0.5);
      ctx.fillStyle = col; ctx.globalAlpha = 0.85; ctx.fillRect(X + ts * 0.08, Y + ts * 0.45, ts * 0.84, ts * 0.08); ctx.globalAlpha = 1;
    }
    function drawPlate(pl) {
      const X = wx(pl.x), Y = pl.y * ts + ts, on = pl.on || W.go[pl.g];
      ctx.fillStyle = '#4a3a33'; ctx.fillRect(X + ts * 0.08, Y - ts * (pl.on ? 0.08 : 0.16), ts * 0.84, ts * (pl.on ? 0.08 : 0.16));
      ctx.fillStyle = on ? '#ff9a3c' : '#8a5a3a'; ctx.fillRect(X + ts * 0.3, Y - ts * (pl.on ? 0.1 : 0.18), ts * 0.4, ts * 0.04);
      if (pl.on) { const g = ctx.createRadialGradient(X + ts / 2, Y, 1, X + ts / 2, Y, ts); g.addColorStop(0, 'rgba(255,150,60,.4)'); g.addColorStop(1, 'rgba(255,150,60,0)'); ctx.fillStyle = g; ctx.fillRect(X - ts / 2, Y - ts, ts * 2, ts * 1.2); }
      if (W.solo && W.lt[pl.g] > 0 && !pl.on) { ctx.fillStyle = '#ffd28a'; ctx.font = '700 ' + Math.round(ts * 0.36) + 'px ' + MONO; ctx.textAlign = 'center'; ctx.fillText(Math.ceil(W.lt[pl.g]) + '', X + ts / 2, Y - ts * 0.3); }
    }
    function drawLever(lv) {
      const X = wx(lv.x + 0.5), Y = lv.y * ts + ts;
      ctx.fillStyle = '#3a2c27'; ctx.fillRect(X - ts * 0.22, Y - ts * 0.16, ts * 0.44, ts * 0.16);
      const a = lv.on ? 0.6 : -0.6;
      ctx.strokeStyle = '#9b8576'; ctx.lineWidth = Math.max(2, ts * 0.09); ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(X, Y - ts * 0.12); ctx.lineTo(X + Math.sin(a) * ts * 0.55, Y - ts * 0.12 - Math.cos(a) * ts * 0.55); ctx.stroke();
      ctx.fillStyle = lv.on ? '#ffd28a' : '#c9653a'; ctx.beginPath(); ctx.arc(X + Math.sin(a) * ts * 0.55, Y - ts * 0.12 - Math.cos(a) * ts * 0.55, ts * 0.1, 0, 6.29); ctx.fill();
      ctx.fillStyle = lv.on ? '#ffd28a' : 'rgba(242,233,216,.8)'; ctx.font = '700 ' + Math.round(ts * 0.34) + 'px ' + FONT; ctx.textAlign = 'center';
      ctx.fillText(['', 'Ⅰ', 'Ⅱ', 'Ⅲ'][lv.i] || '', X, Y - ts * 0.85);
    }
    function drawCp(cp, on) {
      const x = cp.xs[0], X = wx(x + 0.5), Y = (cp.row + 1) * ts;
      ctx.fillStyle = '#3d302a'; ctx.fillRect(X - ts * 0.16, Y - ts * 0.55, ts * 0.32, ts * 0.55);
      ctx.fillStyle = on ? '#ffcf7a' : '#6a5045'; ctx.fillRect(X - ts * 0.08, Y - ts * 0.45, ts * 0.16, ts * 0.12);
      if (on) { const g = ctx.createRadialGradient(X, Y - ts * 0.4, 1, X, Y - ts * 0.4, ts * 0.9); g.addColorStop(0, 'rgba(255,200,110,.45)'); g.addColorStop(1, 'rgba(255,200,110,0)'); ctx.fillStyle = g; ctx.fillRect(X - ts, Y - ts * 1.3, ts * 2, ts * 1.8); }
    }
    function drawLift(lf) {
      const X = wx(lf.x), Y = lf.y * ts;
      ctx.strokeStyle = 'rgba(120,100,90,.7)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(X + ts * 0.15, (lf.y0 - 1.5) * ts); ctx.lineTo(X + ts * 0.15, Y); ctx.moveTo(X + ts * 1.85, (lf.y0 - 1.5) * ts); ctx.lineTo(X + ts * 1.85, Y); ctx.stroke();
      ctx.fillStyle = '#5c4a40'; ctx.fillRect(X, Y, ts * 2, ts * 0.24);
      ctx.fillStyle = '#8a7060'; ctx.fillRect(X, Y, ts * 2, ts * 0.06);
      ctx.fillStyle = '#2a1e1a'; for (let k = 0; k < 4; k++) ctx.fillRect(X + ts * (0.2 + k * 0.45), Y + ts * 0.1, ts * 0.12, ts * 0.08);
    }
    function drawChain(c, t) {
      const e = chainEnd(c, t);
      ctx.fillStyle = '#4b3c35'; ctx.beginPath(); ctx.arc(wx(c.ax), c.ay * ts, ts * 0.16, 0, 6.29); ctx.fill();
      const nL = 9;
      ctx.strokeStyle = '#a39184'; ctx.lineWidth = Math.max(1.5, ts * 0.07);
      for (let k = 0; k < nL; k++) {
        const u = (k + 0.5) / nL, x = c.ax + (e.x - c.ax) * u, y = c.ay + (e.y - c.ay) * u;
        ctx.beginPath(); ctx.ellipse(wx(x), y * ts, ts * 0.07, ts * 0.13, -e.a, 0, 6.29); ctx.stroke();
      }
      ctx.fillStyle = '#c9b6a6'; ctx.beginPath(); ctx.arc(wx(e.x), e.y * ts, ts * 0.13, 0, 6.29); ctx.fill();
    }
    function drawCrate(k) {
      const X = wx(k.x), Y = k.y * ts, s = CS * ts;
      if (k.hv) {
        const g = ctx.createRadialGradient(X + s * 0.35, Y + s * 0.3, 1, X + s / 2, Y + s / 2, s * 0.7);
        g.addColorStop(0, '#4a4452'); g.addColorStop(1, '#16131c');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(X + s * 0.15, Y + s); ctx.lineTo(X, Y + s * 0.45); ctx.lineTo(X + s * 0.22, Y + s * 0.05); ctx.lineTo(X + s * 0.75, Y); ctx.lineTo(X + s, Y + s * 0.4); ctx.lineTo(X + s * 0.9, Y + s); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = 'rgba(200,190,230,.35)'; ctx.lineWidth = 1; ctx.stroke();
        ctx.fillStyle = 'rgba(242,233,216,.75)'; ctx.font = '700 ' + Math.round(ts * 0.3) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.fillText(W.solo ? '' : '×2', X + s / 2, Y + s * 0.62);
      } else {
        ctx.fillStyle = '#6e5446'; ctx.fillRect(X, Y, s, s);
        ctx.fillStyle = '#8b6c5a'; ctx.fillRect(X, Y, s, s * 0.14);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(X + s * 0.2, Y + s * 0.35, s * 0.25, s * 0.1); ctx.fillRect(X + s * 0.55, Y + s * 0.6, s * 0.3, s * 0.08);
        ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.strokeRect(X + 0.5, Y + 0.5, s - 1, s - 1);
      }
    }
    function drawKey(k, now) {
      const X = wx(k.x + 0.5), Y = (k.y + 0.5) * ts + Math.sin(now / 300) * ts * 0.06;
      const g = ctx.createRadialGradient(X, Y, 1, X, Y, ts * 0.9); g.addColorStop(0, 'rgba(120,220,255,.5)'); g.addColorStop(1, 'rgba(120,220,255,0)');
      ctx.fillStyle = g; ctx.fillRect(X - ts, Y - ts, ts * 2, ts * 2);
      ctx.fillStyle = '#a8ecff'; ctx.beginPath(); ctx.moveTo(X, Y - ts * 0.32); ctx.lineTo(X + ts * 0.18, Y); ctx.lineTo(X, Y + ts * 0.32); ctx.lineTo(X - ts * 0.18, Y); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#e8fbff'; ctx.lineWidth = 1; ctx.stroke();
    }
    function drawPlayer(p, i, now, mine) {
      const col = P(i).color || '#e3ae45';
      const X = wx(p.x), Y = p.y * ts, w = PW * ts, h = PH * ts;
      const run = p.gr && Math.abs(p.vx) > 0.5 ? Math.sin(now / 70 + i) : 0;
      // lamp glow
      const lx = X + w / 2 + p.fc * w * 0.25, ly = Y + h * 0.18;
      const gr = ctx.createRadialGradient(lx, ly, 1, lx, ly, ts * (i % 4 === 0 ? 3.4 : 2.6));
      gr.addColorStop(0, 'rgba(255,230,170,.22)'); gr.addColorStop(1, 'rgba(255,230,170,0)');
      ctx.fillStyle = gr; ctx.fillRect(lx - ts * 3.5, ly - ts * 3.5, ts * 7, ts * 7);
      // legs
      ctx.fillStyle = '#1d1517';
      ctx.fillRect(X + w * 0.18 + run * w * 0.1, Y + h * 0.72, w * 0.22, h * 0.28);
      ctx.fillRect(X + w * 0.6 - run * w * 0.1, Y + h * 0.72, w * 0.22, h * 0.28);
      // torso (seat colour, darkened)
      const sh = i % 4 === 1 ? 0.08 : 0;
      ctx.fillStyle = shade(col, -0.25); rr(ctx, X + w * (0.05 - sh), Y + h * 0.32, w * (0.9 + sh * 2), h * 0.44, w * 0.18); ctx.fill();
      ctx.fillStyle = shade(col, -0.55); ctx.fillRect(X + w * 0.05, Y + h * 0.62, w * 0.9, h * 0.06);
      // gear by role
      if (i % 4 === 2) { ctx.fillStyle = '#8f8a86'; ctx.fillRect(X + w * 0.1, Y + h * 0.3, w * 0.8, h * 0.08); ctx.fillRect(X + (p.fc > 0 ? 0 : w * 0.7), Y + h * 0.34, w * 0.3, h * 0.08); }
      if (i % 4 === 3) { ctx.strokeStyle = '#a58457'; ctx.lineWidth = Math.max(1.5, w * 0.1); ctx.beginPath(); ctx.arc(X + w * (p.fc > 0 ? 0.15 : 0.85), Y + h * 0.5, w * 0.2, 0, 6.29); ctx.stroke(); }
      // head + helmet
      ctx.fillStyle = '#c9a58a'; ctx.fillRect(X + w * 0.22, Y + h * 0.14, w * 0.56, h * 0.2);
      ctx.fillStyle = '#2e2422'; ctx.beginPath(); ctx.ellipse(X + w / 2, Y + h * 0.16, w * 0.4, h * 0.16, 0, Math.PI, 0); ctx.fill();
      ctx.fillRect(X + w * 0.06, Y + h * 0.14, w * 0.88, h * 0.05);
      ctx.fillStyle = '#ffe9a8'; ctx.beginPath(); ctx.arc(X + w / 2 + p.fc * w * 0.18, Y + h * 0.1, w * 0.08, 0, 6.29); ctx.fill();
      // eye slit
      ctx.fillStyle = '#140c0c'; ctx.fillRect(X + w * (p.fc > 0 ? 0.52 : 0.28), Y + h * 0.22, w * 0.2, h * 0.04);
      if (p.key >= 0 || (p.key === 0)) { /* key drawn by key itself */ }
      if (mine) { ctx.strokeStyle = 'rgba(255,220,150,.75)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(X + w / 2 - 5, Y - 8); ctx.lineTo(X + w / 2, Y - 3); ctx.lineTo(X + w / 2 + 5, Y - 8); ctx.stroke(); }
      else {
        let up = 0; for (let j = 0; j < i; j++) { const q = W.ps[j]; if (!q.dead && Math.abs(q.x - p.x) < 1.6 && Math.abs(q.y - p.y) < 0.6) up += 13; }
        ctx.fillStyle = col; ctx.font = '700 ' + Math.round(clamp(ts * 0.36, 10, 13)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.fillText(roleName(i), X + w / 2, Y - 4 - up);
      }
    }
    function drawLava(now, y1) {
      const ly = W.lava * ts;
      if (W.lava > y1 + 2) return;
      const w0 = ox, w1 = ox + GW * ts;
      const glow = ctx.createLinearGradient(0, ly - ts * 4, 0, ly);
      glow.addColorStop(0, 'rgba(255,90,20,0)'); glow.addColorStop(1, 'rgba(255,110,30,.32)');
      ctx.fillStyle = glow; ctx.fillRect(w0, ly - ts * 4, w1 - w0, ts * 4);
      ctx.beginPath(); ctx.moveTo(w0, ly + ts * 30);
      for (let x = 0; x <= GW * 4; x++) { const xx = w0 + x * ts / 4; ctx.lineTo(xx, ly + Math.sin(x * 0.9 + now / 260) * ts * 0.1 + Math.sin(x * 0.37 - now / 410) * ts * 0.08); }
      ctx.lineTo(w1, ly + ts * 30); ctx.closePath();
      const lg = ctx.createLinearGradient(0, ly, 0, ly + ts * 3);
      lg.addColorStop(0, '#ffcf5a'); lg.addColorStop(0.12, '#ff7a1e'); lg.addColorStop(0.5, '#c2300f'); lg.addColorStop(1, '#5a0f06');
      ctx.fillStyle = lg; ctx.fill();
      ctx.fillStyle = 'rgba(40,8,4,.45)';
      for (let k = 0; k < 6; k++) { const xx = w0 + ((k * 97 + now / 30) % (GW * ts)); ctx.beginPath(); ctx.ellipse(xx, ly + ts * (0.9 + (k % 3) * 0.5), ts * 0.7, ts * 0.12, 0, 0, 6.29); ctx.fill(); }
    }
    function drawHud(w, h, me) {
      // top strip
      const g = ctx.createLinearGradient(0, 0, 0, 44); g.addColorStop(0, 'rgba(10,5,6,.85)'); g.addColorStop(1, 'rgba(10,5,6,0)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, 46);
      ctx.textAlign = 'left'; ctx.fillStyle = '#ffd28a'; ctx.font = '15px ' + DISP;
      const nmTx = st ? lvName(st.lv) : ''; ctx.fillText(nmTx.length > 16 && w < 380 ? nmTx.split(' · ')[0] : nmTx, 12, 22);
      ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#e9dccb';
      ctx.fillText('목숨 ' + W.lives, 12, 38);
      // lava distance
      ctx.textAlign = 'right';
      if (me && !me.dead) {
        const d = Math.max(0, W.lava - (me.y + PH));
        ctx.fillStyle = d < 3 ? '#ff6a3a' : d < 6 ? '#ffb36b' : '#e9dccb';
        ctx.font = '700 13px ' + FONT; ctx.fillText('용암까지 ' + d.toFixed(1) + '칸', w - 12, 22);
      } else if (me && me.dead) { ctx.fillStyle = '#ff8a5a'; ctx.font = '700 12px ' + FONT; ctx.fillText(W.lives > 0 ? '곧 다시 일어나요…' : '목숨이 없어요 · 동료를 응원해요', w - 12, 22); }
      // team dots
      let xx = w - 12;
      for (let i = W.ps.length - 1; i >= 0; i--) { const p = W.ps[i]; ctx.globalAlpha = p.dead ? 0.3 : 1; ctx.fillStyle = P(i).color; ctx.beginPath(); ctx.arc(xx - 5, 34, 5, 0, 6.29); ctx.fill(); if (p.ex) { ctx.strokeStyle = '#bfe0ff'; ctx.lineWidth = 2; ctx.stroke(); } xx -= 15; }
      ctx.globalAlpha = 1;
      // floats
      floats.forEach((f, k) => { const a = clamp(f.t / f.T * 3, 0, 1); ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.font = '700 15px ' + FONT; ctx.fillStyle = 'rgba(10,5,6,.7)'; const tw = ctx.measureText(f.text).width + 20; rr(ctx, w / 2 - tw / 2, 58 + k * 30, tw, 26, 13); ctx.fill(); ctx.fillStyle = f.col; ctx.fillText(f.text, w / 2, 76 + k * 30); ctx.globalAlpha = 1; });
      // hint above controls
      if (hintTx && phase === 'play') {
        const bs = parseFloat(bL.style.height) || 60;
        ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; const tw = Math.min(w - 20, ctx.measureText(hintTx).width + 18);
        const yy = h - bs * 1.55 - 40;
        ctx.fillStyle = 'rgba(10,5,6,.72)'; rr(ctx, w / 2 - tw / 2, yy, tw, 24, 12); ctx.fill();
        ctx.fillStyle = '#ffe2b0'; ctx.fillText(hintTx, w / 2, yy + 16);
      }
      // exit waiting
      if (me && me.ex && !W.done) { const n = W.ps.filter((p) => !p.dead && !p.ex).length; if (n) { ctx.textAlign = 'center'; ctx.font = '700 14px ' + FONT; ctx.fillStyle = '#bfe0ff'; ctx.fillText('출구! 동료 ' + n + '명을 기다려요', w / 2, 100); } }
    }

    const STEP = 1 / 60;
    const stopLoop = U.loop((rdt) => {
      refreshInput();
      acc += Math.min(0.25, rdt) * SPD();
      let n = 0;
      try { while (acc >= STEP && n < 90) { frame(STEP); acc -= STEP; n++; } } catch (e) { console.error(e); acc = 0; }
      if (n >= 90) acc = 0;
      try { publish(rdt); } catch (e) {}
      try { draw(performance.now()); } catch (e) { console.error(e); }
    });
    layout();

    return {
      update(next) {
        if (!next) return;
        const prev = st; st = next;
        const k = curKey();
        if (k && k !== key) { key = k; startRoundView(); }
        if (!k) { key = null; }
        if (prev && prev.ph !== next.ph && next.ph === 'done') { sfx('lose'); W = W; releaseAll(); }
      },
      destroy() {
        if (hintOff) hintOff();
        stopLoop();
        pad.removeEventListener('pointerdown', padDown); pad.removeEventListener('pointermove', padMove);
        pad.removeEventListener('pointerup', padUp); pad.removeEventListener('pointercancel', padUp); pad.removeEventListener('lostpointercapture', padUp);
        root.removeEventListener('contextmenu', noCtx); window.removeEventListener('blur', releaseAll);
        ui.remove(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ W, st, phase, input }),
    };
  }
  function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '')); if (!m) return hex;
    const n = parseInt(m[1], 16); const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'lavacave', name: '용암 동굴 탈출', tag: '협동 실시간 플랫폼', cat: '아케이드', coop: true,
    blurb: '차오르는 용암을 피해 화산 동굴을 함께 빠져나가요! 발판·레버·밧줄·어깨 받치기로 서로를 도와요. 한 기기에 한 명씩.',
    tint: '#6e1e0c',
    icon: '<path d="M4 50c6-4 10-4 16 0s10 4 16 0 10-4 16 0v6H4z" fill="currentColor"/><rect x="8" y="34" width="14" height="4" rx="1" fill="currentColor" opacity=".7"/><rect x="30" y="24" width="16" height="4" rx="1" fill="currentColor" opacity=".7"/><rect x="14" y="12" width="12" height="4" rx="1" fill="currentColor" opacity=".7"/><circle cx="38" cy="16" r="3.5" fill="currentColor"/><rect x="35" y="19" width="6" height="5" rx="1.5" fill="currentColor"/><path d="M20 30l3-6 3 6" stroke="currentColor" stroke-width="2.5" fill="none" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 3, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'L', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'R', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'J', label: '점프 · 밧줄 오르기', keys: ['Space', 'ArrowUp', 'KeyW'], pad: ['a', 'up'] },
      { id: 'A', label: '액션(레버 · 던지기 · 놓기)', keys: ['KeyE', 'KeyJ', 'ShiftLeft'], pad: ['x', 'b'] },
      { id: 'D', label: '밧줄 내려가기', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
    ],
    options: [
      { id: 'mode', label: '시작', tip: '어디서 시작할지.', choices: [{ v: 'camp', label: '1단계부터', tip: '1단계부터 차례로.' }, { v: 'deep', label: '깊은 곳(무작위 동굴)', tip: '무작위 깊은 동굴에서 바로.' }], def: 'camp' },
      { id: 'lava', label: '용암 속도', tip: '용암이 차오르는 속도.', choices: [{ v: 0, label: '느림' }, { v: 1, label: '보통' }, { v: 2, label: '빠름' }], def: 1 },
    ],
    quick: [
      '모두 함께 화산 동굴을 위로 빠져나가요. 아래에서 용암이 천천히 차올라요!',
      '◀▶로 걷고 ⤒점프. ✋액션으로 레버 당기기·동료 던져 올리기·밧줄 놓기.',
      '살아 있는 모두가 맨 위 출구(푸른 빛)에 모이면 다음 단계. 목숨은 다 같이 써요.',
    ],
    rules: [
      { h: '목표', p: [
        '협동 게임이에요. 단계마다 동굴 맨 위 푸른 빛이 도는 출구까지 올라가요.',
        '살아 있는 사람이 모두 출구에 모이면 단계 통과! 손으로 만든 12단계를 지나면 그다음부터는 무작위로 만들어지는 「깊은 곳」이 끝없이 이어져요.',
        '용암은 천천히 차올라요. 너무 뒤처지면 더 빨리 따라와요.',
      ] },
      { h: '목숨 · 체크포인트', p: [
        '목숨은 모두가 함께 써요(처음 3+인원 수, 단계를 통과할 때마다 +1).',
        '용암에 빠지면 잠시 뒤 마지막 체크포인트(빛나는 돌기둥)에서 다시 일어나요. 그때 용암이 가까우면 조금 가라앉아요.',
        '목숨이 없을 때 빠지면 그 단계는 구경만 해요. 다음 단계에 다시 함께해요. 모두가 쓰러지면 끝!',
      ] },
      { h: '조작', p: [
        '◀▶ 버튼(손가락을 미끄러뜨려도 돼요)으로 걷고, ⤒ 점프. 길게 누르면 높이, 짧게 누르면 낮게 뛰어요.',
        '발판 끝에서 살짝 늦게 눌러도 뛰어지고, 땅에 닿기 직전에 눌러도 뛰어요.',
        '✋ 액션: 레버 당기기, 머리 위에 선 동료 던져 올리기, 밧줄·사슬 놓기.',
        'PC: ←→/AD 이동, Space·↑·W 점프, E·J 액션, ↓·S 밧줄 내려가기. 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '동굴 장치', p: [
        '🟧 압력 발판: 누군가(또는 돌덩이)가 밟고 있는 동안만 문이 열려요. 문 건너편에도 발판이 있어서 서로 열어 줄 수 있어요.',
        '🔧 레버 Ⅰ·Ⅱ·Ⅲ: 번호 순서대로 당기면 문이 열려요. 틀리면 모두 처음으로 돌아가요.',
        '🪢 밧줄: 뛰어들면 매달려요. 점프를 누르고 있으면 올라가고, ◀▶을 누르면 뛰어내려요.',
        '⛓ 흔들 사슬: 끝을 잡으면 흔들려요. 원하는 쪽으로 흔들릴 때 점프로 놓으면 멀리 날아가요.',
        '♨ 증기 구멍: 증기가 뿜어질 때(구멍이 붉게 깜빡이면 곧) 위에 서 있으면 높이 솟아요.',
        '⬛ 승강기: 저절로 오르내려요. 바닥에 내려왔을 때 올라타요.',
        '💎 수정 열쇠: 들고 수정 자물쇠에 닿으면 자물쇠가 사라져요.',
        '돌덩이는 혼자 밀 수 있고, 무거운 바위(×2)는 둘이 같은 쪽에서 함께 밀어야 움직여요.',
        '금 간 발판은 밟으면 곧 무너지고, 몇 초 뒤 다시 생겨요.',
      ] },
      { h: '어깨 받치기', p: [
        '동료 머리 위에 올라설 수 있어요. 그대로 점프하면 조금 더 높이 뛰어요.',
        '아래 사람이 ✋ 액션을 누르면 위 사람을 높이 던져 올려요. 혼자는 못 오르는 높은 턱은 이렇게!',
      ] },
      { h: '혼자 할 때', p: [
        '혼자(1명) 하면 퍼즐이 바뀌어요: 압력 발판은 밟았다 떼도 6초 동안 문이 열려 있고, 높은 턱에는 돌계단이 생기고, 무거운 바위도 혼자 밀 수 있어요.',
        'AI 동료와 하면 AI가 발판을 밟아 주고, 레버를 당기고, 어깨를 받쳐 줘요. 너무 뒤처진 AI는 알아서 따라붙어요.',
      ] },
      { h: '예시', p: [
        '문 앞 발판을 AI 「바위어깨」가 밟고 있어요 → 내가 문을 지나 건너편 발판을 밟아요 → 바위어깨가 문을 지나와요. 둘 다 통과!',
      ] },
      { h: 'AI · 함께 하기', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 골라요. 어려움은 빠르고 정확하게 돕고, 쉬움은 굼뜨고 가끔 헤매요.',
        '실시간 게임이라 한 기기에 한 명씩이에요. 혼자 켜면 나머지는 AI 동료, 친구와는 온라인 방이나 LAN 방으로 해요.',
        '캐릭터: ' + ROLES.map((r) => r.nm).join(' · ') + ' (자리 순서대로).',
      ] },
    ],
    codex: [
      { h: '단계', p: ['손으로 만든 12단계 다음은 무작위로 이어 붙인 「깊은 곳」이에요.'], rows: HAND.map((hd, i) => ({ icon: '🔥', name: (i + 1) + '단계 · ' + hd.nm, tag: '구간 ' + hd.c.length + '개 · 용암 ' + lavaRate(i, 1).toFixed(2) + '칸/초', desc: hd.hint })) },
      { h: '동굴 구간', p: ['단계는 아래 구간들을 쌓아서 만들어요.'], rows: POOL.map((id) => ({ icon: '🪨', name: CHUNKS[id].nm, tag: '구간', desc: chunkDesc(id) })) },
      { h: '캐릭터', p: ['자리 순서대로 정해져요. 능력은 모두 같고 모습만 달라요.'], rows: ROLES.map((r) => ({ icon: '⛑️', name: r.nm, tag: '탐험가', desc: r.ds })) },
    ],
    init, actor: () => null,
    apply(st) { throw new Error('realtime'); },
    ai() { return null; },
    result, mount,
    _t: { mkP, edges, buildWorld, stepWorld, aiControl, director, aiInit, findPath, needFor, CHUNKS, HAND, levelPlan, encWorld, decWorld, lavaRate, nextLevel, endRun, cellOf, PW, PH },
  });
  function chunkDesc(id) {
    const r = CHUNKS[id].r.join('');
    const f = [];
    if (/[AB]/.test(r)) f.push('압력 발판'); if (/[123]/.test(r)) f.push('레버'); if (/R|q/.test(r)) f.push('밧줄'); if (/~/.test(r)) f.push('무너지는 발판');
    if (/v/.test(r)) f.push('증기'); if (/T/.test(r)) f.push('승강기'); if (/k/.test(r)) f.push('수정 열쇠'); if (/O/.test(r)) f.push('무거운 바위'); if (/o/.test(r)) f.push('돌덩이');
    if (/H/.test(r)) f.push('흔들 사슬'); if (/b/.test(r)) f.push('어깨 받치기');
    return f.length ? f.join(' · ') : '점프로 오르는 바위턱';
  }
})();
