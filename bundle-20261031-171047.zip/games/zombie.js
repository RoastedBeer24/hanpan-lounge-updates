/* 좀비 감염 — 2–8인 실시간 술래 감염전.
   처음엔 알파 좀비 1명. 잡힌 사람은 무작위 종류의 좀비가 되어 같이 쫓는다. 시간이 끝날 때 한 명이라도 남으면 생존자 승리.
   생존자 도구: 문 닫기, 판자 막기(문·창문), 사다리로 지붕 오르기(시간 제한), 숨는 곳, 아이템(음료·덫·손전등·백신·소리 미끼).
   Host-authoritative: the host (or local device) runs the world sim; guests get ~15 snapshots/s via hostSend and predict
   their own body. Coarse state (round, map, scores) travels with api.setState. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  const fin = (v) => typeof v === 'number' && isFinite(v);

  /* ---------- tuning ---------- */
  const NP = 8, PR = 0.3, CATCH = 0.58, ACC = 26;
  const V_S = 3.1, V_A = 3.3, V_Z = 2.35, DRINK_K = 1.45, DRINK_T = 4;
  const LUNGE_T = 0.28, V_LUNGE = 6.8, LUNGE_CD_A = 3.5, LUNGE_CD = 5, MISS_T = 0.6;
  const TF_T = 1.6, START_T = 4, HELI_T = 30, HELI_R = 1.6, HELI_STAY = 0.8, END_T = 6.5;
  const DOOR_HP = 100, DOOR_PUSH = 22, DOOR_BASH = 34, DOOR_CD = 10, REACH = 1.3;
  const BAR_HP = 110, BAR_ADD = 70, BAR_MAX = 200, PK_MAX = 3, PK_START = 2, PRY_T = 1.0, TANK_K = 2.2;
  const CLIMB_S = 0.7, CLIMB_Z = 1.0, ROOF_T = 12, LAD_R = 0.8, SLIP_T = 0.6;
  const HIDE_T = 0.6, HIDE_SEE = 1.4;
  const LURE_T = 6, LURE_D = 6, LURE_R = 12;
  const FLASH_R = 3.5, FLASH_T = 2.2, TRAP_T = 2.6, VAC_T = 2.5, VAC_STUN = 1.2;
  const RUN_T = 2.5, RUN_K = 1.35, SNIFF_T = 3.5, SNIFF_R = 14, LEAP_T = 0.42, LEAP_D = 2.6, SCREAM_R = 5, CALL_R = 9, BOOST_T = 3, BOOST_K = 1.18, SCARE_T = 1.3, REV_T = 4;
  const SMELL_N = 3, HORDE_N = 5;
  const LIGHT_S = 4.6, LIGHT_Z = 4.0;
  const PT_SEC = 3, PT_SURV = 10, PT_LAST = 10, PT_INF = 8;
  const IT_NM = ['속도 음료', '덫', '손전등', '백신', '소리 미끼', '판자 묶음', '바리케이드', '연막탄'];
  const IT_W = [3, 2, 2, 1, 2, 0, 2, 2], IT_K = [0, 1, 2, 3, 4, 6, 7]; // 5 = plank bundle (not spawned)
  const BARI_T = 8, SMOKE_T = 6, SMOKE_R = 2.2, VENT_K = 0.7;
  // zombie kinds an infected survivor can turn into (the alpha keeps its own kit: fast + quick lunge)
  const ZT = [
    { nm: '질주 좀비', sk: '질주', v: 1.06, cd: 12, d: '「질주」 잠깐 아주 빨라져요', sk2: '빨리 달리기' },
    { nm: '탱커 좀비', sk: '박살', v: 0.9, cd: 11, d: '「박살」 문·판자를 한 번에 · 덫·빛에 강해요', sk2: '문·판자 부수기' },
    { nm: '냄새 좀비', sk: '킁킁', v: 1, cd: 12, d: '「킁킁」 근처 사람 위치를 모두에게', sk2: '숨은 사람 찾기' },
    { nm: '도약 좀비', sk: '도약', v: 0.97, cd: 6, d: '「도약」 장애물 넘기 · 창문·사다리도 타요', sk2: '앞으로 뛰어넘기' },
    { nm: '비명 좀비', sk: '비명', v: 0.95, cd: 15, d: '「비명」 좀비를 불러 빠르게 · 사람은 움찔', sk2: '좀비 불러 모으기' },
  ];

  // survivor jobs (picked during the countdown; infected → the zombie kind's skill replaces the job)
  // act: the small button uses the job when empty-handed (cd in s, 0 = passive)
  const JB = [
    { nm: '수리공', ic: '🔨', act: 0, d: '판자 1개 더 · 판자 1.5배 튼튼 · 빨리 뜯기' },
    { nm: '척후', ic: '👟', act: 0, d: '조금 빠름 · 발소리가 작아 좀비가 늦게 알아채요' },
    { nm: '의무병', ic: '💊', act: 0, d: '판마다 한 번 감염을 해독(잡혀도 버팀)' },
    { nm: '경비원', ic: '🔒', act: 0, d: '내가 닫은 문은 2배 튼튼' },
    { nm: '달리기 선수', ic: '🏃', act: 14, sk: '질주', d: '「질주」 1.6초 아주 빠르게' },
    { nm: '무전병', ic: '📻', act: 20, sk: '무전', d: '「무전」 좀비 위치 3초 보기 · 살아 있으면 구조 10초 일찍' },
    { nm: '덫잡이', ic: '🕸', act: 16, sk: '덫', d: '「덫」 발밑에 덫 놓기' },
    { nm: '은신가', ic: '🌿', act: 0, d: '빨리 숨고(0.25초) 숨으면 더 안 보여요' },
  ];
  const JOB_RUN_T = 1.6, JOB_RUN_K = 1.4, SCOUT_K = 1.03, SCOUT_EAR = 0.85, FIX_K = 1.5, GUARD_K = 2, RADIO_T = 3, RADIO_HELI = 6, MED_T = 6, SNEAK_T = 0.25, SNEAK_SEE = 1.0;
  const hideT = (p) => (p.jb === 7 ? SNEAK_T : HIDE_T);

  /* ---------- maps (built from rooms/rects so they stay readable) ----------
     # wall · . floor · , outside · D door · W window (people & leapers climb through) · T tree/pillar (blocks sight)
     o low stuff (car, bench) · ~ water · R track pit · B roof block (walk on it after climbing) · L ladder · h hiding spot
     room door tokens: 'e2' = door on the east wall 2 tiles down, '!e2' = window there. */
  const MAPS = [
    { nm: '햇살 마을', th: 0, dark: 0, base: ',', zv: 1.12,
      rooms: [[2, 2, 6, 5, 'e2 s3 !n3'], [16, 2, 6, 5, 'w2 s2 !s4'], [9, 9, 6, 5, 's2 s3 !n2'], [2, 11, 6, 5, 'e2 n2 !w2'], [16, 11, 6, 5, 'w2 n3 !e2'], [2, 22, 7, 6, 'n3 e3 !w3'], [15, 22, 7, 6, 'n3 w2 !e3']],
      rects: [['T', 10, 3], ['T', 13, 3], ['o', 10, 6, 2, 1], ['o', 14, 7, 1, 1], ['o', 3, 8, 2, 1], ['o', 19, 8, 2, 1], ['o', 6, 18, 2, 1], ['o', 16, 18, 2, 1],
        ['T', 8, 16], ['T', 15, 16], ['T', 11, 27], ['T', 1, 18], ['T', 22, 21], ['B', 10, 21, 4, 3], ['L', 12, 24],
        ['h', 8, 8], ['h', 15, 9], ['h', 1, 20], ['h', 22, 8], ['h', 9, 27], ['h', 14, 27], ['h', 5, 9]],
      items: [[4, 4], [19, 4], [11, 11], [4, 13], [19, 13], [5, 25], [18, 25], [12, 7], [1, 22], [22, 17]], z: [11, 25], hz: [12, 18] },
    { nm: '반짝 쇼핑몰', th: 1, dark: 0, base: '.', zv: 0.86, // 실내 맵: 바깥 순환로가 없어 좀비가 조금 느려요(모의 대전으로 맞춤)
      rooms: [[1, 1, 7, 7, 'e3 s3 !e5'], [1, 8, 7, 7, 'e3 n3 s3 !e5'], [1, 15, 7, 7, 'e3 n3 s3 !e5'], [1, 22, 7, 7, 'e3 n3 !e5'], [16, 1, 7, 7, 'w3 s3 !w5'], [16, 8, 7, 7, 'w3 n3 s3 !w5'], [16, 15, 7, 7, 'w3 n3 s3 !w5'], [16, 22, 7, 7, 'w3 n3 !w5']],
      rects: [['o', 10, 4, 1, 5], ['o', 13, 4, 1, 5], ['~', 11, 12, 2, 2], ['T', 9, 20], ['T', 14, 20], ['o', 11, 24, 2, 1], ['B', 10, 16, 4, 2], ['L', 12, 18],
        ['h', 9, 2], ['h', 14, 2], ['h', 9, 11], ['h', 14, 11], ['h', 9, 26], ['h', 14, 26], ['h', 3, 3], ['h', 20, 27]],
      items: [[4, 4], [4, 11], [4, 18], [4, 25], [19, 4], [19, 11], [19, 18], [19, 25], [11, 9], [12, 21]], z: [11, 2], hz: [12, 27] },
    { nm: '한밤 학교', th: 2, dark: 1, base: '.',
      pre: [[',', 1, 20, 22, 9]],
      rooms: [[1, 1, 7, 7, 's3 !s5'], [8, 1, 8, 7, 's2 s5'], [16, 1, 7, 7, 's3 !s1'], [1, 11, 7, 7, 'n3 s3 !e3'], [16, 11, 7, 7, 'n3 s3 !w3'], [15, 21, 7, 7, 'w3 n2 !n5 !e3']],
      rects: [['#', 1, 19, 22, 1], ['D', 4, 19], ['D', 11, 19], ['D', 12, 19], ['D', 20, 19], ['T', 10, 13], ['T', 13, 13], ['T', 10, 15], ['T', 13, 15],
        ['T', 3, 22], ['T', 9, 26], ['T', 11, 22], ['o', 6, 21, 1, 1], ['o', 12, 27, 1, 1], ['o', 18, 24, 1, 1], ['B', 10, 23, 3, 2], ['L', 11, 25],
        ['h', 8, 9], ['h', 15, 9], ['h', 11, 17], ['h', 1, 24], ['h', 8, 21], ['h', 22, 27], ['h', 3, 4], ['h', 20, 15]],
      items: [[4, 4], [11, 4], [19, 4], [4, 14], [19, 14], [11, 14], [19, 26], [2, 27], [14, 24]], z: [12, 9], hz: [6, 25] },
    { nm: '달빛 병원', th: 3, dark: 1, base: '.', zv: 0.86,
      rooms: [[1, 1, 9, 6, 'e3 s4 !e1'], [1, 7, 9, 6, 'e2 n4 !e4'], [14, 1, 9, 6, 'w3 s4 !w1'], [14, 7, 9, 6, 'w2 n4 !w4'], [1, 17, 9, 6, 'e3 s4 !e1'], [1, 23, 9, 6, 'e2 n4 !e4'], [14, 17, 9, 6, 'w3 s4 !w1'], [14, 23, 9, 6, 'w2 n4 !w4']],
      rects: [['o', 11, 4], ['o', 12, 21], ['o', 11, 15, 2, 1], ['T', 1, 13], ['T', 22, 16], ['B', 11, 9, 2, 3], ['L', 11, 12],
        ['h', 2, 2], ['h', 21, 2], ['h', 2, 27], ['h', 21, 27], ['h', 8, 11], ['h', 15, 11], ['h', 3, 14], ['h', 20, 15]],
      items: [[5, 3], [5, 10], [18, 3], [18, 10], [5, 19], [5, 26], [18, 19], [18, 26], [12, 7], [3, 15], [20, 14]], z: [12, 2], hz: [11, 27] },
    { nm: '숲속 캠핑장', th: 4, dark: 1, base: ',',
      rooms: [[2, 2, 6, 5, 's2 !e2'], [16, 3, 6, 5, 's3 w2 !n2'], [3, 20, 6, 5, 'n2 e2 !w2'], [15, 21, 7, 5, 'n3 !w2'], [9, 10, 6, 5, 'w2 e2 !n3 !s3']],
      rects: [['~', 18, 12, 4, 4], ['T', 11, 2], ['T', 13, 5], ['T', 1, 9], ['T', 5, 10], ['T', 7, 13], ['T', 19, 9], ['T', 22, 18], ['T', 10, 18], ['T', 14, 17],
        ['T', 12, 27], ['T', 8, 27], ['T', 20, 27], ['T', 1, 26], ['T', 4, 8], ['T', 20, 1], ['o', 12, 17], ['o', 16, 9, 2, 1], ['B', 11, 24, 2, 2], ['L', 13, 25],
        ['h', 1, 12], ['h', 6, 15], ['h', 13, 7], ['h', 21, 19], ['h', 9, 22], ['h', 17, 27], ['h', 3, 17]],
      items: [[4, 4], [18, 5], [5, 22], [18, 23], [11, 12], [2, 14], [21, 10], [12, 21], [16, 17]], z: [12, 8], hz: [5, 16] },
    { nm: '지하철역', th: 5, dark: 0, base: '.',
      rooms: [[1, 1, 6, 5, 'e2 !s3'], [17, 1, 6, 5, 'w2 !s3'], [1, 11, 5, 5, 'e2 !n2'], [18, 11, 5, 5, 'w2 !n2'], [1, 22, 5, 5, 'e2 !n2'], [18, 22, 5, 5, 'w2 !n2']],
      rects: [['o', 1, 9, 22, 1], ['.', 3, 9, 3, 1], ['.', 10, 9, 4, 1], ['.', 18, 9, 3, 1], ['R', 9, 11, 6, 18], ['.', 9, 15, 6, 2], ['.', 9, 23, 6, 2],
        ['T', 7, 13], ['T', 7, 20], ['T', 7, 26], ['T', 16, 13], ['T', 16, 20], ['T', 16, 26], ['o', 10, 3, 4, 1], ['o', 4, 18], ['o', 19, 18], ['B', 10, 17, 4, 5], ['L', 11, 16],
        ['h', 7, 4], ['h', 16, 4], ['h', 2, 19], ['h', 21, 19], ['h', 7, 17], ['h', 16, 24]],
      items: [[3, 3], [19, 3], [3, 13], [20, 13], [3, 24], [20, 24], [13, 16], [12, 24], [5, 7], [18, 7]], z: [4, 20], hz: [12, 6] },
    { nm: '항구 창고', th: 6, dark: 0, base: ',', zv: 1.07,
      pre: [['~', 1, 25, 8, 4], ['~', 15, 25, 8, 4]],
      rooms: [[2, 2, 9, 8, 's3 e4 !s7 !e2'], [14, 2, 8, 8, 's4 w4 !s1 !w2'], [2, 14, 6, 6, 'e2 n3 !s3']],
      rects: [['o', 5, 4, 2, 1], ['o', 17, 6, 2, 1], ['B', 11, 12, 5, 2], ['L', 13, 14], ['B', 17, 15, 4, 2], ['L', 16, 16], ['B', 9, 20, 2, 3], ['L', 11, 21],
        ['o', 12, 10], ['o', 19, 12, 2, 1], ['o', 3, 22, 2, 1], ['o', 20, 21], ['o', 14, 19],
        ['h', 21, 11], ['h', 8, 12], ['h', 1, 21], ['h', 18, 19], ['h', 13, 23], ['h', 7, 23], ['h', 4, 7]],
      items: [[6, 6], [18, 4], [4, 17], [12, 16], [20, 23], [3, 11], [12, 7], [22, 18], [6, 21], [16, 12]], z: [12, 4], hz: [11, 26] },
    { nm: '눈 덮인 산장', th: 7, dark: 1, base: ',', zv: 1.12,
      rooms: [[5, 2, 14, 9, 's4 s9 w4 e4 !n3 !n10'], [1, 16, 6, 5, 'n2 e2 !s3'], [17, 16, 6, 5, 'n3 w2 !s2']],
      rects: [['#', 12, 3, 1, 7], ['D', 12, 6], ['o', 6, 3, 2, 1], ['o', 15, 7, 2, 1], ['B', 10, 21, 4, 3], ['L', 12, 24],
        ['T', 2, 12], ['T', 7, 13], ['T', 16, 13], ['T', 21, 12], ['T', 3, 25], ['T', 8, 27], ['T', 17, 26], ['T', 20, 23], ['T', 1, 8], ['T', 22, 6],
        ['o', 9, 14, 2, 1], ['o', 14, 18],
        ['h', 4, 12], ['h', 19, 13], ['h', 9, 18], ['h', 15, 24], ['h', 5, 27], ['h', 21, 27], ['h', 2, 4]],
      items: [[7, 6], [16, 4], [10, 8], [3, 18], [19, 18], [12, 15], [5, 23], [19, 21], [2, 28], [21, 3]], z: [12, 12], hz: [12, 27] },
    { nm: '한낮 놀이공원', th: 8, dark: 0, base: ',',
      rooms: [[1, 1, 6, 5, 's3 !e2'], [17, 1, 6, 5, 's2 !w2'], [2, 10, 7, 8, 'e3 s2 !n5'], [16, 11, 6, 5, 'w2 n3 !s3'], [1, 23, 6, 6, 'n3 !e3'], [17, 23, 6, 6, 'n2 !w3']],
      rects: [['B', 10, 13, 4, 4], ['L', 12, 17], ['B', 18, 18, 3, 2], ['L', 17, 19],
        ['T', 9, 3], ['T', 14, 3], ['T', 9, 21], ['T', 15, 21], ['o', 11, 8, 2, 1], ['o', 11, 26, 2, 1], ['o', 3, 20, 2, 1],
        ['h', 8, 6], ['h', 15, 6], ['h', 1, 19], ['h', 22, 9], ['h', 8, 26], ['h', 15, 27], ['h', 4, 13]],
      items: [[3, 3], [20, 3], [5, 14], [19, 13], [3, 26], [20, 26], [12, 11], [11, 20], [22, 17], [8, 22]], z: [12, 4], hz: [12, 23] },
    { nm: '옥수수 농장', th: 9, dark: 0, base: ',',
      rooms: [[2, 2, 9, 8, 's4 e3 !n5 !w4'], [15, 2, 7, 6, 's3 w3 !e2']],
      rects: [['B', 17, 11, 3, 3], ['L', 16, 12], ['B', 4, 13, 3, 2], ['L', 5, 15], ['o', 12, 10, 2, 1], ['o', 4, 4, 2, 1], ['o', 9, 13, 1, 2], ['T', 12, 20], ['T', 1, 16], ['T', 22, 15],
        ['h', 2, 19, 8, 2], ['h', 2, 22, 8, 2], ['h', 2, 25, 8, 2], ['h', 14, 19, 8, 2], ['h', 14, 22, 8, 2], ['h', 14, 25, 8, 2], ['h', 7, 6]],
      items: [[6, 5], [18, 4], [12, 13], [2, 12], [21, 9], [5, 17], [19, 17], [11, 23], [12, 28], [8, 12]], z: [12, 8], hz: [12, 25] },
    { nm: '한밤 아파트', th: 10, dark: 1, base: ',', zv: 1.07,
      rooms: [[9, 10, 6, 6, 'n2 s3 !w2 !e3'], [1, 13, 4, 4, 'e1'], [17, 12, 6, 6, 'w2 s3 !n3']],
      rects: [['B', 2, 2, 6, 4], ['L', 5, 6], ['B', 16, 2, 6, 4], ['L', 18, 6], ['B', 2, 24, 6, 4], ['L', 5, 23], ['B', 16, 24, 6, 4], ['L', 18, 23],
        ['o', 3, 9, 2, 1], ['o', 6, 9, 2, 1], ['o', 3, 20, 2, 1], ['o', 6, 20, 2, 1], ['o', 16, 20, 2, 1], ['o', 19, 20, 2, 1], ['o', 11, 18, 2, 1],
        ['T', 9, 3], ['T', 14, 3], ['T', 8, 17], ['T', 15, 18],
        ['h', 1, 8], ['h', 22, 9], ['h', 9, 20], ['h', 14, 22], ['h', 1, 21], ['h', 22, 21], ['h', 11, 7]],
      items: [[5, 8], [19, 8], [11, 12], [2, 15], [20, 15], [12, 19], [5, 18], [19, 22], [12, 27], [22, 7]], z: [12, 24], hz: [12, 5] },
    { nm: '심야 지하철역', th: 11, dark: 1, base: '.', zv: 1,
      rooms: [[2, 2, 7, 6, 'e3 s3 !s5'], [15, 2, 7, 6, 'w3 s2 !s4'], [2, 20, 6, 6, 'n3 e2'], [16, 20, 6, 6, 'n2 w3'], [9, 23, 6, 5, 'n2 !n4']],
      rects: [['R', 1, 13, 22, 3], ['.', 5, 13, 2, 3], ['.', 17, 13, 2, 3], ['v', 12, 12, 1, 5], ['v', 7, 24, 3, 1],
        ['o', 1, 9, 4, 1], ['o', 8, 9, 3, 1], ['o', 13, 9, 3, 1], ['o', 19, 9, 4, 1], ['B', 19, 13, 3, 3], ['L', 20, 12],
        ['T', 5, 11], ['T', 18, 11], ['T', 5, 18], ['T', 18, 18], ['T', 9, 18], ['T', 14, 18], ['o', 4, 4, 2, 1], ['o', 17, 5, 2, 1],
        ['h', 3, 11], ['h', 21, 11], ['h', 10, 19], ['h', 13, 19], ['h', 3, 24], ['h', 20, 24], ['h', 7, 3]],
      items: [[5, 5], [18, 3], [11, 8], [3, 17], [20, 17], [4, 22], [18, 22], [11, 25], [2, 11], [21, 10]], z: [12, 10], hz: [12, 21] },
    { nm: '학교 건물', th: 12, dark: 1, base: '.', zv: 1,
      pre: [[',', 15, 21, 8, 8]],
      rooms: [[1, 1, 8, 8, 's3 s6'], [8, 1, 8, 8, 's2 s5'], [15, 1, 8, 8, 's3 !s5'], [1, 13, 8, 8, 'n3 !n6'], [8, 13, 8, 8, 'n2 n5'], [15, 13, 8, 8, 'n3 s3'],
        [1, 20, 14, 9, 'n3 n10 e3']],
      rects: [['v', 8, 4], ['v', 15, 4], ['v', 8, 16], ['v', 15, 16],
        ['o', 3, 3, 2, 1], ['o', 3, 5, 2, 1], ['o', 11, 4, 2, 1], ['o', 18, 3, 2, 1], ['o', 18, 5, 2, 1], ['o', 3, 16, 2, 1], ['o', 11, 17, 2, 1], ['o', 18, 16, 2, 1],
        ['T', 6, 10], ['T', 17, 11], ['B', 2, 25, 3, 2], ['L', 5, 25], ['B', 20, 22, 2, 2], ['L', 19, 22], ['T', 16, 26], ['T', 22, 27],
        ['h', 2, 9], ['h', 12, 9], ['h', 21, 12], ['h', 7, 22], ['h', 13, 27], ['h', 21, 26], ['h', 10, 6]],
      items: [[4, 6], [12, 3], [19, 6], [4, 18], [11, 15], [19, 18], [9, 24], [17, 23], [12, 11], [1, 11]], z: [12, 10], hz: [17, 27] },
  ];
  /* ---------- 도감 (codex): generated from ZT / IT_NM / MAPS / PM / THEMES and the constants above ---------- */
  function zbCodex() {
    const pct = (v) => Math.round(v * 100) + '%';
    const spd = (v) => '사람의 ' + pct(v / V_S);
    const ZI = ['💨', '🛡', '👃', '🦘', '📢'];
    const ZX = [
      RUN_T + '초 동안 ' + pct(RUN_K) + ' 속도로 달려요.',
      '문·판자를 ' + TANK_K + '배 세게 부숴요. 덫·손전등은 절반만 통해요.',
      '숨은 사람을 3칸 안에서 찾아요. 「킁킁」 ' + SNIFF_R + '칸 안 사람 위치를 ' + SNIFF_T + '초 동안 모든 좀비에게 보여 줘요.',
      '장애물·판자를 최대 ' + LEAP_D + '칸 뛰어넘어요. 창문을 넘고 사다리로 지붕에도 올라와요.',
      CALL_R + '칸 안 좀비를 ' + BOOST_T + '초 빠르게, ' + SCREAM_R + '칸 안 사람은 움찔(느려짐)하고 ' + REV_T + '초 들켜요.',
    ];
    const tot = IT_W.reduce((a, b) => a + b, 0);
    const II = ['🥤', '🪤', '🔦', '💉', '📣', '', '🚧', '💨'];
    const IX = [
      DRINK_T + '초 동안 ' + pct(DRINK_K) + ' 속도로 달려요.',
      '발밑에 놓아요. 밟은 좀비는 ' + TRAP_T + '초 꼼짝 못 해요(탱커는 절반).',
      '「번쩍!」 주변 ' + FLASH_R + '칸 좀비가 ' + FLASH_T + '초 눈부셔 멈춰요(탱커는 절반).',
      '들고만 있으면 한 번 잡혀도 막아 줘요. 좀비는 ' + VAC_STUN + '초 멈추고 나는 ' + VAC_T + '초 무적.',
      '보는 쪽으로 ' + LURE_D + '칸 던져요. ' + LURE_T + '초 동안 울려 ' + LURE_R + '칸 안 좀비를 끌어요(똑똑한 좀비는 잘 안 속아요).',
      '',
      '문·창문 앞에서 써요. ' + BARI_T + '초 동안 아무도 못 지나가고 절대 안 부서져요(탱커 「박살」도 안 통해요). 시간이 지나면 저절로 치워져요.',
      '발밑에 터뜨려요. ' + SMOKE_T + '초 동안 반지름 ' + SMOKE_R + '칸 연기 — 안에 있는 사람은 움직여도 숨은 것처럼 보이고, 좀비는 콜록거리며 ' + pct(0.8) + ' 속도.',
    ];
    const JX = [
      '판자를 ' + (PK_START + 1) + '개로 시작해요. 막은 판자가 ' + FIX_K + '배 튼튼하고(최대 ' + BAR_MAX * FIX_K + '), 판자를 ' + PRY_T / 2 + '초 만에 뜯어요.',
      '조금 빨라요(' + pct(SCOUT_K) + '). 발소리가 작아서 좀비가 알아채는 거리가 ' + pct(SCOUT_EAR) + '로 줄어요.',
      '판마다 한 번, 잡혀도 바로 감염되지 않고 ' + MED_T + '초 버텨요(그동안 안 잡히고 좀비는 다른 사람을 쫓아요). 그 안에 구조로 탈출하면 살아남아요. 판이 그 안에 끝나도 생존.',
      '내가 닫은 문은 튼튼함이 ' + DOOR_HP * GUARD_K + '(보통 ' + DOOR_HP + ')이에요.',
      '「질주」 ' + JOB_RUN_T + '초 동안 ' + pct(JOB_RUN_K) + ' 속도로 달려요.',
      '「무전」 ' + RADIO_T + '초 동안 모든 좀비 위치가 보여요(화면 밖은 화살표). 무전병이 살아 있으면 구조가 ' + RADIO_HELI + '초 일찍 와요.',
      '「덫」 발밑에 덫을 놓아요(아이템 덫과 같아요, 지붕 위에선 못 놓아요).',
      HIDE_T + '초 대신 ' + SNEAK_T + '초 만에 숨고, 숨으면 좀비가 ' + SNEAK_SEE + '칸까지 와야 보여요(보통 ' + HIDE_SEE + ').',
    ];
    const HS = ['덤불', '큰 화분', '사물함', '커튼 침대', '천 덮인 상자', '옥수수밭', '눈 덮인 덤불'];
    const MI = ['🏘', '🛍', '🏫', '🏥', '🏕', '🚇', '⚓', '🏔', '🎢', '🌽', '🏢', '🚉', '🏫'];
    const NOTE = [
      '집 7채가 흩어진 밝은 마을. 가운데 지붕이 넓어요.',
      '양쪽에 가게 8곳, 가운데 분수와 긴 통로. 문 많은 가게 사이로 빙빙 돌기 좋아요.',
      '교실 줄과 운동장이 벽으로 나뉘어요. 복도 문 4개가 길목이에요.',
      '병실 8곳이 대칭으로 있고 가운데 복도가 길어요.',
      '나무가 빽빽한 숲과 호수. 오두막이 흩어져 있어요.',
      '가운데 선로 구덩이는 못 건너요(건널목 2곳). 승강장이 길어요.',
      '큰 창고 2채와 지붕 3곳, 아래쪽은 바다예요.',
      '큰 산장 하나(가운데 벽과 문)와 작은 오두막 2채. 나무가 많아요.',
      '놀이기구 지붕이 크고 넓어요. 가게가 가장자리에 있어요.',
      '아래쪽 절반이 옥수수밭 — 어디서나 숨을 수 있어요. 헛간과 지붕 2곳.',
      '네 귀퉁이 지붕(사다리 4개)과 가운데 건물. 방이 적어요.',
      '불 꺼진 지하 역. 가로지르는 선로는 건널목 2곳으로만 건너고, 선로 밑 환풍구(사람만)가 지름길. 세운 열차 위가 지붕.',
      '어두운 교실 6칸과 긴 복도, 체육관, 뒷마당. 교실 사이 벽 환풍구(사람만)로 빠져나가요.',
    ];
    return [
      { h: '좀비 종류', p: ['모든 좀비: 닿으면 감염, 큰 버튼 「돌진」(' + LUNGE_CD + '초마다), 닫힌 문·판자는 「부수기」. 좀비가 ' + SMELL_N + '명부터 가까운 사람 쪽 화살표, ' + HORDE_N + '명부터 문·판자를 2배 빨리 부숴요.', '감염된 사람은 아래 다섯 종류 중 하나가 무작위로 돼요. 속도는 처음 기준이고, 좀비가 늘수록 조금씩 빨라져요.'],
        rows: [{ icon: '👑', name: '알파 좀비', tag: '처음 1명 · 돌진 ' + LUNGE_CD_A + '초마다', desc: '판 시작 때의 좀비. 속도 ' + spd(V_A) + '(사람이 적으면 조금 느려요). 돌진을 자주 써요. 특기는 없어요.' }]
          .concat(ZT.map((z, i) => ({ icon: ZI[i], name: z.nm, tag: '「' + z.sk + '」 ' + z.cd + '초마다', desc: z.sk2 + ' — ' + ZX[i] + ' 속도 ' + spd(V_Z * z.v) + '.' }))) },
      { h: '생존자 직업', p: ['판 시작 카운트다운 동안 고르고(기본 무작위, 고른 직업은 이 기기에 기억돼요. 첫 판은 사람이 모두 직업을 누를 때까지 카운트다운이 멈춰요), 감염되면 직업 대신 좀비 종류 특기를 써요. 특기가 있는 직업은 빈손일 때 작은 버튼으로 써요.'],
        rows: JB.map((J, i) => ({ icon: J.ic, name: J.nm, tag: J.act ? '「' + J.sk + '」 ' + J.act + '초마다' : '늘 켜져 있음', desc: JX[i] })) },
      { h: '생존자 도구', p: ['아이템은 한 번에 1개만 들어요(걸어가면 주워요). 맵 곳곳에 나오고, 10초마다 빈자리에 새로 생겨요. 확률은 나올 때마다 기준.'],
        rows: [
          { icon: '🪵', name: '판자', tag: PK_START + '개로 시작 · 최대 ' + PK_MAX, desc: '문·창문 앞에서 「판자」로 막아요(튼튼함 ' + BAR_HP + '). 또 누르면 보강(+' + BAR_ADD + ', 최대 ' + BAR_MAX + '). 내가 나갈 땐 ' + PRY_T + '초 밀면 뜯어지고 판자를 돌려받아요.' },
          { icon: '🚪', name: '문', tag: '닫기·열기', desc: '닫힌 문은 좀비가 부숴야 지나가요(튼튼함 ' + DOOR_HP + ').' },
          { icon: '🪟', name: '창문', tag: '사람만 넘기', desc: '사람은 천천히 넘어가고, 좀비는 못 넘어요(도약 좀비만 넘어요).' },
          { icon: '🪜', name: '사다리·지붕', tag: '한 판 ' + ROOF_T + '초', desc: '지붕 위엔 좀비가 못 와요(도약 좀비만). 한 판에 모두 합쳐 ' + ROOF_T + '초까지, 그 뒤엔 미끄러져 떨어져요. 가장자리에서 「뛰어내리기」.' },
          { icon: '🌿', name: '숨는 곳', tag: HIDE_T + '초 가만히', desc: '위에 가만히 서 있으면 숨어요. 좀비에겐 ' + HIDE_SEE + '칸 안에 와야 보여요(냄새 좀비는 3칸). 움직이면 다시 보여요.' },
          { icon: '🚁', name: '구조', tag: '마지막 ' + HELI_T + '초', desc: 'H 동그라미 안에 ' + HELI_STAY + '초 서 있으면 탈출! 맵에 따라 헬기·보트·열차가 와요(설정에서 끌 수 있어요).' },
          { icon: '🕳', name: '환풍구', tag: '사람만 · 느리게', desc: '좁은 환풍구는 사람만 기어서 지나가요(속도 ' + pct(VENT_K) + '). 좀비는 도약 좀비도 못 들어와요.' },
        ].concat(IT_K.map((k) => ({ icon: II[k], name: IT_NM[k], tag: '아이템 · ' + Math.round(IT_W[k] / tot * 100) + '%', desc: IX[k] }))) },
      { h: '맵', p: ['기본값은 무작위(판마다 바뀌어요). 어두운 맵은 내 주변만 보여요(설정 「어둠」으로 바꿀 수 있어요).'],
        rows: MAPS.map((m, i) => {
          const P = PM[i], T = THEMES[m.th] || THEMES[0], g = P.gates;
          const nv = P.c.split('').filter((ch) => ch === 'v').length;
          const st = '문 ' + g.filter((x) => !x.win).length + ' · 창문 ' + g.filter((x) => x.win).length + (nv ? ' · 환풍구 ' + nv + '칸' : '') + ' · 지붕 ' + P.roofs.length + ' · 숨는 곳 ' + (m.th === 9 ? '옥수수밭' : P.hide.length) + ' · 아이템 자리 ' + P.items.length;
          return { icon: MI[i] || '🗺', name: m.nm, tag: (m.dark ? '어둠' : '밝음') + ' · ' + T.rz, desc: NOTE[i] + ' 숨는 곳: ' + HS[T.hs] + '. ' + st };
        }) },
    ];
  }
  // hs = hiding-spot style: 0 bush · 1 plant · 2 locker · 3 curtain bed · 4 tarp crates · 5 corn · 6 snowy bush
  const THEMES = [
    { fl: '#8a6a48', fl2: '#7e6040', gr: '#4c5661', gr2: '#46505a', wall: '#8a6a4a', wtop: '#ecd6b2', tree: '#3f8a46', obj: '#c4523f', bg: '#2b3a2a', rz: '헬기', rf: '#b0503a', rf2: '#8f3e2d', hs: 0 },
    { fl: '#c8beae', fl2: '#b9af9f', gr: '#c8beae', gr2: '#b9af9f', wall: '#2e2540', wtop: '#54467a', tree: '#4c9a5a', obj: '#8a7a6a', bg: '#2a2236', rz: '옥상 헬기', rf: '#6a5a8a', rf2: '#55486f', hs: 1 },
    { fl: '#9a805a', fl2: '#8d7451', gr: '#7c6a48', gr2: '#736241', wall: '#25343f', wtop: '#46607a', tree: '#3c7a40', obj: '#8a5a3a', bg: '#1c2330', rz: '헬기', rf: '#5a6a7a', rf2: '#48566a', hs: 2 },
    { fl: '#9ec2bc', fl2: '#93b6b0', gr: '#9ec2bc', gr2: '#93b6b0', wall: '#22363b', wtop: '#3f5f68', tree: '#4f8a64', obj: '#d8dde0', bg: '#16242a', rz: '옥상 헬기', rf: '#e8eef0', rf2: '#c0ccd0', hs: 3 },
    { fl: '#8a6440', fl2: '#7c5a38', gr: '#3c5e34', gr2: '#36552f', wall: '#5a3a20', wtop: '#b88250', tree: '#2c6a34', obj: '#9a6a3a', bg: '#14200f', rz: '헬기', rf: '#6a4a2a', rf2: '#57391f', hs: 0 },
    { fl: '#8f8f96', fl2: '#86868d', gr: '#8f8f96', gr2: '#86868d', wall: '#1c2130', wtop: '#3a4256', tree: '#d0b040', obj: '#c95a3a', bg: '#1a1c24', rz: '구조 열차', rf: '#3a6aa0', rf2: '#2c5280', hs: 2 },
    { fl: '#7a6a58', fl2: '#706150', gr: '#6a7078', gr2: '#646a72', wall: '#3a3a44', wtop: '#7a7a88', tree: '#c8a040', obj: '#8a6a3a', bg: '#132030', rz: '구조 보트', rf: '#c0553a', rf2: '#2f7a8a', hs: 4 },
    { fl: '#8a6440', fl2: '#7f5c3a', gr: '#dfe6ee', gr2: '#d3dbe6', wall: '#5a3a20', wtop: '#f4f8fc', tree: '#2c5a44', obj: '#c8d4e0', bg: '#1a2230', rz: '헬기', rf: '#f0f4f8', rf2: '#c8d2dc', hs: 6 },
    { fl: '#d8b88a', fl2: '#cdae80', gr: '#b8a890', gr2: '#ae9e86', wall: '#7a2a5a', wtop: '#e87aa8', tree: '#3f8a46', obj: '#3a7ab0', bg: '#2a1a2a', rz: '헬기', rf: '#e0607a', rf2: '#f0c040', hs: 0 },
    { fl: '#8a6a48', fl2: '#7e6040', gr: '#6e8a44', gr2: '#67823f', wall: '#8a2a20', wtop: '#d86a50', tree: '#c8b060', obj: '#9a7a4a', bg: '#1e2a12', rz: '헬기', rf: '#b8bcc0', rf2: '#d8b050', hs: 5 },
    { fl: '#9a9488', fl2: '#908a7e', gr: '#4e535e', gr2: '#494e58', wall: '#2a2f3a', wtop: '#5a6070', tree: '#3a6a3a', obj: '#a03a3a', bg: '#12141c', rz: '옥상 헬기', rf: '#4a5262', rf2: '#3e4554', hs: 0 },
    { fl: '#5e625f', fl2: '#575b58', gr: '#5e625f', gr2: '#575b58', wall: '#1b1f22', wtop: '#3b4246', tree: '#6a6f68', obj: '#7a7f78', bg: '#0c0e10', rz: '구조 열차', rf: '#52606a', rf2: '#3f4a52', hs: 2 },
    { fl: '#7d7466', fl2: '#756c5f', gr: '#4a5040', gr2: '#454b3c', wall: '#2c2a26', wtop: '#5c5648', tree: '#55584e', obj: '#6a5a44', bg: '#121210', rz: '옥상 헬기', rf: '#5a5a54', rf2: '#484843', hs: 2 },
  ];
  const SOLID = '#To~RB', OPAQ = '#TB'; // 'v' vent: see parseMap
  function build(d) {
    const W = d.W || 24, H = d.H || 30, g = [];
    for (let y = 0; y < H; y++) g.push(new Array(W).fill(d.base || '.'));
    const set = (x, y, c) => { if (x >= 0 && y >= 0 && x < W && y < H) g[y][x] = c; };
    const rect = (c, x, y, w, h) => { for (let j = y; j < y + (h || 1); j++) for (let i = x; i < x + (w || 1); i++) set(i, j, c); };
    for (const r of d.pre || []) rect(r[0], r[1], r[2], r[3], r[4]);
    for (const r of d.rooms || []) {
      const [x, y, w, h, ds] = r; rect('#', x, y, w, h); rect('.', x + 1, y + 1, w - 2, h - 2);
      for (let t of String(ds || '').split(' ').filter(Boolean)) {
        const win = t[0] === '!'; if (win) t = t.slice(1);
        const s = t[0], o = +t.slice(1), c = win ? 'W' : 'D';
        if (s === 'n') set(x + o, y, c); else if (s === 's') set(x + o, y + h - 1, c); else if (s === 'w') set(x, y + o, c); else set(x + w - 1, y + o, c);
      }
    }
    for (const r of d.rects || []) rect(r[0], r[1], r[2], r[3], r[4]);
    for (let x = 0; x < W; x++) { g[0][x] = '#'; g[H - 1][x] = '#'; }
    for (let y = 0; y < H; y++) { g[y][0] = '#'; g[y][W - 1] = '#'; }
    return g.map((r) => r.join(''));
  }
  function parseMap(d, k) {
    const rows = build(d), Wd = rows[0].length, H = rows.length, N = Wd * H, c = rows.join('');
    const M = { k, nm: d.nm, th: d.th, dark: d.dark, W: Wd, H, N, c, sol: new Uint8Array(N), opq: new Uint8Array(N), gateAt: new Int16Array(N).fill(-1), gates: [],
      lads: [], roofOf: new Int16Array(N).fill(-1), roofs: [], hide: [],
      items: d.items.map(([x, y]) => ({ x: x + 0.5, y: y + 0.5, i: y * Wd + x })), z: { x: d.z[0] + 0.5, y: d.z[1] + 0.5 }, hz: { x: d.hz[0] + 0.5, y: d.hz[1] + 0.5 },
      walk: [], dead: new Float32Array(N) };
    const wallish = (ch) => ch === '#' || ch === 'W' || ch === 'D';
    for (let i = 0; i < N; i++) {
      const ch = c[i];
      if (SOLID.includes(ch)) M.sol[i] = 7;
      if (ch === 'v') M.sol[i] = 6; // crawl vent: survivors only
      if (OPAQ.includes(ch)) M.opq[i] = 1;
      if (ch === 'D' || ch === 'W') {
        const x = i % Wd, y = (i / Wd) | 0, hz = wallish(c[i - 1]) || wallish(c[i + 1]);
        M.gateAt[i] = M.gates.length; M.gates.push({ i, x: x + 0.5, y: y + 0.5, hz, win: ch === 'W' });
        if (ch === 'W') M.sol[i] = 2; // windows stop ordinary zombies only
      } else if (!M.sol[i]) M.walk.push(i);
      if (ch === 'h') M.hide.push(i);
    }
    // roofs = connected B blocks; ladders hook onto one of them
    for (let i = 0; i < N; i++) {
      if (c[i] !== 'B' || M.roofOf[i] >= 0) continue;
      const id = M.roofs.length, R = { tiles: [], lads: [], x: 0, y: 0 }, q = [i]; M.roofOf[i] = id;
      for (let h = 0; h < q.length; h++) {
        const t = q[h]; R.tiles.push(t);
        for (const n of [t - 1, t + 1, t - Wd, t + Wd]) if (n >= 0 && n < N && c[n] === 'B' && M.roofOf[n] < 0 && (Math.abs((n % Wd) - (t % Wd)) <= 1)) { M.roofOf[n] = id; q.push(n); }
      }
      for (const t of R.tiles) { R.x += t % Wd + 0.5; R.y += ((t / Wd) | 0) + 0.5; }
      R.x /= R.tiles.length; R.y /= R.tiles.length;
      M.roofs.push(R);
    }
    for (let i = 0; i < N; i++) {
      if (c[i] !== 'L') continue;
      const x = i % Wd;
      for (const n of [i - Wd, i + Wd, x > 0 ? i - 1 : -1, x < Wd - 1 ? i + 1 : -1]) {
        if (n < 0 || n >= N || c[n] !== 'B') continue;
        const r = M.roofOf[n], j = M.lads.length;
        M.lads.push({ i, x: x + 0.5, y: ((i / Wd) | 0) + 0.5, t: n, tx: n % Wd + 0.5, ty: ((n / Wd) | 0) + 0.5, r });
        M.roofs[r].lads.push(j);
        break;
      }
    }
    // roof edges you can jump down from
    for (const R of M.roofs) {
      R.ex = [];
      for (const t of R.tiles) {
        const x = t % Wd;
        for (const [n, dx, dy] of [[t - 1, -1, 0], [t + 1, 1, 0], [t - Wd, 0, -1], [t + Wd, 0, 1]]) {
          if (n < 0 || n >= N || (dx && Math.abs((n % Wd) - x) !== 1)) continue;
          if (c[n] === 'B' || (M.sol[n] & 3) || M.gateAt[n] >= 0) continue;
          R.ex.push({ t, n, dx, dy, x: n % Wd + 0.5, y: ((n / Wd) | 0) + 0.5 });
        }
      }
    }
    // dead-end score: how many tiles are reachable within 5 steps (small = cornered)
    for (const i of M.walk) {
      const seen = new Map([[i, 0]]), q = [i];
      for (let h = 0; h < q.length; h++) {
        const t = q[h], dd = seen.get(t); if (dd >= 5) continue;
        for (const n of [t - 1, t + 1, t - Wd, t + Wd]) if (n >= 0 && n < N && !(M.sol[n] & 1) && !seen.has(n)) { seen.set(n, dd + 1); q.push(n); }
      }
      M.dead[i] = clamp((34 - seen.size) / 26, 0, 1);
    }
    return M;
  }
  const PM = MAPS.map(parseMap);

  function mulberry(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hash2(a, b) { let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  const tileOf = (M, x, y) => clamp(Math.floor(y), 0, M.H - 1) * M.W + clamp(Math.floor(x), 0, M.W - 1);
  const wrapA = (a) => { while (a > Math.PI) a -= TAU; while (a < -Math.PI) a += TAU; return a; };

  /* ---------- physics ---------- */
  const maskOf = (p) => (!p.z ? 1 : p.zt === 3 ? 4 : 2);
  function solidP(W, p, tx, ty) {
    const M = W.M; if (tx < 0 || ty < 0 || tx >= M.W || ty >= M.H) return true;
    const i = ty * M.W + tx;
    if (p.up) return M.c[i] !== 'B';
    return (W.sol[i] & maskOf(p)) !== 0;
  }
  function resolve(W, p) {
    for (let it = 0; it < 2; it++) {
      const x0 = Math.floor(p.x - PR), x1 = Math.floor(p.x + PR), y0 = Math.floor(p.y - PR), y1 = Math.floor(p.y + PR);
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        if (!solidP(W, p, tx, ty)) continue;
        const cx = clamp(p.x, tx, tx + 1), cy = clamp(p.y, ty, ty + 1), dx = p.x - cx, dy = p.y - cy, d2 = dx * dx + dy * dy;
        if (d2 >= PR * PR) continue;
        if (d2 > 1e-9) { const d = Math.sqrt(d2), k = (PR - d) / d; p.x += dx * k; p.y += dy * k; }
        else { // centre inside the tile: leave along the shortest side
          const l = p.x - tx, r = tx + 1 - p.x, u = p.y - ty, b = ty + 1 - p.y, m = Math.min(l, r, u, b);
          if (m === l) p.x = tx - PR; else if (m === r) p.x = tx + 1 + PR; else if (m === u) p.y = ty - PR; else p.y = ty + 1 + PR;
        }
      }
    }
  }
  function fitsAt(W, p, x, y) {
    const r = PR - 0.02;
    return !solidP(W, p, Math.floor(x - r), Math.floor(y - r)) && !solidP(W, p, Math.floor(x + r), Math.floor(y - r)) &&
      !solidP(W, p, Math.floor(x - r), Math.floor(y + r)) && !solidP(W, p, Math.floor(x + r), Math.floor(y + r));
  }
  function los(W, x0, y0, x1, y1) { // opaque tiles, closed doors and barricades block
    const M = W.M, d = hyp(x1 - x0, y1 - y0), n = Math.ceil(d * 3);
    for (let k = 1; k < n; k++) {
      const x = x0 + (x1 - x0) * k / n, y = y0 + (y1 - y0) * k / n, i = tileOf(M, x, y);
      if (M.opq[i]) return false;
      const j = M.gateAt[i]; if (j >= 0 && (W.gate[j].s === 1 || W.gate[j].b > 0 || W.gate[j].lk > 0)) return false;
    }
    return true;
  }
  // someone up on a roof sees / is seen over walls
  const losP = (W, a, b) => (a.up || b.up ? true : los(W, a.x, a.y, b.x, b.y));
  function updGate(W, j) {
    const G = W.M.gates[j], g = W.gate[j];
    W.sol[G.i] = g.s === 1 || g.b > 0 || g.lk > 0 ? 7 : G.win ? 2 : 0;
  }
  function setDoor(W, j, s) { W.gate[j].s = s; updGate(W, j); }

  /* ---------- world ---------- */
  function pickItem(rng) {
    let r = rng() * IT_W.reduce((a, b) => a + b, 0); for (let k = 0; k < IT_W.length; k++) { r -= IT_W[k]; if (r < 0) return k; } return 0;
  }
  function newWorld(st) {
    const M = PM[st.mk] || PM[0], rng = mulberry(((st.rid | 0) * 7919 + (st.rd | 0) * 104729) | 0);
    const W = { M, t: 0, sol: Uint8Array.from(M.sol), gate: M.gates.map(() => ({ s: 0, hp: 0, cd: 0, b: 0, lk: 0 })), pl: [], gi: [], traps: [], lu: [], sm: [], fx: [], fxN: 0, res: null,
      zv: (MAPS[st.mk] && MAPS[st.mk].zv) || 1, len: st.len || 90, heli: st.heli ? 1 : 0, dark: st.fog === 1 ? 1 : st.fog === 0 ? 0 : M.dark, nz: 1, itT: 6, zf: null, zfT: -9, al: st.al | 0 };
    const used = [];
    for (let s = 0; s < st.np; s++) {
      let x = M.z.x, y = M.z.y;
      if (s !== W.al) {
        for (let tries = 0; tries < 400; tries++) {
          const i = M.walk[Math.floor(rng() * M.walk.length)], tx = i % M.W + 0.5, ty = ((i / M.W) | 0) + 0.5;
          if (M.c[i] === 'L') continue;
          if (hyp(tx - M.z.x, ty - M.z.y) < 8 - tries / 100) continue;
          if (used.some((u) => hyp(u[0] - tx, u[1] - ty) < 2)) continue;
          x = tx; y = ty; break;
        }
        used.push([x, y]);
      }
      const al = s === W.al ? 1 : 0;
      W.pl.push({ x, y, a: rng() * TAU, vx: 0, vy: 0, z: al, alpha: al, zt: -1, tf: 0, stun: 0, dk: 0, ln: 0, la: 0, lcd: 0, slow: 0, sh: 0,
        it: -1, ic: 0, sv: 0, esc: 0, escT: 0, hz: 0, cd: 0, zat: 0, by: -1, trap: 0, pk: al ? 0 : PK_START, up: 0, rt: 0, cl: 0, cdir: 0, cli: -1, hd: 0,
        jb: al ? -1 : Math.floor(rng() * JB.length), ju: 0, rv: 0, sp: 0, run: 0, boost: 0, scared: 0, rev: 0, jp: 0, jd: 0, j0x: 0, j0y: 0, j1x: 0, j1y: 0, pry: 0, pc: 0 });
    }
    // half of the item spots start filled
    const spots = M.items.map((_, j) => j).sort(() => rng() - 0.5);
    for (let k = 0; k < Math.ceil(spots.length / 2); k++) W.gi.push({ s: spots[k], k: pickItem(rng) });
    return W;
  }
  function fx(W, code, x, y, a, b) { W.fxN++; W.fx.push([W.fxN, code, Math.round(x * 10), Math.round(y * 10), a | 0, b | 0]); if (W.fx.length > 24) W.fx.shift(); }
  const FX_INF = 1, FX_FLASH = 2, FX_TRAP = 3, FX_DOORX = 4, FX_ESC = 5, FX_BASH = 6, FX_DRINK = 7, FX_VAC = 8, FX_CLOSE = 9, FX_OPEN = 10, FX_TIER = 11, FX_PICK = 12, FX_SETTRAP = 13, FX_HELI = 14,
    FX_BAR = 15, FX_BARX = 16, FX_PRY = 17, FX_CLIMB = 18, FX_SLIP = 19, FX_LURE = 20, FX_RUN = 21, FX_SMASH = 22, FX_SNIFF = 23, FX_LEAP = 24, FX_LAND = 25, FX_SCREAM = 26, FX_ROOF = 27, FX_BARI = 28, FX_BARIX = 29, FX_SMOKE = 30, FX_RADIO = 31, FX_CURE = 32;
  const alive = (p) => !p.z && !p.esc;
  const hidden = (p) => !p.z && p.hd >= hideT(p);
  function zSpeed(W, p) { return (p.alpha ? alphaV(W) : (V_Z + Math.min(0.32, 0.055 * (W.nz - 1))) * (ZT[p.zt] ? ZT[p.zt].v : 1)) * (W.zv || 1); }
  // the alpha is a bit slower when there are only a few survivors to chase (fair at 2–4 players)
  function alphaV(W) { const n = W.pl.length - 1; return n <= 1 ? V_A - 0.65 : n === 2 ? V_A - 0.45 : n === 3 ? V_A - 0.3 : n <= 5 ? V_A - 0.15 : V_A; }
  function lungeCd(W, p) { return Math.max(2.4, (p.alpha ? LUNGE_CD_A + (W.pl.length <= 3 ? 1 : 0) : LUNGE_CD) - 0.15 * (W.nz - 1)); }
  function speedOf(W, p) {
    let v;
    if (p.z) { v = zSpeed(W, p); if (p.run > 0) v *= RUN_K; if (p.boost > 0) v *= BOOST_K; if (W.sm.length && !p.up && inSmoke(W, p.x, p.y)) v *= 0.8; }
    else { v = V_S * (p.jb === 1 ? SCOUT_K : 1); if (p.run > 0) v *= JOB_RUN_K; if (p.scared > 0) v *= 0.75; const ch = p.up ? '' : W.M.c[tileOf(W.M, p.x, p.y)]; if (ch === 'W') v *= 0.55; else if (ch === 'v') v *= VENT_K; }
    if (p.dk > 0) v *= DRINK_K;
    if (p.slow > 0) v *= 0.5;
    return v;
  }
  function heliOn(W) { // a living radio operator calls the rescue in 10 s early (once it is here it stays)
    if (!W.heli) return false; if (W.hOn) return true;
    return W.t >= START_T + W.len - HELI_T - (W.pl.some((p) => p.jb === 5 && alive(p)) ? RADIO_HELI : 0);
  }
  function doorMult(W) { return W.nz >= HORDE_N ? 2 : 1; }
  function gateNear(W, p, f, reach) {
    const M = W.M; let best = -1, bd = reach || REACH;
    for (let j = 0; j < M.gates.length; j++) {
      const G = M.gates[j]; if (!f(W.gate[j], G)) continue;
      const d = hyp(G.x - p.x, G.y - p.y); if (d < bd) { bd = d; best = j; }
    }
    return best;
  }
  function ladNear(W, p) {
    const M = W.M; let best = -1, bd = LAD_R;
    for (let j = 0; j < M.lads.length; j++) {
      const D = M.lads[j], d = p.up ? hyp(D.tx - p.x, D.ty - p.y) : hyp(D.x - p.x, D.y - p.y);
      if (d < bd) { bd = d; best = j; }
    }
    return best;
  }
  function exitAt(W, p) { // a roof edge right next to me I can jump down from
    const M = W.M, R = M.roofs[M.roofOf[tileOf(M, p.x, p.y)]]; if (!R) return null;
    let best = null, bv = 1.15;
    for (const e of R.ex) { const d = hyp(e.x - p.x, e.y - p.y) - 0.2 * Math.cos(Math.atan2(e.dy, e.dx) - p.a); if (d < bv) { bv = d; best = e; } }
    return best;
  }
  function gateClear(W, j) { const G = W.M.gates[j]; for (const q of W.pl) if (!q.esc && !q.up && Math.abs(q.x - G.x) < 0.5 + PR && Math.abs(q.y - G.y) < 0.5 + PR) return false; return true; }
  const blocked = (g) => g.s === 1 || g.b > 0 || g.lk > 0;
  const inSmoke = (W, x, y) => W.sm.some((S) => hyp(S.x - x, S.y - y) < SMOKE_R);
  // the big button
  function mainCtx(W, p) {
    if (p.esc || p.tf > 0 || p.cl > 0 || p.jp > 0) return null;
    if (!p.z || p.zt === 3 || p.up) {
      const j = ladNear(W, p);
      if (j >= 0) {
        if (p.up) return { k: 'down', j, ok: true };
        if (!p.z) return { k: 'up', j, ok: p.rt < ROOF_T - 0.5 };
        return { k: 'up', j, ok: W.t >= START_T };
      }
    }
    if (p.up) {
      const e = exitAt(W, p);
      if (e && (!p.z || !W.pl.some((q) => alive(q) && q.up && W.M.roofOf[tileOf(W.M, q.x, q.y)] === W.M.roofOf[e.t]))) return { k: 'jump', e, ok: true };
    }
    if (p.z) {
      if (!p.up) { const j = gateNear(W, p, blocked); if (j >= 0) return { k: 'bash', j, ok: p.cd <= 0 && W.gate[j].lk <= 0 }; }
      return { k: 'lunge', ok: W.t >= START_T && p.lcd <= 0 && p.ln <= 0 && p.stun <= 0 };
    }
    if (p.up) return null;
    const jc = gateNear(W, p, (g, G) => !G.win && g.b === 0 && !g.lk && g.s === 1); if (jc >= 0) return { k: 'open', j: jc, ok: true };
    const jo = gateNear(W, p, (g, G) => !G.win && g.b === 0 && !g.lk && g.s === 0 && g.cd <= 0);
    if (jo >= 0) return { k: 'close', j: jo, ok: gateClear(W, jo) };
    return null;
  }
  // survivor plank button
  function plankCtx(W, p) {
    if (p.z || p.up || p.esc || p.tf > 0 || p.cl > 0) return null;
    const j = gateNear(W, p, (g) => g.b < BAR_MAX * (p.jb === 0 ? FIX_K : 1) - 10 && !g.lk);
    if (j < 0) return { k: 'bar', j: -1, ok: false };
    const g = W.gate[j];
    return { k: g.b > 0 ? 'rein' : 'bar', j, ok: p.pk > 0 && p.pc <= 0 && (g.b > 0 || gateClear(W, j)) };
  }
  // survivor item / zombie special
  function skillCtx(W, p) {
    if (p.esc || p.tf > 0 || p.cl > 0 || p.jp > 0) return null;
    const go = W.t >= START_T;
    if (!p.z) {
      if (p.it === 0) return { k: 'drink', ok: p.dk <= 0 };
      if (p.it === 1) return { k: 'trap', ok: !p.up };
      if (p.it === 2) return { k: 'flash', ok: true };
      if (p.it === 3) return { k: 'vac', ok: false };
      if (p.it === 4) return { k: 'lure', ok: true };
      if (p.it === 6) { const j = p.up ? -1 : gateNear(W, p, (g) => !g.lk, REACH + 0.3); return { k: 'bari', j, ok: j >= 0 && (blocked(W.gate[j]) || gateClear(W, j)) }; }
      if (p.it === 7) return { k: 'smoke', ok: !p.up };
      const J = JB[p.jb]; if (p.it < 0 && J && J.act) return { k: 'job', ok: go && p.sp <= 0 && (p.jb !== 6 || !p.up) };
      return null;
    }
    if (p.alpha || p.zt < 0) return null;
    const rdy = go && p.sp <= 0 && p.stun <= 0;
    if (p.zt === 0) return { k: 'run', ok: rdy };
    if (p.zt === 1) { const j = p.up ? -1 : gateNear(W, p, (g) => blocked(g) && !g.lk, REACH + 0.2); return { k: 'smash', j, ok: rdy && j >= 0 }; }
    if (p.zt === 2) return { k: 'sniff', ok: rdy };
    if (p.zt === 3) return { k: 'leap', ok: rdy && p.ln <= 0 };
    return { k: 'scream', ok: rdy };
  }
  function damageGate(W, j, dmg) {
    const g = W.gate[j], G = W.M.gates[j];
    if (g.lk > 0) return;
    if (g.b > 0) { g.b -= dmg; if (g.b <= 0) { g.b = 0; updGate(W, j); fx(W, FX_BARX, G.x, G.y, j, 0); } }
    else if (g.s === 1) { g.hp -= dmg; if (g.hp <= 0) breakDoor(W, j); }
  }
  function breakDoor(W, j) { const g = W.gate[j]; g.s = 0; g.cd = DOOR_CD; g.hp = 0; updGate(W, j); fx(W, FX_DOORX, W.M.gates[j].x, W.M.gates[j].y, j, 0); }
  function leapTarget(W, p, a) {
    const M = W.M, ca = Math.cos(a), sa = Math.sin(a);
    for (let d = LEAP_D; d >= 0.9; d -= 0.2) {
      const x = p.x + ca * d, y = p.y + sa * d, n = Math.ceil(d * 4);
      let ok = true;
      for (let k = 1; k <= n && ok; k++) {
        const i = tileOf(M, p.x + ca * d * k / n, p.y + sa * d * k / n), ch = M.c[i];
        if (p.up) { if (ch !== 'B') ok = false; continue; }
        if (ch === '#' || ch === 'T' || ch === 'B') ok = false;
        const j = M.gateAt[i]; if (j >= 0 && !M.gates[j].win && W.gate[j].s === 1) ok = false;
      }
      if (ok && fitsAt(W, p, x, y)) return { x, y };
    }
    return null;
  }
  function lureLand(W, p, a) {
    const M = W.M, ca = Math.cos(a), sa = Math.sin(a);
    let ok = null;
    for (let d = 0.6; d <= LURE_D; d += 0.25) {
      const x = p.x + ca * d, y = p.y + sa * d;
      if (x < 0.6 || y < 0.6 || x > M.W - 0.6 || y > M.H - 0.6) break;
      const i = tileOf(M, x, y), ch = M.c[i];
      if (ch === '#' || ch === 'T' || (ch === 'B' && !p.up)) break;
      const j = M.gateAt[i]; if (j >= 0 && blocked(W.gate[j])) break;
      if (!(M.sol[i] & 2) && ch !== 'B' && j < 0) ok = { x: Math.floor(x) + 0.5, y: Math.floor(y) + 0.5 };
    }
    return ok;
  }
  function doMain(W, p, inp) {
    const c = mainCtx(W, p); if (!c || !c.ok) return;
    const M = W.M, me = W.pl.indexOf(p);
    p.hd = 0;
    if (c.k === 'up' || c.k === 'down') {
      const D = M.lads[c.j];
      p.cl = p.z ? CLIMB_Z : CLIMB_S; p.cdir = c.k === 'up' ? 1 : -1; p.cli = c.j; p.vx = p.vy = 0; p.ln = 0;
      if (c.k === 'up') { p.x = D.x; p.y = D.y; } else { p.x = D.tx; p.y = D.ty; }
      fx(W, FX_CLIMB, D.x, D.y, me, p.cdir > 0 ? 1 : 0);
    } else if (c.k === 'jump') {
      p.up = 0; p.jp = LEAP_T; p.jd = 1; p.j0x = p.x; p.j0y = p.y; p.j1x = c.e.x; p.j1y = c.e.y; p.vx = p.vy = 0; p.ln = 0;
      fx(W, FX_LEAP, p.x, p.y, me, 2);
    } else if (c.k === 'bash') {
      p.cd = 0.8; fx(W, FX_BASH, M.gates[c.j].x, M.gates[c.j].y, c.j, 0);
      damageGate(W, c.j, DOOR_BASH * doorMult(W) * (p.zt === 1 ? TANK_K : 1));
    } else if (c.k === 'lunge') {
      let a = p.a; if (hyp(inp.ax, inp.ay) > 0.2) a = Math.atan2(inp.ay, inp.ax);
      p.ln = LUNGE_T; p.la = a; p.a = a;
      p.lcd = lungeCd(W, p);
    } else if (c.k === 'open') { setDoor(W, c.j, 0); fx(W, FX_OPEN, M.gates[c.j].x, M.gates[c.j].y, c.j, 0); }
    else if (c.k === 'close') { setDoor(W, c.j, 1); W.gate[c.j].hp = DOOR_HP * (p.jb === 3 ? GUARD_K : 1); fx(W, FX_CLOSE, M.gates[c.j].x, M.gates[c.j].y, c.j, 0); }
  }
  function doPlank(W, p) {
    const c = plankCtx(W, p); if (!c || !c.ok) return;
    const g = W.gate[c.j], G = W.M.gates[c.j];
    const fk = p.jb === 0 ? FIX_K : 1; g.b = g.b > 0 ? Math.min(BAR_MAX * fk, g.b + BAR_ADD * fk) : BAR_HP * fk; p.pk--; p.pc = p.jb === 0 ? 0.25 : 0.5; p.hd = 0;
    updGate(W, c.j); fx(W, FX_BAR, G.x, G.y, W.pl.indexOf(p), c.k === 'rein' ? 1 : 0);
  }
  function doSkill(W, p, inp) {
    const c = skillCtx(W, p); if (!c || !c.ok) return;
    const M = W.M, me = W.pl.indexOf(p);
    p.hd = 0;
    if (!p.z) {
      if (c.k === 'drink') { p.dk = DRINK_T; p.it = -1; fx(W, FX_DRINK, p.x, p.y, me, 0); }
      else if (c.k === 'trap') { W.traps.push({ x: p.x, y: p.y, o: me }); if (W.traps.length > 8) W.traps.shift(); p.it = -1; fx(W, FX_SETTRAP, p.x, p.y, 0, 0); }
      else if (c.k === 'flash') {
        p.it = -1; let n = 0;
        for (const q of W.pl) if (q.z && !q.esc && q.tf <= 0 && q.up === p.up && hyp(q.x - p.x, q.y - p.y) < FLASH_R && losP(W, p, q)) { q.stun = Math.max(q.stun, FLASH_T * (q.zt === 1 ? 0.5 : 1)); q.ln = 0; n++; }
        fx(W, FX_FLASH, p.x, p.y, me, n);
      } else if (c.k === 'lure') {
        const a = fin(inp.ta) ? inp.ta : p.a, L0 = lureLand(W, p, a);
        if (!L0) return;
        W.lu.push({ x: L0.x, y: L0.y, t: LURE_T }); if (W.lu.length > 3) W.lu.shift();
        p.it = -1; fx(W, FX_LURE, L0.x, L0.y, me, Math.round(wrapA(a) * 10));
      } else if (c.k === 'bari') {
        const g = W.gate[c.j], G = M.gates[c.j]; g.lk = BARI_T; updGate(W, c.j); p.it = -1; fx(W, FX_BARI, G.x, G.y, me, c.j);
      } else if (c.k === 'job') {
        p.sp = JB[p.jb].act;
        if (p.jb === 4) { p.run = JOB_RUN_T; fx(W, FX_RUN, p.x, p.y, me, 1); }
        else if (p.jb === 5) { p.rv = RADIO_T; fx(W, FX_RADIO, p.x, p.y, me, 0); }
        else if (p.jb === 6) { W.traps.push({ x: p.x, y: p.y, o: me }); if (W.traps.length > 8) W.traps.shift(); fx(W, FX_SETTRAP, p.x, p.y, 0, 0); }
      } else if (c.k === 'smoke') {
        W.sm.push({ x: p.x, y: p.y, t: SMOKE_T }); if (W.sm.length > 3) W.sm.shift(); p.it = -1; fx(W, FX_SMOKE, p.x, p.y, me, 0);
      }
      return;
    }
    p.sp = ZT[p.zt].cd;
    if (c.k === 'run') { p.run = RUN_T; fx(W, FX_RUN, p.x, p.y, me, 0); }
    else if (c.k === 'smash') {
      const g = W.gate[c.j], G = M.gates[c.j]; g.b = 0;
      if (g.s === 1) breakDoor(W, c.j); else updGate(W, c.j);
      fx(W, FX_SMASH, G.x, G.y, me, c.j);
    } else if (c.k === 'sniff') {
      let n = 0; for (const q of W.pl) if (alive(q) && hyp(q.x - p.x, q.y - p.y) < SNIFF_R) { q.rev = Math.max(q.rev, SNIFF_T); n++; }
      fx(W, FX_SNIFF, p.x, p.y, me, n);
    } else if (c.k === 'leap') {
      let a = p.a; if (fin(inp.ta)) a = inp.ta; else if (hyp(inp.ax, inp.ay) > 0.2) a = Math.atan2(inp.ay, inp.ax);
      const T = leapTarget(W, p, a); p.a = a;
      if (!T) { p.ln = LUNGE_T; p.la = a; fx(W, FX_LEAP, p.x, p.y, me, 0); return; }
      p.jp = LEAP_T; p.j0x = p.x; p.j0y = p.y; p.j1x = T.x; p.j1y = T.y; p.ln = 0; p.vx = p.vy = 0;
      fx(W, FX_LEAP, p.x, p.y, me, 1);
    } else if (c.k === 'scream') {
      let n = 0;
      for (const q of W.pl) {
        if (q.esc) continue;
        const d = hyp(q.x - p.x, q.y - p.y);
        if (q.z && d < CALL_R) q.boost = BOOST_T;
        else if (!q.z && d < SCREAM_R) { q.rev = Math.max(q.rev, REV_T); q.scared = SCARE_T; q.hd = 0; n++; }
      }
      fx(W, FX_SCREAM, p.x, p.y, me, n);
    }
  }
  function movePl(W, p, inp, h) {
    let tx = 0, ty = 0, v;
    if (p.ln > 0) { v = V_LUNGE; tx = Math.cos(p.la) * v; ty = Math.sin(p.la) * v; p.vx = tx; p.vy = ty; }
    else {
      v = speedOf(W, p);
      let ax = fin(inp.ax) ? inp.ax : 0, ay = fin(inp.ay) ? inp.ay : 0; const m = hyp(ax, ay); if (m > 1) { ax /= m; ay /= m; }
      tx = ax * v; ty = ay * v;
      const k = Math.min(1, ACC * h / Math.max(1, v));
      p.vx += (tx - p.vx) * k; p.vy += (ty - p.vy) * k;
      if (m > 0.15) p.a = wrapA(p.a + wrapA(Math.atan2(ay, ax) - p.a) * Math.min(1, h * 14));
    }
    p.x += p.vx * h; resolve(W, p); p.y += p.vy * h; resolve(W, p);
  }
  function finishClimb(W, p) {
    const D = W.M.lads[p.cli]; p.cl = 0;
    if (!D) return;
    if (p.cdir > 0) { p.up = 1; p.x = D.tx; p.y = D.ty; if (!p.z) fx(W, FX_ROOF, D.tx, D.ty, W.pl.indexOf(p), 0); }
    else { p.up = 0; p.x = D.x; p.y = D.y; }
    p.cdir = 0; p.vx = p.vy = 0; p.hd = 0;
  }
  const NOIN = { ax: 0, ay: 0, act: 0, pl: 0, sk: 0 };
  function stepWorld(W, h, I) {
    const M = W.M;
    W.t += h;
    const go = W.t >= START_T;
    if (go && W.t - h < START_T) for (const p of W.pl) if (!p.z && p.jb === 0) p.pk = Math.min(PK_MAX, p.pk + 1); // repairer: one extra plank
    for (const D of W.gate) if (D.cd > 0) D.cd -= h;
    W.gate.forEach((D, j) => { if (D.lk > 0) { D.lk -= h; if (D.lk <= 0) { D.lk = 0; updGate(W, j); fx(W, FX_BARIX, M.gates[j].x, M.gates[j].y, j, 0); } } });
    for (let k = W.sm.length - 1; k >= 0; k--) { W.sm[k].t -= h; if (W.sm[k].t <= 0) W.sm.splice(k, 1); }
    W.pl.forEach((p, i) => {
      if (p.esc) return;
      const inp = I[i] || NOIN;
      p.stun = Math.max(0, p.stun - h); p.dk = Math.max(0, p.dk - h); p.lcd = Math.max(0, p.lcd - h); p.slow = Math.max(0, p.slow - h);
      p.sh = Math.max(0, p.sh - h); p.cd = Math.max(0, p.cd - h); p.tf = Math.max(0, p.tf - h); p.sp = Math.max(0, p.sp - h);
      p.run = Math.max(0, p.run - h); p.rv = Math.max(0, p.rv - h); p.boost = Math.max(0, p.boost - h); p.scared = Math.max(0, p.scared - h); p.rev = Math.max(0, p.rev - h); p.pc = Math.max(0, p.pc - h);
      if (p.ln > 0) { p.ln -= h; if (p.ln <= 0) { p.ln = 0; p.slow = MISS_T; } }
      let frozen = p.tf > 0 || p.stun > 0 || (p.z && !go);
      if (p.cl > 0) { frozen = true; p.vx = p.vy = 0; p.cl -= h; if (p.cl <= 0) finishClimb(W, p); }
      else if (p.jp > 0) {
        frozen = true; p.jp -= h;
        const k = clamp(1 - p.jp / LEAP_T, 0, 1);
        p.x = p.j0x + (p.j1x - p.j0x) * k; p.y = p.j0y + (p.j1y - p.j0y) * k;
        if (p.jp <= 0) { p.jp = 0; p.x = p.j1x; p.y = p.j1y; resolve(W, p); if (p.jd) { p.jd = 0; p.stun = Math.max(p.stun, 0.3); } fx(W, FX_LAND, p.x, p.y, i, 0); }
      } else if (frozen) { p.vx = 0; p.vy = 0; p.ln = 0; }
      else movePl(W, p, inp, h);
      if (inp.act) { inp.act = 0; if (!frozen) doMain(W, p, inp); }
      if (inp.pl) { inp.pl = 0; if (!frozen) doPlank(W, p); }
      if (inp.sk) { inp.sk = 0; if (!frozen) doSkill(W, p, inp); }
      const m = hyp(inp.ax || 0, inp.ay || 0);
      // pushing into a closed door / barricade: zombies slowly break it, survivors pry the planks off
      let pj = -1;
      if (!frozen && !p.up && m > 0.3) { const j = M.gateAt[tileOf(M, p.x + inp.ax / m * 0.75, p.y + inp.ay / m * 0.75)]; if (j >= 0) pj = j; }
      if (p.z) { if (pj >= 0 && blocked(W.gate[pj])) damageGate(W, pj, DOOR_PUSH * doorMult(W) * h * (p.zt === 1 ? TANK_K : 1)); }
      else if (pj >= 0 && W.gate[pj].b > 0) {
        p.pry += h;
        if (p.pry >= PRY_T * (p.jb === 0 ? 0.5 : 1)) { const G = M.gates[pj]; W.gate[pj].b = 0; updGate(W, pj); p.pk = Math.min(PK_MAX, p.pk + 1); p.pry = 0; fx(W, FX_PRY, G.x, G.y, i, pj); }
      } else p.pry = 0;
      if (!p.z) {
        // hiding: stand (almost) still in a hiding spot
        if (!p.up && !p.cl && M.c[tileOf(M, p.x, p.y)] === 'h' && hyp(p.vx, p.vy) < 1.0) p.hd += h;
        else if (!p.up && W.sm.length && inSmoke(W, p.x, p.y)) p.hd = HIDE_T; // hidden inside smoke, even while moving
        else p.hd = 0;
        // roof time runs out → you slide down the ladder
        if (p.up) {
          p.rt += h;
          if (p.rt >= ROOF_T && !p.cl) {
            const R = M.roofs[M.roofOf[tileOf(M, p.x, p.y)]];
            let best = null, bd = 1e9;
            for (const e of R ? R.ex : []) { const d = hyp(e.x - p.x, e.y - p.y); if (d < bd) { bd = d; best = e; } }
            if (best) { p.up = 0; p.x = best.x; p.y = best.y; p.vx = p.vy = 0; p.stun = SLIP_T; fx(W, FX_SLIP, best.x, best.y, i, 0); }
          }
        }
      }
    });
    if (go) {
      // catches
      for (let zi = 0; zi < W.pl.length; zi++) {
        const z = W.pl[zi]; if (!z.z || z.esc || z.tf > 0 || z.stun > 0 || z.cl > 0 || z.jp > 0) continue;
        for (let si = 0; si < W.pl.length; si++) {
          const s = W.pl[si]; if (!alive(s) || s.sh > 0 || s.jp > 0 || s.up !== z.up) continue;
          if (hyp(s.x - z.x, s.y - z.y) > CATCH) continue;
          if (!losP(W, z, s)) continue;
          if (s.it === 3) { s.it = -1; s.sh = VAC_T; z.stun = VAC_STUN; z.ln = 0; fx(W, FX_VAC, s.x, s.y, si, zi); continue; }
          if (s.jb === 2 && !s.ju) { s.ju = 1; s.sp = MED_T; s.sh = MED_T; s.by = zi; z.ln = 0; z.stun = 0.4; fx(W, FX_CURE, s.x, s.y, si, zi); continue; }
          infect(W, s, zi);
        }
      }
      // medic: the delayed infection sets in (unless they got out on the rescue first)
      for (const p of W.pl) if (alive(p) && p.jb === 2 && p.ju && p.sp <= 0) infect(W, p, p.by >= 0 && W.pl[p.by] ? p.by : W.al);
      // traps (leapers in the air fly over)
      for (let k = W.traps.length - 1; k >= 0; k--) {
        const T = W.traps[k];
        for (const z of W.pl) if (z.z && !z.esc && !z.up && z.jp <= 0 && z.tf <= 0 && hyp(z.x - T.x, z.y - T.y) < 0.45) { z.stun = Math.max(z.stun, TRAP_T * (z.zt === 1 ? 0.5 : 1)); z.ln = 0; z.trap = 1; z.run = 0; fx(W, FX_TRAP, T.x, T.y, 0, 0); W.traps.splice(k, 1); break; }
      }
      for (const p of W.pl) if (p.trap && p.stun <= 0) p.trap = 0;
    }
    for (let k = W.lu.length - 1; k >= 0; k--) { W.lu[k].t -= h; if (W.lu[k].t <= 0) W.lu.splice(k, 1); }
    // items
    for (let k = W.gi.length - 1; k >= 0; k--) {
      const G = W.gi[k], S = M.items[G.s];
      for (let i = 0; i < W.pl.length; i++) {
        const p = W.pl[i]; if (!alive(p) || p.up || hyp(p.x - S.x, p.y - S.y) > 0.6) continue;
        if (G.k === 5) { if (p.pk >= PK_MAX) continue; p.pk = Math.min(PK_MAX, p.pk + 2); }
        else { if (p.it >= 0) continue; p.it = G.k; }
        W.gi.splice(k, 1); fx(W, FX_PICK, S.x, S.y, i, G.k); break;
      }
    }
    W.itT -= h;
    if (W.itT <= 0) {
      W.itT = 10;
      if (W.gi.length < Math.ceil(M.items.length / 2)) {
        const free = M.items.map((_, j) => j).filter((j) => !W.gi.some((g) => g.s === j) && !W.pl.some((p) => !p.esc && hyp(p.x - M.items[j].x, p.y - M.items[j].y) < 3));
        if (free.length) W.gi.push({ s: free[Math.floor(Math.random() * free.length)], k: pickItem(Math.random) });
      }
    }
    // rescue (last 30 s)
    if (heliOn(W)) {
      if (!W.hF) { W.hF = 1; W.hOn = 1; fx(W, FX_HELI, M.hz.x, M.hz.y, 0, 0); }
      W.pl.forEach((p, i) => {
        if (!alive(p) || p.up || p.cl) return;
        if (hyp(p.x - M.hz.x, p.y - M.hz.y) < HELI_R) { p.hz += h; if (p.hz >= HELI_STAY) { p.esc = 1; p.escT = W.t; p.vx = p.vy = 0; fx(W, FX_ESC, p.x, p.y, i, 0); } }
        else p.hz = 0;
      });
    }
    if (go) for (const p of W.pl) if (alive(p)) p.sv += h;
    // end?
    if (!W.res) {
      const left = W.pl.filter((p) => !p.z).length;
      if (!left) W.res = { win: 1, t: W.t };
      else if (W.t >= START_T + W.len) W.res = { win: 0, t: W.t };
      else if (W.pl.every((p) => p.z || p.esc)) W.res = { win: 0, t: W.t };
    }
  }
  function infect(W, s, zi) {
    const z = W.pl[zi], si = W.pl.indexOf(s);
    s.z = 1; s.zt = Math.floor(Math.random() * ZT.length); s.tf = TF_T; s.zat = W.t; s.by = zi; s.it = -1; s.dk = 0; s.ln = 0; s.hd = 0; s.rev = 0; s.scared = 0; s.cl = 0; s.pk = 0; s.run = 0; s.rv = 0; s.sh = 0;
    if (s.up) { s.up = 0; const R = W.M.roofs[W.M.roofOf[tileOf(W.M, s.x, s.y)]], e = R && R.ex[0]; if (e) { s.x = e.x; s.y = e.y; } }
    s.sp = 3; if (z) { z.ic++; z.ln = 0; }
    const was = W.nz; W.nz++;
    fx(W, FX_INF, s.x, s.y, si, zi * 8 + s.zt);
    if ((was < SMELL_N && W.nz >= SMELL_N) || (was < HORDE_N && W.nz >= HORDE_N)) fx(W, FX_TIER, 0, 0, W.nz >= HORDE_N ? 2 : 1, 0);
  }
  function tickWorld(W, dt, I) {
    let n = Math.max(1, Math.ceil(dt / (1 / 60)));
    const h = dt / n;
    while (n-- > 0 && !W.res) stepWorld(W, h, I);
  }
  function roundRows(W) {
    const end = START_T + W.len, surv = W.pl.filter((p) => !p.z), last = surv.length === 1 ? W.pl.indexOf(surv[0]) : -1;
    return W.pl.map((p, i) => {
      let sv = p.sv; if (p.esc) sv += Math.max(0, end - p.escT);
      const ok = !p.z;
      const pts = Math.floor(sv / PT_SEC) + (ok ? PT_SURV : 0) + (i === last ? PT_LAST : 0) + p.ic * PT_INF;
      const oc = p.alpha ? 3 : p.esc ? 1 : ok ? 0 : 2;
      return [i, pts, oc, p.ic, Math.round(sv)];
    });
  }

  /* ---------- AI ---------- */
  function field(W, srcs, mask, dc, bc, maxD) { // Dial's algorithm on the tile grid; closed doors / barricades cost extra
    const M = W.M, N = M.N, d = new Int16Array(N).fill(32767), B = [];
    for (let k = 0; k < 16; k++) B.push([]);
    let pend = 0;
    for (const s of srcs) if (s >= 0 && s < N && d[s] > 0) { d[s] = 0; B[0].push(s); pend++; }
    let cur = 0; const Wd = M.W;
    while (pend > 0 && cur <= maxD) {
      const b = B[cur & 15];
      if (!b.length) { cur++; continue; }
      const i = b.pop(); pend--;
      if (d[i] !== cur) continue;
      const x = i % Wd;
      for (let k = 0; k < 4; k++) {
        const n = k === 0 ? (x > 0 ? i - 1 : -1) : k === 1 ? (x < Wd - 1 ? i + 1 : -1) : k === 2 ? i - Wd : i + Wd;
        if (n < 0 || n >= N || (M.sol[n] & mask)) continue;
        const gj = M.gateAt[n]; let w = 1;
        if (gj >= 0) { const g = W.gate[gj]; if (g.lk > 0) w = 99; else if (g.b > 0) w = bc; else if (g.s === 1) w = dc; else if (M.gates[gj].win && mask === 1) w = 2; }
        if (w > 15) continue;
        const nd = cur + w;
        if (nd < d[n]) { d[n] = nd; B[nd & 15].push(n); pend++; }
      }
    }
    return d;
  }
  function descend(W, f, i, mask) { // best neighbour (8-way, no corner cutting)
    const M = W.M, Wd = M.W, x = i % Wd, y = (i / Wd) | 0;
    let best = i, bv = f[i];
    const free = (tx, ty) => tx >= 0 && ty >= 0 && tx < Wd && ty < M.H && !(M.sol[ty * Wd + tx] & mask);
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
      if (!dx && !dy) continue;
      const tx = x + dx, ty = y + dy; if (!free(tx, ty)) continue;
      if (dx && dy) { if (!free(x + dx, y) || !free(x, y + dy)) continue; if (M.gateAt[ty * Wd + tx] >= 0 || M.gateAt[y * Wd + x + dx] >= 0 || M.gateAt[(y + dy) * Wd + x] >= 0) continue; }
      const n = ty * Wd + tx, v = f[n] + (dx && dy ? 0.4 : 0);
      if (v < bv) { bv = v; best = n; }
    }
    return best;
  }
  function zField(W) { // shared distance-from-zombies map for survivors (refreshed every 0.25 s)
    if (W.zf && W.t - W.zfT < 0.25) return W.zf;
    const src = []; for (const p of W.pl) if (p.z && !p.esc && !p.up && p.tf < 0.8) src.push(tileOf(W.M, p.x, p.y));
    W.zf = field(W, src, 2, 7, 9, 60); W.zfT = W.t; return W.zf;
  }
  // levels: sense radius, replan interval, speed factor, mistakes, skill eagerness, how much a noise maker fools them
  const ZD = [{ r: 6, rp: 0.6, sp: 0.86, lu: 0.25, lr: 1.4, sk: 0.25, lure: -4 }, { r: 9, rp: 0.35, sp: 0.96, lu: 0.65, lr: 1.6, sk: 0.6, lure: 3 }, { r: 14, rp: 0.22, sp: 1, lu: 0.7, lr: 1.6, sk: 0.9, lure: 8 }];
  const SD = [{ r: 5, rp: 0.6, sp: 0.9, door: 0.12, dead: 0, top: 6, bar: 0.12, roof: 0.15, lad: 3, hide: 0.05 },
    { r: 8, rp: 0.35, sp: 0.97, door: 0.55, dead: 4, top: 2, bar: 0.5, roof: 0.35, lad: 5, hide: 0.25 },
    { r: 11, rp: 0.22, sp: 1, door: 0.9, dead: 9, top: 1, bar: 0.85, roof: 0.5, lad: 7, hide: 0.35 }];
  function newI() { return { ax: 0, ay: 0, act: 0, pl: 0, sk: 0, ta: null }; }
  function steerTo(W, p, I, tx, ty, sp) {
    const dx = tx - p.x, dy = ty - p.y, d = hyp(dx, dy);
    if (d < 0.05) { I.ax = 0; I.ay = 0; return; }
    I.ax = dx / d * sp; I.ay = dy / d * sp;
  }
  function unstick(m, p, I, dt) {
    m.sk = (m.sk || 0) + dt;
    if (m.jit > 0) { m.jit -= dt; I.ax = Math.cos(m.ja); I.ay = Math.sin(m.ja); return true; }
    if (m.sk > 0.8) {
      const moved = hyp(p.x - (m.lx || 0), p.y - (m.ly || 0)); m.sk = 0; m.lx = p.x; m.ly = p.y;
      if (moved < 0.15 && hyp(I.ax, I.ay) > 0.3) { m.jit = 0.35; m.ja = Math.atan2(I.ay, I.ax) + (Math.random() < 0.5 ? 1.7 : -1.7); m.rt = 0; }
    }
    return false;
  }
  function tc(M, i) { return [i % M.W + 0.5, ((i / M.W) | 0) + 0.5]; }
  function roofLadder(W, rid, x, y, f) { // the ladder of a roof that is closest (by field f, else straight distance)
    const R = W.M.roofs[rid]; if (!R) return null;
    let best = null, bv = 1e9;
    for (const j of R.lads) { const D = W.M.lads[j], v = f ? f[D.i] : hyp(D.x - x, D.y - y); if (v < bv) { bv = v; best = D; } }
    return best;
  }
  function zSees(W, p, q, lv, D, smell) {
    if (q.jb === 2 && q.ju && q.sh > 0) return false; // already bitten medic: leave them, they turn soon
    if (q.rev > 0) return true;
    const e = hyp(q.x - p.x, q.y - p.y);
    if (hidden(q)) return e < (p.zt === 2 ? 3 : (q.jb === 7 ? SNEAK_SEE : HIDE_SEE) + (lv === 3 ? 0.4 : 0));
    const ear = q.jb === 1 ? SCOUT_EAR : 1;
    if (q.up || p.up) return e < D.r;
    return e < (D.r + (smell ? 5 : 0)) * ear && (lv >= 2 || e < 3 || los(W, p.x, p.y, q.x, q.y));
  }
  function aiZombie(W, p, m, lv, dt) {
    const D = ZD[lv - 1], M = W.M, I = newI(), me = W.pl.indexOf(p);
    if (p.tf > 0 || p.stun > 0 || W.t < START_T || p.cl > 0 || p.jp > 0) return I;
    const smell = W.nz >= SMELL_N || p.zt === 2, mask = maskOf(p), dc = p.zt === 1 ? 4 : 7, bc = p.zt === 1 ? 4 : 9;
    m.rt = (m.rt || 0) - dt;
    let tg = m.tg >= 0 ? W.pl[m.tg] : null; if (tg && !alive(tg)) { tg = null; m.tg = -1; m.rt = 0; }
    if (p.up) { // on a roof: chase anyone up here, otherwise climb back down
      const rid = M.roofOf[tileOf(M, p.x, p.y)];
      if (m.rt <= 0) {
        m.rt = D.rp; let best = -1, bd = 1e9;
        W.pl.forEach((q, i) => { if (!alive(q) || !q.up || M.roofOf[tileOf(M, q.x, q.y)] !== rid) return; const d = hyp(q.x - p.x, q.y - p.y); if (d < bd) { bd = d; best = i; } });
        m.tg = best; p.aiT = best; tg = best >= 0 ? W.pl[best] : null;
      }
      if (tg && tg.up) {
        steerTo(W, p, I, tg.x, tg.y, D.sp);
        const d = hyp(tg.x - p.x, tg.y - p.y);
        if (ladNear(W, p) < 0 && p.lcd <= 0 && d < D.lr && d > 0.5 && Math.random() < D.lu * dt * 8) I.act = 1;
      } else {
        // the ladder whose foot is closest to a survivor
        const R = M.roofs[rid]; let bl = null, bv = 1e9;
        if (R) for (const j of R.lads) { const Ld = M.lads[j]; let v = hyp(Ld.tx - p.x, Ld.ty - p.y); for (const q of W.pl) if (alive(q) && !q.up) v = Math.min(v, hyp(q.x - Ld.x, q.y - Ld.y) + 3); if (v < bv) { bv = v; bl = Ld; } }
        if (R) for (const e of R.ex) { let v = 1e9; for (const q of W.pl) if (alive(q) && !q.up) v = Math.min(v, hyp(q.x - e.x, q.y - e.y)); v += hyp(e.x - p.x, e.y - p.y); if (v < bv) { bv = v; bl = { tx: e.t % M.W + 0.5 + e.dx * 0.3, ty: ((e.t / M.W) | 0) + 0.5 + e.dy * 0.3, e: 1 }; } }
        if (bl) { steerTo(W, p, I, bl.tx, bl.ty, D.sp); if (hyp(bl.tx - p.x, bl.ty - p.y) < (bl.e ? 0.2 : LAD_R * 0.8)) I.act = 1; }
      }
      unstick(m, p, I, dt);
      return I;
    }
    if (m.rt <= 0) {
      m.rt = D.rp * (0.8 + Math.random() * 0.4);
      const here = tileOf(M, p.x, p.y), fz = field(W, [here], mask, dc, bc, 80);
      let best = -1, bv = 1e9, bgt = -1;
      W.pl.forEach((q, i) => {
        if (!alive(q)) return;
        const seen = zSees(W, p, q, lv, D, smell);
        if (!seen && (hidden(q) || !(smell && lv >= 2))) return;
        let gt, extra = 0;
        if (q.up) { const Ld = roofLadder(W, M.roofOf[tileOf(M, q.x, q.y)], p.x, p.y, fz); if (!Ld) return; gt = Ld.i; extra = p.zt === 3 ? 2 : 9; }
        else gt = tileOf(M, q.x, q.y);
        let v = fz[gt] + extra + (seen ? 0 : 8);
        if (lv === 3) { for (let k = 0; k < W.pl.length; k++) if (k !== me && W.pl[k].z && W.pl[k].aiT === i) v += 4; v -= 2 * M.dead[gt]; if (q.it === 3) v += 3; }
        if (i === m.tg) v -= 2;
        if (v < bv) { bv = v; best = i; bgt = gt; }
      });
      // a ringing noise maker pulls zombies that aren't locked on someone close
      let lure = -1;
      W.lu.forEach((Lr, k) => { if (Lr.t < 0.8 || hyp(Lr.x - p.x, Lr.y - p.y) > LURE_R) return; const v = fz[tileOf(M, Lr.x, Lr.y)] + D.lure; if (v < bv) { bv = v; lure = k; } });
      if (lure >= 0) { const Lr = W.lu[lure]; best = -1; m.md = 'lure'; m.gl = tileOf(M, Lr.x, Lr.y); m.f = field(W, [m.gl], mask, dc, bc, 120); m.wg = -1; }
      else if (best >= 0) { m.md = W.pl[best].up ? 'lad' : 'chase'; m.gl = bgt; m.f = field(W, [bgt], mask, dc, bc, 120); m.wg = -1; }
      else {
        m.md = 'wander';
        if (!(m.wg >= 0) || here === m.wg || Math.random() < 0.08) {
          m.wg = Math.random() < 0.5 ? M.items[Math.floor(Math.random() * M.items.length)].i : M.walk[Math.floor(Math.random() * M.walk.length)];
          m.f = field(W, [m.wg], mask, dc, bc, 120);
        }
      }
      m.tg = best; p.aiT = best;
      tg = best >= 0 ? W.pl[best] : null;
    }
    if (!m.f) return I;
    const cur = tileOf(M, p.x, p.y);
    const td = tg ? hyp(tg.x - p.x, tg.y - p.y) : 99;
    if (tg && !tg.up && td < 2.6 && los(W, p.x, p.y, tg.x, tg.y)) {
      const lead = lv === 3 ? 0.25 : 0;
      steerTo(W, p, I, tg.x + tg.vx * lead, tg.y + tg.vy * lead, D.sp);
      if (p.lcd <= 0 && td < D.lr && td > 0.5 && Math.random() < D.lu * dt * 8) I.act = 1;
    } else if (m.md === 'lad' && tg && tg.up && ladNear(W, p) >= 0 && M.lads[ladNear(W, p)].r === M.roofOf[tileOf(M, tg.x, tg.y)]) {
      // at the foot of their ladder: leapers climb, the rest wait below
      if (p.zt === 3) I.act = 1;
      else { const Ld = M.lads[ladNear(W, p)]; steerTo(W, p, I, Ld.x, Ld.y, 0.4); }
    } else {
      const nx = descend(W, m.f, cur, mask);
      const [cx, cy] = tc(M, nx === cur ? cur : nx);
      steerTo(W, p, I, cx, cy, D.sp);
      const dj = M.gateAt[nx];
      if (dj >= 0 && blocked(W.gate[dj]) && !W.gate[dj].lk && p.cd <= 0) I.act = 1;
      if (m.md === 'lad' && p.zt === 3 && ladNear(W, p) >= 0) I.act = 1;
    }
    // special skills
    const sc = skillCtx(W, p);
    if (sc && sc.ok && Math.random() < D.sk * dt * 6) {
      let use = lv === 1 && Math.random() < 0.2;
      if (sc.k === 'run') use = use || (tg && !tg.up && td > 1.2 && td < 7 && (lv === 1 || los(W, p.x, p.y, tg.x, tg.y)));
      else if (sc.k === 'smash') use = true;
      else if (sc.k === 'sniff') use = use || !tg || td > 6 || W.pl.some((q) => alive(q) && hidden(q) && hyp(q.x - p.x, q.y - p.y) < SNIFF_R * 0.7);
      else if (sc.k === 'leap') {
        use = false;
        if (tg && !tg.up && td > 1.3 && td < 3.4) {
          const a = Math.atan2(tg.y - p.y, tg.x - p.x), T = leapTarget(W, p, a);
          if (T && hyp(T.x - tg.x, T.y - tg.y) < td - 0.8) { use = true; I.ta = a; }
        }
      } else if (sc.k === 'scream') { let n = 0; for (const q of W.pl) if (alive(q) && !q.up && hyp(q.x - p.x, q.y - p.y) < SCREAM_R) n++; use = use || n >= 1; }
      if (use) I.sk = 1;
    }
    unstick(m, p, I, dt);
    return I;
  }
  function sPath(W, start, maxD, zf, minZ, race) { // BFS for a survivor that avoids tiles next to zombies (race: only tiles I reach first)
    const M = W.M, N = M.N, d = new Int16Array(N).fill(-1), par = new Int32Array(N).fill(-1), q = [start], Wd = M.W;
    d[start] = 0;
    for (let h = 0; h < q.length; h++) {
      const i = q[h]; if (d[i] >= maxD) continue;
      const x = i % Wd;
      for (let k = 0; k < 4; k++) {
        const n = k === 0 ? (x > 0 ? i - 1 : -1) : k === 1 ? (x < Wd - 1 ? i + 1 : -1) : k === 2 ? i - Wd : i + Wd;
        if (n < 0 || n >= N || (M.sol[n] & 1) || d[n] >= 0) continue;
        const gj = M.gateAt[n]; if (gj >= 0 && (W.gate[gj].b > 0 || W.gate[gj].lk > 0)) continue;
        if (zf && zf[n] < minZ) continue;
        if (race && zf[n] - (d[i] + 1) * 0.9 < race) continue;
        d[n] = d[i] + 1; par[n] = i; q.push(n);
      }
    }
    return { d, par, q };
  }
  function clearLine(W, p, x0, y0, x1, y1) { // can a body walk straight from a to b?
    const d = hyp(x1 - x0, y1 - y0), n = Math.ceil(d * 4), r = PR + 0.04;
    for (let k = 1; k <= n; k++) {
      const x = x0 + (x1 - x0) * k / n, y = y0 + (y1 - y0) * k / n;
      if (solidP(W, p, Math.floor(x - r), Math.floor(y - r)) || solidP(W, p, Math.floor(x + r), Math.floor(y - r)) || solidP(W, p, Math.floor(x - r), Math.floor(y + r)) || solidP(W, p, Math.floor(x + r), Math.floor(y + r))) return false;
    }
    return true;
  }
  function pathTo(par, goal) { const out = []; let i = goal; while (i >= 0 && out.length < 200) { out.push(i); i = par[i]; } out.reverse(); return out; }
  function bestLure(W, p, zq) { // AI: throw the noise maker where it pulls zombies away from me
    let best = null, bs = -1e9;
    for (let k = 0; k < 8; k++) {
      const a = k * TAU / 8 + 0.2, Lp = lureLand(W, p, a); if (!Lp) continue;
      const dm = hyp(Lp.x - p.x, Lp.y - p.y); if (dm < 2.5) continue;
      const s = dm - (zq ? 0.8 * hyp(Lp.x - zq.x, Lp.y - zq.y) : 0);
      if (s > bs) { bs = s; best = a; }
    }
    return best;
  }
  function aiRoof(W, p, m, lv, I, zf) {
    const D = SD[lv - 1], M = W.M, rid = M.roofOf[tileOf(M, p.x, p.y)], R = M.roofs[rid];
    if (!R) return I;
    let threat = false;
    for (const q of W.pl) {
      if (!q.z || q.esc || q.tf > 0) continue;
      if (q.up) { if (M.roofOf[tileOf(M, q.x, q.y)] === rid) threat = true; }
      else if (q.zt === 3 && lv >= 2) { for (const j of R.lads) if (hyp(M.lads[j].x - q.x, M.lads[j].y - q.y) < 2.5) threat = true; }
    }
    let ladZ = 1e9; for (const j of R.lads) ladZ = Math.min(ladZ, zf[M.lads[j].i]);
    const late = p.rt > ROOF_T - (lv === 1 ? 0.8 : 2.5);
    // noise maker from the roof to clear the ladder
    if (p.it === 4 && lv >= 2 && ladZ < 5 && p.rt > ROOF_T * 0.4) {
      let best = null, bs = -1;
      for (let k = 0; k < 8; k++) {
        const a = k * TAU / 8, Lp = lureLand(W, p, a); if (!Lp) continue;
        let s = 1e9; for (const j of R.lads) s = Math.min(s, hyp(Lp.x - M.lads[j].x, Lp.y - M.lads[j].y));
        if (s > bs) { bs = s; best = a; }
      }
      if (best != null && bs > 3.5) { I.sk = 1; I.ta = best; }
    }
    const goDown = threat || late || (lv >= 2 && p.rt > 3 && ladZ > 9) || heliOn(W) && lv >= 2 && ladZ > 4;
    if (goDown) {
      let bl = null, bv = -1e9;
      for (const j of R.lads) { const Ld = M.lads[j], v = lv === 1 ? -hyp(Ld.tx - p.x, Ld.ty - p.y) : Math.min(zf[Ld.i], 20) - 0.3 * hyp(Ld.tx - p.x, Ld.ty - p.y); if (v > bv) { bv = v; bl = Ld; } }
      if (lv >= 2) for (const e of R.ex) {
        const tx = e.t % M.W + 0.5 + e.dx * 0.3, ty = ((e.t / M.W) | 0) + 0.5 + e.dy * 0.3;
        const v = Math.min(zf[e.n], 20) - 0.3 * hyp(tx - p.x, ty - p.y) - 0.5;
        if (v > bv) { bv = v; bl = { tx, ty, e: 1 }; }
      }
      if (bl) { steerTo(W, p, I, bl.tx, bl.ty, D.sp); if (hyp(bl.tx - p.x, bl.ty - p.y) < (bl.e ? 0.2 : LAD_R * 0.8)) I.act = 1; }
    } else {
      // stay in the middle, away from a zombie climbing up
      if (hyp(R.x - p.x, R.y - p.y) > 0.6) steerTo(W, p, I, R.x, R.y, 0.5);
    }
    return I;
  }
  function aiSurvivor(W, p, m, lv, dt) {
    const D = SD[lv - 1], M = W.M, I = newI();
    if (p.esc || p.tf > 0 || p.stun > 0 || p.cl > 0) return I;
    const zf = zField(W), here = tileOf(M, p.x, p.y);
    if (p.up) return aiRoof(W, p, m, lv, I, zf);
    // nearest zombie I notice
    let zd = 1e9, zq = null;
    for (const q of W.pl) {
      if (!q.z || q.esc || q.tf > 0.6) continue;
      const e = hyp(q.x - p.x, q.y - p.y);
      if (e > D.r) continue;
      if (W.dark && lv < 3 && e > 3.5 && !losP(W, p, q)) continue;
      if (e < zd) { zd = e; zq = q; }
    }
    const heli = heliOn(W);
    // tucked away in a hiding spot and nobody is coming → keep still
    if (hidden(p) && lv >= 2 && p.rev <= 0 && !heli) {
      let stay = true;
      if (zq) {
        const dx = p.x - zq.x, dy = p.y - zq.y, toward = (zq.vx * dx + zq.vy * dy) / Math.max(0.1, zd);
        stay = zd > (lv === 3 ? 1.7 : 2.6) && toward < 1.2 && zq.zt !== 2;
      }
      if (stay) { m.path = null; m.rt = 0; m.dg = false; return I; }
    }
    const danger = !!zq && W.t >= START_T - 1.5;
    m.rt = (m.rt || 0) - dt;
    if (danger && !m.dg) m.rt = 0;
    m.dg = danger;
    if (m.rt <= 0 || !m.path || m.pi >= m.path.length) {
      m.rt = D.rp * (0.8 + Math.random() * 0.4);
      m.lad = -1; m.hide = 0;
      const hzT = tileOf(M, M.hz.x, M.hz.y);
      if (danger || heli) {
        // climb onto a roof if a ladder is close and I get there first
        if (danger && !heli && M.lads.length && p.rt < ROOF_T - 5 && Math.random() < D.roof) {
          const S0 = sPath(W, here, D.lad, zf, zf[here] >= 2 ? 2 : 0);
          let bl = -1, bv = 1e9;
          M.lads.forEach((Ld, j) => {
            const dd = S0.d[Ld.i]; if (dd < 0 || zf[Ld.i] <= dd + 1) return;
            if (W.pl.some((q) => q.z && !q.esc && (q.zt === 3 || q.up) && hyp(q.x - Ld.x, q.y - Ld.y) < 6)) return;
            if (W.pl.some((q) => alive(q) && q.up && M.roofOf[tileOf(M, q.x, q.y)] === Ld.r && q !== p) && lv === 3) return;
            if (dd < bv) { bv = dd; bl = j; }
          });
          if (bl >= 0) { m.path = pathTo(S0.par, M.lads[bl].i); m.pi = 0; m.lad = bl; }
        }
        if (m.lad < 0) {
          let S = lv >= 2 ? sPath(W, here, heli ? 40 : 15, zf, 0, lv === 3 ? 1.5 : 1) : null;
          if (!S || S.q.length < 4) S = sPath(W, here, heli ? 40 : 11, zf, zf[here] >= 2 ? 2 : 0);
          const cands = [];
          for (const i of S.q) {
            if (i === here && S.q.length > 1) continue;
            const [cx, cy] = tc(M, i);
            let v = Math.min(zf[i], 14) - 0.28 * S.d[i] - D.dead * M.dead[i];
            if (lv >= 2 && M.c[i] === 'h' && zf[i] > 5) v += 1.5;
            if (heli && (lv >= 2 || S.d[i] < 12)) { const hd = hyp(cx - M.hz.x, cy - M.hz.y); v += hd < HELI_R ? 30 : -hd * 0.6 * (lv >= 2 ? 1 : 0.4); }
            if (lv === 1) v += Math.random() * 4;
            cands.push([v, i]);
          }
          cands.sort((a, b) => b[0] - a[0]);
          let pick = cands.length ? cands[Math.floor(Math.random() * Math.min(D.top, cands.length))][1] : here;
          if (lv >= 2 && m.fg >= 0 && S.d[m.fg] > 0) { const old = cands.find((c) => c[1] === m.fg); if (old && cands[0][0] - old[0] < 1.5) pick = m.fg; }
          m.fg = pick;
          m.path = pathTo(S.par, pick); m.pi = 0;
          if (heli && S.d[hzT] < 0 && lv >= 2) m.path = pathTo(S.par, pick);
        }
      } else {
        // calm: grab an item / planks, slip into a hiding spot, or wander away from zombies
        const S = sPath(W, here, lv === 1 ? 6 : 12, null, 0);
        let goal = -1;
        if (lv >= 2 && M.c[here] === 'h' && m.hg === here && Math.random() < 0.9) { goal = here; m.hide = 1; }
        if (goal < 0) {
          let bd = 1e9;
          for (const g of W.gi) { if (g.k === 5 ? p.pk >= PK_MAX : p.it >= 0) continue; const t = M.items[g.s].i, dd = S.d[t]; if (dd >= 0 && dd < bd && zf[t] > 4) { bd = dd; goal = t; } }
        }
        if (goal < 0 && M.hide.length && Math.random() < D.hide) {
          let bd = 1e9; for (const t of M.hide) { const dd = S.d[t]; if (dd > 0 && zf[t] > 7 && dd + Math.random() * 4 < bd && !W.pl.some((q) => q !== p && !q.esc && tileOf(M, q.x, q.y) === t)) { bd = dd; goal = t; } }
          if (goal >= 0) { m.hide = 1; m.hg = goal; }
        }
        if (goal < 0) {
          if (m.wg >= 0 && S.d[m.wg] > 0 && Math.random() < 0.85) goal = m.wg;
          else { const far = S.q.filter((i) => zf[i] > 8 && S.d[i] > 3); goal = far.length ? far[Math.floor(Math.random() * far.length)] : S.q[Math.floor(Math.random() * S.q.length)]; }
          m.wg = goal;
        }
        m.path = pathTo(S.par, goal); m.pi = 0;
      }
    }
    // follow the path (aim at the farthest tile in a clear straight line, so we don't zigzag)
    let k = -1; for (let j = m.pi; j < Math.min(m.path.length, m.pi + 4); j++) if (m.path[j] === here) k = j;
    if (k >= 0) m.pi = k + 1;
    const sp = danger ? D.sp : 0.8 * D.sp;
    if (m.pi < m.path.length) {
      const nx = m.path[m.pi];
      let aim = m.pi;
      if (lv >= 2) for (let j = m.pi + 1; j < Math.min(m.path.length, m.pi + 4); j++) { if (M.gateAt[m.path[j]] >= 0) break; const [qx, qy] = tc(M, m.path[j]); if (clearLine(W, p, p.x, p.y, qx, qy)) aim = j; else break; }
      const [cx, cy] = tc(M, m.path[aim]);
      steerTo(W, p, I, cx, cy, sp);
      const dj = M.gateAt[nx];
      if (dj >= 0 && !M.gates[dj].win && W.gate[dj].s === 1 && hyp(cx - p.x, cy - p.y) < REACH) I.act = 1;
    } else if (m.hide && M.c[here] === 'h') { const [cx, cy] = tc(M, here); if (hyp(cx - p.x, cy - p.y) > 0.25) steerTo(W, p, I, cx, cy, 0.25); }
    else if (danger) steerTo(W, p, I, p.x - (zq.x - p.x), p.y - (zq.y - p.y), sp);
    if (m.lad >= 0 && ladNear(W, p) === m.lad) { I.act = 1; m.lad = -1; }
    // shut a door / nail planks behind me
    m.dcd = (m.dcd || 0) - dt;
    if (!I.act && danger && zd < 6 && m.dcd <= 0) {
      const j = gateNear(W, p, (g) => g.b === 0 && !g.lk);
      if (j >= 0) {
        const G = M.gates[j], g = W.gate[j], Wd = M.W;
        const a = G.hz ? G.i - Wd : G.i - 1, b = G.hz ? G.i + Wd : G.i + 1, zs = Math.min(zf[a], zf[b], zf[G.i]);
        m.dcd = 0.5;
        const useful = G.win ? zq.zt === 3 : true;
        if (useful && zs < zf[here] && zf[here] - zs <= 4 && gateClear(W, j)) {
          let room = 99;
          if (p.pk > 0 && lv >= 2) { g.b = 1; room = sPath(W, here, 10, null, 0).q.length; g.b = 0; } // don't nail myself into a small room
          if (p.it === 6 && (lv > 1 || Math.random() < 0.3)) { if (room === 99) { g.b = 1; room = sPath(W, here, 10, null, 0).q.length; g.b = 0; } if (room > 45 || lv === 1) I.sk = 1; }
          if (I.sk) { /* barricade item used instead */ } else if (p.pk > 0 && room > 45 && Math.random() < D.bar) I.pl = 1;
          else if (!G.win && g.s === 0 && g.cd <= 0 && Math.random() < D.door) I.act = 1;
        }
      }
    }
    // items
    if (!I.act && !I.pl && !I.sk && p.it >= 0 && p.it !== 3 && zq) {
      const r = Math.random();
      if (p.it === 0 && (lv === 1 ? zd < 4 && r < 0.05 : zd < 2.4)) I.sk = 1;
      else if (p.it === 2 && zd < (lv === 1 ? 3.4 : 2.6) && losP(W, p, zq) && (lv > 1 || r < 0.08)) I.sk = 1;
      else if (p.it === 1 && (lv === 1 ? r < 0.02 : zd > 1.2 && zd < 3.6 && (zq.vx * (p.x - zq.x) + zq.vy * (p.y - zq.y)) > 0)) I.sk = 1;
      else if (p.it === 4 && zd > 2.2 && zd < 8 && (lv === 1 ? r < 0.03 : r < 0.25)) {
        const a = lv === 1 ? r * TAU * 30 : bestLure(W, p, zq);
        if (a != null) { I.sk = 1; I.ta = a; }
      } else if (p.it === 7 && (lv === 1 ? zd < 3 && r < 0.05 : zd < 3.2 && !hidden(p) && (zq.zt !== 2 || zd > 2.2))) I.sk = 1;
    }
    unstick(m, p, I, dt);
    return I;
  }
  function aiThink(W, p, m, lv, dt) {
    if (p.z) return aiZombie(W, p, m, lv, dt);
    const I = aiSurvivor(W, p, m, lv, dt);
    if (!I.sk && p.it < 0 && JB[p.jb] && JB[p.jb].act && p.sp <= 0 && !p.esc && W.t >= START_T) aiJob(W, p, m, lv, dt, I);
    return I;
  }
  function aiJob(W, p, m, lv, dt, I) { // survivor job actives (empty-handed)
    let zd = 1e9, zq = null;
    for (const q of W.pl) if (q.z && !q.esc && q.tf <= 0.6 && q.up === p.up) { const e = hyp(q.x - p.x, q.y - p.y); if (e < zd) { zd = e; zq = q; } }
    const r = Math.random();
    if (p.jb === 4) { if (lv === 1 ? zd < 4 && r < 0.04 : zd < (lv === 3 ? 2.2 : 2.8) && hyp(I.ax, I.ay) > 0.5) I.sk = 1; }
    else if (p.jb === 5) { if (lv === 1 ? r < 0.01 : zd > 4 && zd < 14 && !hidden(p)) I.sk = 1; }
    else if (p.jb === 6 && !p.up) { if (lv === 1 ? r < 0.015 : zq && zd > 1.1 && zd < 3.8 && (zq.vx * (p.x - zq.x) + zq.vy * (p.y - zq.y)) > 0) I.sk = 1; }
  }

  /* ---------- coarse state (api.setState) ---------- */
  function pickMap(mp, prev) {
    if (mp >= 0 && mp < MAPS.length) return mp;
    let k = U.rand(MAPS.length); if (MAPS.length > 1 && k === prev) k = (k + 1 + U.rand(MAPS.length - 1)) % MAPS.length;
    return k;
  }
  function pickAlpha(st) {
    const cand = []; for (let i = 0; i < st.np; i++) if (!((st.ad >> i) & 1)) cand.push(i);
    const pool = cand.length ? cand : Array.from({ length: st.np }, (_, i) => i).filter((i) => i !== st.al);
    return pool.length ? pool[U.rand(pool.length)] : 0;
  }
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 2, NP);
    const mp = typeof o.map === 'number' && o.map >= -1 && o.map < MAPS.length ? o.map : -1;
    const st = {
      rid: 1 + U.rand(99999), nm: players.slice(0, np).map((p) => String((p && p.name) || '').slice(0, 8)), np, mp,
      rounds: [3, 5].includes(+o.rounds) ? +o.rounds : 3, len: [60, 90, 120].includes(+o.len) ? +o.len : 90,
      heli: o.heli === 0 ? 0 : 1, fog: [0, 1].includes(o.fog) ? o.fog : -1,
      rd: 1, mk: pickMap(mp, -1), al: 0, ad: 0, ph: 'play', sc: Array(np).fill(0), sw: Array(np).fill(0), ic: Array(np).fill(0), rs: null, win: -1, res: null,
    };
    st.al = pickAlpha(st); st.ad = 1 << st.al;
    st.jr = Array.from({ length: np }, (_, i) => (players[i] && !players[i].ai && i !== st.al ? 0 : 1)); // 첫 판: 사람이 직업을 고를(준비) 때까지 카운트다운 멈춤
    return st;
  }
  function roundOver(st, rows, win) {
    const n = Object.assign({}, st, { sc: st.sc.slice(), sw: st.sw.slice(), ic: st.ic.slice(), ph: 'end', win: win ? 1 : 0 });
    const rs = [];
    if (Array.isArray(rows)) for (const r of rows) {
      if (!Array.isArray(r)) continue;
      const s = r[0] | 0; if (s < 0 || s >= st.np) continue;
      const pts = clamp(r[1] | 0, 0, 200), oc = clamp(r[2] | 0, 0, 3);
      n.sc[s] += pts; if (oc === 0 || oc === 1) n.sw[s]++; n.ic[s] += clamp(r[3] | 0, 0, 9);
      rs.push([s, pts, oc, r[3] | 0, r[4] | 0]);
    }
    n.rs = rs;
    return n;
  }
  function nextRound(st) {
    if (st.rd >= st.rounds) {
      const order = st.sc.map((v, i) => [i, v, st.sw[i], st.ic[i]]).sort((a, b) => b[1] - a[1] || b[2] - a[2] || b[3] - a[3] || a[0] - b[0]);
      return Object.assign({}, st, { ph: 'done', res: order });
    }
    const n = Object.assign({}, st, { rd: st.rd + 1, mk: pickMap(st.mp, st.mk), ph: 'play', rs: null, win: -1 });
    n.al = pickAlpha(n); n.ad = st.ad | (1 << n.al);
    return n;
  }
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res) || !st.res.length) return null;
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번';
    const top = st.res[0][1], winners = st.res.filter((r) => r[1] === top).map((r) => r[0]);
    const lines = st.res.map((r, k) => (k + 1) + '위  ' + nm(r[0]) + '  ' + r[1] + '점 · 살아남음 ' + r[2] + '판 · 감염시킴 ' + r[3]);
    const head = (st.mp >= 0 ? MAPS[st.mp].nm : '맵 무작위') + ' · ' + st.rounds + '판';
    const by = []; st.res.forEach((r) => { if (Array.isArray(r)) by[r[0]] = r; });
    const col = (fm) => Array.from({ length: st.nm ? st.nm.length : st.res.length }, (_, i) => (by[i] ? fm(by[i]) : '-'));
    const stats = [{ label: '점수', values: col((r) => (r[1] | 0) + '점') }, { label: '살아남은 판', values: col((r) => (r[2] | 0) + '/' + st.rounds) }, { label: '감염시킨 수', values: col((r) => (r[3] | 0) + '명') }];
    return { stats, winners, title: winners.length === 1 ? nm(winners[0]) + ' 우승!' : '공동 우승', text: head + '\n' + lines.join('\n') };
  }

  /* ---------- host snapshot ---------- */
  const PF = 10;
  function snapshot(W, key, q) {
    const P = [];
    for (const p of W.pl) {
      const fl = (p.z ? 1 : 0) | (p.alpha ? 2 : 0) | (p.dk > 0 ? 4 : 0) | (p.stun > 0 ? 8 : 0) | (p.ln > 0 ? 16 : 0) | (p.sh > 0 ? 32 : 0) | (p.esc ? 64 : 0) |
        (p.tf > 0 ? 128 : 0) | (p.slow > 0 ? 256 : 0) | (p.trap ? 512 : 0) | (p.up ? 1024 : 0) | (hidden(p) ? 2048 : 0) | (p.cl > 0 ? 4096 : 0) | (p.rev > 0 ? 8192 : 0) |
        (p.boost > 0 ? 16384 : 0) | (p.run > 0 ? 32768 : 0) | (p.jp > 0 ? 65536 : 0) | (p.scared > 0 ? 131072 : 0) | (p.cdir > 0 ? 262144 : 0) | (p.rv > 0 ? 524288 : 0);
      P.push(Math.round(p.x * 10), Math.round(p.y * 10), Math.round(wrapA(p.a) * 10), fl, p.it, Math.ceil(Math.max(p.lcd, p.cd) * 10), Math.round(p.hz * 10) + p.ic * 100,
        (p.zt + 1) + p.pk * 8 + (p.jb + 1) * 32 + (p.ju ? 512 : 0), Math.ceil(p.sp * 10), Math.round(p.rt * 10));
    }
    return { k: key, q, t: Math.round(W.t * 10) / 10, nz: W.nz, P, fx: W.fx.slice(-10),
      g: W.gate.map((d) => (d.s === 1 ? 1 : d.cd > 0 ? 2 : 0) + 4 * (d.s === 1 ? Math.max(1, Math.ceil(d.hp)) : 0) + 1000 * Math.ceil(d.b)),
      gl: W.gate.flatMap((d, j) => (d.lk > 0 ? [j, Math.ceil(d.lk * 10)] : [])), sm: W.sm.flatMap((S) => [Math.round(S.x * 10), Math.round(S.y * 10), Math.ceil(S.t * 10)]),
      gi: W.gi.flatMap((g) => [g.s, g.k]), tr: W.traps.flatMap((t) => [Math.round(t.x * 10), Math.round(t.y * 10)]), lu: W.lu.flatMap((l) => [Math.round(l.x * 10), Math.round(l.y * 10), Math.ceil(l.t * 10)]) };
  }
  function applySnap(W, hs, me) {
    if (fin(hs.t)) W.t = hs.t;
    if (fin(hs.nz)) W.nz = hs.nz | 0;
    const A = hs.P;
    W.pl.forEach((p, i) => {
      const o = i * PF; if (!fin(+A[o]) || !fin(+A[o + 1])) return;
      const fl = A[o + 3] | 0;
      p.z = fl & 1 ? 1 : 0; p.alpha = fl & 2 ? 1 : 0; p.dk = fl & 4 ? 1 : 0; p.stun = fl & 8 ? 1 : 0; p.ln = fl & 16 ? 1 : 0; p.sh = fl & 32 ? 1 : 0;
      const wasEsc = p.esc, wasUp = p.up; p.esc = fl & 64 ? 1 : 0; p.tf = fl & 128 ? 1 : 0; p.slow = fl & 256 ? 1 : 0; p.trap = fl & 512 ? 1 : 0;
      p.up = fl & 1024 ? 1 : 0; p.hd = fl & 2048 ? HIDE_T : 0; p.cl = fl & 4096 ? 1 : 0; p.rev = fl & 8192 ? 1 : 0; p.boost = fl & 16384 ? 1 : 0; p.run = fl & 32768 ? 1 : 0;
      p.jp = fl & 65536 ? 1 : 0; p.scared = fl & 131072 ? 1 : 0; p.cdir = fl & 262144 ? 1 : -1; p.rv = fl & 524288 ? 1 : 0;
      p.it = clamp(A[o + 4] | 0, -1, 7); p.lcd = (A[o + 5] | 0) / 10; p.cd = p.lcd;
      const hv = A[o + 6] | 0; p.hz = (hv % 100) / 10; p.ic = Math.floor(hv / 100);
      const e = A[o + 7] | 0; p.zt = clamp((e & 7) - 1, -1, ZT.length - 1); p.pk = clamp((e >> 3) & 3, 0, PK_MAX); p.jb = clamp(((e >> 5) & 15) - 1, -1, JB.length - 1); p.ju = (e >> 9) & 1;
      p.sp = (A[o + 8] | 0) / 10; p.rt = (A[o + 9] | 0) / 10;
      p.nx = (A[o] | 0) / 10; p.ny = (A[o + 1] | 0) / 10;
      if (i !== me) p.na = (A[o + 2] | 0) / 10;
      if (hyp(p.nx - p.x, p.ny - p.y) > 2.5 || wasEsc !== p.esc || wasUp !== p.up) { p.x = p.nx; p.y = p.ny; }
    });
    if (Array.isArray(hs.g)) for (let j = 0; j < W.gate.length; j++) {
      const v = +hs.g[j] || 0, D = W.gate[j], s = v % 4;
      D.s = s === 1 ? 1 : 0; D.cd = s === 2 ? 1 : 0; D.hp = Math.floor((v % 1000) / 4); D.b = Math.floor(v / 1000); D.lk = 0;
    }
    if (Array.isArray(hs.gl)) for (let k = 0; k + 1 < hs.gl.length; k += 2) { const D = W.gate[hs.gl[k] | 0]; if (D) D.lk = (hs.gl[k + 1] | 0) / 10; }
    W.gate.forEach((_, j) => updGate(W, j));
    W.sm = []; if (Array.isArray(hs.sm)) for (let k = 0; k + 2 < hs.sm.length; k += 3) W.sm.push({ x: (hs.sm[k] | 0) / 10, y: (hs.sm[k + 1] | 0) / 10, t: (hs.sm[k + 2] | 0) / 10 });
    W.gi = []; if (Array.isArray(hs.gi)) for (let k = 0; k + 1 < hs.gi.length; k += 2) { const s = hs.gi[k] | 0; if (s >= 0 && s < W.M.items.length) W.gi.push({ s, k: clamp(hs.gi[k + 1] | 0, 0, 7) }); }
    W.traps = []; if (Array.isArray(hs.tr)) for (let k = 0; k + 1 < hs.tr.length; k += 2) W.traps.push({ x: (hs.tr[k] | 0) / 10, y: (hs.tr[k + 1] | 0) / 10 });
    W.lu = []; if (Array.isArray(hs.lu)) for (let k = 0; k + 2 < hs.lu.length; k += 3) W.lu.push({ x: (hs.lu[k] | 0) / 10, y: (hs.lu[k + 1] | 0) / 10, t: (hs.lu[k + 2] | 0) / 10 });
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  let STICK_R = 48; const TOPH = 46;
  const KC = () => { const v = L.ui && L.ui.ctlScale ? +L.ui.ctlScale() : 1; return v > 0 ? v : 1; };
  const ZSKIN = '#8ccf6a', ZDARK = '#4f8a3c';
  const ZSK = ['#b8d860', '#7f9a78', '#b49ad6', '#d6d45a', '#9cc8dc'], ZSK2 = ['#6f8a2c', '#4a5e48', '#6a5490', '#8a8a2a', '#4f7a8c'];
  const CTX_NM = { bash: '부수기', lunge: '돌진', open: '문 열기', close: '문 닫기', up: '오르기', down: '내려가기', jump: '뛰어내리기' };
  const SK_NM = { drink: '음료', trap: '덫 놓기', flash: '번쩍!', vac: '백신', lure: '미끼', bari: '바리케이드', smoke: '연막', run: '질주', smash: '박살', sniff: '킁킁', leap: '도약', scream: '비명' };
  const CSS = `
.zb-btn{position:absolute;border-radius:50%;border:2px solid rgba(242,233,216,.4);background:rgba(30,40,30,.88);color:#f2e9d8;
  font:700 16px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;
  touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0;box-shadow:0 4px 14px rgba(0,0,0,.5);
  -webkit-tap-highlight-color:transparent;cursor:pointer;line-height:1.1;width:94px;height:94px;right:12px;bottom:16px;transition:transform .08s}
.zb-btn small{font-size:11px;font-weight:600;opacity:.85;max-width:84px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.zb-btn.s2{width:64px;height:64px;font-size:13px;right:24px;bottom:124px}
.zb-btn.s2 small{font-size:10px;max-width:58px}
.zb-btn.pl{right:118px;bottom:22px}
.zb-btn.dim{opacity:.45}
.zb-btn.sv{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.zb-btn.zb{background:#5f9a44;color:#10200a;border-color:#d8f5c4}
.zb-btn.dr{background:#c98a4a;color:#241404;border-color:#ffe2c0}
.zb-btn.wd{background:#8a5a30;color:#fff1dc;border-color:#e8c08a}
.zb-btn.lad{background:#4f7aa8;color:#f2f6ff;border-color:#cfe2ff}
.zb-btn.sk{background:#7a4aa8;color:#f6eaff;border-color:#e2c8ff}
.zb-btn .cd{position:absolute;inset:0;border-radius:50%;pointer-events:none;background:conic-gradient(rgba(12,8,22,.6) calc(var(--c,0) * 1turn),transparent 0)}
.zb-btn.press{transform:scale(.92)}
.zb-end{position:absolute;left:50%;top:54px;transform:translateX(-50%);width:min(340px,calc(100% - 24px));z-index:4;background:rgba(23,19,31,.95);
  border:2px solid rgba(227,174,69,.5);border-radius:16px;padding:12px 12px 10px;color:#f2e9d8;font-family:var(--f-body,system-ui);box-sizing:border-box;
  box-shadow:0 10px 30px rgba(0,0,0,.6);pointer-events:none}
.zb-end h3{margin:0 0 4px;font:22px var(--f-display,sans-serif);text-align:center;letter-spacing:.5px}
.zb-end .sub{font-size:13px;text-align:center;color:#ab9fb8;margin-bottom:8px}
.zb-end .row{display:flex;align-items:center;gap:6px;font-size:13px;padding:3px 2px;border-top:1px solid rgba(255,255,255,.07)}
.zb-end .row .nm{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.zb-end .row .oc{font-size:12px;color:#ab9fb8;white-space:nowrap}
.zb-end .row b{font-family:var(--f-mono,monospace);min-width:44px;text-align:right;color:#e3ae45}
.zb-end .row .tot{font-family:var(--f-mono,monospace);min-width:34px;text-align:right;color:#ab9fb8;font-size:12px}
.zb-end .dot{width:12px;height:12px;border-radius:50%;flex:0 0 12px;background:var(--c)}
.zb-end .me{background:rgba(227,174,69,.12);border-radius:6px}
`;
  const JOB_CSS = `
.zb-job{position:absolute;left:50%;transform:translateX(-50%);width:min(344px,calc(100% - 16px));z-index:4;display:flex;flex-wrap:wrap;justify-content:center;gap:6px;
  background:rgba(10,8,16,.82);border:1px solid rgba(227,174,69,.4);border-radius:14px;padding:8px;box-sizing:border-box;font-family:var(--f-body,system-ui)}
.zb-job button{width:60px;height:48px;border-radius:10px;border:2px solid rgba(242,233,216,.22);background:rgba(46,38,64,.95);color:#f2e9d8;font:600 10px var(--f-body,system-ui);
  display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0;line-height:1.15;cursor:pointer;touch-action:manipulation;white-space:nowrap}
.zb-job button b{font-size:17px;font-weight:400}
.zb-job button.on{border-color:#e3ae45;background:#5a4520}
.zb-job .ds{width:100%;text-align:center;font-size:12px;font-weight:600;color:#f2e9d8;min-height:16px}
.zb-job .hd{width:100%;text-align:center;font-size:12px;color:#e3ae45;font-weight:700}
`;
  const OC_NM = ['살아남음', '탈출', '감염', '알파 좀비'];
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS + JOB_CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    let st = null, key = null, W = null, lay = null, aiMem = [];
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const COL = (s) => P(s).color || (L.COLORS && L.COLORS[s % 8]) || '#888';
    const curKey = () => (st ? st.rid + '.' + st.rd : null);
    const myP = () => { const m = me(); return W && m >= 0 && !auto() ? W.pl[m] : null; };
    function spect() { const p = myP(); return !p || p.esc || !st || st.ph !== 'play'; }
    const lsGet = (k) => { try { return +localStorage.getItem('lounge.zb.' + k) || 0; } catch (e) { return 0; } };
    const lsSet = (k, v) => { try { localStorage.setItem('lounge.zb.' + k, String(v)); } catch (e) { /* private */ } };

    /* ----- sound: heartbeat, groans, screams (own tiny synth; follows the app's sound switch) ----- */
    const Snd = {
      ac: null, nb: null,
      on() { try { return !!(U.store ? U.store.get('sound', true) : true); } catch (e) { return true; } },
      out: null,
      vol() { try { if (this.out) this.out.gain.value = L.audio ? L.audio.sfx() : 1; } catch (e) {} }, // app effect volume
      ctx() { if (auto() || !this.on()) return null; try { if (!this.ac) { this.ac = new (window.AudioContext || window.webkitAudioContext)(); this.out = this.ac.createGain(); this.out.connect(this.ac.destination); this.vol(); } if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
      tone(f, f2, d, type, vol, dl, lp) {
        const ac = this.ctx(); if (!ac) return;
        try {
          const t = ac.currentTime + (dl || 0), o = ac.createOscillator(), g = ac.createGain();
          o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
          g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.03, d / 3)); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
          if (lp) { const f3 = ac.createBiquadFilter(); f3.type = 'lowpass'; f3.frequency.value = lp; o.connect(f3).connect(g); } else o.connect(g);
          g.connect(this.out || ac.destination); o.start(t); o.stop(t + d + 0.05);
        } catch (e) {}
      },
      noise(d, freq, q, vol, dl, type) {
        const ac = this.ctx(); if (!ac) return;
        try {
          if (!this.nb) { const n = ac.sampleRate * 1, b = ac.createBuffer(1, n, ac.sampleRate), c = b.getChannelData(0); for (let i = 0; i < n; i++) c[i] = Math.random() * 2 - 1; this.nb = b; }
          const t = ac.currentTime + (dl || 0), s = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
          s.buffer = this.nb; f.type = type || 'bandpass'; f.frequency.value = freq; f.Q.value = q;
          g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, d / 4)); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
          s.connect(f).connect(g).connect(this.out || ac.destination); s.start(t); s.stop(t + d + 0.05);
        } catch (e) {}
      },
      beat(k) { const v = 0.1 + 0.3 * k; this.tone(72, 40, 0.13, 'sine', v); this.tone(64, 36, 0.11, 'sine', v * 0.7, 0.17); },
      groan(v) { this.tone(105 + Math.random() * 30, 70, 0.9, 'sawtooth', 0.035 * v, 0, 420); this.tone(52, 44, 0.9, 'sine', 0.06 * v); },
      scream(v) { this.tone(620, 980, 0.5, 'sawtooth', 0.05 * v, 0, 2400); this.noise(0.6, 1800, 1.2, 0.09 * v); },
      sniff() { for (let k = 0; k < 3; k++) this.noise(0.08, 3000, 0.8, 0.06, k * 0.12, 'highpass'); },
      hammer() { for (let k = 0; k < 2; k++) { this.noise(0.05, 900, 2, 0.16, k * 0.14); this.tone(320, 180, 0.06, 'square', 0.04, k * 0.14); } },
      crash() { this.noise(0.45, 500, 0.7, 0.22); this.tone(90, 45, 0.3, 'sine', 0.3); },
      ring() { for (let k = 0; k < 4; k++) this.tone(1400, 1300, 0.07, 'square', 0.03, k * 0.09); },
      close() { try { if (this.ac) this.ac.close(); } catch (e) {} this.ac = null; this.out = null; },
    };
    const onVol = () => Snd.vol();
    window.addEventListener('lounge-volume', onVol);

    let floats = [], rings = [], parts = [], decals = [], banner = null, endT = 0, shake = 0, lastFx = 0, tipT = 0, flashA = 0, lastCount = -1, endEl = null;
    let infA = 0, hbPh = 0, hbPulse = 0, hbK = 0, groanT = 3, anim = [];
    function startRound() {
      key = curKey();
      W = newWorld(st);
      aiMem = W.pl.map(() => ({}));
      anim = W.pl.map((p) => ({ ph: 0, lx: p.x, ly: p.y, sp: 0, jt: 0, ct: 0, sk: 0, scr: 0, snf: 0, hit: 0 }));
      floats = []; rings = []; parts = []; decals = []; banner = null; lastFx = 0; lastQ = -1; flashA = 0; lastCount = -1; infA = 0; hbK = 0;
      for (const k in remIn) delete remIn[k];
      locIn.act = 0; locIn.pl = 0; locIn.sk = 0; netA.h = 0; netA.h2 = 0; netA.h3 = 0;
      endT = END_T; stick = null;
      if (st.ph === 'end' || st.ph === 'done') { W.res = { t: 0, sent: 1 }; W.t = START_T + 0.01; }
      tipT = 0;
      if (st.ph === 'play' && myP()) { const n = lsGet('tip2'); if (n < 3) { lsSet('tip2', n + 1); tipT = START_T + 6; } }
      netA.j = -1;
      const mp0 = myP(), pref = lsGet('job');
      if (mp0 && !mp0.z && st.ph === 'play' && pref >= 1 && pref <= JB.length) { if (host()) mp0.jb = pref - 1; else netA.j = pref - 1; }
      jobSig = '';
      lay = null; layout(); showEnd();
    }

    /* ----- layout & cached map ----- */
    let bgCv = null, bgKey = '', fogCv = null, fogCtx = null, vigCv = null, vigKey = '';
    const cam = { x: 12, y: 15 };
    function layout() {
      if (!W) return;
      const M = W.M, w = cv.w, h = cv.h, sp = spect();
      let ts;
      if (sp) ts = Math.max(8, Math.min((w - 12) / M.W, (h - TOPH - 12) / M.H));
      else ts = clamp(Math.min(w / 12, (h - TOPH) / 15), 26, 46);
      lay = { w, h, ts, sp, ay: sp ? TOPH + (h - TOPH) / 2 : TOPH + (h - TOPH) * 0.46 };
      const dpr = Math.min(2, cv.dpr || 1), k = M.k + '|' + ts + '|' + dpr;
      if (k !== bgKey || !bgCv) { bgKey = k; bgCv = buildMap(M, ts, dpr); }
      const t = camTarget(); cam.x = t.x; cam.y = t.y;
    }
    cv.onresize = () => { if (W) { lay = null; layout(); } };
    function camTarget() {
      const M = W.M;
      if (!lay || lay.sp) return { x: M.W / 2, y: M.H / 2 };
      const p = myP();
      const hw = lay.w / 2 / lay.ts, top = (lay.ay - TOPH) / lay.ts, below = (lay.h - lay.ay) / lay.ts;
      let x = p.x, y = p.y;
      x = M.W + 2 < hw * 2 ? M.W / 2 : clamp(x, hw - 1, M.W + 1 - hw);
      y = M.H + 2 < top + below ? M.H / 2 : clamp(y, top - 1, M.H + 1 - below);
      return { x, y };
    }
    const SX = (x) => lay.w / 2 + (x - cam.x) * lay.ts;
    const SY = (y) => lay.ay + (y - cam.y) * lay.ts;
    function drawHide(g, hs, X, Y, ts, r) {
      const cx = X + ts / 2, cy = Y + ts / 2;
      if (hs === 0 || hs === 6) { // bush
        g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(cx + ts * 0.06, cy + ts * 0.18, ts * 0.5, ts * 0.3, 0, 0, TAU); g.fill();
        const c1 = hs === 6 ? '#3a6a52' : '#3a7a3a', c2 = hs === 6 ? '#4c8466' : '#4f9a48';
        for (let k = 0; k < 5; k++) { const a = k / 5 * TAU + r * 3; g.fillStyle = k & 1 ? c1 : c2; g.beginPath(); g.arc(cx + Math.cos(a) * ts * 0.22, cy + Math.sin(a) * ts * 0.18, ts * 0.26, 0, TAU); g.fill(); }
        g.fillStyle = c2; g.beginPath(); g.arc(cx, cy - ts * 0.04, ts * 0.26, 0, TAU); g.fill();
        if (hs === 6) { g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.ellipse(cx - ts * 0.08, cy - ts * 0.2, ts * 0.22, ts * 0.09, -0.3, 0, TAU); g.fill(); }
        else { g.fillStyle = '#e86a8a'; g.beginPath(); g.arc(cx + ts * 0.14, cy - ts * 0.12, ts * 0.05, 0, TAU); g.fill(); g.beginPath(); g.arc(cx - ts * 0.18, cy + ts * 0.06, ts * 0.04, 0, TAU); g.fill(); }
      } else if (hs === 1) { // big potted plant
        g.fillStyle = '#7a4a2a'; rr(g, X + ts * 0.3, Y + ts * 0.55, ts * 0.4, ts * 0.36, ts * 0.06); g.fill();
        g.fillStyle = '#3f8a46'; for (let k = 0; k < 6; k++) { const a = k / 6 * TAU; g.beginPath(); g.ellipse(cx + Math.cos(a) * ts * 0.2, cy - ts * 0.08 + Math.sin(a) * ts * 0.16, ts * 0.2, ts * 0.1, a, 0, TAU); g.fill(); }
      } else if (hs === 2) { // locker
        g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(X + ts * 0.14, Y + ts * 0.12, ts * 0.8, ts * 0.86);
        g.fillStyle = '#5a7a96'; rr(g, X + ts * 0.1, Y + ts * 0.06, ts * 0.8, ts * 0.86, ts * 0.06); g.fill();
        g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(X + ts * 0.49, Y + ts * 0.08, ts * 0.03, ts * 0.82);
        g.fillStyle = 'rgba(255,255,255,.35)'; for (let k = 0; k < 3; k++) { g.fillRect(X + ts * 0.18, Y + ts * (0.16 + k * 0.06), ts * 0.24, ts * 0.025); g.fillRect(X + ts * 0.58, Y + ts * (0.16 + k * 0.06), ts * 0.24, ts * 0.025); }
      } else if (hs === 3) { // curtained bed
        g.fillStyle = '#e8eef2'; rr(g, X + ts * 0.12, Y + ts * 0.08, ts * 0.76, ts * 0.84, ts * 0.08); g.fill();
        g.fillStyle = '#7ab8c8'; for (let k = 0; k < 4; k++) g.fillRect(X + ts * (0.12 + k * 0.2), Y + ts * 0.08, ts * 0.12, ts * 0.84);
      } else if (hs === 4) { // tarp-covered crates
        g.fillStyle = '#6a4a2a'; g.fillRect(X + ts * 0.08, Y + ts * 0.2, ts * 0.84, ts * 0.72);
        g.fillStyle = '#2f6a7a'; g.beginPath(); g.moveTo(X + ts * 0.04, Y + ts * 0.86); g.lineTo(X + ts * 0.16, Y + ts * 0.12); g.lineTo(X + ts * 0.84, Y + ts * 0.1); g.lineTo(X + ts * 0.96, Y + ts * 0.88); g.closePath(); g.fill();
        g.strokeStyle = 'rgba(255,255,255,.2)'; g.lineWidth = 1; g.beginPath(); g.moveTo(X + ts * 0.3, Y + ts * 0.12); g.lineTo(X + ts * 0.26, Y + ts * 0.86); g.moveTo(X + ts * 0.66, Y + ts * 0.1); g.lineTo(X + ts * 0.7, Y + ts * 0.88); g.stroke();
      } else { // corn
        for (let k = 0; k < 3; k++) {
          const sx = X + ts * (0.2 + k * 0.3) + (r - 0.5) * ts * 0.08;
          g.strokeStyle = '#7a8a2a'; g.lineWidth = Math.max(1.5, ts * 0.07); g.beginPath(); g.moveTo(sx, Y + ts); g.lineTo(sx, Y + ts * 0.05); g.stroke();
          g.fillStyle = '#9ab040'; g.beginPath(); g.ellipse(sx + ts * 0.1, Y + ts * 0.45, ts * 0.16, ts * 0.05, -0.6, 0, TAU); g.fill(); g.beginPath(); g.ellipse(sx - ts * 0.1, Y + ts * 0.25, ts * 0.16, ts * 0.05, 0.6, 0, TAU); g.fill();
          g.fillStyle = '#f0c840'; g.beginPath(); g.ellipse(sx + ts * 0.05, Y + ts * 0.62, ts * 0.05, ts * 0.11, 0.2, 0, TAU); g.fill();
        }
      }
    }
    function buildMap(M, ts, dpr) {
      const c = document.createElement('canvas'); c.width = Math.ceil(M.W * ts * dpr); c.height = Math.ceil(M.H * ts * dpr);
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      const T = THEMES[M.th];
      g.fillStyle = T.bg; g.fillRect(0, 0, M.W * ts, M.H * ts);
      const at = (x, y) => (x < 0 || y < 0 || x >= M.W || y >= M.H ? '#' : M.c[y * M.W + x]);
      const roofAt = (x, y) => at(x, y) === 'B';
      for (let y = 0; y < M.H; y++) for (let x = 0; x < M.W; x++) {
        const ch = at(x, y), X = x * ts, Y = y * ts, r = hash2(x + M.k * 31, y);
        const out = ch === ',' || ch === 'L' || ch === 'h' && at(x, y) && (at(x - 1, y) === ',' || at(x + 1, y) === ',' || at(x, y - 1) === ',' || at(x, y + 1) === ',') ||
          (ch !== '.' && ch !== 'D' && ch !== 'W' && (at(x - 1, y) === ',' || at(x + 1, y) === ',' || at(x, y - 1) === ',' || at(x, y + 1) === ','));
        // floor under everything
        g.fillStyle = out ? ((x + y) & 1 ? T.gr : T.gr2) : ((x + y) & 1 ? T.fl : T.fl2);
        g.fillRect(X, Y, ts + 0.5, ts + 0.5);
        if (out) {
          if (M.th === 0 && r < 0.12) { g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(X + ts * 0.2, Y + ts * 0.45, ts * 0.6, ts * 0.08); }
          if ((M.th === 4 || M.th === 2 || M.th === 9 || M.th === 8) && r < 0.3) { g.fillStyle = 'rgba(255,255,255,.07)'; g.beginPath(); g.arc(X + r * ts * 3 % ts, Y + ts * 0.6, ts * 0.06, 0, TAU); g.fill(); }
          if (M.th === 7 && r < 0.4) { g.fillStyle = 'rgba(255,255,255,.7)'; g.fillRect(X + r * ts * 5 % ts, Y + r * ts * 7 % ts, 1.5, 1.5); }
          if ((M.th === 6 || M.th === 10) && r < 0.08) { g.fillStyle = 'rgba(0,0,0,.12)'; g.beginPath(); g.ellipse(X + ts / 2, Y + ts / 2, ts * 0.35, ts * 0.2, r * 6, 0, TAU); g.fill(); }
          if (M.th === 10 && (x === 8 || x === 15) && y > 6 && y < 22 && (y & 1)) { g.fillStyle = 'rgba(240,220,120,.35)'; g.fillRect(X + ts * 0.46, Y + ts * 0.1, ts * 0.08, ts * 0.8); }
        } else {
          if (M.th === 1 && ((x + y) & 1)) { g.fillStyle = 'rgba(255,255,255,.06)'; g.fillRect(X, Y, ts, ts); }
          if ((M.th === 0 || M.th === 4 || M.th === 7 || M.th === 9 || M.th === 6) && ch === '.') { g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(X, Y + ts * 0.48, ts, 1); }
        }
        if (ch === '#') {
          g.fillStyle = T.wall; g.fillRect(X, Y, ts + 0.5, ts + 0.5);
          g.fillStyle = T.wtop; g.fillRect(X, Y, ts + 0.5, ts * ('#WD'.includes(at(x, y + 1)) ? 1 : 0.7));
          g.fillStyle = 'rgba(0,0,0,.45)'; const e = Math.max(1, ts * 0.06);
          if (!'#WD'.includes(at(x - 1, y))) g.fillRect(X, Y, e, ts); if (!'#WD'.includes(at(x + 1, y))) g.fillRect(X + ts - e, Y, e, ts);
          if (!'#WD'.includes(at(x, y - 1))) g.fillRect(X, Y, ts, e);
          if (!'#WD'.includes(at(x, y + 1))) { g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(X, Y + ts, ts + 0.5, ts * 0.18); }
        } else if (ch === 'W') { // window: frame + glass
          const hz = '#WD'.includes(at(x - 1, y)) || '#WD'.includes(at(x + 1, y));
          g.fillStyle = T.wall; g.fillRect(X, Y, ts + 0.5, ts + 0.5);
          g.fillStyle = T.wtop;
          if (hz) g.fillRect(X, Y, ts + 0.5, ts * 0.2); else g.fillRect(X, Y, ts * 0.2, ts + 0.5);
          g.fillStyle = 'rgba(150,200,230,.55)';
          if (hz) g.fillRect(X + ts * 0.06, Y + ts * 0.3, ts * 0.88, ts * 0.42); else g.fillRect(X + ts * 0.3, Y + ts * 0.06, ts * 0.42, ts * 0.88);
          g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1; g.beginPath();
          if (hz) { g.moveTo(X + ts * 0.2, Y + ts * 0.62); g.lineTo(X + ts * 0.36, Y + ts * 0.38); g.moveTo(X + ts * 0.5, Y + ts * 0.3); g.lineTo(X + ts * 0.5, Y + ts * 0.72); }
          else { g.moveTo(X + ts * 0.38, Y + ts * 0.2); g.lineTo(X + ts * 0.62, Y + ts * 0.36); g.moveTo(X + ts * 0.3, Y + ts * 0.5); g.lineTo(X + ts * 0.72, Y + ts * 0.5); }
          g.stroke();
        } else if (ch === 'T') {
          if (M.th === 7) { // snowy pine
            g.fillStyle = 'rgba(0,0,0,.22)'; g.beginPath(); g.ellipse(X + ts * 0.6, Y + ts * 0.8, ts * 0.45, ts * 0.22, 0, 0, TAU); g.fill();
            for (let k = 0; k < 3; k++) { const yy = Y + ts * (0.95 - k * 0.3), wv = ts * (0.55 - k * 0.12); g.fillStyle = T.tree; g.beginPath(); g.moveTo(X + ts / 2 - wv, yy); g.lineTo(X + ts / 2 + wv, yy); g.lineTo(X + ts / 2, yy - ts * 0.45); g.closePath(); g.fill(); g.fillStyle = 'rgba(255,255,255,.8)'; g.beginPath(); g.moveTo(X + ts / 2 - wv * 0.4, yy - ts * 0.27); g.lineTo(X + ts / 2 + wv * 0.4, yy - ts * 0.27); g.lineTo(X + ts / 2, yy - ts * 0.45); g.closePath(); g.fill(); }
          } else if (M.th === 9 && x === 12) { // scarecrow
            g.strokeStyle = '#7a5a30'; g.lineWidth = ts * 0.1; g.beginPath(); g.moveTo(X + ts / 2, Y + ts); g.lineTo(X + ts / 2, Y + ts * 0.15); g.moveTo(X + ts * 0.1, Y + ts * 0.4); g.lineTo(X + ts * 0.9, Y + ts * 0.4); g.stroke();
            g.fillStyle = '#d8b050'; g.beginPath(); g.arc(X + ts / 2, Y + ts * 0.2, ts * 0.17, 0, TAU); g.fill();
            g.fillStyle = '#5a3a20'; g.fillRect(X + ts * 0.28, Y + ts * 0.02, ts * 0.44, ts * 0.08);
          } else if (M.th === 0 || M.th === 4 || M.th === 8 || M.th === 9 || M.th === 10 || M.th === 2 && out) {
            g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(X + ts * 0.55, Y + ts * 0.62, ts * 0.5, ts * 0.38, 0, 0, TAU); g.fill();
            g.fillStyle = T.tree; g.beginPath(); g.arc(X + ts / 2, Y + ts * 0.45, ts * 0.52, 0, TAU); g.fill();
            g.fillStyle = 'rgba(0,0,0,.15)'; g.beginPath(); g.arc(X + ts * 0.6, Y + ts * 0.55, ts * 0.32, 0, TAU); g.fill();
            g.fillStyle = 'rgba(255,255,255,.14)'; g.beginPath(); g.arc(X + ts * 0.38, Y + ts * 0.32, ts * 0.22, 0, TAU); g.fill();
          } else if (M.th === 1) {
            g.fillStyle = '#7a5a3a'; g.fillRect(X + ts * 0.15, Y + ts * 0.3, ts * 0.7, ts * 0.6);
            g.fillStyle = T.tree; g.beginPath(); g.arc(X + ts / 2, Y + ts * 0.32, ts * 0.38, 0, TAU); g.fill();
          } else {
            g.fillStyle = T.wall; g.fillRect(X + ts * 0.12, Y + ts * 0.12, ts * 0.76, ts * 0.8);
            g.fillStyle = T.wtop; g.fillRect(X + ts * 0.12, Y + ts * 0.05, ts * 0.76, ts * 0.6);
          }
        } else if (ch === 'o') {
          g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(X + ts * 0.1, Y + ts * 0.22, ts * 0.86, ts * 0.78);
          if (M.th === 6) { // crate
            g.fillStyle = '#a07a48'; g.fillRect(X + ts * 0.08, Y + ts * 0.08, ts * 0.84, ts * 0.8);
            g.strokeStyle = '#6a4a28'; g.lineWidth = Math.max(1.5, ts * 0.06); g.strokeRect(X + ts * 0.1, Y + ts * 0.1, ts * 0.8, ts * 0.76);
            g.beginPath(); g.moveTo(X + ts * 0.1, Y + ts * 0.1); g.lineTo(X + ts * 0.9, Y + ts * 0.86); g.stroke();
          } else if (M.th === 7) { // snow pile
            g.fillStyle = '#f4f8fc'; g.beginPath(); g.ellipse(X + ts / 2, Y + ts * 0.58, ts * 0.48, ts * 0.36, 0, 0, TAU); g.fill();
            g.fillStyle = 'rgba(160,190,220,.4)'; g.beginPath(); g.ellipse(X + ts * 0.58, Y + ts * 0.7, ts * 0.32, ts * 0.18, 0, 0, TAU); g.fill();
          } else {
            g.fillStyle = T.obj; rr(g, X + ts * 0.06, Y + ts * 0.1, ts * 0.88, ts * 0.78, ts * 0.18); g.fill();
            g.fillStyle = 'rgba(255,255,255,.18)'; rr(g, X + ts * 0.14, Y + ts * 0.16, ts * 0.72, ts * 0.22, ts * 0.1); g.fill();
          }
        } else if (ch === '~') {
          g.fillStyle = M.th === 6 ? '#24577e' : '#3d7fb0'; g.fillRect(X, Y, ts + 0.5, ts + 0.5);
          g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(X + ts * 0.2, Y + ts * 0.5); g.quadraticCurveTo(X + ts * 0.35, Y + ts * 0.35, X + ts * 0.5, Y + ts * 0.5); g.quadraticCurveTo(X + ts * 0.65, Y + ts * 0.65, X + ts * 0.8, Y + ts * 0.5); g.stroke();
        } else if (ch === 'R') {
          g.fillStyle = '#2a2a30'; g.fillRect(X, Y, ts + 0.5, ts + 0.5);
          g.fillStyle = '#5a4a3a'; g.fillRect(X, Y + ts * 0.42, ts + 0.5, ts * 0.16);
          g.fillStyle = '#b8b8c0'; g.fillRect(X + ts * 0.22, Y, ts * 0.07, ts + 0.5); g.fillRect(X + ts * 0.71, Y, ts * 0.07, ts + 0.5);
        } else if (ch === 'v') { // crawl vent: dark duct with a grate
          g.fillStyle = '#22262a'; g.fillRect(X, Y, ts + 0.5, ts + 0.5);
          g.fillStyle = '#3a4046'; g.fillRect(X + ts * 0.08, Y + ts * 0.08, ts * 0.84, ts * 0.84);
          g.fillStyle = '#15181b'; for (let k = 0; k < 4; k++) g.fillRect(X + ts * 0.14, Y + ts * (0.17 + k * 0.19), ts * 0.72, ts * 0.08);
          g.fillStyle = '#8a9096'; const e = Math.max(1, ts * 0.07); for (const [a, b] of [[0.14, 0.14], [0.86, 0.14], [0.14, 0.86], [0.86, 0.86]]) g.fillRect(X + ts * a - e / 2, Y + ts * b - e / 2, e, e);
        } else if (ch === 'h') drawHide(g, T.hs, X, Y, ts, r);
        if (M.th === 11 && ch === '.' && r < 0.06) { g.fillStyle = 'rgba(20,16,10,.35)'; g.beginPath(); g.ellipse(X + ts / 2, Y + ts / 2, ts * 0.4, ts * 0.22, r * 9, 0, TAU); g.fill(); }
        if (M.th === 11 && ch === '.' && (y === 12 || y === 16) && x > 0 && x < M.W - 1) { g.fillStyle = 'rgba(230,200,60,.55)'; g.fillRect(X, Y + (y === 12 ? ts * 0.8 : 0), ts + 0.5, ts * 0.2); }
        if (M.th === 12 && ch === '.' && !out && (x + y * 3) % 7 === 0 && r < 0.3) { g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(X + ts * 0.1, Y + ts * 0.7, ts * 0.5, ts * 0.06); }
      }
      // roofs on top (raised blocks with a drop shadow), ladders leaning on them
      M.roofs.forEach((R, id) => {
        let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1;
        for (const t of R.tiles) { const x = t % M.W, y = (t / M.W) | 0; x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
        const X = x0 * ts, Y = y0 * ts, Wr = (x1 - x0 + 1) * ts, Hr = (y1 - y0 + 1) * ts;
        g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(X + ts * 0.25, Y + ts * 0.3, Wr, Hr);
        const col = id % 2 && M.th === 6 ? T.rf2 : T.rf, col2 = M.th === 6 ? 'rgba(0,0,0,.18)' : T.rf2;
        g.fillStyle = col; g.fillRect(X, Y, Wr, Hr);
        g.save(); g.beginPath(); g.rect(X, Y, Wr, Hr); g.clip();
        if (M.th === 6 || M.th === 5) { g.fillStyle = col2; for (let xx = X + ts * 0.15; xx < X + Wr; xx += ts * 0.3) g.fillRect(xx, Y, ts * 0.12, Hr); }
        else if (M.th === 9 && Wr === Hr) { g.fillStyle = col2; g.beginPath(); g.arc(X + Wr / 2, Y + Hr / 2, Wr * 0.42, 0, TAU); g.fill(); g.fillStyle = col; g.beginPath(); g.arc(X + Wr / 2, Y + Hr / 2, Wr * 0.12, 0, TAU); g.fill(); }
        else if (M.th === 8) { for (let k = 0; k < 8; k++) { g.fillStyle = k & 1 ? T.rf2 : col; g.beginPath(); g.moveTo(X + Wr / 2, Y + Hr / 2); g.arc(X + Wr / 2, Y + Hr / 2, Math.max(Wr, Hr), k / 8 * TAU, (k + 1) / 8 * TAU); g.closePath(); g.fill(); } }
        else { g.strokeStyle = col2; g.lineWidth = Math.max(1, ts * 0.05); for (let yy = Y + ts * 0.33, row = 0; yy < Y + Hr; yy += ts * 0.33, row++) { g.beginPath(); g.moveTo(X, yy); g.lineTo(X + Wr, yy); g.stroke(); for (let xx = X + (row & 1 ? ts * 0.25 : 0); xx < X + Wr; xx += ts * 0.5) { g.beginPath(); g.moveTo(xx, yy - ts * 0.33); g.lineTo(xx, yy); g.stroke(); } } }
        g.restore();
        g.strokeStyle = 'rgba(255,255,255,.28)'; g.lineWidth = Math.max(1.5, ts * 0.06); g.strokeRect(X + 1, Y + 1, Wr - 2, Hr - 2);
        g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = Math.max(1.5, ts * 0.08); g.beginPath(); g.moveTo(X, Y + Hr); g.lineTo(X + Wr, Y + Hr); g.lineTo(X + Wr, Y); g.stroke();
      });
      for (const D of M.lads) {
        const X = (D.x - 0.5) * ts, Y = (D.y - 0.5) * ts, vert = Math.abs(D.ty - D.y) > 0.5;
        g.save(); g.translate(X + ts / 2, Y + ts / 2); if (!vert) g.rotate(Math.PI / 2); if ((vert ? D.ty - D.y : D.tx - D.x) > 0) g.rotate(Math.PI);
        g.fillStyle = 'rgba(0,0,0,.3)'; g.fillRect(-ts * 0.3, -ts * 0.9, ts * 0.66, ts * 1.3);
        g.strokeStyle = '#d8b878'; g.lineWidth = Math.max(2, ts * 0.08);
        g.beginPath(); g.moveTo(-ts * 0.26, ts * 0.45); g.lineTo(-ts * 0.22, -ts * 0.95); g.moveTo(ts * 0.26, ts * 0.45); g.lineTo(ts * 0.22, -ts * 0.95); g.stroke();
        g.lineWidth = Math.max(1.5, ts * 0.06); g.beginPath(); for (let k = 0; k < 5; k++) { const yy = ts * 0.35 - k * ts * 0.3; g.moveTo(-ts * 0.24, yy); g.lineTo(ts * 0.24, yy); } g.stroke();
        g.restore();
      }
      // rescue pad
      const hx = M.hz.x * ts, hy = M.hz.y * ts;
      g.strokeStyle = 'rgba(255,240,200,.55)'; g.lineWidth = Math.max(2, ts * 0.08); g.beginPath(); g.arc(hx, hy, HELI_R * ts * 0.9, 0, TAU); g.stroke();
      g.fillStyle = 'rgba(255,240,200,.55)'; g.font = '700 ' + Math.round(ts * 1.1) + 'px ' + DISP; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('H', hx, hy + ts * 0.05);
      return c;
    }
    function vignette(w, h) {
      const k = w + 'x' + h;
      if (vigCv && vigKey === k) return vigCv;
      vigKey = k; vigCv = document.createElement('canvas'); vigCv.width = Math.max(1, Math.round(w / 2)); vigCv.height = Math.max(1, Math.round(h / 2));
      const g = vigCv.getContext('2d'), cw = vigCv.width, ch = vigCv.height;
      const gr = g.createRadialGradient(cw / 2, ch / 2, Math.min(cw, ch) * 0.28, cw / 2, ch / 2, Math.hypot(cw, ch) * 0.55);
      gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.6, 'rgba(0,0,0,.45)'); gr.addColorStop(1, 'rgba(0,0,0,1)');
      g.fillStyle = gr; g.fillRect(0, 0, cw, ch);
      return vigCv;
    }

    /* ----- input ----- */
    const locIn = { ax: 0, ay: 0, act: 0, pl: 0, sk: 0, ta: null };
    const netA = { h: 0, h2: 0, h3: 0, j: -1, r: 0 };
    let stick = null;
    const press = { m: 0, p: 0, s: 0 };
    function mkBtn(cls, aria) {
      const b = L.h('button', { class: cls, 'aria-label': aria });
      const lab = L.h('span', { text: '' }), sub = L.h('small', { text: '' }), cd = L.h('i', { class: 'cd' });
      b.appendChild(cd); b.appendChild(lab); b.appendChild(sub); root.appendChild(b);
      return { b, lab, sub, cd, sig: '' };
    }
    const bM = mkBtn('zb-btn dim', '행동'), bP = mkBtn('zb-btn s2 pl dim', '판자'), bS = mkBtn('zb-btn s2 dim', '아이템·특기');
    bM.b.dataset.action = 'act'; bP.b.dataset.action = 'plank'; bS.b.dataset.action = 'skill';
    // job picker (shown during the countdown; the choice is remembered on this device)
    let jobSig = '';
    const jobEl = L.h('div', { class: 'zb-job' }); jobEl.style.display = 'none'; jobEl.style.top = (TOPH + 36) + 'px';
    const jobHd = L.h('div', { class: 'hd', text: '직업 고르기 · 누르면 준비' }), jobDs = L.h('div', { class: 'ds', text: '' });
    jobEl.appendChild(jobHd);
    const jobBs = [{ ic: '🎲', nm: '무작위' }].concat(JB).map((J, k) => {
      const b = L.h('button', { 'aria-label': J.nm }); b.appendChild(L.h('b', { text: J.ic })); b.appendChild(L.h('span', { text: J.nm.length > 4 ? J.nm.slice(0, 3) : J.nm }));
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); pickJob(k); });
      jobEl.appendChild(b); return b;
    });
    jobEl.appendChild(jobDs); root.appendChild(jobEl);
    function pickJob(k) {
      const p = myP(); if (!p || p.z || !st || st.ph !== 'play' || W.t >= START_T) return;
      lsSet('job', k);
      const j = k > 0 ? k - 1 : Math.floor(Math.random() * JB.length);
      p.jb = j; if (!host()) { netA.j = j; netA.r = 1; pubT = 0; inT = 0; } else setJr(me());
      api.sfx('click'); api.buzz(10); jobSig = '';
    }
    // 라운드 44: 첫 판은 사람이 모두 직업을 골라야(누르면 준비) 카운트다운이 흐른다. 방장 「지금 시작」은 남은 사람을 지금 직업(기본 무작위)으로 확정.
    let pbar = null;
    const jrOk = (i) => !st || !st.jr || !!st.jr[i] || i === st.al || (auto() && localHuman(i));
    function jobHold() { return !!(st && st.jr && W && W.t < START_T && L.pick.waiting(api.players, jrOk).length); }
    function setJr(i) { if (!host() || !st || !st.jr || st.jr[i] || i < 0) return; const jr = st.jr.slice(); jr[i] = 1; api.setState(Object.assign({}, st, { jr })); }
    function syncBar() {
      const want = !!(st && st.jr && st.ph === 'play' && W && W.t < START_T && st.jr.some((v) => !v));
      if (want && !pbar) pbar = api.pickBar({ picked: jrOk, onForce: () => { if (host() && st && st.jr) api.setState(Object.assign({}, st, { jr: st.jr.map(() => 1) })); } });
      else if (!want && pbar) { pbar.destroy(); pbar = null; }
    }
    function syncJob() {
      syncBar();
      const p = myP(), show = !!p && !p.z && !auto() && !!st && st.ph === 'play' && W.t < START_T;
      jobEl.style.display = show ? 'flex' : 'none';
      if (!show) return;
      const pref = lsGet('job'), sig = pref + '|' + p.jb;
      if (sig === jobSig) return; jobSig = sig;
      jobBs.forEach((b, k) => b.classList.toggle('on', k === (pref >= 1 && pref <= JB.length ? pref : 0)));
      const J = JB[p.jb]; jobDs.textContent = J ? (pref ? '' : '무작위 → ') + J.ic + ' ' + J.nm + ': ' + J.d : '';
    }
    function placeBtns() {
      const k = KC(), f = Math.min(1.4, Math.max(0.8, k)), mb = Math.round(94 * k), sb = Math.round(64 * k);
      STICK_R = Math.round(48 * k);
      const set = (B, sz, r, bo, fs) => { const q = B.b.style; q.width = q.height = sz + 'px'; q.right = r + 'px'; q.bottom = bo + 'px'; q.fontSize = Math.round(fs * f) + 'px'; };
      set(bM, mb, 12, 16, 16);
      set(bS, sb, 12 + (mb - sb) / 2, 16 + mb + 12, 13);
      set(bP, sb, 12 + mb + 12, 22, 13);
    }
    placeBtns();
    const onCtl = () => placeBtns(); window.addEventListener('lounge-ctl', onCtl);
    function pressBtn(which) {
      if (!W || !st || st.ph !== 'play') return;
      if (host()) { if (which === 'm') locIn.act = 1; else if (which === 'p') locIn.pl = 1; else locIn.sk = 1; }
      else { if (which === 'm') netA.h = (netA.h + 1) % 1000; else if (which === 'p') netA.h2 = (netA.h2 + 1) % 1000; else netA.h3 = (netA.h3 + 1) % 1000; pubT = 0; inT = 0; }
      press[which] = 0.12; api.buzz(12);
    }
    const onBM = (e) => { e.preventDefault(); e.stopPropagation(); pressBtn('m'); };
    const onBP = (e) => { e.preventDefault(); e.stopPropagation(); pressBtn('p'); };
    const onBS = (e) => { e.preventDefault(); e.stopPropagation(); pressBtn('s'); };
    bM.b.addEventListener('pointerdown', onBM); bP.b.addEventListener('pointerdown', onBP); bS.b.addEventListener('pointerdown', onBS);
    function onDown(e) {
      if (!lay || lay.sp) return;
      const q = cv.local(e);
      if (!stick) { stick = { id: e.pointerId, bx: q.x, by: q.y, x: q.x, y: q.y }; try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {} }
      e.preventDefault();
    }
    function onMove(e) { if (stick && e.pointerId === stick.id) { const q = cv.local(e); stick.x = q.x; stick.y = q.y; const dx = q.x - stick.bx, dy = q.y - stick.by, d = hyp(dx, dy); if (d > STICK_R * 1.6) { stick.bx = q.x - dx / d * STICK_R * 1.6; stick.by = q.y - dy / d * STICK_R * 1.6; } } }
    function onUp(e) { if (stick && e.pointerId === stick.id) stick = null; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    const releaseAll = () => { stick = null; };
    window.addEventListener('blur', releaseAll);
    const offIn = api.input ? api.input.on((type, id) => { if (type !== 'down') return; if (id === 'act') pressBtn('m'); else if (id === 'plank') pressBtn('p'); else if (id === 'skill') pressBtn('s'); }) : null;
    function readInput() {
      let sx = 0, sy = 0;
      if (stick) {
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), dz = 5;
        if (d > dz) { const m = Math.min(1, (d - dz) / (STICK_R * 0.7 - dz)); sx = dx / d * m; sy = dy / d * m; }
      }
      if (!sx && !sy && api.input) { const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down'); if (kx || ky) { const m = hyp(kx, ky); sx = m > 1 ? kx / m : kx; sy = m > 1 ? ky / m : ky; } }
      locIn.ax = sx; locIn.ay = sy;
    }

    /* ----- host flow ----- */
    const remIn = {};
    const newRem = () => ({ ax: 0, ay: 0, act: 0, pl: 0, sk: 0, ta: null, h: -1, h2: -1, h3: -1 });
    function inputsFor(dt) {
      const out = [];
      for (let s = 0; s < W.pl.length; s++) {
        if (isAIseat(s)) out[s] = aiThink(W, W.pl[s], aiMem[s] || (aiMem[s] = {}), P(s).ai ? lvOf(s) : 2, dt);
        else if (localHuman(s)) out[s] = locIn;
        else out[s] = remIn[s] || (remIn[s] = newRem());
      }
      return out;
    }
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'play' && W && W.res && !W.res.sent) { W.res.sent = 1; api.setState(roundOver(st, roundRows(W), W.res.win)); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRound(st)); } }
    }

    /* ----- online ----- */
    let pubT = 0, hsQ = 0, lastQ = -1, lastSig = '', inT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.pl.length) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = newRem());
        const pj = W.pl[s];
        if (W.t < START_T && pj && !pj.z && Number.isInteger(o.j) && o.j >= 0 && o.j < JB.length) { pj.jb = o.j; }
        if (o.r === 1) setJr(s);
        R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
        for (const [hk, f] of [['h', 'act'], ['h2', 'pl'], ['h3', 'sk']]) {
          const h = o[hk] | 0;
          if ((R[hk] >= 0 && h !== R[hk]) || (R[hk] < 0 && h > 0)) R[f] = 1;
          R[hk] = h;
        }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.P)) return;
      lastQ = hs.q;
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; try { onFx(e[1] | 0, (+e[2] || 0) / 10, (+e[3] || 0) / 10, e[4] | 0, e[5] | 0); } catch (er) {} }
      try { applySnap(W, hs, auto() ? -1 : me()); } catch (er) { console.error(er); }
    }
    function guestStep(dt, rdt) {
      const m = auto() ? -1 : me();
      const k = 1 - Math.exp(-rdt * 12);
      W.t += dt;
      W.pl.forEach((p, i) => {
        if (!fin(p.nx)) return;
        if (i === m && !p.esc && !p.tf && !p.stun && !p.ln && !p.cl && !p.jp && W.t >= (p.z ? START_T : 0)) {
          movePl(W, p, locIn, dt);
          const kk = 1 - Math.exp(-rdt * 4);
          p.x += (p.nx - p.x) * kk; p.y += (p.ny - p.y) * kk;
          return;
        }
        p.x += (p.nx - p.x) * k; p.y += (p.ny - p.y) * k;
        if (fin(p.na)) p.a = wrapA(p.a + wrapA(p.na - p.a) * k);
      });
    }
    function publish(rdt) {
      if (!api.online || !W || !st) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0 || st.ph !== 'play') return;
          pubT = 1 / 15; hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(snapshot(W, key, hsQ));
        } else {
          if (me() < 0) return;
          const ax = Math.round(locIn.ax * 100) / 100, ay = Math.round(locIn.ay * 100) / 100;
          const sig = ax + '|' + ay + '|' + netA.h + '|' + netA.h2 + '|' + netA.h3 + '|' + netA.j + '|' + netA.r;
          if ((sig === lastSig && inT > 0) || pubT > 0) return;
          lastSig = sig; inT = 0.25; pubT = 1 / 20;
          api.net.publish({ k: key, ax, ay, h: netA.h, h2: netA.h2, h3: netA.h3, j: netA.j, r: netA.r });
        }
      } catch (e) {}
    }

    /* ----- effects ----- */
    function burst(x, y, n, c, sp, life, sz) {
      for (let k = 0; k < n; k++) { const a = Math.random() * TAU, v = sp * (0.4 + Math.random() * 0.8); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, l: life * (0.6 + Math.random() * 0.6), c, s: sz * (0.6 + Math.random() * 0.8), r: Math.random() * TAU }); }
      if (parts.length > 160) parts.splice(0, parts.length - 160);
    }
    function near(x, y, r) { const p = myP(); return !!p && hyp(p.x - x, p.y - y) < r; }
    function onFx(code, x, y, a, b) {
      const m = auto() ? -1 : me(), mp = myP();
      if (code === FX_INF) {
        const zi = b >> 3, zt = b & 7, zn = ZT[zt] ? ZT[zt].nm : '좀비';
        rings.push({ x, y, t: 0, c: ZSKIN, r: 1.6 });
        burst(x, y, 14, ZSK[zt] || ZSKIN, 2.6, 0.7, 0.12);
        decals.push({ x, y, r: Math.random() * TAU, c: ZSK2[zt] || ZDARK }); if (decals.length > 12) decals.shift();
        floats.push({ x, y, t: 0, s: '감염! ' + zn, c: ZSK[zt] || ZSKIN });
        if (anim[a]) anim[a].hit = 0.6;
        if (a === m) { banner = { s: '감염됐어요! — ' + zn, s2: (ZT[zt] ? ZT[zt].d : '') + ' (작은 버튼)', t: -0.4, c: ZSK[zt] || ZSKIN, long: 1 }; api.sfx('lose'); api.buzz(160); shake = 0.5; infA = 1; Snd.groan(1.5); }
        else if (zi === m) { api.sfx('win'); api.buzz(40); floats.push({ x, y: y - 0.6, t: 0, s: '+' + PT_INF, c: '#e3ae45' }); }
        else { api.sfx('hit'); if (near(x, y, 6) && mp && !mp.z) shake = Math.max(shake, 0.15); }
      } else if (code === FX_FLASH) { rings.push({ x, y, t: 0, c: '#fff3b0', r: FLASH_R }); if (seen(x, y)) flashA = Math.max(flashA, b > 0 ? 0.55 : 0.3); api.sfx('pop'); if (b > 0) floats.push({ x, y: y - 0.5, t: 0, s: '눈부심!', c: '#fff3b0' }); }
      else if (code === FX_TRAP) { floats.push({ x, y, t: 0, s: '철컥!', c: '#d8d8e0' }); burst(x, y, 6, '#d8d8e0', 1.5, 0.4, 0.06); api.sfx('click'); }
      else if (code === FX_DOORX || code === FX_BARX || code === FX_SMASH) {
        floats.push({ x, y, t: 0, s: code === FX_SMASH ? '박살!' : code === FX_BARX ? '와장창!' : '쾅!', c: '#ee6a55' });
        rings.push({ x, y, t: 0, c: '#c98a4a', r: 1.2 }); burst(x, y, code === FX_SMASH ? 18 : 12, '#a8703c', 3.2, 0.7, 0.14);
        if (seen(x, y)) { shake = Math.max(shake, code === FX_SMASH ? 0.4 : 0.25); Snd.crash(); } api.sfx('thud');
      }
      else if (code === FX_BASH) { if (seen(x, y)) { floats.push({ x, y, t: 0, s: '쿵', c: '#f2e9d8' }); burst(x, y, 4, '#a8703c', 1.6, 0.4, 0.08); api.sfx('thud'); } }
      else if (code === FX_CLOSE) { if (seen(x, y)) api.sfx('thud'); }
      else if (code === FX_OPEN) { if (seen(x, y)) api.sfx('click'); }
      else if (code === FX_DRINK) { if (a === m) api.sfx('whoosh'); floats.push({ x, y, t: 0, s: '쌩!', c: '#7fd6ff' }); }
      else if (code === FX_VAC) { rings.push({ x, y, t: 0, c: '#9be3ff', r: 1.4 }); floats.push({ x, y, t: 0, s: '백신 방어!', c: '#9be3ff' }); api.sfx('chip'); if (a === m) api.buzz(60); }
      else if (code === FX_ESC) { floats.push({ x, y, t: 0, s: '탈출!', c: '#e3ae45' }); api.sfx(a === m ? 'win' : 'whoosh'); if (a === m) banner = { s: '탈출 성공!', s2: THEMES[W.M.th].rz + '에 탔어요 — 남은 시간도 점수로', t: 0, c: '#e3ae45' }; }
      else if (code === FX_TIER) { banner = { s: a === 2 ? '좀비 무리가 커졌어요!' : '좀비가 냄새를 맡아요!', s2: a === 2 ? '문·판자를 2배 빨리 부숴요' : '좀비 화면에 가장 가까운 사람 방향이 보여요', t: 0, c: ZSKIN }; api.sfx('thud'); }
      else if (code === FX_PICK) { if (a === m) { api.sfx('chip'); floats.push({ x, y, t: 0, s: b === 5 ? '판자 +2' : IT_NM[b], c: '#f2e9d8' }); } }
      else if (code === FX_SETTRAP) { if (seen(x, y)) api.sfx('click'); }
      else if (code === FX_HELI) { banner = { s: THEMES[W.M.th].rz + ' 도착!', s2: '30초 동안 H 위에 서면 탈출', t: 0, c: '#e3ae45' }; api.sfx('whoosh'); }
      else if (code === FX_BAR) { if (seen(x, y)) { floats.push({ x, y, t: 0, s: b ? '보강!' : '탕탕!', c: '#e8c08a' }); burst(x, y, 6, '#d8b878', 1.8, 0.45, 0.07); Snd.hammer(); } }
      else if (code === FX_PRY) { if (a === m) { floats.push({ x, y, t: 0, s: '판자 뜯음 +1', c: '#e8c08a' }); api.sfx('click'); } else if (seen(x, y)) api.sfx('click'); }
      else if (code === FX_CLIMB) { if (seen(x, y) || a === m) api.sfx('tick'); }
      else if (code === FX_ROOF) { if (a === m) banner = { s: '지붕 위!', s2: ROOF_T + '초 동안 안전 — 도약 좀비는 올라와요', t: 0, c: '#9fc8ff' }; }
      else if (code === FX_SLIP) { floats.push({ x, y, t: 0, s: '미끄러짐!', c: '#9fc8ff' }); burst(x, y, 6, '#bbbbbb', 1.4, 0.5, 0.08); if (a === m) { banner = { s: '지붕에서 미끄러졌어요!', s2: '지붕은 ' + ROOF_T + '초까지만 버틸 수 있어요', t: 0, c: '#ee6a55' }; api.buzz(80); } api.sfx('thud'); }
      else if (code === FX_LURE) { rings.push({ x, y, t: 0, c: '#ffb050', r: 1.2 }); if (seen(x, y)) Snd.ring(); floats.push({ x, y, t: 0, s: '딸랑딸랑', c: '#ffb050' }); }
      else if (code === FX_BARI) { if (seen(x, y)) { floats.push({ x, y, t: 0, s: '바리케이드!', c: '#e8a030' }); rings.push({ x, y, t: 0, c: '#e8a030', r: 1 }); Snd.hammer(); } }
      else if (code === FX_BARIX) { if (seen(x, y)) { floats.push({ x, y, t: 0, s: '바리케이드 치움', c: '#c8c0b0' }); api.sfx('click'); } }
      else if (code === FX_SMOKE) { burst(x, y, 16, 'rgba(210,214,210,.8)', 2.2, 0.9, 0.16); if (seen(x, y)) { floats.push({ x, y, t: 0, s: '연막!', c: '#d8dcd8' }); api.sfx('whoosh'); } }
      else if (code === FX_CURE) { rings.push({ x, y, t: 0, c: '#ff9ab0', r: 1.4 }); floats.push({ x, y, t: 0, s: '해독!', c: '#ff9ab0' }); api.sfx('chip'); if (a === m) { api.buzz(60); banner = { s: '의무병 해독!', s2: '이번 한 번은 버텼어요 — 다음엔 감염돼요', t: -0.2, c: '#ff9ab0' }; } }
      else if (code === FX_RADIO) { if (a === m) { rings.push({ x, y, t: 0, c: '#9be3ff', r: 2.5 }); api.sfx('chip'); } }
      else if (code === FX_RUN) { if (anim[a]) anim[a].sk = 0.5; if (seen(x, y)) { floats.push({ x, y, t: 0, s: '질주!', c: '#ff7a5a' }); api.sfx('whoosh'); } }
      else if (code === FX_SNIFF) {
        if (anim[a]) anim[a].snf = 1.2; rings.push({ x, y, t: 0, c: '#c8a8ff', r: SNIFF_R * 0.3 });
        if (seen(x, y)) { floats.push({ x, y, t: 0, s: '킁킁', c: '#c8a8ff' }); Snd.sniff(); }
        if (mp && !mp.z && hyp(mp.x - x, mp.y - y) < SNIFF_R) { banner = { s: '냄새를 들켰어요!', s2: '좀비들에게 내 위치가 잠깐 보여요', t: 0, c: '#c8a8ff' }; api.buzz(50); }
      } else if (code === FX_LEAP) { burst(x, y, 6, 'rgba(200,190,170,.8)', 1.2, 0.4, 0.1); if (seen(x, y)) api.sfx('whoosh'); }
      else if (code === FX_LAND) { burst(x, y, 8, 'rgba(200,190,170,.8)', 1.6, 0.45, 0.1); rings.push({ x, y, t: 0, c: 'rgba(220,210,190,.8)', r: 0.8 }); if (seen(x, y)) api.sfx('thud'); }
      else if (code === FX_SCREAM) {
        if (anim[a]) anim[a].scr = 1.2;
        rings.push({ x, y, t: 0, c: '#9cc8dc', r: SCREAM_R }); rings.push({ x, y, t: -0.15, c: '#9cc8dc', r: CALL_R });
        const d = mp ? hyp(mp.x - x, mp.y - y) : 99;
        Snd.scream(d < CALL_R ? 1.4 : 0.6);
        if (mp && !mp.z && d < SCREAM_R) { banner = { s: '비명! 움찔했어요', s2: '좀비들에게 내 위치가 보여요', t: 0, c: '#9cc8dc' }; shake = Math.max(shake, 0.35); api.buzz(90); }
        else if (mp && mp.z && d < CALL_R) floats.push({ x: mp.x, y: mp.y, t: 0, s: '부름! 빨라져요', c: '#9cc8dc' });
      }
    }
    function drainFx() {
      for (const e of W.fx) if (e[0] > lastFx) { lastFx = e[0]; onFx(e[1], e[2] / 10, e[3] / 10, e[4], e[5]); }
    }

    /* ----- visibility (fog of war per phone) ----- */
    function lightR(p) { return (p.z ? LIGHT_Z : LIGHT_S) + (p.up ? 1.2 : 0); }
    function seen(x, y) {
      if (!lay || lay.sp) return true;
      const p = myP(); if (!p) return true;
      if (!W.dark) return true;
      return hyp(x - p.x, y - p.y) < lightR(p) + 0.4 && (p.up || los(W, p.x, p.y, x, y));
    }
    function visible(q) {
      const p = myP();
      if (!p || q === p || !lay || lay.sp) return true;
      if (!p.z && p.rv > 0 && q.z) return true; // radio: zombie positions for a moment
      if (p.z && !q.z && !q.esc) {
        if (q.rev > 0) return true;
        if (hidden(q)) return hyp(q.x - p.x, q.y - p.y) < (p.zt === 2 ? 3 : q.jb === 7 ? SNEAK_SEE : HIDE_SEE);
      }
      if (W.dark) return hyp(q.x - p.x, q.y - p.y) < lightR(p) + 0.3 && losP(W, p, q);
      return true;
    }

    /* ----- main loop ----- */
    function frame(rdt) {
      if (!st) return;
      if (curKey() !== key) startRound();
      if (!W) return;
      const dt = rdt * SPD();
      readInput();
      if (host()) {
        pollHost();
        if (st.ph === 'play' && !W.res && !jobHold()) { const I = inputsFor(dt); tickWorld(W, dt, I); drainFx(); }
        hostFlow(dt);
      } else {
        pollGuest();
        if (st.ph === 'play') guestStep(dt, rdt);
      }
      publish(rdt);
      // countdown ticks
      if (st.ph === 'play' && W.t < START_T) { const n = Math.ceil(START_T - W.t); if (n !== lastCount) { lastCount = n; if (n <= 3) api.sfx('tick'); } }
      else if (st.ph === 'play' && lastCount !== 0 && W.t >= START_T) { lastCount = 0; api.sfx('whoosh'); Snd.groan(0.8); }
      const sp = spect();
      if (lay && sp !== lay.sp) { lay = null; layout(); }
      if (lay && !lay.sp) { const t = camTarget(), k = 1 - Math.exp(-rdt * 8); cam.x += (t.x - cam.x) * k; cam.y += (t.y - cam.y) * k; }
      // per-character animation (walk cycle from distance moved, jump / climb timers)
      W.pl.forEach((p, i) => {
        const an = anim[i]; if (!an) return;
        const d = hyp(p.x - an.lx, p.y - an.ly); an.lx = p.x; an.ly = p.y;
        if (d < 1.5) { an.ph += d * 7; an.sp += (Math.min(6, d / Math.max(1e-3, dt)) - an.sp) * Math.min(1, rdt * 10); }
        an.jt = p.jp ? an.jt + dt : 0;
        an.ct = p.cl ? Math.min(1, an.ct + dt / (p.z ? CLIMB_Z : CLIMB_S)) : 0;
        an.sk = Math.max(0, an.sk - rdt); an.scr = Math.max(0, an.scr - rdt); an.snf = Math.max(0, an.snf - rdt); an.hit = Math.max(0, an.hit - rdt);
      });
      for (const f of floats) f.t += rdt; floats = floats.filter((f) => f.t < 1.3);
      for (const r of rings) r.t += rdt; rings = rings.filter((r) => r.t < 0.7);
      for (const q of parts) { q.t += rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vx *= 1 - rdt * 3; q.vy *= 1 - rdt * 3; q.r += rdt * 6; } parts = parts.filter((q) => q.t < q.l);
      if (banner) { banner.t += rdt; if (banner.t > (banner.long ? 3.4 : 2.6)) banner = null; }
      shake = Math.max(0, shake - rdt); flashA = Math.max(0, flashA - rdt * 0.9); infA = Math.max(0, infA - rdt * 0.7);
      for (const k in press) press[k] = Math.max(0, press[k] - rdt);
      tension(rdt);
    }
    // heartbeat when a zombie is near me (survivor), slow groans when they're close
    function tension(rdt) {
      const m = myP();
      let k = 0;
      if (m && !m.z && !m.esc && st.ph === 'play' && W.t >= START_T - 1) {
        let d = 1e9; for (const q of W.pl) if (q.z && !q.esc && q.tf <= 0) d = Math.min(d, hyp(q.x - m.x, q.y - m.y) + (q.up !== m.up ? 2.5 : 0));
        k = clamp((7 - d) / 5.5, 0, 1);
        if (hidden(m)) k = Math.min(1, k * 1.25);
        groanT -= rdt;
        if (d < 4.5 && groanT <= 0) { groanT = 2.5 + Math.random() * 3; Snd.groan(clamp(1.2 - d / 5, 0.3, 1)); }
      }
      hbK += (k - hbK) * Math.min(1, rdt * 4);
      if (hbK > 0.04) {
        const bpm = 66 + 96 * hbK, prev = hbPh;
        hbPh += rdt * bpm / 60;
        if (Math.floor(hbPh) !== Math.floor(prev)) { hbPulse = 1; Snd.beat(hbK); if (hbK > 0.7) api.buzz(18); }
      }
      hbPulse = Math.max(0, hbPulse - rdt * 3.2);
    }

    /* ----- drawing ----- */
    function drawItem(g, k, x, y, s, now) {
      const b = Math.sin(now / 300 + x) * s * 0.05;
      g.save(); g.translate(x, y + b);
      g.fillStyle = 'rgba(255,255,255,.18)'; g.beginPath(); g.arc(0, 0, s * 0.36, 0, TAU); g.fill();
      if (k === 0) { // speed drink
        g.fillStyle = '#4fc3f7'; rr(g, -s * 0.12, -s * 0.18, s * 0.24, s * 0.38, s * 0.06); g.fill();
        g.fillStyle = '#e0f7ff'; g.fillRect(-s * 0.06, -s * 0.27, s * 0.12, s * 0.1);
        g.fillStyle = '#ffe14d'; g.beginPath(); g.moveTo(s * 0.02, -s * 0.12); g.lineTo(-s * 0.06, s * 0.02); g.lineTo(s * 0.01, s * 0.02); g.lineTo(-s * 0.03, s * 0.14); g.lineTo(s * 0.07, -s * 0.01); g.lineTo(0, -s * 0.01); g.closePath(); g.fill();
      } else if (k === 1) { // trap
        g.strokeStyle = '#c8c8d2'; g.lineWidth = s * 0.06; g.beginPath(); g.arc(0, 0, s * 0.2, 0, TAU); g.stroke();
        g.fillStyle = '#c8c8d2'; for (let i = 0; i < 6; i++) { const a = i / 6 * TAU; g.beginPath(); g.moveTo(Math.cos(a) * s * 0.2, Math.sin(a) * s * 0.2); g.lineTo(Math.cos(a + 0.25) * s * 0.08, Math.sin(a + 0.25) * s * 0.08); g.lineTo(Math.cos(a - 0.25) * s * 0.08, Math.sin(a - 0.25) * s * 0.08); g.fill(); }
      } else if (k === 2) { // flashlight
        g.rotate(-0.6);
        g.fillStyle = '#ffd54a'; g.fillRect(-s * 0.22, -s * 0.07, s * 0.3, s * 0.14);
        g.fillStyle = '#ffe98a'; g.beginPath(); g.moveTo(s * 0.06, -s * 0.12); g.lineTo(s * 0.2, -s * 0.15); g.lineTo(s * 0.2, s * 0.15); g.lineTo(s * 0.06, s * 0.12); g.fill();
        g.fillStyle = 'rgba(255,250,200,.6)'; g.beginPath(); g.moveTo(s * 0.2, -s * 0.12); g.lineTo(s * 0.34, -s * 0.2); g.lineTo(s * 0.34, s * 0.2); g.lineTo(s * 0.2, s * 0.12); g.fill();
      } else if (k === 3) { // vaccine vial
        g.fillStyle = '#eef6ff'; rr(g, -s * 0.1, -s * 0.2, s * 0.2, s * 0.4, s * 0.06); g.fill();
        g.fillStyle = '#7be08a'; g.fillRect(-s * 0.08, -s * 0.02, s * 0.16, s * 0.16);
        g.fillStyle = '#3a7bd5'; g.fillRect(-s * 0.03, -s * 0.16, s * 0.06, s * 0.1); g.fillRect(-s * 0.06, -s * 0.13, s * 0.12, s * 0.04);
      } else if (k === 4) { // alarm clock noise maker
        g.fillStyle = '#ff9a40'; g.beginPath(); g.arc(0, s * 0.02, s * 0.17, 0, TAU); g.fill();
        g.fillStyle = '#fff4e0'; g.beginPath(); g.arc(0, s * 0.02, s * 0.11, 0, TAU); g.fill();
        g.strokeStyle = '#2a1d10'; g.lineWidth = Math.max(1, s * 0.03); g.beginPath(); g.moveTo(0, s * 0.02); g.lineTo(0, -s * 0.06); g.moveTo(0, s * 0.02); g.lineTo(s * 0.06, s * 0.04); g.stroke();
        g.fillStyle = '#ff9a40'; g.beginPath(); g.arc(-s * 0.12, -s * 0.15, s * 0.06, 0, TAU); g.fill(); g.beginPath(); g.arc(s * 0.12, -s * 0.15, s * 0.06, 0, TAU); g.fill();
      } else if (k === 6) { // folding barricade
        g.fillStyle = '#e8a030'; g.fillRect(-s * 0.26, -s * 0.12, s * 0.52, s * 0.14);
        g.fillStyle = '#1e1e1e'; for (let i = 0; i < 3; i++) { g.beginPath(); g.moveTo(-s * 0.2 + i * s * 0.17, -s * 0.12); g.lineTo(-s * 0.12 + i * s * 0.17, -s * 0.12); g.lineTo(-s * 0.18 + i * s * 0.17, s * 0.02); g.lineTo(-s * 0.26 + i * s * 0.17, s * 0.02); g.fill(); }
        g.fillStyle = '#9aa0a6'; g.fillRect(-s * 0.22, s * 0.02, s * 0.05, s * 0.18); g.fillRect(s * 0.17, s * 0.02, s * 0.05, s * 0.18);
      } else if (k === 7) { // smoke canister
        g.fillStyle = '#5a6a5a'; rr(g, -s * 0.1, -s * 0.12, s * 0.2, s * 0.32, s * 0.05); g.fill();
        g.fillStyle = '#c8ccc8'; g.fillRect(-s * 0.1, -s * 0.02, s * 0.2, s * 0.05);
        g.fillStyle = '#2a2e2a'; g.fillRect(-s * 0.04, -s * 0.2, s * 0.08, s * 0.08);
        g.fillStyle = 'rgba(220,225,220,.7)'; g.beginPath(); g.arc(s * 0.1, -s * 0.24, s * 0.07, 0, TAU); g.arc(s * 0.18, -s * 0.3, s * 0.05, 0, TAU); g.fill();
      } else { // plank bundle
        g.rotate(-0.3);
        for (let i = -1; i <= 1; i++) { g.fillStyle = i ? '#b88a50' : '#c89a60'; g.fillRect(-s * 0.26, i * s * 0.09 - s * 0.04, s * 0.52, s * 0.08); }
        g.fillStyle = '#5a3a20'; g.fillRect(-s * 0.12, -s * 0.16, s * 0.04, s * 0.3); g.fillRect(s * 0.1, -s * 0.16, s * 0.04, s * 0.3);
      }
      g.restore();
    }
    function skinOf(p) { return p.alpha ? ZSKIN : ZSK[p.zt] || ZSKIN; }
    function drawChar(p, i, now) {
      const an = anim[i] || { ph: 0, sp: 0, jt: 0, ct: 0, sk: 0, scr: 0, snf: 0, hit: 0 };
      const base = lay.ts * (p.up ? 1.12 : 1), x = SX(p.x), y0 = SY(p.y), a = p.a, col = COL(i), mine = myP() === p;
      if (x < -base * 2 || y0 < -base * 2 || x > lay.w + base * 2 || y0 > lay.h + base * 2) return;
      const tf = p.tf ? 1 : 0, z = p.z && !tf, big = z && p.zt === 1 ? 1.2 : z && p.zt === 0 ? 0.9 : 1, s = base;
      let lift = 0;
      if (p.jp) lift = Math.sin(clamp(an.jt / LEAP_T, 0, 1) * Math.PI) * s * 0.75;
      if (p.cl) lift = (p.cdir > 0 ? an.ct : 1 - an.ct) * s * 0.55;
      const y = y0 - lift;
      ctx.save();
      const hid = hidden(p);
      if (hid) ctx.globalAlpha = 0.55;
      // shadow
      const shk = 1 - lift / (s * 1.5);
      ctx.fillStyle = 'rgba(0,0,0,' + (p.up ? 0.4 : 0.3) + ')'; ctx.beginPath(); ctx.ellipse(x + lift * 0.3, y0 + s * 0.26, s * 0.34 * big * shk, s * 0.14 * shk, 0, 0, TAU); ctx.fill();
      if (mine) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.ellipse(x, y0 + s * 0.26, s * 0.46 * big, s * 0.2, 0, 0, TAU); ctx.stroke(); }
      if (p.alpha) { const gl = ctx.createRadialGradient(x, y, s * 0.2, x, y, s * 0.9); gl.addColorStop(0, 'rgba(170,90,230,.55)'); gl.addColorStop(1, 'rgba(170,90,230,0)'); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(x, y, s * 0.9, 0, TAU); ctx.fill(); }
      if (p.boost) { const pr = 0.5 + 0.5 * Math.sin(now / 90); ctx.strokeStyle = 'rgba(156,200,220,' + (0.35 + pr * 0.4) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, s * (0.5 + pr * 0.08), 0, TAU); ctx.stroke(); }
      if (p.rev && !p.z) { const pr = 0.5 + 0.5 * Math.sin(now / 120); ctx.strokeStyle = 'rgba(238,106,85,' + (0.4 + pr * 0.5) + ')'; ctx.lineWidth = 2.5; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.arc(x, y, s * 0.6, now / 400, now / 400 + TAU); ctx.stroke(); ctx.setLineDash([]); }
      if (p.ln) { ctx.strokeStyle = 'rgba(140,207,106,.5)'; ctx.lineWidth = s * 0.12; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - Math.cos(a) * s * 0.9, y - Math.sin(a) * s * 0.9); ctx.stroke(); }
      if (p.dk || p.run) { ctx.strokeStyle = p.run ? 'rgba(255,122,90,.75)' : 'rgba(127,214,255,.7)'; ctx.lineWidth = 2; for (let k = -1; k <= 1; k++) { const ox = -Math.sin(a) * k * s * 0.18, oy = Math.cos(a) * k * s * 0.18; ctx.beginPath(); ctx.moveTo(x + ox - Math.cos(a) * s * 0.45, y + oy - Math.sin(a) * s * 0.45); ctx.lineTo(x + ox - Math.cos(a) * s * 0.85, y + oy - Math.sin(a) * s * 0.85); ctx.stroke(); } }
      if (tf) { ctx.strokeStyle = skinOf(p); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, s * 0.48, now / 120, now / 120 + 4.2); ctx.stroke(); ctx.beginPath(); ctx.arc(x, y, s * 0.6, -now / 160, -now / 160 + 2.4); ctx.stroke(); }
      // feet (walk cycle)
      const mv = clamp(an.sp / 3, 0, 1), sw = Math.sin(an.ph) * mv, ca = Math.cos(a), sa = Math.sin(a);
      ctx.fillStyle = z ? ZSK2[p.zt] || ZDARK : '#3a2a20';
      for (const sd of [-1, 1]) {
        const f = sw * sd * s * 0.17, fx = x - sa * sd * s * 0.14 * big + ca * f, fy = y + ca * sd * s * 0.14 * big + sa * f;
        ctx.beginPath(); ctx.ellipse(fx, fy, s * 0.1 * big, s * 0.07 * big, a, 0, TAU); ctx.fill();
      }
      if (z) { // arms reaching forward
        const sk = skinOf(p);
        ctx.strokeStyle = sk; ctx.lineCap = 'round'; ctx.lineWidth = s * (p.zt === 1 ? 0.17 : 0.13);
        const wob = Math.sin(now / 150 + i) * 0.12, len = s * (p.zt === 3 ? 0.55 : p.zt === 1 ? 0.36 : 0.42);
        for (const sd of [-1, 1]) {
          const bx = x + Math.cos(a + sd * 1.25) * s * 0.26 * big, by = y + Math.sin(a + sd * 1.25) * s * 0.26 * big;
          const aa = p.zt === 4 && an.scr > 0 ? a + sd * 1.1 : a + sd * wob;
          ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + Math.cos(aa) * len, by + Math.sin(aa) * len); ctx.stroke();
        }
      }
      // body (shirt in player colour; torn and darker on zombies)
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, s * 0.34 * big, 0, TAU); ctx.fill();
      if (z) { ctx.fillStyle = 'rgba(20,30,10,.35)'; ctx.beginPath(); ctx.arc(x - ca * s * 0.12, y - sa * s * 0.12, s * 0.22 * big, a + 2, a + 4.2); ctx.fill(); ctx.fillStyle = ZSK2[p.zt] || ZDARK; ctx.beginPath(); ctx.arc(x + sa * s * 0.18, y - ca * s * 0.18, s * 0.06, 0, TAU); ctx.fill(); }
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(x, y, s * 0.34 * big, 0, TAU); ctx.stroke();
      if (z && p.zt === 1) { ctx.fillStyle = '#5a5e66'; for (const sd of [-1, 1]) { ctx.save(); ctx.translate(x - sa * sd * s * 0.3, y + ca * sd * s * 0.3); ctx.rotate(a); rr(ctx, -s * 0.12, -s * 0.09, s * 0.24, s * 0.18, s * 0.05); ctx.fill(); ctx.restore(); } }
      // head
      const hx = x + ca * s * 0.05, hy = y + sa * s * 0.05, hr = s * 0.23 * (z && p.zt === 1 ? 1.08 : 1);
      ctx.fillStyle = z || tf ? skinOf(p) : '#f6d7b0'; ctx.beginPath(); ctx.arc(hx, hy, hr, 0, TAU); ctx.fill();
      ctx.strokeStyle = z || tf ? ZSK2[p.zt] || ZDARK : '#c79a72'; ctx.lineWidth = 1.2; ctx.stroke();
      if (!z && !tf) { ctx.fillStyle = ['#3a2416', '#1e1a18', '#6a3a1a', '#b8862e'][i % 4]; ctx.beginPath(); ctx.arc(hx, hy, hr, a + 1.6, a + 4.7); ctx.fill(); }
      const ex = ca * s * 0.1, ey = sa * s * 0.1, px = -sa * s * 0.085, py = ca * s * 0.085;
      if (z) {
        // type features first (behind the eyes)
        if (p.zt === 0) { ctx.strokeStyle = '#d83a2a'; ctx.lineWidth = s * 0.07; ctx.beginPath(); ctx.arc(hx, hy, hr * 0.92, a + 1.2, a + 5.1); ctx.stroke(); ctx.beginPath(); ctx.moveTo(hx - ca * hr, hy - sa * hr); ctx.lineTo(hx - ca * hr * 1.9 + px * 0.6 * Math.sin(now / 80), hy - sa * hr * 1.9 + py * 0.6 * Math.sin(now / 80)); ctx.stroke(); }
        else if (p.zt === 1) { ctx.fillStyle = '#4a4e56'; ctx.beginPath(); ctx.arc(hx, hy, hr * 1.02, a + 1.9, a + 4.4); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.2)'; ctx.fillRect(hx - ca * hr * 0.5 - 2, hy - sa * hr * 0.5 - 2, 3, 3); }
        else if (p.zt === 3) { ctx.fillStyle = ZSK2[3]; for (const k of [-0.5, 0, 0.5]) { const aa = a + Math.PI + k; ctx.beginPath(); ctx.moveTo(hx + Math.cos(aa - 0.25) * hr * 0.8, hy + Math.sin(aa - 0.25) * hr * 0.8); ctx.lineTo(hx + Math.cos(aa) * hr * 1.6, hy + Math.sin(aa) * hr * 1.6); ctx.lineTo(hx + Math.cos(aa + 0.25) * hr * 0.8, hy + Math.sin(aa + 0.25) * hr * 0.8); ctx.fill(); } }
        ctx.fillStyle = '#fffbe0'; ctx.beginPath(); ctx.arc(hx + ex + px, hy + ey + py, s * 0.075, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(hx + ex - px, hy + ey - py, s * 0.055, 0, TAU); ctx.fill();
        ctx.fillStyle = p.alpha ? '#b02a8a' : p.zt === 2 ? '#5a2a90' : '#c22'; ctx.beginPath(); ctx.arc(hx + ex * 1.2 + px, hy + ey * 1.2 + py, s * 0.035, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(hx + ex * 1.2 - px, hy + ey * 1.2 - py, s * 0.028, 0, TAU); ctx.fill();
        if (p.zt === 2) { // big nose + sniff puffs
          ctx.fillStyle = ZSK2[2]; ctx.beginPath(); ctx.arc(hx + ex * 2.1, hy + ey * 2.1, s * 0.07, 0, TAU); ctx.fill();
          if (an.snf > 0 || Math.sin(now / 300 + i) > 0.85) { ctx.fillStyle = 'rgba(200,168,255,.55)'; for (let k = 0; k < 3; k++) { const t = (now / 400 + k / 3) % 1; ctx.beginPath(); ctx.arc(hx + ex * (2.4 + t * 4) + px * (k - 1) * 0.8, hy + ey * (2.4 + t * 4) + py * (k - 1) * 0.8, s * 0.04 * (1 - t), 0, TAU); ctx.fill(); } }
        } else if (p.zt === 4) { // gaping mouth + sound waves
          const op = an.scr > 0 ? 1.6 : 1 + 0.2 * Math.sin(now / 200);
          ctx.fillStyle = '#2a0a14'; ctx.beginPath(); ctx.ellipse(hx + ex * 1.7, hy + ey * 1.7, s * 0.06 * op, s * 0.08 * op, a, 0, TAU); ctx.fill();
          if (an.scr > 0) { ctx.strokeStyle = 'rgba(156,200,220,.8)'; ctx.lineWidth = 2; for (let k = 0; k < 3; k++) { const rr2 = s * (0.4 + ((now / 160 + k / 3) % 1) * 0.9); ctx.beginPath(); ctx.arc(hx, hy, rr2, a - 0.7, a + 0.7); ctx.stroke(); } }
        } else { ctx.strokeStyle = ZSK2[p.zt] || ZDARK; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(hx + ex * 1.9 + px * 0.5, hy + ey * 1.9 + py * 0.5); ctx.lineTo(hx + ex * 1.9 - px * 0.5, hy + ey * 1.9 - py * 0.5); ctx.stroke(); }
      } else {
        ctx.fillStyle = '#2a1d10'; ctx.beginPath(); ctx.arc(hx + ex + px, hy + ey + py, s * 0.042, 0, TAU); ctx.fill(); ctx.beginPath(); ctx.arc(hx + ex - px, hy + ey - py, s * 0.042, 0, TAU); ctx.fill();
        if (p.scared) { ctx.fillStyle = '#9cc8dc'; ctx.beginPath(); ctx.arc(hx + px * 2.2, hy + py * 2.2 - s * 0.1, s * 0.05, 0, TAU); ctx.fill(); }
      }
      if (p.alpha && z) { // little crown
        ctx.fillStyle = '#e3ae45'; const cx = hx - ex * 0.8, cy = hy - ey * 0.8 - s * 0.2;
        ctx.beginPath(); ctx.moveTo(cx - s * 0.14, cy + s * 0.06); ctx.lineTo(cx - s * 0.14, cy - s * 0.06); ctx.lineTo(cx - s * 0.07, cy); ctx.lineTo(cx, cy - s * 0.09); ctx.lineTo(cx + s * 0.07, cy); ctx.lineTo(cx + s * 0.14, cy - s * 0.06); ctx.lineTo(cx + s * 0.14, cy + s * 0.06); ctx.closePath(); ctx.fill();
      }
      if (hid) { ctx.globalAlpha = 1; ctx.fillStyle = 'rgba(70,140,70,.55)'; for (let k = 0; k < 4; k++) { const aa = k / 4 * TAU + now / 900; ctx.beginPath(); ctx.arc(x + Math.cos(aa) * s * 0.26, y + Math.sin(aa) * s * 0.2, s * 0.17, 0, TAU); ctx.fill(); } ctx.globalAlpha = 0.55; }
      if (p.sh) { ctx.strokeStyle = 'rgba(155,227,255,.85)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, s * 0.5, 0, TAU); ctx.stroke(); ctx.fillStyle = 'rgba(155,227,255,.15)'; ctx.fill(); }
      if (p.stun) { ctx.fillStyle = p.trap ? '#d8d8e0' : '#fff3b0'; for (let k = 0; k < 3; k++) { const aa = now / 200 + k * TAU / 3; ctx.beginPath(); ctx.arc(x + Math.cos(aa) * s * 0.36, y - s * 0.42 + Math.sin(aa) * s * 0.1, s * 0.06, 0, TAU); ctx.fill(); } }
      if (an.hit > 0) { ctx.globalAlpha = an.hit; ctx.fillStyle = skinOf(p); ctx.beginPath(); ctx.arc(x, y, s * (0.5 + (0.6 - an.hit)), 0, TAU); ctx.fill(); ctx.globalAlpha = hid ? 0.55 : 1; }
      if (p.it >= 0 && !p.z && (mine || !lay.sp)) { ctx.save(); drawItem(ctx, p.it, x + s * 0.32, y - s * 0.34, s * 0.55, 0); ctx.restore(); }
      // name tag
      ctx.globalAlpha = 1;
      if (lay.ts >= 18 || mine) {
        ctx.font = '600 ' + Math.max(10, Math.round(s * 0.32)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
        const t = (!z && JB[p.jb] && !p.esc ? JB[p.jb].ic + ' ' : '') + name(i), ty = y - s * 0.5 * big - (p.alpha && z ? s * 0.12 : 0);
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,8,16,.8)'; ctx.strokeText(t, x, ty); ctx.fillStyle = z ? '#cfeebe' : '#f2e9d8'; ctx.fillText(t, x, ty);
      }
      if (p.hz > 0 && !p.esc) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, s * 0.55, -Math.PI / 2, -Math.PI / 2 + TAU * Math.min(1, p.hz / HELI_STAY)); ctx.stroke(); }
      if (p.up && !p.z && (mine || lay.sp)) { const f = clamp(1 - p.rt / ROOF_T, 0, 1); ctx.strokeStyle = f > 0.35 ? '#9fc8ff' : '#ee6a55'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, s * 0.62, -Math.PI / 2, -Math.PI / 2 + TAU * f); ctx.stroke(); }
      ctx.restore();
    }
    function drawPlanks(x, y, s, hz, b, now) {
      ctx.save(); ctx.translate(x + s / 2, y + s / 2); if (!hz) ctx.rotate(Math.PI / 2);
      const n = b > BAR_HP ? 3 : 2, f = clamp(b / BAR_HP, 0, 1);
      for (let k = 0; k < n; k++) {
        const yy = (k - (n - 1) / 2) * s * 0.26, rot = (k & 1 ? 0.18 : -0.14);
        ctx.save(); ctx.translate(0, yy); ctx.rotate(rot);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(-s * 0.62, -s * 0.07 + 2, s * 1.24, s * 0.16);
        ctx.fillStyle = k & 1 ? '#b8884e' : '#c89a5e'; ctx.fillRect(-s * 0.62, -s * 0.08, s * 1.24, s * 0.16);
        ctx.fillStyle = 'rgba(90,58,30,.6)'; ctx.fillRect(-s * 0.62, s * 0.02, s * 1.24, s * 0.03);
        ctx.fillStyle = '#d8d8e0'; ctx.fillRect(-s * 0.52, -s * 0.03, s * 0.05, s * 0.05); ctx.fillRect(s * 0.47, -s * 0.03, s * 0.05, s * 0.05);
        if (f < 0.5) { ctx.strokeStyle = 'rgba(40,20,10,.8)'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(-s * 0.1, -s * 0.08); ctx.lineTo(s * 0.02, 0); ctx.lineTo(-s * 0.04, s * 0.08); ctx.stroke(); }
        ctx.restore();
      }
      ctx.restore();
    }
    function hpBar(x, y, s, f) { ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fillRect(x + s * 0.1, y - s * 0.22, s * 0.8, s * 0.14); ctx.fillStyle = f > 0.5 ? '#9be36a' : f > 0.25 ? '#e3ae45' : '#ee6a55'; ctx.fillRect(x + s * 0.1, y - s * 0.22, s * 0.8 * f, s * 0.14); }
    function drawGates(now) {
      const M = W.M, s = lay.ts;
      M.gates.forEach((D, j) => {
        const x = SX(D.x - 0.5), y = SY(D.y - 0.5), d = W.gate[j];
        if (x < -s * 2 || y < -s * 2 || x > lay.w + s || y > lay.h + s) return;
        if (!D.win) {
          if (d.s === 1) {
            ctx.fillStyle = '#8a5a30'; ctx.fillRect(x + 1, y + 1, s - 2, s - 2);
            ctx.strokeStyle = '#5a3818'; ctx.lineWidth = Math.max(2, s * 0.08);
            ctx.beginPath(); ctx.moveTo(x + s * 0.15, y + s * 0.15); ctx.lineTo(x + s * 0.85, y + s * 0.85); ctx.moveTo(x + s * 0.85, y + s * 0.15); ctx.lineTo(x + s * 0.15, y + s * 0.85); ctx.stroke();
            ctx.strokeStyle = '#c99a5a'; ctx.lineWidth = 1.5; ctx.strokeRect(x + 1.5, y + 1.5, s - 3, s - 3);
            ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(x + (D.hz ? s * 0.78 : s * 0.5), y + (D.hz ? s * 0.5 : s * 0.78), s * 0.06, 0, TAU); ctx.fill();
          } else {
            const e = s * 0.14;
            ctx.fillStyle = '#4a3018';
            if (D.hz) { ctx.fillRect(x, y + s * 0.3, e, s * 0.4); ctx.fillRect(x + s - e, y + s * 0.3, e, s * 0.4); }
            else { ctx.fillRect(x + s * 0.3, y, s * 0.4, e); ctx.fillRect(x + s * 0.3, y + s - e, s * 0.4, e); }
            if (d.cd <= 0) { ctx.fillStyle = '#a8703c'; if (D.hz) ctx.fillRect(x + e * 0.2, y + s * 0.5, e * 0.8, s * 0.85); else ctx.fillRect(x + s * 0.5, y + e * 0.2, s * 0.85, e * 0.8); }
            else { ctx.strokeStyle = '#8a5a30'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(x + s * 0.2, y + s * 0.7); ctx.lineTo(x + s * 0.45, y + s * 0.55); ctx.moveTo(x + s * 0.6, y + s * 0.8); ctx.lineTo(x + s * 0.85, y + s * 0.6); ctx.stroke(); }
          }
        }
        if (d.lk > 0) { // folding barricade: striped bar + countdown
          ctx.fillStyle = '#1e1e1e'; ctx.fillRect(x + 1, y + s * 0.25, s - 2, s * 0.5);
          ctx.save(); ctx.beginPath(); ctx.rect(x + 1, y + s * 0.25, s - 2, s * 0.5); ctx.clip(); ctx.fillStyle = '#e8a030';
          for (let k = -2; k < 5; k++) { ctx.beginPath(); ctx.moveTo(x + k * s * 0.3, y + s * 0.75); ctx.lineTo(x + k * s * 0.3 + s * 0.15, y + s * 0.75); ctx.lineTo(x + k * s * 0.3 + s * 0.4, y + s * 0.25); ctx.lineTo(x + k * s * 0.3 + s * 0.25, y + s * 0.25); ctx.fill(); }
          ctx.restore(); hpBar(x, y, s, clamp(d.lk / BARI_T, 0, 1));
        }
        if (d.b > 0) drawPlanks(x, y, s, D.hz, d.b, now);
        if (d.b > 0 && d.b < BAR_HP - 1) hpBar(x, y, s, clamp(d.b / BAR_HP, 0, 1));
        else if (!d.b && d.s === 1 && d.hp < DOOR_HP - 1) hpBar(x, y, s, clamp(d.hp / DOOR_HP, 0, 1));
      });
    }
    function drawHeli(now) {
      const M = W.M, s = lay.ts, x = SX(M.hz.x), y = SY(M.hz.y);
      if (!W.heli || !heliOn(W)) return;
      const pr = 0.5 + 0.5 * Math.sin(now / 200);
      ctx.strokeStyle = 'rgba(227,174,69,' + (0.5 + pr * 0.4) + ')'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(x, y, HELI_R * s, 0, TAU); ctx.stroke();
      ctx.save(); ctx.translate(x + s * 0.2, y - s * 0.3);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(-s * 0.2, s * 0.6, s * 1, s * 0.3, 0, 0, TAU); ctx.fill();
      if (M.th === 6) { // rescue boat
        ctx.fillStyle = '#f2f2f2'; ctx.beginPath(); ctx.moveTo(-s * 0.9, -s * 0.3); ctx.lineTo(s * 0.7, -s * 0.3); ctx.lineTo(s * 1.0, 0); ctx.lineTo(s * 0.7, s * 0.3); ctx.lineTo(-s * 0.9, s * 0.3); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#ee6a55'; ctx.fillRect(-s * 0.9, -s * 0.08, s * 1.6, s * 0.16); ctx.fillStyle = '#bfe3ff'; ctx.fillRect(-s * 0.3, -s * 0.2, s * 0.4, s * 0.4);
      } else if (M.th === 5) { // rescue train headlight
        ctx.fillStyle = '#3a6aa0'; rr(ctx, -s * 0.5, -s * 1.2, s * 1.0, s * 1.6, s * 0.2); ctx.fill(); ctx.fillStyle = '#fff3b0'; ctx.beginPath(); ctx.arc(0, s * 0.25, s * 0.15, 0, TAU); ctx.fill();
      } else {
        ctx.fillStyle = '#e8eef4'; ctx.fillRect(s * 0.5, -s * 0.08, s * 1.0, s * 0.16);
        ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.ellipse(0, 0, s * 0.7, s * 0.45, 0, 0, TAU); ctx.fill();
        ctx.fillStyle = '#bfe3ff'; ctx.beginPath(); ctx.ellipse(-s * 0.32, -s * 0.06, s * 0.28, s * 0.22, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(40,40,50,.75)'; ctx.lineWidth = s * 0.08; const ra = now / 40;
        ctx.beginPath(); ctx.moveTo(Math.cos(ra) * s * 1.2, Math.sin(ra) * s * 0.4 - s * 0.1); ctx.lineTo(-Math.cos(ra) * s * 1.2, -Math.sin(ra) * s * 0.4 - s * 0.1); ctx.stroke();
      }
      ctx.restore();
    }
    function edgeArrow(tx, ty, col, label) {
      const x = SX(tx), y = SY(ty), m = 30;
      if (x > m && y > TOPH + m && x < lay.w - m && y < lay.h - m) return;
      const cx = lay.w / 2, cy = lay.ay, a = Math.atan2(y - cy, x - cx);
      const k = Math.min((lay.w / 2 - m) / Math.max(1e-3, Math.abs(Math.cos(a))), (Math.abs(Math.sin(a)) > 1e-3 ? (Math.sin(a) > 0 ? lay.h - m - cy : cy - TOPH - m) / Math.abs(Math.sin(a)) : 1e9));
      const ax = cx + Math.cos(a) * k, ay = cy + Math.sin(a) * k;
      ctx.save(); ctx.translate(ax, ay); ctx.rotate(a);
      ctx.fillStyle = col; ctx.strokeStyle = 'rgba(10,8,16,.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(14, 0); ctx.lineTo(-8, -10); ctx.lineTo(-4, 0); ctx.lineTo(-8, 10); ctx.closePath(); ctx.stroke(); ctx.fill();
      ctx.restore();
      if (label) { ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = col; ctx.fillText(label, ax - Math.cos(a) * 24, ay - Math.sin(a) * 18); }
    }
    function drawFog(p) {
      const w = lay.w, h = lay.h, dpr = cv.dpr || 1;
      if (!fogCv) { fogCv = document.createElement('canvas'); fogCtx = fogCv.getContext('2d'); }
      const fw = Math.max(1, Math.round(w * dpr / 2)), fh = Math.max(1, Math.round(h * dpr / 2));
      if (fogCv.width !== fw || fogCv.height !== fh) { fogCv.width = fw; fogCv.height = fh; }
      const g = fogCtx, k = fw / w;
      g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'source-over';
      g.clearRect(0, 0, fw, fh); g.fillStyle = 'rgba(6,5,14,.9)'; g.fillRect(0, 0, fw, fh);
      g.globalCompositeOperation = 'destination-out';
      const R = lightR(p) * lay.ts * k, x = SX(p.x) * k, y = SY(p.y) * k;
      const gr = g.createRadialGradient(x, y, R * 0.35, x, y, R);
      gr.addColorStop(0, 'rgba(0,0,0,1)'); gr.addColorStop(0.7, 'rgba(0,0,0,.85)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = gr; g.beginPath(); g.arc(x, y, R, 0, TAU); g.fill();
      if (heliOn(W)) { const hx = SX(W.M.hz.x) * k, hy = SY(W.M.hz.y) * k, hr = HELI_R * 1.6 * lay.ts * k; const g2 = g.createRadialGradient(hx, hy, 0, hx, hy, hr); g2.addColorStop(0, 'rgba(0,0,0,.8)'); g2.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = g2; g.beginPath(); g.arc(hx, hy, hr, 0, TAU); g.fill(); }
      g.globalCompositeOperation = 'source-over';
      ctx.drawImage(fogCv, 0, 0, w, h);
    }
    function drawHud(now) {
      const w = lay.w, m = myP();
      ctx.fillStyle = 'rgba(16,12,24,.86)'; ctx.fillRect(0, 0, w, TOPH);
      ctx.fillStyle = 'rgba(227,174,69,.35)'; ctx.fillRect(0, TOPH - 1, w, 1);
      const left = Math.max(0, START_T + W.len - W.t), pre = W.t < START_T && st.ph === 'play';
      const tt = pre ? W.len : Math.ceil(left), mm = Math.floor(tt / 60), ss = tt % 60;
      ctx.textBaseline = 'middle';
      ctx.font = '700 22px ' + MONO; ctx.textAlign = 'left';
      const hot = !pre && left < 10 && st.ph === 'play';
      ctx.fillStyle = hot ? (Math.floor(now / 300) % 2 ? '#ee6a55' : '#ffd0c8') : '#f2e9d8';
      ctx.fillText(mm + ':' + String(ss).padStart(2, '0'), 12, TOPH / 2);
      const nS = W.pl.filter((p) => !p.z).length, nZ = W.pl.length - nS;
      const cx = w / 2 + 4;
      ctx.font = '700 16px ' + FONT; ctx.textAlign = 'right'; ctx.fillStyle = '#f6d7b0';
      ctx.beginPath(); ctx.arc(cx - 46, TOPH / 2, 7, 0, TAU); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.fillText(String(nS), cx - 14, TOPH / 2);
      ctx.fillStyle = ZSKIN; ctx.beginPath(); ctx.arc(cx + 6, TOPH / 2, 7, 0, TAU); ctx.fill();
      ctx.textAlign = 'left'; ctx.fillStyle = '#cfeebe'; ctx.fillText(String(nZ), cx + 18, TOPH / 2);
      ctx.font = '600 13px ' + FONT; ctx.textAlign = 'right'; ctx.fillStyle = '#ab9fb8';
      ctx.fillText(st.rd + '/' + st.rounds + '판', w - 10, TOPH / 2 - 8);
      ctx.font = '600 11px ' + FONT; ctx.fillText(W.M.nm, w - 10, TOPH / 2 + 9);
      if (m && st.ph === 'play') {
        let txt, bg, fg = '#f2e9d8';
        if (m.esc) { txt = '탈출 성공 — 구경 중'; bg = 'rgba(227,174,69,.9)'; fg = '#2a1d05'; }
        else if (m.alpha) { txt = '알파 좀비 · 빠르고 돌진이 잦아요'; bg = 'rgba(79,138,60,.92)'; fg = '#10200a'; }
        else if (m.z) { txt = (ZT[m.zt] ? ZT[m.zt].nm + ' · ' + ZT[m.zt].sk2 : '좀비'); bg = ZSK2[m.zt] || 'rgba(79,138,60,.9)'; }
        else if (m.up) { txt = '지붕 위 · ' + Math.max(0, Math.ceil(ROOF_T - m.rt)) + '초 남음'; bg = m.rt > ROOF_T - 4 ? 'rgba(238,106,85,.92)' : 'rgba(79,122,168,.92)'; }
        else if (hidden(m)) { txt = '숨는 중 · 움직이면 들켜요'; bg = 'rgba(58,110,58,.92)'; }
        else if (m.jb === 2 && m.ju && m.sh) { txt = '💊 물렸어요 · ' + Math.max(0, Math.ceil(m.sp)) + '초 뒤 감염 — 구조로 탈출하면 살아요'; bg = 'rgba(160,60,90,.92)'; }
        else if (m.rv > 0) { txt = '📻 무전 · 좀비 위치가 보여요'; bg = 'rgba(40,110,140,.92)'; }
        else { const J = JB[m.jb]; txt = (J ? J.ic + ' ' + J.nm + ' · ' : '생존자 · ') + '판자 ' + m.pk + '개'; bg = 'rgba(46,38,64,.9)'; }
        ctx.font = '700 13px ' + FONT; const tw = Math.min(w - 20, ctx.measureText(txt).width + 22);
        ctx.fillStyle = bg; rr(ctx, w / 2 - tw / 2, TOPH + 6, tw, 24, 12); ctx.fill();
        ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.fillText(txt, w / 2, TOPH + 18, w - 30);
      }
    }
    function drawStick() {
      if (!stick || !lay || lay.sp) return;
      ctx.fillStyle = 'rgba(242,233,216,.1)'; ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(stick.bx, stick.by, STICK_R, 0, TAU); ctx.fill(); ctx.stroke();
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), k = d > STICK_R ? STICK_R / d : 1;
      ctx.fillStyle = 'rgba(242,233,216,.5)'; ctx.beginPath(); ctx.arc(stick.bx + dx * k, stick.by + dy * k, Math.round(22 * KC()), 0, TAU); ctx.fill();
    }
    function drawBanner(now) {
      const cx = lay.w / 2;
      if (st.ph === 'play' && W.t < START_T) {
        const n = Math.ceil(START_T - W.t), m = myP(), fr = (START_T - W.t) % 1;
        const alpha = name(W.al), by0 = jobEl && jobEl.style.display !== 'none' ? Math.max(lay.h * 0.3, TOPH + 196) : lay.h * 0.3;
        ctx.fillStyle = 'rgba(10,8,16,.6)'; ctx.fillRect(0, by0, lay.w, 130);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.save(); ctx.translate(cx, by0 + 34); const sc = 1 + fr * 0.35; ctx.scale(sc, sc);
        ctx.font = '40px ' + DISP; ctx.fillStyle = '#f2e9d8'; ctx.fillText(String(n), 0, 0); ctx.restore();
        ctx.font = '700 16px ' + FONT; ctx.fillStyle = m && m.alpha ? ZSKIN : '#e3ae45';
        ctx.fillText(m && m.alpha ? '내가 알파 좀비! 곧 출발해요' : m ? '알파 좀비는 ' + alpha + ' — 어서 흩어져요!' : '알파 좀비: ' + alpha, cx, by0 + 76, lay.w - 20);
        ctx.font = '600 13px ' + FONT; ctx.fillStyle = '#ab9fb8';
        ctx.fillText(m && m.alpha ? '잡힌 사람은 여러 종류의 좀비가 돼요' : W.len + '초 동안 한 명이라도 살아남으면 생존자 승리', cx, by0 + 104, lay.w - 20);
        return;
      }
      if (banner) {
        const life = banner.long ? 3.4 : 2.6, a = Math.min(1, Math.max(0, banner.t) * 4, (life - banner.t) * 3);
        ctx.globalAlpha = clamp(a, 0, 1);
        const bw = Math.min(lay.w - 16, 340);
        ctx.fillStyle = 'rgba(10,8,16,.8)'; rr(ctx, cx - bw / 2, TOPH + 36, bw, 60, 14); ctx.fill();
        ctx.strokeStyle = banner.c; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = '21px ' + DISP; ctx.fillStyle = banner.c; ctx.fillText(banner.s, cx, TOPH + 57, bw - 16);
        ctx.font = '600 12px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText(banner.s2, cx, TOPH + 81, bw - 16);
        ctx.globalAlpha = 1;
      } else if (tipT > 0 && W.t < tipT && W.t >= START_T && myP()) {
        const m = myP();
        const t = m.z ? '끌어서 이동 · 큰 버튼 돌진·부수기 · 작은 버튼 특기' : '끌어서 이동 · 큰 버튼 문·사다리 · 판자 · 아이템';
        ctx.font = '600 12px ' + FONT; const tw = Math.min(lay.w - 20, ctx.measureText(t).width + 20);
        ctx.fillStyle = 'rgba(10,8,16,.78)'; rr(ctx, cx - tw / 2, lay.h - 236, tw, 28, 10); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, cx, lay.h - 222, lay.w - 30);
      }
    }
    function drawSmoke(S, now) {
      const s = lay.ts, x = SX(S.x), y = SY(S.y), a = clamp(Math.min(S.t, SMOKE_T - S.t + 0.3) / 0.8, 0, 1);
      for (let k = 0; k < 7; k++) {
        const an = k * 0.9 + now / 2400 * (k & 1 ? 1 : -1), rr0 = SMOKE_R * s * (k ? 0.55 : 0), px = x + Math.cos(an) * rr0, py = y + Math.sin(an) * rr0 * 0.8;
        ctx.fillStyle = 'rgba(190,196,190,' + (0.42 * a).toFixed(3) + ')'; ctx.beginPath(); ctx.arc(px, py, s * (k ? 0.95 : 1.3), 0, TAU); ctx.fill();
      }
    }
    function drawLure(Lr, now) {
      const s = lay.ts, x = SX(Lr.x), y = SY(Lr.y), sh = Math.sin(now / 30) * s * 0.04;
      for (let k = 0; k < 3; k++) { const t = ((now / 700) + k / 3) % 1; ctx.strokeStyle = 'rgba(255,176,80,' + (0.6 * (1 - t)) + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, s * (0.3 + t * 1.6), 0, TAU); ctx.stroke(); }
      drawItem(ctx, 4, x + sh, y, s, 0);
    }
    function draw(now) {
      if (!st || !W || !lay) return;
      const w = lay.w, h = lay.h, s = lay.ts, M = W.M;
      ctx.save();
      ctx.fillStyle = THEMES[M.th].bg; ctx.fillRect(0, 0, w, h);
      if (shake > 0) { const fxk = L.fx ? L.fx() : 1; ctx.translate((Math.random() - 0.5) * shake * 14 * fxk, (Math.random() - 0.5) * shake * 14 * fxk); }
      const ox = SX(0), oy = SY(0), dpr = bgCv.width / (M.W * s);
      const sx0 = Math.max(0, -ox), sy0 = Math.max(0, -oy), sw = Math.min(M.W * s - sx0, w - Math.max(0, ox)), sh = Math.min(M.H * s - sy0, h - Math.max(0, oy));
      if (sw > 0 && sh > 0) ctx.drawImage(bgCv, sx0 * dpr, sy0 * dpr, sw * dpr, sh * dpr, Math.max(0, ox), Math.max(0, oy), sw, sh);
      for (const d of decals) { if (!seen(d.x, d.y)) continue; ctx.fillStyle = d.c; ctx.globalAlpha = 0.45; for (let k = 0; k < 5; k++) { const a = d.r + k * 1.3; ctx.beginPath(); ctx.arc(SX(d.x + Math.cos(a) * 0.25 * (k % 3)), SY(d.y + Math.sin(a) * 0.2 * (k % 3)), s * (0.18 - k * 0.025), 0, TAU); ctx.fill(); } ctx.globalAlpha = 1; }
      drawGates(now);
      for (const g of W.gi) { const S = M.items[g.s]; if (seen(S.x, S.y)) drawItem(ctx, g.k, SX(S.x), SY(S.y), s, now); }
      const m = myP();
      for (const T of W.traps) if (!m || !m.z || hyp(T.x - m.x, T.y - m.y) < 2.2) { ctx.globalAlpha = 0.85; drawItem(ctx, 1, SX(T.x), SY(T.y), s * 0.9, 0); ctx.globalAlpha = 1; }
      for (const Lr of W.lu) if (seen(Lr.x, Lr.y) || (m && m.z && hyp(Lr.x - m.x, Lr.y - m.y) < LURE_R)) drawLure(Lr, now);
      const order = W.pl.map((p, i) => i).filter((i) => !W.pl[i].esc).sort((a, b) => (W.pl[a].up - W.pl[b].up) || (W.pl[a].y - W.pl[b].y));
      for (const i of order) { const p = W.pl[i]; if (visible(p)) drawChar(p, i, now); }
      for (const S of W.sm) if (seen(S.x, S.y) || W.dark === 0) drawSmoke(S, now);
      drawHeli(now);
      for (const r of rings) { if (r.t < 0 || !seen(r.x, r.y)) continue; const k = r.t / 0.7; ctx.strokeStyle = r.c; ctx.globalAlpha = 1 - k; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(SX(r.x), SY(r.y), r.r * s * (0.3 + k * 0.7), 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; }
      for (const q of parts) { if (!seen(q.x, q.y)) continue; ctx.globalAlpha = clamp(1 - q.t / q.l, 0, 1); ctx.fillStyle = q.c; ctx.save(); ctx.translate(SX(q.x), SY(q.y)); ctx.rotate(q.r); ctx.fillRect(-q.s * s, -q.s * s * 0.4, q.s * s * 2, q.s * s * 0.8); ctx.restore(); }
      ctx.globalAlpha = 1;
      if (W.dark && m && !lay.sp) drawFog(m);
      for (const f of floats) { if (!seen(f.x, f.y)) continue; ctx.globalAlpha = clamp(1.3 - f.t, 0, 1); ctx.font = '800 15px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(10,8,16,.85)'; const y = SY(f.y) - s * 0.7 - f.t * 26; ctx.strokeText(f.s, SX(f.x), y); ctx.fillStyle = f.c; ctx.fillText(f.s, SX(f.x), y); ctx.globalAlpha = 1; }
      if (flashA > 0) { ctx.fillStyle = 'rgba(255,250,215,' + (flashA * (L.fx ? Math.max(0.35, L.fx()) : 1)).toFixed(3) + ')'; ctx.fillRect(0, 0, w, h); }
      ctx.restore();
      // mood + tension: dark vignette, red heartbeat pulse for survivors, green haze for zombies
      if (!lay.sp && m && st.ph === 'play') {
        const vg = vignette(w, h);
        ctx.globalAlpha = clamp((m.z ? 0.35 : 0.3) + hbK * 0.45 * (0.7 + 0.3 * hbPulse), 0, 0.95); ctx.drawImage(vg, 0, 0, w, h);
        if (hbK > 0.05 && !m.z) { ctx.globalAlpha = hbK * (0.18 + 0.32 * hbPulse); const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.72); g.addColorStop(0, 'rgba(150,0,20,0)'); g.addColorStop(1, 'rgba(170,0,25,1)'); ctx.fillStyle = g; ctx.fillRect(0, TOPH, w, h - TOPH); }
        if (m.z) { ctx.globalAlpha = 0.22; const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75); g.addColorStop(0, 'rgba(90,180,60,0)'); g.addColorStop(1, 'rgba(90,180,60,1)'); ctx.fillStyle = g; ctx.fillRect(0, TOPH, w, h - TOPH); }
        ctx.globalAlpha = 1;
      }
      if (infA > 0) { // just got infected: green splash with drips
        ctx.globalAlpha = clamp(infA, 0, 1) * 0.6; ctx.fillStyle = '#4f8a3c'; ctx.fillRect(0, 0, w, h);
        ctx.globalAlpha = clamp(infA, 0, 1); ctx.fillStyle = '#2f5a22';
        for (let k = 0; k < 9; k++) { const dx = (k + 0.5) / 9 * w, dl = (1 - infA) * h * (0.3 + hash2(k, 7) * 0.5); ctx.fillRect(dx - 5, 0, 10, dl); ctx.beginPath(); ctx.arc(dx, dl, 7, 0, TAU); ctx.fill(); }
        ctx.globalAlpha = 1;
      }
      // edge arrows
      if (m && !lay.sp && st.ph === 'play' && W.t >= START_T) {
        if (heliOn(W) && !m.z) edgeArrow(M.hz.x, M.hz.y, '#e3ae45', 'H');
        if (!m.z && m.rv > 0) for (const q of W.pl) if (q.z && !q.esc && !(SX(q.x) > 30 && SX(q.x) < w - 30 && SY(q.y) > TOPH + 30 && SY(q.y) < h - 30)) edgeArrow(q.x, q.y, '#9be3ff', '');
        if (m.z) {
          for (const q of W.pl) if (alive(q) && q.rev > 0) edgeArrow(q.x, q.y, '#ee6a55', '');
          if (W.nz >= SMELL_N || m.zt === 2) {
            let best = null, bd = 1e9; for (const q of W.pl) if (alive(q) && (!hidden(q) || q.rev > 0)) { const d = hyp(q.x - m.x, q.y - m.y); if (d < bd) { bd = d; best = q; } }
            if (best && !(visible(best) && SX(best.x) > 30 && SX(best.x) < w - 30 && SY(best.y) > TOPH + 30 && SY(best.y) < h - 30)) edgeArrow(best.x, best.y, ZSKIN, '');
          }
          for (const Lr of W.lu) if (hyp(Lr.x - m.x, Lr.y - m.y) < LURE_R) edgeArrow(Lr.x, Lr.y, '#ffb050', '♪');
        }
      }
      drawHud(now);
      drawStick();
      drawBanner(now);
    }

    /* ----- buttons & end panel ----- */
    function setBtn(B, show, lab, sub, cls, cdv, pr) {
      B.b.style.display = show ? 'flex' : 'none';
      if (!show) return;
      if (pr > 0) cls += ' press';
      const sig = lab + '|' + sub + '|' + cls + '|' + Math.round(cdv * 40);
      if (sig === B.sig) return;
      B.sig = sig; B.lab.textContent = lab; B.sub.textContent = sub; B.b.className = cls; B.cd.style.setProperty('--c', String(cdv));
    }
    function syncBtn() {
      syncJob();
      const m = myP(), show = !!m && !m.esc && st && st.ph === 'play' && !auto();
      if (!show) { setBtn(bM, false); setBtn(bP, false); setBtn(bS, false); return; }
      // big button
      const c = mainCtx(W, m);
      let lab = '…', sub = '', cls = 'zb-btn', cdv = 0;
      if (m.tf) { lab = '변신 중'; cls += ' dim zb'; }
      else if (m.cl) { lab = m.cdir > 0 ? '오르는 중' : '내려가는 중'; cls += ' dim lad'; }
      else if (c) {
        lab = CTX_NM[c.k] || '';
        if (c.k === 'lunge') { sub = m.alpha ? '알파 · 빠른 재사용' : '가까울 때 휙!'; cls += ' zb'; const T = lungeCd(W, m); cdv = m.lcd > 0 ? clamp(m.lcd / T, 0, 1) : 0; }
        else if (c.k === 'bash') { sub = m.zt === 1 ? '탱커 · 2배 세게' : '문·판자 부수기'; cls += ' zb'; }
        else if (c.k === 'up') { sub = m.z ? '사다리 타기' : c.ok ? '지붕으로' : '지붕 시간 끝'; cls += ' lad'; }
        else if (c.k === 'down') { sub = '사다리로'; cls += ' lad'; }
        else if (c.k === 'jump') { sub = '잠깐 휘청'; cls += ' lad'; }
        else { sub = c.k === 'close' ? (c.ok ? '좀비를 막아요' : '문간이 막혔어요') : '지나가기'; cls += ' dr'; }
        if (!c.ok) cls += ' dim';
      } else { lab = m.z ? '돌진' : m.up ? '지붕 위' : '문·사다리'; sub = m.z ? '' : m.up ? '사다리 쪽으로 가요' : '가까이 가면 켜져요'; cls += ' dim'; }
      setBtn(bM, true, lab, sub, cls, cdv, press.m);
      // plank button (survivors)
      if (m.z) setBtn(bP, false);
      else {
        const pc = plankCtx(W, m);
        const ok = pc && pc.ok, rein = pc && pc.k === 'rein';
        setBtn(bP, true, rein ? '보강' : '판자', '남은 ' + m.pk + '개', 'zb-btn s2 pl wd' + (ok ? '' : ' dim'), 0, press.p);
      }
      // item / special
      const k = skillCtx(W, m);
      if (m.z) {
        if (m.alpha || m.zt < 0) setBtn(bS, false);
        else { const T = ZT[m.zt]; setBtn(bS, true, T.sk, m.sp > 0 ? Math.ceil(m.sp) + '초' : '특기', 'zb-btn s2 sk' + (k && k.ok ? '' : ' dim'), m.sp > 0 ? clamp(m.sp / T.cd, 0, 1) : 0, press.s); }
      } else {
        const J = JB[m.jb];
        if (m.it < 0 && J && J.act) setBtn(bS, true, J.ic + ' ' + J.sk, m.sp > 0 ? Math.ceil(m.sp) + '초' : '직업 특기', 'zb-btn s2 sk' + (k && k.ok ? '' : ' dim'), m.sp > 0 ? clamp(m.sp / J.act, 0, 1) : 0, press.s);
        else if (m.it < 0) setBtn(bS, true, '빈손', J ? J.ic + ' ' + J.nm : '아이템', 'zb-btn s2 dim', 0, 0);
        else setBtn(bS, true, k ? SK_NM[k.k] : IT_NM[m.it], m.it === 3 ? '자동 방어' : m.it === 4 ? '보는 쪽 던짐' : m.it === 6 ? '문·창문 앞' : m.it === 7 ? '발밑에' : '아이템', 'zb-btn s2 sv' + (k && k.ok ? '' : ' dim'), 0, press.s);
      }
    }
    function showEnd() {
      if (endEl) { endEl.remove(); endEl = null; }
      if (!st || st.ph !== 'end' || !Array.isArray(st.rs)) return;
      const m = me();
      const rows = st.rs.slice().sort((a, b) => b[1] - a[1]);
      endEl = L.h('div', { class: 'zb-end' },
        L.h('h3', { text: st.win ? '좀비 승리!' : '생존자 승리!', style: { color: st.win ? ZSKIN : '#e3ae45' } }),
        L.h('div', { class: 'sub', text: st.rd + '/' + st.rounds + '판 · ' + (st.win ? '모두 감염됐어요' : '끝까지 버틴 사람이 있어요') }),
        ...rows.map((r) => L.h('div', { class: 'row' + (r[0] === m ? ' me' : '') },
          L.h('i', { class: 'dot', style: { '--c': COL(r[0]) } }),
          L.h('span', { class: 'nm', text: name(r[0]) }),
          L.h('span', { class: 'oc', text: OC_NM[r[2]] + (r[3] ? ' · 감염 ' + r[3] : '') }),
          L.h('b', { text: '+' + r[1] }),
          L.h('span', { class: 'tot', text: String(st.sc[r[0]]) }))));
      root.appendChild(endEl);
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n); syncBtn(); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (curKey() !== key) { startRound(); return; }
        if (prev && prev.ph !== next.ph && next.ph === 'end') {
          endT = END_T; stick = null;
          if (W && !W.res) W.res = { t: W.t, sent: 1 };
          const m = me(), r = (next.rs || []).find((q) => q[0] === m);
          if (r && !auto()) { const good = r[2] === 0 || r[2] === 1 ? !next.win : !!next.win; api.sfx(good ? 'win' : 'lose'); } else api.sfx('chip');
          hbK = 0; lay = null; layout(); showEnd();
        }
        if (next.ph === 'done' && endEl) { endEl.remove(); endEl = null; }
      },
      destroy() {
        if (pbar) pbar.destroy();
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll); window.removeEventListener('lounge-ctl', onCtl);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        bM.b.removeEventListener('pointerdown', onBM); bP.b.removeEventListener('pointerdown', onBP); bS.b.removeEventListener('pointerdown', onBS);
        bM.b.remove(); bP.b.remove(); bS.b.remove(); jobEl.remove(); if (endEl) endEl.remove();
        styleEl.remove();
        Snd.close(); window.removeEventListener('lounge-volume', onVol);
        cv.destroy();
      },
      _dbg: () => ({ W, st, lay, locIn, remIn, cam, aiMem }),
    };
  }

  L.register({
    id: 'zombie', name: '좀비 감염', tag: '실시간 감염 술래', cat: '파티',
    blurb: '처음엔 좀비 1명! 잡힌 사람은 여러 종류의 좀비가 되어 같이 쫓아요. 문·판자로 막고, 지붕에 오르고, 숨고, 미끼로 속이며 끝까지 버티면 생존자 승리, 모두 감염되면 좀비 승리.',
    tint: '#2f5a2a',
    icon: '<circle cx="28" cy="24" r="13" fill="currentColor"/><rect x="11" y="34" width="13" height="5" rx="2.5" fill="currentColor"/><rect x="32" y="34" width="13" height="5" rx="2.5" fill="currentColor"/><path d="M18 44h20v6H18z" fill="currentColor" opacity=".55"/><circle cx="23" cy="22" r="3.4" fill="#000" opacity=".55"/><circle cx="33.5" cy="23" r="2.4" fill="#000" opacity=".55"/><path d="M22 30l3-2 3 2 3-2 3 2" stroke="#000" stroke-opacity=".5" stroke-width="1.6" fill="none"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 8, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'map', label: '맵', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'rounds', label: '판 수', choices: [{ v: 3, label: '3판' }, { v: 5, label: '5판' }], def: 3 },
      { id: 'len', label: '한 판 시간', choices: [{ v: 60, label: '60초' }, { v: 90, label: '90초' }, { v: 120, label: '120초' }], def: 90 },
      { id: 'heli', label: '구조(마지막 30초)', tip: '마지막 30초에 구조 헬기가 와요.', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
      { id: 'fog', label: '어둠(내 주변만 보임)', tip: '어두우면 내 주변만 보여요.', choices: [{ v: -1, label: '맵대로' }, { v: 1, label: '항상 어둡게' }, { v: 0, label: '항상 밝게' }], def: -1 },
    ],
    controls: [
      { id: 'up', label: '위로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'act', label: '큰 버튼 (문·사다리·돌진·부수기)', keys: ['Space', 'KeyJ', 'Enter'], pad: ['a', 'rt'] },
      { id: 'plank', label: '판자 막기', keys: ['KeyK'], pad: ['x', 'lt'] },
      { id: 'skill', label: '아이템 쓰기 · 좀비 특기', keys: ['KeyL', 'KeyE'], pad: ['b', 'rb'] },
    ],
    quick: [
      '처음엔 알파 좀비 1명! 잡히면 나도 무작위 종류의 좀비가 되어 같이 쫓아요.',
      '생존자는 직업(8종)을 골라 문 닫기·판자 막기·지붕 오르기·숨기·아이템으로 버텨요. 좀비는 돌진하고 종류마다 다른 특기를 써요.',
      '시간이 끝날 때 한 명이라도 남으면 생존자 승리, 모두 감염되면 좀비 승리. 여러 판 점수 합계로 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '판마다 한 명이 「알파 좀비」로 시작하고, 나머지는 모두 생존자예요(빈자리는 AI가 채워요, 최대 8명).',
        '좀비에게 닿으면 감염! 잠깐 변신한 뒤 다섯 종류 중 하나의 좀비가 되어(무작위) 남은 사람을 쫓아요.',
        '시간(기본 90초)이 끝날 때 한 명이라도 남아 있으면 생존자 승리, 모두 감염되면 그 순간 좀비 승리예요.',
      ] },
      { h: '생존자 — 버튼 3개', p: [
        '큰 버튼: 문 앞에서 「문 닫기/열기」, 사다리 앞에서 「오르기/내려가기」, 지붕 가장자리에서 「뛰어내리기」.',
        '「판자」 버튼: 문이나 창문 앞에서 누르면 판자로 막아요(판마다 2개로 시작). 이미 막힌 곳에 또 누르면 「보강」(더 튼튼해져요).',
        '막은 판자는 모두 못 지나가요. 내가 나가려면 판자 쪽으로 1초쯤 밀면 뜯어지고 판자 1개를 돌려받아요.',
        '작은 버튼: 들고 있는 아이템 쓰기(한 번에 1개, 걸어가면 주워요). 빈손이면 직업 특기.',
        '· 속도 음료: 4초 동안 아주 빨라져요.  · 덫: 발밑에 놓아요. 밟은 좀비는 2.4초 꼼짝 못 해요.',
        '· 손전등: 「번쩍!」 주변 3.5칸 좀비가 2초 눈부셔 멈춰요.  · 백신: 들고만 있으면 한 번 잡혀도 막아 줘요.',
        '· 소리 미끼: 바라보는 쪽으로 멀리 던져요. 6초 동안 울려서 근처 좀비가 그쪽으로 몰려가요(똑똑한 좀비는 잘 안 속아요).',
        '· 바리케이드: 문·창문 앞에서 쓰면 8초 동안 그 길이 완전히 막혀요(어떤 좀비도 못 부숴요). 8초 뒤 저절로 치워져요.',
        '· 연막탄: 발밑에 터뜨리면 6초 동안 연기가 퍼져요. 연기 안에선 움직여도 좀비 눈에 잘 안 보이고, 좀비는 느려져요.',
      ] },
      { h: '생존자 직업', p: [
        '판 시작 카운트다운 동안 화면 위에서 직업을 골라요. 기본은 「무작위」, 고른 직업은 이 기기에 기억돼요 첫 판은 모두 직업을 누를(준비) 때까지 기다리고, 방장은 「지금 시작」으로 바로 출발할 수 있어요. 알파 좀비는 직업이 없어요.',
        '감염되면 직업 능력은 사라지고 좀비 종류 특기를 써요. 이름 앞 그림이 직업이에요.',
        '· 🔨 수리공: 판자 3개로 시작, 막은 판자가 1.5배 튼튼, 판자를 빨리 뜯어요.  · 👟 척후: 조금 빠르고 좀비가 늦게 알아채요.',
        '· 💊 의무병: 판마다 한 번, 잡혀도 6초 버텨요(그 안에 구조로 탈출하면 살아요).  · 🔒 경비원: 내가 닫은 문은 2배 튼튼.',
        '· 🏃 달리기 선수: 「질주」 1.6초 아주 빠르게(14초마다).  · 📻 무전병: 「무전」 3초 동안 좀비 위치 보기(20초마다), 살아 있으면 구조가 6초 일찍.',
        '· 🕸 덫잡이: 「덫」 발밑에 덫(16초마다).  · 🌿 은신가: 0.25초 만에 숨고, 숨으면 더 가까이 와야 보여요.',
        '특기 있는 직업(질주·무전·덫)은 아이템이 없을 때 작은 버튼으로 써요. 아이템을 들고 있으면 아이템이 먼저예요.',
      ] },
      { h: '창문 · 지붕 · 숨는 곳', p: [
        '창문: 생존자는 천천히 넘어갈 수 있지만 좀비는 못 넘어요(도약 좀비만 넘어요).',
        '지붕: 사다리로 올라가면 좀비가 못 따라와요(도약 좀비만 사다리를 타고 올라와요!). 내려올 땐 사다리로, 또는 지붕 가장자리에서 큰 버튼 「뛰어내리기」(잠깐 휘청).',
        '지붕은 한 판에 모두 합쳐 12초까지만 버틸 수 있어요. 시간이 끝나면 가까운 가장자리로 미끄러져 떨어져요(0.6초 휘청).',
        '환풍구(지하철역·학교 건물): 사람만 기어서 지나가는 좁은 통로예요(조금 느려요). 좀비는 못 들어와요.',
        '숨는 곳(덤불·사물함·옥수수밭 등): 그 위에서 가만히 있으면 0.6초 뒤 숨어요. 좀비 화면에선 아주 가까이 오기 전엔 안 보여요. 움직이거나 버튼을 쓰면 다시 보여요.',
      ] },
      { h: '좀비 종류', p: [
        '모든 좀비: 사람에게 닿으면 감염. 큰 버튼 「돌진」(가까울 때 휙!), 닫힌 문·판자 앞에선 「부수기」(밀고만 있어도 조금씩 부서져요).',
        '알파 좀비(왕관): 처음부터 생존자보다 빠르고 돌진을 자주 써요.',
        '· 질주 좀비: 「질주」 2.5초 동안 아주 빨라져요.',
        '· 탱커 좀비: 느리지만 문·판자를 2배 세게 부수고, 「박살」로 앞의 문·판자를 한 번에 부숴요. 덫·손전등이 반만 통해요.',
        '· 냄새 좀비: 숨은 사람을 3칸 안에서 찾아내고, 「킁킁」으로 근처 사람 위치를 3.5초 동안 모든 좀비에게 보여 줘요.',
        '· 도약 좀비: 「도약」으로 장애물·판자를 뛰어넘고, 창문을 넘고, 사다리로 지붕에도 올라가요.',
        '· 비명 좀비: 「비명」으로 근처 좀비를 3초 빠르게 하고, 가까운 사람은 움찔(느려짐)하며 위치가 들켜요.',
        '좀비가 많아질수록 강해져요: 3명부터 가장 가까운 사람 쪽 화살표, 5명부터 문·판자를 2배 빨리 부숴요.',
      ] },
      { h: '구조 · 어둠', p: [
        '「구조」가 켜져 있으면 마지막 30초에 H 표시에 헬기(항구는 보트, 지하철역은 열차)가 와요. H 동그라미 안에 0.8초 서 있으면 탈출! 탈출하면 남은 시간도 점수로 쳐요.',
        '어두운 맵(학교·병원·캠핑장·산장·아파트·심야 지하철역·학교 건물)은 내 주변만 보여요. 지붕 위에선 조금 더 멀리 보여요.',
        '좀비가 가까우면 심장 소리가 빨라지고 화면 가장자리가 붉어져요.',
      ] },
      { h: '점수·우승', p: [
        '생존자: 살아 있는 3초마다 +1점, 끝까지 살아남으면 +10점, 혼자 남은 「최후의 생존자」는 +10점 더.',
        '좀비: 사람 한 명 감염시킬 때마다 +8점(알파든 감염된 좀비든 같아요).',
        '예시) 45초 버티다 잡히고, 좀비가 되어 2명을 잡으면 15 + 16 = 31점. 90초를 끝까지 버티면 30 + 10 = 40점.',
        '판 수(3판/5판)가 끝나면 합계가 가장 높은 사람이 우승! 알파 좀비는 판마다 아직 안 해 본 사람 중에서 무작위로 정해요.',
      ] },
      { h: '조작', p: [
        '화면 아무 데나 누르고 끌면 그쪽으로 움직여요(떠 있는 조이스틱).',
        '오른쪽 아래 버튼: 큰 버튼(문·사다리·돌진), 「판자」(생존자), 작은 버튼(아이템 / 좀비 특기).',
        'PC: WASD·방향키 이동, 스페이스(J) 큰 버튼, K 판자, L(E) 아이템·특기. 패드: 왼스틱, A·X·B. 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '맵', p: [
        MAPS.map((m) => m.nm + (m.dark ? '(어둠)' : '') + (m.zv < 1 ? '(좀비 느림)' : m.zv > 1 ? '(좀비 빠름)' : '')).join(' · ') + ' — 기본값은 무작위(판마다 바뀌어요).',
        '도망칠 길이 좁은 실내 맵은 좀비가 조금 느리고, 탁 트인 맵은 조금 빨라요(양쪽 승률이 비슷하도록 맞춘 값).',
        '맵마다 문 달린 방, 창문, 사다리 달린 지붕, 숨는 곳이 있어요. 문 하나뿐인 방은 숨기 좋지만 문이 부서지면 갇혀요!',
      ] },
      { h: '함께 하기 · AI', p: [
        '실시간 게임이라 한 폰에 한 명이에요. 혼자 하면 나머지는 AI, 친구와는 온라인·LAN 방에서 각자 폰으로(빈자리는 AI).',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬운 AI는 도구를 잘 못 쓰고 미끼에 잘 속아요. 어려운 AI는 판자·지붕·숨기를 잘 쓰고, 어려운 좀비는 특기를 제때 쓰며 서로 다른 사람을 나눠 쫓아요.',
      ] },
      { h: '팁', p: [
        '좀비가 쫓아오면 문을 지나간 뒤 바로 「판자」 — 탱커·도약 좀비가 아니면 한참 벌 수 있어요.',
        '지붕은 잠깐 숨 돌리는 곳이에요. 좀비가 사다리 아래에 모이기 전에 내려와요. 지붕에서 미끼를 던져 좀비를 떼어 내면 좋아요.',
        '좀비라면 친구 좀비와 양쪽에서 몰아요. 비명 좀비는 무리 한가운데서, 냄새 좀비는 사람이 안 보일 때 특기를!',
      ] },
    ],
    codex: zbCodex(),
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newWorld, tickWorld, stepWorld, aiThink, roundRows, roundOver, nextRound, result, snapshot, applySnap, MAPS, PM, mainCtx, plankCtx, skillCtx, ZT },
  });
})();
