/* 수집 카드 대전 (cardduel) — 1:1 수집형 카드 배틀. 이름·그림·문구는 모두 독자 설계. */
(function(){
  const L = window.Lounge, U = L.util;
  const GID = 'cardduel';

  /* ───────── 직업 ───────── */
  const CLS = {
    b: { n: '칼날 기사단', s: '기사단', col: '#c0453a', hi: '#ff9a7a', em: 'sword', d: '방패병을 줄 세우고 함께 강해지는 정면 승부. 돌격으로 마무리해요.', arch: '전열 강화 · 돌격 마무리' },
    w: { n: '숲의 사수', s: '숲', col: '#3f9a52', hi: '#9fe39a', em: 'leaf', d: '싼 카드를 한 턴에 여러 장 내면 터지는 「연계」. 잎새 정령으로 수를 채워요.', arch: '연계 · 잎새 정령' },
    a: { n: '별빛 학파', s: '학파', col: '#4a6fd0', hi: '#9fc0ff', em: 'star', d: '주문을 쓸수록 커지는 「공명」, 쓴 주문 수로 터지는 큰 마법.', arch: '주문 · 공명 · 화력' },
    d: { n: '용의 혈족', s: '혈족', col: '#d4862a', hi: '#ffd08a', em: 'wing', d: '최대 PP를 늘려 남보다 먼저 거대한 용을 꺼내요. PP 7부터 「각성」.', arch: 'PP 가속 · 각성 · 거대 용' },
    n: { n: '망령술사', s: '망령', col: '#7a4ab0', hi: '#cfa6ff', em: 'skull', d: '내 추종자가 쓰러질 때마다 「넋」이 쌓이고, 넋을 써서 큰 효과를 내요.', arch: '유언 · 넋 소모' },
    v: { n: '핏빛 귀족', s: '귀족', col: '#a02848', hi: '#ff8aa8', em: 'fang', d: '내 리더 체력을 깎아 힘을 얻고, 체력 10 이하 「갈증」에서 폭발해요.', arch: '자해 · 갈증 · 흡수' },
    h: { n: '새벽 성소', s: '성소', col: '#c9a93a', hi: '#fff0a0', em: 'sun', d: '대기 시간이 지나면 터지는 「마법진」과 단단한 수호로 버티며 회복해요.', arch: '마법진 · 수호 · 회복' },
    g: { n: '태엽 공방', s: '공방', col: '#3f8c96', hi: '#9fe6ee', em: 'gear', d: '0코스트 「태엽 부품」을 모아 쓸수록 기계가 완성돼요.', arch: '부품 누적 · 조립' },
    x: { n: '공용', s: '공용', col: '#7d7468', hi: '#e8dcc8', em: 'gem', d: '어느 직업이든 넣을 수 있는 카드.', arch: '' },
  };
  const CL_ORDER = ['b', 'w', 'a', 'd', 'n', 'v', 'h', 'g'];

  const KW = {
    ward: { n: '수호', d: '상대는 수호 추종자부터 공격해야 해요.', ic: '🛡' },
    rush: { n: '기습', d: '낸 턴에 바로 추종자를 공격할 수 있어요(리더는 다음 턴부터).', ic: '⚡' },
    storm: { n: '돌격', d: '낸 턴에 바로 리더든 추종자든 공격할 수 있어요.', ic: '🐎' },
    amb: { n: '잠복', d: '스스로 공격하기 전까지 상대의 공격과 효과 대상이 되지 않아요.', ic: '🌫' },
    bane: { n: '독날', d: '이 추종자에게 피해를 입은 추종자는 파괴돼요.', ic: '☠' },
    drain: { n: '흡수', d: '공격할 때 준 피해만큼 내 리더 체력을 회복해요.', ic: '🩸' },
  };
  const TERMS = [
    ['등장', '카드를 낼 때 한 번 일어나는 효과.'],
    ['유언', '이 추종자(또는 마법진)가 사라질 때 일어나는 효과.'],
    ['진화 시', '진화할 때 일어나는 효과. 진화하면 공격력·체력이 +2/+2(카드마다 다를 수 있음) 되고, 이번 턴에 바로 추종자를 공격할 수 있어요.'],
    ['공명', '(별빛 학파) 내가 주문을 쓸 때마다 일어나는 효과.'],
    ['연계 N', '(숲의 사수) 이번 턴에 이 카드까지 N장 이상 냈으면 일어나는 효과.'],
    ['갈증', '(핏빛 귀족) 내 리더 체력이 10 이하이면 일어나는 효과.'],
    ['넋 N 소모', '(망령술사) 넋이 N 이상이면 N을 써서 일어나는 효과. 넋은 내 추종자가 파괴될 때마다 1 쌓여요.'],
    ['각성', '(용의 혈족) 내 최대 PP가 7 이상이면 일어나는 효과.'],
    ['부품 N', '(태엽 공방) 이번 판에 「태엽 부품」을 N장 이상 썼으면 일어나는 효과.'],
    ['주문 N', '이번 판에 주문을 N장 이상 썼으면 일어나는 효과.'],
    ['마법진 · 대기 N', '내 턴 시작마다 대기가 1씩 줄고 0이 되면 사라지며 유언을 일으켜요. 마법진은 공격하지도, 공격받지도 않아요.'],
  ];

  /* ───────── 카드 표 ─────────
     F(추종자) id, 이름, 코스트, 공격, 체력, {k:'키워드', fx:[...], ev:{a,h}, r:희귀도1~4, tok}
     S(주문)   id, 이름, 코스트, {fx}
     A(마법진) id, 이름, 코스트, {cd:대기, fx}
     fx = {o:때(play|lw|evo|atk|start|end|spell|ally), d:효과, n, g:대상, i:조건, x:반복, id, a, h, k, f:{mx,mn}} */
  const CARDS = {}, ORDER = [];
  function put(id, t, n, c, a, h, o) {
    o = o || {};
    const cl = id.indexOf('_') > 0 ? id[0] : (id[0] === 'x' ? 'x' : id[0]);
    const k = {}; (o.k || '').split(' ').filter(Boolean).forEach((x) => { k[x] = 1; });
    const cd = { id, t, n, c, a: a || 0, h: h || 0, cl, k, fx: o.fx || [], ev: o.ev || null, r: o.r || (c >= 8 ? 4 : c >= 6 ? 3 : c >= 4 ? 2 : 1), cdn: o.cd || 0, tok: !!o.tok, q: o.q || '' };
    CARDS[id] = cd; if (!cd.tok) ORDER.push(id);
  }
  const F = (id, n, c, a, h, o) => put(id, 'f', n, c, a, h, o);
  const S = (id, n, c, o) => put(id, 's', n, c, 0, 0, o);
  const A = (id, n, c, o) => put(id, 'a', n, c, 0, 0, o);

  /* 토큰 */
  F('b_t1', '견습 방패병', 1, 1, 1, { k: 'ward', tok: 1 });
  F('b_t2', '기병', 2, 2, 2, { k: 'rush', tok: 1 });
  F('w_t', '잎새 정령', 1, 1, 1, { tok: 1, fx: [{ o: 'play', i: 'cb2', d: 'buff', a: 1, h: 0, g: 'self' }] });
  S('a_t', '룬 파편', 0, { tok: 1, fx: [{ d: 'dmg', n: 1, g: 'ef' }] });
  F('d_t', '불씨 비룡', 2, 2, 2, { k: 'rush', tok: 1 });
  F('n_t', '해골병', 1, 1, 1, { tok: 1 });
  F('n_t2', '뼈 거인', 4, 4, 4, { k: 'ward', tok: 1 });
  F('v_t', '박쥐', 1, 1, 1, { k: 'storm', tok: 1 });
  F('h_t', '빛의 수호령', 1, 1, 2, { k: 'ward', tok: 1 });
  F('h_t2', '종의 성기사', 4, 4, 5, { k: 'ward', tok: 1 });
  S('g_t', '태엽 부품', 0, { tok: 1, fx: [{ d: 'buff', a: 1, h: 1, g: 'raf' }] });
  F('g_t2', '미니 로봇', 1, 1, 1, { tok: 1 });
  F('x_t', '쌍둥이 그림자', 1, 1, 1, { tok: 1 });

  /* 칼날 기사단 */
  F('b01', '칼날 수련생', 1, 2, 1, { q: '첫 칼끝은 늘 떨린다.' });
  F('b02', '방패 신병', 1, 1, 2, { k: 'ward' });
  F('b03', '기사단 나팔수', 2, 1, 2, { fx: [{ d: 'sum', id: 'b_t1', n: 1 }] });
  F('b04', '돌격 창병', 2, 2, 1, { k: 'storm' });
  F('b05', '쌍검 결투가', 2, 2, 2, { fx: [{ o: 'evo', d: 'dmg', n: 2, g: 'ef' }] });
  F('b06', '깃발 기수', 3, 2, 3, { fx: [{ d: 'buff', a: 1, h: 0, g: 'oth' }] });
  F('b07', '철갑 기병', 3, 3, 2, { k: 'rush', ev: { a: 2, h: 3 } });
  F('b08', '기사단 교관', 3, 1, 2, { fx: [{ d: 'sum', id: 'b_t1', n: 2 }] });
  S('b09', '일격', 2, { fx: [{ d: 'dmg', n: 3, g: 'ef' }] });
  S('b10', '결속의 함성', 3, { fx: [{ d: 'buff', a: 1, h: 1, g: 'afs' }] });
  F('b11', '전열 지휘관', 4, 3, 4, { fx: [{ d: 'sum', id: 'b_t1', n: 1 }, { o: 'evo', d: 'buff', a: 1, h: 0, g: 'oth' }] });
  F('b12', '질풍 기사', 4, 4, 4, { k: 'rush' });
  F('b13', '방패벽 기사', 4, 2, 6, { k: 'ward' });
  F('b14', '두손검 처형인', 5, 4, 4, { fx: [{ d: 'kill', g: 'ef', f: { mx: 3 } }] });
  S('b15', '기병대 돌진', 4, { fx: [{ d: 'sum', id: 'b_t2', n: 2 }] });
  F('b16', '백전 노장', 5, 4, 5, { k: 'ward', fx: [{ o: 'evo', d: 'sum', id: 'b_t1', n: 2 }] });
  F('b17', '서약의 기사', 6, 5, 4, { k: 'storm' });
  F('b18', '군단장', 7, 5, 6, { fx: [{ d: 'buff', a: 2, h: 1, g: 'oth' }] });
  F('b19', '왕실 근위대장', 8, 6, 7, { k: 'ward', fx: [{ d: 'sum', id: 'b_t1', n: 2 }] });
  F('b20', '전장의 영웅', 9, 7, 7, { k: 'storm', fx: [{ d: 'buff', a: 1, h: 1, g: 'oth' }] });
  A('b21', '단련의 장', 2, { cd: 3, fx: [{ o: 'end', d: 'buff', a: 1, h: 1, g: 'raf' }] });
  S('b22', '반격 태세', 1, { fx: [{ d: 'buff', a: 1, h: 2, g: 'af' }, { d: 'give', k: 'ward', g: 'tgt' }] });

  /* 숲의 사수 */
  F('w01', '정령 부르는 아이', 1, 1, 2, { fx: [{ d: 'add', id: 'w_t', n: 1 }] });
  F('w02', '덩굴 궁수', 2, 2, 3, { fx: [{ i: 'cb2', d: 'dmg', n: 2, g: 'ef' }] });
  F('w03', '바람 사냥꾼', 2, 2, 3, { k: 'rush' });
  F('w04', '메아리 요정', 2, 2, 2, { fx: [{ d: 'add', id: 'w_t', n: 1 }] });
  S('w05', '화살비', 2, { fx: [{ d: 'dmg', n: 1, g: 'ref', x: 3 }] });
  S('w06', '숲의 되돌림', 1, { fx: [{ d: 'bounce', g: 'af' }, { d: 'draw', n: 1 }] });
  F('w07', '나무껍질 수호자', 3, 3, 4, { k: 'ward', fx: [{ i: 'cb2', d: 'buff', a: 1, h: 1, g: 'self' }] });
  F('w08', '이끼 정령', 3, 3, 4, { fx: [{ d: 'add', id: 'w_t', n: 1 }] });
  F('w09', '숲의 저격수', 3, 2, 3, { fx: [{ i: 'cb3', d: 'kill', g: 'ef' }] });
  F('w10', '춤추는 칼잎', 4, 3, 4, { fx: [{ d: 'dmg', n: 1, g: 're', x: 'cb' }] });
  S('w11', '숲의 노래', 2, { fx: [{ d: 'draw', n: 2 }] });
  F('w12', '고목 감시자', 4, 4, 5, { k: 'ward' });
  F('w13', '그림자 사냥꾼', 4, 4, 4, { k: 'amb' });
  F('w14', '바람 정령왕', 5, 5, 4, { fx: [{ i: 'cb2', d: 'give', k: 'storm', g: 'self' }] });
  F('w15', '수풀의 여왕', 5, 4, 5, { fx: [{ d: 'add', id: 'w_t', n: 2 }, { o: 'evo', d: 'buff', a: 1, h: 1, g: 'oth' }] });
  F('w16', '천년 고목', 7, 5, 7, { k: 'ward', fx: [{ d: 'heal', n: 3, g: 'me' }] });
  S('w17', '폭풍 화살', 4, { fx: [{ d: 'dmg', n: 3, g: 'e' }, { i: 'cb2', d: 'dmg', n: 2, g: 'tgt' }] });
  F('w18', '꽃가루 요정', 1, 1, 1, { fx: [{ d: 'draw', n: 1 }] });
  F('w19', '숲의 심판자', 8, 6, 6, { k: 'rush', fx: [{ i: 'cb2', d: 'dmg', n: 3, g: 'efs' }] });
  S('w20', '잎새 칼날', 1, { fx: [{ d: 'dmg', n: 2, g: 'ef' }] });
  A('w21', '되살아나는 숲', 2, { cd: 2, fx: [{ o: 'lw', d: 'add', id: 'w_t', n: 2 }, { o: 'lw', d: 'draw', n: 1 }] });
  F('w22', '사냥꾼의 매', 3, 2, 2, { k: 'storm', fx: [{ i: 'cb2', d: 'buff', a: 1, h: 1, g: 'self' }] });

  /* 별빛 학파 */
  F('a01', '견습 마도사', 1, 1, 2, { fx: [{ o: 'spell', d: 'buff', a: 1, h: 0, g: 'self' }] });
  S('a02', '마력 화살', 1, { fx: [{ d: 'dmg', n: 2, g: 'ef' }] });
  S('a03', '지식 탐구', 1, { fx: [{ d: 'draw', n: 1 }] });
  F('a04', '룬 조각사', 2, 1, 2, { fx: [{ d: 'add', id: 'a_t', n: 1 }] });
  F('a05', '수정 골렘', 3, 2, 4, { fx: [{ o: 'spell', d: 'buff', a: 1, h: 1, g: 'self' }] });
  S('a06', '연쇄 번개', 3, { fx: [{ d: 'dmg', n: 2, g: 'ref', x: 2 }] });
  S('a07', '화염 폭발', 5, { fx: [{ d: 'dmg', n: 2, g: 'efs' }] });
  F('a08', '비전 학자', 3, 2, 3, { fx: [{ d: 'draw', n: 1 }] });
  F('a09', '지혜의 올빼미', 2, 2, 3, { fx: [{ o: 'evo', d: 'draw', n: 1 }] });
  F('a10', '주문검 기사', 4, 3, 3, { fx: [{ o: 'spell', d: 'dmg', n: 1, g: 'ref' }] });
  F('a11', '별빛 학자', 4, 3, 4, { fx: [{ i: 'sp5', d: 'buff', a: 3, h: 3, g: 'self' }, { i: 'sp5', d: 'give', k: 'ward', g: 'self' }] });
  S('a12', '마나 폭풍', 5, { fx: [{ d: 'dmg', n: 4, g: 'ef' }, { d: 'draw', n: 1 }] });
  F('a13', '탑의 수호자', 5, 4, 6, { k: 'ward', fx: [{ o: 'spell', d: 'buff', a: 1, h: 0, g: 'self' }] });
  F('a14', '대마도사', 6, 4, 5, { fx: [{ d: 'add', id: 'a_t', n: 2 }, { i: 'sp8', d: 'dmg', n: 3, g: 'eL' }] });
  S('a15', '운석 낙하', 7, { fx: [{ d: 'dmg', n: 4, g: 'efs' }] });
  S('a16', '시간 왜곡', 3, { fx: [{ d: 'draw', n: 2 }] });
  A('a17', '지식의 탑', 2, { cd: 3, fx: [{ o: 'spell', d: 'cdr', n: 1 }, { o: 'lw', d: 'draw', n: 2 }] });
  S('a18', '얼음 창', 4, { fx: [{ d: 'dmg', n: 4, g: 'ef' }] });
  F('a19', '서적 수호령', 2, 1, 3, { k: 'ward', fx: [{ o: 'spell', d: 'buff', a: 1, h: 0, g: 'self' }] });
  F('a20', '원소 결정체', 5, 4, 4, { fx: [{ o: 'evo', d: 'dmg', n: 1, g: 'efs' }] });
  F('a21', '마도왕', 8, 6, 6, { fx: [{ d: 'dmg', n: 1, g: 're', x: 'sp' }] });
  S('a22', '비전 화살비', 6, { fx: [{ d: 'dmg', n: 4, g: 'e' }, { d: 'add', id: 'a_t', n: 2 }] });

  /* 용의 혈족 */
  F('d01', '용알 수호자', 1, 1, 2, { fx: [{ i: 'ov', d: 'buff', a: 2, h: 2, g: 'self' }] });
  F('d02', '불씨 드레이크', 2, 2, 2, { fx: [{ i: 'ov', d: 'give', k: 'storm', g: 'self' }] });
  S('d03', '용의 기도', 2, { fx: [{ d: 'mpp', n: 1 }] });
  F('d04', '비늘 전사', 2, 2, 3);
  S('d05', '화염 숨결', 2, { fx: [{ i: '!ov', d: 'dmg', n: 2, g: 'ef' }, { i: 'ov', d: 'dmg', n: 4, g: 'ef' }] });
  F('d06', '하늘 수색꾼', 3, 3, 2, { k: 'rush' });
  A('d07', '용의 둥지', 3, { cd: 2, fx: [{ o: 'lw', d: 'mpp', n: 1 }, { o: 'lw', d: 'draw', n: 1 }] });
  F('d08', '용혈 전사', 3, 3, 3, { fx: [{ i: 'ov', d: 'buff', a: 2, h: 2, g: 'self' }] });
  F('d09', '비룡 기수', 4, 3, 4, { fx: [{ o: 'evo', d: 'dmg', n: 3, g: 'ef' }] });
  F('d10', '바위비늘 용', 4, 3, 5, { k: 'ward' });
  S('d11', '불꽃 폭풍', 6, { fx: [{ d: 'dmg', n: 4, g: 'alls' }] });
  F('d12', '성난 비룡', 5, 4, 4, { k: 'rush' });
  S('d13', '고룡의 부름', 1, { fx: [{ i: '!ov', d: 'draw', n: 1 }, { i: 'ov', d: 'draw', n: 2 }] });
  F('d14', '용의 군주', 6, 4, 5, { fx: [{ d: 'dmg', n: 3, g: 'ef' }] });
  F('d15', '화산 용', 7, 6, 6, { k: 'rush' });
  F('d16', '하늘 지배자', 8, 6, 6, { k: 'storm' });
  F('d17', '대지 용', 9, 8, 8, { k: 'ward', fx: [{ d: 'heal', n: 4, g: 'me' }] });
  F('d18', '용 조련사', 4, 3, 3, { fx: [{ d: 'mpp', n: 1 }] });
  S('d19', '용비늘 방패', 1, { fx: [{ d: 'buff', a: 0, h: 3, g: 'af' }, { d: 'give', k: 'ward', g: 'tgt' }] });
  F('d20', '용의 새끼', 1, 1, 1, { fx: [{ o: 'lw', d: 'draw', n: 1 }] });
  F('d21', '비늘 갑주 기사', 5, 4, 6, { fx: [{ i: 'ov', d: 'buff', a: 1, h: 1, g: 'self' }, { i: 'ov', d: 'give', k: 'ward', g: 'self' }] });
  F('d22', '종말의 용', 10, 10, 10, { fx: [{ d: 'kill', g: 'efs' }] });

  /* 망령술사 */
  F('n01', '뼈 수집가', 1, 1, 1, { fx: [{ o: 'lw', d: 'sum', id: 'n_t', n: 1 }] });
  F('n02', '묘지 쥐', 1, 1, 2, { fx: [{ o: 'lw', d: 'dmg', n: 1, g: 'ref' }] });
  S('n03', '혼령 소환', 2, { fx: [{ d: 'sum', id: 'n_t', n: 2 }] });
  F('n04', '망자 기사', 2, 2, 2, { fx: [{ o: 'lw', d: 'sum', id: 'n_t', n: 1 }] });
  S('n05', '영혼 착취', 1, { fx: [{ d: 'kill', g: 'af' }, { d: 'draw', n: 2 }] });
  F('n06', '시체 먹는 자', 3, 3, 3, { fx: [{ i: 'so2', d: 'buff', a: 2, h: 2, g: 'self' }] });
  F('n07', '해골 궁수', 3, 2, 3, { fx: [{ d: 'dmg', n: 1, g: 'ef' }, { i: 'so3', d: 'dmg', n: 2, g: 'tgt' }] });
  F('n08', '묘지 거인', 6, 5, 5, { fx: [{ o: 'lw', d: 'sum', id: 'n_t', n: 2 }] });
  S('n09', '영혼 사슬', 4, { fx: [{ d: 'kill', g: 'ef' }] });
  A('n10', '저주받은 망토', 1, { cd: 2, fx: [{ o: 'lw', d: 'sum', id: 'n_t', n: 2 }] });
  F('n11', '원혼', 3, 2, 3, { k: 'amb bane' });
  F('n12', '망령 마도사', 4, 3, 5, { fx: [{ i: 'so4', d: 'dmg', n: 2, g: 'efs' }] });
  F('n13', '무덤의 군주', 6, 5, 5, { fx: [{ i: 'so4', d: 'sum', id: 'n_t2', n: 1 }] });
  F('n14', '넋 수확자', 4, 3, 4, { fx: [{ o: 'evo', d: 'sum', id: 'n_t', n: 2 }] });
  S('n15', '시체 폭발', 2, { fx: [{ d: 'kill', g: 'af' }, { d: 'dmg', n: 2, g: 'efs' }] });
  F('n16', '유령 나비', 2, 1, 3, { k: 'bane' });
  S('n17', '망자의 행진', 5, { fx: [{ d: 'sum', id: 'n_t', n: 3 }, { d: 'buff', a: 1, h: 0, g: 'afs' }] });
  F('n18', '해골 비룡', 7, 6, 7, { fx: [{ o: 'lw', d: 'sum', id: 'n_t', n: 3 }] });
  F('n19', '굶주린 시체', 2, 3, 2, { fx: [{ o: 'lw', d: 'soul', n: 1 }] });
  A('n20', '망각의 종', 3, { cd: 3, fx: [{ o: 'end', d: 'dmg', n: 1, g: 'ref' }, { o: 'lw', d: 'sum', id: 'n_t', n: 1 }] });
  F('n21', '죽음의 사신', 9, 7, 7, { fx: [{ i: 'so8', d: 'kill', g: 'efs' }] });
  F('n22', '영혼 흡수 마녀', 5, 4, 4, { k: 'drain', fx: [{ o: 'lw', d: 'sum', id: 'n_t', n: 1 }] });

  /* 핏빛 귀족 */
  F('v01', '박쥐 떼 주인', 1, 1, 2, { fx: [{ d: 'hurt', n: 1 }, { d: 'sum', id: 'v_t', n: 1 }] });
  S('v02', '피의 계약', 1, { fx: [{ d: 'hurt', n: 2 }, { d: 'draw', n: 2 }] });
  F('v03', '흡혈 시종', 2, 2, 3, { k: 'drain' });
  F('v04', '굶주린 늑대', 2, 3, 3, { fx: [{ i: 'th', d: 'give', k: 'storm', g: 'self' }] });
  F('v05', '붉은 칼춤꾼', 2, 2, 2, { fx: [{ d: 'hurt', n: 1 }, { d: 'dmg', n: 2, g: 'ef' }] });
  S('v06', '피의 연회', 2, { fx: [{ d: 'dmg', n: 3, g: 'e' }, { d: 'hurt', n: 1 }] });
  F('v07', '밤의 백작', 3, 3, 4, { fx: [{ i: 'th', d: 'buff', a: 2, h: 0, g: 'self' }, { i: 'th', d: 'give', k: 'drain', g: 'self' }] });
  F('v08', '늑대인간', 3, 3, 3, { fx: [{ o: 'evo', d: 'dmg', n: 3, g: 'eL' }] });
  S('v09', '박쥐 부르기', 2, { fx: [{ d: 'sum', id: 'v_t', n: 2 }] });
  A('v10', '피의 성', 3, { cd: 4, fx: [{ o: 'start', d: 'hurt', n: 1 }, { o: 'start', d: 'sum', id: 'v_t', n: 1 }] });
  F('v11', '송곳니 기사', 4, 4, 4, { k: 'rush drain' });
  F('v12', '핏빛 마녀', 4, 4, 4, { fx: [{ d: 'hurt', n: 2 }, { d: 'dmg', n: 3, g: 'eL' }] });
  F('v13', '광기의 귀족', 5, 5, 4, { fx: [{ d: 'dmg', n: 4, g: 'ef', f: { w: 1 } }, { i: 'th', d: 'give', k: 'storm', g: 'self' }] });
  F('v14', '피의 군주', 6, 5, 5, { k: 'drain', fx: [{ d: 'sum', id: 'v_t', n: 2 }] });
  S('v15', '진홍 폭풍', 4, { fx: [{ d: 'dmg', n: 2, g: 'efs' }, { d: 'hurt', n: 1 }] });
  S('v16', '피의 갈망', 1, { fx: [{ d: 'buff', a: 2, h: 0, g: 'af' }, { d: 'give', k: 'drain', g: 'tgt' }] });
  F('v17', '송곳니 사냥꾼', 3, 3, 3, { k: 'rush drain' });
  F('v18', '밤의 여왕', 8, 5, 6, { k: 'storm drain' });
  F('v19', '박쥐 왕', 5, 3, 4, { fx: [{ i: '!th', d: 'sum', id: 'v_t', n: 1 }, { i: 'th', d: 'sum', id: 'v_t', n: 3 }] });
  S('v20', '핏빛 서약', 1, { fx: [{ i: '!th', d: 'dmg', n: 2, g: 'e' }, { i: 'th', d: 'dmg', n: 4, g: 'e' }] });
  F('v21', '고대 흡혈귀', 7, 6, 6, { fx: [{ d: 'heal', n: 5, g: 'me' }, { i: 'th', d: 'give', k: 'storm', g: 'self' }] });
  F('v22', '피 맛 본 검객', 1, 2, 2, { fx: [{ d: 'hurt', n: 1 }] });

  /* 새벽 성소 */
  F('h01', '견습 사제', 1, 1, 2, { fx: [{ d: 'heal', n: 1, g: 'me' }] });
  A('h02', '빛의 결계', 1, { cd: 1, fx: [{ o: 'lw', d: 'sum', id: 'h_t', n: 1 }] });
  F('h03', '성가대원', 2, 2, 3, { k: 'ward' });
  F('h04', '기도하는 수녀', 2, 2, 3, { fx: [{ d: 'cdr', n: 1 }] });
  S('h05', '정화의 빛', 2, { fx: [{ d: 'kill', g: 'ef', f: { mx: 3 } }] });
  A('h06', '축복의 종', 2, { cd: 3, fx: [{ o: 'lw', d: 'sum', id: 'h_t2', n: 1 }] });
  F('h07', '수호 성기사', 3, 2, 4, { k: 'ward', fx: [{ d: 'heal', n: 2, g: 'me' }] });
  F('h08', '새벽 사제', 3, 2, 4, { fx: [{ d: 'draw', n: 1 }] });
  S('h09', '빛의 심판', 4, { fx: [{ d: 'kill', g: 'ef' }] });
  A('h10', '성스러운 등불', 3, { cd: 2, fx: [{ o: 'start', d: 'heal', n: 1, g: 'me' }, { o: 'lw', d: 'draw', n: 2 }] });
  F('h11', '순례 기사', 4, 4, 6, { k: 'ward' });
  F('h12', '성역 수호자', 4, 3, 5, { k: 'ward', fx: [{ o: 'evo', d: 'sum', id: 'h_t', n: 2 }] });
  A('h13', '대성당', 4, { cd: 2, fx: [{ o: 'lw', d: 'sum', id: 'h_t2', n: 2 }] });
  S('h14', '빛의 창', 3, { fx: [{ d: 'dmg', n: 3, g: 'ef' }, { d: 'heal', n: 2, g: 'me' }] });
  F('h15', '성녀', 6, 5, 6, { k: 'ward', fx: [{ d: 'heal', n: 3, g: 'me' }] });
  F('h16', '하늘 기사', 5, 4, 5, { fx: [{ d: 'sum', id: 'h_t', n: 1 }, { o: 'evo', d: 'sum', id: 'h_t', n: 1 }] });
  S('h17', '기적', 5, { fx: [{ d: 'kill', g: 'efs', f: { mn: 4 } }] });
  F('h18', '빛의 전령', 2, 2, 2, { fx: [{ o: 'evo', d: 'heal', n: 3, g: 'me' }] });
  A('h19', '모래시계 제단', 1, { cd: 3, fx: [{ o: 'lw', d: 'heal', n: 3, g: 'me' }, { o: 'lw', d: 'draw', n: 1 }] });
  F('h20', '대천사', 7, 6, 8, { k: 'ward', fx: [{ d: 'cdr', n: 2 }, { d: 'heal', n: 3, g: 'me' }] });
  F('h21', '등불지기', 1, 1, 1, { fx: [{ d: 'cdr', n: 1 }] });
  A('h22', '성광의 탑', 3, { cd: 4, fx: [{ o: 'end', d: 'dmg', n: 2, g: 'ref' }] });

  /* 태엽 공방 */
  F('g01', '태엽 견습생', 1, 1, 1, { fx: [{ d: 'add', id: 'g_t', n: 1 }] });
  F('g02', '톱니 경비병', 2, 2, 3, { fx: [{ i: 'pt3', d: 'buff', a: 1, h: 1, g: 'self' }, { i: 'pt3', d: 'give', k: 'ward', g: 'self' }] });
  S('g03', '조립', 1, { fx: [{ d: 'add', id: 'g_t', n: 2 }] });
  F('g04', '태엽 쥐', 1, 1, 1, { k: 'storm' });
  F('g05', '증기 정비공', 2, 2, 2, { fx: [{ o: 'evo', d: 'add', id: 'g_t', n: 2 }] });
  A('g06', '자동 포탑', 3, { cd: 3, fx: [{ o: 'end', d: 'dmg', n: 1, g: 'ref' }] });
  F('g07', '강철 집게', 3, 3, 3, { fx: [{ i: 'pt4', d: 'dmg', n: 3, g: 'ef' }] });
  F('g08', '공장 감독관', 3, 2, 4, { fx: [{ o: 'start', d: 'add', id: 'g_t', n: 1 }] });
  S('g09', '과부하', 2, { fx: [{ d: 'dmg', n: 2, g: 'ef' }, { d: 'add', id: 'g_t', n: 1 }] });
  F('g10', '증기 기관차', 4, 4, 3, { k: 'rush', fx: [{ i: 'pt5', d: 'give', k: 'storm', g: 'self' }] });
  A('g11', '미니 로봇 공장', 3, { cd: 3, fx: [{ o: 'start', d: 'sum', id: 'g_t2', n: 1 }] });
  F('g12', '강철 수문장', 4, 3, 5, { k: 'ward', fx: [{ o: 'evo', d: 'add', id: 'g_t', n: 2 }] });
  S('g13', '개조', 2, { fx: [{ d: 'buff', a: 2, h: 2, g: 'af' }] });
  F('g14', '기계 거인', 6, 5, 6, { fx: [{ i: 'pt5', d: 'buff', a: 3, h: 3, g: 'self' }, { i: 'pt5', d: 'give', k: 'ward', g: 'self' }] });
  S('g15', '전기 방전', 4, { fx: [{ d: 'dmg', n: 2, g: 'efs' }] });
  F('g16', '연쇄 폭탄병', 3, 2, 2, { fx: [{ o: 'lw', d: 'dmg', n: 2, g: 'ref' }] });
  F('g17', '태엽 기사', 5, 4, 4, { fx: [{ d: 'add', id: 'g_t', n: 2 }] });
  F('g18', '발명가', 4, 3, 3, { fx: [{ d: 'draw', n: 1 }, { d: 'add', id: 'g_t', n: 1 }] });
  F('g19', '거대 전투 기계', 8, 7, 7, { fx: [{ i: 'pt8', d: 'dmg', n: 3, g: 'efs' }] });
  F('g20', '정밀 사격 로봇', 5, 3, 3, { fx: [{ d: 'dmg', n: 1, g: 'ref', x: 3 }] });
  S('g21', '태엽 심장', 3, { fx: [{ d: 'buff', a: 1, h: 1, g: 'afs' }, { d: 'add', id: 'g_t', n: 1 }] });
  F('g22', '기계 신', 10, 10, 10, { fx: [{ d: 'buff', a: 2, h: 2, g: 'oth' }] });

  /* 공용 */
  F('x01', '떠돌이 용병', 1, 1, 2);
  F('x02', '골목 불량배', 1, 2, 1);
  F('x03', '방패 든 농부', 2, 1, 3, { k: 'ward' });
  F('x04', '여관 주인', 2, 2, 2, { fx: [{ d: 'heal', n: 2, g: 'me' }] });
  F('x05', '숲 늑대', 2, 3, 2);
  F('x06', '떠돌이 음유시인', 2, 1, 2, { fx: [{ d: 'draw', n: 1 }] });
  F('x07', '광산 골렘', 3, 2, 4, { k: 'ward' });
  F('x08', '용병 검사', 3, 3, 4);
  F('x09', '독침 거미', 2, 1, 1, { k: 'bane' });
  F('x10', '숨은 자객', 3, 3, 2, { k: 'amb' });
  F('x11', '폭탄 상인', 3, 2, 2, { fx: [{ o: 'lw', d: 'dmg', n: 2, g: 'ref' }] });
  F('x12', '고원의 거인', 4, 4, 5);
  F('x13', '견습 기마병', 4, 3, 4, { k: 'rush' });
  F('x14', '떠도는 치유사', 4, 3, 4, { fx: [{ d: 'heal', n: 3, g: 'me' }] });
  F('x15', '돌산 트롤', 5, 5, 6);
  F('x16', '바다 괴수', 6, 6, 6, { k: 'ward' });
  F('x17', '전설의 용사', 8, 7, 7, { fx: [{ d: 'dmg', n: 3, g: 'ef' }] });
  F('x18', '시간의 마법사', 5, 3, 4, { fx: [{ d: 'draw', n: 2 }] });
  F('x19', '화염 정령', 3, 3, 2, { fx: [{ d: 'dmg', n: 1, g: 'ef' }] });
  F('x20', '그림자 쌍둥이', 2, 1, 1, { fx: [{ d: 'sum', id: 'x_t', n: 1 }] });
  F('x21', '수호 골렘', 5, 3, 7, { k: 'ward' });
  F('x22', '돌격 멧돼지', 3, 3, 1, { k: 'storm' });
  A('x23', '마나 우물', 1, { cd: 2, fx: [{ o: 'lw', d: 'draw', n: 1 }] });
  S('x24', '응급 치료', 1, { fx: [{ d: 'heal', n: 4, g: 'me' }] });
  S('x25', '날카로운 칼', 1, { fx: [{ d: 'dmg', n: 1, g: 'ef' }, { d: 'draw', n: 1 }] });
  S('x26', '전투의 함성', 2, { fx: [{ d: 'buff', a: 2, h: 1, g: 'af' }, { d: 'give', k: 'rush', g: 'tgt' }] });
  F('x27', '방랑 기사', 6, 5, 5, { fx: [{ d: 'dmg', n: 2, g: 'ref' }] });
  F('x28', '하늘 고래', 7, 5, 8, { k: 'ward', fx: [{ o: 'lw', d: 'draw', n: 2 }] });
  F('x29', '고대 골렘', 9, 8, 8, { k: 'ward' });
  F('x30', '보물 고블린', 1, 1, 1, { fx: [{ o: 'lw', d: 'draw', n: 1 }] });

  /* 그림 파일 목록(나중에 서브컬처 그림을 넣을 자리) — 없으면 자리 그림으로 그린다 */
  const ART = {};
  Object.keys(CARDS).forEach((id) => { ART[id] = 'img/cardduel/' + id + '.webp'; });
  Object.keys(CLS).forEach((c) => { ART['leader_' + c] = 'img/cardduel/leader_' + c + '.webp'; });
  // 그림을 넣은 카드 id를 여기에 적거나(예: 'b01'), 전부 넣었으면 ART_ALL = true. 적힌 것만 불러와서 없는 파일 오류를 내지 않는다.
  const ART_ALL = false;
  const ART_READY = new Set([]);

  /* ───────── 규칙 상수 ───────── */
  const HP0 = 20, MAXPP = 10, BOARD = 5, HAND = 9, DECK = 40, COPIES = 3, TURN_CAP = 70, DRAFT_PICKS = 20;
  const EVO_TURN = [5, 4], EVO_PTS = [2, 3];   // 선공·후공: 진화 가능한 내 턴 · 진화 포인트
  const LEAD = { b: '기사단장', w: '숲의 궁수장', a: '별빛 대학자', d: '용의 무녀', n: '망령 군주', v: '핏빛 백작', h: '새벽 대주교', g: '태엽 장인', x: '방랑자' };

  const cardOf = (id) => CARDS[id];
  const isFol = (u) => u && CARDS[u.id].t === 'f';
  const op = (s) => 1 - s;
  const rnd = (n) => Math.floor(Math.random() * n);
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ───────── 덱 ───────── */
  function classPool(cl) { return ORDER.filter((id) => CARDS[id].cl === cl || CARDS[id].cl === 'x'); }
  function validDeck(cl, d) {
    if (!CLS[cl] || cl === 'x' || !Array.isArray(d) || d.length !== DECK) return false;
    const cnt = {};
    for (const id of d) { const c = CARDS[id]; if (!c || c.tok || (c.cl !== cl && c.cl !== 'x')) return false; cnt[id] = (cnt[id] || 0) + 1; if (cnt[id] > COPIES) return false; }
    return true;
  }
  // 추천(기본) 덱: 직업 카드 중심 + 공용으로 곡선 맞추기. 결정적.
  const PRESET_NEUTRAL = ['x08', 'x12', 'x07', 'x05', 'x14', 'x18', 'x16', 'x25', 'x06', 'x13', 'x15', 'x03', 'x10', 'x21'];
  const PRESET_SKIP = { d: ['d22'], n: ['n21'], g: ['g22'], a: ['a21'], h: [], b: [], w: [], v: [] };
  function presetDeck(cl) {
    const own = ORDER.filter((id) => CARDS[id].cl === cl && !(PRESET_SKIP[cl] || []).includes(id));
    const d = [];
    own.forEach((id) => { const c = CARDS[id].c; const n = c >= 7 ? 1 : 2; for (let i = 0; i < n; i++) d.push(id); });
    let k = 0;
    while (d.length < DECK) { const id = PRESET_NEUTRAL[k % PRESET_NEUTRAL.length]; if (d.filter((x) => x === id).length < 2) d.push(id); k++; if (k > 200) break; }
    // 너무 많으면 비싼 카드부터 1장씩 덜기
    while (d.length > DECK) {
      const sorted = d.map((id, i) => [CARDS[id].c, i, id]).sort((a, b) => b[0] - a[0]);
      let rm = sorted.find((x) => d.filter((y) => y === x[2]).length > 1) || sorted[0];
      d.splice(rm[1], 1);
    }
    return d.sort((a, b) => CARDS[a].c - CARDS[b].c || (a < b ? -1 : 1));
  }

  /* ───────── 카드 점수(드래프트 AI·덱 짐작) ───────── */
  function cardScore(id) {
    const c = CARDS[id]; let v = 0;
    if (c.t === 'f') v = (c.a + c.h) - (2 * c.c + 1);
    for (const k in c.k) v += { ward: 1, rush: 1.2, storm: 2, amb: 1, bane: 2, drain: 1 }[k] || 0;
    c.fx.forEach((f) => {
      const m = f.i ? 0.6 : 1, x = typeof f.x === 'number' ? f.x : f.x ? 2 : 1;
      const w = { dmg: (f.g === 'efs' || f.g === 'alls' ? 2.2 : 1) * (f.n || 1) * x, heal: 0.5 * f.n, draw: 2 * f.n, sum: (CARDS[f.id] ? CARDS[f.id].a + CARDS[f.id].h : 2) * f.n, add: 1.2 * f.n, buff: ((f.a || 0) + (f.h || 0)) * (f.g === 'afs' || f.g === 'oth' ? 2 : 1), give: 1, kill: f.g === 'efs' ? 12 : 6, bounce: 1, mpp: 4, hurt: -0.8 * f.n, cdr: 1, soul: 1, evof: 3 }[f.d] || 0;
      v += w * m * (f.o === 'evo' ? 0.6 : 1);
    });
    if (c.t !== 'f') v -= c.c * 0.9 - 1;
    return v;
  }

  /* ───────── 상태 ───────── */
  function mkPlayer(p, seat) {
    return { cl: '', dk: [], hd: [], bd: [], hp: HP0, pp: 0, mp: 0, ep: EVO_PTS[seat], evt: 0, own: 0, so: 0, sp: 0, pc: 0, cb: 0, ok: 0, mu: 0, dr: null,
      st: { pl: 0, fd: 0, ev: 0, big: 0, kills: 0 } };
  }
  function init(players, opts) {
    opts = opts || {};
    const s = { ph: 'pick', mode: opts.mode === 'draft' ? 'draft' : 'std', cur: 0, tn: 0, uid: 1, P: [mkPlayer(players[0], 0), mkPlayer(players[1], 1)], log: [], last: { id: 0, ev: [] }, win: null, names: players.map((p, i) => String(p.name || (i + 1) + 'P').slice(0, 12)), lv: players.map((p) => p.lv || 0) };
    if (s.mode === 'draft') s.P.forEach((p) => { p.dr = { co: shuffle(CL_ORDER.slice()).slice(0, 3), off: [], pk: [] }; });
    return s;
  }
  function actor(s) {
    if (s.win != null) return null;
    if (s.ph === 'pick') { const w = [0, 1].filter((i) => !s.P[i].ok); return w.length ? w : null; }
    if (s.ph === 'mull') { const w = [0, 1].filter((i) => !s.P[i].mu); return w.length ? w : null; }
    return s.cur;
  }
  function logp(s, t) { s.log.push(t); if (s.log.length > 40) s.log.shift(); }
  const EV = (s, e) => { s.last.ev.push(e); };
  const pname = (s, seat) => (s.names && s.names[seat]) || (seat + 1) + 'P';

  function draftOffer(s, p) {
    const pool = classPool(p.cl);
    const own = pool.filter((id) => CARDS[id].cl === p.cl), neu = pool.filter((id) => CARDS[id].cl === 'x');
    const out = [];
    let guard = 0;
    while (out.length < 3 && guard++ < 50) {
      const src = Math.random() < 0.68 ? own : neu;
      // 희귀도 가중: 높은 희귀도는 덜 나옴
      let id = src[rnd(src.length)];
      if (CARDS[id].r >= 3 && Math.random() < 0.45) id = src[rnd(src.length)];
      if (!out.includes(id)) out.push(id);
    }
    p.dr.off = out;
  }
  function startMatch(s) {
    s.ph = 'mull';
    s.P.forEach((p, i) => { p.dk = shuffle(p.dk.slice()); p.hd = []; for (let k = 0; k < 3; k++) drawRaw(s, i); });
    logp(s, '덱을 섞고 카드 3장씩 받았어요. 바꿀 카드를 고르세요.');
  }
  function drawRaw(s, seat) {
    const p = s.P[seat];
    if (!p.dk.length) return null;
    const id = p.dk.shift(), c = { u: s.uid++, id };
    p.hd.push(c); return c;
  }
  function draw(s, seat, n) {
    const p = s.P[seat];
    for (let i = 0; i < n; i++) {
      if (!p.dk.length) { if (s.win == null) { s.win = op(seat); s.why = 'deck'; logp(s, pname(s, seat) + '의 덱이 바닥나 패배했어요.'); } return; }
      if (p.hd.length >= HAND) { const id = p.dk.shift(); EV(s, ['burn', seat, id]); logp(s, '손패가 가득 차 「' + CARDS[id].n + '」이(가) 버려졌어요.'); continue; }
      const c = drawRaw(s, seat); EV(s, ['dr', seat, c.u]);
    }
  }
  function addHand(s, seat, id, n) {
    const p = s.P[seat];
    for (let i = 0; i < n; i++) { if (p.hd.length >= HAND) break; const c = { u: s.uid++, id }; p.hd.push(c); EV(s, ['add', seat, c.u, id]); }
  }
  function mkUnit(s, id) {
    const c = CARDS[id];
    const u = { u: s.uid++, id, a: c.a, h: c.h, m: c.h, k: Object.assign({}, c.k), e: 0, sk: 1, at: 0, er: 0 };
    if (c.t === 'a') { u.cd = c.cdn; delete u.sk; }
    return u;
  }
  function findU(s, uid) {
    for (let i = 0; i < 2; i++) { const j = s.P[i].bd.findIndex((x) => x.u === uid); if (j >= 0) return { seat: i, i: j, u: s.P[i].bd[j] }; }
    return null;
  }

  /* 리더 대상은 문자열 'L0' / 'L1', 카드 대상은 uid 숫자 */
  function targetable(s, seat, sel, f, srcUid) {
    const me = s.P[seat], en = s.P[op(seat)], out = [];
    const okf = (u) => isFol(u) && (!f || ((f.mx == null || u.a <= f.mx) && (f.mn == null || u.a >= f.mn) && (!f.w || u.k.ward)));
    if (sel === 'ef' || sel === 'e' || sel === 'f') en.bd.forEach((u) => { if (okf(u) && !u.k.amb) out.push(u.u); });
    if (sel === 'e') out.push('L' + op(seat));
    if (sel === 'af' || sel === 'f') me.bd.forEach((u) => { if (okf(u) && u.u !== srcUid) out.push(u.u); });
    return out;
  }
  const CHOSEN = { ef: 1, e: 1, af: 1, f: 1 };
  function chosenSel(fxs, on) {
    for (const f of fxs) if ((f.o || 'play') === on && CHOSEN[f.g]) return f;
    return null;
  }

  function condOk(s, seat, cond) {
    if (!cond) return true;
    const p = s.P[seat];
    let neg = false; if (cond[0] === '!') { neg = true; cond = cond.slice(1); }
    let r;
    if (cond.startsWith('cb')) r = p.cb >= +cond.slice(2);
    else if (cond === 'th') r = p.hp <= 10;
    else if (cond === 'ov') r = p.mp >= 7;
    else if (cond.startsWith('so')) r = p.so >= +cond.slice(2);
    else if (cond.startsWith('sp')) r = p.sp >= +cond.slice(2);
    else if (cond.startsWith('pt')) r = p.pc >= +cond.slice(2);
    else r = true;
    return neg ? !r : r;
  }

  // 한 번의 발동(같은 때의 효과 묶음)을 처리
  function runFx(s, seat, card, on, ctx) {
    const fxs = CARDS[card.id].fx.filter((f) => (f.o || 'play') === on);
    if (!fxs.length) return;
    const pass = {}; const spent = {};
    fxs.forEach((f) => { if (f.i && pass[f.i] == null) pass[f.i] = condOk(s, seat, f.i); });
    for (const f of fxs) {
      if (s.win != null) return;
      if (f.i && !pass[f.i]) continue;
      if (f.i && f.i.startsWith('so') && !spent[f.i]) { spent[f.i] = 1; s.P[seat].so -= +f.i.slice(2); EV(s, ['so', seat, -(+f.i.slice(2))]); }
      doFx(s, seat, card, f, ctx);
    }
  }
  function resolveT(s, seat, card, g, ctx, f) {
    const me = s.P[seat], en = s.P[op(seat)];
    const okf = (u) => isFol(u) && (!f.f || ((f.f.mx == null || u.a <= f.f.mx) && (f.f.mn == null || u.a >= f.f.mn) && (!f.f.w || u.k.ward)));
    switch (g) {
      case 'ef': case 'e': case 'af': case 'f': case 'tgt': {
        const t = ctx.tgt; if (t == null) return [];
        if (typeof t === 'string') return [t];
        const fu = findU(s, t); return fu ? [t] : [];
      }
      case 'self': return findU(s, card.u) ? [card.u] : [];
      case 'me': return ['L' + seat];
      case 'eL': return ['L' + op(seat)];
      case 'efs': return en.bd.filter(okf).map((u) => u.u);
      case 'afs': return me.bd.filter(okf).map((u) => u.u);
      case 'oth': return me.bd.filter((u) => okf(u) && u.u !== card.u).map((u) => u.u);
      case 'alls': return me.bd.concat(en.bd).filter(okf).map((u) => u.u);
      case 'ref': { const l = en.bd.filter((u) => okf(u) && u.h > 0); return l.length ? [l[rnd(l.length)].u] : []; }
      case 'raf': { const l = me.bd.filter((u) => okf(u) && u.h > 0); return l.length ? [l[rnd(l.length)].u] : []; }
      case 're': { const l = en.bd.filter((u) => okf(u) && u.h > 0).map((u) => u.u); l.push('L' + op(seat)); return [l[rnd(l.length)]]; }
    }
    return [];
  }
  function dmgTo(s, t, n, srcSeat, srcU) {
    if (n <= 0) return 0;
    if (typeof t === 'string') {
      const ps = +t[1], p = s.P[ps]; p.hp -= n; EV(s, ['d', t, n, p.hp]);
      if (srcSeat != null && ps !== srcSeat) s.P[srcSeat].st.fd += n;
      if (p.hp <= 0 && s.win == null) { s.win = op(ps); s.why = 'hp'; }
      return n;
    }
    const fu = findU(s, t); if (!fu || !isFol(fu.u)) return 0;
    fu.u.h -= n; EV(s, ['d', t, n, fu.u.h]);
    if (srcU && srcU.k && srcU.k.bane && fu.u.h > 0) { fu.u.h = 0; EV(s, ['bane', t]); }
    return n;
  }
  function healTo(s, t, n) {
    if (typeof t === 'string') { const p = s.P[+t[1]]; const b = p.hp; p.hp = Math.min(HP0, p.hp + n); if (p.hp > b) EV(s, ['h', t, p.hp - b, p.hp]); return; }
    const fu = findU(s, t); if (!fu) return; const b = fu.u.h; fu.u.h = Math.min(fu.u.m, fu.u.h + n); if (fu.u.h > b) EV(s, ['h', t, fu.u.h - b, fu.u.h]);
  }
  function summon(s, seat, id, n) {
    const p = s.P[seat];
    for (let i = 0; i < n; i++) {
      if (p.bd.length >= BOARD) break;
      const u = mkUnit(s, id); p.bd.push(u); EV(s, ['sm', seat, u.u, id]);
      allyTrig(s, seat, u);
    }
  }
  function allyTrig(s, seat, nu) {
    s.P[seat].bd.slice().forEach((o) => { if (o.u !== nu.u && CARDS[o.id].fx.some((f) => f.o === 'ally')) runFx(s, seat, o, 'ally', {}); });
  }
  function evolve(s, seat, u, ctx, free) {
    const c = CARDS[u.id], ev = c.ev || { a: 2, h: 2 };
    const me = s.P[seat];
    u.e = 1; u.a += ev.a; u.h += ev.h; u.m += ev.h;
    let bonus = 0;
    if (me.hp < s.P[op(seat)].hp) { u.a += 1; u.h += 1; u.m += 1; bonus = 1; }   // 역전 진화
    if (u.sk && !u.k.storm) u.er = 1;
    me.st.ev++;
    EV(s, ['e', u.u, u.a, u.h, bonus]);
    logp(s, pname(s, seat) + ': 「' + c.n + '」 진화!' + (bonus ? ' (역전 +1/+1)' : ''));
    runFx(s, seat, u, 'evo', ctx || {});
  }
  function doFx(s, seat, card, f, ctx) {
    const reps = f.x === 'cb' ? s.P[seat].cb : f.x === 'sp' ? Math.min(8, s.P[seat].sp) : (f.x || 1);
    for (let r = 0; r < reps; r++) {
      if (s.win != null) return;
      const ts = (f.d === 'dmg' || f.d === 'heal' || f.d === 'buff' || f.d === 'give' || f.d === 'kill' || f.d === 'bounce' || f.d === 'evof') ? resolveT(s, seat, card, f.g, ctx, f) : [];
      switch (f.d) {
        case 'dmg': ts.forEach((t) => dmgTo(s, t, f.n, seat, null)); if (f.g === 'efs' || f.g === 'alls') EV(s, ['aoe', seat]); break;
        case 'heal': ts.forEach((t) => healTo(s, t, f.n)); break;
        case 'draw': draw(s, seat, f.n); break;
        case 'sum': summon(s, seat, f.id, f.n); break;
        case 'add': addHand(s, seat, f.id, f.n); break;
        case 'buff': ts.forEach((t) => { const fu = findU(s, t); if (!fu) return; fu.u.a += f.a || 0; fu.u.h += f.h || 0; fu.u.m += f.h || 0; EV(s, ['bf', t, fu.u.a, fu.u.h]); }); break;
        case 'give': ts.forEach((t) => { const fu = findU(s, t); if (!fu) return; fu.u.k[f.k] = 1; EV(s, ['kw', t, f.k]); }); break;
        case 'kill': ts.forEach((t) => { const fu = findU(s, t); if (!fu) return; fu.u.h = 0; fu.u.kd = 1; EV(s, ['kill', t]); }); break;
        case 'bounce': ts.forEach((t) => { const fu = findU(s, t); if (!fu) return; s.P[fu.seat].bd.splice(fu.i, 1); EV(s, ['bn', t, fu.seat]); if (!CARDS[fu.u.id].tok && s.P[fu.seat].hd.length < HAND) addHand(s, fu.seat, fu.u.id, 1); }); break;
        case 'mpp': { const p = s.P[seat]; if (p.mp < MAXPP) { p.mp = Math.min(MAXPP, p.mp + f.n); EV(s, ['mpp', seat, p.mp]); } break; }
        case 'pp': { const p = s.P[seat]; p.pp = Math.min(p.mp, p.pp + f.n); break; }
        case 'ep': s.P[seat].ep += f.n; break;
        case 'hurt': dmgTo(s, 'L' + seat, f.n, null, null); break;
        case 'cdr': s.P[seat].bd.forEach((u) => { if (u.cd != null) { u.cd = Math.max(0, u.cd - f.n); EV(s, ['cd', u.u, u.cd]); } }); break;
        case 'soul': s.P[seat].so += f.n; EV(s, ['so', seat, f.n]); break;
        case 'evof': ts.forEach((t) => { const fu = findU(s, t); if (fu && !fu.u.e) evolve(s, fu.seat, fu.u, {}, 1); }); break;
      }
    }
  }
  // 쓰러진 추종자·끝난 마법진 정리(유언 연쇄)
  function reap(s) {
    for (let guard = 0; guard < 30; guard++) {
      let any = false;
      for (const seat of [s.cur, op(s.cur)]) {
        const p = s.P[seat];
        for (let i = 0; i < p.bd.length; i++) {
          const u = p.bd[i];
          const dead = isFol(u) ? u.h <= 0 : u.cd != null && u.cd <= 0;
          if (!dead) continue;
          p.bd.splice(i, 1); i--; any = true;
          EV(s, ['k', u.u, seat, u.id, isFol(u) ? 0 : 1]);
          if (isFol(u)) { p.so++; s.P[op(seat)].st.kills++; }
          runFx(s, seat, u, 'lw', {});
          if (s.win != null) return;
        }
      }
      if (!any) return;
    }
  }
  function checkEnd(s) {
    if (s.win != null) { s.ph = 'over'; return true; }
    return false;
  }

  function evoReady(s, seat) {
    const p = s.P[seat];
    return s.ph === 'play' && s.cur === seat && !p.evt && p.ep > 0 && p.own >= EVO_TURN[seat];
  }
  function canAttack(u) { return isFol(u) && !u.at && u.a > 0 && (!u.sk || u.k.storm || u.k.rush || u.er); }
  function attackTargets(s, seat, u) {
    if (!canAttack(u)) return [];
    const en = s.P[op(seat)];
    const vis = en.bd.filter((x) => isFol(x) && !x.k.amb);
    const wards = vis.filter((x) => x.k.ward);
    if (wards.length) return wards.map((x) => x.u);
    const out = vis.map((x) => x.u);
    if (!u.sk || u.k.storm) out.push('L' + op(seat));
    return out;
  }
  function chosenFor(s, seat, fxs, on, cbAdd) {
    const p = s.P[seat]; p.cb += cbAdd; let r = null;
    for (const f of fxs) if ((f.o || 'play') === on && CHOSEN[f.g] && condOk(s, seat, f.i)) { r = f; break; }
    p.cb -= cbAdd; return r;
  }
  function playable(s, seat, c) {
    const p = s.P[seat], cd = CARDS[c.id];
    if (s.ph !== 'play' || s.cur !== seat || cd.c > p.pp) return false;
    if (cd.t !== 's' && p.bd.length >= BOARD) return false;
    if (cd.t === 's') { const ch = chosenFor(s, seat, cd.fx, 'play', 1); if (ch && !targetable(s, seat, ch.g, ch.f).length) return false; }
    return true;
  }
  function playTargets(s, seat, c) {
    const ch = chosenFor(s, seat, CARDS[c.id].fx, 'play', 1);
    return ch ? targetable(s, seat, ch.g, ch.f) : null;
  }
  function evoTargets(s, seat, u) {
    const ch = chosenFor(s, seat, CARDS[u.id].fx, 'evo', 0);
    return ch ? targetable(s, seat, ch.g, ch.f, u.u) : null;
  }

  function startTurn(s, seat) {
    s.cur = seat; s.tn++;
    const p = s.P[seat];
    p.own++; p.mp = Math.min(MAXPP, p.mp + 1); p.pp = p.mp; p.evt = 0; p.cb = 0;
    p.bd.forEach((u) => { u.sk = 0; u.at = 0; u.er = 0; });
    EV(s, ['t', seat]);
    logp(s, '— ' + pname(s, seat) + '의 ' + p.own + '번째 턴 (PP ' + p.mp + ')');
    // 마법진 대기
    p.bd.forEach((u) => { if (u.cd != null) { u.cd--; EV(s, ['cd', u.u, u.cd]); } });
    reap(s); if (checkEnd(s)) return;
    p.bd.slice().forEach((u) => { if (findU(s, u.u)) runFx(s, seat, u, 'start', {}); });
    reap(s); if (checkEnd(s)) return;
    draw(s, seat, 1);
    checkEnd(s);
  }
  function endTurn(s) {
    const seat = s.cur, p = s.P[seat];
    p.bd.slice().forEach((u) => { if (findU(s, u.u)) runFx(s, seat, u, 'end', {}); });
    reap(s); if (checkEnd(s)) return;
    if (s.tn >= TURN_CAP) {
      const a = s.P[0].hp, b = s.P[1].hp;
      s.win = a > b ? 0 : b > a ? 1 : -1; s.why = 'cap'; s.ph = 'over';
      logp(s, '턴 제한! 리더 체력으로 승부를 가려요.'); return;
    }
    startTurn(s, op(seat));
  }

  function apply(s, seat, a) {
    s.last = { id: (s.last ? s.last.id : 0) + 1, ev: [], by: seat, t: a.t };
    if (!a || !a.t) throw new Error('bad action');
    if (s.ph === 'over') throw new Error('over');
    const p = s.P[seat];
    if (a.t === 'names') { throw new Error('bad'); }
    if (s.ph === 'pick') {
      if (p.ok) throw new Error('already');
      if (a.t === 'deck') {
        if (s.mode !== 'std') throw new Error('mode');
        let d = a.d;
        if (a.pre || !d) d = presetDeck(a.cl);
        if (!validDeck(a.cl, d)) throw new Error('bad deck');
        p.cl = a.cl; p.dk = d.slice(); p.ok = 1; p.dn = String(a.n || (CLS[a.cl].n + ' 기본')).slice(0, 16);
      } else if (a.t === 'dcl') {
        if (s.mode !== 'draft' || p.cl) throw new Error('bad');
        const cl = p.dr.co[a.k]; if (!cl) throw new Error('bad');
        p.cl = cl; draftOffer(s, p);
      } else if (a.t === 'dp') {
        if (s.mode !== 'draft' || !p.cl) throw new Error('bad');
        const id = p.dr.off[a.k]; if (!id) throw new Error('bad');
        p.dr.pk.push(id); p.dk.push(id, id);
        if (p.dr.pk.length >= DRAFT_PICKS) { p.ok = 1; p.dn = '드래프트 덱'; p.dr.off = []; }
        else draftOffer(s, p);
      } else throw new Error('bad');
      if (s.P[0].ok && s.P[1].ok) startMatch(s);
      return s;
    }
    if (s.ph === 'mull') {
      if (a.t !== 'mull' || p.mu) throw new Error('bad');
      const sw = (a.sw || []).filter((u, i, arr) => arr.indexOf(u) === i && p.hd.some((c) => c.u === u));
      const back = [];
      sw.forEach((u) => { const i = p.hd.findIndex((c) => c.u === u); back.push(p.hd[i].id); p.hd.splice(i, 1); });
      for (let i = 0; i < back.length; i++) drawRaw(s, seat);
      p.dk = shuffle(p.dk.concat(back));
      p.mu = 1; p.msw = back.length;
      if (s.P[0].mu && s.P[1].mu) { s.ph = 'play'; logp(s, '대전 시작! ' + pname(s, 0) + ' 선공'); startTurn(s, 0); }
      return s;
    }
    if (s.cur !== seat) throw new Error('not your turn');
    if (a.t === 'end') { EV(s, ['end', seat]); endTurn(s); return s; }
    if (a.t === 'play') {
      const hi = p.hd.findIndex((c) => c.u === a.u); if (hi < 0) throw new Error('no card');
      const c = p.hd[hi], cd = CARDS[c.id];
      if (!playable(s, seat, c)) throw new Error('cannot play');
      const tl = playTargets(s, seat, c);
      let tg = null;
      if (tl && tl.length) { if (!tl.includes(a.tg)) throw new Error('bad target'); tg = a.tg; }
      p.pp -= cd.c; p.hd.splice(hi, 1); p.cb++; p.st.pl++;
      if (cd.c >= 7) p.st.big++;
      if (cd.t === 's') {
        p.sp++; if (c.id === 'g_t') p.pc++;
        EV(s, ['s', seat, c.id, c.u, tg]);
        logp(s, pname(s, seat) + ': 주문 「' + cd.n + '」');
        runFx(s, seat, c, 'play', { tgt: tg });
        reap(s); if (checkEnd(s)) return s;
        p.bd.slice().forEach((u) => { if (findU(s, u.u)) runFx(s, seat, u, 'spell', {}); });
      } else {
        const u = mkUnit(s, c.id); u.u = c.u;
        const pos = Math.max(0, Math.min(p.bd.length, a.pos == null ? p.bd.length : a.pos));
        p.bd.splice(pos, 0, u);
        EV(s, ['p', seat, u.u, c.id, tg]);
        logp(s, pname(s, seat) + ': 「' + cd.n + '」' + (cd.t === 'a' ? ' 마법진' : ''));
        allyTrig(s, seat, u);
        runFx(s, seat, u, 'play', { tgt: tg });
      }
      reap(s); checkEnd(s); return s;
    }
    if (a.t === 'atk') {
      const fu = findU(s, a.u); if (!fu || fu.seat !== seat) throw new Error('no unit');
      const u = fu.u;
      const tl = attackTargets(s, seat, u); if (!tl.includes(a.tg)) throw new Error('bad target');
      u.at = 1; if (u.k.amb) { delete u.k.amb; EV(s, ['kw-', u.u, 'amb']); }
      EV(s, ['a', u.u, a.tg]);
      runFx(s, seat, u, 'atk', {});
      if (findU(s, u.u) && u.h > 0) {
        if (typeof a.tg === 'string') {
          const n = dmgTo(s, a.tg, u.a, seat, u);
          if (u.k.drain) healTo(s, 'L' + seat, n);
          logp(s, pname(s, seat) + ': 「' + CARDS[u.id].n + '」 → 리더 ' + n + ' 피해');
        } else {
          const tf = findU(s, a.tg);
          if (tf) {
            const t = tf.u, da = u.a, db = t.a;
            dmgTo(s, t.u, da, seat, u);
            dmgTo(s, u.u, db, op(seat), t);
            if (u.k.drain) healTo(s, 'L' + seat, da);
            logp(s, pname(s, seat) + ': 「' + CARDS[u.id].n + '」 ⚔ 「' + CARDS[t.id].n + '」');
          }
        }
      }
      reap(s); checkEnd(s); return s;
    }
    if (a.t === 'evo') {
      const fu = findU(s, a.u); if (!fu || fu.seat !== seat || !isFol(fu.u) || fu.u.e) throw new Error('no unit');
      if (!evoReady(s, seat)) throw new Error('cannot evolve');
      const tl = evoTargets(s, seat, fu.u);
      let tg = null;
      if (tl && tl.length) { if (!tl.includes(a.tg)) throw new Error('bad target'); tg = a.tg; }
      p.ep--; p.evt = 1;
      evolve(s, seat, fu.u, { tgt: tg });
      reap(s); checkEnd(s); return s;
    }
    throw new Error('unknown action');
  }

  function result(s) {
    if (s.win == null) return null;
    const why = { hp: '리더 체력 0', deck: '덱 소진', cap: '턴 제한 · 체력 비교' }[s.why] || '';
    const stats = [
      { label: '직업', values: s.P.map((p) => CLS[p.cl] ? CLS[p.cl].n : '-') },
      { label: '남은 리더 체력', values: s.P.map((p) => Math.max(0, p.hp)) },
      { label: '낸 카드', values: s.P.map((p) => p.st.pl) },
      { label: '리더에게 준 피해', values: s.P.map((p) => p.st.fd) },
      { label: '쓰러뜨린 추종자', values: s.P.map((p) => p.st.kills) },
      { label: '진화', values: s.P.map((p) => p.st.ev) },
    ];
    if (s.win === -1) return { winners: [], title: '무승부', text: why, stats };
    const w = s.P[s.win];
    const hl = [];
    if (w.hp <= 5) hl.push('체력 ' + Math.max(0, w.hp) + '에서 버틴 아슬아슬한 승리');
    if (s.P[s.win].st.ev >= 2) hl.push('진화 ' + w.st.ev + '번으로 판을 뒤집었어요');
    hl.push(s.tn + '턴 만에 결판');
    return { winners: [s.win], text: why + ' · ' + (CLS[w.cl] ? CLS[w.cl].n : ''), stats, highlights: hl };
  }

  /* ───────── AI ───────── */
  function legal(s, seat) {
    const out = [], p = s.P[seat];
    p.hd.forEach((c) => {
      if (!playable(s, seat, c)) return;
      const tl = playTargets(s, seat, c);
      if (tl && tl.length) tl.forEach((t) => out.push({ t: 'play', u: c.u, tg: t }));
      else out.push({ t: 'play', u: c.u });
    });
    p.bd.forEach((u) => attackTargets(s, seat, u).forEach((t) => out.push({ t: 'atk', u: u.u, tg: t })));
    if (evoReady(s, seat)) p.bd.forEach((u) => {
      if (!isFol(u) || u.e) return;
      const tl = evoTargets(s, seat, u);
      if (tl && tl.length) tl.forEach((t) => out.push({ t: 'evo', u: u.u, tg: t }));
      else out.push({ t: 'evo', u: u.u });
    });
    out.push({ t: 'end' });
    return out;
  }
  const KWV = { ward: 1.2, bane: 2.2, drain: 0.8, amb: 1.0, storm: 0.3, rush: 0.2 };
  function unitV(u, mine, s, seat) {
    const c = CARDS[u.id];
    if (c.t === 'a') return 2.5 + c.fx.length * 0.8 - (u.cd || 0) * 0.25;
    let v = u.a * 1.0 + u.h * 0.85 + (u.a > 0 ? 0.6 : 0);
    for (const k in u.k) v += KWV[k] || 0;
    if (u.k.ward) v += u.h * 0.12;
    if (u.k.drain) v += u.a * 0.3;
    if (c.fx.some((f) => f.o === 'end' || f.o === 'start' || f.o === 'spell' || f.o === 'ally')) v += 1.8;
    if (c.fx.some((f) => f.o === 'lw')) v += 1.2;
    return v;
  }
  function hpv(h) { return h <= 0 ? -1e5 : h * 0.9 + Math.min(h, 12) * 0.75 + Math.min(h, 5) * 0.8; }
  function evalS(s, me) {
    if (s.win === me) return 1e6;
    if (s.win === op(me)) return -1e6;
    if (s.win === -1) return 0;
    const P = s.P[me], E = s.P[op(me)];
    let v = hpv(P.hp) - hpv(E.hp) * 1.05;
    let mb = 0, eb = 0;
    P.bd.forEach((u) => { mb += unitV(u, 1, s, me); });
    E.bd.forEach((u) => { eb += unitV(u, 0, s, me); });
    v += mb - eb * 1.08;
    v += Math.min(P.hd.length, 8) * 0.75 - Math.min(E.hd.length, 8) * 0.5;
    v += P.ep * 1.1 - E.ep * 0.9;
    v += P.so * 0.25 + Math.min(P.pc, 10) * 0.2 + Math.min(P.sp, 10) * 0.12 + P.mp * 0.15;
    // 다음 상대 턴 위협
    const myW = P.bd.filter((u) => isFol(u) && u.k.ward && !u.k.amb);
    let ePot = 0; E.bd.forEach((u) => { if (isFol(u)) ePot += u.a; });
    if (myW.length) { let wh = 0; myW.forEach((u) => { wh += u.h; }); ePot = Math.max(0, ePot - wh * 0.8); }
    if (ePot >= P.hp) v -= 40; else v -= Math.max(0, ePot - P.hp + 7) * 1.6;
    // 내 다음 턴 마무리 가능성
    const eW = E.bd.some((u) => isFol(u) && u.k.ward && !u.k.amb);
    if (!eW) { let mp = 0; P.bd.forEach((u) => { if (isFol(u)) mp += u.a; }); if (mp >= E.hp) v += 14; else v += Math.max(0, mp - E.hp + 6) * 0.8; }
    return v;
  }
  function sim(s, seat, a) {
    const t = JSON.parse(JSON.stringify(s));
    try { apply(t, seat, a); } catch (e) { return null; }
    t.log = [];
    return t;
  }
  function greedyPick(s, seat, noise, attacksOnly) {
    const base = evalS(s, seat);
    let best = null, bv = base + 0.25;
    for (const a of legal(s, seat)) {
      if (a.t === 'end') continue;
      if (attacksOnly && a.t !== 'atk') continue;
      const t = sim(s, seat, a); if (!t) continue;
      let v = evalS(t, seat);
      if (noise) v += (Math.random() - 0.5) * noise;
      if (v > bv) { bv = v; best = a; }
    }
    return best;
  }
  function rollout(s, seat, steps) {
    let t = s;
    for (let i = 0; i < steps && t.win == null; i++) {
      const a = greedyPick(t, seat, 0, false); if (!a) break;
      const n = sim(t, seat, a); if (!n) break; t = n;
    }
    return t;
  }
  // 어려움: 내 턴 끝 → 상대가 공격만으로 얼마나 해낼지까지 본다
  function replyEval(t, seat) {
    if (t.win != null) return evalS(t, seat);
    const e = sim(t, seat, { t: 'end' }); if (!e) return evalS(t, seat);
    if (e.win != null) return evalS(e, seat);
    const o = op(seat);
    let x = e;
    for (let i = 0; i < 6 && x.win == null && x.cur === o; i++) {
      const a = greedyPick(x, o, 0, true); if (!a) break;
      const n = sim(x, o, a); if (!n) break; x = n;
    }
    return evalS(x, seat) * 0.55 + evalS(t, seat) * 0.45;
  }
  function aiPlay(s, seat, lv) {
    s.log = [];
    const acts = legal(s, seat);
    if (acts.length === 1) return acts[0];
    if (lv <= 1) {
      if (Math.random() < 0.12) return { t: 'end' };
      if (Math.random() < 0.3) { const nz = acts.filter((a) => a.t !== 'end' && a.t !== 'evo'); if (nz.length) return nz[rnd(nz.length)]; }
      return greedyPick(s, seat, 4.5, false) || { t: 'end' };
    }
    if (lv === 2) return greedyPick(s, seat, 0.6, false) || { t: 'end' };
    // 어려움: 한 수씩 평가 → 상위 후보만 그 턴 끝까지 굴려 보고, 상대 반격까지 본다
    const t0 = Date.now();
    const sc = [];
    for (const a of acts) {
      if (a.t === 'end') continue;
      const t = sim(s, seat, a); if (!t) continue;
      if (t.win === seat) return a;   // 바로 이김
      sc.push([evalS(t, seat), a, t]);
    }
    sc.sort((x, y) => y[0] - x[0]);
    let best = { t: 'end' }, bv = replyEval(s, seat) + 0.3;
    const K = Math.min(sc.length, 14);
    for (let i = 0; i < K; i++) {
      if (Date.now() - t0 > 240 && i > 2) break;
      const fin = rollout(sc[i][2], seat, 7);
      const v = fin.win === seat ? 1e6 : replyEval(fin, seat);
      if (v > bv) { bv = v; best = sc[i][1]; }
    }
    return best;
  }
  function aiMull(s, seat, lv) {
    const p = s.P[seat];
    if (lv <= 1) return { t: 'mull', sw: p.hd.filter(() => Math.random() < 0.25).map((c) => c.u) };
    const cheap = p.hd.filter((c) => CARDS[c.id].c <= 3).length;
    return { t: 'mull', sw: p.hd.filter((c) => CARDS[c.id].c >= (cheap >= 2 ? 5 : 4)).map((c) => c.u) };
  }
  const CURVE = { 1: 2, 2: 4, 3: 4, 4: 3, 5: 3, 6: 2, 7: 2 };
  function aiDraftPick(s, seat, lv) {
    const p = s.P[seat];
    if (lv <= 1) return { t: 'dp', k: rnd(p.dr.off.length) };
    const cnt = {}; p.dr.pk.forEach((id) => { const b = Math.min(7, Math.max(1, CARDS[id].c)); cnt[b] = (cnt[b] || 0) + 1; });
    let bk = 0, bv = -1e9;
    p.dr.off.forEach((id, k) => {
      const b = Math.min(7, Math.max(1, CARDS[id].c));
      let v = cardScore(id) + ((cnt[b] || 0) < CURVE[b] ? 1.5 : -1) + (lv >= 3 ? 0 : Math.random() * 1.5);
      if (v > bv) { bv = v; bk = k; }
    });
    return { t: 'dp', k: bk };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'pick') {
      const p = s.P[seat];
      if (s.mode === 'draft') {
        if (!p.cl) return { t: 'dcl', k: rnd(3) };
        return aiDraftPick(s, seat, lv);
      }
      const cl = (s.forceCl && s.forceCl[seat]) || CL_ORDER[rnd(CL_ORDER.length)];
      return { t: 'deck', cl, pre: 1 };
    }
    if (s.ph === 'mull') return aiMull(s, seat, lv);
    return aiPlay(s, seat, lv);
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'pick') return 60;
    if (s.ph === 'mull') return 500;
    return lv >= 3 ? 650 : 800;
  }

  function forcePick(s) {
    s.P.forEach((p) => {
      if (p.ok) return;
      if (s.mode === 'draft') {
        if (!p.cl) { p.cl = p.dr.co[rnd(3)]; draftOffer(s, p); }
        while (p.dr.pk.length < DRAFT_PICKS) { const id = p.dr.off[rnd(p.dr.off.length)]; p.dr.pk.push(id); p.dk.push(id, id); draftOffer(s, p); }
        p.dr.off = []; p.ok = 1; p.dn = '드래프트 덱';
      } else { p.cl = CL_ORDER[rnd(8)]; p.dk = presetDeck(p.cl); p.ok = 1; p.dn = CLS[p.cl].n + ' 기본'; }
    });
    if (s.ph === 'pick') startMatch(s);
    return s;
  }

  /* ───────── 카드 글(데이터에서 자동 생성) ───────── */
  const TG = { ef: '적 추종자 하나', e: '적 하나(추종자·리더)', af: '내 추종자 하나', f: '추종자 하나', tgt: '그 대상', self: '이 추종자', me: '내 리더', eL: '적 리더',
    efs: '적 추종자 모두', afs: '내 추종자 모두', oth: '다른 내 추종자 모두', alls: '모든 추종자', ref: '무작위 적 추종자 하나', raf: '무작위 내 추종자 하나', re: '무작위 적 하나' };
  const ON = { play: '등장', lw: '유언', evo: '진화 시', atk: '공격할 때', start: '내 턴 시작에', end: '내 턴 끝에', spell: '공명', ally: '내 추종자가 나올 때' };
  function condName(i) {
    if (!i) return '';
    const neg = i[0] === '!'; const c = neg ? i.slice(1) : i;
    let t = c.startsWith('cb') ? '연계 ' + c.slice(2) : c === 'th' ? '갈증' : c === 'ov' ? '각성' : c.startsWith('so') ? '넋 ' + c.slice(2) + ' 소모' : c.startsWith('sp') ? '주문 ' + c.slice(2) : c.startsWith('pt') ? '부품 ' + c.slice(2) : c;
    return neg ? t + '이 아니면' : t;
  }
  function fxPhrase(f, cd) {
    let T = TG[f.g] || '';
    if (f.f) T = (f.f.w ? '수호를 가진 ' : f.f.mx != null ? '공격력 ' + f.f.mx + ' 이하인 ' : '공격력 ' + f.f.mn + ' 이상인 ') + T;
    if (cd && cd.t === 'f' && f.g === 'af' && f.o === 'evo') T = '다른 내 추종자 하나';
    const rep = f.x === 'cb' ? ' (이번 턴 낸 카드 수만큼)' : f.x === 'sp' ? ' (쓴 주문 수만큼, 최대 8번)' : f.x > 1 ? ' ×' + f.x + '번' : '';
    const nm = (id) => '「' + CARDS[id].n + '」' + (CARDS[id].t === 'f' ? '(' + CARDS[id].a + '/' + CARDS[id].h + (Object.keys(CARDS[id].k).length ? ' ' + Object.keys(CARDS[id].k).map((k) => KW[k].n).join('·') : '') + ')' : '');
    switch (f.d) {
      case 'dmg': return T + '에게 ' + f.n + ' 피해' + rep;
      case 'heal': return T + ' 체력 ' + f.n + ' 회복';
      case 'draw': return '카드 ' + f.n + '장 뽑기';
      case 'sum': return nm(f.id) + ' ' + f.n + '마리 소환';
      case 'add': return nm(f.id) + ' ' + f.n + '장을 손에 넣기';
      case 'buff': return T + ' +' + (f.a || 0) + '/+' + (f.h || 0);
      case 'give': return T + '에게 ' + KW[f.k].n + ' 부여';
      case 'kill': return T + ' 파괴';
      case 'bounce': return T + '을(를) 손으로 되돌리기';
      case 'mpp': return '최대 PP +' + f.n;
      case 'pp': return 'PP ' + f.n + ' 회복';
      case 'ep': return '진화 포인트 +' + f.n;
      case 'hurt': return '내 리더에게 ' + f.n + ' 피해';
      case 'cdr': return '내 마법진 대기 −' + f.n;
      case 'soul': return '넋 +' + f.n;
      case 'evof': return T + ' 진화(포인트 없이)';
    }
    return '';
  }
  const TXT = {};
  function cardText(id) {
    if (TXT[id]) return TXT[id];
    const cd = CARDS[id], out = [];
    const kws = Object.keys(cd.k).map((k) => KW[k].n);
    if (kws.length) out.push(kws.join(' · '));
    if (cd.t === 'a' && cd.cdn) out.push('대기 ' + cd.cdn);
    const groups = [];
    cd.fx.forEach((f) => {
      const on = f.o || 'play', key = on + '|' + (f.i || '');
      let g = groups.find((x) => x.key === key && x === groups[groups.length - 1]);
      if (!g) { g = { key, on, i: f.i, ps: [] }; groups.push(g); }
      g.ps.push(fxPhrase(f, cd));
    });
    groups.forEach((g) => {
      let pre = cd.t === 's' && g.on === 'play' ? '' : (ON[g.on] || '') + ': ';
      if (cd.t === 'a' && g.on === 'play') pre = '';
      const cn = condName(g.i);
      out.push(pre + (cn ? cn + ' → ' : '') + g.ps.join(', ') + '.');
    });
    if (cd.t === 'f') { const ev = cd.ev || { a: 2, h: 2 }; if (ev.a !== 2 || ev.h !== 2) out.push('(진화하면 +' + ev.a + '/+' + ev.h + ')'); }
    TXT[id] = out;
    return out;
  }
  function cardKeys(id) {   // 이 카드에 나오는 용어 풀이
    const cd = CARDS[id], set = [];
    Object.keys(cd.k).forEach((k) => set.push([KW[k].n, KW[k].d]));
    cd.fx.forEach((f) => {
      const on = f.o || 'play';
      const t = TERMS.find((x) => x[0] === ON[on]); if (t && !set.some((y) => y[0] === t[0])) set.push(t);
      if (f.i) { const nm = condName(f.i).replace(/ \d+.*$/, '').replace('이 아니면', ''); const tt = TERMS.find((x) => x[0].startsWith(nm)); if (tt && !set.some((y) => y[0] === tt[0])) set.push(tt); }
      if (f.d === 'give' && !set.some((y) => y[0] === KW[f.k].n)) set.push([KW[f.k].n, KW[f.k].d]);
      if ((f.d === 'sum' || f.d === 'add') && CARDS[f.id]) set.push(['「' + CARDS[f.id].n + '」', (CARDS[f.id].t === 'f' ? CARDS[f.id].a + '/' + CARDS[f.id].h + ' 추종자. ' : CARDS[f.id].c + '코스트 주문. ') + cardText(f.id).join(' ')]);
    });
    if (cd.t === 'a') { const t = TERMS.find((x) => x[0].startsWith('마법진')); set.push(t); }
    return set;
  }
  const TYPE_N = { f: '추종자', s: '주문', a: '마법진' };
  const RAR = ['', '일반', '고급', '희귀', '전설'];

  /* ───────── 그리기 도우미 ───────── */
  const FONT_D = '"Black Han Sans", "IBM Plex Sans KR", sans-serif', FONT_B = '"IBM Plex Sans KR", "Malgun Gothic", sans-serif', FONT_M = '"IBM Plex Mono", ui-monospace, monospace';
  function hash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function hueRot(hex, deg) {
    const n = parseInt(hex.slice(1), 16); let r = (n >> 16) / 255, g = ((n >> 8) & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2;
    if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; }
    return 'hsl(' + ((h + deg + 360) % 360).toFixed(0) + ',' + (s * 100).toFixed(0) + '%,' + (l * 100).toFixed(0) + '%)';
  }
  function emblem(ctx, em, cx, cy, r, col) {
    ctx.save(); ctx.translate(cx, cy); ctx.fillStyle = col; ctx.strokeStyle = col; ctx.lineWidth = Math.max(1, r * 0.14); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath();
    if (em === 'sword') { ctx.moveTo(0, -r); ctx.lineTo(r * 0.16, -r * 0.2); ctx.lineTo(r * 0.16, r * 0.45); ctx.lineTo(-r * 0.16, r * 0.45); ctx.lineTo(-r * 0.16, -r * 0.2); ctx.closePath(); ctx.fill(); ctx.fillRect(-r * 0.55, r * 0.42, r * 1.1, r * 0.16); ctx.fillRect(-r * 0.1, r * 0.55, r * 0.2, r * 0.4); }
    else if (em === 'leaf') { ctx.moveTo(0, -r); ctx.quadraticCurveTo(r * 0.95, -r * 0.1, 0, r); ctx.quadraticCurveTo(-r * 0.95, -r * 0.1, 0, -r); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.moveTo(0, -r * 0.7); ctx.lineTo(0, r * 0.95); ctx.stroke(); }
    else if (em === 'star') { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr2 = i % 2 ? r * 0.42 : r; ctx.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); } ctx.closePath(); ctx.fill(); }
    else if (em === 'wing') { ctx.moveTo(-r * 0.1, r * 0.6); ctx.quadraticCurveTo(-r, r * 0.1, -r * 0.9, -r * 0.9); ctx.quadraticCurveTo(-r * 0.4, -r * 0.3, 0, -r * 0.2); ctx.quadraticCurveTo(r * 0.4, -r * 0.3, r * 0.9, -r * 0.9); ctx.quadraticCurveTo(r, r * 0.1, r * 0.1, r * 0.6); ctx.closePath(); ctx.fill(); }
    else if (em === 'skull') { ctx.arc(0, -r * 0.15, r * 0.72, 0, Math.PI * 2); ctx.fill(); ctx.fillRect(-r * 0.42, r * 0.3, r * 0.84, r * 0.55); ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.beginPath(); ctx.arc(-r * 0.28, -r * 0.15, r * 0.18, 0, 7); ctx.arc(r * 0.28, -r * 0.15, r * 0.18, 0, 7); ctx.fill(); }
    else if (em === 'fang') { ctx.moveTo(-r * 0.8, -r * 0.6); ctx.lineTo(r * 0.8, -r * 0.6); ctx.lineTo(r * 0.45, -r * 0.2); ctx.lineTo(r * 0.3, r); ctx.lineTo(r * 0.12, -r * 0.2); ctx.lineTo(-r * 0.12, -r * 0.2); ctx.lineTo(-r * 0.3, r); ctx.lineTo(-r * 0.45, -r * 0.2); ctx.closePath(); ctx.fill(); }
    else if (em === 'sun') { ctx.arc(0, 0, r * 0.45, 0, 7); ctx.fill(); for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r * 0.6, Math.sin(a) * r * 0.6); ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); ctx.stroke(); } }
    else if (em === 'gear') { for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8, rr2 = i % 2 ? r * 0.72 : r; ctx.lineTo(Math.cos(a) * rr2, Math.sin(a) * rr2); } ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.beginPath(); ctx.arc(0, 0, r * 0.3, 0, 7); ctx.fill(); }
    else { ctx.moveTo(0, -r); ctx.lineTo(r * 0.75, 0); ctx.lineTo(0, r); ctx.lineTo(-r * 0.75, 0); ctx.closePath(); ctx.fill(); }
    ctx.restore();
  }

  /* 그림: img/cardduel/<id>.webp 가 있으면 쓰고, 없으면 자리 그림 */
  const IMG = {};
  let onArt = null;
  function artImg(id) {
    let e = IMG[id];
    if (!e) {
      e = IMG[id] = { ok: false, img: null };
      if (typeof Image !== 'undefined' && ART[id] && (ART_ALL || ART_READY.has(id)) && !(L.debug && L.debug.noArt)) {
        const im = new Image(); im.onload = () => { e.ok = true; e.img = im; if (onArt) onArt(); }; im.onerror = () => { e.ok = false; }; im.src = ART[id];
      }
    }
    return e.ok ? e.img : null;
  }
  const ARTC = new Map();
  function drawArt(ctx, id, x, y, w, h) {
    const im = artImg(id);
    if (im) {
      const s = Math.max(w / im.width, h / im.height), sw = w / s, sh = h / s;
      ctx.drawImage(im, (im.width - sw) / 2, (im.height - sh) * 0.35, sw, sh, x, y, w, h); return;
    }
    const key = id + '|' + Math.round(w) + 'x' + Math.round(h);
    let c = ARTC.get(key);
    if (!c && typeof document !== 'undefined') {
      c = document.createElement('canvas'); const dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = Math.max(1, Math.round(w * dpr)); c.height = Math.max(1, Math.round(h * dpr));
      const g = c.getContext('2d'); g.scale(dpr, dpr); placeholder(g, id, w, h);
      if (ARTC.size > 700) ARTC.clear();
      ARTC.set(key, c);
    }
    if (c) ctx.drawImage(c, x, y, w, h);
  }
  function placeholder(g, id, w, h) {
    const cd = CARDS[id] || { cl: id.replace('leader_', '')[0], t: 'f' }, cls = CLS[cd.cl] || CLS.x, hs = hash(id);
    const hue = ((hs % 50) - 25);
    const bg = g.createLinearGradient(0, 0, w * 0.3, h);
    bg.addColorStop(0, hueRot(cls.hi, hue)); bg.addColorStop(0.55, hueRot(cls.col, hue)); bg.addColorStop(1, shade(cls.col, -0.65));
    g.fillStyle = bg; g.fillRect(0, 0, w, h);
    // 빛줄기
    g.save(); g.globalAlpha = 0.18; g.fillStyle = '#fff';
    for (let i = 0; i < 3; i++) { const sx = ((hs >> (i * 5)) % 100) / 100 * w; g.beginPath(); g.moveTo(sx, 0); g.lineTo(sx + w * 0.18, 0); g.lineTo(sx - w * 0.3, h); g.lineTo(sx - w * 0.42, h); g.closePath(); g.fill(); }
    g.restore();
    emblem(g, cls.em, w * 0.78, h * 0.25, Math.min(w, h) * 0.22, 'rgba(255,255,255,.14)');
    const ink = 'rgba(15,10,25,.62)', rim = 'rgba(255,245,220,.55)';
    g.save();
    if (cd.t === 's') {
      const cx = w / 2, cy = h * 0.55, r = Math.min(w, h) * 0.36;
      g.strokeStyle = rim; g.lineWidth = Math.max(1, r * 0.07);
      g.beginPath(); g.arc(cx, cy, r, 0, 7); g.stroke(); g.beginPath(); g.arc(cx, cy, r * 0.68, 0, 7); g.stroke();
      const n = 5 + (hs % 3); g.beginPath();
      for (let i = 0; i <= n; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / n * 2; g.lineTo(cx + Math.cos(a) * r * 0.68, cy + Math.sin(a) * r * 0.68); } g.stroke();
      g.fillStyle = 'rgba(255,255,255,.75)'; g.beginPath(); g.arc(cx, cy, r * 0.16, 0, 7); g.fill();
    } else if (cd.t === 'a') {
      const cx = w / 2, cy = h * 0.55, r = Math.min(w, h) * 0.36;
      g.fillStyle = ink; g.beginPath(); for (let i = 0; i < 6; i++) { const a = i * Math.PI / 3 + Math.PI / 6; g.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } g.closePath(); g.fill();
      g.strokeStyle = rim; g.lineWidth = Math.max(1, r * 0.06); g.stroke();
      emblem(g, cls.em, cx, cy, r * 0.5, 'rgba(255,240,200,.7)');
    } else {
      // 인물 실루엣(머리·어깨) + 테두리 빛
      const cx = w * (0.42 + ((hs >> 3) % 20) / 100), base = h, hr = Math.min(w, h) * (0.17 + ((hs >> 7) % 6) / 100);
      const hy = h * 0.45;
      g.fillStyle = ink; g.strokeStyle = rim; g.lineWidth = Math.max(1, hr * 0.12);
      g.beginPath(); g.moveTo(cx - hr * 2.5, base); g.quadraticCurveTo(cx - hr * 2.2, hy + hr * 1.3, cx, hy + hr * 1.05); g.quadraticCurveTo(cx + hr * 2.2, hy + hr * 1.3, cx + hr * 2.5, base); g.closePath(); g.fill(); g.stroke();
      g.beginPath(); g.arc(cx, hy, hr, 0, 7); g.fill(); g.stroke();
      // 무기·뿔 같은 표지(카드마다 다르게)
      const m = hs % 4; g.strokeStyle = rim; g.lineWidth = Math.max(1, hr * 0.18);
      g.beginPath();
      if (m === 0) { g.moveTo(cx + hr * 1.6, base - hr * 0.3); g.lineTo(cx + hr * 2.4, hy - hr * 1.6); }
      else if (m === 1) { g.moveTo(cx - hr * 0.6, hy - hr * 0.7); g.lineTo(cx - hr * 0.95, hy - hr * 1.6); g.moveTo(cx + hr * 0.6, hy - hr * 0.7); g.lineTo(cx + hr * 0.95, hy - hr * 1.6); }
      else if (m === 2) { g.arc(cx, hy - hr * 0.2, hr * 1.45, Math.PI * 1.15, Math.PI * 1.85); }
      else { g.moveTo(cx - hr * 2.2, hy - hr * 0.2); g.lineTo(cx - hr * 1.6, base - hr * 0.2); }
      g.stroke();
      g.fillStyle = 'rgba(255,240,210,.85)'; g.beginPath(); g.arc(cx - hr * 0.35, hy - hr * 0.05, hr * 0.12, 0, 7); g.arc(cx + hr * 0.35, hy - hr * 0.05, hr * 0.12, 0, 7); g.fill();
    }
    g.restore();
    const vg = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.75);
    vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.5)'); g.fillStyle = vg; g.fillRect(0, 0, w, h);
  }

  function wrapLines(ctx, text, maxW) {
    const out = []; let line = '';
    const words = text.split(/(\s+)/);
    for (const wd of words) {
      if (!wd) continue;
      const t = line + wd;
      if (ctx.measureText(t).width <= maxW || !line) {
        if (ctx.measureText(t).width > maxW) {   // 긴 낱말은 글자 단위로
          for (const ch of wd) { if (ctx.measureText(line + ch).width > maxW && line) { out.push(line); line = ch.trim() ? ch : ''; } else line += ch; }
        } else line = t;
      } else { out.push(line.trimEnd()); line = wd.trim() ? wd : ''; }
    }
    if (line.trim()) out.push(line.trimEnd());
    return out;
  }
  function gem(ctx, cx, cy, r, txt, fill, ink) {
    ctx.save();
    const g = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.35, r * 0.1, cx, cy, r);
    g.addColorStop(0, shade(fill, 0.45)); g.addColorStop(1, shade(fill, -0.35));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
    ctx.lineWidth = Math.max(1, r * 0.14); ctx.strokeStyle = 'rgba(20,12,8,.8)'; ctx.stroke();
    ctx.fillStyle = ink || '#fff'; ctx.font = 'bold ' + Math.round(r * 1.25) + 'px ' + FONT_M; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.lineWidth = Math.max(2, r * 0.3); ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.strokeText(txt, cx, cy + r * 0.06); ctx.fillText(txt, cx, cy + r * 0.06);
    ctx.restore();
  }
  function statBadge(ctx, cx, cy, r, v, base, kind) {
    const col = kind === 'a' ? '#d9a02c' : '#c23a3a';
    ctx.save();
    ctx.beginPath();
    if (kind === 'a') { ctx.moveTo(cx, cy - r); ctx.lineTo(cx + r, cy); ctx.lineTo(cx, cy + r); ctx.lineTo(cx - r, cy); ctx.closePath(); }
    else { ctx.moveTo(cx, cy + r); ctx.bezierCurveTo(cx - r * 1.3, cy, cx - r * 0.8, cy - r * 1.05, cx, cy - r * 0.55); ctx.bezierCurveTo(cx + r * 0.8, cy - r * 1.05, cx + r * 1.3, cy, cx, cy + r); }
    const g = ctx.createLinearGradient(cx, cy - r, cx, cy + r); g.addColorStop(0, shade(col, 0.35)); g.addColorStop(1, shade(col, -0.3));
    ctx.fillStyle = g; ctx.fill(); ctx.lineWidth = Math.max(1, r * 0.13); ctx.strokeStyle = 'rgba(20,10,5,.85)'; ctx.stroke();
    const up = v > base, dn = v < base;
    ctx.fillStyle = up ? '#a8ff8a' : dn && kind === 'h' ? '#ffd0d0' : '#fff';
    ctx.font = 'bold ' + Math.round(r * 1.18) + 'px ' + FONT_M; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.lineWidth = Math.max(2, r * 0.3); ctx.strokeStyle = 'rgba(0,0,0,.8)'; ctx.strokeText(String(v), cx, cy + r * 0.05); ctx.fillText(String(v), cx, cy + r * 0.05);
    ctx.restore();
  }
  /* 손패·도감용 카드(세로 5:7) */
  function drawCard(ctx, id, x, y, w, h, o) {
    o = o || {};
    const cd = CARDS[id], cls = CLS[cd.cl] || CLS.x, R = w * 0.07;
    ctx.save();
    if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = w * 0.18; }
    else { ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = w * 0.08; ctx.shadowOffsetY = w * 0.03; }
    const fr = ctx.createLinearGradient(x, y, x + w, y + h);
    const rimC = cd.r >= 4 ? ['#fff2b8', '#c9952a', '#7a5212'] : cd.r === 3 ? ['#e9d6ff', '#9a7ad0', '#4a3070'] : cd.r === 2 ? ['#e8eef5', '#9aa6b5', '#4b5563'] : ['#e0c9a0', '#9a7a4a', '#5a4020'];
    fr.addColorStop(0, rimC[0]); fr.addColorStop(0.5, rimC[1]); fr.addColorStop(1, rimC[2]);
    rr(ctx, x, y, w, h, R); ctx.fillStyle = fr; ctx.fill();
    ctx.restore();
    ctx.save();
    const b = Math.max(1.5, w * 0.035);
    rr(ctx, x + b, y + b, w - 2 * b, h - 2 * b, R * 0.8); ctx.fillStyle = shade(cls.col, -0.62); ctx.fill();
    // 그림 칸
    const ax = x + b * 1.6, ay = y + b * 1.6, aw = w - b * 3.2, ah = h * (o.full ? 0.48 : 0.6);
    ctx.save(); rr(ctx, ax, ay, aw, ah, R * 0.6); ctx.clip();
    if (cd.t === 'a') { ctx.beginPath(); }
    drawArt(ctx, id, ax, ay, aw, ah);
    ctx.restore();
    // 이름 띠
    const ny = ay + ah - h * 0.02, nh = h * (o.full ? 0.085 : 0.12);
    const ng = ctx.createLinearGradient(x, ny, x, ny + nh); ng.addColorStop(0, shade(cls.col, 0.1)); ng.addColorStop(1, shade(cls.col, -0.45));
    ctx.fillStyle = ng; ctx.fillRect(x + b, ny, w - 2 * b, nh);
    ctx.fillStyle = '#fff6e4'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    let fs = Math.round(nh * 0.62); ctx.font = fs + 'px ' + FONT_D;
    while (fs > 7 && ctx.measureText(cd.n).width > w - 2 * b - 6) { fs--; ctx.font = fs + 'px ' + FONT_D; }
    ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.strokeText(cd.n, x + w / 2, ny + nh / 2 + 1); ctx.fillText(cd.n, x + w / 2, ny + nh / 2 + 1);
    // 본문
    const ty = ny + nh + h * 0.012;
    if (o.full) {
      ctx.fillStyle = 'rgba(250,240,220,.94)'; rr(ctx, x + b * 2, ty, w - b * 4, y + h - ty - b * 2 - h * 0.02, R * 0.5); ctx.fill();
      ctx.fillStyle = '#5a4630'; ctx.font = Math.round(h * 0.03) + 'px ' + FONT_B; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillText(cls.s + ' · ' + TYPE_N[cd.t] + (cd.tok ? ' · 토큰' : ' · ' + RAR[cd.r]), x + b * 3.4, ty + h * 0.012);
      const lines = cardText(id); let ly = ty + h * 0.055; const lh = h * 0.042;
      ctx.font = Math.round(h * 0.034) + 'px ' + FONT_B; ctx.fillStyle = '#2a1d10';
      for (const ln of lines) for (const sub of wrapLines(ctx, ln, w - b * 7.5)) { if (ly > y + h - h * 0.11) break; ctx.fillText(sub, x + b * 3.4, ly); ly += lh; }
      if (cd.q && ly < y + h - h * 0.15) { ctx.font = 'italic ' + Math.round(h * 0.03) + 'px ' + FONT_B; ctx.fillStyle = '#7a6448'; ctx.fillText(cd.q, x + b * 3.4, ly + lh * 0.3); }
    } else {
      // 손패: 짧은 요약(키워드/첫 효과)
      const lines = cardText(id);
      if (lines.length && h > 80) {
        ctx.fillStyle = 'rgba(250,240,220,.92)'; const th = y + h - ty - b * 2; rr(ctx, x + b * 2, ty, w - b * 4, th, R * 0.4); ctx.fill();
        let fs2 = Math.max(8, Math.round(h * 0.068)); ctx.font = fs2 + 'px ' + FONT_B; ctx.fillStyle = '#2a1d10'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
        const all = []; lines.forEach((l) => wrapLines(ctx, l, w - b * 6).forEach((z) => all.push(z)));
        const maxL = Math.max(1, Math.floor((th - 4) / (fs2 * 1.12)));
        all.slice(0, maxL).forEach((z, i) => ctx.fillText(i === maxL - 1 && all.length > maxL ? z.slice(0, Math.max(1, z.length - 2)) + '…' : z, x + w / 2, ty + 2 + i * fs2 * 1.12));
      }
    }
    // 코스트
    const cost = o.cost != null ? o.cost : cd.c;
    gem(ctx, x + w * 0.13, y + w * 0.13, w * 0.12, String(cost), '#2f6fd6');
    if (cd.t === 'f') {
      statBadge(ctx, x + w * 0.13, y + h - w * 0.13, w * 0.115, o.a != null ? o.a : cd.a, cd.a, 'a');
      statBadge(ctx, x + w * 0.87, y + h - w * 0.13, w * 0.115, o.hp != null ? o.hp : cd.h, cd.h, 'h');
    } else {
      ctx.fillStyle = 'rgba(255,240,210,.95)'; ctx.font = 'bold ' + Math.round(w * 0.09) + 'px ' + FONT_B; ctx.textAlign = 'right'; ctx.textBaseline = 'top';
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.7)'; const tt = cd.t === 's' ? '주문' : '마법진' + (cd.cdn ? ' ' + cd.cdn : '');
      ctx.strokeText(tt, x + w - b * 3, y + b * 3); ctx.fillText(tt, x + w - b * 3, y + b * 3);
    }
    emblem(ctx, cls.em, x + w * 0.87, y + w * 0.14 + (cd.t === 'f' ? 0 : w * 0.12), w * 0.06, 'rgba(255,240,210,.85)');
    if (o.dim) { rr(ctx, x, y, w, h, R); ctx.fillStyle = 'rgba(10,6,16,.5)'; ctx.fill(); }
    ctx.restore();
  }
  function drawBack(ctx, x, y, w, h) {
    ctx.save();
    if (L.ui && L.ui.drawCardBack) { try { L.ui.drawCardBack(ctx, x, y, w, h, w * 0.08); ctx.restore(); return; } catch (e) {} }
    rr(ctx, x, y, w, h, w * 0.08); ctx.fillStyle = '#2b2350'; ctx.fill(); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.stroke();
    emblem(ctx, 'gem', x + w / 2, y + h / 2, w * 0.25, 'rgba(227,174,69,.6)');
    ctx.restore();
  }
  /* 판 위 추종자·마법진 */
  function drawUnit(ctx, u, x, y, w, h, o) {
    o = o || {};
    const cd = CARDS[u.id], cls = CLS[cd.cl] || CLS.x;
    const a = o.a != null ? o.a : u.a, hp = o.hp != null ? o.hp : u.h;
    ctx.save();
    if (u.k && u.k.amb) ctx.globalAlpha *= 0.62;
    if (o.glow) { ctx.shadowColor = o.glow; ctx.shadowBlur = w * 0.25; } else { ctx.shadowColor = 'rgba(0,0,0,.6)'; ctx.shadowBlur = 8; ctx.shadowOffsetY = 3; }
    if (cd.t === 'a') {
      const cx = x + w / 2, cy = y + h / 2, r = Math.min(w, h) * 0.5;
      ctx.beginPath(); for (let i = 0; i < 6; i++) { const an = i * Math.PI / 3; ctx.lineTo(cx + Math.cos(an) * r, cy + Math.sin(an) * r * 1.05); } ctx.closePath();
      ctx.fillStyle = shade(cls.col, 0.25); ctx.fill(); ctx.restore(); ctx.save();
      ctx.beginPath(); for (let i = 0; i < 6; i++) { const an = i * Math.PI / 3; ctx.lineTo(cx + Math.cos(an) * r * 0.9, cy + Math.sin(an) * r * 0.95); } ctx.closePath(); ctx.clip();
      drawArt(ctx, u.id, cx - r, cy - r, r * 2, r * 2); ctx.restore(); ctx.save();
      if (u.cd != null && cd.cdn) gem(ctx, cx, y + h - r * 0.28, r * 0.3, String(o.cd != null ? o.cd : u.cd), '#7a4ab0');
      ctx.restore(); return;
    }
    const R = w * 0.12;
    const fr = ctx.createLinearGradient(x, y, x + w, y + h);
    if (u.e) { fr.addColorStop(0, '#fff6c8'); fr.addColorStop(0.5, '#e3ae45'); fr.addColorStop(1, '#8a5a10'); }
    else { fr.addColorStop(0, shade(cls.col, 0.4)); fr.addColorStop(1, shade(cls.col, -0.5)); }
    if (u.k && u.k.ward) {   // 수호: 방패 모양 테두리
      ctx.beginPath(); ctx.moveTo(x - w * 0.06, y + h * 0.05); ctx.lineTo(x + w / 2, y - h * 0.06); ctx.lineTo(x + w * 1.06, y + h * 0.05); ctx.lineTo(x + w * 1.06, y + h * 0.72); ctx.quadraticCurveTo(x + w * 0.9, y + h * 1.0, x + w / 2, y + h * 1.07); ctx.quadraticCurveTo(x + w * 0.1, y + h * 1.0, x - w * 0.06, y + h * 0.72); ctx.closePath();
      ctx.fillStyle = 'rgba(200,215,235,.9)'; ctx.fill(); ctx.lineWidth = 1.5; ctx.strokeStyle = '#4a5a70'; ctx.stroke();
      ctx.shadowColor = 'transparent';
    }
    rr(ctx, x, y, w, h, R); ctx.fillStyle = fr; ctx.fill();
    ctx.restore(); ctx.save();
    const b = Math.max(2, w * 0.05);
    rr(ctx, x + b, y + b, w - 2 * b, h - 2 * b, R * 0.75); ctx.clip();
    drawArt(ctx, u.id, x + b, y + b, w - 2 * b, h - 2 * b);
    if (u.e) { const g = ctx.createLinearGradient(x, y, x, y + h); g.addColorStop(0, 'rgba(255,230,140,.0)'); g.addColorStop(1, 'rgba(255,210,90,.28)'); ctx.fillStyle = g; ctx.fillRect(x, y, w, h); }
    ctx.restore(); ctx.save();
    if (o.dim) { rr(ctx, x, y, w, h, R); ctx.fillStyle = 'rgba(10,6,16,.35)'; ctx.fill(); }
    // 키워드 표시
    const ks = Object.keys(u.k || {}).filter((k) => k !== 'ward');
    ctx.font = Math.round(w * 0.2) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ks.slice(0, 3).forEach((k, i) => { const cx = x + w * 0.2 + i * w * 0.3, cy = y + w * 0.17; ctx.fillStyle = 'rgba(15,10,20,.72)'; ctx.beginPath(); ctx.arc(cx, cy, w * 0.14, 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillText(KW[k].ic, cx, cy + 1); });
    if (cd.fx.some((f) => f.o === 'lw')) { ctx.fillStyle = 'rgba(15,10,20,.72)'; ctx.beginPath(); ctx.arc(x + w * 0.5, y + h - w * 0.17, w * 0.13, 0, 7); ctx.fill(); ctx.fillStyle = '#cfa6ff'; ctx.font = Math.round(w * 0.17) + 'px sans-serif'; ctx.fillText('✝', x + w * 0.5, y + h - w * 0.16); }
    else if (cd.fx.some((f) => f.o === 'end' || f.o === 'start' || f.o === 'spell' || f.o === 'ally')) { ctx.fillStyle = 'rgba(15,10,20,.72)'; ctx.beginPath(); ctx.arc(x + w * 0.5, y + h - w * 0.17, w * 0.13, 0, 7); ctx.fill(); ctx.fillStyle = '#ffe08a'; ctx.font = Math.round(w * 0.17) + 'px sans-serif'; ctx.fillText('✦', x + w * 0.5, y + h - w * 0.16); }
    statBadge(ctx, x + w * 0.16, y + h - w * 0.15, w * 0.17, a, cd.a + (u.e ? (cd.ev || { a: 2 }).a : 0), 'a');
    statBadge(ctx, x + w * 0.84, y + h - w * 0.15, w * 0.17, Math.max(0, hp), u.m != null ? u.m : cd.h, 'h');
    ctx.restore();
  }
  function drawLeaderPortrait(ctx, cl, cx, cy, r, glow) {
    const cls = CLS[cl] || CLS.x;
    ctx.save();
    if (glow) { ctx.shadowColor = glow; ctx.shadowBlur = r * 0.6; }
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7);
    const g = ctx.createLinearGradient(cx, cy - r, cx, cy + r); g.addColorStop(0, '#f6dc9a'); g.addColorStop(1, '#7a5212');
    ctx.fillStyle = g; ctx.fill(); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r * 0.88, 0, 7); ctx.clip();
    drawArt(ctx, 'leader_' + (cl || 'x'), cx - r, cy - r, r * 2, r * 2);
    ctx.restore();
  }

  /* ───────── 소리(타격·진화 합성, 소리 크기 설정을 따름) ───────── */
  let AC = null;
  function audio() {
    try { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); } catch (e) { AC = null; }
    return AC;
  }
  function vol() { try { return L.audio && L.audio.sfx ? L.audio.sfx() : 0.6; } catch (e) { return 0.6; } }
  function tone(f, d, type, v, delay, f2) {
    const ac = audio(); const V = vol() * v; if (!ac || V <= 0.001) return;
    const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
    o.type = type || 'sine'; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(V, t + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + d + 0.05);
  }
  function noise(d, v, delay, hp) {
    const ac = audio(); const V = vol() * v; if (!ac || V <= 0.001) return;
    const t = ac.currentTime + (delay || 0), n = Math.floor(ac.sampleRate * d), buf = ac.createBuffer(1, n, ac.sampleRate), ch = buf.getChannelData(0);
    for (let i = 0; i < n; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.2);
    const src = ac.createBufferSource(); src.buffer = buf; const fl = ac.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = hp || 1800;
    const g = ac.createGain(); g.gain.value = V; src.connect(fl); fl.connect(g); g.connect(ac.destination); src.start(t);
  }
  const SND = {
    impact(n) { const k = Math.min(1, n / 8); tone(150 - k * 70, 0.18 + k * 0.2, 'sine', 0.35 + k * 0.4, 0, 45); noise(0.08 + k * 0.12, 0.25 + k * 0.35, 0, 900 + k * 1500); },
    land(big) { tone(110, 0.16, 'sine', big ? 0.45 : 0.28, 0, 50); noise(0.06, 0.2, 0, 700); },
    evolve() { [392, 523, 659, 784, 1047].forEach((f, i) => tone(f, 0.5, 'triangle', 0.16, i * 0.07)); noise(0.5, 0.12, 0.35, 5000); tone(1568, 0.7, 'sine', 0.1, 0.45); },
    shatter() { noise(0.2, 0.22, 0, 3200); tone(900, 0.12, 'square', 0.05, 0, 300); },
    spell() { tone(660, 0.35, 'sine', 0.12, 0, 1320); noise(0.25, 0.08, 0.05, 4000); },
    heal() { tone(784, 0.25, 'sine', 0.1); tone(1046, 0.3, 'sine', 0.08, 0.08); },
  };

  /* ───────── 화면 ───────── */
  function mount(root, api) {
    const cvs = U.canvas(root), ctx = cvs.ctx;
    const ui = L.h('div', { class: 'cd-ui', style: { position: 'absolute', inset: '0', pointerEvents: 'none', fontFamily: 'var(--f-body)' } });
    root.append(ui);
    const style = L.h('style', { text: CSS });
    ui.append(style);
    let st = null, alive = true;
    let bottom = Math.max(0, api.players.findIndex((p) => p.local && !p.ai));
    if (api.players.filter((p) => !p.ai).length === 0) bottom = 0;
    const speedF = () => Math.max(0.25, (L.debug && L.debug.speed || 1) * (L.speed ? L.speed() : 1));
    const fxF = () => (L.fx ? L.fx() : 1);

    /* DOM 버튼 */
    const endBtn = L.h('button', { class: 'btn primary cd-end', 'data-action': 'end', style: { pointerEvents: 'auto' }, text: '턴 종료', onclick: () => doEnd() });
    const logBtn = L.h('button', { class: 'btn sm ghost cd-logb', 'data-action': 'log', style: { pointerEvents: 'auto' }, text: '📜', title: '대전 기록 (L)', onclick: () => toggleLog() });
    const logEl = L.h('div', { class: 'cd-log', style: { pointerEvents: 'auto' } });
    const tipEl = L.h('div', { class: 'cd-tip' });
    ui.append(endBtn, logBtn, logEl, tipEl);
    let logOpen = false;
    function toggleLog() { logOpen = !logOpen; renderLog(); }
    let logSig = '';
    function renderLog() {
      const wide = G && G.wide;
      logEl.style.display = (wide || logOpen) ? 'block' : 'none';
      logEl.classList.toggle('wide', !!wide);
      if (!st) return;
      const sig = st.log.length + '|' + st.log[st.log.length - 1] + wide;
      if (sig === logSig) return; logSig = sig;
      logEl.innerHTML = '';
      logEl.append(L.h('div', { class: 'cd-logh', text: '대전 기록' }));
      st.log.slice().reverse().forEach((t) => logEl.append(L.h('div', { class: t.startsWith('—') ? 'cd-logt' : 'cd-logl', text: t })));
    }

    /* 확대 보기 */
    const zoomEl = L.h('div', { class: 'cd-zoom', style: { display: 'none' } });
    ui.append(zoomEl);
    let zoomMode = '';
    function showZoom(id, mode, info) {
      zoomMode = mode; zoomEl.innerHTML = '';
      zoomEl.style.display = 'flex'; zoomEl.classList.toggle('peek', mode === 'peek');
      zoomEl.style.pointerEvents = mode === 'peek' ? 'none' : 'auto';
      const W = Math.min(250, (cvs.w || 360) * 0.66), H = W * 1.4;
      const c = L.h('canvas', { style: { width: W + 'px', height: H + 'px' } });
      const dpr = Math.min(3, window.devicePixelRatio || 1); c.width = W * dpr; c.height = H * dpr;
      const g = c.getContext('2d'); g.scale(dpr, dpr); drawCard(g, id, 0, 0, W, H, Object.assign({ full: true }, info || {}));
      const terms = L.h('div', { class: 'cd-terms' });
      cardKeys(id).slice(0, 5).forEach((t) => terms.append(L.h('div', {}, L.h('b', { text: t[0] }), ' ' + t[1])));
      if (info && info.extra) terms.append(L.h('div', { class: 'muted', text: info.extra }));
      zoomEl.append(L.h('div', { class: 'cd-zbox' }, c, terms));
      if (mode !== 'peek') zoomEl.onclick = () => hideZoom();
    }
    function hideZoom() { zoomEl.style.display = 'none'; zoomMode = ''; }

    /* 그리기 상태 */
    let G = null;
    const pos = {};               // u → {x,y} 부드러운 위치
    let A = null;                 // 연출 타임라인
    let parts = [], pops = [], shake = 0, flash = 0, flashCol = '#fff', banner = null, bubble = null;
    let sel = null, tmode = null, drag = null, hover = null, ptr = { x: -99, y: -99 };
    let lastTurnSeat = -1;

    function layout(w, h) {
      const wide = w > h * 1.15 && w >= 640;
      const side = wide ? Math.min(270, w * 0.22) : 0;
      const M = wide ? Math.min(w - side - 24, h * 1.5) : w;
      const X0 = wide ? Math.max(8, (w - side - M) / 2) : 0;
      const topH = Math.max(64, h * 0.12), meH = Math.max(68, h * 0.115);
      const handH = wide ? Math.max(130, h * 0.22) : Math.max(120, h * 0.2);
      const bTop = topH + 2, bBot = h - handH - meH;
      const bh = (bBot - bTop) / 2;
      const uw = Math.max(40, Math.min((M - 20) / 5 - 8, bh * 0.66)), uh = uw * 1.28;
      const hw = Math.min(wide ? 120 : M / 4.5, (handH - 8) / 1.4), hh = hw * 1.4;
      return { w, h, wide, side, M, X0, cx: X0 + M / 2, topH, meH, handH, bTop, bBot, bh, oppY: bTop + bh / 2, myY: bTop + bh * 1.5, mid: bTop + bh, uw, uh,
        narrow: M < 560,
        oppL: { x: M < 560 ? X0 + 14 + Math.min(topH * 0.4, 34) : X0 + M / 2, y: topH / 2 + 2, r: Math.min(topH * 0.4, 34) }, myL: { x: M < 560 ? X0 + 14 + Math.min(meH * 0.4, 34) : X0 + M / 2, y: bBot + meH / 2, r: Math.min(meH * 0.4, 34) },
        handY: h - handH, hw, hh };
    }

    /* ── 보이는 판(유령·숨김 포함) ── */
    function boardList(seat, now) {
      const live = st.P[seat].bd.filter((u) => !(A && A.hide[u.u] != null && A.t < A.hide[u.u]));
      if (!A) return live;
      const out = live.slice();
      A.ghosts.forEach((g) => { if (g.seat === seat && A.t < g.until) out.splice(Math.min(g.idx, out.length), 0, g.unit); });
      return out;
    }
    function slotX(i, n) { return G.cx + (i - (n - 1) / 2) * (G.uw + 9); }
    function unitTarget(seat, i, n) { return { x: slotX(i, n), y: seat === bottom ? G.myY : G.oppY }; }
    function ensurePos(dt) {
      const k = 1 - Math.exp(-dt * 16);
      for (const seat of [0, 1]) {
        const l = boardList(seat);
        l.forEach((u, i) => {
          const t = unitTarget(seat, i, l.length);
          const p = pos[u.u];
          if (!p) pos[u.u] = { x: t.x, y: t.y };
          else { p.x += (t.x - p.x) * k; p.y += (t.y - p.y) * k; }
        });
      }
    }
    function leaderPos(seat) { return seat === bottom ? G.myL : G.oppL; }
    function tPos(t) {   // 대상(uid 또는 'L0') 화면 위치
      if (typeof t === 'string') { const l = leaderPos(+t[1]); return { x: l.x, y: l.y }; }
      return pos[t] ? { x: pos[t].x, y: pos[t].y } : { x: G.cx, y: G.mid };
    }
    function dispU(u) {
      const o = A && A.ov[u.u];
      return o ? { a: o.a, hp: o.h, cd: o.cd, e: o.e != null ? o.e : u.e } : { a: u.a, hp: u.h, cd: u.cd, e: u.e };
    }
    function dispHP(seat) { return A && A.ovL[seat] != null ? A.ovL[seat] : st.P[seat].hp; }

    /* ── 연출 타임라인 ── */
    const DUR = { p: 380, s: 600, sm: 170, a: 340, d: 170, k: 230, e: 1050, bf: 120, kw: 110, h: 150, cd: 90, so: 60, mpp: 220, dr: 90, add: 110, burn: 200, t: 260, bn: 220, aoe: 60, bane: 60, end: 60, 'kw-': 0 };
    function startAnim(nst, pst) {
      const sp = speedF();
      const evs = (nst.last && nst.last.ev) || [];
      const a = { t: 0, list: [], end: 0, ov: {}, ovL: [pst.P[0].hp, pst.P[1].hp], hide: {}, ghosts: [], atk: [], fly: [], spell: null, evo: [], stop: 0 };
      const prevU = {};
      pst.P.forEach((p, seat) => p.bd.forEach((u, idx) => { prevU[u.u] = { u, seat, idx }; a.ov[u.u] = { a: u.a, h: u.h, cd: u.cd, e: u.e }; }));
      const nowU = {}; nst.P.forEach((p) => p.bd.forEach((u) => { nowU[u.u] = u; if (!a.ov[u.u]) a.ov[u.u] = { a: CARDS[u.id].a, h: CARDS[u.id].h, cd: CARDS[u.id].cdn, e: 0 }; }));
      Object.values(prevU).forEach((g) => { if (!nowU[g.u.u]) a.ghosts.push({ unit: g.u, seat: g.seat, idx: g.idx, until: 0 }); });
      let T = 0, impact = -1;
      for (const e of evs) {
        const k = e[0];
        let at = T, step = (DUR[k] || 0) / sp;
        if ((k === 'd' || k === 'bane') && impact >= 0) { at = impact; step = 0; }
        else if (k !== 'd' && k !== 'h' && k !== 'bane') impact = -1;
        if (k === 'a') { impact = T + 190 / sp; a.atk.push({ u: e[1], tg: e[2], T0: T, Ti: impact, T1: T + 340 / sp }); }
        if (k === 'p') { a.hide[e[2]] = T + 300 / sp; a.fly.push({ id: e[3], u: e[2], seat: e[1], T0: T, T1: T + 300 / sp }); }
        if (k === 'sm') a.hide[e[2]] = T;
        if (k === 's') a.spell = { id: e[2], seat: e[1], tg: e[4], T0: T, T1: T + 560 / sp };
        if (k === 'e') a.evo.push({ u: e[1], T0: T, T1: T + 1050 / sp });
        if (k === 'k' || k === 'bn') { const g = a.ghosts.find((x) => x.unit.u === e[1]); if (g) g.until = T; }
        a.list.push({ T: k === 'e' ? T + 520 / sp : at, e, done: 0 });
        T += step;
      }
      a.end = T + 200 / sp;
      if (a.end < 30) { A = null; return false; }
      A = a; api.setBusy(true);
      return true;
    }
    function fireEv(ev) {
      const e = ev.e, k = e[0];
      const F = fxF();
      if (k === 'd') {
        const n = e[2], p = tPos(e[1]);
        if (typeof e[1] === 'string') A.ovL[+e[1][1]] = e[3]; else if (A.ov[e[1]]) A.ov[e[1]].h = e[3];
        const big = n >= 5;
        shake = Math.max(shake, (2 + n * 1.5) * F * (typeof e[1] === 'string' ? 1.4 : 1));
        A.stop = Math.max(A.stop, Math.min(150, 40 + n * 14) * (F > 0 ? 1 : 0));
        burst(p.x, p.y, 8 + n * 4, ['#fff', '#ffd27a', '#ff7a4a'], 2.2 + n * 0.4);
        pop(p.x, p.y - 10, '−' + n, '#ff5a4a', 18 + Math.min(16, n * 2.2));
        SND.impact(n); if (big) api.sfx('thud');
        if (typeof e[1] === 'string' && +e[1][1] === bottom) { api.buzz(Math.min(120, 20 + n * 10)); flash = Math.max(flash, 0.12 + n * 0.03); flashCol = '#ff2a2a'; }
      } else if (k === 'h') {
        const p = tPos(e[1]); if (typeof e[1] === 'string') A.ovL[+e[1][1]] = e[3]; else if (A.ov[e[1]]) A.ov[e[1]].h = e[3];
        pop(p.x, p.y - 10, '+' + e[2], '#7aff9a', 18); sparkle(p.x, p.y, 10, '#9aff9a'); SND.heal();
      } else if (k === 'bf') {
        if (A.ov[e[1]]) { A.ov[e[1]].a = e[2]; A.ov[e[1]].h = e[3]; }
        const p = tPos(e[1]); sparkle(p.x, p.y, 8, '#ffe08a'); api.sfx('chip', { vol: 0.5 });
      } else if (k === 'e') {
        if (A.ov[e[1]]) { A.ov[e[1]].a = e[2]; A.ov[e[1]].h = e[3]; A.ov[e[1]].e = 1; }
        const p = tPos(e[1]); flash = Math.max(flash, 0.55 * F); flashCol = '#fff4c0'; shake = Math.max(shake, 6 * F);
        burst(p.x, p.y, 46, ['#fff6c8', '#e3ae45', '#ffffff'], 4.2); A.stop = Math.max(A.stop, 90);
        if (e[4]) pop(p.x, p.y - G.uh * 0.6, '역전 +1/+1', '#ffd27a', 15);
      } else if (k === 'k') {
        const g = A.ghosts.find((x) => x.unit.u === e[1]); const p = pos[e[1]] || tPos(e[1]);
        const cl = CLS[CARDS[e[3]].cl] || CLS.x;
        shards(p.x, p.y, cl.col); SND.shatter();
        if (g) g.until = A.t;
      } else if (k === 'p') {
        const seat = e[1], big = CARDS[e[3]].c >= 7;
        shake = Math.max(shake, (big ? 7 : 2.5) * F);
        const p = unitTarget(seat, 0, 1); dust((pos[e[2]] || p).x, (pos[e[2]] || p).y + G.uh * 0.4, big ? 22 : 12);
        SND.land(big); api.sfx('card', { vol: 0.7 });
      } else if (k === 'sm') { const p = pos[e[2]]; if (p) sparkle(p.x, p.y, 10, '#fff'); api.sfx('pop', { vol: 0.5 }); }
      else if (k === 's') { SND.spell(); api.sfx('whoosh'); }
      else if (k === 'a') { api.sfx('whoosh', { vol: 0.6 }); }
      else if (k === 'kw') { const p = tPos(e[1]); sparkle(p.x, p.y, 8, '#9fd8ff'); }
      else if (k === 'cd') { if (A.ov[e[1]]) A.ov[e[1]].cd = e[2]; api.sfx('tick', { vol: 0.5 }); }
      else if (k === 'mpp') { const l = leaderPos(e[1]); sparkle(l.x + l.r * 2, l.y, 14, '#7ab8ff'); pop(l.x + l.r * 2.2, l.y - 6, '최대 PP +1', '#9fd0ff', 13); api.sfx('chip'); }
      else if (k === 'dr' || k === 'add') { api.sfx('card', { vol: 0.35 }); }
      else if (k === 'burn') { pop(G.cx, G.handY - 16, '손패 가득 — 버림', '#ffb0a0', 14); }
      else if (k === 'bn') { const p = tPos(e[1]); sparkle(p.x, p.y, 12, '#c8ffd8'); api.sfx('whoosh', { vol: 0.5 }); }
      else if (k === 'aoe') { flash = Math.max(flash, 0.18 * F); flashCol = '#ffd0a0'; }
      else if (k === 't') {
        if (e[1] === bottom && api.canAct(e[1])) { banner = { txt: '내 턴', sub: 'PP ' + st.P[e[1]].mp, t0: performance.now(), col: '#e3ae45' }; api.sfx('turn'); api.haptic && api.haptic('alert', 30); }
        else banner = { txt: '상대 턴', t0: performance.now(), col: '#ab9fb8', small: 1 };
      } else if (k === 'so') { if (e[2] > 0) { const l = leaderPos(e[1]); pop(l.x - l.r * 2, l.y, '넋 +' + e[2], '#cfa6ff', 12); } }
    }
    function burst(x, y, n, cols, sp) { for (let i = 0; i < n; i++) { const a = Math.random() * 6.283, v = (0.4 + Math.random()) * sp * 60; parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, g: 220, life: 0.35 + Math.random() * 0.4, t: 0, col: cols[i % cols.length], sz: 1.5 + Math.random() * 2.5, sh: 0 }); } }
    function sparkle(x, y, n, col) { for (let i = 0; i < n; i++) parts.push({ x: x + (Math.random() - 0.5) * G.uw, y: y + (Math.random() - 0.3) * G.uh * 0.6, vx: (Math.random() - 0.5) * 20, vy: -40 - Math.random() * 50, g: -10, life: 0.6 + Math.random() * 0.4, t: 0, col, sz: 2 + Math.random() * 2, sh: 2 }); }
    function shards(x, y, col) { for (let i = 0; i < 22; i++) { const a = Math.random() * 6.283, v = 60 + Math.random() * 180; parts.push({ x: x + (Math.random() - 0.5) * G.uw * 0.6, y: y + (Math.random() - 0.5) * G.uh * 0.6, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, g: 520, life: 0.6 + Math.random() * 0.4, t: 0, col: i % 3 ? col : '#f2e9d8', sz: 3 + Math.random() * 5, sh: 1, rot: Math.random() * 6, vr: (Math.random() - 0.5) * 14 }); } }
    function dust(x, y, n) { for (let i = 0; i < n; i++) { const a = Math.PI + Math.random() * Math.PI, v = 40 + Math.random() * 90; parts.push({ x, y, vx: Math.cos(a) * v * 1.6, vy: Math.sin(a) * v * 0.3, g: -20, life: 0.4 + Math.random() * 0.3, t: 0, col: 'rgba(230,215,190,.7)', sz: 3 + Math.random() * 4, sh: 3 }); } }
    function pop(x, y, txt, col, size) { pops.push({ x, y, txt, col, size, t: 0, life: 0.95 }); }

    /* ── 그리기 ── */
    let bgC = null, bgKey = '';
    function drawBG(w, h) {
      const key = w + 'x' + h + (st ? st.P[0].cl + st.P[1].cl + bottom : '');
      if (key !== bgKey) {
        bgKey = key; bgC = document.createElement('canvas'); const dpr = Math.min(2, window.devicePixelRatio || 1);
        bgC.width = w * dpr; bgC.height = h * dpr; const g = bgC.getContext('2d'); g.scale(dpr, dpr);
        const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#120e1c'); gr.addColorStop(0.5, '#1e1830'); gr.addColorStop(1, '#120e1c'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
        if (st && st.P[0].cl) {
          const top = CLS[st.P[1 - bottom].cl] || CLS.x, bot = CLS[st.P[bottom].cl] || CLS.x;
          let r = g.createRadialGradient(G.cx, G.oppY, 10, G.cx, G.oppY, G.M * 0.7); r.addColorStop(0, shade(top.col, -0.35)); r.addColorStop(1, 'rgba(0,0,0,0)'); g.globalAlpha = 0.55; g.fillStyle = r; g.fillRect(0, 0, w, G.mid);
          r = g.createRadialGradient(G.cx, G.myY, 10, G.cx, G.myY, G.M * 0.7); r.addColorStop(0, shade(bot.col, -0.35)); r.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = r; g.fillRect(0, G.mid, w, h - G.mid); g.globalAlpha = 1;
          emblem(g, top.em, G.cx, G.oppY, G.bh * 0.32, 'rgba(255,255,255,.035)');
          emblem(g, bot.em, G.cx, G.myY, G.bh * 0.32, 'rgba(255,255,255,.035)');
        }
        // 판 테두리·가운데 줄
        g.strokeStyle = 'rgba(227,174,69,.25)'; g.lineWidth = 1;
        rr(g, G.X0 + 4, G.bTop, G.M - 8, G.bBot - G.bTop, 14); g.stroke();
        g.setLineDash([6, 6]); g.beginPath(); g.moveTo(G.X0 + 14, G.mid); g.lineTo(G.X0 + G.M - 14, G.mid); g.stroke(); g.setLineDash([]);
        // 칸 자리
        for (const yy of [G.oppY, G.myY]) for (let i = 0; i < 5; i++) { rr(g, slotX(i, 5) - G.uw / 2, yy - G.uh / 2, G.uw, G.uh, G.uw * 0.12); g.strokeStyle = 'rgba(255,255,255,.05)'; g.stroke(); }
        const vg = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.55)'); g.fillStyle = vg; g.fillRect(0, 0, w, h);
      }
      ctx.drawImage(bgC, 0, 0, w, h);
    }
    function myTurn() { return st && st.ph === 'play' && st.cur === bottom && api.canAct(bottom) && !A; }
    function handVisible(seat) { return st && (api.viewer() === seat || (st.win != null && api.canAct(seat))); }
    function handRects() {
      const p = st.P[bottom], n = p.hd.length; if (!n) return [];
      const sp = Math.min(G.hw + 6, (G.M - G.hw - 16) / Math.max(1, n - 1));
      const out = [];
      p.hd.forEach((c, i) => {
        const x = G.cx + (i - (n - 1) / 2) * sp - G.hw / 2;
        let y = G.h - G.hh - 4;
        const raised = (sel && sel.t === 'h' && sel.u === c.u) || (hover && hover.k === 'h' && hover.u === c.u && !drag);
        if (raised) y -= G.hh * 0.22;
        out.push({ c, x, y, w: G.hw, h: G.hh, i });
      });
      return out;
    }
    function hitTest(p) {
      if (!st || !G) return null;
      if (evoBtn && p.x >= evoBtn.x && p.x <= evoBtn.x + evoBtn.w && p.y >= evoBtn.y && p.y <= evoBtn.y + evoBtn.h) return { k: 'evo' };
      if (handVisible(bottom)) { const hr = handRects(); for (let i = hr.length - 1; i >= 0; i--) { const r = hr[i]; if (p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y) return { k: 'h', u: r.c.u, id: r.c.id }; } }
      for (const seat of [0, 1]) for (const u of boardList(seat)) { const q = pos[u.u]; if (!q) continue; if (Math.abs(p.x - q.x) <= G.uw / 2 + 4 && Math.abs(p.y - q.y) <= G.uh / 2 + 4) return { k: 'u', u: u.u, seat, id: u.id }; }
      for (const seat of [0, 1]) { const l = leaderPos(seat); if (Math.hypot(p.x - l.x, p.y - l.y) <= l.r + 8) return { k: 'L', seat, t: 'L' + seat }; }
      return null;
    }
    function targetsNow() {
      if (!st || st.ph !== 'play') return [];
      if (tmode) return tmode.list;
      if (drag && drag.moved && drag.k === 'h') { const c = st.P[bottom].hd.find((x) => x.u === drag.u); if (c && playable(st, bottom, c)) return playTargets(st, bottom, c) || []; }
      const su = (drag && drag.k === 'u') ? drag.u : (sel && sel.t === 'u') ? sel.u : null;
      if (su != null) { const f = findU(st, su); if (f && f.seat === bottom) return attackTargets(st, bottom, f.u); }
      return [];
    }
    let evoBtn = null;
    function draw(dt) {
      const w = cvs.w, h = cvs.h; if (!w || !h) return;
      G = layout(w, h);
      if (!st || !st.P[0].cl || st.ph === 'pick') { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, w, h); return; }
      ensurePos(dt);
      ctx.save();
      if (shake > 0.2) { ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake); }
      drawBG(w, h);
      const now = performance.now(), pulse = 0.5 + 0.5 * Math.sin(now / 220);
      const tl = targetsNow(), tset = new Set(tl.map(String));
      const mine = myTurn();
      // 판
      for (const seat of [0, 1]) {
        boardList(seat).forEach((u) => {
          const p = pos[u.u]; if (!p) return;
          let ox = 0, oy = 0, sc = 1;
          if (A) {
            const at = A.atk.find((x) => x.u === u.u && A.t >= x.T0 && A.t <= x.T1);
            if (at) { const tp = tPos(at.tg); let k; if (A.t < at.Ti) { k = (A.t - at.T0) / (at.Ti - at.T0); k = k * k * 0.82; } else { k = 0.82 * (1 - (A.t - at.Ti) / (at.T1 - at.Ti)); k = Math.max(0, k); } ox = (tp.x - p.x) * k; oy = (tp.y - p.y) * k; sc = 1 + k * 0.12; }
            const ev = A.evo.find((x) => x.u === u.u && A.t >= x.T0 && A.t <= x.T1);
            if (ev) { const k = (A.t - ev.T0) / (ev.T1 - ev.T0); sc = 1 + Math.sin(Math.min(1, k) * Math.PI) * 0.45; oy = -Math.sin(Math.min(1, k) * Math.PI) * G.uh * 0.25; }
            const hd = A.hide[u.u]; if (hd != null && A.t - hd < 160) { const k = (A.t - hd) / 160; sc *= 1.25 - 0.25 * k; }
            const gh = A.ghosts.find((x) => x.unit.u === u.u); if (gh && gh.until - A.t < 120) sc *= 1 + (1 - (gh.until - A.t) / 120) * 0.1;
          }
          const d = dispU(u);
          let glow = null;
          if (tset.has(String(u.u))) glow = seat === bottom ? 'rgba(120,255,160,' + (0.6 + pulse * 0.4) + ')' : 'rgba(255,80,60,' + (0.6 + pulse * 0.4) + ')';
          else if (mine && seat === bottom && canAttack(u) && attackTargets(st, bottom, u).length) glow = 'rgba(120,230,255,.85)';
          if (sel && sel.t === 'u' && sel.u === u.u) glow = '#ffe08a';
          const ww = G.uw * sc, hh = G.uh * sc;
          const dim = seat === bottom && isFol(u) && st.cur === bottom && (u.sk && !u.k.storm && !u.k.rush && !u.er) ? 1 : 0;
          drawUnit(ctx, Object.assign({}, u, { e: d.e }), p.x + ox - ww / 2, p.y + oy - hh / 2, ww, hh, { a: d.a, hp: d.hp, cd: d.cd, glow, dim });
          if (dim && !A) { ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.font = Math.round(G.uw * 0.2) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('💤', p.x + G.uw * 0.32, p.y - G.uh * 0.32); }
        });
      }
      // 진화 연출(빛줄기)
      if (A) A.evo.forEach((ev) => {
        if (A.t < ev.T0 || A.t > ev.T1) return; const p = pos[ev.u]; if (!p) return; const k = (A.t - ev.T0) / (ev.T1 - ev.T0);
        ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.translate(p.x, p.y); ctx.rotate(k * 2);
        for (let i = 0; i < 12; i++) { ctx.rotate(Math.PI / 6); const g = ctx.createLinearGradient(0, 0, 0, -G.uh * 1.6); g.addColorStop(0, 'rgba(255,230,140,' + (0.5 * Math.sin(k * Math.PI)) + ')'); g.addColorStop(1, 'rgba(255,230,140,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(6, 0); ctx.lineTo(0, -G.uh * 1.6); ctx.fill(); }
        ctx.restore();
      });
      // 리더
      drawLeader(1 - bottom, G.oppL, tset);
      drawLeader(bottom, G.myL, tset);
      // 상대 손패(뒷면)
      const oh = st.P[1 - bottom].hd.length;
      { const bw = Math.min(24, G.topH * 0.32), stp = Math.min(bw * 0.5, 12), x0 = G.X0 + G.M - 10 - bw - Math.max(0, oh - 1) * stp;
        for (let i = 0; i < oh; i++) drawBack(ctx, x0 + i * stp, 8, bw, bw * 1.4);
        if (oh) { ctx.fillStyle = '#f2e9d8'; ctx.font = '12px ' + FONT_M; ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic'; ctx.fillText('손패 ' + oh, G.X0 + G.M - 10, bw * 1.4 + 24); } }
      // 손패
      evoBtn = null;
      if (handVisible(bottom)) {
        const hr = handRects();
        hr.forEach((r) => {
          if (drag && drag.k === 'h' && drag.u === r.c.u && drag.moved) return;
          const can = mine && playable(st, bottom, r.c);
          drawCard(ctx, r.c.id, r.x, r.y, r.w, r.h, { glow: can ? 'rgba(90,230,255,.95)' : null, dim: st.cur === bottom && !can && st.ph === 'play' });
        });
      } else {
        const n = st.P[bottom].hd.length;
        for (let i = 0; i < n; i++) drawBack(ctx, G.cx + (i - (n - 1) / 2) * Math.min(G.hw * 0.5, 30) - G.hw * 0.35, G.h - G.hh * 0.55, G.hw * 0.7, G.hw * 0.98);
      }
      // 진화 버튼
      if (mine && sel && sel.t === 'u' && evoReady(st, bottom)) {
        const f = findU(st, sel.u);
        if (f && f.seat === bottom && isFol(f.u) && !f.u.e && pos[sel.u]) {
          const p = pos[sel.u], bw = 76, bh = 44;
          evoBtn = { x: Math.max(G.X0 + 4, Math.min(G.X0 + G.M - bw - 4, p.x - bw / 2)), y: p.y - G.uh / 2 - bh - 6, w: bw, h: bh };
          ctx.save(); ctx.shadowColor = 'rgba(255,220,120,.9)'; ctx.shadowBlur = 12 + pulse * 8;
          const g = ctx.createLinearGradient(0, evoBtn.y, 0, evoBtn.y + bh); g.addColorStop(0, '#fff0b0'); g.addColorStop(1, '#c98a1a');
          rr(ctx, evoBtn.x, evoBtn.y, bw, bh, 12); ctx.fillStyle = g; ctx.fill(); ctx.restore();
          ctx.fillStyle = '#3a2408'; ctx.font = '17px ' + FONT_D; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('진화 ✦', evoBtn.x + bw / 2, evoBtn.y + bh / 2 + 1);
          if (L.ui && L.ui.drawKeyBadge) L.ui.drawKeyBadge(ctx, evoBtn.x + bw, evoBtn.y + bh, L.ui.keyLabel(GID, 'evo'));
        }
      }
      // 화살표(공격·대상 고르기)
      let src = null;
      if (drag && drag.moved && drag.k === 'u') src = pos[drag.u];
      else if (tmode) src = tmode.src || (tmode.u != null && pos[tmode.u]) || { x: G.cx, y: G.h - G.hh * 0.6 };
      else if (drag && drag.moved && drag.k === 'h' && tl.length) src = null;
      if (src && (drag || ptr.x > 0)) arrow(src.x, src.y, ptr.x, ptr.y, tset.size && hitTest(ptr) && tset.has(String(hitTestT(hitTest(ptr)))));
      // 끌고 있는 카드
      if (drag && drag.k === 'h' && drag.moved) {
        const c = st.P[bottom].hd.find((x) => x.u === drag.u);
        if (c) { const over = ptr.y < G.handY; const s2 = over ? 0.85 : 1; drawCard(ctx, c.id, ptr.x - G.hw * s2 / 2, ptr.y - G.hh * s2 * 0.6, G.hw * s2, G.hh * s2, { glow: over && playable(st, bottom, c) ? 'rgba(120,255,170,.95)' : 'rgba(0,0,0,.5)' }); }
      }
      // 날아가는 카드(내기)
      if (A) {
        A.fly.forEach((f) => {
          if (A.t < f.T0 || A.t > f.T1) return;
          const k = (A.t - f.T0) / (f.T1 - f.T0), e = 1 - Math.pow(1 - k, 3);
          const from = f.seat === bottom ? { x: G.cx, y: G.h - G.hh * 0.5 } : { x: G.oppL.x, y: G.oppL.y };
          const to = pos[f.u] || unitTarget(f.seat, 0, 1);
          const sc = 1.25 - 0.25 * e, ww = G.uw * 1.25 * sc, hh = ww * 1.4;
          const x = from.x + (to.x - from.x) * e, y = from.y + (to.y - from.y) * e - Math.sin(k * Math.PI) * 40;
          drawCard(ctx, f.id, x - ww / 2, y - hh / 2, ww, hh, { glow: 'rgba(255,240,200,.6)' });
        });
        if (A.spell && A.t >= A.spell.T0 && A.t <= A.spell.T1) {
          const sp = A.spell, k = (A.t - sp.T0) / (sp.T1 - sp.T0);
          const ww = Math.min(G.M * 0.42, 150), hh = ww * 1.4, a = k < 0.15 ? k / 0.15 : k > 0.75 ? (1 - k) / 0.25 : 1;
          ctx.save(); ctx.globalAlpha = Math.max(0, a);
          const cls = CLS[CARDS[sp.id].cl] || CLS.x;
          ctx.globalCompositeOperation = 'lighter'; const rg = ctx.createRadialGradient(G.cx, G.mid, 10, G.cx, G.mid, ww * 1.2); rg.addColorStop(0, shade(cls.hi, 0) ); rg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.globalAlpha = a * 0.35; ctx.fillStyle = rg; ctx.fillRect(G.cx - ww * 1.3, G.mid - ww * 1.3, ww * 2.6, ww * 2.6);
          ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = Math.max(0, a);
          drawCard(ctx, sp.id, G.cx - ww / 2, G.mid - hh / 2 - (1 - a) * 20, ww, hh, { glow: shade(cls.hi, 0) });
          ctx.restore();
        }
      }
      // 입자·숫자
      parts = parts.filter((q) => (q.t += dt) < q.life);
      parts.forEach((q) => {
        q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; const a = 1 - q.t / q.life;
        ctx.globalAlpha = Math.max(0, a); ctx.fillStyle = q.col;
        if (q.sh === 1) { q.rot += (q.vr || 0) * dt; ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.rot); ctx.fillRect(-q.sz / 2, -q.sz / 2, q.sz, q.sz * 0.6); ctx.restore(); }
        else if (q.sh === 2) { ctx.beginPath(); ctx.moveTo(q.x, q.y - q.sz * 1.6); ctx.lineTo(q.x + q.sz * 0.5, q.y); ctx.lineTo(q.x, q.y + q.sz * 1.6); ctx.lineTo(q.x - q.sz * 0.5, q.y); ctx.fill(); }
        else { ctx.beginPath(); ctx.arc(q.x, q.y, q.sz * (q.sh === 3 ? (1 + q.t * 3) : 1), 0, 7); ctx.fill(); }
      });
      ctx.globalAlpha = 1;
      pops = pops.filter((q) => (q.t += dt) < q.life);
      pops.forEach((q) => {
        const k = q.t / q.life, s = q.t < 0.12 ? 0.6 + q.t / 0.12 * 0.7 : 1.3 - Math.min(0.3, (q.t - 0.12) * 2);
        ctx.save(); ctx.globalAlpha = k > 0.7 ? (1 - k) / 0.3 : 1; ctx.translate(q.x, q.y - k * 28); ctx.scale(s, s);
        ctx.font = 'bold ' + Math.round(q.size) + 'px ' + FONT_M; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.85)'; ctx.strokeText(q.txt, 0, 0); ctx.fillStyle = q.col; ctx.fillText(q.txt, 0, 0); ctx.restore();
      });
      ctx.restore();
      if (flash > 0.01) { ctx.save(); ctx.globalAlpha = Math.min(0.7, flash); ctx.fillStyle = flashCol; ctx.fillRect(0, 0, w, h); ctx.restore(); flash *= Math.pow(0.02, dt); }
      shake *= Math.pow(0.004, dt);
      // 띠(내 턴)
      if (banner) {
        const k = (performance.now() - banner.t0) / (900 / Math.min(2, speedF()));
        if (k > 1) banner = null; else {
          const a = k < 0.2 ? k / 0.2 : k > 0.75 ? (1 - k) / 0.25 : 1;
          ctx.save(); ctx.globalAlpha = a; const bh = banner.small ? 34 : 54, y = G.mid - bh / 2;
          const g = ctx.createLinearGradient(G.X0, 0, G.X0 + G.M, 0); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(0.5, 'rgba(10,6,16,.85)'); g.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = g; ctx.fillRect(G.X0, y, G.M, bh);
          ctx.fillStyle = banner.col; ctx.font = (banner.small ? 18 : 30) + 'px ' + FONT_D; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText(banner.txt, G.cx + (1 - a) * 30 * (k < 0.5 ? -1 : 1), G.mid + 1);
          ctx.restore();
        }
      }
      // 말풍선(상대 리더)
      if (bubble) {
        const k = (performance.now() - bubble.t0) / 2600;
        if (k > 1) bubble = null; else {
          const l = G.oppL; ctx.save(); ctx.globalAlpha = k > 0.85 ? (1 - k) / 0.15 : 1;
          ctx.font = '13px ' + FONT_B; const lines = wrapLines(ctx, bubble.txt, Math.min(200, G.M * 0.5)); const bw = Math.max(...lines.map((z) => ctx.measureText(z).width)) + 18, bh = lines.length * 17 + 12;
          const bx = Math.min(G.X0 + G.M - bw - 6, l.x + l.r + 10), by = Math.max(4, l.y - bh / 2);
          rr(ctx, bx, by, bw, bh, 9); ctx.fillStyle = 'rgba(250,240,220,.96)'; ctx.fill();
          ctx.fillStyle = '#2a1d10'; ctx.textAlign = 'left'; ctx.textBaseline = 'top'; lines.forEach((z, i) => ctx.fillText(z, bx + 9, by + 7 + i * 17));
          ctx.restore();
        }
      }
    }
    function hitTestT(h) { return !h ? null : h.k === 'u' ? h.u : h.k === 'L' ? h.t : null; }
    function arrow(x0, y0, x1, y1, ok) {
      ctx.save();
      const col = ok ? '#ff6a4a' : 'rgba(255,230,180,.85)';
      const mx = (x0 + x1) / 2, my = Math.min(y0, y1) - 40;
      ctx.lineWidth = 7; ctx.lineCap = 'round'; ctx.strokeStyle = 'rgba(0,0,0,.45)';
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.quadraticCurveTo(mx, my, x1, y1); ctx.stroke();
      ctx.lineWidth = 4.5; ctx.strokeStyle = col; ctx.setLineDash([12, 7]); ctx.lineDashOffset = -performance.now() / 20; ctx.stroke(); ctx.setLineDash([]);
      const an = Math.atan2(y1 - my, x1 - mx); ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(x1 + Math.cos(an) * 6, y1 + Math.sin(an) * 6); ctx.lineTo(x1 + Math.cos(an + 2.5) * 16, y1 + Math.sin(an + 2.5) * 16); ctx.lineTo(x1 + Math.cos(an - 2.5) * 16, y1 + Math.sin(an - 2.5) * 16); ctx.fill();
      ctx.restore();
    }
    function drawLeader(seat, Lp, tset) {
      const p = st.P[seat], cls = CLS[p.cl] || CLS.x;
      const isT = tset.has('L' + seat);
      const cur = st.cur === seat && st.ph === 'play';
      drawLeaderPortrait(ctx, p.cl, Lp.x, Lp.y, Lp.r, isT ? 'rgba(255,70,50,.95)' : cur ? 'rgba(227,174,69,.8)' : null);
      if (isT) { ctx.save(); ctx.strokeStyle = 'rgba(255,90,60,' + (0.5 + 0.5 * Math.sin(performance.now() / 160)) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(Lp.x, Lp.y, Lp.r + 5, 0, 7); ctx.stroke(); ctx.restore(); }
      const hp = dispHP(seat);
      const hx = Lp.x + Lp.r * 0.78, hy = Lp.y + Lp.r * 0.62;
      ctx.save(); ctx.beginPath(); ctx.arc(hx, hy, Lp.r * 0.45, 0, 7); ctx.fillStyle = hp <= 10 ? '#9a1a2a' : '#5a1a1a'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#f6dc9a'; ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.font = 'bold ' + Math.round(Lp.r * 0.52) + 'px ' + FONT_M; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(Math.max(0, hp)), hx, hy + 1); ctx.restore();
      const nm = ((api.players[seat] && api.players[seat].name) || '').slice(0, 10);
      const evOn = p.own >= EVO_TURN[seat];
      let extra = '덱 ' + p.dk.length;
      if (p.cl === 'n') extra += ' · 넋 ' + p.so; else if (p.cl === 'a') extra += ' · 주문 ' + p.sp; else if (p.cl === 'g') extra += ' · 부품 ' + p.pc; else if (p.cl === 'v' && p.hp <= 10) extra += ' · 갈증!'; else if (p.cl === 'd' && p.mp >= 7) extra += ' · 각성!'; else if (p.cl === 'w' && st.cur === seat) extra += ' · 연계 ' + p.cb;
      const evText = !evOn ? (EVO_TURN[seat] - p.own) + '턴 뒤' : p.evt ? '사용함' : '';
      ctx.save(); ctx.textBaseline = 'middle';
      const pips = (x, y) => { for (let i = 0; i < EVO_PTS[seat]; i++) { ctx.beginPath(); ctx.arc(x + i * 12, y, 4.5, 0, 7); ctx.fillStyle = i < p.ep ? (evOn && !p.evt ? '#ffd76a' : '#9a7a3a') : 'rgba(255,255,255,.12)'; ctx.fill(); } return x + EVO_PTS[seat] * 12; };
      const gems = (x, y, gw) => { for (let i = 0; i < p.mp; i++) { ctx.fillStyle = i < p.pp ? '#5ab0ff' : 'rgba(90,176,255,.22)'; ctx.beginPath(); const gx = x + i * gw, gy = y; ctx.moveTo(gx, gy - 5); ctx.lineTo(gx + gw * 0.42, gy); ctx.lineTo(gx, gy + 5); ctx.lineTo(gx - gw * 0.42, gy); ctx.fill(); } };
      if (G.narrow) {
        const x = Lp.x + Lp.r + 12, top = Lp.y - Lp.r * 0.95;
        const lh = Math.max(15, Lp.r * 0.64);
        ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.font = '14px ' + FONT_D; ctx.fillText(nm, x, top + lh * 0.45);
        const nw = ctx.measureText(nm).width; ctx.font = '11.5px ' + FONT_B; ctx.fillStyle = cls.hi; ctx.fillText(cls.s, x + nw + 6, top + lh * 0.45);
        ctx.font = 'bold 14px ' + FONT_M; ctx.fillStyle = '#9fd0ff'; const pt = 'PP ' + p.pp + '/' + p.mp; ctx.fillText(pt, x, top + lh * 1.45);
        const pw = ctx.measureText(pt).width; gems(x + pw + 10, top + lh * 1.45, 8);
        ctx.font = '11.5px ' + FONT_B; ctx.fillStyle = '#e3ae45'; ctx.fillText('진화', x, top + lh * 2.45);
        let ex = pips(x + 30, top + lh * 2.45) + 2;
        ctx.fillStyle = '#ab9fb8'; ctx.fillText((evText ? evText + ' · ' : '') + extra, ex, top + lh * 2.45);
      } else {
        ctx.textAlign = 'right'; ctx.fillStyle = '#f2e9d8'; const lx = Lp.x - Lp.r - 12;
        ctx.font = '15px ' + FONT_D; ctx.fillText(nm, lx, Lp.y - 12);
        ctx.font = '12px ' + FONT_B; ctx.fillStyle = cls.hi; ctx.fillText(LEAD[p.cl] + ' · ' + cls.s, lx, Lp.y + 6);
        ctx.fillStyle = '#ab9fb8'; ctx.fillText(extra, lx, Lp.y + 22);
        const rx = Lp.x + Lp.r + 12; ctx.textAlign = 'left';
        ctx.font = 'bold 16px ' + FONT_M; ctx.fillStyle = '#9fd0ff'; ctx.fillText('PP ' + p.pp + '/' + p.mp, rx, Lp.y - 10); gems(rx + 82, Lp.y - 10, 9);
        ctx.font = '12px ' + FONT_B; ctx.fillStyle = '#e3ae45'; ctx.fillText('진화', rx, Lp.y + 12);
        const ex = pips(rx + 32, Lp.y + 12) + 4; ctx.fillStyle = '#ab9fb8'; if (evText) ctx.fillText(evText, ex, Lp.y + 12);
      }
      ctx.restore();
    }

    /* ── 입력 ── */
    function cardBy(u) { return st.P[bottom].hd.find((c) => c.u === u); }
    function reasonNot(c) {
      const p = st.P[bottom], cd = CARDS[c.id];
      if (st.cur !== bottom) return '상대 턴이에요';
      if (cd.c > p.pp) return 'PP가 부족해요 (' + cd.c + ' 필요)';
      if (cd.t !== 's' && p.bd.length >= BOARD) return '내 판이 가득 찼어요(최대 5)';
      return '고를 대상이 없어요';
    }
    function dropPos(x) {
      const l = st.P[bottom].bd; let i = 0;
      for (; i < l.length; i++) { const q = pos[l[i].u]; if (q && x < q.x) break; }
      return i;
    }
    function tryPlay(u, dropT, x) {
      const c = cardBy(u); if (!c) return;
      if (!playable(st, bottom, c)) { api.toast(reasonNot(c)); api.sfx('warn'); return; }
      const tl = playTargets(st, bottom, c);
      const ps = x != null ? dropPos(x) : null;
      if (tl && tl.length) {
        if (dropT != null && tl.map(String).includes(String(dropT))) { send({ t: 'play', u, tg: dropT, pos: ps }); return; }
        tmode = { kind: 'play', u, list: tl, pos: ps, src: { x: G.cx, y: G.h - G.hh * 0.7 } }; sel = null;
        tip('대상을 고르세요 · 빈 곳을 누르면 취소');
        return;
      }
      send({ t: 'play', u, pos: ps });
    }
    function send(a) { sel = null; tmode = null; tip(''); hideZoom(); api.act(a); }
    function doEnd() {
      if (!myTurn()) return;
      sel = null; tmode = null; tip('');
      api.sfx('click'); send({ t: 'end' });
    }
    function doEvo(u) {
      const f = findU(st, u); if (!f) return;
      const tl = evoTargets(st, bottom, f.u);
      if (tl && tl.length) { tmode = { kind: 'evo', u, list: tl }; tip('진화 효과의 대상을 고르세요'); return; }
      send({ t: 'evo', u });
    }
    let tipT = 0;
    function tip(t) { tipEl.textContent = t; tipEl.style.display = t ? 'block' : 'none'; clearTimeout(tipT); if (t) tipT = setTimeout(() => { if (!tmode) tipEl.style.display = 'none'; }, 3500); }
    let lpT = 0;
    function onDown(e) {
      if (!st || st.ph !== 'play' || !G) return;
      audio();
      const p = cvs.local(e); ptr = p;
      const h = hitTest(p);
      clearTimeout(lpT);
      if (zoomMode === 'peek') hideZoom();
      if (h && h.k === 'evo') { if (sel && sel.t === 'u') doEvo(sel.u); return; }
      if (tmode) {
        const t = hitTestT(h);
        if (t != null && tmode.list.map(String).includes(String(t))) {
          if (tmode.kind === 'play') send({ t: 'play', u: tmode.u, tg: t, pos: tmode.pos });
          else if (tmode.kind === 'evo') send({ t: 'evo', u: tmode.u, tg: t });
          return;
        }
        tmode = null; tip(''); return;
      }
      if (h && (h.k === 'h' || h.k === 'u' || h.k === 'L')) {
        drag = { k: h.k, u: h.u, seat: h.seat, id: h.id, sx: p.x, sy: p.y, moved: false, hit: h };
        lpT = setTimeout(() => { if (drag && !drag.moved) { const id = h.k === 'L' ? null : h.id; if (id) { zoomInfo(h); drag = null; api.buzz(10, 'ui'); } } }, 430);
        if (h.k === 'u' && (h.seat !== bottom || !myTurn())) { /* 길게 눌러 보기만 */ }
      } else { sel = null; }
    }
    function zoomInfo(h) {
      if (h.k === 'h') { showZoom(h.id, 'modal'); return; }
      const f = findU(st, h.u); if (!f) return;
      const u = f.u, cd = CARDS[u.id];
      const ks = Object.keys(u.k).filter((k) => !cd.k[k]).map((k) => KW[k].n);
      showZoom(u.id, 'modal', { a: u.a, hp: u.h, extra: (u.e ? '진화함 · ' : '') + (ks.length ? '얻은 능력: ' + ks.join(', ') + ' · ' : '') + (cd.t === 'f' ? '지금 ' + u.a + '/' + u.h : '대기 ' + (u.cd || 0)) });
    }
    function onMove(e) {
      if (!G) return;
      const p = cvs.local(e); ptr = p;
      if (drag) {
        if (!drag.moved && Math.hypot(p.x - drag.sx, p.y - drag.sy) > 9) {
          if (drag.k === 'h' && myTurn()) { drag.moved = true; clearTimeout(lpT); sel = null; api.sfx('tick', { vol: 0.4 }); }
          else if (drag.k === 'u' && drag.seat === bottom && myTurn()) { const f = findU(st, drag.u); if (f && attackTargets(st, bottom, f.u).length) { drag.moved = true; clearTimeout(lpT); sel = { t: 'u', u: drag.u }; } else { clearTimeout(lpT); drag = null; } }
          else { clearTimeout(lpT); drag = null; }
        }
        return;
      }
      if (e.pointerType === 'mouse') {
        const h = hitTest(p);
        const key = h ? h.k + (h.u != null ? h.u : h.t) : '';
        if (key !== (hover && hover.key)) {
          hover = h ? Object.assign({ key, t0: performance.now() }, h) : null;
          if (zoomMode === 'peek') hideZoom();
        } else if (hover && !hover.shown && performance.now() - hover.t0 > 380 && hover.k !== 'L' && !zoomMode) {
          hover.shown = 1;
          if (hover.k === 'h') showZoom(hover.id, 'peek');
          else { const f = findU(st, hover.u); if (f) showZoom(f.u.id, 'peek', { a: f.u.a, hp: f.u.h }); }
        }
      }
    }
    function onUp(e) {
      clearTimeout(lpT);
      if (!drag || !st) { drag = null; return; }
      const p = cvs.local(e); ptr = p;
      const d = drag; drag = null;
      const h = hitTest(p);
      if (d.k === 'h') {
        if (d.moved) { if (p.y < G.handY - 4) tryPlay(d.u, hitTestT(h), p.x); return; }
        if (!myTurn()) { showZoom(d.id, 'modal'); return; }
        if (sel && sel.t === 'h' && sel.u === d.u) { tryPlay(d.u, null, null); return; }
        sel = { t: 'h', u: d.u }; api.sfx('tick', { vol: 0.4 });
        const c = cardBy(d.u); if (c && !playable(st, bottom, c)) tip(reasonNot(c)); else tip('한 번 더 누르거나 판으로 끌어 내세요');
        return;
      }
      if (d.k === 'u') {
        if (d.moved) {
          const t = hitTestT(h);
          const f = findU(st, d.u);
          if (f && t != null && attackTargets(st, bottom, f.u).map(String).includes(String(t))) { send({ t: 'atk', u: d.u, tg: t }); return; }
          sel = null; return;
        }
        if (sel && sel.t === 'u' && d.seat !== bottom) {
          const f = findU(st, sel.u);
          if (f && attackTargets(st, bottom, f.u).map(String).includes(String(d.u))) { send({ t: 'atk', u: sel.u, tg: d.u }); return; }
        }
        if (d.seat === bottom && myTurn()) { sel = (sel && sel.u === d.u) ? null : { t: 'u', u: d.u }; api.sfx('tick', { vol: 0.4 }); if (sel) { const f = findU(st, d.u); const at = f && attackTargets(st, bottom, f.u).length; tip(at ? '공격할 대상을 누르거나 끌어 놓으세요' + (evoReady(st, bottom) && !f.u.e ? ' · 진화 가능' : '') : evoReady(st, bottom) && f && !f.u.e && isFol(f.u) ? '진화할 수 있어요' : '지금은 공격할 수 없어요'); } return; }
        zoomInfo(d.hit); return;
      }
      if (d.k === 'L') {
        if (sel && sel.t === 'u' && d.seat !== bottom) { const f = findU(st, sel.u); if (f && attackTargets(st, bottom, f.u).includes('L' + d.seat)) { send({ t: 'atk', u: sel.u, tg: 'L' + d.seat }); return; } }
        const pl = st.P[d.seat]; api.toast((CLS[pl.cl] || CLS.x).n + ' · 체력 ' + pl.hp + ' · 손패 ' + pl.hd.length + ' · 덱 ' + pl.dk.length);
      }
    }
    cvs.cv.addEventListener('pointerdown', onDown);
    cvs.cv.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    cvs.cv.addEventListener('pointerleave', () => { hover = null; if (zoomMode === 'peek') hideZoom(); });
    const onCancel = (e) => {
      if (zoomMode) { hideZoom(); e.preventDefault(); return; }
      if (tmode || sel || drag) { tmode = null; sel = null; drag = null; tip(''); e.preventDefault(); }
    };
    window.addEventListener('lounge-cancel', onCancel);
    const offKeys = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      if (id === 'end') doEnd();
      else if (id === 'log') toggleLog();
      else if (id === 'evo') { if (myTurn() && sel && sel.t === 'u' && evoReady(st, bottom)) doEvo(sel.u); else if (myTurn()) { const f = st.P[bottom].bd.find((u) => isFol(u) && !u.e); if (f && evoReady(st, bottom)) { sel = { t: 'u', u: f.u }; tip('진화할 추종자를 고르고 V'); } } }
      else if (id === 'next' || id === 'prev') {
        if (!myTurn()) return; const hd = st.P[bottom].hd; if (!hd.length) return;
        let i = sel && sel.t === 'h' ? hd.findIndex((c) => c.u === sel.u) : -1; i = (i + (id === 'next' ? 1 : hd.length - 1)) % hd.length; if (i < 0) i = 0;
        sel = { t: 'h', u: hd[i].u }; showZoom(hd[i].id, 'peek');
      } else if (id === 'play') { if (myTurn() && sel && sel.t === 'h') tryPlay(sel.u, null, null); }
    }) : null;

    /* ── 고르기·멀리건(DOM) ── */
    const PU = makePickUI(ui, api, () => st, (seat, a) => { if (api.actAs) api.actAs(seat, a); else api.act(a); }, (id) => showZoom(id, 'modal'));

    /* ── AI 리더 한마디 ── */
    let emoT = 0;
    function emote(kind, seat) {
      const pl = api.players[seat]; if (!pl || !pl.ai || seat === bottom) return;
      const now = performance.now(); if (now - emoT < 9000 && kind !== 'win' && kind !== 'lose') return; emoT = now;
      const cl = st.P[seat].cl, list = (EMOTE[cl] && EMOTE[cl][kind]) || EMOTE.x[kind]; if (!list) return;
      const line = list[(st.last.id + seat) % list.length];
      bubble = { txt: line, t0: now };
      try {
        if (L.ai && L.ai.enabled && L.ai.enabled(GID) && !api.online) {
          const myId = st.last.id;
          L.ai.ask({ tier: 'fast', maxTokens: 60, system: '카드 대전 게임 속 상대 리더(' + LEAD[cl] + ', ' + CLS[cl].n + ')의 짧은 한마디를 한국어 한 문장(25자 이내)으로. 이모지·따옴표 없이, 상황: ' + EMO_SIT[kind] + '. 예시 말투: ' + line, prompt: '한마디만.' })
            .then((t) => { if (!t || typeof t !== 'string' || !alive) return; t = t.replace(/["'「」]/g, '').trim().split('\n')[0].slice(0, 34); if (t && /[가-힣]/.test(t) && bubble && st.last.id - myId < 6) bubble = { txt: t + ' ✦', t0: performance.now() }; }).catch(() => {});
        }
      } catch (e) {}
    }
    function emoteFrom(nst, pst) {
      if (!nst.last || !pst) return;
      const opp = 1 - bottom;
      if (!api.players[opp] || !api.players[opp].ai) return;
      const evs = nst.last.ev || [];
      if (nst.win != null && pst.win == null) { emote(nst.win === opp ? 'win' : 'lose', opp); return; }
      if (pst.ph === 'mull' && nst.ph === 'play') { emote('hi', opp); return; }
      const big = evs.find((e) => e[0] === 'p' && e[1] === opp && CARDS[e[3]].c >= 7);
      if (big) { emote('big', opp); return; }
      if (evs.some((e) => e[0] === 'e' && nst.last.by === opp)) { emote('evo', opp); return; }
      let hurt = 0; evs.forEach((e) => { if (e[0] === 'd' && e[1] === 'L' + opp) hurt += e[2]; });
      if (hurt >= 5) emote('hurt', opp);
      else if (nst.P[bottom].hp <= 6 && pst.P[bottom].hp > 6) emote('press', opp);
    }

    /* ── 메인 루프 ── */
    const stopLoop = U.loop((dt) => {
      dt = Math.min(0.05, dt > 5 ? dt / 1000 : dt);
      if (A) {
        if (A.stop > 0) A.stop -= dt * 1000; else A.t += dt * 1000;
        for (const ev of A.list) if (!ev.done && A.t >= ev.T) { ev.done = 1; try { fireEv(ev); } catch (er) { console.error(er); } }
        if (A.t >= A.end) { A = null; api.setBusy(false); }
      }
      try { draw(dt); } catch (er) { console.error(er); }
    });
    onArt = () => { bgKey = ''; };

    function layoutDom() {
      if (!G) return;
      const show = st && st.ph === 'play';
      endBtn.style.display = show ? '' : 'none'; logBtn.style.display = show && !G.wide ? '' : 'none';
      endBtn.style.top = (G.mid - 22) + 'px'; endBtn.style.right = Math.max(8, G.w - (G.X0 + G.M) + 8) + 'px';
      logBtn.style.top = (G.mid - 22) + 'px'; logBtn.style.left = (G.X0 + 6) + 'px'; logBtn.style.right = 'auto';
      tipEl.style.top = (G.mid - 17) + 'px'; tipEl.style.bottom = 'auto';
      if (G.wide) { logEl.style.right = '8px'; logEl.style.top = '8px'; logEl.style.bottom = '8px'; logEl.style.width = (G.side - 8) + 'px'; logEl.style.left = 'auto'; }
      else { logEl.style.left = '10px'; logEl.style.right = '10px'; logEl.style.top = (G.topH + 4) + 'px'; logEl.style.bottom = (G.handH + G.meH) + 'px'; logEl.style.width = 'auto'; }
      if (st && st.ph === 'play') {
        const mine = st.cur === bottom && api.canAct(bottom);
        endBtn.disabled = !mine;
        endBtn.textContent = mine ? '턴 종료' : '상대 턴';
        const anyPlay = mine && legalCount() === 0;
        endBtn.classList.toggle('pulse', anyPlay);
      }
      renderLog();
    }
    function legalCount() { try { return legal(st, bottom).length - 1; } catch (e) { return 0; } }
    const domIv = setInterval(layoutDom, 200);

    return {
      update(ns, prev) {
        const old = st; st = ns;
        if (api.viewer() >= 0 && st.ph === 'play') bottom = api.viewer();
        else if (st.ph === 'play' && !api.players.some((p) => p.local && !p.ai)) bottom = 0;
        if (old && st.ph === 'play' && old.ph === 'play' && st.last && old.last && st.last.id !== old.last.id) {
          if (A) { A = null; api.setBusy(false); }
          // 내 선택 정리
          if (sel && sel.t === 'h' && !cardBy(sel.u)) sel = null;
          if (sel && sel.t === 'u' && !findU(st, sel.u)) sel = null;
          if (tmode) tmode = null;
          startAnim(st, old);
          emoteFrom(st, old);
        } else if (old && old.ph === 'mull' && st.ph === 'play') {
          if (A) { A = null; api.setBusy(false); }
          startAnim(st, old); emoteFrom(st, old);
        }
        bgKey = bgKey && st.P[0].cl + st.P[1].cl ? bgKey : '';
        PU.update(st);
        layoutDom();
      },
      destroy() {
        alive = false; stopLoop(); clearInterval(domIv); clearTimeout(lpT); clearTimeout(tipT);
        window.removeEventListener('pointerup', onUp); window.removeEventListener('lounge-cancel', onCancel);
        if (offKeys) offKeys(); PU.destroy(); api.setBusy(false); onArt = null; cvs.destroy(); ui.remove();
      },
    };
  }

  /* ───────── AI 리더 한마디(자료 문장) ───────── */
  const EMO_SIT = { hi: '대전을 시작하며 인사', big: '비싼 카드를 꺼내며 으스댐', evo: '추종자를 진화시키며', hurt: '큰 피해를 입고 분해함', press: '상대를 몰아붙이며', win: '이겼을 때', lose: '졌을 때 깨끗이 인정' };
  const EMOTE = {
    x: { hi: ['잘 부탁해. 봐주진 않아.', '좋은 승부를 하자.', '패는 준비됐어.'], big: ['이건 막기 힘들걸.', '자, 진짜는 지금부터야.'], evo: ['더 강해져라!', '지금이야, 진화!'],
      hurt: ['꽤 아픈데…', '방심했군.', '아직 안 끝났어.'], press: ['이제 끝이 보이네.', '버틸 수 있을까?'], win: ['좋은 승부였어.', '내 덱이 한 수 위였네.'], lose: ['졌다… 다음엔 안 져.', '훌륭했어. 인정할게.'] },
    b: { hi: ['기사단, 전열을 갖춰라!', '정정당당하게 겨루자.'], big: ['기사단의 깃발 아래로!', '진군하라!'], win: ['기사단의 승리다!'] },
    w: { hi: ['숲이 너를 지켜보고 있어.', '바람이 내 편이야.'], big: ['숲의 분노를 받아라!'], win: ['숲은 언제나 이겨.'] },
    a: { hi: ['이론은 끝났어. 실습 시간이야.', '별의 계산은 틀리지 않아.'], big: ['쌓아 둔 마력을 풀어 주지.'], win: ['계산대로야.'] },
    d: { hi: ['용의 숨결을 느껴 봐.', '하늘이 내 편이다.'], big: ['고룡이여, 깨어나라!'], win: ['용 앞에 무릎 꿇어라.'] },
    n: { hi: ['죽음도 내겐 시작일 뿐.', '넋들이 속삭이는군.'], big: ['무덤에서 일어나라!'], win: ['너도 내 군단에 들어오겠나?'] },
    v: { hi: ['피 냄새가 좋은 밤이야.', '우아하게 즐겨 볼까.'], big: ['갈증이 나는군…'], win: ['맛있는 승부였어.'] },
    h: { hi: ['빛이 우리를 이끌기를.', '서두르지 않아. 때가 올 테니.'], big: ['새벽이 밝아온다.'], win: ['빛이 함께했네.'] },
    g: { hi: ['톱니는 벌써 돌고 있어.', '설계도는 완벽해.'], big: ['조립 완료! 가동!'], win: ['계획대로 맞물렸군.'] },
  };

  /* ───────── 덱 저장(이 기기) ───────── */
  const DKEY = 'lounge.cardduel.decks';
  function loadDecks() { try { const v = JSON.parse(localStorage.getItem(DKEY) || '[]'); return Array.isArray(v) ? v.filter((d) => d && validDeck(d.cl, d.d)) : []; } catch (e) { return []; } }
  function allDecks() { try { const v = JSON.parse(localStorage.getItem(DKEY) || '[]'); return Array.isArray(v) ? v : []; } catch (e) { return []; } }
  function saveDecks(l) { try { localStorage.setItem(DKEY, JSON.stringify(l.slice(0, 24))); return true; } catch (e) { return false; } }

  const H = (t, a, ...k) => L.h(t, a, ...k);
  function cardCanvas(id, w, o) {
    const hh = Math.round(w * 1.4), c = H('canvas', { class: 'cd-cc', style: { width: w + 'px', height: hh + 'px' } });
    const dpr = Math.min(2.5, window.devicePixelRatio || 1); c.width = Math.round(w * dpr); c.height = Math.round(hh * dpr);
    const g = c.getContext('2d'); g.scale(dpr, dpr); drawCard(g, id, 1, 1, w - 2, hh - 2, o || {});
    return c;
  }
  function emblemCanvas(cl, s) {
    const c = H('canvas', { style: { width: s + 'px', height: s + 'px' } }); const dpr = Math.min(2.5, window.devicePixelRatio || 1);
    c.width = s * dpr; c.height = s * dpr; const g = c.getContext('2d'); g.scale(dpr, dpr);
    const cls = CLS[cl]; const gr = g.createRadialGradient(s / 2, s / 2, 2, s / 2, s / 2, s / 2); gr.addColorStop(0, shade(cls.col, 0.2)); gr.addColorStop(1, shade(cls.col, -0.5));
    g.fillStyle = gr; g.beginPath(); g.arc(s / 2, s / 2, s / 2 - 1, 0, 7); g.fill(); emblem(g, cls.em, s / 2, s / 2, s * 0.3, '#fff6e4');
    return c;
  }
  function curveBars(ids) {
    const n = [0, 0, 0, 0, 0, 0, 0, 0]; ids.forEach((id) => { n[Math.min(7, CARDS[id].c)]++; });
    const mx = Math.max(1, ...n);
    return H('div', { class: 'cd-curve' }, ...n.map((v, i) => H('div', { class: 'cd-bar' }, H('i', { style: { height: (v / mx * 100) + '%' } }), H('span', { text: i === 7 ? '7+' : String(i) }), H('em', { text: v ? String(v) : '' }))));
  }
  function zoomOverlay(parent, id) {
    const W = Math.min(260, (parent.clientWidth || 360) * 0.7);
    const terms = H('div', { class: 'cd-terms' }); cardKeys(id).slice(0, 6).forEach((t) => terms.append(H('div', {}, H('b', { text: t[0] }), ' ' + t[1])));
    const o = H('div', { class: 'cd-zoom', style: { display: 'flex', position: 'fixed', zIndex: 200 }, onclick: () => o.remove() }, H('div', { class: 'cd-zbox' }, cardCanvas(id, W, { full: true }), terms));
    document.body.append(o);
    return o;
  }

  /* ───────── 덱 만들기 ───────── */
  function deckBuilder(box, o) {
    o = o || {};
    let cl = o.cl || 'b', deck = (o.deck || []).slice(), name = o.name || '', editIdx = o.idx != null ? o.idx : -1;
    let fCost = -1, fType = '', fSrc = '', q = '';
    box.innerHTML = '';
    const wrap = H('div', { class: 'cd-bld' });
    box.append(wrap);
    const head = H('div', { class: 'cd-row' });
    const nameIn = H('input', { class: 'cd-in', placeholder: '덱 이름', value: name, maxlength: 16, oninput: (e) => { name = e.target.value; } });
    head.append(H('button', { class: 'btn sm ghost', text: '‹ 돌아가기', onclick: () => o.onClose && o.onClose(null) }), H('b', { class: 'cd-h', text: '🛠 덱 만들기' }), nameIn);
    const clRow = H('div', { class: 'cd-chips' });
    const filt = H('div', { class: 'cd-chips' });
    const search = H('input', { class: 'cd-in', placeholder: '이름·효과 검색', oninput: (e) => { q = e.target.value.trim(); drawGrid(); } });
    const grid = H('div', { class: 'cd-grid' });
    const side = H('div', { class: 'cd-deck' });
    wrap.append(head, clRow, filt, search, H('div', { class: 'cd-bbody' }, grid, side));
    function setCl(c) {
      if (c === cl) return;
      if (deck.some((id) => CARDS[id].cl !== 'x') && !confirm('직업을 바꾸면 직업 카드는 빠져요. 바꿀까요?')) return;
      cl = c; deck = deck.filter((id) => CARDS[id].cl === 'x'); drawAll();
    }
    function drawChips() {
      clRow.innerHTML = '';
      CL_ORDER.forEach((c) => clRow.append(H('button', { class: 'cd-chip' + (c === cl ? ' on' : ''), style: { '--c': CLS[c].col }, onclick: () => setCl(c) }, emblemCanvas(c, 20), CLS[c].s)));
      filt.innerHTML = '';
      [[-1, '전체'], [1, '≤1'], [2, '2'], [3, '3'], [4, '4'], [5, '5'], [6, '6'], [7, '7+']].forEach(([v, t]) => filt.append(H('button', { class: 'cd-chip sm' + (fCost === v ? ' on' : ''), text: t, onclick: () => { fCost = v; drawChips(); drawGrid(); } })));
      [['', '모든 종류'], ['f', '추종자'], ['s', '주문'], ['a', '마법진']].forEach(([v, t]) => filt.append(H('button', { class: 'cd-chip sm' + (fType === v ? ' on' : ''), text: t, onclick: () => { fType = v; drawChips(); drawGrid(); } })));
      [['', '직업+공용'], ['c', '직업만'], ['x', '공용만']].forEach(([v, t]) => filt.append(H('button', { class: 'cd-chip sm' + (fSrc === v ? ' on' : ''), text: t, onclick: () => { fSrc = v; drawChips(); drawGrid(); } })));
    }
    function count(id) { return deck.filter((x) => x === id).length; }
    function matches(id) {
      const c = CARDS[id];
      if (fCost >= 0 && (fCost === 1 ? c.c > 1 : fCost === 7 ? c.c < 7 : c.c !== fCost)) return false;
      if (fType && c.t !== fType) return false;
      if (fSrc === 'c' && c.cl !== cl) return false;
      if (fSrc === 'x' && c.cl !== 'x') return false;
      if (q && !(c.n + ' ' + cardText(id).join(' ')).includes(q)) return false;
      return true;
    }
    function drawGrid() {
      grid.innerHTML = '';
      const pool = classPool(cl).filter(matches).sort((a, b) => CARDS[a].c - CARDS[b].c || (CARDS[a].cl === 'x') - (CARDS[b].cl === 'x') || (a < b ? -1 : 1));
      const w = Math.max(74, Math.min(104, ((box.clientWidth || 360) - 40) / 4 - 6));
      pool.forEach((id) => {
        const n = count(id);
        const cell = H('div', { class: 'cd-cell' + (n >= COPIES ? ' full' : ''), title: CARDS[id].n + ' — ' + cardText(id).join(' ') }, cardCanvas(id, w), H('span', { class: 'cd-cnt', text: n + '/' + COPIES }));
        let lp = 0, long = false;
        cell.addEventListener('pointerdown', () => { long = false; lp = setTimeout(() => { long = true; zoomOverlay(box, id); }, 430); });
        cell.addEventListener('pointerup', () => { clearTimeout(lp); if (long) return; add(id); });
        cell.addEventListener('pointerleave', () => clearTimeout(lp));
        cell.addEventListener('contextmenu', (e) => { e.preventDefault(); clearTimeout(lp); zoomOverlay(box, id); });
        grid.append(cell);
      });
      if (!pool.length) grid.append(H('p', { class: 'muted', text: '맞는 카드가 없어요' }));
    }
    function add(id) {
      if (deck.length >= DECK) { L.toast && L.toast('40장이 가득 찼어요'); return; }
      if (count(id) >= COPIES) { L.toast && L.toast('같은 카드는 ' + COPIES + '장까지'); return; }
      deck.push(id); L.sfx && L.sfx('card'); drawSide(); drawGrid();
    }
    function rm(id) { const i = deck.indexOf(id); if (i >= 0) deck.splice(i, 1); drawSide(); drawGrid(); }
    function drawSide() {
      side.innerHTML = '';
      const ok = validDeck(cl, deck);
      side.append(H('div', { class: 'cd-dhead' }, H('b', { text: '덱 ' + deck.length + '/' + DECK }), H('span', { class: 'muted', text: ok ? ' 완성!' : ' 40장을 채워 주세요' })), curveBars(deck));
      const list = H('div', { class: 'cd-dlist' });
      const uniq = [...new Set(deck)].sort((a, b) => CARDS[a].c - CARDS[b].c || (a < b ? -1 : 1));
      uniq.forEach((id) => list.append(H('button', { class: 'cd-drow', style: { '--c': (CLS[CARDS[id].cl] || CLS.x).col }, title: '눌러서 빼기', onclick: () => rm(id) }, H('i', { text: String(CARDS[id].c) }), H('span', { text: CARDS[id].n }), H('em', { text: '×' + count(id) }))));
      side.append(list);
      side.append(H('div', { class: 'cd-row' },
        H('button', { class: 'btn sm', text: '자동 채우기', onclick: () => { const pre = presetDeck(cl); for (const id of pre) { if (deck.length >= DECK) break; if (count(id) < COPIES && pre.filter((x) => x === id).length > count(id)) deck.push(id); } let k = 0; while (deck.length < DECK && k++ < 200) { const p = classPool(cl); const id = p[rnd(p.length)]; if (count(id) < 2) deck.push(id); } drawSide(); drawGrid(); } }),
        H('button', { class: 'btn sm ghost', text: '비우기', onclick: () => { if (deck.length && confirm('덱을 비울까요?')) { deck = []; drawSide(); drawGrid(); } } }),
        H('button', { class: 'btn sm primary', text: '💾 저장', disabled: !ok, onclick: () => {
          const l = allDecks(); const d = { n: (name || CLS[cl].s + ' 덱').slice(0, 16), cl, d: deck.slice() };
          if (editIdx >= 0 && l[editIdx]) l[editIdx] = d; else { l.unshift(d); editIdx = 0; }
          if (saveDecks(l)) { L.toast && L.toast('덱을 저장했어요'); o.onClose && o.onClose(d); } else L.toast && L.toast('저장하지 못했어요');
        } })));
      const saved = allDecks();
      if (saved.length) {
        const sl = H('div', { class: 'cd-saved' }, H('div', { class: 'muted', text: '저장한 덱 (눌러서 고치기)' }));
        saved.forEach((d, i) => sl.append(H('div', { class: 'cd-row' },
          H('button', { class: 'cd-chip', style: { '--c': (CLS[d.cl] || CLS.x).col }, onclick: () => { cl = d.cl; deck = d.d.slice(); name = d.n; nameIn.value = name; editIdx = i; drawAll(); } }, CLS[d.cl] ? emblemCanvas(d.cl, 18) : '', d.n + ' (' + (d.d || []).length + ')'),
          H('button', { class: 'cd-chip sm', text: '🗑', title: '지우기', onclick: () => { if (confirm('「' + d.n + '」 덱을 지울까요?')) { const l = allDecks(); l.splice(i, 1); saveDecks(l); if (editIdx === i) editIdx = -1; drawSide(); } } }))));
        side.append(sl);
      }
    }
    function drawAll() { drawChips(); drawGrid(); drawSide(); }
    drawAll();
  }

  /* ───────── 고르기 · 멀리건 화면 ───────── */
  function makePickUI(ui, api, getSt, actAs, zoom) {
    const el = H('div', { class: 'cd-pick', style: { display: 'none', pointerEvents: 'auto' } });
    ui.append(el);
    let gate = {}, selCl = null, selDeck = 'pre', mull = new Set(), sig = '', pbar = null, building = false;
    const multi = () => api.players.filter((p) => p.local && !p.ai).length > 1;
    function pending(st) { const a = actor(st); if (!Array.isArray(a)) return -1; const m = a.filter((s) => api.canAct(s)); return m.length ? m[0] : -1; }
    function render(force) {
      const st = getSt(); if (!st) return;
      if (st.ph !== 'pick' && st.ph !== 'mull') { el.style.display = 'none'; if (pbar) { pbar.destroy(); pbar = null; } gate = {}; return; }
      if (building) return;
      const seat = pending(st);
      const key = [st.ph, seat, st.last.id, selCl, selDeck, [...mull].join(','), gate[seat], el.clientWidth > 640].join('|');
      if (key === sig && !force) return; sig = key;
      el.style.display = 'flex'; el.innerHTML = '';
      const inner = H('div', { class: 'cd-pin' }); el.append(inner);
      if (st.ph === 'pick' && st.P.some((p, i) => !p.ok) && api.players.some((p) => !p.ai)) {
        if (!pbar) pbar = api.pickBar({ picked: (s) => { const t = getSt(); return !!(t && t.P[s] && t.P[s].ok) || !!(t && t.ph !== 'pick'); }, onForce: () => { const t = getSt(); if (t && t.ph === 'pick' && api.isHost && api.setState) api.setState(forcePick(JSON.parse(JSON.stringify(t)))); }, parent: el, style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none', margin: '8px auto' } });
        else el.append(pbar.el);
      } else if (pbar) { pbar.destroy(); pbar = null; }
      if (seat < 0) {
        const done = st.ph === 'pick' ? '상대가 덱을 고르는 중이에요…' : '상대가 카드를 바꾸는 중이에요…';
        inner.append(H('div', { class: 'cd-wait' }, H('div', { class: 'cd-spin' }), H('p', { text: done })));
        if (pbar) el.append(pbar.el);
        return;
      }
      const pl = api.players[seat], p = st.P[seat];
      if (multi() && gate[seat] !== st.ph) {
        inner.append(H('div', { class: 'cd-wait' }, H('span', { class: 'dot', style: { '--c': pl.color, width: '18px', height: '18px' } }), H('h2', { class: 'cd-h', text: pl.name }), H('p', { class: 'muted', text: '다른 사람이 보지 않게 폰을 넘겨주세요' }),
          H('button', { class: 'btn primary', 'data-key': 'Enter', text: st.ph === 'pick' ? '덱 고르기' : '내 패 보기', onclick: () => { gate[seat] = st.ph; render(true); } })));
        return;
      }
      if (st.ph === 'pick' && st.mode === 'std') renderStd(inner, st, seat, pl);
      else if (st.ph === 'pick') renderDraft(inner, st, seat, pl, p);
      else renderMull(inner, st, seat, pl, p);
      if (pbar) el.append(pbar.el);
    }
    function renderStd(box, st, seat, pl) {
      const decks = loadDecks();
      if (!selCl) selCl = (decks[0] && decks[0].cl) || CL_ORDER[rnd(8)];
      box.append(H('h2', { class: 'cd-h', text: '덱 고르기' + (multi() ? ' — ' + pl.name : '') }));
      const tiles = H('div', { class: 'cd-tiles' });
      CL_ORDER.forEach((c) => tiles.append(H('button', { class: 'cd-tile' + (c === selCl ? ' on' : ''), style: { '--c': CLS[c].col }, title: CLS[c].d, onclick: () => { selCl = c; selDeck = 'pre'; render(true); } }, emblemCanvas(c, 34), H('b', { text: CLS[c].n }), H('small', { text: CLS[c].arch }))));
      box.append(tiles);
      const cls = CLS[selCl];
      box.append(H('p', { class: 'cd-desc' }, H('b', { text: LEAD[selCl] + ' · ' + cls.n }), ' — ' + cls.d));
      const mine = decks.map((d, i) => [d, i]).filter(([d]) => d.cl === selCl);
      const list = H('div', { class: 'cd-dsel' });
      const row = (k, label, ids) => list.append(H('button', { class: 'cd-drow2' + (selDeck === k ? ' on' : ''), onclick: () => { selDeck = k; render(true); } }, H('b', { text: label }), curveBars(ids)));
      row('pre', '추천 덱 (기본)', presetDeck(selCl));
      mine.forEach(([d, i]) => row('s' + i, '💾 ' + d.n, d.d));
      box.append(list);
      const pickDeck = () => { if (selDeck === 'pre') return { t: 'deck', cl: selCl, pre: 1, n: CLS[selCl].s + ' 추천 덱' }; const d = decks[+selDeck.slice(1)]; return d ? { t: 'deck', cl: d.cl, d: d.d, n: d.n } : { t: 'deck', cl: selCl, pre: 1 }; };
      box.append(H('div', { class: 'cd-row center' },
        H('button', { class: 'btn ghost', text: '🛠 덱 만들기', onclick: () => openBuilder(selDeck === 'pre' ? { cl: selCl, deck: presetDeck(selCl), name: CLS[selCl].s + ' 내 덱' } : (() => { const i = +selDeck.slice(1); const d = decks[i]; return { cl: d.cl, deck: d.d, name: d.n, idx: allDecks().findIndex((x) => x.n === d.n && x.cl === d.cl) }; })()) }),
        H('button', { class: 'btn primary', 'data-key': 'Enter', text: '이 덱으로 시작', onclick: () => { api.sfx('click'); actAs(seat, pickDeck()); } })));
    }
    function openBuilder(o) {
      building = true; el.innerHTML = '';
      const box = H('div', { class: 'cd-pin wide' }); el.append(box);
      deckBuilder(box, Object.assign({}, o, { onClose: (d) => { building = false; if (d) { const l = loadDecks(); const i = l.findIndex((x) => x.n === d.n && x.cl === d.cl); selCl = d.cl; selDeck = i >= 0 ? 's' + i : 'pre'; } render(true); } }));
    }
    function renderDraft(box, st, seat, pl, p) {
      if (!p.cl) {
        box.append(H('h2', { class: 'cd-h', text: '드래프트 — 직업 고르기' }), H('p', { class: 'muted', text: '셋 중 하나를 고르면, 카드 3장 중 1장을 20번 골라 40장 덱을 만들어요(고른 카드는 2장씩).' }));
        const tiles = H('div', { class: 'cd-tiles three' });
        p.dr.co.forEach((c, k) => tiles.append(H('button', { class: 'cd-tile', style: { '--c': CLS[c].col }, onclick: () => { api.sfx('click'); actAs(seat, { t: 'dcl', k }); } }, emblemCanvas(c, 44), H('b', { text: CLS[c].n }), H('small', { text: CLS[c].d }))));
        box.append(tiles); return;
      }
      box.append(H('h2', { class: 'cd-h', text: '카드 고르기 ' + (p.dr.pk.length + 1) + ' / ' + DRAFT_PICKS }), H('p', { class: 'muted', text: CLS[p.cl].n + ' · 하나를 누르면 2장이 덱에 들어가요 · 길게 누르면 크게 보기' }));
      const row = H('div', { class: 'cd-offer' });
      const W = Math.max(96, Math.min(150, ((el.clientWidth || 360) - 40) / 3 - 8));
      p.dr.off.forEach((id, k) => {
        const c = cardCanvas(id, W, { full: W >= 130 });
        let lp = 0, long = false;
        const b = H('button', { class: 'cd-ocard' }, c, H('small', { text: TYPE_N[CARDS[id].t] + ' · ' + RAR[CARDS[id].r] }));
        b.addEventListener('pointerdown', () => { long = false; lp = setTimeout(() => { long = true; zoom(id); }, 430); });
        b.addEventListener('pointerup', () => { clearTimeout(lp); if (!long) { api.sfx('card'); actAs(seat, { t: 'dp', k }); } });
        b.addEventListener('pointerleave', () => clearTimeout(lp));
        row.append(b);
      });
      box.append(row, H('div', { class: 'muted', style: { margin: '6px 0 2px' }, text: '지금까지 고른 카드' }), curveBars(p.dk));
    }
    function renderMull(box, st, seat, pl, p) {
      const first = seat === 0;
      box.append(H('h2', { class: 'cd-h', text: '첫 손패 — 바꿀 카드 고르기' }),
        H('p', { class: 'muted', text: (first ? '선공이에요 · 진화는 5번째 턴부터 2번' : '후공이에요 · 진화는 4번째 턴부터 3번') + ' · 바꿀 카드를 누르세요' }));
      const row = H('div', { class: 'cd-offer' });
      const W = Math.max(96, Math.min(150, ((el.clientWidth || 360) - 40) / 3 - 8));
      p.hd.forEach((c) => {
        const on = mull.has(c.u);
        const b = H('button', { class: 'cd-ocard' + (on ? ' swap' : '') }, cardCanvas(c.id, W, { full: W >= 130 }), H('small', { text: on ? '↻ 바꿈' : '그대로' }));
        let lp = 0, long = false;
        b.addEventListener('pointerdown', () => { long = false; lp = setTimeout(() => { long = true; zoom(c.id); }, 430); });
        b.addEventListener('pointerup', () => { clearTimeout(lp); if (long) return; if (mull.has(c.u)) mull.delete(c.u); else mull.add(c.u); api.sfx('tick'); render(true); });
        b.addEventListener('pointerleave', () => clearTimeout(lp));
        row.append(b);
      });
      box.append(row, H('div', { class: 'cd-row center' }, H('button', { class: 'btn primary', 'data-key': 'Enter', text: mull.size ? mull.size + '장 바꾸고 시작' : '이대로 시작', onclick: () => { const sw = [...mull]; mull = new Set(); api.sfx('click'); actAs(seat, { t: 'mull', sw }); } })),
        H('p', { class: 'muted small', text: '팁: 4코스트 이상 카드를 바꾸면 초반이 편해요.' }));
    }
    const iv = setInterval(() => render(false), 400);
    return { update() { render(false); }, destroy() { clearInterval(iv); if (pbar) pbar.destroy(); el.remove(); } };
  }

  /* ───────── 도감 ───────── */
  function codex(el, cx) {
    el.innerHTML = '';
    const st = H('style', { text: CSS }); el.append(st);
    let fCl = 'all', fCost = -1, fType = '', fKw = '', q = '';
    const top = H('div', { class: 'cd-row' }, H('b', { class: 'cd-h', text: '카드 ' + ORDER.length + '장' }), H('button', { class: 'btn sm', text: '🛠 덱 만들기', onclick: () => { const box = H('div', { class: 'cd-pin wide', style: { position: 'relative' } }); el.innerHTML = ''; el.append(st, box); deckBuilder(box, { cl: fCl !== 'all' && fCl !== 'x' && fCl !== 'tok' ? fCl : 'b', onClose: () => codex(el, cx) }); } }));
    const chips = H('div', { class: 'cd-chips' }), chips2 = H('div', { class: 'cd-chips' });
    const search = H('input', { class: 'cd-in', placeholder: '이름·효과 검색 (예: 수호, 피해)', oninput: (e) => { q = e.target.value.trim(); grid(); } });
    const g = H('div', { class: 'cd-grid' });
    const info = H('div', { class: 'muted small' });
    el.append(top, chips, chips2, search, info, g);
    function drawChips() {
      chips.innerHTML = '';
      [['all', '전체']].concat(CL_ORDER.map((c) => [c, CLS[c].s]), [['x', '공용'], ['tok', '토큰']]).forEach(([v, t]) => chips.append(H('button', { class: 'cd-chip' + (fCl === v ? ' on' : ''), style: CLS[v] ? { '--c': CLS[v].col } : {}, onclick: () => { fCl = v; drawChips(); grid(); } }, CLS[v] && v !== 'x' ? emblemCanvas(v, 18) : '', t)));
      chips2.innerHTML = '';
      [[-1, '모든 코스트'], [1, '≤1'], [2, '2'], [3, '3'], [4, '4'], [5, '5'], [6, '6'], [7, '7+']].forEach(([v, t]) => chips2.append(H('button', { class: 'cd-chip sm' + (fCost === v ? ' on' : ''), text: t, onclick: () => { fCost = v; drawChips(); grid(); } })));
      [['', '모든 종류'], ['f', '추종자'], ['s', '주문'], ['a', '마법진']].forEach(([v, t]) => chips2.append(H('button', { class: 'cd-chip sm' + (fType === v ? ' on' : ''), text: t, onclick: () => { fType = v; drawChips(); grid(); } })));
      [['', '모든 능력']].concat(Object.keys(KW).map((k) => [k, KW[k].n])).forEach(([v, t]) => chips2.append(H('button', { class: 'cd-chip sm' + (fKw === v ? ' on' : ''), text: t, onclick: () => { fKw = v; drawChips(); grid(); } })));
    }
    function grid() {
      g.innerHTML = '';
      const ids = (fCl === 'tok' ? Object.keys(CARDS).filter((id) => CARDS[id].tok) : ORDER).filter((id) => {
        const c = CARDS[id];
        if (fCl !== 'all' && fCl !== 'tok' && c.cl !== fCl) return false;
        if (fCost >= 0 && (fCost === 1 ? c.c > 1 : fCost === 7 ? c.c < 7 : c.c !== fCost)) return false;
        if (fType && c.t !== fType) return false;
        if (fKw && !c.k[fKw] && !c.fx.some((f) => f.k === fKw)) return false;
        if (q && !(c.n + ' ' + cardText(id).join(' ') + ' ' + (CLS[c.cl] || CLS.x).n).includes(q)) return false;
        return true;
      }).sort((a, b) => CARDS[a].c - CARDS[b].c || (a < b ? -1 : 1));
      info.textContent = ids.length + '장 · 누르면 크게 보기';
      const w = Math.max(80, Math.min(112, ((el.clientWidth || 360) - 30) / 4 - 6));
      ids.forEach((id) => g.append(H('button', { class: 'cd-cell', title: CARDS[id].n, onclick: () => zoomOverlay(el, id) }, cardCanvas(id, w))));
    }
    drawChips(); grid();
  }

  const CSS = `
  .cd-ui .btn{min-height:44px}
  .cd-end{position:absolute;min-width:88px;z-index:5}
  .cd-end.pulse{animation:cdpulse 1.1s ease-in-out infinite}
  @keyframes cdpulse{0%,100%{box-shadow:0 0 0 0 rgba(227,174,69,.0)}50%{box-shadow:0 0 0 6px rgba(227,174,69,.45)}}
  .cd-logb{position:absolute;z-index:5;min-width:44px;padding:0 8px}
  .cd-log{position:absolute;display:none;overflow:auto;background:rgba(18,14,26,.92);border:1px solid rgba(227,174,69,.3);border-radius:12px;padding:8px 10px;font-size:12.5px;z-index:6;color:var(--ink)}
  .cd-log.wide{background:rgba(18,14,26,.6)}
  .cd-logh{font-family:var(--f-display);color:var(--brass);margin-bottom:4px}
  .cd-logt{color:var(--brass);margin-top:6px}.cd-logl{color:var(--ink);opacity:.9;padding-left:6px;line-height:1.35}
  .cd-tip{position:absolute;left:50%;transform:translateX(-50%);bottom:calc(22% + 70px);display:none;background:rgba(18,14,26,.9);color:var(--ink);border:1px solid rgba(227,174,69,.4);padding:6px 12px;border-radius:999px;font-size:13px;white-space:nowrap;max-width:92%;overflow:hidden;text-overflow:ellipsis;z-index:7}
  .cd-zoom{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(8,5,14,.72);z-index:40}
  .cd-zoom.peek{background:none;justify-content:flex-end;align-items:flex-start;padding:70px 12px 0}
  .cd-zbox{display:flex;flex-direction:column;align-items:center;gap:8px;max-width:300px}
  .cd-zoom.peek .cd-zbox{max-width:260px}
  .cd-terms{background:rgba(18,14,26,.94);border:1px solid rgba(227,174,69,.3);border-radius:10px;padding:8px 10px;font-size:12.5px;line-height:1.4;color:var(--ink);display:flex;flex-direction:column;gap:3px;max-width:290px}
  .cd-terms b{color:var(--brass)}
  .cd-pick{position:absolute;inset:0;background:radial-gradient(ellipse at top,#2a2140,#120e1c);overflow:auto;flex-direction:column;align-items:center;z-index:20;color:var(--ink)}
  .cd-pin{width:100%;max-width:760px;padding:12px 12px 16px;box-sizing:border-box;display:flex;flex-direction:column;gap:8px}
  .cd-pin.wide{max-width:1100px;height:100%}
  .cd-h{font-family:var(--f-display);font-size:20px;margin:2px 0;color:var(--ink);font-weight:400}
  .cd-tiles{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
  .cd-tiles.three{grid-template-columns:repeat(3,1fr)}
  .cd-tile{display:flex;flex-direction:column;align-items:center;gap:3px;padding:8px 4px;min-height:44px;border-radius:12px;border:1.5px solid rgba(255,255,255,.1);background:linear-gradient(180deg,color-mix(in srgb,var(--c) 30%,#1e1830),#1a1526);color:var(--ink);cursor:pointer;font:inherit}
  .cd-tile b{font-size:12.5px;font-weight:600;text-align:center}.cd-tile small{font-size:11px;color:var(--muted);text-align:center;line-height:1.25}
  .cd-tile.on{border-color:var(--brass);box-shadow:0 0 0 2px rgba(227,174,69,.35)}
  .cd-desc{font-size:13px;line-height:1.45;margin:2px 0}
  .cd-dsel{display:flex;flex-direction:column;gap:6px}
  .cd-drow2{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:48px;padding:6px 10px;border-radius:10px;border:1.5px solid rgba(255,255,255,.1);background:#1e1830;color:var(--ink);font:inherit;cursor:pointer;text-align:left}
  .cd-drow2.on{border-color:var(--brass)}
  .cd-curve{display:flex;gap:3px;align-items:flex-end;height:38px;margin-top:12px}
  .cd-bar{display:flex;flex-direction:column;align-items:center;width:16px;height:100%;justify-content:flex-end;position:relative}
  .cd-bar i{display:block;width:10px;background:linear-gradient(#ffd27a,#c98a1a);border-radius:2px;min-height:1px}
  .cd-bar span{font-size:10px;color:var(--muted);font-family:var(--f-mono)}.cd-bar em{position:absolute;top:-13px;font-size:9px;font-style:normal;color:var(--ink)}
  .cd-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.cd-row.center{justify-content:center;margin-top:6px}
  .cd-wait{display:flex;flex-direction:column;align-items:center;gap:10px;margin:18vh auto 0;text-align:center}
  .cd-spin{width:34px;height:34px;border-radius:50%;border:3px solid rgba(227,174,69,.25);border-top-color:var(--brass);animation:cdspin 1s linear infinite}
  @keyframes cdspin{to{transform:rotate(360deg)}}
  .cd-offer{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
  .cd-ocard{display:flex;flex-direction:column;align-items:center;gap:4px;background:none;border:2px solid transparent;border-radius:12px;padding:3px;color:var(--ink);font:inherit;cursor:pointer;transition:transform .12s}
  .cd-ocard:hover{transform:translateY(-4px)}
  .cd-ocard.swap{border-color:var(--coral);opacity:.75}
  .cd-ocard small{font-size:12px;color:var(--muted)}
  .cd-chips{display:flex;gap:5px;flex-wrap:wrap}
  .cd-chip{display:inline-flex;align-items:center;gap:4px;min-height:36px;padding:3px 9px;border-radius:999px;border:1.5px solid rgba(255,255,255,.12);background:#221c2e;color:var(--ink);font:inherit;font-size:12.5px;cursor:pointer}
  .cd-chip.sm{min-height:32px;font-size:12px;padding:2px 8px}
  .cd-chip.on{border-color:var(--brass);background:color-mix(in srgb,var(--c,#e3ae45) 35%,#221c2e)}
  .cd-in{min-height:40px;border-radius:10px;border:1px solid rgba(255,255,255,.15);background:#17131f;color:var(--ink);padding:0 10px;font:inherit;flex:1;min-width:120px}
  .cd-grid{display:flex;flex-wrap:wrap;gap:6px;align-content:flex-start;justify-content:center}
  .cd-cell{position:relative;background:none;border:0;padding:0;cursor:pointer;touch-action:manipulation}
  .cd-cell.full{opacity:.45}
  .cd-cnt{position:absolute;right:3px;top:3px;background:rgba(10,6,16,.85);color:#ffd27a;font:11px var(--f-mono);padding:1px 5px;border-radius:8px}
  .cd-bld{display:flex;flex-direction:column;gap:6px;height:100%;min-height:0}
  .cd-bbody{display:flex;gap:8px;flex:1;min-height:0}
  .cd-bld .cd-grid{flex:1;overflow:auto;min-height:200px}
  .cd-deck{width:230px;flex:none;display:flex;flex-direction:column;gap:6px;overflow:auto;background:rgba(0,0,0,.25);border-radius:10px;padding:8px}
  @media (max-width:640px){.cd-bbody{flex-direction:column}.cd-deck{width:auto;max-height:38vh}}
  .cd-dlist{display:flex;flex-direction:column;gap:2px}
  .cd-drow{display:flex;gap:6px;align-items:center;min-height:30px;padding:2px 6px;border-radius:6px;border:0;border-left:4px solid var(--c);background:#221c2e;color:var(--ink);font:inherit;font-size:12.5px;cursor:pointer;text-align:left}
  .cd-drow i{font:bold 12px var(--f-mono);color:#9fd0ff;width:18px;font-style:normal}.cd-drow span{flex:1}.cd-drow em{font-style:normal;color:var(--brass)}
  .cd-saved{display:flex;flex-direction:column;gap:4px;margin-top:6px}
  .small{font-size:12px}
  `;

  function hint(s, seat) {
    if (!s || s.win != null) return null;
    if (s.ph === 'pick') return ['덱 고르기', '직업 8개 중 하나와 덱(추천 덱 또는 내가 만든 덱)을 골라요.', '드래프트 모드면 직업 하나를 고른 뒤, 카드 3장 중 1장을 20번 골라요.'];
    if (s.ph === 'mull') return ['첫 손패 바꾸기', '바꾸고 싶은 카드를 눌러 표시하고 확정하세요. 바꾼 카드는 덱에 섞여요.', '선공은 진화 5턴부터 2번, 후공은 4턴부터 3번.'];
    const me = seat >= 0 ? seat : s.cur, p = s.P[me], o = s.P[op(me)];
    const out = [(s.cur === me ? '내 턴' : '상대 턴') + ' · PP ' + p.pp + '/' + p.mp + ' · 체력 ' + p.hp + ' vs ' + o.hp];
    if (s.cur === me) {
      const pl = p.hd.filter((c) => playable(s, me, c)).length;
      out.push('낼 수 있는 카드 ' + pl + '장 · 공격할 수 있는 추종자 ' + p.bd.filter((u) => attackTargets(s, me, u).length).length + '명');
      if (evoReady(s, me)) out.push('이번 턴에 진화할 수 있어요(남은 ' + p.ep + '번). 추종자를 눌러 「진화」.');
      else if (p.own < EVO_TURN[me]) out.push('진화는 ' + EVO_TURN[me] + '번째 내 턴부터 (지금 ' + p.own + '번째)');
      const wards = o.bd.filter((u) => isFol(u) && u.k.ward && !u.k.amb);
      if (wards.length) out.push('상대에게 수호 ' + wards.length + '명 — 수호부터 공격해야 해요.');
      let pot = 0; p.bd.forEach((u) => { if (canAttack(u) && (!u.sk || u.k.storm)) pot += u.a; });
      if (!wards.length && pot >= o.hp) out.push('지금 리더를 공격하면 이길 수 있어요!');
    }
    if (p.cl === 'n') out.push('넋 ' + p.so); if (p.cl === 'a') out.push('쓴 주문 ' + p.sp + '장'); if (p.cl === 'g') out.push('쓴 부품 ' + p.pc + '장');
    if (p.cl === 'v') out.push(p.hp <= 10 ? '갈증 상태! (체력 10 이하)' : '체력 10 이하가 되면 갈증');
    if (p.cl === 'd') out.push(p.mp >= 7 ? '각성 상태! (최대 PP 7 이상)' : '최대 PP 7부터 각성');
    return out.slice(0, 6);
  }
  function panelInfo(s, seat) {
    if (!s || !s.P[0].cl) return null;
    return s.P.map((p, i) => ({ label: (s.names[i] || '') + ' · ' + (CLS[p.cl] ? CLS[p.cl].s : ''), value: '체력 ' + p.hp + ' · PP ' + p.mp + ' · 손 ' + p.hd.length }));
  }
  function preview(cv) {
    const g = cv.getContext('2d'), w = cv.width, h = cv.height;
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#1b1530'); gr.addColorStop(1, '#2a1830'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const ids = ['b18', 'a14', 'd16', 'n13', 'v18'];
    ids.forEach((id, i) => { const cw = 110, ch = 154, x = w / 2 - cw / 2 + (i - 2) * 96, y = 110 + Math.abs(i - 2) * 16; g.save(); g.translate(x + cw / 2, y + ch / 2); g.rotate((i - 2) * 0.12); drawCard(g, id, -cw / 2, -ch / 2, cw, ch, {}); g.restore(); });
    g.fillStyle = '#f2e9d8'; g.font = '34px ' + FONT_D; g.textAlign = 'center'; g.fillText('수집 카드 대전', w / 2, 60);
  }

  L.register({
    id: GID, name: '수집 카드 대전', tag: '카드 배틀', cat: '카드', hidden: true, aiNarration: true,
    blurb: '8개 직업의 덱으로 겨루는 1:1 카드 배틀. 추종자를 내고 진화시켜, 상대 리더의 체력 20을 먼저 0으로 만들면 이겨요.',
    time: '10–20분', minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, aiDelay: 800, save: true, undo: false, sidePanel: false,
    saveLabel: (s) => s.ph === 'play' ? s.tn + '턴 · ' + s.P.map((p) => (CLS[p.cl] || CLS.x).s + ' ' + p.hp).join(' vs ') : '덱 고르는 중',
    tint: '#3a1f4a',
    icon: '<rect x="9" y="12" width="22" height="32" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-12 20 28)"/><rect x="25" y="10" width="22" height="32" rx="3" fill="currentColor" opacity=".9" transform="rotate(10 36 26)"/><path d="M36 18l2.5 5 5.5.8-4 3.9 1 5.5-5-2.6-5 2.6 1-5.5-4-3.9 5.5-.8z" fill="#17131f" transform="rotate(10 36 26)"/>',
    options: [
      { id: 'mode', label: '대전 방식', tip: '어떤 덱으로 겨룰지 정해요.', def: 'std', choices: [
        { v: 'std', label: '내 덱 대전', tip: '직업별 추천 덱이나 「덱 만들기」로 만든 내 덱(40장, 같은 카드 3장까지)으로 겨뤄요.' },
        { v: 'draft', label: '드래프트', tip: '직업 3개 중 하나를 고르고, 카드 3장 중 1장을 20번 골라(2장씩) 그 자리에서 덱을 만들어요.' }] },
    ],
    quick: [
      '상대 리더의 체력 20을 먼저 0으로 만들면 이겨요.',
      '내 턴마다 PP가 1씩 늘어요(최대 10). PP를 써서 추종자·주문·마법진 카드를 내요.',
      '추종자는 다음 턴부터 공격(리더 또는 추종자). 진화하면 +2/+2 — 후공은 진화를 더 일찍, 더 많이 해요.',
    ],
    rules: [
      { h: '목표', p: ['1:1 대전. 상대 리더의 체력(20)을 0으로 만들면 이겨요. 내 덱에서 카드를 뽑아야 하는데 덱이 비어 있으면 져요.', '서로 70턴이 지나도 안 끝나면 리더 체력이 많은 쪽이 이겨요.'] },
      { h: '준비', p: ['직업과 덱(40장)을 골라요. 직업마다 「추천 덱」이 있고, 「🛠 덱 만들기」로 내 덱을 만들어 이 기기에 저장할 수 있어요(같은 카드 최대 3장, 그 직업 카드 + 공용 카드).',
        '드래프트: 직업 3개 중 하나 → 카드 3장 중 1장 고르기를 20번(고른 카드는 2장씩) 해서 즉석 덱을 만들어요.',
        '손패 3장을 받고, 바꾸고 싶은 카드를 골라 한 번 바꿀 수 있어요(멀리건).', '선공·후공은 무작위. 선공은 첫 턴 PP 1로 시작해요.'] },
      { h: '내 턴에 할 일', p: ['턴 시작: 최대 PP +1(최대 10), PP가 다 차고, 카드 1장을 뽑아요.',
        '① 카드 내기 — 코스트(파란 보석)만큼 PP를 써요. 손패 카드를 판으로 끌거나, 두 번 눌러 내요. 대상이 필요하면 빛나는 대상을 누르세요.',
        '② 공격 — 내 추종자를 상대 추종자나 리더에게 끌어다 놓거나, 눌러서 고른 뒤 대상을 눌러요. 추종자끼리 싸우면 서로 공격력만큼 피해를 줘요.',
        '③ 진화 — 추종자를 누르고 「진화 ✦」. 한 턴에 한 번.',
        '할 게 끝나면 「턴 종료」(Space/E).'] },
      { h: '카드 종류', p: ['추종자: 판에 남아 싸우는 카드. 왼쪽 아래 노란 마름모가 공격력, 오른쪽 아래 빨간 하트가 체력. 낸 턴에는 공격하지 못해요(💤).',
        '주문: 한 번 쓰고 사라지는 효과.', '마법진(육각형): 판에 남아 효과를 내요. 「대기 N」은 내 턴 시작마다 1씩 줄고 0이 되면 사라지며 유언을 일으켜요. 공격하지도, 공격받지도 않아요.',
        '판에는 추종자·마법진을 합쳐 5개까지, 손패는 9장까지(넘치면 뽑은 카드가 버려져요).'] },
      { h: '진화', p: ['선공: 5번째 내 턴부터, 진화 포인트 2개. 후공: 4번째 내 턴부터, 3개.', '진화하면 +2/+2(카드마다 다름)가 되고, 낸 턴이어도 바로 추종자를 공격할 수 있어요. 「진화 시」 효과도 일어나요.',
        '역전 진화: 내 리더 체력이 상대보다 적을 때 진화하면 +1/+1을 더 받아요.'] },
      { h: '능력', p: Object.keys(KW).map((k) => KW[k].ic + ' ' + KW[k].n + ': ' + KW[k].d).concat(TERMS.map((t) => t[0] + ': ' + t[1])) },
      { h: '직업', p: CL_ORDER.map((c) => CLS[c].n + ' — ' + CLS[c].d) },
      { h: '예시', p: ['상대 판에 2/3 수호 추종자가 있어요. 내 4/2 추종자는 수호부터 쳐야 해요 → 수호는 4 피해로 쓰러지고 내 추종자도 2 피해로 쓰러져요(체력 2).',
        '진화하면 4/2 → 6/4가 되어 살아남고, 남은 추종자로 리더를 칠 수 있어요.'] },
      { h: '조작', p: ['카드·추종자를 길게 누르면(PC는 마우스를 올리면) 크게 보고 능력 설명을 읽을 수 있어요.', '오른쪽 클릭·Esc: 고르던 것 취소. PC 단축키: Space/E 턴 종료 · V 진화 · L 기록 · ←/→ 손패 고르기 · Enter 고른 카드 내기.',
        '한 폰 두 사람: 차례마다 가림막이 떠요(덱 고르기·손패 바꾸기 포함).'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움은 그 턴 끝까지 수를 읽고, 상대 반격까지 따져 맞교환·마무리를 노려요.', '설정에서 「🤖 AI 서술」을 켜면 상대 리더의 한마디가 AI 문장으로 바뀌어요(✦ 표시).'] },
    ],
    tutorial: [
      { text: '수집 카드 대전에 온 걸 환영해요! 상대 리더의 체력 20을 먼저 0으로 만들면 이겨요.' },
      { text: '아래가 내 손패예요. 파란 보석이 코스트(PP). 판으로 끌어 놓거나 두 번 눌러 내요. 빛나는 카드가 지금 낼 수 있는 카드예요.' },
      { text: '추종자는 다음 턴부터 공격해요. 내 추종자를 상대 추종자나 리더에게 끌어다 놓으세요. 🛡 수호가 있으면 수호부터!' },
      { text: '5번째 턴(후공은 4번째)부터 추종자를 눌러 「진화 ✦」 — +2/+2에 바로 추종자를 칠 수 있어요. 다 했으면 「턴 종료」.' },
    ],
    controls: [
      { id: 'end', label: '턴 종료', keys: ['Space', 'KeyE'], pad: ['start'] },
      { id: 'evo', label: '진화', keys: ['KeyV'], pad: ['y'] },
      { id: 'log', label: '대전 기록', keys: ['KeyL'], pad: ['back'] },
      { id: 'prev', label: '이전 손패', keys: ['ArrowLeft'], pad: ['left'] },
      { id: 'next', label: '다음 손패', keys: ['ArrowRight'], pad: ['right'] },
      { id: 'play', label: '고른 카드 내기', keys: ['Enter'], pad: ['a'] },
    ],
    init(players, opts) { return init(players, opts); },
    actor, apply, ai, aiDelayFor, result, mount, hint, panelInfo, codex, preview,
    _t: { CARDS, ORDER, CLS, ART, presetDeck, validDeck, legal, cardText, forcePick },
  });
})();
