/* 컬러 블록 맞추기 — 8×8 판에 색 블록 조각을 끌어 놓아 줄을 지우는 혼자 하는 퍼즐 */
(function () {
  const L = window.Lounge, U = L.util;
  /* ---------- 오늘의 퍼즐 (날짜 YYYYMMDD 씨앗 → 모두 같은 퍼즐). 기록·연속 일수는 이 기기에만, 지난 7일치만 남김 ---------- */
  function mkDaily(gid, short, fmt, lower) {
    const SK = 'lounge.daily.' + gid;
    const ymd = (d) => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
    const toD = (n) => new Date(Math.floor(n / 10000), Math.floor(n / 100) % 100 - 1, n % 100, 12);
    const shift = (n, k) => { const d = toD(n); d.setDate(d.getDate() + k); return ymd(d); };
    const rd = () => { try { return JSON.parse(localStorage.getItem(SK) || '{}') || {}; } catch (e) { return {}; } };
    const wr = (o) => { try { localStorage.setItem(SK, JSON.stringify(o)); } catch (e) {} };
    const D = {
      today: () => ymd(new Date()),
      md: (n) => (Math.floor(n / 100) % 100) + '/' + (n % 100),
      long: (n) => (Math.floor(n / 100) % 100) + '월 ' + (n % 100) + '일',
      seed(n) { let h = (n >>> 0) ^ 0x9e3779b9; h = Math.imul(h ^ (h >>> 16), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; },
      score: (n) => { const o = rd(); return o.done ? o.done[n] : undefined; },
      streak() { const o = rd(), t = D.today(); return o.last && (o.last === t || o.last === shift(t, -1)) ? o.st | 0 : 0; },
      prune() {
        const o = rd(), cut = shift(D.today(), -6);
        if (o.done) for (const k in o.done) if (+k < cut) delete o.done[k];
        wr(o);
        try { const all = U.store.get('best.' + gid, {}); let ch = 0; for (const k in all) if (/^d\d{8}$/.test(k) && +k.slice(1) < cut) { delete all[k]; ch = 1; } if (ch) U.store.set('best.' + gid, all); } catch (e) {}
      },
      /* 완료 기록 → 새 최고면 true */
      complete(n, sc, api) {
        const o = rd(); o.done = o.done || {};
        const old = o.done[n], first = old == null;
        if (first || (lower ? sc < old : sc > old)) o.done[n] = sc;
        if (first) { o.st = o.last === shift(n, -1) ? (o.st | 0) + 1 : o.last === n ? o.st | 0 || 1 : 1; if (!o.last || n > o.last) o.last = n; }
        wr(o);
        if (api) api.best('d' + n, sc, { label: '오늘의 퍼즐 ' + D.md(n), lower: !!lower, unit: fmt === 'time' ? '' : fmt, fmt: fmt === 'time' ? 'time' : '' });
        D.prune();
        return !first && o.done[n] === sc && sc !== old;
      },
      text(n) {
        const sc = D.score(n);
        const v = fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt;
        return '한판 라운지 ' + short + ' ' + D.md(n) + ' ✓ ' + v + ' · 연속 ' + Math.max(1, D.streak()) + '일';
      },
      share(n, api) {
        const t = D.text(n), ok = () => api && api.toast('복사했어요: ' + t);
        const fb = () => { try { const ta = L.h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); ok(); } catch (e) { if (api) api.toast(t); } };
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb(); } catch (e) { fb(); }
      },
      fmtScore(sc) { return sc == null ? '' : fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt; },
      /* 단계/모드 고르기 맨 위에 넣는 큰 카드 */
      card(onPlay, api, sub) {
        const n = D.today(), sc = D.score(n), st = D.streak();
        const box = L.h('div', { class: 'daily-card', style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '12px', borderRadius: '14px', border: '2px solid var(--brass,#e3ae45)', background: 'linear-gradient(135deg,rgba(227,174,69,.22),rgba(227,174,69,.06))' } });
        const head = L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } });
        head.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', lineHeight: '1.2' } },
          L.h('b', { style: { fontSize: '18px' }, text: '📅 오늘의 퍼즐' }),
          L.h('span', { class: 'muted', style: { fontSize: '13px' }, text: D.long(n) + (sub ? ' · ' + sub : '') })),
          L.h('div', { style: { textAlign: 'right', lineHeight: '1.2', fontSize: '13px' } },
            L.h('div', { style: { fontSize: '15px', fontWeight: '700', color: sc != null ? '#8fd14f' : 'inherit' }, text: sc != null ? '완료 ✓' : '미완료' }),
            L.h('div', { class: 'muted', text: '🔥 연속 ' + st + '일' })));
        box.append(head);
        if (sc != null) box.append(L.h('div', { style: { fontSize: '13px' }, text: '오늘 최고 ' + D.fmtScore(sc) }));
        const row = L.h('div', { style: { display: 'flex', gap: '6px' } });
        row.append(L.h('button', { class: 'btn primary', style: { flex: '1', minHeight: '48px' }, text: sc != null ? '다시 도전 ▶' : '도전하기 ▶', onclick: () => onPlay(n) }));
        if (sc != null) row.append(L.h('button', { class: 'btn', style: { flex: '0 0 auto', minHeight: '48px', padding: '0 14px' }, text: '📋 공유', onclick: () => D.share(n, api) }));
        box.append(row);
        return box;
      },
    };
    return D;
  }
  const N = 8;
  const COLS = ['#ef5b4f', '#f3b63c', '#78cc48', '#2fc3b0', '#4d8cf0', '#a874e9'];
  const CNAME = ['빨강', '노랑', '초록', '청록', '파랑', '보라'];
  const LS_BEST = 'colorblast.best', LS_STAGE = 'colorblast.stage';
  const lsGet = (k) => { try { return +(window.localStorage.getItem(k) || 0) || 0; } catch (e) { return 0; } };
  const lsSet = (k, v) => { try { window.localStorage.setItem(k, String(v)); } catch (e) { /* 저장 안 됨 */ } };

  /* ---------- 조각 모양 (기본 모양을 돌려 만든다) ---------- */
  const BASES = [
    [[[0, 0]], 3],
    [[[0, 0], [0, 1]], 3],
    [[[0, 0], [0, 1], [0, 2]], 3],
    [[[0, 0], [0, 1], [0, 2], [0, 3]], 2],
    [[[0, 0], [0, 1], [0, 2], [0, 3], [0, 4]], 1.4],
    [[[0, 0], [0, 1], [1, 0], [1, 1]], 3],
    [[[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2], [2, 0], [2, 1], [2, 2]], 0.9],
    [[[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [1, 2]], 1.4],
    [[[0, 0], [1, 0], [1, 1]], 3],
    [[[0, 0], [1, 0], [2, 0], [2, 1], [2, 2]], 1.2],
    [[[0, 0], [0, 1], [0, 2], [1, 1]], 2],
    [[[0, 1], [0, 2], [1, 0], [1, 1]], 1.5],
    [[[0, 0], [0, 1], [1, 1], [1, 2]], 1.5],
    [[[0, 0], [1, 0], [2, 0], [2, 1]], 2],
    [[[0, 1], [1, 1], [2, 1], [2, 0]], 2],
  ];
  function norm(cells) {
    const mr = Math.min(...cells.map((c) => c[0])), mc = Math.min(...cells.map((c) => c[1]));
    return cells.map((c) => [c[0] - mr, c[1] - mc]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  }
  const SH = [], SW = [];
  BASES.forEach(([cells, w]) => {
    const rots = []; let cur = cells;
    for (let k = 0; k < 4; k++) {
      const n = norm(cur), key = JSON.stringify(n);
      if (!rots.some((r) => r.key === key)) rots.push({ key, n });
      cur = cur.map(([r, c]) => [c, -r]);
    }
    rots.forEach((r) => { SH.push(r.n); SW.push(w / rots.length); });
  });
  const SWT = SW.reduce((a, b) => a + b, 0);
  const dims = (cells) => ({ h: 1 + Math.max(...cells.map((c) => c[0])), w: 1 + Math.max(...cells.map((c) => c[1])) });
  const SD = SH.map(dims);

  /* ---------- 난수 (상태 안에 씨앗) ---------- */
  function rnd(s) {
    let t = (s.rs = (s.rs + 0x6D2B79F5) >>> 0);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  function pickShape(s) { let x = rnd(s) * SWT; for (let i = 0; i < SH.length; i++) { x -= SW[i]; if (x <= 0) return i; } return 0; }
  function pickColor(s) {
    const k = s.nc;
    if (s.g && s.g.c != null && rnd(s) < (s.g.k === 'mono' ? 0.45 : 0.3)) return s.g.c; // 단계: 목표 색이 조금 더 자주
    return Math.floor(rnd(s) * k);
  }

  /* ---------- 판 ---------- */
  const at = (b, r, c) => b.charCodeAt(r * N + c) - 48; // -2 = '.'
  const EMPTY = '.'.charCodeAt(0) - 48;
  function fits(b, sh, r, c) {
    const cells = SH[sh];
    for (const [dr, dc] of cells) {
      const rr = r + dr, cc = c + dc;
      if (rr < 0 || cc < 0 || rr >= N || cc >= N || b[rr * N + cc] !== '.') return false;
    }
    return true;
  }
  function anyFit(b, sh) {
    const d = SD[sh];
    for (let r = 0; r + d.h <= N; r++) for (let c = 0; c + d.w <= N; c++) if (fits(b, sh, r, c)) return true;
    return false;
  }
  // 놓았을 때 결과 (판, 지워지는 줄, 단색 줄)
  function simulate(b, sh, col, r, c) {
    const a = b.split('');
    for (const [dr, dc] of SH[sh]) a[(r + dr) * N + c + dc] = String(col);
    const rows = [], cols = [], mono = [];
    for (let i = 0; i < N; i++) {
      let full = true, one = true; const f = a[i * N];
      for (let j = 0; j < N; j++) { const v = a[i * N + j]; if (v === '.') { full = false; break; } if (v !== f) one = false; }
      if (full) { rows.push(i); if (one) mono.push(['r', i, +f]); }
      full = true; one = true; const g = a[i];
      for (let j = 0; j < N; j++) { const v = a[j * N + i]; if (v === '.') { full = false; break; } if (v !== g) one = false; }
      if (full) { cols.push(i); if (one) mono.push(['c', i, +g]); }
    }
    const gone = new Array(N * N).fill(0);
    rows.forEach((i) => { for (let j = 0; j < N; j++) gone[i * N + j] = 1; });
    cols.forEach((i) => { for (let j = 0; j < N; j++) gone[j * N + i] = 1; });
    const counts = [0, 0, 0, 0, 0, 0];
    for (let k = 0; k < N * N; k++) if (gone[k]) { counts[+a[k]]++; a[k] = '.'; }
    return { board: a.join(''), rows, cols, mono, counts };
  }

  /* ---------- 단계 만들기 (단계 번호로 늘 같은 판) ---------- */
  const DST = 20; // 오늘의 퍼즐 = 20단계 급 목표(목표 종류는 날짜로 정함)
  const DAILY = mkDaily('colorblast', '컬러 블록', '조각', true);
  function stageDef(n, seed) {
    const s = { rs: seed ? seed >>> 0 : (n * 7919 + 1234567) >>> 0 };
    const nc = Math.min(6, 3 + Math.floor((n - 1) / 5));
    const kinds = ['ln', 'sc', 'cc', 'ln', 'mono'];
    const k = seed ? kinds[Math.floor(rnd(s) * kinds.length)] : n <= 2 ? 'ln' : kinds[(n - 1) % 5];
    const c = Math.floor(rnd(s) * nc);
    let g;
    if (k === 'ln') { const t = Math.min(18, 2 + Math.floor(n / 2)); g = { k, t, p: Math.round(t * 3 + 9 - Math.min(5, n / 6)) }; }
    else if (k === 'sc') { const t = 300 + n * 60; g = { k, t, p: 18 + Math.floor(n / 3) }; }
    else if (k === 'cc') { const t = Math.min(48, 10 + n); g = { k, c, t, p: Math.round(t / 1.6 + 10) }; }
    else { const t = Math.min(3, 1 + Math.floor(n / 15)); g = { k, c, t, p: 22 + 8 * t }; }
    // 미리 깔린 블록
    const pre = Math.min(12, Math.floor((n - 1) * 0.5));
    const a = new Array(N * N).fill('.');
    let tries = 0, placed = 0;
    if (k === 'mono') { // 목표 색으로 반쯤 찬 줄을 깔아 둔다
      for (let q = 0; q < g.t; q++) {
        const r = Math.floor(rnd(s) * N);
        for (let j = 0; j < N; j++) if (rnd(s) < 0.6 && a[r * N + j] === '.') a[r * N + j] = String(c);
        if (!a.slice(r * N, r * N + N).includes('.')) a[r * N + Math.floor(rnd(s) * N)] = '.';
      }
    }
    while (placed < pre && tries++ < 400) {
      const i = Math.floor(rnd(s) * N * N);
      if (a[i] !== '.') continue;
      a[i] = String(Math.floor(rnd(s) * nc));
      const r = Math.floor(i / N), cc = i % N;
      let rf = true, cf = true;
      for (let j = 0; j < N; j++) { if (a[r * N + j] === '.') rf = false; if (a[j * N + cc] === '.') cf = false; }
      if (rf || cf) { a[i] = '.'; continue; }
      placed++;
    }
    return { g, nc, board: a.join(''), seed: seed ? (Math.imul(seed, 31) + 77) >>> 0 : (n * 104729 + 77) >>> 0 };
  }

  /* ---------- 상태 ---------- */
  function fresh(mode, stage, dy) {
    const s = { m: mode, sc: 0, cb: 0, mc: 0, ms: 0, ln: 0, tray: [null, null, null], used: 0, over: 0, win: 0, ph: 'play', seq: 0, last: null, best: lsGet(LS_BEST), nb: 0 };
    if (mode === 'day') {
      const d = stageDef(DST, dailySeed(dy));
      s.dy = dy; s.n = DST; s.g = d.g; s.gp = 0; s.nc = d.nc; s.b = d.board; s.rs = d.seed;
    } else if (mode === 'st') {
      const d = stageDef(stage);
      s.n = stage; s.g = d.g; s.gp = 0; s.nc = d.nc; s.b = d.board; s.rs = d.seed;
    } else {
      s.n = 0; s.g = null; s.nc = 6; s.b = '.'.repeat(N * N); s.rs = (Math.random() * 4294967296) >>> 0;
    }
    deal(s);
    return s;
  }
  /* 오늘의 퍼즐: 어려움 AI가 실제로 깰 수 있는 판만 쓴다(날짜마다 첫 통과 후보 → 누구나 같은 판) */
  const dsCache = {};
  function dailySeed(dy) {
    if (dsCache[dy]) return dsCache[dy];
    const base = DAILY.seed(dy);
    let pick = base;
    for (let k = 0; k < 12; k++) {
      const sd = (base + k * 0x9e3779b1) >>> 0 || 1;
      const d = stageDef(DST, sd);
      const s = { m: 'st', sc: 0, cb: 0, mc: 0, ms: 0, ln: 0, tray: [null, null, null], used: 0, over: 0, win: 0, ph: 'play', seq: 0, last: null, best: 0, nb: 0, n: DST, g: d.g, gp: 0, nc: d.nc, b: d.board, rs: d.seed };
      deal(s);
      for (let n = 0; n < 200 && s.ph === 'play' && !s.over; n++) { const m = ai(s, 0, 3); if (!m) break; apply(s, 0, m); }
      if (s.ph === 'clear') { pick = sd; break; }
    }
    return (dsCache[dy] = pick);
  }
  function piecesLeft(s) { return s.g ? s.g.p - s.used : Infinity; }
  function deal(s) {
    const left = piecesLeft(s);
    const k = Math.min(3, left);
    let best = null;
    for (let t = 0; t < 30; t++) {
      const tr = [null, null, null];
      for (let i = 0; i < k; i++) tr[i] = [pickShape(s), pickColor(s)];
      best = tr;
      if (tr.some((p) => p && anyFit(s.b, p[0]))) break; // 적어도 하나는 들어가게
    }
    s.tray = best;
  }
  function goalDone(s) { return s.g && s.gp >= s.g.t; }

  function init(players, opts) {
    const mode = opts && (opts.mode === 'st' || opts.mode === 'day') ? opts.mode : 'inf';
    if (mode === 'day') return fresh('day', 0, (opts && opts._day) || DAILY.today());
    let stage = 1;
    if (mode === 'st') stage = opts.from === 'one' ? 1 : Math.max(1, lsGet(LS_STAGE) || 1);
    return fresh(mode, stage);
  }
  function actor(s) { return s.over ? null : 0; }

  function apply(s, seat, a) {
    if (!a) throw new Error('bad');
    if (a.t === 'end') {
      if (s.ph !== 'dclear') throw new Error('not clear');
      s.over = 1; s.win = 1; s.why = '목표 달성'; s.ph = 'over'; return s;
    }
    if (a.t === 'next') {
      if (s.ph !== 'clear') throw new Error('not clear');
      const best = s.best, seq = s.seq;
      const ns = fresh('st', s.n + 1);
      ns.best = best; ns.seq = seq + 1; ns.last = { id: ns.seq, t: 'new' };
      return ns;
    }
    if (a.t !== 'put' || s.ph !== 'play') throw new Error('bad action');
    const p = s.tray[a.i];
    if (!p || !fits(s.b, p[0], a.r, a.c)) throw new Error('no fit');
    const [sh, col] = p;
    const res = simulate(s.b, sh, col, a.r, a.c);
    const L2 = res.rows.length + res.cols.length;
    let pts = SH[sh].length, mult = 1;
    if (L2) {
      s.cb = s.cb > 0 && s.ms <= 2 ? s.cb + 1 : 1; s.ms = 0;
      mult = 1 + (s.cb - 1) * 0.5; if (s.cb > s.mc) s.mc = s.cb;
      pts += Math.round(((L2 * (L2 + 1)) / 2 * 80 + res.mono.length * 120) * mult);
    } else { s.ms++; if (s.ms > 2) s.cb = 0; }
    s.sc += pts; s.ln += L2;
    s.b = res.board; s.tray[a.i] = null; s.used++;
    if (s.g) {
      const g = s.g;
      if (g.k === 'ln') s.gp += L2;
      else if (g.k === 'sc') s.gp = s.sc;
      else if (g.k === 'cc') s.gp += res.counts[g.c];
      else s.gp += res.mono.filter((m) => m[2] === g.c).length;
      s.gp = Math.min(s.gp, g.t);
    }
    s.seq++;
    s.last = { id: s.seq, t: 'put', sh, col, r: a.r, c: a.c, rows: res.rows, cols: res.cols, mono: res.mono, pts, cb: L2 ? s.cb : 0, mult };
    if (goalDone(s)) { s.ph = s.m === 'day' ? 'dclear' : 'clear'; return s; }
    if (s.tray.every((x) => !x)) {
      if (piecesLeft(s) <= 0) { finish(s, '조각을 다 썼어요'); return s; }
      deal(s);
    }
    if (!s.tray.some((x) => x && anyFit(s.b, x[0]))) finish(s, '놓을 자리가 없어요');
    return s;
  }
  function finish(s, why) {
    s.over = 1; s.why = why; s.ph = 'over';
    if (s.m === 'inf' && s.sc > s.best) { s.nb = 1; }
  }
  function result(s) {
    if (!s.over) return null;
    const stats = [{ label: '점수', value: s.sc + '점' }, { label: '지운 줄', value: s.ln + '줄' }, { label: '최대 콤보', value: String(s.mc || 0) }, { label: '놓은 조각', value: s.used + '개' }];
    if (s.g) stats.push({ label: '목표', value: goalText(s.g) + ' (' + s.gp + '/' + s.g.t + ')' });
    if (s.m === 'inf') {
      return { winners: [0], title: s.nb ? '새 최고 기록!' : '게임 끝', text: `${s.why}. 점수 ${s.sc}점 · 지운 줄 ${s.ln}줄 · 최고 ${Math.max(s.best, s.sc)}점`, stats };
    }
    if (s.m === 'day') {
      if (s.win) return { winners: [0], title: '오늘의 퍼즐 ' + DAILY.md(s.dy) + ' 완료!', text: `조각 ${s.used}개로 「${goalText(s.g)}」를 이뤘어요.`, stats };
      return { winners: [], title: '오늘의 퍼즐 실패', text: `${s.why}. 목표 ${s.gp}/${s.g.t} — 다시 하면 같은 판·같은 조각으로 도전해요.`, stats };
    }
    return { winners: [], title: `${s.n}단계 실패`, text: `${s.why}. 목표 ${s.gp}/${s.g.t} — 다시 하면 같은 판으로 도전해요.`, stats };
  }

  /* ---------- 자동 플레이 (시험·AI 자리) ---------- */
  function evalBoard(b) {
    // 구멍(사방이 막힌 빈칸)·조각화 벌점, 큰 조각 자리 보너스
    let pen = 0;
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
      if (b[r * N + c] !== '.') continue;
      let block = 0;
      if (r === 0 || b[(r - 1) * N + c] !== '.') block++;
      if (r === N - 1 || b[(r + 1) * N + c] !== '.') block++;
      if (c === 0 || b[r * N + c - 1] !== '.') block++;
      if (c === N - 1 || b[r * N + c + 1] !== '.') block++;
      if (block === 4) pen += 6; else if (block === 3) pen += 2;
    }
    let bonus = 0;
    if (anyFit(b, SH.findIndex((x) => x.length === 9))) bonus += 8;
    for (let i = 0; i < N; i++) { // 거의 찬 줄은 좋음
      let fr = 0, fc = 0;
      for (let j = 0; j < N; j++) { if (b[i * N + j] !== '.') fr++; if (b[j * N + i] !== '.') fc++; }
      if (fr >= 6) bonus += 1; if (fc >= 6) bonus += 1;
    }
    let empty = 0; for (let k = 0; k < N * N; k++) if (b[k] === '.') empty++;
    return empty * 0.4 + bonus - pen;
  }
  function ai(s, seat, lv) {
    if (s.ph === 'clear') return { t: 'next' };
    if (s.ph === 'dclear') return { t: 'end' };
    const moves = [];
    s.tray.forEach((p, i) => {
      if (!p) return;
      const d = SD[p[0]];
      for (let r = 0; r + d.h <= N; r++) for (let c = 0; c + d.w <= N; c++) if (fits(s.b, p[0], r, c)) moves.push({ i, r, c, p });
    });
    if (!moves.length) return null;
    if (lv === 1 && Math.random() < 0.5) { const m = moves[Math.floor(Math.random() * moves.length)]; return { t: 'put', i: m.i, r: m.r, c: m.c }; }
    let best = null, bv = -1e9;
    for (const m of moves) {
      const res = simulate(s.b, m.p[0], m.p[1], m.r, m.c);
      const L2 = res.rows.length + res.cols.length;
      let v = L2 * 30 + res.mono.length * 20 + evalBoard(res.board);
      if (lv >= 3) { // 남은 조각이 들어갈 수 있는지
        s.tray.forEach((q, j) => { if (q && j !== m.i && !anyFit(res.board, q[0])) v -= 60; });
      }
      if (lv === 1) v += Math.random() * 25;
      if (v > bv) { bv = v; best = m; }
    }
    return { t: 'put', i: best.i, r: best.r, c: best.c };
  }
  function aiDelayFor(s, seat, lv) { return lv === 3 ? 350 : 550; }

  /* ---------- 화면 ---------- */
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16);
    let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f > 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return `rgb(${r | 0},${g | 0},${b | 0})`;
  }
  function goalText(g) {
    if (!g) return '';
    if (g.k === 'ln') return `줄 ${g.t}개 지우기`;
    if (g.k === 'sc') return `${g.t}점 만들기`;
    if (g.k === 'cc') return `${CNAME[g.c]} 칸 ${g.t}개 지우기`;
    return `${CNAME[g.c]} 단색 줄 ${g.t}개`;
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null;
    const sprites = {};
    let drag = null; // {i, x, y, ghost:{r,c,ok,res}}
    const fx = []; // 터지는 칸·파편·글자
    let shake = 0, scoreShown = 0, stop = null, busyUntil = 0, popIn = null;
    const sp = () => L.debug.speed || 1;

    const nextBtn = L.h('button', { 'data-action': 'next', class: 'btn primary cb-next', text: '다음 단계 ▶', style: { position: 'absolute', left: '50%', transform: 'translateX(-50%)', minHeight: '52px', minWidth: '180px', fontSize: '18px', display: 'none', zIndex: 3 }, onclick() { api.sfx('click'); api.act({ t: 'next' }); } });
    root.append(nextBtn);
    let dov = null;
    const closeD = () => { if (dov) { dov.remove(); dov = null; } };
    function dpanel(kids) {
      closeD();
      dov = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', background: 'rgba(10,8,15,.66)' } });
      const sh = L.h('div', { class: 'sheet', style: { gap: '12px', maxWidth: '380px', width: '100%' } });
      kids.forEach((k) => k && sh.append(k)); dov.append(sh); root.append(dov);
    }
    function dailyIntro() {
      if (!st || st.m !== 'day' || !api.canAct(0) || api.players[0].ai) return;
      dpanel([DAILY.card(() => { closeD(); api.sfx('click'); }, api, goalText(st.g)),
        L.h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: `조각 ${st.g.p}개 안에 목표를 이루세요. 오늘은 누구나 같은 판·같은 조각 순서예요. 적은 조각으로 이룰수록 좋은 기록!` })]);
      const b = dov.querySelector('.btn.primary'); if (b) b.textContent = DAILY.score(st.dy) != null ? '다시 도전 ▶' : '시작 ▶';
    }
    function dailyClear() {
      const sc = DAILY.score(st.dy);
      dpanel([L.h('h2', { text: '오늘의 퍼즐 완료! 🎉' }),
        L.h('p', { style: { margin: 0, fontSize: '16px' }, text: `조각 ${st.used}개` + (sc != null ? ` · 오늘 최고 ${sc}조각` : '') + ` · 🔥 연속 ${DAILY.streak()}일` }),
        L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '📋 결과 공유(복사)', onclick: () => DAILY.share(st.dy, api) }),
        L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '마치기', onclick: () => { closeD(); api.act({ t: 'end' }); } })]);
    }

    function layout() {
      const w = cv.w, h = cv.h;
      const head = 70, trayMin = 128;
      const cell = Math.floor(Math.min((w - 24) / N, (h - head - trayMin - 24) / N, 56));
      const size = cell * N;
      const bx = Math.round((w - size) / 2);
      const spare = h - head - size - trayMin - 24;
      const by = head + Math.max(0, Math.floor(spare * 0.35));
      const ty = by + size + 14;
      const th = Math.min(h - ty - 8, 170);
      G = { cell, size, bx, by, ty, th, w, h, tc: Math.max(14, Math.floor(Math.min(cell * 0.56, th / 5.4, (w - 24) / 3 / 5.4))) };
      for (const k in sprites) delete sprites[k];
      nextBtn.style.top = (by + size / 2 + 40) + 'px';
    }
    function sprite(col, sz) {
      const key = col + ':' + sz;
      if (sprites[key]) return sprites[key];
      const d = cv.dpr || 1, c = document.createElement('canvas');
      c.width = c.height = Math.ceil(sz * d);
      const g = c.getContext('2d'); g.scale(d, d);
      const m = Math.max(1, sz * 0.05), rr = sz * 0.2, x = m, y = m, s2 = sz - m * 2;
      const base = COLS[col];
      g.fillStyle = shade(base, -0.38); rrect(g, x, y + s2 * 0.06, s2, s2 * 0.94, rr); g.fill();
      const gr = g.createLinearGradient(0, y, 0, y + s2);
      gr.addColorStop(0, shade(base, 0.25)); gr.addColorStop(1, base);
      g.fillStyle = gr; rrect(g, x, y, s2, s2 * 0.9, rr); g.fill();
      g.fillStyle = 'rgba(255,255,255,0.32)'; rrect(g, x + s2 * 0.16, y + s2 * 0.1, s2 * 0.68, s2 * 0.22, rr * 0.6); g.fill();
      g.strokeStyle = shade(base, 0.45); g.lineWidth = Math.max(1, sz * 0.03); rrect(g, x + 0.5, y + 0.5, s2 - 1, s2 * 0.9 - 1, rr); g.stroke();
      sprites[key] = c; return c;
    }
    function rrect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
    function drawCell(col, x, y, sz, alpha, scale) {
      const im = sprite(col, Math.round(sz));
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      const s2 = sz * (scale || 1);
      ctx.drawImage(im, x + (sz - s2) / 2, y + (sz - s2) / 2, s2, s2);
      ctx.globalAlpha = 1;
    }
    function slotRect(i) { const sw = (G.w - 16) / 3; return { x: 8 + sw * i, y: G.ty, w: sw, h: G.th }; }
    function trayPos(i, sh) {
      const r = slotRect(i), d = SD[sh], t = Math.floor(Math.min(G.cell * 0.62, (r.w - 22) / Math.max(3, d.w), (r.h - 22) / Math.max(3, d.h)));
      return { x: r.x + (r.w - d.w * t) / 2, y: r.y + (r.h - d.h * t) / 2, t };
    }

    function ghostFor(px, py) {
      const p = st.tray[drag.i]; if (!p) return null;
      const d = SD[p[0]], c = G.cell;
      const lift = Math.max(70, c * 1.9);
      const x0 = px - (d.w * c) / 2, y0 = py - lift - (d.h * c) / 2;
      drag.dx = x0; drag.dy = y0;
      const col = Math.round((x0 - G.bx) / c), row = Math.round((y0 - G.by) / c);
      if (row < -1 || col < -1 || row + d.h > N + 1 || col + d.w > N + 1) return null;
      const rr = U.clamp(row, 0, N - d.h), cc = U.clamp(col, 0, N - d.w);
      if (!fits(st.b, p[0], rr, cc)) return { r: rr, c: cc, ok: false };
      return { r: rr, c: cc, ok: true, res: simulate(st.b, p[0], p[1], rr, cc) };
    }
    const canPlay = () => st && st.ph === 'play' && !st.over && api.canAct(0) && performance.now() > busyUntil - 200;
    function down(ev) {
      if (!canPlay()) return;
      const { x, y } = cv.local(ev);
      if (y < G.ty - 10) return;
      for (let i = 0; i < 3; i++) {
        const r = slotRect(i);
        if (st.tray[i] && x >= r.x && x <= r.x + r.w) {
          drag = { i, x, y }; drag.gh = ghostFor(x, y);
          api.sfx('tick'); api.buzz(8);
          try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) { /* 무시 */ }
          return;
        }
      }
    }
    function move(ev) {
      if (!drag) return;
      const { x, y } = cv.local(ev);
      const prev = drag.gh;
      drag.x = x; drag.y = y; drag.gh = ghostFor(x, y);
      if (drag.gh && drag.gh.ok && (!prev || prev.r !== drag.gh.r || prev.c !== drag.gh.c)) api.buzz(4);
    }
    function up() {
      if (!drag) return;
      const g = drag.gh, i = drag.i; drag = null;
      if (g && g.ok && canPlay()) { api.act({ t: 'put', i, r: g.r, c: g.c }); }
      else if (g) api.sfx('thud');
    }
    cv.cv.addEventListener('pointerdown', down);
    cv.cv.addEventListener('pointermove', move);
    cv.cv.addEventListener('pointerup', up);
    cv.cv.addEventListener('pointercancel', () => { drag = null; });

    function onEvent(last) {
      if (!last) return;
      if (last.t === 'new') { scoreShown = 0; popIn = { t0: performance.now(), all: true }; api.sfx('whoosh'); return; }
      const now = performance.now();
      popIn = { t0: now, cells: SH[last.sh].map(([dr, dc]) => [last.r + dr, last.c + dc]) };
      const L2 = last.rows.length + last.cols.length;
      api.sfx(L2 ? 'pop' : 'chip');
      if (!L2) return;
      api.buzz(L2 > 1 ? 30 : 15);
      shake = Math.min(10, 3 + L2 * 2);
      const prevB = (prevBoard || st.b);
      // 지워진 칸: 놓은 직후의 판에서 색을 가져온다
      const a = prevB.split('');
      for (const [dr, dc] of SH[last.sh]) a[(last.r + dr) * N + last.c + dc] = String(last.col);
      const done = {};
      const add = (r, c, delay) => {
        const k = r * N + c; if (done[k]) return; done[k] = 1;
        const col = +a[k]; if (isNaN(col)) return;
        fx.push({ k: 'cell', r, c, col, t0: now + delay / sp(), d: 380 });
        for (let q = 0; q < 3; q++) fx.push({ k: 'bit', col, x: G.bx + (c + 0.5) * G.cell, y: G.by + (r + 0.5) * G.cell, vx: (Math.random() - 0.5) * 0.5, vy: -Math.random() * 0.5 - 0.1, t0: now + delay / sp(), d: 650, s: G.cell * (0.15 + Math.random() * 0.15) });
      };
      last.rows.forEach((r) => { for (let c = 0; c < N; c++) add(r, c, Math.abs(c - last.c) * 22); });
      last.cols.forEach((c) => { for (let r = 0; r < N; r++) add(r, c, Math.abs(r - last.r) * 22); });
      last.mono.forEach((m) => fx.push({ k: 'band', o: m[0], i: m[1], col: m[2], t0: now, d: 700 }));
      const cx = G.bx + (last.c + 1) * G.cell, cy = G.by + (last.r + 0.5) * G.cell;
      fx.push({ k: 'txt', text: '+' + last.pts, x: cx, y: cy, t0: now, d: 900, sz: 26, color: '#fff3d6' });
      let line2 = L2 >= 2 ? `${L2}줄 동시!` : '';
      if (last.cb >= 2) line2 = (line2 ? line2 + ' ' : '') + `콤보 ×${last.mult}`;
      if (line2) fx.push({ k: 'txt', text: line2, x: G.w / 2, y: G.by + G.size * 0.42, t0: now + 80, d: 1100, sz: 30, color: '#e3ae45' });
      if (last.mono.length) fx.push({ k: 'txt', text: last.mono.length > 1 ? `단색 줄 ×${last.mono.length}!` : '단색 줄!', x: G.w / 2, y: G.by + G.size * 0.58, t0: now + 160, d: 1100, sz: 26, color: COLS[last.mono[0][2]] });
      if (last.mono.length || L2 >= 3) api.sfx('win');
      busyUntil = now + 450 / sp();
      api.setBusy(true);
    }
    let prevBoard = null;

    function draw(now) {
      if (!G || !st) return;
      ctx.clearRect(0, 0, G.w, G.h);
      const bgr = ctx.createLinearGradient(0, 0, 0, G.h);
      bgr.addColorStop(0, '#1d1729'); bgr.addColorStop(1, '#120f19');
      ctx.fillStyle = bgr; ctx.fillRect(0, 0, G.w, G.h);
      // 머리글: 점수·목표
      const tgtScore = st.sc;
      scoreShown += (tgtScore - scoreShown) * Math.min(1, 0.2 * sp());
      if (Math.abs(tgtScore - scoreShown) < 1) scoreShown = tgtScore;
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 13px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left';
      if (st.m === 'inf') {
        ctx.fillText('점수', 14, 18);
        ctx.textAlign = 'right'; ctx.fillText('최고 ' + Math.max(st.best, st.sc), G.w - 14, 18);
        ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 32px "IBM Plex Mono", monospace';
        ctx.fillText(String(Math.round(scoreShown)), 14, 46);
        if (st.cb >= 2) { ctx.textAlign = 'right'; ctx.fillStyle = '#e3ae45'; ctx.font = '700 18px "IBM Plex Sans KR", sans-serif'; ctx.fillText(`콤보 ${st.cb}`, G.w - 14, 46); }
      } else {
        ctx.fillText(`${st.m === 'day' ? '📅 오늘 ' + DAILY.md(st.dy) : st.n + '단계'} · ${goalText(st.g)}`, 14, 16);
        ctx.textAlign = 'right'; ctx.fillText(`남은 조각 ${Math.max(0, st.g.p - st.used)}`, G.w - 14, 16);
        // 진행 막대
        const bw = G.w - 28, y = 32, f = st.g.t ? st.gp / st.g.t : 0;
        ctx.fillStyle = '#2e2640'; rrect(ctx, 14, y, bw, 14, 7); ctx.fill();
        ctx.fillStyle = st.g.c != null ? COLS[st.g.c] : '#e3ae45'; if (f > 0) { rrect(ctx, 14, y, Math.max(14, bw * f), 14, 7); ctx.fill(); }
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.font = '700 12px "IBM Plex Mono", monospace'; ctx.fillText(`${st.gp} / ${st.g.t}`, 14 + bw / 2, y + 7.5);
        ctx.textAlign = 'left'; ctx.font = '700 15px "IBM Plex Mono", monospace'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(`${Math.round(scoreShown)}점`, 14, 60);
        if (st.cb >= 2) { ctx.textAlign = 'right'; ctx.fillStyle = '#e3ae45'; ctx.fillText(`콤보 ${st.cb}`, G.w - 14, 60); }
      }
      // 판
      let ox = 0, oy = 0;
      if (shake > 0.2) { ox = (Math.random() - 0.5) * shake * L.fx(); oy = (Math.random() - 0.5) * shake * L.fx(); shake *= 0.85; } else shake = 0;
      ctx.save(); ctx.translate(ox, oy);
      const { bx, by, size, cell } = G;
      ctx.fillStyle = '#3a2a1e'; rrect(ctx, bx - 8, by - 8, size + 16, size + 16, 14); ctx.fill();
      ctx.fillStyle = '#0f2f26'; rrect(ctx, bx - 3, by - 3, size + 6, size + 6, 9); ctx.fill();
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        ctx.fillStyle = (r + c) % 2 ? '#174a3b' : '#1a5242';
        rrect(ctx, bx + c * cell + 1.5, by + r * cell + 1.5, cell - 3, cell - 3, cell * 0.16); ctx.fill();
      }
      const gh = drag && drag.gh;
      const clr = {};
      if (gh && gh.ok) { gh.res.rows.forEach((r) => { for (let c = 0; c < N; c++) clr[r * N + c] = 1; }); gh.res.cols.forEach((c) => { for (let r = 0; r < N; r++) clr[r * N + c] = 1; }); }
      const pulse = 0.5 + 0.5 * Math.sin(now / 110);
      let popT = popIn ? (now - popIn.t0) * sp() / 220 : 2;
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = st.b[r * N + c]; if (v === '.') continue;
        let sc = 1;
        if (popT < 1 && (popIn.all || popIn.cells.some(([a, b]) => a === r && b === c))) sc = 0.6 + 0.4 * easeBack(popT);
        drawCell(+v, bx + c * cell, by + r * cell, cell, 1, sc);
        if (clr[r * N + c]) { ctx.fillStyle = `rgba(255,244,214,${0.25 + 0.25 * pulse})`; rrect(ctx, bx + c * cell + 2, by + r * cell + 2, cell - 4, cell - 4, cell * 0.18); ctx.fill(); }
      }
      if (gh) {
        const p = st.tray[drag.i];
        for (const [dr, dc] of SH[p[0]]) {
          const x = bx + (gh.c + dc) * cell, y = by + (gh.r + dr) * cell;
          if (gh.ok) drawCell(p[1], x, y, cell, 0.42);
          else { ctx.strokeStyle = 'rgba(238,106,85,.7)'; ctx.lineWidth = 2; rrect(ctx, x + 3, y + 3, cell - 6, cell - 6, cell * 0.16); ctx.stroke(); }
        }
        if (gh.ok) { // 지워질 줄 미리 보기: 빈칸도 빛나게
          for (const k in clr) { const r = Math.floor(k / N), c = k % N; if (st.b[k] === '.') { ctx.fillStyle = `rgba(255,244,214,${0.18 + 0.2 * pulse})`; rrect(ctx, bx + c * cell + 2, by + r * cell + 2, cell - 4, cell - 4, cell * 0.18); ctx.fill(); } }
          if (gh.res.mono.length) { ctx.fillStyle = '#fff3d6'; ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.fillText('단색 줄 보너스!', G.w / 2, by - 20 > 64 ? by - 20 : by + 14); }
        }
      }
      // 효과
      for (let q = fx.length - 1; q >= 0; q--) {
        const e = fx[q], t = (now - e.t0) * sp() / e.d;
        if (t >= 1) { fx.splice(q, 1); continue; }
        if (t < 0) continue;
        if (e.k === 'cell') {
          const x = bx + e.c * cell, y = by + e.r * cell;
          drawCell(e.col, x, y, cell, 1 - t, 1 + t * 0.5);
          ctx.fillStyle = `rgba(255,255,255,${(1 - t) * 0.7})`; rrect(ctx, x + 2, y + 2, cell - 4, cell - 4, cell * 0.2); ctx.fill();
        } else if (e.k === 'band') {
          ctx.fillStyle = COLS[e.col]; ctx.globalAlpha = (1 - t) * 0.6;
          if (e.o === 'r') ctx.fillRect(bx - 8, by + e.i * cell - t * 6, size + 16, cell + t * 12); else ctx.fillRect(bx + e.i * cell - t * 6, by - 8, cell + t * 12, size + 16);
          ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
      for (const e of fx) {
        const t = (now - e.t0) * sp() / e.d; if (t < 0 || t >= 1) continue;
        if (e.k === 'bit') {
          const ms = (now - e.t0) * sp();
          const x = e.x + e.vx * ms, y = e.y + e.vy * ms + 0.0009 * ms * ms;
          ctx.globalAlpha = 1 - t; ctx.fillStyle = COLS[e.col]; ctx.fillRect(x - e.s / 2, y - e.s / 2, e.s, e.s); ctx.globalAlpha = 1;
        } else if (e.k === 'txt') {
          const s = t < 0.15 ? 0.6 + t / 0.15 * 0.5 : 1.1 - Math.min(0.1, (t - 0.15));
          ctx.save(); ctx.globalAlpha = t > 0.7 ? (1 - t) / 0.3 : 1;
          ctx.translate(U.clamp(e.x, 70, G.w - 70), e.y - t * 30); ctx.scale(s, s);
          ctx.font = `800 ${e.sz}px "Black Han Sans", "IBM Plex Sans KR", sans-serif`; ctx.textAlign = 'center';
          ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(20,14,28,.85)'; ctx.strokeText(e.text, 0, 0);
          ctx.fillStyle = e.color; ctx.fillText(e.text, 0, 0); ctx.restore();
        }
      }
      // 조각 받침
      for (let i = 0; i < 3; i++) {
        const r = slotRect(i);
        ctx.fillStyle = 'rgba(46,38,64,.55)'; rrect(ctx, r.x + 4, r.y, r.w - 8, r.h, 14); ctx.fill();
        const p = st.tray[i];
        if (!p || (drag && drag.i === i)) continue;
        const tp = trayPos(i, p[0]);
        const fitsAny = anyFit(st.b, p[0]);
        let sc = 1;
        if (popIn && popIn.deal && (now - popIn.t0) * sp() < 260) sc = easeBack((now - popIn.t0) * sp() / 260);
        for (const [dr, dc] of SH[p[0]]) drawCell(p[1], tp.x + dc * tp.t, tp.y + dr * tp.t, tp.t, fitsAny ? 1 : 0.3, sc);
      }
      // 끌고 있는 조각 (손가락 위에)
      if (drag && st.tray[drag.i]) {
        const p = st.tray[drag.i];
        for (const [dr, dc] of SH[p[0]]) drawCell(p[1], drag.dx + dc * cell, drag.dy + dr * cell, cell, 0.95);
      }
      // 안내
      if (canPlay() && !drag && st.used === 0 && st.sc === 0) {
        ctx.fillStyle = 'rgba(242,233,216,.8)'; ctx.font = '600 13px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('아래 조각을 끌어서 판에 놓으세요', G.w / 2, G.ty + G.th - 9);
      }
      if (st.ph === 'clear') {
        ctx.fillStyle = 'rgba(18,14,25,.72)'; rrect(ctx, bx - 8, by + size / 2 - 70, size + 16, 170, 16); ctx.fill();
        ctx.fillStyle = '#e3ae45'; ctx.font = '400 34px "Black Han Sans", sans-serif'; ctx.textAlign = 'center';
        ctx.fillText(`${st.n}단계 성공!`, G.w / 2, by + size / 2 - 32);
        ctx.fillStyle = '#f2e9d8'; ctx.font = '600 14px "IBM Plex Sans KR", sans-serif';
        ctx.fillText(`조각 ${st.used}개 사용 · ${st.sc}점`, G.w / 2, by + size / 2 + 6);
      }
      if (busyUntil && now > busyUntil) { busyUntil = 0; api.setBusy(false); }
    }
    function easeBack(t) { t = U.clamp(t, 0, 1); const c1 = 1.7; return 1 + (c1 + 1) * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }

    cv.onresize = () => layout();
    layout();
    stop = U.loop((dt, now) => draw(now == null ? performance.now() : now));

    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down') return;
      const b = [...document.querySelectorAll('[data-action="' + id + '"]')].find((x) => !x.disabled && x.getClientRects().length);
      if (b) b.click();
    }) : null;
    const noFocus = (e) => { const b = e.target && e.target.closest && e.target.closest('button[data-action]'); if (b) e.preventDefault(); };   // 마우스로 누른 버튼에 포커스가 남아 Space/Enter 단축키를 가로채지 않게
    document.addEventListener('mousedown', noFocus, true);
    return {
      update(s, prev) {
        if (!st) { DAILY.prune(); setTimeout(dailyIntro, 0); }
        if (!st && L.best) { const b = lsGet(LS_BEST), g = lsGet(LS_STAGE) - 1; if (b) L.best.set('colorblast', 'inf', b, { label: '무한 최고 점수', unit: '점' }); if (g > 0) L.best.set('colorblast', 'stage', g, { label: '최고 단계', unit: '단계' }); }
        const old = st;
        st = s;
        if (prev && prev !== s && s.last && (!prev.last || prev.last.id !== s.last.id)) {
          prevBoard = prev.b;
          onEvent(s.last);
          if (s.last.t === 'put' && prev.tray.filter(Boolean).length === 1 && s.tray.filter(Boolean).length > 1) { popIn = Object.assign(popIn || { t0: performance.now() }, { deal: true }); }
        } else if (!old) { scoreShown = s.sc; }
        nextBtn.style.display = s.ph === 'clear' && api.canAct(0) ? '' : 'none';
        if (s.ph === 'clear' && (!prev || prev.ph !== 'clear')) { lsSet(LS_STAGE, Math.max(lsGet(LS_STAGE), s.n + 1)); if (api.canAct(0)) api.best('stage', s.n, { label: '최고 단계', unit: '단계' }); api.sfx('win'); api.toast(`${s.n}단계 성공!`); }
        if (s.over && (!prev || !prev.over)) {
          if (s.m === 'inf' && s.sc > lsGet(LS_BEST)) lsSet(LS_BEST, s.sc);
          if (s.m === 'inf' && api.canAct(0)) api.best('inf', s.sc, { label: '무한 최고 점수', unit: '점' });
          if (s.m === 'st') lsSet(LS_STAGE, Math.max(lsGet(LS_STAGE), s.n));
          api.sfx(s.nb ? 'win' : 'lose');
        }
        if (s.ph === 'dclear' && (!prev || prev.ph !== 'dclear')) {
          const me = api.canAct(0) && !api.players[0].ai;
          if (me && DAILY.complete(s.dy, s.used, api)) api.toast('오늘 최고 기록!');
          api.sfx('win');
          if (me) setTimeout(() => { if (st && st.ph === 'dclear') dailyClear(); }, 700 / sp());
        }
        if (drag && (!s.tray[drag.i] || s.ph !== 'play')) drag = null;
      },
      destroy() { if (offKeys) offKeys(); document.removeEventListener('mousedown', noFocus, true); if (stop) stop(); closeD(); api.setBusy(false); nextBtn.remove(); cv.destroy(); },
    };
  }

  L.register({
    _daily: DAILY,
    id: 'colorblast', name: '컬러 블록 맞추기', tag: '블록 퍼즐', cat: '아케이드',
    blurb: '색 블록 조각 3개를 8×8 판에 끌어 놓아 가로·세로 줄을 채워 지우세요. 한 번에 여러 줄, 연속으로 지우면 콤보!',
    controls: [
      { id: 'next', label: '다음 단계', keys: ['Enter', 'Space'], pad: ['a'] },
    ],
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, hidden: false, aiDelay: 550, fixedOrder: true,
    tint: '#6a2a5e',
    icon: '<rect x="6" y="6" width="13" height="13" rx="3" fill="currentColor"/><rect x="21" y="6" width="13" height="13" rx="3" fill="currentColor"/><rect x="36" y="6" width="13" height="13" rx="3" fill="currentColor" opacity=".45"/><rect x="6" y="21" width="13" height="13" rx="3" fill="currentColor" opacity=".45"/><rect x="21" y="21" width="13" height="13" rx="3" fill="currentColor"/><rect x="6" y="36" width="13" height="13" rx="3" fill="currentColor"/><rect x="21" y="36" width="13" height="13" rx="3" fill="currentColor" opacity=".45"/><rect x="36" y="36" width="13" height="13" rx="3" fill="currentColor"/><rect x="36" y="21" width="13" height="13" rx="3" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="3 2"/>',
    options: [
      { id: 'mode', label: '방식', tip: '혼자 즐기는 방식.', choices: [{ v: 'inf', label: '무한', tip: '끝없이 이어지는 판, 최고 점수 도전.' }, { v: 'st', label: '단계', tip: '목표가 있는 단계를 하나씩 깨요.' }, { v: 'day', label: '📅 오늘의 퍼즐', tip: '날마다 모두 같은 퍼즐 하나.' }], def: 'inf' },
      { id: 'from', label: '단계 시작', tip: '「단계」 방식에서 어디부터 시작할지.', choices: [{ v: 'cont', label: '이어서' }, { v: 'one', label: '1단계부터' }], def: 'cont' },
    ],
    quick: [
      '아래 조각 3개를 끌어서 8×8 판에 놓아요.',
      '가로나 세로 한 줄을 꽉 채우면 그 줄이 사라지고 점수!',
      '남은 조각이 하나도 안 들어가면 끝 — 최고 점수에 도전해요.',
    ],
    rules: [
      { h: '목표', p: ['조각을 판에 놓아 줄을 지우며 점수를 모아요. 「무한」은 최고 점수, 「단계」는 단계마다 정해진 목표를 이루면 성공이에요.'] },
      { h: '차례에 할 일', p: ['아래 받침에 조각 3개가 나와요. 하나를 끌어서 판의 빈칸에 놓으세요(조각은 손가락보다 조금 위에 떠서 보여요). 돌릴 수는 없어요.', '3개를 다 놓으면 새 조각 3개가 나와요. 끄는 동안 놓일 자리가 반투명하게, 지워질 줄이 반짝이며 보여요.'] },
      { h: '점수', p: ['놓은 칸 1개 = 1점.', '줄 지우기: 1줄 80점, 2줄 동시 240점, 3줄 480점… 한 번에 많이 지울수록 크게 올라요.', '콤보: 줄을 지운 뒤 조각 3개 안에 또 지우면 콤보가 이어져요. 콤보 2 = ×1.5, 3 = ×2 …', '단색 줄: 지운 줄이 모두 같은 색이면 줄마다 120점 보너스!'] },
      { h: '끝', p: ['남은 조각이 어디에도 안 들어가면 끝나요. 「단계」에서는 조각 수가 정해져 있어서 다 쓰기 전에 목표를 이뤄야 해요.'] },
      { h: '단계', p: ['목표는 「줄 N개 지우기」「N점 만들기」「○○색 칸 N개 지우기」「○○색 단색 줄 N개」 중 하나예요. 단계마다 판과 조각 순서가 늘 같아서 다시 도전하며 요령을 익힐 수 있어요.', '성공하면 다음 단계가 열리고 진행은 이 기기에 저장돼요. 「단계 시작」을 「1단계부터」로 바꾸면 처음부터 해요.'] },
      { h: '오늘의 퍼즐', p: ['「방식」에서 「📅 오늘의 퍼즐」을 고르면 매일 하나씩 정해진 목표(20단계 급)에 도전해요. 날짜가 같으면 누구나 같은 판·같은 조각 순서예요.', '적은 조각으로 이룰수록 좋은 기록. 하루씩 이어서 깨면 🔥 연속 일수가 올라가고, 「📋 공유」로 판 내용 없이 결과를 복사할 수 있어요. 단계 진행과는 따로예요.'] },
      { h: '예시', p: ['한 줄에 7칸이 차 있고 빈칸 1개 → 1칸짜리 조각을 놓으면 그 줄이 사라져요. 동시에 세로줄도 차면 2줄 = 240점!'] },
    ],
    tutorial: [
      { text: '아래 받침의 조각을 손가락으로 눌러 판 위로 끌어 보세요. 조각은 손가락 위에 떠서 보여요.' },
      { text: '가로·세로 한 줄을 꽉 채우면 사라져요. 지워질 줄은 놓기 전에 반짝여요.' },
      { text: '같은 색으로만 된 줄을 지우면 보너스, 연달아 지우면 콤보예요!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
  });
})();
