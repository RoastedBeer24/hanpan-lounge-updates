/* 던전 주인 (dkeeper) — 리메이크 (2026-10-23, docs/DKEEPER_PLAN.md)
   서브컬처풍 던전 경영 + 침입자 방어. PC 전용. 턴제 상태(낮 경영 = 행동, 밤 침입 = 0.5초 단위 'tk' 행동으로 반실시간 진행).
   - 낮: 땅 파기·방·함정·마물 고용·배치·대화·선물·각성·포로 설득 (시간 제한 없음)
   - 밤: 용사 파티가 침입 → 함정·마물·주인 스킬로 막기 (1×/2×, 혼자 판은 일시정지)
   - 아침: 수입·급여·식사·기분·친밀도 이벤트·방문 마물
   - 캠페인 5~7장(장마다 칭호 용사, 마지막 「성검의 용사」), 끝없는 침입, 멀티 협동(구역 분담)
   등장인물은 전원 여성. 이름은 역할·칭호. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ================= 초상화 파일 목록(있는 것만) ================= */
  // img/dkeeper/<code>_<expr>.webp — 없는 캐릭터·표정은 캔버스 임시 초상으로 그림(표정 → 그 캐릭터 neutral → 임시)
  const PORTRAITS = {
    master: ['neutral', 'smile', 'angry', 'surprised', 'shy', 'serious', 'hurt', 'flustered'],
    dragonknight: ['neutral', 'smile', 'happy', 'angry', 'sad', 'surprised', 'shy', 'serious', 'hurt', 'flustered', 'awakened'],
  };
  const IMG_DIR = 'img/dkeeper/';

  /* ================= 기본 상수 ================= */
  const W = 32, H = 18, N = W * H;
  const idx = (x, y) => y * W + x;
  const cx = (i) => i % W, cy = (i) => (i / W) | 0;
  const NB4 = [];
  for (let i = 0; i < N; i++) { const x = cx(i), y = cy(i), a = []; if (x > 0) a.push(i - 1); if (x < W - 1) a.push(i + 1); if (y > 0) a.push(i - W); if (y < H - 1) a.push(i + W); NB4.push(a); }
  const setc = (str, i, ch) => str.slice(0, i) + ch + str.slice(i + 1);
  const R1 = (v) => Math.round(v * 10) / 10, R2 = (v) => Math.round(v * 100) / 100;
  const rnd = (n) => Math.floor(Math.random() * n);
  const pick = (a) => a[rnd(a.length)];
  const walkT = (c) => c === '.' || c === '~' || c === 'E' || c === 'H';
  const rockT = (c) => c === '#' || c === '$' || c === '*';

  /* ================= 역할 기본 능력 ================= */
  // hp, atk, def, rng, spd(칸/초), as(공격 간격 초), labor
  const ROLE = {
    f: { n: '전위', hp: 170, atk: 14, def: 22, rng: 1.1, spd: 1.6, as: 1.0, lab: 0 },
    b: { n: '후위', hp: 105, atk: 13, def: 8, rng: 4.5, spd: 1.7, as: 1.2, lab: 0 },
    m: { n: '마법', hp: 95, atk: 17, def: 6, rng: 4, spd: 1.5, as: 1.5, lab: 0 },
    s: { n: '지원', hp: 115, atk: 8, def: 10, rng: 3.5, spd: 1.6, as: 1.4, lab: 0 },
    w: { n: '노동', hp: 125, atk: 9, def: 12, rng: 1.1, spd: 1.7, as: 1.1, lab: 3 },
  };

  /* ================= 방 15종 ================= */
  // k: 칸 문자(방 층), c: 칸당 값, adj: 붙으면 서로 효과 +25%
  const ROOMS = [
    { k: 'a', n: '보물고', ic: '💰', c: 60, col: '#c9a03a', adj: 'g', e: '금고 +300 · 금화 +10/아침', d: '금고 한도 +300/칸, 아침마다 금화 +10/칸. 도적이 노려요.' },
    { k: 'b', n: '마력 샘', ic: '🔮', c: 70, col: '#6a5acd', adj: 'l', e: '마력 +7/아침 · 한도 +15', d: '아침마다 마력 +7/칸, 마력 한도 +15/칸.' },
    { k: 'c', n: '숙소', ic: '🛏', c: 40, col: '#7a5a48', adj: 'j', e: '마물 1명 숙소 · 회복 +5%', d: '마물 1명/칸이 지낼 수 있어요. 아침 회복 +5%/칸(최대 +40%).' },
    { k: 'd', n: '식당', ic: '🍖', c: 50, col: '#b8643a', adj: 'n', e: '마물 3명 식사', d: '마물 3명/칸을 먹여요. 못 먹으면 기분이 크게 떨어져요.' },
    { k: 'e', n: '훈련장', ic: '⚔', c: 70, col: '#8a3a3a', adj: 'f', e: '모든 마물 경험 +3/아침', d: '아침마다 모든 마물 경험 +3/칸.' },
    { k: 'f', n: '대장간', ic: '🔨', c: 80, col: '#a0522d', adj: 'e', e: '함정 피해 +4% · 값 -2%', d: '함정 피해 +4%/칸, 함정 값 -2%/칸(최대 -20%).' },
    { k: 'g', n: '경비실', ic: '🛡', c: 60, col: '#4f6b7a', adj: 'a', e: '여기 선 마물 방어 +12', d: '경비실에 배치된 마물 방어 +12. 칸마다 경비실 마물의 공격 +2%.' },
    { k: 'h', n: '감옥', ic: '⛓', c: 60, col: '#55505e', adj: 'k', e: '용사 포로 1명', d: '쓰러진 용사 1명/칸을 가둬요. 설득하면 동료가 돼요.' },
    { k: 'i', n: '연구실', ic: '⚗', c: 80, col: '#3a7a6a', adj: 'l', e: '연구 +4/아침', d: '아침마다 연구 +4/칸. 연구가 쌓이면 함정·주인 스킬이 열려요.' },
    { k: 'j', n: '온천', ic: '♨', c: 70, col: '#3a8fb0', adj: 'c', e: '기분 +2 · 회복 +10%', d: '아침마다 기분 +2/칸(최대 +8), 회복 +10%/칸.' },
    { k: 'k', n: '주인의 방', ic: '👑', c: 90, col: '#8a2d4f', adj: 'h', e: '주인 스킬 +4% · 마력 회복', d: '주인 스킬 위력 +4%/칸, 침입 중 마력 회복 +8%/칸.' },
    { k: 'l', n: '서고', ic: '📚', c: 70, col: '#5a4a8a', adj: 'i', e: '마력 한도 +30 · 연구 +1', d: '마력 한도 +30/칸, 연구 +1/칸.' },
    { k: 'n', n: '정원', ic: '🌿', c: 40, col: '#4a8a3a', adj: 'd', e: '식량 2명 · 금화 +3', d: '마물 2명/칸 몫의 식량. 아침 금화 +3/칸.' },
    { k: 'o', n: '제단', ic: '🕯', c: 90, col: '#7a6a9a', adj: 'k', e: '명성 +1/아침 · 근처 회복', d: '아침마다 명성 +1/칸. 침입 중 근처(3칸) 마물 회복.' },
    { k: 'p', n: '연회장', ic: '🍷', c: 80, col: '#9a3a6a', adj: 'd', e: '친밀도 +1/아침 · 대화 +½', d: '아침마다 모든 마물 친밀도 +1/칸(최대 +3), 대화 횟수 +1/2칸.' },
  ];
  const RM = {}; ROOMS.forEach((r) => (RM[r.k] = r));

  /* ================= 함정 20종 ================= */
  // rq: 필요 연구, cd: 재작동(초), dm: 피해, 효과는 fireTrap에서
  const TRAPS = [
    { k: 'A', n: '가시 바닥', ic: '▲', c: 50, rq: 0, cd: 2, dm: 20, d: '밟으면 가시가 솟아요.' },
    { k: 'B', n: '물웅덩이', ic: '💧', c: 35, rq: 0, cd: 0.5, dm: 0, d: '적을 적셔요(6초, 조금 느려짐). 전격·냉기와 연계.' },
    { k: 'C', n: '전격 룬', ic: '⚡', c: 85, rq: 0, cd: 4, dm: 22, d: '젖은 적에게 ×2.2, 근처 젖은 적에게 번져요「감전」.' },
    { k: 'S', n: '끈끈이 바닥', ic: '🟢', c: 45, rq: 0, cd: 2, dm: 0, d: '4초 동안 크게 느려져요.' },
    { k: 'D', n: '화염 분사', ic: '🔥', c: 95, rq: 20, cd: 4, dm: 16, d: '불붙여요(4초). 기름 묻은 적은 「대폭발」.' },
    { k: 'E', n: '기름 바닥', ic: '🛢', c: 45, rq: 20, cd: 0.5, dm: 0, d: '기름 범벅(8초, 느려짐). 화염과 연계.' },
    { k: 'F', n: '냉기 룬', ic: '❄', c: 85, rq: 20, cd: 5, dm: 10, d: '느리게(3초). 젖은 적은 「빙결」로 2.5초 얼어요.' },
    { k: 'K', n: '그물', ic: '🕸', c: 65, rq: 20, cd: 6, dm: 0, d: '3초 동안 묶어요(이동 불가).' },
    { k: 'G', n: '독안개', ic: '☠', c: 105, rq: 45, cd: 6, dm: 0, d: '주변 1칸 독(5초, 초당 피해). 불이 닿으면 「독연 폭발」.' },
    { k: 'H', n: '회전 칼날', ic: '✴', c: 130, rq: 45, cd: 2.5, dm: 30, d: '묶이거나 기절한 적에게 ×1.7「난도질」.' },
    { k: 'L', n: '마비 룬', ic: '💫', c: 115, rq: 45, cd: 8, dm: 5, d: '2초 기절.' },
    { k: 'M', n: '화살 벽', ic: '➹', c: 115, rq: 45, cd: 2.5, dm: 15, d: '2.5칸 안에 들어온 적을 쏴요(밟지 않아도).' },
    { k: 'T', n: '미믹 보물상자', ic: '🎁', c: 140, rq: 45, cd: 8, dm: 45, d: '도적·보물 사냥꾼을 꾀어 덥석! 1.5초 묶어요.' },
    { k: 'I', n: '굴러오는 바위', ic: '🪨', c: 150, rq: 80, cd: 10, dm: 60, d: '같은 줄 4칸 안의 적을 모두 쳐요.' },
    { k: 'J', n: '함정문', ic: '🕳', c: 170, rq: 80, cd: 14, dm: 40, d: '체력 45% 아래면 감옥으로 곧장(빈 자리 있을 때). 아니면 피해+기절.' },
    { k: 'N', n: '거울 환영', ic: '🪞', c: 125, rq: 80, cd: 10, dm: 0, d: '4초 혼란 — 엉뚱한 길로 헤매요.' },
    { k: 'O', n: '흡혈 덩굴', ic: '🌱', c: 140, rq: 80, cd: 6, dm: 20, d: '2.5초 묶고 피를 빨아 근처 마물을 회복.' },
    { k: 'P', n: '수면 가스', ic: '💤', c: 135, rq: 120, cd: 12, dm: 0, d: '주변 1칸 3초 잠재움(맞으면 깨요).' },
    { k: 'Q', n: '저주 문양', ic: '☾', c: 115, rq: 120, cd: 8, dm: 0, d: '8초 공격 -35%, 받는 피해 +25%.' },
    { k: 'R', n: '폭발 룬', ic: '💥', c: 190, rq: 120, cd: 20, dm: 80, d: '주변 1.8칸 큰 폭발.' },
  ];
  const TP = {}; TRAPS.forEach((t) => (TP[t.k] = t));
  const COMBOS = [
    ['감전', '물웅덩이 + 전격 룬', '젖은 적에게 전격 피해 ×2.2, 2칸 안 젖은 적에게 번져요.'],
    ['빙결', '물웅덩이 + 냉기 룬', '젖은 적이 2.5초 꽁꽁 얼어요.'],
    ['대폭발', '기름 바닥 + 화염 분사', '기름 묻은 적이 터지며 주변 1.5칸에 큰 피해.'],
    ['독연 폭발', '독안개 + 화염(함정·스킬)', '중독된 적에게 불이 닿으면 추가 피해.'],
    ['난도질', '그물·덩굴·끈끈이·마비·빙결 + 회전 칼날', '묶이거나 기절한 적에게 칼날 ×1.7.'],
    ['저주받은 몸', '저주 문양 + 아무 공격', '받는 피해 +25%.'],
  ];

  /* ================= 스킬(마물·용사 공용) ================= */
  // t: single(적 하나) aoe(적 무리) self ally(아군 하나) allies(주변 아군) / rg 사거리 r 반경 dm 피해 배수 st 상태 du 지속 hl 회복(최대 체력 비율) cd
  const SK = {
    slam: { n: '내려찍기', t: 'single', rg: 1.3, dm: 1.9, cd: 6, d: '강하게 내려쳐요.' },
    cleave: { n: '휩쓸기', t: 'aoe', rg: 0, r: 1.4, dm: 1.1, cd: 7, d: '주변 적을 모두 베요.' },
    taunt: { n: '도발', t: 'aoe', rg: 0, r: 2.6, st: 'tt', du: 3, cd: 10, d: '주변 적이 자신을 노려요.' },
    guard: { n: '철벽', t: 'self', st: 'df', v: 40, du: 5, cd: 12, d: '방어 +40(5초).' },
    charge: { n: '돌진', t: 'single', rg: 4, dm: 1.3, st: 'sn', du: 1, dash: 1, cd: 9, d: '달려들어 1초 기절.' },
    bite: { n: '물어뜯기', t: 'single', rg: 1.3, dm: 1.4, st: 'ps', du: 5, cd: 7, d: '피해 + 중독.' },
    shot: { n: '저격', t: 'single', rg: 6, dm: 2.1, cd: 7, d: '멀리서 한 발.' },
    volley: { n: '연사', t: 'aoe', rg: 5, r: 1.2, dm: 0.85, cd: 9, d: '화살비.' },
    fire: { n: '불덩이', t: 'aoe', rg: 4.5, r: 1.2, dm: 1.4, st: 'bn', du: 4, fire: 1, cd: 8, d: '폭발 + 화상.' },
    frost: { n: '서리 화살', t: 'single', rg: 5, dm: 1.1, st: 'sl', du: 3, cd: 7, d: '피해 + 둔화.' },
    thunder: { n: '벼락', t: 'single', rg: 5, dm: 1.8, wet: 2, cd: 9, d: '젖은 적 ×2.' },
    curse: { n: '저주', t: 'single', rg: 4.5, st: 'cs', du: 6, cd: 10, d: '공격 -35%, 받는 피해 +25%.' },
    heal: { n: '치유', t: 'ally', rg: 4, hl: 0.28, cd: 7, d: '가장 다친 아군 회복.' },
    mend: { n: '회복의 노래', t: 'allies', r: 3.2, hl: 0.13, cd: 10, d: '주변 아군 모두 회복.' },
    bless: { n: '축복', t: 'allies', r: 3.2, st: 'bf', v: 0.3, du: 6, cd: 12, d: '주변 아군 공격 +30%.' },
    lullaby: { n: '자장가', t: 'aoe', rg: 3.5, r: 1.5, st: 'sp', du: 2.5, cd: 12, d: '잠재워요.' },
    charm: { n: '매혹', t: 'single', rg: 3.5, st: 'ch', du: 4, cd: 14, d: '잠깐 우리 편으로.' },
    fear: { n: '공포', t: 'aoe', rg: 0, r: 2.2, st: 'fr', du: 2.5, cd: 12, d: '적이 겁먹고 달아나요.' },
    web: { n: '거미줄', t: 'single', rg: 4, st: 'rt', du: 3, cd: 9, d: '3초 묶어요.' },
    drain: { n: '흡혈', t: 'single', rg: 1.3, dm: 1.3, ls: 1, cd: 8, d: '준 피해만큼 회복.' },
    swallow: { n: '삼키기', t: 'single', rg: 1.3, dm: 1.0, st: 'sn', du: 3, cd: 12, d: '꿀꺽 — 3초 기절.' },
    quake: { n: '지진', t: 'aoe', rg: 0, r: 2, dm: 1.2, st: 'sl', du: 2, cd: 12, d: '주변 피해 + 둔화.' },
    howl: { n: '울부짖음', t: 'allies', r: 3.2, st: 'bf', v: 0.25, du: 7, cd: 12, d: '주변 아군 공격 +25%.' },
    spore: { n: '포자 구름', t: 'aoe', rg: 3, r: 1.5, st: 'ps', du: 5, cd: 9, d: '중독.' },
    wail: { n: '통곡', t: 'aoe', rg: 0, r: 2.5, st: 'fr', du: 2, dm: 0.6, cd: 11, d: '피해 + 공포.' },
    foxfire: { n: '여우불', t: 'aoe', rg: 4.5, r: 1, dm: 1.3, fire: 1, st: 'bn', du: 3, cd: 6, d: '푸른 불꽃.' },
    confuse: { n: '환술', t: 'single', rg: 4, st: 'cf', du: 3, cd: 10, d: '헤매게 해요.' },
    snap: { n: '덥석', t: 'single', rg: 1.3, dm: 2.3, cd: 10, d: '보물상자 입으로 덥석.' },
    rearm: { n: '함정 손보기', t: 'trap', r: 4, cd: 12, d: '근처 함정을 바로 다시 작동.' },
    temper: { n: '담금질', t: 'allies', r: 3.2, st: 'df', v: 25, du: 6, cd: 12, d: '주변 아군 방어 +25.' },
    roar: { n: '포효', t: 'aoe', rg: 0, r: 2.4, st: 'tt', du: 3, dm: 0.5, cd: 10, d: '피해 + 도발.' },
    gaze: { n: '석화의 눈빛', t: 'single', rg: 4, st: 'sn', du: 2, cd: 11, d: '2초 굳혀요.' },
    haste: { n: '질풍', t: 'self', st: 'hs', du: 5, cd: 10, d: '5초 빨라져요.' },
    // 각성 스킬
    a_wave: { n: '해일 삼키기', t: 'aoe', rg: 0, r: 2.2, dm: 1.6, st: 'sn', du: 2, cd: 14, d: '각성: 주변을 삼켜 기절.' },
    a_oath: { n: '망국의 맹세', t: 'allies', r: 4, st: 'df', v: 50, du: 8, cd: 16, d: '각성: 주변 아군 방어 +50.' },
    a_storm: { n: '달빛 깃털비', t: 'aoe', rg: 6, r: 2, dm: 1.4, cd: 12, d: '각성: 넓은 깃털 폭풍.' },
    a_coil: { n: '대사의 똬리', t: 'aoe', rg: 0, r: 1.8, dm: 1.2, st: 'rt', du: 3, cd: 13, d: '각성: 주변 적을 감아 묶어요.' },
    a_breath: { n: '용의 숨결', t: 'aoe', rg: 4, r: 1.8, dm: 2.2, fire: 1, st: 'bn', du: 4, cd: 13, d: '각성: 불의 숨결.' },
    a_banquet: { n: '완벽한 접대', t: 'allies', r: 5, hl: 0.25, st: 'bf', v: 0.3, du: 6, cd: 18, d: '각성: 아군 회복 + 공격 +30%.' },
    a_fortress: { n: '움직이는 요새', t: 'self', st: 'df', v: 90, du: 8, cd: 16, d: '각성: 방어 +90, 도발.', tt: 1 },
    a_brew: { n: '대실패 물약', t: 'aoe', rg: 4.5, r: 2, dm: 1.8, st: 'cf', du: 2, cd: 13, d: '각성: 폭발 + 혼란.' },
    a_moon: { n: '은월의 송곳니', t: 'single', rg: 1.4, dm: 3.2, ls: 0.5, cd: 10, d: '각성: 강타 + 흡혈.' },
    a_hoard: { n: '보물 산사태', t: 'aoe', rg: 0, r: 2, dm: 1.8, st: 'sn', du: 1.5, cd: 13, d: '각성: 금화 폭포.' },
    a_lanterns: { n: '백 개의 등불', t: 'allies', r: 5, hl: 0.3, cd: 16, d: '각성: 넓은 회복.' },
    a_rage: { n: '광전사의 도끼', t: 'aoe', rg: 0, r: 1.8, dm: 2.2, cd: 11, d: '각성: 강한 회전 베기.' },
    a_turret: { n: '자동 포탑', t: 'aoe', rg: 5, r: 1.3, dm: 1.6, cd: 9, d: '각성: 기계 팔 포격.' },
    a_bloom: { n: '만개', t: 'allies', r: 5, hl: 0.22, st: 'df', v: 20, du: 6, cd: 15, d: '각성: 회복 + 방어.' },
    a_tide: { n: '물의 고리', t: 'aoe', rg: 4, r: 2, dm: 1.0, wetS: 1, st: 'sl', du: 4, cd: 12, d: '각성: 적을 적시고 둔화.' },
    a_inferno: { n: '업화', t: 'aoe', rg: 4.5, r: 2, dm: 2.0, fire: 1, st: 'bn', du: 5, cd: 13, d: '각성: 큰 불바다.' },
    a_silk: { n: '황금 비단', t: 'aoe', rg: 4.5, r: 2, st: 'rt', du: 3.5, cd: 14, d: '각성: 넓은 속박.' },
    a_rider: { n: '망령 기마', t: 'single', rg: 5, dm: 2.4, st: 'fr', du: 3, dash: 1, cd: 11, d: '각성: 돌격 + 공포.' },
    a_souls: { n: '영혼 폭풍', t: 'aoe', rg: 5, r: 2.2, dm: 1.7, cd: 12, d: '각성: 영혼을 휘몰아쳐요.' },
    a_maze: { n: '미궁의 주인', t: 'aoe', rg: 0, r: 2.2, dm: 1.4, st: 'cf', du: 3, cd: 13, d: '각성: 피해 + 혼란.' },
    a_ninetail: { n: '구미호 강림', t: 'aoe', rg: 5, r: 2, dm: 1.8, st: 'ch', du: 3, cd: 15, d: '각성: 피해 + 매혹.' },
    a_kanabo: { n: '천둥 철퇴', t: 'aoe', rg: 0, r: 1.8, dm: 2.4, st: 'sn', du: 1.5, cd: 12, d: '각성: 땅을 부수는 일격.' },
    a_obsidian: { n: '흑요석 날개', t: 'self', st: 'df', v: 70, du: 8, cd: 15, d: '각성: 방어 +70.', tt: 1 },
    a_glow: { n: '발광 포자', t: 'aoe', rg: 4, r: 2.2, st: 'sp', du: 3, cd: 15, d: '각성: 넓게 잠재워요.' },
    a_aria: { n: '진주의 아리아', t: 'allies', r: 5, hl: 0.3, st: 'bf', v: 0.2, du: 6, cd: 16, d: '각성: 회복 + 공격.' },
    a_hellfire: { n: '지옥불 꼬리', t: 'aoe', rg: 3.5, r: 1.5, dm: 1.6, fire: 1, st: 'bn', du: 4, cd: 10, d: '각성: 불꼬리.' },
    a_forge: { n: '용광로 망치', t: 'aoe', rg: 0, r: 1.8, dm: 2.0, st: 'sn', du: 1, cd: 11, d: '각성: 달군 망치.' },
    a_dirge: { n: '죽음의 진혼가', t: 'aoe', rg: 0, r: 3, dm: 1.3, st: 'fr', du: 3, cd: 14, d: '각성: 넓은 공포.' },
    a_hunt: { n: '삼수의 사냥', t: 'single', rg: 6, dm: 3.0, st: 'ps', du: 5, cd: 9, d: '각성: 저격 + 중독.' },
    a_dream: { n: '꿈결의 낙원', t: 'aoe', rg: 4.5, r: 2, st: 'ch', du: 4, cd: 16, d: '각성: 무리 매혹.' },
    a_flame: { n: '진홍 업화검', t: 'aoe', rg: 0, r: 2, dm: 2.4, fire: 1, st: 'bn', du: 4, cd: 11, d: '각성: 불의 대검.' },
    a_galaxy: { n: '은하 붕괴', t: 'aoe', rg: 6, r: 2.4, dm: 2.4, cd: 14, d: '각성: 별이 떨어져요.' },
    a_bloodmoon: { n: '핏빛 달', t: 'aoe', rg: 0, r: 3, dm: 1.4, ls: 0.5, cd: 13, d: '각성: 넓은 흡혈.' },
    a_wolfking: { n: '은랑의 군세', t: 'allies', r: 5, st: 'bf', v: 0.45, du: 8, cd: 16, d: '각성: 아군 공격 +45%.' },
    // 용사 스킬
    h_heal: { n: '성스러운 손길', t: 'ally', rg: 4, hl: 0.25, cd: 6, d: '' },
    h_fire: { n: '화염구', t: 'aoe', rg: 4.5, r: 1.2, dm: 1.3, fire: 1, cd: 7, d: '' },
    h_shield: { n: '수호의 오라', t: 'allies', r: 3, st: 'df', v: 25, du: 6, cd: 12, d: '' },
    h_back: { n: '급소 찌르기', t: 'single', rg: 1.3, dm: 2.6, cd: 8, d: '' },
    h_bomb: { n: '폭탄 플라스크', t: 'aoe', rg: 4, r: 1.3, dm: 1.3, cd: 8, d: '' },
    h_song: { n: '용기의 노래', t: 'allies', r: 3.5, st: 'bf', v: 0.25, du: 6, cd: 12, d: '' },
    h_arrow: { n: '관통 화살', t: 'single', rg: 6, dm: 1.9, cd: 7, d: '' },
    h_palm: { n: '장타', t: 'single', rg: 1.3, dm: 1.5, st: 'sn', du: 1, cd: 8, d: '' },
    h_lance: { n: '창 돌격', t: 'single', rg: 4, dm: 1.6, dash: 1, cd: 9, d: '' },
    h_cleanse: { n: '정화', t: 'allies', r: 3, cl: 1, cd: 9, d: '' },
    // 칭호 용사
    b_holy: { n: '성검 해방', t: 'aoe', rg: 0, r: 2.2, dm: 2.2, cd: 9, d: '' },
    b_flame: { n: '심판의 불꽃', t: 'aoe', rg: 0, r: 2, dm: 1.8, fire: 1, st: 'bn', du: 4, cd: 8, d: '' },
    b_stake: { n: '은 말뚝', t: 'single', rg: 6, dm: 2.8, cd: 6, d: '' },
    b_meteor: { n: '유성', t: 'aoe', rg: 6, r: 2, dm: 2.0, cd: 9, d: '' },
    b_pack: { n: '사냥 신호', t: 'allies', r: 4, st: 'bf', v: 0.35, du: 6, cd: 12, d: '' },
    b_miracle: { n: '기적', t: 'allies', r: 5, hl: 0.35, cl: 1, cd: 11, d: '' },
  };

  /* ================= 마왕군 간부 4 · 마물 동료 30 ================= */
  // [code, 이름, 역할키, 역할 표시, 좋아하는 방, 좋아하는 일, 급여, 고용비, 체력배수, 공격배수, 스킬, 각성 스킬, 성격, 색[머리, 옷, 포인트, 피부]]
  const EXEC = [
    ['dragonknight', '진홍 용기사', 'f', '간부 · 전위 대장', 'e', '경비', 0, 0, 2.3, 2.0, ['slam', 'taunt', 'guard'], 'a_flame', '엄격하고 충성스러운 무인. 마왕 앞에서만 말이 서툴러진다', ['#c0283a', '#7a1a24', '#e3ae45', '#f3dccb']],
    ['abysswitch', '심연의 대마녀', 'm', '간부 · 마법 대장', 'i', '연구', 0, 0, 1.8, 2.3, ['thunder', 'fire', 'curse'], 'a_galaxy', '능글맞은 천재. 연구실을 자주 폭발시킨다', ['#c8c8d8', '#2a1f3a', '#9a6ad0', '#f1e2d6']],
    ['nightduchess', '밤의 여공작', 's', '간부 · 재무와 외교', 'a', '재무', 0, 0, 1.9, 1.9, ['drain', 'charm', 'bless'], 'a_bloodmoon', '냉정한 귀족. 금화 계산과 예절에 엄격하다', ['#e8e0d0', '#5a1428', '#c02040', '#f6e8e4']],
    ['beastqueen', '짐승 무리의 여왕', 'f', '간부 · 습격대장', 'e', '사냥', 0, 0, 2.1, 2.2, ['cleave', 'howl', 'charge'], 'a_wolfking', '호탕한 싸움꾼. 강한 상대를 보면 웃는다', ['#d0d4dc', '#6a4a2a', '#c08040', '#c89870']],
  ];
  const ALLY = [
    ['slime', '말랑 슬라임', 'w', '노동·전위', 'd', '운반', 10, 70, 1.1, 0.9, ['swallow', 'guard'], 'a_wave', '뭐든 삼키고 뭐든 운반하는 낙천가', ['#7ec8f0', '#5aa8e0', '#b8e8ff', '#bfe6fa']],
    ['skelknight', '녹슨 해골 기사', 'f', '전위', 'g', '경비', 18, 110, 1.05, 1.0, ['slam', 'taunt'], 'a_oath', '옛 왕국의 기사. 기사도를 고집한다', ['#d8d8e0', '#2a2e3a', '#4a7ad0', '#e8e4dc']],
    ['harpy', '달빛 하피', 'b', '후위·정찰', 'n', '정찰', 14, 90, 0.95, 1.0, ['shot', 'haste'], 'a_storm', '수다쟁이 정찰병', ['#f0f0f8', '#9ab0c8', '#d0d8f0', '#f6e6da']],
    ['lamia', '늪지 라미아', 'f', '전위', 'j', '경비', 17, 110, 1.15, 1.0, ['web', 'bite'], 'a_coil', '느긋하지만 한번 감으면 놓지 않는다', ['#2a5a3a', '#4a3a2a', '#3ac070', '#f0dcc8']],
    ['dragonkid', '붉은 비늘 견습', 'f', '전위·마법', 'e', '훈련', 16, 120, 1.0, 1.1, ['charge', 'fire'], 'a_breath', '용기사를 동경하는 견습 기사', ['#d03030', '#8a5a3a', '#f0a030', '#f6dcc8']],
    ['butler', '서큐버스 집사', 's', '지원', 'p', '살림', 20, 130, 0.95, 0.9, ['heal', 'bless'], 'a_banquet', '던전 살림을 맡은 완벽주의자', ['#6a4a9a', '#1a1a24', '#e8e8f0', '#f4e2da']],
    ['golem', '돌집 골렘', 'w', '노동·전위', 'f', '채굴', 14, 120, 1.4, 0.9, ['guard', 'quake'], 'a_fortress', '말수가 적고 힘이 세다', ['#5a7a4a', '#8a8a90', '#60d0c0', '#c8c8c0']],
    ['witchapprentice', '견습 마녀', 'm', '마법', 'i', '연구', 15, 100, 0.9, 1.05, ['frost', 'fire'], 'a_brew', '대마녀의 제자. 실험이 자주 엇나간다', ['#4ab060', '#4a3a6a', '#a070d0', '#f6e2d0']],
    ['werewolf', '은빛 늑대 전사', 'f', '전위', 'e', '사냥', 20, 140, 1.1, 1.15, ['bite', 'howl'], 'a_moon', '짐승 여왕의 오른팔', ['#a0a4ac', '#5a4a3a', '#c0c8d8', '#e8d0b8']],
    ['mimic', '장난꾸러기 미믹', 'w', '노동·함정', 'a', '함정', 12, 100, 1.0, 1.1, ['snap', 'rearm'], 'a_hoard', '보물상자 행세로 용사를 놀래는 게 취미', ['#c06030', '#7a4a20', '#e0b040', '#f6dcc8']],
    ['ghost', '등불 유령', 's', '지원·마법', 'o', '안내', 14, 110, 0.85, 0.9, ['heal', 'fear'], 'a_lanterns', '길 잃은 영혼을 이끄는 상냥한 안내자', ['#f0f4ff', '#c8d4ec', '#60a0ff', '#eef2fa']],
    ['orc', '도끼 오크', 'f', '전위·노동', 'd', '먹기', 15, 110, 1.2, 1.1, ['cleave', 'slam'], 'a_rage', '먹는 것과 싸우는 것을 좋아한다', ['#1a1a1a', '#6a4a2a', '#c04030', '#7aa060']],
    ['goblin', '손재주 고블린', 'w', '노동·함정', 'f', '발명', 12, 90, 0.85, 0.9, ['rearm', 'volley'], 'a_turret', '함정 설계 담당 발명가', ['#3a3a2a', '#7a5a3a', '#e0a030', '#8ac060']],
    ['dryad', '숲 정령', 's', '지원', 'n', '정원', 15, 110, 0.95, 0.85, ['mend', 'web'], 'a_bloom', '던전 정원을 가꾸는 치유사', ['#4a9a3a', '#7ab060', '#f0a0c0', '#d8c0a0']],
    ['undine', '샘물 운디네', 's', '지원·마법', 'j', '온천', 16, 120, 0.9, 0.95, ['heal', 'frost'], 'a_tide', '온천 담당. 늘 차분하다', ['#60c8e0', '#3a90c0', '#c0f0ff', '#d0eef8']],
    ['salamander', '화염 살라만다', 'm', '마법', 'f', '불지기', 17, 120, 0.95, 1.15, ['fire', 'haste'], 'a_inferno', '다혈질 대장간 불지기', ['#f07020', '#a03020', '#ffd040', '#f6d4b8']],
    ['arachne', '거미 직조공', 'b', '후위·노동', 'p', '재봉', 16, 120, 1.0, 0.95, ['web', 'shot'], 'a_silk', '던전 의상을 짓는 재봉사', ['#2a1a3a', '#3a2a4a', '#9a5ad0', '#f0e0e8']],
    ['dullahan', '목 없는 기사', 'f', '전위', 'o', '경비', 21, 150, 1.2, 1.1, ['charge', 'fear'], 'a_rider', '죽음의 사자. 의외로 다정하다', ['#e8d8b0', '#1a1a2a', '#60a0ff', '#f0e4d8']],
    ['lich', '서고의 리치', 'm', '마법', 'l', '사서', 22, 160, 0.9, 1.25, ['curse', 'thunder'], 'a_souls', '도서관 관장. 빌려 간 책은 꼭 받아 낸다', ['#3a3a4a', '#2a2a3a', '#60e080', '#e0e0d8']],
    ['minotaur', '미궁 미노타우로스', 'f', '전위', 'g', '경비', 22, 160, 1.4, 1.15, ['roar', 'charge'], 'a_maze', '미궁 지기. 덩치에 비해 수줍음이 많다', ['#5a3a2a', '#8a6a30', '#e0c070', '#d8b090']],
    ['kitsune', '구미호 무녀', 'm', '마법', 'o', '제사', 22, 170, 0.95, 1.2, ['foxfire', 'confuse'], 'a_ninetail', '속내를 알 수 없는 여우 무녀', ['#f0d0a0', '#f0f0f0', '#d03030', '#f8e8dc']],
    ['oni', '철퇴 오니', 'f', '전위', 'p', '씨름', 20, 150, 1.3, 1.2, ['slam', 'quake'], 'a_kanabo', '술과 씨름을 사랑하는 호걸', ['#f0f0f0', '#e0b030', '#c03020', '#e07060']],
    ['gargoyle', '돌날개 파수꾼', 'b', '후위·전위', 'g', '파수', 17, 130, 1.25, 0.95, ['gaze', 'guard'], 'a_obsidian', '밤새 문을 지키는 과묵한 파수꾼', ['#6a6a72', '#5a5a62', '#d04040', '#9a9aa2']],
    ['mushroom', '포자 버섯', 'w', '지원·노동', 'n', '재배', 10, 80, 0.95, 0.85, ['spore', 'mend'], 'a_glow', '늘 졸린 식량 담당', ['#c0a080', '#e0d0c0', '#d04040', '#f4e4d4']],
    ['mermaid', '지하호수 인어', 's', '지원', 'j', '노래', 17, 130, 0.9, 0.85, ['lullaby', 'mend'], 'a_aria', '노래로 동료를 달래는 가수', ['#3a70d0', '#40a0b0', '#f0f0f0', '#f4e0d4']],
    ['imp', '심부름 임프', 'w', '노동', 'a', '심부름', 8, 60, 0.75, 0.85, ['haste', 'fire'], 'a_hellfire', '잔꾀 많은 심부름꾼', ['#2a1a1a', '#5a2020', '#ff8030', '#d86050']],
    ['cyclops', '외눈 대장장이', 'w', '노동·전위', 'f', '대장일', 18, 140, 1.25, 1.05, ['temper', 'slam'], 'a_forge', '장인 기질의 대장장이', ['#5a3a2a', '#6a5040', '#ff9030', '#e0c0a0']],
    ['banshee', '통곡의 반시', 'm', '마법', 'o', '노래', 18, 140, 0.85, 1.1, ['wail', 'curse'], 'a_dirge', '슬픈 노래로 적을 얼어붙게 한다', ['#f0f0f8', '#d8d8e8', '#8080c0', '#eaeaf2']],
    ['chimera', '키메라 사냥꾼', 'b', '후위', 'e', '사냥', 19, 140, 1.0, 1.2, ['shot', 'bite'], 'a_hunt', '사냥에 미친 야생아', ['#d0a040', '#6a5030', '#40a040', '#e8c8a0']],
    ['succubus', '꿈결 서큐버스', 'm', '마법·매혹', 'p', '유혹', 21, 160, 0.9, 1.1, ['charm', 'lullaby'], 'a_dream', '꿈속에서 용사를 홀리는 장난꾼', ['#f080b0', '#1a1020', '#c03070', '#f6e2dc']],
  ];
  const MON = {};
  function mkMon(a, ex) {
    const R = ROLE[a[2]];
    return { k: a[0], n: a[1], rk: a[2], rl: a[3], like: a[4], work: a[5], wage: a[6], cost: a[7],
      hp: Math.round(R.hp * a[8]), atk: Math.round(R.atk * a[9] * 10) / 10, def: R.def, rng: R.rng, spd: R.spd, as: R.as,
      lab: R.lab + (a[2] === 'w' ? 0 : 0) + (/노동/.test(a[3]) && a[2] !== 'w' ? 2 : 0), sk: a[10], aw: a[11], ps: a[12], col: a[13], ex: !!ex };
  }
  EXEC.forEach((a) => (MON[a[0]] = mkMon(a, 1)));
  ALLY.forEach((a) => (MON[a[0]] = mkMon(a, 0)));
  MON.dragonknight.def = 40; MON.beastqueen.spd = 1.9;

  /* ================= 침입 용사 12 · 칭호 용사 6 ================= */
  // ai: m 근접 r 원거리 h 치유 t 도적 a 암살 x 탐험 / dis: 함정 해제 확률 / loot 처치 시 금화
  const HERO = {
    rookie: { n: '신참 검사', hp: 120, atk: 12, def: 14, rng: 1.1, spd: 1.6, as: 1.0, ai: 'm', loot: 30, sk: ['slam'], col: ['#7a4a2a', '#9aa0b0', '#c0c8d8', '#f6dcc8'], d: '첫 모험에 나선 열혈 신참.' },
    thief: { n: '도적', hp: 90, atk: 10, def: 8, rng: 1.1, spd: 2.1, ai: 't', as: 0.8, loot: 40, dis: 0.45, sk: ['haste'], col: ['#1a1a1a', '#3a3a3a', '#a08040', '#f0d8c0'], d: '함정 해제의 달인. 보물고부터 털고 달아나요.' },
    nun: { n: '수녀', hp: 100, atk: 6, def: 10, rng: 3.5, spd: 1.5, as: 1.4, ai: 'h', loot: 35, sk: ['h_heal', 'h_cleanse'], col: ['#f0d070', '#f0f0f0', '#e0b040', '#f6e2d4'], d: '동료를 치유하고 상태 이상을 씻어요.' },
    elemental: { n: '원소 마법사', hp: 80, atk: 16, def: 6, rng: 4, spd: 1.5, as: 1.6, ai: 'r', loot: 40, sk: ['h_fire'], col: ['#3a3a5a', '#3a60c0', '#a0d0ff', '#f6e2d4'], d: '화염구로 마물 무리를 태워요.' },
    elfarcher: { n: '엘프 궁수', hp: 85, atk: 14, def: 8, rng: 5, spd: 1.7, as: 1.2, ai: 'r', loot: 40, sk: ['h_arrow'], col: ['#f0d080', '#3a7a3a', '#c0e0a0', '#f6e6d8'], d: '먼 거리에서 정확히 쏴요.' },
    paladin: { n: '성기사', hp: 220, atk: 11, def: 32, rng: 1.1, spd: 1.3, as: 1.2, ai: 'm', loot: 50, sk: ['h_shield'], col: ['#e0c060', '#d0d4e0', '#f0d040', '#f6e2d4'], d: '단단한 방패. 주변 동료 방어를 올려요.' },
    assassin: { n: '암살자', hp: 100, atk: 20, def: 10, rng: 1.1, spd: 2.0, as: 0.9, ai: 'a', loot: 50, dis: 0.2, sk: ['h_back'], col: ['#202020', '#1a1a24', '#a02030', '#f0dcd0'], d: '마법·지원 마물을 먼저 노려요.' },
    explorer: { n: '보물 사냥꾼', hp: 100, atk: 9, def: 10, rng: 1.1, spd: 1.9, as: 1.0, ai: 'x', loot: 45, dis: 0.3, sk: ['haste'], col: ['#a06030', '#8a6a40', '#e0c060', '#f6dcc8'], d: '함정을 찾아내 길드에 알려요(함정 기억).' },
    royalknight: { n: '왕국 기사', hp: 180, atk: 15, def: 25, rng: 1.1, spd: 1.5, as: 1.0, ai: 'm', loot: 55, sk: ['h_lance'], col: ['#c0a060', '#3a5ac0', '#e0e0f0', '#f6e2d4'], d: '창 돌격으로 뚫고 들어와요.' },
    monk: { n: '무도가', hp: 140, atk: 16, def: 12, rng: 1.1, spd: 1.9, as: 0.8, ai: 'm', loot: 40, sk: ['h_palm'], col: ['#2a2a2a', '#e0e0d8', '#c03030', '#e8c8a8'], d: '빠른 주먹, 장타로 기절시켜요.' },
    alchemist: { n: '연금술사', hp: 90, atk: 12, def: 9, rng: 3.5, spd: 1.6, as: 1.3, ai: 'r', loot: 50, sk: ['h_bomb'], imm: 'ps', col: ['#6a3a2a', '#6a5a3a', '#60d0a0', '#f6e2d4'], d: '폭탄 플라스크. 독에 면역.' },
    bard: { n: '음유시인', hp: 90, atk: 7, def: 9, rng: 3, spd: 1.6, as: 1.3, ai: 'h', loot: 40, sk: ['h_song'], col: ['#e0a040', '#c04080', '#40c0a0', '#f6e2d4'], d: '노래로 동료 공격을 올려요.' },
    // 칭호 용사
    tamer: { n: '맹수 조련사', boss: 1, hp: 900, atk: 24, def: 22, rng: 1.2, spd: 1.7, as: 0.9, ai: 'm', loot: 300, sk: ['b_pack', 'slam'], col: ['#8a5a2a', '#6a4a2a', '#e0a040', '#e8c8a8'], d: '짐승 떼를 이끄는 조련사. 늑대들을 데려와요.' },
    hunter: { n: '그림자 사냥꾼', boss: 1, hp: 800, atk: 28, def: 18, rng: 5, spd: 1.7, as: 1.1, ai: 'r', loot: 320, dis: 0.6, sk: ['b_stake', 'haste'], col: ['#1a1a1a', '#2a2a30', '#c0c0c0', '#f0dcd0'], d: '은 말뚝으로 마물을 노리는 사냥꾼. 함정을 잘 피해요.' },
    archsage: { n: '대현자', boss: 1, hp: 750, atk: 32, def: 14, rng: 5, spd: 1.5, as: 1.4, ai: 'r', loot: 340, sk: ['b_meteor', 'h_cleanse'], col: ['#d8d8e8', '#2a3a6a', '#f0e070', '#f6e6dc'], d: '유성을 떨어뜨리고, 함정 마법을 꿰뚫어 봐요.' },
    inquisitor: { n: '불굴의 이단심문관', boss: 1, hp: 1150, atk: 32, def: 30, rng: 1.2, spd: 1.4, as: 1.1, ai: 'm', loot: 380, sk: ['b_flame', 'guard'], col: ['#d0d0d8', '#e8e8f0', '#e04020', '#f0dcd0'], d: '마물을 증오하는 심문관. 불꽃 대검.' },
    saint: { n: '순례 성녀', boss: 1, hp: 900, atk: 18, def: 20, rng: 3.5, spd: 1.4, as: 1.3, ai: 'h', loot: 400, sk: ['b_miracle', 'h_shield'], col: ['#f8f0d0', '#f8f8f8', '#f0d060', '#f8ece4'], d: '기적으로 동료를 살려요. 마왕을 구원하려 해요.' },
    holysword: { n: '성검의 용사', boss: 1, hp: 1500, atk: 40, def: 34, rng: 1.3, spd: 1.6, as: 0.9, ai: 'm', loot: 600, sk: ['b_holy', 'h_lance', 'guard'], col: ['#f0d060', '#f0f0f8', '#60a0ff', '#f8e8dc'], d: '마왕을 쓰러뜨릴 운명을 진 소녀. 성검이 빛나요.' },
    wolf: { n: '조련된 늑대', summon: 1, hp: 140, atk: 14, def: 8, rng: 1.1, spd: 2.2, as: 0.8, ai: 'm', loot: 10, sk: ['bite'], col: ['#7a7a80', '#6a6a70', '#c0c0c8', '#9a9aa0'], d: '조련사가 데려오는 늑대.' },
  };
  const HCLS = ['rookie', 'thief', 'nun', 'elemental', 'elfarcher', 'paladin', 'assassin', 'explorer', 'royalknight', 'monk', 'alchemist', 'bard'];
  const HUNLOCK = { rookie: 0, thief: 0, nun: 0, elfarcher: 1, elemental: 2, explorer: 2, monk: 3, paladin: 4, royalknight: 5, alchemist: 6, assassin: 7, bard: 8 };
  const GOALS = { k: '마왕 처치', l: '보물 약탈', r: '포로 구출', s: '정찰' };

  /* ================= 주인 타입 · 주인 스킬 ================= */
  const MTYPE = {
    mag: { n: '마술', ic: '🔮', d: '주인 스킬 위력 +25%, 마력 한도 +40, 침입 중 마력 회복 +30%.' },
    war: { n: '전투', ic: '⚔', d: '마왕이 직접 싸워요: 체력 +30%, 공격 ×2. 마물 공격 +8%.' },
    cha: { n: '매혹', ic: '💋', d: '포로 설득 +25%p, 고용비 -20%, 친밀도 상승 ×1.5, 기분 +1/일.' },
    tec: { n: '기술', ic: '⚙', d: '함정 값 -20%, 함정 피해 +15%, 작업력 +5.' },
  };
  // ty: all/mag/war/cha/tec, mp 마력, cd 초, rq 연구, r 반경
  const MSK = [
    { k: 'heal', ty: 'all', n: '치유의 비', ic: '✚', mp: 30, cd: 12, rq: 0, r: 2.5, d: '반경 2.5칸 마물 체력 40% 회복.' },
    { k: 'fear', ty: 'all', n: '공포의 그림자', ic: '👁', mp: 30, cd: 15, rq: 0, r: 2, d: '반경 2칸 용사가 4초 달아나요.' },
    { k: 'bolt', ty: 'mag', n: '낙뢰', ic: '⚡', mp: 25, cd: 6, rq: 0, r: 1.2, d: '피해 70(젖은 적 ×2).' },
    { k: 'wall', ty: 'mag', n: '마력 장벽', ic: '🧱', mp: 30, cd: 15, rq: 20, r: 0, d: '그 칸을 12초 막아요(용사가 못 지나감).' },
    { k: 'storm', ty: 'mag', n: '화염 폭풍', ic: '🔥', mp: 45, cd: 14, rq: 45, r: 2, d: '피해 45 + 화상, 반경 2칸.' },
    { k: 'stop', ty: 'mag', n: '시간 정지', ic: '⏳', mp: 80, cd: 40, rq: 120, r: 0, d: '모든 용사 3.5초 정지.' },
    { k: 'descend', ty: 'war', n: '마왕 강림', ic: '👑', mp: 40, cd: 20, rq: 0, r: 1.6, d: '마왕이 그 칸으로 내려와 휩쓸어요(피해 60). 10초 뒤 옥좌로.' },
    { k: 'rally', ty: 'war', n: '집결 명령', ic: '🚩', mp: 15, cd: 8, rq: 0, r: 0, d: '모든 마물이 8초 동안 그 칸으로 빠르게 달려가요.' },
    { k: 'cry', ty: 'war', n: '전장의 함성', ic: '📯', mp: 35, cd: 25, rq: 20, r: 0, d: '모든 마물 공격 +40%(10초).' },
    { k: 'blades', ty: 'war', n: '칼날 폭풍', ic: '🗡', mp: 55, cd: 18, rq: 80, r: 2, d: '반경 2칸 피해 55 × 3번.' },
    { k: 'charm', ty: 'cha', n: '매혹의 시선', ic: '💗', mp: 40, cd: 18, rq: 0, r: 1, d: '용사 하나가 10초 우리 편이 돼요.' },
    { k: 'dream', ty: 'cha', n: '꿈결', ic: '💤', mp: 35, cd: 16, rq: 20, r: 1.8, d: '반경 1.8칸 4초 잠재움.' },
    { k: 'kiss', ty: 'cha', n: '입맞춤 낙인', ic: '💋', mp: 25, cd: 10, rq: 45, r: 1, d: '용사 하나 10초 받는 피해 ×1.5, 방어 -50%.' },
    { k: 'stage', ty: 'cha', n: '홀림의 무대', ic: '🎭', mp: 70, cd: 40, rq: 120, r: 0, d: '모든 용사 4초 혼란.' },
    { k: 'reload', ty: 'tec', n: '함정 재장전', ic: '🔧', mp: 30, cd: 20, rq: 0, r: 0, d: '모든 함정이 바로 다시 작동.' },
    { k: 'over', ty: 'tec', n: '과부하', ic: '⚙', mp: 40, cd: 25, rq: 20, r: 0, d: '10초 동안 함정 피해 ×2.' },
    { k: 'golem', ty: 'tec', n: '골렘 소환', ic: '🗿', mp: 45, cd: 25, rq: 45, r: 0, d: '그 칸에 돌 골렘(25초).' },
    { k: 'mine', ty: 'tec', n: '즉석 지뢰', ic: '💣', mp: 30, cd: 12, rq: 80, r: 0, d: '그 칸에 폭발 룬을 깔아요(이번 밤만).' },
  ];
  const MS = {}; MSK.forEach((m) => (MS[m.k] = m));

  /* ================= 캠페인 장 ================= */
  const CHAPTERS = [
    { t: '첫 번째 침입', sub: '조용하던 던전에 횃불이 들어온다', boss: ['tamer'] },
    { t: '그림자의 추적', sub: '함정을 읽는 눈이 다가온다', boss: ['hunter'] },
    { t: '별의 서고', sub: '마법을 꿰뚫어 보는 현자', boss: ['archsage'] },
    { t: '불꽃의 심판', sub: '이단을 태우는 대검', boss: ['inquisitor'] },
    { t: '칭호들의 연합', sub: '사냥꾼과 현자가 손을 잡다', boss: ['hunter', 'archsage'] },
    { t: '순례의 성녀', sub: '구원이라는 이름의 침략', boss: ['saint'] },
    { t: '성검', sub: '운명의 소녀가 문을 연다', boss: ['holysword'] },
  ];
  const CH_SET = { 5: [0, 1, 3, 5, 6], 6: [0, 1, 2, 3, 5, 6], 7: [0, 1, 2, 3, 4, 5, 6] };
  const NIGHTS_PER_CH = 3;

  /* ================= 지도 만들기 ================= */
  const MAPS = { cave: '천연 동굴', rich: '금맥 지대', lake: '지하 호수', hard: '단단한 암반', plain: '보통 암반' };
  function genMap(style) {
    const m = new Array(N).fill('#');
    const blob = (x0, y0, rad, ch, prob) => { for (let y = y0 - rad; y <= y0 + rad; y++) for (let x = x0 - rad; x <= x0 + rad; x++) if (x > 0 && y > 0 && x < W - 1 && y < H - 1 && (x - x0) ** 2 + (y - y0) ** 2 <= rad * rad + 0.5 && Math.random() < (prob || 1)) m[idx(x, y)] = ch; };
    const nh = style === 'hard' ? 10 : 4;
    for (let k = 0; k < nh; k++) blob(2 + rnd(W - 4), 2 + rnd(H - 4), 1 + rnd(2), 'X', 0.85);
    const pg = style === 'rich' ? 0.075 : 0.032, pc = style === 'rich' ? 0.025 : 0.016;
    for (let i = 0; i < N; i++) if (m[i] === '#') { const r = Math.random(); if (r < pg) m[i] = '$'; else if (r < pg + pc) m[i] = '*'; }
    if (style === 'cave') for (let k = 0; k < 6; k++) blob(3 + rnd(W - 6), 3 + rnd(H - 6), 1 + rnd(2), '.', 0.8);
    if (style === 'lake') for (let k = 0; k < 3; k++) blob(4 + rnd(W - 8), 4 + rnd(H - 8), 1 + rnd(2), '~', 0.95);
    else blob(4 + rnd(W - 8), 4 + rnd(H - 8), 1, '~', 0.7);
    for (let x = 0; x < W; x++) { m[idx(x, 0)] = 'X'; m[idx(x, H - 1)] = 'X'; }
    for (let y = 0; y < H; y++) { m[idx(0, y)] = 'X'; m[idx(W - 1, y)] = 'X'; }
    const ex = 4 + rnd(W - 8), hx = 5 + rnd(W - 10), hy = H - 3;
    const E = idx(ex, 1), Hc = idx(hx, hy);
    let x = ex, y = 2;
    const carve = (xx, yy) => { if (xx > 0 && yy > 0 && xx < W - 1 && yy < H - 1) { const i = idx(xx, yy); if (m[i] !== '~') m[i] = '.'; } };
    carve(x, 2);
    let guard = 0;
    while ((x !== hx || y !== hy) && guard++ < 400) {
      const r = Math.random();
      if (r < 0.22 && y < hy - 1) { const dx = Math.random() < 0.5 ? -1 : 1; const k2 = 2 + rnd(4); for (let k = 0; k < k2; k++) { const nx = x + dx; if (nx < 2 || nx > W - 3) break; x = nx; carve(x, y); } }
      else if (y < hy && (Math.random() < 0.6 || x === hx)) { y++; carve(x, y); }
      else if (x !== hx) { x += x < hx ? 1 : -1; carve(x, y); }
      else { y++; carve(x, y); }
    }
    for (let yy = hy - 1; yy <= hy + 1; yy++) for (let xx = hx - 1; xx <= hx + 1; xx++) carve(xx, yy);
    m[E] = 'E'; m[Hc] = 'H';
    const r = new Array(N).fill('-');
    [idx(hx - 1, hy), idx(hx + 1, hy), idx(hx - 1, hy + 1), idx(hx + 1, hy + 1)].forEach((i) => { if (m[i] === '.') r[i] = 'k'; });
    const side = [];
    for (let i = 0; i < N; i++) if (m[i] === '#' && cy(i) > 3 && cy(i) < H - 1 && NB4[i].some((j) => m[j] === '.') && cx(i) > 1 && cx(i) < W - 2) side.push(i);
    U.shuffle(side);
    const want = ['c', 'c', 'c', 'a', 'd'];
    for (const i of side) { if (!want.length) break; if (Math.abs(cx(i) - hx) + Math.abs(cy(i) - hy) > 9) continue; m[i] = '.'; r[i] = want.shift(); }
    return { m: m.join(''), r: r.join(''), E, Hc };
  }

  /* ================= 상태 ================= */
  const AFF_TH = [25, 55, 85];
  /* 간부 제안(낮에 가끔): 받아들이면 정해진 만큼만 효과 + 그 간부 친밀도 +5. 거절은 손해 없음. */
  const PROP = {
    drill: { n: '합동 훈련', ic: '⚔', g: 60, d: '금화 60 → 모든 마물 경험 +6', f: (s) => s.ro.forEach((e) => (e.xp += 6)) },
    guard: { n: '경비 재배치', ic: '🛡', g: 0, d: '전위 마물을 용사 길 앞쪽에, 후위·지원을 그 뒤에 세워요', f: (s) => autoPost(s) },
    rest: { n: '휴식 명령', ic: '♨', g: 0, d: '모든 마물 체력 +25%, 기분 +3', f: (s) => s.ro.forEach((e) => { e.hp = Math.min(1, e.hp + 0.25); e.md = Math.min(100, e.md + 3); }) },
    lab: { n: '연구 지원', ic: '⚗', g: 70, d: '금화 70 → 연구 +6', f: (s) => (s.res += 6) },
    crystal: { n: '마력 결정 구입', ic: '🔮', g: 80, d: '금화 80 → 마력 +40', f: (s) => (s.mana = Math.min(manaCap(s), s.mana + 40)) },
    shaft: { n: '갱도 보강', ic: '⛏', g: 40, d: '금화 40 → 오늘 작업력 +6', f: (s) => (s.lab += 6) },
    tax: { n: '통행세 징수', ic: '💰', g: 0, d: '금화 +70, 명성 -1', f: (s) => { s.gold = Math.min(goldCap(s), s.gold + 70); s.fame = Math.max(0, s.fame - 1); } },
    feast: { n: '작은 연회', ic: '🍷', g: 50, d: '금화 50 → 모든 마물 기분 +8', f: (s) => s.ro.forEach((e) => (e.md = Math.min(100, e.md + 8))) },
    hunt: { n: '지상 사냥', ic: '🐺', g: 0, d: '금화 +40, 모든 마물 경험 +2', f: (s) => { s.gold = Math.min(goldCap(s), s.gold + 40); s.ro.forEach((e) => (e.xp += 2)); } },
  };
  const PROP_OF = { dragonknight: ['drill', 'guard', 'rest'], abysswitch: ['lab', 'crystal', 'shaft'], nightduchess: ['tax', 'feast', 'crystal'], beastqueen: ['hunt', 'drill', 'guard'] };
  // 제안 대사(자료). AI 서술이 켜져 있으면 이 줄을 바탕으로 그 인물 말투로 다시 씀
  const PROP_LINE = {
    dragonknight: { drill: '폐하, 오늘 오후에 합동 훈련을 열고 싶습니다. 금화 예순이면 됩니다. ……허락해 주시겠습니까.', guard: '폐하, 배치를 다시 짜 보았습니다. 방패는 앞으로, 활은 뒤로. 제 손으로 옮겨도 되겠습니까.', rest: '폐하, 다들 지쳐 있습니다. 오늘 하루 쉬게 해 주시면 밤에 두 배로 갚겠습니다.' },
    abysswitch: { lab: '폐하, 연구비를 조금만 더 주시면 좋겠거든요. 일흔이면 돼요. 이번엔 안 터져요. 아마도요.', crystal: '어머, 지상 상인이 마력 결정을 싸게 내놨대요. 여든에 한 자루. 놓치면 아깝잖아요.', shaft: '갱도 버팀목을 마법으로 굳히면 오늘 더 팔 수 있거든요. 금화 마흔이면 충분해요.' },
    nightduchess: { tax: '폐하, 던전 앞 길에 통행세를 걷지요. 금화는 늘지만 평판은 조금 깎입니다. 결정은 폐하께.', feast: '장부를 보니 다들 기운이 빠져 있습니다. 쉰 닢으로 조촐한 연회를 열지요. 사기도 이자가 붙습니다.', crystal: '마력 결정 시세가 바닥입니다. 여든 닢에 한 자루. 지금 사 두시지요.' },
    beastqueen: { hunt: '폐하, 애들 데리고 지상에 잠깐 사냥 다녀올게. 잡은 건 금화로 바꿔 오지. 허락만 해.', drill: '애들 이빨이 무뎌졌어. 금화 예순만 줘. 오늘 오후에 제대로 굴려 줄게.', guard: '배치가 영 냄새가 별로야. 싸울 놈은 앞에, 쏘는 놈은 뒤에. 내가 다시 세워도 되지?' },
  };
  const PROP_OK = { dragonknight: '|smile|감사합니다, 폐하. 실망시키지 않겠습니다.', abysswitch: '|happy|역시 폐하는 보는 눈이 있다니까요.', nightduchess: '|smile|현명한 결정이십니다. 장부에 적어 두지요.', beastqueen: '|happy|하하, 그럴 줄 알았어. 맡겨.' };
  const PROP_NO = { dragonknight: '|serious|……알겠습니다. 다음 기회를 기다리겠습니다.', abysswitch: '|sad|어머, 아쉬워라. 다음엔 더 그럴듯하게 조를게요.', nightduchess: '|neutral|그러시지요. 오늘은 아끼는 쪽으로.', beastqueen: '|neutral|뭐, 좋아. 대신 밤엔 실컷 물게 해 줘.' };
  function init(players, opts) {
    opts = opts || {};
    let style = opts.map || 'rnd'; if (style === 'rnd') style = pick(Object.keys(MAPS));
    const mode = opts.mode || 'camp';
    const len = +(opts.len || 6);
    const g = genMap(style);
    return {
      v: 2, n: players.length, lv: players.map((p) => (p.ai ? (p.lv || 2) : 0)), mode, len, sty: style, chs: CH_SET[len] || CH_SET[6],
      ch: 0, nd: 0, night: 0, ph: 'pick', m: g.m, r: g.r, t: '-'.repeat(N), E: g.E, Hc: g.Hc,
      mt: null, pk: players.map(() => ''), gold: 600, mana: 60, fame: 0, res: 0, hp: 600, mhp: 600, lab: 0, talk: 0,
      ro: [], nid: 1, vis: [], pr: [], mem: [], rd: players.map(() => 0), ev: [], evn: 0, log: [], rep: null, R: null, win: null,
      st: { kills: 0, caps: 0, conv: 0, aw: 0, bosses: 0, gold: 0 }, seq: 0,
    };
  }
  const evPush = (s, e) => { e.i = ++s.evn; e.d = s.night; s.ev.push(e); if (s.ev.length > 24) s.ev.splice(0, s.ev.length - 24); };
  const logPush = (s, t) => { s.log.push(t); if (s.log.length > 14) s.log.shift(); };
  const cnt = (str, ch) => { let k = 0; for (let i = 0; i < str.length; i++) if (str[i] === ch) k++; return k; };
  const zoneOf = (s, i) => (s.n <= 1 ? 0 : Math.min(s.n - 1, Math.floor(cx(i) * s.n / W)));
  const isBossNight = (s) => (s.mode === 'camp' ? s.nd === NIGHTS_PER_CH - 1 : s.night % 5 === 4);
  const chDef = (s) => CHAPTERS[s.chs[Math.min(s.ch, s.chs.length - 1)]];
  const isExec = (k) => !!(MON[k] && MON[k].ex);
  const nonExec = (s) => s.ro.filter((e) => !isExec(e.k)).length;
  const cap = (s) => Math.min(24, 2 + cnt(s.r, 'c'));
  const prisonCap = (s) => cnt(s.r, 'h');
  function adjFrac(s, k) {
    const R = RM[k]; let a = 0, b = 0;
    for (let i = 0; i < N; i++) if (s.r[i] === k) { b++; if (NB4[i].some((j) => s.r[j] === R.adj)) a++; }
    return b ? a / b : 0;
  }
  const roomPow = (s, k) => cnt(s.r, k) * (1 + 0.25 * adjFrac(s, k));
  const goldCap = (s) => Math.round(500 + 300 * roomPow(s, 'a'));
  const manaCap = (s) => Math.round(100 + 15 * roomPow(s, 'b') + 30 * roomPow(s, 'l') + (s.mt === 'mag' ? 40 : 0));
  const trapCost = (s, k) => Math.round(TP[k].c * (s.mt === 'tec' ? 0.8 : 1) * (1 - Math.min(0.2, 0.02 * cnt(s.r, 'f'))));
  const hireCost = (s, k) => Math.round(MON[k].cost * (s.mt === 'cha' ? 0.8 : 1));
  const laborMax = (s) => 10 + (s.mt === 'tec' ? 5 : 0) + s.ro.reduce((a, e) => a + (MON[e.k] ? MON[e.k].lab : 0) + (e.k === 'slime' || e.k === 'imp' ? 2 : 0), 0);
  const talkMax = (s) => 3 + Math.floor(cnt(s.r, 'p') / 2) + (s.n > 1 ? s.n - 1 : 0);
  const unitName = (k) => (MON[k] ? MON[k].n : HERO[k] ? HERO[k].n : k === 'master' ? '마왕' : k);
  const scaleN = (s) => 1 + 0.12 * s.night + Math.max(0, s.night - 15) * 0.2 + (s.n - 1) * 0.1;
  const xpNeed = (lv) => 14 + lv * 10;

  function addRoster(s, k, opt) {
    const e = { i: s.nid++, k, d0: s.night, lv: 1, xp: 0, hp: 1, af: isExec(k) ? 30 : 10, md: 70, aw: 0, p: -1, ev: 0 };
    if (opt && opt.h) { e.h = 1; e.af = 5; e.md = 55; e.lv = 1 + Math.floor(s.night / 3); }
    if (isExec(k)) e.lv = 3;
    s.ro.push(e); return e;
  }
  function refreshVisitors(s) {
    const owned = new Set(s.ro.map((e) => e.k));
    const pool = ALLY.map((a) => a[0]).filter((k) => !owned.has(k));
    const w = pool.map((k) => { const M = MON[k]; let v = 1; if (cnt(s.r, M.like)) v += 1.5; if (M.cost > 140 && s.fame < 12) v *= 0.35; if (M.cost < 100 && s.fame > 40) v *= 0.6; return v; });
    const out = [];
    for (let t = 0; t < 3 && pool.length; t++) {
      const sum = w.reduce((a, b) => a + b, 0); let r = Math.random() * sum, j = 0;
      while (j < pool.length - 1 && (r -= w[j]) > 0) j++;
      out.push(pool[j]); pool.splice(j, 1); w.splice(j, 1);
    }
    s.vis = out;
  }

  /* 고르기 → 첫 낮 */
  function finishPick(s) {
    if (!s.mt) s.mt = pick(Object.keys(MTYPE));
    const used = new Set(s.pk.filter(Boolean));
    s.pk = s.pk.map((p) => { if (p) return p; const left = EXEC.map((e) => e[0]).filter((k) => !used.has(k)); const k = pick(left); used.add(k); return k; });
    s.pk.forEach((k) => addRoster(s, k));
    addRoster(s, 'slime'); addRoster(s, 'imp');
    s.ro.forEach((e) => (e.p = defaultPost(s)));
    if (s.mt === 'war') { s.mhp = 780; s.hp = 780; }
    if (s.mt === 'mag') s.mana = 100;
    if (s.mode === 'camp') { evPush(s, { k: 'story', id: 'prologue' }); evPush(s, { k: 'story', id: 'c' + s.chs[0] + '_in' }); }
    else evPush(s, { k: 'story', id: 'endless_in' });
    startDay(s);
  }
  function defaultPost(s) {
    const p = mainPath(s); if (!p.length) return s.Hc;
    return p[Math.min(p.length - 1, Math.floor(p.length * (0.45 + Math.random() * 0.5)))];
  }
  function autoPost(s) {
    const path = mainPath(s), L2 = path.length; if (L2 < 3) return;
    s.ro.forEach((e, j) => {
      const M = MON[e.k] || HERO[e.k]; const rk = M.rk || (HERO[e.k] && HERO[e.k].ai === 'h' ? 's' : 'f');
      const f = rk === 'f' ? 0.55 + (j % 3) * 0.08 : rk === 'b' || rk === 'm' ? 0.72 + (j % 3) * 0.06 : 0.8;
      const c = path[Math.min(L2 - 1, Math.floor(L2 * f))]; if (c != null) e.p = c;
    });
  }
  function startDay(s) {
    s.ph = 'day'; s.rd = s.rd.map(() => 0);
    s.np = genParty(s); // 정찰 보고: 오늘 밤 올 파티(밤에 그대로 들어옴)
    s.prop = null;
    const ex = s.ro.filter((e) => isExec(e.k) && PROP_OF[e.k]);
    if (s.night > 0 && ex.length && Math.random() < 0.4) { const e = pick(ex); const id = pick(PROP_OF[e.k]); s.prop = { c: e.k, u: e.i, id }; evPush(s, { k: 'prop', c: e.k, id }); }
    s.lab = laborMax(s); s.talk = talkMax(s);
    if (!s.vis.length) refreshVisitors(s);
    s.pr.forEach((p) => (p.t = 0));
    s.ro.forEach((e) => { delete e.tk; delete e.gf; });
  }

  /* ================= 길 찾기 ================= */
  const FC = new Map();
  function cacheGet(key, fn) { let v = FC.get(key); if (!v) { v = fn(); FC.set(key, v); if (FC.size > 700) FC.delete(FC.keys().next().value); } return v; }
  function bfsFrom(m, src) {
    return cacheGet('b' + src + m, () => {
      const d = new Int16Array(N).fill(9999); const q = [src]; d[src] = 0;
      for (let h = 0; h < q.length; h++) { const c = q[h]; for (const j of NB4[c]) if (d[j] === 9999 && walkT(m[j])) { d[j] = d[c] + 1; q.push(j); } }
      return d;
    });
  }
  function goalCells(s, g) {
    if (g === 'k') return [s.Hc];
    if (g === 'x') return [s.E];
    const dE = bfsFrom(s.m, s.E);
    if (g === 'l' || g === 'r') { const k = g === 'l' ? 'a' : 'h'; const a = []; for (let i = 0; i < N; i++) if (s.r[i] === k && dE[i] < 9999) a.push(i); return a; }
    if (g === 's') { const a = []; for (let i = 0; i < N; i++) if (dE[i] < 9999 && s.r[i] !== '-') a.push(i); a.sort((p, q) => dE[q] - dE[p]); return a.slice(0, 3); }
    return [s.Hc];
  }
  function goalField(s, g) {
    const memK = s.mem.join(',');
    return cacheGet('g' + g + memK + s.m + s.r, () => {
      const d = new Float32Array(N).fill(1e9); const srcs = goalCells(s, g);
      if (!srcs.length) srcs.push(s.Hc);
      const mem = new Set(s.mem); const open = [];
      srcs.forEach((i) => { d[i] = 0; open.push(i); });
      const done = new Uint8Array(N);
      while (open.length) {
        let bi = 0; for (let k = 1; k < open.length; k++) if (d[open[k]] < d[open[bi]]) bi = k;
        const c = open[bi]; open[bi] = open[open.length - 1]; open.pop(); if (done[c]) continue; done[c] = 1;
        for (const j of NB4[c]) { if (!walkT(s.m[j])) continue; const w = (s.m[j] === '~' ? 1.7 : 1) + (mem.has(j) ? 6 : 0); if (d[c] + w < d[j]) { d[j] = d[c] + w; open.push(j); } }
      }
      return d;
    });
  }
  function mainPath(s) {
    const d = bfsFrom(s.m, s.Hc); const out = []; let c = s.E; if (d[c] >= 9999) return out;
    let g = 0; while (c !== s.Hc && g++ < 400) { let b = -1; for (const j of NB4[c]) if (d[j] < d[c] && (b < 0 || d[j] < d[b])) b = j; if (b < 0) break; c = b; if (c !== s.Hc) out.push(c); }
    return out;
  }

  /* ================= 낮 행동 ================= */
  const canZone = (s, seat, i) => s.n <= 1 || zoneOf(s, i) === seat;
  function doOp(s, seat, a) {
    if (!a || typeof a !== 'object') return '잘못된 명령';
    const t = a.t, c = a.c | 0, inb = c >= 0 && c < N;
    if (t === 'dig') {
      if (!inb) return '판 밖'; const ch = s.m[c];
      if (!canZone(s, seat, c)) return '내 구역이 아니에요';
      if (ch === 'X') return '너무 단단한 암반이에요';
      if (!rockT(ch)) return '팔 바위가 아니에요';
      if (!NB4[c].some((j) => walkT(s.m[j]))) return '파 놓은 곳 옆만 팔 수 있어요';
      const cost = ch === '#' ? 1 : 2; if (s.lab < cost) return '오늘 작업력이 모자라요';
      s.lab -= cost; s.m = setc(s.m, c, '.');
      if (ch === '$') s.gold = Math.min(goldCap(s), s.gold + 50);
      if (ch === '*') s.mana = Math.min(manaCap(s), s.mana + 20);
      return '';
    }
    if (t === 'room') {
      if (!inb) return '판 밖'; const R = RM[a.k]; if (!R) return '?';
      if (!canZone(s, seat, c)) return '내 구역이 아니에요';
      if (s.m[c] !== '.') return '파 놓은 바닥에만 지어요';
      if (s.t[c] !== '-') return '함정이 있는 칸이에요';
      if (s.r[c] === a.k) return '이미 그 방이에요';
      if (s.gold < R.c) return '금화가 모자라요';
      if (s.r[c] === 'c' && nonExec(s) > cap(s) - 1) return '마물이 지내는 숙소예요';
      if (s.r[c] === 'h' && s.pr.length > prisonCap(s) - 1) return '포로가 갇힌 감옥이에요';
      s.gold -= R.c; s.r = setc(s.r, c, a.k); return '';
    }
    if (t === 'trap') {
      if (!inb) return '판 밖'; const T = TP[a.k]; if (!T) return '?';
      if (!canZone(s, seat, c)) return '내 구역이 아니에요';
      if (s.m[c] !== '.') return '파 놓은 바닥에만 놓아요';
      if (s.r[c] !== '-') return '방 안에는 함정을 못 놓아요';
      if (s.t[c] !== '-') return '이미 함정이 있어요';
      if (s.res < T.rq) return '연구 ' + T.rq + '이 필요해요';
      const k = trapCost(s, a.k); if (s.gold < k) return '금화가 모자라요';
      s.gold -= k; s.t = setc(s.t, c, a.k); return '';
    }
    if (t === 'sell') {
      if (!inb) return '판 밖';
      if (!canZone(s, seat, c)) return '내 구역이 아니에요';
      if (s.t[c] !== '-') { s.gold += Math.floor(trapCost(s, s.t[c]) / 2); s.t = setc(s.t, c, '-'); return ''; }
      const rk = s.r[c];
      if (rk !== '-') {
        if (rk === 'c' && nonExec(s) > cap(s) - 1) return '마물이 지내는 숙소예요';
        if (rk === 'h' && s.pr.length > prisonCap(s) - 1) return '포로가 갇힌 감옥이에요';
        s.gold += Math.floor(RM[rk].c / 2); s.r = setc(s.r, c, '-'); return '';
      }
      return '허물 것이 없어요';
    }
    if (t === 'hire') {
      const k = s.vis[a.v | 0]; if (!k) return '이미 떠났어요';
      if (nonExec(s) >= cap(s)) return '숙소가 모자라요(숙소 1칸 = 1명)';
      const cst = hireCost(s, k); if (s.gold < cst) return '금화가 모자라요';
      s.gold -= cst; const e = addRoster(s, k); e.p = defaultPost(s); s.vis.splice(a.v | 0, 1);
      evPush(s, { k: 'hire', c: k, u: e.i }); return '';
    }
    if (t === 'prop') {
      const P = s.prop; if (!P) return '제안이 없어요'; const D = PROP[P.id];
      if (a.ok) { if (s.gold < D.g) return '금화가 모자라요'; s.gold -= D.g; D.f(s); const ee = s.ro.find((x) => x.i === P.u); if (ee) { affGain(s, ee, 5); checkAff(s, ee); } logPush(s, nameOf(P.c) + '의 제안 「' + D.n + '」을 받아들였어요'); }
      s.prop = null; evPush(s, { k: 'propr', c: P.c, ok: a.ok ? 1 : 0 }); return '';
    }
    const e = a.u != null ? s.ro.find((x) => x.i === a.u) : null;
    if (t === 'fire') { if (!e) return '?'; if (isExec(e.k)) return '간부는 내보낼 수 없어요'; s.ro.splice(s.ro.indexOf(e), 1); logPush(s, unitName(e.k) + '을(를) 내보냈어요'); return ''; }
    if (t === 'post') { if (!e) return '?'; if (!inb || !walkT(s.m[c])) return '걸을 수 있는 칸이어야 해요'; e.p = c; return ''; }
    if (t === 'talk') {
      if (!e) return '?'; if (s.talk <= 0) return '오늘 대화는 다 했어요'; if (e.tk) return '오늘은 이미 이야기했어요';
      s.talk--; e.tk = 1; affGain(s, e, 6); e.md = Math.min(100, e.md + 4); evPush(s, { k: 'talk', u: e.i, c: e.k, s: seat }); checkAff(s, e); return '';
    }
    if (t === 'gift') {
      if (!e) return '?'; if (s.gold < 40) return '금화가 모자라요'; if (e.gf) return '오늘은 이미 선물했어요';
      s.gold -= 40; e.gf = 1; affGain(s, e, 9); e.md = Math.min(100, e.md + 10); evPush(s, { k: 'gift', u: e.i, c: e.k, s: seat }); checkAff(s, e); return '';
    }
    if (t === 'aw') {
      if (!e) return '?'; if (e.aw) return '이미 각성했어요'; if (e.h) return '용사 출신은 각성하지 않아요';
      if (e.af < 85 || e.lv < 5) return '친밀도 85 · 레벨 5가 필요해요'; if (s.mana < 100) return '마력 100이 필요해요';
      s.mana -= 100; e.aw = 1; s.st.aw++; evPush(s, { k: 'awaken', c: e.k, u: e.i }); return '';
    }
    if (t === 'pers') {
      const p = s.pr[a.p | 0]; if (!p) return '?';
      if (a.how === 'talk') {
        if (HERO[p.k].boss) return '칭호 용사는 설득할 수 없어요';
        if (p.t) return '오늘은 이미 설득했어요'; if (nonExec(s) >= cap(s)) return '숙소가 모자라요';
        p.t = 1; const ch = 0.22 + (s.mt === 'cha' ? 0.25 : 0) + p.d * 0.1 + Math.min(0.15, s.fame / 400);
        if (Math.random() < ch) { s.pr.splice(a.p | 0, 1); const ne = addRoster(s, p.k, { h: 1 }); ne.p = defaultPost(s); s.st.conv++; evPush(s, { k: 'convert', c: p.k, u: ne.i }); }
        else { p.d++; evPush(s, { k: 'persfail', c: p.k }); }
        return '';
      }
      if (a.how === 'ransom') { s.pr.splice(a.p | 0, 1); s.gold = Math.min(goldCap(s), s.gold + 80); s.fame = Math.max(0, s.fame - 1); return ''; }
      if (a.how === 'free') { s.pr.splice(a.p | 0, 1); s.fame += 3; return ''; }
      return '?';
    }
    return '모르는 명령';
  }
  function affGain(s, e, v) { e.af = Math.min(100, e.af + Math.round(v * (s.mt === 'cha' ? 1.5 : 1))); }
  function checkAff(s, e) {
    while (e.ev < 3 && e.af >= AFF_TH[e.ev]) { evPush(s, { k: 'aff', c: e.k, n: e.ev, u: e.i }); e.ev++; }
  }

  /* ================= 밤 침입 (반실시간 시뮬) ================= */
  const DT = 0.1, STEPS = 5; // 'tk' 한 번 = 0.5초
  const BOSS_CYCLE = ['tamer', 'hunter', 'archsage', 'inquisitor', 'saint', 'holysword'];
  const CC = { sn: 1, sp: 1, rt: 1, ch: 1, cf: 1, fr: 1 };
  const NEG = ['sn', 'sp', 'rt', 'cf', 'fr', 'bn', 'ps', 'cs', 'sl', 'mk', 'wet', 'oil'];
  const stU = (v) => (Array.isArray(v) ? v[0] : v || 0);
  const on = (R, u, k) => !!u.st[k] && stU(u.st[k]) > R.t;
  const stV = (R, u, k, d) => (on(R, u, k) && Array.isArray(u.st[k]) ? u.st[k][1] : d);
  const side = (R, u) => (u.s === 1 && on(R, u, 'ch') ? 0 : u.s);
  const cellOf = (u) => idx(Math.max(0, Math.min(W - 1, Math.round(u.x))), Math.max(0, Math.min(H - 1, Math.round(u.y))));
  const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
  function addSt(R, u, k, du, v) {
    if (u.b && CC[k]) du *= 0.45;
    if (u.ms && CC[k]) du *= 0.3;
    if (HERO[u.k] && HERO[u.k].imm === k) return;
    const until = R1(R.t + du);
    const cur = stU(u.st[k]);
    if (v != null) u.st[k] = [Math.max(until, cur), v]; else u.st[k] = Math.max(until, cur);
  }
  const fxp = (R, f) => { if (R.fx.length < 70) R.fx.push(f); };
  const trapScale = (s) => (1 + 0.07 * s.night) * (1 + 0.04 * roomPow(s, 'f')) * (s.mt === 'tec' ? 1.15 : 1) * (s.R && s.R.buf.over > s.R.t ? 2 : 1);
  const msPow = (s) => (1 + 0.04 * roomPow(s, 'k')) * (s.mt === 'mag' ? 1.25 : 1) * (1 + 0.06 * s.night);

  function genParty(s) {
    const L = s.night;
    const size = Math.min(s.mode === 'endless' ? 12 : 9, 2 + Math.floor(L * 0.42) + (s.n - 1));
    const pool = HCLS.filter((k) => HUNLOCK[k] <= L);
    const out = [];
    let boss = [];
    if (isBossNight(s)) boss = s.mode === 'camp' ? chDef(s).boss.slice() : [BOSS_CYCLE[Math.floor(s.night / 5) % BOSS_CYCLE.length]];
    const esc = boss.length ? Math.max(1, size - 1 - boss.length) : size;
    if (esc > 0) out.push(pick(pool.filter((k) => HERO[k].ai === 'm')));
    while (out.length < esc) out.push(pick(pool));
    boss.forEach((b) => { out.push(b); if (b === 'tamer') out.push('wolf', 'wolf'); });
    // 목표
    const w = [['k', 40]];
    if (cnt(s.r, 'a')) w.push(['l', 30]);
    if (s.pr.length) w.push(['r', 30]);
    if (L > 0) w.push(['s', 14]);
    let sum = w.reduce((a, b) => a + b[1], 0), r = Math.random() * sum, goal = 'k';
    for (const [g, v] of w) { if ((r -= v) <= 0) { goal = g; break; } }
    if (boss.length) goal = 'k';
    return { q: out, goal, boss: boss.length > 0 };
  }
  function mkHero(s, R, k) {
    const B = HERO[k], sc = B.boss ? 0.5 + 0.05 * s.night + (s.n - 1) * 0.15 : scaleN(s);
    const u = { i: R.uid++, s: 1, k, x: cx(s.E), y: cy(s.E), hp: Math.round(B.hp * sc), mh: Math.round(B.hp * sc), a: R1(B.atk * (1 + 0.08 * s.night)), d: B.def, r: B.rng, v: B.spd, as: B.as, ac: 0.5,
      sk: B.sk.map((id) => [id, 2 + Math.random() * 3]), st: {}, g: B.ai === 't' && cnt(s.r, 'a') ? 'l' : R.goal, c: 0, tm: 0, lc: -1, seen: [] };
    if (B.boss) u.b = 1;
    if (B.summon) u.sm = 1;
    return u;
  }
  function mkMonUnit(s, R, e) {
    const M = MON[e.k] || HERO[e.k]; if (!M) return null;
    const lvM = 1 + 0.1 * (e.lv - 1), aw = e.aw ? 1.35 : 1;
    let atk = M.atk * lvM * aw * (e.md < 30 ? 0.85 : 1) * (s.mt === 'war' ? 1.08 : 1) * (e.h ? 1 + 0.05 * s.night : 1);
    const post = e.p >= 0 && walkT(s.m[e.p]) && bfsFrom(s.m, s.Hc)[e.p] < 9999 ? e.p : s.Hc;
    let def = M.def + (e.aw ? 10 : 0);
    if (s.r[post] === 'g') { def += 12; atk *= 1 + 0.02 * cnt(s.r, 'g'); }
    const mh = Math.round(M.hp * lvM * aw * (e.h ? 1 + 0.08 * s.night : 1));
    const sk = (e.h ? HERO[e.k].sk.filter((x) => !/^b_/.test(x)) : M.sk.slice());
    if (e.aw && M.aw) sk.push(M.aw);
    return { i: R.uid++, s: 0, k: e.k, ri: e.i, x: cx(post) + (Math.random() - 0.5) * 0.3, y: cy(post) + (Math.random() - 0.5) * 0.3, hp: Math.max(1, Math.round(mh * e.hp)), mh,
      a: R1(atk), d: def, r: M.rng, v: M.spd, as: M.as, ac: 0.3, sk: sk.map((id) => [id, 1 + Math.random() * 3]), st: {}, p: post, lv: e.lv, aw: e.aw ? 1 : 0 };
  }
  function startRaid(s) {
    delete s.un;
    const P = s.np || genParty(s); delete s.np; delete s.prop;
    if ((P.goal === "l" && !cnt(s.r, "a")) || (P.goal === "r" && !s.pr.length)) P.goal = "k";
    const R = { n: 0, t: 0, sp: 1, uid: 1, u: [], q: P.q.map((k, j) => [k, R1(0.6 + j * 1.3)]), tr: {}, off: [], mines: [], gain: 0, stolen: 0, kills: 0, caps: [], esc: 0, fx: [], goal: P.goal, boss: P.boss ? 1 : 0,
      tl: 150, buf: { cry: 0, over: 0 }, wall: {}, mcd: {}, rally: null, ko: [], bossDown: 0, seen: [], lose: 0, end: 0, xp: {}, alt: [], party: P.q.filter((k) => k !== 'wolf') };
    for (let i = 0; i < N; i++) if (s.r[i] === 'o') R.alt.push(i);
    s.R = R;
    const mu = { i: R.uid++, s: 0, k: 'master', ms: 1, x: cx(s.Hc), y: cy(s.Hc), hp: Math.round(s.hp), mh: s.mhp, a: R1(16 * (s.mt === 'war' ? 2 : 1) * (1 + 0.08 * s.night)), d: 34, r: s.mt === 'war' ? 1.8 : 1.5, v: 2, as: 1, ac: 0,
      sk: ({ war: ['cleave'], mag: ['thunder'], cha: ['charm'], tec: ['rearm'] }[s.mt] || ['cleave']).map((id) => [id, 3]), st: {} };
    R.u.push(mu);
    s.ro.forEach((e) => { if (e.hp >= 0.05) { const u = mkMonUnit(s, R, e); if (u) R.u.push(u); } });
    s.ph = 'raid'; s.rd = s.rd.map(() => 0);
    evPush(s, { k: 'raid', g: P.goal, boss: R.boss, party: R.party });
  }

  /* 피해 */
  function hit(s, R, src, tgt, mult, kind) {
    if (!tgt || tgt.hp <= 0) return 0;
    let a = src.a * mult;
    if (on(R, src, 'bf')) a *= 1 + stV(R, src, 'bf', 0);
    if (on(R, src, 'cs')) a *= 0.65;
    if (side(R, src) === 0 && R.buf.cry > R.t) a *= 1.4;
    let def = tgt.d + (on(R, tgt, 'df') ? stV(R, tgt, 'df', 0) : 0);
    if (on(R, tgt, 'mk')) { def *= 0.5; a *= 1.5; }
    if (on(R, tgt, 'cs')) a *= 1.25;
    const dmg = Math.max(1, a * 60 / (60 + Math.max(0, def)));
    tgt.hp -= dmg; tgt.la = src.i;
    if (on(R, tgt, 'sp')) delete tgt.st.sp;
    if (kind != null) fxp(R, ['a', src.i, tgt.i, kind]);
    if (dmg >= 12) fxp(R, ['d', R1(tgt.x), R1(tgt.y), Math.round(dmg), tgt.s]);
    return dmg;
  }
  function rawDmg(s, R, tgt, dmg, srcId) {
    if (!tgt || tgt.hp <= 0) return;
    if (on(R, tgt, 'cs')) dmg *= 1.25;
    if (on(R, tgt, 'mk')) dmg *= 1.5;
    tgt.hp -= dmg; if (srcId) tgt.la = srcId;
    if (on(R, tgt, 'sp')) delete tgt.st.sp;
    if (dmg >= 12) fxp(R, ['d', R1(tgt.x), R1(tgt.y), Math.round(dmg), tgt.s]);
  }
  function fireCombo(s, R, tgt, base) { // 불이 닿을 때
    if (on(R, tgt, 'oil')) {
      delete tgt.st.oil; fxp(R, ['c', '대폭발', R1(tgt.x), R1(tgt.y)]);
      R.u.forEach((o) => { if (side(R, o) === 1 && d2(o, tgt) <= 2.25) rawDmg(s, R, o, 45 * trapScale(s)); });
    }
    if (on(R, tgt, 'ps')) { fxp(R, ['c', '독연 폭발', R1(tgt.x), R1(tgt.y)]); rawDmg(s, R, tgt, 28 * trapScale(s)); }
  }
  const enemies = (R, u) => { const sd = side(R, u); return R.u.filter((o) => o.hp > 0 && side(R, o) !== sd && !(o.ms && o.hide)); };
  const allies = (R, u) => { const sd = side(R, u); return R.u.filter((o) => o.hp > 0 && side(R, o) === sd); };
  function nearest(list, u, maxR) { let b = null, bd = maxR * maxR; for (const o of list) { const d = d2(o, u); if (d <= bd) { bd = d; b = o; } } return b; }

  /* 스킬 */
  function tryCast(s, R, u, sk) {
    const S = SK[sk]; if (!S) return false;
    const en = enemies(R, u);
    if (S.t === 'single') {
      let tg = null;
      if (u.s === 1 && on(R, u, 'tt')) tg = R.u.find((o) => o.i === stV(R, u, 'tt', 0) && o.hp > 0 && d2(o, u) <= S.rg * S.rg);
      if (!tg) tg = nearest(en, u, S.rg); if (!tg) return false;
      if ((S.st === 'ch' || S.st === 'cf') && (tg.b || tg.ms)) return false;
      if (S.dash && d2(tg, u) > 1.5) { const dx = tg.x - u.x, dy = tg.y - u.y, l = Math.sqrt(dx * dx + dy * dy); u.x = R2(tg.x - dx / l * 0.8); u.y = R2(tg.y - dy / l * 0.8); }
      let m = S.dm || 0; if (S.wet && on(R, tg, 'wet')) m *= S.wet;
      if (m) { const dd = hit(s, R, u, tg, m, 2); if (S.ls) u.hp = Math.min(u.mh, u.hp + dd * S.ls); }
      if (S.st) addSt(R, tg, S.st, S.du, S.st === 'sl' ? 0.6 : S.st === 'tt' ? u.i : null);
      if (S.fire) fireCombo(s, R, tg);
      fxp(R, ['s', u.i, sk, tg.i]); return true;
    }
    if (S.t === 'aoe') {
      let c = u;
      if (S.rg > 0) { c = nearest(en, u, S.rg); if (!c) return false; }
      const hits = en.filter((o) => d2(o, c) <= S.r * S.r);
      if (!hits.length) return false;
      if (S.rg === 0 && S.st === 'tt' && hits.length < 1) return false;
      hits.forEach((o) => {
        if (S.dm) { const dd = hit(s, R, u, o, S.dm, null); if (S.ls) u.hp = Math.min(u.mh, u.hp + dd * S.ls); }
        if (S.wetS) addSt(R, o, 'wet', 6);
        if (S.st && !((S.st === 'ch' || S.st === 'cf') && (o.b || o.ms))) addSt(R, o, S.st, S.du, S.st === 'sl' ? 0.6 : S.st === 'tt' ? u.i : null);
        if (S.fire) fireCombo(s, R, o);
      });
      fxp(R, ['s', u.i, sk, -1, R1(c.x), R1(c.y), S.r]); return true;
    }
    if (S.t === 'self') {
      if (!nearest(en, u, 4)) return false;
      addSt(R, u, S.st, S.du, S.v != null ? S.v : null);
      if (S.tt) en.forEach((o) => { if (d2(o, u) <= 9) addSt(R, o, 'tt', 3, u.i); });
      fxp(R, ['s', u.i, sk, u.i]); return true;
    }
    if (S.t === 'ally') {
      let b = null, br = 0.7;
      for (const o of allies(R, u)) if (d2(o, u) <= S.rg * S.rg && o.hp / o.mh < br) { br = o.hp / o.mh; b = o; }
      if (!b) return false;
      b.hp = Math.min(b.mh, b.hp + b.mh * S.hl); fxp(R, ['s', u.i, sk, b.i]); return true;
    }
    if (S.t === 'allies') {
      const al = allies(R, u).filter((o) => d2(o, u) <= S.r * S.r);
      const hurt = al.some((o) => o.hp / o.mh < 0.85);
      const fight = !!nearest(en, u, 5);
      if (S.hl && !S.st && !hurt && !S.cl) return false;
      if (S.cl && !al.some((o) => NEG.some((k) => on(R, o, k)))) return false;
      if (S.st && !fight) return false;
      al.forEach((o) => {
        if (S.hl) o.hp = Math.min(o.mh, o.hp + o.mh * S.hl);
        if (S.st) addSt(R, o, S.st, S.du, S.v);
        if (S.cl) NEG.forEach((k) => delete o.st[k]);
      });
      fxp(R, ['s', u.i, sk, -1, R1(u.x), R1(u.y), S.r || 3]); return true;
    }
    if (S.t === 'trap') {
      let any = 0;
      for (const k in R.tr) { const c = +k; if (R.tr[k] > R.t && (cx(c) - u.x) ** 2 + (cy(c) - u.y) ** 2 <= S.r * S.r) { R.tr[k] = R.t; any++; } }
      if (!any) return false;
      fxp(R, ['s', u.i, sk, u.i]); return true;
    }
    return false;
  }

  /* 함정 */
  function fireTrap(s, R, c, k, h) {
    const T = TP[k]; if (!T) return;
    const sc = trapScale(s), dm = T.dm * sc;
    const heroes = () => R.u.filter((o) => o.hp > 0 && side(R, o) === 1);
    R.tr[c] = R1(R.t + T.cd);
    fxp(R, ['t', c, k]);
    if (h && !h.seen.includes(c)) h.seen.push(c);
    switch (k) {
      case 'A': rawDmg(s, R, h, dm); break;
      case 'B': addSt(R, h, 'wet', 6); break;
      case 'C': {
        if (on(R, h, 'wet')) { fxp(R, ['c', '감전', R1(h.x), R1(h.y)]); rawDmg(s, R, h, dm * 2.2); heroes().forEach((o) => { if (o !== h && on(R, o, 'wet') && d2(o, h) <= 4) rawDmg(s, R, o, dm * 1.2); }); }
        else rawDmg(s, R, h, dm);
        break;
      }
      case 'S': addSt(R, h, 'sl', 4, 0.45); break;
      case 'D': rawDmg(s, R, h, dm); addSt(R, h, 'bn', 4); fireCombo(s, R, h); break;
      case 'E': addSt(R, h, 'oil', 8); break;
      case 'F': rawDmg(s, R, h, dm); if (on(R, h, 'wet')) { fxp(R, ['c', '빙결', R1(h.x), R1(h.y)]); addSt(R, h, 'sn', 2.5); addSt(R, h, 'fz', 2.5); } else addSt(R, h, 'sl', 3, 0.6); break;
      case 'K': addSt(R, h, 'rt', 3); break;
      case 'G': heroes().forEach((o) => { if (d2(o, { x: cx(c), y: cy(c) }) <= 1.44 * 1.44) addSt(R, o, 'ps', 5); }); break;
      case 'H': { const bound = on(R, h, 'rt') || on(R, h, 'sn') || on(R, h, 'sp'); if (bound) fxp(R, ['c', '난도질', R1(h.x), R1(h.y)]); rawDmg(s, R, h, dm * (bound ? 1.7 : 1)); break; }
      case 'L': rawDmg(s, R, h, dm); addSt(R, h, 'sn', 2); break;
      case 'M': rawDmg(s, R, h, dm); fxp(R, ['a', -c - 1, h.i, 1]); break;
      case 'T': rawDmg(s, R, h, dm * (HERO[h.k] && (HERO[h.k].ai === 't' || HERO[h.k].ai === 'x') ? 1.6 : 1)); addSt(R, h, 'rt', 1.5); break;
      case 'I': heroes().forEach((o) => { if (Math.round(o.y) === cy(c) && Math.abs(o.x - cx(c)) <= 4.2) rawDmg(s, R, o, dm); }); break;
      case 'J': {
        const free = prisonCap(s) - s.pr.length - R.caps.length;
        if (h.hp < h.mh * 0.45 && free > 0 && !h.b && !h.sm) { fxp(R, ['c', '함정문', R1(h.x), R1(h.y)]); h.cap = 1; h.hp = 0; }
        else { rawDmg(s, R, h, dm); addSt(R, h, 'sn', 2); }
        break;
      }
      case 'N': if (!h.b) addSt(R, h, 'cf', 4); break;
      case 'O': rawDmg(s, R, h, dm); addSt(R, h, 'rt', 2.5); R.u.forEach((o) => { if (o.hp > 0 && side(R, o) === 0 && d2(o, h) <= 9) o.hp = Math.min(o.mh, o.hp + 20 * sc); }); break;
      case 'P': heroes().forEach((o) => { if (d2(o, { x: cx(c), y: cy(c) }) <= 1.44 * 1.44) addSt(R, o, 'sp', 3); }); break;
      case 'Q': addSt(R, h, 'cs', 8); break;
      case 'R': heroes().forEach((o) => { if (d2(o, { x: cx(c), y: cy(c) }) <= 1.8 * 1.8) rawDmg(s, R, o, dm); }); break;
    }
  }

  /* 이동 */
  function stepField(R, u, field, dist, avoidWall) {
    const c = cellOf(u);
    let best = -1, bv = field[c];
    for (const j of NB4[c]) {
      if (avoidWall && R.wall[j] > R.t) continue;
      if (field[j] < bv - 1e-6) { bv = field[j]; best = j; }
    }
    const tc = best >= 0 ? best : c;
    moveToward(u, cx(tc), cy(tc), dist);
  }
  function moveToward(u, tx, ty, dist) {
    const dx = tx - u.x, dy = ty - u.y, l = Math.sqrt(dx * dx + dy * dy);
    if (l < 1e-4) return;
    const k = Math.min(1, dist / l); u.x += dx * k; u.y += dy * k;
    if (Math.abs(dx) > 0.05) u.fl = dx < 0 ? 1 : 0;
  }
  function speedOf(R, u) {
    let v = u.v;
    if (on(R, u, 'wet')) v *= 0.85;
    if (on(R, u, 'oil')) v *= 0.75;
    if (on(R, u, 'sl')) v *= stV(R, u, 'sl', 0.6);
    if (on(R, u, 'hs')) v *= 1.4;
    return v;
  }

  /* 한 스텝 */
  function step(s, R) {
    R.t = R1(R.t + DT);
    const t = R.t;
    // 등장
    while (R.q.length && R.q[0][1] <= t) {
      const k = R.q.shift()[0]; const h = mkHero(s, R, k); R.u.push(h);
      if (HERO[k].boss) fxp(R, ['B', h.i, k]);
    }
    // 마력
    s.mana = Math.min(manaCap(s), s.mana + DT * (0.6 + 0.08 * roomPow(s, 'k')) * (s.mt === 'mag' ? 1.3 : 1));
    // 상태 피해
    const tickDot = Math.round(t * 10) % 5 === 0;
    for (const u of R.u) {
      if (u.hp <= 0) continue;
      if (tickDot) {
        if (on(R, u, 'bn')) rawDmg(s, R, u, 3 * (1 + 0.05 * s.night));
        if (on(R, u, 'ps')) rawDmg(s, R, u, 3.5 * (1 + 0.05 * s.night));
      }
      for (const sk of u.sk) sk[1] -= DT;
      u.ac -= DT;
    }
    // 제단 회복
    if (R.alt.length && Math.round(t * 10) % 10 === 0) {
      const al = R.alt.length;
      R.u.forEach((o) => { if (o.hp > 0 && side(R, o) === 0 && R.alt.some((c) => (cx(c) - o.x) ** 2 + (cy(c) - o.y) ** 2 <= 9)) o.hp = Math.min(o.mh, o.hp + o.mh * 0.015 * Math.min(4, al)); });
    }
    // 화살 벽
    for (let c = 0; c < N; c++) {
      if (s.t[c] !== 'M' || (R.tr[c] || 0) > t || R.off.includes(c)) continue;
      let b = null, bd = 6.25;
      for (const o of R.u) if (o.hp > 0 && side(R, o) === 1) { const d = (o.x - cx(c)) ** 2 + (o.y - cy(c)) ** 2; if (d <= bd) { bd = d; b = o; } }
      if (b) fireTrap(s, R, c, 'M', b);
    }
    // 유닛 행동
    for (const u of R.u) {
      if (u.hp <= 0) continue;
      if (u.ms && u.dn && u.dn <= t) { u.x = cx(s.Hc); u.y = cy(s.Hc); u.dn = 0; }
      if (u.sm && u.k === 'stonegolem' && u.ex <= t) { u.hp = 0; continue; }
      if (on(R, u, 'sn') || on(R, u, 'sp')) continue;
      const sd = side(R, u);
      // 스킬
      if (!on(R, u, 'fr')) for (const sk of u.sk) if (sk[1] <= 0) { if (tryCast(s, R, u, sk[0])) { sk[1] = SK[sk[0]].cd * (0.9 + Math.random() * 0.2); break; } else sk[1] = 0.5; }
      const sp = speedOf(R, u) * DT;
      const rooted = on(R, u, 'rt');
      if (u.s === 1 && sd === 1) heroAct(s, R, u, sp, rooted);
      else if (u.ms) masterAct(s, R, u);
      else monAct(s, R, u, sp, rooted, sd);
    }
    // 정리
    const dead = R.u.filter((u) => u.hp <= 0);
    if (dead.length) {
      for (const u of dead) onDeath(s, R, u);
      R.u = R.u.filter((u) => u.hp > 0 && !u.gone);
    }
    R.u = R.u.filter((u) => !u.gone);
    // 시간 제한 → 후퇴
    if (t >= R.tl && !R.ret) { R.ret = 1; R.u.forEach((u) => { if (u.s === 1) u.g = 'x'; }); fxp(R, ['r']); }
    if (t >= R.tl + 40) R.u.forEach((u) => { if (u.s === 1) { u.gone = 1; R.esc++; R.stolen += u.c || 0; } });
    R.u = R.u.filter((u) => !u.gone);
    const heroesLeft = R.u.some((u) => u.s === 1) || R.q.length;
    if (R.lose || !heroesLeft) R.end = 1;
  }
  function heroAct(s, R, u, sp, rooted) {
    const B = HERO[u.k];
    const c = cellOf(u);
    if (c !== u.lc) {
      u.lc = c;
      // 함정
      const tk = s.t[c] !== '-' ? s.t[c] : R.mines.includes(c) ? 'R' : null;
      if (tk && tk !== 'M' && (R.tr[c] || 0) <= R.t && !R.off.includes(c)) {
        fireTrap(s, R, c, tk, u);
        if (R.mines.includes(c)) { R.mines.splice(R.mines.indexOf(c), 1); }
      }
      // 해제·탐지
      for (const j of NB4[c].concat([c])) {
        if (s.t[j] === '-' || R.off.includes(j)) continue;
        if (u.k === 'explorer' || u.k === 'hunter') { if (!u.seen.includes(j)) u.seen.push(j); }
        if (u.k === 'archsage' && Math.random() < 0.5) { R.off.push(j); fxp(R, ['x', j]); continue; }
        if (B.dis && (s.mem.includes(j) || u.seen.includes(j) || j !== c) && Math.random() < B.dis * (s.mem.includes(j) ? 1 : 0.35)) { R.off.push(j); fxp(R, ['x', j]); }
      }
    }
    if (on(R, u, 'fr')) { if (!rooted) stepField(R, u, goalField(s, 'x'), sp, true); return; }
    if (on(R, u, 'cf')) {
      if (!rooted) { if (!u.cfT || u.cfT <= R.t) { u.cfT = R.t + 0.8; const nb = NB4[c].filter((j) => walkT(s.m[j])); u.cfC = nb.length ? pick(nb) : c; } moveToward(u, cx(u.cfC), cy(u.cfC), sp); }
      return;
    }
    const en = enemies(R, u);
    let tg = null;
    if (on(R, u, 'tt')) tg = R.u.find((o) => o.i === stV(R, u, 'tt', 0) && o.hp > 0);
    if (!tg && B.ai === 'a') tg = nearest(en.filter((o) => MON[o.k] && (MON[o.k].rk === 'm' || MON[o.k].rk === 's')), u, 6);
    if (!tg) tg = nearest(en, u, u.r + 0.4);
    if (tg && d2(tg, u) <= (u.r + 0.3) ** 2) {
      if (u.ac <= 0) { u.ac = u.as; hit(s, R, u, tg, 1, u.r > 2 ? 1 : 0); }
      if (tg.x < u.x - 0.05) u.fl = 1; else if (tg.x > u.x + 0.05) u.fl = 0;
      return;
    }
    if (rooted) return;
    if (tg) { moveToward(u, tg.x, tg.y, sp); return; }
    // 목표
    if (u.g === 'l' && s.r[c] === 'a') {
      u.tm += DT; if (u.tm >= 2) { const take = Math.min(s.gold, Math.round(45 * scaleN(s))); s.gold -= take; u.c += take; u.g = 'x'; fxp(R, ['g', R1(u.x), R1(u.y), take]); }
      return;
    }
    if (u.g === 'r' && s.r[c] === 'h') { if (s.pr.length) { fxp(R, ['c', '포로 탈출', R1(u.x), R1(u.y)]); R.freed = (R.freed || 0) + s.pr.length; s.pr = []; } u.g = 'x'; return; }
    if (u.g === 's' && goalField(s, 's')[c] === 0) { u.g = 'x'; u.sc = 1; return; }
    if (u.g === 'x' && c === s.E) { u.gone = 1; R.esc++; R.stolen += u.c || 0; u.seen.forEach((j) => { if (!R.seen.includes(j)) R.seen.push(j); }); return; }
    if ((u.g === 'l' && !cnt(s.r, 'a')) || (u.g === 'r' && !cnt(s.r, 'h'))) u.g = 'k';
    stepField(R, u, goalField(s, u.g), sp, true);
  }
  function masterAct(s, R, u) {
    const tg = nearest(enemies(R, u), u, u.r + 0.3);
    if (tg && u.ac <= 0) { u.ac = u.as; hit(s, R, u, tg, 1, 0); }
  }
  function monAct(s, R, u, sp, rooted, sd) {
    const en = enemies(R, u);
    let aggro = u.p != null && s.r[u.p] === 'g' ? 5 : 6.5;
    if (u.sm) aggro = 4.5;
    if (R.rally && R.rally.u > R.t && sd === 0 && !u.sm) {
      const rc = R.rally.c; const dd = (cx(rc) - u.x) ** 2 + (cy(rc) - u.y) ** 2;
      const near = nearest(en, u, u.r + 0.3);
      if (near) { if (u.ac <= 0) { u.ac = u.as; hit(s, R, u, near, 1, u.r > 2 ? 1 : 0); } return; }
      if (!rooted && dd > 0.3) stepField(R, u, bfsFrom(s.m, rc), sp * 1.5, false);
      return;
    }
    if (on(R, u, 'fr') && !rooted) { stepField(R, u, bfsFrom(s.m, s.Hc), sp, false); return; }
    const tg = nearest(en, u, aggro);
    if (tg) {
      if (d2(tg, u) <= (u.r + 0.3) ** 2) { if (u.ac <= 0) { u.ac = u.as; hit(s, R, u, tg, 1, u.r > 2 ? (MON[u.k] && MON[u.k].rk === 'm' ? 2 : 1) : 0); } if (tg.x < u.x - 0.05) u.fl = 1; else if (tg.x > u.x + 0.05) u.fl = 0; return; }
      if (rooted) return;
      if (d2(tg, u) < 2.2) moveToward(u, tg.x, tg.y, sp);
      else stepField(R, u, bfsFrom(s.m, cellOf(tg)), sp, false);
      return;
    }
    if (rooted) return;
    const home = u.p != null ? u.p : s.Hc;
    if ((cx(home) - u.x) ** 2 + (cy(home) - u.y) ** 2 > 0.05) { if (cellOf(u) === home) moveToward(u, cx(home), cy(home), sp); else stepField(R, u, bfsFrom(s.m, home), sp, false); }
  }
  function onDeath(s, R, u) {
    fxp(R, ['k', u.i, R1(u.x), R1(u.y), u.s, u.k]);
    if (u.ms) { R.lose = 1; return; }
    if (u.s === 1) {
      const B = HERO[u.k];
      if (u.c) { s.gold += u.c; u.c = 0; }
      if (u.sm) return;
      R.gain += Math.round(B.loot * (1 + 0.06 * s.night));
      R.kills++;
      if (u.b) R.bossDown = 1;
      const killer = R.u.find((o) => o.i === u.la);
      if (killer && killer.ri) R.xp[killer.ri] = (R.xp[killer.ri] || 0) + (u.b ? 20 : 6);
      const free = prisonCap(s) - s.pr.length - R.caps.length;
      if (!u.b && free > 0 && (u.cap || Math.random() < 0.55)) { R.caps.push(u.k); fxp(R, ['p', R1(u.x), R1(u.y)]); }
      return;
    }
    if (u.ri) R.ko.push(u.ri);
  }

  /* ================= 주인 스킬 ================= */
  function msAvail(s, k) { const M = MS[k]; return !!M && (M.ty === 'all' || M.ty === s.mt) && s.res >= M.rq; }
  function castMS(s, k, c) {
    const R = s.R, M = MS[k];
    if (!R || s.ph !== 'raid') return '침입 중에만 써요';
    if (!msAvail(s, k)) return '아직 못 쓰는 스킬이에요';
    if ((R.mcd[k] || 0) > R.t) return '다시 쓰려면 기다려야 해요';
    if (s.mana < M.mp) return '마력이 모자라요';
    c = c | 0; if (c < 0 || c >= N) return '판 밖';
    const P = msPow(s), at = { x: cx(c), y: cy(c) };
    const H = R.u.filter((o) => o.hp > 0 && side(R, o) === 1);
    const inR = (o, r) => d2(o, at) <= r * r;
    const near1 = () => nearest(H, at, 1.6);
    const needCell = ['wall', 'golem', 'mine', 'descend', 'rally'];
    if (needCell.includes(k) && !walkT(s.m[c])) return '걸을 수 있는 칸을 골라요';
    switch (k) {
      case 'heal': { const al = R.u.filter((o) => o.hp > 0 && side(R, o) === 0 && inR(o, M.r)); if (!al.length) return '근처에 마물이 없어요'; al.forEach((o) => (o.hp = Math.min(o.mh, o.hp + o.mh * 0.4))); break; }
      case 'fear': { const h = H.filter((o) => inR(o, M.r)); if (!h.length) return '근처에 용사가 없어요'; h.forEach((o) => addSt(R, o, 'fr', 4)); break; }
      case 'bolt': { const h = H.filter((o) => inR(o, M.r)); if (!h.length) return '근처에 용사가 없어요'; h.forEach((o) => rawDmg(s, R, o, 70 * P * (on(R, o, 'wet') ? 2 : 1))); break; }
      case 'wall': if (c === s.Hc || c === s.E) return '그 칸은 막을 수 없어요'; R.wall[c] = R1(R.t + 12); break;
      case 'storm': { const h = H.filter((o) => inR(o, M.r)); if (!h.length) return '근처에 용사가 없어요'; h.forEach((o) => { rawDmg(s, R, o, 45 * P); addSt(R, o, 'bn', 4); fireCombo(s, R, o); }); break; }
      case 'stop': if (!H.length) return '용사가 없어요'; H.forEach((o) => addSt(R, o, 'sn', 3.5)); break;
      case 'descend': { const mu = R.u.find((o) => o.ms); if (!mu) return '?'; mu.x = at.x; mu.y = at.y; mu.dn = R1(R.t + 10); H.filter((o) => inR(o, M.r)).forEach((o) => rawDmg(s, R, o, 60 * P)); break; }
      case 'rally': R.rally = { c, u: R1(R.t + 8) }; break;
      case 'cry': R.buf.cry = R1(R.t + 10); break;
      case 'blades': { const h = H.filter((o) => inR(o, M.r)); if (!h.length) return '근처에 용사가 없어요'; h.forEach((o) => rawDmg(s, R, o, 55 * 3 * P)); break; }
      case 'charm': { const h = near1(); if (!h) return '그 근처에 용사가 없어요'; if (h.b) return '칭호 용사는 홀릴 수 없어요'; addSt(R, h, 'ch', 10); break; }
      case 'dream': { const h = H.filter((o) => inR(o, M.r)); if (!h.length) return '근처에 용사가 없어요'; h.forEach((o) => addSt(R, o, 'sp', 4)); break; }
      case 'kiss': { const h = near1(); if (!h) return '그 근처에 용사가 없어요'; addSt(R, h, 'mk', 10); break; }
      case 'stage': if (!H.length) return '용사가 없어요'; H.forEach((o) => { if (!o.b) addSt(R, o, 'cf', 4); else addSt(R, o, 'sl', 4, 0.5); }); break;
      case 'reload': R.tr = {}; R.off = []; break;
      case 'over': R.buf.over = R1(R.t + 10); break;
      case 'golem': R.u.push({ i: R.uid++, s: 0, k: 'stonegolem', sm: 1, ex: R1(R.t + 25), x: at.x, y: at.y, hp: Math.round(380 * P), mh: Math.round(380 * P), a: R1(20 * P), d: 30, r: 1.2, v: 1.4, as: 1.1, ac: 0, sk: [['quake', 3]], st: {}, p: c }); break;
      case 'mine': if (s.t[c] !== '-' || R.mines.includes(c)) return '이미 함정이 있는 칸이에요'; R.mines.push(c); break;
    }
    s.mana -= M.mp; R.mcd[k] = R1(R.t + M.cd);
    fxp(R, ['m', k, c]);
    return '';
  }

  /* ================= 침입 끝 → 아침 ================= */
  function endRaid(s) {
    const R = s.R;
    const mu = R.u.find((o) => o.ms);
    s.hp = R.lose ? 0 : Math.max(1, Math.round(mu ? mu.hp : s.hp));
    const ko = [];
    s.ro.forEach((e) => {
      const u = R.u.find((o) => o.ri === e.i);
      if (u) { e.hp = Math.max(0.05, u.hp / u.mh); e.xp += 3 + (R.xp[e.i] || 0); affGain(s, e, 2); }
      else if (R.ko.includes(e.i)) { e.hp = 0; e.md = Math.max(0, e.md - 6); e.af = Math.max(0, e.af - 2); e.xp += 2 + (R.xp[e.i] || 0); ko.push(e.k); }
    });
    if (R.lose) { s.ph = 'over'; s.win = 0; s.R = null; evPush(s, { k: 'story', id: 'defeat' }); return; }
    R.caps.forEach((k) => { if (s.pr.length < prisonCap(s)) { s.pr.push({ k, d: 0, t: 0 }); s.st.caps++; } });
    const gain = R.gain;
    s.gold = Math.min(goldCap(s), s.gold + gain); s.st.gold += gain; s.st.kills += R.kills;
    if (R.bossDown) s.st.bosses++;
    const fameG = R.kills + (R.bossDown ? 6 : 0) - Math.floor(R.stolen / 60);
    s.fame = Math.max(0, s.fame + fameG);
    R.seen.forEach((c) => { if (!s.mem.includes(c)) s.mem.push(c); });
    if (s.mem.length > 40) s.mem = s.mem.slice(-40);
    const sum = { kills: R.kills, caps: R.caps.length, gain, stolen: R.stolen, esc: R.esc, ko, boss: R.boss, bossDown: R.bossDown, freed: R.freed || 0, goal: R.goal, fame: fameG, mem: R.seen.length, hpLost: Math.max(0, Math.round((mu ? mu.mh : s.mhp) - s.hp)) };
    s.R = null;
    morning(s, sum);
  }
  function morning(s, sum) {
    const rep = Object.assign({ inc: {}, left: [], lvup: [], unlock: [], unfed: 0, unpaid: 0, wage: 0 }, sum);
    const duch = s.ro.some((e) => e.k === 'nightduchess') ? 1.1 : 1;
    const gi = Math.round((40 + 10 * roomPow(s, 'a') + 3 * roomPow(s, 'n')) * duch);
    s.gold = Math.min(goldCap(s), s.gold + gi); rep.inc.gold = gi;
    const mi = Math.round(7 * roomPow(s, 'b') + 4); s.mana = Math.min(manaCap(s), s.mana + mi); rep.inc.mana = mi;
    const r0 = s.res, ri = Math.round(2 + 4 * roomPow(s, 'i') + roomPow(s, 'l') + (s.ro.some((e) => e.k === 'abysswitch') ? 2 : 0)); s.res += ri; rep.inc.res = ri;
    TRAPS.forEach((T) => { if (T.rq > r0 && T.rq <= s.res) rep.unlock.push('함정 「' + T.n + '」'); });
    MSK.forEach((M) => { if ((M.ty === 'all' || M.ty === s.mt) && M.rq > r0 && M.rq <= s.res) rep.unlock.push('주인 스킬 「' + M.n + '」'); });
    const fi = Math.round(roomPow(s, 'o')); s.fame += fi; rep.inc.fame = fi + (sum.fame || 0);
    // 급여
    const wage = s.ro.reduce((a, e) => a + (isExec(e.k) ? 0 : e.h ? 15 : MON[e.k].wage), 0);
    rep.wage = wage;
    if (s.gold >= wage) s.gold -= wage; else { rep.unpaid = 1; s.ro.forEach((e) => { if (!isExec(e.k)) e.md -= 25; }); }
    // 식사
    const food = Math.floor(3 * roomPow(s, 'd') + 2 * roomPow(s, 'n'));
    const eaters = s.ro.filter((e) => !isExec(e.k)).sort((a, b) => b.af - a.af);
    eaters.forEach((e, j) => { if (j >= food) { e.md -= 15; rep.unfed++; } });
    // 기분·경험·친밀도·회복
    const spring = Math.min(8, 2 * roomPow(s, 'j')), train = 3 * roomPow(s, 'e'), feast = Math.min(3, cnt(s.r, 'p'));
    const healB = 0.5 + Math.min(0.4, 0.05 * cnt(s.r, 'c')) + 0.1 * cnt(s.r, 'j');
    s.ro.forEach((e) => {
      const M = MON[e.k];
      const likes = M ? cnt(s.r, M.like) > 0 : true;
      e.md += (likes ? 4 : -2) + spring + (s.mt === 'cha' ? 1 : 0);
      e.md = Math.max(0, Math.min(100, Math.round(e.md)));
      e.xp += Math.round(train);
      let up = 0; while (e.lv < 10 && e.xp >= xpNeed(e.lv)) { e.xp -= xpNeed(e.lv); e.lv++; up = 1; }
      if (up) rep.lvup.push(e.k);
      affGain(s, e, feast + (likes ? 1 : 0));
      e.hp = Math.min(1, e.hp + healB);
      checkAff(s, e);
    });
    // 떠나는 마물
    for (let j = s.ro.length - 1; j >= 0; j--) { const e = s.ro[j]; if (!isExec(e.k) && e.md < 15) { s.ro.splice(j, 1); rep.left.push(e.k); evPush(s, { k: 'leave', c: e.k }); } }
    s.hp = Math.min(s.mhp, Math.round(s.hp + s.mhp * 0.25));
    refreshVisitors(s);
    s.rep = rep; s.ph = 'morn';
    s.rd = s.rd.map(() => 0);
    evPush(s, { k: 'morn' });
  }
  function joinExec(s) {
    const have = new Set(s.ro.map((e) => e.k));
    const left = EXEC.map((e) => e[0]).filter((k) => !have.has(k));
    if (!left.length) return;
    const k = left[0]; const e = addRoster(s, k); e.p = defaultPost(s); e.lv = 2 + s.ch;
    evPush(s, { k: 'story', id: 'join_' + k });
  }
  function afterMorning(s) {
    const wasBoss = isBossNight(s);
    s.night++;
    if (s.mode === 'camp') {
      if (wasBoss) {
        evPush(s, { k: 'story', id: 'c' + s.chs[s.ch] + '_out' });
        s.ch++; s.nd = 0; s.mhp += 80; s.hp = Math.min(s.mhp, s.hp + 200);
        if (s.ch >= s.chs.length) { s.ph = 'over'; s.win = 1; evPush(s, { k: 'story', id: 'ending' }); return; }
        evPush(s, { k: 'story', id: 'c' + s.chs[s.ch] + '_in' });
        if (s.ch <= 3) joinExec(s);
        s.mem = s.mem.slice(Math.floor(s.mem.length / 2));
      } else s.nd++;
      if (isBossNight(s)) evPush(s, { k: 'story', id: 'c' + s.chs[s.ch] + '_boss' });
    } else {
      s.nd++;
      if (wasBoss) evPush(s, { k: 'story', id: 'endless_boss' });
      if (s.night % 7 === 3 && s.night < 25) joinExec(s);
    }
    startDay(s);
  }

  /* ================= 규칙 함수 ================= */
  function actor(s) {
    if (s.ph === 'over') return null;
    if (s.ph === 'pick') return s.pk.map((_, i) => i);
    if (s.ph === 'day' || s.ph === 'morn') { const a = []; s.rd.forEach((r, i) => { if (!r) a.push(i); }); return a.length ? a : null; }
    if (s.ph === 'raid') return s.pk.map((_, i) => i);
    return null;
  }
  function clockSeat(s) { const h = s.lv.findIndex((l) => !l); return h >= 0 ? -1 : 0; } // 사람 있으면 사람 화면이 시계
  /* 낮 건설 되돌리기: 짓기·파기·허물기(묶음 포함)마다 바뀐 칸만 기억(자리마다 최대 10단계).
     그 사이에 다른 행동(고용·대화·다른 주인의 건설 등)이 끼면 되돌릴 수 없음(seq가 이어져야 함). */
  const BUILD_OP = { dig: 1, room: 1, trap: 1, sell: 1 };
  function buildSnap(s, a) {
    const ok = BUILD_OP[a.t] || (a.t === 'batch' && !a.ready && (a.ops || []).length && a.ops.every((o) => o && BUILD_OP[o.t]));
    return ok ? { m: s.m, r: s.r, t: s.t, g: s.gold, mn: s.mana, lb: s.lab } : null;
  }
  function pushSnap(s, seat, b) {
    if (!b) return;
    const c = []; for (let i = 0; i < N; i++) if (b.m[i] !== s.m[i] || b.r[i] !== s.r[i] || b.t[i] !== s.t[i]) c.push(i, b.m[i] + b.r[i] + b.t[i]);
    if (!c.length) return;
    if (!s.un) s.un = s.pk.map(() => null);
    const st = s.un[seat] && s.un[seat].length && s.un[seat][s.un[seat].length - 1].q === s.seq - 1 ? s.un[seat] : [];
    st.push({ q: s.seq, g: b.g, mn: b.mn, lb: b.lb, c }); if (st.length > 10) st.shift();
    s.un[seat] = st;
  }
  function canUndo(s, seat) { const u = s.un && s.un[seat]; return !!(s.ph === 'day' && u && u.length && u[u.length - 1].q === s.seq); }
  function undoBuild(s, seat) {
    const u = s.un && s.un[seat];
    if (!u || !u.length || u[u.length - 1].q !== s.seq - 1) throw new Error('되돌릴 건설이 없어요');
    const b = u.pop();
    for (let k = 0; k < b.c.length; k += 2) { const i = b.c[k], v = b.c[k + 1]; s.m = setc(s.m, i, v[0]); s.r = setc(s.r, i, v[1]); s.t = setc(s.t, i, v[2]); }
    s.gold = b.g; s.mana = b.mn; s.lab = b.lb;
    if (u.length) u[u.length - 1].q = s.seq; else s.un[seat] = null;
    return s;
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad');
    const act = actor(s); if (!act || !act.includes(seat)) throw new Error('not your turn');
    s.seq++;
    if (s.ph === 'pick') {
      if (a.t === 'pick') {
        if (s.pk[seat]) throw new Error('이미 골랐어요');
        if (a.ex) { if (!EXEC.some((e) => e[0] === a.ex) || s.pk.includes(a.ex)) throw new Error('다른 간부를 골라요'); s.pk[seat] = a.ex; }
        if (seat === 0 || !s.mt) { if (a.mt && MTYPE[a.mt] && seat === 0) s.mt = a.mt; }
        if (!s.pk[seat]) throw new Error('간부를 골라요');
      } else if (a.t === 'force') { /* 남은 자리는 무작위 */ s.pk = s.pk.map((p) => p); s._force = 1; }
      else throw new Error('bad');
      if (s._force || s.pk.every(Boolean)) { delete s._force; finishPick(s); }
      return s;
    }
    if (s.ph === 'day') {
      if (a.t === 'ready') { s.rd[seat] = 1; if (s.un) s.un[seat] = null; if (s.rd.every(Boolean)) startRaid(s); return s; }
      if (a.t === 'undo') return undoBuild(s, seat);
      const snap = buildSnap(s, a);
      if (a.t === 'batch') {
        let ok = 0; for (const op of (a.ops || []).slice(0, 300)) if (doOp(s, seat, op) === '') ok++;
        if (a.ready) { s.rd[seat] = 1; if (s.un) s.un[seat] = null; if (s.rd.every(Boolean)) startRaid(s); }
        else if (!ok && (a.ops || []).length) throw new Error('할 수 있는 일이 없어요');
        if (ok) pushSnap(s, seat, snap);
        return s;
      }
      const err = doOp(s, seat, a); if (err) throw new Error(err);
      pushSnap(s, seat, snap);
      return s;
    }
    if (s.ph === 'morn') {
      if (a.t !== 'ack') throw new Error('bad');
      s.rd[seat] = 1; if (s.rd.every(Boolean)) afterMorning(s);
      return s;
    }
    if (s.ph === 'raid') {
      const R = s.R;
      if (a.t === 'sp') { R.sp = a.v === 2 ? 2 : 1; return s; }
      if (a.t === 'ms') { const err = castMS(s, a.k, a.c); if (err) throw new Error(err); return s; }
      if (a.t === 'tk') {
        if (a.n !== R.n) throw new Error('stale');
        R.n++; R.fx = [];
        if (a.ms) castMS(s, a.ms.k, a.ms.c);
        // AI 동료(사람이 섞인 판): 첫 AI 자리가 2초마다 주인 스킬 판단
        const aiSeat = s.lv.findIndex((l) => l > 0);
        if (aiSeat >= 0 && s.lv.some((l) => !l) && R.n % 4 === 0) { const c = aiCast(s, s.lv[aiSeat]); if (c) castMS(s, c.k, c.c); }
        for (let k = 0; k < STEPS && !R.end; k++) step(s, R);
        R.u.forEach((u) => { u.x = R2(u.x); u.y = R2(u.y); u.hp = R1(u.hp); u.ac = R1(u.ac); u.sk.forEach((q) => (q[1] = R1(q[1]))); for (const k in u.st) if (stU(u.st[k]) <= R.t) delete u.st[k]; });
        for (const k in R.wall) if (R.wall[k] <= R.t) delete R.wall[k];
        for (const k in R.tr) if (R.tr[k] <= R.t) delete R.tr[k];
        if (R.end) { s.lastRaid = { fx: R.fx, u: R.u.map((u) => ({ i: u.i, k: u.k, x: u.x, y: u.y, s: u.s })) }; endRaid(s); }
        return s;
      }
      throw new Error('bad');
    }
    throw new Error('over');
  }

  /* ================= AI ================= */
  function aiCast(s, lv) {
    const R = s.R; if (!R) return null;
    if (lv === 1 && Math.random() < 0.6) return null;
    const H = R.u.filter((o) => o.hp > 0 && side(R, o) === 1);
    if (!H.length) return null;
    const ok = MSK.filter((M) => msAvail(s, M.k) && s.mana >= M.mp && (R.mcd[M.k] || 0) <= R.t);
    if (!ok.length) return null;
    const dH = bfsFrom(s.m, s.Hc);
    // 가장 위험한 용사 무리
    let best = null, bv = 0;
    for (const h of H) {
      const near = H.filter((o) => d2(o, h) <= 4).length;
      const danger = near * 2 + (h.b ? 3 : 0) + Math.max(0, 12 - dH[cellOf(h)]) * 0.4;
      if (danger > bv) { bv = danger; best = h; }
    }
    if (!best) return null;
    const c = cellOf(best);
    const near = H.filter((o) => d2(o, best) <= 4).length;
    const mons = R.u.filter((o) => o.hp > 0 && side(R, o) === 0 && !o.ms);
    const hurt = mons.filter((o) => o.hp / o.mh < 0.5);
    const mu = R.u.find((o) => o.ms);
    const pref = [];
    if (hurt.length >= 2 && ok.find((m) => m.k === 'heal')) { const h0 = hurt[0]; return { k: 'heal', c: cellOf(h0) }; }
    if (mu && mu.hp / mu.mh < 0.5 && dH[c] < 4) pref.push('stop', 'stage', 'fear', 'dream', 'wall', 'blades', 'storm', 'bolt');
    if (near >= 3) pref.push('stop', 'storm', 'blades', 'dream', 'stage', 'cry', 'over');
    if (best.b) pref.push('kiss', 'bolt', 'descend', 'blades', 'cry');
    if (Object.keys(R.tr).length >= 3) pref.push('reload');
    pref.push('bolt', 'charm', 'golem', 'descend', 'mine', 'kiss');
    if (lv >= 3 && dH[c] > 10 && Math.random() < 0.5) return null; // 아껴 두기
    for (const k of pref) {
      const M = ok.find((m) => m.k === k); if (!M) continue;
      if (k === 'mine') { const p = mainPath(s).find((j) => dH[j] < dH[c] && dH[j] > dH[c] - 3 && s.t[j] === '-'); if (p != null) return { k, c: p }; continue; }
      if (k === 'golem' || k === 'wall') { const p = mainPath(s).find((j) => dH[j] === dH[c] - 1); if (p != null && p !== s.Hc) return { k, c: p }; continue; }
      return { k, c };
    }
    return null;
  }

  function aiPlan(s, seat, lv) {
    const ops = [];
    const tryOp = (op) => { if (doOp(s, seat, op) === '') { ops.push(op); return true; } return false; };
    const mine = (i) => canZone(s, seat, i);
    const noise = lv === 1 ? 0.35 : lv === 2 ? 0.12 : 0.03;
    const path = mainPath(s);
    const onPath = new Set(path);
    // 1) 파기 — 금맥·결정 우선, 길 옆
    for (let g = 0; g < 60 && s.lab > 0; g++) {
      let best = -1, bv = -1e9;
      for (let i = 0; i < N; i++) {
        if (!rockT(s.m[i]) || !mine(i) || !NB4[i].some((j) => walkT(s.m[j]))) continue;
        const cost = s.m[i] === '#' ? 1 : 2; if (cost > s.lab) continue;
        let v = (s.m[i] === '$' ? 6 : s.m[i] === '*' ? 4 : 0) + Math.random() * 3 * (1 + noise * 4);
        if (NB4[i].some((j) => onPath.has(j))) v += 1.5;
        if (cy(i) <= 2) v -= 3;
        if (v > bv) { bv = v; best = i; }
      }
      if (best < 0 || !tryOp({ t: 'dig', c: best })) break;
    }
    // 2) 방
    const nMon = s.ro.length;
    const want = { c: nonExec(s) + 2, a: 2 + Math.floor(s.night / 3), d: Math.ceil(nonExec(s) / 3) + 1, b: 2 + Math.floor(s.night / 4), i: 1 + Math.floor(s.night / 3), e: s.night > 1 ? 2 : 0, h: s.night > 0 ? 2 + Math.floor(s.night / 5) : 0, j: s.night > 2 ? 2 : 0, f: s.night > 3 ? 2 : 0, l: s.night > 4 ? 2 : 0, o: s.night > 5 ? 1 : 0, p: s.night > 6 ? 1 : 0, n: s.night > 2 ? 1 : 0, g: s.night > 3 ? 1 : 0, k: 4 };
    const order = U.shuffle(Object.keys(want)).sort((a, b) => (want[b] - cnt(s.r, b)) - (want[a] - cnt(s.r, a)));
    const reserve = 120 + s.night * 15;
    for (const k of order) {
      let need = want[k] - cnt(s.r, k);
      while (need > 0 && s.gold - RM[k].c > reserve) {
        let best = -1, bv = -1e9;
        for (let i = 0; i < N; i++) {
          if (s.m[i] !== '.' || s.r[i] !== '-' || s.t[i] !== '-' || !mine(i) || onPath.has(i)) continue;
          let v = Math.random() * (1 + noise * 6);
          NB4[i].forEach((j) => { if (s.r[j] === k) v += 2; if (s.r[j] === RM[k].adj) v += lv >= 2 ? 1.5 : 0; });
          if (v > bv) { bv = v; best = i; }
        }
        if (best < 0 || !tryOp({ t: 'room', c: best, k })) break;
        need--;
      }
    }
    // 3) 함정 — 길 위, 연계 짝
    const pairs = [['B', 'C'], ['E', 'D'], ['K', 'H'], ['B', 'F'], ['S', 'H'], ['L', 'H'], ['A'], ['M'], ['G', 'D'], ['Q'], ['R'], ['N'], ['O'], ['J'], ['T'], ['I'], ['P']];
    const pc = path.filter((i) => mine(i) && cy(i) > 2);
    let slots = pc.filter((i) => s.t[i] === '-' && s.r[i] === '-');
    const trapBudget = s.gold - (lv === 1 ? 60 : 40);
    let spent = 0;
    for (let g = 0; g < 30 && slots.length; g++) {
      const pr = lv === 1 ? [pick(TRAPS).k] : pick(pairs.filter((p) => p.every((k) => s.res >= TP[k].rq)));
      if (!pr) break;
      const total = pr.reduce((a, k) => a + trapCost(s, k), 0);
      if (spent + total > trapBudget) break;
      const st = slots.findIndex((i, j) => pr.length === 1 || (slots[j + 1] != null && NB4[i].includes(slots[j + 1])));
      if (st < 0) break;
      const cells = pr.length === 1 ? [slots[st]] : [slots[st], slots[st + 1]];
      let okc = true;
      pr.forEach((k, j) => { if (!tryOp({ t: 'trap', c: cells[j], k })) okc = false; else spent += trapCost(s, k); });
      slots = slots.filter((i) => s.t[i] === '-');
      if (!okc) break;
    }
    // 4) 고용
    for (let g = 0; g < 3; g++) {
      if (nonExec(s) >= cap(s) || !s.vis.length) break;
      let b = -1, bv = -1e9;
      s.vis.forEach((k, j) => { const v = MON[k].cost * (0.8 + Math.random() * noise * 2) + (cnt(s.r, MON[k].like) ? 30 : 0); if (hireCost(s, k) <= s.gold - 80 && v > bv) { bv = v; b = j; } });
      if (b < 0 || !tryOp({ t: 'hire', v: b })) break;
    }
    // 5) 대화·선물·각성
    const byAf = s.ro.slice().sort((a, b) => b.af - a.af);
    for (const e of byAf) { if (s.talk <= 0) break; tryOp({ t: 'talk', u: e.i }); }
    if (s.gold > 500) for (const e of s.ro.filter((e) => e.md < 50).slice(0, 2)) tryOp({ t: 'gift', u: e.i });
    for (const e of s.ro) if (!e.aw && e.af >= 85 && e.lv >= 5 && s.mana >= 100) tryOp({ t: 'aw', u: e.i });
    // 5b) 간부 제안: 여유가 있으면 받아들임
    if (s.prop) { const D = PROP[s.prop.id]; tryOp({ t: 'prop', ok: s.gold - D.g > (lv === 1 ? 40 : 160) && !(s.prop.id === 'tax' && lv >= 3 && s.gold > 400) ? 1 : 0 }); }
    // 6) 포로
    for (let j = s.pr.length - 1; j >= 0; j--) {
      const p = s.pr[j];
      if (HERO[p.k].boss) { tryOp({ t: 'pers', p: j, how: 'ransom' }); continue; }
      if (nonExec(s) < cap(s)) tryOp({ t: 'pers', p: j, how: 'talk' });
      else if (s.gold < 150) tryOp({ t: 'pers', p: j, how: 'ransom' });
    }
    // 7) 배치 — 전위는 함정 뒤, 후위는 그 뒤, 지원은 가운데
    if (lv >= 2 && path.length > 4) {
      const L2 = path.length;
      s.ro.forEach((e, j) => {
        const M = MON[e.k] || HERO[e.k]; const rk = M.rk || (HERO[e.k] && HERO[e.k].ai === 'h' ? 's' : 'f');
        const f = rk === 'f' ? 0.55 + (j % 3) * 0.08 : rk === 'b' || rk === 'm' ? 0.72 + (j % 3) * 0.06 : 0.8;
        const c = path[Math.min(L2 - 1, Math.floor(L2 * f))];
        if (c != null && e.p !== c) tryOp({ t: 'post', u: e.i, c });
      });
    }
    return ops;
  }

  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'pick') {
      if (s.pk[seat]) return null;
      if (L.pick && !L.pick.aiTurn(s.lv.map((l) => ({ ai: !!l })), (i) => !!s.pk[i])) return null;
      const left = EXEC.map((e) => e[0]).filter((k) => !s.pk.includes(k));
      return { t: 'pick', ex: pick(left), mt: seat === 0 ? pick(Object.keys(MTYPE)) : undefined };
    }
    if (s.ph === 'day') { const ops = aiPlan(s, seat, lv); return { t: 'batch', ops, ready: 1 }; }
    if (s.ph === 'morn') return { t: 'ack' };
    if (s.ph === 'raid') {
      if (clockSeat(s) !== seat) return null;
      const c = aiCast(s, lv);
      return { t: 'tk', n: s.R.n, ms: c || undefined };
    }
    return null;
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'raid') return clockSeat(s) === seat ? Math.round(500 / (s.R ? s.R.sp : 1)) : null;
    if (s.ph === 'pick') return s.pk[seat] ? null : 500;
    if (s.ph === 'morn') return 1200;
    return 900;
  }

  function result(s) {
    if (s.ph !== 'over') return null;
    const stats = [
      { label: '버틴 밤', values: s.pk.map(() => String(s.night + (s.win ? 0 : 0))) },
      { label: '쓰러뜨린 용사', values: s.pk.map(() => String(s.st.kills)) },
      { label: '칭호 용사 격파', values: s.pk.map(() => String(s.st.bosses)) },
      { label: '동료가 된 포로', values: s.pk.map(() => String(s.st.conv)) },
    ];
    const all = s.pk.map((_, i) => i);
    if (s.mode === 'endless') return { winners: s.night >= 10 ? all : [], title: '끝없는 침입 — ' + s.night + '번째 밤까지', text: '쓰러뜨린 용사 ' + s.st.kills + '명. 마왕은 다음 밤을 기약해요.', stats };
    if (s.win) return { winners: all, title: '던전을 지켜 냈어요!', text: '성검의 용사까지 물리치고 ' + s.chs.length + '장의 이야기를 끝냈어요.', stats };
    return { winners: [], title: '마왕이 쓰러졌어요', text: (s.ch + 1) + '장 ' + (s.nd + 1) + '번째 밤에서 무너졌어요.', stats };
  }
  /* ================= 대사 · 이야기 ================= */
  // 줄 형식 '말하는 이|표정|대사'. M = 마왕, N = 서술. 표정이 없는 그림이면 그 캐릭터 기본 → 임시 초상.
  const SCN = {
    prologue: [
      'N||땅 밑 깊은 곳, 오래 잠들어 있던 던전에 다시 불이 켜진다.',
      'M|neutral|……조용하네. 지난 전쟁 뒤로 이 옥좌에 앉는 건 처음인가.',
      'M|serious|성은 무너지고, 군단은 흩어졌어. 남은 건 이 굴 하나와 나를 믿고 따라온 몇 사람뿐.',
      '@0|serious|폐하. 지상의 길드가 이 던전의 위치를 알아냈습니다. 머지않아 용사들이 내려올 겁니다.',
      'M|smile|그럼 맞이할 준비를 해야지. 손님에게 실례가 되지 않도록.',
      'M|neutral|파고, 짓고, 모으자. 이번엔 아무도 잃지 않을 거야.',
      'N||【낮】에는 던전을 가꾸고, 【밤】에는 침입자를 막아요. 장마다 칭호를 가진 용사가 찾아와요.',
    ],
    c0_in: [
      'N||제1장 · 첫 번째 침입',
      'M|neutral|첫 손님은 신참들이겠지. 가시 몇 개면 돌아갈 거야.',
      '@0|serious|방심은 금물입니다. 신참일수록 무모하니까요.',
      'M|smile|걱정해 줘서 고마워. 그럼 통로부터 파 볼까.',
    ],
    c0_boss: [
      'N||짐승의 울음이 지상에서부터 울려 퍼진다.',
      'tamer|smile|이 굴 냄새, 마물이 잔뜩이네. 우리 아이들 배가 고파서 말이야.',
      'M|serious|맹수 조련사…… 늑대 떼를 끌고 오는 칭호 용사구나.',
      '@0|angry|폐하의 던전을 사냥터 취급이라니. 용서 못 합니다.',
      'M|neutral|늑대는 빠르지만 길을 몰라. 함정 골목으로 유인하자.',
    ],
    c0_out: [
      'tamer|hurt|하, 하하…… 이런 굴에 이렇게 이빨이 많을 줄이야.',
      'M|smile|돌아가서 전해. 이 던전엔 주인이 있다고.',
      '@0|smile|첫 장은 저희 승리입니다, 폐하.',
      'M|shy|……다 너희 덕분이야. 오늘 밤은 다 같이 따뜻한 걸 먹자.',
    ],
    c1_in: [
      'N||제2장 · 그림자의 추적',
      'M|serious|도망친 용사들이 우리 함정 위치를 길드에 팔았대.',
      'nightduchess|neutral|정보는 금화보다 비싸지요. 함정을 같은 자리에 두면 그대로 읽힐 겁니다.',
      'M|neutral|그럼 바꾸면 돼. 기억하는 만큼, 우리는 새로 짓자.',
    ],
    c1_boss: [
      'hunter|serious|은 말뚝은 충분해. 오늘 밤엔 마왕의 심장에 하나 꽂아 주지.',
      'M|neutral|그림자 사냥꾼. 함정을 읽고 피하는 사람이야.',
      '@0|serious|피할 수 없는 곳에 두면 됩니다. 묶고, 베고.',
      'M|smile|그물과 칼날. 좋아, 그걸로 가자.',
    ],
    c1_out: [
      'hunter|hurt|……읽었는데도 피할 수가 없었다고? 이 던전, 살아 있어.',
      'M|smile|살아 있지. 매일 아침 다시 태어나거든.',
      'M|neutral|사냥꾼은 물러났어. 하지만 길드는 더 큰 걸 보낼 거야.',
    ],
    c2_in: [
      'N||제3장 · 별의 서고',
      'abysswitch|smile|폐하, 지상에 「대현자」가 움직였대요. 함정 마법을 손짓 한 번에 풀어 버린다나?',
      'M|surprised|함정을 푼다고? 그럼 우리 골목이…….',
      'abysswitch|smile|그러니까 마물이 막아야죠. 마법이 안 통하면 주먹이 통하는 법이에요.',
    ],
    c2_boss: [
      'archsage|smile|흥미로운 구조네요. 누가 설계했는지 만나 보고 싶을 정도로.',
      'M|neutral|대현자. 칭찬은 고맙지만 여기서 돌아가 줬으면 해.',
      'archsage|serious|그럴 순 없어요. 지식은 나눠야 하니까, 이 던전의 비밀도요.',
    ],
    c2_out: [
      'archsage|hurt|……마법이 아니라 마음으로 짠 미궁이군요. 풀 수 없을 리가.',
      'M|smile|다음엔 손님으로 와. 서고는 늘 열어 둘게.',
    ],
    c3_in: [
      'N||제4장 · 불꽃의 심판',
      'M|serious|교단이 이단심문관을 보냈어. 마물이라면 아이든 늙은이든 가리지 않고 태운다는.',
      'beastqueen|angry|그 얘기 들었어. 우리 무리도 그 불에 많이 잃었지.',
      'M|neutral|이번엔 아무도 잃지 않아. 그게 내 약속이야.',
    ],
    c3_boss: [
      'inquisitor|angry|이단의 굴. 오늘 이 불꽃으로 깨끗이 정화하겠다.',
      'M|angry|정화? 여기 있는 아이들은 누구에게도 해를 끼치지 않았어.',
      'inquisitor|serious|존재가 죄다. 마왕, 너부터.',
      'M|serious|……그럼 막을 수밖에. 모두, 자리로.',
    ],
    c3_out: [
      'inquisitor|hurt|어째서…… 마물이 서로를 감싸지? 인간보다도 더.',
      'M|neutral|가족이니까. 너도 언젠가 알게 될 거야.',
    ],
    c4_in: [
      'N||제5장 · 칭호들의 연합',
      'nightduchess|serious|그림자 사냥꾼과 대현자가 손을 잡았다는 소식입니다. 함정은 읽히고, 마법은 풀리겠지요.',
      'M|neutral|그래도 마물들은 읽을 수 없어. 우리 아이들은 매일 강해지니까.',
    ],
    c4_boss: [
      'hunter|serious|이번엔 혼자가 아니야.',
      'archsage|smile|분석은 끝났어요. 이 던전의 약점은 마왕 자신.',
      'M|smile|그럼 와 봐. 내가 약점인지, 심장인지.',
    ],
    c4_out: [
      'archsage|surprised|계산이…… 틀렸어요? 마물들이 계산보다 강해요.',
      'hunter|hurt|철수다. 이 던전은 사냥터가 아니야.',
      'M|smile|잘했어, 모두. 오늘은 연회장 문을 활짝 열자.',
    ],
    c5_in: [
      'N||제6장 · 순례의 성녀',
      'M|surprised|성녀가 순례를 온다고? 싸우러가 아니라?',
      'nightduchess|neutral|「마왕을 구원하러」 온다더군요. 구원이란 이름의 침략이지요.',
      'M|serious|……구원받을 이유는 없는데. 그래도 그 사람, 마물을 해치진 않는대.',
    ],
    c5_boss: [
      'saint|smile|마왕님. 당신의 외로움을 덜어 드리러 왔어요.',
      'M|shy|……외롭지 않아. 이젠.',
      'saint|serious|그 말이 진심이라면, 그 증거를 보여 주세요.',
    ],
    c5_out: [
      'saint|shy|……정말이네요. 당신 곁엔 이렇게 많은 사람이 있어요.',
      'M|smile|구원은 필요 없어. 대신 차 한 잔이라면 언제든.',
      'N||지상에서 마지막 소문이 퍼진다. 「성검이 깨어났다.」',
    ],
    c6_in: [
      'N||마지막 장 · 성검',
      'M|serious|성검의 용사. 마왕을 쓰러뜨릴 운명을 진 아이.',
      '@0|serious|폐하, 어떤 운명이든 저희가 베어 내겠습니다.',
      'M|smile|운명은 베는 게 아니야. 지켜 내는 거지. 모두와 함께.',
    ],
    c6_boss: [
      'holysword|serious|마왕. 네가 사라지면 세상은 평화로워진다고 배웠어.',
      'M|neutral|그렇게 배웠구나. 그럼 오늘 다른 걸 배워 가.',
      'holysword|angry|말로는 안 속아. 성검이 빛나는 한, 나는 멈추지 않아!',
      'M|serious|모두. 마지막 밤이야. 끝까지 함께해 줘.',
    ],
    c6_out: [
      'holysword|hurt|성검이…… 너를 베지 않겠대. 왜지?',
      'M|smile|칼은 주인이 무엇을 지키는지 아는 법이니까.',
      'holysword|shy|……나, 틀렸던 걸까.',
      'M|neutral|틀린 게 아니라 몰랐던 거야. 이제 알았으면 됐어.',
    ],
    ending: [
      'N||성검의 빛이 잦아들고, 던전에 아침이 온다.',
      'M|smile|끝났어. 아무도 잃지 않았어.',
      '@0|happy|폐하의 약속, 지켜 내셨습니다.',
      'M|shy|우리가 지켜 낸 거야. ……고마워, 정말로.',
      'N||던전의 주인은 오늘도 옥좌에 앉아 있다. 이제는 혼자가 아니다.',
    ],
    defeat: [
      'M|hurt|……미안해, 모두. 여기까지인가 봐.',
      '@0|sad|폐하! 아직……!',
      'N||옥좌가 무너지고, 던전의 불이 하나둘 꺼진다.',
    ],
    endless_in: [
      'N||끝없는 침입 — 몇 번째 밤까지 버틸 수 있을까요?',
      'M|smile|좋아. 오늘 밤도, 내일 밤도. 몇 번이고 맞이해 줄게.',
    ],
    endless_boss: [
      'M|smile|칭호 용사도 물리쳤어. 다음 밤은 더 거세겠지만.',
    ],
    join_dragonknight: ['dragonknight|serious|진홍 용기사, 지금 도착했습니다. 폐하의 검이 되겠습니다.', 'M|smile|기다렸어. 네가 앞에 서 주면 든든해.', 'dragonknight|flustered|그, 그런 말씀은…… 전장에서 증명하겠습니다.'],
    join_abysswitch: ['abysswitch|smile|심연의 대마녀, 재밌는 일 있다길래 왔어요.', 'M|neutral|연구실은 폭발시키지 말아 줘.', 'abysswitch|smile|약속은 못 하지만 노력은 해 볼게요.'],
    join_nightduchess: ['nightduchess|neutral|밤의 여공작입니다. 장부를 보니 한숨이 나오는군요.', 'M|flustered|그, 그렇게 엉망이야?', 'nightduchess|smile|제가 왔으니 이제 괜찮습니다.'],
    join_beastqueen: ['beastqueen|smile|짐승 무리의 여왕, 합류! 강한 놈이 온다며?', 'M|smile|응. 아주 강한 손님들이 와.', 'beastqueen|happy|좋아! 그럼 신나게 물어뜯어 주지.'],
  };
  // 친밀도 이벤트 3단계 (간부·마물)
  const AFF = {
    dragonknight: [
      ['dragonknight|serious|폐하, 오늘 훈련 상대를 부탁드려도 되겠습니까?', 'M|surprised|내가? 상대가 될까?', 'dragonknight|flustered|아, 아닙니다! 그저 폐하의 검을 직접 보고 싶어서…….', 'M|smile|그럼 살살 해 줘.'],
      ['dragonknight|sad|어릴 적, 저는 비늘 색이 달라 무리에서 쫓겨났습니다.', 'M|neutral|그 붉은 비늘, 나는 처음부터 예쁘다고 생각했어.', 'dragonknight|shy|……그 말씀, 평생 잊지 않겠습니다.'],
      ['dragonknight|serious|폐하. 저는 검으로만 말할 줄 압니다. 그래서…….', 'M|shy|응.', 'dragonknight|flustered|그러니까, 곁에 있게 해 주십시오. 기사가 아니라, 그냥…… 저로서.', 'M|smile|처음부터 그러길 바랐어.'],
    ],
    abysswitch: [
      ['abysswitch|smile|폐하, 이 물약 마셔 볼래요? 아마 안 터질 거예요.', 'M|flustered|아마?', 'abysswitch|happy|농담이에요. 반쯤은.'],
      ['abysswitch|neutral|사람들은 제 마법을 무서워했어요. 폐하는 왜 안 무서워해요?', 'M|smile|그 마법으로 우리를 지켜 주잖아.', 'abysswitch|shy|……그렇게 말해 준 사람은 처음이에요.'],
      ['abysswitch|serious|별을 하나 이름 지었어요. 아무한테도 안 알려 줄 거예요.', 'M|surprised|나한테도?', 'abysswitch|shy|폐하 이름이니까요. 비밀이에요.'],
    ],
    nightduchess: [
      ['nightduchess|neutral|폐하, 이번 달 장부입니다. 식비가 예산을 넘었군요.', 'M|flustered|오크가 좀 많이 먹어서…….', 'nightduchess|smile|괜찮습니다. 그 웃음값이라 치지요.'],
      ['nightduchess|sad|오래 살다 보면 이름을 불러 주는 사람이 하나둘 사라집니다.', 'M|neutral|그럼 내가 계속 부를게. 여공작, 하고.', 'nightduchess|shy|……예법에 어긋나는 대답이지만, 기쁩니다.'],
      ['nightduchess|serious|폐하. 한 곡만 함께 춰 주시겠습니까? 연회장이 비어 있을 때.', 'M|shy|나 춤 못 춰.', 'nightduchess|smile|제가 이끌겠습니다. 처음부터 그럴 생각이었으니까요.'],
    ],
    beastqueen: [
      ['beastqueen|happy|폐하! 팔씨름 한 판 어때?', 'M|surprised|지금? 여기서?', 'beastqueen|smile|지는 게 무서워? 하하, 농담이야. 져 줄게.'],
      ['beastqueen|sad|무리를 이끌다 보면 약한 모습을 못 보여. 폐하도 그렇지?', 'M|neutral|응. 그래도 너 앞에선 괜찮을 것 같아.', 'beastqueen|shy|……뭐야, 갑자기. 꼬리가 멋대로 흔들리잖아.'],
      ['beastqueen|serious|폐하. 내 무리는 이제 여기야. 그리고 내 짝도.', 'M|shy|짝……?', 'beastqueen|happy|대답은 천천히 해도 돼. 사냥은 기다리는 거니까.'],
    ],
    slime: [
      ['slime|happy|마왕님! 오늘 돌 백 개 날랐어요! 꿀꺽해서요!', 'M|smile|대단하네. 배는 안 아파?', 'slime|smile|말랑하니까 괜찮아요!'],
      ['slime|sad|가끔 몸이 너무 투명해서 아무도 저를 못 봐요.', 'M|neutral|난 잘 보여. 반짝반짝해서.', 'slime|shy|헤헤…… 더 반짝일게요.'],
      ['slime|happy|마왕님 모양으로 변신해 봤어요! 어때요?', 'M|flustered|파, 파랗네…….', 'slime|smile|좋아하는 사람 모양이 제일 쉬워요!'],
    ],
    skelknight: [
      ['skelknight|serious|기사의 예로 인사드립니다, 주군.', 'M|smile|그렇게 딱딱하게 안 해도 돼.', 'skelknight|neutral|예법은 제게 남은 마지막 살입니다.'],
      ['skelknight|sad|제 왕국은 사라졌습니다. 지킬 것이 없는 기사는 무엇입니까.', 'M|neutral|여기 있잖아. 지킬 것.', 'skelknight|surprised|……그렇군요. 다시 맹세할 곳이 생겼군요.'],
      ['skelknight|smile|갑옷을 닦았습니다. 주군께 부끄럽지 않도록.', 'M|smile|반짝이네. 멋있어.', 'skelknight|shy|뼈만 남은 몸이 이렇게 뜨거울 줄은.'],
    ],
    harpy: [
      ['harpy|happy|들었어요? 지상에 새 빵집이 생겼대요! 그리고 길드장이 대머리래요!', 'M|smile|정찰 보고야, 수다야?', 'harpy|smile|둘 다요!'],
      ['harpy|sad|날개로 물건을 못 쥐어서, 예전엔 쓸모없다는 말을 들었어요.', 'M|neutral|넌 우리 눈이야. 제일 멀리 보잖아.', 'harpy|shy|……그럼 마왕님만 계속 볼게요.'],
      ['harpy|happy|마왕님, 달 보러 가요! 제가 안고 날아 줄게요!', 'M|flustered|떨어뜨리면 안 돼!', 'harpy|smile|절대 안 놓쳐요. 약속!'],
    ],
    lamia: [
      ['lamia|smile|온천 옆이 따뜻해서 좋아요. 마왕님도 감겨 볼래요?', 'M|flustered|감, 감긴다는 건…….', 'lamia|happy|후후, 따뜻하다는 뜻이에요.'],
      ['lamia|neutral|저는 느려서, 늘 무리 끝에 있었어요.', 'M|smile|여기선 끝도 처음도 없어.', 'lamia|shy|그럼 마왕님 옆에 있을래요.'],
      ['lamia|serious|한번 감은 건 놓지 않아요. 그게 제 성격이에요.', 'M|shy|알고 있어.', 'lamia|smile|그러니까, 각오하세요.'],
    ],
    dragonkid: [
      ['dragonkid|serious|용기사님처럼 되려면 어떻게 해야 해요?', 'M|smile|매일 조금씩. 그리고 밥 많이 먹기.', 'dragonkid|happy|밥이라면 자신 있어요!'],
      ['dragonkid|sad|오늘 훈련에서 또 졌어요. 불도 제대로 못 뿜고.', 'M|neutral|불씨는 있어. 아직 바람이 모자랄 뿐.', 'dragonkid|surprised|바람…… 마왕님이 불어 주세요!'],
      ['dragonkid|happy|봐요! 날개가 조금 자랐어요!', 'M|smile|정말이네. 곧 하늘도 날겠다.', 'dragonkid|shy|처음 날면 마왕님한테 제일 먼저 갈게요.'],
    ],
    butler: [
      ['butler|serious|마왕님, 망토 주름이 0.3도 틀어졌습니다.', 'M|surprised|그게 보여?', 'butler|smile|제 일이니까요.'],
      ['butler|neutral|완벽하지 않으면 버려질까 봐, 늘 두려웠습니다.', 'M|neutral|틀려도 돼. 여긴 네 집이야.', 'butler|shy|……집. 좋은 말이네요.'],
      ['butler|smile|오늘은 마왕님을 위해 차를 준비했습니다. 처음으로, 일이 아니라.', 'M|smile|그럼 같이 마시자.', 'butler|shy|그 말을 기다렸습니다.'],
    ],
    golem: [
      ['golem|neutral|……돌, 팠다.', 'M|smile|고마워. 힘들지 않아?', 'golem|smile|……괜찮다. 마왕, 다정하다.'],
      ['golem|sad|……예전 주인은 나를 버리고 갔다.', 'M|neutral|난 안 가.', 'golem|shy|……알고 있다. 룬이 따뜻하다.'],
      ['golem|smile|……꽃, 심었다. 돌 틈에.', 'M|surprised|예쁘다.', 'golem|happy|……마왕 닮았다.'],
    ],
    witchapprentice: [
      ['witchapprentice|surprised|으앗! 또 냄비가…… 죄송해요!', 'M|smile|괜찮아. 다친 데는 없어?', 'witchapprentice|shy|마왕님은 혼내지 않으시네요.'],
      ['witchapprentice|sad|스승님처럼 될 수 있을까요. 늘 실수만 하는데.', 'M|neutral|대마녀도 처음엔 연구실을 날렸대.', 'witchapprentice|happy|정말요? 희망이 생겼어요!'],
      ['witchapprentice|smile|성공했어요! 마왕님 이름으로 지은 물약이에요.', 'M|flustered|효과가 뭔데?', 'witchapprentice|shy|마시면…… 웃게 돼요. 마왕님처럼.'],
    ],
    werewolf: [
      ['werewolf|serious|여왕님 명령으로 마왕님 경호를 맡았다.', 'M|smile|든든하네.', 'werewolf|neutral|……꼬리 만지지 마라.'],
      ['werewolf|sad|보름달이 뜨면 나를 잃을 때가 있다.', 'M|neutral|그럼 내가 이름을 불러 줄게. 돌아올 때까지.', 'werewolf|surprised|……그런 말을 한 건 네가 처음이다.'],
      ['werewolf|shy|……꼬리, 조금은 만져도 된다.', 'M|smile|정말?', 'werewolf|smile|마왕만이다.'],
    ],
    mimic: [
      ['mimic|happy|짠! 보물인 줄 알았죠?', 'M|surprised|깜짝이야!', 'mimic|smile|마왕님 놀라는 얼굴 최고예요.'],
      ['mimic|sad|다들 저를 열어 보고 실망해요. 보물이 아니라고.', 'M|neutral|난 열어 보고 기뻤는데.', 'mimic|shy|……그럼 마왕님 앞에서만 활짝 열릴게요.'],
      ['mimic|smile|제 상자 안에 진짜 보물 넣어 뒀어요. 마왕님 초상화요.', 'M|flustered|언제 그렸어?', 'mimic|happy|비밀!'],
    ],
    ghost: [
      ['ghost|smile|길 잃은 영혼은 없나 등불을 들고 돌아봤어요.', 'M|neutral|고생했어. 춥지 않아?', 'ghost|shy|유령은 춥지 않아요. 그래도 고마워요.'],
      ['ghost|sad|제가 왜 죽었는지 기억이 안 나요.', 'M|neutral|그럼 여기서 새로 기억을 만들자.', 'ghost|smile|첫 기억은 마왕님이네요.'],
      ['ghost|happy|오늘은 등불을 하나 더 켰어요. 마왕님 몫이에요.', 'M|smile|따뜻하다.', 'ghost|shy|제 마음이니까요.'],
    ],
    orc: [
      ['orc|happy|마왕! 고기 남았냐!', 'M|smile|식당에 있어. 천천히 먹어.', 'orc|smile|천천히는 못 한다!'],
      ['orc|neutral|사람들은 오크를 짐승이라 한다.', 'M|neutral|넌 우리 집 최고의 요리 평론가야.', 'orc|happy|하하! 그건 맞다!'],
      ['orc|shy|……마왕, 이 고기 제일 좋은 부위다. 너 먹어라.', 'M|surprised|네가 양보를?', 'orc|smile|좋아하는 사람한텐 준다.'],
    ],
    goblin: [
      ['goblin|happy|봐요! 새 함정 설계도! 이번엔 안 터져요!', 'M|smile|기대할게.', 'goblin|surprised|……아마도요!'],
      ['goblin|sad|작아서 다들 저를 무시해요.', 'M|neutral|이 던전 함정은 다 네 손에서 나왔어.', 'goblin|shy|……그럼 더 크게 만들게요. 마음만이라도.'],
      ['goblin|smile|마왕님 전용 의자 만들었어요. 등받이에 비밀 장치도!', 'M|flustered|무슨 장치?', 'goblin|happy|어깨 주물러 주는 거요!'],
    ],
    dryad: [
      ['dryad|smile|정원에 꽃이 피었어요. 마왕님 눈 색이에요.', 'M|smile|금색 꽃이네.', 'dryad|shy|제일 예쁜 색이죠.'],
      ['dryad|sad|숲이 불탈 때, 저 혼자 남았어요.', 'M|neutral|여기서 숲을 다시 키우자. 천천히.', 'dryad|smile|……네. 뿌리를 내릴게요.'],
      ['dryad|happy|꽃관 만들었어요. 써 주실래요?', 'M|shy|어울릴까.', 'dryad|smile|세상에서 제일요.'],
    ],
    undine: [
      ['undine|neutral|온천 온도 맞춰 뒀어요. 마왕님 좋아하는 온도로.', 'M|smile|내 취향을 어떻게 알아?', 'undine|smile|물은 다 기억해요.'],
      ['undine|sad|물은 흘러가 버려요. 저도 언젠가 그럴까 봐요.', 'M|neutral|그럼 여기 샘이 되면 돼. 늘 있는.', 'undine|shy|……고여 있는 것도 나쁘지 않네요.'],
      ['undine|smile|같이 온천 들어가요. 오늘은 제가 등을 밀어 드릴게요.', 'M|flustered|어, 응…….', 'undine|happy|후후, 얼굴이 빨개요.'],
    ],
    salamander: [
      ['salamander|angry|대장간 불이 약하잖아! 누가 바람구멍 막았어!', 'M|flustered|미, 미안. 내가 그랬나 봐.', 'salamander|shy|……마왕이면 봐줄게.'],
      ['salamander|sad|화내면 다들 피해. 진짜 화난 게 아닌데.', 'M|neutral|알아. 너는 뜨거운 거지, 무서운 게 아니야.', 'salamander|surprised|……그걸 아는 사람이 있었네.'],
      ['salamander|smile|마왕한테 줄 반지 두드려 만들었어. 불꽃 무늬로.', 'M|shy|예쁘다.', 'salamander|happy|당연하지! 내 불로 만든 건데!'],
    ],
    arachne: [
      ['arachne|smile|마왕님 새 드레스 치수 재러 왔어요.', 'M|flustered|또?', 'arachne|smile|매일 조금씩 더 아름다워지시니까요.'],
      ['arachne|sad|다리가 많아서, 다들 소리 지르며 도망가요.', 'M|neutral|그 다리로 이렇게 고운 비단을 짜잖아.', 'arachne|shy|……칭찬 받으니 실이 엉켜요.'],
      ['arachne|happy|완성했어요. 마왕님만을 위한 망토예요.', 'M|smile|가볍고 따뜻하네.', 'arachne|shy|제 마음을 한 올 한 올 넣었어요.'],
    ],
    dullahan: [
      ['dullahan|neutral|머리를 들고 다니면 인사할 때 편해요.', 'M|surprised|그런 장점이?', 'dullahan|smile|이렇게요. 꾸벅.'],
      ['dullahan|sad|죽음을 알리는 일을 오래 했어요. 다들 저를 미워했죠.', 'M|neutral|여기선 아무도 안 죽어. 그러니까 쉬어.', 'dullahan|shy|……쉬는 법을 잊어버렸어요.'],
      ['dullahan|smile|머리, 잠깐 맡아 주실래요? 믿는 사람한테만 맡겨요.', 'M|shy|무거워?', 'dullahan|happy|마왕님 품이면 가벼워요.'],
    ],
    lich: [
      ['lich|serious|마왕님, 지난번 빌려 간 책 반납 기한이 지났습니다.', 'M|flustered|아직 다 못 읽었어…….', 'lich|smile|사흘 연장해 드리죠. 특별히.'],
      ['lich|sad|천 년을 책과 살았습니다. 대화하는 법을 잊었지요.', 'M|neutral|지금 잘하고 있어.', 'lich|surprised|……그런가요. 이것도 기록해 둬야겠군요.'],
      ['lich|smile|마왕님에 관한 책을 쓰고 있습니다. 대출 금지 서가에 둘 겁니다.', 'M|shy|왜 금지야?', 'lich|shy|저만 읽고 싶어서요.'],
    ],
    minotaur: [
      ['minotaur|shy|저, 저기…… 미궁 지도 그렸어요. 보, 보실래요?', 'M|smile|와, 정말 꼼꼼하다.', 'minotaur|happy|헤헤……!'],
      ['minotaur|sad|덩치가 커서 다들 무서워해요. 저는 겁이 많은데.', 'M|neutral|그 덩치로 우리를 지켜 주잖아. 그게 진짜 용기야.', 'minotaur|surprised|……용기, 저한테도 있었네요.'],
      ['minotaur|shy|마왕님…… 미궁 한가운데에 비밀 방을 만들었어요. 둘만 아는.', 'M|shy|뭐 하는 방이야?', 'minotaur|smile|같이 쉬는 방이요.'],
    ],
    kitsune: [
      ['kitsune|smile|후후, 마왕님 운세를 봤어요. 오늘은 여우를 조심하래요.', 'M|surprised|너잖아.', 'kitsune|happy|정답이에요.'],
      ['kitsune|neutral|꼬리가 하나씩 늘 때마다 누군가를 잃었어요.', 'M|serious|이제 그만 잃어도 돼.', 'kitsune|shy|……그 말, 거짓이면 홀려 버릴 거예요.'],
      ['kitsune|smile|아홉 번째 꼬리는 마왕님 몫으로 남겨 둘게요.', 'M|shy|무슨 뜻이야?', 'kitsune|happy|여우는 속내를 말하지 않는답니다.'],
    ],
    oni: [
      ['oni|happy|마왕! 술 한잔 하자! 씨름도!', 'M|smile|술만 하자.', 'oni|smile|하하! 겁쟁이!'],
      ['oni|neutral|뿔이 하나라 오니 마을에서 반쪽이라 불렸지.', 'M|neutral|그 뿔 하나로 충분히 멋있어.', 'oni|shy|……술이 오르네. 그런 말 하지 마라.'],
      ['oni|smile|마왕, 이 술은 내가 백 년 묵힌 거다. 너랑 마시려고.', 'M|surprised|백 년이나?', 'oni|happy|기다릴 만한 상대였으니까!'],
    ],
    gargoyle: [
      ['gargoyle|neutral|……이상 없음.', 'M|smile|밤새 고마워. 좀 자.', 'gargoyle|serious|……파수는 자지 않는다.'],
      ['gargoyle|sad|……돌이 되어 있던 세월이 길었다. 아무도 말을 걸지 않았다.', 'M|neutral|이제 매일 걸게.', 'gargoyle|shy|……돌이, 녹는다.'],
      ['gargoyle|smile|……마왕의 방 앞, 내 자리로 정했다.', 'M|smile|든든해.', 'gargoyle|shy|……영원히.'],
    ],
    mushroom: [
      ['mushroom|neutral|으음…… 버섯 수프 다 됐어요…… 쿨.', 'M|smile|자면서 요리했어?', 'mushroom|smile|꿈에서 맛 봤어요…….'],
      ['mushroom|sad|다들 저를 독버섯이라고…… 독 없는데…….', 'M|neutral|네 수프가 제일 맛있어.', 'mushroom|happy|……진짜요? 잠이 깼어요.'],
      ['mushroom|shy|마왕님 무릎에서 낮잠 자도 돼요……?', 'M|shy|조금만이야.', 'mushroom|smile|포자 안 날릴게요…… 아마……'],
    ],
    mermaid: [
      ['mermaid|smile|새 노래 만들었어요. 들어 보실래요?', 'M|smile|응, 들려줘.', 'mermaid|happy|♪ 깊은 호수의 주인에게……'],
      ['mermaid|sad|바다에 가 본 적이 없어요. 여기서 태어났거든요.', 'M|neutral|언젠가 같이 가자.', 'mermaid|surprised|……약속이에요?'],
      ['mermaid|shy|이 노래는 마왕님한테만 불러요. 다른 사람이 들으면 안 돼요.', 'M|shy|무슨 노래인데?', 'mermaid|smile|사랑 노래요.'],
    ],
    imp: [
      ['imp|happy|심부름 다녀왔어요! 거스름돈은…… 수고비로!', 'M|surprised|어이.', 'imp|smile|헤헤, 농담이에요. 반만.'],
      ['imp|sad|작은 마물은 늘 심부름만 해요.', 'M|neutral|네 심부름 덕에 던전이 돌아가.', 'imp|shy|……그럼 더 빨리 뛸게요.'],
      ['imp|smile|마왕님 생일 몰래 알아냈어요. 기대하세요!', 'M|flustered|어떻게 알았어?', 'imp|happy|임프는 다 알아요!'],
    ],
    cyclops: [
      ['cyclops|serious|이 검, 한 번 더 두드려야 한다.', 'M|smile|완벽주의구나.', 'cyclops|neutral|장인이니까.'],
      ['cyclops|sad|눈이 하나라 사람들이 흉하다 했다.', 'M|neutral|그 눈으로 제일 정확한 칼을 만들잖아.', 'cyclops|shy|……칭찬은 서툴러서 곤란하다.'],
      ['cyclops|smile|마왕의 왕관을 고쳤다. 흠집 하나 없이.', 'M|smile|새것 같아.', 'cyclops|happy|네 머리에 어울리게.'],
    ],
    banshee: [
      ['banshee|sad|……오늘도 노래를 불렀어요. 슬픈 노래만 알아서.', 'M|neutral|그 노래, 나는 좋던데.', 'banshee|surprised|……정말요?'],
      ['banshee|neutral|제 노래를 들으면 다들 울어요. 그래서 혼자였어요.', 'M|smile|울어도 돼. 같이 울면 덜 슬퍼.', 'banshee|shy|……마왕님은 이상한 분이에요.'],
      ['banshee|smile|처음으로 기쁜 노래를 만들었어요. 마왕님 생각하면서.', 'M|smile|들려줘.', 'banshee|happy|♪…… 웃음이 나오는 노래예요.'],
    ],
    chimera: [
      ['chimera|happy|사냥감이다! ……아, 마왕이구나.', 'M|surprised|나를 사냥하려고?', 'chimera|smile|냄새가 좋아서 그만.'],
      ['chimera|sad|사자, 염소, 뱀. 어느 무리에도 못 꼈어.', 'M|neutral|여긴 다 섞여 사는 곳이야.', 'chimera|surprised|……그럼 여기가 내 무리야?'],
      ['chimera|smile|마왕한테 줄 사냥감 잡아 왔어! 제일 큰 걸로!', 'M|flustered|이, 이렇게 큰 건…….', 'chimera|happy|좋아하는 상대한텐 제일 큰 걸 주는 거야!'],
    ],
    succubus: [
      ['succubus|smile|마왕님 꿈에 놀러 가도 돼요?', 'M|flustered|안 돼.', 'succubus|happy|후후, 벌써 다녀왔는걸요.'],
      ['succubus|neutral|다들 제가 장난만 치는 줄 알아요.', 'M|neutral|진심일 때도 있다는 거, 알아.', 'succubus|shy|……들켰네요.'],
      ['succubus|serious|오늘은 꿈 말고, 깨어 있는 마왕님 곁에 있고 싶어요.', 'M|shy|……응.', 'succubus|smile|이건 장난 아니에요.'],
    ],
  };
  // 하루 대화(친밀도 단계 0~3에서 고름)
  const TALK = {
    dragonknight: ['오늘도 경계에 이상 없습니다, 폐하.', '훈련장 바닥이 패였습니다. 제가 너무 세게 휘둘렀나 봅니다.', '폐하, 식사는 하셨습니까? ……아닙니다, 그냥 궁금해서.'],
    abysswitch: ['연구실이요? 아직 서 있어요. 아직은.', '마력 샘 흐름이 좋네요. 폐하 기분이 좋은가 봐요.', '오늘 밤 별이 예뻐요. 땅속이라 안 보이지만.'],
    nightduchess: ['금화는 정직합니다. 사람보다 훨씬.', '예법은 무기입니다, 폐하. 칼보다 오래 남지요.', '오늘의 홍차는 제가 골랐습니다.'],
    beastqueen: ['몸이 근질거려! 빨리 밤이 왔으면.', '애들 밥은 잘 먹이고 있어? 굶기면 물어.', '폐하는 웃을 때가 제일 강해 보여.'],
    slime: ['오늘은 뭐 삼킬까요?', '말랑말랑!', '마왕님 신발 닦아 놨어요! 꿀꺽해서!'],
    skelknight: ['경계 근무 이상 없습니다.', '검은 녹슬어도 맹세는 녹슬지 않습니다.', '주군의 그림자에 서는 것이 영광입니다.'],
    harpy: ['오늘 새 소식 세 개! 들을래요?', '날개 손질했어요. 반짝반짝!', '지상 바람 냄새가 바뀌었어요. 비가 오려나 봐요.'],
    lamia: ['따뜻한 곳이 좋아요오.', '늪 냄새가 그리울 때도 있어요.', '마왕님 체온, 딱 좋아 보여요.'],
    dragonkid: ['오늘 불 세 번 뿜었어요!', '용기사님이 칭찬해 줬어요!', '날개 근육이 조금 붙었어요. 만져 보실래요?'],
    butler: ['오늘 일정 보고드립니다.', '먼지 한 톨 없습니다.', '마왕님, 자세가 아름다우십니다.'],
    golem: ['……돌.', '……마왕, 좋다.', '……일, 끝났다.'],
    witchapprentice: ['이번엔 안 터졌어요!', '스승님이 또 웃으셨어요. 제 머리 보고.', '물약 색이 예쁘게 나왔어요.'],
    werewolf: ['냄새로 침입자를 알 수 있다.', '여왕님은 지금 훈련 중이다.', '……달이 보고 싶다.'],
    mimic: ['짠!', '오늘은 몇 명 놀래킬까요?', '상자 안이 제일 편해요.'],
    ghost: ['등불이 꺼지지 않게 지킬게요.', '조용한 밤이 좋아요.', '마왕님 그림자가 따뜻해요.'],
    orc: ['배고프다!', '도끼 갈았다!', '밥 맛있었다! 또 먹고 싶다!'],
    goblin: ['나사 하나만 더!', '설계도 백 장째예요!', '함정은 예술이에요!'],
    dryad: ['새싹이 났어요.', '흙이 촉촉해요.', '꽃 냄새 맡아 보실래요?'],
    undine: ['물 온도 좋아요.', '흐르는 대로 사는 게 좋아요.', '오늘 온천 손님이 많았어요.'],
    salamander: ['불 좋아!', '대장간이 제일 시원해! 아니, 뜨거워!', '누가 내 화로 건드렸어!'],
    arachne: ['실이 곱게 나왔어요.', '치수 재실래요?', '새 무늬를 생각 중이에요.'],
    dullahan: ['머리 위치 괜찮아요?', '오늘은 아무도 안 데려갔어요.', '조용한 게 좋아요.'],
    lich: ['정숙.', '책은 제자리에.', '오늘 새로운 지식을 얻었습니다.'],
    minotaur: ['저, 저기……', '미궁 순찰 끝났어요.', '머, 멋있다고요? 제가요?'],
    kitsune: ['후후.', '여우불 예쁘죠?', '마왕님 마음, 다 보여요.'],
    oni: ['한잔 할까!', '씨름 상대 없나!', '하하! 좋은 날이다!'],
    gargoyle: ['……파수 중.', '……이상 없음.', '……마왕, 왔나.'],
    mushroom: ['쿨……', '수프 드실래요……', '졸려요……'],
    mermaid: ['♪', '노래 들으실래요?', '호수 물이 맑아요.'],
    imp: ['심부름 주세요!', '헤헤!', '뭐든 가져올게요!'],
    cyclops: ['쇠가 잘 달궈졌다.', '망치 소리 좋지?', '날 하나 세웠다.'],
    banshee: ['……♪', '오늘은 조금 덜 슬퍼요.', '마왕님 목소리가 좋아요.'],
    chimera: ['사냥 가자!', '냄새 좋다!', '세 개의 심장이 다 뛰어!'],
    succubus: ['후후, 왔어요?', '오늘 꿈은 뭘로 할까요?', '마왕님 피곤해 보여요. 재워 드릴까요?'],
  };
  const GREET = {
    slime: '말랑 슬라임이에요! 뭐든 날라요!', skelknight: '녹슨 검이나마 바치겠습니다.', harpy: '정찰이라면 맡겨 줘요! 수다도요!', lamia: '여기 따뜻해 보여서 왔어요.', dragonkid: '용기사님 계신 곳이죠? 받아 주세요!',
    butler: '살림은 제게 맡기십시오. 완벽하게.', golem: '……일한다.', witchapprentice: '스, 스승님이 여기 계시다고 해서……!', werewolf: '여왕님의 명으로 왔다.', mimic: '짠! 보물…… 아니고 저예요!',
    ghost: '길을 잃은 건 아니에요. 찾아온 거예요.', orc: '밥 주면 싸운다!', goblin: '함정 만들 곳 있어요? 많이요?', dryad: '흙이 좋아 보여서요.', undine: '온천 있나요?',
    salamander: '화로 어디야! 불 좀 지필게!', arachne: '옷이 낡으셨네요. 지어 드릴게요.', dullahan: '죽음이 아니라, 일하러 왔어요.', lich: '서고가 있다고 들었습니다.', minotaur: '저, 저…… 미궁 지기 필요하세요?',
    kitsune: '후후, 재미있는 던전이네요.', oni: '술 있나! 싸움 있나!', gargoyle: '……문, 지킨다.', mushroom: '쿨…… 여기 습해서 좋아요……', mermaid: '호수가 있다길래요.',
    imp: '심부름꾼 필요하죠? 그쵸?', cyclops: '모루 둘 곳 있나.', banshee: '……노래해도 될까요.', chimera: '사냥감 많다며!', succubus: '마왕님 꿈이 맛있어 보여서요.',
  };
  const HERO_LINE = { // [등장, 쓰러짐, 설득됨]
    rookie: ['첫 던전이다! 가자!', '아직…… 시작도 안 했는데…….', '……여기 사람들, 나쁘지 않네. 검, 맡길게.'],
    thief: ['보물 냄새가 나는데?', '칫, 함정이 너무 많잖아…….', '훔칠 건 다 훔쳤어. 이번엔 마음을.'],
    nun: ['신이시여, 저희를 지켜 주소서.', '기도가…… 닿지 않아…….', '이곳에도 신의 사랑이 있네요. 치유는 제가 할게요.'],
    elemental: ['원소의 이름으로!', '마력이…… 바닥났어…….', '서고가 대단하네요. 여기서 연구해도 될까요?'],
    elfarcher: ['바람이 탁하군.', '숲으로…… 돌아가고 싶어…….', '정원이 있다니. 화살은 이제 이쪽으로 겨눌게요.'],
    paladin: ['방패 앞으로!', '신념이…… 꺾이다니…….', '지켜야 할 것이 여기에도 있군요.'],
    assassin: ['표적 확인.', '……실패.', '새 의뢰인은 당신이군요.'],
    explorer: ['지도에 없는 길이다! 신난다!', '보물이…… 저기 있었는데…….', '이 던전 전체가 보물이네요!'],
    royalknight: ['왕명을 받들어!', '폐하…… 면목 없습니다…….', '제 새 주군은 여기 계시는군요.'],
    monk: ['수행의 일환이다!', '아직…… 수행이 부족해…….', '마음의 수행이 여기에 있었군.'],
    alchemist: ['좋은 재료가 있겠는데?', '배합을…… 잘못했나…….', '연구실 좀 빌려도 돼요? 대신 폭탄 만들어 줄게요.'],
    bard: ['오늘의 노래는 영웅담이다!', '마지막 소절을…… 못 불렀네…….', '이 던전의 노래를 짓고 싶어졌어요.'],
    tamer: ['가자, 얘들아!', '얘들아…… 도망쳐…….', ''], hunter: ['사냥 시작.', '……물러난다.', ''], archsage: ['흥미롭군요.', '계산 밖이에요…….', ''],
    inquisitor: ['정화한다!', '불꽃이…… 꺼진다…….', ''], saint: ['모두에게 축복을.', '이것도…… 신의 뜻인가요…….', ''], holysword: ['성검이여, 빛나라!', '성검이…… 무거워…….', ''], wolf: ['아우우!', '깨갱…….', ''],
  };
  const GOAL_LINE = { k: '목표는 마왕의 목! 전원 돌격!', l: '보물고를 털고 빠진다. 욕심은 금물!', r: '갇힌 동료들을 구하러 간다!', s: '던전 구조를 살피고 돌아간다. 싸움은 피해.' };
  const MON_BARK = { // 역할별 [스킬, 쓰러짐, 처치]
    f: ['막는다!', '크윽…… 물러날게요…….', '다음!'], b: ['조준 완료.', '날개가…… 다쳤어…….', '명중!'], m: ['마력 해방!', '마력이…… 바닥…….', '흔적도 없이.'],
    s: ['괜찮아요, 버텨요!', '미안…… 먼저 빠질게요…….', '모두 무사하죠?'], w: ['영차!', '으앗, 쉬러 갈게요!', '해냈다!'],
  };
  const EXEC_BARK = {
    dragonknight: ['폐하의 앞을 막는 자, 베겠다!', '……폐하, 죄송합니다…….', '진홍의 검에 무릎 꿇어라.'],
    abysswitch: ['자, 터뜨려 볼까요?', '어머, 이건 계산 밖인데…….', '실험 성공!'],
    nightduchess: ['무례한 손님이군요.', '드레스가…… 찢어졌네요…….', '예법을 배우고 오시지요.'],
    beastqueen: ['하하! 덤벼!', '이 정도로…… 쓰러질 줄이야…….', '좋은 사냥이었어!'],
  };
  /* ================= 대사 자료 확장 (round 47) =================
     말투 카드(VOICE) — 자료 대사 고르기와 AI 프롬프트가 같이 쓴다. reg: hap 하십시오체 · yo 해요체 · ban 반말 · terse 끊어 말하기.
     [말 높이, 마왕 호칭, 말끝, 버릇, 자주 쓰는 말, 절대 안 하는 말] */
  const VOICE_RAW = {
    dragonknight: ['hap', '폐하', '…습니다 / …겠습니다. 짧게 끊는다', '폐하 앞에서 말이 막히면 「……」 뒤에 고쳐 말함, 「아닙니다」로 얼버무림', '검, 경계, 자리, 송구합니다, 면목', '애교, 반말, 「헤헤」, 장황한 감정 고백'],
    abysswitch: ['yo', '폐하', '…거든요 / …잖아요 / …랄까요', '「어머」, 위험한 일을 「조금요」라고 줄여 말함', '실험, 계산, 마력, 작품, 폭발', '겸손한 사과, 하십시오체, 수줍은 말더듬'],
    nightduchess: ['hap', '폐하', '…지요 / …하시지요 / …입니다', '숫자와 예법으로 감정을 돌려 말함', '장부, 금화, 예법, 홍차, 이자', '반말, 감탄사 남발, 「헐」 같은 속어'],
    beastqueen: ['ban', '폐하', '…지 / …거든 / …야. 거침없음', '「하하」로 웃음, 냄새·사냥으로 비유', '사냥, 무리, 이빨, 냄새, 애들', '존댓말, 돌려 말하기, 우는소리'],
    slime: ['yo', '마왕님', '…요. 짧고 둥글게', '몸 상태(묽음, 동그람)로 기분을 말함', '말랑, 나르기, 삼키기, 반짝', '어려운 말, 하십시오체, 냉소'],
    skelknight: ['hap', '주군', '…습니다 / …지요', '옛 왕국과 기사도를 끌어옴', '맹세, 기사도, 깃발, 갑옷, 영광', '반말, 속어, 경박한 농담'],
    harpy: ['yo', '마왕님', '…요 / …래요. 말이 빠름', '「있잖아요」로 시작하는 소문 얘기', '소문, 하늘, 바람, 깃털, 소식', '하십시오체, 무거운 철학'],
    lamia: ['yo', '마왕님', '…요. 느릿하게', '「음……」으로 뜸을 들임, 체온·따뜻함 얘기', '따뜻한 곳, 꼬리, 감기, 늪, 비늘', '서두르는 말, 하십시오체'],
    dragonkid: ['yo', '마왕님', '…요. 성실하고 곧음', '용기사를 「용기사님」이라 부르며 동경', '불꽃, 훈련, 자세, 날개, 용기사님', '반말, 비꼼, 유아적인 떼쓰기'],
    butler: ['hap', '마왕님', '…습니다 / …드리겠습니다', '일정과 치수를 숫자로 말함', '일정, 은식기, 먼지, 찻잔, 완벽', '반말, 엉성한 말, 속어'],
    golem: ['terse', '마왕', '……단어. 단어. (아주 짧게 끊음)', '모든 문장 앞에 「……」', '돌, 일, 단단하다, 좋다, 지킨다', '긴 문장, 존댓말, 접속사'],
    witchapprentice: ['yo', '마왕님', '…요. 조금 허둥댐', '당황하면 첫 음절을 더듬음(「저, 저기」), 스승님 얘기', '물약, 주문, 스승님, 연습, 실험', '하십시오체, 자신만만한 허세'],
    werewolf: ['ban', '마왕', '…다. 짧은 평서문', '감정을 행동으로만 말함, 여왕님에게 충성', '냄새, 순찰, 발톱, 달, 여왕님', '존댓말(마왕에게), 수다, 애교'],
    mimic: ['yo', '마왕님', '…요. 장난스럽게', '「짠」, 상자·뚜껑 비유', '상자, 뚜껑, 보물, 놀래키기, 경첩', '하십시오체, 진지한 설교'],
    ghost: ['yo', '마왕님', '…요. 조용하고 부드럽게', '몸이 흐려짐·등불로 기분을 말함', '등불, 길, 그림자, 따뜻함, 영혼', '큰소리, 반말, 거친 말'],
    orc: ['ban', '마왕', '…다. 단순한 평서문', '먹는 얘기로 기분을 말함', '도끼, 고기, 밥, 씨름, 힘', '어려운 말, 존댓말, 비꼼'],
    goblin: ['yo', '마왕님', '…요. 빠르고 신남', '설계·부품·톱니 얘기로 빠짐', '설계도, 톱니, 함정, 연계, 부품', '하십시오체, 느린 말'],
    dryad: ['yo', '마왕님', '…요. 느리고 다정하게', '식물의 상태로 마음을 말함', '흙, 뿌리, 새싹, 꽃, 그늘', '거친 말, 반말, 서두름'],
    undine: ['yo', '마왕님', '…요. 차분하게', '물의 흐름에 빗대 말함', '물, 온천, 흐름, 맑음, 온도', '흥분한 말투, 반말'],
    salamander: ['ban', '마왕', '…야 / …잖아. 퉁명스러움', '화를 내다가 금방 누그러짐', '불, 화로, 쇠, 대장간, 불씨', '존댓말, 차분한 말투'],
    arachne: ['yo', '마왕님', '…요. 세련되고 여유 있게', '치수·옷감·무늬로 마음을 말함', '실, 치수, 본, 안감, 무늬', '반말, 거친 말'],
    dullahan: ['yo', '마왕님', '…요. 조용하고 담담하게', '자기 머리를 소재로 담담한 농담', '머리, 말(馬), 이름, 죽음, 꽃', '큰소리, 위협적인 말'],
    lich: ['hap', '마왕', '…습니다 / …지요. 간결하고 건조함', '규칙과 기록을 들먹임', '서고, 기록, 대출 기한, 고문서, 정숙', '감탄사, 반말, 수다'],
    minotaur: ['yo', '마왕님', '…요. 수줍게', '긴장하면 첫 음절을 더듬음, 문틀에 뿔이 걸림', '미궁, 순찰, 뿔, 문틀, 덩치', '하십시오체, 자랑'],
    kitsune: ['yo', '마왕님', '…요 / …죠. 여유롭게', '「후후」, 속내를 감추는 말장난', '여우불, 꼬리, 장난, 속내, 제단', '반말, 직설적인 고백(친밀도 낮을 때)'],
    oni: ['ban', '마왕', '…다 / …자. 호탕하게', '「하하」, 술과 씨름 얘기', '술, 씨름, 철퇴, 한판, 축하주', '존댓말, 소심한 말'],
    gargoyle: ['terse', '마왕', '……짧은 보고. 「이상 없음」식 끊김', '보고 형식으로만 말함', '파수, 이상 없음, 경계, 날개, 밤', '긴 문장, 감탄사'],
    mushroom: ['yo', '마왕님', '…요…… 졸린 듯 늘어짐', '문장 끝을 「……」로 흐림', '수프, 포자, 잠, 습함, 그늘', '큰소리, 빠른 말, 반말'],
    mermaid: ['yo', '마왕님', '…요. 노래하듯 부드럽게', '노래·박자 얘기', '노래, 가사, 호수, 박자, 자장가', '반말, 거친 말'],
    imp: ['yo', '마왕님', '…요. 약삭빠르게', '반쯤 거짓말인 척 너스레', '심부름, 금화, 꾀, 소문, 꼬리', '하십시오체, 진지한 맹세(친밀도 낮을 때)'],
    cyclops: ['ban', '마왕', '…다. 무뚝뚝한 장인', '망치·쇠로 비유', '쇠, 망치, 날, 모루, 이음새', '존댓말, 수다'],
    banshee: ['yo', '마왕님', '……요. 속삭이듯', '문장 앞을 「……」로 엶', '노래, 울음, 복도, 장송곡, 목소리', '큰소리, 느낌표, 반말'],
    chimera: ['ban', '마왕', '…야 / …다. 들뜬 야생', '머리 셋(사자·염소·뱀)의 의견 다툼', '사냥, 냄새, 심장, 머리 셋, 뼈', '존댓말, 어려운 말'],
    succubus: ['yo', '마왕님', '…요. 나른하고 장난스럽게', '「후후」, 꿈 얘기로 놀림', '꿈, 눈웃음, 장난, 연회장, 홀리기', '노골적·선정적 표현, 반말'],
  };
  const VOICE = {}; for (const k in VOICE_RAW) { const v = VOICE_RAW[k]; VOICE[k] = { reg: v[0], call: v[1], end: v[2], tic: v[3], voc: v[4], never: v[5] }; }
  const REG_KO = { hap: '하십시오체(…습니다, …지요). 반말 금지', yo: '해요체(…요). 반말·하십시오체를 섞지 않음', ban: '반말(…야, …어, …지, …다). 마왕에게도 반말', terse: '아주 짧게 끊는 반말(……돌. 좋다.)' };
  /* 상황별 대사 'tags|표정|대사'. tags(공백 구분, 모두 맞아야 나옴):
     g 선물 · lo/hi 기분 낮음/높음 · f0 낯섦(<25) f1/f2/f3 친밀도 25/55/85 이상 · win/bad/ko/hungry/unpaid 어젯밤 일 · boss 오늘 밤 칭호 용사
     new 들어온 지 이틀 · early/mid/late 캠페인 시기 · like/nolike 좋아하는 방 있음/없음 · rm<k> 배치 칸의 방 · ex:<code> 그 인물이 던전에 있음 · ex2 다른 동료 아무나({ally}) */
  const LN = {
    dragonknight: ['|serious|순찰 끝냈습니다. 입구 쪽 바위가 조금 무릅니다. 내일 보강하겠습니다.', 'lo|sad|……요즘 칼끝이 무겁습니다. 핑계는 대지 않겠습니다.', 'hi|smile|오늘은 몸이 가볍습니다. 누구든 와도 좋습니다.', 'f2|shy|폐하께서 부르시면 저는…… 아닙니다. 부르셨으니 왔습니다.', 'f3|shy|검 말고는 드릴 게 없어서 늘 송구합니다. ……그래도 받아 주시겠습니까.', 'win|smile|어젯밤 전과는 폐하의 설계 덕입니다. 저는 휘둘렀을 뿐입니다.', 'bad|angry|어젯밤 놓친 놈들, 얼굴 기억해 두었습니다. 다음은 없습니다.', 'ko|hurt|어젯밤 쓰러진 건 제 불찰입니다. 폐하 앞에서 두 번은 무릎 꿇지 않겠습니다.', 'boss|serious|오늘 밤 칭호 붙은 자가 온다고 들었습니다. 제 자리는 옥좌 앞입니다.', 'ex:dragonkid|smile|견습이 오늘 제 자세를 흉내 냈습니다. 제법이었습니다.', 'ex:beastqueen|angry|짐승 여왕이 또 훈련장을 어질렀습니다. ……같이 치우긴 했습니다.', 'rme|smile|훈련장 바닥을 새로 다졌습니다. 발이 덜 미끄러질 겁니다.', 'early|serious|던전이 아직 얕습니다. 그만큼 제가 깊이 서 있겠습니다.', 'late|serious|끝이 가까워 오는 게 느껴집니다. 마지막까지 곁에 있겠습니다.', 'mid|neutral|요즘 용사들 검술이 늘었습니다. 저도 손을 놓지 않겠습니다.', 'g|flustered|이, 이걸 제게 말입니까. ……칼집에 달고 다니겠습니다.', 'g f2|shy|폐하께 받은 건 전부 갑옷 안쪽에 넣어 둡니다. 비밀입니다.'],
    abysswitch: ['|smile|오늘은 아무것도 안 터뜨렸어요. 칭찬해 주셔도 돼요.', '|neutral|마력 샘 소리 들어 보셨어요? 밤에 들으면 꽤 운치 있거든요.', 'lo|sad|머리가 잘 안 돌아가요. 이런 날엔 실험을 쉬는 게 맞죠.', 'hi|happy|좋은 생각이 났어요. 위험하냐고요? 조금요. 아주 조금.', 'f2|smile|폐하랑 얘기하면 계산이 자꾸 틀려요. 이상하죠.', 'f3|shy|연구 노트 맨 뒷장은 보지 마세요. 폐하 얘기만 적혀 있거든요.', 'win|smile|어젯밤 번개 각도 보셨어요? 그건 작품이었어요.', 'bad|serious|함정 자리를 다시 짜 봐요. 같은 자리에 두 번 속는 바보는 없거든요.', 'ko|hurt|어젯밤 일은 잊어 주세요. 마녀도 가끔 넘어져요.', 'ex:witchapprentice|smile|제자가 오늘 물약 색을 맞혔어요. 냄새는 아직 엉망이지만요.', 'ex:lich|neutral|서고 리치가 또 연체 딱지를 붙였어요. 저한테만 엄격하다니까요.', 'rmi|happy|연구실 환기구를 하나 더 뚫었어요. 다음 폭발은 덜 시끄러울 거예요.', 'nolike|sad|연구실이 없으니 손이 심심해요. 방 하나만 내주시면 안 될까요.', 'late|serious|성검 얘기가 들려요. 그 빛, 한번 분해해 보고 싶네요.', 'early|smile|던전이 작으니까 오히려 좋아요. 실험할 자리가 많잖아요.', 'g|surprised|어머, 선물이요? 대가를 바라시는 거죠? ……아니에요? 그럼 그냥 받을게요.', 'g f2|shy|이건 실험 재료로 안 쓸게요. 약속해요.'],
    nightduchess: ['|neutral|오늘 장부는 맞았습니다. 맞지 않는 날이 드물어야 하는데 말이지요.', '|smile|폐하, 옷깃이 접혔습니다. 잠시만…… 됐습니다.', 'lo|serious|기분이 좋지 않은 날엔 말수를 줄이는 게 예의라 배웠습니다.', 'hi|smile|오늘은 홍차가 유난히 잘 우러났습니다. 한 잔 내 올까요?', 'f2|smile|폐하와의 대화는 셈이 필요 없어서 좋습니다.', 'f3|shy|……이런 말은 장부에 적지 않겠습니다. 폐하 곁이 편합니다.', 'win|smile|전리품 정리는 끝났습니다. 숫자가 아름다운 아침이군요.', 'bad|angry|도둑맞은 금화는 기억해 두겠습니다. 이자까지 받아 낼 생각입니다.', 'hungry|serious|굶는 이가 생겼습니다. 식당을 늘릴 예산은 제가 마련해 두지요.', 'unpaid|angry|급여를 거르는 주인에게 충성은 오래가지 않습니다. 다음엔 꼭 챙기시지요.', 'ex:butler|neutral|집사가 은식기를 또 닦았습니다. 하루 세 번은 과하다고 일렀는데요.', 'ex:succubus|serious|꿈결 그 아이에게 회의 중에 졸지 말라고 전해 주시겠습니까.', 'rma|smile|보물고 앞에 서 있으면 마음이 차분해집니다. 금화는 거짓말을 안 하니까요.', 'late|serious|끝이 가까워지면 다들 들뜹니다. 그럴수록 장부는 꼼꼼해야지요.', 'early|neutral|지금은 들어오는 것보다 나가는 게 많습니다. 처음엔 다 그렇지요.', 'g|surprised|……선물은 미리 말씀하고 주시는 겁니다. 답례를 준비할 시간이 필요하니까요.', 'g f2|smile|받겠습니다. 이건 장부 밖의 일로 해 두지요.'],
    beastqueen: ['|smile|오늘 바람 냄새 괜찮다. 밤에 손님 많겠는데.', '|neutral|애들 사냥 연습 시켰어. 다들 이빨이 근질근질하대.', 'lo|sad|오늘은 좀 가라앉네. 이럴 땐 그냥 옆에 앉아 있어 줘.', 'hi|happy|하하, 몸이 뜨겁다. 밤까지 못 기다리겠어.', 'f2|smile|폐하 냄새는 금방 알아. 무리 냄새랑 비슷하거든.', 'f3|shy|……너한테는 등을 보여도 안 불안해. 그게 무슨 뜻인지 알지?', 'win|happy|어젯밤 사냥 좋았지? 그 정도면 무리 전체가 배불러.', 'bad|angry|도망친 놈들 냄새 기억했어. 다시 오면 끝이야.', 'ko|hurt|어젯밤엔 내가 방심했어. 웃지 마. ……웃어도 돼, 폐하니까.', 'boss|happy|오늘 밤 거물이 온다며? 하하, 이빨 갈아 놔야지.', 'ex:werewolf|smile|은빛 그 녀석, 오늘 내 그림자까지 지키더라. 성실해서 탈이야.', 'ex:dragonknight|smile|용기사랑 팔씨름했어. 비겼다고 해 두자.', 'hungry|angry|애들이 배고프면 나도 성질나. 밥부터 챙겨 줘.', 'rme|happy|훈련장 좋다. 바닥에 발톱 자국 좀 남겨도 되지?', 'late|serious|성검 든 놈이 온다며. 그 냄새는 처음 맡아 보겠네.', 'g|happy|나한테? 하하, 이런 거 처음 받아 봐.', 'g f2|shy|……고마워. 목에 걸고 다닐게. 안 떨어지게.'],
    slime: ['|happy|오늘은 돌멩이 백 개 날랐어요. 하나도 안 삼켰어요.', '|smile|바닥이 미끄러우면 저 때문이에요. 미안해요.', 'lo|sad|몸이 좀 묽어졌어요. 기운이 없나 봐요.', 'hi|happy|탱글탱글한 날이에요. 이런 날은 뭐든 할 수 있어요.', 'f2|shy|마왕님 손은 따뜻해서 좀 녹을 것 같아요.', 'f3|happy|마왕님 옆에 있으면 모양이 예쁘게 잡혀요. 동그랗게요.', 'win|happy|어젯밤 떨어진 동전 다 주웠어요. 반짝반짝해요.', 'ko|hurt|어제 납작해졌는데 이제 다시 동그래요.', 'hungry|sad|배고프면 투명해져요. 지금 좀 투명하죠?', 'rmd|happy|식당 바닥은 제가 맡을게요. 흘린 건 전부 제 몫이에요.', 'g|happy|이거 삼키면 안 되는 거죠? 그럼 머리에 올려 둘게요.'],
    skelknight: ['|serious|성벽이 없어도 기사는 서 있을 수 있습니다.', '|neutral|옛 왕국에선 아침마다 깃발을 올렸습니다. 이곳엔 깃발 대신 주군이 계시지요.', 'lo|sad|뼈마디가 시립니다. 오래 서 있던 탓이겠지요.', 'hi|smile|오늘은 갑옷이 덜 삐걱입니다. 좋은 징조입니다.', 'f2|smile|주군을 모시니 잊었던 맹세가 다시 떠오릅니다.', 'f3|serious|두 번째 생은 덤이라 여겼는데, 이제는 덤이 아닙니다.', 'win|serious|어젯밤 적은 정정당당했습니다. 그래서 더 확실히 쓰러뜨렸지요.', 'bad|angry|등 뒤를 노리는 도적이라니. 기사도는 어디로 갔는지.', 'rmg|serious|경비실에 서면 옛 초소가 떠오릅니다.', 'ex:dullahan|neutral|목 없는 기사 공과 검을 겨뤘습니다. 머리를 어디 둘지 늘 고민하더군요.', 'g|surprised|기사에게 하사품이라니. 녹슬지 않게 간수하겠습니다.'],
    harpy: ['|happy|있잖아요, 지상에선 요즘 마왕님 소문이 돌아요. 무섭고 예쁘대요.', '|neutral|입구 위 하늘이 흐려요. 오늘 밤엔 횃불 든 사람이 많을 거예요.', 'lo|sad|깃이 몇 개 빠졌어요. 별일 아닌데 그냥 속상해요.', 'hi|happy|오늘 소식 세 개, 아니 네 개예요. 어디부터 할까요?', 'f2|smile|마왕님한테만 하는 얘긴데요, 사실 저 높은 데 무서워요. 농담이에요.', 'f3|shy|날 수 있어도 마왕님 옆에 내려앉는 게 제일 좋아요.', 'win|happy|어젯밤 도망친 사람이 하나도 없어요. 소문 날 거리도 없겠네요.', 'bad|serious|도망친 놈이 길드에 함정 자리를 떠벌릴 거예요. 자리 좀 바꿔요.', 'ex:imp|smile|임프랑 소문 바꿔 들었어요. 걔 소문은 반은 지어낸 거예요.', 'rmn|happy|정원 위를 날면 꽃가루가 깃털에 묻어요. 냄새 좋죠?', 'g|happy|반짝이는 거다. 둥지 제일 잘 보이는 데 둘게요.'],
    lamia: ['|neutral|음…… 오늘은 좀 천천히 움직일게요. 바닥이 차서요.', '|smile|꼬리 끝이 따뜻하면 기분이 좋은 거예요. 지금 따뜻해요.', 'lo|sad|늪이 그리운 날이 있어요. 오늘이 그래요.', 'hi|smile|볕 드는 바위가 있으면 하루 종일 누워 있을래요.', 'f2|shy|마왕님 옆은 늘 적당히 따뜻해요. 감고 싶어질 만큼요.', 'f3|smile|한번 감으면 안 놓는다는 말, 마왕님한텐 좋은 뜻이에요.', 'win|smile|어젯밤 하나 꽉 감았어요. 금방 조용해지던걸요.', 'rmj|happy|온천 옆자리는 최고예요. 비늘이 반들반들해져요.', 'nolike|sad|따뜻한 물이 없으니 몸이 굳어요. 온천 하나만요.', 'g|smile|고마워요. 이건 꼬리에 감아 둘게요. 잃어버리지 않게.'],
    dragonkid: ['|happy|오늘 불꽃이 두 뼘이나 나갔어요. 재 보셨어요?', '|neutral|용기사님처럼 서 보려는데 다리가 자꾸 떨려요.', 'lo|sad|오늘은 불이 안 나와요. 연기만 나와요.', 'hi|happy|날개가 근질근질해요. 곧 날 수 있을 것 같아요.', 'f2|smile|마왕님 앞에선 떨지 않기로 했어요. 지금은 조금 떨어요.', 'f3|shy|언젠가 마왕님 곁을 지키는 기사가 될 거예요. 진짜로요.', 'win|happy|어젯밤 한 명은 제가 쓰러뜨렸어요. 용기사님이 고개를 끄덕였어요.', 'ko|hurt|어제 넘어졌어요. 그래도 칼은 놓지 않았어요.', 'ex:dragonknight|smile|용기사님 검 닦는 걸 도왔어요. 무거워서 혼났어요.', 'rme|happy|훈련장 허수아비를 오늘 세 개 태웠어요. 다시 세워 둘게요.', 'g|happy|제 보물 상자에 넣을래요. 용들이 다 그러거든요.'],
    butler: ['|neutral|오늘 일정은 세 가지입니다. 식사, 휴식, 그리고 휴식을 거르지 않기.', '|serious|마왕님, 망토 자락이 2센티 깁니다. 오늘 밤 안에 고쳐 두겠습니다.', 'lo|sad|오늘은 은식기에 얼룩이 남았습니다. 제 마음에도요.', 'hi|smile|모든 방의 먼지를 털었습니다. 기분 좋은 아침입니다.', 'f2|smile|마왕님 찻잔 온도는 이제 손끝으로도 압니다.', 'f3|shy|완벽하지 않은 것도 아름다울 수 있다는 걸 마왕님을 보며 배웠습니다.', 'win|smile|전리품 목록은 정리해 두었습니다. 얼룩진 것은 따로 세탁 중입니다.', 'hungry|serious|식사가 모자랐습니다. 집사로서 면목이 없습니다.', 'ex:nightduchess|neutral|여공작께서 은식기 닦는 횟수를 줄이라 하셨습니다. 줄일 생각은 없습니다.', 'rmp|happy|연회장 촛대를 새로 맞췄습니다. 오늘 밤 불빛이 고울 겁니다.', 'g|surprised|저에게 말씀입니까. 받는 쪽은 익숙지 않아서…… 잠시만 기다려 주십시오.'],
    golem: ['|neutral|……바위. 단단하다. 좋다.', '|neutral|……오늘. 많이 팠다.', 'lo|sad|……금 갔다. 조금.', 'hi|smile|……햇빛, 없다. 그래도 좋다.', 'f2|smile|……마왕. 작다. 지킨다.', 'f3|shy|……마왕 옆. 따뜻하다. 돌인데.', 'win|smile|……밟았다. 끝.', 'ko|hurt|……부서졌다. 붙였다. 괜찮다.', 'ex:gargoyle|neutral|……날개 돌. 말 없다. 나도. 좋다.', 'g|surprised|……나. 주나. ……가슴에. 넣는다.'],
    witchapprentice: ['|flustered|저, 저기, 연구실 문에 탄 자국은 제가 아니에요. 반쯤만요.', '|smile|물약 거품이 보라색으로 나왔어요. 스승님 말로는 이게 정답이래요.', 'lo|sad|오늘은 주문이 혀에서 꼬였어요. 다시 연습할게요.', 'hi|happy|오늘은 한 번에 성공했어요. 믿기지 않아서 세 번 확인했어요.', 'f2|shy|마왕님이 웃으시면 외운 주문이 다 날아가요. 곤란해요.', 'f3|smile|언젠가 스승님 제자 말고 제 이름으로 불리는 마녀가 될게요. 마왕님 곁에서요.', 'win|happy|어젯밤 얼음 화살 맞힌 거 보셨어요? 조준 연습한 보람이 있었어요.', 'ex:abysswitch|flustered|스승님이 제 앞머리가 또 그을렸다고 웃으셨어요.', 'rmi|happy|연구실 선반을 정리했어요. 폭발하지 않는 순서로요.', 'g|flustered|이, 이런 걸 받아도 돼요? 스승님한텐 비밀로 할게요.'],
    werewolf: ['|neutral|입구 쪽 냄새 확인했다. 아직 조용하다.', '|serious|발톱 손질 끝났다. 언제든.', 'lo|sad|오늘은 달 냄새가 안 난다. 기운이 없다.', 'hi|smile|몸이 가볍다. 오늘 밤엔 달리고 싶다.', 'f2|smile|마왕 냄새는 무리 냄새다. 이제는 그렇다.', 'f3|shy|……여왕님만큼. 그 말이다. 더는 안 한다.', 'win|smile|어젯밤 한 놈도 못 빠져나갔다. 좋은 사냥이었다.', 'bad|angry|놓친 놈이 있다. 다음엔 목덜미를 문다.', 'ex:beastqueen|serious|여왕님이 오늘 웃었다. 그럼 된 거다.', 'g|surprised|……나한테? 냄새 좋다. 간직한다.'],
    mimic: ['|happy|오늘은 뚜껑에 금칠을 했어요. 더 맛있어 보이죠?', '|smile|짠, 하고 열었는데 아무도 안 놀랐어요. 마왕님이라도 놀라 줄래요?', 'lo|sad|오늘은 뚜껑이 무거워요. 그냥 닫혀 있고 싶어요.', 'hi|happy|오늘 밤엔 누가 절 열지 벌써 설레요.', 'f2|smile|마왕님 앞에서는 입 다물고 있기 힘들어요. 상자인데도요.', 'f3|shy|진짜 보물은 안에 안 넣어요. 마왕님은 밖에 계시니까.', 'win|happy|어젯밤 도둑 하나를 덥석 물었어요. 표정이 최고였어요.', 'ex:goblin|smile|고블린이 경첩에 기름칠을 해 줬어요. 소리 없이 열려요.', 'rma|happy|보물고에 있으면 아무도 절 못 알아봐요. 완벽한 위장이죠.', 'g|happy|선물은 제 안에 넣어 둘게요. 제일 안쪽에.'],
    ghost: ['|neutral|등불 기름을 갈았어요. 오늘 밤엔 길을 잃는 사람이 없을 거예요.', '|smile|복도 끝 찬바람은 제가 아니에요. 정말이에요.', 'lo|sad|오늘은 몸이 자꾸 흐려져요. 마음이 무거운가 봐요.', 'hi|smile|오늘은 등불이 유난히 밝아요. 마왕님 덕분일까요.', 'f2|shy|마왕님 그림자에 잠깐 들어가 있어도 될까요. 거기가 제일 따뜻해서요.', 'f3|smile|오래 떠돌았는데, 이제 돌아올 곳이 생겼어요.', 'win|neutral|어젯밤 쓰러진 용사들도 나가는 길은 잘 찾았을 거예요.', 'ex:banshee|smile|반시 언니 노래에 등불이 흔들렸어요. 슬픈데 예뻤어요.', 'rmo|neutral|제단 촛불은 꺼뜨리지 않을게요. 제 일이니까요.', 'g|surprised|손에 잡히는 선물이라니. 등불 옆에 두고 매일 볼게요.'],
    orc: ['|happy|도끼 날 세웠다. 오늘은 뭐든 쪼갠다.', '|neutral|식당 고기가 어제보다 두껍다. 마왕 덕이다.', 'lo|sad|배가 고프면 도끼도 무겁다.', 'hi|happy|힘이 넘친다. 씨름할 사람?', 'f2|smile|마왕은 작아도 세다. 나는 그런 게 좋다.', 'f3|shy|……마왕 옆에선 도끼를 내려놓게 된다. 이상하다.', 'win|happy|어젯밤 잘 싸웠다. 오늘 고기는 두 배다. 그렇지?', 'hungry|angry|어제 굶었다. 화났다. 식당 늘려라.', 'ex:oni|happy|오니랑 술 마셨다. 졌다. 다음엔 이긴다.', 'rmd|happy|식당이 가깝다. 행복하다.', 'g|happy|먹는 거냐? ……아니야? 그래도 좋다. 고맙다.'],
    goblin: ['|happy|새 설계도 나왔어요. 바닥이 꺼지면서 옆에서 화살이 나오는 거예요.', '|neutral|함정 톱니 하나가 헐거워요. 오늘 안에 조여 둘게요.', 'lo|sad|설계가 꽉 막혔어요. 머리를 좀 식혀야겠어요.', 'hi|happy|오늘은 손이 빨라요. 뭐든 만들어 드릴게요.', 'f2|smile|마왕님은 제 설계도를 끝까지 봐 줘서 좋아요.', 'f3|shy|함정 말고 마왕님 드릴 걸 하나 만들고 있어요. 아직 비밀이에요.', 'win|happy|어젯밤 연계 터진 거 보셨죠? 계산대로였어요.', 'bad|serious|도둑이 함정을 풀었어요. 못 풀게 덮개를 바꿀게요.', 'rmf|happy|대장간 옆이라 부품 구하기 쉬워요. 최고의 자리예요.', 'g|surprised|이거 분해해도 돼요? 농담이에요. 아껴 쓸게요.'],
    dryad: ['|smile|이끼가 새로 올라왔어요. 만져 보면 폭신해요.', '|neutral|흙이 숨 쉬는 소리가 들려요. 조용히 있으면 마왕님도 들릴 거예요.', 'lo|sad|잎 끝이 말랐어요. 저도 조금 지쳤나 봐요.', 'hi|happy|꽃이 한꺼번에 피었어요. 좋은 일이 있으려나 봐요.', 'f2|shy|마왕님 옆에 있으면 뿌리가 편해요.', 'f3|smile|마왕님을 닮은 꽃을 하나 키우고 있어요. 곧 필 거예요.', 'hungry|sad|먹을 게 모자라요. 정원을 조금 더 넓혀 주세요.', 'ex:mushroom|smile|버섯이 제 그늘에서 또 잠들었어요. 깨우지 않았어요.', 'rmn|happy|정원에 있으면 시간이 천천히 가요. 좋은 뜻이에요.', 'g|happy|고마워요. 이건 흙에 묻지 않고 곁에 둘게요.'],
    undine: ['|neutral|온천 온도는 딱 맞춰 뒀어요. 들어가실래요?', '|smile|물은 낮은 데로 흘러요. 저도 그렇게 사는 게 편해요.', 'lo|sad|물이 탁해졌어요. 제 마음이 그런가 봐요.', 'hi|smile|오늘은 물이 유난히 맑아요. 바닥까지 다 보여요.', 'f2|smile|마왕님 어깨가 굳어 있어요. 온천에 오세요. 풀어 드릴게요.', 'f3|shy|흐르는 게 좋다고 했는데, 마왕님 곁에서는 머물고 싶어요.', 'win|neutral|어젯밤 다친 이들은 다 씻겨 줬어요.', 'ex:mermaid|smile|인어가 온천에서 노래를 불렀어요. 물이 따라 흔들렸어요.', 'nolike|sad|따뜻한 물이 없으면 제가 할 일이 없어요.', 'g|smile|고마워요. 물에 젖지 않는 곳에 둘게요. 저한텐 드문 자리예요.'],
    salamander: ['|angry|누가 화로 문 열어 놨어? 불 식으면 내가 다시 피워야 하잖아.', '|happy|불 색 좀 봐. 오늘 이 정도면 쇠도 웃으면서 녹아.', 'lo|sad|불씨가 작아. 나도 오늘은 좀 꺼진 것 같아.', 'hi|happy|하, 오늘 불 최고다. 뭐든 갖고 와.', 'f2|smile|마왕은 내 불 옆에 와도 안 피하더라. 그게 좋아.', 'f3|shy|……내 불이 너를 데우면 좋겠어. 태우지 말고.', 'win|happy|어젯밤 불맛 제대로 보여 줬지?', 'ex:cyclops|neutral|외눈이가 또 불 온도로 잔소리했어. 맞는 말이라 더 짜증 나.', 'rmf|happy|대장간이 내 자리야. 여기선 아무도 날 못 이겨.', 'g|surprised|어, 이거 나 주는 거야? ……안 태울게. 진짜로.'],
    arachne: ['|neutral|새 망토 본을 떴어요. 어깨선을 조금 더 날카롭게 했어요.', '|smile|치수는 눈으로도 재요. 마왕님, 지난번보다 조금 마르셨어요.', 'lo|sad|실이 자꾸 엉켜요. 손보다 마음이 엉킨 거겠죠.', 'hi|happy|오늘은 실이 비단처럼 나와요. 뭘 지어 드릴까요?', 'f2|smile|마왕님 옷은 제 실로만 짓고 싶어요. 욕심이죠.', 'f3|shy|안감에 몰래 무늬를 넣었어요. 마왕님만 아는 무늬로요.', 'win|neutral|어젯밤 거미줄에 셋이 걸렸어요. 수선할 데가 많네요.', 'ex:nightduchess|smile|여공작님 드레스 자락을 고쳐 드렸어요. 칭찬은 없었지만 웃으셨어요.', 'rmp|happy|연회장 장식 천은 제가 짰어요. 불빛에 비치면 더 예뻐요.', 'g|surprised|어머, 제가 받는 쪽이 되다니. 이걸로 뭘 지을지 벌써 떠올라요.'],
    dullahan: ['|neutral|머리를 어느 쪽에 둘지 고민하다 아침이 다 갔어요.', '|smile|죽음의 사자라고 다 무서운 건 아니에요. 저는 꽃도 좋아해요.', 'lo|sad|오늘은 머리가 무거워요. 손에 들고 있는데도요.', 'hi|smile|말이 오늘 기분이 좋대요. 저도요.', 'f2|shy|마왕님은 제 얼굴을 똑바로 봐 주셔서 좋아요. 다들 몸 쪽만 보거든요.', 'f3|smile|데려갈 이름 목록에서 마왕님 이름은 지웠어요. 영원히요.', 'win|serious|어젯밤 이름 몇 개를 적었어요. 오래 기억하진 않을 거예요.', 'ex:skelknight|smile|해골 기사님이 대련 끝나고 제 머리를 주워 줬어요. 신사예요.', 'g|shy|두 손으로 받을게요. ……머리는 잠깐 내려놓고요.'],
    lich: ['|neutral|오늘 정리한 책은 백 권입니다. 내일은 백한 권이지요.', '|serious|서고에서 음식은 금지입니다. 마왕이라도 예외는 없습니다.', 'lo|sad|오래 산다는 건 잊는 것보다 기억하는 게 많다는 뜻이지요. 오늘은 그게 무겁습니다.', 'hi|smile|흥미로운 고문서를 찾았습니다. 읽어 드릴까요. 짧게.', 'f2|smile|마왕과의 대화는 기록해 둘 가치가 있습니다.', 'f3|shy|……마왕에게는 대출 기한을 두지 않겠습니다. 무엇이든.', 'win|neutral|어젯밤 용사들의 전술은 기록해 두었습니다. 참고 문헌이 늘었군요.', 'ex:abysswitch|serious|심연의 마녀가 빌린 책 세 권이 아직 안 돌아왔습니다. 전해 주십시오.', 'rml|smile|서고는 조용합니다. 그게 이 방의 가장 큰 장점이지요.', 'g|surprised|선물이라. 목록에 없는 것을 받는 건 오랜만입니다.'],
    minotaur: ['|flustered|저, 저기…… 미궁 모퉁이 하나를 새로 외웠어요.', '|neutral|순찰 돌았어요. 길 잃은 건 저 말고 아무도 없었어요.', 'lo|sad|뿔이 문틀에 걸렸어요. 세 번이나요.', 'hi|smile|오늘은 문틀에 한 번도 안 걸렸어요. 좋은 날이에요.', 'f2|shy|마, 마왕님이 멋있다고 해 주신 거…… 아직 기억하고 있어요.', 'f3|smile|덩치 큰 게 싫었는데, 마왕님을 가려 드릴 수 있으니 이젠 좋아요.', 'win|happy|어젯밤 한 명 들이받았어요. 미, 미안하진 않아요.', 'rmg|neutral|경비실은 좁지만 편해요. 벽이 등에 닿아서요.', 'g|flustered|이, 이걸 저한테요? 부서지지 않게 살살 들게요.'],
    kitsune: ['|smile|후후, 오늘 무슨 생각 하셨는지 맞혀 볼까요?', '|neutral|여우불이 오늘따라 낮게 떠요. 밤엔 바람이 바뀌겠어요.', 'lo|sad|꼬리 하나가 축 처졌어요. 아홉 개 중 하나라 티는 안 나지만요.', 'hi|smile|기분이 좋으면 꼬리가 다 펴져요. 세어 보실래요?', 'f2|smile|마왕님 속이 다 보인다고 했죠. 사실 반쯤은 허세예요.', 'f3|shy|……이번 건 속임수가 아니에요. 믿어 주실래요?', 'win|smile|어젯밤 용사 둘이 서로를 베게 만들었어요. 여우 장난이죠.', 'ex:succubus|smile|서큐버스랑 누가 더 잘 홀리나 내기했어요. 결과는 비밀이에요.', 'rmo|neutral|제단 앞에선 마음이 맑아져요. 무녀라서 그런가 봐요.', 'g|surprised|어머, 여우를 놀라게 하시다니. 이건 진짜로 놀란 거예요.'],
    oni: ['|happy|이봐 마왕, 한잔하자. 낮술이 제일 맛있어.', '|smile|오늘 씨름 다섯 판 이겼다. 상대가 다 도망갔지만.', 'lo|sad|술맛이 없는 날도 있구나. 처음 알았다.', 'hi|happy|하하, 오늘은 산이라도 들겠다.', 'f2|smile|마왕은 술 상대로도 싸움 상대로도 괜찮아. 드문 일이지.', 'f3|shy|……취해서 하는 말 아니다. 너 좋다고.', 'win|happy|어젯밤 철퇴가 신났다. 오늘은 축하주다.', 'bad|angry|도망간 놈들 등짝에 철퇴 자국 하나씩 남겨 줬어야 했는데.', 'ex:orc|happy|오크랑 술 겨뤘다. 내가 이겼지. 당연히.', 'rmp|happy|연회장은 내 무대다. 오늘 밤에도 마실 거다.', 'g|happy|하하, 선물? 그럼 오늘 술은 내가 산다.'],
    gargoyle: ['|neutral|……이상 없음.', '|serious|……입구. 바람 바뀜. 경계 중.', 'lo|sad|……날개 무거움. 그래도 이상 없음.', 'hi|smile|……오늘. 별 소리 들림. 좋음.', 'f2|smile|……마왕 지나갈 때. 고개 숙임. 습관 됨.', 'f3|shy|……밤새 지킴. 마왕 잠. 편하게.', 'win|serious|……어젯밤. 통과자 없음.', 'ex:golem|neutral|……골렘. 조용함. 좋은 동료.', 'g|surprised|……받음. 날개 밑. 보관.'],
    mushroom: ['|neutral|……수프 끓여 놨어요…… 식기 전에……', '|smile|포자가 고르게 퍼졌어요…… 내일은 버섯 풍년이에요……', 'lo|sad|……오늘은 더 졸려요…… 조금만 누울게요……', 'hi|smile|오늘은 눈이 반쯤 떠져요…… 드문 일이에요……', 'f2|shy|마왕님 옆에서 졸면…… 꿈이 좋아요……', 'f3|smile|……마왕님 그늘이 제일 습하고 편해요…… 칭찬이에요……', 'hungry|sad|먹을 게 모자라요…… 제가 더 키울게요……', 'ex:dryad|smile|정령님 그늘에서 잤어요…… 또요……', 'rmn|happy|정원 흙이 촉촉해요…… 여기 살래요……', 'g|surprised|……어, 선물이요…… 잠이 확 깼어요…… 잠깐만요……'],
    mermaid: ['|smile|새 노래를 지었어요. 아직 가사가 반밖에 없어요.', '|neutral|호수 바닥에 빛나는 돌이 있어요. 언젠가 보여 드릴게요.', 'lo|sad|목이 잠겼어요. 오늘은 흥얼거리기만 할게요.', 'hi|happy|오늘은 노래가 저절로 나와요. 들어 보실래요?', 'f2|shy|마왕님 발소리에 맞춰 박자를 세는 버릇이 생겼어요.', 'f3|smile|마왕님 노래를 하나 만들었어요. 마왕님한테만 불러 드릴 거예요.', 'win|smile|어젯밤 다친 이들한테 자장가를 불러 줬어요. 금방 잠들었어요.', 'ex:undine|smile|운디네가 물결로 반주를 해 줬어요. 둘이 하니 더 좋았어요.', 'nolike|sad|물이 없으니 목소리가 말라요. 호수나 온천 하나만요.', 'g|happy|고마워요. 이 선물로 노래 한 소절을 더 지을게요.'],
    imp: ['|smile|심부름 세 개 끝냈어요. 하나는 시키신 적 없는 거예요.', '|neutral|금화 냄새는 멀리서도 나요. 보물고 문은 꽉 잠그세요.', 'lo|sad|오늘은 다들 저만 찾아요. 꼬리가 다 저려요.', 'hi|happy|오늘은 꾀가 술술 나와요. 뭐든 시켜 보세요.', 'f2|smile|마왕님 심부름은 공짜로 해 드릴게요. 가끔은요.', 'f3|shy|사실 심부름이 좋은 게 아니라 마왕님이 부르시는 게 좋은 거예요.', 'win|happy|어젯밤 떨어진 금화 몇 닢은…… 다 보물고에 넣었어요. 정말로요.', 'ex:harpy|smile|하피가 제 소문을 냈대요. 반은 사실이에요.', 'g|surprised|저한테요? 훔친 게 아니라 받은 거라니, 기분이 묘하네요.'],
    cyclops: ['|neutral|쇠가 잘 먹었다. 오늘은 날이 곧게 섰다.', '|serious|망치는 거짓말을 안 한다. 두드린 만큼 나온다.', 'lo|sad|오늘은 손이 떨린다. 망치를 좀 쉬어야겠다.', 'hi|smile|불도 쇠도 좋다. 이런 날은 드물다.', 'f2|smile|마왕 갑옷 이음새, 내가 다시 봤다. 이제 안 샌다.', 'f3|shy|……하나뿐인 눈으로 늘 보는 건 너다. 그게 다다.', 'win|smile|어젯밤 내 날이 제 몫을 했다. 장인으로서 만족한다.', 'ex:salamander|neutral|불지기 녀석, 온도는 잘 맞춘다. 입이 험해서 그렇지.', 'rmf|happy|대장간 모루 소리가 좋다. 여기가 내 자리다.', 'g|surprised|……선물이라. 쇠 말고 이런 걸 받는군. 고맙다.'],
    banshee: ['|neutral|……오늘은 울지 않고 노래만 했어요.', '|smile|조용한 복도가 좋아요. 제 목소리가 멀리 가니까요.', 'lo|sad|……오늘은 노래가 자꾸 울음이 돼요.', 'hi|smile|……슬프지 않은 노래도 한 소절 불러 봤어요.', 'f2|shy|마왕님이 제 목소리가 좋다고 하셔서…… 그 뒤로 덜 슬퍼요.', 'f3|smile|……마왕님 곁에선 장송곡을 안 불러도 돼요.', 'win|serious|……어젯밤 제 노래에 다들 얼어붙었어요. 그게 제 일이에요.', 'ex:ghost|smile|등불 유령이 제 노래를 듣고 불을 밝혀 줬어요.', 'g|surprised|……저한테 선물을요? 오늘은 기쁜 노래를 불러 볼게요.'],
    chimera: ['|happy|냄새 좋다. 오늘은 사냥하는 날이다.', '|neutral|머리 셋이 다 딴소리를 해. 오늘은 사자 쪽이 이겼어.', 'lo|sad|오늘은 셋 다 조용해. 이런 날은 처음이야.', 'hi|happy|심장 셋이 다 뛰어. 빨리 밤이 왔으면.', 'f2|smile|마왕은 사냥감 냄새가 아니야. 무리 냄새야.', 'f3|shy|……셋 다 너를 좋아해. 처음으로 의견이 맞았어.', 'win|happy|어젯밤 사냥 최고였어. 뼈까지 깨끗하게.', 'ex:beastqueen|smile|여왕이 내 사냥 솜씨를 칭찬했어. 머리 셋이 다 신났어.', 'rme|happy|훈련장에서 뛰면 숨이 트여.', 'g|surprised|나 주는 거야? 먹는 거 아니어도…… 좋아.'],
    succubus: ['|smile|후후, 오늘 밤 꿈 주문 받아요. 마왕님은 특별히 공짜예요.', '|neutral|용사들 꿈은 다 비슷해요. 영웅이 되는 꿈. 지루하죠.', 'lo|sad|오늘은 장난칠 기운이 없어요. 그냥 옆에 있을게요.', 'hi|happy|기분 좋은 날엔 눈웃음이 저절로 나와요. 보이죠?', 'f2|shy|장난인 척하는 거, 사실 반은 진심이에요.', 'f3|serious|꿈속 말고 깨어 있는 마왕님 곁이 좋아요. 이건 장난 아니에요.', 'win|smile|어젯밤 홀린 용사가 자기 동료를 막아섰어요. 귀엽죠.', 'ex:nightduchess|flustered|여공작님이 회의 중에 졸지 말래요. 꿈속에선 일하고 있었는데.', 'ex:kitsune|smile|여우님이랑 내기는 제가 이겼어요. 아마도요.', 'rmp|happy|연회장 불빛 아래가 제일 잘 어울려요. 그렇죠?', 'g|shy|어머…… 이러면 제가 홀린 쪽이 되잖아요.'],
  };
  // 말 높이별 공용 대사({c} 호칭 · {like} 좋아하는 방 · {post} 배치 칸 · {work} 좋아하는 일 · {ally} 다른 동료, {x:이/가}처럼 조사 자동)
  const GEN = {
    yo: ['|neutral|{post} 쪽은 오늘도 조용해요.', '|smile|오늘은 {work} 일이 손에 잘 붙어요.', 'like|happy|{like} 덕분에 요즘 지내기 편해요. 고마워요, {c}.', 'nolike|sad|{like:이/가} 있으면 좋겠어요. 욕심이죠?', 'lo|sad|오늘은 기분이 좀 가라앉아요. 금방 괜찮아질 거예요.', 'lo|sad|{c}, 요즘 좀 지쳤어요. 하루쯤 쉬고 싶네요.', 'hi|happy|요즘 던전 생활이 꽤 살 만해요.', 'f0|neutral|아직 여기 생활이 낯설어요. 그래도 나쁘진 않아요.', 'f0|neutral|{c:이랑/랑} 이렇게 얘기하는 건 처음이네요.', 'f2|smile|{c:이/가} 말 걸어 주는 게 하루 중 제일 좋아요.', 'f3|shy|요즘은 {c} 얼굴 보는 게 버릇이 됐어요.', 'win|happy|어젯밤 정말 잘 막았죠. 다들 아직 들떠 있어요.', 'win|smile|어젯밤 일, 다들 아직도 얘기해요.', 'bad|serious|어젯밤엔 아쉬웠어요. 다음엔 안 놓칠 거예요.', 'ko|hurt|어젯밤엔 제가 먼저 쓰러졌죠. 미안해요.', 'hungry|sad|어제 다들 배를 곯았어요. 식당이 좀 더 있으면 좋겠어요.', 'unpaid|angry|급여가 밀리면 다들 수군거려요. 저도요.', 'boss|serious|오늘 밤엔 칭호 붙은 용사가 온대요. 단단히 준비해요.', 'new|smile|온 지 얼마 안 됐는데 벌써 정이 들었어요.', 'ex2|smile|{ally:이랑/랑} 오늘 잠깐 얘기했어요. 생각보다 재밌던데요.', 'early|neutral|던전이 아직 작지만 점점 커지는 게 보여요.', 'mid|neutral|처음 왔을 때보다 복도가 훨씬 길어졌어요.', 'late|serious|요즘 지상이 시끄러워요. 끝이 다가오는 느낌이에요.', '|neutral|오늘 밤엔 어디를 지키면 될까요?', '|smile|{c}, 오늘 얼굴이 좋아 보여요.',
      'g|happy|선물이요? 고마워요. 소중히 할게요.', 'g|surprised|이런 걸 받아도 될까요? ……받을게요.', 'g f2|shy|{c:이/가} 주신 거라 더 좋아요.', 'g lo|smile|마침 기운이 없었는데, 덕분에 좀 나아졌어요.'],
    hap: ['|neutral|{post} 쪽은 이상 없습니다.', '|serious|{work:은/는} 오늘도 차질 없이 마쳤습니다.', 'like|smile|{like:이/가} 있어 지내기 한결 낫습니다. 감사합니다, {c}.', 'nolike|sad|{like:이/가} 없으니 아무래도 허전합니다.', 'lo|sad|오늘은 기운이 없습니다. 맡은 일은 하겠습니다.', 'hi|smile|오늘은 몸이 가볍습니다.', 'f0|neutral|아직 이곳 법도가 익숙하지 않습니다. 곧 익히겠습니다.', 'f2|smile|{c}께서 말을 걸어 주시면 하루가 반듯해집니다.', 'f3|shy|……이런 말씀을 드려도 될지 모르겠습니다만, {c} 곁이 편합니다.', 'win|smile|어젯밤 전과, 훌륭했습니다.', 'bad|serious|어젯밤은 아쉬웠습니다. 같은 실수는 없을 겁니다.', 'ko|hurt|어젯밤엔 면목 없었습니다.', 'hungry|serious|식량이 모자랍니다. 식당이나 정원을 늘리시지요.', 'unpaid|angry|급여가 밀렸습니다. 다들 말은 안 해도 알고 있습니다.', 'boss|serious|오늘 밤 칭호 용사가 옵니다. 각오는 되어 있습니다.', 'new|neutral|새로 왔으니 더 부지런히 움직이겠습니다.', 'ex2|neutral|{ally:와/과} 함께 근무를 섰습니다. 믿을 만한 동료였습니다.', 'early|neutral|아직 던전이 얕습니다. 차근차근 깊어지겠지요.', 'late|serious|마지막이 가까워졌습니다. 흔들리지 않겠습니다.', '|neutral|오늘 밤 배치는 그대로 두시겠습니까?',
      'g|surprised|과분합니다. 감사히 받겠습니다.', 'g|smile|소중히 간직하겠습니다.', 'g f2|shy|{c}께 받은 것은 함부로 쓰지 않겠습니다.'],
    ban: ['|neutral|{post} 쪽은 조용해.', '|smile|오늘은 {work} 일이 잘 풀려.', 'like|happy|{like:이/가} 있어서 좋아. 고마워.', 'nolike|sad|{like:이/가} 있으면 좋겠는데.', 'lo|sad|오늘은 좀 별로야. 금방 괜찮아질 거야.', 'hi|happy|오늘 기분 좋다.', 'f0|neutral|아직 여기 낯설어. 뭐, 나쁘진 않아.', 'f2|smile|{c:이랑/랑} 얘기하는 거, 싫지 않아.', 'f3|shy|……요즘 자꾸 네 생각이 나. 그냥 그렇다고.', 'win|happy|어젯밤 끝내줬지.', 'bad|angry|어젯밤 놓친 거, 아직도 열 받아.', 'ko|hurt|어젯밤엔 내가 먼저 뻗었지. 다음엔 안 그래.', 'hungry|angry|배고파. 식당 좀 늘려 줘.', 'unpaid|angry|급여 밀린 거 알지? 다들 투덜대.', 'boss|serious|오늘 밤 거물 온다며. 준비해 둘게.', 'new|smile|온 지 얼마 안 됐는데, 여기 괜찮네.', 'ex2|smile|{ally:이랑/랑} 오늘 잠깐 붙어 봤어. 꽤 하던데.', 'late|serious|끝이 가까워. 느껴져.', '|neutral|오늘 밤엔 어디 서면 돼?',
      'g|happy|나 주는 거야? 고마워.', 'g|surprised|뭐야, 갑자기. ……좋네.', 'g f2|shy|네가 준 거니까 잘 간직할게.'],
    terse: ['|neutral|……{post}. 조용.', 'lo|sad|……기운. 없다.', 'hi|smile|……좋다.', 'win|smile|……어젯밤. 잘했다.', 'bad|angry|……놓쳤다. 다음엔. 안 놓친다.', 'hungry|sad|……배. 비었다.', 'boss|serious|……오늘 밤. 강한 놈.', 'f3|shy|……마왕. 좋다.', 'g|surprised|……받는다. 고맙다.'],
  };
  // 둘이 주고받는 장면(대화할 때 상대가 던전에 있으면 가끔). M = 마왕. 4번째 값 = 둘 다 이 친밀도 이상일 때만
  const BANTER = [
    ['abysswitch', 'witchapprentice', ['witchapprentice|flustered|스승님, 그 플라스크는 제가 아까……', 'abysswitch|smile|알아. 그래서 일부러 멀리서 열고 있잖니.', 'witchapprentice|sad|……터질 거라고 확신하시는 거죠.', 'abysswitch|happy|확신이 아니라 기대지.', 'M|smile|둘 다 연구실 안에서 해.']],
    ['dragonknight', 'dragonkid', ['dragonkid|happy|용기사님, 오늘 자세 좀 봐 주세요.', 'dragonknight|serious|발이 좁다. 어깨 힘을 빼.', 'dragonkid|flustered|이렇게요?', 'dragonknight|smile|……그래, 그거다. 폐하, 보셨습니까.', 'M|smile|봤어. 둘 다 보기 좋다.']],
    ['beastqueen', 'werewolf', ['beastqueen|smile|은빛, 너 어젯밤 내 뒤만 지키더라.', 'werewolf|serious|여왕님 등은 제가 맡습니다.', 'beastqueen|happy|하하, 앞도 좀 봐. 사냥감은 앞에 있어.', 'werewolf|shy|……앞도 보겠습니다.']],
    ['nightduchess', 'butler', ['nightduchess|serious|집사, 은식기를 또 닦았다지.', 'butler|neutral|네 번째입니다. 빛이 덜 났습니다.', 'nightduchess|smile|……다섯 번째는 내 앞에서 하게.', 'butler|smile|영광입니다.']],
    ['cyclops', 'salamander', ['salamander|angry|외눈이, 불 줄이라고 한 거 너지?', 'cyclops|neutral|쇠가 울었다. 불이 너무 셌다.', 'salamander|angry|쇠가 우는 게 들려? 난 안 들리는데.', 'cyclops|smile|그래서 내가 대장장이다.', 'salamander|flustered|……다음엔 미리 말해.']],
    ['goblin', 'mimic', ['goblin|happy|미믹, 뚜껑 안에 화살 장치 달아 볼래요?', 'mimic|surprised|제 안에요? 간지러울 것 같은데요.', 'goblin|smile|열자마자 피융. 멋지잖아요.', 'mimic|happy|……좋아요. 대신 경첩은 금으로요.']],
    ['undine', 'mermaid', ['mermaid|smile|운디네, 오늘 온천에서 노래해도 돼?', 'undine|neutral|물이 출렁여도 괜찮다면요.', 'mermaid|happy|그게 반주야.', 'undine|smile|……그럼 물결을 조금 높일게요.']],
    ['dryad', 'mushroom', ['dryad|smile|또 내 그늘에서 자고 있었어요?', 'mushroom|neutral|……여기가 제일 습해서요……', 'dryad|shy|그럼 뿌리를 조금 비켜 줄게요.', 'mushroom|smile|……고마워요…… 쿨……']],
    ['lich', 'abysswitch', ['lich|serious|심연의 마녀. 대출 기한이 이레 지났습니다.', 'abysswitch|smile|어머, 그 책 아직 읽는 중이에요.', 'lich|angry|표지가 그을려 있던데요.', 'abysswitch|flustered|……읽으면서 실험도 좀 했거든요.', 'M|serious|오늘 안에 돌려줘.']],
    ['oni', 'orc', ['oni|happy|오크, 오늘 밤 끝나면 한판 붙자.', 'orc|happy|씨름? 술?', 'oni|smile|둘 다.', 'orc|happy|좋다. 고기도.']],
    ['ghost', 'banshee', ['ghost|smile|언니, 오늘 노래가 조금 밝았어요.', 'banshee|shy|……들켰네요. 마왕님이 좋아하셔서요.', 'ghost|happy|등불도 덩달아 밝아졌어요.']],
    ['skelknight', 'dullahan', ['skelknight|serious|목 없는 기사 공, 대련 한 판 어떻습니까.', 'dullahan|smile|좋아요. 이번엔 머리를 단단히 묶을게요.', 'skelknight|smile|지난번엔 머리를 줍느라 승부가 흐려졌지요.', 'dullahan|flustered|……그건 잊어 주세요.']],
    ['golem', 'gargoyle', ['golem|neutral|……날개 돌.', 'gargoyle|neutral|……큰 돌.', 'golem|smile|……오늘. 조용.', 'gargoyle|smile|……동의.', 'M|smile|……둘이 무슨 얘기를 하는 건지.']],
    ['harpy', 'imp', ['harpy|happy|임프, 들었어요? 지상에 새 칭호 용사가 생겼대요.', 'imp|smile|들었죠. 근데 그 사람 칼이 사실 빌린 거래요.', 'harpy|surprised|진짜요?', 'imp|happy|반은 진짜예요.']],
    ['kitsune', 'succubus', ['succubus|smile|여우님, 오늘 누가 더 많이 홀렸게요?', 'kitsune|smile|후후, 세는 것부터가 하수예요.', 'succubus|flustered|……그럼 제가 진 거네요.', 'kitsune|happy|아니요, 비긴 걸로 해 둬요.']],
    ['arachne', 'nightduchess', ['arachne|smile|여공작님, 소매 길이를 조금 줄였어요.', 'nightduchess|neutral|……손목이 보이는군요.', 'arachne|happy|요즘 유행이에요.', 'nightduchess|smile|좋습니다. 이번만은 유행을 따르지요.']],
    ['dragonknight', 'beastqueen', ['beastqueen|happy|용기사, 팔씨름 한 판 더?', 'dragonknight|serious|지난번은 무승부였습니다.', 'beastqueen|smile|그러니까 한 판 더지.', 'dragonknight|flustered|……폐하께서 보고 계십니다.', 'M|smile|난 신경 쓰지 마.']],
    ['beastqueen', 'chimera', ['chimera|happy|여왕, 오늘 사냥 같이 가자.', 'beastqueen|smile|밤까지 참아. 사냥감이 알아서 들어오잖아.', 'chimera|neutral|머리 셋이 다 못 참겠대.', 'beastqueen|happy|하하, 그럼 셋이서 훈련장 열 바퀴.']],
    ['minotaur', 'lamia', ['lamia|smile|경비실 문틀, 또 부딪혔지요?', 'minotaur|flustered|어, 어떻게 아셨어요?', 'lamia|neutral|뿔 자국이 새로 났거든요.', 'minotaur|sad|……문틀을 높여 달라고 해 볼까요.', 'M|smile|다음에 늘려 줄게.']],
    ['nightduchess', 'succubus', ['nightduchess|serious|어제 회의 중에 졸았지요.', 'succubus|smile|존 게 아니라 일하고 있었어요. 꿈속에서.', 'nightduchess|angry|그 꿈의 장부는 누가 씁니까?', 'succubus|flustered|……다음부턴 깨어 있을게요.']],
    ['werewolf', 'chimera', ['chimera|happy|늑대야, 누가 먼저 입구까지 가나 내기하자.', 'werewolf|neutral|순찰 중이다.', 'chimera|smile|그럼 순찰 겸 내기.', 'werewolf|smile|……딱 한 번이다.']],
    ['abysswitch', 'nightduchess', ['nightduchess|serious|연구 예산이 또 넘었습니다.', 'abysswitch|smile|넘은 게 아니라 미래에 투자한 거예요.', 'nightduchess|neutral|미래는 이자를 안 줍니다.', 'abysswitch|flustered|……폐하, 뭐라고 좀 해 주세요.', 'M|smile|예산은 여공작 말대로.']],
    // ── 간부끼리 ──
    ['dragonknight', 'abysswitch', ['abysswitch|smile|용기사님, 검에 마력 각인 하나 새겨 드릴까요? 공짜로요.', 'dragonknight|serious|지난번 각인은 칼집째 녹였습니다.', 'abysswitch|flustered|그건 칼집이 약했던 거고요.', 'dragonknight|neutral|……칼집 값은 장부에 올리겠습니다.']],
    ['dragonknight', 'nightduchess', ['nightduchess|serious|용기사, 갑옷 수리비가 이번 달만 세 번째입니다.', 'dragonknight|serious|세 번 다 폐하 앞을 막다 생긴 흠입니다.', 'nightduchess|neutral|……그렇다면 그 항목은 지우지요.', 'dragonknight|surprised|지워도 됩니까?', 'nightduchess|smile|명예 비용은 따로 적습니다.']],
    ['abysswitch', 'beastqueen', ['beastqueen|happy|마녀, 어젯밤 번개 좋았어. 털이 다 섰다니까.', 'abysswitch|smile|어머, 우리 편 털까지 세울 생각은 없었는데요.', 'beastqueen|smile|괜찮아. 애들이 그거 보고 더 신나서 물었거든.', 'abysswitch|happy|그럼 다음엔 조금 더 크게 칠게요.', 'M|serious|우리 편은 피해서.']],
    ['nightduchess', 'beastqueen', ['nightduchess|serious|여왕, 사냥감을 식당에 통째로 들여놓지 마십시오.', 'beastqueen|neutral|신선하잖아.', 'nightduchess|angry|아직 움직이고 있었습니다.', 'beastqueen|happy|하하, 그러니까 신선하다는 거지.']],
    ['dragonknight', 'beastqueen', ['dragonknight|serious|여왕, 어젯밤 진형을 벗어났습니다.', 'beastqueen|smile|냄새가 났어. 쫓아가면 잡히는 냄새.', 'dragonknight|neutral|……잡았습니까.', 'beastqueen|happy|당연하지. 네 몫도 남겨 뒀어.', 'dragonknight|flustered|그런 걸 남겨 두지 마십시오.']],
    ['abysswitch', 'nightduchess', ['abysswitch|smile|공작님, 홍차에 마력 한 방울 넣으면 향이 두 배래요.', 'nightduchess|neutral|지난번 그 한 방울에 찻잔이 노래를 불렀지요.', 'abysswitch|happy|음정은 맞았잖아요.', 'nightduchess|smile|……박자는 엉망이었습니다.']],
    // 간부끼리 — 가까워진 뒤(둘 다 친밀도 55 이상)
    ['dragonknight', 'abysswitch', ['abysswitch|neutral|용기사님, 어젯밤 제 앞을 막아 준 거, 일부러였죠.', 'dragonknight|serious|마법사는 뒤에 있어야 합니다. 그게 진형입니다.', 'abysswitch|smile|진형 말고요. 그쪽 마음 얘기예요.', 'dragonknight|flustered|……폐하, 저는 순찰을 다녀오겠습니다.', 'M|smile|다녀와. 얼굴 식히고.'], 55],
    ['nightduchess', 'beastqueen', ['beastqueen|neutral|공작, 요즘 밤마다 장부 펴 놓고 졸더라.', 'nightduchess|serious|졸지 않았습니다. 눈을 감고 계산했지요.', 'beastqueen|smile|담요 덮어 준 것도 계산했어?', 'nightduchess|shy|……이자는 붙이지 않겠습니다.'], 55],
    ['dragonknight', 'nightduchess', ['nightduchess|neutral|용기사, 폐하께서 요즘 잘 웃으십니다.', 'dragonknight|serious|보았습니다. 밤이 덜 무서워졌습니다.', 'nightduchess|smile|그 공의 절반은 그대 것이지요.', 'dragonknight|shy|……나머지 절반은 공작 몫입니다.', 'M|smile|둘 다 들린다.'], 55],
    ['abysswitch', 'beastqueen', ['beastqueen|serious|마녀, 너 어젯밤 마력 바닥까지 썼지. 냄새로 알아.', 'abysswitch|smile|조금요. 아주 조금.', 'beastqueen|angry|조금이 아니던데. 쓰러지면 누가 업고 와?', 'abysswitch|shy|……그쪽이 업어 주겠죠.', 'beastqueen|smile|하하. 그래, 내가 업어.'], 55],
    // 아주 가까워진 뒤(85)
    ['dragonknight', 'beastqueen', ['beastqueen|smile|용기사, 우리 처음 만났을 때 기억나? 서로 목을 노렸잖아.', 'dragonknight|neutral|기억합니다. 그대가 먼저 웃었지요.', 'beastqueen|happy|지금은 등을 맡기잖아. 이상하지.', 'dragonknight|smile|……이상하지 않습니다. 폐하 곁이니까요.', 'M|shy|……둘 다 고마워.'], 85],
    ['abysswitch', 'nightduchess', ['nightduchess|neutral|마녀, 연구 예산을 다음 달부터 늘리지요.', 'abysswitch|surprised|어머. 공작님이 먼저 그런 말을요?', 'nightduchess|smile|폐하를 지키는 데 쓴다는 걸 이제 압니다.', 'abysswitch|shy|……그럼 이번엔 진짜 안 터뜨릴게요.', 'nightduchess|smile|그건 장부에 적지 않겠습니다. 믿지 않으니까요.'], 85],
    // ── 간부와 동료 ──
    ['dragonknight', 'skelknight', ['skelknight|serious|용기사 공, 옛 왕국에선 무릎을 꿇고 맹세했습니다.', 'dragonknight|neutral|이곳에선 서서 지킵니다. 그게 폐하의 법도입니다.', 'skelknight|smile|……무릎이 녹슬어 다행입니다.']],
    ['dragonknight', 'minotaur', ['minotaur|flustered|용, 용기사님. 훈련장 기둥을 또 부러뜨렸어요.', 'dragonknight|serious|몇 번째입니까.', 'minotaur|sad|……네 번째요.', 'dragonknight|smile|좋은 힘입니다. 기둥을 더 굵게 세우지요.']],
    ['abysswitch', 'lich', ['lich|serious|심연의 마녀, 서고에 금서 한 권이 비어 있습니다.', 'abysswitch|smile|어머, 그 책이 저를 따라왔나 봐요.', 'lich|angry|책은 발이 없습니다.', 'abysswitch|flustered|……이번 책은 있었어요. 진짜로요.']],
    ['abysswitch', 'salamander', ['salamander|angry|마녀, 대장간 불에 뭘 넣었어? 파랗게 탔잖아.', 'abysswitch|happy|어머, 예쁘죠?', 'salamander|serious|……예쁘긴 해. 근데 쇠가 울었어.', 'abysswitch|smile|그럼 쇠가 감동한 거예요.']],
    ['nightduchess', 'mimic', ['mimic|happy|여공작님, 오늘 금화 하나 삼켰다가 뱉었어요. 착하죠?', 'nightduchess|serious|그 하나가 장부와 맞지 않아 한 시간을 셌습니다.', 'mimic|sad|……뱉은 자리가 달랐나 봐요.', 'nightduchess|smile|다음엔 뱉기 전에 말하세요.']],
    ['nightduchess', 'imp', ['imp|smile|공작님, 지상 시세 들으셨어요? 소금이 금값이래요.', 'nightduchess|neutral|출처는.', 'imp|flustered|……반은 제가 들은 거예요.', 'nightduchess|serious|나머지 반은 지어낸 것이로군요.', 'imp|smile|그래도 반은 진짜잖아요.']],
    ['beastqueen', 'orc', ['orc|happy|여왕, 고기 다 구웠다.', 'beastqueen|smile|애들 먼저 먹여. 난 나중에.', 'orc|surprised|여왕이 나중에?', 'beastqueen|serious|무리의 우두머리는 마지막에 먹는 거야. 기억해 둬.']],
    ['beastqueen', 'harpy', ['harpy|happy|여왕님, 있잖아요, 지상에서 여왕님 현상금이 올랐대요.', 'beastqueen|happy|얼마나?', 'harpy|smile|폐하 다음으로 비싸요.', 'beastqueen|smile|하하, 다음엔 폐하를 넘어야겠네.', 'M|serious|넘지 마.']],
    // ── 동료끼리 ──
    ['slime', 'golem', ['slime|happy|골렘, 등에 올라타도 돼요? 말랑하게 굴러갈게요.', 'golem|neutral|……무겁다. 아니. 가볍다.', 'slime|smile|어느 쪽이에요?', 'golem|smile|……좋다.']],
    ['harpy', 'gargoyle', ['harpy|smile|파수꾼, 밤새 안 움직이면 지루하지 않아요?', 'gargoyle|neutral|……안 지루. 바람. 소리.', 'harpy|surprised|소리를 듣는 거예요?', 'gargoyle|smile|……네 날갯소리. 시끄럽다.', 'harpy|flustered|……칭찬 맞죠?']],
    ['lamia', 'undine', ['lamia|smile|음…… 운디네, 온천 물 조금만 더 데워 줘요.', 'undine|neutral|이미 다른 분들한텐 뜨겁대요.', 'lamia|sad|저는 비늘이라 늘 춥거든요.', 'undine|smile|……그럼 그 구석만 따로 데울게요.']],
    ['witchapprentice', 'goblin', ['goblin|happy|견습님, 폭발 물약을 함정에 넣으면 어떨까요?', 'witchapprentice|flustered|제 물약은 원래 다 폭발하는데요.', 'goblin|smile|그러니까 딱이죠.', 'witchapprentice|sad|……칭찬인지 모르겠어요.']],
    ['arachne', 'butler', ['butler|serious|직조공, 연회장 식탁보를 새로 부탁드립니다.', 'arachne|smile|무늬는 어떻게 할까요?', 'butler|neutral|폐하의 문장, 그리고 은빛 테두리를.', 'arachne|happy|사흘이면 돼요. 집사님 앞치마도 하나 덤으로요.', 'butler|shy|……감사히 받겠습니다.']],
    ['kitsune', 'banshee', ['kitsune|smile|반시, 오늘 제사에서 한 소절 불러 줄래요?', 'banshee|sad|……제 노래는 장송곡뿐인데요.', 'kitsune|neutral|그게 필요해요. 떠난 이들도 들어야 하니까.', 'banshee|shy|……그럼 조금 따뜻하게 부를게요.']],
    ['oni', 'cyclops', ['oni|happy|외눈이, 철퇴 손잡이 좀 고쳐 줘.', 'cyclops|neutral|또 부러뜨렸어?', 'oni|smile|씨름하다가.', 'cyclops|angry|철퇴 들고 씨름을 왜 해.', 'oni|happy|이겼으니까 괜찮아.']],
    ['dryad', 'mermaid', ['mermaid|smile|정령님, 정원에 물 주는 시간에 노래해도 돼요?', 'dryad|happy|좋아요. 잎들이 노래 들으면 더 잘 자라요.', 'mermaid|surprised|정말요?', 'dryad|smile|……사실 저도 처음 해 보는 거예요.']],
    ['werewolf', 'dullahan', ['werewolf|neutral|목 없는 기사, 순찰 같이 돌자.', 'dullahan|smile|좋아요. 대신 제 머리 좀 들어 줄래요?', 'werewolf|surprised|……왜.', 'dullahan|happy|위에서 보면 더 멀리 보이거든요.']],
    ['succubus', 'lamia', ['succubus|smile|라미아, 오늘 꿈에 뭐 보여 줄까요?', 'lamia|neutral|음…… 따뜻한 모래밭이요.', 'succubus|happy|쉬워요. 그럼 오늘은 일찍 자요.', 'lamia|smile|……이미 졸려요.']],
    ['ghost', 'dullahan', ['ghost|smile|기사님, 오늘 길 잃은 영혼을 하나 데려왔어요.', 'dullahan|serious|용사였나요?', 'ghost|sad|……아직 앳된 견습이었어요.', 'dullahan|smile|그럼 제가 끝까지 바래다줄게요.']],
    ['chimera', 'harpy', ['chimera|happy|하피, 하늘에서 사냥감 보이면 알려 줘.', 'harpy|smile|대신 소문 하나 줘요.', 'chimera|neutral|……사자 머리가 뱀 머리 몰래 고기 먹었어.', 'harpy|happy|그거 최고예요!']],
    // 동료끼리 — 가까워진 뒤
    ['undine', 'mermaid', ['mermaid|shy|운디네, 어젯밤 쓰러졌을 때 온천까지 옮겨 준 거 너지.', 'undine|neutral|물 냄새가 나는 쪽으로 왔을 뿐이에요.', 'mermaid|smile|거짓말. 손이 떨렸잖아.', 'undine|shy|……다음엔 쓰러지지 마요.'], 55],
    ['skelknight', 'dullahan', ['dullahan|neutral|해골 기사님, 옛 왕국이 그리워요?', 'skelknight|serious|가끔은. 깃발이 펄럭이던 소리가.', 'dullahan|smile|여기도 깃발 있어요. 폐하 문장이요.', 'skelknight|smile|……그렇군요. 이제 그 소리를 듣겠습니다.'], 55],
    ['werewolf', 'chimera', ['chimera|serious|늑대야, 어젯밤 너 다쳤을 때 머리 셋이 다 울었어.', 'werewolf|surprised|……셋 다?', 'chimera|shy|응. 처음으로 의견이 맞았어.', 'werewolf|smile|그럼 다음엔 안 다칠게. 셋 다 안 울게.'], 55],
    ['golem', 'gargoyle', ['gargoyle|neutral|……큰 돌. 금 갔다. 어제.', 'golem|neutral|……괜찮다.', 'gargoyle|serious|……안 괜찮다. 고친다.', 'golem|smile|……고맙다. 날개 돌.', 'M|smile|……둘이 정말 사이좋네.'], 55],
  ];
  /* 대사 기억(이 기기 localStorage): 인물별 최근 대사 40개 + 쓴 날. 놀이 날짜(day)는 판을 넘어 이어져, 같은 말을 여러 날 피한다. */
  const LM = (() => {
    const K = 'lounge.dk.lines'; let d = null;
    const load = () => { if (d) return d; try { d = JSON.parse(localStorage.getItem(K) || 'null'); } catch (e) { d = null; } if (!d || typeof d !== 'object' || !d.c) d = { day: 0, c: {}, cd: {}, b: {}, lb: -9 }; return d; };
    const save = () => { try { localStorage.setItem(K, JSON.stringify(d)); } catch (e) {} };
    return {
      day: () => load().day, tick() { load().day++; save(); },
      recent: (code) => load().c[code] || [],
      texts: (code, n) => (load().c[code] || []).slice(-(n || 10)).map((r) => r[0]),
      use(code, t) { const a = load().c[code] = load().c[code] || []; a.push([String(t).slice(0, 60), d.day]); if (a.length > 40) a.splice(0, a.length - 40); save(); },
      cdOk: (k, gap) => load().day - (load().cd[k] == null ? -99 : d.cd[k]) >= gap, cdSet(k) { load().cd[k] = d.day; save(); },
      bOk: (i) => load().day - (load().b[i] == null ? -99 : d.b[i]) >= 15 && d.day - d.lb >= 1, bSet(i) { load().b[i] = d.day; d.lb = d.day; save(); },
      _reset() { d = { day: 0, c: {}, cd: {}, b: {}, lb: -9 }; save(); },
    };
  })();
  function josa(w, a, b) {
    w = String(w || ''); const c = w.charCodeAt(w.length - 1);
    if (!(c >= 0xac00 && c <= 0xd7a3)) return w + b;
    const jong = (c - 0xac00) % 28;
    if (a === '으로') return w + (jong && jong !== 8 ? '으로' : '로');
    return w + (jong ? a : b);
  }
  const fillT = (t, v) => t.replace(/\{(\w+)(?::([^/}]+)\/([^}]+))?\}/g, (m, k, a, b) => (a ? josa(v[k] || '', a, b) : (v[k] || '')));
  const EV_TAGS = { win: 1, bad: 1, ko: 1, hungry: 1, unpaid: 1, boss: 1, new: 1 };
  function lineCtx(s, e) {
    const M = MON[e.k] || HERO[e.k] || {}, rep = s.rep, T = new Set();
    const af = e.af || 0, md = e.md == null ? 70 : e.md;
    if (md < 35) T.add('lo'); if (md >= 75) T.add('hi');
    if (af < 25) T.add('f0'); if (af >= 25) T.add('f1'); if (af >= 55) T.add('f2'); if (af >= 85) T.add('f3');
    if (rep) {
      if (rep.kills > 0 && !rep.stolen && !rep.freed) T.add('win');
      if (rep.stolen || rep.freed || rep.esc || (rep.left && rep.left.length)) T.add('bad');
      if (rep.ko && rep.ko.includes(e.k)) T.add('ko');
      if (rep.unfed) T.add('hungry'); if (rep.unpaid) T.add('unpaid');
    }
    if (s.ph === 'day' && isBossNight(s)) T.add('boss');
    if (e.d0 != null && s.night - e.d0 <= 1) T.add('new');
    const late = s.mode === 'camp' ? s.ch >= s.chs.length - 2 : s.night >= 15;
    T.add(late ? 'late' : s.night < 4 ? 'early' : 'mid');
    if (M.like) T.add(cnt(s.r, M.like) ? 'like' : 'nolike');
    const pr = e.p >= 0 ? s.r[e.p] : '-'; if (pr && pr !== '-') T.add('rm' + pr);
    const others = s.ro.filter((x) => x.k !== e.k);
    others.forEach((x) => T.add('ex:' + x.k)); if (others.length) T.add('ex2');
    const al = others.length ? pick(others.filter((x) => !isExec(x.k)).concat(others)).k : '';
    const V = VOICE[e.k] || { reg: 'yo', call: '마왕님' };
    return { T, V, vars: { c: V.call, like: M.like ? RM[M.like].n : '', post: pr && pr !== '-' && RM[pr] ? RM[pr].n : '통로', work: M.work || '일', ally: al ? nameOf(al) : '' } };
  }
  const parseLn = (str) => { const p = str.split('|'); return { tags: p[0] ? p[0].split(' ') : [], ex: p[1] || 'neutral', text: p.slice(2).join('|') }; };
  // 인물·상황에 맞는 자료 대사 한 줄(최근 쓴 말·사건 대사 쿨다운 피함). sit: 'talk' | 'gift'
  function pickLine(s, e, sit) {
    const code = e.k, C = lineCtx(s, e), day = LM.day();
    const rec = LM.recent(code), recent = new Set(rec.filter((r, i) => day - r[1] <= 10 || i >= rec.length - 25).map((r) => r[0]));
    const pool = (LN[code] || []).map((x) => [x, 1.5]).concat((GEN[C.V.reg] || GEN.yo).map((x) => [x, 0]));
    const cands = [], all = [];
    for (const [str, bonus] of pool) {
      const L0 = parseLn(str); const g = L0.tags.includes('g');
      if ((sit === 'gift') !== g) continue;
      let ok = true, sc = 1 + bonus, evs = [];
      for (const t of L0.tags) { if (t === 'g') continue; if (!C.T.has(t)) { ok = false; break; } if (EV_TAGS[t]) { if (!LM.cdOk(code + ':' + t, 1)) { ok = false; break; } sc += 3; evs.push(t); } else sc += t.startsWith('ex') || t.startsWith('rm') ? 2 : 1.2; }
      if (!ok) continue;
      const text = fillT(L0.text, C.vars); if (/\{|\}/.test(text) || (/\{ally/.test(L0.text) && !C.vars.ally)) continue;
      const o = { spk: code, ex: L0.ex, text, sc, evs };
      all.push(o); if (!recent.has(text.slice(0, 60))) cands.push(o);
    }
    let pickd = null;
    if (cands.length) { const w = cands.map((o) => o.sc * o.sc); let r = Math.random() * w.reduce((a, b) => a + b, 0), j = 0; while (j < cands.length - 1 && (r -= w[j]) > 0) j++; pickd = cands[j]; }
    else if (all.length) { const when = new Map(rec.map((r, i) => [r[0], i])); all.sort((a, b) => (when.get(a.text.slice(0, 60)) || 0) - (when.get(b.text.slice(0, 60)) || 0)); pickd = all[0]; }
    if (!pickd) return say(code, sit, e);
    LM.use(code, pickd.text); pickd.evs.forEach((t) => LM.cdSet(code + ':' + t));
    return { spk: code, ex: pickd.ex, text: pickd.text };
  }
  // 대화할 때 가끔 둘이 주고받는 장면(상대가 던전에 있고, 15일 안에 안 본 장면)
  function pickBanter(s, code) {
    if (Math.random() > 0.3) return null;
    const have = new Set(s.ro.map((x) => x.k));
    const afOf = (k) => (s.ro.find((x) => x.k === k) || {}).af || 0;
    const ok = BANTER.map((b, i) => [b, i]).filter(([b, i]) => (b[0] === code || b[1] === code) && have.has(b[0]) && have.has(b[1]) && (!b[3] || (afOf(b[0]) >= b[3] && afOf(b[1]) >= b[3])) && LM.bOk(i));
    if (!ok.length) return null;
    const hi = ok.filter(([b]) => b[3]); // 가까워진 사이의 장면이 있으면 그쪽을 먼저
    const [b, i] = hi.length && Math.random() < 0.6 ? pick(hi) : pick(ok); LM.bSet(i);
    b[2].forEach((x) => { const o = lineOf(x); if (o.spk !== 'M') LM.use(o.spk, o.text); });
    return b[2];
  }
  for (const k in TALK) LN[k] = (LN[k] || []).concat(TALK[k].map((t) => '|neutral|' + t));
  function lineOf(str) { const p = str.split('|'); return { spk: p[0], ex: p[1] || 'neutral', text: p.slice(2).join('|') }; }
  /* AI 서술 연결 지점: (말하는 이, 상황, 맥락) → 대사 한 줄 {spk, ex, text}.
     지금은 데이터에서 고른다. 나중에 Claude API를 붙일 때 이 함수만 바꾸면 된다(실패·오프라인이면 이 기본값). */
  const regOf = (k) => (VOICE[k] ? VOICE[k].reg : 'yo'), callOf = (k) => (VOICE[k] ? VOICE[k].call : '마왕님');
  function say(spk, sit, ctx) {
    ctx = ctx || {};
    const hl = HERO_LINE[spk], M = MON[spk];
    const bark = M && M.ex ? EXEC_BARK[spk] : M ? MON_BARK[M.rk] : null;
    const ex0 = (e) => ({ spk, ex: e, text: '' });
    let r = null;
    switch (sit) {
      case 'talk': { const L0 = TALK[spk]; if (L0) r = { spk, ex: (ctx.md || 70) < 35 ? 'sad' : (ctx.af || 0) > 60 ? 'smile' : 'neutral', text: L0[Math.floor(Math.random() * L0.length)] }; break; }
      case 'gift': r = { spk, ex: 'happy', text: pick(['선물이요? 고마워요!', '이런 걸…… 정말 받아도 돼요?', '소중히 할게요.', '마왕님 센스, 최고예요.']) }; break;
      case 'greet': r = { spk, ex: 'smile', text: GREET[spk] || (hl && hl[2]) || '잘 부탁해요.' }; break;
      case 'leave': r = { spk, ex: 'sad', text: pick(regOf(spk) === 'hap' ? ['……더는 버틸 수 없습니다. 이만 물러가겠습니다.', '제 자리가 아니었나 봅니다. 안녕히 계십시오.'] : regOf(spk) === 'ban' ? ['……더는 못 있겠어. 잘 있어.', '여긴 내 자리가 아닌가 봐. 갈게.'] : regOf(spk) === 'terse' ? ['……간다. 잘 있어라.'] : ['……더는 못 버티겠어요. 안녕히 계세요.', '여긴 제 자리가 아닌가 봐요.', '배고프고 지쳤어요. 떠날게요.']) }; break;
      case 'awaken': r = { spk, ex: 'awakened', text: pick(regOf(spk) === 'hap' ? ['힘이 차오릅니다. 이 힘, ' + callOf(spk) + '께 바치겠습니다.', '이것이 제 본모습입니다. 지켜봐 주십시오.'] : regOf(spk) === 'ban' ? ['……이게 진짜 나야. 잘 봐.', '힘이 넘쳐. 이제 누구한테도 안 져.'] : regOf(spk) === 'terse' ? ['……힘. 넘친다. 지킨다.'] : ['힘이…… 넘쳐요. ' + callOf(spk) + ' 덕분이에요.', '이게 진짜 저예요. 봐 주세요.', '이제 누구에게도 지지 않아요.']) }; break;
      case 'convert': r = { spk, ex: 'shy', text: (hl && hl[2]) || '……동료가 될게요.' }; break;
      case 'persfail': r = { spk, ex: 'angry', text: pick(['마물의 말엔 안 넘어가!', '……아직은 믿을 수 없어.', '흥. 내일 다시 와 봐.']) }; break;
      case 'h_in': r = { spk, ex: 'neutral', text: hl ? hl[0] : '' }; break;
      case 'h_ko': r = { spk, ex: 'hurt', text: hl ? hl[1] : '' }; break;
      case 'm_skill': r = bark ? { spk, ex: 'serious', text: bark[0] } : null; break;
      case 'm_ko': r = bark ? { spk, ex: 'hurt', text: bark[1] } : null; break;
      case 'm_kill': r = bark ? { spk, ex: 'smile', text: bark[2] } : null; break;
      case 'goal': r = { spk, ex: 'serious', text: GOAL_LINE[ctx.g] || '' }; break;
    }
    return r || ex0('neutral');
  }
  const EXPR_ALL = ['neutral', 'smile', 'happy', 'angry', 'sad', 'surprised', 'shy', 'serious', 'hurt', 'flustered'];
  /* AI 서술(round 46 → 47): 말투 카드 + 최근 대화 + 최근에 한 말을 넣어 자연스러운 구어로. 대화·선물·인사·간부 제안만(이야기 장면·아침 보고는 자료 그대로, round 49).
     결과는 걸러서(따옴표·지문·이름표 제거, 길이, 영어·메타 금지, 최근 대사와 너무 비슷하면 버림) 실패면 자료 대사. 침입 중 외침은 자료만.
     대사는 연출일 뿐 규칙·수치에 영향 없음. 게임별 켬/끔: L.ai.enabled('dkeeper'). */
  const DK_SYS = [
    '당신은 다크 판타지 던전 경영 게임 「던전 주인」의 대사 작가입니다. 던전의 주인인 마왕(여성)과 그녀를 따르는 간부·마물(모두 성인 여성)의 대사를 씁니다.',
    '좋은 대사의 조건:',
    '- 실제로 입 밖에 내는 짧은 구어. 보통 15~45자, 길어도 60자. 한두 문장.',
    '- 말투 카드(호칭·말 높이·말끝·버릇·안 쓰는 말)를 그대로 지킨다. 말 높이를 섞지 않는다.',
    '- 번역투·설명조 금지: 「~하는 것이다」 「그것은」 「나의」 「당신」 같은 말, 주어(나는/저는) 반복, 감정을 이름으로 늘어놓기(「기뻐요. 행복해요.」).',
    '- 느낌표는 많아야 한 번. 물음표·말줄임표도 남발하지 않는다. 이모지·의성어 나열 금지.',
    '- 지문·괄호·따옴표·이름표·해설 없이 대사만.',
    '- 게임 밖 이야기(플레이어, 게임, 수치, 친밀도·기분 숫자, AI) 금지. 숫자 대신 분위기로.',
    '- 최근 대화와 이 인물이 최근에 한 말을 되풀이하지 않는다. 같은 말머리·소재·비유도 피한다.',
    '- 어른스럽고 품위 있게. 다정함과 은근한 설렘은 좋지만 선정적·노골적 표현은 쓰지 않는다. 유치한 말투 금지.',
  ].join('\n');
  const DK_SCENE_SYS = DK_SYS + '\n\n장면 형식: JSON {"lines":[{"s":"c" 또는 "m","ex":"표정","t":"대사"}]} 3~5줄. c = 그 인물, m = 마왕. 표정은 주어진 목록에서만 고른다.\n마왕(m)은 부하에게 반말. 짧고 낮게, 위엄 있되 다정함이 묻어난다(예: 「수고했어.」 「무리하지 마.」 「……고마워.」). 마왕 대사는 절반 이하.';
  const SIT_KO = { talk: '마왕이 낮에 말을 걸었다(일상 대화)', gift: '마왕에게 선물을 받았다', greet: '던전에 처음 들어와 마왕에게 인사한다', prop: '낮에 마왕을 찾아와 던전 운영에 관한 제안을 한다(제안 내용은 주어진 그대로, 자기 성격대로 짧게 권한다)' };
  function voiceCard(code) {
    const V = VOICE[code], M = MON[code] || HERO[code] || {};
    if (!V) return '■ ' + nameOf(code) + ' — 용사 출신으로 마왕군에 들어온 성인 여성. ' + (M.d || '') + '\n- 마왕 호칭: 마왕님 / 말 높이: ' + REG_KO.yo;
    const ex = (LN[code] || []).map(parseLn).filter((l) => !l.tags.includes('g') && !/\{/.test(l.text)).slice(0, 5).map((l) => '  ' + l.text);
    return '■ ' + M.n + ' — ' + M.rl + '. ' + (M.ps || '') + '. 좋아하는 일: ' + (M.work || '') + '\n- 마왕 호칭: ' + V.call + ' / 말 높이: ' + REG_KO[V.reg]
      + '\n- 말끝: ' + V.end + '\n- 버릇: ' + V.tic + '\n- 자주 쓰는 말: ' + V.voc + '\n- 절대 안 하는 말: ' + V.never + '\n- 말투 예시(그대로 쓰지 말 것):\n' + ex.join('\n');
  }
  function ctxWords(s, e) {
    if (!s || !e) return '';
    const md = e.md == null ? 70 : e.md, af = e.af || 0, M = MON[e.k] || {};
    const out = ['- 기분: ' + (md < 35 ? '가라앉음' : md >= 75 ? '좋음' : '보통'), '- 마왕과의 사이: ' + (af >= 85 ? '아주 가까움(마음을 거의 다 열었음)' : af >= 55 ? '가까움' : af >= 25 ? '조금 익숙해짐' : '아직 낯섦')];
    if (e.p >= 0 && RM[s.r[e.p]]) out.push('- 오늘 지키는 자리: ' + RM[s.r[e.p]].n);
    if (M.like) out.push('- 좋아하는 방(' + RM[M.like].n + '): ' + (cnt(s.r, M.like) ? '던전에 있음' : '아직 없음'));
    out.push('- 시기: ' + (s.mode === 'camp' ? (s.ch + 1) + '장 / 전체 ' + s.chs.length + '장' : (s.night + 1) + '번째 밤 무렵') + (s.ph === 'day' && isBossNight(s) ? ', 오늘 밤 칭호 용사가 온다' : ''));
    const mates = s.ro.filter((x) => x.k !== e.k).slice(0, 8).map((x) => nameOf(x.k)); if (mates.length) out.push('- 함께 지내는 동료: ' + mates.join(', '));
    return out.join('\n');
  }
  // AI 결과 다듬기·거르기
  function cleanAI(t) {
    let s = String(t || '').replace(/\r?\n+/g, ' ').trim();
    s = s.replace(/^[^\s:：]{1,14}\s*[:：]\s*/, '');
    s = s.replace(/\([^)]*\)|（[^）]*）|\*[^*]*\*|\[[^\]]*\]/g, '');
    s = s.replace(/["“”‘’「」『』《》〈〉]/g, '').replace(/^'+|'+$/g, '');
    s = s.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B50}\u{2764}]/gu, '');
    s = s.replace(/~+/g, '').replace(/!{2,}/g, '!').replace(/\?{2,}/g, '?').replace(/\.{3,}|…{3,}/g, '……').replace(/(……\s*){2,}/g, '…… ');
    let n = 0; s = s.replace(/!/g, () => (n++ ? '.' : '!'));
    s = s.replace(/\s+/g, ' ').trim();
    if (s.length > 70) { const cut = s.slice(0, 70); const m = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('? '), cut.lastIndexOf('! '), cut.lastIndexOf('요. '), cut.lastIndexOf('다. ')); s = m > 15 ? cut.slice(0, m + 1).trim() : cut.slice(0, 66).trim() + '…'; }
    return s;
  }
  function bigrams(s) { s = String(s).replace(/[\s.,!?…]/g, ''); const a = []; for (let i = 0; i < s.length - 1; i++) a.push(s.slice(i, i + 2)); return a; }
  function simLine(a, b) {
    const A = bigrams(a), B = bigrams(b); if (!A.length || !B.length) return a === b ? 1 : 0;
    const m = new Map(); B.forEach((x) => m.set(x, (m.get(x) || 0) + 1)); let k = 0; A.forEach((x) => { const v = m.get(x); if (v) { k++; m.set(x, v - 1); } });
    return 2 * k / (A.length + B.length);
  }
  function badAI(s, recent) {
    if (!s || s.length < 2) return 'empty';
    if (/[A-Za-z]{3,}/.test(s)) return 'latin';
    if (/플레이어|게임|친밀도|수치|프롬프트|캐릭터|\bAI\b|대사/.test(s)) return 'meta';
    if (recent.some((r) => simLine(r, s) > 0.55)) return 'repeat';
    return '';
  }
  // base: 자료 대사(실패 시 그대로). o.ai/o.scene 프롬프트는 보여 줄 때(vnNext) 최근 대화까지 넣어 만든다.
  function aiLine(base, sit, e, tier, extra) {
    if (!base || !base.text || !(MON[base.spk] || HERO[base.spk])) return base;
    return Object.assign({}, base, { ai: { tier: tier || 'fast', sit, e, extra: extra || '' } });
  }
  function aiScene(base, sit, e, tier, extra) {
    if (!base || !(MON[base.spk] || HERO[base.spk])) return base;
    return Object.assign({}, base, { scene: { tier: tier || 'fast', sit, e, extra: extra || '' } });
  }
  const SCENE_SCHEMA = { type: 'object', properties: { lines: { type: 'array', items: { type: 'object', properties: { s: { type: 'string', enum: ['c', 'm'] }, ex: { type: 'string' }, t: { type: 'string' } }, required: ['s', 'ex', 't'], additionalProperties: false } } }, required: ['lines'], additionalProperties: false };
  function aiPrompt(o, s, hist, scene) {
    const q = scene ? o.scene : o.ai, code = o.spk;
    const parts = [voiceCard(code), '', '상황: ' + (SIT_KO[q.sit] || q.sit)];
    const cw = ctxWords(s, q.e); if (cw) parts.push(cw);
    if (q.extra) parts.push(q.extra);
    if (hist.length) parts.push('', '방금까지의 대화(흐름만 참고, 되풀이 금지):', ...hist.map((x) => '- ' + x));
    const mine = LM.texts(code, 12); if (mine.length) parts.push('', '이 인물이 최근에 한 말(다시 쓰지 말 것):', ...mine.map((x) => '- ' + x));
    if (o.fb) parts.push('', '분위기 참고용 자료 문장(고쳐 쓰지 말고 새로 쓸 것): ' + o.fb);
    if (scene) parts.push('', '그 인물(c)의 표정 목록: ' + (PORTRAITS[code] || EXPR_ALL).join(', '), '마왕(m)의 표정 목록: ' + PORTRAITS.master.join(', '), '', '이 상황으로 이어지는 짧은 장면을 JSON으로 쓰세요. 첫 줄은 그 인물(c)이 엽니다.');
    else parts.push('', '이 인물의 대사 한 줄만 쓰세요.');
    return parts.join('\n');
  }
  function parseScene(r, code, recent) {
    const ls = r && Array.isArray(r.lines) ? r.lines : []; const exs = PORTRAITS[code] || EXPR_ALL, mex = PORTRAITS.master;
    const out = []; const seen = recent.slice();
    for (const l of ls.slice(0, 6)) {
      const m = l && l.s === 'm'; const t = cleanAI(l && l.t);
      if (badAI(t, seen)) continue; seen.push(t);
      out.push({ spk: m ? 'M' : code, ex: (m ? mex : exs).includes(l.ex) ? l.ex : 'neutral', text: t, mk: 1 });
    }
    return out.length >= 2 && out.some((x) => x.spk === code) ? out : [];
  }
  /* ================= 초상화 ================= */
  const MASTER_COL = ['#16121c', '#1a1020', '#e3ae45', '#f6e2dc'];
  const EXPR_KO = { neutral: '기본', smile: '웃음', happy: '기쁨', angry: '화남', sad: '슬픔', surprised: '놀람', shy: '부끄러움', serious: '진지', hurt: '다침', flustered: '당황', awakened: '각성' };
  const HORNS = { master: 2, dragonknight: 2, dragonkid: 2, butler: 2, succubus: 2, oni: 1, minotaur: 3, imp: 2, chimera: 1 };
  const EARS = { beastqueen: 1, werewolf: 1, kitsune: 1, chimera: 1, minotaur: 1 };
  const HATS = { abysswitch: 1, witchapprentice: 1, explorer: 2, elemental: 1, hunter: 2, bard: 2, mushroom: 3 };
  const HALO = { saint: 1, ghost: 0 };
  const colOf = (k) => (k === 'master' || k === 'M' ? MASTER_COL : MON[k] ? MON[k].col : HERO[k] ? HERO[k].col : k === 'stonegolem' ? ['#5a6a5a', '#7a7a80', '#60d0c0', '#9a9aa0'] : ['#888', '#666', '#aaa', '#ddd']);
  const nameOf = (k) => (k === 'M' || k === 'master' ? '마왕' : unitName(k));
  const PIMG = {};
  function portraitImg(code, ex) {
    const list = PORTRAITS[code]; if (!list || !list.includes(ex)) return null;
    const key = code + '_' + ex; let p = PIMG[key];
    if (p === undefined) { const im = new Image(); p = PIMG[key] = { im, ok: 0 }; im.onload = () => { p.ok = 1; window.dispatchEvent(new Event('dk-img')); }; im.onerror = () => { p.ok = -1; }; im.src = IMG_DIR + key + '.webp'; }
    return p.ok === 1 ? p.im : p.ok === -1 ? null : 'wait';
  }
  const PH = {};
  function placeholder(code, ex) {
    const key = code + '_' + ex; if (PH[key]) return PH[key];
    const c = document.createElement('canvas'); c.width = 320; c.height = 460; const g = c.getContext('2d');
    const col = colOf(code);
    // 배경: 은은한 그라데이션 + 빛
    const bg = g.createLinearGradient(0, 0, 0, 460); bg.addColorStop(0, '#2a2232'); bg.addColorStop(0.6, '#1b1622'); bg.addColorStop(1, '#120e18');
    g.fillStyle = bg; g.fillRect(0, 0, 320, 460);
    const glow = g.createRadialGradient(160, 170, 10, 160, 190, 230); glow.addColorStop(0, col[2] + (ex === 'awakened' ? '88' : '44')); glow.addColorStop(1, 'transparent');
    g.fillStyle = glow; g.fillRect(0, 0, 320, 460);
    // 실루엣 경로
    const sil = () => {
      g.beginPath();
      g.moveTo(30, 460); g.bezierCurveTo(40, 360, 90, 320, 136, 300); // 왼어깨
      g.lineTo(140, 262); g.bezierCurveTo(108, 250, 100, 205, 104, 170); // 목·턱
      g.bezierCurveTo(104, 110, 136, 88, 160, 88); g.bezierCurveTo(184, 88, 216, 110, 216, 170);
      g.bezierCurveTo(220, 205, 212, 250, 180, 262); g.lineTo(184, 300);
      g.bezierCurveTo(230, 320, 280, 360, 290, 460); g.closePath();
    };
    // 긴 머리(뒤)
    const hg = g.createLinearGradient(0, 90, 0, 420); hg.addColorStop(0, col[0]); hg.addColorStop(1, '#0c0a10');
    g.fillStyle = hg; g.globalAlpha = 0.85;
    g.beginPath(); g.moveTo(100, 150); g.bezierCurveTo(70, 240, 80, 340, 60, 400); g.lineTo(260, 400); g.bezierCurveTo(240, 340, 250, 240, 220, 150); g.closePath(); g.fill();
    g.globalAlpha = 1;
    // 몸 실루엣
    const bodyG = g.createLinearGradient(0, 100, 0, 460); bodyG.addColorStop(0, '#0e0b13'); bodyG.addColorStop(1, col[1]);
    g.fillStyle = bodyG; sil(); g.fill();
    // 테두리 빛(림 라이트)
    g.save(); sil(); g.clip(); g.strokeStyle = col[2]; g.globalAlpha = 0.55; g.lineWidth = 6; sil(); g.stroke(); g.restore();
    g.strokeStyle = col[2] + 'aa'; g.lineWidth = 1.5; sil(); g.stroke();
    // 앞머리 윤곽
    g.fillStyle = col[0]; g.globalAlpha = 0.9; g.beginPath(); g.moveTo(102, 168); g.bezierCurveTo(104, 100, 140, 82, 160, 84); g.bezierCurveTo(186, 82, 218, 104, 218, 168); g.bezierCurveTo(200, 128, 176, 118, 160, 124); g.bezierCurveTo(140, 116, 116, 132, 102, 168); g.fill(); g.globalAlpha = 1;
    // 장식
    g.fillStyle = '#0c0a10'; g.strokeStyle = col[2]; g.lineWidth = 1.5;
    const hn = HORNS[code];
    if (hn) (hn === 1 ? [0] : [-1, 1]).forEach((sd) => { const bx = 160 + sd * 38; g.beginPath(); g.moveTo(bx - 7, 106); g.quadraticCurveTo(bx + sd * 34, 72, bx + sd * 30, 30); g.quadraticCurveTo(bx + sd * 14, 76, bx + 7, 102); g.closePath(); g.fill(); g.stroke(); });
    if (EARS[code]) [-1, 1].forEach((sd) => { g.beginPath(); g.moveTo(160 + sd * 34, 104); g.lineTo(160 + sd * 66, 52); g.lineTo(160 + sd * 64, 118); g.closePath(); g.fillStyle = col[0]; g.fill(); g.stroke(); });
    const ht = HATS[code];
    if (ht === 1) { g.fillStyle = '#0c0a10'; g.beginPath(); g.moveTo(54, 118); g.quadraticCurveTo(160, 96, 266, 118); g.quadraticCurveTo(200, 104, 196, 96); g.lineTo(150, 6); g.lineTo(126, 98); g.quadraticCurveTo(100, 104, 54, 118); g.fill(); g.stroke(); }
    if (ht === 2) { g.fillStyle = '#120e14'; g.beginPath(); g.ellipse(160, 104, 100, 16, 0, 0, 7); g.fill(); g.stroke(); g.fillRect(114, 60, 92, 44); g.strokeRect(114, 60, 92, 44); }
    if (ht === 3) { g.fillStyle = col[2] + 'cc'; g.beginPath(); g.ellipse(160, 98, 112, 50, 0, Math.PI, 0); g.fill(); }
    if (code === 'master' || code === 'M' || code === 'nightduchess' || (HERO[code] && HERO[code].boss)) { g.fillStyle = '#e3ae45'; g.beginPath(); g.moveTo(134, 92); g.lineTo(140, 70); g.lineTo(150, 86); g.lineTo(160, 62); g.lineTo(170, 86); g.lineTo(180, 70); g.lineTo(186, 92); g.closePath(); g.fill(); }
    if (HALO[code] !== undefined && code === 'saint') { g.strokeStyle = '#f8e8a0'; g.lineWidth = 3; g.beginPath(); g.ellipse(160, 62, 54, 12, 0, 0, 7); g.stroke(); }
    // 아주 절제된 눈빛 두 점
    g.fillStyle = col[2]; g.globalAlpha = 0.8; g.beginPath(); g.ellipse(140, 180, 5, 2, 0, 0, 7); g.ellipse(180, 180, 5, 2, 0, 0, 7); g.fill(); g.globalAlpha = 1;
    // 목걸이 장식
    g.strokeStyle = col[2] + 'cc'; g.lineWidth = 2; g.beginPath(); g.moveTo(128, 304); g.quadraticCurveTo(160, 336, 192, 304); g.stroke();
    // 액자 틀
    g.strokeStyle = 'rgba(227,174,69,.45)'; g.lineWidth = 1; g.strokeRect(10.5, 10.5, 299, 439);
    // 이름표
    const ng = g.createLinearGradient(0, 380, 0, 460); ng.addColorStop(0, 'transparent'); ng.addColorStop(1, 'rgba(8,6,12,.92)'); g.fillStyle = ng; g.fillRect(0, 370, 320, 90);
    g.fillStyle = '#f2e9d8'; g.font = '700 21px "Gowun Batang", "IBM Plex Sans KR", serif'; g.textAlign = 'center'; g.fillText(nameOf(code), 160, 424);
    g.fillStyle = '#c8b890'; g.font = '12px "IBM Plex Sans KR", sans-serif'; g.fillText('「임시 그림」 · ' + (EXPR_KO[ex] || ex), 160, 445);
    PH[key] = c; return c;
  }
  function portraitFor(code, ex) { // 이미지 → 같은 캐릭터 neutral → 임시 그림
    if (code === 'M') code = 'master';
    let im = portraitImg(code, ex);
    if (im && im !== 'wait') return im;
    if (im === 'wait') { const n0 = portraitImg(code, 'neutral'); if (n0 && n0 !== 'wait') return n0; return placeholder(code, ex); }
    const n = portraitImg(code, 'neutral'); if (n && n !== 'wait') return n;
    return placeholder(code, ex);
  }

  /* ================= SD 캐릭터 ================= */
  function drawChibi(g, x, y, sz, k, o) {
    o = o || {};
    const col = colOf(k), M = MON[k], Hh = HERO[k];
    const rk = M ? M.rk : Hh ? (Hh.ai === 'r' ? 'b' : Hh.ai === 'h' ? 's' : 'f') : k === 'master' ? 'm' : 'f';
    g.save(); g.translate(x, y); if (o.fl) g.scale(-1, 1);
    const s = sz / 24, bob = o.bob || 0;
    g.scale(s, s); g.translate(0, bob);
    if (o.aw || o.boss) { g.fillStyle = o.boss ? 'rgba(255,230,120,.28)' : 'rgba(255,200,90,.25)'; g.beginPath(); g.arc(0, -2, 15, 0, 7); g.fill(); }
    g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(0, 11, 8, 2.5, 0, 0, 7); g.fill();
    // 무기
    g.lineWidth = 2; g.strokeStyle = col[2];
    if (rk === 'f') { g.beginPath(); g.moveTo(6, 6); g.lineTo(12, -6); g.stroke(); }
    else if (rk === 'b') { g.beginPath(); g.arc(8, 2, 6, -1.3, 1.3); g.stroke(); }
    else if (rk === 'm' || rk === 's') { g.strokeStyle = '#8a6a4a'; g.beginPath(); g.moveTo(8, 10); g.lineTo(9, -8); g.stroke(); g.fillStyle = col[2]; g.beginPath(); g.arc(9, -9, 2.4, 0, 7); g.fill(); }
    else { g.strokeStyle = '#8a8a90'; g.beginPath(); g.moveTo(6, 8); g.lineTo(10, -4); g.stroke(); }
    // 몸
    g.fillStyle = '#1e1620'; g.beginPath(); g.ellipse(-2.8, 10.4, 2.2, 1.3, 0, 0, 7); g.ellipse(2.8, 10.4, 2.2, 1.3, 0, 0, 7); g.fill(); // 신발
    g.fillStyle = col[1]; g.strokeStyle = 'rgba(16,8,16,.8)'; g.lineWidth = 0.8; g.beginPath(); g.moveTo(-6, 10); g.lineTo(-4.5, 1); g.quadraticCurveTo(0, -1, 4.5, 1); g.lineTo(6, 10); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = 'rgba(255,255,255,.12)'; g.beginPath(); g.moveTo(-4, 9); g.lineTo(-3.2, 2); g.lineTo(-1.5, 1.4); g.lineTo(-2, 9); g.fill(); // 옷 주름 빛
    g.fillStyle = col[2]; g.fillRect(-4, 3, 8, 1.4); g.fillStyle = '#e3ae45'; g.fillRect(-0.7, 2.9, 1.4, 1.6); // 허리띠·버클
    g.fillStyle = col[3]; g.beginPath(); g.arc(-5.6, 5.5, 1.6, 0, 7); g.arc(5.6, 5.5, 1.6, 0, 7); g.fill(); // 손
    // 머리
    g.fillStyle = col[0]; g.strokeStyle = 'rgba(16,8,16,.8)'; g.lineWidth = 0.8; g.beginPath(); g.arc(0, -6, 7.5, 0, 7); g.fill(); g.stroke();
    g.fillRect(-7.5, -6, 3, 9); g.fillRect(4.5, -6, 3, 9);
    g.fillStyle = col[3]; g.beginPath(); g.arc(0, -5, 5.6, 0, 7); g.fill();
    g.fillStyle = col[0]; g.beginPath(); g.arc(0, -8.2, 5.8, Math.PI, 0); g.fill();
    if (HORNS[k]) { g.fillStyle = k === 'oni' ? '#e05030' : '#241a20'; (HORNS[k] === 1 ? [0] : [-1, 1]).forEach((sd) => { g.beginPath(); g.moveTo(sd * 3 - 1, -12); g.lineTo(sd * 6, -17); g.lineTo(sd * 4 + 1, -11.5); g.fill(); }); }
    if (EARS[k]) { g.fillStyle = col[0]; [-1, 1].forEach((sd) => { g.beginPath(); g.moveTo(sd * 3, -12); g.lineTo(sd * 6.5, -16.5); g.lineTo(sd * 7, -10); g.fill(); }); }
    if (HATS[k] === 1) { g.fillStyle = '#1e1828'; g.beginPath(); g.moveTo(-9, -10); g.lineTo(9, -10); g.lineTo(1, -22); g.fill(); }
    if (Hh && !Hh.boss && !Hh.summon) { g.strokeStyle = 'rgba(160,210,255,.9)'; g.lineWidth = 1; g.beginPath(); g.arc(0, -6, 8.3, 0, 7); g.stroke(); }
    if (Hh && Hh.boss) { g.fillStyle = '#f0d060'; g.beginPath(); g.moveTo(-4, -14); g.lineTo(-2, -17); g.lineTo(0, -14.5); g.lineTo(2, -17); g.lineTo(4, -14); g.fill(); }
    if (k === 'master') { g.fillStyle = '#e3ae45'; g.beginPath(); g.moveTo(-4, -13); g.lineTo(-2, -16); g.lineTo(0, -13.5); g.lineTo(2, -16); g.lineTo(4, -13); g.fill(); g.fillStyle = '#8a1a30'; g.fillRect(-7, 2, 2, 8); g.fillRect(5, 2, 2, 8); }
    // 눈
    g.fillStyle = o.hurt ? '#c03040' : '#2a1a24';
    if (o.sleep) { g.fillRect(-3.2, -5, 2.2, 0.8); g.fillRect(1, -5, 2.2, 0.8); }
    else { g.fillRect(-3.2, -6.4, 2, 2.8); g.fillRect(1.2, -6.4, 2, 2.8); g.fillStyle = 'rgba(255,255,255,.85)'; g.fillRect(-2.7, -6.2, 0.8, 0.8); g.fillRect(1.7, -6.2, 0.8, 0.8); }
    g.fillStyle = 'rgba(255,120,140,.32)'; g.beginPath(); g.ellipse(-4.2, -2.8, 1.4, 0.8, 0, 0, 7); g.ellipse(4.2, -2.8, 1.4, 0.8, 0, 0, 7); g.fill(); // 볼
    g.fillStyle = 'rgba(255,255,255,.22)'; g.beginPath(); g.ellipse(-2.6, -11, 2.4, 1, -0.4, 0, 7); g.fill(); // 머리 윤기
    g.restore();
  }

  /* ================= 화면 ================= */
  const CSS = `
  .dk-ui{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body),sans-serif;color:var(--ink)}
  .dk-ui *{box-sizing:border-box}
  .dk-ui button{pointer-events:auto}
  .dk-top{position:absolute;left:8px;right:8px;top:6px;height:40px;display:flex;gap:6px;align-items:center;pointer-events:auto;overflow:hidden}
  .dk-chip{display:flex;align-items:center;gap:5px;height:34px;padding:0 10px;border-radius:9px;background:rgba(23,19,31,.86);border:1px solid rgba(227,174,69,.25);font-size:13px;white-space:nowrap}
  .dk-chip b{font-family:var(--f-mono),monospace;font-weight:600}
  .dk-chip.ph{background:#4a1420;border-color:#e3ae45;font-weight:700}
  .dk-side{position:absolute;right:8px;top:52px;bottom:8px;width:360px;display:flex;flex-direction:column;gap:6px;pointer-events:auto;background:rgba(18,14,24,.94);border:1px solid rgba(227,174,69,.3);border-radius:12px;padding:8px;overflow:hidden}
  .dk-tabs{display:flex;gap:4px;flex:none}
  .dk-tabs button{flex:1;min-height:44px;padding:2px 4px;font-size:12px;border-radius:8px;background:var(--surface-2);color:var(--ink);border:1px solid transparent;cursor:pointer;position:relative}
  .dk-tabs button.on{background:#5a1a2a;border-color:var(--brass)}
  .dk-body{flex:1;overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column;gap:6px;padding-right:2px;min-height:0}
  .dk-foot{flex:none;display:flex;gap:6px}
  .dk-btn{min-height:44px;border-radius:9px;border:1px solid rgba(227,174,69,.35);background:var(--surface-2);color:var(--ink);font:600 13px var(--f-body),sans-serif;padding:4px 10px;cursor:pointer;position:relative}
  .dk-btn:hover{border-color:var(--brass)}
  .dk-btn.pri{background:linear-gradient(#8a2d4f,#5a1a32);border-color:var(--brass);font-size:15px}
  .dk-btn.on{background:#5a1a2a;border-color:var(--brass);box-shadow:0 0 0 1px var(--brass) inset}
  .dk-btn:disabled{opacity:.45;cursor:default}
  .dk-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:5px}
  .dk-grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}
  .dk-item{display:flex;align-items:center;gap:6px;min-height:44px;padding:4px 7px;border-radius:9px;background:var(--surface);border:1px solid transparent;cursor:pointer;font-size:12px;text-align:left;color:var(--ink);position:relative}
  .dk-item:hover{border-color:rgba(227,174,69,.5)}
  .dk-item.on{border-color:var(--brass);background:#3a1a2a}
  .dk-item.lock{opacity:.45}
  .dk-item .ic{font-size:18px;width:22px;text-align:center;flex:none}
  .dk-item .nm{font-weight:600;line-height:1.2}
  .dk-room{min-height:46px;padding:3px 7px}.dk-room .ric{flex:none;width:34px;height:34px;border-radius:8px;border:1px solid;display:flex;align-items:center;justify-content:center;font-size:19px}
  .dk-room .eff{font-size:11px;color:#d8cce0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.dk-item.lock .ric{filter:grayscale(1)}
  .dk-item .sub{color:var(--muted);font-size:11px;font-family:var(--f-mono),monospace}
  .dk-h{font:700 13px var(--f-body),sans-serif;color:var(--brass);margin:4px 0 0}
  .dk-p{font-size:12px;color:var(--muted);line-height:1.45;margin:0}
  .dk-card{background:var(--surface);border-radius:10px;padding:8px;display:flex;flex-direction:column;gap:6px;font-size:12px}
  .dk-row{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
  .dk-bar{height:6px;border-radius:3px;background:#2a2234;overflow:hidden;flex:1;min-width:40px}
  .dk-bar>i{display:block;height:100%}
  .dk-mon{display:flex;gap:7px;align-items:center;min-height:48px;padding:4px 6px;border-radius:9px;background:var(--surface);cursor:pointer;border:1px solid transparent;position:relative}
  .dk-mon.on{border-color:var(--brass);background:#3a1a2a}
  .dk-mon canvas{flex:none;border-radius:7px;background:#2a2234}
  .dk-mon .info{flex:1;min-width:0;font-size:12px;display:flex;flex-direction:column;gap:2px}
  .dk-mon .info b{font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dk-tip{position:absolute;z-index:60;max-width:300px;padding:8px 10px;border-radius:9px;background:rgba(14,10,20,.96);border:1px solid var(--brass);font-size:12px;line-height:1.45;pointer-events:none;white-space:pre-line;display:none}
  .dk-vn{position:absolute;left:0;right:0;bottom:0;height:220px;z-index:40;pointer-events:auto;background:linear-gradient(transparent,rgba(10,6,14,.92) 26%,rgba(10,6,14,.98));display:none;cursor:pointer}
  .dk-vn .pt{position:absolute;left:24px;bottom:16px;width:290px;height:420px;border-radius:14px;overflow:hidden;border:1px solid rgba(227,174,69,.5);box-shadow:0 10px 40px rgba(0,0,0,.6);background:#2a2234}
  .dk-vn .pt canvas{width:100%;height:100%;display:block}
  .dk-vn .box{position:absolute;left:330px;right:24px;bottom:18px;height:160px;border-radius:14px;background:rgba(28,20,36,.95);border:1px solid rgba(227,174,69,.45);padding:28px 22px 12px}
  .dk-vn .nm{position:absolute;left:18px;top:-17px;padding:5px 16px;border-radius:9px;font:700 16px var(--f-body),sans-serif;background:#5a1a32;border:1px solid var(--brass)}
  .dk-vn .tx{font-size:18px;line-height:1.6;min-height:58px;white-space:pre-wrap}
  .dk-vn .ctl{position:absolute;right:12px;bottom:10px;display:flex;gap:6px}
  .dk-vn .ctl button{min-height:44px;min-width:64px;font-size:12px}
  .dk-vn.narr .pt{display:none}.dk-vn.narr .box{left:24px}.dk-vn.narr .tx{font-style:italic;color:#d8cce8}
  .dk-modal{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:35;pointer-events:auto;background:rgba(20,14,28,.97);border:1px solid var(--brass);border-radius:16px;padding:18px;display:none;max-height:calc(100% - 64px);top:calc(50% + 22px);overflow-y:auto;box-shadow:0 20px 60px rgba(0,0,0,.6)}
  .dk-log{position:absolute;left:50%;top:52px;bottom:12px;transform:translateX(-50%);width:min(720px,90%);z-index:45;pointer-events:auto;background:rgba(14,10,20,.98);border:1px solid var(--brass);border-radius:14px;padding:14px;overflow-y:auto;display:none;font-size:14px;line-height:1.6}
  .dk-sk{display:grid;grid-template-columns:repeat(3,1fr);gap:5px}
  .dk-sk button{min-height:62px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;font-size:11px;padding:3px}
  .dk-sk button .i{font-size:20px}
  .dk-sk button span{white-space:nowrap}
  .dk-pick{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}
  .dk-pk{display:flex;flex-direction:column;gap:6px;padding:8px;border-radius:12px;background:var(--surface);border:2px solid transparent;cursor:pointer;font-size:12px;color:var(--ink);text-align:left;min-height:44px}
  .dk-pk.on{border-color:var(--brass);background:#3a1a2a}
  .dk-pk.off{opacity:.4;cursor:default}
  .dk-pk canvas{height:min(22vh,220px);width:auto;aspect-ratio:2/3;align-self:center;border-radius:8px;background:#2a2234}
  .dk-ready{display:flex;gap:4px;flex-wrap:wrap;font-size:11px}
  .dk-lg{display:flex;gap:8px;font-size:13px;line-height:1.5;padding:2px 0}.dk-lg b{flex:none;min-width:84px}.dk-lg.n span{font-style:italic;color:#c8bcd8}
  .dk-feed{display:flex;flex-direction:column;gap:2px;font-size:12px;background:var(--surface);border-radius:9px;padding:6px 8px}
  .dk-feed div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .dk-hit{position:absolute;inset:0;pointer-events:none;box-shadow:inset 0 0 60px 10px rgba(220,30,60,.55);opacity:0;transition:opacity .5s;z-index:20}
  .dk-todo{position:absolute;left:12px;top:56px;width:300px;z-index:12;pointer-events:auto;display:none;flex-direction:column;gap:5px;padding:8px;border-radius:12px;background:rgba(18,14,24,.9);border:1px solid rgba(227,174,69,.3);max-height:calc(100% - 76px);overflow-y:auto}
  .dk-todo-i{display:flex;gap:7px;align-items:center;min-height:40px;padding:4px 8px;border-radius:9px;background:var(--surface);border:1px solid transparent;color:var(--ink);font:600 12px var(--f-body),sans-serif;text-align:left;cursor:pointer}
  .dk-todo-i:hover{border-color:var(--brass)}.dk-todo-i .ic{font-size:16px;width:20px;text-align:center;flex:none}
  .dk-banner{position:absolute;left:50%;top:70px;transform:translateX(-50%);z-index:30;padding:10px 22px;border-radius:12px;background:rgba(20,10,20,.9);border:1px solid var(--brass);font:700 18px var(--f-body),sans-serif;pointer-events:none;display:none;text-align:center;white-space:nowrap}
  `;

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const style = L.h('style', { text: CSS });
    const ui = L.h('div', { class: 'dk-ui' });
    root.append(style, ui);
    const mine = () => api.mySeats();
    let me = mine().length ? mine()[0] : 0;
    let st = null, prevU = new Map(), curU = new Map(), tUpd = 0, lastEv = -1, first = true;
    let tab = 'build', tool = 'look', selRoom = 'c', selTrap = 'A', selU = null, msSel = null, hover = -1, drag = null, paused = false;
    let lastTickN = -1, lastTickAt = 0, statKey = '', statC = null, Z = 24, OX = 0, OY = 0;
    const fx = [], bubbles = [], vnQ = [], vnLog = [];
    // 카메라(휠 확대·WASD/방향키/가장자리/가운데 버튼 끌기), 끌기 미리보기, 침입 소식
    let zoom = 1, camX = W / 2, camY = H / 2, AW = 0, AH = 0, panDrag = null, pendCard = null, mouse = null, prevKey = '', prevRes = null;
    const feed = []; let lastMhp = null, hitAt = 0;
    const pushFeed = (t) => { feed.push(t); if (feed.length > 7) feed.shift(); };
    // 대화 설정(이 기기): 글자 속도·자동 넘김
    const VNS = (() => { try { return Object.assign({ sp: 'normal', auto: false }, JSON.parse(localStorage.getItem('lounge.dk.vn') || '{}')); } catch (e) { return { sp: 'normal', auto: false }; } })();
    const saveVNS = () => { try { localStorage.setItem('lounge.dk.vn', JSON.stringify(VNS)); } catch (e) {} };
    const CPS = { slow: 22, normal: 42, fast: 85, instant: 1e6 }, SP_KO = { slow: '느리게', normal: '보통', fast: '빠르게', instant: '바로' };
    let vn = null, banner = null, stopLoop = null;
    const PW = 360;
    const iCan = () => api.canAct(me);
    const isSpect = () => !mine().length;
    const ticker = () => api.isHost && mine().length > 0;
    const soloPause = () => !api.online;

    /* ---------- DOM ---------- */
    const top = L.h('div', { class: 'dk-top' });
    const side = L.h('div', { class: 'dk-side' });
    const tabs = L.h('div', { class: 'dk-tabs' });
    const body = L.h('div', { class: 'dk-body' });
    const foot = L.h('div', { class: 'dk-foot' });
    side.append(tabs, body, foot);
    const tip = L.h('div', { class: 'dk-tip' });
    const modal = L.h('div', { class: 'dk-modal' });
    const logEl = L.h('div', { class: 'dk-log' });
    const ban = L.h('div', { class: 'dk-banner' });
    const todoEl = L.h('div', { class: 'dk-todo' });
    // 대화 창
    const vnEl = L.h('div', { class: 'dk-vn' });
    const vnPt = L.h('div', { class: 'pt' }); const vnCv = L.h('canvas'); vnCv.width = 480; vnCv.height = 696; vnPt.append(vnCv);
    const vnBox = L.h('div', { class: 'box' }); const vnNm = L.h('div', { class: 'nm' }); const vnTx = L.h('div', { class: 'tx' });
    const vnCtl = L.h('div', { class: 'ctl' });
    const bNext = L.h('button', { class: 'dk-btn', 'data-action': 'adv', text: '다음 ▶', onclick: (e) => { e.stopPropagation(); vnAdvance(); } });
    const bSkip = L.h('button', { class: 'dk-btn', 'data-action': 'skip', 'data-tip': '지금 나오는 대화를 모두 건너뛰어요(기록엔 남아요).', text: '모두 건너뛰기', onclick: (e) => { e.stopPropagation(); vnSkip(); } });
    const bAuto = L.h('button', { class: 'dk-btn', 'data-action': 'auto', 'data-tip': '자동 넘김: 글이 다 나오면 잠시 뒤 다음 줄로.', onclick: (e) => { e.stopPropagation(); toggleAuto(); } });
    const paintAuto = () => { bAuto.textContent = VNS.auto ? '자동 ✓' : '자동'; bAuto.classList.toggle('on', !!VNS.auto); };
    function toggleAuto() { VNS.auto = !VNS.auto; saveVNS(); paintAuto(); api.toast(VNS.auto ? '자동 넘김 켬' : '자동 넘김 끔'); if (tab === 'ms' && !vn) renderSide(); }
    paintAuto();
    const bLog = L.h('button', { class: 'dk-btn', 'data-action': 'log', text: '기록', onclick: (e) => { e.stopPropagation(); toggleLog(); } });
    vnCtl.append(bLog, bAuto, bSkip, bNext); vnBox.append(vnNm, vnTx, vnCtl); vnEl.append(vnPt, vnBox);
    vnEl.onclick = () => vnAdvance();
    const hitEl = L.h('div', { class: 'dk-hit' });
    ui.append(hitEl, top, side, todoEl, modal, ban, vnEl, logEl, tip);

    const h = L.h;
    const btn = (label, on, o) => { o = o || {}; const b = h('button', { class: 'dk-btn' + (o.cls ? ' ' + o.cls : ''), onclick: (e) => { e.stopPropagation(); on(); } }); b.innerHTML = label; if (o.act) b.setAttribute('data-action', o.act); if (o.tip) b.setAttribute('data-tip', o.tip); if (o.dis) b.disabled = true; if (o.style) Object.assign(b.style, o.style); return b; };
    const tipOf = (el, t) => { el.setAttribute('data-tip', t); return el; };

    /* ---------- 툴팁 ---------- */
    let tipEl = null;
    function showTip(text, x, y) {
      if (!text) { tip.style.display = 'none'; return; }
      tip.textContent = text; tip.style.display = 'block';
      const r = root.getBoundingClientRect(); const tw = tip.offsetWidth, th = tip.offsetHeight;
      let lx = x - r.left + 14, ly = y - r.top + 16;
      if (lx + tw > r.width - 6) lx = x - r.left - tw - 10; if (ly + th > r.height - 6) ly = y - r.top - th - 10;
      tip.style.left = Math.max(4, lx) + 'px'; tip.style.top = Math.max(4, ly) + 'px';
    }
    const onOver = (e) => { const t = e.target.closest && e.target.closest('[data-tip]'); tipEl = t; if (t) showTip(t.getAttribute('data-tip'), e.clientX, e.clientY); else if (hover < 0) showTip(''); };
    const onMoveTip = (e) => { if (tipEl) showTip(tipEl.getAttribute('data-tip'), e.clientX, e.clientY); };
    ui.addEventListener('mouseover', onOver); ui.addEventListener('mousemove', onMoveTip);
    ui.addEventListener('mouseleave', () => { tipEl = null; showTip(''); });

    /* ---------- 미니 초상 ---------- */
    function mini(k, ex, w, hgt) {
      const c = h('canvas'); c.width = w * 2; c.height = hgt * 2; c.style.width = w + 'px'; c.style.height = hgt + 'px';
      const g = c.getContext('2d'); const draw = () => { const im = portraitFor(k, ex || 'neutral'); g.clearRect(0, 0, c.width, c.height); try { const iw = im.naturalWidth || im.width, ih = im.naturalHeight || im.height; const sc = Math.max(c.width / iw, c.height / (ih * 0.55)); g.drawImage(im, (c.width - iw * sc) / 2, -ih * sc * 0.04, iw * sc, ih * sc); } catch (e) {} };
      draw(); c._draw = draw; minis.push(c); return c;
    }
    const minis = [];
    const onImg = () => { minis.forEach((c) => c.isConnected && c._draw()); if (vn) drawVNPortrait(); };
    window.addEventListener('dk-img', onImg);

    /* ---------- 대화(비주얼 노벨) ---------- */
    function resolveSpk(spk) { if (spk && spk[0] === '@') { const k = st && st.pk[+spk.slice(1)]; return k || 'dragonknight'; } return spk; }
    function queueLines(lines) { lines.forEach((l) => { const o = typeof l === 'string' ? lineOf(l) : l; o.spk = resolveSpk(o.spk); if (o.text) vnQ.push(o); }); if (!vn) vnNext(); }
    const logLine = (o) => { const narr = !o.spk || o.spk === 'N'; vnLog.push({ k: narr ? '' : o.spk, t: o.text, ai: !!o.mk || (o.ai && !o.wait && o.text !== o.fb) }); if (vnLog.length > 300) vnLog.shift(); };
    const histLines = () => vnLog.slice(-10).map((x) => (x.k ? (x.k === 'M' ? '마왕' : nameOf(x.k)) + ': ' : '') + x.t);
    const aiRecent = (code) => LM.texts(code, 30).concat(vnLog.slice(-30).map((x) => x.t));
    function vnNext() {
      vn = vnQ.shift() || null;
      if (!vn) { vnEl.style.display = 'none'; renderSide(); return; }
      vn.shown = 0; vn.full = 0; vn.t0 = performance.now();
      vnEl.style.display = 'block';
      const narr = !vn.spk || vn.spk === 'N';
      vnEl.classList.toggle('narr', narr);
      vnNm.style.display = narr ? 'none' : 'block';
      vnNm.textContent = narr ? '' : nameOf(vn.spk);
      if (!narr) { const c = colOf(vn.spk); vnNm.style.background = c[1]; }
      vnTx.textContent = '';
      if (vn.mk && !narr) vnNm.textContent = nameOf(vn.spk) + ' ✦';
      const aiOn = !!(L.ai && L.ai.enabled && L.ai.enabled('dkeeper'));
      if (vn.scene && aiOn) {
        const o = vn; o.fb = o.text; o.text = ''; o.wait = 1; vnTx.textContent = '…';
        const recent = aiRecent(o.spk);
        L.ai.ask({ tier: o.scene.tier, system: DK_SCENE_SYS, prompt: aiPrompt(o, st, histLines(), true), maxTokens: 700, json: SCENE_SCHEMA, timeout: 20000 }).then((r) => {
          if (o.cancel) return; o.wait = 0; const ls = parseScene(r, o.spk, recent);
          if (!ls.length) { o.text = o.fb; logLine(o); return; }
          ls.forEach((x) => { if (x.spk !== 'M') LM.use(x.spk, x.text); });
          if (vn === o) { vnQ.unshift(...ls); vnNext(); } });
      } else if (vn.ai && aiOn) {
        const o = vn, fb = o.text; o.fb = fb; o.text = ''; o.wait = 1; vnTx.textContent = '…';
        const recent = aiRecent(o.spk);
        L.ai.ask({ tier: o.ai.tier, system: DK_SYS, prompt: aiPrompt(o, st, histLines(), false), maxTokens: 160, stream: (t) => { if (!o.cancel) o.text = cleanAI(t); } }).then((r) => {
          if (o.cancel) return; o.wait = 0; const t = r && cleanAI(r); const bad = badAI(t, recent);
          o.text = bad ? fb : t;
          if (!bad) { LM.use(o.spk, t); if (vn === o) vnNm.textContent = nameOf(o.spk) + ' ✦'; }
          if (vn === o && o.shown > o.text.length) o.shown = 0;
          logLine(o); });
      } else logLine(vn);
      drawVNPortrait();
    }
    function drawVNPortrait() {
      if (!vn || !vn.spk || vn.spk === 'N') return;
      const g = vnCv.getContext('2d'); g.fillStyle = '#d8d4dc'; g.fillRect(0, 0, vnCv.width, vnCv.height);
      const im = portraitFor(vn.spk, vn.ex);
      try { const iw = im.naturalWidth || im.width, ih = im.naturalHeight || im.height; const sc = Math.max(vnCv.width / iw, vnCv.height / ih); g.drawImage(im, (vnCv.width - iw * sc) / 2, 0, iw * sc, ih * sc); } catch (e) {}
    }
    function vnAdvance() {
      if (!vn) return;
      if (vn.wait) { vn.cancel = 1; vn.wait = 0; vn.text = vn.fb; vn.shown = vn.text.length; vnTx.textContent = vn.text; logLine(vn); return; }
      if (vn.shown < vn.text.length) { vn.shown = vn.text.length; vnTx.textContent = vn.text; return; }
      api.sfx('click'); vnNext();
    }
    function vnSkip() { if (vn && vn.wait) { vn.cancel = 1; vn.text = vn.fb; logLine(vn); } vnQ.splice(0).forEach((o) => { if (!o.scene && !o.ai) logLine(o); }); vn = null; vnNext(); }
    function toggleLog() {
      if (logEl.style.display === 'block') { logEl.style.display = 'none'; return; }
      logEl.innerHTML = ''; logEl.append(h('div', { class: 'dk-h', text: '대화 기록 — 최근 ' + Math.min(150, vnLog.length) + '줄' }));
      vnLog.slice(-150).forEach((x) => { const r = h('div', { class: 'dk-lg' + (x.k ? '' : ' n') }); if (x.k) r.append(h('b', { style: { color: colOf(x.k)[2] }, text: (x.k === 'M' ? '마왕' : nameOf(x.k)) + (x.ai ? ' ✦' : '') })); r.append(h('span', { text: x.t })); logEl.append(r); });
      if (!vnLog.length) logEl.append(h('p', { class: 'dk-p', text: '아직 나눈 대화가 없어요.' }));
      logEl.append(btn('닫기', () => (logEl.style.display = 'none'), { act: 'log' }));
      logEl.style.display = 'block'; logEl.scrollTop = 1e9;
    }
    const autoVN = () => (L.debug && (L.debug.noTut || L.debug.autoplay)) || isSpect();

    /* ---------- 사건 → 대사 ---------- */
    const MEM = []; const remember = (t) => { MEM.push(t); if (MEM.length > 8) MEM.shift(); };
    const memTxt = () => (MEM.length ? '최근 던전에서 있었던 일:\n- ' + MEM.join('\n- ') : '최근 특별한 일은 없었다.');
    function handleEvents() {
      const evs = st.ev.filter((e) => e.i > lastEv);
      if (!evs.length) return;
      lastEv = st.evn;
      for (const e of evs) {
        if (st.ph === 'raid' && e.k !== 'raid') continue; // 침입 중엔 큰 대화 없음
        if (e.k === 'story' && SCN[e.id]) queueLines(SCN[e.id]);
        else if (e.k === 'aff' && AFF[e.c] && AFF[e.c][e.n]) { queueLines(['N||♥ ' + nameOf(e.c) + ' — 친밀도 이야기 ' + (e.n + 1) + '/3'].concat(AFF[e.c][e.n])); remember(nameOf(e.c) + '와(과) 친밀도 이야기 ' + (e.n + 1) + '번째를 나눴다'); api.sfx('win'); }
        else if ((e.k === 'talk' || e.k === 'gift') && e.s === me) {
          const ro = st.ro.find((x) => x.i === e.u);
          if (e.k === 'gift') remember(nameOf(e.c) + '에게 마왕이 선물을 주었다');
          const bt = e.k === 'talk' && ro ? pickBanter(st, e.c) : null;
          if (bt) { queueLines(bt); remember(bt.map((x) => lineOf(x)).filter((x) => x.spk !== 'M').map((x) => nameOf(x.spk)).filter((v, i, a) => a.indexOf(v) === i).join('·') + '이(가) 마왕 앞에서 티격태격했다'); }
          else queueLines([aiScene(ro ? pickLine(st, ro, e.k) : say(e.c, e.k, {}), e.k, ro, 'fast', memTxt())]);
        }
        else if (e.k === 'hire') remember(nameOf(e.c) + '이(가) 새로 들어왔다'), queueLines([aiLine(say(e.c, 'greet'), 'greet', st.ro.find((x) => x.i === e.u), 'fast', memTxt())]);
        else if (e.k === 'convert') queueLines(['N||⛓ ' + nameOf(e.c) + '이(가) 설득에 넘어왔어요!', say(e.c, 'convert')]);
        else if (e.k === 'persfail') queueLines([say(e.c, 'persfail')]);
        else if (e.k === 'awaken') { queueLines(['N||✨ ' + nameOf(e.c) + ' 각성!', say(e.c, 'awaken'), 'M|surprised|……눈부셔. 정말 멋져.']); api.sfx('win'); }
        else if (e.k === 'leave') queueLines([say(e.c, 'leave'), 'N||' + nameOf(e.c) + '이(가) 던전을 떠났어요. 급여·식사·좋아하는 방을 챙겨 주세요.']);
        else if (e.k === 'raid') {
          const lead = (e.party || []).find((k) => HERO[k] && HERO[k].boss) || (e.party || [])[0];
          showBanner((e.boss ? '👑 칭호 용사 침입! · ' : '🌙 침입 · ') + GOALS[e.g], 3200);
          if (lead) setTimeout(() => { const u = st && st.R && st.R.u.find((o) => o.s === 1); addBubble(u || { i: -99, x: cx(st.E), y: cy(st.E), s: 1 }, e.boss ? (HERO_LINE[lead] || [])[0] || '' : GOAL_LINE[e.g]); }, 1200);
          api.sfx('whoosh');
        }
        else if (e.k === 'morn' && st.rep) { const r = st.rep, ls = morningLines(st); remember('밤 침입: 용사 ' + (r.kills || 0) + '명 처치' + (r.caps ? ', ' + r.caps + '명 포획' : '') + (r.stolen ? ', 금화 ' + r.stolen + ' 도둑맞음' : '') + (r.ko && r.ko.length ? ', ' + r.ko.map(nameOf).join('·') + ' 쓰러짐' : '')); queueLines(ls); }
        else if (e.k === 'prop' && PROP[e.id] && PROP_LINE[e.c] && !isSpect()) { const D = PROP[e.id]; queueLines([aiLine({ spk: e.c, ex: 'smile', text: PROP_LINE[e.c][e.id] }, 'prop', st.ro.find((x) => x.k === e.c), 'fast', '제안 내용: 「' + D.n + '」 ' + D.d + '. 받아들이면 그대로 효과가 나고, 거절해도 손해는 없다.')]); }
        else if (e.k === 'propr' && !isSpect() && (e.ok ? PROP_OK : PROP_NO)[e.c]) queueLines([e.c + (e.ok ? PROP_OK : PROP_NO)[e.c]]);
      }
    }
    // 아침 보고: 문장마다 여러 갈래, 최근에 쓴 갈래는 피함
    const MV = {
      kill: ['어젯밤 용사 {k}명을 물리쳤습니다. 전리품은 금화 {g}.', '밤사이 {k}명이 쓰러졌습니다. 거둔 금화는 {g}입니다.', '어젯밤 성과입니다. 용사 {k}명, 금화 {g}.', '용사 {k}명이 돌아가지 못했습니다. 금화는 {g}만큼 늘었지요.'],
      cap: [' {c}명은 감옥에 모셨지요.', ' 그중 {c}명은 감옥에 있습니다.', ' {c}명은 산 채로 붙잡았습니다.'],
      none: ['어젯밤은 소득이 없었습니다. 함정 배치를 다시 보시지요.', '빈손인 밤이었습니다. 길목을 다시 살펴보시지요.', '어젯밤은 아무도 쓰러뜨리지 못했습니다. 함정이 길에서 비켜 있지 않은지 보시지요.'],
      stolen: ['금화 {s}닢을 도둑맞았습니다. 보물고 앞에 경비를 세우시지요.', '도둑이 금화 {s}닢을 들고 나갔습니다. 보물고 길목을 막아야겠습니다.', '금화 {s}닢이 사라졌습니다. 경비실을 보물고 옆에 붙이시지요.'],
      unpaid: ['급여를 못 줬습니다. 다들 기분이 크게 상했습니다.', '급여가 밀렸습니다. 불만이 커지고 있습니다.'],
      unfed: ['{n}명이 굶었습니다. 식당이나 정원이 더 필요합니다.', '어젯밤 {n}명이 끼니를 걸렀습니다. 식량을 늘리시지요.'],
      ko: ['{ko} — 쓰러졌다가 지금은 숙소에서 쉬고 있습니다.', '{ko} — 숙소에서 회복 중입니다. 오늘 밤엔 괜찮을 겁니다.'],
      unlock: ['연구 성과예요. {u} — 이제 쓸 수 있어요.', '좋은 소식이요. {u}, 드디어 열렸어요.', '밤새 계산이 맞아떨어졌어요. {u}, 열렸어요.'],
      mem: ['도망친 용사가 함정 {m}곳을 봤습니다. 길드가 그 자리를 기억할 겁니다.', '함정 {m}곳이 길드에 알려졌습니다. 자리를 옮기시는 게 좋겠습니다.'],
    };
    function mv(key, v) {
      const a = MV[key]; let ok = a.map((_, i) => i).filter((i) => LM.cdOk('mv:' + key + i, 3)); if (!ok.length) ok = a.map((_, i) => i);
      const i = pick(ok); LM.cdSet('mv:' + key + i); return fillT(a[i], v);
    }
    function morningLines(s) {
      const r = s.rep; const spk = s.ro.some((e) => e.k === 'nightduchess') ? 'nightduchess' : s.ro.some((e) => e.k === 'butler') ? 'butler' : 'M';
      const out = [];
      if (r.kills) out.push({ spk, ex: 'smile', text: mv('kill', { k: r.kills, g: r.gain }) + (r.caps ? mv('cap', { c: r.caps }) : '') });
      else out.push({ spk, ex: 'serious', text: mv('none', {}) });
      if (r.stolen) out.push({ spk, ex: 'angry', text: mv('stolen', { s: r.stolen }) });
      if (r.unpaid) out.push({ spk, ex: 'angry', text: mv('unpaid', {}) });
      if (r.unfed) out.push({ spk, ex: 'sad', text: mv('unfed', { n: r.unfed }) });
      if (r.ko.length) out.push({ spk, ex: 'sad', text: mv('ko', { ko: r.ko.map(nameOf).join(', ') }) });
      if (r.unlock.length) out.push({ spk: s.ro.some((e) => e.k === 'abysswitch') ? 'abysswitch' : spk, ex: 'smile', text: mv('unlock', { u: r.unlock.join(', ') }) });
      if (r.mem) out.push({ spk, ex: 'serious', text: mv('mem', { m: r.mem }) });
      return out;
    }
    function showBanner(t, ms) { ban.textContent = t; ban.style.display = 'block'; banner = performance.now() + ms; }

    /* ---------- 레이아웃 ---------- */
    function layout() {
      const aw = cv.w - PW - 24, ah = cv.h - 60; AW = aw; AH = ah;
      const base = Math.max(10, Math.floor(Math.min(aw / W, ah / H)));
      const z2 = Math.max(10, Math.round(base * zoom)); if (z2 !== Z) statKey = ''; Z = z2;
      const mw = W * Z, mh = H * Z;
      if (mw <= aw) { camX = W / 2; OX = Math.round(8 + (aw - mw) / 2); } else { camX = Math.max(aw / 2 / Z, Math.min(W - aw / 2 / Z, camX)); OX = Math.round(8 + aw / 2 - camX * Z); }
      if (mh <= ah) { camY = H / 2; OY = Math.round(52 + (ah - mh) / 2); } else { camY = Math.max(ah / 2 / Z, Math.min(H - ah / 2 / Z, camY)); OY = Math.round(52 + ah / 2 - camY * Z); }
    }
    function setZoom(nz, px, py) {
      nz = Math.max(1, Math.min(3, nz)); if (Math.abs(nz - zoom) < 1e-3) return;
      if (px == null) { px = 8 + AW / 2; py = 52 + AH / 2; }
      const gx = (px - OX) / Z, gy = (py - OY) / Z; zoom = nz; layout();
      camX = gx - (px - (8 + AW / 2)) / Z; camY = gy - (py - (52 + AH / 2)) / Z; layout();
    }
    // 파 놓은 곳(+둘레 3칸)에 맞춰 확대 — 처음·아침·화면 맞춤(H)
    let userZoom = false;
    function fitView() {
      if (!st) return;
      let x0 = W, y0 = H, x1 = -1, y1 = -1;
      for (let i = 0; i < N; i++) if (walkT(st.m[i])) { const x = cx(i), y = cy(i); if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      if (x1 < 0) { zoom = 1; layout(); return; }
      x0 = Math.max(0, x0 - 3); y0 = Math.max(0, y0 - 3); x1 = Math.min(W - 1, x1 + 3); y1 = Math.min(H - 1, y1 + 3);
      const bw = Math.max(12, x1 - x0 + 1), bh = Math.max(7, y1 - y0 + 1);
      const base = Math.max(10, Math.floor(Math.min(AW / W, AH / H)));
      zoom = Math.max(1, Math.min(3, Math.min(AW / (bw * base), AH / (bh * base)) * 0.98));
      camX = (x0 + x1 + 1) / 2; camY = (y0 + y1 + 1) / 2; layout(); userZoom = false;
    }
    const panBy = (dx, dy) => { if (zoom <= 1) return; camX += dx; camY += dy; layout(); };
    cv.onresize = () => layout();
    layout();
    if (L.debug) L.debug.dkv = { geo: () => ({ OX, OY, Z, zoom, AW, AH }), st: () => st, cellXY: (c) => { const r = cv.cv.getBoundingClientRect(); return { x: r.left + OX + cx(c) * Z + Z / 2, y: r.top + OY + cy(c) * Z + Z / 2 }; } };

    /* ---------- 고정 그림(지형·방·함정) ---------- */
    const hsh = (i, k) => { let x = (i * 374761393 + k * 668265263) | 0; x = (x ^ (x >>> 13)) * 1274126177; return ((x ^ (x >>> 16)) >>> 0) / 4294967296; };
    let lights = [];
    const LIGHT_RM = { b: '150,120,255', j: '120,200,255', k: '255,90,140', o: '255,210,140', f: '255,140,60', a: '255,210,90', i: '120,255,200', p: '255,140,200', l: '200,170,255' };
    const FURN = { a: ['💰', '📦', '💎', '👑'], b: ['🔮', '✨', '💠'], c: ['🛏', '🛏', '🕯'], d: ['🍖', '🍞', '🍷', '🍽'], e: ['⚔', '🎯', '🛡'], f: ['🔨', '⚒', '🔥'], g: ['🛡', '🗡', '🚩'], h: ['⛓', '🔒', '⛓'], i: ['⚗', '🧪', '📜'], j: ['♨', '💧', '♨'], k: ['👑', '🕯', '🏺'], l: ['📚', '📜', '🕯'], n: ['🌿', '🌸', '🍄'], o: ['🕯', '🗿', '✨'], p: ['🍷', '🎻', '🕯'] };
    function staticLayer() {
      const key = st.m + st.r + st.t + Z + (st.ph === 'raid' ? 'r' : 'd') + st.n;
      if (statKey === key && statC) return statC;
      statKey = key; lights = [];
      const dpr = cv.dpr || 1, c = statC || document.createElement('canvas');
      c.width = Math.ceil(W * Z * dpr); c.height = Math.ceil(H * Z * dpr);
      const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      for (let i = 0; i < N; i++) {
        const x = cx(i) * Z, y = cy(i) * Z, ch = st.m[i];
        if (rockT(ch) || ch === 'X') {
          const face = NB4[i].some((j) => walkT(st.m[j])); // 바닥과 닿은 바위 = 벽면(밝게), 안쪽 바위 = 아주 어둡게
          g.fillStyle = ch === 'X' ? '#0c0d13' : face ? '#3a2d3a' : '#141017'; g.fillRect(x, y, Z, Z);
          if (face && ch !== 'X') { // 벽돌 결
            g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 1; const rh = Z / 3;
            for (let r = 1; r < 3; r++) { g.beginPath(); g.moveTo(x, y + r * rh); g.lineTo(x + Z, y + r * rh); g.stroke(); }
            for (let r = 0; r < 3; r++) { const ox = (r % 2 ? 0.5 : 0) * Z / 2 + Z / 4; g.beginPath(); g.moveTo(x + ox, y + r * rh); g.lineTo(x + ox, y + (r + 1) * rh); g.moveTo(x + ox + Z / 2, y + r * rh); g.lineTo(x + ox + Z / 2, y + (r + 1) * rh); g.stroke(); }
            g.fillStyle = 'rgba(255,220,190,.07)'; g.fillRect(x, y, Z, 2);
          } else {
            for (let k = 0; k < 3; k++) { g.fillStyle = ch === 'X' ? 'rgba(110,120,170,.10)' : 'rgba(255,230,200,.035)'; g.fillRect(x + hsh(i, k) * (Z - 4), y + hsh(i, k + 9) * (Z - 4), 3, 2); }
            if (hsh(i, 21) < 0.25) { g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1; g.beginPath(); const a0 = hsh(i, 22) * Z, b0 = hsh(i, 23) * Z; g.moveTo(x + a0, y + b0); g.lineTo(x + a0 + Z * 0.25, y + b0 + Z * 0.2); g.lineTo(x + a0 + Z * 0.15, y + b0 + Z * 0.45); g.stroke(); }
          }
          if (face && ch !== 'X' && hsh(i, 5) < 0.14 && cy(i) < H - 1 && walkT(st.m[i + W])) { lights.push([x + Z / 2, y + Z * 0.55, Z * 2.6, '255,170,80', 1]); g.fillStyle = '#5a3a22'; g.fillRect(x + Z * 0.45, y + Z * 0.45, Z * 0.1, Z * 0.4); g.fillStyle = '#ffb040'; g.beginPath(); g.ellipse(x + Z / 2, y + Z * 0.4, Z * 0.09, Z * 0.15, 0, 0, 7); g.fill(); }
          if (ch === '$') { g.fillStyle = '#e3ae45'; for (let k = 0; k < 5; k++) { g.beginPath(); g.arc(x + 3 + hsh(i, k + 3) * (Z - 6), y + 3 + hsh(i, k + 7) * (Z - 6), Z * 0.06 + 1, 0, 7); g.fill(); } }
          if (ch === '*') { g.fillStyle = '#9a6ad0'; g.beginPath(); g.moveTo(x + Z * 0.5, y + Z * 0.15); g.lineTo(x + Z * 0.7, y + Z * 0.55); g.lineTo(x + Z * 0.5, y + Z * 0.85); g.lineTo(x + Z * 0.3, y + Z * 0.55); g.fill(); }
          // 바닥과 닿은 면 그림자
          g.fillStyle = 'rgba(0,0,0,.35)';
          if (cy(i) < H - 1 && walkT(st.m[i + W])) g.fillRect(x, y + Z - 3, Z, 3);
        } else {
          const v = hsh(i, 1) * 0.06;
          g.fillStyle = ch === '~' ? '#1c4462' : `rgb(${66 + v * 200 | 0},${57 + v * 160 | 0},${68 + v * 160 | 0})`; g.fillRect(x, y, Z, Z);
          if (ch !== '~') { // 판석: 줄마다 어긋난 돌 4장
            g.strokeStyle = 'rgba(0,0,0,.28)'; g.lineWidth = 1; const hz = Z / 2, off = (cy(i) % 2) * Z / 4;
            g.beginPath(); g.moveTo(x, y + hz); g.lineTo(x + Z, y + hz); g.moveTo(x + off + Z / 4, y); g.lineTo(x + off + Z / 4, y + hz); g.moveTo(x + Z * 0.75 - off, y + hz); g.lineTo(x + Z * 0.75 - off, y + Z); g.stroke();
            for (let k = 0; k < 4; k++) { const sx = x + (k % 2) * hz, sy = y + (k >> 1) * hz; g.fillStyle = 'rgba(255,240,220,' + (hsh(i, 30 + k) * 0.05).toFixed(3) + ')'; g.fillRect(sx + 1, sy + 1, hz - 2, hz - 2); }
          }
          g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 1; g.strokeRect(x + 0.5, y + 0.5, Z - 1, Z - 1);
          const rk = st.r[i];
          if (ch === '.' && rk === '-' && st.t[i] === '-') { // 바닥 장식(자갈·뼈·이끼)
            const dv = hsh(i, 40);
            if (dv < 0.07) { g.fillStyle = 'rgba(200,190,170,.35)'; for (let k = 0; k < 3; k++) { g.beginPath(); g.arc(x + Z * (0.25 + hsh(i, 41 + k) * 0.5), y + Z * (0.3 + hsh(i, 44 + k) * 0.45), Z * 0.04 + 0.8, 0, 7); g.fill(); } }
            else if (dv < 0.11) { g.strokeStyle = 'rgba(230,220,200,.45)'; g.lineWidth = Math.max(1, Z * 0.05); g.beginPath(); g.moveTo(x + Z * 0.3, y + Z * 0.62); g.lineTo(x + Z * 0.68, y + Z * 0.48); g.stroke(); g.fillStyle = 'rgba(230,220,200,.45)'; [[0.3, 0.62], [0.68, 0.48]].forEach(([a, b]) => { g.beginPath(); g.arc(x + Z * a, y + Z * b, Z * 0.05, 0, 7); g.fill(); }); }
            else if (dv < 0.17) { g.fillStyle = 'rgba(80,140,70,.28)'; g.beginPath(); g.ellipse(x + Z * (0.3 + hsh(i, 47) * 0.4), y + Z * (0.3 + hsh(i, 48) * 0.4), Z * 0.2, Z * 0.1, hsh(i, 49) * 3, 0, 7); g.fill(); }
          }
          if (rk !== '-' && RM[rk]) {
            g.fillStyle = RM[rk].col + '5a'; g.fillRect(x, y, Z, Z);
            if (rk === 'c' || rk === 'k' || rk === 'p' || rk === 'o') { g.fillStyle = 'rgba(120,20,40,.25)'; g.fillRect(x + Z * 0.1, y + Z * 0.1, Z * 0.8, Z * 0.8); } // 깔개
            if (LIGHT_RM[rk] && hsh(i, 60) < 0.4) lights.push([x + Z / 2, y + Z / 2, Z * 2.2, LIGHT_RM[rk], 0]);
            g.strokeStyle = RM[rk].col; g.lineWidth = 2;
            NB4[i].forEach((j) => { if (st.r[j] !== rk) { g.beginPath(); const jx = cx(j) - cx(i), jy = cy(j) - cy(i); if (jx === 1) { g.moveTo(x + Z - 1, y); g.lineTo(x + Z - 1, y + Z); } if (jx === -1) { g.moveTo(x + 1, y); g.lineTo(x + 1, y + Z); } if (jy === 1) { g.moveTo(x, y + Z - 1); g.lineTo(x + Z, y + Z - 1); } if (jy === -1) { g.moveTo(x, y + 1); g.lineTo(x + Z, y + 1); } g.stroke(); } });
            const fl = FURN[rk] || [RM[rk].ic], fi = hsh(i, 61) < 0.45 ? 0 : 1 + Math.floor(hsh(i, 62) * (fl.length - 1)); // 칸마다 가구(첫째 = 방 표시)
            g.globalAlpha = 0.92; g.font = Math.round(Z * (fi ? 0.46 : 0.56)) + 'px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
            g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(x + Z / 2, y + Z * 0.78, Z * 0.26, Z * 0.07, 0, 0, 7); g.fill();
            g.fillText(fl[Math.min(fi, fl.length - 1)], x + Z / 2 + (hsh(i, 63) - 0.5) * Z * 0.16, y + Z / 2 + 1); g.globalAlpha = 1;
          }
          const tk = st.t[i];
          if (tk !== '-' && TP[tk]) {
            g.fillStyle = 'rgba(20,10,20,.55)'; g.beginPath(); g.arc(x + Z / 2, y + Z / 2, Z * 0.4, 0, 7); g.fill();
            g.strokeStyle = '#c04060'; g.lineWidth = 1.5; g.stroke();
            g.fillStyle = '#f2e9d8'; g.font = Math.round(Z * 0.46) + 'px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(TP[tk].ic, x + Z / 2, y + Z / 2 + 1);
          }
          if (ch === 'E') { g.fillStyle = '#2a6aa0'; g.beginPath(); g.arc(x + Z / 2, y + Z * 0.7, Z * 0.42, Math.PI, 0); g.fill(); g.fillStyle = '#9ad0ff'; g.beginPath(); g.arc(x + Z / 2, y + Z * 0.7, Z * 0.28, Math.PI, 0); g.fill(); }
          if (ch === 'E') lights.push([x + Z / 2, y + Z / 2, Z * 3, '120,180,255', 0]);
          if (ch === 'H') lights.push([x + Z / 2, y + Z / 2, Z * 3.2, '255,90,110', 0]);
          if (ch === 'H') { g.fillStyle = '#5a1a2a'; g.fillRect(x + Z * 0.15, y + Z * 0.1, Z * 0.7, Z * 0.8); g.fillStyle = '#e3ae45'; g.fillRect(x + Z * 0.15, y + Z * 0.1, Z * 0.7, Z * 0.12); g.fillStyle = '#c0283a'; g.beginPath(); g.arc(x + Z / 2, y + Z * 0.5, Z * 0.16, 0, 7); g.fill(); }
        }
      }
      // 구역 경계(협동)
      if (st.n > 1) { g.strokeStyle = 'rgba(227,174,69,.35)'; g.setLineDash([4, 4]); g.lineWidth = 1.5; for (let k = 1; k < st.n; k++) { const xx = Math.ceil(k * W / st.n) * Z; g.beginPath(); g.moveTo(xx, 0); g.lineTo(xx, H * Z); g.stroke(); } g.setLineDash([]); }
      statC = c; return c;
    }

    /* ---------- 그리기 ---------- */
    function cellAt(px, py) { const x = Math.floor((px - OX) / Z), y = Math.floor((py - OY) / Z); return x >= 0 && y >= 0 && x < W && y < H ? idx(x, y) : -1; }
    function draw(now) {
      ctx.fillStyle = '#100c15'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!st) return;
      ctx.save(); if (zoom > 1) { ctx.beginPath(); ctx.rect(0, 48, 8 + AW + 6, cv.h - 48); ctx.clip(); }
      ctx.drawImage(staticLayer(), OX, OY, W * Z, H * Z);
      const t = now / 1000;
      if (lights.length) { // 방·횃불 불빛(깜빡임)
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        for (let k = 0; k < lights.length && k < 90; k++) { const [lx, ly, lr, col, tor] = lights[k]; const fk = tor ? 0.8 + Math.sin(t * 9 + k * 1.7) * 0.12 + Math.sin(t * 23 + k) * 0.06 : 0.85 + Math.sin(t * 1.6 + k) * 0.1;
          const X0 = OX + lx, Y0 = OY + ly, gr = ctx.createRadialGradient(X0, Y0, 0, X0, Y0, lr); gr.addColorStop(0, 'rgba(' + col + ',' + (0.22 * fk).toFixed(3) + ')'); gr.addColorStop(1, 'rgba(' + col + ',0)'); ctx.fillStyle = gr; ctx.fillRect(X0 - lr, Y0 - lr, lr * 2, lr * 2); }
        ctx.restore();
      }
      // 물결
      ctx.fillStyle = 'rgba(140,200,255,.10)';
      for (let i = 0; i < N; i++) if (st.m[i] === '~') { const ph = Math.sin(t * 2 + i) * 0.5 + 0.5; ctx.globalAlpha = 0.3 + ph * 0.4; ctx.fillRect(OX + cx(i) * Z + 3, OY + cy(i) * Z + Z * 0.4 + ph * 3, Z - 6, 2); }
      ctx.globalAlpha = 1;
      const R = st.R;
      // 내 구역 밖 어둡게(협동, 짓는 도구)
      if (st.n > 1 && st.ph === 'day' && (tool === 'dig' || tool === 'room' || tool === 'trap' || tool === 'sell')) {
        ctx.fillStyle = 'rgba(0,0,0,.35)';
        for (let k = 0; k < st.n; k++) if (k !== me) { const x0 = Math.ceil(k * W / st.n), x1 = Math.ceil((k + 1) * W / st.n); ctx.fillRect(OX + x0 * Z, OY, (x1 - x0) * Z, H * Z); }
      }
      if (st.ph === 'day' || st.ph === 'morn' || st.ph === 'pick') {
        // 길 표시
        if (st.ph === 'day') { ctx.strokeStyle = 'rgba(160,210,255,.22)'; ctx.lineWidth = 2; ctx.setLineDash([3, 5]); ctx.beginPath(); let p0 = st.E; ctx.moveTo(OX + cx(p0) * Z + Z / 2, OY + cy(p0) * Z + Z / 2); mainPath(st).concat([st.Hc]).forEach((c) => ctx.lineTo(OX + cx(c) * Z + Z / 2, OY + cy(c) * Z + Z / 2)); ctx.stroke(); ctx.setLineDash([]); }
        // 기억된 함정
        st.mem.forEach((c) => { ctx.strokeStyle = 'rgba(255,200,80,.6)'; ctx.lineWidth = 1; ctx.strokeRect(OX + cx(c) * Z + 2, OY + cy(c) * Z + 2, Z - 4, Z - 4); });
        // 마물(배치 자리)
        const at = {};
        st.ro.forEach((e) => { const c = e.p >= 0 ? e.p : st.Hc; const k2 = at[c] = (at[c] || 0) + 1; const ox = ((k2 - 1) % 3 - 1) * Z * 0.28, oy = Math.floor((k2 - 1) / 3) * -Z * 0.2;
          drawChibi(ctx, OX + cx(c) * Z + Z / 2 + ox, OY + cy(c) * Z + Z * 0.6 + oy, Z * 1.12, e.k, { aw: e.aw, bob: Math.sin(t * 2 + e.i) * 0.6, fl: (e.i % 2) === 1, sleep: e.hp < 0.3 });
          if (selU === e.i) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.strokeRect(OX + cx(c) * Z + 1, OY + cy(c) * Z + 1, Z - 2, Z - 2); }
        });
        drawChibi(ctx, OX + cx(st.Hc) * Z + Z / 2, OY + cy(st.Hc) * Z + Z * 0.55, Z * 1.3, 'master', { bob: Math.sin(t * 1.5) * 0.5 });
      }
      if (R) drawRaid(now, R);
      // 커서
      if (hover >= 0) {
        const x = OX + cx(hover) * Z, y = OY + cy(hover) * Z;
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.strokeRect(x + 1, y + 1, Z - 2, Z - 2);
        if (msSel && MS[msSel]) { const r = Math.max(0.6, MS[msSel].r || 0.6) * Z; ctx.strokeStyle = 'rgba(255,120,160,.9)'; ctx.fillStyle = 'rgba(255,80,140,.14)'; ctx.beginPath(); ctx.arc(x + Z / 2, y + Z / 2, r, 0, 7); ctx.fill(); ctx.stroke(); }
      }
      drawPreview(t);
      // 효과
      for (let k = fx.length - 1; k >= 0; k--) { const f = fx[k]; const a = (now - f.t0) / f.d; if (a >= 1) { fx.splice(k, 1); continue; } drawFx(f, a); }
      for (let k = bubbles.length - 1; k >= 0; k--) { const b = bubbles[k]; const a = (now - b.t0) / b.d; if (a >= 1) { bubbles.splice(k, 1); continue; } drawBubble(b, a, now); }
      // 일시정지
      if (st.ph === 'raid' && paused) { ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(OX, OY, W * Z, H * Z); ctx.fillStyle = '#f2e9d8'; ctx.font = '700 28px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.fillText('일시정지', OX + W * Z / 2, OY + H * Z / 2); const kb = L.ui.keyLabel ? L.ui.keyLabel('dkeeper', 'pause') : ''; if (kb) { ctx.font = '14px sans-serif'; ctx.fillText('[' + kb + '] 계속', OX + W * Z / 2, OY + H * Z / 2 + 28); } }
      ctx.restore();
      if (banner && now > banner) { ban.style.display = 'none'; banner = null; }
    }
    /* ---------- 짓기 미리보기(가능 칸 초록·불가 빨강, 합계 비용) ---------- */
    const toolOp = (c) => (tool === 'dig' ? { t: 'dig', c } : tool === 'room' ? { t: 'room', c, k: selRoom } : tool === 'trap' ? { t: 'trap', c, k: selTrap } : tool === 'sell' ? { t: 'sell', c } : null);
    function simCells(cells) {
      const key = tool + selRoom + selTrap + st.seq + ':' + cells.join(',');
      if (key === prevKey) return prevRes;
      const tmp = JSON.parse(JSON.stringify(Object.assign({}, st, { R: null, ev: [], log: [] }))); const ok = new Set(), bad = new Map();
      const g0 = tmp.gold, m0 = tmp.mana, l0 = tmp.lab;
      for (const c of cells) { const e = doOp(tmp, me, toolOp(c)); if (e) bad.set(c, e); else ok.add(c); }
      prevKey = key; prevRes = { ok, bad, gold: tmp.gold - g0, mana: tmp.mana - m0, lab: tmp.lab - l0 };
      return prevRes;
    }
    const dragCells = () => (drag && drag.cells ? drag.cells : hover >= 0 ? [hover] : []);
    function drawPreview(t) {
      if (!st || st.ph !== 'day') return;
      if (drag && drag.mon != null) { // 마물 끌어 배치
        const e = st.ro.find((x) => x.i === drag.mon); if (!e || hover < 0) return;
        const okc = walkT(st.m[hover]); const x = OX + cx(hover) * Z, y = OY + cy(hover) * Z;
        ctx.globalAlpha = 0.75; drawChibi(ctx, x + Z / 2, y + Z * 0.6, Z * 1.12, e.k, { bob: 0 }); ctx.globalAlpha = 1;
        ctx.strokeStyle = okc ? '#70e090' : '#ff6070'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]); ctx.strokeRect(x + 1, y + 1, Z - 2, Z - 2);
        if (e.p >= 0) { ctx.beginPath(); ctx.moveTo(OX + cx(e.p) * Z + Z / 2, OY + cy(e.p) * Z + Z / 2); ctx.lineTo(x + Z / 2, y + Z / 2); ctx.stroke(); }
        ctx.setLineDash([]); return;
      }
      if (!toolOp(0) || !iCan()) return;
      const cells = dragCells(); if (!cells.length || (!drag && hover < 0)) return;
      const r = simCells(cells);
      for (const c of cells) {
        const x = OX + cx(c) * Z, y = OY + cy(c) * Z, ok = r.ok.has(c);
        ctx.fillStyle = ok ? 'rgba(110,220,140,.22)' : 'rgba(255,90,100,.22)'; ctx.fillRect(x, y, Z, Z);
        if (ok && (tool === 'room' || tool === 'trap')) { ctx.globalAlpha = 0.55 + Math.sin(t * 4) * 0.15; ctx.font = Math.round(Z * 0.5) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#fff'; ctx.fillText(tool === 'room' ? RM[selRoom].ic : TP[selTrap].ic, x + Z / 2, y + Z / 2 + 1); ctx.globalAlpha = 1; ctx.textBaseline = 'alphabetic'; }
        if (!ok) { ctx.strokeStyle = 'rgba(255,90,100,.8)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(x + 5, y + 5); ctx.lineTo(x + Z - 5, y + Z - 5); ctx.stroke(); }
      }
      if (drag && cells.length > 1 && mouse) { // 합계
        const txt = r.ok.size + '칸' + (r.gold ? ' · 💰' + (r.gold > 0 ? '+' : '') + r.gold : '') + (r.lab ? ' · ⛏' + r.lab : '') + (r.mana ? ' · 🔮+' + r.mana : '') + (r.bad.size ? ' · 불가 ' + r.bad.size : '');
        ctx.font = '600 13px "IBM Plex Sans KR", sans-serif'; const w = ctx.measureText(txt).width + 16;
        ctx.fillStyle = 'rgba(14,10,20,.92)'; ctx.fillRect(mouse.x + 14, mouse.y - 30, w, 24); ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1; ctx.strokeRect(mouse.x + 14.5, mouse.y - 29.5, w - 1, 23);
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(txt, mouse.x + 22, mouse.y - 18); ctx.textBaseline = 'alphabetic';
      }
    }
    function unitPos(u, now) {
      const p = prevU.get(u.i); const iv = 500 / ((st.R && st.R.sp) || 1);
      const a = Math.min(1, (now - tUpd) / iv);
      if (!p || paused) return { x: u.x, y: u.y };
      return { x: p.x + (u.x - p.x) * a, y: p.y + (u.y - p.y) * a };
    }
    function drawRaid(now, R) {
      const t = now / 1000;
      // 장벽·지뢰·꺼진 함정·쿨다운
      for (const k in R.wall) { const c = +k; ctx.fillStyle = 'rgba(120,90,255,.45)'; ctx.fillRect(OX + cx(c) * Z + 2, OY + cy(c) * Z + 2, Z - 4, Z - 4); }
      R.mines.forEach((c) => { ctx.fillStyle = '#ff6040'; ctx.beginPath(); ctx.arc(OX + cx(c) * Z + Z / 2, OY + cy(c) * Z + Z / 2, Z * 0.18, 0, 7); ctx.fill(); });
      R.off.forEach((c) => { ctx.strokeStyle = '#ffcc40'; ctx.lineWidth = 2; const x = OX + cx(c) * Z, y = OY + cy(c) * Z; ctx.beginPath(); ctx.moveTo(x + 4, y + 4); ctx.lineTo(x + Z - 4, y + Z - 4); ctx.moveTo(x + Z - 4, y + 4); ctx.lineTo(x + 4, y + Z - 4); ctx.stroke(); });
      for (const k in R.tr) { const c = +k; if (R.tr[k] > R.t) { ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.beginPath(); ctx.arc(OX + cx(c) * Z + Z / 2, OY + cy(c) * Z + Z / 2, Z * 0.4, 0, 7); ctx.fill(); } }
      if (R.rally && R.rally.u > R.t) { const c = R.rally.c; ctx.fillStyle = '#e3ae45'; ctx.font = Math.round(Z * 0.7) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('🚩', OX + cx(c) * Z + Z / 2, OY + cy(c) * Z + Z * 0.7); }
      // 유닛
      const list = R.u.slice().sort((a, b) => a.y - b.y);
      for (const u of list) {
        const p = unitPos(u, now);
        const px = OX + p.x * Z + Z / 2, py = OY + p.y * Z + Z * 0.55;
        const hero = u.s === 1, charmed = hero && on(R, u, 'ch');
        const sz = u.b ? Z * 1.45 : u.ms ? Z * 1.3 : Z * 1.12;
        drawChibi(ctx, px, py, sz, u.k, { fl: u.fl, aw: u.aw, boss: u.b, hurt: u.la && u.hp < u.mh * 0.3, sleep: on(R, u, 'sp'), bob: Math.sin(t * 6 + u.i) * 0.5 });
        if (charmed) { ctx.fillStyle = '#ff70b0'; ctx.font = Math.round(Z * 0.4) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('♥', px, py - sz * 0.9); }
        // 체력
        const bw = Z * (u.b ? 1.3 : 0.9), fr = Math.max(0, u.hp / u.mh);
        ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(px - bw / 2, py - sz * 0.85, bw, 4);
        ctx.fillStyle = hero && !charmed ? (u.b ? '#f0c040' : '#5ab0ff') : u.ms ? '#e04060' : '#60d080'; ctx.fillRect(px - bw / 2, py - sz * 0.85, bw * fr, 4);
        // 상태
        let sx = px - bw / 2; const icons = [['wet', '💧'], ['oil', '🛢'], ['bn', '🔥'], ['ps', '☠'], ['sn', '💫'], ['rt', '🕸'], ['sp', '💤'], ['cf', '❓'], ['fr', '😱'], ['cs', '☾'], ['mk', '💋'], ['bf', '⬆'], ['df', '🛡']];
        ctx.font = Math.round(Z * 0.32) + 'px sans-serif'; ctx.textAlign = 'left';
        for (const [k, ic] of icons) if (on(R, u, k)) { ctx.fillText(ic, sx, py - sz * 0.9 - 2); sx += Z * 0.33; }
        if (u.c) { ctx.fillStyle = '#e3ae45'; ctx.fillText('💰', px + bw / 2, py - sz * 0.4); }
        if (selU === u.i || (u.ri && selU === u.ri)) { ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(px, py + sz * 0.42, sz * 0.45, sz * 0.16, 0, 0, 7); ctx.stroke(); }
      }
      // 남은 시간
      const left = Math.max(0, Math.ceil(R.tl - R.t));
      ctx.fillStyle = 'rgba(14,10,20,.8)'; ctx.fillRect(OX + 6, OY + 6, 150, 26);
      ctx.fillStyle = R.ret ? '#ffcc40' : '#f2e9d8'; ctx.font = '600 13px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(R.ret ? '용사들이 후퇴 중' : '새벽까지 ' + left + '초', OX + 14, OY + 19); ctx.textBaseline = 'alphabetic';
    }
    function addFx(f) { f.t0 = performance.now(); f.d = (f.d || 700) / Math.max(1, (L.debug && L.debug.speed) || 1); if (fx.length < 160) fx.push(f); }
    function drawFx(f, a) {
      const X = (x) => OX + x * Z + Z / 2, Y = (y) => OY + y * Z + Z / 2;
      ctx.save();
      if (f.k === 'n') { ctx.globalAlpha = 1 - a; ctx.fillStyle = f.c; ctx.font = '700 ' + Math.round(Z * 0.5) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.fillText(f.v, X(f.x), Y(f.y) - Z * 0.6 - a * Z * 0.8); }
      else if (f.k === 'line') { ctx.globalAlpha = 1 - a; ctx.strokeStyle = f.c; ctx.lineWidth = f.w || 2; const bx = X(f.x0) + (X(f.x1) - X(f.x0)) * Math.min(1, a * 1.6), by = Y(f.y0) + (Y(f.y1) - Y(f.y0)) * Math.min(1, a * 1.6); ctx.beginPath(); ctx.moveTo(X(f.x0) + (bx - X(f.x0)) * 0.6, Y(f.y0) + (by - Y(f.y0)) * 0.6); ctx.lineTo(bx, by); ctx.stroke(); }
      else if (f.k === 'ring') { ctx.globalAlpha = (1 - a) * 0.8; ctx.strokeStyle = f.c; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X(f.x), Y(f.y), Math.max(2, f.r * Z * (0.3 + a * 0.7)), 0, 7); ctx.stroke(); ctx.globalAlpha = (1 - a) * 0.2; ctx.fillStyle = f.c; ctx.fill(); }
      else if (f.k === 'txt') { ctx.globalAlpha = a < 0.8 ? 1 : (1 - a) * 5; ctx.fillStyle = f.c; ctx.strokeStyle = '#000'; ctx.lineWidth = 4; ctx.font = '700 ' + Math.round(Z * 0.7) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.strokeText(f.v, X(f.x), Y(f.y) - Z - a * Z * 0.5); ctx.fillText(f.v, X(f.x), Y(f.y) - Z - a * Z * 0.5); }
      else if (f.k === 'puff') { ctx.globalAlpha = 1 - a; ctx.fillStyle = f.c; for (let k = 0; k < 6; k++) { const an = k * 1.05; ctx.beginPath(); ctx.arc(X(f.x) + Math.cos(an) * a * Z * 0.8, Y(f.y) + Math.sin(an) * a * Z * 0.8, Z * 0.14 * (1 - a) + 1, 0, 7); ctx.fill(); } }
      else if (f.k === 'flash') { ctx.globalAlpha = (1 - a) * 0.7; ctx.fillStyle = f.c; ctx.fillRect(OX + cx(f.c0) * Z, OY + cy(f.c0) * Z, Z, Z); }
      ctx.restore();
    }
    function addBubble(u, text) {
      if (!text || bubbles.length > 3) return;
      const now = performance.now();
      if (bubbles.some((b) => b.u === u.i)) return;
      bubbles.push({ u: u.i, x: u.x, y: u.y, text, t0: now, d: 2400 / Math.max(1, (L.debug && L.debug.speed) || 1), hero: u.s === 1 });
    }
    function drawBubble(b, a, now) {
      const R = st.R; const u = R && R.u.find((o) => o.i === b.u); if (u) { const p = unitPos(u, now); b.x = p.x; b.y = p.y; }
      const x = OX + b.x * Z + Z / 2, y = OY + b.y * Z - Z * 0.6;
      ctx.save(); ctx.globalAlpha = a > 0.85 ? (1 - a) / 0.15 : 1;
      ctx.font = '600 12px "IBM Plex Sans KR", sans-serif'; const w = Math.min(220, ctx.measureText(b.text).width + 16);
      const bx = Math.max(OX, Math.min(OX + W * Z - w, x - w / 2));
      ctx.fillStyle = b.hero ? 'rgba(230,240,255,.95)' : 'rgba(255,236,240,.95)'; ctx.strokeStyle = b.hero ? '#5a8ad0' : '#c04060'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx, y - 24, w, 22, 8) : ctx.rect(bx, y - 24, w, 22); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#221c2b'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(b.text, bx + 8, y - 13, w - 14); ctx.restore();
    }
    function playFx(R) {
      const byId = new Map(R.u.map((u) => [u.i, u]));
      const pos = (id) => byId.get(id) || prevU.get(id);
      let sfxN = 0;
      for (const f of R.fx) {
        const k = f[0];
        if (k === 'a') { const s0 = f[1] < 0 ? { x: cx(-f[1] - 1), y: cy(-f[1] - 1) } : pos(f[1]), t0 = pos(f[2]); if (s0 && t0 && f[3]) addFx({ k: 'line', x0: s0.x, y0: s0.y, x1: t0.x, y1: t0.y, c: f[3] === 2 ? '#c080ff' : '#f0e0a0', d: 400 }); else if (t0) addFx({ k: 'puff', x: t0.x, y: t0.y, c: '#fff', d: 260 }); if (sfxN++ < 1) api.sfx('hit'); }
        else if (k === 'd') addFx({ k: 'n', x: f[1], y: f[2], v: f[3], c: f[4] === 1 ? '#ffd080' : '#ff7080', d: 800 });
        else if (k === 't') { addFx({ k: 'flash', c0: f[1], c: '#ff5070', d: 400 }); }
        else if (k === 'c') { pushFeed('✨ 연계 「' + f[1] + '」'); addFx({ k: 'txt', x: f[2], y: f[3], v: f[1] + '!', c: '#ffd040', d: 1300 }); api.sfx('pop'); }
        else if (k === 's') { const u = pos(f[1]); const S = SK[f[2]]; if (f[3] === -1) addFx({ k: 'ring', x: f[4], y: f[5], r: f[6] || 1.5, c: u && u.s === 1 ? '#80b0ff' : '#ff80b0', d: 600 }); else if (u) addFx({ k: 'ring', x: u.x, y: u.y, r: 0.9, c: '#ffe080', d: 500 });
          if (u && S && Math.random() < 0.18) { if (u.s === 0 && !u.ms) { const line = say(u.k, 'm_skill'); addBubble(u, line.text ? S.n + '! ' + line.text : S.n + '!'); } else addBubble(u, S.n + '!'); } }
        else if (k === 'k') { pushFeed(f[4] === 1 ? '⚔ ' + nameOf(f[5]) + ' 쓰러뜨림' : '💤 ' + nameOf(f[5]) + ' 쓰러짐'); addFx({ k: 'puff', x: f[2], y: f[3], c: f[4] === 1 ? '#9ad0ff' : '#ff9ab0', d: 700 }); const u = { i: -f[1], x: f[2], y: f[3], s: f[4] }; if (Math.random() < 0.5) { const l = f[4] === 1 ? say(f[5], 'h_ko') : say(f[5], 'm_ko'); if (l.text) addBubble(u, l.text); } api.sfx(f[4] === 1 ? 'pop' : 'thud'); }
        else if (k === 'm') { const M = MS[f[1]]; addFx({ k: 'ring', x: cx(f[2]), y: cy(f[2]), r: Math.max(1, M.r || 1), c: '#ff4080', d: 900 }); addFx({ k: 'txt', x: cx(f[2]), y: cy(f[2]), v: M.ic + ' ' + M.n, c: '#ffb0d0', d: 1200 }); api.sfx('whoosh'); }
        else if (k === 'g') { pushFeed('💸 금화 -' + f[3] + ' 도둑맞음'); addFx({ k: 'txt', x: f[1], y: f[2], v: '-' + f[3] + '💰', c: '#e3ae45', d: 1200 }); }
        else if (k === 'x') pushFeed('🔧 함정 하나가 풀림'), addFx({ k: 'txt', x: cx(f[1]), y: cy(f[1]), v: '해제', c: '#ffcc40', d: 900 });
        else if (k === 'p') pushFeed('⛓ 용사 포획'), addFx({ k: 'txt', x: f[1], y: f[2], v: '⛓ 포획', c: '#c0c0ff', d: 1100 });
        else if (k === 'B') { const u = byId.get(f[1]); if (u) addBubble(u, (HERO_LINE[f[2]] || [''])[0]); showBanner('👑 ' + HERO[f[2]].n + ' 등장!', 2500); api.sfx('thud'); }
        else if (k === 'r') showBanner('🌅 새벽 — 용사들이 물러나요', 2200);
      }
      // 새로 들어온 용사 한마디
      R.u.forEach((u) => { if (u.s === 1 && !prevU.has(u.i) && !u.b && Math.random() < 0.35) addBubble(u, say(u.k, 'h_in').text); });
    }

    /* ---------- 위쪽 막대 ---------- */
    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      const chip = (ic, v, tipT, cls) => { const c = h('div', { class: 'dk-chip' + (cls ? ' ' + cls : '') }); c.innerHTML = ic + ' <b>' + v + '</b>'; if (tipT) c.setAttribute('data-tip', tipT); return c; };
      const phN = { pick: '고르기', day: '☀ 낮 · 경영', raid: '🌙 밤 · 침입', morn: '🌅 아침', over: '끝' }[st.ph];
      const chLabel = st.mode === 'camp' ? (st.ch + 1) + '장 ' + (st.nd + 1) + '밤' + (isBossNight(st) ? ' 👑' : '') : (st.night + 1) + '번째 밤';
      top.append(chip('', phN, null, 'ph'), chip('📅', chLabel, st.mode === 'camp' ? chDef(st).t + ' — ' + chDef(st).sub + '\n장마다 밤 ' + NIGHTS_PER_CH + '번, 마지막 밤은 칭호 용사.' : '끝없는 침입. 5번째 밤마다 칭호 용사.'),
        chip('💰', Math.floor(st.gold) + '/' + goldCap(st), '금화 / 금고 한도(보물고 칸마다 +300). 넘친 금화는 사라져요.'),
        chip('🔮', Math.floor(st.mana) + '/' + manaCap(st), '마력 / 한도. 주인 스킬·각성에 써요. 마력 샘·서고로 늘려요.'),
        chip('⭐', st.fame, '명성. 쓰러뜨린 용사·제단으로 올라요. 높을수록 강한 마물이 찾아와요.'),
        chip('⚗', st.res, '연구. 연구실·서고에서 쌓여요. 20·45·80·120에서 함정·주인 스킬이 열려요.'),
        chip('❤', Math.round(st.R ? ((st.R.u.find((u) => u.ms) || {}).hp || st.hp) : st.hp) + '/' + st.mhp, '마왕 체력. 0이 되면 패배. 아침마다 25% 회복.'));
      if (st.ph === 'day') top.append(chip('⛏', st.lab, '오늘 남은 작업력. 바위 1칸 = 1, 금맥·마력 결정 = 2. 노동 마물이 많을수록 늘어요.'), chip('💬', st.talk, '오늘 남은 대화 횟수(연회장으로 늘어요).'));
      top.append(chip('👹', nonExec(st) + '/' + cap(st), '마물 수 / 숙소 자리(숙소 1칸 = 1명, 기본 +2). 간부는 따로.'));
      if (st.pr.length || prisonCap(st)) top.append(chip('⛓', st.pr.length + '/' + prisonCap(st), '포로 / 감옥 칸'));
    }

    /* ---------- 오늘 할 일 · 간부 제안 · 정찰 보고(낮, 지도 왼쪽 위) ---------- */
    let todoFold = false;
    function todoList(s) {
      const out = [];
      const jump = (f) => () => { f(); renderSide(); api.sfx('click'); };
      const wage = s.ro.reduce((a, e) => a + (isExec(e.k) ? 0 : e.h ? 15 : MON[e.k].wage), 0);
      const inc = Math.round(40 + 10 * roomPow(s, 'a') + 3 * roomPow(s, 'n'));
      if (wage && s.gold + inc < wage) out.push([10, '💸', '급여 ' + wage + '금이 모자라요', '아침 수입(약 ' + inc + ')을 더해도 급여를 못 줘요 → 모든 마물 기분 -25.\n보물고를 짓거나 금화를 아껴요.', jump(() => { tab = 'build'; tool = 'room'; selRoom = 'a'; })]);
      const eaters = s.ro.filter((e) => !isExec(e.k)).length, food = Math.floor(3 * roomPow(s, 'd') + 2 * roomPow(s, 'n'));
      if (eaters > food) out.push([9, '🍖', '식량 ' + food + '/' + eaters + ' — 식당 짓기', '못 먹은 마물은 아침에 기분 -15. 식당 1칸 = 3명, 정원 1칸 = 2명.', jump(() => { tab = 'build'; tool = 'room'; selRoom = 'd'; })]);
      const sad = s.ro.filter((e) => e.md < 30).sort((a, b) => a.md - b.md)[0];
      if (sad) out.push([8.5, '😟', nameOf(sad.k) + ' 기분 ' + sad.md + ' — 달래기', '기분이 15 아래로 내려가면 떠나요. 대화(+4)·선물(+10)·좋아하는 방.', jump(() => { tab = 'mon'; selU = sad.i; tool = 'look'; })]);
      if (s.talk > 0) { const near = s.ro.filter((e) => e.ev < 3 && !e.tk && e.af >= AFF_TH[e.ev] - 6).sort((a, b) => b.af - a.af)[0]; if (near) out.push([8, '♥', nameOf(near.k) + ' — 대화하면 이야기', '친밀도 ' + near.af + '/' + AFF_TH[near.ev] + '. 대화 한 번(+6)이면 둘만의 이야기가 열려요.', jump(() => { tab = 'mon'; selU = near.i; tool = 'look'; })]); }
      if (s.mem.length) out.push([7, '⚙', '들킨 함정 ' + s.mem.length + '곳 — 옮기기', '노란 테두리 칸은 길드가 기억하는 함정이에요. 용사가 피해 가거나 풀어 버려요. 허물고 다른 자리에 다시 놓아요.', jump(() => { tab = 'build'; tool = 'sell'; })]);
      const path = mainPath(s); const trapsOn = path.filter((c) => s.t[c] !== '-').length;
      if (path.length > 4 && trapsOn < 2) out.push([6.5, '⚙', '용사 길에 함정 ' + trapsOn + '개 — 더 놓기', '점선이 용사가 걸어올 길이에요. 그 위에 함정을 놓아야 작동해요.', jump(() => { tab = 'build'; tool = 'trap'; })]);
      const pend = s.pr.filter((p) => !p.t && !HERO[p.k].boss).length;
      if (pend) out.push([5, '⛓', '포로 ' + pend + '명 설득하기', '날마다 성공률이 올라요. 성공하면 동료가 돼요.', jump(() => { tab = 'pr'; })]);
      const canHire = s.vis.some((k) => s.gold >= hireCost(s, k)) && nonExec(s) < cap(s);
      if (canHire) out.push([4.5, '🚪', '찾아온 마물 고용 가능', '숙소 ' + nonExec(s) + '/' + cap(s) + ' · 금화로 바로 고용할 수 있어요.', jump(() => { tab = 'vis'; })]);
      if (s.lab >= 6) out.push([4, '⛏', '작업력 ' + s.lab + ' 남음 — 더 파기', '작업력은 아침마다 새로 차요. 남기면 아까워요. 금맥(+50)·마력 결정(+20)도 노려 봐요.', jump(() => { tab = 'build'; tool = 'dig'; })]);
      if (nonExec(s) >= cap(s) && s.vis.length) out.push([3.5, '🛏', '숙소가 꽉 찼어요', '숙소 1칸 = 마물 1명. 늘려야 고용할 수 있어요.', jump(() => { tab = 'build'; tool = 'room'; selRoom = 'c'; })]);
      const untalk = s.ro.filter((e) => !e.tk).length;
      if (s.talk > 0 && untalk) out.push([2, '💬', '대화 ' + s.talk + '번 남음', '대화는 친밀도 +6, 기분 +4. 하루 한 번씩.', jump(() => { tab = 'mon'; selU = null; })]);
      return out.sort((a, b) => b[0] - a[0]).slice(0, 3);
    }
    let todoKey = '';
    function renderTodo() {
      const show = st && st.ph === 'day' && !isSpect();
      const key = show ? st.seq + '|' + todoFold + '|' + st.gold + '|' + JSON.stringify(st.prop) : '-';
      if (key === todoKey) return; todoKey = key;
      todoEl.innerHTML = '';
      todoEl.style.display = show ? 'flex' : 'none'; if (!show) return;
      const hd = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap', justifyContent: 'space-between' } });
      hd.append(h('div', { class: 'dk-h', style: { margin: 0 }, text: '📋 오늘 할 일' }), btn(todoFold ? '펼치기' : '접기', () => { todoFold = !todoFold; renderTodo(); }, { act: 'todo_fold', style: { minHeight: '32px', fontSize: '11px', padding: '2px 8px' } }));
      todoEl.append(hd);
      if (todoFold) return;
      // 간부 제안
      const P = st.prop;
      if (P && PROP[P.id]) {
        const D = PROP[P.id]; const c = h('div', { class: 'dk-card', style: { border: '1px solid var(--brass)', background: '#2a1826' } });
        const r = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } });
        r.append(mini(P.c, 'smile', 44, 52));
        const inf = h('div', { style: { flex: '1', minWidth: 0, display: 'flex', flexDirection: 'column', gap: '2px' } });
        inf.append(h('div', { style: { fontWeight: 700, fontSize: '12px' }, text: D.ic + ' ' + nameOf(P.c) + '의 제안 — ' + D.n }), h('div', { class: 'dk-p', style: { color: 'var(--ink)' }, text: '「' + ((PROP_LINE[P.c] || {})[P.id] || '') + '」' }), h('div', { class: 'dk-p', text: D.d + ' · 받아들이면 친밀도 +5' }));
        r.append(inf); c.append(r);
        if (iCan()) { const g = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } }); g.append(btn('✔ 받아들이기', () => sendOp({ t: 'prop', ok: 1 }), { cls: 'pri', act: 'prop_ok', dis: st.gold < D.g, style: { flex: '1', fontSize: '13px' }, tip: D.g ? '금화 ' + D.g + '이 들어요.' : '금화가 들지 않아요.' }), btn('거절', () => sendOp({ t: 'prop', ok: 0 }), { act: 'prop_no', style: { flex: '0 0 72px' }, tip: '거절해도 손해는 없어요.' })); c.append(g); }
        todoEl.append(c);
      }
      const L3 = todoList(st);
      if (!L3.length) todoEl.append(h('p', { class: 'dk-p', text: '급한 일은 없어요. 준비가 되면 밤을 맞이해요.' }));
      L3.forEach(([, ic, t, tp, fn], j) => { const b = h('button', { class: 'dk-todo-i', 'data-action': 'todo' + j, onclick: (e) => { e.stopPropagation(); fn(); } }); b.append(h('span', { class: 'ic', text: ic }), h('span', { text: t })); b.setAttribute('data-tip', tp + '\n누르면 바로 그 화면으로'); todoEl.append(b); });
      // 정찰 보고
      const np = st.np;
      if (np && np.q) {
        const c = h('div', { class: 'dk-card', style: { gap: '3px' } });
        const cntK = {}; np.q.forEach((k) => (cntK[k] = (cntK[k] || 0) + 1));
        const boss = np.q.filter((k) => HERO[k] && HERO[k].boss);
        const goal = (np.goal === 'l' && !cnt(st.r, 'a')) || (np.goal === 'r' && !st.pr.length) ? 'k' : np.goal;
        c.append(h('div', { style: { fontWeight: 700, fontSize: '12px', color: boss.length ? '#f0c040' : 'var(--brass)' }, text: '🔭 정찰 보고 — 오늘 밤 ' + np.q.length + '명' + (boss.length ? ' · 👑 ' + boss.map((k) => HERO[k].n).join('·') : '') }));
        c.append(h('div', { class: 'dk-p', style: { color: 'var(--ink)' }, text: Object.keys(cntK).map((k) => (HERO[k] ? HERO[k].n : k) + (cntK[k] > 1 ? '×' + cntK[k] : '')).join(' · ') }));
        c.append(h('div', { class: 'dk-p', text: '목표: ' + GOALS[goal] + ' — ' + ({ k: '옥좌로 곧장 와요. 길목을 막아요.', l: '보물고를 노려요. 보물고 앞을 지켜요.', r: '감옥을 노려요. 감옥 앞을 지켜요.', s: '둘러보고 돌아가요. 함정을 들키지 않게.' })[goal] }));
        c.setAttribute('data-tip', '정찰꾼이 알아 온 오늘 밤 파티예요. 밤이 되면 이대로 들어와요.\n' + Object.keys(cntK).map((k) => HERO[k] ? HERO[k].n + ' — ' + HERO[k].d : k).join('\n'));
        todoEl.append(c);
      }
    }

    /* ---------- 오른쪽 패널 ---------- */
    function renderSide() {
      if (!st) return;
      side.style.display = st.ph === 'pick' ? 'none' : 'flex';
      tabs.innerHTML = ''; body.innerHTML = ''; foot.innerHTML = '';
      for (let k = minis.length - 1; k >= 0; k--) if (!minis[k].isConnected) minis.splice(k, 1);
      if (st.ph === 'raid') return renderRaidSide();
      const T = [['build', '🏗 건설', 'tab_build'], ['mon', '👹 마물', 'tab_mon'], ['vis', '🚪 방문', 'tab_vis'], ['pr', '⛓ 감옥', 'tab_pr'], ['ms', '👑 주인', 'tab_ms']];
      T.forEach(([k, l, a]) => { const b = h('button', { class: tab === k ? 'on' : '', 'data-action': a, text: l, onclick: () => { tab = k; renderSide(); } }); tabs.append(b); });
      if (tab === 'build') renderBuild(); else if (tab === 'mon') renderMon(); else if (tab === 'vis') renderVis(); else if (tab === 'pr') renderPr(); else renderMs();
      // 준비
      if (st.ph === 'day') {
        const myRd = st.rd[me];
        if (st.n > 1) { const rr = h('div', { class: 'dk-ready' }); st.rd.forEach((r, i) => rr.append(h('span', { class: 'dk-chip', style: { height: '26px' }, text: (api.players[i] || {}).name + (r ? ' ✓' : ' …') }))); body.append(rr); }
        if (iCan()) foot.append(btn(myRd ? '다른 주인을 기다리는 중…' : '🌙 밤을 맞이하기', () => { if (!myRd) { api.act({ t: 'ready' }); api.sfx('whoosh'); } }, { cls: 'pri', act: 'ready', dis: !!myRd, style: { flex: '1' }, tip: '준비가 끝나면 밤이 와요. 협동은 모두 준비해야 시작해요.' }));
      }
    }
    function toolBtn(id, label, act, tipT) { return btn(label, () => { tool = id; msSel = null; renderSide(); }, { cls: tool === id ? 'on' : '', act, tip: tipT, style: { flex: '1', padding: '2px 3px', fontSize: '12px', minWidth: '0' } }); }
    function renderBuild() {
      const row = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } });
      row.append(toolBtn('look', '👆 선택', 'tool_look', '도구 없이 보기·마물 고르기. 마물을 끌어 배치를 옮겨요.'));
      row.append(toolBtn('dig', '⛏ 파기', 'tool_dig', '바위를 끌어서 파요(작업력). 금맥 +50금화, 마력 결정 +20마력. 검푸른 암반은 못 파요.'),
        toolBtn('room', '🏛 방', 'tool_room', '파 놓은 바닥에 끌어서 방을 칠해요. 짝 방과 붙이면 +25%.'),
        toolBtn('trap', '⚙ 함정', 'tool_trap', '방이 아닌 바닥에 함정을 놓아요. 용사가 지나갈 길(점선)에!'),
        toolBtn('sell', '✖ 허물기', 'tool_sell', '방·함정을 없애고 값의 절반을 돌려받아요.'));
      body.append(row);
      body.append(h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } }, btn('↶ 되돌리기', doUndo, { act: 'undo', dis: !iCan() || !canUndo(st, me), style: { flex: '1' }, tip: '방금 한 파기·짓기·허물기를 되돌려요(최대 10번). 사이에 다른 일을 하면 끊겨요.' })));
      if (st.n > 1) body.append(h('p', { class: 'dk-p', text: '협동: 나는 ' + (me + 1) + '번 구역(점선으로 나뉜 ' + (me + 1) + '번째 칸)에서만 파고 지을 수 있어요. 금화·마물은 함께 써요.' }));
      if (tool === 'room' || tool === 'look' || tool === 'dig' || tool === 'sell') {
        body.append(h('div', { class: 'dk-h', text: '방 15종' }));
        const g = h('div', { class: 'dk-grid' });
        let free = 0; for (let i = 0; i < N; i++) if (st.m[i] === '.' && st.r[i] === '-' && st.t[i] === '-' && canZone(st, me, i)) free++;
        g.style.gridTemplateColumns = '1fr';
        ROOMS.forEach((R) => {
          const why = !iCan() ? '지금은 지을 수 없어요' : st.gold < R.c ? '금화가 모자라요(칸당 ' + R.c + ', 지금 ' + Math.floor(st.gold) + ')' : !free ? '빈 바닥이 없어요 — 먼저 ⛏ 파기' : '';
          const it = h('button', { class: 'dk-item dk-room' + (tool === 'room' && selRoom === R.k ? ' on' : '') + (why ? ' lock' : ''), onclick: () => { if (why) { api.toast(why); api.sfx('thud'); return; } tool = 'room'; selRoom = R.k; renderSide(); } });
          const n0 = cnt(st.r, R.k);
          it.append(h('span', { class: 'ric', style: { background: R.col + '55', borderColor: R.col }, text: R.ic }), h('span', { style: { flex: '1', minWidth: 0 } }, h('div', { class: 'nm', text: R.n + (n0 ? ' · ' + n0 + '칸' : '') }), h('div', { class: 'eff', text: R.e || R.d })), h('span', { class: 'sub', style: { flex: 'none' }, text: R.c + '금' }));
          it.setAttribute('data-tip', (why ? '✖ ' + why + '\n' : '') + R.n + ' — ' + R.d + '\n짝 방: ' + RM[R.adj].ic + RM[R.adj].n + '(붙이면 효과 +25%)\n지금 ' + n0 + '칸');
          g.append(it);
        });
        body.append(g);
      }
      if (tool === 'trap') {
        body.append(h('div', { class: 'dk-h', text: '함정 20종 · 연구 ' + st.res }));
        const g = h('div', { class: 'dk-grid' });
        TRAPS.forEach((T) => {
          const lock = st.res < T.rq;
          const it = h('button', { class: 'dk-item' + (selTrap === T.k ? ' on' : '') + (lock ? ' lock' : ''), onclick: () => { if (lock) { api.toast('연구 ' + T.rq + '이 필요해요'); return; } selTrap = T.k; renderSide(); } });
          it.append(h('span', { class: 'ic', text: T.ic }), h('span', null, h('div', { class: 'nm', text: T.n }), h('div', { class: 'sub', text: lock ? '🔒 연구 ' + T.rq : trapCost(st, T.k) + '금' })));
          it.setAttribute('data-tip', T.n + ' — ' + T.d + '\n피해 ' + Math.round(T.dm * trapScale(st)) + ' · 재작동 ' + T.cd + '초' + (lock ? '\n연구 ' + T.rq + '에서 열려요' : ''));
          g.append(it);
        });
        body.append(g);
        body.append(h('div', { class: 'dk-h', text: '연계' }));
        COMBOS.forEach((c) => body.append(h('p', { class: 'dk-p', text: '「' + c[0] + '」 ' + c[1] + ' — ' + c[2] })));
      }
      body.append(h('p', { class: 'dk-p', text: '끌기 = 여러 칸 · Shift+끌기 = 네모 칸 · 오른쪽 클릭 = 끌기/도구 취소 · 휠 = 확대, WASD·방향키·가운데 버튼 끌기 = 화면 이동. 노란 테두리 칸 = 길드가 기억하는 함정 자리.' }));
    }
    function monCard(e, onclick) {
      const M = MON[e.k] || HERO[e.k];
      const row = h('div', { class: 'dk-mon' + (selU === e.i ? ' on' : ''), onclick });
      if (st.ph === 'day' && iCan()) row.addEventListener('mousedown', (ev) => { if (ev.button === 0) pendCard = { u: e.i, x: ev.clientX, y: ev.clientY }; });
      row.append(mini(e.k, e.aw ? 'awakened' : e.md < 30 ? 'sad' : 'neutral', 40, 44));
      const info = h('div', { class: 'info' });
      info.append(h('b', { text: (e.aw ? '✨' : '') + nameOf(e.k) + ' Lv' + e.lv }));
      const bars = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } });
      const bar = (v, col) => { const b = h('div', { class: 'dk-bar' }); b.append(h('i', { style: { width: Math.round(v * 100) + '%', background: col } })); return b; };
      bars.append(bar(e.hp, '#60d080'), bar(e.af / 100, '#ff70a0'), bar(e.md / 100, e.md < 30 ? '#ff8040' : '#e3ae45'));
      info.append(bars);
      info.append(h('span', { class: 'sub', style: { color: 'var(--muted)', fontSize: '11px' }, text: (M.rl || (e.h ? '용사 출신' : '')) + ' · ♥' + e.af + ' · 기분 ' + e.md + (e.tk ? ' · 대화함' : '') }));
      row.append(info);
      row.setAttribute('data-tip', nameOf(e.k) + (M.ps ? ' — ' + M.ps : '') + '\n체력 ' + Math.round(e.hp * 100) + '% · 친밀도 ' + e.af + ' · 기분 ' + e.md + '\n좋아하는 방: ' + (M.like ? RM[M.like].n : '-') + ' · 좋아하는 일: ' + (M.work || '-') + (st.ph === 'day' ? '\n지도로 끌어다 놓으면 그 칸에 배치' : ''));
      return row;
    }
    function renderMon() {
      const sel = st.ro.find((e) => e.i === selU);
      if (sel) {
        const M = MON[sel.k] || HERO[sel.k];
        const card = h('div', { class: 'dk-card' });
        const top2 = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } });
        top2.append(mini(sel.k, sel.aw ? 'awakened' : 'smile', 96, 120));
        const inf = h('div', { style: { flex: '1', minWidth: 0, display: 'flex', flexDirection: 'column', gap: '3px' } });
        inf.append(h('div', { style: { fontWeight: 700, fontSize: '14px' }, text: (sel.aw ? '✨ ' : '') + nameOf(sel.k) }));
        inf.append(h('div', { class: 'dk-p', text: (M.rl || '용사 출신') + ' · Lv ' + sel.lv + ' (경험 ' + sel.xp + '/' + xpNeed(sel.lv) + ')' }));
        inf.append(h('div', { class: 'dk-p', text: M.ps || M.d || '' }));
        const lvM = 1 + 0.1 * (sel.lv - 1), aw = sel.aw ? 1.35 : 1;
        inf.append(h('div', { class: 'dk-p', text: '체력 ' + Math.round(M.hp * lvM * aw) + ' · 공격 ' + Math.round(M.atk * lvM * aw) + ' · 방어 ' + M.def + ' · 사거리 ' + M.rng }));
        const sks = (sel.h ? HERO[sel.k].sk : M.sk.concat(sel.aw ? [M.aw] : []));
        inf.append(h('div', { class: 'dk-p', text: '스킬: ' + sks.map((k) => SK[k] ? SK[k].n : k).join(', ') + (!sel.h && !sel.aw && M.aw ? ' · 각성 시 「' + SK[M.aw].n + '」' : '') }));
        if (M.like) inf.append(h('div', { class: 'dk-p', text: '좋아하는 방 ' + RM[M.like].ic + RM[M.like].n + (cnt(st.r, M.like) ? ' ✓' : ' ✗(기분 -2/일)') + ' · 급여 ' + (isExec(sel.k) ? 0 : sel.h ? 15 : M.wage) }));
        inf.append(h('div', { class: 'dk-p', text: '친밀도 ' + sel.af + '/100 — 이야기 ' + sel.ev + '/3 (25·55·85에서)' }));
        top2.append(inf); card.append(top2);
        if (iCan() && st.ph === 'day') {
          const r = h('div', { class: 'dk-grid3' });
          r.append(btn('💬 대화', () => sendOp({ t: 'talk', u: sel.i }), { tip: '친밀도 +6, 기분 +4. 하루 한 번(남은 대화 ' + st.talk + ').', dis: !!sel.tk || st.talk <= 0 }),
            btn('🎁 선물', () => sendOp({ t: 'gift', u: sel.i }), { tip: '금화 40: 친밀도 +9, 기분 +10. 하루 한 번.', dis: !!sel.gf }),
            btn('📍 배치', () => { tool = 'post'; renderSide(); api.toast('지도에서 지킬 칸을 눌러요'); }, { tip: '밤에 지킬 칸을 정해요(경비실이면 방어 +12).', cls: tool === 'post' ? 'on' : '' }));
          if (!sel.h) r.append(btn('✨ 각성', () => sendOp({ t: 'aw', u: sel.i }), { tip: '친밀도 85 · 레벨 5 · 마력 100. 능력 +35%, 각성 스킬.', dis: !!sel.aw || sel.af < 85 || sel.lv < 5 }));
          if (!isExec(sel.k)) r.append(btn('내보내기', () => { if (confirm(nameOf(sel.k) + '을(를) 내보낼까요?')) { sendOp({ t: 'fire', u: sel.i }); selU = null; } }, { tip: '던전에서 내보내요(급여 절약).' }));
          if (AFF[sel.k] && sel.ev > 0) r.append(btn('📖 다시 보기', () => { for (let n = 0; n < sel.ev; n++) queueLines(AFF[sel.k][n]); }, { tip: '본 친밀도 이야기를 다시 봐요.' }));
          card.append(r);
        }
        card.append(btn('‹ 목록으로', () => { selU = null; tool = 'look'; renderSide(); }));
        body.append(card);
        return;
      }
      body.append(h('p', { class: 'dk-p', text: '초록 = 체력 · 분홍 = 친밀도 · 노랑 = 기분. 기분이 15 아래면 떠나요(급여·식사·좋아하는 방·온천).' }));
      st.ro.forEach((e) => body.append(monCard(e, () => { selU = e.i; renderSide(); })));
    }
    function renderVis() {
      body.append(h('p', { class: 'dk-p', text: '매일 아침 3명이 찾아와요. 좋아하는 방이 있으면 더 자주, 명성이 높으면 강한 마물이 와요. 숙소 ' + nonExec(st) + '/' + cap(st) }));
      st.vis.forEach((k, j) => {
        const M = MON[k]; const card = h('div', { class: 'dk-card' });
        const r = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } });
        r.append(mini(k, 'smile', 72, 96));
        const inf = h('div', { style: { flex: '1', minWidth: 0, display: 'flex', flexDirection: 'column', gap: '2px' } });
        inf.append(h('div', { style: { fontWeight: 700 }, text: M.n }), h('div', { class: 'dk-p', text: M.rl + ' · ' + M.ps }), h('div', { class: 'dk-p', text: '「' + (GREET[k] || '') + '」' }),
          h('div', { class: 'dk-p', text: '체력 ' + M.hp + ' · 공격 ' + M.atk + ' · 급여 ' + M.wage + ' · 좋아하는 방 ' + RM[M.like].n }), h('div', { class: 'dk-p', text: '스킬: ' + M.sk.map((x) => SK[x].n).join(', ') }));
        r.append(inf); card.append(r);
        if (iCan()) card.append(btn('고용 · ' + hireCost(st, k) + '금', () => sendOp({ t: 'hire', v: j }), { cls: 'pri', dis: st.gold < hireCost(st, k) || nonExec(st) >= cap(st) }));
        body.append(card);
      });
      if (!st.vis.length) body.append(h('p', { class: 'dk-p', text: '오늘은 찾아온 마물이 없어요.' }));
    }
    function renderPr() {
      body.append(h('p', { class: 'dk-p', text: '쓰러진 용사는 감옥 빈 칸만큼 붙잡혀요(함정문은 확실히). 설득하면 동료가 되고, 날마다 성공률이 올라요. 구출 파티가 감옥을 노릴 수 있어요.' }));
      st.pr.forEach((p, j) => {
        const B = HERO[p.k]; const card = h('div', { class: 'dk-card' });
        const r = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } });
        r.append(mini(p.k, p.d > 1 ? 'shy' : 'angry', 56, 72));
        const chn = Math.round(Math.min(1, 0.22 + (st.mt === 'cha' ? 0.25 : 0) + p.d * 0.1 + Math.min(0.15, st.fame / 400)) * 100);
        r.append(h('div', { style: { flex: '1' } }, h('div', { style: { fontWeight: 700 }, text: B.n }), h('div', { class: 'dk-p', text: B.d }), h('div', { class: 'dk-p', text: '갇힌 지 ' + p.d + '일 · 설득 성공률 ' + (B.boss ? 0 : chn) + '%' })));
        card.append(r);
        if (iCan()) { const g = h('div', { class: 'dk-grid3' }); g.append(btn('💬 설득', () => sendOp({ t: 'pers', p: j, how: 'talk' }), { dis: !!p.t || !!B.boss, tip: '성공하면 동료(숙소 자리 필요). 하루 한 번.' }), btn('💰 몸값', () => sendOp({ t: 'pers', p: j, how: 'ransom' }), { tip: '금화 +80, 명성 -1. 풀어 줘요.' }), btn('🕊 석방', () => sendOp({ t: 'pers', p: j, how: 'free' }), { tip: '명성 +3. 그냥 풀어 줘요.' })); card.append(g); }
        body.append(card);
      });
      if (!st.pr.length) body.append(h('p', { class: 'dk-p', text: '갇힌 용사가 없어요. 감옥 칸 ' + prisonCap(st) + '개.' }));
    }
    function renderMs() {
      const T = MTYPE[st.mt] || {};
      const card = h('div', { class: 'dk-card' });
      const r = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap', alignItems: 'flex-start' } });
      r.append(mini('master', 'smile', 84, 108));
      r.append(h('div', { style: { flex: '1' } }, h('div', { style: { fontWeight: 700, fontSize: '14px' }, text: '마왕 · ' + (T.ic || '') + ' ' + (T.n || '') + ' 타입' }), h('div', { class: 'dk-p', text: T.d || '' }),
        h('div', { class: 'dk-p', text: (st.mode === 'camp' ? chDef(st).t + ' — ' + chDef(st).sub : '끝없는 침입') }), h('div', { class: 'dk-p', text: '쓰러뜨린 용사 ' + st.st.kills + ' · 칭호 격파 ' + st.st.bosses + ' · 길드가 기억한 함정 ' + st.mem.length })));
      card.append(r); body.append(card);
      body.append(h('div', { class: 'dk-h', text: '주인 스킬 (밤에 써요)' }));
      MSK.filter((M) => M.ty === 'all' || M.ty === st.mt).forEach((M) => {
        const lock = st.res < M.rq;
        const it = h('div', { class: 'dk-item' + (lock ? ' lock' : '') });
        it.append(h('span', { class: 'ic', text: M.ic }), h('span', null, h('div', { class: 'nm', text: M.n + (lock ? ' 🔒 연구 ' + M.rq : '') }), h('div', { class: 'sub', text: '마력 ' + M.mp + ' · ' + M.cd + '초' }), h('div', { class: 'dk-p', text: M.d })));
        body.append(it);
      });
      body.append(h('div', { class: 'dk-h', text: '최근 소식' }));
      st.log.slice(-6).forEach((t) => body.append(h('p', { class: 'dk-p', text: '· ' + t })));
      body.append(btn('📜 대화 기록', toggleLog, { act: 'log' }));
      body.append(h('div', { class: 'dk-h', text: '대화 설정' }));
      const sp = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } });
      ['slow', 'normal', 'fast', 'instant'].forEach((k) => sp.append(btn(SP_KO[k], () => { VNS.sp = k; saveVNS(); renderSide(); }, { cls: VNS.sp === k ? 'on' : '', style: { flex: '1', padding: '2px 4px' }, tip: '글자가 나오는 속도' })));
      body.append(h('p', { class: 'dk-p', text: '글자 속도' }), sp);
      body.append(btn(VNS.auto ? '자동 넘김 ✓ 켬' : '자동 넘김 끔', toggleAuto, { act: 'auto', cls: VNS.auto ? 'on' : '', tip: '글이 다 나오면 잠시 뒤 저절로 다음 줄로 넘어가요.' }));
      if (L.ai && L.ai.setGame) {
        const glob = (() => { try { return L.ai.enabled() || !!L.ai._mock; } catch (e) { return false; } })(), onG = L.ai.gameOn ? L.ai.gameOn('dkeeper') : true;
        body.append(btn('🤖 AI 서술: ' + (!glob ? '꺼짐(설정에서 켜기)' : onG ? '이 게임 켬 ✓' : '이 게임 끔'), () => { if (!glob) { api.toast('홈 설정 「🤖 AI 서술」에서 먼저 켜고 키를 넣어 주세요'); return; } L.ai.setGame('dkeeper', !onG); renderSide(); }, { cls: glob && onG ? 'on' : '', tip: 'Claude API로 대사를 그때그때 지어요. 꺼 두면 자료 대사만 써요(규칙·수치는 같아요).' }));
      }
    }
    function renderRaidSide() {
      const R = st.R;
      body.append(h('div', { class: 'dk-h', text: (R.boss ? '👑 칭호 용사의 밤' : '🌙 침입') + ' · 목표: ' + GOALS[R.goal] }));
      const sp = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap' } });
      sp.append(btn('1×', () => api.act({ t: 'sp', v: 1 }), { cls: R.sp === 1 ? 'on' : '', act: 'speed', style: { flex: '1' }, tip: '보통 속도' }), btn('2×', () => api.act({ t: 'sp', v: 2 }), { cls: R.sp === 2 ? 'on' : '', style: { flex: '1' }, tip: '두 배 속도' }));
      if (soloPause()) sp.append(btn(paused ? '▶ 계속' : '⏸ 멈춤', () => { paused = !paused; renderSide(); }, { act: 'pause', cls: paused ? 'on' : '', style: { flex: '1.3' }, tip: '혼자 판에서만 멈출 수 있어요. 멈춘 채로 스킬을 골라 둘 수 있어요.' }));
      body.append(sp);
      const mu = R.u.find((u) => u.ms);
      if (mu) { const hb = h('div', { class: 'dk-row', style: { flexWrap: 'nowrap', fontSize: '12px' } }); const bar = h('div', { class: 'dk-bar', style: { height: '9px' } }); const fr = Math.max(0, mu.hp / mu.mh); bar.append(h('i', { style: { width: Math.round(fr * 100) + '%', background: fr < 0.35 ? '#ff4060' : '#e04060' } })); hb.append(h('span', { style: { flex: 'none', fontWeight: 700 }, text: '❤ 마왕 ' + Math.round(mu.hp) + '/' + mu.mh }), bar); body.append(hb); }
      if (feed.length) { const fd = h('div', { class: 'dk-feed' }); feed.slice().reverse().forEach((t, i) => fd.append(h('div', { style: { opacity: String(1 - i * 0.11) }, text: t }))); body.append(fd); }
      body.append(h('div', { class: 'dk-h', text: '주인 스킬 · 마력 ' + Math.floor(st.mana) }));
      const g = h('div', { class: 'dk-sk' });
      let ki = 0;
      MSK.filter((M) => M.ty === 'all' || M.ty === st.mt).forEach((M) => {
        const lock = st.res < M.rq, cd = Math.max(0, (R.mcd[M.k] || 0) - R.t), noMp = st.mana < M.mp;
        const b = h('button', { class: 'dk-btn' + (msSel === M.k ? ' on' : ''), onclick: () => { if (lock) return api.toast('연구 ' + M.rq + '이 필요해요'); if (cd > 0) return api.toast(Math.ceil(cd) + '초 뒤에 다시 써요'); if (noMp) return api.toast('마력이 모자라요'); msSel = msSel === M.k ? null : M.k; renderSide(); } });
        b.append(h('span', { class: 'i', text: lock ? '🔒' : M.ic }), h('span', { text: M.n }), h('span', { class: 'sub', style: { fontFamily: 'var(--f-mono)', color: noMp ? '#ff8080' : 'var(--muted)' }, text: cd > 0 ? Math.ceil(cd) + '초' : M.mp + '마력' }));
        if (!lock) b.setAttribute('data-action', 'ms' + (++ki));
        b.disabled = !iCan() && !api.online ? false : !iCan();
        if (lock || cd > 0 || noMp) b.style.opacity = '.5';
        b.setAttribute('data-tip', M.n + ' — ' + M.d + '\n마력 ' + M.mp + ' · 재사용 ' + M.cd + '초' + (lock ? '\n연구 ' + M.rq + '에서 열려요' : '\n고른 뒤 지도를 누르면 써요. 오른쪽 클릭 = 취소.'));
        g.append(b);
      });
      body.append(g);
      body.append(h('div', { class: 'dk-h', text: '침입자' }));
      R.u.filter((u) => u.s === 1).forEach((u) => {
        const B = HERO[u.k]; const it = h('div', { class: 'dk-item', style: { minHeight: '34px', cursor: 'default' } });
        const bar = h('div', { class: 'dk-bar' }); bar.append(h('i', { style: { width: Math.round(Math.max(0, u.hp / u.mh) * 100) + '%', background: u.b ? '#f0c040' : '#5ab0ff' } }));
        it.append(h('span', { style: { width: '108px', flex: 'none', fontWeight: 600 }, text: (u.b ? '👑' : '') + B.n }), bar, h('span', { class: 'sub', text: { k: '⚔', l: '💰', r: '⛓', s: '👁', x: '🏃' }[u.g] || '' }));
        it.setAttribute('data-tip', B.n + ' — ' + B.d);
        body.append(it);
      });
      if (R.q.length) body.append(h('p', { class: 'dk-p', text: '입구 밖에 ' + R.q.length + '명 더 있어요.' }));
      body.append(h('p', { class: 'dk-p', text: '쓰러뜨림 ' + R.kills + ' · 전리품 ' + R.gain + ' · 포획 ' + R.caps.length + (R.stolen ? ' · 도둑맞음 ' + R.stolen : '') }));
    }
    let sideKey = '';
    function sideSig() { // 침입 중엔 0.5초마다 바뀌는 숫자만 다시 그림
      const R = st.R; return feed.length + (feed[feed.length - 1] || '') + '|' + st.ph + '|' + tab + '|' + selU + '|' + tool + '|' + msSel + '|' + paused + '|' + (R ? R.sp + '|' + Math.floor(st.mana) + '|' + R.u.filter((u) => u.s === 1).map((u) => u.i + ':' + Math.round(u.hp / u.mh * 20)).join(',') + '|' + R.kills + '|' + R.q.length + '|' + JSON.stringify(R.mcd) : st.seq);
    }

    /* ---------- 고르기 ---------- */
    let pick0 = { mt: null, ex: null }, pbar = null;
    function renderPick() {
      modal.style.display = 'block'; modal.innerHTML = ''; modal.style.width = 'min(1080px, calc(100% - 40px))'; modal.style.left = '50%';
      const done = !!st.pk[me];
      modal.append(h('div', { style: { font: '700 24px var(--f-display), sans-serif', color: 'var(--brass)' }, text: '던전 주인 — 시작 준비' }));
      if (isSpect()) { modal.append(h('p', { class: 'dk-p', text: '자리 없이 보고 있어요.' })); return; }
      if (me === 0) {
        modal.append(h('div', { class: 'dk-h', text: '① 마왕의 타입' }));
        const g = h('div', { class: 'dk-pick' });
        Object.keys(MTYPE).forEach((k) => { const T = MTYPE[k]; const b = h('button', { class: 'dk-pk' + (pick0.mt === k ? ' on' : '') + (done ? ' off' : ''), onclick: () => { if (done) return; pick0.mt = k; renderPick(); } }); b.append(h('div', { style: { fontSize: '26px' }, text: T.ic }), h('div', { style: { fontWeight: 700, fontSize: '15px' }, text: T.n }), h('div', { class: 'dk-p', text: T.d }), h('div', { class: 'dk-p', text: '스킬: ' + MSK.filter((M) => M.ty === k).map((M) => M.n).join(' · ') })); g.append(b); });
        modal.append(g);
      } else modal.append(h('p', { class: 'dk-p', text: '마왕의 타입은 방장(1번 자리)이 정해요. 나는 함께 던전을 지킬 간부를 골라요.' }));
      modal.append(h('div', { class: 'dk-h', text: (me === 0 ? '② ' : '') + '처음 함께할 간부 (나머지는 장이 넘어갈 때 합류해요)' }));
      const g2 = h('div', { class: 'dk-pick' });
      EXEC.forEach((a) => {
        const k = a[0], taken = st.pk.includes(k) && st.pk[me] !== k;
        const b = h('button', { class: 'dk-pk' + (pick0.ex === k || st.pk[me] === k ? ' on' : '') + (taken || done ? ' off' : ''), onclick: () => { if (taken || done) return; pick0.ex = k; renderPick(); } });
        const c = h('canvas'); c.width = 240; c.height = 360; const gg = c.getContext('2d'); const dr = () => { const im = portraitFor(k, 'neutral'); gg.fillStyle = '#d8d4dc'; gg.fillRect(0, 0, 240, 360); try { const iw = im.naturalWidth || im.width, ih = im.naturalHeight || im.height, sc = Math.max(240 / iw, 360 / ih); gg.drawImage(im, (240 - iw * sc) / 2, 0, iw * sc, ih * sc); } catch (e) {} }; dr(); c._draw = dr; minis.push(c);
        b.append(c, h('div', { style: { fontWeight: 700, fontSize: '14px' }, text: a[1] + (taken ? ' (다른 주인)' : '') }), h('div', { class: 'dk-p', text: a[3] + ' · ' + a[12] }), h('div', { class: 'dk-p', text: '스킬: ' + a[10].map((x) => SK[x].n).join(', ') }));
        g2.append(b);
      });
      modal.append(g2);
      const ok = !done && pick0.ex && (me !== 0 || pick0.mt);
      modal.append(h('div', { class: 'dk-row', style: { justifyContent: 'flex-end', marginTop: '10px', position: 'sticky', bottom: '-18px', background: 'rgba(20,14,28,.97)', padding: '8px 0' } }, btn(done ? '골랐어요 — 다른 주인을 기다려요' : '이대로 시작', () => { if (!ok) return api.toast(me === 0 ? '타입과 간부를 골라요' : '간부를 골라요'); api.act({ t: 'pick', mt: pick0.mt, ex: pick0.ex }); }, { cls: 'pri', act: 'ready', dis: !ok })));
      if (st.n > 1 && !pbar) pbar = api.pickBar({ picked: (i) => !!st.pk[i], onForce: () => { api.act({ t: 'force' }); } });
    }

    /* ---------- 아침 보고 ---------- */
    function renderMorning() {
      if (st.ph !== 'morn' || isSpect() || st.rd[me] || vn) { if (st.ph !== 'pick') modal.style.display = 'none'; return; }
      const r = st.rep; if (!r) return;
      modal.style.display = 'block'; modal.innerHTML = ''; modal.style.width = 'min(560px, calc(100% - 420px))'; modal.style.left = 'calc((100% - 376px) / 2)';
      modal.append(h('div', { style: { font: '700 22px var(--f-display), sans-serif', color: 'var(--brass)' }, text: '🌅 ' + (st.night + 1) + '번째 아침' }));
      const li = (ic, t, c) => modal.append(h('div', { style: { display: 'flex', gap: '8px', fontSize: '14px', padding: '3px 0', color: c || 'var(--ink)' } }, h('span', { style: { width: '22px' }, text: ic }), h('span', { text: t })));
      modal.append(h('div', { class: 'dk-h', text: '어젯밤' }));
      li('⚔', '쓰러뜨린 용사 ' + r.kills + '명' + (r.bossDown ? ' · 칭호 용사 격파!' : '') + ' · 전리품 금화 +' + r.gain);
      if (r.caps) li('⛓', '포획 ' + r.caps + '명 (감옥 탭에서 설득)');
      if (r.esc) li('🏃', '도망친 용사 ' + r.esc + '명' + (r.mem ? ' · 함정 ' + r.mem + '곳이 길드에 알려졌어요' : ''), '#ffcc80');
      if (r.stolen) li('💸', '도둑맞은 금화 -' + r.stolen, '#ff9080');
      if (r.freed) li('🔓', '포로 ' + r.freed + '명이 구출됐어요', '#ff9080');
      if (r.ko.length) li('💤', '쓰러졌던 마물: ' + r.ko.map(nameOf).join(', '), '#ffcc80');
      modal.append(h('div', { class: 'dk-h', text: '오늘 아침' }));
      li('💰', '수입 +' + r.inc.gold + ' · 급여 -' + r.wage + (r.unpaid ? ' (못 줬어요! 기분 -25)' : ''), r.unpaid ? '#ff9080' : null);
      li('🔮', '마력 +' + r.inc.mana + ' · ⚗ 연구 +' + r.inc.res + ' · ⭐ 명성 ' + (r.inc.fame >= 0 ? '+' : '') + r.inc.fame);
      if (r.unfed) li('🍖', r.unfed + '명이 굶었어요(기분 -15). 식당·정원을 늘려요.', '#ff9080');
      if (r.lvup.length) li('⬆', '레벨 업: ' + r.lvup.map(nameOf).join(', '));
      if (r.unlock.length) li('🔓', '열림: ' + r.unlock.join(', '), '#a0ffb0');
      if (r.left.length) li('👋', '떠난 마물: ' + r.left.map(nameOf).join(', '), '#ff9080');
      li('❤', '마왕 체력 ' + st.hp + '/' + st.mhp);
      if (isBossNight(st) || (st.mode === 'camp' && st.nd === NIGHTS_PER_CH - 2)) li('👑', '다음 밤에는 칭호 용사가 와요!', '#ffd060');
      modal.append(h('div', { class: 'dk-row', style: { justifyContent: 'flex-end', marginTop: '10px' } }, btn('다음 날로 ▶', () => api.act({ t: 'ack' }), { cls: 'pri', act: 'ready' })));
    }

    /* ---------- 행동 보내기(미리 확인) ---------- */
    function sendOp(op) {
      if (!iCan()) return;
      const err = doOp(JSON.parse(JSON.stringify(st)), me, op);
      if (err) { api.toast(err); api.sfx('thud'); return; }
      api.act(op); api.sfx('click');
    }
    function sendBatch(cells) {
      if (!iCan() || st.ph !== 'day') return;
      const tmp = JSON.parse(JSON.stringify(st)); const ops = []; let err = '';
      for (const c of cells) {
        const op = tool === 'dig' ? { t: 'dig', c } : tool === 'room' ? { t: 'room', c, k: selRoom } : tool === 'trap' ? { t: 'trap', c, k: selTrap } : { t: 'sell', c };
        const e = doOp(tmp, me, op); if (e) { err = err || e; continue; } ops.push(op);
      }
      if (!ops.length) { if (err) api.toast(err); api.sfx('thud'); return; }
      if (ops.length === 1) api.act(ops[0]); else api.act({ t: 'batch', ops });
      api.sfx(tool === 'dig' ? 'thud' : 'pop');
      if (err && ops.length < cells.length) api.toast(err);
    }

    /* ---------- 입력 ---------- */
    function local(e) { const r = cv.cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
    function cellTip(c) {
      if (c < 0 || !st) return '';
      const ch = st.m[c]; const out = [];
      out.push({ '#': '바위 — 파면 바닥(작업력 1)', '$': '금맥 — 파면 금화 +50(작업력 2)', '*': '마력 결정 — 파면 마력 +20(작업력 2)', X: '단단한 암반 — 못 파요', '.': '바닥', '~': '지하수 — 걷기 느림, 늘 젖어 있음', E: '입구 — 용사가 들어와요', H: '마왕의 옥좌 — 지켜야 할 곳' }[ch] || '');
      if (st.r[c] !== '-') { const R = RM[st.r[c]]; out.push(R.ic + ' ' + R.n + ' — ' + R.d); }
      if (st.t[c] !== '-') { const T = TP[st.t[c]]; out.push(T.ic + ' ' + T.n + ' — ' + T.d); }
      if (st.mem.includes(c)) out.push('⚠ 길드가 기억하는 함정 자리');
      if (st.ph === 'day' && iCan() && toolOp(c)) {
        const r = simCells([c]), err = r.bad.get(c);
        const nm = tool === 'dig' ? '⛏ 파기' : tool === 'room' ? RM[selRoom].ic + ' ' + RM[selRoom].n : tool === 'trap' ? TP[selTrap].ic + ' ' + TP[selTrap].n : '✖ 허물기';
        let v = err ? '✗ ' + err : (r.gold ? '금화 ' + (r.gold > 0 ? '+' : '') + r.gold : '') + (r.lab ? ' 작업력 ' + r.lab : '') + (r.mana ? ' 마력 +' + r.mana : '');
        if (!err && tool === 'room' && NB4[c].some((j) => st.r[j] === RM[selRoom].adj)) v += ' · 짝 방(' + RM[RM[selRoom].adj].n + ')과 붙음 +25%';
        if (!err && tool === 'trap') v += mainPath(st).includes(c) ? ' · 용사 길 위 ✓' : ' · 용사 길(점선)에서 벗어남';
        out.push('▶ ' + nm + ': ' + (v || '가능'));
      }
      if (st.ph === 'day' && tool === 'post' && selU != null) out.push(walkT(st.m[c]) ? '📍 누르면 ' + nameOf((st.ro.find((x) => x.i === selU) || {}).k) + '을(를) 여기에 배치' : '✗ 걸을 수 있는 칸이 아니에요');
      if (st.ph === 'day' && tool === 'look' && st.ro.some((x) => x.p === c)) out.push('끌어서 다른 칸으로 옮기면 배치 변경');
      if (st.n > 1) out.push((zoneOf(st, c) + 1) + '번 구역(' + ((api.players[zoneOf(st, c)] || {}).name || '') + ')');
      const here = st.R ? st.R.u.filter((u) => cellOf(u) === c) : st.ro.filter((e) => e.p === c);
      if (here.length) out.push('👥 ' + here.map((u) => nameOf(u.k) + (u.hp != null && st.R ? ' ' + Math.round(u.hp) + '/' + u.mh : '')).join(', '));
      return out.filter(Boolean).join('\n');
    }
    const overMap = (e) => { const sr = side.getBoundingClientRect(); return !(side.style.display !== 'none' && e.clientX >= sr.left && e.clientX <= sr.right && e.clientY >= sr.top && e.clientY <= sr.bottom) && e.target === cv.cv; };
    const rectCells = (a, b) => { const out = []; const x0 = Math.min(cx(a), cx(b)), x1 = Math.max(cx(a), cx(b)), y0 = Math.min(cy(a), cy(b)), y1 = Math.max(cy(a), cy(b)); for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) out.push(idx(x, y)); return out.slice(0, 300); };
    const onDown = (e) => {
      if (!st) return;
      if (e.button === 1) { e.preventDefault(); panDrag = { x: e.clientX, y: e.clientY, cx: camX, cy: camY }; return; }
      if (e.button === 2) { if (drag) { drag = null; api.sfx('click'); } return; }
      const p = local(e); const c = cellAt(p.x, p.y); if (c < 0) return;
      if (st.ph === 'raid') {
        if (msSel) { if (!iCan()) return; const err = castMS(JSON.parse(JSON.stringify(st)), msSel, c); if (err) { api.toast(err); return; } api.act({ t: 'ms', k: msSel, c }); msSel = null; renderSide(); return; }
        const u = st.R.u.find((o) => cellOf(o) === c); selU = u ? u.ri || u.i : null; return;
      }
      if (st.ph !== 'day') return;
      if (tool === 'post' && selU != null) { sendOp({ t: 'post', u: selU, c }); tool = 'look'; renderSide(); return; }
      if (tool === 'look') { const e2 = st.ro.find((x) => x.p === c); if (e2) { selU = e2.i; tab = 'mon'; renderSide(); if (iCan()) drag = { mon: e2.i, from: c, moved: false }; } return; }
      drag = { cells: [c], start: c, rect: e.shiftKey };
    };
    const onMove = (e) => {
      if (!st) return;
      if (panDrag) { camX = panDrag.cx - (e.clientX - panDrag.x) / Z; camY = panDrag.cy - (e.clientY - panDrag.y) / Z; layout(); return; }
      const p = local(e); mouse = e.target === cv.cv ? p : null; const c = overMap(e) ? cellAt(p.x, p.y) : -1;
      if (pendCard && !drag && Math.hypot(e.clientX - pendCard.x, e.clientY - pendCard.y) > 6) { drag = { mon: pendCard.u, from: -1, moved: true }; pendCard = null; }
      if (c !== hover) { hover = c; if (!tipEl) showTip(cellTip(c), e.clientX, e.clientY); }
      else if (!tipEl && c >= 0) showTip(cellTip(c), e.clientX, e.clientY);
      if (c < 0 && !tipEl) showTip('');
      if (!drag || c < 0) return;
      if (drag.mon != null) { if (c !== drag.from) drag.moved = true; return; }
      if (drag.rect || e.shiftKey) { drag.rect = true; drag.cells = rectCells(drag.start, c); }
      else if (!drag.cells.includes(c)) { const l = drag.cells[drag.cells.length - 1]; // 빠르게 끌어도 칸이 비지 않게 사이를 메움
        const dx = cx(c) - cx(l), dy = cy(c) - cy(l), n = Math.max(Math.abs(dx), Math.abs(dy));
        for (let k = 1; k <= n; k++) { const q = idx(cx(l) + Math.round(dx * k / n), cy(l) + Math.round(dy * k / n)); if (!drag.cells.includes(q)) drag.cells.push(q); } }
    };
    const onUp = (e) => {
      if (panDrag) { panDrag = null; return; }
      pendCard = null;
      if (!drag) return;
      const d = drag; drag = null;
      if (d.mon != null) { if (d.moved && hover >= 0 && hover !== d.from && st && st.ph === 'day') { sendOp({ t: 'post', u: d.mon, c: hover }); selU = d.mon; tool = 'look'; renderSide(); } return; }
      if (e && e.button === 2) return;
      sendBatch(d.cells);
    };
    const onCtx = (e) => { e.preventDefault(); if (drag) { drag = null; return; } if (msSel || tool !== 'look') { msSel = null; tool = 'look'; renderSide(); } };
    const onLeave = () => { hover = -1; mouse = null; if (!tipEl) showTip(''); };
    const onWheel = (e) => { if (!st || st.ph === 'pick') return; e.preventDefault(); userZoom = true; const p = local(e); setZoom(zoom * (e.deltaY < 0 ? 1.15 : 1 / 1.15), p.x, p.y); };
    cv.cv.addEventListener('mousedown', onDown); window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp);
    cv.cv.addEventListener('contextmenu', onCtx); cv.cv.addEventListener('mouseleave', onLeave); cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('auxclick', (e) => e.preventDefault());
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      if (logEl.style.display === 'block' && id === 'log') return toggleLog();
      if (id === 'auto') return toggleAuto();
      if (vn) { if (id === 'adv' || id === 'pause' || id === 'ready') vnAdvance(); else if (id === 'skip') vnSkip(); else if (id === 'log') toggleLog(); return; }
      if (id === 'log') return toggleLog();
      if (id === 'zoom_in') { userZoom = true; return setZoom(zoom * 1.25); }
      if (id === 'zoom_out') { userZoom = true; return setZoom(zoom / 1.25); }
      if (id === 'cam_fit') { if (zoom > 1.01 && !userZoom) { zoom = 1; layout(); userZoom = true; } else fitView(); return; }
      if (/^pan_/.test(id)) return;
      if (st.ph === 'day') {
        const tm = { tool_look: 'look', tool_dig: 'dig', tool_room: 'room', tool_trap: 'trap', tool_sell: 'sell' };
        if (tm[id]) { tool = tool === tm[id] && id !== 'tool_look' ? 'look' : tm[id]; msSel = null; if (tool !== 'look') tab = 'build'; renderSide(); return; }
        const tb = { tab_build: 'build', tab_mon: 'mon', tab_vis: 'vis', tab_pr: 'pr', tab_ms: 'ms' };
        if (tb[id]) { tab = tb[id]; renderSide(); return; }
        if (id === 'undo') { doUndo(); return; }
        if (id === 'ready' && iCan() && !st.rd[me]) { api.act({ t: 'ready' }); return; }
      }
      if (st.ph === 'morn' && id === 'ready' && iCan() && !st.rd[me]) { api.act({ t: 'ack' }); return; }
      if (st.ph === 'pick' && id === 'ready') { const b = modal.querySelector('.dk-btn.pri'); if (b) b.click(); return; }
      if (st.ph === 'raid') {
        if (id === 'pause' && soloPause()) { paused = !paused; renderSide(); return; }
        if (id === 'speed') { api.act({ t: 'sp', v: st.R.sp === 2 ? 1 : 2 }); return; }
        const m = /^ms(\d)$/.exec(id); if (m) { const list = MSK.filter((M) => (M.ty === 'all' || M.ty === st.mt) && st.res >= M.rq); const M = list[+m[1] - 1]; if (M) { msSel = msSel === M.k ? null : M.k; renderSide(); } }
      }
    }) : null;
    function doUndo() {
      if (!iCan() || !canUndo(st, me)) { api.toast('되돌릴 건설이 없어요(다른 일을 하면 끊겨요)'); api.sfx('thud'); return; }
      api.act({ t: 'undo' }); api.sfx('click');
    }

    /* ---------- 침입 시계 ---------- */
    function tickLoop(now) {
      if (!st || st.ph !== 'raid' || !st.R || !ticker() || paused) return;
      if (vn && soloPause()) return;
      const iv = 500 / (st.R.sp || 1) / Math.max(1, (L.debug && L.debug.speed) || 1);
      if (st.R.n === lastTickN && now - lastTickAt < iv * 3) return;
      if (now - lastTickAt < iv) return;
      lastTickN = st.R.n; lastTickAt = now;
      api.act({ t: 'tk', n: st.R.n });
    }
    stopLoop = U.loop((dt, now) => {
      now = performance.now();
      if (vn) {
        const sp = Math.max(1, (L.debug && L.debug.speed) || 1);
        const n2 = Math.min(vn.text.length, Math.floor((now - vn.t0) / 1000 * (CPS[VNS.sp] || 42) * sp));
        if (n2 !== vn.shown) { vn.shown = n2; vnTx.textContent = vn.text.slice(0, n2); if (n2 >= vn.text.length) vn.full = now; }
        if (autoVN() && !vn.wait && now - vn.t0 > 700 / sp + vn.text.length * 20 / sp) vnAdvance();
        else if (VNS.auto && !vn.wait && vn.full && vn.shown >= vn.text.length && now - vn.full > 900 + vn.text.length * 45) vnAdvance();
      }
      tickLoop(now);
      if (api.input && st && st.ph !== 'pick' && zoom > 1) { // 카메라 이동(키·화면 가장자리)
        const k = (dt || 0.016) * 14 / zoom;
        let dx = api.input.axis ? api.input.axis('pan_l', 'pan_r') : 0, dy = api.input.axis ? api.input.axis('pan_u', 'pan_d') : 0;
        if (mouse && !drag && !panDrag && !vn) { if (mouse.x < 14) dx = -1; else if (mouse.x > 8 + AW - 6 && mouse.x < 8 + AW + 4) dx = 1; if (mouse.y < 58 && mouse.y > 46) dy = -1; else if (mouse.y > cv.h - 14) dy = 1; }
        if (dx || dy) panBy(dx * k, dy * k);
      }
      draw(now);
    });

    /* ---------- 갱신 ---------- */
    function update(s, prev) {
      const was = st; st = s;
      if (was && st.R && was.R && st.R.n !== was.R.n) { prevU = new Map(was.R.u.map((u) => [u.i, { x: u.x, y: u.y }])); tUpd = performance.now(); playFx(st.R); }
      else if (st.R && (!was || !was.R)) { prevU = new Map(); tUpd = performance.now(); }
      if (!st.R && was && was.R && st.lastRaid) playFx({ fx: st.lastRaid.fx, u: [] });
      if (st.R) { lastTickN = -1; const mu = st.R.u.find((u) => u.ms); if (mu) { if (lastMhp != null && mu.hp < lastMhp - 0.5) { hitEl.style.opacity = '1'; setTimeout(() => (hitEl.style.opacity = '0'), 260); const now = performance.now(); if (now - hitAt > 6000) { hitAt = now; showBanner('⚠ 마왕이 공격받고 있어요! (' + Math.round(mu.hp) + '/' + mu.mh + ')', 1600); pushFeed('⚠ 마왕 피격'); } } lastMhp = mu.hp; } } else lastMhp = null;
      if (first) { first = false; lastEv = st.evn; layout(); fitView(); }
      else handleEvents();
      if (st.ph === 'pick') renderPick(); else { if (pbar) { pbar.destroy(); pbar = null; } if (modal.style.display === 'block' && st.ph !== 'morn') modal.style.display = 'none'; }
      renderTop(); renderTodo();
      const sig = sideSig(); if (sig !== sideKey) { sideKey = sig; renderSide(); }
      renderMorning();
      if (was && was.ph !== st.ph) { if (st.ph === 'raid') { vnQ.length = 0; if (vn) vnNext(); tool = 'look'; selU = null; paused = false; api.sfx('whoosh'); } if (st.ph === 'day') { msSel = null; tab = 'build'; LM.tick(); if (!userZoom) fitView(); } if (st.ph === 'raid') feed.length = 0; if (st.ph === 'over') api.sfx(st.win ? 'win' : 'lose'); }
    }
    // 대화가 끝나면 아침 보고를 보여 줌
    const vnWatch = setInterval(() => { if (st && st.ph === 'morn' && !vn && modal.style.display !== 'block') renderMorning(); }, 250);

    return {
      update,
      destroy() {
        stopLoop && stopLoop(); clearInterval(vnWatch);
        window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); window.removeEventListener('dk-img', onImg);
        if (offIn) offIn(); if (pbar) pbar.destroy();
        cv.destroy(); style.remove(); ui.remove();
      },
    };
  }

  /* ================= 도감 ================= */
  function codex() {
    return [
      { h: '방', p: ['파 놓은 바닥에 칠해요. 짝 방과 붙은 칸은 효과 +25%.'], rows: ROOMS.map((R) => ({ icon: R.ic, name: R.n, tag: R.c + '금/칸 · 짝: ' + RM[R.adj].n, desc: R.d })) },
      { h: '함정', p: ['용사가 밟으면 작동해요(화살 벽은 가까이 오면). 연구가 쌓이면 열려요.'].concat(COMBOS.map((c) => '「' + c[0] + '」 ' + c[1] + ' — ' + c[2])), rows: TRAPS.map((T) => ({ icon: T.ic, name: T.n, tag: T.c + '금 · 연구 ' + T.rq, desc: '피해 ' + T.dm + ' · 재작동 ' + T.cd + '초 — ' + T.d })) },
      { h: '간부', p: ['마왕군 간부 4명. 처음 1명과 시작하고, 장이 넘어갈 때 합류해요. 급여 없음, 떠나지 않아요.'], rows: EXEC.map((a) => { const M = MON[a[0]]; return { icon: '👑', name: M.n, tag: M.rl, desc: '체력 ' + M.hp + ' · 공격 ' + M.atk + ' · 방어 ' + M.def + ' · 스킬 ' + M.sk.map((k) => SK[k].n).join(', ') + ' · 각성 「' + SK[M.aw].n + '」 — ' + M.ps }; }) },
      { h: '마물 동료', p: ['30종. 친밀도 25·55·85에서 전용 이야기, 85 + 레벨 5 + 마력 100으로 각성(능력 +35%, 각성 스킬).'], rows: ALLY.map((a) => { const M = MON[a[0]]; return { icon: { f: '🛡', b: '🏹', m: '🔮', s: '✚', w: '⛏' }[M.rk], name: M.n, tag: M.rl + ' · ' + M.cost + '금 · 급여 ' + M.wage, desc: '체력 ' + M.hp + ' · 공격 ' + M.atk + ' · 사거리 ' + M.rng + ' · 좋아하는 방 ' + RM[M.like].n + ' · 스킬 ' + M.sk.map((k) => SK[k].n).join(', ') + ' · 각성 「' + SK[M.aw].n + '」 — ' + M.ps }; }) },
      { h: '용사', p: ['밤마다 파티로 들어와요(목표: 마왕 처치·보물 약탈·포로 구출·정찰). 도망친 용사는 본 함정을 길드에 알려요.'], rows: HCLS.map((k) => { const B = HERO[k]; return { icon: '⚔', name: B.n, tag: HUNLOCK[k] + 1 + '번째 밤부터', desc: '체력 ' + B.hp + ' · 공격 ' + B.atk + ' · 방어 ' + B.def + ' · 사거리 ' + B.rng + ' — ' + B.d }; }) },
      { h: '칭호 용사', p: ['장의 마지막 밤에 찾아와요. 마지막은 「성검의 용사」.'], rows: BOSS_CYCLE.map((k) => { const B = HERO[k]; return { icon: '👑', name: B.n, tag: '전리품 ' + B.loot, desc: '체력 ' + B.hp + ' · 공격 ' + B.atk + ' · 방어 ' + B.def + ' — ' + B.d }; }) },
      { h: '주인 스킬', p: Object.keys(MTYPE).map((k) => MTYPE[k].ic + ' ' + MTYPE[k].n + ' 타입 — ' + MTYPE[k].d), rows: MSK.map((M) => ({ icon: M.ic, name: M.n, tag: (M.ty === 'all' ? '공통' : MTYPE[M.ty].n) + ' · 마력 ' + M.mp + ' · 연구 ' + M.rq, desc: M.d + ' (재사용 ' + M.cd + '초)' })) },
    ];
  }

  /* ================= 조작 ================= */
  const CONTROLS = [
    { id: 'adv', label: '대화 넘기기', keys: ['KeyZ', 'Enter'] }, { id: 'skip', label: '대화 모두 건너뛰기', keys: ['KeyX'] }, { id: 'log', label: '대화 기록', keys: ['KeyL'] }, { id: 'auto', label: '대화 자동 넘김 켬/끔', keys: ['KeyO'] },
    { id: 'ready', label: '밤 맞이하기 · 다음 날 · 시작', keys: ['KeyN'] },
    { id: 'tool_look', label: '선택 도구(도구 끄기)', keys: ['KeyQ'] },
    { id: 'tool_dig', label: '파기 도구', keys: ['Digit1'] }, { id: 'tool_room', label: '방 도구', keys: ['Digit2'] }, { id: 'tool_trap', label: '함정 도구', keys: ['Digit3'] }, { id: 'tool_sell', label: '허물기 도구', keys: ['Digit4'] },
    { id: 'undo', label: '건설 되돌리기', keys: ['KeyU', 'Backspace'] },
    { id: 'tab_build', label: '건설 탭', keys: ['KeyB'] }, { id: 'tab_mon', label: '마물 탭', keys: ['KeyM'] }, { id: 'tab_vis', label: '방문 탭', keys: ['KeyV'] }, { id: 'tab_pr', label: '감옥 탭', keys: ['KeyJ'] }, { id: 'tab_ms', label: '주인 탭', keys: ['KeyK'] },
    { id: 'pause', label: '일시정지(혼자 판)', keys: ['Space'] }, { id: 'speed', label: '배속 1×/2×', keys: ['KeyF'] },
    { id: 'ms1', label: '주인 스킬 1(밤)', keys: ['Digit1'] }, { id: 'ms2', label: '주인 스킬 2(밤)', keys: ['Digit2'] }, { id: 'ms3', label: '주인 스킬 3(밤)', keys: ['Digit3'] },
    { id: 'ms4', label: '주인 스킬 4(밤)', keys: ['Digit4'] }, { id: 'ms5', label: '주인 스킬 5(밤)', keys: ['Digit5'] }, { id: 'ms6', label: '주인 스킬 6(밤)', keys: ['Digit6'] },
    { id: 'pan_u', label: '화면 위로', keys: ['KeyW', 'ArrowUp'] }, { id: 'pan_d', label: '화면 아래로', keys: ['KeyS', 'ArrowDown'] }, { id: 'pan_l', label: '화면 왼쪽', keys: ['KeyA', 'ArrowLeft'] }, { id: 'pan_r', label: '화면 오른쪽', keys: ['KeyD', 'ArrowRight'] },
    { id: 'zoom_in', label: '확대', keys: ['Equal', 'NumpadAdd'] }, { id: 'zoom_out', label: '축소', keys: ['Minus', 'NumpadSubtract'] }, { id: 'cam_fit', label: '화면 맞춤', keys: ['KeyH'] },
  ];
  /*@END*/
  /*@REG*/
  L.register({
    id: 'dkeeper', name: '던전 주인', tag: '던전 경영 · 침입 방어', cat: '전략', pcOnly: true, landscape: true, contextMenu: true,
    mood: 'tension', ambient: 'cave', time: '1–3시간',
    blurb: '마왕이 되어 던전을 파고 방·함정·마물 동료를 갖춰, 밤마다 쳐들어오는 용사들을 막아요. 장마다 칭호 용사, 마지막은 성검의 용사. 2~4명 협동도 돼요.',
    tint: '#4a1420',
    icon: '<path d="M8 50V22l9-9h22l9 9v28z" fill="currentColor" opacity=".3"/><path d="M19 50V32a9 9 0 0 1 18 0v18z" fill="#000" opacity=".45"/><path d="M16 14l4-8 4 6 4-8 4 8 4-6 4 8z" fill="currentColor"/><path d="M28 34l5 6-5 6-5-6z" fill="currentColor"/><path d="M10 50h36" stroke="currentColor" stroke-width="3"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, fixedOrder: true, aiDelay: 900, aiNarration: true,
    save: true, saveLabel: (s) => (s ? (s.mode === 'camp' ? (s.ch + 1) + '장 ' + (s.nd + 1) + '밤' : (s.night + 1) + '번째 밤') + (s.mt ? ' · ' + MTYPE[s.mt].n : '') : ''),
    options: [
      { id: 'mode', label: '모드', tip: '놀이 방식.', choices: [{ v: 'camp', label: '캠페인', tip: '장마다 목표가 있는 이야기 진행.' }, { v: 'endless', label: '끝없는 침입', tip: '점점 강해지는 침입을 얼마나 버티나.' }], def: 'camp' },
      { id: 'len', label: '캠페인 길이', tip: '캠페인 장 수.', choices: [{ v: '5', label: '짧게 5장' }, { v: '6', label: '보통 6장' }, { v: '7', label: '길게 7장' }], def: '6' },
      { id: 'map', label: '지형', choices: [{ v: 'rnd', label: '무작위' }].concat(Object.keys(MAPS).map((k) => ({ v: k, label: MAPS[k] }))), def: 'rnd' },
    ],
    quick: [
      '목표: 마왕(나)의 옥좌를 지키며 밤마다 쳐들어오는 용사 파티를 막아요. 캠페인은 마지막 「성검의 용사」까지.',
      '낮(시간 제한 없음): 바위를 파고, 방·함정을 짓고, 마물을 고용·배치하고, 대화·선물로 친밀도를 쌓아요.',
      '밤(반실시간 1×/2×): 함정과 마물이 싸우고, 나는 주인 스킬을 골라 지도를 눌러 거들어요. 아침엔 수입·급여·식사 정산.',
    ],
    rules: [
      { h: '목표', p: ['캠페인: 장(5~7장)마다 밤 3번, 마지막 밤엔 칭호 용사가 와요. 마지막 장의 「성검의 용사」까지 버티면 승리. 마왕 체력이 0이 되면 패배.', '끝없는 침입: 몇 번째 밤까지 버티나(최고 기록). 5번째 밤마다 칭호 용사.', '협동(2~4명): 던전 하나를 함께 지어요. 지도는 세로로 구역이 나뉘어 각자 자기 구역만 파고 지어요. 금화·마력·마물은 함께 써요.'] },
      { h: '시작', p: ['방장은 마왕의 타입(마술·전투·매혹·기술)을, 모두는 처음 함께할 간부(진홍 용기사·심연의 대마녀·밤의 여공작·짐승 무리의 여왕)를 골라요. 나머지 간부는 장이 넘어갈 때 합류해요.'] },
      { h: '낮 — 경영', p: ['⛏ 파기(1): 파 놓은 곳 옆 바위를 끌어 파요. 작업력은 하루마다 10 + 노동 마물 몫. 금맥은 금화 +50, 마력 결정은 마력 +20.', '🏛 방(2): 15종. 숙소(마물 1명/칸)·식당(3명/칸)·보물고(금고 한도)·마력 샘·연구실·감옥·온천·훈련장·대장간·경비실·주인의 방·서고·정원·제단·연회장. 짝 방과 붙이면 +25%.', '⚙ 함정(3): 20종, 연구(20·45·80·120)로 열려요. 용사가 지나갈 길(점선)에 두세요. 물+전격「감전」, 물+냉기「빙결」, 기름+화염「대폭발」, 묶기+칼날「난도질」 같은 연계가 강해요.', '👹 마물: 방문객을 고용하고(숙소 필요), 📍배치로 밤에 지킬 칸을 정해요. 💬대화(하루 몇 번)·🎁선물로 친밀도를 올리면 전용 이야기(25·55·85)와 각성(85 + 레벨 5 + 마력 100).', '⛓ 감옥: 쓰러진 용사가 감옥 빈 칸만큼 잡혀요. 설득하면 동료, 몸값(금화) 또는 석방(명성).', '준비가 끝나면 「🌙 밤을 맞이하기」(N).'] },
      { h: '밤 — 침입', p: ['용사 파티가 입구에서 들어와 목표(마왕 처치·보물 약탈·포로 구출·정찰)로 가요. 함정을 밟으면 작동하고, 가까운 마물이 맞서 싸워요.', '주인 스킬(밤에 1~6): 고르고 지도를 누르면 써요(마력). 오른쪽 클릭 = 취소. 공통 2개 + 타입별 4개.', '1×/2×(F), 혼자 판은 일시정지(Space). 협동 판은 멈출 수 없어요.', '도둑은 함정을 풀고, 도망친 용사는 본 함정 자리를 길드에 알려요(노란 테두리). 다음 용사는 그 칸을 피해 가려 해요 — 함정을 옮기면 다시 속일 수 있어요.', '150초가 지나면 새벽 — 남은 용사는 물러나요.'] },
      { h: '아침 — 정산', p: ['수입(보물고·정원), 마력(마력 샘), 연구(연구실·서고), 명성(제단·쓰러뜨린 용사). 급여를 못 주면 기분 -25, 못 먹이면 -15. 기분이 15 아래로 떨어진 마물은 떠나요(간부 제외).', '좋아하는 방이 있으면 기분 +4(없으면 -2), 온천은 기분, 훈련장은 경험, 연회장은 친밀도.'] },
      { h: '예시', p: ['통로에 물웅덩이 → 바로 다음 칸에 전격 룬: 젖은 용사에게 2.2배 감전. 그 뒤에 진홍 용기사와 오크를 배치해 막고, 후위 하피가 쏘게 해요. 보물고 옆엔 경비실.'] },
      { h: '조작 · AI', p: ['마우스: 왼쪽 끌기 = 여러 칸 파기·짓기(초록 = 가능, 빨강 = 불가, 합계 비용 표시), Shift+끌기 = 네모로 칠하기, 오른쪽 클릭 = 끌기·도구 취소, 칸에 올리면 설명과 비용. 마물은 지도나 목록에서 끌어다 놓으면 배치가 바뀌어요.', '낮: 1~4 도구 · Q 선택 · U(Backspace) 되돌리기(최대 10번) · B/M/V/J/K 탭 · N 밤 맞이하기. 밤: 1~6 주인 스킬 · F 배속 · Space 멈춤.', '화면: 휠·+/- 확대, WASD·방향키·화면 가장자리·가운데 버튼 끌기로 이동, H 화면 맞춤.', '대화: Z/Enter 넘기기 · X 모두 건너뛰기 · L 기록 · O 자동 넘김. 글자 속도·AI 서술 켬/끔은 주인 탭 「대화 설정」. 단축키는 「⌨ 조작 설정」에서 바꿀 수 있어요.', 'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(협동의 AI 동료).', '저장: 나가기·일시정지 창의 「💾 저장하고 나가기」, 자동 저장도 돼요(혼자·협동 따로).'] },
    ],
    controls: CONTROLS,
    codex: codex(),
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { step, startRaid, aiPlan, castMS, genParty, mainPath, doOp, MON, HERO, SCN, AFF, say, pickLine, pickBanter, LM, cleanAI, badAI, simLine, VOICE, LN, GEN, BANTER, voiceCard, aiPrompt },
  });
})();
