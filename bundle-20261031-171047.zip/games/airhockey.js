/* 에어하키 — realtime 2-player air hockey.
   Local: one person per phone vs AI (friends play via online / LAN rooms, one per phone).
   Online: host-authoritative puck; each device publishes its own mallet, the host applies remote mallets
   (velocity from successive samples) and sends the puck; guests interpolate + predict hits with their own mallet. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- world (units: table width = 100) ---------- */
  const TW = 100, TL = 180, MID = TL / 2, GW = 36, GX0 = (TW - GW) / 2, GX1 = (TW + GW) / 2;
  const RM = 7.4, RP = 4.5;            // mallet / puck radius
  const PMAX = 430, MMAX = 360;        // max puck speed, max mallet speed (units/s)
  const FRIC = 0.12, EW = 0.88, EM = 0.9, WALL_T = 0.985;
  const CD_GOAL = 0.9, CD_NUM = 1.5;   // goal banner, then 3-2-1
  const DIFF = {
    easy: { spd: 0.5, react: 0.24, err: 0.38, miss: 0.22, def: 0.55, ctr: 0.05 },
    normal: { spd: 0.74, react: 0.12, err: 0.17, miss: 0.08, def: 0.78, ctr: 0.25 },
    hard: { spd: 1, react: 0.05, err: 0.06, miss: 0.02, def: 0.9, ctr: 0.45 },
  };
  const DIFF_KO = { easy: '쉬움', normal: '보통', hard: '어려움' };
  /* per-seat AI level (api.players[seat].lv: 1 쉬움 / 2 보통 / 3 어려움) → tier */
  const LVD = { 1: 'easy', 2: 'normal', 3: 'hard' };
  const diffOf = (lv) => LVD[lv] || 'normal';
  /* rink looks (visual only — physics identical so online/AI stay fair) */
  const RINKS = [
    { id: 'neon', nm: '심야 네온', s0: '#0c3446', s1: '#10465c', hole: 'rgba(160,220,240,.13)', edge: 'rgba(140,225,255,.5)', line: 'rgba(227,174,69,.75)', rail: ['#3b2733', '#56384a'] },
    { id: 'ice', nm: '빙판', s0: '#b9d3df', s1: '#e3eef3', hole: 'rgba(40,80,110,.12)', edge: 'rgba(60,120,160,.55)', line: 'rgba(190,50,60,.75)', rail: ['#2c3d4c', '#45607a'] },
    { id: 'felt', nm: '녹색 펠트', s0: '#123d2a', s1: '#1a5238', hole: 'rgba(200,240,210,.1)', edge: 'rgba(227,174,69,.5)', line: 'rgba(242,233,216,.7)', rail: ['#3e2a1a', '#6a4728'] },
    { id: 'ember', nm: '용광로', s0: '#2a0f12', s1: '#45181a', hole: 'rgba(255,170,110,.12)', edge: 'rgba(255,120,60,.55)', line: 'rgba(255,190,90,.8)', rail: ['#241a20', '#3d2c33'] },
  ];
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);

  function malletBounds(seat) {
    return seat === 0 ? { x0: RM, x1: TW - RM, y0: MID + RM * 0.3, y1: TL - RM } : { x0: RM, x1: TW - RM, y0: RM, y1: MID - RM * 0.3 };
  }
  function servePos(seat) { return { x: TW / 2, y: seat === 0 ? TL * 0.7 : TL * 0.3 }; }
  function homePos(seat) { return { x: TW / 2, y: seat === 0 ? TL - 24 : 24 }; }

  function newWorld(sv) {
    const sp = servePos(sv === 1 ? 1 : 0);
    const mk = (s) => { const h = homePos(s); return { x: h.x, y: h.y, vx: 0, vy: 0, tx: h.x, ty: h.y, max: MMAX, col: true }; };
    return { p: { x: sp.x, y: sp.y, vx: 0, vy: 0 }, m: [mk(0), mk(1)], frozen: true, goal: -1, t: 0 };
  }

  /* one physics step (h seconds). Mallets chase (gx, gy) at ≤ max speed.
     hooks: {hit(seat, impulse), wall(speed), post(speed), goal(scorer)} */
  function stepWorld(W, h, hooks) {
    W.pv = { x: W.p.x, y: W.p.y, vx: W.p.vx, vy: W.p.vy }; // puck before this step (result stats: saves)
    for (let s = 0; s < 2; s++) {
      const m = W.m[s], b = malletBounds(s);
      const gx = fin(m.gx) ? m.gx : fin(m.tx) ? m.tx : m.x, gy = fin(m.gy) ? m.gy : fin(m.ty) ? m.ty : m.y;
      let dx = clamp(gx, b.x0, b.x1) - m.x, dy = clamp(gy, b.y0, b.y1) - m.y;
      const d = Math.hypot(dx, dy), mx = (m.max || MMAX) * h;
      if (d > mx) { dx *= mx / d; dy *= mx / d; }
      m.x += dx; m.y += dy; m.vx = dx / h; m.vy = dy / h;
    }
    const p = W.p;
    if (!W.frozen && W.goal < 0) {
      const f = Math.exp(-FRIC * h);
      p.vx *= f; p.vy *= f;
      p.x += p.vx * h; p.y += p.vy * h;
      // side walls
      if (p.x < RP) { p.x = RP; if (p.vx < 0) { if (hooks && hooks.wall) hooks.wall(-p.vx); p.vx = -p.vx * EW; p.vy *= WALL_T; } }
      else if (p.x > TW - RP) { p.x = TW - RP; if (p.vx > 0) { if (hooks && hooks.wall) hooks.wall(p.vx); p.vx = -p.vx * EW; p.vy *= WALL_T; } }
      // end walls with goal mouths. yi = depth into the table from that end, vi = velocity into the table
      for (let e = 0; e < 2 && W.goal < 0; e++) {
        const top = e === 0;
        let yi = top ? p.y : TL - p.y, vi = top ? p.vy : -p.vy, vx = p.vx;
        if (yi >= RP) continue;
        if (p.x > GX0 && p.x < GX1) {
          for (const gx of [GX0, GX1]) { // round posts at the mouth corners
            const ex = p.x - gx, dd = Math.hypot(ex, yi);
            if (dd >= RP || dd < 1e-6) continue;
            const nx = ex / dd, ny = yi / dd, dot = vx * nx + vi * ny;
            p.x = gx + nx * RP; yi = ny * RP;
            if (dot < 0) { vx -= (1 + EW) * dot * nx; vi -= (1 + EW) * dot * ny; if (hooks && hooks.post) hooks.post(-dot); }
          }
          if (yi < 0) p.x = clamp(p.x, GX0 + RP, GX1 - RP); // inside the goal pocket
          if (yi < -RP * 1.2) { W.goal = top ? 0 : 1; } // fully over the line: seat 0 scores at the top
        } else {
          yi = RP;
          if (vi < 0) { if (hooks && hooks.wall) hooks.wall(-vi); vi = -vi * EW; vx *= WALL_T; }
        }
        p.vx = vx; p.y = top ? yi : TL - yi; p.vy = top ? vi : -vi;
        if (W.goal >= 0) { p.vx *= 0.3; p.vy *= 0.3; if (hooks && hooks.goal) hooks.goal(W.goal); }
      }
    }
    // mallet ↔ puck
    for (let s = 0; s < 2; s++) {
      const m = W.m[s];
      if (m.col === false) continue;
      let dx = p.x - m.x, dy = p.y - m.y, d = Math.hypot(dx, dy);
      const R = RM + RP;
      if (d >= R) continue;
      if (d < 1e-6) { dx = 0; dy = s === 0 ? -1 : 1; d = 1; }
      const nx = dx / d, ny = dy / d;
      if (W.frozen || W.goal >= 0) { m.x = p.x - nx * R; m.y = p.y - ny * R; continue; } // the waiting puck can't be pushed
      p.x = m.x + nx * R; p.y = m.y + ny * R;
      const vn = (p.vx - m.vx) * nx + (p.vy - m.vy) * ny;
      if (vn < 0) {
        p.vx -= (1 + EM) * vn * nx; p.vy -= (1 + EM) * vn * ny;
        const sp = Math.hypot(p.vx, p.vy);
        if (sp > PMAX) { p.vx *= PMAX / sp; p.vy *= PMAX / sp; }
        if (hooks && hooks.hit) hooks.hit(s, -vn);
      }
      // squeezed against a wall: the puck stays on the table and the mallet is pushed back instead
      const cx = clamp(p.x, RP, TW - RP);
      const cy = p.x > GX0 && p.x < GX1 ? p.y : clamp(p.y, RP, TL - RP);
      if (cx !== p.x || cy !== p.y) {
        p.x = cx; p.y = cy;
        dx = p.x - m.x; dy = p.y - m.y; d = Math.hypot(dx, dy) || 1;
        if (d < R) { m.x = p.x - dx / d * R; m.y = p.y - dy / d * R; }
        // pinned between mallet and wall: the energy goes into the wall, not back and forth
        p.vx *= 0.25; p.vy *= 0.25; m.vx = 0; m.vy = 0;
      }
    }
    W.t += h;
  }
  /* advance by dt with substeps small enough that nothing tunnels (≤ 1.5 units of travel per substep).
     Each mallet's target is interpolated from last frame's target, so its velocity matches the finger's. */
  function simulate(W, dt, hooks) {
    if (!(dt > 0)) return;
    let mv = Math.hypot(W.p.vx, W.p.vy) * dt;
    for (const m of W.m) {
      if (!fin(m.tx)) { m.tx = m.x; m.ty = m.y; }
      if (!fin(m.ptx)) { m.ptx = m.tx; m.pty = m.ty; }
      mv = Math.max(mv, Math.min((m.max || MMAX) * dt, Math.hypot(m.tx - m.x, m.ty - m.y) + Math.hypot(m.tx - m.ptx, m.ty - m.pty)));
    }
    const n = Math.min(800, Math.max(1, Math.ceil(mv / 1.5)));
    const h = dt / n;
    for (let i = 0; i < n; i++) {
      const k = (i + 1) / n;
      for (const m of W.m) { m.gx = m.ptx + (m.tx - m.ptx) * k; m.gy = m.pty + (m.ty - m.pty) * k; }
      stepWorld(W, h, hooks);
      if (W.goal >= 0) break;
    }
    for (const m of W.m) { m.ptx = m.tx; m.pty = m.ty; }
  }

  /* ---------- AI (works in a frame where its own goal is at the bottom) ---------- */
  /* would a puck at (x,y) moving (vx,vy) slide into the goal on line gy (walls bounce it)? */
  function onTarget(x, y, vx, vy, gy) {
    if (Math.hypot(vx, vy) < 60 || (gy - y) * vy <= 0) return false;
    const gx = reflectX(x + vx * (gy - y) / vy);
    return gx > GX0 + RP * 0.5 && gx < GX1 - RP * 0.5;
  }
  function reflectX(x) {
    const lo = RP, hi = TW - RP, w = hi - lo;
    let u = (x - lo) % (2 * w); if (u < 0) u += 2 * w;
    return lo + (u > w ? 2 * w - u : u);
  }
  function aiThink(W, seat, mem, D, dt) {
    const flip = seat === 1;
    const toL = (x, y) => (flip ? { x: TW - x, y: TL - y } : { x, y });
    mem.rt = (mem.rt || 0) - dt;
    if (mem.rt <= 0 || !mem.pk) { mem.rt = D.react; mem.pk = { x: W.p.x, y: W.p.y, vx: W.p.vx, vy: W.p.vy }; }
    const age = D.react - mem.rt;
    const pk = mem.pk;
    let P = toL(reflectX(pk.x + pk.vx * age), clamp(pk.y + pk.vy * age, 0, TL));
    let vx = flip ? -pk.vx : pk.vx, vy = flip ? -pk.vy : pk.vy;
    const me = W.m[seat], M = toL(me.x, me.y);
    let tx, ty;
    mem.aimT = (mem.aimT || 0) - dt;
    if (W.frozen || W.goal >= 0) {
      // wait near home, drifting a little toward the puck
      tx = TW / 2 + (P.x - TW / 2) * 0.25; ty = TL - 26;
      if (P.y > MID) { tx = P.x; ty = Math.min(TL - RM, P.y + RM + RP + 10); }
      mem.aim = null;
    } else if (P.y < MID - 2) {
      if (vy > 40) {
        const yd = TL - 26, t = (yd - P.y) / vy;
        const px = reflectX(P.x + vx * t);
        tx = TW / 2 + (px - TW / 2) * D.def; ty = yd;
      } else { tx = TW / 2 + (P.x - TW / 2) * 0.4; ty = TL - 30; }
      mem.aim = null; mem.inc = null;
    } else {
      const threat = vy > 150 && P.y < M.y - 4;
      if (threat && !mem.striking) {
        if (!mem.inc) { const tire = 1 + Math.max(0, W.t - 10) / 8; // long rallies: the bot's blocks get sloppier so points end
          mem.inc = { counter: Math.random() < D.ctr, e: (Math.random() - 0.5) * 2 * Math.min(0.6, (1 - D.def) * tire) * GW * 0.9 }; }
        const t = Math.max(0, (M.y - P.y) / vy);
        const ix = reflectX(P.x + vx * t);
        if (mem.inc.counter && P.y > MID + 8 && P.y < M.y - 18) {
          // step into the puck's path and hit it back on the way
          const tt = Math.max(0, (TL - 44 - P.y) / vy);
          tx = reflectX(P.x + vx * tt) + mem.inc.e * 0.3; ty = TL - 44 - 4;
        } else {
          tx = TW / 2 + (ix - TW / 2) * D.def + mem.inc.e; ty = Math.max(M.y, TL - 30);
        }
      } else {
        mem.inc = null;
        if (!mem.aim || mem.aimT <= 0) {
          const r = Math.random();
          let gx = r < 0.55 ? TW / 2 : r < 0.78 ? -TW / 2 : TW * 1.5;
          if (Math.random() < D.miss) gx = TW / 2 + (Math.random() - 0.5) * TW * 2.4;
          mem.aim = { x: gx + (Math.random() - 0.5) * GW * 0.6, y: -RP, e: (Math.random() - 0.5) * 2 * D.err };
          mem.aimT = 0.7;
        }
        const q = { x: P.x + vx * 0.06, y: P.y + vy * 0.06 };
        let dx = mem.aim.x - q.x, dy = mem.aim.y - q.y; const dl = Math.hypot(dx, dy) || 1;
        const ca = Math.cos(mem.aim.e), sa = Math.sin(mem.aim.e);
        let ux = dx / dl, uy = dy / dl;
        [ux, uy] = [ux * ca - uy * sa, ux * sa + uy * ca];
        const R = RM + RP;
        const rx = M.x - q.x, ry = M.y - q.y, along = rx * ux + ry * uy, lat = Math.abs(rx * -uy + ry * ux);
        if (along < -R * 0.45 && lat < RM * 0.95) { tx = q.x + ux * 26; ty = q.y + uy * 26; mem.striking = 0.35; }
        else if (along > -3) { // in front of the puck: go around it
          const side = (rx * -uy + ry * ux) >= 0 ? 1 : -1;
          tx = q.x + -uy * side * (R + 7) - ux * R * 0.6; ty = q.y + ux * side * (R + 7) - uy * R * 0.6;
        } else { tx = q.x - ux * (R + 3); ty = q.y - uy * (R + 3); }
      }
    }
    if (mem.striking) { mem.striking -= dt; if (mem.striking <= 0) mem.striking = 0; }
    const out = flip ? { x: TW - tx, y: TL - ty } : { x: tx, y: ty };
    me.tx = out.x; me.ty = out.y; me.max = MMAX * D.spd;
  }

  /* ---------- pure game interface ---------- */
  function init(players, opts) {
    const o = opts || {};
    return {
      rid: 1 + U.rand(99999), n: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      to: o.to === 11 ? 11 : 7, rk: RINKS.some((r) => r.id === o.rink) ? o.rink : RINKS[U.rand(RINKS.length)].id, sc: [0, 0], seq: 1, sv: U.rand(2), lg: -1, ph: 'play', w: -1,
    };
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !(s.w === 0 || s.w === 1)) return null;
    const nm = (i) => (s.n && s.n[i]) || (i + 1) + '번';
    const sc = Array.isArray(s.sc) ? s.sc : [0, 0];
    const ht = Array.isArray(s.ht) ? s.ht : [0, 0], tv = Array.isArray(s.tv) ? s.tv : [0, 0];
    const stats = [{ label: '득점', values: [sc[0] | 0, sc[1] | 0].map(String) }, { label: '유효 슈팅', values: [ht[0] | 0, ht[1] | 0].map((v) => v + '번') },
      { label: '선방', values: [tv[0] | 0, tv[1] | 0].map((v) => v + '번') }];
    return { winners: [s.w], title: nm(s.w) + ' 승리!', text: nm(0) + ' ' + sc[0] + ' : ' + sc[1] + ' ' + nm(1), stats };
  }
  function scoreGoal(s, scorer) { // pure: next coarse state after a goal
    const n = Object.assign({}, s, { sc: [(s.sc && s.sc[0]) | 0, (s.sc && s.sc[1]) | 0] });
    n.sc[scorer]++;
    n.seq = (s.seq | 0) + 1; n.lg = scorer; n.sv = 1 - scorer;
    if (n.sc[scorer] >= (s.to || 7)) { n.ph = 'done'; n.w = scorer; }
    return n;
  }

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, key = null, W = newWorld(0), phase = 'wait', cd = 0, cdMax = 0;
    const parts = []; let endT = 0, flash = 0;
    const rink = () => RINKS.find((r) => r.id === (st && st.rk)) || RINKS[0];
    let bg = null, lay = null, flip = false, shake = 0, frameNo = 0;
    const trail = [], rings = [], aiMem = [{}, {}];
    const ptr = new Map(); // pointerId -> seat
    let stat = { h: [0, 0], v: [0, 0], lt: [0, 0] }, statRid = null;
    let pendingGoal = -1, lastSfx = 0, rescueT = 0, slowT = 0, hintT = 6, pubT = 0, hsQ = 0;
    const remS = {};    // host: remote mallet samples by seat
    let snap = null, lastHsQ = -1, pred = null, hcount = [0, 0], peerH = [0, 0];
    let claimNow = false, claimN = 0, lastClaim = null, heldGoal = null; const ghost = [0, 0];
    const D = (s) => DIFF[diffOf((api.players[s] || {}).lv)];
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const name = (s) => (st && st.n && st.n[s]) || P(s).name || (s + 1) + '번';
    const local = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const simHere = (s) => { const p = api.players[s]; if (!p) return false; if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const humansHere = () => [0, 1].filter(local).slice(0, 1); // one driver per phone

    function computeFlip() { const hs = humansHere(); return hs.length > 0 && !hs.includes(0); }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h, R = 8;
      const s = Math.min((w - 20) / (TW + 2 * R), (h - 20) / (TL + 2 * R));
      lay = { s, ox: (w - TW * s) / 2, oy: (h - TL * s) / 2, R };
      flip = computeFlip();
      buildBg();
    }
    const toS = (x, y) => { const fx = flip ? TW - x : x, fy = flip ? TL - y : y; return { x: lay.ox + fx * lay.s, y: lay.oy + fy * lay.s }; };
    const toW = (sx, sy) => { let x = (sx - lay.ox) / lay.s, y = (sy - lay.oy) / lay.s; if (flip) { x = TW - x; y = TL - y; } return { x, y }; };

    function buildBg() {
      const c = document.createElement('canvas');
      c.width = Math.round(cv.w * cv.dpr); c.height = Math.round(cv.h * cv.dpr);
      const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const { s, ox, oy, R } = lay, tw = TW * s, tl = TL * s, rr = R * s;
      // floor vignette
      const fg = g.createRadialGradient(cv.w / 2, cv.h / 2, 10, cv.w / 2, cv.h / 2, Math.max(cv.w, cv.h) * 0.7);
      fg.addColorStop(0, '#231b30'); fg.addColorStop(1, '#120e19');
      g.fillStyle = fg; g.fillRect(0, 0, cv.w, cv.h);
      // shadow + rail
      g.save(); g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowBlur = 24; g.shadowOffsetY = 8;
      rrect(g, ox - rr, oy - rr, tw + 2 * rr, tl + 2 * rr, rr * 1.4); g.fillStyle = '#2a1d2c'; g.fill(); g.restore();
      const rg = g.createLinearGradient(ox - rr, 0, ox + tw + rr, 0);
      const RK = rink();
      rg.addColorStop(0, RK.rail[0]); rg.addColorStop(0.5, RK.rail[1]); rg.addColorStop(1, RK.rail[0]);
      rrect(g, ox - rr, oy - rr, tw + 2 * rr, tl + 2 * rr, rr * 1.4); g.fillStyle = rg; g.fill();
      rrect(g, ox - rr * 0.45, oy - rr * 0.45, tw + rr * 0.9, tl + rr * 0.9, rr * 0.8); g.strokeStyle = 'rgba(227,174,69,.55)'; g.lineWidth = 1.5; g.stroke();
      // surface
      const sg = g.createLinearGradient(0, oy, 0, oy + tl);
      sg.addColorStop(0, RK.s0); sg.addColorStop(0.5, RK.s1); sg.addColorStop(1, RK.s0);
      g.fillStyle = sg; g.fillRect(ox, oy, tw, tl);
      // air holes
      g.fillStyle = RK.hole;
      const step = 5 * s;
      for (let y = oy + step / 2; y < oy + tl; y += step) for (let x = ox + step / 2; x < ox + tw; x += step) { g.beginPath(); g.arc(x, y, Math.max(0.6, s * 0.35), 0, 7); g.fill(); }
      // creases in each player's colour (seat at the bottom of the screen is drawn at the bottom)
      for (let seat = 0; seat < 2; seat++) {
        const gy = seat === 0 ? TL : 0, c0 = toS(TW / 2, gy), col = P(seat).color || '#ccc';
        g.save(); g.beginPath(); g.rect(ox, oy, tw, tl); g.clip();
        g.beginPath(); g.arc(c0.x, c0.y, GW * 0.62 * s, 0, Math.PI * 2);
        g.fillStyle = hexA(col, 0.1); g.fill(); g.strokeStyle = hexA(col, 0.65); g.lineWidth = 2; g.stroke();
        g.restore();
      }
      // centre line + circle
      g.save(); g.shadowColor = 'rgba(227,174,69,.7)'; g.shadowBlur = 8;
      g.strokeStyle = RK.line; g.lineWidth = 2.5;
      g.beginPath(); g.moveTo(ox, oy + tl / 2); g.lineTo(ox + tw, oy + tl / 2); g.stroke();
      g.lineWidth = 1.5; g.beginPath(); g.arc(ox + tw / 2, oy + tl / 2, 15 * s, 0, 7); g.stroke();
      g.restore();
      // neon inner edge
      g.save(); g.shadowColor = 'rgba(120,220,255,.6)'; g.shadowBlur = 10; g.strokeStyle = RK.edge; g.lineWidth = 1.5;
      g.strokeRect(ox + 1, oy + 1, tw - 2, tl - 2); g.restore();
      // goal slots
      for (const gy of [0, TL]) {
        const a = toS(GX0, gy), b = toS(GX1, gy), y0 = Math.min(a.y, b.y);
        const up = gy === 0 ? !flip : flip; // slot opens away from the table
        g.fillStyle = '#07040a';
        g.fillRect(Math.min(a.x, b.x), up ? y0 - rr : y0, Math.abs(b.x - a.x), rr);
        g.fillStyle = 'rgba(227,174,69,.9)';
        for (const p of [a, b]) { g.beginPath(); g.arc(p.x, p.y, 2.2, 0, 7); g.fill(); }
      }
      bg = c;
    }

    /* ----- input ----- */
    function onDown(e) {
      if (!lay) return;
      const p = cv.local(e), w = toW(p.x, p.y);
      const hs = humansHere();
      if (!hs.length) return;
      const seat = hs[0];
      ptr.clear(); // newest finger drives the mallet
      ptr.set(e.pointerId, seat);
      W.m[seat].tx = w.x; W.m[seat].ty = w.y - fOff(e);
      hintT = Math.min(hintT, 0.6);
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
    }
    function onMove(e) {
      if (!ptr.has(e.pointerId) || !lay) return;
      const seat = ptr.get(e.pointerId), p = cv.local(e), w = toW(p.x, p.y);
      W.m[seat].tx = w.x; W.m[seat].ty = w.y - fOff(e);
    }
    /* touch: keep the mallet a little above the fingertip (screen-up) so the finger doesn't hide it */
    function fOff(e) { return e.pointerType === 'touch' ? (flip ? -1 : 1) * Math.min(9, 34 / lay.s) : 0; }
    function onUp(e) { ptr.delete(e.pointerId); }
    /* keyboard / gamepad (declared in `controls`, rebindable): moves the mallet's target, screen-relative.
       Keys glide at KEY_V; a stick sets the speed in proportion; holding 「빠르게」 moves at full mallet speed (smash). */
    const KEY_V = 150;
    function padMove(dt) {
      const inp = api.input, s = humansHere()[0];
      if (!inp || s == null || !(dt > 0)) return;
      let ax = inp.axis('left', 'right'), ay = inp.axis('up', 'down');
      if (!ax && !ay) return;
      const n = Math.hypot(ax, ay); if (n > 1) { ax /= n; ay /= n; }
      if (flip) { ax = -ax; ay = -ay; }
      const m = W.m[s], b = malletBounds(s), v = inp.held('fast') ? MMAX : KEY_V;
      const x0 = fin(m.tx) ? m.tx : m.x, y0 = fin(m.ty) ? m.ty : m.y;
      m.tx = clamp(x0 + ax * v * dt, b.x0, b.x1); m.ty = clamp(y0 + ay * v * dt, b.y0, b.y1);
      ptr.clear(); hintT = Math.min(hintT, 0.6);
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);

    /* ----- sound / feedback ----- */
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 45)) return; lastSfx = t; api.sfx(n); }
    const hooks = {
      hit(seat, imp) {
        const m = W.m[seat];
        rings.push({ x: (m.x + W.p.x) / 2, y: (m.y + W.p.y) / 2, t: 0.35, col: P(seat).color, big: imp > 200 });
        if (imp > 25) sfx(imp > 220 ? 'thud' : 'hit');
        if (local(seat)) api.buzz(imp > 220 ? 22 : 12);
        if (api.isHost || !api.online) hcount[seat] = (hcount[seat] + 1) % 1000;
        if (api.online && !api.isHost && local(seat)) { pred = { until: performance.now() + 320, c: peerH[seat] }; claimNow = true; }
        if (imp > 260) shake = Math.min(1, shake + 0.4);
        if ((api.isHost || !api.online) && imp > 25) { // result stats (host only): shots on goal (h) + saves (v)
          if (statRid !== (st && st.rid)) { statRid = st && st.rid; stat = { h: [0, 0], v: [0, 0], lt: [0, 0] }; }
          const tn = performance.now();
          if (tn - (stat.lt[seat] || 0) > 250) { // one touch, counted once
            const own = seat === 0 ? TL : 0, pv = W.pv || W.p;
            if (onTarget(pv.x, pv.y, pv.vx, pv.vy, own)) stat.v[seat]++; // save: it was going into my goal
            if (onTarget(W.p.x, W.p.y, W.p.vx, W.p.vy, TL - own)) stat.h[seat]++; // shot on goal
          }
          stat.lt[seat] = tn;
        }
        burst((m.x + W.p.x) / 2, (m.y + W.p.y) / 2, imp > 220 ? 9 : 4, P(seat).color, imp / 3);
      },
      wall(v) { if (v > 40) sfx('bounce', 70); if (v > 240) burst(W.p.x, W.p.y, 2, '#f2e9d8', v / 5); },
      post(v) { if (v > 30) sfx('chip', 70); },
      goal(scorer) { pendingGoal = scorer; },
    };

    function onGoal(scorer) {
      if (!st || st.ph === 'done' || !host()) return; // guests wait for the host's state
      goalFx(scorer);
      const n = scoreGoal(st, scorer);
      if (statRid === st.rid) { n.ht = stat.h.slice(); n.tv = stat.v.slice(); }
      api.setState(n);
    }
    function burst(x, y, n, col, sp) {
      for (let i = 0; i < n && parts.length < 90; i++) { const a = Math.random() * 6.283, v = (0.3 + Math.random()) * Math.min(120, sp + 20); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0.35 + Math.random() * 0.3, col }); }
    }
    function goalFx(scorer) {
      api.sfx('thud'); shake = 1; flash = 0.5;
      burst(W.p.x, W.p.y < MID ? 3 : TL - 3, 26, P(scorer).color, 140);
      const me = humansHere()[0];
      if (me === 1 - scorer) api.buzz(70);
      else if (me === scorer) { api.buzz(30); setTimeout(() => api.sfx('chip'), 120); }
    }

    /* ----- round control ----- */
    function startPoint(next) {
      const sv = next.sv === 1 ? 1 : 0;
      const keepM = W.m.map((m) => ({ x: m.x, y: m.y, tx: m.tx, ty: m.ty }));
      W = newWorld(sv);
      keepM.forEach((m, i) => { if (fin(m.x)) { W.m[i].x = m.x; W.m[i].y = m.y; W.m[i].tx = m.tx; W.m[i].ty = m.ty; } });
      trail.length = 0; snap = null; pred = null; rescueT = 0; slowT = 0; heldGoal = null;
      if (next.ph === 'done') { phase = 'done'; W.frozen = true; cd = 0; return; }
      phase = 'count'; cdMax = cd = (next.lg >= 0 ? CD_GOAL : 0) + CD_NUM;
      if (next.lg >= 0) { const sc = next.sc || [0, 0]; const gp = Math.max(sc[0], sc[1]) === (next.to || 7) - 1; if (gp && sc[0] !== sc[1]) api.toast('매치 포인트'); }
    }

    /* ----- online ----- */
    function curKey() { return st ? st.rid + '.' + st.seq : null; }
    function pollNet(now) {
      if (!api.online) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (rem && typeof rem === 'object') for (const k in rem) {
          const s = +k, o = rem[k];
          if (!(s === 0 || s === 1) || simHere(s) || !o || !Array.isArray(o.m)) continue;
          const x = +o.m[0], y = +o.m[1];
          if (!fin(x) || !fin(y)) continue;
          const r = remS[s] || (remS[s] = { q: -1 });
          if (o.q === r.q) continue;
          const t = fin(o.t) ? o.t : now;
          if (r.q >= 0 && fin(r.t)) {
            let dt = (t - r.t) / 1000; if (dt < 0) dt += 60;
            if (dt > 0.004 && dt < 0.5) { r.vx = (x - r.x) / dt; r.vy = (y - r.y) / dt; } else { r.vx = 0; r.vy = 0; }
          } else { r.vx = 0; r.vy = 0; }
          Object.assign(r, { q: o.q, x, y, t, at: now });
        }
        // a guest's own hit (it sees its mallet without lag): accept it while the puck is near its half
        if (rem && typeof rem === 'object') for (const k in rem) {
          const s = +k, o = rem[k], c = o && o.c;
          if (!(s === 0 || s === 1) || simHere(s) || !c || o.k !== curKey() || !Array.isArray(c.p) || c.p.length < 4 || !c.p.every(fin)) continue;
          const r = remS[s] || (remS[s] = { q: -1 });
          if (c.n === r.cn) continue;
          r.cn = c.n;
          const mineHalf = s === 0 ? W.p.y > MID - 25 : W.p.y < MID + 25;
          const saves = heldGoal && heldGoal.g === 1 - s;
          if (!(saves || (W.goal < 0 && !W.frozen && mineHalf)) || phase !== 'play') continue;
          heldGoal = null; W.goal = -1; W.frozen = false;
          W.p.x = clamp(c.p[0], RP, TW - RP); W.p.y = clamp(c.p[1], RP, TL - RP); W.p.vx = c.p[2]; W.p.vy = c.p[3];
          ghost[s] = now + 160; // the lagging copy of that mallet must not hit it again
          hcount[s] = (hcount[s] + 1) % 1000;
          const sp = Math.hypot(c.p[2], c.p[3]);
          rings.push({ x: W.p.x, y: W.p.y, t: 0.35, col: P(s).color, big: sp > 200 });
          sfx(sp > 220 ? 'thud' : 'hit');
          simulate(W, 0.05, hooks); // roughly catch up the one-way delay
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== curKey() || hs.q === lastHsQ) return;
        lastHsQ = hs.q;
        if (Array.isArray(hs.p) && hs.p.length >= 4 && hs.p.every(fin)) snap = { x: hs.p[0], y: hs.p[1], vx: hs.p[2], vy: hs.p[3], f: !!hs.f, at: now };
        if (Array.isArray(hs.h)) peerH = [hs.h[0] | 0, hs.h[1] | 0];
        if (hs.m && typeof hs.m === 'object') for (const k in hs.m) {
          const s = +k, a = hs.m[k];
          if ((s === 0 || s === 1) && !simHere(s) && Array.isArray(a) && fin(a[0]) && fin(a[1])) {
            const r = remS[s] || (remS[s] = {});
            if (fin(r.x) && r.at) { const dt = (now - r.at) / 1000; if (dt > 0.01 && dt < 0.5) { r.vx = (a[0] - r.x) / dt; r.vy = (a[1] - r.y) / dt; } }
            r.x = a[0]; r.y = a[1]; r.at = now; if (!fin(r.vx)) { r.vx = 0; r.vy = 0; }
          }
        }
      }
    }
    function applyRemoteMallets(now) {
      for (let s = 0; s < 2; s++) {
        if (simHere(s)) continue;
        const r = remS[s], m = W.m[s];
        m.col = api.isHost && now > ghost[s]; // guests only predict against their own mallet
        if (!r || !fin(r.x)) { const hp = homePos(s); m.tx = hp.x; m.ty = hp.y; m.max = MMAX; continue; }
        const age = Math.min(0.08, (now - r.at) / 1000);
        m.tx = r.x + (r.vx || 0) * age; m.ty = r.y + (r.vy || 0) * age; m.max = MMAX * 1.6;
      }
    }
    function reconcile(rdt, now) {
      if (api.isHost || !api.online || !snap) return;
      if (pred) {
        const mine = humansHere()[0];
        if (mine != null && peerH[mine] !== pred.c) pred = null;     // host registered my hit
        else if (now > pred.until) pred = null;                     // host disagreed → take its puck
        else return;
      }
      if (snap.f) W.frozen = true; else if (phase !== 'count') W.frozen = false;
      const age = Math.min(0.12, (now - snap.at) / 1000 + 0.03) * SPD();
      const tx = clamp(snap.x + snap.vx * age, RP, TW - RP), ty = snap.y + snap.vy * age;
      const d = Math.hypot(tx - W.p.x, ty - W.p.y), k = 1 - Math.exp(-rdt * 14);
      if (d > 30 || snap.f) { W.p.x = tx; W.p.y = ty; }
      else { W.p.x += (tx - W.p.x) * k; W.p.y += (ty - W.p.y) * k; }
      W.p.vx += (snap.vx - W.p.vx) * Math.min(1, k * 2); W.p.vy += (snap.vy - W.p.vy) * Math.min(1, k * 2);
    }
    function publish(rdt) {
      if (!api.online) return;
      pubT -= rdt; if (pubT > 0) return; pubT = 1 / 30;
      const k = curKey();
      try {
        if (api.isHost) {
          const m = {};
          for (let s = 0; s < 2; s++) if (simHere(s)) m[s] = [r1(W.m[s].x), r1(W.m[s].y)];
          hsQ = (hsQ + 1) % 1000;
          api.net.hostSend({ k, q: hsQ, p: [r1(W.p.x), r1(W.p.y), r1(W.p.vx), r1(W.p.vy)], m, h: hcount.slice(), f: W.frozen || W.goal >= 0 ? 1 : 0 });
        } else {
          const s = humansHere()[0];
          if (s == null) return;
          hsQ = (hsQ + 1) % 1000;
          const o = { k, q: hsQ, m: [r1(W.m[s].x), r1(W.m[s].y)], t: Math.round(performance.now()) % 60000 };
          if (lastClaim) o.c = lastClaim;
          api.net.publish(o);
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      frameNo++;
      const dt = rdt * SPD();
      pollNet(now);
      if (phase === 'count') {
        const before = cd; cd -= dt;
        const nb = Math.ceil(before / (CD_NUM / 3)), na = Math.ceil(cd / (CD_NUM / 3));
        if (before <= CD_NUM && na !== nb && na > 0) { api.sfx('tick'); }
        else if (before > CD_NUM && cd <= CD_NUM) api.sfx('tick');
        if (cd <= 0) { phase = 'play'; W.frozen = false; api.sfx('pop'); api.buzz(15); }
      }
      if (hintT > 0) hintT -= rdt;
      for (let s = 0; s < 2; s++) {
        const p = api.players[s];
        if (p && simHere(s) && (p.ai || (L.debug && L.debug.autoplay))) aiThink(W, s, aiMem[s], p.ai ? D(s) : DIFF.normal, dt);
        else if (simHere(s)) { W.m[s].max = MMAX; W.m[s].col = true; }
      }
      padMove(dt);
      applyRemoteMallets(now);
      if (phase === 'done') W.frozen = true;
      const prevF = W.frozen;
      if (!api.isHost && api.online && snap && !pred) W.frozen = snap.f || phase === 'count';
      pendingGoal = -1; claimNow = false;
      if (!heldGoal) simulate(W, Math.min(dt, 0.25), hooks);
      if (claimNow) { claimN = (claimN + 1) % 1000; lastClaim = { n: claimN, p: [r1(W.p.x), r1(W.p.y), r1(W.p.vx), r1(W.p.vy)] }; pubT = 0; }
      if (!api.isHost && api.online) { reconcile(rdt, now); if (W.goal >= 0) { W.goal = -1; W.frozen = true; } }
      else if (pendingGoal >= 0) {
        const g = pendingGoal; pendingGoal = -1;
        if (api.online && !simHere(1 - g)) heldGoal = { g, at: now }; // give the defender's own hit report a moment
        else onGoal(g);
      }
      if (heldGoal && now - heldGoal.at > 300) { const g = heldGoal.g; heldGoal = null; onGoal(g); }
      void prevF;
      // stuck-puck rescue (host/local only)
      if (host() && phase === 'play' && W.goal < 0 && !W.frozen) {
        const sp = Math.hypot(W.p.vx, W.p.vy);
        const corner = (W.p.x < 16 || W.p.x > TW - 16) && (W.p.y < 18 || W.p.y > TL - 18);
        if (sp < 30) { slowT += dt; if (corner) rescueT += dt; } else { slowT = 0; rescueT = 0; }
        if (rescueT > 1.6 || slowT > 5 || (Math.abs(W.p.y - MID) < RP + 1 && slowT > 1.2)) {
          const tx = TW / 2 - W.p.x, ty = (W.p.y > MID ? TL * 0.62 : TL * 0.38) - W.p.y, d = Math.hypot(tx, ty) || 1;
          W.p.vx = tx / d * 90; W.p.vy = ty / d * 90 + (Math.abs(W.p.y - MID) < RP + 1 ? (Math.random() < 0.5 ? 60 : -60) : 0);
          rescueT = 0; slowT = 0; api.sfx('whoosh');
        }
      }
      // trail
      if (!W.frozen) { trail.push({ x: W.p.x, y: W.p.y }); if (trail.length > 10) trail.shift(); } else trail.length = 0;
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t -= rdt; if (rings[i].t <= 0) rings.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 4); flash = Math.max(0, flash - rdt);
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vx *= 0.92; q.vy *= 0.92; if (q.t <= 0) parts.splice(i, 1); }
      if (phase === 'done') endT += rdt;
      publish(rdt);
    }

    /* ----- drawing ----- */
    function draw() {
      if (!lay) return;
      cv.clear();
      const fxk = L.fx ? L.fx() : 1, sx = shake > 0 ? (Math.random() - 0.5) * shake * 4 * fxk : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake * 4 * fxk : 0;
      ctx.save(); ctx.translate(sx, sy);
      ctx.drawImage(bg, 0, 0, cv.w, cv.h);
      const s = lay.s;
      // scores printed on the table, left of centre
      if (st) {
        const sc = st.sc || [0, 0];
        for (let seat = 0; seat < 2; seat++) {
          const c = toS(TW * 0.14, seat === 0 ? MID + 14 : MID - 14);
          ctx.save(); ctx.translate(c.x, c.y);
          ctx.font = '700 ' + Math.round(s * 13) + 'px "IBM Plex Mono", ui-monospace, monospace';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillStyle = hexA(P(seat).color, 0.55); ctx.fillText(String(sc[seat] | 0), 0, 0);
          ctx.restore();
          // name + target near the goal
          // inside the crease, a little in from the goal end (same distance at the top and the bottom)
          const nc = toS(TW / 2, seat === 0 ? TL - 7.5 : 7.5);
          ctx.save(); ctx.translate(nc.x, nc.y);
          ctx.font = '600 ' + Math.max(10, Math.round(s * 3.6)) + 'px "IBM Plex Sans KR", system-ui, sans-serif';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillStyle = hexA(P(seat).color, 0.8);
          const tag = P(seat).ai ? ' · ' + DIFF_KO[diffOf(P(seat).lv)] : '';
          ctx.fillText(name(seat) + tag, 0, 0);
          ctx.restore();
        }
        // first-to label on the right
        const tc = toS(TW * 0.86, MID);
        ctx.font = '600 ' + Math.max(10, Math.round(s * 3.3)) + 'px "IBM Plex Sans KR", system-ui, sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = 'rgba(227,174,69,.7)';
        ctx.fillText((st.to || 7) + '점 선승', tc.x, tc.y - s * 4.5);
      }
      // rings
      for (const r of rings) {
        const c = toS(r.x, r.y), k = 1 - r.t / 0.35;
        ctx.beginPath(); ctx.arc(c.x, c.y, (RP + k * (r.big ? 14 : 8)) * s, 0, 7);
        ctx.strokeStyle = hexA(r.col || '#fff', 0.6 * (1 - k)); ctx.lineWidth = 2; ctx.stroke();
      }
      for (const q of parts) { const c = toS(q.x, q.y); ctx.globalAlpha = Math.min(1, q.t * 2.5); ctx.fillStyle = q.col || '#fff'; ctx.fillRect(c.x - s * 0.7, c.y - s * 0.7, s * 1.4, s * 1.4); }
      ctx.globalAlpha = 1;
      // puck trail + puck
      for (let i = 0; i < trail.length; i++) {
        const t = trail[i], c = toS(t.x, t.y), a = (i + 1) / trail.length;
        ctx.beginPath(); ctx.arc(c.x, c.y, RP * s * (0.5 + 0.5 * a), 0, 7); ctx.fillStyle = 'rgba(255,214,120,' + (0.12 * a) + ')'; ctx.fill();
      }
      const pc = toS(W.p.x, W.p.y);
      if (W.goal < 0 || true) {
        ctx.save();
        ctx.shadowColor = 'rgba(0,0,0,.5)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2;
        ctx.beginPath(); ctx.arc(pc.x, pc.y, RP * s, 0, 7); ctx.fillStyle = '#1a1420'; ctx.fill();
        ctx.restore();
        ctx.save(); ctx.shadowColor = 'rgba(255,200,90,.85)'; ctx.shadowBlur = 12;
        ctx.beginPath(); ctx.arc(pc.x, pc.y, RP * s * 0.78, 0, 7);
        const pg = ctx.createRadialGradient(pc.x - RP * s * 0.3, pc.y - RP * s * 0.3, 1, pc.x, pc.y, RP * s);
        pg.addColorStop(0, '#fff3cf'); pg.addColorStop(1, '#e3ae45'); ctx.fillStyle = pg; ctx.fill(); ctx.restore();
        ctx.beginPath(); ctx.arc(pc.x, pc.y, RP * s * 0.35, 0, 7); ctx.strokeStyle = 'rgba(90,60,20,.5)'; ctx.lineWidth = 1; ctx.stroke();
      }
      // mallets
      for (let seat = 0; seat < 2; seat++) {
        const m = W.m[seat], c = toS(m.x, m.y), col = P(seat).color || '#ccc', R = RM * s;
        ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.55)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 4;
        ctx.beginPath(); ctx.arc(c.x, c.y, R, 0, 7); ctx.fillStyle = shade(col, -0.35); ctx.fill(); ctx.restore();
        const g = ctx.createRadialGradient(c.x - R * 0.35, c.y - R * 0.4, 1, c.x, c.y, R);
        g.addColorStop(0, shade(col, 0.35)); g.addColorStop(0.7, col); g.addColorStop(1, shade(col, -0.25));
        ctx.beginPath(); ctx.arc(c.x, c.y, R * 0.92, 0, 7); ctx.fillStyle = g; ctx.fill();
        ctx.beginPath(); ctx.arc(c.x, c.y, R * 0.62, 0, 7); ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1.5; ctx.stroke();
        const g2 = ctx.createRadialGradient(c.x - R * 0.15, c.y - R * 0.2, 1, c.x, c.y, R * 0.42);
        g2.addColorStop(0, shade(col, 0.5)); g2.addColorStop(1, shade(col, -0.1));
        ctx.beginPath(); ctx.arc(c.x, c.y, R * 0.4, 0, 7); ctx.fillStyle = g2; ctx.fill();
        if (local(seat) && [...ptr.values()].includes(seat)) { ctx.beginPath(); ctx.arc(c.x, c.y, R + 4, 0, 7); ctx.strokeStyle = hexA('#f2e9d8', 0.35); ctx.lineWidth = 2; ctx.stroke(); }
      }
      ctx.restore();
      // overlay texts
      const cx = lay.ox + TW * s / 2, cy = lay.oy + TL * s / 2;
      if (phase === 'count' && st) {
        let txt, sub = null, col = '#f2e9d8';
        if (cd > CD_NUM && st.lg >= 0) { txt = '골!'; sub = name(st.lg) + ' 득점'; col = P(st.lg).color; }
        else txt = String(Math.max(1, Math.ceil(cd / (CD_NUM / 3))));
        const k = txt === '골!' ? 1 : 1 + ((cd / (CD_NUM / 3)) % 1) * 0.25;
        {
          ctx.save(); ctx.translate(cx, cy);
          ctx.scale(k, k);
          ctx.font = Math.round(s * 16) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(10,8,16,.75)'; ctx.strokeText(txt, 0, 0);
          ctx.fillStyle = col; ctx.fillText(txt, 0, 0);
          if (sub) { ctx.font = '600 ' + Math.max(12, Math.round(s * 4.5)) + 'px "IBM Plex Sans KR", sans-serif'; ctx.lineWidth = 4; ctx.strokeText(sub, 0, s * 12); ctx.fillStyle = '#f2e9d8'; ctx.fillText(sub, 0, s * 12); }
          ctx.restore();
        }
      }
      if (flash > 0 && st && st.lg >= 0) { ctx.fillStyle = hexA(P(st.lg).color, flash * 0.35 * (L.fx ? L.fx() : 1)); ctx.fillRect(lay.ox, lay.oy, TW * s, TL * s); }
      // end banner (before the core's result overlay)
      if (phase === 'done' && st && (st.w === 0 || st.w === 1)) {
        const a = Math.min(1, endT * 3);
        ctx.save(); ctx.globalAlpha = a; ctx.fillStyle = 'rgba(12,9,18,.72)'; ctx.fillRect(lay.ox, cy - s * 14, TW * s, s * 28);
        ctx.font = Math.round(s * 11) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = P(st.w).color; ctx.fillText(name(st.w) + ' 승리', cx, cy - s * 3);
        const sc = st.sc || [0, 0];
        ctx.font = '700 ' + Math.max(12, Math.round(s * 5)) + 'px "IBM Plex Mono", ui-monospace, monospace'; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(sc[0] + ' : ' + sc[1], cx, cy + s * 8); ctx.restore();
      }
      // hint for the person on this phone (their half is always at the bottom)
      if (hintT > 0 && phase !== 'done' && humansHere().length) {
        ctx.font = '600 13px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        {
          ctx.save(); ctx.translate(cx, lay.oy + TL * s * 0.78); // between the serve spot and my mallet (doesn't cover it)
          ctx.globalAlpha = Math.min(1, hintT);
          const t = '내 쪽 절반에서 말렛을 끌어 퍽을 쳐요';
          const w = ctx.measureText(t).width + 24;
          rrect(ctx, -w / 2, -15, w, 30, 15); ctx.fillStyle = 'rgba(23,19,31,.78)'; ctx.fill();
          ctx.fillStyle = '#f2e9d8'; ctx.fillText(t, 0, 1);
          ctx.restore();
        }
      }
    }

    const stopLoop = U.loop((rdt, now) => {
      // fast-forward (Lounge.debug.speed) in ≤ 1/30 s game-time slices so AI and physics stay fine-grained
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); } catch (e) { console.error(e); }
      try { draw(); } catch (e) { console.error(e); }
    });
    cv.onresize = layout;
    layout();

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (computeFlip() !== flip) layout();
        const k = curKey();
        if (k !== key) {
          key = k;
          if (prev && next.lg >= 0 && prev.seq !== next.seq && !host()) goalFx(next.lg); // the host played it already
          startPoint(next);
        }
        if (next.ph === 'done') { phase = 'done'; W.frozen = true; }
        buildBg();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        cv.destroy();
      },
      _dbg: () => ({ W, phase, cd, flip, lay, toS, toW, st, ptr, snap, pred }),
    };
  }

  /* ---------- small drawing helpers ---------- */
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'airhockey', name: '에어하키', tag: '실시간 대결', cat: '아케이드',
    blurb: '말렛을 끌어 퍽을 상대 골에 넣어요. 7점(또는 11점) 먼저! 혼자면 AI와, 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#16485a',
    icon: '<rect x="12" y="6" width="32" height="44" rx="5" fill="none" stroke="currentColor" stroke-width="3"/><path d="M12 28h32" stroke="currentColor" stroke-width="2" opacity=".6"/><path d="M22 6h12M22 50h12" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="28" cy="40" r="6" fill="currentColor"/><circle cx="28" cy="40" r="2.5" fill="#16485a"/><circle cx="33" cy="22" r="3.5" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 2, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'to', label: '목표 점수', choices: [{ v: 7, label: '7점' }, { v: 11, label: '11점' }], def: 7 },
      { id: 'rink', label: '테이블', tip: '테이블 모양·색만 달라요(규칙은 같아요).', choices: [{ v: 'rnd', label: '무작위' }].concat(RINKS.map((r) => ({ v: r.id, label: r.nm }))), def: 'rnd' },
    ],
    controls: [
      { id: 'up', label: '위', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'fast', label: '빠르게 (강슛)', keys: ['Space', 'ShiftLeft'], pad: ['a', 'rb'] },
    ],
    quick: [
      '말렛(동그란 손잡이)으로 퍽을 쳐서 위쪽 상대 골에 넣으면 1점이에요.',
      '손가락을 대고 끌면 말렛이 따라와요. 빠르게 밀어칠수록 강슛!',
      '7점(또는 11점)을 먼저 따면 이겨요.',
    ],
    rules: [
      { h: '목표', p: [
        '에어하키 한 판이에요. 내 말렛과 골은 항상 화면 아래쪽, 상대는 위쪽이에요.',
        '퍽(납작한 원반)을 쳐서 상대 골(테이블 위쪽 끝의 홈)에 넣으면 1점.',
        '정한 점수(7점, 또는 11점)를 먼저 따면 바로 이겨요. 2점 차는 필요 없어요.',
      ] },
      { h: '조작 (터치)', p: [
        '화면에 손가락을 대면 말렛이 그 자리로 달려가고, 끌면 계속 따라와요. 말렛을 정확히 누르지 않아도 돼요.',
        '터치할 때 말렛은 손가락보다 살짝 위에 떠서 따라와요(손가락에 가려지지 않게).',
        '말렛은 내 쪽 절반(아래)에서만 움직여요. 손가락이 가운데 선을 넘어가도 말렛은 선 앞에서 멈춰요.',
        '말렛을 움직이는 속도가 퍽에 그대로 실려요. 빠르게 밀어치면 강슛, 가만히 대고 있으면 막기.',
        '말렛은 최고 속도가 있어서 너무 빨리 휘두르면 살짝 늦게 따라와요.',
        'PC: 마우스로 누른 채 끌어도 되고, 방향키·WASD·왼스틱으로 움직여도 돼요. 스페이스·Shift·Ⓐ·RB를 누르고 있으면 최고 속도(강슛). 키는 「⌨ 조작 설정」에서 바꿔요.',
      ] },
      { h: '진행 · 특수 규칙', p: [
        '첫 퍽은 무작위로 한쪽 진영에 놓여요. 그다음부터는 골을 먹은 쪽 진영에 퍽이 놓여요.',
        '3·2·1 카운트다운이 끝나면 시작해요. 카운트다운 동안 퍽은 움직이지 않아요.',
        '퍽은 벽에 튕길 때마다 조금씩 느려져요.',
        '테이블 모양(네온·빙판·펠트·용광로)은 보기만 다르고 물리는 같아요. 기본은 무작위.',
        '퍽이 구석에 끼거나 오래 멈춰 있으면 가운데 쪽으로 살짝 밀어 줘요.',
      ] },
      { h: '팁', p: [
        '평소에는 말렛을 내 골 앞에 두고 지키다가, 퍽이 내 쪽으로 느리게 오면 앞으로 나가 쳐요.',
        '벽에 한 번 튕겨 비스듬히 들어가는 슛은 막기 어려워요.',
        '퍽 바로 뒤에서 상대 골 쪽으로 쭉 밀어 주면 가장 세게 나가요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 상대는 AI예요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로 해요.',
        '온라인·LAN: 각자 폰에서 자기 말렛이 항상 아래쪽에 보여요. 퍽은 호스트 폰이 계산해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(반응 속도, 말렛 속도, 슛 정확도가 달라요).',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { newWorld, stepWorld, simulate, aiThink, scoreGoal, malletBounds, servePos, DIFF, TW, TL, MID, RM, RP, PMAX, MMAX, GX0, GX1 },
  });
})();
