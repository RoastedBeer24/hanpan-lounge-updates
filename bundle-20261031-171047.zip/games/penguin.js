/* 펭귄 얼음 깨기 — hex ice field over dark water. Two ways to play (option 「방식」):
   · 실시간 (realtime, default, one person per phone, up to 8): penguins slide around freely; the ice under a penguin cracks
     stage by stage and breaks into water. 「배치기」 belly-bumps rivals into the water. After a while a heavy polar bear (two
     on large maps) climbs on, chases, winds up and swipes (dodgeable). Every map has its own gimmicks (drifting floes,
     currents, seals, snowstorms, chain cracks, rolling icebergs, geysers, fishing holes with power fish, wind gusts,
     thin-ice zones, glare ice, rock ice). Late in the round the ice starts melting from the edges.
     The core sees a turn-based def: in realtime mode actor() is null, the view simulates the world on the host/local device
     and syncs it with api.net (hostSend / publish), and api.setState carries the falls and the end.
   · 차례대로 (turn-based, pass-and-play OK, up to 4): walk up to 2 tiles (optional), then strike one adjacent ice tile
     (멀쩡 → 금 → 구멍). Pieces cut off from the main field drift away with whoever stands on them. When the game drags on,
     a polar bear climbs onto the ice and attacks the nearest penguin after every move.
   Map size (소형/중형/대형, 자동 = by player count) scales every map on one shared 15×21 hex grid.
   Last penguin standing wins. */
(function () {
  const L = window.Lounge, U = L.util;
  const W = 15, H = 21, N = W * H, SQ3 = Math.sqrt(3);
  const STEPS = 2, ANGRY = 4; // turn mode: penguin walk range; rounds on the ice before the bear gets angry (2 steps per move)
  const Q = new Int16Array(N), R = new Int16Array(N), NB = new Int16Array(N * 6);
  const AX = [[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]];
  for (let i = 0; i < N; i++) { const c = i % W, r = (i / W) | 0; Q[i] = c - ((r - (r & 1)) >> 1); R[i] = r; }
  function idxQR(q, r) { if (r < 0 || r >= H) return -1; const c = q + ((r - (r & 1)) >> 1); return c < 0 || c >= W ? -1 : r * W + c; }
  for (let i = 0; i < N; i++) for (let d = 0; d < 6; d++) NB[i * 6 + d] = idxQR(Q[i] + AX[d][0], R[i] + AX[d][1]);
  function hd(a, b) { const dq = Q[a] - Q[b], dr = R[a] - R[b]; return (Math.abs(dq) + Math.abs(dr) + Math.abs(dq + dr)) / 2; }
  function dirOf(a, b) { for (let d = 0; d < 6; d++) if (NB[a * 6 + d] === b) return d; return -1; }
  // world coordinates (hex radius = 1): tile centres and point → tile
  const XW = new Float64Array(N), YW = new Float64Array(N);
  for (let i = 0; i < N; i++) { XW[i] = SQ3 * ((i % W) + 0.5 * (((i / W) | 0) & 1)); YW[i] = 1.5 * ((i / W) | 0); }
  function tileAt(x, y) {
    const qf = (SQ3 / 3) * x - y / 3, rf = (2 / 3) * y, sf = -qf - rf;
    let q = Math.round(qf), r = Math.round(rf); const s = Math.round(sf);
    const dq = Math.abs(q - qf), dr = Math.abs(r - rf), ds = Math.abs(s - sf);
    if (dq > dr && dq > ds) q = -r - s; else if (dr > ds) r = -q - s;
    return idxQR(q, r);
  }

  /* ---------- map sizes: every map is a shape in normalised coords (u, v ∈ −1…1) scaled to the size ---------- */
  const X0 = SQ3 * (W - 0.5) / 2, Y0 = 1.5 * (H - 1) / 2;
  const SIZES = [
    { k: 0, id: 's', name: '소형', rx: 7.7, ry: 9.4 },
    { k: 1, id: 'm', name: '중형', rx: 9.3, ry: 11.6 },
    { k: 2, id: 'l', name: '대형', rx: 12.2, ry: 14.8 },
  ];
  function sizeFor(opt, n, rt) {
    let k = opt === 's' ? 0 : opt === 'm' ? 1 : opt === 'l' ? 2 : n <= 3 ? 0 : n <= 6 ? 1 : 2;
    if (!rt && k > 1 && n <= 4) k = 1; // 팀전 5~8명이면 대형도 써요 // 차례대로는 중형까지 (대형은 너무 길어져요)
    return k;
  }
  const SE = (u, v, p) => Math.pow(Math.abs(u), p) + Math.pow(Math.abs(v), p); // superellipse "radius"
  const bl = (u, v, cu, cv, r) => (u - cu) * (u - cu) + (v - cv) * (v - cv) <= r * r;
  const nearPt = (i, z, u, v, r) => Math.hypot(XW[i] - X0 - u * z.rx, YW[i] - Y0 - v * z.ry) <= r;
  function segW(i, z, u0, v0, u1, v1) { // world distance from tile i to a segment given in normalised coords
    const ax = X0 + u0 * z.rx, ay = Y0 + v0 * z.ry, dx = (u1 - u0) * z.rx, dy = (v1 - v0) * z.ry;
    const f = Math.max(0, Math.min(1, ((XW[i] - ax) * dx + (YW[i] - ay) * dy) / (dx * dx + dy * dy)));
    return Math.hypot(XW[i] - ax - dx * f, YW[i] - ay - dy * f);
  }
  const HOLEPTS = [[0, 0], [-0.45, -0.42], [0.45, -0.42], [-0.45, 0.42], [0.45, 0.42], [0, -0.75], [0, 0.75], [-0.8, 0], [0.8, 0]];
  const CORN = [[-0.6, -0.62], [0.6, -0.62], [-0.6, 0.62], [0.6, 0.62]];
  /* f(u, v, i, z) → 0 water · 1 ice · 2 thin ice (살얼음) · 3 rock ice (바위) · 4 fishing hole (water)
     gm = realtime gimmicks of the map (the turn mode only uses the shape, holes and thin ice) */
  const LAYS = [
    { id: 'round', name: '둥근 섬', gm: ['seal', 'fish'], f: (u, v) => (SE(u, v, 3) <= 1 ? 1 : 0) },
    { id: 'holes', name: '구멍 빙판', gm: ['fish', 'chain'], f: (u, v, i, z) => (SE(u, v, 3) > 1 ? 0 : HOLEPTS.some((p) => nearPt(i, z, p[0], p[1], 0.9)) ? 4 : 1) },
    { id: 'ring', name: '고리 섬', gm: ['lakef', 'wind'], f: (u, v) => (SE(u, v, 3) <= 1 && u * u + v * v >= 0.15 ? 1 : 0) },
    { id: 'twin', name: '쌍둥이 섬', gm: ['gey', 'chain'], f: (u, v, i, z) => (bl(u, v, 0, -0.53, 0.55) || bl(u, v, 0, 0.53, 0.55) || (Math.abs(XW[i] - X0) <= 1.0 + 0.45 * z.k && Math.abs(v) <= 0.2) ? 1 : 0) },
    { id: 'thin', name: '살얼음', gm: ['thin', 'seal'], f: (u, v, i) => (SE(u, v, 3) > 1 ? 0 : ((Q[i] * 2 + R[i] * 3) % 4 + 4) % 4 === 0 ? 2 : 1) },
    { id: 'cross', name: '십자 빙판', gm: ['wind', 'berg'], f: (u, v) => ((Math.abs(u) <= 0.42 || Math.abs(v) <= 0.36) && SE(u, v, 3) <= 1.1 ? 1 : 0) },
    { id: 'moon', name: '초승달', gm: ['floe', 'seal'], f: (u, v) => (SE(u, v, 3) <= 1.05 && (u - 0.75) * (u - 0.75) + v * v * 0.8 >= 0.3 ? 1 : 0) },
    { id: 'hour', name: '모래시계', gm: ['berg', 'glare'], f: (u, v) => (Math.abs(v) <= 1.02 && Math.abs(u) <= 0.26 + 0.85 * Math.abs(v) ? 1 : 0) },
    { id: 'stones', name: '징검다리 섬', gm: ['chain', 'floe'], f: (u, v, i, z) => (bl(u, v, 0, 0, 0.34) || CORN.some((c) => bl(u, v, c[0], c[1], 0.42) || segW(i, z, 0, 0, c[0], c[1]) <= 0.9 + 0.3 * z.k) ? 1 : 0) },
    { id: 'long', name: '기다란 빙하', gm: ['berg', 'wind'], f: (u, v) => (Math.abs(u) <= 0.72 && Math.abs(v) <= 1.02 && Math.abs(u) + Math.abs(v) * 0.5 <= 1.12 ? 1 : 0) },
    { id: 'gen', name: '매번 새 빙판', gen: true },
    { id: 'star', name: '별 빙판', gm: ['glare', 'gey'], f: (u, v) => { const r = Math.hypot(u, v), a = Math.atan2(v, u) + Math.PI / 2; return r <= 0.5 + 0.52 * Math.pow(Math.abs(Math.cos(2.5 * a)), 2.2) ? 1 : 0; } },
    { id: 'strait', name: '얼음 해협', gm: ['cur', 'wind'], f: (u, v, i, z) => (SE(u, v, 2.6) > 1 ? 0 : Math.abs(YW[i] - Y0) > 0.5 || Math.abs(Math.abs(XW[i] - X0) - 0.5 * z.rx) <= 1.0 ? 1 : 0) },
    { id: 'archi', name: '군도', gm: ['floe', 'seal'], f: (u, v, i, z) => {
      if (bl(u, v, 0, 0, 0.4)) return 1;
      for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3 + Math.PI / 6, cu = Math.cos(a) * 0.68, cv = Math.sin(a) * 0.72; if (bl(u, v, cu, cv, 0.26) || segW(i, z, 0, 0, cu, cv) <= 0.9 + 0.2 * z.k) return 1; }
      return 0;
    } },
    { id: 'spiral', name: '소용돌이', gm: ['glare', 'storm'], f: (u, v) => {
      if (SE(u, v, 2.4) > 1) return 0;
      const r = Math.hypot(u, v); if (r < 0.24) return 1;
      const ph = (((Math.atan2(v, u) + r * 7) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
      return Math.abs(ph - Math.PI) < 0.42 ? 0 : 1;
    } },
    { id: 'lake', name: '큰 호수', gm: ['fish', 'lakef'], f: (u, v) => (SE(u, v, 2) <= 1 && !bl(u, v, 0.08, -0.05, 0.5) ? 1 : 0) },
    { id: 'zigzag', name: '번개 빙하', gm: ['chain', 'storm'], f: (u, v) => {
      if (Math.abs(v) > 1.0) return 0;
      const tri = Math.abs((((v * 2 + 0.5) % 2) + 2) % 2 - 1) * 2 - 1;
      return Math.abs(u - tri * 0.42) <= 0.42 ? 1 : 0;
    } },
    { id: 'diamond', name: '마름모 빙판', gm: ['rock', 'gey'], f: (u, v) => (Math.abs(u) + Math.abs(v) <= 1.05 ? 1 : 0) },
    { id: 'flower', name: '꽃잎 섬', gm: ['fish', 'storm'], f: (u, v) => {
      if (bl(u, v, 0, 0, 0.4)) return 1;
      for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; if (bl(u, v, Math.cos(a) * 0.58, Math.sin(a) * 0.58, 0.34)) return 1; }
      return 0;
    } },
    { id: 'fort', name: '바위 요새', gm: ['rock', 'berg'], f: (u, v) => {
      const r = SE(u, v, 5); if (r > 1) return 0;
      return r > 0.2 && r < 0.36 && Math.abs(u) > 0.14 && Math.abs(v) > 0.14 ? 3 : 1;
    } },
    { id: 'tri', name: '세모 섬', gm: ['thin', 'wind'], f: (u, v) => (v <= 0.88 && v >= -1.02 && Math.abs(u) <= (v + 1.02) * 0.5 ? 1 : 0) },
  ];
  /* gimmick names (realtime) */
  const GMN = { floe: '떠다니는 유빙', lakef: '호수 유빙', cur: '해류 유빙', seal: '물개', storm: '눈보라', chain: '연쇄 균열',
    berg: '굴러오는 빙산', gey: '간헐천', fish: '낚시 구멍·힘 물고기', wind: '돌풍', thin: '살얼음 구역', glare: '미끄럼 빙판', rock: '바위 얼음', bears: '북극곰 두 마리', orca: '범고래',
    thick: '두꺼운 얼음', snow: '눈 덮인 얼음' };
  /* ice types mixed into the map (option 「얼음 종류」): c 금 간 얼음 · k 두꺼운 얼음 · s 미끄러운 얼음 · n 눈 덮인 얼음 */
  const ICE_TYPES = [
    { ch: 'c', name: '금 간 얼음', rt: '처음부터 금이 2단계 가 있어 금방 깨져요.', t: '한 번만 치면 구멍. 그 위에 멈추면 내려앉기 시작해서(빨간 점선), 다음 내 차례가 끝날 때도 그대로 서 있으면 깨져요.' },
    { ch: 'k', name: '두꺼운 얼음', rt: '금이 절반 속도로 가요. 오래 버티기 좋아요.', t: '세 번 쳐야 구멍이 나요(멀쩡 → 흠집 → 금 → 구멍).' },
    { ch: 's', name: '미끄러운 얼음', rt: '잘 안 멈추고 쭉 미끄러져요(미끄럼 빙판과 같아요).', t: '밟으면 걷던 방향으로 미끄러운 칸이 끝날 때까지 쭉 미끄러져요(걸음 수는 그대로). 물가나 펭귄 앞에서는 멈춰요.' },
    { ch: 'n', name: '눈 덮인 얼음', rt: '눈에 발이 빠져서 느리게 걷고 배치기도 약해져요. 대신 금방 멈춰요.', t: '들어서면 그 차례의 걷기가 끝나요.' },
  ];
  const MIXAMT = { few: 0.08, mid: 0.14, many: 0.22 };
  function mixPlan(opt) {
    if (opt === 'none') return null;
    const fixed = !!MIXAMT[opt], amt = MIXAMT[fixed ? opt : rndOf(['few', 'mid', 'many'])];
    const pool = ICE_TYPES.map((t) => t.ch);
    for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
    return { amt, types: pool.slice(0, fixed ? 4 : 2 + Math.floor(Math.random() * 3)) };
  }
  /* blobs of ice types over free ice tiles (never on or right next to a start tile) */
  function mixTiles(ice, st, plan, taken) {
    const ty = new Array(N).fill('.');
    if (!plan) return ty;
    const free = (i) => ice[i] && !taken(i) && !st.some((p) => hd(p, i) <= 1);
    const list = []; for (let i = 0; i < N; i++) if (free(i)) list.push(i);
    const target = Math.round(list.length * plan.amt);
    let cnt = 0, guard = 0;
    while (cnt < target && guard++ < 200 && list.length) {
      const c = list[Math.floor(Math.random() * list.length)]; if (ty[c] !== '.') continue;
      const ch = plan.types[Math.floor(Math.random() * plan.types.length)], rad = 0.9 + Math.random() * 0.8;
      for (const t of list) if (ty[t] === '.' && Math.hypot(XW[t] - XW[c], YW[t] - YW[c]) <= rad) { ty[t] = ch; cnt++; }
    }
    return ty;
  }
  const GEN_GM = ['seal', 'storm', 'chain', 'berg', 'gey', 'fish', 'wind', 'thin', 'glare', 'rock', 'floe'];
  function comps(ice) {
    const comp = new Int16Array(N).fill(-1), sizes = [], stack = [];
    for (let i = 0; i < N; i++) {
      if (!ice[i] || comp[i] >= 0) continue;
      const k = sizes.length; let cnt = 0; comp[i] = k; stack.push(i);
      while (stack.length) {
        const c = stack.pop(); cnt++;
        for (let d = 0; d < 6; d++) { const t = NB[c * 6 + d]; if (t >= 0 && ice[t] && comp[t] < 0) { comp[t] = k; stack.push(t); } }
      }
      sizes.push(cnt);
    }
    return { comp, sizes };
  }
  function keepLargest(ice) {
    const { comp, sizes } = comps(ice);
    if (sizes.length <= 1) return;
    let b = 0; for (let k = 1; k < sizes.length; k++) if (sizes[k] > sizes[b]) b = k;
    for (let i = 0; i < N; i++) if (ice[i] && comp[i] !== b) ice[i] = 0;
  }
  const UXz = (i, z) => (XW[i] - X0) / z.rx, VYz = (i, z) => (YW[i] - Y0) / z.ry;
  /* a fresh random floe every game: Eden growth from the centre inside a random ellipse, a few lakes and thin spots */
  function genIce(z) {
    const ice = new Array(N).fill(0), list = [];
    const st = tileAt(X0, Y0); ice[st] = 1; list.push(st);
    const area = (z.rx * z.ry) / (7.7 * 9.4);
    const target = Math.round((70 + Math.floor(Math.random() * 24)) * area), ea = 0.8 + Math.random() * 0.3, eb = 0.8 + Math.random() * 0.25;
    let guard = 0;
    while (list.length < target && guard++ < 60000) {
      const c = list[Math.floor(Math.random() * list.length)], t = NB[c * 6 + Math.floor(Math.random() * 6)];
      if (t < 0 || ice[t]) continue;
      const u = UXz(t, z) / ea, v = VYz(t, z) / eb, r = u * u + v * v;
      if (r > 1 || Math.random() > 1.2 - r * 0.8) continue;
      ice[t] = 1; list.push(t);
    }
    for (let i = 0; i < N; i++) if (!ice[i]) { let c = 0; for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n >= 0 && ice[n]) c++; } if (c >= 5) ice[i] = 1; }
    const lakes = Math.floor(Math.random() * (3 + z.k));
    for (let k = 0; k < lakes; k++) { const c = list[Math.floor(Math.random() * list.length)]; const r = UXz(c, z) ** 2 + VYz(c, z) ** 2; if (r < 0.45 && r > 0.05) ice[c] = 0; }
    for (const i of list) if (ice[i] && Math.random() < 0.07) ice[i] = 2;
    return ice;
  }
  /* spread the penguins out: greedy farthest-point from a few seeds, interior tiles first */
  function pickStarts(ice, n, avoid) {
    let cand = [];
    for (let i = 0; i < N; i++) {
      if (!ice[i] || (avoid && avoid[i])) continue;
      let ok = true; for (let d = 0; d < 6; d++) { const t = NB[i * 6 + d]; if (t < 0 || !ice[t]) ok = false; }
      if (ok) cand.push(i);
    }
    if (cand.length < n * 2) { cand = []; for (let i = 0; i < N; i++) if (ice[i] && !(avoid && avoid[i])) cand.push(i); }
    if (cand.length < n) { cand = []; for (let i = 0; i < N; i++) if (ice[i]) cand.push(i); }
    let best = null, bs = -1;
    const step = Math.max(1, Math.floor(cand.length / 24));
    for (let f = Math.floor(Math.random() * step); f < cand.length; f += step) {
      const pick = [cand[f]];
      while (pick.length < n) {
        let bc = -1, bv = -1;
        for (const c of cand) {
          if (pick.indexOf(c) >= 0) continue;
          let mn = 99, sm = 0; for (const p of pick) { const d = hd(c, p); if (d < mn) mn = d; sm += d; }
          const v = mn * 1000 + sm; if (v > bv) { bv = v; bc = c; }
        }
        if (bc < 0) break; pick.push(bc);
      }
      if (pick.length < n) continue;
      let mn = 99, sm = 0;
      for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) { const d = hd(pick[a], pick[b]); if (d < mn) mn = d; sm += d; }
      const sc = mn * 1000 + sm; if (sc > bs) { bs = sc; best = pick; }
    }
    return best;
  }
  /* special tiles (sp string, one char per tile): . none · h fishing hole (water) · t thin-ice zone · g glare ice ·
     b brittle (chain cracks) · v geyser vent · r rock ice */
  const rndOf = (a) => a[Math.floor(Math.random() * a.length)];
  function buildMap(li, z, n, rt) {
    const LY = LAYS[li];
    const code = new Array(N).fill(0);
    if (LY.gen) { const g = genIce(z); for (let i = 0; i < N; i++) code[i] = g[i]; }
    else for (let i = 0; i < N; i++) code[i] = LY.f(UXz(i, z), VYz(i, z), i, z);
    let gm;
    if (LY.gen) { const pool = GEN_GM.slice(); gm = []; while (gm.length < 2) { const g = pool.splice(Math.floor(Math.random() * pool.length), 1)[0]; gm.push(g); } }
    else gm = LY.gm.slice();
    const iceOf = () => code.map((c) => (c >= 1 && c <= 3 ? 1 : 0));
    let ice = iceOf(); keepLargest(ice);
    for (let i = 0; i < N; i++) if (!ice[i] && code[i] !== 4) code[i] = 0;
    for (let i = 0; i < N; i++) if (code[i] === 4) { let any = false; for (let d = 0; d < 6; d++) { const t = NB[i * 6 + d]; if (t >= 0 && ice[t]) any = true; } if (!any) code[i] = 0; }
    const has = (c) => code.indexOf(c) >= 0;
    // fishing holes for the fish gimmick (interior tiles, spread out)
    if (gm.indexOf('fish') >= 0 && !has(4)) {
      const cnt = [2, 3, 4][z.k], picked = [];
      const cand = []; for (let i = 0; i < N; i++) if (ice[i]) { let ok = true; for (let d = 0; d < 6; d++) { const t = NB[i * 6 + d]; if (t < 0 || !ice[t]) ok = false; } if (ok) cand.push(i); }
      for (let g = 0; g < 200 && picked.length < cnt && cand.length; g++) { const c = rndOf(cand); if (picked.every((p) => hd(p, c) >= 4)) picked.push(c); }
      for (const c of picked) code[c] = 4;
      ice = iceOf(); keepLargest(ice);
    }
    const holeOrRock = new Array(N).fill(0);
    for (let i = 0; i < N; i++) if (code[i] === 3) holeOrRock[i] = 1;
    const st = pickStarts(ice, n, holeOrRock);
    for (let i = st.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = st[i]; st[i] = st[j]; st[j] = t; }
    const sp = new Array(N).fill('.');
    for (let i = 0; i < N; i++) { if (code[i] === 4) sp[i] = 'h'; else if (code[i] === 2) sp[i] = 't'; else if (code[i] === 3 && rt) sp[i] = 'r'; }
    const nearStart = (i, d) => st.some((p) => hd(p, i) <= d);
    const iceList = []; for (let i = 0; i < N; i++) if (ice[i]) iceList.push(i);
    const blobs = (ch, cnt, rad, ok) => {
      for (let b = 0; b < cnt; b++) {
        let c = -1; for (let g = 0; g < 40; g++) { const t = rndOf(iceList); if (sp[t] === '.' && !nearStart(t, 2)) { c = t; break; } }
        if (c < 0) continue;
        for (const t of iceList) if (sp[t] === '.' && Math.hypot(XW[t] - XW[c], YW[t] - YW[c]) <= rad && (!ok || ok(t))) sp[t] = ch;
      }
    };
    const kk = z.k;
    if (gm.indexOf('thin') >= 0 && !has(2)) blobs('t', [2, 3, 4][kk], 1.8);
    if (rt) {
      if (gm.indexOf('glare') >= 0) blobs('g', [2, 3, 4][kk], 1.9);
      if (gm.indexOf('rock') >= 0 && !has(3)) blobs('r', [2, 3, 4][kk], 1.8);
      if (gm.indexOf('chain') >= 0) {
        for (let b = 0; b < [2, 3, 4][kk]; b++) { // fault lines across the field
          const c = rndOf(iceList), a = Math.random() * Math.PI, dx = Math.cos(a), dy = Math.sin(a), len = 3 + kk * 1.4 + Math.random() * 2;
          for (const t of iceList) {
            const rx = XW[t] - XW[c], ry = YW[t] - YW[c], al = rx * dx + ry * dy;
            if (Math.abs(al) <= len && Math.abs(rx * dy - ry * dx) <= 0.8 && sp[t] === '.') sp[t] = 'b';
          }
        }
      }
      if (gm.indexOf('gey') >= 0) {
        const cnt = [2, 3, 4][kk], picked = [];
        for (let g = 0; g < 300 && picked.length < cnt; g++) {
          const c = rndOf(iceList); if (sp[c] !== '.' || nearStart(c, 2)) continue;
          let inner = true; for (let d = 0; d < 6; d++) { const t = NB[c * 6 + d]; if (t < 0 || !ice[t]) inner = false; }
          if (inner && picked.every((p) => hd(p, c) >= 4)) picked.push(c);
        }
        for (const c of picked) sp[c] = 'v';
      }
    }
    for (const p of st) { code[p] = 1; for (let d = -1; d < 6; d++) { const t = d < 0 ? p : NB[p * 6 + d]; if (t >= 0 && ice[t] && 'tgbvr'.indexOf(sp[t]) >= 0 && (d < 0 || sp[t] !== 'r')) sp[t] = '.'; } }
    return { ice, sp, st, gm };
  }

  /* ---------- turn mode: pure helpers ---------- */
  function iceArr(s) { const a = new Array(N); for (let i = 0; i < N; i++) a[i] = s.ice.charCodeAt(i) - 48; return a; }
  function occ(s) {
    const o = new Int8Array(N).fill(-1);
    for (let k = 0; k < s.n; k++) if (!s.dead[k]) o[s.p[k]] = k;
    if (s.b.at >= 0) o[s.b.at] = 9;
    return o;
  }
  /* 팀전: s.tm[k] = 0/1 (자리 번갈아), 개인전이면 없음 */
  const TC = ['#4fa8ff', '#ff6a5c'], TN = ['파랑 팀', '빨강 팀'];
  function mate(s, a, b) { return !!s.tm && a !== b && s.tm[a] === s.tm[b]; }
  function oneLeft(s, al) { if (al.length <= 1) return true; return !!s.tm && al.every((k) => s.tm[k] === s.tm[al[0]]); }
  function teamWin(s, w) { // winners → whole team (dead teammates too) when all survivors share a team
    if (!s.tm || !w.length || !w.every((k) => s.tm[k] === s.tm[w[0]])) return null;
    const t = s.tm[w[0]], a = []; for (let k = 0; k < s.n; k++) if (s.tm[k] === t) a.push(k);
    return { winners: a, title: TN[t] + ' 승리!', text: '팀원 중 ' + (w.length > 1 ? w.length + '마리가' : '한 마리가') + ' 마지막까지 얼음 위에 남았어요!' };
  }
  function aliveSeats(s) { const a = []; for (let k = 0; k < s.n; k++) if (!s.dead[k]) a.push(k); return a; }
  /* tiles a penguin standing on `from` can walk to (≤ STEPS through empty ice), incl. staying */
  /* ty (optional): s 미끄러운 얼음 slides you on in the same direction, n 눈 덮인 얼음 ends the walk */
  function reachFrom(ice, oc, from, ty) {
    const prev = new Int16Array(N).fill(-2), dep = new Int8Array(N), mid = new Uint8Array(N);
    prev[from] = -1; const list = [from];
    for (let qi = 0; qi < list.length; qi++) {
      const c = list[qi]; if (dep[c] >= STEPS) continue;
      for (let d = 0; d < 6; d++) {
        const t = NB[c * 6 + d];
        if (t < 0 || prev[t] !== -2 || !ice[t] || oc[t] !== -1) continue;
        prev[t] = c;
        let stop = t;
        if (ty) while (ty[stop] === 's') {
          const nx = NB[stop * 6 + d];
          if (nx < 0 || !ice[nx] || oc[nx] !== -1 || prev[nx] !== -2) break;
          mid[stop] = 1; prev[nx] = stop; stop = nx;
        }
        dep[stop] = ty && ty[stop] === 'n' ? STEPS : dep[c] + 1; list.push(stop);
      }
    }
    return { list, prev, mid };
  }
  function pathTo(prev, to) { const p = []; for (let c = to; c !== -1; c = prev[c]) p.unshift(c); return p; }
  function targetsFrom(ice, to) {
    const t = [];
    for (let d = 0; d < 6; d++) { const n = NB[to * 6 + d]; if (n >= 0 && ice[n]) t.push(n); }
    if (!t.length && ice[to]) t.push(to); // nothing next to you: you stomp your own tile
    return t;
  }
  function isEdge(ice, i) { for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n < 0 || !ice[n]) return true; } return false; }

  /* split check: only the biggest piece stays (equal biggest pieces all stay); the rest drift away with riders */
  function sinkCheck(s, ice, ev, order) {
    if (s.fl) s.fl = s.fl.filter((f) => ice[f[0]] > 0); // 유빙: 깨진 조각은 사라짐, 남은 조각은 갈라짐 판정에서 빠짐
    const fm = floeMask(s);
    const { comp, sizes } = comps(fm ? ice.map((v, i) => (fm[i] ? 0 : v)) : ice);
    if (sizes.length <= 1) return;
    const mx = Math.max.apply(null, sizes);
    const ts = [];
    for (let i = 0; i < N; i++) if (comp[i] >= 0 && sizes[comp[i]] < mx) ts.push(i);
    if (!ts.length) return;
    const ps = [];
    for (let k = 0; k < s.n; k++) if (!s.dead[k] && sizes[comp[s.p[k]]] < mx) { ps.push(k); s.dead[k] = order; }
    let bb = 0;
    if (s.b.at >= 0 && comp[s.b.at] >= 0 && sizes[comp[s.b.at]] < mx) { bb = 1; s.b.at = -1; }
    for (const t of ts) ice[t] = 0;
    ev.push({ t: 'k', ts, ps, bb });
  }

  /* the bear's next action, taken right after `mover`'s turn (pure; also drawn as a preview) */
  function bearPlan(s, ice, oc, mover) {
    const b0 = s.b.at; if (b0 < 0) return null;
    ice = ice || iceArr(s); oc = oc || occ(s);
    if (mover == null) mover = s.turn;
    const steps = s.b.age >= ANGRY ? 2 : 1;
    const dist = new Int16Array(N).fill(-1), prev = new Int16Array(N).fill(-1);
    dist[b0] = 0; const q = [b0];
    for (let qi = 0; qi < q.length; qi++) {
      const c = q[qi];
      for (let d = 0; d < 6; d++) { const t = NB[c * 6 + d]; if (t < 0 || dist[t] >= 0 || !ice[t] || oc[t] !== -1) continue; dist[t] = dist[c] + 1; prev[t] = c; q.push(t); }
    }
    // nearest penguin; ties → one it can push into the water, then the one who just moved (then seat order after them)
    let tgt = -1, appr = -1, bk = 1e9;
    for (let k = 0; k < s.n; k++) {
      if (s.dead[k]) continue;
      const pos = s.p[k], rot = (k - mover + s.n) % s.n;
      for (let d = 0; d < 6; d++) {
        const n = NB[pos * 6 + d]; if (n < 0) continue;
        const dd = n === b0 ? 0 : dist[n]; if (dd < 0) continue;
        const dest = NB[pos * 6 + (d + 3) % 6];
        const leth = dest < 0 || !ice[dest] || (ice[pos] === 1 && oc[dest] !== -1 && dest !== b0) ? 1 : 0;
        const key = dd * 100 + (1 - leth) * 10 + rot;
        if (key < bk) { bk = key; tgt = k; appr = n; }
      }
    }
    let path = [b0];
    if (tgt >= 0) {
      if (appr !== b0) { const full = []; for (let c = appr; c !== -1; c = prev[c]) full.unshift(c); path = full.slice(0, steps + 1); }
    } else {
      // nobody reachable: shuffle toward the closest penguin as the crow flies
      let bestD = 1e9;
      for (let k = 0; k < s.n; k++) if (!s.dead[k] && hd(b0, s.p[k]) < bestD) { bestD = hd(b0, s.p[k]); tgt = k; }
      if (tgt < 0) return { path, tgt: -1, hit: 0, dir: -1, dest: -1, lethal: 0 };
      let c = b0;
      for (let st = 0; st < steps; st++) {
        let nx = -1, nd = hd(c, s.p[tgt]);
        for (let d = 0; d < 6; d++) { const t = NB[c * 6 + d]; if (t >= 0 && ice[t] && oc[t] === -1 && path.indexOf(t) < 0 && hd(t, s.p[tgt]) < nd) { nd = hd(t, s.p[tgt]); nx = t; } }
        if (nx < 0) break; path.push(nx); c = nx;
      }
    }
    const fin = path[path.length - 1], pos = s.p[tgt];
    const hit = hd(fin, pos) === 1 ? 1 : 0;
    let dest = -1, lethal = 0, dir = -1;
    if (hit) {
      dir = dirOf(fin, pos); dest = NB[pos * 6 + dir];
      lethal = dest < 0 || !ice[dest] || (ice[pos] === 1 && oc[dest] !== -1 && dest !== b0) ? 1 : 0;
    }
    return { path, tgt, hit, dir, dest, lethal };
  }
  function pickSpawn(s, ice) {
    const oc = occ(s), alive = aliveSeats(s), good = [];
    let best = -1, bs = -1;
    for (let i = 0; i < N; i++) {
      if (!ice[i] || oc[i] !== -1 || !isEdge(ice, i) || isFloe(s, i)) continue;
      let m = 99; for (const k of alive) m = Math.min(m, hd(i, s.p[k]));
      if (m >= 3) good.push(i);
      if (m > bs) { bs = m; best = i; }
    }
    return good.length ? good[Math.floor(Math.random() * good.length)] : best;
  }
  /* the bear acts right after every penguin's turn */
  function bearAct(s, ice, ev, mover) {
    const order = s.seq * 2 + 1;
    const pl = bearPlan(s, ice, null, mover);
    if (pl.path.length > 1) { ev.push({ t: 'bm', pa: pl.path }); s.b.at = pl.path[pl.path.length - 1]; }
    if (pl.hit) {
      const k = pl.tgt, pos = s.p[k], dest = pl.dest;
      ice[pos] = Math.max(0, ice[pos] - 1);
      const oc = occ(s);
      let to = pos, fell = 0;
      if (dest < 0 || !ice[dest]) { fell = 1; if (dest >= 0) to = dest; }
      else if (oc[dest] !== -1) { if (!ice[pos]) fell = 1; }
      else to = dest;
      s.p[k] = to;
      if (fell) s.dead[k] = order;
      ev.push({ t: 'sw', s: k, fr: pos, to, d: pl.dir, f: fell, v: ice[pos] });
      sinkCheck(s, ice, ev, order);
    }
  }
  /* end of a round: the bear gets angrier, or a warning splash appears, or it climbs onto the ice */
  /* 얼음 녹는 계절(차례대로): 곰이 올라오고 두 라운드 뒤부터, 라운드가 끝날 때마다 예고해 둔 가장자리 칸이 녹고
     다음에 녹을 칸을 새로 예고한다(예고된 칸에서 한 차례 안에 벗어나면 안전) */
  const MELT_T = 2;
  function meltStart(s) { return s.K + MELT_T; }
  function meltPick(ice, n, avoid) {
    let cx = 0, cy = 0, c = 0; for (let i = 0; i < N; i++) if (ice[i]) { cx += XW[i]; cy += YW[i]; c++; }
    if (!c) return [];
    cx /= c; cy /= c;
    const ed = []; for (let i = 0; i < N; i++) if (ice[i] && isEdge(ice, i) && (!avoid || avoid.indexOf(i) < 0)) ed.push([Math.hypot(XW[i] - cx, YW[i] - cy) + Math.random() * 0.8, i]);
    ed.sort((a, b) => b[0] - a[0]);
    return ed.slice(0, Math.max(0, Math.min(n, c - 4))).map((e) => e[1]);
  }
  function meltRound(s, ice, ev) {
    if (!s.ml) return;
    const order = s.seq * 2 + 1;
    if (s.mw && s.mw.length) {
      const ts = s.mw.filter((t) => ice[t]);
      s.mw = [];
      if (ts.length) {
        const ps = [];
        for (let k = 0; k < s.n; k++) if (!s.dead[k] && ts.indexOf(s.p[k]) >= 0) { ps.push(k); s.dead[k] = order; }
        let bb = 0; if (s.b.at >= 0 && ts.indexOf(s.b.at) >= 0) { bb = 1; s.b.at = -1; }
        for (const t of ts) ice[t] = 0;
        ev.push({ t: 'k', ts, ps, bb, ml: 1 });
        sinkCheck(s, ice, ev, order);
      }
    }
    if (aliveSeats(s).length > 1 && s.rd >= meltStart(s) - 1) {
      const n = Math.min(7, 3 + Math.max(0, s.rd - meltStart(s) + 1));
      const ts = meltPick(ice, n, (s.fl || []).map((f) => f[0]));
      if (ts.length) { s.mw = ts; ev.push({ t: 'mw', ts }); }
    }
  }
  /* 유빙(차례대로): 물 위의 얼음 한 칸짜리 조각. 라운드가 끝날 때마다 정해진 방향으로 한 칸 흘러가고(막히면 방향을 틂),
     위에 탄 펭귄·곰도 함께 간다. 다음 이동은 미리 화살표로 보인다(결정적). */
  function floeMask(s) { if (!s.fl || !s.fl.length) return null; const m = new Uint8Array(N); for (const f of s.fl) m[f[0]] = 1; return m; }
  function isFloe(s, i) { if (s.fl) for (const f of s.fl) if (f[0] === i) return true; return false; }
  function floeMoves(s, ice) {
    const out = []; if (!s.fl || !s.fl.length) return out;
    const fm = floeMask(s), used = new Uint8Array(N);
    const nearMain = (t) => { for (let i = 0; i < N; i++) if (ice[i] && !fm[i] && hd(i, t) <= 2) return true; return false; };
    for (const f of s.fl) {
      const c = f[0]; let to = -1, nd = f[1];
      for (const o of [0, 1, 5, 2, 4, 3]) {
        const d = (f[1] + o) % 6, t = NB[c * 6 + d];
        if (t < 0 || ice[t] || used[t] || fm[t] || (s.mw && s.mw.indexOf(t) >= 0) || !nearMain(t)) continue;
        let edge = false; for (let e = 0; e < 6; e++) if (NB[t * 6 + e] < 0) edge = true;
        if (edge) continue;
        to = t; nd = d; break;
      }
      if (to >= 0) used[to] = 1;
      out.push([c, to, nd]);
    }
    return out;
  }
  function floeRound(s, ice, ev) {
    const mv = floeMoves(s, ice), shown = [];
    mv.forEach((m, j) => {
      const [a, b, d] = m; s.fl[j][1] = d;
      if (b < 0) return;
      ice[b] = ice[a]; ice[a] = 0; s.fl[j][0] = b;
      for (let k = 0; k < s.n; k++) if (!s.dead[k] && s.p[k] === a) s.p[k] = b;
      if (s.b.at === a) s.b.at = b;
      if (s.b.w === a) s.b.w = -1;
      shown.push([a, b]);
    });
    if (shown.length) ev.push({ t: 'fd', mv: shown });
  }
  /* 범고래(차례대로): 라운드 끝에 지느러미가 물가 칸 하나를 노리고(예고), 다음 라운드 끝에 그 칸을 들이받는다.
     그 칸은 한 단계 깨지고, 위의 펭귄은 안쪽으로 한 칸 밀려난다(못 밀리고 칸이 구멍 나면 풍덩). */
  function seaMask(ice) { // water reachable from the open sea (not enclosed holes)
    const sea = new Uint8Array(N), q = [];
    for (let i = 0; i < N; i++) { if (ice[i]) continue; let b = false; for (let d = 0; d < 6; d++) if (NB[i * 6 + d] < 0) b = true; if (b) { sea[i] = 1; q.push(i); } }
    for (let qi = 0; qi < q.length; qi++) for (let d = 0; d < 6; d++) { const t = NB[q[qi] * 6 + d]; if (t >= 0 && !sea[t] && !ice[t]) { sea[t] = 1; q.push(t); } }
    return sea;
  }
  const WDIR = (i, ice, sea) => { for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n >= 0 && !ice[n] && (!sea || sea[n])) return d; } for (let d = 0; d < 6; d++) if (NB[i * 6 + d] < 0) return d; return -1; };
  function orcaRound(s, ice, ev) {
    const o = s.o; if (!o) return;
    const order = s.seq * 2 + 1;
    if (o.t >= 0) {
      const i = o.t, d = o.d; o.t = -1; o.cd = 1;
      if (!ice[i]) { ev.push({ t: 'oh', at: i, d, v: 0, s: -1, to: -1, f: 0, miss: 1 }); return; }
      const oc = occ(s); let k = -1;
      for (let q = 0; q < s.n; q++) if (!s.dead[q] && s.p[q] === i) k = q;
      const v = ice[i] - 1; ice[i] = v;
      let to = -1, f = 0;
      if (k >= 0) {
        const dest = NB[i * 6 + (d + 3) % 6];
        if (dest >= 0 && ice[dest] && oc[dest] === -1) { to = dest; s.p[k] = dest; }
        else if (!v) { f = 1; s.dead[k] = order; }
      }
      if (!v && s.b.at === i) s.b.at = -1;
      ev.push({ t: 'oh', at: i, d, v, s: k, to, f });
      sinkCheck(s, ice, ev, order);
      return;
    }
    if (o.cd > 0) { o.cd--; return; }
    const al = aliveSeats(s); if (al.length < 2) return;
    const fm = floeMask(s), oc = occ(s), cand = [], sea = seaMask(fm ? ice.map((v, i) => (fm[i] ? 0 : v)) : ice);
    for (let i = 0; i < N; i++) {
      if (!ice[i] || (fm && fm[i]) || !isEdge(ice, i) || i === s.b.w) continue;
      let ok = false; for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n < 0 || (sea[n] && !ice[n])) ok = true; }
      if (!ok) continue;
      let m = 99; for (const k of al) m = Math.min(m, hd(i, s.p[k]));
      if (m <= 1) cand.push([m * 2 + (oc[i] >= 0 && oc[i] < 9 ? 0 : 1) + Math.random() * 1.5, i]);
    }
    if (!cand.length) return;
    cand.sort((a, b) => a[0] - b[0]);
    const i = cand[0][1]; o.t = i; o.d = WDIR(i, ice, sea);
    ev.push({ t: 'ow', at: i, d: o.d });
  }
  function roundEnd(s, ice, ev) {
    floeRound(s, ice, ev);
    meltRound(s, ice, ev);
    if (aliveSeats(s).length > 1) orcaRound(s, ice, ev);
    const b = s.b;
    if (b.at >= 0) b.age++;
    else if (b.w >= 0) {
      let p = b.w;
      if (!ice[p] || occ(s)[p] !== -1) p = pickSpawn(s, ice);
      b.w = -1;
      if (p >= 0) { b.at = p; ev.push({ t: 'bi', at: p }); }
    } else if (s.rd >= s.K - 1) {
      const p = pickSpawn(s, ice);
      if (p >= 0) { b.w = p; ev.push({ t: 'w', at: p }); }
    }
  }

  /* ---------- game logic ---------- */
  const BEAR_TURNS = { fast: 16, mid: 24, slow: 32 }; // turn mode: total turns (all players) before the bear climbs on
  const BEAR_SEC = { fast: 20, mid: 32, slow: 45 };   // realtime: seconds before the bear climbs on
  function bearRound(n, v) { return Math.max(3, Math.round((BEAR_TURNS[v] || BEAR_TURNS.mid) / n)); }
  let curMode = 'rt'; // mode of the game last started/shown on this device (picks the tutorial)
  function init(players, opts) {
    opts = opts || {};
    const n = players.length, rt = opts.mode !== 't', tm = opts.team === 'team' ? players.map((_, k) => k % 2) : undefined;
    curMode = rt ? 'rt' : 't';
    let li = LAYS.findIndex((l) => l.id === opts.lay);
    if (li < 0) li = Math.floor(Math.random() * LAYS.length);
    const sz = sizeFor(opts.size, n, rt), z = SIZES[sz];
    const M = buildMap(li, z, n, rt);
    const g = Math.floor(Math.random() * 1e6);
    const plan = mixPlan(opts.mix), TY = mixTiles(M.ice, M.st, plan, (i) => M.sp[i] !== '.');
    if (rt) {
      const RTC = { c: 't', k: 'k', s: 'g', n: 'n' }, extra = [];
      for (let i = 0; i < N; i++) if (TY[i] !== '.') M.sp[i] = RTC[TY[i]];
      if (plan) for (const [ch, gk] of [['c', 'thin'], ['k', 'thick'], ['s', 'glare'], ['n', 'snow']]) if (TY.indexOf(ch) >= 0 && M.gm.indexOf(gk) < 0) extra.push(gk);
      M.gm = M.gm.concat(extra);
      const ice = M.ice.map((v, i) => (v ? (M.sp[i] === 't' ? 2 : 4) : 0)).join('');
      let gm = M.gm.slice(); if (sz === 2) gm.push('bears');
      if (opts.floe === 'off') gm = gm.filter((k) => k !== 'floe' && k !== 'lakef' && k !== 'cur');
      else if (gm.indexOf('lakef') < 0 && gm.indexOf('cur') < 0 && gm.indexOf('floe') < 0) gm.push('floe');
      if (opts.sea === 'off') gm = gm.filter((k) => k !== 'seal'); else gm.push('orca');
      return { n, g, m: 'rt', lay: li, sz, gm, ice, sp: M.sp.join(''), p: M.st, dead: M.st.map(() => 0), bt: BEAR_SEC[opts.bear] || BEAR_SEC.mid, ml: opts.melt === 'off' ? 0 : 1, over: 0, tt: 0, w: null, cap: 0, tm };
    }
    const ice = M.ice.map((v, i) => (v ? (M.sp[i] === 't' || TY[i] === 'c' ? 1 : TY[i] === 'k' ? 3 : 2) : 0)).join('');
    const ty = plan && TY.some((c) => c !== '.') ? TY.join('') : undefined;
    const fl = [];
    if (opts.floe !== 'off') {
      const ia = M.ice, cand = [];
      for (let i = 0; i < N; i++) {
        if (ia[i]) continue;
        let edge = false; for (let d = 0; d < 6; d++) if (NB[i * 6 + d] < 0) edge = true;
        if (edge) continue;
        let m = 99; for (let j = 0; j < N; j++) if (ia[j]) { const h = hd(i, j); if (h < m) m = h; }
        if (m === 2) cand.push(i);
      }
      const want = [2, 2, 3][sz] || 2;
      for (let g2 = 0; g2 < 60 && fl.length < want && cand.length; g2++) {
        const c = cand[Math.floor(Math.random() * cand.length)];
        if (fl.some((f) => hd(f[0], c) < 3) || M.st.some((p) => hd(p, c) < 3)) continue;
        fl.push([c, Math.floor(Math.random() * 6)]);
      }
    }
    const iceS = ice.split('').map((ch, i) => (fl.some((f) => f[0] === i) ? '2' : ch)).join('');
    return { n, g, lay: li, sz, ice: iceS, ty, fl, o: opts.sea === 'off' ? null : { t: -1, d: 0, cd: 2 }, p: M.st, dead: M.st.map(() => 0), turn: 0, rd: 1, K: bearRound(n, opts.bear),
      b: { at: -1, w: -1, age: 0 }, ml: opts.melt === 'off' ? 0 : 1, mw: [], seq: 0, over: 0, last: null, tm };
  }
  function actor(s) { return s.m === 'rt' || s.over ? null : s.turn; }
  function nextAlive(s, from) { for (let k = from + 1; k < s.n; k++) if (!s.dead[k]) return k; return -1; }
  function apply(s, seat, a) {
    if (s.m === 'rt') throw new Error('realtime mode: no turn actions');
    if (s.over || seat !== s.turn || !a || typeof a.to !== 'number' || typeof a.h !== 'number') throw new Error('bad action');
    const ice = iceArr(s), oc = occ(s), from = s.p[seat];
    const r = reachFrom(ice, oc, from, s.ty);
    if (a.to < 0 || a.to >= N || r.prev[a.to] === -2 || r.mid[a.to]) throw new Error('cannot walk there');
    if (targetsFrom(ice, a.to).indexOf(a.h) < 0) throw new Error('cannot strike there');
    s.seq++;
    const ev = [], order = s.seq * 2;
    const pre = { i: s.ice, p: s.p.slice(), d: s.dead.map((x) => (x ? 1 : 0)), b: s.b.at, w: s.b.w, mw: (s.mw || []).slice(), fl: (s.fl || []).map((f) => f.slice()), o: s.o ? { t: s.o.t, d: s.o.d } : null };
    if (a.to !== from) { ev.push({ t: 'm', s: seat, pa: pathTo(r.prev, a.to) }); s.p[seat] = a.to; }
    const h = a.h;
    if (!s.ss) s.ss = { h: Array(s.n).fill(0), k: Array(s.n).fill(0), m: Array(s.n).fill(0) }; // result stats
    s.ss.h[seat]++; s.ss.m[seat]++;
    ice[h]--;
    ev.push({ t: 'h', s: seat, at: h, v: ice[h] });
    if (!ice[h]) {
      for (let k = 0; k < s.n; k++) if (!s.dead[k] && s.p[k] === h) { s.dead[k] = order; ev.push({ t: 'f', s: k, at: h }); if (k !== seat) s.ss.k[seat]++; }
      if (s.b.at === h) { s.b.at = -1; ev.push({ t: 'bf', at: h }); }
    }
    sinkCheck(s, ice, ev, order);
    if (s.ty && !s.dead[seat]) { // 금 간 얼음: stop on it and it starts to sag; still there after your next turn → it gives way
      const pos = s.p[seat], ch = s.ty[pos];
      if (ice[pos] && (ch === 'c' || ch === 'C')) {
        if (ch === 'C' && a.to === from) {
          ice[pos] = 0; s.dead[seat] = order;
          ev.push({ t: 'cb', at: pos, s: seat }); ev.push({ t: 'f', s: seat, at: pos });
          sinkCheck(s, ice, ev, order);
        } else if (ch === 'c') s.ty = s.ty.slice(0, pos) + 'C' + s.ty.slice(pos + 1);
      }
    }
    const bp = ev.length;
    if (!oneLeft(s, aliveSeats(s)) && s.b.at >= 0) bearAct(s, ice, ev, seat);
    if (!oneLeft(s, aliveSeats(s))) {
      let nx = nextAlive(s, seat);
      if (nx < 0) { roundEnd(s, ice, ev); s.rd++; nx = nextAlive(s, -1); }
      s.turn = nx < 0 ? 0 : nx;
    }
    if (oneLeft(s, aliveSeats(s))) s.over = 1;
    s.ice = ice.join('');
    s.last = { id: s.seq, s: seat, pre, ev, bp };
    return s;
  }
  function statRows(s) {
    const ss = s.ss; if (!ss) return null;
    const col = (a, fm) => Array.from({ length: s.n }, (_, i) => fm((Array.isArray(a) ? a[i] : 0) | 0));
    if (s.m === 'rt') return [{ label: '버틴 시간', values: col(ss.t, (v) => Math.floor(v / 60) + ':' + String(v % 60).padStart(2, '0')) },
      { label: '배치기', values: col(ss.d, (v) => v + '번') }, { label: '밀려난 횟수', values: col(ss.h, (v) => v + '번') }];
    return [{ label: '깬 얼음', values: col(ss.h, (v) => v + '칸') }, { label: '빠뜨린 상대', values: col(ss.k, (v) => v + '마리') }, { label: '둔 차례', values: col(ss.m, (v) => v + '번') }];
  }
  function result(s) {
    const r = result0(s); if (r) { const t = statRows(s); if (t) r.stats = t; } return r;
  }
  function result0(s) {
    if (!s.over) return null;
    if (s.m === 'rt') {
      const w = s.w || [];
      const tw = teamWin(s, w); if (tw) return tw;
      const tt = Math.floor((s.tt || 0) / 60) + ':' + String((s.tt || 0) % 60).padStart(2, '0');
      if (w.length === 1) return { winners: w, text: tt + ' 동안 버티고 마지막까지 얼음 위에 남았어요!' };
      if (s.cap) return { winners: w, title: '무승부', text: '시간이 다 돼서 남은 펭귄이 함께 이겼어요.' };
      return { winners: w, title: '무승부', text: '남은 펭귄들이 한꺼번에 빠졌어요.' };
    }
    const alive = aliveSeats(s);
    const tw = teamWin(s, alive); if (tw) return tw;
    if (alive.length === 1) return { winners: alive, text: '마지막까지 얼음 위에 남았어요!' };
    const mx = Math.max.apply(null, s.dead);
    const w = []; for (let k = 0; k < s.n; k++) if (s.dead[k] === mx) w.push(k);
    return { winners: w, title: '무승부', text: '남은 펭귄들이 한꺼번에 빠졌어요.' };
  }

  /* ---------- turn mode AI ---------- */
  function actions(s, seat) {
    const ice = iceArr(s), oc = occ(s);
    const r = reachFrom(ice, oc, s.p[seat], s.ty), out = [];
    for (const to of r.list) for (const h of targetsFrom(ice, to)) out.push({ to, h });
    return out;
  }
  const cloneS = (s) => JSON.parse(JSON.stringify(s));
  function evalFor(s, me, full) {
    if (s.dead[me]) {
      const r = result(s);
      return r && r.winners.indexOf(me) >= 0 ? -20000 : -100000;
    }
    const alive = aliveSeats(s).filter((o) => !mate(s, me, o));
    if (alive.length === 1) return 100000;
    let sc = -900 * (alive.length - 1);
    if (s.tm) for (let o = 0; o < s.n; o++) if (mate(s, me, o)) { // 팀원: 살아 있게, 튼튼한 얼음 위에
      if (s.dead[o]) { sc -= 700; continue; }
      const ti = iceArr(s)[s.p[o]]; if (ti === 1) sc -= 60;
    }
    const ice = iceArr(s), oc = occ(s), my = s.p[me];
    const mr = reachFrom(ice, oc, my, s.ty);
    sc += Math.min(mr.list.length, 12) * 6;
    let nIce = 0; for (let d = 0; d < 6; d++) { const n = NB[my * 6 + d]; if (n >= 0 && ice[n]) nIce++; }
    sc += nIce * 5 - (6 - nIce) * 7;
    if (ice[my] === 1) sc -= 45;
    if (ice[my] === 3) sc += 18;
    if (s.ty) { const ch = s.ty[my]; if (ch === 'C') sc -= 70; else if (ch === 'c') sc -= 20; }
    if (s.mw && s.mw.length) { // 녹기 직전 칸 피하기
      if (s.mw.indexOf(my) >= 0) sc -= me >= s.turn ? 150 : 2500; // 이번 라운드에 내 차례가 남았으면 아직 피할 수 있음
      for (let d = 0; d < 6; d++) { const n = NB[my * 6 + d]; if (n >= 0 && s.mw.indexOf(n) >= 0) sc -= 6; }
    }
    if (s.ml && s.rd >= meltStart(s) - 1) { let cx = 0, cy = 0, c = 0; for (let i = 0; i < N; i++) if (ice[i]) { cx += XW[i]; cy += YW[i]; c++; } if (c) sc -= Math.hypot(XW[my] - cx / c, YW[my] - cy / c) * 4; }
    if (s.o && s.o.t >= 0) { // 범고래가 노리는 물가 칸
      if (s.o.t === my) { const dest = NB[my * 6 + (s.o.d + 3) % 6]; const safe = dest >= 0 && ice[dest] && oc[dest] === -1; sc -= me >= s.turn ? 60 : safe ? (ice[my] === 1 ? 120 : 70) : (ice[my] === 1 ? 2500 : 90); }
    }
    if (s.fl && isFloe(s, my)) { let adj = false; for (let d = 0; d < 6; d++) { const n = NB[my * 6 + d]; if (n >= 0 && ice[n] && !isFloe(s, n)) adj = true; } if (!adj) sc -= 25; }
    if (!full) return sc;
    for (const o of alive) {
      if (o === me) continue;
      const orr = reachFrom(ice, oc, s.p[o], s.ty);
      let canHit = false;
      for (const t of orr.list) if (hd(t, my) === 1) { canHit = true; break; }
      if (canHit) sc -= ice[my] === 1 ? 650 : 30;
      if (ice[s.p[o]] === 1) sc += 30;
      sc -= Math.min(orr.list.length, 12) * 4;
      let oIce = 0; for (let d = 0; d < 6; d++) { const n = NB[s.p[o] * 6 + d]; if (n >= 0 && ice[n]) oIce++; }
      sc -= oIce * 3;
    }
    if (s.b.at >= 0) {
      const pl = bearPlan(s, ice, oc);
      if (pl && pl.tgt === me) sc -= pl.hit ? (pl.lethal ? 500 : 120) : 50;
      else if (pl && pl.hit && pl.lethal) sc += 60;
      sc += Math.min(hd(s.b.at, my), 6) * 12;
    } else if (s.b.w >= 0) sc += Math.min(hd(s.b.w, my), 6) * 6;
    return sc;
  }
  function bestReply(s, seat) {
    let best = null, bs = -1e9;
    for (const a of actions(s, seat)) {
      const s2 = apply(cloneS(s), seat, a);
      const v = evalFor(s2, seat, true);
      if (v > bs) { bs = v; best = s2; }
    }
    return best;
  }
  function ai(s, seat, lv) {
    if (s.m === 'rt') return null;
    lv = lv || 2;
    const acts = actions(s, seat);
    if (!acts.length) return null;
    if (lv === 1 && Math.random() < 0.15) return acts[Math.floor(Math.random() * acts.length)];
    const scored = acts.map((a) => {
      const s2 = apply(cloneS(s), seat, a);
      const noise = lv === 1 ? Math.random() * 260 : lv === 2 ? Math.random() * 30 : Math.random() * 4;
      return { a, s2, v: evalFor(s2, seat, lv > 1) + noise };
    });
    scored.sort((x, y) => y.v - x.v);
    if (lv < 3) return scored[0].a;
    let best = scored[0], bs = -1e9;
    for (const c of scored.slice(0, 6)) {
      let v = c.v;
      const s2 = c.s2;
      if (!s2.over && s2.turn !== seat && !s2.dead[seat]) {
        const s3 = bestReply(s2, s2.turn);
        if (s3) v = evalFor(s3, seat, true) * 0.7 + v * 0.3;
      }
      if (v > bs) { bs = v; best = c; }
    }
    return best.a;
  }
  /* animation length of one event (seconds at speed 1) — shared by the view and the AI pacing */
  function evDur(e) {
    switch (e.t) {
      case 'm': return 0.26 * (e.pa.length - 1);
      case 'h': return 0.44;
      case 'cb': return 0.5;
      case 'f': return 0.6;
      case 'bf': return 0.75;
      case 'k': return 1.0;
      case 'w': return 0.8;
      case 'mw': return 0.6;
      case 'bi': return 1.0;
      case 'bm': return 0.34 * (e.pa.length - 1);
      case 'sw': return 0.7;
      case 'fd': return 0.7;
      case 'ow': return 0.7;
      case 'oh': return 0.9;
    }
    return 0.2;
  }
  // AI waits for the last move's animation, then a short look-around pause
  function aiDelayFor(s, seat, lv) {
    if (s.m === 'rt') return -1;
    const anim = s.last ? s.last.ev.reduce((a, e) => a + evDur(e), 0) * 1000 : 0;
    return anim + (lv === 1 ? 850 : lv === 3 ? 550 : 700);
  }

  /* ---------- realtime mode: world sim (host/local device runs it, guests mirror it) ---------- */
  const RT = {
    VMAX: 3.0, ACC: 7, FRIC: 5, SFRIC: 2.6, DASHV: 8, DASHT: 0.22, DASHCD: 1.3, PUSHV: 6.0, PR: 0.4, BR: 0.72,
    LVLT: 1.1, MOVE: 0.55, BEARST: 1.1, BSPD: 1.9, BSPD2: 2.5, ANGRYT: 25, WARN: 3, BACK: 7, WIND: 0.6, WIND2: 0.45,
    KNOCK: 8.5, REACH: 1.75, CAP: 300, FR: 0.95, IR: 0.95, GUST: 6, SNOWW: 1.5, PWT: 5, BEAR2: 14, FLOEHP: 3,
  };
  const MELT = [90, 100, 110], MELTK = [1, 1.6, 2.4], MELTW = 2.5; // 녹기 시작(초), 녹는 빠르기, 예고 시간(초)
  const SPC = { '.': 0, h: 1, t: 2, g: 3, b: 4, v: 5, r: 6, k: 7, n: 8 };
  const SP_H = 1, SP_T = 2, SP_G = 3, SP_B = 4, SP_V = 5, SP_R = 6, SP_K = 7, SP_N = 8;
  function newBear(k, at0) { return { k, at0, st: 0, x: 0, y: 0, vx: 0, vy: 0, dx: 1, dy: 0, t: 0, age: 0, cd: 0, tgt: -1, wx: -9, wy: -9, rp: 0, way: -1, sw: 0, hit: 0 }; }
  function iceBB(wd) {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let i = 0; i < N; i++) if (wd.ice[i]) { if (XW[i] < x0) x0 = XW[i]; if (XW[i] > x1) x1 = XW[i]; if (YW[i] < y0) y0 = YW[i]; if (YW[i] > y1) y1 = YW[i]; }
    if (x0 > x1) { x0 = x1 = X0; y0 = y1 = Y0; }
    wd.bb = { x0: x0 - 1, y0: y0 - 1, x1: x1 + 1, y1: y1 + 1 };
  }
  function newWorld(s) {
    const ice = new Int8Array(N), acc = new Float32Array(N), sp = new Uint8Array(N), cc = new Float32Array(N);
    for (let i = 0; i < N; i++) { ice[i] = s.ice.charCodeAt(i) - 48; sp[i] = SPC[s.sp ? s.sp[i] : '.'] || 0; }
    const gm = {}; for (const g of s.gm || []) gm[g] = 1;
    const sz = s.sz | 0;
    let cx = 0, cy = 0, cn = 0; for (let i = 0; i < N; i++) if (ice[i]) { cx += XW[i]; cy += YW[i]; cn++; }
    cx = cn ? cx / cn : X0; cy = cn ? cy / cn : Y0;
    const pl = [];
    for (let k = 0; k < s.n; k++) pl.push({ x: XW[s.p[k]], y: YW[s.p[k]], vx: 0, vy: 0, fx: XW[s.p[k]] > cx ? -1 : 1, fy: 0, dash: 0, cd: 0, stun: 0, out: s.dead[k] ? 1 : 0, hc: 0, dn: 0, pw: 0, fe: 0 });
    let ord = 0; for (const d of s.dead) if (d > ord) ord = d;
    const wd = { tm: s.tm, t: 0, sz, gm, ice, acc, sp, cc, pl, dead: s.dead.slice(), ord, bt: s.bt || BEAR_SEC.mid, melt: 0, ch: 0, res: null, brk: 0,
      cx, cy, meltAt: s.ml === 0 ? 1e9 : MELT[sz], mw: [], mk: new Uint8Array(N), bs: [], fl: [], sl: [], vs: [], fs: [], holes: [], cq: [], shore: null, bb: null,
      ib: { st: 0, x: 0, y: 0, dx: 1, dy: 0, t: 0, len: 0, d: 0, lt: -1, hm: 0 },
      wn: { st: 0, t: 9 + Math.random() * 4, dx: 1, dy: 0 }, sn: { st: 0, t: 14 + Math.random() * 6, dx: 1, dy: 0 },
      tSeal: 9 + Math.random() * 3, tBerg: 13 + Math.random() * 4, tFish: 2.5 + Math.random() * 2 };
    const nb = gm.bears ? 2 : 1;
    for (let k = 0; k < nb; k++) wd.bs.push(newBear(k, wd.bt + k * RT.BEAR2));
    for (let i = 0; i < N; i++) { if (sp[i] === SP_V && ice[i]) wd.vs.push({ i, t: 5 + Math.random() * 5, st: 0, e: 0 }); if (sp[i] === SP_H) wd.holes.push(i); }
    if (gm.seal) for (let k = 0; k < (sz === 2 ? 2 : 1); k++) wd.sl.push({ st: 0, x: 0, y: 0, dx: 1, dy: 0, t: 0, d: 0, on: 0, hm: 0, e: 0, e2: 0 });
    iceBB(wd);
    if (gm.floe || gm.lakef || gm.cur) makeFloes(wd);
    if (gm.orca) wd.oc = { st: 0, t: 12 + Math.random() * 5, x: 0, y: 0, dx: 1, dy: 0, ti: -1, e: 0 };
    return wd;
  }
  /* ----- drifting floes: orbit the island (or a lake), or ride the current through the strait ----- */
  function makeFloes(wd) {
    const cnt = [2, 3, 4][wd.sz], B = 48;
    if (wd.gm.cur) {
      const x0 = wd.bb.x0 - 1.5, x1 = wd.bb.x1 + 1.5;
      wd.cur = { x0, x1 };
      for (let k = 0; k < cnt; k++) wd.fl.push({ m: 2, a: 0, x: x0 + (k + 0.5) * (x1 - x0) / cnt, y: Y0, vx: 0, vy: 0, hp: RT.FLOEHP, rs: 0 });
      return;
    }
    let inner = false, ccx = wd.cx, ccy = wd.cy;
    if (wd.gm.lakef) { // the biggest enclosed water (not reachable from the open sea)
      const sea = new Uint8Array(N), q = [];
      for (let i = 0; i < N; i++) {
        if (wd.ice[i]) continue;
        let border = false; for (let d = 0; d < 6; d++) if (NB[i * 6 + d] < 0) border = true;
        if (border) { sea[i] = 1; q.push(i); }
      }
      for (let qi = 0; qi < q.length; qi++) for (let d = 0; d < 6; d++) { const t = NB[q[qi] * 6 + d]; if (t >= 0 && !sea[t] && !wd.ice[t]) { sea[t] = 1; q.push(t); } }
      const lake = new Array(N); for (let i = 0; i < N; i++) lake[i] = !wd.ice[i] && !sea[i] ? 1 : 0;
      const { comp, sizes } = comps(lake);
      let bk = -1; for (let k = 0; k < sizes.length; k++) if (sizes[k] >= 3 && (bk < 0 || sizes[k] > sizes[bk])) bk = k;
      if (bk >= 0) { inner = true; let sx = 0, sy = 0, n = 0; for (let i = 0; i < N; i++) if (comp[i] === bk) { sx += XW[i]; sy += YW[i]; n++; } ccx = sx / n; ccy = sy / n; }
    }
    const rr = new Float32Array(B).fill(inner ? 99 : -1);
    for (let i = 0; i < N; i++) {
      if (!wd.ice[i]) continue;
      const dx = XW[i] - ccx, dy = YW[i] - ccy, d = Math.hypot(dx, dy);
      const b = Math.floor(((Math.atan2(dy, dx) / (2 * Math.PI)) + 1) * B) % B;
      if (inner ? d < rr[b] : d > rr[b]) rr[b] = d;
    }
    for (let pass = 0; pass < B; pass++) for (let b = 0; b < B; b++) if (rr[b] === (inner ? 99 : -1)) { const a = rr[(b + B - 1) % B], c = rr[(b + 1) % B]; const ok = (v) => v !== (inner ? 99 : -1); if (ok(a)) rr[b] = a; else if (ok(c)) rr[b] = c; }
    for (let b = 0; b < B; b++) rr[b] = inner ? Math.max(0.4, rr[b] - 1.55) : rr[b] + 1.55;
    wd.shore = { cx: ccx, cy: ccy, r: rr, B };
    for (let k = 0; k < cnt; k++) {
      const a = (k / cnt) * Math.PI * 2 + Math.random() * 0.5, r = shoreR(wd.shore, a);
      wd.fl.push({ m: inner ? 1 : 0, a, x: ccx + Math.cos(a) * r, y: ccy + Math.sin(a) * r, vx: 0, vy: 0, hp: RT.FLOEHP, rs: 0 });
    }
  }
  function shoreR(S, a) {
    const f = (((a / (2 * Math.PI)) % 1) + 1) % 1 * S.B, i = Math.floor(f) % S.B, j = (i + 1) % S.B, u = f - Math.floor(f);
    return S.r[i] * (1 - u) + S.r[j] * u;
  }
  function floeStep(wd, h) {
    for (const f of wd.fl) {
      const ox = f.x, oy = f.y;
      if (f.hp <= 0) { f.rs -= h; if (f.rs <= 0) { f.hp = RT.FLOEHP; wd.ch++; } }
      if (f.m === 2) {
        f.x += 1.0 * h;
        if (f.x > wd.cur.x1) { f.x = wd.cur.x0; if (f.hp > 0) { f.hp = 0; f.rs = 1.5; } }
      } else {
        const S = wd.shore;
        f.a += (f.m ? -0.75 : 0.85) * h / Math.max(1.5, shoreR(S, f.a));
        const r = shoreR(S, f.a), tx = S.cx + Math.cos(f.a) * r, ty = S.cy + Math.sin(f.a) * r, k = Math.min(1, 2.5 * h);
        f.x += (tx - f.x) * k; f.y += (ty - f.y) * k;
      }
      f.vx = Math.abs(f.x - ox) > 1 ? 0 : (f.x - ox) / h; f.vy = (f.y - oy) / h;
    }
  }
  function onFloe(wd, x, y) {
    for (const f of wd.fl) if (f.hp > 0 && (x - f.x) * (x - f.x) + (y - f.y) * (y - f.y) < RT.FR * RT.FR) return f;
    return null;
  }
  function waterN(wd, i) { let c = 0; for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n < 0 || !wd.ice[n]) c++; } return c; }
  const onTile = (wd, x, y) => { const t = tileAt(x, y); return t >= 0 && wd.ice[t] > 0; };
  const onIce = (wd, x, y) => onTile(wd, x, y) || !!onFloe(wd, x, y);
  /* every crack goes through here: rock resists until the sea warms up; brittle fault lines pass the crack along */
  function hurt(wd, i) {
    if (i < 0 || !wd.ice[i]) return;
    if (wd.sp[i] === SP_R && wd.t < wd.meltAt) return;
    wd.ice[i]--; wd.acc[i] = 0; wd.ch++;
    if (!wd.ice[i]) wd.brk = 1;
    if (wd.sp[i] === SP_B) {
      wd.cc[i] = wd.t + 0.9;
      for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n >= 0 && wd.sp[n] === SP_B && wd.ice[n] && wd.cc[n] <= wd.t) { wd.cc[n] = wd.t + 0.9; wd.cq.push(n, wd.t + 0.3); } }
    }
  }
  function movePeng(wd, p, I, h) {
    if (p.cd > 0) p.cd -= h;
    if (p.stun > 0) p.stun -= h;
    if (p.pw > 0) p.pw -= h;
    let ax = I ? +I.ax || 0 : 0, ay = I ? +I.ay || 0 : 0;
    const m = Math.hypot(ax, ay);
    if (m > 1) { ax /= m; ay /= m; }
    const ti = tileAt(p.x, p.y), onT = ti >= 0 && wd.ice[ti] > 0, gl = onT && wd.sp[ti] === SP_G, pw = p.pw > 0, sw = onT && wd.sp[ti] === SP_N;
    if (I && I.dash && p.cd <= 0 && p.stun <= 0) {
      let dx = ax, dy = ay, dm = Math.hypot(dx, dy);
      if (dm < 0.2) { dx = p.fx; dy = p.fy; dm = Math.hypot(dx, dy) || 1; }
      p.fx = dx / dm; p.fy = dy / dm;
      const dv = RT.DASHV * (sw ? 0.75 : 1);
      p.vx = p.fx * dv; p.vy = p.fy * dv; p.dash = RT.DASHT; p.cd = RT.DASHCD * (pw ? 0.45 : 1); p.dn = (p.dn + 1) % 64; p.dc = (p.dc | 0) + 1;
    }
    if (p.dash > 0) p.dash -= h;
    else if (m > 0.08) {
      const vm = RT.VMAX * (pw ? 1.25 : 1) * (sw ? 0.6 : 1), k = Math.min(1, (p.stun > 0 ? 1.4 : RT.ACC) * (gl ? 0.28 : 1) * h);
      p.vx += (ax * vm - p.vx) * k; p.vy += (ay * vm - p.vy) * k;
      const mm = Math.hypot(ax, ay); p.fx = ax / mm; p.fy = ay / mm;
    } else { const f = Math.exp(-(p.stun > 0 ? RT.SFRIC : RT.FRIC) * (gl ? 0.12 : sw ? 1.8 : 1) * h); p.vx *= f; p.vy *= f; }
    const w = wd.wn; if (w.st === 2) { p.vx += w.dx * RT.GUST * h; p.vy += w.dy * RT.GUST * h; }
    const sn = wd.sn; if (sn.st === 2) { p.vx += sn.dx * RT.SNOWW * h; p.vy += sn.dy * RT.SNOWW * h; }
    if (!onT && wd.fl.length) { const f = onFloe(wd, p.x, p.y); if (f) { p.x += f.vx * h; p.y += f.vy * h; } }
    p.x += p.vx * h; p.y += p.vy * h;
  }
  function knock(p, nx, ny, v, stun) { if (p.pw > 0) v *= 0.6; p.vx = nx * v; p.vy = ny * v; p.stun = Math.max(p.stun, stun); p.dash = 0; p.hc = (p.hc + 1) % 64; p.hn = (p.hn | 0) + 1; }
  const bearOn = (b) => b.st >= 2 && b.st <= 4;
  function collide(wd) {
    const P = wd.pl, D = RT.PR * 2;
    for (let a = 0; a < P.length; a++) {
      const A = P[a]; if (A.out) continue;
      for (let c = a + 1; c < P.length; c++) {
        const B = P[c]; if (B.out) continue;
        const dx = B.x - A.x, dy = B.y - A.y, d2 = dx * dx + dy * dy;
        if (d2 >= D * D) continue;
        const d = Math.sqrt(d2) || 1e-4, nx = d2 ? dx / d : 1, ny = d2 ? dy / d : 0, ov = (D - d) / 2;
        A.x -= nx * ov; A.y -= ny * ov; B.x += nx * ov; B.y += ny * ov;
        const rv = (B.vx - A.vx) * nx + (B.vy - A.vy) * ny;
        if (rv >= 0) continue;
        const tmm = mate(wd, a, c), ad = A.dash > 0 && !tmm, bd = B.dash > 0 && !tmm; // 팀원끼리는 배치기로 안 날아가요(살짝 부딪히기만)
        if (ad && !bd) { knock(B, nx, ny, RT.PUSHV * (A.pw > 0 ? 1.2 : 1), 0.4); A.vx *= 0.2; A.vy *= 0.2; A.dash = 0; }
        else if (bd && !ad) { knock(A, -nx, -ny, RT.PUSHV * (B.pw > 0 ? 1.2 : 1), 0.4); B.vx *= 0.2; B.vy *= 0.2; B.dash = 0; }
        else {
          const j = -1.8 * rv / 2;
          A.vx -= j * nx; A.vy -= j * ny; B.vx += j * nx; B.vy += j * ny;
          if (ad && bd) { A.dash = B.dash = 0; A.stun = B.stun = 0.3; A.hc = (A.hc + 1) % 64; B.hc = (B.hc + 1) % 64; }
        }
      }
    }
    const DB = RT.PR + RT.BR;
    for (const b of wd.bs) {
      if (!bearOn(b)) continue;
      for (const p of P) {
        if (p.out) continue;
        const dx = p.x - b.x, dy = p.y - b.y, d2 = dx * dx + dy * dy;
        if (d2 >= DB * DB) continue;
        const d = Math.sqrt(d2) || 1e-4, nx = dx / d, ny = dy / d;
        p.x = b.x + nx * DB; p.y = b.y + ny * DB;
        const rv = (p.vx - b.vx) * nx + (p.vy - b.vy) * ny;
        if (rv < 0) {
          if (p.dash > 0) knock(p, nx, ny, 3.2, 0.3); // bounced off the bear's belly
          else { p.vx -= rv * nx * 1.3; p.vy -= rv * ny * 1.3; }
        }
      }
    }
    if (wd.bs.length > 1) {
      const a = wd.bs[0], b = wd.bs[1];
      if (bearOn(a) && bearOn(b)) {
        const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 1e-4, DD = RT.BR * 2;
        if (d < DD) { const ov = (DD - d) / 2, nx = dx / d, ny = dy / d; a.x -= nx * ov; a.y -= ny * ov; b.x += nx * ov; b.y += ny * ov; }
      }
    }
  }
  function nearAlive(wd, x, y, r) { for (const p of wd.pl) if (!p.out && Math.hypot(p.x - x, p.y - y) < r) return true; return false; }
  function bearSpawn(wd, me) {
    let best = -1, bs = -1; const good = [];
    for (let i = 0; i < N; i++) {
      if (wd.ice[i] < 3 || !waterN(wd, i)) continue;
      let m = 99; for (const p of wd.pl) if (!p.out) m = Math.min(m, Math.hypot(XW[i] - p.x, YW[i] - p.y));
      for (const o of wd.bs) if (o !== me && (bearOn(o) || o.st === 1)) m = Math.min(m, Math.hypot(XW[i] - (o.st === 1 ? o.wx : o.x), YW[i] - (o.st === 1 ? o.wy : o.y)) * 0.8);
      if (m >= 4.5) good.push(i);
      if (m > bs) { bs = m; best = i; }
    }
    return good.length ? good[Math.floor(Math.random() * good.length)] : best;
  }
  function bearWarn(wd, b, dur) {
    const i = bearSpawn(wd, b);
    if (i < 0) { b.t = 1; return; }
    b.st = 1; b.t = dur; b.wx = XW[i]; b.wy = YW[i];
  }
  /* bear path: BFS over ice from its tile; target = penguin with the shortest walk (ties: closer). Two bears split up. */
  const bDist = new Int16Array(N), bPrev = new Int16Array(N);
  function bearPlanRT(wd, b) {
    const from = tileAt(b.x, b.y), dist = bDist, prev = bPrev;
    b.tgt = -1; b.way = -1;
    if (from < 0) return;
    let other = -1; for (const o of wd.bs) if (o !== b && bearOn(o)) other = o.tgt;
    let bk = 1e9, bt = -1;
    for (const minLv of [2, 1]) { // the bear knows its weight: it walks around badly cracked ice when it can
      dist.fill(-1); prev.fill(-1); dist[from] = 0; const q = [from];
      for (let qi = 0; qi < q.length; qi++) {
        const c = q[qi];
        for (let d = 0; d < 6; d++) { const t = NB[c * 6 + d]; if (t < 0 || dist[t] >= 0 || wd.ice[t] < minLv) continue; dist[t] = dist[c] + 1; prev[t] = c; q.push(t); }
      }
      wd.pl.forEach((p, k) => {
        if (p.out) return;
        const t = tileAt(p.x, p.y); if (t < 0) return;
        let dd = dist[t];
        if (dd < 0) for (let d = 0; d < 6; d++) { const n = NB[t * 6 + d]; if (n >= 0 && dist[n] >= 0 && (dd < 0 || dist[n] + 1 < dd)) dd = dist[n] + 1; }
        if (dd < 0) return;
        const key = dd * 100 + Math.hypot(p.x - b.x, p.y - b.y) + (k === other ? 250 : 0);
        if (key < bk) { bk = key; b.tgt = k; bt = dist[t] >= 0 ? t : -2 - t; }
      });
      if (b.tgt >= 0) break;
    }
    if (bt < -1) { // target stands on weak ice next to the safe path: walk to the safe neighbour
      const t = -2 - bt; let bn = -1;
      for (let d = 0; d < 6; d++) { const n = NB[t * 6 + d]; if (n >= 0 && dist[n] >= 0 && (bn < 0 || dist[n] < dist[bn])) bn = n; }
      bt = bn;
    }
    if (b.tgt < 0) { // nobody reachable on foot: nearest as the crow flies
      let bd = 1e9; wd.pl.forEach((p, k) => { if (!p.out) { const d = Math.hypot(p.x - b.x, p.y - b.y); if (d < bd) { bd = d; b.tgt = k; } } });
      return;
    }
    if (bt >= 0 && dist[bt] >= 2) { let c = bt; while (prev[c] !== from && prev[c] >= 0) c = prev[c]; b.way = c; }
  }
  function bearStep(wd, b, h) {
    const P = wd.pl;
    switch (b.st) {
      case 0: if (wd.t >= b.at0 - RT.WARN) bearWarn(wd, b, RT.WARN); break;
      case 1: {
        b.t -= h; if (b.t > 0) break;
        let i = tileAt(b.wx, b.wy);
        if (i < 0 || !wd.ice[i] || nearAlive(wd, XW[i], YW[i], 1.2)) { i = bearSpawn(wd, b); if (i < 0 || nearAlive(wd, XW[i], YW[i], 1.2)) { b.t = 0.5; break; } }
        b.st = 2; b.x = XW[i]; b.y = YW[i]; b.vx = b.vy = 0; b.cd = 1; b.age = 0; b.rp = 0;
        break;
      }
      case 2: {
        b.rp -= h; b.cd -= h;
        if (b.rp <= 0) { b.rp = 0.4; bearPlanRT(wd, b); }
        const tp = b.tgt >= 0 ? P[b.tgt] : null;
        if (!tp || tp.out) { b.rp = 0; b.vx *= 0.9; b.vy *= 0.9; break; }
        let tx = tp.x, ty = tp.y;
        const pd0 = Math.hypot(tp.x - b.x, tp.y - b.y);
        if (b.way >= 0 && wd.ice[b.way]) { tx = XW[b.way]; ty = YW[b.way]; if (Math.hypot(tx - b.x, ty - b.y) < 0.35) b.rp = 0; }
        const dx = tx - b.x, dy = ty - b.y, d = Math.hypot(dx, dy) || 1;
        const spd = b.age > RT.ANGRYT ? RT.BSPD2 : RT.BSPD, k = Math.min(1, 5 * h);
        b.vx += (dx / d * spd - b.vx) * k; b.vy += (dy / d * spd - b.vy) * k;
        const nx = b.x + b.vx * h, ny = b.y + b.vy * h, nt = tileAt(nx, ny), ct = tileAt(b.x, b.y);
        if (nt >= 0 && wd.ice[nt] && (nt === ct || wd.ice[nt] >= 2 || pd0 < 1.6)) { b.x = nx; b.y = ny; } else { b.vx *= 0.3; b.vy *= 0.3; b.rp = Math.min(b.rp, 0.1); }
        const pd = Math.hypot(tp.x - b.x, tp.y - b.y);
        if (pd > 0.01) { b.dx = (tp.x - b.x) / pd; b.dy = (tp.y - b.y) / pd; }
        if (pd < 1.3 && b.cd <= 0) { b.st = 3; b.t = b.age > RT.ANGRYT ? RT.WIND2 : RT.WIND; b.sw = (b.sw + 1) % 64; }
        break;
      }
      case 3: {
        b.t -= h; const f = Math.exp(-8 * h); b.vx *= f; b.vy *= f; b.x += b.vx * h; b.y += b.vy * h;
        if (b.t > 0) break;
        let any = false;
        for (const p of P) {
          if (p.out) continue;
          const rx = p.x - b.x, ry = p.y - b.y, d = Math.hypot(rx, ry) || 1e-4;
          if (d > RT.REACH || (rx * b.dx + ry * b.dy) / d < 0.42) continue;
          const kx = rx / d * 0.6 + b.dx * 0.4, ky = ry / d * 0.6 + b.dy * 0.4, km = Math.hypot(kx, ky) || 1;
          knock(p, kx / km, ky / km, RT.KNOCK, 0.6); any = true;
          hurt(wd, tileAt(p.x, p.y));
        }
        b.hit = (b.hit + 1) % 64; b.st = 4; b.t = any ? 0.7 : 0.5; b.cd = 1.3;
        break;
      }
      case 4: b.t -= h; b.vx *= 0.9; b.vy *= 0.9; if (b.t <= 0) b.st = 2; break;
      case 5: b.t -= h; if (b.t <= 0) bearWarn(wd, b, RT.WARN); break;
    }
    if (bearOn(b)) {
      b.age += h;
      if (!onTile(wd, b.x, b.y)) { b.st = 5; b.t = RT.BACK; b.vx = b.vy = 0; }
    }
  }
  /* ----- seals: pop up from the water (or a fishing hole), belly-slide straight across and bump penguins aside ----- */
  /* ----- 범고래: 지느러미가 물가 칸으로 다가오고(빨간 칸 예고) → 물보라 → 돌진해 가장자리를 들이받음 ----- */
  const OC = { APPR: 2.4, WIND: 1.2, V: 2.6, HIT: 1.2 };
  function orcaPick(wd) {
    const o = wd.oc, al = aliveList(wd);
    if (al.length < 2) { o.t = 3; return; }
    const q = al[Math.floor(Math.random() * al.length)];
    let bi = -1, bd = 2.6;
    const sea = seaMask(wd.ice);
    for (let i = 0; i < N; i++) {
      if (!wd.ice[i]) continue;
      let ok = false; for (let d = 0; d < 6; d++) { const n = NB[i * 6 + d]; if (n < 0 || (sea[n] && !wd.ice[n])) ok = true; }
      if (!ok) continue;
      const d = Math.hypot(XW[i] - q.x, YW[i] - q.y) + Math.random() * 0.6;
      if (d < bd) { bd = d; bi = i; }
    }
    if (bi < 0) { o.t = 2; return; }
    let nx = 0, ny = 0;
    for (let d = 0; d < 6; d++) { const n = NB[bi * 6 + d]; if (n < 0 || (sea[n] && !wd.ice[n])) { const a = [0, -60, -120, 180, 120, 60][d] * Math.PI / 180; nx += Math.cos(a); ny += Math.sin(a); } }
    const nm = Math.hypot(nx, ny) || 1; nx /= nm; ny /= nm;
    o.ti = bi; o.dx = -nx; o.dy = -ny;
    o.x = XW[bi] + nx * (1.4 + OC.V * OC.APPR); o.y = YW[bi] + ny * (1.4 + OC.V * OC.APPR);
    o.st = 1; o.t = OC.APPR;
  }
  function orcaStep(wd, h) {
    const o = wd.oc; if (!o) return;
    switch (o.st) {
      case 0: o.t -= h; if (o.t <= 0) orcaPick(wd); break;
      case 1: o.x += o.dx * OC.V * h; o.y += o.dy * OC.V * h; o.t -= h; if (o.t <= 0) { o.st = 2; o.t = OC.WIND; } break;
      case 2: o.t -= h; if (o.t <= 0) { o.st = 3; o.t = 0.25; } break;
      case 3: {
        o.x += o.dx * 5.6 * h; o.y += o.dy * 5.6 * h; o.t -= h;
        if (o.t > 0) break;
        const i = o.ti; o.e = (o.e + 1) % 64;
        if (i >= 0 && wd.ice[i]) { hurt(wd, i); hurt(wd, i); }
        for (const p of wd.pl) {
          if (p.out || Math.hypot(p.x - XW[i], p.y - YW[i]) > OC.HIT) continue;
          knock(p, o.dx, o.dy, 6.5, 0.6);
        }
        for (const b of wd.bs) if (bearOn(b) && Math.hypot(b.x - XW[i], b.y - YW[i]) < OC.HIT) { b.vx = o.dx * 3; b.vy = o.dy * 3; }
        o.st = 4; o.t = 1.6; break;
      }
      case 4: o.x -= o.dx * 2.2 * h; o.y -= o.dy * 2.2 * h; o.t -= h; if (o.t <= 0) { o.st = 0; o.t = (9 + Math.random() * 5) / (wd.sz === 2 ? 1.3 : 1); } break;
    }
  }
  function aliveList(wd) { const a = []; for (const p of wd.pl) if (!p.out) a.push(p); return a; }
  function sealStep(wd, h) {
    if (!wd.sl.length) return;
    const P = wd.pl;
    for (const s of wd.sl) {
      if (s.st === 1) { s.t -= h; if (s.t <= 0) { s.st = 2; s.on = 0; s.hm = 0; s.d = 0; s.e = (s.e + 1) % 64; } }
      else if (s.st === 2) {
        const v = 6.2; s.x += s.dx * v * h; s.y += s.dy * v * h; s.d += v * h;
        const oi = onIce(wd, s.x, s.y);
        if (oi) s.on = 1;
        if ((s.on && !oi) || s.d > 40) { s.st = 0; s.e2 = (s.e2 + 1) % 64; continue; }
        for (let k = 0; k < P.length; k++) {
          const p = P[k]; if (p.out || (s.hm & (1 << k))) continue;
          const dx = p.x - s.x, dy = p.y - s.y;
          if (dx * dx + dy * dy > 0.8 * 0.8) continue;
          s.hm |= 1 << k;
          const side = dx * -s.dy + dy * s.dx >= 0 ? 1 : -1;
          let nx = s.dx * 0.55 - s.dy * side * 0.85, ny = s.dy * 0.55 + s.dx * side * 0.85; const nm = Math.hypot(nx, ny) || 1;
          knock(p, nx / nm, ny / nm, 6.4, 0.5);
        }
      }
    }
    wd.tSeal -= h;
    if (wd.tSeal > 0) return;
    wd.tSeal = (7 + Math.random() * 4) / (wd.sz === 2 ? 1.3 : 1);
    const s = wd.sl.find((q) => q.st === 0), al = aliveList(wd);
    if (!s || !al.length) return;
    const q = al[Math.floor(Math.random() * al.length)];
    let sx = 0, sy = 0, dx = 1, dy = 0, ok = false;
    if (wd.holes.length && Math.random() < 0.45) {
      let bh = -1, bd = 7; for (const i of wd.holes) { const d = Math.hypot(XW[i] - q.x, YW[i] - q.y); if (d > 1.2 && d < bd) { bd = d; bh = i; } }
      if (bh >= 0) { sx = XW[bh]; sy = YW[bh]; dx = (q.x - sx) / bd; dy = (q.y - sy) / bd; ok = true; }
    }
    if (!ok) {
      const a = Math.random() * Math.PI * 2; dx = Math.cos(a); dy = Math.sin(a);
      let x = q.x, y = q.y, water = 0;
      for (let k = 0; k < 70 && water < 2; k++) { x -= dx * 0.5; y -= dy * 0.5; water = onIce(wd, x, y) ? 0 : water + 1; }
      sx = x; sy = y;
    }
    s.st = 1; s.t = 1.3; s.x = sx; s.y = sy; s.dx = dx; s.dy = dy;
  }
  /* ----- a rolling iceberg: telegraphed lane, then it bulldozes across, cracking the ice under it ----- */
  function bergStep(wd, h) {
    if (!wd.gm.berg) return;
    const ib = wd.ib, B = wd.bb, M = 2.2;
    const inside = (x, y) => x > B.x0 - M && x < B.x1 + M && y > B.y0 - M && y < B.y1 + M;
    if (ib.st === 0) {
      wd.tBerg -= h; if (wd.tBerg > 0) return;
      wd.tBerg = 15 + Math.random() * 7 - wd.sz * 2;
      const al = aliveList(wd); if (!al.length) return;
      const q = al[Math.floor(Math.random() * al.length)], a = Math.random() * Math.PI * 2, dx = Math.cos(a), dy = Math.sin(a);
      let x = q.x, y = q.y, k = 0;
      while (k++ < 120 && inside(x, y)) { x -= dx * 0.5; y -= dy * 0.5; }
      let ex = x, ey = y, len = 0; k = 0;
      do { ex += dx * 0.5; ey += dy * 0.5; len += 0.5; } while (k++ < 240 && (len < 3 || inside(ex, ey)));
      Object.assign(ib, { st: 1, t: 2.2, x, y, dx, dy, len, d: 0, lt: -1, hm: 0 });
    } else if (ib.st === 1) { ib.t -= h; if (ib.t <= 0) ib.st = 2; }
    else if (ib.st === 2) {
      const v = 2.4; ib.x += ib.dx * v * h; ib.y += ib.dy * v * h; ib.d += v * h;
      const t = tileAt(ib.x, ib.y); if (t !== ib.lt) { ib.lt = t; if (t >= 0 && wd.ice[t]) hurt(wd, t); }
      const DP = RT.IR + RT.PR;
      wd.pl.forEach((p, k) => {
        if (p.out) return;
        const dx = p.x - ib.x, dy = p.y - ib.y, d = Math.hypot(dx, dy);
        if (d >= DP) return;
        const nx = d > 1e-3 ? dx / d : -ib.dy, ny = d > 1e-3 ? dy / d : ib.dx;
        p.x = ib.x + nx * DP; p.y = ib.y + ny * DP;
        if (!(ib.hm & (1 << k))) { ib.hm |= 1 << k; let kx = ib.dx * 0.75 + nx * 0.65, ky = ib.dy * 0.75 + ny * 0.65; const km = Math.hypot(kx, ky) || 1; knock(p, kx / km, ky / km, 5.2, 0.4); }
        else { const along = p.vx * ib.dx + p.vy * ib.dy; if (along < v) { p.vx += ib.dx * (v - along); p.vy += ib.dy * (v - along); } }
      });
      for (const b of wd.bs) {
        if (!bearOn(b)) continue;
        const dx = b.x - ib.x, dy = b.y - ib.y, d = Math.hypot(dx, dy), DD = RT.IR + RT.BR;
        if (d < DD) { const nx = d > 1e-3 ? dx / d : -ib.dy, ny = d > 1e-3 ? dy / d : ib.dx; b.x = ib.x + nx * DD; b.y = ib.y + ny * DD; }
      }
      if (ib.d >= ib.len) ib.st = 0;
    }
  }
  /* ----- geysers: bubbling warning, then a blast that throws nearby penguins outward ----- */
  function ventStep(wd, h) {
    for (const v of wd.vs) {
      if (v.st === 3) continue;
      if (!wd.ice[v.i]) { v.st = 3; continue; }
      v.t -= h;
      if (v.st === 2) { if (v.t <= 0) { v.st = 0; v.t = 6.5 + Math.random() * 4.5; } continue; }
      if (v.st === 0 && v.t <= 1.5) v.st = 1;
      if (v.st === 1 && v.t <= 0) {
        v.st = 2; v.t = 0.7; v.e = (v.e + 1) % 64;
        const x = XW[v.i], y = YW[v.i];
        for (const p of wd.pl) {
          if (p.out) continue;
          let dx = p.x - x, dy = p.y - y, d = Math.hypot(dx, dy);
          if (d >= 1.35) continue;
          if (d < 0.08) { const a = Math.random() * Math.PI * 2; dx = Math.cos(a); dy = Math.sin(a); d = 1; }
          knock(p, dx / d, dy / d, 7.2, 0.55);
        }
        for (const b of wd.bs) if (bearOn(b) && Math.hypot(b.x - x, b.y - y) < 1.7) { b.st = 4; b.t = 1.2; b.vx = b.vy = 0; }
        hurt(wd, v.i);
      }
    }
  }
  /* ----- fishing holes: fish jump out onto the ice; eat one for 5 s of 힘 (faster, quick belly bumps, harder to push) ----- */
  function fishStep(wd, h) {
    if (!wd.gm.fish) return;
    for (let j = wd.fs.length - 1; j >= 0; j--) {
      const f = wd.fs[j];
      if (f.t > 0) { f.t -= h; continue; }
      f.life -= h;
      const ti = tileAt(f.x, f.y);
      if (f.life <= 0 || ti < 0 || !wd.ice[ti]) { wd.fs.splice(j, 1); continue; }
      for (const p of wd.pl) {
        if (p.out || (p.x - f.x) * (p.x - f.x) + (p.y - f.y) * (p.y - f.y) > 0.62 * 0.62) continue;
        p.pw = RT.PWT; p.cd = 0; p.fe = (p.fe + 1) % 64; wd.fs.splice(j, 1); break;
      }
    }
    wd.tFish -= h;
    if (wd.tFish > 0) return;
    wd.tFish = 4 + Math.random() * 3;
    if (wd.fs.length >= [2, 3, 4][wd.sz]) return;
    let src = -1;
    if (wd.holes.length) src = wd.holes[Math.floor(Math.random() * wd.holes.length)];
    else {
      const edge = []; for (let i = 0; i < N; i++) if (wd.ice[i] && waterN(wd, i)) edge.push(i);
      if (!edge.length) return;
      const e = edge[Math.floor(Math.random() * edge.length)];
      for (let d = 0; d < 6; d++) { const n = NB[e * 6 + d]; if (n >= 0 && !wd.ice[n]) { src = n; break; } }
    }
    if (src < 0) return;
    const land = [];
    for (let i = 0; i < N; i++) if (wd.ice[i] >= 2 && Math.hypot(XW[i] - XW[src], YW[i] - YW[src]) < 3.3) land.push(i);
    if (!land.length) return;
    const t = land[Math.floor(Math.random() * land.length)];
    wd.fs.push({ x: XW[t] + (Math.random() - 0.5) * 0.5, y: YW[t] + (Math.random() - 0.5) * 0.4, sx: XW[src], sy: YW[src], t: 0.7, life: 13 });
  }
  /* ----- weather: wind gusts (shove everyone one way) and snowstorms (low visibility + gentle drift) ----- */
  function weatherStep(wd, h) {
    const w = wd.wn;
    if (wd.gm.wind) {
      w.t -= h;
      if (w.st === 0 && w.t <= 0) { const a = Math.floor(Math.random() * 8) * Math.PI / 4; w.dx = Math.cos(a); w.dy = Math.sin(a); w.st = 1; w.t = 1.6; }
      else if (w.st === 1 && w.t <= 0) { w.st = 2; w.t = 1.8; }
      else if (w.st === 2 && w.t <= 0) { w.st = 0; w.t = 8 + Math.random() * 5; }
    }
    const s = wd.sn;
    if (wd.gm.storm) {
      s.t -= h;
      if (s.st === 0 && s.t <= 0) { const a = Math.random() * Math.PI * 2; s.dx = Math.cos(a); s.dy = Math.sin(a); s.st = 1; s.t = 2; }
      else if (s.st === 1 && s.t <= 0) { s.st = 2; s.t = 9; }
      else if (s.st === 2 && s.t <= 0) { s.st = 0; s.t = 16 + Math.random() * 8; }
    }
  }
  /* cracking: weight on a tile wears it down one level per LVLT seconds (moving penguins press less, the bear much more) */
  const touched = [];
  function stress(wd, h) {
    touched.length = 0;
    const melting = wd.t >= wd.meltAt;
    for (const p of wd.pl) {
      if (p.out) continue;
      const t = tileAt(p.x, p.y);
      if (t < 0 || !wd.ice[t]) { const f = onFloe(wd, p.x, p.y); if (f) { f.hp -= h * 0.6; if (f.hp <= 0) { f.hp = 0; f.rs = 7; wd.ch++; } } continue; }
      if (wd.sp[t] === SP_R && !melting) continue;
      wd.acc[t] += h * (Math.hypot(p.vx, p.vy) < 0.9 ? 1 : RT.MOVE) * (wd.sp[t] === SP_K ? 0.5 : 1); touched.push(t);
    }
    for (const f of wd.fl) if (f.hp > 0 && f.hp < RT.FLOEHP) f.hp = Math.min(RT.FLOEHP, f.hp + h * 0.12);
    for (const b of wd.bs) { if (!bearOn(b)) continue; const t = tileAt(b.x, b.y); if (t >= 0 && wd.ice[t] && (wd.sp[t] !== SP_R || melting)) { wd.acc[t] += h * RT.BEARST; touched.push(t); } }
    if (wd.cq.length) {
      const q = wd.cq; wd.cq = [];
      for (let k = 0; k < q.length; k += 2) { if (q[k + 1] <= wd.t) hurt(wd, q[k]); else wd.cq.push(q[k], q[k + 1]); }
    }
    if (melting) { // the sea warms up: edge tiles melt, faster and faster (bigger maps melt more at once)
      wd.melt -= h * MELTK[wd.sz];
      let guard = 0;
      while (wd.melt <= 0 && guard++ < 8) {
        wd.melt += Math.max(0.35, 1.4 - (wd.t - wd.meltAt) * 0.012);
        // 가장자리(가운데서 먼 물가 칸)부터 골라 먼저 예고하고, MELTW초 뒤에 녹인다
        const edge = []; for (let i = 0; i < N; i++) if (wd.ice[i] && !wd.mk[i] && waterN(wd, i)) edge.push([Math.hypot(XW[i] - wd.cx, YW[i] - wd.cy) + Math.random() * 1.2, i]);
        if (edge.length) { edge.sort((a, b) => b[0] - a[0]); const i = edge[Math.floor(Math.random() * Math.min(4, edge.length))][1]; wd.mk[i] = 1; wd.mw.push({ i, at: wd.t + MELTW }); }
      }
    }
    if (wd.mw.length) {
      const keep = [];
      for (const m of wd.mw) {
        if (!wd.ice[m.i]) { wd.mk[m.i] = 0; continue; }
        if (m.at <= wd.t) { let g = 0; while (wd.ice[m.i] && g++ < 5) hurt(wd, m.i); wd.mk[m.i] = 0; } else keep.push(m);
      }
      wd.mw = keep;
    }
    for (const t of touched) {
      while (wd.acc[t] >= RT.LVLT && wd.ice[t] > 0) { const a = wd.acc[t] - RT.LVLT, b0 = wd.ice[t]; hurt(wd, t); wd.acc[t] = a; if (wd.ice[t] === b0) { wd.acc[t] = 0; break; } }
    }
  }
  function sinkRT(wd) {
    const { comp, sizes } = comps(wd.ice);
    if (sizes.length > 1) {
      const mx = Math.max.apply(null, sizes);
      for (let i = 0; i < N; i++) if (comp[i] >= 0 && sizes[comp[i]] < mx) { wd.ice[i] = 0; wd.acc[i] = 0; wd.ch++; }
    }
    iceBB(wd);
  }
  function stepWorld(wd, h, inp) {
    if (wd.res) return;
    wd.t += h; wd.brk = 0;
    if (wd.fl.length) floeStep(wd, h);
    weatherStep(wd, h);
    const P = wd.pl;
    for (let k = 0; k < P.length; k++) if (!P[k].out) movePeng(wd, P[k], inp ? inp[k] : null, h);
    for (const b of wd.bs) bearStep(wd, b, h);
    sealStep(wd, h); orcaStep(wd, h); bergStep(wd, h); if (wd.vs.length) ventStep(wd, h); fishStep(wd, h);
    collide(wd);
    stress(wd, h);
    if (wd.brk) sinkRT(wd);
    for (const b of wd.bs) if (bearOn(b) && !onTile(wd, b.x, b.y)) { b.st = 5; b.t = RT.BACK; b.vx = b.vy = 0; }
    let fell = 0;
    for (let k = 0; k < P.length; k++) {
      const p = P[k]; if (p.out) continue;
      if (!onIce(wd, p.x, p.y)) { p.out = 1; p.ot = wd.t; fell++; wd.dead[k] = -1; }
    }
    if (fell) { wd.ord++; for (let k = 0; k < P.length; k++) if (wd.dead[k] === -1) wd.dead[k] = wd.ord; }
    const alive = []; for (let k = 0; k < P.length; k++) if (!P[k].out) alive.push(k);
    if (oneLeft(wd, alive) && P.length > 1) {
      let w = alive;
      if (!w.length) { w = []; for (let k = 0; k < P.length; k++) if (wd.dead[k] === wd.ord) w.push(k); }
      wd.res = { w };
    } else if (wd.t >= RT.CAP || (P.length === 1 && !alive.length)) wd.res = { w: alive, cap: alive.length > 1 ? 1 : 0 };
  }
  /* ----- host → guests snapshot (compact; well under the 4 KiB hostSend slot even with 8 penguins and 2 bears) ----- */
  const i100 = (v) => Math.round(v * 100);
  function encodeW(wd, extra) {
    const Pp = [];
    for (const p of wd.pl) Pp.push(i100(p.x), i100(p.y), i100(p.vx), i100(p.vy), (p.out ? 1 : 0) | (p.dash > 0 ? 2 : 0) | (p.stun > 0 ? 4 : 0) | (p.pw > 0 ? 8 : 0), p.hc, p.dn, p.fe);
    const B = [];
    for (const b of wd.bs) B.push(b.st, i100(b.x), i100(b.y), i100(b.dx), i100(b.dy), b.age > RT.ANGRYT ? 1 : 0, i100(b.wx), i100(b.wy), b.sw, b.hit, Math.round(b.t * 10), b.tgt);
    const o = Object.assign({ t: Math.round(wd.t * 10), I: wd.ice.join(''), P: Pp, B }, extra || {});
    if (wd.fl.length) { o.F = []; for (const f of wd.fl) o.F.push(i100(f.x), i100(f.y), Math.round(f.hp * 10)); }
    if (wd.sl.length) { o.S = []; for (const s of wd.sl) o.S.push(s.st, i100(s.x), i100(s.y), i100(s.dx), i100(s.dy), s.e, s.e2); }
    if (wd.oc) { const q = wd.oc; o.O = [q.st, i100(q.x), i100(q.y), i100(q.dx), i100(q.dy), q.ti, q.e]; }
    if (wd.gm.berg) { const ib = wd.ib; o.K = [ib.st, i100(ib.x), i100(ib.y), i100(ib.dx), i100(ib.dy), i100(ib.len), i100(ib.d)]; }
    if (wd.vs.length) { o.V = []; for (const v of wd.vs) o.V.push(v.st, v.e); }
    if (wd.gm.fish) { o.Fi = []; for (const f of wd.fs) o.Fi.push(i100(f.x), i100(f.y), i100(f.sx), i100(f.sy), Math.round(f.t * 10)); }
    if (wd.mw.length) o.Mw = wd.mw.map((m) => m.i);
    if (wd.gm.wind) o.Wn = [wd.wn.st, i100(wd.wn.dx), i100(wd.wn.dy)];
    if (wd.gm.storm) o.Sn = [wd.sn.st, i100(wd.sn.dx), i100(wd.sn.dy)];
    return o;
  }
  /* guests: copy the gimmick entities out of a snapshot (penguins are interpolated by the view) */
  function decodeGimmicks(wd, hs, now) {
    const num = (v) => (isFinite(+v) ? +v : 0);
    if (Array.isArray(hs.F)) wd.fl.forEach((f, j) => {
      const o = j * 3; if (o + 2 >= hs.F.length) return;
      const nx = num(hs.F[o]) / 100, ny = num(hs.F[o + 1]) / 100, hp = num(hs.F[o + 2]) / 10;
      if (f.nat) { const dt = Math.max(0.03, (now - f.nat) / 1000); if (Math.abs(nx - f.nx) < 2) { f.vx = (nx - f.nx) / dt; f.vy = (ny - f.ny) / dt; } else { f.vx = 1; f.vy = 0; f.x = nx; f.y = ny; } }
      if (hp > 0 && f.hp <= 0) { f.x = nx; f.y = ny; wd.ch++; }
      if (hp <= 0 && f.hp > 0) wd.ch++;
      f.nx = nx; f.ny = ny; f.nat = now; f.hp = hp;
    });
    if (Array.isArray(hs.S)) wd.sl.forEach((s, j) => {
      const o = j * 7; if (o + 6 >= hs.S.length) return;
      const ns = num(hs.S[o]) | 0, nx = num(hs.S[o + 1]) / 100, ny = num(hs.S[o + 2]) / 100;
      if (ns !== s.st || Math.hypot(nx - s.x, ny - s.y) > 2) { s.x = nx; s.y = ny; }
      s.st = ns; s.nx = nx; s.ny = ny; s.dx = num(hs.S[o + 3]) / 100; s.dy = num(hs.S[o + 4]) / 100; s.e = num(hs.S[o + 5]) | 0; s.e2 = num(hs.S[o + 6]) | 0;
    });
    if (Array.isArray(hs.O) && wd.oc && hs.O.length >= 7) {
      const q = wd.oc, ns = num(hs.O[0]) | 0, nx = num(hs.O[1]) / 100, ny = num(hs.O[2]) / 100;
      if (ns !== q.st || Math.hypot(nx - q.x, ny - q.y) > 2) { q.x = nx; q.y = ny; }
      q.st = ns; q.nx = nx; q.ny = ny; q.dx = num(hs.O[3]) / 100; q.dy = num(hs.O[4]) / 100; q.ti = num(hs.O[5]) | 0; q.e = num(hs.O[6]) | 0;
    }
    if (Array.isArray(hs.K)) {
      const ib = wd.ib, ns = num(hs.K[0]) | 0, nx = num(hs.K[1]) / 100, ny = num(hs.K[2]) / 100;
      if (ns !== ib.st || Math.hypot(nx - ib.x, ny - ib.y) > 2) { ib.x = nx; ib.y = ny; }
      ib.st = ns; ib.nx = nx; ib.ny = ny; ib.dx = num(hs.K[3]) / 100; ib.dy = num(hs.K[4]) / 100; ib.len = num(hs.K[5]) / 100; ib.d = num(hs.K[6]) / 100;
    }
    if (Array.isArray(hs.V)) wd.vs.forEach((v, j) => { if (j * 2 + 1 < hs.V.length) { v.st = num(hs.V[j * 2]) | 0; v.e = num(hs.V[j * 2 + 1]) | 0; } });
    if (Array.isArray(hs.Fi)) {
      wd.fs.length = 0;
      for (let o = 0; o + 4 < hs.Fi.length; o += 5) wd.fs.push({ x: num(hs.Fi[o]) / 100, y: num(hs.Fi[o + 1]) / 100, sx: num(hs.Fi[o + 2]) / 100, sy: num(hs.Fi[o + 3]) / 100, t: num(hs.Fi[o + 4]) / 10, life: 9 });
    }
    wd.mk.fill(0); wd.mw = [];
    if (Array.isArray(hs.Mw)) for (const v of hs.Mw) { const i = num(v) | 0; if (i >= 0 && i < N) { wd.mk[i] = 1; wd.mw.push({ i, at: 0 }); } }
    if (Array.isArray(hs.Wn)) { wd.wn.st = num(hs.Wn[0]) | 0; wd.wn.dx = num(hs.Wn[1]) / 100; wd.wn.dy = num(hs.Wn[2]) / 100; }
    if (Array.isArray(hs.Sn)) { wd.sn.st = num(hs.Sn[0]) | 0; wd.sn.dx = num(hs.Sn[1]) / 100; wd.sn.dy = num(hs.Sn[2]) / 100; }
  }
  function guestGimmickStep(wd, rdt) { // smooth the mirrored entities between snapshots
    const k = 1 - Math.exp(-rdt * 10);
    for (const f of wd.fl) if (isFinite(f.nx)) { f.x += (f.nx + f.vx * 0.05 - f.x) * k; f.y += (f.ny + f.vy * 0.05 - f.y) * k; }
    for (const s of wd.sl) if (s.st === 2) { s.x += s.dx * 6.2 * rdt; s.y += s.dy * 6.2 * rdt; if (isFinite(s.nx)) { s.x += (s.nx - s.x) * k * 0.5; s.y += (s.ny - s.y) * k * 0.5; } }
    const q = wd.oc; if (q && isFinite(q.nx)) { const v = q.st === 1 ? OC.V : q.st === 3 ? 5.6 : q.st === 4 ? -2.2 : 0; q.x += q.dx * v * rdt; q.y += q.dy * v * rdt; q.x += (q.nx - q.x) * k * 0.5; q.y += (q.ny - q.y) * k * 0.5; }
    const ib = wd.ib; if (ib.st === 2) { ib.x += ib.dx * 2.4 * rdt; ib.y += ib.dy * 2.4 * rdt; if (isFinite(ib.nx)) { ib.x += (ib.nx - ib.x) * k * 0.5; ib.y += (ib.ny - ib.y) * k * 0.5; } }
    for (const f of wd.fs) if (f.t > 0) f.t = Math.max(0, f.t - rdt);
  }

  /* ----- realtime AI: pick a safe tile to stand on, walk there over the ice, belly-bump rivals near the water,
     dodge bears, seals, icebergs and geysers, grab power fish ----- */
  const REACT = [0, 0.55, 0.3, 0.14], DEPTH = [0, 2, 3, 4];
  const aDist = new Int8Array(N), aPrev = new Int16Array(N);
  function laneHit(x, y, ox, oy, dx, dy, w) { const rx = x - ox, ry = y - oy; return rx * dx + ry * dy > -1 && Math.abs(rx * dy - ry * dx) < w; }
  function hazard(wd, t, lv) {
    let sc = 0; const x = XW[t], y = YW[t], sp = wd.sp[t];
    if (wd.mk[t]) sc -= lv === 1 ? 2 : 8; // 녹기 직전 칸
    else if (lv > 1 && wd.t >= wd.meltAt) { for (let d = 0; d < 6; d++) { const n = NB[t * 6 + d]; if (n >= 0 && wd.mk[n]) { sc -= 1.2; break; } } }
    if (lv > 1) {
      if (sp === SP_G) sc -= waterN(wd, t) ? 2.5 : 0.8;
      if (sp === SP_B) sc -= lv === 3 ? 1.6 : 0.8;
      if (sp === SP_R && wd.t < wd.meltAt) sc += 1.4;
      if (sp === SP_K) sc += 0.8;
      if (sp === SP_N) sc -= 0.5;
    }
    for (const v of wd.vs) if (v.st <= 1) { const d = Math.hypot(XW[v.i] - x, YW[v.i] - y); if (d < 1.55 && (v.st === 1 || (lv === 3 && v.t < 3.2))) sc -= lv === 1 ? 1.5 : 6; }
    const ib = wd.ib; if ((ib.st === 1 || ib.st === 2) && laneHit(x, y, ib.x, ib.y, ib.dx, ib.dy, RT.IR + 0.9)) sc -= lv === 1 ? 2 : 7;
    for (const s of wd.sl) if ((s.st === 1 || s.st === 2) && laneHit(x, y, s.x, s.y, s.dx, s.dy, 1.0)) sc -= lv === 1 ? 1.5 : 5;
    const oq = wd.oc; if (oq && oq.st >= 1 && oq.st <= 3 && oq.ti >= 0 && Math.hypot(XW[oq.ti] - x, YW[oq.ti] - y) < 1.7) sc -= lv === 1 ? 1.5 : 7;
    for (const f of wd.fs) if (f.t <= 0 && Math.hypot(f.x - x, f.y - y) < 0.9) sc += [0, 1.2, 2.6, 3.4][lv];
    const w = wd.wn; if ((w.st === 1 || w.st === 2) && lv > 1 && !onTile(wd, x + w.dx * 1.8, y + w.dy * 1.8)) sc -= lv === 3 ? 3.5 : 1.5;
    return sc;
  }
  function aiPlan(wd, k, mem, lv) {
    const p = wd.pl[k], me = tileAt(p.x, p.y);
    mem.path = []; mem.goal = me; mem.dash = null;
    if (me < 0 || !wd.ice[me]) { // on a floe (or about to slip): head for the closest solid ice
      let best = -1, bd = 1e9;
      for (let i = 0; i < N; i++) if (wd.ice[i] >= 2) { const d = (XW[i] - p.x) * (XW[i] - p.x) + (YW[i] - p.y) * (YW[i] - p.y) + (wd.sp[i] === SP_H ? 9 : 0); if (d < bd) { bd = d; best = i; } }
      mem.goal = best; mem.nz = 0; return;
    }
    const dist = aDist, prev = aPrev, list = [me];
    dist.fill(-1); dist[me] = 0; prev[me] = -1;
    for (let qi = 0; qi < list.length; qi++) {
      const c = list[qi]; if (dist[c] >= DEPTH[lv]) continue;
      for (let d = 0; d < 6; d++) { const t = NB[c * 6 + d]; if (t < 0 || dist[t] >= 0 || !wd.ice[t]) continue; dist[t] = dist[c] + 1; prev[t] = c; list.push(t); }
    }
    const storm = wd.sn.st === 2, noise = [0, 3.2, 0.8, 0.15][lv] * (storm ? [1, 2, 1.6, 1.2][lv] : 1);
    let best = me, bs = -1e9;
    for (const t of list) {
      const hp = wd.ice[t] - wd.acc[t] / RT.LVLT, wn = waterN(wd, t);
      let sc = hp * 3 - wn * (lv === 1 ? 0.5 : 1.5) - dist[t] * 0.35;
      if (hp < 1.3) sc -= lv === 1 ? 1 : 6;
      if (t === me) sc -= 0.6;
      for (const b of wd.bs) {
        if (bearOn(b)) { const db = Math.hypot(XW[t] - b.x, YW[t] - b.y); sc += Math.min(db, 6) * (lv === 1 ? 0.25 : 0.8); if (db < 2.4 && lv > 1) sc -= 4; }
        else if (b.st === 1 && lv > 1 && Math.hypot(XW[t] - b.wx, YW[t] - b.wy) < 2.4) sc -= 3;
      }
      if (lv > 1) for (let o = 0; o < wd.pl.length; o++) {
        const q = wd.pl[o]; if (o === k || q.out) continue;
        const d = Math.hypot(XW[t] - q.x, YW[t] - q.y);
        if (mate(wd, k, o)) { if (d < 1.1) sc -= 0.8; continue; } // 팀원 옆에 붙지 않기
        if (d < 1.9 && wn > 0) sc -= 1.2 * wn; // don't hang around the edge next to a rival
        const ot = tileAt(q.x, q.y);
        if (ot >= 0 && wd.ice[ot] && waterN(wd, ot) >= 2 && d > 1.2 && d < 2.4 && wn === 0) sc += lv === 3 ? 2.2 : 0.9; // stalk a rival on the edge
        if (d < 2.9 && d > 0.3 && q.cd < 0.4) { // could that rival bump me into the water from here?
          const ux = (XW[t] - q.x) / d, uy = (YW[t] - q.y) / d;
          if (!onIce(wd, XW[t] + ux * 1.3, YW[t] + uy * 1.3) || !onIce(wd, XW[t] + ux * 2.1, YW[t] + uy * 2.1)) sc -= lv === 3 ? 4.5 : 1.5;
        }
      }
      sc += hazard(wd, t, lv);
      sc += Math.random() * noise;
      if (sc > bs) { bs = sc; best = t; }
    }
    mem.goal = best;
    for (let c = best; c !== me && c >= 0; c = prev[c]) mem.path.unshift(c);
    mem.nz = lv === 1 ? (Math.random() - 0.5) * 0.6 : lv === 2 ? (Math.random() - 0.5) * 0.2 : 0;
    if (p.cd > 0 || p.stun > 0) return;
    for (let o = 0; o < wd.pl.length; o++) {
      const q = wd.pl[o]; if (o === k || q.out || mate(wd, k, o)) continue;
      const lead = lv === 3 ? 0.15 : 0, qx = q.x + q.vx * lead, qy = q.y + q.vy * lead;
      const dx = qx - p.x, dy = qy - p.y, d = Math.hypot(dx, dy);
      if (d > (lv === 3 ? 2.7 : 2.3) || d < 0.5) continue;
      const ux = dx / d, uy = dy / d;
      const edge = !onIce(wd, q.x + ux * 1.2, q.y + uy * 1.2) || !onIce(wd, q.x + ux * 2.1, q.y + uy * 2.1);
      let clear = true; for (let f = 0.4; f < d; f += 0.4) if (!onIce(wd, p.x + ux * f, p.y + uy * f)) clear = false;
      const pr = edge ? [0, 0.22, 0.55, 0.9][lv] * (p.pw > 0 ? 1.2 : 1) : [0, 0.06, 0.03, 0][lv];
      if (wd.tm && lv > 1) for (let m2 = 0; m2 < wd.pl.length; m2++) { const r2 = wd.pl[m2]; if (mate(wd, k, m2) && !r2.out && laneHit(r2.x, r2.y, p.x, p.y, ux, uy, 0.7) && Math.hypot(r2.x - p.x, r2.y - p.y) < d + 1.5) clear = false; }
      if ((clear || lv === 1) && wd.t > 2.5 && Math.random() < pr) { mem.dash = [ux, uy]; break; }
    }
  }
  function sidestep(wd, p, dx, dy, out) { // pick the side (perpendicular to dx,dy) with the better footing
    let bx = 0, by = 0, bv = -1e9;
    for (const sgn of [-1, 1]) {
      const vx = -dy * sgn, vy = dx * sgn, t = tileAt(p.x + vx * 1.3, p.y + vy * 1.3);
      const v = t >= 0 && wd.ice[t] ? wd.ice[t] - waterN(wd, t) * 0.6 : -9;
      if (v > bv) { bv = v; bx = vx; by = vy; }
    }
    out.ax = bx; out.ay = by; return out;
  }
  function aiThink(wd, k, mem, lv, h) {
    const p = wd.pl[k], out = mem.o || (mem.o = { ax: 0, ay: 0, dash: false });
    out.dash = false; out.ax = 0; out.ay = 0;
    if (p.out || wd.res) return out;
    // dodge a bear's wind-up
    for (const b of wd.bs) {
      if (b.st !== 3) continue;
      const id = b.k * 100 + b.sw;
      if (mem.sw !== id) { mem.sw = id; mem.dodge = Math.random() < [0, 0.3, 0.7, 0.95][lv]; mem.dd = [0, 0.3, 0.15, 0.04][lv]; }
      const rx = p.x - b.x, ry = p.y - b.y, d = Math.hypot(rx, ry) || 1;
      if (mem.dodge && d < RT.REACH + 0.7 && (rx * b.dx + ry * b.dy) / d > 0.15) {
        mem.dd -= h;
        if (mem.dd <= 0) {
          let bx = 0, by = 0, bv = -1e9;
          for (const sgn of [-1, 1]) for (const away of [0, 0.7]) {
            const vx = -b.dy * sgn * (1 - away) + rx / d * away, vy = b.dx * sgn * (1 - away) + ry / d * away, vm = Math.hypot(vx, vy) || 1;
            const tx = p.x + vx / vm * 1.3, ty = p.y + vy / vm * 1.3, t = tileAt(tx, ty);
            const v = t >= 0 && wd.ice[t] ? wd.ice[t] - waterN(wd, t) * 0.5 : -9;
            if (v > bv) { bv = v; bx = vx / vm; by = vy / vm; }
          }
          out.ax = bx; out.ay = by; return out;
        }
      }
    }
    // 범고래가 노리는 물가: 안쪽으로 물러남
    const oq = wd.oc;
    if (oq && (oq.st === 1 || oq.st === 2) && oq.ti >= 0 && Math.hypot(p.x - XW[oq.ti], p.y - YW[oq.ti]) < 1.6) {
      const id = 300 + oq.e; if (mem.ocId !== id) { mem.ocId = id; mem.ocOk = Math.random() < [0, 0.4, 0.8, 0.97][lv]; }
      if (mem.ocOk) { out.ax = oq.dx; out.ay = oq.dy; return out; }
    }
    // a seal or the iceberg is coming down my lane: better bots step aside
    const lanes = [];
    for (const s of wd.sl) if (s.st === 2 || (s.st === 1 && lv === 3)) lanes.push([s.x, s.y, s.dx, s.dy, 1.0, 100 + s.e]);
    const ib = wd.ib; if (ib.st === 2 || (ib.st === 1 && lv > 1)) lanes.push([ib.x, ib.y, ib.dx, ib.dy, RT.IR + 0.6, 200]);
    for (const L0 of lanes) {
      const rx = p.x - L0[0], ry = p.y - L0[1], al = rx * L0[2] + ry * L0[3];
      if (al < -0.5 || al > 6 || Math.abs(rx * L0[3] - ry * L0[2]) > L0[4]) continue;
      if (mem.laneId !== L0[5]) { mem.laneId = L0[5]; mem.laneOk = Math.random() < [0, 0.35, 0.75, 0.97][lv]; }
      if (mem.laneOk) return sidestep(wd, p, L0[2], L0[3], out);
    }
    // a rival is belly-sliding at me: better bots sidestep
    for (let o = 0; o < wd.pl.length; o++) {
      const q = wd.pl[o]; if (o === k || q.out || q.dash <= 0 || mate(wd, k, o)) continue;
      const rx = p.x - q.x, ry = p.y - q.y, d = Math.hypot(rx, ry), v = Math.hypot(q.vx, q.vy);
      if (d > 2.4 || v < 1 || (rx * q.vx + ry * q.vy) / (d * v) < 0.75) continue;
      const id = o * 100 + q.dn;
      if (mem.dodgeId !== id) { mem.dodgeId = id; mem.side = Math.random() < [0, 0, 0.3, 0.7][lv]; }
      if (!mem.side) continue;
      return sidestep(wd, p, q.vx / v, q.vy / v, out);
    }
    mem.t = (mem.t || 0) - h;
    if (mem.t <= 0 || !mem.path) { mem.t = REACT[lv] * (0.75 + Math.random() * 0.5) * (wd.sn.st === 2 && lv < 3 ? 1.5 : 1); aiPlan(wd, k, mem, lv); }
    if (mem.dash && p.cd <= 0 && p.stun <= 0) { out.dash = true; out.ax = mem.dash[0]; out.ay = mem.dash[1]; mem.dash = null; return out; }
    // sliding toward the water? brake hard (better bots notice sooner)
    const look = [0, 0.15, 0.3, 0.4][lv];
    if (Math.hypot(p.vx, p.vy) > 1.2 && !onIce(wd, p.x + p.vx * look, p.y + p.vy * look) && (lv > 1 || Math.random() < 0.5)) {
      const v = Math.hypot(p.vx, p.vy); out.ax = -p.vx / v; out.ay = -p.vy / v; return out;
    }
    const cur = tileAt(p.x, p.y);
    while (mem.path.length && (!wd.ice[mem.path[0]] || (cur === mem.path[0] && Math.hypot(XW[cur] - p.x, YW[cur] - p.y) < 0.55))) mem.path.shift();
    const tgt = mem.path.length ? mem.path[0] : mem.goal;
    if (tgt != null && tgt >= 0 && wd.ice[tgt]) {
      let dx = XW[tgt] - p.x, dy = YW[tgt] - p.y;
      const d = Math.hypot(dx, dy);
      if (mem.path.length || d >= 0.15) {
        const mag = mem.path.length ? 1 : Math.min(1, d / 0.6);
        const a = Math.atan2(dy, dx) + (mem.nz || 0);
        dx = Math.cos(a); dy = Math.sin(a);
        out.ax = dx * mag; out.ay = dy * mag;
      }
    }
    // lean into a gust (better bots brace harder)
    const w = wd.wn;
    if (w.st === 2) { const c = [0, 0.15, 0.6, 0.9][lv]; out.ax -= w.dx * c; out.ay -= w.dy * c; const m = Math.hypot(out.ax, out.ay); if (m > 1) { out.ax /= m; out.ay /= m; } }
    return out;
  }

  /* ---------- shared drawing ---------- */
  const TOPH = 50, BOTH = 82;
  /* turn mode: fit the starting ice (bb in world units, tile centres ±1) into the stage */
  function layoutG(w, h, bb) {
    const availW = w - 16, availH = h - TOPH - BOTH - 14;
    const bwU = bb.x1 - bb.x0 + 0.2, bhU = bb.y1 - bb.y0 + 0.5;
    const s = Math.max(6, Math.min(availW / bwU, availH / bhU));
    const bw = bwU * s, bh = bhU * s, x0 = (w - bw) / 2, y0 = TOPH + 7 + Math.max(0, (availH - bh) / 2);
    return { s, ox: x0 - (bb.x0 - 0.1) * s, oy: y0 - (bb.y0 - 0.1) * s, bw, bh, x0, y0 };
  }
  function bbOfIce(str) {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let i = 0; i < N; i++) if (str.charCodeAt(i) !== 48) { if (XW[i] < x0) x0 = XW[i]; if (XW[i] > x1) x1 = XW[i]; if (YW[i] < y0) y0 = YW[i]; if (YW[i] > y1) y1 = YW[i]; }
    if (x0 > x1) return { x0: X0 - 8, y0: Y0 - 10, x1: X0 + 8, y1: Y0 + 10 };
    return { x0: x0 - 1, y0: y0 - 1, x1: x1 + 1, y1: y1 + 1.3 };
  }
  function hexPath(c, x, y, r) { c.beginPath(); for (let k = 0; k < 6; k++) { const a = (Math.PI / 180) * (60 * k - 30); c.lineTo(x + r * Math.cos(a), y + r * Math.sin(a)); } c.closePath(); }
  function rnd(seed) { let t = seed * 9301 + 49297; return () => { t = (t * 9301 + 49297) % 233280; return t / 233280; }; }
  const TILE_COL = [ // side, rim, top gradient ×3 — per crack stage
    ['#4a7fa8', '#79aed3', '#ffffff', '#dff1fb', '#a9d4ef'],
    ['#4a7fa8', '#79aed3', '#fbfdff', '#d9ecf7', '#a3cbe5'],
    ['#5a7f99', '#7e9fb6', '#f2f6f8', '#cddbe4', '#a8bccb'],
    ['#48667c', '#68849a', '#dce4ea', '#aebfcb', '#879cad'],
  ];
  const ROCK_COL = [
    ['#4d5866', '#6f7c8a', '#c9d0d6', '#a7b1ba', '#87929d'],
    ['#4d5866', '#6f7c8a', '#c4cbd1', '#a2acb5', '#828d98'],
    ['#4a5461', '#69757f', '#b8c0c6', '#98a2ab', '#7b8590'],
    ['#434c57', '#626c76', '#a9b1b8', '#8a949c', '#707a84'],
  ];
  const THICK_COL = [
    ['#1f4f78', '#3d77a6', '#e4f2fb', '#9fcbea', '#5f9dcc'],
    ['#1f4f78', '#3d77a6', '#dcedf8', '#97c3e2', '#5893c0'],
    ['#24496a', '#456f93', '#d2e2ec', '#90b2c9', '#5f87a6'],
    ['#22425d', '#3f6482', '#c2d3de', '#7f9fb5', '#56778f'],
  ];
  /* marks for the mixed ice types (both modes): c/C cracked (C = sagging), k thick, s slippery, n snow */
  function drawTyMark(c, i, x, y, s, ch, lv) {
    const r = s * 0.95, rn = rnd(i * 5 + 3);
    if (ch === 'k') {
      hexPath(c, x, y, r * 0.72); c.lineWidth = Math.max(1.2, s * 0.08); c.strokeStyle = lv === 3 ? 'rgba(20,60,100,.55)' : 'rgba(20,60,100,.25)'; c.stroke();
      hexPath(c, x, y, r * 0.5); c.lineWidth = Math.max(1, s * 0.05); c.strokeStyle = 'rgba(255,255,255,.5)'; c.stroke();
    } else if (ch === 's') {
      c.save(); hexPath(c, x, y, r * 0.95); c.clip();
      c.fillStyle = 'rgba(110,200,255,.3)'; c.fillRect(x - r, y - r, 2 * r, 2 * r);
      c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineWidth = Math.max(1, s * 0.07); c.lineCap = 'round';
      for (let k = -1; k <= 1; k++) { c.beginPath(); c.moveTo(x - r * 0.5 + k * r * 0.45, y + r * 0.45); c.lineTo(x + r * 0.15 + k * r * 0.45, y - r * 0.45); c.stroke(); }
      c.restore();
    } else if (ch === 'n') {
      c.save(); hexPath(c, x, y, r * 0.95); c.clip();
      c.fillStyle = 'rgba(250,252,255,.92)';
      for (let k = 0; k < 5; k++) { c.beginPath(); c.ellipse(x + (rn() - 0.5) * r * 1.2, y + (rn() - 0.5) * r * 1.1, r * (0.3 + rn() * 0.22), r * (0.18 + rn() * 0.12), rn() * 3, 0, 7); c.fill(); }
      c.fillStyle = 'rgba(160,190,215,.5)';
      for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(x + (rn() - 0.5) * r * 1.1, y + (rn() - 0.5) * r, s * 0.04, 0, 7); c.fill(); }
      c.restore();
    } else if (ch === 'c' || ch === 'C') {
      hexPath(c, x, y, r * 0.8); c.setLineDash([Math.max(2, s * 0.14), Math.max(2, s * 0.1)]); c.lineWidth = Math.max(1.2, s * 0.07);
      c.strokeStyle = ch === 'C' ? 'rgba(238,106,85,.95)' : 'rgba(214,140,60,.85)'; c.stroke(); c.setLineDash([]);
      if (ch === 'C') { c.fillStyle = 'rgba(20,60,100,.28)'; hexPath(c, x, y + s * 0.05, r * 0.6); c.fill(); }
    }
  }
  const FLOE_COL = TILE_COL.map((p) => [p[0], '#8fd0ee', '#e9fbff', '#bfe9fa', '#8fcfee']);
  const CRACK_ORDER = [0, 3, 1, 4, 2, 5];
  /* one ice tile; cr = crack stage 0 (멀쩡) … 3 (곧 깨짐) */
  function drawTile(c, i, x, y, s, cr, alpha, pal) {
    pal = pal || TILE_COL;
    const r = s * 0.95, th = s * 0.24, P = pal[cr] || pal[0];
    c.globalAlpha = alpha == null ? 1 : alpha;
    hexPath(c, x, y + th, r); c.fillStyle = P[0]; c.fill();
    hexPath(c, x, y + th * 0.5, r); c.fillStyle = P[1]; c.fill();
    const g = c.createLinearGradient(x - r, y - r, x + r * 0.6, y + r);
    g.addColorStop(0, P[2]); g.addColorStop(0.5, P[3]); g.addColorStop(1, P[4]);
    hexPath(c, x, y, r); c.fillStyle = g; c.fill();
    c.lineWidth = Math.max(1, s * 0.05); c.strokeStyle = cr >= 3 ? 'rgba(255,255,255,.45)' : 'rgba(255,255,255,.75)'; c.stroke();
    c.fillStyle = cr >= 3 ? 'rgba(255,255,255,.3)' : 'rgba(255,255,255,.55)';
    c.beginPath(); c.ellipse(x - r * 0.32, y - r * 0.42, r * 0.34, r * 0.12, -0.5, 0, 7); c.fill();
    const rn = rnd(i + 7);
    c.fillStyle = 'rgba(120,170,205,.35)';
    for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(x + (rn() - 0.5) * r, y + (rn() - 0.3) * r * 0.9, s * 0.04 + rn() * s * 0.03, 0, 7); c.fill(); }
    if (cr > 0) {
      const ox = x + (rn() - 0.5) * r * 0.35, oy = y + (rn() - 0.5) * r * 0.35;
      c.lineCap = 'round'; c.lineJoin = 'round';
      const lines = [];
      for (let k = 0; k < 6; k++) {
        const a0 = (k / 6) * Math.PI * 2 + rn() * 0.8; const pts = [[ox, oy]];
        let px = ox, py = oy, a = a0;
        for (let j = 0; j < 3; j++) { a += (rn() - 0.5) * 0.9; const len = r * (0.22 + rn() * 0.12); px += Math.cos(a) * len; py += Math.sin(a) * len * 0.9; pts.push([px, py]); }
        lines.push(pts);
      }
      const nb = [0, 2, 4, 6][cr];
      if (cr >= 3) { c.fillStyle = 'rgba(20,50,80,.55)'; c.beginPath(); c.ellipse(ox, oy, r * 0.16, r * 0.1, 0.4, 0, 7); c.fill(); }
      for (const pass of [0, 1]) {
        c.strokeStyle = pass ? 'rgba(255,255,255,.85)' : cr >= 3 ? '#2c4f6c' : '#3f6a8c'; c.lineWidth = pass ? Math.max(0.6, s * 0.025) : Math.max(1.2, s * (cr >= 3 ? 0.075 : 0.06));
        for (let q = 0; q < nb; q++) {
          const pts = lines[CRACK_ORDER[q]];
          c.beginPath(); c.moveTo(pts[0][0] + pass * 0.8, pts[0][1] + pass * 0.8);
          for (let j = 1; j < pts.length; j++) { if (Math.hypot(pts[j][0] - x, pts[j][1] - y) > r * 0.9) break; c.lineTo(pts[j][0] + pass * 0.8, pts[j][1] + pass * 0.8); }
          c.stroke();
        }
      }
    }
    c.globalAlpha = 1;
  }
  /* realtime special tiles drawn on top of the ice */
  function drawTileSp(c, i, x, y, s, cr, spc, melt) {
    drawTile(c, i, x, y, s, cr, 1, spc === SP_R ? ROCK_COL : spc === SP_K ? THICK_COL : null);
    if (spc === SP_K) { drawTyMark(c, i, x, y, s, 'k', 3); return; }
    if (spc === SP_N) { drawTyMark(c, i, x, y, s, 'n', 2); return; }
    const r = s * 0.95, rn = rnd(i * 3 + 1);
    if (spc === SP_T) {
      c.fillStyle = 'rgba(150,215,250,.22)'; hexPath(c, x, y, r * 0.86); c.fill();
      hexPath(c, x, y, r * 0.74); c.setLineDash([Math.max(2, s * 0.16), Math.max(2, s * 0.12)]); c.lineWidth = Math.max(1, s * 0.06); c.strokeStyle = 'rgba(30,100,160,.75)'; c.stroke(); c.setLineDash([]);
    } else if (spc === SP_G) {
      c.save(); hexPath(c, x, y, r * 0.95); c.clip();
      c.fillStyle = 'rgba(110,200,255,.3)'; c.fillRect(x - r, y - r, 2 * r, 2 * r);
      c.strokeStyle = 'rgba(255,255,255,.85)'; c.lineWidth = Math.max(1, s * 0.07); c.lineCap = 'round';
      for (let k = -1; k <= 1; k++) { c.beginPath(); c.moveTo(x - r * 0.5 + k * r * 0.45, y + r * 0.45); c.lineTo(x + r * 0.15 + k * r * 0.45, y - r * 0.45); c.stroke(); }
      c.restore();
    } else if (spc === SP_B) {
      c.strokeStyle = 'rgba(122,59,42,.8)'; c.lineWidth = Math.max(1.2, s * 0.08); c.lineJoin = 'round';
      c.beginPath(); c.moveTo(x - r * 0.9, y);
      for (let k = 1; k <= 5; k++) c.lineTo(x - r * 0.9 + k * r * 0.36, y + (k % 2 ? -1 : 1) * r * (0.12 + rn() * 0.12));
      c.stroke();
      c.strokeStyle = 'rgba(255,230,210,.6)'; c.lineWidth = Math.max(0.6, s * 0.025); c.stroke();
    } else if (spc === SP_V) {
      c.fillStyle = 'rgba(140,175,200,.9)'; c.beginPath(); c.ellipse(x, y + r * 0.05, r * 0.5, r * 0.32, 0, 0, 7); c.fill();
      c.fillStyle = '#16304a'; c.beginPath(); c.ellipse(x, y + r * 0.05, r * 0.36, r * 0.22, 0, 0, 7); c.fill();
      c.fillStyle = 'rgba(120,210,255,.45)'; c.beginPath(); c.ellipse(x, y + r * 0.08, r * 0.2, r * 0.11, 0, 0, 7); c.fill();
    } else if (spc === SP_R && !melt) {
      c.fillStyle = 'rgba(70,80,92,.45)';
      for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(x + (rn() - 0.5) * r, y + (rn() - 0.5) * r * 0.8, s * (0.06 + rn() * 0.06), 0, 7); c.fill(); }
    }
  }
  function drawHole(c, x, y, s) { // fishing hole (water) with a little fish shadow
    c.fillStyle = 'rgba(4,22,42,.55)'; c.beginPath(); c.ellipse(x, y + s * 0.1, s * 0.62, s * 0.44, 0, 0, 7); c.fill();
    c.strokeStyle = 'rgba(210,240,255,.55)'; c.lineWidth = Math.max(1, s * 0.06); c.beginPath(); c.ellipse(x, y + s * 0.1, s * 0.62, s * 0.44, 0, 0, 7); c.stroke();
    c.fillStyle = 'rgba(242,163,58,.55)'; c.beginPath(); c.ellipse(x, y + s * 0.12, s * 0.2, s * 0.08, 0.3, 0, 7); c.fill();
    c.beginPath(); c.moveTo(x - s * 0.16, y + s * 0.07); c.lineTo(x - s * 0.32, y - s * 0.02); c.lineTo(x - s * 0.3, y + s * 0.16); c.closePath(); c.fill();
  }
  /* realtime: parlour background and a brass-rimmed pool filling the play area (the camera moves inside it) */
  function paintPool(c, w, h, A) {
    const bg = c.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, '#1d1728'); bg.addColorStop(1, '#120e19');
    c.fillStyle = bg; c.fillRect(0, 0, w, h);
    const rr = (x, y, ww, hh, r) => { c.beginPath(); if (c.roundRect) c.roundRect(x, y, ww, hh, r); else c.rect(x, y, ww, hh); };
    rr(A.x - 3, A.y - 3, A.w + 6, A.h + 6, 20); c.fillStyle = '#8a6a2c'; c.fill();
    rr(A.x - 1.5, A.y - 1.5, A.w + 3, A.h + 3, 19); c.fillStyle = '#e3ae45'; c.fill();
    rr(A.x, A.y, A.w, A.h, 18);
    const wg = c.createRadialGradient(A.x + A.w / 2, A.y + A.h * 0.45, 10, A.x + A.w / 2, A.y + A.h / 2, Math.max(A.w, A.h) * 0.75);
    wg.addColorStop(0, '#12406a'); wg.addColorStop(0.6, '#0b2a4a'); wg.addColorStop(1, '#061629');
    c.fillStyle = wg; c.fill();
    c.save(); rr(A.x, A.y, A.w, A.h, 18); c.clip();
    const rn = rnd(3);
    c.strokeStyle = 'rgba(140,200,255,.07)'; c.lineWidth = 1.2;
    for (let k = 0; k < 60; k++) { const x = A.x + rn() * A.w, y = A.y + rn() * A.h, l = 10 + rn() * 26; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + l / 2, y - 3, x + l, y); c.stroke(); }
    c.restore();
    rr(A.x, A.y, A.w, A.h, 18); c.lineWidth = 3; c.strokeStyle = 'rgba(0,0,0,.35)'; c.stroke();
  }
  /* parlour background, brass-rimmed pool and all ice tiles (cached by the views); crackOf(i) → −1 water, else 0..3 */
  function paintBoard(c, w, h, G, crackOf, ty, lvOf) {
    const bg = c.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, '#1d1728'); bg.addColorStop(1, '#120e19');
    c.fillStyle = bg; c.fillRect(0, 0, w, h);
    const px = Math.max(4, G.x0 - 8), py = G.y0 - 8, pw = Math.min(w - 8, G.bw + 16), ph = G.bh + 16;
    const rr = (x, y, ww, hh, r) => { c.beginPath(); if (c.roundRect) c.roundRect(x, y, ww, hh, r); else c.rect(x, y, ww, hh); };
    rr(px - 3, py - 3, pw + 6, ph + 6, 20); c.fillStyle = '#8a6a2c'; c.fill();
    rr(px - 1.5, py - 1.5, pw + 3, ph + 3, 19); c.fillStyle = '#e3ae45'; c.fill();
    rr(px, py, pw, ph, 18);
    const wg = c.createRadialGradient(w / 2, py + ph * 0.45, 10, w / 2, py + ph / 2, ph * 0.75);
    wg.addColorStop(0, '#12406a'); wg.addColorStop(0.6, '#0b2a4a'); wg.addColorStop(1, '#061629');
    c.fillStyle = wg; c.fill();
    c.save(); rr(px, py, pw, ph, 18); c.clip();
    const rn = rnd(3);
    c.strokeStyle = 'rgba(140,200,255,.07)'; c.lineWidth = 1.2;
    for (let k = 0; k < 50; k++) { const x = px + rn() * pw, y = py + rn() * ph, l = 10 + rn() * 26; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + l / 2, y - 3, x + l, y); c.stroke(); }
    for (let i = 0; i < N; i++) {
      if (crackOf(i) < 0) continue;
      c.fillStyle = 'rgba(0,10,25,.35)'; hexPath(c, G.ox + XW[i] * G.s + 2, G.oy + YW[i] * G.s + G.s * 0.4, G.s * 0.98); c.fill();
    }
    for (let i = 0; i < N; i++) {
      const cr = crackOf(i); if (cr < 0) continue;
      const x = G.ox + XW[i] * G.s, y = G.oy + YW[i] * G.s, ch = ty ? ty[i] : '.';
      drawTile(c, i, x, y, G.s, cr, 1, ch === 'k' && lvOf && lvOf(i) === 3 ? THICK_COL : null);
      if (ch && ch !== '.') drawTyMark(c, i, x, y, G.s, ch, lvOf ? lvOf(i) : 2);
    }
    c.restore();
    rr(px, py, pw, ph, 18); c.lineWidth = 3; c.strokeStyle = 'rgba(0,0,0,.35)'; c.stroke();
  }
  function drawPeng(c, x, y, colr, u, o) {
    o = o || {};
    c.save();
    c.globalAlpha = o.alpha == null ? 1 : o.alpha;
    c.translate(x, y);
    if (!o.noShadow) { c.fillStyle = 'rgba(0,20,40,.28)'; c.beginPath(); c.ellipse(0, 0, u * 0.85, u * 0.3, 0, 0, 7); c.fill(); }
    if (o.tc) { c.strokeStyle = o.tc; c.lineWidth = Math.max(2, u * 0.16); c.beginPath(); c.ellipse(0, 0, u * 1.0, u * 0.38, 0, 0, 7); c.stroke(); }
    c.rotate(o.tilt || 0);
    c.scale((o.face || 1) * (1 + (o.sq || 0)), 1 - (o.sq || 0));
    c.translate(0, -(o.lift || 0));
    c.fillStyle = '#f29a2e';
    c.beginPath(); c.ellipse(-u * 0.32, -u * 0.04, u * 0.3, u * 0.13, 0.1, 0, 7); c.fill();
    c.beginPath(); c.ellipse(u * 0.38, -u * 0.04, u * 0.3, u * 0.13, -0.1, 0, 7); c.fill();
    const fl = o.flap || 0;
    c.fillStyle = '#18202d';
    c.save(); c.translate(-u * 0.62, -u * 1.25); c.rotate(0.35 + fl); c.beginPath(); c.ellipse(0, u * 0.35, u * 0.16, u * 0.45, 0, 0, 7); c.fill(); c.restore();
    const bg = c.createLinearGradient(-u, -u * 2, u, 0); bg.addColorStop(0, '#34425a'); bg.addColorStop(1, '#151b26');
    c.fillStyle = bg; c.beginPath(); c.ellipse(0, -u * 0.98, u * 0.76, u * 0.98, 0, 0, 7); c.fill();
    c.fillStyle = '#f8f5ee'; c.beginPath(); c.ellipse(u * 0.16, -u * 0.86, u * 0.5, u * 0.76, 0, 0, 7); c.fill();
    c.fillStyle = bg; c.beginPath(); c.arc(u * 0.05, -u * 1.86, u * 0.6, 0, 7); c.fill();
    c.fillStyle = '#f8f5ee'; c.beginPath(); c.ellipse(u * 0.26, -u * 1.8, u * 0.36, u * 0.33, 0, 0, 7); c.fill();
    c.fillStyle = '#121212'; c.beginPath(); c.arc(u * 0.36, -u * 1.92, u * (o.dazed ? 0.06 : 0.1), 0, 7); c.fill();
    c.fillStyle = '#fff'; c.beginPath(); c.arc(u * 0.39, -u * 1.95, u * 0.035, 0, 7); c.fill();
    c.fillStyle = 'rgba(255,120,140,.45)'; c.beginPath(); c.arc(u * 0.3, -u * 1.68, u * 0.08, 0, 7); c.fill();
    c.fillStyle = '#f5a63a'; c.beginPath(); c.moveTo(u * 0.55, -u * 1.86); c.lineTo(u * 0.98, -u * 1.76); c.lineTo(u * 0.55, -u * 1.66); c.closePath(); c.fill();
    c.fillStyle = colr;
    c.beginPath(); if (c.roundRect) c.roundRect(-u * 0.62, -u * 1.42, u * 1.24, u * 0.27, u * 0.12); else c.rect(-u * 0.62, -u * 1.42, u * 1.24, u * 0.27); c.fill();
    c.save(); c.translate(-u * 0.5, -u * 1.3); c.rotate(0.35 + fl * 0.6); c.fillRect(-u * 0.12, 0, u * 0.24, u * 0.55); c.restore();
    c.fillStyle = 'rgba(255,255,255,.28)'; c.fillRect(-u * 0.6, -u * 1.38, u * 1.2, u * 0.06);
    c.fillStyle = colr; c.beginPath(); c.ellipse(u * 0.02, -u * 2.18, u * 0.56, u * 0.42, 0, Math.PI, 0); c.fill();
    c.fillStyle = 'rgba(0,0,0,.22)'; c.fillRect(-u * 0.56, -u * 2.24, u * 1.14, u * 0.14);
    c.fillStyle = '#fbfaf6'; c.beginPath(); c.arc(u * 0.02, -u * 2.64, u * 0.16, 0, 7); c.fill();
    c.fillStyle = '#1f2939';
    c.save(); c.translate(u * 0.5, -u * 1.25); c.rotate(-0.25 - fl); c.beginPath(); c.ellipse(0, u * 0.35, u * 0.14, u * 0.42, 0, 0, 7); c.fill(); c.restore();
    c.restore();
  }
  function drawBearC(c, x, y, u, o) {
    o = o || {};
    c.save(); c.globalAlpha = o.alpha == null ? 1 : o.alpha; c.translate(x, y);
    if (!o.noShadow) { c.fillStyle = 'rgba(0,20,40,.3)'; c.beginPath(); c.ellipse(0, 0, u * 1.25, u * 0.38, 0, 0, 7); c.fill(); }
    c.scale(o.face || 1, 1); c.rotate(o.tilt || 0); c.translate(0, -(o.lift || 0));
    const fur = c.createLinearGradient(0, -u * 2.2, 0, 0); fur.addColorStop(0, '#fbf8f0'); fur.addColorStop(1, '#d9cfbd');
    c.fillStyle = '#cfc4b0';
    for (const lx of [-0.75, 0.55]) { c.beginPath(); c.ellipse(u * lx, -u * 0.22, u * 0.26, u * 0.3, 0, 0, 7); c.fill(); }
    c.fillStyle = fur; c.beginPath(); c.ellipse(-u * 0.1, -u * 0.95, u * 1.15, u * 0.82, 0, 0, 7); c.fill();
    for (const lx of [-0.45, 0.85]) { c.beginPath(); c.ellipse(u * lx, -u * 0.25, u * 0.27, u * 0.32, 0, 0, 7); c.fill(); }
    const sw = o.swipe || 0;
    c.save(); c.translate(u * 0.9, -u * 1.1); c.rotate(-0.4 - sw * 1.6); c.fillStyle = fur;
    c.beginPath(); c.ellipse(u * 0.35, 0, u * 0.42, u * 0.24, 0, 0, 7); c.fill();
    c.fillStyle = '#2b2622'; for (let k = 0; k < 3; k++) { c.beginPath(); c.arc(u * 0.72, (k - 1) * u * 0.11, u * 0.045, 0, 7); c.fill(); }
    c.restore();
    c.fillStyle = fur;
    c.beginPath(); c.arc(u * 0.95, -u * 1.55, u * 0.58, 0, 7); c.fill();
    for (const ex of [0.6, 1.18]) { c.beginPath(); c.arc(u * ex, -u * 2.03, u * 0.17, 0, 7); c.fill(); c.fillStyle = '#d8b9a8'; c.beginPath(); c.arc(u * ex, -u * 2.03, u * 0.08, 0, 7); c.fill(); c.fillStyle = fur; }
    c.fillStyle = '#fffdf7'; c.beginPath(); c.ellipse(u * 1.32, -u * 1.42, u * 0.3, u * 0.22, 0, 0, 7); c.fill();
    c.fillStyle = '#1b1715'; c.beginPath(); c.ellipse(u * 1.56, -u * 1.5, u * 0.11, u * 0.08, 0, 0, 7); c.fill();
    c.beginPath(); c.arc(u * 1.08, -u * 1.7, u * 0.065, 0, 7); c.fill();
    if (o.angry) { c.strokeStyle = '#1b1715'; c.lineWidth = u * 0.07; c.beginPath(); c.moveTo(u * 0.92, -u * 1.86); c.lineTo(u * 1.2, -u * 1.78); c.stroke(); }
    c.strokeStyle = '#1b1715'; c.lineWidth = u * 0.05; c.beginPath(); c.moveTo(u * 1.38, -u * 1.33); c.quadraticCurveTo(u * 1.48, -u * 1.26, u * 1.58, -u * 1.34); c.stroke();
    c.restore();
  }
  function drawHatC(c, x, y, colr, u, t, k) {
    const b = Math.sin(t / 380 + k) * u * 0.08;
    c.save(); c.translate(x, y + b); c.rotate(Math.sin(t / 500 + k) * 0.2);
    c.fillStyle = 'rgba(160,210,255,.25)'; c.beginPath(); c.ellipse(0, u * 0.12, u * 0.75, u * 0.2, 0, 0, 7); c.fill();
    c.fillStyle = colr; c.beginPath(); c.ellipse(0, 0, u * 0.5, u * 0.38, 0, Math.PI, 0); c.fill();
    c.fillStyle = '#fbfaf6'; c.beginPath(); c.arc(0, -u * 0.42, u * 0.14, 0, 7); c.fill();
    c.restore();
  }
  function drawPawC(c, x, y, u, a, alpha) {
    c.save(); c.translate(x, y); c.rotate(a); c.globalAlpha = alpha; c.fillStyle = '#8a3a2e';
    c.beginPath(); c.ellipse(0, u * 0.1, u * 0.26, u * 0.2, 0, 0, 7); c.fill();
    for (let k = -1; k <= 1; k++) { c.beginPath(); c.arc(k * u * 0.17, -u * 0.18 - (k ? 0 : u * 0.05), u * 0.08, 0, 7); c.fill(); }
    c.restore();
  }
  function hexA(hex, a) {
    if (!/^#[0-9a-f]{6}$/i.test(hex)) return 'rgba(255,255,255,' + a + ')';
    const n = parseInt(hex.slice(1), 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a.toFixed(3) + ')';
  }
  function makeParts() {
    const a = [];
    const P = {
      list: a,
      clear() { a.length = 0; },
      burst(x, y, kind, n, s) {
        if (a.length > 360) return;
        for (let k = 0; k < n; k++) {
          const ang = Math.random() * Math.PI * 2, sp = (kind === 'shard' ? 1.2 : 1.6) * s * (0.6 + Math.random());
          a.push({ x, y, vx: Math.cos(ang) * sp, vy: -Math.abs(Math.sin(ang)) * sp * 1.4 - s * 0.6, g: s * 7, life: 0, max: 0.5 + Math.random() * 0.35, kind, r: s * (0.05 + Math.random() * 0.06), y0: y + s * 0.2 });
        }
      },
      ring(x, y, n, s) { for (let k = 0; k < n; k++) a.push({ x, y, life: -k * 0.16, max: 0.9, kind: 'ring', r: s * 0.2 }); },
      splash(x, y, big, s) { P.burst(x, y, 'drop', big ? 22 : 14, s); P.ring(x, y + s * 0.15, big ? 3 : 2, s); },
      step(dt) {
        for (let k = a.length - 1; k >= 0; k--) {
          const p = a[k]; p.life += dt;
          if (p.life >= p.max) { a.splice(k, 1); continue; }
          if (p.life < 0 || p.kind === 'ring') continue;
          p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt;
          if (p.y > p.y0 && p.vy > 0) { p.y = p.y0; p.vx *= 0.5; p.vy *= -0.25; }
        }
      },
      draw(c, s) {
        for (const p of a) {
          if (p.life < 0) continue;
          const f = p.life / p.max;
          if (p.kind === 'ring') {
            c.strokeStyle = 'rgba(190,230,255,' + (0.7 * (1 - f)).toFixed(3) + ')'; c.lineWidth = 2;
            c.beginPath(); c.ellipse(p.x, p.y, p.r + f * s * 0.9, (p.r + f * s * 0.9) * 0.4, 0, 0, 7); c.stroke();
          } else if (p.kind === 'shard') {
            c.fillStyle = 'rgba(240,250,255,' + (1 - f * 0.8).toFixed(3) + ')';
            c.save(); c.translate(p.x, p.y); c.rotate(p.life * 9); c.beginPath(); c.moveTo(-p.r, p.r); c.lineTo(p.r * 1.2, p.r * 0.6); c.lineTo(0, -p.r * 1.3); c.closePath(); c.fill(); c.restore();
          } else {
            c.fillStyle = 'rgba(150,215,255,' + (0.9 * (1 - f)).toFixed(3) + ')';
            c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill();
          }
        }
      },
    };
    return P;
  }
  function bubbleC(c, s, x, y, txt, colr) {
    const r = s * 0.28;
    c.fillStyle = colr; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
    c.fillStyle = '#fff'; c.font = '700 ' + Math.round(r * 1.4) + 'px "IBM Plex Sans KR", sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(txt, x, y + 1);
  }
  /* pulsing ripples where the bear is about to climb on */
  /* 녹기 직전 칸: 파랗게 깜빡이는 점선 테두리 + 떨어지는 물방울 */
  function meltMark(c, x, y, s, t) {
    const pulse = 0.5 + 0.5 * Math.sin(t / 170);
    hexPath(c, x, y, s * 0.84); c.fillStyle = 'rgba(40,120,200,' + (0.18 + 0.16 * pulse).toFixed(3) + ')'; c.fill();
    c.setLineDash([4, 4]); c.lineWidth = Math.max(1.5, s * 0.1); c.strokeStyle = 'rgba(90,190,255,' + (0.55 + 0.45 * pulse).toFixed(3) + ')'; c.stroke(); c.setLineDash([]);
    c.fillStyle = 'rgba(150,215,255,.9)';
    for (let k = 0; k < 3; k++) { const f = ((t / 900) + k / 3) % 1, dx = (k - 1) * s * 0.32; c.globalAlpha = 1 - f; c.beginPath(); c.arc(x + dx, y - s * 0.3 + f * s * 0.6, s * 0.07, 0, 7); c.fill(); }
    c.globalAlpha = 1;
  }
  function warnRipples(c, G, wx, wy, t, ice) {
    const s = G.s;
    c.save(); c.beginPath(); c.rect(G.x0 - 6, G.y0 - 6, G.bw + 12, G.bh + 12); c.clip();
    for (let k = 0; k < 3; k++) {
      const f = ((t / 900) + k / 3) % 1;
      c.strokeStyle = 'rgba(255,140,110,' + (0.8 * (1 - f)).toFixed(3) + ')'; c.lineWidth = 2;
      c.beginPath(); c.ellipse(wx, wy, s * (0.2 + f * 0.7), s * (0.08 + f * 0.28), 0, 0, 7); c.stroke();
    }
    c.restore();
    void ice;
  }
  function chipsInto(top, n, deadOf, activeOf, col, nm, tm) {
    top.innerHTML = '';
    const per = n > 4 ? 4 : n; // 5–8 penguins: two rows of four
    top.style.flexWrap = n > 4 ? 'wrap' : 'nowrap'; top.style.rowGap = '4px';
    for (let k = 0; k < n; k++) {
      const dead = deadOf(k);
      top.append(L.h('span', { class: 'turn', style: { flex: '0 1 auto', minWidth: '0', maxWidth: 'calc((100% - ' + (per * 5) + 'px) / ' + per + ')', fontSize: n > 4 ? '11.5px' : '12px', padding: n > 4 ? '2px 7px 2px 5px' : '3px 8px 3px 6px', opacity: dead ? 0.45 : 1, borderColor: activeOf(k) ? col(k) : '', borderBottom: tm ? '3px solid ' + TC[tm[k]] : '', textDecoration: dead ? 'line-through' : 'none' } },
        L.h('span', { class: 'dot', style: { '--c': col(k) } }),
        L.h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' }, text: nm(k) + (dead ? ' 풍덩' : '') })));
    }
  }

  /* ---------- turn mode view ---------- */
  function mountTurn(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, D = null, G = null, plan = null;
    let queue = [], cur = null, drift = null;
    let sel = { ph: 0, to: -1, h: -1 }, prevw = null, pending = false, shownKey = '', watchdog = 0, busy = false;
    const face = [];
    let bearFace = -1, msg = '', lastDraw = 0;
    const cache = document.createElement('canvas'), cctx = cache.getContext('2d');
    let cacheKey = '';
    const PT = makeParts();
    const burst = (x, y, kind, n) => PT.burst(x, y, kind, n, G.s), splash = (x, y, big) => PT.splash(x, y, big, G.s);

    const top = L.h('div', { class: 'hud top pg-top', style: { gap: '5px', flexWrap: 'nowrap', padding: '8px 8px' } });
    const hud = L.h('div', { class: 'hud bottom pg-hud', style: { flexWrap: 'nowrap', alignItems: 'stretch', padding: '8px 10px' } });
    const info = L.h('div', { class: 'panel pg-info', style: { flex: '1 1 auto', minWidth: '0', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '2px', minHeight: '52px', padding: '6px 10px' } });
    const stLine = L.h('div', { class: 'mono', style: { fontSize: '11.5px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
    const hint = L.h('div', { style: { fontSize: '13.5px', fontWeight: 700, lineHeight: 1.3 } });
    info.append(stLine, hint);
    const undoBtn = L.h('button', { 'data-action': 'redo', class: 'btn ghost', 'aria-label': '다시 고르기', text: '↶', style: { minWidth: '48px', fontSize: '20px', padding: '0 10px' }, onclick() { if (sel.ph) { sel = { ph: 0, to: -1, h: -1 }; prevw = null; api.sfx('click'); refresh(); } } });
    const goBtn = L.h('button', { 'data-action': 'go', class: 'btn primary', text: '깨기!', style: { minWidth: '76px' }, onclick() { submit(); } });
    hud.append(info, undoBtn, goBtn);
    const offTB = api.input ? api.input.on((t, id) => { if (t !== 'down') return; const b = id === 'go' ? goBtn : id === 'redo' ? undoBtn : null; if (b && !b.hidden && !b.disabled && b.getClientRects().length) b.click(); }) : null;
    // tutorial spotlight targets (invisible): the ice field and my penguin
    const boardMark = L.h('div', { class: 'pg-board', style: { position: 'absolute', pointerEvents: 'none' } });
    const meMark = L.h('div', { class: 'pg-me', style: { position: 'absolute', pointerEvents: 'none' } });
    root.append(boardMark, meMark, top, hud);
    function placeMarks() {
      if (!G) return;
      Object.assign(boardMark.style, { left: G.x0 + 'px', top: G.y0 + 'px', width: G.bw + 'px', height: G.bh + 'px' });
      const mine = api.mySeats ? api.mySeats() : [], k = mine.length ? mine[0] : 0;
      if (st && st.p[k] != null) Object.assign(meMark.style, { left: (cx(st.p[k]) - G.s * 1.1) + 'px', top: (cy(st.p[k]) - G.s * 1.6) + 'px', width: (G.s * 2.2) + 'px', height: (G.s * 2.6) + 'px' });
    }
    let bbT = null, bbG = null;
    function layout() { G = layoutG(cv.w, cv.h, bbT || { x0: X0 - 8.5, y0: Y0 - 10.4, x1: X0 + 8.5, y1: Y0 + 10.6 }); cacheKey = ''; placeMarks(); }
    const cx = (i) => G.ox + XW[i] * G.s;
    const cy = (i) => G.oy + YW[i] * G.s;
    cv.onresize = () => { layout(); draw(performance.now()); };
    layout();

    function fromState(s) { return { ice: iceArr(s), p: s.p.slice(), dead: s.dead.map((x) => (x ? 1 : 0)), b: s.b.at, w: s.b.w, mw: (s.mw || []).slice(), fl: (s.fl || []).map((f) => f.slice()), o: s.o && s.o.t >= 0 ? { t: s.o.t, d: s.o.d } : null }; }
    function fromPre(pr) { const ice = []; for (let i = 0; i < N; i++) ice[i] = pr.i.charCodeAt(i) - 48; return { ice, p: pr.p.slice(), dead: pr.d.slice(), b: pr.b, w: pr.w, mw: (pr.mw || []).slice(), fl: (pr.fl || []).map((f) => f.slice()), o: pr.o && pr.o.t >= 0 ? { t: pr.o.t, d: pr.o.d } : null }; }
    const col = (k) => (api.players[k] && api.players[k].color) || '#ccc';
    const nm = (k) => (api.players[k] && api.players[k].name) || '펭귄';
    const drawPenguin = (x, y, k, u, o) => drawPeng(ctx, x, y, col(k), u, st && st.tm && o && !o.noShadow ? Object.assign({ tc: TC[st.tm[k]] }, o) : o);
    const drawBear = (x, y, u, o) => drawBearC(ctx, x, y, u, o);
    const bubble = (x, y, txt, c) => bubbleC(ctx, G.s, x, y, txt, c);

    function ensureCache() {
      const key = D.ice.join('') + (st && st.ty ? st.ty : '') + '|' + cv.w + 'x' + cv.h + '|' + G.s.toFixed(2);
      if (key === cacheKey) return;
      cacheKey = key;
      cache.width = Math.round(cv.w * cv.dpr); cache.height = Math.round(cv.h * cv.dpr);
      cctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      paintBoard(cctx, cv.w, cv.h, G, (i) => (D.ice[i] ? (D.ice[i] === 1 ? 2 : 0) : -1), st && st.ty, (i) => D.ice[i]);
    }

    /* ----- event animation (from state.last) ----- */
    const ease = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
    const durOf = evDur;
    function startAnim(last) {
      D = fromPre(last.pre);
      queue = last.ev.map((e) => Object.assign({}, e));
      PT.clear(); drift = null;
      busy = true; api.setBusy(true);
      clearTimeout(watchdog);
      const total = queue.reduce((a, e) => a + durOf(e), 0);
      watchdog = setTimeout(() => { if (busy) finishAnim(); }, (total * 1000) / L.debug.speed + 2000);
      nextEv();
    }
    function nextEv() {
      cur = queue.shift() || null;
      if (!cur) { finishAnim(); return; }
      cur.el = 0; cur.dur = durOf(cur); cur.hit = false;
      renderInfo();
      const e = cur;
      if (e.t === 'm') { const a = e.pa[0], b = e.pa[e.pa.length - 1]; if (cx(b) !== cx(a)) face[e.s] = cx(b) > cx(a) ? 1 : -1; }
      if (e.t === 'h') { const p = D.p[e.s]; if (cx(e.at) !== cx(p)) face[e.s] = cx(e.at) > cx(p) ? 1 : -1; }
      if (e.t === 'f') { splash(cx(e.at), cy(e.at), false); api.sfx('whoosh'); api.buzz(25); }
      if (e.t === 'cb') { D.ice[e.at] = 0; burst(cx(e.at), cy(e.at), 'shard', 14); api.sfx('pop'); api.toast('금 간 얼음이 무게를 못 버텼어요!'); }
      if (e.t === 'bf') { splash(cx(e.at), cy(e.at), true); api.sfx('thud'); api.buzz(30); api.toast('북극곰이 풍덩! 곧 다시 올라와요'); }
      if (e.t === 'k') {
        let sx = 0, sy = 0, n = 0;
        for (let i = 0; i < N; i++) if (D.ice[i] && e.ts.indexOf(i) < 0) { sx += cx(i); sy += cy(i); n++; }
        const mx = n ? sx / n : cv.w / 2, my = n ? sy / n : cv.h / 2;
        let tx = 0, ty = 0; for (const t of e.ts) { tx += cx(t); ty += cy(t); }
        tx /= e.ts.length; ty /= e.ts.length;
        let vx = tx - mx, vy = ty - my; const l = Math.hypot(vx, vy) || 1; vx /= l; vy /= l;
        drift = { ts: e.ts.map((t) => ({ i: t, hp: D.ice[t] })), vx, vy, ps: e.ps, bb: e.bb };
        for (const t of e.ts) D.ice[t] = 0;
        if (e.ml) D.mw = [];
        api.sfx('whoosh'); api.toast(e.ml ? '가장자리 얼음이 녹았어요!' : '얼음 조각이 떠내려가요!');
      }
      if (e.t === 'mw') { D.mw = e.ts.slice(); api.sfx('tick'); api.toast('💧 물방울 칸은 라운드가 끝나면 녹아요! 벗어나세요'); }
      if (e.t === 'w') { D.w = e.at; api.sfx('tick'); api.buzz(15); api.toast('북극곰이 다가와요! 물보라 자리를 조심!'); }
      if (e.t === 'bi') { D.w = -1; D.b = -2; splash(cx(e.at), cy(e.at), true); api.sfx('thud'); api.buzz([30, 40, 30]); api.toast('북극곰 등장!'); bearFace = cx(e.at) > cv.w / 2 ? -1 : 1; }
      if (e.t === 'bm') { D.b = -2; const a = e.pa[0], b = e.pa[e.pa.length - 1]; if (cx(a) !== cx(b)) bearFace = cx(b) > cx(a) ? 1 : -1; }
      if (e.t === 'sw') { if (cx(e.fr) !== cx(D.b)) bearFace = cx(e.fr) > cx(D.b) ? 1 : -1; }
      if (e.t === 'fd') { e.hp = e.mv.map((m) => D.ice[m[0]]); for (const m of e.mv) D.ice[m[0]] = 0; api.sfx('whoosh'); }
      if (e.t === 'ow') { D.o = { t: e.at, d: e.d }; api.sfx('tick'); api.buzz(15); api.toast('범고래 지느러미! 빨간 물가 칸에서 벗어나세요'); }
      if (e.t === 'oh') { D.o = null; }
    }
    function endEv(e) {
      if (/^(f|k|sw)$/.test(e.t)) setTimeout(renderTop, 0);
      if (e.t === 'm') D.p[e.s] = e.pa[e.pa.length - 1];
      if (e.t === 'h' && !e.hit) impact(e);
      if (e.t === 'f') { D.dead[e.s] = 1; api.toast(nm(e.s) + ' 풍덩!'); }
      if (e.t === 'bf') D.b = -1;
      if (e.t === 'k') {
        for (const t of drift.ts) { const p = driftPos(t.i, 1); splash(p.x, p.y, false); }
        for (const k of e.ps) D.dead[k] = 1;
        if (e.bb) D.b = -1;
        if (e.ps.length) api.toast(e.ps.map(nm).join(', ') + ' 떠내려가서 풍덩!');
        drift = null;
      }
      if (e.t === 'bi') D.b = e.at;
      if (e.t === 'bm') D.b = e.pa[e.pa.length - 1];
      if (e.t === 'fd') {
        e.mv.forEach((m, j) => {
          D.ice[m[1]] = e.hp[j];
          for (let k = 0; k < D.p.length; k++) if (!D.dead[k] && D.p[k] === m[0]) D.p[k] = m[1];
          if (D.b === m[0]) D.b = m[1];
          const f = D.fl.find((q) => q[0] === m[0]); if (f) f[0] = m[1];
        });
      }
      if (e.t === 'oh') {
        if (!e.hit) orcaImpact(e);
        if (e.s >= 0) { if (e.to >= 0) D.p[e.s] = e.to; if (e.f) { D.dead[e.s] = 1; api.toast(nm(e.s) + ' 범고래에 받혀 풍덩!'); } }
        if (!e.v && D.b === e.at) D.b = -1;
      }
      if (e.t === 'sw') {
        if (!e.hit) swImpact(e);
        if (e.f) { const p = flyEnd(e); splash(p.x, p.y, false); D.dead[e.s] = 1; D.p[e.s] = e.to; api.sfx('whoosh'); api.toast(nm(e.s) + ' 곰에게 밀려 풍덩!'); }
        else D.p[e.s] = e.to;
      }
    }
    function impact(e) {
      e.hit = true;
      D.ice[e.at] = e.v;
      const x = cx(e.at), y = cy(e.at);
      burst(x, y, 'shard', e.v ? 8 : 14);
      if (!e.v) { splash(x, y, false); api.sfx('pop'); } else api.sfx('hit');
      api.buzz(e.v ? 12 : 22);
    }
    function orcaImpact(e) {
      e.hit = true;
      const x = cx(e.at), y = cy(e.at);
      splash(x, y, true);
      if (!e.miss) { D.ice[e.at] = e.v; burst(x, y, 'shard', e.v ? 10 : 16); }
      api.sfx('thud'); api.buzz([25, 30, 25]);
      if (!e.f) api.toast(e.miss ? '범고래가 헛물을 켰어요' : '범고래가 얼음 가장자리를 들이받았어요!');
    }
    function finPos(i, d, k) { const a = [0, -60, -120, 180, 120, 60][d] * Math.PI / 180; return { x: cx(i) + Math.cos(a) * G.s * SQ3 * k, y: cy(i) + Math.sin(a) * G.s * SQ3 * k }; }
    function fdPos(i) {
      if (!cur || cur.t !== 'fd') return null;
      const m = cur.mv.find((q) => q[0] === i); if (!m) return null;
      const f = ease(Math.min(1, cur.el / cur.dur));
      return { x: U.lerp(cx(m[0]), cx(m[1]), f), y: U.lerp(cy(m[0]), cy(m[1]), f) };
    }
    function swImpact(e) {
      e.hit = true;
      D.ice[e.fr] = e.v;
      burst(cx(e.fr), cy(e.fr), 'shard', 10);
      api.sfx('hit'); api.buzz(35);
    }
    function flyEnd(e) {
      if (e.to !== e.fr) return { x: cx(e.to), y: cy(e.to) };
      if (!e.f) return { x: cx(e.fr), y: cy(e.fr) };
      const a = [0, -60, -120, 180, 120, 60][e.d] * Math.PI / 180;
      return { x: cx(e.fr) + Math.cos(a) * G.s * SQ3, y: cy(e.fr) + Math.sin(a) * G.s * SQ3 };
    }
    function driftPos(i, f) {
      const e = ease(Math.min(1, f));
      return { x: cx(i) + drift.vx * G.s * 1.6 * e, y: cy(i) + drift.vy * G.s * 1.6 * e + G.s * 0.3 * e };
    }
    function finishAnim() {
      clearTimeout(watchdog);
      cur = null; queue = []; drift = null;
      if (st) D = fromState(st);
      if (busy) { busy = false; api.setBusy(false); }
      plan = st && st.b.at >= 0 && !st.over ? bearPlan(st) : null;
      msg = summary(st);
      refresh();
    }
    function summary(s) {
      if (!s || !s.last) return '';
      const ev = s.last.ev, fall = [];
      let bear = '';
      for (const e of ev) {
        if (e.t === 'f') fall.push(nm(e.s));
        if (e.t === 'k') for (const k of e.ps) fall.push(nm(k));
        if (e.t === 'sw' && e.f) fall.push(nm(e.s));
        if (e.t === 'w') bear = '물보라! 다음 라운드 끝에 북극곰이 올라와요';
        if (e.t === 'bi') bear = '북극곰이 올라왔어요!';
        if (e.t === 'bf' || (e.t === 'k' && e.bb)) bear = '북극곰이 빠졌어요';
        if (e.t === 'oh' && e.f) fall.push(nm(e.s));
        if (e.t === 'ow' && !bear) bear = '범고래가 물가를 노려요';
      }
      if (fall.length) return fall.join(', ') + ' 풍덩!' + (bear ? ' · ' + bear : '');
      if (bear) return bear;
      return '';
    }

    /* ----- input ----- */
    function myTurn() { if (!st || st.over) return -1; const a = actor(st); return a != null && api.canAct(a) && !busy && !pending ? a : -1; }
    function reachInfo() {
      const me = myTurn(); if (me < 0) return null;
      const ice = iceArr(st), oc = occ(st);
      return { me, ice, oc, r: reachFrom(ice, oc, st.p[me], st.ty) };
    }
    function preview() {
      if (sel.h < 0) { prevw = null; return; }
      const me = myTurn(); if (me < 0) { prevw = null; return; }
      let s2;
      try { s2 = apply(cloneS(st), me, { to: sel.to, h: sel.h }); } catch (e) { prevw = null; return; }
      const ev = s2.last.ev, end = s2.last.bp >= 0 ? s2.last.bp : ev.length;
      const p = { hole: false, fall: [], sink: [], bear: false };
      for (let k = 0; k < end; k++) {
        const e = ev[k];
        if (e.t === 'h') p.hole = !e.v;
        if (e.t === 'f') p.fall.push(e.s);
        if (e.t === 'bf') p.bear = true;
        if (e.t === 'k') { p.sink = e.ts; p.fall.push.apply(p.fall, e.ps); if (e.bb) p.bear = true; }
      }
      p.bpl = null;
      if (st.b.at >= 0 && !p.bear && s2.last.bp >= 0) {
        const base = movedPlan(me) || { path: [st.b.at], tgt: -1, hit: 0, dir: -1, lethal: 0 };
        const bpl = { path: [st.b.at], tgt: base.tgt, hit: 0, dir: -1, lethal: 0 };
        for (let k = end; k < ev.length; k++) {
          const e = ev[k];
          if (e.t === 'bm') bpl.path = e.pa;
          if (e.t === 'sw') { bpl.tgt = e.s; bpl.hit = 1; bpl.dir = e.d; bpl.lethal = e.f; }
        }
        p.bpl = bpl;
      }
      prevw = p;
    }
    function movedPlan(me) {
      if (!st || st.b.at < 0) return null;
      const t = cloneS(st); t.p[me] = sel.to;
      return bearPlan(t, null, null, me);
    }
    function curPlan() {
      const me = myTurn();
      if (me >= 0 && sel.ph === 1) return prevw ? prevw.bpl : movedPlan(me);
      return plan;
    }
    function pick(px, py, cands) {
      let best = -1, bd = G.s * 1.1;
      for (const i of cands) {
        let d = Math.hypot(px - cx(i), (py - cy(i)) * 1.1);
        const occd = (D.p.indexOf(i) >= 0 && !D.dead[D.p.indexOf(i)]) || i === sel.to || (D.b === i);
        if (occd) d = Math.min(d, Math.hypot(px - cx(i), py - (cy(i) - G.s * 0.8)) * 0.9);
        if (d < bd) { bd = d; best = i; }
      }
      return best;
    }
    function onDown(ev) {
      const R0 = reachInfo(); if (!R0) return;
      const p = cv.local(ev);
      if (sel.ph === 0) {
        const t = pick(p.x, p.y, R0.r.list);
        if (t < 0) return;
        sel = { ph: 1, to: t, h: -1 }; prevw = null;
        if (t !== st.p[R0.me]) face[R0.me] = cx(t) > cx(st.p[R0.me]) ? 1 : cx(t) < cx(st.p[R0.me]) ? -1 : face[R0.me];
        api.sfx('tick'); api.buzz(8);
        const tg = targetsFrom(R0.ice, t); if (tg.length === 1) { sel.h = tg[0]; preview(); }
        refresh(); return;
      }
      const tg = targetsFrom(R0.ice, sel.to);
      const both = tg.concat(R0.r.list.filter((i) => tg.indexOf(i) < 0 && i !== sel.to));
      const t = pick(p.x, p.y, both);
      if (t < 0) return;
      if (tg.indexOf(t) >= 0) {
        if (sel.h === t) { submit(); return; }
        sel.h = t; preview(); api.sfx('tick'); api.buzz(8);
      } else {
        sel = { ph: 1, to: t, h: -1 }; prevw = null; api.sfx('tick');
        const tg2 = targetsFrom(R0.ice, t); if (tg2.length === 1) { sel.h = tg2[0]; preview(); }
      }
      refresh();
    }
    cv.cv.addEventListener('pointerdown', onDown);
    function submit() {
      const me = myTurn(); if (me < 0 || sel.ph !== 1 || sel.h < 0) return;
      pending = true; api.sfx('click'); api.buzz(14);
      const a = { to: sel.to, h: sel.h };
      sel = { ph: 0, to: -1, h: -1 }; prevw = null;
      refresh();
      api.act(a);
      setTimeout(() => { if (pending) { pending = false; refresh(); } }, 4000);
    }

    /* ----- HUD ----- */
    function renderTop() {
      if (!st) { top.innerHTML = ''; return; }
      const a = actor(st);
      chipsInto(top, st.n, (k) => (D ? D.dead[k] : st.dead[k]), (k) => a === k && !busy, col, nm, st.tm);
    }
    function renderInfo() {
      if (!st) return;
      const b = st.b;
      let sl = st.rd + '라운드 · ';
      if (b.at >= 0) sl += b.age >= ANGRY ? '곰 화남! 2칸씩' : '곰 출몰 · 1칸씩';
      else if (b.w >= 0) sl += '물보라! 곧 곰이 와요';
      else if (st.rd > st.K) sl += '곰이 다시 와요';
      else sl += '곰까지 ' + (st.K - st.rd + 1) + '라운드';
      if (st.o && st.o.t >= 0) sl += ' · 범고래!';
      if (!busy || !stLine.textContent) stLine.textContent = sl;
      let ht = '', color = '';
      const me = myTurn();
      if (st.over) ht = msg || '경기 끝!';
      else if (me >= 0) {
        if (sel.ph === 0) ht = '갈 칸을 탭 (2칸까지) · 그대로면 내 펭귄 탭';
        else if (sel.h < 0) ht = '깰 얼음을 탭하세요 (바로 옆 칸)';
        else if (prevw) {
          const parts2 = [];
          if (prevw.fall.indexOf(me) >= 0) { parts2.push('앗, 내가 빠져요!'); color = 'var(--coral)'; }
          const others = prevw.fall.filter((k) => k !== me);
          if (prevw.sink.length) parts2.push('얼음 ' + prevw.sink.length + '칸이 떠내려가요');
          if (others.length) parts2.push(others.map(nm).join(', ') + ' 풍덩!');
          if (prevw.bear) parts2.push('곰이 빠져요!');
          if (!parts2.length) parts2.push(prevw.hole ? '구멍이 나요' : '금이 가요');
          if (prevw.bpl && prevw.bpl.tgt === me && prevw.bpl.hit && prevw.fall.indexOf(me) < 0) { parts2.push(prevw.bpl.lethal ? '곰에게 밀려 빠져요!' : '곰에게 맞아요'); if (prevw.bpl.lethal) color = 'var(--coral)'; }
          ht = parts2.join(' · ') + ' · 한 번 더 탭하면 깨요';
        }
      } else if (busy) ht = cur && /^(bm|sw|bi|w)$/.test(cur.t) ? (cur.t === 'w' ? '물보라가 일어요…' : cur.t === 'bi' ? '북극곰이 올라와요!' : '북극곰 차례!') : st.last ? nm(st.last.s) + ' 깨는 중…' : '';
      else {
        const a = actor(st);
        ht = msg ? msg : nm(a) + ' 차례';
        if (plan && plan.tgt >= 0) ht = (msg ? msg + ' · ' : '') + '곰 → ' + nm(plan.tgt) + (plan.hit && plan.lethal ? ' (위험!)' : '');
      }
      if (me >= 0 && sel.ph === 0 && plan && plan.tgt >= 0) ht += ' · 곰이 ' + (plan.tgt === me ? '나를' : nm(plan.tgt) + '을(를)') + ' 노려요';
      hint.textContent = ht;
      hint.style.color = color;
    }
    function refresh() {
      const me = myTurn();
      undoBtn.hidden = goBtn.hidden = me < 0;
      undoBtn.disabled = sel.ph === 0;
      goBtn.disabled = !(sel.ph === 1 && sel.h >= 0);
      if (prevw && me >= 0 && prevw.fall.indexOf(me) >= 0) { goBtn.textContent = '그래도 깨기'; goBtn.className = 'btn danger'; }
      else { goBtn.textContent = '깨기!'; goBtn.className = 'btn primary'; }
      renderTop(); renderInfo(); placeMarks();
    }

    /* ----- frame ----- */
    function spritePos(k, t) {
      if (cur && cur.t === 'm' && cur.s === k) {
        const pa = cur.pa, f = Math.min(cur.el / cur.dur, 0.9999) * (pa.length - 1), i = Math.floor(f), u = f - i;
        return { x: U.lerp(cx(pa[i]), cx(pa[i + 1]), u), y: U.lerp(cy(pa[i]), cy(pa[i + 1]), u), lift: Math.sin(u * Math.PI) * G.s * 0.22, tilt: Math.sin(f * Math.PI * 2) * 0.18, flap: Math.sin(f * Math.PI * 2) * 0.5 };
      }
      if (cur && cur.t === 'sw' && cur.s === k && cur.el > 0.22 * cur.dur) {
        const f = Math.min(1, (cur.el - 0.22 * cur.dur) / (0.5 * cur.dur)), e = flyEnd(cur);
        const x = U.lerp(cx(cur.fr), e.x, f), y = U.lerp(cy(cur.fr), e.y, f);
        return { x, y, lift: Math.sin(f * Math.PI) * G.s * 0.9, tilt: f * 2.4 * (face[k] || 1), flap: 0.8, dazed: true, alpha: cur.f && f > 0.9 ? 1 - (f - 0.9) * 10 : 1 };
      }
      if (cur && cur.t === 'h' && cur.s === k) {
        const f = cur.el / cur.dur;
        const lean = f < 0.4 ? f / 0.4 : Math.max(0, 1 - (f - 0.4) / 0.35);
        return { x: cx(D.p[k]) + (face[k] || 1) * lean * G.s * 0.18, y: cy(D.p[k]), lift: f < 0.4 ? lean * G.s * 0.25 : 0, tilt: (face[k] || 1) * lean * 0.35, flap: -lean * 1.2, sq: f > 0.4 && f < 0.6 ? 0.08 : 0 };
      }
      if (cur && cur.t === 'f' && cur.s === k) {
        const f = cur.el / cur.dur;
        return { x: cx(cur.at), y: cy(cur.at) + f * G.s * 0.8, alpha: 1 - f, tilt: Math.sin(f * 20) * 0.3, flap: 1.2 * Math.sin(f * 25), dazed: true };
      }
      if (drift && drift.ps.indexOf(k) >= 0) {
        const f = cur.el / cur.dur, p = driftPos(D.p[k], f);
        return { x: p.x, y: p.y, alpha: f > 0.7 ? 1 - (f - 0.7) / 0.3 : 1, tilt: Math.sin(f * 14) * 0.25, flap: Math.sin(f * 30) };
      }
      const bob = Math.sin(t / 420 + k * 1.7) * 0.03;
      const fp = fdPos(D.p[k]); if (fp) return { x: fp.x, y: fp.y, sq: bob };
      if (cur && cur.t === 'oh' && cur.s === k && cur.el > 0.45 * cur.dur && cur.to >= 0) {
        const f = Math.min(1, (cur.el - 0.45 * cur.dur) / (0.4 * cur.dur));
        return { x: U.lerp(cx(cur.at), cx(cur.to), f), y: U.lerp(cy(cur.at), cy(cur.to), f), lift: Math.sin(f * Math.PI) * G.s * 0.5, dazed: true, tilt: f * 0.6 };
      }
      return { x: cx(D.p[k]), y: cy(D.p[k]), sq: bob };
    }
    function bearPos(t) {
      if (cur && cur.t === 'bm') {
        const pa = cur.pa, f = Math.min(cur.el / cur.dur, 0.9999) * (pa.length - 1), i = Math.floor(f), u = f - i;
        if (u < 0.05 && !cur['s' + i]) { cur['s' + i] = 1; api.sfx('thud'); }
        return { x: U.lerp(cx(pa[i]), cx(pa[i + 1]), u), y: U.lerp(cy(pa[i]), cy(pa[i + 1]), u), lift: Math.sin(u * Math.PI) * G.s * 0.12, tilt: Math.sin(f * Math.PI * 2) * 0.08 };
      }
      if (cur && cur.t === 'bi') {
        const f = cur.el / cur.dur;
        return { x: cx(cur.at), y: cy(cur.at) + (1 - ease(f)) * G.s * 1.0, alpha: Math.min(1, f * 2), tilt: (1 - f) * 0.4 * bearFace };
      }
      if (cur && cur.t === 'bf') {
        const f = cur.el / cur.dur;
        return { x: cx(cur.at), y: cy(cur.at) + f * G.s, alpha: 1 - f, tilt: Math.sin(f * 16) * 0.2 };
      }
      if (cur && cur.t === 'sw') {
        const f = cur.el / cur.dur;
        return { x: cx(D.b), y: cy(D.b), swipe: f < 0.22 ? -f / 0.22 * 0.4 : f < 0.4 ? 1 : Math.max(0, 1 - (f - 0.4) * 3), lift: f < 0.22 ? f * G.s * 0.6 : 0 };
      }
      if (drift && drift.bb && D.b >= 0) {
        const f = cur.el / cur.dur, p = driftPos(D.b, f);
        return { x: p.x, y: p.y, alpha: f > 0.7 ? 1 - (f - 0.7) / 0.3 : 1 };
      }
      if (D.b < 0) return null;
      const fp = fdPos(D.b); if (fp) return { x: fp.x, y: fp.y };
      return { x: cx(D.b), y: cy(D.b), lift: Math.abs(Math.sin(t / 700)) * G.s * 0.03 };
    }
    function draw(t) {
      if (!G || !D) { cv.clear(); return; }
      ensureCache();
      ctx.drawImage(cache, 0, 0, cv.w, cv.h);
      const s = G.s;
      ctx.save();
      ctx.beginPath(); ctx.rect(G.x0 - 6, G.y0 - 6, G.bw + 12, G.bh + 12); ctx.clip();
      ctx.strokeStyle = 'rgba(170,220,255,.10)'; ctx.lineWidth = 1.5;
      for (let k = 0; k < 8; k++) {
        const y = G.y0 + ((k * 97 + t * 0.012) % (G.bh + 12)), x = G.x0 + ((k * 151) % G.bw);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 14, y - 3 + Math.sin(t / 600 + k) * 2, x + 30, y); ctx.stroke();
      }
      ctx.restore();
      if (drift && cur) {
        const f = cur.el / cur.dur;
        for (const d of drift.ts) { const p = driftPos(d.i, f); drawTile(ctx, d.i, p.x, p.y, s * (1 - 0.15 * f), d.hp === 1 ? 2 : 0, f > 0.55 ? Math.max(0, 1 - (f - 0.55) / 0.45) : 1); }
      }
      if (cur && cur.t === 'fd') cur.mv.forEach((m, j) => { const p = fdPos(m[0]); drawTile(ctx, m[0], p.x, p.y + Math.sin(t / 300 + j) * s * 0.03, s, cur.hp[j] === 1 ? 2 : 0, 1); });
      // 유빙: 물결 테두리 + 다음 라운드에 흘러갈 방향 화살표
      if (D.fl && D.fl.length && !(cur && cur.t === 'fd')) {
        const nx = st && !st.over ? floeMoves({ fl: D.fl, mw: D.mw }, D.ice) : null;
        D.fl.forEach((f, j) => {
          if (!D.ice[f[0]]) return;
          const x = cx(f[0]), y = cy(f[0]), fo = 0.5 + 0.5 * Math.sin(t / 320 + j);
          ctx.strokeStyle = 'rgba(225,245,255,' + (0.35 + 0.3 * fo).toFixed(3) + ')'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.ellipse(x, y + s * 0.3, s * (0.98 + 0.06 * fo), s * (0.5 + 0.03 * fo), 0, 0, 7); ctx.stroke();
          const m = nx && nx[j]; if (m && m[1] >= 0) { const a = Math.atan2(cy(m[1]) - y, cx(m[1]) - x); arrow(x + Math.cos(a) * s * 0.55, y + Math.sin(a) * s * 0.55, x + Math.cos(a) * s * 1.05, y + Math.sin(a) * s * 1.05, 'rgba(225,245,255,.85)'); }
        });
      }
      // 범고래: 노리는 칸(빨간 점선) + 물속 지느러미
      if (D.o && D.o.t >= 0) {
        const pulse = 0.5 + 0.5 * Math.sin(t / 170), fp = finPos(D.o.t, D.o.d, 0.95 + 0.12 * Math.sin(t / 500));
        hexPath(ctx, cx(D.o.t), cy(D.o.t), s * 0.86); ctx.fillStyle = 'rgba(238,106,85,' + (0.12 + 0.12 * pulse).toFixed(3) + ')'; ctx.fill();
        ctx.setLineDash([5, 4]); ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(238,106,85,' + (0.55 + 0.45 * pulse).toFixed(3) + ')'; ctx.stroke(); ctx.setLineDash([]);
        const sway = Math.sin(t / 400) * s * 0.25, a = [0, -60, -120, 180, 120, 60][D.o.d] * Math.PI / 180;
        drawFin(ctx, fp.x - Math.sin(a) * sway, fp.y + Math.cos(a) * sway, s * 0.8, -Math.cos(a) >= 0 ? 1 : -1, t);
      }
      if (cur && cur.t === 'oh') {
        const f = cur.el / cur.dur, k = f < 0.45 ? 1 - f / 0.45 * 0.7 : 0.3 + (f - 0.45) * 1.4, fp = finPos(cur.at, cur.d, k);
        drawOrca(ctx, fp.x, fp.y, s * 0.75, -Math.cos([0, -60, -120, 180, 120, 60][cur.d] * Math.PI / 180) >= 0 ? 1 : -1, Math.sin(Math.min(1, f / 0.6) * Math.PI), f > 0.75 ? Math.max(0, 1 - (f - 0.75) * 4) : 1);
        if (!cur.hit && f >= 0.45) orcaImpact(cur);
      }
      for (let k = 0; k < (st ? st.n : 0); k++) if (D.dead[k] && D.p[k] >= 0 && !D.ice[D.p[k]]) drawHatC(ctx, cx(D.p[k]), cy(D.p[k]) + s * 0.1, col(k), s * 0.42, t, k);
      const me = myTurn();
      if (D.mw && D.mw.length) for (const i of D.mw) if (D.ice[i]) meltMark(ctx, cx(i), cy(i), s, t);
      if (D.w >= 0) {
        const w = D.w, pulse = 0.5 + 0.5 * Math.sin(t / 180);
        let wx = cx(w), wy = cy(w);
        for (let d = 0; d < 6; d++) { const n = NB[w * 6 + d]; if (n < 0 || !D.ice[n]) { const a = [0, -60, -120, 180, 120, 60][d] * Math.PI / 180; wx += Math.cos(a) * s * 0.85; wy += Math.sin(a) * s * 0.85; break; } }
        wx = U.clamp(wx, G.x0 + s * 0.5, G.x0 + G.bw - s * 0.5); wy = U.clamp(wy, G.y0 + s * 0.3, G.y0 + G.bh - s * 0.3);
        warnRipples(ctx, G, wx, wy, t);
        hexPath(ctx, cx(w), cy(w), s * 0.86); ctx.setLineDash([5, 4]); ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.5 * pulse).toFixed(3) + ')'; ctx.stroke(); ctx.setLineDash([]);
        bubble(cx(w), cy(w) - s * 0.15 - pulse * s * 0.12, '!', '#ee6a55');
      }
      const pl = curPlan();
      if (!cur && pl && D.b >= 0 && st && !st.over) {
        const pa = pl.path;
        for (let k = 1; k < pa.length; k++) {
          const a = Math.atan2(cy(pa[k]) - cy(pa[k - 1]), cx(pa[k]) - cx(pa[k - 1])) + Math.PI / 2;
          drawPawC(ctx, cx(pa[k]), cy(pa[k]), s * 0.8, a, 0.45 + 0.1 * Math.sin(t / 250 + k));
        }
        if (pl.tgt >= 0 && !D.dead[pl.tgt]) {
          const tp = pl.tgt === me && sel.ph === 1 ? sel.to : D.p[pl.tgt], pulse = 0.5 + 0.5 * Math.sin(t / 160);
          ctx.strokeStyle = 'rgba(238,106,85,' + (0.55 + 0.45 * pulse).toFixed(3) + ')'; ctx.lineWidth = 3;
          ctx.beginPath(); ctx.ellipse(cx(tp), cy(tp), s * 0.7, s * 0.34, 0, 0, 7); ctx.stroke();
          if (pl.hit) {
            const a = [0, -60, -120, 180, 120, 60][pl.dir] * Math.PI / 180;
            const x0 = cx(tp) + Math.cos(a) * s * 0.45, y0 = cy(tp) + Math.sin(a) * s * 0.45;
            const x1 = cx(tp) + Math.cos(a) * s * 1.35, y1 = cy(tp) + Math.sin(a) * s * 1.35;
            arrow(x0, y0, x1, y1, pl.lethal ? '#ee6a55' : 'rgba(30,58,95,.9)');
            if (pl.lethal) { ctx.fillStyle = 'rgba(120,200,255,.9)'; for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.arc(x1 + k * s * 0.16, y1 + s * 0.18 + Math.abs(k) * s * 0.06, s * 0.07, 0, 7); ctx.fill(); } }
          }
        }
      }
      if (me >= 0) {
        const R0 = reachInfo();
        const mc = col(me);
        if (sel.ph === 0) {
          for (const i of R0.r.list) {
            hexPath(ctx, cx(i), cy(i), s * 0.82); ctx.fillStyle = hexA(mc, 0.16 + 0.08 * Math.sin(t / 260)); ctx.fill();
            ctx.lineWidth = 2; ctx.strokeStyle = hexA(mc, 0.9); ctx.stroke();
            if (i !== st.p[me]) { ctx.fillStyle = hexA(mc, 0.95); ctx.beginPath(); ctx.arc(cx(i), cy(i), s * 0.12, 0, 7); ctx.fill(); }
          }
        } else {
          for (const i of R0.r.list) if (i !== sel.to) { hexPath(ctx, cx(i), cy(i), s * 0.82); ctx.lineWidth = 1.5; ctx.strokeStyle = hexA(mc, 0.35); ctx.stroke(); }
          const tg = targetsFrom(R0.ice, sel.to);
          if (prevw) for (const i of prevw.sink) { hexPath(ctx, cx(i), cy(i), s * 0.9); ctx.fillStyle = 'rgba(238,106,85,.38)'; ctx.fill(); }
          for (const i of tg) {
            const on = i === sel.h;
            hexPath(ctx, cx(i), cy(i), s * 0.8);
            if (on) { ctx.fillStyle = prevw && prevw.hole ? 'rgba(10,40,70,.55)' : 'rgba(238,106,85,.25)'; ctx.fill(); }
            ctx.setLineDash(on ? [] : [5, 4]); ctx.lineWidth = on ? 3.5 : 2.4; ctx.strokeStyle = on ? '#ee6a55' : 'rgba(30,58,95,.85)'; ctx.stroke(); ctx.setLineDash([]);
            pickIcon(cx(i), cy(i), s * (on ? 0.42 : 0.32), on);
          }
        }
      }
      const spr = [];
      if (st) for (let k = 0; k < st.n; k++) {
        if (D.dead[k]) continue;
        let p = spritePos(k, t);
        let ghost = null;
        if (me === k && sel.ph === 1 && sel.to !== st.p[k]) { ghost = p; p = { x: cx(sel.to), y: cy(sel.to), sq: p.sq }; }
        if (ghost) { const gh = ghost; spr.push({ y: gh.y - 0.01, f: () => drawPenguin(gh.x, gh.y, k, s * 0.46, { face: face[k] || 1, alpha: 0.35, noShadow: true }) }); }
        const pp = p;
        spr.push({ y: pp.y, f: () => {
          if (actor(st) === k && !busy && !st.over) {
            ctx.strokeStyle = hexA(col(k), 0.9); ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(pp.x, pp.y, s * 0.62, s * 0.28, 0, 0, 7); ctx.stroke();
            const by = pp.y - s * 1.55 - Math.abs(Math.sin(t / 260)) * s * 0.18;
            ctx.fillStyle = col(k); ctx.beginPath(); ctx.moveTo(pp.x - s * 0.16, by - s * 0.18); ctx.lineTo(pp.x + s * 0.16, by - s * 0.18); ctx.lineTo(pp.x, by); ctx.closePath(); ctx.fill();
          }
          drawPenguin(pp.x, pp.y, k, s * 0.46, { face: face[k] || 1, tilt: pp.tilt, sq: pp.sq, lift: pp.lift, flap: pp.flap, dazed: pp.dazed, alpha: pp.alpha });
          if (prevw && prevw.fall.indexOf(k) >= 0) bubble(pp.x, pp.y - s * 1.45, '!', '#ee6a55');
        } });
      }
      const bp = bearPos(t);
      if (bp) spr.push({ y: bp.y, f: () => drawBear(bp.x, bp.y, s * 0.5, { face: bearFace, tilt: bp.tilt, lift: bp.lift, alpha: bp.alpha, swipe: bp.swipe, angry: st && st.b.age >= ANGRY }) });
      spr.sort((a, b) => a.y - b.y);
      for (const sp of spr) sp.f();
      PT.draw(ctx, s);
    }
    function arrow(x0, y0, x1, y1, c) {
      const a = Math.atan2(y1 - y0, x1 - x0), hl = G.s * 0.28;
      ctx.strokeStyle = c; ctx.fillStyle = c; ctx.lineWidth = 3.5; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1 - Math.cos(a) * hl * 0.6, y1 - Math.sin(a) * hl * 0.6); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x1 - Math.cos(a - 0.45) * hl, y1 - Math.sin(a - 0.45) * hl); ctx.lineTo(x1 - Math.cos(a + 0.45) * hl, y1 - Math.sin(a + 0.45) * hl); ctx.closePath(); ctx.fill();
    }
    function pickIcon(x, y, r, on) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(-0.6);
      ctx.fillStyle = on ? '#ee6a55' : 'rgba(30,58,95,.85)';
      ctx.fillRect(-r * 0.09, -r * 0.2, r * 0.18, r * 1.0);
      ctx.beginPath(); ctx.moveTo(-r * 0.8, -r * 0.35); ctx.quadraticCurveTo(0, -r * 0.75, r * 0.8, -r * 0.35); ctx.lineTo(r * 0.6, -r * 0.2); ctx.quadraticCurveTo(0, -r * 0.5, -r * 0.6, -r * 0.2); ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    const stop = U.loop((dt, t) => {
      if (!G || !D) return;
      const sp = L.debug.speed || 1;
      if (cur) {
        cur.el += dt * sp;
        if (cur.t === 'h' && !cur.hit && cur.el >= cur.dur * 0.4) impact(cur);
        if (cur.t === 'sw' && !cur.hit && cur.el >= cur.dur * 0.22) swImpact(cur);
        if (cur.t === 'm') { const f = cur.el / cur.dur * (cur.pa.length - 1); if (!cur['s' + Math.floor(f)]) { cur['s' + Math.floor(f)] = 1; api.sfx('tick'); } }
        if (cur.el >= cur.dur) { const e = cur; endEv(e); nextEv(); }
      }
      PT.step(dt * sp);
      const idle = !cur && !PT.list.length;
      if (idle && t - lastDraw < 45) return;
      lastDraw = t;
      draw(t);
    });

    return {
      update(next, prev) {
        st = next;
        pending = false;
        if (next.g !== bbG) { bbG = next.g; bbT = bbOfIce(next.last ? next.last.pre.i : next.ice); layout(); }
        const key = next.last ? next.g + ':' + next.last.id : '';
        if (next.last && key !== shownKey && prev && G) { shownKey = key; sel = { ph: 0, to: -1, h: -1 }; prevw = null; plan = null; msg = ''; startAnim(next.last); }
        else {
          if (key !== shownKey) { sel = { ph: 0, to: -1, h: -1 }; prevw = null; }
          shownKey = key;
          if (!cur) { D = fromState(next); plan = next.b.at >= 0 && !next.over ? bearPlan(next) : null; msg = summary(next); }
        }
        for (let k = 0; k < next.n; k++) if (!face[k]) face[k] = cx(next.p[k]) > cv.w / 2 ? -1 : 1;
        refresh();
        draw(performance.now());
      },
      destroy() { if (offTB) offTB();
        stop(); clearTimeout(watchdog);
        if (busy) { busy = false; api.setBusy(false); }
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.destroy(); top.remove(); hud.remove(); boardMark.remove(); meMark.remove();
      },
    };
  }

  /* ---------- realtime mode view (host/local simulates, guests mirror) ---------- */
  /* 범고래: 물 위로 보이는 등지느러미(+물살), 들이받을 때는 몸통이 솟구침 */
  function drawFin(c, x, y, u, dir, t, alpha) {
    c.save(); c.globalAlpha = alpha == null ? 1 : alpha; c.translate(x, y);
    c.strokeStyle = 'rgba(220,240,255,.55)'; c.lineWidth = Math.max(1.2, u * 0.08);
    for (let k = 1; k <= 2; k++) { c.beginPath(); c.moveTo(-dir * u * 0.15, u * 0.1); c.quadraticCurveTo(-dir * u * (0.6 + k * 0.35), u * (0.05 + k * 0.12), -dir * u * (1.0 + k * 0.5), u * (0.1 + k * 0.2)); c.stroke(); }
    c.fillStyle = 'rgba(0,10,25,.35)'; c.beginPath(); c.ellipse(0, u * 0.12, u * 0.55, u * 0.12, 0, 0, 7); c.fill();
    c.fillStyle = '#10161f'; c.beginPath(); c.moveTo(-dir * u * 0.32, u * 0.1); c.quadraticCurveTo(-dir * u * 0.2, -u * 0.55, dir * u * 0.12, -u * 0.95 - Math.sin(t / 260) * u * 0.04); c.quadraticCurveTo(dir * u * 0.05, -u * 0.35, dir * u * 0.3, u * 0.1); c.closePath(); c.fill();
    c.restore();
  }
  function drawOrca(c, x, y, u, dir, rise, alpha) {
    c.save(); c.globalAlpha = alpha; c.translate(x, y); c.scale(dir, 1); c.rotate(-0.5 * rise);
    const yy = -rise * u * 0.6;
    c.fillStyle = '#10161f'; c.beginPath(); c.ellipse(0, yy, u * 1.1, u * 0.45, 0, 0, 7); c.fill();
    c.beginPath(); c.moveTo(-u * 0.1, yy - u * 0.35); c.lineTo(u * 0.05, yy - u * 1.0); c.lineTo(u * 0.3, yy - u * 0.35); c.closePath(); c.fill();
    c.fillStyle = '#eef4f8'; c.beginPath(); c.ellipse(u * 0.6, yy - u * 0.12, u * 0.2, u * 0.09, -0.2, 0, 7); c.fill();
    c.beginPath(); c.ellipse(u * 0.2, yy + u * 0.22, u * 0.5, u * 0.14, 0, 0, 7); c.fill();
    c.restore();
    c.fillStyle = 'rgba(220,240,255,.7)'; for (let k = -2; k <= 2; k++) { c.beginPath(); c.arc(x + k * u * 0.35, y + u * 0.1 - Math.abs(Math.sin(rise * 3 + k)) * u * 0.4 * rise, u * 0.08, 0, 7); c.fill(); }
  }
  function drawSeal(c, x, y, u, dx, dy, t, alpha) {
    c.save(); c.translate(x, y); c.globalAlpha = alpha == null ? 1 : alpha;
    c.fillStyle = 'rgba(0,20,40,.28)'; c.beginPath(); c.ellipse(0, u * 0.1, u * 1.1, u * 0.34, 0, 0, 7); c.fill();
    const f = dx >= 0 ? 1 : -1; c.scale(f, 1); c.rotate(Math.atan2(dy, Math.abs(dx) || 1e-3) * 0.35);
    const g = c.createLinearGradient(0, -u, 0, u * 0.3); g.addColorStop(0, '#9aa6b4'); g.addColorStop(1, '#5d6876');
    c.fillStyle = g; c.beginPath(); c.ellipse(-u * 0.15, -u * 0.25, u * 1.0, u * 0.42, 0, 0, 7); c.fill();
    c.beginPath(); c.moveTo(-u * 1.05, -u * 0.25); c.lineTo(-u * 1.55, -u * 0.55 + Math.sin(t / 60) * u * 0.1); c.lineTo(-u * 1.5, u * 0.05); c.closePath(); c.fill();
    c.fillStyle = '#6c7886'; c.beginPath(); c.ellipse(u * 0.15, u * 0.1, u * 0.3, u * 0.12, 0.6, 0, 7); c.fill();
    c.fillStyle = '#a9b4c1'; c.beginPath(); c.arc(u * 0.82, -u * 0.42, u * 0.38, 0, 7); c.fill();
    c.fillStyle = '#1b1f26'; c.beginPath(); c.arc(u * 0.95, -u * 0.52, u * 0.07, 0, 7); c.fill();
    c.beginPath(); c.arc(u * 1.18, -u * 0.4, u * 0.06, 0, 7); c.fill();
    c.strokeStyle = 'rgba(30,30,30,.6)'; c.lineWidth = Math.max(0.6, u * 0.03);
    c.beginPath(); c.moveTo(u * 1.1, -u * 0.32); c.lineTo(u * 1.45, -u * 0.4); c.moveTo(u * 1.1, -u * 0.28); c.lineTo(u * 1.45, -u * 0.22); c.stroke();
    c.restore();
  }
  function drawBerg(c, x, y, u, rot, alpha) {
    c.save(); c.translate(x, y); c.globalAlpha = alpha == null ? 1 : alpha;
    c.fillStyle = 'rgba(0,20,40,.3)'; c.beginPath(); c.ellipse(0, u * 0.2, u * 1.05, u * 0.4, 0, 0, 7); c.fill();
    c.translate(0, -u * 0.55); c.rotate(rot);
    const pts = 7, r = u;
    const g = c.createLinearGradient(-r, -r, r, r); g.addColorStop(0, '#ffffff'); g.addColorStop(0.55, '#cfe8f7'); g.addColorStop(1, '#7fb3d6');
    c.fillStyle = g; c.beginPath();
    for (let k = 0; k < pts; k++) { const a = k / pts * Math.PI * 2, rr = r * (0.82 + 0.18 * ((k * 7) % 3) / 2); c.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); }
    c.closePath(); c.fill();
    c.strokeStyle = 'rgba(70,120,160,.6)'; c.lineWidth = Math.max(1, u * 0.06); c.stroke();
    c.strokeStyle = 'rgba(255,255,255,.8)'; c.beginPath(); c.moveTo(-r * 0.4, -r * 0.3); c.lineTo(r * 0.1, -r * 0.55); c.moveTo(-r * 0.1, r * 0.1); c.lineTo(r * 0.45, -r * 0.05); c.stroke();
    c.restore();
  }
  function drawFish(c, x, y, u, t, k) {
    c.save(); c.translate(x, y); c.rotate(Math.sin(t / 90 + k) * 0.35);
    c.fillStyle = '#f2a33a'; c.beginPath(); c.ellipse(0, 0, u * 0.5, u * 0.22, 0, 0, 7); c.fill();
    c.beginPath(); c.moveTo(-u * 0.42, 0); c.lineTo(-u * 0.78, -u * 0.22); c.lineTo(-u * 0.78, u * 0.22); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.ellipse(u * 0.05, -u * 0.07, u * 0.28, u * 0.07, 0, 0, 7); c.fill();
    c.fillStyle = '#222'; c.beginPath(); c.arc(u * 0.3, -u * 0.04, u * 0.05, 0, 7); c.fill();
    c.restore();
  }
  function mountRT(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const P = (k) => api.players[k] || { name: '펭귄', color: '#ccc', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (k) => { const p = api.players[k]; return !!p && !p.ai && !!p.local; };
    const col = (k) => P(k).color || '#ccc', nm = (k) => P(k).name || '펭귄';
    let st = null, key = null, wd = null, phase = 'wait', cd = 0, G = null, A = null, sentEnd = false, endTimer = 0, busy = false, sentDead = '';
    // world-space tile cache (re-painted only where tiles change) + screen-space parlour/pool background
    const board = document.createElement('canvas'), bctx = board.getContext('2d');
    const bgc = document.createElement('canvas'), gctx = bgc.getContext('2d');
    let CB = null, bgKey = '', fullPaint = true;
    const chg = new Set();
    const cam = { s: 0, cx: 0, cy: 0, ok: false };
    let tbb = null; // bounding box of the ice we're showing
    let aiMem = [], remIn = {}, shown = null, shownOut = [], prevHc = [], prevDn = [], prevFe = [], fallAt = [], fallPos = [], face = [], dashAt = [], fishAt = [];
    let prevB = [], drift = [], lastCh = -1, lastCrack = 0, lastBrk = 0, tipT = 0, infoT = 0, curH = 1 / 60, prevFloe = [], prevSeal = [], prevO = { st: 0, e: 0 }, prevV = [], ventAt = [], prevK = 0, prevW = 0, prevSn = 0, snowA = 0;
    const PT = makeParts();
    function me() { if (!st) return -1; for (let k = 0; k < st.n; k++) if (localHuman(k)) return k; return -1; } // one penguin per phone
    const ctl = () => (auto() ? -1 : me());
    const isBot = (k) => !!P(k).ai || auto() || (localHuman(k) && k !== me()); // extra people on this phone → AI 보통
    const lvOf = (k) => { const v = P(k).ai ? P(k).lv | 0 : 2; return v >= 1 && v <= 3 ? v : 2; };
    const sx = (x) => G.ox + x * G.s, sy = (y) => G.oy + y * G.s;

    const top = L.h('div', { class: 'hud top pg-top', style: { gap: '4px', flexWrap: 'nowrap', padding: '8px 8px' } });
    const hud = L.h('div', { class: 'hud bottom pg-hud', style: { flexWrap: 'nowrap', alignItems: 'stretch', padding: '8px 10px' } });
    const info = L.h('div', { class: 'panel pg-info', style: { flex: '1 1 auto', minWidth: '0', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: '2px', minHeight: '52px', padding: '6px 10px' } });
    const stLine = L.h('div', { class: 'mono', style: { fontSize: '11.5px', color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } });
    const hint = L.h('div', { style: { fontSize: '13px', fontWeight: 700, lineHeight: 1.3 } });
    info.append(stLine, hint);
    const dashBtn = L.h('button', { class: 'btn primary pg-dash', 'data-action': 'dash', 'aria-label': '배치기', style: { minWidth: '92px', minHeight: '52px', fontSize: '16px', touchAction: 'none', padding: '0 12px' }, text: '배치기' });
    dashBtn.addEventListener('pointerdown', (e) => { e.preventDefault(); doDash(); });
    hud.append(info, dashBtn);
    root.append(top, hud);

    /* ----- input: drag anywhere = stick, tap = walk there, 「배치기」 / second finger / Space = belly bump ----- */
    const locIn = { ax: 0, ay: 0 };
    let locDash = false, dashN = 0, stick = null, moveTo = null;
    function doDash() {
      const m = ctl(); if (m < 0 || phase !== 'play' || !wd || wd.pl[m].out || wd.pl[m].cd > 0) return;
      locDash = true; dashN = (dashN + 1) % 1000; api.buzz(12);
    }
    function onDown(ev) {
      if (ctl() < 0 || !G) return;
      const p = cv.local(ev);
      if (stick && stick.id !== ev.pointerId) { doDash(); return; }
      stick = { id: ev.pointerId, bx: p.x, by: p.y, x: p.x, y: p.y, t0: performance.now(), moved: false };
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) { /* ignore */ }
    }
    function onMove(ev) {
      if (!stick || ev.pointerId !== stick.id) return;
      const p = cv.local(ev); stick.x = p.x; stick.y = p.y;
      if (Math.hypot(p.x - stick.bx, p.y - stick.by) > 10) { stick.moved = true; moveTo = null; }
    }
    function onUp(ev) {
      if (!stick || ev.pointerId !== stick.id) return;
      if (!stick.moved && performance.now() - stick.t0 < 350) moveTo = { x: (stick.x - G.ox) / G.s, y: (stick.y - G.oy) / G.s };
      stick = null;
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    const keyOff = api.input ? api.input.on((type, id) => { if (type === 'down' && id === 'dash') doDash(); }) : null;
    function readInput() {
      let ax = 0, ay = 0;
      if (stick && stick.moved) {
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = Math.hypot(dx, dy);
        if (d > 8) { const m = Math.min(1, d / 42); ax = dx / d * m; ay = dy / d * m; }
      } else if (api.input) {
        const kx = api.input.axis('left', 'right'), ky = api.input.axis('up', 'down');
        if (kx || ky) { const m = Math.hypot(kx, ky); ax = m > 1 ? kx / m : kx; ay = m > 1 ? ky / m : ky; moveTo = null; }
      }
      if (!ax && !ay && moveTo && wd) {
        const m = ctl(), p = m >= 0 ? wd.pl[m] : null;
        if (!p || p.out) moveTo = null;
        else {
          const dx = moveTo.x - p.x, dy = moveTo.y - p.y, d = Math.hypot(dx, dy);
          if (d < 0.18) moveTo = null; else { const mm = Math.min(1, d / 0.7); ax = dx / d * mm; ay = dy / d * mm; }
        }
      }
      locIn.ax = ax; locIn.ay = ay;
    }

    /* ----- round start ----- */
    let pubT = 0, hsQ = 0, lastQ = -1, snaps = [], lastSig = '', inT = 0;
    function startRound() {
      key = st.g; wd = newWorld(st);
      aiMem = st.dead.map(() => ({})); remIn = {};
      shown = Int8Array.from(wd.ice); shownOut = wd.pl.map((p) => p.out); prevHc = wd.pl.map(() => 0); prevDn = wd.pl.map(() => 0); prevFe = wd.pl.map(() => 0);
      fallAt = wd.pl.map(() => -1e9); fallPos = wd.pl.map((p) => ({ x: p.x, y: p.y })); face = wd.pl.map((p) => (p.fx < 0 ? -1 : 1)); dashAt = wd.pl.map(() => -1e9);
      prevB = wd.bs.map(() => ({ st: 0, hit: 0 })); prevFloe = wd.fl.map((f) => f.hp > 0); prevSeal = wd.sl.map(() => ({ e: 0, e2: 0 })); prevO = { st: 0, e: wd.oc ? wd.oc.e : 0 }; prevV = wd.vs.map(() => 0); ventAt = wd.vs.map(() => -1e9);
      prevK = 0; prevW = 0; prevSn = 0; snowA = 0; fishAt = [];
      drift = []; PT.clear(); lastCh = wd.ch; chg.clear();
      sentEnd = !!st.over; sentDead = st.dead.join(','); moveTo = null; stick = null; locDash = false;
      phase = st.over ? 'end' : 'count'; cd = ctl() >= 0 ? 5 : 3; tipT = 5;
      snaps = []; lastQ = -1;
      tbb = null; cam.ok = false; fullPaint = true; CB = null;
      if (me() >= 0 && api.mySeats().length > 1 && !api.online) api.toast('실시간은 한 폰에 한 명만! 다른 사람 자리는 AI(보통)가 맡아요');
      layout();
      renderTop(); renderInfo(true);
    }

    /* ----- host: inputs, sim, state ----- */
    function inputsFor() {
      const out = [];
      for (let k = 0; k < wd.pl.length; k++) {
        if (wd.pl[k].out) { out[k] = null; continue; }
        if (isBot(k)) out[k] = aiThink(wd, k, aiMem[k], lvOf(k), curH);
        else if (k === me()) { out[k] = { ax: locIn.ax, ay: locIn.ay, dash: locDash }; locDash = false; }
        else { const Rr = remIn[k]; if (Rr) { out[k] = { ax: Rr.ax, ay: Rr.ay, dash: Rr.dash }; Rr.dash = false; } else out[k] = null; }
      }
      return out;
    }
    function hostFlow() {
      const dk = wd.dead.join(',');
      if (wd.res && !sentEnd) {
        sentEnd = true; phase = 'end'; sentDead = dk;
        busy = true; api.setBusy(true); clearTimeout(endTimer);
        endTimer = setTimeout(() => { if (busy) { busy = false; api.setBusy(false); } }, 1600 / SPD());
        api.setState(Object.assign({}, st, { dead: wd.dead.slice(), over: 1, tt: Math.round(wd.t), w: wd.res.w.slice(), cap: wd.res.cap ? 1 : 0,
          ss: { d: wd.pl.map((p) => p.dc | 0), h: wd.pl.map((p) => p.hn | 0), t: wd.pl.map((p) => Math.round(p.out ? p.ot || 0 : wd.t)) } }));
        return;
      }
      if (dk !== sentDead) { sentDead = dk; api.setState(Object.assign({}, st, { dead: wd.dead.slice() })); }
    }
    function pollHost() {
      if (!api.online || !api.isHost) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const kk in rem) {
        const k = +kk, o = rem[kk];
        if (!(k >= 0 && k < st.n) || isBot(k) || localHuman(k) || !o || typeof o !== 'object' || o.k !== key) continue;
        const Rr = remIn[k] || (remIn[k] = { ax: 0, ay: 0, dash: false, seen: -1 });
        Rr.ax = isFinite(+o.ax) ? U.clamp(+o.ax, -1, 1) : 0; Rr.ay = isFinite(+o.ay) ? U.clamp(+o.ay, -1, 1) : 0;
        const n = o.n | 0; if (Rr.seen >= 0 && n !== Rr.seen) Rr.dash = true; Rr.seen = n;
      }
    }
    const encode = () => encodeW(wd, { k: key, q: hsQ, ph: phase === 'count' ? 0 : phase === 'play' ? 1 : 2, c: Math.round(cd * 10) });
    /* ----- guest: mirror the host ----- */
    function pollGuest(now) {
      if (!api.online || api.isHost) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.P)) return;
      lastQ = hs.q;
      if (phase !== 'end' || hs.ph === 2) phase = hs.ph === 0 ? 'count' : hs.ph === 1 ? 'play' : 'end';
      cd = (hs.c | 0) / 10; wd.t = (hs.t | 0) / 10;
      if (typeof hs.I === 'string' && hs.I.length === N) for (let i = 0; i < N; i++) { const v = hs.I.charCodeAt(i) - 48; if (v !== wd.ice[i] && v >= 0 && v <= 4) { wd.ice[i] = v; wd.ch++; } }
      const A8 = hs.P;
      wd.pl.forEach((p, k) => {
        const o = k * 8; if (!isFinite(+A8[o])) return;
        const fl = A8[o + 4] | 0;
        p.out = fl & 1 ? 1 : p.out; p.dash = fl & 2 ? 0.1 : 0; p.stun = fl & 4 ? 0.1 : 0; p.pw = fl & 8 ? 1 : 0; p.hc = A8[o + 5] | 0; p.dn = A8[o + 6] | 0; p.fe = A8[o + 7] | 0;
        p.nx = A8[o] / 100; p.ny = A8[o + 1] / 100; p.nvx = A8[o + 2] / 100; p.nvy = A8[o + 3] / 100; p.nat = now;
      });
      snaps.push({ at: now, P: A8.slice() }); if (snaps.length > 6) snaps.shift();
      const B = hs.B;
      if (Array.isArray(B)) wd.bs.forEach((b, j) => {
        const o = j * 12; if (o + 11 >= B.length) return;
        const ns = B[o] | 0;
        b.nx = B[o + 1] / 100; b.ny = B[o + 2] / 100;
        if (ns !== b.st && (ns === 2 || b.st < 2 || b.st === 5)) { b.x = b.nx; b.y = b.ny; }
        b.st = ns; b.dx = B[o + 3] / 100; b.dy = B[o + 4] / 100; b.age = B[o + 5] ? 99 : 0; b.wx = B[o + 6] / 100; b.wy = B[o + 7] / 100; b.sw = B[o + 8] | 0; b.hit = B[o + 9] | 0; b.t = (B[o + 10] | 0) / 10; b.tgt = B[o + 11] | 0;
      });
      decodeGimmicks(wd, hs, now);
    }
    function guestStep(dt, rdt, now) {
      const m = ctl(), rt = now - 110;
      let A0 = null, Bs = snaps.length ? snaps[snaps.length - 1] : null, f = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A0 = snaps[i - 1]; Bs = snaps[i]; break; }
      if (A0) f = U.clamp((rt - A0.at) / Math.max(1, Bs.at - A0.at), 0, 1.2);
      wd.pl.forEach((p, k) => {
        if (!Bs) return;
        const o = k * 8;
        if (k === m && phase === 'play' && !p.out) { // predict my own penguin, then pull it toward the host's copy
          const n = Math.max(1, Math.ceil(dt / (1 / 60))), h = dt / n;
          const I = { ax: locIn.ax, ay: locIn.ay, dash: locDash }; locDash = false;
          const d0 = p.dash, s0 = p.stun, w0 = p.pw;
          for (let j = 0; j < n; j++) { movePeng(wd, p, I, h); I.dash = false; }
          if (p.dash <= 0) p.dash = Math.max(0, d0 - dt); if (s0 > 0) p.stun = s0; p.pw = w0;
          if (isFinite(p.nx)) {
            const age = Math.min(0.15, (now - p.nat) / 1000);
            const tx = p.nx + p.nvx * age, ty = p.ny + p.nvy * age, d = Math.hypot(tx - p.x, ty - p.y);
            if (d > 1.4) { p.x = tx; p.y = ty; p.vx = p.nvx; p.vy = p.nvy; }
            else { const kk = 1 - Math.exp(-rdt * (p.stun > 0 ? 14 : 6)); p.x += (tx - p.x) * kk; p.y += (ty - p.y) * kk; }
          }
          return;
        }
        const bx = Bs.P[o] / 100, by = Bs.P[o + 1] / 100;
        if (A0) { const ax = A0.P[o] / 100, ay = A0.P[o + 1] / 100; if (Math.hypot(bx - ax, by - ay) < 3) { p.x = ax + (bx - ax) * f; p.y = ay + (by - ay) * f; } else { p.x = bx; p.y = by; } }
        else { p.x = bx; p.y = by; }
        p.vx = Bs.P[o + 2] / 100; p.vy = Bs.P[o + 3] / 100;
      });
      for (const b of wd.bs) if (isFinite(b.nx)) { const kk = 1 - Math.exp(-rdt * 10); b.x += (b.nx - b.x) * kk; b.y += (b.ny - b.y) * kk; }
      guestGimmickStep(wd, rdt);
    }
    function publish(rdt) {
      if (!api.online || !wd) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20; hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(encode());
        } else {
          const m = ctl(); if (m < 0) return;
          const ax = Math.round(locIn.ax * 100) / 100, ay = Math.round(locIn.ay * 100) / 100, sig = ax + '|' + ay + '|' + dashN;
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0) return;
          lastSig = sig; inT = 0.25; pubT = 1 / 30;
          api.net.publish({ k: key, ax, ay, n: dashN });
        }
      } catch (e) { /* ignore */ }
    }

    /* ----- effects from world changes (same on host and guests) ----- */
    function effects(now) {
      const s = G.s, m = ctl();
      if (wd.ch !== lastCh) {
        lastCh = wd.ch;
        let drifted = 0, bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9;
        for (let i = 0; i < N; i++) {
          const a = shown[i], b = wd.ice[i];
          if (b) { if (XW[i] < bx0) bx0 = XW[i]; if (XW[i] > bx1) bx1 = XW[i]; if (YW[i] < by0) by0 = YW[i]; if (YW[i] > by1) by1 = YW[i]; }
          if (a === b) continue;
          shown[i] = b; chg.add(i);
          if (b >= a) continue;
          const x = sx(XW[i]), y = sy(YW[i]);
          if (b === 0 && a >= 2) {
            let vx = XW[i] - wd.cx, vy = YW[i] - wd.cy; const l = Math.hypot(vx, vy) || 1;
            if (drift.length < 40) drift.push({ i, cr: 4 - a, t: 0, vx: vx / l, vy: vy / l }); drifted++;
          } else if (b === 0) {
            PT.splash(x, y, false, s); PT.burst(x, y, 'shard', 10, s);
            if (now - lastBrk > 90) { api.sfx('pop'); lastBrk = now; }
          } else {
            PT.burst(x, y, 'shard', 3 + (4 - b) * 2, s);
            if (now - lastCrack > 140) { api.sfx('tick'); lastCrack = now; }
          }
        }
        if (bx0 <= bx1) tbb = { x0: bx0 - 1, y0: by0 - 1, x1: bx1 + 1, y1: by1 + 1 };
        if (drifted >= 2) { api.sfx('whoosh'); api.toast('얼음이 갈라져 조각이 떠내려가요!'); }
      }
      wd.pl.forEach((p, k) => {
        if (p.out && !shownOut[k]) {
          shownOut[k] = 1; fallAt[k] = now; fallPos[k] = { x: p.x, y: p.y };
          PT.splash(sx(p.x), sy(p.y), true, s); api.sfx('whoosh');
          if (k === m) api.buzz([30, 40, 60]);
          api.toast(nm(k) + ' 풍덩!'); renderTop();
        }
        if (p.hc !== prevHc[k]) { prevHc[k] = p.hc; PT.burst(sx(p.x), sy(p.y) - s * 0.6, 'shard', 6, s); api.sfx('hit'); if (k === m) api.buzz(30); }
        if (p.dn !== prevDn[k]) { prevDn[k] = p.dn; dashAt[k] = now; if (k === m) api.sfx('whoosh'); }
        if (p.fe !== prevFe[k]) { prevFe[k] = p.fe; fishAt[k] = now; PT.burst(sx(p.x), sy(p.y) - s * 0.8, 'shard', 8, s); api.sfx('pop'); if (k === m) { api.buzz(20); api.toast('힘 물고기! 5초 동안 빠르고 배치기가 자주 돼요'); } }
        if (Math.abs(p.vx) > 0.3) face[k] = p.vx > 0 ? 1 : -1;
      });
      wd.bs.forEach((b, j) => {
        const pb = prevB[j];
        if (b.st !== pb.st) {
          const two = wd.bs.length > 1;
          if (b.st === 1) { api.sfx('tick'); api.buzz(15); api.toast(pb.st === 5 ? '북극곰이 다시 올라오려고 해요!' : two && j === 1 ? '두 번째 북극곰이 다가와요!' : '북극곰이 다가와요! 물보라를 조심!'); }
          if (b.st === 2 && (pb.st === 1 || pb.st === 0 || pb.st === 5)) { b.inAt = now; PT.splash(sx(b.x), sy(b.y), true, s); api.sfx('thud'); api.buzz([30, 40, 30]); api.toast('북극곰 등장!'); }
          if (b.st === 3 && b.tgt === m) api.buzz(20);
          if (b.st === 5) { b.outAt = now; b.outPos = { x: b.x, y: b.y }; PT.splash(sx(b.x), sy(b.y), true, s); api.sfx('thud'); api.toast('북극곰이 풍덩! 잠시 뒤 다시 와요'); }
          pb.st = b.st;
        }
        if (b.hit !== pb.hit) { pb.hit = b.hit; api.sfx('thud'); }
      });
      wd.fl.forEach((f, j) => {
        const on = f.hp > 0;
        if (on !== prevFloe[j]) { prevFloe[j] = on; if (!on) { PT.splash(sx(f.x), sy(f.y), true, s); api.sfx('pop'); } else PT.ring(sx(f.x), sy(f.y), 2, s); }
      });
      wd.sl.forEach((q, j) => {
        const ps = prevSeal[j];
        if (q.e !== ps.e) { ps.e = q.e; PT.splash(sx(q.x), sy(q.y), false, s); api.sfx('whoosh'); }
        if (q.e2 !== ps.e2) { ps.e2 = q.e2; PT.splash(sx(q.x), sy(q.y), false, s); }
      });
      if (wd.oc) {
        const q = wd.oc;
        if (q.st !== prevO.st) { if (q.st === 1) { api.sfx('tick'); api.toast('범고래 지느러미! 빨간 물가 칸에서 물러나요'); } if (q.st === 2) PT.splash(sx(q.x), sy(q.y), false, s); prevO.st = q.st; }
        if (q.e !== prevO.e) { prevO.e = q.e; if (q.ti >= 0) { PT.splash(sx(XW[q.ti]), sy(YW[q.ti]), true, s); PT.burst(sx(XW[q.ti]), sy(YW[q.ti]), 'shard', 10, s); } api.sfx('thud'); api.buzz([25, 30, 25]); }
      }
      wd.vs.forEach((v, j) => { if (v.e !== prevV[j]) { prevV[j] = v.e; ventAt[j] = now; PT.burst(sx(XW[v.i]), sy(YW[v.i]), 'drop', 18, s); api.sfx('whoosh'); api.buzz(18); } });
      const ib = wd.ib;
      if (ib.st !== prevK) { if (ib.st === 1) { api.toast('빙산이 굴러와요! 빨간 길에서 비켜요'); api.sfx('tick'); } if (ib.st === 2) { api.sfx('thud'); api.buzz(25); } prevK = ib.st; }
      if (wd.wn.st !== prevW) { if (wd.wn.st === 1) { api.toast('돌풍이 불어요! 화살표 쪽으로 밀려요'); api.sfx('whoosh'); } prevW = wd.wn.st; }
      if (wd.sn.st !== prevSn) { if (wd.sn.st === 1) { api.toast('눈보라가 몰려와요! 앞이 잘 안 보여요'); api.sfx('whoosh'); } prevSn = wd.sn.st; }
    }

    /* ----- HUD ----- */
    function renderTop() {
      if (!st || !wd) { top.innerHTML = ''; return; }
      chipsInto(top, st.n, (k) => wd.pl[k].out, (k) => k === ctl() && !wd.pl[k].out, col, nm, st.tm);
    }
    const mmss = (t) => Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0');
    function renderInfo(force) {
      if (!st || !wd) return;
      let bt = '';
      const on = wd.bs.filter(bearOn), b0 = wd.bs[0];
      if (wd.bs.some((b) => b.st === 1)) bt = '물보라! 곧 곰이 와요';
      else if (on.length) bt = (on.length > 1 ? '곰 두 마리' : on.some((b) => b.age > RT.ANGRYT) ? '곰 화남! 빨라요' : '북극곰 출몰');
      else if (b0.st === 0) bt = '곰까지 ' + Math.max(0, Math.ceil(b0.at0 - wd.t)) + '초';
      else bt = '곰이 빠졌어요 · 곧 다시 와요';
      const sl = '⏱ ' + mmss(wd.t) + ' · ' + bt + (wd.t > wd.meltAt ? ' · 얼음이 녹아요' : ' · ' + LAYS[st.lay].name);
      if (force || stLine.textContent !== sl) stLine.textContent = sl;
      const m = ctl();
      let ht = '', color = '';
      if (phase === 'end' || st.over) ht = '경기 끝!';
      else if (m < 0) ht = auto() || me() < 0 ? '관전 중 · 마지막까지 남는 펭귄은?' : '';
      else if (wd.pl[m].out) ht = '풍덩! 남은 펭귄들을 지켜봐요';
      else if (phase === 'count') ht = '곧 시작해요!';
      else {
        const p = wd.pl[m], t = tileAt(p.x, p.y), onT = t >= 0 && wd.ice[t] > 0;
        let swing = false;
        for (const b of wd.bs) { if (b.st !== 3) continue; const rx = p.x - b.x, ry = p.y - b.y, bd = Math.hypot(rx, ry) || 1; if (bd < RT.REACH + 0.5 && (rx * b.dx + ry * b.dy) / bd > 0.3) swing = true; }
        let lane = false; const ib = wd.ib;
        if ((ib.st === 1 || ib.st === 2) && laneHit(p.x, p.y, ib.x, ib.y, ib.dx, ib.dy, RT.IR + 0.5)) lane = '빙산';
        for (const s of wd.sl) if ((s.st === 1 || s.st === 2) && laneHit(p.x, p.y, s.x, s.y, s.dx, s.dy, 0.9)) lane = '물개';
        let orc = false; const oq = wd.oc; if (oq && (oq.st === 1 || oq.st === 2) && oq.ti >= 0 && Math.hypot(p.x - XW[oq.ti], p.y - YW[oq.ti]) < 1.6) orc = true;
        let vent = false; for (const v of wd.vs) if (v.st === 1 && Math.hypot(XW[v.i] - p.x, YW[v.i] - p.y) < 1.5) vent = true;
        if (swing) { ht = '곰이 앞발을 들었어요! 옆으로 피해요'; color = 'var(--coral)'; }
        else if (lane) { ht = lane + '이 지나가요! 옆으로 비켜요'; color = 'var(--coral)'; }
        else if (vent) { ht = '간헐천이 곧 터져요! 얼른 비켜요'; color = 'var(--coral)'; }
        else if (orc) { ht = '범고래가 이 물가로 와요! 안쪽으로 물러나요'; color = 'var(--coral)'; }
        else if (!onT) { ht = '유빙 위! 오래 있으면 가라앉아요'; color = 'var(--coral)'; }
        else if (wd.ice[t] === 1) { ht = '발밑 얼음이 곧 깨져요! 움직여요'; color = 'var(--coral)'; }
        else if (wd.wn.st === 1) ht = '돌풍이 와요! 물가에서 떨어지세요';
        else if (p.pw > 0) ht = '힘 물고기! 빠르고 배치기가 자주 돼요';
        else if (wd.sp[t] === SP_G) ht = '미끄럼 빙판! 잘 안 멈춰요';
        else if (wd.sp[t] === SP_N) ht = '눈 덮인 얼음 · 걸음이 느려져요';
        else if (wd.sp[t] === SP_K && wd.ice[t] >= 3) ht = '두꺼운 얼음 · 금이 천천히 가요';
        else if (wd.ice[t] === 2) ht = '발밑에 금이 갔어요 · 튼튼한 얼음으로';
        else ht = '끌어서 걷기 · 「배치기」로 밀기';
      }
      if (hint.textContent !== ht) hint.textContent = ht;
      hint.style.color = color;
      const showBtn = m >= 0 && phase !== 'end' && !wd.pl[m].out;
      dashBtn.hidden = !showBtn;
      if (showBtn) { const ready = phase === 'play' && wd.pl[m].cd <= 0; dashBtn.style.opacity = ready ? '1' : '0.5'; }
    }

    /* ----- camera: fit the remaining ice and every penguin/bear into the pool, zooming in as the field shrinks ----- */
    function layout() {
      const th = st && st.n > 4 ? 72 : TOPH;
      A = { x: 6, y: th + 2, w: Math.max(60, cv.w - 12), h: Math.max(60, cv.h - th - BOTH - 6) };
      bgKey = ''; fullPaint = true;
      if (wd && !tbb) { const b = wd.bb; tbb = { x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1 }; }
      if (wd) { camUpdate(1, true); }
    }
    function camTarget() {
      let x0 = tbb.x0, y0 = tbb.y0, x1 = tbb.x1, y1 = tbb.y1;
      const add = (x, y) => { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; };
      for (const p of wd.pl) if (!p.out) add(p.x, p.y);
      for (const b of wd.bs) if (bearOn(b)) add(b.x, b.y);
      for (const f of wd.fl) if (f.hp > 0 && f.m !== 2) { add(f.x - 1, f.y - 1); add(f.x + 1, f.y + 1); }
      x0 -= 0.5; x1 += 0.5; y0 -= 1.6; y1 += 0.6;
      const fit = Math.min(A.w / (x1 - x0), A.h / (y1 - y0));
      const s = Math.min(fit, cam.max || fit);
      return { s, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
    }
    function camUpdate(rdt, snap) {
      if (!tbb) return;
      if (!cam.ok || snap) {
        cam.max = 0; const T0 = camTarget();
        cam.max = Math.min(46, T0.s * 2.2);
      }
      const T = camTarget();
      if (!cam.ok || snap) { cam.s = T.s; cam.cx = T.cx; cam.cy = T.cy; cam.ok = true; }
      else { const k = 1 - Math.exp(-rdt * 1.6); cam.s += (T.s - cam.s) * k; cam.cx += (T.cx - cam.cx) * k; cam.cy += (T.cy - cam.cy) * k; }
      G = { s: cam.s, ox: A.x + A.w / 2 - cam.cx * cam.s, oy: A.y + A.h / 2 - cam.cy * cam.s };
    }

    /* ----- drawing ----- */
    function ensureBg() {
      const kk = cv.w + 'x' + cv.h + ':' + cv.dpr;
      if (kk === bgKey) return;
      bgKey = kk;
      bgc.width = Math.round(cv.w * cv.dpr); bgc.height = Math.round(cv.h * cv.dpr);
      gctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      paintPool(gctx, cv.w, cv.h, A);
    }
    function ensureBoard() {
      if (!CB) {
        const b = wd.bb, x0 = b.x0 - 0.6, y0 = b.y0 - 0.6, w = b.x1 - b.x0 + 1.2, h = b.y1 - b.y0 + 1.6;
        const cs = Math.max(4, Math.min((cam.max || 30) * Math.min(cv.dpr || 1, 2), 2048 / w, 2048 / h));
        CB = { x0, y0, w, h, cs };
        board.width = Math.ceil(w * cs); board.height = Math.ceil(h * cs);
        fullPaint = true;
      }
      if (fullPaint) { fullPaint = false; chg.clear(); paintTiles(null); return; }
      if (!chg.size) return;
      if (chg.size > 14) { chg.clear(); paintTiles(null); return; }
      for (const i of chg) paintTiles(i);
      chg.clear();
    }
    const crOf = (i) => (shown[i] ? 4 - shown[i] : -1);
    function paintTiles(only) {
      const cs = CB.cs, Gc = { s: cs, ox: -CB.x0 * cs, oy: -CB.y0 * cs }, c = bctx;
      c.setTransform(1, 0, 0, 1, 0, 0);
      let near = null;
      if (only == null) c.clearRect(0, 0, board.width, board.height);
      else {
        const X = Gc.ox + XW[only] * cs, Y = Gc.oy + YW[only] * cs;
        const rx0 = Math.floor(X - 1.05 * cs), ry0 = Math.floor(Y - 1.05 * cs), rx1 = Math.ceil(X + 1.05 * cs), ry1 = Math.ceil(Y + 1.55 * cs);
        c.save(); c.beginPath(); c.rect(rx0, ry0, rx1 - rx0, ry1 - ry0); c.clip();
        c.clearRect(rx0, ry0, rx1 - rx0, ry1 - ry0);
        near = (j) => Math.abs(XW[j] - XW[only]) < 3.3 && Math.abs(YW[j] - YW[only]) < 3.4;
      }
      for (let i = 0; i < N; i++) {
        if (near && !near(i)) continue;
        if (wd.sp[i] === SP_H && !shown[i]) drawHole(c, Gc.ox + XW[i] * cs, Gc.oy + YW[i] * cs, cs);
        if (crOf(i) < 0) continue;
        c.fillStyle = 'rgba(0,10,25,.35)'; hexPath(c, Gc.ox + XW[i] * cs + cs * 0.08, Gc.oy + YW[i] * cs + cs * 0.4, cs * 0.98); c.fill();
      }
      for (let i = 0; i < N; i++) { if (near && !near(i)) continue; const cr = crOf(i); if (cr >= 0) drawTileSp(c, i, Gc.ox + XW[i] * cs, Gc.oy + YW[i] * cs, cs, cr, wd.sp[i], wd.t >= wd.meltAt); }
      if (only != null) c.restore();
    }
    const ease = (t) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
    function draw(now) {
      if (!G || !wd) { cv.clear(); return; }
      ensureBg(); ensureBoard();
      ctx.drawImage(bgc, 0, 0, cv.w, cv.h);
      const s = G.s, t = now, m = ctl(), u = Math.max(s * 0.46, 7.2);
      ctx.save();
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(A.x, A.y, A.w, A.h, 18); else ctx.rect(A.x, A.y, A.w, A.h); ctx.clip();
      ctx.strokeStyle = 'rgba(170,220,255,.10)'; ctx.lineWidth = 1.5;
      for (let k = 0; k < 10; k++) {
        const y = A.y + ((k * 97 + t * 0.012) % A.h), x = A.x + ((k * 151) % A.w);
        ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 14, y - 3 + Math.sin(t / 600 + k) * 2, x + 30, y); ctx.stroke();
      }
      ctx.drawImage(board, 0, 0, board.width, board.height, sx(CB.x0), sy(CB.y0), CB.w * s, CB.h * s);
      // floes (drifting ice you can stand on)
      wd.fl.forEach((f, j) => {
        if (f.hp <= 0) return;
        const cr = f.hp > 2.2 ? 0 : f.hp > 1.4 ? 1 : f.hp > 0.7 ? 2 : 3, bob = Math.sin(t / 500 + j * 2) * s * 0.05;
        const fx = sx(f.x), fy = sy(f.y) + bob, fo = 0.5 + 0.5 * Math.sin(t / 300 + j);
        ctx.strokeStyle = 'rgba(225,245,255,' + (0.35 + 0.3 * fo).toFixed(3) + ')'; ctx.lineWidth = Math.max(1.5, s * 0.08);
        ctx.beginPath(); ctx.ellipse(fx, fy + s * 0.35, s * (1.05 + 0.08 * fo), s * (0.5 + 0.04 * fo), 0, 0, 7); ctx.stroke();
        ctx.fillStyle = 'rgba(0,10,25,.3)'; hexPath(ctx, fx + 2, fy + s * 0.4, s * 0.92); ctx.fill();
        drawTile(ctx, 900 + j, fx, fy, s * 0.92, cr, 1, FLOE_COL);
        const vm = Math.hypot(f.vx, f.vy);
        if (vm > 0.2 && vm < 9) { // 흘러가는 방향 예고
          const ux = f.vx / vm, uy = f.vy / vm, ax = fx + ux * s * 1.25, ay = fy + uy * s * 1.25, hl = s * 0.3;
          ctx.fillStyle = 'rgba(225,245,255,' + (0.5 + 0.3 * fo).toFixed(3) + ')';
          ctx.beginPath(); ctx.moveTo(ax + ux * hl, ay + uy * hl); ctx.lineTo(ax - uy * hl * 0.6, ay + ux * hl * 0.6); ctx.lineTo(ax + uy * hl * 0.6, ay - ux * hl * 0.6); ctx.closePath(); ctx.fill();
        }
      });
      for (const d of drift) {
        const f = Math.min(1, d.t / 1.2), e = ease(f);
        drawTile(ctx, d.i, sx(XW[d.i]) + d.vx * s * 1.8 * e, sy(YW[d.i]) + d.vy * s * 1.8 * e + s * 0.3 * e, s * (1 - 0.15 * f), d.cr, f > 0.5 ? Math.max(0, 1 - (f - 0.5) / 0.5) : 1);
      }
      for (let k = 0; k < wd.pl.length; k++) if (shownOut[k] && t - fallAt[k] > 600) drawHatC(ctx, sx(fallPos[k].x), sy(fallPos[k].y) + s * 0.1, col(k), u * 0.92, t, k);
      const pulse = 0.5 + 0.5 * Math.sin(t / 110);
      // geysers: bubbling warning, steam blast
      wd.vs.forEach((v, j) => {
        if (v.st === 3) return;
        const x = sx(XW[v.i]), y = sy(YW[v.i]);
        if (v.st === 1) {
          ctx.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.5 * pulse).toFixed(3) + ')'; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.arc(x, y, s * 1.35, 0, 7); ctx.stroke();
          ctx.fillStyle = 'rgba(235,248,255,.8)';
          for (let k = 0; k < 5; k++) { const f = ((t / 500) + k / 5) % 1; ctx.beginPath(); ctx.arc(x + Math.sin(k * 2.3 + t / 200) * s * 0.25, y - f * s * 0.9, s * (0.06 + 0.05 * (1 - f)), 0, 7); ctx.fill(); }
        }
        const f = (t - ventAt[j]) / 1100;
        if (f >= 0 && f < 1) {
          for (let k = 0; k < 7; k++) {
            const h = (f * 2.4 + k * 0.12) % 1.2;
            ctx.fillStyle = 'rgba(240,250,255,' + (0.75 * (1 - f) * (1 - h / 1.2)).toFixed(3) + ')';
            ctx.beginPath(); ctx.ellipse(x + Math.sin(k * 1.7) * s * 0.2, y - h * s * 2.6, s * (0.3 + h * 0.45), s * (0.22 + h * 0.3), 0, 0, 7); ctx.fill();
          }
        }
      });
      for (const mm of wd.mw) if (shown[mm.i]) meltMark(ctx, sx(XW[mm.i]), sy(YW[mm.i]), s, t);
      // weak ice under penguins
      for (let k = 0; k < wd.pl.length; k++) {
        const p = wd.pl[k]; if (p.out) continue;
        const ti = tileAt(p.x, p.y); if (ti < 0 || !shown[ti]) continue;
        if (k === m) { hexPath(ctx, sx(XW[ti]), sy(YW[ti]), s * 0.86); ctx.lineWidth = 2.5; ctx.strokeStyle = hexA(col(k), 0.85); ctx.stroke(); }
        if (shown[ti] === 1) { hexPath(ctx, sx(XW[ti]), sy(YW[ti]), s * 0.8); ctx.setLineDash([5, 4]); ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(238,106,85,' + (0.45 + 0.55 * pulse).toFixed(3) + ')'; ctx.stroke(); ctx.setLineDash([]); }
      }
      for (const b of wd.bs) {
        if (b.st === 1) {
          let wx = sx(b.wx), wy = sy(b.wy);
          const wi = tileAt(b.wx, b.wy);
          if (wi >= 0) for (let d = 0; d < 6; d++) { const n = NB[wi * 6 + d]; if (n < 0 || !shown[n]) { const a = [0, -60, -120, 180, 120, 60][d] * Math.PI / 180; wx += Math.cos(a) * s * 0.85; wy += Math.sin(a) * s * 0.85; break; } }
          for (let k = 0; k < 3; k++) {
            const f = ((t / 900) + k / 3) % 1;
            ctx.strokeStyle = 'rgba(255,140,110,' + (0.8 * (1 - f)).toFixed(3) + ')'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.ellipse(wx, wy, s * (0.2 + f * 0.7), s * (0.08 + f * 0.28), 0, 0, 7); ctx.stroke();
          }
          hexPath(ctx, sx(b.wx), sy(b.wy), s * 0.86); ctx.setLineDash([5, 4]); ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.5 * pulse).toFixed(3) + ')'; ctx.stroke(); ctx.setLineDash([]);
          bubbleC(ctx, Math.max(s, 16), sx(b.wx), sy(b.wy) - s * 0.15 - pulse * s * 0.12, '!', '#ee6a55');
        }
        if (b.st === 3) { // the swipe zone (dodge it!)
          const a = Math.atan2(b.dy, b.dx), r = RT.REACH * s;
          ctx.save(); ctx.translate(sx(b.x), sy(b.y));
          ctx.fillStyle = 'rgba(238,106,85,' + (0.18 + 0.2 * pulse).toFixed(3) + ')'; ctx.strokeStyle = 'rgba(238,106,85,.9)'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(0, 0); ctx.arc(0, 0, r, a - 1.13, a + 1.13); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.restore();
        }
      }
      // telegraphed lanes: iceberg (wide) and seals (narrow)
      const lane = (x, y, dx, dy, len, w, a0) => {
        ctx.save(); ctx.translate(sx(x), sy(y)); ctx.rotate(Math.atan2(dy, dx));
        ctx.fillStyle = 'rgba(238,106,85,' + a0.toFixed(3) + ')'; ctx.fillRect(0, -w * s, len * s, 2 * w * s);
        ctx.strokeStyle = 'rgba(238,106,85,.75)'; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
        ctx.beginPath(); ctx.moveTo(0, -w * s); ctx.lineTo(len * s, -w * s); ctx.moveTo(0, w * s); ctx.lineTo(len * s, w * s); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = 'rgba(255,220,210,.85)';
        for (let q = 0; q < len; q += 2.2) { const xx = ((q + t / 300) % len) * s; ctx.beginPath(); ctx.moveTo(xx + w * s * 0.5, 0); ctx.lineTo(xx - w * s * 0.2, -w * s * 0.5); ctx.lineTo(xx - w * s * 0.2, w * s * 0.5); ctx.closePath(); ctx.fill(); }
        ctx.restore();
      };
      const ib = wd.ib;
      if (ib.st === 1) lane(ib.x, ib.y, ib.dx, ib.dy, ib.len, RT.IR, 0.12 + 0.1 * pulse);
      if (ib.st === 2) lane(ib.x, ib.y, ib.dx, ib.dy, Math.max(0, ib.len - ib.d), RT.IR, 0.08);
      if (wd.oc && wd.oc.st >= 1 && wd.oc.st <= 3 && wd.oc.ti >= 0) {
        const ti = wd.oc.ti, x = sx(XW[ti]), y = sy(YW[ti]);
        hexPath(ctx, x, y, s * 0.86); ctx.fillStyle = 'rgba(238,106,85,' + (0.12 + 0.14 * pulse).toFixed(3) + ')'; ctx.fill();
        ctx.setLineDash([5, 4]); ctx.lineWidth = 2.5; ctx.strokeStyle = 'rgba(238,106,85,' + (0.5 + 0.5 * pulse).toFixed(3) + ')'; ctx.stroke(); ctx.setLineDash([]);
        if (wd.oc.st === 2) { ctx.fillStyle = 'rgba(220,240,255,.8)'; for (let k = 0; k < 5; k++) { const f = ((t / 300) + k / 5) % 1; ctx.beginPath(); ctx.arc(sx(wd.oc.x) + Math.sin(k * 2.3 + t / 120) * s * 0.4, sy(wd.oc.y) - f * s * 0.7, s * 0.08, 0, 7); ctx.fill(); } }
      }
      for (const q of wd.sl) if (q.st === 1) {
        lane(q.x, q.y, q.dx, q.dy, 9, 0.55, 0.1 + 0.1 * pulse);
        ctx.fillStyle = 'rgba(220,240,255,.8)';
        for (let k = 0; k < 4; k++) { const f = ((t / 380) + k / 4) % 1; ctx.beginPath(); ctx.arc(sx(q.x) + Math.sin(k * 2 + t / 150) * s * 0.3, sy(q.y) - f * s * 0.5, s * 0.07, 0, 7); ctx.fill(); }
      }
      if (moveTo && m >= 0 && !wd.pl[m].out) {
        const x = sx(moveTo.x), y = sy(moveTo.y);
        ctx.strokeStyle = hexA(col(m), 0.9); ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.ellipse(x, y, s * 0.35, s * 0.17, 0, 0, 7); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(x - s * 0.15, y); ctx.lineTo(x + s * 0.15, y); ctx.moveTo(x, y - s * 0.08); ctx.lineTo(x, y + s * 0.08); ctx.stroke();
      }
      const spr = [];
      wd.fs.forEach((f, j) => {
        if (f.t > 0) {
          const g = 1 - f.t / 0.7, x = sx(f.sx + (f.x - f.sx) * g), y = sy(f.sy + (f.y - f.sy) * g) - Math.sin(g * Math.PI) * s * 1.6;
          spr.push({ y: sy(f.y), f: () => drawFish(ctx, x, y, u, t, j) });
        } else {
          const x = sx(f.x), y = sy(f.y);
          spr.push({ y, f: () => {
            ctx.strokeStyle = 'rgba(255,214,120,' + (0.4 + 0.4 * pulse).toFixed(3) + ')'; ctx.lineWidth = 2;
            ctx.beginPath(); ctx.ellipse(x, y, s * 0.42, s * 0.18, 0, 0, 7); ctx.stroke();
            drawFish(ctx, x, y - u * 0.25, u, t, j);
          } });
        }
      });
      for (let k = 0; k < wd.pl.length; k++) {
        const p = wd.pl[k];
        if (p.out) {
          const f = (t - fallAt[k]) / 650;
          if (f < 0 || f >= 1) continue;
          const x = sx(fallPos[k].x), y = sy(fallPos[k].y);
          spr.push({ y, f: () => drawPeng(ctx, x, y + f * s * 0.8, col(k), u, { face: face[k], alpha: 1 - f, tilt: Math.sin(f * 20) * 0.3, flap: 1.2 * Math.sin(f * 25), dazed: true }) });
          continue;
        }
        const x = sx(p.x), y = sy(p.y), sp = Math.min(1, Math.hypot(p.vx, p.vy) / RT.VMAX), ph = t / 75 + k * 2;
        const slide = p.dash > 0 || t - dashAt[k] < 300;
        const o = slide ? { face: face[k], tilt: face[k] * 1.15, lift: 0, flap: -0.9 }
          : { face: face[k], tilt: Math.sin(ph) * 0.14 * sp + (p.stun > 0 ? Math.sin(t / 50) * 0.25 : 0), lift: Math.abs(Math.sin(ph)) * s * 0.08 * sp, flap: Math.sin(ph * 1.3) * 0.45 * sp, dazed: p.stun > 0, sq: Math.sin(t / 420 + k * 1.7) * 0.03 * (1 - sp) };
        spr.push({ y, f: () => {
          if (p.pw > 0) { ctx.strokeStyle = 'rgba(255,200,90,' + (0.55 + 0.4 * pulse).toFixed(3) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.ellipse(x, y, u * 1.25, u * 0.5, 0, 0, 7); ctx.stroke(); }
          if (k === m) { // my marker
            const by = y - u * 3.35 - Math.abs(Math.sin(t / 260)) * u * 0.3;
            ctx.fillStyle = col(k); ctx.strokeStyle = 'rgba(18,14,25,.7)'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(x - u * 0.42, by - u * 0.45); ctx.lineTo(x + u * 0.42, by - u * 0.45); ctx.lineTo(x, by); ctx.closePath(); ctx.fill(); ctx.stroke();
          }
          if (st.tm) o.tc = TC[st.tm[k]];
          drawPeng(ctx, x, y, col(k), u, o);
        } });
      }
      wd.bs.forEach((b) => {
        if (bearOn(b)) {
          const x = sx(b.x), y = sy(b.y), fi = Math.min(1, (t - (b.inAt || -1e9)) / 700);
          const bf = b.dx >= 0 ? 1 : -1, sp = Math.min(1, Math.hypot(b.vx || 0, b.vy || 0) / RT.BSPD);
          const swipe = b.st === 3 ? -0.4 : b.st === 4 ? Math.max(0, 1 - (0.7 - b.t) * 2.5) : 0;
          spr.push({ y, f: () => drawBearC(ctx, x, y + (1 - ease(fi)) * s, Math.max(s * 0.5, 7.8), { face: bf, alpha: Math.min(1, fi * 2), tilt: Math.sin(t / 120) * 0.06 * sp, lift: Math.abs(Math.sin(t / 120)) * s * 0.06 * sp + (b.st === 3 ? s * 0.12 : 0), swipe, angry: b.age > RT.ANGRYT }) });
        } else if (b.st === 5 && b.outPos && t - b.outAt < 800) {
          const f = (t - b.outAt) / 800, x = sx(b.outPos.x), y = sy(b.outPos.y);
          spr.push({ y, f: () => drawBearC(ctx, x, y + f * s, Math.max(s * 0.5, 7.8), { alpha: 1 - f, tilt: Math.sin(f * 16) * 0.2 }) });
        }
      });
      if (wd.oc && wd.oc.st > 0) {
        const q = wd.oc, x = sx(q.x), y = sy(q.y), dir = q.dx >= 0 ? 1 : -1;
        if (q.st === 3) spr.push({ y, f: () => drawOrca(ctx, x, y, s * 0.75, dir, 1 - Math.max(0, q.t) / 0.25 * 0.5, 1) });
        else spr.push({ y: y - s, f: () => drawFin(ctx, x, y, s * 0.8, q.st === 4 ? -dir : dir, t, q.st === 4 ? Math.min(1, q.t / 0.8) : 1) });
      }
      for (const q of wd.sl) if (q.st === 2) { const x = sx(q.x), y = sy(q.y); spr.push({ y, f: () => drawSeal(ctx, x, y, u * 0.95, q.dx, q.dy, t) }); }
      if (ib.st === 2) { const x = sx(ib.x), y = sy(ib.y); spr.push({ y, f: () => drawBerg(ctx, x, y, s * RT.IR * 1.05, ib.d * 0.9) }); }
      spr.sort((a, c) => a.y - c.y);
      for (const q of spr) q.f();
      PT.draw(ctx, s);
      // wind: arrows while it builds up, streaks while it blows
      const w = wd.wn;
      if (w.st === 1 || w.st === 2) {
        const a = Math.atan2(w.dy, w.dx);
        if (w.st === 1) {
          ctx.save(); ctx.translate(A.x + A.w / 2, A.y + A.h / 2); ctx.rotate(a);
          ctx.fillStyle = 'rgba(242,233,216,' + (0.35 + 0.45 * pulse).toFixed(3) + ')';
          for (let k = -1; k <= 1; k++) { const xx = k * 46; ctx.beginPath(); ctx.moveTo(xx + 22, 0); ctx.lineTo(xx - 6, -16); ctx.lineTo(xx, 0); ctx.lineTo(xx - 6, 16); ctx.closePath(); ctx.fill(); }
          ctx.restore();
        }
        ctx.strokeStyle = 'rgba(235,245,255,' + (w.st === 2 ? 0.55 : 0.22).toFixed(3) + ')'; ctx.lineWidth = 1.6;
        const L0 = Math.max(A.w, A.h) * 1.2, sp2 = w.st === 2 ? 1.4 : 0.4;
        for (let k = 0; k < 26; k++) {
          const ph = ((k * 0.618 + t / 1000 * sp2) % 1), off = ((k * 0.377) % 1 - 0.5) * L0;
          const cxm = A.x + A.w / 2 + Math.cos(a) * (ph - 0.5) * L0 - Math.sin(a) * off, cym = A.y + A.h / 2 + Math.sin(a) * (ph - 0.5) * L0 + Math.cos(a) * off;
          ctx.beginPath(); ctx.moveTo(cxm, cym); ctx.lineTo(cxm - Math.cos(a) * 26, cym - Math.sin(a) * 26); ctx.stroke();
        }
      }
      // snowstorm: white-out with a small clear circle around my penguin
      const sn = wd.sn, targ = sn.st === 2 ? 1 : sn.st === 1 ? 0.35 : 0;
      snowA += (targ - snowA) * Math.min(1, 0.05 * (L.debug.speed || 1));
      if (snowA > 0.02) {
        const p = m >= 0 && !wd.pl[m].out ? wd.pl[m] : null;
        if (p) {
          const x = sx(p.x), y = sy(p.y) - s * 0.5, g = ctx.createRadialGradient(x, y, s * 2.0, x, y, s * 4.6);
          g.addColorStop(0, 'rgba(226,236,246,0)'); g.addColorStop(1, 'rgba(226,236,246,' + (0.93 * snowA).toFixed(3) + ')');
          ctx.fillStyle = g;
        } else ctx.fillStyle = 'rgba(226,236,246,' + (0.5 * snowA).toFixed(3) + ')';
        ctx.fillRect(A.x, A.y, A.w, A.h);
        ctx.fillStyle = 'rgba(255,255,255,' + (0.85 * snowA).toFixed(3) + ')';
        const a = Math.atan2(sn.dy, sn.dx);
        for (let k = 0; k < 70; k++) {
          const ph = ((k * 0.618 + t / 2600) % 1), off = ((k * 0.377) % 1);
          const x = A.x + ((off * A.w + Math.cos(a) * ph * A.w * 0.6 + A.w * 2) % A.w), y = A.y + ((ph * A.h + Math.sin(a) * off * 40 + A.h * 2) % A.h);
          ctx.beginPath(); ctx.arc(x, y, 1.2 + (k % 3) * 0.6, 0, 7); ctx.fill();
        }
      }
      ctx.restore();
      if (stick && stick.moved) {
        ctx.strokeStyle = 'rgba(242,233,216,.5)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(stick.bx, stick.by, 42, 0, 7); ctx.stroke();
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = Math.hypot(dx, dy), kx = d > 42 ? dx / d * 42 : dx, ky = d > 42 ? dy / d * 42 : dy;
        ctx.fillStyle = 'rgba(242,233,216,.35)'; ctx.beginPath(); ctx.arc(stick.bx + kx, stick.by + ky, 18, 0, 7); ctx.fill();
      }
      if (phase === 'count' || phase === 'wait') {
        const n = Math.max(1, Math.ceil(cd)), cxm = cv.w / 2, cym = A.y + A.h * 0.42;
        ctx.fillStyle = 'rgba(18,14,25,.7)';
        const tips = tipT > 0 && cd > 1.2, mine = ctl() >= 0;
        const gml = (st.gm || []).map((g) => GMN[g]).filter(Boolean);
        const lines = tips ? (mine ? ['끌어서 걷기 · 탭하면 그곳으로', '「배치기」(두 번째 손가락 탭)로 밀치기', '오래 서 있는 얼음은 금이 가다 깨져요!'] : []) : [];
        const bw = Math.min(cv.w - 24, 316), bh = 70 + (tips ? 46 + lines.length * 22 + Math.ceil(gml.length / 2) * 20 : 0);
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(cxm - bw / 2, cym - bh / 2, bw, bh, 16); else ctx.rect(cxm - bw / 2, cym - bh / 2, bw, bh); ctx.fill();
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        let yy = cym - bh / 2 + 36;
        ctx.fillStyle = '#e3ae45'; ctx.font = '400 40px "Black Han Sans", sans-serif';
        ctx.fillText(cd > 3 && tips ? '준비' : String(Math.min(3, n)), cxm, yy);
        if (tips) {
          yy += 40;
          ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px "IBM Plex Sans KR", sans-serif';
          ctx.fillText(LAYS[st.lay].name + ' · ' + SIZES[st.sz | 0].name, cxm, yy);
          ctx.fillStyle = '#9fd3f5'; ctx.font = '700 12.5px "IBM Plex Sans KR", sans-serif';
          for (let k = 0; k < gml.length; k += 2) { yy += 20; ctx.fillText(gml.slice(k, k + 2).join(' · '), cxm, yy); }
          ctx.fillStyle = '#f2e9d8'; ctx.font = '700 13px "IBM Plex Sans KR", sans-serif';
          yy += 6;
          lines.forEach((ln) => { yy += 22; ctx.fillText(ln, cxm, yy); });
        }
      }
    }

    /* ----- main loop ----- */
    const stop = U.loop((rdt0, now) => {
      if (!st || !wd || !G) return;
      const rdt = Math.min(rdt0, 0.1), dt = rdt * SPD();
      readInput();
      if (tipT > 0) tipT -= dt;
      if (host()) {
        pollHost();
        if (phase === 'count') {
          const a = Math.ceil(cd); cd -= dt; const c2 = Math.ceil(cd);
          if (c2 !== a && c2 > 0 && c2 <= 3) api.sfx('tick');
          if (cd <= 0) { phase = 'play'; api.sfx('pop'); api.buzz(16); }
        }
        if (phase === 'play' && !wd.res) {
          let rem = dt;
          while (rem > 1e-6) { const h = Math.min(1 / 60, rem); rem -= h; curH = h; stepWorld(wd, h, inputsFor()); if (wd.res) break; }
          hostFlow();
        } else if (phase === 'play') hostFlow();
      } else {
        pollGuest(now);
        if (phase === 'count') cd = Math.max(0, cd - dt);
        guestStep(Math.min(dt, 0.2), rdt, now);
      }
      for (let i = drift.length - 1; i >= 0; i--) { drift[i].t += rdt; if (drift[i].t > 1.2) drift.splice(i, 1); }
      effects(now);
      camUpdate(rdt, false);
      PT.step(rdt);
      infoT -= rdt; if (infoT <= 0) { infoT = 0.2; renderInfo(); }
      publish(rdt);
      draw(now);
    });
    cv.onresize = () => { layout(); if (wd) draw(performance.now()); };
    layout();

    return {
      update(next) {
        const was = st; st = next;
        if (!wd || next.g !== key) startRound();
        else if (!host()) next.dead.forEach((d, k) => { if (d && wd.pl[k] && !wd.pl[k].out) wd.pl[k].out = 1; });
        if (next.over && was && !was.over && !host()) {
          phase = 'end'; busy = true; api.setBusy(true); clearTimeout(endTimer);
          endTimer = setTimeout(() => { if (busy) { busy = false; api.setBusy(false); } }, 1200);
        }
        renderTop(); renderInfo(true);
      },
      destroy() {
        stop(); clearTimeout(endTimer);
        if (busy) { busy = false; api.setBusy(false); }
        if (keyOff) keyOff();
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp);
        cv.destroy(); top.remove(); hud.remove();
      },
    };
  }

  /* the view picks the turn or realtime renderer from the state */
  function mount(root, api) {
    let sub = null, mode = '';
    return {
      update(s, prev) {
        const m = s && s.m === 'rt' ? 'rt' : 't';
        curMode = m;
        if (m !== mode) { if (sub) sub.destroy(); mode = m; sub = m === 'rt' ? mountRT(root, api) : mountTurn(root, api); prev = null; }
        sub.update(s, prev);
      },
      destroy() { if (sub) sub.destroy(); sub = null; },
    };
  }

  const TUT = [
    { sel: '.pg-board', text: '얼음판이에요! 물에 빠지지 않고 마지막까지 남은 펭귄이 이겨요.' },
    { sel: '.pg-me', text: '이게 내 펭귄이에요. 내 차례엔 먼저 2칸까지 걸을 수 있어요. 갈 칸을 탭하세요(안 움직이려면 내 펭귄을 탭).' },
    { sel: '.pg-board', text: '그다음 바로 옆 얼음 한 칸(곡괭이 표시)을 탭해 깨요. 얼음은 멀쩡 → 금 감 → 구멍. 구멍 위의 펭귄은 풍덩!' },
    { sel: '.pg-board', text: '얼음판이 갈라지면 가장 큰 조각만 남고, 작은 조각은 위의 펭귄과 함께 떠내려가요. 깨기 전에 빨간 미리보기로 보여 줘요.' },
    { sel: '.pg-info', text: '여기 「곰까지 N라운드」가 보여요. 때가 되면 가장자리에 물보라와 ! 가 뜨고, 다음 라운드 끝에 북극곰이 올라와요.' },
    { sel: '.pg-board', text: '곰은 펭귄이 한 번 할 때마다 다가와 가까운 펭귄을 밀어요. 판에 곰 미리보기(발자국 · 노리는 펭귄 빨간 원 · 밀리는 화살표)가 떠요. 빨간 화살표 = 물에 빠짐!' },
    { sel: '.pg-hud', text: '내가 갈 칸을 고르면 곰 미리보기가 그 자리에 맞춰 바뀌어요. 안전한 칸을 골라 「깨기!」로 확정, 「↶」로 다시 고르기. 시작해요!' },
  ];

  L.register({
    id: 'penguin', name: '펭귄 얼음 깨기', tag: '얼음 깨기 생존', cat: '파티',
    blurb: '얼음판 위 펭귄들! 실시간으로 미끄러지며 밀치거나(8명까지), 차례대로 얼음을 깨요. 맵마다 물개·빙산·눈보라 같은 기믹과 북극곰이 기다려요.',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 4, hidden: false,
    maxPlayersIf: (o) => (o && (o.mode === 'rt' || o.team === 'team') ? 8 : 4), // core: 실시간·팀전 8명, 차례대로 개인전 4명
    realtimeIf: (o) => !!o && o.mode === 'rt',          // core: 실시간 방식이면 한 폰에 한 명
    tint: '#1d4a6e',
    icon: '<path d="M6 45l9-7h26l9 7-9 7H15z" fill="currentColor" opacity=".35"/><path d="M20 45l5-3 3 4 5-3 4 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><path d="M19 30c0-8 4-12 9-12s9 4 9 12-3 11-9 11-9-3-9-11z" fill="none" stroke="currentColor" stroke-width="3"/><ellipse cx="29" cy="31" rx="4.5" ry="7" fill="currentColor" opacity=".5"/><circle cx="28" cy="15" r="6.5" fill="currentColor"/><path d="M34 14.5l6 1.6-6 1.6z" fill="currentColor"/><rect x="20" y="20" width="16" height="3.6" rx="1.8" fill="currentColor"/><circle cx="28" cy="6.5" r="2.3" fill="currentColor"/>',
    options: [
      { id: 'mode', label: '방식', tip: '밀기 방식.', def: 'rt', choices: [{ v: 'rt', label: '실시간 (8명까지)', tip: '모두 동시에 실시간으로 밀어요(8명까지).' }, { v: 't', label: '차례대로 (4명까지)', tip: '차례마다 방향·힘을 정해 밀어요(4명까지).' }] },
      { id: 'team', label: '모드', tip: '혼자 살아남기 또는 두 팀.', def: 'solo', choices: [{ v: 'solo', label: '개인전' }, { v: 'team', label: '팀전 (두 팀)' }] },
      { id: 'size', label: '맵 크기', def: 'auto', choices: [{ v: 'auto', label: '자동' }, { v: 's', label: '소형 (2~3인)' }, { v: 'm', label: '중형 (3~6인)' }, { v: 'l', label: '대형 (7~8인)' }] },
      { id: 'lay', label: '얼음판', def: 'rand', choices: [{ v: 'rand', label: '무작위' }].concat(LAYS.map((l) => ({ v: l.id, label: l.name }))) },
      { id: 'mix', label: '얼음 종류', tip: '미끄러운 얼음·잘 깨지는 얼음 같은 특수 얼음 비율.', def: 'rand', choices: [{ v: 'rand', label: '무작위' }, { v: 'none', label: '보통 얼음만' }, { v: 'few', label: '조금 섞기' }, { v: 'mid', label: '알맞게 섞기' }, { v: 'many', label: '많이 섞기' }] },
      { id: 'melt', label: '얼음 녹는 계절', tip: '시간이 지나면 얼음이 녹아 판이 좁아져요.', def: 'on', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔' }] },
      { id: 'floe', label: '유빙', tip: '떠다니는 얼음 조각이 나타나요.', def: 'on', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔' }] },
      { id: 'sea', label: '바다 생물', tip: '바다 생물이 나와 펭귄을 건드려요.', def: 'on', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔' }] },
      { id: 'bear', label: '북극곰 등장', tip: '북극곰이 나타나는 시점.', def: 'mid', choices: [{ v: 'fast', label: '빨리' }, { v: 'mid', label: '보통' }, { v: 'slow', label: '늦게' }] },
    ],
    controls: [
      { id: 'up', label: '위로 걷기 (실시간)', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 걷기 (실시간)', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 걷기 (실시간)', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 걷기 (실시간)', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'dash', label: '배치기 (실시간)', keys: ['Space', 'KeyJ'], pad: ['a', 'x'] },
      { id: 'go', label: '깨기! (차례대로)', keys: ['Enter'] },
      { id: 'redo', label: '다시 고르기 (차례대로)', keys: ['Backspace', 'KeyZ'] },
    ],
    quick: [
      '물에 빠지지 않고 마지막까지 얼음 위에 남은 펭귄이 이겨요.',
      '실시간(기본·8명까지): 끌어서 걸어요. 서 있는 얼음은 금이 가다 깨져요. 「배치기」로 상대를 물로 밀어요!',
      '맵마다 기믹이 있어요: 물개·빙산·간헐천·돌풍·눈보라·유빙·힘 물고기 등. 시간이 지나면 북극곰도 올라와요.',
      '차례대로(4명까지): 내 차례에 2칸까지 걷고, 바로 옆 얼음 한 칸을 깨요(두 번 치면 구멍).',
    ],
    rules: [
      { h: '목표', p: [
        '얼음판 위에 사람마다 펭귄이 한 마리씩 있어요.',
        '물에 빠지지 않고 마지막까지 남은 펭귄이 이겨요. 남은 펭귄들이 한꺼번에 빠지면 무승부예요.'] },
      { h: '팀전', p: [
        '「모드」에서 팀전을 고르면 두 팀(파랑·빨강)으로 나눠요. 4명이면 2대2, 6명이면 3대3, 8명이면 4대4예요. 팀전은 차례대로도 8명까지 돼요.',
        '펭귄 발밑의 고리 색과 위쪽 이름표 밑줄이 팀 색이에요.',
        '팀원끼리는 배치기로 날아가지 않아요(살짝 부딪히기만). 차례대로에서는 팀원 발밑 얼음도 깰 수 있으니 조심!',
        '팀원 중 한 마리라도 끝까지 남으면 그 팀 모두가 이겨요.'] },
      { h: '방식 고르기', p: [
        '「실시간」(기본): 모두 동시에 움직여요. 2~8명. 한 폰에 한 명만 할 수 있어요(나 + AI). 친구와는 온라인 방이나 LAN 방으로 해요.',
        '「차례대로」: 한 명씩 번갈아 해요. 2~4명. 한 폰으로 돌려 하기도 돼요. (차례대로를 고르면 자리가 4명까지로 줄어요.)'] },
      { h: '맵 크기', p: [
        '자동(기본): 인원에 맞춰 골라요. 2~3명 소형, 4~6명 중형, 7~8명 대형.',
        '소형(2~3인) · 중형(3~6인) · 대형(7~8인)을 직접 골라도 돼요. 맵이 클수록 얼음이 넓고 펭귄들이 더 멀리 떨어져서 시작해요.',
        '대형 맵에는 북극곰이 두 마리 나와요. 차례대로 방식은 중형까지예요(대형을 고르면 중형으로 해요).'] },
      { h: '얼음판 (21가지, 기본 무작위)', p: [
        '둥근 섬 · 구멍 빙판 · 고리 섬 · 쌍둥이 섬 · 살얼음 · 십자 빙판 · 초승달 · 모래시계 · 징검다리 섬 · 기다란 빙하 · 매번 새 빙판(판마다 새로 만들어짐) · 별 빙판 · 얼음 해협 · 군도 · 소용돌이 · 큰 호수 · 번개 빙하 · 마름모 빙판 · 꽃잎 섬 · 바위 요새 · 세모 섬.',
        '펭귄은 서로 멀리 떨어진 튼튼한 얼음에서 시작해요.',
        '얼음판이 갈라지면 가장 큰 조각만 남고, 작은 조각은 위의 펭귄과 함께 떠내려가요. (가장 큰 조각이 여럿이면 모두 남아요.)',
        '시작할 때 화면 가운데에 맵 이름과 그 맵의 기믹이 나와요.'] },
      { h: '실시간 · 얼음', p: [
        '얼음은 따로 깨지 않아요. 펭귄이 서 있는 얼음이 점점 금이 가요: 멀쩡 → 금 1 → 금 2 → 금 3(빨갛게 깜빡임) → 깨져서 물!',
        '가만히 서 있으면 약 1초마다 한 단계씩 금이 가요(걸어가며 지나가면 절반쯤). 금은 다시 붙지 않아요.',
        '펭귄 가운데가 물 위로 가면 풍덩! 탈락이에요.',
        '「얼음 녹는 계절」(기본 켬): 1분 30초쯤(맵이 크면 조금 늦게) 바다가 따뜻해져서 바깥 가장자리 얼음부터 점점 빨리 녹아요. 녹기 2.5초 전에 그 칸에 파란 점선과 물방울이 떠요. 얼른 벗어나세요! (끄면 안 녹고, 바위 얼음도 끝까지 단단해요.)',
        '5분이 되면 남은 펭귄 모두 승리(무승부).'] },
      { h: '실시간 · 맵 기믹', p: [
        '「유빙」(기본 켬): 유빙이 없는 맵에도 떠다니는 유빙이 생겨요. 유빙 앞의 작은 화살표가 흘러가는 방향이에요. 끄면 유빙 기믹이 모두 빠져요.',
        '「바다 생물」(기본 켬): 범고래가 나와요. 끄면 범고래와 물개가 모두 빠져요.',
        '범고래: 물속 지느러미가 물가 칸으로 다가오고 그 칸이 빨간 점선으로 깜빡여요. 물보라가 인 뒤 돌진해서 그 칸을 들이받아요 — 얼음이 두 단계 깨지고, 가까운 펭귄은 안쪽으로 튕겨 비틀거려요. 예고는 3초 넘게 보이니 안쪽으로 물러나세요.',
        '떠다니는 유빙 · 호수 유빙: 섬 둘레(또는 가운데 호수)를 도는 얼음 조각이에요. 올라탈 수 있지만 오래 서 있으면 가라앉아요.',
        '해류 유빙: 얼음 해협의 물길을 따라 유빙이 흘러가요. 다리 대신 건너는 데 쓸 수 있어요. 끝까지 타고 가면 풍덩!',
        '물개: 빨간 점선 길이 먼저 보이고, 물(또는 낚시 구멍)에서 튀어나와 그 길로 쭉 미끄러지며 펭귄을 옆으로 밀쳐요.',
        '굴러오는 빙산: 넓은 빨간 길이 2초쯤 먼저 보여요. 빙산은 그 길로 굴러가며 펭귄을 밀어내고 지나간 얼음에 금을 내요.',
        '간헐천: 동그란 구멍 칸이에요. 거품이 올라오고 빨간 원이 뜨면 곧 펑! 가까운 펭귄이 사방으로 날아가요.',
        '낚시 구멍 · 힘 물고기: 구멍(물)에서 물고기가 얼음 위로 튀어나와요. 먼저 먹으면 5초 동안 빨라지고, 배치기가 금방 다시 되고, 잘 안 밀려요.',
        '돌풍: 화살표가 먼저 뜨고, 잠시 뒤 모두가 그쪽으로 밀려요. 물가에서 떨어지세요!',
        '눈보라: 한동안 내 펭귄 주변만 보이고, 바람에 살살 밀려요.',
        '연쇄 균열: 갈색 금이 그어진 칸들이에요. 하나에 금이 가면 이어진 칸에도 차례로 금이 퍼져요.',
        '살얼음 구역: 점선으로 표시된 칸은 처음부터 금이 2단계 가 있어요.',
        '미끄럼 빙판: 반짝이는 칸은 잘 안 멈추고 쭉 미끄러져요.',
        '바위 얼음: 회색 칸은 밟아도 금이 안 가요. 단, 바다가 따뜻해지면 바위 얼음도 녹아요.'] },
      { h: '얼음 종류 (기본 무작위)', p: [
        '판마다 특별한 얼음이 몇 덩이씩 섞여요. 무작위(기본)면 섞는 양과 종류(2~4가지)가 판마다 달라요. 「보통 얼음만」으로 끌 수 있어요. 펭귄 시작 칸 둘레에는 놓이지 않아요.',
      ].concat(ICE_TYPES.map((t) => t.name + ' — 실시간: ' + t.rt + ' 차례대로: ' + t.t)) },
      { h: '실시간 · 밀치기', p: [
        '「배치기」를 누르면 보는 방향으로 배를 깔고 쭉 미끄러져요. 부딪힌 펭귄은 멀리 밀려나요.',
        '한 번 쓰면 1.3초 쉬어야 해요(버튼이 흐려져요). 빗나가면 내가 물로 미끄러질 수도 있어요!'] },
      { h: '실시간 · 북극곰', p: [
        '「북극곰 등장」 빨리 20초 · 보통 32초 · 늦게 45초에 올라와요. 3초 전에 가장자리에 물보라와 ! 가 떠요. 대형 맵은 14초 뒤 두 번째 곰도 와요.',
        '곰은 가장 가까운 펭귄을 쫓아와요(두 마리면 서로 다른 펭귄을 노려요). 펭귄보다 느리지만, 25초가 지나면 화가 나서 빨라져요.',
        '곰이 가까이 오면 앞발을 들어요(빨간 부채꼴). 잠깐 뒤 그 안의 펭귄을 크게 쳐 내고 발밑 얼음에 금을 내요. 옆으로 피하세요!',
        '곰은 무거워서 밟는 얼음이 아주 빨리 깨져요. 곰이 깨진 얼음이나 물에 빠지면 7초 뒤 다른 곳으로 다시 올라와요.'] },
      { h: '실시간 · 조작', p: [
        '화면 아무 데나 누른 채 끌면 그 방향으로 걸어요(조이스틱). 짧게 탭하면 그 자리로 걸어가요.',
        '「배치기」 버튼, 또는 끄는 중에 다른 손가락으로 탭하면 배치기!',
        '화면은 남은 얼음과 모든 펭귄이 보이게 저절로 줌돼요. 내 펭귄 위에는 내 색 화살표가 떠요.',
        'PC: 방향키·WASD로 걷기, 스페이스로 배치기 (설정의 「조작 설정」에서 바꿀 수 있어요). 게임패드도 돼요.'] },
      { h: '차례대로 · 차례에 할 일', p: [
        '① 걷기(안 해도 돼요): 얼음 위로 2칸까지 걸어가요. 다른 펭귄이나 곰이 있는 칸은 지나갈 수 없어요.',
        '② 깨기(꼭 해요): 내 펭귄 바로 옆 얼음 한 칸을 콕 쳐요. 옆에 얼음이 하나도 없으면 내가 선 칸을 쳐요.',
        '얼음은 멀쩡 → 금 감 → 구멍 순서로 깨져요. 두 번 치면 구멍이에요.',
        '구멍이 난 칸 위의 펭귄은 물에 빠져요. 다른 펭귄이 서 있는 금 간 칸을 치면 그 펭귄이 빠지는 거예요!',
        '깨기 전에 미리보기로 어떤 칸이 떠내려가는지 빨갛게 보여 줘요.',
        '차례대로에서는 맵 모양·낚시 구멍·살얼음과 아래의 유빙·범고래만 나오고, 다른 움직이는 기믹(물개·빙산 등)은 나오지 않아요.'] },
      { h: '차례대로 · 유빙과 범고래', p: [
        '유빙(기본 켬): 물 위에 얼음 한 칸짜리 조각이 2~3개 떠 있어요. 라운드가 끝날 때마다 한 칸씩 흘러가요. 위에 탄 펭귄·곰도 함께 가요.',
        '유빙 옆의 흰 화살표가 다음에 흘러갈 칸이에요(막히면 방향을 틀어요). 판에 붙으면 다리처럼 건널 수 있고, 판이 갈라져도 유빙은 가라앉지 않아요. 단, 쳐서 구멍 내면 사라져요.',
        '범고래(바다 생물, 기본 켬): 3라운드가 끝날 때부터 지느러미가 펭귄 가까운 물가 칸 하나를 노려요(빨간 점선). 다음 라운드가 끝날 때 그 칸을 들이받아요.',
        '들이받힌 칸은 한 단계 깨져요(금 간 칸이면 구멍). 그 위의 펭귄은 안쪽으로 한 칸 밀려나요. 밀릴 곳이 막혔는데 칸이 구멍 나면 풍덩! 표시가 뜨면 내 차례에 그 칸에서 벗어나면 안전해요.'] },
      { h: '차례대로 · 북극곰', p: [
        '게임이 길어지면 북극곰이 판 가장자리로 올라와요. 한 라운드 전에 그 자리에 물보라와 ! 표시가 떠요.',
        '언제: 「북극곰 등장」 보통이면 2명 12라운드, 3명 8라운드, 4명 6라운드가 끝날 때. (빨리 8·5·4, 늦게 16·11·8) 아래 줄에 「곰까지 N라운드」가 보여요.',
        '올라온 뒤에는 펭귄이 한 번 할 때마다 곰도 바로 1칸 움직여요. 곰이 올라오고 4라운드가 지나면 화가 나서 2칸씩 움직여요.',
        '곰은 가장 가까운 펭귄에게 가요. 거리가 같으면 물에 빠뜨릴 수 있는 펭귄, 그다음 방금 깬 펭귄을 노려요.',
        '곰 바로 옆이 되면 앞발로 쳐요: 맞은 펭귄이 서 있던 얼음에 금이 가고(금 간 칸이면 구멍), 펭귄은 한 칸 뒤로 밀려나요. 밀린 곳이 물이면 풍덩!',
        '밀릴 곳에 다른 펭귄이 있으면 안 밀려요. 대신 서 있던 칸이 구멍이 되면 빠져요.',
        '곰이 선 얼음을 구멍 내거나 떠내려 보내면 곰도 풍덩! 그 라운드 끝에 물보라가 생기고, 다음 라운드 끝에 다시 올라와요.',
        '판에 곰의 다음 행동이 보여요: 갈 칸(발자국), 노리는 펭귄(빨간 원), 밀리는 방향(화살표, 빨가면 물에 빠짐). 내가 갈 칸을 고르면 미리보기가 그 자리에 맞춰 바뀌어요.'] },
      { h: '차례대로 · 얼음 녹는 계절', p: [
        '「얼음 녹는 계절」(기본 켬): 북극곰이 올라오고 2라운드쯤 지나면 바다가 따뜻해져요.',
        '라운드가 끝날 때 바깥 가장자리 칸 몇 개에 파란 점선과 물방울(녹기 직전 표시)이 떠요. 다음 라운드가 끝나면 그 칸들이 녹아서 물이 돼요. 그 위에 있던 펭귄(과 곰)은 풍덩!',
        '표시가 뜨면 내 차례에 그 칸에서 벗어나면 돼요. 라운드마다 녹는 칸이 3개 → 4개 … 7개까지 늘어나요.'] },
      { h: '차례대로 · 조작', p: [
        '① 갈 칸을 탭해요(안 움직이려면 내 펭귄을 탭).',
        '② 깰 칸(곡괭이 표시)을 탭하면 미리보기가 나와요. 한 번 더 탭하거나 「깨기!」를 누르면 확정이에요.',
        '「↶」를 누르면 갈 칸부터 다시 골라요. 내가 빠지는 수라면 버튼이 빨간 「그래도 깨기」로 바뀌어요.'] },
      { h: '예시', p: [
        '실시간: 상대가 물가에 서 있어요. 상대 쪽으로 걸어가다 2칸쯤에서 「배치기」! 상대가 물로 밀려나요. 단, 내 발밑이 금 3이면 먼저 피해야 해요.',
        '실시간: 돌풍 화살표가 오른쪽을 가리켜요. 오른쪽 물가에 있던 상대 뒤로 가서 배치기하면 바람까지 더해져 풍덩!',
        '차례대로: 상대가 금 간 칸에 서 있고 내 펭귄이 2칸 거리예요. 1칸 걸어 그 옆에서 그 칸을 깨면 구멍! 상대가 풍덩.'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움: 위험을 잘 못 보고 곰·물개·빙산도 잘 못 피해요. 보통: 금 간 얼음과 곰, 예고된 위험을 대체로 피하고 기회를 노려요. 어려움: 간헐천·돌풍까지 미리 대비하고, 물고기를 챙기고, 물가의 상대를 노려 밀쳐요.'] },
    ],
    codex: [
      { h: '얼음 종류', p: ['「얼음 종류」 옵션으로 판에 섞이는 특별한 얼음이에요.'],
        rows: ICE_TYPES.map((t) => ({ icon: { c: '🧊', k: '🔷', s: '✨', n: '❄️' }[t.ch], name: t.name, tag: t.ch === 'k' ? '튼튼함' : t.ch === 'c' ? '위험' : '움직임', desc: '실시간: ' + t.rt + ' · 차례대로: ' + t.t })) },
      { h: '맵 기믹', p: ['실시간 방식에서 맵마다 나오는 기믹이에요.'],
        rows: Object.keys(GMN).filter((k) => k !== 'thick' && k !== 'snow' && k !== 'orca').map((k) => ({ icon: '🌊', name: GMN[k], tag: '기믹', desc: (LAYS.filter((l) => l.gm && l.gm.indexOf(k) >= 0).map((l) => l.name).join(' · ') || (k === 'bears' ? '대형 맵' : '매번 새 빙판')) + '에서 나와요.' + (k === 'floe' ? ' 「유빙」 옵션을 켜면 유빙 없는 맵에도 나와요.' : k === 'seal' ? ' 「바다 생물」을 끄면 빠져요.' : '') })) },
      { h: '바다 생물 · 유빙', p: ['「바다 생물」·「유빙」 옵션으로 켜고 끌 수 있어요(기본 켬).'],
        rows: [
          { icon: '🐋', name: '범고래', tag: '바다 생물', desc: '실시간: 지느러미 접근 → 빨간 물가 칸 → 물보라(약 3.6초 예고) → 돌진, 그 칸 얼음 2단계 깨짐 + 가까운 펭귄을 안쪽으로 튕김. 10초 안팎마다. · 차례대로: 라운드 끝에 노릴 칸 예고, 다음 라운드 끝에 1단계 깨고 위의 펭귄을 안쪽으로 1칸 밀침.' },
          { icon: '🦭', name: '물개', tag: '바다 생물', desc: '실시간 일부 맵: 빨간 점선 길로 튀어나와 미끄러지며 펭귄을 옆으로 밀쳐요.' },
          { icon: '🧊', name: '유빙', tag: '움직이는 얼음', desc: '실시간: 섬 둘레를 천천히 돌아요(화살표 = 흘러가는 방향). 오래 서 있으면 가라앉음. · 차례대로: 라운드마다 한 칸씩 흘러가는 얼음 한 칸, 위의 펭귄도 함께 이동.' },
        ] },
    ],
    get tutorial() { return curMode === 'rt' ? null : TUT; },
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { LAYS, SIZES, sizeFor, buildMap, pickStarts, bearPlan, iceArr, occ, actions, reachFrom, targetsFrom, sinkCheck, NB, hd, N, W, H, XW, YW, tileAt, newWorld, stepWorld, aiThink, movePeng, RT, genIce, keepLargest, comps, encodeW, decodeGimmicks, GMN },
  });
})();
