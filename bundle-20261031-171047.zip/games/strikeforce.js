/* 협동 작전 부대 (strikeforce) — PC 전용 협동 분대 전술(턴제, 리메이크 2026-10-27).
   대원 4명(1~4명이 나눠 맡음, 빈자리는 AI)이 10×8 격자 전장에서 작전 목표를 끝낸다.
   한 라운드: ① 적의 다음 공격이 빨간 칸으로 미리 보인다 → ② 모든 대원이 동시에(순서 자유) 이동 + 행동 하나
   → ③ 적 차례: 적은 「보여 준 칸」을 그대로 공격한다(밀려나면 공격 방향도 같이 밀림 — 적끼리 맞기도 함) → 이동·다음 공격 표시.
   판 = 작전 3/5개 연속(점점 어려워짐), 작전 사이에 부대 강화 1개(이 판 안에서만 — 판 밖 성장 없음). */
(function () {
  const L = window.Lounge, U = L.util;
  const W = 10, H = 8, NU = 4;
  const D4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const inb = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
  const cheb = (ax, ay, bx, by) => Math.max(Math.abs(ax - bx), Math.abs(ay - by));
  const man = (ax, ay, bx, by) => Math.abs(ax - bx) + Math.abs(ay - by);
  const sgn = (v) => (v > 0 ? 1 : v < 0 ? -1 : 0);
  const rnd = (n) => Math.floor(Math.random() * n);
  const pickOne = (a) => a[rnd(a.length)];
  const clone = (o) => JSON.parse(JSON.stringify(o));

  /* ================= 자료 ================= */
  // 역할: hp 체력, mv 이동, ar 방어(받는 피해 −), atk 기본 공격(rg 1 = 붙은 칸), ab 능력(cd 몇 라운드마다)
  const ROLES = [
    { id: 'asl', nm: '돌격병', ic: '🔫', c: '#e0703c', hp: 10, mv: 4, ar: 0, atk: { nm: '소총 사격', dm: 3, rg: 3 },
      ab: { nm: '돌파 사격', cd: 2, d: '상하좌우로 붙은 적 모두 3 피해 + 1칸 밀어내기' },
      d: '앞장서서 붙어 싸워요. 밀려난 적이 바위·다른 적·상자에 부딪히면 둘 다 1 피해.', tip: '적 무리 한가운데로 뛰어들어 돌파 사격 → 적의 공격 방향이 같이 밀려나요.' },
    { id: 'snp', nm: '저격수', ic: '🎯', c: '#6fb0e0', hp: 7, mv: 3, ar: 0, atk: { nm: '저격', dm: 4, rg: 7 },
      ab: { nm: '관통탄', cd: 3, d: '한 줄(상하좌우) 8칸 안의 적 모두 5 피해(바위에서 멈춤)' },
      d: '멀리서 큰 피해. 이동하지 않고 쏘면 +2 피해(자리 지킴). 체력이 낮아요.', tip: '방패병이 도발로 적을 한 줄에 모으면 관통탄으로 꿰뚫어요.' },
    { id: 'grd', nm: '방패병', ic: '🛡', c: '#d9b44a', hp: 14, mv: 3, ar: 1, atk: { nm: '방패 밀치기', dm: 2, rg: 1, push: 1 },
      ab: { nm: '도발', cd: 3, d: '4칸 안의 적이 최대 2칸 다가와 방패병을 노려요. 다음 적 차례까지 방어 +2' },
      d: '단단한 방어(받는 피해 −1). 동료 대신 맞아 줘요.', tip: '약한 동료가 노려지면 도발로 공격을 다 끌어와요. 모인 적은 폭파병의 먹잇감.' },
    { id: 'med', nm: '의무병', ic: '💉', c: '#7fd08a', hp: 8, mv: 4, ar: 0, atk: { nm: '권총', dm: 2, rg: 4 },
      ab: { nm: '응급 치료', cd: 2, d: '2칸 안의 대원 하나(자신 포함) 체력 +5, 쓰러진 대원은 체력 5로 일으켜요' },
      d: '부대의 생명줄. 쓰러진 동료를 멀리서도 일으켜요.', tip: '쓰러진 대원은 누구나 옆 칸에서 「일으키기」(체력 3)로도 살릴 수 있어요.' },
    { id: 'eng', nm: '공병', ic: '🛠', c: '#b48ae0', hp: 9, mv: 3, ar: 0, atk: { nm: '기관단총', dm: 2, rg: 4 },
      ab: { nm: '자동 포탑', cd: 3, d: '옆 칸에 포탑(체력 5) 설치 — 적 차례가 시작될 때 4칸 안의 가까운 적에게 2 피해. 적의 공격을 끌어요(하나만)' },
      d: '포탑으로 길목을 막고 적의 공격을 받아 줘요.', tip: '거점·수송차 앞에 포탑을 두면 적이 포탑부터 노려요.' },
    { id: 'gre', nm: '폭파병', ic: '💣', c: '#e05a7a', hp: 9, mv: 3, ar: 0, atk: { nm: '소총', dm: 2, rg: 4 },
      ab: { nm: '유탄', cd: 2, d: '2~5칸 떨어진 칸에 3×3 폭발 3 피해(벽 너머 가능). 아군도 맞아요! 상자를 부숴요' },
      d: '모여 있는 적을 한 번에. 장갑 적(🛡)에도 잘 들어요.', tip: '폭발 범위(주황)에 동료가 있으면 빨간 경고가 떠요.' },
  ];
  const RI = {}; ROLES.forEach((r, i) => { RI[r.id] = i; });
  // 적: k 공격 방식(mel 붙은 칸, sht 한 줄 첫 대상, chg 돌진(부딪힌 대상 밀기), bm 광선(한 줄 전부), lob 곡사(칸 + 둘레 튐)), el 정예
  const FAC = [
    { id: 'bug', nm: '군체', c: '#d38a3a', hz: '산성 웅덩이', nest: '군체 둥지', fl: ['#5a4630', '#4f3d2a'], rk: '#2e2318', hc: '#9acd32', d: '빠른 벌레 떼와 곡사 침. 가까이 붙기 전에 줄이세요.' },
    { id: 'bot', nm: '기계단', c: '#d24a3c', hz: '불타는 기름', nest: '기계 공장', fl: ['#4a4a50', '#414147'], rk: '#232328', hc: '#ff8a3a', d: '멀리서 쏘는 기계 군대. 장갑(🛡)이 있어 큰 한 방이 필요해요.' },
    { id: 'void', nm: '공허 결사', c: '#9b6cff', hz: '공허 균열', nest: '공허 관문', fl: ['#3b3350', '#342d47'], rk: '#1a1626', hc: '#c27bff', d: '순간 이동과 관통 광선. 한 줄로 서 있지 마세요.' },
  ];
  const EN = [
    { id: 'ling', f: 0, nm: '잔발이', ic: '🐜', hp: 3, mv: 4, ar: 0, k: 'mel', dm: 2, rg: 1, d: '빠르고 약한 벌레. 붙은 칸을 물어요.' },
    { id: 'spit', f: 0, nm: '산성 침뱉이', ic: '🦂', hp: 4, mv: 2, ar: 0, k: 'lob', dm: 3, rg: 4, sp: 1, d: '2~4칸 떨어진 칸에 침(3) + 둘레 1. 벽 너머로도 와요.' },
    { id: 'chg', f: 0, nm: '갑각 돌진충', ic: '🪲', hp: 7, mv: 3, ar: 1, k: 'chg', dm: 3, rg: 5, d: '한 줄로 돌진해 처음 부딪힌 대상에 3 피해 + 밀기. 장갑 1.' },
    { id: 'tit', f: 0, nm: '둥지 거신', ic: '🦗', hp: 12, mv: 2, ar: 1, k: 'lob', dm: 4, rg: 5, sp: 2, el: 1, big: 1, d: '정예. 큰 산성 덩어리(4) + 둘레 2. 밀리지 않아요.' },
    { id: 'trp', f: 1, nm: '보병 기계', ic: '🤖', hp: 4, mv: 3, ar: 0, k: 'sht', dm: 2, rg: 5, d: '한 줄로 쏴서 처음 맞는 대상에 2 피해.' },
    { id: 'rkt', f: 1, nm: '로켓 기계', ic: '🚀', hp: 4, mv: 2, ar: 0, k: 'lob', dm: 3, rg: 5, sp: 1, d: '곡사 로켓(3) + 둘레 1.' },
    { id: 'shd', f: 1, nm: '방패 기계', ic: '🛡', hp: 6, mv: 3, ar: 2, k: 'mel', dm: 3, rg: 1, d: '장갑 2 — 작은 피해는 1만 들어가요. 유탄·저격으로.' },
    { id: 'tank', f: 1, nm: '보행 전차', ic: '🦾', hp: 12, mv: 1, ar: 1, k: 'sht', dm: 4, rg: 6, push: 1, el: 1, big: 1, d: '정예. 포탄(4) + 밀기. 느리지만 단단해요.' },
    { id: 'shade', f: 2, nm: '그림자', ic: '👤', hp: 3, mv: 3, ar: 0, k: 'mel', dm: 3, rg: 1, blink: 1, d: '5칸 안 어디로든 순간 이동해 약한 대원을 물어요.' },
    { id: 'eye', f: 2, nm: '감시 눈', ic: '👁', hp: 3, mv: 4, ar: 0, k: 'bm', dm: 2, rg: 4, fly: 1, d: '한 줄 광선 — 줄 위의 모두(적 포함)에 2 피해. 날아서 웅덩이를 무시.' },
    { id: 'lan', f: 2, nm: '공허 창병', ic: '🗡', hp: 5, mv: 3, ar: 0, k: 'sht', dm: 3, rg: 4, d: '빛 창을 던져 처음 맞는 대상에 3 피해.' },
    { id: 'col', f: 2, nm: '공허 거신', ic: '🌀', hp: 12, mv: 2, ar: 1, k: 'bm', dm: 3, rg: 6, el: 1, big: 1, d: '정예. 긴 광선(3) — 한 줄 전부. 밀리지 않아요.' },
    { id: 'nest', f: -1, nm: '적 소굴', ic: '🕳', hp: 11, mv: 0, ar: 0, k: '', dm: 0, rg: 0, big: 1, d: '2라운드마다 옆에 적을 낳아요. 공격은 안 해요.' },
  ];
  const EI = {}; EN.forEach((e, i) => { EI[e.id] = i; });
  const FAC_EN = [0, 1, 2].map((f) => EN.map((e, i) => (e.f === f && !e.el ? i : -1)).filter((i) => i >= 0));
  const FAC_EL = [0, 1, 2].map((f) => EN.map((e, i) => (e.f === f && e.el ? i : -1)).filter((i) => i >= 0));
  const KNM = { mel: '근접', sht: '사격', chg: '돌진', bm: '광선', lob: '곡사', '': '' };
  const MIS = [
    { id: 'kill', nm: '섬멸 작전', ic: '⚔', rl: 8, d: '적을 모두 처치하세요. 증원은 정해진 만큼만 와요.' },
    { id: 'hold', nm: '거점 사수', ic: '📡', rl: 6, d: '통신 장치 2개 중 하나라도 6라운드 끝까지 지키세요.' },
    { id: 'data', nm: '자료 회수', ic: '💾', rl: 6, d: '자료 상자 3개를 회수하세요(그 칸이나 옆 칸에서 「회수」).' },
    { id: 'nest', nm: '소굴 파괴', ic: '🕳', rl: 8, d: '적 소굴 2개를 부수세요. 소굴은 2라운드마다 적을 낳아요.' },
    { id: 'escort', nm: '수송차 호송', ic: '🚚', rl: 8, d: '수송차를 오른쪽 끝 출구까지. 대원이 2칸 안에 있으면 라운드마다 3칸 가요(장갑 1 · 길을 막지 마세요).' },
  ];
  const MI = {}; MIS.forEach((m, i) => { MI[m.id] = i; });
  // 난이도(적 수·증원·정예·적 체력). 작전마다(mi) 조금씩 더 세짐.
  const DIFF = [
    { nm: '쉬움', e0: 2, sp: 1, el: 0.0, hp: 0, kb: 2, dev: 10, car: 14 },
    { nm: '보통', e0: 3, sp: 1, el: 0.1, hp: 0, kb: 3, dev: 9, car: 12 },
    { nm: '어려움', e0: 4, sp: 1, el: 0.26, hp: 1, kb: 4, dev: 8, car: 11 },
  ];
  const UPG = [
    { id: 'hp', nm: '보강 장갑', ic: '❤', d: '모든 대원 최대 체력 +3', max: 2 },
    { id: 'dmg', nm: '개량 탄약', ic: '🔺', d: '모든 기본 공격 피해 +1', max: 2 },
    { id: 'cd', nm: '빠른 재정비', ic: '⏱', d: '모든 능력 대기 −1라운드(최소 1)', max: 1 },
    { id: 'mv', nm: '경량 장비', ic: '👟', d: '모든 대원 이동 +1', max: 1 },
    { id: 'sh', nm: '보호막 발생기', ic: '🔵', d: '작전마다 모든 대원이 보호막 3으로 시작(먼저 깎임)', max: 2 },
  ];

  /* ================= 기본 도우미 ================= */
  const tileAt = (st, x, y) => (inb(x, y) ? st.M.g[y * W + x] : '#');
  const setTile = (st, x, y, c) => { const g = st.M.g; const i = y * W + x; st.M.g = g.slice(0, i) + c + g.slice(i + 1); };
  const solidT = (c) => c === '#' || c === 'x';
  const uDef = (u) => ROLES[u.r];
  const eDef = (e) => EN[e.t];
  const upLv = (st, id) => st.upg[UPG.findIndex((q) => q.id === id)] | 0;
  const mvOf = (st, u) => uDef(u).mv + upLv(st, 'mv');
  const cdOf = (st, u) => Math.max(1, uDef(u).ab.cd - upLv(st, 'cd'));
  const atkDm = (st, u) => uDef(u).atk.dm + upLv(st, 'dmg');
  const ready = (u) => !u.down && !u.acted;
  const liveU = (st) => st.u.filter((u) => !u.down);
  // 칸 위의 대상: u 대원, e 적, t 포탑, o 물체(장치·수송차)
  function occ(st, x, y, skip) {
    for (const u of st.u) if (u !== skip && u.x === x && u.y === y) return { k: 'u', o: u };
    for (const e of st.e) if (e !== skip && e.x === x && e.y === y) return { k: 'e', o: e };
    if (st.tu && st.tu !== skip && st.tu.x === x && st.tu.y === y) return { k: 't', o: st.tu };
    for (const o of st.o) if (o !== skip && o.k !== 'data' && o.hp > 0 && o.x === x && o.y === y) return { k: 'o', o };
    return null;
  }
  const freeT = (st, x, y, skip) => inb(x, y) && !solidT(tileAt(st, x, y)) && !occ(st, x, y, skip);
  function losClear(st, ax, ay, bx, by) {
    const n = Math.max(Math.abs(bx - ax), Math.abs(by - ay)) * 3;
    for (let i = 1; i < n; i++) {
      const t = i / n, x = Math.round(ax + (bx - ax) * t), y = Math.round(ay + (by - ay) * t);
      if ((x !== ax || y !== ay) && (x !== bx || y !== by) && solidT(tileAt(st, x, y))) return false;
    }
    return true;
  }
  function logp(st, s) { st.log.push(s); if (st.log.length > 7) st.log.shift(); }
  const ev = (st, a) => { st.last.ev.push(a); };
  const ukey = (u) => 'u' + u.id, ekey = (e) => 'e' + e.id;

  /* ================= 지도 ================= */
  function genMap(st, mt, fac) {
    for (let tries = 0; tries < 80; tries++) {
      const g = Array(W * H).fill('.');
      const put = (x, y, c) => { if (x >= 2 && inb(x, y)) g[y * W + x] = c; };
      const nr = 6 + rnd(4);
      for (let i = 0; i < nr; i++) { const x = 2 + rnd(W - 2), y = rnd(H); put(x, y, '#'); if (Math.random() < 0.45) put(x + pickOne([-1, 1, 0]), y + pickOne([-1, 1]), '#'); }
      const nh = 3 + rnd(3);
      for (let i = 0; i < nh; i++) { const x = 2 + rnd(W - 3), y = rnd(H); if (g[y * W + x] === '.') g[y * W + x] = '~'; }
      const nc = 2 + rnd(3);
      for (let i = 0; i < nc; i++) { const x = 3 + rnd(W - 4), y = rnd(H); if (g[y * W + x] === '.') g[y * W + x] = 'x'; }
      // 연결 확인(상자는 막힘으로)
      const seen = new Uint8Array(W * H), q = [0]; seen[0] = 1; let cnt = 1;
      if (g[0] !== '.') continue;
      while (q.length) { const i = q.pop(), x = i % W, y = (i / W) | 0; for (const [dx, dy] of D4) { const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue; const j = ny * W + nx; if (seen[j] || solidT(g[j])) continue; seen[j] = 1; cnt++; q.push(j); } }
      const open = g.filter((c) => !solidT(c)).length;
      if (cnt !== open) continue;
      // 오른쪽 세 줄에 빈칸이 넉넉해야(적 등장)
      let rf = 0; for (let y = 0; y < H; y++) for (let x = W - 3; x < W; x++) if (g[y * W + x] === '.') rf++;
      if (rf < 10) continue;
      return g.join('');
    }
    return '.'.repeat(W * H);
  }
  function freeTiles(st, f) { const out = []; for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (tileAt(st, x, y) === '.' && !occ(st, x, y) && !st.o.some((o) => o.x === x && o.y === y) && (!f || f(x, y))) out.push([x, y]); return out; }
  function pathBFS(st, sx, sy, tx, ty) {
    const prev = new Int16Array(W * H).fill(-2), q = [sy * W + sx]; prev[sy * W + sx] = -1;
    while (q.length) { const i = q.shift(), x = i % W, y = (i / W) | 0; if (x === tx && y === ty) break; for (const [dx, dy] of D4) { const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue; const j = ny * W + nx; if (prev[j] !== -2 || solidT(tileAt(st, nx, ny))) continue; prev[j] = i; q.push(j); } }
    if (prev[ty * W + tx] === -2) return null;
    const p = []; let i = ty * W + tx; while (i >= 0) { p.push([i % W, (i / W) | 0]); i = prev[i]; } return p.reverse();
  }

  /* ================= 판 · 작전 ================= */
  function init(players, opts) {
    const o = opts || {}, np = Math.max(1, Math.min(4, players.length | 0));
    const roles = U.shuffle(ROLES.map((_, i) => i)).slice(0, NU);
    const st = {
      v: 2, np, nm: players.slice(0, np).map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 10)),
      ai: players.slice(0, np).map((p) => (p && p.ai ? 1 : 0)),
      dif: Math.max(0, Math.min(2, o.dif === undefined ? 1 : o.dif | 0)), ops: [3, 5].indexOf(+o.ops) >= 0 ? +o.ops : 3,
      facO: [-1, 0, 1, 2].indexOf(+o.fac) >= 0 ? +o.fac : -1,
      ph: 'pick', roles, rd: Array(np).fill(0), mi: 0, wins: 0, upg: UPG.map(() => 0), upc: null, plan: [],
      M: null, u: [], e: [], o: [], tu: null, sp: [], done: Array(np).fill(0), rn: 1, eid: 1,
      log: [], last: { id: 0, ev: [] }, sk: Array.from({ length: np }, () => [0, 0, 0, 0]), res: null, hist: [],
    };
    // 작전 순서: 종류는 겹치지 않게 섞어서, 진영은 옵션(무작위면 작전마다)
    const ms = U.shuffle(MIS.map((_, i) => i)); while (ms.length < st.ops) ms.push(rnd(MIS.length));
    st.plan = ms.slice(0, st.ops).map((m) => [m, st.facO >= 0 ? st.facO : rnd(3)]);
    for (let s = 0; s < np; s++) if (st.ai[s]) st.rd[s] = 1;
    if (st.rd.every((v) => v)) startMission(st);
    return st;
  }
  const ownerOf = (st, ui) => ui % st.np;
  function rollEnemy(st) {
    const f = st.M.fac, D = DIFF[st.dif];
    if (Math.random() < D.el + st.mi * 0.07 && FAC_EL[f].length) return pickOne(FAC_EL[f]);
    return pickOne(FAC_EN[f]);
  }
  function addEnemy(st, t, x, y) {
    const d = EN[t], extra = d.f >= 0 ? DIFF[st.dif].hp + (st.mi >= 2 ? 1 : 0) * (d.el ? 2 : 0) : DIFF[st.dif].hp * 2;
    const e = { id: st.eid++, t, x, y, hp: d.hp + extra, mhp: d.hp + extra, it: null, age: 0 };
    st.e.push(e); return e;
  }
  function startMission(st) {
    const [mt, fac] = st.plan[st.mi], M = MIS[mt], D = DIFF[st.dif];
    st.ph = 'play'; st.rn = 1; st.e = []; st.o = []; st.tu = null; st.sp = []; st.eid = 1;
    st.M = { mt, fac, g: '', rl: M.rl + (st.dif === 0 && M.id !== 'hold' ? 1 : 0), bud: mt === MI.kill ? D.kb + st.mi : 99, got: 0, path: null, pi: 0, exit: null };
    st.M.g = genMap(st, mt, fac);
    const shBase = upLv(st, 'sh') * 3;
    st.u = st.roles.map((r, i) => {
      const R = ROLES[r], mhp = R.hp + upLv(st, 'hp') * 3;
      return { id: i, r, own: ownerOf(st, i), x: 0, y: 0, hp: mhp, mhp, cd: 0, acted: 0, down: 0, mvd: 0, tb: 0, sh: shBase };
    });
    // 물체
    if (mt === MI.escort) {
      for (let k = 0; k < 40; k++) {
        const ry = rnd(H), ey = rnd(H);
        if (tileAt(st, 0, ry) !== '.' || tileAt(st, W - 1, ey) !== '.') continue;
        const p = pathBFS(st, 0, ry, W - 1, ey); if (!p) continue;
        st.M.path = p; st.M.exit = [W - 1, ey]; st.o.push({ k: 'car', x: 0, y: ry, hp: D.car, mhp: D.car }); break;
      }
      if (!st.M.path) { st.M.g = '.'.repeat(W * H); st.M.path = Array.from({ length: W }, (_, x) => [x, 3]); st.M.exit = [W - 1, 3]; st.o.push({ k: 'car', x: 0, y: 3, hp: D.car, mhp: D.car }); }
    }
    if (mt === MI.hold) {
      const c = freeTiles(st, (x, y) => x >= 2 && x <= 4); U.shuffle(c);
      const a = c[0], b = c.find((p) => man(p[0], p[1], a[0], a[1]) >= 3) || c[1];
      st.o.push({ k: 'dev', x: a[0], y: a[1], hp: D.dev, mhp: D.dev }); st.o.push({ k: 'dev', x: b[0], y: b[1], hp: D.dev, mhp: D.dev });
    }
    if (mt === MI.data) {
      const c = freeTiles(st, (x) => x >= 4); U.shuffle(c);
      const got = [];
      for (const p of c) { if (got.length >= 3) break; if (got.every((q) => man(q[0], q[1], p[0], p[1]) >= 3)) got.push(p); }
      while (got.length < 3) got.push(c[got.length]);
      got.forEach((p) => st.o.push({ k: 'data', x: p[0], y: p[1], hp: 1 }));
    }
    // 대원 배치(왼쪽 두 줄)
    const left = freeTiles(st, (x, y) => x <= 1 && !(st.M.path && st.M.path[0][0] === x && st.M.path[0][1] === y)); U.shuffle(left);
    left.sort((a, b) => a[0] - b[0]);
    st.u.forEach((u, i) => { const p = left[i] || [0, i]; u.x = p[0]; u.y = p[1]; });
    if (mt === MI.nest) {
      const c = freeTiles(st, (x) => x >= W - 3); U.shuffle(c);
      const a = c[0], b = c.find((p) => man(p[0], p[1], a[0], a[1]) >= 4) || c[1];
      addEnemy(st, EI.nest, a[0], a[1]); addEnemy(st, EI.nest, b[0], b[1]);
    }
    const n0 = D.e0 + st.mi;
    for (let i = 0; i < n0; i++) { const c = freeTiles(st, (x) => x >= 6); if (!c.length) break; const p = pickOne(c); addEnemy(st, rollEnemy(st), p[0], p[1]); }
    if (st.M.bud < 99) st.M.bud = Math.max(0, st.M.bud);
    placeSpawns(st);
    st.done = Array(st.np).fill(0);
    st.last = { id: (st.last.id | 0) + 1, ev: [['ph', '작전 ' + (st.mi + 1) + ' — ' + M.nm]] };
    st.log = []; logp(st, '▶ 작전 ' + (st.mi + 1) + '/' + st.ops + ' · ' + M.nm + ' · ' + FAC[fac].nm);
    planEnemies(st);
    autoDone(st);
  }
  function spawnCount(st) {
    const D = DIFF[st.dif], mt = st.M.mt;
    let n = D.sp + (st.mi >= 2 ? 1 : 0) + (st.mi >= 4 ? 1 : 0);
    if (mt === MI.nest) n = Math.max(0, n - 1);
    if (mt === MI.kill) n = Math.min(n, st.M.bud);
    if (st.rn >= st.M.rl) n = 0;
    return n;
  }
  function placeSpawns(st) {
    const n = spawnCount(st);
    for (let i = 0; i < n; i++) {
      const c = freeTiles(st, (x, y) => x >= W - 2 && !st.sp.some((s) => s[0] === x && s[1] === y));
      if (!c.length) break;
      const p = pickOne(c); st.sp.push([p[0], p[1], -1]);
      if (st.M.mt === MI.kill) st.M.bud--;
    }
    if (st.M.mt === MI.nest && st.rn % 2 === 1 && st.rn < st.M.rl) {
      for (const e of st.e) if (e.t === EI.nest) {
        const c = D4.map(([dx, dy]) => [e.x + dx, e.y + dy]).filter(([x, y]) => freeT(st, x, y) && tileAt(st, x, y) === '.' && !st.sp.some((s) => s[0] === x && s[1] === y));
        if (c.length) { const p = pickOne(c); st.sp.push([p[0], p[1], -1]); }
      }
    }
  }

  /* ================= 피해 · 밀기 ================= */
  function armorU(st, u) { return uDef(u).ar + (u.tb ? 2 : 0); }
  function hurtU(st, u, dm, src) {
    if (u.down || dm <= 0) return 0;
    let d = Math.max(0, dm - armorU(st, u));
    if (u.sh > 0 && d > 0) { const a = Math.min(u.sh, d); u.sh -= a; d -= a; }
    if (d <= 0) { ev(st, ['hit', u.x, u.y, 0, 1]); return 0; }
    u.hp -= d; ev(st, ['hit', u.x, u.y, d, 1]);
    if (u.hp <= 0) { u.hp = 0; u.down = 1; u.acted = 1; st.sk[u.own][3]++; ev(st, ['tx', u.x, u.y, '쓰러짐']); logp(st, '✖ ' + uDef(u).nm + ' 쓰러짐' + (src ? ' (' + src + ')' : '')); }
    return d;
  }
  function hurtE(st, e, dm, seat) {
    if (e.hp <= 0) return 0;
    const d = Math.max(1, dm - eDef(e).ar);
    e.hp -= d; ev(st, ['hit', e.x, e.y, d, 0]);
    if (seat >= 0 && st.sk[seat]) st.sk[seat][1] += d;
    if (e.hp <= 0) {
      ev(st, ['die', ekey(e), e.x, e.y]);
      st.e = st.e.filter((q) => q !== e);
      if (seat >= 0 && st.sk[seat]) st.sk[seat][0]++;
      logp(st, '✔ ' + eDef(e).nm + ' 처치');
    }
    return d;
  }
  // 칸 하나에 피해: seat = 공격한 자리(적이면 −1)
  function hurtAt(st, x, y, dm, seat, src) {
    if (!inb(x, y)) return;
    if (tileAt(st, x, y) === 'x') { setTile(st, x, y, '.'); ev(st, ['tx', x, y, '상자 부숨']); return; }
    const q = occ(st, x, y);
    if (!q) return;
    if (q.k === 'u') hurtU(st, q.o, dm, src);
    else if (q.k === 'e') hurtE(st, q.o, dm, seat);
    else if (q.k === 't') { q.o.hp -= dm; ev(st, ['hit', x, y, dm, 1]); if (q.o.hp <= 0) { st.tu = null; ev(st, ['tx', x, y, '포탑 파괴']); } }
    else if (q.k === 'o') { if (q.o.k === 'car') dm = Math.max(1, dm - 1); q.o.hp = Math.max(0, q.o.hp - dm); ev(st, ['hit', x, y, dm, 1]); if (q.o.hp <= 0) { ev(st, ['tx', x, y, '파괴!']); logp(st, '✖ ' + (q.o.k === 'car' ? '수송차' : '통신 장치') + ' 파괴'); } }
  }
  // (x,y)에 있는 대상을 (dx,dy)로 1칸 밀기 — 막히면 둘 다 1 피해
  function push(st, x, y, dx, dy, seat) {
    const q = occ(st, x, y); if (!q) return;
    if (q.k === 'o' || q.k === 't' || (q.k === 'e' && eDef(q.o).big) || (q.k === 'u' && q.o.down)) return;
    const nx = x + dx, ny = y + dy;
    if (freeT(st, nx, ny)) {
      q.o.x = nx; q.o.y = ny;
      ev(st, ['mv', q.k === 'u' ? ukey(q.o) : ekey(q.o), x, y, nx, ny]);
      return;
    }
    ev(st, ['tx', x, y, '쾅!']);
    const blk = inb(nx, ny) ? occ(st, nx, ny) : null;
    if (q.k === 'u') hurtU(st, q.o, 1, '부딪힘'); else hurtE(st, q.o, 1, seat);
    if (blk) hurtAt(st, nx, ny, 1, seat, '부딪힘');
    else if (inb(nx, ny) && tileAt(st, nx, ny) === 'x') hurtAt(st, nx, ny, 1, seat);
  }

  /* ================= 적의 공격 (보여 주기 = 실제) ================= */
  // 공격 칸 계산: {tiles:[[x,y,dm,push]], line:[[x,y]], to:[x,y](돌진 도착)}
  function intentTiles(st, e) {
    const d = eDef(e), it = e.it, out = { tiles: [], line: [], to: null };
    if (!it || !d.k) return out;
    if (it.k === 'lob') {
      const tx = e.x + it.o[0], ty = e.y + it.o[1];
      if (!inb(tx, ty)) return out;
      out.tiles.push([tx, ty, d.dm, 0]); out.line.push([tx, ty]);
      for (const [dx, dy] of D4) if (inb(tx + dx, ty + dy)) out.tiles.push([tx + dx, ty + dy, d.sp || 1, 0]);
      return out;
    }
    const [dx, dy] = it.d;
    if (it.k === 'mel') { const x = e.x + dx, y = e.y + dy; if (inb(x, y)) out.tiles.push([x, y, d.dm, d.push | 0]); out.line.push([x, y]); return out; }
    let x = e.x, y = e.y;
    for (let s = 1; s <= d.rg; s++) {
      x += dx; y += dy;
      if (!inb(x, y)) break;
      const c = tileAt(st, x, y);
      if (c === '#') break;
      out.line.push([x, y]);
      if (it.k === 'bm') { out.tiles.push([x, y, d.dm, 0]); continue; }
      const q = occ(st, x, y, e);
      const blocks = c === 'x' || (q && !(q.k === 'u' && q.o.down));
      if (blocks) { out.tiles.push([x, y, d.dm, it.k === 'chg' || d.push ? 1 : 0]); if (it.k === 'chg') out.to = [x - dx, y - dy]; break; }
    }
    if (it.k === 'chg' && !out.to && out.line.length) { const l = out.line[out.line.length - 1]; out.to = freeT(st, l[0], l[1], e) ? l : null; }
    return out;
  }
  function execIntent(st, e) {
    const d = eDef(e); if (!e.it || !d.k) return;
    const T = intentTiles(st, e), k = e.it.k;
    if (k === 'chg' && T.to && (T.to[0] !== e.x || T.to[1] !== e.y)) {
      if (freeT(st, T.to[0], T.to[1], e)) { ev(st, ['mv', ekey(e), e.x, e.y, T.to[0], T.to[1]]); e.x = T.to[0]; e.y = T.to[1]; }
    } else if (k !== 'mel' && k !== 'chg' && T.line.length) {
      const l = T.tiles.length ? T.tiles[0] : T.line[T.line.length - 1];
      ev(st, ['sh', e.x, e.y, l[0], l[1], k === 'bm' ? 2 : k === 'lob' ? 3 : 1]);
    }
    if (k === 'bm' && T.line.length) { const l = T.line[T.line.length - 1]; ev(st, ['sh', e.x, e.y, l[0], l[1], 2]); }
    if (k === 'lob' && T.tiles.length) ev(st, ['bm', T.tiles[0][0], T.tiles[0][1], 1]);
    for (const [x, y, dm, pu] of T.tiles) {
      if (!st.e.includes(e) && k !== 'lob') break;
      hurtAt(st, x, y, dm, -1, d.nm);
      if (pu) { const [dx, dy] = e.it.d; push(st, x, y, dx, dy, -1); }
    }
  }

  /* ================= 적 이동 · 조준 ================= */
  // 적이 (x,y)에서 대상 (tx,ty)를 칠 수 있으면 조준(it), 아니면 null
  function aimFrom(st, e, x, y, tx, ty) {
    const d = eDef(e), ox = e.x, oy = e.y;
    if (!d.k) return null;
    const dx = tx - x, dy = ty - y;
    if (d.k === 'lob') { const c = cheb(x, y, tx, ty); return c >= 2 && c <= d.rg ? { k: 'lob', o: [dx, dy] } : null; }
    if (dx !== 0 && dy !== 0) return null;
    const dist = Math.abs(dx) + Math.abs(dy);
    if (dist === 0) return null;
    const ux = sgn(dx), uy = sgn(dy);
    if (d.k === 'mel') return dist === 1 ? { k: 'mel', d: [ux, uy] } : null;
    if (dist > d.rg) return null;
    e.x = x; e.y = y;
    let ok = true;
    for (let s = 1; s < dist; s++) {
      const cx = x + ux * s, cy = y + uy * s, c = tileAt(st, cx, cy);
      if (c === '#') { ok = false; break; }
      if (d.k !== 'bm') { const q = occ(st, cx, cy, e); if (c === 'x' || (q && !(q.k === 'u' && q.o.down))) { ok = false; break; } }
    }
    e.x = ox; e.y = oy;
    return ok ? { k: d.k, d: [ux, uy] } : null;
  }
  function enemyReach(st, e) {
    const d = eDef(e), out = [[e.x, e.y, 0]];
    if (!d.mv) return out;
    if (d.blink) { for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if ((x !== e.x || y !== e.y) && cheb(x, y, e.x, e.y) <= 5 && freeT(st, x, y, e) && !hasSpawn(st, x, y)) out.push([x, y, 1]); return out; }
    const dist = new Int8Array(W * H).fill(-1), q = [[e.x, e.y]]; dist[e.y * W + e.x] = 0;
    while (q.length) {
      const [x, y] = q.shift(), dd = dist[y * W + x];
      if (dd >= d.mv) continue;
      for (const [dx, dy] of D4) {
        const nx = x + dx, ny = y + dy; if (!inb(nx, ny) || dist[ny * W + nx] >= 0) continue;
        const c = tileAt(st, nx, ny); if (c === '#' || (c === 'x' && !d.fly)) continue;
        const o = occ(st, nx, ny, e); if (o && o.k !== 'e') continue;
        dist[ny * W + nx] = dd + 1; q.push([nx, ny]);
        if (!o && c !== 'x' && !hasSpawn(st, nx, ny)) out.push([nx, ny, dd + 1]);
      }
    }
    return out;
  }
  const hasSpawn = (st, x, y) => st.sp.some((s) => s[0] === x && s[1] === y);
  function enemyTargets(st) {
    const T = [], mt = st.M.mt;
    for (const u of st.u) if (!u.down) T.push([u.x, u.y, 10 + (u.mhp - u.hp) * 0.6 + (uDef(u).ar ? -2 : 0) + (u.tb ? -3 : 0)]);
    if (st.tu) T.push([st.tu.x, st.tu.y, 11]);
    for (const o of st.o) if (o.k !== 'data' && o.hp > 0) T.push([o.x, o.y, mt === MI.hold ? 11.5 : mt === MI.escort ? 9.5 : 8]);
    return T;
  }
  function planEnemy(st, e, forced) {
    const d = eDef(e);
    if (!d.k) { e.it = null; return; }
    const T = forced ? [forced] : enemyTargets(st);
    const R = forced ? forced.reach : enemyReach(st, e);
    let best = null, bs = -1e9;
    const noise = st.dif === 0 ? 4 : st.dif === 1 ? 1.5 : 0.4;
    for (const [x, y, dd] of R) {
      const hz = tileAt(st, x, y) === '~' && !d.fly ? 4 : 0;
      for (const t of T) {
        const it = aimFrom(st, e, x, y, t[0], t[1]); if (!it) continue;
        const s = t[2] - dd * 0.25 - hz + Math.random() * noise;
        if (s > bs) { bs = s; best = [x, y, it]; }
      }
    }
    if (best) {
      if (best[0] !== e.x || best[1] !== e.y) { ev(st, ['mv', ekey(e), e.x, e.y, best[0], best[1]]); e.x = best[0]; e.y = best[1]; }
      e.it = best[2]; return;
    }
    if (forced) return;
    // 칠 대상이 없으면 가까운 대상 쪽으로 다가가기
    let tb = null, td = 1e9;
    for (const [x, y] of R) for (const t of T) { const dd2 = man(x, y, t[0], t[1]) + (tileAt(st, x, y) === '~' && !d.fly ? 2 : 0); if (dd2 < td) { td = dd2; tb = [x, y, t]; } }
    if (tb) {
      if (tb[0] !== e.x || tb[1] !== e.y) { ev(st, ['mv', ekey(e), e.x, e.y, tb[0], tb[1]]); e.x = tb[0]; e.y = tb[1]; }
      const t = tb[2], dx = t[0] - e.x, dy = t[1] - e.y;
      if (d.k === 'lob') { const c = cheb(e.x, e.y, t[0], t[1]); e.it = c >= 2 && c <= d.rg ? { k: 'lob', o: [dx, dy] } : null; }
      else { const ax = Math.abs(dx) >= Math.abs(dy); const dir = ax ? [sgn(dx), 0] : [0, sgn(dy)]; e.it = dir[0] || dir[1] ? { k: d.k, d: dir } : null; }
    } else e.it = null;
  }
  function planEnemies(st) { for (const e of st.e.slice()) planEnemy(st, e); }

  /* ================= 대원 행동 ================= */
  function reachU(st, u) {
    const mv = mvOf(st, u), out = [[u.x, u.y]], dist = new Int8Array(W * H).fill(-1), q = [[u.x, u.y]];
    dist[u.y * W + u.x] = 0;
    while (q.length) {
      const [x, y] = q.shift(), dd = dist[y * W + x]; if (dd >= mv) continue;
      for (const [dx, dy] of D4) {
        const nx = x + dx, ny = y + dy; if (!inb(nx, ny) || dist[ny * W + nx] >= 0) continue;
        if (solidT(tileAt(st, nx, ny))) continue;
        const o = occ(st, nx, ny, u); if (o && o.k !== 'u') continue;
        dist[ny * W + nx] = dd + 1; q.push([nx, ny]);
        if (!o) out.push([nx, ny]);
      }
    }
    return out;
  }
  // 기본 공격 대상(대원이 (x,y)에 있을 때)
  function atkTargets(st, u, x, y) {
    const R = uDef(u), out = [];
    for (const e of st.e) {
      if (R.atk.rg === 1) { if (man(x, y, e.x, e.y) === 1) out.push(e); continue; }
      if (cheb(x, y, e.x, e.y) <= R.atk.rg && losClear(st, x, y, e.x, e.y)) out.push(e);
    }
    return out;
  }
  function gTiles(cx, cy) { const t = []; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (inb(cx + dx, cy + dy)) t.push([cx + dx, cy + dy]); return t; }
  function lineTiles(st, x, y, dx, dy, n) { const t = []; for (let s = 1; s <= n; s++) { const cx = x + dx * s, cy = y + dy * s; if (!inb(cx, cy) || tileAt(st, cx, cy) === '#') break; t.push([cx, cy]); } return t; }
  // 능력 대상 목록 (null = 대상 없이 바로)
  function ablTargets(st, u, x, y) {
    const R = uDef(u);
    switch (R.id) {
      case 'asl': return null;
      case 'grd': return null;
      case 'snp': return D4.map(([dx, dy]) => [x + dx, y + dy]).filter(([a, b]) => inb(a, b) && tileAt(st, a, b) !== '#');
      case 'med': return st.u.filter((v) => cheb(x, y, v.x, v.y) <= 2 && (v.down || v.hp < v.mhp || v === u)).map((v) => [v === u ? x : v.x, v === u ? y : v.y]);
      case 'eng': return D4.map(([dx, dy]) => [x + dx, y + dy]).filter(([a, b]) => freeT(st, a, b, u) && tileAt(st, a, b) !== '~' && !hasSpawn(st, a, b));
      case 'gre': { const t = []; for (let b = 0; b < H; b++) for (let a = 0; a < W; a++) { const c = cheb(x, y, a, b); if (c >= 2 && c <= 5) t.push([a, b]); } return t; }
    }
    return null;
  }
  // 한 대원 행동: a = {u, x, y, a:'atk'|'abl'|'rev'|'int'|'wait', tx, ty}
  function doAct(st, seat, a) {
    const u = st.u[a.u | 0];
    if (!u || u.own !== seat || !ready(u)) throw new Error('bad unit');
    const R = uDef(u);
    const to = (a.x | 0) === u.x && (a.y | 0) === u.y ? [u.x, u.y] : reachU(st, u).find((p) => p[0] === (a.x | 0) && p[1] === (a.y | 0));
    if (!to) throw new Error('bad move');
    const moved = to[0] !== u.x || to[1] !== u.y;
    const fx = u.x, fy = u.y;
    // 검증 먼저(이동 위치 기준)
    const k = a.a, tx = a.tx | 0, ty = a.ty | 0;
    u.x = to[0]; u.y = to[1];
    let ok = true;
    if (k === 'atk') ok = atkTargets(st, u, u.x, u.y).some((e) => e.x === tx && e.y === ty);
    else if (k === 'abl') { if (u.cd > 0) ok = false; else { const T = ablTargets(st, u, u.x, u.y); ok = T === null || T.some((p) => p[0] === tx && p[1] === ty); } }
    else if (k === 'rev') ok = st.u.some((v) => v.down && man(v.x, v.y, u.x, u.y) === 1 && v.x === tx && v.y === ty);
    else if (k === 'int') ok = st.o.some((o) => o.k === 'data' && cheb(o.x, o.y, u.x, u.y) <= 1 && o.x === tx && o.y === ty);
    else if (k !== 'wait') ok = false;
    if (!ok) { u.x = fx; u.y = fy; throw new Error('bad action'); }
    if (moved) ev(st, ['mv', ukey(u), fx, fy, u.x, u.y]);
    u.mvd = moved ? 1 : 0;
    const nm = R.nm;
    if (k === 'atk') {
      const e = st.e.find((q) => q.x === tx && q.y === ty);
      let dm = atkDm(st, u) + (R.id === 'snp' && !moved ? 2 : 0);
      ev(st, ['sh', u.x, u.y, tx, ty, 0]);
      hurtE(st, e, dm, seat);
      if (R.atk.push) push(st, tx, ty, tx - u.x, ty - u.y, seat);
    } else if (k === 'abl') {
      u.cd = cdOf(st, u); st.sk[seat][2] += 0;
      if (R.id === 'asl') {
        ev(st, ['bm', u.x, u.y, 1]);
        for (const [dx, dy] of D4) { const x = u.x + dx, y = u.y + dy; const q = occ(st, x, y); if (q && q.k === 'e') { const e = q.o; hurtE(st, e, 3, seat); if (st.e.includes(e)) push(st, e.x, e.y, dx, dy, seat); } }
        logp(st, '★ ' + nm + ' 돌파 사격');
      } else if (R.id === 'snp') {
        const dx = tx - u.x, dy = ty - u.y; const L2 = lineTiles(st, u.x, u.y, dx, dy, 8);
        if (L2.length) ev(st, ['sh', u.x, u.y, L2[L2.length - 1][0], L2[L2.length - 1][1], 4]);
        for (const [x, y] of L2) { const q = occ(st, x, y); if (q && q.k === 'e') hurtE(st, q.o, 5, seat); }
        logp(st, '★ ' + nm + ' 관통탄');
      } else if (R.id === 'grd') {
        u.tb = 1; ev(st, ['tx', u.x, u.y, '도발!']);
        for (const e of st.e.slice()) {
          if (!eDef(e).k || cheb(e.x, e.y, u.x, u.y) > 4) continue;
          const R2 = enemyReach(st, e).filter((p) => p[2] <= 2 || eDef(e).blink);
          planEnemy(st, e, Object.assign([u.x, u.y, 50], { reach: R2 }));
        }
        logp(st, '★ ' + nm + ' 도발 — 적이 방패병을 노려요');
      } else if (R.id === 'med') {
        const v = st.u.find((q) => (q === u ? u.x === tx && u.y === ty : q.x === tx && q.y === ty));
        if (v.down) { v.down = 0; v.hp = Math.min(v.mhp, 5); v.acted = 1; ev(st, ['heal', v.x, v.y, 5]); logp(st, '♥ ' + uDef(v).nm + ' 일으킴'); }
        else { const h = Math.min(5, v.mhp - v.hp); v.hp += h; ev(st, ['heal', v.x, v.y, h]); }
        st.sk[seat][2] += 5;
      } else if (R.id === 'eng') {
        st.tu = { x: tx, y: ty, hp: 5 }; ev(st, ['tx', tx, ty, '포탑 설치']); logp(st, '★ 공병 포탑 설치');
      } else if (R.id === 'gre') {
        ev(st, ['sh', u.x, u.y, tx, ty, 3]); ev(st, ['bm', tx, ty, 2]);
        for (const [x, y] of gTiles(tx, ty)) hurtAt(st, x, y, 3, seat, '유탄');
        logp(st, '★ 폭파병 유탄');
      }
    } else if (k === 'rev') {
      const v = st.u.find((q) => q.down && q.x === tx && q.y === ty);
      v.down = 0; v.hp = Math.min(v.mhp, 3); v.acted = 1; ev(st, ['heal', v.x, v.y, 3]); st.sk[seat][2] += 3; logp(st, '♥ ' + uDef(v).nm + ' 일으킴');
    } else if (k === 'int') {
      st.o = st.o.filter((o) => !(o.k === 'data' && o.x === tx && o.y === ty)); st.M.got++;
      ev(st, ['tx', tx, ty, '자료 회수!']); logp(st, '💾 자료 회수 ' + st.M.got + '/3');
    }
    u.acted = 1;
  }

  /* ================= 적 차례 ================= */
  function enemyPhase(st) {
    ev(st, ['ph', '적 차례']);
    // 포탑 사격
    if (st.tu) {
      let best = null, bd = 99;
      for (const e of st.e) { const c = cheb(e.x, e.y, st.tu.x, st.tu.y); if (c <= 4 && c < bd && losClear(st, st.tu.x, st.tu.y, e.x, e.y)) { bd = c; best = e; } }
      if (best) { ev(st, ['sh', st.tu.x, st.tu.y, best.x, best.y, 0]); const ow = st.u.find((v) => uDef(v).id === 'eng'); hurtE(st, best, 2, ow ? ow.own : -1); }
    }
    for (const e of st.e.slice()) { if (!st.e.includes(e)) continue; execIntent(st, e); e.age++; }
    // 웅덩이
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (tileAt(st, x, y) === '~') {
      const q = occ(st, x, y); if (!q) continue;
      if (q.k === 'u' && !q.o.down) hurtU(st, q.o, 2, FAC[st.M.fac].hz);
      else if (q.k === 'e' && !eDef(q.o).fly && eDef(q.o).k) hurtE(st, q.o, 2, -1);
    }
    // 수송차
    if (st.M.mt === MI.escort) {
      const car = st.o.find((o) => o.k === 'car');
      if (car && car.hp > 0 && st.u.some((u) => !u.down && cheb(u.x, u.y, car.x, car.y) <= 2)) {
        for (let s = 0; s < 3; s++) {
          const nx = st.M.path[st.M.pi + 1]; if (!nx) break;
          if (occ(st, nx[0], nx[1], car)) break;
          ev(st, ['mv', 'car', car.x, car.y, nx[0], nx[1]]); car.x = nx[0]; car.y = nx[1]; st.M.pi++;
        }
      }
    }
    // 증원 등장
    const keep = [];
    for (const s of st.sp) {
      const q = occ(st, s[0], s[1]);
      if (q) { if (q.k === 'u') { hurtU(st, q.o, 1, '증원 막음'); ev(st, ['tx', s[0], s[1], '증원 막음']); } continue; }
      const e = addEnemy(st, rollEnemy(st), s[0], s[1]); ev(st, ['sp', ekey(e)]);
    }
    st.sp = keep;
    st.rn++;
    if (checkEnd(st, true)) return;
    placeSpawns(st);
    ev(st, ['ph', '라운드 ' + st.rn]);
    planEnemies(st);
    for (const u of st.u) { u.acted = u.down ? 1 : 0; u.mvd = 0; u.tb = 0; if (u.cd > 0) u.cd--; }
    st.done = Array(st.np).fill(0);
    autoDone(st);
  }
  function objDone(st) {
    const m = MIS[st.M.mt].id;
    if (m === 'kill') return st.e.length === 0 && st.M.bud <= 0 && !st.sp.length;
    if (m === 'data') return st.M.got >= 3;
    if (m === 'nest') return !st.e.some((e) => e.t === EI.nest);
    if (m === 'escort') { const car = st.o.find((o) => o.k === 'car'); return !!car && car.hp > 0 && st.M.pi >= st.M.path.length - 1; }
    return false;
  }
  // 끝났으면 true (afterEnemy: 적 차례 끝난 직후 — 라운드 제한 확인)
  function checkEnd(st, afterEnemy) {
    if (st.ph !== 'play') return true;
    const m = MIS[st.M.mt].id;
    let ok = null, why = '';
    if (objDone(st)) ok = true;
    else if (st.u.every((u) => u.down)) { ok = false; why = '부대 전멸'; }
    else if (m === 'hold' && st.o.filter((o) => o.k === 'dev' && o.hp > 0).length === 0) { ok = false; why = '통신 장치가 모두 파괴됐어요'; }
    else if (m === 'escort' && st.o.some((o) => o.k === 'car' && o.hp <= 0)) { ok = false; why = '수송차가 파괴됐어요'; }
    else if (afterEnemy && st.rn > st.M.rl) { if (m === 'hold') ok = true; else { ok = false; why = '시간 초과(라운드 ' + st.M.rl + ')'; } }
    if (ok === null) return false;
    finishMission(st, ok, why);
    return true;
  }
  function finishMission(st, ok, why) {
    const [mt, fac] = st.plan[st.mi];
    st.hist.push([mt, fac, ok ? 1 : 0, st.rn - 1]);
    ev(st, ['ph', ok ? '작전 성공!' : '작전 실패 — ' + why]);
    logp(st, ok ? '★ 작전 성공' : '✖ 작전 실패: ' + why);
    st.done = Array(st.np).fill(1);
    if (!ok) { st.ph = 'done'; st.res = { ok: 0, why }; return; }
    st.wins++;
    if (st.mi + 1 >= st.ops) { st.ph = 'done'; st.res = { ok: 1 }; return; }
    st.ph = 'up';
    const c = UPG.map((q, i) => i).filter((i) => (st.upg[i] | 0) < UPG[i].max);
    st.upc = U.shuffle(c).slice(0, 3);
  }
  function autoDone(st) {
    for (let s = 0; s < st.np; s++) if (!st.u.some((u) => u.own === s && ready(u))) st.done[s] = 1;
  }
  function maybeEnemy(st) {
    if (st.ph !== 'play') return;
    if (checkEnd(st, false)) return;
    autoDone(st);
    if (st.done.every((v) => v)) enemyPhase(st);
  }

  /* ================= 규약 함수 ================= */
  function actor(st) {
    if (!st) return null;
    if (st.ph === 'pick') { const a = []; for (let s = 0; s < st.np; s++) if (!st.rd[s]) a.push(s); return a.length ? a : null; }
    if (st.ph === 'up') { const h = st.ai.findIndex((v) => !v); return h >= 0 ? h : 0; }
    if (st.ph === 'play') { const a = []; for (let s = 0; s < st.np; s++) if (!st.done[s]) a.push(s); return a.length ? a : null; }
    return null;
  }
  function apply(st, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad');
    st.last = { id: (st.last.id | 0) + 1, ev: [] };
    if (st.ph === 'pick') {
      if (a.t === 'role') { const ui = a.u | 0; if (ui < 0 || ui >= NU || ownerOf(st, ui) !== seat || !(a.r >= 0 && a.r < ROLES.length)) throw new Error('bad role'); st.roles[ui] = a.r | 0; return st; }
      if (a.t === 'go') { st.rd[seat] = 1; if (st.rd.every((v) => v)) startMission(st); return st; }
      throw new Error('bad');
    }
    if (st.ph === 'up') {
      if (a.t !== 'up') throw new Error('bad');
      const k = st.upc[a.k | 0]; if (k === undefined) throw new Error('bad up');
      st.upg[k] = (st.upg[k] | 0) + 1; logp(st, '⬆ 부대 강화: ' + UPG[k].nm);
      st.mi++; st.upc = null; startMission(st); return st;
    }
    if (st.ph !== 'play') throw new Error('over');
    if (st.done[seat]) throw new Error('done');
    if (a.t === 'do') doAct(st, seat, a);
    else if (a.t === 'end') { st.done[seat] = 1; }
    else throw new Error('bad');
    maybeEnemy(st);
    return st;
  }
  function result(st) {
    if (!st || st.ph !== 'done') return null;
    const ok = st.res && st.res.ok;
    const col = (k) => st.sk.map((a) => String(a[k] | 0));
    return {
      winners: ok ? Array.from({ length: st.np }, (_, i) => i) : [],
      title: ok ? '모든 작전 성공 — 부대 귀환!' : '작전 실패',
      text: DIFF[st.dif].nm + ' · 작전 ' + st.ops + '개 중 ' + st.wins + '개 성공' + (!ok && st.res.why ? ' · ' + st.res.why : ''),
      stats: [{ label: '성공한 작전', value: st.wins + ' / ' + st.ops }, { label: '처치', values: col(0) }, { label: '준 피해', values: col(1) }, { label: '치료', values: col(2) }, { label: '쓰러짐', values: col(3), low: true }],
      highlights: st.hist.map((h) => MIS[h[0]].nm + ' (' + FAC[h[1]].nm + ') — ' + (h[2] ? '성공' : '실패')),
    };
  }

  /* ================= AI (동료 대원) ================= */
  // 적 차례 공격을 시뮬레이션한 뒤 상황 점수
  function simAttack(st) {
    st.last = { id: 0, ev: [] };
    if (st.tu) { let best = null, bd = 99; for (const e of st.e) { const c = cheb(e.x, e.y, st.tu.x, st.tu.y); if (c <= 4 && c < bd && losClear(st, st.tu.x, st.tu.y, e.x, e.y)) { bd = c; best = e; } } if (best) hurtE(st, best, 2, -1); }
    for (const e of st.e.slice()) if (st.e.includes(e)) execIntent(st, e);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (tileAt(st, x, y) === '~') { const q = occ(st, x, y); if (q && q.k === 'u' && !q.o.down) hurtU(st, q.o, 2); }
  }
  function value(st) {
    const m = MIS[st.M.mt].id;
    let v = 0;
    for (const u of st.u) {
      if (u.down) { v -= 16; continue; }
      v += Math.min(u.hp, 8) * 1.1 + u.hp * 0.25 + u.sh * 0.5;
      let nd = 99; for (const e of st.e) nd = Math.min(nd, man(u.x, u.y, e.x, e.y));
      if (nd < 99 && nd > 5) v -= (nd - 5) * 0.5;
      if (hasSpawn(st, u.x, u.y) && u.hp > 3) v += 2.5;
      if (u.cd > 0) v -= 0.6;
    }
    for (const e of st.e) { const d = eDef(e); v -= e.hp * 1.1 + 4 + (d.el ? 6 : 0) + (e.t === EI.nest ? 8 + e.hp * 1.5 : 0); }
    if (st.tu) v += st.tu.hp * 0.5 + 2;
    if (m === 'data') {
      v += st.M.got * 25;
      for (const o of st.o) if (o.k === 'data') { let md = 99; for (const u of st.u) if (!u.down) md = Math.min(md, cheb(u.x, u.y, o.x, o.y)); v -= md * 1.2; }
    } else if (m === 'hold') {
      for (const o of st.o) if (o.k === 'dev') v += o.hp > 0 ? 10 + o.hp * 3 : 0;
    } else if (m === 'escort') {
      const car = st.o.find((o) => o.k === 'car');
      if (car) { v += car.hp > 0 ? 15 + car.hp * 3 : -60; v += st.M.pi * 5; const near = st.u.filter((u) => !u.down && cheb(u.x, u.y, car.x, car.y) <= 2).length; v += near ? 8 + near : -st.M.pi * 0.5 - 4;
        for (let k = 1; k <= 3; k++) { const p = st.M.path[st.M.pi + k]; if (p && st.u.some((u) => u.x === p[0] && u.y === p[1])) v -= 5; } }
    } else if (m === 'kill') v -= st.sp.length * 3;
    if (st.ph !== 'play') v += st.res && !st.res.ok ? -200 : 200;
    return v;
  }
  function genCands(st, u) {
    const out = [], R = uDef(u);
    for (const [x, y] of reachU(st, u)) {
      out.push({ x, y, a: 'wait' });
      const ox = u.x, oy = u.y; u.x = x; u.y = y;
      for (const e of atkTargets(st, u, x, y)) out.push({ x, y, a: 'atk', tx: e.x, ty: e.y });
      if (u.cd === 0) {
        const T = ablTargets(st, u, x, y);
        if (T === null) {
          if (R.id === 'asl' ? D4.some(([dx, dy]) => { const q = occ(st, x + dx, y + dy, u); return q && q.k === 'e'; }) : st.e.some((e) => eDef(e).k && cheb(e.x, e.y, x, y) <= 4)) out.push({ x, y, a: 'abl', tx: x, ty: y });
        } else if (R.id === 'gre') {
          let bs = 0, bt = null;
          for (const [a, b] of T) {
            let s = 0; for (const [c, d] of gTiles(a, b)) { const q = occ(st, c, d, null); if (q && q.k === 'e') s += eDef(q.o).ar ? 4 : 3; else if (q && (q.k === 'u' && !q.o.down)) s -= 6; else if (c === x && d === y) s -= 6; else if (q) s -= 4; }
            if (s > bs) { bs = s; bt = [a, b]; }
          }
          if (bt && bs >= 5) out.push({ x, y, a: 'abl', tx: bt[0], ty: bt[1] });
        } else if (R.id === 'snp') {
          for (const [a, b] of T) { const dx = a - x, dy = b - y; if (lineTiles(st, x, y, dx, dy, 8).some(([c, d]) => { const q = occ(st, c, d); return q && q.k === 'e'; })) out.push({ x, y, a: 'abl', tx: a, ty: b }); }
        } else if (R.id === 'eng') { if (!st.tu || st.tu.hp < 3) T.slice(0, 3).forEach(([a, b]) => out.push({ x, y, a: 'abl', tx: a, ty: b })); }
        else if (R.id === 'med') { for (const [a, b] of T) { const v = st.u.find((q) => (q === u ? a === x && b === y : q.x === a && q.y === b)); if (v && (v.down || v.mhp - v.hp >= 3)) out.push({ x, y, a: 'abl', tx: a, ty: b }); } }
      }
      for (const v of st.u) if (v.down && man(v.x, v.y, x, y) === 1) out.push({ x, y, a: 'rev', tx: v.x, ty: v.y });
      for (const o of st.o) if (o.k === 'data' && cheb(o.x, o.y, x, y) <= 1) out.push({ x, y, a: 'int', tx: o.x, ty: o.y });
      u.x = ox; u.y = oy;
    }
    return out;
  }
  function bestFor(st, seat, u, lv) {
    const C = genCands(st, u);
    if (lv <= 1 && Math.random() < 0.3) return { a: pickOne(C), v: 0 };
    const noise = lv <= 1 ? 6 : lv === 2 ? 1.2 : 0.2;
    let best = null, bv = -1e9;
    for (const c of C) {
      const s = clone(st);
      try { doAct(s, seat, Object.assign({ u: u.id }, c)); } catch (e) { continue; }
      let v;
      if (objDone(s)) v = 1000;
      else { simAttack(s); v = value(s); }
      if (lv >= 3 && c.a === 'wait' && u.cd === 0) v -= 0.3;
      v += Math.random() * noise;
      if (v > bv) { bv = v; best = c; }
    }
    return { a: best || { x: u.x, y: u.y, a: 'wait' }, v: bv };
  }
  function ai(st, seat, lv) {
    lv = lv || 2;
    if (st.ph === 'pick') {
      const mine = st.roles.map((r, i) => i).filter((i) => ownerOf(st, i) === seat);
      return { t: 'go', _m: mine.length };
    }
    if (st.ph === 'up') {
      const pr = ['hp', 'sh', 'dmg', 'mv', 'cd'];
      const c = st.upc.map((k, i) => [i, pr.indexOf(UPG[k].id) + Math.random() * (lv >= 3 ? 0.5 : 3)]).sort((a, b) => a[1] - b[1]);
      return { t: 'up', k: c[0][0] };
    }
    if (st.ph !== 'play') return null;
    const mine = st.u.filter((u) => u.own === seat && ready(u));
    if (!mine.length) return { t: 'end' };
    let pick = null;
    if (lv >= 3 && mine.length > 1) {
      // 가장 이득이 큰 대원부터
      let bv = -1e9;
      for (const u of mine) { const r = bestFor(st, seat, u, lv); if (r.v > bv) { bv = r.v; pick = Object.assign({ u: u.id }, r.a); } }
    } else {
      // 위험한 대원·붙은 대원 먼저
      const u = mine.slice().sort((a, b) => urg(st, b) - urg(st, a))[0];
      pick = Object.assign({ u: u.id }, bestFor(st, seat, u, lv).a);
    }
    return Object.assign({ t: 'do' }, pick);
  }
  function urg(st, u) {
    let s = 0; for (const e of st.e) { const T = intentTiles(st, e); if (T.tiles.some((t) => t[0] === u.x && t[1] === u.y)) s += 5; s += Math.max(0, 4 - man(e.x, e.y, u.x, u.y)); }
    return s + (uDef(u).id === 'med' ? 1 : 0);
  }

  /* ================= 화면 ================= */
  const CSS = `
.sf{position:absolute;inset:0;display:flex;background:#120e16;color:var(--ink);font:13px/1.35 var(--f-body),sans-serif}
.sf.port{flex-direction:column}
.sf-bd{position:relative;flex:1;min-width:0;min-height:0}
.sf-side{flex:0 0 330px;overflow-y:auto;padding:10px;display:flex;flex-direction:column;gap:8px;background:var(--surface);border-left:1px solid rgba(255,255,255,.08)}
.sf.port .sf-side{border-left:0;border-top:1px solid rgba(255,255,255,.08)}
.sf-card{background:var(--surface-2);border-radius:10px;padding:8px 10px}
.sf-h{font:16px var(--f-display),sans-serif;letter-spacing:.5px}
.sf-sub{color:var(--muted);font-size:12px}
.sf-obj{margin-top:4px;font-weight:600;color:#ffd98a}
.sf-hint{background:#2a2236;border-left:3px solid var(--brass);border-radius:8px;padding:7px 9px;font-size:12.5px}
.sf-hint.warn{border-left-color:#ee6a55;background:#3a1f22}
.sf-row{display:flex;align-items:center;gap:8px;min-height:44px;padding:3px 8px;border-radius:8px;cursor:pointer;background:rgba(255,255,255,.03);border:2px solid transparent}
.sf-row.on{border-color:#fff}.sf-row.off{opacity:.5}
.sf-row .ic{font-size:20px;width:26px;text-align:center}
.sf-row .nm{flex:1;min-width:0}.sf-row .nm b{display:block}.sf-row .nm small{color:var(--muted)}
.sf-hp{font:12px var(--f-mono),monospace;text-align:right}
.sf-acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.sf-b{min-height:44px;min-width:44px;padding:6px 10px;border-radius:9px;border:2px solid transparent;background:#3a3050;color:var(--ink);cursor:pointer;font:inherit;font-weight:600}
.sf-b.on{border-color:var(--brass)}.sf-b:disabled{opacity:.4;cursor:default}
.sf-b.pri{background:var(--brass);color:#1b1408}.sf-b.dng{background:#5a2a2a}
.sf-log{font-size:12px;color:var(--muted);display:flex;flex-direction:column;gap:2px}
.sf-ov{position:absolute;inset:0;background:rgba(10,8,14,.84);display:flex;align-items:center;justify-content:center;z-index:5}
.sf-pop{width:min(900px,calc(100% - 20px));max-height:calc(100% - 20px);overflow:auto;background:var(--surface);border-radius:14px;padding:14px 16px;display:flex;flex-direction:column;gap:10px}
.sf-chips{display:flex;flex-wrap:wrap;gap:6px}
.sf-u{display:flex;flex-direction:column;gap:6px;padding:8px;border-radius:10px;background:var(--surface-2)}
.sf-up{display:flex;gap:10px;flex-wrap:wrap}.sf-up .sf-b{flex:1 1 200px;text-align:left;padding:10px 12px;font-weight:400}
`;
  const DUR = { mv: 0.2, sh: 0.15, bm: 0.2, hit: 0.05, heal: 0.05, tx: 0.03, die: 0.07, sp: 0.12, ph: 0.4 };
  const escH = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  function mount(root, api) {
    const h = L.h;
    if (!document.getElementById('sf-css')) document.head.appendChild(h('style', { id: 'sf-css', text: CSS }));
    const spd = () => ((L.debug && L.debug.speed) || 1) * (L.speed ? L.speed() : 1);
    const R0 = h('div', { class: 'sf' }), bd = h('div', { class: 'sf-bd' }), side = h('div', { class: 'sf-side' });
    R0.append(bd, side); root.appendChild(R0);
    const C = U.canvas(bd), g = C.ctx;
    let S = null, P = null, sel = -1, stg = null, mode = '', hov = null, anim = null, floats = [], banner = null, intro = null, introKey = '', nextAfter = false, dead = false;
    const P_ = (s) => api.players[s] || { name: '?', color: '#888' };
    const mineSeat = (s) => !!S && S.ph === 'play' && api.canAct(s) && !S.done[s];
    const mine = (u) => !!u && !u.down && !u.acted && mineSeat(u.own);
    const actAs = (s, a) => { if (api.actAs) api.actAs(s, a); else api.act(a); };
    function lay() {
      const port = R0.clientWidth < R0.clientHeight * 1.05;
      R0.classList.toggle('port', port);
      side.style.flex = '0 0 ' + (port ? '46%' : Math.round(Math.max(270, Math.min(360, R0.clientWidth * 0.3))) + 'px');
    }
    const ro = new ResizeObserver(lay); ro.observe(R0); lay();
    function geo() { const ts = Math.max(8, Math.floor(Math.min((C.w - 12) / W, (C.h - 12) / H))); return { ts, ox: Math.round((C.w - ts * W) / 2), oy: Math.round((C.h - ts * H) / 2) }; }
    function cellAt(ev) { const p = C.local(ev), G2 = geo(); const x = Math.floor((p.x - G2.ox) / G2.ts), y = Math.floor((p.y - G2.oy) / G2.ts); return inb(x, y) ? [x, y] : null; }

    // ---------- 상호작용 ----------
    const selU = () => (S && sel >= 0 ? S.u[sel] : null);
    function withStage(fn) { const u = selU(); if (!u || !stg) return null; const ox = u.x, oy = u.y; u.x = stg[0]; u.y = stg[1]; try { return fn(u); } finally { u.x = ox; u.y = oy; } }
    function select(u) { sel = u ? u.id : -1; stg = u ? [u.x, u.y] : null; mode = ''; render(); }
    function nextUnit() { const L2 = S.u.filter(mine); if (!L2.length) { select(null); return; } const i = L2.findIndex((u) => u.id === sel); select(L2[(i + 1) % L2.length]); }
    function commit(a, tx, ty) { const u = selU(); if (!u || !stg) return; nextAfter = true; api.sfx(a === 'atk' ? 'hit' : a === 'wait' ? 'click' : 'pop'); const s = u.own, A2 = { t: 'do', u: u.id, x: stg[0], y: stg[1], a, tx: tx | 0, ty: ty | 0 }; sel = -1; stg = null; mode = ''; actAs(s, A2); }
    function ablNoTarget(u) { const id = uDef(u).id; return id === 'asl' || id === 'grd'; }
    function ablPick(x, y) {
      return withStage((u) => {
        const T = ablTargets(S, u, u.x, u.y) || [];
        if (uDef(u).id === 'snp') { const dx = x - u.x, dy = y - u.y; if (!dx && !dy) return null; const d = Math.abs(dx) >= Math.abs(dy) ? [sgn(dx), 0] : [0, sgn(dy)]; const t = [u.x + d[0], u.y + d[1]]; return T.some((p) => p[0] === t[0] && p[1] === t[1]) ? t : null; }
        return T.some((p) => p[0] === x && p[1] === y) ? [x, y] : null;
      });
    }
    function useAbility() {
      const u = selU(); if (!u || u.cd > 0) return;
      if (ablNoTarget(u)) { commit('abl', stg[0], stg[1]); return; }
      mode = mode === 'abl' ? '' : 'abl'; render();
    }
    function onTile(x, y, btn) {
      if (!S || S.ph !== 'play' || anim) return;
      if (btn === 2) { if (mode) { mode = ''; render(); } else select(null); return; }
      const u = selU();
      const at = S.u.find((v) => v.x === x && v.y === y);
      if (u && stg) {
        if (mode === 'abl') { const t = ablPick(x, y); if (t) { commit('abl', t[0], t[1]); return; } mode = ''; render(); return; }
        const e = S.e.find((q) => q.x === x && q.y === y);
        if (e && withStage((v) => atkTargets(S, v, v.x, v.y).includes(e))) { commit('atk', x, y); return; }
        if (at && at.down && man(at.x, at.y, stg[0], stg[1]) === 1) { commit('rev', x, y); return; }
        const dat = S.o.some((o) => o.k === 'data' && o.x === x && o.y === y);
        if (dat && cheb(x, y, stg[0], stg[1]) <= 1 && !(x !== stg[0] || y !== stg[1] ? false : false)) {
          const canMove = reachU(S, u).some((p) => p[0] === x && p[1] === y);
          if (!canMove || (x === stg[0] && y === stg[1])) { commit('int', x, y); return; }
        }
      }
      if (at && at !== u && mine(at)) { select(at); api.sfx('click'); return; }
      if (u && reachU(S, u).some((p) => p[0] === x && p[1] === y)) { stg = [x, y]; render(); return; }
      select(null);
    }
    C.cv.addEventListener('pointerdown', (ev) => { const c = cellAt(ev); if (c) onTile(c[0], c[1], ev.button); });
    C.cv.addEventListener('pointermove', (ev) => { const c = cellAt(ev); const k = c ? c.join() : ''; if (k !== (hov ? hov.join() : '')) { hov = c; showInfo(); } });
    C.cv.addEventListener('pointerleave', () => { hov = null; showInfo(); });
    C.cv.addEventListener('contextmenu', (ev) => ev.preventDefault());
    function endTurn() { if (!S || S.ph !== 'play') return; const L2 = []; for (let s = 0; s < S.np; s++) if (mineSeat(s)) L2.push(s); sel = -1; stg = null; L2.forEach((s) => actAs(s, { t: 'end' })); }
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !S || S.ph !== 'play' || anim) return;
      if (id === 'next') nextUnit();
      else if (id === 'end') endTurn();
      else if (id === 'abl') useAbility();
      else if (id === 'atk') { mode = ''; render(); }
      else if (id === 'wait' && selU()) commit('wait');
    }) : null;

    // ---------- 패널 ----------
    function dangerAt(st) { const m = {}; for (const e of st.e) for (const t of intentTiles(st, e).tiles) { const k = t[1] * W + t[0]; m[k] = (m[k] || 0) + t[2]; } return m; }
    function ctxHint() {
      if (!S || !S.M) return ['', 0];
      const dm = dangerAt(S);
      const myU = S.u.filter((u) => api.canAct(u.own));
      const hit = myU.find((u) => !u.down && !u.acted && dm[u.y * W + u.x]);
      if (S.mi === 0 && S.rn === 1 && myU.length && myU.every((u) => !u.acted)) return ['① 빛나는 내 대원을 누르고 → ② 파란 칸으로 이동 → ③ 노란 테두리 적을 눌러 공격(2 = 능력). 오른쪽 클릭 = 취소.', 0];
      if (hit) return ['⚠ ' + uDef(hit).nm + '이(가) 빨간 칸에 있어요 — 적 차례에 ' + dm[hit.y * W + hit.x] + ' 피해. 옮기거나 그 적을 처치·밀어내세요.', 1];
      if (S.u.some((u) => u.down)) return ['쓰러진 동료 옆 칸에서 「일으키기」(체력 3). 의무병은 2칸 거리에서 치료로 일으켜요(체력 5).', 1];
      if (S.sp.length && S.rn <= 2) return ['▼ 칸 = 다음 적 차례에 증원이 나와요. 그 위에 서 있으면 1 피해를 받고 막아요.', 0];
      const m = MIS[S.M.mt].id;
      if (m === 'escort') return ['수송차 2칸 안에 대원이 있어야 움직여요. 수송차 앞길(점선)을 막지 마세요.', 0];
      if (m === 'hold') return ['적은 통신 장치를 먼저 노려요. 방패병 도발·공병 포탑으로 공격을 끌어오세요.', 0];
      if (m === 'data') return ['자료 상자(💾) 칸이나 옆 칸에서 「회수」. 3개를 모으면 바로 성공!', 0];
      if (m === 'nest') return ['소굴(🕳)은 2라운드마다 적을 낳아요. 유탄·저격·관통탄으로 빨리 부수세요.', 0];
      return ['적을 밀어 다른 적의 공격선(빨간 칸)에 넣으면 적끼리 맞아요.', 0];
    }
    const infoEl = h('div', { class: 'sf-card sf-sub', style: { whiteSpace: 'pre-line' } });
    function unitLine(u) {
      const R = uDef(u);
      return R.ic + ' ' + R.nm + ' — ' + R.atk.nm + ' ' + atkDm(S, u) + (R.atk.rg === 1 ? '(붙은 칸)' : '(' + R.atk.rg + '칸)') + ' · ★' + R.ab.nm + ': ' + R.ab.d + '\n' + R.d;
    }
    function showInfo() {
      if (!S || S.ph !== 'play' || !hov || !S.M) { infoEl.style.display = 'none'; return; }
      const [x, y] = hov;
      const e = S.e.find((q) => q.x === x && q.y === y), u = S.u.find((q) => q.x === x && q.y === y);
      let t = '';
      if (e) {
        const d = eDef(e), T = intentTiles(S, e);
        const tgt = T.tiles.map((p) => { const q = occ(S, p[0], p[1], e); return q ? (q.k === 'u' ? (q.o.down ? '' : uDef(q.o).nm) : q.k === 'e' ? eDef(q.o).nm + '(적끼리!)' : q.k === 't' ? '포탑' : q.o.k === 'car' ? '수송차' : '통신 장치') : ''; }).filter(Boolean);
        t = d.ic + ' ' + d.nm + ' — 체력 ' + e.hp + '/' + e.mhp + (d.ar ? ' · 🛡장갑 ' + d.ar + '(받는 피해 −' + d.ar + ')' : '') + '\n' + (d.k ? '다음 공격: ' + KNM[e.it ? e.it.k : d.k] + ' ' + d.dm + ' 피해' + (tgt.length ? ' → ' + tgt.join(', ') : e.it ? ' (지금은 빈칸)' : ' (다가오는 중)') : '공격 안 함') + '\n' + d.d;
      } else if (u) t = unitLine(u) + (u.down ? '\n쓰러짐 — 옆 칸에서 일으키기' : '');
      else if (tileAt(S, x, y) === '~') t = FAC[S.M.fac].hz + ': 적 차례가 끝날 때 위에 있으면 2 피해(적도).';
      else if (tileAt(S, x, y) === 'x') t = '상자: 길과 시야를 막아요. 맞으면 부서져요.';
      else if (tileAt(S, x, y) === '#') t = '바위: 지나갈 수 없고 시야·사격을 막아요(곡사·유탄은 넘어가요).';
      else if (hasSpawn(S, x, y)) t = '▼ 적 증원 예정 칸 — 위에 서 있으면 막아요(1 피해).';
      else { const o = S.o.find((q) => q.x === x && q.y === y); if (o) t = o.k === 'data' ? '💾 자료 상자 — 이 칸이나 옆 칸에서 회수' : o.k === 'dev' ? '📡 통신 장치 ' + o.hp + '/' + o.mhp + ' — 지켜야 해요' : '🚚 수송차 ' + o.hp + '/' + o.mhp + ' (장갑 1)'; else if (S.tu && S.tu.x === x && S.tu.y === y) t = '🗼 자동 포탑 체력 ' + S.tu.hp + ' — 적 차례 시작에 4칸 안의 적에게 2 피해'; }
      infoEl.style.display = t ? '' : 'none'; infoEl.textContent = t;
    }
    function render() {
      if (dead) return;
      side.innerHTML = '';
      if (!S) return;
      renderOv();
      if (!S.M) { draw(); return; }
      const M = MIS[S.M.mt], F = FAC[S.M.fac];
      side.append(h('div', { class: 'sf-card' },
        h('div', { class: 'sf-h', text: M.ic + ' ' + M.nm }),
        h('div', { class: 'sf-sub', text: '작전 ' + (S.mi + 1) + '/' + S.ops + ' · ' + DIFF[S.dif].nm + ' · 적: ' + F.nm + ' · 라운드 ' + Math.min(S.rn, S.M.rl) + '/' + S.M.rl }),
        h('div', { text: M.d }), h('div', { class: 'sf-obj', text: '▶ ' + objText(S) })));
      const [ht, warn] = ctxHint();
      if (ht && S.ph === 'play') side.append(h('div', { class: 'sf-hint' + (warn ? ' warn' : ''), text: ht }));
      const sq = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px' } });
      for (const u of S.u) {
        const R = uDef(u), p = P_(u.own);
        const st2 = u.down ? '쓰러짐' : u.acted ? '행동 끝' : '대기 중';
        sq.append(h('div', { class: 'sf-row' + (u.id === sel ? ' on' : '') + (u.down || u.acted ? ' off' : ''), title: unitLine(u), onclick() { if (mine(u)) select(u); } },
          h('span', { class: 'ic', text: R.ic }),
          h('span', { class: 'nm' }, h('b', { text: R.nm, style: { color: R.c } }), h('small', { html: '<span style="color:' + p.color + '">●</span> ' + escH(p.name) + ' · ' + st2 + ' · ★' + (u.cd ? u.cd + '라운드 뒤' : '준비') })),
          h('span', { class: 'sf-hp', text: '❤' + u.hp + '/' + u.mhp + (u.sh ? ' 🔵' + u.sh : '') })));
      }
      side.append(sq);
      const u = selU();
      if (u && S.ph === 'play') {
        const R = uDef(u);
        const box = h('div', { class: 'sf-card' }, h('b', { text: R.ic + ' ' + R.nm + (stg && (stg[0] !== u.x || stg[1] !== u.y) ? ' — 이동할 칸 정함' : ' — 파란 칸을 눌러 이동') }));
        const acts = h('div', { class: 'sf-acts' });
        const canAtk = withStage((v) => atkTargets(S, v, v.x, v.y).length) || 0;
        acts.append(h('button', { class: 'sf-b' + (mode === '' ? ' on' : ''), text: '1 🔫 ' + R.atk.nm + (canAtk ? ' (노란 적 클릭)' : ' (닿는 적 없음)'), onclick() { mode = ''; render(); } }));
        acts.append(h('button', { class: 'sf-b' + (mode === 'abl' ? ' on' : ''), disabled: u.cd > 0, text: '2 ★ ' + R.ab.nm + (u.cd ? ' (' + u.cd + '라운드 뒤)' : ''), onclick: useAbility }));
        acts.append(h('button', { class: 'sf-b', text: '3 대기', onclick() { commit('wait'); } }));
        acts.append(h('button', { class: 'sf-b dng', text: '취소', onclick() { select(null); } }));
        box.append(acts, h('div', { class: 'sf-sub', style: { marginTop: '6px' }, text: '★ ' + R.ab.d + (R.id === 'snp' ? ' · 이동 안 하고 저격하면 +2' : '') }));
        side.append(box);
      }
      side.append(infoEl); showInfo();
      if (S.ph === 'play') {
        const my = []; for (let s = 0; s < S.np; s++) if (mineSeat(s)) my.push(s);
        const left = S.u.filter((v) => my.includes(v.own) && ready(v)).length;
        const wait = []; for (let s = 0; s < S.np; s++) if (!S.done[s] && !api.canAct(s)) wait.push(P_(s).name);
        if (my.length) side.append(h('button', { class: 'sf-b pri', text: 'E 턴 끝' + (left ? ' (남은 대원 ' + left + ')' : ''), onclick: endTurn }));
        else side.append(h('div', { class: 'sf-sub', text: wait.length ? wait.join(', ') + ' 행동 중…' : '적 차례…' }));
      }
      side.append(h('div', { class: 'sf-log' }, S.log.slice(-5).map((l) => h('div', { text: l }))));
      draw();
    }

    // ---------- 겹창 (편성 · 강화 · 작전 소개) ----------
    let ovEl = null;
    function renderOv() {
      if (ovEl) { ovEl.remove(); ovEl = null; }
      if (!S) return;
      let pop = null;
      if (S.ph === 'pick') {
        pop = h('div', { class: 'sf-pop' }, h('div', { class: 'sf-h', text: '부대 편성 — 대원 4명의 역할' }),
          h('div', { class: 'sf-sub', text: '작전 ' + S.ops + '개 · ' + DIFF[S.dif].nm + ' · 역할은 겹쳐도 돼요. 방패병·의무병은 버티기, 폭파병·저격수는 큰 피해, 돌격병·공병은 길목 장악.' }));
        for (let i = 0; i < NU; i++) {
          const s = ownerOf(S, i), me = api.canAct(s) && !S.rd[s], R = ROLES[S.roles[i]];
          const box = h('div', { class: 'sf-u' }, h('div', { html: '<b>대원 ' + (i + 1) + '</b> · <span style="color:' + P_(s).color + '">●</span> ' + escH(P_(s).name) + (S.rd[s] ? ' · ✔ 준비' : '') }));
          if (me) box.append(h('div', { class: 'sf-chips' }, ROLES.map((r, ri) => h('button', { class: 'sf-b' + (ri === S.roles[i] ? ' on' : ''), text: r.ic + ' ' + r.nm, onclick() { actAs(s, { t: 'role', u: i, r: ri }); } }))));
          box.append(h('div', { class: 'sf-sub', text: R.ic + ' ' + R.nm + ' (체력 ' + R.hp + ' · 이동 ' + R.mv + ') — ' + R.atk.nm + ' ' + R.atk.dm + ' · ★' + R.ab.nm + ': ' + R.ab.d }));
          pop.append(box);
        }
        const mySeats = []; for (let s = 0; s < S.np; s++) if (api.canAct(s) && !S.rd[s]) mySeats.push(s);
        if (mySeats.length) pop.append(h('button', { class: 'sf-b pri', text: '출격!', onclick() { mySeats.forEach((s) => actAs(s, { t: 'go' })); } }));
        else pop.append(h('div', { class: 'sf-sub', text: '다른 대원이 편성하는 중…' }));
      } else if (S.ph === 'up') {
        const ch = actor(S), me = api.canAct(ch), nx = S.plan[S.mi + 1];
        pop = h('div', { class: 'sf-pop' }, h('div', { class: 'sf-h', text: '작전 성공! 부대 강화 하나 고르기' }), h('div', { class: 'sf-sub', text: '다음 작전: ' + MIS[nx[0]].nm + ' · ' + FAC[nx[1]].nm + ' (조금 더 세져요). 모든 대원이 회복하고, 강화는 이 판 안에서만 유지돼요.' }));
        const row = h('div', { class: 'sf-up' });
        S.upc.forEach((k, i) => { const q = UPG[k]; row.append(h('button', { class: 'sf-b', disabled: !me, html: '<b>' + q.ic + ' ' + q.nm + '</b><br><span class="sf-sub">' + q.d + ((S.upg[k] | 0) ? ' (지금 ' + S.upg[k] + '단계)' : '') + '</span>', onclick() { actAs(ch, { t: 'up', k: i }); } })); });
        pop.append(row);
        if (!me) pop.append(h('div', { class: 'sf-sub', text: P_(ch).name + ' 님이 고르는 중…' }));
      } else if (S.ph === 'play' && intro && S.M) {
        const M = MIS[S.M.mt], F = FAC[S.M.fac];
        pop = h('div', { class: 'sf-pop', style: { maxWidth: '560px' } }, h('div', { class: 'sf-h', text: '작전 ' + (S.mi + 1) + '/' + S.ops + ' — ' + M.ic + ' ' + M.nm }),
          h('div', { class: 'sf-obj', text: '목표: ' + M.d + ' (라운드 ' + S.M.rl + ')' }), h('div', { text: '적: ' + F.nm + ' — ' + F.d }),
          h('div', { class: 'sf-sub', text: '빨간 칸 = 적의 다음 공격(숫자 = 피해) · ▼ = 다음 증원 · ' + F.hz + ' 위에서 적 차례가 끝나면 2 피해' }),
          h('button', { class: 'sf-b pri', text: '작전 시작', onclick() { intro = null; renderOv(); } }));
      }
      if (pop) { ovEl = h('div', { class: 'sf-ov', onclick(ev) { if (ev.target === ovEl && S.ph === 'play') { intro = null; renderOv(); } } }, pop); R0.appendChild(ovEl); }
    }

    // ---------- 그림 ----------
    function rr(x, y, w, hh, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + hh, r); g.arcTo(x + w, y + hh, x, y + hh, r); g.arcTo(x, y + hh, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
    function txt(s, x, y, size, col, stroke, fam) {
      g.font = (stroke ? 'bold ' : '') + Math.round(size) + 'px ' + (fam || '"IBM Plex Sans KR","Segoe UI Emoji",sans-serif');
      g.textAlign = 'center'; g.textBaseline = 'middle';
      if (stroke) { g.lineWidth = 3; g.strokeStyle = 'rgba(0,0,0,.8)'; g.strokeText(s, x, y); }
      g.fillStyle = col || '#fff'; g.fillText(s, x, y);
    }
    function animState(now) {
      if (!anim) return null;
      const tt = (now - anim.t0) / 1000 * spd();
      const pos = {}, gone = {}, born = {}, act = [];
      let ph = null;
      anim.tl.forEach((it, i) => {
        const e = it.e; if (it.s > tt) return;
        const k = Math.min(1, (tt - it.s) / Math.max(0.001, it.d));
        if (e[0] === 'mv') pos[e[1]] = [e[2] + (e[4] - e[2]) * k, e[3] + (e[5] - e[3]) * k];
        else if (e[0] === 'die') gone[e[1]] = 1;
        else if (e[0] === 'sp') born[e[1]] = 1;
        else if (e[0] === 'ph' && tt < it.s + it.d + 0.4) ph = e[1];
        if ((e[0] === 'sh' || e[0] === 'bm') && tt < it.s + it.d + 0.12) act.push([e, (tt - it.s) / (it.d + 0.12)]);
        if (!anim.fired[i] && (e[0] === 'hit' || e[0] === 'heal' || e[0] === 'tx')) {
          anim.fired[i] = 1;
          const label = e[0] === 'tx' ? e[3] : e[0] === 'heal' ? '+' + e[3] : e[3] ? '−' + e[3] : '막음';
          floats.push({ x: e[1], y: e[2], t: label, c: e[0] === 'heal' ? '#7fd08a' : e[0] === 'tx' ? '#ffe7a0' : e[4] ? '#ff6a5a' : '#ffd24a', t0: now });
          if (e[0] === 'hit') api.sfx(e[4] ? 'thud' : 'hit');
        }
      });
      if (tt >= anim.T + 0.15) { anim = null; api.setBusy(false); render(); return null; }
      return { pos, gone, born, act, ph };
    }
    function draw(now) {
      if (dead) return;
      now = now || performance.now();
      C.clear();
      g.fillStyle = '#120e16'; g.fillRect(0, 0, C.w, C.h);
      if (!S || !S.M) return;
      const A = animState(now);
      if (dead) return;
      const { ts, ox, oy } = geo(), F = FAC[S.M.fac];
      const cx = (x) => ox + x * ts + ts / 2, cy = (y) => oy + y * ts + ts / 2;
      function bar(x, y, hp, mhp, col, sh) {
        const X = ox + x * ts + ts * 0.14, Y = oy + y * ts + ts * 0.86, w = ts * 0.72;
        g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(X - 1, Y - 1, w + 2, 6);
        g.fillStyle = col; g.fillRect(X, Y, w * Math.max(0, hp) / mhp, 4);
        if (sh) { g.fillStyle = '#5ab0ff'; g.fillRect(X, Y - 4, Math.min(w, w * sh / mhp), 3); }
      }
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const c = tileAt(S, x, y), X = ox + x * ts, Y = oy + y * ts;
        g.fillStyle = F.fl[(x + y) & 1]; g.fillRect(X, Y, ts, ts);
        if (c === '#') { g.fillStyle = F.rk; rr(X + 2, Y + 2, ts - 4, ts - 4, ts * 0.22); g.fill(); g.fillStyle = 'rgba(255,255,255,.07)'; rr(X + 5, Y + 4, ts - 12, ts * 0.3, ts * 0.12); g.fill(); }
        else if (c === '~') { g.fillStyle = F.hc; g.globalAlpha = 0.35 + 0.1 * Math.sin(now / 400 + x + y); g.beginPath(); g.ellipse(X + ts / 2, Y + ts / 2, ts * 0.42, ts * 0.34, 0, 0, 7); g.fill(); g.globalAlpha = 1; }
        else if (c === 'x') { g.fillStyle = '#8a6438'; rr(X + ts * 0.14, Y + ts * 0.14, ts * 0.72, ts * 0.72, 4); g.fill(); g.strokeStyle = '#5a3e20'; g.lineWidth = 2; g.beginPath(); g.moveTo(X + ts * 0.2, Y + ts * 0.2); g.lineTo(X + ts * 0.8, Y + ts * 0.8); g.moveTo(X + ts * 0.8, Y + ts * 0.2); g.lineTo(X + ts * 0.2, Y + ts * 0.8); g.stroke(); }
      }
      g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 1;
      for (let x = 0; x <= W; x++) { g.beginPath(); g.moveTo(ox + x * ts + 0.5, oy); g.lineTo(ox + x * ts + 0.5, oy + H * ts); g.stroke(); }
      for (let y = 0; y <= H; y++) { g.beginPath(); g.moveTo(ox, oy + y * ts + 0.5); g.lineTo(ox + W * ts, oy + y * ts + 0.5); g.stroke(); }
      if (S.M.path) {
        g.setLineDash([4, 5]); g.strokeStyle = 'rgba(140,220,255,.55)'; g.lineWidth = 2; g.beginPath();
        S.M.path.slice(S.M.pi).forEach((p, i) => { if (i) g.lineTo(cx(p[0]), cy(p[1])); else g.moveTo(cx(p[0]), cy(p[1])); }); g.stroke(); g.setLineDash([]);
        const e = S.M.exit; g.fillStyle = 'rgba(120,220,140,.3)'; g.fillRect(ox + e[0] * ts, oy + e[1] * ts, ts, ts); txt('🏁', cx(e[0]), cy(e[1]), ts * 0.5);
      }
      for (const s of S.sp) { const X = ox + s[0] * ts, Y = oy + s[1] * ts; g.strokeStyle = '#ff5a4a'; g.setLineDash([4, 3]); g.lineWidth = 2; g.strokeRect(X + 4, Y + 4, ts - 8, ts - 8); g.setLineDash([]); txt('▼', X + ts / 2, Y + ts / 2, ts * 0.42, '#ff6a5a'); }
      const u = selU();
      if (!A && u && S.ph === 'play') {
        for (const [x, y] of reachU(S, u)) { g.fillStyle = 'rgba(90,160,255,.28)'; g.fillRect(ox + x * ts + 2, oy + y * ts + 2, ts - 4, ts - 4); }
        if (stg) { g.strokeStyle = '#9cc8ff'; g.lineWidth = 2; g.strokeRect(ox + stg[0] * ts + 3, oy + stg[1] * ts + 3, ts - 6, ts - 6); }
      }
      if (!A && S.ph === 'play') {
        const dm = {};
        for (const e of S.e) {
          if (!e.it) continue;
          const T = intentTiles(S, e), k = e.it.k, col = k === 'lob' ? '255,150,40' : k === 'bm' ? '190,110,255' : '255,70,60';
          g.strokeStyle = 'rgba(' + col + ',.75)'; g.lineWidth = 2;
          const end = T.tiles.length ? T.tiles[0] : T.line[T.line.length - 1];
          if (end) { g.beginPath(); g.moveTo(cx(e.x), cy(e.y)); if (k === 'lob') g.quadraticCurveTo((cx(e.x) + cx(end[0])) / 2, Math.min(cy(e.y), cy(end[1])) - ts, cx(end[0]), cy(end[1])); else g.lineTo(cx(end[0]), cy(end[1])); g.stroke(); }
          for (const t of T.tiles) { g.fillStyle = 'rgba(' + col + ',' + (t[2] >= 2 ? 0.38 : 0.22) + ')'; g.fillRect(ox + t[0] * ts + 1, oy + t[1] * ts + 1, ts - 2, ts - 2); const kk = t[1] * W + t[0]; dm[kk] = (dm[kk] || 0) + t[2]; }
        }
        for (const kk in dm) { const x = kk % W, y = (kk / W) | 0, bw = Math.max(16, ts * 0.36); g.fillStyle = '#d8342a'; rr(ox + x * ts + ts - bw - 2, oy + y * ts + 2, bw, bw * 0.85, 4); g.fill(); txt(String(dm[kk]), ox + x * ts + ts - bw / 2 - 2, oy + y * ts + 2 + bw * 0.43, Math.max(10, bw * 0.62), '#fff'); }
      }
      for (const o of S.o) {
        if (o.k === 'data') { txt('💾', cx(o.x), cy(o.y), ts * 0.5); continue; }
        if (o.hp <= 0) { txt('💥', cx(o.x), cy(o.y), ts * 0.45); continue; }
        const p = A && A.pos.car && o.k === 'car' ? A.pos.car : [o.x, o.y];
        g.fillStyle = 'rgba(120,200,255,.25)'; rr(ox + p[0] * ts + 3, oy + p[1] * ts + 3, ts - 6, ts - 6, 8); g.fill(); txt(o.k === 'car' ? '🚚' : '📡', cx(p[0]), cy(p[1]), ts * 0.5); bar(p[0], p[1], o.hp, o.mhp, '#7cc8ff');
      }
      if (S.tu) { txt('🗼', cx(S.tu.x), cy(S.tu.y), ts * 0.5); bar(S.tu.x, S.tu.y, S.tu.hp, 5, '#b48ae0'); }
      const pe = A && P && P.e ? P.e : [];
      const elist = S.e.slice(); for (const e of pe) if (!S.e.some((q) => q.id === e.id)) elist.push(e);
      for (const e of elist) {
        const key = ekey(e), wasP = pe.find((q) => q.id === e.id), nowS = S.e.find((q) => q.id === e.id);
        if (A) { if (!nowS && A.gone[key]) continue; if (!wasP && anim && anim.hasSp[key] && !A.born[key]) continue; }
        const p = A && A.pos[key] ? A.pos[key] : A && wasP ? [wasP.x, wasP.y] : [e.x, e.y];
        const d = eDef(e), X = ox + p[0] * ts, Y = oy + p[1] * ts;
        g.fillStyle = d.f < 0 ? '#3a2030' : '#2a1414'; g.strokeStyle = d.f < 0 ? '#c05a8a' : F.c; g.lineWidth = d.el ? 3 : 2;
        rr(X + ts * 0.1, Y + ts * 0.1, ts * 0.8, ts * 0.8, ts * 0.2); g.fill(); g.stroke();
        txt(d.ic, X + ts / 2, Y + ts * 0.47, ts * (d.big ? 0.52 : 0.44));
        if (d.ar) txt('🛡' + d.ar, X + ts * 0.24, Y + ts * 0.2, Math.max(9, ts * 0.2), '#fff', true);
        if (d.el) txt('★', X + ts * 0.82, Y + ts * 0.18, Math.max(9, ts * 0.22), '#ffd24a');
        bar(p[0], p[1], A && wasP ? wasP.hp : e.hp, e.mhp, '#ff5a4a');
      }
      for (const v of S.u) {
        const key = ukey(v), pv = A && P && P.u ? P.u[v.id] : null;
        const p = A && A.pos[key] ? A.pos[key] : A && pv ? [pv.x, pv.y] : [v.x, v.y];
        const R = uDef(v), X = cx(p[0]), Y = cy(p[1]), r = ts * 0.38;
        g.globalAlpha = v.down ? 0.55 : v.acted && !A ? 0.62 : 1;
        if (mine(v) && !A) { g.fillStyle = 'rgba(255,255,255,' + (0.18 + 0.12 * Math.sin(now / 250)) + ')'; g.beginPath(); g.arc(X, Y, r + 5, 0, 7); g.fill(); }
        g.fillStyle = v.down ? '#444' : '#1d2230'; g.strokeStyle = R.c; g.lineWidth = 3; g.beginPath(); g.arc(X, Y, r, 0, 7); g.fill(); g.stroke();
        g.strokeStyle = P_(v.own).color; g.lineWidth = 2; g.beginPath(); g.arc(X, Y, r + 2.5, 0, 7); g.stroke();
        txt(v.down ? '✖' : R.ic, X, Y, ts * 0.42, v.down ? '#ff8a7a' : undefined);
        if (v.tb) txt('🛡', X + r * 0.8, Y - r * 0.8, Math.max(10, ts * 0.22));
        g.globalAlpha = 1;
        bar(p[0], p[1], A && pv ? pv.hp : v.hp, v.mhp, '#7fd08a', v.sh);
        if (v.id === sel && !A) { g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath(); g.arc(X, Y, r + 6, 0, 7); g.stroke(); }
      }
      if (!A && u && stg && S.ph === 'play') {
        if (stg[0] !== u.x || stg[1] !== u.y) { g.globalAlpha = 0.6; txt(uDef(u).ic, cx(stg[0]), cy(stg[1]), ts * 0.4); g.globalAlpha = 1; }
        if (mode === '') withStage((v) => {
          for (const e of atkTargets(S, v, v.x, v.y)) { g.strokeStyle = '#ffd24a'; g.lineWidth = 3; g.strokeRect(ox + e.x * ts + 3, oy + e.y * ts + 3, ts - 6, ts - 6); const dmg = Math.max(1, atkDm(S, v) + (uDef(v).id === 'snp' && v.x === u.x && v.y === u.y ? 2 : 0) - eDef(e).ar); txt('−' + dmg, ox + e.x * ts + ts / 2, oy + e.y * ts + ts - 10, Math.max(11, ts * 0.22), '#ffd24a', true); }
          for (const w of S.u) if (w.down && man(w.x, w.y, v.x, v.y) === 1) { g.strokeStyle = '#7fd08a'; g.lineWidth = 3; g.strokeRect(ox + w.x * ts + 3, oy + w.y * ts + 3, ts - 6, ts - 6); }
          for (const o of S.o) if (o.k === 'data' && cheb(o.x, o.y, v.x, v.y) <= 1) { g.strokeStyle = '#7cc8ff'; g.lineWidth = 3; g.strokeRect(ox + o.x * ts + 3, oy + o.y * ts + 3, ts - 6, ts - 6); }
        });
        if (mode === 'abl') {
          const T = withStage((v) => ablTargets(S, v, v.x, v.y)) || [];
          for (const [x, y] of T) { g.fillStyle = 'rgba(255,170,60,.18)'; g.fillRect(ox + x * ts + 2, oy + y * ts + 2, ts - 4, ts - 4); }
          const pk = hov ? ablPick(hov[0], hov[1]) : null;
          if (pk) {
            const id = uDef(u).id;
            const area = id === 'gre' ? gTiles(pk[0], pk[1]) : id === 'snp' ? lineTiles(S, stg[0], stg[1], pk[0] - stg[0], pk[1] - stg[1], 8) : [pk];
            for (const [x, y] of area) {
              const q = occ(S, x, y, u), self = x === stg[0] && y === stg[1];
              const ally = id === 'gre' && ((q && q.k === 'u' && !q.o.down) || self || (q && (q.k === 't' || q.k === 'o')));
              g.fillStyle = ally ? 'rgba(255,60,60,.55)' : 'rgba(255,170,60,.45)'; g.fillRect(ox + x * ts + 2, oy + y * ts + 2, ts - 4, ts - 4);
              if (ally) txt('아군!', ox + x * ts + ts / 2, oy + y * ts + ts - 10, Math.max(10, ts * 0.2), '#fff', true);
            }
          }
        }
      }
      if (A) for (const [e, k] of A.act) {
        if (e[0] === 'sh') { const col = ['#ffe08a', '#ff6a5a', '#c58aff', '#ffa040', '#9ff'][e[5]] || '#fff'; g.strokeStyle = col; g.lineWidth = e[5] === 4 ? 4 : 2.5; g.globalAlpha = Math.max(0, 1 - k * 0.6); g.beginPath(); g.moveTo(cx(e[1]), cy(e[2])); const t = Math.min(1, k * 1.6); g.lineTo(cx(e[1]) + (cx(e[3]) - cx(e[1])) * t, cy(e[2]) + (cy(e[4]) - cy(e[2])) * t); g.stroke(); g.globalAlpha = 1; }
        else { g.fillStyle = 'rgba(255,170,60,' + Math.max(0, 0.6 * (1 - k)) + ')'; g.beginPath(); g.arc(cx(e[1]), cy(e[2]), ts * (0.5 + e[3] * 0.6) * (0.4 + k), 0, 7); g.fill(); }
      }
      floats = floats.filter((f) => (now - f.t0) / 1000 * spd() < 1.1);
      for (const f of floats) { const k = (now - f.t0) / 1000 * spd() / 1.1; g.globalAlpha = Math.max(0, 1 - k); txt(f.t, cx(f.x), cy(f.y) - ts * 0.3 - k * ts * 0.5, Math.max(12, ts * 0.3), f.c, true); g.globalAlpha = 1; }
      const bt = A && A.ph ? A.ph : banner && now - banner.t < 1600 / spd() ? banner.s : null;
      if (bt) { g.font = '20px "Black Han Sans",sans-serif'; const w = g.measureText(bt).width + 40; g.fillStyle = 'rgba(10,8,14,.85)'; rr(C.w / 2 - w / 2, oy + 8, w, 38, 10); g.fill(); txt(bt, C.w / 2, oy + 27, 20, '#ffd98a', false, '"Black Han Sans",sans-serif'); }
    }
    const stopLoop = U.loop((dt, now) => { if (S && S.M) draw(now); });
    return {
      update(st, prev) {
        S = st;
        if (sel >= 0 && S.u[sel] && !mine(S.u[sel])) { sel = -1; stg = null; mode = ''; }
        if (S.ph === 'play' && S.M) { const k = S.mi + '|' + S.ops + '|' + (S.hist.length); if (introKey !== k && S.rn === 1) { introKey = k; intro = 1; } }
        if (prev && prev !== st && st.last && prev.last && st.last.id !== prev.last.id && st.last.ev.length) {
          const same = prev.ph === 'play' && st.ph !== 'pick' && prev.mi === st.mi && prev.M && st.M;
          if (same) {
            let t = 0; const tl = [], hasSp = {};
            for (const e of st.last.ev) { const d = (DUR[e[0]] || 0.05) * (e[0] === 'mv' ? Math.min(2, Math.max(1, man(e[2], e[3], e[4], e[5]) / 2)) : 1); tl.push({ e, s: t, d }); t += d; if (e[0] === 'sp') hasSp[e[1]] = 1; }
            if (anim) api.setBusy(false);
            P = prev; anim = { tl, T: t, t0: performance.now(), fired: {}, hasSp }; api.setBusy(true);
          } else { const ph = st.last.ev.find((e) => e[0] === 'ph'); if (ph) banner = { s: ph[1], t: performance.now() }; }
          if (st.last.ev.some((e) => e[0] === 'ph' && /성공/.test(e[1]))) api.sfx('win'); else if (st.last.ev.some((e) => e[0] === 'ph' && /실패/.test(e[1]))) api.sfx('lose');
        }
        if (nextAfter) { nextAfter = false; const L2 = S.u.filter(mine); if (L2.length) { sel = L2[0].id; stg = [L2[0].x, L2[0].y]; mode = ''; } }
        render();
      },
      destroy() { dead = true; stopLoop(); ro.disconnect(); if (offIn) offIn(); if (ovEl) ovEl.remove(); C.destroy(); R0.remove(); api.setBusy(false); },
    };
  }
  const def = {
    id: 'strikeforce', name: '협동 작전 부대', tag: '협동 분대 전술', cat: '협동', coop: true,
    blurb: '대원 4명이 격자 전장에서 작전을 수행하는 턴제 협동 전술. 적의 다음 공격이 빨간 칸으로 미리 보여요 — 피하고, 밀어내고, 먼저 쓰러뜨리세요.',
    tint: '#3a2a14',
    icon: '<rect x="8" y="8" width="40" height="40" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><path d="M8 21h40M8 35h40M21 8v40M35 8v40" stroke="currentColor" stroke-width="2" opacity=".5"/><circle cx="14.5" cy="41.5" r="4.5" fill="currentColor"/><rect x="36" y="15" width="11" height="11" fill="currentColor" opacity=".55"/><path d="M41.5 13l4 4M45.5 13l-4 4" stroke="currentColor" stroke-width="2"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 420, landscape: true, pcOnly: true, undo: false,
    save: true, mood: 'drums', time: '15–40분',
    saveLabel: (st) => (st ? '작전 ' + Math.min(st.mi + 1, st.ops) + '/' + st.ops + ' · ' + DIFF[st.dif].nm : ''),
    options: [
      { id: 'dif', label: '난이도', tip: '적의 수·증원·정예 비율. 쉬움은 처음 하는 분께, 어려움은 손발이 맞는 부대에게.', choices: DIFF.map((d, i) => ({ v: i, label: d.nm })), def: 1 },
      { id: 'ops', label: '작전 수', tip: '한 판에 이어서 치르는 작전 수. 작전마다 적이 조금씩 세지고, 사이에 부대 강화를 하나 골라요. 한 번 실패하면 판이 끝나요.', choices: [{ v: 3, label: '3개' }, { v: 5, label: '5개' }], def: 3 },
      { id: 'fac', label: '적 진영', tip: '무작위면 작전마다 바뀌어요.', choices: [{ v: -1, label: '무작위' }, { v: 0, label: FAC[0].nm }, { v: 1, label: FAC[1].nm }, { v: 2, label: FAC[2].nm }], def: -1 },
    ],
    controls: [
      { id: 'atk', label: '기본 공격 고르기', keys: ['Digit1'], pad: ['x'] },
      { id: 'abl', label: '능력 고르기', keys: ['Digit2'], pad: ['y'] },
      { id: 'wait', label: '이 자리에서 대기', keys: ['Digit3'], pad: ['b'] },
      { id: 'next', label: '다음 대원', keys: ['Tab'], pad: ['rb'] },
      { id: 'end', label: '턴 끝', keys: ['KeyE'], pad: ['start'] },
    ],
    quick: [
      '대원 4명으로 작전 목표(화면 왼쪽 위)를 끝내요. 작전 3개를 연속으로 성공하면 승리.',
      '빨간 칸 = 적의 다음 공격. 대원을 고르고 → 파란 칸으로 이동 → 공격·능력 하나.',
      '적은 보여 준 칸을 그대로 쳐요. 피하거나, 밀어내거나(적끼리 맞기도!), 먼저 쓰러뜨리세요.',
    ],
    rules: [
      { h: '목표', p: ['작전 목표를 끝내면 성공(섬멸·거점 사수·자료 회수·소굴 파괴·수송차 호송). 라운드 제한이 있어요.', '정한 수의 작전을 연속으로 성공하면 판 승리. 대원이 모두 쓰러지거나 목표를 잃으면 실패하고 판이 끝나요.', '작전 사이에 부대 강화를 하나 골라요(이 판 안에서만).'] },
      { h: '한 라운드', p: ['① 적의 다음 공격이 보여요: 빨간 칸과 숫자(피해). 주황 = 곡사(벽 너머), 보라 줄 = 광선(줄 전체).', '② 모든 대원이 순서 상관없이 「이동(파란 칸) + 행동 하나」. 친구와 동시에 움직여요. 다 쓰면 자동으로 턴 끝(E로 일찍 끝내도 돼요).', '③ 적 차례: 적은 보여 준 칸을 그대로 공격한 뒤 다가와 다음 공격을 보여 줘요. ▼ 표시 칸에선 다음 차례에 적 증원이 나와요(그 위에 서 있으면 1 피해 받고 막아요).'] },
      { h: '행동', p: ['기본 공격: 노란 테두리 적을 누르기(1). 능력: 2 — 쓰면 몇 라운드 쉬어요.', '일으키기: 쓰러진 동료 옆 칸에서(체력 3). 회수: 자료 상자 칸·옆 칸에서. 대기: 3.', '밀기: 밀린 대상이 바위·상자·다른 유닛에 부딪히면 둘 다 1 피해. 밀린 적의 공격 칸도 같이 옮겨 가요 — 적의 공격선 위로 다른 적을 밀어 넣으세요!', '웅덩이(산성·기름·균열) 위에서 적 차례가 끝나면 2 피해(적도 똑같이).'] },
      { h: '역할', p: ROLES.map((r) => r.ic + ' ' + r.nm + ' (체력 ' + r.hp + ' · 이동 ' + r.mv + ') — ' + r.atk.nm + ' ' + r.atk.dm + ' / ' + r.ab.nm + ': ' + r.ab.d) },
      { h: '함께 하기', p: ['1~4명이 대원 4명을 나눠 맡아요(1명이면 4명 모두, 2명이면 2명씩). 빈자리는 AI 동료 — AI 난이도는 자리마다 쉬움·보통·어려움.', '조작: 마우스 클릭(대원 → 칸 → 대상), 오른쪽 클릭 = 취소, 1 공격 · 2 능력 · 3 대기 · Tab 다음 대원 · E 턴 끝. 키는 「⌨ 조작 설정」에서 바꿔요.'] },
    ],
    codex: codexData(), hint,
    init, actor, apply, ai, result,
    aiDelayFor(st) { return st && st.ph === 'play' ? 380 : 300; },
    mount,
    _t: { ROLES, EN, MIS, DIFF, UPG, intentTiles, doAct, value, genCands, startMission, enemyPhase },
  };
  function codexData() {
    return [
      { h: '역할', p: ['대원 4명을 6역할 중에서 골라요(겹쳐도 돼요).'], rows: ROLES.map((r) => ({ icon: r.ic, name: r.nm, tag: '체력 ' + r.hp + ' · 이동 ' + r.mv + (r.ar ? ' · 방어 ' + r.ar : ''), desc: r.atk.nm + ' 피해 ' + r.atk.dm + ' · 사거리 ' + (r.atk.rg === 1 ? '붙은 칸' : r.atk.rg) + ' / ★ ' + r.ab.nm + '(' + r.ab.cd + '라운드마다): ' + r.ab.d + ' — ' + r.d })) },
    ].concat(FAC.map((f, fi) => ({ h: f.nm, p: [f.d, '웅덩이: ' + f.hz + ' · 소굴: ' + f.nest], rows: EN.filter((e) => e.f === fi).map((e) => ({ icon: e.ic, name: e.nm, tag: (e.el ? '정예 · ' : '') + '체력 ' + e.hp + (e.ar ? ' · 장갑 ' + e.ar : '') + ' · 이동 ' + e.mv, desc: KNM[e.k] + ' ' + e.dm + (e.rg > 1 ? ' · 사거리 ' + e.rg : '') + ' — ' + e.d })) }))).concat([
      { h: '작전', rows: MIS.map((m) => ({ icon: m.ic, name: m.nm, tag: '라운드 ' + m.rl, desc: m.d })).concat([{ icon: EN[EI.nest].ic, name: EN[EI.nest].nm, tag: '체력 ' + EN[EI.nest].hp, desc: EN[EI.nest].d }]) },
      { h: '강화', p: ['작전 사이에 3개 중 하나. 이 판 안에서만 유지돼요.'], rows: UPG.map((q) => ({ icon: q.ic, name: q.nm, tag: '최대 ' + q.max + '번', desc: q.d })) },
      { h: '난이도', rows: DIFF.map((d) => ({ icon: '⚙', name: d.nm, tag: '처음 적 ' + d.e0 + '+', desc: '라운드마다 증원 ' + d.sp + '+ · 정예 ' + Math.round(d.el * 100) + '%+ · 장치 체력 ' + d.dev + ' · 수송차 체력 ' + d.car + ' (작전이 지날수록 더 세져요)' })) },
    ]);
  }
  function objText(st) {
    if (!st.M) return '';
    const m = MIS[st.M.mt].id;
    if (m === 'kill') return '남은 적 ' + st.e.length + (st.M.bud > 0 || st.sp.length ? ' · 증원 ' + (st.M.bud + st.sp.length) : ' · 증원 없음');
    if (m === 'hold') return '장치 ' + st.o.filter((o) => o.k === 'dev').map((o) => o.hp + '/' + o.mhp).join(' · ') + ' — ' + st.M.rl + '라운드 끝까지';
    if (m === 'data') return '자료 ' + st.M.got + '/3';
    if (m === 'nest') return '남은 소굴 ' + st.e.filter((e) => e.t === EI.nest).length + '/2';
    if (m === 'escort') { const car = st.o.find((o) => o.k === 'car'); return '수송차 체력 ' + (car ? car.hp : 0) + ' · 출구까지 ' + Math.max(0, st.M.path.length - 1 - st.M.pi) + '칸'; }
    return '';
  }
  function hint(st, seat) {
    if (!st) return null;
    if (st.ph === 'pick') return ['대원 4명의 역할을 고르고 「출격」', '방패병·의무병이 있으면 버티기 쉬워요. 폭파병·저격수는 큰 피해.'];
    if (st.ph !== 'play') return null;
    return [MIS[st.M.mt].nm + ': ' + MIS[st.M.mt].d, '지금: ' + objText(st) + ' · 라운드 ' + st.rn + '/' + st.M.rl, '빨간 칸 = 적의 다음 공격. 피하거나 적을 밀어내세요.', '대원 → 파란 칸 → 노란 적(공격) 또는 2(능력)'];
  }
  L.register(def);
})();
