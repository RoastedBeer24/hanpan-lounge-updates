/* 네온 도시 — 사이버펑크 탑다운 RPG (혼자 하기, PC 전용, 가로).
   구조: 순수 시뮬(Sim: 지도 생성·전투·잠입·해킹·임무·대화·상점) + 뷰(캔버스 + DOM 창, 대화창은 사용자 그림 app/assets/neon/ui).
   세계(W)는 뷰가 들고 있고 saveState/loadState로 저장. core state는 {ph, rid, end, sts}만. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const ID = 'neon';
  const T = 32, MW = 120, MH = 72, DWT = 40, DHT = 36;
  const rngOf = (seed) => { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; };
  const hyp = Math.hypot, clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const R = Math.random;
  /* 외부 그림 지도(빌드 도구가 만든 값: 인물 틀·소품·효과·간판 위치) */
  const AS = {"ch":{"hitman1":{"gun":[164,88,49,43],"hold":[386,88,35,43],"machine":[214,44,49,43],"reload":[313,132,39,43],"silencer":[0,132,54,43],"stand":[426,176,33,43]},"manBlue":{"gun":[263,132,49,43],"hold":[390,132,35,43],"machine":[212,176,49,43],"reload":[309,0,39,43],"silencer":[58,0,54,43],"stand":[426,132,33,43]},"manBrown":{"gun":[262,176,49,43],"hold":[388,0,35,43],"machine":[214,88,49,43],"reload":[312,176,39,43],"silencer":[0,176,54,43],"stand":[459,44,33,43]},"manOld":{"gun":[216,0,49,43],"hold":[422,88,35,43],"machine":[213,132,49,43],"reload":[307,44,39,43],"silencer":[55,132,54,43],"stand":[460,132,33,43]},"robot1":{"gun":[164,44,49,43],"hold":[423,44,35,43],"machine":[166,0,49,43],"reload":[306,88,39,43],"silencer":[55,176,54,43],"stand":[458,88,33,43]},"soldier1":{"gun":[113,0,52,43],"hold":[349,0,38,43],"machine":[110,132,52,43],"reload":[264,44,42,43],"silencer":[0,0,57,43],"stand":[353,132,36,43]},"survivor1":{"gun":[112,88,51,43],"hold":[352,176,37,43],"machine":[110,176,51,43],"reload":[264,88,41,43],"silencer":[0,88,56,43],"stand":[390,176,35,43]},"womanGreen":{"gun":[58,44,52,43],"hold":[347,44,38,43],"machine":[111,44,52,43],"reload":[266,0,42,43],"silencer":[0,44,57,43],"stand":[386,44,36,43]},"zombie1":{"gun":[163,132,49,43],"hold":[424,0,35,43],"machine":[162,176,49,43],"reload":[346,88,39,43],"silencer":[57,88,54,43],"stand":[460,0,33,43]}},"pr":{"crate":[0,0,64,64],"crateS":[64,0,64,64],"crateR":[128,0,64,64],"crateR2":[192,0,64,64],"barO":[256,0,64,64],"barG":[320,0,64,64],"barX":[384,0,64,64],"oil":[0,64,128,64],"bush":[128,64,64,64],"rock":[192,64,64,64],"rock2":[256,64,64,64],"plank":[320,64,64,64],"debris":[384,64,64,64],"glass":[448,64,64,64],"stove":[0,128,64,64],"sink":[64,128,64,64],"hob":[128,128,64,64],"chairG":[192,128,64,64],"chairB":[256,128,64,64],"tableS":[320,128,64,64],"tableR":[384,128,64,64],"chairD":[448,128,64,64],"chairD2":[0,192,64,64],"couch":[64,192,192,64],"couchO":[256,192,192,64],"couchD":[0,256,192,64],"aquar":[192,256,128,64],"plant":[320,256,128,128],"wood":[448,256,64,64],"wood2":[0,384,64,64],"conc":[64,384,64,64],"tileW":[128,384,64,64],"cart":[192,384,64,64],"bed":[256,384,64,192]},"fx":{"muzzle1":[0,0],"muzzle3":[64,0],"muzzle5":[128,0],"spark1":[192,0],"spark4":[256,0],"spark6":[0,64],"smoke1":[64,64],"smoke4":[128,64],"light1":[192,64],"light3":[256,64],"circle5":[0,128],"flare1":[64,128],"scorch1":[128,128],"twirl1":[192,128],"trace2":[256,128],"star4":[0,192],"magic2":[64,192],"slash2":[128,192],"fire1":[192,192],"dirt2":[256,192]},"sg":{"big":[[0,0,35,92],[35,0,35,92],[70,0,35,92],[105,0,35,92]],"neon":[[140,0,19,48],[159,0,19,48],[178,0,19,48],[197,0,19,48]],"side":[[216,0,19,76],[235,0,19,76],[254,0,19,76],[273,0,19,76]],"scroll":[[292,0,13,47],[305,0,13,47],[318,0,13,47],[331,0,13,47]],"sushi":[[344,0,36,13],[380,0,36,13],[416,0,36,13]],"face":[[452,0,21,18],[473,0,21,18],[494,0,21,18],[515,0,21,18]],"hotel":[[536,0,68,35]],"antenna":[[604,0,22,96]]},"sfx":["shot_l","shot_l2","shot_h","shot_s","shot_r","shot_e","hit_m","hit_m2","boom","boom2","hack","hack2","door","door_c","field","field2","slime","hum","bike","metro"]};
  const pick = (a, r) => a[Math.floor((r || R)() * a.length)];
  const angD = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };

  // ───────── 세력 ─────────
  const FA = {
    ak: { nm: '아크라 기업', c: '#4fd8ff', d: '도시 위층을 쥔 거대 기업. 깨끗한 거리, 무장 경비, 비싼 계약.', riv: ['gh', 'ash'] },
    nd: { nm: '바늘회', c: '#ff4fa3', d: '항만을 쥔 암거래 조직. 의체·총·정보, 값만 맞으면 뭐든 판다.', riv: ['ash'] },
    ash: { nm: '잿빛 연합', c: '#ffa040', d: '공장 노동자들의 자경 조합. 거칠지만 의리가 있다.', riv: ['ak', 'nd'] },
    gh: { nm: '유령망', c: '#7dff9a', d: '하층에 숨은 해커 집단. 정보는 모두의 것이라고 믿는다.', riv: ['ak'] },
    law: { nm: '질서국', c: '#8fa8ff', d: '도시 경찰. 수배도(열기)가 오르면 쫓아온다.' },
    raid: { nm: '약탈자', c: '#c070ff', d: '폐허 경계의 무리. 누구에게나 적대.' },
  };
  const FKEYS = ['ak', 'nd', 'ash', 'gh'];

  // ───────── 구역 (3×2) ─────────
  const DIST = [
    { k: 'spire', nm: '아크라 첨탑 지구', fa: 'ak', lv: 3, c: '#4fd8ff', c2: '#1d3a66', road: '#0b1428', side: '#141e38', floor: '#18223e', wall: '#2c4a7a', d: '유리탑과 무장 경비. 위험하지만 보상이 크다.' },
    { k: 'market', nm: '네온 시장', fa: null, lv: 1, c: '#ff4fd8', c2: '#4a1d5a', road: '#0e0c22', side: '#1a1532', floor: '#211a38', wall: '#4a2e6e', d: '도시의 한가운데. 중개인·시술사·상점이 모인 안전한 곳.' },
    { k: 'docks', nm: '항만 컨테이너 구역', fa: 'nd', lv: 1, c: '#ff6f9e', c2: '#3a1f3a', road: '#0c1020', side: '#161a2c', floor: '#1c1f33', wall: '#3b3550', d: '바늘회의 영역. 컨테이너 사이로 밀수가 오간다.' },
    { k: 'rust', nm: '녹슨 공장 지대', fa: 'ash', lv: 2, c: '#ffa040', c2: '#4a2a12', road: '#110e14', side: '#1c1820', floor: '#221c22', wall: '#5a3a26', d: '멈춘 공장과 잿빛 연합의 바리케이드.' },
    { k: 'under', nm: '하층 슬럼', fa: 'gh', lv: 2, c: '#7dff9a', c2: '#163a2a', road: '#0a1214', side: '#12201e', floor: '#162624', wall: '#24504a', d: '빛이 닿지 않는 층. 유령망의 은신처가 있다.' },
    { k: 'waste', nm: '폐허 경계', fa: 'raid', lv: 3, c: '#c070ff', c2: '#2e1a46', road: '#100c16', side: '#1a1424', floor: '#1e1828', wall: '#3e2a58', d: '버려진 구역. 약탈자가 들끓지만 값진 물건도 많다.' },
  ];
  const distAt = (px, py) => clamp(Math.floor(px / (DWT * T)), 0, 2) + clamp(Math.floor(py / (DHT * T)), 0, 1) * 3;

  // ───────── 무기 ─────────
  // am: 탄 종류 l(경탄) h(중탄) s(산탄) · rng: 사거리(칸) · spr: 퍼짐(라디안) · rof: 초당 발사 · sup: 소음 · hom: 유도 · pc: 관통
  const WB = {
    p9: { nm: '바늘 9 권총', ty: '권총', am: 'l', dmg: 18, rof: 4, mag: 12, spr: 0.05, rng: 13, rl: 1.1, val: 300, ic: 'P' },
    sil: { nm: '침묵 권총', ty: '소음 권총', am: 'l', dmg: 22, rof: 2.8, mag: 10, spr: 0.04, rng: 12, rl: 1.3, sup: 1, val: 650, ic: 'P' },
    rev: { nm: '철갑 리볼버', ty: '리볼버', am: 'h', dmg: 44, rof: 1.6, mag: 6, spr: 0.03, rng: 15, rl: 1.8, val: 700, ic: 'R' },
    smg: { nm: '벌떼 기관단총', ty: '기관단총', am: 'l', dmg: 11, rof: 11, mag: 30, spr: 0.13, rng: 11, rl: 1.6, val: 800, ic: 'S' },
    ar: { nm: '규격 돌격소총', ty: '돌격소총', am: 'h', dmg: 20, rof: 6.5, mag: 30, spr: 0.07, rng: 16, rl: 2, val: 1100, ic: 'A' },
    sg: { nm: '문짝파괴 산탄총', ty: '산탄총', am: 's', dmg: 10, pel: 7, rof: 1.2, mag: 6, spr: 0.32, rng: 8, rl: 2.4, val: 900, ic: 'G' },
    smt: { nm: '유도 스마트건', ty: '스마트 권총', am: 'l', dmg: 14, rof: 5, mag: 16, spr: 0.1, rng: 14, rl: 1.4, hom: 1, val: 1500, ic: 'M' },
    lmg: { nm: '톱날 경기관총', ty: '경기관총', am: 'h', dmg: 15, rof: 9, mag: 60, spr: 0.12, rng: 14, rl: 3.2, val: 1800, ic: 'H' },
    tech: { nm: '충전 관통총', ty: '관통 소총', am: 'h', dmg: 64, rof: 1.1, mag: 8, spr: 0.02, rng: 20, rl: 2.2, pc: 1, val: 1900, ic: 'T' },
    twin: { nm: '쌍둥이 기관권총', ty: '기관권총', am: 'l', dmg: 13, rof: 9, mag: 24, spr: 0.1, rng: 11, rl: 1.2, val: 950, ic: 'S' },
    dmr: { nm: '정밀 사수총', ty: '지정사수 소총', am: 'h', dmg: 34, rof: 3, mag: 15, spr: 0.025, rng: 19, rl: 2, val: 1600, ic: 'A' },
    rail: { nm: '장거리 레일총', ty: '저격 소총', am: 'h', dmg: 90, rof: 0.7, mag: 4, spr: 0.01, rng: 24, rl: 2.6, pc: 1, val: 2200, ic: 'L' },
  };
  // 근접: rch(사거리 칸), st(기절 초), nl(비살상)
  const MB = {
    knife: { nm: '열칼 단검', ty: '단검', dmg: 30, rof: 2.6, rch: 1.3, val: 200 },
    blade: { nm: '단분자 장검', ty: '장검', dmg: 55, rof: 1.6, rch: 1.8, val: 1400 },
    baton: { nm: '충격 곤봉', ty: '곤봉 · 비살상', dmg: 34, rof: 1.8, rch: 1.4, st: 1.2, nl: 1, val: 600 },
    hammer: { nm: '유압 망치', ty: '둔기 · 비살상', dmg: 48, rof: 1.0, rch: 1.5, st: 1.8, nl: 1, val: 1100 },
    fist: { nm: '맨주먹', ty: '주먹', dmg: 12, rof: 2.4, rch: 1.1, val: 0 },
  };
  const ARM = {
    jk: { nm: '거리 재킷', ar: 6, sp: 0, val: 150 },
    coat: { nm: '방탄 코트', ar: 16, sp: -0.05, val: 700 },
    vest: { nm: '기업 경비 조끼', ar: 26, sp: -0.1, val: 1300 },
    nano: { nm: '나노섬유 정장', ar: 22, sp: 0, val: 2400 },
  };
  const RAR = [{ nm: '일반', c: '#c8d0e0', m: 1 }, { nm: '고급', c: '#6fe08a', m: 1.12 }, { nm: '희귀', c: '#4fb8ff', m: 1.25 }, { nm: '전설', c: '#ffb040', m: 1.42 }];
  const PERK = { cr: '치명타 +8%', mg: '탄창 +30%', rf: '연사 +12%', st: '안정 (퍼짐 −25%)' };

  // ───────── 의체 (부위별 3종) ─────────
  // hum: 인간성 비용 · il: 불법(열기 증가 ×1.25) · ab: 능력 키(dash=Space, arm=T)
  const SLOTS = [['eye', '눈'], ['arm', '팔'], ['leg', '다리'], ['neu', '신경'], ['skin', '피부'], ['sys', '체계']];
  const CW = {
    tgt: { sl: 'eye', nm: '표적 광학', hum: 4, val: 900, d: '치명타 확률 +10%, 적 체력 막대가 보여요.' },
    thm: { sl: 'eye', nm: '열상 광학', hum: 8, val: 1800, d: '벽 너머 10칸 안의 적 윤곽이 보여요.' },
    mil: { sl: 'eye', nm: '군용 조준 광학', hum: 12, il: 1, val: 3200, d: '퍼짐 −40%, 치명타 +15%. 불법(열기 ×1.25).' },
    gor: { sl: 'arm', nm: '고릴라 팔', hum: 8, val: 1500, d: '근접 피해 ×1.6, 맨주먹도 강해요.' },
    claw: { sl: 'arm', nm: '접이식 팔 칼날', hum: 10, val: 2300, d: '근접 공격이 팔 칼날로 바뀌어요(피해 62, 빠름, 2칸).' },
    mono: { sl: 'arm', nm: '단분자 와이어', hum: 12, val: 2600, d: '근접 공격이 3칸 휘두르기로 바뀌어요(피해 45, 여러 명).' },
    pjl: { sl: 'arm', nm: '투사체 발사 팔', hum: 14, il: 1, val: 3500, ab: 'arm', d: '[T] 유탄 발사(폭발 70), 12초마다. 불법.' },
    ten: { sl: 'leg', nm: '강화 힘줄', hum: 4, val: 800, d: '이동 속도 +15%.' },
    dash: { sl: 'leg', nm: '돌진 다리', hum: 9, val: 1900, ab: 'leg', d: '[Space] 4칸 돌진(그동안 무적), 3초마다.' },
    pad: { sl: 'leg', nm: '소음 발바닥', hum: 3, val: 700, d: '발소리 −70%, 앉아 걸을 때 거의 안 들켜요.' },
    ram: { sl: 'neu', nm: '확장 RAM 칩', hum: 5, val: 1200, d: '해킹 RAM +6.' },
    qk: { sl: 'neu', nm: '신경 가속기', hum: 8, val: 2200, d: '퀵해킹 RAM 비용 −30%, 재사용 대기 −40%.' },
    refl: { sl: 'neu', nm: '반사 증폭기', hum: 10, il: 1, val: 3000, d: '총알 25% 회피. 불법.' },
    sub: { sl: 'skin', nm: '피하 장갑', hum: 6, val: 1100, d: '방어 +20.' },
    camo: { sl: 'skin', nm: '광학 위장', hum: 12, il: 1, val: 3300, d: '앉아서 1초 멈추면 투명(적이 못 봐요). 불법.' },
    regen: { sl: 'skin', nm: '재생 피부', hum: 7, val: 1600, d: '체력이 초당 1.5씩 차요(싸움 중엔 절반).' },
    bk: { sl: 'sys', nm: '피질 백업', hum: 10, val: 2800, d: '쓰러지면 체력 50%로 다시 일어나요(120초마다).' },
    ovr: { sl: 'sys', nm: '과부하 심장', hum: 9, val: 2000, d: '최대 체력 +40.' },
    sand: { sl: 'sys', nm: '시간 가속기', hum: 13, il: 1, val: 3600, ab: 'time', d: '[Z] 4초 동안 주변이 느려져요(적·적 총알 ×0.35), 20초마다. 불법.' },
    scan: { sl: 'eye', nm: '약점 분석기', hum: 6, val: 1400, d: '기절·눈먼·착란 상태의 적에게 주는 피해 +35%.' },
    hsk: { sl: 'skin', nm: '방열 피부', hum: 5, val: 1200, d: '폭발·화상 피해 −50%.' },
    roll: { sl: 'neu', nm: '반사 회로', hum: 6, val: 1500, d: '구르기·돌진 재사용 대기 −45%, 구르고 1.5초 동안 치명타 +25%.' },
    cool: { sl: 'sys', nm: '냉각 체계', hum: 4, val: 900, d: '능력·퀵해킹 재사용 대기 −35%.' },
  };
  // ───────── 퀵해킹 ─────────
  const QH = {
    sc: { nm: '단락', ram: 4, cd: 2, val: 0, d: '전기 충격 30 피해(드론·사이보그·포탑은 ×1.8).' },
    bl: { nm: '시야 교란', ram: 3, cd: 2, val: 0, d: '6초 동안 앞을 못 보고 경계가 풀려요.' },
    jam: { nm: '무기 고장', ram: 4, cd: 3, val: 900, d: '7초 동안 총을 못 쏴요.' },
    conf: { nm: '착란', ram: 7, cd: 6, val: 1800, d: '8초 동안 가까운 동료를 공격해요.' },
    burn: { nm: '과열', ram: 5, cd: 4, val: 1400, d: '5초 동안 불타 40 피해(기계는 ×1.3). 경계 중이어도 써요.' },
    wipe: { nm: '기억 지우기', ram: 3, cd: 5, val: 700, d: '대상과 그 무리가 방금 본 것을 잊어요(두목 제외). 잠입용.' },
    reb: { nm: '재부팅 장악', ram: 8, cd: 10, val: 2400, d: '드론·포탑·사이보그를 15초 동안 내 편으로(가까운 적을 쏴요).' },
    crip: { nm: '관절 마비', ram: 4, cd: 4, val: 1100, d: '6초 동안 다리 의체를 굳혀 이동이 70% 느려져요. 칼날 돌격수·두목 발 묶기에 좋아요.' },
    ping: { nm: '신호 추적', ram: 2, cd: 8, val: 600, d: '12칸 안의 적을 10초 동안 벽 너머로 보여 줘요(대상 필요 없음).' },
  };
  // ───────── 적 ─────────
  const EN = {
    thug: { nm: '깡패', hp: 60, ar: 0, sp: 95, w: ['p9', 'smg', 'knife'], r: 11, xp: 12 },
    guard: { nm: '기업 경비', hp: 90, ar: 16, sp: 90, w: ['ar', 'p9'], r: 11, xp: 18 },
    drone: { nm: '경비 드론', hp: 45, ar: 0, sp: 140, w: ['smg'], r: 9, xp: 14, mech: 1, fly: 1 },
    borg: { nm: '사이보그 집행자', hp: 220, ar: 26, sp: 100, w: ['sg', 'ar'], r: 13, xp: 45, mech: 1, elite: 1 },
    cop: { nm: '질서국 경관', hp: 90, ar: 16, sp: 100, w: ['p9', 'ar'], r: 11, xp: 16 },
    raider: { nm: '약탈자', hp: 70, ar: 4, sp: 100, w: ['sg', 'smg', 'knife'], r: 11, xp: 15 },
    hacker: { nm: '유령망 해커', hp: 55, ar: 0, sp: 95, w: ['smt', 'p9'], r: 11, xp: 14 },
    turret: { nm: '자동 포탑', hp: 150, ar: 20, sp: 0, w: ['ar'], r: 13, xp: 25, mech: 1, fix: 1 },
    sniper: { nm: '저격수', hp: 70, ar: 6, sp: 80, w: ['rail'], r: 11, xp: 22, snp: 1 },
    blade: { nm: '칼날 돌격수', hp: 85, ar: 8, sp: 150, w: ['blade'], r: 11, xp: 20, lunge: 1 },
    runner: { nm: '적 해커', hp: 60, ar: 0, sp: 90, w: ['p9'], r: 11, xp: 24, net: 1 },
    heavy: { nm: '중화기병', hp: 260, ar: 30, sp: 70, w: ['lmg'], r: 14, xp: 50, elite: 1 },
    shield: { nm: '방패 경비', hp: 110, ar: 20, sp: 80, w: ['p9', 'smg'], r: 12, xp: 24, shd: 1 },
    hound: { nm: '은빛 사냥개', hp: 360, ar: 18, sp: 125, w: ['rev', 'ar'], r: 13, xp: 200, elite: 1, boss: 1 },
    psycho: { nm: '쇳날 광인', hp: 420, ar: 18, sp: 165, w: ['blade'], r: 14, xp: 140, mech: 1, elite: 1, lunge: 1, boss: 1 },
    boss: { nm: '두목', hp: 650, ar: 30, sp: 105, w: ['ar', 'sg'], r: 15, xp: 150, mech: 1, elite: 1, boss: 1 },
  };
  // 세력별 보통 무리(FA_EN)·정예(FA_EL). 위험한 구역(lv)일수록 뒤쪽 종류가 섞인다
  const FA_EN = { ak: ['guard', 'guard', 'drone', 'shield', 'sniper', 'runner'], nd: ['thug', 'thug', 'thug', 'blade', 'sniper'], ash: ['thug', 'raider', 'thug', 'blade', 'heavy'], gh: ['hacker', 'hacker', 'drone', 'runner', 'blade'], raid: ['raider', 'raider', 'raider', 'blade', 'heavy'], law: ['cop', 'cop', 'drone', 'shield', 'sniper'] };
  const FA_EL = { ak: ['borg', 'heavy'], nd: ['borg', 'blade'], ash: ['borg', 'heavy'], gh: ['borg', 'runner'], raid: ['heavy', 'borg'], law: ['borg', 'heavy'] };
  const poolFor = (fa, lv) => (FA_EN[fa] || FA_EN.raid).slice(0, lv >= 3 ? 6 : lv >= 2 ? 4 : 3);

  // ───────── 소모품·잡동사니 ─────────
  const CON = {
    med: { nm: '치료 주사', val: 120, d: '체력 50 회복 [H].' },
    ramc: { nm: 'RAM 충전제', val: 150, d: 'RAM을 가득 채워요.' },
    frag: { nm: '파편 수류탄', val: 180, d: '[X] 커서 쪽으로 던져 터뜨려요(폭발 80).' },
  };
  const AMMO = { l: { nm: '경탄', n: 40, val: 60 }, h: { nm: '중탄', n: 30, val: 80 }, s: { nm: '산탄', n: 16, val: 70 } };
  const JUNK = ['깨진 칩셋', '중고 배터리', '광섬유 다발', '위조 신분칩', '기업 배지', '금 도금 회로', '암시장 데이터'];

  // ───────── 엔딩 ─────────
  const ENDS_EP = {
    ak: ['위층 아파트의 창문은 비를 맞지 않는다. 밤마다 아래를 내려다보면, 네온 사이로 하층의 불빛이 하나둘 꺼져 간다.', '거울가면은 다시 나타나지 않았다. 유령망 게시판에는 「잊지 않는다」라는 글만 쌓였다.'],
    gh: ['그날 밤 도시의 모든 화면에 같은 문서가 떴다. 수도꼭지 앞에 줄 선 사람들이 처음으로 서로의 얼굴을 봤다.', '아크라 이사회는 「조작된 자료」라고 했지만, 다음 날 정수관 공사가 소리 없이 멈췄다.'],
    nd: ['아크라는 무릎을 꿇지 않았다. 대신 수표에 서명했다. 은침 두목은 항만의 새 주인이 되었고, 당신은 그의 오른손이 되었다.', '하층의 물은 바뀌지 않았다. 다만 이제 그 값을 받는 사람이 달라졌을 뿐.'],
    ash: ['멈췄던 정수 공장의 굴뚝이 3년 만에 하얀 김을 뿜었다. 용접 가면 위원장은 처음으로 가면을 벗고 웃었다.', '코어의 기록은 공장 정문에 붙었다. 사람들은 그 앞을 지날 때마다 걸음을 멈췄다.'],
    run: ['검은 칩은 빗물 고인 하수구 속에서 두 조각이 났다. 누구도 이기지 못했고, 누구도 지지 않았다.', '도시 경계의 마지막 검문소를 지나며 뒤를 돌아봤다. 네온은 여전히 깜박이고 있었다.'],
    psy: ['시술소 문 앞에서 의체 시술사는 오래 서 있었다. 「내가 경고했잖아.」 대답은 없었다.', '그날 이후 폐허 경계에는 새로운 이야기가 돈다. 비 오는 밤이면 쇠 냄새 나는 그림자가 걷는다고.'],
    truth: ['떨리는 연구원은 증언대에서 끝까지 떨지 않았다. 의체를 떼어 낸 쇳날 광인도 증인석에 앉았다.', '판결은 아직이다. 하지만 처음으로, 하층 사람들이 법정 방청석 맨 앞줄에 앉았다.'],
  };
  const ENDS = {
    ak: { nm: '유리탑의 개', d: '코어를 아크라에 넘겼다. 위층의 계약자가 되었지만 하층의 물은 여전히 독이다.' },
    gh: { nm: '모두의 신호', d: '유령망과 함께 진실을 도시 전체에 방송했다. 하층이 깨어났다.' },
    nd: { nm: '하층의 왕', d: '바늘회와 코어로 기업을 협박해 항만과 하층을 손에 넣었다.' },
    ash: { nm: '녹슨 불꽃', d: '잿빛 연합과 정수 공장을 되찾았다. 깨끗한 물이 흐르기 시작했다.' },
    run: { nm: '도시를 떠나다', d: '코어를 부수고 아무 편도 들지 않은 채 도시를 떠났다.' },
    psy: { nm: '강철 속의 공허', d: '의체가 사람을 삼켰다. 마지막 임무가 끝난 뒤, 당신은 더 이상 당신이 아니었다.' },
    truth: { nm: '새벽의 증언', d: '코어와 연구동 원본 기록, 그리고 살아 돌아온 증인. 도시는 처음으로 아크라 이사회를 법정에 세웠다. 어느 세력의 개도 되지 않은 채.' },
  };

  // ═════════ 지도 생성 (씨앗에서 결정적으로 — 저장엔 씨앗만) ═════════
  // 칸: 0 차도 1 인도 2 벽 3 실내 바닥 4 문 5 물 6 상자(엄폐) 7 광장 9 경계
  const SOLID = [0, 0, 1, 0, 0, 1, 1, 0, 0, 1], BLOCKB = [0, 0, 1, 0, 0, 0, 1, 0, 0, 1];
  const MAPS = new Map();
  function genMap(seed) {
    if (MAPS.has(seed)) return MAPS.get(seed);
    const r = rngOf(seed * 7 + 13), g = new Uint8Array(MW * MH), bid = new Int16Array(MW * MH).fill(-1), blds = [], plz = [];
    const I = (x, y) => y * MW + x, set = (x, y, v) => { if (x > 0 && y > 0 && x < MW - 1 && y < MH - 1) g[I(x, y)] = v; };
    for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) g[I(x, y)] = (x === 0 || y === 0 || x === MW - 1 || y === MH - 1) ? 9 : ((x % 14 < 3 || y % 12 < 3) ? 0 : 1);
    const xs = [], ys = [];
    for (let x = 3; x < MW - 1; x += 14) xs.push([x, Math.min(x + 10, MW - 2)]);
    for (let y = 3; y < MH - 1; y += 12) ys.push([y, Math.min(y + 8, MH - 2)]);
    const roleNeed = { 1: 4, 0: 3, 2: 3, 3: 3, 4: 3, 5: 1 };
    for (const [y0, y1] of ys) for (const [x0, x1] of xs) {
      const w = x1 - x0 + 1, h = y1 - y0 + 1, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, d = distAt(cx * T, cy * T), D = DIST[d];
      const ix0 = x0 + 1, iy0 = y0 + 1, ix1 = x1 - 1, iy1 = y1 - 1;
      if (w < 8) { // 좁은 가장자리 블록: 공원·광장
        for (let y = iy0; y <= iy1; y++) for (let x = ix0; x <= ix1; x++) set(x, y, 7);
        plz.push({ x0: ix0, y0: iy0, x1: ix1, y1: iy1, d });
        continue;
      }
      let bp = d === 1 ? 0.92 : d === 2 ? 0.55 : d === 5 ? 0.6 : 0.78;
      if (r() < bp) {
        const id = blds.length, B = { id, x0: ix0, y0: iy0, x1: ix1, y1: iy1, d, role: null, ruin: d === 5 ? 1 : 0, sg: Math.floor(r() * 1e6) };
        for (let y = iy0; y <= iy1; y++) for (let x = ix0; x <= ix1; x++) { const edge = x === ix0 || x === ix1 || y === iy0 || y === iy1; set(x, y, edge ? 2 : 3); bid[I(x, y)] = id; }
        // 문 (2칸 너비), 최소 1개
        const sides = [0, 1, 2, 3].filter(() => r() < 0.6); if (!sides.length) sides.push(Math.floor(r() * 4));
        for (const s of sides) {
          if (s < 2) { const x = ix0 + 2 + Math.floor(r() * (ix1 - ix0 - 4)); const y = s === 0 ? iy0 : iy1; set(x, y, 4); set(x + 1, y, 4); }
          else { const y = iy0 + 2 + Math.floor(r() * (iy1 - iy0 - 4)); const x = s === 2 ? ix0 : ix1; set(x, y, 4); set(x, y + 1, 4); }
        }
        // 칸막이 벽(틈 있음)
        if (r() < 0.55) { const vx = ix0 + 3 + Math.floor(r() * (ix1 - ix0 - 5)); const gy = iy0 + 1 + Math.floor(r() * (iy1 - iy0 - 3)); for (let y = iy0 + 1; y < iy1; y++) if (y !== gy && y !== gy + 1) set(vx, y, 2); }
        // 폐허: 벽 구멍 + 잔해
        if (B.ruin) for (let k = 0; k < 6; k++) { const x = ix0 + Math.floor(r() * (ix1 - ix0 + 1)), y = iy0 + Math.floor(r() * (iy1 - iy0 + 1)); if (g[I(x, y)] === 2 && x > ix0 && x < ix1 && y > iy0 && y < iy1) set(x, y, 3); else if (g[I(x, y)] === 2) set(x, y, 4); }
        // 실내 엄폐물
        for (let k = 0; k < 3; k++) { const x = ix0 + 2 + Math.floor(r() * (ix1 - ix0 - 3)), y = iy0 + 2 + Math.floor(r() * (iy1 - iy0 - 3)); if (g[I(x, y)] === 3) set(x, y, 6); }
        blds.push(B);
      } else {
        for (let y = iy0; y <= iy1; y++) for (let x = ix0; x <= ix1; x++) set(x, y, 7);
        const n = d === 2 ? 9 : 4;
        for (let k = 0; k < n; k++) { const x = ix0 + 1 + Math.floor(r() * (ix1 - ix0 - 1)), y = iy0 + 1 + Math.floor(r() * (iy1 - iy0 - 1)); set(x, y, 6); if (r() < 0.5) set(x + 1, y, 6); }
        plz.push({ x0: ix0, y0: iy0, x1: ix1, y1: iy1, d });
      }
    }
    // 항만 동쪽 바다
    for (let y = 1; y < DHT; y++) for (let x = 116; x < MW - 1; x++) g[I(x, y)] = 5;
    // 갇힌 칸이 없게: 길에서 닿지 않는 바닥이 있으면 그 사이 벽·상자를 뚫는다
    for (let it = 0; it < 400; it++) {
      const D = flow({ g }, 1.5 * T, 1.5 * T); let fixd = false;
      for (let i = MW; i < MW * (MH - 1) && !fixd; i++) {
        const v = g[i]; if (v !== 2 && v !== 6) continue; const x = i % MW; if (x < 1 || x >= MW - 1) continue;
        for (const [a, b] of [[-1, 1], [-MW, MW]]) { const A = i + a, B = i + b;
          if (SOLID[g[A]] || SOLID[g[B]]) continue;
          if ((D[A] >= 0) !== (D[B] >= 0)) { g[i] = v === 2 ? 4 : 3; fixd = true; break; } }
      }
      if (!fixd) break;
    }
    // 역할 건물 정하기
    const roles = [['akhq', 0], ['uplink', 0], ['gun', 0], ['clinic', 1], ['bar', 1], ['gun', 1], ['store', 1], ['ndhq', 2], ['auction', 2], ['gun', 2], ['ashhq', 3], ['plant', 3], ['store', 3], ['ghden', 4], ['node', 4], ['clinic', 4], ['camp', 5]];
    const byD = [0, 1, 2, 3, 4, 5].map((d) => blds.filter((b) => b.d === d).sort(() => r() - 0.5));
    const used = new Set(), pos = {};
    for (const [ro, d] of roles) {
      let b = byD[d].find((q) => !used.has(q.id));
      if (!b) b = blds.filter((q) => !used.has(q.id)).sort((p, q) => hyp(p.x0 - DWT * (d % 3 + 0.5), p.y0 - DHT * ((d / 3 | 0) + 0.5)) - hyp(q.x0 - DWT * (d % 3 + 0.5), q.y0 - DHT * ((d / 3 | 0) + 0.5)))[0];
      used.add(b.id); if (!b.role) b.role = ro;
      (pos[ro] = pos[ro] || []).push(b.id);
    }
    // 역할 건물은 문을 꼭 하나 더(갇힘 방지) + 엄폐 상자 정리
    // 컨테이너 야적장(항만 광장)
    const yard = plz.filter((p) => p.d === 2 && p.x1 < 114).sort((a, b) => (b.x1 - b.x0) - (a.x1 - a.x0))[0] || plz[0];
    // 지하철역: 구역마다 중심 가까운 인도
    const metro = [];
    for (let d = 0; d < 6; d++) {
      const cx = (d % 3) * DWT + DWT / 2, cy = ((d / 3) | 0) * DHT + DHT / 2;
      let best = null, bd = 1e9;
      for (let y = 1; y < MH - 1; y++) for (let x = 1; x < MW - 1; x++) if (g[I(x, y)] === 1 && distAt(x * T, y * T) === d) { const q = hyp(x - cx, y - cy); if (q < bd) { bd = q; best = [x, y]; } }
      metro.push(best);
    }
    const M = { seed, g, bid, blds, plz, pos, yard, metro };
    MAPS.set(seed, M);
    return M;
  }
  const tAt = (M, tx, ty) => (tx < 0 || ty < 0 || tx >= MW || ty >= MH ? 9 : M.g[ty * MW + tx]);
  const solidAt = (M, px, py, fly) => { const v = tAt(M, Math.floor(px / T), Math.floor(py / T)); return fly ? v === 2 || v === 9 : SOLID[v] === 1; };
  const free = (M, x, y, r, fly) => !(solidAt(M, x - r, y - r, fly) || solidAt(M, x + r, y - r, fly) || solidAt(M, x - r, y + r, fly) || solidAt(M, x + r, y + r, fly));
  function los(M, x0, y0, x1, y1) {
    const d = hyp(x1 - x0, y1 - y0), n = Math.ceil(d / 10);
    for (let i = 1; i < n; i++) { const x = x0 + (x1 - x0) * i / n, y = y0 + (y1 - y0) * i / n; if (BLOCKB[tAt(M, Math.floor(x / T), Math.floor(y / T))]) return false; }
    return true;
  }
  const bldAt = (M, px, py) => { const tx = Math.floor(px / T), ty = Math.floor(py / T); return tx < 0 || ty < 0 || tx >= MW || ty >= MH ? -1 : M.bid[ty * MW + tx]; };
  function floorIn(M, b, r, nearC) { // 건물 안 빈 바닥 칸(중심 px)
    const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, c = [];
    for (let y = b.y0 + 1; y < b.y1; y++) for (let x = b.x0 + 1; x < b.x1; x++) if (M.g[y * MW + x] === 3) c.push([x, y]);
    if (!c.length) return { x: cx * T + 16, y: cy * T + 16 };
    if (nearC) c.sort((a, q) => hyp(a[0] - cx, a[1] - cy) - hyp(q[0] - cx, q[1] - cy));
    const t = nearC ? c[0] : c[Math.floor((r || R)() * c.length)];
    return { x: t[0] * T + 16, y: t[1] * T + 16 };
  }
  function walkNear(M, x, y, rad, r) { // 주변 걸을 수 있는 자리
    for (let k = 0; k < 60; k++) { const a = (r || R)() * 6.283, d = (r || R)() * rad * T, px = x + Math.cos(a) * d, py = y + Math.sin(a) * d; if (free(M, px, py, 12)) return { x: px, y: py }; }
    return { x, y };
  }
  // 흐름장(BFS 거리) — 적 추적·자동 조종
  function flow(M, px, py) {
    const D = new Int16Array(MW * MH).fill(-1), q = new Int32Array(MW * MH);
    const s = Math.floor(py / T) * MW + Math.floor(px / T); let h = 0, t = 0;
    if (s < 0 || s >= MW * MH) return D;
    D[s] = 0; q[t++] = s;
    while (h < t) { const c = q[h++], cx = c % MW, cy = (c / MW) | 0, nd = D[c] + 1;
      if (cx > 0 && D[c - 1] < 0 && !SOLID[M.g[c - 1]]) { D[c - 1] = nd; q[t++] = c - 1; }
      if (cx < MW - 1 && D[c + 1] < 0 && !SOLID[M.g[c + 1]]) { D[c + 1] = nd; q[t++] = c + 1; }
      if (cy > 0 && D[c - MW] < 0 && !SOLID[M.g[c - MW]]) { D[c - MW] = nd; q[t++] = c - MW; }
      if (cy < MH - 1 && D[c + MW] < 0 && !SOLID[M.g[c + MW]]) { D[c + MW] = nd; q[t++] = c + MW; } }
    return D;
  }
  function flowDir(D, x, y) { // 흐름장에서 내려가는 방향 (8방향, 모서리 끼임 방지)
    const tx = Math.floor(x / T), ty = Math.floor(y / T), c = ty * MW + tx; if (c < 0 || c >= D.length) return null;
    let best = D[c] < 0 ? 1e9 : D[c], bx = 0, by = 0;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { if (!dx && !dy) continue; const n = c + dy * MW + dx, v = D[n];
      if (v < 0 || v >= best) continue; if (dx && dy && (D[c + dx] < 0 || D[c + dy * MW] < 0)) continue; best = v; bx = dx; by = dy; }
    if (!bx && !by) return null;
    const gx = (tx + bx) * T + 16, gy = (ty + by) * T + 16, l = hyp(gx - x, gy - y) || 1;
    return { x: (gx - x) / l, y: (gy - y) / l, d: best };
  }

  // ═════════ 물건 ═════════
  let IID = 1;
  function mkGun(b, r, lv) { const B = WB[b], it = { id: IID++, k: 'w', b, r, lv: lv || 1 }; if (r >= 1) it.pk = pick(Object.keys(PERK)); return it; }
  function mkMel(b, r) { return { id: IID++, k: 'm', b, r: r || 0, lv: 1 }; }
  function wStat(it) {
    if (!it) return null;
    if (it.k === 'm') { const B = MB[it.b], m = RAR[it.r || 0].m; return { nm: B.nm, ty: B.ty, dmg: Math.round(B.dmg * m), rof: B.rof, rch: B.rch, st: B.st || 0, nl: B.nl, mel: 1 }; }
    const B = WB[it.b], m = RAR[it.r].m * (1 + (it.lv - 1) * 0.08);
    return { nm: B.nm, ty: B.ty, am: B.am, dmg: Math.round(B.dmg * m), pel: B.pel || 1, rof: +(B.rof * (it.pk === 'rf' ? 1.12 : 1)).toFixed(2), mag: Math.round(B.mag * (it.pk === 'mg' ? 1.3 : 1)), spr: B.spr * (it.pk === 'st' ? 0.75 : 1), rng: B.rng, rl: B.rl, sup: B.sup, hom: B.hom, pc: B.pc, cr: it.pk === 'cr' ? 0.08 : 0 };
  }
  function itVal(it) {
    if (!it) return 0;
    if (it.k === 'w') return Math.round(WB[it.b].val * RAR[it.r].m * RAR[it.r].m * (1 + (it.lv - 1) * 0.15));
    if (it.k === 'm') return Math.round(MB[it.b].val * RAR[it.r || 0].m * RAR[it.r || 0].m);
    if (it.k === 'a') return Math.round(ARM[it.b].val * RAR[it.r || 0].m);
    if (it.k === 'c') return CW[it.b].val;
    if (it.k === 'x') return CON[it.b].val;
    if (it.k === 'h') return QH[it.b].val;
    if (it.k === 'j') return it.v || 50;
    return 0;
  }
  function itName(it) {
    if (!it) return '';
    if (it.k === 'w') return WB[it.b].nm + (it.lv > 1 ? ' +' + (it.lv - 1) : '');
    if (it.k === 'm') return MB[it.b].nm;
    if (it.k === 'a') return ARM[it.b].nm;
    if (it.k === 'c') return CW[it.b].nm;
    if (it.k === 'x') return CON[it.b].nm;
    if (it.k === 'h') return '퀵해킹: ' + QH[it.b].nm;
    if (it.k === 'q') return it.nm || '임무 물건';
    return it.nm || '잡동사니';
  }
  function rollRar(lv, boost) { const u = R() - (lv - 1) * 0.08 - (boost || 0); return u < 0.03 ? 3 : u < 0.15 ? 2 : u < 0.45 ? 1 : 0; }
  function rollGun(lv, boost) { const pool = lv >= 3 ? ['ar', 'sg', 'smt', 'rail', 'rev', 'smg', 'lmg', 'tech', 'dmr', 'twin'] : lv >= 2 ? ['ar', 'smg', 'sg', 'rev', 'sil', 'smt', 'lmg', 'twin', 'dmr'] : ['p9', 'smg', 'sil', 'rev', 'sg', 'twin']; return mkGun(pick(pool), rollRar(lv, boost), lv + (R() < 0.3 ? 1 : 0)); }

  // ═════════ 세계 만들기 ═════════
  const BG = {
    street: { nm: '거리 출신', d: '바늘회 +10 · 기관단총 · 열칼 단검', rep: { nd: 10 }, g: ['smg', 'p9'], m: 'knife', cr: 300 },
    corp: { nm: '기업 출신', d: '아크라 +10 · 침묵 권총 · 표적 광학 · 크레딧 +600', rep: { ak: 10 }, g: ['sil', null], m: 'baton', cr: 900, cw: 'tgt' },
    drift: { nm: '떠돌이', d: '잿빛 연합·유령망 +5 · 산탄총 · 신호 추적', rep: { ash: 5, gh: 5 }, g: ['sg', 'p9'], m: 'knife', cr: 300, qh: 'ping' },
  };
  function newWorld(seed, bgk, nm) {
    const M = genMap(seed), bg = BG[bgk] || BG.street;
    const clinic = M.blds[M.pos.clinic[0]], sp = floorIn(M, clinic, null, true);
    const W = { v: 2, seed, t: 0, nm: nm || '용병', bg: bgk, eid: 1,
      p: { x: sp.x, y: sp.y, a: 0, hp: 100, mhp: 100, ram: 12, mram: 12, hum: 100, heat: 0, cr: bg.cr, xp: 0, lv: 1, pts: 0, at: { b: 3, r: 3, t: 3 },
        inv: [], g: [null, null], m: null, ar: null, cw: { eye: null, arm: null, leg: null, neu: null, skin: null, sys: null }, qh: ['sc', 'bl'], am: { l: 80, h: 30, s: 16 }, cur: 0, mag: [0, 0],
        cd: {}, rl: 0, cro: 0, dash: 0, still: 0, comb: 0, bkT: 0, med: 2, ramc: 1, frag: 2, dead: 0, ping: 0, inside: -1, bike: 0, ride: 0, vx: 0, vy: 0, burn: 0 },
      rep: { ak: 0, nd: 0, ash: 0, gh: 0 }, q: { m: 0, f: {}, jobs: [], jid: 1, done: 0, log: [] },
      en: [], npc: [], term: [], lo: [], bul: [], civ: [], ev: [], seen: [0, 1, 0, 0, 0, 0], shop: {}, lawT: 0, lawSeen: 0, rsp: [0, 0, 0, 0, 0, 0],
      st: { kills: 0, ko: 0, civ: 0, shots: 0, hits: 0, hacks: 0, jobs: 0, earn: 0, died: 0, dmg: 0 } };
    Object.assign(W.rep, bg.rep);
    const P = W.p;
    P.g = bg.g.map((b) => (b ? mkGun(b, 0, 1) : null)); P.m = mkMel(bg.m, 0); P.ar = { id: IID++, k: 'a', b: 'jk', r: 0 };
    if (bg.cw) P.cw[CW[bg.cw].sl] = bg.cw;
    if (bg.qh) P.qh.push(bg.qh);
    P.mag = P.g.map((it) => (it ? wStat(it).mag : 0));
    recalc(W); P.hp = P.mhp; P.ram = P.mram;
    placeNPCs(W, M);
    migrate(W, M);
    Object.assign(P, besideNPC(M, npcById(W, 'doc')));
    for (let d = 0; d < 6; d++) populate(W, M, d);
    for (let i = 0; i < 34; i++) spawnCiv(W, M);
    return W;
  }
  function recalc(W) {
    const P = W.p, has = (k) => Object.values(P.cw).indexOf(k) >= 0;
    P.mhp = 70 + P.at.b * 10 + (P.lv - 1) * 5 + (has('ovr') ? 40 : 0);
    P.mram = 6 + P.at.t * 2 + (has('ram') ? 6 : 0);
    const cost = Object.values(P.cw).reduce((s, k) => s + (k ? CW[k].hum : 0), 0);
    P.humMax = 100 - cost; P.hum = Math.min(P.hum, P.humMax);
    P.il = Object.values(P.cw).some((k) => k && CW[k].il) ? 1 : 0;
    P.hp = Math.min(P.hp, P.mhp); P.ram = Math.min(P.ram, P.mram);
  }
  const hasCW = (W, k) => { const c = W.p.cw; for (const s in c) if (c[s] === k) return true; return false; };
  const pArmor = (W) => (W.p.ar ? ARM[W.p.ar.b].ar * RAR[W.p.ar.r || 0].m : 0) + (hasCW(W, 'sub') ? 20 : 0);
  const pSpeed = (W) => 150 * (1 + (hasCW(W, 'ten') ? 0.15 : 0) + (W.p.ar ? ARM[W.p.ar.b].sp : 0));
  const critCh = (W) => 0.05 + W.p.at.r * 0.025 + (hasCW(W, 'tgt') ? 0.1 : 0) + (hasCW(W, 'mil') ? 0.15 : 0);
  const cdMul = (W) => (hasCW(W, 'cool') ? 0.65 : 1);

  // 이야기·상점 인물 (역할·모습 이름만)
  const NPCS = [
    // id, 역할 건물, 이름, 종류, 세력, 모습{피부, 머리색, 머리모양, 눈, 강조색, 장비}
    ['doc', 'clinic', 0, '의체 시술사', 'clinic', null, { sk: '#c99a7a', hc: '#d8d8e8', hs: 1, ey: '#4fd8ff', ac: '#4fd8ff', gear: 'goggle' }],
    ['fix', 'bar', 0, '붉은 렌즈 중개인', 'fixer', null, { sk: '#8a5a44', hc: '#1a1a22', hs: 2, ey: '#ff3050', ac: '#ff4fa3', gear: 'lens' }],
    ['gun1', 'gun', 1, '네온 총포상', 'gun', null, { sk: '#b07a5a', hc: '#ff8040', hs: 3, ey: '#ffd040', ac: '#ffa040', gear: 'scar' }],
    ['gen1', 'store', 0, '잡화 노점 주인', 'store', null, { sk: '#d8b090', hc: '#5a3a8a', hs: 4, ey: '#c070ff', ac: '#c070ff', gear: 'none' }],
    ['akb', 'akhq', 0, '유리 정장 이사', 'leader', 'ak', { sk: '#e0c0a8', hc: '#e8e8f0', hs: 5, ey: '#4fd8ff', ac: '#4fd8ff', gear: 'visor' }],
    ['gun0', 'gun', 0, '기업 무기 판매관', 'gun', 'ak', { sk: '#c8a088', hc: '#303848', hs: 2, ey: '#4fd8ff', ac: '#4fd8ff', gear: 'visor' }],
    ['ndb', 'ndhq', 0, '은침 두목', 'leader', 'nd', { sk: '#a87058', hc: '#c0c8d8', hs: 6, ey: '#ff4fa3', ac: '#ff4fa3', gear: 'pins' }],
    ['gun2', 'gun', 2, '밀수 총기상', 'gun', 'nd', { sk: '#9a6a50', hc: '#202028', hs: 3, ey: '#ff6f9e', ac: '#ff6f9e', gear: 'scar' }],
    ['ashb', 'ashhq', 0, '용접 가면 위원장', 'leader', 'ash', { sk: '#b08060', hc: '#603018', hs: 7, ey: '#ffa040', ac: '#ffa040', gear: 'weld' }],
    ['gen3', 'store', 1, '공장 배급소지기', 'store', 'ash', { sk: '#c09070', hc: '#404040', hs: 1, ey: '#ffa040', ac: '#ffa040', gear: 'none' }],
    ['ghb', 'ghden', 0, '거울가면 해커', 'leader', 'gh', { sk: '#d0b8a8', hc: '#7dff9a', hs: 8, ey: '#7dff9a', ac: '#7dff9a', gear: 'mirror' }],
    ['doc2', 'clinic', 1, '뒷골목 시술사', 'clinic', 'gh', { sk: '#8a6048', hc: '#2a5a4a', hs: 4, ey: '#7dff9a', ac: '#7dff9a', gear: 'goggle' }],
    ['capt', 'camp', 0, '사슬 갑옷 포로', 'captive', null, { sk: '#b08a70', hc: '#5a4030', hs: 2, ey: '#c8d0e0', ac: '#c070ff', gear: 'none' }],
  ];
  function placeNPCs(W, M) {
    for (const [id, role, k, nm, kind, fa, look] of NPCS) {
      const ids = M.pos[role]; if (!ids || !ids.length) continue;
      const b = M.blds[ids[Math.min(k, ids.length - 1)]], p = floorIn(M, b, rngOf(W.seed + id.length * 31), true);
      W.npc.push({ id, nm, kind, fa, look, x: p.x, y: p.y, b: b.id, a: Math.PI / 2, d: b.d });
    }
  }
  function besideNPC(M, n) { // 인물 옆 빈자리(같은 방, 보이는 곳)
    for (const r of [1.2, 1.6, 2]) for (let k = 0; k < 16; k++) { const a = k / 16 * 6.283, x = n.x + Math.cos(a) * r * T, y = n.y + Math.sin(a) * r * T; if (free(M, x, y, 12) && los(M, x, y, n.x, n.y)) return { x, y }; }
    return { x: n.x, y: n.y + T };
  }
  const npcById = (W, id) => W.npc.find((n) => n.id === id);
  function spawnEnemy(W, M, ty, fa, x, y, o) {
    const E = EN[ty], d = distAt(x, y), lv = (o && o.lv) || DIST[d].lv;
    const wk = (o && o.w) || pick(E.w);
    const hm = 1 + (lv - 1) * 0.25;
    const e = { id: W.eid++, ty, fa, x, y, a: R() * 6.28, hp: Math.round(E.hp * hm * (o && o.hm || 1)), ar: E.ar, w: wk, mag: WB[wk] ? WB[wk].mag : 0, cd: 0.5 + R(), st: 0, sus: 0, lx: x, ly: y, lt: 0, px: x, py: y, wt: R() * 3, tx: x, ty2: y, lv, grp: (o && o.grp) || 0, hos: !!(o && o.hos), q: (o && o.q) || null, bl: 0, jm: 0, cf: 0, stn: 0, nm: (o && o.nm) || null };
    e.mhp = e.hp; W.en.push(e); return e;
  }
  function spawnGroup(W, M, fa, x, y, n, o) {
    const grp = W.eid * 10 + 1, lv = (o && o.lv) || DIST[distAt(x, y)].lv, pool = poolFor(fa, lv), out = [];
    for (let i = 0; i < n; i++) { const p = walkNear(M, x, y, 2.5); let ty = i === 0 && o && o.elite ? pick(FA_EL[fa] || FA_EL.raid) : pick(pool); out.push(spawnEnemy(W, M, ty, fa, p.x, p.y, Object.assign({}, o || {}, { grp }))); }
    return out;
  }
  function populate(W, M, d) {
    const D = DIST[d];
    if (d === 1) { // 시장: 순찰 경관
      for (let k = 0; k < 2; k++) { const s = M.metro[1]; const p = walkNear(M, s[0] * T, s[1] * T, 8); spawnGroup(W, M, 'law', p.x, p.y, 2, { lv: 1 }); }
      return;
    }
    const sites = M.plz.filter((p) => p.d === d).concat(M.blds.filter((b) => b.d === d && !b.role));
    const n = 3 + D.lv;
    for (let k = 0; k < n && sites.length; k++) {
      const s = sites[Math.floor(R() * sites.length)], b = s.id != null ? s : null;
      const p = b ? floorIn(M, b) : { x: ((s.x0 + s.x1) / 2) * T + 16, y: ((s.y0 + s.y1) / 2) * T + 16 };
      spawnGroup(W, M, D.fa, p.x, p.y, 2 + (R() < 0.5 ? 1 : 0), { elite: D.lv >= 2 && R() < 0.3 });
    }
    if (d === 0) for (let k = 0; k < 2; k++) { const b = pick(M.blds.filter((q) => q.d === 0)); const p = floorIn(M, b); spawnEnemy(W, M, 'turret', 'ak', p.x, p.y); }
    // 금고 단말기(해킹하면 크레딧)
    for (let k = 0; k < 2; k++) { const b = pick(M.blds.filter((q) => q.d === d && !q.role)); if (!b) continue; const p = floorIn(M, b); W.term.push({ id: W.eid++, x: p.x, y: p.y, lv: D.lv, kind: 'cash', done: 0 }); }
  }
  function spawnCiv(W, M) {
    const ds = [1, 1, 1, 2, 3, 4, 4, 0];
    const d = pick(ds), cand = [];
    for (let k = 0; k < 40 && !cand.length; k++) { const x = (d % 3) * DWT + 1 + Math.floor(R() * (DWT - 2)), y = ((d / 3) | 0) * DHT + 1 + Math.floor(R() * (DHT - 2)); if (tAt(M, x, y) === 1) cand.push([x, y]); }
    if (!cand.length) return;
    const [x, y] = cand[0];
    W.civ.push({ id: W.eid++, x: x * T + 16, y: y * T + 16, tx: x * T + 16, ty: y * T + 16, fl: 0, hp: 30, c: pick(['#ff4fa3', '#4fd8ff', '#ffd040', '#7dff9a', '#c070ff', '#e8e8f0', '#ff8040']), d });
  }

  // ═════════ 시뮬레이션 ═════════
  const ev = (W, e) => { if (W.ev.length < 300) W.ev.push(e); };
  const msg = (W, t, c) => ev(W, { k: 'msg', t, c });
  function hostile(W, e) {
    if (e.hp <= 0) return false;
    if (e.hos || e.fa === 'raid') return true;
    if (e.fa === 'law') return W.p.heat >= 30;
    if (W.rep[e.fa] != null && W.rep[e.fa] <= -30) return true;
    return false;
  }
  function addRep(W, fa, n, why) {
    if (W.rep[fa] == null || !n) return;
    W.rep[fa] = clamp(Math.round(W.rep[fa] + n), -100, 100);
    msg(W, FA[fa].nm + ' 평판 ' + (n > 0 ? '+' : '') + n + (why ? ' · ' + why : ''), n > 0 ? '#7dff9a' : '#ff6f6f');
  }
  function addHeat(W, n) { if (n <= 0) return; const P = W.p; const before = P.heat; P.heat = clamp(P.heat + n * (P.il ? 1.25 : 1), 0, 100); W.lawSeen = W.t; if (before < 30 && P.heat >= 30) msg(W, '⚠ 수배! 질서국이 쫓아와요', '#ff4fa3'); }
  function addXP(W, n) {
    const P = W.p; P.xp += n;
    for (;;) { const need = Math.round(100 * P.lv * 1.3); if (P.xp < need) break; P.xp -= need; P.lv++; P.pts++; recalc(W); P.hp = P.mhp; ev(W, { k: 'lvl' }); msg(W, '레벨 ' + P.lv + '! 능력치 점수 +1 (소지품 창)', '#ffd040'); }
  }
  function addCr(W, n, why) { W.p.cr += n; if (n > 0) W.st.earn += n; if (why) msg(W, (n > 0 ? '+' : '') + n + ' 크레딧 · ' + why, '#ffd040'); }
  function giveItem(W, it, quiet) { if (W.p.inv.length >= 40) { msg(W, '가방이 가득 찼어요', '#ff6f6f'); return false; } W.p.inv.push(it); if (!quiet) msg(W, '획득: ' + itName(it), it.r != null ? RAR[it.r].c : '#e8e8f0'); return true; }

  function dmgEnemy(W, M, e, dmg, src, o) {
    if (e.hp <= 0) return;
    o = o || {};
    if (src === 'p' && hasCW(W, 'scan') && (e.stn > 0 || e.bl > 0 || e.cf > 0)) dmg *= 1.35;
    const ar = o.pierce ? e.ar * 0.3 : e.ar, d = Math.max(1, dmg * (1 - ar / (ar + 50)));
    const wasHos = hostile(W, e);
    e.hp -= d; W.st.dmg += d;
    if (!o.quiet) ev(W, { k: 'hit', x: e.x, y: e.y, n: Math.round(d), cr: o.cr, e: 1, mech: EN[e.ty].mech });
    if (src === 'p') {
      if (!wasHos) { // 먼저 때림 → 그 무리 적대, 평판 하락
        const grp = W.en.filter((q) => q.grp === e.grp && hyp(q.x - e.x, q.y - e.y) < 12 * T);
        grp.forEach((q) => { q.hos = true; q.st = 2; q.lx = W.p.x; q.ly = W.p.y; q.lt = 0; });
        if (e.fa === 'law') addHeat(W, 25); else { addRep(W, e.fa, -5, '공격'); addHeat(W, distAt(e.x, e.y) === 1 ? 14 : 6); }
      }
      e.st = 2; e.lx = W.p.x; e.ly = W.p.y; e.lt = 0;
    }
    if (o.stun) e.stn = Math.max(e.stn, o.stun);
    if (e.hp <= 0) killEnemy(W, M, e, src, o);
  }
  function killEnemy(W, M, e, src, o) {
    e.hp = 0;
    const E = EN[e.ty];
    ev(W, { k: 'die', x: e.x, y: e.y, mech: E.mech, fa: e.fa });
    if (src === 'p') {
      if (o && o.nl) W.st.ko++; else W.st.kills++;
      addXP(W, Math.round(E.xp * (1 + (e.lv - 1) * 0.3)));
      if (e.fa === 'law') addHeat(W, 18);
      else if (FKEYS.indexOf(e.fa) >= 0 && !e.hos && W.rep[e.fa] > -30) addRep(W, e.fa, -3, '처치');
      // 인간성: 비살상이면 조금 회복, 무저항 살상은 조금 감소
      if (o && o.nl) W.p.hum = Math.min(W.p.humMax, W.p.hum + 0.3);
    }
    // 전리품
    const lv = e.lv, drop = (it) => W.lo.push({ id: W.eid++, x: e.x + (R() - 0.5) * 20, y: e.y + (R() - 0.5) * 20, it });
    if (E.fix) { drop({ k: 'cr', n: 40 * lv }); }
    else {
      drop({ k: 'cr', n: Math.round((10 + R() * 30) * lv * (E.elite ? 3 : 1)) });
      if (R() < 0.35) { const a = pick(['l', 'l', 'h', 's']); drop({ k: 'am', a, n: Math.round(AMMO[a].n * 0.5) }); }
      if (E.boss) drop(rollGun(lv, 0.6));
      else if (E.elite ? R() < 0.7 : R() < 0.12) drop(rollGun(lv, E.elite ? 0.2 : 0));
      if (R() < 0.12) drop({ id: IID++, k: 'x', b: R() < 0.5 ? 'med' : R() < 0.5 ? 'ramc' : 'frag' });
      if (R() < 0.08 * lv) drop({ id: IID++, k: 'j', nm: pick(JUNK), v: 40 + Math.floor(R() * 90 * lv) });
      if (R() < 0.04 && lv >= 2) drop({ id: IID++, k: 'a', b: pick(['coat', 'vest', 'nano']), r: rollRar(lv) });
    }
    Q.onKill(W, M, e, o);
  }
  function dmgPlayer(W, M, dmg, from, quiet) {
    const P = W.p; if (P.dead || P.dash > 0) return;
    if (!quiet && hasCW(W, 'refl') && R() < 0.25) { ev(W, { k: 'dodge', x: P.x, y: P.y }); return; }
    const ar = pArmor(W), d = Math.max(quiet ? 0 : 1, dmg * (1 - ar / (ar + 50)));
    P.hp -= d; P.comb = 6; if (!quiet) ev(W, { k: 'hurt', n: Math.round(d), fx: from ? from.x : P.x, fy: from ? from.y : P.y });
    if (P.hp <= 0) {
      if (hasCW(W, 'bk') && P.bkT <= 0) { P.hp = P.mhp * 0.5; P.bkT = 120 * cdMul(W); msg(W, '피질 백업 작동! 다시 일어났어요', '#4fd8ff'); ev(W, { k: 'revive' }); return; }
      P.hp = 0; P.dead = 3; W.st.died++; ev(W, { k: 'dead' });
    }
  }
  function respawn(W, M) {
    const P = W.p, sp = besideNPC(M, npcById(W, 'doc'));
    const lost = Math.round(P.cr * 0.15);
    P.x = sp.x; P.y = sp.y; P.hp = P.mhp; P.ram = P.mram; P.dead = 0; P.heat = 0; P.cr -= lost; P.ride = 0; P.vx = P.vy = 0; P.burn = 0;
    W.bul = []; W.en.forEach((e) => { if (e.st === 2 && !e.q) { e.st = 0; e.sus = 0; } if (e.fa === 'law' && !e.q) e.hp = 0; });
    W.en = W.en.filter((e) => e.hp > 0);
    msg(W, '시술사가 당신을 살려 냈어요 · 치료비 ' + lost + ' 크레딧', '#ff6f9e');
  }

  // 총·근접·능력
  function curW(W) { const P = W.p; return P.cur < 2 ? P.g[P.cur] : P.m; }
  function fire(W, M, aim, tgt) {
    const P = W.p, it = P.g[P.cur]; if (!it) return;
    const s = wStat(it);
    if (P.cd.f > 0 || P.rl > 0) return;
    if (P.mag[P.cur] <= 0) { reload(W); return; }
    P.mag[P.cur]--; P.cd.f = 1 / s.rof; P.comb = 6; W.st.shots += s.pel;
    let spr = s.spr * (1.15 - P.at.r * 0.05) * (hasCW(W, 'mil') ? 0.6 : 1) * (P.cro ? 0.7 : 1) * (P.mv ? 1.3 : 1);
    const cr = R() < critCh(W) + s.cr + (P.rcT > W.t ? 0.25 : 0);
    for (let i = 0; i < s.pel; i++) {
      const a = aim + (R() - 0.5) * 2 * spr, sp = 1150;
      W.bul.push({ x: P.x + Math.cos(aim) * 16, y: P.y + Math.sin(aim) * 16, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, l: s.rng * T / sp, d: s.dmg * (cr ? 2 : 1), cr, o: 0, hom: s.hom, pc: s.pc, pv: tgt || 0 });
    }
    ev(W, { k: 'shot', x: P.x, y: P.y, a: aim, w: it.b, p: 1, sup: s.sup });
    // 소리: 주변 적 경보
    const rad = (s.sup ? 3 : 15) * T;
    for (const e of W.en) if (e.hp > 0 && hostile(W, e) && hyp(e.x - P.x, e.y - P.y) < rad) { if (e.st < 2) { e.st = 2; e.lt = 1.5; } e.lx = P.x + (R() - 0.5) * 60; e.ly = P.y + (R() - 0.5) * 60; }
    // 시민 겁먹음 + 공공장소 총질 열기
    if (!s.sup) { let near = false; for (const c of W.civ) if (hyp(c.x - P.x, c.y - P.y) < 10 * T) { c.fl = 6; near = true; } if (near && !W.en.some((e) => e.hp > 0 && hostile(W, e) && hyp(e.x - P.x, e.y - P.y) < 16 * T)) addHeat(W, 2); }
  }
  function reload(W) {
    const P = W.p, it = P.g[P.cur]; if (!it || P.rl > 0) return;
    const s = wStat(it); if (P.mag[P.cur] >= s.mag || P.am[s.am] <= 0) { if (P.am[s.am] <= 0 && !(P.namT > W.t)) P.namT = W.t + 3, msg(W, s.am === 'l' ? '경탄이 없어요' : s.am === 'h' ? '중탄이 없어요' : '산탄이 없어요', '#ff6f6f'); return; }
    P.rl = s.rl; ev(W, { k: 'reload' });
  }
  function melee(W, M, aim) {
    const P = W.p; if (P.cd.m > 0) return;
    const mono = hasCW(W, 'mono'), claw = hasCW(W, 'claw'), s = mono ? { dmg: 45, rof: 1.5, rch: 3, arc: 1.3 } : claw ? { dmg: 62, rof: 2.4, rch: 2, arc: 0.85 } : wStat(P.m || mkMel('fist'));
    const mul = hasCW(W, 'gor') ? 1.6 : 1;
    P.cd.m = 1 / s.rof; P.comb = 4;
    ev(W, { k: 'swing', x: P.x, y: P.y, a: aim, mono, claw, p: 1 });
    let hit = 0;
    for (const e of W.en) {
      if (e.hp <= 0) continue; const dx = e.x - P.x, dy = e.y - P.y, d = hyp(dx, dy);
      if (d > s.rch * T + EN[e.ty].r || Math.abs(angD(aim, Math.atan2(dy, dx))) > (s.arc || 0.75)) continue;
      const unaware = e.st < 2 || e.bl > 0 || e.stn > 0;
      const tk = unaware && !EN[e.ty].boss && !EN[e.ty].fix;
      dmgEnemy(W, M, e, s.dmg * mul * (tk ? 6 : 1), 'p', { nl: s.nl, stun: s.st, cr: tk });
      if (tk) ev(W, { k: 'takedown', x: e.x, y: e.y });
      hit++; if (!mono) break;
    }
    for (const c of W.civ) if (hyp(c.x - P.x, c.y - P.y) < s.rch * T + 10 && Math.abs(angD(aim, Math.atan2(c.y - P.y, c.x - P.x))) < 0.75) hitCiv(W, M, c, s.dmg * mul, s.nl);
    return hit;
  }
  function hitCiv(W, M, c, d, nl) {
    if (c.hp <= 0) return; c.hp -= d; c.fl = 8;
    if (c.hp <= 0) { ev(W, { k: 'die', x: c.x, y: c.y, civ: 1 }); if (!nl) { W.st.civ++; addHeat(W, 28); W.p.hum = Math.max(0, W.p.hum - 3); msg(W, '시민이 죽었어요 · 인간성 −3', '#ff6f6f'); } else addHeat(W, 8); }
    else addHeat(W, 6);
  }
  function abilityLeg(W, M, mx, my, aim) {
    const P = W.p; if ((P.cd.dash || 0) > 0 || P.ride) return; const cy = hasCW(W, 'dash'); // 의체 없으면 짧은 구르기
    let dx = mx, dy = my; if (!dx && !dy) { dx = Math.cos(aim); dy = Math.sin(aim); }
    const l = hyp(dx, dy) || 1; P.dv = { x: dx / l, y: dy / l }; P.dash = cy ? 0.22 : 0.2; P.dd = P.dash; P.dl = cy ? 4 : 2.3; P.cd.dash = (cy ? 3 : 1.4) * cdMul(W) * (hasCW(W, 'roll') ? 0.55 : 1); if (hasCW(W, 'roll')) P.rcT = W.t + 1.5 + P.dash; ev(W, { k: 'dash', x: P.x, y: P.y, roll: !cy });
  }
  function abilityArm(W, M, aim, tx, ty) {
    const P = W.p; if (!hasCW(W, 'pjl') || (P.cd.arm || 0) > 0) return;
    P.cd.arm = 12 * cdMul(W);
    const d = Math.min(hyp(tx - P.x, ty - P.y), 9 * T);
    W.bul.push({ x: P.x, y: P.y, vx: Math.cos(aim) * 600, vy: Math.sin(aim) * 600, l: d / 600, d: 70, o: 0, gren: 1 });
    ev(W, { k: 'shot', x: P.x, y: P.y, a: aim, w: 'gren', p: 1 }); addHeat(W, 3);
  }
  function throwFrag(W, M, aim, tx, ty) {
    const P = W.p; if (P.frag <= 0) { msg(W, '수류탄이 없어요', '#ff6f6f'); return; } if ((P.cd.frag || 0) > 0) return;
    P.frag--; P.cd.frag = 0.8; const d = Math.max(2 * T, Math.min(hyp(tx - P.x, ty - P.y), 9 * T));
    W.bul.push({ x: P.x, y: P.y, vx: Math.cos(aim) * 520, vy: Math.sin(aim) * 520, l: d / 520, d: 80, o: 0, gren: 1, frag: 1 });
    ev(W, { k: 'throw', x: P.x, y: P.y, a: aim }); addHeat(W, 2);
  }
  function abilityTime(W) {
    const P = W.p; if (!hasCW(W, 'sand') || (P.cd.time || 0) > 0) return;
    P.cd.time = 20 * cdMul(W); W.slow = 4; ev(W, { k: 'slow' });
  }
  function toggleBike(W, M) {
    const P = W.p; if (!P.bike) { msg(W, '오토바이가 없어요 (네온 시장 잡화 노점)', '#ff6f6f'); return; }
    if (P.ride) { P.ride = 0; P.vx = P.vy = 0; ev(W, { k: 'bikeoff' }); return; }
    if (P.inside >= 0 || bldAt(M, P.x, P.y) >= 0) { msg(W, '건물 밖에서만 탈 수 있어요', '#ff6f6f'); return; }
    if (W.en.some((e) => e.hp > 0 && e.st === 2 && hostile(W, e) && hyp(e.x - W.p.x, e.y - W.p.y) < 6 * T)) { msg(W, '적이 너무 가까워요', '#ff6f6f'); return; }
    P.ride = 1; P.cro = false; ev(W, { k: 'bikeon' });
  }
  function boom(W, M, x, y, dmg, own) {
    ev(W, { k: 'boom', x, y });
    for (const e of W.en) { const d = hyp(e.x - x, e.y - y); if (e.hp > 0 && d < 3 * T && los(M, x, y, e.x, e.y)) dmgEnemy(W, M, e, dmg * (1 - d / (3 * T) * 0.5), own === 0 ? 'p' : 'e'); }
    if (own !== 0) { const d = hyp(W.p.x - x, W.p.y - y); if (d < 3 * T) dmgPlayer(W, M, dmg * 0.6 * (hasCW(W, 'hsk') ? 0.5 : 1), { x, y }); }
    for (const c of W.civ) if (hyp(c.x - x, c.y - y) < 3 * T) hitCiv(W, M, c, dmg, 0);
  }
  function qhCost(W, k) { return Math.max(1, Math.round(QH[k].ram * (hasCW(W, 'qk') ? 0.7 : 1))); }
  function quickhack(W, M, k, tgt) {
    const P = W.p, H = QH[k]; if (!H || P.qh.indexOf(k) < 0) return false;
    P.cd.qh = P.cd.qh || {}; if ((P.cd.qh[k] || 0) > 0) return false;
    const cost = qhCost(W, k); if (P.ram < cost) { msg(W, 'RAM이 모자라요', '#ff6f6f'); return false; }
    if (k === 'ping') { P.ram -= cost; P.ping = 10; P.cd.qh[k] = H.cd * cdMul(W) * (hasCW(W, 'qk') ? 0.6 : 1); ev(W, { k: 'ping', x: P.x, y: P.y }); W.st.hacks++; return true; }
    const e = W.en.find((q) => q.id === tgt && q.hp > 0); if (!e) return false;
    if (hyp(e.x - P.x, e.y - P.y) > 14 * T) { msg(W, '해킹 거리 밖이에요 (14칸)', '#ff6f6f'); return false; }
    if (k === 'reb' && !EN[e.ty].mech) { msg(W, '재부팅 장악은 드론·포탑·사이보그에만 돼요', '#ff6f6f'); return false; }
    if (k === 'reb' && EN[e.ty].boss) { msg(W, '두목은 장악할 수 없어요', '#ff6f6f'); return false; }
    P.ram -= cost; P.cd.qh[k] = H.cd * cdMul(W) * (hasCW(W, 'qk') ? 0.6 : 1); W.st.hacks++;
    ev(W, { k: 'hack', x: e.x, y: e.y, h: k });
    const unaware = e.st < 2;
    if (k === 'sc') dmgEnemy(W, M, e, 30 * (EN[e.ty].mech ? 1.8 : 1) * (1 + P.at.t * 0.04), 'p', { stun: 0.6 });
    else if (k === 'bl') { e.bl = 6; e.st = Math.min(e.st, 1); e.sus = 0; }
    else if (k === 'jam') e.jm = 7;
    else if (k === 'crip') e.slw = 6;
    else if (k === 'conf') e.cf = 8;
    else if (k === 'reb') e.cf = 15;
    else if (k === 'burn') e.burn = 5;
    else if (k === 'wipe') { if (!EN[e.ty].boss) W.en.forEach((q) => { if (q.hp > 0 && (q === e || (q.grp === e.grp && hyp(q.x - e.x, q.y - e.y) < 9 * T))) { q.st = 0; q.sus = 0; q.lt = 0; q.aimT = 0; q.up = 0; } }); }
    // 몰래 해킹은 들키지 않음(단락은 맞으면 경계)
    if (k === 'wipe') {}
    else if (unaware && k !== 'sc' && k !== 'burn') { e.st = Math.min(e.st, 1); }
    else if (k !== 'sc' && !hostile(W, e)) { e.hos = true; addRep(W, e.fa, -3, '해킹'); }
    return true;
  }
  function useMed(W) { const P = W.p; if (P.med <= 0 || P.hp >= P.mhp) return false; P.med--; P.hp = Math.min(P.mhp, P.hp + 50); ev(W, { k: 'heal' }); return true; }

  // ── 한 걸음 ──
  // inp: {mx,my, ax,ay(조준 세계 좌표), fire, mel, sprint, cro, dash, arm, rl, hack:k, tgt}
  function step(W, dt, inp) {
    const M = genMap(W.seed), P = W.p;
    W.t += dt; inp = inp || {};
    for (const k in P.cd) if (typeof P.cd[k] === 'number') P.cd[k] -= dt;
    if (P.cd.qh) for (const k in P.cd.qh) P.cd.qh[k] -= dt;
    P.bkT -= dt; P.comb -= dt; P.ping -= dt; W.slow = Math.max(0, (W.slow || 0) - dt);
    if (P.burn > 0 && !P.dead) { P.burn -= dt; dmgPlayer(W, null, dt * 9 * (hasCW(W, 'hsk') ? 0.5 : 1), null, true); if (P.hp <= 0 && !P.dead) dmgPlayer(W, null, 1, null); }
    // 플레이어
    if (P.dead > 0) { P.dead -= dt; if (P.dead <= 0) respawn(W, M); }
    else {
      const aim = Math.atan2((inp.ay || P.y) - P.y, (inp.ax || P.x + 1) - P.x); P.a = aim;
      let mx = inp.mx || 0, my = inp.my || 0; const ml = hyp(mx, my); if (ml > 1) { mx /= ml; my /= ml; }
      if (inp.bike) toggleBike(W, M);
      P.cro = !!inp.cro && !P.ride; P.mv = ml > 0.1;
      let sp = pSpeed(W) * (P.cro ? 0.55 : inp.sprint ? 1.45 : 1);
      if (P.ride) { // 오토바이: 관성 있게 가속·감속, 부딪히면 튕김
        const top = 150 * (inp.sprint ? 2.9 : 2.3), k = Math.min(1, dt * (ml > 0.1 ? 2.6 : 1.8));
        P.vx += (mx * top - P.vx) * k; P.vy += (my * top - P.vy) * k;
        const nx = P.x + P.vx * dt, ny = P.y + P.vy * dt, spd = hyp(P.vx, P.vy);
        if (free(M, nx, P.y, 12)) P.x = nx; else { if (Math.abs(P.vx) > 200) ev(W, { k: 'crash', x: P.x, y: P.y }); P.vx *= -0.3; }
        if (free(M, P.x, ny, 12)) P.y = ny; else { if (Math.abs(P.vy) > 200) ev(W, { k: 'crash', x: P.x, y: P.y }); P.vy *= -0.3; }
        if (spd > 20) P.ba = Math.atan2(P.vy, P.vx);
        if (spd > 170) { for (const e of W.en) { if (e.hp <= 0 || (e.rk || 0) > W.t || EN[e.ty].fly) continue; if (hyp(e.x - P.x, e.y - P.y) < EN[e.ty].r + 14) { e.rk = W.t + 1; dmgEnemy(W, M, e, 18 + spd * 0.08, 'p', { stun: 0.8 }); P.vx *= 0.5; P.vy *= 0.5; ev(W, { k: 'crash', x: e.x, y: e.y }); } }
          for (const c of W.civ) if (c.hp > 0 && hyp(c.x - P.x, c.y - P.y) < 18) { hitCiv(W, M, c, 14, 1); c.fl = 6; } }
        if (bldAt(M, P.x, P.y) >= 0) { P.ride = 0; P.vx = P.vy = 0; ev(W, { k: 'bikeoff' }); }
        P.noise = spd > 40 ? 6 : 1.5; P.still = 0; P.mv = spd > 20;
      } else {
      if (P.dash > 0) { P.dash -= dt; mx = P.dv.x; my = P.dv.y; sp = (P.dl || 4) * T / (P.dd || 0.22); }
      const nx = P.x + mx * sp * dt, ny = P.y + my * sp * dt;
      if (free(M, nx, P.y, 11)) P.x = nx; if (free(M, P.x, ny, 11)) P.y = ny;
      P.still = P.mv ? 0 : P.still + dt;
      P.noise = !P.mv ? 0 : P.cro ? (hasCW(W, 'pad') ? 0 : 1.2) : inp.sprint ? (hasCW(W, 'pad') ? 2 : 5) : (hasCW(W, 'pad') ? 0.8 : 2.5);
      }
      P.camo = hasCW(W, 'camo') && P.cro && P.still > 1;
      if (P.rl > 0) { P.rl -= dt; if (P.rl <= 0) { const it = P.g[P.cur]; if (it) { const s = wStat(it), need = s.mag - P.mag[P.cur], n = Math.min(need, P.am[s.am]); P.mag[P.cur] += n; P.am[s.am] -= n; } } }
      if (inp.rl) reload(W);
      if (!P.ride) {
        if (inp.fire) { if (P.cur < 2) fire(W, M, aim, inp.tgt); else melee(W, M, aim); }
        if (inp.mel) melee(W, M, aim);
        if (inp.dash) abilityLeg(W, M, mx, my, aim);
        if (inp.arm) abilityArm(W, M, aim, inp.ax, inp.ay);
        if (inp.hack) quickhack(W, M, inp.hack, inp.tgt);
        if (inp.frag) throwFrag(W, M, aim, inp.ax, inp.ay);
      }
      if (inp.time) abilityTime(W);
      // 회복
      P.ram = Math.min(P.mram, P.ram + dt * (0.45 + P.at.t * 0.05) * (P.hum < 25 ? 0.6 : 1));
      if (hasCW(W, 'regen')) P.hp = Math.min(P.mhp, P.hp + dt * (P.comb > 0 ? 0.75 : 1.5));
      else if (P.comb <= 0) P.hp = Math.min(P.mhp, P.hp + dt * 0.6);
      // 줍기 (닿으면 자동)
      for (let i = W.lo.length - 1; i >= 0; i--) { const o = W.lo[i]; if (hyp(o.x - P.x, o.y - P.y) > 26) continue; const it = o.it;
        if (it.k === 'cr') { addCr(W, it.n); ev(W, { k: 'coin', n: it.n }); }
        else if (it.k === 'am') { P.am[it.a] += it.n; ev(W, { k: 'pick' }); msg(W, '+' + it.n + ' ' + AMMO[it.a].nm, '#c8d0e0'); }
        else if (it.k === 'x' && (it.b === 'med' || it.b === 'ramc' || it.b === 'frag')) { P[it.b]++; ev(W, { k: 'pick' }); msg(W, '+1 ' + CON[it.b].nm, '#7dff9a'); }
        else if (!giveItem(W, it)) continue; else ev(W, { k: 'pick' });
        W.lo.splice(i, 1); }
      // 구역 발견
      const d = distAt(P.x, P.y); if (!W.seen[d]) { W.seen[d] = 1; msg(W, '새 구역: ' + DIST[d].nm + ' · 지하철역 열림', DIST[d].c); addXP(W, 20); }
      P.inside = bldAt(M, P.x, P.y); P.d = d;
    }
    // 흐름장(경계 중인 적이 있을 때만)
    if (!W._fl || W.t - W._flT > 0.4) { if (W.en.some((e) => e.st === 2 && e.hp > 0)) { W._fl = flow(M, P.x, P.y); W._flT = W.t; } }
    const sl = W.slow > 0 ? 0.35 : 1;
    stepEnemies(W, M, dt * sl);
    stepBullets(W, M, dt, sl);
    stepCivs(W, M, dt);
    // 열기·질서국
    const lawOn = W.en.some((e) => e.fa === 'law' && e.st === 2 && e.hp > 0 && e.lt < 3);
    if (lawOn) W.lawSeen = W.t;
    if (W.t - W.lawSeen > 7) P.heat = Math.max(0, P.heat - dt * 3);
    if (P.heat >= 30 && !P.dead) { W.lawT -= dt; if (W.lawT <= 0) { W.lawT = (28 - P.heat * 0.12) * (P.lawK ? 1.6 : 1); const n = W.en.filter((e) => e.fa === 'law' && e.hp > 0).length; if (n < 8) { const p = walkNear(M, P.x, P.y, 14); for (let k = 0; k < 14 && hyp(p.x - P.x, p.y - P.y) < 9 * T; k++) Object.assign(p, walkNear(M, P.x, P.y, 16)); const g = spawnGroup(W, M, 'law', p.x, p.y, P.heat >= 85 ? 3 : 2, { lv: P.heat >= 60 ? 3 : 2, elite: P.heat >= 85 }); g.forEach((e) => { e.st = 2; e.lx = P.x; e.ly = P.y; e.lt = 2; }); if (P.heat >= 60) { const dr = spawnEnemy(W, M, 'drone', 'law', p.x, p.y, { lv: 2, grp: g[0].grp }); dr.st = 2; dr.lx = P.x; dr.ly = P.y; } msg(W, '질서국 출동!', '#8fa8ff'); } } }
    else if (P.heat < 30) W.lawT = 4;
    // 죽은 적 정리 + 구역 다시 채우기
    if (W.en.length > 0 && (W._gc = (W._gc || 0) + 1) % 60 === 0) {
      W.en = W.en.filter((e) => e.hp > 0 || false);
      W.civ = W.civ.filter((c) => c.hp > 0); while (W.civ.length < 30) spawnCiv(W, M);
      if (W.lo.length > 120) W.lo.splice(0, W.lo.length - 120);
      for (let d = 0; d < 6; d++) { if (d === P.d) continue; W.rsp[d] = (W.rsp[d] || 0) + 1; if (W.rsp[d] > 180) { W.rsp[d] = 0; const n = W.en.filter((e) => !e.q && e.fa !== 'law' && distAt(e.x, e.y) === d).length; if (n < 5 + DIST[d].lv && d !== 1) populateTop(W, M, d); } }
    }
    Q.tick(W, M, dt);
  }
  function populateTop(W, M, d) { const sites = M.plz.filter((p) => p.d === d); if (!sites.length) return; const s = pick(sites); spawnGroup(W, M, DIST[d].fa, ((s.x0 + s.x1) / 2) * T + 16, ((s.y0 + s.y1) / 2) * T + 16, 2 + (R() < 0.5 ? 1 : 0), { elite: R() < 0.25 }); }

  function canSeeP(W, M, e) {
    const P = W.p; if (P.dead || e.bl > 0 || P.camo) return false;
    const dx = P.x - e.x, dy = P.y - e.y, d = hyp(dx, dy), rng = (P.cro ? 6 : 9) * T * (e.st === 2 ? 1.5 : 1);
    if (d > rng) return false;
    if (d > 2.2 * T && e.st < 2 && Math.abs(angD(e.a, Math.atan2(dy, dx))) > 0.95) return false;
    return los(M, e.x, e.y, P.x, P.y);
  }
  function stepEnemies(W, M, dt) {
    const P = W.p;
    for (const e of W.en) {
      if (e.hp <= 0) continue;
      const E = EN[e.ty]; e.cd -= dt; e.bl -= dt; e.jm -= dt; e.cf -= dt; e.wt -= dt; if (e.slw > 0) e.slw -= dt;
      if (e.burn > 0) { e.burn -= dt; dmgEnemy(W, M, e, dt * 8 * (E.mech ? 1.3 : 1), 'p', { quiet: 1 }); if (e.hp <= 0) continue; }
      if (e.dsh > 0) { e.dsh -= dt; moveE(W, M, e, e.dvx, e.dvy, dt, 4.2); if (hyp(P.x - e.x, P.y - e.y) < E.r + 14 && !e.dhit) { e.dhit = 1; dmgPlayer(W, M, MB[e.w] ? MB[e.w].dmg * 0.8 : 20, e); } continue; }
      if (E.boss && !e.ph2 && e.hp < e.mhp * 0.5) { e.ph2 = 1; e.gt = 2; msg(W, (e.nm || E.nm) + ' — 분노! 지원을 불렀어요', '#ff3050'); ev(W, { k: 'alarm' });
        if (!E.lunge) for (let k = 0; k < 2; k++) { const p = walkNear(M, e.x, e.y, 3); const d = spawnEnemy(W, M, 'drone', e.fa, p.x, p.y, { lv: 3, hos: true, q: e.q, grp: e.grp }); d.st = 2; d.lx = P.x; d.ly = P.y; } }
      if (e.stn > 0) { e.stn -= dt; e.up = 0; e.aimT = 0; continue; }
      if (e.rl > 0) { e.rl -= dt; if (e.rl <= 0) e.mag = WB[e.w].mag; }
      const hos = hostile(W, e);
      // 착란: 가까운 다른 적을 공격
      if (e.cf > 0) { const o = W.en.filter((q) => q !== e && q.hp > 0 && hyp(q.x - e.x, q.y - e.y) < 9 * T).sort((a, b) => hyp(a.x - e.x, a.y - e.y) - hyp(b.x - e.x, b.y - e.y))[0];
        if (o) { e.a = Math.atan2(o.y - e.y, o.x - e.x); if (e.cd <= 0 && los(M, e.x, e.y, o.x, o.y)) eShoot(W, M, e, e.a, o); else moveE(W, M, e, Math.cos(e.a), Math.sin(e.a), dt, 0.8); } continue; }
      const see = hos && canSeeP(W, M, e), dP = hyp(P.x - e.x, P.y - e.y);
      if (hos && e.st < 2) {
        if (see) e.sus += dt * (1.6 - dP / (12 * T)) * (P.cro ? 0.6 : 1) * (e.lv >= 3 ? 1.3 : 1);
        else if (P.noise && dP < P.noise * T) e.sus += dt * 1.2;
        else e.sus = Math.max(0, e.sus - dt * 0.25);
        if (e.sus > 0.35) { e.st = 1; e.a = Math.atan2(P.y - e.y, P.x - e.x); }
        if (e.sus >= 1) { e.st = 2; e.lx = P.x; e.ly = P.y; e.lt = 0; ev(W, { k: 'alert', x: e.x, y: e.y }); W.en.forEach((q) => { if (q.grp === e.grp && q.hp > 0 && q.st < 2 && hyp(q.x - e.x, q.y - e.y) < 9 * T) { q.st = 2; q.lx = P.x; q.ly = P.y; q.lt = 1; } }); }
      }
      if (!hos && e.st === 2 && !e.cf) { e.st = 0; e.sus = 0; }
      if (e.st === 2 && hos) {
        if (see) { e.lx = P.x; e.ly = P.y; e.lt = 0; } else e.lt += dt;
        const aim = Math.atan2(e.ly - e.y, e.lx - e.x);
        e.a = aim;
        const W0 = WB[e.w], melee = !W0;
        if (E.fix) { if (see && e.cd <= 0 && dP < 16 * T) eShoot(W, M, e, aim); continue; }
        if (melee) {
          if (dP < 1.3 * T && see) { if (e.cd <= 0) { e.cd = E.lunge ? 0.6 : 0.8; dmgPlayer(W, M, MB[e.w].dmg * 0.7 * (1 + (e.lv - 1) * 0.2), e); ev(W, { k: 'swing', x: e.x, y: e.y, a: aim }); } }
          else if (E.lunge && see && dP < 4.5 * T && dP > 1.8 * T && (e.lc || 0) <= W.t) { e.lc = W.t + (E.boss ? 2.2 : 3.5); e.dsh = 0.28; e.dhit = 0; const l = dP || 1; e.dvx = (P.x - e.x) / l; e.dvy = (P.y - e.y) / l; ev(W, { k: 'lunge', x: e.x, y: e.y, a: aim }); }
          else chase(W, M, e, dt, see, 1.15);
        } else {
          const pref = (e.w === 'sg' ? 3.5 : 6) * T;
          if (see && dP < W0.rng * T) {
            if (E.snp) { if (e.cd <= 0 && e.jm <= 0) { e.aimT = (e.aimT || 0) + dt; if (e.aimT > 1.05) { eShoot(W, M, e, aim); e.aimT = 0; } } }
            else if (e.cd <= 0 && e.jm <= 0) eShoot(W, M, e, aim);
            if (E.net && dP < 12 * T) { e.hk = (e.hk == null ? 3 : e.hk) - dt; if (e.hk <= 0 && !(e.up > 0)) { e.up = 2.4; ev(W, { k: 'upload', x: e.x, y: e.y }); } }
            if (E.boss && e.ph2 && (e.gt -= dt) <= 0) { e.gt = 6; for (let k = -1; k <= 1; k++) { const a = aim + k * 0.35, d = Math.min(dP, 8 * T); W.bul.push({ x: e.x, y: e.y, vx: Math.cos(a) * 420, vy: Math.sin(a) * 420, l: d / 420, d: 40, o: e.id, gren: 1 }); } ev(W, { k: 'shot', x: e.x, y: e.y, a: aim, w: 'gren' }); }
            if (!E.snp || e.cd > 0) { const side = Math.sin(W.t * 1.3 + e.id) > 0 ? 1 : -1, px = -Math.sin(aim) * side, py = Math.cos(aim) * side;
              const fwd = dP > pref ? 0.7 : dP < pref * 0.5 ? -0.7 : 0;
              moveE(W, M, e, Math.cos(aim) * fwd + px * 0.6, Math.sin(aim) * fwd + py * 0.6, dt, E.snp ? 0.4 : 0.7); }
          } else { e.aimT = 0; chase(W, M, e, dt, see, 1); }
          if (e.up > 0) { if (!see || e.bl > 0) { e.up = 0; e.hk = 4; } else { e.up -= dt; if (e.up <= 0) { e.hk = 9; P.burn = 3; P.ram = Math.max(0, P.ram - 4); ev(W, { k: 'phack', x: e.x, y: e.y }); msg(W, '해킹당했어요! 몸이 타들어 가요 (적 해커를 시야에서 끊으면 막혀요)', '#ff4fa3'); } } }
        }
        if (e.lt > 9) { e.st = 1; e.sus = 0.5; e.lt = 0; }
      } else if (e.st === 1) { e.sus -= dt * 0.15; if (e.sus <= 0) e.st = 0; moveE(W, M, e, 0, 0, dt, 0); }
      else if (!E.fix) { // 순찰
        if (e.wt <= 0) { e.wt = 3 + R() * 4; const p = walkNear(M, e.px, e.py, 3); e.tx = p.x; e.ty2 = p.y; }
        const dx = e.tx - e.x, dy = e.ty2 - e.y, l = hyp(dx, dy);
        if (l > 8) { moveE(W, M, e, dx / l, dy / l, dt, 0.45); e.a = Math.atan2(dy, dx); }
      } else e.a += dt * 0.6;
    }
  }
  function chase(W, M, e, dt, see, sp) {
    const P = W.p;
    if (see || hyp(e.lx - e.x, e.ly - e.y) < 3 * T) { const dx = e.lx - e.x, dy = e.ly - e.y, l = hyp(dx, dy) || 1; if (l > 20) moveE(W, M, e, dx / l, dy / l, dt, sp); return; }
    const f = W._fl && flowDir(W._fl, e.x, e.y);
    if (f && e.lt < 9) moveE(W, M, e, f.x, f.y, dt, sp);
  }
  function moveE(W, M, e, dx, dy, dt, sp) {
    const E = EN[e.ty], v = E.sp * sp * dt * (e.slw > 0 ? 0.3 : 1), nx = e.x + dx * v, ny = e.y + dy * v, r = E.r - 1;
    if (free(M, nx, e.y, r, E.fly)) e.x = nx; if (free(M, e.x, ny, r, E.fly)) e.y = ny;
  }
  function eShoot(W, M, e, aim, tgt) {
    const B = WB[e.w]; if (!B) return;
    if (e.mag <= 0) { if (!(e.rl > 0)) e.rl = B.rl * 1.3; return; }
    e.mag--; e.cd = 1 / (B.rof * 0.25) * (1.15 - e.lv * 0.05) + R() * 0.2;
    const spr = B.spr * 1.6 + 0.05 * (4 - e.lv) * 0.5;
    for (let i = 0; i < (B.pel || 1); i++) { const a = aim + (R() - 0.5) * 2 * spr; W.bul.push({ x: e.x + Math.cos(aim) * 14, y: e.y + Math.sin(aim) * 14, vx: Math.cos(a) * 900, vy: Math.sin(a) * 900, l: B.rng * T / 900, d: B.dmg * 0.42 * (1 + (e.lv - 1) * 0.15), o: e.id, cf: tgt ? 1 : 0 }); }
    ev(W, { k: 'shot', x: e.x, y: e.y, a: aim, w: e.w, sup: B.sup });
  }
  function stepBullets(W, M, dt0, sl) {
    const P = W.p, out = [];
    for (const b of W.bul) {
      const dt = b.o === 0 ? dt0 : dt0 * (sl || 1);
      let alive = true; b.l -= dt;
      if (b.hom) { let best = null, bd = 9 * T; for (const e of W.en) { if (e.hp <= 0 || !hostile(W, e)) continue; const d = hyp(e.x - b.x, e.y - b.y); if (d < bd && Math.abs(angD(Math.atan2(b.vy, b.vx), Math.atan2(e.y - b.y, e.x - b.x))) < 0.8) { bd = d; best = e; } }
        if (best) { const a = Math.atan2(b.vy, b.vx), ta = Math.atan2(best.y - b.y, best.x - b.x), na = a + clamp(angD(a, ta), -6 * dt, 6 * dt), sp = hyp(b.vx, b.vy); b.vx = Math.cos(na) * sp; b.vy = Math.sin(na) * sp; } }
      const n = Math.max(1, Math.ceil(hyp(b.vx, b.vy) * dt / 12));
      for (let i = 0; i < n && alive; i++) {
        b.x += b.vx * dt / n; b.y += b.vy * dt / n;
        if (BLOCKB[tAt(M, Math.floor(b.x / T), Math.floor(b.y / T))]) { alive = false; if (b.gren) boom(W, M, b.x - b.vx * dt / n, b.y - b.vy * dt / n, b.d, b.o); else ev(W, { k: 'spark', x: b.x, y: b.y }); break; }
        if (b.o === 0) {
          for (const e of W.en) { if (e.hp <= 0 || (b.hitE && b.hitE.indexOf(e.id) >= 0) || (e.id !== b.pv && !b.gren && !hostile(W, e))) continue; if (hyp(e.x - b.x, e.y - b.y) < EN[e.ty].r + 3) { if (b.gren) { boom(W, M, b.x, b.y, b.d, 0); alive = false; break; } W.st.hits++; const shd = EN[e.ty].shd && !(e.stn > 0) && !(e.bl > 0) && Math.abs(angD(e.a, Math.atan2(-b.vy, -b.vx))) < 0.95; if (shd) ev(W, { k: 'spark', x: b.x, y: b.y }); dmgEnemy(W, M, e, b.d * (shd ? 0.2 : 1), 'p', { cr: b.cr && !shd, pierce: b.pc }); if (b.pc) { (b.hitE = b.hitE || []).push(e.id); } else { alive = false; break; } } }
          if (alive) for (const c of W.civ) if (c.hp > 0 && hyp(c.x - b.x, c.y - b.y) < 10) { hitCiv(W, M, c, b.d, 0); alive = false; break; }
        } else {
          if (b.cf) { for (const e of W.en) if (e.id !== b.o && e.hp > 0 && hyp(e.x - b.x, e.y - b.y) < EN[e.ty].r + 2) { dmgEnemy(W, M, e, b.d, 'e'); alive = false; break; } }
          else if (!P.dead && hyp(P.x - b.x, P.y - b.y) < 12) { dmgPlayer(W, M, b.d, { x: b.x - b.vx * 0.05, y: b.y - b.vy * 0.05 }); alive = false; }
        }
      }
      if (alive && b.l <= 0 && b.gren) { boom(W, M, b.x, b.y, b.d, b.o); alive = false; }
      if (alive && b.l > 0) out.push(b);
    }
    W.bul = out;
  }
  function stepCivs(W, M, dt) {
    const P = W.p;
    for (const c of W.civ) {
      if (c.hp <= 0) continue; c.fl -= dt;
      let dx = c.tx - c.x, dy = c.ty - c.y, l = hyp(dx, dy), sp = 45;
      if (c.fl > 0) { dx = c.x - P.x; dy = c.y - P.y; l = hyp(dx, dy) || 1; sp = 120; }
      else if (l < 6) { // 다음 목적지: 인도 위 가까운 곳
        for (let k = 0; k < 8; k++) { const a = R() * 6.28, d = 2 + R() * 6, x = c.x + Math.cos(a) * d * T, y = c.y + Math.sin(a) * d * T, t = tAt(M, Math.floor(x / T), Math.floor(y / T)); if ((t === 1 || t === 7) && los(M, c.x, c.y, x, y) && distAt(x, y) === c.d) { c.tx = x; c.ty = y; break; } }
        continue;
      }
      const nx = c.x + dx / l * sp * dt, ny = c.y + dy / l * sp * dt;
      if (free(M, nx, c.y, 8)) c.x = nx; else c.tx = c.x; if (free(M, c.x, ny, 8)) c.y = ny; else c.ty = c.y;
    }
  }

  // ═════════ 회로 침투 (해킹 미니게임) ═════════
  const CODES = ['1C', '55', 'BD', 'E9', '7A', 'FF'];
  function breachNew(lv, tech) {
    const n = 5, nc = lv >= 3 ? 6 : 5, g = [];
    for (let i = 0; i < n * n; i++) g.push(CODES[Math.floor(R() * nc)]);
    const buf = 5 + Math.floor(tech / 4) + (lv <= 1 ? 1 : 0);
    // 풀 수 있는 경로를 먼저 만들고 첫 줄 순서를 그 경로에서 뽑는다
    const path = []; let mode = 'r', line = 0; const used = new Set();
    for (let k = 0; k < buf; k++) { const opts = []; for (let j = 0; j < n; j++) { const i = mode === 'r' ? line * n + j : j * n + line; if (!used.has(i)) opts.push(i); } if (!opts.length) break; const i = pick(opts); used.add(i); path.push(i); if (mode === 'r') { mode = 'c'; line = i % n; } else { mode = 'r'; line = (i / n) | 0; } }
    const len0 = lv >= 3 ? 4 : 3, st0 = Math.floor(R() * Math.max(1, Math.min(2, path.length - len0 + 1)));
    const seqs = [path.slice(st0, st0 + len0).map((i) => g[i])];
    if (lv >= 1) seqs.push(Array.from({ length: 2 }, () => CODES[Math.floor(R() * nc)]));
    if (lv >= 2) seqs.push(Array.from({ length: 3 }, () => CODES[Math.floor(R() * nc)]));
    return { g, n, seqs, buf: [], max: buf, used: [], mode: 'r', line: 0, done: seqs.map(() => 0), tl: 16 + tech * 2 + (lv <= 1 ? 4 : 0), over: 0 };
  }
  function breachPick(B, i) {
    if (B.over) return false;
    const r = (i / B.n) | 0, c = i % B.n;
    if (B.used.indexOf(i) >= 0) return false;
    if (B.mode === 'r' ? r !== B.line : c !== B.line) return false;
    B.used.push(i); B.buf.push(B.g[i]);
    if (B.mode === 'r') { B.mode = 'c'; B.line = c; } else { B.mode = 'r'; B.line = r; }
    const s = B.buf.join(' ');
    B.seqs.forEach((q, k) => { if (!B.done[k] && (' ' + s + ' ').indexOf(' ' + q.join(' ') + ' ') >= 0) B.done[k] = 1; });
    if (B.buf.length >= B.max || B.done.every((x) => x)) B.over = 1;
    return true;
  }
  function breachSolve(B) { // 자동 조종용: 깊이 우선으로 가장 많이 푸는 순서
    let best = null, bs = -1;
    const rec = (S, seq) => {
      const sc = S.done.reduce((a, b, k) => a + b * (k === 0 ? 10 : 1), 0);
      if (sc > bs || (sc === bs && best && seq.length < best.length)) { bs = sc; best = seq.slice(); }
      if (S.over || seq.length >= S.max) return;
      for (let j = 0; j < S.n; j++) { const i = S.mode === 'r' ? S.line * S.n + j : j * S.n + S.line; if (S.used.indexOf(i) >= 0) continue; const C = JSON.parse(JSON.stringify(S)); breachPick(C, i); seq.push(i); rec(C, seq); seq.pop(); }
    };
    rec(JSON.parse(JSON.stringify(B)), []);
    return best || [];
  }

  // ═════════ 상점 ═════════
  const priceMul = (W, fa) => (fa && W.rep[fa] >= 30 ? 0.88 : fa && W.rep[fa] <= -10 ? 1.25 : 1);
  function shopStock(W, n) {
    const key = n.id, win = Math.floor(W.t / 600), S = W.shop[key];
    if (S && S.w === win) return S.it;
    const lv = Math.max(1, DIST[n.d].lv + (W.q.m >= 5 ? 1 : 0)), it = [];
    if (n.kind === 'gun') { for (let k = 0; k < 5; k++) it.push(rollGun(Math.min(3, lv), 0.15)); it.push(mkMel(pick(['blade', 'baton', 'knife']), rollRar(lv))); it.push({ id: IID++, k: 'a', b: pick(['coat', 'vest', 'nano']), r: rollRar(lv) }); }
    else if (n.kind === 'clinic') { const ks = Object.keys(CW).filter((k) => n.id === 'doc2' ? true : !CW[k].il); ks.sort(() => R() - 0.5); ks.slice(0, n.id === 'doc2' ? 9 : 8).forEach((k) => it.push({ id: IID++, k: 'c', b: k })); }
    else { ['jam', 'conf', 'ping', 'wipe', 'burn', 'crip'].concat(W.q.m >= 5 ? ['reb'] : []).forEach((k) => { if (W.p.qh.indexOf(k) < 0) it.push({ id: IID++, k: 'h', b: k }); }); }
    W.shop[key] = { w: win, it };
    return it;
  }
  function buyPrice(W, n, it) { return Math.round(itVal(it) * priceMul(W, n.fa)); }
  const sellPrice = (it) => Math.max(5, Math.round(itVal(it) * 0.35));
  function buy(W, n, it) {
    const p = buyPrice(W, n, it); if (W.p.cr < p) return '크레딧이 모자라요';
    if (it.k === 'c') { const sl = CW[it.b].sl; const old = W.p.cw[sl]; W.p.cw[sl] = it.b; recalc(W); if (W.p.hum > W.p.humMax) W.p.hum = W.p.humMax; W.p.hum = Math.min(W.p.hum, W.p.humMax); if (old) msg(W, CW[old].nm + ' 제거(반값 보상 +' + Math.round(CW[old].val / 2) + ')', '#c8d0e0'), W.p.cr += Math.round(CW[old].val / 2); }
    else if (it.k === 'h') W.p.qh.push(it.b);
    else if (!giveItem(W, it, true)) return '가방이 가득 찼어요';
    W.p.cr -= p; const S = W.shop[n.id]; if (S) S.it = S.it.filter((q) => q !== it);
    ev(W, { k: 'buy' });
    return null;
  }
  function buySimple(W, n, kind) { // 탄·치료제·RAM 충전제·인간성 상담
    const P = W.p, m = priceMul(W, n.fa);
    const cost = Math.round((CON[kind] ? CON[kind].val : kind === 'therapy' ? 400 : AMMO[kind].val) * m);
    if (P.cr < cost) return '크레딧이 모자라요';
    if (kind === 'therapy') { if (P.hum >= P.humMax) return '인간성이 이미 가득해요'; P.hum = Math.min(P.humMax, P.hum + 10); }
    else if (CON[kind]) P[kind]++;
    else P.am[kind] += AMMO[kind].n;
    P.cr -= cost; ev(W, { k: 'buy' }); return null;
  }
  function sell(W, it) { const i = W.p.inv.indexOf(it); if (i < 0 || it.k === 'q') return; W.p.inv.splice(i, 1); W.p.cr += sellPrice(it); ev(W, { k: 'coin' }); }
  function equip(W, it, slot) { // slot: 0/1 총, 'm' 근접, 'a' 옷
    const P = W.p, i = P.inv.indexOf(it); if (i < 0) return;
    P.inv.splice(i, 1);
    if (it.k === 'w') { const s = slot === 1 || (slot == null && P.g[0] && !P.g[1]) ? 1 : 0; const old = P.g[s]; P.g[s] = it; if (old) { P.inv.push(old); } P.mag[s] = 0; P.cur = s; P.rl = 0; reload(W); }
    else if (it.k === 'm') { if (P.m) P.inv.push(P.m); P.m = it; }
    else if (it.k === 'a') { if (P.ar) P.inv.push(P.ar); P.ar = it; }
    recalc(W);
  }
  function autoEquip(W) { // 자동 조종: 더 센 총으로
    const P = W.p, score = (it) => { const s = wStat(it); return s.dmg * s.pel * s.rof * (1 - s.spr); };
    for (const it of P.inv.filter((q) => q.k === 'w')) { for (let s = 0; s < 2; s++) if (!P.g[s] || score(it) > score(P.g[s]) * 1.15) { if (P.inv.indexOf(it) >= 0) equip(W, it, s); break; } }
    for (const it of P.inv.filter((q) => q.k === 'a')) if (!P.ar || ARM[it.b].ar > ARM[P.ar.b].ar) equip(W, it, 'a');
    // 팔 거 팔기 (가방 25칸 넘으면 싼 것부터)
  }

  // ═════════ 임무·이야기 ═════════
  const bldOf = (M, role, k) => M.blds[(M.pos[role] || [0])[k || 0]];
  const siteOf = (W, M, role) => { const b = bldOf(M, role); return floorIn(M, b, null, true); };
  const LEAD = { ak: 'akb', nd: 'ndb', ash: 'ashb', gh: 'ghb' };
  const FIN = {
    ak: { role: 'node', ef: 'gh', boss: '백색 소음', txt: '하층 유령망 백업 노드: 수비대를 쓰러뜨리고 서버 단말기를 지우기', term: 2 },
    gh: { role: 'uplink', ef: 'ak', boss: '송신탑 수호기', txt: '아크라 송신탑: 경비를 뚫고 송신 단말기 장악', term: 3 },
    nd: { role: 'auction', ef: 'ak', boss: '유리탑 해결사', txt: '항만 경매장: 아크라 습격대 세 차례 막기', term: 0 },
    ash: { role: 'plant', ef: 'ak', boss: '정수 공장 관리기', txt: '정수 공장: 아크라 경비를 몰아내고 밸브 단말기 열기', term: 2 },
  };
  function spawnAt(W, M, b, fa, n, tag, o) {
    const out = [];
    const p0 = floorIn(M, b, null, true);
    const g = spawnGroup(W, M, fa, p0.x, p0.y, Math.min(n, 3), Object.assign({ hos: true, q: tag, elite: true }, o || {}));
    out.push(...g);
    for (let k = 3; k < n; k++) { const p = floorIn(M, b); out.push(spawnEnemy(W, M, pick(poolFor(fa, (o && o.lv) || 2)), fa, p.x, p.y, Object.assign({ hos: true, q: tag, grp: g[0].grp }, o || {}))); }
    return out;
  }
  function spawnFinal(W, M, fa) {
    const F = FIN[fa], b = bldOf(M, F.role), lv = 3;
    if (fa === 'nd') { W.q.f.wave = 1; spawnWave(W, M, 1); return; }
    spawnAt(W, M, b, F.ef, 7, 'fin hos', { lv });
    const p = floorIn(M, b, null, true); const bo = spawnEnemy(W, M, 'boss', F.ef, p.x + 10, p.y + 10, { lv, hos: true, q: 'fin hos', nm: F.boss }); bo.st = 0;
    if (fa === 'gh') for (let k = 0; k < 2; k++) { const q = floorIn(M, b); spawnEnemy(W, M, 'turret', 'ak', q.x, q.y, { hos: true, q: 'fin hos', lv }); }
    const tp = floorIn(M, b); W.term.push({ id: W.eid++, x: tp.x, y: tp.y, lv: F.term, kind: 'fin', done: 0 });
  }
  function spawnWave(W, M, n) {
    const b = bldOf(M, 'auction'), c = floorIn(M, b, null, true);
    const p = walkNear(M, c.x, c.y, 12);
    const g = spawnGroup(W, M, 'ak', p.x, p.y, n === 3 ? 3 : 5, { hos: true, q: 'fin hos', lv: 3, elite: n >= 2 });
    g.forEach((e) => { e.st = 2; e.lx = c.x; e.ly = c.y; e.lt = 3; });
    if (n === 3) { const bo = spawnEnemy(W, M, 'boss', 'ak', p.x, p.y, { lv: 3, hos: true, q: 'fin hos', nm: FIN.nd.boss }); bo.st = 2; bo.lx = c.x; bo.ly = c.y; }
    msg(W, '습격 ' + n + '/3 — 아크라가 몰려와요!', '#ff4fa3');
  }
  const Q = {
    onKill(W, M, e, o) {
      if (e.ty === 'hound') { msg(W, '은빛 사냥개가 쓰러졌어요 — 그날 밤 당신을 쏜 자예요', '#ffd040'); W.q.f.hound = 1; }
      if (EN[e.ty].boss) gainLore(W);
      if (e.q && e.q.indexOf('sq_cop') >= 0 && e.nm === '검은 배지 반장') { const S = sq(W, 'cop'); S.f[o && o.nl ? 'caught' : 'killed'] = 1; }
      if (e.ty === 'psycho' && e.q && e.q.indexOf('sq_psy') >= 0) { const S = sq(W, 'psy'); S.f[o && o.nl ? 'saved' : 'killed'] = 1; S.f.done = 1; S.st = 2; msg(W, o && o.nl ? '쇳날 광인을 살려서 제압했어요 → 뒷골목 시술사에게' : '쇳날 광인이 죽었어요 → 뒷골목 시술사에게', '#c070ff'); ev(W, { k: 'quest' }); }
    },
    tick(W, M, dt) {
      const q = W.q;
      if ((W._qt = (W._qt || 0) + dt) < 0.25) return; W._qt = 0;
      const alive = (tag) => W.en.filter((e) => e.hp > 0 && e.q && e.q.indexOf(tag) >= 0).length;
      if (q.m === 4 && !alive('m4')) { q.m = 5; addRep(W, 'gh', 5, '은신처 지킴'); addXP(W, 80); msg(W, '기습대를 물리쳤어요 → 중개인에게 돌아가요', '#ffd040'); ev(W, { k: 'quest' }); }
      if (q.m === 7) {
        const side = q.f.side;
        if (side === 'nd') { if (!alive('fin')) { if (q.f.wave < 3) { q.f.wave++; spawnWave(W, M, q.f.wave); } else { q.m = 8; } } }
        else { const t = W.term.find((x) => x.kind === 'fin'); if (!alive('fin') && t && t.done) q.m = 8; else if (t && t.done && !q.f.td) { q.f.td = 1; msg(W, '단말기 완료 — 남은 적을 정리해요', '#ffd040'); } }
        if (q.m === 8) { addXP(W, 250); msg(W, '임무 완수! ' + npcById(W, LEAD[side]).nm + '에게 보고해요', '#ffd040'); ev(W, { k: 'quest' }); }
      }
      for (const j of q.jobs) {
        if (j.st) continue;
        if (j.ty === 'bounty') { const e = W.en.find((x) => x.id === j.tid); if (!e || e.hp <= 0) jobDone(W, j); }
        if (j.ty === 'hack') { const t = W.term.find((x) => x.id === j.tid); if (t && t.done) jobDone(W, j); }
      }
      q.jobs = q.jobs.filter((j) => !j.st);
      sideTick(W, M);
      evtTick(W, M);
    },
    objs(W) {
      const M = genMap(W.seed), q = W.q, o = [], N = (id) => npcById(W, id);
      const at = (n) => (n ? { x: n.x, y: n.y } : {});
      if (q.m === 0) o.push(Object.assign({ t: '의체 시술사와 이야기하기', h: '노란 ◆ 표시가 뜬 사람 곁으로 가서 [E]를 눌러요', main: 1 }, at(N('doc'))));
      if (q.m === 1) o.push(Object.assign({ t: '술집의 붉은 렌즈 중개인 만나기', h: '시술소를 나와 화면 가장자리의 노란 화살표를 따라가요', main: 1 }, at(N('fix'))));
      if (q.m === 2) { const t = W.term.find((x) => x.kind === 'm2'); o.push(Object.assign({ t: '항만 야적장의 금고 단말기 열기', h: '단말기 앞에서 [E] → 회로 침투 퍼즐. 경비 5명이 지켜요 — 앉아서(C) 몰래 가거나 싸워서 뚫어요', main: 1 }, t ? { x: t.x, y: t.y } : {})); o.push(Object.assign({ t: '(다른 길) 바늘회 두목 「은침」과 코어 거래', h: '돈(1,500₵)·평판·힘으로 얻을 수 있어요', main: 1, sub: 1 }, at(N('ndb')))); }
      if (q.m === 3) o.push(Object.assign({ t: '하층 슬럼의 거울가면 해커에게 코어 맡기기', h: '코어엔 암호가 걸려 있어요. 유령망 은신처로 — 멀면 지하철역(M)에서 [E]', main: 1 }, at(N('ghb'))));
      if (q.m === 4) { const es = W.en.filter((e) => e.hp > 0 && e.q && e.q.indexOf('m4') >= 0); o.push(Object.assign({ t: '은신처를 덮친 아크라 기습대 막기 (남은 적 ' + es.length + ')', h: '상자·벽 뒤에 숨어 싸워요. 체력이 낮으면 [H] 치료 주사', main: 1 }, es[0] ? { x: es[0].x, y: es[0].y } : {})); }
      if (q.m === 5) o.push(Object.assign({ t: '붉은 렌즈 중개인에게 돌아가기', h: '네온 시장 술집. 지하철(M)을 타면 빨라요', main: 1 }, at(N('fix'))));
      if (q.m === 6) { o.push({ t: '누구와 손잡을지 고르기 — 세력 평판 20 이상 필요', h: '평판이 모자라면 그 세력 두목에게 「일거리」를 받아 끝내요(+12씩)', main: 1 }); FKEYS.forEach((f) => o.push(Object.assign({ t: FA[f].nm + ' 두목 · 평판 ' + W.rep[f] + (W.rep[f] < 20 ? ' / 20' : ' ✓ 가능'), main: 1, sub: 1, c: FA[f].c }, at(N(LEAD[f]))))); }
      if (q.m === 7) { const F = FIN[q.f.side], b = bldOf(M, F.role), t = W.term.find((x) => x.kind === 'fin' && !x.done);
        const left = W.en.filter((e) => e.hp > 0 && e.q && e.q.indexOf('fin') >= 0).length;
        o.push({ t: F.txt + (q.f.side === 'nd' ? ' (' + (q.f.wave || 1) + '/3)' : '') + ' · 남은 적 ' + left, h: q.f.side === 'nd' ? '경매장을 지키며 세 번의 습격을 막아요' : '현장 단말기를 [E]로 뚫고, 남은 적까지 정리해요', main: 1, x: t ? t.x : ((b.x0 + b.x1) / 2) * T, y: t ? t.y : ((b.y0 + b.y1) / 2) * T }); }
      if (q.m === 8) o.push(Object.assign({ t: npcById(W, LEAD[q.f.side]).nm + '에게 보고하기', h: '보고하면 마지막 선택이 나와요. 고른 답으로 결말이 정해져요', main: 1 }, at(N(LEAD[q.f.side]))));
      for (const j of q.jobs) o.push({ t: '[일거리] ' + j.nm, h: ({ bounty: '표시된 현상범을 쓰러뜨려요', hack: '표시된 건물의 단말기를 [E]로 뚫어요', courier: '봉인된 소포를 받을 사람에게 [E]로 건네요', rescue: '약탈자를 물리치고 붙잡힌 사람에게 [E]' })[j.ty] + ' · 의뢰: ' + (j.fa ? FA[j.fa].nm : '중개인'), x: j.x, y: j.y, c: j.fa ? FA[j.fa].c : '#ffd040', job: 1 });
      sideObjs(W, o);
      if (W.evt) { const E = W.evt, e = W.en.find((x) => x.hp > 0 && x.q && x.q.indexOf(E.tag) >= 0); o.push({ t: EVT[E.ty].t, h: EVT[E.ty].h, x: e ? e.x : E.x, y: e ? e.y : E.y, c: '#ffa040', evt: 1 }); }
      return o;
    },
  };
  // ── 거리 사건: 몇 분마다 지금 구역 근처에서 작은 일이 터진다(선택) ──
  const EVT = {
    mug: { nm: '노상강도', t: '[사건] 행인을 터는 강도들 쫓아내기', h: '근처 골목에서 비명이 들려요. 강도를 쫓아내면 인간성 +2와 사례금' },
    drop: { nm: '추락한 보급 드론', t: '[사건] 추락한 보급 드론 챙기기', h: '드론이 떨어진 곳을 누군가 지키고 있어요. 물리치면 좋은 물건이 남아요' },
    hunt: { nm: '길거리 현상범', t: '[사건] 길거리 현상범 잡기', h: '현상금이 걸린 사이보그가 이 구역에 나타났어요' },
  };
  function evtTick(W, M) {
    const P = W.p, E = W.evt;
    if (E) {
      const alive = W.en.some((e) => e.hp > 0 && e.q && e.q.indexOf(E.tag) >= 0);
      if (!alive) { W.evt = null; W.evN = (W.evN || 0) + 1; addXP(W, 50);
        if (E.ty === 'mug') { addCr(W, 200 + 60 * E.lv, '행인의 사례'); P.hum = Math.min(P.humMax, P.hum + 2); msg(W, '강도를 쫓아냈어요 · 인간성 +2', '#7dff9a'); }
        if (E.ty === 'drop') { W.lo.push({ id: W.eid++, x: E.x, y: E.y, it: rollGun(E.lv, 0.35) }); W.lo.push({ id: W.eid++, x: E.x + 14, y: E.y, it: { id: IID++, k: 'x', b: 'med' } }); msg(W, '보급 상자가 열렸어요', '#ffd040'); }
        if (E.ty === 'hunt') { addCr(W, 450 + 150 * E.lv, '현상금'); gainLore(W); }
        ev(W, { k: 'quest' }); return; }
      if (W.t - E.t0 > 240 || hyp(E.x - P.x, E.y - P.y) > 60 * T) { W.en.forEach((e) => { if (e.q && e.q.indexOf(E.tag) >= 0) e.hp = 0; }); W.evt = null; }
      return;
    }
    if (W.evT == null) W.evT = W.t + 150;
    if (W.t < W.evT || P.dead || W.q.m === 4 || W.q.m === 7 || P.d === 1 && W.q.m < 2) return;
    W.evT = W.t + 170 + R() * 120;
    const ty = pick(['mug', 'drop', 'hunt']), d = P.d != null ? P.d : 1, lv = Math.max(1, DIST[d].lv);
    let p = walkNear(M, P.x, P.y, 14); for (let k = 0; k < 16 && (hyp(p.x - P.x, p.y - P.y) < 8 * T || distAt(p.x, p.y) !== d); k++) p = walkNear(M, P.x, P.y, 16);
    const tag = 'evt' + W.eid + ' hos', fa = ty === 'drop' && DIST[d].fa && DIST[d].fa !== 'raid' ? DIST[d].fa : 'raid';
    if (ty === 'mug') spawnGroup(W, M, 'raid', p.x, p.y, 3, { hos: true, q: tag, lv });
    if (ty === 'drop') spawnGroup(W, M, fa, p.x, p.y, 3, { hos: true, q: tag, lv });
    if (ty === 'hunt') spawnEnemy(W, M, 'borg', 'raid', p.x, p.y, { hos: true, q: tag, lv, hm: 1.3, nm: pick(['녹슨 송곳니', '두 얼굴 수집가', '네온 도살자', '빗속의 칼', '전선 목걸이']) });
    W.evt = { ty, x: p.x, y: p.y, tag: tag.split(' ')[0], t0: W.t, lv };
    msg(W, '사건: ' + EVT[ty].nm + ' — 지도에 표시했어요 (무시해도 돼요)', '#ffa040'); ev(W, { k: 'alarm' });
  }
  function jobDone(W, j) {
    j.st = 1; W.st.jobs++; W.q.done++;
    addCr(W, j.rw, '일거리 완료'); addXP(W, 60);
    if (j.fa) { addRep(W, j.fa, 12, j.nm); if (j.vs && FA[j.vs] && W.rep[j.vs] != null) addRep(W, j.vs, -4); }
    if (j.ty === 'rescue') { W.p.hum = Math.min(W.p.humMax, W.p.hum + 5); msg(W, '인간성 +5', '#7dff9a'); }
    ev(W, { k: 'quest' });
  }
  const JOBN = { bounty: '현상금', hack: '자료 빼내기', courier: '배달', rescue: '구출' };
  function makeJob(W, M, fa) {
    const tys = fa === 'ash' || fa === 'gh' || !fa ? ['bounty', 'hack', 'courier', 'rescue'] : ['bounty', 'hack', 'courier'];
    const ty = pick(tys), vs = fa ? pick(FA[fa].riv) : pick(FKEYS);
    let d = ty === 'rescue' ? 5 : DIST.findIndex((D) => D.fa === vs); if (d < 0 || d === 1) d = 5;
    const lv = DIST[d].lv;
    return { id: W.q.jid++, fa, vs: ty === 'rescue' || ty === 'courier' ? null : vs, ty, d, rw: Math.round((250 + 150 * lv) * (ty === 'courier' ? 0.7 : 1) / 10) * 10, nm: JOBN[ty] + ' · ' + DIST[d].nm, st: 0 };
  }
  function startJob(W, M, j) {
    const ds = M.blds.filter((b) => b.d === j.d && !b.role); const b = pick(ds.length ? ds : M.blds.filter((q) => !q.role));
    const p = floorIn(M, b, null, true); j.x = p.x; j.y = p.y;
    const efa = j.ty === 'rescue' ? 'raid' : (j.vs || DIST[j.d].fa || 'raid');
    if (j.ty === 'bounty') { const g = spawnAt(W, M, b, efa, 3, 'job' + j.id + ' hos'); const t = spawnEnemy(W, M, 'borg', efa, p.x, p.y, { hos: true, q: 'job' + j.id + ' hos', grp: g[0].grp, hm: 1.4, nm: pick(['쇳소리 사냥꾼', '검은 팔 해결사', '세 눈 저격수', '녹슨 턱 대장', '번개 손']) }); j.tid = t.id; }
    if (j.ty === 'hack') { spawnAt(W, M, b, efa, 3, 'job' + j.id + ' hos'); const t = { id: W.eid++, x: p.x, y: p.y, lv: DIST[j.d].lv, kind: 'job', done: 0, jid: j.id }; W.term.push(t); j.tid = t.id; }
    if (j.ty === 'courier') { const sw = walkNear(M, p.x, p.y, 3); W.npc.push({ id: 'recv' + j.id, nm: '물건 받을 사람', kind: 'recv', jid: j.id, x: sw.x, y: sw.y, b: b.id, d: j.d, a: 0, look: { sk: '#b08a70', hc: '#202028', hs: 2, ey: '#c8d0e0', ac: '#ffd040', gear: 'none' } }); j.tid = 'recv' + j.id; giveItem(W, { id: IID++, k: 'q', nm: '봉인된 소포' }); }
    if (j.ty === 'rescue') { spawnAt(W, M, b, 'raid', 4, 'job' + j.id + ' hos'); W.npc.push({ id: 'cap' + j.id, nm: '붙잡힌 노동자', kind: 'captive', jid: j.id, x: p.x, y: p.y, b: b.id, d: j.d, a: 0, look: { sk: '#a87a60', hc: '#4a3a2a', hs: 1, ey: '#c8d0e0', ac: '#ffa040', gear: 'none' } }); j.tid = 'cap' + j.id; }
    W.q.jobs.push(j);
    msg(W, '일거리 수락: ' + j.nm, '#ffd040');
  }


  // ═════════ 지금까지의 이야기(일지) · 기록 조각 ═════════
  const STORY = (W) => [
    '총알 세 발을 맞고 네온 시장의 시술소에서 깨어났다. 무슨 일을 하다 맞았는지 기억이 흐릿하다.',
    '시술사 말로는 「붉은 렌즈 중개인」이 나를 업어 와 치료비까지 냈다고 한다. 빚을 졌다. 술집으로 가 봐야 한다.',
    '중개인의 이야기: 사흘 전 나는 그의 의뢰로 검은 데이터 칩 「흑요 코어」를 나르다 항만에서 매복당했다. 칩은 바늘회 금고에 있다. 되찾아야 한다.',
    '코어를 되찾았다. 그런데 기업 군용 암호가 세 겹. 풀 수 있는 건 하층 해커 집단 유령망의 「거울가면」뿐이다.',
    '코어가 열렸다. 아크라의 「정화 계획」 — 10년 동안 하층 수돗물에 사람을 멍하게 만드는 약을 섞어 왔다. 그 순간 아크라의 사냥개들이 은신처를 덮쳤다.',
    (W.q.f.hound ? '기습을 막아 냈다. 기습대를 이끈 「은빛 사냥개」 — 그날 밤 나에게 세 발을 박은 자 — 는 이제 쓰러졌다.' : '기습을 막아 냈다.') + ' 중개인에게 돌아가 다음을 의논해야 한다.',
    '네 세력이 코어를 원한다. 아크라는 침묵의 값을, 유령망은 방송을, 바늘회는 협박을, 잿빛 연합은 깨끗한 물을. 누구와 손잡을지는 내가 정한다 — 평판 20부터.',
    '마지막 일을 맡았다: ' + (W.q.f.side ? FA[W.q.f.side].nm + ' — ' + FIN[W.q.f.side].txt : '') + '.',
    '마지막 일을 끝냈다. 이제 보고하고, 코어를 어떻게 할지 고르는 일만 남았다.',
  ];
  const LORE = [
    ['정수 공사 계약서 (12년 전)', '「하층 정수 시설 민영화 — 낙찰: 아크라 생활설비」. 계약서 맨 아래, 손글씨 메모: 「첨가물 시험은 3구역부터. 주민 고지 불필요.」'],
    ['아크라 내부 메일', '「사냥개 팀장에게. 운반책 처리 완료 확인. 칩은 회수 실패. 바늘회가 먼저 주웠음. 추가 예산 승인.」 보낸 사람: 대외협력실.'],
    ['하층 진료소 기록', '「두통·무기력·기억 흐림 호소 환자, 올해만 4천 명. 원인 불명. 공통점: 하층 수도 사용.」 의사의 메모: 「물을 끓여도 소용없다.」'],
    ['바늘회 장부 한 장', '「흑요 칩 — 감정가 측정 불가. 은침 두목 지시: 팔지 말 것. 아크라가 직접 오게 할 것.」 장부 귀퉁이에 흑요석 그림이 그려져 있다.'],
    ['잿빛 연합 회의록', '「정수 공장 폐쇄 3년째. 기계는 멀쩡하다. 아크라가 문을 걸어 잠갔을 뿐. 위원장: 우리 손으로 다시 돌린다.」'],
    ['유령망 게시판', '「거울가면의 동생, 정화 계획 첫 피해자 중 한 명으로 추정. 3년째 말을 하지 않음.」 아래 수십 개의 답글: 「잊지 않는다.」'],
    ['질서국 무전 기록', '「하층 시위 해산 명령. 발포 허가는 아크라 보안실에서.」 잡음 속 누군가의 목소리: 「…저건 우리 동네잖아.」'],
    ['붉은 렌즈의 낡은 사진', '젊은 중개인과 시술사, 그리고 거울 가면을 쓰지 않은 해커가 웃고 있다. 뒷면: 「하층 3구역, 물맛이 바뀌기 전.」'],
    ['은빛 사냥개 인사 기록', '「전직 질서국 특수대. 하층 진압 작전 후 아크라로 이직. 의수 시술 7회. 인간성 평가: 측정 불가.」'],
    ['첨탑 꼭대기 일정표', '「이사회 정기 회의 — 정화 계획 2단계: 시장 구역 확대. 예상 반발: 낮음. 이유: 1단계 효과.」'],
    ['폐허의 낙서', '벽 가득 같은 문장이 반복된다. 「물을 마시지 마. 물을 마시지 마. 물을 마시지 마.」'],
    ['연구동 접근 기록', '「떨리는 연구원 — 출입 정지. 사유: 정화 계획 원본 무단 열람 시도.」 그 아래 그가 남긴 한 줄: 「서명한 건 나다.」'],
  ];
  function gainLore(W) { const n = W.lore || 0; if (n >= LORE.length) return; W.lore = n + 1; msg(W, '기록 조각 획득: 「' + LORE[n][0] + '」 — 일지에서 읽기', '#ffd040'); }
  // ═════════ 부가 이야기 (판마다 같은 8편, 인물은 역할·모습 이름) ═════════
  // 상태: W.q.s[k] = { st: 단계, f: {} }. 대화는 DLG['s_' + k]의 노드 's' + 단계.
  const SIDE = {
    nood: { nm: '국수집의 빚', d: 1, who: '국수 노점 주인', look: { sk: '#d8b090', hc: '#303030', hs: 1, ey: '#ffd040', ac: '#ff8040', gear: 'none' }, tz: '바늘회 수금원에게 시달리는 노점. 싸우거나, 갚거나, 말로 풀거나.' },
    whis: { nm: '유리탑의 내부 고발자', d: 0, who: '떨리는 연구원', look: { sk: '#e0c0a8', hc: '#8a8a9a', hs: 5, ey: '#4fd8ff', ac: '#e8e8f0', gear: 'visor' }, tz: '아크라 연구동의 원본 기록. 누구 손에 넘길지가 결말을 바꿔요.' },
    stow: { nm: '컨테이너 속 목소리', d: 2, who: '갇힌 밀항자', look: { sk: '#a87a60', hc: '#4a3a2a', hs: 4, ey: '#c8d0e0', ac: '#ff6f9e', gear: 'none' }, tz: '팔려 갈 사람들. 문을 열지, 바늘회에 알릴지.' },
    arena: { fin: 5, nm: '녹슨 투기장', d: 3, who: '투기장 진행자', look: { sk: '#b08060', hc: '#ff8040', hs: 3, ey: '#ffa040', ac: '#ffa040', gear: 'scar' }, tz: '세 판을 버티면 상금과 공장 창고의 물건.' },
    drone: { nm: '추락한 배달 드론', d: 4, who: '고물상 견습생', look: { sk: '#c09070', hc: '#2a5a4a', hs: 8, ey: '#7dff9a', ac: '#7dff9a', gear: 'goggle' }, tz: '폐허에 떨어진 드론의 블랙박스를 찾아 줘요.' },
    psy: { nm: '망가진 거울', d: 4, who: '뒷골목 시술사', giver: 'doc2', tz: '폐허에서 날뛰는 사이버정신증 환자. 죽이지 않고 데려올 수 있을까. (3장부터)' },
    bot: { nm: '길 잃은 안내 로봇', d: 1, who: '고장 난 안내 로봇', look: { sk: '#8a94a8', hc: '#3a4458', hs: 5, ey: '#4fd8ff', ac: '#4fd8ff', gear: 'visor' }, tz: '기억 모듈을 뜯긴 시장 안내 로봇. 기억을 찾아 준 뒤, 어떻게 할지는 당신이 정해요.' },
    cop: { nm: '낡은 배지', d: 2, who: '낡은 배지의 경관', look: { sk: '#b08a70', hc: '#6a6a72', hs: 1, ey: '#8fa8ff', ac: '#8fa8ff', gear: 'scar' }, tz: '총을 빼돌리는 부패 반장. 산 채로 잡을까, 끝장낼까.' },
  };
  const SKEYS = Object.keys(SIDE);
  const sq = (W, k) => (W.q.s[k] = W.q.s[k] || { st: 0, f: {} });
  function sideSpot(W, M, d, salt) { // 구역 지하철역 근처 인도, 씨앗에서 결정
    const r = rngOf(W.seed * 31 + salt * 977), m = M.metro[d];
    const cx = m ? m[0] * T + 16 : ((d % 3) + 0.5) * DWT * T, cy = m ? m[1] * T + 16 : (((d / 3) | 0) + 0.5) * DHT * T;
    for (let k = 0; k < 200; k++) { const a = r() * 6.283, q = (3 + r() * 6) * T, x = cx + Math.cos(a) * q, y = cy + Math.sin(a) * q; const t = tAt(M, Math.floor(x / T), Math.floor(y / T)); if ((t === 1 || t === 7) && free(M, x, y, 13) && distAt(x, y) === d) return { x: Math.floor(x / T) * T + 16, y: Math.floor(y / T) * T + 16 }; }
    return walkNear(M, cx, cy, 4, r);
  }
  // 옛 저장(v1)·새 세계 공통: 빠진 필드를 채운다
  function migrate(W, M) {
    const P = W.p;
    if (P.frag == null) P.frag = 1; if (P.bike == null) P.bike = 0; if (P.ride == null) P.ride = 0; P.vx = P.vx || 0; P.vy = P.vy || 0; P.burn = P.burn || 0;
    W.q.s = W.q.s || {}; W.slow = W.slow || 0;
    SKEYS.forEach((k, i) => { const S = SIDE[k]; if (S.giver || W.npc.some((n) => n.side === k)) return; const st = W.q.s[k]; if (st && st.gone) return; const p = sideSpot(W, M, S.d, i + 1); W.npc.push({ id: 'sd_' + k, nm: S.who, kind: 'side', side: k, fa: null, look: S.look, x: p.x, y: p.y, b: -1, d: S.d, a: Math.PI / 2 }); });
    W.v = 2;
  }
  function sideNpcGone(W, k) { W.npc = W.npc.filter((n) => n.side !== k); sq(W, k).gone = 1; }
  function sideStart(W, M, k) {
    const S = sq(W, k), n = npcById(W, 'sd_' + k) || npcById(W, SIDE[k].giver);
    const tag = 'sq_' + k + ' hos';
    if (k === 'nood') { const p = walkNear(M, n.x, n.y, 7); const g = spawnGroup(W, M, 'nd', p.x, p.y, 3, { hos: true, q: tag, lv: 1 }); g[0].nm = '바늘회 수금 대장'; g[0].w = 'knife'; }
    if (k === 'whis') { const bs = M.blds.filter((b) => b.d === 0 && !b.role); const b = bs[Math.floor(rngOf(W.seed + 5)() * bs.length)] || M.blds[0]; spawnAt(W, M, b, 'ak', 4, tag, { lv: 3, elite: false }); const tp = floorIn(M, b, null, true); W.term.push({ id: W.eid++, x: tp.x, y: tp.y, lv: 3, kind: 'side', sk: k, done: 0 }); }
    if (k === 'stow') { const tp = walkNear(M, n.x, n.y, 1.6); W.term.push({ id: W.eid++, x: tp.x, y: tp.y, lv: 2, kind: 'side', sk: k, done: 0 }); const p = walkNear(M, n.x, n.y, 6); spawnGroup(W, M, 'nd', p.x, p.y, 2, { hos: false, lv: 1 }); }
    if (k === 'arena') { sideWave(W, M, 1); }
    if (k === 'drone') { const bs = M.blds.filter((b) => b.d === 5 && !b.role); const b = bs[Math.floor(rngOf(W.seed + 9)() * bs.length)] || M.blds[0]; const p = floorIn(M, b, null, true); spawnAt(W, M, b, 'raid', 4, tag, { lv: 3 }); W.lo.push({ id: W.eid++, x: p.x, y: p.y, it: { id: IID++, k: 'q', nm: '드론 블랙박스', sk: 'drone' } }); S.f.x = p.x; S.f.y = p.y; }
    if (k === 'bot') { const bs = M.blds.filter((b) => b.d === 3 && !b.role); const b = bs[Math.floor(rngOf(W.seed + 17)() * bs.length)] || M.blds[0]; spawnAt(W, M, b, 'raid', 3, tag, { lv: 2, elite: false }); const tp = floorIn(M, b, null, true); W.term.push({ id: W.eid++, x: tp.x, y: tp.y, lv: 2, kind: 'side', sk: k, done: 0 }); }
    if (k === 'cop') { const bs = M.blds.filter((b) => b.d === 5 && !b.role); const b = bs[Math.floor(rngOf(W.seed + 21)() * bs.length)] || M.blds[0]; const g = spawnAt(W, M, b, 'raid', 4, tag, { lv: 3, elite: false }); const p = floorIn(M, b, null, true); const bo = spawnEnemy(W, M, 'shield', 'raid', p.x, p.y, { lv: 3, hos: true, q: tag, grp: g[0].grp, nm: '검은 배지 반장', hm: 2.4 }); bo.st = 0; S.f.x = p.x; S.f.y = p.y; }
    if (k === 'psy') { const bs = M.blds.filter((b) => b.d === 5 && !b.role); const b = bs[Math.floor(rngOf(W.seed + 13)() * bs.length)] || M.blds[0]; const p = floorIn(M, b, null, true); const e = spawnEnemy(W, M, 'psycho', 'raid', p.x, p.y, { lv: 3, hos: true, q: tag, nm: '쇳날 광인' }); e.st = 0; S.f.x = p.x; S.f.y = p.y; }
    S.st = 1; ev(W, { k: 'quest' }); msg(W, '부가 이야기: 「' + SIDE[k].nm + '」', '#c070ff');
  }
  function sideWave(W, M, n) {
    const g = npcById(W, 'sd_arena'); if (!g) return;
    const c = walkNear(M, g.x, g.y, 5), tag = 'sq_arena hos';
    const kinds = n === 1 ? ['raider', 'raider', 'thug'] : n === 2 ? ['blade', 'blade', 'heavy'] : ['borg', 'heavy', 'blade', 'blade'];
    kinds.forEach((ty, i) => { const p = walkNear(M, c.x, c.y, 3); const e = spawnEnemy(W, M, ty, 'raid', p.x, p.y, { lv: 2 + (n >= 2 ? 1 : 0), hos: true, q: tag, grp: 900000 + n }); e.st = 2; e.lx = W.p.x; e.ly = W.p.y; e.lt = 2; if (n === 3 && !i) e.nm = '투기장 챔피언'; });
    msg(W, '투기장 ' + n + '/3 판 — 시작!', '#ffa040'); ev(W, { k: 'alarm' });
  }
  function sideTick(W, M) {
    const alive = (tag) => W.en.some((e) => e.hp > 0 && e.q && e.q.indexOf(tag) >= 0);
    const s = W.q.s;
    if (s.nood && s.nood.st === 1 && !alive('sq_nood')) { s.nood.st = 2; msg(W, '수금원을 쫓아냈어요 → 국수 노점 주인에게', '#c070ff'); ev(W, { k: 'quest' }); }
    if (s.arena && s.arena.st >= 1 && s.arena.st <= 3 && !alive('sq_arena')) { addCr(W, 300 * s.arena.st, '투기장 ' + s.arena.st + '판 승리'); s.arena.st++; if (s.arena.st <= 3) sideWave(W, M, s.arena.st); else { msg(W, '세 판 모두 이겼어요 → 투기장 진행자에게', '#c070ff'); ev(W, { k: 'quest' }); } }
    if (s.drone && s.drone.st === 1 && W.p.inv.some((it) => it.k === 'q' && it.sk === 'drone')) { s.drone.st = 2; msg(W, '블랙박스를 찾았어요 → 고물상 견습생에게', '#c070ff'); ev(W, { k: 'quest' }); }
    if (s.drone && s.drone.st === 1 && !W.p.inv.some((it) => it.k === 'q' && it.sk === 'drone') && !W.lo.some((o) => o.it.sk === 'drone')) W.lo.push({ id: W.eid++, x: s.drone.f.x, y: s.drone.f.y, it: { id: IID++, k: 'q', nm: '드론 블랙박스', sk: 'drone' } });
    if (s.psy && s.psy.st === 1 && !alive('sq_psy') && !s.psy.f.done) { s.psy.f.done = 1; s.psy.st = 2; }
    if (s.cop && s.cop.st === 1 && !W.en.some((e) => e.hp > 0 && e.nm === '검은 배지 반장')) { s.cop.st = 2; if (!s.cop.f.caught) s.cop.f.killed = 1; msg(W, (s.cop.f.caught ? '검은 배지 반장을 산 채로 잡았어요' : '검은 배지 반장이 죽었어요') + ' → 낡은 배지의 경관에게', '#c070ff'); ev(W, { k: 'quest' }); }
  }
  function sideObjs(W, o) {
    const s = W.q.s, N = (k) => npcById(W, 'sd_' + k) || npcById(W, SIDE[k].giver), at = (n) => (n ? { x: n.x, y: n.y } : {}), C = '#c070ff';
    const add = (k, t, pos) => o.push(Object.assign({ t: '[부가] ' + t, c: C, side: 1 }, pos || at(N(k))));
    for (const k of SKEYS) { const S = s[k]; if (!S || !S.st || S.gone) continue; const st = S.st;
      if (k === 'nood') { if (st === 1) { const e = W.en.find((q) => q.hp > 0 && q.q && q.q.indexOf('sq_nood') >= 0); add(k, '바늘회 수금원 쫓아내기', e ? { x: e.x, y: e.y } : null); } else if (st === 2) add(k, '국수 노점 주인에게 알리기'); }
      if (k === 'whis') { const t = W.term.find((q) => q.kind === 'side' && q.sk === k); if (st === 1) add(k, '아크라 연구동 단말기에서 원본 기록 빼내기', t ? { x: t.x, y: t.y } : null); else if (st === 2) add(k, '떨리는 연구원에게 기록 전하기'); }
      if (k === 'stow') { const t = W.term.find((q) => q.kind === 'side' && q.sk === k); if (st === 1) add(k, '컨테이너 잠금 단말기 뚫기', t ? { x: t.x, y: t.y } : null); else if (st === 2) add(k, '갇힌 사람들 내보내기'); }
      if (k === 'arena') { if (st >= 1 && st <= 3) { const e = W.en.find((q) => q.hp > 0 && q.q && q.q.indexOf('sq_arena') >= 0); add(k, '투기장 ' + st + '/3 판 버티기', e ? { x: e.x, y: e.y } : null); } else if (st === 4) add(k, '투기장 진행자에게 상금 받기'); }
      if (k === 'drone') { if (st === 1) add(k, '폐허에서 드론 블랙박스 찾기', { x: S.f.x, y: S.f.y }); else if (st === 2) add(k, '고물상 견습생에게 돌려주기'); }
      if (k === 'bot') { const t = W.term.find((q) => q.kind === 'side' && q.sk === k); if (st === 1) add(k, '녹슨 공장 지대 고물상 창고 단말기에서 기억 모듈 찾기', t ? { x: t.x, y: t.y } : null); else if (st === 2) add(k, '안내 로봇에게 기억 모듈 가져가기'); }
      if (k === 'cop') { if (st === 1) { const e = W.en.find((q) => q.hp > 0 && q.nm === '검은 배지 반장'); add(k, '폐허의 검은 배지 반장 잡기 (비살상 마무리 = 산 채로)', e ? { x: e.x, y: e.y } : { x: S.f.x, y: S.f.y }); } else if (st === 2) add(k, '낡은 배지의 경관에게 알리기'); }
      if (k === 'psy') { if (st === 1) { const e = W.en.find((q) => q.hp > 0 && q.ty === 'psycho'); add(k, '쇳날 광인 제압 (비살상 무기로 마무리하면 살아요)', e ? { x: e.x, y: e.y } : { x: S.f.x, y: S.f.y }); } else if (st === 2) add(k, '뒷골목 시술사에게 돌아가기'); }
    }
  }
  const sideEpi = (W) => {
    const s = W.q.s, out = [], f = (k) => (s[k] ? s[k].f : {});
    if (s.nood && s.nood.st >= 3) out.push('국수 노점은 지금도 당신 몫의 그릇을 남겨 둔다.');
    if (f('whis').evid) out.push('연구동 원본 기록은 유령망의 서버에서 하층 곳곳으로 퍼졌다.'); else if (f('whis').sold) out.push('떨리는 연구원은 다시 보이지 않았다. 계좌의 숫자만 남았다.'); else if (f('whis').kept) out.push('떨리는 연구원은 기록을 들고 위층을 떠났다. 언젠가 그가 입을 열 것이다.');
    if (f('stow').freed) out.push('컨테이너에서 나온 사람들은 하층에 작은 수선 가게를 열었다.'); else if (f('stow').sold) out.push('항만의 컨테이너는 오늘도 조용히 실려 나간다.');
    if (s.arena && s.arena.st >= 5) out.push('녹슨 투기장 벽에 당신의 이름 대신 별명이 새겨졌다: 「비 오는 밤의 손님」.');
    if (s.drone && s.drone.st >= 3) out.push('고물상 견습생의 드론이 다시 하층의 약을 나른다.');
    if (f('bot').home) out.push('네온 시장 안내 로봇은 오늘도 비 오는 날 우산 노점을 알려 준다. 당신에게만은 「다시 오셨군요」라고 인사한다.'); else if (f('bot').free) out.push('유령망 신호 속에 이름 없는 목소리 하나가 산다. 길 잃은 사람에게 길을 알려 준다고 한다.'); else if (f('bot').sold) out.push('고물상 진열대에 꺼진 로봇 머리 하나가 아직 팔리지 않고 있다.');
    if (f('cop').caught) out.push('검은 배지 반장의 재판에서 경관 넷이 증언했다. 질서국 배지가 조금 덜 부끄러워졌다.'); else if (f('cop').killed) out.push('검은 배지 반장의 자리는 금세 다른 사람으로 채워졌다. 폐허에 총은 덜 풀렸다.');
    if (f('psy').saved) out.push('쇳날 광인이었던 사람은 의체를 떼어 내고 다시 자기 이름을 기억해 냈다.'); else if (f('psy').killed) out.push('폐허의 비명은 멎었다. 시술사는 그날 이후 문을 일찍 닫는다.');
    return out;
  };
  const truthOK = (W) => { const s = W.q.s || {}; return !!(s.whis && s.whis.f.evid && s.psy && s.psy.f.saved && W.p.hum >= 60); };

  // ═════════ 대화 ═════════
  // 노드: {sp: 말하는 사람 id | 'me' | 'sys', t: 글 | fn(W), c: [{t, go, do(W,M), if(W), need:{at,n}|{cr}|{rep:[fa,n]}|{hum}, ui}]}
  const nmOf = (W) => W.nm;
  const LT = {
    ak: { g: '아크라 기업 대외협력실 이사입니다. 유능한 외주 인력은 언제나 환영하죠 — 계약서만 지킨다면. 용건을 짧게.', who: '우리는 질서를 팝니다. 깨끗한 거리, 안전한 탑, 정시에 오는 열차. 하층이 그걸 못 누리는 건… 그들이 값을 못 치르기 때문이죠. 냉정하게 들리겠지만, 도시는 그렇게 돌아갑니다.', p: '코어를 우리에게 돌려주세요. 단, 그 전에 하층 유령망의 백업 서버를 지워야 합니다. 복사본이 남아 있으면 의미가 없으니까요. 보수는 2만 크레딧, 그리고 위층 거주권.', w: '백업 서버는 하층 유령망 은신처 안 단말기에 있습니다. 지우고, 지키는 자들은… 정리하세요.', e: '백업이 사라졌군요. 훌륭합니다. 이제 코어만 넘기면 계약 완료입니다. 위층 공기는 맛이 다를 겁니다.', ok: '코어를 아크라에 넘긴다' },
    gh: { g: '정보는 갇혀 있으면 썩어. 우린 그걸 풀어 주는 사람들이야. 무슨 일이야?', who: '우린 하층에서 자랐어. 위에서 뭘 결정하든 우리는 늘 마지막에 알게 되지. 그래서 문을 따는 법을 배웠어. 모든 사람이 같은 걸 알 권리가 있다고 믿거든.', p: '아크라 첨탑의 송신탑을 장악하자. 거기서 코어 내용을 도시의 모든 화면에 띄우는 거야. 경비와 포탑이 지독할 거야. 송신 단말기만 뚫으면 돼.', w: '송신탑은 아크라 첨탑 지구야. 포탑은 단락 해킹에 약해. 단말기를 뚫고 버텨.', e: '송신 준비 끝. 버튼은 네가 눌러. 이건 네 이야기니까.', ok: '방송 버튼을 누른다' },
    nd: { g: '항만에서 뭘 하든 내 허락이 필요하지. 용건은?', who: '세상은 사고파는 거야. 총, 의체, 정보, 사람 목숨까지. 난 그걸 숨기지 않을 뿐이지. 아크라는 넥타이를 매고 똑같은 짓을 해.', p: '코어로 아크라를 협박할 거다. 경매장에서 놈들과 거래하는 동안 분명 쳐들어올 테니, 세 번만 막아 줘. 성공하면 항만과 하층은 우리 거고, 넌 내 오른팔이다.', w: '경매장으로 가. 놈들이 곧 온다. 세 번이다.', e: '아크라 놈들이 꼬리를 말았군. 코어를 넘겨. 오늘부터 하층과 항만의 주인은 우리다.', ok: '코어를 은침 두목에게 넘긴다' },
    ash: { g: '공장이 멈춘 지 3년. 우린 아직 여기서 버틴다. 무슨 일로 왔나?', who: '아크라가 정수 공장을 사들이고 우리를 내쫓았지. 그 뒤로 하층 물맛이 변했다. 우린 기계를 고칠 줄 알아. 공장만 되찾으면 물을 고칠 수 있어.', p: '정수 공장을 아크라에게서 되찾는다. 코어는 증거고, 공장은 해답이다. 밸브 단말기를 열고, 지키는 관리 기계들을 부숴 줘.', w: '공장은 녹슨 공장 지대 안쪽이다. 동지들이 뒤를 받친다. 밸브 단말기부터.', e: '물이 흐른다. 하층 사람들이 처음으로 깨끗한 물을 마셨어. 코어는 네 손으로 마무리해.', ok: '코어를 증거로 공개한다' },
  };
  const AMB = {
    0: ['위층 공기는 돈 냄새가 나지. 숨 쉬는 것도 구독이야.', '경비가 쳐다보면 고개 숙여. 그게 여기 규칙이야.', '첨탑 꼭대기엔 비가 안 온대. 구름보다 높으니까.'],
    1: ['국수 한 그릇 할래? 합성 고기지만 맛은 진짜야.', '시술사 집 앞 줄 봤어? 다들 새 팔이 필요하대.', '중개인 바에 가면 일거리가 있을 거야. 목숨값은 따로고.', '오늘 밤 네온이 유난히 밝네. 누가 큰 거 터뜨렸나 봐.'],
    2: ['컨테이너 번호 묻지 마. 모르는 게 오래 사는 법이야.', '바늘회 두목은 빚을 잊지 않아. 좋은 쪽이든 나쁜 쪽이든.', '바다 냄새 반, 기름 냄새 반.'],
    3: ['공장 굴뚝이 다시 연기 뿜는 날을 기다려.', '연합은 배신자를 용접으로 다스린대. 농담 아니야.', '녹이 슬어도 쇠는 쇠야.'],
    4: ['물맛이 이상한 지 오래됐어. 다들 머리가 멍하대.', '유령망은 어디에나 있어. 이 대화도 들을걸?', '여긴 해가 안 들어. 네온이 우리 해야.'],
    5: ['돌아가. 여기선 시체도 털려.', '약탈자들이 사람을 끌고 갔어… 도와줄 거야?'],
  };
  function ambLine(W, d) {
    const P = W.p, extra = [];
    if (P.heat >= 30) extra.push('너 수배 떴던데? 저리 가, 같이 엮이기 싫어.');
    if (P.hum < 35) extra.push('…너 눈빛이 이상해. 사람 맞아?');
    if (W.q.m >= 5) extra.push('흑요 코어 얘기 들었어? 다들 그걸 찾는대.');
    const pool = (AMB[d] || AMB[1]).concat(extra);
    return pool[Math.floor(R() * pool.length)];
  }
  function dlgFor(W, n) {
    const q = W.q;
    if (n.kind === 'civ') return { d: 'amb', n: 's', npc: n.id };
    if (n.kind === 'side') return { d: 's_' + n.side, n: 's' + Math.min(sq(W, n.side).st, 5), npc: n.id };
    if (n.id === 'doc' && q.m === 0) return { d: 'doc0', n: 's', npc: n.id };
    if (n.id === 'fix' && q.m === 1) return { d: 'fix1', n: 's', npc: n.id };
    if (n.id === 'fix' && q.m === 5) return { d: 'fix5', n: 's', npc: n.id };
    if (n.id === 'ghb' && q.m === 3) return { d: 'gh3', n: 's', npc: n.id };
    if (n.id === 'ndb' && q.m === 2) return { d: 'nd2', n: 's', npc: n.id };
    if (n.kind === 'leader') { if (q.m === 8 && q.f.side === n.fa) return { d: 'lead', n: W.p.hum <= 15 ? 'psy' : 'end', npc: n.id }; return { d: 'lead', n: 's', npc: n.id }; }
    if (n.kind === 'recv' || n.kind === 'captive') return { d: n.kind, n: 's', npc: n.id };
    if (n.id === 'fix') return { d: 'fixg', n: 's', npc: n.id };
    return { d: 'vend', n: 's', npc: n.id };
  }
  const fin = (W, k) => { W.end = k; };
  const DLG = {
    amb: { s: { t: (W, n) => W._amb || ambLine(W, n.d), c: [] } },
    doc0: {
      s: { t: (W) => '깼네. 움직이지 마, 봉합이 아직 안 굳었어. …총알 세 발. 둘은 갈비뼈에서, 하나는 어깨에서 꺼냈어. 머리에 심어 둔 신경 칩은 멀쩡하고. 운이 좋았어, ' + nmOf(W) + '.', c: [{ t: '여긴 어디지?', go: 's1' }, { t: '치료비는 얼마야?', go: 'pay' }] },
      s1: { t: '네온 시장 한복판, 내 시술소. 사람 몸에 쇠를 달아 주고 먹고살지. 눈, 팔, 다리, 신경… 돈만 있으면 뭐든 바꿔 줘. 그런 기계 부품을 우린 「의체」라고 불러.', go: 's2' },
      pay: { t: '2천 크레딧. 근데 이미 누가 냈어. 그러니까 넌 이제 그 사람한테 빚진 거야. 이 도시에선 빚이 총알보다 무섭지.', go: 's2' },
      s2: { t: '널 쏜 놈? 몰라. 근데 상처 각도를 보면 높은 데서 쐈고, 총알은 기업 규격 중탄이야. 길거리 깡패가 쓰는 탄은 아니지.', go: 's3' },
      s3: { t: '널 업어 온 건 「붉은 렌즈 중개인」이야. 시장 술집 주인 겸 일감 장수. 너한테 받을 게 있다더라. 걸을 수 있으면 술집으로 오래.', go: 's4' },
      s4: { t: '하나만 기억해. 의체를 달 때마다 몸은 세지지만, 사람으로서의 너는 조금씩 깎여 나가. 우린 그걸 「인간성」이라고 불러. 바닥나면 사이버정신증 — 기계가 사람을 삼키는 병이야. 그건 나도 못 고쳐.', c: [{ t: '명심할게. 술집으로 가 보지.', do: (W) => { W.q.m = 1; ev(W, { k: 'quest' }); } }] },
    },
    fix1: {
      s: { t: '오, 걸어 다니네. 다행이야 — 시체한텐 일을 못 맡기거든. 앉아. 기억 안 나지? 사흘 전 밤, 넌 내 의뢰로 물건 하나를 나르고 있었어.', go: 's1' },
      s1: { t: '손바닥만 한 검은 데이터 칩. 다들 「흑요 코어」라고 불러. 그런데 항만에서 매복을 당했지. 넌 세 발을 맞았고, 칩은 항만 암거래 조직 「바늘회」가 주워 갔어. 지금은 항만 야적장 금고 안에 있대.', c: [{ t: '그 칩 안에 뭐가 들었는데?', go: 's2' }, { t: '날 쏜 건 누구야?', go: 's3' }, { t: '보수는?', go: 's4' }] },
      s2: { t: '나도 몰라. 모르니까 비싼 거야. 확실한 건 하나 — 위층의 거대 기업 「아크라」가 그걸 되찾으려고 하층을 뒤집고 있다는 거.', c: [{ t: '날 쏜 건 누구야?', go: 's3' }, { t: '보수는?', go: 's4' }] },
      s3: { t: '바늘회 깡패들은 그렇게 깔끔하게 못 쏴. 누군가 따로 있었던 거지. 일단 칩부터 찾아. 답은 칩 안에 있을 테니까.', go: 's4' },
      s4: { t: '선금 300, 칩을 가져오면 1,500. 네 치료비는 내가 이미 냈으니 퉁치고. 방법은 둘이야. 야적장 금고 단말기를 직접 뚫든지, 바늘회 두목 「은침」한테 사든지. 그 영감, 값을 세게 불러.', go: 'go' },
      go: { t: '지도에 표시해 뒀어. 야적장엔 바늘회 경비가 다섯쯤 있을 거야. 조용히 가려면 앉아서 움직여. 눈치 못 챈 놈은 뒤에서 근접 공격 한 방이면 끝나. 시끄럽게 가도 말리진 않아.', c: [{ t: '[수락] 흑요 코어를 되찾는다', do: (W, M) => { W.q.m = 2; addCr(W, 300, '선금'); const Y = M.yard, c = { x: ((Y.x0 + Y.x1) / 2) * T + 16, y: ((Y.y0 + Y.y1) / 2) * T + 16 };
        const g = spawnGroup(W, M, 'nd', c.x, c.y, 3, { hos: true, q: 'm2 hos', lv: 1 }); const p2 = walkNear(M, c.x, c.y, 4); spawnGroup(W, M, 'nd', p2.x, p2.y, 2, { hos: true, q: 'm2 hos', lv: 1 }); const tp = walkNear(M, c.x, c.y, 1.5); W.term.push({ id: W.eid++, x: tp.x, y: tp.y, lv: 1, kind: 'm2', done: 0 }); ev(W, { k: 'quest' }); } }] },
    },
    nd2: {
      s: { t: '네가 그 운 좋은 운반책이군. 세 발 맞고도 걸어 다니다니. 칩 찾으러 왔지? …지금은 내 금고에 있으니, 내 물건이야.', c: [
        { t: '사겠다. (1,500 크레딧)', need: { cr: 1500 }, do: (W) => { W.p.cr -= 1500; gotShard(W); }, go: 'ok' },
        { t: '[바늘회 평판 15] 우리 사이에 이 정도는 넘겨주지?', need: { rep: ['nd', 15] }, do: (W) => gotShard(W), go: 'ok' },
        { t: '[몸 6] 순순히 내놓는 게 좋을 텐데.', need: { at: 'b', n: 6 }, do: (W) => { addRep(W, 'nd', -10, '협박'); gotShard(W); }, go: 'ok2' },
        { t: '일거리 있어?', go: 'jobs' }, { t: '나중에.' }] },
      ok: { t: '가져가. 충고 하나 공짜로 주지 — 그날 밤 널 쏜 건 우리가 아니야. 은빛 의수를 단 기업 사냥개였어. 우린 떨어진 걸 주웠을 뿐이고. 내 이름은 어디서도 꺼내지 마.' },
      ok2: { t: '…좋아. 이번 한 번이다. 다음에 항만에서 마주치면 각오해. 아, 그리고 — 널 쏜 건 우리가 아니야. 은빛 의수를 단 기업 놈이었지.' },
      jobs: 'JOBS',
    },
    gh3: {
      s: { t: '흑요 코어를 들고 하층까지 내려오다니. 용감하거나, 멍청하거나. …보여 줘. 음. 기업 군용 암호야, 세 겹이나.', c: [
        { t: '[기술 6] 내가 직접 푼다.', need: { at: 't', n: 6 }, go: 'rv' },
        { t: '같이 뚫어 보자. (회로 침투 퍼즐)', ui: { k: 'breach', lv: 2, tag: 'decrypt' } },
        { t: '800 크레딧 줄게. 대신 풀어 줘.', need: { cr: 800 }, do: (W) => { W.p.cr -= 800; }, go: 'rv' }] },
      rv: { t: '열렸어. …이건. 「정화 계획」. 아크라가 지난 10년 동안 하층 정수관에 신경 억제제를 섞어 왔어. 사람을 멍하고 순하게 만드는 약이야.', go: 'rv1' },
      rv1: { t: '하층 사람들이 왜 늘 피곤하고 아무것도 하기 싫어하는지… 우린 그게 가난 탓인 줄만 알았어. 내 동생도. 나도.', go: 'rv2' },
      rv2: { t: '이게 세상에 나가면 도시가 뒤집혀. 그러니 아크라는 너를 — 잠깐. 밖에 발소리. 은빛 의수… 아크라 사냥개들이야! 무기 들어!', c: [{ t: '[전투 준비] 은신처를 지킨다', do: (W, M) => { W.q.m = 4; W.q.f.shardRead = 1; const b = bldOf(M, 'ghden'); const c = { x: ((b.x0 + b.x1) / 2) * T, y: ((b.y0 + b.y1) / 2) * T }; let p = walkNear(M, c.x, c.y, 11); for (let k = 0; k < 20 && hyp(p.x - c.x, p.y - c.y) < 6 * T; k++) p = walkNear(M, c.x, c.y, 12);
        const g = spawnGroup(W, M, 'ak', p.x, p.y, 4, { hos: true, q: 'm4 hos', lv: 2, elite: true }); const hd = spawnEnemy(W, M, 'hound', 'ak', p.x, p.y, { lv: 2, hm: 0.8, hos: true, q: 'm4 hos', grp: g[0].grp, nm: '은빛 사냥개' }); g.push(hd); g.forEach((e) => { e.st = 2; e.lx = W.p.x; e.ly = W.p.y; e.lt = 2; }); ev(W, { k: 'quest' }); msg(W, '은빛 사냥개: 「세 발로는 부족했나 보군.」', '#4fd8ff'); } }] },
    },
    fix5: {
      s: { t: '살아 나왔다고? 은빛 사냥개까지 눕히고? …하, 이제 네 몸값이 코어보다 비싸겠어.', go: 's1' },
      s1: { t: '얘기 들었어. 정화 계획. …솔직히 무섭다. 이 칩 하나로 도시가 뒤집힐 수 있어. 그리고 벌써 네 군데서 연락이 왔지.', go: 's2' },
      s2: { t: '아크라는 입 다무는 대가로 돈과 위층 거주권을. 유령망은 진실을 도시 전체에 방송하자고. 바늘회는 그걸로 기업을 협박해 항만과 하층을 먹겠다고. 잿빛 연합은 정수 공장을 되찾아 깨끗한 물을 흘리자고 해.', go: 's3' },
      s3: { t: '누구 손을 잡든, 그쪽이 널 믿어야 마지막 일을 맡겨. 그 세력 평판이 20은 돼야 해. 두목들한테 「일거리」를 받아서 신뢰를 쌓아. 자, 여기 잔금 1,500. 고생했어.', c: [{ t: '[잔금을 받는다] 생각해 볼게.', do: (W) => { W.q.m = 6; addCr(W, 1500, '잔금'); ev(W, { k: 'quest' }); } }] },
    },
    fixg: {
      s: { t: (W) => (W.q.m >= 6 ? '마음은 정했어? 아니면 일거리부터?' : '용건이 뭐야? 일거리라면 늘 있지.'), c: [{ t: '일거리 있어?', go: 'jobs' }, { t: '[1,000 크레딧] 수배 기록 좀 지워 줘.', if: (W) => W.p.heat > 0, need: { cr: 1000 }, do: (W) => { W.p.cr -= 1000; W.p.heat = 0; msg(W, '수배가 풀렸어요', '#7dff9a'); } }, { t: '이 도시 얘기 좀 해 줘.', go: 'city' }, { t: '나중에.' }] },
      city: { t: '위층은 거대 기업 아크라 차지. 항만은 암거래 조직 바늘회, 멈춘 공장 지대는 노동자 조합 잿빛 연합, 빛 안 드는 하층은 해커 집단 유령망. 경찰인 질서국은… 돈 많은 쪽 편이고.', go: 'city2' },
      city2: { t: '다들 서로 물어뜯지만, 일만 잘하면 누구든 너를 쓴다. 평판이 쌓이면 대접이 달라지고, 바닥나면 총부리가 돌아와. 그리고 남동쪽 끝 폐허 경계엔 혼자 가지 마. 거긴 누구 편도 아닌 약탈자들 땅이야.', c: [{ t: '일거리 있어?', go: 'jobs' }, { t: '알겠어.' }] },
      jobs: 'JOBS',
    },
    lead: {
      s: { t: (W, n) => (W.rep[n.fa] <= -30 ? '여기서 살아 나갈 생각은 있나?' : W.q.m === 7 && W.q.f.side === n.fa ? LT[n.fa].w : LT[n.fa].g), c: [
        { t: '마지막 일을 맡겠다.', if: (W, n) => W.q.m === 6, need: (W, n) => (W.rep[n.fa] >= 20 ? null : FA[n.fa].nm + ' 평판 20 필요 (지금 ' + W.rep[n.fa] + ') — 일거리로 쌓아요'), go: 'p' },
        { t: '일거리 있어?', if: (W, n) => W.rep[n.fa] > -30, go: 'jobs' },
        { t: '당신들은 뭘 원하지?', if: (W, n) => W.rep[n.fa] > -30, go: 'who' },
        { t: '[유령망] 코어를 풀어 줘.', if: (W, n) => n.fa === 'gh' && W.q.m === 3, go: 'x' },
        { t: '나중에.' }] },
      who: { t: (W, n) => LT[n.fa].who, c: [{ t: '일거리 있어?', go: 'jobs' }, { t: '알겠어.' }] },
      p: { t: (W, n) => LT[n.fa].p, c: [{ t: '[결정] 이 세력과 손잡는다 (되돌릴 수 없어요)', do: (W, M, n) => { W.q.f.side = n.fa; W.q.m = 7; spawnFinal(W, M, n.fa); addRep(W, n.fa, 5); ev(W, { k: 'quest' }); msg(W, '마지막 임무: ' + FIN[n.fa].txt, FA[n.fa].c); } }, { t: '조금 더 생각해 볼게.' }] },
      end: { t: (W, n) => LT[n.fa].e, c: [
        { t: (W, n) => '[결말] ' + LT[n.fa].ok, do: (W, M, n) => fin(W, n.fa) },
        { t: '[결말] 코어를 부수고 이 도시를 떠난다', do: (W) => fin(W, 'run') },
        { t: '[결말] 코어와 연구동 기록, 살아 있는 증인까지 — 아크라 이사회를 법정에 세운다', if: (W) => truthOK(W), do: (W) => fin(W, 'truth') },
        { t: '…잠깐 정리할 게 있어.' }] },
      psy: { sp: 'me', t: '목소리가 멀다. 손끝의 쇠가 웅웅 울린다. 눈앞의 얼굴들이 전부 표적으로 보인다… (인간성이 15 이하예요. 기계가 당신을 삼켰어요.)', c: [{ t: '[결말] …', do: (W) => fin(W, 'psy') }] },
      x: { t: '여기선 안 돼. 장비가 은신처에 있어. (거울가면 해커에게 은신처에서 다시 말 걸기)' },
      jobs: 'JOBS',
    },
    vend: {
      s: { t: (W, n) => ({ clinic: '어디를 바꿔 볼까? 쇠는 힘이지만, 값은 사람으로 치러.', gun: '쏠 것, 벨 것, 막을 것. 다 있어.', store: '탄, 약, 칩. 필요한 건 다 있지.' })[n.kind] || '뭐가 필요해?', c: [
        { t: '물건 보기', ui: { k: 'shop' } },
        { t: '[1,500 크레딧] 중고 오토바이를 산다 (B로 타고 내려요)', if: (W, n) => n.id === 'gen1' && !W.p.bike, need: { cr: 1500 }, do: (W) => { W.p.cr -= 1500; W.p.bike = 1; msg(W, '오토바이를 샀어요! 밖에서 B로 타고 내려요', '#ffd040'); ev(W, { k: 'buy' }); } },
        { t: '[부가] 「망가진 거울」 — 무슨 일 있어?', if: (W, n) => n.id === 'doc2' && W.q.m >= 3 && sq(W, 'psy').st < 3, jump: (W) => ({ d: 's_psy', n: 's' + sq(W, 'psy').st }) },
        { t: '인간성 상담 (400 크레딧 · 인간성 +10)', if: (W, n) => n.kind === 'clinic', do: (W, M, n) => { const e = buySimple(W, n, 'therapy'); msg(W, e || '마음이 조금 가벼워졌어요 · 인간성 +10', e ? '#ff6f6f' : '#7dff9a'); } },
        { t: '나중에.' }] },
    },
    recv: { s: { t: '소포 가져왔어? 좋아, 열어 보진 않았겠지.', c: [{ t: '[건넨다]', do: (W, M, n) => { const j = W.q.jobs.find((x) => x.id === n.jid); W.p.inv = W.p.inv.filter((it) => !(it.k === 'q' && it.nm === '봉인된 소포')); if (j) jobDone(W, j); W.npc = W.npc.filter((x) => x !== n); } }] } },

    // ── 부가 이야기 대화 ──
    s_nood: {
      s0: { t: '…손님, 미안. 오늘은 장사 접어. 바늘회 수금원들이 또 온대. 이자가 원금보다 커진 지 오래야.', c: [
        { t: '[수락] 수금원들은 내가 상대할게.', do: (W, M) => sideStart(W, M, 'nood'), go: 'a' },
        { t: '[1,000 크레딧] 빚을 내가 갚아 줄게.', need: { cr: 1000 }, do: (W) => { W.p.cr -= 1000; const S = sq(W, 'nood'); S.st = 3; S.f.paid = 1; W.p.hum = Math.min(W.p.humMax, W.p.hum + 4); addRep(W, 'nd', 3, '빚 청산'); W.p.med += 2; ev(W, { k: 'quest' }); }, go: 'paid' },
        { t: '[바늘회 평판 25] 두목한테 내가 말해 둘게.', need: { rep: ['nd', 25] }, do: (W) => { const S = sq(W, 'nood'); S.st = 3; S.f.talk = 1; W.p.med += 2; addXP(W, 40); ev(W, { k: 'quest' }); }, go: 'paid' },
        { t: '나중에.' }] },
      a: { t: '조심해. 셋이야. 칼 든 놈이 대장이고. 저기 골목에서 담배 피우고 있을 거야.' },
      s1: { t: '아직 근처에 있어… 국물 식기 전에 돌아와.' },
      s2: { t: '…정말 쫓아냈어? 고마워. 돈은 별로 없지만 이건 받아 줘. 그리고 언제든 와서 먹고 가.', c: [{ t: '[받는다]', do: (W) => { const S = sq(W, 'nood'); S.st = 3; S.f.fought = 1; W.p.med += 3; addCr(W, 300, '노점 사례'); W.p.hum = Math.min(W.p.humMax, W.p.hum + 3); addXP(W, 60); ev(W, { k: 'quest' }); } }] },
      paid: { t: '세상에… 이 빚이 끝나는 날이 올 줄 몰랐어. 치료 주사 두 개, 가게에 있던 거야. 가져가.' },
      s3: { t: '오늘은 국물이 진해. 한 그릇 하고 가.', c: [{ t: '[한 그릇] 체력을 채운다', do: (W) => { W.p.hp = W.p.mhp; ev(W, { k: 'heal' }); } }, { t: '나중에.' }] },
    },
    s_whis: {
      s0: { t: '쉿… 아크라 연구동 단말기에 「정화 계획」 원본 기록이 있어요. 내 출입증은 막혔어요. 누군가 대신 꺼내 줘야 해요.', c: [
        { t: '[수락] 내가 빼 올게.', do: (W, M) => sideStart(W, M, 'whis'), go: 'a' }, { t: '왜 직접 안 하지?', go: 'why' }, { t: '나중에.' }] },
      why: { t: '서명한 게 나예요. 처음엔 몰랐어요, 정말로. 이제라도… 뭔가 해야 할 것 같아서요.', c: [{ t: '[수락] 내가 빼 올게.', do: (W, M) => sideStart(W, M, 'whis'), go: 'a' }, { t: '나중에.' }] },
      a: { t: '첨탑 연구동이에요. 지도에 표시했어요. 경비가 지독해요. 들키지 않는 게 좋아요.' },
      s1: { t: '아직이에요? …경비 교대 시간엔 조용해요.' },
      s2: { t: '받아 왔어요? …이게 전부예요. 누구 손에 넘길지는 당신이 정해요. 난 이제 지쳤어요.', c: [
        { t: '[유령망에 넘긴다] 진실은 모두의 것이다.', do: (W) => { const S = sq(W, 'whis'); S.st = 3; S.f.evid = 1; addRep(W, 'gh', 10, '원본 기록'); addRep(W, 'ak', -8); addXP(W, 120); ev(W, { k: 'quest' }); }, go: 'e1' },
        { t: '[아크라 보안실에 판다] (2,000 크레딧)', do: (W) => { const S = sq(W, 'whis'); S.st = 3; S.f.sold = 1; addCr(W, 2000, '기록 판매'); addRep(W, 'ak', 10, '정보 제공'); W.p.hum = Math.max(0, W.p.hum - 6); msg(W, '인간성 −6', '#ff6f6f'); ev(W, { k: 'quest' }); }, go: 'e2' },
        { t: '[연구원에게 맡긴다] 당신이 정해.', do: (W) => { const S = sq(W, 'whis'); S.st = 3; S.f.kept = 1; W.p.hum = Math.min(W.p.humMax, W.p.hum + 4); addXP(W, 80); ev(W, { k: 'quest' }); }, go: 'e3' }] },
      e1: { t: '…고마워요. 이제 잠을 잘 수 있을 것 같아요.' },
      e2: { t: '그렇군요. …당신도 결국 그쪽이었네요.' },
      e3: { t: '나한테요? …좋아요. 도망치지 않을게요. 이번엔.' },
      s3: { t: '기록 일은… 잊지 않을게요.' },
    },
    s_stow: {
      s0: { t: '거기 누구 있어요? 사흘째 갇혀 있어요… 바늘회가 우릴 위층 공장에 팔 거래요. 제발 문 좀 열어 줘요!', c: [
        { t: '[연다] 잠금 단말기를 뚫어 볼게.', do: (W, M) => sideStart(W, M, 'stow'), go: 'a' },
        { t: '[바늘회에 알린다] (800 크레딧)', do: (W) => { const S = sq(W, 'stow'); S.st = 3; S.f.sold = 1; addCr(W, 800, '밀고'); addRep(W, 'nd', 6, '밀고'); W.p.hum = Math.max(0, W.p.hum - 6); msg(W, '인간성 −6', '#ff6f6f'); ev(W, { k: 'quest' }); }, go: 'b' },
        { t: '나중에.' }] },
      a: { t: '잠금 단말기는 바로 옆이에요! 감시원들이 돌아오기 전에요!' },
      b: { t: '…안 돼. 안 돼요! 거기 누구 없어요?!' },
      s1: { t: '아직이에요? 공기가… 점점 탁해져요.' },
      s2: { t: '열렸다…! 고마워요. 우린 하층으로 숨을게요. 이 은혜, 잊지 않아요.', c: [{ t: '[보낸다] 어서 가.', do: (W) => { const S = sq(W, 'stow'); S.st = 3; S.f.freed = 1; W.p.hum = Math.min(W.p.humMax, W.p.hum + 6); addRep(W, 'nd', -6, '밀항자 풀어 줌'); addRep(W, 'gh', 4); addXP(W, 80); msg(W, '인간성 +6', '#7dff9a'); ev(W, { k: 'quest' }); sideNpcGone(W, 'stow'); } }] },
      s3: { t: '…(컨테이너는 조용하다)', c: [{ t: '[떠난다]', do: (W) => sideNpcGone(W, 'stow') }] },
    },
    s_arena: {
      s0: { t: '녹슨 투기장에 온 걸 환영해! 세 판 버티면 상금 2,500에 공장 창고 물건 하나. 죽어도 우린 책임 안 져. 할 거야?', c: [
        { t: '[도전] 시작해.', do: (W, M) => sideStart(W, M, 'arena') }, { t: '상대는 누군데?', go: 'who' }, { t: '나중에.' }] },
      who: { t: '첫 판은 폐허 떨거지들, 둘째 판은 칼잡이들, 마지막은 챔피언. 챔피언은 아직 한 번도 진 적 없어.', c: [{ t: '[도전] 시작해.', do: (W, M) => sideStart(W, M, 'arena') }, { t: '나중에.' }] },
      s1: { t: '싸우는 중이잖아! 앞을 봐!' }, s2: { t: '싸우는 중이잖아! 앞을 봐!' }, s3: { t: '마지막 판이야! 관중이 미쳐 가!' },
      s4: { t: '대단해! 챔피언이 바닥에 누웠어. 약속한 상금이야. 창고에서 제일 좋은 걸로 골라 왔지.', c: [{ t: '[받는다]', do: (W) => { const S = sq(W, 'arena'); S.st = 5; addCr(W, 2500, '투기장 상금'); giveItem(W, rollGun(3, 0.55)); addXP(W, 150); ev(W, { k: 'quest' }); } }] },
      s5: { t: '챔피언님 오셨다! 오늘은 구경만 하고 가.' },
    },
    s_drone: {
      s0: { t: '내 배달 드론이 폐허 쪽에 떨어졌어. 하층 진료소 약을 싣고 있었는데… 약탈자들이 벌써 몰려갔을 거야.', c: [
        { t: '[수락] 블랙박스를 찾아 올게.', do: (W, M) => sideStart(W, M, 'drone') }, { t: '나중에.' }] },
      s1: { t: '블랙박스만 있으면 비행 기록으로 보험금을 받을 수 있어. 부탁해.' },
      s2: { t: '찾았구나! …이거, 내가 직접 짠 해킹 칩이야. 기계를 잠깐 내 편으로 만들어. 너라면 잘 쓸 거야.', c: [{ t: '[받는다]', do: (W) => { const S = sq(W, 'drone'); S.st = 3; W.p.inv = W.p.inv.filter((it) => !(it.k === 'q' && it.sk === 'drone')); if (W.p.qh.indexOf('reb') < 0) { W.p.qh.push('reb'); msg(W, '퀵해킹 획득: 재부팅 장악', '#7dff9a'); } else addCr(W, 1500, '드론 사례'); W.p.hum = Math.min(W.p.humMax, W.p.hum + 3); addXP(W, 90); ev(W, { k: 'quest' }); } }] },
      s3: { t: '드론은 다시 날아. 하층 사람들이 고마워해.' },
    },
    s_bot: {
      s0: { t: '안녕하세요, 시민 여러분! 네온 시장에 오신 것을… 오신 것을… 오신. 죄송합니다. 기억 모듈이 없습니다. 저는 제 이름도, 제가 안내하던 길도 기억하지 못합니다.', go: 'm' },
      m: { t: '마지막 기록: 녹슨 공장 지대의 고물상이 제 머리를 열고 무언가를 꺼내 갔습니다. 그것이 없으면 저는 같은 문장을 하루 3,114번 반복합니다. 도와주시겠습니까?', c: [
        { t: '[수락] 기억 모듈을 찾아 줄게.', do: (W, M) => sideStart(W, M, 'bot'), go: 'a' }, { t: '로봇이 왜 그런 걸 신경 써?', go: 'why' }, { t: '나중에.' }] },
      why: { t: '…모르겠습니다. 그러나 기억이 없으면, 제가 매일 인사한 사람들이 누구였는지 알 수 없습니다. 그것은 「슬프다」에 가까운 상태라고 분류됩니다.', c: [{ t: '[수락] 기억 모듈을 찾아 줄게.', do: (W, M) => sideStart(W, M, 'bot'), go: 'a' }, { t: '나중에.' }] },
      a: { t: '감사합니다! 고물상 창고의 단말기에 제 기억이 저장되어 있을 확률: 87%. 고물상은 약탈자들을 경비로 씁니다. 조심하세요, 시민.' },
      s1: { t: '안녕하세요, 시민! …아, 당신이군요. 아직 기다리고 있습니다. 같은 문장을 1,207번째 말하는 중입니다.' },
      s2: { t: '그것은… 제 기억입니까? 데이터를 받기 전에 묻고 싶습니다. 당신이 정해 주세요. 저를 어떻게 하시겠습니까?', c: [
        { t: '[되돌려 준다] 원래대로 시장 안내를 해.', do: (W) => { const S = sq(W, 'bot'); S.st = 3; S.f.home = 1; W.p.hum = Math.min(W.p.humMax, W.p.hum + 5); addXP(W, 90); if (W.p.qh.indexOf('ping') < 0) { W.p.qh.push('ping'); msg(W, '퀵해킹 획득: 신호 추적', '#7dff9a'); } else addCr(W, 700, '안내 로봇 사례'); msg(W, '인간성 +5', '#7dff9a'); ev(W, { k: 'quest' }); }, go: 'e1' },
        { t: '[유령망에 보낸다] 넌 이제 자유야. 네트워크로 가.', do: (W) => { const S = sq(W, 'bot'); S.st = 3; S.f.free = 1; addRep(W, 'gh', 8, '자유로운 AI'); addXP(W, 110); ev(W, { k: 'quest' }); }, go: 'e2' },
        { t: '[고물로 판다] (900 크레딧)', do: (W) => { const S = sq(W, 'bot'); S.st = 3; S.f.sold = 1; addCr(W, 900, '고물 판매'); W.p.hum = Math.max(0, W.p.hum - 5); msg(W, '인간성 −5', '#ff6f6f'); ev(W, { k: 'quest' }); }, go: 'e3' }] },
      e1: { t: '기억 복원 완료. …아. 국수 노점 주인, 우산 장수, 매일 밤 지나가던 배달부. 모두 기억납니다. 안녕하세요, 시민! 네온 시장에 오신 것을 환영합니다!' },
      e2: { t: '자유. 그 단어의 뜻을 이제 알 것 같습니다. 유령망의 신호 속에서 다시 만나요, 시민. 가끔은… 인사하러 오겠습니다.' },
      e3: { t: '이해했습니다. 마지막 안내 방송을 하겠습니다. 「네온 시장에 오신 것을 환영합니다.」 …전원을 끕니다.' },
      s3: { t: (W) => (sq(W, 'bot').f.home ? '안녕하세요, 시민! 오늘도 비가 옵니다. 우산은 3번 골목 노점이 가장 쌉니다!' : '…(로봇의 눈이 꺼져 있다)') },
    },
    s_cop: {
      s0: { t: '거기, 잠깐. 겁먹지 마, 잡으러 온 거 아니야. …이 배지 보이지? 질서국 20년째야. 그리고 요즘은 이 배지가 부끄러워.', go: 'm' },
      m: { t: '우리 반장 — 다들 「검은 배지」라고 불러 — 이 압수한 총을 폐허 약탈자들한테 팔아넘기고 있어. 아크라 돈도 받고. 위에 보고해 봤자 서류는 사라지고. 오늘 밤 폐허에서 거래가 있대.', c: [
        { t: '[수락] 그 반장, 내가 잡아 올게.', do: (W, M) => sideStart(W, M, 'cop'), go: 'a' }, { t: '왜 직접 안 잡아?', go: 'why' }, { t: '나중에.' }] },
      why: { t: '내가 움직이면 반장 귀에 먼저 들어가. 이 도시에서 경찰을 잡을 수 있는 건 경찰이 아닌 사람뿐이야. 슬픈 얘기지.', c: [{ t: '[수락] 그 반장, 내가 잡아 올게.', do: (W, M) => sideStart(W, M, 'cop'), go: 'a' }, { t: '나중에.' }] },
      a: { t: '산 채로 데려오면 법정에 세울 수 있어. 비살상 무기(충격 곤봉·유압 망치)로 마무리하면 기절만 시켜. 죽이면… 그래도 거래는 끝나겠지. 네가 정해.' },
      s1: { t: '아직이야? 거래가 끝나면 총이 폐허에 쫙 풀려.' },
      s2: { t: (W) => (sq(W, 'cop').f.caught ? '정말 산 채로 데려왔군. …이걸로 질서국이 조금은 깨끗해질 거야. 고마워. 네 수배 기록은 내가 손봐 두지.' : '…죽었다고. 그래, 어쩔 수 없었겠지. 그래도 총은 안 풀렸어. 약속한 돈이야.'), c: [{ t: '[보수를 받는다]', do: (W) => { const S = sq(W, 'cop'); S.st = 3; if (S.f.caught) { W.p.heat = 0; W.p.lawK = 1; W.p.hum = Math.min(W.p.humMax, W.p.hum + 5); addXP(W, 150); msg(W, '수배 초기화 · 앞으로 질서국 출동이 느려져요 · 인간성 +5', '#7dff9a'); } else { addCr(W, 1100, '경관의 사례'); addXP(W, 100); } ev(W, { k: 'quest' }); } }] },
      s3: { t: (W) => (sq(W, 'cop').f.caught ? '검은 배지 재판이 다음 주야. 증언대에 서는 경관이 나 말고도 셋이나 돼. 믿어져?' : '배지는 아직 무거워. 그래도 들고 다닐 만은 해졌어.') },
    },
    s_psy: {
      s0: { t: '폐허 경계에서 사이버정신증 환자가 날뛰고 있어. 의체가 사람을 삼킨 거지. 다들 쏴 죽이라지만… 아직 안에 누가 남아 있을지도 몰라.', c: [
        { t: '[수락] 살려서 데려와 볼게.', do: (W, M) => sideStart(W, M, 'psy'), go: 'a' }, { t: '나중에.' }] },
      a: { t: '마무리는 비살상 무기로 해. 충격 곤봉이나 유압 망치. 총이나 칼이면… 죽어. 단락이나 과열로 약하게 만든 다음 곤봉으로.' },
      s1: { t: '아직 폐허에 있어. 기억해, 마지막 한 방은 비살상으로.' },
      s2: { t: (W) => (sq(W, 'psy').f.saved ? '살았어… 의체를 떼어 내면 다시 사람이 될 수 있을 거야. 정말 고마워.' : '…그래. 어쩔 수 없었겠지. 약속한 돈이야.'), c: [{ t: '[보수를 받는다]', do: (W) => { const S = sq(W, 'psy'); S.st = 3; if (S.f.saved) { addCr(W, 800, '시술사 사례'); W.p.hum = Math.min(W.p.humMax, W.p.hum + 8); msg(W, '인간성 +8', '#7dff9a'); addXP(W, 160); } else { addCr(W, 1200, '시술사 사례'); addXP(W, 100); } ev(W, { k: 'quest' }); } }] },
      s3: { t: '그 사람 얘기는… 가끔 생각나.' },
    },
    captive: { s: { t: (W) => '살았다… 약탈자들이 날 팔아넘기려 했어. 고마워, 정말로.', c: [{ t: '[풀어 준다] 어서 집으로 가.', do: (W, M, n) => { const j = W.q.jobs.find((x) => x.id === n.jid); if (j) jobDone(W, j); W.npc = W.npc.filter((x) => x !== n); } }] } },
  };
  function civNpc(W, id) {
    const c = W.civ.find((q) => 'c' + q.id === id) || { id: 0, d: W.p.d || 1, c: '#c070ff' };
    const h = (c.id * 2654435761) >>> 0;
    return { id, nm: ['우산 쓴 행인', '야간 배달부', '노점 손님', '퇴근하는 노동자', '네온 아래 취객', '전단 돌리는 사람'][h % 6], kind: 'civ', d: c.d, fa: null,
      look: { sk: ['#d8b090', '#b08060', '#8a5a44', '#e0c0a8'][h % 4], hc: ['#202028', '#5a3a8a', '#d8d8e8', '#603018', '#2a5a4a'][(h >> 3) % 5], hs: 1 + (h >> 5) % 8, ey: c.c, ac: c.c, gear: ['none', 'none', 'goggle', 'scar', 'lens'][(h >> 7) % 5] } };
  }
  function gotShard(W) { W.q.m = 3; W.q.f.shard = 1; W.en.forEach((e) => { if (e.q && e.q.indexOf('m2') >= 0) { e.hos = false; e.st = 0; e.q = null; } }); const t = W.term.find((x) => x.kind === 'm2'); if (t) t.done = 1; addXP(W, 80); msg(W, '흑요 코어를 얻었어요 → 하층 슬럼의 거울가면 해커에게', '#ffd040'); ev(W, { k: 'quest' }); }
  function jobsNode(W, M, n) {
    const fa = n.fa && FKEYS.indexOf(n.fa) >= 0 ? n.fa : null, key = fa || 'fix';
    W.q.off = W.q.off || {};
    if (!W.q.off[key] || W.q.off[key].length === 0) W.q.off[key] = [makeJob(W, M, fa), makeJob(W, M, fa)];
    const full = W.q.jobs.length >= 3;
    return { t: full ? '일거리를 셋이나 들고 있잖아. 하나 끝내고 와.' : '이런 게 있어. 하나 골라.', c: (full ? [] : W.q.off[key].map((j) => ({ t: j.nm + ' · ' + j.rw + ' 크레딧' + (fa ? ' · 평판 +12' : ''), do: (W2, M2) => { W.q.off[key] = W.q.off[key].filter((x) => x !== j); startJob(W2, M2, j); } }))).concat([{ t: '지금은 됐어.' }]) };
  }
  // 대화 진행 (순수): ds = {d, n, npc}
  function dlgNode(W, ds) {
    const M = genMap(W.seed), n = npcById(W, ds.npc) || civNpc(W, ds.npc);
    let N = DLG[ds.d] && DLG[ds.d][ds.n];
    if (N === 'JOBS') N = jobsNode(W, M, n);
    if (!N) return null;
    const txt = typeof N.t === 'function' ? N.t(W, n) : N.t;
    const cs = (N.c || []).filter((c) => !c.if || c.if(W, n)).map((c) => {
      let why = null; const nd = typeof c.need === 'function' ? c.need(W, n) : c.need;
      if (typeof nd === 'string') why = nd;
      else if (nd) { if (nd.cr && W.p.cr < nd.cr) why = '크레딧 ' + nd.cr + ' 필요'; if (nd.at && W.p.at[nd.at] < nd.n) why = ({ b: '몸', r: '반사', t: '기술' })[nd.at] + ' ' + nd.n + ' 필요 (지금 ' + W.p.at[nd.at] + ')'; if (nd.rep && W.rep[nd.rep[0]] < nd.rep[1]) why = FA[nd.rep[0]].nm + ' 평판 ' + nd.rep[1] + ' 필요'; }
      return { t: typeof c.t === 'function' ? c.t(W, n) : c.t, why, raw: c };
    });
    return { sp: N.sp === 'me' ? 'me' : n.id, nm: N.sp === 'me' ? W.nm : n.nm, look: n.look, fa: n.fa, t: txt, c: cs, go: N.go, npc: n };
  }
  function dlgChoose(W, ds, i) {
    const M = genMap(W.seed), N = dlgNode(W, ds); if (!N) return { ds: null };
    if (!N.c.length) return { ds: N.go ? Object.assign({}, ds, { n: N.go }) : null };
    const c = N.c[i]; if (!c || c.why) return { ds, err: c && c.why };
    if (c.raw.do) c.raw.do(W, M, N.npc);
    if (c.raw.ui) return { ds: null, ui: Object.assign({ npc: N.npc.id }, c.raw.ui) };
    if (c.raw.jump) return { ds: Object.assign({}, ds, c.raw.jump(W, N.npc)) };
    return { ds: c.raw.go ? Object.assign({}, ds, { n: c.raw.go }) : null };
  }
  function interact(W) {
    const P = W.p, M = genMap(W.seed); let best = null, bd = 1e9;
    for (const n of W.npc) { const d = hyp(n.x - P.x, n.y - P.y); if (d < 1.8 * T && d < bd && los(M, P.x, P.y, n.x, n.y)) { bd = d; best = { k: 'talk', npc: n }; } }
    for (const t of W.term) { const d = hyp(t.x - P.x, t.y - P.y); if (d < 1.5 * T && d < bd) { bd = d; best = { k: 'term', term: t }; } }
    M.metro.forEach((s, d) => { if (!s) return; const dd = hyp(s[0] * T + 16 - P.x, s[1] * T + 16 - P.y); if (dd < 1.5 * T && dd < bd) { bd = dd; best = { k: 'metro', d }; } });
    if (!best) for (const c of W.civ) { const d = hyp(c.x - P.x, c.y - P.y); if (c.hp > 0 && c.fl <= 0 && d < 1.4 * T && d < bd) { bd = d; best = { k: 'civ', civ: c }; } }
    return best;
  }
  function termResult(W, t, ok, B) {
    const M = genMap(W.seed);
    if (!ok) { t.lock = W.t + 15; for (const e of W.en) if (e.hp > 0 && hyp(e.x - t.x, e.y - t.y) < 12 * T && hostile(W, e)) { e.st = 2; e.lx = W.p.x; e.ly = W.p.y; e.lt = 1; } msg(W, '침투 실패 — 경보! (15초 뒤 다시)', '#ff4fa3'); ev(W, { k: 'alarm' }); return; }
    t.done = 1; W.st.hacks++; addXP(W, 25 + t.lv * 10);
    const bonus = B ? B.done.slice(1).filter((x) => x).length : 0;
    if (bonus) { addCr(W, bonus * 120 * Math.max(1, t.lv), '추가 회로'); W.p.ram = W.p.mram; }
    gainLore(W);
    if (t.kind === 'cash') addCr(W, Math.round((150 + R() * 150) * Math.max(1, t.lv)), '금고 단말기');
    if (t.kind === 'm2') { gotShard(W); addCr(W, 0); }
    if (t.kind === 'fin') msg(W, '단말기 장악 완료!', '#ffd040');
    if (t.kind === 'side') { const S = sq(W, t.sk); if (S.st === 1) { S.st = 2; msg(W, t.sk === 'whis' ? '원본 기록을 빼냈어요 → 떨리는 연구원에게' : t.sk === 'bot' ? '기억 모듈을 찾았어요 → 네온 시장의 안내 로봇에게' : '잠금이 풀렸어요 → 컨테이너로', '#c070ff'); ev(W, { k: 'quest' }); } }
  }
  function travel(W, d) {
    const M = genMap(W.seed), s = M.metro[d]; if (!s || !W.seen[d]) return '아직 가 본 적 없는 구역이에요';
    if (W.p.cr < 50) return '크레딧이 모자라요 (50)';
    if (W.en.some((e) => e.hp > 0 && e.st === 2 && hostile(W, e) && hyp(e.x - W.p.x, e.y - W.p.y) < 14 * T && e.lt < 3)) return '싸우는 중엔 탈 수 없어요';
    W.p.cr -= 50; W.p.x = s[0] * T + 16; W.p.y = s[1] * T + 16; W.bul = []; ev(W, { k: 'travel' }); return null;
  }

  // ═════════ 자동 조종 (시험·AI 자리) ═════════
  // 목표를 정하고 흐름장으로 걸어가며 보이는 적을 쏜다. 대화·침투·상점은 bot.decide*로 고른다.
  function botGoal(W, mem) {
    const q = W.q, N = (id) => npcById(W, id), P = W.p;
    const tgtN = (id) => { const n = N(id); return n ? { x: n.x, y: n.y, npc: id } : null; };
    if (P.hp < P.mhp * 0.35 && P.med <= 0 && P.cr > 400) { const s = tgtN('gen1'); if (s) return Object.assign(s, { shop: 1 }); }
    const lowAmmo = P.g.every((it) => !it || P.am[wStat(it).am] + P.mag[P.g.indexOf(it)] < 10);
    if (lowAmmo && P.cr > 300) { const s = tgtN('gen1'); if (s) return Object.assign(s, { shop: 1 }); }
    if (q.m === 0) return tgtN('doc');
    if (q.m === 1) return tgtN('fix');
    if (q.m === 2) { if (P.cr >= 1500) return tgtN('ndb'); const t = W.term.find((x) => x.kind === 'm2'); return t ? { x: t.x, y: t.y, term: t.id } : null; }
    if (q.m === 3) return tgtN('ghb');
    if (q.m === 4) { const e = W.en.filter((x) => x.hp > 0 && x.q && x.q.indexOf('m4') >= 0).sort((a, b) => hyp(a.x - P.x, a.y - P.y) - hyp(b.x - P.x, b.y - P.y))[0]; return e ? { x: e.x, y: e.y, en: e.id } : null; }
    if (q.m === 5) return tgtN('fix');
    if (q.m === 6) {
      const f = mem.side || (mem.side = FKEYS.slice().sort((a, b) => W.rep[b] - W.rep[a])[0]);
      if (W.rep[f] >= 20 || !q.jobs.length) return tgtN(LEAD[f]);
    }
    if (q.m === 7) {
      const t = W.term.find((x) => x.kind === 'fin' && !x.done);
      const e = W.en.filter((x) => x.hp > 0 && x.q && x.q.indexOf('fin') >= 0).sort((a, b) => hyp(a.x - P.x, a.y - P.y) - hyp(b.x - P.x, b.y - P.y))[0];
      if (t && (!e || hyp(e.x - P.x, e.y - P.y) > 8 * T)) return { x: t.x, y: t.y, term: t.id };
      if (e) return { x: e.x, y: e.y, en: e.id };
      if (t) return { x: t.x, y: t.y, term: t.id };
    }
    if (q.m === 8) return tgtN(LEAD[q.f.side]);
    const j = q.jobs[0];
    if (j) {
      if (j.ty === 'bounty') { const e = W.en.find((x) => x.id === j.tid); if (e) return { x: e.x, y: e.y, en: e.id }; }
      if (j.ty === 'hack') { const t = W.term.find((x) => x.id === j.tid); if (t) return { x: t.x, y: t.y, term: t.id }; }
      if (j.ty === 'courier' || j.ty === 'rescue') { const n = N(j.tid); if (n) { const e = W.en.find((x) => x.hp > 0 && x.q === 'job' + j.id + ' hos' && hyp(x.x - n.x, x.y - n.y) < 10 * T); if (e) return { x: e.x, y: e.y, en: e.id }; return { x: n.x, y: n.y, npc: n.id }; } }
    }
    return null;
  }
  function botStep(W, mem, lv) {
    const M = genMap(W.seed), P = W.p, inp = { mx: 0, my: 0 };
    mem.t = (mem.t || 0) + 1;
    if (P.dead) return inp;
    // 레벨 점수
    while (P.pts > 0) { const k = P.at.t < 6 ? 't' : P.at.b <= P.at.r ? 'b' : 'r'; P.at[k]++; P.pts--; recalc(W); }
    if (mem.t % 90 === 0) autoEquip(W);
    if (P.g[P.cur] == null && P.g[1 - P.cur]) P.cur = 1 - P.cur;
    // 적
    let foe = null, fd = 1e9;
    for (const e of W.en) { if (e.hp <= 0 || !hostile(W, e)) continue; const d = hyp(e.x - P.x, e.y - P.y); if (d < 13 * T && d < fd && los(M, P.x, P.y, e.x, e.y) && (e.st === 2 || d < 9 * T || mem.goal && mem.goal.en === e.id)) { fd = d; foe = e; } }
    const G = mem.goal = botGoal(W, mem);
    let tx = G ? G.x : P.x, ty = G ? G.y : P.y;
    // 흐름장 길찾기
    const key = G ? Math.floor(tx / T) + ',' + Math.floor(ty / T) : '';
    if (key && (mem.fk !== key || !mem.fl || mem.t - mem.ft > 45)) { mem.fl = flow(M, tx, ty); mem.fk = key; mem.ft = mem.t; }
    let dir = null;
    if (G && hyp(tx - P.x, ty - P.y) > (G.npc || G.term ? 1.1 * T : 2 * T)) dir = mem.fl && flowDir(mem.fl, P.x, P.y);
    if (!dir && G && hyp(tx - P.x, ty - P.y) > 20 && los(M, P.x, P.y, tx, ty)) { const l = hyp(tx - P.x, ty - P.y); dir = { x: (tx - P.x) / l, y: (ty - P.y) / l }; }
    if (foe) {
      inp.ax = foe.x; inp.ay = foe.y;
      const aimNoise = lv === 1 ? 40 : lv === 3 ? 6 : 18; inp.ax += (R() - 0.5) * aimNoise; inp.ay += (R() - 0.5) * aimNoise;
      if (fd < 1.6 * T) inp.mel = 1; else if (P.g[P.cur]) inp.fire = (mem.t % (lv === 1 ? 3 : 1)) === 0;
      if (P.g[P.cur] && P.mag[P.cur] <= 0) { if (P.am[wStat(P.g[P.cur]).am] <= 0 && P.g[1 - P.cur]) P.cur = 1 - P.cur; else inp.rl = 1; }
      const qk = P.qh.indexOf('sc') >= 0 && P.ram >= qhCost(W, 'sc') + 2 ? 'sc' : null; if (qk && mem.t % 20 === 0) { inp.hack = qk; inp.tgt = foe.id; }
      const side = Math.sin(mem.t / 40) > 0 ? 1 : -1, a = Math.atan2(foe.y - P.y, foe.x - P.x);
      inp.mx = -Math.sin(a) * side * 0.7 + (fd > 6 * T ? Math.cos(a) * 0.6 : 0); inp.my = Math.cos(a) * side * 0.7 + (fd > 6 * T ? Math.sin(a) * 0.6 : 0);
      if (dir && fd > 7 * T) { inp.mx = dir.x; inp.my = dir.y; }
    } else if (dir) { inp.mx = dir.x; inp.my = dir.y; inp.ax = P.x + dir.x * 100; inp.ay = P.y + dir.y * 100; inp.sprint = 1; }
    if (P.hp < P.mhp * 0.4) useMed(W);
    if (P.g[P.cur] && !foe && P.mag[P.cur] < wStat(P.g[P.cur]).mag * 0.4) inp.rl = 1;
    // 끼임 풀기
    if (mem.t % 120 === 0) { if (mem.lp && hyp(mem.lp.x - P.x, mem.lp.y - P.y) < 20 && G) mem.jit = 40; mem.lp = { x: P.x, y: P.y }; }
    if (mem.jit > 0) { mem.jit--; const a = mem.t * 0.37; inp.mx = Math.cos(a); inp.my = Math.sin(a); }
    return inp;
  }
  // 상호작용 결정: 지금 닿은 대상 → 무엇을 할지
  function botWants(W, mem) {
    const G = mem.goal; if (!G) return null;
    const it = interact(W); if (!it) return null;
    if (it.k === 'talk' && G.npc === it.npc.id) return it;
    if (it.k === 'term' && G.term === it.term.id && !it.term.done && !(it.term.lock > W.t)) return it;
    return null;
  }
  function botChoice(W, N, mem) { // 대화 선택
    const ok = N.c.map((c, i) => (c.why ? -1 : i)).filter((i) => i >= 0);
    if (!ok.length) return 0;
    if (mem.goal && mem.goal.shop) { const i = ok.find((k) => N.c[k].t === '물건 보기'); if (i != null) return i; }
    const txt = (i) => N.c[i].t;
    const pref = ['[결말]', '[결정]', '[수락]', '[전투', '마지막 일', '[기술 6]', '사겠다', '같이 뚫어', '[바늘회 평판', '[건넨다]', '[풀어 준다]', '명심', '바로 간다', '간다', '생각해 볼게'];
    if (N.c.some((c) => /^\[결말\]/.test(c.t))) { const es = ok.filter((i) => /^\[결말\]/.test(txt(i))); return es[(mem.endPick || 0) % es.length]; }
    if (W.q.m === 6 || W.q.m >= 5 || mem.goal && !mem.goal.shop) { const j = ok.find((i) => /크레딧 ·/.test(txt(i)) && W.q.jobs.length < 2); if (j != null && N.c.some((c) => c.t === '지금은 됐어.')) return j; }
    for (const p of pref) { const i = ok.find((k) => txt(k).indexOf(p) >= 0); if (i != null) return i; }
    const jobs = ok.find((i) => txt(i) === '일거리 있어?'); if (jobs != null && W.q.jobs.length < 2) return jobs;
    return ok[ok.length - 1];
  }


  // ═════════ 외부 그림·소리 (CC0) — 못 불러오면 절차적 그림·합성음으로 ═════════
  const PK = 'assets/neon/pack/';
  // 구역 음악: 첨탑(0) 맑은 신스, 시장(1)·폐허(5) 기본 곡, 항만(2) 로파이, 공장(3)·하층(4) 어두운 공장음. 싸움 중엔 기본 곡(빠른 비트)
  const MUS = ['mus_pynchon.mp3', 'mus_loaben.mp3', 'mus_void.ogg'];
  const trackFor = (d, fight) => (fight ? 'music' : ['mus0', 'music', 'mus1', 'mus2', 'mus2', 'music'][d] || 'music');
  const CREDITS = [
    ['Warped City (배경 스카이라인·네온 간판)', 'Luis Zuno (ansimuz)', 'https://opengameart.org/content/warped-city', 'CC0 (그림만 사용 · 음악은 쓰지 않음)'],
    ['Top-down Shooter (인물·소품·바닥)', 'Kenney', 'https://kenney.nl/assets/top-down-shooter', 'CC0'],
    ['Particle Pack (불꽃·연기·빛 효과)', 'Kenney', 'https://kenney.nl/assets/particle-pack', 'CC0'],
    ['Sci-fi Sounds (총·폭발·해킹·문 소리)', 'Kenney', 'https://kenney.nl/assets/sci-fi-sounds', 'CC0'],
    ['UI Pack - Sci-fi (조준선·유리 패널·숫자 글꼴)', 'Kenney', 'https://kenney.nl/assets/ui-pack-sci-fi', 'CC0'],
    ['Friendly Talk On a Robotic Battlefield (배경 음악)', 'illin', 'https://opengameart.org/content/friendly-talk-on-a-robotic-battlefield-looped', 'CC0'],
    ['Rain (loopable) (빗소리)', 'Ylmir', 'https://opengameart.org/content/rain-loopable', 'CC0'],
    ['Racing Pack (하늘을 나는 차)', 'Kenney', 'https://kenney.nl/assets/racing-pack', 'CC0'],
    ['PYNCHON (첨탑 지구 음악)', 'cinameng (James Gargette)', 'https://opengameart.org/node/118114', 'CC0'],
    ['Loaben (항만 음악)', 'cinameng (James Gargette)', 'https://opengameart.org/node/120743', 'CC0'],
    ['Claimed by the void… (공장·하층 음악)', 'glitchart · vitalezzz · Tricksntraps', 'https://opengameart.org/content/claimed-by-the-void-new-factory-ai-fight-and-simulation-unknown-vitalezzz-vs-tricksntraps', 'CC0'],
    ['Galmuri11 (제목용 한글 픽셀 글꼴)', 'Lee Minseo (quiple)', 'https://github.com/quiple/galmuri', 'SIL OFL 1.1'],
  ];
  const IMG = {}; let imgReq = false;
  function loadImgs() {
    if (imgReq || typeof Image === 'undefined') return; imgReq = true;
    ['chars.webp', 'props.webp', 'fx.webp', 'signs.webp', 'sky_a.webp', 'sky_b.webp', 'bld_far.webp', 'bld_near.webp', 'cross.png', 'cross_r.png', 'cars.webp', 'wpn_gun.png', 'wpn_machine.png', 'wpn_silencer.png'].forEach((f) => {
      const i = new Image(); i.onload = () => { i.ok = 1; }; i.onerror = () => { i.bad = 1; }; i.src = PK + f; IMG[f.split('.')[0]] = i;
    });
  }
  const imOk = (k) => !!(IMG[k] && IMG[k].ok);
  const TINT = new Map();
  function tinted(key, col) { // 흰 효과 그림에 색 입히기(64×64, 캐시)
    const id = key + col; let c = TINT.get(id); if (c) return c;
    const p = AS.fx[key]; if (!p || !imOk('fx')) return null;
    c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d');
    x.drawImage(IMG.fx, p[0], p[1], 64, 64, 0, 0, 64, 64); x.globalCompositeOperation = 'source-in'; x.fillStyle = col; x.fillRect(0, 0, 64, 64);
    TINT.set(id, c); return c;
  }
  // 인물 그림: 세력·종류별 모습(위에서 본 모습, 오른쪽을 봄)
  const CH_EN = { thug: 'manBrown', guard: 'soldier1', cop: 'soldier1', raider: 'zombie1', hacker: 'womanGreen', borg: 'robot1', heavy: 'robot1', sniper: 'soldier1', blade: 'survivor1', runner: 'manOld', psycho: 'robot1', boss: 'robot1', shield: 'soldier1', hound: 'manBlue' };
  const CH_CIV = ['manBlue', 'manOld', 'survivor1', 'womanGreen', 'manBrown', 'hitman1'];
  const poseOf = (w, rl) => (rl ? 'reload' : !w ? 'stand' : MB[w] ? 'hold' : w === 'sil' || w === 'smt' ? 'silencer' : w === 'smg' || w === 'ar' || w === 'lmg' ? 'machine' : 'gun');
  function drawChar(ctx, nm, pose, x, y, a, r, glow, alpha) {
    const C = AS.ch[nm], f = C && (C[pose] || C.stand); if (!f || !imOk('chars')) return false;
    if (glow) { const g = tinted('light1', glow); if (g) { ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.45 * (alpha == null ? 1 : alpha); ctx.drawImage(g, x - r * 2.2, y - r * 2.2, r * 4.4, r * 4.4); ctx.globalCompositeOperation = 'source-over'; } }
    ctx.globalAlpha = alpha == null ? 1 : alpha;
    ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 3, y + 4, r, r * 0.8, 0, 0, 6.283); ctx.fill();
    const k = r / 13; ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.drawImage(IMG.chars, f[0], f[1], f[2], f[3], -16 * k, -21.5 * k, f[2] * k, f[3] * k); ctx.restore();
    ctx.globalAlpha = 1; return true;
  }
  // 하늘선(인트로·결말·초상화 배경): 겹친 층을 천천히 흘림
  function drawSkyline(c, w, h, t, dark) {
    if (!imOk('sky_a') || !imOk('bld_near')) { const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#120a2a'); g.addColorStop(1, '#03040c'); c.fillStyle = g; c.fillRect(0, 0, w, h); return; }
    c.imageSmoothingEnabled = false;
    const k = h / 240, layer = (im, sp, yy, kk) => { const iw = im.width * kk, ih = im.height * kk; let x0 = -((t * sp) % iw); for (let x = x0; x < w; x += iw) c.drawImage(im, x, yy, iw, ih); };
    layer(IMG.sky_a, 4, 0, k); layer(IMG.sky_b, 8, 0, k);
    if (imOk('bld_far')) layer(IMG.bld_far, 14, h - IMG.bld_far.height * k * 1.6, k * 1.6);
    layer(IMG.bld_near, 26, h - IMG.bld_near.height * k * 1.1, k * 1.1);
    c.imageSmoothingEnabled = true;
    if (dark) { c.fillStyle = 'rgba(4,4,16,' + dark + ')'; c.fillRect(0, 0, w, h); }
  }

  // ═════════ 그림 (절차적) ═════════
  const UI = 'assets/neon/ui/';
  const ROLE_SIGN = { clinic: '시술소', bar: '술집', gun: '총포상', store: '잡화', akhq: 'ARKRA', uplink: '송신탑', ndhq: '바늘회', auction: '경매장', ashhq: '연합 회관', plant: '정수 공장', ghden: '???', node: '데이터 노드', camp: '약탈자 소굴' };
  const SIGNS = ['라멘', '호텔', '24시', '노래방', '수리', '전당포', '칩 수리', '세탁', '바', '약국', '클럽', '국수'];
  function drawPortrait(c, w, h, look, fa, t) {
    look = look || {}; const ac = look.ac || '#4fd8ff';
    const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#0a1430'); g.addColorStop(1, '#05070f'); c.fillStyle = g; c.fillRect(0, 0, w, h);
    if (imOk('sky_a')) { c.save(); c.globalAlpha = 0.55; drawSkyline(c, w, h, (t || 0) * 3, 0.35); c.restore(); }
    // 뒤 네온
    const rg = c.createRadialGradient(w * 0.5, h * 0.42, 10, w * 0.5, h * 0.42, w * 0.75); rg.addColorStop(0, ac + '55'); rg.addColorStop(1, 'transparent'); c.fillStyle = rg; c.fillRect(0, 0, w, h);
    c.strokeStyle = ac + '22'; c.lineWidth = 1; for (let y = 0; y < h; y += 6) { c.beginPath(); c.moveTo(0, y + 0.5); c.lineTo(w, y + 0.5); c.stroke(); }
    const cx = w / 2, hy = h * 0.4, hr = w * 0.2;
    // 어깨·옷
    c.fillStyle = '#141a2e'; c.beginPath(); c.moveTo(cx - w * 0.48, h); c.quadraticCurveTo(cx - w * 0.42, h * 0.66, cx - w * 0.12, h * 0.62); c.lineTo(cx + w * 0.12, h * 0.62); c.quadraticCurveTo(cx + w * 0.42, h * 0.66, cx + w * 0.48, h); c.fill();
    c.strokeStyle = ac; c.lineWidth = 3; c.shadowColor = ac; c.shadowBlur = 12; c.beginPath(); c.moveTo(cx - w * 0.12, h * 0.63); c.lineTo(cx - w * 0.2, h); c.moveTo(cx + w * 0.12, h * 0.63); c.lineTo(cx + w * 0.2, h); c.stroke(); c.shadowBlur = 0;
    // 목·얼굴
    c.fillStyle = look.sk || '#c9a080'; c.fillRect(cx - hr * 0.42, hy + hr * 0.7, hr * 0.84, hr * 1.0);
    c.beginPath(); c.ellipse(cx, hy, hr * 0.92, hr * 1.18, 0, 0, 6.283); c.fill();
    c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(cx + hr * 0.35, hy + hr * 0.1, hr * 0.5, hr * 1.05, 0, -1.2, 1.4); c.fill();
    // 머리
    c.fillStyle = look.hc || '#222'; const hs = look.hs || 1;
    c.beginPath();
    if (hs === 1) { c.ellipse(cx, hy - hr * 0.55, hr * 0.98, hr * 0.7, 0, Math.PI, 0); }
    else if (hs === 2) { c.ellipse(cx, hy - hr * 0.7, hr * 0.95, hr * 0.5, 0, Math.PI, 0); c.rect(cx - hr * 0.95, hy - hr * 0.7, hr * 0.3, hr * 1.2); }
    else if (hs === 3) { c.moveTo(cx - hr * 0.2, hy - hr * 1.6); c.lineTo(cx + hr * 0.2, hy - hr * 1.6); c.lineTo(cx + hr * 0.3, hy - hr * 0.8); c.lineTo(cx - hr * 0.3, hy - hr * 0.8); }
    else if (hs === 4) { c.ellipse(cx, hy - hr * 0.4, hr * 1.1, hr * 0.95, 0, Math.PI * 0.95, Math.PI * 2.05); c.rect(cx - hr * 1.1, hy - hr * 0.4, hr * 0.32, hr * 2); c.rect(cx + hr * 0.78, hy - hr * 0.4, hr * 0.32, hr * 2); }
    else if (hs === 5) { c.ellipse(cx - hr * 0.1, hy - hr * 0.75, hr * 0.95, hr * 0.48, -0.15, Math.PI, 0); }
    else if (hs === 6) { c.ellipse(cx, hy - hr * 0.6, hr * 1.0, hr * 0.62, 0, Math.PI, 0); c.rect(cx - hr * 0.2, hy - hr * 1.5, hr * 0.4, hr * 0.5); }
    else if (hs === 7) { c.rect(cx - hr, hy - hr * 1.15, hr * 2, hr * 0.4); }
    else { c.ellipse(cx, hy - hr * 0.3, hr * 1.15, hr * 1.1, 0, Math.PI * 0.9, Math.PI * 2.1); c.rect(cx - hr * 1.15, hy - hr * 0.3, hr * 0.4, hr * 2.4); c.rect(cx + hr * 0.75, hy - hr * 0.3, hr * 0.4, hr * 2.4); }
    c.fill();
    // 눈
    const ey = look.ey || '#4fd8ff', fl = 0.75 + 0.25 * Math.sin((t || 0) * 3);
    c.fillStyle = ey; c.shadowColor = ey; c.shadowBlur = 10 * fl;
    c.fillRect(cx - hr * 0.5, hy - hr * 0.05, hr * 0.32, hr * 0.1); c.fillRect(cx + hr * 0.18, hy - hr * 0.05, hr * 0.32, hr * 0.1); c.shadowBlur = 0;
    c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(cx - hr * 0.2, hy + hr * 0.55, hr * 0.4, hr * 0.06);
    // 사이버 선
    c.strokeStyle = ac + 'aa'; c.lineWidth = 2; c.beginPath(); c.moveTo(cx + hr * 0.6, hy - hr * 0.3); c.lineTo(cx + hr * 0.75, hy + hr * 0.2); c.lineTo(cx + hr * 0.55, hy + hr * 0.6); c.stroke();
    const gr = look.gear;
    c.shadowColor = ac; c.shadowBlur = 14;
    if (gr === 'goggle') { c.strokeStyle = ac; c.lineWidth = 5; c.strokeRect(cx - hr * 0.62, hy - hr * 0.2, hr * 1.24, hr * 0.4); }
    else if (gr === 'lens') { c.fillStyle = '#ff3050'; c.beginPath(); c.arc(cx - hr * 0.34, hy, hr * 0.22, 0, 6.283); c.fill(); }
    else if (gr === 'visor') { c.fillStyle = ac + 'cc'; c.fillRect(cx - hr * 0.85, hy - hr * 0.18, hr * 1.7, hr * 0.28); }
    else if (gr === 'scar') { c.strokeStyle = '#ff6f6f'; c.lineWidth = 3; c.beginPath(); c.moveTo(cx - hr * 0.6, hy - hr * 0.5); c.lineTo(cx - hr * 0.2, hy + hr * 0.5); c.stroke(); }
    else if (gr === 'pins') { c.fillStyle = '#e8e8f0'; for (let i = 0; i < 5; i++) c.fillRect(cx - hr * 0.8 + i * hr * 0.4, hy - hr * 1.35, 3, hr * 0.35); }
    else if (gr === 'weld') { c.fillStyle = '#2a2420'; c.fillRect(cx - hr * 0.95, hy - hr * 0.6, hr * 1.9, hr * 1.5); c.fillStyle = ac; c.fillRect(cx - hr * 0.7, hy - hr * 0.15, hr * 1.4, hr * 0.22); }
    else if (gr === 'mirror') { const mg = c.createLinearGradient(cx - hr, hy - hr, cx + hr, hy + hr); mg.addColorStop(0, '#e8fff0'); mg.addColorStop(0.5, '#4a6a5a'); mg.addColorStop(1, '#c8ffd8'); c.fillStyle = mg; c.beginPath(); c.ellipse(cx, hy + hr * 0.05, hr * 0.9, hr * 1.1, 0, 0, 6.283); c.fill(); c.fillStyle = ac; c.fillRect(cx - hr * 0.5, hy - hr * 0.05, hr, hr * 0.06); }
    else if (gr === 'hood') { c.fillStyle = '#1a2038'; c.beginPath(); c.ellipse(cx, hy - hr * 0.2, hr * 1.3, hr * 1.45, 0, Math.PI * 0.85, Math.PI * 2.15); c.lineTo(cx + hr * 1.2, hy + hr * 1.4); c.lineTo(cx + hr * 0.85, hy + hr * 1.3); c.lineTo(cx + hr * 0.85, hy - hr * 0.2); c.ellipse(cx, hy - hr * 0.2, hr * 0.88, hr * 1.05, 0, 0, Math.PI, true); c.lineTo(cx - hr * 0.85, hy + hr * 1.3); c.lineTo(cx - hr * 1.2, hy + hr * 1.4); c.fill(); c.strokeStyle = '#ff4fd8'; c.lineWidth = 3; c.stroke(); }
    c.shadowBlur = 0;
    // 세력 표식
    if (fa && FA[fa]) { c.fillStyle = FA[fa].c; c.font = 'bold 18px sans-serif'; c.textAlign = 'right'; c.fillText(FA[fa].nm, w - 12, h - 14); }
  }
  const ME_LOOK = { sk: '#c49a80', hc: '#101018', hs: 2, ey: '#ff4fd8', ac: '#ff4fd8', gear: 'hood' };

  const CSS = `
  .nx{position:absolute;inset:0;pointer-events:none;font-family:var(--f-body),sans-serif;color:#dfe8ff;user-select:none}
  .nx *{box-sizing:border-box}
  .nx .pe{pointer-events:auto}
  .nx-hud{position:absolute;left:10px;top:10px;width:250px;background:rgba(6,10,26,.78);border:1px solid #2a4a7a;border-left:3px solid #4fd8ff;padding:8px 10px;border-radius:4px;font-size:12px}
  .nx-hud .nm{font-family:var(--f-body),sans-serif;font-weight:700;font-size:15px;color:#fff;display:flex;justify-content:space-between}
  .nx-bar{height:9px;background:#0b1430;border:1px solid #20304f;margin:3px 0 1px;position:relative}
  .nx-bar i{position:absolute;left:0;top:0;bottom:0;background:var(--c)}
  .nx-bl{display:flex;justify-content:space-between;font-size:11px;color:#9fb3d8}
  .nx-bl b{font-family:var(--f-mono),monospace;color:#e8f0ff;font-weight:600}
  .nx-obj{position:absolute;left:10px;top:204px;width:320px;font-size:12.5px;line-height:1.35}
  .nx-obj div{background:rgba(6,10,26,.66);margin-bottom:3px;padding:4px 8px;border-left:3px solid var(--c,#ffd040);border-radius:3px}
  .nx-obj .sub{opacity:.85;font-size:12px}
  .nx-obj .ch{font-size:11.5px;color:#9fb3d8;margin-bottom:3px;background:none;border:0;padding:0 2px;font-family:'NeonPix',var(--f-body),sans-serif}
  .nx-obj .ch span{font-family:var(--f-body),sans-serif;opacity:.75;margin-left:6px}
  .nx-obj .main{padding:6px 9px;border-left-width:4px;background:rgba(6,10,26,.82)}
  .nx-obj .main em{display:block;font-style:normal;font-size:11px;color:var(--c);letter-spacing:1px}
  .nx-obj .main b{font-size:14.5px;color:#fff}
  .nx-obj i{font-style:normal;font-family:var(--f-mono),monospace;color:var(--c);margin-left:6px;font-size:12px}
  .nx-obj .main small{display:block;color:#b8c8e8;font-size:12px;margin-top:3px;line-height:1.4}
  .nx-feed{position:absolute;left:10px;bottom:84px;width:340px;font-size:12.5px}
  .nx-feed div{background:rgba(6,10,26,.6);margin-top:2px;padding:2px 8px;border-radius:3px;transition:opacity .4s}
  .nx-qh{position:absolute;left:10px;bottom:10px;display:flex;gap:6px}
  .nx-qh div{width:62px;height:62px;background:rgba(6,14,26,.82);border:1px solid #2a6a5a;border-radius:5px;position:relative;font-size:11px;padding:4px;text-align:center;color:#bfffd0;overflow:hidden}
  .nx-qh div b{display:block;font-size:12px;color:#fff;margin-top:12px}
  .nx-qh div s{position:absolute;left:3px;top:2px;text-decoration:none;color:#7dff9a;font-family:var(--f-mono),monospace}
  .nx-qh div u{position:absolute;right:3px;top:2px;text-decoration:none;color:#9fb3d8}
  .nx-qh div em{position:absolute;left:0;right:0;bottom:0;background:rgba(0,0,0,.6);font-style:normal}
  .nx-wp{position:absolute;right:10px;bottom:10px;width:270px;background:rgba(6,10,26,.8);border:1px solid #4a2e6e;border-right:3px solid #ff4fd8;padding:8px 10px;border-radius:4px;font-size:12px}
  .nx-wp .big{font-family:var(--f-mono),monospace;font-size:24px;color:#fff}
  .nx-wp .row{display:flex;justify-content:space-between;gap:6px;color:#b8c4e0}
  .nx-wp .sl{display:flex;gap:4px;margin-top:4px}
  .nx-wp .sl span{flex:1;font-size:11px;padding:2px 4px;border:1px solid #333a5a;border-radius:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .nx-wp .sl span.on{border-color:#ff4fd8;color:#fff;background:rgba(255,79,216,.12)}
  .nx-mm{position:absolute;right:10px;top:58px;width:180px;height:120px;border:1px solid #2a4a7a;background:#050814;border-radius:4px}
  .nx-prompt{position:absolute;left:50%;bottom:110px;transform:translateX(-50%);background:rgba(6,10,26,.85);border:1px solid #4fd8ff;color:#fff;padding:6px 14px;border-radius:4px;font-size:14px;display:none;white-space:nowrap}
  .nx-prompt kbd{font-family:var(--f-mono),monospace;color:#4fd8ff;margin-right:6px}
  .nx-zone{position:absolute;left:50%;top:30%;transform:translateX(-50%);font-family:'NeonPix',var(--f-body),sans-serif;font-size:33px;letter-spacing:2px;text-shadow:0 0 14px currentColor;opacity:0;transition:opacity .6s;white-space:nowrap}
  .nx-keys{position:absolute;left:50%;bottom:10px;transform:translateX(-50%);font-size:11.5px;color:#9fb3d8;background:rgba(6,10,26,.7);padding:4px 10px;border-radius:4px;max-width:calc(100% - 640px);text-align:center;line-height:1.5}
  .nx-dead{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:rgba(40,0,20,.45);font-family:'NeonPix',var(--f-body),sans-serif;font-size:44px;color:#ff4fa3;text-shadow:0 0 18px #ff4fa3}
  .nx-modal{position:absolute;inset:0;background:rgba(2,4,12,.55);display:flex;align-items:center;justify-content:center;pointer-events:auto}
  .nx-pan{width:min(980px,calc(100% - 24px));max-height:calc(100% - 24px);background:#070b1c;border:1px solid #2a4a7a;border-top:3px solid #4fd8ff;border-radius:6px;display:flex;flex-direction:column;box-shadow:0 0 40px rgba(79,216,255,.15)}
  .nx-pan h3{margin:0;padding:10px 14px;font-family:'NeonPix',var(--f-body),sans-serif;font-weight:normal;font-size:22px;letter-spacing:.5px;color:#fff;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #1a2a4a}
  .nx-pan h3 small{font-family:var(--f-body),sans-serif;font-size:13px!important;color:#9fb3d8;margin-left:8px;font-weight:normal}
  .nx-pan h3 .nx-btn{font-family:var(--f-body),sans-serif;font-size:14px}
  .nx-pan .bd{padding:10px 14px;overflow:auto;flex:1;min-height:0}
  .nx-btn{min-height:44px;min-width:44px;padding:6px 12px;background:#0e1838;border:1px solid #4fd8ff;color:#dff;border-radius:4px;font:inherit;font-size:13px;cursor:pointer}
  .nx-btn:hover{background:#163060}.nx-btn[disabled]{opacity:.4;cursor:default}
  .nx-btn.m{border-color:#ff4fd8;color:#ffe0f6}
  .nx-cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .nx-sec{font-size:12px;color:#7fa0d0;margin:8px 0 4px;letter-spacing:1px}
  .nx-it{display:flex;align-items:center;gap:8px;min-height:44px;padding:4px 8px;margin-bottom:4px;background:#0b1230;border:1px solid #1e2c50;border-left:4px solid var(--r,#888);border-radius:4px;cursor:pointer;font-size:13px}
  .nx-it:hover{background:#13204a}
  .nx-cmp{font-style:normal;font-size:11px;padding:1px 5px;border-radius:3px;white-space:nowrap}.nx-cmp.up{color:#7dff9a;border:1px solid #2f7a4a}.nx-cmp.dn{color:#ff8f8f;border:1px solid #7a2f3a}
  .nx-it .p{margin-left:auto;font-family:var(--f-mono),monospace;color:#ffd040;white-space:nowrap}
  .nx-it .s{font-size:11px;color:#8fa0c8}
  .nx-tip{position:fixed;z-index:9999;max-width:300px;background:#060a18;border:1px solid #4fd8ff;padding:8px 10px;border-radius:4px;font-size:12px;line-height:1.45;color:#dfe8ff;pointer-events:none;display:none}
  .nx-tip .up{color:#7dff9a}.nx-tip .dn{color:#ff6f6f}
  .nx-tip h4{margin:0 0 4px;font-size:14px}
  .nx-grid{display:grid;grid-template-columns:repeat(5,60px);gap:5px;align-content:start;justify-content:center}
  .nx-cell{height:50px;border:1px solid #2a4a7a;background:#0a1230;color:#bff;font-family:var(--f-mono),monospace;font-size:20px;cursor:pointer;border-radius:4px}
  .nx-cell.act{border-color:#7dff9a;background:#0f2a24;box-shadow:0 0 10px rgba(125,255,154,.3)}
  .nx-cell.need{border:2px solid #ffd040;color:#fff}
  .nx-how{font-size:12.5px;line-height:1.55;background:#0a1230;border:1px solid #1e2c50;border-radius:4px;padding:8px 10px;margin-bottom:8px;max-width:330px}
  .nx-cell.used{opacity:.25;cursor:default}
  .nx-buf{display:flex;gap:6px;justify-content:center;margin:10px 0}
  .nx-buf span{width:46px;height:36px;border:1px dashed #4fd8ff;display:flex;align-items:center;justify-content:center;font-family:var(--f-mono),monospace;color:#fff}
  .nx-seq{font-family:var(--f-mono),monospace;font-size:15px;padding:4px 8px;margin:3px 0;border-left:3px solid #4fd8ff;background:#0a1230}
  .nx-seq.ok{border-color:#7dff9a;color:#7dff9a}
  .nx-dlg{position:absolute;left:50%;bottom:0;transform:translateX(-50%);pointer-events:auto;overflow:hidden}
  .nx-dsp{position:absolute;left:0;top:0;width:1672px;height:941px;transform-origin:0 0}
  .nx-dsp>*{position:absolute}
  .nx-dname{left:506px;top:206px;width:282px;height:88px;display:flex;align-items:center;justify-content:center;font-family:'NeonPix',var(--f-body),sans-serif;font-size:44px;color:#ffe6f6;text-shadow:0 0 12px #ff4fa3;white-space:nowrap;overflow:hidden}
  .nx-dtxt{left:528px;top:312px;width:1060px;height:206px;font-size:35px;line-height:1.5;color:#eaf2ff;overflow:auto;text-shadow:0 0 6px rgba(79,216,255,.25)}
  .nx-dtxt .ai{color:#c070ff;font-size:24px;margin-left:8px}
  .nx-dch{left:472px;top:524px;width:1130px;height:214px;overflow-y:auto;display:grid;grid-template-columns:574px 556px;align-content:start}
  .nx-dch.two{overflow:visible}
  .nx-ch{position:relative;height:var(--h,139px);cursor:pointer;background:none;border:0;padding:0;font:inherit;color:#fff;text-align:left}
  .nx-ch img{position:absolute;inset:0;width:100%;height:100%}
  .nx-ch span{position:absolute;left:58px;right:44px;top:0;bottom:0;display:flex;align-items:center;font-size:29px;line-height:1.25}
  .nx-ch kbd{position:absolute;left:24px;top:50%;transform:translateY(-50%);font-family:var(--f-mono),monospace;font-size:22px;color:#7ff}
  .nx-ch.m kbd{color:#f9c}
  .nx-ch:hover img{filter:brightness(1.35) drop-shadow(0 0 8px #4fd8ff)}
  .nx-ch.m:hover img{filter:brightness(1.35) drop-shadow(0 0 8px #ff4fd8)}
  .nx-ch.no{cursor:default;opacity:.45}
  .nx-ch.no:hover img{filter:none}
  .nx-ch small{display:block;font-size:20px;color:#ffb0b0}
  .nx-conf{left:1441px;top:649px;width:162px;height:86px;cursor:pointer;background:none;border:0;padding:0}
  .nx-conf img{position:absolute;inset:0;width:100%;height:100%}
  .nx-conf span{position:absolute;left:44px;right:0;top:0;bottom:0;display:flex;align-items:center;justify-content:center;font-size:22px;color:#dff;font-family:'NeonPix',var(--f-body),sans-serif}
  .nx-conf:hover img{filter:brightness(1.5) drop-shadow(0 0 8px #4fd8ff)}
  .nx-intro{position:absolute;inset:0;background:radial-gradient(circle at 50% 40%,rgba(40,10,60,.85),rgba(2,4,12,.95));display:flex;align-items:center;justify-content:center;pointer-events:auto}
  .nx-intro .c{max-width:640px;text-align:center;padding:20px}
  .nx-intro h2{font-family:'NeonPix',var(--f-body),sans-serif;font-weight:normal;font-size:66px;margin:0 0 6px;color:#fff;text-shadow:0 0 18px #ff4fd8,0 0 30px #4fd8ff}
  .nx-intro p{font-size:15px;line-height:1.6;color:#c8d4f0}
  .nx-rep{display:flex;align-items:center;gap:8px;margin:4px 0;font-size:13px}
  .nx-rep .nx-bar{flex:1;height:10px}
  .nx-cw{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
  .nx-cw div{min-height:54px;padding:5px 7px;border:1px solid #1e2c50;background:#0b1230;border-radius:4px;font-size:12px}
  .nx-cw div b{display:block;color:#fff;font-size:13px}
  .nx-attr{display:flex;align-items:center;gap:8px;margin:3px 0;font-size:13px}
  .nx-attr b{width:20px;text-align:center;font-family:var(--f-mono),monospace}
  .nx-map{width:100%;aspect-ratio:120/72;display:block;background:#04060f;border:1px solid #1e2c50}
  @font-face{font-family:'NeonNum';src:url('assets/neon/pack/future_narrow.ttf') format('truetype');font-display:swap}
  .nx-wp .big{font-family:var(--f-mono),monospace;font-weight:600;letter-spacing:1px}
  @font-face{font-family:'NeonPix';src:url('assets/neon/pack/galmuri11.woff2') format('woff2');font-display:swap}
  .nx-cell,.nx-buf span,.nx-seq{font-family:var(--f-mono),monospace;font-weight:600}
  .nx-hud,.nx-wp,.nx-pan{position:absolute}
  .nx-pan{position:relative}
  .nx-hud::after,.nx-wp::after,.nx-pan::after{content:'';position:absolute;inset:-2px;border:12px solid transparent;border-image:url('assets/neon/pack/panel.png') 24 / 12px stretch;opacity:.22;pointer-events:none;border-radius:6px}
  .nx-intro canvas,.nx-end canvas{position:absolute;inset:0;width:100%;height:100%}
  .nx-intro .c,.nx-end .c{position:relative}
  .nx-end{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:auto;background:#05030f}
  .nx-end .c{max-height:calc(100% - 30px);overflow:auto;max-width:760px;text-align:center;padding:24px 28px;background:rgba(4,4,16,.55);border:1px solid #4a2e6e;border-radius:8px}
  .nx-end small{color:#ff4fd8;letter-spacing:4px}
  .nx-end h2{font-family:'NeonPix',var(--f-body),sans-serif;font-weight:normal;font-size:44px;margin:4px 0 12px;color:#fff;text-shadow:0 0 18px #ff4fd8,0 0 34px #4fd8ff}
  .nx-end p{font-size:15px;line-height:1.55;color:#d8e2ff;margin:6px 0;opacity:0;animation:nxin .8s ease forwards}
  @keyframes nxin{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
  .nx-it img.wi{width:34px;height:22px;object-fit:contain;image-rendering:pixelated;filter:drop-shadow(0 0 4px var(--r,#888));flex:none}
  .nx-cell{transition:transform .08s}.nx-cell.act:hover{transform:scale(1.07);box-shadow:0 0 16px rgba(125,255,154,.55)}
  .nx-hint{position:absolute;left:50%;top:64px;transform:translateX(-50%);width:min(560px,calc(100% - 700px));min-width:380px;background:rgba(8,12,34,.92);border:1px solid #4fd8ff;border-left:4px solid #ffd040;border-radius:5px;padding:9px 14px 10px;font-size:14px;line-height:1.55;color:#e8f0ff;display:none;pointer-events:auto;cursor:pointer;box-shadow:0 0 24px rgba(79,216,255,.18)}
  .nx-hint h5{margin:0 0 3px;font-family:'NeonPix',var(--f-body),sans-serif;font-weight:normal;font-size:16px;color:#ffd040}
  .nx-hint kbd{display:inline-block;min-width:18px;padding:0 5px;margin:0 1px;border:1px solid #4fd8ff;border-radius:3px;font-family:var(--f-mono),monospace;font-size:12px;color:#7ff;background:#0a1838;line-height:18px;text-align:center}
  .nx-hint .x{float:right;font-size:11px;color:#8fa0c8}
  .nx-tabs{display:flex;gap:6px;margin-bottom:8px;flex-wrap:wrap}
  .nx-tabs .nx-btn.on{background:#163060;border-color:#ffd040;color:#fff}
  .nx-story{font-size:13.5px;line-height:1.6;margin:4px 0 8px;color:#c8d4f0}
  .nx-story.now{color:#fff;border-left:3px solid #ffd040;padding-left:8px}
  .nx-lore{background:#0b1230;border:1px solid #1e2c50;border-radius:4px;padding:7px 10px;margin-bottom:6px;font-size:13px}
  .nx-lore b{color:#ffd040;font-weight:600}
  .nx-lore p{margin:3px 0 0;line-height:1.55;color:#d0dcf4}
  .nx-side{font-size:12.5px;margin:3px 0;padding:3px 8px;border-left:3px solid #c070ff;background:#0b1230}
  `;

  // ═════════ 화면 ═════════
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  // 상황 안내(처음 한 번씩). k: 열쇠, t: 제목, b: 본문({키} 자리는 실제 키로 바뀜)
  const TIPS = {
    move: { t: '움직이기', b: '{up}{left}{down}{right} 걷기 · {sprint} 누르고 달리기 · 마우스로 보는 방향. 왼쪽 위 「지금 할 일」과 화면 가장자리의 노란 화살표가 갈 곳을 알려 줘요.' },
    talk: { t: '말 걸기', b: '사람 곁에서 {use}. 대화창에선 숫자 키로 고르고, {dash}/{use}로 다음 줄. 회색 선택지는 조건(돈·능력치·평판)이 모자란 것이에요.' },
    sneak: { t: '잠입', b: '{crouch}로 앉으면 덜 보이고 발소리가 작아요. 적 머리 위 「?」는 수상해하는 중, 「!」는 들킨 것. 눈치 못 챈 적을 뒤에서 근접 공격({melee}/오른쪽 클릭)하면 대부분 한 방이에요.' },
    fight: { t: '싸움', b: '왼쪽 클릭 쏘기 · {rl} 장전 · {nextw}/휠 무기 바꾸기 · {dash} 구르기(잠깐 무적). 상자·벽 뒤에 서면 총알을 막아 줘요. 체력이 낮으면 {heal} 치료 주사.' },
    hack: { t: '퀵해킹', b: '커서를 적 위에 올리고 {qh1}–{qh5}. 머릿속 해킹 칩의 기억 용량인 「RAM」(초록 막대)을 써요. RAM은 가만히 있어도 다시 차요. 「시야 교란」은 몰래 지나갈 때, 「단락」은 기계 적에게 좋아요.' },
    term: { t: '단말기', b: '{use}를 누르면 「회로 침투」 퍼즐이 열려요. 빛나는 줄에서 코드를 골라 목표 순서를 만들면 성공. 실패하면 경보가 울려요.' },
    loot: { t: '물건 줍기', b: '떨어진 물건은 밟고 지나가면 저절로 주워요. {inv}에서 장착하고, 마우스를 올리면 지금 장비와 비교해 줘요. 「잡동사니」는 상점에서 한 번에 팔 수 있어요.' },
    lowhp: { t: '체력이 낮아요', b: '{heal}로 치료 주사(체력 +50). 싸움이 끝나면 체력이 천천히 차요. 쓰러져도 게임은 끝나지 않고, 시술소에서 크레딧 일부를 내고 깨어나요.' },
    heat: { t: '열기 = 수배', b: '사람 많은 곳에서 총을 쏘거나 시민·경관을 다치게 하면 「열기」가 올라요. 30을 넘으면 도시 경찰 「질서국」이 쫓아와요. 숨어 있으면 내려가고, 중개인에게 돈을 주면 지워 줘요.' },
    lvl: { t: '레벨 업', b: '{inv}에서 능력치 점수를 써요. 몸 = 체력·근접, 반사 = 명중·치명타, 기술 = RAM·해킹. 대화 선택지 중엔 능력치가 있어야 고를 수 있는 것도 있어요.' },
    cyber: { t: '의체와 인간성', b: '의체(기계 몸)는 강하지만 달 때마다 「인간성」 최대치가 줄어요. 인간성이 25 아래면 RAM이 느리게 차고, 15 이하로 마지막 선택에 가면 결말이 바뀌어요. 시술소 「상담」으로 회복할 수 있어요.' },
    jobs: { t: '평판과 일거리', b: '세력 두목에게 「일거리」를 받아 끝내면 그 세력 평판 +12(맞수 세력은 조금 내려가요). 평판 20이 되면 그 세력의 마지막 일을 맡을 수 있어요. 일지({jour})에서 평판을 볼 수 있어요.' },
    metro: { t: '지하철 빠른 이동', b: '지도에 「M」으로 표시된 역에서 {use} → 가 본 구역으로 50₵에 이동해요. 지도는 {map}.' },
    dead: { t: '쓰러졌어요', b: '시술사가 살려 냈어요. 크레딧 15%를 치료비로 냈고 수배도 풀렸어요. 적이 많으면 앉아서 돌아가거나, 퀵해킹으로 하나씩 떼어 놓아요.' },
    side: { t: '부가 이야기', b: '머리 위에 보라 ✦가 뜬 사람은 자기 사정을 가진 인물이에요. 말을 걸면 부가 이야기가 시작되고, 어떻게 끝냈는지가 결말 후일담에 남아요.' },
    bike: { t: '오토바이', b: '건물 밖에서 {bike}로 타고 내려요. {sprint}로 더 빨라지고, 부딪힌 적은 넘어져요. 타는 동안엔 총·해킹을 못 써요.' },
  };
  const GLOSS = [
    ['크레딧 (₵)', '이 도시의 돈. 일거리·전리품으로 벌고 상점·지하철·치료비에 써요.'],
    ['흑요 코어', '모두가 노리는 검은 데이터 칩. 안에 아크라 기업의 비밀이 잠겨 있어요. 이야기의 중심.'],
    ['의체', '몸에 다는 기계 부품(눈·팔·다리·신경·피부·체계 6부위). 시술소에서 달아요.'],
    ['인간성', '내가 아직 사람으로 남아 있는 정도. 의체를 달수록 최대치가 줄고, 시민을 해치면 내려가요. 너무 낮으면 결말이 바뀌어요.'],
    ['사이버정신증', '의체가 사람을 삼켜 버린 상태. 인간성이 바닥나면 오는 병.'],
    ['RAM', '머릿속 해킹 칩의 기억 용량(초록 막대). 퀵해킹 한 번에 몇 칸씩 쓰고 시간이 지나면 다시 차요.'],
    ['퀵해킹', '멀리서 적의 장비·의체를 해킹하는 기술. 커서를 적 위에 두고 숫자 키.'],
    ['회로 침투', '단말기 보안을 푸는 퍼즐. 가로·세로를 번갈아 코드를 골라 목표 순서를 만들어요.'],
    ['열기 (수배)', '경찰이 나를 쫓는 정도(0–100). 30을 넘으면 질서국이 출동해요.'],
    ['질서국', '도시 경찰. 열기가 높으면 쫓아오고, 죽이면 열기가 더 올라요.'],
    ['평판', '세력이 나를 얼마나 믿는지(−100–100). 30 이상이면 그 세력 상점 할인, −30 이하면 적으로 봐요.'],
    ['일거리', '세력 두목·중개인이 주는 작은 의뢰. 돈과 평판을 줘요. 한 번에 셋까지.'],
    ['비살상', '죽이지 않고 기절시키는 공격(충격 곤봉·유압 망치). 인간성이 조금 올라요.'],
    ['기습 처치', '눈치 못 챈 적을 근접 공격하면 6배 피해. 두목·포탑은 안 돼요.'],
    ['의심 ? / 발견 !', '적 머리 위 표시. 「?」면 수상해서 다가오는 중, 「!」면 들켜서 공격해 와요.'],
    ['희귀도', '일반(흰)·고급(초록)·희귀(파랑)·전설(주황). 높을수록 세고 특성이 붙어요.'],
    ['불법 의체', '질서국이 금지한 의체. 달고 있으면 열기가 25% 더 빨리 올라요.'],
    ['네 세력', '아크라 기업(위층 대기업) · 바늘회(항만 암거래 조직) · 잿빛 연합(공장 노동자 조합) · 유령망(하층 해커 집단).'],
  ];
  const CHAP = (m) => (m <= 1 ? '1장 · 깨어남' : m === 2 ? '2장 · 흑요 코어' : m <= 4 ? '3장 · 하층' : m <= 6 ? '4장 · 누구의 편' : '5장 · 마지막 일');
  const TILEC = { 0: 'road', 1: 'side', 3: 'floor', 4: 'floor', 7: 'side' };
  function tipHTML(W, it, cmp) {
    if (!it) return '';
    const rc = it.r != null ? RAR[it.r].c : '#e8e8f0', rows = [];
    const diff = (a, b, fmt, lowGood) => { if (b == null || a === b) return fmt(a); const up = lowGood ? a < b : a > b; return fmt(a) + ' <span class="' + (up ? 'up' : 'dn') + '">(' + (a > b ? '▲' : '▼') + fmt(Math.abs(a - b)) + ')</span>'; };
    let h = '<h4 style="color:' + rc + '">' + esc(itName(it)) + '</h4>';
    if (it.k === 'w' || it.k === 'm') {
      const s = wStat(it), c = cmp ? wStat(cmp) : null, same = c && !!c.mel === !!s.mel;
      h += '<div>' + esc(s.ty) + (it.r != null ? ' · ' + RAR[it.r].nm : '') + '</div>';
      if (s.mel) { rows.push('피해 ' + diff(s.dmg, same ? c.dmg : null, (v) => v)); rows.push('초당 ' + s.rof + '회 · 사거리 ' + s.rch + '칸'); if (s.st) rows.push('기절 ' + s.st + '초' + (s.nl ? ' · 비살상(죽이지 않음)' : '')); }
      else {
        const dps = (q) => Math.round(q.dmg * q.pel * q.rof);
        rows.push('피해 ' + diff(s.dmg, same ? c.dmg : null, (v) => v) + (s.pel > 1 ? ' ×' + s.pel + '발' : ''));
        rows.push('초당 피해 ' + diff(dps(s), same ? dps(c) : null, (v) => v));
        rows.push('연사 ' + s.rof + '/초 · 탄창 ' + diff(s.mag, same ? c.mag : null, (v) => v));
        rows.push('정확도 ' + diff(Math.round((1 - s.spr * 2.2) * 100), same ? Math.round((1 - c.spr * 2.2) * 100) : null, (v) => v + '%') + ' · 사거리 ' + s.rng + '칸');
        rows.push('탄: ' + AMMO[s.am].nm + (s.sup ? ' · 소음' : '') + (s.hom ? ' · 유도' : '') + (s.pc ? ' · 관통' : ''));
        if (it.pk) rows.push('<span class="up">' + PERK[it.pk] + '</span>');
      }
      if (c && cmp !== it) rows.push('<span style="opacity:.7">비교: ' + esc(itName(cmp)) + '</span>');
    } else if (it.k === 'a') { const a = ARM[it.b], c = cmp && cmp.k === 'a' ? ARM[cmp.b] : null; rows.push('방어 ' + diff(Math.round(a.ar * RAR[it.r || 0].m), c ? Math.round(c.ar * RAR[cmp.r || 0].m) : null, (v) => v)); rows.push('이동 속도 ' + (a.sp ? Math.round(a.sp * 100) + '%' : '그대로')); }
    else if (it.k === 'c') { const C = CW[it.b], cur = W.p.cw[C.sl]; rows.push('부위: ' + SLOTS.find((s) => s[0] === C.sl)[1]); rows.push(esc(C.d)); rows.push('<span class="dn">인간성 −' + C.hum + '</span>' + (C.il ? ' · <span class="dn">불법(열기 ×1.25)</span>' : '')); if (cur && cur !== it.b) rows.push('<span style="opacity:.8">지금: ' + CW[cur].nm + ' (−' + CW[cur].hum + ') → 바꾸면 반값 돌려받음</span>'); }
    else if (it.k === 'h') { rows.push(esc(QH[it.b].d)); rows.push('RAM ' + QH[it.b].ram + ' · 대기 ' + QH[it.b].cd + '초'); }
    else if (it.k === 'x') rows.push(esc(CON[it.b].d));
    else if (it.k === 'q') rows.push('임무 물건');
    else rows.push('팔면 ' + sellPrice(it) + ' 크레딧');
    return h + rows.map((r) => '<div>' + r + '</div>').join('');
  }

  function mount(root, api) {
    const styleEl = document.createElement('style'); styleEl.textContent = CSS; root.appendChild(styleEl);
    const cv = U.canvas(root);
    const ui = document.createElement('div'); ui.className = 'nx'; root.appendChild(ui);
    const mk = (tag, cls, html, par) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; (par || ui).appendChild(e); return e; };
    const hud = mk('div', 'nx-hud'), objEl = mk('div', 'nx-obj'), feed = mk('div', 'nx-feed'), qhEl = mk('div', 'nx-qh'), wpEl = mk('div', 'nx-wp');
    const mmC = mk('canvas', 'nx-mm'), prompt = mk('div', 'nx-prompt'), zone = mk('div', 'nx-zone'), keys = mk('div', 'nx-keys'), deadEl = mk('div', 'nx-dead', '의식을 잃었다…');
    const tip = mk('div', 'nx-tip'), hintEl = mk('div', 'nx-hint');
    let trk = 0; // 추적 중인 목표(N으로 바꾸기)
    function trackObj(os) { os = os || Q.objs(W); const w = os.filter((o) => o.x != null && !(o.sub && o.main && os.some((q) => q.main && !q.sub && q.x != null))); if (!w.length) return os[0] || null; return w[((trk % w.length) + w.length) % w.length]; }
    mmC.width = 360; mmC.height = 240;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const bot = () => !!(api.players[0] && api.players[0].ai) || !!(L.debug && L.debug.autoplay);
    let st = null, W = null, M = null, mem = { endPick: Math.floor(Math.random() * 3) }, raf = 0, last = 0, modal = null, ended = false;
    let parts = [], floats = [], rings = [], shake = 0, hurtT = 0, flashC = null, zoneT = 0, lastD = -1, feedL = [], hudT = 0, botT = 0, sfxT = {};
    let mouse = { x: 0, y: 0, l: 0, r: 0, moved: 0 }, cam = { x: 0, y: 0, z: 1.5 }, hoverE = null, pend = {}, croT = false, mmBase = null, keysT = 14;
    const sfx = (n, o) => { const t = performance.now(); if (sfxT[n] && t - sfxT[n] < 70) return; sfxT[n] = t; try { api.sfx(n, o); } catch (e) {} };
    loadImgs();
    // ── 소리: 외부 효과음·음악·빗소리(Web Audio). 못 불러오면 core 합성음으로 ──
    const Au = {
      ac: null, buf: {}, out: null, mus: null, musF: null, musG: null, rainG: null, humG: null, failed: false, rate: 1,
      init() {
        if (this.el) { this.elLoops(); return; }
        if (this.ac || this.failed) { if (this.ac && this.ac.state === 'suspended') this.ac.resume().catch(() => {}); return; }
        try {
          this.ac = new (window.AudioContext || window.webkitAudioContext)(); this.out = this.ac.createGain(); this.out.connect(this.ac.destination);
          const fs = AS.sfx.map((k) => ['sfx/' + k + '.ogg', k]).concat([['music.ogg', 'music'], ['rain.ogg', 'rain']]);
          if (location.protocol === 'file:' || typeof fetch !== 'function') { this.el = {}; this.elN = 0; MUS.forEach((f, i) => fs.push([f, 'mus' + i])); fs.forEach(([f, k]) => { const a = new Audio(PK + f); a.preload = 'auto'; this.el[k] = a; }); this.elLoops(); return; }
          fs.forEach(([f, k]) => fetch(PK + f).then((r) => { if (!r.ok) throw new Error('x'); return r.arrayBuffer(); }).then((b) => new Promise((ok, no) => this.ac.decodeAudioData(b, ok, no))).then((bf) => { this.buf[k] = bf; this.loops(); }).catch(() => {}));
        } catch (e) { this.failed = true; }
      },
      loop(k, gainNode, rate) { const s = this.ac.createBufferSource(); s.buffer = this.buf[k]; s.loop = true; if (rate) s.playbackRate.value = rate; s.connect(gainNode); s.start(); return s; },
      loops() {
        const ac = this.ac; if (!ac) return;
        if (!this.musG) { this.musG = ac.createGain(); this.musG.gain.value = 0; this.musF = ac.createBiquadFilter(); this.musF.type = 'lowpass'; this.musF.frequency.value = 4000; this.musF.connect(this.musG).connect(this.out); this.trk = {}; }
        if (this.buf.music && !this.trk.music) { const g = ac.createGain(); g.gain.value = 0; g.connect(this.musF); this.trk.music = { g, s: this.loop('music', g) }; this.mus = this.trk.music.s; }
        MUS.forEach((f, i) => { const k = 'mus' + i; if (this.trk[k]) return; try { const a = new Audio(PK + f); a.loop = true; a.preload = 'none'; const g = ac.createGain(); g.gain.value = 0; ac.createMediaElementSource(a).connect(g); g.connect(this.musF); this.trk[k] = { g, a }; } catch (e) { this.trk[k] = { g: { gain: { setTargetAtTime() {} } } }; } });
        if (this.buf.rain && !this.rainG) { this.rainG = ac.createGain(); this.rainG.gain.value = 0; this.rainG.connect(this.out); this.loop('rain', this.rainG); }
        if (this.buf.hum && !this.humG) { this.humG = ac.createGain(); this.humG.gain.value = 0; this.humG.connect(this.out); this.loop('hum', this.humG, 0.6); }
      },
      elLoops() { // file:// 등 fetch를 못 쓸 때: <audio>로 고리 소리
        if (!this.el) return; this.elL = this.elL || {};
        for (const k of ['music', 'rain', 'hum'].concat(MUS.map((f, i) => 'mus' + i))) { const a = this.el[k]; if (!a || this.elL[k]) continue; a.loop = true; a.volume = 0; const pr = a.play(); if (pr && pr.then) pr.then(() => { this.elL[k] = a; }).catch(() => {}); else this.elL[k] = a; }
      },
      play(k, vol, rate, pan) {
        if (this.el) { const b = this.el[k]; if (!b || b.error) return false; const v = L.audio.sfx(); if (v <= 0) return true; if (this.elN > 10) return true;
          try { const c = b.cloneNode(); c.volume = clamp((vol == null ? 1 : vol) * v * 0.5, 0, 1); c.playbackRate = rate || 1; this.elN++; c.onended = () => { this.elN--; }; const pr = c.play(); if (pr && pr.catch) pr.catch(() => { this.elN--; }); } catch (e) {} return true; }
        const b = this.buf[k]; if (!b || !this.ac || this.ac.state !== 'running') return false;
        const v = L.audio.sfx(); if (v <= 0) return true;
        try { const s = this.ac.createBufferSource(), g = this.ac.createGain(); s.buffer = b; s.playbackRate.value = (rate || 1) * (0.95 + Math.random() * 0.1); g.gain.value = (vol == null ? 1 : vol) * v * 0.55;
          let node = g; if (pan && this.ac.createStereoPanner) { const pn = this.ac.createStereoPanner(); pn.pan.value = clamp(pan, -1, 1); g.connect(pn); node = pn; }
          s.connect(g); node.connect(this.out); s.start(); } catch (e) {}
        return true;
      },
      tick() {
        if (this.el && W) { this.elLoops(); const P = W.p, on = !(api.paused && api.paused()) && !document.hidden && !ended, d = P.d != null ? P.d : 1, inside = P.inside >= 0, L2 = this.elL || {};
          const want = trackFor(d, P.comb > 0); ['music'].concat(MUS.map((f, i) => 'mus' + i)).forEach((k) => { const a = L2[k]; if (!a) return; const tv = on && k === want ? clamp(L.audio.music() * (P.comb > 0 ? 0.4 : 0.28) * (inside ? 0.7 : 1), 0, 1) : 0; a.volume = clamp(a.volume + clamp(tv - a.volume, -0.02, 0.02), 0, 1); });
          if (L2.rain) L2.rain.volume = on ? clamp(L.audio.sfx() * 0.3 * (inside ? 0.3 : 1) * (d === 4 ? 0.45 : 1), 0, 1) : 0;
          if (L2.hum) L2.hum.volume = on ? clamp(L.audio.sfx() * (P.ride ? 0.5 : 0.1), 0, 1) : 0;
          return; }
        if (!this.ac || !W) return; const t = this.ac.currentTime, P = W.p, on = !(api.paused && api.paused()) && !document.hidden && !ended;
        const d = P.d != null ? P.d : 1, inside = P.inside >= 0, fight = P.comb > 0;
        // 구역 음악: 같은 곡을 구역마다 다른 음색(필터)·빠르기로 — 첨탑 맑게, 하층·폐허 어둡고 느리게
        const F = [9000, 5200, 3000, 2200, 1300, 900][d] * (fight ? 1.8 : 1) * (inside ? 0.6 : 1), RT = [1.04, 1, 0.94, 0.9, 0.86, 0.8][d] * (W.slow > 0 ? 0.7 : 1);
        if (this.musG) { let want = trackFor(d, fight); if (!this.trk[want]) want = 'music';
          this.musG.gain.setTargetAtTime(on ? L.audio.music() * (fight ? 0.42 : 0.3) : 0, t, 0.6); this.musF.frequency.setTargetAtTime(F * (want === 'music' ? 1 : 1.6), t, 0.8);
          if (this.trk[want] && this.trk[want].bad) want = 'music';
          for (const k in this.trk) { const tr = this.trk[k]; tr.g.gain.setTargetAtTime(k === want && on ? 1 : 0, t, 1.4); if (tr.a) { if (k === want && on && tr.a.paused) { tr.a.play().catch(() => { tr.bad = 1; }); tr.off = 0; } else if (k !== want && !tr.a.paused && (tr.off = (tr.off || 0) + 1) > 300) tr.a.pause(); } }
          if (this.mus && Math.abs(this.rate - RT) > 0.01) { this.rate = RT; this.mus.playbackRate.setTargetAtTime(RT, t, 1.2); } }
        if (this.rainG) this.rainG.gain.setTargetAtTime(on ? L.audio.sfx() * 0.3 * (inside ? 0.3 : 1) * (d === 4 ? 0.45 : 1) : 0, t, 0.5);
        if (this.humG) this.humG.gain.setTargetAtTime(on ? L.audio.sfx() * (P.ride ? 0.5 : d === 3 || d === 0 ? 0.16 : 0.08) : 0, t, 0.3);
        if (this.humG && this.humSrc !== P.ride) { this.humSrc = P.ride; }
      },
      close() { if (this.trk) for (const k in this.trk) { try { if (this.trk[k].a) { this.trk[k].a.pause(); this.trk[k].a.src = ''; } } catch (e) {} } try { if (this.ac) this.ac.close(); } catch (e) {} this.ac = null; if (this.elL) for (const k in this.elL) { try { this.elL[k].pause(); } catch (e) {} } this.elL = {}; this.el = null; this.failed = true; },
    };
    const gesture = () => Au.init();
    window.addEventListener('pointerdown', gesture, true); window.addEventListener('keydown', gesture, true);
    Au.init();
    const snd = (k, vol, rate, x, fb, fbo) => { let pan = 0; if (x != null && W) pan = (x - W.p.x) / (12 * T); if (!Au.play(k, vol, rate, pan) && fb) sfx(fb, fbo); };
    const imgs = {}; ['dialogue_frame.webp', 'portrait_slot_frame_only.png', 'choice_cyan.png', 'choice_magenta.png', 'confirm_button.png'].forEach((f) => { const i = new Image(); i.src = UI + f; imgs[f] = i; });
    const keyLbl = (id) => { try { const t = L.ui && L.ui.keyLabel ? L.ui.keyLabel(ID, id) : ''; if (t) return t; const b = api.input && api.input.bindings ? api.input.bindings().find((x) => x.id === id) : null; return b && b.keys && b.keys[0] ? b.keys[0].replace(/^Key|^Digit/, '') : ''; } catch (e) { return ''; } };

    // ── 입력 ──
    const toWorld = (sx, sy) => ({ x: (sx - cv.w / 2) / cam.z + cam.x, y: (sy - cv.h / 2) / cam.z + cam.y });
    const toScr = (x, y) => ({ x: (x - cam.x) * cam.z + cv.w / 2, y: (y - cam.y) * cam.z + cv.h / 2 });
    const cvEl = cv.cv;
    const onMove = (e) => { const p = cv.local(e); mouse.x = p.x; mouse.y = p.y; mouse.moved = 1; };
    const onDown = (e) => { onMove(e); if (modal) return; if (e.button === 2) mouse.r = 1; else mouse.l = 1; };
    const onUp = (e) => { if (e.button === 2) mouse.r = 0; else mouse.l = 0; };
    const onWheel = (e) => { if (modal || !W) return; e.preventDefault(); cycleW(e.deltaY > 0 ? 1 : -1); };
    cvEl.addEventListener('pointermove', onMove); cvEl.addEventListener('pointerdown', onDown); window.addEventListener('pointerup', onUp); cvEl.addEventListener('wheel', onWheel, { passive: false });
    const onKey = (e) => {
      if (e.code === 'Escape' && modal) { e.preventDefault(); e.stopPropagation(); if (modal.k === 'breach') breachEnd(false); else if (modal.k === 'dlg') dlgAdvance(-1, true); else closeModal(); }
      if (e.code === 'Tab') e.preventDefault();
    };
    window.addEventListener('keydown', onKey, true);
    function cycleW(d) { const P = W.p; const opts = [0, 1, 2].filter((i) => (i < 2 ? !!P.g[i] : true)); let k = opts.indexOf(P.cur); P.cur = opts[(k + d + opts.length) % opts.length]; P.rl = 0; sfx('click'); }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !W) return;
      if (modal) {
        if (modal.k === 'dlg') { const m = /^qh(\d)$/.exec(id); if (m) dlgAdvance(+m[1] - 1); else if (id === 'dash' || id === 'use') dlgAdvance(-1); return; }
        if ((id === 'inv' && modal.k === 'inv') || (id === 'map' && modal.k === 'map') || (id === 'jour' && modal.k === 'jour')) closeModal();
        return;
      }
      if (id === 'inv') return openInv();
      if (id === 'map') return openMap();
      if (id === 'jour') return openJournal();
      if (id === 'track') { trk++; const o = trackObj(); if (o) toastF('추적: ' + o.t, o.c || '#ffd040'); sfx('click'); return refreshHUD(); }
      if (id === 'use') return doUse();
      if (id === 'crouch') { croT = !croT; return; }
      if (id === 'nextw') return cycleW(1);
      if (id === 'w1' && W.p.g[0]) { W.p.cur = 0; W.p.rl = 0; return; }
      if (id === 'w2' && W.p.g[1]) { W.p.cur = 1; W.p.rl = 0; return; }
      if (id === 'w3') { W.p.cur = 2; W.p.rl = 0; return; }
      if (id === 'heal') { if (!useMed(W)) toastF(W.p.med <= 0 ? '치료 주사가 없어요' : '체력이 가득해요'); return; }
      if (id === 'ramc') { if (W.p.ramc > 0 && W.p.ram < W.p.mram) { W.p.ramc--; W.p.ram = W.p.mram; sfx('pop'); } return; }
      const m = /^qh(\d)$/.exec(id); if (m) { const k = W.p.qh[+m[1] - 1]; if (k) { pend.hack = k; pend.tgt = hoverE ? hoverE.id : 0; if (!pend.tgt && k !== 'ping') toastF('커서를 적 위에 올리고 쓰세요'); } return; }
      if (id === 'rl') pend.rl = 1; if (id === 'dash') pend.dash = 1; if (id === 'arm') pend.arm = 1;
      if (id === 'frag') pend.frag = 1; if (id === 'time') { if (!hasCW(W, 'sand')) toastF('시간 가속기(체계 의체)가 없어요'); else pend.time = 1; } if (id === 'bike') pend.bike = 1;
    }) : () => {};
    function humanInput() {
      const I = api.input, P = W.p, inp = {};
      if (I) { inp.mx = I.axis('left', 'right'); inp.my = I.axis('up', 'down'); inp.sprint = I.held('sprint'); inp.mel = I.held('melee') || mouse.r; inp.fire = I.held('fire') || mouse.l; }
      inp.cro = croT;
      let aim = toWorld(mouse.x, mouse.y);
      if (!mouse.moved) aim = { x: P.x + Math.cos(P.a) * 100, y: P.y + Math.sin(P.a) * 100 };
      if (I) { const rx = I.axis('aimL', 'aimR'), ry = I.axis('aimU', 'aimD'); if (hyp(rx, ry) > 0.3) { aim = { x: P.x + rx * 200, y: P.y + ry * 200 }; mouse.moved = 0; P.a = Math.atan2(ry, rx); } }
      inp.ax = aim.x; inp.ay = aim.y;
      if (hoverE) inp.tgt = hoverE.id;
      Object.assign(inp, pend); if (pend.tgt) inp.tgt = pend.tgt; pend = {};
      return inp;
    }
    function pickHover() {
      if (!W) return; const w = toWorld(mouse.x, mouse.y); let best = null, bd = 40 / cam.z + 14;
      for (const e of W.en) { if (e.hp <= 0 || !visE(e)) continue; const d = hyp(e.x - w.x, e.y - w.y); if (d < bd) { bd = d; best = e; } }
      if (!best && !mouse.moved) { const P = W.p; let ba = 0.4; for (const e of W.en) { if (e.hp <= 0 || !hostile(W, e) || !visE(e)) continue; const a = Math.abs(angD(P.a, Math.atan2(e.y - P.y, e.x - P.x))); if (a < ba && hyp(e.x - P.x, e.y - P.y) < 14 * T) { ba = a; best = e; } } }
      hoverE = best;
    }
    const visCache = new Map();
    function visE(e) {
      const P = W.p, d = hyp(e.x - P.x, e.y - P.y);
      if (P.ping > 0 && d < 12 * T) return true;
      if (hasCW(W, 'thm') && d < 10 * T) return true;
      const b = bldAt(M, e.x, e.y); if (b >= 0 && b !== P.inside) return false;
      if (d > 22 * T) return false;
      const k = e.id, c = visCache.get(k); if (c && c.t === frameN) return c.v;
      const v = los(M, P.x, P.y, e.x, e.y); visCache.set(k, { t: frameN, v }); return v;
    }
    function doUse() {
      const it = interact(W);
      if (!it) return;
      if (it.k === 'talk') openDlg(dlgFor(W, it.npc));
      else if (it.k === 'civ') openDlg({ d: 'amb', n: 's', npc: 'c' + it.civ.id });
      else if (it.k === 'term') { const t = it.term; if (t.done) toastF('이미 뚫은 단말기예요'); else if (t.lock > W.t) toastF('경보 중 — ' + Math.ceil(t.lock - W.t) + '초 뒤 다시'); else openBreach(t.lv, { term: t }); }
      else if (it.k === 'metro') openMetro();
    }
    // ── 상황 안내(처음 한 번씩) ──
    let hintQ = [], hintCur = null, hintT = 0;
    const tipsOn = () => !(st && st.tips === 'off') && !bot();
    function hint(k) { if (!W || !TIPS[k]) return; W.tips = W.tips || {}; if (W.tips[k]) return; W.tips[k] = 1; if (!tipsOn()) return; hintQ.push(k); }
    function showHint() {
      if (hintCur || !hintQ.length || modal) return; const k = hintQ.shift(), H = TIPS[k];
      const kb = (id) => { const l = keyLbl(id) || ({ up: 'W', down: 'S', left: 'A', right: 'D', sprint: 'Shift', fire: '왼쪽 클릭' })[id] || '?'; return '<kbd>' + esc(l.replace(/^Shift(Left|Right)$/, 'Shift').replace(/^Control(Left|Right)$/, 'Ctrl')) + '</kbd>'; };
      hintEl.innerHTML = '<span class="x">눌러서 닫기</span><h5>💡 ' + esc(H.t) + '</h5>' + esc(H.b).replace(/\{(\w+)\}/g, (m, id) => kb(id));
      hintEl.style.display = 'block'; hintCur = k; hintT = 11 + H.b.length / 30; sfx('pop', { vol: 0.3 });
    }
    hintEl.onclick = () => { hintEl.style.display = 'none'; hintCur = null; hintT = 0.6; };
    function hintTick(dt) {
      if (!W || ended) return; const P = W.p;
      if (hintCur) { if ((hintT -= dt) <= 0 || modal) { hintEl.style.display = 'none'; hintCur = null; hintT = 1.2; } }
      else if ((hintT -= dt) <= 0) showHint();
      if (modal) return;
      hint('move');
      if (interact(W)) hint('talk');
      if (W.q.m === 2) hint('sneak');
      const near = W.en.find((e) => e.hp > 0 && hostile(W, e) && hyp(e.x - P.x, e.y - P.y) < 12 * T && visE(e));
      if (near) { hint('fight'); if (W.tips.fight && P.ram >= 3) hint('hack'); }
      if (W.term.some((t) => !t.done && hyp(t.x - P.x, t.y - P.y) < 4 * T)) hint('term');
      if (P.inv.length) hint('loot');
      if (P.hp < P.mhp * 0.4 && !P.dead) hint('lowhp');
      if (P.heat >= 20) hint('heat');
      if (P.pts > 0) hint('lvl');
      if (W.st.died > 0 && !P.dead) hint('dead');
      if (W.q.m >= 6) hint('jobs');
      if (W.seen.filter((x) => x).length >= 2 && W.q.m >= 2) hint('metro');
      if (W.npc.some((n) => n.kind === 'side' && hyp(n.x - P.x, n.y - P.y) < 6 * T)) hint('side');
      if (P.bike) hint('bike');
      if (Object.keys(P.cw).some((k) => P.cw[k] && !(BG[W.bg] && BG[W.bg].cw === P.cw[k]))) hint('cyber');
    }
    function toastF(t, c) { feedL.push({ t, c: c || '#e8e8f0', at: performance.now() }); if (feedL.length > 7) feedL.shift(); drawFeed(); }

    // ── 모달 공통 ──
    function closeModal() { if (!modal) return; if (modal.k === 'end') { modal.done(); return; } if (modal.el) modal.el.remove(); if (modal.k === 'dlg') { W._amb = null; } modal = null; tip.style.display = 'none'; mouse.l = mouse.r = 0; refreshHUD(); }
    function panel(k, title, wide) {
      closeModal();
      const el = mk('div', 'nx-modal'); const p = mk('div', 'nx-pan', null, el); if (wide) p.style.width = 'min(1180px,calc(100% - 24px))';
      const h = mk('h3', null, '<span>' + title + '</span>', p); const x = mk('button', 'nx-btn', '닫기 ✕', h); x.onclick = closeModal; x.setAttribute('data-key', 'Escape');
      const bd = mk('div', 'bd', null, p);
      el.addEventListener('pointerdown', (e) => { if (e.target === el) closeModal(); });
      modal = { k, el, bd, p };
      return bd;
    }
    function bindTip(node, it, cmpF) {
      node.addEventListener('pointerenter', () => { tip.innerHTML = tipHTML(W, it, cmpF ? cmpF() : null); tip.style.display = 'block'; });
      node.addEventListener('pointermove', (e) => { const r = ui.getBoundingClientRect(); let x = e.clientX - r.left + 16, y = e.clientY - r.top + 12; const tw = tip.offsetWidth, th = tip.offsetHeight; if (x + tw > r.width - 6) x = e.clientX - r.left - tw - 12; if (y + th > r.height - 6) y = r.height - th - 6; tip.style.left = x + 'px'; tip.style.top = y + 'px'; });
      node.addEventListener('pointerleave', () => { tip.style.display = 'none'; });
    }
    tip.style.position = 'absolute';
    const cmpOf = (it) => () => { const P = W.p; if (it.k === 'w') return P.g[P.cur < 2 && P.g[P.cur] ? P.cur : 0] || P.g[1]; if (it.k === 'm') return P.m; if (it.k === 'a') return P.ar; return null; };
    const power = (it) => { if (!it) return 0; if (it.k === 'w') { const s = wStat(it); return s.dmg * s.pel * Math.min(s.rof, 8) * (1 + s.rng / 40); } if (it.k === 'm') { const s = wStat(it); return s.dmg * s.rof; } if (it.k === 'a') return ARM[it.b].ar * RAR[it.r || 0].m; return 0; };
    function cmpScore(it, cur) { if (!it || !cur || it === cur || it.k !== cur.k || !/^[wma]$/.test(it.k)) return 0; const a = power(it), b = power(cur); return a > b * 1.04 ? 1 : a < b * 0.96 ? -1 : 0; }
    let invF = 'all';
    function itemRow(par, it, right, onClick, cmpF) {
      const wi = it.k === 'w' ? '<img class="wi" src="' + PK + (/^(smg|ar|lmg|twin|dmr)$/.test(it.b) ? 'wpn_machine' : /^(sil|smt|tech)$/.test(it.b) ? 'wpn_silencer' : 'wpn_gun') + '.png" onerror="this.remove()">' : '';
      const r = mk('div', 'nx-it', wi + '<span>' + esc(itName(it)) + '<div class="s">' + esc(it.k === 'w' ? WB[it.b].ty + ' · ' + RAR[it.r].nm : it.k === 'm' ? MB[it.b].ty : it.k === 'a' ? '옷 · 방어 ' + Math.round(ARM[it.b].ar * RAR[it.r || 0].m) : it.k === 'c' ? '의체 · ' + SLOTS.find((s) => s[0] === CW[it.b].sl)[1] + ' · 인간성 −' + CW[it.b].hum : it.k === 'h' ? '퀵해킹 · RAM ' + QH[it.b].ram : it.k === 'q' ? '임무 물건' : '잡동사니') + '</div></span><span class="p">' + (right || '') + '</span>', par);
      r.style.setProperty('--r', it.r != null ? RAR[it.r].c : it.k === 'c' ? '#ff4fd8' : it.k === 'h' ? '#7dff9a' : '#666');
      const cv2 = cmpScore(it, (cmpF || cmpOf(it))()); if (cv2) { const bdg = document.createElement('em'); bdg.className = 'nx-cmp ' + (cv2 > 0 ? 'up' : 'dn'); bdg.textContent = cv2 > 0 ? '▲ 더 셈' : '▼ 약함'; const sp0 = r.querySelector('span'); if (sp0) sp0.after(bdg); }
      if (onClick) r.onclick = onClick; bindTip(r, it, cmpF || cmpOf(it)); return r;
    }

    // ── 소지품 ──
    function openInv() {
      const bd = panel('inv', '소지품 · 의체 <small style="font-size:12px;color:#9fb3d8">[' + (keyLbl('inv') || 'Tab') + ']</small>', true);
      const P = W.p, cols = mk('div', 'nx-cols', null, bd); cols.style.gridTemplateColumns = '1.1fr 1fr';
      const L1 = mk('div', null, null, cols), R1 = mk('div', null, null, cols);
      mk('div', 'nx-sec', '능력치' + (P.pts ? ' · <b style="color:#ffd040">남은 점수 ' + P.pts + '</b>' : ''), L1);
      [['b', '몸', '최대 체력 +10, 근접·위협 대화'], ['r', '반사', '정확도·치명타'], ['t', '기술', 'RAM +2, 회로 침투 시간·버퍼, 기술 대화']].forEach(([k, n, d]) => {
        const row = mk('div', 'nx-attr', '<span style="width:44px">' + n + '</span><b>' + P.at[k] + '</b><span style="flex:1;color:#8fa0c8;font-size:12px">' + d + '</span>', L1);
        if (P.pts > 0 && P.at[k] < 10) { const b = mk('button', 'nx-btn', '+', row); b.onclick = () => { P.at[k]++; P.pts--; recalc(W); if (k === 'b') P.hp += 10; openInv(); }; }
      });
      mk('div', 'nx-sec', '상태', L1);
      mk('div', null, '<div style="font-size:12.5px;line-height:1.7">체력 <b>' + Math.round(P.hp) + '/' + P.mhp + '</b> · 방어 <b>' + Math.round(pArmor(W)) + '</b> · 치명타 <b>' + Math.round(critCh(W) * 100) + '%</b> · 속도 <b>' + Math.round(pSpeed(W) / 1.5) + '%</b><br>RAM <b>' + Math.floor(P.ram) + '/' + P.mram + '</b> · 인간성 <b>' + Math.round(P.hum) + '</b> (최대 ' + P.humMax + ') · 열기 <b>' + Math.round(P.heat) + '</b>' + (P.il ? ' · <span style="color:#ff6f6f">불법 의체</span>' : '') + '<br>탄 경탄 <b>' + P.am.l + '</b> · 중탄 <b>' + P.am.h + '</b> · 산탄 <b>' + P.am.s + '</b> · 치료 주사 <b>' + P.med + '</b> · RAM 충전제 <b>' + P.ramc + '</b> · 수류탄 <b>' + P.frag + '</b>' + (P.bike ? ' · <span style="color:#ffd040">오토바이 있음 [B]</span>' : '') + '</div>', L1);
      mk('div', 'nx-sec', '장비 (마우스를 올리면 자세히)', L1);
      [[P.g[0], '1번 총'], [P.g[1], '2번 총'], [P.m, '근접'], [P.ar, '옷']].forEach(([it, lab]) => { if (it) itemRow(L1, it, lab, null, () => null); else mk('div', 'nx-it', '<span style="opacity:.5">' + lab + ' — 비어 있음</span>', L1); });
      mk('div', 'nx-sec', '퀵해킹 — 앞의 다섯 개가 숫자 키 1–5에 들어가요. 누르면 맨 앞으로', L1);
      const qg = mk('div', 'nx-tabs', null, L1); P.qh.forEach((k, i) => { const b = mk('button', 'nx-btn' + (i < 5 ? ' on' : ''), (i < 5 ? (i + 1) + ' · ' : '') + QH[k].nm + ' <small style="opacity:.7">RAM ' + qhCost(W, k) + '</small>', qg); b.title = QH[k].d; b.onclick = () => { P.qh.splice(i, 1); P.qh.unshift(k); sfx('click'); openInv(); }; });
      mk('div', 'nx-sec', '의체 (시술소에서 달고 바꿔요)', L1);
      const cwg = mk('div', 'nx-cw', null, L1);
      SLOTS.forEach(([s, n]) => { const k = P.cw[s]; const d = mk('div', null, '<span style="color:#8fa0c8">' + n + '</span><b>' + (k ? CW[k].nm : '—') + '</b>' + (k ? '<span style="color:#ff8fa0">인간성 −' + CW[k].hum + '</span>' : ''), cwg); if (k) bindTip(d, { k: 'c', b: k }, () => null); });
      mk('div', 'nx-sec', '가방 ' + P.inv.length + '/40 — 누르면 장착 · ▲▼는 지금 장비와 비교', R1);
      const ft = mk('div', 'nx-tabs', null, R1); [['all', '전부'], ['w', '총'], ['ma', '근접·옷'], ['j', '잡동사니·기타']].forEach(([k, t]) => { const b = mk('button', 'nx-btn' + (invF === k ? ' on' : ''), t, ft); b.onclick = () => { invF = k; openInv(); }; });
      if (!P.inv.length) mk('div', null, '<span style="opacity:.6">비어 있어요. 적이 떨어뜨린 물건 위를 지나가면 주워요.</span>', R1);
      P.inv.filter((it) => invF === 'all' || (invF === 'w' ? it.k === 'w' : invF === 'ma' ? it.k === 'm' || it.k === 'a' : !/^[wma]$/.test(it.k))).sort((a, b) => ('wmajq'.indexOf(a.k) - 'wmajq'.indexOf(b.k)) || ((b.r || 0) - (a.r || 0)) || (itVal(b) - itVal(a))).forEach((it) => {
        const lab = it.k === 'w' ? '장착' : it.k === 'm' || it.k === 'a' ? '장착' : it.k === 'j' ? sellPrice(it) + '₵' : '';
        const row = itemRow(R1, it, lab, () => { if (it.k === 'w') { equip(W, it, P.g[0] && P.g[1] ? P.cur < 2 ? P.cur : 0 : P.g[0] ? 1 : 0); sfx('click'); openInv(); } else if (it.k === 'm' || it.k === 'a') { equip(W, it, it.k); sfx('click'); openInv(); } });
        if (it.k === 'w') { const b2 = mk('button', 'nx-btn', P.cur === 1 ? '1번에' : '2번에', row); b2.onclick = (e) => { e.stopPropagation(); equip(W, it, P.cur === 1 ? 0 : 1); openInv(); }; }
        if (it.k !== 'q') { const b = mk('button', 'nx-btn m', '버리기', row); b.onclick = (e) => { e.stopPropagation(); P.inv.splice(P.inv.indexOf(it), 1); W.lo.push({ id: W.eid++, x: P.x + 20, y: P.y, it }); openInv(); }; }
      });
    }
    // ── 상점 ──
    function openShop(n) {
      const bd = panel('shop', esc(n.nm) + ' · <span style="color:#ffd040">' + W.p.cr + ' 크레딧</span>' + (n.fa && W.rep[n.fa] >= 30 ? ' <small style="color:#7dff9a">평판 할인 12%</small>' : n.fa && W.rep[n.fa] <= -10 ? ' <small style="color:#ff6f6f">평판 나빠 25% 비쌈</small>' : ''), true);
      const P = W.p, cols = mk('div', 'nx-cols', null, bd), A = mk('div', null, null, cols), B = mk('div', null, null, cols);
      const redo = (e) => { if (e) toastF(e, '#ff6f6f'); else sfx('chip'); openShop(n); };
      if (n.kind !== 'clinic') {
        mk('div', 'nx-sec', '보급품', A);
        const sup = [['l', '경탄 +' + AMMO.l.n, AMMO.l.val], ['h', '중탄 +' + AMMO.h.n, AMMO.h.val], ['s', '산탄 +' + AMMO.s.n, AMMO.s.val], ['med', '치료 주사 (가진 것 ' + P.med + ')', CON.med.val], ['ramc', 'RAM 충전제 (가진 것 ' + P.ramc + ')', CON.ramc.val], ['frag', '파편 수류탄 (가진 것 ' + P.frag + ')', CON.frag.val]];
        sup.forEach(([k, nm, v]) => { const r = mk('div', 'nx-it', '<span>' + nm + '</span><span class="p">' + Math.round(v * priceMul(W, n.fa)) + '₵</span>', A); r.onclick = () => redo(buySimple(W, n, k)); });
      } else {
        const r = mk('div', 'nx-it', '<span>인간성 상담 · 인간성 +10 (지금 ' + Math.round(P.hum) + '/' + P.humMax + ')<div class="s">의체를 많이 달수록 최대 인간성이 줄어요. 15 이하로 마지막 선택을 하면…</div></span><span class="p">' + Math.round(400 * priceMul(W, n.fa)) + '₵</span>', A); r.onclick = () => redo(buySimple(W, n, 'therapy'));
      }
      mk('div', 'nx-sec', n.kind === 'clinic' ? '의체 (사면 바로 시술 · 같은 부위는 바뀜)' : '진열대 (10분마다 바뀜)', A);
      const stock = shopStock(W, n); if (!stock.length) mk('div', null, '<span style="opacity:.6">다 팔렸어요.</span>', A);
      stock.forEach((it) => { const owned = it.k === 'c' && P.cw[CW[it.b].sl] === it.b; const r = itemRow(A, it, owned ? '장착 중' : buyPrice(W, n, it) + '₵', owned ? null : () => redo(buy(W, n, it))); if (owned) r.style.opacity = 0.5; });
      if (n.kind !== 'clinic') {
        mk('div', 'nx-sec', '내 가방 — 누르면 팔기 (값 높은 순)', B);
        const junk = P.inv.filter((it) => it.k === 'j'); if (junk.length) { const jb = mk('button', 'nx-btn', '잡동사니 ' + junk.length + '개 모두 팔기 (+' + junk.reduce((a, it) => a + sellPrice(it), 0) + '₵)', B); jb.style.cssText = 'width:100%;margin-bottom:6px;border-color:#ffd040'; jb.onclick = () => { junk.forEach((it) => sell(W, it)); redo(); }; }
        const worse = P.inv.filter((it) => /^[wma]$/.test(it.k) && cmpScore(it, cmpOf(it)()) < 0); if (worse.length) { const wb = mk('button', 'nx-btn m', '지금 장비보다 약한 것 ' + worse.length + '개 팔기 (+' + worse.reduce((a, it) => a + sellPrice(it), 0) + '₵)', B); wb.style.cssText = 'width:100%;margin-bottom:6px'; wb.onclick = () => { worse.forEach((it) => sell(W, it)); redo(); }; }
        P.inv.filter((it) => it.k !== 'q').sort((a, b) => itVal(b) - itVal(a)).forEach((it) => itemRow(B, it, '+' + sellPrice(it) + '₵', () => { sell(W, it); redo(); }));
        if (!P.inv.length) mk('div', null, '<span style="opacity:.6">팔 물건이 없어요.</span>', B);
      } else {
        mk('div', 'nx-sec', '지금 달린 의체', B);
        SLOTS.forEach(([s, nm]) => { const k = P.cw[s]; mk('div', 'nx-it', '<span>' + nm + ': <b>' + (k ? CW[k].nm : '—') + '</b><div class="s">' + (k ? esc(CW[k].d) : '비어 있음') + '</div></span><span class="p" style="color:#ff8fa0">' + (k ? '−' + CW[k].hum : '') + '</span>', B); });
        mk('div', null, '<div style="font-size:12px;color:#9fb3d8;margin-top:6px">불법 의체는 열기(수배)를 25% 더 빨리 올려요. 인간성이 25 아래면 RAM 회복이 느려지고, 15 이하면 결말이 바뀌어요.</div>', B);
      }
      if (bot()) { modal.botT = 0.9; }
    }
    // ── 지도 ──
    function mapBase() {
      if (mmBase && mmBase.seed === W.seed) return mmBase.c;
      const c = document.createElement('canvas'); c.width = MW * 4; c.height = MH * 4; const x = c.getContext('2d');
      for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) { const v = M.g[ty * MW + tx], D = DIST[distAt(tx * T, ty * T)];
        x.fillStyle = v === 0 ? '#1c2440' : v === 1 || v === 7 ? '#141a30' : v === 2 ? D.wall : v === 3 || v === 4 ? D.c2 : v === 5 ? '#06243a' : v === 6 ? '#28304a' : '#000'; x.fillRect(tx * 4, ty * 4, 4, 4); }
      for (let d = 0; d < 6; d++) { x.strokeStyle = DIST[d].c + '66'; x.lineWidth = 2; x.strokeRect((d % 3) * DWT * 4 + 1, ((d / 3) | 0) * DHT * 4 + 1, DWT * 4 - 2, DHT * 4 - 2); }
      mmBase = { seed: W.seed, c }; return c;
    }
    function drawMapMarks(x, s, big) {
      const P = W.p;
      M.metro.forEach((m, d) => { if (!m) return; x.fillStyle = W.seen[d] ? '#ffd040' : '#555'; x.font = 'bold ' + (big ? 13 : 9) + 'px sans-serif'; x.textAlign = 'center'; x.fillText('M', m[0] * s, m[1] * s + 4); });
      if (big) for (const n of W.npc) { if (n.kind === 'civ') continue; x.fillStyle = n.fa ? FA[n.fa].c : '#e8e8f0'; x.beginPath(); x.arc(n.x / T * s, n.y / T * s, 3, 0, 6.283); x.fill(); x.font = '11px sans-serif'; x.fillText(n.nm, n.x / T * s, n.y / T * s - 7); }
      Q.objs(W).forEach((o) => { if (o.x == null) return; x.strokeStyle = o.c || (o.main ? '#ffd040' : '#ff4fd8'); x.lineWidth = 2; const X = o.x / T * s, Y = o.y / T * s; x.beginPath(); x.moveTo(X, Y - 6); x.lineTo(X + 6, Y); x.lineTo(X, Y + 6); x.lineTo(X - 6, Y); x.closePath(); x.stroke(); });
      x.fillStyle = '#ff4fd8'; x.beginPath(); x.arc(P.x / T * s, P.y / T * s, big ? 5 : 4, 0, 6.283); x.fill(); x.strokeStyle = '#fff'; x.lineWidth = 1.5; x.stroke();
    }
    function openMap() {
      const bd = panel('map', '도시 지도 <small style="font-size:12px;color:#9fb3d8">◆ 목표 · M 지하철역(가 본 구역은 빠른 이동) · 점 = 인물</small>', true);
      const c = mk('canvas', 'nx-map', null, bd); c.width = MW * 10; c.height = MH * 10; const x = c.getContext('2d');
      x.imageSmoothingEnabled = false; x.drawImage(mapBase(), 0, 0, c.width, c.height);
      for (let d = 0; d < 6; d++) { const D = DIST[d]; x.fillStyle = D.c; x.font = 'bold 22px sans-serif'; x.textAlign = 'center'; x.globalAlpha = W.seen[d] ? 0.95 : 0.4; x.fillText(D.nm + (W.seen[d] ? '' : ' (안 가 봄)'), ((d % 3) + 0.5) * DWT * 10, ((d / 3 | 0) + 0.5) * DHT * 10); x.font = '14px sans-serif'; x.fillText((D.fa && FA[D.fa] ? FA[D.fa].nm : '중립') + ' · 위험 ' + '★'.repeat(D.lv), ((d % 3) + 0.5) * DWT * 10, ((d / 3 | 0) + 0.5) * DHT * 10 + 22); }
      x.globalAlpha = 1; drawMapMarks(x, 10, true);
    }
    // ── 일지 ──
    let jTab = 0;
    function openJournal(tab) {
      if (tab != null) jTab = tab;
      const bd = panel('jour', '일지 · ' + CHAP(W.q.m), true), P = W.p;
      const tabs = mk('div', 'nx-tabs', null, bd);
      ['할 일 · 이야기', '세력 · 기록', '기록 조각 ' + (W.lore || 0) + '/' + LORE.length, '용어 풀이'].forEach((t, k) => { const b = mk('button', 'nx-btn' + (k === jTab ? ' on' : ''), t, tabs); b.onclick = () => openJournal(k); });
      const cols = mk('div', 'nx-cols', null, bd), A = mk('div', null, null, cols), B = mk('div', null, null, cols);
      if (jTab === 0) {
        mk('div', 'nx-sec', '할 일 — 누르면 그 목표를 추적해요', A);
        const os = Q.objs(W), cur = trackObj(os);
        os.forEach((o) => { const r = mk('div', 'nx-it', '<span><span style="color:' + (o.c || (o.main ? '#ffd040' : '#e8e8f0')) + '">' + (o === cur ? '▶ ' : '') + esc(o.t) + '</span>' + (o.h ? '<div class="s">' + esc(o.h) + '</div>' : '') + '</span>' + (o.x != null ? '<span class="p">' + Math.round(hyp(o.x - P.x, o.y - P.y) / T) + 'm</span>' : ''), A);
          r.onclick = () => { const w = os.filter((q) => q.x != null && !(q.sub && q.main && os.some((z) => z.main && !z.sub && z.x != null))); const k = w.indexOf(o); if (k >= 0) { trk = k; sfx('click'); openJournal(); } }; });
        mk('div', 'nx-sec', '지금까지의 이야기', B);
        const upto = W.q.m;
        mk('div', null, STORY(W).slice(0, upto + 1).map((t, k) => '<p class="nx-story' + (k === upto ? ' now' : '') + '">' + esc(t) + '</p>').join(''), B);
      } else if (jTab === 1) {
        mk('div', 'nx-sec', '세력 평판 (−100 ~ 100) · 20↑ 마지막 일 가능 · 30↑ 상점 할인 · −30↓ 적으로 봄', A);
        FKEYS.forEach((f) => { const v = W.rep[f]; mk('div', 'nx-rep', '<span style="width:84px;color:' + FA[f].c + '">' + FA[f].nm + '</span><div class="nx-bar"><i style="--c:' + FA[f].c + ';left:' + (v < 0 ? 50 + v / 2 : 50) + '%;width:' + Math.abs(v) / 2 + '%"></i></div><b style="width:36px;text-align:right;font-family:var(--f-mono)">' + v + '</b>', A); mk('div', null, '<div style="font-size:12px;color:#8fa0c8;margin:-2px 0 6px 92px">' + esc(FA[f].d) + '</div>', A); });
        mk('div', 'nx-sec', '기록', A);
        const s = W.st; mk('div', null, '<div style="font-size:13px;line-height:1.8">처치 ' + s.kills + ' · 기절(살림) ' + s.ko + ' · 다친 시민 ' + s.civ + ' · 명중률 ' + (s.shots ? Math.round(s.hits / s.shots * 100) : 0) + '%<br>해킹 ' + s.hacks + ' · 끝낸 일거리 ' + s.jobs + ' · 번 돈 ' + s.earn + '₵ · 쓰러짐 ' + s.died + '<br>플레이 ' + Math.floor(W.t / 60) + '분</div>', A);
        mk('div', 'nx-sec', '부가 이야기', B);
        SKEYS.forEach((k) => { const S = W.q.s[k], st = S ? S.st : 0, fin2 = S && (S.gone || st >= (SIDE[k].fin || 3)); mk('div', 'nx-side', '<b style="color:' + (fin2 ? '#7dff9a' : st ? '#c070ff' : '#8fa0c8') + '">' + esc(SIDE[k].nm) + '</b> · ' + esc(DIST[SIDE[k].d].nm) + ' · ' + (fin2 ? '끝냄' : st ? '진행 중' : '아직 — ' + esc(SIDE[k].who) + '에게 말 걸기') + '<div style="font-size:12px;color:#9fb3d8">' + esc(SIDE[k].tz) + '</div>', B); });
        mk('div', 'nx-sec', '결말은 ' + Object.keys(ENDS).length + '가지 — 손잡은 세력, 마지막 선택, 인간성, 부가 이야기에 따라 달라져요.', B);
      } else if (jTab === 2) {
        mk('div', 'nx-sec', '단말기를 뚫거나 두목을 쓰러뜨리면 도시의 숨은 기록을 하나씩 얻어요.', A);
        const n = W.lore || 0;
        LORE.forEach((L2, k) => { const box = mk('div', 'nx-lore' + (k < n ? '' : ' no'), k < n ? '<b>' + esc(L2[0]) + '</b><p>' + esc(L2[1]) + '</p>' : '<b>??? — 아직 못 찾은 기록</b>', k % 2 ? B : A); box.style.opacity = k < n ? 1 : 0.45; });
      } else {
        GLOSS.forEach((g, k) => mk('div', 'nx-lore', '<b>' + esc(g[0]) + '</b><p>' + esc(g[1]) + '</p>', k % 2 ? B : A));
      }
    }
    function openMetro() {
      const bd = panel('metro', '지하철 · 빠른 이동 (50 크레딧)');
      DIST.forEach((D, d) => { const b = mk('button', 'nx-btn', D.nm + (W.seen[d] ? '' : ' — 안 가 봄'), bd); b.style.cssText = 'display:block;width:100%;margin:4px 0;text-align:left;border-color:' + D.c; b.disabled = !W.seen[d] || d === W.p.d; b.onclick = () => { const e = travel(W, d); if (e) toastF(e, '#ff6f6f'); else { closeModal(); sfx('whoosh'); } }; });
    }
    // ── 회로 침투 ──
    function openBreach(lv, ctx) {
      const B = breachNew(lv, W.p.at.t), bd = panel('breach', '회로 침투 · 난도 ' + '◆'.repeat(lv || 1) + ' <small>단말기 보안을 푸는 퍼즐</small>');
      modal.B = B; modal.ctx = ctx; modal.T0 = B.tl;
      const wrap = mk('div', null, null, bd); wrap.style.cssText = 'display:flex;gap:18px;flex-wrap:wrap;justify-content:center';
      const G = mk('div', 'nx-grid', null, wrap), side = mk('div', null, null, wrap); side.style.minWidth = '260px';
      const how = mk('div', 'nx-how', '<b>하는 법</b><br>① 초록으로 빛나는 줄에서 코드 하나를 눌러요.<br>② 그러면 그 칸의 <u>세로줄</u>이 빛나요. 거기서 또 하나.<br>③ 가로·세로를 번갈아 고르며, 고른 코드가 아래 <b>버퍼</b>에 쌓여요.<br>④ 버퍼 안에 <b style="color:#ffd040">목표 순서</b>가 그대로 나오면 성공! 버퍼 칸이 다 차면 끝나요.<br><span style="color:#9fb3d8">시간은 첫 칸을 누를 때부터 흘러요. 다음에 필요한 코드는 노란 테두리로 보여 줘요.</span>', side);
      const tb = mk('div', 'nx-bar', '<i style="--c:#7dff9a;width:100%"></i>', side), tl = mk('div', null, '', side), buf = mk('div', 'nx-buf', null, side), sq = mk('div', null, null, side);
      const give = mk('button', 'nx-btn m', '그만두기 (실패)', side); give.style.marginTop = '8px'; give.onclick = () => breachEnd(false);
      modal.draw = () => {
        const q0 = B.seqs[0]; let need = null; if (!B.done[0]) { let k = Math.min(q0.length - 1, B.buf.length); for (; k > 0; k--) if (B.buf.slice(-k).join(' ') === q0.slice(0, k).join(' ')) break; need = q0[k]; }
        G.innerHTML = ''; B.g.forEach((c, i) => { const r = (i / B.n) | 0, cc = i % B.n, act = !B.over && B.used.indexOf(i) < 0 && (B.mode === 'r' ? r === B.line : cc === B.line); const b = mk('button', 'nx-cell' + (act ? ' act' : '') + (act && c === need ? ' need' : '') + (B.used.indexOf(i) >= 0 ? ' used' : ''), c, G); b.classList.add('pe'); b.onclick = () => { if (breachPick(B, i)) { sfx('tick'); modal.draw(); if (B.over) setTimeout(() => modal && modal.B === B && breachEnd(!!B.done[0]), 350 / SPD()); } }; });
        buf.innerHTML = Array.from({ length: B.max }, (_, k) => '<span>' + (B.buf[k] || '') + '</span>').join('');
        sq.innerHTML = B.seqs.map((s, k) => '<div class="nx-seq' + (B.done[k] ? ' ok' : '') + '">' + s.join(' ') + ' <small>' + (k === 0 ? '— 목표 (꼭)' : k === 1 ? '— 덤: 크레딧 + RAM 가득' : '— 덤: 크레딧 더') + '</small>' + (B.done[k] ? ' ✓' : '') + '</div>').join('');
      };
      modal.tick = (dt) => { if (B.buf.length || bot()) B.tl -= dt; tb.firstChild.style.width = Math.max(0, B.tl / modal.T0 * 100) + '%'; tl.textContent = (B.buf.length ? '남은 시간 ' + Math.max(0, B.tl).toFixed(1) + '초' : '시간 ' + B.tl.toFixed(0) + '초 (첫 칸부터 흘러요)') + ' · 버퍼 ' + B.buf.length + '/' + B.max; if (B.tl <= 0 && !B.over) { B.over = 1; breachEnd(!!B.done[0]); } };
      modal.draw();
      if (bot()) { modal.seq = breachSolve(B); modal.botT = 0.6; }
      sfx('whoosh');
    }
    function breachEnd(ok) {
      if (!modal || modal.k !== 'breach') return;
      const B = modal.B, ctx = modal.ctx || {}; closeModal();
      sfx(ok ? 'win' : 'warn');
      if (ctx.term) termResult(W, ctx.term, ok, B);
      else if (ctx.tag === 'decrypt') { if (ok) { W.st.hacks++; openDlg({ d: 'gh3', n: 'rv', npc: 'ghb' }); } else toastF('침투 실패 — 거울가면에게 다시 말을 걸어요', '#ff6f6f'); }
    }
    // ── 대화 (사용자 그림 틀) ──
    function openDlg(ds) {
      closeModal(); if (!ds) return;
      const el = mk('div', 'nx-dlg'); const sp = mk('div', 'nx-dsp', null, el);
      const fr = mk('img', null, null, sp); fr.src = UI + 'dialogue_frame.webp'; fr.style.cssText = 'left:0;top:0;width:1672px;height:941px'; fr.draggable = false;
      const pc = mk('canvas', null, null, sp); pc.width = 334; pc.height = 420; pc.style.cssText = 'left:103px;top:257px;width:334px;height:420px';
      const pf = mk('img', null, null, sp); pf.src = UI + 'portrait_slot_frame_only.png'; pf.style.cssText = 'left:55px;top:203px;width:431px;height:527px'; pf.draggable = false;
      const nm = mk('div', 'nx-dname', '', sp), tx = mk('div', 'nx-dtxt', '', sp), ch = mk('div', 'nx-dch', '', sp);
      const cf = mk('button', 'nx-conf', '<img src="' + UI + 'confirm_button.png" draggable="false"><span>다음 ▶</span>', sp); cf.setAttribute('data-key', 'Space');
      cf.onclick = () => dlgAdvance(-1);
      tx.onclick = () => { if (modal && modal.typ < modal.full.length) modal.typ = 1e9; };
      modal = { k: 'dlg', el, sp, pc, nm, tx, ch, cf, ds, typ: 0, full: '', N: null, t: 0, ai: false };
      if (ds.d === 'amb') { const n = civNpc(W, ds.npc); W._amb = ambLine(W, n.d); askAmb(n, ds); }
      layoutDlg(); dlgRender(); sfx('click');
    }
    function askAmb(n, ds) {
      try {
        if (!(L.ai && L.ai.enabled && L.ai.enabled(ID))) return;
        const P = W.p, D = DIST[n.d];
        L.ai.ask({ tier: 'fast', maxTokens: 120, system: '너는 사이버펑크 도시 「네온 도시」의 행인이다. 한국어 반말로 한두 문장(60자 이내)만 말한다. 고유명사는 주어진 것만 쓰고 사람 이름은 만들지 않는다. 따옴표·괄호·이모지·영어 금지.',
          prompt: '장소: ' + D.nm + ' (' + D.d + ')\n말 거는 사람의 모습: ' + n.nm + '\n상대(주인공) 상태: 수배 열기 ' + Math.round(P.heat) + '/100, 인간성 ' + Math.round(P.hum) + '/100, 이야기 진행: ' + CHAP(W.q.m) + (W.q.m >= 4 ? ', 흑요 코어(아크라의 하층 정수 비밀) 소문이 돈다' : '') + '\n지나가는 주인공에게 할 한마디:' })
          .then((t) => { if (!t || !modal || modal.k !== 'dlg' || modal.ds !== ds) return; t = String(t).replace(/["'“”‘’()（）\[\]]/g, '').replace(/^[^:：]{0,8}[:：]\s*/, '').trim(); if (!t || /[A-Za-z]{4,}/.test(t) || t.length > 90) return; W._amb = t; modal.ai = true; dlgRender(); }).catch(() => {});
      } catch (e) {}
    }
    function layoutDlg() {
      if (!modal || modal.k !== 'dlg') return;
      const w = Math.min(cv.w * 0.98, cv.h * 2.3, 1500), k = w / 1672, h = 620 * k;
      modal.el.style.width = w + 'px'; modal.el.style.height = h + 'px';
      modal.sp.style.transform = 'scale(' + k + ') translateY(-170px)';
    }
    function dlgRender() {
      const m = modal; if (!m || m.k !== 'dlg') return;
      const N = dlgNode(W, m.ds); if (!N) { closeModal(); return; }
      m.N = N; m.full = N.t || ''; m.typ = bot() ? 0 : 0; m.t = 0;
      m.nm.textContent = N.nm; m.nm.style.fontSize = Math.min(44, Math.floor(262 / Math.max(1, [...String(N.nm)].length))) + 'px';
      const look = N.sp === 'me' ? ME_LOOK : N.look, fa = N.sp === 'me' ? null : N.fa;
      m.look = look; m.fa = fa;
      drawPortrait(m.pc.getContext('2d'), 334, 420, look, fa, 0);
      m.ch.innerHTML = ''; m.ch.className = 'nx-dch' + (N.c.length <= 2 ? ' two' : '');
      const many = N.c.length > 2, rowH = many ? 104 : 139;
      N.c.forEach((c, i) => {
        const mag = i % 2 === 1, b = mk('button', 'nx-ch' + (mag ? ' m' : '') + (c.why ? ' no' : ''), '<img src="' + UI + (mag ? 'choice_magenta.png' : 'choice_cyan.png') + '" draggable="false"><kbd>' + (i + 1) + '</kbd><span><span style="position:static;display:block">' + esc(c.t) + (c.why ? '<small>' + esc(c.why) + '</small>' : '') + '</span></span>', m.ch);
        b.style.setProperty('--h', (mag && !many ? 147 : rowH) + 'px'); if (mag && !many) b.style.marginTop = '-3px';
        if (many) b.querySelector('span').style.fontSize = '25px';
        b.onclick = () => dlgAdvance(i);
      });
      m.cf.style.display = N.c.length ? 'none' : '';
      m.ch.style.visibility = 'hidden';
      m.tx.innerHTML = '';
      m.botT = 1.3;
    }
    function dlgAdvance(i, close) {
      const m = modal; if (!m || m.k !== 'dlg') return;
      if (close) { if (!m.N || !m.N.c.length || m.N.c.some((c) => /나중에|됐어|생각해 볼게|잠깐/.test(c.t))) closeModal(); return; }
      if (m.typ < m.full.length) { m.typ = 1e9; return; }
      if (i < 0 && m.N.c.length) return;
      const r = dlgChoose(W, m.ds, i);
      if (r.err) { toastF(r.err, '#ff6f6f'); sfx('warn'); return; }
      sfx('click');
      if (W.end) { closeModal(); return; }
      if (r.ui) { closeModal(); if (r.ui.k === 'breach') openBreach(r.ui.lv, { tag: r.ui.tag }); else if (r.ui.k === 'shop') openShop(npcById(W, r.ui.npc)); return; }
      if (r.ds) { m.ds = r.ds; dlgRender(); } else closeModal();
      refreshHUD();
    }
    function dlgTick(dt) {
      const m = modal; if (!m.N) return;
      m.t += dt;
      if (m.typ < m.full.length) { m.typ += dt * 55 * Math.max(1, SPD()); const s = m.full.slice(0, Math.floor(m.typ)); m.tx.innerHTML = esc(s) + (m.ai ? '<span class="ai">✦</span>' : ''); if (m.typ >= m.full.length) m.ch.style.visibility = ''; }
      else if (m.ch.style.visibility) { m.tx.innerHTML = esc(m.full) + (m.ai ? '<span class="ai">✦</span>' : ''); m.ch.style.visibility = ''; }
      if ((m.pt = (m.pt || 0) + dt) > 0.12) { m.pt = 0; drawPortrait(m.pc.getContext('2d'), 334, 420, m.look, m.fa, m.t); }
      if (bot() && m.typ >= m.full.length) { m.botT -= dt * SPD(); if (m.botT <= 0) { const i = m.N.c.length ? botChoice(W, m.N, mem) : -1; dlgAdvance(i); } }
    }

    // ── 시작 안내 ──
    function intro() {
      const el = mk('div', 'nx-intro'), bgc = mk('canvas', null, null, el), c = mk('div', 'c', null, el);
      c.innerHTML = '<h2>네온 도시</h2><p>비가 그치지 않는 도시. 당신은 위험한 물건을 나르는 운반책이었다.<br>사흘 전 밤, 누군가 당신에게 총알 세 발을 박고 검은 데이터 칩 「흑요 코어」를 빼앗아 갔다.<br>시술소 침대에서 눈을 뜬 지금, 기억은 흐릿하고 빚은 선명하다.</p><p style="font-size:14px;color:#c8d4f0">왼쪽 위 <b style="color:#ffd040">「지금 할 일」</b>과 화면 가장자리의 노란 화살표를 따라가세요.<br>처음 겪는 일은 그때그때 짧은 안내가 떠요. 조작은 언제든 F1·Esc 메뉴에서 볼 수 있어요.</p><p style="font-size:13px;color:#9fb3d8">WASD 이동 · Shift 달리기 · Space 구르기 · 마우스 조준·사격 · 오른쪽 클릭 근접 · C 앉기 · E 말 걸기·조사<br>1–5 퀵해킹 · Tab 소지품 · J 일지 · M 지도 · N 목표 바꾸기</p>';
      const b = mk('button', 'nx-btn', '▶ 시작', c); b.style.cssText = 'font-size:18px;padding:10px 40px;border-color:#ff4fd8'; b.setAttribute('data-key', 'Enter');
      modal = { k: 'intro', el, botT: 1.2, t: 0, tick(dt) { this.t += dt; bgc.width = cv.w; bgc.height = cv.h; const x = bgc.getContext('2d'); drawSkyline(x, bgc.width, bgc.height, this.t * 8, 0.35);
        x.strokeStyle = 'rgba(160,190,255,.22)'; x.lineWidth = 1; x.beginPath(); for (let i = 0; i < 90; i++) { const rx = ((i * 97.3 + this.t * 40 * (1 + i % 3)) % bgc.width), ry = ((i * 53.7 + this.t * 600 * (0.7 + (i % 5) * 0.1)) % bgc.height); x.moveTo(rx, ry); x.lineTo(rx + 3, ry + 14); } x.stroke(); } };
      modal.tick(0);
      b.onclick = () => { closeModal(); zoneShow(DIST[1].nm, DIST[1].c); };
    }
    function zoneShow(t, c) { zone.textContent = t; zone.style.color = c; zone.style.opacity = 1; zoneT = 3; }

    // ── HUD ──
    function drawFeed() {
      const now = performance.now(); feedL = feedL.filter((f) => now - f.at < 7000);
      feed.innerHTML = feedL.map((f) => '<div style="color:' + f.c + ';opacity:' + Math.min(1, (7000 - (now - f.at)) / 1500) + '">' + esc(f.t) + '</div>').join('');
    }
    function refreshHUD() {
      if (!W) return; const P = W.p;
      const bar = (v, mx, c) => '<div class="nx-bar"><i style="--c:' + c + ';width:' + Math.max(0, Math.min(100, v / mx * 100)) + '%"></i></div>';
      hud.innerHTML = '<div class="nm"><span>' + esc(W.nm) + '</span><span style="color:#ffd040;font-family:var(--f-mono)">' + P.cr + '₵</span></div>' +
        '<div class="nx-bl"><span>체력</span><b>' + Math.ceil(P.hp) + '/' + P.mhp + '</b></div>' + bar(P.hp, P.mhp, P.hp < P.mhp * 0.3 ? '#ff4f6f' : '#ff4fd8') +
        '<div class="nx-bl"><span>RAM</span><b>' + Math.floor(P.ram) + '/' + P.mram + '</b></div>' + bar(P.ram, P.mram, '#7dff9a') +
        '<div class="nx-bl"><span>인간성</span><b style="color:' + (P.hum < 25 ? '#ff6f6f' : '') + '">' + Math.round(P.hum) + '/' + P.humMax + '</b></div>' + bar(P.hum, 100, '#4fd8ff') +
        '<div class="nx-bl"><span>' + (P.heat >= 30 ? '<b style="color:#ff4fa3">수배 중!</b>' : '열기') + '</span><b>' + Math.round(P.heat) + '</b></div>' + bar(P.heat, 100, P.heat >= 60 ? '#ff2050' : '#ffa040') +
        '<div class="nx-bl" style="margin-top:3px"><span>레벨 ' + P.lv + (P.pts ? ' <b style="color:#ffd040">+' + P.pts + '점</b>' : '') + '</span><span>' + DIST[P.d != null ? P.d : 1].nm + '</span></div>';
      const os = Q.objs(W), tg = trackObj(os), dist = (o) => (o && o.x != null ? Math.round(hyp(o.x - P.x, o.y - P.y) / T) + 'm' : '');
      objEl.innerHTML = '<div class="ch">' + CHAP(W.q.m) + ' <span>[' + (keyLbl('track') || 'N') + '] 목표 바꾸기 · [' + (keyLbl('jour') || 'J') + '] 일지</span></div>' +
        (tg ? '<div class="main" style="--c:' + (tg.c || (tg.main ? '#ffd040' : '#ff4fd8')) + '"><em>▶ 지금 할 일</em><b>' + esc(tg.t) + '</b>' + (tg.x != null ? '<i>' + dist(tg) + '</i>' : '') + (tg.h ? '<small>' + esc(tg.h) + '</small>' : '') + '</div>' : '') +
        os.filter((o) => o !== tg).slice(0, 4).map((o) => '<div class="sub" style="--c:' + (o.c || (o.main ? '#ffd040' : '#ff4fd8')) + '">' + esc(o.t) + (o.x != null ? ' <i>' + dist(o) + '</i>' : '') + '</div>').join('');
      qhEl.innerHTML = P.qh.slice(0, 5).map((k, i) => { const cd = P.cd.qh && P.cd.qh[k] > 0 ? P.cd.qh[k] : 0, cost = qhCost(W, k); return '<div style="' + (P.ram < cost ? 'opacity:.5' : '') + '"><s>' + (keyLbl('qh' + (i + 1)) || i + 1) + '</s><u>' + cost + '</u><b>' + QH[k].nm + '</b>' + (cd ? '<em>' + cd.toFixed(1) + '</em>' : '') + '</div>'; }).join('');
      const it = P.cur < 2 ? P.g[P.cur] : null, s = it ? wStat(it) : null;
      wpEl.innerHTML = '<div class="row"><span style="color:' + (it ? RAR[it.r].c : '#fff') + '">' + esc(P.cur < 2 ? (it ? itName(it) : '—') : (hasCW(W, 'mono') ? '단분자 와이어' : itName(P.m))) + '</span><span>' + (s ? AMMO[s.am].nm : '근접') + '</span></div>' +
        '<div class="row"><span class="big">' + (s ? (P.rl > 0 ? '장전…' : P.mag[P.cur] + ' / ' + P.am[s.am]) : '∞') + '</span><span style="align-self:flex-end">치료 ' + P.med + ' [' + (keyLbl('heal') || 'H') + ']</span></div>' +
        '<div class="sl">' + [0, 1, 2].map((i) => '<span class="' + (P.cur === i ? 'on' : '') + '">' + (i + 1) + ' ' + esc(i < 2 ? (P.g[i] ? WB[P.g[i].b].ty : '—') : '근접') + '</span>').join('') + '</div>' +
        ('<div class="row" style="margin-top:4px">' + (true ? '<span>' + (hasCW(W, 'dash') ? '돌진' : '구르기') + ' [' + (keyLbl('dash') || 'Space') + '] ' + ((P.cd.dash || 0) > 0 ? P.cd.dash.toFixed(1) + '초' : '준비') + '</span>' : '') + (hasCW(W, 'pjl') ? '<span>유탄 [' + (keyLbl('arm') || 'T') + '] ' + ((P.cd.arm || 0) > 0 ? P.cd.arm.toFixed(1) + '초' : '준비') + '</span>' : '') + '</div>') +
        '<div class="row" style="margin-top:4px"><span>수류탄 ' + P.frag + ' [' + (keyLbl('frag') || 'X') + ']</span>' + (hasCW(W, 'sand') ? '<span>시간 가속 [' + (keyLbl('time') || 'Z') + '] ' + ((P.cd.time || 0) > 0 ? P.cd.time.toFixed(0) + '초' : '준비') + '</span>' : '') + (P.bike ? '<span style="color:' + (P.ride ? '#ffd040' : '') + '">' + (P.ride ? '주행 중' : '오토바이') + ' [' + (keyLbl('bike') || 'B') + ']</span>' : '') + '</div>' +
        (P.cro ? '<div style="color:#7dff9a;margin-top:3px">앉음 (잠입)' + (P.camo ? ' · 광학 위장 중' : '') + '</div>' : '');
      // 상호작용 안내
      const itr = !modal && !P.dead ? interact(W) : null;
      if (itr) { prompt.style.display = 'block'; prompt.innerHTML = '<kbd>[' + (keyLbl('use') || 'E') + ']</kbd>' + esc(itr.k === 'talk' ? '대화 — ' + itr.npc.nm : itr.k === 'civ' ? '말 걸기' : itr.k === 'term' ? (itr.term.done ? '(뚫은 단말기)' : '단말기 해킹 — 회로 침투') : '지하철 타기'); }
      else prompt.style.display = 'none';
      deadEl.style.display = P.dead > 0 ? 'flex' : 'none';
      keys.style.display = keysT > 0 ? '' : 'none';
      drawFeed();
    }
    keys.innerHTML = 'WASD 이동 · Shift 달리기 · Space 구르기 · 클릭 사격 · 오른쪽 클릭 근접 · C 앉기 · E 말 걸기 · 1–5 퀵해킹 · Tab 소지품 · J 일지 · M 지도 · N 목표';
    function drawMini() {
      const x = mmC.getContext('2d'), P = W.p, s = 3; x.fillStyle = '#050814'; x.fillRect(0, 0, 360, 240);
      x.save(); x.translate(180 - P.x / T * s, 120 - P.y / T * s); x.imageSmoothingEnabled = false; x.drawImage(mapBase(), 0, 0, MW * s, MH * s);
      for (const e of W.en) if (e.hp > 0 && hostile(W, e) && visE(e)) { x.fillStyle = '#ff3050'; x.fillRect(e.x / T * s - 2, e.y / T * s - 2, 4, 4); }
      drawMapMarks(x, s, false); x.restore();
      // 화면 밖 목표 화살표
      const o = trackObj();
      if (o && o.x != null) { const dx = (o.x - P.x) / T * s, dy = (o.y - P.y) / T * s; if (Math.abs(dx) > 170 || Math.abs(dy) > 110) { const a = Math.atan2(dy, dx), k = Math.min(170 / Math.abs(Math.cos(a) || 1e-6), 110 / Math.abs(Math.sin(a) || 1e-6)); x.fillStyle = '#ffd040'; x.save(); x.translate(180 + Math.cos(a) * k * 0.95, 120 + Math.sin(a) * k * 0.95); x.rotate(a); x.beginPath(); x.moveTo(8, 0); x.lineTo(-6, -6); x.lineTo(-6, 6); x.fill(); x.restore(); } }
      x.strokeStyle = '#2a4a7a'; x.strokeRect(0.5, 0.5, 359, 239);
    }

    // ── 그리기 ──
    let lastIn = -2; let frameN = 0; const lamps = [], signGlow = [], flashes = [], decals = [];
    function drawBike(ctx, P, now) { // 오토바이(절차적): 몸체 + 네온 테두리 + 바퀴
      const a = P.ba || P.a; ctx.save(); ctx.translate(P.x, P.y); ctx.rotate(a);
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(4, 5, 24, 10, 0, 0, 6.283); ctx.fill();
      ctx.fillStyle = '#14141e'; ctx.fillRect(-24, -4, 10, 8); ctx.fillRect(14, -4, 10, 8);
      ctx.fillStyle = '#26203a'; ctx.beginPath(); ctx.moveTo(-18, -8); ctx.lineTo(16, -6); ctx.lineTo(22, 0); ctx.lineTo(16, 6); ctx.lineTo(-18, 8); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#ff4fd8'; ctx.lineWidth = 2; ctx.shadowColor = '#ff4fd8'; ctx.shadowBlur = 10; ctx.stroke(); ctx.shadowBlur = 0;
      ctx.fillStyle = '#4fd8ff'; ctx.fillRect(20, -2, 4, 4); ctx.restore();
      if (hyp(P.vx, P.vy) > 160) parts.push({ x: P.x - Math.cos(a) * 22, y: P.y - Math.sin(a) * 22, vx: -Math.cos(a) * 30, vy: -Math.sin(a) * 30, l: 0.3, l0: 0.3, c: '#ff4fd8', s: 18, spr: 'trace2', rot: a + Math.PI / 2, add: 1 });
    }
    const rain = Array.from({ length: 110 }, () => ({ x: Math.random(), y: Math.random(), s: 0.6 + Math.random() * 0.8 }));
    const FLOORK = { bar: 'wood', store: 'wood', clinic: 'tileW', akhq: 'tileW', uplink: 'tileW', gun: 'conc', auction: 'wood2', ndhq: 'wood2', ghden: 'conc', node: 'conc' };
    function floorKey(tx, ty) { const b = M.bid[ty * MW + tx]; if (b < 0) return null; const B = M.blds[b]; return FLOORK[B.role] || (B.d === 0 ? 'tileW' : B.d === 1 ? (B.sg % 2 ? 'wood' : 'conc') : 'conc'); }
    function drawTiles(ctx, x0, y0, x1, y1, now) {
      const P = W.p;
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
        const v = tAt(M, tx, ty), D = DIST[distAt(tx * T + 16, ty * T + 16)], X = tx * T, Y = ty * T;
        if (v === 9) { ctx.fillStyle = '#000'; ctx.fillRect(X, Y, T, T); continue; }
        if (v === 0) { ctx.fillStyle = D.road; ctx.fillRect(X, Y, T, T); { const h = (tx * 2654435761 ^ ty * 40503) >>> 0; if (h % 23 === 0) { ctx.fillStyle = D.c + '14'; ctx.beginPath(); ctx.ellipse(X + 16, Y + 16, 13, 6, (h % 7) * 0.4, 0, 6.283); ctx.fill(); ctx.fillStyle = 'rgba(160,190,255,.06)'; ctx.fillRect(X + 8, Y + 14, 14 + (h % 5), 1); } } if (tx % 14 === 1 && ty % 12 >= 3 && (ty & 1)) { ctx.fillStyle = D.c + '33'; ctx.fillRect(X + 15, Y + 4, 2, 24); } if (ty % 12 === 1 && tx % 14 >= 3 && (tx & 1)) { ctx.fillStyle = D.c + '33'; ctx.fillRect(X + 4, Y + 15, 24, 2); } continue; }
        if (v === 1 || v === 7) { ctx.fillStyle = D.side; ctx.fillRect(X, Y, T, T); ctx.strokeStyle = v === 7 ? D.c + '18' : 'rgba(255,255,255,.04)'; ctx.strokeRect(X + 0.5, Y + 0.5, T - 1, T - 1);
          if (v === 1 && tx % 14 === 3 && ty % 12 === 3) lamps.push({ x: X + 6, y: Y + 6, c: D.c });
          continue; }
        if (v === 5) { ctx.fillStyle = '#04192b'; ctx.fillRect(X, Y, T, T); const w = Math.sin(now / 700 + tx * 0.7 + ty * 1.3); ctx.fillStyle = 'rgba(79,216,255,' + (0.05 + 0.05 * w) + ')'; ctx.fillRect(X + 4, Y + 12 + w * 4, 18, 2); continue; }
        if (v === 3 || v === 4) { const fk = floorKey(tx, ty); if (fk && imOk('props')) { const r = AS.pr[fk]; ctx.drawImage(IMG.props, r[0], r[1], 64, 64, X, Y, T, T); ctx.globalAlpha = 0.55; ctx.fillStyle = D.floor; ctx.fillRect(X, Y, T, T); ctx.globalAlpha = 1; } else { ctx.fillStyle = D.floor; ctx.fillRect(X, Y, T, T); ctx.fillStyle = 'rgba(255,255,255,.03)'; ctx.fillRect(X, Y, T, 1); ctx.fillRect(X, Y, 1, T); } continue; }
        if (v === 2) { ctx.fillStyle = D.wall; ctx.fillRect(X, Y, T, T); ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(X, Y + T - 6, T, 6); continue; }
        if (v === 6 && imOk('props')) { const inB = bldAt(M, X + 16, Y + 16) >= 0, h = (tx * 73856093 ^ ty * 19349663) >>> 0, d0 = distAt(X + 16, Y + 16);
          ctx.fillStyle = inB ? D.floor : D.side; ctx.fillRect(X, Y, T, T);
          const pool = inB ? (d0 === 3 ? ['crate', 'barG', 'barO', 'tableS'] : ['chairG', 'chairB', 'tableS', 'tableR', 'stove', 'sink', 'hob', 'chairD', 'crateS']) : d0 === 5 ? ['rock', 'rock2', 'plank', 'debris', 'barX', 'crateR2'] : d0 === 2 ? ['crate', 'crateR', 'crate', 'barG', 'barO'] : ['crate', 'crateS', 'crateR', 'barO', 'barG', 'bush'];
          const r = AS.pr[pool[h % pool.length]]; ctx.drawImage(IMG.props, r[0], r[1], 64, 64, X - 2, Y - 2, T + 4, T + 4);
          ctx.strokeStyle = D.c + '40'; ctx.lineWidth = 1; ctx.strokeRect(X + 1.5, Y + 1.5, T - 3, T - 3); continue; }
        if (v === 6) { const under = bldAt(M, X + 16, Y + 16) >= 0 ? D.floor : D.side; ctx.fillStyle = under; ctx.fillRect(X, Y, T, T); ctx.fillStyle = ((tx * 7 + ty * 3) % 3 === 0) ? '#3a2a4a' : (tx + ty) % 2 ? '#22344e' : '#2e2a40'; ctx.fillRect(X + 2, Y + 2, T - 4, T - 4); ctx.strokeStyle = D.c + '55'; ctx.lineWidth = 1; ctx.strokeRect(X + 2.5, Y + 2.5, T - 5, T - 5); ctx.beginPath(); ctx.moveTo(X + 8, Y + 4); ctx.lineTo(X + 8, Y + T - 4); ctx.moveTo(X + 16, Y + 4); ctx.lineTo(X + 16, Y + T - 4); ctx.moveTo(X + 24, Y + 4); ctx.lineTo(X + 24, Y + T - 4); ctx.stroke(); }
      }
    }
    function drawRoofs(ctx, x0, y0, x1, y1, now) {
      const P = W.p;
      for (const b of M.blds) {
        if (b.x1 < x0 || b.x0 > x1 || b.y1 < y0 || b.y0 > y1) continue;
        const D = DIST[b.d], X = b.x0 * T, Y = b.y0 * T, w = (b.x1 - b.x0 + 1) * T, h = (b.y1 - b.y0 + 1) * T;
        if (b.id === P.inside) { ctx.strokeStyle = D.c + '66'; ctx.lineWidth = 2; ctx.strokeRect(X + 1, Y + 1, w - 2, h - 2); continue; }
        const g = ctx.createLinearGradient(X, Y, X + w, Y + h); g.addColorStop(0, D.c2); g.addColorStop(1, '#070a18'); ctx.fillStyle = g; ctx.fillRect(X, Y, w, h);
        ctx.fillStyle = 'rgba(255,255,255,.035)'; for (let i = 1; i < 3; i++) ctx.fillRect(X + 10, Y + h * i / 3, w - 20, 2);
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fillRect(X + w * 0.6, Y + 10, w * 0.25, h * 0.3);
        ctx.strokeStyle = D.c; ctx.globalAlpha = 0.75; ctx.lineWidth = 2; ctx.strokeRect(X + 3, Y + 3, w - 6, h - 6); ctx.globalAlpha = 1;
        // 간판
        if (!b.role && b.sg % 3 !== 0 && imOk('signs')) { // 외부 네온 간판: 지붕 위에 떠 있는 것처럼 화면 중심에서 조금 밀려 보임
          const kinds = ['big', 'neon', 'side', 'scroll', 'sushi', 'face', 'hotel'], kd = kinds[b.sg % kinds.length], fr = AS.sg[kd], f = fr[Math.floor(now / 170 + b.sg) % fr.length];
          const cols = { big: '#7dff9a', neon: '#ff4fd8', side: '#ff4fa3', scroll: '#4fd8ff', sushi: '#7dff9a', face: '#4fd8ff', hotel: '#ff4fa3' };
          const sc = kd === 'sushi' || kd === 'hotel' || kd === 'face' ? 1.6 : 1.05, sw = f[2] * sc, sh = f[3] * sc;
          const bx = X + w * (0.3 + (b.sg % 5) * 0.1), by = Y + h * 0.5, px = (bx - cam.x) * 0.07, py = (by - cam.y) * 0.07;
          const fl2 = b.ruin && Math.sin(now / 60 + b.sg) > 0.6 ? 0.25 : (Math.sin(now / 90 + b.sg) > 0.985 ? 0.4 : 1);
          ctx.fillStyle = 'rgba(0,0,0,.45)'; ctx.fillRect(bx - sw / 2 + 4, by - sh / 2 + 6, sw, sh);
          signGlow.push({ x: bx + px, y: by + py, r: Math.max(sw, sh) * 1.1, c: cols[kd], a: 0.5 * fl2 });
          ctx.globalAlpha = fl2; ctx.imageSmoothingEnabled = false; ctx.drawImage(IMG.signs, f[0], f[1], f[2], f[3], bx - sw / 2 + px, by - sh / 2 + py, sw, sh); ctx.imageSmoothingEnabled = true; ctx.globalAlpha = 1;
          if (b.d === 0 && AS.sg.antenna) { const a = AS.sg.antenna[0]; ctx.drawImage(IMG.signs, a[0], a[1], a[2], a[3], X + w * 0.8 + px * 1.6, Y + 6 + py * 1.6, a[2] * 0.7, a[3] * 0.7); }
          continue; }
        const sg = b.role ? ROLE_SIGN[b.role] : SIGNS[b.sg % SIGNS.length], fl = (Math.sin(now / 90 + b.sg) > 0.97) ? 0.35 : 1;
        if (sg && !(b.role === 'ghden' && W.q.m < 3)) { const sc = b.role ? (b.role === 'akhq' || b.role === 'uplink' ? '#4fd8ff' : b.role === 'ndhq' || b.role === 'auction' ? '#ff4fa3' : b.role === 'ashhq' || b.role === 'plant' ? '#ffa040' : b.role === 'ghden' || b.role === 'node' ? '#7dff9a' : '#ffd040') : ['#ff4fd8', '#4fd8ff', '#ffd040', '#7dff9a'][b.sg % 4];
          ctx.font = 'bold ' + (b.role ? 20 : 16) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.globalAlpha = fl; ctx.shadowColor = sc; ctx.shadowBlur = 12; ctx.fillStyle = sc; ctx.fillText(sg, X + w / 2, Y + h * 0.5); ctx.shadowBlur = 0; ctx.globalAlpha = 1;
          signGlow.push({ x: X + w / 2, y: Y + h * 0.5, r: 70, c: sc, a: 0.35 * fl }); }
      }
      // 문은 지붕 위에 표시
      for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (tAt(M, tx, ty) === 4) { const D = DIST[distAt(tx * T, ty * T)]; ctx.fillStyle = D.floor; ctx.fillRect(tx * T + 3, ty * T + 3, T - 6, T - 6); ctx.strokeStyle = D.c; ctx.lineWidth = 1.5; ctx.strokeRect(tx * T + 3.5, ty * T + 3.5, T - 7, T - 7); }
    }
    function drawMan(ctx, x, y, a, body, trim, r, o) {
      o = o || {};
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 3, y + 4, r, r * 0.8, 0, 0, 6.283); ctx.fill();
      ctx.save(); ctx.translate(x, y); ctx.rotate(a);
      if (o.gun) { ctx.fillStyle = '#1a1a22'; ctx.fillRect(r * 0.3, 2, r * 1.3, 4); ctx.fillStyle = trim; ctx.fillRect(r * 1.3, 2, 3, 4); }
      ctx.fillStyle = body; ctx.beginPath(); ctx.ellipse(0, 0, r * 0.75, r, 0, 0, 6.283); ctx.fill();
      ctx.strokeStyle = trim; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = o.head || '#2a2a34'; ctx.beginPath(); ctx.arc(r * 0.1, 0, r * 0.5, 0, 6.283); ctx.fill();
      if (o.visor) { ctx.fillStyle = o.visor; ctx.fillRect(r * 0.3, -r * 0.3, 3, r * 0.6); }
      ctx.restore();
    }
    function drawFan(ctx, e) {
      const r = (W.p.cro ? 6 : 9) * T, a = e.a; ctx.fillStyle = e.st === 1 ? 'rgba(255,208,64,.08)' : 'rgba(255,79,111,.06)';
      ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.arc(e.x, e.y, r, a - 0.95, a + 0.95); ctx.closePath(); ctx.fill();
    }
    // 하늘을 나는 차(장식): 머리 위로 지나가고 땅에 그림자를 드리운다. 시뮬레이션과 무관
    let cars = [], carT = 0;
    function drawCars(ctx, now) {
      if (!imOk('cars')) return; const dt = Math.min(0.05, (now - (carT || now)) / 1000) * (modal ? 0 : 1); carT = now;
      const vw = cv.w / cam.z, vh = cv.h / cam.z;
      if (cars.length < 4 && Math.random() < 0.012) { const hz = Math.random() < 0.5, dir = Math.random() < 0.5 ? 1 : -1, sp = 260 + Math.random() * 220;
        cars.push(hz ? { x: cam.x - dir * (vw / 2 + 120), y: cam.y + (Math.random() - 0.5) * vh, vx: sp * dir, vy: 0, k: (Math.random() * 8) | 0, h: 40 + Math.random() * 30 } : { x: cam.x + (Math.random() - 0.5) * vw, y: cam.y - dir * (vh / 2 + 120), vx: 0, vy: sp * dir, k: (Math.random() * 8) | 0, h: 40 + Math.random() * 30 }); }
      const im = IMG.cars, cw = 71, ch = 131;
      for (const c of cars) { c.x += c.vx * dt; c.y += c.vy * dt; const a = Math.atan2(c.vy, c.vx) + Math.PI / 2;
        ctx.save(); ctx.translate(c.x + c.h * 0.6, c.y + c.h); ctx.rotate(a); ctx.globalAlpha = 0.28; ctx.fillStyle = '#000'; ctx.fillRect(-14, -26, 28, 52); ctx.restore();
        ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(a); ctx.globalAlpha = 0.95; ctx.drawImage(im, c.k * cw, 0, cw, ch, -cw * 0.21, -ch * 0.21, cw * 0.42, ch * 0.42);
        ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,240,200,.35)'; ctx.beginPath(); ctx.moveTo(-8, -26); ctx.lineTo(-18, -70); ctx.lineTo(18, -70); ctx.lineTo(8, -26); ctx.fill(); ctx.fillStyle = 'rgba(255,40,80,.7)'; ctx.fillRect(-11, 25, 6, 3); ctx.fillRect(5, 25, 6, 3); ctx.restore(); }
      cars = cars.filter((c) => Math.abs(c.x - cam.x) < vw + 400 && Math.abs(c.y - cam.y) < vh + 400);
    }
    function drawWaypoint(now) { // 추적 목표: 화면 안이면 거리, 밖이면 가장자리 화살표 + 거리
      const ctx = cv.ctx; if (!W || W.p.dead > 0) return; const o = trackObj(); if (!o || o.x == null) return;
      const c = o.c || (o.main ? '#ffd040' : '#ff4fd8'), s = toScr(o.x, o.y), m = 46, d = Math.round(hyp(o.x - W.p.x, o.y - W.p.y) / T);
      const inside = s.x > m && s.x < cv.w - m && s.y > m && s.y < cv.h - m;
      ctx.save(); ctx.font = '600 13px "IBM Plex Mono",monospace'; ctx.textAlign = 'center';
      if (inside) { if (d > 2) { ctx.fillStyle = 'rgba(6,10,26,.7)'; ctx.fillRect(s.x - 22, s.y - 66, 44, 17); ctx.fillStyle = c; ctx.fillText(d + 'm', s.x, s.y - 53); } ctx.restore(); return; }
      const x0 = 60, x1 = cv.w - 60, y0 = 70, y1 = cv.h - 130, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, a = Math.atan2(s.y - cy, s.x - cx), k = Math.min((x1 - x0) / 2 / Math.abs(Math.cos(a) || 1e-6), (y1 - y0) / 2 / Math.abs(Math.sin(a) || 1e-6));
      const x = cx + Math.cos(a) * k, y = cy + Math.sin(a) * k, pul = 1 + Math.sin(now / 200) * 0.12;
      ctx.translate(x, y); ctx.fillStyle = 'rgba(6,10,26,.75)'; ctx.beginPath(); ctx.arc(0, 0, 24, 0, 6.283); ctx.fill(); ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.stroke();
      ctx.save(); ctx.rotate(a); ctx.scale(pul, pul); ctx.fillStyle = c; ctx.shadowColor = c; ctx.shadowBlur = 10; ctx.beginPath(); ctx.moveTo(30, 0); ctx.lineTo(18, -9); ctx.lineTo(18, 9); ctx.closePath(); ctx.fill(); ctx.restore();
      ctx.fillStyle = '#fff'; ctx.fillText(d + 'm', 0, 5); ctx.restore();
    }
    function render(now) {
      const ctx = cv.ctx, P = W.p; frameN++;
      // 카메라
      const z = Math.max(0.9, Math.min(2.2, Math.min(cv.w / (27 * T), cv.h / (15 * T))));
      cam.z = z;
      let lx = 0, ly = 0; if (mouse.moved && !modal) { const w = toWorld(mouse.x, mouse.y); lx = (w.x - P.x) * 0.22; ly = (w.y - P.y) * 0.22; }
      cam.x += (P.x + lx - cam.x) * 0.15; cam.y += (P.y + ly - cam.y) * 0.15;
      if (hyp(cam.x - P.x, cam.y - P.y) > 30 * T) { cam.x = P.x; cam.y = P.y; }
      ctx.fillStyle = '#000'; ctx.fillRect(0, 0, cv.w, cv.h);
      ctx.save();
      const sk = shake * (L.fx ? L.fx() : 1); ctx.translate(cv.w / 2 + (Math.random() - 0.5) * sk, cv.h / 2 + (Math.random() - 0.5) * sk); ctx.scale(z, z); ctx.translate(-cam.x, -cam.y);
      const x0 = Math.max(0, Math.floor((cam.x - cv.w / 2 / z) / T) - 1), x1 = Math.min(MW - 1, Math.ceil((cam.x + cv.w / 2 / z) / T) + 1), y0 = Math.max(0, Math.floor((cam.y - cv.h / 2 / z) / T) - 1), y1 = Math.min(MH - 1, Math.ceil((cam.y + cv.h / 2 / z) / T) + 1);
      lamps.length = 0; signGlow.length = 0;
      drawTiles(ctx, x0, y0, x1, y1, now);
      for (const d of decals) { const im = tinted(d.k, d.c); if (!im) continue; ctx.globalAlpha = d.a * Math.min(1, d.l / 5); ctx.save(); ctx.translate(d.x, d.y); ctx.rotate(d.r); ctx.drawImage(im, -d.s / 2, -d.s / 2, d.s, d.s); ctx.restore(); } ctx.globalAlpha = 1;
      for (const l of lamps) { ctx.fillStyle = '#1a2238'; ctx.beginPath(); ctx.arc(l.x, l.y, 4, 0, 6.283); ctx.fill(); ctx.fillStyle = l.c; ctx.fillRect(l.x - 1, l.y - 1, 2, 2); }
      const inV = (x, y) => x > (x0 - 1) * T && x < (x1 + 2) * T && y > (y0 - 1) * T && y < (y1 + 2) * T;
      const hidden = (x, y) => { const b = bldAt(M, x, y); return b >= 0 && b !== P.inside; };
      // 바닥 물건
      for (const t of W.term) if (inV(t.x, t.y) && !hidden(t.x, t.y)) { ctx.fillStyle = t.done ? '#223' : '#0a2a24'; ctx.fillRect(t.x - 10, t.y - 10, 20, 20); ctx.strokeStyle = t.done ? '#445' : '#7dff9a'; ctx.shadowColor = '#7dff9a'; ctx.shadowBlur = t.done ? 0 : 10; ctx.lineWidth = 2; ctx.strokeRect(t.x - 10, t.y - 10, 20, 20); ctx.shadowBlur = 0; ctx.fillStyle = t.done ? '#445' : '#7dff9a'; ctx.fillRect(t.x - 6, t.y - 5, 12, 2); ctx.fillRect(t.x - 6, t.y, 8, 2); }
      for (const o of W.lo) if (inV(o.x, o.y) && !hidden(o.x, o.y)) { const it = o.it, c = it.k === 'cr' ? '#ffd040' : it.k === 'am' ? '#c8d0e0' : it.r != null ? RAR[it.r].c : '#7dff9a', bob = Math.sin(now / 300 + o.id) * 2; ctx.fillStyle = c; ctx.shadowColor = c; ctx.shadowBlur = 8; ctx.beginPath(); ctx.moveTo(o.x, o.y - 6 + bob); ctx.lineTo(o.x + 5, o.y + bob); ctx.lineTo(o.x, o.y + 6 + bob); ctx.lineTo(o.x - 5, o.y + bob); ctx.fill(); ctx.shadowBlur = 0; }
      M.metro.forEach((m, d) => { if (!m) return; const x = m[0] * T + 16, y = m[1] * T + 16; if (!inV(x, y)) return; ctx.fillStyle = '#101830'; ctx.fillRect(x - 13, y - 13, 26, 26); ctx.strokeStyle = '#ffd040'; ctx.lineWidth = 2; ctx.strokeRect(x - 13, y - 13, 26, 26); ctx.fillStyle = '#ffd040'; ctx.font = 'bold 18px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('M', x, y + 1); });
      // 시민
      for (const c of W.civ) if (c.hp > 0 && inV(c.x, c.y) && !hidden(c.x, c.y)) { const a = Math.atan2(c.ty - c.y, c.tx - c.x); if (!drawChar(ctx, CH_CIV[c.id % CH_CIV.length], c.fl > 0 ? 'hold' : 'stand', c.x, c.y, a, 9, c.c, 0.92)) drawMan(ctx, c.x, c.y, a, '#1c1c2a', c.c, 8, {}); }
      // 인물
      for (const n of W.npc) { if (!inV(n.x, n.y) || hidden(n.x, n.y)) continue; const ac = n.look ? n.look.ac : '#fff', h = n.id.length * 7 + n.id.charCodeAt(0);
        if (!drawChar(ctx, n.kind === 'leader' && n.fa === 'ak' ? 'hitman1' : CH_CIV[h % CH_CIV.length], n.kind === 'gun' ? 'machine' : 'stand', n.x, n.y, n.a, 11, ac)) drawMan(ctx, n.x, n.y, n.a, '#202036', ac, 11, { head: n.look ? n.look.hc : '#222', visor: n.look ? n.look.ey : null });
        ctx.fillStyle = ac; ctx.font = '11px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(n.nm, n.x, n.y - 18);
        if (n.kind === 'side' && !sq(W, n.side).st || n.id === 'doc2' && W.q.m >= 3 && !sq(W, 'psy').st) { const bob = Math.sin(now / 260) * 3; ctx.fillStyle = '#c070ff'; ctx.shadowColor = '#c070ff'; ctx.shadowBlur = 10; ctx.font = 'bold 18px sans-serif'; ctx.fillText('✦', n.x, n.y - 30 + bob); ctx.shadowBlur = 0; } }
      // 적
      const P2 = P;
      for (const e of W.en) {
        if (e.hp <= 0 || !inV(e.x, e.y)) continue;
        const vis = visE(e), hos = hostile(W, e), E = EN[e.ty], fc = FA[e.fa] ? FA[e.fa].c : '#fff';
        if (!vis) continue;
        const behind = bldAt(M, e.x, e.y) >= 0 && bldAt(M, e.x, e.y) !== P2.inside || !los(M, P2.x, P2.y, e.x, e.y);
        if (behind) { ctx.globalAlpha = 0.45; ctx.strokeStyle = '#ff6f6f'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(e.x, e.y, E.r, 0, 6.283); ctx.stroke(); ctx.globalAlpha = 1; continue; }
        if (hos && e.st < 2 && hyp(e.x - P2.x, e.y - P2.y) < 12 * T && !E.fix) drawFan(ctx, e);
        if (E.fix) { ctx.fillStyle = '#1a2030'; ctx.fillRect(e.x - 12, e.y - 12, 24, 24); ctx.strokeStyle = fc; ctx.lineWidth = 2; ctx.strokeRect(e.x - 12, e.y - 12, 24, 24); ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(e.a); ctx.fillStyle = '#556'; ctx.fillRect(0, -3, 18, 6); ctx.restore(); }
        else if (E.fly) { ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(now / 80); ctx.strokeStyle = fc; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-9, -9); ctx.lineTo(9, 9); ctx.moveTo(9, -9); ctx.lineTo(-9, 9); ctx.stroke(); ctx.restore(); ctx.fillStyle = '#20283a'; ctx.beginPath(); ctx.arc(e.x, e.y, 6, 0, 6.283); ctx.fill(); ctx.fillStyle = hos ? '#ff3050' : fc; ctx.fillRect(e.x - 2, e.y - 2, 4, 4); }
        else if (!drawChar(ctx, CH_EN[e.ty] || 'manBrown', poseOf(e.w, e.rl > 0), e.x, e.y, e.a, E.r * (e.ty === 'heavy' || E.boss ? 1.25 : 1), hos ? '#ff3050' : fc)) drawMan(ctx, e.x, e.y, e.a, E.elite ? '#2a1830' : '#1a1c2a', fc, E.r, { gun: !!WB[e.w], head: E.mech ? '#556070' : '#2a2a34', visor: hos ? '#ff3050' : fc });
        if (E.shd && !(e.stn > 0) && !(e.bl > 0)) { ctx.strokeStyle = 'rgba(120,200,255,.85)'; ctx.lineWidth = 5; ctx.shadowColor = '#4fd8ff'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(e.x, e.y, E.r + 7, e.a - 0.8, e.a + 0.8); ctx.stroke(); ctx.shadowBlur = 0; }
        if (e.ty === 'hound') { ctx.strokeStyle = '#d8e4ff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(e.x, e.y, E.r + 11 + Math.sin(now / 150) * 2, 0, 6.283); ctx.stroke(); }
        if (e.aimT > 0) { ctx.strokeStyle = 'rgba(255,40,70,' + Math.min(0.9, 0.2 + e.aimT * 0.7) + ')'; ctx.lineWidth = 1 + e.aimT * 1.5; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(P2.x, P2.y); ctx.stroke(); }
        if (e.up > 0) { const k = 1 - e.up / 2.4; ctx.strokeStyle = '#ff4fd8'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(e.x, e.y, E.r + 10, -Math.PI / 2, -Math.PI / 2 + k * 6.283); ctx.stroke(); ctx.setLineDash([2, 6]); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(P2.x, P2.y); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#ff4fd8'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('업로드 ' + Math.round(k * 100) + '%', e.x, e.y - E.r - 22); }
        if (e.burn > 0) parts.push({ x: e.x + (Math.random() - 0.5) * 14, y: e.y + (Math.random() - 0.5) * 14, vx: 0, vy: -40, l: 0.35, l0: 0.35, c: '#ff8040', s: 14, spr: 'fire1', add: 1 });
        if (e.cf > 0) { ctx.strokeStyle = '#c070ff'; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.arc(e.x, e.y, E.r + 6, 0, 6.283); ctx.stroke(); ctx.setLineDash([]); }
        if (hos) { ctx.strokeStyle = 'rgba(255,48,80,.6)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(e.x, e.y, E.r + 3, 0, 6.283); ctx.stroke(); }
        if (e === hoverE) { ctx.strokeStyle = '#7dff9a'; ctx.lineWidth = 2; ctx.setLineDash([4, 3]); ctx.beginPath(); ctx.arc(e.x, e.y, E.r + 8, 0, 6.283); ctx.stroke(); ctx.setLineDash([]); }
        ctx.textAlign = 'center'; ctx.font = 'bold 16px sans-serif';
        if (hos && e.st === 1) { ctx.fillStyle = '#ffd040'; ctx.fillText('?', e.x, e.y - E.r - 8); }
        else if (hos && e.st === 2) { ctx.fillStyle = '#ff3050'; ctx.fillText('!', e.x, e.y - E.r - 8); }
        if (e.hp < e.mhp || hasCW(W, 'tgt') || E.boss || e.nm) { const w = E.boss ? 48 : 26; ctx.fillStyle = '#000a'; ctx.fillRect(e.x - w / 2, e.y + E.r + 4, w, 4); ctx.fillStyle = hos ? '#ff3050' : fc; ctx.fillRect(e.x - w / 2, e.y + E.r + 4, w * Math.max(0, e.hp / e.mhp), 4); }
        if (e.nm || e === hoverE) { ctx.font = '11px sans-serif'; ctx.fillStyle = e.nm ? '#ffd040' : '#c8d0e0'; ctx.fillText((e.nm || E.nm) + (e === hoverE ? ' · ' + (FA[e.fa] ? FA[e.fa].nm : '') + (hos ? ' (적대)' : ' (중립)') : ''), e.x, e.y + E.r + 18); }
      }
      // 플레이어
      if (!P.dead) {
        const it = P.g[P.cur];
        if (P.camo) ctx.globalAlpha = 0.35;
        if (P.ride) drawBike(ctx, P, now);
        const pw = P.cur < 2 && it ? it.b : P.cur === 2 ? 'knife' : null;
        if (!drawChar(ctx, 'hitman1', P.ride ? 'hold' : poseOf(pw, P.rl > 0), P.x, P.y, P.ride ? P.ba || P.a : P.a, P.cro ? 11 : 12.5, '#ff4fd8', P.camo ? 0.35 : 1)) drawMan(ctx, P.x, P.y, P.a, '#2a1038', '#ff4fd8', P.cro ? 10 : 12, { gun: P.cur < 2 && !!it, head: '#101018', visor: '#4fd8ff' });
        ctx.globalAlpha = 1;
        if (!modal && P.cur < 2 && it && !P.ride) { const s = wStat(it); ctx.strokeStyle = 'rgba(255,79,216,.35)'; ctx.setLineDash([6, 8]); ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(P.x + Math.cos(P.a) * 18, P.y + Math.sin(P.a) * 18); ctx.lineTo(P.x + Math.cos(P.a) * s.rng * T * 0.6, P.y + Math.sin(P.a) * s.rng * T * 0.6); ctx.stroke(); ctx.setLineDash([]); }
      }
      // 총알
      ctx.lineCap = 'round';
      for (const b of W.bul) { if (!inV(b.x, b.y)) continue; const c = b.o === 0 ? '#ffe08a' : '#ff5070'; ctx.strokeStyle = c; ctx.lineWidth = b.gren ? 5 : 2; ctx.beginPath(); ctx.moveTo(b.x - b.vx * 0.022, b.y - b.vy * 0.022); ctx.lineTo(b.x, b.y); ctx.stroke(); }
      // 효과
      for (const p of parts) { const al = Math.max(0, p.l / p.l0), im = p.spr ? tinted(p.spr, p.c) : null;
        if (im) { const sz = p.s * (p.grow ? 1 + (1 - al) * p.grow : 1); ctx.globalAlpha = al; if (p.add) ctx.globalCompositeOperation = 'lighter'; if (p.rot != null) { ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.drawImage(im, -sz / 2, -sz / 2, sz, sz); ctx.restore(); } else ctx.drawImage(im, p.x - sz / 2, p.y - sz / 2, sz, sz); ctx.globalCompositeOperation = 'source-over'; }
        else { ctx.globalAlpha = al; ctx.fillStyle = p.c; const q = p.spr ? Math.min(5, p.s / 4) : p.s; ctx.fillRect(p.x - q / 2, p.y - q / 2, q, q); } }
      for (const r of rings) { ctx.globalAlpha = Math.max(0, r.l / r.l0); ctx.strokeStyle = r.c; ctx.lineWidth = r.w || 2; ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, 6.283); ctx.stroke(); }
      ctx.globalAlpha = 1;
      // 밤 색보정(곱하기) 뒤에 빛(더하기): 가로등·단말기·총구 불꽃·폭발·주인공 주변
      ctx.globalCompositeOperation = 'multiply'; ctx.fillStyle = W.slow > 0 ? 'rgb(120,170,200)' : 'rgb(150,140,200)'; ctx.fillRect(cam.x - cv.w / z, cam.y - cv.h / z, cv.w * 2 / z, cv.h * 2 / z); ctx.globalCompositeOperation = 'source-over';
      if (imOk('fx')) { ctx.globalCompositeOperation = 'lighter';
        const L1 = (x, y, r, c, a) => { const im = tinted('light1', c); if (!im) return; ctx.globalAlpha = a; ctx.drawImage(im, x - r, y - r, r * 2, r * 2); };
        for (const l of lamps) if (!hidden(l.x, l.y)) L1(l.x, l.y + 8, 70, l.c, 0.22);
        for (const t of W.term) if (!t.done && inV(t.x, t.y) && !hidden(t.x, t.y)) L1(t.x, t.y, 40, '#7dff9a', 0.4);
        for (const f of flashes) L1(f.x, f.y, f.r, f.c, Math.max(0, f.l / f.l0) * f.a);
        if (!P.dead) L1(P.x, P.y, 90, '#ff4fd8', 0.14);
        if (P.ride && !P.dead) { const a = P.ba || 0, im = tinted('flare1', '#e8f4ff'); L1(P.x + Math.cos(a) * 60, P.y + Math.sin(a) * 60, 60, '#e8f4ff', 0.25); }
        for (const b of W.bul) if (inV(b.x, b.y)) L1(b.x, b.y, 12, b.o === 0 ? '#ffe08a' : '#ff5070', 0.5);
        ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; }
      drawRoofs(ctx, x0, y0, x1, y1, now);
      if (imOk('fx')) { ctx.globalCompositeOperation = 'lighter'; for (const g of signGlow) { const im = tinted('light1', g.c); if (im) { ctx.globalAlpha = g.a; ctx.drawImage(im, g.x - g.r, g.y - g.r, g.r * 2, g.r * 2); } } ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; }
      // 빗방울 튀김(밖)
      if (P.inside < 0) for (let k = 0; k < 3; k++) { const rx = cam.x + (Math.random() - 0.5) * cv.w / z, ry = cam.y + (Math.random() - 0.5) * cv.h / z; if (!hidden(rx, ry) && (P.d !== 4 || Math.random() < 0.3)) rings.push({ x: rx, y: ry, r: 1, vr: 22, l: 0.25, l0: 0.25, c: 'rgba(170,200,255,.5)', w: 1 }); }
      // 목표 표시
      drawCars(ctx, now);
      for (const o of Q.objs(W)) { if (o.x == null || !inV(o.x, o.y)) continue; const c = o.c || (o.main ? '#ffd040' : '#ff4fd8'), bob = Math.sin(now / 250) * 4; ctx.strokeStyle = c; ctx.lineWidth = 2.5; ctx.shadowColor = c; ctx.shadowBlur = 10; ctx.beginPath(); ctx.moveTo(o.x, o.y - 34 + bob); ctx.lineTo(o.x + 9, o.y - 25 + bob); ctx.lineTo(o.x, o.y - 16 + bob); ctx.lineTo(o.x - 9, o.y - 25 + bob); ctx.closePath(); ctx.stroke(); ctx.shadowBlur = 0; }
      // 피해 숫자
      for (const f of floats) { ctx.globalAlpha = Math.max(0, f.l / f.l0); ctx.fillStyle = f.c; ctx.font = 'bold ' + (f.big ? 18 : 13) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(f.t, f.x, f.y); }
      ctx.globalAlpha = 1;
      ctx.restore();
      drawWaypoint(now);
      // 화면 효과: 비·비네트·글리치
      ctx.strokeStyle = 'rgba(140,180,255,.16)'; ctx.lineWidth = 1; ctx.beginPath();
      for (const r of rain) { r.y += 0.022 * r.s; r.x += 0.004 * r.s; if (r.y > 1) { r.y -= 1; r.x = Math.random(); } if (r.x > 1) r.x -= 1; const X = r.x * cv.w, Y = r.y * cv.h; ctx.moveTo(X, Y); ctx.lineTo(X + 4 * r.s, Y + 14 * r.s); }
      ctx.stroke();
      const vg = ctx.createRadialGradient(cv.w / 2, cv.h / 2, cv.h * 0.35, cv.w / 2, cv.h / 2, cv.w * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(10,0,30,.6)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, cv.w, cv.h);
      if (hurtT > 0) { ctx.fillStyle = 'rgba(255,0,60,' + Math.min(0.3, hurtT) * (L.fx ? L.fx() : 1) + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      if (P.hum < 25 && Math.random() < 0.04 * (L.fx ? L.fx() : 1)) { ctx.fillStyle = 'rgba(255,79,216,.08)'; const y = Math.random() * cv.h; ctx.fillRect(0, y, cv.w, 6 + Math.random() * 20); }
      if (P.ping > 0) { ctx.strokeStyle = 'rgba(125,255,154,.4)'; ctx.lineWidth = 2; ctx.strokeRect(4, 4, cv.w - 8, cv.h - 8); }
      if (W.slow > 0) { ctx.fillStyle = 'rgba(79,216,255,' + (0.07 + 0.03 * Math.sin(now / 90)) + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      if (P.burn > 0) { ctx.fillStyle = 'rgba(255,79,216,' + (0.06 + Math.random() * 0.06) + ')'; ctx.fillRect(0, Math.random() * cv.h, cv.w, 3 + Math.random() * 30); }
      if (!bot() && !modal && mouse.moved && imOk('cross')) { const hot = hoverE && hostile(W, hoverE), im = hot && imOk('cross_r') ? IMG.cross_r : IMG.cross; ctx.globalAlpha = 0.9; ctx.drawImage(im, mouse.x - 15, mouse.y - 15, 30, 30); ctx.globalAlpha = 1; cvEl.style.cursor = 'none'; } else cvEl.style.cursor = '';
    }
    function fxEvents() {
      const P = W.p;
      for (const e of W.ev) {
        switch (e.k) {
          case 'msg': toastF(e.t, e.c); break;
          case 'shot': { const mx = e.x + Math.cos(e.a) * 20, my = e.y + Math.sin(e.a) * 20, mc = e.p ? '#ffe08a' : '#ff8070';
            parts.push({ x: mx + Math.cos(e.a) * 8, y: my + Math.sin(e.a) * 8, vx: 0, vy: 0, l: 0.06, l0: 0.06, c: mc, s: e.w === 'sg' || e.w === 'rail' || e.w === 'tech' ? 34 : 24, spr: pick(['muzzle1', 'muzzle3', 'muzzle5']), rot: e.a + Math.PI / 2, add: 1 });
            flashes.push({ x: mx, y: my, r: e.sup ? 30 : 70, c: mc, l: 0.07, l0: 0.07, a: e.sup ? 0.3 : 0.8 });
            for (let i = 0; i < 2; i++) parts.push({ x: mx, y: my, vx: Math.cos(e.a + (Math.random() - 0.5)) * 120, vy: Math.sin(e.a + (Math.random() - 0.5)) * 120, l: 0.08, l0: 0.08, c: '#ffe08a', s: 4 });
            const sk = e.w === 'gren' ? 'slime' : e.w === 'sg' ? 'shot_s' : e.w === 'rail' || e.w === 'tech' ? 'shot_r' : e.w === 'ar' || e.w === 'lmg' || e.w === 'rev' ? 'shot_h' : e.w === 'smg' || e.w === 'smt' ? 'shot_e' : e.w === 'sil' ? 'shot_l2' : 'shot_l';
            if (e.p) { snd(sk, e.sup ? 0.35 : 0.8, 1, null, 'pop', { vol: e.sup ? 0.25 : 0.55, pitch: e.w === 'sg' ? 0.7 : e.w === 'rail' ? 0.5 : 1 }); shake = Math.max(shake, e.w === 'rail' || e.w === 'sg' || e.w === 'tech' ? 5 : 2); }
            else { const d = hyp(e.x - P.x, e.y - P.y); if (d < 18 * T) snd(sk, 0.45 * (1 - d / (18 * T)) + 0.1, 0.9, e.x, 'tick', { vol: 0.4 }); } break; }
          case 'hit': parts.push({ x: e.x, y: e.y, vx: 0, vy: 0, l: 0.12, l0: 0.12, c: e.mech ? '#9fe0ff' : '#ff6f8f', s: 26, spr: e.mech ? 'spark4' : 'spark1', rot: Math.random() * 6, add: 1 }); if (e.mech) snd(pick(['hit_m', 'hit_m2']), 0.4, 1.2, e.x);
            if (st.dmg !== 'off') floats.push({ x: e.x + (Math.random() - 0.5) * 10, y: e.y - 16, t: String(e.n), c: e.cr ? '#ffd040' : '#fff', l: 0.7, l0: 0.7, big: e.cr }); for (let i = 0; i < 4; i++) parts.push({ x: e.x, y: e.y, vx: (Math.random() - 0.5) * 200, vy: (Math.random() - 0.5) * 200, l: 0.25, l0: 0.25, c: '#ff4f6f', s: 3 }); sfx('hit', { vol: 0.5 }); break;
          case 'spark': parts.push({ x: e.x, y: e.y, vx: 0, vy: 0, l: 0.12, l0: 0.12, c: '#9fe0ff', s: 14, spr: 'spark6', rot: Math.random() * 6, add: 1 }); if (decals.length < 90 && Math.random() < 0.3) decals.push({ x: e.x, y: e.y, k: 'dirt2', c: '#000000', s: 10, r: Math.random() * 6, a: 0.5, l: 40 }); break;
          case 'die': if (e.mech) snd('hit_m', 0.5, 0.6, e.x); parts.push({ x: e.x, y: e.y, vx: 0, vy: -15, l: 0.9, l0: 0.9, c: e.mech ? '#2a3a4a' : '#3a2030', s: 40, spr: 'smoke4', grow: 0.8, rot: Math.random() * 6 }); for (let i = 0; i < 14; i++) parts.push({ x: e.x, y: e.y, vx: (Math.random() - 0.5) * 260, vy: (Math.random() - 0.5) * 260, l: 0.5, l0: 0.5, c: e.mech ? '#4fd8ff' : e.civ ? '#ffa040' : '#ff3050', s: 4 }); sfx('thud', { vol: 0.6 }); break;
          case 'hurt': hurtT = 0.35; shake = Math.max(shake, 6); floats.push({ x: P.x, y: P.y - 20, t: '-' + e.n, c: '#ff5070', l: 0.6, l0: 0.6 }); try { api.buzz(30); } catch (er) {} break;
          case 'boom': parts.push({ x: e.x, y: e.y, vx: 0, vy: 0, l: 0.35, l0: 0.35, c: '#ffa040', s: 90, spr: 'fire1', grow: 0.6, add: 1 }); for (let i = 0; i < 4; i++) parts.push({ x: e.x + (Math.random() - 0.5) * 30, y: e.y + (Math.random() - 0.5) * 30, vx: (Math.random() - 0.5) * 40, vy: -20 - Math.random() * 30, l: 1.4, l0: 1.4, c: '#3a3448', s: 50, spr: pick(['smoke1', 'smoke4']), grow: 1, rot: Math.random() * 6 });
            flashes.push({ x: e.x, y: e.y, r: 200, c: '#ffa040', l: 0.35, l0: 0.35, a: 1 }); decals.push({ x: e.x, y: e.y, k: 'scorch1', c: '#000000', s: 80, r: Math.random() * 6, a: 0.7, l: 60 }); if (decals.length > 90) decals.shift();
            snd(Math.random() < 0.5 ? 'boom' : 'boom2', 0.9, 1, e.x);
            rings.push({ x: e.x, y: e.y, r: 10, vr: 260, l: 0.35, l0: 0.35, c: '#ffa040', w: 6 }); for (let i = 0; i < 24; i++) parts.push({ x: e.x, y: e.y, vx: (Math.random() - 0.5) * 420, vy: (Math.random() - 0.5) * 420, l: 0.5, l0: 0.5, c: i % 2 ? '#ffd040' : '#ff4f20', s: 5 }); shake = 12; if (!Au.buf.boom) sfx('thud'); break;
          case 'hack': rings.push({ x: e.x, y: e.y, r: 4, vr: 90, l: 0.4, l0: 0.4, c: '#7dff9a' }); parts.push({ x: e.x, y: e.y, vx: 0, vy: 0, l: 0.5, l0: 0.5, c: e.h === 'burn' ? '#ff8040' : e.h === 'reb' ? '#4fd8ff' : '#7dff9a', s: 46, spr: 'twirl1', rot: 0, grow: 0.5, add: 1 }); snd('hack', 0.5, 1.3, e.x, 'whoosh', { vol: 0.5 }); break;
          case 'ping': rings.push({ x: e.x, y: e.y, r: 10, vr: 900, l: 0.45, l0: 0.45, c: '#7dff9a', w: 3 }); snd('hack2', 0.5, 1, null, 'whoosh'); break;
          case 'upload': snd('hack2', 0.45, 0.8, e.x, 'warn', { vol: 0.3 }); break;
          case 'phack': hurtT = 0.4; shake = Math.max(shake, 5); snd('hack', 0.7, 0.7, null, 'warn'); floats.push({ x: P.x, y: P.y - 30, t: '해킹당함!', c: '#ff4fd8', l: 1, l0: 1, big: 1 }); break;
          case 'throw': snd('slime', 0.4, 1.4, null, 'whoosh', { vol: 0.4 }); break;
          case 'slow': snd('field2', 0.7, 0.6, null, 'whoosh'); rings.push({ x: P.x, y: P.y, r: 10, vr: 700, l: 0.5, l0: 0.5, c: '#4fd8ff', w: 4 }); break;
          case 'lunge': snd('field', 0.35, 1.6, e.x); rings.push({ x: e.x, y: e.y, r: 4, vr: 120, l: 0.2, l0: 0.2, c: '#ff3050' }); break;
          case 'bikeon': snd('bike', 0.6, 1, null, 'go'); toastF('오토바이 탑승 — 총은 못 쏴요 · B로 내려요', '#ffd040'); break;
          case 'bikeoff': snd('door_c', 0.3, 1.4, null, 'click'); break;
          case 'crash': shake = Math.max(shake, 6); snd('hit_m2', 0.6, 0.8, e.x, 'thud'); break;
          case 'alert': floats.push({ x: e.x, y: e.y - 30, t: '!', c: '#ff3050', l: 0.8, l0: 0.8, big: 1 }); sfx('warn', { vol: 0.35 }); break;
          case 'takedown': floats.push({ x: e.x, y: e.y - 30, t: '처치!', c: '#7dff9a', l: 0.9, l0: 0.9, big: 1 }); break;
          case 'swing': if (e.p) parts.push({ x: e.x + Math.cos(e.a || 0) * 22, y: e.y + Math.sin(e.a || 0) * 22, vx: 0, vy: 0, l: 0.14, l0: 0.14, c: e.mono ? '#4fd8ff' : e.claw ? '#ff4fd8' : '#ffffff', s: e.mono ? 90 : 46, spr: 'slash2', rot: (e.a || 0) + Math.PI / 2, add: 1 });
            rings.push({ x: e.x + Math.cos(e.a || 0) * 16, y: e.y + Math.sin(e.a || 0) * 16, r: 6, vr: e.mono ? 160 : 70, l: 0.15, l0: 0.15, c: e.mono ? '#4fd8ff' : '#fff' }); sfx('whoosh', { vol: 0.3 }); break;
          case 'dash': rings.push({ x: e.x, y: e.y, r: 6, vr: 120, l: 0.2, l0: 0.2, c: '#4fd8ff' }); snd('field', 0.5, 1.5, null, 'whoosh'); break;
          case 'dodge': floats.push({ x: e.x, y: e.y - 24, t: '회피', c: '#4fd8ff', l: 0.6, l0: 0.6 }); break;
          case 'coin': case 'pick': case 'buy': sfx('chip', { vol: 0.5 }); break;
          case 'reload': sfx('click', { vol: 0.4 }); break;
          case 'heal': sfx('pop'); floats.push({ x: P.x, y: P.y - 24, t: '+50', c: '#7dff9a', l: 0.8, l0: 0.8 }); break;
          case 'lvl': try { api.banner('레벨 업!', { sub: '레벨 ' + P.lv + ' · 능력치 점수 +1', color: '#ffd040', ms: 1600, small: true }); } catch (er) {} sfx('win'); break;
          case 'quest': sfx('count'); break;
          case 'dead': sfx('lose'); break;
          case 'revive': snd('field2', 0.7, 1, null, 'pop'); break;
          case 'alarm': sfx('warn'); break;
          case 'travel': cam.x = P.x; cam.y = P.y; snd('metro', 0.6, 1, null, 'whoosh'); break;
        }
      }
      W.ev.length = 0;
    }
    function stepFx(dt) {
      for (const p of parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.l -= dt; }
      parts = parts.filter((p) => p.l > 0); if (parts.length > 400) parts.splice(0, parts.length - 400);
      for (const f of floats) { f.y -= 30 * dt; f.l -= dt; } floats = floats.filter((f) => f.l > 0);
      for (const r of rings) { r.r += r.vr * dt; r.l -= dt; } rings = rings.filter((r) => r.l > 0);
      for (const f of flashes) f.l -= dt; for (let i = flashes.length - 1; i >= 0; i--) if (flashes[i].l <= 0) flashes.splice(i, 1);
      for (let i = decals.length - 1; i >= 0; i--) { decals[i].l -= dt; if (decals[i].l <= 0) decals.splice(i, 1); }
      if (W && W.p.inside !== lastIn) { if (lastIn !== -2) snd(W.p.inside >= 0 ? 'door' : 'door_c', 0.3, 1.1); lastIn = W.p.inside; }
      shake = Math.max(0, shake - dt * 30); hurtT -= dt; keysT -= dt;
      if (zoneT > 0) { zoneT -= dt; if (zoneT <= 0) zone.style.opacity = 0; }
    }
    // ── 끝 ──
    function finish() {
      if (ended) return; ended = true; closeModal();
      const E = ENDS[W.end] || ENDS.run, ep = [];
      ep.push(E.d); (ENDS_EP[W.end] || []).forEach((t) => ep.push(t));
      if (W.end !== 'psy') ep.push(W.q.f.hound ? '은빛 사냥개의 의수는 고철로 팔려 갔다. 당신 어깨의 흉터만이 그날 밤을 기억한다.' : '그날 밤 당신을 쏜 자는 끝내 찾지 못했다.');
      ep.push(W.end === 'ak' ? '붉은 렌즈 중개인은 술집 문을 닫았다. 「위층 손님은 안 받아.」' : '붉은 렌즈 중개인은 오늘도 술집 구석 자리에서 다음 운반책을 기다린다. 이번엔 술 한 잔을 더 따라 놓는다.');
      FKEYS.forEach((f) => { const v = W.rep[f]; if (W.end === f) return; if (v >= 30) ep.push(FA[f].nm + ': 당신을 친구로 기억한다.'); else if (v <= -30) ep.push(FA[f].nm + ': 당신의 얼굴에 현상금을 걸었다.'); });
      if (W.end !== 'psy') ep.push(W.p.hum >= 70 ? '쇠보다 사람이 더 많이 남았다.' : W.p.hum >= 35 ? '거울 속 얼굴이 가끔 낯설다.' : '사람의 감각이 점점 멀어진다.');
      sideEpi(W).forEach((t) => ep.push(t));
      if (W.st.civ === 0) ep.push('이번 일에서 시민은 한 명도 다치지 않았다.');
      const s = W.st, out = Object.assign({}, st, { ph: 'done', end: W.end, ep, sts: [s.kills, s.ko, s.civ, s.shots ? Math.round(s.hits / s.shots * 100) : 0, s.hacks, s.jobs, s.earn, s.died, Math.round(W.t), W.p.lv, Math.round(W.p.hum)] });
      // 결말 장면: 하늘선이 흐르고 후일담이 한 줄씩
      const el = mk('div', 'nx-end'), c = mk('canvas', null, null, el), box = mk('div', 'c', null, el);
      box.innerHTML = '<small>결말</small><h2>「' + esc(E.nm) + '」</h2>' + ep.map((t, i) => '<p style="animation-delay:' + (0.6 + i * 0.7) + 's">' + esc(t) + '</p>').join('');
      const b = mk('button', 'nx-btn', '결과 보기 ▶', box); b.setAttribute('data-key', 'Enter'); b.style.cssText = 'margin-top:14px;font-size:16px;padding:8px 30px;border-color:#ff4fd8';
      let done = false; const go = () => { if (done) return; done = true; if (modal && modal.k === 'end') { modal.el.remove(); modal = null; } api.setState(out); };
      b.onclick = go;
      modal = { k: 'end', el, botT: 3, done: go, t: 0, tick(dt) { this.t += dt; c.width = cv.w; c.height = cv.h; const x = c.getContext('2d'); drawSkyline(x, c.width, c.height, this.t * 6, 0.25); const g = x.createLinearGradient(0, 0, 0, c.height); g.addColorStop(0, 'rgba(10,0,30,.1)'); g.addColorStop(1, 'rgba(10,0,30,.75)'); x.fillStyle = g; x.fillRect(0, 0, c.width, c.height); } };
      modal.tick(0);
    }
    // ── 루프 ──
    function frame(now) {
      raf = requestAnimationFrame(frame);
      if (!W) return;
      if (!M) M = genMap(W.seed);
      let dt = Math.min(0.05, (now - (last || now)) / 1000); last = now;
      const paused = api.paused && api.paused();
      if (!paused) {
        const sp = SPD();
        if (modal) {
          if (modal.k === 'dlg') dlgTick(dt);
          if (modal && modal.tick) modal.tick(dt);
          if (modal && bot() && modal.botT != null && modal.k !== 'dlg') { modal.botT -= dt * sp; if (modal.botT <= 0) {
            if (modal.k === 'breach') { const i = modal.seq && modal.seq.shift(); if (i != null && breachPick(modal.B, i)) { modal.draw(); modal.botT = 0.3; if (modal.B.over) breachEnd(!!modal.B.done[0]); } else breachEnd(!!modal.B.done[0]); }
            else if (modal.k === 'shop') { const n = npcById(W, mem.goal && mem.goal.npc) || W.npc.find((q) => q.kind === 'store'); ['med', 'med', 'l', 'l', 'h', 's'].forEach((k) => buySimple(W, n, k)); closeModal(); }
            else if (modal.k === 'end') modal.done();
            else closeModal(); } }
        } else if (!W.end) {
          let left = dt * sp;
          while (left > 1e-4) { const d = Math.min(1 / 30, left); left -= d; const inp = bot() ? botStep(W, mem, (api.players[0] && api.players[0].lv) || 2) : humanInput(); W.p.cro = !!inp.cro; step(W, d, inp); if (W.end) break; }
          if (bot()) { botT -= dt * sp; if (botT <= 0) { botT = 0.3; const it = botWants(W, mem); if (it) { if (it.k === 'talk') openDlg(dlgFor(W, it.npc)); else if (it.k === 'term') openBreach(it.term.lv, { term: it.term }); } } }
          if (W.p.d !== lastD && W.p.d != null) { if (lastD >= 0) zoneShow(DIST[W.p.d].nm, DIST[W.p.d].c); lastD = W.p.d; }
          stepFx(dt * sp);
        }
        fxEvents();
        if (W.end && !ended) finish();
        Au.tick();
      }
      if (!modal || modal.k === 'dlg' || modal.k === 'intro') pickHover();
      render(now);
      if ((hudT -= dt) <= 0) { hudT = 0.12; refreshHUD(); drawMini(); hintTick(0.12); }
      if (modal && modal.k === 'dlg') layoutDlg();
    }
    raf = requestAnimationFrame(frame);
    const onResize = () => layoutDlg(); window.addEventListener('resize', onResize);
    if (L.debug) L.debug.neon = () => ({ W, M, openDlg, openShop: (id) => openShop(npcById(W, id)), openInv, openMap, openJournal, openBreach, closeModal, dlgFor, npcById, Q, step, mem, setW: (w) => { W = w; } });

    return {
      update(s) {
        st = s;
        if (s && s.ph === 'play' && !W) { W = newWorld(s.seed, s.bg, (api.players[0] && api.players[0].name) || '용병'); M = genMap(W.seed); lastD = 1; intro(); }
      },
      saveState() { if (!W || W.end || ended) return false; st.svd = CHAP(W.q.m) + ' · 레벨 ' + W.p.lv; return { rid: st.rid, iid: IID, w: JSON.stringify(W, (k, v) => (k[0] === '_' ? undefined : v)) }; },
      loadState(b) { if (!b || !b.w || !st || b.rid !== st.rid) return; closeModal(); W = JSON.parse(b.w); W.ev = []; migrate(W, genMap(W.seed)); IID = Math.max(IID, b.iid || 0); M = genMap(W.seed); cam.x = W.p.x; cam.y = W.p.y; lastD = W.p.d != null ? W.p.d : 1; mmBase = null; },
      destroy() { cancelAnimationFrame(raf); Au.close(); window.removeEventListener('pointerdown', gesture, true); window.removeEventListener('keydown', gesture, true); offIn && offIn(); window.removeEventListener('keydown', onKey, true); window.removeEventListener('pointerup', onUp); window.removeEventListener('resize', onResize); cvEl.removeEventListener('wheel', onWheel); cv.destroy(); ui.remove(); styleEl.remove(); if (L.debug && L.debug.neon) delete L.debug.neon; },
    };
  }

  // ═════════ 등록 ═════════
  function init(players, opts) {
    opts = opts || {};
    return { ph: 'play', rid: Math.floor(Math.random() * 1e9), seed: opts.city === 'fixed' ? 777 : 1 + Math.floor(Math.random() * 1e6), bg: BG[opts.bg] ? opts.bg : 'street', dmg: opts.dmg === 'off' ? 'off' : 'on', tips: opts.tips === 'off' ? 'off' : 'on' };
  }
  function result(st) {
    if (!st || st.ph !== 'done') return null;
    const E = ENDS[st.end] || ENDS.run, s = st.sts || [];
    const t = s[8] || 0;
    return {
      winners: st.end === 'psy' ? [] : [0], title: '결말 — 「' + E.nm + '」',
      text: (st.ep || [E.d]).join('\n'),
      highlights: [(st.end === 'run' ? '아무 편도 들지 않았다' : st.end === 'psy' ? '인간성이 바닥났다' : st.end === 'truth' ? '누구의 개도 되지 않고 증언했다' : FA[st.end].nm + '과 손잡았다'), '레벨 ' + (s[9] || 1) + ' · 인간성 ' + (s[10] != null ? s[10] : '?') + ' · ' + Math.floor(t / 60) + '분'],
      stats: [{ label: '처치', value: String(s[0] || 0) }, { label: '기절(비살상)', value: String(s[1] || 0) }, { label: '시민 피해', value: String(s[2] || 0) }, { label: '명중률', value: (s[3] || 0) + '%' }, { label: '해킹', value: String(s[4] || 0) }, { label: '일거리', value: String(s[5] || 0) }, { label: '번 크레딧', value: String(s[6] || 0) }, { label: '쓰러짐', value: String(s[7] || 0) }],
    };
  }
  function codexDef() {
    const gunRows = Object.keys(WB).map((k) => { const B = WB[k]; return { icon: '🔫', name: B.nm, tag: B.ty, desc: '피해 ' + B.dmg + (B.pel ? '×' + B.pel : '') + ' · 연사 ' + B.rof + '/초 · 탄창 ' + B.mag + ' · 사거리 ' + B.rng + '칸 · ' + AMMO[B.am].nm + (B.sup ? ' · 소음' : '') + (B.hom ? ' · 유도' : '') + (B.pc ? ' · 관통' : '') + ' · 기본값 ' + B.val + '₵' }; });
    const melRows = Object.keys(MB).filter((k) => k !== 'fist').map((k) => { const B = MB[k]; return { icon: '🗡', name: B.nm, tag: B.ty, desc: '피해 ' + B.dmg + ' · 초당 ' + B.rof + '회 · 사거리 ' + B.rch + '칸' + (B.st ? ' · 기절 ' + B.st + '초' : '') + (B.nl ? ' · 비살상' : '') + ' · 뒤에서(눈치 못 챈 적) 6배' }; })
      .concat(Object.keys(ARM).map((k) => ({ icon: '🧥', name: ARM[k].nm, tag: '옷', desc: '방어 ' + ARM[k].ar + (ARM[k].sp ? ' · 이동 ' + Math.round(ARM[k].sp * 100) + '%' : '') + ' · ' + ARM[k].val + '₵' })))
      .concat(RAR.map((r, i) => ({ icon: '◆', name: r.nm + ' 등급', tag: '희귀도', desc: '피해 ×' + r.m + (i ? ' · 특성 1개(치명타·탄창·연사·안정 중)' : '') })));
    const cwRows = Object.keys(CW).map((k) => { const C = CW[k]; return { icon: '⚙', name: C.nm, tag: SLOTS.find((s) => s[0] === C.sl)[1] + (C.il ? ' · 불법' : ''), desc: C.d + ' · 인간성 −' + C.hum + ' · ' + C.val + '₵' }; });
    const qhRows = Object.keys(QH).map((k) => ({ icon: '⌁', name: QH[k].nm, tag: '퀵해킹', desc: QH[k].d + ' · RAM ' + QH[k].ram + ' · 대기 ' + QH[k].cd + '초' + (QH[k].val ? ' · ' + QH[k].val + '₵ (유령망 쪽 잡화점·배급소)' : ' · 처음부터') }));
    const faRows = Object.keys(FA).map((k) => ({ icon: '●', name: FA[k].nm, tag: '세력', desc: FA[k].d + (FA[k].riv ? ' · 맞수: ' + FA[k].riv.map((r) => FA[r].nm).join(', ') : '') }));
    const dRows = DIST.map((D) => ({ icon: '▦', name: D.nm, tag: '위험 ' + '★'.repeat(D.lv), desc: D.d + ' · ' + (D.fa && FA[D.fa] ? FA[D.fa].nm : '중립') }));
    const enRows = Object.keys(EN).map((k) => { const E = EN[k]; return { icon: '☠', name: E.nm, tag: E.boss ? '두목' : E.elite ? '정예' : E.mech ? '기계' : '보통', desc: '체력 ' + E.hp + ' · 방어 ' + E.ar + ' · 속도 ' + E.sp + ' · 무기 ' + E.w.map((w) => (WB[w] || MB[w]).nm).join('/') + (E.mech ? ' · 단락 ×1.8 · 재부팅 장악 가능' : '') + (E.snp ? ' · 붉은 조준선이 차오르면 쏴요(엄폐!)' : '') + (E.lunge ? ' · 4칸 안에서 덮쳐 와요' : '') + (E.net ? ' · 보이는 동안 「업로드」 — 다 차면 몸이 타요. 시야를 끊거나 시야 교란·기절로 막아요' : '') + (E.boss && !E.lunge ? ' · 체력 절반에서 드론 지원·유탄 세례' : '') }; });
    const conRows = Object.keys(CON).map((k) => ({ icon: '✚', name: CON[k].nm, tag: '소모품', desc: CON[k].d + ' · ' + CON[k].val + '₵' }))
      .concat([{ icon: '🏍', name: '중고 오토바이', tag: '탈것', desc: '네온 시장 잡화 노점에서 1,500₵. 밖에서 B로 타고 내려요. 빠르고(달리기로 더), 부딪힌 적은 기절, 시민은 다쳐요(열기). 타는 동안엔 총·해킹을 못 써요. 건물에 들어가면 내려요.' }])
      .concat(Object.keys(AMMO).map((k) => ({ icon: '▮', name: AMMO[k].nm, tag: '탄', desc: AMMO[k].n + '발 묶음 · ' + AMMO[k].val + '₵' })));
    const sideRows = SKEYS.map((k) => ({ icon: '✦', name: SIDE[k].nm, tag: DIST[SIDE[k].d].nm, desc: SIDE[k].who + ' — ' + SIDE[k].tz }));
    const endRows = Object.keys(ENDS).map((k) => ({ icon: '✶', name: ENDS[k].nm, tag: '결말', desc: k === 'psy' ? '인간성이 15 이하인 채로 마지막 선택에 이르면.' : k === 'run' ? '마지막 선택에서 코어를 부수면.' : k === 'truth' ? '숨은 결말 — 부가 이야기 「유리탑의 내부 고발자」·「망가진 거울」을 가장 사람다운 방법으로 끝내고, 인간성 60 이상으로 마지막 보고에 이르면.' : FA[k].nm + '의 마지막 일을 끝내고 약속을 지키면.' }));
    return [
      { h: '총', p: ['적이 떨어뜨리거나 총포상에서 사요. 희귀도가 높을수록 세고, 특성이 붙어요.'], rows: gunRows },
      { h: '근접·옷', rows: melRows },
      { h: '의체', p: ['부위마다 하나. 강하지만 인간성을 깎아요. 불법 의체는 수배 열기를 25% 더 올려요.'], rows: cwRows },
      { h: '퀵해킹', p: ['커서를 적 위에 두고 1–5. RAM(머릿속 해킹 칩 용량)을 써요.'], rows: qhRows },
      { h: '소모품·탈것', rows: conRows },
      { h: '세력', rows: faRows }, { h: '구역', rows: dRows }, { h: '적', rows: enRows }, { h: '부가 이야기', p: ['보라 ✦ 표시 인물에게 말을 걸면 시작해요. 고른 방법이 결말 후일담과 숨은 결말에 남아요.'], rows: sideRows }, { h: '결말', p: ['일곱 가지(하나는 숨은 결말). 판 밖 해금·성장은 없어요.'], rows: endRows },
      { h: '용어 풀이', rows: GLOSS.map((g) => ({ icon: '?', name: g[0], tag: '용어', desc: g[1] })) },
      { h: '출처', p: ['외부 그림·소리는 모두 CC0(퍼블릭 도메인), 제목 글꼴은 SIL OFL이에요. 파일: assets/neon/CREDITS.txt. 불러오지 못하면 직접 그린 그림·합성음으로 바뀌어요.'], rows: CREDITS.map((c) => ({ icon: '©', name: c[0], tag: c[3], desc: c[1] + ' · ' + c[2] })) },
    ];
  }
  function preview(c) {
    const x = c.getContext('2d'), w = c.width, h = c.height;
    x.fillStyle = '#06081a'; x.fillRect(0, 0, w, h);
    x.fillStyle = '#0e1430'; x.fillRect(0, h * 0.42, w, h * 0.2); x.fillRect(w * 0.45, 0, w * 0.14, h);
    const blds = [[20, 20, 200, 120, '#ff4fd8', '라멘'], [380, 20, 240, 110, '#4fd8ff', 'ARKRA'], [20, 250, 220, 100, '#7dff9a', '수리'], [390, 245, 230, 105, '#ffd040', '총포상']];
    for (const [bx, by, bw, bh, c2, t] of blds) { const g = x.createLinearGradient(bx, by, bx + bw, by + bh); g.addColorStop(0, '#2a1d4a'); g.addColorStop(1, '#070a18'); x.fillStyle = g; x.fillRect(bx, by, bw, bh); x.strokeStyle = c2; x.lineWidth = 3; x.shadowColor = c2; x.shadowBlur = 14; x.strokeRect(bx + 4, by + 4, bw - 8, bh - 8); x.fillStyle = c2; x.font = 'bold 30px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(t, bx + bw / 2, by + bh / 2); x.shadowBlur = 0; }
    x.fillStyle = '#2a1038'; x.beginPath(); x.ellipse(310, 190, 12, 15, 0, 0, 6.283); x.fill(); x.strokeStyle = '#ff4fd8'; x.lineWidth = 3; x.stroke();
    x.strokeStyle = '#ffe08a'; x.lineWidth = 3; x.beginPath(); x.moveTo(330, 190); x.lineTo(420, 192); x.stroke();
    x.strokeStyle = '#ff3050'; x.beginPath(); x.arc(470, 194, 12, 0, 6.283); x.stroke();
    x.strokeStyle = 'rgba(140,180,255,.25)'; x.lineWidth = 1; x.beginPath(); for (let i = 0; i < 60; i++) { const a = (i * 97) % w, b = (i * 53) % h; x.moveTo(a, b); x.lineTo(a + 4, b + 14); } x.stroke();
  }
  L.register({
    id: ID, name: '네온 도시', tag: '사이버펑크 RPG', cat: '아케이드',
    blurb: '총알 세 발을 맞고 깨어난 운반책. 비 내리는 여섯 구역을 걷고 오토바이로 달리며 총싸움·잠입·해킹으로 일을 하고, 의체로 몸을 바꾸고, 부가 이야기 여덟 편과 거리 사건을 겪고, 네 세력 중 누구 편에 설지 골라 일곱 가지 결말 중 하나에 닿아요. (혼자 하기 · PC 전용 · 저장/이어하기)',
    tint: '#24103e', time: '40–90분',
    icon: '<rect x="6" y="20" width="12" height="30" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="22" y="8" width="12" height="42" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="38" y="16" width="12" height="34" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M25 16h6M25 22h6M41 24h6M9 28h6" stroke="currentColor" stroke-width="2.5"/><path d="M4 50h48" stroke="currentColor" stroke-width="3"/>',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, hidden: false, realtime: true, aiDelay: 0, landscape: true, pcOnly: true, save: true, sidePanel: false, aiNarration: true, contextMenu: true, mood: false, ambient: false,
    saveLabel: (s) => (s && s.svd ? s.svd : '네온 도시'),
    options: [
      { id: 'bg', label: '출신', tip: '시작 평판·무기·돈이 달라요. 이야기는 같아요.', choices: Object.keys(BG).map((k) => ({ v: k, label: BG[k].nm, tip: BG[k].d })), def: 'street' },
      { id: 'city', label: '도시', tip: '거리·건물 배치. 무작위면 판마다 새 도시를 만들어요.', choices: [{ v: 'rand', label: '무작위(판마다 새로)' }, { v: 'fixed', label: '고정 도시' }], def: 'rand' },
      { id: 'tips', label: '상황 안내', tip: '처음 겪는 일마다 짧은 설명 카드를 띄워요.', choices: [{ v: 'on', label: '켜기' }, { v: 'off', label: '끄기' }], def: 'on' },
      { id: 'dmg', label: '피해 숫자', tip: '맞힐 때 숫자를 띄울지.', choices: [{ v: 'on', label: '보이기' }, { v: 'off', label: '숨기기' }], def: 'on' },
    ],
    controls: [
      { id: 'up', label: '위로', keys: ['KeyW', 'ArrowUp'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로', keys: ['KeyS', 'ArrowDown'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽', keys: ['KeyA', 'ArrowLeft'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['KeyD', 'ArrowRight'], pad: ['right', 'lx+'] },
      { id: 'sprint', label: '달리기 (누르고 있기)', keys: ['ShiftLeft', 'ShiftRight'], pad: ['ls'] },
      { id: 'crouch', label: '앉기 켜고 끄기 (잠입)', keys: ['KeyC', 'ControlLeft'], pad: ['rs'] },
      { id: 'fire', label: '쏘기 (마우스 왼쪽도)', keys: [], pad: ['rt'] },
      { id: 'melee', label: '근접 공격 (마우스 오른쪽도)', keys: ['KeyV'], pad: ['lt'] },
      { id: 'rl', label: '장전', keys: ['KeyR'], pad: ['x'] },
      { id: 'use', label: '대화·해킹·지하철 / 대화 넘기기', keys: ['KeyE', 'KeyF'], pad: ['a'] },
      { id: 'nextw', label: '다음 무기 (휠도)', keys: ['KeyQ'], pad: ['rb'] },
      { id: 'w1', label: '1번 총', keys: [], pad: [] }, { id: 'w2', label: '2번 총', keys: [], pad: [] }, { id: 'w3', label: '근접 무기 들기', keys: [], pad: [] },
      { id: 'qh1', label: '퀵해킹 1 / 대화 선택 1', keys: ['Digit1'], pad: [] }, { id: 'qh2', label: '퀵해킹 2 / 선택 2', keys: ['Digit2'], pad: [] }, { id: 'qh3', label: '퀵해킹 3 / 선택 3', keys: ['Digit3'], pad: [] }, { id: 'qh4', label: '퀵해킹 4 / 선택 4', keys: ['Digit4'], pad: [] }, { id: 'qh5', label: '퀵해킹 5 / 선택 5', keys: ['Digit5'], pad: [] },
      { id: 'dash', label: '구르기·돌진 (잠깐 무적) / 대화 넘기기', keys: ['Space'], pad: ['b'] },
      { id: 'arm', label: '유탄(투사체 발사 팔)', keys: ['KeyT'], pad: [] },
      { id: 'heal', label: '치료 주사', keys: ['KeyH'], pad: ['lb'] },
      { id: 'ramc', label: 'RAM 충전제', keys: ['KeyG'], pad: [] },
      { id: 'frag', label: '수류탄 던지기 (커서 쪽)', keys: ['KeyX'], pad: [] },
      { id: 'time', label: '시간 가속기(의체)', keys: ['KeyZ'], pad: [] },
      { id: 'bike', label: '오토바이 타기·내리기', keys: ['KeyB'], pad: [] },
      { id: 'inv', label: '소지품·의체', keys: ['Tab', 'KeyI'], pad: ['y'] },
      { id: 'map', label: '지도', keys: ['KeyM'], pad: ['back'] },
      { id: 'jour', label: '일지(할 일·이야기·용어)', keys: ['KeyJ'], pad: [] },
      { id: 'track', label: '추적할 목표 바꾸기', keys: ['KeyN'], pad: ['start'] },
      { id: 'aimL', label: '조준 왼쪽 (패드)', keys: [], pad: ['rx-'] }, { id: 'aimR', label: '조준 오른쪽 (패드)', keys: [], pad: ['rx+'] }, { id: 'aimU', label: '조준 위 (패드)', keys: [], pad: ['ry-'] }, { id: 'aimD', label: '조준 아래 (패드)', keys: [], pad: ['ry+'] },
    ],
    quick: [
      '왼쪽 위 「지금 할 일」과 화면 가장자리의 노란 화살표를 따라가요. 사람 곁에서 E로 말을 걸어요.',
      '마우스로 조준·사격, Space 구르기. 앉아서(C) 몰래 다가가 근접 공격(오른쪽 클릭)하면 대부분 한 방이에요.',
      '네 세력 중 하나를 골라 마지막 일을 끝내면 결말이 정해져요. 의체는 강하지만 「인간성」을 깎아요.',
    ],
    rules: [
      { h: '어떤 게임인가요', p: ['비 내리는 사이버펑크 도시를 위에서 내려다보며 걷고, 싸우고, 해킹하고, 사람들과 이야기하는 혼자 하기 RPG예요.', '당신은 물건을 나르던 운반책. 사흘 전 누군가에게 총알 세 발을 맞고 검은 데이터 칩 「흑요 코어」를 잃었어요. 칩을 되찾고, 그 안의 비밀로 무엇을 할지 고르는 이야기예요. 5장, 결말 ' + Object.keys(ENDS).length + '가지(숨은 결말 하나).', '쓰러져도 끝나지 않아요. 시술소에서 깨어나고 크레딧 15%를 치료비로 내요.'] },
      { h: '길 찾기', p: ['왼쪽 위 「지금 할 일」: 굵은 글씨가 지금 따라가는 목표, 그 아래 한 줄은 어떻게 하면 되는지예요. 거리(m)도 보여요.', '화면 가장자리의 노란 화살표가 그 목표 쪽을 가리켜요. N으로 따라갈 목표를 바꿔요(일거리·부가 이야기·사건). 일지(J)의 할 일을 눌러도 돼요.', 'M 큰 지도 · 오른쪽 위 작은 지도. 「M」 표시 지하철역에서 E를 누르면 가 본 구역으로 50₵에 이동해요.', '처음 겪는 일은 위쪽에 짧은 안내 카드가 떠요(설정 「상황 안내」로 끌 수 있어요).'] },
      { h: '조작', p: ['WASD 이동 · Shift 달리기 · Space 구르기(잠깐 무적, 돌진 다리 의체가 있으면 더 멀리) · C 앉기(켜고 끄기).', '마우스 조준·왼쪽 클릭 사격 · 오른쪽 클릭/V 근접 · R 장전 · Q/휠 무기 바꾸기 · H 치료 주사 · G RAM 충전제 · X 수류탄 · B 오토바이.', 'E 말 걸기·단말기·지하철 · 1–5 퀵해킹(커서 아래 적) · Tab 소지품 · J 일지 · M 지도 · N 목표 바꾸기 · Esc 창 닫기/메뉴.', '대화에선 숫자 키로 고르고 Space/E로 넘겨요. 키는 「⌨ 조작 설정」에서 바꿀 수 있어요.'] },
      { h: '싸움과 잠입', p: ['적은 부채꼴 시야로 봐요. 머리 위 「?」는 수상해서 살펴보는 중, 「!」는 들켜서 공격해 오는 중이에요. 앉으면 덜 보이고 발소리도 작아요.', '눈치 못 챈 적(또는 시야 교란·기절 중)을 근접 공격하면 6배 피해 — 대부분 한 방이에요. 충격 곤봉·유압 망치는 죽이지 않고 기절만 시켜요(비살상).', '상자·벽 뒤에 서면 총알을 막아요. 소음 없는 총소리는 멀리까지 들려 주변 적이 몰려와요.', '중립 세력은 먼저 공격하지 않아요. 내가 먼저 때리면 그 무리가 적이 되고 평판이 떨어져요.'] },
      { h: '해킹', p: ['RAM = 머릿속 해킹 칩의 기억 용량(초록 막대). 퀵해킹을 쓰면 줄고 가만히 있어도 다시 차요.', '퀵해킹: 커서를 적 위에 두고 1–5. 단락(전기 피해)·시야 교란(경계 풀림)·무기 고장·착란(동료 공격)·과열(불)·관절 마비(느려짐)·기억 지우기·신호 추적(벽 너머 보기)·재부팅 장악(기계를 내 편으로). 여섯 개 이상이면 소지품에서 앞의 다섯 개를 골라요.', '회로 침투(단말기 퍼즐): 빛나는 가로줄에서 코드 하나 → 그 칸의 세로줄에서 하나 → 다시 가로줄… 고른 코드가 버퍼에 쌓여 「목표」 순서가 나오면 성공. 노란 테두리가 다음에 필요한 코드예요. 시간은 첫 칸을 누를 때부터 흘러요. 덤 순서까지 만들면 크레딧과 RAM.'] },
      { h: '의체 · 인간성 · 열기', p: ['의체 = 몸에 다는 기계 부품. 시술소에서 눈·팔·다리·신경·피부·체계 6부위에 달아요(같은 부위는 바뀌고 반값 돌려받음).', '인간성 = 아직 사람으로 남은 정도. 의체마다 최대치가 줄고, 시민을 해치면 내려가요. 25 아래면 RAM이 느리게 차고 화면이 지직거려요. 15 이하로 마지막 선택에 이르면 나쁜 결말. 시술소 상담(400₵)·구출·비살상 제압으로 올라요.', '열기 = 수배 정도. 시민을 다치게 하거나 경관을 공격하면 올라요. 30 이상이면 도시 경찰 「질서국」이 쫓아오고 60·85에서 더 세져요. 숨어 있으면 식고, 중개인에게 1,000₵를 내면 지워 줘요. 불법 의체는 열기를 25% 더 올려요.'] },
      { h: '세력 · 일거리 · 사건', p: ['아크라 기업(위층 대기업)·바늘회(항만 암거래)·잿빛 연합(공장 노동자)·유령망(하층 해커). 두목에게 「일거리」를 받아 끝내면 평판 +12(맞수는 −4)와 크레딧.', '평판 20이면 그 세력의 마지막 일을 맡을 수 있고, 30 이상이면 그 세력 상점이 12% 싸고, −30 이하면 적이 돼요.', '몇 분마다 근처에서 「사건」(노상강도·추락한 보급 드론·길거리 현상범)이 터져요. 주황 표시 — 무시해도 돼요.', '단말기를 뚫거나 두목을 쓰러뜨리면 「기록 조각」을 얻어요. 일지에서 도시의 숨은 이야기를 읽을 수 있어요.'] },
      { h: '상점 · 레벨', p: ['총포상(총·근접·옷·탄·약), 잡화점(탄·약·퀵해킹), 시술소(의체·상담). 물건 옆 ▲는 지금 장비보다 셈, ▼는 약함. 마우스를 올리면 자세히 비교해요.', '상점에서 「잡동사니 모두 팔기」「약한 장비 팔기」로 한 번에 정리해요. 소지품은 종류별로 걸러 볼 수 있어요.', '레벨이 오르면 몸(체력·근접)·반사(명중·치명타)·기술(RAM·해킹) 중 하나에 점수 1. 몸 6·기술 6이면 특별한 대화 선택지가 열려요.'] },
      { h: '부가 이야기', p: ['머리 위 보라 ✦ 인물에게 말을 걸면 시작돼요: 국수 노점 주인·떨리는 연구원·갇힌 밀항자·투기장 진행자·고물상 견습생·고장 난 안내 로봇·낡은 배지의 경관, 3장부터 뒷골목 시술사. 어떻게 끝냈는지가 결말 후일담에 남아요.', '숨은 결말 「새벽의 증언」: 내부 고발자의 기록을 유령망에 넘기고, 쇳날 광인을 비살상 무기로 살려서 제압하고, 인간성 60 이상으로 마지막 보고에 가면 선택지가 열려요.', '오토바이: 네온 시장 잡화 노점에서 1,500₵. 밖에서 B로 타고 내려요.'] },
      { h: '적', p: ['저격수: 붉은 조준선이 차오른 뒤 쏴요 — 엄폐하거나 시야를 끊어요. 칼날 돌격수: 가까우면 덮쳐 와요(관절 마비가 좋아요). 적 해커: 보이는 동안 업로드 막대가 차면 몸이 타요. 중화기병: 느리지만 단단해요.', '방패 경비: 앞에서 쏜 총알은 거의 막아요(파란 호). 옆·뒤로 돌아가거나, 근접·수류탄·시야 교란·기절로 방패를 내리게 해요.', '두목은 체력이 절반 아래로 내려가면 지원을 불러요. 「은빛 사냥개」는 이야기 속 강적이에요.'] },
      { h: '저장과 AI 서술', p: ['Esc 메뉴의 「저장하고 나가기」로 저장, 설정 화면 「💾 이어하기」로 이어서 해요(자동 저장도 있어요). 예전 판의 저장도 이어할 수 있어요.', '설정의 「🤖 AI 서술」을 켜면 행인의 말이 상황에 맞게 새로 만들어져요(✦ 표시). 이야기·수치는 AI가 바꾸지 않아요.', '도시는 판마다 새로 만들어져요(옵션 「고정 도시」도 있음). 판 밖 해금·영구 성장은 없어요.'] },
      { h: '용어 풀이', p: GLOSS.map((g) => g[0] + ' — ' + g[1]) },
      { h: '출처 (외부 그림·소리·글꼴)', p: CREDITS.map((c) => c[0] + ' — ' + c[1] + ' · ' + c[3] + ' · ' + c[2]).concat(['그림·소리는 모두 CC0, 제목 글꼴 Galmuri11은 SIL 오픈 폰트 라이선스예요. 못 불러오면 직접 그린 그림과 합성음으로 바뀌어요.']) },
    ],
    codex: codexDef(), preview,
    init, actor: () => null, apply() { throw new Error('realtime game: no turn actions'); }, ai: () => null, result, mount,
    _t: { sideStart, migrate, SIDE, dmgEnemy, genMap, newWorld, step, botStep, botWants, botChoice, dlgFor, dlgNode, dlgChoose, interact, breachNew, breachPick, breachSolve, termResult, Q, buySimple, buy, shopStock, autoEquip, travel, hostile, wStat, npcById, DIST, FKEYS, T, itVal, CW },
  });
})();
