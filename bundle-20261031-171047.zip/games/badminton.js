/* 배드민턴 — realtime side-view badminton, singles (1:1) or doubles (2:2).
   Shuttle physics: quadratic drag (terminal ≈ 7 m/s) → fast off the racket, then slows and drops steeply.
   Controls: ◀ ▶ move, 점프, 스윙. The shot is picked by the contact height + the held direction
   (▶ toward the net = 스매시/드라이브/헤어핀, ◀ = 드롭/리프트, none = 클리어/리프트); swing timing sets the quality.
   Rally scoring (21 or 11, win by 2, cap 30/15), 1 game or best of 3. Serve: rally winner serves, court by score parity.
   Local: me + AI (one human per phone). Online: host-authoritative shuttle + referee; guests simulate their own
   player (position/jump) and publish it with swing counters; the host streams a snapshot ~30 Hz. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- world (metres): x along the court (net at 0), y height ---------- */
  const HL = 6.7, NETH = 1.55, SSL = 1.98, DLS = 5.94, G = 9.8, K = 0.2, SUB = 1 / 240;
  const SW_END = 0.34, SW_WIN = 0.27, SW_IDEAL = 0.1;
  const CD_PT = 1.1, CD_NUM = 1.0;
  const SG = (t) => (t === 0 ? -1 : 1);          // side sign: team 0 on the left (x < 0)
  const FW = (t) => -SG(t);                       // forward = toward the net
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r2 = (v) => Math.round(v * 100) / 100;
  const SHOTS = ['클리어', '리프트', '드롭', '스매시', '드라이브', '헤어핀', '하이 서브', '숏 서브'];
  const SI = { clear: 0, lift: 1, drop: 2, smash: 3, drive: 4, net: 5, hs: 6, ss: 7 };
  const SPEC = [
    { v: [23, 25], d: [5.4, 6.3], m: 'high' },        // clear
    { v: [19, 21, 23], d: [5.0, 6.2], m: 'high' },    // lift
    { v: [7, 9, 11, 13], d: [1.1, 2.4], m: 'low' },   // drop
    { v: [29], d: [3.0, 5.6], m: 'smash' },            // smash
    { v: [17, 19], d: [3.4, 5.4], m: 'low' },          // drive
    { v: [3.5, 4.5, 5.5, 7, 9], d: [0.35, 1.3], m: 'low' }, // net (hairpin)
    { v: [16, 18, 20], d: [4.8, 6.3], m: 'high' },     // high serve
    { v: [5, 6, 7, 8.5, 10], d: [2.15, 2.8], m: 'low' }, // short serve
  ];
  const WHY = ['', '네트에 걸림', '못 넘김', '아웃', '서브 범위 밖', '못 받음', '시간 초과'];
  const DIFF = {
    1: { spd: 3.7, react: 0.32, pos: 0.45, tn: 0.075, miss: 0.1, sm: 0.55, smash: 0.15, drop: 0.2, net: 0.3, jump: false, short: 0.3, lead: 0.12 },
    2: { spd: 4.7, react: 0.18, pos: 0.22, tn: 0.04, miss: 0.05, sm: 0.38, smash: 0.35, drop: 0.25, net: 0.45, jump: true, short: 0.45, lead: 0.11 },
    3: { spd: 5.5, react: 0.1, pos: 0.08, tn: 0.016, miss: 0.02, sm: 0.22, smash: 0.55, drop: 0.3, net: 0.6, jump: true, short: 0.6, lead: 0.105 },
  };
  const LV_KO = { 1: '쉬움', 2: '보통', 3: '어려움' };

  /* ---------- scoring (pure) ---------- */
  const other = (s, t, seat) => (s.np === 4 ? (seat === t ? t + 2 : t) : t);
  function receiver(s) {
    const o = 1 - s.st, even = s.sc[s.st] % 2 === 0;
    return even ? s.rc[o] : other(s, o, s.rc[o]);
  }
  function point(s0, w, why, rl) {
    const s = JSON.parse(JSON.stringify(s0));
    if (!s.k) s.k = [[0, 0, 0], [0, 0, 0]];   // stats per side: points, points on own serve, winners (opponent could not reach)
    s.k[w][0]++; if (s.st === w) s.k[w][1]++; if ((why | 0) === 5) s.k[w][2]++;
    s.sc[w]++; s.seq++; s.lg = w; s.why = why | 0; s.rl = rl | 0; s.mx = Math.max(s.mx | 0, rl | 0); s.ng = 0;
    const a = s.sc[w], b = s.sc[1 - w];
    if ((a >= s.to && a - b >= 2) || a >= s.cap) {
      s.g[w]++; s.ng = 1;
      if (s.g[w] >= (s.bo === 3 ? 2 : 1)) { s.ph = 'done'; s.w = w; return s; }
      s.gn++; s.sc = [0, 0]; s.st = w; s.rc = [0, 1]; s.sv = s.rc[w];
      return s;
    }
    if (s.st === w) {
      if (s.np === 4) s.rc[w] = other(s, w, s.rc[w]); // server switches court, keeps serving
    } else {
      s.st = w;
      s.sv = s.sc[w] % 2 === 0 ? s.rc[w] : other(s, w, s.rc[w]);
    }
    return s;
  }
  function init(players, opts) {
    const o = opts || {};
    const np = o.fmt === 'd' ? 4 : 2;
    const to = o.to === 11 ? 11 : 21;
    const n = [];
    for (let i = 0; i < np; i++) n.push(String((players[i] && players[i].name) || ('봇 ' + (i + 1))).slice(0, 10));
    const st = U.rand(2);
    return { rid: 1 + U.rand(99999), n, np, to, cap: to === 11 ? 15 : 30, bo: o.bo === 3 ? 3 : 1,
      sc: [0, 0], g: [0, 0], gn: 1, st, rc: [0, 1], sv: st, seq: 1, lg: -1, why: 0, rl: 0, mx: 0, ng: 0, ph: 'play', w: -1 };
  }
  function result(s) {
    const r = result0(s);
    if (r) try {
      const K = s.k || [[0, 0, 0], [0, 0, 0]], P = s.n.map((x, i) => i % 2);
      r.stats = [
        { label: '총 득점', values: P.map((t) => String(K[t][0])) },
        { label: '서브권 득점', values: P.map((t) => String(K[t][1])) },
        { label: '위닝샷', values: P.map((t) => String(K[t][2])) },
        { label: '최장 랠리 (경기)', values: P.map(() => (s.mx | 0) + '회') },
      ];
    } catch (e) {}
    return r;
  }
  function result0(s) {
    if (!s || s.ph !== 'done' || !(s.w === 0 || s.w === 1)) return null;
    const tn = (t) => s.np === 4 ? s.n[t] + '·' + s.n[t + 2] : s.n[t];
    const winners = s.np === 4 ? [s.w, s.w + 2] : [s.w];
    const sc = s.bo === 3 ? '게임 ' + s.g[0] + ' : ' + s.g[1] + ' (마지막 ' + s.sc[0] + ' : ' + s.sc[1] + ')' : s.sc[0] + ' : ' + s.sc[1];
    return { winners, title: tn(s.w) + ' 승리!', text: tn(0) + ' ' + sc + ' ' + tn(1) + ' · 최장 랠리 ' + (s.mx | 0) + '회' };
  }

  /* ---------- shuttle ---------- */
  /* one step; returns 'net' | 'land' | null */
  function stepB(b, h) {
    const v = Math.hypot(b.vx, b.vy);
    b.vx += -K * v * b.vx * h; b.vy += (-G - K * v * b.vy) * h;
    const px = b.x;
    b.x += b.vx * h; b.y += b.vy * h;
    if (!b.net && px * b.x <= 0 && px !== b.x && b.y < NETH && b.y > 0) {
      b.net = 1; b.x = px >= 0 ? 0.05 : -0.05; b.vx = -b.vx * 0.08; b.vy = Math.min(b.vy, 0) * 0.3;
      return 'net';
    }
    if (b.y <= 0) { b.y = 0; return 'land'; }
    return null;
  }
  function flight(x0, y0, vx, vy) {
    const b = { x: x0, y: y0, vx, vy, net: 0 }; let apex = y0, cleared = true;
    for (let t = 0; t < 5; t += 1 / 120) {
      const e = stepB(b, 1 / 120);
      if (b.y > apex) apex = b.y;
      if (e === 'net') cleared = false;
      if (e === 'land') break;
    }
    return { x: b.x, apex, cleared };
  }
  /* aim a shot of type ti from (x0,y0) for team; q = timing quality 0..1; rnd = random fn */
  function makeShot(ti, x0, y0, team, q, rnd, dbl, pow) {
    const sp = SPEC[ti], f = FW(team);
    let d = sp.d[0] + (sp.d[1] - sp.d[0]) * rnd();
    if (ti === SI.hs && dbl) d = Math.min(d, 5.75);
    d += (rnd() - 0.5) * 2 * (1 - q) * 2.0;
    if (q < 0.3 && rnd() < 0.5) d += (rnd() < 0.5 ? -1 : 1) * (1.2 + rnd());
    const xt = f * d;
    const vs = sp.m === 'smash' ? [sp.v[0] * (0.8 + 0.22 * q) * (pow || 1)] : sp.v;
    let best = null;
    for (const v of vs) {
      const a0 = sp.m === 'smash' ? -55 : -30, a1 = sp.m === 'smash' ? 8 : 82;
      for (let a = a0; a <= a1; a += 1.5) {
        const r = a * Math.PI / 180, vx = f * v * Math.cos(r), vy = v * Math.sin(r);
        const fl = flight(x0, y0, vx, vy);
        let c = Math.abs(fl.x - xt) + (fl.cleared ? 0 : 12);
        if (sp.m === 'high') c += Math.max(0, 5 - fl.apex) * 0.6;
        else c += fl.apex * 0.06;
        if (!best || c < best.c) best = { c, vx, vy };
      }
    }
    // bad timing: the shuttle comes off flatter/weaker than meant
    const k = q < 0.3 ? 0.88 + 0.1 * rnd() : 1;
    return { vx: best.vx * k, vy: best.vy * k };
  }
  function shotType(y, dir) {
    if (y >= 2.3) return dir > 0 ? SI.smash : dir < 0 ? SI.drop : SI.clear;
    if (y >= 1.5) return dir > 0 ? SI.drive : dir < 0 ? SI.drop : SI.clear;
    return dir > 0 ? SI.net : SI.lift;
  }
  const timingQ = (sw) => clamp(1 - Math.abs(sw - SW_IDEAL) / 0.16, 0.15, 1);

  /* ---------- world ---------- */
  function newWorld(s) {
    const np = s.np, pl = [];
    for (let i = 0; i < np; i++) {
      const t = i % 2, back = i >= 2;
      pl.push({ x: SG(t) * (back ? 4.6 : 2.6), y: 0, vx: 0, vy: 0, mv: 0, sw: -1, sd: 0, cool: 0, spd: 5, jq: 0, rm: false });
    }
    const W = { b: { x: 0, y: 1, vx: 0, vy: 0, net: 0 }, pl, ph: 'wait', srv: s.sv, rcv: receiver(s), lt: -1, sv: false,
      rl: 0, hc: 0, ht: -1, hq: 1, hs: -1, t: 0, ft: 0, np, dbl: np === 4, land: null };
    // server & receiver start in the service area
    W.pl[W.srv].x = SG(W.srv % 2) * 2.5; W.pl[W.rcv].x = SG(W.rcv % 2) * 3.0;
    if (np === 4) { const m = (W.srv + 2) % 4, r = (W.rcv + 2) % 4; W.pl[m].x = SG(m % 2) * 4.6; W.pl[r].x = SG(r % 2) * 4.6; }
    holdB(W);
    return W;
  }
  function holdB(W) {
    const p = W.pl[W.srv], t = W.srv % 2;
    W.b.x = p.x + FW(t) * 0.38; W.b.y = 0.95 + p.y; W.b.vx = 0; W.b.vy = 0; W.b.net = 0;
  }
  function bounds(W, s) {
    const t = s % 2, sg = SG(t);
    let a = 0.35, b = 7.1;
    if (W.ph === 'wait') { if (s === W.srv) { a = 2.1; b = 4.0; } else if (s === W.rcv) { a = 2.1; b = 5.2; } }
    return sg < 0 ? [-b, -a] : [a, b];
  }
  function inReach(p, t, b) {
    const dx = (b.x - p.x) * FW(t), dy = b.y - p.y;
    return dx > -0.55 && dx < 1.25 && dy > 0.1 && dy < 2.85 && b.x * SG(t) > -0.05;
  }
  const canHit = (W, s) => W.ph === 'fly' && W.lt !== s % 2 && (!W.sv || s === W.rcv);
  function serve(W, s, dir, hooks, rnd) {
    if (W.ph !== 'wait' || s !== W.srv) return false;
    const t = s % 2, ti = dir > 0 ? SI.ss : SI.hs, p = W.pl[s];
    holdB(W);
    const v = makeShot(ti, W.b.x, W.b.y, t, 0.92, rnd || Math.random, W.dbl);
    W.b.vx = v.vx; W.b.vy = v.vy; W.b.net = 0;
    W.ph = 'fly'; W.lt = t; W.sv = true; W.rl = 1; W.ft = 0;
    W.hc = (W.hc + 1) % 1000; W.ht = ti; W.hq = 1; W.hs = s;
    p.sw = 0.12; p.sd = dir;
    for (let i = 0; i < W.np; i++) if (i % 2 === t) W.pl[i].cool = 0.3;
    if (hooks && hooks.hit) hooks.hit(s, ti, 1);
    return true;
  }
  function doHit(W, s, hooks, rnd) {
    const p = W.pl[s], t = s % 2, b = W.b;
    const q = timingQ(p.sw);
    const ti = shotType(b.y, p.sd);
    const pow = p.y > 0.25 ? 1.1 : 1;
    const v = makeShot(ti, b.x, b.y, t, q, rnd || Math.random, W.dbl, pow);
    b.vx = v.vx; b.vy = v.vy; b.net = 0;
    W.lt = t; W.sv = false; W.rl++; W.ft = 0;
    W.hc = (W.hc + 1) % 1000; W.ht = ti; W.hq = q; W.hs = s;
    for (let i = 0; i < W.np; i++) if (i % 2 === t) W.pl[i].cool = 0.3;
    if (hooks && hooks.hit) hooks.hit(s, ti, q);
  }
  function judge(W) {
    const x = W.b.x, side = x < 0 ? 0 : 1, H = W.lt, O = 1 - H;
    if (side === H) return { w: O, why: W.b.net ? 1 : 2 };
    if (Math.abs(x) > HL) return { w: O, why: 3 };
    if (W.sv) { const d = Math.abs(x); if (d < SSL || d > (W.dbl ? DLS : HL)) return { w: O, why: 4 }; }
    return { w: H, why: 5 };
  }
  /* advance dt. live=false: guest (no referee/hits). hooks: hit(s,ti,q), net(), land(x,in), point(r), ctl(s)->bool */
  function simulate(W, dt, hooks, live) {
    if (!(dt > 0)) return;
    const n = Math.min(400, Math.max(1, Math.ceil(dt / SUB))), h = dt / n;
    for (let i = 0; i < n; i++) {
      W.t += h;
      for (let s = 0; s < W.np; s++) {
        const p = W.pl[s];
        if (p.cool > 0) p.cool -= h;
        if (p.sw >= 0) { p.sw += h; if (p.sw > SW_END) p.sw = -1; }
        if (p.rm) continue; // remote player: position comes from the network
        const tv = clamp(p.mv, -1, 1) * p.spd, acc = 38 * h;
        p.vx += clamp(tv - p.vx, -acc, acc);
        const bd = bounds(W, s);
        p.x = clamp(p.x + p.vx * h, bd[0], bd[1]);
        if (p.x <= bd[0] || p.x >= bd[1]) p.vx = 0;
        if (p.y > 0 || p.vy > 0) { p.vy -= G * h; p.y += p.vy * h; if (p.y <= 0) { p.y = 0; p.vy = 0; } }
      }
      if (W.ph === 'wait') { holdB(W); continue; }
      if (W.ph !== 'fly' || !live) continue;
      W.ft += h;
      const e = stepB(W.b, h);
      if (e === 'net' && hooks && hooks.net) hooks.net();
      if (e === 'land' || W.ft > 14) {
        W.ph = 'dead';
        const r = W.ft > 14 ? { w: 1 - W.lt, why: 6 } : judge(W);
        W.land = { x: W.b.x, ok: r.w === W.lt };
        if (hooks && hooks.land) hooks.land(W.b.x, r.w === W.lt);
        if (hooks && hooks.point) hooks.point(r, W.rl);
        continue;
      }
      for (let s = 0; s < W.np; s++) {
        const p = W.pl[s];
        if (p.sw < 0 || p.sw > SW_WIN || p.cool > 0 || !canHit(W, s)) continue;
        if (!inReach(p, s % 2, W.b)) continue;
        doHit(W, s, hooks);
        break;
      }
    }
  }
  function startSwing(W, s, dir, hooks) {
    const p = W.pl[s];
    if (W.ph === 'wait' && s === W.srv) return serve(W, s, dir, hooks);
    if (p.sw >= 0 && p.sw < SW_END - 0.06) return false;
    p.sw = 0; p.sd = dir;
    return true;
  }
  function jump(p) { if (p.y <= 0 && p.vy <= 0) { p.vy = 4.3; return true; } return false; }

  /* ---------- AI ---------- */
  function predict(b0, T) {
    const b = Object.assign({}, b0), out = [];
    for (let t = 0; t < (T || 3); t += 1 / 60) {
      const e = stepB(b, 1 / 60);
      out.push({ t: t + 1 / 60, x: b.x, y: b.y });
      if (e === 'land' || e === 'net') break;
    }
    return out;
  }
  function aiThink(W, s, mem, D, dt, hooks) {
    const p = W.pl[s], t = s % 2, sg = SG(t), f = FW(t);
    p.spd = D.spd;
    mem.rt = (mem.rt || 0) - dt;
    const go = (x) => { const d = x - p.x; p.mv = Math.abs(d) < 0.08 ? 0 : clamp(d * 2.5, -1, 1); };
    const mate = W.np === 4 ? W.pl[(s + 2) % 4] : null;
    // doubles formation: attacking → front/back, defending → side by side (two lanes, same depth)
    const hum = mate && W.pl[(s + 2) % 4].hm;
    const att = !mate ? false : W.lt === t ? [SI.smash, SI.drop, SI.drive, SI.net, SI.ss].indexOf(W.ht) >= 0 : [SI.clear, SI.lift, SI.hs].indexOf(W.ht) >= 0;
    const front = mate && (Math.abs(p.x) < Math.abs(mate.x) - 0.05 || (Math.abs(Math.abs(p.x) - Math.abs(mate.x)) <= 0.05 && s < 2));
    const home = () => {
      if (!mate) return sg * 3.3;
      if (W.ph !== 'fly' || att || hum) return front ? sg * 2.3 : sg * 4.4;
      return sg * 3.5;
    };
    if (W.ph === 'wait') {
      mem.plan = null; mem.swung = -1;
      if (W.srv === s) {
        go(sg * 2.5);
        if (mem.serveT == null) mem.serveT = 0.7 + Math.random() * 0.9;
        mem.serveT -= dt;
        if (mem.serveT <= 0) { mem.serveT = null; serve(W, s, Math.random() < D.short * (W.dbl ? 1.5 : 1) ? 1 : 0, hooks); }
      } else if (W.rcv === s) go(sg * 3.0);
      else go(mate ? sg * 4.4 : sg * 3.3);
      return;
    }
    mem.serveT = null;
    if (W.ph !== 'fly') { go(home()); return; }
    if (!canHit(W, s)) { mem.plan = null; go(W.lt === t ? home() : sg * 3.3); return; }
    if (!mem.plan || mem.hc !== W.hc || mem.rt <= 0) {
      mem.rt = D.react;
      const fresh = mem.hc !== W.hc; mem.hc = W.hc;
      if (fresh) { mem.wait = D.react; mem.swung = -1; mem.err = (Math.random() - 0.5) * 2 * D.pos; mem.skip = Math.random() < D.miss + (W.ht === SI.smash ? D.sm * (W.hq > 0.8 ? 1.2 : 0.8) : W.ht === SI.drive ? D.sm * 0.35 : 0); mem.choice = null; }
      const tr = predict(W.b, 3.5);
      const maxY = D.jump ? 3.45 : 2.75;
      let pick = null;
      for (const pt of tr) {
        if (pt.x * sg < 0.3 || pt.y > maxY) continue;
        const need = Math.abs((pt.x - f * 0.5) - p.x) / D.spd + 0.12;
        if (need <= pt.t) { pick = pt; break; }
      }
      if (!pick) for (let i = tr.length - 1; i >= 0; i--) if (tr[i].x * sg > 0.3) { pick = tr[i]; break; }
      if (pick) mem.plan = { x: pick.x - f * 0.5, y: pick.y, at: W.t + pick.t };
      else mem.plan = { x: home(), y: 0, at: W.t + 1 };
      // doubles: who takes it — front/back split when attacking, lanes when defending; with a human partner: whoever is closer
      if (mate && mem.plan) {
        const mine = Math.abs(p.x - mem.plan.x), theirs = Math.abs(mate.x - mem.plan.x);
        if (hum) mem.mine = !(theirs + 0.3 < mine || (Math.abs(theirs - mine) <= 0.3 && Math.abs(mate.x) > Math.abs(p.x) === (Math.abs(mem.plan.x) > 3.3)));
        else if (att) mem.mine = front === (Math.abs(mem.plan.x) < 3.4);
        else mem.mine = (((W.hc * 7) >> 1) % 2 === 0) === (s < 2);
        if (!hum && theirs + 1.6 < mine) mem.mine = false; // partner is clearly closer anyway
        if (!hum && mine + 1.6 < theirs) mem.mine = true;
      } else mem.mine = true;
    }
    if (mem.wait > 0) { mem.wait -= dt; return; }
    if (!mem.mine) { // cover the other half; in front/back keep clear of the partner's path
      let x = att || hum ? (Math.abs(mem.plan.x) > 3.3 ? sg * 2.3 : sg * 4.4) : sg * 3.5;
      if ((att || hum) && Math.abs(x - mate.x) < 1.0) x = clamp(mate.x + (Math.abs(x) > Math.abs(mate.x) ? sg : -sg) * 1.0, sg < 0 ? -7.1 : 0.35, sg < 0 ? -0.35 : 7.1);
      go(x); return;
    }
    go(clamp(mem.plan.x + mem.err, sg < 0 ? -7.1 : 0.35, sg < 0 ? -0.35 : 7.1));
    if (D.jump && mem.plan.y > 2.7 && p.y === 0 && mem.plan.at - W.t < 0.45 && mem.plan.at - W.t > 0.3) jump(p);
    // swing timing: look a little ahead for the first moment the shuttle enters the reach box
    if (mem.swung === W.hc || mem.skip) return;
    const b = Object.assign({}, W.b), pp = { x: p.x, y: p.y };
    let te = -1;
    for (let k = 0; k <= 18; k++) {
      if (inReach(pp, t, b)) { te = k / 60; break; }
      if (stepB(b, 1 / 60)) break;
    }
    if (te < 0) return;
    if (mem.lead == null || mem.leadHc !== W.hc) { mem.leadHc = W.hc; mem.lead = D.lead + (Math.random() - 0.5) * 2 * D.tn; }
    if (te > mem.lead) return;
    // choose the shot
    const y = b.y, r = Math.random();
    let dir = 0;
    if (y >= 2.3) dir = r < D.smash && Math.abs(b.x) < 5.8 ? 1 : r < D.smash + D.drop ? -1 : 0;
    else if (y >= 1.5) dir = r < 0.4 ? 1 : r < 0.4 + D.drop ? -1 : 0;
    else dir = Math.abs(b.x) < 2.6 && r < D.net ? 1 : 0;
    mem.swung = W.hc;
    startSwing(W, s, dir, hooks);
  }

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    let st = null, key = null, W = null, phase = 'count', cd = 0, banner = null, lay = null, bg = null, flip = false;
    let mem = [{}, {}, {}, {}], fx = [], trail = [], shake = 0, flash = 0, lastSfx = 0, pubT = 0, q = 0;
    let pendingPt = null, rallyPop = 0, lastRl = 0, hintT = 9, snap = null, lastQ = -1, seenHc = -1;
    const remS = {}; let swN = 0, swD = 0, lastSw = -1;
    const P = (s) => api.players[s] || { name: '봇', color: ['#e9785f', '#5fa8e9', '#e9c25f', '#7fd18b'][s] || '#aaa', ai: true, lv: 2, bot: true };
    const D = (s) => DIFF[P(s).lv] || DIFF[2];
    const name = (s) => (st && st.n && st.n[s]) || P(s).name || (s + 1) + '번';
    const local = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const host = () => !api.online || api.isHost;
    const simHere = (s) => { const p = api.players[s]; if (!p) return host(); if (!api.online) return true; if (api.isHost) return !!p.ai || !!p.local; return !p.ai && !!p.local; };
    const aiCtl = (s) => simHere(s) && (P(s).ai || !!(L.debug && L.debug.autoplay));
    const np = () => (st ? st.np : 2);
    const me = () => { for (let s = 0; s < np(); s++) if (local(s)) return s; return -1; };
    const meH = () => { const m = me(); return m >= 0 && !aiCtl(m) ? m : -1; };
    const myTeam = () => { const m = me(); return m >= 0 ? m % 2 : 0; };

    /* ----- DOM controls ----- */
    const held = { l: 0, r: 0 };
    const pad = L.h('div', { style: { position: 'absolute', left: '0', right: '0', bottom: '0', height: '0', pointerEvents: 'none' } });
    function mkBtn(label, cls, onDown, onUp) {
      const b = L.h('button', { class: 'bm-btn ' + cls, style: { pointerEvents: 'auto' } });
      b.innerHTML = label;
      const dn = (e) => { e.preventDefault(); try { b.setPointerCapture(e.pointerId); } catch (er) {} b.classList.add('on'); onDown(); };
      const upf = (e) => { b.classList.remove('on'); if (onUp) onUp(); };
      b.addEventListener('pointerdown', dn); b.addEventListener('pointerup', upf); b.addEventListener('pointercancel', upf); b.addEventListener('lostpointercapture', upf);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
      pad.appendChild(b); return b;
    }
    const css = L.h('style', { text: '.bm-btn{position:absolute;border-radius:18px;border:2px solid rgba(242,233,216,.25);background:rgba(46,38,64,.82);color:var(--ink);font:700 15px var(--f-body),sans-serif;touch-action:none;user-select:none;-webkit-user-select:none;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.1;box-shadow:0 4px 0 rgba(0,0,0,.35)}.bm-btn.on{transform:translateY(3px);box-shadow:0 1px 0 rgba(0,0,0,.35);background:rgba(227,174,69,.35)}.bm-btn .ar{font-size:26px}.bm-sw{background:rgba(238,106,85,.85);border-color:rgba(255,220,200,.5);font-size:18px}.bm-sw small{font:600 12px var(--f-body),sans-serif;opacity:.9;margin-top:3px}.bm-sw.go{box-shadow:0 0 0 4px rgba(255,230,140,.75),0 4px 0 rgba(0,0,0,.35)}' });
    root.appendChild(css);
    const bL = mkBtn('<span class="ar">◀</span>', 'bm-l', () => { held.l = 1; }, () => { held.l = 0; });
    const bR = mkBtn('<span class="ar">▶</span>', 'bm-r', () => { held.r = 1; }, () => { held.r = 0; });
    const bJ = mkBtn('점프', 'bm-j', () => doJump());
    const bS = mkBtn('스윙<small></small>', 'bm-sw', () => doSwing());
    const swLab = bS.querySelector('small');
    [[bL, 'left'], [bR, 'right'], [bJ, 'jump'], [bS, 'swing']].forEach(([b, a]) => b.setAttribute('data-action', a));
    root.appendChild(pad);
    function placeButtons() {
      const w = cv.w, ph = lay.panel, y0 = 10, bh = Math.min(84, ph - 22);
      const bw = Math.min(84, (w - 48) / 4.3);
      const set = (b, x, ww) => Object.assign(b.style, { left: x + 'px', top: y0 + 'px', width: ww + 'px', height: bh + 'px' });
      pad.style.height = ph + 'px';
      set(bL, 12, bw); set(bR, 20 + bw, bw);
      set(bS, w - 12 - bw * 1.25, bw * 1.25); set(bJ, w - 20 - bw * 2.25, bw);
      pad.style.display = meH() >= 0 ? '' : 'none';
    }
    // world direction from screen keys/buttons
    function inDir() {
      let ax = (held.r - held.l);
      if (api.input) { const a = api.input.axis('left', 'right'); if (a) ax = a; }
      ax = Math.abs(ax) < 0.3 ? 0 : ax;
      return flip ? -ax : ax;
    }
    function doJump() {
      const s = meH(); if (s < 0 || !W || phase === 'done') return;
      if (jump(W.pl[s])) { api.sfx('whoosh'); api.buzz(8); }
    }
    function doSwing() {
      const s = meH(); if (s < 0 || !W || phase !== 'play') return;
      const dir = Math.sign(inDir()) * FW(s % 2);
      hintT = Math.min(hintT, 2);
      if (host()) { if (!startSwing(W, s, dir, hooks)) { bufT = 0.14; bufD = dir; } }
      else { const p = W.pl[s]; if (!(p.sw >= 0 && p.sw < SW_END - 0.06)) { p.sw = 0; p.sd = dir; } swN = (swN + 1) % 1000; swD = dir; pubT = 0; }
      api.buzz(10); sfx('whoosh', 80);
    }
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'swing') doSwing(); else if (id === 'jump') doJump();
    }) : null;

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const panel = Math.max(96, Math.min(120, h * 0.16));
      const top = 74, bottom = h - panel - 30;
      const s = Math.min((w - 12) / 15.6, (bottom - top) / 7.6);
      lay = { s, cx: w / 2, fy: bottom, top, panel, w, h };
      flip = myTeam() === 1;
      buildBg(); placeButtons();
    }
    const toS = (x, y) => ({ x: lay.cx + (flip ? -x : x) * lay.s, y: lay.fy - y * lay.s });
    function buildBg() {
      const c = document.createElement('canvas');
      c.width = Math.round(cv.w * cv.dpr); c.height = Math.round(cv.h * cv.dpr);
      const g = c.getContext('2d'); g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      const w = cv.w, h = cv.h, s = lay.s, fy = lay.fy;
      const wall = g.createLinearGradient(0, 0, 0, fy);
      wall.addColorStop(0, '#120e1a'); wall.addColorStop(0.6, '#241b33'); wall.addColorStop(1, '#2f2440');
      g.fillStyle = wall; g.fillRect(0, 0, w, h);
      // hall lights
      for (let i = 0; i < 4; i++) {
        const lx = w * (0.14 + i * 0.24), gr = g.createRadialGradient(lx, lay.top - 20, 2, lx, lay.top + 60, s * 6);
        gr.addColorStop(0, 'rgba(255,236,200,.22)'); gr.addColorStop(1, 'rgba(255,236,200,0)');
        g.fillStyle = gr; g.fillRect(0, 0, w, fy);
      }
      // stands with a quiet crowd
      const sy0 = lay.top + 30, sy1 = fy - s * 1.3;
      if (sy1 - sy0 > 40) {
        for (let y = sy1, r = 0; y > sy0; y -= 16, r++) {
          g.fillStyle = r % 2 ? 'rgba(255,255,255,.025)' : 'rgba(0,0,0,.12)'; g.fillRect(0, y - 16, w, 16);
          for (let x = (r % 2) * 7; x < w; x += 14) {
            if (Math.random() < 0.6) continue;
            g.fillStyle = ['rgba(238,106,85,', 'rgba(95,168,233,', 'rgba(227,174,69,', 'rgba(171,159,184,'][(Math.random() * 4) | 0] + (0.07 + 0.07 * Math.random()) + ')';
            g.beginPath(); g.arc(x, y - 10, 3.2, 0, Math.PI * 2); g.fill(); g.fillRect(x - 4, y - 7, 8, 7);
          }
        }
        g.fillStyle = 'rgba(227,174,69,.35)'; g.fillRect(0, sy1, w, 2);
      }
      // padded wall strip
      g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, fy - s * 1.1, w, s * 1.1 - s * 0.5);
      // floor (fake perspective band)
      const fb = s * 0.55, ff = s * 0.75;
      const fl = g.createLinearGradient(0, fy - fb, 0, h);
      fl.addColorStop(0, '#2f6a52'); fl.addColorStop(0.35, '#246048'); fl.addColorStop(1, '#173d30');
      g.fillStyle = '#5a3d2c'; g.fillRect(0, fy - fb, w, h - fy + fb);
      const A = (x, k) => lay.cx + (flip ? -x : x) * s * (1 + k * 0.06);
      g.fillStyle = fl; g.beginPath();
      g.moveTo(A(-HL - 0.4, -1), fy - fb); g.lineTo(A(HL + 0.4, -1), fy - fb); g.lineTo(A(HL + 0.4, 1), fy + ff); g.lineTo(A(-HL - 0.4, 1), fy + ff); g.closePath(); g.fill();
      g.strokeStyle = 'rgba(242,236,224,.85)'; g.lineWidth = 2;
      const line = (x) => { g.beginPath(); g.moveTo(A(x, -1), fy - fb); g.lineTo(A(x, 1), fy + ff); g.stroke(); };
      [-HL, HL, -SSL, SSL, -DLS, DLS].forEach(line);
      g.lineWidth = 1.5; g.beginPath(); g.moveTo(A(-HL, -1), fy - fb); g.lineTo(A(HL, -1), fy - fb); g.moveTo(A(-HL, 1), fy + ff); g.lineTo(A(HL, 1), fy + ff); g.stroke();
      // centre line (front court halves)
      g.globalAlpha = 0.5; g.beginPath(); g.moveTo(A(-HL, 0), fy + (ff - fb) / 2); g.lineTo(A(-SSL, 0), fy + (ff - fb) / 2); g.moveTo(A(SSL, 0), fy + (ff - fb) / 2); g.lineTo(A(HL, 0), fy + (ff - fb) / 2); g.stroke(); g.globalAlpha = 1;
      // floor grain
      g.globalAlpha = 0.05; g.fillStyle = '#fff';
      for (let i = 0; i < 200; i++) g.fillRect(Math.random() * w, fy - fb + Math.random() * (fb + ff), 2, 1);
      g.globalAlpha = 1;
      // net: posts + mesh band
      const nx = lay.cx, nt = fy - NETH * s, nb = fy - 0.78 * s;
      g.fillStyle = '#d9d2c4'; g.fillRect(nx - 2, nt - 2, 4, fy - nt + 2);
      g.fillStyle = 'rgba(20,20,26,.55)'; g.fillRect(nx - 5, nt, 10, nb - nt);
      g.strokeStyle = 'rgba(230,230,230,.35)'; g.lineWidth = 1;
      for (let yy = nt + 4; yy < nb; yy += 4) { g.beginPath(); g.moveTo(nx - 5, yy); g.lineTo(nx + 5, yy); g.stroke(); }
      g.fillStyle = '#f4f0e6'; g.fillRect(nx - 6, nt - 3, 12, 4);
      g.fillStyle = '#e3ae45'; g.fillRect(nx - 3, nt - 10, 6, 7);
      bg = c;
    }

    /* ----- feedback ----- */
    /* 스매시 연출(보기만): 잔상·짧은 슬로·흔들림·소리. 판정·물리는 그대로 */
    let smashT = 0, slowT = 0, actx = null, stopT = 0, bufT = 0, bufD = 0, rkF = [0, 0, 0, 0];
    function smashSnd(pw) {
      const vol = L.audio && L.audio.sfx ? L.audio.sfx() : 1; if (!vol) return;
      try {
        actx = actx || new (window.AudioContext || window.webkitAudioContext)();
        const t = actx.currentTime, n = Math.floor(actx.sampleRate * 0.28), buf = actx.createBuffer(1, n, actx.sampleRate), d = buf.getChannelData(0);
        for (let i = 0; i < n; i++) { const k = i / n; d[i] = (Math.random() * 2 - 1) * (i < 300 ? 1 : Math.pow(1 - k, 2) * 0.5); }
        const src = actx.createBufferSource(); src.buffer = buf;
        const bp = actx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 1.2; bp.frequency.setValueAtTime(3800, t); bp.frequency.exponentialRampToValueAtTime(600, t + 0.28);
        const g = actx.createGain(); g.gain.setValueAtTime(0.5 * vol * Math.min(1, pw), t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
        src.connect(bp); bp.connect(g); g.connect(actx.destination); src.start(t);
      } catch (e) {}
    }
    function sfx(n, gap) { const t = performance.now(); if (t - lastSfx < (gap || 40)) return; lastSfx = t; api.sfx(n); }
    function hitFx(s, ti, qq) {
      const b = W.b, smash = ti === SI.smash;
      sfx(smash ? 'hit' : ti === SI.net || ti === SI.ss ? 'pop' : 'chip');
      if (local(s)) api.buzz(smash ? [25, 30, 20] : qq < 0.5 ? 6 : 12);
      fx.push({ k: 'ring', x: b.x, y: b.y, t: 0.3, T: 0.3, col: P(s).color, big: smash });
      const sp0 = Math.hypot(b.vx, b.vy), fast = smash && sp0 > 20;
      if (fast) { smashT = 0.6; if (!api.online) slowT = 0.3 * L.fx(); shake = 0.9; smashSnd(sp0 / 28); }
      if (smash) { shake = Math.max(shake, 0.6); flash = 0.25; fx.push({ k: 'txt', x: b.x, y: b.y + 0.6, t: 0.9, T: 0.9, s: '스매시!', col: '#ffd36a', big: 1 }); }
      if (!smash && SHOTS[ti]) { fx.push({ k: 'txt', x: b.x, y: Math.max(2.35, b.y + 0.7), t: 0.8, T: 0.8, s: SHOTS[ti], col: 'rgba(255,255,255,.85)' }); }
      if (smash) { /* 위에서 처리 */ }
      // 타이밍 판정(내 손으로 친 공만): 빠름/정확/늦음 — 품질(qq)은 이미 샷 속도·정확도에 반영됨
      const sw = W.pl[s].sw;
      if (local(s) && !P(s).ai && ti !== SI.ss && ti !== SI.hs && sw >= 0) {
        const good = qq >= 0.8, early = sw > SW_IDEAL;
        fx.push({ k: 'txt', x: b.x, y: b.y + (smash ? 1.2 : 0.5), t: 0.7, T: 0.7, s: good ? '정확!' : early ? '빠름' : '늦음', col: good ? '#bfe9a8' : '#f0b27a' });
      }
      rkF[s] = 0.16;
      if (!api.online) stopT = (smash ? 0.07 : qq >= 0.8 ? 0.045 : 0.025) * L.fx();
      if (!smash && local(s)) { if (qq >= 0.8) api.buzz([8, 20, 12]); }
      rallyPop = 0.35;
    }
    const hooks = {
      hit(s, ti, qq) { hitFx(s, ti, qq); },
      net() { sfx('thud', 60); },
      land(x, ok) { sfx('bounce', 50); fx.push({ k: 'land', x, y: 0, t: 1.2, T: 1.2, ok }); },
      point(r, rl) { pendingPt = { r, rl }; },
    };

    function startPoint(next) {
      const keep = W ? W.pl.map((p) => p.x) : null;
      W = newWorld(next);
      if (keep && next.ng !== 1) W.pl.forEach((p, i) => { if (i !== W.srv && i !== W.rcv && fin(keep[i])) p.x = keep[i]; });
      for (let s = 0; s < W.np; s++) { W.pl[s].rm = api.online && !simHere(s); W.pl[s].hm = !P(s).ai; }
      mem = [{}, {}, {}, {}]; trail.length = 0; pendingPt = null; snap = null; lastRl = 0;
      if (next.ph === 'done') { phase = 'done'; W.ph = 'dead'; return; }
      phase = 'count'; cd = (next.lg >= 0 ? CD_PT : 0) + CD_NUM + (next.ng ? 0.8 : 0);
      banner = next.lg >= 0 ? { w: next.lg, why: next.why | 0, rl: next.rl | 0, ng: next.ng } : null;
      if (next.lg >= 0) {
        const m = me();
        if (m < 0) api.sfx('chip');
        else if (m % 2 === next.lg) { api.sfx(next.ng ? 'win' : 'chip'); api.buzz(20); } else { api.sfx(next.ng ? 'lose' : 'thud'); api.buzz(35); }
        const a = next.sc[0], b = next.sc[1];
        if (!next.ng && a === b && a >= next.to - 1 && a < next.cap - 1) api.toast('듀스!');
        if (!next.ng && Math.max(a, b) === next.cap - 1 && a === b) api.toast('다음 점수가 이겨요');
      }
    }
    function doPoint(r, rl) {
      if (!st || st.ph === 'done' || !host()) return;
      api.setState(point(st, r.w, r.why, rl));
    }

    /* ----- online ----- */
    const curKey = () => (st ? st.rid + '.' + st.seq : null);
    function pollNet(now) {
      if (!api.online) return;
      if (api.isHost) {
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (rem && typeof rem === 'object') for (const k in rem) {
          const s = +k, o = rem[k];
          if (!(s >= 0 && s < W.np) || simHere(s) || !o || typeof o !== 'object' || o.k !== curKey()) continue;
          const p = W.pl[s], r = remS[s] || (remS[s] = { sw: -1 });
          if (fin(o.x) && fin(o.y)) { const bd = bounds(W, s); p.x = clamp(o.x, bd[0], bd[1]); p.y = Math.max(0, o.y); }
          if (fin(o.sw) && o.sw !== r.sw) { if (r.sw >= 0 && startSwing(W, s, clamp(o.d | 0, -1, 1), hooks) && W.pl[s].sw === 0) W.pl[s].sw = 0.05; r.sw = o.sw; /* ~50 ms network lag */ }
        }
      } else {
        let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
        if (!hs || typeof hs !== 'object' || hs.k !== curKey() || hs.q === lastQ) return;
        lastQ = hs.q;
        if (Array.isArray(hs.b) && hs.b.length >= 4 && hs.b.every(fin)) snap = { b: hs.b, at: now };
        W.ph = ['wait', 'fly', 'dead'][hs.e | 0] || 'dead';
        W.lt = fin(hs.lt) ? hs.lt : -1; W.rl = hs.rl | 0; W.sv = !!hs.sv;
        if (Array.isArray(hs.p)) hs.p.forEach((a, s) => {
          if (simHere(s) || !Array.isArray(a) || !W.pl[s]) return;
          const p = W.pl[s]; p.nx = a[0]; p.ny = a[1];
          if (a[2] >= 0 && (p.sw < 0 || a[2] / 100 < p.sw - 0.08)) p.sw = a[2] / 100;
        });
        if (fin(hs.hc) && hs.hc !== seenHc) {
          if (seenHc >= 0 && fin(hs.ht)) { if (snap) { W.b.x = snap.b[0]; W.b.y = snap.b[1]; } hitFx(hs.hs | 0, hs.ht, fin(hs.hq) ? hs.hq : 1); }
          seenHc = hs.hc; W.hc = hs.hc; if (fin(hs.ht)) W.ht = hs.ht; if (fin(hs.hq)) W.hq = hs.hq;
        }
      }
    }
    function guestFollow(rdt, now) {
      for (let s = 0; s < W.np; s++) {
        const p = W.pl[s];
        if (simHere(s) || !fin(p.nx)) continue;
        const k = 1 - Math.exp(-rdt * 18);
        p.x += (p.nx - p.x) * k; p.y += (p.ny - p.y) * k;
      }
      if (!snap) return;
      const b = snap.b, age = Math.min(0.15, (now - snap.at) / 1000 + 0.03) * SPD();
      const t = { x: b[0], y: b[1], vx: b[2], vy: b[3], net: 1 };
      if (W.ph === 'fly') for (let a = 0; a < age; a += 1 / 120) if (stepB(t, 1 / 120)) break;
      const d = Math.hypot(t.x - W.b.x, t.y - W.b.y), k = 1 - Math.exp(-rdt * 20);
      if (d > 1.2 || W.ph !== 'fly') Object.assign(W.b, { x: t.x, y: t.y }); else { W.b.x += (t.x - W.b.x) * k; W.b.y += (t.y - W.b.y) * k; }
      W.b.vx = t.vx; W.b.vy = t.vy;
    }
    function publish(rdt) {
      if (!api.online) return;
      pubT -= rdt; if (pubT > 0) return; pubT = 1 / 30;
      q = (q + 1) % 1000;
      try {
        if (api.isHost) {
          const b = W.b;
          api.net.hostSend({ k: curKey(), q, b: [r2(b.x), r2(b.y), r2(b.vx), r2(b.vy)], e: ['wait', 'fly', 'dead'].indexOf(W.ph),
            p: W.pl.map((p) => [r2(p.x), r2(p.y), p.sw >= 0 ? Math.round(p.sw * 100) : -1]), hc: W.hc, ht: W.ht, hq: r2(W.hq), hs: W.hs, lt: W.lt, rl: W.rl, sv: W.sv ? 1 : 0 });
        } else {
          const s = me(); if (s < 0) return;
          const p = W.pl[s];
          api.net.publish({ k: curKey(), q, x: r2(p.x), y: r2(p.y), sw: swN, d: swD });
        }
      } catch (e) {}
    }

    /* ----- frame ----- */
    function frame(rdt, now) {
      if (!st || !W) return;
      const slowK = slowT > 0 ? 0.35 : 1; slowT = Math.max(0, slowT - rdt);
      smashT = Math.max(0, smashT - rdt);
      const hs = stopT > 0; stopT = Math.max(0, stopT - rdt);
      const dt = hs ? 0 : rdt * SPD() * slowK;
      for (let i = 0; i < 4; i++) rkF[i] = Math.max(0, rkF[i] - rdt);
      if (bufT > 0) { bufT -= rdt; const s = meH(); if (s >= 0 && phase === 'play' && host() && startSwing(W, s, bufD, hooks)) bufT = 0; }
      pollNet(now);
      if (phase === 'count') {
        const before = cd; cd -= dt;
        if (before > CD_NUM * 0.5 && cd <= CD_NUM * 0.5) api.sfx('tick');
        if (cd <= 0) { phase = 'play'; banner = null; }
      }
      const live = phase === 'play';
      for (let s = 0; s < W.np; s++) {
        const p = W.pl[s];
        if (!simHere(s)) continue;
        if (aiCtl(s)) {
          if (live || W.ph !== 'wait') aiThink(W, s, mem[s], P(s).ai ? D(s) : DIFF[2], dt, hooks);
          else p.mv = 0;
        } else p.mv = inDir();
      }
      if (hintT > 0 && W.ph === 'fly') hintT -= rdt;
      const guest = api.online && !api.isHost;
      if (phase === 'done') W.ph = 'dead';
      if (guest && aiCtl(me()) && me() >= 0) { // debug autoplay on a guest: forward the AI's swings to the host
        const p = W.pl[me()];
        if (p.sw >= 0 && (lastSw < 0 || p.sw < lastSw)) { swN = (swN + 1) % 1000; swD = p.sd; pubT = 0; }
        lastSw = p.sw;
      }
      if (guest) { const ph = W.ph; simulate(W, Math.min(dt, 0.25), hooks, false); W.ph = ph; guestFollow(rdt, now); }
      else simulate(W, Math.min(dt, 0.25), hooks, true);
      if (pendingPt) { const x = pendingPt; pendingPt = null; doPoint(x.r, x.rl); }
      if (W.ph === 'fly') { trail.push({ x: W.b.x, y: W.b.y }); if (trail.length > 9) trail.shift(); } else if (trail.length) trail.shift();
      if (W.rl !== lastRl) { lastRl = W.rl; }
      for (let i = fx.length - 1; i >= 0; i--) { fx[i].t -= rdt; if (fx[i].t <= 0) fx.splice(i, 1); }
      shake = Math.max(0, shake - rdt * 2.5); flash = Math.max(0, flash - rdt); rallyPop = Math.max(0, rallyPop - rdt);
      publish(rdt);
    }

    /* ----- drawing ----- */
    function drawPlayer(s) {
      const p = W.pl[s], t = s % 2, col = P(s).color || '#ccc', S = lay.s;
      const depth = s >= 2 ? -0.18 : 0.12; // doubles partner a little "behind"
      const base = toS(p.x, p.y), fx0 = base.x, fy0 = base.y + depth * S;
      const face = FW(t) * (flip ? -1 : 1);
      // shadow
      const sh = toS(p.x, 0);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(sh.x, sh.y + depth * S, S * 0.38 * (1 - Math.min(0.5, p.y * 0.4)), S * 0.08, 0, 0, Math.PI * 2); ctx.fill();
      const run = Math.sin(W.t * 14) * clamp(Math.abs(p.vx) / 4, 0, 1) * (p.y > 0 ? 0 : 1);
      ctx.save(); ctx.translate(fx0, fy0); ctx.scale(face, 1);
      ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      const u = S; // 1 m in px
      // legs
      ctx.strokeStyle = '#2a2233'; ctx.lineWidth = Math.max(3, u * 0.13);
      const hip = -0.9 * u, kn = p.y > 0 ? 0.25 : 0;
      ctx.beginPath(); ctx.moveTo(0, hip); ctx.lineTo((0.18 + run * 0.25 + kn * 0.3) * u, -0.45 * u); ctx.lineTo((0.12 + run * 0.4) * u, 0); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, hip); ctx.lineTo((-0.12 - run * 0.25 + kn * 0.2) * u, -0.45 * u); ctx.lineTo((-0.2 - run * 0.4) * u, 0); ctx.stroke();
      // torso
      ctx.strokeStyle = col; ctx.lineWidth = Math.max(6, u * 0.3);
      ctx.beginPath(); ctx.moveTo(0, hip); ctx.lineTo(0.05 * u, -1.42 * u); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.25)'; ctx.lineWidth = Math.max(1.5, u * 0.05);
      ctx.beginPath(); ctx.moveTo(0.06 * u, -1.0 * u); ctx.lineTo(0.08 * u, -1.38 * u); ctx.stroke();
      // head
      ctx.fillStyle = '#f0c9a4'; ctx.beginPath(); ctx.arc(0.08 * u, -1.65 * u, Math.max(4, u * 0.15), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2b1d22'; ctx.beginPath(); ctx.arc(0.04 * u, -1.7 * u, Math.max(4, u * 0.15), Math.PI * 0.95, Math.PI * 1.9); ctx.fill();
      ctx.fillStyle = col; ctx.fillRect(-0.1 * u, -1.76 * u, 0.36 * u, Math.max(2, u * 0.05));
      // racket arm: angle from forward horizontal (up positive)
      let ang;
      const serving = W.ph === 'wait' && s === W.srv;
      if (p.sw >= 0) {
        const k = clamp(p.sw / 0.22, 0, 1), e = 1 - Math.pow(1 - k, 3);
        ang = (p.sd < 0 && W.b.y < 1.5) || serving ? -150 + e * 200 : 125 - e * 215;
        if (W.ht === SI.ss || W.ht === SI.hs) ang = -150 + e * 200;
      } else ang = serving ? -150 : 115;
      const a = ang * Math.PI / 180, sx = 0.08 * u, sy = -1.42 * u;
      const ex = sx + Math.cos(a) * 0.55 * u, ey = sy - Math.sin(a) * 0.55 * u;
      const hx = sx + Math.cos(a) * 0.82 * u, hy = sy - Math.sin(a) * 0.82 * u;
      const rx = sx + Math.cos(a) * 1.0 * u, ry = sy - Math.sin(a) * 1.0 * u;
      ctx.strokeStyle = '#f0c9a4'; ctx.lineWidth = Math.max(3, u * 0.1);
      ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke();
      ctx.strokeStyle = '#d9d2c4'; ctx.lineWidth = Math.max(1.5, u * 0.04);
      ctx.beginPath(); ctx.moveTo(ex, ey); ctx.lineTo(hx, hy); ctx.stroke();
      ctx.save(); ctx.translate(rx, ry); ctx.rotate(-a);
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = Math.max(2, u * 0.05);
      ctx.beginPath(); ctx.ellipse(0, 0, u * 0.2, u * 0.14, 0, 0, Math.PI * 2); ctx.stroke();
      if (rkF[s] > 0) { ctx.fillStyle = 'rgba(255,246,210,' + (rkF[s] / 0.16 * 0.8) + ')'; ctx.beginPath(); ctx.ellipse(0, 0, u * 0.26, u * 0.2, 0, 0, Math.PI * 2); ctx.fill(); }
      ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(-u * 0.18, 0); ctx.lineTo(u * 0.18, 0); ctx.moveTo(0, -u * 0.12); ctx.lineTo(0, u * 0.12); ctx.stroke();
      ctx.restore();
      if (p.sw >= 0 && p.sw < 0.22) { // swing arc
        ctx.strokeStyle = 'rgba(255,240,200,' + (0.35 * (1 - p.sw / 0.22)) + ')'; ctx.lineWidth = Math.max(3, u * 0.12);
        ctx.beginPath(); ctx.arc(sx, sy, u * 1.0, -125 * Math.PI / 180, -ang * Math.PI / 180, false); ctx.stroke();
      }
      ctx.restore();
      // name tag
      const m = me();
      ctx.font = '700 11px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      const tag = s === m && !aiCtl(s) ? '나' : name(s);
      ctx.fillStyle = 'rgba(0,0,0,.45)'; const tw = ctx.measureText(tag).width + 10;
      rr(ctx, fx0 - tw / 2, fy0 - 2.2 * S - 16, tw, 15, 7); ctx.fill();
      ctx.fillStyle = col; ctx.fillText(tag, fx0, fy0 - 2.2 * S - 2);
    }
    function drawShuttle() {
      const b = W.b, c = toS(b.x, b.y), S = lay.s;
      // floor shadow
      const sh = toS(b.x, 0);
      ctx.fillStyle = 'rgba(0,0,0,' + (0.35 - Math.min(0.25, b.y * 0.04)) + ')';
      ctx.beginPath(); ctx.ellipse(sh.x, sh.y + 0.05 * S, 5, 2, 0, 0, Math.PI * 2); ctx.fill();
      // trail
      if (trail.length > 1) {
        const sp = Math.hypot(b.vx, b.vy);
        ctx.strokeStyle = sp > 14 ? 'rgba(255,214,120,.55)' : 'rgba(255,255,255,.22)'; ctx.lineWidth = sp > 14 ? 4 : 2; ctx.lineCap = 'round';
        ctx.beginPath(); trail.forEach((p, i) => { const q2 = toS(p.x, p.y); if (i) ctx.lineTo(q2.x, q2.y); else ctx.moveTo(q2.x, q2.y); }); ctx.lineTo(c.x, c.y); ctx.stroke();
      }
      if (smashT > 0 && trail.length > 2 && W.ph === 'fly') { // 잔상
        for (let i = 0; i < trail.length - 1; i += 2) { const q2 = toS(trail[i].x, trail[i].y); ctx.fillStyle = 'rgba(255,224,150,' + (0.12 + 0.4 * i / trail.length) * Math.min(1, smashT / 0.3) + ')'; ctx.beginPath(); ctx.arc(q2.x, q2.y, Math.max(4, S * 0.16), 0, Math.PI * 2); ctx.fill(); }
      }
      let vx = b.vx * (flip ? -1 : 1), vy = -b.vy;
      if (W.ph === 'wait') { vx = 0; vy = 1; }
      const a = Math.atan2(vy, vx);
      const L0 = Math.max(9, S * 0.3);
      ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(a);
      ctx.fillStyle = 'rgba(250,248,240,.95)'; ctx.strokeStyle = 'rgba(120,110,100,.7)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(0, -2.4); ctx.lineTo(-L0, -L0 * 0.45); ctx.lineTo(-L0, L0 * 0.45); ctx.lineTo(0, 2.4); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(140,130,120,.6)'; ctx.beginPath(); ctx.moveTo(-L0 * 0.5, -L0 * 0.25); ctx.lineTo(-L0 * 0.5, L0 * 0.25); ctx.stroke();
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(0.5, 0, 3.2, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
      // off the top of the screen: arrow marker
      if (c.y < 6) {
        ctx.fillStyle = '#ffd36a'; ctx.beginPath(); ctx.moveTo(c.x, 4); ctx.lineTo(c.x - 7, 16); ctx.lineTo(c.x + 7, 16); ctx.closePath(); ctx.fill();
      }
    }
    function drawFx() {
      for (const f of fx) {
        const k = f.t / f.T, c = toS(f.x, f.y);
        if (f.k === 'ring') {
          ctx.strokeStyle = hexA(f.col, k * 0.9); ctx.lineWidth = f.big ? 4 : 2.5;
          ctx.beginPath(); ctx.arc(c.x, c.y, (1 - k) * (f.big ? 40 : 22) + 4, 0, Math.PI * 2); ctx.stroke();
          if (f.big) for (let i = 0; i < 8; i++) {
            const an = i * Math.PI / 4 + 0.3, r0 = 10 + (1 - k) * 30, r1 = r0 + 14 * k;
            ctx.beginPath(); ctx.moveTo(c.x + Math.cos(an) * r0, c.y + Math.sin(an) * r0); ctx.lineTo(c.x + Math.cos(an) * r1, c.y + Math.sin(an) * r1); ctx.stroke();
          }
        } else if (f.k === 'txt') {
          ctx.globalAlpha = Math.min(1, k * 2);
          ctx.font = (f.big ? 26 : 16) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          const y = c.y - (1 - k) * 24, x = clamp(c.x, 50, cv.w - 50);
          ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.strokeText(f.s, x, Math.max(20, y)); ctx.fillStyle = f.col; ctx.fillText(f.s, x, Math.max(20, y));
          ctx.globalAlpha = 1;
        } else if (f.k === 'land') {
          ctx.globalAlpha = Math.min(1, k * 1.5);
          ctx.strokeStyle = f.ok ? '#8fe39a' : '#ff7a66'; ctx.lineWidth = 2.5;
          ctx.beginPath(); ctx.ellipse(c.x, c.y + 0.05 * lay.s, 10 + (1 - k) * 14, 4 + (1 - k) * 4, 0, 0, Math.PI * 2); ctx.stroke();
          ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
          ctx.fillStyle = f.ok ? '#8fe39a' : '#ff7a66'; ctx.fillText(f.ok ? '인' : '아웃', clamp(c.x, 20, cv.w - 20), c.y - 8);
          ctx.globalAlpha = 1;
        }
      }
    }
    function teamName(t) { return np() === 4 ? name(t) + '·' + name(t + 2) : name(t); }
    function drawHud() {
      if (!st) return;
      const w = cv.w, y0 = 6, bh = 54;
      const sides = flip ? [1, 0] : [0, 1];
      const bw = Math.min(140, (w - 100) / 2);
      sides.forEach((t, i) => {
        const x = i === 0 ? 8 : w - 8 - bw, col = P(t).color;
        ctx.fillStyle = 'rgba(34,28,46,.88)'; rr(ctx, x, y0, bw, bh, 12); ctx.fill();
        ctx.fillStyle = col; rr(ctx, x, y0, 6, bh, 3); ctx.fill();
        ctx.font = '600 11px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textBaseline = 'top'; ctx.textAlign = i === 0 ? 'left' : 'right';
        let nm = teamName(t); const tx = i === 0 ? x + 14 : x + bw - 10;
        while (ctx.measureText(nm).width > bw - 26 && nm.length > 2) nm = nm.slice(0, -2) + '…';
        ctx.fillStyle = '#ab9fb8'; ctx.fillText(nm, tx, y0 + 6);
        ctx.font = '700 28px "IBM Plex Mono", ui-monospace, monospace'; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(String(st.sc[t]), tx, y0 + 20);
        // serve marker
        if (st.st === t) { const mx = i === 0 ? x + bw - 18 : x + 18; drawMiniShuttle(mx, y0 + 34); }
        if (st.bo === 3) for (let k = 0; k < 2; k++) {
          const gx = i === 0 ? x + bw - 40 + k * 10 : x + 30 + k * 10;
          ctx.fillStyle = k < st.g[t] ? '#e3ae45' : 'rgba(242,233,216,.18)'; ctx.beginPath(); ctx.arc(gx, y0 + 12, 3.5, 0, Math.PI * 2); ctx.fill();
        }
      });
      // centre: mini court with the serve diagonal
      const mw = Math.min(70, w - 2 * bw - 30), mh = mw * 0.5, mx = w / 2 - mw / 2, my = y0 + 2;
      ctx.strokeStyle = 'rgba(242,233,216,.6)'; ctx.lineWidth = 1; ctx.fillStyle = 'rgba(28,102,80,.8)';
      ctx.fillRect(mx, my, mw, mh); ctx.strokeRect(mx + 0.5, my + 0.5, mw - 1, mh - 1);
      ctx.beginPath(); ctx.moveTo(mx + mw / 2, my); ctx.lineTo(mx + mw / 2, my + mh); ctx.moveTo(mx, my + mh / 2); ctx.lineTo(mx + mw * 0.36, my + mh / 2); ctx.moveTo(mx + mw * 0.64, my + mh / 2); ctx.lineTo(mx + mw, my + mh / 2); ctx.stroke();
      if (W) {
        const even = st.sc[st.st] % 2 === 0;
        // server's team on screen left or right; right court of a left-side team = bottom half
        const srvLeft = (st.st === 0) !== flip;
        const sq = (left, rightCourt) => ({ x: left ? mx + 1 : mx + mw * 0.64, y: (left === rightCourt) ? my + mh / 2 : my + 1, w: mw * 0.36 - 1, h: mh / 2 - 1 });
        const a = sq(srvLeft, even), b = sq(!srvLeft, even);
        ctx.fillStyle = hexA(P(st.st).color, 0.75); ctx.fillRect(a.x, a.y, a.w, a.h);
        ctx.fillStyle = hexA(P(1 - st.st).color, 0.45); ctx.fillRect(b.x, b.y, b.w, b.h);
        ctx.strokeStyle = '#ffd36a'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(a.x + a.w / 2, a.y + a.h / 2); ctx.lineTo(b.x + b.w / 2, b.y + b.h / 2); ctx.stroke();
      }
      ctx.font = '600 10px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = '#ab9fb8';
      ctx.fillText((st.bo === 3 ? st.gn + '게임 · ' : '') + st.to + '점', w / 2, my + mh + 3);
      // rally counter
      if (W && (W.ph === 'fly' || W.ph === 'dead') && W.rl > 1) {
        const k = 1 + rallyPop * 1.2, big = W.rl >= 10;
        ctx.save(); ctx.translate(w / 2, y0 + bh + 16); ctx.scale(k, k);
        ctx.font = '700 15px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = big ? '#ffd36a' : '#f2e9d8'; ctx.fillText('랠리 ' + W.rl + (big ? ' 🔥' : ''), 0, 0);
        ctx.restore();
      }
    }
    function drawMiniShuttle(x, y) {
      ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.moveTo(x - 6, y - 8); ctx.lineTo(x + 6, y - 8); ctx.lineTo(x + 2, y + 2); ctx.lineTo(x - 2, y + 2); ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(x, y + 4, 3.5, 0, Math.PI * 2); ctx.fill();
    }
    function centerText(lines) {
      const cy = toS(0, 4.4).y;
      for (const ln of lines) {
        ctx.font = ln.f; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 5; ctx.strokeStyle = 'rgba(10,8,14,.7)'; ctx.strokeText(ln.t, cv.w / 2, cy + ln.y);
        ctx.fillStyle = ln.c || '#f2e9d8'; ctx.fillText(ln.t, cv.w / 2, cy + ln.y);
      }
    }
    function predictLabel() {
      const s = meH(); if (s < 0 || !W) return '';
      const t = s % 2, p = W.pl[s];
      if (W.ph === 'wait') return W.srv === s ? (Math.sign(inDir()) * FW(t) > 0 ? '숏 서브' : '하이 서브') : '';
      if (!canHit(W, s)) return '';
      // height when the shuttle comes near me
      const b = Object.assign({}, W.b); let y = null, te = -1;
      for (let k = 0; k < 90; k++) { if (inReach(p, t, b)) { y = b.y; te = k / 60; break; } if (stepB(b, 1 / 60)) break; }
      if (y == null) return '';
      bS.classList.toggle('go', te <= 0.16);
      return SHOTS[shotType(y, Math.sign(inDir()) * FW(t))];
    }
    let labT = 0, labS = '';
    function draw(rdt) {
      if (!lay || !W) return;
      cv.clear();
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 8 * L.fx(), (Math.random() - 0.5) * shake * 8 * L.fx());
      ctx.drawImage(bg, 0, 0, cv.w, cv.h);
      const order = W.pl.map((_, i) => i).sort((a, b) => (b >= 2) - (a >= 2));
      for (const s of order) drawPlayer(s);
      drawShuttle();
      drawFx();
      ctx.restore();
      if (flash > 0) { ctx.fillStyle = 'rgba(255,240,200,' + flash * 0.6 * L.fx() + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      drawHud();
      const fz = Math.round(Math.min(48, cv.w * 0.12));
      if (phase === 'count' && st) {
        if (banner && cd > CD_NUM) {
          const t = banner.w, mine = me() >= 0 && me() % 2 === t;
          const lines = [{ t: banner.ng ? (st.ph === 'done' ? '' : (st.gn - 1) + '게임 끝!') : (mine ? '득점!' : teamName(t) + ' 득점'), f: fz * 0.7 + 'px "Black Han Sans", sans-serif', y: -fz * 0.3, c: P(t).color },
            { t: (WHY[banner.why] || '') + (banner.rl > 3 ? ' · 랠리 ' + banner.rl : ''), f: '600 14px "IBM Plex Sans KR", sans-serif', y: fz * 0.35 }];
          centerText(lines);
        } else {
          const sv = W.srv, mine = sv === meH();
          centerText([{ t: mine ? '내 서브' : name(sv) + ' 서브', f: fz * 0.6 + 'px "Black Han Sans", sans-serif', y: 0, c: P(sv).color }]);
        }
      }
      // hint
      const s = meH();
      if (s >= 0 && phase === 'play') {
        let t = null;
        if (W.ph === 'wait' && W.srv === s) t = '스윙 = 하이 서브 · ▶+스윙 = 숏 서브';
        else if (W.ph === 'wait' && W.rcv === s) t = '받을 차례! 셔틀이 오면 스윙';
        else if (hintT > 0 && W.ph === 'fly') t = '셔틀이 닿기 직전에 스윙 · 높을 때 ▶+스윙 = 스매시';
        if (t) {
          ctx.font = '600 12px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          const tw = Math.min(cv.w - 16, ctx.measureText(t).width + 20), y = lay.top + 44;
          ctx.fillStyle = 'rgba(0,0,0,.5)'; rr(ctx, cv.w / 2 - tw / 2, y - 11, tw, 22, 11); ctx.fill();
          ctx.fillStyle = '#f2e9d8'; ctx.fillText(t, cv.w / 2, y);
        }
      }
      // swing button label (shot preview)
      labT -= rdt;
      if (labT <= 0) { labT = 0.08; const l = predictLabel(); if (!l) bS.classList.remove('go'); if (l !== labS) { labS = l; swLab.textContent = l; } }
    }

    const stopLoop = U.loop((rdt, now) => {
      const n = Math.min(12, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); } catch (e) { console.error(e); }
      try { draw(rdt); } catch (e) { console.error(e); }
    });
    cv.onresize = layout;
    layout();

    return {
      update(next) {
        if (!next) return;
        st = next;
        const f = myTeam() === 1;
        if (f !== flip) layout(); else placeButtons();
        const k = curKey();
        if (k !== key) { key = k; startPoint(next); }
        if (next.ph === 'done') { phase = 'done'; if (W) W.ph = 'dead'; }
      },
      destroy() {
        stopLoop();
        if (offIn) offIn();
        pad.remove(); css.remove();
        cv.destroy();
      },
      _dbg: () => ({ W, phase, st, flip, lay }),
    };
  }

  function rr(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, r); else c.rect(x, y, w, h); }
  function hexA(hex, a) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return 'rgba(220,220,220,' + a + ')';
    const n = parseInt(m[1], 16);
    return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  L.register({
    id: 'badminton', name: '배드민턴', tag: '실시간 대결', cat: '스포츠',
    blurb: '옆에서 보는 배드민턴! 셔틀이 오는 순간에 맞춰 스윙하고, 높이와 방향으로 클리어·드롭·스매시를 골라요. 단식·복식, 21점 랠리 점수제.',
    tint: '#2a5f4a',
    icon: '<path d="M14 44L30 28" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><ellipse cx="36" cy="20" rx="10" ry="13" transform="rotate(45 36 20)" fill="none" stroke="currentColor" stroke-width="3"/><path d="M30 14l12 12M33 11l9 9M28 18l10 10" stroke="currentColor" stroke-width="1.5" opacity=".7"/><path d="M12 12l8 2-2 8z" fill="currentColor"/><circle cx="11" cy="11" r="3" fill="currentColor"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    maxPlayersIf: (o) => (o && o.fmt === 'd' ? 4 : 2),
    options: [
      { id: 'fmt', label: '경기', tip: '혼자 치기 또는 2:2 팀.', choices: [{ v: 's', label: '단식', tip: '1:1 (2명).' }, { v: 'd', label: '복식 2:2', tip: '2:2 복식 (4자리, 빈자리는 AI).' }], def: 's' },
      { id: 'to', label: '점수', choices: [{ v: 11, label: '11점' }, { v: 21, label: '21점' }], def: 21 },
      { id: 'bo', label: '게임 수', tip: '몇 게임을 할지.', choices: [{ v: 1, label: '1게임' }, { v: 3, label: '3게임 중 2승' }], def: 1 },
    ],
    controls: [
      { id: 'left', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'jump', label: '점프', keys: ['ArrowUp', 'KeyW'], pad: ['b', 'up'] },
      { id: 'swing', label: '스윙 (서브)', keys: ['Space', 'KeyJ'], pad: ['a', 'rt'] },
    ],
    quick: [
      '셔틀콕을 쳐서 네트 너머 상대 코트 바닥에 떨어뜨리면 1점이에요.',
      '◀ ▶로 움직이고, 셔틀이 라켓에 닿기 직전에 「스윙」! ▶(네트 쪽)를 누르며 치면 스매시·헤어핀.',
      '21점(또는 11점)을 먼저 따면 이겨요. 20:20부터는 2점 차, 30점이면 바로 승리.',
    ],
    rules: [
      { h: '목표', p: [
        '옆에서 보는 배드민턴이에요. 내 편은 항상 화면 왼쪽, 상대는 오른쪽이에요.',
        '셔틀콕(깃털 공)을 쳐서 네트를 넘기고, 상대 코트 바닥에 떨어뜨리면 내 점수예요.',
        '셔틀은 처음엔 아주 빠르지만 금방 느려지고 뚝 떨어져요. 떨어질 곳을 미리 보고 움직여요.',
      ] },
      { h: '조작', p: [
        '◀ ▶: 움직이기. 점프: 높은 셔틀을 칠 때(점프해서 치는 스매시는 더 빨라요).',
        '스윙: 셔틀이 라켓에 닿기 직전에 눌러요. 딱 맞으면 「나이스!」, 너무 늦거나 이르면 「빗맞음」이 나고 엉뚱하게 날아가요.',
        '스윙 버튼 아래에 지금 치면 나갈 기술이 미리 보여요. 버튼이 빛나면 지금이 칠 때예요.',
        'PC: ←→(A·D) 움직이기, ↑(W) 점프, 스페이스(J) 스윙. 게임패드는 왼스틱·Ⓐ·Ⓑ. 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '기술 고르기', p: [
        '머리 위 높은 셔틀: 그냥 스윙 = 클리어(높고 깊게) · ▶(네트 쪽)+스윙 = 스매시(아주 빠르게 내리꽂기) · ◀+스윙 = 드롭(네트 앞에 살짝).',
        '가슴 높이: 그냥 = 클리어 · ▶ = 드라이브(낮고 빠르게) · ◀ = 드롭.',
        '낮은 셔틀: 그냥이나 ◀ = 리프트(높이 띄워 뒤로) · ▶ = 헤어핀(네트 바로 너머로 톡).',
      ] },
      { h: '서브', p: [
        '서브는 허리 아래에서 올려 쳐요. 그냥 스윙 = 하이 서브(높고 깊게), ▶+스윙 = 숏 서브(네트 앞 짧게).',
        '서브는 대각선 쪽 상대 서비스 구역에 떨어져야 해요: 네트에서 1.98m 앞 선보다 멀고, 단식은 끝선, 복식은 뒤쪽 서비스 선(끝선 0.76m 안쪽)보다 가까이.',
        '내 점수가 짝수면 오른쪽, 홀수면 왼쪽 코트에서 서브해요. 위쪽 작은 코트 그림이 서브 방향을 보여 줘요.',
        '서브는 정해진 받는 사람만 받을 수 있어요.',
      ] },
      { h: '점수 · 승리', p: [
        '랠리 점수제: 누가 서브했든 랠리를 이긴 쪽이 1점을 얻고 다음 서브를 해요.',
        '이럴 때 상대 점수: 셔틀이 네트에 걸림 · 내 코트에 떨어짐 · 코트 끝선 밖으로 나감 · 서브가 서비스 구역 밖 · 내 코트에 떨어질 때까지 못 받음.',
        '21점 경기: 21점 먼저. 20:20이면 2점 차가 날 때까지, 단 30점에 먼저 닿으면 바로 승리. (11점 경기는 10:10부터 2점 차, 15점이면 승리.)',
        '「3게임 중 2승」이면 두 게임을 먼저 이긴 쪽이 승리. 게임을 이긴 쪽이 다음 게임 첫 서브를 해요.',
        '한 편이 연달아 두 번 칠 수는 없어요(복식에서 짝과 번갈아 쳐도 안 돼요).',
      ] },
      { h: '복식', p: [
        '2:2로 해요. 서브한 편이 이기면 같은 사람이 코트를 바꿔 계속 서브, 받는 편이 이기면 그 편이 서브를 가져가요.',
        '서브는 대각선 상대 서비스 구역으로: 복식은 네트 쪽 선(1.98m)보다 멀고 뒤쪽 복식 서비스 선(끝선 0.76m 안쪽)보다 가까이. 랠리 중에는 끝선까지 모두 인이에요.',
        '서브하는 편의 점수가 짝수면 오른쪽, 홀수면 왼쪽 코트 사람이 서브하고, 대각선에 선 사람만 받을 수 있어요. 받는 편은 득점해도 자리를 바꾸지 않아요.',
        '서브 다음부터 셔틀은 편 안에서 누구나 받을 수 있어요. AI 짝은 공격할 땐 앞·뒤로, 수비할 땐 좌·우로 나란히 서고 서로 부딪히지 않게 비켜요.',
        '친구와 하려면 온라인·LAN 방에서 4명(빈자리는 AI)으로, 한 폰에 한 명씩.',
      ] },
      { h: '예시', p: [
        '상대가 높게 올려 준 셔틀이 머리 위로 내려와요 → 점프하면서 ▶를 누른 채 스윙 → 「스매시!」 → 상대가 못 받아 바닥에 떨어지면 내 점수.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지는 AI예요. 친구와는 온라인·LAN 방에서 각자 자기 폰으로 해요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요(발 빠르기, 반응, 스윙 타이밍, 스매시·점프 여부가 달라요).',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { point, receiver, init, newWorld, simulate, aiThink, serve, startSwing, makeShot, shotType, stepB, judge, DIFF, SI },
  });
})();
