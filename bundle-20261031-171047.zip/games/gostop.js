/* 고스톱 — 2인 맞고(7점) / 3인 고스톱(3점). 화투 48장(+보너스 피), 그림은 모두 캔버스로 직접 그림.
   흔들기·폭탄·총통·뻑·자뻑·따닥·쪽·쓸, 피 뺏기, 고(1고 +1, 2고 +2, 3고부터 ×2…), 피박·광박·고박(·멍박 옵션),
   나가리 → 다음 판 ×2, 1/3/5판 누적 점수. 패는 api.viewer()만 앞면. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- cards: one char each. i = month*4 + k (0..47), 48/49 보너스 쌍피, 50 보너스 쓰리피 ---------- */
  const ALPH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const ci = (ch) => ALPH.indexOf(ch);
  const cc = (i) => ALPH[i];
  const MN = ['송학', '매조', '벚꽃', '흑싸리', '난초', '모란', '홍싸리', '공산', '국진', '단풍', '오동', '비'];
  // type per card: 0 광, 1 열끗, 2 띠, 3 피
  const KT = [[0, 2, 3, 3], [1, 2, 3, 3], [0, 2, 3, 3], [1, 2, 3, 3], [1, 2, 3, 3], [1, 2, 3, 3], [1, 2, 3, 3], [0, 1, 3, 3], [1, 2, 3, 3], [1, 2, 3, 3], [0, 3, 3, 3], [0, 1, 2, 3]];
  const GUK = 32, RAIN = 44;
  const BIRDS = [4, 12, 29];
  const DAN = { h: [1, 5, 9], c: [21, 33, 37], o: [13, 17, 25] }; // 홍단 · 청단 · 초단
  const monthOf = (i) => (i >= 48 ? -1 : i >> 2);
  const typeOf = (i) => (i >= 48 ? 3 : KT[i >> 2][i & 3]);
  const piVal = (i) => (i === 50 ? 3 : i >= 48 ? 2 : i === 41 || i === 47 ? 2 : typeOf(i) === 3 ? 1 : 0);
  const TYN = ['광', '열끗', '띠', '피'];
  function cardName(i) {
    if (i >= 48) return i === 50 ? '보너스 쓰리피' : '보너스 쌍피';
    const m = monthOf(i), t = typeOf(i);
    let nm = (m + 1) + '월 ' + MN[m] + ' ';
    if (i === RAIN) return nm + '비광';
    if (i === GUK) return nm + '열끗(국진)';
    if (BIRDS.includes(i)) return nm + '열끗(고도리)';
    if (t === 2) return nm + (DAN.h.includes(i) ? '홍단' : DAN.c.includes(i) ? '청단' : DAN.o.includes(i) ? '초단' : '띠');
    if (t === 3 && piVal(i) === 2) return nm + '쌍피';
    return nm + TYN[t];
  }
  /* two cards are interchangeable when both are plain 피 of the same value */
  const same = (a, b) => typeOf(a) === 3 && typeOf(b) === 3 && a !== GUK && b !== GUK && piVal(a) === piVal(b);

  /* ---------- scoring ---------- */
  function tally(cards, gukPi) {
    const t = { g: 0, rain: 0, y: 0, b: 0, t: 0, h: 0, c: 0, o: 0, p: 0, n: cards.length };
    for (const i of cards) {
      if (i >= 48) { t.p += piVal(i); continue; }
      if (i === GUK && gukPi) { t.p += 2; continue; }
      const ty = typeOf(i);
      if (ty === 0) { t.g++; if (i === RAIN) t.rain = 1; }
      else if (ty === 1) { t.y++; if (BIRDS.includes(i)) t.b++; }
      else if (ty === 2) { t.t++; if (DAN.h.includes(i)) t.h++; else if (DAN.c.includes(i)) t.c++; else if (DAN.o.includes(i)) t.o++; }
      else t.p += piVal(i);
    }
    t.gw = t.g === 5 ? 15 : t.g === 4 ? 4 : t.g === 3 ? (t.rain ? 2 : 3) : 0;
    t.ys = t.y >= 5 ? t.y - 4 : 0;
    t.gd = t.b === 3 ? 5 : 0;
    t.ts = t.t >= 5 ? t.t - 4 : 0;
    t.dh = t.h === 3 ? 3 : 0; t.dc = t.c === 3 ? 3 : 0; t.do = t.o === 3 ? 3 : 0;
    t.ps = t.p >= 10 ? t.p - 9 : 0;
    t.tot = t.gw + t.ys + t.gd + t.ts + t.dh + t.dc + t.do + t.ps;
    t.gp = gukPi ? 1 : 0;
    return t;
  }
  const pileArr = (str) => str.split('').map(ci);
  /* 국진 option: 'a' auto (whichever scores more), 'y' always 열끗, 'p' always 쌍피 */
  function tallyBest(cards, gk) {
    if (!cards.includes(GUK) || gk === 'y') return tally(cards, 0);
    if (gk === 'p') return tally(cards, 1);
    const a = tally(cards, 0), b = tally(cards, 1);
    return b.tot > a.tot ? b : a;
  }
  /* 피 count for 피박: 국진 counts as 쌍피 for the holder unless the option fixes it as 열끗 */
  function piForBak(cards, gk) { return tally(cards, cards.includes(GUK) && gk !== 'y' ? 1 : 0).p; }
  const score = (s, seat) => tallyBest(pileArr(s.c[seat]), s.o.gk);
  const thr = (s) => (s.n === 2 ? 7 : 3);

  /* ---------- state ----------
     n, nm, ai, o:{bn, gk, mb, g}, gi (game no.), sc (match totals), mul (나가리 multiplier for this game), dl (선),
     h hands, f floor, d deck, c captured piles, t turn, ph: 'p' play | 'f' choose floor card for the flip | 'g' 고/스톱
     | 'r' round over | 'x' match over, go 고 count, gs score at last 고, sh 흔들기/폭탄 count, pk 뻑 count,
     bt 폭탄패(flip-only turns), bb 12 chars: 뻑 owner per month ('-' none), tk taken this turn (pending), sn steals owed,
     fp flipped card waiting for a choice, rr round result, last event, seq */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const o = { bn: opts.bonus === 0 ? 0 : opts.bonus === 3 ? 3 : 2, gk: opts.guk === 'y' ? 'y' : opts.guk === 'p' ? 'p' : 'a', mb: opts.meong === 'on' ? 1 : 0, g: opts.games === 1 ? 1 : opts.games === 5 ? 5 : 3 };
    const s = {
      n, nm: players.map((p) => String(p.name || '').slice(0, 12)), ai: players.map((p) => (p.ai ? 1 : 0)), o,
      gi: 1, dn: 0, sc: players.map(() => 0), mul: 1, dl: U.rand(n), seq: 0, rr: null,
    };
    deal(s);
    return s;
  }
  function deal(s) {
    const n = s.n, hs = n === 2 ? 10 : 7, fl = n === 2 ? 8 : 6;
    let tries = 0;
    for (;;) {
      const all = [];
      for (let i = 0; i < 48; i++) all.push(i);
      if (s.o.bn >= 2) all.push(48, 50);
      if (s.o.bn >= 3) all.push(49);
      let dk = U.shuffle(all).map(cc).join('');
      s.c = []; s.h = [];
      for (let k = 0; k < n; k++) { s.h.push(dk.slice(0, hs)); dk = dk.slice(hs); s.c.push(''); }
      let f = '';
      while (f.length < fl) {
        const ch = dk[0]; dk = dk.slice(1);
        if (ci(ch) >= 48) s.c[s.dl] += ch; // 바닥에 깔린 보너스 피는 선이 가져가고 한 장 더 깔아요
        else f += ch;
      }
      const cnt = new Array(12).fill(0);
      for (const ch of f) cnt[monthOf(ci(ch))]++;
      if (cnt.some((x) => x === 4) && tries++ < 50) continue; // 바닥에 같은 달 4장 → 다시 섞기
      s.f = f; s.d = dk;
      break;
    }
    s.t = s.dl; s.ph = 'p'; s.dn++;
    s.go = s.h.map(() => 0); s.gs = s.h.map(() => 0); s.sh = s.h.map(() => 0); s.pk = s.h.map(() => 0); s.bt = s.h.map(() => 0);
    s.bb = '------------'; s.tk = ''; s.sn = 0; s.fp = '';
    s.seq++;
    s.last = { id: s.seq, k: 'deal', s: s.dl };
    // 총통: 처음 받은 패에 같은 달 4장 → 바로 승리
    for (let k = 0; k < s.n; k++) {
      const seat = (s.dl + k) % s.n;
      const cnt = new Array(12).fill(0);
      for (const ch of s.h[seat]) { const m = monthOf(ci(ch)); if (m >= 0) cnt[m]++; }
      const m = cnt.indexOf(4);
      if (m >= 0) { s.last.ev = 'C'; s.last.cm = m; endRound(s, seat, 'c'); return; }
    }
  }

  const floorOf = (s, m) => s.f.split('').filter((ch) => monthOf(ci(ch)) === m);
  const handOf = (s, seat, m) => s.h[seat].split('').filter((ch) => monthOf(ci(ch)) === m);
  const rm = (str, ch) => str.replace(ch, '');
  const canMove = (s, seat) => s.h[seat].length > 0 || (s.bt[seat] > 0 && s.d.length > 0);
  const setBB = (s, m, v) => { s.bb = s.bb.slice(0, m) + v + s.bb.slice(m + 1); };

  // 상황 도움말(라운드 35)
  function hint(s, seat) {
    if (s.ph === 'r') return ['한 판이 끝났어요. 「다음 판」을 누르면 새로 패를 돌려요.'];
    const out = [];
    const me = seat >= 0 && seat < s.n ? seat : s.t;
    const mine = score(s, me), need = thr(s);
    if (s.t !== seat) out.push((s.nm[s.t] || '상대') + ' 차례예요. 내 점수 ' + mine.tot + '점 / 나기 ' + need + '점.');
    else if (s.ph === 'g') {
      out.push('나기 점수(' + need + '점)를 넘었어요! 지금 ' + mine.tot + '점 — 고 할지 스톱 할지 골라요.');
      out.push('스톱: 여기서 끝내고 지금 점수로 돈을 받아요.');
      out.push('고: 계속해요. 1고 +1점, 2고 +2점, 3고부터는 점수 두 배씩 — 하지만 상대가 먼저 나면 내가 「고박」으로 몽땅 물어요.');
      if (s.go[seat]) out.push('지금까지 ' + s.go[seat] + '고 했어요.');
    } else if (s.ph === 'f') {
      out.push('뒤집은 패와 같은 달이 바닥에 2장 — 그중 가져올 1장을 골라요(광·열끗·띠·쌍피가 보통 더 좋아요).');
    } else {
      const hand = s.h[seat].split('').map(ci);
      const fm = new Set(s.f.split('').map((c) => monthOf(ci(c))));
      const hit = [], miss = [];
      const months = [...new Set(hand.filter((i) => i < 48).map(monthOf))];
      for (const m of months) (fm.has(m) ? hit : miss).push((m + 1) + '월');
      if (hit.length) out.push('바닥과 짝이 맞는 패: ' + hit.join(', ') + ' — 내면 같은 달 패를 가져와요.');
      else out.push('바닥과 맞는 달이 없어요. 아무거나 내면 바닥에 깔려요(상대가 노리기 어려운 패부터).');
      if (hand.some((i) => i >= 48)) out.push('보너스 피는 내면 바로 내 것이 되고 한 장 더 뒤집어요.');
      if (s.bt[seat] > 0) out.push('폭탄으로 받은 차례 ' + s.bt[seat] + '번 — 패 없이 더미만 뒤집을 수 있어요.');
      out.push('내 점수 ' + mine.tot + '점 / 나기 ' + need + '점. 낸 뒤 더미에서 1장을 뒤집어 한 번 더 맞춰요.');
    }
    return out;
  }
  function actor(s) {
    if (s.ph === 'x') return null;
    if (s.ph === 'r') { const a = []; for (let i = 0; i < s.n; i++) a.push(i); return a; }
    return s.t;
  }

  /* 3 floor cards of a month captured: if it was someone's 뻑, take 피 (자뻑 = own 뻑 → 2장씩) */
  function ppukTake(s, seat, m, ev) {
    const o = s.bb[m];
    if (o === '-') return ev;
    setBB(s, m, '-');
    if (+o === seat) { s.sn += 2; return ev + 'Z'; }
    s.sn += 1; return ev + 'E';
  }

  /* one full turn: play (or bomb / flip-only), then flip. Returns after finish or when a choice is needed (ph 'f'). */
  function turn(s, seat, a, sim) {
    s.tk = ''; s.sn = 0; s.fp = '';
    const last = { id: ++s.seq, k: 'p', s: seat, c: '', fl: '', cap: '', ev: '', st: '' };
    s.last = last;
    let m = -1, mode = '', hold = '', played = '';
    if (a.t === 'pass') {
      if (!(s.bt[seat] > 0) || !s.d.length) throw new Error('no flip-only turn');
      s.bt[seat]--; last.k = 'x';
    } else if (a.t === 'bomb') {
      m = a.m | 0;
      const hc = handOf(s, seat, m), F = floorOf(s, m);
      if (m < 0 || m > 11 || hc.length !== 3 || F.length !== 1) throw new Error('no bomb');
      for (const ch of hc) s.h[seat] = rm(s.h[seat], ch);
      s.f = rm(s.f, F[0]);
      s.tk += hc.join('') + F[0];
      s.sh[seat]++; s.bt[seat] += 2; s.sn++;
      last.c = hc.join(''); last.k = 'b'; last.ev += 'B'; mode = 'cap';
    } else if (a.t === 'play') {
      const ch = String(a.c || '');
      const i = ci(ch);
      if (ch.length !== 1 || i < 0 || s.h[seat].indexOf(ch) < 0) throw new Error('no such card');
      if (i >= 48) { // 보너스 피: 바로 가져오고 더미에서 1장 받아 계속
        s.h[seat] = rm(s.h[seat], ch);
        s.c[seat] += ch;
        last.k = 'n'; last.c = ch; last.cap = ch; last.ev = 'N';
        if (s.d.length) { s.h[seat] += s.d[0]; s.d = s.d.slice(1); last.dr = 1; }
        if (!sim && !canMove(s, seat)) afterTurn(s, seat);
        return;
      }
      m = monthOf(i); played = ch;
      const F = floorOf(s, m);
      if (a.sh) {
        if (handOf(s, seat, m).length !== 3 || F.length !== 0) throw new Error('cannot shake');
        s.sh[seat]++; last.ev += 'H'; last.shm = m;
      }
      s.h[seat] = rm(s.h[seat], ch);
      last.c = ch;
      if (F.length === 0) { s.f += ch; mode = 'laid'; }
      else if (F.length === 1) { s.f = rm(s.f, F[0]); hold = ch + F[0]; mode = 'pair'; }
      else if (F.length === 2) {
        let p = a.p;
        if (!p || F.indexOf(p) < 0) {
          if (same(ci(F[0]), ci(F[1]))) p = F[0];
          else throw new Error('choose a floor card');
        }
        s.f = rm(s.f, p); hold = ch + p; mode = 'pair2';
      } else {
        for (const x of F) s.f = rm(s.f, x);
        s.tk += ch + F.join(''); mode = 'cap';
        last.ev = ppukTake(s, seat, m, last.ev);
      }
    } else throw new Error('bad action');

    // flip the deck top (보너스 피는 바로 가져오고 한 장 더 뒤집어요)
    let d = '';
    while (s.d.length) {
      const ch = s.d[0]; s.d = s.d.slice(1); last.fl += ch;
      if (ci(ch) >= 48) { s.tk += ch; last.ev += 'N'; continue; }
      d = ch; break;
    }
    if (d && monthOf(ci(d)) === m && mode !== 'cap') {
      if (mode === 'laid') { s.f = rm(s.f, played); s.tk += played + d; s.sn++; last.ev += 'J'; } // 쪽
      else if (mode === 'pair') { s.f += hold + d; hold = ''; setBB(s, m, String(seat)); s.pk[seat]++; last.ev += 'P'; last.pm = m; } // 뻑
      else { const other = floorOf(s, m)[0]; s.f = rm(s.f, other); s.tk += hold + other + d; hold = ''; s.sn++; last.ev += 'T'; } // 따닥
    } else {
      s.tk += hold; hold = '';
      if (d) {
        const dm = monthOf(ci(d)), Fd = floorOf(s, dm);
        if (Fd.length === 0) s.f += d;
        else if (Fd.length === 1) { s.f = rm(s.f, Fd[0]); s.tk += d + Fd[0]; }
        else if (Fd.length === 2) {
          if (same(ci(Fd[0]), ci(Fd[1])) || sim) {
            const p = sim ? bestOf(Fd) : Fd[0];
            s.f = rm(s.f, p); s.tk += d + p;
          } else { s.fp = d; s.ph = 'f'; return; }
        } else { for (const x of Fd) s.f = rm(s.f, x); s.tk += d + Fd.join(''); last.ev = ppukTake(s, seat, dm, last.ev); }
      }
    }
    finish(s, seat, last, sim);
  }
  function pick(s, seat, p) {
    if (!s.fp) throw new Error('nothing to pick');
    const dm = monthOf(ci(s.fp)), Fd = floorOf(s, dm);
    if (Fd.indexOf(p) < 0) throw new Error('pick a matching card');
    const last = { id: ++s.seq, k: 'k', s: seat, c: '', fl: '', cap: '', ev: '', st: '' };
    s.last = last;
    s.f = rm(s.f, p); s.tk += s.fp + p; s.fp = ''; s.ph = 'p';
    finish(s, seat, last, false);
  }
  /* steal the cheapest 피 (never 국진) */
  function stealPick(pile) {
    let best = '', bv = 9;
    for (const ch of pile) {
      const i = ci(ch);
      if (i === GUK || typeOf(i) !== 3) continue;
      const v = piVal(i) + (i >= 48 ? 0.5 : 0);
      if (v < bv) { bv = v; best = ch; }
    }
    return best;
  }
  function finish(s, seat, last, sim) {
    const got = s.tk;
    s.c[seat] += got; last.cap += got; s.tk = '';
    const handsLeft = s.h.reduce((a, h) => a + h.length, 0);
    if (got.length >= 2 && !s.f.length && (handsLeft > 0 || s.d.length > 0)) { s.sn++; last.ev += 'S'; } // 쓸 (막판 쓸은 제외)
    if (s.sn) {
      for (let o = 0; o < s.n; o++) {
        if (o === seat) continue;
        for (let k = 0; k < s.sn; k++) {
          const ch = stealPick(s.c[o]);
          if (!ch) break;
          s.c[o] = rm(s.c[o], ch); s.c[seat] += ch; last.st += o + ch;
        }
      }
      s.sn = 0;
    }
    if (sim) return;
    afterTurn(s, seat);
  }
  function afterTurn(s, seat) {
    if (s.pk[seat] >= 3 && s.last.ev && s.last.ev.indexOf('P') >= 0) { s.last.ev += '3'; endRound(s, seat, '3'); return; } // 3뻑
    const b = score(s, seat).tot;
    if (b >= thr(s) && b > s.gs[seat]) {
      if (!canMove(s, seat)) { s.last.auto = 1; endRound(s, seat, 's'); return; } // 마지막 패: 자동 스톱
      s.ph = 'g'; s.t = seat; return;
    }
    nextTurn(s, seat);
  }
  function nextTurn(s, seat) {
    for (let k = 1; k <= s.n; k++) {
      const j = (seat + k) % s.n;
      if (canMove(s, j)) { s.t = j; s.ph = 'p'; return; }
    }
    endRound(s, -1, 'n'); // 나가리
  }

  /* settle a round. kind: 's' stop, 'c' 총통, '3' 3뻑, 'n' 나가리 */
  function settle(s, w, kind) {
    const r = { k: kind, w, pay: s.h.map(() => 0), fx: s.h.map(() => ''), mul: s.mul };
    if (kind === 'n') return r;
    const gk = s.o.gk;
    let pts;
    if (kind === 's') {
      const tw = score(s, w);
      r.b = tw.tot; r.go = s.go[w];
      pts = (tw.tot + s.go[w]) * (s.go[w] >= 3 ? Math.pow(2, s.go[w] - 2) : 1);
      r.pts = pts;
      const base = s.mul * Math.pow(2, s.sh[w]) * (s.o.mb && tw.y >= 7 ? 2 : 1);
      for (let l = 0; l < s.n; l++) {
        if (l === w) continue;
        const cl = pileArr(s.c[l]), tl = tally(cl, 0);
        let m = base, fx = '';
        if (tw.ps > 0 && piForBak(cl, gk) <= 5) { m *= 2; fx += 'p'; }
        if (tw.gw > 0 && tl.g === 0) { m *= 2; fx += 'g'; }
        if (s.n === 2 && s.go[l] > 0) { m *= 2; fx += 'o'; }
        r.fx[l] = fx; r.pay[l] = pts * m;
      }
      if (s.o.mb && tw.y >= 7) r.mb = 1;
      if (s.n === 3) { // 3인 고박: 고를 했던 패자가 다른 패자 몫까지 모두 내요(독박)
        const gl = [];
        for (let l = 0; l < 3; l++) if (l !== w && s.go[l] > 0) gl.push(l);
        if (gl.length === 1) {
          const l = gl[0];
          let tot = 0;
          for (let x = 0; x < 3; x++) if (x !== w) { tot += r.pay[x]; if (x !== l) r.pay[x] = 0; }
          r.pay[l] = tot; r.fx[l] += 'o'; r.dok = l;
        }
      }
    } else {
      pts = 10; r.pts = 10; r.b = 10;
      for (let l = 0; l < s.n; l++) if (l !== w) r.pay[l] = 10 * s.mul;
    }
    r.sh = s.sh[w];
    return r;
  }
  function endRound(s, w, kind) {
    const r = settle(s, w, kind);
    if (kind === 'n') { s.mul *= 2; r.next = s.mul; }
    else {
      let tot = 0;
      for (let l = 0; l < s.n; l++) if (l !== w) { s.sc[l] -= r.pay[l]; tot += r.pay[l]; }
      s.sc[w] += tot; r.tot = tot;
      s.mul = 1; s.dl = w;
      // per-seat result stats: [rounds won, best single-round gain, times hit by 박]
      if (!s.ks) s.ks = s.sc.map(() => [0, 0, 0]);
      s.ks[w][0]++; s.ks[w][1] = Math.max(s.ks[w][1], tot);
      for (let l = 0; l < s.n; l++) if (l !== w && r.fx && r.fx[l]) s.ks[l][2]++;
    }
    s.rr = r;
    s.ph = kind === 'n' ? (s.dn >= s.o.g + 4 ? 'x' : 'r') : s.gi >= s.o.g ? 'x' : 'r';
    s.t = s.dl;
  }

  function apply(s, seat, a) {
    if (!a || typeof a.t !== 'string') throw new Error('bad action');
    if (s.ph === 'x') throw new Error('game over');
    if (s.ph === 'r') {
      if (a.t !== 'next') throw new Error('round over');
      if (s.rr && s.rr.k !== 'n') s.gi++;
      s.rr = null;
      deal(s);
      return s;
    }
    if (seat !== s.t) throw new Error('not your turn');
    if (s.ph === 'g') {
      if (a.t === 'go') {
        s.go[seat]++; s.gs[seat] = score(s, seat).tot;
        s.last = { id: ++s.seq, k: 'g', s: seat, n: s.go[seat] };
        nextTurn(s, seat);
        return s;
      }
      if (a.t === 'stop') { s.last = { id: ++s.seq, k: 's', s: seat }; endRound(s, seat, 's'); return s; }
      throw new Error('go or stop');
    }
    if (s.ph === 'f') { if (a.t !== 'pick') throw new Error('pick'); pick(s, seat, String(a.p || '')); return s; }
    turn(s, seat, a, false);
    return s;
  }

  function result(s) {
    if (s.ph !== 'x') return null;
    let best = -1e9;
    for (const v of s.sc) best = Math.max(best, v);
    const winners = [];
    s.sc.forEach((v, i) => { if (v === best) winners.push(i); });
    const lines = [];
    const r = s.rr;
    if (r) lines.push(roundLine(s, r));
    lines.push((s.o.g > 1 ? s.o.g + '판 합계: ' : '점수: ') + s.sc.map((v, i) => s.nm[i] + ' ' + (v > 0 ? '+' : '') + v).join(' · '));
    const ks = s.ks || s.sc.map(() => [0, 0, 0]);
    const stats = [{ label: '이긴 판', values: ks.map((k) => String(k[0])) }, { label: '한 판 최고 득점', values: ks.map((k) => String(k[1])) },
      { label: '박 당함', values: ks.map((k) => String(k[2])) }, { label: '합계', values: s.sc.map((v) => (v > 0 ? '+' : '') + v) }];
    return { winners: winners.length === s.n ? [] : winners, stats, title: winners.length === s.n ? '무승부' : undefined, text: lines.join('\n') };
  }
  function roundLine(s, r) {
    if (r.k === 'n') return '마지막 판은 나가리였어요.';
    const nm = s.nm[r.w];
    if (r.k === 'c') return nm + ' 총통! 10점';
    if (r.k === '3') return nm + ' 3뻑! 10점';
    return nm + ' ' + r.b + '점' + (r.go ? ' · ' + r.go + '고' : '') + ' 스톱 → ' + r.tot + '점';
  }

  /* ---------- AI ---------- */
  function bestOf(F) { // most valuable floor card of a pair choice (no context)
    let b = F[0], bv = -1;
    for (const ch of F) { const v = worth0(ci(ch)); if (v > bv) { bv = v; b = ch; } }
    return b;
  }
  function worth0(i) {
    if (i >= 48) return piVal(i) * 1.2;
    const t = typeOf(i);
    if (t === 0) return i === RAIN ? 4 : 6;
    if (t === 1) return BIRDS.includes(i) ? 5 : i === GUK ? 4 : 3;
    if (t === 2) return i === 46 ? 2 : 3.2;
    return piVal(i) * 1.2;
  }
  const SETS = [DAN.h, DAN.c, DAN.o, BIRDS];
  const GWANGS = [0, 8, 28, 40, 44];
  /* heuristic value of a captured pile; dead = Set of cards owned by others (combo parts no longer reachable) */
  function pileValue(cards, dead, gk) {
    const t = tallyBest(cards, gk);
    let v = 10 * t.tot + 0.9 * t.p + 1.5 * t.t + 1.5 * t.y + 3.6 * t.g;
    const has = new Set(cards);
    SETS.forEach((set, k) => {
      let h = 0, open = 0;
      for (const x of set) { if (has.has(x)) h++; else if (!dead.has(x)) open++; }
      if (h === 2 && open) v += k === 3 ? 13 : 8;
      else if (h === 1 && open === 2) v += 1.5;
    });
    if (t.g === 2 && GWANGS.some((x) => !has.has(x) && !dead.has(x))) v += 6;
    if (t.p >= 7 && t.p < 10) v += (t.p - 6) * 1.6;
    if (t.y === 4) v += 4; if (t.t === 4) v += 4;
    if (t.p <= 5) v += t.p * 0.6; // 피박 피하기
    return v;
  }
  function deadFor(s, seat) {
    const d = new Set();
    for (let o = 0; o < s.n; o++) if (o !== seat) for (const ch of s.c[o]) d.add(ci(ch));
    return d;
  }
  /* cards this seat cannot see: opponents' hands + deck (public info only) */
  function unknownCards(s, seat) {
    const seen = new Set();
    for (const ch of s.h[seat] + s.f + s.tk + s.fp) seen.add(ch);
    s.c.forEach((p) => { for (const ch of p) seen.add(ch); });
    const out = [];
    const tot = 48 + (s.o.bn >= 2 ? 2 : 0) + (s.o.bn >= 3 ? 1 : 0);
    const ids = []; for (let i = 0; i < 48; i++) ids.push(i);
    if (s.o.bn >= 2) ids.push(48, 50); if (s.o.bn >= 3) ids.push(49);
    for (const i of ids) if (!seen.has(cc(i))) out.push(cc(i));
    void tot;
    return out;
  }
  function evalPos(s, seat, lv, unk) {
    const gk = s.o.gk;
    let v = 0;
    const lam = lv >= 3 ? 0.95 : 0.75;
    const piles = s.c.map(pileArr);
    for (let o = 0; o < s.n; o++) {
      const dead = new Set(); for (let x = 0; x < s.n; x++) if (x !== o) piles[x].forEach((c) => dead.add(c));
      const pv = pileValue(piles[o], dead, gk);
      v += o === seat ? pv : -lam * pv;
    }
    // threat: floor cards the opponents may grab next
    const U2 = Math.max(1, unk.length);
    const unkM = new Array(12).fill(0);
    for (const ch of unk) { const m = monthOf(ci(ch)); if (m >= 0) unkM[m]++; }
    const fl = {};
    for (const ch of s.f) { const m = monthOf(ci(ch)); (fl[m] = fl[m] || []).push(ci(ch)); }
    const myH = new Array(12).fill(0);
    for (const ch of s.h[seat]) { const m = monthOf(ci(ch)); if (m >= 0) myH[m]++; }
    const wTh = lv >= 3 ? 1 : 0.5;
    for (const k in fl) {
      const m = +k, cards = fl[m];
      // 보통 doesn't track captured cards: assume everything not in hand/floor is still out
      const km = lv >= 3 ? unkM[m] : Math.max(0, 4 - myH[m] - cards.length);
      if (!km) continue;
      for (let j = 1; j < s.n; j++) {
        const o = (seat + j) % s.n, h = s.h[o].length;
        let q = 1;
        for (let x = 0; x < h; x++) q *= Math.max(0, (U2 - km - x)) / Math.max(1, U2 - x);
        let pr = (1 - q) + 0.5 * km / U2;
        if (pr > 1) pr = 1;
        const gain = cards.length === 2 ? Math.max(...cards.map((c) => worthFor(piles[o], c, gk))) : cards.reduce((a, c) => a + worthFor(piles[o], c, gk), 0) + (cards.length === 3 ? 3 : 0);
        v -= wTh * pr * gain * (j === 1 ? 1 : 0.6) * lam;
      }
    }
    return v;
  }
  function worthFor(pile, c, gk) {
    const e = new Set();
    return pileValue(pile.concat([c]), e, gk) - pileValue(pile, e, gk);
  }
  function candidates(s, seat, lv) {
    const out = [];
    const hand = s.h[seat].split('');
    const seenMonth = {};
    for (const ch of hand) {
      const i = ci(ch);
      if (i >= 48) continue;
      const m = monthOf(i), F = floorOf(s, m), hc = handOf(s, seat, m).length;
      const key = m + ':' + (typeOf(i) === 3 && i !== GUK ? 'p' + piVal(i) : ch);
      if (seenMonth[key]) continue; seenMonth[key] = 1;
      const sh = hc === 3 && F.length === 0 ? 1 : 0;
      if (F.length === 2 && !same(ci(F[0]), ci(F[1]))) { out.push({ t: 'play', c: ch, p: F[0] }); out.push({ t: 'play', c: ch, p: F[1] }); }
      else out.push(sh && (lv >= 2 || Math.random() < 0.5) ? { t: 'play', c: ch, sh: 1 } : { t: 'play', c: ch });
      if (hc === 3 && F.length === 1 && !out.some((a) => a.t === 'bomb' && a.m === m)) out.push({ t: 'bomb', m });
    }
    if (s.bt[seat] > 0 && s.d.length) out.push({ t: 'pass' });
    return out;
  }
  const clone = (o) => JSON.parse(JSON.stringify(o));
  function simValue(s, seat, a, lv, unk) {
    // expected value over the unknown flip (the AI never peeks at the real deck)
    const flips = unk.length ? unk : [''];
    let tot = 0;
    for (const f of flips) {
      const t = clone(s);
      t.d = f;
      try { turn(t, seat, a, true); } catch (e) { return -1e9; }
      tot += evalPos(t, seat, lv, unk.filter((x) => x !== f));
    }
    let v = tot / flips.length;
    if (a.t === 'bomb') v += 7; // ×2 and two free flips
    if (a.sh) v += 4;
    return v;
  }
  function immediateValue(s, seat, a) { // 쉬움: only what this card grabs right now
    if (a.t === 'pass') return 0.5;
    if (a.t === 'bomb') return 14;
    const i = ci(a.c), F = floorOf(s, monthOf(i));
    if (!F.length) return -worth0(i) * 0.2;
    if (F.length === 3) return worth0(i) + F.reduce((x, c) => x + worth0(ci(c)), 0) + 3;
    const p = a.p || bestOf(F);
    return worth0(i) + worth0(ci(p));
  }
  function aiPlay(s, seat, lv) {
    const hb = s.h[seat].split('').find((ch) => ci(ch) >= 48);
    if (hb) return { t: 'play', c: hb };
    const cands = candidates(s, seat, lv);
    if (!cands.length) return { t: 'pass' };
    if (lv <= 1) {
      if (Math.random() < 0.22) return cands[U.rand(cands.length)];
      let best = cands[0], bv = -1e9;
      for (const a of cands) { const v = immediateValue(s, seat, a) + Math.random() * 3; if (v > bv) { bv = v; best = a; } }
      return best;
    }
    const unk = unknownCards(s, seat);
    let best = cands[0], bv = -1e9;
    for (const a of cands) {
      const v = simValue(s, seat, a, lv, unk) + (lv === 2 ? Math.random() * 3.5 : 0);
      if (v > bv) { bv = v; best = a; }
    }
    return best;
  }
  function aiPick(s, seat, lv) {
    const Fd = floorOf(s, monthOf(ci(s.fp)));
    if (lv <= 1) return { t: 'pick', p: Math.random() < 0.4 ? Fd[U.rand(Fd.length)] : bestOf(Fd) };
    const unk = unknownCards(s, seat);
    let best = Fd[0], bv = -1e9;
    for (const p of Fd) {
      const t = clone(s);
      t.f = rm(t.f, p); t.tk += t.fp + p; t.fp = '';
      finish(t, seat, t.last, true);
      const v = evalPos(t, seat, lv, unk);
      if (v > bv) { bv = v; best = p; }
    }
    return { t: 'pick', p: best };
  }
  /* rough "how many points could this opponent still reach soon" */
  function threatOf(s, o) {
    const cards = pileArr(s.c[o]), t = tallyBest(cards, s.o.gk);
    const dead = deadFor(s, o);
    let pot = t.tot;
    const has = new Set(cards);
    SETS.forEach((set, k) => {
      let h = 0, open = 0;
      for (const x of set) { if (has.has(x)) h++; else if (!dead.has(x)) open++; }
      if (h === 2 && open) pot += k === 3 ? 3 : 2;
    });
    if (t.g === 2 && GWANGS.some((x) => !has.has(x) && !dead.has(x))) pot += 2;
    if (t.p >= 8) pot += 1;
    if (t.y === 4 || t.t === 4) pot += 1;
    return { base: t.tot, pot };
  }
  function aiGo(s, seat, lv) {
    const hand = s.h[seat].length, T = thr(s);
    if (lv <= 1) return { t: Math.random() < 0.55 ? 'go' : 'stop' };
    let oppBase = 0, oppPot = 0;
    for (let o = 0; o < s.n; o++) if (o !== seat) { const th = threatOf(s, o); oppBase = Math.max(oppBase, th.base); oppPot = Math.max(oppPot, th.pot); }
    if (lv === 2) {
      if (hand < 2) return { t: 'stop' };
      if (oppBase >= T - 2 || oppPot >= T) return { t: 'stop' };
      if (s.go[seat] >= 2 && hand < 4) return { t: 'stop' };
      return { t: 'go' };
    }
    // 어려움: 고박 위험과 상대 위협을 따져요
    const my = score(s, seat), myPi = my.p;
    const turnsLeft = hand;
    if (turnsLeft < 2) return { t: 'stop' };
    if (oppPot >= T - (s.n === 2 ? 1 : 0)) return { t: 'stop' };
    if (oppBase >= T - 3) return { t: 'stop' };
    if (myPi <= 5 && oppPot >= T - 3) return { t: 'stop' }; // 지면 피박까지
    if (s.go[seat] >= 3) return { t: 'stop' };
    if (s.go[seat] >= 2 && turnsLeft < 4) return { t: 'stop' };
    return { t: 'go' };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'r') return { t: 'next' };
    if (s.ph === 'x' || seat !== s.t) return null;
    if (s.ph === 'g') { // AI 성향(core 라운드 31): 도박형은 고를 더, 수비형은 스톱을 더
      const a = aiGo(s, seat, lv), st = (L.aiStyle && L.aiStyle(seat)) || 'bal', hand = s.h[seat].length;
      if (st === 'gamble' && a.t === 'stop' && hand >= 2 && s.go[seat] < 3 && Math.random() < 0.4) return { t: 'go' };
      if (st === 'agg' && a.t === 'stop' && hand >= 3 && s.go[seat] < 2 && Math.random() < 0.2) return { t: 'go' };
      if (st === 'def' && a.t === 'go' && (s.go[seat] >= 1 || hand < 4) && Math.random() < 0.5) return { t: 'stop' };
      return a;
    }
    if (s.ph === 'f') return aiPick(s, seat, lv);
    return aiPlay(s, seat, lv);
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'r') return s.ai.every((x) => x) && seat === 0 ? 3200 : -1;
    if (seat !== s.t) return -1;
    if (s.ph === 'g') return 900;
    if (s.ph === 'f') return 650;
    return lv === 1 ? 1000 : lv === 3 ? 650 : 800;
  }

  /* ---------- art: original hwatu-style faces, drawn in a 100×160 unit box ---------- */
  const RED = '#c8281e', DRED = '#8f1a14', INK = '#1c1714', CREAM = '#f7f0e0', GOLD = '#d9a23a', GRN = '#2f5d3a', BLUE = '#2c4a8a', PUR = '#5c3d8f', BRN = '#7a4a26';
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace', DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const CR = 1.6; // card height / width
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  function circ(c, x, y, r, col) { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); }
  function ell(c, x, y, rx, ry, rot, col) { c.fillStyle = col; c.beginPath(); c.ellipse(x, y, rx, ry, rot || 0, 0, 7); c.fill(); }
  function line(c, pts, w, col) { c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'round'; c.beginPath(); c.moveTo(pts[0], pts[1]); for (let k = 2; k < pts.length; k += 2) c.lineTo(pts[k], pts[k + 1]); c.stroke(); }
  function curve(c, x0, y0, cx, cy, x1, y1, w, col) { c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'round'; c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(cx, cy, x1, y1); c.stroke(); }
  function blossom(c, x, y, r, col, mid) { for (let k = 0; k < 5; k++) { const a = k * 1.2566 - 1.57; circ(c, x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55, r * 0.5, col); } circ(c, x, y, r * 0.28, mid || GOLD); }
  function leaf(c, x, y, len, wid, ang, col) { c.save(); c.translate(x, y); c.rotate(ang); c.fillStyle = col; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(len * 0.5, -wid, len, 0); c.quadraticCurveTo(len * 0.5, wid, 0, 0); c.fill(); c.restore(); }
  function bird(c, x, y, s, body, wing, flip) { // small perched/flying bird
    c.save(); c.translate(x, y); c.scale(flip ? -s : s, s);
    ell(c, 0, 0, 14, 8, -0.2, body);
    circ(c, 11, -6, 6, body);
    c.fillStyle = GOLD; c.beginPath(); c.moveTo(16, -7); c.lineTo(23, -5); c.lineTo(16, -4); c.fill();
    circ(c, 12.5, -7, 1.5, INK);
    c.fillStyle = wing; c.beginPath(); c.moveTo(-4, -3); c.quadraticCurveTo(-8, -20, 6, -16); c.quadraticCurveTo(4, -6, -4, -3); c.fill();
    c.fillStyle = body; c.beginPath(); c.moveTo(-12, 0); c.lineTo(-24, 6); c.lineTo(-20, -2); c.fill();
    c.restore();
  }
  function flyer(c, x, y, s, col) { c.save(); c.translate(x, y); c.scale(s, s); c.fillStyle = col; c.beginPath(); c.moveTo(-14, -4); c.quadraticCurveTo(-6, -8, 0, 0); c.quadraticCurveTo(6, -8, 14, -4); c.quadraticCurveTo(6, -2, 0, 4); c.quadraticCurveTo(-6, -2, -14, -4); c.fill(); c.restore(); }
  function ribbon(c, kind) {
    const col = kind === 'c' ? BLUE : RED;
    c.save(); c.translate(50, 86); c.rotate(-0.12);
    c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(-11, -46, 24, 96);
    c.fillStyle = col; c.beginPath(); c.moveTo(-12, -48); c.lineTo(12, -48); c.lineTo(10, 40); c.lineTo(14, 50); c.lineTo(0, 44); c.lineTo(-14, 50); c.lineTo(-10, 40); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,.25)'; c.fillRect(-12, -48, 4, 88);
    if (kind === 'h') { // 홍단: brushed marks
      c.strokeStyle = INK; c.lineWidth = 2.4; c.lineCap = 'round';
      for (let k = 0; k < 3; k++) { const y = -36 + k * 22; c.beginPath(); c.moveTo(-4, y); c.quadraticCurveTo(5, y + 3, -2, y + 9); c.moveTo(3, y + 1); c.lineTo(2, y + 14); c.stroke(); }
    } else if (kind === 'r') { // 비 띠: black stripes
      c.fillStyle = INK; for (let k = 0; k < 4; k++) c.fillRect(-12, -40 + k * 22, 24, 6);
    }
    c.restore();
  }
  function pine(c) {
    curve(c, 18, 165, 20, 100, 58, 70, 9, INK);
    curve(c, 30, 110, 55, 108, 78, 95, 5, INK);
    for (const [x, y, r] of [[56, 62, 22], [80, 92, 16], [26, 96, 17]]) {
      ell(c, x, y, r, r * 0.62, 0, GRN);
      c.strokeStyle = INK; c.lineWidth = 1.4; c.beginPath();
      for (let k = 0; k <= 8; k++) { const a = Math.PI + k * Math.PI / 8; c.moveTo(x, y + r * 0.3); c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r * 0.62); }
      c.stroke();
    }
  }
  function plum(c) {
    curve(c, 8, 158, 30, 90, 88, 30, 7, INK);
    curve(c, 40, 92, 60, 96, 86, 104, 4, INK);
    curve(c, 26, 120, 14, 96, 10, 70, 3.5, INK);
    for (const [x, y] of [[84, 34], [66, 50], [50, 68], [76, 102], [58, 96], [12, 74], [36, 104]]) blossom(c, x, y, 11, RED, '#fff3d6');
  }
  function cherry(c) {
    curve(c, 0, 30, 50, 40, 100, 20, 4, INK);
    for (const [x, y] of [[14, 30], [30, 42], [48, 36], [66, 30], [84, 24], [22, 56], [58, 54], [80, 46], [40, 62]]) blossom(c, x, y, 12, (x + y) % 3 ? '#e8899a' : RED, '#fff3d6');
  }
  function wisteria(c) {
    for (let k = 0; k < 5; k++) {
      const x0 = 12 + k * 19, len = 70 + (k % 2) * 30;
      for (let j = 0; j < 9; j++) { const y = 6 + j * len / 9, x = x0 + Math.sin(j * 0.7 + k) * 4; ell(c, x, y, 4.2, 7.5, 0.3, INK); }
    }
  }
  function iris(c, flowers) {
    for (let k = 0; k < 6; k++) { const x = 18 + k * 13; c.fillStyle = k % 2 ? GRN : INK; c.beginPath(); c.moveTo(x - 4, 165); c.quadraticCurveTo(x - 6 + k, 100, x + (k - 3) * 3, 52 + (k % 3) * 12); c.quadraticCurveTo(x + 2, 110, x + 4, 165); c.fill(); }
    if (flowers) for (const [x, y] of [[30, 52], [70, 44], [52, 70]]) { leaf(c, x, y, 16, 6, -2.2, PUR); leaf(c, x, y, 16, 6, -0.9, PUR); leaf(c, x, y, 13, 5, 1.57, '#7d5bb5'); circ(c, x, y, 3, GOLD); }
  }
  function peony(c, x, y, r) {
    for (const [a, l] of [[2.4, 30], [0.7, 30], [1.6, 26], [3.6, 26], [-0.4, 26]]) leaf(c, x, y, l + r * 0.4, 9, a, INK);
    for (let k = 0; k < 9; k++) { const a = k * 0.698; circ(c, x + Math.cos(a) * r * 0.6, y + Math.sin(a) * r * 0.6, r * 0.5, RED); }
    for (let k = 0; k < 6; k++) { const a = k * 1.047 + 0.3; circ(c, x + Math.cos(a) * r * 0.32, y + Math.sin(a) * r * 0.32, r * 0.34, '#e2594a'); }
    circ(c, x, y, r * 0.2, GOLD);
  }
  function clover(c) {
    for (let k = 0; k < 4; k++) {
      const x0 = 10 + k * 24;
      curve(c, x0, 165, x0 + 30, 90, x0 + 18, 20 + k * 8, 2.6, INK);
      for (let j = 0; j < 8; j++) { const t = j / 8, x = x0 + 30 * 2 * t * (1 - t) + 18 * t * t, y = 165 * (1 - t) * (1 - t) + 2 * t * (1 - t) * 90 + t * t * (20 + k * 8); ell(c, x + 5, y, 4.5, 2.6, 0.5, RED); ell(c, x - 5, y + 3, 4.5, 2.6, -0.5, j % 2 ? DRED : RED); }
    }
  }
  function hill(c) {
    const g = c.createLinearGradient(0, 0, 0, 110); g.addColorStop(0, '#b52018'); g.addColorStop(1, '#e0582e');
    c.fillStyle = g; c.fillRect(0, 0, 100, 160);
    c.fillStyle = INK; c.beginPath(); c.moveTo(0, 160); c.lineTo(0, 108); c.quadraticCurveTo(50, 70, 100, 108); c.lineTo(100, 160); c.fill();
    c.strokeStyle = '#efe5cf'; c.lineWidth = 1.4; c.beginPath();
    for (let k = 0; k < 13; k++) { const x = 6 + k * 7.5, y = 108 - Math.sin((x / 100) * Math.PI) * 26 + 10; c.moveTo(x, y + 30); c.quadraticCurveTo(x + 2, y + 10, x + 6, y - 4); }
    c.stroke();
  }
  function mum(c, x, y, r) {
    curve(c, x, y, x - 8, y + 40, x - 4, 165, 3, INK);
    leaf(c, x - 4, y + 40, 22, 8, 2.6, INK); leaf(c, x - 4, y + 52, 22, 8, 0.4, GRN);
    for (let k = 0; k < 16; k++) { const a = k * 0.3927; leaf(c, x, y, r, r * 0.22, a, k % 2 ? '#e8b830' : '#f2cf55'); }
    circ(c, x, y, r * 0.3, RED);
  }
  function maple(c) {
    curve(c, 0, 60, 50, 40, 100, 70, 3, INK); curve(c, 30, 160, 40, 100, 60, 52, 3, INK);
    for (const [x, y, s] of [[14, 52, 1], [40, 40, 1.1], [70, 48, 1], [88, 70, 0.9], [52, 76, 1], [26, 82, 0.9], [62, 104, 0.8]]) {
      c.fillStyle = (x + y) % 2 ? RED : DRED; c.beginPath();
      for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, rr2 = (k % 2 ? 4.5 : 12) * s; c.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
      c.closePath(); c.fill();
    }
  }
  function paulownia(c, yellow) {
    if (yellow) { c.fillStyle = '#f0cf5a'; c.fillRect(0, 0, 100, 160); }
    for (const [x, y, s, a] of [[30, 128, 1.2, -0.3], [70, 124, 1.1, 0.4], [50, 146, 1, 0]]) {
      c.save(); c.translate(x, y); c.rotate(a); c.scale(s, s); c.fillStyle = INK; c.beginPath(); c.moveTo(0, 22); c.bezierCurveTo(-30, 4, -22, -26, 0, -16); c.bezierCurveTo(22, -26, 30, 4, 0, 22); c.fill(); c.restore();
    }
    curve(c, 50, 104, 48, 70, 52, 22, 3, INK);
    for (let k = 0; k < 7; k++) { circ(c, 46 + (k % 2) * 9, 28 + k * 10, 4.5, PUR); circ(c, 46 + (k % 2) * 9, 28 + k * 10, 1.5, '#e8d9ff'); }
  }
  function willow(c) {
    for (let k = 0; k < 5; k++) { const x = 8 + k * 22; curve(c, x, -4, x + 14, 60, x + 4, 120 - (k % 2) * 30, 2.4, k % 2 ? GRN : INK); }
    c.strokeStyle = 'rgba(40,50,70,.35)'; c.lineWidth = 1; c.beginPath();
    for (let k = 0; k < 14; k++) { const x = (k * 37) % 100, y = (k * 53) % 150; c.moveTo(x, y); c.lineTo(x - 5, y + 14); }
    c.stroke();
  }
  function drawArt(c, i) {
    c.fillStyle = CREAM; c.fillRect(0, 0, 100, 160);
    if (i >= 48) { // 보너스 피
      const g = c.createLinearGradient(0, 0, 100, 160); g.addColorStop(0, '#f6d77a'); g.addColorStop(1, '#d9a23a');
      c.fillStyle = g; c.fillRect(0, 0, 100, 160);
      c.strokeStyle = DRED; c.lineWidth = 3; rr(c, 8, 8, 84, 144, 8); c.stroke();
      c.fillStyle = DRED; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.font = '700 15px ' + FONT; c.fillText('보너스', 50, 34);
      c.font = '64px ' + DISP; c.fillText(String(piVal(i)), 50, 86);
      c.font = '700 22px ' + FONT; c.fillText('피', 50, 128);
      return;
    }
    const m = monthOf(i), k = i & 3, t = typeOf(i);
    switch (m) {
      case 0: if (t === 0) { circ(c, 70, 38, 20, RED); pine(c); c.save(); c.translate(0, 18); ell(c, 44, 112, 20, 11, -0.3, '#fff'); curve(c, 54, 106, 66, 92, 60, 76, 4, INK); circ(c, 60, 74, 4.5, '#fff'); circ(c, 60, 70.5, 2.6, RED); line(c, [24, 116, 14, 124], 6, INK); line(c, [40, 122, 38, 142, 44, 142], 2, INK); c.restore(); }
        else { c.fillStyle = RED; c.beginPath(); c.ellipse(50, 168, 70, 34, 0, 0, 7); c.fill(); pine(c); }
        break;
      case 1: plum(c); if (t === 1) bird(c, 52, 84, 1.3, '#9fae3a', '#5f6f22'); break;
      case 2: cherry(c); if (t === 0) { c.fillStyle = INK; c.fillRect(4, 84, 92, 5); for (let s = 0; s < 8; s++) { c.fillStyle = s % 2 ? '#fff' : RED; c.beginPath(); c.moveTo(6 + s * 11, 89); c.lineTo(17 + s * 11, 89); c.lineTo(17 + s * 11, 146 - (s % 2) * 6); c.quadraticCurveTo(11.5 + s * 11, 154, 6 + s * 11, 146 - (s % 2) * 6); c.fill(); } c.strokeStyle = GOLD; c.lineWidth = 3; c.beginPath(); c.moveTo(4, 100); c.quadraticCurveTo(50, 116, 96, 100); c.stroke(); }
        else if (t === 3) { c.fillStyle = RED; c.beginPath(); c.ellipse(50, 172, 70, 40, 0, 0, 7); c.fill(); }
        break;
      case 3: wisteria(c); if (t === 1) { c.fillStyle = RED; c.beginPath(); c.arc(76, 126, 14, 0, 7); c.fill(); c.fillStyle = CREAM; c.beginPath(); c.arc(82, 122, 13, 0, 7); c.fill(); flyer(c, 48, 118, 2.2, INK); circ(c, 48, 118, 4, RED); } break;
      case 4: iris(c, true); if (t === 1) { c.fillStyle = BRN; for (let s = 0; s < 3; s++) { c.save(); c.translate(20 + s * 30, 124 - (s % 2) * 14); c.rotate(s % 2 ? 0.35 : -0.35); c.fillRect(-18, -5, 36, 10); c.fillStyle = '#4a2a14'; c.fillRect(-18, -1, 36, 2); c.fillStyle = BRN; c.restore(); } } break;
      case 5: peony(c, 50, t === 1 ? 104 : 80, 24); if (t === 1) { for (const [x, y, s] of [[30, 40, 1], [70, 54, 0.8]]) { c.save(); c.translate(x, y); c.scale(s, s); ell(c, -9, -6, 10, 7, -0.5, '#f2cf55'); ell(c, 9, -6, 10, 7, 0.5, '#f2cf55'); ell(c, -7, 6, 7, 5, 0.4, GOLD); ell(c, 7, 6, 7, 5, -0.4, GOLD); c.strokeStyle = INK; c.lineWidth = 1.6; c.beginPath(); c.moveTo(0, -10); c.lineTo(0, 10); c.stroke(); c.restore(); } } break;
      case 6: clover(c); if (t === 1) { ell(c, 50, 128, 30, 16, 0, '#4a3020'); circ(c, 76, 122, 11, '#4a3020'); ell(c, 86, 126, 6, 4, 0, '#6b4a33'); circ(c, 78, 118, 2, '#fff'); for (const x of [30, 42, 58, 68]) line(c, [x, 138, x, 152], 5, '#4a3020'); c.fillStyle = '#4a3020'; c.beginPath(); c.moveTo(72, 112); c.lineTo(70, 102); c.lineTo(78, 110); c.fill(); } break;
      case 7: hill(c); if (t === 0) { circ(c, 50, 50, 30, '#fbf5e4'); circ(c, 50, 50, 30, 'rgba(255,240,200,.4)'); } if (t === 1) { flyer(c, 30, 40, 1.4, INK); flyer(c, 56, 30, 1.2, INK); flyer(c, 76, 50, 1.3, INK); } break;
      case 8: if (t === 1) { mum(c, 70, 40, 16); c.fillStyle = RED; c.beginPath(); c.moveTo(20, 96); c.lineTo(76, 96); c.quadraticCurveTo(70, 138, 48, 140); c.quadraticCurveTo(26, 138, 20, 96); c.fill(); ell(c, 48, 96, 28, 6, 0, DRED); c.fillStyle = GOLD; c.font = '700 22px serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('壽', 48, 116); }
        else { mum(c, 46, 54, 22); if (t === 3) mum(c, 76, 104, 12); }
        break;
      case 9: maple(c); if (t === 1) { ell(c, 46, 128, 24, 12, 0, BRN); c.save(); c.translate(68, 114); c.rotate(-0.5); ell(c, 0, 0, 9, 6, 0, BRN); c.restore(); circ(c, 70, 112, 1.8, INK); line(c, [66, 106, 60, 94, 54, 92], 2, '#4a2a14'); line(c, [70, 104, 72, 92, 80, 88], 2, '#4a2a14'); for (const x of [30, 38, 54, 62]) line(c, [x, 136, x + (x % 3) - 1, 152], 3.5, BRN); for (let s = 0; s < 5; s++) circ(c, 36 + s * 6, 124 + (s % 2) * 3, 1.6, CREAM); } break;
      case 10: paulownia(c, i === 41); if (t === 0) { c.save(); c.translate(52, 66); for (let s = 0; s < 5; s++) { c.strokeStyle = [RED, GOLD, GRN, BLUE, RED][s]; c.lineWidth = 5; c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(-30 - s * 4, 10 + s * 8, -36 + s * 6, 44 + s * 4); c.stroke(); } ell(c, 4, -4, 16, 10, -0.4, RED); circ(c, 18, -16, 7, GOLD); c.fillStyle = INK; c.beginPath(); c.moveTo(24, -16); c.lineTo(32, -14); c.lineTo(24, -12); c.fill(); circ(c, 19, -18, 1.5, INK); leaf(c, 0, -6, 26, 9, -2.4, GRN); c.restore(); } break;
      case 11:
        if (i === 47) { c.fillStyle = INK; c.fillRect(0, 0, 100, 160); c.lineWidth = 6; for (let s = 0; s < 6; s++) { c.strokeStyle = s % 2 ? '#efe5cf' : RED; c.beginPath(); for (let x = 0; x <= 100; x += 10) c.lineTo(x, 22 + s * 22 + (x / 10 % 2 ? -6 : 6)); c.stroke(); } circ(c, 50, 80, 16, DRED); circ(c, 50, 80, 9, GOLD); break; }
        willow(c);
        if (t === 0) { c.fillStyle = RED; c.beginPath(); c.arc(40, 70, 28, Math.PI, 0); c.fill(); c.strokeStyle = INK; c.lineWidth = 2; for (let s = -2; s <= 2; s++) { c.beginPath(); c.moveTo(40, 42); c.lineTo(40 + s * 13, 70); c.stroke(); } line(c, [40, 70, 46, 98], 2.5, INK); circ(c, 48, 82, 7, '#f0d9b5'); c.fillStyle = INK; c.beginPath(); c.moveTo(36, 150); c.lineTo(46, 88); c.lineTo(64, 92); c.lineTo(70, 150); c.fill(); ell(c, 80, 146, 9, 6, 0, '#5a8a3a'); circ(c, 77, 143, 1.5, INK); circ(c, 83, 143, 1.5, INK); }
        else if (t === 1) { c.save(); c.translate(52, 96); c.rotate(0.5); flyer(c, 0, 0, 2.6, INK); c.fillStyle = INK; c.beginPath(); c.moveTo(0, 2); c.lineTo(-8, 30); c.lineTo(0, 22); c.lineTo(8, 30); c.fill(); circ(c, 0, -2, 4, RED); c.restore(); }
        break;
    }
    if (t === 2) ribbon(c, m === 11 ? 'r' : DAN.h.includes(i) ? 'h' : DAN.c.includes(i) ? 'c' : 'o');
  }
  function drawBadges(c, i) {
    const t = typeOf(i);
    const dark = i === 47 || monthOf(i) === 7;
    if (i < 48) {
      c.fillStyle = dark ? 'rgba(255,248,232,.92)' : 'rgba(28,23,20,.86)'; rr(c, 3, 3, 26, 20, 6); c.fill();
      c.fillStyle = dark ? INK : '#fff6e6'; c.font = '700 16px ' + MONO; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(String(monthOf(i) + 1), 16, 13.5);
    }
    let txt = '', bgc = '', fg = '#fff';
    if (t === 0) { txt = '光'; bgc = RED; }
    else if (t === 1) { txt = i === GUK ? '끗²' : '끗'; bgc = BIRDS.includes(i) ? '#3a6a2a' : INK; }
    else if (t === 2) { txt = '띠'; bgc = DAN.c.includes(i) ? BLUE : DAN.h.includes(i) ? RED : DAN.o.includes(i) ? '#b0472f' : '#6a5a50'; }
    else if (piVal(i) >= 2 && i < 48) { txt = '쌍'; bgc = DRED; }
    if (!txt) return;
    if (t === 0) { circ(c, 16, 37, 13, bgc); c.strokeStyle = '#fff3d6'; c.lineWidth = 1.5; c.stroke(); }
    else { c.fillStyle = bgc; rr(c, 3, 25, 26, 22, 6); c.fill(); }
    c.fillStyle = fg; c.font = (t === 0 ? '700 17px serif' : '700 14px ' + FONT); c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillText(txt, 16, t === 0 ? 38 : 36.5);
  }
  /* ---------- 「모던」 화투 그림: 평면 일러스트, 달마다 색 · 상징 하나, 큰 표시 (기기에 저장) ---------- */
  const SKIN_KEY = 'lounge.gostop.skin';
  let skin = 'classic';
  try { if (localStorage.getItem(SKIN_KEY) === 'modern') skin = 'modern'; } catch (e) {}
  function setSkin(v) { skin = v; try { localStorage.setItem(SKIN_KEY, v); } catch (e) {} }
  // [바탕, 진한 색, 보조 색]
  const MP = [['#e6f0e8', '#24704a', '#8fc39f'], ['#fbe8ee', '#c23b66', '#f2a9bf'], ['#fdeef4', '#d95a92', '#f7c3d8'], ['#ebeaf3', '#45446e', '#a9a7cf'],
    ['#e8eefb', '#3b58c4', '#a9b9ef'], ['#fcebe7', '#cc3f30', '#f3ada3'], ['#f5e8f1', '#a23a7a', '#dfa6c9'], ['#1e2842', '#f2dd9a', '#4c5a82'],
    ['#fdf3d9', '#c98a12', '#f2cf7a'], ['#fdebe0', '#d4501a', '#f4ae86'], ['#eceee0', '#5f6e22', '#c3cc8e'], ['#e1e7ee', '#35546f', '#9db2c6']];
  function poly(c, pts, col) { c.fillStyle = col; c.beginPath(); c.moveTo(pts[0], pts[1]); for (let k = 2; k < pts.length; k += 2) c.lineTo(pts[k], pts[k + 1]); c.closePath(); c.fill(); }
  function petals(c, x, y, n, len, wid, col, rot) { for (let k = 0; k < n; k++) { const an = rot + k * 6.2832 / n; ell(c, x + Math.cos(an) * len * 0.6, y + Math.sin(an) * len * 0.6, len * 0.6, wid, an, col); } }
  function mSym(c, m, x, y, s) { // month emblem centered at x,y, size s (≈ radius)
    const d = MP[m][1], a = MP[m][2];
    c.save(); c.translate(x, y); c.scale(s / 30, s / 30);
    switch (m) {
      case 0: c.fillStyle = '#7a5a3a'; c.fillRect(-4, 14, 8, 18); poly(c, [0, -32, -22, -6, 22, -6], d); poly(c, [0, -18, -28, 10, 28, 10], d); poly(c, [0, -4, -32, 22, 32, 22], a); break;
      case 1: petals(c, 0, 0, 5, 26, 13, d, -1.57); circ(c, 0, 0, 8, '#ffe39a'); break;
      case 2: for (let k = 0; k < 5; k++) { c.save(); c.rotate(k * 1.2566); c.fillStyle = a; c.beginPath(); c.moveTo(0, 0); c.bezierCurveTo(-18, -12, -12, -30, -3, -30); c.lineTo(0, -25); c.lineTo(3, -30); c.bezierCurveTo(12, -30, 18, -12, 0, 0); c.fill(); c.restore(); } circ(c, 0, 0, 6, d); break;
      case 3: line(c, [-20, -32, 20, -32], 4, '#5a4a3a'); for (const ox of [-14, 6]) for (let k = 0; k < 5; k++) circ(c, ox + (k % 2) * 4, -24 + k * 12, 7 - k * 0.8, k % 2 ? a : d); break;
      case 4: line(c, [0, 32, 0, 0], 4, '#3c7a46'); leaf(c, 0, 30, 30, 5, -1.9, '#3c7a46'); ell(c, 0, -14, 9, 20, 0, d); ell(c, -14, -2, 8, 18, -0.9, a); ell(c, 14, -2, 8, 18, 0.9, a); break;
      case 5: circ(c, 0, 0, 30, a); petals(c, 0, 0, 6, 22, 11, d, 0); circ(c, 0, 0, 10, '#ffd56a'); break;
      case 6: curve(c, -26, 30, -24, -20, 20, -30, 3.5, '#6a4a38'); for (let k = 0; k < 5; k++) { const t = k / 5, px = -26 + t * 40 - t * t * 8, py = 30 - t * 58; ell(c, px - 8, py, 7, 4, -0.6, a); ell(c, px + 8, py - 2, 6, 3.5, 0.6, d); } break;
      case 7: circ(c, 6, -10, 20, d); c.fillStyle = a; c.beginPath(); c.moveTo(-34, 32); c.quadraticCurveTo(0, -6, 34, 32); c.fill(); break;
      case 8: petals(c, 0, 0, 16, 28, 4.5, d, 0); petals(c, 0, 0, 12, 16, 4, a, 0.2); circ(c, 0, 0, 7, '#8a5a10'); break;
      case 9: { const pts = []; for (let k = 0; k < 10; k++) { const r = k % 2 ? 13 : 32, an = -1.57 + k * 0.6283; pts.push(Math.cos(an) * r, Math.sin(an) * r); } poly(c, pts, d); line(c, [0, 6, 0, 32], 3.5, '#7a3a14'); break; }
      case 10: c.fillStyle = d; c.beginPath(); c.moveTo(0, 30); c.bezierCurveTo(-40, 0, -24, -34, 0, -20); c.bezierCurveTo(24, -34, 40, 0, 0, 30); c.fill(); line(c, [0, 26, 0, -14], 2.5, a); for (let k = 0; k < 3; k++) circ(c, (k - 1) * 12, -30 + Math.abs(k - 1) * 4, 5, '#b38be0'); break;
      case 11: c.fillStyle = d; c.beginPath(); c.arc(0, -4, 28, Math.PI, 0); c.fill(); line(c, [0, -4, 0, 24], 3.5, d); curve(c, 0, 24, 6, 32, 10, 24, 3.5, d); for (const [lx, ly] of [[-26, 8], [-14, 18], [20, 10], [28, -26], [-30, -30]]) line(c, [lx, ly, lx - 4, ly + 10], 3, a); break;
    }
    c.restore();
  }
  function animal(c, i, x, y) { // 열끗 그림
    const m = monthOf(i), col = m === 7 ? '#f6efe0' : INK;
    c.save(); c.translate(x, y);
    if (BIRDS.includes(i) || m === 11) {
      for (const [bx, by, s] of (m === 7 ? [[-16, -6, 0.9], [8, -14, 0.8], [16, 6, 0.85]] : [[0, 0, 1.3]])) { c.save(); c.translate(bx, by); c.scale(s, s); flyer(c, 0, 0, 1.2, col); circ(c, 0, 0, 3, m === 11 ? RED : '#e7b43a'); c.restore(); }
    } else if (m === 5) { for (const sx of [-1, 1]) { ell(c, sx * 10, -6, 10, 7, sx * 0.5, '#e8b730'); ell(c, sx * 8, 6, 7, 5, -sx * 0.4, '#c98a12'); } line(c, [0, -10, 0, 10], 2.5, INK); }
    else if (m === 4) { c.fillStyle = '#7a4a26'; rr(c, -26, -6, 52, 10, 3); c.fill(); for (const px of [-18, 0, 18]) c.fillRect(px - 2, 4, 4, 10); }
    else if (m === 8) { poly(c, [-18, -10, 18, -10, 10, 12, -10, 12], RED); ell(c, 0, -10, 18, 4, 0, '#8f1a14'); c.fillStyle = '#ffd56a'; c.font = '700 13px serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('壽', 0, 1); }
    else { ell(c, 0, 2, 20, 10, 0, '#6b4226'); circ(c, 18, -6, 7, '#6b4226'); for (const lx of [-12, -4, 6, 12]) line(c, [lx, 8, lx, 18], 3.5, '#6b4226'); if (m === 9) { line(c, [16, -12, 12, -22], 2, '#4a2a14'); line(c, [20, -12, 24, -22], 2, '#4a2a14'); } circ(c, 20, -7, 1.4, '#fff'); }
    c.restore();
  }
  function drawModern(c, i) {
    if (i >= 48) {
      c.fillStyle = '#2b2233'; c.fillRect(0, 0, 100, 160);
      circ(c, 50, 74, 34, '#f2c14e');
      c.fillStyle = '#2b2233'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.font = '56px ' + DISP; c.fillText(String(piVal(i)), 50, 78);
      c.fillStyle = '#f2c14e'; c.font = '700 16px ' + FONT; c.fillText('보너스 피', 50, 136);
      return;
    }
    const m = monthOf(i), t = typeOf(i), dark = m === 7;
    c.fillStyle = MP[m][0]; c.fillRect(0, 0, 100, 160);
    if (i === 47) { for (let k = 0; k < 14; k++) line(c, [k * 12, 0, k * 12 - 40, 160], 3, 'rgba(53,84,111,.22)'); }
    if (t === 0) { // 광: 금빛 원판 + 상징
      circ(c, 50, 74, 36, dark ? '#3a4770' : '#fff4d0'); c.strokeStyle = '#e0a82e'; c.lineWidth = 4; c.beginPath(); c.arc(50, 74, 36, 0, 7); c.stroke();
      for (let k = 0; k < 12; k++) { const an = k * 0.5236; line(c, [50 + Math.cos(an) * 41, 74 + Math.sin(an) * 41, 50 + Math.cos(an) * 47, 74 + Math.sin(an) * 47], 3, '#e0a82e'); }
      mSym(c, m, 50, 74, 25);
    } else if (t === 1) { mSym(c, m, 50, 62, 22); animal(c, i, 50, 112); }
    else if (t === 2) mSym(c, m, 50, 64, 24);
    else mSym(c, m, 50, 82, piVal(i) >= 2 ? 32 : 26);
    if (t === 2) { // 띠: 가로 리본
      const rc = m === 11 ? '#8a8f98' : DAN.c.includes(i) ? '#2f5fc4' : DAN.h.includes(i) ? '#d3302a' : '#e0742a';
      c.save(); c.translate(50, 113); c.rotate(-0.12); c.fillStyle = rc; rr(c, -38, -11, 76, 22, 4); c.fill();
      poly(c, [-38, -11, -47, -11, -41, 0, -47, 11, -38, 11], rc); poly(c, [38, -11, 47, -11, 41, 0, 47, 11, 38, 11], rc);
      if (m !== 11) { c.fillStyle = '#fff'; c.font = '700 14px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(DAN.c.includes(i) ? '청단' : DAN.h.includes(i) ? '홍단' : '초단', 0, 1); }
      c.restore();
    }
    // 아래 종류 띠
    const lab = t === 0 ? '광' : t === 1 ? '열끗' : t === 2 ? '띠' : piVal(i) >= 2 ? '쌍피' : '피';
    const lc = t === 0 ? '#e0a82e' : t === 1 ? (BIRDS.includes(i) ? '#2f8a4a' : '#3b3340') : t === 2 ? '#6a5a7a' : piVal(i) >= 2 ? '#a3241b' : (dark ? 'rgba(255,255,255,.16)' : 'rgba(0,0,0,.09)');
    c.fillStyle = lc; c.fillRect(0, 137, 100, 23);
    c.fillStyle = t === 0 ? '#2b1d05' : t === 3 && piVal(i) < 2 ? (dark ? '#f2dd9a' : MP[m][1]) : '#fff'; c.font = '700 16px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(lab, 50, 149);
  }
  function drawModernBadges(c, i) {
    if (i >= 48) return;
    const m = monthOf(i), t = typeOf(i), dark = m === 7;
    c.fillStyle = dark ? '#fff6e0' : MP[m][1]; rr(c, 4, 4, 30, 26, 8); c.fill();
    c.fillStyle = dark ? '#1e2842' : '#fff'; c.font = '700 19px ' + MONO; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(String(m + 1), 19, 17.5);
    let txt = '', bg = '';
    if (t === 0) { txt = '光'; bg = '#d3302a'; }
    else if (t === 1) { txt = i === GUK ? '끗²' : '끗'; bg = BIRDS.includes(i) ? '#2f8a4a' : '#3b3340'; }
    else if (t === 2) { txt = '띠'; bg = m === 11 ? '#6f7480' : DAN.c.includes(i) ? '#2f5fc4' : DAN.h.includes(i) ? '#d3302a' : '#e0742a'; }
    else if (piVal(i) >= 2) { txt = '쌍'; bg = '#a3241b'; }
    if (!txt) return;
    c.fillStyle = bg; rr(c, 4, 33, 30, 24, 8); c.fill();
    c.fillStyle = '#fff'; c.font = t === 0 ? '700 18px serif' : '700 15px ' + FONT; c.fillText(txt, 19, 45.5);
  }
  const faceCache = new Map();
  function faceImg(i, w, dpr) {
    const key = skin[0] + i + '|' + Math.round(w * dpr);
    let cv = faceCache.get(key);
    if (cv) return cv;
    if (faceCache.size > 400) faceCache.clear();
    cv = document.createElement('canvas');
    cv.width = Math.ceil(w * dpr); cv.height = Math.ceil(w * CR * dpr);
    const c = cv.getContext('2d');
    c.scale(cv.width / 100, cv.height / 160);
    c.save(); rr(c, 0, 0, 100, 160, 9); c.clip();
    if (skin === 'modern') drawModern(c, i); else drawArt(c, i);
    c.restore();
    if (skin === 'modern') drawModernBadges(c, i); else drawBadges(c, i);
    c.strokeStyle = skin === 'modern' ? 'rgba(0,0,0,.35)' : 'rgba(60,30,20,.55)'; c.lineWidth = 2; rr(c, 1, 1, 98, 158, 8); c.stroke();
    faceCache.set(key, cv);
    return cv;
  }
  function backImg(w, dpr) {
    const CB = (L.ui && L.ui.cardBack) ? L.ui.cardBack() : null;  // 설정 「카드 뒷면」(라운드 34) — 화투답게 단색 바탕 + 꽃잎 문양
    const key = 'b|' + Math.round(w * dpr) + '|' + (CB ? CB.id : '');
    let cv = faceCache.get(key);
    if (cv) return cv;
    cv = document.createElement('canvas');
    cv.width = Math.ceil(w * dpr); cv.height = Math.ceil(w * CR * dpr);
    const c = cv.getContext('2d');
    c.scale(cv.width / 100, cv.height / 160);
    const g = c.createLinearGradient(0, 0, 100, 160); g.addColorStop(0, CB ? CB.b : '#b3261c'); g.addColorStop(1, CB ? CB.a : '#7c140f');
    c.fillStyle = g; rr(c, 0, 0, 100, 160, 9); c.fill();
    const ln = CB ? CB.line : '#ffdcaa';
    c.globalAlpha = 0.4; c.strokeStyle = ln; c.lineWidth = 3; rr(c, 9, 9, 82, 142, 6); c.stroke();
    if (CB && CB.pat !== 'grid') { c.lineWidth = 1.2; c.globalAlpha = 0.22; for (let y = 22; y < 150; y += 22) { c.beginPath(); c.arc(50, y, 30, 0.15 * Math.PI, 0.85 * Math.PI); c.stroke(); } }
    c.globalAlpha = 0.3; c.fillStyle = ln; for (let k = 0; k < 4; k++) { c.save(); c.translate(50, 80); c.rotate(k * Math.PI / 2); c.beginPath(); c.ellipse(0, -14, 7, 14, 0, 0, 7); c.fill(); c.restore(); }
    c.globalAlpha = 1;
    faceCache.set(key, cv);
    return cv;
  }
  /* standalone canvas of one card for DOM sheets */
  function cardEl(i, w) {
    const dpr = Math.min(3, window.devicePixelRatio || 1);
    const src = faceImg(i, w, dpr);
    const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
    c.style.width = w + 'px'; c.style.height = w * CR + 'px'; c.style.borderRadius = '3px'; c.style.flex = 'none';
    c.getContext('2d').drawImage(src, 0, 0);
    return c;
  }

  /* ---------- score text ---------- */
  function parts(t) {
    const a = [];
    if (t.gw) a.push((t.g === 5 ? '오광' : t.g === 4 ? '사광' : t.rain ? '비삼광' : '삼광') + ' ' + t.gw);
    if (t.gd) a.push('고도리 5');
    if (t.dh) a.push('홍단 3'); if (t.dc) a.push('청단 3'); if (t.do) a.push('초단 3');
    if (t.ys) a.push('열끗 ' + t.ys); if (t.ts) a.push('띠 ' + t.ts); if (t.ps) a.push('피 ' + t.ps);
    return a;
  }
  const EVN = { P: '뻑!', J: '쪽!', T: '따닥!', S: '쓸!', B: '폭탄!', H: '흔들기!', E: '뻑 먹기!', Z: '자뻑!', N: '보너스 피', C: '총통!', 3: '3뻑!' };
  const EVSUB = { P: '못 먹고 3장이 바닥에', J: '피 1장씩 뺏기', T: '피 1장씩 뺏기', S: '바닥 싹쓸이 · 피 1장씩', B: '×2 · 피 1장씩', H: '이기면 ×2', E: '피 1장씩 뺏기', Z: '피 2장씩 뺏기', N: '바로 가져와요', C: '같은 달 4장 · 10점', 3: '한 판에 뻑 3번 · 10점' };

  /* ---------- rules ---------- */

  /* 규칙 그림(라운드 33): 광·띠·피 예시 */
  const FIG_HT = (x, kind) => {
    let in_ = '';
    if (kind === 'g') in_ = '<circle cx="24" cy="26" r="13" fill="#d3302a"/><text x="24" y="31" font-size="14" text-anchor="middle" fill="#fff" font-weight="700">光</text><path d="M4 62 Q24 44 44 62 L44 70 L4 70Z" fill="#2b2b3a"/>';
    else if (kind === 'r') in_ = '<rect x="10" y="12" width="12" height="44" fill="#d3302a"/><text x="16" y="40" font-size="9" text-anchor="middle" fill="#fff" writing-mode="tb">홍단</text><path d="M26 60 q8 -30 14 -40" stroke="#3a6b3a" stroke-width="4" fill="none"/>';
    else if (kind === 'b') in_ = '<rect x="10" y="12" width="12" height="44" fill="#2f5fc4"/><path d="M26 60 q8 -30 14 -40" stroke="#3a6b3a" stroke-width="4" fill="none"/>';
    else in_ = '<path d="M8 60 q10 -26 16 -44 M24 60 q6 -20 16 -36" stroke="#3a6b3a" stroke-width="3" fill="none"/><circle cx="36" cy="22" r="4" fill="#d3302a"/>';
    return '<g transform="translate(' + x + ',8)"><rect width="48" height="74" rx="5" fill="#efe5cf" stroke="#b52018" stroke-width="2"/>' + in_ + '</g>';
  };
  const FIG_HROW = (kinds, label) => '<svg viewBox="0 0 340 112" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif">' + kinds.map((k, i) => FIG_HT(170 - kinds.length * 28 + i * 56 + 4, k)).join('') + '<text x="170" y="104" font-size="14" text-anchor="middle" fill="#e3ae45" font-weight="700">' + label + '</text></svg>';
  const RULE_FIGS = [
    { svg: FIG_HROW(['g', 'g', 'g'], '광 3장 = 3점 (비광 끼면 2점)'), cap: '광: 빨간 동그라미에 「光」이 있는 패' },
    { svg: FIG_HROW(['r', 'r', 'r', 'b'], '띠: 홍단 3장 = 3점, 띠 5장부터 1점'), cap: '띠: 길쭉한 리본이 그려진 패' },
    { svg: FIG_HROW(['p', 'p', 'p', 'p', 'p'], '피: 10장부터 1점, 1장 늘 때마다 +1'), cap: '피: 그림만 있는 가장 흔한 패' },
  ];
  /* 규칙 화면 움직이는 예시(core demo, 라운드 50): 뻑 · 쪽 · 따닥 */
  const RULE_DEMOS = (() => {
    const C = (k, x, y, m, o) => Object.assign({ k, x, y, w: 30, h: 44, r: 4, fill: m ? '#f4efe4' : '#b8261d', stroke: '#5a1410', lw: 1.5, text: m ? m + '월' : '', ink: '#b8261d', size: 12 }, o || {});
    const T = (x, y, t) => ({ shape: 'text', x, y, text: t, ink: '#cfc6b0', size: 11, bold: false });
    const base = [T(120, 10, '바닥'), T(305, 10, '더미'), T(120, 76, '내 손패')];
    const deck = (o) => C('d', 290, 18, 0, o);
    const HL = { stroke: '#ffd34d', lw: 3 };
    const ppeok = { h: 150, cap: '뻑: 3장이 바닥에 남음', frames: [
      { say: '바닥에 3월 1장, 내 손에도 3월', items: base.concat([C('f', 105, 18, 3), C('x', 160, 18, 8), deck(), C('h', 105, 84, 3)]) },
      { say: '손패 3월을 바닥 3월에 짝 맞춰 냄', items: base.concat([C('f', 105, 18, 3), C('x', 160, 18, 8), deck(), C('h', 112, 24, 3)]) },
      { say: '더미를 뒤집었더니 또 3월!', items: base.concat([C('f', 105, 18, 3), C('x', 160, 18, 8), C('h', 112, 24, 3), C('d', 119, 30, 3)]) },
      { say: '같은 달 3장 → 못 가져가요 = 「뻑」', items: base.concat([C('f', 105, 18, 3, HL), C('x', 160, 18, 8), C('h', 112, 24, 3, HL), C('d', 119, 30, 3, HL), deck({ k: 'd2' })]) },
    ] };
    const jjok = { h: 150, cap: '쪽: 깔아 둔 패를 바로 가져옴', frames: [
      { say: '내 손 5월 — 바닥에 5월이 없어요', items: base.concat([C('x', 105, 18, 8), C('y', 145, 18, 11), deck(), C('h', 105, 84, 5)]) },
      { say: '짝이 없으니 바닥에 깔아요', items: base.concat([C('x', 105, 18, 8), C('y', 145, 18, 11), deck(), C('h', 195, 18, 5)]) },
      { say: '더미를 뒤집었더니 5월! 바로 짝', items: base.concat([C('x', 105, 18, 8), C('y', 145, 18, 11), C('h', 195, 18, 5), C('d', 202, 24, 5)]) },
      { say: '2장 가져오고 상대마다 피 1장 = 「쪽」', items: base.concat([C('x', 105, 18, 8), C('y', 145, 18, 11), deck({ k: 'd2' }), C('h', 230, 84, 5, HL), C('d', 262, 84, 5, HL), { shape: 'text', x: 305, y: 106, text: '+피', ink: '#ffd34d', size: 14 }]) },
    ] };
    const ttadak = { h: 150, cap: '따닥: 4장 모두 가져옴', frames: [
      { say: '바닥에 7월 2장, 내 손에 7월', items: base.concat([C('a', 105, 18, 7), C('b', 140, 18, 7), deck(), C('h', 105, 84, 7)]) },
      { say: '손패 7월을 바닥 7월에 냄', items: base.concat([C('a', 105, 18, 7), C('b', 140, 18, 7), deck(), C('h', 122, 26, 7)]) },
      { say: '더미를 뒤집었더니 또 7월!', items: base.concat([C('a', 105, 18, 7), C('b', 140, 18, 7), C('h', 122, 26, 7), C('d', 130, 32, 7)]) },
      { say: '4장 모두 가져오고 피 1장씩 = 「따닥」', items: base.concat([deck({ k: 'd2' }), C('a', 170, 84, 7, HL), C('b', 202, 84, 7, HL), C('h', 234, 84, 7, HL), C('d', 266, 84, 7, HL), { shape: 'text', x: 316, y: 106, text: '+피', ink: '#ffd34d', size: 14 }]) },
    ] };
    return [ppeok, jjok, ttadak];
  })();
  const RULES = [
    { h: '그림으로 보기 — 광 · 띠 · 피', fig: RULE_FIGS },
    { h: '목표', p: [
      '같은 달(같은 그림) 화투끼리 짝을 맞춰 가져와요.',
      '가져온 패로 족보 점수를 만들어요. 기준점을 넘기면 「고」 또는 「스톱」을 골라요.',
      '2명이면 「맞고」(7점부터 날 수 있음), 3명이면 「고스톱」(3점부터).',
      '정한 판 수(1·3·5판)가 끝났을 때 누적 점수가 가장 높은 사람이 우승!'] },
    { h: '화투 읽는 법', p: [
      '화투는 1월~12월, 달마다 4장씩 모두 48장이에요.',
      '패 종류는 4가지: 광(光) · 열끗(그림 동물) · 띠(리본) · 피(나머지 흔한 패).',
      '카드 왼쪽 위 표시: 숫자 = 달, 光 = 광, 끗 = 열끗(초록 = 고도리 새), 띠 = 띠(빨강 홍단 · 파랑 청단 · 주황 초단), 쌍 = 쌍피.',
      '쌍피는 피 2장으로 세요(11월·12월에 한 장씩). 보너스 피는 2장 또는 3장으로 세요.',
      '「족보」 화면에서 화투 그림을 「전통」/「모던」으로 바꿀 수 있어요(이 기기에 저장). 모던은 아래 띠에 종류(광·열끗·띠·쌍피·피)가 크게 써 있어요.'] },
    { h: '준비 (자동으로 해 줘요)', p: [
      '맞고(2명): 한 사람 10장, 바닥 8장. 고스톱(3명): 한 사람 7장, 바닥 6장. 나머지는 가운데 더미.',
      '설정의 「보너스 피」: 2장(보너스 쌍피 1 · 쓰리피 1, 기본) / 3장(쌍피 2 · 쓰리피 1) / 없음.',
      '바닥에 같은 달 4장이 깔리면 다시 섞어요. 바닥에 보너스 피가 깔리면 선이 가져가고 한 장 더 깔아요.',
      '첫 판 선(먼저 하는 사람)은 무작위, 그다음은 이긴 사람이 선이에요(나가리면 그대로).'] },
    { h: '차례에 할 일', p: [
      '① 손패 1장을 내요. 바닥에 같은 달 패가 있으면 그 위에 놓여 짝이 돼요.',
      '② 더미 맨 위 1장이 자동으로 뒤집혀요. 바닥에 같은 달이 있으면 또 짝이 돼요.',
      '③ 짝이 된 패는 모두 내 것으로 가져와요. 짝이 없는 패는 바닥에 그냥 깔려요.',
      '④ 가져온 패로 점수가 기준점(맞고 7점, 고스톱 3점) 이상이 되면 「고」/「스톱」을 골라요.',
      '바닥에 같은 달이 2장 있으면 둘 중 하나를 골라 가져와요. 3장 있으면(누가 싼 뻑) 4장 모두 가져와요.',
      '보너스 피를 내면 바로 내 것이 되고, 더미에서 1장 받아 차례를 이어가요.'] },
    { h: '점수 (족보)', p: [
      '광: 3장 3점(비광이 끼면 2점) · 4장 4점 · 5장 15점.',
      '열끗: 5장 1점, 그 뒤 1장마다 +1점.',
      '고도리: 2월·4월·8월의 새 3장 = 5점.',
      '띠: 5장 1점, 그 뒤 1장마다 +1점.',
      '홍단(1·2·3월 붉은 띠) 3점 · 청단(6·9·10월 파란 띠) 3점 · 초단(4·5·7월 붉은 띠) 3점.',
      '피: 10장 1점, 그 뒤 1장마다 +1점(쌍피는 2장으로).',
      '국진(9월 열끗): 기본 「유리하게 자동」 — 열끗과 쌍피 중 점수가 더 높은 쪽으로 세요. 설정에서 열끗만/쌍피만으로 고정할 수 있어요.',
      '게임 중 가운데 「족보」 버튼으로 점수표를 바로 볼 수 있어요.'] },
    { h: '고 · 스톱', p: [
      '처음으로 기준점 이상이 되면 고/스톱을 골라요.',
      '스톱: 판이 끝나고 지금 점수를 받아요.',
      '고: 판을 계속해서 점수를 더 키워요. 고를 한 뒤에는 점수가 더 올라야 다시 고/스톱을 고를 수 있어요.',
      '고 보너스: 1고 +1점, 2고 +2점, 3고부터는 (점수 + 고 수)에 ×2, 4고 ×4, 5고 ×8…',
      '위험: 고를 했는데 남이 먼저 나면 「고박」이에요(아래 박).',
      '손패가 다 떨어진 마지막 차례에 점수가 나면 자동으로 스톱이에요.'] },
    { h: '박 (진 사람이 2배로 내요)', p: [
      '피박: 이긴 사람이 피로 점수를 냈는데, 진 사람 피가 5장 이하(0장 포함) → ×2.',
      '광박: 이긴 사람이 광으로 점수를 냈는데, 진 사람 광이 0장 → ×2.',
      '고박: 맞고에서 고를 했던 사람이 지면 ×2. 고스톱(3명)에서는 고를 했던 사람이 다른 진 사람 몫까지 모두 내요(독박).',
      '멍박(설정, 기본 끔): 이긴 사람 열끗이 7장 이상이면 ×2.',
      '박은 겹쳐요. 예: 피박 + 광박 = ×4.'] },
    { h: '특수 규칙 ① 피 뺏기', demo: RULE_DEMOS, p: [
      '쪽: 낸 패가 짝이 없어 깔렸는데, 뒤집은 패가 바로 그 달 → 2장 가져오고 상대마다 피 1장씩 뺏어요.',
      '따닥: 바닥 같은 달 2장에 내 패를 냈는데 뒤집은 패도 그 달 → 4장 모두 가져오고 피 1장씩.',
      '뻑: 바닥 1장에 짝을 맞췄는데 뒤집은 패도 같은 달 → 3장 모두 바닥에 남아요(못 가져가요).',
      '뻑 먹기: 남이 싼 뻑 3장을 가져오면 피 1장씩. 자뻑(내가 싼 뻑을 내가 먹기)은 피 2장씩.',
      '쓸: 내 차례에 바닥 패를 싹 다 가져오면 피 1장씩(마지막 차례는 제외).',
      '피를 뺏을 때는 상대의 가장 싼 피(일반 피 먼저)를 가져와요. 국진은 뺏기지 않아요.'] },
    { h: '특수 규칙 ② 흔들기 · 폭탄 · 총통 · 3뻑', p: [
      '흔들기: 같은 달 3장을 들고 있고 바닥에 그 달이 없을 때, 낼 때 「흔들고 내기」를 고를 수 있어요 → 이기면 ×2.',
      '폭탄: 같은 달 3장을 들고 있고 바닥에 그 달이 1장 → 3장을 한꺼번에 내서 4장 모두 가져와요. 피 1장씩 뺏고, 이기면 ×2.',
      '폭탄 뒤에는 손패가 2장 적으니, 다음 2번은 손패 대신 「더미만 뒤집기」를 할 수 있어요.',
      '흔들기·폭탄은 할 때마다 ×2가 겹쳐요.',
      '총통: 처음 받은 패에 같은 달 4장 → 바로 승리(10점).',
      '3뻑: 한 판에 뻑을 3번 싸면 그 자리에서 승리(10점).'] },
    { h: '판이 끝나면', p: [
      '진 사람마다 계산한 점수만큼 이긴 사람에게 줘요(진 사람 점수는 그만큼 줄어요).',
      '나가리: 아무도 못 나고 패가 다 떨어지면 무효 → 다음 판 점수가 ×2(연속이면 계속 ×2). 나가리는 판 수에 세지 않아요(최대 4번까지 다시).',
      '정한 판 수가 끝나면 누적 점수 1등이 우승이에요.'] },
    { h: '조작', p: [
      '내 패를 탭하면 고르고, 한 번 더 탭하거나 「내기」를 누르면 내요. 「취소」로 다시 고를 수 있어요.',
      '금색으로 빛나는 내 패 = 바닥과 짝이 맞는 패예요.',
      '바닥에 같은 달이 2장(종류가 다를 때)이면 가져올 패를 버튼이나 바닥에서 직접 골라요.',
      '흔들기·폭탄이 가능하면 버튼이 따로 떠요.',
      '사람 이름표(가져온 패 칸)를 탭하면 그 사람 점수 내역을 볼 수 있어요. 「족보」는 점수표예요.',
      '한 폰으로 여럿이 하면 차례마다 가림막이 떠요. 다른 사람 패는 뒷면만 보여요.'] },
    { h: '예시 ① 한 차례', p: [
      '바닥에 3월 벚꽃 피가 있고, 내 손에 3월 벚꽃 광이 있어요(금색으로 빛나요).',
      '→ 벚꽃 광을 내면 바닥 벚꽃 피와 짝! 이어서 더미에서 7월 홍싸리가 뒤집혔는데 바닥에 7월 패가 있으면 그것도 짝!',
      '→ 이번 차례에 4장(광 1 · 피 1 · 7월 2장)을 가져와요.'] },
    { h: '예시 ② 점수 계산 (맞고)', p: [
      '내가 가져온 패: 광 3장(비광 없음) 3점 + 피 12장 3점 + 띠 5장 1점 = 7점 → 맞고 기준 7점!',
      '「고」를 한 번 하고, 점수가 8점이 됐을 때 「스톱」 → 8 + 1고 보너스 1 = 9점.',
      '상대 피는 4장(피박 ×2), 광은 1장(광박 아님) → 9 × 2 = 18점을 받아요.',
      '흔들기를 1번 했다면 ×2가 더 붙어 36점이에요.',
      '3고였다면: 점수 6점 → (6 + 3) × 2 = 18점.'] },
    { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
  ];

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    let st = null, G = null, bg = null, dirty = true, busy = false, holdUntil = 0;
    let flies = [], sel = '', hits = [], lastId = -1, waitSeq = -1, waitUntil = 0;
    let anim = null, banners = [], shk = null, booms = [];
    /* 큰 장면 연출: 세기(1~3), 자체 WebAudio 효과음(× L.audio.sfx), 화면 흔들림(× L.fx), 진동 */
    const BIG = { H: 2, B: 3, P: 2, J: 1, T: 2, S: 3, E: 2, Z: 2, C: 3, 3: 3, go: 2, stop: 2 };
    let ac = null;
    function slamSnd(lv, kind) {
      const v = L.audio && L.audio.sfx ? L.audio.sfx() : 1;
      if (v <= 0) return;
      try {
        if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)();
        if (ac.state === 'suspended') ac.resume();
        const t = ac.currentTime, out = ac.createGain(); out.gain.value = 0.5 * v; out.connect(ac.destination);
        // 패 내리치는 '탁' (짧은 잡음 + 낮은 쿵)
        const n = Math.floor(ac.sampleRate * 0.09), buf = ac.createBuffer(1, n, ac.sampleRate), d = buf.getChannelData(0);
        for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 3);
        const ns = ac.createBufferSource(); ns.buffer = buf;
        const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1800; bp.Q.value = 0.8;
        const ng = ac.createGain(); ng.gain.value = 0.6 + lv * 0.2; ns.connect(bp); bp.connect(ng); ng.connect(out); ns.start(t);
        const o = ac.createOscillator(), og = ac.createGain(); o.type = 'sine';
        o.frequency.setValueAtTime(150 + lv * 10, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.18);
        og.gain.setValueAtTime(0.5 + lv * 0.2, t); og.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
        o.connect(og); og.connect(out); o.start(t); o.stop(t + 0.25);
        // 상황별 꼬리음: 좋은 일=밝게 올라감, 뻑=낮게 내려감, 흔들기=떨림
        const tones = kind === 'P' || kind === 'Z' ? [330, 247] : kind === 'H' ? [440, 466, 440, 466] : kind === 'stop' ? [523, 659, 784] : kind === 'go' ? [392, 523] : lv >= 3 ? [523, 659, 784, 1047] : [587, 784];
        tones.forEach((f, k) => {
          const q = ac.createOscillator(), g = ac.createGain(), t1 = t + 0.07 + k * (kind === 'H' ? 0.05 : 0.08);
          q.type = 'triangle'; q.frequency.value = f; g.gain.setValueAtTime(0.0001, t1); g.gain.exponentialRampToValueAtTime(0.22, t1 + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t1 + 0.16);
          q.connect(g); g.connect(out); q.start(t1); q.stop(t1 + 0.2);
        });
      } catch (e) { /* 소리 실패는 무시 */ }
    }
    function boom(b) {
      const lv = b.lv || 1, fx = L.fx ? L.fx() : 1;
      if (fx > 0) shk = { t0: performance.now(), dur: 180 + lv * 70, amp: (2 + lv * 2.2) * fx };
      booms.push({ t0: performance.now(), dur: 420, lv, col: b.col });
      slamSnd(lv, b.c);
      if (b.mine) { if (L.haptic) L.haptic('hit', lv >= 3 ? [30, 40, 50] : 20 + lv * 10); else api.buzz(20 + lv * 10); }
    }
    const spd = () => L.debug.speed || 1;
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    const bar = L.h('div', { style: { position: 'absolute', left: '8px', right: '8px', display: 'none', gap: '6px', zIndex: 6 } });
    const jokboBtn = L.h('button', { 'data-action': 'jokbo', class: 'btn sm', style: { position: 'absolute', zIndex: 5, minHeight: '40px', minWidth: '52px', padding: '4px 10px', fontSize: '13px', fontWeight: 700, background: 'rgba(23,19,31,.85)' }, 'aria-label': '족보 보기', text: '족보', onclick: () => openJokbo() });
    let sheet = null, sheetKind = '';
    jokboBtn.classList.add('gs-jokbo'); bar.classList.add('gs-bar');
    root.append(bar, jokboBtn);
    /* invisible boxes over canvas regions — spotlight targets for the first-play tutorial */
    const anc = {};
    function anchor(cls, x, y, w, h) {
      let el = anc[cls];
      if (!el) { el = anc[cls] = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', visibility: 'hidden' } }); root.append(el); }
      Object.assign(el.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    }

    function vwr() { return api.viewer(); }
    function bottomSeat() {
      const v = vwr();
      if (v >= 0) return v;
      const mine = api.mySeats();
      return mine.length ? mine[0] : 0;
    }
    function myTurnSeat() { return st && (st.ph === 'p' || st.ph === 'f' || st.ph === 'g') && api.canAct(st.t) && vwr() === st.t ? st.t : -1; }
    function locked() { return st && st.seq === waitSeq && performance.now() < waitUntil; }
    function send(a, seat) {
      if (locked() || busy) return;
      waitSeq = st.seq; waitUntil = performance.now() + (api.online ? 3000 : 400);
      api.actAs(seat != null ? seat : st.t, a);
      sel = '';
    }
    const others = () => { const b = bottomSeat(), o = []; for (let k = 1; k < st.n; k++) o.push((b + k) % st.n); return o; };

    function geometry() {
      const W = cv.w, H = cv.h;
      const pad = 8;
      const cw = Math.round(U.clamp(W * 0.12, 40, 54));
      const ch = cw * CR;
      const handH = ch + 22;
      const handY = H - handH;
      const myH = H < 660 ? 70 : 78;
      const myY = handY - myH - 2;
      const opH = H < 660 ? 70 : 78;
      const fy0 = pad + opH + 6, fy1 = myY - 6;
      const colW = (W - pad * 2) / 5, rowH = (fy1 - fy0) / 3;
      const fc = Math.round(Math.min(56, colW - 24, (rowH - 14) / CR));
      G = { W, H, pad, cw, ch, handH, handY, myH, myY, opH, fy0, fy1, colW, rowH, fc };
      jokboBtn.style.left = (pad + colW + 4) + 'px';
      jokboBtn.style.top = (fy0 + rowH * 1.5 - 20) + 'px';
      if (st) {
        anchor('gs-hand', pad, handY + 6, W - pad * 2, handH - 8);
        anchor('gs-floor', 9, fy0 - 2, W - 18, fy1 - fy0 + 4);
        const d = deckXY(); anchor('gs-deck', d.x - 4, d.y - 4, G.fc + 8, G.fc * CR + 22);
        const mr = panelRect(bottomSeat()); anchor('gs-mine', mr.x, mr.y, mr.w, mr.h);
        anchor('gs-opp', pad, pad, W - pad * 2, opH);
      }
    }
    function buildBg() {
      const W = cv.w, H = cv.h, dpr = cv.dpr;
      const c = document.createElement('canvas'); c.width = Math.ceil(W * dpr); c.height = Math.ceil(H * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      // 군용 담요 느낌의 진한 초록 펠트 + 나무 테두리
      const FT = (L.ui && L.ui.felt) ? L.ui.felt() : { c: ['#24806a', '#1c6650', '#0c3528'], rail: ['#7a4a24', '#3f230f'], line: 'rgba(227,174,69,.45)' };
      const wg = x.createLinearGradient(0, 0, W, H); wg.addColorStop(0, FT.rail[0]); wg.addColorStop(1, FT.rail[1]);
      x.fillStyle = wg; rr(x, 3, G.fy0 - 8, W - 6, G.fy1 - G.fy0 + 16, 18); x.fill();
      const fg = x.createRadialGradient(W / 2, (G.fy0 + G.fy1) / 2, 20, W / 2, (G.fy0 + G.fy1) / 2, Math.max(W, H) * 0.6);
      fg.addColorStop(0, FT.c[0]); fg.addColorStop(0.7, FT.c[1]); fg.addColorStop(1, FT.c[2]);
      x.fillStyle = fg; rr(x, 9, G.fy0 - 2, W - 18, G.fy1 - G.fy0 + 4, 13); x.fill();
      x.save(); rr(x, 9, G.fy0 - 2, W - 18, G.fy1 - G.fy0 + 4, 13); x.clip();
      for (let k = 0; k < 900; k++) { x.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.06)'; x.fillRect(Math.random() * W, G.fy0 + Math.random() * (G.fy1 - G.fy0), 1.2, 1.2); }
      x.restore();
      x.strokeStyle = 'rgba(227,174,69,.4)'; x.lineWidth = 1; rr(x, 9, G.fy0 - 2, W - 18, G.fy1 - G.fy0 + 4, 13); x.stroke();
      // month slot hints
      x.font = '600 10px ' + MONO; x.textAlign = 'center'; x.textBaseline = 'middle';
      for (let m = 0; m < 12; m++) { const p = slotPos(m); x.fillStyle = 'rgba(242,233,216,.07)'; rr(x, p.x - 2, p.y - 2, G.fc + 4, G.fc * CR + 4, 5); x.fill(); x.fillStyle = 'rgba(242,233,216,.2)'; x.fillText((m + 1) + '월', p.x + G.fc / 2, p.y + G.fc * CR / 2); }
      bg = c;
    }
    cv.onresize = () => { if (!st) return; geometry(); buildBg(); dirty = true; };
    const onFelt = () => { if (!st || !G) return; buildBg(); dirty = true; }; window.addEventListener('lounge-felt', onFelt); const onRC = (e) => { if (sel) { sel = ''; renderBar(); dirty = true; e.preventDefault(); } }; window.addEventListener('lounge-cancel', onRC); window.addEventListener('lounge-cardback', onFelt); window.addEventListener('lounge-contrast', onFelt);  // 오른쪽 클릭 = 선택 해제, 카드 뒷면 바뀜(라운드 34)

    /* fixed slot per month: row 0 = 1–5월, row 1 = 6월 (left) · 7월 (right), row 2 = 8–12월 */
    function slotCell(m) { if (m < 5) return [0, m]; if (m === 5) return [1, 0]; if (m === 6) return [1, 4]; return [2, m - 7]; }
    function slotPos(m) {
      const [r, c] = slotCell(m);
      const cx = G.pad + G.colW * (c + 0.5), cy = G.fy0 + G.rowH * (r + 0.5);
      return { x: Math.round(cx - G.fc / 2), y: Math.round(cy - G.fc * CR / 2) };
    }
    function stackPos(m, k, cnt) {
      const p = slotPos(m), d = Math.max(1, cnt - 1);
      const ox = Math.min(G.fc * 0.2, (G.colW - G.fc - 6) / d), oy = Math.min(6, Math.max(0, G.rowH - G.fc * CR - 6) / d);
      return { x: p.x - ox * (cnt - 1) / 2 + k * ox, y: p.y - oy * (cnt - 1) / 2 + k * oy };
    }
    const deckXY = () => ({ x: G.W / 2 - G.fc / 2, y: G.fy0 + G.rowH * 1.5 - G.fc * CR / 2 });

    /* pile panels */
    function panelRect(seat) {
      const b = bottomSeat();
      if (seat === b) return { x: G.pad, y: G.myY, w: G.W - G.pad * 2, h: G.myH, me: 1 };
      const os = others(), k = os.indexOf(seat);
      if (st.n === 2) return { x: G.pad, y: G.pad, w: G.W - G.pad * 2, h: G.opH };
      const w = (G.W - G.pad * 2 - 6) / 2;
      return { x: G.pad + k * (w + 6), y: G.pad, w, h: G.opH };
    }
    const GT = [0, 1, 2, 3]; // group order: 광 열끗 띠 피
    function groupOf(i) { if (i === GUK) return st && st.o.gk === 'p' ? 3 : 1; return typeOf(i); }
    function pileLayout(seat, hide) {
      const r = panelRect(seat);
      const mw = r.me ? 21 : st.n === 3 ? 15 : 18, mh = mw * CR;
      const gy = r.y + 22;
      const gx0 = r.x + 6, gw = (r.w - 12) / 4;
      const cards = pileArr(st.c[seat]).filter((i) => !(hide && hide.has(cc(i))));
      const groups = [[], [], [], []];
      for (const i of cards) groups[groupOf(i)].push(i);
      groups.forEach((g) => g.sort((a, b2) => a - b2));
      const out = [];
      groups.forEach((g, gi) => {
        const n = g.length, room = gw - mw - 16;
        const step = n > 1 ? Math.min(mw * 0.5, room / (n - 1)) : 0;
        g.forEach((i, k) => out.push({ i, x: gx0 + gi * gw + k * step, y: gy, w: mw }));
      });
      return { r, groups, out, mw, mh, gy, gx0, gw };
    }
    function pileTarget(seat, i) {
      const pl = pileLayout(seat);
      const g = groupOf(i), n = pl.groups[g].length;
      const room = pl.gw - pl.mw - 16, step = n > 1 ? Math.min(pl.mw * 0.5, room / (n - 1)) : 0;
      return { x: pl.gx0 + g * pl.gw + Math.max(0, n - 1) * step, y: pl.gy, w: pl.mw };
    }

    function handLayout(seat, s) {
      s = s || st;
      const cards = s.h[seat].split('').map(ci).sort((a, b2) => (a >= 48 ? 99 : a) - (b2 >= 48 ? 99 : b2));
      const n = cards.length, cw = G.cw, out = [];
      if (!n) return out;
      const avail = G.W - 16 - cw;
      const step = n > 1 ? Math.min(cw * 0.98, avail / (n - 1)) : 0;
      const tot = step * (n - 1) + cw, x0 = (G.W - tot) / 2;
      cards.forEach((i, k) => { const off = (k - (n - 1) / 2) / Math.max(1, n); out.push({ i, x: x0 + k * step, y: G.handY + 14 + Math.abs(off) * 8, rot: off * 0.14, w: cw, step, last: k === n - 1 }); });
      return out;
    }
    function oppHandPos(seat) { const r = panelRect(seat); return { x: r.x + r.w - 40, y: r.y + 4, w: 16 }; }

    function drawCard(x, y, w, i, up, rot, sx, glow) {
      const h = w * CR;
      ctx.save();
      ctx.translate(x + w / 2, y + h / 2);
      if (rot) ctx.rotate(rot);
      if (sx != null) ctx.scale(Math.max(0.03, Math.abs(sx)), 1);
      if (glow) { ctx.shadowColor = glow; ctx.shadowBlur = 14; } else { ctx.shadowColor = 'rgba(0,0,0,.4)'; ctx.shadowBlur = w > 30 ? 5 : 2; ctx.shadowOffsetY = 1.5; }
      ctx.fillStyle = glow || '#000'; rr(ctx, -w / 2, -h / 2, w, h, w * 0.08); ctx.fill();
      ctx.shadowColor = 'transparent';
      const img = up && i >= 0 && !(sx != null && sx < 0) ? faceImg(i, w, cv.dpr) : backImg(w, cv.dpr);
      ctx.drawImage(img, -w / 2, -h / 2, w, h);
      ctx.restore();
    }
    function tag(x, y, text, bgc, fg, font, h) {
      ctx.font = font || '600 12px ' + FONT;
      h = h || 20;
      const tw = ctx.measureText(text).width + 14;
      ctx.fillStyle = bgc; rr(ctx, x - tw / 2, y - h / 2, tw, h, h / 2); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, x, y + 1);
      return tw;
    }
    function clip(t, w) {
      if (ctx.measureText(t).width <= w) return t;
      while (t.length > 1 && ctx.measureText(t + '…').width > w) t = t.slice(0, -1);
      return t + '…';
    }

    /* floor cards shown right now (during an animation: previous floor + cards that already landed) */
    function dispFloor(now) {
      if (anim && now < anim.tcap) {
        let f = anim.prevDisp;
        for (const [ch, t] of anim.land) if (now >= t && f.indexOf(ch) < 0) f += ch;
        return f;
      }
      return st.f + st.tk + st.fp;
    }
    function draw(now) {
      cv.clear();
      let sx = 0, sy = 0;
      if (shk) { const p = (now - shk.t0) / shk.dur; if (p >= 1) shk = null; else { const a = shk.amp * (1 - p); sx = (Math.random() - 0.5) * 2 * a; sy = (Math.random() - 0.5) * 2 * a; } }
      ctx.save(); ctx.translate(sx, sy);
      try { draw0(now); } finally { ctx.restore(); }
    }
    function draw0(now) {
      if (!G || !st) return;
      if (bg) ctx.drawImage(bg, 0, 0, G.W, G.H);
      hits = [];
      const flying = new Set(flies.filter((f) => now < f.t0 + f.dur && now >= f.t0 - 1e9).map((f) => f.ch));
      const ts = myTurnSeat();
      const active = ts >= 0 && !busy && !locked();
      // floor
      const fl = dispFloor(now).split('');
      const byM = {};
      for (const ch of fl) { const m = monthOf(ci(ch)); (byM[m] = byM[m] || []).push(ch); }
      let hl = new Set();
      if (active && st.ph === 'p' && sel) { const F = floorOf(st, monthOf(ci(sel))); if (F.length === 2 && !same(ci(F[0]), ci(F[1]))) F.forEach((x) => hl.add(x)); else F.forEach((x) => hl.add(x)); }
      if (active && st.ph === 'f') floorOf(st, monthOf(ci(st.fp))).forEach((x) => hl.add(x));
      const pulse = 0.5 + 0.5 * Math.sin(now / 180);
      for (const k in byM) {
        const m = +k, cards = byM[m];
        cards.forEach((ch, j) => {
          if (flying.has(ch)) return;
          const p = stackPos(m, j, cards.length);
          const isFp = st.fp === ch && (!anim || now >= anim.tcap);
          const glow = hl.has(ch) ? 'rgba(255,214,110,' + (0.6 + 0.4 * pulse) + ')' : isFp ? 'rgba(238,106,85,.95)' : null;
          drawCard(p.x, p.y - (hl.has(ch) ? 3 : 0), G.fc, ci(ch), true, 0, null, glow);
          if (hl.has(ch)) hits.push({ k: 'f', ch, x: p.x, y: p.y - 3, w: G.fc, h: G.fc * CR });
        });
        if (st.bb[m] !== '-' && cards.length >= 3) { const p = slotPos(m); tag(p.x + G.fc / 2 + 6, p.y + G.fc * CR + 2, '뻑 · ' + st.nm[+st.bb[m]], 'rgba(238,106,85,.92)', '#2b0c06', '700 10px ' + FONT, 16); }
      }
      // deck + center info
      const d = deckXY(), dn = st.d.length;
      for (let k = Math.min(4, Math.ceil(dn / 6)) - 1; k >= 0; k--) drawCard(d.x - k * 1.2, d.y - k * 1.5, G.fc, -1, false);
      if (!dn) { ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.setLineDash([4, 4]); rr(ctx, d.x, d.y, G.fc, G.fc * CR, 5); ctx.stroke(); ctx.setLineDash([]); }
      tag(d.x + G.fc / 2, d.y + G.fc * CR + 10, dn + '장', 'rgba(15,12,20,.8)', '#f2e9d8', '600 11px ' + MONO, 18);
      if (active && st.ph === 'p' && st.bt[ts] > 0 && dn) hits.push({ k: 'deck', x: d.x - 6, y: d.y - 6, w: G.fc + 12, h: G.fc * CR + 12 });
      const rx = G.pad + G.colW * 3.5 + 6;
      const cy = G.fy0 + G.rowH * 1.5;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 12px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.75)';
      L.ui.strokeText(ctx, st.o.g > 1 ? st.gi + ' / ' + st.o.g + '판' : '단판', rx, cy - 12);
      ctx.font = '600 11px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.5)';
      L.ui.strokeText(ctx, (st.n === 2 ? '맞고 ' : '고스톱 ') + thr(st) + '점', rx, cy + 4);
      if (st.mul > 1) tag(rx, cy + 22, '나가리 ×' + st.mul, '#ee6a55', '#2b0c06', '700 11px ' + FONT, 18);
      // panels
      for (let s = 0; s < st.n; s++) drawPanel(s, now);
      drawHand(now, flying, active);
      // flies
      for (const f of flies) {
        const p = (now - f.t0) / f.dur;
        if (p < 0 || p > 1) continue;
        const e = 1 - Math.pow(1 - p, 3);
        const x = U.lerp(f.x0, f.x1, e), y = U.lerp(f.y0, f.y1, e) - Math.sin(p * Math.PI) * (f.arc || 16), w = U.lerp(f.w0, f.w1, e) * (f.slam ? 1 + 0.4 * Math.sin(Math.min(1, p * 1.25) * Math.PI) : 1);
        drawCard(x, y, w, ci(f.ch), f.up, (1 - e) * (f.rot || 0), f.flip ? Math.cos(Math.PI * (1 - Math.min(1, p * 1.6))) * -1 : null);
      }
      // hint
      const hn = hintText();
      if (hn && bar.style.display === 'none') { ctx.font = '600 12.5px ' + FONT; tag(G.W / 2, G.myY - 12, clip(hn, G.W - 40), 'rgba(16,12,22,.82)', '#f2e9d8', '600 12.5px ' + FONT); }
      // banners
      const cyB = (G.fy0 + G.fy1) / 2 - 6;
      for (const o of booms) {
        const p = (now - o.t0) / o.dur;
        if (p < 0 || p > 1) continue;
        const fx = L.fx ? L.fx() : 1;
        ctx.save(); ctx.globalAlpha = (1 - p) * 0.75; ctx.strokeStyle = o.col || '#e3ae45'; ctx.lineWidth = 3 + o.lv;
        ctx.beginPath(); ctx.arc(G.W / 2, cyB, 30 + p * (70 + o.lv * 30), 0, Math.PI * 2); ctx.stroke();
        if (o.lv >= 2) { ctx.lineWidth = 2; for (let k = 0; k < 10; k++) { const a = k / 10 * Math.PI * 2 + 0.3, r0 = 50 + p * 60, r1 = r0 + 18 + o.lv * 6; ctx.beginPath(); ctx.moveTo(G.W / 2 + Math.cos(a) * r0, cyB + Math.sin(a) * r0 * 0.7); ctx.lineTo(G.W / 2 + Math.cos(a) * r1, cyB + Math.sin(a) * r1 * 0.7); ctx.stroke(); } }
        if (o.lv >= 3 && p < 0.25 && fx > 0) { ctx.globalAlpha = (0.25 - p) * 0.9 * fx; ctx.fillStyle = '#fff3d6'; ctx.fillRect(0, 0, G.W, G.H); }
        ctx.restore();
      }
      for (const b of banners) {
        const p = (now - b.t0) / b.dur;
        if (p < 0 || p > 1) continue;
        // 큰 장면: 위에서 크게 내리찍듯 (2.2배 → 1배), 보통: 살짝 튀어나옴
        const sc = b.lv ? (p < 0.12 ? 2.2 - p / 0.12 * 1.3 : p < 0.2 ? 0.9 + (p - 0.12) / 0.08 * 0.1 : 1) : p < 0.15 ? 0.6 + p / 0.15 * 0.5 : p < 0.25 ? 1.1 - (p - 0.15) : 1;
        ctx.save(); ctx.globalAlpha = p > 0.8 ? (1 - p) / 0.2 : 1;
        ctx.translate(G.W / 2, (G.fy0 + G.fy1) / 2 - 6); ctx.scale(sc, sc);
        ctx.font = (b.lv >= 3 ? 50 : b.lv ? 46 : 40) + 'px ' + DISP; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const tw = Math.max(ctx.measureText(b.t).width, b.sub ? 150 : 0) + 40;
        ctx.fillStyle = 'rgba(16,10,14,.86)'; rr(ctx, -tw / 2, -34, tw, b.sub ? 82 : 66, 16); ctx.fill();
        ctx.strokeStyle = b.col || '#e3ae45'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = b.col || '#e3ae45'; L.ui.strokeText(ctx, b.t, 0, -2);
        if (b.sub) { ctx.font = '600 13px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.fillText(b.sub, 0, 32); }
        ctx.restore();
      }
    }
    function drawPanel(seat, now) {
      const pl = pileLayout(seat, anim && anim.hide && now < anim.tend ? new Set([...anim.hide].filter(([ch, t]) => now < t).map(([ch]) => ch)) : null);
      const r = pl.r, p = api.players[seat] || { name: st.nm[seat], color: '#888' };
      const turn = (st.ph === 'p' || st.ph === 'f' || st.ph === 'g') && st.t === seat;
      ctx.save();
      if (turn) { ctx.shadowColor = 'rgba(227,174,69,.55)'; ctx.shadowBlur = 12; }
      ctx.fillStyle = turn ? 'rgba(46,38,64,.97)' : 'rgba(26,20,34,.92)'; rr(ctx, r.x, r.y, r.w, r.h, 12); ctx.fill();
      ctx.restore();
      ctx.lineWidth = turn ? 1.8 : 1; ctx.strokeStyle = turn ? '#e3ae45' : 'rgba(242,233,216,.12)'; rr(ctx, r.x, r.y, r.w, r.h, 12); ctx.stroke();
      const t = tallyBest(pileArr(st.c[seat]), st.o.gk);
      // header
      circ(ctx, r.x + 11, r.y + 11, 4.5, p.color);
      ctx.font = '700 12.5px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      const nm = clip(p.name, r.w * (r.me ? 0.3 : 0.36));
      L.ui.strokeText(ctx, nm, r.x + 20, r.y + 11.5);
      let tx = r.x + 24 + ctx.measureText(nm).width;
      const tags = [];
      if (!r.me) tags.push(['패 ' + st.h[seat].length, 'rgba(242,233,216,.14)', '#f2e9d8']);
      if (st.go[seat]) tags.push([st.go[seat] + '고', '#e3ae45', '#2a1d05']);
      if (st.sh[seat]) tags.push(['×' + Math.pow(2, st.sh[seat]), '#ee6a55', '#2b0c06']);
      if (st.pk[seat]) tags.push(['뻑' + st.pk[seat], 'rgba(238,106,85,.3)', '#ffb4a6']);
      if (st.bt[seat]) tags.push(['뒤집기' + st.bt[seat], 'rgba(242,233,216,.14)', '#f2e9d8']);
      ctx.font = '700 10px ' + FONT;
      for (const [txt, b2, fg] of tags) { const w = ctx.measureText(txt).width + 10; if (tx + w > r.x + r.w - 58) break; tag(tx + w / 2, r.y + 11.5, txt, b2, fg, '700 10px ' + FONT, 15); tx += w + 3; }
      // score
      ctx.font = '700 15px ' + MONO; ctx.textAlign = 'right'; ctx.fillStyle = t.tot >= thr(st) ? '#e3ae45' : '#f2e9d8';
      L.ui.strokeText(ctx, t.tot + '점', r.x + r.w - 8, r.y + 11.5);
      if (st.o.g > 1 || st.sc.some((v) => v)) { ctx.font = '600 10px ' + MONO; ctx.fillStyle = 'rgba(242,233,216,.55)'; ctx.fillText('누적 ' + (st.sc[seat] > 0 ? '+' : '') + st.sc[seat], r.x + r.w - 8, r.y + r.h - 8); }
      // groups
      const cnts = [t.g, t.y, t.t, t.p];
      const lab = ['광', '끗', '띠', '피'];
      for (let g = 0; g < 4; g++) {
        const gx = pl.gx0 + g * pl.gw;
        if (!pl.groups[g].length) { ctx.strokeStyle = 'rgba(242,233,216,.12)'; ctx.setLineDash([3, 3]); rr(ctx, gx, pl.gy, pl.mw, pl.mh, 3); ctx.stroke(); ctx.setLineDash([]); }
        const nTxt = String(cnts[g]);
        ctx.font = '700 ' + (r.me ? 13 : 11) + 'px ' + MONO; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        const lastX = pl.groups[g].length ? pl.out.filter((o) => groupOf(o.i) === g).reduce((a, o) => Math.max(a, o.x), gx) + pl.mw : gx + pl.mw;
        ctx.fillStyle = cnts[g] ? '#f2e9d8' : 'rgba(242,233,216,.35)';
        ctx.fillText(nTxt, Math.min(lastX + 3, gx + pl.gw - 12), pl.gy + pl.mh / 2 - 6);
        ctx.font = '600 9px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.5)';
        ctx.fillText(lab[g], Math.min(lastX + 3, gx + pl.gw - 12), pl.gy + pl.mh / 2 + 7);
      }
      for (const o of pl.out) drawCard(o.x, o.y, pl.mw, o.i, true);
      // breakdown line
      const pr = parts(t);
      const room = r.w - 16 - (st.o.g > 1 || st.sc.some((v) => v) ? 60 : 0);
      ctx.font = '600 10px ' + FONT; ctx.textAlign = 'left'; ctx.fillStyle = pr.length ? '#e3ae45' : 'rgba(242,233,216,.4)';
      ctx.fillText(clip(pr.length ? pr.join(' · ') : '아직 점수 없음', room), r.x + 8, r.y + r.h - 8);
      hits.push({ k: 'panel', seat, x: r.x, y: r.y, w: r.w, h: r.h, low: 1 });
    }
    function drawHand(now, flying, active) {
      const b = bottomSeat(), up = b === vwr();
      const lay = handLayout(b);
      const hideH = anim && anim.hand && now < anim.hand[1] ? anim.hand[0] : '';
      const canPlay = active && st.ph === 'p' && st.t === b;
      for (const c of lay) {
        const ch = cc(c.i);
        if (flying.has(ch) || ch === hideH) continue;
        const m = monthOf(c.i), match = canPlay && (c.i >= 48 || floorOf(st, m).length > 0);
        let lift = match ? 7 : 0;
        if (sel === ch) lift = 22;
        const y = c.y - lift;
        drawCard(c.x, y, c.w, c.i, up, c.rot, null, sel === ch ? '#e3ae45' : match ? 'rgba(255,214,110,.75)' : null);
        if (canPlay) hits.push({ k: 'h', ch, x: c.x, y: y - 4, w: c.last ? c.w : Math.max(c.step, 12), h: c.w * CR + 4 + lift });
      }
      if (!up && lay.length) { ctx.font = '600 11px ' + FONT; tag(G.W / 2, G.handY + 8, (api.players[b] ? api.players[b].name : '') + ' 패 ' + lay.length + '장', 'rgba(16,12,22,.8)', '#d9cfe4', '600 11px ' + FONT, 18); }
    }
    function hintText() {
      if (!st) return '';
      const ts = myTurnSeat();
      if (ts < 0 || busy) return '';
      if (st.ph === 'f') return '뒤집은 ' + cardName(ci(st.fp)) + ' · 가져올 바닥 패를 탭하세요';
      if (st.ph !== 'p') return '';
      if (sel) return '';
      if (st.bt[ts] > 0 && !st.h[ts].length) return '더미를 탭해서 뒤집어요';
      if (st.h[ts].split('').some((ch) => ci(ch) >= 48)) return '보너스 피는 내면 바로 가져오고 1장 더 받아요';
      const any = st.h[ts].split('').some((ch) => floorOf(st, monthOf(ci(ch))).length);
      return any ? '빛나는 패는 바닥과 짝이 맞아요 · 낼 패를 탭하세요' : '짝 맞는 패가 없어요 · 1장을 바닥에 내세요';
    }

    /* ---------- input ---------- */
    function onDown(e) {
      if (!st || !G || sheet) return;
      const q = cv.local(e);
      for (let k = hits.length - 1; k >= 0; k--) {
        const h = hits[k];
        if (h.low) continue;
        if (q.x >= h.x && q.x <= h.x + h.w && q.y >= h.y && q.y <= h.y + h.h) { onHit(h); return; }
      }
      for (const h of hits) if (h.low && q.x >= h.x && q.x <= h.x + h.w && q.y >= h.y && q.y <= h.y + h.h) { openBreakdown(h.seat); return; }
      if (sel) { sel = ''; renderBar(); dirty = true; }
    }
    function onHit(h) {
      if (busy || locked()) return;
      if (h.k === 'h') return tapCard(h.ch);
      if (h.k === 'deck') { api.sfx('card'); api.buzz(10); send({ t: 'pass' }); return; }
      if (h.k === 'f') {
        if (st.ph === 'f') { api.sfx('card'); api.buzz(12); send({ t: 'pick', p: h.ch }); return; }
        if (sel) { const F = floorOf(st, monthOf(ci(sel))); if (F.length === 2) { api.sfx('card'); api.buzz(12); send({ t: 'play', c: sel, p: h.ch }); renderBar(); } else playSel(); }
      }
    }
    function choices(ch) { // what can be done with this hand card
      const ts = st.t, i = ci(ch);
      if (i >= 48) return { plain: 1 };
      const m = monthOf(i), F = floorOf(st, m), hc = handOf(st, ts, m).length;
      return { plain: 1, two: F.length === 2 && !same(ci(F[0]), ci(F[1])) ? F : null, shake: hc === 3 && F.length === 0, bomb: hc === 3 && F.length === 1, m };
    }
    function tapCard(ch) {
      if (sel === ch) { const c = choices(ch); if (!c.two && !c.shake && !c.bomb) { playSel(); return; } }
      sel = ch; api.sfx('tick'); api.buzz(6);
      renderBar(); dirty = true;
    }
    function playSel(extra) {
      if (!sel || myTurnSeat() < 0) return;
      const c = choices(sel);
      if (c.two && !(extra && extra.p)) return;
      api.sfx('card'); api.buzz(12);
      send(Object.assign({ t: 'play', c: sel }, extra || {}));
      renderBar(); dirty = true;
    }

    /* ---------- action bar & sheets ---------- */
    const B = (txt, cls, fn, extra) => L.h('button', { class: 'btn ' + (cls || ''), style: Object.assign({ flex: '1 1 0', minWidth: 0, minHeight: '48px', padding: '6px 6px', whiteSpace: 'nowrap', fontSize: '14px', overflow: 'hidden', textOverflow: 'ellipsis' }, extra || {}), onclick: fn }, txt);
    function shortName(i) { const t = typeOf(i); if (i === GUK) return '국진'; if (t === 0) return i === RAIN ? '비광' : '광'; if (t === 1) return BIRDS.includes(i) ? '고도리' : '열끗'; if (t === 2) return DAN.h.includes(i) ? '홍단' : DAN.c.includes(i) ? '청단' : DAN.o.includes(i) ? '초단' : '띠'; return piVal(i) >= 2 ? '쌍피' : '피'; }
    function renderBar() {
      bar.innerHTML = ''; bar.style.display = 'none';
      if (!st || !G) return;
      bar.style.top = (G.myY + 6) + 'px';
      const ts = myTurnSeat();
      if (ts < 0 || busy) return;
      const off = locked();
      const show = () => { bar.style.display = 'flex'; };
      if (st.ph === 'f') {
        floorOf(st, monthOf(ci(st.fp))).forEach((ch) => { const b = B(shortName(ci(ch)) + ' 가져오기', 'primary', () => { api.sfx('card'); send({ t: 'pick', p: ch }); }); b.disabled = off; bar.append(b); });
        show(); return;
      }
      if (st.ph !== 'p') return;
      if (sel) {
        const c = choices(sel);
        if (c.two) c.two.forEach((ch) => { const b = B(shortName(ci(ch)) + ' 가져오기', 'primary', () => playSel({ p: ch })); b.disabled = off; bar.append(b); });
        else if (c.bomb) {
          bar.append(B('폭탄! (3장 내기)', 'danger', () => { api.sfx('hit'); api.buzz(25); send({ t: 'bomb', m: c.m }); renderBar(); }));
          bar.append(B('1장만 내기', '', () => playSel()));
        } else if (c.shake) {
          bar.append(B('흔들고 내기 ×2', 'danger', () => playSel({ sh: 1 })));
          bar.append(B('그냥 내기', '', () => playSel()));
        } else bar.append(B('내기 · ' + shortName(ci(sel)), 'primary', () => playSel()));
        bar.append(B('취소', 'ghost', () => { sel = ''; api.sfx('click'); renderBar(); dirty = true; }, { flex: '0 0 60px' }));
        [...bar.children].forEach((b) => { if (off) b.disabled = true; });
        show(); return;
      }
      if (st.bt[ts] > 0 && st.d.length) { bar.append(B('더미만 뒤집기 (폭탄 후 ' + st.bt[ts] + '번)', st.h[ts].length ? '' : 'primary', () => { api.sfx('card'); send({ t: 'pass' }); })); show(); }
    }
    function closeSheet() { if (sheet) { sheet.remove(); sheet = null; sheetKind = ''; } }
    function openSheet(kind, inner, tap) {
      closeSheet();
      sheetKind = kind;
      sheet = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'flex', alignItems: kind === 'go' || kind === 'round' ? 'flex-end' : 'center', justifyContent: 'center', padding: '10px', background: 'rgba(10,8,15,.55)' }, onclick: tap ? (e) => { if (e.target === sheet || tap === 'any') { api.sfx('click'); closeSheet(); } } : null },
        L.h('div', { class: 'panel', style: { width: '100%', maxWidth: '400px', maxHeight: '100%', overflowY: 'auto', padding: '14px', display: 'flex', flexDirection: 'column', gap: '8px', background: 'var(--surface)', borderRadius: '16px', border: '1px solid rgba(242,233,216,.12)' } }, inner));
      root.append(sheet);
    }
    function row(a, b, c) {
      return L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', padding: '3px 0', borderBottom: '1px solid rgba(242,233,216,.06)' } },
        L.h('div', { style: { minWidth: '76px', fontWeight: 700 } }, a),
        L.h('div', { style: { display: 'flex', gap: '2px', flexWrap: 'wrap', flex: '1' } }, b || []),
        L.h('div', { style: { color: 'var(--brass)', fontWeight: 700, whiteSpace: 'nowrap', textAlign: 'right' } }, c));
    }
    function openJokbo() {
      api.sfx('click');
      if (sheetKind === 'jokbo') { closeSheet(); return; }
      const cs = (arr) => arr.map((i) => cardEl(i, 20));
      const sub = (t) => L.h('div', { class: 'label', style: { marginTop: '6px' }, text: t });
      openSheet('jokbo', [
        L.h('div', { style: { display: 'flex', alignItems: 'center' } }, L.h('b', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '19px' }, text: '족보' }),
          L.h('span', { class: 'muted', style: { marginLeft: 'auto', fontSize: '11px' }, text: '아무 데나 누르면 닫혀요' })),
        L.h('div', { style: { display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px' } }, [L.h('b', { text: '화투 그림' })].concat(
          [['classic', '전통'], ['modern', '모던']].map(([v, lb]) => L.h('button', { class: 'btn sm' + (skin === v ? ' primary' : ''), style: { minHeight: '44px', minWidth: '64px' }, text: lb, 'aria-pressed': skin === v ? 'true' : 'false',
            onclick: (e) => { e.stopPropagation(); if (skin !== v) { setSkin(v); faceCache.clear(); dirty = true; } sheetKind = ''; openJokbo(); } })),
          [L.h('span', { class: 'muted', style: { fontSize: '11px' }, text: '이 기기에 저장' })])),
        sub('광'),
        row('광 5장', cs(GWANGS), '15점'), row('광 4장', null, '4점'), row('광 3장', null, '3점'), row('비광 낀 3장', cs([RAIN]), '2점'),
        sub('열끗 · 띠 · 피'),
        row('고도리', cs(BIRDS), '5점'),
        row('홍단', cs(DAN.h), '3점'), row('청단', cs(DAN.c), '3점'), row('초단', cs(DAN.o), '3점'),
        row('열끗 5장', null, '1점 (+1/장)'), row('띠 5장', null, '1점 (+1/장)'),
        row('피 10장', cs([41, 47].concat(st && st.o.bn ? [48] : []).concat(st && st.o.bn >= 3 ? [49] : [])), '1점 (+1/장)'),
        L.h('div', { class: 'muted', style: { fontSize: '12px' }, text: '쌍피·보너스 피는 2장(보너스 3은 3장)으로 세요. 국진: ' + (st && st.o.gk === 'y' ? '열끗으로만' : st && st.o.gk === 'p' ? '쌍피로만' : '열끗/쌍피 중 유리하게 자동') + '.' }),
        sub('나기 · 고'),
        L.h('div', { style: { fontSize: '13px', lineHeight: 1.45 } }, (st && st.n === 3 ? '3점' : '7점') + '부터 고/스톱 · 1고 +1 · 2고 +2 · 3고 ×2 · 4고 ×4 …'),
        sub('2배 되는 것'),
        L.h('div', { style: { fontSize: '13px', lineHeight: 1.45 } }, '흔들기·폭탄 ×2(할 때마다) · 피박(피 5장 이하) · 광박(광 0장) · 고박' + (st && st.o.mb ? ' · 멍박(열끗 7장↑)' : '') + ' · 나가리 다음 판 ×2'),
        sub('피 뺏기'),
        L.h('div', { style: { fontSize: '13px', lineHeight: 1.45 } }, '쪽·따닥·쓸·폭탄·뻑 먹기 → 1장씩 · 자뻑 → 2장씩'),
      ], 'any');
    }
    function openBreakdown(seat) {
      api.sfx('click');
      const t = tallyBest(pileArr(st.c[seat]), st.o.gk);
      const pr = parts(t);
      const cards = pileArr(st.c[seat]).sort((a, b2) => groupOf(a) - groupOf(b2) || a - b2);
      openSheet('brk', [
        L.h('b', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '19px' }, text: st.nm[seat] + ' · ' + t.tot + '점' }),
        L.h('div', { style: { fontSize: '13px', lineHeight: 1.5 } }, '광 ' + t.g + '장 · 열끗 ' + t.y + '장 · 띠 ' + t.t + '장 · 피 ' + t.p + '장(쌍피 포함)' + (t.gp ? ' · 국진은 쌍피로' : '')),
        L.h('div', { style: { fontSize: '14px', color: 'var(--brass)', fontWeight: 700 } }, pr.length ? pr.join(' + ') + ' = ' + t.tot + '점' : '아직 점수가 없어요'),
        L.h('div', { style: { fontSize: '12px', color: 'var(--muted)' } }, [st.go[seat] ? st.go[seat] + '고' : '', st.sh[seat] ? '흔들기/폭탄 ' + st.sh[seat] + '번(×' + Math.pow(2, st.sh[seat]) + ')' : '', st.pk[seat] ? '뻑 ' + st.pk[seat] + '번' : ''].filter(Boolean).join(' · ') || ' '),
        L.h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '3px' } }, cards.map((i) => cardEl(i, 24))),
        L.h('span', { class: 'muted', style: { fontSize: '11px', textAlign: 'center' }, text: '눌러서 닫기' }),
      ], 'any');
    }
    function goSheet() {
      const seat = st.t, t = score(st, seat);
      const sim = settle(clone(st), seat, 's');
      let gain = 0; for (let l = 0; l < st.n; l++) gain += sim.pay[l];
      const ng = st.go[seat] + 1;
      const fx = [];
      for (let l = 0; l < st.n; l++) if (l !== seat && sim.fx[l]) fx.push(st.nm[l] + ' ' + sim.fx[l].split('').map((x) => ({ p: '피박', g: '광박', o: '고박' }[x])).join('·'));
      const btnS = { flex: '1 1 0', minHeight: '64px', fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '26px', borderRadius: '14px' };
      openSheet('go', [
        L.h('div', { style: { display: 'flex', alignItems: 'baseline', gap: '8px' } },
          L.h('b', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '22px' }, text: t.tot + '점 났어요!' }),
          L.h('span', { class: 'muted', style: { fontSize: '12px' }, text: parts(t).join(' · ') })),
        L.h('div', { style: { fontSize: '13px', lineHeight: 1.5 } },
          L.h('div', null, '스톱하면 지금 ', L.h('b', { style: { color: 'var(--brass)' }, text: '+' + gain + '점' }), ' 받고 이 판을 끝내요' + (fx.length ? ' (' + fx.join(', ') + ')' : '') + '.'),
          L.h('div', { class: 'muted' }, '고하면 ' + ng + '고 (' + (ng === 1 ? '+1점' : ng === 2 ? '+2점' : '×' + Math.pow(2, ng - 2)) + ') · 점수가 더 나야 다시 고/스톱 · 남이 먼저 나면 고박!')),
        L.h('div', { style: { display: 'flex', gap: '10px' } },
          L.h('button', { class: 'btn danger', 'data-action': 'go', style: btnS, onclick: () => { api.buzz(30); closeSheet(); send({ t: 'go' }); } }, '고!'),
          L.h('button', { class: 'btn primary', 'data-action': 'stop', style: btnS, onclick: () => { api.buzz(30); closeSheet(); send({ t: 'stop' }); } }, '스톱')),
      ]);
    }
    function roundSheet() {
      const r = st.rr;
      const items = [];
      const title = r.k === 'n' ? '나가리!' : st.nm[r.w] + (r.k === 'c' ? ' 총통!' : r.k === '3' ? ' 3뻑!' : ' 스톱!');
      items.push(L.h('div', { class: 'label', text: (st.o.g > 1 ? st.gi + '/' + st.o.g + '판 결과' : '판 결과') }));
      items.push(L.h('b', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '26px' }, text: title }));
      if (r.k === 'n') items.push(L.h('div', { style: { fontSize: '14px' } }, '아무도 나지 못했어요. 다음 판 점수 ×' + r.next + '!'));
      else {
        const t = r.k === 's' ? score(st, r.w) : null;
        let calc = r.k === 's' ? (parts(t).join(' + ') + ' = ' + r.b + '점') : '10점';
        if (r.go) calc += ' · ' + r.go + '고 → ' + r.pts + '점';
        items.push(L.h('div', { style: { fontSize: '13px', lineHeight: 1.5 } }, calc));
        const mults = [];
        if (r.mul > 1) mults.push('나가리 ×' + r.mul);
        if (r.sh) mults.push((r.sh > 1 ? '흔들기·폭탄 ' + r.sh + '번' : '흔들기/폭탄') + ' ×' + Math.pow(2, r.sh));
        if (r.mb) mults.push('멍박 ×2');
        if (mults.length) items.push(L.h('div', { style: { fontSize: '13px', color: 'var(--coral)' } }, mults.join(' · ')));
        for (let l = 0; l < st.n; l++) {
          if (l === r.w) continue;
          const fx = (r.fx[l] || '').split('').filter(Boolean).map((x) => ({ p: '피박', g: '광박', o: r.dok === l ? '고박(독박)' : '고박' }[x]));
          items.push(row(st.nm[l], fx.length ? [L.h('span', { style: { color: 'var(--coral)', fontSize: '12px' }, text: fx.join(' · ') })] : null, '−' + r.pay[l]));
        }
        items.push(row(st.nm[r.w], null, '+' + r.tot));
      }
      items.push(L.h('div', { class: 'muted', style: { fontSize: '12px' } }, '누적: ' + st.sc.map((v, i) => st.nm[i] + ' ' + (v > 0 ? '+' : '') + v).join(' · ')));
      const humans = api.mySeats();
      if (humans.length) items.push(L.h('button', { class: 'btn primary', 'data-action': 'next', style: { minHeight: '52px', fontSize: '16px' }, onclick: () => { api.sfx('click'); waitSeq = st.seq; waitUntil = performance.now() + 3000; api.actAs(humans[0], { t: 'next' }); } }, '다음 판'));
      else items.push(L.h('div', { class: 'muted', style: { fontSize: '12px', textAlign: 'center' } }, '곧 다음 판을 시작해요'));
      openSheet('round', items);
    }
    function syncSheets() {
      if (!st) return;
      if (st.ph === 'g' && myTurnSeat() >= 0 && !busy) { if (sheetKind !== 'go') goSheet(); }
      else if (sheetKind === 'go') closeSheet();
      if (st.ph === 'r' && !busy) { if (sheetKind !== 'round') roundSheet(); }
      else if (sheetKind === 'round') closeSheet();
    }

    /* ---------- animation ---------- */
    function animate(prev, next) {
      const l = next.last, now = performance.now(), sp = spd();
      if (!l || l.id === lastId) return;
      flies = []; banners = []; booms = []; anim = null;
      let t = now;
      const evs = [];
      if (l.k === 'deal') {
        // floor cards fly out of the deck
        const d = deckXY();
        const f = next.f.split('');
        const cnt = {};
        f.forEach((ch, k) => { const m = monthOf(ci(ch)); const j = cnt[m] = (cnt[m] || 0); cnt[m]++; const p = stackPos(m, j, j + 1); flies.push({ ch, up: true, x0: d.x, y0: d.y, w0: G.fc, x1: p.x, y1: p.y, w1: G.fc, t0: t + k * 50 / sp, dur: 240 / sp }); });
        t += (f.length * 50 + 260) / sp;
        if (l.ev === 'C') evs.push(['C', l.s]);
        api.sfx('whoosh');
      } else if (l.k === 'p' || l.k === 'b' || l.k === 'x' || l.k === 'k' || l.k === 'n') {
        const prevDisp = prev.f + prev.tk + prev.fp;
        const land = new Map();
        const b = bottomSeat();
        const fromHand = (ch) => {
          if (prev.h[l.s].indexOf(ch) < 0) return null;
          if (l.s === b) { const c = handLayout(b, prev).find((x) => cc(x.i) === ch); if (c) return { x: c.x, y: c.y, w: c.w }; }
          return oppHandPos(l.s);
        };
        // where would a card sit on the floor (in the merged display)
        const slotFor = (ch, disp) => { const m = monthOf(ci(ch)); const arr = disp.split('').filter((x) => monthOf(ci(x)) === m); const j = arr.indexOf(ch); return stackPos(m, j < 0 ? arr.length : j, Math.max(arr.length, j + 1)); };
        let disp = prevDisp;
        const showUp = (seat) => true;
        if (l.k === 'n') {
          const o = fromHand(l.c) || oppHandPos(l.s), tg = pileTarget(l.s, ci(l.c));
          flies.push({ ch: l.c, up: true, x0: o.x, y0: o.y, w0: o.w, x1: tg.x, y1: tg.y, w1: tg.w, t0: t, dur: 300 / sp });
          t += 320 / sp;
          if (l.dr && l.s === b) { const nc = next.h[l.s].split('').find((ch) => prev.h[l.s].indexOf(ch) < 0); if (nc) { const d = deckXY(), c = handLayout(b).find((x) => cc(x.i) === nc); if (c) flies.push({ ch: nc, up: vwr() === b, x0: d.x, y0: d.y, w0: G.fc, x1: c.x, y1: c.y, w1: c.w, t0: t, dur: 260 / sp }); t += 280 / sp; } }
          anim = { tcap: 0, prevDisp, land, hide: new Map([[l.c, now + 320 / sp]]), tend: t };
          evs.push(['N', l.s]);
        } else {
          const slam = /[BHPJTSEZ]/.test(l.ev || '');
          if (l.c && (l.k === 'p' || l.k === 'b')) {
            l.c.split('').forEach((ch, k) => {
              const o = fromHand(ch) || oppHandPos(l.s);
              disp += ch;
              const p = slotFor(ch, disp);
              flies.push({ ch, up: showUp(l.s), x0: o.x, y0: o.y, w0: o.w, x1: p.x, y1: p.y, w1: G.fc, t0: t + k * 70 / sp, dur: (slam ? 300 : 260) / sp, rot: slam ? 0.5 : 0.3, arc: slam ? 46 : 16, slam });
              land.set(ch, t + (k * 70 + 260) / sp);
            });
            t += (l.c.length * 70 + 280) / sp;
          }
          if (l.fl) {
            const d = deckXY();
            l.fl.split('').forEach((ch) => {
              const i = ci(ch);
              if (i >= 48) { const tg = pileTarget(l.s, i); flies.push({ ch, up: true, flip: 1, x0: d.x, y0: d.y, w0: G.fc, x1: tg.x, y1: tg.y, w1: tg.w, t0: t, dur: 340 / sp }); t += 360 / sp; return; }
              disp += ch;
              const p = slotFor(ch, disp);
              flies.push({ ch, up: true, flip: 1, x0: d.x, y0: d.y, w0: G.fc, x1: p.x, y1: p.y, w1: G.fc, t0: t, dur: 320 / sp, arc: 26 });
              land.set(ch, t + 320 / sp);
              t += 360 / sp;
            });
          }
          const tcap = t + 140 / sp;
          const hide = new Map();
          // captures: from their floor slot (in the merged display) to the pile
          const capCards = l.cap.split('').filter((ch) => ci(ch) < 48 || prevDisp.indexOf(ch) >= 0 || l.fl.indexOf(ch) < 0);
          const caps = capCards.filter((ch) => !(ci(ch) >= 48 && l.fl.indexOf(ch) >= 0));
          caps.forEach((ch, k) => {
            const p = disp.indexOf(ch) >= 0 ? slotFor(ch, disp) : deckXY();
            const tg = pileTarget(l.s, ci(ch));
            flies.push({ ch, up: true, x0: p.x, y0: p.y, w0: G.fc, x1: tg.x, y1: tg.y, w1: tg.w, t0: tcap + k * 35 / sp, dur: 300 / sp, arc: 8 });
            hide.set(ch, tcap + (k * 35 + 300) / sp);
          });
          l.fl.split('').filter((ch) => ci(ch) >= 48).forEach((ch) => hide.set(ch, tcap));
          t = tcap + (caps.length ? caps.length * 35 + 320 : 0) / sp;
          // steals
          for (let k = 0; k < l.st.length; k += 2) {
            const o = +l.st[k], ch = l.st[k + 1];
            const src = pileTarget(o, ci(ch)), tg = pileTarget(l.s, ci(ch));
            flies.push({ ch, up: true, x0: src.x, y0: src.y, w0: src.w, x1: tg.x, y1: tg.y, w1: tg.w, t0: t + (k / 2) * 80 / sp, dur: 340 / sp, arc: 30 });
            hide.set(ch, t + ((k / 2) * 80 + 340) / sp);
          }
          if (l.st.length) t += (l.st.length / 2 * 80 + 360) / sp;
          anim = { tcap, prevDisp, land, hide, tend: t };
          for (const c of l.ev || '') if (c !== 'N' || l.k !== 'n') evs.push([c, l.s]);
          if (l.st.length) evs.push(['steal', l.s, l.st.length / 2]);
        }
      } else if (l.k === 'g') { evs.push(['go', l.s, l.n]); }
      else if (l.k === 's') { evs.push(['stop', l.s]); }
      if (next.rr && next.ph !== 'p' && prev.ph !== 'r' && prev.ph !== 'x' && next.rr.k === 'n') evs.push(['nagari']);
      // banners
      let bt = Math.max(now, (anim ? anim.tcap : now) - 200 / sp);
      const seen = new Set();
      for (const e of evs) {
        const [c, s, n] = e;
        if (c === 'N' && seen.has('N')) continue;
        seen.add(c);
        let b = null;
        if (c === 'go') b = { t: n + '고!', sub: st.nm[s], col: '#ee6a55' };
        else if (c === 'stop') b = { t: '스톱!', sub: st.nm[s], col: '#e3ae45' };
        else if (c === 'nagari') b = { t: '나가리', sub: '다음 판 ×' + next.mul, col: '#c9b8e0' };
        else if (c === 'steal') b = { t: '피 뺏기', sub: st.nm[s] + (next.n > 2 ? ' · 1인당 ' : ' · ') + Math.round(n / (next.n - 1)) + '장', col: '#e3ae45' };
        else if (EVN[c]) b = { t: EVN[c], sub: EVSUB[c], col: c === 'P' ? '#ee6a55' : '#e3ae45' };
        if (!b) continue;
        if (c === 'steal' && seen.has('stealx')) continue;
        if (BIG[c]) { b.lv = BIG[c]; b.c = c; b.mine = api.canAct(s); }
        b.t0 = bt; b.dur = (b.lv ? 900 : 820) / sp; banners.push(b); bt += (b.lv ? 680 : 620) / sp;
        if (c === 'steal') seen.add('stealx');
      }
      t = Math.max(t, bt);
      if (anim) anim.tend = t;
      if (t > now) { holdUntil = Math.max(holdUntil, t); setBusy(true); }
    }
    function feedback(prev, next) {
      const l = next.last;
      if (!l || l.id === lastId) return;
      const ev = l.ev || '';
      if (l.k === 'p' || l.k === 'b' || l.k === 'x' || l.k === 'k') {
        api.sfx(l.cap ? 'chip' : 'card');
      } else if (l.k === 's') { api.sfx('win'); }
      else if (l.k === 'deal') api.sfx('whoosh');
      if (next.ph === 'r' && prev.ph !== 'r' && next.rr && next.rr.k === 'n') api.sfx('lose');
      // 이 기기 사람이 이긴 판: 한 판 최고 점수(받은 돈 점수) 기록
      if (next.rr && !(prev && prev.rr) && next.rr.k !== 'n' && next.rr.tot > 0 && api.canAct(next.rr.w) && api.best &&
        api.best('round', next.rr.tot, { label: '한 판 최고 점수', unit: '점' })) setTimeout(() => api.toast('🏆 새 최고 기록! ' + next.rr.tot + '점'), 900 / spd());
    }
    function frame() {
      const now = performance.now();
      for (const b of banners) if (b.lv && !b.fired && now >= b.t0) { b.fired = 1; boom(b); }
      if (booms.length && booms.every((o) => now > o.t0 + o.dur)) booms = [];
      const live = flies.some((f) => now < f.t0 + f.dur) || banners.some((b) => now < b.t0 + b.dur) || booms.length || shk;
      if (!live && flies.length) { flies = []; }
      if (busy && now >= holdUntil) { setBusy(false); anim = null; banners = []; renderBar(); syncSheets(); dirty = true; }
      const pulsing = st && myTurnSeat() >= 0 && (sel || st.ph === 'f');
      if (live || dirty || busy || pulsing) { draw(now); dirty = false; }
    }
    cv.cv.addEventListener('pointerdown', onDown);
    const stopLoop = U.loop(frame);
    const wd = setInterval(() => { if (busy && performance.now() > holdUntil + 800 / spd()) { flies = []; banners = []; anim = null; setBusy(false); renderBar(); syncSheets(); dirty = true; } }, 300);
    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down') return;
      const b = [...document.querySelectorAll('[data-action="' + id + '"]')].find((x) => !x.disabled && x.getClientRects().length);
      if (b) b.click();
    }) : null;
    const noFocus = (e) => { const b = e.target && e.target.closest && e.target.closest('button[data-action]'); if (b) e.preventDefault(); };   // 마우스로 누른 버튼에 포커스가 남아 Space/Enter 단축키를 가로채지 않게
    document.addEventListener('mousedown', noFocus, true);
    return {
      update(next, prev) {
        const isNew = prev && prev !== next;
        st = next;
        geometry();
        if (!bg || !prev) buildBg();
        if (isNew) { animate(prev, next); feedback(prev, next); }
        lastId = next.last ? next.last.id : -1;
        if (isNew && prev.seq !== next.seq) { sel = ''; waitSeq = -1; }
        if (prev && prev !== next && prev.dn !== next.dn) buildBg();
        if (sel && (myTurnSeat() < 0 || next.h[next.t].indexOf(sel) < 0)) sel = '';
        if (sheetKind === 'brk' || sheetKind === 'jokbo') { /* keep open */ } else if (isNew) closeSheet();
        renderBar();
        syncSheets();
        dirty = true;
      },
      destroy() { if (offKeys) offKeys(); document.removeEventListener('mousedown', noFocus, true); window.removeEventListener('lounge-felt', onFelt); window.removeEventListener('lounge-cancel', onRC); window.removeEventListener('lounge-cardback', onFelt); window.removeEventListener('lounge-contrast', onFelt); try { if (ac) ac.close(); } catch (e) {} stopLoop(); clearInterval(wd); setBusy(false); cv.cv.removeEventListener('pointerdown', onDown); cv.destroy(); bar.remove(); jokboBtn.remove(); Object.values(anc).forEach((el) => el.remove()); closeSheet(); },
    };
  }

  L.register({
    id: 'gostop', name: '고스톱', tag: '화투', cat: '카드', hidden: true,
    blurb: '같은 달 화투를 맞춰 먹고 족보로 점수를 내요. 점수가 나면 고(더!) 또는 스톱(끝!). 둘이면 맞고, 셋이면 고스톱.',
    controls: [
      { id: 'go', label: '고!', keys: ['KeyG'], pad: ['x'] },
      { id: 'stop', label: '스톱', keys: ['KeyS'], pad: ['b'] },
      { id: 'next', label: '다음 판', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'jokbo', label: '족보 보기', keys: ['KeyJ'], pad: ['y'] },
    ],
    minPlayers: 2, maxPlayers: 3, defaultPlayers: 2, aiDelay: 800,
    icon: '<rect x="7" y="12" width="22" height="34" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-12 18 29)"/><rect x="25" y="9" width="24" height="38" rx="3" fill="currentColor"/><circle cx="37" cy="21" r="6" fill="#7a1f1a"/><path d="M29 41 q8 -11 16 0 z" fill="#7a1f1a"/>',
    tint: '#7a1f1a',
    options: [
      { id: 'games', label: '판 수 (점수 누적)', tip: '여러 판 점수를 더해 순위를 정해요.', choices: [{ v: 1, label: '1판' }, { v: 3, label: '3판' }, { v: 5, label: '5판' }], def: 3 },
      { id: 'bonus', label: '보너스 피', tip: '덱에 넣을 보너스 피 장 수(받으면 바로 피에 더해요).', choices: [{ v: 0, label: '없음' }, { v: 2, label: '2장' }, { v: 3, label: '3장' }], def: 2 },
      { id: 'guk', label: '국진(9월 열끗)', tip: '9월 국진(열끗)을 열끗으로 셀지 쌍피로 셀지.', choices: [{ v: 'a', label: '유리하게 자동', tip: '나에게 더 유리한 쪽으로 자동.' }, { v: 'y', label: '열끗만' }, { v: 'p', label: '쌍피만' }], def: 'a' },
      { id: 'meong', label: '멍박(열끗 7장↑ ×2)', tip: '열끗을 7장 이상 모아 나면 점수 두 배.', choices: [{ v: 'off', label: '끔' }, { v: 'on', label: '켬' }], def: 'off' },
    ],
    quick: [
      '같은 달(같은 그림) 화투끼리 짝을 맞춰 가져오고, 가져온 패로 족보 점수를 모아요.',
      '내 차례: 손패 1장 내기 → 더미 1장 자동 뒤집기. 바닥에 같은 달이 있으면 짝 맞춰 가져와요.',
      '맞고 7점(3명은 3점)을 넘기면 「고」(더 크게) 또는 「스톱」(점수 받기). 판이 다 끝나면 누적 점수 1등이 우승!',
    ],
    rules: RULES,
    tutorial: [
      { sel: '.gs-hand', text: '아래가 내 손패예요. 화투는 1월~12월, 달마다 4장. 카드 왼쪽 위 숫자가 「달」이고, 같은 달끼리 짝이 맞아요.' },
      { sel: '.gs-floor', text: '가운데는 바닥이에요. 달마다 놓이는 자리가 정해져 있어요(희미한 「N월」 칸).' },
      { sel: '.gs-hand', text: '내 차례: 낼 패를 탭하고 한 번 더 탭(또는 「내기」)! 금색으로 빛나는 패는 바닥과 짝이 맞아서 가져올 수 있어요.' },
      { sel: '.gs-deck', text: '패를 내면 이 더미에서 1장이 자동으로 뒤집혀요. 이 패도 바닥에 같은 달이 있으면 또 가져와요.' },
      { sel: '.gs-mine', text: '가져온 패는 여기 쌓여요: 광 · 열끗 · 띠 · 피 순서. 예: 피 10장 = 1점, 광 3장 = 3점, 띠 5장 = 1점.' },
      { sel: '.gs-jokbo', text: '점수표가 궁금하면 「족보」를 누르세요. 이름표(가져온 패 칸)를 탭하면 그 사람 점수 내역이 나와요.' },
      { sel: '.gs-opp', text: '맞고는 7점(3명이면 3점)이 되면 「고」 또는 「스톱」! 고를 하면 점수가 커지지만, 상대가 먼저 나면 고박(×2)이에요.' },
      { text: '쪽 · 따닥 · 뻑 · 쓸 같은 특별한 일은 화면에 크게 떠요. 자세한 규칙과 점수 계산 예시는 위 「?」에 있어요. 시작해 볼까요?' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount, hint,
    _t: { ALPH, ci, cc, monthOf, typeOf, piVal, tally, tallyBest, score, settle, endRound, floorOf, deal, unknownCards, cardName, stealPick, thr, skin: (v) => { setSkin(v); faceCache.clear(); }, cardEl },
  });
})();
