/* 나사 풀기 퍼즐 — 혼자 즐기는 나사 빼기 퍼즐.
   Board: layered translucent planks (later index = higher layer) pinned by screws. A screw can be pulled only when no
   higher plank still covers it. Pulled screws go to a matching active toolbox (2 at a time, 3 screws each) or to a small
   holding tray. A plank with one screw left hangs from it (pose = centre straight below the pivot, used for covering too);
   with none it falls off. Levels are seeded and solvable by construction: a random legal removal order is made first,
   colours/boxes are assigned along that order and the order is simulated with the real rules (tray margin) before use.
   Progress (current level, max cleared, best) lives in localStorage — progress only, no power. */
(function () {
  const L = window.Lounge, U = L.util;
  /* ---------- 오늘의 퍼즐 (날짜 YYYYMMDD 씨앗 → 모두 같은 퍼즐). 기록·연속 일수는 이 기기에만, 지난 7일치만 남김 ---------- */
  function mkDaily(gid, short, fmt, lower) {
    const SK = 'lounge.daily.' + gid;
    const ymd = (d) => d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
    const toD = (n) => new Date(Math.floor(n / 10000), Math.floor(n / 100) % 100 - 1, n % 100, 12);
    const shift = (n, k) => { const d = toD(n); d.setDate(d.getDate() + k); return ymd(d); };
    const rd = () => { try { return JSON.parse(localStorage.getItem(SK) || '{}') || {}; } catch (e) { return {}; } };
    const wr = (o) => { try { localStorage.setItem(SK, JSON.stringify(o)); } catch (e) {} };
    const D = {
      today: () => ymd(new Date()),
      md: (n) => (Math.floor(n / 100) % 100) + '/' + (n % 100),
      long: (n) => (Math.floor(n / 100) % 100) + '월 ' + (n % 100) + '일',
      seed(n) { let h = (n >>> 0) ^ 0x9e3779b9; h = Math.imul(h ^ (h >>> 16), 0x85ebca6b); h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35); return (h ^ (h >>> 16)) >>> 0; },
      score: (n) => { const o = rd(); return o.done ? o.done[n] : undefined; },
      streak() { const o = rd(), t = D.today(); return o.last && (o.last === t || o.last === shift(t, -1)) ? o.st | 0 : 0; },
      prune() {
        const o = rd(), cut = shift(D.today(), -6);
        if (o.done) for (const k in o.done) if (+k < cut) delete o.done[k];
        wr(o);
        try { const all = U.store.get('best.' + gid, {}); let ch = 0; for (const k in all) if (/^d\d{8}$/.test(k) && +k.slice(1) < cut) { delete all[k]; ch = 1; } if (ch) U.store.set('best.' + gid, all); } catch (e) {}
      },
      /* 완료 기록 → 새 최고면 true */
      complete(n, sc, api) {
        const o = rd(); o.done = o.done || {};
        const old = o.done[n], first = old == null;
        if (first || (lower ? sc < old : sc > old)) o.done[n] = sc;
        if (first) { o.st = o.last === shift(n, -1) ? (o.st | 0) + 1 : o.last === n ? o.st | 0 || 1 : 1; if (!o.last || n > o.last) o.last = n; }
        wr(o);
        if (api) api.best('d' + n, sc, { label: '오늘의 퍼즐 ' + D.md(n), lower: !!lower, unit: fmt === 'time' ? '' : fmt, fmt: fmt === 'time' ? 'time' : '' });
        D.prune();
        return !first && o.done[n] === sc && sc !== old;
      },
      text(n) {
        const sc = D.score(n);
        const v = fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt;
        return '한판 라운지 ' + short + ' ' + D.md(n) + ' ✓ ' + v + ' · 연속 ' + Math.max(1, D.streak()) + '일';
      },
      share(n, api) {
        const t = D.text(n), ok = () => api && api.toast('복사했어요: ' + t);
        const fb = () => { try { const ta = L.h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = t; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); ok(); } catch (e) { if (api) api.toast(t); } };
        try { if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(ok, fb); else fb(); } catch (e) { fb(); }
      },
      fmtScore(sc) { return sc == null ? '' : fmt === 'time' ? (sc >= 60 ? Math.floor(sc / 60) + '분 ' + Math.round(sc % 60) + '초' : Math.round(sc) + '초') : sc + fmt; },
      /* 단계/모드 고르기 맨 위에 넣는 큰 카드 */
      card(onPlay, api, sub) {
        const n = D.today(), sc = D.score(n), st = D.streak();
        const box = L.h('div', { class: 'daily-card', style: { display: 'flex', flexDirection: 'column', gap: '8px', padding: '12px', borderRadius: '14px', border: '2px solid var(--brass,#e3ae45)', background: 'linear-gradient(135deg,rgba(227,174,69,.22),rgba(227,174,69,.06))' } });
        const head = L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' } });
        head.append(L.h('div', { style: { display: 'flex', flexDirection: 'column', lineHeight: '1.2' } },
          L.h('b', { style: { fontSize: '18px' }, text: '📅 오늘의 퍼즐' }),
          L.h('span', { class: 'muted', style: { fontSize: '13px' }, text: D.long(n) + (sub ? ' · ' + sub : '') })),
          L.h('div', { style: { textAlign: 'right', lineHeight: '1.2', fontSize: '13px' } },
            L.h('div', { style: { fontSize: '15px', fontWeight: '700', color: sc != null ? '#8fd14f' : 'inherit' }, text: sc != null ? '완료 ✓' : '미완료' }),
            L.h('div', { class: 'muted', text: '🔥 연속 ' + st + '일' })));
        box.append(head);
        if (sc != null) box.append(L.h('div', { style: { fontSize: '13px' }, text: '오늘 최고 ' + D.fmtScore(sc) }));
        const row = L.h('div', { style: { display: 'flex', gap: '6px' } });
        row.append(L.h('button', { class: 'btn primary', style: { flex: '1', minHeight: '48px' }, text: sc != null ? '다시 도전 ▶' : '도전하기 ▶', onclick: () => onPlay(n) }));
        if (sc != null) row.append(L.h('button', { class: 'btn', style: { flex: '0 0 auto', minHeight: '48px', padding: '0 14px' }, text: '📋 공유', onclick: () => D.share(n, api) }));
        box.append(row);
        return box;
      },
    };
    return D;
  }
  const BW = 100, BH = 130, SR = 3.4;          // board (logical units), screw radius
  const COLS = ['#e8433a', '#f39a2b', '#f2d43a', '#4fc25a', '#2bb9c8', '#3b6fe0', '#9a5ce0', '#ec6fb4'];
  const SYMS = ['●', '▲', '■', '◆', '★', '✚', '♥', '▼'];
  const PCOL = ['#c98b4a', '#7fa7c9', '#9fc27a', '#d48aa0', '#c9b25a', '#8a9ad6', '#7cc2b4', '#d59a6a'];
  const KEY = 'lounge.screw';
  const TRAY = 5, UNDO = 3, HINTS = 3;

  function store() { try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; } }
  function save(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); } catch (e) {} }
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }

  /* ---------- geometry ---------- */
  // plank = [cx, cy, angleDeg, halfLen, halfWid, type]; type 0: bar 2 holes, 1: bar 3 holes, 2: plate 4 holes
  function holesOf(p) {
    const l = p[3], w = p[4], t = p[5];
    if (t === 2) return [[-(l - 5), -(w - 5)], [l - 5, -(w - 5)], [l - 5, w - 5], [-(l - 5), w - 5]];
    const e = l - 5;
    return t === 1 ? [[-e, 0], [0, 0], [e, 0]] : [[-e, 0], [e, 0]];
  }
  function toW(cx, cy, a, u, v) { const c = Math.cos(a), s = Math.sin(a); return [cx + u * c - v * s, cy + u * s + v * c]; }
  // static tables: per screw → [plank, hole index], per plank → first screw index
  function tables(P) {
    const sp = [], first = [];
    P.forEach((p, i) => { first.push(sp.length); holesOf(p).forEach((h, k) => sp.push([i, k])); });
    return { sp, first };
  }
  // current pose of plank i given removed flags → {cx, cy, a, hang, n}
  function pose(P, T, rm, i) {
    const p = P[i], H = holesOf(p), f = T.first[i];
    let n = 0, last = -1;
    for (let k = 0; k < H.length; k++) if (rm[f + k] !== '1') { n++; last = k; }
    const a0 = p[2] * Math.PI / 180;
    if (n !== 1) return { cx: p[0], cy: p[1], a: a0, n, hang: -1 };
    const h = H[last], len = Math.hypot(h[0], h[1]);
    if (len < 1) return { cx: p[0], cy: p[1], a: a0, n, hang: last };
    const piv = toW(p[0], p[1], a0, h[0], h[1]);
    const a = -Math.PI / 2 - Math.atan2(h[1], h[0]);
    const c = Math.cos(a), s = Math.sin(a);
    return { cx: piv[0] - (h[0] * c - h[1] * s), cy: piv[1] - (h[0] * s + h[1] * c), a, n, hang: last, px: piv[0], py: piv[1] };
  }
  function screwPos(P, T, rm, j) {
    const [i, k] = T.sp[j], q = pose(P, T, rm, i), h = holesOf(P[i])[k];
    return toW(q.cx, q.cy, q.a, h[0], h[1]);
  }
  function covers(P, q, i, x, y) {
    const p = P[i], dx = x - q.cx, dy = y - q.cy, c = Math.cos(q.a), s = Math.sin(q.a);
    const u = dx * c + dy * s, v = -dx * s + dy * c;
    return Math.abs(u) <= p[3] + SR * 0.6 && Math.abs(v) <= p[4] + SR * 0.6;
  }
  function freeList(P, T, rm) {
    const poses = P.map((_, i) => pose(P, T, rm, i));
    const out = [];
    for (let j = 0; j < T.sp.length; j++) {
      if (rm[j] === '1') continue;
      const pi = T.sp[j][0], h = holesOf(P[pi])[T.sp[j][1]], q = poses[pi];
      const w = toW(q.cx, q.cy, q.a, h[0], h[1]);
      let ok = true;
      for (let i = pi + 1; i < P.length && ok; i++) if (poses[i].n > 0 && covers(P, poses[i], i, w[0], w[1])) ok = false;
      if (ok) out.push(j);
    }
    return out;
  }

  /* ---------- rules (pure) — g = {rm, bx:[[c,n],[c,n]], bi, tr} ---------- */
  function step(g, q, sc, j) {
    const c = sc[j];
    g.rm = g.rm.slice(0, j) + '1' + g.rm.slice(j + 1);
    let k = g.bx.findIndex((b) => b[0] === c && b[1] < 3);
    let to;
    if (k >= 0) { to = 'b' + k + g.bx[k][1]; g.bx[k][1]++; } else { to = 't' + g.tr.length; g.tr += c; }
    let moved = 0, done = [];
    for (let guard = 0; guard < 40; guard++) {
      const f = g.bx.findIndex((b) => b[0] && b[1] >= 3);
      if (f < 0) break;
      done.push(f);
      const nc = g.bi < q.length ? q[g.bi++] : '';
      g.bx[f] = [nc, 0];
      if (nc) { // pull matching tray screws
        let t = '';
        for (const ch of g.tr) { if (ch === nc && g.bx[f][1] < 3) { g.bx[f][1]++; moved++; } else t += ch; }
        g.tr = t;
      }
    }
    return { to, moved, done };
  }
  const snap = (g) => g.rm + '|' + g.bx.map((b) => (b[0] || '-') + b[1]).join('') + '|' + g.bi + '|' + g.tr;
  function unsnap(str) {
    const [rm, b, bi, tr] = str.split('|');
    return { rm, bx: [[b[0] === '-' ? '' : b[0], +b[1]], [b[2] === '-' ? '' : b[2], +b[3]]], bi: +bi, tr: tr || '' };
  }

  /* ---------- solver: DFS with memo → list of screw ids or null ---------- */
  function solve(s, limit) {
    const P = s.p, T = tables(P), q = s.q, sc = s.sc, cap = s.tc;
    const seen = new Set(); let nodes = 0;
    const path = [];
    function rec(g) {
      if (g.rm.indexOf('0') < 0) return true;
      if (++nodes > limit) return false;
      const key = snap(g);
      if (seen.has(key)) return false;
      seen.add(key);
      const fr = freeList(P, T, g.rm);
      const good = [], bad = [];
      for (const j of fr) (g.bx.some((b) => b[0] === sc[j] && b[1] < 3) ? good : bad).push(j);
      // among tray moves prefer colours that come soonest in the queue
      const soon = (c) => { const k = q.indexOf(c, g.bi); return k < 0 ? 99 : k; };
      bad.sort((a, b) => soon(sc[a]) - soon(sc[b]));
      for (const j of good.length ? good.slice(0, 1).concat(good.slice(1)) : bad) {
        const n = { rm: g.rm, bx: g.bx.map((b) => b.slice()), bi: g.bi, tr: g.tr };
        step(n, q, sc, j);
        if (n.tr.length >= cap && n.rm.indexOf('0') >= 0) continue;
        path.push(j);
        if (rec(n)) return true;
        path.pop();
        if (nodes > limit) return false;
        if (good.length) break; // a matching pull never hurts
      }
      return false;
    }
    const g0 = { rm: s.rm, bx: s.bx.map((b) => b.slice()), bi: s.bi, tr: s.tr };
    return rec(g0) ? path : null;
  }

  /* ---------- generator ---------- */
  const plankCount = (lv) => Math.min(17, 4 + Math.floor(lv * 0.7));
  const colorCount = (lv) => Math.min(8, 3 + Math.floor((lv - 1) / 3));
  const DLV = 18; // 오늘의 퍼즐 = 18단계 난이도
  const DAILY = mkDaily('screw', '나사', '번', true);
  function gen(lv, seed) {
    for (let at = 0; at < 300; at++) {
      const r = prng(seed ? (seed + at * 104729) >>> 0 : lv * 7919 + at * 104729 + 31);
      const n = plankCount(lv), P = [], pts = [];
      let tries = 0;
      while (P.length < n && tries++ < 600) {
        let p;
        if (r() < 0.22) { const l = 10 + Math.floor(r() * 5); p = [0, 0, [0, 15, 30, 45][Math.floor(r() * 4)], l, l, 2]; }
        else { const l = 13 + Math.floor(r() * 20); p = [0, 0, [0, 90, 45, -45, 30, -30, 60, -60, 0, 90][Math.floor(r() * 10)], l, 5, r() < 0.25 && l >= 22 ? 1 : 0]; }
        p[0] = 12 + Math.floor(r() * (BW - 24)); p[1] = 14 + Math.floor(r() * (BH - 28));
        const a = p[2] * Math.PI / 180;
        const hw = holesOf(p).map((h) => toW(p[0], p[1], a, h[0], h[1]));
        if (hw.some((w) => w[0] < 6 || w[0] > BW - 6 || w[1] < 6 || w[1] > BH - 6)) continue;
        if (hw.some((w) => pts.some((o) => Math.hypot(o[0] - w[0], o[1] - w[1]) < 10))) continue;
        // keep things overlapping a bit after the first few
        if (P.length >= 2) {
          let ov = false;
          for (let i = 0; i < P.length && !ov; i++) { const q = P[i]; if (Math.hypot(q[0] - p[0], q[1] - p[1]) < q[3] + p[3]) ov = true; }
          if (!ov && r() < 0.8) continue;
        }
        P.push(p); hw.forEach((w) => pts.push(w));
      }
      if (P.length < n) continue;
      // total screws → multiple of 3
      let cnt = P.reduce((a, p) => a + holesOf(p).length, 0);
      for (let i = 0; i < P.length && cnt % 3; i++) {
        const p = P[i];
        if (p[5] === 0 && p[3] >= 18) {
          const a = p[2] * Math.PI / 180, w = toW(p[0], p[1], a, 0, 0);
          const others = pts.filter((o) => true);
          if (others.some((o) => Math.hypot(o[0] - w[0], o[1] - w[1]) < 10)) continue;
          p[5] = 1; pts.push(w); cnt++;
        }
      }
      if (cnt % 3) continue;
      const T = tables(P);
      // random legal removal order (hang poses included)
      let rm = '0'.repeat(cnt); const ord = [];
      while (ord.length < cnt) {
        const fr = freeList(P, T, rm);
        if (!fr.length) break;
        const j = fr[Math.floor(r() * fr.length)];
        ord.push(j); rm = rm.slice(0, j) + '1' + rm.slice(j + 1);
      }
      if (ord.length < cnt) continue;
      // boxes along the order, then mix within a window while the order still works with margin
      const nb = cnt / 3, kc = colorCount(lv), q = [];
      for (let b = 0; b < nb; b++) {
        let c; do { c = String.fromCharCode(97 + Math.floor(r() * kc)); } while (b > 0 && c === q[b - 1] && kc > 1);
        q.push(c);
      }
      const col = ord.map((_, k) => q[Math.floor(k / 3)]);
      const margin = lv < 4 ? 2 : lv < 12 ? 1 : 1;
      const D = Math.min(9, 3 + Math.floor(lv / 2));
      const sim = () => {
        const sc = []; ord.forEach((j, k) => { sc[j] = col[k]; });
        const g = { rm: '0'.repeat(cnt), bx: [[q[0], 0], [q[1] || '', 0]], bi: 2, tr: '' };
        const scs = sc.join('');
        let mx = 0;
        for (const j of ord) { step(g, q.join(''), scs, j); mx = Math.max(mx, g.tr.length); }
        return mx <= TRAY - margin ? scs : null;
      };
      let good = sim(); if (!good) continue;
      const swaps = 6 + lv * 3;
      for (let k = 0; k < swaps; k++) {
        const a = Math.floor(r() * cnt), b = Math.min(cnt - 1, a + 1 + Math.floor(r() * D));
        if (col[a] === col[b]) continue;
        const t = col[a]; col[a] = col[b]; col[b] = t;
        const ok = sim();
        if (ok) good = ok; else { col[b] = col[a]; col[a] = t; }
      }
      return { p: P, sc: good, q: q.join(''), o: ord.map((j) => String.fromCharCode(48 + j)).join('') };
    }
    return null;
  }

  function newLevel(s, lv, dy) {
    s.dy = dy || 0;
    let G = s.dy ? gen(DLV, DAILY.seed(s.dy)) : gen(lv);
    if (!G) { lv = 1; G = gen(1); s.dy = 0; }
    if (s.dy) lv = DLV;
    s.lv = lv; s.p = G.p; s.sc = G.sc; s.q = G.q; s.o = G.o;
    s.rm = '0'.repeat(G.sc.length); s.bx = [[G.q[0], 0], [G.q[1] || '', 0]]; s.bi = 2; s.tr = '';
    s.tc = TRAY; s.m = 0; s.u = []; s.ul = UNDO; s.h = HINTS; s.x = 0; s.hint = -1;
    s.won = 0; s.lost = 0; s.end = 0;
    s.last = { id: (s.last ? s.last.id : 0) + 1, t: 'new' };
    return s;
  }
  function planNext(s) {
    // follow the construction order while it is still exactly the moves made so far
    const p = solve(s, 15000);
    return p && p.length ? p[0] : -1;
  }

  const def = {
    id: 'screw', name: '나사 풀기 퍼즐', tag: '나사 빼기 퍼즐', cat: '아케이드',
    blurb: '겹친 판자를 고정한 나사를 눌러 빼요. 같은 색 공구함에 3개씩 모으고, 판자를 모두 떨어뜨리면 통과!',
    tint: '#4a3a1c',
    icon: '<rect x="6" y="20" width="44" height="12" rx="6" transform="rotate(-20 28 26)" fill="none" stroke="currentColor" stroke-width="2.5"/><rect x="8" y="30" width="40" height="12" rx="6" transform="rotate(15 28 36)" fill="currentColor" opacity=".45"/><circle cx="14" cy="31" r="5" fill="currentColor"/><circle cx="42" cy="22" r="5" fill="currentColor"/><path d="M11 31h6M42 19v6" stroke="#000" stroke-opacity=".5" stroke-width="2"/><rect x="18" y="4" width="20" height="8" rx="2" fill="none" stroke="currentColor" stroke-width="2.2"/>',
    minPlayers: 1, maxPlayers: 1, defaultPlayers: 1, noAI: true, hidden: false, aiDelay: 380,
    controls: [
      { id: 'undo', label: '되돌리기', keys: ['KeyZ', 'Backspace'], pad: ['b'] },
      { id: 'reset', label: '다시 하기', keys: ['KeyR'], pad: ['back'] },
      { id: 'hint', label: '힌트', keys: ['KeyH'], pad: ['y'] },
      { id: 'extra', label: '보관 칸 더하기', keys: ['KeyE'], pad: ['x'] },
    ],
    quick: [
      '목표: 나사를 모두 빼서 판자를 전부 떨어뜨리기!',
      '나사를 누르면 빠져서 같은 색 공구함(3칸)으로 가요. 맞는 공구함이 없으면 보관함으로 가요.',
      '보관함(5칸)이 꽉 차면 실패! 위에 다른 판자가 덮은 나사는 뺄 수 없어요.',
    ],
    rules: [
      { h: '목표', p: ['나사를 모두 빼면 판자가 전부 떨어지고 단계 통과예요.'] },
      { h: '그림으로 보기', fig: [{ svg: "<svg viewBox=\"0 0 340 126\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"126\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"20\" y=\"40\" width=\"150\" height=\"30\" rx=\"6\" fill=\"#b07a45\" stroke=\"#6b4a2a\" stroke-width=\"2\"/><circle cx=\"40\" cy=\"55\" r=\"9\" fill=\"#e0524a\" stroke=\"#111\" stroke-width=\"1.5\"/><path d=\"M35 55 h10\" stroke=\"#111\" stroke-width=\"2\"/><circle cx=\"150\" cy=\"55\" r=\"9\" fill=\"#4a8fe0\" stroke=\"#111\" stroke-width=\"1.5\"/><path d=\"M145 55 h10\" stroke=\"#111\" stroke-width=\"2\"/><rect x=\"110\" y=\"20\" width=\"90\" height=\"28\" rx=\"6\" fill=\"rgba(160,120,80,.85)\" stroke=\"#6b4a2a\" stroke-width=\"2\"/><circle cx=\"185\" cy=\"34\" r=\"9\" fill=\"#4cc27a\" stroke=\"#111\" stroke-width=\"1.5\"/><path d=\"M180 34 h10\" stroke=\"#111\" stroke-width=\"2\"/><text x=\"40\" y=\"92\" font-size=\"11\" fill=\"#9fd59f\" text-anchor=\"middle\" font-weight=\"400\">O 뺄 수 있음</text><text x=\"150\" y=\"92\" font-size=\"11\" fill=\"#f2a0a0\" text-anchor=\"middle\" font-weight=\"400\">X 판자에 덮임</text><text x=\"270\" y=\"40\" font-size=\"11.5\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">위 판자를 먼저</text><text x=\"270\" y=\"58\" font-size=\"11.5\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">풀어야 아래</text><text x=\"270\" y=\"76\" font-size=\"11.5\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">나사가 빠져요</text><text x=\"170\" y=\"116\" font-size=\"11.5\" fill=\"#e3ae45\" text-anchor=\"middle\" font-weight=\"400\">나사가 0개가 된 판자는 떨어져요</text></svg>", cap: "덮인 나사는 못 빼요" }, { svg: "<svg viewBox=\"0 0 340 110\" xmlns=\"http://www.w3.org/2000/svg\" font-family=\"sans-serif\"><rect width=\"340\" height=\"110\" rx=\"10\" fill=\"#1d2230\"/><rect x=\"20\" y=\"16\" width=\"84\" height=\"34\" rx=\"6\" fill=\"#2b3245\" stroke=\"#e0524a\" stroke-width=\"2\"/><text x=\"62\" y=\"38\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">공구함</text><rect x=\"120\" y=\"16\" width=\"84\" height=\"34\" rx=\"6\" fill=\"#2b3245\" stroke=\"#4a8fe0\" stroke-width=\"2\"/><text x=\"162\" y=\"38\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"middle\" font-weight=\"400\">공구함</text><rect x=\"20\" y=\"66\" width=\"30\" height=\"30\" rx=\"5\" fill=\"#2b3245\" stroke=\"#777\" stroke-width=\"1\"/><rect x=\"56\" y=\"66\" width=\"30\" height=\"30\" rx=\"5\" fill=\"#2b3245\" stroke=\"#777\" stroke-width=\"1\"/><rect x=\"92\" y=\"66\" width=\"30\" height=\"30\" rx=\"5\" fill=\"#2b3245\" stroke=\"#777\" stroke-width=\"1\"/><rect x=\"128\" y=\"66\" width=\"30\" height=\"30\" rx=\"5\" fill=\"#2b3245\" stroke=\"#777\" stroke-width=\"1\"/><rect x=\"164\" y=\"66\" width=\"30\" height=\"30\" rx=\"5\" fill=\"#2b3245\" stroke=\"#777\" stroke-width=\"1\"/><circle cx=\"35\" cy=\"81\" r=\"9\" fill=\"#4cc27a\" stroke=\"#111\" stroke-width=\"1.5\"/><path d=\"M30 81 h10\" stroke=\"#111\" stroke-width=\"2\"/><text x=\"206\" y=\"76\" font-size=\"11\" fill=\"#f2e9d8\" text-anchor=\"start\" font-weight=\"400\">맞는 색 없으면 보관함</text><text x=\"206\" y=\"94\" font-size=\"11\" fill=\"#f2a0a0\" text-anchor=\"start\" font-weight=\"400\">5칸 꽉 차면 실패</text></svg>", cap: "공구함과 보관함" }] },
      { h: '나사 빼기', p: [
        '나사를 누르면 빙글 돌며 빠져요. 그 나사 위를 다른 판자가 덮고 있으면 뺄 수 없어요(흔들리기만 해요).',
        '빠진 나사는 위쪽 같은 색 공구함으로 가요. 공구함은 2개가 열려 있고, 3개가 차면 닫히고 다음 공구함이 와요.',
        '색이 맞는 공구함이 없으면 아래 보관함에 들어가요. 그 색 공구함이 오면 보관함 나사가 저절로 옮겨 가요.',
      ] },
      { h: '판자', p: [
        '나사가 하나만 남은 판자는 그 나사에 매달려 아래로 축 늘어져요(그 모습대로 다른 나사를 덮어요).',
        '나사가 하나도 없으면 판자가 떨어져요.',
      ] },
      { h: '실패와 도움', p: [
        '보관함 5칸이 꽉 차면 실패예요. 되돌리기·보관 칸 더하기·다시 하기로 이어 갈 수 있어요.',
        '↶ 되돌리기: 단계마다 3번. ＋ 보관 칸: 단계마다 1번, 칸을 하나 늘려요. 💡 힌트: 단계마다 3번, 뺄 나사를 깜빡여 줘요.',
        '◐ 무늬: 나사 머리에 색마다 다른 모양을 그려요(색 구분이 어려울 때).',
      ] },
      { h: '그림 판자', p: ['「단계」 화면의 🖼 그림 판자를 켜면 판자마다 그림 조각이 칠해지고, 나사를 뺄수록 뒤판의 그림이 점점 밝게 드러나요. 다 풀면 한 장의 그림이 완성!',
        '그림은 단계마다 정해져 있어요(산과 호수·밤의 도시·바다 섬·우주·꽃 언덕·추상화).'] },
      { h: '최소 수', p: ['나사 하나에 한 번씩 누르니까 최소 수 = 나사 개수예요. 되돌리기를 쓰면 누른 수가 늘어나요. 위쪽에 「누른 수 / 최소」가 나와요.'] },
      { h: '단계', p: [
        '모든 단계는 반드시 풀 수 있게 만들어져요. 단계가 오를수록 판자와 색이 늘어나요.',
        '지금 단계와 최고 기록이 이 폰에 저장돼요. 「단계」 버튼으로 깬 단계를 다시 할 수 있어요.',
      ] },
      { h: '오늘의 퍼즐', p: ['「단계」 버튼 맨 위 카드에서 매일 하나씩 새 퍼즐(18단계 급)을 풀 수 있어요. 날짜가 같으면 누구나 같은 퍼즐이에요.', '하루씩 이어서 풀면 🔥 연속 일수가 올라가요. 오늘 기록은 「📋 공유」로 퍼즐 내용 없이 복사할 수 있어요. 단계 진행과는 따로예요.'] },
      { h: '조작(PC)', p: ['마우스로 나사를 눌러요. Z 되돌리기 · R 다시 · H 힌트 · E 보관 칸.'] },
    ],
    tutorial: [
      { text: '나사를 누르면 빠져서 위쪽 같은 색 공구함으로 가요. 3개 모이면 공구함이 닫혀요.' },
      { text: '색이 안 맞으면 보관함으로! 보관함이 꽉 차면 실패니까 순서를 잘 생각하세요.' },
      { text: '막히면 아래 버튼: 되돌리기 · 다시 · 보관 칸 · 힌트 · 단계 고르기 · 무늬.', sel: '.sw-bar' },
    ],

    init() {
      const st = store();
      const mx = Math.max(0, st.max | 0);
      let lv = Math.max(1, st.cur | 0 || 1);
      if (lv > mx + 1) lv = mx + 1;
      return newLevel({ mx, last: null }, lv);
    },
    actor(s) { return s.end ? null : 0; },
    apply(s, seat, a) {
      if (!a || s.end) throw new Error('bad');
      const t = a.t;
      if (t === 'tap') {
        if (s.won || s.lost) throw new Error('over');
        const j = a.j | 0;
        if (s.rm[j] !== '0') throw new Error('gone');
        const T = tables(s.p);
        if (freeList(s.p, T, s.rm).indexOf(j) < 0) throw new Error('blocked');
        const g = { rm: s.rm, bx: s.bx, bi: s.bi, tr: s.tr };
        s.u.push(snap(g)); if (s.u.length > UNDO) s.u.shift();
        const pi = T.sp[j][0];
        const r = step(g, s.q, s.sc, j);
        s.rm = g.rm; s.bx = g.bx; s.bi = g.bi; s.tr = g.tr;
        s.m++; s.hint = -1;
        const fell = pose(s.p, T, s.rm, pi).n === 0 ? 1 : 0;
        s.last = { id: s.last.id + 1, t: 'tap', j, to: r.to, d: r.done.join(''), mv: r.moved, f: fell };
        if (s.rm.indexOf('0') < 0) { s.won = 1; if (!s.dy && s.lv > s.mx) s.mx = s.lv; }
        else if (s.tr.length >= s.tc) s.lost = 1;
      } else if (t === 'undo') {
        if (s.won || !s.ul || !s.u.length) throw new Error('no undo');
        Object.assign(s, unsnap(s.u.pop()));
        s.ul--; s.m++; s.hint = -1; s.lost = 0;
        s.last = { id: s.last.id + 1, t: 'undo' };
      } else if (t === 'reset') {
        newLevel(s, s.lv, s.dy); s.last.t = 'reset';
      } else if (t === 'extra') {
        if (s.won || s.x) throw new Error('used');
        s.x = 1; s.tc++; if (s.tr.length < s.tc) s.lost = 0;
        s.last = { id: s.last.id + 1, t: 'extra' };
      } else if (t === 'hint') {
        if (s.won || s.lost || !s.h) throw new Error('no hint');
        s.h--; s.hint = planNext(s);
        s.last = { id: s.last.id + 1, t: 'hint' };
      } else if (t === 'next') {
        if (!s.won) throw new Error('not yet');
        if (s.dy) newLevel(s, s.rl || 1); else newLevel(s, s.lv + 1);
      } else if (t === 'go') {
        const n = a.n | 0;
        if (n < 1 || n > s.mx + 1) throw new Error('locked');
        newLevel(s, n);
      } else if (t === 'daily') {
        const d = a.d | 0;
        if (d < 20000101 || d > 29991231) throw new Error('bad date');
        if (!s.dy) s.rl = s.lv;
        newLevel(s, DLV, d);
      } else if (t === 'end') {
        if (!s.won) throw new Error('not yet');
        s.end = 1;
      } else throw new Error('unknown');
      return s;
    },
    ai(s) {
      if (s.won) return { t: 'end' };
      if (s.lost) return s.x ? (s.ul && s.u.length ? { t: 'undo' } : { t: 'reset' }) : { t: 'extra' };
      const j = planNext(s);
      if (j >= 0) return { t: 'tap', j };
      if (s.ul && s.u.length) return { t: 'undo' };
      const fr = freeList(s.p, tables(s.p), s.rm);
      return fr.length ? { t: 'tap', j: fr[0] } : { t: 'reset' };
    },
    result(s) {
      if (!s.end) return null;
      return { winners: [0], title: s.dy ? '오늘의 퍼즐 ' + DAILY.md(s.dy) + ' 완료!' : s.lv + '단계 통과!', text: s.m + '번 만에 판자를 모두 떨어뜨렸어요.',
        stats: [{ label: '누른 수', value: String(s.m) }, { label: '최소', value: s.sc.length + '번' }, { label: '판자 · 나사', value: s.p.length + '장 · ' + s.sc.length + '개' }, { label: '힌트 사용', value: (HINTS - s.h) + '번' }, { label: '되돌리기 사용', value: (UNDO - s.ul) + '번' }, { label: '보관 칸 더하기', value: s.x ? '썼어요' : '안 썼어요' }] };
    },

    mount(root, api) {
      const cvs = U.canvas(root), cv = cvs.cv, ctx = cvs.ctx;
      const SP = () => (L.debug && L.debug.speed) || 1;
      let S = null, T = null, rafStop = null, now = 0, lastWin = 0, lastLose = 0;
      let parts = [], fly = null, swings = {}, falls = [], shakes = {}, boxIn = {}, trayPop = 0, spinOut = null;
      let sym = !!store().sym, pic = !!store().pic;
      /* 그림 판자: 그림(숫자 슬라이드 퍼즐과 같은 그리기 함수)을 뒤판에 깔고 판자마다 처음 놓인 자리의 그림 조각을 칠함 */
      const art = { k: '', cv: null };
      const paint = () => (L.games && L.games.slide && L.games.slide._paint) || null;
      const artSeed = () => (S.dy ? DAILY.seed(S.dy) : Math.imul(S.lv, 2654435761) >>> 0) >>> 0;
      const artTheme = () => { const th = L.games.slide._themes; return artSeed() % th.length; };
      function artFor(w, h) {
        const pf = paint(); if (!pf || !pic) return null;
        const k = artSeed() + ':' + Math.round(w) + 'x' + Math.round(h);
        if (art.k !== k) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); pf(c.getContext('2d'), c.width, c.height, artSeed(), artTheme()); art.k = k; art.cv = c; }
        return art.cv;
      }
      const par = () => S.sc.length; // each pull is one press → the minimum is the screw count
      const bar = L.h('div', { class: 'sw-bar', style: { position: 'absolute', left: '0', right: '0', bottom: '0', display: 'flex', gap: '5px', padding: '8px 8px 10px', justifyContent: 'center', zIndex: 5 } });
      const mkBtn = (ic, lab, fn) => {
        const b = L.h('button', { class: 'btn sm', style: { flex: '1 1 0', minWidth: '0', minHeight: '52px', padding: '4px 2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '1px', lineHeight: '1.1' }, onclick: (e) => { e.stopPropagation(); fn(); } });
        const i = L.h('span', { style: { fontSize: '18px' }, text: ic }), t = L.h('span', { style: { fontSize: '11px', whiteSpace: 'nowrap' }, text: lab });
        b.append(i, t); bar.append(b); return { b, t };
      };
      const act = (a) => { if (api.canAct(0)) api.act(a); };
      const bUndo = mkBtn('↶', '되돌리기', () => act({ t: 'undo' }));
      const bReset = mkBtn('⟲', '다시', () => act({ t: 'reset' }));
      const bExtra = mkBtn('＋', '보관 칸', () => act({ t: 'extra' }));
      const bHint = mkBtn('💡', '힌트', () => act({ t: 'hint' }));
      bUndo.b.dataset.action = 'undo'; bReset.b.dataset.action = 'reset'; bExtra.b.dataset.action = 'extra'; bHint.b.dataset.action = 'hint';
      const bLv = mkBtn('▦', '단계', () => openPicker());
      const bSym = mkBtn('◐', '무늬', () => { sym = !sym; const o = store(); o.sym = sym ? 1 : 0; save(o); refreshBar(); });
      root.append(bar);
      let ov = null;
      function closeOv() { if (ov) { ov.remove(); ov = null; } }
      function panel(children) {
        closeOv();
        ov = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 15, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', background: 'rgba(10,8,15,.6)' }, onpointerdown: (e) => { if (e.target === ov) closeOv(); } });
        const sh = L.h('div', { class: 'sheet', style: { maxHeight: '86%', gap: '12px' } });
        children.forEach((c) => c && sh.append(c));
        ov.append(sh); root.append(ov);
      }
      function openPicker() {
        if (!S) return;
        const best = store().best || {};
        const grid = L.h('div', { style: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(54px,1fr))', gap: '6px', overflowY: 'auto', maxHeight: '52vh' } });
        for (let n = 1; n <= S.mx + 1; n++) {
          const b = L.h('button', { class: 'btn sm' + (n === S.lv ? ' primary' : ''), style: { minHeight: '54px', padding: '2px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', lineHeight: '1.1' }, onclick: () => { closeOv(); act({ t: 'go', n }); } });
          b.append(L.h('span', { class: 'mono', style: { fontSize: '17px' }, text: String(n) }), L.h('span', { style: { fontSize: '10px', opacity: '.8' }, text: best[n] ? best[n] + '번' : n > S.mx ? '새 단계' : '✓' }));
          grid.append(b);
        }
        const picBtn = paint() ? L.h('button', { class: 'btn' + (pic ? ' primary' : ''), style: { minHeight: '48px' }, text: pic ? '🖼 그림 판자 켬 (끄기)' : '🖼 그림 판자 끔 (켜기)', onclick: () => { pic = !pic; const o = store(); o.pic = pic ? 1 : 0; save(o); openPicker(); } }) : null;
        panel([DAILY.card((d) => { closeOv(); act({ t: 'daily', d }); }, api, '18단계 급'), picBtn, L.h('h2', { text: '단계 고르기' }), L.h('p', { class: 'muted', style: { margin: 0 }, text: '깬 단계는 다시 할 수 있어요. 숫자 아래는 최고 기록(가장 적게 누른 수).' }), grid,
          L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '닫기', onclick: closeOv })]);
        setTimeout(() => { const c = grid.querySelector('.primary'); if (c && c.scrollIntoView) c.scrollIntoView({ block: 'center' }); }, 0);
      }
      function winPanel() {
        if (S.dy) {
          const sc = DAILY.score(S.dy);
          return panel([L.h('h2', { text: '오늘의 퍼즐 완료! 🎉' }),
            L.h('p', { style: { margin: 0, fontSize: '16px' }, text: S.m + '번 (최소 ' + par() + '번)' + (sc != null ? ' · 오늘 최고 ' + sc + '번' : '') + ' · 🔥 연속 ' + DAILY.streak() + '일' }),
            L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '📋 결과 공유(복사)', onclick: () => DAILY.share(S.dy, api) }),
            L.h('button', { class: 'btn', style: { minHeight: '48px' }, text: '단계로 돌아가기 ▶', onclick: () => { closeOv(); act({ t: 'next' }); } }),
            L.h('button', { 'data-action': 'reset', class: 'btn ghost', style: { minHeight: '48px' }, text: '다시 도전', onclick: () => { closeOv(); act({ t: 'reset' }); } })]);
        }
        const b = (store().best || {})[S.lv];
        panel([L.h('h2', { text: S.lv + '단계 통과! 🎉' }),
          L.h('p', { style: { margin: 0, fontSize: '16px' }, text: S.m + '번' + (b ? ' · 최고 기록 ' + b + '번' : '') }),
          L.h('p', { style: { margin: 0, color: S.m <= par() ? '#8fd14f' : '#e3ae45' }, text: S.m <= par() ? '🏅 최소 ' + par() + '번 그대로 통과!' : '최소 ' + par() + '번 · 나는 ' + (S.m - par()) + '번 더(되돌리기)' }),
          L.h('button', { class: 'btn primary', style: { minHeight: '52px', fontSize: '17px' }, text: '다음 단계 ▶', onclick: () => { closeOv(); act({ t: 'next' }); } }),
          L.h('button', { 'data-action': 'reset', class: 'btn', style: { minHeight: '48px' }, text: '이 단계 다시', onclick: () => { closeOv(); act({ t: 'reset' }); } }),
          L.h('button', { class: 'btn ghost', style: { minHeight: '48px' }, text: '단계 고르기', onclick: () => openPicker() })]);
      }
      function losePanel() {
        panel([L.h('h2', { text: '보관함이 꽉 찼어요 😵' }),
          L.h('p', { class: 'muted', style: { margin: 0 }, text: '되돌리거나 칸을 늘려서 이어 갈 수 있어요.' }),
          S.ul && S.u.length ? L.h('button', { 'data-action': 'undo', class: 'btn primary', style: { minHeight: '50px' }, text: '↶ 되돌리기 (' + S.ul + ')', onclick: () => { closeOv(); act({ t: 'undo' }); } }) : null,
          !S.x ? L.h('button', { 'data-action': 'extra', class: 'btn', style: { minHeight: '50px' }, text: '＋ 보관 칸 하나 더', onclick: () => { closeOv(); act({ t: 'extra' }); } }) : null,
          L.h('button', { 'data-action': 'reset', class: 'btn', style: { minHeight: '50px' }, text: '⟲ 처음부터 다시', onclick: () => { closeOv(); act({ t: 'reset' }); } })]);
      }
      function refreshBar() {
        if (!S) return;
        const dis = (b, v) => { b.b.disabled = !v; b.b.style.opacity = v ? '1' : '.4'; };
        bUndo.t.textContent = '되돌리기 ' + S.ul; dis(bUndo, !S.won && S.ul > 0 && S.u.length > 0);
        bExtra.t.textContent = S.x ? '보관 칸 ✓' : '보관 칸 1'; dis(bExtra, !S.won && !S.x);
        bHint.t.textContent = '힌트 ' + S.h; dis(bHint, !S.won && !S.lost && S.h > 0);
        bSym.t.textContent = sym ? '무늬 켬' : '무늬 끔'; bSym.b.style.outline = sym ? '2px solid var(--brass)' : 'none';
      }

      /* ---------- layout ---------- */
      let LY = null;
      function layout() {
        const W = cvs.w, H = cvs.h;
        const boxY = 44, boxH = Math.min(62, Math.max(50, H * 0.08));
        const trayY = boxY + boxH + 10, slot = Math.min(40, (W - 40) / 6.4);
        const top = trayY + slot + 12, bot = H - 76;
        const sc = Math.min((W - 20) / BW, (bot - top) / BH);
        const ox = (W - BW * sc) / 2, oy = top + Math.max(0, (bot - top - BH * sc) / 2);
        const bw = Math.min(150, (W - 76) / 2);
        LY = { W, H, boxY, boxH, bw, trayY, slot, sc, ox, oy };
      }
      const bx2 = (x) => LY.ox + x * LY.sc, by2 = (y) => LY.oy + y * LY.sc;
      function boxRect(k) { const gap = 10, tot = LY.bw * 2 + gap + 46; const x0 = (LY.W - tot) / 2; return { x: x0 + k * (LY.bw + gap), y: LY.boxY, w: LY.bw, h: LY.boxH }; }
      function boxSlot(k, n) { const r = boxRect(k); return [r.x + r.w * (0.22 + n * 0.28), r.y + r.h * 0.58]; }
      function traySlot(n, cap) { const sp = LY.slot + 6, tot = sp * cap - 6; return [(LY.W - tot) / 2 + n * sp + LY.slot / 2, LY.trayY + LY.slot / 2]; }

      /* ---------- drawing ---------- */
      function rr(x, y, w, h, r) { ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y, w, h, r) : ctx.rect(x, y, w, h); }
      function drawScrew(x, y, r, c, rot, dim, glow) {
        ctx.save(); ctx.translate(x, y);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(1.5, 2, r, 0, 7); ctx.fill();
        const g = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r);
        g.addColorStop(0, '#fff'); g.addColorStop(0.25, c); g.addColorStop(1, shade(c));
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill();
        ctx.lineWidth = 1.2; ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.stroke();
        ctx.rotate(rot);
        if (sym && dim < 1) {
          ctx.fillStyle = 'rgba(20,14,26,.8)'; ctx.font = Math.round(r * 1.05) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText(SYMS[COLS.indexOf(c)] || '', 0, 1);
        } else {
          ctx.strokeStyle = 'rgba(30,20,10,.7)'; ctx.lineWidth = Math.max(1.6, r * 0.26); ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(-r * 0.55, 0); ctx.lineTo(r * 0.55, 0); ctx.moveTo(0, -r * 0.55); ctx.lineTo(0, r * 0.55); ctx.stroke();
        }
        ctx.restore();
        if (dim) { ctx.fillStyle = 'rgba(15,10,20,' + (0.45 * dim) + ')'; ctx.beginPath(); ctx.arc(x, y, r + 0.5, 0, 7); ctx.fill(); }
        if (glow) { ctx.strokeStyle = glow; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, r + 4, 0, 7); ctx.stroke(); }
      }
      const shadeCache = {};
      function shade(c) {
        if (shadeCache[c]) return shadeCache[c];
        const n = parseInt(c.slice(1), 16); const f = (v) => Math.round(v * 0.55);
        return (shadeCache[c] = 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')');
      }
      function drawPlank(i, cx, cy, a, alpha) {
        const p = S.p[i], sc = LY.sc, l = p[3] * sc, w = p[4] * sc;
        ctx.save(); ctx.translate(bx2(cx), by2(cy)); ctx.rotate(a); ctx.globalAlpha = alpha;
        ctx.fillStyle = 'rgba(0,0,0,.3)'; rr(-l + 3, -w + 4, l * 2, w * 2, Math.min(w, 10)); ctx.fill();
        const col = PCOL[i % PCOL.length], AC = art.cv && pic && paint() ? art.cv : null;
        if (AC) { // painted with the part of the picture it covered at the start
          ctx.save(); ctx.globalAlpha = alpha * 0.8; rr(-l, -w, l * 2, w * 2, p[5] === 2 ? 8 : w); ctx.clip();
          ctx.rotate(-p[2] * Math.PI / 180); ctx.translate(-p[0] * sc, -p[1] * sc);
          ctx.drawImage(AC, 0, 0, BW * sc, BH * sc);
          ctx.restore(); ctx.globalAlpha = alpha;
        } else { ctx.fillStyle = col; ctx.globalAlpha = alpha * 0.78; rr(-l, -w, l * 2, w * 2, p[5] === 2 ? 8 : w); ctx.fill(); }
        ctx.globalAlpha = alpha;
        ctx.fillStyle = 'rgba(255,255,255,.22)'; rr(-l + 3, -w + 2, l * 2 - 6, Math.max(2, w * 0.35), w); ctx.fill();
        ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(30,18,10,.55)'; rr(-l, -w, l * 2, w * 2, p[5] === 2 ? 8 : w); ctx.stroke();
        // holes
        ctx.fillStyle = 'rgba(20,12,8,.6)';
        for (const h of holesOf(p)) { ctx.beginPath(); ctx.arc(h[0] * sc, h[1] * sc, SR * sc * 1.05, 0, 7); ctx.fill(); }
        ctx.restore(); ctx.globalAlpha = 1;
      }

      function frame(dt) {
        now += dt;
        if (!S) return;
        if (!LY || LY.W !== cvs.w || LY.H !== cvs.h) layout();
        const W = cvs.w, H = cvs.h, sp = SP();
        const bg = ctx.createLinearGradient(0, 0, 0, H);
        bg.addColorStop(0, '#2a2030'); bg.addColorStop(1, '#17131f');
        ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
        // header
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.font = (S.dy ? '19px' : '24px') + ' "Black Han Sans", sans-serif'; ctx.fillText(S.dy ? '오늘의 퍼즐 ' + DAILY.md(S.dy) : S.lv + '단계', 14, 22);
        ctx.textAlign = 'right'; ctx.font = '13px "IBM Plex Mono", monospace'; ctx.fillStyle = '#ab9fb8';
        const best = S.dy ? DAILY.score(S.dy) : (store().best || {})[S.lv];
        ctx.fillText('누른 수 ' + S.m + ' / 최소 ' + par() + (best ? ' · 최고 ' + best : ''), W - 14, 22);

        // pegboard
        const bxp = LY.ox - 6, byp = LY.oy - 6, bwp = BW * LY.sc + 12, bhp = BH * LY.sc + 12;
        const pg = ctx.createLinearGradient(0, byp, 0, byp + bhp); pg.addColorStop(0, '#5a4630'); pg.addColorStop(1, '#3e2f20');
        ctx.fillStyle = pg; rr(bxp, byp, bwp, bhp, 12); ctx.fill();
        ctx.strokeStyle = '#8a6a3e'; ctx.lineWidth = 3; ctx.stroke();
        ctx.fillStyle = 'rgba(0,0,0,.22)';
        for (let y = 8; y < BH; y += 12) for (let x = 8; x < BW; x += 12) { ctx.beginPath(); ctx.arc(bx2(x), by2(y), 1.6, 0, 7); ctx.fill(); }
        const AC = artFor(BW * LY.sc * cvs.dpr, BH * LY.sc * cvs.dpr);
        if (AC) { // the picture shows through as screws come out
          const left = S.rm.split('').filter((c) => c === '0').length, done = 1 - left / Math.max(1, S.sc.length);
          ctx.save(); rr(bx2(0), by2(0), BW * LY.sc, BH * LY.sc, 8); ctx.clip();
          ctx.drawImage(AC, bx2(0), by2(0), BW * LY.sc, BH * LY.sc);
          ctx.fillStyle = 'rgba(30,22,16,' + (0.82 * (1 - done) + (S.won ? 0 : 0.08)).toFixed(3) + ')'; ctx.fillRect(bx2(0), by2(0), BW * LY.sc, BH * LY.sc);
          ctx.restore();
        }

        // toolboxes (from prev state while a screw is in the air)
        const V = fly && fly.pre ? fly.pre : S;
        for (let k = 0; k < 2; k++) {
          const r = boxRect(k), b = V.bx[k];
          let oy = 0;
          if (boxIn[k]) { const e = (now - boxIn[k]) / 380 * sp; if (e >= 1) delete boxIn[k]; else oy = -(1 - e) * (1 - e) * 70; }
          ctx.save(); ctx.translate(0, oy);
          if (b[0]) {
            const c = COLS[b[0].charCodeAt(0) - 97];
            ctx.fillStyle = shade(c); rr(r.x, r.y + 6, r.w, r.h - 6, 9); ctx.fill();
            ctx.fillStyle = c; rr(r.x, r.y, r.w, 12, 6); ctx.fill();
            ctx.fillStyle = 'rgba(0,0,0,.25)'; rr(r.x + r.w * 0.38, r.y - 6, r.w * 0.24, 8, 3); ctx.fill();
            for (let n = 0; n < 3; n++) {
              const s = boxSlot(k, n);
              ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(s[0], s[1], LY.slot * 0.34, 0, 7); ctx.fill();
              if (n < b[1]) drawScrew(s[0], s[1], LY.slot * 0.3, c, n, 0, null);
            }
          } else {
            ctx.strokeStyle = 'rgba(242,233,216,.2)'; ctx.setLineDash([5, 5]); rr(r.x, r.y, r.w, r.h, 9); ctx.stroke(); ctx.setLineDash([]);
          }
          ctx.restore();
        }
        // next boxes preview
        {
          const r = boxRect(1), x = r.x + r.w + 10, y = LY.boxY;
          ctx.fillStyle = '#ab9fb8'; ctx.font = '11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center';
          ctx.fillText('다음', x + 18, y + 6);
          for (let k = 0; k < 2; k++) {
            const c = V.q[V.bi + k];
            if (!c) continue;
            ctx.globalAlpha = k ? 0.5 : 0.9; ctx.fillStyle = COLS[c.charCodeAt(0) - 97];
            rr(x + 4, y + 16 + k * 22, 28, 16, 4); ctx.fill(); ctx.globalAlpha = 1;
          }
          ctx.fillStyle = '#ab9fb8'; ctx.fillText('남은 함 ' + Math.max(0, V.q.length - V.bi), x + 18, y + LY.boxH + 2);
        }
        // tray
        const cap = V.tc;
        for (let n = 0; n < cap; n++) {
          const s = traySlot(n, cap);
          const warn = V.tr.length >= cap - 1 && n >= V.tr.length;
          ctx.fillStyle = warn ? 'rgba(238,106,85,' + (0.25 + 0.15 * Math.sin(now / 150)) + ')' : 'rgba(0,0,0,.35)';
          rr(s[0] - LY.slot / 2, s[1] - LY.slot / 2, LY.slot, LY.slot, 8); ctx.fill();
          ctx.strokeStyle = n >= TRAY ? '#e3ae45' : 'rgba(242,233,216,.18)'; ctx.lineWidth = 1.5; ctx.stroke();
          if (n < V.tr.length) {
            const pop = trayPop && n === V.tr.length - 1 ? Math.max(0, 1 - (now - trayPop) / 200 * sp) : 0;
            drawScrew(s[0], s[1], LY.slot * 0.32 * (1 + pop * 0.3), COLS[V.tr.charCodeAt(n) - 97], n, 0, null);
          }
        }

        // planks + screws
        const rm = S.rm, free = new Set(freeList(S.p, T, rm));
        const pin = fly && fly.pre ? fly.j : -1;
        for (let i = 0; i < S.p.length; i++) {
          const q = pose(S.p, T, rm, i);
          if (q.n === 0) continue;
          let a = q.a, cx = q.cx, cy = q.cy;
          const sw = swings[i];
          if (sw && q.hang >= 0) {
            const e = (now - sw.t0) * sp / 1000;
            if (e > 4) delete swings[i];
            else {
              let d = sw.from - q.a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
              a = q.a + d * Math.exp(-e * 1.6) * Math.cos(e * 7);
              const h = holesOf(S.p[i])[q.hang], c = Math.cos(a), s = Math.sin(a);
              cx = q.px - (h[0] * c - h[1] * s); cy = q.py - (h[0] * s + h[1] * c);
            }
          }
          let shx = 0;
          if (shakes['p' + i]) { const k = (now - shakes['p' + i]) / 300; if (k > 1) delete shakes['p' + i]; else shx = Math.sin(k * 30) * 0.9 * (1 - k) * L.fx(); }
          drawPlank(i, cx + shx, cy, a, 1);
          const H2 = holesOf(S.p[i]), f = T.first[i];
          for (let k = 0; k < H2.length; k++) {
            const j = f + k; if (rm[j] === '1' || j === pin) continue;
            const w = toW(cx + shx, cy, a, H2[k][0], H2[k][1]);
            let ox = 0;
            if (shakes[j]) { const e = (now - shakes[j]) / 300; if (e > 1) delete shakes[j]; else ox = Math.sin(e * 30) * 3 * (1 - e) * L.fx(); }
            const hint = S.hint === j ? 'rgba(120,230,255,' + (0.5 + 0.5 * Math.sin(now / 140)).toFixed(2) + ')' : null;
            drawScrew(bx2(w[0]) + ox, by2(w[1]), SR * LY.sc, COLS[S.sc.charCodeAt(j) - 97], a + j, free.has(j) ? 0 : 1, hint);
          }
        }
        // falling planks
        for (let k = falls.length - 1; k >= 0; k--) {
          const F = falls[k], e = (now - F.t0) * sp / 1000;
          const y = F.cy + F.vy * e + 0.5 * 260 * e * e, x = F.cx + F.vx * e;
          if (by2(y) - 80 > H) { falls.splice(k, 1); continue; }
          drawPlank(F.i, x, y, F.a + F.w * e, Math.max(0.15, 1 - e * 0.5));
        }
        // screw in flight: spin out (0..0.35) then arc to slot
        if (fly) {
          fly.t += dt * sp / 640;
          const e = Math.min(1, fly.t);
          let x, y, r = SR * LY.sc, rot;
          if (e < 0.35) {
            const k = e / 0.35;
            x = fly.x0; y = fly.y0 - k * 10; r *= 1 + k * 0.5; rot = k * 12;
          } else {
            const k = (e - 0.35) / 0.65, ee = k * k * (3 - 2 * k);
            x = U.lerp(fly.x0, fly.x1, ee); y = U.lerp(fly.y0 - 10, fly.y1, ee) - Math.sin(k * Math.PI) * 50;
            r = U.lerp(r * 1.5, fly.r1, ee); rot = 12 + k * 6;
          }
          drawScrew(x, y, r, fly.c, rot, 0, null);
          if (e >= 1) land();
        }
        // particles
        for (let k = parts.length - 1; k >= 0; k--) {
          const q = parts[k]; q.l -= dt * sp;
          if (q.l <= 0) { parts.splice(k, 1); continue; }
          q.vy += 0.0009 * dt * sp; q.x += q.vx * dt * sp; q.y += q.vy * dt * sp;
          ctx.globalAlpha = Math.min(1, q.l / 400); ctx.fillStyle = q.c;
          ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(q.l / 90); ctx.fillRect(-q.s / 2, -q.s / 3, q.s, q.s * 0.66); ctx.restore();
        }
        ctx.globalAlpha = 1;
        if (S.won && !fly) {
          ctx.fillStyle = '#e3ae45'; ctx.textAlign = 'center'; ctx.font = '30px "Black Han Sans", sans-serif';
          ctx.fillText('모두 풀었다!', W / 2, LY.oy + BH * LY.sc / 2 + Math.sin(now / 200) * 3);
        }
      }
      function burst(x, y, c, k) {
        for (let i = 0; i < k; i++) {
          const a = Math.random() * Math.PI * 2, v = 0.08 + Math.random() * 0.22;
          parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.2, l: 500 + Math.random() * 500, s: 3 + Math.random() * 5, c });
        }
      }
      function confetti() {
        for (let i = 0; i < 90; i++) parts.push({ x: Math.random() * cvs.w, y: -10 - Math.random() * 120, vx: (Math.random() - 0.5) * 0.12, vy: 0.05 + Math.random() * 0.15, l: 1600 + Math.random() * 1200, s: 5 + Math.random() * 6, c: COLS[i % COLS.length] });
      }
      function land() {
        const F = fly; fly = null;
        api.setBusy(false);
        api.sfx(F.box ? 'chip' : 'tick'); api.buzz(10);
        if (F.box) burst(F.x1, F.y1, F.c, 6); else trayPop = now;
        if (F.done) {
          for (const k of F.done) { const r = boxRect(+k); burst(r.x + r.w / 2, r.y + r.h / 2, F.c, 22); boxIn[k] = now + 160; }
          api.sfx('pop'); api.buzz(25);
        }
        if (F.mv) setTimeout(() => api.sfx('click'), 300 / SP());
        afterState();
      }
      function afterState() {
        if (!S) return;
        if (S.lost && lastLose !== S.last.id) {
          lastLose = S.last.id; api.sfx('lose'); api.buzz(80);
          if (api.canAct(0) && !api.players[0].ai) losePanel();
        }
      }

      /* ---------- input ---------- */
      function hit(px, py) {
        if (!LY || !S) return -1;
        let best = -1, bd = Math.max(22, SR * LY.sc * 2.2);
        const rm = S.rm;
        for (let j = 0; j < T.sp.length; j++) {
          if (rm[j] === '1') continue;
          const w = screwPos(S.p, T, rm, j);
          const d = Math.hypot(bx2(w[0]) - px, by2(w[1]) - py);
          if (d < bd) { bd = d; best = j; }
        }
        return best;
      }
      const onDown = (e) => {
        if (ov || !S || S.won || S.lost || fly || !api.canAct(0)) return;
        const p = cvs.local(e), j = hit(p.x, p.y);
        if (j < 0) return;
        const fr = freeList(S.p, T, S.rm);
        if (fr.indexOf(j) >= 0) { act({ t: 'tap', j }); return; }
        shakes[j] = now; api.sfx('thud'); api.buzz(30);
        // wobble the plank on top
        const w = screwPos(S.p, T, S.rm, j);
        for (let i = S.p.length - 1; i > T.sp[j][0]; i--) { const q = pose(S.p, T, S.rm, i); if (q.n && covers(S.p, q, i, w[0], w[1])) { shakes['p' + i] = now; break; } }
      };
      cv.addEventListener('pointerdown', onDown);
      const offIn = api.input ? api.input.on((type, id) => {
        if (type !== 'down' || !S) return;
        if (id === 'undo') act({ t: 'undo' }); else if (id === 'reset') act({ t: 'reset' }); else if (id === 'hint') act({ t: 'hint' }); else if (id === 'extra') act({ t: 'extra' });
      }) : null;

      rafStop = U.loop((dt) => frame(Math.min(dt * 1000, 50)));

      return {
        update(s, prev) {
          const fresh = !S;
          S = s; T = tables(s.p);
          if (!LY) layout();
          const L0 = s.last || {}, P = prev && prev.last;
          if (prev && prev !== s && P && L0.id !== P.id) {
            if (L0.t === 'tap') {
              const PT = tables(prev.p);
              const w = screwPos(prev.p, PT, prev.rm, L0.j);
              const box = L0.to[0] === 'b';
              const dst = box ? boxSlot(+L0.to[1], +L0.to[2]) : traySlot(+L0.to.slice(1), prev.tc);
              if (fly) { fly.t = 1; land(); }
              fly = { t: 0, j: L0.j, c: COLS[s.sc.charCodeAt(L0.j) - 97], x0: bx2(w[0]), y0: by2(w[1]), x1: dst[0], y1: dst[1], r1: LY.slot * (box ? 0.3 : 0.32), box, done: L0.d ? L0.d.split('') : null, mv: L0.mv, pre: prev };
              api.setBusy(true); api.sfx('whoosh');
              // plank reactions
              const pi = T.sp[L0.j][0], q0 = pose(prev.p, PT, prev.rm, pi), q1 = pose(s.p, T, s.rm, pi);
              if (q1.n === 0) { falls.push({ i: pi, cx: q0.cx, cy: q0.cy, a: q0.a, vx: (Math.random() - 0.5) * 20, vy: -10, w: (Math.random() - 0.5) * 3, t0: now }); setTimeout(() => api.sfx('thud'), 260 / SP()); delete swings[pi]; }
              else if (q1.hang >= 0 && q0.hang < 0) swings[pi] = { t0: now, from: q0.a };
            } else if (L0.t === 'undo') { api.sfx('whoosh'); swings = {}; }
            else if (L0.t === 'extra') { api.sfx('pop'); api.toast('보관 칸이 하나 늘었어요'); closeOv(); }
            else if (L0.t === 'hint') { if (s.hint < 0) api.toast('길이 안 보여요. 되돌리기나 다시 하기를 써 보세요'); else api.sfx('tick'); }
            else if (L0.t === 'new' || L0.t === 'reset') { if (fly) { fly = null; api.setBusy(false); } swings = {}; falls = []; closeOv(); }
            if (L0.t === 'new' && !s.dy) { const o = store(); o.cur = s.lv; save(o); }
            if (L0.t !== 'tap') afterState();
          }
          if (fresh) { DAILY.prune(); const o = store(); o.cur = s.lv; save(o); if (o.max && L.best) L.best.set('screw', 'lv', o.max | 0, { label: '최고 단계', unit: '단계' }); }
          if (s.won && lastWin !== L0.id && prev && !prev.won) {
            lastWin = L0.id;
            if (s.dy) {
              if (api.canAct(0) && !api.players[0].ai && DAILY.complete(s.dy, s.m, api)) api.toast('오늘 최고 기록!');
              setTimeout(() => { if (!S || !S.won) return; confetti(); api.sfx('win'); api.buzz(60); if (api.canAct(0) && !api.players[0].ai) winPanel(); }, 900 / SP());
              refreshBar(); return;
            }
            const o = store(); o.best = o.best || {};
            const ob = o.best[s.lv]; if (!ob || s.m < ob) { o.best[s.lv] = s.m; if (ob) api.toast('새 최고 기록!'); }
            o.max = Math.max(o.max | 0, s.lv); o.cur = s.lv + 1; save(o);
            if (api.canAct(0)) api.best('lv', o.max, { label: '최고 단계', unit: '단계' });
            setTimeout(() => { if (!S || !S.won) return; confetti(); api.sfx('win'); api.buzz(60); if (api.canAct(0) && !api.players[0].ai) winPanel(); }, 900 / SP());
          }
          refreshBar();
        },
        destroy() { if (rafStop) rafStop(); cv.removeEventListener('pointerdown', onDown); if (offIn) offIn(); closeOv(); bar.remove(); api.setBusy(false); cvs.destroy(); },
      };
    },
  };
  def._solve = solve; def._gen = gen; def._daily = DAILY;
  L.register(def);
})();
