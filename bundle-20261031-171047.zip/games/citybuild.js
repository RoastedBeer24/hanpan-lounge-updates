/* 도시 건설 — 위에서 내려다보는 격자 도시 만들기(실시간). 라운드 43 리메이크.
   도시 하나 = 타입 배열 묶음(C). 순수 시뮬(sim)은 DOM이 없어서 뷰·AI 시장·node 시험이 같이 쓴다.
   하루 = 틱, 30일 = 한 달. 한 달 동안 「작업 줄」(망 → 서비스 범위 → 환경 → 수요 → 성장 → 교통 → 수거)이
   프레임마다 시간 예산만큼 나눠 돌고, 달이 끝나면 예산·이정표·재해를 정산한다.
   멀티: 「각자 도시 인구 경쟁」 — 모두 같은 지형(같은 seed)에서 자기 기기에서 자기 도시를 짓고, 호스트가 달(시계)을
   쥐고 각 도시의 통계·작은 지도만 주고받는다(상태가 작다). AI 도시는 호스트 기기에서 같은 시뮬로 돈다.
   판 밖 성장 없음(이정표 해금은 그 도시 안에서만). */
(function () {
  const L = window.Lounge, U = L.util;
  const KEY = 'lounge.citybuild.v2', TIP = 'lounge.citybuild.tip2';
  const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const won = (v) => (v < 0 ? '−' : '') + '₩' + Math.round(Math.abs(v)).toLocaleString('en-US');
  const num = (v) => Math.round(v).toLocaleString('en-US');

  /* ================= 데이터 ================= */
  const MAPS = ['river', 'coast', 'lake', 'hills'];
  const MAPN = { river: '굽이치는 강', coast: '바닷가', lake: '호수 분지', hills: '산골짜기' };
  /* 구역: k = 수요 종류. cap[레벨] = 칸 하나의 주민 수(주거) 또는 일자리 수 */
  const ZN = [null,
    { id: 'rl', n: '주거 · 저밀', s: '주거', k: 'R', cap: [0, 4, 5, 6, 7, 8], col: '#7cc46f', tier: 0, d: '단독·연립 주택. 땅값이 오르면 집이 좋아져요.' },
    { id: 'rh', n: '주거 · 고밀', s: '고밀 주거', k: 'R', cap: [0, 14, 20, 28, 38, 50], col: '#4d9a48', tier: 3, d: '아파트. 한 칸에 많이 살지만 교육·의료·치안이 필요해요.' },
    { id: 'cl', n: '상업 · 저밀', s: '상업', k: 'C', cap: [0, 3, 4, 5, 6, 7], col: '#62a6ea', tier: 0, d: '동네 가게. 주민이 물건을 사러 와요.' },
    { id: 'ch', n: '상업 · 고밀', s: '고밀 상업', k: 'C', cap: [0, 10, 14, 18, 23, 28], col: '#3b7cc6', tier: 3, d: '백화점·상가. 시끄럽지만 세금이 많아요.' },
    { id: 'in', n: '산업', s: '산업', k: 'I', cap: [0, 8, 10, 12, 14, 16], col: '#e6ad45', tier: 0, d: '공장·창고. 일자리가 많지만 공기·땅을 더럽히고 화물차가 다녀요.' },
    { id: 'of', n: '사무', s: '사무', k: 'O', cap: [0, 12, 16, 20, 25, 30], col: '#a387e6', tier: 4, d: '오염 없는 사무실. 교육받은 주민이 많아야 자라요.' },
  ];
  const ZK = ['R', 'C', 'I', 'O'];
  const Z_RL = 1, Z_RH = 2, Z_CL = 3, Z_CH = 4, Z_I = 5, Z_O = 6;
  /* 도로: cap = 한 달 통행 용량(표본 기준), sp = 속도 배율, nz = 소음 */
  const RD = [null,
    { id: 'r2', n: '2차선 도로', cost: 30, up: 0.15, cap: 900, sp: 1, nz: 1, zone: 1, tier: 0, d: '기본 도로. 양옆에 구역을 칠할 수 있어요.' },
    { id: 'r4', n: '4차선 도로', cost: 90, up: 0.45, cap: 2400, sp: 1.25, nz: 2, zone: 1, tier: 2, d: '차가 많이 다니는 길. 시끄러워요.' },
    { id: 'r1', n: '일방통행', cost: 40, up: 0.2, cap: 1400, sp: 1.2, nz: 1, zone: 1, tier: 1, one: 1, d: '끈 방향으로만 달려요. 교차로가 덜 막혀요.' },
    { id: 'hw', n: '고속도로', cost: 220, up: 1.1, cap: 6000, sp: 2.6, nz: 4, zone: 0, tier: 2, d: '아주 빠르고 넓은 길. 옆에 구역을 칠할 수 없어요. 일반 도로와 닿는 곳이 나들목이 돼요.' },
  ];
  const BRIDGE = 4; // 물 위 다리 = 값 ×4
  const PIPE_COST = 10, PLINE_COST = 12;
  /* 서비스·시설 */
  const SV = [
    // 전기
    { id: 'wind', n: '풍력 발전기', g: 'pw', ic: '🌬️', cost: 1500, up: 18, sz: 1, pw: 8, tier: 0, np: 1, col: '#d6dde3', d: '깨끗한 전기. 높은 곳일수록 더 많이 만들어요.' },
    { id: 'coal', n: '석탄 발전소', g: 'pw', ic: '🏭', cost: 9000, up: 110, sz: 2, pw: 42, air: 70, tier: 0, np: 1, col: '#6d6168', d: '싸고 많은 전기. 공기를 크게 더럽혀요.' },
    { id: 'gas', n: '가스 발전소', g: 'pw', ic: '🔥', cost: 15000, up: 170, sz: 2, pw: 70, air: 25, tier: 3, np: 1, col: '#8a7d6d', d: '석탄보다 깨끗하고 힘이 세요.' },
    { id: 'solar', n: '태양광 단지', g: 'pw', ic: '☀️', cost: 24000, up: 150, sz: 3, pw: 60, tier: 4, np: 1, col: '#2f4c78', d: '오염 없는 전기. 땅을 넓게 써요.' },
    { id: 'nuke', n: '원자력 발전소', g: 'pw', ic: '☢️', cost: 90000, up: 650, sz: 3, pw: 450, tier: 6, np: 1, col: '#b8b3a8', d: '아주 많은 전기. 비싸요.' },
    // 상수
    { id: 'pump', n: '취수장', g: 'wt', ic: '💧', cost: 2500, up: 28, sz: 1, wt: 45, shore: 1, tier: 0, col: '#5b8fb0', d: '물가에 지어 물을 끌어와요. 하수 배출구 아래쪽 물을 퍼 오면 주민이 병나요.' },
    { id: 'tower', n: '급수탑', g: 'wt', ic: '🗼', cost: 4000, up: 45, sz: 1, wt: 20, tier: 1, col: '#7395a8', d: '물가가 아니어도 되지만 양이 적어요. 땅이 오염되면 물도 더러워져요.' },
    { id: 'purif', n: '정수장', g: 'wt', ic: '🌊', cost: 18000, up: 190, sz: 2, wt: 170, shore: 1, clean: 1, tier: 4, col: '#4d86a8', d: '물가. 물을 아주 많이, 언제나 깨끗하게.' },
    // 하수
    { id: 'outlet', n: '하수 배출구', g: 'sw', ic: '🕳️', cost: 2000, up: 24, sz: 1, sw: 50, shore: 1, wp: 1, tier: 0, col: '#5f6a52', d: '물가에 하수를 흘려보내요. 물을 더럽혀요 — 취수장과 멀리!' },
    { id: 'sewage', n: '하수 처리장', g: 'sw', ic: '♻️', cost: 20000, up: 210, sz: 2, sw: 180, shore: 1, wp: 0.15, tier: 3, col: '#5b7a6a', d: '물가. 하수를 깨끗이 걸러 내보내요.' },
    // 쓰레기
    { id: 'landfill', n: '쓰레기 매립지', g: 'gar', ic: '🗑️', cost: 5000, up: 55, sz: 2, r: 16, store: 20000, gnd: 30, tier: 0, col: '#7d7356', d: '쓰레기차가 반경 안을 돌며 모아 묻어요. 가득 차면 못 모아요. 땅을 더럽혀요.' },
    { id: 'incin', n: '소각장', g: 'gar', ic: '🔥', cost: 18000, up: 200, sz: 2, r: 22, proc: 900, air: 30, pw: 6, tier: 3, col: '#6b5f58', d: '쓰레기를 태워 없애고 전기도 조금. 공기를 더럽혀요.' },
    { id: 'recyc', n: '재활용 센터', g: 'gar', ic: '♻️', cost: 24000, up: 240, sz: 2, r: 22, proc: 650, tier: 5, col: '#5f8a64', d: '깨끗하게 쓰레기를 처리해요.' },
    // 묘지
    { id: 'cem', n: '추모 공원', g: 'dead', ic: '⚱️', cost: 4000, up: 40, sz: 2, r: 18, store: 2500, tier: 1, np: 1, col: '#7f8a72', d: '세상을 떠난 주민을 모셔요. 가득 차면 더 못 받아요.' },
    { id: 'crem', n: '화장장', g: 'dead', ic: '🕯️', cost: 14000, up: 150, sz: 2, r: 24, proc: 160, tier: 4, col: '#8a8178', d: '반경 넓게, 가득 차지 않아요.' },
    // 소방·치안·의료
    { id: 'fire', n: '소방서', g: 'fire', ic: '🚒', cost: 4000, up: 60, sz: 1, r: 11, tier: 1, col: '#b04a3c', d: '반경 안 불을 빨리 꺼요. 불이 덜 나요.' },
    { id: 'firehq', n: '소방 본부', g: 'fire', ic: '🧯', cost: 16000, up: 190, sz: 2, r: 20, tier: 4, col: '#a34236', d: '넓은 지역 화재 대응.' },
    { id: 'police', n: '파출소', g: 'pol', ic: '🚓', cost: 4000, up: 60, sz: 1, r: 11, tier: 1, col: '#4a62a8', d: '범죄를 줄여요. 상업이 자라는 데 필요해요.' },
    { id: 'polhq', n: '경찰청', g: 'pol', ic: '🚔', cost: 16000, up: 190, sz: 2, r: 20, tier: 4, col: '#3f5596', d: '넓은 지역 치안.' },
    { id: 'clinic', n: '보건소', g: 'hlth', ic: '💊', cost: 4500, up: 70, sz: 1, r: 11, tier: 1, col: '#d9d3c7', d: '주민 건강. 덜 아프고 오래 살아요.' },
    { id: 'hosp', n: '종합 병원', g: 'hlth', ic: '🏥', cost: 20000, up: 250, sz: 2, r: 20, tier: 3, col: '#e4e0d8', d: '넓은 지역 의료.' },
    // 교육
    { id: 'elem', n: '초등학교', g: 'edu1', ic: '🏫', cost: 4000, up: 70, sz: 1, r: 10, tier: 1, col: '#c49a5a', d: '기초 교육. 주거 3단계부터 필요해요.' },
    { id: 'high', n: '고등학교', g: 'edu2', ic: '🏫', cost: 12000, up: 170, sz: 2, r: 15, tier: 3, col: '#b0874e', d: '중등 교육. 주거 4단계·산업·사무가 자라는 데 필요해요.' },
    { id: 'univ', n: '대학교', g: 'edu3', ic: '🎓', cost: 40000, up: 420, sz: 3, r: 26, tier: 5, col: '#9a6f4a', d: '고등 교육. 주거 5단계·사무 고층에 필요해요.' },
    // 공원
    { id: 'park', n: '작은 공원', g: 'park', ic: '🌳', cost: 600, up: 6, sz: 1, r: 5, tier: 0, np: 1, col: '#4f8a4a', d: '땅값·행복을 올리고 공기를 조금 맑게 해요.' },
    { id: 'plaza', n: '광장', g: 'park', ic: '⛲', cost: 1600, up: 12, sz: 1, r: 6, tier: 1, np: 1, col: '#9a9a8a', d: '분수가 있는 광장. 상업 땅값 +.' },
    { id: 'bigpark', n: '큰 공원', g: 'park', ic: '🌲', cost: 5000, up: 40, sz: 2, r: 10, tier: 2, np: 1, col: '#467f42', d: '연못이 있는 공원.' },
    { id: 'garden', n: '식물원', g: 'park', ic: '🌺', cost: 15000, up: 100, sz: 3, r: 14, tier: 4, np: 1, tour: 2, col: '#3f7a3f', d: '넓은 범위 땅값·행복 +, 관광객도 와요.' },
    { id: 'stadium', n: '경기장', g: 'lm', ic: '🏟️', cost: 40000, up: 300, sz: 3, tier: 5, uniq: 1, hapC: 4, tour: 6, col: '#8a8f99', d: '도시 전체 행복 +4, 관광 +.' },
    // 대중교통
    { id: 'depot', n: '버스 차고지', g: 'tr', ic: '🚌', cost: 6000, up: 70, sz: 2, depot: 1, tier: 2, col: '#c99a36', d: '버스 노선을 굴리려면 하나는 있어야 해요(노선 8개까지).' },
    { id: 'stop', n: '버스 정류장', g: 'tr', ic: '🚏', cost: 300, up: 3, sz: 1, stop: 'bus', tier: 2, np: 1, col: '#d9b44a', d: '도로 옆에. 「노선」 도구로 정류장을 차례로 눌러 노선을 만들어요. 반경 5칸.' },
    { id: 'metro', n: '지하철역', g: 'tr', ic: '🚇', cost: 9000, up: 90, sz: 1, stop: 'metro', tier: 4, col: '#7a5fb0', d: '역끼리 땅속으로 이어요. 반경 8칸, 많이 타요. 전기가 필요해요.' },
    { id: 'rail', n: '기차역', g: 'tr', ic: '🚉', cost: 20000, up: 180, sz: 2, rail: 1, r: 12, tier: 3, uniq: 1, tour: 3, col: '#8a7a96', d: '바깥 도시와 잇는 철도역. 상업·산업 수요 +, 관광 +, 반경 12칸 주민이 기차로 다녀요.' },
    // 랜드마크·특수
    { id: 'hall', n: '시청', g: 'lm', ic: '🏛️', cost: 20000, up: 140, sz: 3, tier: 3, uniq: 1, hapC: 3, aur: [10, 18], adm: 1, col: '#d8cdb0', d: '도시 전체 행복 +3, 주변 땅값 +, 지구·정책 비용 −25%.' },
    { id: 'museum', n: '박물관', g: 'lm', ic: '🏺', cost: 26000, up: 180, sz: 2, tier: 4, uniq: 1, hapC: 2, tour: 8, aur: [9, 25], col: '#b9a27c', d: '관광객이 와요. 주변 땅값 크게 +.' },
    { id: 'obs', n: '전망 타워', g: 'lm', ic: '🗼', cost: 35000, up: 220, sz: 2, tier: 5, uniq: 1, hapC: 2, tour: 10, aur: [12, 20], col: '#c9c2d8', d: '도시의 상징. 관광 크게 +.' },
    { id: 'port', n: '화물항', g: 'sp', ic: '⚓', cost: 30000, up: 220, sz: 3, tier: 3, uniq: 1, sea: 1, bI: 25, nz: 6, col: '#5d6f7d', d: '바다 옆(바닷가 지형)에만. 산업 수요 크게 +, 화물차가 늘어요.' },
    { id: 'airport', n: '공항', g: 'sp', ic: '✈️', cost: 80000, up: 600, sz: 4, tier: 6, uniq: 1, tour: 15, bC: 20, nz: 12, col: '#6d7078', d: '상업·관광 크게 +. 주변이 아주 시끄러워요.' },
  ];
  const SVI = {}; SV.forEach((s, i) => { SVI[s.id] = i; });
  const COVG = ['fire', 'pol', 'hlth', 'edu1', 'edu2', 'edu3', 'park'];
  const BUDG = [
    ['pw', '⚡ 전기'], ['wt', '💧 상하수도'], ['gar', '🗑️ 쓰레기·묘지'], ['fire', '🚒 소방'], ['pol', '🚓 치안'],
    ['hlth', '🏥 의료'], ['edu', '🏫 교육'], ['park', '🌳 공원'], ['tr', '🚌 대중교통'], ['road', '🛣️ 도로'],
  ];
  const bgOf = (g) => (g === 'sw' ? 'wt' : g === 'dead' ? 'gar' : g === 'edu1' || g === 'edu2' || g === 'edu3' ? 'edu' : g === 'lm' || g === 'sp' ? null : g);
  /* 이정표(인구 단계) */
  const TIERS = [
    { n: '빈 터', p: 0, gift: 0, cap: 2 },
    { n: '작은 마을', p: 300, gift: 5000, cap: 2 },
    { n: '마을', p: 1000, gift: 10000, cap: 3 },
    { n: '읍', p: 2500, gift: 15000, cap: 3 },
    { n: '소도시', p: 6000, gift: 25000, cap: 4 },
    { n: '도시', p: 13000, gift: 40000, cap: 4 },
    { n: '대도시', p: 26000, gift: 60000, cap: 5 },
    { n: '광역 도시', p: 50000, gift: 90000, cap: 5 },
    { n: '거대 도시', p: 90000, gift: 120000, cap: 5 },
  ];
  /* 정책: c = 한 달 비용(대상 건물 칸당), tier, k = 적용 대상 */
  const POL = [
    { id: 'recycle', n: '분리배출', ic: '♻️', c: 0.6, tier: 2, d: '쓰레기 −35%. 건물마다 비용이 조금.' },
    { id: 'smoke', n: '금연 거리', ic: '🚭', c: 0.5, tier: 2, d: '주민 건강 +(사망 −25%), 행복 +2.' },
    { id: 'freebus', n: '무료 대중교통', ic: '🎫', c: 0, tier: 2, d: '대중교통 이용 +15%p. 요금 수입 없음.' },
    { id: 'lowrise', n: '고층 제한', ic: '🏘️', c: 0, tier: 2, d: '건물이 3단계까지만 자라요. 땅값 +5.' },
    { id: 'green', n: '친환경 산업', ic: '🍃', c: 0.8, tier: 3, d: '산업 오염 −60%. 산업 세금 −10%.' },
    { id: 'quiet', n: '소음 규제', ic: '🔇', c: 0.3, tier: 2, d: '소음 −50%. 상업 세금 −10%.' },
    { id: 'saveP', n: '전기 아껴 쓰기', ic: '💡', c: 0.3, tier: 2, d: '전기 사용 −15%.' },
    { id: 'saveW', n: '물 아껴 쓰기', ic: '🚿', c: 0.3, tier: 2, d: '물·하수 −20%, 행복 −1.' },
    { id: 'hitech', n: '첨단 산업 지구', ic: '🔬', c: 1.2, tier: 5, d: '산업 오염 거의 없음, 세금 +20%. 교육(고교 이상)이 필요해요.' },
    { id: 'tour', n: '관광 특구', ic: '🎡', c: 0.8, tier: 4, d: '상업 세금 +15%, 관광 +. 소음 +.' },
  ];
  const POLI = {}; POL.forEach((p, i) => { POLI[p.id] = 1 << i; });
  const DISTN = ['도시 전체', '가 지구', '나 지구', '다 지구', '라 지구', '마 지구', '바 지구'];
  const DISTC = ['#ffffff', '#ef7b5a', '#5fc3e4', '#8fd16b', '#e28fd0', '#f2c14e', '#b9a0ff'];
  const LINEC = ['#f2c14e', '#ef7b5a', '#5fc3e4', '#8fd16b', '#e28fd0', '#f0e6c8', '#ff9f43', '#7bed9f', '#70a1ff', '#ff6b81', '#eccc68', '#a4b0be', '#c56cf0', '#3ae374'];
  const LOANS = [{ a: 30000, mo: 24, r: 0.04, tier: 0 }, { a: 80000, mo: 60, r: 0.06, tier: 2 }, { a: 200000, mo: 120, r: 0.08, tier: 4 }];
  const PB = { pw: 1, wt: 2, sw: 4, gar: 8, dead: 16, road: 32, sick: 64, fire: 128 };
  const PBN = [['pw', '⚡', '전기가 안 들어와요'], ['wt', '💧', '물이 안 나와요'], ['sw', '🚽', '하수가 안 빠져요'], ['gar', '🗑️', '쓰레기가 쌓였어요'], ['dead', '⚱️', '추모 공원이 필요해요'], ['road', '🚗', '도로와 이어지지 않았어요'], ['sick', '🤢', '더러운 물 때문에 아파요'], ['fire', '🔥', '불이 났어요!']];

  /* ================= 난수·잡음 ================= */
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function rnd(C) { const a = C.rs = (C.rs + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  const hash = (i, s) => { let h = Math.imul(i ^ (s | 0), 2654435761) | 0; h = Math.imul(h ^ (h >>> 15), 2246822519); h = Math.imul(h ^ (h >>> 13), 3266489917); return ((h ^ (h >>> 16)) >>> 0) % 1000; };
  function vnoise(R, n, cell) {
    const g = Math.ceil(n / cell) + 2, v = new Float32Array(g * g); for (let i = 0; i < v.length; i++) v[i] = R();
    const o = new Float32Array(n * n);
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) {
      const fx = x / cell, fy = y / cell, ix = Math.floor(fx), iy = Math.floor(fy); let tx = fx - ix, ty = fy - iy;
      tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty);
      const a = v[iy * g + ix], b = v[iy * g + ix + 1], c = v[(iy + 1) * g + ix], d = v[(iy + 1) * g + ix + 1];
      o[y * n + x] = a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
    }
    return o;
  }
  function fbm(R, n, base) { const o = new Float32Array(n * n); let amp = 1, tot = 0; for (let k = 0, cell = base; k < 4 && cell >= 2; k++, cell /= 2, amp *= 0.5) { const v = vnoise(R, n, cell); for (let i = 0; i < o.length; i++) o[i] += v[i] * amp; tot += amp; } for (let i = 0; i < o.length; i++) o[i] /= tot; return o; }

  /* ================= 지형 ================= */
  function genTerrain(C) {
    const N = C.N, NN = N * N, R = prng(C.seed * 7919 + 17);
    let mp = C.mp; if (!MAPS.includes(mp)) { mp = MAPS[Math.floor(R() * MAPS.length)]; C.mp = mp; }
    const h = fbm(R, N, N / 3), f = fbm(R, N, N / 6);
    const ter = C.ter, ht = C.ht, fr = C.fr;
    for (let i = 0; i < NN; i++) { let v = h[i]; if (mp === 'hills') v = Math.pow(v, 0.8) * 1.12; else v = v * 0.85; ht[i] = clamp(Math.round(v * 255), 0, 255); }
    const water = new Uint8Array(NN);
    const carve = (cx, cy, rr) => { for (let y = Math.floor(cy - rr); y <= cy + rr; y++) for (let x = Math.floor(cx - rr); x <= cx + rr; x++) if (x >= 0 && y >= 0 && x < N && y < N && (x - cx) * (x - cx) + (y - cy) * (y - cy) <= rr * rr) water[y * N + x] = 1; };
    const river = (w) => { // 한쪽 가장자리에서 반대편까지 굽이치는 강
      const vert = R() < 0.5; let p = N * (0.3 + R() * 0.4), dp = 0;
      for (let t = -2; t < N + 2; t++) { dp = clamp(dp + (R() - 0.5) * 0.5, -0.9, 0.9); p = clamp(p + dp, N * 0.12, N * 0.88); const ww = w + Math.sin(t / 9) * 0.6; if (vert) carve(p, t, ww); else carve(t, p, ww); }
    };
    if (mp === 'river') { river(2.2 + R() * 0.8); if (R() < 0.5) { // 지류
      const vert = R() < 0.5; let p = N * (0.2 + R() * 0.6); const len = N * (0.3 + R() * 0.3); for (let t = 0; t < len; t++) { p += (R() - 0.5) * 1.2; if (vert) carve(p, t, 1.2); else carve(t, p, 1.2); } } }
    else if (mp === 'coast') {
      const side = Math.floor(R() * 4), nz = fbm(R, N, N / 4);
      for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { const d = side === 0 ? y : side === 1 ? N - 1 - x : side === 2 ? N - 1 - y : x; if (d < N * 0.16 + nz[y * N + x] * N * 0.14) water[y * N + x] = 1; }
      C.seaSide = side; if (R() < 0.6) { let p = N * (0.3 + R() * 0.4); for (let t = 0; t < N; t++) { p += (R() - 0.5) * 1.4; const xx = side === 1 || side === 3 ? t : p, yy = side === 1 || side === 3 ? p : t; carve(xx, yy, 1.3); } }
    } else if (mp === 'lake') {
      const k = 2 + Math.floor(R() * 2); for (let j = 0; j < k; j++) { const cx = N * (0.25 + R() * 0.5), cy = N * (0.25 + R() * 0.5), rr = N * (0.07 + R() * 0.07); for (let a = 0; a < 7; a++) carve(cx + (R() - 0.5) * rr * 1.6, cy + (R() - 0.5) * rr * 1.6, rr * (0.5 + R() * 0.5)); }
      river(1.3);
    } else { river(1.4); }
    const lowest = (mp === 'hills') ? 0.0 : 0;
    for (let i = 0; i < NN; i++) {
      if (water[i]) { ter[i] = 1; ht[i] = Math.min(ht[i], 40 + lowest); continue; }
      ter[i] = ht[i] > (mp === 'hills' ? 222 : 236) ? 2 : 0;
      fr[i] = ter[i] === 0 && f[i] > 0.6 ? 1 : 0;
    }
    // 물가 근처는 낮게(둑)
    for (let pass = 0; pass < 2; pass++) for (let i = 0; i < NN; i++) if (!ter[i]) { const x = i % N, y = (i / N) | 0; let wn = 0; for (let d = 0; d < 4; d++) { const xx = x + DX[d], yy = y + DY[d]; if (xx >= 0 && yy >= 0 && xx < N && yy < N && ter[yy * N + xx] === 1) wn++; } if (wn) ht[i] = Math.min(ht[i], 70 + pass * 25); }
    // 바깥 도시와 잇는 고속도로(가장자리 → 안쪽)
    let best = null;
    for (let side = 0; side < 4; side++) for (let k = 0; k < 9; k++) {
      const p = Math.floor(N * (0.3 + 0.05 * k)), len = Math.floor(N * 0.2); let ok = 0, bad = 0, cells = [];
      for (let t = 0; t < len; t++) { const x = side === 0 ? p : side === 1 ? N - 1 - t : side === 2 ? p : t, y = side === 0 ? t : side === 1 ? p : side === 2 ? N - 1 - t : p; const i = y * N + x; cells.push(i); if (ter[i] === 0) ok++; else bad += ter[i] === 2 ? 99 : 3; }
      const sc = ok - bad + R() * 2; if (!best || sc > best.sc) best = { sc, cells };
    }
    for (const i of best.cells) { if (ter[i] === 2) ter[i] = 0; C.rd[i] = 4; fr[i] = 0; }
    C.hwEnd = best.cells[best.cells.length - 1]; C.hwStart = best.cells[0];
  }
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];

  /* ================= 도시 ================= */
  const ARR8 = ['ter', 'ht', 'fr', 'rd', 'rdir', 'zn', 'bl', 'ab', 'pi', 'pl', 'dist', 'gar', 'dead', 'gnd8'];
  function alloc(C) {
    const NN = C.N * C.N;
    for (const k of ARR8) C[k] = new Uint8Array(NN);
    C.ob = new Int16Array(NN);       // 시설 번호+1
    C.acc = new Int32Array(NN);      // 가장 가까운 구역용 도로 칸(−1)
    C.accD = new Uint8Array(NN);     // 거리
    C.pw = new Uint8Array(NN); C.wt = new Uint8Array(NN); C.sw = new Uint8Array(NN); C.sick = new Uint8Array(NN);
    C.wc = new Int16Array(NN);       // 상수 망 번호(커버)
    C.cov = {}; for (const g of COVG) C.cov[g] = new Uint8Array(NN);
    C.aur = new Uint8Array(NN); C.lmask = new Uint16Array(NN); C.trc = new Uint8Array(NN);
    C.air = new Float32Array(NN); C.nz = new Float32Array(NN); C.gnd = new Float32Array(NN); C.wpol = new Float32Array(NN);
    C.lv = new Uint8Array(NN); C.hap = new Uint8Array(NN); C.pb = new Uint8Array(NN);
    C.vol = new Float32Array(NN); C.nvol = new Float32Array(NN); C.cong = new Uint8Array(NN);
    C.burn = new Uint8Array(NN);
    C._paths = []; C._pi = 0;
  }
  function newCity(o) {
    const C = {
      v: 2, N: o.n || 100, seed: o.seed >>> 0, mp: o.mp || 'rand', dis: o.dis ? 1 : 0, md: o.md || 'sand', goal: o.goal || 0,
      m: 70000, tier: 0, mo: 0, day: 0, rs: (o.seed * 31 + 7) | 0,
      tax: { R: 9, C: 9, I: 9, O: 9 }, bud: {}, pol: [0, 0, 0, 0, 0, 0, 0], B: [], lines: [], loans: [], hist: [], news: [], nid: 0,
      st: null, fin: null, fires: [], seaSide: -1, mx: 0, built: 0,
    };
    for (const [k] of BUDG) C.bud[k] = 100;
    alloc(C); genTerrain(C); emptyStats(C);
    netsDirty(C); computeAcc(C); C.job = { s: 0, k: 0 };
    return C;
  }
  function emptyStats(C) {
    C.st = { pop: 0, jobs: { R: 0, C: 0, I: 0, O: 0 }, wk: 0, dem: { R: 60, C: 30, I: 40, O: 0 }, hap: 60, pwP: 0, pwU: 0, wtP: 0, wtU: 0, swP: 0, swU: 0,
      garP: 0, garU: 0, dP: 0, dU: 0, flow: 100, rid: 0, rail: 0, tour: 0, edu: [0, 0, 0], crime: 0, unemp: 0, bld: 0, ab: 0, lvAvg: 0, sickN: 0, noRoute: 0, polC: 0, cnt: [0, 0, 0, 0, 0, 0, 0], prob: {} };
    C.fin = { inc: {}, exp: {}, net: 0 };
  }
  function news(C, t, txt, c) { C.nid++; C.news.push({ id: C.nid, t, txt, c: c == null ? -1 : c, mo: C.mo }); if (C.news.length > 40) C.news.shift(); }
  const netsDirty = (C) => { C._dn = 1; };
  const polAt = (C, i) => C.pol[0] | C.pol[C.dist[i]];
  const hasPol = (C, i, id) => (polAt(C, i) & POLI[id]) !== 0;
  const capOf = (C, i) => { const z = C.zn[i], b = C.bl[i]; if (!z || !b || (C.ab[i] & 128)) return 0; return ZN[z].cap[b]; };
  const zkOf = (z) => (z ? ZN[z].k : '');
  const bmul = (C, g) => { const k = bgOf(g); return k ? C.bud[k] / 100 : 1; };

  /* ---------- 도로 접근 ---------- */
  function computeAcc(C) {
    const N = C.N, NN = N * N, acc = C.acc, ad = C.accD, rd = C.rd, ter = C.ter;
    acc.fill(-1); ad.fill(255);
    const q = new Int32Array(NN); let qh = 0, qt = 0;
    for (let i = 0; i < NN; i++) if (rd[i] && RD[rd[i]].zone) { acc[i] = i; ad[i] = 0; q[qt++] = i; }
    while (qh < qt) {
      const i = q[qh++], d = ad[i]; if (d >= 3) continue; const x = i % N, y = (i / N) | 0;
      for (let k = 0; k < 4; k++) { const xx = x + DX[k], yy = y + DY[k]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (ad[j] !== 255 || rd[j] || ter[j]) continue; ad[j] = d + 1; acc[j] = acc[i]; q[qt++] = j; }
    }
  }
  function fpCells(C, x, y, sz) { const o = []; for (let yy = y; yy < y + sz; yy++) for (let xx = x; xx < x + sz; xx++) o.push(yy * C.N + xx); return o; }
  function roadAdj(C, b) { // 시설 둘레에 구역용 도로가 닿는지 → 그 도로 칸
    const N = C.N, s = SV[b.t].sz;
    for (let yy = b.y - 1; yy <= b.y + s; yy++) for (let xx = b.x - 1; xx <= b.x + s; xx++) {
      if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const inside = xx >= b.x && xx < b.x + s && yy >= b.y && yy < b.y + s; if (inside) continue;
      if ((xx === b.x - 1 || xx === b.x + s) && (yy === b.y - 1 || yy === b.y + s)) continue; // 모서리 제외
      const j = yy * N + xx; if (C.rd[j]) return j;
    }
    return -1;
  }

  /* ---------- 전력망 ---------- */
  const PW_OFF = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1], [2, 0], [-2, 0], [0, 2], [0, -2]];
  function useOf(C, i) { const c = capOf(C, i); if (!c) return 0; const k = zkOf(C.zn[i]); return c * (k === 'I' ? 0.032 : k === 'R' ? 0.018 : 0.024) * (hasPol(C, i, 'saveP') ? 0.85 : 1); }
  function wuseOf(C, i) { const c = capOf(C, i); if (!c) return 0; const k = zkOf(C.zn[i]); return c * (k === 'I' ? 0.03 : 0.02) * (hasPol(C, i, 'saveW') ? 0.8 : 1); }
  function plantOut(C, b) { const s = SV[b.t]; if (!s.pw) return 0; let v = s.pw * Math.min(1.2, 0.5 + 0.5 * bmul(C, 'pw')); if (s.id === 'wind') v *= 0.6 + C.ht[b.y * C.N + b.x] / 255 * 0.9; if (s.g === 'gar') v = s.pw * (b.on ? 1 : 0); return v; }
  function computePower(C) {
    const N = C.N, NN = N * N, comp = new Int32Array(NN).fill(-1), pw = C.pw; pw.fill(0);
    const isC = (i) => (C.bl[i] && C.zn[i]) || C.ob[i] || C.pl[i] || C.rd[i]; // 도로도 전기를 실어 날라요(간략)
    const q = new Int32Array(NN); let nc = 0, P = 0, U = 0; const prod = [], use = [];
    for (let s = 0; s < NN; s++) {
      if (comp[s] >= 0 || !isC(s)) continue;
      let qh = 0, qt = 0; q[qt++] = s; comp[s] = nc; let pr = 0, us = 0;
      while (qh < qt) {
        const i = q[qh++], x = i % N, y = (i / N) | 0;
        us += useOf(C, i);
        for (const [dx, dy] of PW_OFF) { const xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (comp[j] >= 0 || !isC(j)) continue; if ((dx === 2 || dx === -2 || dy === 2 || dy === -2) && !C.rd[(y + dy / 2) * N + x + dx / 2] && !isC((y + dy / 2) * N + x + dx / 2)) continue; comp[j] = nc; q[qt++] = j; }
      }
      prod.push(0); use.push(us); nc++;
    }
    for (const b of C.B) if (b) { const s = SV[b.t], a = b.y * N + b.x, c = comp[a]; if (c < 0) continue; if (s.pw) prod[c] += plantOut(C, b); else if (!s.np) use[c] += s.sz * s.sz * 0.6; }
    for (let c = 0; c < nc; c++) { P += prod[c]; U += use[c]; }
    for (let i = 0; i < NN; i++) { const c = comp[i]; if (c < 0) continue; const f = use[c] > 0 ? prod[c] / use[c] : 1; pw[i] = f >= 1 || hash(i, 11) < f * 1000 ? 1 : 0; }
    for (const b of C.B) if (b && SV[b.t].pw) for (const j of fpCells(C, b.x, b.y, SV[b.t].sz)) pw[j] = 1;
    C.st.pwP = P; C.st.pwU = U; C._pcomp = comp;
  }
  /* ---------- 상하수도 ---------- */
  function computeWater(C) {
    const N = C.N, NN = N * N, pi = C.pi, comp = new Int16Array(NN).fill(-1);
    const q = new Int32Array(NN); let nc = 0;
    const isP = (j) => pi[j] || (C.ob[j] && C.B[C.ob[j] - 1] && (SV[C.B[C.ob[j] - 1].t].wt || SV[C.B[C.ob[j] - 1].t].sw)); // 시설도 관을 이어 줌
    for (let s = 0; s < NN; s++) {
      if (!isP(s) || comp[s] >= 0) continue; let qh = 0, qt = 0; q[qt++] = s; comp[s] = nc;
      while (qh < qt) { const i = q[qh++], x = i % N, y = (i / N) | 0; for (let k = 0; k < 4; k++) { const xx = x + DX[k], yy = y + DY[k]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (comp[j] < 0 && isP(j)) { comp[j] = nc; q[qt++] = j; } } }
      nc++;
    }
    const sup = new Float32Array(nc + 1), swc = new Float32Array(nc + 1), dirty = new Uint8Array(nc + 1), wu = new Float32Array(nc + 1);
    let WP = 0, SP = 0;
    for (const b of C.B) if (b) {
      const s = SV[b.t]; if (!s.wt && !s.sw) continue; b.wc = -1; const own = comp[b.y * N + b.x]; let hasPipe = false;
      for (let yy = b.y - 1; yy <= b.y + s.sz && !hasPipe; yy++) for (let xx = b.x - 1; xx <= b.x + s.sz; xx++) { if (xx >= 0 && yy >= 0 && xx < N && yy < N && pi[yy * N + xx]) { hasPipe = true; break; } }
      if (hasPipe) b.wc = own;
      const sz = s.sz; for (let yy = b.y - 1; yy <= b.y + sz && b.wc < 0; yy++) for (let xx = b.x - 1; xx <= b.x + sz; xx++) { if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (comp[j] >= 0) { b.wc = comp[j]; break; } }
      const on = C.pw[b.y * N + b.x]; b.on = on && b.wc >= 0 ? 1 : 0; if (!b.on) continue;
      const f = Math.min(1.2, 0.5 + 0.5 * bmul(C, 'wt'));
      if (s.wt) { sup[b.wc] += s.wt * f; WP += s.wt * f; if (!s.clean) { const dirtyIn = s.shore ? intakePol(C, b) > 45 : C.gnd[b.y * N + b.x] > 30; if (dirtyIn) dirty[b.wc] = 1; b.dirty = dirtyIn ? 1 : 0; } }
      if (s.sw) { swc[b.wc] += s.sw * f; SP += s.sw * f; }
    }
    // 관에서 4칸 커버
    const wc = C.wc; wc.fill(-1); const dd = new Uint8Array(NN).fill(255); let qh = 0, qt = 0;
    for (let i = 0; i < NN; i++) if (comp[i] >= 0) { wc[i] = comp[i]; dd[i] = 0; q[qt++] = i; }
    while (qh < qt) { const i = q[qh++], d = dd[i]; if (d >= 4) continue; const x = i % N, y = (i / N) | 0; for (let k = 0; k < 4; k++) { const xx = x + DX[k], yy = y + DY[k]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (dd[j] !== 255) continue; dd[j] = d + 1; wc[j] = wc[i]; q[qt++] = j; } }
    for (let i = 0; i < NN; i++) if (wc[i] >= 0) wu[wc[i]] += wuseOf(C, i);
    let WU = 0; for (let c = 0; c < nc; c++) WU += wu[c];
    C.wt.fill(0); C.sw.fill(0); C.sick.fill(0);
    for (let i = 0; i < NN; i++) {
      const c = wc[i]; if (c < 0) continue; const u = wu[c];
      const fw = u > 0 ? sup[c] / u : 1, fs = u > 0 ? swc[c] / u : 1;
      if (sup[c] > 0 && (fw >= 1 || hash(i, 23) < fw * 1000)) { C.wt[i] = 1; if (dirty[c]) C.sick[i] = 1; }
      if (swc[c] > 0 && (fs >= 1 || hash(i, 37) < fs * 1000)) C.sw[i] = 1;
    }
    C.st.wtP = WP; C.st.swP = SP; C.st.wtU = WU; C.st.swU = WU; C._wcomp = comp;
  }
  function shoreCells(C, b) { const N = C.N, s = SV[b.t].sz, o = []; for (let yy = b.y - 1; yy <= b.y + s; yy++) for (let xx = b.x - 1; xx <= b.x + s; xx++) { if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (C.ter[j] === 1) o.push(j); } return o; }
  function intakePol(C, b) { let m = 0; for (const j of shoreCells(C, b)) m = Math.max(m, C.wpol[j]); return m; }

  /* ---------- 서비스 범위 ---------- */
  function bActive(C, b) { const s = SV[b.t]; if (b.ra < 0) return false; if (!s.np && !C.pw[b.y * C.N + b.x]) return false; if ((s.store) && b.fl >= s.store) return false; return true; }
  function stamp(C, arr, cx, cy, r, mode, val) {
    const N = C.N, r2 = r * r;
    for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(N - 1, Math.ceil(cy + r)); y++) for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(N - 1, Math.ceil(cx + r)); x++) {
      const d2 = (x + 0.5 - cx) * (x + 0.5 - cx) + (y + 0.5 - cy) * (y + 0.5 - cy); if (d2 > r2) continue; const i = y * N + x;
      if (mode === 'or') arr[i] |= val; else { const v = Math.round(val * (1 - 0.6 * Math.sqrt(d2) / r)); if (v > arr[i]) arr[i] = v; }
    }
  }
  function svRadius(C, b) { const s = SV[b.t]; let r = s.r || 0; if (!r) return 0; r *= 0.75 + 0.25 * bmul(C, s.g); if (s.g === 'park' && hasPol(C, b.y * C.N + b.x, 'tour')) r *= 1.1; return r; }
  function computeCov(C) {
    const N = C.N;
    for (const g of COVG) C.cov[g].fill(0); C.aur.fill(0); C.lmask.fill(0); C.trc.fill(0);
    let hapC = 0, tour = 0, bI = 0, bC = 0, adm = 0, rail = null;
    for (const b of C.B) if (b) {
      const s = SV[b.t]; b.ra = roadAdj(C, b);
      const act = bActive(C, b); b.act = act ? 1 : 0; if (!act) continue;
      const cx = b.x + s.sz / 2, cy = b.y + s.sz / 2;
      if (C.cov[s.g] && s.r) stamp(C, C.cov[s.g], cx, cy, svRadius(C, b), 'max', 255);
      if (s.aur) stamp(C, C.aur, cx, cy, s.aur[0], 'max', s.aur[1]);
      if (s.hapC) hapC += s.hapC; if (s.tour) tour += s.tour; if (s.bI) bI += s.bI; if (s.bC) bC += s.bC; if (s.adm) adm = 1;
      if (s.rail) { rail = b; stamp(C, C.trc, cx, cy, s.r, 'max', 200); }
    }
    // 대중교통 노선
    const depots = C.B.filter((b) => b && SV[b.t].depot && b.act).length;
    let busN = 0;
    C.lines.forEach((ln, k) => {
      ln.ok = 0; if (ln.s.length < 2) return;
      const stops = ln.s.map((id) => C.B[id]).filter(Boolean); if (stops.length < 2) return;
      if (ln.t === 'bus') { if (!depots || busN >= depots * 8) { ln.why = '차고지 필요'; return; } if (!ln.path || ln.pv !== C._rv) busPath(C, ln); if (!ln.path) { ln.why = '정류장 사이 도로가 끊겼어요'; return; } busN++; }
      else if (stops.some((b) => !C.pw[b.y * N + b.x])) { ln.why = '역에 전기가 없어요'; return; }
      ln.ok = 1; ln.why = '';
      const rr = ln.t === 'bus' ? 5 : 8, bit = 1 << (k % 16);
      for (const b of stops) { stamp(C, C.lmask, b.x + 0.5, b.y + 0.5, rr, 'or', bit); stamp(C, C.trc, b.x + 0.5, b.y + 0.5, rr, 'max', ln.t === 'bus' ? 160 : 230); }
    });
    C.st.hapC = hapC; C.st.tourB = tour; C.st.bI = bI; C.st.bC = bC; C.st.adm = adm; C.st.rail = rail ? 1 : 0;
  }

  /* ---------- 환경(오염·땅값·행복) ---------- */
  function blur(src, N, r, tmp) {
    // 상자 흐리기(가로→세로), r칸
    const w = 2 * r + 1;
    for (let y = 0; y < N; y++) { let s = 0; const o = y * N; for (let x = -r; x <= r; x++) s += src[o + clamp(x, 0, N - 1)]; for (let x = 0; x < N; x++) { tmp[o + x] = s / w; s += src[o + clamp(x + r + 1, 0, N - 1)] - src[o + clamp(x - r, 0, N - 1)]; } }
    for (let x = 0; x < N; x++) { let s = 0; for (let y = -r; y <= r; y++) s += tmp[clamp(y, 0, N - 1) * N + x]; for (let y = 0; y < N; y++) { src[y * N + x] = s / w; s += tmp[clamp(y + r + 1, 0, N - 1) * N + x] - tmp[clamp(y - r, 0, N - 1) * N + x]; } }
  }
  function computeEnv(C) {
    const N = C.N, NN = N * N, air = C.air, nz = C.nz, gnd = C.gnd, tmp = new Float32Array(NN);
    air.fill(0); nz.fill(0); const gs = new Float32Array(NN);
    for (let i = 0; i < NN; i++) {
      const r = C.rd[i];
      if (r) { const v = C.vol[i] / RD[r].cap; nz[i] += RD[r].nz * (6 + Math.min(3, v) * 12); air[i] += Math.min(3, v) * 6 * RD[r].nz; }
      const z = C.zn[i], c = capOf(C, i); if (!c) continue; const k = ZN[z].k; const quiet = hasPol(C, i, 'quiet') ? 0.5 : 1;
      if (k === 'I') { const g = hasPol(C, i, 'hitech') ? 0.08 : hasPol(C, i, 'green') ? 0.4 : 1; air[i] += c * 5.5 * g; gs[i] += c * 0.9 * g; nz[i] += 30 * quiet; }
      else if (k === 'C') nz[i] += (z === Z_CH ? 28 : 16) * quiet * (hasPol(C, i, 'tour') ? 1.3 : 1);
      else if (k === 'O') nz[i] += 8;
    }
    for (const b of C.B) if (b) { const s = SV[b.t], i = b.y * N + b.x; if (s.air && b.act !== 0) air[i] += s.air * s.sz * 2; if (s.gnd) gs[i] += s.gnd * 4; if (s.nz) nz[i] += s.nz * 40; }
    blur(air, N, 3, tmp); blur(air, N, 3, tmp);
    blur(nz, N, 2, tmp);
    // 숲·공원은 공기를 맑게
    for (let i = 0; i < NN; i++) { let a = air[i] * 1.6; if (C.fr[i]) a *= 0.7; a -= C.cov.park[i] / 40; air[i] = clamp(a, 0, 100); nz[i] = clamp(nz[i] * 1.4, 0, 100); }
    blur(gs, N, 2, tmp);
    for (let i = 0; i < NN; i++) { gnd[i] = clamp(gnd[i] * 0.88 + gs[i] * 1.2, 0, 100); C.gnd8[i] = gnd[i]; }
    // 물 오염: 배출구에서 물칸으로 퍼짐
    const wp = C.wpol; for (let i = 0; i < NN; i++) wp[i] *= 0.6;
    for (const b of C.B) if (b && SV[b.t].sw && b.on) { const sh = shoreCells(C, b); const load = Math.min(SV[b.t].sw, C.st.swU || 0) * SV[b.t].wp * 1.5; for (const j of sh) wp[j] = Math.min(255, wp[j] + load / sh.length + 25 * SV[b.t].wp); }
    for (let it = 0; it < 10; it++) for (let i = 0; i < NN; i++) {
      if (C.ter[i] !== 1 || wp[i] < 1) continue; const x = i % N, y = (i / N) | 0;
      for (let k = 0; k < 4; k++) { const xx = x + DX[k], yy = y + DY[k]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (C.ter[j] === 1 && wp[j] < wp[i] * 0.8) wp[j] = wp[i] * 0.8; }
    }
    // 땅값·행복
    const wd = C._wd || (C._wd = waterDist(C));
    const tierCap = TIERS[C.tier].cap; let crime = 0, cn = 0;
    for (let i = 0; i < NN; i++) {
      if (C.ter[i] === 1) { C.lv[i] = 0; continue; }
      const cv = C.cov; let v = 12;
      if (wd[i] <= 4) v += 12 - wd[i] * 2; if (C.ht[i] > 150) v += (C.ht[i] - 150) / 12;
      v += cv.park[i] / 255 * 22 + (cv.pol[i] ? 4 : 0) + (cv.fire[i] ? 4 : 0) + (cv.hlth[i] ? 5 : 0) + (cv.edu1[i] ? 4 : 0) + (cv.edu2[i] ? 4 : 0) + (cv.edu3[i] ? 5 : 0);
      v += C.trc[i] / 255 * 10 + C.aur[i];
      v -= air[i] * 0.45 + nz[i] * 0.3 + gnd[i] * 0.4;
      if (C.gar[i] > 120) v -= 10; if (hasPol(C, i, 'lowrise')) v += 5;
      C.lv[i] = clamp(Math.round(v), 0, 100);
      const z = C.zn[i];
      if (z && C.bl[i]) {
        const k = ZN[z].k;
        let cr = (k === 'R' || k === 'C') ? 28 + C.bl[i] * 4 - cv.pol[i] / 255 * 40 : 10; cr = clamp(cr, 0, 60); crime += cr; cn++;
        if (k === 'R') {
          let h = 46 + (cv.pol[i] ? 6 : 0) + (cv.fire[i] ? 5 : 0) + (cv.hlth[i] ? 7 : 0) + (cv.edu1[i] ? 5 : 0) + (cv.park[i] ? 6 : 0) + (C.trc[i] ? 3 : 0);
          h += C.st.hapC + (hasPol(C, i, 'smoke') ? 2 : 0) - (hasPol(C, i, 'saveW') ? 1 : 0);
          h -= air[i] * 0.35 + nz[i] * 0.25 + gnd[i] * 0.2 + cr * 0.25 + (C.sick[i] ? 18 : 0) + (C.pb[i] & 31 ? 12 : 0);
          h -= Math.max(0, C.tax.R - 9) * 1.6;
          C.hap[i] = clamp(Math.round(h), 0, 100);
        }
      }
    }
    C.st.crime = cn ? crime / cn : 0;
    void tierCap;
  }
  function waterDist(C) { const N = C.N, NN = N * N, d = new Uint8Array(NN).fill(255), q = new Int32Array(NN); let qh = 0, qt = 0; for (let i = 0; i < NN; i++) if (C.ter[i] === 1) { d[i] = 0; q[qt++] = i; } while (qh < qt) { const i = q[qh++]; if (d[i] >= 8) continue; const x = i % N, y = (i / N) | 0; for (let k = 0; k < 4; k++) { const xx = x + DX[k], yy = y + DY[k]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (d[j] === 255) { d[j] = d[i] + 1; q[qt++] = j; } } } return d; }

  /* ---------- 수요 ---------- */
  function computeDemand(C) {
    const s = C.st, J = s.jobs, pop = s.pop, wk = pop * 0.58, jobs = J.C + J.I + J.O;
    const outOK = outsideOK(C);
    const tp = (k) => (C.tax[k] - 9) * 4.5;
    let R = 35 + (jobs - wk * 0.9) / Math.max(60, wk) * 150 + (s.hap - 55) * 0.8 - tp('R') + (pop < 400 ? 45 : pop < 1500 ? 15 : 0);
    if (!outOK) R -= 50;
    const shop = pop * 0.3 + s.tour * 0.02;
    let Cd = (shop - J.C) / Math.max(40, shop) * 140 - tp('C') + (s.bC || 0) + (s.rail ? 8 : 0) - (s.flow < 45 ? 15 : 0);
    const goods = pop * 0.2 + J.C * 0.6;
    let I = (goods - J.I) / Math.max(40, goods) * 130 - tp('I') + (s.bI || 0) + (s.rail ? 8 : 0) + (pop < 600 ? 20 : 0) - (s.flow < 45 ? 20 : 0);
    if (!outOK) I -= 40;
    let O = C.tier >= ZN[Z_O].tier ? ((pop * 0.58 * (s.edu[1] * 0.5 + s.edu[2] * 0.5) * 0.35) - J.O) / Math.max(40, pop * 0.08) * 120 - tp('O') : -100;
    // 일자리보다 일할 사람이 너무 적으면 C/I/O 수요가 줄어요
    if (jobs > wk * 1.25) { const p = (jobs / Math.max(1, wk) - 1.25) * 120; Cd -= p; I -= p; O -= p; }
    s.unemp = wk > 0 ? clamp(1 - jobs / wk, 0, 1) : 0;
    s.dem = { R: clamp(Math.round(R), -100, 100), C: clamp(Math.round(Cd), -100, 100), I: clamp(Math.round(I), -100, 100), O: clamp(Math.round(O), -100, 100) };
  }
  function outsideOK(C) { // 바깥 고속도로와 이어진 도로가 있는지(도로망 BFS, 달마다)
    return C._out !== 0;
  }
  function computeOutside(C) {
    const N = C.N, NN = N * N, seen = new Uint8Array(NN), q = new Int32Array(NN); let qh = 0, qt = 0;
    for (let i = 0; i < NN; i++) { const x = i % N, y = (i / N) | 0; if (C.rd[i] === 4 && (x === 0 || y === 0 || x === N - 1 || y === N - 1)) { seen[i] = 1; q[qt++] = i; } }
    while (qh < qt) { const i = q[qh++], x = i % N, y = (i / N) | 0; for (let k = 0; k < 4; k++) { const xx = x + DX[k], yy = y + DY[k]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (!seen[j] && C.rd[j]) { seen[j] = 1; q[qt++] = j; } } }
    C._oseen = seen; C._outs = []; for (let i = 0; i < NN; i++) { const x = i % N, y = (i / N) | 0; if (C.rd[i] === 4 && (x === 0 || y === 0 || x === N - 1 || y === N - 1)) C._outs.push(i); }
    let any = 0; for (let i = 0; i < NN; i++) if (seen[i] && C.rd[i] && C.rd[i] !== 4) { any = 1; break; }
    C._out = any ? 1 : (qt ? 0 : 0);
  }

  /* ---------- 성장 ---------- */
  function eduOf(C, i) { const c = C.cov; return (c.edu1[i] ? 1 : 0) + (c.edu2[i] ? 1 : 0) + (c.edu3[i] ? 1 : 0); }
  function targetLevel(C, i) {
    const z = C.zn[i], k = ZN[z].k, lv = C.lv[i], c = C.cov, E = C.st.edu; let t = 1;
    if (k === 'R') { const e = eduOf(C, i); t = 1 + (lv >= 22 ? 1 : 0); if (t === 2 && lv >= 36 && e >= 1) t = 3; if (t === 3 && lv >= 50 && e >= 2 && c.hlth[i]) t = 4; if (t === 4 && lv >= 64 && e >= 3) t = 5; if (C.hap[i] < 30) t = Math.min(t, 2); }
    else if (k === 'C') { t = 1 + (lv >= 22 ? 1 : 0); if (t === 2 && lv >= 36 && c.pol[i]) t = 3; if (t === 3 && lv >= 50 && E[0] > 0.5) t = 4; if (t === 4 && lv >= 64 && E[1] > 0.45) t = 5; }
    else if (k === 'I') { t = 1 + (c.fire[i] ? 1 : 0); if (t === 2 && E[0] > 0.4) t = 3; if (t === 3 && E[1] > 0.35) t = 4; if (t === 4 && E[2] > 0.2) t = 5; if (hasPol(C, i, 'hitech') && E[1] < 0.3) t = Math.min(t, 2); }
    else { t = 1 + (lv >= 30 && E[1] > 0.25 ? 1 : 0); if (t === 2 && lv >= 42 && E[1] > 0.4) t = 3; if (t === 3 && lv >= 55 && E[2] > 0.2) t = 4; if (t === 4 && lv >= 68 && E[2] > 0.35) t = 5; }
    let cap = TIERS[C.tier].cap; if (hasPol(C, i, 'lowrise')) cap = Math.min(cap, 3);
    return Math.min(t, cap);
  }
  function growChunk(C, y0, y1, acc) {
    const N = C.N, D = C.st.dem;
    for (let y = y0; y < y1; y++) for (let x = 0; x < N; x++) {
      const i = y * N + x, z = C.zn[i]; if (!z) continue; const k = ZN[z].k;
      if (C.burn[i]) { acc.fireN++; continue; }
      const roadOK = C.acc[i] >= 0 && C.accD[i] <= 3;
      if (!C.bl[i]) {
        if (!roadOK) continue;
        acc.ez[k]++;
        const d = D[k]; if (d <= 0) continue;
        const p = d / 100 * (k === 'R' ? 0.35 : 0.28);
        if (rnd(C) < p && acc.sp[k] < acc.spMax) { C.bl[i] = 1; C.ab[i] = 0; acc.sp[k]++; acc.newB++; }
        continue;
      }
      let pb = 0; const abd = C.ab[i] & 128;
      if (!C.pw[i]) pb |= PB.pw; if (!C.wt[i]) pb |= PB.wt; if (!C.sw[i]) pb |= PB.sw; if (C.gar[i] > 140) pb |= PB.gar; if (C.dead[i] > 120) pb |= PB.dead; if (!roadOK) pb |= PB.road; if (C.sick[i]) pb |= PB.sick;
      C.pb[i] = pb;
      const severe = pb & (PB.pw | PB.wt | PB.sw | PB.gar | PB.road | PB.dead);
      const grace = C.bl[i] === 1 && (C.ab[i] & 127) < 3; // 새 건물은 잠깐 봐줘요
      if (abd) { if (!severe && D[k] > -20 && rnd(C) < 0.2) { C.bl[i] = 1; C.ab[i] = 0; } else { acc.ab++; } continue; }
      if (severe) { let c = (C.ab[i] & 127) + 1; if (c >= 7) { C.ab[i] = 128; acc.abNew++; if (acc.abCell < 0) acc.abCell = i; continue; } C.ab[i] = c; }
      else { C.ab[i] = Math.max(0, (C.ab[i] & 127) - 2); }
      const t = targetLevel(C, i);
      if (!severe && t > C.bl[i] && rnd(C) < 0.18 && D[k] > -30) { C.bl[i]++; acc.up++; }
      else if (t < C.bl[i] - 1 && rnd(C) < 0.08) C.bl[i]--;
      const cap = capOf(C, i) * ((severe && !grace) ? 0.6 : 1);
      if (k === 'R') { acc.pop += cap; acc.rL.push(i); acc.hap += C.hap[i] * cap; const e = eduOf(C, i); if (e >= 1) acc.e1 += cap; if (e >= 2) acc.e2 += cap; if (e >= 3) acc.e3 += cap; if (C.sick[i]) acc.sick += cap; }
      else { acc.jobs[k] += cap; acc.jL.push(i); if (k === 'C') acc.cL.push(i); if (k === 'I') acc.iL.push(i); }
      acc.bld++; acc.lvs += C.bl[i]; acc.cnt[z]++;
      const pm = polAt(C, i); for (let b = 0; b < POL.length; b++) if (pm & (1 << b)) acc.polCells[b]++;
      // 쓰레기·사망
      const gmul = hasPol(C, i, 'recycle') ? 0.65 : 1;
      const gg = Math.round(cap * 0.16 * gmul + 0.4); C.gar[i] = Math.min(255, C.gar[i] + gg); acc.gGen += gg; if (C.gar[i] > 110) acc.gHot.push(i);
      if (k === 'R') { const dm = (C.cov.hlth[i] ? 0.5 : 1) * (hasPol(C, i, 'smoke') ? 0.75 : 1) * (C.sick[i] ? 2 : 1); const dd = cap * 0.03 * dm; acc.dGen += dd; if (C.dead[i] > 90) acc.dHot.push(i); C.dead[i] = Math.min(255, C.dead[i] + Math.floor(dd) + (rnd(C) < dd % 1 ? 1 : 0)); }
    }
  }
  /* ---------- 쓰레기·묘지 수거 ---------- */
  function collect(C) {
    const N = C.N; let gP = 0, dP = 0, gU = 0, dU = 0;
    gU = C.st.gGen || 0; dU = C.st.dGen || 0;
    for (const b of C.B) if (b) {
      const s = SV[b.t]; if (s.g !== 'gar' && s.g !== 'dead') continue; b.on = 0; if (!b.act) continue; b.on = 1;
      const arr = s.g === 'gar' ? C.gar : C.dead; const mul = bmul(C, s.g);
      let capm = s.proc ? s.proc * mul : Math.min(s.store - (b.fl || 0), (s.g === 'gar' ? 700 : 120) * mul);
      if (capm <= 0) continue;
      const r = svRadius(C, b), cx = b.x + s.sz / 2, cy = b.y + s.sz / 2; let got = 0;
      for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(N - 1, Math.ceil(cy + r)) && got < capm; y++) for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(N - 1, Math.ceil(cx + r)); x++) {
        const i = y * N + x; if (!arr[i]) continue; if ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 > r * r) continue;
        const take = Math.min(arr[i], capm - got); arr[i] -= take; got += take; if (got >= capm) break;
      }
      if (!s.proc) b.fl = (b.fl || 0) + got; b.got = got;
      if (s.g === 'gar') gP += capm; else dP += capm;
      if (s.store && b.fl >= s.store && !b.full) { b.full = 1; news(C, 'warn', s.n + '이(가) 가득 찼어요. 새로 지어 주세요.', b.y * N + b.x); }
    }
    C.st.garP = gP; C.st.garU = gU; C.st.dP = dP; C.st.dU = dU;
  }

  /* ---------- 교통(경로 탐색) ---------- */
  let AS = null;
  function asBuf(NN) { if (!AS || AS.n !== NN) AS = { n: NN, g: new Float32Array(NN), st: new Uint32Array(NN), from: new Int32Array(NN), hk: new Float32Array(NN * 2), hv: new Int32Array(NN * 2), gen: 1 }; return AS; }
  function stepCost(C, j) { const r = C.rd[j], c = C.cong[j] / 100; return (1 / RD[r].sp) * (1 + 1.6 * Math.min(4, c * c)); }
  function canMove(C, a, b, dir) { // a→b, dir: 0 N 1 E 2 S 3 W
    const ra = C.rd[a], rb = C.rd[b];
    if (rb === 3) { const d = C.rdir[b]; if (d && ((d - 1 + 2) % 4) === dir) return false; }
    if (ra === 3) { const d = C.rdir[a]; if (d && ((d - 1 + 2) % 4) === dir) return false; }
    return true;
  }
  function astar(C, s, t, maxExp) {
    const N = C.N, NN = N * N, A = asBuf(NN); A.gen++; if (A.gen > 4e9) { A.gen = 1; A.st.fill(0); }
    const gen = A.gen, g = A.g, st = A.st, from = A.from, hk = A.hk, hv = A.hv; let hn = 0;
    const tx = t % N, ty = (t / N) | 0;
    const push = (v, k) => { let i = hn++; while (i > 0) { const p = (i - 1) >> 1; if (hk[p] <= k) break; hk[i] = hk[p]; hv[i] = hv[p]; i = p; } hk[i] = k; hv[i] = v; };
    const pop = () => { const v = hv[0], lk = hk[--hn], lv = hv[hn]; let i = 0; for (;;) { let c = 2 * i + 1; if (c >= hn) break; if (c + 1 < hn && hk[c + 1] < hk[c]) c++; if (hk[c] >= lk) break; hk[i] = hk[c]; hv[i] = hv[c]; i = c; } hk[i] = lk; hv[i] = lv; return v; };
    g[s] = 0; st[s] = gen; from[s] = -1; push(s, 0); let exp = 0;
    while (hn > 0) {
      const a = pop(); if (a === t) break; if (++exp > maxExp) return null;
      const ax = a % N, ay = (a / N) | 0, ga = g[a];
      for (let d = 0; d < 4; d++) {
        const xx = ax + DX[d], yy = ay + DY[d]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const b = yy * N + xx; if (!C.rd[b]) continue;
        if (!canMove(C, a, b, d)) continue;
        const nb = ga + stepCost(C, b);
        if (st[b] === gen && g[b] <= nb) continue; st[b] = gen; g[b] = nb; from[b] = a;
        push(b, nb + (Math.abs(xx - tx) + Math.abs(yy - ty)) / 2.6);
      }
      if (hn > NN * 2 - 8) return null;
    }
    if (st[t] !== gen) return null;
    const path = []; let c = t, guard = 0; while (c >= 0 && guard++ < NN) { path.push(c); c = from[c]; } path.reverse();
    return { path, cost: g[t] };
  }
  function busPath(C, ln) {
    C._rv = C._rv || 1; ln.pv = C._rv; ln.path = null; const pts = [];
    for (let k = 0; k < ln.s.length; k++) {
      const a = C.B[ln.s[k]], b = C.B[ln.s[(k + 1) % ln.s.length]]; if (!a || !b) return;
      const ra = roadAdj(C, a), rb = roadAdj(C, b); if (ra < 0 || rb < 0) return;
      const r = astar(C, ra, rb, 20000); if (!r) return; if (pts.length) r.path.shift(); pts.push(...r.path);
    }
    ln.path = pts;
  }
  function trafficPrep(C) {
    computeOutside(C); C.nvol.fill(0); C._tr = { n: 0, T: 0, ft: 0, at: 0, rid: 0, fail: 0, car: 0 };
    const s = C.st; const T = clamp(Math.round(s.pop / 35), C._rL && C._rL.length ? 20 : 0, 240);
    C._tr.T = T; C._tr.W = T ? (s.pop * 0.55 + s.jobs.I * 0.25) / T : 0;
  }
  function pickFrom(C, list) { return list.length ? list[Math.floor(rnd(C) * list.length)] : -1; }
  function tripStep(C, n) {
    const tr = C._tr, N = C.N;
    for (let k = 0; k < n && tr.n < tr.T; k++) {
      tr.n++;
      const r = rnd(C); let o, d, kind = 0;
      if (r < 0.68) { o = pickFrom(C, C._rL); d = pickFrom(C, C._jL); }
      else if (r < 0.86) { o = pickFrom(C, C._rL); d = pickFrom(C, C._cL); kind = 1; }
      else { o = pickFrom(C, C._iL); d = rnd(C) < 0.5 ? pickFrom(C, C._cL) : -2; kind = 2; }
      if (o < 0) continue;
      const W = tr.W * (kind === 2 ? 0.7 : 1) * ((C.sc && C.sc.tw) || 1); // 시나리오 「교통 지옥」: 차량 배율
      // 대중교통
      if (d >= 0 && kind !== 2) {
        const m = C.lmask[o] & C.lmask[d];
        if (m) { let best = 0; C.lines.forEach((ln, li) => { if (ln.ok && (m & (1 << (li % 16)))) best = Math.max(best, ln.t === 'bus' ? 0.4 : 0.65); }); if (hasPol(C, o, 'freebus')) best += 0.15;
          if (rnd(C) < best) { tr.rid += W; C.lines.forEach((ln, li) => { if (ln.ok && (m & (1 << (li % 16)))) ln.rid = (ln.rid || 0) + W; }); continue; } }
        if (C.st.rail && C.trc[o] >= 200 && rnd(C) < 0.08) { tr.rail = (tr.rail || 0) + W; continue; }
      }
      let a = C.acc[o]; if (a < 0) { tr.fail++; continue; }
      let b;
      if (d === -2 || (d < 0)) { if (!C._outs || !C._outs.length) { tr.fail++; continue; } b = C._outs[Math.floor(rnd(C) * C._outs.length)]; }
      else { b = C.acc[d]; if (b < 0) { tr.fail++; continue; } }
      if (a === b) continue;
      const res = astar(C, a, b, 9000);
      if (!res) { tr.fail++; continue; }
      const p = res.path; let free = 0;
      for (const c of p) { C.nvol[c] += W; free += 1 / RD[C.rd[c]].sp; }
      tr.ft += free; tr.at += res.cost; tr.car++;
      C._paths[C._pi % 90] = { p, k: kind }; C._pi++;
    }
    return tr.n >= tr.T;
  }
  function trafficEnd(C) {
    const tr = C._tr, NN = C.N * C.N;
    for (const ln of C.lines) if (ln.ok && ln.t === 'bus' && ln.path) for (const c of ln.path) C.nvol[c] += 25;
    for (let i = 0; i < NN; i++) { const r = C.rd[i]; if (!r) { C.vol[i] = 0; C.cong[i] = 0; continue; } C.vol[i] = C.vol[i] * 0.35 + C.nvol[i] * 0.65; C.cong[i] = clamp(Math.round(C.vol[i] / RD[r].cap * 100), 0, 255); }
    C.st.flow = tr.at > 0 ? clamp(Math.round(tr.ft / tr.at * 100), 5, 100) : 100;
    C.st.rid = Math.round(tr.rid); C.st.railR = Math.round(tr.rail || 0); C.st.noRoute = tr.fail; C.st.trips = tr.T;
    C.lines.forEach((ln) => { ln.rm = Math.round(ln.rid || 0); ln.rid = 0; });
  }

  /* ---------- 작업 줄(한 달 동안 나눠 돌기) ---------- */
  function newAcc(C) { return { pop: 0, jobs: { R: 0, C: 0, I: 0, O: 0 }, rL: [], jL: [], cL: [], iL: [], hap: 0, e1: 0, e2: 0, e3: 0, sick: 0, bld: 0, lvs: 0, ab: 0, abNew: 0, abCell: -1, up: 0, newB: 0, fireN: 0, sp: { R: 0, C: 0, I: 0, O: 0 }, spMax: 0, cnt: [0, 0, 0, 0, 0, 0, 0], polCells: POL.map(() => 0), gGen: 0, dGen: 0, gHot: [], dHot: [], ez: { R: 0, C: 0, I: 0, O: 0 } }; }
  /* 단계: 0 망 · 1 서비스 범위 · 2 환경 · 3 수요 · 4 성장(줄 나눔) · 5 교통 준비 · 6 교통(나눔) · 7 수거·마무리 · 8 끝 */
  function simStep(C, until) {
    const J = C.job, N = C.N;
    while (J.s < 8) {
      if (until !== Infinity && now() > until) return false;
      if (J.s === 0) { computeAcc(C); computePower(C); computeWater(C); C._dn = 0; J.s++; }
      else if (J.s === 1) { computeCov(C); J.s++; }
      else if (J.s === 2) { computeEnv(C); J.s++; }
      else if (J.s === 3) { computeDemand(C); J.acc = newAcc(C); J.acc.spMax = 6 + Math.round(C.st.pop / 60); J.k = 0; J.s++; }
      else if (J.s === 4) { const y1 = Math.min(N, J.k + 25); growChunk(C, J.k, y1, J.acc); J.k = y1; if (J.k >= N) { finishGrow(C, J.acc); J.s++; } }
      else if (J.s === 5) { trafficPrep(C); J.s++; }
      else if (J.s === 6) { if (tripStep(C, 12)) { trafficEnd(C); J.s++; } }
      else if (J.s === 7) { collect(C); J.s++; }
    }
    return true;
  }
  function finishGrow(C, a) {
    const s = C.st; s.pop = Math.round(a.pop); s.jobs = { R: 0, C: Math.round(a.jobs.C), I: Math.round(a.jobs.I), O: Math.round(a.jobs.O) };
    s.hap = a.pop > 0 ? Math.round(a.hap / a.pop) : 60; s.edu = a.pop > 0 ? [a.e1 / a.pop, a.e2 / a.pop, a.e3 / a.pop] : [0, 0, 0];
    s.bld = a.bld; s.ab = a.ab + a.abNew; s.lvAvg = a.bld ? a.lvs / a.bld : 0; s.sickN = Math.round(a.sick); s.cnt = a.cnt; s.polCells = a.polCells; s.gGen = Math.round(a.gGen); s.dGen = Math.round(a.dGen); C._gHot = a.gHot; C._dHot = a.dHot; s.ez = a.ez;
    C._rL = a.rL; C._jL = a.jL; C._cL = a.cL; C._iL = a.iL;
    s.tour = Math.round((s.tourB || 0) * 120 * (0.4 + s.hap / 100) * (1 + (C.tier >= 4 ? 0.3 : 0)));
    if (a.abNew > 0) news(C, 'warn', '건물 ' + a.abNew + '채가 버려졌어요(전기·물·하수·쓰레기·도로 확인).', a.abCell);
    if (s.pop > C.mx) C.mx = s.pop;
  }
  function monthEnd(C) {
    if (C.job.s < 8) simStep(C, Infinity);
    const s = C.st, inc = {}, exp = {};
    const tm = (k, base) => base * C.tax[k] / 100;
    let tI = 1, tC = 1;
    // 정책 세금 조정은 평균 근사(정책 적용 칸 비율)
    const pc = s.polCells || POL.map(() => 0), tot = Math.max(1, s.bld);
    tI += (-(pc[POL.findIndex((p) => p.id === 'green')] || 0) * 0.1 + (pc[POL.findIndex((p) => p.id === 'hitech')] || 0) * 0.2) / tot;
    tC += (-(pc[POL.findIndex((p) => p.id === 'quiet')] || 0) * 0.1 + (pc[POL.findIndex((p) => p.id === 'tour')] || 0) * 0.15) / tot;
    inc.R = tm('R', s.pop * 9); inc.C = tm('C', s.jobs.C * 11) * tC; inc.I = tm('I', s.jobs.I * 10) * tI; inc.O = tm('O', s.jobs.O * 13);
    inc.tour = s.tour * 0.6; inc.fare = s.rid * 0.04 * (C.pol[0] & POLI.freebus ? 0 : 1);
    for (const [k] of BUDG) exp[k] = 0;
    for (const b of C.B) if (b) { const sv = SV[b.t], k = bgOf(sv.g) || 'lm'; exp[k] = (exp[k] || 0) + sv.up * (bgOf(sv.g) ? C.bud[k] / 100 : 1); }
    let rc = 0; for (let i = 0; i < C.N * C.N; i++) if (C.rd[i]) rc += RD[C.rd[i]].up; exp.road += rc * C.bud.road / 100;
    exp.road += (C.pi._n || 0) * 0;
    C.lines.forEach((ln) => { if (ln.ok) exp.tr += (ln.t === 'bus' ? 45 : 140) + ln.s.length * (ln.t === 'bus' ? 4 : 25); });
    let pcost = 0; POL.forEach((p, k) => { pcost += (pc[k] || 0) * p.c; }); exp.pol2 = pcost * (s.adm ? 0.75 : 1);
    let loan = 0; C.loans = C.loans.filter((l) => { loan += l.pay; l.left--; return l.left > 0; }); exp.loan = loan;
    let I = 0, E = 0; for (const k in inc) I += inc[k]; for (const k in exp) E += exp[k];
    C.m += I - E; C.fin = { inc, exp, net: I - E, I, E };
    C.hist.push([s.pop, Math.round(C.m), s.hap, Math.round(I - E)]); if (C.hist.length > 240) C.hist.shift();
    // 이정표
    while (C.tier < TIERS.length - 1 && s.pop >= TIERS[C.tier + 1].p) { C.tier++; C.m += TIERS[C.tier].gift; news(C, 'tier', '🏆 「' + TIERS[C.tier].n + '」 달성! 지원금 ' + won(TIERS[C.tier].gift) + ' · 새 건물이 열렸어요.'); }
    // 알림
    const lack = (p, u) => u > 0 && p < u * 0.97;
    C.alerts = { pw: lack(s.pwP, s.pwU), wt: lack(s.wtP, s.wtU), sw: lack(s.swP, s.swU), gar: s.pop > 200 && (s.garP < s.garU || (C._gHot || []).length > 20), dead: s.pop > 800 && (s.dP < s.dU || (C._dHot || []).length > 20), traffic: s.flow < 55, money: C.m < 0, out: s.pop > 0 && !C._out };
    if (C.mo % 3 === 0) {
      if (C.alerts.pw) news(C, 'pw', '⚡ 전기가 모자라요(' + Math.round(s.pwP) + '/' + Math.round(s.pwU) + ' MW). 발전소를 더 지어요.');
      if (C.alerts.wt) news(C, 'wt', '💧 물이 모자라요. 취수장을 더 짓고 관으로 이어요.');
      if (C.alerts.sw) news(C, 'sw', '🚽 하수 처리가 모자라요. 하수 배출구를 늘려요.');
      if (C.alerts.gar) news(C, 'gar', '🗑️ 쓰레기가 쌓여요. 매립지·소각장이 필요해요.');
      if (C.alerts.traffic) news(C, 'traffic', '🚗 길이 많이 막혀요(교통 흐름 ' + s.flow + '%). 큰길·일방통행·대중교통을 써 봐요.');
      if (C.alerts.money) news(C, 'money', '💸 돈이 바닥났어요. 세금을 올리거나 대출을 받아요.');
    }
    // 재해
    if (C.dis) disasters(C);
    C.mo++; C.day = 0; C.job = { s: 0, k: 0 };
    if (C.sc) scenEval(C);
    if (C.goal && s.pop >= C.goal && !C.goalAt) { C.goalAt = C.mo; news(C, 'good', '🎯 목표 인구 ' + num(C.goal) + '명 달성!'); }
  }
  function disasters(C) {
    const s = C.st; if (s.bld < 40) return;
    const N = C.N;
    if (rnd(C) < 0.05 + s.bld / 40000) {
      const i = pickFrom(C, C._jL && rnd(C) < 0.5 ? C._jL : C._rL || []); if (i < 0 || !C.bl[i]) return;
      if (C.cov.fire[i] && rnd(C) < C.cov.fire[i] / 300) return; // 소방서가 미리 막음
      C.burn[i] = 6; C.fires.push(i); news(C, 'fire', '🔥 불이 났어요! 소방서 범위 밖이면 번져요.', i);
    }
    if ((C.mp === 'river' || C.mp === 'coast') && rnd(C) < 0.006) {
      const wd = C._wd || waterDist(C); let n = 0; const c0 = Math.floor(rnd(C) * N * N);
      for (let k = 0; k < N * N; k++) { const i = (c0 + k) % (N * N); if (wd[i] <= 2 && C.ht[i] < 80 && C.bl[i] && rnd(C) < 0.5) { C.bl[i] = Math.max(1, C.bl[i] - 2); n++; if (n > 40) break; } }
      if (n) news(C, 'flood', '🌊 홍수! 물가 낮은 땅 건물 ' + n + '채가 피해를 입었어요.');
    }
  }
  function dayTick(C) {
    C.day++;
    if (C.fires.length) {
      const N = C.N, nf = [];
      for (const i of C.fires) {
        if (!C.burn[i]) continue;
        const cov = C.cov.fire[i]; C.burn[i] -= cov ? 2 : 1;
        if (C.burn[i] <= 0 || C.burn[i] > 200) { C.burn[i] = 0; if (!cov || rnd(C) < 0.3) { C.bl[i] = 0; C.ab[i] = 0; C.dirtyCells && C.dirtyCells.push(i); } continue; }
        nf.push(i);
        if (!cov || rnd(C) < 0.15) { const x = i % N, y = (i / N) | 0; for (let d = 0; d < 4; d++) { const xx = x + DX[d], yy = y + DY[d]; if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue; const j = yy * N + xx; if (C.bl[j] && !C.burn[j] && rnd(C) < (cov ? 0.04 : 0.12)) { C.burn[j] = 6; nf.push(j); } } }
      }
      C.fires = nf.slice(0, 200);
    }
    if (C.day >= 30) { monthEnd(C); return true; }
    return false;
  }

  /* ================= 건설 동작 ================= */
  const inb = (C, x, y) => x >= 0 && y >= 0 && x < C.N && y < C.N;
  function unlocked(C, kind, id) {
    if (kind === 'road') return C.tier >= RD[id].tier;
    if (kind === 'zone') return C.tier >= ZN[id].tier;
    if (kind === 'sv') return C.tier >= SV[id].tier || !!(C.sc && C.sc.ul && C.sc.ul.includes(SV[id].id));
    if (kind === 'dist') return C.tier >= 2;
    return true;
  }
  function clearCell(C, i) { // 구역 건물만 지움(구역은 남김)
    C.bl[i] = 0; C.ab[i] = 0; C.burn[i] = 0; C.pb[i] = 0;
  }
  /* 도로 칸 목록 비용·가능 여부 */
  function roadPlan(C, cells, t) {
    let cost = 0, ok = 0; const res = [];
    for (const i of cells) {
      let why = '';
      if (C.ter[i] === 2) why = '바위산'; else if (C.ob[i]) why = '시설'; else if (C.rd[i] === t && t !== 3) why = 'same';
      if (why) { res.push(why === 'same' ? 1 : 0); continue; }
      let c = RD[t].cost * (C.ter[i] === 1 ? BRIDGE : 1); if (C.rd[i]) c = Math.max(0, c - RD[C.rd[i]].cost * 0.5); if (C.rd[i] === t) c = 2;
      cost += c; ok++; res.push(2);
    }
    return { cost: Math.round(cost), ok, res };
  }
  function doRoad(C, cells, t, dirs) {
    if (!unlocked(C, 'road', t)) return { ok: false, why: '🔒 ' + TIERS[RD[t].tier].n + '부터' };
    const P = roadPlan(C, cells, t); if (!P.ok) return { ok: false, why: '여기엔 길을 낼 수 없어요' };
    if (P.cost > C.m) return { ok: false, why: '돈이 모자라요(' + won(P.cost) + ')' };
    cells.forEach((i, k) => { if (P.res[k] !== 2) return; if (C.zn[i]) { C.zn[i] = 0; clearCell(C, i); } C.fr[i] = 0; C.rd[i] = t; C.rdir[i] = t === 3 ? (dirs ? dirs[k] : 0) : 0; });
    C.m -= P.cost; C._rv = (C._rv || 1) + 1; C._wd = C._wd; computeAcc(C); netsDirty(C);
    return { ok: true, cost: P.cost, n: P.ok };
  }
  function zonePlan(C, cells, z) {
    const res = []; let ok = 0;
    for (const i of cells) {
      let g = 0;
      if (z === 0) g = C.zn[i] ? 2 : 0;
      else if (!C.ter[i] && !C.rd[i] && !C.ob[i] && C.acc[i] >= 0 && C.accD[i] <= 3 && C.zn[i] !== z) g = 2;
      else if (C.zn[i] === z) g = 1;
      if (g === 2) ok++; res.push(g);
    }
    return { ok, res, cost: 0 };
  }
  function doZone(C, cells, z) {
    if (z && !unlocked(C, 'zone', z)) return { ok: false, why: '🔒 ' + TIERS[ZN[z].tier].n + '부터' };
    const P = zonePlan(C, cells, z); if (!P.ok) return { ok: false, why: z ? '도로에서 3칸 안쪽 빈 땅에 칠해요' : '지울 구역이 없어요' };
    cells.forEach((i, k) => { if (P.res[k] !== 2) return; const old = C.zn[i]; if (old && (!z || ZN[old].k !== ZN[z].k || (old !== z))) clearCell(C, i); C.zn[i] = z; C.fr[i] = 0; });
    netsDirty(C); return { ok: true, n: P.ok, cost: 0 };
  }
  function svPlan(C, t, x, y) {
    const s = SV[t], N = C.N, cells = [];
    if (!unlocked(C, 'sv', t)) return { ok: false, why: '🔒 ' + TIERS[s.tier].n + '(인구 ' + num(TIERS[s.tier].p) + '명)부터' };
    if (s.uniq && C.B.some((b) => b && b.t === t)) return { ok: false, why: '하나만 지을 수 있어요' };
    if (x < 0 || y < 0 || x + s.sz > N || y + s.sz > N) return { ok: false, why: '지도 밖이에요' };
    let zc = 0;
    for (let yy = y; yy < y + s.sz; yy++) for (let xx = x; xx < x + s.sz; xx++) { const i = yy * N + xx; if (C.ter[i] || C.rd[i] || C.ob[i]) return { ok: false, why: C.ter[i] === 1 ? '물 위엔 못 지어요' : C.rd[i] ? '도로 위엔 못 지어요' : C.ter[i] === 2 ? '바위산이에요' : '다른 시설이 있어요' }; if (C.zn[i] && C.bl[i]) zc++; cells.push(i); }
    const fake = { t, x, y }; if (roadAdj(C, fake) < 0) return { ok: false, why: '도로에 붙여 지어요' };
    if (s.shore && !shoreCells(C, fake).length) return { ok: false, why: '물가(물에 닿게)에 지어요' };
    if (s.sea && (C.mp !== 'coast' || shoreCells(C, fake).length < 4)) return { ok: false, why: '바닷가 지형의 바다에 닿게 지어요' };
    const cost = s.cost + zc * 50;
    if (cost > C.m) return { ok: false, why: '돈이 모자라요(' + won(cost) + ')', cost };
    return { ok: true, cost, cells };
  }
  function doSv(C, t, x, y) {
    const P = svPlan(C, t, x, y); if (!P.ok) return P;
    const s = SV[t], b = { t, x, y, fl: 0, bm: C.mo }; let id = C.B.indexOf(null); if (id < 0) { id = C.B.length; C.B.push(b); } else C.B[id] = b;
    for (const i of P.cells) { C.ob[i] = id + 1; C.zn[i] = 0; clearCell(C, i); C.fr[i] = 0; C.dist[i] = C.dist[i]; }
    C.m -= P.cost; netsDirty(C); C.built++;
    b.ra = roadAdj(C, b);
    if (s.r && C.cov[s.g]) stamp(C, C.cov[s.g], x + s.sz / 2, y + s.sz / 2, svRadius(C, b), 'max', 255); // 바로 보이게(달 끝에 다시 계산)
    return { ok: true, cost: P.cost, id };
  }
  function doPipe(C, cells, layer) { // layer: 'pi' 수도관 / 'pl' 송전선
    const arr = C[layer], unit = layer === 'pi' ? PIPE_COST : PLINE_COST; let cost = 0, n = 0;
    for (const i of cells) { if (arr[i] || (layer === 'pl' && C.ter[i] === 2)) continue; if (layer === 'pl' && (C.ob[i] || (C.zn[i] && C.bl[i]))) continue; cost += unit * (C.ter[i] === 1 ? 2 : 1); n++; }
    if (!n) return { ok: false, why: layer === 'pi' ? '이미 관이 있어요' : '여기엔 송전선을 놓을 수 없어요' };
    if (cost > C.m) return { ok: false, why: '돈이 모자라요(' + won(cost) + ')' };
    for (const i of cells) { if (arr[i] || (layer === 'pl' && C.ter[i] === 2)) continue; if (layer === 'pl' && (C.ob[i] || (C.zn[i] && C.bl[i]))) continue; arr[i] = 1; }
    C.m -= cost; netsDirty(C); return { ok: true, cost, n };
  }
  function doBull(C, cells, layer) {
    let n = 0, ref = 0; const N = C.N;
    for (const i of cells) {
      if (layer === 'pi' || layer === 'pl') { if (C[layer][i]) { C[layer][i] = 0; n++; } continue; }
      if (C.ob[i]) { const id = C.ob[i] - 1, b = C.B[id]; if (b) { const s = SV[b.t]; for (const j of fpCells(C, b.x, b.y, s.sz)) C.ob[j] = 0; ref += s.cost * 0.25; C.B[id] = null; C.lines.forEach((ln) => { ln.s = ln.s.filter((q) => q !== id); ln.path = null; }); n++; } continue; }
      if (C.rd[i]) { if (C.rd[i] === 4) { const x = i % N, y = (i / N) | 0; if (x === 0 || y === 0 || x === N - 1 || y === N - 1) continue; } C.rd[i] = 0; C.rdir[i] = 0; n++; continue; }
      if (C.zn[i] && C.bl[i]) { clearCell(C, i); n++; continue; }
      if (C.pl[i]) { C.pl[i] = 0; n++; }
    }
    C.lines = C.lines.filter((ln) => ln.s.length >= 1);
    if (!n) return { ok: false, why: '지울 게 없어요' };
    C.m += ref; C._rv = (C._rv || 1) + 1; computeAcc(C); netsDirty(C); return { ok: true, n, cost: -ref };
  }
  function doDist(C, cells, d) { for (const i of cells) if (C.ter[i] !== 1) C.dist[i] = d; return { ok: true, n: cells.length }; }
  function lineAdd(C, t, stops) {
    if (C.lines.length >= 14) return { ok: false, why: '노선은 14개까지' };
    if (stops.length < 2) return { ok: false, why: '정류장(역)을 2곳 이상 골라요' };
    const used = C.lines.map((l) => l.c); let c = 0; while (used.includes(c) && c < LINEC.length - 1) c++;
    C.lines.push({ t, s: stops.slice(), c, rid: 0, rm: 0 }); netsDirty(C); C._rv = (C._rv || 1) + 1;
    return { ok: true };
  }
  function takeLoan(C, k) { const L0 = LOANS[k]; if (!L0 || C.tier < L0.tier || C.loans.some((l) => l.k === k)) return false; const tot = L0.a * (1 + L0.r * L0.mo / 12); C.loans.push({ k, a: L0.a, pay: Math.round(tot / L0.mo), left: L0.mo }); C.m += L0.a; return true; }
  function repayLoan(C, k) { const l = C.loans.find((q) => q.k === k); if (!l) return false; const amt = l.pay * l.left * 0.95; if (C.m < amt) return false; C.m -= amt; C.loans = C.loans.filter((q) => q !== l); return true; }

  /* 선 그리기(직선·꺾은선·곡선) */
  function lineCells(C, x0, y0, x1, y1, mode) {
    const o = [], dirs = [];
    const push = (x, y, d) => { if (!inb(C, x, y)) return; const i = y * C.N + x; if (o.length && o[o.length - 1] === i) return; o.push(i); dirs.push(d); };
    if (mode === 'free') return { cells: o, dirs };
    const dx = x1 - x0, dy = y1 - y0;
    if (mode === 'curve' && Math.abs(dx) > 1 && Math.abs(dy) > 1) { // 부드러운 사분원 근사(계단식)
      const steps = (Math.abs(dx) + Math.abs(dy)) * 2; let px = x0, py = y0;
      for (let s = 0; s <= steps; s++) { const t = s / steps; const a = t * Math.PI / 2; const fx = x0 + dx * Math.sin(a), fy = y0 + dy * (1 - Math.cos(a)); const nx = Math.round(fx), ny = Math.round(fy);
        while (px !== nx || py !== ny) { if (px !== nx && (Math.abs(nx - px) >= Math.abs(ny - py))) { px += Math.sign(nx - px); push(px, py, nx > px - Math.sign(nx - px) ? 2 : 4); } else { py += Math.sign(ny - py); push(px, py, 0); } }
        if (s === 0) push(x0, y0, 0);
      }
      fixDirs(C, o, dirs); return { cells: o, dirs };
    }
    const hFirst = Math.abs(dx) >= Math.abs(dy);
    let x = x0, y = y0; push(x, y, 0);
    if (hFirst) { while (x !== x1) { x += Math.sign(dx); push(x, y, 0); } while (y !== y1) { y += Math.sign(dy); push(x, y, 0); } }
    else { while (y !== y1) { y += Math.sign(dy); push(x, y, 0); } while (x !== x1) { x += Math.sign(dx); push(x, y, 0); } }
    fixDirs(C, o, dirs); return { cells: o, dirs };
  }
  function fixDirs(C, o, dirs) { // 각 칸의 진행 방향(1 북 2 동 3 남 4 서)
    const N = C.N;
    for (let k = 0; k < o.length; k++) { const a = o[Math.max(0, k - (k === o.length - 1 ? 1 : 0))], b = o[Math.min(o.length - 1, k + (k === o.length - 1 ? 0 : 1))]; const ax = a % N, ay = (a / N) | 0, bx = b % N, by = (b / N) | 0; dirs[k] = by < ay ? 1 : bx > ax ? 2 : by > ay ? 3 : bx < ax ? 4 : 0; }
    if (o.length === 1) dirs[0] = 0;
  }
  function rectCells(C, x0, y0, x1, y1) { const o = []; for (let y = Math.min(y0, y1); y <= Math.max(y0, y1); y++) for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x++) if (inb(C, x, y)) o.push(y * C.N + x); return o; }

  /* ================= 저장(이 기기) ================= */
  function rle(a) { const o = []; for (let i = 0; i < a.length;) { const v = a[i]; let n = 1; while (i + n < a.length && a[i + n] === v && n < 255) n++; o.push(n, v); i += n; } let s = ''; for (let i = 0; i < o.length; i += 8192) s += String.fromCharCode.apply(null, o.slice(i, i + 8192)); return btoa(s); }
  function unrle(str, NN) { const s = atob(str), a = new Uint8Array(NN); let p = 0; for (let i = 0; i + 1 < s.length; i += 2) { const n = s.charCodeAt(i), v = s.charCodeAt(i + 1); a.fill(v, p, p + n); p += n; } return a; }
  const SAVE8 = ['ter', 'ht', 'fr', 'rd', 'rdir', 'zn', 'bl', 'ab', 'pi', 'pl', 'dist', 'gar', 'dead', 'gnd8'];
  function serialize(C) {
    const o = { v: 2 }; for (const k of ['N', 'seed', 'mp', 'dis', 'md', 'goal', 'm', 'tier', 'mo', 'day', 'rs', 'tax', 'bud', 'pol', 'loans', 'hist', 'mx', 'hwEnd', 'hwStart', 'seaSide', 'goalAt', 'built', 'sc']) o[k] = C[k];
    o.B = C.B.map((b) => (b ? [b.t, b.x, b.y, Math.round(b.fl || 0)] : 0)); o.lines = C.lines.map((l) => ({ t: l.t, s: l.s, c: l.c }));
    o.A = {}; for (const k of SAVE8) o.A[k] = rle(C[k]); o.st = { pop: C.st.pop };
    return JSON.stringify(o);
  }
  function deserialize(str) {
    const o = JSON.parse(str); if (!o || o.v !== 2) return null;
    const C = { v: 2, st: null, fin: null, news: [], nid: 0, fires: [], lines: [], B: [] }; for (const k in o) if (k !== 'A' && k !== 'B' && k !== 'lines' && k !== 'st') C[k] = o[k];
    alloc(C); const NN = C.N * C.N; for (const k of SAVE8) if (o.A[k]) C[k] = unrle(o.A[k], NN);
    C.gnd = new Float32Array(NN); for (let i = 0; i < NN; i++) C.gnd[i] = C.gnd8[i];
    C.B = o.B.map((q) => (q ? { t: q[0], x: q[1], y: q[2], fl: q[3] } : null));
    C.B.forEach((b, id) => { if (b) for (const j of fpCells(C, b.x, b.y, SV[b.t].sz)) C.ob[j] = id + 1; });
    C.lines = (o.lines || []).map((l) => ({ t: l.t, s: l.s, c: l.c, rid: 0, rm: 0 }));
    for (const [k] of BUDG) if (C.bud[k] == null) C.bud[k] = 100;
    emptyStats(C); C.st.pop = (o.st && o.st.pop) || 0; C.job = { s: 0, k: 0 }; computeAcc(C); netsDirty(C);
    // 첫 달 통계를 바로 채움
    simStep(C, Infinity); C.job = { s: 0, k: 0 };
    return C;
  }
  /* 작은 지도(멀티 점수판·상대 도시 보기): S×S 글자 */
  function thumb(C, S) {
    const N = C.N, f = N / S; let out = '';
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const cnt = {}; let best = '.', bn = 0;
      for (let yy = Math.floor(y * f); yy < Math.floor((y + 1) * f); yy++) for (let xx = Math.floor(x * f); xx < Math.floor((x + 1) * f); xx++) {
        const i = yy * N + xx; let c = C.ter[i] === 1 ? '~' : C.ter[i] === 2 ? '^' : C.rd[i] ? 'r' : C.ob[i] ? 's' : C.zn[i] && C.bl[i] ? ZN[C.zn[i]].k : C.zn[i] ? 'z' : C.fr[i] ? 'f' : '.';
        if (c === 'r' && C.rd[i] === 4) c = 'h';
        const w = c === '.' ? 1 : c === 'f' ? 1.1 : c === '~' ? 1.2 : c === 'r' ? 1.6 : 2; cnt[c] = (cnt[c] || 0) + w; if (cnt[c] > bn) { bn = cnt[c]; best = c; }
      }
      out += best;
    }
    return out;
  }

  /* ================= AI 시장(자동 건설) ================= */
  /* 격자 블록을 고속도로 끝에서부터 바깥으로 넓혀 간다. 블록 = 도로 사이 6칸(양쪽 3칸씩 구역).
     lv1: 느리고 서비스·세금을 자주 놓침 · lv2: 기본 · lv3: 빠르고 교통·대중교통·세금까지 챙김. */
  const BS = 7; // 블록 간격(도로 1 + 6)
  function aiInit(C, lv) {
    const N = C.N, e = C.hwEnd, ex = e % N, ey = (e / N) | 0;
    const A = { lv, ox: ex, oy: ey, blocks: {}, ring: [], next: 0, t: 0, iSide: null, last: '' };
    // 고속도로 방향 → 산업은 고속도로 쪽, 주거는 반대쪽
    const sx = C.hwStart % N, sy = (C.hwStart / N) | 0; A.hdx = Math.sign(ex - sx); A.hdy = Math.sign(ey - sy);
    C.ai = A; return A;
  }
  function aiBlockOK(C, bx, by) {
    const A = C.ai, N = C.N, x0 = A.ox + bx * BS, y0 = A.oy + by * BS; let bad = 0, wat = 0;
    if (x0 < 1 || y0 < 1 || x0 + BS >= N - 1 || y0 + BS >= N - 1) return false;
    for (let y = y0; y <= y0 + BS; y++) for (let x = x0; x <= x0 + BS; x++) { const i = y * N + x; if (C.ter[i] === 2 || C.ob[i]) bad++; if (C.ter[i] === 1) wat++; }
    return bad === 0 && wat < 24;
  }
  function aiBuildBlock(C, bx, by) {
    const A = C.ai, N = C.N, x0 = A.ox + bx * BS, y0 = A.oy + by * BS;
    const ring = [];
    for (let x = x0; x <= x0 + BS; x++) { ring.push(y0 * N + x); ring.push((y0 + BS) * N + x); }
    for (let y = y0 + 1; y < y0 + BS; y++) { ring.push(y * N + x0); ring.push(y * N + x0 + BS); }
    const need = ring.filter((i) => !C.rd[i]);
    const P = roadPlan(C, need, 1); if (P.cost + 300 > C.m) return false;
    if (need.length) doRoad(C, need, 1);
    // 길 따라 수도관
    const pneed = ring.filter((i) => !C.pi[i]); if (pneed.length && pneed.length * PIPE_COST < C.m) doPipe(C, pneed, 'pi');
    A.blocks[bx + ',' + by] = { z: 0 };
    return true;
  }
  function aiZoneBlock(C, bx, by, z) {
    const A = C.ai, N = C.N, x0 = A.ox + bx * BS, y0 = A.oy + by * BS, cells = [];
    for (let y = y0 + 1; y < y0 + BS; y++) for (let x = x0 + 1; x < x0 + BS; x++) cells.push(y * N + x);
    const r = doZone(C, cells, z); if (r.ok) A.blocks[bx + ',' + by].z = z; return r.ok;
  }
  function aiFindSpot(C, t, near, maxR, pass) { // 시설 자리: 먼저 블록 안(구역 칸), 없으면 빈 땅
    if (pass == null) return aiFindSpot(C, t, near, maxR, 0) || aiFindSpot(C, t, near, maxR, 1);
    const N = C.N, s = SV[t], nx = near % N, ny = (near / N) | 0; let best = null;
    for (let r = 0; r <= maxR && !best; r++) for (let y = ny - r; y <= ny + r && !best; y++) for (let x = nx - r; x <= nx + r; x++) {
      if (Math.max(Math.abs(x - nx), Math.abs(y - ny)) !== r) continue; if (!inb(C, x, y)) continue;
      let ok = true; for (let yy = y; yy < y + s.sz && ok; yy++) for (let xx = x; xx < x + s.sz; xx++) { if (!inb(C, xx, yy)) { ok = false; break; } const i = yy * N + xx; if (C.ter[i] || C.rd[i] || C.ob[i] || (C.zn[i] && C.bl[i] >= 3) || (!pass && !C.zn[i])) { ok = false; break; } }
      if (!ok) continue; const P = svPlan(C, t, x, y); if (P.ok) { best = [x, y]; break; }
    }
    return best;
  }
  function aiShoreSpot(C, t, near, avoid, md) {
    if (md == null && SV[t].sw && avoid && avoid.length) return aiShoreSpot(C, t, near, avoid, 0) || aiShoreSpot(C, t, near, null, 0);
    if (md == null) return aiShoreSpot(C, t, near, avoid, 18) || aiShoreSpot(C, t, near, avoid, 9) || aiShoreSpot(C, t, near, avoid, 0);
    const N = C.N, s = SV[t], nx = near % N, ny = (near / N) | 0; let best = null, bd = 1e9;
    for (let y = 1; y < N - s.sz; y += 1) for (let x = 1; x < N - s.sz; x += 1) {
      const i = y * N + x; if (C.ter[i] || C.rd[i] || C.ob[i]) continue; if (C.ai && C.ai.wfail && C.ai.wfail[x + ',' + y]) continue;
      let d = Math.abs(x - nx) + Math.abs(y - ny);
      if (md === 0 && avoid && avoid.length) { if (d > 45) continue; d = -Math.min(...avoid.map((a) => Math.abs(x - a % N) + Math.abs(y - ((a / N) | 0)))); }
      if (d >= bd) continue;
      if (avoid && avoid.some((a) => Math.abs(x - a % N) + Math.abs(y - ((a / N) | 0)) < md)) continue;
      if (s.shore && !shoreCells(C, { t, x, y }).length) continue; const P = svPlan(C, t, x, y); if (P.ok || P.why === '도로에 붙여 지어요') { bd = d; best = [x, y]; }
    }
    return best;
  }
  function aiConnectPipe(C, from, to) { // 꺾은선으로 수도관 잇기
    const N = C.N, r = lineCells(C, from % N, (from / N) | 0, to % N, (to / N) | 0, 'line');
    return doPipe(C, r.cells, 'pi');
  }
  function aiConnectRoad(C, from, to) { const N = C.N, r = lineCells(C, from % N, (from / N) | 0, to % N, (to / N) | 0, 'line'); return doRoad(C, r.cells.filter((i) => !C.rd[i]), 1); }
  function aiNearestPipe(C, x, y) { const N = C.N; let best = -1, bd = 1e9; for (let i = 0; i < N * N; i++) if (C.pi[i]) { const d = Math.abs(i % N - x) + Math.abs(((i / N) | 0) - y); if (d < bd) { bd = d; best = i; } } return best; }
  function aiNearestRoad(C, x, y) { const N = C.N; let best = -1, bd = 1e9; for (let i = 0; i < N * N; i++) if (C.rd[i] && C.rd[i] !== 4) { const d = Math.abs(i % N - x) + Math.abs(((i / N) | 0) - y); if (d < bd) { bd = d; best = i; } } return best; }
  function aiCenter(C) { const A = C.ai; return (A.oy + Math.round(BS / 2)) * C.N + A.ox + Math.round(BS / 2); }
  function aiHas(C, id) { return C.B.some((b) => b && SV[b.t].id === id); }
  function aiPlace(C, id, near, R) {
    const t = SVI[id]; if (!unlocked(C, 'sv', t) || SV[t].cost > C.m) return false;
    const g = SV[t].g, must = g === 'pw' || g === 'wt' || g === 'sw' || g === 'gar' || g === 'dead';
    if (!must && C.mo > 3 && (C.fin.net || 0) < SV[t].up * 1.5) return false; // 유지비를 감당할 수 있을 때만
    const sp = aiFindSpot(C, t, near, R || 12); if (!sp) return false;
    const r = doSv(C, t, sp[0], sp[1]); return r.ok;
  }
  function aiCovered(C, g, i) { // 그 종류 시설이 (작동 여부와 상관없이) 반경 안에 있나
    const N = C.N, x = i % N, y = (i / N) | 0;
    for (const b of C.B) { if (!b) continue; const s = SV[b.t]; if (s.g !== g || !s.r || (s.store && b.fl >= s.store)) continue; const cx = b.x + s.sz / 2, cy = b.y + s.sz / 2; if ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= s.r * s.r * 0.8) return true; }
    return false;
  }
  function aiGap(C, g, list) { // 서비스 범위 밖 칸 하나
    const L0 = list || C._rL || []; if (!L0.length) return -1;
    for (let k = 0; k < 30; k++) { const i = L0[Math.floor(rnd(C) * L0.length)]; if (!aiCovered(C, g, i)) return i; }
    return -1;
  }
  function aiStep(C) {
    const A = C.ai, s = C.st, N = C.N, lv = A.lv;
    const rand = () => rnd(C);
    if (lv === 1 && rand() < 0.35) return; // 쉬움: 자주 멍
    const ctr = aiCenter(C);
    // 0) 첫 블록
    if (!Object.keys(A.blocks).length) {
      if (!A.found) { // 고속도로 끝 가까이에서 블록이 들어갈 자리 찾기
        const ex = A.ox, ey = A.oy; let ok = false;
        for (let r = 0; r <= 30 && !ok; r += 2) for (let dy = -r; dy <= r && !ok; dy += 2) for (let dx = -r; dx <= r; dx += 2) { if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue; A.ox = ex + dx; A.oy = ey + dy; if (aiBlockOK(C, 0, 0)) { ok = true; break; } }
        if (!ok) { A.ox = ex; A.oy = ey; } A.found = 1;
      }
      aiConnectRoad(C, C.hwEnd, (A.oy) * N + A.ox);
      aiBuildBlock(C, 0, 0);
      return;
    }
    const capOfG = (k) => { let v = 0; for (const b of C.B) if (b && SV[b.t][k] && !b.dirty && (b.on || b.act || C.mo - (b.bm || 0) < 2 || k === 'pw')) v += SV[b.t][k] * (SV[b.t].id === 'wind' ? 0.8 : 1); return v; };
    if (rand() < 0.3 && C.B.some((b) => b && (SV[b.t].wt || SV[b.t].sw) && !b.on)) { const b = C.B.find((q) => q && (SV[q.t].wt || SV[q.t].sw) && !q.on); if (b.wc == null || b.wc < 0) { if (aiLinkFacility(C)) return; } else aiPowerLink(C, b); }
    if (rand() < 0.3) { const dp = C.B.findIndex((b) => b && SV[b.t].wt && b.dirty); if (dp >= 0 && C.B.filter((b) => b && SV[b.t].wt && !b.dirty && b.on).length) { const b = C.B[dp]; doBull(C, [b.y * N + b.x], ''); return; } }
    if (C.mo % 2 === 0 && C.day < 10 && rand() < 0.3 && aiLinkFacility(C)) return;
    if (C.m < 0 && (C.fin.net || 0) < 0 && rand() < 0.5) { // 파산 직전: 유지비 큰 선택 시설부터 팔기
      let bi = -1, bu = 0; C.B.forEach((b, k) => { if (!b) return; const g = SV[b.t].g; if (g === 'pw' || g === 'wt' || g === 'sw' || g === 'gar') return; if (SV[b.t].up > bu) { bu = SV[b.t].up; bi = k; } });
      if (bi >= 0) { const b = C.B[bi]; doBull(C, [b.y * N + b.x], ''); return; }
    }
    if (rand() < 0.25) { // 더러운 취수장 옆 배출구를 멀리 옮기기
      const dp = C.B.find((b) => b && SV[b.t].wt && b.dirty);
      if (dp) { let bo = null, bd = 1e9; for (const b of C.B) if (b && SV[b.t].sw && SV[b.t].wp >= 1) { const d = Math.abs(b.x - dp.x) + Math.abs(b.y - dp.y); if (d < bd) { bd = d; bo = b; } } if (bo && bd < 30 && C.m > 6000) { doBull(C, [bo.y * N + bo.x], ''); if (aiWater(C, 'outlet')) return; } }
    }
    if (rand() < 0.15) { // 빠진 수도관 메우기
      for (const k of Object.keys(A.blocks)) { const [bx, by] = k.split(',').map(Number); const x0 = A.ox + bx * BS, y0 = A.oy + by * BS, ring = []; for (let x = x0; x <= x0 + BS; x++) { ring.push(y0 * N + x, (y0 + BS) * N + x); } for (let y = y0 + 1; y < y0 + BS; y++) { ring.push(y * N + x0, y * N + x0 + BS); } const need = ring.filter((i) => !C.pi[i]); if (need.length && need.length * PIPE_COST * 2 < C.m) { doPipe(C, need, 'pi'); return; } }
    }
    // 1) 전기
    const pwNeed = s.pwU * 1.15 + 6;
    if (Math.max(s.pwP, capOfG('pw') * 0.9) < pwNeed && s.pop + s.bld > 0) {
      const big = C.m > 15000 && (s.pwU > 20 || lv === 3);
      const id = C.tier >= 6 && C.m > 100000 && s.pwU > 250 ? 'nuke' : C.tier >= 3 && C.m > 20000 && s.pwU > 60 ? 'gas' : big ? 'coal' : 'wind';
      // 주거에서 멀리(산업 쪽) — 발전소는 기존 건물 옆(전기가 건너가게)
      const near = (C._iL && C._iL.length) ? C._iL[Math.floor(rand() * C._iL.length)] : ctr;
      if (aiPlace(C, id, near, 10)) return;
      if (id !== 'wind' && aiPlace(C, 'wind', near, 10)) return;
    }
    // 2) 물·하수
    const wNeed = s.wtU * 1.15 + 4;
    if (Math.max(s.wtP, capOfG('wt')) < wNeed && s.bld > 0) { if (aiWater(C, 'pump')) return; if (C.tier >= 4 && aiWater(C, 'purif')) return; if (C.tier >= 1) { const lf = C.B.filter((b) => b && SV[b.t].gnd); let best = null, bs = -1; for (let k = 0; k < 6; k++) { const L0 = C._rL || []; const c = L0.length ? L0[Math.floor(rand() * L0.length)] : ctr; const d = lf.length ? Math.min(...lf.map((b) => Math.abs(b.x - c % N) + Math.abs(b.y - ((c / N) | 0)))) : 99; if (d > bs && C.gnd[c] < 15) { bs = d; best = c; } } if (best != null && aiPlace(C, 'tower', best, 8)) { aiLinkFacility(C); return; } } }
    if (Math.max(s.swP, capOfG('sw')) < wNeed && s.bld > 0) { if (aiWater(C, C.tier >= 3 && C.m > 30000 ? 'sewage' : 'outlet')) return; }
    // 3) 쓰레기·묘지
    const hotG = C._gHot || [], hotD = C._dHot || [];
    if (s.pop > 200 && C.m > 7000) { const gap = aiGap(C, 'gar', hotG.length ? hotG : null); const short = s.garP < s.garU * 1.05 && C.B.filter((b) => b && SV[b.t].g === 'gar' && !b.act).length === 0; if (gap >= 0 || short) { const id = C.tier >= 3 && C.m > 30000 ? 'incin' : 'landfill'; if (aiPlace(C, id, gap >= 0 ? gap : ctr, 10)) return; } }
    if (C.tier >= 1 && s.pop > 500 && C.m > 6000 && (lv > 1 || rand() < 0.5)) { const gap = aiGap(C, 'dead', hotD.length ? hotD : null); const short = s.dP < s.dU * 1.05 && C.B.filter((b) => b && SV[b.t].g === 'dead' && !b.act).length === 0; if (gap >= 0 || short) { const id = C.tier >= 4 && C.m > 30000 ? 'crem' : 'cem'; if (aiPlace(C, id, gap >= 0 ? gap : ctr, 10)) return; } }
    // 4) 서비스 범위
    if (C.tier >= 1 && s.pop > 400) {
      const order = lv === 1 ? ['elem', 'fire', 'police', 'clinic'] : ['fire', 'elem', 'clinic', 'police'];
      for (const id of order) { if (lv === 1 && rand() < 0.5) continue; const g = SV[SVI[id]].g; if (s.pop < (C.B.filter((q) => q && SV[q.t].g === g).length + 1) * (lv === 3 ? 900 : 1100)) continue; const gap = aiGap(C, g); if (gap >= 0 && C.m > SV[SVI[id]].cost + 4000) { if (aiPlace(C, id, gap, 6)) return; } }
      if (C.tier >= 3) for (const id of ['high', 'hosp']) { const g = SV[SVI[id]].g; const gap = aiGap(C, g); if (gap >= 0 && C.m > SV[SVI[id]].cost + 8000 && rand() < (lv === 3 ? 0.9 : 0.5)) { if (aiPlace(C, id, gap, 8)) return; } }
      if (C.tier >= 5 && !aiHas(C, 'univ') && C.m > 60000) { if (aiPlace(C, 'univ', ctr, 14)) return; }
      if (lv >= 2 && rand() < 0.2 && C.B.filter((b) => b && SV[b.t].g === 'park').length < Object.keys(A.blocks).length / 4) { const gap = aiGap(C, 'park'); if (gap >= 0 && C.m > 4000) { if (aiPlace(C, C.tier >= 2 && C.m > 12000 ? 'bigpark' : 'park', gap, 4)) return; } }
      if (lv >= 2 && C.tier >= 3 && !aiHas(C, 'hall') && C.m > 40000) { if (aiPlace(C, 'hall', ctr, 12)) return; }
    }
    // 5) 어려움: 세금·교통·대중교통
    if (lv >= 2) {
      const net = C.fin.net || 0;
      if (net > 300 && C.m > 8000 && C.mo % (lv === 3 ? 2 : 4) === 0) { for (const k of ZK) if (s.dem[k] < (lv === 3 ? 25 : 12)) C.tax[k] = Math.max(lv === 3 ? 6 : 8, C.tax[k] - 1); }
      else if (net > 1500 && C.m > 60000 && C.mo % 3 === 0) for (const k of ZK) C.tax[k] = Math.max(8, C.tax[k] - 1);
      if (C.tier >= 2 && s.flow < (lv === 3 ? 70 : 60) && rand() < 0.5) { // 막힌 길 4차선으로
        let cnt = 0; const cells = []; for (let i = 0; i < N * N && cnt < 30; i++) if (C.rd[i] === 1 && C.cong[i] > 110) { cells.push(i); cnt++; }
        if (cells.length && C.m > cells.length * 120 + 5000) { doRoad(C, cells, 2); return; }
      }
      if (lv === 3 && C.tier >= 2 && s.pop > 2500 && C.m > 25000 && !A.bus && rand() < 0.3) { if (aiBus(C)) return; }
    }
    // 6) 돈이 바닥 → 대출
    if (C.m < 3000 && lv >= 2 && (C.fin.net || 0) > 300 && C.mo > 6) { if (takeLoan(C, 0)) return; }
    if ((C.fin.net || 0) < -100 && C.mo % 2 === 0 && rand() < (lv === 1 ? 0.3 : 0.8)) { for (const k of ZK) C.tax[k] = Math.min(lv === 1 ? 14 : 12, C.tax[k] + 1); }
    // 7) 구역 넓히기
    const D = s.dem; const want = [['R', D.R], ['C', D.C * 0.9], ['I', D.I * 0.9], ['O', D.O * 0.8]].sort((a, b) => b[1] - a[1]);
    let pick = want[0]; if (lv === 1 && rand() < 0.4) pick = want[Math.floor(rand() * 3)];
    const ez = { R: 0, C: 0, I: 0, O: 0 }; // 칠했지만 아직 빈 칸(바로 셈)
    for (const k of Object.keys(A.blocks)) { const B0 = A.blocks[k]; if (!B0.z) continue; const [bx, by] = k.split(',').map(Number); let e = 0; for (let y = A.oy + by * BS + 1; y < A.oy + by * BS + BS; y++) for (let x = A.ox + bx * BS + 1; x < A.ox + bx * BS + BS; x++) { const i = y * N + x; if (C.zn[i] && !C.bl[i] && C.ter[i] === 0) e++; } ez[ZN[B0.z].k] += e; }
    const ezMax = (50 + s.pop / 100) * (lv === 3 ? 1.6 : lv === 1 ? 0.7 : 1.1);
    if (pick[1] > 15 && ez[pick[0]] > ezMax) pick = want.find((w) => w[1] > 15 && ez[w[0]] <= ezMax) || ['', 0];
    if (pick[1] > 15) {
      // 비어 있는 같은 종류 구역이 많으면 기다림
      const keys = Object.keys(A.blocks);
      const emptyKey = keys.find((k) => !A.blocks[k].z && !A.blocks[k].res);
      const z = pick[0] === 'R' ? (C.tier >= 3 && rand() < (lv === 1 ? 0.4 : 0.75) ? Z_RH : Z_RL) : pick[0] === 'C' ? (C.tier >= 3 && rand() < 0.5 ? Z_CH : Z_CL) : pick[0] === 'I' ? Z_I : Z_O;
      if (emptyKey) { const [bx, by] = emptyKey.split(',').map(Number); if (aiZoneBlock(C, bx, by, z)) return; A.blocks[emptyKey].res = 1; }
      // 새 블록: 산업은 고속도로 쪽, 나머지는 반대쪽 우선
      const cand = [];
      for (const k of keys) { const [bx, by] = k.split(',').map(Number); for (let d = 0; d < 4; d++) { const nx = bx + DX[d], ny = by + DY[d]; if (A.blocks[nx + ',' + ny] || A.bad && A.bad[nx + ',' + ny]) continue; cand.push([nx, ny]); } }
      if (!cand.length) A.full = 1;
      if (A.full && pick[0] !== 'R') { // 땅이 없으면 비어 있는 주거 블록을 바꿈
        for (const k of keys) { const B0 = A.blocks[k]; if (B0.z !== Z_RL) continue; const [bx, by] = k.split(',').map(Number); let built = 0; for (let y = A.oy + by * BS + 1; y < A.oy + by * BS + BS; y++) for (let x = A.ox + bx * BS + 1; x < A.ox + bx * BS + BS; x++) if (C.bl[y * N + x]) built++; if (built < 6) { if (aiZoneBlock(C, bx, by, z)) return; } }
      }
      if (cand.length) {
        const side = pick[0] === 'I' ? -1 : 1;
        cand.sort((a, b) => (Math.abs(a[0]) + Math.abs(a[1]) + side * (a[0] * A.hdx + a[1] * A.hdy) * 0.6) - (Math.abs(b[0]) + Math.abs(b[1]) + side * (b[0] * A.hdx + b[1] * A.hdy) * 0.6));
        A.full = 0;
        for (const [bx, by] of cand.slice(0, 6)) {
          if (!aiBlockOK(C, bx, by)) { (A.bad = A.bad || {})[bx + ',' + by] = 1; continue; }
          if (aiBuildBlock(C, bx, by)) { aiZoneBlock(C, bx, by, z); return; }
          break;
        }
      }
    }
    // 7b) 재개발: 땅이 모자라면 저밀 주거 블록을 고밀·사무로
    if (C.tier >= 3 && C.m > 25000 && rand() < [0, 0.1, 0.25, 0.5][lv] && (A.full || C.m > 40000)) {
      const N0 = C.N; let best = null, bv = -1;
      for (const k of Object.keys(A.blocks)) { const B0 = A.blocks[k]; if (B0.z !== Z_RL && B0.z !== Z_CL) continue; const [bx, by] = k.split(',').map(Number); const c = (A.oy + by * BS + 3) * N0 + A.ox + bx * BS + 3; const v = C.lv[c] + rnd(C) * 10; if (v > bv) { bv = v; best = [bx, by, B0.z]; } }
      if (best && bv > (lv === 3 ? 18 : 28)) { const z = D.O > 40 && C.tier >= ZN[Z_O].tier && rand() < 0.5 ? Z_O : best[2] === Z_RL ? Z_RH : Z_CH; if (aiZoneBlock(C, best[0], best[1], z)) return; }
    }
    // 8) 시설 수도관 잇기(가끔)
    if (rand() < 0.25) aiLinkFacility(C);
  }
  function aiLinkFacility(C) { // 관에 안 닿은 상하수 시설 → 가장 가까운 관으로
    const N = C.N;
    const cnt = {}; let main = -1, mn = 0; if (C._wcomp) for (const i of (C._rL || [])) { const c = C.wc[i]; if (c >= 0) { cnt[c] = (cnt[c] || 0) + 1; if (cnt[c] > mn) { mn = cnt[c]; main = c; } } }
    for (const b of C.B) if (b && (SV[b.t].wt || SV[b.t].sw) && (b.wc == null || b.wc < 0 || (main >= 0 && b.wc !== main))) {
      let p = -1; if (main >= 0 && b.wc >= 0) { let bd = 1e9; for (let i = 0; i < N * N; i++) if (C.pi[i] && C._wcomp[i] === main) { const d = Math.abs(i % N - b.x) + Math.abs(((i / N) | 0) - b.y); if (d < bd) { bd = d; p = i; } } } else p = aiNearestPipe(C, b.x, b.y);
      if (p < 0) continue;
      const fx = Math.min(N - 1, b.x + SV[b.t].sz), r = aiConnectPipe(C, b.y * N + fx, p); if (r.ok) return true;
    }
    return false;
  }
  function aiWater(C, id) {
    const t = SVI[id]; if (!unlocked(C, 'sv', t) || SV[t].cost + 1500 > C.m) return false;
    const N = C.N, ctr = aiCenter(C);
    const avoid = C.B.filter((b) => b && (SV[t].wt ? SV[b.t].sw : (SV[b.t].wt && SV[b.t].shore))).map((b) => b.y * N + b.x);
    const sp = aiShoreSpot(C, t, ctr, avoid); if (!sp) return false;
    // 도로가 닿아야 지을 수 있음 → 근처 도로까지 길 먼저
    const r = doSv(C, t, sp[0], sp[1]);
    if (!r.ok) {
      const rd = aiNearestRoad(C, sp[0], sp[1]); if (rd < 0) return false;
      // 시설 옆 칸까지 도로
      const N2 = C.N, z = SV[t].sz; let done = false;
      for (const [tx, ty] of [[sp[0] + z, sp[1]], [sp[0] - 1, sp[1]], [sp[0], sp[1] + z], [sp[0], sp[1] - 1]]) {
        if (!inb(C, tx, ty) || C.ter[ty * N2 + tx] || C.ob[ty * N2 + tx]) continue;
        const fp = fpCells(C, sp[0], sp[1], z), lc = lineCells(C, rd % N2, (rd / N2) | 0, tx, ty, 'line').cells;
        if (lc.some((q) => fp.includes(q) || C.ob[q]) || lc.length > 80 || roadPlan(C, lc.filter((q) => !C.rd[q]), 1).cost > C.m * 0.4) continue;
        const rr = doRoad(C, lc.filter((q) => !C.rd[q]), 1); if (!rr.ok && !C.rd[ty * N2 + tx]) continue;
        if (doSv(C, t, sp[0], sp[1]).ok) { done = true; break; }
      }
      if (!done) { (C.ai.wfail = C.ai.wfail || {})[sp[0] + ',' + sp[1]] = 1; return false; }
    }
    const b = C.B[C.B.length - 1] && SV[C.B[C.B.length - 1].t].id === id ? C.B[C.B.length - 1] : C.B.find((q) => q && q.t === t && q.x === sp[0] && q.y === sp[1]);
    if (b) { const p = aiNearestPipe(C, b.x, b.y); if (p >= 0) aiConnectPipe(C, b.y * N + Math.min(N - 1, b.x + SV[t].sz), p); }
    // 전기도 이어야 → 송전선(시설에서 가장 가까운 건물까지)
    if (b) aiPowerLink(C, b);
    return true;
  }
  function aiPowerLink(C, b) {
    const N = C.N; let best = -1, bd = 1e9; const L0 = C._jL && C._jL.length ? C._jL.concat(C._rL || []) : (C._rL || []);
    for (const i of L0) { const d = Math.abs(i % N - b.x) + Math.abs(((i / N) | 0) - b.y); if (d < bd) { bd = d; best = i; } }
    if (best < 0 || bd < 3) return;
    const r = lineCells(C, b.x, b.y, best % N, (best / N) | 0, 'line');
    doPipe(C, r.cells.filter((i) => !C.ob[i] && !(C.zn[i] && C.bl[i])), 'pl');
  }
  function aiBus(C) {
    const A = C.ai, ctr = aiCenter(C);
    if (!aiHas(C, 'depot') && !aiPlace(C, 'depot', ctr, 10)) return false;
    const stops = []; const keys = Object.keys(A.blocks).slice(0, 10);
    for (const k of keys) { const [bx, by] = k.split(',').map(Number); const near = (A.oy + by * BS + 3) * C.N + A.ox + bx * BS + 3; const sp = aiFindSpot(C, SVI.stop, near, 3); if (sp) { const r = doSv(C, SVI.stop, sp[0], sp[1]); if (r.ok) stops.push(r.id); } if (stops.length >= 6) break; }
    if (stops.length >= 2) { lineAdd(C, 'bus', stops); A.bus = 1; return true; }
    return false;
  }

  /* ================= 시나리오 도전 =================
     시나리오 = 시작 지도·상태(setup) + 목표(obj, 2달 연속 지키면 성공) + 별(빨리 끝낼수록) + 실패 조건(fail·기한·파산).
     「미리 지은 도시」는 어려움 AI 시장이 몇 해 지은 도시(같은 seed → 같은 도시)를 쓰고, 그 위에 사건을 덧씌운다. */
  const SC_HOLD = 2, SC_DEBT = 80000;
  const SCN = [
    { id: 'flood', ic: '🌊', n: '홍수 복구', mp: 'river', pre: 36, m: 45000, lim: 36, s2: 20, s3: 10,
      d: '큰 홍수가 강가 동네를 휩쓸었어요. 물가 건물과 취수장·배출구가 떠내려가고 길이 끊겼어요. 홍수 전 인구를 되찾아요.',
      obj: (b) => [{ k: 'pop', op: '>=', v: Math.round(b.pop * 0.95 / 10) * 10, n: '인구(홍수 전의 95%)' }, { k: 'ab', op: '<=', v: 10, n: '버려진 건물' }, { k: 'hap', op: '>=', v: 50, n: '행복(%)' }] },
    { id: 'quake', ic: '🏚️', n: '지진 복구', mp: 'hills', pre: 36, m: 50000, lim: 30, s2: 12, s3: 6,
      d: '도시 한가운데를 큰 지진이 덮쳤어요. 건물이 무너지고 길이 갈라졌으며 발전소도 멈췄어요. 전기를 되살리고 도시를 다시 세워요.',
      obj: (b) => [{ k: 'pop', op: '>=', v: Math.round(b.pop / 10) * 10, n: '인구(지진 전만큼)' }, { k: 'ab', op: '<=', v: 10, n: '버려진 건물' }, { k: 'pwok', op: '>=', v: 1, n: '전기 충분(1=예)' }, { k: 'flow', op: '>=', v: 70, n: '교통 흐름(%)' }] },
    { id: 'rush', ic: '⏱️', n: '인구 목표 시간 제한', mp: 'rand', pre: 0, m: 80000, lim: 60, s2: 44, s3: 32,
      d: '빈 땅에서 시작해 5년 안에 인구 4,000명 도시를 만들어요. 빠를수록 별이 많아요.',
      obj: () => [{ k: 'pop', op: '>=', v: 4000, n: '인구' }] },
    { id: 'debt', ic: '💸', n: '적자 예산 살리기', mp: 'rand', pre: 36, m: -25000, lim: 36, s2: 24, s3: 14,
      d: '전임 시장이 세금을 깎고 예산을 펑펑 써서 금고가 바닥났어요. 빚을 갚고 흑자 도시로 돌려놓아요. 빚이 ₩80,000을 넘으면 파산이에요.',
      obj: () => [{ k: 'm', op: '>=', v: 20000, n: '금고(₩)' }, { k: 'net', op: '>=', v: 0, n: '한 달 수지(₩)' }, { k: 'hap', op: '>=', v: 45, n: '행복(%)' }] },
    { id: 'jam', ic: '🚗', n: '교통 지옥 정리', mp: 'rand', pre: 48, tw: 4, m: 60000, lim: 36, s2: 24, s3: 14,
      d: '큰길을 모두 좁은 길로 바꾸고 버스를 없앤 탓에 도시가 꽉 막혔어요. 게다가 이 도시 주민은 차를 유난히 많이 타요(차량 ×4). 길을 넓히고 대중교통을 깔아 차를 흐르게 해요.',
      obj: (b) => [{ k: 'flow', op: '>=', v: 80, n: '교통 흐름(%)' }, { k: 'pop', op: '>=', v: Math.round(b.pop * 0.9 / 10) * 10, n: '인구(지금의 90%)' }] },
    { id: 'smog', ic: '🏭', n: '공해 도시 정화', mp: 'rand', pre: 36, m: 60000, lim: 48, s2: 30, s3: 18,
      d: '석탄 발전소와 공장이 동네 한복판에 들어서 공기가 잿빛이에요. 주민이 아파요. 깨끗한 도시로 바꿔요.',
      obj: (b) => [{ k: 'air', op: '<=', v: Math.max(5, Math.round(b.air * 0.15)), n: '공기 나쁜 집 칸' }, { k: 'sick', op: '<=', v: 5, n: '아픈 주민 칸' }, { k: 'hap', op: '>=', v: 55, n: '행복(%)' }] },
    { id: 'tour', ic: '🎡', n: '관광 도시 만들기', mp: 'coast', pre: 30, m: 120000, lim: 48, s2: 32, s3: 22, ul: ['plaza', 'bigpark', 'garden', 'museum', 'rail', 'stadium', 'obs'],
      d: '이 도시를 관광 명소로! 식물원·박물관·기차역·경기장·전망 타워를 처음부터 지을 수 있어요(하나씩만인 건 하나씩). 관광객을 불러 모아요.',
      obj: () => [{ k: 'tour', op: '>=', v: 2000, n: '한 달 관광객' }, { k: 'hap', op: '>=', v: 55, n: '행복(%)' }] },
    { id: 'isle', ic: '🏝️', n: '섬 도시', mp: 'lake', pre: 0, m: 60000, lim: 72, s2: 54, s3: 40,
      d: '사방이 물인 작은 섬. 땅이 좁으니 빽빽하게 짓고 위로 키워야 해요. 다리(고속도로) 하나로 바깥과 이어져요.',
      obj: () => [{ k: 'pop', op: '>=', v: 3000, n: '인구' }, { k: 'hap', op: '>=', v: 50, n: '행복(%)' }] },
    { id: 'boom', ic: '🚀', n: '급성장 신도시', mp: 'rand', pre: 0, m: 300000, lim: 48, s2: 36, s3: 26,
      d: '정부 지원금 ₩300,000으로 4년 안에 인구 6,000명 신도시를 세워요. 너무 급하게 키워 주민이 불행해지면(행복 25% 미만) 실패!',
      obj: () => [{ k: 'pop', op: '>=', v: 6000, n: '인구' }, { k: 'hap', op: '>=', v: 55, n: '행복(%)' }, { k: 'flow', op: '>=', v: 60, n: '교통 흐름(%)' }],
      fail: [{ k: 'hap', op: '<', v: 25, after: 6, n: '행복 25% 미만' }] },
  ];
  const SCNI = {}; SCN.forEach((s) => { SCNI[s.id] = s; });
  const scCmp = (a, op, v) => (op === '>=' ? a >= v : op === '<=' ? a <= v : op === '<' ? a < v : a > v);
  function avgAir(C) { let n = 0; for (let i = 0; i < C.N * C.N; i++) if (C.bl[i] && zkOf(C.zn[i]) === 'R' && C.air[i] >= 8) n++; return n; } // 공기 나쁜 집 칸(대기 오염 8 이상)
  function scM(C, k) {
    const s = C.st;
    switch (k) {
      case 'pop': return s.pop; case 'hap': return s.hap; case 'flow': return s.flow; case 'm': return Math.round(C.m); case 'net': return Math.round((C.fin && C.fin.net) || 0);
      case 'ab': return s.ab; case 'tour': return s.tour || 0; case 'sick': return s.sickN; case 'air': return avgAir(C);
      case 'pwok': return s.pwU > 0 && s.pwP >= s.pwU * 0.97 ? 1 : 0;
    }
    return 0;
  }
  function scenPrebuild(C, months) {
    aiInit(C, 3);
    for (let mo = 0; mo < months; mo++) for (let d = 0; d < 30; d++) { if (C.m < 40000) C.m += 30000; if (C.day % 8 === 0) aiStep(C); dayTick(C); }
    delete C.ai; C.fires = []; C.burn.fill(0);
  }
  const scRefresh = (C) => { netsDirty(C); computeAcc(C); C.job = { s: 0, k: 0 }; simStep(C, Infinity); C.job = { s: 0, k: 0 }; };
  function scenIsland(C) { // 가운데 둥근 섬만 남기고 물. 고속도로는 다리로 남김
    const N = C.N, cx = N / 2, cy = N / 2, R0 = N * 0.27;
    for (let i = 0; i < N * N; i++) { const x = i % N, y = (i / N) | 0, d = Math.hypot(x - cx, y - cy) + Math.sin(Math.atan2(y - cy, x - cx) * 5) * 2.5; if (d > R0) { C.ter[i] = 1; C.fr[i] = 0; C.ht[i] = Math.min(C.ht[i], 40); } else if (C.ter[i] === 1 && d < R0 - 3) { C.ter[i] = 0; C.ht[i] = 70; } }
    for (let i = 0; i < N * N; i++) if (C.rd[i] === 4) C.rd[i] = 0;
    const sx = C.hwStart % N, sy = (C.hwStart / N) | 0; let x = sx, y = sy; const cells = [];
    while (Math.hypot(x - cx, y - cy) > R0 - 6) { cells.push(y * N + x); if (Math.abs(cx - x) > Math.abs(cy - y)) x += Math.sign(cx - x); else y += Math.sign(cy - y); }
    cells.push(y * N + x); for (const i of cells) { C.rd[i] = 4; if (C.ter[i] === 2) C.ter[i] = 0; }
    C.hwEnd = cells[cells.length - 1];
  }
  function scenTwist(C, id) {
    const N = C.N, NN = N * N, R = () => rnd(C);
    const killSv = (pred) => { for (let k = 0; k < C.B.length; k++) { const b = C.B[k]; if (b && pred(b, SV[b.t])) { for (const j of fpCells(C, b.x, b.y, SV[b.t].sz)) C.ob[j] = 0; C.B[k] = null; C.lines.forEach((ln) => { ln.s = ln.s.filter((q) => q !== k); ln.path = null; }); } } C.lines = C.lines.filter((ln) => ln.s.length >= 2); };
    const edgeHw = (i) => C.rd[i] === 4;
    if (id === 'flood') {
      const wd = waterDist(C); C._wd = wd; let n = 0;
      for (let i = 0; i < NN; i++) { if (wd[i] > 4) continue; if (C.bl[i] && R() < 0.85) { C.bl[i] = 0; C.ab[i] = 0; n++; } if (C.rd[i] && !edgeHw(i) && wd[i] <= 2 && R() < 0.5) { C.rd[i] = 0; C.rdir[i] = 0; } if (C.pi[i] && R() < 0.5) C.pi[i] = 0; }
      killSv((b, s) => s.shore || wd[b.y * N + b.x] <= 2);
      news(C, 'flood', '🌊 대홍수! 물가 건물 ' + n + '채가 쓸려 갔어요. 물가 시설과 길도 끊겼어요.');
    } else if (id === 'quake') {
      const ctr = C._ctr; const cx = ctr % N, cy = (ctr / N) | 0, rr = 16; let n = 0;
      for (let i = 0; i < NN; i++) { const x = i % N, y = (i / N) | 0, d = Math.hypot(x - cx, y - cy); if (d > rr) continue; const p = 0.75 * (1 - d / rr) + 0.2; if (C.bl[i] && R() < p) { C.bl[i] = 0; C.ab[i] = 0; n++; } if (C.rd[i] && !edgeHw(i) && R() < p * 0.35) { C.rd[i] = 0; C.rdir[i] = 0; } if (C.pl[i] && R() < p) C.pl[i] = 0; }
      killSv((b, s) => s.g === 'pw');
      news(C, 'fire', '🏚️ 큰 지진! 건물 ' + n + '채가 무너지고 발전소가 모두 멈췄어요.');
    } else if (id === 'debt') {
      C.tax = { R: 4, C: 4, I: 4, O: 4 }; for (const [k] of BUDG) C.bud[k] = 150;
      C.loans = [{ k: 0, a: LOANS[0].a, pay: Math.round(LOANS[0].a * (1 + LOANS[0].r * 2) / 24), left: 24 }];
      news(C, 'money', '💸 금고가 비었어요. 세율 4%, 서비스 예산 150%, 대출 상환이 남아 있어요.');
    } else if (id === 'jam') {
      for (let i = 0; i < NN; i++) if (C.rd[i] === 2 || C.rd[i] === 3) { C.rd[i] = 1; C.rdir[i] = 0; }
      killSv((b, s) => s.g === 'tr'); C.lines = [];
      const touch = []; for (let i = 0; i < NN; i++) { if (!C.rd[i] || C.rd[i] === 4) continue; const x = i % N, y = (i / N) | 0; for (let d = 0; d < 4; d++) { const xx = x + DX[d], yy = y + DY[d]; if (inb(C, xx, yy) && C.rd[yy * N + xx] === 4) { touch.push(i); break; } } }
      touch.slice(1).forEach((i) => { C.rd[i] = 0; }); // 고속도로 나들목은 하나만
      news(C, 'traffic', '🚗 큰길이 모두 2차선이 되고 버스가 멈췄어요. 나들목도 하나뿐이에요. 이 도시는 차를 많이 타요(차량 ×4).');
    } else if (id === 'smog') {
      killSv((b, s) => s.g === 'pw');
      const rl = []; for (let i = 0; i < NN; i++) if (zkOf(C.zn[i]) === 'R' && C.bl[i]) rl.push(i);
      let placed = 0;
      for (let t = 0; t < 400 && placed < 4; t++) {
        const i = rl[Math.floor(R() * rl.length)]; if (i == null) break; const x = i % N, y = (i / N) | 0;
        for (const [dx, dy] of [[0, 0], [-1, 0], [0, -1], [-1, -1]]) {
          const xx = x + dx, yy = y + dy; let ok = xx >= 0 && yy >= 0 && xx + 2 <= N && yy + 2 <= N;
          if (ok) for (const j of fpCells(C, xx, yy, 2)) if (C.ter[j] || C.rd[j] || C.ob[j]) ok = false;
          if (!ok || roadAdj(C, { t: SVI.coal, x: xx, y: yy }) < 0) continue;
          const m0 = C.m; C.m = 1e9; const r = doSv(C, SVI.coal, xx, yy); C.m = m0; if (r.ok) { placed++; break; }
        }
      }
      for (let i = 0; i < NN; i++) if ((C.zn[i] === Z_CL && R() < 0.5) || (C.zn[i] === Z_RL && R() < 0.08)) { if (C.bl[i]) C.zn[i] = Z_I; }
      news(C, 'warn', '🏭 동네 한복판에 석탄 발전소 ' + placed + '곳과 공장이 들어섰어요. 공기가 나빠요.');
    }
  }
  function scenSetup(C, id) {
    const S0 = SCNI[id] || SCN[0];
    if (id === 'isle') scenIsland(C);
    if (S0.pre) scenPrebuild(C, S0.pre);
    if (id === 'quake') { let best = -1, bn = -1; for (let i = 0; i < C.N * C.N; i += 7) { if (!C.bl[i]) continue; let n = 0; const x = i % C.N, y = (i / C.N) | 0; for (let dy = -6; dy <= 6; dy += 2) for (let dx = -6; dx <= 6; dx += 2) { const xx = x + dx, yy = y + dy; if (inb(C, xx, yy) && C.bl[yy * C.N + xx]) n++; } if (n > bn) { bn = n; best = i; } } C._ctr = best < 0 ? C.hwEnd : best; }
    scRefresh(C);
    const pre = { pop: C.st.pop };
    scenTwist(C, S0.id);
    C.m = S0.m; C.mo = 0; C.day = 0; C.hist = []; C.mx = 0; C.news = C.news.slice(-1);
    scRefresh(C); if (S0.tw) { scRefresh(C); scRefresh(C); } // 교통량이 자리 잡도록
    const base = { pop: S0.id === 'jam' || S0.id === 'smog' ? C.st.pop : pre.pop, air: avgAir(C) };
    C.sc = { id: S0.id, lim: S0.lim, s2: S0.s2, s3: S0.s3, obj: S0.obj(base), fail: S0.fail || [], ul: S0.ul || [], tw: S0.tw || 0, ok: [], streak: 0, end: '', stars: 0, at: 0, why: '' };
    C.sc.ok = C.sc.obj.map((o) => scCmp(scM(C, o.k), o.op, o.v));
    return C;
  }
  function scenEval(C) {
    const sc = C.sc; if (!sc || sc.end) return;
    const el = C.mo;
    sc.ok = sc.obj.map((o) => scCmp(scM(C, o.k), o.op, o.v));
    if (sc.ok.every(Boolean)) {
      sc.streak++;
      if (sc.streak >= SC_HOLD) { sc.end = 'win'; sc.at = el; sc.stars = el <= sc.s3 ? 3 : el <= sc.s2 ? 2 : 1; news(C, 'good', '🎯 시나리오 성공! ' + '★'.repeat(sc.stars) + '☆'.repeat(3 - sc.stars) + ' (' + el + '달)'); return; }
    } else sc.streak = 0;
    if (C.m < -SC_DEBT) { sc.end = 'fail'; sc.why = '파산(빚 ' + won(-C.m) + ')'; }
    for (const f of sc.fail) if (!sc.end && el >= (f.after || 0) && scCmp(scM(C, f.k), f.op, f.v)) { sc.end = 'fail'; sc.why = f.n; }
    if (!sc.end && el >= sc.lim) { sc.end = 'fail'; sc.why = '기한(' + sc.lim + '달) 끝'; }
    if (sc.end === 'fail') { sc.at = el; news(C, 'warn', '⛔ 시나리오 실패 — ' + sc.why); }
  }

  /* ================= 시장 비서(자료 보고서 + 선택 AI 문장) ================= */
  function aideFacts(C) {
    const s = C.st, a = C.alerts || {}, f = C.fin || {};
    const F = { 날짜: (Math.floor(C.mo / 12) + 1) + '년 ' + (C.mo % 12 + 1) + '월', 단계: TIERS[C.tier].n, 인구: s.pop, 금고: Math.round(C.m), 월수지: Math.round(f.net || 0), 행복: s.hap, 교통흐름: s.flow,
      수요: { 주거: Math.round(s.dem.R), 상업: Math.round(s.dem.C), 산업: Math.round(s.dem.I) }, 실업률: Math.round((s.unemp || 0) * 100), 버려진건물: s.ab, 아픈칸: s.sickN, 범죄: Math.round(s.crime || 0),
      전기: [Math.round(s.pwU), Math.round(s.pwP)], 물: [Math.round(s.wtU), Math.round(s.wtP)], 하수: [Math.round(s.swU), Math.round(s.swP)], 자원설명: '[필요(사용), 공급]', 공기나쁜집: avgAir(C), 세율: C.tax, 관광객: s.tour || 0,
      부족: Object.keys(a).filter((k) => a[k]) };
    if (C.sc) { const S0 = SCNI[C.sc.id]; F.시나리오 = { 이름: S0.n, 남은달: Math.max(0, C.sc.lim - C.mo), 목표: C.sc.obj.map((o, k) => ({ 항목: o.n, 지금: scM(C, o.k), 기준: o.v + (o.op === '>=' ? ' 이상' : ' 이하'), 달성: scCmp(scM(C, o.k), o.op, o.v) && k >= 0 })) }; }
    return F;
  }
  function aideReport(F) { // 심각한 순서로 {ic, t 문제, a 조언}
    const out = [], A = F.부족;
    if (A.includes('out')) out.push([9, '🛣️', '도로가 바깥 고속도로와 끊겼어요.', '고속도로 끝과 동네 길을 이어요.']);
    if (A.includes('money')) out.push([8, '💸', '금고가 ' + won(F.금고) + '로 바닥났어요(한 달 ' + won(F.월수지) + ').', '세율을 1~2%p 올리거나 쓰지 않는 서비스 예산을 줄여요.']);
    else if (F.월수지 < 0) out.push([5, '📉', '매달 ' + won(-F.월수지) + '씩 적자예요.', '예산 화면에서 유지비가 큰 항목을 살피고, 수요 높은 구역을 늘려 세수를 키워요.']);
    if (A.includes('pw')) out.push([8, '⚡', '전기가 모자라요(필요 ' + F.전기[0] + ' · 공급 ' + F.전기[1] + ' MW).', '발전소를 하나 더 짓고 송전선으로 이어요.']);
    if (A.includes('wt')) out.push([8, '💧', '물이 모자라요(필요 ' + F.물[0] + ' · 공급 ' + F.물[1] + ' 톤).', '취수장을 더 짓고 수도관을 동네까지 이어요.']);
    if (A.includes('sw')) out.push([7, '🚽', '하수가 넘쳐요(나옴 ' + F.하수[0] + ' · 처리 ' + F.하수[1] + ' 톤).', '취수장에서 먼 물가에 하수 배출구를 늘려요.']);
    if (A.includes('gar')) out.push([6, '🗑️', '쓰레기가 쌓이고 있어요.', '동네 가까이 매립지나 소각장을 지어요.']);
    if (A.includes('dead')) out.push([5, '⚱️', '추모 공원이 모자라요.', '추모 공원을 하나 더 지어요.']);
    if (F.버려진건물 > 5) out.push([6, '🏚️', '버려진 건물이 ' + F.버려진건물 + '채예요.', '그 칸을 눌러 무엇이 끊겼는지(전기·물·도로) 확인해요.']);
    if (F.아픈칸 > 5) out.push([6, '🤢', '더러운 물로 아픈 칸이 ' + F.아픈칸 + '곳이에요.', '취수장을 하수 배출구 위쪽으로 옮기거나 정수장을 지어요.']);
    if (F.인구 > 0 && F.교통흐름 < 70) out.push([F.교통흐름 < 55 ? 7 : 4, '🚗', '교통 흐름이 ' + F.교통흐름 + '%예요.', '🗺 교통 화면의 빨간 길을 4차선·일방통행으로 바꾸고 버스 노선을 깔아요.']);
    if (F.공기나쁜집 > 15) out.push([5, '🏭', '공기가 나쁜 집이 ' + F.공기나쁜집 + '칸이에요.', '공장·석탄 발전소를 주거지에서 떨어뜨리고 공원을 지어요(친환경 산업 정책도 좋아요).']);
    if (F.인구 > 0 && F.행복 < 50) out.push([5, '😟', '행복이 ' + F.행복 + '%로 낮아요.', '공원·보건소·학교를 늘리고 세율을 조금 낮춰요.']);
    if (F.실업률 > 15) out.push([4, '💼', '실업률이 ' + F.실업률 + '%예요.', '산업·상업 구역을 더 칠해 일자리를 만들어요.']);
    const top = Object.entries(F.수요).sort((a, b) => b[1] - a[1])[0]; if (top && top[1] > 30) out.push([3, '📈', top[0] + ' 수요가 ' + top[1] + '로 높아요.', top[0] + ' 구역을 더 칠해요.']);
    if (F.시나리오) { const miss = F.시나리오.목표.filter((o) => !o.달성); if (miss.length) out.push([7.5, '🎯', '남은 ' + F.시나리오.남은달 + '달, 못 채운 목표: ' + miss.map((o) => o.항목 + ' ' + o.지금 + '(' + o.기준 + ')').join(', ') + '.', '이 목표부터 챙겨요.']); }
    if (!out.length) out.push([0, '👍', '큰 문제는 없어요.', '수요가 높은 구역을 늘려 도시를 키워요.']);
    return out.sort((a, b) => b[0] - a[0]).slice(0, 5).map((r) => ({ ic: r[1], t: r[2], a: r[3] }));
  }
  const numsIn = (t) => (String(t).match(/\d[\d,]*(\.\d+)?/g) || []).map((v) => v.replace(/,/g, '').replace(/^0+(?=\d)/, ''));
  function aideCheck(text, F, rep) { // AI 글의 숫자가 모두 자료(사실·보고서)에 있는 숫자인지
    if (!text || /[A-Za-z]{3,}/.test(text)) return false;
    const ok = new Set(numsIn(JSON.stringify(F) + ' ' + rep.map((r) => r.t + ' ' + r.a).join(' ')));
    return numsIn(text).every((v) => ok.has(v));
  }

  const sim = {
    newCity, simStep, dayTick, monthEnd, doRoad, doZone, doSv, doPipe, doBull, doDist, lineAdd, takeLoan, repayLoan, roadPlan, zonePlan, svPlan,
    lineCells, rectCells, serialize, deserialize, thumb, aiInit, aiStep, computePower, computeWater, computeAcc, computeCov, astar, busPath, capOf, targetLevel,
    SCN, scenSetup, scenEval, scM, aideFacts, aideReport, aideCheck,
  };

  /* ================= 뷰 ================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const SPEEDS = [0, 0.42, 0.21, 0.1]; // 하루 길이(초): 정지·1×·2×·3×
  const CS = 8; // 지도 캐시: 칸당 픽셀
  const CSS = `
  .cb-hud{position:absolute;left:0;right:0;top:0;z-index:6;background:linear-gradient(rgba(20,17,28,.97),rgba(20,17,28,.9));border-bottom:1px solid rgba(227,174,69,.22);padding:4px 6px 2px;font-family:var(--f-body);color:var(--ink)}
  .cb-row{display:flex;align-items:center;gap:4px}
  .cb-chip{min-height:44px;display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:0;line-height:1.15;padding:0 8px;border-radius:12px;background:var(--surface-2);border:1px solid rgba(255,255,255,.06);color:var(--ink);font:600 13px var(--f-mono);white-space:nowrap;cursor:pointer;position:relative}
  .cb-chip.neg{color:#ff8e7a}.cb-chip small{font:500 10.5px var(--f-body);color:var(--muted)}
  .cb-fill{flex:1;min-width:0}
  .cb-sp{width:40px;min-width:36px;height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.08);background:var(--surface);color:var(--ink);font-size:13px;font-weight:700;padding:0;position:relative;cursor:pointer}
  .cb-sp.on{background:var(--brass);color:#22180c;border-color:var(--brass)}
  .cb-sp:disabled{opacity:.5}
  .cb-sub{display:flex;align-items:center;gap:8px;height:26px;font-size:11px;color:var(--muted);padding:0 2px;white-space:nowrap;overflow:hidden}
  .cb-rci{display:flex;gap:5px;align-items:center}
  .cb-rci span{display:flex;align-items:center;gap:2px;font:600 10.5px var(--f-mono)}
  .cb-rci i{display:block;width:8px;height:20px;border-radius:3px;background:rgba(255,255,255,.1);position:relative;overflow:hidden}
  .cb-rci i b{position:absolute;left:0;right:0;bottom:0}
  .cb-al{font-size:14px;animation:cbBlink 1s steps(2) infinite;cursor:pointer}
  @keyframes cbBlink{50%{opacity:.35}}
  .cb-bar{position:absolute;left:0;right:0;bottom:0;z-index:6;background:linear-gradient(rgba(20,17,28,.9),rgba(20,17,28,.98));border-top:1px solid rgba(227,174,69,.22);font-family:var(--f-body)}
  .cb-tools{display:flex;gap:4px;overflow-x:auto;padding:5px 6px 7px;scrollbar-width:none;touch-action:pan-x}
  .cb-tools::-webkit-scrollbar,.cb-subs::-webkit-scrollbar{display:none}
  .cb-t{flex:0 0 auto;width:54px;height:52px;border-radius:12px;border:1px solid rgba(255,255,255,.07);background:var(--surface);color:var(--ink);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;padding:0;cursor:pointer;position:relative}
  .cb-t b{font-size:18px;line-height:1.1;font-weight:400}
  .cb-t small{font-size:10.5px;color:var(--muted);white-space:nowrap}
  .cb-t.on{background:#3a2f22;border-color:var(--brass)}.cb-t.on small{color:var(--brass)}
  .cb-subs{display:flex;gap:4px;overflow-x:auto;padding:5px 6px 0;scrollbar-width:none;touch-action:pan-x}
  .cb-s{flex:0 0 auto;min-width:76px;height:48px;border-radius:11px;border:1px solid rgba(255,255,255,.07);background:var(--surface-2);color:var(--ink);display:flex;align-items:center;gap:5px;padding:0 8px;text-align:left;cursor:pointer;position:relative}
  .cb-s b{font-size:17px;font-weight:400}
  .cb-s span{display:flex;flex-direction:column;font-size:11.5px;line-height:1.2;white-space:nowrap}
  .cb-s em{font-style:normal;font:10.5px var(--f-mono);color:var(--brass)}
  .cb-s.on{border-color:var(--brass);background:#3a2f22}
  .cb-s.lock{opacity:.42}
  .cb-s.mode{min-width:52px;justify-content:center;background:var(--surface)}
  .cb-side{position:absolute;right:6px;z-index:5;display:flex;flex-direction:column;gap:5px}
  .cb-side button{width:44px;height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:rgba(34,28,46,.92);color:var(--ink);font-size:17px;padding:0;cursor:pointer;position:relative}
  .cb-side button.on{border-color:var(--brass);color:var(--brass);background:#3a2f22}
  .cb-badge{position:absolute;top:-3px;right:-3px;min-width:16px;height:16px;border-radius:8px;background:var(--coral);color:#fff;font:700 10px/16px var(--f-mono);padding:0 3px}
  .cb-legend{position:absolute;left:8px;z-index:4;pointer-events:none;background:rgba(20,17,28,.88);border-radius:9px;padding:4px 8px;font-size:11px;color:var(--ink);display:flex;align-items:center;gap:6px;max-width:calc(100% - 70px)}
  .cb-legend i{display:block;width:64px;height:8px;border-radius:4px;flex:0 0 auto}
  .cb-hint{position:absolute;left:8px;right:58px;z-index:4;pointer-events:none;font-size:12px;color:var(--ink);text-shadow:0 1px 3px #000;opacity:.92}
  .cb-ov{position:absolute;inset:0;z-index:15;display:flex;align-items:flex-end;justify-content:center;background:rgba(10,8,15,.55)}
  .cb-sheet{width:100%;max-width:560px;max-height:86%;overflow-y:auto;background:var(--surface);border-radius:18px 18px 0 0;padding:12px 14px 18px;color:var(--ink);font-family:var(--f-body);box-shadow:0 -10px 30px rgba(0,0,0,.5)}
  .cb-sheet h3{margin:0 0 8px;font:400 19px var(--f-display);color:var(--brass);display:flex;align-items:center;justify-content:space-between;gap:8px}
  .cb-sheet h4{margin:12px 0 6px;font-size:13px;color:var(--muted);font-weight:600}
  .cb-x{width:44px;height:44px;border-radius:12px;border:0;background:var(--surface-2);color:var(--ink);font-size:18px;cursor:pointer;flex:0 0 auto}
  .cb-line{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:28px;font-size:13px}
  .cb-line .mono{font-family:var(--f-mono)}
  .cb-pm{display:flex;align-items:center;gap:6px}
  .cb-pm button{width:44px;height:44px;border-radius:12px;border:1px solid rgba(255,255,255,.1);background:var(--surface-2);color:var(--ink);font-size:18px;cursor:pointer}
  .cb-pm b{min-width:46px;text-align:center;font:600 14px var(--f-mono)}
  .cb-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:6px}
  .cb-grid button{min-height:46px;border-radius:12px;border:1px solid rgba(255,255,255,.08);background:var(--surface-2);color:var(--ink);font-size:12.5px;cursor:pointer;padding:4px}
  .cb-grid button.on{border-color:var(--brass);color:var(--brass);background:#3a2f22}
  .cb-tabs{display:flex;gap:4px;overflow-x:auto;margin-bottom:8px}
  .cb-tabs button{flex:0 0 auto;min-height:40px;padding:0 10px;border-radius:10px;border:1px solid rgba(255,255,255,.1);background:var(--surface-2);color:var(--ink);cursor:pointer;font-size:12.5px}
  .cb-tabs button.on{border-color:var(--brass);color:var(--brass)}
  .cb-pol{display:flex;align-items:center;gap:8px;padding:6px 8px;border-radius:12px;background:var(--surface-2);margin-bottom:5px;font-size:12.5px}
  .cb-pol div{flex:1;min-width:0}.cb-pol small{display:block;color:var(--muted);font-size:11.5px}
  .cb-pol button{min-width:64px;height:44px;border-radius:11px;border:1px solid rgba(255,255,255,.1);background:var(--surface);color:var(--ink);cursor:pointer}
  .cb-pol button.on{background:var(--brass);color:#22180c}
  .cb-news{font-size:12px;color:var(--muted);padding:5px 0;border-bottom:1px solid rgba(255,255,255,.05);display:flex;gap:6px;align-items:center}
  .cb-news span{flex:1}
  .cb-news button{width:44px;height:36px;border-radius:9px;border:0;background:var(--surface-2);color:var(--ink);cursor:pointer}
  .cb-info{position:absolute;left:8px;right:58px;z-index:7;background:rgba(34,28,46,.97);border:1px solid rgba(227,174,69,.3);border-radius:14px;padding:8px 10px;color:var(--ink);font-family:var(--f-body);font-size:12.5px;display:flex;gap:8px;align-items:flex-start;box-shadow:0 6px 20px rgba(0,0,0,.5);max-height:46%;overflow-y:auto}
  .cb-info .bd{flex:1;min-width:0}.cb-info b{font-size:14px}
  .cb-info .kv{display:flex;flex-wrap:wrap;gap:2px 10px;margin-top:4px;color:var(--muted)}
  .cb-info .kv em{font-style:normal;color:var(--ink);font-family:var(--f-mono)}
  .cb-info .need{margin-top:4px;color:#ffcf7a;font-size:12px}
  .cb-info .bad{color:#ff9c87}
  .cb-tip{position:absolute;inset:0;z-index:20;display:flex;align-items:center;justify-content:center;background:rgba(10,8,15,.6);padding:16px}
  .cb-tip .cb-sheet{border-radius:18px;max-height:90%}
  .cb-sb{display:flex;align-items:center;gap:8px;padding:6px;border-radius:12px;background:var(--surface-2);margin-bottom:6px}
  .cb-sb canvas{width:60px;height:60px;border-radius:8px;flex:0 0 auto;image-rendering:pixelated}
  .cb-sb div{flex:1;min-width:0;font-size:12.5px}.cb-sb b{font-size:14px}
  `;
  const CATS = [
    { id: 'view', ic: '👆', n: '보기', k: 'KeyV' },
    { id: 'road', ic: '🛣️', n: '도로', k: 'KeyR', tools: ['road:1', 'road:3', 'road:2', 'road:4', 'mode:line', 'mode:curve', 'mode:free'] },
    { id: 'zone', ic: '🏘️', n: '구역', k: 'KeyZ', tools: ['zone:1', 'zone:2', 'zone:3', 'zone:4', 'zone:5', 'zone:6', 'zone:0'] },
    { id: 'pw', ic: '⚡', n: '전기', k: 'KeyE', tools: ['sv:wind', 'sv:coal', 'sv:gas', 'sv:solar', 'sv:nuke', 'pl'] },
    { id: 'wt', ic: '💧', n: '상하수도', k: 'KeyW2', tools: ['pi', 'sv:pump', 'sv:outlet', 'sv:tower', 'sv:sewage', 'sv:purif'] },
    { id: 'gar', ic: '🗑️', n: '위생', tools: ['sv:landfill', 'sv:cem', 'sv:incin', 'sv:crem', 'sv:recyc'] },
    { id: 'safe', ic: '🚒', n: '안전·의료', tools: ['sv:fire', 'sv:police', 'sv:clinic', 'sv:hosp', 'sv:firehq', 'sv:polhq'] },
    { id: 'edu', ic: '🏫', n: '교육', tools: ['sv:elem', 'sv:high', 'sv:univ'] },
    { id: 'park', ic: '🌳', n: '공원', tools: ['sv:park', 'sv:plaza', 'sv:bigpark', 'sv:garden'] },
    { id: 'tr', ic: '🚌', n: '대중교통', tools: ['sv:depot', 'sv:stop', 'line:bus', 'sv:metro', 'line:metro', 'sv:rail'] },
    { id: 'lm', ic: '🏛️', n: '특별', tools: ['sv:hall', 'sv:museum', 'sv:stadium', 'sv:obs', 'sv:port', 'sv:airport'] },
    { id: 'dist', ic: '🗺️', n: '지구', tools: ['dist:1', 'dist:2', 'dist:3', 'dist:4', 'dist:5', 'dist:6', 'dist:0'] },
    { id: 'bull', ic: '🧹', n: '철거', k: 'KeyB', tools: ['bull:all', 'bull:pi', 'bull:pl'] },
  ];
  const LAYERS = [
    { id: '', n: '끄기' }, { id: 'pw', n: '⚡ 전력' }, { id: 'wt', n: '💧 상하수도' }, { id: 'traffic', n: '🚗 교통' }, { id: 'lv', n: '💎 땅값' },
    { id: 'air', n: '🏭 대기 오염' }, { id: 'nz', n: '🔊 소음' }, { id: 'gnd', n: '🟤 땅 오염' }, { id: 'wpol', n: '🌊 물 오염' }, { id: 'hap', n: '😊 행복' },
    { id: 'fire', n: '🚒 소방' }, { id: 'pol', n: '🚓 치안' }, { id: 'hlth', n: '🏥 의료' }, { id: 'edu1', n: '🏫 초등' }, { id: 'edu2', n: '🏫 고등' }, { id: 'edu3', n: '🎓 대학' },
    { id: 'park', n: '🌳 공원' }, { id: 'tr', n: '🚌 대중교통' }, { id: 'gar', n: '🗑️ 쓰레기' }, { id: 'dist', n: '🗺️ 지구' },
  ];
  const ZROOF = {
    R: ['#c9694f', '#b5564a', '#d08a5a', '#9c6b52', '#c27a64'], RH: ['#d9d1c2', '#c8c0b0', '#e0d6c4', '#bfb7aa'],
    C: ['#5b8fd0', '#4f7fb8', '#7aa8de', '#6a95c9'], I: ['#c9a14a', '#a88d5a', '#8d8d8d', '#b59b62'], O: ['#9e8ad6', '#7f9fc9', '#a4b6d8', '#8c7fc4'],
  };
  function toolInfo(t) {
    const [k, v] = t.split(':');
    if (k === 'road') { const r = RD[+v]; return { ic: ['', '🛣️', '🛤️', '➡️', '🛣️'][+v], n: r.n, cost: r.cost + '/칸', tier: r.tier, d: r.d }; }
    if (k === 'zone') { if (+v === 0) return { ic: '⬜', n: '구역 지우기', d: '칠한 구역을 지워요.' }; const z = ZN[+v]; return { ic: ['', '🏠', '🏢', '🏪', '🏬', '🏭', '💼'][+v], n: z.s, tier: z.tier, d: z.d, col: z.col }; }
    if (k === 'sv') { const s = SV[SVI[v]]; return { ic: s.ic, n: s.n, cost: won(s.cost), tier: s.tier, d: s.d, sv: SVI[v] }; }
    if (k === 'pl') return { ic: '🔌', n: '송전선', cost: PLINE_COST + '/칸', d: '빈 땅을 건너 전기를 이어요(도로·건물은 저절로 이어져요).' };
    if (k === 'pi') return { ic: '🔵', n: '수도관', cost: PIPE_COST + '/칸', d: '땅속 관. 관에서 4칸 안 건물에 물·하수를 이어 줘요.' };
    if (k === 'mode') return { ic: { line: '📐', curve: '〰️', free: '✍️' }[v], n: { line: '직선', curve: '곡선', free: '자유' }[v], mode: 1 };
    if (k === 'line') return { ic: v === 'bus' ? '🚍' : '🚆', n: v === 'bus' ? '버스 노선' : '지하철 노선', tier: v === 'bus' ? 2 : 4, d: '정류장(역)을 차례로 눌러 노선을 만들어요.' };
    if (k === 'dist') return +v ? { ic: '🖌️', n: DISTN[+v], tier: 2, col: DISTC[+v], d: '지구를 칠해 따로 정책을 걸어요.' } : { ic: '⬜', n: '지구 지우기', tier: 2 };
    if (k === 'bull') return { ic: { all: '🧹', pi: '🔵', pl: '🔌' }[v], n: { all: '건물·도로', pi: '수도관', pl: '송전선' }[v] + ' 철거' };
    return { ic: '?', n: t };
  }

  function mountView(root, api) {
    if (!document.getElementById('cb2-css')) { const st = document.createElement('style'); st.id = 'cb2-css'; st.textContent = CSS; document.head.appendChild(st); }
    const cv = U.canvas(root), ctx = cv.ctx;
    const h = L.h;
    let S = null, me = -1, demo = false, spect = false, C = null, viewC = null, cities = {}, speed = 1, alive = true;
    let tool = 'view', cat = 'view', mode = 'line', layer = '', sheet = null, info = null, lineStops = [], lineType = 'bus';
    const cam = { x: 50, y: 50, z: 12 };
    let cache = null, cctx = null, cacheRow = 0, cacheAll = true, ovCv = null, ovKey = '', ovMo = -1;
    let lastNews = 0, dayAcc = 0, shake = 0, cars = [], tick = 0, lastPub = -1, hostMo = -1, ended = false;
    const dirtyQ = [];
    const fx = () => (L.fx ? L.fx() : 1);
    const dbgSp = () => (L.debug && L.debug.speed) || 1;

    /* ---------- DOM ---------- */
    const hud = h('div', { class: 'cb-hud' });
    const moneyChip = h('button', { class: 'cb-chip', 'data-key': 'KeyM', onclick: () => openBudget() });
    const popChip = h('button', { class: 'cb-chip', onclick: () => openStats() });
    const dateChip = h('span', { style: { color: 'var(--ink)', fontFamily: 'var(--f-mono)', fontWeight: '600' } });
    const spBtns = [0, 1, 2, 3].map((v) => h('button', { class: 'cb-sp', 'data-action': ['pause', 'sp1', 'sp2', 'sp3'][v], text: ['⏸', '▶', '▶▶', '▶▶▶'][v], 'aria-label': ['멈춤', '보통', '빠르게', '아주 빠르게'][v], onclick: () => setSpeed(v) }));
    const spWrap = h('div', { class: 'cb-row' }, ...spBtns);
    const row1 = h('div', { class: 'cb-row' }, moneyChip, popChip, h('div', { class: 'cb-fill' }), spWrap);
    const rci = h('div', { class: 'cb-rci', title: '수요(주거·상업·산업·사무)' });
    const subInfo = h('div', { class: 'cb-sub' });
    hud.append(row1, subInfo);
    const side = h('div', { class: 'cb-side' });
    const sideBtns = {};
    const SIDE = [['layer', '🗺', '정보 화면', () => openLayers()], ['pol', '📜', '정책', () => openPolicies()], ['lines', '🚌', '대중교통 노선', () => openLines()], ['news', '🔔', '알림', () => openNews()], ['aide', '📋', '시장 비서', () => openAide()], ['mile', '🏆', '이정표', () => openMilestones()], ['menu', '☰', '메뉴', () => openMenu()], ['zin', '＋', '확대', () => zoomBy(1.3)], ['zout', '－', '축소', () => zoomBy(1 / 1.3)]];
    for (const [id, ic, n, fn] of SIDE) { const b = h('button', { 'aria-label': n, title: n, text: ic, onclick: () => { api.sfx('click'); fn(); } }); if (id === 'layer') b.dataset.action = 'layer'; if (id === 'zin') b.dataset.action = 'zin'; if (id === 'zout') b.dataset.action = 'zout'; sideBtns[id] = b; side.append(b); }
    const newsBadge = h('span', { class: 'cb-badge', style: { display: 'none' } }); sideBtns.news.append(newsBadge);
    const bar = h('div', { class: 'cb-bar' });
    const subs = h('div', { class: 'cb-subs' });
    const tools = h('div', { class: 'cb-tools' });
    bar.append(subs, tools);
    const legend = h('div', { class: 'cb-legend', style: { display: 'none' } });
    const hint = h('div', { class: 'cb-hint' });
    root.append(hud, side, bar, legend, hint);
    const catBtns = {};
    for (const c of CATS) {
      const b = h('button', { class: 'cb-t', 'aria-label': c.n, onclick: () => pickCat(c.id) }, h('b', { text: c.ic }), h('small', { text: c.n }));
      if (c.id === 'view') b.dataset.action = 'view'; if (c.id === 'road') b.dataset.action = 'road'; if (c.id === 'zone') b.dataset.action = 'zone'; if (c.id === 'bull') b.dataset.action = 'bull';
      catBtns[c.id] = b; tools.append(b);
    }
    function layout() {
      const top = hud.offsetHeight || 76, bot = bar.offsetHeight || 64;
      side.style.top = (top + 6) + 'px';
      legend.style.bottom = (bot + 6) + 'px';
      hint.style.top = (top + 6) + 'px';
      if (info) info.style.bottom = (bot + 6) + 'px';
      // 아주 낮은 화면에서는 옆 버튼 일부를 숨김
      const avail = cv.h - top - bot - 12; const n = Math.max(4, Math.floor(avail / 49));
      SIDE.forEach(([id], k) => { sideBtns[id].style.display = k < n || id === 'zin' || id === 'zout' ? '' : 'none'; });
      if (n < SIDE.length) { let hidden = SIDE.length - n; for (const id of ['mile', 'lines', 'pol', 'aide']) { if (hidden <= 0) break; sideBtns[id].style.display = 'none'; hidden--; } }
    }
    function myCityEditable() { return C && viewC === C && !ended; }

    /* ---------- 도구 ---------- */
    function pickCat(id) {
      if (!myCityEditable() && id !== 'view') { api.toast(demo ? 'AI 시장이 짓는 중이에요' : '내 도시에서만 지을 수 있어요'); return; }
      cat = id; const c = CATS.find((q) => q.id === id);
      if (!c.tools) setTool('view');
      else { const first = c.tools.find((t) => !t.startsWith('mode') && !locked(t)) || c.tools[0]; setTool(first); }
      api.sfx('click'); refreshTools(); layout();
    }
    function locked(t) { const i = toolInfo(t); return C && i.tier != null && C.tier < i.tier; }
    function setTool(t) {
      if (t.startsWith('mode:')) { mode = t.split(':')[1]; refreshTools(); return; }
      if (locked(t)) { const i = toolInfo(t); api.toast('🔒 ' + TIERS[i.tier].n + '(인구 ' + num(TIERS[i.tier].p) + '명)부터'); return; }
      tool = t; drag = null; ghost = null; closeInfo();
      if (t.startsWith('line:')) { lineType = t.split(':')[1]; lineStops = []; }
      if (t === 'pi' || t === 'bull:pi' || t.startsWith('sv:') && (SV[SVI[t.slice(3)]].wt || SV[SVI[t.slice(3)]].sw)) setLayer('wt', true);
      else if (t === 'pl' || t === 'bull:pl' || (t.startsWith('sv:') && SV[SVI[t.slice(3)]].pw)) setLayer('pw', true);
      else if (t.startsWith('dist')) setLayer('dist', true);
      else if (t.startsWith('sv:') && SV[SVI[t.slice(3)]].r && C.cov[SV[SVI[t.slice(3)]].g]) setLayer(SV[SVI[t.slice(3)]].g, true);
      else if (t.startsWith('line') || t === 'sv:stop' || t === 'sv:metro') setLayer('tr', true);
      else if (autoLayer) setLayer('', true);
      refreshTools(); updHint();
    }
    let autoLayer = false;
    function refreshTools() {
      for (const c of CATS) catBtns[c.id].classList.toggle('on', c.id === cat);
      subs.innerHTML = '';
      const c = CATS.find((q) => q.id === cat);
      if (!c || !c.tools) { subs.style.display = 'none'; layout(); return; }
      subs.style.display = '';
      for (const t of c.tools) {
        const i = toolInfo(t), lk = locked(t);
        const on = i.mode ? t === 'mode:' + mode : t === tool;
        if (i.mode && !tool.startsWith('road') && !tool.startsWith('pi') && !tool.startsWith('pl')) continue;
        const b = h('button', { class: 'cb-s' + (on ? ' on' : '') + (lk ? ' lock' : '') + (i.mode ? ' mode' : ''), title: i.d || i.n, onclick: () => { api.sfx('click'); setTool(t); } },
          h('b', { text: lk ? '🔒' : i.ic, style: i.col ? { color: i.col } : {} }), h('span', {}, i.n, i.cost ? h('em', { text: i.cost }) : lk ? h('em', { text: TIERS[i.tier].n }) : null));
        subs.append(b);
      }
      layout();
    }
    function updHint() {
      let t = '';
      if (!myCityEditable()) t = demo ? 'AI 시장 시연 중 — 지도를 끌어 구경해요' : spect ? '👀 관전 중 — 도시는 한 폰에 하나씩이라 같은 지형만 보여요(🏁 메뉴에서 순위)' : viewC !== C ? '👀 상대 도시 구경 중' : '';
      else if (tool.startsWith('road')) t = (mode === 'free' ? '손가락이 지나간 칸에 길을 깔아요' : mode === 'curve' ? '끌면 둥글게 굽은 길' : '끌어서 곧은 길(꺾이면 ㄱ자)') + (tool === 'road:3' ? ' · 끈 방향으로 일방통행' : '');
      else if (tool.startsWith('zone')) t = '네모로 끌어 칠해요(도로에서 3칸 안쪽)';
      else if (tool.startsWith('sv:')) t = '끌어서 자리를 맞추고 손을 떼면 지어요';
      else if (tool === 'pi') t = '수도관: 시설(취수장·배출구)과 동네를 이어요';
      else if (tool === 'pl') t = '송전선: 떨어진 발전소와 동네를 이어요';
      else if (tool.startsWith('line')) t = (lineType === 'bus' ? '정류장' : '역') + '을 차례로 눌러요 · ' + lineStops.length + '곳 → 「완료」';
      else if (tool.startsWith('dist')) t = '네모로 끌어 지구를 칠해요 → 📜 정책에서 지구마다 정책';
      else if (tool.startsWith('bull')) t = '네모로 끌어 지워요';
      hint.textContent = t; hint.style.display = t ? '' : 'none';
      if (tool.startsWith('line') && myCityEditable()) {
        hint.style.pointerEvents = 'auto';
        hint.append(' ', h('button', { class: 'btn sm primary', text: '완료', style: { pointerEvents: 'auto', minHeight: '36px' }, onclick: () => finishLine() }), ' ', h('button', { class: 'btn sm', text: '취소', style: { pointerEvents: 'auto', minHeight: '36px' }, onclick: () => { lineStops = []; updHint(); } }));
      } else hint.style.pointerEvents = 'none';
    }
    function finishLine() {
      if (lineStops.length < 2) { api.toast('2곳 이상 골라요'); return; }
      const r = lineAdd(C, lineType, lineStops); if (!r.ok) { api.toast(r.why); return; }
      computeCov(C); api.toast((lineType === 'bus' ? '🚍 버스' : '🚆 지하철') + ' 노선을 만들었어요'); api.sfx('chip'); lineStops = []; updHint();
    }
    function setSpeed(v) {
      if (api.online && !api.isHost) { api.toast('빠르기는 방장이 정해요'); return; }
      speed = v; if (api.online && S && S.sp !== v) api.setState(Object.assign({}, S, { sp: v }));
      spBtns.forEach((b, k) => b.classList.toggle('on', k === v)); api.sfx('click');
    }
    function setLayer(id, auto) { layer = id; autoLayer = !!auto && !!id; ovKey = ''; sideBtns.layer.classList.toggle('on', !!id); drawLegend(); }
    function drawLegend() {
      if (!layer) { legend.style.display = 'none'; return; }
      const L0 = LAYERS.find((q) => q.id === layer); const grad = { lv: 'linear-gradient(90deg,#3b2b52,#2f9e7a,#f2d16b)', air: 'linear-gradient(90deg,#2b4f2b,#c9a03b,#a0402e)', nz: 'linear-gradient(90deg,#24324a,#c97fd6)', gnd: 'linear-gradient(90deg,#3a4a2a,#8a5a2e)', wpol: 'linear-gradient(90deg,#2f6d8f,#6b5a2a)', hap: 'linear-gradient(90deg,#c0453a,#e0b84a,#53b06a)', traffic: 'linear-gradient(90deg,#3ec46d,#f2c14e,#e5483b)', gar: 'linear-gradient(90deg,#3a4a2a,#c08a3a)' }[layer] || 'linear-gradient(90deg,rgba(80,200,255,.2),rgba(80,200,255,.9))';
      legend.innerHTML = ''; legend.append(h('span', { text: L0 ? L0.n : '' }), h('i', { style: { background: grad } }), h('span', { text: { pw: '초록=들어옴 빨강=안 들어옴', wt: '파랑=관 · 빨강=물 없음', traffic: '막힘', hap: '행복', lv: '땅값' }[layer] || '' }));
      legend.style.display = '';
    }
    function zoomBy(f, sx, sy) {
      const W = cv.w, H = cv.h; if (sx == null) { sx = W / 2; sy = H / 2; }
      const wx = cam.x + (sx - W / 2) / cam.z, wy = cam.y + (sy - H / 2) / cam.z;
      cam.z = clamp(cam.z * f, minZ(), 44); cam.x = wx - (sx - W / 2) / cam.z; cam.y = wy - (sy - H / 2) / cam.z; clampCam();
    }
    const minZ = () => Math.max(1.5, Math.min(cv.w, cv.h - 120) / ((viewC && viewC.N) || 100) * 0.9);
    function clampCam() { const N = (viewC && viewC.N) || 100; cam.x = clamp(cam.x, 0, N); cam.y = clamp(cam.y, 0, N); }
    const toWorld = (sx, sy) => ({ x: cam.x + (sx - cv.w / 2) / cam.z, y: cam.y + (sy - cv.h / 2) / cam.z });
    const toScr = (wx, wy) => ({ x: (wx - cam.x) * cam.z + cv.w / 2, y: (wy - cam.y) * cam.z + cv.h / 2 });

    /* ---------- 입력 ---------- */
    const ptrs = new Map(); let drag = null, ghost = null, pinch = null, panning = null, hoverCell = -1;
    function cellAt(sx, sy) { const w = toWorld(sx, sy), N = viewC.N; const x = Math.floor(w.x), y = Math.floor(w.y); return x >= 0 && y >= 0 && x < N && y < N ? { x, y, i: y * N + x } : null; }
    function onDown(ev) {
      if (!viewC) return; cv.cv.setPointerCapture && cv.cv.setPointerCapture(ev.pointerId);
      const p = cv.local(ev); ptrs.set(ev.pointerId, p);
      if (ptrs.size === 2) { drag = null; ghost = null; panning = null; const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 }; return; }
      if (ptrs.size > 2) return;
      const right = ev.button === 2 || ev.button === 1;
      if (right || tool === 'view' || !myCityEditable()) { panning = { x: p.x, y: p.y, cx: cam.x, cy: cam.y, moved: 0, right, t: now() }; return; }
      const c = cellAt(p.x, p.y); if (!c) return;
      drag = { x0: c.x, y0: c.y, x1: c.x, y1: c.y, free: [c.i], moved: 0, sx: p.x, sy: p.y };
      updGhost();
    }
    function onMove(ev) {
      const p = cv.local(ev);
      if (ptrs.has(ev.pointerId)) ptrs.set(ev.pointerId, p);
      if (pinch && ptrs.size >= 2) { const [a, b] = [...ptrs.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y), cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2; cam.x -= (cx - pinch.cx) / cam.z; cam.y -= (cy - pinch.cy) / cam.z; zoomBy(d / Math.max(1, pinch.d), cx, cy); pinch.d = d; pinch.cx = cx; pinch.cy = cy; return; }
      if (panning) { const dx = p.x - panning.x, dy = p.y - panning.y; if (Math.abs(dx) + Math.abs(dy) > 6) panning.moved = 1; cam.x = panning.cx - dx / cam.z; cam.y = panning.cy - dy / cam.z; clampCam(); return; }
      if (drag) {
        const c = cellAt(p.x, p.y); if (!c) return;
        if (c.x !== drag.x1 || c.y !== drag.y1) { drag.moved = 1;
          if (mode === 'free' && (tool.startsWith('road') || tool === 'pi' || tool === 'pl')) { // 손가락 길 따라(빈틈은 이어 붙임)
            const last = drag.free[drag.free.length - 1], N = viewC.N; let lx = last % N, ly = (last / N) | 0;
            while (lx !== c.x || ly !== c.y) { if (lx !== c.x) lx += Math.sign(c.x - lx); else ly += Math.sign(c.y - ly); const j = ly * N + lx; if (drag.free.indexOf(j) < 0) drag.free.push(j); }
          }
          drag.x1 = c.x; drag.y1 = c.y; updGhost(); }
        return;
      }
      if (ev.pointerType === 'mouse') { const c = cellAt(p.x, p.y); hoverCell = c ? c.i : -1; if (tool.startsWith('sv:') && c && myCityEditable()) { drag = null; ghostSv(c.x, c.y); } }
    }
    function onUp(ev) {
      const p = cv.local(ev); ptrs.delete(ev.pointerId);
      if (pinch) { if (ptrs.size < 2) pinch = null; return; }
      if (panning) { const pn = panning; panning = null; if (!pn.moved && now() - pn.t < 600) { if (pn.right) { if (tool !== 'view') { pickCat('view'); } else closeInfo(); } else tapCell(p.x, p.y); } return; }
      if (!drag) return;
      const d = drag; drag = null; commit(d); ghost = null;
    }
    function onWheel(ev) { ev.preventDefault(); const p = cv.local(ev); zoomBy(ev.deltaY < 0 ? 1.15 : 1 / 1.15, p.x, p.y); }
    cv.cv.addEventListener('pointerdown', onDown); window.addEventListener('pointermove', onMove); window.addEventListener('pointerup', onUp); window.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('contextmenu', (e) => e.preventDefault());
    function strokeCells(d) {
      const C0 = viewC;
      if (tool.startsWith('road') || tool === 'pi' || tool === 'pl') {
        if (mode === 'free') { const dirs = []; fixDirs(C0, d.free, dirs); return { cells: d.free, dirs }; }
        return lineCells(C0, d.x0, d.y0, d.x1, d.y1, mode);
      }
      return { cells: rectCells(C0, d.x0, d.y0, d.x1, d.y1) };
    }
    function ghostSv(x, y) { const t = SVI[tool.slice(3)], s = SV[t]; const gx = x - Math.floor((s.sz - 1) / 2), gy = y - Math.floor((s.sz - 1) / 2); const P = svPlan(C, t, gx, gy); ghost = { sv: t, x: gx, y: gy, ok: P.ok, why: P.why, cost: P.ok ? P.cost : s.cost }; }
    function updGhost() {
      if (!drag) return;
      if (tool.startsWith('sv:')) { ghostSv(drag.x1, drag.y1); return; }
      if (tool.startsWith('line')) { ghost = null; return; }
      const r = strokeCells(drag); let st = [], cost = 0, n = 0;
      if (tool.startsWith('road')) { const P = roadPlan(C, r.cells, +tool.split(':')[1]); st = P.res; cost = P.cost; }
      else if (tool.startsWith('zone')) { const P = zonePlan(C, r.cells, +tool.split(':')[1]); st = P.res; }
      else if (tool === 'pi' || tool === 'pl') { const arr = C[tool]; st = r.cells.map((i) => (arr[i] ? 1 : (tool === 'pl' && C.ter[i] === 2) || (tool === 'pl' && (C.ob[i] || (C.zn[i] && C.bl[i]))) ? 0 : 2)); st.forEach((v, k) => { if (v === 2) { n++; cost += (tool === 'pi' ? PIPE_COST : PLINE_COST) * (C.ter[r.cells[k]] === 1 ? 2 : 1); } }); }
      else st = r.cells.map(() => 2);
      ghost = { cells: r.cells, dirs: r.dirs, st, cost, n };
    }
    function commit(d) {
      if (!myCityEditable()) return;
      let r = null;
      if (tool.startsWith('line')) { tapStop(d.x1, d.y1); return; }
      if (tool.startsWith('sv:')) { ghostSv(d.x1, d.y1); const g = ghost; if (!g.ok) { api.toast(g.why); api.buzz(20); return; } r = doSv(C, g.sv, g.x, g.y); if (r.ok) { markDirty(fpCells(C, g.x, g.y, SV[g.sv].sz)); api.sfx('pop'); api.buzz(14); floatTxt('−' + won(r.cost), g.x + SV[g.sv].sz / 2, g.y); if (SV[g.sv].stop && tool !== 'view') lineHelp(); } else api.toast(r.why); return; }
      const sc = strokeCells(d);
      if (tool.startsWith('road')) r = doRoad(C, sc.cells, +tool.split(':')[1], sc.dirs);
      else if (tool.startsWith('zone')) r = doZone(C, sc.cells, +tool.split(':')[1]);
      else if (tool === 'pi' || tool === 'pl') r = doPipe(C, sc.cells, tool);
      else if (tool.startsWith('bull')) { const lay = tool.split(':')[1]; r = doBull(C, sc.cells, lay === 'all' ? '' : lay); }
      else if (tool.startsWith('dist')) { r = doDist(C, sc.cells, +tool.split(':')[1]); ovKey = ''; }
      if (!r) return;
      if (!r.ok) { api.toast(r.why); api.buzz(20); return; }
      markDirty(sc.cells); ovKey = '';
      api.sfx(tool.startsWith('bull') ? 'thud' : tool.startsWith('road') ? 'tick' : 'click'); api.buzz(10);
      if (r.cost) { const w = sc.cells[sc.cells.length - 1]; floatTxt((r.cost > 0 ? '−' : '+') + won(Math.abs(r.cost)), w % C.N + 0.5, (w / C.N) | 0); }
      if (tool.startsWith('road') && !C._roadTip) { C._roadTip = 1; }
    }
    let lineHelped = false;
    function lineHelp() { if (lineHelped) return; lineHelped = true; api.toast('정류장 2곳 이상 → 「노선」 도구로 이어요'); }
    function tapStop(x, y) {
      const i = y * C.N + x, id = C.ob[i] - 1, b = id >= 0 ? C.B[id] : null;
      if (!b || !SV[b.t].stop || (lineType === 'bus') !== (SV[b.t].stop === 'bus')) { api.toast(lineType === 'bus' ? '버스 정류장을 눌러요' : '지하철역을 눌러요'); return; }
      if (lineStops[lineStops.length - 1] === id) return; lineStops.push(id); api.sfx('tick'); updHint();
    }
    function tapCell(sx, sy) {
      const c = cellAt(sx, sy); if (!c) { closeInfo(); return; }
      openInfo(c.i);
    }
    /* 키보드(조작 설정과 연결) */
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'pause') setSpeed(speed ? 0 : 1); else if (id === 'sp1') setSpeed(1); else if (id === 'sp2') setSpeed(2); else if (id === 'sp3') setSpeed(3);
      else if (id === 'zin') zoomBy(1.3); else if (id === 'zout') zoomBy(1 / 1.3);
      else if (id === 'layer') { const k = LAYERS.findIndex((q) => q.id === layer); setLayer(LAYERS[(k + 1) % LAYERS.length].id); api.toast('정보 화면: ' + (LAYERS.find((q) => q.id === layer) || {}).n); }
      else if (id === 'view' || id === 'road' || id === 'zone' || id === 'bull') pickCat(id);
      else if (id === 'next') { const c = CATS.find((q) => q.id === cat); if (c && c.tools) { const ts = c.tools.filter((t) => !t.startsWith('mode')); const k = ts.indexOf(tool); setTool(ts[(k + 1) % ts.length]); } }
      else if (id === 'budget') openBudget();
    }) : null;
    function onKey(e) { if (e.code === 'Escape' && (sheet || info || tool !== 'view')) { e.preventDefault(); e.stopPropagation(); if (sheet) closeSheet(); else if (tool !== 'view') pickCat('view'); else closeInfo(); } }
    window.addEventListener('keydown', onKey, true);

    /* ---------- 정보 카드 ---------- */
    function closeInfo() { if (info) { info.remove(); info = null; } selCell = -1; }
    let selCell = -1;
    function openInfo(i) {
      closeInfo(); const C0 = viewC; selCell = i;
      const N = C0.N, x = i % N, y = (i / N) | 0;
      const kv = (a) => h('div', { class: 'kv' }, ...a.filter(Boolean).map(([k, v]) => h('span', {}, k + ' ', h('em', { text: v }))));
      let title = '', icon = '', body = [], btns = [];
      const env = [['땅값', C0.lv[i]], ['공기', Math.round(C0.air[i])], ['소음', Math.round(C0.nz[i])]];
      if (C0.ob[i]) {
        const id = C0.ob[i] - 1, b = C0.B[id], s = SV[b.t]; icon = s.ic; title = s.n; selCell = b.y * N + b.x;
        const why = b.ra < 0 ? '도로에 닿지 않았어요' : (!s.np && !C0.pw[b.y * N + b.x]) ? '⚡ 전기가 안 들어와요' : (s.store && b.fl >= s.store) ? '가득 찼어요' : ((s.wt || s.sw) && (b.wc == null || b.wc < 0)) ? '🔵 수도관에 닿지 않았어요' : '';
        const lines = [['상태', why ? '멈춤' : '작동 중'], ['유지비', won(s.up) + '/달']];
        if (s.pw) lines.push(['발전', Math.round(plantOut(C0, b)) + ' MW']);
        if (s.wt) lines.push(['물', s.wt + ' 톤/달' + (b.dirty ? ' (더러움!)' : '')]); if (s.sw) lines.push(['하수', s.sw + ' 톤/달']);
        if (s.r) lines.push(['범위', Math.round(svRadius(C0, b)) + '칸']);
        if (s.store) lines.push(['채움', Math.round((b.fl || 0) / s.store * 100) + '%']); if (s.proc) lines.push(['처리', num(s.proc) + '/달']);
        body = [kv(lines), why ? h('div', { class: 'need bad', text: '⚠ ' + why }) : null, h('div', { class: 'muted', style: { marginTop: '3px', fontSize: '11.5px' }, text: s.d })];
        if (myCityEditable()) btns.push(h('button', { class: 'btn sm', text: '철거(+' + won(s.cost * 0.25) + ')', onclick: () => { doBull(C, [i], ''); markDirty(fpCells(C, b.x, b.y, s.sz)); api.sfx('thud'); closeInfo(); } }));
      } else if (C0.rd[i]) {
        const r = RD[C0.rd[i]]; icon = '🛣️'; title = r.n + (C0.ter[i] === 1 ? ' (다리)' : '');
        body = [kv([['통행', num(C0.vol[i]) + '/달'], ['혼잡', C0.cong[i] + '%'], ['유지비', r.up.toFixed(2) + '/달']]), C0.cong[i] > 100 ? h('div', { class: 'need bad', text: '막혀요 → 4차선·일방통행·우회로·대중교통' }) : null];
      } else if (C0.zn[i]) {
        const z = ZN[C0.zn[i]], b = C0.bl[i]; icon = ['', '🏠', '🏢', '🏪', '🏬', '🏭', '💼'][C0.zn[i]]; title = z.n + (b ? ' · ' + b + '단계' : ' · 빈 땅');
        if (C0.ab[i] & 128) title += ' (버려짐)';
        const cap = capOf(C0, i);
        const pbs = PBN.filter((q, k) => C0.pb[i] & (1 << k)).map((q) => q[1] + ' ' + q[2]);
        const lines = [[z.k === 'R' ? '주민' : '일자리', cap + '명']].concat(env); if (z.k === 'R') lines.push(['행복', C0.hap[i]]);
        body = [kv(lines)];
        if (C0.burn[i]) body.push(h('div', { class: 'need bad', text: '🔥 불이 났어요!' }));
        if (pbs.length && b) body.push(h('div', { class: 'need bad', text: '⚠ ' + pbs.join(' · ') }));
        if (b) { const nx = nextNeed(C0, i); if (nx) body.push(h('div', { class: 'need', text: '⬆ ' + nx })); }
        else if (C0.acc[i] < 0) body.push(h('div', { class: 'need bad', text: '도로에서 너무 멀어요' }));
        else body.push(h('div', { class: 'need', text: C0.st.dem[z.k] > 0 ? '수요가 있으면 곧 건물이 들어와요' : '이 구역 수요가 없어요(위 막대)' }));
      } else {
        icon = C0.ter[i] === 1 ? '🌊' : C0.ter[i] === 2 ? '⛰️' : C0.fr[i] ? '🌲' : '🌱'; title = C0.ter[i] === 1 ? '물' : C0.ter[i] === 2 ? '바위산' : C0.fr[i] ? '숲' : '빈 땅';
        body = [kv(C0.ter[i] === 1 ? [['물 오염', Math.round(C0.wpol[i])]] : env.concat([['높이', Math.round(C0.ht[i] / 2.55) + 'm']]))];
      }
      info = h('div', { class: 'cb-info' }, h('div', { style: { fontSize: '24px' }, text: icon }), h('div', { class: 'bd' }, h('b', { text: title }), ...body.filter(Boolean), btns.length ? h('div', { style: { marginTop: '6px', display: 'flex', gap: '6px' } }, ...btns) : null),
        h('button', { class: 'cb-x', text: '✕', 'aria-label': '닫기', onclick: () => closeInfo() }));
      root.append(info); layout(); void x; void y;
    }
    function nextNeed(C0, i) {
      const z = C0.zn[i], k = ZN[z].k, b = C0.bl[i], lv = C0.lv[i], c = C0.cov, E = C0.st.edu;
      if (b >= 5) return ''; if (b >= TIERS[C0.tier].cap) return '다음 이정표에서 더 높아질 수 있어요'; if (hasPol(C0, i, 'lowrise') && b >= 3) return '고층 제한 정책';
      if (k === 'R') { if (b === 1) return lv < 22 ? '땅값 22 필요(지금 ' + lv + ')' : ''; if (b === 2) return lv < 36 ? '땅값 36 필요(지금 ' + lv + ')' : !c.edu1[i] ? '초등학교 범위 필요' : ''; if (b === 3) return lv < 50 ? '땅값 50 필요(지금 ' + lv + ')' : !c.edu2[i] ? '고등학교 범위 필요' : !c.hlth[i] ? '보건소·병원 범위 필요' : ''; return lv < 64 ? '땅값 64 필요(지금 ' + lv + ')' : !c.edu3[i] ? '대학교 범위 필요' : ''; }
      if (k === 'C') { if (b === 1) return lv < 22 ? '땅값 22 필요(지금 ' + lv + ')' : ''; if (b === 2) return lv < 36 ? '땅값 36 필요' : !c.pol[i] ? '파출소 범위 필요' : ''; if (b === 3) return lv < 50 ? '땅값 50 필요' : E[0] <= 0.5 ? '초등 교육 주민 50% 필요' : ''; return lv < 64 ? '땅값 64 필요' : '고등 교육 주민 45% 필요'; }
      if (k === 'I') { if (b === 1) return !c.fire[i] ? '소방서 범위 필요' : ''; if (b === 2) return '초등 교육 주민 40% 필요'; if (b === 3) return '고등 교육 주민 35% 필요'; return '대학 교육 주민 20% 필요'; }
      return b === 1 ? '땅값 30 · 고등 교육 25% 필요' : b === 2 ? '땅값 42 · 고등 교육 40% 필요' : '땅값 55+ · 대학 교육 필요';
    }

    /* ---------- 시트(예산·정책·노선…) ---------- */
    function closeSheet() { if (sheet) { sheet.remove(); sheet = null; } }
    function openSheet(title, build) {
      closeSheet(); const body = h('div', { class: 'cb-sheet' });
      const ov = h('div', { class: 'cb-ov', onclick: (e) => { if (e.target === ov) closeSheet(); } }, body);
      const re = () => { body.innerHTML = ''; body.append(h('h3', {}, h('span', { text: title }), h('button', { class: 'cb-x', text: '✕', 'aria-label': '닫기', 'data-key': 'Escape', onclick: () => closeSheet() }))); build(body, re); };
      re(); root.append(ov); sheet = ov; return re;
    }
    const pm = (val, dec, inc) => h('div', { class: 'cb-pm' }, h('button', { text: '−', onclick: dec }), h('b', { text: val }), h('button', { text: '＋', onclick: inc }));
    function openBudget() {
      if (!viewC) return; const C0 = viewC, ro = !myCityEditable();
      openSheet('💰 예산', (b, re) => {
        const f = C0.fin || { inc: {}, exp: {} };
        b.append(h('div', { class: 'cb-line' }, h('span', { text: '지난달 수입 − 지출' }), h('b', { class: 'mono', style: { color: (f.net || 0) >= 0 ? '#8fd16b' : '#ff8e7a' }, text: won(f.net || 0) })));
        b.append(h('h4', { text: '세율(높으면 수요·행복 ↓)' }));
        for (const k of ZK) {
          const nm = { R: '주거', C: '상업', I: '산업', O: '사무' }[k];
          b.append(h('div', { class: 'cb-line' }, h('span', { text: nm + ' · 수입 ' + won(f.inc[k] || 0) }), ro ? h('b', { class: 'mono', text: C0.tax[k] + '%' }) : pm(C0.tax[k] + '%', () => { C0.tax[k] = clamp(C0.tax[k] - 1, 1, 29); re(); }, () => { C0.tax[k] = clamp(C0.tax[k] + 1, 1, 29); re(); })));
        }
        b.append(h('div', { class: 'cb-line' }, h('span', { text: '관광 · 대중교통 요금' }), h('span', { class: 'mono', text: won((f.inc.tour || 0) + (f.inc.fare || 0)) })));
        b.append(h('h4', { text: '서비스 예산(높으면 범위·성능 ↑, 유지비 ↑)' }));
        for (const [k, n] of BUDG) b.append(h('div', { class: 'cb-line' }, h('span', { text: n + ' · ' + won(f.exp[k] || 0) }), ro ? h('b', { class: 'mono', text: C0.bud[k] + '%' }) : pm(C0.bud[k] + '%', () => { C0.bud[k] = clamp(C0.bud[k] - 10, 50, 150); re(); }, () => { C0.bud[k] = clamp(C0.bud[k] + 10, 50, 150); re(); })));
        b.append(h('div', { class: 'cb-line' }, h('span', { text: '🏛️ 랜드마크 · 📜 정책 · 💳 대출 상환' }), h('span', { class: 'mono', text: won((f.exp.lm || 0) + (f.exp.pol2 || 0) + (f.exp.loan || 0)) })));
        b.append(h('h4', { text: '대출' }));
        LOANS.forEach((l, k) => {
          const has = C0.loans.find((q) => q.k === k), lk = C0.tier < l.tier;
          b.append(h('div', { class: 'cb-line' }, h('span', { text: won(l.a) + ' · ' + (l.mo / 12) + '년 · 이자 ' + Math.round(l.r * 100) + '%' + (has ? ' · 남은 ' + has.left + '달, 매달 ' + won(has.pay) : lk ? ' · 🔒 ' + TIERS[l.tier].n : '') }),
            ro ? null : has ? h('button', { class: 'btn sm', text: '갚기', onclick: () => { if (repayLoan(C0, k)) { api.toast('대출을 갚았어요'); api.sfx('chip'); re(); } else api.toast('돈이 모자라요'); } })
              : h('button', { class: 'btn sm' + (lk ? '' : ' primary'), text: '빌리기', onclick: () => { if (takeLoan(C0, k)) { api.toast(won(l.a) + ' 대출'); api.sfx('chip'); re(); } else api.toast(lk ? '🔒 ' + TIERS[l.tier].n + '부터' : '이미 빌렸어요'); } })));
        });
      });
    }
    function openLayers() {
      openSheet('🗺 정보 화면', (b) => {
        const g = h('div', { class: 'cb-grid' });
        for (const L0 of LAYERS) g.append(h('button', { class: L0.id === layer ? 'on' : '', text: L0.n, onclick: () => { setLayer(L0.id); closeSheet(); api.sfx('click'); } }));
        b.append(g, h('div', { class: 'muted', style: { fontSize: '11.5px', marginTop: '8px' }, text: '키보드 O로 차례로 바꿀 수 있어요. 시설을 고르면 그 범위가 저절로 보여요.' }));
      });
    }
    let polD = 0;
    function openPolicies() {
      if (!viewC) return; const C0 = viewC, ro = !myCityEditable();
      openSheet('📜 정책', (b, re) => {
        const tabs = h('div', { class: 'cb-tabs' });
        DISTN.forEach((n, d) => { const cnt = d ? countDist(C0, d) : 0; if (d && !cnt && d !== polD) return; tabs.append(h('button', { class: d === polD ? 'on' : '', text: n + (d ? ' (' + cnt + '칸)' : ''), style: d ? { color: DISTC[d] } : {}, onclick: () => { polD = d; re(); } })); });
        b.append(tabs);
        if (C0.tier < 2) b.append(h('div', { class: 'muted', text: '🔒 「' + TIERS[2].n + '」(인구 ' + num(TIERS[2].p) + '명)부터 정책을 쓸 수 있어요.' }));
        b.append(h('div', { class: 'muted', style: { fontSize: '11.5px', marginBottom: '6px' }, text: polD ? '이 지구에만 걸려요. 지구는 🗺️ 지구 도구로 칠해요.' : '도시 전체에 걸려요. 지구마다 따로 걸려면 🗺️ 지구 도구로 지구를 칠해요.' }));
        POL.forEach((p, k) => {
          const on = (C0.pol[polD] & (1 << k)) !== 0, lk = C0.tier < p.tier;
          b.append(h('div', { class: 'cb-pol' }, h('span', { style: { fontSize: '20px' }, text: lk ? '🔒' : p.ic }), h('div', {}, h('b', { text: p.n }), h('small', { text: p.d + (p.c ? ' · 건물 칸당 ₩' + p.c.toFixed(1) + '/달' : '') + (lk ? ' · ' + TIERS[p.tier].n + '부터' : '') })),
            ro ? h('b', { text: on ? '켬' : '끔' }) : h('button', { class: on ? 'on' : '', text: on ? '켬' : '끔', onclick: () => { if (lk) { api.toast('🔒 ' + TIERS[p.tier].n + '부터'); return; } C0.pol[polD] ^= (1 << k); netsDirty(C0); api.sfx('click'); re(); } })));
        });
      });
    }
    function countDist(C0, d) { let n = 0; for (let i = 0; i < C0.N * C0.N; i++) if (C0.dist[i] === d) n++; return n; }
    function openLines() {
      if (!viewC) return; const C0 = viewC, ro = !myCityEditable();
      openSheet('🚌 대중교통', (b, re) => {
        const s = C0.st; b.append(h('div', { class: 'cb-line' }, h('span', { text: '한 달 이용객(버스·지하철)' }), h('b', { class: 'mono', text: num(s.rid || 0) + '명' })));
        if (s.rail) b.append(h('div', { class: 'cb-line' }, h('span', { text: '🚉 기차 이용객' }), h('b', { class: 'mono', text: num(s.railR || 0) + '명' })));
        if (!C0.lines.length) b.append(h('div', { class: 'muted', style: { margin: '8px 0' }, text: '노선이 없어요. 🚌 대중교통 → 버스 차고지 → 정류장 2곳 이상 → 「버스 노선」으로 정류장을 차례로 눌러요.' }));
        C0.lines.forEach((ln, k) => {
          b.append(h('div', { class: 'cb-pol' }, h('span', { style: { width: '14px', height: '28px', borderRadius: '4px', background: LINEC[ln.c % LINEC.length], display: 'block' } }),
            h('div', {}, h('b', { text: (ln.t === 'bus' ? '🚍 버스 ' : '🚆 지하철 ') + (k + 1) + '호선' }), h('small', { text: ln.s.length + '곳 · 이용 ' + num(ln.rm || 0) + '명/달' + (ln.ok ? '' : ' · ⚠ ' + (ln.why || '멈춤')) })),
            ro ? null : h('button', { text: '🗑', 'aria-label': '노선 없애기', onclick: () => { C0.lines.splice(k, 1); computeCov(C0); api.sfx('thud'); re(); } })));
        });
        if (!ro) b.append(h('div', { style: { display: 'flex', gap: '6px', marginTop: '8px' } },
          h('button', { class: 'btn', text: '🚍 새 버스 노선', onclick: () => { closeSheet(); cat = 'tr'; setTool('line:bus'); } }),
          h('button', { class: 'btn', text: '🚆 새 지하철 노선', onclick: () => { closeSheet(); cat = 'tr'; setTool('line:metro'); } })));
      });
    }
    function openNews() {
      if (!viewC) return; const C0 = viewC; newsSeen = C0.nid; newsBadge.style.display = 'none';
      openSheet('🔔 알림', (b) => {
        const a = C0.alerts || {}; const now0 = [];
        if (a.pw) now0.push('⚡ 전기 부족 — 발전소를 더 지어요'); if (a.wt) now0.push('💧 물 부족 — 취수장·급수탑 + 수도관'); if (a.sw) now0.push('🚽 하수 부족 — 하수 배출구·처리장'); if (a.gar) now0.push('🗑️ 쓰레기 — 매립지·소각장(범위 안)'); if (a.dead) now0.push('⚱️ 추모 공원이 모자라요'); if (a.traffic) now0.push('🚗 교통 체증 — 큰길·대중교통'); if (a.out) now0.push('🛣️ 바깥 고속도로와 도로가 끊겼어요'); if (a.money) now0.push('💸 돈이 바닥 — 세금·대출');
        if (now0.length) { b.append(h('h4', { text: '지금 문제' })); now0.forEach((t) => b.append(h('div', { class: 'cb-news' }, h('span', { text: t })))); }
        b.append(h('h4', { text: '소식' }));
        if (!C0.news.length) b.append(h('div', { class: 'muted', text: '아직 소식이 없어요.' }));
        C0.news.slice().reverse().forEach((n) => b.append(h('div', { class: 'cb-news' }, h('span', { text: (Math.floor(n.mo / 12) + 1) + '년 ' + (n.mo % 12 + 1) + '월 · ' + n.txt }), n.c >= 0 ? h('button', { text: '📍', 'aria-label': '위치 보기', onclick: () => { cam.x = n.c % C0.N + 0.5; cam.y = ((n.c / C0.N) | 0) + 0.5; cam.z = Math.max(cam.z, 18); closeSheet(); openInfo(n.c); } }) : null)));
      });
    }
    let newsSeen = 0;
    function openMilestones() {
      if (!viewC) return; const C0 = viewC;
      openSheet('🏆 이정표', (b) => {
        TIERS.forEach((t, k) => {
          const un = [].concat(ZN.filter((z) => z && z.tier === k).map((z) => z.s), RD.filter((r) => r && r.tier === k).map((r) => r.n), SV.filter((s) => s.tier === k).map((s) => s.ic + s.n), k === 2 ? ['📜 정책·지구'] : [], LOANS.filter((l) => l.tier === k && k).map((l) => '💳 대출 ' + won(l.a)));
          b.append(h('div', { class: 'cb-pol', style: { opacity: k <= C0.tier ? 1 : 0.6 } }, h('span', { style: { fontSize: '20px' }, text: k <= C0.tier ? '✅' : '🔒' }), h('div', {}, h('b', { text: t.n + ' · 인구 ' + num(t.p) + '명' }), h('small', { text: (t.gift ? '지원금 ' + won(t.gift) + ' · ' : '') + '최고 ' + t.cap + '단계 건물' + (un.length ? ' · ' + un.join(', ') : '') }))));
        });
      });
    }
    function openStats() {
      if (!viewC) return; const C0 = viewC;
      openSheet('📊 도시 통계', (b) => {
        const s = C0.st, J = s.jobs;
        const g = h('canvas', { style: { width: '100%', height: '120px', display: 'block', background: 'var(--surface-2)', borderRadius: '10px' } }); b.append(g);
        requestAnimationFrame(() => { const r = g.getBoundingClientRect(), d = Math.min(2, window.devicePixelRatio || 1); g.width = r.width * d; g.height = r.height * d; const x = g.getContext('2d'); x.scale(d, d); const H0 = C0.hist; if (H0.length < 2) { x.fillStyle = '#ab9fb8'; x.font = '12px ' + FONT; x.fillText('한 달 뒤부터 그래프가 그려져요', 10, 20); return; } const mx = Math.max(1, ...H0.map((q) => q[0])); x.strokeStyle = '#8fd16b'; x.lineWidth = 2; x.beginPath(); H0.forEach((q, k) => { const px = 6 + k / (H0.length - 1) * (r.width - 12), py = r.height - 8 - q[0] / mx * (r.height - 24); if (k) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke(); const mm = Math.max(1, ...H0.map((q) => Math.abs(q[1]))); x.strokeStyle = '#e3ae45'; x.lineWidth = 1.5; x.beginPath(); H0.forEach((q, k) => { const px = 6 + k / (H0.length - 1) * (r.width - 12), py = r.height / 2 - q[1] / mm * (r.height / 2 - 10); if (k) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke(); x.font = '11px ' + FONT; x.fillStyle = '#8fd16b'; x.fillText('인구 ' + num(mx), 8, 14); x.fillStyle = '#e3ae45'; x.fillText('돈', 8, 28); });
        const rows = [['인구', num(s.pop) + '명'], ['일자리(상업·산업·사무)', num(J.C) + ' · ' + num(J.I) + ' · ' + num(J.O)], ['실업률', Math.round(s.unemp * 100) + '%'], ['행복', s.hap + '%'], ['교육(초·고·대)', s.edu.map((v) => Math.round(v * 100) + '%').join(' · ')], ['범죄', Math.round(s.crime)], ['교통 흐름', s.flow + '%'], ['대중교통 이용', num(s.rid) + '명/달'], ['관광객', num(s.tour) + '명/달'],
          ['전기', Math.round(s.pwU) + ' / ' + Math.round(s.pwP) + ' MW'], ['물', Math.round(s.wtU) + ' / ' + Math.round(s.wtP) + ' 톤'], ['하수', Math.round(s.swU) + ' / ' + Math.round(s.swP) + ' 톤'], ['쓰레기(발생/처리)', num(s.garU) + ' / ' + num(s.garP)], ['버려진 건물', num(s.ab)], ['건물 평균 단계', s.lvAvg.toFixed(1)]];
        for (const [k, v] of rows) b.append(h('div', { class: 'cb-line' }, h('span', { text: k }), h('b', { class: 'mono', text: v })));
      });
    }
    function openScen(intro) {
      const C0 = C || viewC; if (!C0 || !C0.sc) return; const sc = C0.sc, S0 = SCNI[sc.id];
      openSheet(S0.ic + ' ' + S0.n, (b) => {
        b.append(h('div', { style: { fontSize: '13px', lineHeight: '1.5', marginBottom: '6px' }, text: S0.d }));
        b.append(h('h4', { text: '목표(모두 2달 연달아 지키면 성공)' }));
        sc.obj.forEach((o, k) => { const v = scM(C0, o.k), ok = scCmp(v, o.op, o.v); void k; b.append(h('div', { class: 'cb-line' }, h('span', { text: (ok ? '✅ ' : '⬜ ') + o.n + ' ' + (o.op === '>=' ? '≥ ' : '≤ ') + (o.k === 'm' || o.k === 'net' ? won(o.v) : num(o.v)) }), h('b', { class: 'mono', style: { color: ok ? '#8fd16b' : '#ff8e7a' }, text: o.k === 'm' || o.k === 'net' ? won(v) : num(v) }))); });
        b.append(h('h4', { text: '별' }));
        b.append(h('div', { class: 'cb-line' }, h('span', { text: '★★★ ' + sc.s3 + '달 안 · ★★ ' + sc.s2 + '달 안 · ★ ' + sc.lim + '달 안' }), h('b', { class: 'mono', text: '지금 ' + C0.mo + '달째' })));
        b.append(h('h4', { text: '실패' }));
        b.append(h('div', { class: 'muted', style: { fontSize: '12px' }, text: [sc.lim + '달이 지나도 못 이루면', '빚이 ' + won(SC_DEBT) + '를 넘으면(파산)'].concat(sc.fail.map((f) => f.n + (f.after ? '(' + f.after + '달 뒤부터)' : ''))).join(' · ') }));
        if (sc.end) b.append(h('div', { style: { marginTop: '8px', fontWeight: '700' }, text: sc.end === 'win' ? '🎯 성공! ' + '★'.repeat(sc.stars) : '⛔ 실패 — ' + sc.why }));
        if (intro) b.append(h('button', { class: 'btn primary', style: { width: '100%', marginTop: '10px' }, text: '도전 시작!', 'data-key': 'Enter', onclick: () => closeSheet() }));
      });
    }
    let aideMemo = null;
    function openAide() {
      if (!viewC) return; const C0 = viewC;
      const F = aideFacts(C0), rep = aideReport(F), key = C0.mo + ':' + (C0 === C ? 'me' : 'v');
      const useAI = !!(L.ai && L.ai.enabled && L.ai.enabled('citybuild') && C0 === C);
      let line = aideMemo && aideMemo.key === key ? aideMemo.text : null, busy = false;
      const re = openSheet('📋 시장 비서 보고', (b) => {
        b.append(h('div', { class: 'muted', style: { fontSize: '11.5px', marginBottom: '6px' }, text: F.날짜 + ' · ' + F.단계 + ' · 인구 ' + num(F.인구) + '명 · 금고 ' + won(F.금고) }));
        if (line) b.append(h('div', { class: 'cb-news', style: { fontSize: '13px', lineHeight: '1.5' } }, h('span', { text: '✦ ' + line })));
        else if (busy) b.append(h('div', { class: 'muted', style: { fontSize: '12px', marginBottom: '4px' }, text: '✦ 비서가 보고를 다듬는 중…' }));
        rep.forEach((r) => b.append(h('div', { class: 'cb-pol' }, h('span', { style: { fontSize: '20px' }, text: r.ic }), h('div', {}, h('b', { text: r.t }), h('small', { text: '→ ' + r.a })))));
        b.append(h('div', { class: 'muted', style: { fontSize: '11px', marginTop: '6px' }, text: useAI ? '✦ 표시 문장은 AI가 위 자료로 다듬은 말이에요. 숫자는 게임 자료 그대로예요.' : '도시 자료로 만든 보고예요. 설정 「🤖 AI 서술」을 켜면 비서가 자연스러운 말로 정리해 줘요.' }));
      });
      if (!useAI || line) return;
      busy = true; re();
      const sys = '너는 한국어 도시 경영 게임의 「시장 비서」다. 주어진 도시 자료(JSON)와 자료 보고만 근거로, 시장에게 지금 가장 급한 문제와 할 일을 존댓말 2~3문장(150자 안)으로 보고한다. 자료에 없는 숫자·건물·사건은 절대 만들지 않는다. 숫자는 자료에 있는 그대로만 쓴다. 영어·이모지·목록 기호를 쓰지 않는다.';
      const prompt = '도시 자료: ' + JSON.stringify(F) + '\n자료 보고: ' + rep.map((r) => r.t + ' ' + r.a).join(' / ');
      L.ai.ask({ tier: 'fast', system: sys, prompt, maxTokens: 260 }).then((t) => {
        busy = false; const txt = typeof t === 'string' ? t.replace(/\s+/g, ' ').trim().slice(0, 220) : '';
        if (txt && aideCheck(txt, F, rep)) { line = txt; aideMemo = { key, text: txt }; }
        if (sheet && alive) re();
      }).catch(() => { busy = false; if (sheet && alive) re(); });
    }
    function openMenu() {
      openSheet('☰ 메뉴', (b) => {
        const md = S ? S.md : 'sand';
        if (md === 'race') b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '🏁 순위 · 도시 구경', onclick: () => openBoard() }));
        if (md === 'sand' && !demo) b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '💾 지금 저장', onclick: () => { save(true); } }));
        if (myCityEditable()) b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '재해(화재·홍수): ' + (C.dis ? '켬 → 끄기' : '끔 → 켜기'), onclick: () => { C.dis = C.dis ? 0 : 1; api.toast('재해 ' + (C.dis ? '켬' : '끔')); openMenu(); } }));
        if (md === 'scen' && C && C.sc) b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '🎯 시나리오 목표', onclick: () => openScen(false) }));
        b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '📋 시장 비서 보고', onclick: () => openAide() }));
        b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '📊 통계', onclick: () => openStats() }));
        b.append(h('button', { class: 'btn', style: { width: '100%', marginBottom: '6px' }, text: '💡 처음 안내 다시 보기', onclick: () => { closeSheet(); showTip(true); } }));
        if (md !== 'race' && api.isHost) b.append(h('button', { class: 'btn primary', style: { width: '100%' }, text: md === 'sand' ? '🏁 결산(도시는 저장돼요)' : '🏳 그만하고 결산', onclick: () => { closeSheet(); finish(); } }));
      });
    }
    function openBoard() {
      openSheet('🏁 인구 경쟁', (b) => {
        const P = (S && S.P) || []; const order = P.map((p, k) => k).sort((a, b2) => ((P[b2] || [0])[0] - (P[a] || [0])[0]));
        b.append(h('div', { class: 'muted', style: { marginBottom: '6px' }, text: (S.yrs) + '년 안에 인구가 가장 많은 시장이 이겨요 · 지금 ' + (Math.floor((S.mo || 0) / 12) + 1) + '년 ' + ((S.mo || 0) % 12 + 1) + '월' }));
        order.forEach((k, rank) => {
          const p = P[k] || [0, 0, 0, 0], pl = api.players[k] || { name: '?' };
          const c = h('canvas', { width: 20, height: 20 }); drawThumb(c, (S.th || [])[k]);
          const row = h('div', { class: 'cb-sb' }, c, h('div', {}, h('b', { text: (rank + 1) + '위 · ' + pl.name + (k === me ? ' (나)' : '') }), h('div', { class: 'muted', text: '인구 ' + num(p[0]) + ' · ' + TIERS[p[2] | 0].n + ' · 행복 ' + (p[3] | 0) + '%' })));
          if (cities[k] && cities[k] !== viewC) row.append(h('button', { class: 'btn sm', text: '보기', onclick: () => { viewCity(cities[k]); closeSheet(); } }));
          else if (cities[k] === viewC && viewC !== C && C) row.append(h('button', { class: 'btn sm', text: '내 도시', onclick: () => { viewCity(C); closeSheet(); } }));
          b.append(row);
        });
      });
    }
    function drawThumb(c, str) {
      const x = c.getContext('2d'); if (!str) { x.fillStyle = '#333'; x.fillRect(0, 0, 20, 20); return; }
      const S0 = Math.round(Math.sqrt(str.length)); c.width = S0; c.height = S0;
      const col = { '.': '#56703f', f: '#3e5a32', '~': '#2f6d8f', '^': '#7d776a', r: '#55555c', h: '#3d3d48', s: '#d8cdb0', z: '#4c6b45', R: '#7cc46f', C: '#62a6ea', I: '#e6ad45', O: '#a387e6' };
      for (let i = 0; i < str.length; i++) { x.fillStyle = col[str[i]] || '#000'; x.fillRect(i % S0, Math.floor(i / S0), 1, 1); }
    }
    function viewCity(c) { viewC = c; cacheAll = true; cacheRow = 0; ovKey = ''; cars = []; closeInfo(); if (c !== C) pickCat('view'); centerOn(c); updHint(); }
    function centerOn(c) { const N = c.N, e = c.hwEnd; cam.x = (e % N) + 0.5; cam.y = ((e / N) | 0) + 0.5; cam.z = clamp(Math.min(cv.w, cv.h) / 22, minZ(), 30); clampCam(); }

    /* ---------- 처음 안내 ---------- */
    function showTip(force) {
      let seen = 0; try { seen = +localStorage.getItem(TIP) || 0; } catch (e) {}
      if ((seen && !force) || demo || (L.debug && L.debug.noTut && !force)) return;
      try { localStorage.setItem(TIP, '1'); } catch (e) {}
      const box = h('div', { class: 'cb-sheet' },
        h('h3', { text: '🏙️ 도시 건설 시작하기' }),
        ...['① 🛣️ 도로: 고속도로 끝에서 길을 끌어 내요(바깥 도시와 이어져야 사람이 와요).', '② 🏘️ 구역: 길 옆을 네모로 끌어 주거·상업·산업을 칠해요. 위 막대(주·상·산·사)가 높은 걸 칠하면 잘 자라요.', '③ ⚡ 발전기를 길 옆에, 💧 취수장과 하수 배출구를 물가에 짓고 🔵 수도관으로 동네와 이어요(배출구는 취수장 아래쪽 멀리!).', '④ 🗑️ 매립지 · 🚒 소방서 · 🏫 학교로 건물이 커져요. 🗺 정보 화면에서 무엇이 모자란지 볼 수 있어요.'].map((t) => h('p', { style: { margin: '6px 0', fontSize: '13.5px', lineHeight: '1.45' }, text: t })),
        h('button', { class: 'btn primary', style: { width: '100%', marginTop: '8px' }, text: '시작!', 'data-key': 'Enter', onclick: () => tipEl.remove() }));
      const tipEl = h('div', { class: 'cb-tip', onclick: (e) => { if (e.target === tipEl) tipEl.remove(); } }, box); root.append(tipEl);
    }

    /* ---------- 지도 그리기 ---------- */
    function ensureCache() {
      const N = viewC.N; if (!cache || cache.width !== N * CS) { cache = document.createElement('canvas'); cache.width = cache.height = N * CS; cctx = cache.getContext('2d'); cacheAll = true; cacheRow = 0; }
    }
    function markDirty(cells) { for (const i of cells) dirtyQ.push(i); for (const i of cells) { const N = viewC.N, x = i % N, y = (i / N) | 0; for (let d = 0; d < 4; d++) { const xx = x + DX[d], yy = y + DY[d]; if (xx >= 0 && yy >= 0 && xx < N && yy < N) dirtyQ.push(yy * N + xx); } } }
    function terrCol(C0, i) {
      const t = C0.ter[i], hh = C0.ht[i];
      if (t === 1) { const d = Math.min(1, hh / 60); return 'rgb(' + Math.round(34 + d * 18) + ',' + Math.round(88 + d * 26) + ',' + Math.round(122 + d * 18) + ')'; }
      if (t === 2) { const v = 110 + (hh - 220); return 'rgb(' + v + ',' + (v - 6) + ',' + (v - 14) + ')'; }
      const g = hh / 255; const n = (hash(i, 3) / 1000 - 0.5) * 8;
      return 'rgb(' + Math.round(78 + g * 50 + n) + ',' + Math.round(112 + g * 22 + n) + ',' + Math.round(62 + g * 18 + n) + ')';
    }
    function drawCell(C0, x, y) {
      const i = y * C0.N + x, c = cctx, px = x * CS, py = y * CS;
      c.fillStyle = terrCol(C0, i); c.fillRect(px, py, CS, CS);
      if (C0.ter[i] === 1) { if (hash(i, 5) < 120) { c.fillStyle = 'rgba(255,255,255,.12)'; c.fillRect(px + 1, py + 3, 4, 1); } return; }
      const rd = C0.rd[i];
      if (rd) {
        c.fillStyle = rd === 4 ? '#3b3b46' : rd === 2 ? '#4a4a54' : '#55555e'; c.fillRect(px, py, CS, CS);
        if (rd === 2 || rd === 4) { c.fillStyle = rd === 4 ? '#d8d8d8' : '#d9b44a'; const N = C0.N, hz = (x > 0 && C0.rd[i - 1]) || (x < N - 1 && C0.rd[i + 1]); if (hz) c.fillRect(px, py + CS / 2 - 0.5, CS, 1); else c.fillRect(px + CS / 2 - 0.5, py, 1, CS); }
        return;
      }
      if (C0.ob[i]) { const b = C0.B[C0.ob[i] - 1]; const s = SV[b.t]; c.fillStyle = s.col; c.fillRect(px, py, CS, CS); c.fillStyle = 'rgba(0,0,0,.18)'; if (x === b.x + s.sz - 1) c.fillRect(px + CS - 1, py, 1, CS); if (y === b.y + s.sz - 1) c.fillRect(px, py + CS - 1, CS, 1); return; }
      const z = C0.zn[i];
      if (z) {
        const k = ZN[z].k, b = C0.bl[i];
        c.fillStyle = ZN[z].col; c.globalAlpha = 0.35; c.fillRect(px, py, CS, CS); c.globalAlpha = 1;
        if (b) {
          const ab = C0.ab[i] & 128; const pal = ab ? ['#5a524c'] : (z === Z_RH ? ZROOF.RH : ZROOF[k]); c.fillStyle = pal[hash(i, 7) % pal.length];
          const ins = Math.max(0, 3 - Math.ceil(b / 2)); c.fillRect(px + ins, py + ins, CS - ins * 2, CS - ins * 2);
          if (b >= 3 && !ab) { c.fillStyle = 'rgba(255,255,255,.18)'; c.fillRect(px + ins, py + ins, CS - ins * 2, 1); }
        }
        return;
      }
      if (C0.fr[i]) { c.fillStyle = '#3c5a30'; c.beginPath(); c.arc(px + 2.5 + (hash(i, 9) % 3), py + 3, 2.4, 0, 7); c.arc(px + 5.5, py + 5.5 - (hash(i, 8) % 2), 2.2, 0, 7); c.fill(); }
      if (C0.pl[i]) { c.fillStyle = '#c9c2a8'; c.fillRect(px + CS / 2 - 0.5, py, 1, CS); }
    }
    function updateCache(budget) {
      ensureCache(); const C0 = viewC, N = C0.N; const t0 = now();
      while (dirtyQ.length && now() - t0 < budget) { const i = dirtyQ.pop(); drawCell(C0, i % N, (i / N) | 0); }
      if (cacheAll) { while (cacheRow < N && now() - t0 < budget) { for (let x = 0; x < N; x++) drawCell(C0, x, cacheRow); cacheRow++; } if (cacheRow >= N) { cacheAll = false; cacheRow = 0; } }
    }
    function buildOverlay() {
      const C0 = viewC, N = C0.N, key = layer + ':' + C0.mo + ':' + (C0._dn ? 1 : 0);
      if (key === ovKey && ovCv) return; ovKey = key;
      if (!ovCv || ovCv.width !== N) { ovCv = document.createElement('canvas'); ovCv.width = ovCv.height = N; }
      const x = ovCv.getContext('2d'), img = x.createImageData(N, N), d = img.data;
      const ramp = (v, stops) => { v = clamp(v, 0, 1); const n = stops.length - 1, k = Math.min(n - 1, Math.floor(v * n)), t = v * n - k, a = stops[k], b = stops[k + 1]; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; };
      const HEAT = [[59, 43, 82], [47, 158, 122], [242, 209, 107]], BAD = [[43, 79, 43], [201, 160, 59], [160, 64, 46]];
      for (let i = 0; i < N * N; i++) {
        let r = 0, g = 0, b = 0, a = 0; const built = C0.zn[i] && C0.bl[i];
        switch (layer) {
          case 'pw': if (built || C0.ob[i]) { a = 200; if (C0.pw[i]) { r = 80; g = 220; b = 110; } else { r = 235; g = 70; b = 60; } } else if (C0.pl[i] || (C0._pcomp && C0._pcomp[i] >= 0 && C0.rd[i])) { r = 230; g = 220; b = 120; a = 120; } break;
          case 'wt': if (C0.pi[i]) { r = 60; g = 160; b = 255; a = 255; } else if (built) { a = 190; if (C0.wt[i] && C0.sw[i] && !C0.sick[i]) { r = 70; g = 140; b = 220; a = 120; } else { r = 235; g = 70; b = 60; } } else if (C0.wc[i] >= 0) { r = 60; g = 140; b = 230; a = 50; } break;
          case 'lv': if (!C0.ter[i]) { [r, g, b] = ramp(C0.lv[i] / 80, HEAT); a = 170; } break;
          case 'air': if (C0.air[i] > 2) { [r, g, b] = ramp(C0.air[i] / 60, BAD); a = clamp(C0.air[i] * 6, 0, 190); } break;
          case 'nz': if (C0.nz[i] > 4) { r = 201; g = 127; b = 214; a = clamp(C0.nz[i] * 3, 0, 190); } break;
          case 'gnd': if (C0.gnd[i] > 2) { r = 138; g = 90; b = 46; a = clamp(C0.gnd[i] * 6, 0, 200); } break;
          case 'wpol': if (C0.ter[i] === 1 && C0.wpol[i] > 3) { r = 120; g = 100; b = 40; a = clamp(C0.wpol[i] * 2.5, 0, 230); } break;
          case 'hap': if (C0.zn[i] && C0.bl[i] && ZN[C0.zn[i]].k === 'R') { [r, g, b] = ramp(C0.hap[i] / 100, [[192, 69, 58], [224, 184, 74], [83, 176, 106]]); a = 210; } break;
          case 'tr': if (C0.trc[i]) { r = 90; g = 200; b = 255; a = C0.trc[i] * 0.7; } break;
          case 'gar': if (built && C0.gar[i] > 20) { [r, g, b] = ramp(C0.gar[i] / 160, [[58, 74, 42], [192, 138, 58], [220, 60, 50]]); a = 200; } break;
          case 'dist': if (C0.dist[i]) { const c = DISTC[C0.dist[i]]; r = parseInt(c.slice(1, 3), 16); g = parseInt(c.slice(3, 5), 16); b = parseInt(c.slice(5, 7), 16); a = 120; } break;
          default: { const cvv = C0.cov[layer]; if (cvv && cvv[i]) { r = 80; g = 200; b = 255; a = cvv[i] * 0.7; } }
        }
        d[i * 4] = r; d[i * 4 + 1] = g; d[i * 4 + 2] = b; d[i * 4 + 3] = a;
      }
      x.putImageData(img, 0, 0);
    }
    function render() {
      const W = cv.w, H = cv.h, z = cam.z, C0 = viewC; cv.clear();
      ctx.fillStyle = '#121a14'; ctx.fillRect(0, 0, W, H);
      if (!C0) return;
      const N = C0.N, dpr = cv.dpr;
      let ox = W / 2 - cam.x * z, oy = H / 2 - cam.y * z;
      if (shake > 0) { ox += (Math.random() - 0.5) * shake; oy += (Math.random() - 0.5) * shake; }
      ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy);
      ctx.imageSmoothingEnabled = z < CS; ctx.drawImage(cache, 0, 0, N, N);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.imageSmoothingEnabled = true;
      const x0 = Math.max(0, Math.floor((0 - ox) / z)), y0 = Math.max(0, Math.floor((0 - oy) / z) - 1), x1 = Math.min(N - 1, Math.ceil((W - ox) / z)), y1 = Math.min(N - 1, Math.ceil((H - oy) / z) + 1);
      const SX = (x) => ox + x * z, SY = (y) => oy + y * z;
      if (z >= 15) drawDetail(C0, x0, y0, x1, y1, SX, SY, z);
      // 정보 화면
      if (layer) {
        if (layer === 'traffic') { for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) { const i = y * N + x; if (!C0.rd[i]) continue; const c = C0.cong[i]; ctx.fillStyle = c < 50 ? 'rgba(62,196,109,.85)' : c < 90 ? 'rgba(242,193,78,.9)' : 'rgba(229,72,59,.92)'; ctx.fillRect(SX(x), SY(y), z + 0.5, z + 0.5); } }
        else { buildOverlay(); ctx.save(); ctx.setTransform(dpr * z, 0, 0, dpr * z, dpr * ox, dpr * oy); ctx.imageSmoothingEnabled = !(layer === 'pw' || layer === 'wt' || layer === 'dist' || layer === 'hap' || layer === 'gar'); ctx.globalAlpha = 0.85; ctx.drawImage(ovCv, 0, 0, N, N); ctx.restore(); }
        if (layer === 'tr') drawLines(C0, SX, SY, z);
      }
      // 차
      if (z >= 5 && !layer) drawCars(C0, SX, SY, z);
      else if (z >= 5 && layer === 'traffic') drawCars(C0, SX, SY, z);
      // 불
      if (C0.fires.length) { for (const i of C0.fires) { const x = i % N, y = (i / N) | 0; const f = 0.6 + 0.4 * Math.sin(tick * 0.3 + i); ctx.fillStyle = 'rgba(255,' + Math.round(120 * f) + ',40,' + (0.7 * f) + ')'; ctx.beginPath(); ctx.arc(SX(x + 0.5), SY(y + 0.4), Math.max(3, z * 0.55), 0, 7); ctx.fill(); } }
      // 선택한 칸
      if (selCell >= 0 && info) { const sx = selCell % N, sy = (selCell / N) | 0; const b = C0.ob[selCell] ? C0.B[C0.ob[selCell] - 1] : null; const sz = b ? SV[b.t].sz : 1; ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.strokeRect(SX(sx), SY(sy), z * sz, z * sz); if (b && SV[b.t].r) circle(b.x + sz / 2, b.y + sz / 2, svRadius(C0, b), SX, SY, z, 'rgba(227,174,69,.9)'); }
      // 노선 만들기
      if (tool.startsWith('line') && lineStops.length) { ctx.strokeStyle = LINEC[C0.lines.length % LINEC.length]; ctx.lineWidth = 3; ctx.setLineDash([6, 4]); ctx.beginPath(); lineStops.forEach((id, k) => { const b = C0.B[id]; if (!b) return; const px = SX(b.x + 0.5), py = SY(b.y + 0.5); if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }); ctx.stroke(); ctx.setLineDash([]); lineStops.forEach((id, k) => { const b = C0.B[id]; if (!b) return; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(SX(b.x + 0.5), SY(b.y + 0.5), 9, 0, 7); ctx.fill(); ctx.fillStyle = '#000'; ctx.font = '700 11px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(k + 1, SX(b.x + 0.5), SY(b.y + 0.5)); }); }
      drawGhost(C0, SX, SY, z);
      drawFloats(SX, SY);
      // 확대 안 했을 때 시설 아이콘(작게)
      if (z >= 6 && z < 15) { ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; for (const b of C0.B) { if (!b) continue; const s = SV[b.t]; if (b.x + s.sz < x0 || b.x > x1 || b.y + s.sz < y0 || b.y > y1) continue; const fs = Math.min(22, z * s.sz * 0.7); if (fs < 8) continue; ctx.font = fs + 'px ' + FONT; ctx.fillText(s.ic, SX(b.x + s.sz / 2), SY(b.y + s.sz / 2)); } }
      // 문제 아이콘(확대했을 때)
      if (z >= 11) drawProblems(C0, x0, y0, x1, y1, SX, SY, z);
    }
    function circle(cx, cy, r, SX, SY, z, col) { ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.arc(SX(cx), SY(cy), r * z, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
    function drawDetail(C0, x0, y0, x1, y1, SX, SY, z) {
      const N = C0.N;
      // 바닥: 도로·빈 구역·관
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const i = y * N + x, sx = SX(x), sy = SY(y), rd = C0.rd[i];
        if (rd) {
          ctx.fillStyle = rd === 4 ? '#34343e' : rd === 2 ? '#43434c' : '#4e4e57'; ctx.fillRect(sx, sy, z + 0.6, z + 0.6);
          const up = y > 0 && C0.rd[i - N], dn = y < N - 1 && C0.rd[i + N], lf = x > 0 && C0.rd[i - 1], rt = x < N - 1 && C0.rd[i + 1];
          const cnt = (up ? 1 : 0) + (dn ? 1 : 0) + (lf ? 1 : 0) + (rt ? 1 : 0);
          // 보도
          ctx.fillStyle = 'rgba(200,195,180,.28)'; const w = Math.max(1, z * 0.08);
          if (!up) ctx.fillRect(sx, sy, z, w); if (!dn) ctx.fillRect(sx, sy + z - w, z, w); if (!lf) ctx.fillRect(sx, sy, w, z); if (!rt) ctx.fillRect(sx + z - w, sy, w, z);
          if (cnt <= 2) {
            const hz = (lf || rt) && !(up || dn), vt = (up || dn) && !(lf || rt);
            if (rd === 1) { ctx.fillStyle = 'rgba(240,235,210,.55)'; if (hz) for (let k = 0; k < 2; k++) ctx.fillRect(sx + z * (0.1 + k * 0.5), sy + z / 2 - 0.5, z * 0.28, 1); if (vt) for (let k = 0; k < 2; k++) ctx.fillRect(sx + z / 2 - 0.5, sy + z * (0.1 + k * 0.5), 1, z * 0.28); }
            else if (rd === 2 || rd === 4) { ctx.fillStyle = rd === 4 ? '#e8e8e8' : '#e0b84a'; if (hz) { ctx.fillRect(sx, sy + z / 2 - 1.2, z, 0.9); ctx.fillRect(sx, sy + z / 2 + 0.3, z, 0.9); } if (vt) { ctx.fillRect(sx + z / 2 - 1.2, sy, 0.9, z); ctx.fillRect(sx + z / 2 + 0.3, sy, 0.9, z); } }
            else if (rd === 3 && C0.rdir[i]) { const d = C0.rdir[i] - 1; ctx.save(); ctx.translate(sx + z / 2, sy + z / 2); ctx.rotate(d * Math.PI / 2); ctx.fillStyle = 'rgba(255,255,255,.75)'; ctx.beginPath(); ctx.moveTo(0, -z * 0.3); ctx.lineTo(z * 0.18, -z * 0.05); ctx.lineTo(-z * 0.18, -z * 0.05); ctx.fill(); ctx.fillRect(-z * 0.05, -z * 0.08, z * 0.1, z * 0.32); ctx.restore(); }
          } else { ctx.fillStyle = 'rgba(255,255,255,.35)'; for (let k = 0; k < 4; k++) ctx.fillRect(sx + z * 0.15 + k * z * 0.19, sy + z * 0.05, z * 0.08, z * 0.12); }
          if (C0.ter[i] === 1) { ctx.fillStyle = 'rgba(30,30,36,.6)'; ctx.fillRect(sx, sy, z, z * 0.06); ctx.fillRect(sx, sy + z * 0.94, z, z * 0.06); }
        } else if (C0.zn[i] && !C0.bl[i] && !C0.ob[i]) {
          ctx.strokeStyle = ZN[C0.zn[i]].col; ctx.globalAlpha = 0.6; ctx.lineWidth = 1; ctx.strokeRect(sx + 2, sy + 2, z - 4, z - 4); ctx.globalAlpha = 1;
        }
        if (C0.pl[i] && !rd) { ctx.strokeStyle = '#d8d0b0'; ctx.lineWidth = 1; ctx.beginPath(); const lf = x > 0 && (C0.pl[i - 1] || C0.rd[i - 1]), rt = x < N - 1 && (C0.pl[i + 1] || C0.rd[i + 1]); if (lf || rt) { ctx.moveTo(sx, sy + z * 0.4); ctx.lineTo(sx + z, sy + z * 0.4); } else { ctx.moveTo(sx + z * 0.5, sy); ctx.lineTo(sx + z * 0.5, sy + z); } ctx.stroke(); ctx.fillStyle = '#8a7a5a'; ctx.fillRect(sx + z * 0.45, sy + z * 0.3, z * 0.1, z * 0.3); }
      }
      // 건물(위에서 아래 줄 순서 → 앞 건물이 뒤를 가림)
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
        const i = y * N + x, sx = SX(x), sy = SY(y);
        if (C0.ob[i]) { const b = C0.B[C0.ob[i] - 1]; if (b.x !== x || b.y !== y) continue; drawSv(C0, b, sx, sy, z); continue; }
        const zz = C0.zn[i], bl = C0.bl[i];
        if (zz && bl) { drawBld(C0, i, zz, bl, sx, sy, z); continue; }
        if (!zz && !C0.rd[i] && C0.fr[i] && C0.ter[i] === 0) { const k = hash(i, 4); ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.ellipse(sx + z * 0.55, sy + z * 0.75, z * 0.3, z * 0.12, 0, 0, 7); ctx.fill(); ctx.fillStyle = k % 2 ? '#3f6a35' : '#355c2e'; ctx.beginPath(); ctx.arc(sx + z * (0.35 + (k % 30) / 100), sy + z * 0.45, z * 0.28, 0, 7); ctx.fill(); ctx.fillStyle = '#4c7a3e'; ctx.beginPath(); ctx.arc(sx + z * 0.7, sy + z * 0.35, z * 0.2, 0, 7); ctx.fill(); }
      }
    }
    function drawBld(C0, i, zz, bl, sx, sy, z) {
      const k = ZN[zz].k, ab = C0.ab[i] & 128, hi = zz === Z_RH || zz === Z_CH || zz === Z_O, hsh = hash(i, 7);
      const ins = z * (0.12 - bl * 0.012), w = z - ins * 2;
      const ht = z * (hi ? 0.35 + bl * 0.42 : k === 'I' ? 0.25 + bl * 0.1 : 0.18 + bl * 0.1) * (0.85 + (hsh % 30) / 100);
      const pal = ab ? ['#57514b'] : zz === Z_RH ? ZROOF.RH : ZROOF[k], roof = pal[hsh % pal.length];
      const bx = sx + ins, by = sy + ins - ht;
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(bx + ht * 0.25, sy + ins + w * 0.15, w, w * 0.9);
      ctx.fillStyle = shade(roof, -40); ctx.fillRect(bx, by + w, w, ht); // 앞면
      if (z >= 18 && !ab) { ctx.fillStyle = k === 'O' || (k === 'C' && hi) ? 'rgba(170,215,255,.55)' : 'rgba(255,230,160,.45)'; const rows = Math.max(1, Math.floor(ht / (z * 0.22))); for (let r = 0; r < rows; r++) for (let c = 0; c < 3; c++) ctx.fillRect(bx + w * (0.12 + c * 0.3), by + w + ht * (r + 0.3) / rows, w * 0.16, Math.max(1, ht / rows * 0.35)); }
      ctx.fillStyle = roof; ctx.fillRect(bx, by, w, w);
      if (k === 'R' && !hi && !ab) { ctx.fillStyle = shade(roof, 25); ctx.fillRect(bx, by, w, w * 0.45); }
      if (k === 'I' && !ab) { ctx.fillStyle = '#6b6b6b'; ctx.fillRect(bx + w * 0.7, by - ht * 0.6, w * 0.14, ht * 0.6 + w * 0.2); if (hsh % 3 === 0) { ctx.fillStyle = 'rgba(200,200,200,.35)'; ctx.beginPath(); ctx.arc(bx + w * 0.77, by - ht * 0.7 - (tick % 40) * 0.1, w * 0.12, 0, 7); ctx.fill(); } }
      if (hi && !ab) { ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(bx + w * 0.15, by + w * 0.15, w * 0.7, w * 0.7); }
      if (ab) { ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + w, by + w); ctx.stroke(); }
      if (C0.burn[i]) { ctx.fillStyle = 'rgba(255,120,40,.6)'; ctx.fillRect(bx, by, w, w + ht); }
    }
    function drawSv(C0, b, sx, sy, z) {
      const s = SV[b.t], W = z * s.sz, ins = z * 0.08, w = W - ins * 2;
      const ht = z * (s.g === 'park' ? 0.05 : s.g === 'pw' ? 0.5 : s.g === 'lm' ? 1.2 : 0.55) * (s.sz > 1 ? 1.3 : 1);
      if (s.g === 'park') { ctx.fillStyle = '#4f8a4a'; ctx.fillRect(sx + ins, sy + ins, w, w); ctx.fillStyle = '#5f9e55'; for (let k = 0; k < s.sz * s.sz * 2; k++) { const hh = hash(b.x * 31 + b.y * 17 + k, 2); ctx.beginPath(); ctx.arc(sx + ins + (hh % 100) / 100 * w, sy + ins + ((hh * 7) % 100) / 100 * w, z * 0.18, 0, 7); ctx.fill(); } if (s.id === 'bigpark' || s.id === 'garden') { ctx.fillStyle = '#4a86b0'; ctx.beginPath(); ctx.ellipse(sx + W / 2, sy + W / 2, w * 0.2, w * 0.13, 0, 0, 7); ctx.fill(); } }
      else {
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(sx + ins + ht * 0.25, sy + ins + w * 0.1, w, w * 0.95);
        ctx.fillStyle = shade(s.col, -45); ctx.fillRect(sx + ins, sy + ins - ht + w, w, ht);
        ctx.fillStyle = s.col; ctx.fillRect(sx + ins, sy + ins - ht, w, w);
        ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1; ctx.strokeRect(sx + ins, sy + ins - ht, w, w);
        if (s.id === 'wind') { const a = tick * 0.12 * (b.act ? 1 : 0); ctx.strokeStyle = '#f2f2f2'; ctx.lineWidth = Math.max(1, z * 0.06); const cx = sx + W / 2, cy = sy + W / 2 - ht; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a + k * 2.09) * W * 0.6, cy + Math.sin(a + k * 2.09) * W * 0.6); ctx.stroke(); } ctx.fillStyle = '#9aa4ad'; ctx.beginPath(); ctx.arc(cx, cy, Math.max(1.5, z * 0.08), 0, 7); ctx.fill(); }
      }
      if (s.id !== 'wind') { const fs = Math.min(z * s.sz * 0.55, 40); ctx.font = fs + 'px ' + FONT; ctx.fillText(s.ic, sx + W / 2, sy + W / 2 - (s.g === 'park' ? 0 : ht)); }
      const off = b.ra < 0 || (!s.np && !C0.pw[b.y * C0.N + b.x]) || ((s.wt || s.sw) && !b.on);
      if (off && (tick >> 4) % 2) { ctx.font = Math.max(10, z * 0.5) + 'px ' + FONT; ctx.fillText(b.ra < 0 ? '🚗' : !C0.pw[b.y * C0.N + b.x] ? '⚡' : '🔵', sx + W - z * 0.25, sy - ht + z * 0.2); }
    }
    function shade(hex, d) { const n = parseInt(hex.slice(1), 16); const r = clamp((n >> 16) + d, 0, 255), g = clamp(((n >> 8) & 255) + d, 0, 255), b = clamp((n & 255) + d, 0, 255); return 'rgb(' + r + ',' + g + ',' + b + ')'; }
    function drawProblems(C0, x0, y0, x1, y1, SX, SY, z) {
      if ((tick >> 5) % 2) return; const N = C0.N; ctx.font = Math.max(10, Math.min(18, z * 0.55)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; let n = 0;
      for (let y = y0; y <= y1 && n < 250; y++) for (let x = x0; x <= x1; x++) {
        const i = y * N + x, p = C0.pb[i]; if (!p || !C0.bl[i] || !C0.zn[i]) continue;
        let ic = ''; for (let k = 0; k < PBN.length; k++) if (p & (1 << k)) { ic = PBN[k][1]; break; }
        if (C0.ab[i] & 128) ic = '🏚️';
        ctx.fillStyle = 'rgba(20,17,28,.75)'; ctx.beginPath(); ctx.arc(SX(x + 0.5), SY(y) - z * 0.3, z * 0.36, 0, 7); ctx.fill(); ctx.fillText(ic, SX(x + 0.5), SY(y) - z * 0.3); n++;
      }
    }
    function drawLines(C0, SX, SY, z) {
      C0.lines.forEach((ln) => {
        const col = LINEC[ln.c % LINEC.length]; ctx.strokeStyle = col; ctx.lineWidth = Math.max(2, z * 0.18); ctx.globalAlpha = ln.ok ? 1 : 0.4;
        ctx.beginPath();
        if (ln.t === 'bus' && ln.path) ln.path.forEach((c, k) => { const px = SX(c % C0.N + 0.5), py = SY(((c / C0.N) | 0) + 0.5); if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
        else { ln.s.forEach((id, k) => { const b = C0.B[id]; if (!b) return; const px = SX(b.x + 0.5), py = SY(b.y + 0.5); if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); }); if (ln.s.length > 2) ctx.closePath(); }
        ctx.stroke(); ctx.globalAlpha = 1;
        for (const id of ln.s) { const b = C0.B[id]; if (!b) continue; ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(SX(b.x + 0.5), SY(b.y + 0.5), Math.max(3, z * 0.25), 0, 7); ctx.fill(); ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.stroke(); }
      });
    }
    function drawGhost(C0, SX, SY, z) {
      if (!ghost || !myCityEditable()) return;
      if (ghost.sv != null) {
        const s = SV[ghost.sv]; ctx.fillStyle = ghost.ok ? 'rgba(120,230,140,.45)' : 'rgba(240,90,80,.45)'; ctx.fillRect(SX(ghost.x), SY(ghost.y), z * s.sz, z * s.sz);
        ctx.strokeStyle = ghost.ok ? '#8fe39c' : '#ff7a6a'; ctx.lineWidth = 2; ctx.strokeRect(SX(ghost.x), SY(ghost.y), z * s.sz, z * s.sz);
        if (s.r) circle(ghost.x + s.sz / 2, ghost.y + s.sz / 2, s.r * (0.75 + 0.25 * C0.bud[bgOf(s.g) || 'park'] / 100), SX, SY, z, 'rgba(160,230,255,.95)');
        ctx.font = Math.min(30, z * s.sz * 0.6) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(s.ic, SX(ghost.x + s.sz / 2), SY(ghost.y + s.sz / 2));
        label(SX(ghost.x + s.sz / 2), SY(ghost.y) - 14, ghost.ok ? won(ghost.cost) : ghost.why, ghost.ok);
        return;
      }
      const N = C0.N; let lx = 0, ly = 0;
      ghost.cells.forEach((i, k) => { const st = ghost.st[k]; ctx.fillStyle = st === 2 ? (tool.startsWith('bull') ? 'rgba(240,90,80,.5)' : tool.startsWith('zone') && +tool.split(':')[1] ? hexA(ZN[+tool.split(':')[1]].col, 0.6) : tool.startsWith('dist') ? hexA(DISTC[+tool.split(':')[1]] || '#ffffff', 0.5) : 'rgba(120,230,140,.55)') : st === 1 ? 'rgba(255,255,255,.18)' : 'rgba(240,90,80,.4)'; const x = i % N, y = (i / N) | 0; ctx.fillRect(SX(x), SY(y), z, z); lx = x; ly = y; });
      if (tool === 'road:3' && ghost.dirs) { ctx.fillStyle = '#fff'; ghost.cells.forEach((i, k) => { if (k % 2 || !ghost.dirs[k]) return; const x = i % N, y = (i / N) | 0; ctx.save(); ctx.translate(SX(x + 0.5), SY(y + 0.5)); ctx.rotate((ghost.dirs[k] - 1) * Math.PI / 2); ctx.beginPath(); ctx.moveTo(0, -z * 0.3); ctx.lineTo(z * 0.2, 0); ctx.lineTo(-z * 0.2, 0); ctx.fill(); ctx.restore(); }); }
      const txt = tool.startsWith('road') || tool === 'pi' || tool === 'pl' ? won(ghost.cost) + ' · ' + ghost.cells.length + '칸' : tool.startsWith('zone') ? ghost.st.filter((v) => v === 2).length + '칸' : ghost.cells.length + '칸';
      label(SX(lx + 0.5), SY(ly) - 16, txt, ghost.cost <= C0.m);
    }
    function hexA(hex, a) { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; }
    function label(x, y, t, ok) { ctx.font = '600 12px ' + FONT; const w = ctx.measureText(t).width + 12; x = clamp(x, w / 2 + 4, cv.w - w / 2 - 4); y = clamp(y, 90, cv.h - 130); ctx.fillStyle = 'rgba(20,17,28,.9)'; ctx.fillRect(x - w / 2, y - 10, w, 20); ctx.fillStyle = ok ? '#f2e9d8' : '#ff8e7a'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(t, x, y); }
    const floats = [];
    function floatTxt(t, x, y) { floats.push({ t, x, y, a: 1.2 }); }
    function drawFloats(SX, SY) { for (let k = floats.length - 1; k >= 0; k--) { const f = floats[k]; f.a -= 0.016; f.y -= 0.02; if (f.a <= 0) { floats.splice(k, 1); continue; } ctx.globalAlpha = Math.min(1, f.a); ctx.font = '700 13px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = f.t[0] === '+' ? '#8fd16b' : '#ffd27a'; ctx.fillText(f.t, SX(f.x), SY(f.y)); ctx.globalAlpha = 1; } }
    /* 차: 교통 계산에서 나온 실제 경로를 따라 달림 */
    function drawCars(C0, SX, SY, z) {
      const P = C0._paths; if (!P || !P.length) return;
      const want = Math.min(160, Math.round(C0.st.pop / 60) + 6);
      if (cars.length < want && speed && tick % 2 === 0) { const q = P[Math.floor(Math.random() * P.length)]; if (q && q.p.length > 2) cars.push({ q, t: 0, col: q.k === 2 ? '#e6ad45' : ['#f2f2f2', '#d9d9d9', '#e05a4a', '#4a7fd0', '#2a2a2a', '#f2c14e'][Math.floor(Math.random() * 6)] }); }
      const N = C0.N, sz = Math.max(1.6, z * 0.2);
      for (let k = cars.length - 1; k >= 0; k--) {
        const c = cars[k], p = c.q.p; const ci = Math.min(p.length - 1, Math.floor(c.t));
        if (speed) { const cg = C0.cong[p[ci]] / 100; c.t += 0.09 * speed * (RD[C0.rd[p[ci]]] ? RD[C0.rd[p[ci]]].sp : 1) / (1 + cg * cg * 1.5); }
        if (c.t >= p.length - 1 || !C0.rd[p[ci]]) { cars.splice(k, 1); continue; }
        const a = p[ci], b = p[Math.min(p.length - 1, ci + 1)], f = c.t - ci;
        const ax = a % N, ay = (a / N) | 0, bx = b % N, by = (b / N) | 0; const dx = bx - ax, dy = by - ay;
        const x = ax + 0.5 + dx * f - dy * 0.2, y = ay + 0.5 + dy * f + dx * 0.2;
        ctx.fillStyle = c.col; const L0 = c.q.k === 2 ? sz * 1.8 : sz * 1.3; if (dx) ctx.fillRect(SX(x) - L0 / 2, SY(y) - sz / 2, L0, sz); else ctx.fillRect(SX(x) - sz / 2, SY(y) - L0 / 2, sz, L0);
      }
    }

    /* ---------- 시간·시뮬 ---------- */
    function cityTick(c, seat) {
      const lv = c.ai ? c.ai.lv : 0; const every = { 1: 18, 2: 10, 3: 8 }[lv] || 10;
      if (c.ai && c.day % every === 0) try { aiStep(c); } catch (e) { console.error(e); }
      const m = dayTick(c);
      if (m && c === viewC) { cacheAll = true; cacheRow = 0; ovKey = ''; }
      void seat; return m;
    }
    function loop(dt) {
      tick++; if (!S || !C && !viewC) { render(); return; }
      if (ended) { render(); return; }
      const sp = api.online ? (S.sp != null ? S.sp : 1) : speed;
      if (api.online && sp !== speed) { speed = sp; spBtns.forEach((b, k) => b.classList.toggle('on', k === sp)); }
      // 하루 진행
      if (sp > 0) {
        dayAcc += dt * dbgSp();
        const dayLen = SPEEDS[sp]; let n = 0;
        while (dayAcc >= dayLen && n < 6) {
          dayAcc -= dayLen; n++;
          let gate = true; // 온라인 게스트: 방장 달보다 앞서지 않기
          if (api.online && !api.isHost && C && C.mo > (S.mo || 0)) gate = false;
          if (!gate) { dayAcc = 0; break; }
          for (const k in cities) { const c = cities[k]; if (api.online && !api.isHost && c !== C) continue; const m = cityTick(c, +k); if (m && c === C) onMyMonth(); }
          if (api.online && !api.isHost && C && C.mo < (S.mo || 0) - 1) for (let q = 0; q < 3; q++) { cityTick(C, me); if (C.mo >= (S.mo || 0)) break; } // 뒤처지면 따라잡기
        }
        if (dayAcc > dayLen * 6) dayAcc = 0;
      }
      // 작업 줄(프레임 예산)
      const t0 = now(), budget = 5;
      for (const k in cities) { const c = cities[k]; if (c.job.s < 8) simStep(c, t0 + (c === C || c === viewC ? budget * 0.6 : budget * 0.4 / Math.max(1, Object.keys(cities).length - 1))); }
      if (viewC && viewC._dn && now() - (viewC._dnT || 0) > 300) { viewC._dnT = now(); computeAcc(viewC); computePower(viewC); computeWater(viewC); viewC._dn = 0; ovKey = ''; }
      if (viewC && viewC.job.s === 5 && !viewC._cacheMark) { viewC._cacheMark = 1; cacheAll = true; cacheRow = 0; } if (viewC && viewC.job.s === 0) viewC._cacheMark = 0;
      if (viewC && viewC.dirtyCells && viewC.dirtyCells.length) { markDirty(viewC.dirtyCells); viewC.dirtyCells.length = 0; }
      // 키보드 이동
      if (api.input && api.input.axis) { const ax = api.input.axis('left', 'right'), ay = api.input.axis('up', 'down'); if (ax || ay) { cam.x += ax * dt * 600 / cam.z; cam.y += ay * dt * 600 / cam.z; clampCam(); } }
      if (shake > 0) shake = Math.max(0, shake - dt * 20);
      updateCache(4);
      render();
      if (tick % 15 === 0) hudUpdate();
      pollNews();
      if (api.isHost && S && tick % 30 === 0) hostCollect(false);
    }
    function pollNews() {
      if (!viewC) return; const C0 = viewC;
      if (C0.nid > lastNews) {
        for (const n of C0.news) { if (n.id <= lastNews) continue; if (C0 === C || demo) { api.toast(n.txt.length > 46 ? n.txt.slice(0, 45) + '…' : n.txt); if (n.t === 'fire' || n.t === 'flood') { api.sfx('lose'); api.buzz(40); if (fx() > 0) shake = 6 * fx(); } else if (n.t === 'tier' || n.t === 'good') { api.sfx('win'); refreshTools(); } else api.sfx('pop'); } }
        lastNews = C0.nid;
        if (C0.nid > newsSeen) { newsBadge.style.display = ''; newsBadge.textContent = Math.min(9, C0.nid - newsSeen); }
      }
    }
    function onMyMonth() {
      if (!C) return;
      if (S.md === 'sand' && !demo && C.mo % 3 === 0) save(false);
      if (!demo && C.mo % 12 === 0) try { api.best('pop', C.st.pop, { label: '최고 인구', unit: '명' }); } catch (e) {}
      if (api.online && !api.isHost) { api.net.publish({ k: S.rid, mo: C.mo, p: packP(C), th: C.mo % 2 === 0 || !lastTh ? (lastTh = thumb(C, 20)) : lastTh }); }
      if (api.isHost) hostCollect(true);
      if (S.md === 'goal' && C.goalAt && api.isHost) finish();
      if (S.md === 'scen' && C.sc && C.sc.end && api.isHost) finish();
    }
    let lastTh = '';
    const packP = (c) => [c.st.pop, Math.round(c.m / 1000), c.tier, c.st.hap, c.mo];
    function hostCollect(month) {
      // 방장: 내 도시 + AI 도시 + 게스트 도시 통계를 모아 상태로
      if (!S || ended) return;
      const n = api.players.length, P = [], th = (S.th || []).slice();
      let rem = null; if (api.online) try { rem = api.net.remote(); } catch (e) { rem = null; }
      for (let k = 0; k < n; k++) {
        if (cities[k]) { P[k] = packP(cities[k]); if (month && (cities[k].mo % 3 === 0 || !th[k])) th[k] = thumb(cities[k], 20); }
        else if (rem && rem[k] && rem[k].k === S.rid && Array.isArray(rem[k].p)) { P[k] = rem[k].p.slice(0, 5); if (typeof rem[k].th === 'string') th[k] = rem[k].th.slice(0, 400); }
        else P[k] = (S.P && S.P[k]) || [0, 0, 0, 0, 0];
      }
      const mo = (C || viewC).mo;
      const changed = month || JSON.stringify(P) !== JSON.stringify(S.P);
      if (!changed) return;
      const ns = Object.assign({}, S, { P, th, mo });
      if (S.md === 'race' && mo >= S.yrs * 12) { ns.ph = 'end'; }
      api.setState(ns);
    }
    function finish() {
      if (!api.isHost || ended) return;
      const n = api.players.length, P = []; for (let k = 0; k < n; k++) P[k] = cities[k] ? packP(cities[k]) : ((S.P && S.P[k]) || [0, 0, 0, 0, 0]);
      if (S.md === 'sand' && !demo) save(false);
      if (!demo && C) try { api.best('pop', C.st.pop, { label: '최고 인구', unit: '명' }); if (S.md === 'goal' && C.goalAt) api.best('goal' + S.goal, C.goalAt, { label: '목표 ' + num(S.goal) + '명 걸린 달', lower: true, unit: '달' }); } catch (e) {}
      api.setState(Object.assign({}, S, { ph: 'end', P, mo: (C || viewC).mo, ga: C ? C.goalAt || 0 : 0, sc: C && C.sc ? { id: C.sc.id, end: C.sc.end, stars: C.sc.stars, at: C.sc.at, why: C.sc.why } : null, rid0: C ? C.st.rid : 0, fl: C ? C.st.flow : 0 }));
    }
    function save(show) { if (!C || demo || S.md !== 'sand') return; try { localStorage.setItem(KEY, serialize(C)); if (show) api.toast('💾 저장했어요'); } catch (e) { if (show) api.toast('저장 공간이 모자라요'); } }

    function hudUpdate() {
      const c = viewC; if (!c) return; const s = c.st;
      moneyChip.innerHTML = ''; moneyChip.classList.toggle('neg', c.m < 0); moneyChip.append(won(c.m), h('small', { text: ((c.fin && c.fin.net) >= 0 ? '+' : '') + num((c.fin && c.fin.net) || 0) + '/달' }));
      popChip.innerHTML = ''; popChip.append('👥 ' + num(s.pop), h('small', { text: S && S.md === 'goal' ? '/' + num(S.goal) : c.sc ? '🎯 ' + c.sc.obj.filter((o) => scCmp(scM(c, o.k), o.op, o.v)).length + '/' + c.sc.obj.length : TIERS[c.tier].n }));
      dateChip.textContent = (Math.floor(c.mo / 12) + 1) + '년 ' + (c.mo % 12 + 1) + '월' + (S && S.md === 'race' ? ' /' + S.yrs + '년' : '');
      subInfo.innerHTML = ''; rci.innerHTML = '';
      for (const k of ZK) { if (k === 'O' && c.tier < ZN[Z_O].tier) continue; const v = s.dem[k]; const hgt = Math.round(clamp((v + 100) / 2, 0, 100)); rci.append(h('span', {}, { R: '주', C: '상', I: '산', O: '사' }[k], h('i', {}, h('b', { style: { height: hgt + '%', background: v > 20 ? ZN[{ R: 1, C: 3, I: 5, O: 6 }[k]].col : v > -10 ? '#8a8494' : '#7a4a44' } })))); }
      subInfo.append(dateChip, rci, h('span', { text: '😊' + s.hap + '%' }), h('span', { text: '🚗' + s.flow + '%' }));
      const a = c.alerts || {}; const al = [['pw', '⚡'], ['wt', '💧'], ['sw', '🚽'], ['gar', '🗑️'], ['dead', '⚱️'], ['traffic', '🚗'], ['out', '🛣️'], ['money', '💸']].filter(([k]) => a[k]);
      for (const [k, ic] of al) subInfo.append(h('span', { class: 'cb-al', text: ic, title: k, onclick: () => { openNews(); } }));
      if (S && S.md === 'race') { const P = S.P || []; const mine = (P[me >= 0 ? me : 0] || [0])[0]; const rank = 1 + P.filter((p) => p && p[0] > mine).length; subInfo.append(h('span', { class: 'cb-chip', style: { minHeight: '24px', padding: '0 6px', fontSize: '11px' }, text: '🏁 ' + rank + '/' + P.length, onclick: () => openBoard() })); }
      if (c.sc && !c.sc.end) subInfo.append(h('span', { class: 'cb-chip', style: { minHeight: '24px', padding: '0 6px', fontSize: '11px' }, text: '⏳' + Math.max(0, c.sc.lim - c.mo) + '달', title: '시나리오 남은 기한', onclick: () => openScen(false) }));
      if (viewC !== C && C) subInfo.append(h('span', { style: { color: 'var(--brass)' }, text: '👀 구경 중' }));
      HINT.c = c;
    }

    /* ---------- 시작 ---------- */
    function start(st) {
      S = st; const seats = api.mySeats(); me = seats.length ? seats[0] : -1;
      demo = me < 0 && api.isHost;
      const mk = (lv) => { const c = newCity({ seed: st.seed, mp: st.mp, n: st.n, dis: st.dis, md: st.md, goal: st.goal }); if (st.md === 'scen') scenSetup(c, st.scn); if (lv) aiInit(c, lv); return c; };
      if (me >= 0) {
        if (st.md === 'sand' && st.cont) { try { const raw = localStorage.getItem(KEY); if (raw) C = deserialize(raw); } catch (e) { C = null; } if (C) api.toast('💾 이어서 해요 · ' + (Math.floor(C.mo / 12) + 1) + '년째'); }
        if (!C) C = mk(0);
        cities[me] = C;
      }
      if (api.isHost) api.players.forEach((p, k) => { if (p.ai) { const c = mk(p.lv || 2); cities[k] = c; if (!C && demo && k === 0) C = c; } });
      if (demo) C = cities[0];
      viewC = C || cities[Object.keys(cities)[0]];
      if (!viewC) { viewC = mk(0); spect = true; } // 관전: 같은 지형만 보여 줌
      for (const k in cities) { const c = cities[k]; c.job = { s: 0, k: 0 }; simStep(c, Infinity); c.job = { s: 0, k: 0 }; }
      if (viewC) { centerOn(viewC); lastNews = viewC.nid; newsSeen = viewC.nid; }
      speed = st.sp != null ? st.sp : 1; spBtns.forEach((b, k) => { b.classList.toggle('on', k === speed); if (api.online && !api.isHost) b.disabled = true; });
      if (st.md === 'goal' && C) C.goal = st.goal;
      refreshTools(); hudUpdate(); updHint(); layout(); setTimeout(layout, 50);
      setTimeout(() => { if (st.md === 'scen' && C && C.sc && !demo) openScen(true); else showTip(false); }, 300);
    }
    const stopLoop = U.loop(loop);
    cv.onresize = () => { layout(); };
    function onUi() { layout(); }
    window.addEventListener('lounge-ui', onUi);
    // 라운드 44 저장 훅(core 「저장·이어하기」): 혼자 하는 판만 — 온라인은 각자 기기에서 도시를 지으므로 방장이 모두를 저장할 수 없음
    const hooks = api.online ? {} : {
      saveState() { if (!S || demo || ended) return false; const c = {}; for (const k in cities) if (cities[k]) c[k] = serialize(cities[k]); return { rid: S.rid, c, sp: speed }; },
      loadState(b) {
        if (!b || !b.c) return;
        for (const k in b.c) { const c = deserialize(b.c[k]); if (!c) continue; const p = api.players[k]; if (p && p.ai) aiInit(c, p.lv || 2); if (S && S.md === 'goal') c.goal = S.goal; c.job = { s: 0, k: 0 }; simStep(c, Infinity); c.job = { s: 0, k: 0 }; cities[k] = c; }
        if (me >= 0 && cities[me]) C = cities[me];
        viewC = C || cities[Object.keys(cities)[0]];
        if (viewC) { centerOn(viewC); lastNews = viewC.nid; newsSeen = viewC.nid; }
        if (b.sp != null) speed = b.sp;
      },
    };
    return {
      ...hooks,
      update(state, prev) {
        if (!state) return;
        if (!S) start(state); else S = state;
        if (state.ph === 'end' && !ended) { ended = true; closeSheet(); closeInfo(); if (C && S.md === 'sand' && !demo) save(false); }
        void prev;
      },
      destroy() {
        alive = false; stopLoop(); try { if (C && S && S.md === 'sand' && !demo && !ended) save(false); } catch (e) {}
        cv.cv.removeEventListener('pointerdown', onDown); window.removeEventListener('pointermove', onMove); window.removeEventListener('pointerup', onUp); window.removeEventListener('pointercancel', onUp);
        window.removeEventListener('keydown', onKey, true); window.removeEventListener('lounge-ui', onUi);
        if (offIn) offIn();
        cv.destroy(); [hud, side, bar, legend, hint].forEach((e) => e.remove()); closeSheet(); closeInfo(); HINT.c = null;
        void alive;
      },
      _dbg: () => ({ C, viewC, cities, cam, S, setTool, pickCat, setLayer, openInfo, commit: (d) => commit(d), openBudget, openPolicies, openLines, openBoard, openStats, openMilestones, openNews, openScen, openAide }),
    };
  }
  const HINT = { c: null };

  /* ================= 도감 ================= */
  const svRow = (s) => ({ icon: s.ic, name: s.n, tag: TIERS[s.tier].n + (s.uniq ? ' · 하나만' : ''), desc: s.d + ' · 건설 ' + won(s.cost) + ' · 유지 ' + won(s.up) + '/달' + (s.sz > 1 ? ' · ' + s.sz + '×' + s.sz : '') + (s.pw ? ' · 전기 ' + s.pw + 'MW' : '') + (s.wt ? ' · 물 ' + s.wt + '톤' : '') + (s.sw ? ' · 하수 ' + s.sw + '톤' : '') + (s.r ? ' · 범위 ' + s.r + '칸' : '') + (s.store ? ' · 용량 ' + num(s.store) : '') + (s.proc ? ' · 처리 ' + num(s.proc) + '/달' : '') });
  const GN = { pw: '전기', wt: '상수', sw: '하수', gar: '쓰레기', dead: '추모', fire: '소방', pol: '치안', hlth: '의료', edu1: '교육', edu2: '교육', edu3: '교육', park: '공원', tr: '대중교통', lm: '랜드마크', sp: '특수' };
  const codex = [
    { h: '구역', p: ['길 옆에 칠하면 주민이 건물을 지어요. 칸 하나의 1~5단계 수용 인원(주민/일자리)입니다.'], rows: ZN.filter(Boolean).map((z) => ({ icon: ['🏠', '🏢', '🏪', '🏬', '🏭', '💼'][ZN.indexOf(z) - 1], name: z.n, tag: TIERS[z.tier].n, desc: z.d + ' · 단계별 ' + z.cap.slice(1).join('/') + (z.k === 'R' ? '명' : ' 일자리') })) },
    { h: '도로', p: ['물 위는 다리(값 ×' + BRIDGE + ').'], rows: RD.filter(Boolean).map((r) => ({ icon: '🛣️', name: r.n, tag: TIERS[r.tier].n, desc: r.d + ' · 칸당 ' + won(r.cost) + ' · 유지 ' + r.up + '/달 · 속도 ×' + r.sp + ' · 용량 ' + num(r.cap) })).concat([{ icon: '🔵', name: '수도관', tag: '기본', desc: '칸당 ' + won(PIPE_COST) + ' · 관에서 4칸 안 건물에 물·하수' }, { icon: '🔌', name: '송전선', tag: '기본', desc: '칸당 ' + won(PLINE_COST) + ' · 빈 땅을 건너 전기 잇기' }]) },
    { h: '기반 시설', rows: SV.filter((s) => ['pw', 'wt', 'sw', 'gar', 'dead'].includes(s.g)).map((s) => Object.assign(svRow(s), { tag: GN[s.g] + ' · ' + TIERS[s.tier].n })) },
    { h: '공공 서비스', rows: SV.filter((s) => ['fire', 'pol', 'hlth', 'edu1', 'edu2', 'edu3', 'park'].includes(s.g)).map((s) => Object.assign(svRow(s), { tag: GN[s.g] + ' · ' + TIERS[s.tier].n })) },
    { h: '교통·특별', rows: SV.filter((s) => ['tr', 'lm', 'sp'].includes(s.g)).map((s) => Object.assign(svRow(s), { tag: GN[s.g] + ' · ' + TIERS[s.tier].n })) },
    { h: '정책', p: ['📜에서 도시 전체 또는 지구마다 걸어요.'], rows: POL.map((p) => ({ icon: p.ic, name: p.n, tag: TIERS[p.tier].n, desc: p.d + (p.c ? ' · 건물 칸당 ₩' + p.c.toFixed(1) + '/달' : '') })) },
    { h: '이정표', rows: TIERS.map((t) => ({ icon: '🏆', name: t.n, tag: '인구 ' + num(t.p), desc: '지원금 ' + won(t.gift) + ' · 최고 ' + t.cap + '단계 건물' })) },
  ];

  /* ================= 정의 ================= */
  const def = {
    id: 'citybuild', name: '도시 건설', tag: '도시 경영', cat: '전략',
    blurb: '도로를 깔고 구역을 칠해 도시를 키워요. 전기·상하수도·쓰레기·교통·예산을 꾸리는 실시간 도시 경영. 혼자 샌드박스·목표 도전, 친구·AI와 각자 도시 인구 경쟁.',
    tint: '#1f4a5e', time: '20–60분', mood: 'calm',
    icon: '<rect x="6" y="30" width="12" height="20" fill="currentColor" opacity=".55"/><rect x="20" y="14" width="14" height="36" fill="currentColor"/><rect x="36" y="24" width="14" height="26" fill="currentColor" opacity=".8"/><path d="M23 19h3M28 19h3M23 25h3M28 25h3M23 31h3M28 31h3" stroke="#000" stroke-opacity=".35" stroke-width="2"/><path d="M4 52h48" stroke="currentColor" stroke-width="3"/><path d="M8 26l4-5 4 5z" fill="currentColor"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, realtime: true, save: true, saveLabel: (s) => (s && s.md === 'sand' ? '자유 모드' : s && s.md === 'goal' ? '목표 모드' : s && s.md === 'scen' ? '시나리오' : '경쟁'), hidden: false, contextMenu: true, aiNarration: true,
    maxPlayersIf(o) { return o && (o.md === 'race' || o.md === 'auto' || o.md == null) ? 4 : 1; },
    options: [
      { id: 'md', label: '방식', tip: '어떻게 즐길지.', choices: [{ v: 'auto', label: '자동(혼자=샌드박스·여럿=경쟁)', tip: '혼자면 샌드박스, 여럿이면 인구 경쟁.' }, { v: 'sand', label: '샌드박스', tip: '목표 없이 자유롭게 짓기(이어서 하기 가능).' }, { v: 'goal', label: '목표 도전', tip: '정한 인구를 달성하기.' }, { v: 'scen', label: '시나리오 도전', tip: '정해진 위기 상황을 해결하기.' }, { v: 'race', label: '인구 경쟁', tip: '정한 기간 동안 인구를 가장 많이.' }], def: 'auto' },
      { id: 'scn', label: '시나리오', tip: '「시나리오 도전」에서 할 판. 무작위면 9가지 중 하나.', choices: [{ v: 'rand', label: '무작위' }].concat(SCN.map((q) => ({ v: q.id, label: q.ic + ' ' + q.n, tip: q.d }))), def: 'rand' },
      { id: 'cont', label: '샌드박스', tip: '샌드박스에서 저장된 도시를 이어서 할지.', choices: [{ v: 1, label: '이어서 하기' }, { v: 0, label: '새 도시' }], def: 1 },
      { id: 'map', label: '지형', choices: [{ v: 'rand', label: '무작위' }, { v: 'river', label: '강' }, { v: 'coast', label: '바닷가' }, { v: 'lake', label: '호수' }, { v: 'hills', label: '산골' }], def: 'rand' },
      { id: 'size', label: '땅 크기', tip: '도시를 지을 땅의 가로·세로 칸 수.', choices: [{ v: 80, label: '작게 80' }, { v: 100, label: '보통 100' }, { v: 128, label: '크게 128' }], def: 100 },
      { id: 'goal', label: '목표 인구', tip: '「목표 도전」에서 이겨야 할 인구.', choices: [{ v: 5000, label: '5천' }, { v: 15000, label: '1만 5천' }, { v: 40000, label: '4만' }], def: 15000 },
      { id: 'yrs', label: '경쟁 기간', tip: '「인구 경쟁」의 게임 속 기간.', choices: [{ v: 5, label: '5년' }, { v: 10, label: '10년' }, { v: 15, label: '15년' }], def: 10 },
      { id: 'dis', label: '재해', tip: '화재·홍수 같은 재해가 가끔 일어나요.', choices: [{ v: 1, label: '켬' }, { v: 0, label: '끔' }], def: 1 },
    ],
    controls: [
      { id: 'up', label: '지도 위로', keys: ['ArrowUp', 'KeyW'], pad: ['up', 'ly-'] },
      { id: 'down', label: '지도 아래로', keys: ['ArrowDown', 'KeyS'], pad: ['down', 'ly+'] },
      { id: 'left', label: '지도 왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '지도 오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'zin', label: '확대', keys: ['Equal', 'NumpadAdd'], pad: ['rb'] },
      { id: 'zout', label: '축소', keys: ['Minus', 'NumpadSubtract'], pad: ['lb'] },
      { id: 'pause', label: '멈춤/계속', keys: ['Space', 'KeyP'], pad: ['start'] },
      { id: 'sp1', label: '빠르기 1×', keys: ['Digit1'], pad: [] },
      { id: 'sp2', label: '빠르기 2×', keys: ['Digit2'], pad: [] },
      { id: 'sp3', label: '빠르기 3×', keys: ['Digit3'], pad: [] },
      { id: 'layer', label: '정보 화면 바꾸기', keys: ['KeyO'], pad: ['y'] },
      { id: 'view', label: '보기 도구', keys: ['KeyV'], pad: ['b'] },
      { id: 'road', label: '도로 도구', keys: ['KeyR'], pad: [] },
      { id: 'zone', label: '구역 도구', keys: ['KeyZ'], pad: [] },
      { id: 'bull', label: '철거 도구', keys: ['KeyX', 'Delete'], pad: [] },
      { id: 'next', label: '같은 줄 다음 도구', keys: ['Tab'], pad: ['x'] },
      { id: 'budget', label: '예산', keys: ['KeyM'], pad: ['back'] },
    ],
    quick: [
      '목표: 빈 땅에 도시를 세워 인구를 늘려요(목표 도전: 정한 인구까지 / 경쟁: 정한 해 동안 인구가 가장 많은 시장이 승리).',
      '도로를 깔고 길 옆에 주거·상업·산업·사무 구역을 칠하면 주민이 알아서 건물을 지어요.',
      '전기·물·하수·쓰레기를 대 주고, 소방·치안·의료·교육·공원으로 땅값을 올리면 건물이 5단계까지 커져요.',
      '세금으로 벌고 유지비를 내요. 막히는 길은 큰길·일방통행·대중교통으로 풀어요.',
    ],
    rules: [
      { h: '목표', p: ['샌드박스: 끝 없이 도시를 키워요(이 기기에 저장, 「이어서 하기」). 목표 도전: 정한 인구에 빨리 닿기. 인구 경쟁: 모두 같은 지형에서 각자 자기 도시를 키우고, 정한 해가 끝났을 때 인구가 가장 많은 시장이 이겨요.'] },
      { h: '시작하는 순서', p: [
        '① 🛣️ 도로: 지도 가장자리에서 들어오는 고속도로 끝에서 길을 내요. 바깥과 이어져야 사람이 이사 오고 물건이 오가요.',
        '② 🏘️ 구역: 길에서 3칸 안쪽을 네모로 끌어 칠해요. 위쪽 막대(주·상·산·사)가 높은 구역이 지금 필요한 구역이에요.',
        '③ ⚡ 전기: 발전기를 길 옆에 지어요. 전기는 도로·건물을 타고 퍼지고, 빈 땅은 🔌 송전선으로 건너요.',
        '④ 💧 상하수도: 💧 취수장과 🕳️ 하수 배출구를 물가에 짓고 🔵 수도관으로 동네와 이어요. 관에서 4칸 안 건물에 물이 들어가요. 배출구는 물을 더럽히니 취수장과 멀리!',
        '예시: 고속도로 끝 → 2차선으로 네모 블록 → 안쪽을 주거, 고속도로 쪽을 산업 → 풍력 발전기 2개 → 강가에 취수장(위쪽)·배출구(아래쪽) → 수도관을 길 따라.',
      ] },
      { h: '건물이 자라는 조건(1~5단계)', p: [
        '전기·물·하수·쓰레기 수거가 되고 도로와 이어져야 해요. 오래 못 받으면 버려져요(🏚️).',
        '주거·상업은 땅값이 높을수록 높아져요(물가·언덕·공원·서비스 ↑, 오염·소음 ↓). 주거 3단계는 초등학교, 4단계는 고등학교+의료, 5단계는 대학교 범위가 필요해요. 상업 3단계는 치안이 필요해요.',
        '산업·사무는 주민의 교육 수준으로 커져요. 이정표(인구 단계)마다 최고 단계가 열려요.',
        '칸을 누르면 「⬆ 다음 단계에 필요한 것」과 문제 원인을 알려 줘요.',
      ] },
      { h: '서비스', p: ['🗑️ 매립지(가득 차면 새로)·소각장, ⚱️ 추모 공원, 🚒 소방서(불이 덜 나고 빨리 꺼짐), 🚓 파출소(범죄↓), 💊 보건소·병원(사망↓), 🏫 학교, 🌳 공원. 시설을 고르면 범위 원과 범위 지도가 보여요. 대부분 전기가 들어와야 일해요.'] },
      { h: '교통', p: [
        '주민은 실제로 집에서 일터·가게까지 가장 빠른 길로 다녀요. 🗺 → 🚗 교통에서 막힌 길이 빨강으로 보여요.',
        '4차선(넓음)·일방통행(끈 방향으로만, 교차로가 덜 막힘)·고속도로(아주 빠름, 옆에 구역 불가, 일반 도로와 닿는 곳이 나들목)를 섞어요.',
        '🚌 버스: 차고지 → 길 옆에 정류장 2곳 이상 → 「버스 노선」으로 정류장을 차례로 눌러 「완료」. 🚇 지하철역끼리는 땅속으로 이어져요. 집과 일터가 둘 다 노선 근처면 차 대신 타요. 🚉 기차역은 바깥 도시와 이어 수요를 늘려요.',
      ] },
      { h: '오염·행복·땅값', p: ['🏭 공장·발전소는 대기와 땅을, 큰길·상가는 소음을, 하수 배출구는 물을 더럽혀요. 더러운 물을 퍼 오면 주민이 아파요. 정보 화면(전력·물·교통·땅값·오염·서비스·행복)으로 확인해요.'] },
      { h: '예산', p: ['💰: 구역별 세율(기본 9%), 서비스 예산(50~150%: 범위·성능과 유지비), 대출 3종(나눠 갚기). 세금을 올리면 수요·행복이 떨어져요.'] },
      { h: '정책·지구', p: ['📜 정책(「' + TIERS[2].n + '」부터): 분리배출·금연·무료 대중교통·고층 제한·친환경 산업·소음 규제·절전·절수·첨단 산업·관광 특구. 🗺️ 지구 도구로 땅을 칠하면 지구마다 다른 정책을 걸 수 있어요.'] },
      { h: '이정표', p: ['인구가 ' + TIERS.slice(1).map((t) => num(t.p)).join(' · ') + '명이 될 때마다 지원금과 새 건물·도로·정책이 열려요(🏆).'] },
      { h: '재해(선택)', p: ['🔥 화재: 소방서 범위 밖이면 이웃으로 번져요. 🌊 홍수: 강·바닷가 낮은 땅 건물이 피해를 입어요. 메뉴에서 켜고 끌 수 있어요.'] },
      { h: '조작', p: [
        '폰: 👆 보기에서 끌어 이동·두 손가락 확대, 눌러서 정보. 도구를 고르면 끌어서 짓기(시설은 끌어서 자리 맞추고 손 떼기).',
        'PC: 왼쪽 끌기 = 짓기, 오른쪽(가운데) 끌기 = 이동, 오른쪽 클릭 = 도구 취소, 휠 = 확대. WASD·방향키 이동, Space 멈춤, 1·2·3 빠르기, O 정보 화면, R 도로, Z 구역, X 철거, Tab 다음 도구, M 예산, Esc 취소.',
        '시간: ⏸ 멈춤 · ▶ 1× · ▶▶ 2× · ▶▶▶ 3×. 멈춘 채로도 지을 수 있어요(온라인 경쟁은 방장이 빠르기를 정해요).',
      ] },
      { h: '시나리오 도전(혼자)', p: ['정해진 상황에서 시작해 목표를 모두 2달 연달아 지키면 성공. 빨리 이룰수록 별 ★★★. 기한이 지나거나 빚이 ' + won(SC_DEBT) + '를 넘으면 실패(시나리오마다 다른 실패 조건도 있어요). 기본은 무작위, 설정에서 고를 수 있어요. 위 🎯 칸을 누르면 목표·남은 달을 봐요.', SCN.map((q) => q.ic + ' ' + q.n).join(' · ')] },
      { h: '📋 시장 비서', p: ['옆 📋 버튼: 지금 도시 자료(전기·물·돈·교통·오염·행복·목표)로 급한 문제와 할 일을 보고해요. 설정 「🤖 AI 서술」을 켜면 비서가 같은 자료로 자연스러운 말로 정리해 줘요(✦ 표시, 숫자는 자료 그대로).'] },
      { h: '인구 경쟁(멀티)', p: ['방식 「인구 경쟁」에서 2~4명(친구는 온라인/LAN 한 폰에 한 명, 빈자리는 AI 시장). 모두 같은 지형에서 각자 도시를 지어요. 🏁에서 순위와 작은 지도를 보고, AI 도시는 들어가 구경할 수 있어요. AI 시장 실력은 자리마다 쉬움·보통·어려움.'] },
    ],
    codex,
    _sim: sim,
    hint() {
      const c = HINT.c; if (!c) return null; const a = c.alerts || {}, s = c.st, out = ['지금 도시: 인구 ' + num(s.pop) + ' · ' + TIERS[c.tier].n];
      if (!s.pop) out.push('고속도로 끝에서 길을 내고 옆에 주거·산업을 칠해요.');
      if (a.pw) out.push('⚡ 전기가 모자라요 — 발전소를 더 지어요.'); if (a.wt || a.sw) out.push('💧 물·하수가 모자라요 — 물가 시설 + 수도관.'); if (a.gar) out.push('🗑️ 쓰레기 — 매립지를 동네 가까이.'); if (a.traffic) out.push('🚗 길이 막혀요 — 🗺 교통에서 빨간 길을 넓히거나 우회로.');
      const D = s.dem, top = ZK.filter((k) => D[k] > 30).map((k) => ({ R: '주거', C: '상업', I: '산업', O: '사무' }[k]));
      if (top.length) out.push('수요가 높아요: ' + top.join('·') + ' 구역을 더 칠해요.');
      if (out.length < 3) out.push('칸을 누르면 그 건물이 다음 단계로 가려면 무엇이 필요한지 알려 줘요.');
      return out.slice(0, 6);
    },
    preview(cvs) {
      const x = cvs.getContext('2d'), W = cvs.width, H = cvs.height; const R = prng(7);
      x.fillStyle = '#4f6b40'; x.fillRect(0, 0, W, H);
      x.fillStyle = '#2f6d8f'; x.beginPath(); x.moveTo(0, H * 0.75); for (let i = 0; i <= 20; i++) x.lineTo(i * W / 20, H * 0.72 + Math.sin(i * 0.7) * 16); x.lineTo(W, H); x.lineTo(0, H); x.fill();
      const z = 22;
      for (let gy = 0; gy < 9; gy++) for (let gx = 0; gx < 30; gx++) {
        const px = gx * z, py = gy * z + 10; if (py > H * 0.7) continue; const road = gx % 7 === 0 || gy % 4 === 0;
        if (road) { x.fillStyle = '#4e4e57'; x.fillRect(px, py, z, z); continue; }
        const k = gx > 18 ? 'I' : gx > 12 ? 'C' : 'R'; const pal = ZROOF[k]; const lv = 1 + Math.floor(R() * 5), ht = z * (0.2 + lv * (k === 'C' ? 0.35 : 0.15));
        x.fillStyle = 'rgba(0,0,0,.25)'; x.fillRect(px + 5, py + 4, z - 4, z - 4); x.fillStyle = shadeP(pal[gx % pal.length], -40); x.fillRect(px + 2, py + 2 - ht + z - 4, z - 4, ht); x.fillStyle = pal[(gx + gy) % pal.length]; x.fillRect(px + 2, py + 2 - ht, z - 4, z - 4);
      }
      x.fillStyle = '#f2e9d8'; x.font = '700 30px ' + FONT; x.fillText('도시 건설', 20, H - 22);
      function shadeP(hex, d) { const n = parseInt(hex.slice(1), 16); return 'rgb(' + clamp((n >> 16) + d, 0, 255) + ',' + clamp(((n >> 8) & 255) + d, 0, 255) + ',' + clamp((n & 255) + d, 0, 255) + ')'; }
    },

    init(players, opts) {
      const o = opts || {}, n = players.length;
      const md = n > 1 ? 'race' : (o.md === 'goal' || o.md === 'race' || o.md === 'scen' ? o.md : 'sand');
      const scn = md === 'scen' ? (SCNI[o.scn] ? o.scn : SCN[U.rand(SCN.length)].id) : '';
      const scMap = scn && SCNI[scn].mp !== 'rand' ? SCNI[scn].mp : null;
      const size = [80, 100, 128].includes(+o.size) ? +o.size : 100;
      return { ph: 'play', md, scn, seed: 1 + U.rand(2147480000), mp: scMap || (MAPS.includes(o.map) ? o.map : 'rand'), n: scn ? 100 : size, dis: o.dis === 0 || o.dis === '0' ? 0 : 1,
        cont: md === 'sand' && !(players[0] && players[0].ai) && !(o.cont === 0 || o.cont === '0') ? 1 : 0, goal: [5000, 15000, 40000].includes(+o.goal) ? +o.goal : 15000,
        yrs: [5, 10, 15].includes(+o.yrs) ? +o.yrs : 10, sp: 1, mo: 0, rid: U.rand(1e9), P: players.map(() => [0, 0, 0, 0, 0]), th: [] };
    },
    actor() { return null; },
    apply() { throw new Error('realtime'); },
    result(s) {
      if (!s || s.ph !== 'end') return null;
      const P = s.P || [], n = P.length, y = Math.floor((s.mo || 0) / 12), m = (s.mo || 0) % 12;
      if (s.md === 'race' && n > 1) {
        const best = Math.max(...P.map((p) => (p ? p[0] : 0))); const winners = P.map((p, k) => (p && p[0] === best ? k : -1)).filter((k) => k >= 0);
        return { winners, title: '인구 경쟁 끝', text: s.yrs + '년 동안 가장 큰 도시를 세운 시장이 이겼어요.', stats: [{ label: '인구', values: P.map((p) => num(p ? p[0] : 0) + '명') }, { label: '도시 단계', values: P.map((p) => TIERS[(p && p[2]) | 0].n) }, { label: '행복', values: P.map((p) => ((p && p[3]) | 0) + '%') }, { label: '재정', values: P.map((p) => won(((p && p[1]) | 0) * 1000)) }] };
      }
      const p = P[0] || [0, 0, 0, 0];
      const stats = [{ label: '인구', value: num(p[0]) + '명' }, { label: '도시 단계', value: TIERS[p[2] | 0].n }, { label: '행복', value: (p[3] | 0) + '%' }, { label: '기간', value: y + '년 ' + m + '달' }, { label: '재정', value: won((p[1] | 0) * 1000) }];
      if (s.md === 'scen') { const r = s.sc || {}, S0 = SCNI[s.scn] || { ic: '', n: '' }, ok = r.end === 'win', st3 = r.stars | 0; return { winners: ok ? [0] : [], title: ok ? '시나리오 성공 ' + '★'.repeat(st3) + '☆'.repeat(3 - st3) : '시나리오 실패', text: S0.ic + ' ' + S0.n + ' — ' + (ok ? r.at + '달 만에 목표를 이뤘어요!' : r.why ? r.why : '도전을 그만두었어요.'), stats }; }
      if (s.md === 'goal') { const ok = !!s.ga; return { winners: ok ? [0] : [], title: ok ? '목표 달성!' : '목표 도전 끝', text: ok ? '인구 ' + num(s.goal) + '명까지 ' + Math.floor(s.ga / 12) + '년 ' + (s.ga % 12) + '달 걸렸어요.' : '목표 ' + num(s.goal) + '명에 아직 못 닿았어요.', stats }; }
      return { winners: [0], title: '도시 결산', text: '인구 ' + num(p[0]) + '명 · ' + TIERS[p[2] | 0].n + '\n도시는 이 기기에 저장돼 있어요. 「이어서 하기」로 계속!', stats };
    },
    mount(root, api) { return mountView(root, api); },
  };
  L.register(def);
})();
