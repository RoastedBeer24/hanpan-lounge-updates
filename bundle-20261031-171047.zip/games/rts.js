/* 미니 RTS — realtime base-building strategy for 2–4 (1:1 · 2:2 · 개인전), one human per phone.
   Workers mine 광석·수정, build 본부/보급고/병영/공장/연구소/포탑, train 7 unit types with counters, research 4 upgrades.
   Generated symmetric tile map (high-ground plateaus with ramps, rocks/ridges = chokepoints, expansion sites), fog of war.
   Host-authoritative fixed-step sim (STEP s) in the view; flow fields (Dijkstra, cached) for ground pathing.
   Guests publish a small acked command queue; host sends ~10 Hz packed snapshots of what guests may see (< 4096 chars).
   The coarse JSON state only holds the match setup and the result. Destroy every enemy structure to win. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const STEP = 0.1, INF = 65535;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /* ---------------- data ---------------- */
  // cls: w worker, i infantry, v vehicle · tag: light / armored / air (for bonus damage) · c: [광석, 수정]
  const UN = [
    { k: 'wk', nm: '일꾼', cls: 'w', tag: 'light', hp: 40, ar: 0, dm: 5, ud: 0, rg: 0.3, cd: 1.2, sp: 2.8, si: 6, r: 0.36, c: [50, 0], sup: 1, bt: 12, from: 0, req: -1, aa: 0, ag: 1, bo: {}, d: '광석·수정을 캐 오고 건물을 지어요. 싸움은 약해요.' },
    { k: 'rf', nm: '소총병', cls: 'i', tag: 'light', hp: 60, ar: 0, dm: 6, ud: 1, rg: 5, cd: 0.8, sp: 2.5, si: 8, r: 0.36, c: [50, 0], sup: 1, bt: 16, from: 2, req: -1, aa: 1, ag: 1, bo: { air: 1.3 }, d: '싸고 무난한 기본 보병. 공중(드론)도 쏘고, 드론에 1.3배.' },
    { k: 'fl', nm: '화염병', cls: 'i', tag: 'light', hp: 100, ar: 1, dm: 8, ud: 1, rg: 2, cd: 1.0, sp: 2.5, si: 7, r: 0.42, c: [75, 25], sup: 2, bt: 20, from: 2, req: -1, aa: 0, ag: 1, bo: { light: 1.6 }, spl: 1.1, d: '짧은 불길로 모여 있는 보병·일꾼을 한꺼번에 태워요(경보병 1.6배, 범위). 공중은 못 쏴요.' },
    { k: 'sn', nm: '저격수', cls: 'i', tag: 'light', hp: 45, ar: 0, dm: 20, ud: 2, rg: 9, cd: 2.0, sp: 2.3, si: 10, r: 0.36, c: [75, 75], sup: 2, bt: 24, from: 2, req: 4, aa: 1, ag: 1, bo: { armored: 0.5 }, d: '아주 멀리서 한 발씩 크게. 화염병·소총병을 사거리 밖에서 잡아요. 장갑엔 절반.' },
    { k: 'ac', nm: '경장갑차', cls: 'v', tag: 'armored', hp: 130, ar: 1, dm: 8, ud: 1, rg: 5, cd: 0.6, sp: 3.8, si: 9, r: 0.6, c: [100, 25], sup: 2, bt: 22, from: 3, req: -1, aa: 0, ag: 1, bo: { light: 1.4 }, d: '빠른 장갑차. 저격수·보병을 몰아붙이고 일꾼을 습격해요(경보병 1.4배). 공중은 못 쏴요.' },
    { k: 'at', nm: '포격 전차', cls: 'v', tag: 'armored', hp: 170, ar: 1, dm: 26, ud: 3, rg: 9, mr: 2, cd: 2.8, sp: 1.8, si: 10, r: 0.75, c: [150, 100], sup: 3, bt: 36, from: 3, req: 4, aa: 0, ag: 1, bo: { armored: 1.5, bld: 1.6 }, spl: 1.4, d: '멀리 포탄을 날려 범위 피해. 장갑 1.5배·건물 1.6배. 바로 앞(2칸)은 못 쏘고 공중엔 무력해요.' },
    { k: 'dr', nm: '정찰 드론', cls: 'v', tag: 'air', air: 1, hp: 70, ar: 0, dm: 6, ud: 1, rg: 4, cd: 0.9, sp: 4.2, si: 11, r: 0.45, c: [75, 50], sup: 2, bt: 20, from: 3, req: 4, aa: 1, ag: 1, bo: { armored: 1.6 }, d: '절벽을 넘어 날고 높은 곳도 봐요. 전차·장갑차에 1.6배. 소총병·포탑에 약해요.' },
    { k: 'tp', nm: '수송기', cls: 'v', tag: 'air', air: 1, hp: 150, ar: 1, dm: 0, ud: 0, rg: 0, cd: 1, sp: 3.6, si: 9, r: 0.62, c: [100, 75], sup: 2, bt: 26, from: 3, req: 4, aa: 0, ag: 0, bo: {}, cap: 4, d: '무기 없음. 보병 4명(일꾼 포함) 또는 차량 1대를 태우고 바위·절벽을 넘어 날아가 내려놓아요. 격추되면 탄 유닛도 함께 잃어요.' },
    // ── 군체 무리 (8–14): 생체 · 싸고 많음 · 재생
    { k: 'sw', nm: '일벌', cls: 'w', tag: 'light', hp: 38, ar: 0, dm: 5, ud: 0, rg: 0.3, cd: 1.2, sp: 2.8, si: 6, r: 0.34, c: [50, 0], sup: 1, bt: 12, from: 6, req: -1, aa: 0, ag: 1, bo: {}, d: '자원을 캐고 막 위에 건물을 키워요.' },
    { k: 'fg', nm: '송곳니', cls: 'i', tag: 'light', hp: 42, ar: 0, dm: 5, ud: 1, rg: 0.35, cd: 0.6, sp: 3.7, si: 7, r: 0.32, c: [40, 0], sup: 1, bt: 11, from: 8, req: -1, aa: 0, ag: 1, bo: { light: 1.2 }, fx: 'bite', d: '아주 싸고 빠른 근접 무리. 떼로 몰려 일꾼·포격 유닛을 물어뜯어요. 공중은 못 물어요.' },
    { k: 'sp', nm: '가시뿜이', cls: 'i', tag: 'light', hp: 75, ar: 0, dm: 9, ud: 1, rg: 5, cd: 1.0, sp: 2.6, si: 8, r: 0.4, c: [70, 10], sup: 2, bt: 19, from: 8, req: -1, aa: 1, ag: 1, bo: { air: 1.3 }, fx: 'spit', d: '가시를 뱉는 사격 생체. 땅·하늘 모두 쏘고 공중에 1.3배.' },
    { k: 'ab', nm: '산성 덩이', cls: 'i', tag: 'light', hp: 34, ar: 0, dm: 26, ud: 2, rg: 0.35, cd: 1, sp: 3.3, si: 7, r: 0.38, c: [25, 20], sup: 1, bt: 14, from: 8, req: 10, aa: 0, ag: 1, bo: { light: 1.45, bld: 1.4 }, spl: 1.7, boom: 1, fx: 'acid', d: '적에게 닿으면 터져 산성으로 주변을 녹여요(경보병 1.45배, 범위). 한 번 쓰면 사라져요.' },
    { k: 'cr', nm: '갑각 돌격수', cls: 'v', tag: 'armored', hp: 330, ar: 2, dm: 18, ud: 2, rg: 0.6, cd: 1.0, sp: 2.8, si: 8, r: 0.78, c: [225, 75], sup: 4, bt: 36, from: 9, req: 10, aa: 0, ag: 1, bo: { bld: 1.2 }, spl: 0.8, fx: 'bite', d: '두꺼운 갑각의 거대 근접 생체. 앞의 적을 휩쓸어요(범위). 공중은 못 쳐요.' },
    { k: 'sf', nm: '포자 비행체', cls: 'v', tag: 'air', air: 1, hp: 105, ar: 0, dm: 9, ud: 1, rg: 3.5, cd: 1.0, sp: 4.0, si: 10, r: 0.5, c: [100, 50], sup: 2, bt: 22, from: 9, req: -1, aa: 1, ag: 1, bo: { armored: 1.4 }, fx: 'spit', d: '날아다니는 포자 덩이. 땅·하늘을 쏘고 장갑에 1.4배.' },
    { k: 'bw', nm: '굴착 포격충', cls: 'v', tag: 'armored', hp: 125, ar: 1, dm: 21, ud: 2, rg: 9, mr: 2, cd: 2.6, sp: 2.0, si: 10, r: 0.62, c: [125, 75], sup: 3, bt: 30, from: 9, req: 10, aa: 0, ag: 1, bo: { light: 1.3, bld: 1.4 }, spl: 1.3, fx: 'glob', d: '산성 덩이를 멀리 쏘아 올리는 포격 생체(범위). 바로 앞(2칸)·하늘은 못 쏴요.' },
    // ── 성광 교단 (15–21): 비싸고 강함 · 보호막 · 관문 소환
    { k: 'ac2', nm: '사도', cls: 'w', tag: 'light', hp: 30, sh: 20, ar: 0, dm: 5, ud: 0, rg: 0.3, cd: 1.2, sp: 2.8, si: 6, r: 0.36, c: [50, 0], sup: 1, bt: 12, from: 12, req: -1, aa: 0, ag: 1, bo: {}, d: '자원을 캐고 건물을 소환해요(소환을 시작하면 바로 돌아가요).' },
    { k: 'kn', nm: '수호 기사', cls: 'i', tag: 'light', hp: 100, sh: 40, ar: 1, dm: 13, ud: 1, rg: 0.5, cd: 1.1, sp: 2.8, si: 8, r: 0.44, c: [90, 15], sup: 2, bt: 22, from: 14, req: -1, aa: 0, ag: 1, bo: { light: 1.3 }, spl: 0.7, fx: 'blade', d: '빛의 칼날을 든 근접 기사. 칼날이 옆의 적까지 베고(범위), 보호막과 갑옷으로 오래 버텨요. 공중은 못 쳐요.' },
    { k: 'ar2', nm: '빛살 궁수', cls: 'i', tag: 'light', hp: 55, sh: 35, ar: 0, dm: 9, ud: 1, rg: 5, cd: 1.0, sp: 2.5, si: 9, r: 0.4, c: [80, 35], sup: 2, bt: 22, from: 14, req: -1, aa: 1, ag: 1, bo: { air: 1.3 }, fx: 'ray', d: '빛살을 쏘는 사수. 땅·하늘 모두, 공중에 1.3배.' },
    { k: 'ph', nm: '환영 추적자', cls: 'v', tag: 'armored', hp: 80, sh: 35, ar: 1, dm: 10, ud: 1, rg: 4, cd: 0.9, sp: 4.1, si: 9, r: 0.5, c: [110, 50], sup: 2, bt: 26, from: 15, req: -1, aa: 0, ag: 1, bo: { light: 1.5 }, fx: 'ray', d: '빠른 부유 기병. 보병·일꾼을 사냥해요(경보병 1.5배). 공중은 못 쏴요.' },
    { k: 'jd', nm: '심판자', cls: 'v', tag: 'armored', hp: 150, sh: 70, ar: 1, dm: 30, ud: 3, rg: 7, cd: 2.2, sp: 2.0, si: 10, r: 0.7, c: [175, 100], sup: 4, bt: 38, from: 15, req: 16, aa: 0, ag: 1, bo: { armored: 1.6, bld: 1.2 }, fx: 'lance', d: '빛의 창을 꽂는 보행 병기. 장갑 1.6배. 공중은 못 쏴요.' },
    { k: 'sk', nm: '천공 수호선', cls: 'v', tag: 'air', air: 1, hp: 140, sh: 70, ar: 1, dm: 12, ud: 2, rg: 5, cd: 1.0, sp: 3.2, si: 11, r: 0.66, c: [175, 125], sup: 4, bt: 36, from: 15, req: 16, aa: 1, ag: 1, bo: { armored: 1.3, air: 1.2 }, fx: 'ray', d: '떠다니는 성채선. 땅·하늘 모두 쏘고 장갑·공중에 강해요.' },
    { k: 'cl', nm: '성흔 거상', cls: 'v', tag: 'armored', hp: 230, sh: 90, ar: 1, dm: 19, ud: 2, rg: 8, cd: 1.8, sp: 1.9, si: 10, r: 0.85, c: [250, 175], sup: 6, bt: 46, from: 15, req: 16, aa: 0, ag: 1, bo: { light: 1.5 }, spl: 1.4, fx: 'beam', d: '긴 다리의 거상. 빛줄기로 넓게 쓸어요(경보병 1.5배, 범위). 하늘에서 맞기 쉬워요.' },
    // ── 고철 유목민 (22–29): 이동식 기지 · 고철 회수 · 유닛 개조
    { k: 'sv', nm: '수거꾼', cls: 'w', tag: 'light', hp: 45, ar: 0, dm: 5, ud: 0, rg: 0.3, cd: 1.2, sp: 2.8, si: 6, r: 0.36, c: [50, 0], sup: 1, bt: 12, from: 18, req: -1, aa: 0, ag: 1, bo: {}, d: '자원을 캐고 건물을 짓는 수거꾼.' },
    { k: 'sg', nm: '고철 사수', cls: 'i', tag: 'light', hp: 55, ar: 0, dm: 7, ud: 1, rg: 5, cd: 0.85, sp: 2.5, si: 8, r: 0.36, c: [50, 0], sup: 1, bt: 15, from: 20, req: -1, aa: 1, ag: 1, bo: { air: 1.3 }, d: '고철 총을 든 기본 보병. 공중도 쏘고 1.3배.' },
    { k: 'bk', nm: '불꽃 바이크', cls: 'v', tag: 'light', hp: 90, ar: 0, dm: 7, ud: 1, rg: 2, cd: 0.8, sp: 4.4, si: 8, r: 0.5, c: [75, 25], sup: 2, bt: 18, from: 20, req: -1, aa: 0, ag: 1, bo: { light: 1.45 }, spl: 0.9, fx: 'flame', d: '불을 뿜는 빠른 바이크. 보병 무리·일꾼에 1.45배(범위). 공중은 못 쏴요.' },
    { k: 'hp', nm: '작살 포수', cls: 'i', tag: 'light', hp: 60, ar: 0, dm: 18, ud: 2, rg: 7, cd: 1.8, sp: 2.4, si: 9, r: 0.38, c: [75, 50], sup: 2, bt: 22, from: 20, req: 22, aa: 1, ag: 1, bo: { armored: 1.6 }, fx: 'snipe', d: '쇠사슬 작살로 장갑·비행체를 꿰뚫어요(장갑 1.6배). 땅·하늘 모두.' },
    { k: 'gl', nm: '고철 거신', cls: 'v', tag: 'armored', hp: 280, ar: 2, dm: 12, ud: 2, rg: 1.5, cd: 1.0, sp: 2.2, si: 8, r: 0.8, c: [175, 75], sup: 4, bt: 34, from: 21, req: -1, aa: 0, ag: 1, bo: { bld: 1.5 }, spl: 0.8, fx: 'bite', d: '고철을 이어 붙인 거대 보행기. 앞을 휩쓸고 건물에 1.5배. 공중은 못 쳐요.' },
    { k: 'mt', nm: '박격 트럭', cls: 'v', tag: 'armored', hp: 140, ar: 1, dm: 24, ud: 3, rg: 9, mr: 2.5, cd: 2.8, sp: 2.0, si: 10, r: 0.66, c: [150, 75], sup: 3, bt: 30, from: 21, req: 22, aa: 0, ag: 1, bo: { light: 1.3, bld: 1.4 }, spl: 1.5, fx: 'shell', d: '박격포를 실은 트럭(범위). 바로 앞(2.5칸)·하늘은 못 쏴요.' },
    { k: 'zp', nm: '연 비행선', cls: 'v', tag: 'air', air: 1, hp: 180, ar: 1, dm: 10, ud: 1, rg: 4.5, cd: 1.1, sp: 2.6, si: 11, r: 0.66, c: [150, 100], sup: 3, bt: 28, from: 21, req: 22, aa: 1, ag: 1, bo: { armored: 1.5 }, d: '천을 기운 비행선. 땅·하늘 모두 쏘고 장갑에 1.5배.' },
    { k: 'mb', nm: '이동 본부', cls: 'v', tag: 'armored', hp: 1500, ar: 2, dm: 0, ud: 0, rg: 0, cd: 1, sp: 1.6, si: 10, r: 1.5, c: [300, 0], sup: 0, bt: 0, from: 18, req: -1, aa: 0, ag: 0, bo: {}, mb: 1, d: '접은 본부. 천천히 굴러가다가 어디든 빈 땅에 다시 펼쳐요(⛺펼치기).' },
    // ── 영웅 (30–33): 진영마다 1명 · 본부에서 부름 · 한 번에 한 명
    { k: 'h0', nm: '강습 사령관', cls: 'h', tag: 'armored', hero: 1, hf: 0, hp: 430, ar: 2, dm: 15, ud: 0, rg: 6, cd: 0.9, sp: 2.9, si: 11, r: 0.56, c: [200, 100], sup: 3, bt: 30, from: 0, req: 2, aa: 1, ag: 1, bo: {}, fx: 'line' },
    { k: 'h1', nm: '무리 여왕', cls: 'h', tag: 'armored', hero: 1, hf: 1, hp: 420, ar: 1, dm: 12, ud: 0, rg: 4.5, cd: 0.8, sp: 3.1, si: 10, r: 0.6, c: [200, 100], sup: 3, bt: 30, from: 6, req: 8, aa: 1, ag: 1, bo: { armored: 1.2 }, fx: 'spit' },
    { k: 'h2', nm: '빛의 집행관', cls: 'h', tag: 'armored', hero: 1, hf: 2, hp: 300, sh: 200, ar: 1, dm: 22, ud: 0, rg: 1.0, cd: 1.1, sp: 3.2, si: 10, r: 0.56, c: [200, 100], sup: 3, bt: 30, from: 12, req: 14, aa: 0, ag: 1, bo: { light: 1.2 }, spl: 1.0, fx: 'blade' },
    { k: 'h3', nm: '잔해 군벌', cls: 'h', tag: 'armored', hero: 1, hf: 3, hp: 600, ar: 2, dm: 13, ud: 0, rg: 2.5, cd: 0.9, sp: 2.9, si: 10, r: 0.62, c: [200, 100], sup: 3, bt: 30, from: 18, req: 20, aa: 0, ag: 1, bo: { light: 1.3 }, spl: 1.0, fx: 'flame' },
  ];
  // 영웅: 오라(지나가며 늘 켜짐) + 기술(버튼, 재사용 대기) · 죽으면 HERO_RE초 뒤 다시 부를 수 있어요
  const HERO0 = 30, HERO_RE = 60, AURA = 6;
  const HS = [
    { nm: '포격 요청', ic: '💥', cd: 35, dm: 80, rad: 2.5, rg: 10, d: '사거리 10 안 가장 가까운 적(지금 노리는 적 우선) 자리에 포탄 세 발 — 반경 2.5에 80 피해(건물은 절반)', au: '지휘 오라: 6칸 안 아군의 공격 +20%' },
    { nm: '산란', ic: '🥚', cd: 40, n: 3, life: 20, d: '송곳니 3마리를 곁에 낳아요(보급을 안 먹고 20초 뒤 사라져요)', au: '재생 오라: 6칸 안 아군이 싸우는 중에도 초당 2씩 나아요' },
    { nm: '성역의 빛', ic: '✨', cd: 35, rad: 6, d: '6칸 안 아군의 보호막을 가득 채워요(보호막이 없는 아군은 체력 30 회복)', au: '빛의 오라: 6칸 안 아군의 보호막이 싸우는 중에도 초당 3씩 차올라요' },
    { nm: '과열 돌격', ic: '🔥', cd: 35, rad: 6, life: 8, d: '6칸 안 아군의 공격 속도가 8초 동안 1.6배', au: '현장 수리: 6칸 안 아군 유닛이 초당 3씩 고쳐져요' },
  ];
  // per-unit defaults: fx (shot look), worker flag, faction
  UN.forEach((D, t) => { D.fa = D.hero ? D.hf : t < 8 ? 0 : t < 15 ? 1 : t < 22 ? 2 : 3; if (D.hero) D.d = '진영 영웅 — 한 번에 한 명, 본부에서 불러요. 쓰러지면 ' + HERO_RE + '초 뒤 다시 부를 수 있어요.\n' + HS[D.hf].au + '.\n기술 ' + HS[D.hf].ic + HS[D.hf].nm + '(재사용 ' + HS[D.hf].cd + '초): ' + HS[D.hf].d + '.'; D.w = D.cls === 'w' ? 1 : 0; if (!D.fx) D.fx = ['', 'line', 'flame', 'snipe', 'line', 'shell', 'drone', ''][t] || (D.w ? '' : 'line'); D.sh = D.sh || 0; });
  const TP = 7, CAP = 4, MB = 29;
  const seatOf = (t) => { const D = UN[t]; return D.air ? 0 : D.cls === 'v' ? CAP : 1; }; // 수송기 자리 수
  const BD = [
    { k: 'hq', nm: '본부', sz: 4, hp: 1500, ar: 1, c: [400, 0], bt: 60, si: 10, sup: 10, req: -1, tr: [0], d: '일꾼을 뽑고, 캔 자원을 받는 곳. 보급 +10. 기지 자리(바닥의 원)에만 지어요.' },
    { k: 'sd', nm: '보급고', sz: 2, hp: 400, ar: 1, c: [100, 0], bt: 22, si: 6, sup: 8, req: -1, d: '보급 한도 +8 (최대 100). 유닛마다 보급을 차지해요.' },
    { k: 'br', nm: '병영', sz: 3, hp: 1000, ar: 1, c: [150, 0], bt: 40, si: 7, req: -1, tr: [1, 2, 3], d: '소총병·화염병·저격수(연구소 필요)를 훈련해요.' },
    { k: 'fc', nm: '공장', sz: 3, hp: 1200, ar: 1, c: [150, 100], bt: 45, si: 7, req: 2, tr: [4, 5, 6, 7], d: '경장갑차·포격 전차·정찰 드론·수송기(전차·드론·수송기는 연구소 필요). 병영이 있어야 지어요.' },
    { k: 'lb', nm: '연구소', sz: 3, hp: 750, ar: 1, c: [125, 75], bt: 35, si: 7, req: 2, rs: [0, 1, 2, 3], d: '무기·방어 강화를 연구하고 저격수·포격 전차·드론을 열어요. 병영이 있어야 지어요.' },
    { k: 'tw', nm: '포탑', sz: 2, hp: 400, ar: 1, c: [100, 0], bt: 25, si: 9, req: 2, wpn: { dm: 9, ud: 0, rg: 7, cd: 0.8, aa: 1, ag: 1, bo: { air: 1.3 }, cls: 'b' }, d: '땅과 하늘을 모두 쏘는 방어 탑(사거리 7). 병영이 있어야 지어요.' },
    // ── 군체 무리 (6–11): 막(크립) 위에만 건물 · 재생
    { k: 'nest', nm: '둥지', sz: 4, hp: 1400, ar: 1, c: [400, 0], bt: 55, si: 10, sup: 10, req: -1, tr: [8], crp: 9, d: '일벌을 낳고 자원을 받는 둥지. 보급 +10, 주변(9칸)에 막을 깔아요. 기지 자리에만.' },
    { k: 'egg', nm: '알집', sz: 2, hp: 350, ar: 1, c: [100, 0], bt: 18, si: 6, sup: 8, req: -1, crp: 7, d: '보급 +8. 다 자라면 주변 7칸에 막을 퍼뜨려요 — 막을 넓히는 유일한 방법.' },
    { k: 'pool', nm: '산란못', sz: 3, hp: 850, ar: 1, c: [150, 0], bt: 34, si: 7, req: -1, tr: [9, 10, 11], d: '송곳니·가시뿜이·산성 덩이(진화굴 필요)를 낳아요.' },
    { k: 'coc', nm: '거대 고치', sz: 3, hp: 1000, ar: 1, c: [125, 100], bt: 42, si: 7, req: 8, tr: [12, 13, 14], d: '갑각 돌격수·포자 비행체·굴착 포격충을 길러요(돌격수·포격충은 진화굴 필요). 산란못이 있어야 해요.' },
    { k: 'evo', nm: '진화굴', sz: 3, hp: 700, ar: 1, c: [100, 75], bt: 34, si: 7, req: 8, rs: 1, d: '생체 강화를 연구하고 산성 덩이·돌격수·포격충을 열어요. 산란못이 있어야 해요.' },
    { k: 'spn', nm: '가시 촉수', sz: 2, hp: 380, ar: 1, c: [75, 0], bt: 22, si: 9, req: 8, crp: 4, wpn: { dm: 8, ud: 0, rg: 6.5, cd: 0.8, aa: 1, ag: 1, bo: { air: 1.3 }, cls: 'b' }, d: '땅·하늘을 찌르는 방어 촉수(사거리 6.5). 산란못이 있어야 해요.' },
    // ── 성광 교단 (12–17): 빛의 장 안에 소환 · 보호막
    { k: 'sanc', nm: '성좌', sz: 4, hp: 1000, sh: 600, ar: 1, c: [400, 0], bt: 60, si: 10, sup: 10, req: -1, tr: [15], pw: 8, d: '사도를 부르고 자원을 받는 성좌. 보급 +10, 주변 8칸에 빛의 장. 기지 자리에만.' },
    { k: 'pil', nm: '빛기둥', sz: 2, hp: 250, sh: 200, ar: 1, c: [75, 25], bt: 20, si: 7, sup: 8, req: -1, pw: 7, d: '보급 +8, 주변 7칸에 빛의 장(다른 건물은 장 안에만). 새 유닛이 집결지에서 가장 가까운 빛기둥으로 순간이동해 와요.' },
    { k: 'hall', nm: '수련원', sz: 3, hp: 600, sh: 450, ar: 1, c: [150, 0], bt: 40, si: 7, req: -1, tr: [16, 17], d: '수호 기사·빛살 궁수를 불러요.' },
    { k: 'forge', nm: '제련 성채', sz: 3, hp: 700, sh: 500, ar: 1, c: [150, 100], bt: 45, si: 7, req: 14, tr: [18, 19, 20, 21], d: '환영 추적자·심판자·천공 수호선·성흔 거상(뒤의 셋은 기록 보관소 필요). 수련원이 있어야 해요.' },
    { k: 'arch', nm: '기록 보관소', sz: 3, hp: 500, sh: 400, ar: 1, c: [125, 100], bt: 35, si: 7, req: 14, rs: 1, d: '빛의 강화를 연구하고 고급 유닛을 열어요. 수련원이 있어야 해요.' },
    { k: 'obs', nm: '빛의 감시탑', sz: 2, hp: 250, sh: 250, ar: 1, c: [125, 25], bt: 25, si: 9, req: 14, wpn: { dm: 12, ud: 0, rg: 7, cd: 1.0, aa: 1, ag: 1, bo: { air: 1.2 }, cls: 'b' }, d: '땅·하늘을 쏘는 빛의 탑(사거리 7). 수련원이 있어야 해요.' },
    // ── 고철 유목민 (18–23): 이동 본부 · 고철 회수 · 개조
    { k: 'camp', nm: '이동 본부', sz: 4, hp: 1500, ar: 2, c: [300, 0], bt: 60, si: 10, sup: 10, req: -1, tr: [22], any: 1, pk: 1, d: '수거꾼을 뽑고 자원을 받아요. 보급 +10. 기지 자리가 아니어도 빈 땅이면 어디든 지어요. ⛺접기로 바퀴를 달고 옮길 수 있어요.' },
    { k: 'furn', nm: '고철 용광로', sz: 2, hp: 450, ar: 1, c: [100, 0], bt: 22, si: 7, sup: 8, req: -1, rec: 8, d: '보급 +8. 주변 8칸의 잔해(어느 편이든 부서진 기계 유닛)를 끌어와 광석(값의 {WR})으로 녹여요.' },
    { k: 'tent', nm: '천막 막사', sz: 3, hp: 950, ar: 1, c: [125, 0], bt: 38, si: 7, req: -1, tr: [23, 24, 25], d: '고철 사수·불꽃 바이크·작살 포수(정비소 필요).' },
    { k: 'yard', nm: '조립장', sz: 3, hp: 1150, ar: 1, c: [150, 75], bt: 44, si: 7, req: 20, tr: [26, 27, 28], d: '고철 거신·박격 트럭·연 비행선(트럭·비행선은 정비소 필요). 천막 막사가 있어야 해요.' },
    { k: 'shop', nm: '정비소', sz: 3, hp: 750, ar: 1, c: [125, 50], bt: 35, si: 7, req: 20, rs: 1, mod: 7, d: '강화를 연구하고 고급 유닛을 열어요. 근처(7칸) 유닛을 하나씩 개조({MOD})해요.' },
    { k: 'nest2', nm: '고철 망루', sz: 2, hp: 450, ar: 1, c: [100, 0], bt: 25, si: 9, req: 20, wpn: { dm: 9, ud: 0, rg: 7, cd: 0.85, aa: 1, ag: 1, bo: { air: 1.3 }, cls: 'b' }, d: '땅·하늘을 쏘는 고철 망루(사거리 7). 천막 막사가 있어야 해요.' },
  ];
  BD.forEach((B, t) => { B.fa = t < 6 ? 0 : t < 12 ? 1 : t < 18 ? 2 : 3; B.ro = t % 6; B.hq = B.ro === 0 ? 1 : 0; B.sh = B.sh || 0; if (B.rs) B.rs = [0, 1, 2, 3]; });
  // 진영: 건물 [본부, 보급, 병영, 공장, 연구, 포탑] · 일꾼
  const FAC = [
    { nm: '철강 연합', sh: '철강', c: '#9fb2c4', pl: '#3b3746', b: [0, 1, 2, 3, 4, 5], w: 0, d: '균형 잡힌 보병·차량. 포탑·연구가 탄탄하고, 수송기로 절벽 너머를 기습해요.', sig: '수송기 강습 · 튼튼한 포탑' },
    { nm: '군체 무리', sh: '군체', c: '#b46ad0', pl: '#4a2f45', b: [6, 7, 8, 9, 10, 11], w: 8, d: '싸고 많은 생체 유닛. 모든 유닛·건물이 3초만 안 맞아도 스스로 낫고, 적을 쓰러뜨리면 생체를 흡수해 광석을 얻어요. 건물은 막 위에만 — 알집으로 막을 퍼뜨려요.', sig: '막 · 재생 · 생체 흡수' },
    { nm: '성광 교단', sh: '성광', c: '#f0d27a', pl: '#4d4a63', b: [12, 13, 14, 15, 16, 17], w: 15, d: '비싸고 강한 유닛과 다시 차오르는 보호막. 건물은 빛의 장 안에 소환되고 혼자 완성돼요. 새 유닛은 집결지 근처 빛기둥으로 순간이동. 수정을 더 많이 캐요.', sig: '보호막 · 관문 소환 · 수정 정화' },
    { nm: '고철 유목민', sh: '고철', c: '#d0874a', pl: '#4f4033', b: [18, 19, 20, 21, 22, 23], w: 22, d: '본부를 접어 옮기고 어디든 펼쳐요. 부서진 기계 유닛(어느 편이든)의 잔해를 녹여 광석으로 되살리고, 유닛을 하나씩 개조해요.', sig: '이동 본부 · 고철 회수 · 개조' },
  ];
  const facOf = (W, o) => (W.fa ? W.fa[o] | 0 : 0);
  const MOD = { hp: 1.25, dm: 1.15, c: 0.5 }, WRECK = 0.2, ABSORB = 0.1; // 고철 개조 · 잔해 · 군체 생체 흡수
  const MODT = '체력 ×' + MOD.hp + ' · 공격 ×' + MOD.dm + ', 값의 ' + Math.round(MOD.c * 100) + '%', WRT = Math.round(WRECK * 100) + '%', ABT = Math.round(ABSORB * 100) + '%';
  BD.forEach((B) => { B.d = B.d.replace('{MOD}', MODT).replace('{WR}', WRT); });
  const isW = (t) => UN[t].w === 1;
  // 진영별 건설 조건: 군체 = 막 위, 성광 = 빛의 장 안 (bl: buildings with t,o,x,y,done)
  function facPlace(bl, o, bt, tx, ty) {
    const B = BD[bt], sz = B.sz;
    if (B.hq) return true;
    if (B.fa === 1) {
      const src = []; for (const b of bl) if (!b.dead && b.o === o && BD[b.t].crp && (b.done || BD[b.t].hq)) src.push(b);
      for (let y = ty; y < ty + sz; y++) for (let x = tx; x < tx + sz; x++) { if (!src.some((b) => hyp(b.x - x - 0.5, b.y - y - 0.5) <= BD[b.t].crp)) return false; }
      return true;
    }
    if (B.fa === 2 && !B.pw) { const cx = tx + sz / 2, cy = ty + sz / 2; for (const b of bl) if (!b.dead && b.o === o && BD[b.t].pw && b.done && hyp(b.x - cx, b.y - cy) <= BD[b.t].pw) return true; return false; }
    return true;
  }
  const UPGF = [[
    { nm: '보병 화력', ic: '🔫', c: [[100, 100], [175, 175]], tm: [55, 75], d: '소총병·화염병 공격 +1, 저격수 +2 (단계마다)' },
    { nm: '차량 화력', ic: '💥', c: [[100, 100], [175, 175]], tm: [55, 75], d: '장갑차·드론 공격 +1, 포격 전차 +3 (단계마다)' },
    { nm: '보병 방어', ic: '🦺', c: [[100, 100], [175, 175]], tm: [55, 75], d: '보병 방어 +1 (단계마다, 받는 피해 1씩 줄어요)' },
    { nm: '차량 장갑', ic: '🛡️', c: [[100, 100], [175, 175]], tm: [55, 75], d: '장갑차·전차·드론 방어 +1 (단계마다)' },
  ], [
    { nm: '송곳 강화', ic: '🦷', c: [[100, 100], [175, 175]], tm: [50, 70], d: '송곳니·가시뿜이 공격 +1, 산성 덩이 +2 (단계마다)' },
    { nm: '거대체 강화', ic: '🦂', c: [[100, 100], [175, 175]], tm: [55, 75], d: '돌격수·포격충 공격 +2, 비행체 +1 (단계마다)' },
    { nm: '외피 경화', ic: '🐚', c: [[100, 100], [175, 175]], tm: [50, 70], d: '작은 생체 방어 +1 (단계마다)' },
    { nm: '갑각 경화', ic: '🪲', c: [[100, 100], [175, 175]], tm: [55, 75], d: '돌격수·비행체·포격충 방어 +1 (단계마다)' },
  ], [
    { nm: '빛날 연마', ic: '⚔️', c: [[100, 100], [175, 175]], tm: [55, 75], d: '기사·궁수 공격 +1 (단계마다)' },
    { nm: '병기 출력', ic: '🔆', c: [[125, 125], [200, 200]], tm: [60, 80], d: '추적자 +1, 수호선·거상 +2, 심판자 +3 (단계마다)' },
    { nm: '보병 축복', ic: '💠', c: [[100, 100], [175, 175]], tm: [55, 75], d: '기사·궁수 방어 +1 (단계마다)' },
    { nm: '병기 축복', ic: '🔷', c: [[125, 125], [200, 200]], tm: [60, 80], d: '추적자·심판자·수호선·거상 방어 +1 (단계마다)' },
  ], [
    { nm: '개량 탄약', ic: '🔩', c: [[100, 100], [175, 175]], tm: [55, 75], d: '사수 +1, 작살 포수 +2 (단계마다)' },
    { nm: '대구경', ic: '🧨', c: [[100, 100], [175, 175]], tm: [55, 75], d: '바이크·비행선 +1, 거신 +2, 박격 트럭 +3 (단계마다)' },
    { nm: '덧댄 철판', ic: '🧱', c: [[100, 100], [175, 175]], tm: [55, 75], d: '보병 방어 +1 (단계마다)' },
    { nm: '강판 용접', ic: '⚙️', c: [[100, 100], [175, 175]], tm: [55, 75], d: '바이크·거신·트럭·비행선 방어 +1 (단계마다)' },
  ]];
  const UPG = UPGF[0];
  const upgOf = (fa, v) => UPGF[fa][v];
  const MINE = [{ t: 2.4, c: 5 }, { t: 2.8, c: 4 }];
  const NODE_A = [1000, 900];
  const BUSH_RV = 3, HIGH_RG = 1, UPHILL_MISS = 0.2; // 지형: 수풀에서 쏘거나 맞으면 3초 드러남 · 고지 사거리 +1 · 올려 쏘기 빗나감 20%
  const ORE = '#e6a94f', CRY = '#7fe4f5';
  const THEMES = [
    { nm: '황야', lo: ['#6b5a3e', '#625237'], hi: ['#8d7854', '#82704d'], rk: ['#3a322b', '#2a241f'], rp: '#7c6847', ed: '#2b231b' },
    { nm: '설원', lo: ['#939fac', '#8a97a4'], hi: ['#e2e8ee', '#d6dee6'], rk: ['#56606a', '#434b54'], rp: '#c4ccd5', ed: '#4f5963' },
    { nm: '초원', lo: ['#4a6b38', '#436234'], hi: ['#6c8b49', '#638143'], rk: ['#3e4540', '#2d322e'], rp: '#6e6b48', ed: '#26301f' },
    { nm: '화산', lo: ['#3f3331', '#382d2b'], hi: ['#5d4842', '#54413b'], rk: ['#1f1817', '#151010'], rp: '#4f3d35', ed: '#110b0a' },
  ];
  const TAGNM = { light: '경보병·일꾼', armored: '장갑', air: '공중', bld: '건물' };

  /* ---------------- map generation (deterministic from seed) ---------------- */
  function teamsOf(n, team) { return n === 4 && team ? [0, 0, 1, 1] : Array.from({ length: n }, (_, i) => i); }
  function genMap(st) {
    const R = rng(st.sd), n = st.n, four = n >= 3, S = four ? 80 : 64, N = S * S;
    const ter = new Uint8Array(N), prot = new Uint8Array(N), mesas = []; // ter: 0 low, 1 high, 2 ramp, 3 rock, 4 bush, 5 water, 6 bridge
    const syms = four ? [[0, 0], [1, 0], [0, 1], [1, 1]] : [[0, 0], [1, 1]];
    const swap = R() < 0.5;
    const P = (x, y) => (swap ? [y, x] : [x, y]);
    const inb = (x, y) => x >= 0 && y >= 0 && x < S && y < S;
    const each = (x, y, fn) => { for (const s of syms) { const X = s[0] ? S - 1 - x : x, Y = s[1] ? S - 1 - y : y; if (inb(X, Y)) fn(Y * S + X); } };
    const setP = (px, py, fn) => { const x = Math.floor(px), y = Math.floor(py); if (inb(x, y)) each(x, y, fn); };
    function disc(px, py, r, fn) {
      for (let y = Math.floor(py - r - 1); y <= py + r + 1; y++) for (let x = Math.floor(px - r - 1); x <= px + r + 1; x++) {
        const d = hyp(x + 0.5 - px, y + 0.5 - py); if (d <= r && inb(x, y)) each(x, y, (c) => fn(c, d));
      }
    }
    const fs = [{ x: 11, y: 11, sp: 1 }];
    if (!four) for (const a of [P(12, 30), P(11, 53), P(26, 41)]) fs.push({ x: a[0], y: a[1] });
    else for (const a of [P(12, 29), P(40, 11)]) fs.push({ x: a[0], y: a[1] });
    const sites = [];
    for (const f of fs) for (const s of syms) { const x = s[0] ? S - f.x : f.x, y = s[1] ? S - f.y : f.y; if (!sites.some((q) => q.x === x && q.y === y)) sites.push({ x, y, sp: f.sp ? 1 : 0 }); }
    for (const q of sites) disc(q.x, q.y, q.sp ? 11.5 : 7.5, (c) => { prot[c] = 1; });
    const blob = (x, y, r) => disc(x, y, r, (c) => { if (!prot[c]) ter[c] = 3; });
    for (let i = 0; i < (four ? 7 : 9); i++) blob(3 + R() * (S - 6), 3 + R() * (S - 6), 1.3 + R() * 2.3);
    for (let i = 0; i < 3; i++) { const x = 6 + R() * (S - 12), y = 6 + R() * (S - 12), a = R() * 6.283, len = 6 + R() * 7; for (let k = 0; k < len; k += 0.7) blob(x + Math.cos(a) * k, y + Math.sin(a) * k, 0.95); }
    // high-ground watch mesas with two ramps
    for (let i = 0, tries = 0; i < (four ? 1 : 2) && tries < 60; tries++) {
      const x = 8 + R() * (S - 16), y = 8 + R() * (S - 16), r = 2.4 + R() * 1.2;
      if (sites.some((q) => hyp(q.x - x, q.y - y) < r + (q.sp ? 15 : 9))) continue;
      if (syms.some((s) => (s[0] || s[1]) && hyp((s[0] ? S - x : x) - x, (s[1] ? S - y : y) - y) < 2 * r + 5)) continue;
      disc(x, y, r + 1.1, (c, d) => { ter[c] = d <= r ? 1 : 3; });
      for (const s of syms) mesas.push([s[0] ? S - x : x, s[1] ? S - y : y]);
      const a = R() * 6.283;
      for (const aa of [a, a + Math.PI]) for (let t = r - 0.5; t <= r + 1.7; t += 0.25) for (let w = -1; w <= 1; w += 0.25) setP(x + Math.cos(aa) * t - Math.sin(aa) * w, y + Math.sin(aa) * t + Math.cos(aa) * w, (c) => { if (ter[c] === 3) ter[c] = 2; });
      i++;
    }
    // main base plateau + ramp toward the centre
    const s0 = fs[0], cx = S / 2, cy = S / 2;
    disc(s0.x, s0.y, 10.6, (c, d) => { ter[c] = d <= 9 ? 1 : 3; });
    { const dl = hyp(cx - s0.x, cy - s0.y), dx = (cx - s0.x) / dl, dy = (cy - s0.y) / dl;
      for (let t = 8.2; t <= 11.4; t += 0.25) for (let w = -1.6; w <= 1.6; w += 0.25) setP(s0.x + dx * t - dy * w, s0.y + dy * t + dx * w, (c) => { ter[c] = 2; });
      for (let t = 11.4; t <= 17; t += 0.3) for (let w = -1.9; w <= 1.9; w += 0.3) setP(s0.x + dx * t - dy * w, s0.y + dy * t + dx * w, (c) => { if (ter[c] === 3) ter[c] = 0; }); }
    for (const f of fs) if (!f.sp) disc(f.x, f.y, 6.5, (c) => { if (ter[c] === 3) ter[c] = 0; });
    // creeks with a narrow bridge in the middle (mirrored like everything else) — 다리 = 길목
    const creek = (x, y, a, len) => { const dx = Math.cos(a), dy = Math.sin(a);
      for (let t = -len / 2; t <= len / 2; t += 0.3) disc(x + dx * t, y + dy * t, 1.15, (c) => { if (ter[c] !== 0 && ter[c] !== 4) return; ter[c] = Math.abs(t) < 1.2 ? 6 : 5; }); };
    const farSite = (x, y, r) => !sites.some((q) => hyp(q.x - x, q.y - y) < (q.sp ? 15 : 9) + r);
    if (!four) creek(cx, cy, -Math.PI / 4 + (swap ? 0 : 0), 16);
    for (let i = 0, tries = 0; i < 2 && tries < 60; tries++) {
      const x = 8 + R() * (S - 16), y = 8 + R() * (S - 16), len = 9 + R() * 4;
      if (!farSite(x, y, len / 2 - 2) || hyp(x - cx, y - cy) < 12) continue;
      creek(x, y, R() * Math.PI, len); i++;
    }
    // bush patches (hide units inside)
    for (let i = 0, tries = 0; i < (four ? 6 : 7) && tries < 80; tries++) {
      const x = 5 + R() * (S - 10), y = 5 + R() * (S - 10), r = 1.2 + R() * 1.1;
      if (sites.some((q) => hyp(q.x - x, q.y - y) < (q.sp ? 13 : 8))) continue;
      disc(x, y, r, (c) => { if (ter[c] === 0) ter[c] = 4; }); i++;
    }
    for (let i = 0; i < S; i++) { ter[i] = ter[(S - 1) * S + i] = ter[i * S] = ter[i * S + S - 1] = 3; }
    // resource fields behind each site (away from the centre)
    const nodes = [], nodeCell = new Map();
    for (const f of fs) {
      let ax = f.x - cx, ay = f.y - cy; const al = hyp(ax, ay) || 1; ax /= al; ay /= al;
      const base = Math.atan2(ay, ax), list = [];
      for (let k = -3; k <= 3; k++) list.push([base + k * 0.27, 6.3, 0]);
      list.push([base - 1.22, 5.6, 1], [base + 1.22, 5.6, 1]);
      for (const [a, r, k] of list) {
        const x0 = Math.floor(f.x + Math.cos(a) * r), y0 = Math.floor(f.y + Math.sin(a) * r);
        for (const s of syms) {
          const X = s[0] ? S - 1 - x0 : x0, Y = s[1] ? S - 1 - y0 : y0;
          if (X < 1 || Y < 1 || X > S - 2 || Y > S - 2) continue;
          const c = Y * S + X; if (nodeCell.has(c)) continue;
          nodeCell.set(c, nodes.length); nodes.push({ x: X + 0.5, y: Y + 0.5, c, k, a: NODE_A[k] });
          if (ter[c] >= 2) ter[c] = f.sp ? 1 : 0;
        }
      }
    }
    // connectivity: everything must be reachable from the first main base
    const passable = (c) => ter[c] !== 3 && ter[c] !== 5 && !nodeCell.has(c);
    let seen = null;
    const flood = () => {
      seen = new Uint8Array(N); const q = [s0.y * S + s0.x]; seen[q[0]] = 1;
      while (q.length) { const c = q.pop(), x = c % S, y = (c - x) / S; for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const nx = x + dx, ny = y + dy; if (!inb(nx, ny)) continue; const nc = ny * S + nx; if (!seen[nc] && passable(nc)) { seen[nc] = 1; q.push(nc); } } }
    };
    for (let it = 0; it < 5; it++) {
      flood();
      const bad = fs.filter((f) => !seen[f.y * S + f.x]);
      if (!bad.length) break;
      for (const f of bad) { const dl = hyp(cx - f.x, cy - f.y) || 1; for (let t = 0; t < dl; t += 0.4) disc(f.x + (cx - f.x) * t / dl, f.y + (cy - f.y) * t / dl, 1.5, (c) => { if (ter[c] === 3) ter[c] = 0; else if (ter[c] === 5) ter[c] = 6; }); }
    }
    flood();
    for (let c = 0; c < N; c++) if (!seen[c] && passable(c) && ter[c] !== 6) ter[c] = 3;
    for (let c = 0; c < N; c++) if (ter[c] === 6 && !seen[c]) ter[c] = 5;
    const h = new Uint8Array(N), pass = new Uint8Array(N);
    for (let c = 0; c < N; c++) { h[c] = ter[c] === 1 ? 1 : 0; pass[c] = ter[c] !== 3 && ter[c] !== 5 ? 1 : 0; }
    const sps = sites.filter((q) => q.sp);
    let order;
    if (n === 2) order = R() < 0.5 ? [0, 1] : [1, 0];
    else if (n === 4 && st.team) { order = R() < 0.5 ? [0, 1, 2, 3] : [0, 2, 1, 3]; if (R() < 0.5) order = [order[2], order[3], order[0], order[1]]; }
    else { order = [0, 1, 2, 3]; for (let i = 3; i > 0; i--) { const j = Math.floor(R() * (i + 1)); const t = order[i]; order[i] = order[j]; order[j] = t; } order = order.slice(0, n); }
    return { S, N, ter, h, pass, sites, nodes, nodeCell, spawn: order.map((i) => sps[i]), th: THEMES[st.th] || THEMES[0], tm: teamsOf(n, st.team), four, mesas };
  }

  /* ---------------- world ---------------- */
  const cellOf = (W, x, y) => (y | 0) * W.S + (x | 0);
  const passC = (W, c) => W.map.pass[c] === 1 && W.occ[c] === 0 && W.nodeAt[c] < 0;
  const alive = (e) => e && !e.dead;
  function wst(st) { return st && st.sh ? Object.assign({}, st, { n: 2, team: 0 }) : st; } // 공동 진영: 2 factions, seats 0·1 → faction 0, seats 2·3 → faction 1
  function newWorld(st0) {
    const st = wst(st0), map = genMap(st), S = map.S, N = S * S;
    const W = {
      st, map, S, N, n: st.n, tm: map.tm, nt: Math.max.apply(null, map.tm) + 1, t: 0, nid: 1, E: new Map(), units: [], blds: [], dead: [],
      nodes: map.nodes.map((q) => ({ x: q.x, y: q.y, c: q.c, k: q.k, a: q.a, m: q.a, busy: 0 })),
      occ: new Int32Array(N), nodeAt: new Int16Array(N).fill(-1), fc: new Map(), fb: 0, vis: [], ex: [], vt: 0, et: 0,
      ev: [], evq: 0, pl: [], BS: Math.ceil(S / 4), bk: [], over: null,
      fa: Array.from({ length: st.n }, (_, i) => (Array.isArray(st.fa) && FAC[st.fa[i]] ? st.fa[i] | 0 : 0)), wr: [], wrT: 0, wid: 0,
    };
    W.nomad = W.fa.includes(3);
    W.nodes.forEach((q, i) => { W.nodeAt[q.c] = i; });
    for (let i = 0; i < W.BS * W.BS; i++) W.bk.push([]);
    for (let t = 0; t < W.nt; t++) { W.vis.push(new Uint8Array(N)); W.ex.push(new Uint8Array(N)); }
    for (let s = 0; s < W.n; s++) {
      W.pl.push({ ore: 50, cry: 0, cap: 0, used: 0, up: [0, 0, 0, 0], alive: true, k: 0, lost: 0, mk: 0, mined: 0, sx: 0, hk: 0, hc: 0 });
      const sp = map.spawn[s], F = FAC[W.fa[s]];
      addB(W, F.b[0], s, sp.x - 2, sp.y - 2, true);
      let ax = sp.x - S / 2, ay = sp.y - S / 2; const al = hyp(ax, ay) || 1; ax /= al; ay /= al;
      for (let i = 0; i < 5; i++) {
        const w = (i - 2) * 0.8, u = addU(W, F.w, s, sp.x + ax * 2.9 - ay * w, sp.y + ay * 2.9 + ax * w);
        const nd = bestNode(W, s, sp.x, sp.y, 10); if (nd >= 0) { u.s = 'g'; u.nd = nd; u.gs = 0; }
      }
      W.pl[s].mk = 0;
    }
    recalcSupply(W); updVision(W);
    if (st.op) applyMission(W);
    return W;
  }
  function addU(W, t, o, x, y) {
    const D = UN[t];
    const u = { i: W.nid++, isU: 1, t, o, x, y, hp: D.hp, mhp: D.hp, cd: 0, s: 'i', tx: x, ty: y, gc: cellOf(W, x, y), tg: 0, an: 0, f: 4, cr: 0, ck: 0, nd: -1, gs: 0, mt: 0,
      acq: Math.random() * 0.4, hx: x, hy: y, lea: 0, sk: 0, pd: 1e9, pt: 0, wt: 0, bt: -1, btx: 0, bty: 0, bp: 0, bd: 0, hb: 0, air: !!D.air, dead: 0, in: 0, cg: 0, sh: D.sh, msh: D.sh, lh: -9, md: 0 };
    W.E.set(u.i, u); W.units.push(u); W.pl[o].mk++;
    return u;
  }
  function addB(W, t, o, tx, ty, done) {
    const B = BD[t], sz = B.sz;
    const b = { i: W.nid++, isB: 1, t, o, tx, ty, sz, x: tx + sz / 2, y: ty + sz / 2, hp: done ? B.hp : B.hp * 0.1, mhp: B.hp, done: !!done, pr: 0, q: [], rx: null, ry: null, rn: -1,
      cd: 0, an: 0, f: 4, tg: 0, acq: 0, wk: -1, hb: 0, dead: 0, sh: done ? B.sh : 0, msh: B.sh, lh: -9 };
    for (let y = ty; y < ty + sz; y++) for (let x = tx; x < tx + sz; x++) W.occ[y * W.S + x] = b.i;
    W.E.set(b.i, b); W.blds.push(b); W.fc.clear();
    return b;
  }
  function pushEv(W, kind, x, y, t, o) { W.evq = (W.evq + 1) % 1296; W.ev.push([W.evq, kind, Math.round(x * 10), Math.round(y * 10), t | 0, o | 0]); if (W.ev.length > 14) W.ev.shift(); }
  function recalcSupply(W) {
    for (const P of W.pl) { P.cap = 0; P.used = 0; }
    for (const b of W.blds) { if (b.dead) continue; const P = W.pl[b.o]; if (b.done) P.cap += BD[b.t].sup || 0; for (const it of b.q) if (it[0] === 'u') P.used += UN[it[1]].sup; }
    for (const u of W.units) if (!u.dead && !u.tmp) W.pl[u.o].used += UN[u.t].sup;
    for (const P of W.pl) P.cap = Math.min(100, P.cap);
  }
  function nearNode(W, x, y, rad, excl, kind, freeOnly) {
    let best = -1, bd = rad;
    for (let i = 0; i < W.nodes.length; i++) {
      const q = W.nodes[i]; if (q.a <= 0 || i === excl || (kind >= 0 && q.k !== kind) || (freeOnly && q.busy >= 2)) continue;
      const d = hyp(q.x - x, q.y - y); if (d < bd) { bd = d; best = i; }
    }
    return best;
  }
  function bestNode(W, o, x, y, rad) { // least crowded node near (x,y); crystal gets at most 2 per node
    const cnt = new Int16Array(W.nodes.length);
    for (const u of W.units) if (!u.dead && u.o === o && u.s === 'g' && u.nd >= 0) cnt[u.nd]++;
    let best = -1, bs = 1e9;
    for (let i = 0; i < W.nodes.length; i++) {
      const q = W.nodes[i]; if (q.a <= 0) continue; const d = hyp(q.x - x, q.y - y); if (d > rad) continue;
      const sc = d * 0.35 + cnt[i] * 3 + (q.k && cnt[i] >= 2 ? 12 : 0);
      if (sc < bs) { bs = sc; best = i; }
    }
    return best;
  }
  function nearHQ(W, o, x, y) {
    let best = null, bd = 1e9;
    for (const b of W.blds) if (!b.dead && b.o === o && BD[b.t].hq && b.done) { const d = hyp(b.x - x, b.y - y); if (d < bd) { bd = d; best = b; } }
    return best;
  }
  function hasDone(W, s, bt) { if (bt < 0) return true; for (const b of W.blds) if (!b.dead && b.o === s && b.t === bt && b.done) return true; return false; }
  function depleteNode(W, i) { const q = W.nodes[i]; q.a = 0; W.nodeAt[q.c] = -1; W.fc.clear(); }

  /* ----- placement ----- */
  function canPlaceG(map, occ, nodeAt, bt, tx, ty, margin) {
    const B = BD[bt], sz = B.sz, S = map.S;
    if (tx < 1 || ty < 1 || tx + sz > S - 1 || ty + sz > S - 1) return false;
    if (B.hq && !B.any && !map.sites.some((q) => q.x - 2 === tx && q.y - 2 === ty)) return false;
    for (let y = ty - margin; y < ty + sz + margin; y++) for (let x = tx - margin; x < tx + sz + margin; x++) {
      if (x < 0 || y < 0 || x >= S || y >= S) return false;
      const c = y * S + x, inside = x >= tx && y >= ty && x < tx + sz && y < ty + sz;
      if (inside) { if (!map.pass[c] || map.ter[c] === 2 || map.ter[c] >= 4 || occ[c] || nodeAt[c] >= 0) return false; }
      else if (occ[c] || nodeAt[c] >= 0 || map.ter[c] === 2 || map.ter[c] === 6) return false;
    }
    if (!(B.hq && !B.any)) for (let y = ty - 2; y < ty + sz + 2; y++) for (let x = tx - 2; x < tx + sz + 2; x++) { if (x >= 0 && y >= 0 && x < S && y < S && nodeAt[y * S + x] >= 0) return false; }
    return true;
  }
  function canPlace(W, bt, tx, ty, s, margin, units) {
    if (!canPlaceG(W.map, W.occ, W.nodeAt, bt, tx, ty, margin)) return false;
    if (!facPlace(W.blds, s, bt, tx, ty)) return false;
    if (units) { const sz = BD[bt].sz; for (const u of W.units) if (!u.dead && !u.air && W.tm[u.o] !== W.tm[s] && u.x > tx - 0.3 && u.x < tx + sz + 0.3 && u.y > ty - 0.3 && u.y < ty + sz + 0.3) return false; }
    return true;
  }
  function freeCellNear(W, x0, y0, x1, y1, px, py) { // free cell on rings around a rect, nearest to (px,py)
    for (let r = 1; r < 7; r++) {
      let best = -1, bd = 1e9;
      for (let y = y0 - r; y <= y1 + r; y++) for (let x = x0 - r; x <= x1 + r; x++) {
        if (x > x0 - r && x < x1 + r && y > y0 - r && y < y1 + r) continue;
        if (x < 0 || y < 0 || x >= W.S || y >= W.S) continue;
        const c = y * W.S + x; if (!passC(W, c)) continue;
        const d = hyp(x + 0.5 - px, y + 0.5 - py); if (d < bd) { bd = d; best = c; }
      }
      if (best >= 0) return best;
    }
    return -1;
  }
  function pushOut(W, b) {
    for (const u of W.units) {
      if (u.dead || u.air || u.x < b.tx || u.y < b.ty || u.x >= b.tx + b.sz || u.y >= b.ty + b.sz) continue;
      const c = freeCellNear(W, b.tx, b.ty, b.tx + b.sz - 1, b.ty + b.sz - 1, u.x, u.y);
      if (c >= 0) { u.x = c % W.S + 0.5; u.y = ((c / W.S) | 0) + 0.5; }
    }
  }

  /* ----- flow fields ----- */
  const DX = [1, -1, 0, 0, 1, 1, -1, -1], DY = [0, 0, 1, -1, 1, -1, 1, -1];
  function dijkstra(W, seeds) {
    const S = W.S, F = new Uint16Array(W.N).fill(INF), H = [];
    const push = (v) => { let i = H.length; H.push(v); while (i > 0) { const p = (i - 1) >> 1; if (H[p] <= v) break; H[i] = H[p]; i = p; } H[i] = v; };
    const pop = () => { const top = H[0], last = H.pop(), n = H.length; if (n) { let i = 0; for (;;) { let l = 2 * i + 1; if (l >= n) break; if (l + 1 < n && H[l + 1] < H[l]) l++; if (H[l] >= last) break; H[i] = H[l]; i = l; } H[i] = last; } return top; };
    for (const c of seeds) { F[c] = 0; push(c); }
    while (H.length) {
      const v = pop(), c = v % 8192, d = (v - c) / 8192; if (d > F[c]) continue;
      const x = c % S, y = (c - x) / S;
      for (let k = 0; k < 8; k++) {
        const nx = x + DX[k], ny = y + DY[k]; if (nx < 0 || ny < 0 || nx >= S || ny >= S) continue;
        const nc = ny * S + nx; if (!passC(W, nc)) continue;
        if (k >= 4 && (!passC(W, y * S + nx) || !passC(W, ny * S + x))) continue;
        const nd = d + (k < 4 ? 10 : 14); if (nd < F[nc]) { F[nc] = nd; push(nd * 8192 + nc); }
      }
    }
    return F;
  }
  function seedsPoint(W, c) {
    if (passC(W, c)) return [c];
    const S = W.S, x0 = c % S, y0 = (c - x0) / S;
    for (let r = 1; r <= 5; r++) { const out = []; for (let y = y0 - r; y <= y0 + r; y++) for (let x = x0 - r; x <= x0 + r; x++) { if (Math.max(Math.abs(x - x0), Math.abs(y - y0)) !== r || x < 0 || y < 0 || x >= S || y >= S) continue; const k = y * S + x; if (passC(W, k)) out.push(k); } if (out.length) return out; }
    return [];
  }
  function seedsRect(W, tx, ty, sz) {
    const out = [], S = W.S;
    for (let y = ty - 1; y <= ty + sz; y++) for (let x = tx - 1; x <= tx + sz; x++) { if (x >= tx && x < tx + sz && y >= ty && y < ty + sz) continue; if (x < 0 || y < 0 || x >= S || y >= S) continue; const c = y * S + x; if (passC(W, c)) out.push(c); }
    return out;
  }
  function getField(W, key, seedFn) {
    let f = W.fc.get(key);
    if (f) { W.fc.delete(key); W.fc.set(key, f); return f; }
    if (W.fb <= 0) return null;
    W.fb--;
    const seeds = seedFn(); if (!seeds.length) return null;
    f = dijkstra(W, seeds); W.fc.set(key, f);
    if (W.fc.size > 64) W.fc.delete(W.fc.keys().next().value);
    return f;
  }
  function bestNb(W, F, c) {
    const S = W.S, x = c % S, y = (c - x) / S; let best = -1, bv = F[c];
    for (let k = 0; k < 8; k++) {
      const nx = x + DX[k], ny = y + DY[k]; if (nx < 0 || ny < 0 || nx >= S || ny >= S) continue;
      const nc = ny * S + nx; if (F[nc] >= bv || !passC(W, nc)) continue;
      if (k >= 4 && (!passC(W, y * S + nx) || !passC(W, ny * S + x))) continue;
      bv = F[nc]; best = nc;
    }
    return best;
  }
  function lineClear(W, x0, y0, x1, y1) {
    const d = hyp(x1 - x0, y1 - y0), n = Math.ceil(d / 0.45);
    for (let i = 1; i < n; i++) { const c = cellOf(W, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n); if (!passC(W, c)) return false; }
    return true;
  }
  const faceOf = (dx, dy) => (((Math.round(Math.atan2(dy, dx) / (Math.PI / 8)) % 16) + 16) % 16);
  function okAt(W, u, x, y) {
    if (x < 0.5 || y < 0.5 || x > W.S - 0.5 || y > W.S - 0.5) return false;
    if (u.air) return true;
    if (passC(W, cellOf(W, x, y))) return true;
    return !passC(W, cellOf(W, u.x, u.y)); // already stuck inside something: let it walk out
  }
  function moveBy(W, u, dx, dy) {
    const nx = u.x + dx, ny = u.y + dy;
    if (okAt(W, u, nx, ny)) { u.x = nx; u.y = ny; return true; }
    if (dx && okAt(W, u, nx, u.y)) { u.x = nx; return true; }
    if (dy && okAt(W, u, u.x, ny)) { u.y = ny; return true; }
    return false;
  }
  function onCreep(W, u) {
    if ((u.cpT || 0) > W.t) return u.cp;
    u.cpT = W.t + 0.5; u.cp = false;
    for (const b of W.blds) if (!b.dead && b.o === u.o && BD[b.t].crp && (b.done || BD[b.t].hq) && hyp(b.x - u.x, b.y - u.y) <= BD[b.t].crp) { u.cp = true; break; }
    return u.cp;
  }
  function steer(W, u, D, key, seedFn, ex, ey, dt) {
    const dist = hyp(ex - u.x, ey - u.y);
    if (dist < 1e-3) return 0;
    let tx = ex, ty = ey;
    if (!u.air && dist > 1.4 && !(dist < 9 && lineClear(W, u.x, u.y, ex, ey))) {
      const F = getField(W, key, seedFn), c = cellOf(W, u.x, u.y);
      if (F && F[c] !== INF && F[c] > 0) {
        const n1 = bestNb(W, F, c);
        if (n1 >= 0) {
          const n2 = bestNb(W, F, n1), a = n2 >= 0 ? n2 : n1, S = W.S;
          tx = (n1 % S + a % S) / 2 + 0.5; ty = (((n1 / S) | 0) + ((a / S) | 0)) / 2 + 0.5;
        }
      }
    }
    const dx = tx - u.x, dy = ty - u.y, dl = hyp(dx, dy) || 1, mv = Math.min(D.sp * dt * (D.fa === 1 && !u.air && onCreep(W, u) ? 1.3 : 1), dist);
    moveBy(W, u, dx / dl * mv, dy / dl * mv);
    u.f = faceOf(dx, dy);
    return dist;
  }

  /* ----- vision ----- */
  const CIRC = [];
  function circ(r) { if (!CIRC[r]) { const a = []; for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) if (dx * dx + dy * dy <= r * r + r) a.push(dx, dy); CIRC[r] = a; } return CIRC[r]; }
  function stampVis(map, V, E, x, y, r, air) {
    const S = map.S, cx = x | 0, cy = y | 0; if (cx < 0 || cy < 0 || cx >= S || cy >= S) return;
    const t0 = map.ter[cy * S + cx], vh = air ? 9 : (t0 === 1 || t0 === 2 ? 1 : 0), a = circ(r);
    for (let i = 0; i < a.length; i += 2) {
      const X = cx + a[i], Y = cy + a[i + 1]; if (X < 0 || Y < 0 || X >= S || Y >= S) continue;
      const c = Y * S + X; if (map.h[c] > vh) continue; V[c] = 1; if (E) E[c] = 1;
    }
  }
  function updVision(W) {
    for (const V of W.vis) V.fill(0);
    for (const u of W.units) if (!u.dead && !u.in) { const T = W.tm[u.o]; stampVis(W.map, W.vis[T], W.ex[T], u.x, u.y, UN[u.t].si, u.air); }
    for (const b of W.blds) if (!b.dead) { const T = W.tm[b.o]; stampVis(W.map, W.vis[T], W.ex[T], b.x, b.y, BD[b.t].si + (b.sz >> 1) - 1, false); }
    for (const u of W.units) { // 수풀: 안의 유닛은 곁(2칸)에 온 적 · 최근 쏘거나 맞은 경우에만 보여요
      u.bz = !u.dead && !u.in && !u.air && W.map.ter[cellOf(W, u.x, u.y)] === 4 ? 1 : 0; if (!u.bz) continue;
      if (W.t - u.lh < BUSH_RV || W.t - (u.lf || -9) < BUSH_RV) { u.rv = 255; continue; }
      let rv = 1 << W.tm[u.o]; near(W, u.x, u.y, 2.5, (e) => { if (!e.dead && !e.in && hyp(e.x - u.x, e.y - u.y) <= 2.2) rv |= 1 << W.tm[e.o]; }); u.rv = rv;
    }
  }
  const hidU = (W, T, e) => !!(e.isU && e.bz && !((e.rv >> T) & 1));
  const visU = (W, T, e) => !!W.vis[T][cellOf(W, e.x, e.y)] && !hidU(W, T, e);
  const highAt = (W, x, y) => W.map.ter[cellOf(W, x, y)] === 1;
  const rgOf = (W, u, D) => D.rg + (!u.air && highAt(W, u.x, u.y) ? HIGH_RG : 0);
  function bVis(W, T, b) { const V = W.vis[T], S = W.S; return V[cellOf(W, b.x, b.y)] || V[b.ty * S + b.tx] || V[(b.ty + b.sz - 1) * S + b.tx + b.sz - 1] || V[b.ty * S + b.tx + b.sz - 1] || V[(b.ty + b.sz - 1) * S + b.tx]; }
  function seen(W, o, e) { const T = W.tm[o]; if (W.tm[e.o] === T) return true; return e.isB ? !!bVis(W, T, e) : visU(W, T, e); }

  /* ----- combat ----- */
  function near(W, x, y, r, fn) {
    const BS = W.BS, x0 = clamp(((x - r) / 4) | 0, 0, BS - 1), x1 = clamp(((x + r) / 4) | 0, 0, BS - 1), y0 = clamp(((y - r) / 4) | 0, 0, BS - 1), y1 = clamp(((y + r) / 4) | 0, 0, BS - 1);
    for (let by = y0; by <= y1; by++) for (let bx = x0; bx <= x1; bx++) { const a = W.bk[by * BS + bx]; for (let i = 0; i < a.length; i++) fn(a[i]); }
  }
  function edgeD(u, e) {
    if (e.isB) { const h = e.sz / 2; return hyp(Math.max(Math.abs(u.x - e.x) - h, 0), Math.max(Math.abs(u.y - e.y) - h, 0)); }
    return hyp(u.x - e.x, u.y - e.y) - UN[e.t].r - (u.isU ? UN[u.t].r * 0.5 : 0.9);
  }
  const canHit = (D, e) => (e.isB ? !!D.ag : (UN[e.t].air ? !!D.aa : !!D.ag));
  function dmgOf(W, o, D, tg, src) {
    const up = W.pl[o].up;
    let v = D.dm + (D.ud || 0) * (D.cls === 'i' ? up[0] : D.cls === 'v' ? up[1] : 0);
    if (src && src.md) v *= MOD.dm;
    if (src && src.au > W.t && src.af === 0) v *= 1.2;
    const tag = tg.isB ? 'bld' : UN[tg.t].tag; v *= D.bo[tag] || 1;
    let ar;
    if (tg.isB) ar = BD[tg.t].ar;
    else { const T = UN[tg.t], tu = W.pl[tg.o].up; ar = T.ar + (T.cls === 'i' ? tu[2] : T.cls === 'v' ? tu[3] : 0); }
    return Math.max(0.5, v - ar);
  }
  function hurt(W, e, dm, src) {
    if (e.dead) return;
    e.lh = W.t;
    if (e.sh > 0) { const a = Math.min(e.sh, dm); e.sh -= a; dm -= a; }
    e.hp -= dm; if (src) e.hb = src.i;
    if (e.hp <= 0) {
      e.dead = 1; W.dead.push(e);
      if (src && src.o !== e.o) { W.pl[src.o].k++; if (e.isU && facOf(W, src.o) === 1) { const g = Math.round(UN[e.t].c[0] * ABSORB); W.pl[src.o].ore += g; W.pl[src.o].sx += g; } }
      if (e.isU && W.nomad && !e.in && !UN[e.t].mb && UN[e.t].fa !== 1 && W.wr.length < 40) { /* 생체(군체)는 고철을 남기지 않아요 */ const D = UN[e.t]; W.wr.push({ i: ++W.wid, x: e.x, y: e.y, a: Math.max(8, Math.round((D.c[0] + D.c[1]) * WRECK)), e: W.t + 75 }); }
      if (e.isU && !e.tmp) W.pl[e.o].lost++;
      if (e.isU && UN[e.t].hero) W.pl[e.o].hc = W.t + HERO_RE;
      pushEv(W, e.isB ? 1 : 0, e.x, e.y, e.t, e.o);
      if (e.isU && e.cg) for (const p of W.units) if (p.in === e.i && !p.dead) { p.dead = 1; W.dead.push(p); W.pl[p.o].lost++; if (src && src.o !== p.o) W.pl[src.o].k++; }
    }
  }
  function fire(W, u, D, tg) {
    u.cd = D.cd * (0.95 + ((u.i * 7 + u.an) % 5) * 0.025); u.an = (u.an + 1) & 3; if (u.bf > W.t) u.cd /= 1.6;
    u.lf = W.t;
    const up = !u.air && !tg.air && !highAt(W, u.x, u.y) && W.map.ter[cellOf(W, u.x, u.y)] !== 2 && (tg.isB ? highAt(W, tg.x, tg.y) : highAt(W, tg.x, tg.y));
    if (up && !D.spl && Math.random() < UPHILL_MISS) { pushEv(W, 11, tg.x, tg.y, 0, u.o); return; } // 낮은 곳에서 올려 쏘면 가끔 빗나가요
    const dm = dmgOf(W, u.o, D, tg, u);
    hurt(W, tg, dm, u);
    if (D.spl) {
      const T = W.tm[u.o], air = !tg.isB && UN[tg.t].air;
      near(W, tg.x, tg.y, D.spl + 1, (e) => { if (e === tg || e.dead || W.tm[e.o] === T || e.air !== air) return; const d = hyp(e.x - tg.x, e.y - tg.y); if (d < D.spl + UN[e.t].r) hurt(W, e, dmgOf(W, u.o, D, e, u) * (D.boom ? 1 : 0.6), u); });
      if (D.fx === 'shell' || D.fx === 'glob' || D.boom) pushEv(W, 2, tg.x, tg.y, u.isU ? u.t : 0, u.o);
    }
    if (D.boom && u.isU) { u.dead = 1; W.dead.push(u); W.pl[u.o].lost++; }
  }
  function acquire(W, u, D, rad) {
    const T = W.tm[u.o], V = W.vis[T]; let best = null, bs = 1e9;
    near(W, u.x, u.y, rad + 1.5, (e) => {
      if (e.dead || W.tm[e.o] === T) return;
      const ED = UN[e.t]; if (ED.air ? !D.aa : !D.ag) return;
      if (!V[cellOf(W, e.x, e.y)] || hidU(W, T, e)) return;
      const d = edgeD(u, e); if (d > rad) return;
      const sc = d + (ED.w ? 2 : 0) + (ED.dm > 0 ? 0 : 1) + (D.mr && d < D.mr ? 50 : 0);
      if (sc < bs) { bs = sc; best = e; }
    });
    if (best || !D.ag) return best;
    for (const b of W.blds) {
      if (b.dead || W.tm[b.o] === T) continue;
      const d = edgeD(u, b); if (d > rad || !bVis(W, T, b)) continue;
      const sc = d + (BD[b.t].wpn ? 0 : 4); if (sc < bs) { bs = sc; best = b; }
    }
    return best;
  }
  function fight(W, u, D, tg, dt, mv) {
    const d = edgeD(u, tg);
    const rg = rgOf(W, u, D);
    if (d <= rg + 0.1 && !(D.mr && d < D.mr)) { u.f = faceOf(tg.x - u.x, tg.y - u.y); if (u.cd <= 0) fire(W, u, D, tg); return; }
    if (!mv) { if (d > rg + 0.1) u.tg = 0; return; }
    if (D.mr && d < D.mr) { const dx = u.x - tg.x, dy = u.y - tg.y, dl = hyp(dx, dy) || 1; moveBy(W, u, dx / dl * D.sp * dt, dy / dl * D.sp * dt); return; }
    if (tg.isB) steer(W, u, D, 'b' + tg.i, () => seedsRect(W, tg.tx, tg.ty, tg.sz), tg.x, tg.y, dt);
    else { const c = cellOf(W, tg.x, tg.y); steer(W, u, D, 'p' + c, () => seedsPoint(W, c), tg.x, tg.y, dt); }
  }

  /* ----- orders ----- */
  function clearOrd(W, u) {
    if (u.s === 'g' && u.gs === 1) { const q = W.nodes[u.nd]; if (q) q.busy = Math.max(0, q.busy - 1); }
    if (u.s === 'b' && u.bp) { const P = W.pl[u.o], c = BD[u.bt].c; P.ore += c[0]; P.cry += c[1]; }
    u.bp = 0; u.tg = 0; u.lea = 0; u.sk = 0; u.pd = 1e9; u.pt = 0; u.wt = 0;
  }
  function setMove(W, u, x, y, am, gx, gy) {
    clearOrd(W, u);
    u.s = am ? 'a' : 'm'; u.tx = clamp(x, 0.6, W.S - 0.6); u.ty = clamp(y, 0.6, W.S - 0.6);
    u.gc = cellOf(W, gx == null ? u.tx : gx, gy == null ? u.ty : gy);
  }
  function groupMove(W, us, x, y, am) {
    if (!us.length) return;
    let mx = 0, my = 0; for (const u of us) { mx += u.x; my += u.y; } mx /= us.length; my /= us.length;
    let spread = 0; for (const u of us) spread = Math.max(spread, hyp(u.x - mx, u.y - my));
    const rad = 0.42 * Math.sqrt(us.length) + 0.2;
    us.forEach((u, i) => {
      let ox, oy;
      if (us.length === 1) { ox = oy = 0; }
      else if (spread < 6) { ox = u.x - mx; oy = u.y - my; const ol = hyp(ox, oy); if (ol > rad) { ox *= rad / ol; oy *= rad / ol; } }
      else { const a = i * 2.4, r = 0.62 * Math.sqrt(i); ox = Math.cos(a) * r; oy = Math.sin(a) * r; }
      let tx = x + ox, ty = y + oy;
      if (!u.air && !passC(W, cellOf(W, clamp(tx, 0, W.S - 1), clamp(ty, 0, W.S - 1)))) { tx = x; ty = y; }
      setMove(W, u, tx, ty, am, x, y);
    });
  }
  function board(W, u, tp) { u.in = tp.i; tp.cg += seatOf(u.t); clearOrd(W, u); u.s = 'i'; u.tg = 0; u.x = tp.x; u.y = tp.y; }
  function unload(W, tp) { // set passengers down on free ground around the transport (none over rocks)
    const S = W.S, x0 = tp.x | 0, y0 = tp.y | 0, used = new Set(); let n = 0;
    for (const p of W.units) {
      if (p.in !== tp.i || p.dead) continue;
      let cell = -1;
      for (let r = 0; r <= 2 && cell < 0; r++) for (let y = y0 - r; y <= y0 + r && cell < 0; y++) for (let x = x0 - r; x <= x0 + r; x++) {
        if (Math.max(Math.abs(x - x0), Math.abs(y - y0)) !== r || x < 1 || y < 1 || x >= S - 1 || y >= S - 1) continue;
        const c = y * S + x; if (used.has(c) || !passC(W, c)) continue; cell = c; break;
      }
      if (cell < 0) break;
      used.add(cell); p.in = 0; tp.cg = Math.max(0, tp.cg - seatOf(p.t));
      p.x = cell % S + 0.5; p.y = ((cell / S) | 0) + 0.5; p.s = 'i'; p.hx = p.x; p.hy = p.y; p.tg = 0; p.lea = 0; n++;
    }
    if (n) pushEv(W, 5, tp.x, tp.y, n, tp.o);
    return n;
  }
  function startGather(W, u, nd) { clearOrd(W, u); u.s = 'g'; u.nd = nd; u.gs = u.cr > 0 ? 2 : 0; }
  function afterBuild(W, u) {
    if (u.nd >= 0 && W.nodes[u.nd] && W.nodes[u.nd].a > 0) startGather(W, u, u.nd);
    else { const nd = nearNode(W, u.x, u.y, 12, -1, -1, false); if (nd >= 0 && nearHQ(W, u.o, u.x, u.y)) startGather(W, u, nd); else { clearOrd(W, u); u.s = 'i'; } }
  }
  function cmd(W, s, c) {
    if (!Array.isArray(c) || !W.pl[s] || !W.pl[s].alive || W.over) return false;
    const P = W.pl[s], k = c[0];
    const own = (id) => { const e = W.E.get(id | 0); return e && !e.dead && e.o === s ? e : null; };
    const ownU = (ids) => (Array.isArray(ids) ? ids.slice(0, 150) : []).map(own).filter((e) => e && e.isU && !e.in);
    const ownB = (id) => { const b = own(id); return b && b.isB ? b : null; };
    const pay = (cc) => { if (P.ore < cc[0] || P.cry < cc[1]) return false; P.ore -= cc[0]; P.cry -= cc[1]; return true; };
    if (k === 'm') {
      const us = ownU(c[4]); if (!us.length) return false;
      groupMove(W, us, clamp(+c[1] / 10 || 0, 0.6, W.S - 0.6), clamp(+c[2] / 10 || 0, 0.6, W.S - 0.6), c[3] ? 1 : 0); return true;
    }
    if (k === 'k') {
      const tg = W.E.get(c[1] | 0); if (!alive(tg)) return false;
      const us = ownU(c[2]); if (!us.length) return false;
      const friend = W.tm[tg.o] === W.tm[s];
      const mv = [];
      for (const u of us) {
        const D = UN[u.t];
        if (friend) {
          if (tg.isB && !tg.done && tg.o === s && isW(u.t)) { clearOrd(W, u); u.s = 'c'; u.bd = tg.i; }
          else if (tg.isU && tg.t === TP && tg.o === s && u !== tg && seatOf(u.t)) { clearOrd(W, u); u.s = 'l'; u.tg = tg.i; u.pd = 1e9; }
          else if (u.t === TP && tg.isU && tg.o === s && !tg.in && seatOf(tg.t) && u.cg + seatOf(tg.t) <= CAP) { setMove(W, u, tg.x, tg.y, 0); if (tg.s !== 'l') { clearOrd(W, tg); tg.s = 'l'; tg.tg = u.i; tg.pd = 1e9; } }
          else mv.push(u);
          continue;
        }
        if (!canHit(D, tg)) { mv.push(u); continue; }
        clearOrd(W, u); u.s = 'k'; u.tg = tg.i;
      }
      if (mv.length) groupMove(W, mv, tg.x, tg.y, friend ? 0 : 1);
      return true;
    }
    if (k === 'g') {
      const nd = c[1] | 0, q = W.nodes[nd]; if (!q || q.a <= 0) return false;
      const us = ownU(c[2]); if (!us.length) return false;
      const mv = [];
      for (const u of us) { if (isW(u.t)) startGather(W, u, nd); else mv.push(u); }
      if (mv.length) groupMove(W, mv, q.x, q.y, 0);
      return true;
    }
    if (k === 'u') { // 수송기 내리기: [ids] (+ x, y → 거기까지 날아가서)
      const us = ownU(c[1]).filter((u) => u.t === TP); if (!us.length) return false;
      const go = c[2] != null && c[3] != null;
      for (const u of us) {
        if (!go) { unload(W, u); continue; }
        setMove(W, u, clamp(+c[2] / 10 || 0, 0.6, W.S - 0.6), clamp(+c[3] / 10 || 0, 0.6, W.S - 0.6), 0); u.s = 'd';
      }
      return true;
    }
    if (k === 's' || k === 'h') { const us = ownU(c[1]); for (const u of us) { clearOrd(W, u); u.s = k === 'h' ? 'h' : 'i'; u.hx = u.x; u.hy = u.y; } return us.length > 0; }
    if (k === 'b') {
      const bt = c[1] | 0, tx = c[2] | 0, ty = c[3] | 0, u = own(c[4]); const B = BD[bt];
      if (!B || !u || !u.isU || !isW(u.t) || B.fa !== facOf(W, s)) return false;
      if (B.req >= 0 && !hasDone(W, s, B.req)) return false;
      if (!B.hq && !W.blds.some((b) => !b.dead && b.o === s && BD[b.t].hq)) return false;
      if (!canPlace(W, bt, tx, ty, s, 0, false)) return false;
      if (!pay(B.c)) return false;
      const keepNd = u.nd; clearOrd(W, u); u.nd = keepNd;
      u.s = 'b'; u.bt = bt; u.btx = tx; u.bty = ty; u.wt = 0; u.bp = 1;
      return true;
    }
    if (k === 't') {
      const b = ownB(c[1]), ut = c[2] | 0, D = UN[ut]; if (!b || !b.done || !D || !((BD[b.t].tr || []).includes(ut) || (D.hero && BD[b.t].hq && D.fa === facOf(W, s) && heroWhyW(W, s) === ''))) return false;
      if (!hasDone(W, s, D.req) || b.q.length >= 5 || P.used + D.sup > P.cap) return false;
      if (!pay(D.c)) return false;
      b.q.push(['u', ut, D.bt]); P.used += D.sup; return true;
    }
    if (k === 'r') {
      const b = ownB(c[1]), v = c[2] | 0, UG = UPGF[facOf(W, s)]; if (!b || !b.done || !BD[b.t].rs || !UG[v] || b.q.length >= 2) return false;
      const lvl = P.up[v]; if (lvl >= 2) return false;
      for (const o of W.blds) if (!o.dead && o.o === s) for (const it of o.q) if (it[0] === 'r' && it[1] === v) return false;
      if (!pay(UG[v].c[lvl])) return false;
      b.q.push(['r', v, UG[v].tm[lvl]]); return true;
    }
    if (k === 'x') {
      const b = ownB(c[1]), i = c[2] | 0; if (!b || !b.q[i]) return false;
      const it = b.q.splice(i, 1)[0];
      const cc = it[0] === 'u' ? UN[it[1]].c : upgOf(facOf(W, s), it[1]).c[P.up[it[1]]];
      P.ore += cc[0]; P.cry += cc[1]; if (it[0] === 'u') P.used -= UN[it[1]].sup; return true;
    }
    if (k === 'p') {
      const b = ownB(c[1]); if (!b) return false;
      b.rx = clamp(+c[2] / 10 || 0, 0.5, W.S - 0.5); b.ry = clamp(+c[3] / 10 || 0, 0.5, W.S - 0.5);
      const nd = c[4] | 0; b.rn = W.nodes[nd] && W.nodes[nd].a > 0 && c[4] != null && c[4] >= 0 ? nd : -1; return true;
    }
    if (k === 'pk') { // 고철: 본부 접기
      const b = ownB(c[1]); if (!b || !b.done || !BD[b.t].pk || b.q.length) return false;
      const ratio = b.hp / b.mhp; b.dead = 1; b.silent = 1; W.dead.push(b); sweep(W);
      const u = addU(W, MB, s, b.x, b.y); u.hp = Math.max(1, UN[MB].hp * ratio); u.hx = u.x; u.hy = u.y; W.pl[s].mk--;
      pushEv(W, 9, b.x, b.y, 0, s); return true;
    }
    if (k === 'dp') { // 고철: 본부 펼치기 (빈 땅 어디든)
      const u = own(c[1]); if (!u || !u.isU || !UN[u.t].mb) return false;
      const bt = FAC[3].b[0], tx = Math.round(u.x - 2), ty = Math.round(u.y - 2);
      if (!canPlace(W, bt, tx, ty, s, 0, true)) return false;
      const ratio = u.hp / u.mhp; u.dead = 1; W.dead.push(u); sweep(W);
      const b = addB(W, bt, s, tx, ty, true); b.hp = Math.max(1, b.mhp * ratio); pushOut(W, b); pushEv(W, 9, b.x, b.y, 1, s);
      for (const w of W.units) if (!w.dead && w.o === s && isW(w.t) && w.s === 'i' && hyp(w.x - b.x, w.y - b.y) < 18) { const nd = bestNode(W, s, b.x, b.y, 10); if (nd >= 0) startGather(W, w, nd); }
      return true;
    }
    if (k === 'v') { // 고철: 개조 (정비소 근처)
      const shops = W.blds.filter((b) => !b.dead && b.o === s && b.done && BD[b.t].mod);
      let n = 0;
      for (const u of ownU(c[1])) {
        const D = UN[u.t]; if (u.md || D.w || D.mb || D.hero || D.fa !== 3 || !shops.some((b) => hyp(b.x - u.x, b.y - u.y) <= BD[b.t].mod + b.sz / 2)) continue;
        const cc = [Math.ceil(D.c[0] * MOD.c), Math.ceil(D.c[1] * MOD.c)]; if (!pay(cc)) break;
        u.md = 1; u.mhp *= MOD.hp; u.hp *= MOD.hp; n++;
      }
      if (n) pushEv(W, 4, shops[0].x, shops[0].y, 9, s);
      return n > 0;
    }
    if (k === 'hs') { // 영웅 기술
      const u = own(c[1]); if (!u || !u.isU || !UN[u.t].hero) return false;
      return heroSkill(W, s, u);
    }
    if (k === 'z') {
      const b = ownB(c[1]); if (!b || b.done) return false;
      const cc = BD[b.t].c; P.ore += Math.floor(cc[0] * 0.75); P.cry += Math.floor(cc[1] * 0.75);
      b.dead = 1; b.silent = 1; W.dead.push(b); return true;
    }
    return false;
  }

  /* ----- per-entity updates ----- */
  function spawnUnit(W, b, ut) {
    const px = b.rx != null ? b.rx : b.x, py = b.rx != null ? b.ry : b.y + b.sz;
    let gate = b;
    if (BD[b.t].fa === 2 && b.rx != null && !isW(ut)) { // 관문 소환: the pillar/sanctum nearest the rally point
      let bd = hyp(b.x - px, b.y - py) - 4;
      for (const o of W.blds) if (!o.dead && o.o === b.o && o.done && BD[o.t].pw) { const d = hyp(o.x - px, o.y - py); if (d < bd) { bd = d; gate = o; } }
      if (gate !== b) pushEv(W, 7, gate.x, gate.y, ut, b.o);
    }
    const c = freeCellNear(W, gate.tx, gate.ty, gate.tx + gate.sz - 1, gate.ty + gate.sz - 1, px, py);
    const x = c >= 0 ? c % W.S + 0.5 : gate.x, y = c >= 0 ? ((c / W.S) | 0) + 0.5 : gate.y + gate.sz / 2 + 0.5;
    const u = addU(W, ut, b.o, x, y);
    if (isW(ut)) {
      const nd = b.rn >= 0 && W.nodes[b.rn].a > 0 ? b.rn : (b.rx == null ? bestNode(W, b.o, b.x, b.y, 10) : -1);
      if (nd >= 0) { startGather(W, u, nd); return; }
    }
    if (b.rx != null) setMove(W, u, b.rx, b.ry, 0);
    if (UN[ut].hero) { W.pl[b.o].hk = W.t + 8; pushEv(W, 10, u.x, u.y, 9, b.o); }
  }
  /* ----- 영웅 ----- */
  const heroOf = (W, s) => W.units.find((u) => !u.dead && u.o === s && UN[u.t].hero);
  function heroWhyW(W, s) { // '' = can call the hero now (sim side)
    if (W.mis) return '작전에서는 영웅을 못 불러요';
    if (heroOf(W, s)) return '영웅은 한 번에 한 명이에요';
    for (const b of W.blds) if (!b.dead && b.o === s) for (const it of b.q) if (it[0] === 'u' && UN[it[1]].hero) return '이미 부르는 중이에요';
    if (W.t < W.pl[s].hc) return '다시 부르려면 ' + Math.ceil(W.pl[s].hc - W.t) + '초';
    return '';
  }
  function heroSkill(W, s, u) {
    const P = W.pl[s], fa = UN[u.t].hf, K = HS[fa], T = W.tm[s];
    if (W.t < P.hk) return false;
    if (fa === 0) { // 포격 요청
      let tg = u.tg ? W.E.get(u.tg) : null;
      if (!alive(tg) || W.tm[tg.o] === T || hyp(tg.x - u.x, tg.y - u.y) > K.rg) tg = acquire(W, u, { aa: 1, ag: 1 }, K.rg);
      if (!tg) return false;
      const x = tg.x, y = tg.y;
      for (let k = 0; k < 3; k++) { const a = k * 2.094, ox = x + Math.cos(a) * 0.9, oy = y + Math.sin(a) * 0.9; pushEv(W, 2, ox, oy, 0, s); }
      near(W, x, y, K.rad + 1.5, (e) => { if (e.dead || W.tm[e.o] === T || hyp(e.x - x, e.y - y) > K.rad + UN[e.t].r) return; hurt(W, e, K.dm * (e.air ? 0.7 : 1), u); });
      for (const b of W.blds) if (!b.dead && W.tm[b.o] !== T && edgeD({ x, y }, b) <= K.rad) hurt(W, b, K.dm * 0.5, u);
      pushEv(W, 10, x, y, 0, s);
    } else if (fa === 1) { // 산란
      for (let k = 0; k < K.n; k++) {
        const a = k * 1.571 + 0.4; let x = u.x + Math.cos(a) * 0.8, y = u.y + Math.sin(a) * 0.8;
        if (!passC(W, cellOf(W, x, y))) { x = u.x; y = u.y; }
        const f = addU(W, 9, s, x, y); f.tmp = 1; f.ex = W.t + K.life; f.hx = x; f.hy = y; P.mk--;
        if (u.tg) { const e = W.E.get(u.tg); if (alive(e) && canHit(UN[9], e)) { f.s = 'k'; f.tg = e.i; } }
      }
      pushEv(W, 10, u.x, u.y, 1, s);
    } else if (fa === 2) { // 성역의 빛
      for (const e of W.units) { if (e.dead || e.in || W.tm[e.o] !== T || hyp(e.x - u.x, e.y - u.y) > K.rad) continue; if (e.msh) e.sh = e.msh; else e.hp = Math.min(e.mhp, e.hp + 30); }
      pushEv(W, 10, u.x, u.y, 2, s);
    } else { // 과열 돌격
      for (const e of W.units) { if (e.dead || e.in || W.tm[e.o] !== T || hyp(e.x - u.x, e.y - u.y) > K.rad || UN[e.t].w) continue; e.bf = W.t + K.life; }
      pushEv(W, 10, u.x, u.y, 3, s);
    }
    P.hk = W.t + K.cd; return true;
  }
  function updBld(W, b, dt) {
    const B = BD[b.t];
    if (!b.done) {
      if (b.wk >= W.t - 0.25 || B.fa === 2) { b.pr += dt; b.hp = Math.min(b.mhp, b.hp + b.mhp * 0.9 * dt / B.bt); if (b.pr >= B.bt) { b.done = true; b.sh = b.msh; pushEv(W, 3, b.x, b.y, b.t, b.o); } }
      return;
    }
    if (b.q.length) {
      const it = b.q[0]; it[2] -= dt;
      if (it[2] <= 0) { b.q.shift(); if (it[0] === 'u') spawnUnit(W, b, it[1]); else { W.pl[b.o].up[it[1]] = Math.min(2, W.pl[b.o].up[it[1]] + 1); pushEv(W, 4, b.x, b.y, it[1], b.o); } }
    }
    if (B.wpn) {
      const D = B.wpn; if (b.cd > 0) b.cd -= dt; if (b.acq > 0) b.acq -= dt;
      let tg = b.tg ? W.E.get(b.tg) : null;
      const brg = D.rg + (highAt(W, b.x, b.y) ? HIGH_RG : 0);
      if (tg && (tg.dead || !seen(W, b.o, tg) || edgeD(b, tg) > brg + 0.1)) tg = null;
      if (!tg && b.acq <= 0) { b.acq = 0.3; tg = acquire(W, b, D, brg); }
      b.tg = tg ? tg.i : 0;
      if (tg) { b.f = faceOf(tg.x - b.x, tg.y - b.y); if (b.cd <= 0) fire(W, b, D, tg); }
    }
  }
  function updUnit(W, u, dt) {
    const D = UN[u.t];
    if (u.cd > 0) u.cd -= dt; if (u.acq > 0) u.acq -= dt;
    const s = u.s;
    if (s === 'i' || s === 'h') {
      if (UN[u.t].w || UN[u.t].mb) return;
      let tg = u.tg ? W.E.get(u.tg) : null;
      if (tg && (tg.dead || !seen(W, u.o, tg))) { tg = null; u.tg = 0; }
      if (!tg && u.acq <= 0) {
        u.acq = 0.4;
        let e = acquire(W, u, D, s === 'h' ? rgOf(W, u, D) : D.si);
        if (!e && u.hb && s === 'i') { const a = W.E.get(u.hb); u.hb = 0; if (alive(a) && seen(W, u.o, a) && canHit(D, a) && hyp(a.x - u.x, a.y - u.y) < 13) e = a; }
        if (e) { tg = e; u.tg = e.i; if (s === 'i' && !u.lea) { u.hx = u.x; u.hy = u.y; u.lea = 1; } }
      }
      if (tg) {
        if (s === 'i' && hyp(u.x - u.hx, u.y - u.hy) > 8) { const hx = u.hx, hy = u.hy; setMove(W, u, hx, hy, 0); return; }
        fight(W, u, D, tg, dt, s === 'i');
      } else if (s === 'i' && u.lea) { u.lea = 0; if (hyp(u.x - u.hx, u.y - u.hy) > 1.5) { const hx = u.hx, hy = u.hy; setMove(W, u, hx, hy, 0); } }
      return;
    }
    if (s === 'm' || s === 'a') {
      if (s === 'a') {
        let tg = u.tg ? W.E.get(u.tg) : null;
        if (tg && (tg.dead || !seen(W, u.o, tg))) { tg = null; u.tg = 0; }
        if (!tg && u.acq <= 0) { u.acq = 0.4; const e = acquire(W, u, D, D.si); if (e) { tg = e; u.tg = e.i; } }
        if (tg) { fight(W, u, D, tg, dt, true); u.pt = 0; u.pd = 1e9; return; }
      }
      const gc = u.gc;
      const d = steer(W, u, D, 'p' + gc, () => seedsPoint(W, gc), u.tx, u.ty, dt);
      if (d < 0.3) { u.s = 'i'; u.hx = u.x; u.hy = u.y; return; }
      u.pt += dt;
      if (u.pt >= 1) { u.pt = 0; if (d > u.pd - 0.35) u.sk++; else u.sk = 0; u.pd = d; if ((u.sk >= 2 && d < 3.5) || u.sk >= 6) { u.s = 'i'; u.hx = u.x; u.hy = u.y; u.sk = 0; } }
      return;
    }
    if (s === 'k') {
      const tg = W.E.get(u.tg);
      if (!alive(tg)) { u.s = 'i'; u.tg = 0; u.hx = u.x; u.hy = u.y; return; }
      if (!seen(W, u.o, tg)) { const x = tg.x, y = tg.y; setMove(W, u, x, y, 1); return; }
      fight(W, u, D, tg, dt, true); return;
    }
    if (s === 'g') { updGather(W, u, D, dt); return; }
    if (s === 'l') { // walk to a transport and get in
      const tp = W.E.get(u.tg);
      if (!alive(tp) || tp.cg + seatOf(u.t) > CAP) { u.s = 'i'; u.tg = 0; u.hx = u.x; u.hy = u.y; return; }
      const d = hyp(tp.x - u.x, tp.y - u.y);
      if (d < 1.2 + UN[TP].r) { board(W, u, tp); return; }
      const c = cellOf(W, tp.x, tp.y);
      steer(W, u, D, 'p' + c, () => seedsPoint(W, c), tp.x, tp.y, dt);
      u.pt += dt; if (u.pt >= 1) { u.pt = 0; if (d > u.pd - 0.3) u.sk++; else u.sk = 0; u.pd = d; if (u.sk >= 7) { u.s = 'i'; u.tg = 0; u.sk = 0; u.hx = u.x; u.hy = u.y; } }
      return;
    }
    if (s === 'd') { // transport flying to a drop point
      const d = steer(W, u, D, '', null, u.tx, u.ty, dt);
      if (d < 0.3) { unload(W, u); u.s = 'i'; u.hx = u.x; u.hy = u.y; }
      return;
    }
    if (s === 'b') {
      const B = BD[u.bt], cx = u.btx + B.sz / 2, cy = u.bty + B.sz / 2;
      const d = hyp(Math.max(Math.abs(u.x - cx) - B.sz / 2, 0), Math.max(Math.abs(u.y - cy) - B.sz / 2, 0));
      if (d < 0.9) {
        if (canPlace(W, u.bt, u.btx, u.bty, u.o, 0, true)) { u.bp = 0; const b = addB(W, u.bt, u.o, u.btx, u.bty, false); pushOut(W, b); if (BD[u.bt].fa === 2) { pushEv(W, 7, b.x, b.y, 0, u.o); afterBuild(W, u); } else { u.s = 'c'; u.bd = b.i; } }
        else { u.wt += dt; if (u.wt > 3) { clearOrd(W, u); u.s = 'i'; } }
        return;
      }
      const tx = u.btx, ty = u.bty, sz = B.sz;
      steer(W, u, D, 'r' + tx + ',' + ty + ',' + sz, () => seedsRect(W, tx, ty, sz), cx, cy, dt);
      u.pt += dt; if (u.pt >= 1) { u.pt = 0; if (d > u.pd - 0.3) u.sk++; else u.sk = 0; u.pd = d; if (u.sk >= 8) { clearOrd(W, u); u.s = 'i'; } }
      return;
    }
    if (s === 'c') {
      const b = W.E.get(u.bd);
      if (!alive(b) || b.done) { afterBuild(W, u); return; }
      if (edgeD(u, b) > 0.95) { steer(W, u, D, 'b' + b.i, () => seedsRect(W, b.tx, b.ty, b.sz), b.x, b.y, dt); return; }
      b.wk = W.t; u.f = faceOf(b.x - u.x, b.y - u.y); u.mt -= dt; if (u.mt <= 0) { u.mt = 0.6; u.an = (u.an + 1) & 3; }
    }
  }
  function updGather(W, u, D, dt) {
    if (u.gs === 0) {
      let q = W.nodes[u.nd];
      if (!q || q.a <= 0) { const alt = q ? nearNode(W, u.x, u.y, 10, -1, q.k, false) : bestNode(W, u.o, u.x, u.y, 10); if (alt < 0) { if (u.cr > 0) u.gs = 2; else { u.s = 'i'; } return; } u.nd = alt; q = W.nodes[alt]; }
      const d = hyp(q.x - u.x, q.y - u.y);
      if (d < 1.5) {
        if (q.busy < 2) { q.busy++; u.gs = 1; u.mt = MINE[q.k].t; u.f = faceOf(q.x - u.x, q.y - u.y); return; }
        let alt = nearNode(W, q.x, q.y, 5, u.nd, q.k, true);
        u.wt += 0.1; if (alt < 0 && u.wt > 2) { alt = nearNode(W, q.x, q.y, 8, u.nd, -1, true); }
        if (alt >= 0) { u.nd = alt; u.wt = 0; }
        return;
      }
      const nd = u.nd;
      steer(W, u, D, 'n' + nd, () => seedsRect(W, q.x - 0.5, q.y - 0.5, 1), q.x, q.y, dt);
    } else if (u.gs === 1) {
      const q = W.nodes[u.nd];
      if (!q || q.a <= 0) { if (q) q.busy = Math.max(0, q.busy - 1); u.gs = 0; return; }
      const pm = u.mt; u.mt -= dt;
      if (Math.floor(pm / 0.6) !== Math.floor(u.mt / 0.6)) u.an = (u.an + 1) & 3;
      if (u.mt <= 0) {
        const amt = Math.min(MINE[q.k].c + (q.k && facOf(W, u.o) === 2 ? 1 : 0), q.a); q.a -= amt; q.busy = Math.max(0, q.busy - 1);
        u.cr = amt; u.ck = q.k; u.gs = 2; if (q.a <= 0) depleteNode(W, u.nd);
      }
    } else {
      const h = nearHQ(W, u.o, u.x, u.y);
      if (!h) { u.s = 'i'; return; }
      if (edgeD(u, h) < 0.65) { const P = W.pl[u.o]; if (u.ck) P.cry += u.cr; else P.ore += u.cr; P.mined += u.cr; u.cr = 0; u.gs = 0; return; }
      steer(W, u, D, 'b' + h.i, () => seedsRect(W, h.tx, h.ty, h.sz), h.x, h.y, dt);
    }
  }
  function separate(W) {
    for (const u of W.units) {
      if (u.dead || u.in) continue;
      const ru = UN[u.t].r, gu = u.s === 'g' || u.s === 'c';
      near(W, u.x, u.y, 1.6, (o) => {
        if (o === u || o.dead || o.air !== u.air) return;
        if (gu && (o.s === 'g' || o.s === 'c')) return;
        const rs = (ru + UN[o.t].r) * 0.92, dx = u.x - o.x, dy = u.y - o.y, d2 = dx * dx + dy * dy;
        if (d2 >= rs * rs) return;
        const d = Math.sqrt(d2) || 0.01, push = (rs - d) * (u.s === 'i' || u.s === 'h' ? 0.45 : 0.3);
        const nx = d2 > 1e-6 ? dx / d : ((u.i * 13) % 7) / 7 - 0.5, ny = d2 > 1e-6 ? dy / d : ((u.i * 7) % 5) / 5 - 0.5;
        moveBy(W, u, nx * push, ny * push);
      });
    }
  }
  function sweep(W) {
    if (!W.dead.length) return;
    for (const e of W.dead) {
      if (e.isU) {
        if (e.s === 'g' && e.gs === 1) { const q = W.nodes[e.nd]; if (q) q.busy = Math.max(0, q.busy - 1); }
        if (e.s === 'b' && e.bp) { const c = BD[e.bt].c; W.pl[e.o].ore += c[0]; W.pl[e.o].cry += c[1]; }
      } else {
        for (let y = e.ty; y < e.ty + e.sz; y++) for (let x = e.tx; x < e.tx + e.sz; x++) if (W.occ[y * W.S + x] === e.i) W.occ[y * W.S + x] = 0;
        W.fc.clear();
      }
      W.E.delete(e.i);
    }
    W.dead.length = 0;
    W.units = W.units.filter((u) => !u.dead); W.blds = W.blds.filter((b) => !b.dead);
  }
  function scoreTeam(W, T) {
    let v = 0;
    for (const b of W.blds) if (!b.dead && W.tm[b.o] === T) v += (BD[b.t].c[0] + BD[b.t].c[1]) * b.hp / b.mhp;
    for (const u of W.units) if (!u.dead && W.tm[u.o] === T) v += UN[u.t].c[0] + UN[u.t].c[1];
    return v;
  }
  function checkEnd(W) {
    for (let s = 0; s < W.n; s++) {
      const P = W.pl[s]; if (!P.alive) continue;
      if (!W.blds.some((b) => !b.dead && b.o === s) && !W.units.some((u) => !u.dead && u.o === s && UN[u.t].mb)) { P.alive = false; for (const u of W.units) if (!u.dead && u.o === s) { u.dead = 1; W.dead.push(u); pushEv(W, 0, u.x, u.y, u.t, u.o); } }
    }
    const teams = new Set(); for (let s = 0; s < W.n; s++) if (W.pl[s].alive) teams.add(W.tm[s]);
    if (teams.size <= 1) { const T = teams.size ? [...teams][0] : -1; W.over = { win: W.tm.map((t, s) => (t === T ? s : -1)).filter((s) => s >= 0), why: 'k' }; return; }
    if (W.st.T && W.t >= W.st.T) {
      let bt = -1, bv = -1; for (const T of teams) { const v = scoreTeam(W, T); if (v > bv) { bv = v; bt = T; } }
      W.over = { win: W.tm.map((t, s) => (t === bt ? s : -1)).filter((s) => s >= 0), why: 't' };
    }
  }
  function facTick(W, dt) { // 재생(군체) · 보호막(성광) · 잔해 회수(고철) · 영웅 오라
    W.auT = (W.auT || 0) - dt;
    if (W.auT <= 0) {
      W.auT = 0.5;
      for (const h of W.units) {
        if (h.dead || h.in || !UN[h.t].hero) continue;
        const T = W.tm[h.o], af = UN[h.t].hf;
        near(W, h.x, h.y, AURA + 1, (e) => { if (!e.dead && W.tm[e.o] === T && hyp(e.x - h.x, e.y - h.y) <= AURA) { e.au = W.t + 0.6; e.af = af; } });
      }
    }
    for (const u of W.units) {
      if (u.dead) continue;
      if (u.ex && W.t > u.ex) { u.dead = 1; W.dead.push(u); pushEv(W, 0, u.x, u.y, u.t, u.o); continue; }
      if (u.au > W.t) {
        if (u.af === 1 && u.hp < u.mhp) u.hp = Math.min(u.mhp, u.hp + 2 * dt);
        else if (u.af === 2 && u.msh && u.sh < u.msh) u.sh = Math.min(u.msh, u.sh + 3 * dt);
        else if (u.af === 3 && !UN[u.t].w && u.hp < u.mhp) u.hp = Math.min(u.mhp, u.hp + 3 * dt);
      }
      if (u.msh && u.sh < u.msh && W.t - u.lh > 6) u.sh = Math.min(u.msh, u.sh + 3 * dt);
      else if (UN[u.t].fa === 1 && u.hp < u.mhp && W.t - u.lh > 3) u.hp = Math.min(u.mhp, u.hp + (0.5 + u.mhp * 0.008) * dt);
    }
    for (const b of W.blds) {
      if (b.dead || !b.done) continue;
      if (b.msh && b.sh < b.msh && W.t - b.lh > 6) b.sh = Math.min(b.msh, b.sh + 8 * dt);
      else if (BD[b.t].fa === 1 && b.hp < b.mhp) b.hp = Math.min(b.mhp, b.hp + 3 * dt);
    }
    if (!W.nomad) return;
    W.wrT -= dt; if (W.wrT > 0) return; W.wrT = 0.5;
    W.wr = W.wr.filter((w) => {
      if (W.t > w.e) return false;
      for (let o = 0; o < W.n; o++) {
        if (W.fa[o] !== 3 || !W.pl[o].alive) continue;
        let got = false;
        for (const b of W.blds) if (!b.dead && b.o === o && b.done && BD[b.t].rec && hyp(b.x - w.x, b.y - w.y) <= BD[b.t].rec) { got = true; break; }
        if (!got) near(W, w.x, w.y, 3, (u) => { if (!got && !u.dead && u.o === o && !UN[u.t].w && hyp(u.x - w.x, u.y - w.y) < 2.5) got = true; });
        if (got) { W.pl[o].ore += w.a; W.pl[o].sx += w.a; pushEv(W, 8, w.x, w.y, 0, o); return false; }
      }
      return true;
    });
  }
  function step(W, dt) {
    if (W.over) return;
    W.t += dt; W.fb = 12;
    for (const a of W.bk) a.length = 0;
    for (const u of W.units) if (!u.dead && !u.in) W.bk[clamp((u.y / 4) | 0, 0, W.BS - 1) * W.BS + clamp((u.x / 4) | 0, 0, W.BS - 1)].push(u);
    W.vt -= dt; if (W.vt <= 0) { W.vt = 0.3; updVision(W); }
    for (const b of W.blds) if (!b.dead) updBld(W, b, dt);
    for (const u of W.units) if (!u.dead && !u.in) updUnit(W, u, dt);
    for (const u of W.units) if (u.in && !u.dead) { const c = W.E.get(u.in); if (c && !c.dead) { u.x = c.x; u.y = c.y; } }
    facTick(W, dt);
    separate(W);
    sweep(W);
    recalcSupply(W);
    if (W.mis) misTick(W, dt);
    W.et -= dt; if (W.et <= 0) { W.et = 1; if (W.mis) misCheck(W); else checkEnd(W); sweep(W); }
  }

  /* ---------------- 작전 (solo missions) ---------------- */
  // T: time limit / goal (s) · brief: shown before the start
  const OPS = [null,
    { nm: '기지 방어', goal: '8분 동안 본부 지키기', T: 480, brief: ['적이 1분마다 점점 큰 공격대를 보내요. 8분 동안 본부를 지키면 성공!', '보급고·병영은 미리 지어 두었어요. 일꾼을 늘리고 경사로 앞에 포탑과 병력을 세우세요.', '본부가 무너지면 실패예요.'] },
    { nm: '특수부대 침투', goal: '적 연구소 파괴', T: 600, brief: ['특수부대(화염병 2 · 저격수 2, 강화 1단계)가 수송기에 타고 있어요. 기지도 일꾼도 없어요.', '적 기지 경사로는 포탑이 지켜요. 수송기로 바위·절벽을 넘어 언덕 뒤쪽에 내려 연구소를 부수세요.', '수송기를 고르고 ⤓골라 내리기 → 땅 누르기. 10분이 지나거나 부대를 모두 잃으면 실패.'] },
    { nm: '제한 자원 섬멸', goal: '12분 안에 적 건물 모두 파괴', T: 720, brief: ['이 땅에는 캘 자원이 없어요. 가진 광석 1800 · 수정 900으로 군대를 꾸리세요.', '병영·공장·연구소는 준비되어 있어요. 적 전초기지는 포탑과 수비대가 지켜요 — 상성을 맞춰 아껴 싸우세요.', '12분 안에 적 건물을 모두 부수면 성공. 군대와 자원이 모두 바닥나도 실패.'] },
    { nm: '확장 기지 지키기', goal: '9분 동안 확장 기지 지키기', T: 540, brief: ['앞쪽 기지 자리에 확장 본부를 세웠어요. 적이 그곳을 노리고 계속 쳐들어와요.', '본진에서 병력을 뽑아 보내고, 확장 기지 일꾼도 계속 캐게 두세요.', '9분 동안 확장 본부가 버티면 성공, 무너지면 실패.'] },
    { nm: '수송대 호위', goal: '보급 전차를 먼 기지 자리까지', T: 540, brief: ['보급 전차 2대가 45초 뒤 먼 기지 자리(초록 고리)로 출발해요. 1대라도 도착하면 성공!', '보급 전차는 싸우지 않고 길만 가요. 근처에 적이 있으면 멈춰 기다려요. 길목마다 매복이 나오니 앞장서서 길을 여세요.', '보급 전차가 모두 부서지거나 9분이 지나면 실패.'] },
    { nm: '거점 3곳 점령', goal: '거점 3곳을 90초 동안 동시에', T: 720, brief: ['맵 가운데쪽 거점 3곳(고리)을 차지하세요. 내 병력만 고리 안에 있으면 내 거점이 돼요.', '세 곳을 모두 차지한 채 90초를 버티면 성공. 하나라도 빼앗기면 시간이 처음부터예요. 적은 수비대를 두고 계속 되찾으러 와요.', '12분이 지나거나 본부가 무너지면 실패.'] },
    { nm: '적 지휘관 사냥', goal: '적 지휘 전차 처치', T: 720, brief: ['적 기지 안에 아주 튼튼한 지휘 전차(빨간 고리)가 있어요. 그것만 쓰러뜨리면 성공!', '지휘 전차는 다치면 본부 쪽으로 물러나 조금씩 고쳐요. 포탑·수비대를 피해 옆에서 치거나, 저격수·전차로 멀리서 깎으세요. 적도 가끔 공격대를 보내요.', '12분이 지나거나 본부가 무너지면 실패.'] },
    { nm: '맨손 생존', goal: '일꾼만으로 10분 버티기', T: 600, brief: ['병력도 건물도 없이 본부와 일꾼 6명만 있어요. 2분 30초 뒤부터 적 공격대가 점점 크게 와요.', '빨리 보급고·병영을 짓고 포탑을 세우세요. 일꾼은 급할 때 싸울 수도 있어요.', '10분 동안 본부가 버티면 성공, 무너지면 실패.'] },
  ];
  const OPN = OPS.length - 1;
  function wipe(W, s, units, blds) {
    if (units) for (const u of W.units) if (u.o === s && !u.dead) { u.dead = 1; W.dead.push(u); }
    if (blds) for (const b of W.blds) if (b.o === s && !b.dead) { b.dead = 1; b.silent = 1; W.dead.push(b); }
    sweep(W);
  }
  function spotAt(W, s, bt, cx, cy, a0, spread, r0, r1) { // a free spot for building bt on rings around (cx,cy), near angle a0
    const sz = BD[bt].sz;
    for (let r = r0; r <= r1; r++) for (let k = 0; k < 13; k++) {
      const a = a0 + (k % 2 ? 1 : -1) * Math.ceil(k / 2) / 6 * spread;
      const tx = Math.round(cx + Math.cos(a) * r - sz / 2), ty = Math.round(cy + Math.sin(a) * r - sz / 2);
      if (canPlace(W, bt, tx, ty, s, 1, true)) return [tx, ty];
    }
    return null;
  }
  function putB(W, s, bt, spot) { if (!spot) return null; const b = addB(W, bt, s, spot[0], spot[1], true); pushOut(W, b); return b; }
  function putU(W, t, s, x, y, n) {
    const out = [];
    for (let i = 0; i < n; i++) {
      const c = freeCellNear(W, Math.floor(x), Math.floor(y), Math.floor(x), Math.floor(y), x + Math.cos(i * 2.4) * 2, y + Math.sin(i * 2.4) * 2);
      const u = addU(W, t, s, c >= 0 ? c % W.S + 0.5 : x, c >= 0 ? ((c / W.S) | 0) + 0.5 : y); u.hx = u.x; u.hy = u.y; out.push(u);
    }
    return out;
  }
  function applyMission(W) {
    const st = W.st, op = st.op, cm = st.cm, en = 1 - cm, S = W.S;
    const M = W.mis = { op, cm, en, T: OPS[op].T, tgt: 0, exp: 0, wt: 0, wk: 0, ord: 0, ok: 0, why: '' };
    const hq = (o) => W.blds.find((b) => b.o === o && b.t === 0);
    const ang = (o) => { const sp = W.map.spawn[o]; return Math.atan2(S / 2 - sp.y, S / 2 - sp.x); }; // toward the centre = the ramp
    const C = hq(cm), E = hq(en), aC = ang(cm), aE = ang(en), Pc = W.pl[cm], Pe = W.pl[en];
    const front = (b, a, r) => [b.x + Math.cos(a) * r, b.y + Math.sin(a) * r];
    if (op === 1) {
      Pc.ore = 250; putB(W, cm, 1, spotAt(W, cm, 1, C.x, C.y, aC + 1.6, 1.2, 5, 9)); putB(W, cm, 2, spotAt(W, cm, 2, C.x, C.y, aC - 1.2, 1.2, 5, 9));
      const f = front(C, aC, 5); putU(W, 1, cm, f[0], f[1], 3);
      Pe.ore = 400; M.wt = 70;
    } else if (op === 2) {
      wipe(W, cm, true, true); Pc.ore = 0; Pc.up = [2, 0, 2, 0];
      const sp = W.map.spawn[cm], tp = putU(W, TP, cm, sp.x, sp.y, 1)[0];
      for (const t of [2, 2, 3, 3]) { const u = putU(W, t, cm, sp.x, sp.y, 1)[0]; u.in = tp.i; tp.cg += seatOf(t); u.x = tp.x; u.y = tp.y; }
      const side = Math.random() < 0.5 ? 1 : -1; // the lab sits on a flank of the plateau, away from the ramp turrets
      const lab = putB(W, en, 4, spotAt(W, en, 4, E.x, E.y, aE + side * 1.7, 0.5, 5, 8) || spotAt(W, en, 4, E.x, E.y, aE - side * 1.7, 0.5, 5, 8) || findSpot(W, en, 4, E, front(E, aE, 7)));
      M.tgt = lab ? lab.i : 0; if (lab) lab.hp = lab.mhp = 380;
      const rp = front(E, aE, 7);
      // turrets hold the foot of the ramp (low ground), so the plateau's flanks are open from the air
      putB(W, en, 5, spotAt(W, en, 5, E.x, E.y, aE - 0.25, 0.4, 12, 15)); putB(W, en, 5, spotAt(W, en, 5, E.x, E.y, aE + 0.25, 0.4, 12, 15));
      putB(W, en, 2, spotAt(W, en, 2, E.x, E.y, aE - side * 1.4, 0.8, 5, 9));
      putU(W, 1, en, rp[0], rp[1], [0, 0, 0, 2][W.st.lvE || 2]);
      Pe.ore = [0, 0, 0, 150][W.st.lvE || 2];
    } else if (op === 3) {
      for (let i = 0; i < W.nodes.length; i++) if (W.nodes[i].a > 0) depleteNode(W, i);
      wipe(W, cm, true, false); wipe(W, en, true, false);
      Pc.ore = 1800; Pc.cry = 900;
      for (const [bt, da] of [[2, -1.3], [3, 1.3], [4, 2.4], [1, -2.4], [1, 3.1]]) putB(W, cm, bt, spotAt(W, cm, bt, C.x, C.y, aC + da, 0.9, 5, 10));
      const f = front(C, aC, 5); putU(W, 1, cm, f[0], f[1], 4);
      putB(W, en, 5, spotAt(W, en, 5, E.x, E.y, aE - 0.35, 0.5, 5, 7)); putB(W, en, 5, spotAt(W, en, 5, E.x, E.y, aE + 0.35, 0.5, 5, 7));
      putB(W, en, 2, spotAt(W, en, 2, E.x, E.y, aE + 1.6, 1, 5, 9)); putB(W, en, 1, spotAt(W, en, 1, E.x, E.y, aE - 1.6, 1, 5, 9));
      const g = front(E, aE, 5);
      const lv = W.st.lvE || 2, gar = [null, [3, 1, 0, 0], [4, 2, 1, 1], [6, 3, 1, 1]][lv]; // 수비대: 소총병·화염병·저격수·장갑차
      putU(W, 1, en, g[0], g[1], gar[0]); putU(W, 2, en, g[0], g[1], gar[1]); putU(W, 3, en, E.x, E.y, gar[2]); putU(W, 4, en, g[0], g[1], gar[3]);
      Pe.ore = [0, 0, 100, 200][lv]; Pe.cry = [0, 0, 0, 100][lv];
    } else if (op === 4) {
      const sp = W.map.spawn[cm];
      let site = null, bd = 1e9;
      for (const q of W.map.sites) { if (q.sp) continue; const d = hyp(q.x - sp.x, q.y - sp.y); if (d < bd && canPlace(W, 0, q.x - 2, q.y - 2, cm, 0, true)) { bd = d; site = q; } }
      if (site) {
        const X = putB(W, cm, 0, [site.x - 2, site.y - 2]); M.exp = X.i;
        const ws = putU(W, 0, cm, site.x, site.y, 4); for (const u of ws) { const nd = bestNode(W, cm, site.x, site.y, 9); if (nd >= 0) startGather(W, u, nd); }
        const ax = Math.atan2(S / 2 - site.y, S / 2 - site.x);
        putB(W, cm, 5, spotAt(W, cm, 5, X.x, X.y, ax, 0.8, 4, 6)); putB(W, cm, 5, spotAt(W, cm, 5, X.x, X.y, ax + 0.9, 0.8, 4, 6));
        const f = front(X, ax, 4); putU(W, 1, cm, f[0], f[1], 4);
      }
      Pc.ore = 450; Pe.ore = 400; M.wt = 75;
    } else if (op === 5) {
      const sp = W.map.spawn[cm], ep = W.map.spawn[en];
      let site = null, bd = -1;
      for (const q of W.map.sites) { if (q.sp) continue; const d = hyp(q.x - sp.x, q.y - sp.y); if (d > bd && hyp(q.x - ep.x, q.y - ep.y) > 16) { bd = d; site = q; } }
      if (!site) site = { x: S / 2, y: S / 2 };
      M.dx = site.x; M.dy = site.y; M.d0 = hyp(site.x - C.x, site.y - C.y) || 1; M.amb = 0; M.go = 45;
      const f = front(C, aC, 5);
      M.cv = putU(W, 5, cm, f[0], f[1], 2).map((u) => { u.hp = u.mhp = 400; u.cv = 1; u.s = 'h'; return u.i; });
      putU(W, 1, cm, f[0], f[1], 4); putU(W, 2, cm, f[0], f[1], 2); putU(W, 4, cm, f[0], f[1], 2);
      putB(W, cm, 1, spotAt(W, cm, 1, C.x, C.y, aC + 1.6, 1.2, 5, 9)); putB(W, cm, 2, spotAt(W, cm, 2, C.x, C.y, aC - 1.2, 1.2, 5, 9));
      Pc.ore = 300; Pe.ore = 300; M.wt = 120;
    } else if (op === 6) {
      const ss = W.map.sites.filter((q) => !q.sp).sort((a, b) => hyp(a.x - S / 2, a.y - S / 2) - hyp(b.x - S / 2, b.y - S / 2)).slice(0, 3);
      while (ss.length < 3) ss.push({ x: S / 2 + (ss.length - 1) * 8, y: S / 2 });
      M.pts = ss.map((q) => [q.x, q.y, -1]); M.hold = 0;
      const lv = W.st.lvE || 2;
      for (const q of M.pts) { for (const [t, n] of [[1, [0, 2, 3, 4][lv]], [2, [0, 0, 1, 2][lv]], [4, lv === 3 ? 1 : 0]]) for (const u of putU(W, t, en, q[0], q[1], n)) u.s = 'h'; }
      putB(W, cm, 1, spotAt(W, cm, 1, C.x, C.y, aC + 1.6, 1.2, 5, 9)); putB(W, cm, 2, spotAt(W, cm, 2, C.x, C.y, aC - 1.2, 1.2, 5, 9));
      const f = front(C, aC, 5); putU(W, 1, cm, f[0], f[1], 6); putU(W, 2, cm, f[0], f[1], 2);
      Pc.ore = 400; Pe.ore = 400; M.wt = 50;
    } else if (op === 7) {
      const lv = W.st.lvE || 2;
      for (const [bt, da] of [[2, -1.3], [3, 1.3]]) putB(W, cm, bt, spotAt(W, cm, bt, C.x, C.y, aC + da, 0.9, 5, 10));
      putB(W, cm, 1, spotAt(W, cm, 1, C.x, C.y, aC + 2.4, 1.2, 5, 9));
      const f = front(C, aC, 5); putU(W, 1, cm, f[0], f[1], 4); putU(W, 4, cm, f[0], f[1], 2);
      putB(W, en, 5, spotAt(W, en, 5, E.x, E.y, aE - 0.3, 0.5, 6, 9)); putB(W, en, 5, spotAt(W, en, 5, E.x, E.y, aE + 0.3, 0.5, 6, 9));
      putB(W, en, 2, spotAt(W, en, 2, E.x, E.y, aE + 1.6, 1, 5, 9));
      const g = front(E, aE, 3), bo = putU(W, 5, en, g[0], g[1], 1)[0];
      bo.hp = bo.mhp = [0, 700, 750, 1100][lv]; bo.boss = 1; M.boss = bo.i; M.hx = E.x; M.hy = E.y;
      putU(W, 1, en, g[0], g[1], [0, 2, 3, 5][lv]); putU(W, 4, en, g[0], g[1], [0, 0, 0, 2][lv]);
      Pc.ore = 400; Pc.cry = 150; Pe.ore = [0, 100, 250, 400][lv]; M.wt = 110;
    } else if (op === 8) {
      wipe(W, cm, true, false);
      const sp = W.map.spawn[cm];
      for (const u of putU(W, 0, cm, sp.x, sp.y + 3, 6)) { const nd = bestNode(W, cm, sp.x, sp.y, 10); if (nd >= 0) startGather(W, u, nd); }
      Pc.ore = 200; Pe.ore = 300; M.wt = 150;
    }
    Pc.mk = 0; Pe.mk = 0;
    recalcSupply(W); updVision(W);
  }
  function misTarget(W) { // what the attack waves go for
    const M = W.mis;
    if (M.op === 5) { const c = (M.cv || []).map((i) => W.E.get(i)).find(alive); if (c) return c; }
    if (M.op === 6) { const E = W.blds.find((x) => !x.dead && x.o === M.en && x.t === 0) || { x: W.S / 2, y: W.S / 2 }; let best = null, bd = 1e9; for (const q of M.pts) if (q[2] !== M.en) { const d = hyp(q[0] - E.x, q[1] - E.y); if (d < bd) { bd = d; best = { x: q[0], y: q[1] }; } } if (best) return best; }
    let b = M.op === 4 ? W.E.get(M.exp) : W.blds.find((x) => !x.dead && x.o === M.cm && x.t === 0);
    if (!alive(b)) b = W.blds.find((x) => !x.dead && x.o === M.cm);
    return b;
  }
  function misTick(W, dt) {
    const M = W.mis; if (W.over) return;
    const lvE = W.st.lvE || 2;
    if (WAVE[M.op] && W.t < M.T - 50) {
      M.wt -= dt;
      const E = W.blds.find((b) => !b.dead && b.o === M.en && b.t === 0);
      if (M.wt <= 0 && E) {
        M.wt = WAVE[M.op][0]; M.wk++;
        const k = M.wk * WAVE[M.op][1], f = WAVE[M.op][1 + lvE];
        const S = W.S, a = Math.atan2(S / 2 - E.y, S / 2 - E.x), x = E.x + Math.cos(a) * 6, y = E.y + Math.sin(a) * 6;
        // wave k: more riflemen each time, then flamers, armoured cars, a tank near the end
        const comp = [[1, Math.round((1 + k) * f)], [2, Math.floor(k / 3 * f)], [4, k >= 4 ? Math.round((k - 3) * f) : 0], [5, k >= 6 && f >= 1 ? 1 : 0]];
        for (const [t, n] of comp) for (const u of putU(W, t, M.en, x, y, n)) u.wv = 1;
        M.ord = 0; pushEv(W, 6, x, y, Math.min(9, k), M.en);
      }
    }
    if (M.op === 5) misConvoy(W, M, dt, lvE);
    if (M.op === 6) misPoints(W, M, dt);
    if (M.op === 7) {
      const bo = W.E.get(M.boss); M.mk = alive(bo) ? [[bo.x, bo.y, 1.4, 2]] : [];
      if (alive(bo)) {
        if (bo.hp < bo.mhp * 0.4 && !bo.ret) { bo.ret = 1; cmd(W, M.en, ['m', Math.round(M.hx * 10), Math.round(M.hy * 10), 0, [bo.i]]); }
        if (bo.ret === 1 && hyp(bo.x - M.hx, bo.y - M.hy) < 5) bo.ret = 2;
        if (bo.ret === 2) bo.hp = Math.min(bo.mhp * 0.6, bo.hp + dt * 4);
      }
    }
    M.ord -= dt;
    if (M.ord <= 0) { // keep the attack waves moving at their target
      M.ord = 6; const tg = misTarget(W);
      if (tg) { const ids = W.units.filter((u) => !u.dead && u.wv && u.o === M.en && (u.s === 'i' || u.s === 'h' || u.s === 'm')).map((u) => u.i); if (ids.length) cmd(W, M.en, ['m', Math.round(tg.x * 10), Math.round(tg.y * 10), 1, ids]); }
    }
  }
  // attack waves per op: [period s, size step, f 쉬움, f 보통, f 어려움]
  const WAVE = [null, [60, 1, 0.7, 0.95, 1.25], null, null, [65, 1, 0.6, 0.85, 1.24], [55, 0.8, 0.6, 1, 1.3], [55, 0.9, 0.55, 0.8, 1.6], [75, 0.7, 0.5, 0.75, 1], [50, 0.8, 0.5, 0.75, 1.32]];
  function misConvoy(W, M, dt, lv) {
    const cv = M.cv.map((i) => W.E.get(i)).filter(alive);
    M.mk = [[M.dx, M.dy, 3, 1]].concat(cv.map((u) => [u.x, u.y, 1.1, 1]));
    if (!cv.length) return;
    if (M.go > 0) { M.go -= dt; return; }
    M.ct = (M.ct || 0) - dt; if (M.ct > 0) return; M.ct = 1;
    const lead = cv.reduce((a, u) => (hyp(u.x - M.dx, u.y - M.dy) < hyp(a.x - M.dx, a.y - M.dy) ? u : a));
    const pr = 1 - hyp(lead.x - M.dx, lead.y - M.dy) / M.d0;
    if (M.amb < 3 && pr > [0.12, 0.4, 0.68][M.amb]) { // ambush ahead, beside the road
      M.amb++;
      let ax = M.dx - lead.x, ay = M.dy - lead.y; const al = hyp(ax, ay) || 1; ax /= al; ay /= al;
      const sd = M.amb % 2 ? 1 : -1, x = clamp(lead.x + ax * 9 - ay * 4 * sd, 2, W.S - 2), y = clamp(lead.y + ay * 9 + ax * 4 * sd, 2, W.S - 2);
      const f = [0, 0.7, 1.35, 1.45][lv], k = M.amb;
      for (const [t, n] of [[1, Math.round((2 + k) * f)], [2, Math.round(k * 0.7 * f)], [4, k >= 2 ? (lv === 3 && k === 3 ? 2 : 1) : 0]]) for (const u of putU(W, t, M.en, x, y, n)) { u.wv = 1; u.s = 'h'; }
      pushEv(W, 6, x, y, 3, M.en);
    }
    const foe = W.units.some((e) => !e.dead && !e.in && e.o === M.en && e.t !== 0 && cv.some((u) => hyp(e.x - u.x, e.y - u.y) < 6));
    const mv = cv.filter((u) => (foe ? u.s !== 'h' : u.s !== 'm' || hyp(u.tx - M.dx, u.ty - M.dy) > 2));
    if (!mv.length) return;
    if (foe) cmd(W, M.cm, ['h', mv.map((u) => u.i)]);
    else cmd(W, M.cm, ['m', Math.round(M.dx * 10), Math.round(M.dy * 10), 0, mv.map((u) => u.i)]);
  }
  function misPoints(W, M, dt) {
    M.pt2 = (M.pt2 || 0) - dt;
    if (M.pt2 <= 0) {
      M.pt2 = 0.5;
      for (const q of M.pts) {
        let a = 0, b = 0;
        for (const u of W.units) if (!u.dead && !u.in && u.t !== 0 && !u.air && hyp(u.x - q[0], u.y - q[1]) < 4) { if (u.o === M.cm) a++; else if (u.o === M.en) b++; }
        if (a && !b) q[2] = M.cm; else if (b && !a) q[2] = M.en;
      }
    }
    if (M.pts.every((q) => q[2] === M.cm)) M.hold += dt; else M.hold = 0;
    M.mk = M.pts.map((q) => [q[0], q[1], 4, q[2] === M.cm ? 1 : q[2] === M.en ? 2 : 0]);
  }
  function misEnd(W, ok, why) { const M = W.mis; M.ok = ok ? 1 : 0; M.why = why; W.over = { win: ok ? [M.cm] : [M.en], why: ok ? 'mo' : 'mf' }; }
  function misCheck(W) {
    const M = W.mis, t = W.t;
    const has = (o, f) => W.blds.some((b) => !b.dead && b.o === o && (!f || f(b)));
    const army = W.units.some((u) => !u.dead && u.o === M.cm);
    if (!has(M.cm) && !army) return misEnd(W, false, '부대와 기지를 모두 잃었어요');
    if (M.op === 1) { if (!has(M.cm, (b) => b.t === 0)) return misEnd(W, false, '본부가 무너졌어요'); if (t >= M.T) return misEnd(W, true, '8분 동안 본부를 지켜 냈어요'); }
    if (M.op === 2) { if (!alive(W.E.get(M.tgt))) return misEnd(W, true, '적 연구소를 파괴했어요'); if (t >= M.T) return misEnd(W, false, '시간 안에 연구소를 부수지 못했어요'); }
    if (M.op === 3) {
      if (!has(M.en)) return misEnd(W, true, '적 건물을 모두 부쉈어요');
      if (t >= M.T) return misEnd(W, false, '시간이 다 됐어요');
      const P = W.pl[M.cm], fighters = W.units.some((u) => !u.dead && u.o === M.cm && u.t !== 0), queued = W.blds.some((b) => !b.dead && b.o === M.cm && b.q.length);
      if (!fighters && !queued && P.ore < 50) return misEnd(W, false, '군대와 자원이 모두 바닥났어요');
    }
    if (M.op === 4) { if (!alive(W.E.get(M.exp))) return misEnd(W, false, '확장 기지 본부가 무너졌어요'); if (t >= M.T) return misEnd(W, true, '9분 동안 확장 기지를 지켜 냈어요'); }
    const hqLost = !has(M.cm, (b) => b.t === 0);
    if (M.op === 5) {
      const cv = M.cv.map((i) => W.E.get(i)).filter(alive);
      if (cv.some((u) => hyp(u.x - M.dx, u.y - M.dy) < 3.5)) return misEnd(W, true, '보급 전차 ' + cv.length + '대가 무사히 도착했어요');
      if (!cv.length) return misEnd(W, false, '보급 전차가 모두 부서졌어요');
      if (t >= M.T) return misEnd(W, false, '시간 안에 도착하지 못했어요');
    }
    if (M.op === 6) { if (M.hold >= 90) return misEnd(W, true, '거점 3곳을 90초 동안 지켜 냈어요'); if (hqLost) return misEnd(W, false, '본부가 무너졌어요'); if (t >= M.T) return misEnd(W, false, '시간 안에 거점을 모두 지키지 못했어요'); }
    if (M.op === 7) { if (!alive(W.E.get(M.boss))) return misEnd(W, true, '적 지휘 전차를 쓰러뜨렸어요'); if (hqLost) return misEnd(W, false, '본부가 무너졌어요'); if (t >= M.T) return misEnd(W, false, '시간 안에 지휘 전차를 잡지 못했어요'); }
    if (M.op === 8) { if (hqLost) return misEnd(W, false, '본부가 무너졌어요'); if (t >= M.T) return misEnd(W, true, '맨손으로 10분을 버텨 냈어요'); }
    if (!has(M.en) && !W.units.some((u) => !u.dead && u.o === M.en)) return misEnd(W, true, '적을 모두 물리쳤어요');
  }
  function misLine(W) { // HUD: goal · time left · next wave
    const M = W.mis, left = Math.max(0, M.T - W.t), f = (v) => Math.floor(v / 60) + ':' + String(Math.floor(v % 60)).padStart(2, '0');
    let s = '작전 ' + M.op + ' · ' + OPS[M.op].goal + ' · ' + f(left);
    if (M.op === 5) { const n = M.cv.filter((i) => alive(W.E.get(i))).length; s += ' · 전차 ' + n + '대' + (M.go > 0 ? ' · 출발 ' + f(M.go) : ''); }
    else if (M.op === 6) s += ' · 내 거점 ' + M.pts.filter((q) => q[2] === M.cm).length + '/3' + (M.hold > 0 ? ' · 유지 ' + Math.floor(M.hold) + '/90초' : '');
    else if (M.op === 7) { const bo = W.E.get(M.boss); if (alive(bo)) s += ' · 지휘 전차 ' + Math.ceil(bo.hp / bo.mhp * 100) + '%'; }
    if (WAVE[M.op] && M.op !== 6 && W.t < M.T - 50) s += ' · 다음 공격 ' + f(Math.max(0, M.wt));
    return s;
  }

  /* ---------------- AI ---------------- */
  const AI_DT = [0, 1.5, 1.2, 0.5], HERO_T = [0, 420, 270, 220];
  // [building role (0 본부 1 보급 2 병영 3 공장 4 연구 5 포탑), count, min workers, min time] per faction
  const PLAN0 = [null,
    [[2, 1, 9, 0], [2, 2, 0, 330], [3, 1, 0, 400], [4, 1, 0, 460], [0, 2, 0, 560]],
    [[2, 1, 9, 0], [3, 1, 13, 0], [4, 1, 14, 0], [2, 2, 15, 0], [0, 2, 16, 230], [5, 1, 0, 300], [3, 2, 0, 420], [0, 3, 0, 600]],
    [[2, 1, 9, 0], [2, 2, 13, 0], [0, 2, 14, 150], [4, 1, 16, 0], [3, 1, 18, 0], [5, 1, 0, 260], [3, 2, 0, 330], [2, 3, 0, 380], [0, 3, 0, 460], [5, 2, 0, 480]],
  ];
  const PLANF = [PLAN0, [null,
    [[2, 1, 9, 0], [2, 2, 0, 300], [4, 1, 0, 400], [3, 1, 0, 460], [0, 2, 0, 560]],
    [[2, 1, 9, 0], [0, 2, 13, 170], [2, 2, 13, 0], [4, 1, 15, 0], [3, 1, 16, 0], [5, 1, 0, 280], [2, 3, 0, 330], [3, 2, 0, 450], [0, 3, 0, 560]],
    [[2, 1, 9, 0], [0, 2, 12, 120], [2, 2, 13, 0], [4, 1, 15, 0], [3, 1, 17, 0], [5, 1, 0, 240], [2, 3, 0, 300], [3, 2, 0, 360], [0, 3, 0, 440], [5, 2, 0, 460]],
  ], [null,
    [[2, 1, 9, 0], [2, 2, 0, 250], [3, 1, 0, 380], [4, 1, 0, 430], [0, 2, 0, 560]],
    [[2, 1, 9, 0], [2, 2, 12, 0], [4, 1, 14, 0], [3, 1, 15, 0], [0, 2, 16, 240], [5, 1, 0, 280], [3, 2, 0, 470], [0, 3, 0, 620]],
    [[2, 1, 9, 0], [2, 2, 12, 0], [5, 1, 13, 0], [0, 2, 14, 170], [4, 1, 15, 0], [3, 1, 16, 0], [3, 2, 0, 330], [0, 3, 0, 470], [5, 2, 0, 480]],
  ], [null,
    PLAN0[1],
    [[2, 1, 9, 0], [0, 2, 13, 170], [3, 1, 14, 0], [4, 1, 15, 0], [2, 2, 16, 0], [5, 1, 0, 300], [3, 2, 0, 420], [0, 3, 0, 560]],
    [[2, 1, 9, 0], [0, 2, 13, 140], [2, 2, 14, 0], [4, 1, 16, 0], [3, 1, 18, 0], [5, 1, 0, 260], [3, 2, 0, 330], [2, 3, 0, 380], [0, 3, 0, 460], [5, 2, 0, 480]],
  ]];
  const PLAN = PLAN0;
  // attack timing per faction: threshold (army supply) and earliest attack time multipliers
  // per faction, per level [-, 쉬움, 보통, 어려움]: attack threshold (army value) and earliest attack time multipliers
  const FTAC = [[0, [1, 1], [1.054, 1.054], [0.928, 0.928]], [0, [1, 1], [0.95, 0.95], [0.996, 0.996]], [0, [1, 1], [1.008, 1.008], [1.08, 1.08]], [0, [1, 1], [0.988, 0.988], [0.94, 0.962]]];
  // 대진별 보정(AI가 상대 진영을 보고 공격 시점을 조금 당기거나 늦춰요) · [lv]['내 진영,상대 진영']
  const FMU = [null, {}, { '0,1': 0.94, '1,0': 1.065, '0,2': 0.955, '2,0': 1.045, '0,3': 1.02, '3,0': 0.98, '1,2': 0.955, '2,1': 1.045, '1,3': 0.95, '3,1': 1.05, '2,3': 0.92, '3,2': 1.08 }, { '0,1': 0.952, '1,0': 1.05, '0,2': 1.06, '2,0': 0.945, '0,3': 1.03, '3,0': 0.97, '1,2': 1.03, '2,1': 0.971, '1,3': 0.994, '3,1': 1.007, '2,3': 1.0, '3,2': 1.0 }];
  const AW = { rf: 3, fl: 1.1, sn: 1, ac: 1.6, at: 1.1, dr: 1, fg: 3, sp: 2.2, ab: 1, cr: 1.2, sf: 1, bw: 1, kn: 2.2, ar2: 2, ph: 1.5, jd: 1.2, sk: 0.9, cl: 0.8, sg: 2.5, bk: 1.6, hp: 1.3, gl: 1.3, mt: 1, zp: 0.9 };
  const ucost = (t) => UN[t].c[0] + UN[t].c[1];
  function aiMem(W, s, lv) {
    const sp = W.map.spawn[s], S = W.S, dl = hyp(S / 2 - sp.x, S / 2 - sp.y) || 1;
    const turtle = !!(W.mis && W.mis.en === s), fa = facOf(W, s), jt = W.mis ? 1 : 0.8 + Math.random() * 0.4, ft = { thr: FTAC[fa][lv][0] * jt, tm: FTAC[fa][lv][1] * jt };
    if (!W.mis) { let mu = 0, k = 0; for (let o = 0; o < W.n; o++) if (W.tm[o] !== W.tm[s]) { mu += FMU[lv][fa + ',' + facOf(W, o)] || 1; k++; } if (k) { ft.thr *= mu / k; ft.tm *= mu / k; } } // jt: per-game timing jitter (who strikes first varies)
    return { turtle, fa, nt: lv === 1 ? 4 : 1, kb: new Map(), seen: new Array(UN.length).fill(0), mode: 'b', dr: null, drN: lv === 3 ? 480 : 560, thr: Math.round([0, 18, 16, 20][lv] * ft.thr), tmin: turtle ? 1e9 : [0, 380, 290, 300][lv] * ft.tm, waves: 0, cool: 0,
      hj: 0.85 + Math.random() * 0.3, scout: 0, scDone: lv === 1, chk: new Set(), exi: 0, mic: {}, thc: 0, rp: [sp.x + (S / 2 - sp.x) / dl * 7, sp.y + (S / 2 - sp.y) / dl * 7], fwd: null, mbGo: null, rl: 0 };
  }
  function postSpot(W, main, lv) { // nearest watch mesa, else (어려움) a bush toward the centre
    const map = W.map, S = W.S; let best = null, bd = 1e9;
    for (const q of map.mesas) { const d = hyp(q[0] - main.x, q[1] - main.y); if (d < 30 && d < bd) { bd = d; best = [q[0], q[1]]; } }
    if (best || lv < 3) return best;
    const dl = hyp(S / 2 - main.x, S / 2 - main.y) || 1, px = main.x + (S / 2 - main.x) / dl * 15, py = main.y + (S / 2 - main.y) / dl * 15;
    for (let c = 0; c < W.N; c++) if (map.ter[c] === 4) { const x = c % S + 0.5, y = ((c / S) | 0) + 0.5, d = hyp(x - px, y - py); if (d < 9 && d < bd) { bd = d; best = [x, y]; } }
    return best;
  }
  function findSite(W, s, main) {
    let best = null, bd = 1e9; const T = W.tm[s];
    for (const q of W.map.sites) {
      if (W.blds.some((b) => !b.dead && hyp(b.x - q.x, b.y - q.y) < 5)) continue;
      if (W.units.some((u) => !u.dead && W.tm[u.o] !== T && UN[u.t].dm > 0 && hyp(u.x - q.x, u.y - q.y) < 9 && W.vis[T][cellOf(W, u.x, u.y)])) continue;
      if (!W.nodes.some((n) => n.a > 0 && hyp(n.x - q.x, n.y - q.y) < 8)) continue;
      const d = hyp(q.x - main.x, q.y - main.y); if (d < bd && canPlace(W, FAC[facOf(W, s)].b[0], q.x - 2, q.y - 2, s, 0, true)) { bd = d; best = [q.x - 2, q.y - 2]; }
    }
    return best;
  }
  function findSpot(W, s, bt, main, rp) {
    const sz = BD[bt].sz; let ndx = 0, ndy = 0;
    for (const q of W.nodes) if (q.a > 0 && hyp(q.x - main.x, q.y - main.y) < 9) { ndx += q.x - main.x; ndy += q.y - main.y; }
    const nl = hyp(ndx, ndy) || 1; ndx /= nl; ndy /= nl;
    const ra = Math.atan2(rp[1] - main.y, rp[0] - main.x);
    const tw = !!BD[bt].wpn;
    for (let r = tw ? 5 : 4; r <= 13; r++) {
      const a0 = Math.random() * 6.283;
      for (let k = 0; k < 16; k++) {
        let a = a0 + k * 0.3927;
        if (tw) a = ra + (k / 15 - 0.5) * 1.6;
        const px = main.x + Math.cos(a) * r, py = main.y + Math.sin(a) * r;
        if (!tw && (px - main.x) * ndx + (py - main.y) * ndy > r * 0.25) continue;
        const tx = Math.round(px - sz / 2), ty = Math.round(py - sz / 2);
        if (canPlace(W, bt, tx, ty, s, 1, true)) return [tx, ty];
      }
    }
    return null;
  }
  function pickBuilder(W, wk, spot, scout) {
    let best = null, bd = 1e9;
    for (const u of wk) {
      if (u.i === scout || u.s === 'b' || u.s === 'c') continue;
      const d = hyp(u.x - spot[0], u.y - spot[1]) + (u.s === 'g' && u.gs === 1 ? 3 : 0) + (u.cr ? 2 : 0);
      if (d < bd) { bd = d; best = u; }
    }
    return best;
  }
  function chooseUnit(bt, lv, m, bd, foeTw, rich, oreRich) {
    const opts = BD[bt].tr.filter((t) => !UN[t].cap && !UN[t].mb && (UN[t].req < 0 || bd[UN[t].req] > 0));
    if (!opts.length) return -1;
    const e = m.seen, k = lv === 1 ? 0 : lv === 2 ? 0.5 : 1;
    let wt;
    {
      wt = {}; let tot = 0; for (let i = 0; i < e.length; i++) if (e[i] > 0.05 && !UN[i].w) tot += e[i] * ucost(i);
      for (const t of opts) {
        const D = UN[t]; let sc = 0;
        for (let i = 0; i < e.length; i++) {
          if (e[i] <= 0.05 || UN[i].w) continue;
          const E = UN[i], v = e[i] * ucost(i);
          let term = (D.bo[E.tag] || 1) - 1 - ((E.bo[D.tag] || 1) - 1) * 0.5;
          if (E.air) term += D.aa ? 0.5 : -0.8;
          sc += v * term;
        }
        if (D.bo.bld) sc += foeTw * 60 * (D.bo.bld - 1);
        wt[t] = (AW[D.k] || 1) * Math.max(0.2, 1 + k * 2 * sc / Math.max(300, tot));
      }
    }
    if (rich && lv >= 2) for (const t of opts) if (UN[t].c[1] > 0) wt[t] = (wt[t] || 1) * 1.7;
    if (oreRich && lv >= 2) for (const t of opts) if (UN[t].c[1] <= UN[t].c[0] * 0.2) wt[t] = (wt[t] || 1) * 2;
    let sum = 0; for (const t of opts) sum += Math.max(0.2, wt[t]);
    let r = Math.random() * sum; for (const t of opts) { r -= Math.max(0.2, wt[t]); if (r <= 0) return t; }
    return opts[0];
  }
  // 어려움 미세 조작: 원거리 유닛은 붙어 오는 근접 적에게서 한 발 물러나며 쏴요(카이팅)
  function aiMicro(W, s, m, army, foes, t) {
    for (const u of army) {
      if (!u.tg || m.mic[u.i] > t) continue;
      const D = UN[u.t]; if (D.dm <= 0 || D.hero) continue;
      const cur = W.E.get(u.tg); if (!alive(cur) || cur.isB) continue;
      // kite: ranged & not slower than the melee foe right next to it
      if (D.rg >= 4 && u.cd > 0.25) {
        let mel = null; for (const f of foes) if (UN[f.t].rg < 1.5 && UN[f.t].dm > 0 && canHit(UN[f.t], u) && edgeD(u, f) < 1.2 && UN[f.t].sp <= D.sp + 0.3) { mel = f; break; }
        if (mel) { const dx = u.x - mel.x, dy = u.y - mel.y, dl = hyp(dx, dy) || 1; cmd(W, s, ['m', Math.round((u.x + dx / dl * 2) * 10), Math.round((u.y + dy / dl * 2) * 10), 0, [u.i]]); m.mic[u.i] = t + 0.7; continue; }
      }
    }
  }
  // drop raid: load 4 infantry, fly around the edge, set them down at the enemy's mining line
  function aiDrop(W, s, lv, m, army, tps, main) {
    const t = W.t, T = W.tm[s], dr = m.dr;
    const tp = dr ? W.E.get(dr.tp) : tps[0];
    if (dr && !alive(tp)) { m.dr = null; m.drN = t + (lv === 3 ? 220 : 1e9); return null; }
    if (!dr) {
      if (!tp || t < m.drN || m.mode === 'd' || m.turtle) return null;
      const inf = army.filter((u) => UN[u.t].cls === 'i' && (u.s === 'i' || u.s === 'h') && hyp(u.x - m.rp[0], u.y - m.rp[1]) < 10)
        .sort((a, b) => (b.t === 2) - (a.t === 2) || hyp(a.x - tp.x, a.y - tp.y) - hyp(b.x - tp.x, b.y - tp.y)).slice(0, CAP);
      if (inf.length < 3) return null;
      // target: a known enemy HQ, else an enemy start
      let best = null, bd = 1e9;
      for (const k of m.kb.values()) if (BD[k.t].hq) { const d = hyp(k.x - main.x, k.y - main.y); if (d < bd) { bd = d; best = k; } }
      if (!best) { const sp = W.map.spawn.find((q, i) => W.tm[i] !== T && W.pl[i].alive); if (sp) best = sp; }
      if (!best) return null;
      // drop point: behind the HQ (away from the map centre) — where the workers mine
      const S = W.S; let ax = best.x - S / 2, ay = best.y - S / 2; const al = hyp(ax, ay) || 1; ax /= al; ay /= al;
      let dx = best.x + ax * 4.5, dy = best.y + ay * 4.5;
      for (let k = 0; k < 8 && !passC(W, cellOf(W, dx, dy)); k++) { dx -= ax * 0.6; dy -= ay * 0.6; }
      // waypoint: the corner of an L-shaped route that stays nearer the map edge
      const w1 = [dx, main.y], w2 = [main.x, dy], ed = (q) => Math.min(q[0], q[1], S - q[0], S - q[1]);
      const wp = ed(w1) < ed(w2) ? w1 : w2;
      m.dr = { tp: tp.i, crew: inf.map((u) => u.i), ph: 0, t0: t, x: dx, y: dy, wx: clamp(wp[0], 2, S - 2), wy: clamp(wp[1], 2, S - 2), hx: best.x, hy: best.y };
      cmd(W, s, ['m', Math.round(inf[0].x * 10), Math.round(inf[0].y * 10), 0, [tp.i]]);
      for (const u of inf) cmd(W, s, ['k', tp.i, [u.i]]);
      return new Set(m.dr.crew);
    }
    const crew = new Set(dr.crew);
    if (dr.ph === 0) { // loading
      const live = dr.crew.map((id) => W.E.get(id)).filter(alive);
      const waiting = live.filter((u) => !u.in && u.s === 'l');
      if ((!waiting.length && tp.cg > 0) || t - dr.t0 > 25) {
        if (!tp.cg) { m.dr = null; m.drN = t + 60; return null; }
        for (const u of live) if (!u.in) { crew.delete(u.i); }
        dr.ph = 1; cmd(W, s, ['m', Math.round(dr.wx * 10), Math.round(dr.wy * 10), 0, [tp.i]]);
      }
      return crew;
    }
    if (dr.ph === 1) { // to the waypoint, then to the drop point
      if (hyp(tp.x - dr.wx, tp.y - dr.wy) < 1.2 || tp.s === 'i') { dr.ph = 2; cmd(W, s, ['u', [tp.i], Math.round(dr.x * 10), Math.round(dr.y * 10)]); }
      return crew;
    }
    if (dr.ph === 2) {
      if (tp.cg === 0 || (tp.s === 'i' && hyp(tp.x - dr.x, tp.y - dr.y) < 1)) {
        if (tp.cg) cmd(W, s, ['u', [tp.i]]);
        const down = dr.crew.map((id) => W.E.get(id)).filter((u) => alive(u) && !u.in);
        if (down.length) cmd(W, s, ['m', Math.round(dr.hx * 10), Math.round(dr.hy * 10), 1, down.map((u) => u.i)]);
        cmd(W, s, ['m', Math.round(m.rp[0] * 10), Math.round(m.rp[1] * 10), 0, [tp.i]]);
        dr.ph = 3; dr.t0 = t;
      }
      return crew;
    }
    // raiders fight on their own for a while
    if (t - dr.t0 > 40) { m.dr = null; m.drN = t + (lv === 3 ? 220 : 1e9); return null; }
    return crew;
  }
  function aiNomad(W, s, lv, m, bl, hqs, mbs) { // 고철: move packed bases to a free site and unfold; pack mined-out bases
    for (const u of mbs) {
      let g = m.mbGo && m.mbGo.id === u.i ? m.mbGo : null;
      if (!g) { const site = findSite(W, s, u); g = m.mbGo = site ? { id: u.i, x: site[0] + 2, y: site[1] + 2, t: W.t, n: 0 } : { id: u.i, x: u.x, y: u.y, t: W.t, n: 0 }; }
      const d = hyp(u.x - g.x, u.y - g.y);
      if (d < 1.2 || (u.s === 'i' && d < 6)) {
        if (cmd(W, s, ['dp', u.i])) { m.mbGo = null; continue; }
        g.n++; const a = g.n * 2.4; g.x = clamp(g.x + Math.cos(a) * 1.5, 3, W.S - 3); g.y = clamp(g.y + Math.sin(a) * 1.5, 3, W.S - 3);
        if (g.n > 12) m.mbGo = null;
      }
      if (u.s !== 'm' && m.mbGo) cmd(W, s, ['m', Math.round(g.x * 10), Math.round(g.y * 10), 0, [u.i]]);
    }
    if (lv >= 2 && !mbs.length && W.t > 240) for (const h of hqs) {
      if (h.q.length) continue;
      let left = 0; for (const q of W.nodes) if (q.a > 0 && hyp(h.x - q.x, h.y - q.y) < 9) left += q.a;
      if (left === 0 && findSite(W, s, h)) { cmd(W, s, ['pk', h.i]); break; }
    }
    return !bl.length;
  }
  function aiThink(W, s, lv, m, macro) { // macro: shared faction with an active human — economy/production only, army left to the human
    const P = W.pl[s]; if (!P.alive || W.over) return;
    const T = W.tm[s], V = W.vis[T], t = W.t, fa = facOf(W, s), F = FAC[fa], FB = F.b;
    const wk = [], army = [], tps = [], mbs = [], bl = [], bc = [0, 0, 0, 0, 0, 0], bd = [0, 0, 0, 0, 0, 0], bdg = new Array(BD.length).fill(0);
    for (const u of W.units) if (!u.dead && u.o === s && !u.in && !u.wv) (isW(u.t) ? wk : u.t === TP ? tps : UN[u.t].mb ? mbs : army).push(u);
    for (const b of W.blds) if (!b.dead && b.o === s) { bl.push(b); const ro = BD[b.t].ro; bc[ro]++; if (b.done) { bd[ro]++; bdg[b.t]++; } }
    for (const u of wk) if (u.s === 'b') bc[BD[u.bt].ro]++;
    const hqs = bl.filter((b) => BD[b.t].hq && b.done), main = bl.find((b) => BD[b.t].hq) || bl[0] || mbs[0];
    if (!main) return;
    if (fa === 3 && aiNomad(W, s, lv, m, bl, hqs, mbs)) return;
    if (!bl.length) return;
    // intel
    let foeTw = 0;
    for (const b of W.blds) if (!b.dead && W.tm[b.o] !== T && bVis(W, T, b)) { m.kb.set(b.i, { x: b.x, y: b.y, t: b.t }); if (BD[b.t].wpn) foeTw++; }
    for (const [id] of m.kb) { const e = W.E.get(id); if (!alive(e)) m.kb.delete(id); }
    const sn = new Array(UN.length).fill(0), foes = [];
    for (const u of W.units) if (!u.dead && W.tm[u.o] !== T && V[cellOf(W, u.x, u.y)] && !hidU(W, T, u)) { sn[u.t]++; foes.push(u); }
    for (let i = 0; i < sn.length; i++) m.seen[i] = Math.max(m.seen[i] * 0.985, sn[i]);
    let reserve = [0, 0], asup = 0; for (const u of army) asup += UN[u.t].sup;
    const tryBuild = (ro, near) => {
      const bt = FB[ro], B = BD[bt];
      if (P.ore < B.c[0] || P.cry < B.c[1]) { if (lv >= 2 && asup >= Math.min(24, t / 22)) reserve = [B.c[0] * (lv === 3 ? 0.8 : 0.5), B.c[1] * (lv === 3 ? 0.8 : 0.5)]; return false; }
      let spot = ro === 0 ? findSite(W, s, main) : findSpot(W, s, bt, near || main, m.rp);
      if (!spot && ro !== 0 && !near) { for (const h of hqs) if (h !== main && (spot = findSpot(W, s, bt, h, m.rp))) break; }
      if (!spot) { if (fa === 2 && ro !== 1 && ro !== 0 && bc[1] - bd[1] === 0) return tryBuild(1); return false; }
      const w = pickBuilder(W, wk, spot, m.scout); if (!w) return false;
      return cmd(W, s, ['b', bt, spot[0], spot[1], w.i]);
    };
    // workers
    let nW = wk.length; for (const h of hqs) for (const it of h.q) if (it[0] === 'u' && isW(it[1])) nW++;
    const wT = Math.min([0, 11, 15, 20][lv] * Math.max(1, hqs.length), [0, 18, 32, 54][lv]);
    for (const h of hqs) if (h.q.length < (lv === 3 ? 2 : 1) && nW < wT && P.ore >= UN[F.w].c[0]) { if (cmd(W, s, ['t', h.i, F.w])) nW++; }
    // supply
    const free = P.cap - P.used, sdb = bc[1] - bd[1];
    if (P.cap < 100 && free < [0, 2, 3, 3][lv] + hqs.length + 2 * (bd[2] + bd[3]) + (fa === 1 ? 2 : 0) && (sdb === 0 || (lv === 3 && sdb < 2 && free < 3))) tryBuild(1);
    // build plan
    let planDone = true;
    for (const [ro, n, w, tm] of PLANF[fa][lv]) {
      if (bc[ro] >= n) continue;
      planDone = false;
      const req = BD[FB[ro]].req;
      if (wk.length < w || t < tm || (req >= 0 && !bdg[req])) break;
      tryBuild(ro); break;
    }
    if (planDone && lv >= 2) {
      let left = 0; for (const q of W.nodes) if (q.a > 0 && hqs.some((h) => hyp(h.x - q.x, h.y - q.y) < 9)) left += q.a;
      if ((left < 3500 || P.ore > 900) && bc[0] - bd[0] === 0 && bc[0] < 5 && !mbs.length) tryBuild(0);
      else if (P.ore > 500 && bc[2] < (lv === 3 ? 4 : 3) + (fa === 1 ? 1 : 0)) tryBuild(2);
      else if (P.ore > 450 && P.cry > 250 && bc[3] < 3) tryBuild(3);
    }
    // 성광: forward pillar (warp-in point) toward the map centre
    if (fa === 2 && lv >= 2 && !m.fwd && t > (lv === 3 ? 280 : 380) && bd[2] && P.ore >= 160 && !m.turtle) {
      const S = W.S, fx = main.x + (S / 2 - main.x) * 0.55, fy = main.y + (S / 2 - main.y) * 0.55;
      const spot = findSpot(W, s, FB[1], { x: fx, y: fy }, [S / 2, S / 2]);
      if (spot) { const w = pickBuilder(W, wk, spot, m.scout); if (w && cmd(W, s, ['b', FB[1], spot[0], spot[1], w.i])) m.fwd = spot; } else m.fwd = [0, 0];
    }
    // research
    const UG = UPGF[fa];
    if (lv >= 2 || t > 520) for (const b of bl) {
      if (!BD[b.t].rs || !b.done || b.q.length) continue;
      for (const v of [0, 2, 1, 3]) {
        const lvl = P.up[v]; if (lvl >= 2 || bl.some((o) => o.q.some((it) => it[0] === 'r' && it[1] === v))) continue;
        const c = UG[v].c[lvl]; if (P.ore - reserve[0] >= c[0] + (lv === 1 ? 150 : 0) && P.cry - reserve[1] >= c[1]) cmd(W, s, ['r', b.i, v]);
        break;
      }
    }
    // transport (drops, 철강 only): 어려움 sometimes, 보통 once late; never while the main army is tiny
    const wantTp = fa === 0 && !m.turtle && (lv === 3 || (lv === 2 && m.drN < 1e8)) && t >= m.drN - 40 && bd[3] && bd[4] && army.length >= 6;
    if (wantTp && !macro && !tps.length && !bl.some((b) => b.q.some((it) => it[0] === 'u' && it[1] === TP))) {
      const f = bl.find((b) => b.t === 3 && b.done && b.q.length < 2);
      if (f && P.ore >= UN[TP].c[0] && P.cry >= UN[TP].c[1]) cmd(W, s, ['t', f.i, TP]);
    }
    // army production
    for (const b of bl) {
      const ro = BD[b.t].ro;
      if (!b.done || (ro !== 2 && ro !== 3) || b.q.length >= (lv === 3 ? 2 : 1)) continue;
      const ut = chooseUnit(b.t, lv, m, bdg, foeTw, P.cry > 300 + reserve[1], P.ore > 400 + reserve[0] && P.cry < 120); if (ut < 0) continue;
      const D = UN[ut]; if (P.ore - reserve[0] < D.c[0] || P.cry - reserve[1] < D.c[1]) continue;
      cmd(W, s, ['t', b.i, ut]);
    }
    // 영웅: call once the barracks stands (and again after the respawn wait)
    const HT = HERO0 + fa, hero = army.find((u) => UN[u.t].hero);
    if (!W.mis && !hero && t >= HERO_T[lv] * m.hj && bd[2] && hqs.length && heroWhyW(W, s) === '' && P.ore >= UN[HT].c[0] && P.cry >= UN[HT].c[1]) {
      const h = hqs.find((b) => b.q.length < 2); if (h) cmd(W, s, ['t', h.i, HT]);
    }
    if (hero && !macro && t >= P.hk && (lv > 1 || Math.random() < 0.5)) {
      let go = false; const near6 = (fn) => { let n = 0; for (const e of W.units) if (!e.dead && !e.in && fn(e) && hyp(e.x - hero.x, e.y - hero.y) <= 6) n++; return n; };
      const foeN = near6((e) => W.tm[e.o] !== T && UN[e.t].dm > 0 && V[cellOf(W, e.x, e.y)] && !hidU(W, T, e));
      if (fa === 0) { const e = hero.tg ? W.E.get(hero.tg) : null; if (alive(e)) { let n = 0; for (const f of foes) if (hyp(f.x - e.x, f.y - e.y) < 2.8) n++; go = n >= 2 || e.isB || ucost(e.t) >= 150; } }
      else if (fa === 1) go = foeN >= 2 && !!hero.tg;
      else if (fa === 2) go = foeN >= 1 && (near6((e) => W.tm[e.o] === T && e.msh && e.sh < e.msh * 0.5) >= 2 || hero.sh < hero.msh * 0.3);
      else go = foeN >= 2 && !!hero.tg && near6((e) => W.tm[e.o] === T && !isW(e.t) && UN[e.t].dm > 0) >= 3;
      if (go) cmd(W, s, ['hs', hero.i]);
    }
    // 고철: 개조 when rich (units near the 정비소)
    if (fa === 3 && lv >= 2 && P.ore > 350 && m.mode !== 'a') {
      const shop = bl.find((b) => BD[b.t].mod && b.done);
      if (shop) {
        const cand = army.filter((u) => !u.md && !u.tg && UN[u.t].c[0] + UN[u.t].c[1] >= 75);
        const inR = cand.filter((u) => hyp(u.x - shop.x, u.y - shop.y) <= BD[shop.t].mod + 1);
        if (inR.length) cmd(W, s, ['v', inR.map((u) => u.i)]);
        else { const go = cand.filter((u) => u.s === 'i' || u.s === 'h').slice(0, 4); if (go.length) cmd(W, s, ['m', Math.round(shop.x * 10), Math.round((shop.y + 2.5) * 10), 0, go.map((u) => u.i)]); }
      }
    }
    // resume abandoned construction
    for (const b of bl) if (!b.done && BD[b.t].fa !== 2 && b.wk < t - 3 && !wk.some((u) => u.s === 'c' && u.bd === b.i)) { const w = pickBuilder(W, wk, [b.x, b.y], m.scout); if (w) cmd(W, s, ['k', b.i, [w.i]]); }
    // idle workers back to mining (balanced)
    const wc = new Int16Array(W.nodes.length); for (const u of wk) if (u.s === 'g' && u.nd >= 0) wc[u.nd]++;
    for (const u of wk) {
      if (u.s !== 'i' || u.i === m.scout) continue;
      let best = -1, bs = 1e9;
      for (let i = 0; i < W.nodes.length; i++) {
        const q = W.nodes[i]; if (q.a <= 0 || !hqs.some((h) => hyp(h.x - q.x, h.y - q.y) < 9)) continue;
        const sc = hyp(u.x - q.x, u.y - q.y) * 0.3 + wc[i] * 4 + (q.k ? (wc[i] >= 2 || P.cry > P.ore + 150 ? 10 : (lv === 1 ? 2 : -1)) : 0);
        if (sc < bs) { bs = sc; best = i; }
      }
      if (best >= 0) { cmd(W, s, ['g', best, [u.i]]); wc[best]++; }
    }
    // too much crystal banked → move a crystal miner to ore (and back when crystal runs dry)
    if (lv >= 2 && P.cry > 350 && P.cry > P.ore * 1.5) {
      const u = wk.find((w) => w.s === 'g' && w.gs !== 1 && W.nodes[w.nd] && W.nodes[w.nd].k === 1 && w.i !== m.scout);
      if (u) { const nd = nearNode(W, u.x, u.y, 12, -1, 0, false); if (nd >= 0) cmd(W, s, ['g', nd, [u.i]]); }
    }
    // scouting
    const foeSp = W.map.spawn.filter((q, i) => W.tm[i] !== T);
    if (!m.scDone && t > (lv === 3 ? 45 : 75)) {
      let sc = m.scout ? W.E.get(m.scout) : null;
      if (m.scout && !alive(sc)) { m.scDone = true; sc = null; }
      else if (!sc) { sc = wk.find((u) => u.s === 'g' && u.gs === 0 && !u.cr); if (sc) m.scout = sc.i; }
      if (sc) {
        const left = foeSp.filter((q) => !m.chk.has(q.x * 1000 + q.y));
        for (const q of left) if (V[cellOf(W, q.x, q.y)]) m.chk.add(q.x * 1000 + q.y);
        const rest = left.filter((q) => !m.chk.has(q.x * 1000 + q.y));
        if (!rest.length) { m.scDone = true; m.scout = 0; const nd = nearNode(W, main.x, main.y, 10, -1, 0, false); if (nd >= 0) cmd(W, s, ['g', nd, [sc.i]]); }
        else if (sc.s !== 'm') { rest.sort((a, b) => hyp(a.x - sc.x, a.y - sc.y) - hyp(b.x - sc.x, b.y - sc.y)); cmd(W, s, ['m', rest[0].x * 10, rest[0].y * 10, 0, [sc.i]]); }
      }
    }
    // army
    if (macro) return;
    if (lv === 3 && foes.length) aiMicro(W, s, m, army, foes, t);
    const crew = aiDrop(W, s, lv, m, army, tps, main);
    const am = crew ? army.filter((u) => !crew.has(u.i)) : army; let sup = 0; for (const u of am) sup += ucost(u.t) / 50; // army size in 'rifle equivalents' (value-based, fair across factions)
    const ids = (a) => a.map((u) => u.i);
    let thx = 0, thy = 0, thn = 0;
    const foeWk = foes.filter((f) => isW(f.t) && bl.some((b) => hyp(f.x - b.x, f.y - b.y) < 12)).length;
    for (const f of foes) { if (UN[f.t].dm <= 0 || (isW(f.t) && foeWk < 3)) continue; if (bl.some((b) => hyp(f.x - b.x, f.y - b.y) < 12)) { thx += f.x; thy += f.y; thn++; } }
    const late = t > 720;
    if (thn > 0) m.thc++; else m.thc = 0;
    if (thn > 0 && (lv > 1 || m.thc > 1)) {
      const x = thx / thn, y = thy / thn;
      const awayAtk = m.mode === 'a' && am.length && hyp(am[0].x - main.x, am[0].y - main.y) > 30 && thn < 3;
      if (!awayAtk) {
        const send = am.filter((u) => !u.tg && u.s !== 'k');
        if (send.length) cmd(W, s, ['m', Math.round(x * 10), Math.round(y * 10), 1, ids(send)]);
        if (m.mode !== 'a') m.mode = 'd';
      }
      if (!am.length && thn <= 4 && lv >= 2 && !(W.mis && W.mis.op === 2)) { const ws = wk.filter((u) => u.s !== 'c' && u.s !== 'b' && u.i !== m.scout && hyp(u.x - x, u.y - y) < 12).slice(0, 6); if (ws.length) cmd(W, s, ['m', Math.round(x * 10), Math.round(y * 10), 1, ids(ws)]); }
    }
    if (m.mode !== 'a') {
      if (m.mode === 'd' && thn === 0) m.mode = 'b';
      let fv = 0, mv0 = 0; if (lv >= 2) { for (let i = 0; i < m.seen.length; i++) if (!UN[i].w) fv += m.seen[i] * ucost(i); for (const u of am) mv0 += ucost(u.t) * u.hp / u.mhp; }
      if (am.length && (sup >= m.thr || P.used >= 92 || (late && sup >= 10)) && t >= m.tmin && t >= m.cool && (lv < 2 || P.used >= 92 || late || mv0 >= fv * (lv === 3 ? 1.0 : 0.85))) { m.mode = 'a'; m.waves++; }
      else if (thn === 0) {
        let gar = null;
        if (lv >= 2 && am.length >= 6) { // 지형 활용: 원거리 몇 명을 가까운 고지(언덕)나 수풀 매복 자리에 세워 둬요
          if (m.post === undefined) m.post = postSpot(W, main, lv);
          if (m.post) {
            gar = new Set((m.gar || []).filter((i) => am.some((u) => u.i === i)));
            for (const u of am) { if (gar.size >= 3) break; if (!gar.has(u.i) && UN[u.t].rg >= 3 && !UN[u.t].hero && !u.tg) gar.add(u.i); }
            m.gar = [...gar];
            const go = am.filter((u) => gar.has(u.i) && (u.s === 'i' || u.s === 'h') && !u.tg && hyp(u.x - m.post[0], u.y - m.post[1]) > 1.8);
            if (go.length) cmd(W, s, ['m', Math.round(m.post[0] * 10), Math.round(m.post[1] * 10), 1, ids(go)]);
          }
        }
        const idle = am.filter((u) => (u.s === 'i' || u.s === 'h') && !u.tg && hyp(u.x - m.rp[0], u.y - m.rp[1]) > 5 && !(gar && gar.has(u.i)));
        if (idle.length) cmd(W, s, ['m', Math.round(m.rp[0] * 10), Math.round(m.rp[1] * 10), 1, ids(idle)]);
      }
    }
    if (m.mode !== 'a') { if (m.rlA) { m.rlA = 0; for (const b of W.blds) if (!b.dead && b.o === s && b.done && (BD[b.t].ro === 2 || BD[b.t].ro === 3)) cmd(W, s, ['p', b.i, Math.round(m.rp[0] * 10), Math.round(m.rp[1] * 10), -1]); } return; }
    if (!am.length) { m.mode = 'b'; m.thr = Math.min(m.thr + [0, 4, 5, 6][lv], late ? 14 : [0, 30, 40, 46][lv]); return; }
    let cx = 0, cy = 0; for (const u of am) { cx += u.x; cy += u.y; } cx /= am.length; cy /= am.length;
    if (lv >= 2 && !late) {
      let ev = 0, mv = 0;
      for (const f of foes) if (UN[f.t].dm > 0 && hyp(f.x - cx, f.y - cy) < 11) ev += ucost(f.t) * f.hp / f.mhp;
      for (const b of W.blds) if (!b.dead && BD[b.t].wpn && W.tm[b.o] !== T && hyp(b.x - cx, b.y - cy) < 11 && bVis(W, T, b)) ev += 150;
      for (const u of am) if (hyp(u.x - cx, u.y - cy) < 11) mv += ucost(u.t) * u.hp / u.mhp;
      const home = hyp(cx - main.x, cy - main.y) < 16;
      if ((!home && ev > 0 && mv < ev * (lv === 3 ? 0.7 : 0.5)) || sup < m.thr * 0.3) {
        cmd(W, s, ['m', Math.round(m.rp[0] * 10), Math.round(m.rp[1] * 10), 0, ids(am)]);
        m.mode = 'b'; m.cool = t + 25; m.thr = Math.min(m.thr + 5, [0, 30, 40, 46][lv]); return;
      }
    }
    // target: known structure → enemy start → unexplored sites
    let tg = null, bdd = 1e9;
    for (const k of m.kb.values()) { const d = hyp(k.x - cx, k.y - cy); if (d < bdd) { bdd = d; tg = [k.x, k.y]; } }
    if (!tg) {
      const cand = foeSp.concat(W.map.sites.filter((q) => !q.sp));
      for (let i = 0; i < cand.length; i++) { const q = cand[(m.exi + i) % cand.length]; if (hyp(q.x - cx, q.y - cy) < 6 || (V[cellOf(W, q.x, q.y)] && !m.kb.size)) continue; tg = [q.x, q.y]; m.exi = (m.exi + i) % cand.length; break; }
      if (tg && hyp(tg[0] - cx, tg[1] - cy) < 6) m.exi++;
      if (!tg) { m.exi++; tg = [W.S / 2, W.S / 2]; }
    }
    const far = [], go = [];
    for (const u of am) {
      if (m.mic[u.i] > t) continue;
      if (lv >= 2 && hyp(u.x - cx, u.y - cy) > 12 && hyp(u.x - tg[0], u.y - tg[1]) > hyp(cx - tg[0], cy - tg[1])) { if (u.s !== 'a' || hyp(u.tx - cx, u.ty - cy) > 4) far.push(u); }
      else if (u.s === 'i' || u.s === 'm' || u.s === 'h' || (u.s === 'a' && !u.tg && hyp(u.tx - tg[0], u.ty - tg[1]) > 4)) go.push(u);
    }
    if (far.length) cmd(W, s, ['m', Math.round(cx * 10), Math.round(cy * 10), 1, ids(far)]);
    if (go.length) cmd(W, s, ['m', Math.round(tg[0] * 10), Math.round(tg[1] * 10), 1, ids(go)]);
    if (fa === 2 && lv >= 2 && t > m.rl) { m.rl = t + 8; m.rlA = 1; for (const b of W.blds) if (!b.dead && b.o === s && b.done && (BD[b.t].ro === 2 || BD[b.t].ro === 3)) cmd(W, s, ['p', b.i, Math.round(cx * 10), Math.round(cy * 10), -1]); }
    if (lv === 3) for (const u of am) {
      if (u.hp > u.mhp * 0.35 || !u.tg || UN[u.t].sp < 2.3 || UN[u.t].rg < 2 || u.msh) continue; // melee and shielded units keep fighting
      const e = W.E.get(u.tg); if (!alive(e) || e.isB || hyp(e.x - u.x, e.y - u.y) > 5) continue;
      const dx = m.rp[0] - u.x, dy = m.rp[1] - u.y, dl = hyp(dx, dy) || 1;
      cmd(W, s, ['m', Math.round((u.x + dx / dl * 3) * 10), Math.round((u.y + dy / dl * 3) * 10), 0, [u.i]]); m.mic[u.i] = t + 2.5;
    }
  }

  /* ---------------- coarse state ---------------- */
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    if (o.mode === 1) { // 작전: 1 commander (first human seat) vs 1 enemy AI; mission picked on the briefing screen
      const cm = Math.max(0, players.findIndex((p) => p && !p.ai)), en = 1 - cm;
      return {
        rid: 1 + U.rand(99999), n: 2, nm: players.slice(0, 2).map((p) => String((p && p.name) || '').slice(0, 10)), team: 0,
        th: [0, 1, 2, 3].includes(o.map) ? o.map : U.rand(THEMES.length), T: 0, sd: 1 + U.rand(2147483646), ph: 'brief', win: null, why: '', sc: null,
        mode: 1, op: 0, cm: Math.min(1, cm), lvE: (players[en] && players[en].lv) || 2, fa: [0, 0],
      };
    }
    const sh = n === 4 && o.team !== 0 && o.team !== 1 ? 1 : 0, own = sh ? 2 : n, hum = players.some((p) => p && !p.ai);
    return {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      team: n === 4 && o.team !== 0 ? 1 : 0, sh, th: [0, 1, 2, 3].includes(o.map) ? o.map : U.rand(THEMES.length),
      T: [20, 30].includes(o.time) ? o.time * 60 : 0, sd: 1 + U.rand(2147483646), ph: hum ? 'pick' : 'play', win: null, why: '', sc: null,
      fa: hum ? null : Array.from({ length: own }, () => U.rand(FAC.length)), pk: players.map(() => -1), rd: players.map((p) => (p && !p.ai ? 0 : 1)), pc: PICK_T,
    };
  }
  const PICK_T = 20;
  function pickResolve(st) { // 진영 확정: per owner, a human's explicit pick, else random
    const own = st.sh ? 2 : st.n, out = [];
    for (let o = 0; o < own; o++) {
      const seats = st.sh ? [o * 2, o * 2 + 1] : [o];
      let f = -1; for (const s2 of seats) if (st.pk && st.pk[s2] >= 0 && st.pk[s2] < FAC.length) { f = st.pk[s2]; break; }
      out.push(f >= 0 ? f : U.rand(FAC.length));
    }
    return out;
  }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.win)) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    if (s.mode === 1 && OPS[s.op]) {
      const ok = s.why === 'mo', tt = s.tt ? ' (' + Math.floor(s.tt / 60) + '분 ' + (s.tt % 60) + '초)' : '';
      const r = (s.sc || [])[s.cm] || [0, 0, 0, 0];
      const stats = [{ label: '유닛 생산', value: String(r[2]) }, { label: '처치', value: String(r[0]) }, { label: '손실', value: String(r[1]) }, { label: '자원 채굴', value: String(r[3]) }];
      return { winners: s.win, title: (ok ? '작전 성공! ' : '작전 실패 — ') + '작전 ' + s.op + ' · ' + OPS[s.op].nm, text: (s.mwhy || '') + tt + (ok && s.op < OPN ? '\n다음 작전 ' + (s.op + 1) + ' · ' + OPS[s.op + 1].nm + '이(가) 열렸어요' : ok ? '\n모든 작전을 끝냈어요!' : ''), stats };
    }
    const title = !s.win.length ? '무승부' : s.win.length > 1 ? s.win.map(nm).join(' · ') + ' 팀 승리!' : nm(s.win[0]) + ' 승리!';
    const why = s.why === 't' ? '시간 종료 — 남은 건물·군대 가치가 큰 쪽이 승리' : '적 건물을 모두 무너뜨렸어요';
    const lines = (s.sc || []).map((r, i) => nm(i) + '  처치 ' + r[0] + ' · 잃음 ' + r[1] + ' · 생산 ' + r[2] + ' · 채취 ' + r[3]);
    const sc = s.sc || [], col = (j) => sc.map((r) => String((r && r[j]) || 0));
    const stats = sc.length ? [{ label: '진영', values: sc.map((r, i) => (Array.isArray(s.fa) && FAC[s.fa[s.sh ? i >> 1 : i]] ? FAC[s.fa[s.sh ? i >> 1 : i]].sh : '-')) }, { label: '유닛 생산', values: col(2) }, { label: '처치', values: col(0) }, { label: '손실', values: col(1) }, { label: '자원 채굴', values: col(3) }] : undefined;
    return { winners: s.win, title, text: why + (s.tt ? ' (' + Math.floor(s.tt / 60) + '분 ' + (s.tt % 60) + '초)' : '') + (stats ? '' : '\n' + lines.join('\n')), stats };
  }

  /* ---------------- packing (host → guests) ---------------- */
  const b36 = (v, n) => { v = Math.max(0, Math.round(v)); let s = v.toString(36); if (s.length > n) s = 'z'.repeat(n); return s.length < n ? '0'.repeat(n - s.length) + s : s; };
  const d36 = (s, i, n) => parseInt(s.substr(i, n), 36) || 0;

  /* ---------------- view ---------------- */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  function rr(g, x, y, w, h, r) { r = Math.min(r, w / 2, h / 2); g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function dot(g, x, y, r) { g.beginPath(); g.arc(x, y, r, 0, 6.2832); g.fill(); }
  function shade(hex, k) { const n = parseInt(String(hex).slice(1), 16) || 0; let r = n >> 16, gg = (n >> 8) & 255, b = n & 255; if (k > 0) { r += (255 - r) * k; gg += (255 - gg) * k; b += (255 - b) * k; } else { r *= 1 + k; gg *= 1 + k; b *= 1 + k; } return 'rgb(' + (r | 0) + ',' + (gg | 0) + ',' + (b | 0) + ')'; }
  function unitGlyph(g, t, x, y, R, col, ang, cr, spin) {
    g.save(); g.translate(x, y);
    const lw = Math.max(1, R * 0.14), ol = 'rgba(10,8,14,.75)';
    if (UN[t] && UN[t].air) { g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.ellipse(R * 0.5, R * 1.2, R * 0.9, R * 0.45, 0, 0, 6.28); g.fill(); g.translate(0, -R * 0.55); }
    else { g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(R * 0.12, R * 0.4, R * 1.05, R * 0.72, 0, 0, 6.28); g.fill(); }
    g.rotate(ang); g.lineWidth = lw; g.strokeStyle = ol;
    if (t === 0) {
      if (cr) { g.fillStyle = cr === 2 ? CRY : ORE; g.fillRect(-R * 1.2, -R * 0.45, R * 0.6, R * 0.9); }
      g.fillStyle = '#5b5348'; g.fillRect(R * 0.3, R * 0.35, R * 0.95, R * 0.24);
      g.fillStyle = col; g.beginPath(); g.arc(0, 0, R, 0, 6.28); g.fill(); g.stroke();
      g.fillStyle = '#f2c14e'; g.beginPath(); g.arc(R * 0.1, 0, R * 0.55, 0, 6.28); g.fill();
    } else if (t === 1) {
      g.fillStyle = '#1d1b20'; g.fillRect(R * 0.2, -R * 0.13, R * 1.35, R * 0.26);
      g.fillStyle = col; g.beginPath(); g.arc(0, 0, R, 0, 6.28); g.fill(); g.stroke();
      g.fillStyle = shade(col, -0.45); g.beginPath(); g.arc(0, 0, R * 0.52, 0, 6.28); g.fill();
    } else if (t === 2) {
      g.fillStyle = '#d0702c'; rr(g, -R * 1.25, -R * 0.75, R * 0.6, R * 1.5, R * 0.28); g.fill(); g.stroke();
      g.fillStyle = '#2a2622'; g.fillRect(R * 0.2, -R * 0.16, R * 1.1, R * 0.32);
      g.fillStyle = col; g.beginPath(); g.arc(0, 0, R, 0, 6.28); g.fill(); g.stroke();
      g.fillStyle = '#efc36a'; g.beginPath(); g.arc(R * 0.15, 0, R * 0.42, 0, 6.28); g.fill();
    } else if (t === 3) {
      g.fillStyle = '#14120f'; g.fillRect(R * 0.1, -R * 0.09, R * 2.1, R * 0.18);
      g.fillStyle = shade(col, -0.25); g.beginPath(); g.arc(0, 0, R * 0.95, 0, 6.28); g.fill(); g.stroke();
      g.fillStyle = '#3c4a32'; g.beginPath(); g.arc(-R * 0.15, 0, R * 0.62, 0, 6.28); g.fill();
    } else if (t === 4) {
      g.fillStyle = '#1b1a1e'; for (const sx of [-0.75, 0.6]) for (const sy of [-1, 1]) g.fillRect(R * sx, sy * R * 0.62 - R * 0.17, R * 0.5, R * 0.34);
      g.fillStyle = col; rr(g, -R * 1.05, -R * 0.66, R * 2.1, R * 1.32, R * 0.32); g.fill(); g.stroke();
      g.fillStyle = shade(col, -0.35); rr(g, R * 0.2, -R * 0.4, R * 0.55, R * 0.8, R * 0.15); g.fill();
      g.fillStyle = '#26232a'; g.fillRect(-R * 0.1, -R * 0.1, R * 1.05, R * 0.2);
    } else if (t === 5) {
      g.fillStyle = '#1b1a1e'; g.fillRect(-R * 1.1, -R * 0.95, R * 2.2, R * 0.38); g.fillRect(-R * 1.1, R * 0.57, R * 2.2, R * 0.38);
      g.fillStyle = col; rr(g, -R * 1.05, -R * 0.7, R * 2.1, R * 1.4, R * 0.22); g.fill(); g.stroke();
      g.fillStyle = '#2b282e'; g.fillRect(R * 0.1, -R * 0.13, R * 1.75, R * 0.26);
      g.fillStyle = shade(col, -0.3); g.beginPath(); g.arc(-R * 0.1, 0, R * 0.5, 0, 6.28); g.fill(); g.stroke();
    } else if (t === 6) {
      g.strokeStyle = '#25232a'; g.lineWidth = R * 0.22; g.beginPath(); g.moveTo(-R, -R); g.lineTo(R, R); g.moveTo(R, -R); g.lineTo(-R, R); g.stroke();
      g.fillStyle = 'rgba(220,230,240,.28)'; for (const [a, b] of [[-1, -1], [1, 1], [1, -1], [-1, 1]]) { g.beginPath(); g.arc(a * R, b * R, R * 0.55, 0, 6.28); g.fill(); }
      g.strokeStyle = 'rgba(240,240,250,.6)'; g.lineWidth = Math.max(1, R * 0.08);
      for (const [a, b] of [[-1, -1], [1, 1], [1, -1], [-1, 1]]) { const q = spin + a * 1.3 + b; g.beginPath(); g.moveTo(a * R - Math.cos(q) * R * 0.5, b * R - Math.sin(q) * R * 0.5); g.lineTo(a * R + Math.cos(q) * R * 0.5, b * R + Math.sin(q) * R * 0.5); g.stroke(); }
      g.strokeStyle = ol; g.lineWidth = lw; g.fillStyle = col; g.beginPath(); g.arc(0, 0, R * 0.55, 0, 6.28); g.fill(); g.stroke();
      g.fillStyle = '#9fe8ff'; g.beginPath(); g.arc(R * 0.25, 0, R * 0.18, 0, 6.28); g.fill();
    } else if (t === TP) { // twin-rotor transport; cr = passengers (slots)
      g.fillStyle = col; rr(g, -R * 1.25, -R * 0.42, R * 2.5, R * 0.84, R * 0.4); g.fill(); g.stroke();
      g.fillStyle = shade(col, -0.4); g.fillRect(-R * 0.8, -R * 0.12, R * 1.5, R * 0.24);
      g.fillStyle = '#9fe8ff'; rr(g, R * 0.75, -R * 0.26, R * 0.38, R * 0.52, R * 0.12); g.fill();
      g.strokeStyle = 'rgba(240,240,250,.6)'; g.lineWidth = Math.max(1, R * 0.09);
      for (const ox of [-0.85, 0.85]) { const q = spin * (ox > 0 ? 1 : -1); g.beginPath(); g.moveTo(R * ox - Math.cos(q) * R * 0.95, -Math.sin(q) * R * 0.95); g.lineTo(R * ox + Math.cos(q) * R * 0.95, Math.sin(q) * R * 0.95); g.stroke(); }
      g.fillStyle = '#25232a'; for (const ox of [-0.85, 0.85]) { g.beginPath(); g.arc(R * ox, 0, R * 0.16, 0, 6.28); g.fill(); }
      if (cr) { g.rotate(-ang); g.fillStyle = '#f2e9d8'; for (let k = 0; k < Math.min(4, cr); k++) { g.beginPath(); g.arc((k - 1.5) * R * 0.36, R * 0.82, R * 0.13, 0, 6.28); g.fill(); } }
    } else facUnit(g, t, R, col, cr, spin, ol, lw);
    g.restore();
  }
  function poly(g, pts, R) { g.beginPath(); for (let i = 0; i < pts.length; i += 2) g.lineTo(pts[i] * R, pts[i + 1] * R); g.closePath(); }
  function circ2(g, x, y, r) { g.beginPath(); g.arc(x, y, r, 0, 6.2832); }
  // 군체: 둥근 생체 + 보라 등껍질 · 성광: 각진 금빛 형태 + 하늘빛 · 고철: 각진 녹슨 판 + 리벳
  function facUnit(g, t, R, col, cr, spin, ol, lw) {
    const k = UN[t].k, dk = shade(col, -0.4);
    if (UN[t].hero) { // 영웅: 금빛 고리 + 진영별 모습
      g.save(); g.strokeStyle = 'rgba(255,224,138,.85)'; g.lineWidth = Math.max(1.2, R * 0.12); g.setLineDash([R * 0.5, R * 0.3]); g.lineDashOffset = -spin * R * 0.2; circ2(g, 0, 0, R * 1.45); g.stroke(); g.restore();
      g.strokeStyle = ol; g.lineWidth = lw;
      if (k === 'h0') { // 강습 사령관: 넓은 어깨 갑옷 + 긴 소총 + 깃 안테나
        g.fillStyle = '#1d1b20'; g.fillRect(R * 0.2, -R * 0.14, R * 1.6, R * 0.28);
        g.fillStyle = shade(col, -0.2); rr(g, -R * 0.9, -R * 1.0, R * 1.3, R * 2.0, R * 0.35); g.fill(); g.stroke();
        g.fillStyle = col; circ2(g, 0, 0, R * 0.72); g.fill(); g.stroke();
        g.fillStyle = '#f2c14e'; poly(g, [0.35, 0, -0.1, -0.32, -0.45, 0, -0.1, 0.32], R); g.fill();
        g.strokeStyle = '#9fb2c4'; g.lineWidth = Math.max(1, R * 0.08); g.beginPath(); g.moveTo(-R * 0.6, -R * 0.7); g.lineTo(-R * 1.3, -R * 1.3); g.stroke(); g.fillStyle = '#ee6a55'; circ2(g, -R * 1.3, -R * 1.3, R * 0.14); g.fill();
      } else if (k === 'h1') { // 무리 여왕: 큰 배 + 날개 + 왕관 가시
        g.fillStyle = 'rgba(210,160,240,.35)'; for (const sy of [-1, 1]) { g.beginPath(); g.ellipse(-R * 0.3, sy * R * 0.9, R * 0.85, R * 0.4, sy * 0.5, 0, 6.28); g.fill(); }
        g.fillStyle = dk; g.beginPath(); g.ellipse(-R * 0.75, 0, R * 0.75, R * 0.6, 0, 0, 6.28); g.fill(); g.stroke();
        g.fillStyle = col; g.beginPath(); g.ellipse(R * 0.2, 0, R * 0.7, R * 0.6, 0, 0, 6.28); g.fill(); g.stroke();
        g.fillStyle = '#e8dcc0'; for (let i = -2; i <= 2; i++) { const a = i * 0.45; g.beginPath(); g.moveTo(R * 0.2 + Math.cos(a) * R * 0.5, Math.sin(a) * R * 0.5); g.lineTo(R * 0.2 + Math.cos(a) * R * 1.05, Math.sin(a) * R * 1.05); g.lineTo(R * 0.2 + Math.cos(a + 0.18) * R * 0.55, Math.sin(a + 0.18) * R * 0.55); g.fill(); }
        g.fillStyle = '#9bd84a'; circ2(g, R * 0.45, 0, R * 0.2); g.fill();
      } else if (k === 'h2') { // 빛의 집행관: 마름모 갑주 + 두 자루 빛날
        g.strokeStyle = '#bff3ff'; g.lineWidth = Math.max(1.5, R * 0.2); for (const sy of [-1, 1]) { g.beginPath(); g.moveTo(R * 0.2, sy * R * 0.6); g.lineTo(R * 1.75, sy * R * 0.35); g.stroke(); }
        g.strokeStyle = ol; g.lineWidth = lw; g.fillStyle = col; poly(g, [1.05, 0, 0.2, -0.95, -0.95, -0.5, -1.1, 0, -0.95, 0.5, 0.2, 0.95], R); g.fill(); g.stroke();
        g.fillStyle = '#f0d27a'; poly(g, [0.6, 0, 0, -0.5, -0.55, 0, 0, 0.5], R); g.fill(); g.fillStyle = '#ffffff'; circ2(g, R * 0.05, 0, R * 0.16); g.fill();
      } else { // 잔해 군벌: 철판 망토 + 화염 방사 팔 + 리벳
        g.fillStyle = '#4a3f35'; g.fillRect(R * 0.3, R * 0.25, R * 1.25, R * 0.36); g.fillStyle = '#ffb347'; circ2(g, R * 1.6, R * 0.43, R * 0.16); g.fill();
        g.fillStyle = shade(col, -0.25); poly(g, [0.2, -1.05, -1.1, -0.8, -1.25, 0, -1.1, 0.8, 0.2, 1.05], R); g.fill(); g.stroke();
        g.fillStyle = col; rr(g, -R * 0.65, -R * 0.65, R * 1.3, R * 1.3, R * 0.2); g.fill(); g.stroke();
        g.fillStyle = '#d0874a'; for (const [x, y] of [[-0.45, -0.45], [0.45, -0.45], [-0.45, 0.45], [0.45, 0.45]]) { circ2(g, x * R, y * R, R * 0.1); g.fill(); }
        g.fillStyle = '#7a6a58'; poly(g, [0.55, 0, 0.1, -0.3, 0.1, 0.3], R); g.fill();
      }
      return;
    }
    const carry = () => { if (cr) { g.fillStyle = cr === 2 ? CRY : ORE; g.fillRect(-R * 1.2, -R * 0.45, R * 0.6, R * 0.9); } };
    if (k === 'sw') {
      carry(); g.fillStyle = '#e8dcc0'; for (const sy of [-1, 1]) { g.beginPath(); g.moveTo(R * 0.6, sy * R * 0.25); g.lineTo(R * 1.25, sy * R * 0.12); g.lineTo(R * 0.7, sy * R * 0.5); g.fill(); }
      g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, R, R * 0.85, 0, 0, 6.28); g.fill(); g.stroke(); g.fillStyle = '#7c4a8c'; g.beginPath(); g.ellipse(-R * 0.2, 0, R * 0.5, R * 0.42, 0, 0, 6.28); g.fill();
    } else if (k === 'fg') {
      g.strokeStyle = dk; g.lineWidth = lw; for (const sy of [-1, 1]) for (const lx of [-0.4, 0.3]) { g.beginPath(); g.moveTo(R * lx, 0); g.lineTo(R * (lx - 0.3), sy * R * 1.05); g.stroke(); }
      g.strokeStyle = ol; g.fillStyle = col; poly(g, [1.3, 0, 0.3, -0.62, -1.1, -0.3, -1.1, 0.3, 0.3, 0.62], R); g.fill(); g.stroke();
      g.fillStyle = '#e8dcc0'; for (const sy of [-1, 1]) { g.beginPath(); g.moveTo(R * 1.0, sy * R * 0.18); g.lineTo(R * 1.55, sy * R * 0.32); g.lineTo(R * 1.05, sy * R * 0.42); g.fill(); }
      g.fillStyle = '#7c4a8c'; circ2(g, -R * 0.3, 0, R * 0.28); g.fill();
    } else if (k === 'sp') {
      g.fillStyle = '#e8dcc0'; for (let i = -2; i <= 2; i++) { g.beginPath(); g.moveTo(R * i * 0.35 - R * 0.15, -R * 0.5); g.lineTo(R * i * 0.35 - R * 0.4, -R * 1.1); g.lineTo(R * i * 0.35 + R * 0.1, -R * 0.55); g.fill(); }
      g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, R * 1.1, R * 0.75, 0, 0, 6.28); g.fill(); g.stroke(); g.fillStyle = dk; g.fillRect(R * 0.6, -R * 0.16, R * 0.8, R * 0.32); g.fillStyle = '#c493db'; circ2(g, R * 0.2, 0, R * 0.3); g.fill();
    } else if (k === 'ab') {
      g.fillStyle = '#9bd84a'; circ2(g, 0, 0, R * 1.05); g.fill(); g.stroke(); g.fillStyle = 'rgba(230,255,170,.55)'; circ2(g, -R * 0.3, -R * 0.3, R * 0.35); g.fill();
      g.strokeStyle = col; g.lineWidth = R * 0.25; circ2(g, 0, 0, R * 0.75); g.stroke();
    } else if (k === 'cr') {
      g.fillStyle = '#e8dcc0'; for (const sy of [-1, 1]) { g.beginPath(); g.moveTo(R * 0.7, sy * R * 0.4); g.quadraticCurveTo(R * 1.5, sy * R * 0.55, R * 1.45, sy * R * 0.05); g.lineTo(R * 0.9, sy * R * 0.25); g.fill(); }
      g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, R * 1.05, R * 0.95, 0, 0, 6.28); g.fill(); g.stroke();
      g.strokeStyle = dk; g.lineWidth = lw * 1.2; for (const x of [-0.45, 0, 0.45]) { g.beginPath(); g.arc(R * (x - 0.6), 0, R * 0.8, -0.9, 0.9); g.stroke(); }
    } else if (k === 'sf') {
      g.strokeStyle = '#7c4a8c'; g.lineWidth = lw; for (let i = 0; i < 4; i++) { const a = 2.2 + i * 0.6, w = Math.sin(spin * 0.2 + i) * 0.3; g.beginPath(); g.moveTo(Math.cos(a) * R * 0.6, Math.sin(a) * R * 0.6); g.quadraticCurveTo(Math.cos(a + w) * R * 1.3, Math.sin(a + w) * R * 1.3, Math.cos(a) * R * 1.7, Math.sin(a) * R * 1.7); g.stroke(); }
      g.strokeStyle = ol; g.fillStyle = col; circ2(g, 0, 0, R * 0.95); g.fill(); g.stroke(); g.fillStyle = 'rgba(210,160,240,.6)'; for (const [x, y] of [[0.3, -0.3], [-0.3, 0.25], [0.25, 0.4]]) { circ2(g, x * R, y * R, R * 0.22); g.fill(); }
    } else if (k === 'bw') {
      g.fillStyle = dk; circ2(g, -R * 0.95, 0, R * 0.5); g.fill(); g.stroke(); g.fillStyle = shade(col, -0.15); circ2(g, -R * 0.35, 0, R * 0.68); g.fill(); g.stroke();
      g.fillStyle = col; circ2(g, R * 0.35, 0, R * 0.8); g.fill(); g.stroke(); g.fillStyle = '#9bd84a'; circ2(g, R * 0.55, 0, R * 0.32); g.fill();
    } else if (k === 'ac2') {
      carry(); g.fillStyle = 'rgba(191,243,255,.35)'; circ2(g, 0, 0, R * 1.15); g.fill(); g.fillStyle = col; poly(g, [1.1, 0, 0, -0.9, -1, 0, 0, 0.9], R); g.fill(); g.stroke();
      g.fillStyle = '#f0d27a'; poly(g, [0.5, 0, 0, -0.38, -0.45, 0, 0, 0.38], R); g.fill();
    } else if (k === 'kn') {
      g.strokeStyle = '#bff3ff'; g.lineWidth = Math.max(1.5, R * 0.2); g.beginPath(); g.moveTo(R * 0.3, R * 0.55); g.lineTo(R * 1.7, R * 0.25); g.stroke(); g.strokeStyle = ol; g.lineWidth = lw;
      g.fillStyle = col; poly(g, [1, 0, 0.45, -0.85, -0.8, -0.7, -1, 0, -0.8, 0.7, 0.45, 0.85], R); g.fill(); g.stroke(); g.fillStyle = '#f0d27a'; poly(g, [0.55, 0, 0.1, -0.4, -0.45, 0, 0.1, 0.4], R); g.fill();
    } else if (k === 'ar2') {
      g.strokeStyle = '#f0d27a'; g.lineWidth = Math.max(1.2, R * 0.16); g.beginPath(); g.arc(R * 0.2, 0, R * 1.1, -1.1, 1.1); g.stroke();
      g.strokeStyle = '#bff3ff'; g.lineWidth = Math.max(1, R * 0.08); g.beginPath(); g.moveTo(R * 0.65, -R * 0.98); g.lineTo(R * 0.65, R * 0.98); g.stroke();
      g.strokeStyle = ol; g.lineWidth = lw; g.fillStyle = col; poly(g, [0.8, 0, 0, -0.8, -0.8, 0, 0, 0.8], R); g.fill(); g.stroke();
    } else if (k === 'ph') {
      g.fillStyle = 'rgba(191,243,255,.35)'; poly(g, [-0.6, -0.4, -1.8, 0, -0.6, 0.4], R); g.fill(); g.fillStyle = col; poly(g, [1.35, 0, -0.5, -0.8, -0.9, 0, -0.5, 0.8], R); g.fill(); g.stroke();
      g.fillStyle = '#bff3ff'; poly(g, [0.7, 0, 0, -0.25, 0, 0.25], R); g.fill();
    } else if (k === 'jd') {
      g.fillStyle = '#f0d27a'; g.fillRect(R * 0.2, -R * 0.1, R * 1.7, R * 0.2); g.fillStyle = '#bff3ff'; poly(g, [2.2, 0, 1.8, -0.2, 1.8, 0.2], R); g.fill();
      g.fillStyle = col; g.beginPath(); for (let i = 0; i < 6; i++) { const a = i * 1.047; g.lineTo(Math.cos(a) * R, Math.sin(a) * R); } g.closePath(); g.fill(); g.stroke(); g.fillStyle = '#f0d27a'; circ2(g, 0, 0, R * 0.38); g.fill();
    } else if (k === 'sk') {
      g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, R * 1.3, R * 0.7, 0, 0, 6.28); g.fill(); g.stroke(); g.strokeStyle = '#f0d27a'; g.lineWidth = Math.max(1.2, R * 0.12); g.beginPath(); g.ellipse(0, 0, R * 0.9, R * 0.45, 0, 0, 6.28); g.stroke();
      g.fillStyle = '#bff3ff'; circ2(g, R * 0.15, 0, R * 0.25); g.fill(); g.fillStyle = 'rgba(191,243,255,.5)'; for (const sy of [-1, 1]) { circ2(g, -R * 0.6, sy * R * 0.75, R * 0.2); g.fill(); }
    } else if (k === 'cl') {
      g.strokeStyle = shade(col, -0.3); g.lineWidth = Math.max(1.5, R * 0.16); for (let i = 0; i < 3; i++) { const a = i * 2.094 + 0.5; g.beginPath(); g.moveTo(0, 0); g.lineTo(Math.cos(a) * R * 1.4, Math.sin(a) * R * 1.4); g.stroke(); }
      g.strokeStyle = ol; g.lineWidth = lw; g.fillStyle = col; circ2(g, 0, 0, R * 0.7); g.fill(); g.stroke(); g.fillStyle = '#f0d27a'; g.fillRect(R * 0.3, -R * 0.18, R * 0.9, R * 0.36); g.fillStyle = '#bff3ff'; circ2(g, R * 1.2, 0, R * 0.18); g.fill();
    } else if (k === 'sv') {
      carry(); g.fillStyle = '#7a6a58'; g.fillRect(R * 0.3, R * 0.3, R * 1.0, R * 0.22); g.fillRect(R * 1.1, R * 0.1, R * 0.2, R * 0.45);
      g.fillStyle = col; circ2(g, 0, 0, R); g.fill(); g.stroke(); g.fillStyle = '#d0874a'; g.fillRect(-R * 0.5, -R * 0.5, R * 0.6, R * 0.6);
    } else if (k === 'sg') {
      g.fillStyle = '#4a3f35'; g.fillRect(R * 0.2, -R * 0.18, R * 1.5, R * 0.36); g.fillStyle = '#7a6a58'; g.fillRect(R * 1.2, -R * 0.26, R * 0.3, R * 0.52);
      g.fillStyle = col; circ2(g, 0, 0, R); g.fill(); g.stroke(); g.fillStyle = '#d0874a'; poly(g, [-0.2, -0.95, 0.35, -0.6, -0.1, 0.1, -0.7, -0.3], R); g.fill();
    } else if (k === 'bk') {
      g.fillStyle = '#26221e'; for (const x of [-0.9, 0.9]) { g.beginPath(); g.ellipse(R * x, 0, R * 0.42, R * 0.3, 0, 0, 6.28); g.fill(); }
      g.fillStyle = col; rr(g, -R * 0.8, -R * 0.38, R * 1.6, R * 0.76, R * 0.2); g.fill(); g.stroke(); g.fillStyle = '#d0874a'; g.fillRect(R * 0.5, -R * 0.55, R * 0.18, R * 1.1); g.fillStyle = '#ffb347'; circ2(g, R * 1.25, 0, R * 0.16); g.fill();
    } else if (k === 'hp') {
      g.strokeStyle = '#9a8a76'; g.lineWidth = Math.max(1, R * 0.14); g.beginPath(); g.moveTo(R * 0.2, 0); g.lineTo(R * 1.8, 0); g.stroke(); g.fillStyle = '#d9cbb4'; poly(g, [2.2, 0, 1.75, -0.3, 1.75, 0.3], R); g.fill();
      g.strokeStyle = ol; g.lineWidth = lw; g.fillStyle = col; circ2(g, 0, 0, R * 0.95); g.fill(); g.stroke(); g.strokeStyle = '#d0874a'; g.lineWidth = Math.max(1, R * 0.12); circ2(g, -R * 0.15, 0, R * 0.45); g.stroke();
    } else if (k === 'gl') {
      g.fillStyle = '#4a3f35'; for (const sy of [-1, 1]) g.fillRect(R * 0.4, sy * R * 0.75 - R * 0.2, R * 0.9, R * 0.4);
      g.fillStyle = col; poly(g, [0.9, -0.55, 0.3, -1, -0.8, -0.85, -1.05, 0, -0.8, 0.85, 0.3, 1, 0.9, 0.55], R); g.fill(); g.stroke(); g.fillStyle = '#7a6a58'; rr(g, -R * 0.5, -R * 0.45, R * 0.9, R * 0.9, R * 0.15); g.fill();
      g.fillStyle = '#d0874a'; for (const [x, y] of [[0.6, -0.6], [0.6, 0.6], [-0.7, -0.5], [-0.7, 0.5]]) { circ2(g, x * R, y * R, R * 0.09); g.fill(); }
    } else if (k === 'mt') {
      g.fillStyle = '#26221e'; for (const sx of [-0.7, 0.55]) for (const sy of [-1, 1]) g.fillRect(R * sx, sy * R * 0.62 - R * 0.17, R * 0.42, R * 0.34);
      g.fillStyle = col; rr(g, -R * 1.05, -R * 0.62, R * 2.1, R * 1.24, R * 0.15); g.fill(); g.stroke(); g.fillStyle = '#7a6a58'; g.fillRect(R * 0.45, -R * 0.55, R * 0.55, R * 1.1);
      g.fillStyle = '#3a322b'; circ2(g, -R * 0.35, 0, R * 0.42); g.fill(); g.fillStyle = '#d0874a'; circ2(g, -R * 0.35, 0, R * 0.2); g.fill();
    } else if (k === 'zp') {
      g.fillStyle = col; g.beginPath(); g.ellipse(0, 0, R * 1.35, R * 0.75, 0, 0, 6.28); g.fill(); g.stroke(); g.fillStyle = '#d0874a'; g.fillRect(-R * 0.6, -R * 0.5, R * 0.45, R * 0.4); g.fillStyle = '#9a8a76'; g.fillRect(R * 0.2, R * 0.05, R * 0.5, R * 0.35);
      g.strokeStyle = 'rgba(60,50,40,.6)'; g.beginPath(); g.moveTo(-R * 1.2, 0); g.lineTo(R * 1.2, 0); g.stroke(); g.fillStyle = '#26221e'; rr(g, -R * 0.4, R * 0.65, R * 0.8, R * 0.3, R * 0.1); g.fill();
    } else if (k === 'mb') {
      g.fillStyle = '#26221e'; for (const sx of [-1, -0.2, 0.6]) for (const sy of [-1, 1]) g.fillRect(R * sx, sy * R * 0.68 - R * 0.14, R * 0.4, R * 0.28);
      g.fillStyle = '#4f4033'; rr(g, -R * 1.15, -R * 0.66, R * 2.3, R * 1.32, R * 0.12); g.fill(); g.stroke(); g.fillStyle = col; poly(g, [0.4, 0, -0.3, -0.55, -0.95, -0.55, -0.95, 0.55, -0.3, 0.55], R); g.fill(); g.stroke();
      g.fillStyle = '#7a6a58'; g.fillRect(R * 0.55, -R * 0.45, R * 0.5, R * 0.9); g.fillStyle = '#d0874a'; g.fillRect(-R * 0.75, -R * 0.08, R * 0.6, R * 0.16);
    }
  }
  function facBld(g, t, s, col, ang, tm) {
    const B = BD[t], k = B.k, ro = B.ro;
    if (B.fa === 1) { // 군체: 살덩이 둔덕
      if (ro === 0) { g.fillStyle = '#6b3f5e'; g.beginPath(); g.ellipse(0, 0, s * 0.42, s * 0.38, 0, 0, 6.28); g.fill(); g.fillStyle = '#2a1424'; for (const [x, y, r] of [[-0.15, -0.1, 0.09], [0.14, 0.05, 0.11], [-0.05, 0.18, 0.07]]) { circ2(g, x * s, y * s, r * s); g.fill(); } g.fillStyle = col; circ2(g, 0.02 * s, -0.22 * s, s * 0.08); g.fill(); }
      else if (ro === 1) { for (const [x, y] of [[-0.14, -0.1], [0.14, -0.08], [0, 0.14]]) { g.fillStyle = '#d9c9a8'; g.beginPath(); g.ellipse(x * s, y * s, s * 0.15, s * 0.19, 0, 0, 6.28); g.fill(); g.fillStyle = 'rgba(180,106,208,.5)'; circ2(g, x * s, y * s + s * 0.04, s * 0.07); g.fill(); } }
      else if (ro === 2) { g.fillStyle = '#6b3f5e'; circ2(g, 0, 0, s * 0.38); g.fill(); g.fillStyle = '#7dbb3a'; g.beginPath(); g.ellipse(0, s * 0.02, s * 0.26, s * 0.2, 0, 0, 6.28); g.fill(); g.fillStyle = 'rgba(220,255,170,.5)'; circ2(g, -s * 0.08, -s * 0.04, s * 0.05 + Math.sin(tm || 0) * s * 0.01); g.fill(); }
      else if (ro === 3) { g.fillStyle = '#d9c9a8'; g.beginPath(); g.ellipse(0, 0, s * 0.3, s * 0.4, 0, 0, 6.28); g.fill(); g.strokeStyle = '#8a4a6a'; g.lineWidth = Math.max(1, s * 0.03); for (const a of [-0.6, 0, 0.6]) { g.beginPath(); g.moveTo(0, -s * 0.38); g.quadraticCurveTo(a * s * 0.5, 0, 0, s * 0.38); g.stroke(); } g.fillStyle = col; circ2(g, 0, 0, s * 0.07); g.fill(); }
      else if (ro === 4) { g.fillStyle = '#6b3f5e'; circ2(g, 0, 0, s * 0.36); g.fill(); g.strokeStyle = '#c493db'; g.lineWidth = Math.max(1, s * 0.04); g.beginPath(); for (let i = 0; i < 40; i++) { const a = i * 0.32 + (tm || 0) * 0.3, r = s * 0.02 + i * s * 0.007; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.stroke(); }
      else { g.fillStyle = '#6b3f5e'; circ2(g, 0, 0, s * 0.28); g.fill(); g.rotate(ang); g.fillStyle = '#e8dcc0'; poly(g, [0.48, 0, 0.05, -0.1, 0.05, 0.1], s); g.fill(); g.fillStyle = col; circ2(g, 0, 0, s * 0.13); g.fill(); }
      return;
    }
    if (B.fa === 2) { // 성광: 금빛 기하
      if (ro === 0) { g.fillStyle = '#6b6788'; g.beginPath(); for (let i = 0; i < 8; i++) { const a = i * 0.785; g.lineTo(Math.cos(a) * s * 0.4, Math.sin(a) * s * 0.4); } g.closePath(); g.fill(); g.fillStyle = '#f0d27a'; poly(g, [0, -0.26, 0.08, -0.08, 0.26, 0, 0.08, 0.08, 0, 0.26, -0.08, 0.08, -0.26, 0, -0.08, -0.08], s); g.fill(); g.fillStyle = col; circ2(g, 0, 0, s * 0.07); g.fill(); }
      else if (ro === 1) { g.fillStyle = 'rgba(191,243,255,.25)'; circ2(g, 0, 0, s * 0.42); g.fill(); g.fillStyle = '#bff3ff'; poly(g, [0, -0.4, 0.17, 0, 0, 0.32, -0.17, 0], s); g.fill(); g.fillStyle = '#f0d27a'; poly(g, [0, -0.2, 0.07, 0, 0, 0.14, -0.07, 0], s); g.fill(); }
      else if (ro === 2) { g.fillStyle = '#6b6788'; g.fillRect(-s * 0.36, -s * 0.2, s * 0.72, s * 0.46); g.fillStyle = '#2e2a40'; g.beginPath(); g.arc(0, s * 0.26, s * 0.16, Math.PI, 0); g.fill(); g.strokeStyle = '#f0d27a'; g.lineWidth = Math.max(1, s * 0.03); g.beginPath(); g.moveTo(-s * 0.36, -s * 0.2); g.lineTo(0, -s * 0.38); g.lineTo(s * 0.36, -s * 0.2); g.stroke(); }
      else if (ro === 3) { g.fillStyle = '#6b6788'; poly(g, [0, -0.38, 0.38, 0.28, -0.38, 0.28], s); g.fill(); g.fillStyle = '#f0d27a'; poly(g, [0, -0.16, 0.16, 0.14, -0.16, 0.14], s); g.fill(); g.fillStyle = 'rgba(191,243,255,.7)'; circ2(g, 0, s * 0.04, s * 0.05 + Math.abs(Math.sin(tm || 0)) * s * 0.03); g.fill(); }
      else if (ro === 4) { g.strokeStyle = '#f0d27a'; g.lineWidth = Math.max(1, s * 0.035); for (const r of [0.34, 0.22]) { g.beginPath(); g.ellipse(0, 0, s * r, s * r * 0.55, (tm || 0) * 0.4 * (r > 0.3 ? 1 : -1), 0, 6.28); g.stroke(); } g.fillStyle = '#bff3ff'; circ2(g, 0, 0, s * 0.09); g.fill(); }
      else { g.fillStyle = '#6b6788'; poly(g, [0, -0.36, 0.16, 0.3, -0.16, 0.3], s); g.fill(); g.fillStyle = '#bff3ff'; circ2(g, 0, -s * 0.2, s * 0.1); g.fill(); g.rotate(ang); g.fillStyle = '#f0d27a'; g.fillRect(0, -s * 0.03, s * 0.36, s * 0.06); }
      return;
    }
    // 고철: 천막·고철판
    if (ro === 0) { g.fillStyle = '#7a6a58'; poly(g, [0, -0.38, 0.38, 0.26, -0.38, 0.26], s); g.fill(); g.fillStyle = col; poly(g, [0, -0.38, 0.12, 0.26, -0.12, 0.26], s); g.fill(); g.fillStyle = '#26221e'; for (const x of [-0.3, -0.1, 0.1, 0.3]) { circ2(g, x * s, s * 0.32, s * 0.05); g.fill(); } g.strokeStyle = '#d0874a'; g.lineWidth = Math.max(1, s * 0.025); g.beginPath(); g.moveTo(s * 0.3, s * 0.2); g.lineTo(s * 0.3, -s * 0.36); g.stroke(); g.fillStyle = '#d0874a'; g.fillRect(s * 0.3, -s * 0.36, s * 0.12, s * 0.08); }
    else if (ro === 1) { g.fillStyle = '#5a4d40'; g.fillRect(-s * 0.3, -s * 0.2, s * 0.6, s * 0.46); g.fillStyle = '#3a322b'; g.fillRect(s * 0.06, -s * 0.42, s * 0.16, s * 0.3); g.fillStyle = '#ff9a3c'; g.fillRect(-s * 0.18, s * 0.02, s * 0.2, s * 0.14 + Math.abs(Math.sin(tm || 0)) * s * 0.03); }
    else if (ro === 2) { for (const [x, w] of [[-0.18, 0.3], [0.16, 0.26]]) { g.fillStyle = '#8a7a62'; poly(g, [x, -0.3, x + w / 2, 0.24, x - w / 2, 0.24], s); g.fill(); } g.fillStyle = col; g.fillRect(-s * 0.36, s * 0.24, s * 0.72, s * 0.06); }
    else if (ro === 3) { g.fillStyle = '#5a4d40'; g.fillRect(-s * 0.38, -s * 0.05, s * 0.76, s * 0.33); g.strokeStyle = '#d0874a'; g.lineWidth = Math.max(1.5, s * 0.04); g.beginPath(); g.moveTo(-s * 0.25, -s * 0.05); g.lineTo(-s * 0.25, -s * 0.38); g.lineTo(s * 0.3, -s * 0.3 + Math.sin(tm || 0) * s * 0.04); g.stroke(); g.fillStyle = '#9a8a76'; g.fillRect(s * 0.26, -s * 0.3, s * 0.08, s * 0.14); }
    else if (ro === 4) { g.fillStyle = '#5a4d40'; g.fillRect(-s * 0.36, -s * 0.24, s * 0.72, s * 0.5); g.strokeStyle = '#d0874a'; g.lineWidth = Math.max(1, s * 0.035); g.beginPath(); for (let i = 0; i < 8; i++) { const a = i * 0.785 + (tm || 0) * 0.3; g.moveTo(Math.cos(a) * s * 0.1, Math.sin(a) * s * 0.1); g.lineTo(Math.cos(a) * s * 0.17, Math.sin(a) * s * 0.17); } g.stroke(); circ2(g, 0, 0, s * 0.1); g.stroke(); }
    else { g.fillStyle = '#5a4d40'; g.fillRect(-s * 0.22, -s * 0.22, s * 0.44, s * 0.44); g.strokeStyle = '#3a322b'; g.lineWidth = Math.max(1, s * 0.03); g.strokeRect(-s * 0.22, -s * 0.22, s * 0.44, s * 0.44); g.rotate(ang); g.fillStyle = '#26221e'; g.fillRect(0, -s * 0.06, s * 0.42, s * 0.12); g.fillStyle = col; circ2(g, 0, 0, s * 0.12); g.fill(); }
  }
  function bldGlyph(g, t, x, y, wpx, col, done, pr, ang, tm) {
    const h = wpx / 2, m = wpx * 0.06;
    g.save(); g.translate(x, y);
    g.globalAlpha = done ? 1 : 0.55;
    const FA = BD[t].fa, pr2 = FA === 1 ? wpx * 0.45 : FA === 3 ? wpx * 0.04 : wpx * 0.12;
    g.fillStyle = 'rgba(0,0,0,.35)'; rr(g, -h + m + wpx * 0.05, -h + m + wpx * 0.07, wpx - 2 * m, wpx - 2 * m, pr2); g.fill();
    g.fillStyle = FAC[FA].pl; if (FA === 2) { g.beginPath(); const q = wpx / 2 - m, c = q * 0.42; g.moveTo(-q + c, -q); g.lineTo(q - c, -q); g.lineTo(q, -q + c); g.lineTo(q, q - c); g.lineTo(q - c, q); g.lineTo(-q + c, q); g.lineTo(-q, q - c); g.lineTo(-q, -q + c); g.closePath(); } else rr(g, -h + m, -h + m, wpx - 2 * m, wpx - 2 * m, pr2); g.fill();
    g.strokeStyle = 'rgba(10,8,14,.7)'; g.lineWidth = Math.max(1, wpx * 0.03); g.stroke();
    if (FA === 1) { g.strokeStyle = col; g.lineWidth = Math.max(1.5, wpx * 0.05); g.beginPath(); g.arc(0, 0, wpx / 2 - m - wpx * 0.03, 0.4, 2.74); g.stroke(); }
    else if (FA === 2) { g.strokeStyle = col; g.lineWidth = Math.max(1.5, wpx * 0.04); g.beginPath(); g.moveTo(-h + m + wpx * 0.2, h - m - wpx * 0.02); g.lineTo(h - m - wpx * 0.2, h - m - wpx * 0.02); g.stroke(); }
    else { g.fillStyle = col; g.fillRect(-h + m, h - m - wpx * 0.1, wpx - 2 * m, wpx * 0.1); if (FA === 3) { g.fillStyle = 'rgba(208,135,74,.7)'; for (const [a, b] of [[-1, -1], [1, -1]]) { circ2(g, a * (h - m - wpx * 0.07), b * (h - m - wpx * 0.07), Math.max(1, wpx * 0.025)); g.fill(); } } }
    const s = wpx;
    if (FA) facBld(g, t, s, col, ang, tm);
    else if (t === 0) {
      g.fillStyle = '#4c475a'; g.beginPath(); for (let i = 0; i < 8; i++) { const a = i * 0.785 + 0.39; g.lineTo(Math.cos(a) * s * 0.4, Math.sin(a) * s * 0.4); } g.closePath(); g.fill();
      g.fillStyle = shade(col, 0.15); g.beginPath(); g.arc(0, -s * 0.02, s * 0.2, 0, 6.28); g.fill();
      g.fillStyle = 'rgba(255,255,255,.28)'; g.beginPath(); g.arc(-s * 0.06, -s * 0.08, s * 0.08, 0, 6.28); g.fill();
      g.strokeStyle = '#f2c14e'; g.lineWidth = Math.max(1, s * 0.025); g.strokeRect(-s * 0.36, -s * 0.36, s * 0.14, s * 0.14); g.strokeRect(s * 0.22, -s * 0.36, s * 0.14, s * 0.14);
    } else if (t === 1) {
      g.fillStyle = '#7a5a36'; g.fillRect(-s * 0.32, -s * 0.3, s * 0.36, s * 0.36); g.fillRect(-s * 0.02, -s * 0.12, s * 0.34, s * 0.34);
      g.strokeStyle = '#3b2a18'; g.lineWidth = Math.max(1, s * 0.04); g.strokeRect(-s * 0.32, -s * 0.3, s * 0.36, s * 0.36); g.strokeRect(-s * 0.02, -s * 0.12, s * 0.34, s * 0.34);
      g.fillStyle = col; g.fillRect(-s * 0.32, -s * 0.16, s * 0.36, s * 0.07);
    } else if (t === 2) {
      g.fillStyle = '#5a5363'; g.fillRect(-s * 0.4, -s * 0.34, s * 0.8, s * 0.5);
      g.strokeStyle = '#2d2a33'; g.lineWidth = Math.max(1, s * 0.025); for (let i = -3; i <= 3; i++) { g.beginPath(); g.moveTo(i * s * 0.1, -s * 0.34); g.lineTo(i * s * 0.1, s * 0.16); g.stroke(); }
      g.fillStyle = shade(col, -0.2); g.fillRect(-s * 0.1, s * 0.05, s * 0.2, s * 0.2);
      g.fillStyle = col; g.fillRect(-s * 0.4, -s * 0.34, s * 0.8, s * 0.07);
    } else if (t === 3) {
      g.fillStyle = '#56505e'; g.fillRect(-s * 0.4, -s * 0.2, s * 0.8, s * 0.48);
      g.fillStyle = '#433e4a'; g.fillRect(s * 0.16, -s * 0.42, s * 0.14, s * 0.3);
      g.strokeStyle = '#c9c1b0'; g.lineWidth = Math.max(1, s * 0.035); g.beginPath(); g.arc(-s * 0.12, s * 0.04, s * 0.14, 0, 6.28); g.stroke();
      for (let i = 0; i < 6; i++) { const a = i * 1.047 + (tm || 0) * 0.5; g.beginPath(); g.moveTo(-s * 0.12 + Math.cos(a) * s * 0.14, s * 0.04 + Math.sin(a) * s * 0.14); g.lineTo(-s * 0.12 + Math.cos(a) * s * 0.2, s * 0.04 + Math.sin(a) * s * 0.2); g.stroke(); }
      g.fillStyle = col; g.fillRect(-s * 0.4, -s * 0.2, s * 0.8, s * 0.06);
    } else if (t === 4) {
      g.fillStyle = '#4f5a66'; g.beginPath(); g.arc(-s * 0.16, s * 0.08, s * 0.2, 0, 6.28); g.fill();
      g.fillStyle = '#6a7684'; g.beginPath(); g.arc(s * 0.2, -s * 0.16, s * 0.13, 0, 6.28); g.fill();
      g.strokeStyle = '#d9e4ee'; g.lineWidth = Math.max(1, s * 0.035); g.beginPath(); g.arc(s * 0.2, -s * 0.16, s * 0.2, 2.4 + (tm || 0) * 0.3, 4.6 + (tm || 0) * 0.3); g.stroke();
      g.fillStyle = col; g.beginPath(); g.arc(-s * 0.16, s * 0.08, s * 0.08, 0, 6.28); g.fill();
    } else if (t === 5) {
      g.fillStyle = '#56505e'; g.beginPath(); g.arc(0, 0, s * 0.32, 0, 6.28); g.fill(); g.stroke();
      g.rotate(ang); g.fillStyle = '#25222a'; g.fillRect(0, -s * 0.07, s * 0.45, s * 0.14);
      g.fillStyle = col; g.beginPath(); g.arc(0, 0, s * 0.17, 0, 6.28); g.fill(); g.stroke();
    }
    g.restore();
    if (!done) {
      g.save(); g.translate(x, y); g.strokeStyle = 'rgba(242,193,78,.55)'; g.lineWidth = Math.max(1, wpx * 0.025);
      g.beginPath(); for (let i = -2; i <= 2; i++) { g.moveTo(-h + m, i * wpx * 0.22 - wpx * 0.2); g.lineTo(h - m, i * wpx * 0.22 + wpx * 0.2); } g.stroke(); g.restore();
    }
  }

  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const host = () => !api.online || api.isHost;
    const seat = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const fac = (s) => (st && st.sh ? s >> 1 : s); // seat → faction (owner index in the world)
    const faOf = (o) => (st && Array.isArray(st.fa) ? st.fa[o] | 0 : 0); // owner → 진영
    const myF = () => FAC[faOf(Math.max(0, me()))], myUG = () => UPGF[faOf(Math.max(0, me()))];
    const siteOnly = (bt) => !!(BD[bt].hq && !BD[bt].any);
    const me = () => { const s = seat(); return s < 0 ? -1 : fac(s); };
    const mate = () => (st && st.sh && seat() >= 0 ? seat() ^ 1 : -1); // teammate seat sharing my faction
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const col = (o) => P(st && st.sh ? o * 2 : o).color || '#888';
    const lastAct = []; // host: W.t of each seat's last command (AI teammate takes the army when the human idles)
    const tvR = {}; let tvHS = null; // teammate view/selection: host keeps guests' reports, guests read them from the snapshot
    let hpg = [], hpgId = 0, myPg = null, pgSeen = -1, pgMine = 0; const pgRem = {};
    const PGK = [{ nm: '여기 공격', ic: '⚔', c: '#ee6a55', sf: 'whoosh' }, { nm: '도와줘', ic: '✋', c: '#f2c14e', sf: 'pop' }, { nm: '조심', ic: '⚠', c: '#9fe8ff', sf: 'bounce' }];
    let pingAt = null;
    let st = null, key = null, W = null, map = null, acc = 0, endT = 0, sentEnd = false, frame = 0;
    const aiM = [];
    const R = { u: new Map(), b: new Map(), na: [], p: [], t: 0 };
    let tcv = null, mcv = null, fcv = null, fimg = null, gV = null, gE = null, fogT = 0;
    const bmem = new Map();
    const cam = { x: 32, y: 32, z: 22 };
    let sel = [], selKind = null, groups = [[], [], [], []], mode = null, ghost = null, card = 'main', boxArm = false;
    let fx = [], pings = [], tipT = 0, shake = 0, lastAlert = -99, hpPrev = new Map(), lastEvQ = -1, toastT = 0, hint = '';
    let pubT = 0, hsQ = 0, lastQ = -1, cq = [], cseq = 0; const seenSeq = {}, ack = {};
    let btns = [], lay = null, hover = null, idleIdx = 0, lastTap = { id: 0, t: 0 }, grpTap = { g: -1, t: 0 };
    const mods = { ctrl: false, shift: false };
    const sfxT = {};
    const sfx = (n, gap) => { const t = performance.now(); if (sfxT[n] && t - sfxT[n] < (gap || 90)) return; sfxT[n] = t; api.sfx(n); };
    const myTeam = () => (me() >= 0 && map ? map.tm[me()] : -1);
    const nowT = () => R.t;

    /* ----- render model sync ----- */
    function syncFromW() {
      R.t = W.t;
      const mT = myTeam();
      for (const u of W.units) {
        if (u.in) continue;
        if (mT >= 0 && W.tm[u.o] !== mT && hidU(W, mT, u)) continue;
        let r = R.u.get(u.i); if (!r) { r = { i: u.i }; R.u.set(u.i, r); }
        r.t = u.t; r.o = u.o; r.x = u.x; r.y = u.y; r.hp = (u.hp + u.sh) / (u.mhp + u.msh); r.f = u.f; r.an = u.an & 1; r.cr = u.t === TP ? u.cg : u.cr ? u.ck + 1 : 0; r.md = u.md; r.fr = frame; r.idle = isW(u.t) && u.s === 'i';
      }
      for (const [id, r] of R.u) if (r.fr !== frame) R.u.delete(id);
      for (const b of W.blds) {
        let r = R.b.get(b.i); if (!r) { r = { i: b.i }; R.b.set(b.i, r); }
        r.t = b.t; r.o = b.o; r.tx = b.tx; r.ty = b.ty; r.sz = b.sz; r.x = b.x; r.y = b.y; r.hp = (b.hp + b.sh) / (b.mhp + b.msh); r.done = b.done; r.pr = b.done ? 1 : b.pr / BD[b.t].bt;
        r.q = b.q.map((it) => (it[0] === 'u' ? it[1] : 100 + it[1])); r.qp = b.q.length ? 1 - b.q[0][2] / (b.q[0][0] === 'u' ? UN[b.q[0][1]].bt : upgOf(BD[b.t].fa, b.q[0][1]).tm[Math.min(1, W.pl[b.o].up[b.q[0][1]])]) : 0;
        r.f = b.f; r.an = b.an & 1; r.fr = frame; if (r.rx == null || b.o === me()) { r.rx = b.rx; r.ry = b.ry; }
      }
      for (const [id, r] of R.b) if (r.fr !== frame) R.b.delete(id);
      R.na = W.nodes.map((q) => q.a / q.m); R.wr = W.wr.map((w) => [w.x, w.y]);
      R.p = W.pl.map((p) => ({ ore: Math.floor(p.ore), cry: Math.floor(p.cry), used: p.used, cap: p.cap, up: p.up.slice(), alive: p.alive, hk: Math.max(0, Math.ceil(p.hk - W.t)), hc: Math.max(0, Math.ceil(p.hc - W.t)) }));
      for (const e of W.ev) onEvRaw(e);
    }
    function onEvRaw(e) { const q = e[0]; if (lastEvQ < 0 || ((q - lastEvQ + 1296) % 1296 > 0 && (q - lastEvQ + 1296) % 1296 < 600)) { if (lastEvQ >= 0 || !host()) onEv(e[1], e[2] / 10, e[3] / 10, e[4], e[5]); lastEvQ = q; } }
    function guestTeams() { const s = new Set(); for (let i = 0; i < st.n; i++) { const p = api.players[i]; if (p && !p.ai && !p.local) s.add(map.tm[fac(i)]); } return s; }
    function packSend() {
      const gt = guestTeams(); const Vs = [...gt].map((t) => W.vis[t]);
      const gl = [...gt]; const inc = (e) => gt.has(W.tm[e.o]) || gl.some((T) => visU(W, T, e));
      const us = W.units.filter((u) => !u.dead && !u.in && inc(u));
      const parts = Math.min(3, Math.ceil(us.length / 170) || 1), part = hsQ % parts;
      let u = '';
      for (const x of us) { if (parts > 1 && x.i % parts !== part) continue; u += b36(x.i % 46656, 3) + x.t.toString(36) + x.o + b36(x.x * 16, 2) + b36(x.y * 16, 2) + Math.ceil(clamp((x.hp + x.sh) / (x.mhp + x.msh), 0, 1) * 35).toString(36) + (x.f * 2 + (x.an & 1)).toString(36) + (x.t === TP ? Math.min(9, 4 + x.cg) : x.cr ? x.ck + 1 : isW(x.t) && x.s === 'i' ? 3 : x.md ? 5 : 0); }
      const bs = [];
      for (const b of W.blds) {
        if (b.dead || !(gt.has(W.tm[b.o]) || Vs.some((V) => V[cellOf(W, b.x, b.y)]))) continue;
        if (bs.length >= 80) break;
        let r = b36(b.i % 46656, 3) + b.t.toString(36) + b.o + b36(b.tx, 2) + b36(b.ty, 2) + Math.ceil(clamp((b.hp + b.sh) / (b.mhp + b.msh), 0, 1) * 35).toString(36) + (b.done ? 'z' : Math.floor(clamp(b.pr / BD[b.t].bt, 0, 0.99) * 35).toString(36)) + (b.f * 2 + (b.an & 1)).toString(36);
        if (b.q.length) { r += b.q.map((it) => (it[0] === 'u' ? it[1].toString(36) : String.fromCharCode(65 + it[1]))).join(''); const it = b.q[0]; const tot = it[0] === 'u' ? UN[it[1]].bt : upgOf(BD[b.t].fa, it[1]).tm[Math.min(1, W.pl[b.o].up[it[1]])]; r += Math.floor(clamp(1 - it[2] / tot, 0, 0.99) * 35).toString(36); }
        bs.push(r);
      }
      let nd = ''; for (const q of W.nodes) nd += Math.ceil(q.a / q.m * 35).toString(36);
      let ev = ''; for (const e of W.ev) ev += b36(e[0], 2) + e[1].toString(36) + b36(e[2], 2) + b36(e[3], 2) + b36(e[4], 1) + e[5];
      let wr = ''; if (W.nomad) for (const w of W.wr.slice(0, 30)) if (Vs.some((V) => V[cellOf(W, w.x, w.y)])) wr += b36(w.x * 4, 2) + b36(w.y * 4, 2);
      const ak = []; for (let s = 0; s < st.n; s++) ak.push(seenSeq[s] == null ? -1 : seenSeq[s]);
      const tv = []; if (st.sh) for (let i = 0; i < st.n; i++) { const v = i === seat() ? myView() : tvR[i]; tv.push(v || ''); }
      const o = { k: st.rid, q: hsQ, P: parts, tv, pg: hpg, t: Math.round(W.t * 10) / 10, u, b: bs.join(','), r: nd, ev, ak, wr,
        p: W.pl.map((p) => [Math.floor(p.ore), Math.floor(p.cry), p.used, p.cap, p.up.join(''), p.alive ? 1 : 0, Math.max(0, Math.ceil(p.hk - W.t)), Math.max(0, Math.ceil(p.hc - W.t))]), m: W.mis ? misLine(W) : '' };
      let len = JSON.stringify(o).length; // keep the snapshot under the 4096-char presence limit
      if (len > 4000) { o.wr = ''; while (len > 4000 && bs.length > 10) { bs.length -= 4; o.b = bs.join(','); len = JSON.stringify(o).length; } }
      if (L.debug) L.debug.rtsMaxSnap = Math.max(L.debug.rtsMaxSnap || 0, len);
      api.net.hostSend(o);
    }
    function pollHost() {
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem) return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.n) || !o || o.k !== st.rid) continue;
        if (typeof o.v === 'string') tvR[s] = o.v.slice(0, 60);
        if (st.ph === 'pick' && Array.isArray(o.fp)) pickSet(s, o.fp[0] | 0, o.fp[1] ? 1 : 0);
        if (Array.isArray(o.pg) && (o.pg[0] | 0) !== pgRem[s]) { pgRem[s] = o.pg[0] | 0; if (pgRem[s] > 0) addPing(s, o.pg[1] | 0, +o.pg[2] / 10, +o.pg[3] / 10); }
        if (!Array.isArray(o.c)) continue;
        for (const c of o.c) {
          if (!Array.isArray(c)) continue;
          const q = c[0] | 0, last = seenSeq[s] == null ? -1 : seenSeq[s];
          const dq = (q - last + 100000) % 100000;
          if (last >= 0 && !(dq > 0 && dq < 50000)) continue;
          seenSeq[s] = q; if (cmd(W, fac(s), c.slice(1))) { lastAct[s] = W.t; if (L.debug) L.debug.rtsGuestCmd = (L.debug.rtsGuestCmd || 0) + 1; }
        }
      }
    }
    function pollGuest(rdt) {
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (hs && hs.k === st.rid && typeof hs.u === 'string' && hs.q !== lastQ) {
        lastQ = hs.q; R.t = +hs.t || 0; const parts = hs.P || 1, u = hs.u;
        for (let i = 0; i + 12 <= u.length; i += 12) {
          const id = d36(u, i, 3); let r = R.u.get(id);
          const x = d36(u, i + 5, 2) / 16, y = d36(u, i + 7, 2) / 16;
          if (!r) { r = { i: id, x, y }; R.u.set(id, r); }
          r.t = parseInt(u[i + 3], 36) || 0; r.o = +u[i + 4]; r.nx = x; r.ny = y; r.hp = (parseInt(u[i + 9], 36) || 0) / 35;
          const fa = parseInt(u[i + 10], 36) || 0; r.f = fa >> 1; r.an = fa & 1; const c = +u[i + 11]; r.cr = r.t === TP ? Math.max(0, c - 4) : c === 3 || c === 5 ? 0 : c; r.md = c === 5 && !isW(r.t) ? 1 : 0; r.idle = isW(r.t) && c === 3; r.seen = hs.q;
        }
        for (const [id, r] of R.u) if (((hs.q - r.seen + 100000) % 100000) > parts) R.u.delete(id);
        const nb = new Set();
        for (const s of String(hs.b || '').split(',')) {
          if (s.length < 12) continue;
          const id = d36(s, 0, 3); let r = R.b.get(id); if (!r) { r = { i: id, rx: null, ry: null }; R.b.set(id, r); }
          r.t = parseInt(s[3], 36) || 0; r.o = +s[4]; r.tx = d36(s, 5, 2); r.ty = d36(s, 7, 2); r.sz = BD[r.t].sz; r.x = r.tx + r.sz / 2; r.y = r.ty + r.sz / 2;
          r.hp = (parseInt(s[9], 36) || 0) / 35; r.done = s[10] === 'z'; r.pr = r.done ? 1 : (parseInt(s[10], 36) || 0) / 35;
          const fa = parseInt(s[11], 36) || 0; r.f = fa >> 1; r.an = fa & 1;
          const qs = s.slice(12, -1); r.q = s.length > 12 ? qs.split('').map((ch) => (ch >= 'A' && ch <= 'Z' ? 100 + ch.charCodeAt(0) - 65 : parseInt(ch, 36) || 0)) : []; r.qp = s.length > 12 ? (parseInt(s[s.length - 1], 36) || 0) / 35 : 0;
          nb.add(id);
        }
        for (const id of [...R.b.keys()]) if (!nb.has(id)) R.b.delete(id);
        const nd = String(hs.r || ''); R.na = map.nodes.map((q, i) => (parseInt(nd[i], 36) || 0) / 35);
        R.m = String(hs.m || '').slice(0, 80);
        R.p = (hs.p || []).map((a) => ({ ore: a[0], cry: a[1], used: a[2], cap: a[3], up: String(a[4] || '0000').split('').map(Number), alive: !!a[5], hk: a[6] | 0, hc: a[7] | 0 }));
        const ev = String(hs.ev || ''); for (let i = 0; i + 9 <= ev.length; i += 9) onEvRaw([d36(ev, i, 2), parseInt(ev[i + 2], 36) || 0, d36(ev, i + 3, 2), d36(ev, i + 5, 2), d36(ev, i + 7, 1), +ev[i + 8]]);
        { const w = String(hs.wr || ''); R.wr = []; for (let i = 0; i + 4 <= w.length; i += 4) R.wr.push([d36(w, i, 2) / 4, d36(w, i + 2, 2) / 4]); }
        tvHS = Array.isArray(hs.tv) ? hs.tv : null;
        if (Array.isArray(hs.pg)) for (const g of hs.pg) if (Array.isArray(g) && (g[0] | 0) > pgSeen) { pgSeen = g[0] | 0; if ((g[1] | 0) !== seat()) showPing(g[1] | 0, g[2] | 0, g[3] / 10, g[4] / 10); }
        const a = (hs.ak || [])[seat()]; if (a != null && a >= 0) cq = cq.filter((c) => { const d = (c[0] - a + 100000) % 100000; return d > 0 && d < 50000; });
      }
      const k = Math.min(1, rdt * 12);
      for (const r of R.u.values()) { if (r.nx == null) continue; if (hyp(r.nx - r.x, r.ny - r.y) > 4) { r.x = r.nx; r.y = r.ny; } else { r.x += (r.nx - r.x) * k; r.y += (r.ny - r.y) * k; } }
    }
    function publish(rdt) {
      if (!api.online) return;
      pubT -= rdt; if (pubT > 0) return; pubT = 0.1;
      try {
        if (api.isHost) { if (W) { hsQ = (hsQ + 1) % 100000; packSend(); } }
        else if (me() >= 0 && st) { const o = { k: st.rid, c: cq.slice(-16) }; if (st.ph === 'pick' && myPick) o.fp = myPick; if (st.sh) o.v = myView(); if (myPg) o.pg = myPg; api.net.publish(o); }
      } catch (e) {}
    }
    function send(c) {
      const s = me(); if (s < 0 || !st || st.ph !== 'play') return false;
      if (host()) { const ok = W ? cmd(W, s, c) : false; if (ok) lastAct[seat()] = W.t; return ok; }
      cseq = (cseq + 1) % 100000; cq.push([cseq].concat(c)); if (cq.length > 24) cq.shift(); pubT = 0; return true;
    }

    /* ----- caches ----- */
    /* ----- 공동 진영: teammate view/selection, team pings ----- */
    function myView() { // cx cy hw hh (x10, b36 3 chars each) + kind + up to 12 selected ids (b36 3 chars)
      const hw = cv.w / 2 / cam.z, hh = cv.h / 2 / cam.z;
      let v = b36(cam.x * 10, 3) + b36(cam.y * 10, 3) + b36(hw * 10, 3) + b36(hh * 10, 3) + (selKind === 'b' ? 'b' : 'u');
      if (selKind === 'u' || selKind === 'b') for (const id of sel.slice(0, 12)) v += b36(id % 46656, 3);
      return v;
    }
    function mateView() {
      const m = mate(); if (m < 0) return null;
      const v = host() ? tvR[m] : tvHS && tvHS[m]; if (!v || typeof v !== 'string' || v.length < 13) return null;
      const ids = []; for (let i = 13; i + 3 <= v.length; i += 3) ids.push(d36(v, i, 3));
      return { x: d36(v, 0, 3) / 10, y: d36(v, 3, 3) / 10, hw: d36(v, 6, 3) / 10, hh: d36(v, 9, 3) / 10, b: v[12] === 'b', ids: new Set(ids) };
    }
    const teamPlay = () => !!(st && (st.sh || st.team) && !st.op);
    function showPing(s, k, x, y) {
      if (!map || !PGK[k] || s < 0 || s >= st.n) return;
      if (seat() >= 0 && map.tm[fac(s)] !== myTeam()) return;
      pings.push({ x, y, t: 4, c: PGK[k].c, tp: 1, lab: PGK[k].ic + ' ' + PGK[k].nm, who: (st.nm[s] || '').slice(0, 6) });
      sfx(PGK[k].sf, 300);
      if (s !== seat()) { api.buzz([20, 40, 20]); api.toast((st.nm[s] || (s + 1) + '번') + ': ' + PGK[k].nm); }
    }
    function addPing(s, k, x, y) { // host: record (sent to everyone, each phone shows only its team's) + show
      hpgId++; hpg.push([hpgId, s, k, Math.round(x * 10), Math.round(y * 10)]); if (hpg.length > 4) hpg.shift();
      if (s !== seat()) showPing(s, k, x, y);
    }
    function sendPing(k, x, y) {
      x = clamp(x, 0, map.S); y = clamp(y, 0, map.S);
      showPing(seat(), k, x, y);
      if (host()) { if (api.online) { hpgId++; hpg.push([hpgId, seat(), k, Math.round(x * 10), Math.round(y * 10)]); if (hpg.length > 4) hpg.shift(); } }
      else { pgMine++; myPg = [pgMine, k, Math.round(x * 10), Math.round(y * 10)]; pubT = 0; }
    }
    function buildTerrain() {
      const S = map.S, TS = 16, th = map.th;
      tcv = document.createElement('canvas'); tcv.width = tcv.height = S * TS; const g = tcv.getContext('2d');
      const R2 = rng(st.sd ^ 0x5bd1);
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
        const c = y * S + x, t = map.ter[c], n = R2();
        g.fillStyle = t === 3 ? th.lo[1] : t === 1 ? th.hi[n < 0.5 ? 0 : 1] : t === 2 ? th.rp : th.lo[n < 0.5 ? 0 : 1];
        g.fillRect(x * TS, y * TS, TS, TS);
        if (t === 5 || t === 6) { g.fillStyle = n < 0.5 ? '#2f5f7a' : '#2b5871'; g.fillRect(x * TS, y * TS, TS, TS); }
      }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) if (map.ter[y * S + x] === 3) { g.fillStyle = th.ed; g.beginPath(); g.arc(x * TS + TS / 2 + 1, y * TS + TS / 2 + 3, TS * 0.78, 0, 6.28); g.fill(); }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) if (map.ter[y * S + x] === 3) { g.fillStyle = th.rk[R2() < 0.5 ? 0 : 1]; g.beginPath(); g.arc(x * TS + TS / 2, y * TS + TS / 2, TS * 0.76, 0, 6.28); g.fill(); }
      for (let i = 0; i < S * S * 0.6; i++) { const x = R2() * S, y = R2() * S, c = (y | 0) * S + (x | 0), t = map.ter[c]; if (t === 3) continue; g.fillStyle = R2() < 0.5 ? 'rgba(0,0,0,.08)' : 'rgba(255,255,255,.06)'; g.fillRect(x * TS, y * TS, 2 + R2() * 3, 2 + R2() * 3); }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
        const c = y * S + x, t = map.ter[c];
        if (t === 3) {
          g.fillStyle = 'rgba(255,255,255,.07)'; g.beginPath(); g.arc(x * TS + 5 + R2() * 6, y * TS + 5 + R2() * 6, 3 + R2() * 4, 0, 6.28); g.fill();
          g.fillStyle = 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(x * TS + 9 + R2() * 4, y * TS + 10 + R2() * 4, 2 + R2() * 3, 0, 6.28); g.fill();
        } else if (t === 2) {
          g.fillStyle = 'rgba(0,0,0,.12)'; for (let k = 0; k < 4; k++) g.fillRect(x * TS, y * TS + k * 4, TS, 1.5);
        } else if (t === 1) {
          const dn = y + 1 < S ? map.ter[c + S] : 1, rt = x + 1 < S ? map.ter[c + 1] : 1;
          if (dn === 0) { g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x * TS, y * TS + TS - 3, TS, 3); }
          if (rt === 0) { g.fillStyle = 'rgba(0,0,0,.2)'; g.fillRect(x * TS + TS - 2, y * TS, 2, TS); }
          const up = y > 0 ? map.ter[c - S] : 1; if (up === 3 || up === 0) { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(x * TS, y * TS, TS, 2); }
        }
      }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) { const t = map.ter[y * S + x]; // 물결 · 다리 · 수풀
        if (t === 5) { g.strokeStyle = 'rgba(200,230,245,.25)'; g.lineWidth = 1.2; g.beginPath(); const yy = y * TS + 4 + R2() * 8; g.moveTo(x * TS + 2, yy); g.quadraticCurveTo(x * TS + 8, yy - 3, x * TS + 14, yy); g.stroke(); }
        else if (t === 6) { g.fillStyle = '#7a5a3a'; g.fillRect(x * TS, y * TS + 1, TS, TS - 2); g.fillStyle = 'rgba(0,0,0,.28)'; for (let k = 0; k < 4; k++) g.fillRect(x * TS + k * 4, y * TS + 1, 1, TS - 2); g.fillStyle = '#4e3824'; g.fillRect(x * TS, y * TS, TS, 1.5); g.fillRect(x * TS, y * TS + TS - 1.5, TS, 1.5); }
      }
      for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) if (map.ter[y * S + x] === 4) {
        for (let k = 0; k < 4; k++) { g.fillStyle = k & 1 ? '#2f5a26' : '#3c6e2e'; g.beginPath(); g.arc(x * TS + 3 + R2() * 10, y * TS + 3 + R2() * 10, 4 + R2() * 3, 0, 6.28); g.fill(); }
        g.fillStyle = 'rgba(160,210,120,.25)'; g.beginPath(); g.arc(x * TS + 4 + R2() * 8, y * TS + 4 + R2() * 6, 2, 0, 6.28); g.fill();
      }
      g.setLineDash([6, 5]); g.strokeStyle = 'rgba(242,233,216,.22)'; g.lineWidth = 2;
      for (const q of map.sites) { g.beginPath(); g.arc(q.x * TS, q.y * TS, 2.6 * TS, 0, 6.28); g.stroke(); }
      g.setLineDash([]);
      mcv = document.createElement('canvas'); mcv.width = mcv.height = S; const m = mcv.getContext('2d');
      m.drawImage(tcv, 0, 0, S, S);
      fcv = document.createElement('canvas'); fcv.width = fcv.height = S; fimg = fcv.getContext('2d').createImageData(S, S);
      gV = new Uint8Array(S * S); gE = new Uint8Array(S * S);
    }
    function curVis() { const T = myTeam(); if (T < 0) return null; return host() ? W.vis[T] : gV; }
    function curEx() { const T = myTeam(); if (T < 0) return null; return host() ? W.ex[T] : gE; }
    function updFog() {
      const T = myTeam(), S = map.S;
      if (T >= 0 && !host()) {
        gV.fill(0);
        for (const r of R.u.values()) if (map.tm[r.o] === T) stampVis(map, gV, gE, r.x, r.y, UN[r.t].si, !!UN[r.t].air);
        for (const r of R.b.values()) if (map.tm[r.o] === T) stampVis(map, gV, gE, r.x, r.y, BD[r.t].si + (r.sz >> 1) - 1, false);
      }
      const V = curVis(), E = curEx(), d = fimg.data;
      for (let c = 0; c < S * S; c++) { d[c * 4] = 8; d[c * 4 + 1] = 6; d[c * 4 + 2] = 14; d[c * 4 + 3] = !V ? 0 : V[c] ? 0 : E[c] ? 150 : 236; }
      fcv.getContext('2d').putImageData(fimg, 0, 0);
      if (V) {
        for (const r of R.b.values()) if (map.tm[r.o] !== T && V[cellOf(map, r.x, r.y)]) bmem.set(r.i, { t: r.t, o: r.o, tx: r.tx, ty: r.ty, sz: r.sz, x: r.x, y: r.y });
        for (const [id, k] of bmem) if (V[cellOf(map, k.x, k.y)] && !R.b.has(id)) bmem.delete(id);
      }
    }
    const visAt = (x, y) => { const V = curVis(); return !V || !!V[cellOf(map, x, y)]; };

    /* ----- events / fx ----- */
    function onEv(kind, x, y, t, o) {
      const onScr = Math.abs(x - cam.x) * cam.z < cv.w * 0.7 && Math.abs(y - cam.y) * cam.z < cv.h * 0.7;
      const vis = visAt(x, y);
      if (kind === 0 && vis) { const veh = UN[t] && UN[t].cls === 'v'; for (let i = 0; i < (veh ? 14 : 7); i++) fx.push({ k: 'p', x, y, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 4, t: 0.6, T: 0.6, c: veh ? (Math.random() < 0.5 ? '#ffb347' : '#555') : (Math.random() < 0.5 ? col(o) : '#3a3330') }); if (veh) { fx.push({ k: 'r', x, y, r0: 0.2, r1: 1.4, t: 0.4, T: 0.4, c: '#ffcf6a' }); if (onScr) sfx('thud', 140); } else if (onScr) sfx('pop', 120); }
      if (kind === 1 && vis) { for (let i = 0; i < 26; i++) fx.push({ k: 'p', x: x + (Math.random() - 0.5) * 2, y: y + (Math.random() - 0.5) * 2, vx: (Math.random() - 0.5) * 6, vy: (Math.random() - 0.5) * 6, t: 1, T: 1, c: Math.random() < 0.5 ? '#ff9a3c' : '#4a4440' }); fx.push({ k: 'r', x, y, r0: 0.4, r1: 3.2, t: 0.6, T: 0.6, c: '#ffcf6a' }); if (onScr) { sfx('thud'); shake = Math.max(shake, 0.6); } if (o === me()) { api.toast(BD[t].nm + '이(가) 무너졌어요'); api.buzz(60); } }
      if (kind === 2 && vis) { fx.push({ k: 'r', x, y, r0: 0.2, r1: 1.6, t: 0.35, T: 0.35, c: '#ffd27a' }); for (let i = 0; i < 6; i++) fx.push({ k: 'p', x, y, vx: (Math.random() - 0.5) * 5, vy: (Math.random() - 0.5) * 5, t: 0.4, T: 0.4, c: '#ffb347' }); if (onScr) sfx('thud', 160); }
      if (kind === 3 && o === me()) { api.toast(BD[t].nm + ' 완성'); sfx('chip'); }
      if (kind === 4 && o === me()) { api.toast(t === 9 ? '개조 완료' : upgOf(faOf(o), t).nm + ' 연구 완료'); sfx('chip'); }
      if (kind === 7 && vis) { fx.push({ k: 'r', x, y, r0: 1.4, r1: 0.1, t: 0.5, T: 0.5, c: '#bff3ff' }); for (let i = 0; i < 8; i++) { const a = i * 0.785; fx.push({ k: 'p', x: x + Math.cos(a) * 1.2, y: y + Math.sin(a) * 1.2, vx: -Math.cos(a) * 2.4, vy: -Math.sin(a) * 2.4, t: 0.5, T: 0.5, c: '#f0d27a' }); } if (onScr) sfx('whoosh', 250); }
      if (kind === 8 && vis) { for (let i = 0; i < 6; i++) fx.push({ k: 'p', x, y, vx: (Math.random() - 0.5) * 2, vy: -1.5 - Math.random(), t: 0.6, T: 0.6, c: Math.random() < 0.5 ? '#d0874a' : '#ffb347' }); if (o === me() && onScr) sfx('chip', 300); }
      if (kind === 11 && vis) { fx.push({ k: 'p', x: x + 0.4, y: y - 0.3, vx: 0.6, vy: -1.2, t: 0.4, T: 0.4, c: '#cfc6b4' }); }
      if (kind === 9 && vis) { fx.push({ k: 'r', x, y, r0: 0.4, r1: 2.6, t: 0.5, T: 0.5, c: '#d0874a' }); if (onScr) sfx('thud', 200); if (o === me()) api.toast(t ? '본부를 펼쳤어요' : '본부를 접었어요 — ⛺펼치기로 다시 세워요'); }
      if (kind === 5 && vis && onScr) sfx('whoosh', 200);
      if (kind === 10) { // 영웅: t 0–3 기술, 9 = 도착
        const hc = t === 9 ? '#ffe08a' : ['#ffcf6a', '#c493db', '#bff3ff', '#ff8a3c'][t] || '#fff';
        if (vis) { fx.push({ k: 'r', x, y, r0: t === 2 || t === 3 ? 6 : 0.4, r1: t === 2 || t === 3 ? 0.4 : t === 0 ? 2.8 : 2, t: 0.6, T: 0.6, c: hc }); for (let i = 0; i < 10; i++) { const a = i * 0.628; fx.push({ k: 'p', x, y, vx: Math.cos(a) * 3, vy: Math.sin(a) * 3, t: 0.5, T: 0.5, c: hc }); } if (onScr) { sfx(t === 0 ? 'thud' : 'whoosh', t === 0 ? 120 : 300); if (t === 0) shake = Math.max(shake, 0.4); } }
        if (o === me()) { if (t === 9) api.toast('영웅이 도착했어요 — H로 고르기'); }
      }
      if (me() < 0 && (kind === 1 || kind === 2 || (kind === 0 && Math.random() < 0.3))) autoCam = { x, y, t: 3 };
    }
    let autoCam = null;
    // 군체 막(보랏빛 바닥), 성광 빛의 장(배치 중), 고철 잔해
    let ccv = null, ccKey = '';
    function drawFacGround(z, inV) {
      const S = map.S, T = myTeam();
      let key = ''; const src = [];
      for (const r of R.b.values()) { const B = BD[r.t]; if (B.crp && (r.done || B.hq) && (T < 0 || map.tm[r.o] === T || visAt(r.x, r.y))) { src.push(r); key += r.i + ','; } }
      if (src.length) {
        if (key !== ccKey) {
          ccKey = key; if (!ccv) { ccv = document.createElement('canvas'); ccv.width = ccv.height = S * 2; }
          const g = ccv.getContext('2d'); g.clearRect(0, 0, S * 2, S * 2);
          for (const r of src) { const rad = BD[r.t].crp; const gr = g.createRadialGradient(r.x * 2, r.y * 2, 0, r.x * 2, r.y * 2, rad * 2); gr.addColorStop(0, 'rgba(120,52,120,.5)'); gr.addColorStop(0.85, 'rgba(110,48,110,.42)'); gr.addColorStop(1, 'rgba(110,48,110,0)'); g.fillStyle = gr; g.beginPath(); g.arc(r.x * 2, r.y * 2, rad * 2, 0, 6.28); g.fill(); }
        }
        ctx.drawImage(ccv, SX(0), SY(0), S * z, S * z);
      } else ccKey = '';
      if (mode === 'place' && ghost && BD[ghost.bt].fa === 2 && !BD[ghost.bt].hq && !BD[ghost.bt].pw) {
        ctx.setLineDash([6, 5]); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(240,210,122,.7)'; ctx.fillStyle = 'rgba(240,210,122,.08)';
        for (const r of R.b.values()) if (r.o === me() && r.done && BD[r.t].pw) { ctx.beginPath(); ctx.arc(SX(r.x), SY(r.y), BD[r.t].pw * z, 0, 6.28); ctx.fill(); ctx.stroke(); }
        ctx.setLineDash([]);
      }
      if (R.wr) for (const w of R.wr) {
        if (!inV(w[0], w[1]) || !visAt(w[0], w[1])) continue;
        const X = SX(w[0]), Y = SY(w[1]), q = z * 0.32;
        ctx.fillStyle = '#4a4038'; ctx.fillRect(X - q, Y - q * 0.5, q * 1.4, q); ctx.fillStyle = '#7a6a58'; ctx.fillRect(X - q * 0.2, Y - q, q * 0.9, q * 0.8); ctx.fillStyle = '#d0874a'; ctx.fillRect(X + q * 0.2, Y - q * 0.2, q * 0.4, q * 0.3);
      }
    }
    function shotFx(r, D, x, y, isB) {
      // find a target near the facing direction
      const a = r.f * Math.PI / 8, rg = D.rg;
      let tx = x + Math.cos(a) * Math.max(1, rg), ty = y + Math.sin(a) * Math.max(1, rg), bd = 1e9; const T = map.tm[r.o];
      for (const e of R.u.values()) { if (map.tm[e.o] === T) continue; const dx = e.x - x, dy = e.y - y, d = hyp(dx, dy); if (d > rg + 1.6) continue; const da = Math.abs(((Math.atan2(dy, dx) - a + 9.42) % 6.283) - 3.14); if (da > 0.5) continue; if (d < bd) { bd = d; tx = e.x; ty = e.y; } }
      if (bd > 1e8) for (const e of R.b.values()) { if (map.tm[e.o] === T) continue; const d = hyp(e.x - x, e.y - y) - e.sz / 2; if (d < rg + 1 && d < bd) { bd = d; tx = e.x; ty = e.y; } }
      const onScr = Math.abs(x - cam.x) * cam.z < cv.w * 0.6 && Math.abs(y - cam.y) * cam.z < cv.h * 0.6;
      const k = isB ? (BD[r.t].fa === 2 ? 'ray' : BD[r.t].fa === 1 ? 'spit' : 'tw') : D.fx || (isW(r.t) ? 'wk' : 'line');
      if (k === 'flame') { for (let i = 0; i < 7; i++) { const q = Math.random(); fx.push({ k: 'f', x: x + (tx - x) * q * 0.3, y: y + (ty - y) * q * 0.3, vx: (tx - x) * (1.6 + Math.random()) + (Math.random() - 0.5), vy: (ty - y) * (1.6 + Math.random()) + (Math.random() - 0.5), t: 0.35, T: 0.35 }); } if (onScr) sfx('whoosh', 220); }
      else if (k === 'shell' || k === 'glob') { fx.push({ k: 's', x0: x, y0: y, x1: tx, y1: ty, t: 0.45, T: 0.45, c: k === 'glob' ? '#9bd84a' : null }); if (onScr) sfx('thud', 200); }
      else if (k === 'wk') { fx.push({ k: 'p', x: (x + tx) / 2, y: (y + ty) / 2, vx: (Math.random() - 0.5) * 2, vy: (Math.random() - 0.5) * 2, t: 0.2, T: 0.2, c: '#ffe9a8' }); }
      else if (k === 'bite' || k === 'blade') { const c = k === 'blade' ? '#bff3ff' : '#e8dcc0'; for (let i = 0; i < 3; i++) fx.push({ k: 'p', x: tx + (Math.random() - 0.5) * 0.6, y: ty + (Math.random() - 0.5) * 0.6, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 3, t: 0.22, T: 0.22, c }); if (onScr) sfx('tick', 140); }
      else if (k === 'acid') { /* bursts via event */ }
      else {
        const L2 = { line: ['#ffe08a', 1, 0.09], tw: ['#ffe08a', 1, 0.09], snipe: ['#ffffff', 1.6, 0.18], drone: ['#9fe8ff', 1, 0.09], spit: ['#b8f06a', 1.3, 0.12], ray: ['#bff3ff', 1.4, 0.12], lance: ['#f0d27a', 2.4, 0.2], beam: ['#f0d27a', 3, 0.25] }[k] || ['#ffe08a', 1, 0.09];
        fx.push({ k: 'l', x0: x + Math.cos(a) * 0.4, y0: y + Math.sin(a) * 0.4, x1: tx + (Math.random() - 0.5) * 0.3, y1: ty + (Math.random() - 0.5) * 0.3, t: L2[2], T: L2[2], c: L2[0], w: L2[1] });
        if (onScr) sfx(k === 'snipe' || k === 'lance' ? 'hit' : 'tick', k === 'snipe' ? 120 : 110);
      }
    }
    function mineFx(r) { const a = r.f * Math.PI / 8; fx.push({ k: 'p', x: r.x + Math.cos(a) * 0.7, y: r.y + Math.sin(a) * 0.7, vx: (Math.random() - 0.5) * 2, vy: -1 - Math.random(), t: 0.3, T: 0.3, c: '#ffe9a8' }); }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h, land = w >= h * 1.05;
      const bs = clamp(Math.floor(Math.min(w, h) / 7.4), 44, 54), gap = 4;
      const mm = land ? clamp(Math.floor(h * 0.3), 90, 150) : clamp(Math.floor(w * 0.3), 90, 130);
      const cw = 3 * bs + 2 * gap, ch = 3 * bs + 2 * gap;
      const lo = { w, h, land, bs, gap, mm, cw, ch };
      lo.card = { x: w - cw - 6, y: h - ch - 6 };
      lo.mini = { x: 6, y: h - mm - 6, s: mm };
      if (land) {
        lo.util = { x: 6, y: lo.mini.y - 8 - (4 * bs + 3 * gap), cols: 2, bs };
        lo.info = { x: 6 + mm + 8, y: h - bs - 6, w: lo.card.x - 8 - (6 + mm + 8), h: bs };
      } else {
        { const ub = Math.max(44, Math.min(bs, Math.floor((w - 12 - 6 * gap) / 7))); lo.util = { x: 6, y: lo.card.y - 8 - ub, cols: 7, bs: ub }; }
        lo.info = { x: 6 + mm + 8, y: lo.card.y, w: 0, h: 0 };
        lo.info = { x: 6, y: lo.util.y - 6 - 40, w: w - 12, h: 40 };
      }
      lay = lo;
    }

    /* ----- selection helpers ----- */
    const myU = () => { const s = me(), out = []; for (const r of R.u.values()) if (r.o === s) out.push(r); return out; };
    function selList() { return sel.map((id) => (selKind === 'b' || selKind === 'eb' ? R.b.get(id) : R.u.get(id))).filter(Boolean); }
    function setSel(ids, kind) { sel = ids.slice(0, 150); selKind = sel.length ? kind : null; card = 'main'; if (mode !== 'place') mode = null; }
    function selUnits() { return selKind === 'u' ? selList() : []; }
    function selIds() { return selUnits().map((r) => r.i); }
    function hasWorkerSel() { return selUnits().some((r) => isW(r.t)); }
    function myDoneTypes() { const s = me(), d = new Array(BD.length).fill(0); for (const r of R.b.values()) if (r.o === s && r.done) d[r.t]++; return d; }
    function myTypes() { const s = me(), d = new Array(BD.length).fill(0); for (const r of R.b.values()) if (r.o === s) d[r.t]++; return d; }
    function pd() { return R.p[me()] || { ore: 0, cry: 0, used: 0, cap: 0, up: [0, 0, 0, 0], alive: true }; }
    function costWhy(c) { const p = pd(); if (p.ore < c[0]) return '광석이 모자라요'; if (p.cry < c[1]) return '수정이 모자라요'; return ''; }
    function heroWhy() {
      if (myU().some((r) => UN[r.t].hero)) return '영웅은 한 번에 한 명이에요';
      for (const b of R.b.values()) if (b.o === me() && (b.q || []).some((q) => q < 100 && UN[q] && UN[q].hero)) return '이미 부르는 중이에요';
      const c = pd().hc || 0; return c > 0 ? '다시 부르려면 ' + c + '초' : '';
    }
    function selectHero() { const r = myU().find((u) => UN[u.t].hero); if (!r) { api.toast('영웅이 없어요 — 본부에서 불러요'); return; } setSel([r.i], 'u'); cam.x = r.x; cam.y = r.y; sfx('click'); }
    function reqWhy(req) { if (req < 0) return ''; return myDoneTypes()[req] ? '' : BD[req].nm + '이(가) 필요해요'; }
    function trainWhy(ut) { const D = UN[ut]; const r = reqWhy(D.req); if (r) return r; const c = costWhy(D.c); if (c) return c; const p = pd(); if (p.used + D.sup > p.cap) return p.cap >= 100 ? '보급이 최대(100)예요' : '보급이 모자라요 — ' + BD[myF().b[1]].nm + '을(를) 지으세요'; return ''; }
    function buildWhy(bt) { const B = BD[bt]; const r = reqWhy(B.req); if (r) return r; return costWhy(B.c); }
    function resWhy(v) { const p = pd(); if (p.up[v] >= 2) return '이미 최고 단계예요'; for (const r of R.b.values()) if (r.o === me() && r.q && r.q.includes(100 + v)) return '연구 중이에요'; return costWhy(myUG()[v].c[p.up[v]]); }

    /* ----- command card ----- */
    function cardItems() {
      const it = new Array(9).fill(null);
      if (me() < 0 || st.ph !== 'play') return it;
      if (mode === 'place') {
        it[6] = { lab: '짓기', ic: '✓', on: confirmPlace, dis: !ghost || !ghost.ok, prim: 1 };
        it[8] = { lab: '취소', ic: '✕', on: () => { mode = null; ghost = null; } };
        return it;
      }
      if (mode === 'pingK') {
        PGK.forEach((g, k) => { it[k] = { lab: g.nm, ic: g.ic, on: () => { if (pingAt) { sendPing(k, pingAt.x, pingAt.y); pingAt = null; mode = null; } else { mode = 'ping'; pingAt = { k }; } } }; });
        it[8] = { lab: '취소', ic: '✕', on: () => { mode = null; pingAt = null; } }; return it;
      }
      if (mode === 'ping') { it[8] = { lab: '취소', ic: '✕', on: () => { mode = null; pingAt = null; } }; return it; }
      if (mode === 'amove' || mode === 'rally' || mode === 'drop') { it[8] = { lab: '취소', ic: '✕', on: () => { mode = null; } }; return it; }
      if (!sel.length) {
        it[0] = { lab: '본부', bg: myF().b[0], on: () => { const r = [...R.b.values()].find((b) => b.o === me() && BD[b.t].hq); if (r) { setSel([r.i], 'b'); cam.x = r.x; cam.y = r.y; sfx('click'); } else { const m = [...R.u.values()].find((u) => u.o === me() && UN[u.t].mb); if (m) { setSel([m.i], 'u'); cam.x = m.x; cam.y = m.y; } } } };
        if (teamPlay()) it[2] = { lab: '신호', ic: '📍', on: () => { mode = 'pingK'; pingAt = null; } };
        it[1] = { lab: '일꾼 전부', ug: myF().w, on: () => { const ids = myU().filter((r) => isW(r.t)).map((r) => r.i); if (ids.length) { setSel(ids, 'u'); sfx('click'); } } };
        return it;
      }
      if (selKind === 'u') {
        if (card === 'build') {
          myF().b.forEach((bt, i) => { const B = BD[bt], why = buildWhy(bt); it[i] = { lab: B.nm, sub: B.c[0] + (B.c[1] ? '/' + B.c[1] : ''), bg: bt, why, red: !!why, on: () => startPlace(bt) }; });
          it[8] = { lab: '뒤로', ic: '‹', on: () => { card = 'main'; } };
          return it;
        }
        const hr = selUnits().find((r) => UN[r.t].hero && r.o === me());
        if (hr) { const K = HS[UN[hr.t].hf], cd = pd().hk || 0; it[0] = { lab: K.nm, ic: K.ic, sub: cd > 0 ? cd + '초' : '준비', why: cd > 0 ? '기술 재사용까지 ' + cd + '초' : '', red: cd > 0, on: () => { send(['hs', hr.i]); sfx('whoosh'); } }; }
        it[3] = { lab: '공격', ic: '⚔', on: () => { mode = 'amove'; }, act: mode === 'amove' };
        it[4] = { lab: '정지', ic: '■', on: () => { send(['s', selIds()]); sfx('click'); } };
        it[5] = { lab: '위치 사수', ic: '⛨', on: () => { send(['h', selIds()]); sfx('click'); api.toast('제자리에서만 싸워요'); } };
        if (hasWorkerSel()) it[6] = { lab: '건설', ic: '⚒', on: () => { card = 'build'; } };
        const tps = selUnits().filter((r) => r.t === TP);
        if (tps.length) {
          const n = tps.reduce((a, r) => a + (r.cr || 0), 0);
          it[7] = { lab: '골라 내리기', ic: '⤓', on: () => { if (!n) { api.toast('탄 유닛이 없어요 — 보병을 고르고 수송기를 누르세요'); return; } mode = 'drop'; }, act: mode === 'drop', dis: !n };
          it[8] = { lab: '바로 내리기', ic: '⇩', on: () => { send(['u', tps.map((r) => r.i)]); sfx('click'); }, dis: !n };
        }
        const mbs = selUnits().filter((r) => UN[r.t].mb);
        if (mbs.length) it[7] = { lab: '펼치기', ic: '⛺', on: () => { const r = mbs[0]; const tx = Math.round(r.x - 2), ty = Math.round(r.y - 2), bt = FAC[3].b[0]; const ok = host() ? canPlace(W, bt, tx, ty, me(), 0, true) : canPlaceG(map, gOccNow(), gNodeNow(), bt, tx, ty, 0); if (!ok) { api.toast('여기에는 펼 수 없어요 — 넓은 빈 땅(광석에서 2칸 떨어진 곳)으로 옮기세요'); api.buzz(20); return; } send(['dp', r.i]); sfx('chip'); } };
        if (faOf(me()) === 3) {
          const mo = selUnits().filter((r) => !r.md && !isW(r.t) && !UN[r.t].mb && UN[r.t].fa === 3);
          if (mo.length) { const c0 = mo.reduce((a, r) => a + Math.ceil(UN[r.t].c[0] * MOD.c), 0), c1 = mo.reduce((a, r) => a + Math.ceil(UN[r.t].c[1] * MOD.c), 0); const near = [...R.b.values()].some((b) => b.o === me() && b.done && BD[b.t].mod && mo.some((r) => hyp(r.x - b.x, r.y - b.y) <= BD[b.t].mod + b.sz / 2));
            const why = !near ? '정비소 근처(7칸)로 데려가세요' : costWhy([Math.ceil(UN[mo[0].t].c[0] * MOD.c), Math.ceil(UN[mo[0].t].c[1] * MOD.c)]);
            it[8] = { lab: '개조', ic: '🔧', sub: c0 + (c1 ? '/' + c1 : ''), why, red: !!why, on: () => { send(['v', mo.map((r) => r.i)]); sfx('chip'); } }; }
        }
        return it;
      }
      if (selKind === 'b') {
        const b = R.b.get(sel[0]); if (!b) return it;
        if (!b.done) { it[8] = { lab: '건설 취소', ic: '✕', on: () => { send(['z', b.i]); setSel([], null); } }; return it; }
        const B = BD[b.t];
        (B.tr || []).forEach((ut, i) => { const D = UN[ut], why = trainWhy(ut); it[i] = { lab: D.nm, sub: D.c[0] + (D.c[1] ? '/' + D.c[1] : ''), ug: ut, why, red: !!why, on: () => train(b, ut) }; });
        if (B.rs) B.rs.forEach((v, i) => { const p = pd(), lv = p.up[v], why = resWhy(v), G = myUG()[v]; const c = G.c[Math.min(1, lv)]; it[i] = { lab: G.nm + (lv >= 2 ? ' ✓' : ' ' + (lv + 1)), sub: lv >= 2 ? '완료' : c[0] + '/' + c[1], ic: G.ic, why, red: !!why, on: () => research(b, v) }; });
        if (B.hq && st.mode !== 1) { const ht = HERO0 + faOf(me()), D = UN[ht], why = heroWhy() || trainWhy(ht); it[1] = { lab: D.nm, sub: D.c[0] + '/' + D.c[1], ug: ht, why, red: !!why, on: () => { if (why) { api.toast(why); sfx('click'); return; } train(b, ht); } }; }
        if (B.pk) it[7] = { lab: '접기', ic: '⛺', why: b.q && b.q.length ? '생산을 다 끝내고 접어요' : '', red: !!(b.q && b.q.length), on: () => { send(['pk', b.i]); setSel([], null); sfx('chip'); } };
        if (B.tr) it[8] = { lab: '집결', ic: '⚑', on: () => { mode = 'rally'; }, act: mode === 'rally' };
      }
      return it;
    }
    function train(b, ut) {
      const why = trainWhy(ut); if (why) { api.toast(why); sfx('click'); return; }
      if (b.q && b.q.length >= 5) { api.toast('대기열이 가득 찼어요'); return; }
      send(['t', b.i, ut]); sfx('pop'); api.buzz(8);
    }
    function research(b, v) { const why = resWhy(v); if (why) { api.toast(why); return; } if (b.q && b.q.length >= 2) { api.toast('대기열이 가득 찼어요'); return; } send(['r', b.i, v]); sfx('chip'); }
    function startPlace(bt) {
      const why = buildWhy(bt); if (why) { api.toast(why); sfx('click'); return; }
      mode = 'place'; const B = BD[bt];
      ghost = { bt, tx: Math.round(cam.x - B.sz / 2), ty: Math.round(cam.y - B.sz / 2), ok: false };
      if (siteOnly(bt)) snapSite(cam.x, cam.y, true);
      validGhost(); sfx('click');
    }
    function snapSite(x, y, any) {
      let best = null, bd = any ? 1e9 : 7;
      for (const q of map.sites) { const d = hyp(q.x - x, q.y - y); if (d < bd) { bd = d; best = q; } }
      if (best) { ghost.tx = best.x - 2; ghost.ty = best.y - 2; } else { ghost.tx = Math.round(x - 2); ghost.ty = Math.round(y - 2); }
    }
    let gOcc = null, gNode = null, gOccT = -1;
    function gOccNow() { if (host()) return W.occ; validGhostCache(); return gOcc; }
    function gNodeNow() { if (host()) return W.nodeAt; validGhostCache(); return gNode; }
    function validGhostCache() {
      if (gOcc && gOccT === frame >> 3) return;
      gOccT = frame >> 3; const S = map.S; gOcc = new Int32Array(S * S); gNode = new Int16Array(S * S).fill(-1);
      for (const r of R.b.values()) for (let y = r.ty; y < r.ty + r.sz; y++) for (let x = r.tx; x < r.tx + r.sz; x++) gOcc[y * S + x] = r.i;
      for (const k of bmem.values()) for (let y = k.ty; y < k.ty + k.sz; y++) for (let x = k.tx; x < k.tx + k.sz; x++) gOcc[y * S + x] = 1;
      map.nodes.forEach((q, i) => { if ((R.na[i] || 0) > 0) gNode[q.c] = i; });
    }
    function validGhost() {
      if (!ghost) return;
      let occ, nodeAt;
      if (host()) { occ = W.occ; nodeAt = W.nodeAt; }
      else {
        if (!gOcc || gOccT !== frame >> 3) {
          gOccT = frame >> 3; const S = map.S; gOcc = new Int32Array(S * S); gNode = new Int16Array(S * S).fill(-1);
          for (const r of R.b.values()) for (let y = r.ty; y < r.ty + r.sz; y++) for (let x = r.tx; x < r.tx + r.sz; x++) gOcc[y * S + x] = r.i;
          for (const k of bmem.values()) for (let y = k.ty; y < k.ty + k.sz; y++) for (let x = k.tx; x < k.tx + k.sz; x++) gOcc[y * S + x] = 1;
          map.nodes.forEach((q, i) => { if ((R.na[i] || 0) > 0) gNode[q.c] = i; });
        }
        occ = gOcc; nodeAt = gNode;
      }
      let ok = canPlaceG(map, occ, nodeAt, ghost.bt, ghost.tx, ghost.ty, 0) && facPlace(host() ? W.blds : [...R.b.values()], me(), ghost.bt, ghost.tx, ghost.ty);
      const E = curEx(); const sz = BD[ghost.bt].sz;
      if (ok && E) for (let y = ghost.ty; y < ghost.ty + sz && ok; y++) for (let x = ghost.tx; x < ghost.tx + sz; x++) if (!E[y * map.S + x]) { ok = false; break; }
      ghost.ok = ok;
    }
    function confirmPlace() {
      if (!ghost) return;
      validGhost();
      if (!ghost.ok) { api.toast('여기에는 지을 수 없어요'); api.buzz(20); return; }
      const why = buildWhy(ghost.bt); if (why) { api.toast(why); return; }
      const ws = selUnits().filter((r) => isW(r.t)); if (!ws.length) { mode = null; ghost = null; return; }
      const sz = BD[ghost.bt].sz, cx = ghost.tx + sz / 2, cy = ghost.ty + sz / 2;
      ws.sort((a, b) => hyp(a.x - cx, a.y - cy) - hyp(b.x - cx, b.y - cy));
      send(['b', ghost.bt, ghost.tx, ghost.ty, ws[0].i]); sfx('chip'); api.buzz(10);
      pings.push({ x: cx, y: cy, t: 0.8, c: '#f2c14e' });
      if (!mods.shift) { mode = null; ghost = null; card = 'main'; }
    }

    /* ----- world taps ----- */
    const toWorld = (px, py) => ({ x: (px - cv.w / 2) / cam.z + cam.x, y: (py - cv.h / 2) / cam.z + cam.y });
    const SX = (x) => (x - cam.x) * cam.z + cv.w / 2, SY = (y) => (y - cam.y) * cam.z + cv.h / 2;
    function pickAt(px, py, touch) {
      const p = toWorld(px, py), rad = (touch ? 20 : 12) / cam.z;
      let best = null, bd = 1e9;
      for (const r of R.u.values()) {
        if (r.o !== me() && !visAt(r.x, r.y)) continue;
        const yy = r.y - (UN[r.t].air ? 0.25 : 0);
        const d = hyp(r.x - p.x, yy - p.y) - UN[r.t].r; if (d < rad && d < bd) { bd = d; best = { k: 'u', r }; }
      }
      if (best) return best;
      for (const r of R.b.values()) { if (r.o !== me() && map.tm[r.o] !== myTeam() && !visAt(r.x, r.y)) continue; if (p.x >= r.tx - 0.2 && p.x <= r.tx + r.sz + 0.2 && p.y >= r.ty - 0.2 && p.y <= r.ty + r.sz + 0.2) return { k: 'b', r }; }
      for (let i = 0; i < map.nodes.length; i++) { const q = map.nodes[i]; if (!(R.na[i] > 0)) continue; if (hyp(q.x - p.x, q.y - p.y) < 0.6 + rad * 0.6) return { k: 'n', i, q }; }
      return { k: 'g', x: p.x, y: p.y };
    }
    function command(hit) { // "right click" semantics
      const T = myTeam();
      if (selKind === 'b') {
        const b = R.b.get(sel[0]); if (!b || !b.done || !BD[b.t].tr) return false;
        if (hit.k === 'n') { send(['p', b.i, Math.round(hit.q.x * 10), Math.round(hit.q.y * 10), hit.i]); b.rx = hit.q.x; b.ry = hit.q.y; }
        else { const p = hit.k === 'g' ? hit : hit.r; send(['p', b.i, Math.round(p.x * 10), Math.round(p.y * 10), -1]); b.rx = p.x; b.ry = p.y; }
        pings.push({ x: b.rx, y: b.ry, t: 0.7, c: '#9fe8ff' }); sfx('click'); return true;
      }
      const ids = selIds(); if (!ids.length) return false;
      if (hit.k === 'u' || hit.k === 'b') {
        const r = hit.r;
        if (map.tm[r.o] !== T) { send(['k', r.i, ids]); pings.push({ x: r.x, y: r.y, t: 0.7, c: '#ee6a55' }); sfx('click'); api.buzz(8); return true; }
        if (hit.k === 'b' && !r.done && r.o === me() && hasWorkerSel()) { send(['k', r.i, ids]); pings.push({ x: r.x, y: r.y, t: 0.7, c: '#f2c14e' }); return true; }
        if (hit.k === 'u' && r.o === me() && boardHit(r)) { send(['k', r.i, ids]); pings.push({ x: r.x, y: r.y, t: 0.7, c: '#9fe8ff' }); sfx('click'); api.toast(r.t === TP ? '수송기에 태워요' : '수송기가 태우러 가요'); return true; }
        send(['m', Math.round(r.x * 10), Math.round(r.y * 10), 0, ids]); pings.push({ x: r.x, y: r.y, t: 0.7, c: '#7ff0a0' }); return true;
      }
      if (hit.k === 'n') { if (hasWorkerSel()) { send(['g', hit.i, ids]); pings.push({ x: hit.q.x, y: hit.q.y, t: 0.7, c: hit.q.k ? CRY : ORE }); sfx('click'); return true; } }
      const p = hit.k === 'n' ? hit.q : hit;
      send(['m', Math.round(p.x * 10), Math.round(p.y * 10), mode === 'amove' ? 1 : 0, ids]);
      pings.push({ x: p.x, y: p.y, t: 0.7, c: mode === 'amove' ? '#ee6a55' : '#7ff0a0' }); sfx('click'); api.buzz(6);
      return true;
    }
    // own transport tapped with infantry/vehicles selected (board), or own unit tapped with only transports selected (pick up)
    function boardHit(r) {
      const su = selUnits(); if (!su.length || su.some((o) => o.i === r.i)) return false;
      if (r.t === TP) return su.some((o) => seatOf(o.t) > 0);
      return seatOf(r.t) > 0 && su.every((o) => o.t === TP);
    }
    function selectHit(hit, add) {
      if (hit.k === 'u') {
        const r = hit.r;
        if (r.o === me()) {
          const now = performance.now();
          if (lastTap.id === r.i && now - lastTap.t < 380) { // double tap: same type on screen
            const ids = myU().filter((o) => o.t === r.t && Math.abs(SX(o.x) - SX(r.x)) < cv.w && Math.abs(SY(o.y) - SY(r.y)) < cv.h).map((o) => o.i);
            setSel(ids, 'u'); lastTap.id = 0;
          } else if (add && selKind === 'u') { if (!sel.includes(r.i)) sel.push(r.i); else sel = sel.filter((x) => x !== r.i); }
          else setSel([r.i], 'u');
          lastTap = { id: r.i, t: now }; sfx('click'); return;
        }
        setSel([r.i], 'e'); return;
      }
      if (hit.k === 'b') { setSel([hit.r.i], hit.r.o === me() ? 'b' : 'eb'); sfx('click'); return; }
      setSel([], null);
    }
    function tapWorld(px, py, touch, right) {
      const hit = pickAt(px, py, touch);
      if (mode === 'place') {
        const p = toWorld(px, py), sz = BD[ghost.bt].sz;
        if (!touch && !right) { confirmPlace(); return; }
        if (right) { mode = null; ghost = null; return; }
        if (p.x >= ghost.tx && p.x <= ghost.tx + sz && p.y >= ghost.ty && p.y <= ghost.ty + sz && ghost.ok) { confirmPlace(); return; }
        if (siteOnly(ghost.bt)) snapSite(p.x, p.y, false); else { ghost.tx = Math.round(p.x - sz / 2); ghost.ty = Math.round(p.y - sz / 2); }
        validGhost(); return;
      }
      if (mode === 'ping') { if (!right && pingAt) { const w0 = toWorld(px, py); sendPing(pingAt.k, w0.x, w0.y); } mode = null; pingAt = null; return; }
      if (mode === 'amove') { if (right) { mode = null; return; } if (hit.k === 'u' || hit.k === 'b') { if (map.tm[hit.r.o] !== myTeam()) { command(hit); mode = null; return; } } command(hit.k === 'g' ? hit : { k: 'g', x: toWorld(px, py).x, y: toWorld(px, py).y }); mode = null; return; }
      if (mode === 'rally') { command(hit.k === 'u' ? { k: 'g', x: hit.r.x, y: hit.r.y } : hit); mode = null; return; }
      if (mode === 'drop') {
        if (right) { mode = null; return; }
        const p = toWorld(px, py), ids = selUnits().filter((r) => r.t === TP).map((r) => r.i);
        if (!map.pass[cellOf(map, p.x, p.y)]) { api.toast('바위 위에는 못 내려요 — 땅을 누르세요'); api.buzz(20); return; }
        if (ids.length) { send(['u', ids, Math.round(p.x * 10), Math.round(p.y * 10)]); pings.push({ x: p.x, y: p.y, t: 0.8, c: '#9fe8ff' }); sfx('click'); }
        mode = null; return;
      }
      if (right) { command(hit); return; }
      if (!touch) { selectHit(hit, mods.shift); return; }
      // touch: own things select; with a selection, enemies/ground/nodes are commands
      if (hit.k === 'u' && hit.r.o === me()) { if (selKind === 'u' && boardHit(hit.r)) { command(hit); return; } selectHit(hit, false); return; }
      if (hit.k === 'b' && hit.r.o === me()) {
        if (selKind === 'u' && !hit.r.done && hasWorkerSel()) { command(hit); return; }
        selectHit(hit, false); return;
      }
      if (selKind === 'u' || (selKind === 'b' && R.b.get(sel[0]) && BD[R.b.get(sel[0]).t].tr && hit.k !== 'b')) { if (command(hit)) return; }
      if (hit.k === 'u' || hit.k === 'b') { selectHit(hit, false); return; }
      if (selKind === 'e' || selKind === 'eb') setSel([], null);
    }
    function boxSelect(x0, y0, x1, y1) {
      const a = toWorld(Math.min(x0, x1), Math.min(y0, y1)), b = toWorld(Math.max(x0, x1), Math.max(y0, y1));
      let us = myU().filter((r) => r.x >= a.x - 0.3 && r.x <= b.x + 0.3 && r.y >= a.y - 0.3 && r.y <= b.y + 0.3);
      if (us.some((r) => !isW(r.t))) us = us.filter((r) => !isW(r.t));
      if (mods.shift && selKind === 'u') { const s = new Set(sel); for (const r of us) s.add(r.i); setSel([...s], 'u'); }
      else setSel(us.map((r) => r.i), 'u');
      if (us.length) { sfx('click'); api.buzz(8); }
    }
    function selectArmy() { const ids = myU().filter((r) => !isW(r.t) && !UN[r.t].mb).map((r) => r.i); if (!ids.length) { api.toast('군대가 없어요'); return; } setSel(ids, 'u'); sfx('click'); }
    function selectIdle() {
      const ws = myU().filter((r) => isW(r.t) && r.idle); if (!ws.length) { api.toast('쉬는 일꾼이 없어요'); return; }
      idleIdx = (idleIdx + 1) % ws.length; const r = ws[idleIdx]; setSel([r.i], 'u'); cam.x = r.x; cam.y = r.y; sfx('click');
    }
    function centerBase() { const s = me(); for (const r of R.b.values()) if (r.o === s && BD[r.t].hq) { cam.x = r.x; cam.y = r.y; return; } for (const r of R.u.values()) if (r.o === s && UN[r.t].mb) { cam.x = r.x; cam.y = r.y; return; } }
    function groupTap(g, assign) {
      const ids = selKind === 'u' ? selIds() : [];
      if (assign || (!groups[g].length && ids.length)) { if (!ids.length) return; groups[g] = ids.slice(); api.toast((g + 1) + '번 부대 지정 (' + ids.length + ')'); api.buzz(20); sfx('chip'); return; }
      const live = groups[g].filter((id) => R.u.has(id) && R.u.get(id).o === me()); groups[g] = live;
      if (!live.length) { api.toast('비어 있어요 — 유닛을 고르고 길게 누르면 지정'); return; }
      const now = performance.now();
      if (grpTap.g === g && now - grpTap.t < 400) { let x = 0, y = 0; for (const id of live) { const r = R.u.get(id); x += r.x; y += r.y; } cam.x = x / live.length; cam.y = y / live.length; }
      grpTap = { g, t: now }; setSel(live, 'u'); sfx('click');
    }

    /* ----- input ----- */
    const ptrs = new Map(); let pinch = null, held = null;
    function hitBtn(x, y) { for (let i = btns.length - 1; i >= 0; i--) { const b = btns[i]; if (x >= b.x && y >= b.y && x <= b.x + b.w && y <= b.y + b.h) return b; } return null; }
    function miniJump(x, y) { const m = lay.mini; cam.x = clamp((x - m.x) / m.s * map.S, 0, map.S); cam.y = clamp((y - m.y) / m.s * map.S, 0, map.S); }
    function onDown(ev) {
      if (!lay || !map) return;
      const p = cv.local(ev); ev.preventDefault();
      try { cv.cv.setPointerCapture(ev.pointerId); } catch (e) {}
      const touch = ev.pointerType !== 'mouse';
      const b = hitBtn(p.x, p.y);
      if (b) { if (b.dis && !b.why) return; ptrs.set(ev.pointerId, { k: 'btn', b, x: p.x, y: p.y, t0: performance.now(), lp: false }); return; }
      const m = lay.mini;
      if (p.x >= m.x && p.y >= m.y && p.x <= m.x + m.s && p.y <= m.y + m.s) {
        if (ev.button === 2 && me() >= 0) { const wx = (p.x - m.x) / m.s * map.S, wy = (p.y - m.y) / m.s * map.S; command({ k: 'g', x: wx, y: wy }); return; }
        if (mode === 'ping' && pingAt && pingAt.k != null && ev.button !== 2) { sendPing(pingAt.k, (p.x - m.x) / m.s * map.S, (p.y - m.y) / m.s * map.S); mode = null; pingAt = null; return; }
        ptrs.set(ev.pointerId, { k: 'mm', t0: performance.now(), sx: p.x, sy: p.y, x: p.x, y: p.y }); miniJump(p.x, p.y); return;
      }
      const mapPtrs = [...ptrs.values()].filter((q) => q.k === 'map');
      if (touch && mapPtrs.length === 1) {
        const o = mapPtrs[0]; o.cancel = true;
        pinch = { d0: hyp(p.x - o.x, p.y - o.y) || 1, z0: cam.z, mx: (p.x + o.x) / 2, my: (p.y + o.y) / 2 };
        ptrs.set(ev.pointerId, { k: 'map', sx: p.x, sy: p.y, x: p.x, y: p.y, t0: performance.now(), moved: true, cancel: true, touch });
        return;
      }
      ptrs.set(ev.pointerId, { k: 'map', sx: p.x, sy: p.y, x: p.x, y: p.y, t0: performance.now(), moved: false, box: false, touch, btn: ev.button, cancel: false });
    }
    function onMove(ev) {
      if (!lay || !map) return;
      const p = cv.local(ev); hover = p;
      const q = ptrs.get(ev.pointerId);
      if (mode === 'place' && ghost && ev.pointerType === 'mouse' && !q) { const w = toWorld(p.x, p.y), sz = BD[ghost.bt].sz; if (siteOnly(ghost.bt)) snapSite(w.x, w.y, false); else { ghost.tx = Math.round(w.x - sz / 2); ghost.ty = Math.round(w.y - sz / 2); } validGhost(); }
      if (!q) return;
      if (q.k === 'mm') { if (q.lp) return; q.x = p.x; q.y = p.y; if (hyp(p.x - q.sx, p.y - q.sy) > 10) q.mv = true; miniJump(p.x, p.y); return; }
      if (q.k !== 'map') return;
      const px = q.x, py = q.y; q.x = p.x; q.y = p.y;
      if (pinch && q.touch) {
        const ms = [...ptrs.values()].filter((o) => o.k === 'map');
        if (ms.length >= 2) {
          const a = ms[0], b = ms[1], d = hyp(a.x - b.x, a.y - b.y) || 1, mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
          cam.z = clamp(pinch.z0 * d / pinch.d0, 11, 46);
          cam.x -= (mx - pinch.mx) / cam.z; cam.y -= (my - pinch.my) / cam.z; pinch.mx = mx; pinch.my = my;
        }
        return;
      }
      if (q.cancel) return;
      const d = hyp(p.x - q.sx, p.y - q.sy);
      if (q.box) return;
      if (!q.touch) { if (q.btn === 0 && d > 6 && mode !== 'place') { q.box = true; } else if (q.btn === 1 || (q.btn === 0 && mode === 'place')) { q.moved = true; cam.x -= (p.x - px) / cam.z; cam.y -= (p.y - py) / cam.z; } else if (d > 6) q.moved = true; return; }
      if (boxArm && d > 8) { q.box = true; return; }
      if (d > 9 || q.moved) { q.moved = true; cam.x -= (p.x - px) / cam.z; cam.y -= (p.y - py) / cam.z; }
    }
    function onUp(ev) {
      const q = ptrs.get(ev.pointerId); ptrs.delete(ev.pointerId);
      if (!q || !lay) return;
      const p = cv.local(ev);
      if (q.k === 'btn') { const b = q.b; if (!q.lp && p.x >= b.x - 8 && p.y >= b.y - 8 && p.x <= b.x + b.w + 8 && p.y <= b.y + b.h + 8) { if (b.dis) { if (b.why) { api.toast(b.why); } } else b.on(); } return; }
      if (q.k !== 'map') return;
      if (pinch) { if (![...ptrs.values()].some((o) => o.k === 'map')) pinch = null; return; }
      if (q.cancel) return;
      if (q.box) { boxSelect(q.sx, q.sy, p.x, p.y); boxArm = false; return; }
      if (q.moved) return;
      if (me() < 0) return;
      tapWorld(p.x, p.y, q.touch, !q.touch && q.btn === 2);
    }
    function onWheel(ev) { ev.preventDefault(); const p = cv.local(ev), w0 = toWorld(p.x, p.y); cam.z = clamp(cam.z * (ev.deltaY < 0 ? 1.12 : 1 / 1.12), 11, 46); const w1 = toWorld(p.x, p.y); cam.x += w0.x - w1.x; cam.y += w0.y - w1.y; }
    const noCtx = (e) => e.preventDefault();
    const onKey = (e) => { mods.ctrl = e.ctrlKey || e.metaKey; mods.shift = e.shiftKey; };
    cv.cv.addEventListener('pointerdown', onDown); cv.cv.addEventListener('pointermove', onMove); cv.cv.addEventListener('pointerup', onUp); cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false }); cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('keydown', onKey); window.addEventListener('keyup', onKey);
    const offIn = api.input ? api.input.on((type, id) => {
      if (type !== 'down' || !st || st.ph !== 'play' || me() < 0) return;
      if (id[0] === 'c' && id.length === 2 && id[1] >= '0' && id[1] <= '8') { const it = cardItems()[+id[1]]; if (it) { if (it.dis || it.red) { if (it.why) api.toast(it.why); } else it.on(); } return; }
      if (id === 'g1' || id === 'g2' || id === 'g3' || id === 'g4') { groupTap(+id[1] - 1, mods.ctrl); return; }
      if (id === 'army') selectArmy(); else if (id === 'hero') selectHero(); else if (id === 'idle') selectIdle(); else if (id === 'base') centerBase();
      else if (id === 'cancel') { mode = null; ghost = null; card = 'main'; }
      else if (id === 'zin') cam.z = clamp(cam.z * 1.15, 11, 46); else if (id === 'zout') cam.z = clamp(cam.z / 1.15, 11, 46);
    }) : null;

    /* ----- drawing ----- */
    function drawWorld(rdt) {
      const w = cv.w, h = cv.h, z = cam.z, S = map.S;
      ctx.fillStyle = '#0c0a10'; ctx.fillRect(0, 0, w, h);
      let ox = 0, oy = 0; if (shake > 0) { const fk = typeof L.fx === 'function' ? L.fx() : 1; ox = (Math.random() - 0.5) * shake * 8 * fk; oy = (Math.random() - 0.5) * shake * 8 * fk; shake = Math.max(0, shake - rdt * 2); }
      ctx.save(); ctx.translate(ox, oy);
      ctx.imageSmoothingEnabled = true;
      ctx.drawImage(tcv, SX(0), SY(0), S * z, S * z);
      const x0 = cam.x - w / 2 / z - 2, x1 = cam.x + w / 2 / z + 2, y0 = cam.y - h / 2 / z - 2, y1 = cam.y + h / 2 / z + 2;
      const inV = (x, y) => x > x0 && x < x1 && y > y0 && y < y1;
      const E = curEx();
      drawFacGround(z, inV);
      // resource nodes
      map.nodes.forEach((q, i) => {
        const a = R.na[i] || 0; if (a <= 0 || !inV(q.x, q.y)) return;
        if (E && !E[q.c]) return;
        const X = SX(q.x), Y = SY(q.y), s = z * (0.35 + 0.15 * a);
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(X + s * 0.15, Y + s * 0.5, s * 1.2, s * 0.6, 0, 0, 6.28); ctx.fill();
        if (q.k === 0) {
          ctx.fillStyle = '#9a6a2c'; ctx.beginPath(); ctx.moveTo(X - s * 1.1, Y + s * 0.5); ctx.lineTo(X - s * 0.4, Y - s * 0.9); ctx.lineTo(X + s * 0.5, Y - s * 0.5); ctx.lineTo(X + s * 1.1, Y + s * 0.5); ctx.closePath(); ctx.fill();
          ctx.fillStyle = ORE; ctx.beginPath(); ctx.moveTo(X - s * 0.6, Y + s * 0.3); ctx.lineTo(X - s * 0.3, Y - s * 0.7); ctx.lineTo(X + s * 0.3, Y - s * 0.3); ctx.lineTo(X + s * 0.1, Y + s * 0.3); ctx.closePath(); ctx.fill();
          ctx.fillStyle = 'rgba(255,240,200,.6)'; ctx.fillRect(X - s * 0.3, Y - s * 0.5, s * 0.2, s * 0.2);
        } else {
          ctx.fillStyle = 'rgba(127,228,245,.18)'; ctx.beginPath(); ctx.arc(X, Y - s * 0.3, s * 1.3, 0, 6.28); ctx.fill();
          for (const [dx, hh, ww] of [[-0.45, 1.2, 0.35], [0.1, 1.6, 0.4], [0.55, 1.0, 0.3]]) { ctx.fillStyle = CRY; ctx.beginPath(); ctx.moveTo(X + (dx - ww) * s, Y + s * 0.4); ctx.lineTo(X + dx * s, Y + (0.4 - hh) * s); ctx.lineTo(X + (dx + ww) * s, Y + s * 0.4); ctx.closePath(); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.45)'; ctx.fillRect(X + (dx - 0.06) * s, Y + (0.4 - hh * 0.8) * s, s * 0.1, hh * s * 0.5); }
        }
      });
      // buildings (+ remembered enemy buildings)
      const T = myTeam(), tm = performance.now() / 1000;
      for (const k of bmem.values()) { if (R.b.has(k.i) && visAt(k.x, k.y)) continue; if (visAt(k.x, k.y) || !inV(k.x, k.y)) continue; ctx.globalAlpha = 0.55; bldGlyph(ctx, k.t, SX(k.x), SY(k.y), k.sz * z, col(k.o), true, 1, 0, 0); ctx.globalAlpha = 1; }
      for (const r of R.b.values()) {
        if (!inV(r.x, r.y)) continue;
        if (T >= 0 && map.tm[r.o] !== T && !visAt(r.x, r.y)) continue;
        bldGlyph(ctx, r.t, SX(r.x), SY(r.y), r.sz * z, col(r.o), r.done, r.pr, r.f * Math.PI / 8, (r.q && r.q.length) ? tm * 3 : tm * 0.3);
        if (r.t === 3 && r.q && r.q.length && Math.random() < rdt * 4) fx.push({ k: 'm', x: r.x + 0.3 * r.sz * 0.75, y: r.y - r.sz * 0.42, vx: 0.2, vy: -0.6, t: 1.2, T: 1.2 });
        if (r.pan != null && r.pan !== r.an && BD[r.t].wpn && r.done) shotFx(r, BD[r.t].wpn, r.x, r.y, true);
        r.pan = r.an;
      }
      // units
      const spin = tm * 30;
      const drawU = (air) => {
        for (const r of R.u.values()) {
          const D = UN[r.t]; if (!!D.air !== air) continue;
          if (T >= 0 && map.tm[r.o] !== T && !visAt(r.x, r.y)) { r.pan = r.an; continue; }
          if (r.pan != null && r.pan !== r.an) { if (isW(r.t)) mineFx(r); else shotFx(r, D, r.x, r.y, false); }
          r.pan = r.an;
          if (!inV(r.x, r.y)) continue;
          unitGlyph(ctx, r.t, SX(r.x), SY(r.y), Math.max(4, D.r * z), col(r.o), r.f * Math.PI / 8, r.cr, spin + r.i);
          if (r.md) { ctx.fillStyle = '#ffb347'; ctx.strokeStyle = 'rgba(10,8,14,.8)'; ctx.lineWidth = 1; const X = SX(r.x) + D.r * z * 0.8, Y = SY(r.y) - D.r * z * (D.air ? 1.3 : 0.8); ctx.beginPath(); for (let i = 0; i < 10; i++) { const a = i * 0.628 - 1.571, rd = i % 2 ? 2 : 4.5; ctx.lineTo(X + Math.cos(a) * rd, Y + Math.sin(a) * rd); } ctx.closePath(); ctx.fill(); ctx.stroke(); }
        }
      };
      drawU(false);
      // fx (ground)
      ctx.lineCap = 'round';
      for (let i = fx.length - 1; i >= 0; i--) {
        const f = fx[i]; f.t -= rdt; if (f.t <= 0) { fx.splice(i, 1); continue; }
        const a = f.t / f.T;
        if (f.k === 'l') { ctx.globalAlpha = a; ctx.strokeStyle = f.c; ctx.lineWidth = f.w * Math.max(1, z * 0.06); ctx.beginPath(); ctx.moveTo(SX(f.x0), SY(f.y0)); ctx.lineTo(SX(f.x1), SY(f.y1)); ctx.stroke(); ctx.fillStyle = f.c; dot(ctx, SX(f.x1), SY(f.y1), Math.max(1.5, z * 0.08)); }
        else if (f.k === 'p') { f.x += f.vx * rdt; f.y += f.vy * rdt; ctx.globalAlpha = a; ctx.fillStyle = f.c; dot(ctx, SX(f.x), SY(f.y), Math.max(1.2, z * 0.09)); }
        else if (f.k === 'f') { f.x += f.vx * rdt; f.y += f.vy * rdt; ctx.globalAlpha = a * 0.85; ctx.fillStyle = a > 0.5 ? '#ffd36b' : '#ff7a2a'; dot(ctx, SX(f.x), SY(f.y), z * (0.18 + (1 - a) * 0.25)); }
        else if (f.k === 'r') { ctx.globalAlpha = a; ctx.strokeStyle = f.c; ctx.lineWidth = Math.max(1.5, z * 0.12); ctx.beginPath(); ctx.arc(SX(f.x), SY(f.y), z * (f.r0 + (f.r1 - f.r0) * (1 - a)), 0, 6.28); ctx.stroke(); }
        else if (f.k === 's') { const q = 1 - a, x = f.x0 + (f.x1 - f.x0) * q, y = f.y0 + (f.y1 - f.y0) * q - Math.sin(q * Math.PI) * 1.6; ctx.globalAlpha = 1; ctx.fillStyle = f.c || '#2a2622'; dot(ctx, SX(x), SY(y), Math.max(2, z * 0.14)); }
        else if (f.k === 'm') { f.x += f.vx * rdt; f.y += f.vy * rdt; ctx.globalAlpha = a * 0.35; ctx.fillStyle = '#c9c1b6'; dot(ctx, SX(f.x), SY(f.y), z * (0.15 + (1 - a) * 0.3)); }
      }
      ctx.globalAlpha = 1;
      drawU(true);
      // fog
      if (curVis()) { ctx.imageSmoothingEnabled = true; ctx.drawImage(fcv, SX(0), SY(0), S * z, S * z); }
      // selection + bars
      const selSet = new Set(sel), mv = mateView(), mc = mv ? P(mate()).color || '#fff' : null;
      if (mv && mv.ids.size) {
        ctx.strokeStyle = mc; ctx.lineWidth = 1.6; ctx.setLineDash([4, 3]);
        for (const id of mv.ids) {
          const r = mv.b ? R.b.get(id) : R.u.get(id); if (!r || r.o !== me()) continue;
          if (mv.b) { if (!inV(r.x, r.y)) continue; const X = SX(r.tx), Y = SY(r.ty), wp = r.sz * z; ctx.strokeRect(X - 2, Y - 2, wp + 4, wp + 4); continue; }
          if (!inV(r.x, r.y)) continue;
          const D = UN[r.t], X = SX(r.x), Y = SY(r.y) - (D.air ? D.r * z * 0.55 : 0), rr2 = Math.max(5, D.r * z) + 5.5;
          ctx.beginPath(); ctx.ellipse(X, Y + rr2 * 0.25, rr2, rr2 * 0.75, 0, 0, 6.28); ctx.stroke();
        }
        ctx.setLineDash([]);
      }
      for (const r of R.u.values()) {
        const isSel = selSet.has(r.i) && (selKind === 'u' || selKind === 'e');
        if (!isSel && r.hp >= 0.999) continue;
        if (T >= 0 && map.tm[r.o] !== T && !visAt(r.x, r.y)) continue;
        if (!inV(r.x, r.y)) continue;
        const D = UN[r.t], X = SX(r.x), Y = SY(r.y) - (D.air ? D.r * z * 0.55 : 0), rr2 = Math.max(5, D.r * z) + 3;
        if (isSel) { ctx.strokeStyle = r.o === me() ? '#7ff0a0' : '#ee6a55'; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.ellipse(X, Y + rr2 * 0.25, rr2, rr2 * 0.75, 0, 0, 6.28); ctx.stroke(); }
        const bw = Math.max(14, D.r * z * 2.2); ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(X - bw / 2, Y - rr2 - 5, bw, 3.5); ctx.fillStyle = r.hp > 0.5 ? '#7ff0a0' : r.hp > 0.25 ? '#f2c14e' : '#ee6a55'; ctx.fillRect(X - bw / 2, Y - rr2 - 5, bw * r.hp, 3.5);
      }
      for (const r of R.b.values()) {
        const isSel = selSet.has(r.i) && (selKind === 'b' || selKind === 'eb');
        if (T >= 0 && map.tm[r.o] !== T && !visAt(r.x, r.y)) continue;
        if (!inV(r.x, r.y)) continue;
        const X = SX(r.tx), Y = SY(r.ty), wp = r.sz * z;
        if (isSel) { ctx.strokeStyle = r.o === me() ? '#7ff0a0' : '#ee6a55'; ctx.lineWidth = 2; ctx.strokeRect(X + 1, Y + 1, wp - 2, wp - 2); if (r.rx != null && r.o === me()) { ctx.setLineDash([5, 4]); ctx.strokeStyle = 'rgba(159,232,255,.8)'; ctx.beginPath(); ctx.moveTo(SX(r.x), SY(r.y)); ctx.lineTo(SX(r.rx), SY(r.ry)); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = '#9fe8ff'; ctx.fillRect(SX(r.rx) - 1, SY(r.ry) - 12, 2, 12); ctx.fillRect(SX(r.rx), SY(r.ry) - 12, 8, 5); } }
        if (isSel || r.hp < 0.999 || !r.done) { ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(X + 2, Y - 6, wp - 4, 4); ctx.fillStyle = r.hp > 0.5 ? '#7ff0a0' : r.hp > 0.25 ? '#f2c14e' : '#ee6a55'; ctx.fillRect(X + 2, Y - 6, (wp - 4) * r.hp, 4); }
        if (!r.done) { ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(X + 2, Y + wp - 7, wp - 4, 4); ctx.fillStyle = '#f2c14e'; ctx.fillRect(X + 2, Y + wp - 7, (wp - 4) * r.pr, 4); }
        else if (r.q && r.q.length && r.o === me()) { ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(X + 2, Y + wp - 7, wp - 4, 4); ctx.fillStyle = '#9fe8ff'; ctx.fillRect(X + 2, Y + wp - 7, (wp - 4) * r.qp, 4); }
      }
      // pings
      for (let i = pings.length - 1; i >= 0; i--) { const p = pings[i]; p.t -= rdt; if (p.t <= 0) { pings.splice(i, 1); continue; }
        if (p.tp) { // team signal: pulsing double ring + label
          const X = SX(p.x), Y = SY(p.y), ph = (4 - p.t) % 1; ctx.globalAlpha = Math.min(1, p.t); ctx.strokeStyle = p.c; ctx.lineWidth = 2.5;
          for (const k2 of [ph, (ph + 0.5) % 1]) { const rad = z * (0.4 + k2 * 1.6); ctx.globalAlpha = Math.min(1, p.t) * (1 - k2); ctx.beginPath(); ctx.ellipse(X, Y, rad, rad * 0.7, 0, 0, 6.28); ctx.stroke(); }
          ctx.globalAlpha = Math.min(1, p.t); ctx.font = '700 12px ' + FONT; ctx.textAlign = 'center'; const lab = p.lab + (p.who ? ' · ' + p.who : ''), tw = ctx.measureText(lab).width + 14;
          rr(ctx, X - tw / 2, Y - z * 1.2 - 22, tw, 20, 8); ctx.fillStyle = 'rgba(23,19,31,.85)'; ctx.fill(); ctx.strokeStyle = p.c; ctx.lineWidth = 1.2; ctx.stroke();
          ctx.fillStyle = p.c; ctx.fillText(lab, X, Y - z * 1.2 - 12); continue;
        }
        ctx.globalAlpha = Math.min(1, p.t * 2); ctx.strokeStyle = p.c; ctx.lineWidth = 2; const rad = z * (0.3 + (0.8 - p.t) * 0.9); ctx.beginPath(); ctx.ellipse(SX(p.x), SY(p.y), rad, rad * 0.7, 0, 0, 6.28); ctx.stroke(); }
      ctx.globalAlpha = 1;
      if (W && W.mis && W.mis.mk) for (const q of W.mis.mk) { // 작전 표시: 목적지·거점·지휘 전차
        const c = ['rgba(242,233,216,.8)', '#7ff0a0', '#ee6a55'][q[3]] || '#e3ae45', r = q[2] * z, pul = 0.6 + 0.4 * Math.sin(frame / 12);
        ctx.globalAlpha = 0.5 + 0.5 * pul; ctx.strokeStyle = c; ctx.lineWidth = 2; ctx.setLineDash(q[2] >= 3 ? [6, 5] : []);
        ctx.beginPath(); ctx.ellipse(SX(q[0]), SY(q[1]), r, r * 0.8, 0, 0, 6.28); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
      }
      // ghost
      if (mode === 'place' && ghost) {
        const B = BD[ghost.bt], X = SX(ghost.tx), Y = SY(ghost.ty), wp = B.sz * z;
        ctx.globalAlpha = 0.5; bldGlyph(ctx, ghost.bt, X + wp / 2, Y + wp / 2, wp, col(me()), true, 1, 0, 0); ctx.globalAlpha = 1;
        ctx.fillStyle = ghost.ok ? 'rgba(127,240,160,.22)' : 'rgba(238,106,85,.3)'; ctx.fillRect(X, Y, wp, wp);
        ctx.strokeStyle = ghost.ok ? '#7ff0a0' : '#ee6a55'; ctx.lineWidth = 2; ctx.strokeRect(X, Y, wp, wp);
        if (B.wpn) { ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.beginPath(); ctx.arc(X + wp / 2, Y + wp / 2, (B.wpn.rg + 1) * z, 0, 6.28); ctx.stroke(); }
      }
      // box
      for (const q of ptrs.values()) if (q.k === 'map' && q.box) { ctx.fillStyle = 'rgba(127,240,160,.12)'; ctx.strokeStyle = '#7ff0a0'; ctx.lineWidth = 1.5; const bx = Math.min(q.sx, q.x), by = Math.min(q.sy, q.y), bw = Math.abs(q.x - q.sx), bh = Math.abs(q.y - q.sy); ctx.fillRect(bx, by, bw, bh); ctx.strokeRect(bx, by, bw, bh); }
      ctx.restore();
    }
    function pill(x, y, w, h) { rr(ctx, x, y, w, h, h / 2); ctx.fillStyle = 'rgba(23,19,31,.86)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.35)'; ctx.lineWidth = 1; ctx.stroke(); }
    function button(b) {
      btns.push(b);
      const { x, y, w, h } = b;
      rr(ctx, x, y, w, h, 10);
      ctx.fillStyle = b.act ? 'rgba(227,174,69,.32)' : b.prim ? 'rgba(127,240,160,.22)' : 'rgba(34,28,46,.9)'; ctx.fill();
      ctx.strokeStyle = b.act ? '#e3ae45' : b.prim ? '#7ff0a0' : 'rgba(242,233,216,.2)'; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.globalAlpha = b.dis || b.red ? 0.42 : 1;
      const hasSub = !!b.sub, iy = y + h * (hasSub ? 0.3 : b.lab ? 0.38 : 0.5);
      if (b.ug != null) unitGlyph(ctx, b.ug, x + w / 2, iy, h * (hasSub ? 0.12 : 0.15), col(Math.max(0, me())), -Math.PI / 4, 0, 0);
      else if (b.bg != null) bldGlyph(ctx, b.bg, x + w / 2, iy, h * (hasSub ? 0.34 : 0.42), col(Math.max(0, me())), true, 1, 0, 0);
      else if (b.ic) { ctx.fillStyle = '#f2e9d8'; ctx.font = '700 ' + Math.round(h * (hasSub ? 0.26 : 0.32)) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(b.ic, x + w / 2, iy); }
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (b.lab) { ctx.fillStyle = '#f2e9d8'; ctx.font = '700 ' + (b.lab.length > 4 ? 9 : 10.5) + 'px ' + FONT; ctx.fillText(b.lab, x + w / 2, y + h * (hasSub ? 0.62 : 0.78), w - 4); }
      if (hasSub) { ctx.fillStyle = b.red ? '#ee6a55' : '#e3ae45'; ctx.font = '700 9px ' + MONO; ctx.fillText(b.sub, x + w / 2, y + h * 0.84, w - 4); }
      ctx.globalAlpha = 1;
      { const hk = b.kid ? L.ui.keyLabel('rts', b.kid) : ''; if (hk) { ctx.font = '700 8.5px ' + MONO; ctx.textAlign = 'left'; const tw = ctx.measureText(hk).width; rr(ctx, x + 2, y + 2, tw + 5, 11, 3); ctx.fillStyle = 'rgba(15,15,20,.7)'; ctx.fill(); ctx.fillStyle = 'rgba(242,233,216,.85)'; ctx.fillText(hk, x + 4.5, y + 8); } }
      if (b.badge) { ctx.fillStyle = '#ee6a55'; dot(ctx, x + w - 8, y + 8, 7); ctx.fillStyle = '#fff'; ctx.font = '700 9px ' + MONO; ctx.textAlign = 'center'; ctx.fillText(String(b.badge), x + w - 8, y + 8.5); }
    }
    function cleared() { try { const r = L.best && L.best.all('rts').op; return r ? r.v | 0 : 0; } catch (e) { return 0; } }
    let bSel = 0;
    function wrapT(text, mw) { const out = []; let line = ''; for (const wd of String(text).split(' ')) { const t = line ? line + ' ' + wd : wd; if (ctx.measureText(t).width > mw && line) { out.push(line); line = wd; } else line = t; } if (line) out.push(line); return out; }
    function drawBrief() { // mission select + briefing (작전)
      const w = cv.w, h = cv.h, cl = cleared(), can = host();
      if (!bSel) bSel = clamp(cl + 1, 1, OPN);
      ctx.fillStyle = 'rgba(10,8,14,.74)'; ctx.fillRect(0, 0, w, h);
      const pw = Math.min(w - 16, 760), ph = Math.min(h - 16, pw >= 520 ? 420 : 580), x0 = (w - pw) / 2, y0 = (h - ph) / 2;
      rr(ctx, x0, y0, pw, ph, 14); ctx.fillStyle = 'rgba(23,19,31,.96)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillStyle = '#e3ae45'; ctx.font = '400 18px ' + DISP; ctx.fillText('작전 고르기', x0 + 14, y0 + 20);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px ' + FONT; ctx.textAlign = 'right'; ctx.fillText('성공한 작전 ' + cl + '/' + OPN, x0 + pw - 14, y0 + 20); ctx.textAlign = 'left';
      const land = pw >= 520, bh = 44, gap = 5, rows = Math.ceil(OPN / 2);
      const lw = land ? Math.min(330, pw * 0.46) : pw - 28;
      const lx = x0 + 14, ly = y0 + 40;
      for (let k = 1; k <= OPN; k++) {
        const col2 = (k - 1) % 2, row = (k - 1) >> 1, bw = (lw - gap) / 2;
        const x = lx + col2 * (bw + gap), y = ly + row * (bh + gap), open = k <= cl + 1, on = k === bSel;
        rr(ctx, x, y, bw, bh, 10); ctx.fillStyle = on ? 'rgba(227,174,69,.28)' : 'rgba(34,28,46,.95)'; ctx.fill(); ctx.strokeStyle = on ? '#e3ae45' : 'rgba(242,233,216,.2)'; ctx.stroke();
        ctx.globalAlpha = open ? 1 : 0.45; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 12.5px ' + FONT; ctx.fillText(k + '. ' + OPS[k].nm, x + 8, y + 15, bw - 14);
        ctx.fillStyle = k <= cl ? '#7ff0a0' : '#ab9fb8'; ctx.font = '600 10px ' + FONT; ctx.fillText(k <= cl ? '✓ 성공' : open ? OPS[k].goal : '🔒 ' + (k - 1) + '번을 먼저 성공', x + 8, y + 31, bw - 14); ctx.globalAlpha = 1;
        btns.push({ x, y, w: bw, h: bh, on: () => { if (!open) { api.toast((k - 1) + '번 작전을 먼저 성공하세요'); return; } bSel = k; sfx('click'); } });
      }
      const listH = rows * (bh + gap);
      const tx = land ? lx + lw + 16 : lx, ty = land ? ly : ly + listH + 4, tw = land ? x0 + pw - 14 - tx : lw;
      const O = OPS[bSel];
      ctx.fillStyle = '#e3ae45'; ctx.font = '400 15px ' + DISP; ctx.fillText('작전 ' + bSel + ' · ' + O.nm, tx, ty + 10, tw);
      ctx.fillStyle = '#7ff0a0'; ctx.font = '700 11.5px ' + FONT; ctx.fillText('목표: ' + O.goal, tx, ty + 32, tw);
      ctx.fillStyle = '#f2e9d8'; ctx.font = '600 11.5px ' + FONT;
      let yy = ty + 52; const maxY = y0 + ph - 62;
      for (const para of O.brief) { for (const ln of wrapT(para, tw)) { if (yy > maxY) break; ctx.fillText(ln, tx, yy); yy += 16; } yy += 5; }
      const sw = Math.min(220, tw), sx = land ? tx + tw - sw : x0 + (pw - sw) / 2, sy = y0 + ph - 54;
      rr(ctx, sx, sy, sw, 44, 12); ctx.fillStyle = can ? 'rgba(127,240,160,.24)' : 'rgba(34,28,46,.9)'; ctx.fill(); ctx.strokeStyle = can ? '#7ff0a0' : 'rgba(242,233,216,.2)'; ctx.stroke();
      ctx.textAlign = 'center'; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px ' + FONT; ctx.fillText(can ? '▶ 작전 시작' : '방장이 작전을 고르는 중…', sx + sw / 2, sy + 22, sw - 12); ctx.textAlign = 'left';
      if (can) btns.push({ x: sx, y: sy, w: sw, h: 44, on: () => { if (bSel > cl + 1) return; sfx('chip'); api.setState(Object.assign({}, st, { op: bSel, ph: 'play' })); } });
    }
    /* ----- 진영 고르기 ----- */
    let myPick = null, pkAcc = 0, pkSel = -1, pbar = null, pkForce = false;
    function pickSet(s, f, ready) { // host: record a seat's pick
      if (!st || st.ph !== 'pick' || s < 0 || s >= st.n) return;
      f = f >= -1 && f < FAC.length ? f : -1;
      if (st.pk[s] === f && st.rd[s] === ready) return;
      const pk = st.pk.slice(), rd = st.rd.slice(); pk[s] = f; rd[s] = ready;
      api.setState(Object.assign({}, st, { pk, rd }));
    }
    function pickTick(rdt) {
      if (!st.pk) return;
      const df = L.debug && L.debug.rtsFa; // test hook: force factions
      if (Array.isArray(df)) { api.setState(Object.assign({}, st, { ph: 'play', fa: pickResolve(Object.assign({}, st, { pk: st.pk.map((_, i) => (df[i] != null ? df[i] : -1)) })), pc: 0 })); return; }
      const all = !L.pick.waiting(api.players, (i) => st.rd[i]).length;
      if (L.debug && L.debug.autoplay) pkAcc += rdt * 4;
      if (all || pkForce || pkAcc > 25) { pkForce = false; pkAcc = 0; api.setState(Object.assign({}, st, { ph: 'play', fa: pickResolve(st), pc: 0 })); return; }
    }
    function choosePick(f, ready) {
      const s = seat(); if (s < 0) return;
      pkSel = f; sfx(ready ? 'chip' : 'click');
      if (host()) pickSet(s, f, ready); else { myPick = [f, ready ? 1 : 0]; pubT = 0; }
    }
    function drawPick() {
      const w = cv.w, h = cv.h, s = seat(), land = w >= h * 1.05;
      ctx.fillStyle = 'rgba(10,8,14,.82)'; ctx.fillRect(0, 0, w, h);
      const tb = pbar && pbar.el.isConnected && pbar.el.style.display !== 'none' ? pbar.el.offsetHeight + 10 : 0;
      const pw = Math.min(w - 12, 800), ph = Math.min(h - 12 - tb, land ? 390 : 620), x0 = (w - pw) / 2, y0 = tb + (h - tb - ph) / 2;
      rr(ctx, x0, y0, pw, ph, 14); ctx.fillStyle = 'rgba(23,19,31,.97)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.4; ctx.stroke();
      ctx.textBaseline = 'middle'; ctx.textAlign = 'left'; ctx.fillStyle = '#e3ae45'; ctx.font = '400 18px ' + DISP; ctx.fillText('진영 고르기', x0 + 14, y0 + 20);
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 11px ' + FONT; ctx.textAlign = 'right'; ctx.fillText('모두 준비하면 시작', x0 + pw - 14, y0 + 20); ctx.textAlign = 'left';
      const cur = s >= 0 ? (st.pk[s] != null ? st.pk[s] : -1) : -1, ready = s >= 0 && st.rd[s];
      const shown = pkSel >= -1 && s >= 0 && !host() && myPick ? myPick[0] : cur;
      const opts = [-1, 0, 1, 2, 3], gap = 6, cy0 = y0 + 40, bh = 46;
      const bottom = y0 + ph - bh - 12 - 22;
      let cw, chh, perRow;
      if (land) { perRow = 5; cw = (pw - 28 - gap * 4) / 5; chh = bottom - cy0 - 6; } else { perRow = 1; cw = pw - 28; chh = Math.min(84, (bottom - cy0 - 6 - gap * 4) / 5); }
      opts.forEach((f, i) => {
        const x = x0 + 14 + (land ? i * (cw + gap) : 0), y = cy0 + (land ? 0 : i * (chh + gap)), on = shown === f;
        const F = FAC[f], acc = F ? F.c : '#e3ae45';
        rr(ctx, x, y, cw, chh, 10); ctx.fillStyle = on ? 'rgba(227,174,69,.2)' : 'rgba(34,28,46,.95)'; ctx.fill(); ctx.strokeStyle = on ? acc : 'rgba(242,233,216,.18)'; ctx.lineWidth = on ? 2 : 1; ctx.stroke();
        const myc = s >= 0 ? col(fac(s)) : '#888';
        if (land) {
          if (F) { for (let k2 = 0; k2 < 3; k2++) unitGlyph(ctx, [F.w, F.b && BD[F.b[2]].tr[0], BD[F.b[3]].tr[1]][k2], x + cw * (0.25 + k2 * 0.25), y + 38, 9, myc, -0.6, 0, frame * 0.2); }
          else { ctx.fillStyle = '#e3ae45'; ctx.font = '700 30px ' + FONT; ctx.textAlign = 'center'; ctx.fillText('?', x + cw / 2, y + 38); ctx.textAlign = 'left'; }
          ctx.textAlign = 'center'; ctx.fillStyle = acc; ctx.font = '400 15px ' + DISP; ctx.fillText(F ? F.nm : '무작위', x + cw / 2, y + 70, cw - 8);
          ctx.fillStyle = '#e3ae45'; ctx.font = '700 10px ' + FONT; ctx.fillText(F ? F.sig : '넷 중 하나', x + cw / 2, y + 88, cw - 8);
          ctx.fillStyle = '#d8cfc0'; ctx.font = '600 10.5px ' + FONT; ctx.textAlign = 'left';
          let yy = y + 108; for (const ln of wrapT(F ? F.d : '판이 시작될 때 네 진영 중 하나를 무작위로 받아요. 처음이라면 철강 연합이 가장 무난해요.', cw - 14)) { if (yy > y + chh - 8) break; ctx.fillText(ln, x + 7, yy); yy += 14; }
        } else {
          if (F) unitGlyph(ctx, BD[F.b[2]].tr[0], x + 26, y + chh / 2, 10, myc, -0.6, 0, 0);
          else { ctx.fillStyle = '#e3ae45'; ctx.font = '700 24px ' + FONT; ctx.textAlign = 'center'; ctx.fillText('?', x + 26, y + chh / 2); }
          ctx.textAlign = 'left'; ctx.fillStyle = acc; ctx.font = '400 14px ' + DISP; ctx.fillText(F ? F.nm : '무작위', x + 50, y + 16, cw - 60);
          ctx.fillStyle = '#e3ae45'; ctx.font = '700 10px ' + FONT; ctx.fillText(F ? F.sig : '넷 중 하나', x + 50, y + 33, cw - 60);
          ctx.fillStyle = '#d8cfc0'; ctx.font = '600 10px ' + FONT; const ln = wrapT(F ? F.d : '판이 시작될 때 네 진영 중 하나를 무작위로 받아요.', cw - 60); for (let q = 0; q < Math.min(2, ln.length); q++) if (y + 49 + q * 13 < y + chh - 4) ctx.fillText(ln[q], x + 50, y + 49 + q * 13);
        }
        if (s >= 0 && !ready) btns.push({ x, y, w: cw, h: chh, on: () => choosePick(f, 0) });
      });
      // seats status
      ctx.font = '600 10.5px ' + FONT; ctx.textAlign = 'left'; let sx = x0 + 14; const sy = y0 + ph - bh - 22;
      for (let i = 0; i < st.n; i++) {
        const p = P(i), mateOf = s >= 0 && map && map.tm[fac(i)] === myTeam(), f = st.pk[i];
        const lab = (st.nm[i] || (i + 1) + '번').slice(0, 6) + ' ' + (p.ai ? 'AI' : st.rd[i] ? '✓' : '…') + (mateOf && !p.ai ? ' ' + (f >= 0 ? FAC[f].sh : '무작위') : '');
        const tw = ctx.measureText(lab).width + 18; if (sx + tw > x0 + pw - 10) break;
        ctx.fillStyle = p.color || '#888'; dot(ctx, sx + 5, sy, 4); ctx.fillStyle = '#d8cfc0'; ctx.fillText(lab, sx + 12, sy); sx += tw;
      }
      if (s >= 0) {
        const bw = Math.min(260, pw - 28), bx = x0 + (pw - bw) / 2, by = y0 + ph - bh - 10;
        rr(ctx, bx, by, bw, bh, 12); ctx.fillStyle = ready ? 'rgba(34,28,46,.9)' : 'rgba(127,240,160,.24)'; ctx.fill(); ctx.strokeStyle = ready ? 'rgba(242,233,216,.25)' : '#7ff0a0'; ctx.stroke();
        ctx.textAlign = 'center'; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 14px ' + FONT; ctx.fillText(ready ? '준비 완료 — 다른 사람을 기다려요 (누르면 취소)' : '▶ ' + (shown >= 0 ? FAC[shown].nm : '무작위') + '(으)로 준비', bx + bw / 2, by + bh / 2, bw - 12);
        btns.push({ x: bx, y: by, w: bw, h: bh, on: () => choosePick(shown, ready ? 0 : 1) });
      }
      ctx.textAlign = 'left';
    }
    function drawUI() {
      btns = [];
      const w = cv.w, h = cv.h, lo = lay, s = me();
      ctx.textBaseline = 'middle';
      if (st.ph === 'brief') { drawBrief(); return; }
      if (st.ph === 'pick') { drawPick(); return; }
      // resources
      const p = pd();
      const left = st.T ? Math.max(0, st.T - R.t) : R.t, tt = Math.floor(left / 60) + ':' + String(Math.floor(left % 60)).padStart(2, '0');
      if (s >= 0) {
        const pw = Math.min(w - 12, 268); pill(6, 6, pw, 26);
        ctx.font = '700 12.5px ' + MONO; ctx.textAlign = 'left';
        ctx.fillStyle = ORE; ctx.fillText('◆' + p.ore, 16, 19.5);
        ctx.fillStyle = CRY; ctx.fillText('◇' + p.cry, 16 + 64, 19.5);
        ctx.fillStyle = p.used >= p.cap && p.cap < 100 ? '#ee6a55' : '#f2e9d8'; ctx.fillText('⚑' + p.used + '/' + p.cap, 16 + 124, 19.5);
        ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'right'; ctx.fillText(tt, 6 + pw - 10, 19.5);
      } else { pill(6, 6, 120, 26); ctx.font = '700 12.5px ' + MONO; ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.fillText('관전 ' + tt, 16, 19.5); }
      // players strip (alive)
      { const py = w < 560 && s >= 0 ? 36 : 6; let x = w - 10; ctx.textAlign = 'right'; ctx.font = '700 10.5px ' + FONT;
        for (let i = st.n - 1; i >= 0; i--) { const al = R.p[fac(i)] ? R.p[fac(i)].alive : true; const nm = (st.nm[i] || (i + 1) + '번').slice(0, 6); const tw = ctx.measureText(nm).width + 22; if (x - tw < (py > 6 ? 6 : s >= 0 ? 280 : 132)) break; pill(x - tw, py, tw, 22); ctx.fillStyle = P(i).color || '#888'; dot(ctx, x - tw + 10, py + 11, 4.5); ctx.fillStyle = al ? '#f2e9d8' : '#6e6578'; ctx.fillText(al ? nm : nm + '✕', x - 6, py + 11.5); x -= tw + 4; } }
      // minimap
      const m = lo.mini; const S = map.S;
      rr(ctx, m.x - 2, m.y - 2, m.s + 4, m.s + 4, 8); ctx.fillStyle = 'rgba(23,19,31,.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.45)'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.imageSmoothingEnabled = false; ctx.drawImage(mcv, m.x, m.y, m.s, m.s); ctx.imageSmoothingEnabled = true;
      if (curVis()) ctx.drawImage(fcv, m.x, m.y, m.s, m.s);
      const k = m.s / S, T = myTeam(), E = curEx();
      map.nodes.forEach((q, i) => { if ((R.na[i] || 0) <= 0 || (E && !E[q.c])) return; ctx.fillStyle = q.k ? CRY : ORE; ctx.fillRect(m.x + q.x * k - 0.8, m.y + q.y * k - 0.8, 1.6, 1.6); });
      for (const kk of bmem.values()) { if (R.b.has(kk.i)) continue; ctx.fillStyle = col(kk.o); ctx.globalAlpha = 0.6; ctx.fillRect(m.x + kk.tx * k, m.y + kk.ty * k, Math.max(2, kk.sz * k), Math.max(2, kk.sz * k)); ctx.globalAlpha = 1; }
      for (const r of R.b.values()) { if (T >= 0 && map.tm[r.o] !== T && !visAt(r.x, r.y)) continue; ctx.fillStyle = col(r.o); ctx.fillRect(m.x + r.tx * k, m.y + r.ty * k, Math.max(2.5, r.sz * k), Math.max(2.5, r.sz * k)); }
      for (const r of R.u.values()) { if (T >= 0 && map.tm[r.o] !== T && !visAt(r.x, r.y)) continue; ctx.fillStyle = col(r.o); ctx.fillRect(m.x + r.x * k - 1, m.y + r.y * k - 1, 2, 2); }
      for (const pg of pings) if (pg.tp) { ctx.strokeStyle = pg.c; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(m.x + pg.x * k, m.y + pg.y * k, 3 + ((4 - pg.t) % 1) * 9, 0, 6.28); ctx.stroke(); ctx.fillStyle = pg.c; dot(ctx, m.x + pg.x * k, m.y + pg.y * k, 2.5); }
      { const mv = mateView(); if (mv) { const c = P(mate()).color || '#fff', x0 = clamp(m.x + (mv.x - mv.hw) * k, m.x, m.x + m.s), y0 = clamp(m.y + (mv.y - mv.hh) * k, m.y, m.y + m.s), x1 = clamp(m.x + (mv.x + mv.hw) * k, m.x, m.x + m.s), y1 = clamp(m.y + (mv.y + mv.hh) * k, m.y, m.y + m.s);
        ctx.strokeStyle = c; ctx.lineWidth = 1.4; ctx.setLineDash([3, 2]); ctx.strokeRect(x0, y0, x1 - x0, y1 - y0); ctx.setLineDash([]); } }
      for (const pg of pings) if (pg.alert) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(m.x + pg.x * k, m.y + pg.y * k, 4 + (1 - pg.t / 3) * 10, 0, 6.28); ctx.stroke(); }
      { const rx0 = clamp(m.x + (cam.x - w / 2 / cam.z) * k, m.x, m.x + m.s), ry0 = clamp(m.y + (cam.y - h / 2 / cam.z) * k, m.y, m.y + m.s), rx1 = clamp(m.x + (cam.x + w / 2 / cam.z) * k, m.x, m.x + m.s), ry1 = clamp(m.y + (cam.y + h / 2 / cam.z) * k, m.y, m.y + m.s);
        ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 1; ctx.strokeRect(rx0, ry0, rx1 - rx0, ry1 - ry0); }
      if (s < 0 || st.ph !== 'play') return;
      // util buttons
      const U2 = lo.util, bs = lo.bs, ubs = U2.bs || bs, g = lo.gap;
      const idleN = myU().filter((r) => isW(r.t) && r.idle).length;
      const ub = [
        { lab: '1번', ic: String(groups[0].length || '·'), g: 0 }, { lab: '2번', ic: String(groups[1].length || '·'), g: 1 }, { lab: '3번', ic: String(groups[2].length || '·'), g: 2 }, { lab: '4번', ic: String(groups[3].length || '·'), g: 3 },
        { lab: '군대', ic: '⚔', on: selectArmy }, { lab: '유휴', ic: '⚒', on: selectIdle, badge: idleN }, { lab: '상자', ic: '▢', on: () => { boxArm = !boxArm; if (boxArm) api.toast('지도를 끌어 여러 유닛을 고르세요'); }, act: boxArm },
      ];
      ub.forEach((b, i) => {
        const c = U2.cols === 2 ? i % 2 : i, rI = U2.cols === 2 ? (i >> 1) : 0;
        const o = Object.assign({ x: U2.x + c * (ubs + g), y: U2.y + rI * (ubs + g), w: ubs, h: ubs }, b);
        if (b.g != null) { o.on = () => groupTap(b.g, false); o.lpOn = () => groupTap(b.g, true); o.act = false; o.kid = 'g' + (b.g + 1); }
        else if (b.on === selectArmy) o.kid = 'army'; else if (b.on === selectIdle) o.kid = 'idle';
        button(o);
      });
      // command card
      const items = cardItems(), C = lo.card;
      items.forEach((it, i) => {
        const x = C.x + (i % 3) * (bs + g), y = C.y + ((i / 3) | 0) * (bs + g);
        if (!it) { rr(ctx, x, y, bs, bs, 10); ctx.fillStyle = 'rgba(23,19,31,.45)'; ctx.fill(); return; }
        button(Object.assign({ x, y, w: bs, h: bs, kid: 'c' + i, dis: it.dis || it.red }, it));
      });
      // info panel
      drawInfo();
      // hint line
      let ht = '';
      if (mode === 'place') { const B = ghost ? BD[ghost.bt] : null; ht = B && siteOnly(ghost.bt) ? '본부는 기지 자리(점선 원)에만 — 원을 누르고 ✓' : B && B.fa === 1 && !B.hq ? '막(보랏빛 바닥) 위에만 자라요 — 누르고 ✓ (알집이 막을 넓혀요)' : B && B.fa === 2 && !B.hq && !B.pw ? '빛의 장(금빛 원) 안에만 소환돼요 — 누르고 ✓' : '지을 곳을 누르고 ✓ 짓기 (초록 = 가능)'; }
      else if (mode === 'amove') ht = '공격하며 갈 곳(또는 적)을 누르세요';
      else if (mode === 'rally') ht = '집결 지점을 누르세요 (광석을 누르면 일꾼이 바로 캐요)';
      else if (mode === 'pingK') ht = pingAt ? '보낼 신호를 고르세요 (우리 팀에게만 보여요)' : '신호를 고른 뒤 지도·미니맵을 누르세요';
      else if (mode === 'ping') ht = '신호를 보낼 곳을 누르세요 (지도 또는 미니맵)';
      else if (mode === 'drop') ht = '내려놓을 땅을 누르세요 — 수송기가 날아가서 내려요';
      else if (!sel.length && tipT <= 0 && R.t < 90) ht = '유닛 누르기 = 선택 · 땅 누르기 = 이동 · 길게 누르고 끌기 = 여러 유닛';
      let misY = 0;
      const ml = st.op ? (W && W.mis ? misLine(W) : R.m || '') : '';
      if (ml) {
        ctx.font = '700 11.5px ' + FONT; const tw = Math.min(w - 20, ctx.measureText(ml).width + 26); misY = w >= 720 ? 6 : 64; const mx = w >= 720 ? Math.max(280, (w - tw) / 2) : (w - tw) / 2;
        pill(mx, misY, Math.min(tw, w - mx - 6), 26); ctx.fillStyle = '#ffd27a'; ctx.textAlign = 'center'; ctx.fillText(ml, mx + Math.min(tw, w - mx - 6) / 2, misY + 13.5, Math.min(tw, w - mx - 6) - 12);
      }
      if (ht) { ctx.font = '600 11.5px ' + FONT; const tw = Math.min(w - 20, ctx.measureText(ht).width + 24); const y = misY ? misY + 32 : lo.w < 560 ? 64 : 40; pill((w - tw) / 2, y, tw, 24); ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.fillText(ht, w / 2, y + 12.5, tw - 12); }
      // start tips
      if (tipT > 0) {
        const a = Math.min(1, tipT), bw = Math.min(w - 24, 440), x = (w - bw) / 2, y = h * 0.3;
        ctx.globalAlpha = a * 0.94; rr(ctx, x, y, bw, 70, 14); ctx.fillStyle = 'rgba(23,19,31,.94)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.stroke();
        ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.fillStyle = '#e3ae45'; ctx.font = '400 16px ' + DISP; ctx.fillText(st.op ? '작전 ' + st.op + ' · ' + OPS[st.op].goal : st.n === 4 && st.team ? '적 팀의 건물을 모두 부수면 승리!' : '적 건물을 모두 부수면 승리!', w / 2, y + 20, bw - 16);
        ctx.fillStyle = '#f2e9d8'; ctx.font = '600 11.5px ' + FONT; ctx.fillText(st.op ? OPS[st.op].brief[1] : myF().nm + ' · 일꾼은 이미 캐는 중 · 일꾼을 골라 ⚒건설 → ' + BD[myF().b[1]].nm + '·' + BD[myF().b[2]].nm, w / 2, y + 42, bw - 16);
        ctx.fillStyle = '#ab9fb8'; ctx.fillText('끌기 = 화면 이동 · 두 손가락 = 확대 · 미니맵 누르기 = 이동', w / 2, y + 59, bw - 16);
        ctx.globalAlpha = 1;
      }
    }
    function drawInfo() {
      const I = lay.info; if (!I.w) return;
      const list = selList(); if (!list.length) return;
      rr(ctx, I.x, I.y, I.w, I.h, 10); ctx.fillStyle = 'rgba(23,19,31,.86)'; ctx.fill(); ctx.strokeStyle = 'rgba(242,233,216,.15)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.textBaseline = 'middle';
      if (selKind === 'u' || selKind === 'e') {
        if (list.length === 1) {
          const r = list[0], D = UN[r.t];
          unitGlyph(ctx, r.t, I.x + 20, I.y + I.h / 2, 9, col(r.o), -0.6, r.cr, 0);
          ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 12px ' + FONT; ctx.fillText(D.nm + (r.md ? ' ★개조' : '') + (r.o !== me() ? ' (적)' : ''), I.x + 38, I.y + I.h * 0.32, I.w - 44);
          ctx.fillStyle = '#ab9fb8'; ctx.font = '600 10px ' + MONO;
          ctx.fillText((D.sh ? '체력+막 ' : '체력 ') + Math.ceil(r.hp * (D.hp + D.sh) * (r.md ? MOD.hp : 1)) + '/' + Math.round((D.hp + D.sh) * (r.md ? MOD.hp : 1)) + (r.t === TP ? ' · 탑승 ' + (r.cr || 0) + '/' + CAP + '칸' : ' · 공격 ' + D.dm + ' · 사거리 ' + D.rg), I.x + 38, I.y + I.h * 0.7, I.w - 44);
          return;
        }
        const cell = 30, n = Math.max(1, Math.floor((I.w - 8) / cell)), shown = list.slice(0, n - (list.length > n ? 1 : 0));
        shown.forEach((r, i) => {
          const x = I.x + 4 + i * cell + cell / 2, y = I.y + I.h / 2 - 3;
          unitGlyph(ctx, r.t, x, y, 7.5, col(r.o), -0.6, 0, 0);
          ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.fillRect(x - 11, y + 12, 22, 3); ctx.fillStyle = r.hp > 0.5 ? '#7ff0a0' : r.hp > 0.25 ? '#f2c14e' : '#ee6a55'; ctx.fillRect(x - 11, y + 12, 22 * r.hp, 3);
          btns.push({ x: x - cell / 2, y: I.y, w: cell, h: I.h, on: () => setSel([r.i], 'u') });
        });
        if (list.length > shown.length) { ctx.fillStyle = '#f2e9d8'; ctx.font = '700 11px ' + MONO; ctx.textAlign = 'center'; ctx.fillText('+' + (list.length - shown.length), I.x + 4 + shown.length * cell + cell / 2, I.y + I.h / 2); }
        return;
      }
      const r = list[0], B = BD[r.t];
      bldGlyph(ctx, r.t, I.x + 20, I.y + I.h / 2, 26, col(r.o), true, 1, 0, 0);
      ctx.textAlign = 'left'; ctx.fillStyle = '#f2e9d8'; ctx.font = '700 12px ' + FONT;
      ctx.fillText(B.nm + (r.o !== me() ? ' (적)' : !r.done ? ' · 짓는 중 ' + Math.floor(r.pr * 100) + '%' : ''), I.x + 38, I.y + I.h * 0.32, Math.min(130, I.w - 44));
      ctx.fillStyle = '#ab9fb8'; ctx.font = '600 10px ' + MONO; ctx.fillText((B.sh ? '체력+막 ' : '체력 ') + Math.ceil(r.hp * (B.hp + B.sh)) + '/' + (B.hp + B.sh), I.x + 38, I.y + I.h * 0.7);
      if (r.o === me() && r.q && r.q.length) {
        const x0 = I.x + 38 + Math.min(130, I.w - 44) + 6, cell = 32;
        r.q.forEach((c, i) => {
          const x = x0 + i * cell; if (x + cell > I.x + I.w) return;
          rr(ctx, x, I.y + 4, cell - 4, I.h - 8, 6); ctx.fillStyle = 'rgba(46,38,64,.95)'; ctx.fill();
          if (c < 100) unitGlyph(ctx, c, x + (cell - 4) / 2, I.y + I.h / 2 - 2, 7, col(me()), -0.6, 0, 0);
          else { ctx.fillStyle = '#f2e9d8'; ctx.font = '600 14px ' + FONT; ctx.textAlign = 'center'; ctx.fillText(upgOf(BD[r.t].fa, c - 100).ic, x + (cell - 4) / 2, I.y + I.h / 2 - 2); ctx.textAlign = 'left'; }
          if (i === 0) { ctx.fillStyle = '#9fe8ff'; ctx.fillRect(x + 2, I.y + I.h - 9, (cell - 8) * r.qp, 3); }
          btns.push({ x, y: I.y, w: cell - 2, h: I.h, on: () => { send(['x', r.i, i]); sfx('click'); } });
        });
      }
    }
    function alerts() {
      const s = me(); if (s < 0) return;
      let hit = null;
      for (const r of R.u.values()) if (r.o === s) { const p = hpPrev.get(r.i); if (p != null && r.hp < p - 0.01) hit = r; hpPrev.set(r.i, r.hp); }
      for (const r of R.b.values()) if (r.o === s) { const p = hpPrev.get(-r.i); if (p != null && r.hp < p - 0.005 && r.done) hit = r; hpPrev.set(-r.i, r.hp); }
      if (frame % 120 === 0) for (const k of [...hpPrev.keys()]) if (!(k > 0 ? R.u.has(k) : R.b.has(-k))) hpPrev.delete(k);
      if (hit && R.t - lastAlert > 12) {
        const on = Math.abs(hit.x - cam.x) * cam.z < cv.w / 2 && Math.abs(hit.y - cam.y) * cam.z < cv.h / 2;
        lastAlert = R.t;
        if (!on) { api.toast(hit.t != null && R.b.has(hit.i) ? '기지가 공격받고 있어요!' : '유닛이 공격받고 있어요!'); api.buzz([30, 40, 30]); pings.push({ x: hit.x, y: hit.y, t: 3, c: '#ee6a55', alert: 1 }); }
      }
    }

    /* ----- main loop ----- */
    const stop = U.loop((rdt) => {
      if (!st || !map) return;
      frame++;
      const dt = rdt * SPD();
      if (!lay || lay.w !== cv.w || lay.h !== cv.h) layout();
      if (tipT > 0) tipT -= rdt;
      if (st.ph === 'pick') { if (!pbar) pbar = api.pickBar({ style: { top: '6px', bottom: 'auto' }, picked: (i) => !!(st && st.rd && st.rd[i]), onForce: () => { pkForce = true; } }); }
      else if (pbar) { pbar.destroy(); pbar = null; }
      if (host() && st.ph === 'pick') pickTick(rdt);
      if (host() && W) {
        if (api.online) pollHost();
        if (st.ph === 'play' && !W.over) {
          acc += dt; let k = 0;
          while (acc >= STEP && k < 16) {
            for (let f = 0; f < W.n; f++) {
              if (!W.pl[f].alive) continue;
              const seats = st.sh ? [f * 2, f * 2 + 1] : [f], ais = seats.filter((s) => { const p = api.players[s]; return !p || p.ai; });
              if (!ais.length) continue;
              // 공동 진영: AI + human → AI runs economy/production; it also takes the army while the human has been idle 30 s
              const hum = seats.filter((s) => ais.indexOf(s) < 0), macro = hum.length > 0 && hum.some((s) => W.t - (lastAct[s] || 0) < 30);
              const lv = Math.max.apply(null, ais.map((s) => (api.players[s] && api.players[s].lv) || 2)), mm = aiM[f] || (aiM[f] = aiMem(W, f, lv));
              if (W.t >= mm.nt) { mm.nt = W.t + AI_DT[lv] * (0.8 + Math.random() * 0.4); aiThink(W, f, lv, mm, macro); }
            }
            step(W, STEP); acc -= STEP; k++;
          }
          if (k >= 16) acc = 0;
          if (W.over && !sentEnd) {
            sentEnd = true; endT = 2.6;
            const scF = W.pl.map((p) => [p.k, p.lost, p.mk, p.mined]);
            const sc = st.sh ? Array.from({ length: st.n }, (_, i) => scF[fac(i)]) : scF;
            const win = st.sh ? Array.from({ length: st.n }, (_, i) => i).filter((i) => W.over.win.indexOf(fac(i)) >= 0) : W.over.win;
            if (W.mis && W.mis.ok && me() === W.mis.cm && !P(me()).ai) { try { api.best && api.best('op', st.op, { label: '최고 작전 단계', unit: '단계' }); } catch (e) {} }
            api.setState(Object.assign({}, st, { ph: 'end', win, why: W.over.why, sc, tt: Math.round(W.t) }, W.mis ? { mwhy: W.mis.why } : {}));
          }
        } else if (st.ph === 'end') { endT -= rdt; if (endT <= 0) { endT = 1e9; api.setState(Object.assign({}, st, { ph: 'done' })); } }
        syncFromW();
      } else if (!host()) pollGuest(rdt);
      publish(rdt);
      fogT -= rdt; if (fogT <= 0) { fogT = 0.2; updFog(); }
      // camera keys / auto
      if (api.input) { const ax = api.input.axis('cl', 'cr'), ay = api.input.axis('cu', 'cd'); if (ax || ay) { cam.x += ax * rdt * 700 / cam.z; cam.y += ay * rdt * 700 / cam.z; } }
      if (me() < 0 && autoCam) { cam.x += (autoCam.x - cam.x) * Math.min(1, rdt * 2); cam.y += (autoCam.y - cam.y) * Math.min(1, rdt * 2); autoCam.t -= rdt; if (autoCam.t <= 0) autoCam = null; }
      cam.x = clamp(cam.x, 0, map.S); cam.y = clamp(cam.y, 0, map.S);
      // long press: group assign, touch box start
      const now = performance.now();
      for (const q of ptrs.values()) {
        if (q.k === 'btn' && !q.lp && q.b.lpOn && now - q.t0 > 450) { q.lp = true; q.b.lpOn(); }
        if (q.k === 'mm' && !q.lp && !q.mv && now - q.t0 > 500 && me() >= 0 && teamPlay() && st.ph === 'play') { // 미니맵 길게 누르기 = 팀 신호
          q.lp = true; const m = lay.mini; pingAt = { x: (q.sx - m.x) / m.s * map.S, y: (q.sy - m.y) / m.s * map.S }; mode = 'pingK'; ghost = null; api.buzz(12); sfx('click');
        }
        if (q.k === 'map' && q.touch && !q.moved && !q.box && !q.cancel && !pinch && now - q.t0 > 300 && me() >= 0 && mode !== 'place') { q.box = true; api.buzz(12); }
      }
      // keep selection valid
      if (sel.length && frame % 10 === 0) { const ok = sel.filter((id) => (selKind === 'b' || selKind === 'eb' ? R.b.has(id) : R.u.has(id))); if (ok.length !== sel.length) { sel = ok; if (!sel.length) { selKind = null; card = 'main'; if (mode !== 'place') mode = null; } } }
      if (mode === 'place' && ghost && frame % 10 === 0) validGhost();
      if (mode === 'place' && !hasWorkerSel()) { mode = null; ghost = null; }
      alerts();
      drawWorld(rdt);
      drawUI();
    });

    if (L.debug) L.debug.rtsDbg = () => ({ W, R, st, cam, sel, selKind, mode, ghost, send, setSel, startPlace, confirmPlace, cardItems, choosePick, setGhost: (tx, ty) => { ghost.tx = tx; ghost.ty = ty; validGhost(); return ghost.ok; } });
    function setup() {
      map = genMap(wst(st)); R.u.clear(); R.b.clear(); R.na = map.nodes.map(() => 1); R.p = []; R.t = 0;
      fx = []; pings = []; bmem.clear(); hpPrev.clear(); lastEvQ = -1; lastQ = -1; acc = 0; sentEnd = false; sel = []; selKind = null; mode = null; ghost = null; groups = [[], [], [], []]; cq = [];
      W = host() ? newWorld(st) : null; aiM.length = 0;
      buildTerrain();
      const s = me(), sp = s >= 0 ? map.spawn[s] : { x: map.S / 2, y: map.S / 2 };
      cam.x = sp.x; cam.y = sp.y; cam.z = clamp(Math.min(cv.w, cv.h) / 17, 15, 30);
      if (s < 0) cam.z = clamp(Math.min(cv.w, cv.h) / map.S * 1.6, 8, 20);
      tipT = s >= 0 ? 9 : 0; lay = null; layout();
      if (W) syncFromW();
      updFog();
    }
    return {
      update(next) {
        if (!next) return;
        const prev = st; st = next;
        const k = st.rid + '.' + st.sd + '.' + (st.op || 0) + '.' + (Array.isArray(st.fa) ? st.fa.join('') : '-');
        if (k !== key) { key = k; setup(); }
        if (st.ph !== 'play' && prev && prev.ph === 'play') { const win = (st.win || []).indexOf(seat()) >= 0; if (me() >= 0) { api.sfx(win ? 'win' : 'lose'); api.buzz(win ? 60 : [40, 30, 40]); } }
      },
      destroy() {
        if (pbar) pbar.destroy();
        stop(); if (offIn) offIn();
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove); cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('wheel', onWheel); cv.cv.removeEventListener('contextmenu', noCtx);
        window.removeEventListener('keydown', onKey); window.removeEventListener('keyup', onKey);
        cv.destroy();
      },
      _dbg: () => ({ W, R, st, cam, startOp: (k) => api.setState(Object.assign({}, st, { op: k, ph: 'play' })), sel, selKind, mode, ghost, lay, send, setSel, startPlace, confirmPlace, cardItems, tapWorld, SX, SY, setGhost: (tx, ty) => { ghost.tx = tx; ghost.ty = ty; validGhost(); return ghost.ok; } }),
    };
  }

  /* ---------------- 도감 ---------------- */
  const cst = (c) => '광석 ' + c[0] + (c[1] ? ' · 수정 ' + c[1] : '');
  const bon = (bo) => { const k = Object.keys(bo).filter((x) => bo[x] !== 1); return k.length ? '\n상성: ' + k.map((x) => TAGNM[x] + ' ×' + bo[x]).join(', ') : ''; };
  const UIC = { wk: '⛏️', rf: '🔫', fl: '🔥', sn: '🎯', ac: '🚙', at: '💣', dr: '🛸', tp: '🚁', sw: '🐜', fg: '🦷', sp: '🌵', ab: '🫧', cr: '🦏', sf: '🎈', bw: '🪱', ac2: '🔹', kn: '🛡️', ar2: '🏹', ph: '💨', jd: '🔱', sk: '🛰️', cl: '🗼', sv: '🧰', sg: '🔧', bk: '🏍️', hp: '🪝', gl: '🤖', mt: '🚚', zp: '🎐', mb: '⛺', h0: '🎖️', h1: '👑', h2: '⚜️', h3: '🔥' };
  const BIC = [['🏛️', '📦', '🏕️', '🏭', '🔬', '🗼'], ['🪺', '🥚', '🫧', '🐛', '🌀', '🌵'], ['✴️', '💎', '⛩️', '⚒️', '📜', '🔆'], ['⛺', '🔥', '🏕️', '🏗️', '🔧', '🗼']];
  const QUIRK = [
    ['균형형. 모든 건물은 일꾼이 곁에서 끝까지 지어요.', '포탑이 가장 튼튼하고, 수송기로 보병 4명·차량 1대를 태워 절벽 너머로 날라요.'],
    ['둥지·알집이 막(보랏빛 바닥)을 깔고, 다른 건물은 막 위에만 자라요. 알집을 이어 지어 막을 넓혀요.', '모든 유닛·건물이 3초 동안 안 맞으면 조금씩 스스로 나아요. 막 위에서는 30% 빨리 움직여요.', '적 유닛을 쓰러뜨리면 그 유닛 광석 값의 ' + ABT + '를 생체 흡수로 얻어요.'],
    ['건물은 빛기둥·성좌의 빛의 장 안에만 소환돼요. 사도는 소환을 시작만 하고 바로 일하러 돌아가고, 건물은 혼자 완성돼요.', '모든 유닛·건물에 보호막이 있어요. 6초 동안 안 맞으면 다시 차올라요(받는 피해는 보호막부터).', '새 유닛은 집결지에서 가장 가까운 빛기둥으로 순간이동해 나와요(관문 소환). 수정을 한 번에 1 더 캐요.'],
    ['이동 본부는 기지 자리가 아니어도 빈 땅 어디든 짓고, ⛺접기 → 굴러가서 ⛺펼치기로 옮겨요.', '부서진 기계 유닛(어느 편이든, 생체인 군체는 빼고)은 잔해를 남겨요. 고철 용광로 주변 8칸이나 내 전투 유닛 곁의 잔해는 광석(값의 ' + WRT + ')으로 녹아요.', '정비소 근처(7칸)에서 유닛을 골라 🔧개조: ' + MODT + '. 한 유닛에 한 번.'],
  ];
  const unitRow = (t) => { const D = UN[t]; return { icon: UIC[D.k] || '•', name: D.nm, tag: D.mb ? '접은 본부' : BD[D.from].nm + (D.req >= 0 ? ' + ' + BD[D.req].nm : ''),
    desc: D.d + '\n' + (D.mb ? '' : cst(D.c) + ' · 보급 ' + D.sup + ' · 훈련 ' + D.bt + '초\n') + '체력 ' + D.hp + (D.sh ? ' + 보호막 ' + D.sh : '') + ' · 방어 ' + D.ar + (D.dm ? ' · 공격 ' + D.dm + '/' + D.cd + '초 · 사거리 ' + D.rg + (D.mr ? '(최소 ' + D.mr + ')' : '') + (D.spl ? ' · 범위 ' + D.spl : '') : '') + ' · 속도 ' + D.sp + ' · 시야 ' + D.si + (D.air ? ' · 공중' : '') + '\n' + (D.cap ? '무기 없음 · 보병 ' + D.cap + '명 또는 차량 1대 탑승' : D.mb ? '무기 없음' : D.aa && D.ag ? '땅·하늘 공격' : D.ag ? '땅만 공격' : '하늘만 공격') + (D.boom ? ' · 한 번 터지면 사라짐' : '') + bon(D.bo) }; };
  const bldRow = (t, f) => { const B = BD[t]; return { icon: BIC[f][B.ro], name: B.nm, tag: B.sz + '×' + B.sz + (B.req >= 0 ? ' · ' + BD[B.req].nm + ' 필요' : ''),
    desc: B.d + '\n' + cst(B.c) + ' · ' + (f === 2 ? '소환 ' : '건설 ') + B.bt + '초 · 체력 ' + B.hp + (B.sh ? ' + 보호막 ' + B.sh : '') + (B.sup ? ' · 보급 +' + B.sup : '') + (B.crp ? ' · 막 ' + B.crp + '칸' : '') + (B.pw ? ' · 빛의 장 ' + B.pw + '칸' : '') + (B.wpn ? '\n공격 ' + B.wpn.dm + '/' + B.wpn.cd + '초 · 사거리 ' + B.wpn.rg + bon(B.wpn.bo) : '') }; };
  const codex = FAC.map((F, f) => ({ h: F.nm, p: [F.d].concat(QUIRK[f]),
    rows: UN.map((D, t) => t).filter((t) => UN[t].fa === f).map(unitRow)
      .concat(F.b.map((t) => bldRow(t, f)))
      .concat(UPGF[f].map((G) => ({ icon: G.ic, name: G.nm, tag: '연구 2단계', desc: G.d + '\n1단계 ' + cst(G.c[0]) + ' · ' + G.tm[0] + '초 · 2단계 ' + cst(G.c[1]) + ' · ' + G.tm[1] + '초' }))) })).concat([
    { h: '자원·지형', p: [], rows: [
      { icon: '🟠', name: '광석', tag: '주 자원', desc: '한 덩이 ' + NODE_A[0] + '. 일꾼이 ' + MINE[0].t + '초 캐서 ' + MINE[0].c + '씩 본부로 날라요. 한 덩이에 두 명까지 동시에.' },
      { icon: '🔷', name: '수정', tag: '고급 자원', desc: '한 덩이 ' + NODE_A[1] + '. ' + MINE[1].t + '초 캐서 ' + MINE[1].c + '씩(성광 교단은 ' + (MINE[1].c + 1) + '). 기지마다 두 덩이 — 고급 유닛·연구에 필요해요.' },
      { icon: '⛰️', name: '언덕(높은 땅)', tag: '지형', desc: '아래(낮은 땅)에서는 언덕 위가 안 보여요. 경사로로만 오르내려요. 하늘 유닛은 어디든 보고 날아요.' },
      { icon: '🪨', name: '바위·능선', tag: '지형', desc: '못 지나가요. 사이의 좁은 길(길목)은 적은 수로 지키기 좋아요.' },
      { icon: '🏹', name: '고지의 이점', tag: '지형', desc: '언덕 위 유닛·방어탑은 사거리 +' + HIGH_RG + '. 낮은 땅에서 언덕 위를 쏘면 ' + Math.round(UPHILL_MISS * 100) + '% 빗나가요(범위 공격·하늘 유닛 제외). 경사로 위에서는 빗나가지 않아요.' },
      { icon: '🌿', name: '수풀', tag: '지형', desc: '안에 든 땅 유닛은 곁(2칸)에 온 적에게만 보여요. 쏘거나 맞으면 ' + BUSH_RV + '초 동안 드러나요. 매복에 좋아요. 건물은 못 지어요.' },
      { icon: '🌊', name: '강·다리', tag: '지형', desc: '강은 땅 유닛이 못 건너고(하늘 유닛·사격은 넘어가요) 좁은 다리로만 건너요 — 다리는 좋은 길목. 다리 위엔 건물을 못 지어요.' },
      { icon: '⭕', name: '기지 자리', tag: '확장', desc: '점선 원. 본부는 여기에만 지을 수 있고(고철 유목민은 빈 땅 어디든), 옆에 광석·수정이 있어요.' },
    ] },
    { h: '작전', p: ['방식 「작전」에서 차례로 열리는 혼자용 임무예요. 작전은 철강 연합으로 해요.'], rows: OPS.slice(1).map((O, i) => ({ icon: ['🛡️', '🚁', '💰', '🏴', '🚚', '🚩', '🎖️', '⛏️'][i], name: (i + 1) + '. ' + O.nm, tag: O.goal, desc: O.brief.join(' ') })) },
    { h: '4인 방식', p: ['4명일 때 고르는 방식이에요.'], rows: [
      { icon: '🤝', name: '2:2 공동 진영', tag: '기본', desc: '둘이 진영 하나(본부·자원·보급·유닛·대기열)를 같이 맡아요. 진영은 둘 중 먼저 고른 사람의 것으로. 누구든 모든 유닛에 명령(나중 명령 우선), 팀원 선택·화면이 보이고, 부대 지정은 각자. AI 팀원은 살림(일꾼·건물·생산·연구)을 맡고, 사람이 30초 쉬면 군대도 움직여요.' },
      { icon: '🏳️', name: '2:2 각자 진영', tag: '팀전', desc: '기지·자원·진영은 따로, 이기고 지는 건 팀으로.' },
      { icon: '⚔️', name: '개인전', tag: '넷이 따로', desc: '마지막까지 남은 한 명이 승리.' },
      { icon: '📍', name: '팀 신호', tag: '2:2', desc: '「신호」 칸 또는 미니맵 길게 누르기 → 여기 공격 · 도와줘 · 조심. 소리와 함께 우리 팀에게만 보여요.' },
    ] },
    { h: '상성', p: ['가위바위보처럼 서로 강하고 약해요. 경보병·일꾼 / 장갑 / 공중 / 건물 네 갈래로 나뉘어요.',
      '경보병 사냥: 화염병·경장갑차 · 송곳니·산성 덩이 · 환영 추적자·성흔 거상·수호 기사 · 불꽃 바이크',
      '장갑 사냥: 포격 전차·정찰 드론 · 포자 비행체 · 심판자·천공 수호선 · 작살 포수·연 비행선',
      '하늘 막기: 소총병·저격수·포탑 · 가시뿜이·가시 촉수 · 빛살 궁수·감시탑 · 고철 사수·작살 포수·망루 (땅만 쏘는 유닛은 하늘을 못 막아요)',
      '건물 부수기: 포격 전차 · 굴착 포격충·갑각 돌격수·산성 덩이 · 심판자 · 고철 거신·박격 트럭',
      '진영끼리: 군체는 싸고 빠른 떼로 일찍 몰아치고, 성광은 비싸지만 오래 버티며, 고철은 싸움이 길어질수록 잔해로 살림이 늘고, 철강은 포탑·수송기로 버티고 찔러요.'] },
  ]);

  L.register({
    id: 'rts', name: '미니 RTS', tag: '실시간 전략', cat: '아케이드', landscape: true,
    blurb: '서로 다른 네 진영(철강 연합·군체 무리·성광 교단·고철 유목민) 중 하나를 골라 자원을 캐고 기지를 지어 군대를 키우세요. 상성을 맞춰 싸우고 확장해서, 적 건물을 모두 부수면 승리. 1:1 · 2:2(둘이 한 진영 / 각자 진영) · 개인전 · 혼자 하는 작전 8개.',
    tint: '#2f4a3a',
    icon: '<path d="M6 44l10-14 8 6 10-16 16 24z" fill="currentColor" opacity=".35"/><rect x="8" y="34" width="14" height="12" rx="2" fill="currentColor"/><path d="M11 34v-5h8v5" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="34" cy="40" r="4" fill="currentColor"/><circle cx="44" cy="36" r="4" fill="currentColor"/><path d="M36 38l8-12M46 34l4-10" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><path d="M28 10l4 6 4-6" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"/><path d="M6 50h44" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 4, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    maxPlayersIf: (o) => (o && o.mode === 1 ? 2 : 0),
    options: [
      { id: 'mode', label: '방식', tip: '놀이 방식.', choices: [{ v: 0, label: '대전', tip: '상대 본진을 부수면 승리.' }, { v: 1, label: '작전(혼자)', tip: '혼자 목표가 있는 작전 진행.' }], def: 0 },
      { id: 'team', label: '4인 방식', tip: '4명일 때 편 짜기.', choices: [{ v: 2, label: '2:2 공동 진영', tip: '두 명이 한 본진·자원을 같이 써요.' }, { v: 1, label: '2:2 각자 진영', tip: '두 명이 같은 편, 본진은 따로.' }, { v: 0, label: '개인전', tip: '모두가 적.' }], def: 2 },
      { id: 'map', label: '지형', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '황야' }, { v: 1, label: '설원' }, { v: 2, label: '초원' }, { v: 3, label: '화산' }], def: -1 },
      { id: 'time', label: '제한 시간', tip: '시간이 끝나면 점수가 높은 쪽이 승리.', choices: [{ v: 0, label: '없음' }, { v: 20, label: '20분' }, { v: 30, label: '30분' }], def: 0 },
    ],
    controls: [
      { id: 'cu', label: '화면 위로', keys: ['ArrowUp'], pad: ['up', 'ly-'] },
      { id: 'cd', label: '화면 아래로', keys: ['ArrowDown'], pad: ['down', 'ly+'] },
      { id: 'cl', label: '화면 왼쪽', keys: ['ArrowLeft'], pad: ['left', 'lx-'] },
      { id: 'cr', label: '화면 오른쪽', keys: ['ArrowRight'], pad: ['right', 'lx+'] },
      ...['Q', 'W', 'E', 'A', 'S', 'D', 'Z', 'X', 'C'].map((k, i) => ({ id: 'c' + i, label: '명령 칸 ' + k + ' (' + ['위 왼쪽', '위 가운데', '위 오른쪽', '가운데 왼쪽', '가운데', '가운데 오른쪽', '아래 왼쪽', '아래 가운데', '아래 오른쪽'][i] + ')', keys: ['Key' + k], pad: [] })),
      { id: 'g1', label: '1번 부대 (Ctrl+누르면 지정)', keys: ['Digit1'], pad: [] },
      { id: 'g2', label: '2번 부대 (Ctrl+누르면 지정)', keys: ['Digit2'], pad: [] },
      { id: 'g3', label: '3번 부대 (Ctrl+누르면 지정)', keys: ['Digit3'], pad: [] },
      { id: 'g4', label: '4번 부대 (Ctrl+누르면 지정)', keys: ['Digit4'], pad: [] },
      { id: 'army', label: '모든 군대 고르기', keys: ['KeyF'], pad: ['rb'] },
      { id: 'idle', label: '쉬는 일꾼 고르기', keys: ['KeyG'], pad: ['lb'] },
      { id: 'hero', label: '영웅 고르기', keys: ['KeyH'], pad: ['y'] },
      { id: 'base', label: '본부로 화면 이동', keys: ['Space'], pad: ['back'] },
      { id: 'cancel', label: '모드 취소', keys: ['Backspace'], pad: ['b'] },
      { id: 'zin', label: '확대', keys: ['PageUp', 'Equal'], pad: ['rt'] },
      { id: 'zout', label: '축소', keys: ['PageDown', 'Minus'], pad: ['lt'] },
    ],
    quick: [
      '목표: 적의 건물을 모두 부수면 승리! (2:2는 적 팀 둘 다)',
      '시작 전에 진영을 골라요(기본 무작위): 철강 연합(균형·수송기) · 군체 무리(싸고 많음·재생·막) · 성광 교단(강하고 비쌈·보호막·순간이동) · 고철 유목민(이동 본부·잔해 회수·개조).',
      '진영마다 영웅 1명: 병영을 지은 뒤 본부에서 불러요. 곁의 아군을 돕는 오라 + 버튼으로 쓰는 기술. 쓰러지면 ' + HERO_RE + '초 뒤 다시.',
      '4명 기본 「2:2 공동 진영」: 둘이 한 기지·자원·군대를 같이 움직여요. 📍신호(미니맵 길게 누르기)로 「여기 공격·도와줘·조심」.',
      '일꾼이 광석·수정을 캐 와요. 그 자원으로 보급 건물·병영·공장을 짓고 군대를 뽑아요. 유닛을 고르고 땅 = 이동, 적 = 공격.',
      '방식 「작전」: 혼자 하는 짧은 임무 8개(방어·수송기 침투·제한 자원·확장 지키기·수송대 호위·거점 점령·지휘관 사냥·맨손 생존).',
    ],
    rules: [
      { h: '목표', p: [
        '각자 본부 1개와 일꾼 5명으로 시작해요. 상대의 건물을 하나도 남김없이 부수면 그 사람은 탈락.',
        '1:1·개인전은 마지막까지 남은 사람이, 2:2는 남은 팀이 이겨요. (제한 시간을 정했다면 그때 건물·군대 가치가 큰 쪽이 승리)',
      ] },
      { h: '진영', p: [
        '판이 시작되기 전 「진영 고르기」 화면에서 고르고 ▶준비를 눌러요. 모두 준비하면 시작하고, 방장은 「지금 시작」으로 바로 시작할 수 있어요(안 고른 사람은 무작위). AI는 무작위 진영이에요.',
        '네 진영은 건물 6종(본부·보급·병영·공장·연구·방어탑 역할)과 유닛 7종이 저마다 달라요. 자세한 수치는 「📖 도감」의 진영 탭.',
        '철강 연합: 균형 잡힌 보병·차량. 일꾼이 곁에서 끝까지 지어요. 튼튼한 포탑, 수송기로 보병·차량을 절벽 너머로.',
        '군체 무리: 싸고 많은 생체. 모든 유닛·건물이 3초 동안 안 맞으면 스스로 나아요. 건물은 막(보랏빛 바닥) 위에만 — 둥지·알집이 막을 깔아요(알집을 이어 지어 넓혀요). 막 위에서 30% 빠르고, 적을 쓰러뜨리면 생체 흡수로 광석(그 유닛 광석 값의 ' + ABT + ')을 얻어요. 산성 덩이는 한 번 터지면 사라져요.',
        '성광 교단: 비싸고 강한 유닛. 모두 보호막이 있어 6초 동안 안 맞으면 다시 차올라요. 건물은 빛기둥·성좌의 빛의 장(금빛 원) 안에만 소환되고, 사도는 시작만 하면 돼요. 새 유닛은 집결지에서 가장 가까운 빛기둥으로 순간이동해 나와요 → 앞쪽에 빛기둥을 세우고 집결지를 찍으면 바로 전선으로. 수정을 한 번에 1 더 캐요.',
        '고철 유목민: 이동 본부는 기지 자리가 아니어도 빈 땅 어디든 지어요. 본부를 골라 ⛺접기 → 굴러가서 ⛺펼치기. 부서진 기계 유닛(어느 편이든, 군체 생체는 빼고)의 잔해는 고철 용광로 8칸 안이나 내 전투 유닛 곁에서 광석(값의 ' + WRT + ')으로 녹아요. 정비소 7칸 안의 유닛을 골라 🔧개조(' + MODT + ').',
      ] },
      { h: '영웅', p: [
        '진영마다 영웅이 한 명 있어요. 병영 역할 건물을 지은 뒤 본부를 골라 영웅 칸을 누르면 불러요(광석 ' + UN[HERO0].c[0] + ' · 수정 ' + UN[HERO0].c[1] + ' · 보급 ' + UN[HERO0].sup + ' · ' + UN[HERO0].bt + '초). 한 번에 한 명만, 쓰러지면 ' + HERO_RE + '초 뒤에 다시 부를 수 있어요.',
        '영웅은 곁(' + AURA + '칸)의 아군을 늘 돕는 오라가 있고, 영웅을 고르면 왼쪽 위 칸(Q)에 기술 버튼이 나와요. 쓰고 나면 재사용 시간이 돌아요.',
      ].concat(HS.map((K, f) => FAC[f].sh + ' · ' + UN[HERO0 + f].nm + ': ' + K.au + '. 기술 ' + K.ic + K.nm + '(' + K.cd + '초) — ' + K.d + '.')) },
      { h: '4인 방식', p: [
        '2:2 공동 진영(기본): 두 사람이 진영 하나를 함께 맡아요. 본부·일꾼·자원·보급·건물·생산 대기열·유닛을 모두 같이 써요(본부 하나, 일꾼 5명으로 시작).',
        '둘 다 어떤 유닛·건물이든 고르고 명령할 수 있어요. 같은 유닛에 둘이 명령하면 나중 명령대로 움직여요. 같은 자리에 동시에 지으려 하면 먼저 도착한 쪽만 지어져요.',
        '팀원이 고른 유닛은 팀원 색 점선으로, 팀원이 보는 화면은 미니맵에 점선 상자로 보여요. 1~4번 부대는 각자 따로예요.',
        '📍신호: 아무것도 안 골랐을 때 「신호」 칸, 또는 미니맵을 길게 누르기 → 「여기 공격」「도와줘」「조심」. 소리와 함께 우리 팀에게만 보여요.',
        'AI 팀원(사람 + AI): AI는 일꾼·보급·건물·연구·생산 같은 살림을 맡고, 군대는 사람에게 맡겨요. 사람이 30초 넘게 아무 명령도 안 하면 AI가 군대도 움직여요. AI 둘이 한 진영이면 평소처럼 같이 해요.',
        '공동 진영의 진영은 둘 중 고른 사람의 것을 따라요(둘 다 고르면 앞자리 사람). 2:2 각자 진영: 저마다 기지·자원·진영이 따로인 팀전. 개인전: 넷이 따로 싸워요.',
      ] },
      { h: '자원', p: [
        '광석(주황)은 거의 모든 것에, 수정(하늘색)은 고급 유닛·연구에 써요.',
        '일꾼은 덩이를 캐서 가장 가까운 본부로 날라요. 시작할 때 일꾼은 이미 캐고 있어요.',
        '본부에서 일꾼을 더 뽑을수록 수입이 늘어요(한 덩이엔 두 명까지 동시에). 덩이가 바닥나면 다른 기지 자리에 본부를 지어 확장하세요.',
      ] },
      { h: '보급', p: [
        '유닛마다 보급을 차지해요(작은 유닛 1, 대부분 2~4, 큰 유닛 6까지). 본부 +10, 보급 건물(보급고·알집·빛기둥·고철 용광로) +8, 최대 100.',
        '왼쪽 위 ⚑ 숫자(사용/한도)가 꽉 차면 더 못 뽑아요 → 보급 건물을 미리 지으세요.',
      ] },
      { h: '건물', p: [
        '일꾼을 고르고 ⚒건설 → 건물 고르기 → 지을 곳을 누르고 ✓ 짓기. 초록이면 지을 수 있어요(광석 바로 옆·경사로 위는 안 돼요).',
        '진영마다 건물 6종: 본부(일꾼) · 보급 · 병영(작은 유닛) · 공장(큰 유닛) · 연구(강화·고급 유닛 해금) · 방어탑(땅·하늘).',
        '공장·연구·방어탑은 병영이 먼저 있어야 해요. 고급 유닛은 연구 건물도 있어야 해요. (철강 예: 본부 400 · 보급고 100 · 병영 150 · 공장 150/100 · 연구소 125/75 · 포탑 100)',
        '건물을 고르면 오른쪽 아래에 뽑을 유닛이 나와요(대기열 5개, 아래 칸을 누르면 취소·환불). ⚑집결로 새 유닛이 모일 곳을 정해요.',
      ] },
      { h: '유닛과 상성 (철강 연합 예)', p: [
        '소총병: 싸고 무난, 하늘도 쏴요. 화염병: 짧은 불길로 보병 무리를 태워요. 저격수: 사거리 9로 보병을 멀리서.',
        '경장갑차: 빠르고 단단, 보병 사냥. 포격 전차: 멀리 범위 포격, 장갑·건물에 강함(바로 앞·하늘은 못 쏨). 정찰 드론: 날아다니며 전차·장갑차 사냥.',
        '땅만 쏘는 유닛(화염병·장갑차·전차)은 드론을 못 막아요 → 소총병·포탑·저격수로 막아요.',
        '수송기(공장 + 연구소): 무기는 없지만 보병 4명(일꾼 포함) 또는 차량 1대를 태우고 바위·절벽을 넘어 날아가요. 격추되면 탄 유닛도 함께 잃어요.',
        '연구(화력·방어 2단계씩)는 이미 있는 유닛에도 바로 적용돼요. 다른 진영 유닛도 경보병·장갑·공중으로 나뉘어 같은 원리로 상성이 맞물려요 — 「📖 도감」의 상성 탭.',
      ] },
      { h: '지형 · 시야', p: [
        '안 가 본 곳은 검고, 지금 아무도 없는 곳은 어둡게(전장의 안개) 보여요. 내 유닛·건물 주변만 보여요.',
        '시작 기지는 언덕 위. 낮은 땅에서는 언덕 위가 안 보이니 경사로(줄무늬 길)를 지키면 유리해요. 바위 사이 좁은 길목도 마찬가지.',
        '고지: 언덕 위에서는 사거리 +1, 낮은 땅에서 올려 쏘면 가끔(20%) 빗나가요. 수풀(짙은 덤불) 안의 유닛은 바로 곁에 온 적에게만 보이고, 쏘거나 맞으면 잠깐 드러나요. 강은 다리로만 건너요 — 다리는 좁은 길목.',
      ] },
      { h: '조작 (터치)', p: [
        '유닛 누르기 = 선택 (같은 유닛 두 번 빠르게 = 화면 속 같은 종류 모두) · 길게 누른 채 끌기 또는 ▢상자 = 여러 유닛 선택.',
        '고른 상태에서 땅 = 이동, 적 = 공격, 광석·수정 = 캐기(일꾼), 짓다 만 내 건물 = 이어 짓기. ⚔공격 = 가는 길의 적과 싸우며 이동.',
        '태우기(철강): 보병·차량을 고르고 내 수송기를 누르기(또는 수송기를 고르고 태울 유닛 누르기). 내리기: 수송기를 고르고 ⤓골라 내리기 → 땅 누르기(거기까지 날아가 내려요), ⇩바로 내리기 = 지금 자리.',
        '고철: 본부를 고르고 ⛺접기 → 이동 본부를 옮긴 뒤 ⛺펼치기. 유닛을 정비소 곁으로 데려가 🔧개조. 성광: 생산 건물의 ⚑집결을 앞쪽 빛기둥 근처에 찍으면 새 유닛이 거기로 순간이동해요.',
        '영웅: 본부를 고르고 영웅 칸으로 불러요. 영웅을 고르면 왼쪽 위 칸이 기술 버튼(남은 재사용 시간이 숫자로 보여요).',
        '끌기 = 화면 이동, 두 손가락 = 확대·축소, 미니맵 누르기 = 그곳으로. 1~4번 = 부대(탭 = 호출, 두 번 = 화면 이동, 길게 누르면 지금 선택을 지정 · PC는 Ctrl+숫자 지정, 숫자 호출), 군대 = 모든 전투 유닛, 유휴 = 쉬는 일꾼.',
      ] },
      { h: '조작 (PC)', p: [
        '왼쪽 클릭 = 선택, 끌기 = 상자 선택(Shift = 추가), 오른쪽 클릭 = 이동·공격·캐기·집결. 휠 = 확대, 가운데 버튼 끌기·방향키 = 화면 이동.',
        '명령 칸은 Q W E / A S D / Z X C (Q = 영웅 기술, A = 공격, S = 정지, D = 위치 사수, Z = 건설, X = 펼치기/접기·골라 내리기, C = 개조·바로 내리기·집결, 본부에서 W = 영웅 부르기). 1·2·3 부대(Ctrl+숫자 = 지정), F 모든 군대, H 영웅, G 쉬는 일꾼, 스페이스 본부로.',
      ] },
      { h: '예시', p: [
        '처음 2분: 본부에서 일꾼을 계속 뽑고 → 보급 건물 → 병영. 병력을 모아 경사로 앞에 두고, 3~4분에 두 번째 본부로 확장.',
        '적이 작은 유닛 떼로 온다 → 범위 공격(화염병·산성 덩이·성흔 거상·불꽃 바이크). 적 장갑이 보인다 → 장갑 사냥꾼(드론·포자 비행체·심판자·작살 포수). 적 하늘 유닛 → 하늘을 쏘는 유닛·방어탑.',
      ] },
      { h: '작전 (혼자)', p: [
        '설정의 방식을 「작전」으로 고르면 나 + 적 AI 한 명으로 짧은 임무 8개를 차례로 해요(양쪽 모두 철강 연합). 앞 작전을 성공해야 다음 작전이 열려요.',
        '1 기지 방어(8분 버티기) · 2 특수부대 침투(수송기로 연구소 파괴) · 3 제한 자원 섬멸(캘 자원 없이 12분 안에) · 4 확장 기지 지키기(9분) · 5 수송대 호위(보급 전차를 먼 기지 자리까지) · 6 거점 3곳 점령(셋 다 90초 유지) · 7 적 지휘관 사냥(튼튼한 지휘 전차 처치) · 8 맨손 생존(일꾼만으로 10분). 시작 전에 작전 설명이 나와요.',
        '적 AI 난이도(쉬움·보통·어려움)에 따라 공격대·수비대 크기가 달라져요. 가장 멀리 간 작전은 「🏆 내 최고 기록」에 남아요.',
      ] },
      { h: '함께 하기', p: [
        '한 폰에서는 한 명만 해요(나 + AI). 친구와는 온라인·LAN 방에서 각자 폰으로. 4명이면 친구와 한 진영을 같이 맡을 수도 있어요(공동 진영).',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 느긋하게 모아 늦게 오고, 보통은 정찰·상성·확장을, 어려움은 빠른 빌드·이른 공격·후퇴 컨트롤까지 해요. AI도 진영마다 다르게 싸워요(군체는 막을 넓히며 떼로, 성광은 앞쪽 빛기둥으로 순간이동 증원, 고철은 개조·본부 옮기기, 철강은 수송기 기습). AI도 영웅을 불러 싸움에 맞춰 기술을 써요.',
      ] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount, codex,
    _t: { init, genMap, newWorld, step, cmd, aiThink, aiMem, AI_DT, FTAC, FMU, HS, UN, BD, UPG, UPGF, FAC, STEP, canPlace, _addU: addU },
  });
})();
