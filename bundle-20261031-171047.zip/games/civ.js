/* 문명 개척 — 문명6(흥망성쇠·몰려드는 폭풍 포함)을 휴대폰 턴제 게임으로 옮긴 4X 전략 게임.
   1~8명(사람+AI), 한 폰 돌려하기(가림막)·온라인. 지도는 판마다 새로 만들고(대륙·판게아·군도·섬 대륙·무작위),
   도시·구역·건물·불가사의·기술/사회 제도 트리·정부/정책·종교·위인·도시국가·외교·세계 의회·시대(황금기/암흑기)·
   충성도·총독·기후/재해·전력까지 넣었어요. 상태는 JSON(지도 칸 데이터는 문자열로 압축), 크면 core가 압축해서 보내요.
   상태 개요(s):
     v 버전, W,H 지도 크기, sp 속도 배율, tl 턴 제한, t 턴, cur 차례(자리), nM 주요 문명 수, ph 'p'|'e'
     mt 지형(칸당 1글자: 지형4비트+언덕+강), mf 지형 특성/자연경관, mr 자원, ml 저지대(해수면), im 개선(+약탈), rd 도로,
     ds 구역(+약탈), wn 불가사의, ow 칸 주인 도시(2글자), ex[] 탐험한 칸(비트)
     P[] 나라(주요 문명 → 도시국가 → 야만인), C[] 도시, U[] 유닛, R[] 종교, W{} 세계 불가사의, GP 위인, WC 세계 의회,
     CL 기후, EM 비상사태, L 마지막 사건(애니메이션), q 일련번호, w 승자[], wk 승리 종류 */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= 압축·난수 도우미 ======================= */
  const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
  const B64I = {}; for (let i = 0; i < 64; i++) B64I[B64[i]] = i;
  const e1 = (v) => B64[Math.max(0, Math.min(63, v | 0))];
  const d1 = (c) => B64I[c] || 0;
  const e2 = (v) => { v = Math.max(0, Math.min(4095, v | 0)); return B64[v >> 6] + B64[v & 63]; };
  const d2 = (s, i) => d1(s[i]) * 64 + d1(s[i + 1]);
  function rng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const R = () => Math.random();
  const ri = (n) => Math.floor(Math.random() * n);
  const pickR = (a) => a[Math.floor(Math.random() * a.length)];
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const sum = (a) => a.reduce((x, y) => x + y, 0);

  /* ======================= 산출(6종) ======================= */
  // 0 식량 1 생산 2 금 3 과학 4 문화 5 신앙
  const YN = ['식량', '생산', '금', '과학', '문화', '신앙'];
  const YI = ['🌾', '⚒', '💰', '🔬', '🎭', '🙏'];
  const YC = ['#9fd36a', '#e09a4a', '#f2cf55', '#6fb7e8', '#c991e8', '#f0f0f0'];
  const Y0 = () => [0, 0, 0, 0, 0, 0];
  const yAdd = (a, b, k) => { if (!b) return a; k = k == null ? 1 : k; for (let i = 0; i < 6; i++) a[i] += (b[i] || 0) * k; return a; };
  const yStr = (y, sep) => { const o = []; for (let i = 0; i < 6; i++) if (y[i]) o.push(YI[i] + (y[i] > 0 ? '+' : '') + (Math.round(y[i] * 10) / 10)); return o.join(sep || ' '); };

  /* ======================= 지형 ======================= */
  const TER = [
    { k: 'grass', n: '초원', y: [2, 0, 0, 0, 0, 0], col: '#6f9a3e' },
    { k: 'plains', n: '평원', y: [1, 1, 0, 0, 0, 0], col: '#a9a04e' },
    { k: 'desert', n: '사막', y: [0, 0, 0, 0, 0, 0], col: '#d6bf83' },
    { k: 'tundra', n: '툰드라', y: [1, 0, 0, 0, 0, 0], col: '#8b977f' },
    { k: 'snow', n: '설원', y: [0, 0, 0, 0, 0, 0], col: '#dfe7ec' },
    { k: 'coast', n: '연안', y: [1, 0, 1, 0, 0, 0], water: 1, col: '#3a82ad' },
    { k: 'ocean', n: '대양', y: [1, 0, 0, 0, 0, 0], water: 1, deep: 1, col: '#1f5583' },
    { k: 'lake', n: '호수', y: [1, 0, 1, 0, 0, 0], water: 1, fresh: 1, col: '#4c96bb' },
    { k: 'mtn', n: '산', y: [0, 0, 0, 0, 0, 0], imp: 1, col: '#857d8c' },
  ];
  const TG = 0, TP = 1, TD = 2, TT = 3, TS = 4, TC = 5, TO = 6, TLK = 7, TM = 8;
  // 지형 특성 (1~15), 자연경관은 16+
  const FEAT = [null,
    { k: 'woods', n: '숲', y: [0, 1], mc: 1, df: 3, d: '생산 +1. 이동 2, 방어 +3. 채광 연구 뒤 베어 생산을 얻을 수 있어요.' },
    { k: 'rain', n: '열대우림', y: [1, 0], mc: 1, df: 3, d: '식량 +1. 이동 2, 방어 +3. 청동기 연구 뒤 베어 낼 수 있어요.' },
    { k: 'marsh', n: '습지', y: [1, 0], mc: 1, df: -2, d: '식량 +1. 이동 2, 방어 −2. 관개 연구 뒤 없앨 수 있어요.' },
    { k: 'flood', n: '범람원', y: [1, 0], mc: 0, df: -2, d: '강가의 비옥한 땅(사막이면 식량 +3). 홍수가 나면 땅이 더 비옥해지지만 개선이 망가질 수 있어요.' },
    { k: 'oasis', n: '오아시스', y: [3, 0, 1], mc: 0, df: 0, fresh: 1, d: '사막의 샘. 식량 +3 · 금 +1, 민물.' },
    { k: 'reef', n: '암초', y: [1, 1], mc: 1, df: 3, d: '연안의 산호. 식량 +1 · 생산 +1, 캠퍼스 인접 +1.' },
    { k: 'ice', n: '빙하', y: [0, 0], imp: 1, d: '지나갈 수 없어요.' },
    { k: 'volc', n: '화산', y: [0, 0], d: '활화산. 가끔 분화해 주변 유닛을 다치게 하지만 화산토를 남겨요.' },
    { k: 'vsoil', n: '화산토', y: [1, 1], mc: 0, df: 0, d: '분화가 남긴 비옥한 땅. 식량 +1 · 생산 +1.' },
  ];
  const F_WOODS = 1, F_RAIN = 2, F_MARSH = 3, F_FLOOD = 4, F_OASIS = 5, F_REEF = 6, F_ICE = 7, F_VOLC = 8, F_VSOIL = 9;
  // 자연경관
  const NW = [
    { k: 'kili', n: '킬리만자로', mtn: 1, d: '인접한 칸 식량 +2. 지나갈 수 없어요.', adj: [2, 0, 0, 0, 0, 0] },
    { k: 'everest', n: '에베레스트', mtn: 1, d: '인접한 칸 신앙 +1, 성지 인접 +2.', adj: [0, 0, 0, 0, 0, 1] },
    { k: 'reef', n: '그레이트 배리어 리프', water: 1, y: [3, 0, 0, 2, 0, 0], d: '바다 위 산호초. 식량 +3 · 과학 +2, 캠퍼스 인접 +2.' },
    { k: 'galap', n: '갈라파고스 제도', water: 1, y: [0, 0, 0, 0, 0, 0], d: '인접한 칸 과학 +2.', adj: [0, 0, 0, 2, 0, 0] },
    { k: 'uluru', n: '울루루', mtn: 1, d: '인접한 칸 신앙 +3.', adj: [0, 0, 0, 0, 0, 3] },
    { k: 'deadsea', n: '사해', water: 1, y: [0, 0, 0, 0, 2, 2], d: '문화 +2 · 신앙 +2. 인접한 유닛은 다 나아요.' },
    { k: 'torres', n: '토레스 델 파이네', mtn: 1, d: '인접한 칸 식량 +1 · 생산 +1.', adj: [1, 1, 0, 0, 0, 0] },
    { k: 'eyja', n: '에이야퍄들라이외퀴들', mtn: 1, volc: 1, d: '화산 경관. 인접한 칸 과학 +1 · 생산 +1, 가끔 분화해 화산토를 만들어요.', adj: [0, 1, 0, 1, 0, 0] },
    { k: 'yosem', n: '요세미티', mtn: 1, d: '인접한 칸 과학 +1 · 금 +1.', adj: [0, 0, 1, 1, 0, 0] },
    { k: 'pamuk', n: '파묵칼레', y: [0, 0, 0, 1, 1, 0], d: '석회 온천. 인접 도시 쾌적도 +2, 과학 +1 · 문화 +1.' },
    { k: 'matter', n: '마터호른', mtn: 1, d: '인접한 칸에서 싸우는 유닛 전투력 +2, 인접 칸 문화 +1.', adj: [0, 0, 0, 0, 1, 0] },
  ];
  const NW0 = 16;

  /* ======================= 자원 ======================= */
  // c: b 보너스 / l 사치 / s 전략, on: 놓일 수 있는 곳, im: 맞는 개선, rv: 보이게 하는 기술
  const RES = [null,
    { k: 'wheat', n: '밀', c: 'b', y: [1, 0], on: 'p,g:flood,d:flood', im: 'farm' },
    { k: 'rice', n: '쌀', c: 'b', y: [1, 0], on: 'g,g:marsh', im: 'farm' },
    { k: 'cattle', n: '소', c: 'b', y: [1, 0], on: 'g', im: 'pasture' },
    { k: 'sheep', n: '양', c: 'b', y: [1, 0], on: 'gh,ph,dh,th', im: 'pasture' },
    { k: 'deer', n: '사슴', c: 'b', y: [0, 1], on: 't,g:woods,p:woods,t:woods', im: 'camp' },
    { k: 'banana', n: '바나나', c: 'b', y: [1, 0], on: 'g:rain,p:rain', im: 'plant' },
    { k: 'stone', n: '돌', c: 'b', y: [0, 1], on: 'g,p,gh', im: 'quarry' },
    { k: 'copper', n: '구리', c: 'b', y: [0, 0, 2], on: 'gh,ph,dh,th', im: 'mine' },
    { k: 'fish', n: '물고기', c: 'b', y: [1, 0], on: 'w', im: 'fish' },
    { k: 'crabs', n: '게', c: 'b', y: [0, 0, 2], on: 'w', im: 'fish' },
    { k: 'silk', n: '비단', c: 'l', y: [0, 0, 0, 0, 1], on: 'g:woods,p:woods', im: 'plant' },
    { k: 'spices', n: '향신료', c: 'l', y: [2, 0], on: 'g:rain,p:rain', im: 'plant' },
    { k: 'wine', n: '포도주', c: 'l', y: [1, 0, 1], on: 'g,p,gh,ph', im: 'plant' },
    { k: 'diamond', n: '다이아몬드', c: 'l', y: [0, 0, 3], on: 'gh,ph,dh,g:rain', im: 'mine' },
    { k: 'ivory', n: '상아', c: 'l', y: [0, 1, 1], on: 'g:rain,p,d', im: 'camp' },
    { k: 'cotton', n: '목화', c: 'l', y: [0, 0, 3], on: 'g,p,d:flood', im: 'plant' },
    { k: 'dyes', n: '염료', c: 'l', y: [0, 0, 0, 0, 0, 1], on: 'g:rain,g:woods,p:woods', im: 'plant' },
    { k: 'furs', n: '모피', c: 'l', y: [1, 0, 1], on: 't:woods,t,g:woods', im: 'camp' },
    { k: 'incense', n: '유향', c: 'l', y: [0, 0, 0, 0, 0, 1], on: 'p,d', im: 'plant' },
    { k: 'pearls', n: '진주', c: 'l', y: [0, 0, 0, 0, 0, 1], on: 'w', im: 'fish' },
    { k: 'sugar', n: '설탕', c: 'l', y: [2, 0], on: 'g:marsh,g:flood,p:flood', im: 'plant' },
    { k: 'tea', n: '차', c: 'l', y: [0, 0, 0, 1], on: 'gh,ph', im: 'plant' },
    { k: 'whales', n: '고래', c: 'l', y: [0, 1, 1], on: 'w', im: 'fish' },
    { k: 'marble', n: '대리석', c: 'l', y: [0, 0, 1, 0, 1], on: 'g,p,gh,ph', im: 'quarry' },
    { k: 'silver', n: '은', c: 'l', y: [0, 0, 3], on: 'dh,th,d,t', im: 'mine' },
    { k: 'salt', n: '소금', c: 'l', y: [1, 0, 1], on: 'p,d,t,ph', im: 'mine' },
    { k: 'citrus', n: '감귤', c: 'l', y: [2, 0], on: 'g,p', im: 'plant' },
    { k: 'coffee', n: '커피', c: 'l', y: [0, 0, 0, 0, 1], on: 'g:rain,g,p:rain', im: 'plant' },
    { k: 'horses', n: '말', c: 's', y: [1, 1], on: 'g,p,t', im: 'pasture', rv: 'animal' },
    { k: 'iron', n: '철', c: 's', y: [0, 0, 0, 1], on: 'gh,ph,dh,th,g,p', im: 'mine', rv: 'bronze' },
    { k: 'niter', n: '초석', c: 's', y: [1, 1], on: 'g,p,d,t,g:flood,d:flood', im: 'mine', rv: 'milEng' },
    { k: 'coal', n: '석탄', c: 's', y: [0, 2], on: 'gh,ph,g:woods,p:woods,g:rain', im: 'mine', rv: 'industrial' },
    { k: 'oil', n: '석유', c: 's', y: [0, 3], on: 'd,t,g:marsh,d:flood,s,w', im: 'oilwell', rv: 'refining' },
    { k: 'alum', n: '알루미늄', c: 's', y: [0, 0, 0, 1], on: 'd,p,dh,ph,g:rain', im: 'mine', rv: 'radio' },
    { k: 'uranium', n: '우라늄', c: 's', y: [0, 2], on: 'd,t,s,g:rain,g:woods,ph', im: 'mine', rv: 'combinedArms' },
  ];
  const RESI = {}; RES.forEach((r, i) => { if (r) RESI[r.k] = i; });
  const STRAT = RES.map((r, i) => (r && r.c === 's' ? i : -1)).filter((i) => i >= 0);

  /* ======================= 개선 ======================= */
  const IMP = [null,
    { k: 'farm', n: '농장', y: [1], tech: null, d: '식량 +1. 봉건제: 농장 2개와 붙으면 +1, 교체 가능 부품: +1. 주거 +0.5.' },
    { k: 'mine', n: '광산', y: [0, 1], tech: 'mining', d: '언덕·광물 자원에. 생산 +1(도제 +1, 산업화 +1).' },
    { k: 'quarry', n: '채석장', y: [0, 1], tech: 'mining', d: '돌·대리석에. 생산 +1.' },
    { k: 'pasture', n: '목장', y: [0, 1], tech: 'animal', d: '소·양·말에. 생산 +1, 주거 +0.5.' },
    { k: 'plant', n: '농원', y: [0, 0, 2], tech: 'irrigation', d: '농원 자원에. 금 +2, 주거 +0.5.' },
    { k: 'camp', n: '야영지', y: [0, 0, 1], tech: 'animal', d: '사슴·모피·상아에. 금 +1, 주거 +0.5.' },
    { k: 'fish', n: '어선', y: [1, 0], tech: 'sailing', d: '바다 자원에. 식량 +1(지도 제작 금 +2).' },
    { k: 'lumber', n: '제재소', y: [0, 2], tech: 'machinery', d: '숲·열대우림에. 생산 +2.' },
    { k: 'oilwell', n: '유정', y: [0, 2], tech: 'refining', d: '석유에. 생산 +2.' },
    { k: 'fort', n: '요새', y: [0, 0], tech: 'siegeTac', d: '이 칸의 유닛이 바로 2턴 경계 효과(+6)를 받아요.' },
    { k: 'resort', n: '해변 휴양지', y: [0, 0, 2], tech: 'radio', d: '바닷가 아름다운 땅. 금 +2, 매력만큼 관광.' },
    { k: 'solar', n: '태양광 발전소', y: [0, 0], tech: 'synthetic', pw: 2, d: '평평한 사막·평원에. 전력 +2(탄소 없음).' },
    { k: 'wind', n: '풍력 발전소', y: [0, 0], tech: 'composites', pw: 2, d: '평지에. 전력 +2(탄소 없음).' },
    { k: 'bcamp', n: '야만인 야영지', y: [0, 0], sp: 1, d: '야만인 기지. 정찰병이 도시를 찾으면 습격대를 보내요. 군사 유닛으로 들어가면 없애고 금을 얻어요.' },
    { k: 'silo', n: '미사일 사일로', y: [0, 0], sp: 1, d: '군사 공학자가 지어요(로켓 공학). 여기서 12칸 안으로 핵무기를 쏴요.' },
    { k: 'goody', n: '부족 마을', y: [0, 0], sp: 1, d: '아무 유닛으로 들어가면 금·신앙·유레카·영감·유닛·인구 등 선물을 받아요.' },
    { k: 'ant', n: '고대 유적', y: [0, 0], sp: 1, d: '옛 전투·야영지 자리. 「자연사」 뒤 고고학자가 발굴하면 유물을 얻어요.' },
    // 고유 개선 (문명별)
    { k: 'greatwall', n: '만리장성', y: [0, 0, 1], tech: 'masonry', civ: 'china', df: 4, d: '중국 전용. 국경 칸에. 금 +1, 방어 +4, 붙은 만리장성마다 문화 +1.' },
    { k: 'sphinx', n: '스핑크스', y: [0, 0, 0, 0, 1, 1], tech: 'craftsmanship', civic: 1, civ: 'egypt', d: '이집트 전용. 신앙 +1 · 문화 +1, 범람원이면 신앙 +1 더.' },
    { k: 'chateau', n: '샤토', y: [0, 0, 1, 0, 2], tech: 'humanism', civic: 1, civ: 'france', d: '프랑스 전용. 강가에. 문화 +2 · 금 +1.' },
    { k: 'stepwell', n: '계단식 우물', y: [1, 0, 0, 0, 0, 1], tech: 'irrigation', civ: 'india', d: '인도 전용. 식량 +1 · 신앙 +1, 주거 +1.' },
    { k: 'kurgan', n: '쿠르간', y: [0, 0, 1, 0, 0, 1], tech: 'animal', civ: 'scythia', d: '스키타이 전용. 신앙 +1 · 금 +1, 인접 목장마다 신앙 +1.' },
    { k: 'mission', n: '미션', y: [0, 0, 0, 1, 0, 2], tech: 'exploration', civic: 1, civ: 'spain', d: '스페인 전용. 신앙 +2 · 과학 +1.' },
    { k: 'ziggurat', n: '지구라트', y: [0, 0, 0, 2, 0], tech: null, civ: 'sumeria', d: '수메르 전용. 과학 +2, 강가면 문화 +1.' },
    { k: 'polder', n: '간척지', y: [1, 1, 1], tech: 'guilds', civic: 1, civ: 'netherlands', d: '네덜란드 전용. 연안 바다를 땅처럼. 식량 +1 · 생산 +1 · 금 +1, 주거 +0.5.' },
    { k: 'terrace', n: '계단식 농지', y: [1, 0], tech: null, civ: 'inca', d: '잉카 전용. 언덕에. 식량 +1, 인접한 산마다 식량 +1, 주거 +0.5.' },
    { k: 'pairi', n: '파이리다에자', y: [0, 0, 2, 0, 1], tech: 'bronze', civ: 'persia', d: '페르시아 전용 정원. 문화 +1 · 금 +2, 주변 매력 +1.' },
    { k: 'outback', n: '방목장', y: [1, 1], tech: 'animal', civ: 'australia', d: '오스트레일리아 전용. 평지에. 식량 +1 · 생산 +1, 붙은 목장마다 식량 +1, 주거 +0.5.' },
    { k: 'mekewap', n: '메키와프', y: [0, 1], tech: 'pottery', civ: 'cree', d: '크리 전용. 자원 옆 빈 칸에. 생산 +1, 주거 +1, 붙은 사치 자원마다 금 +1.' },
    { k: 'rockchurch', n: '암굴 교회', y: [0, 0, 0, 0, 0, 1], tech: 'theology', civic: 1, civ: 'ethiopia', d: '에티오피아 전용. 언덕에. 신앙 +1, 붙은 산마다 신앙 +1, 매력만큼 관광.' },
    { k: 'hacienda', n: '아시엔다', y: [0, 1, 2], tech: 'mercantilism', civic: 1, civ: 'gcolombia', d: '그란 콜롬비아 전용. 평지에. 생산 +1 · 금 +2, 붙은 농원마다 식량 +1.' },
    { k: 'kampung', n: '캄풍', y: [1, 1], tech: 'massProd', civ: 'indonesia', d: '인도네시아 전용. 바다 자원 옆 연안 물 위에. 식량·생산 +1, 주거 +1.' },
    { k: 'chemamull', n: '체마물', y: [0, 0, 0, 0, 1], tech: 'recHist', civic: 1, civ: 'mapuche', d: '마푸체 전용. 문화 +1, 매력의 75%만큼 관광.' },
    { k: 'nubpyr', n: '누비아 피라미드', y: [0, 0, 0, 0, 0, 2], tech: 'masonry', civ: 'nubia', d: '누비아 전용. 사막·범람원에. 신앙 +2, 붙은 도심마다 식량 +1.' },
    { k: 'feitoria', n: '페이토리아', y: [0, 1, 4], tech: 'cartography', civ: 'portugal', d: '포르투갈 전용. 바다에 붙은 땅에. 생산 +1 · 금 +4.' },
    { k: 'golf', n: '골프장', y: [0, 0, 2, 0, 1], tech: 'games', civic: 1, civ: 'scotland', d: '스코틀랜드 전용. 금 +2 · 문화 +1, 이 도시 쾌적도 +1.' },
    { k: 'icerink', n: '하키 경기장', y: [0, 0, 0, 0, 1], tech: 'games', civic: 1, civ: 'canada', d: '캐나다 전용. 툰드라·설원에. 문화 +1, 6칸 안 도시 쾌적도 +1.' },
  ];
  const IMPI = {}; IMP.forEach((m, i) => { if (m) IMPI[m.k] = i; });

  /* ======================= 구역 ======================= */
  // y: 인접 보너스가 들어가는 산출, gp: 위인 점수 종류, lim: 인구 제한에 포함
  const DIS = [null,
    { k: 'cc', n: '도심', c: 0, d: '도시의 중심.' },
    { k: 'cam', n: '캠퍼스', c: 54, req: 'writing', y: 3, gp: 'sci', lim: 1, ico: '🔬', col: '#3d79b8', d: '과학. 인접: 산 +1, 암초 +2, 열대우림 2개당 +1, 구역 2개당 +1.' },
    { k: 'hs', n: '성지', c: 54, req: 'astrology', y: 5, gp: 'pro', lim: 1, ico: '🙏', col: '#cfc8a9', d: '신앙. 인접: 산 +1, 자연경관 +2, 숲 2개당 +1, 구역 2개당 +1.' },
    { k: 'com', n: '상업 중심지', c: 54, req: 'currency', y: 2, gp: 'mer', lim: 1, ico: '💰', col: '#d9ad2c', d: '금. 인접: 강 +2, 항만 +2, 구역 2개당 +1. 교역로 +1.' },
    { k: 'th', n: '극장가', c: 54, req: 'c:drama', y: 4, gp: 'wri,art,mus', lim: 1, ico: '🎭', col: '#a75bc4', d: '문화. 인접: 불가사의 +1, 오락 단지·수상 공원 +2, 구역 2개당 +1.' },
    { k: 'ind', n: '산업구역', c: 54, req: 'apprentice', y: 1, gp: 'eng', lim: 1, ico: '⚙', col: '#c46c2c', d: '생산. 인접: 송수로·댐·운하 +2, 광산·채석장 +1, 구역 2개당 +1.' },
    { k: 'hb', n: '항만', c: 54, req: 'celestial', y: 2, gp: 'adm', lim: 1, water: 1, ico: '⚓', col: '#3a9fb6', d: '물 위(연안)에. 금. 인접: 도심 +2, 바다 자원 2개당 +1, 구역 2개당 +1. 배를 만들 수 있어요.' },
    { k: 'enc', n: '주둔지', c: 54, req: 'bronze', y: -1, gp: 'gen', lim: 1, ico: '⚔', col: '#b5403a', d: '군사. 도심과 붙을 수 없어요. 원거리 공격·유닛 경험치 보너스. 한 도시에 하나.' },
    { k: 'ent', n: '오락 단지', c: 54, req: 'c:games', y: -1, lim: 1, ico: '🎡', col: '#d0589a', d: '쾌적도 +1(건물로 더). 극장가 인접 +2.' },
    { k: 'wp', n: '수상 공원', c: 54, req: 'c:navalTrad', y: -1, lim: 1, water: 1, ico: '🎢', col: '#4cc3c8', d: '물 위(연안)에. 쾌적도 +1(건물로 더).' },
    { k: 'aq', n: '송수로', c: 36, req: 'engineering', y: -1, ico: '💧', col: '#6aaad8', d: '도심과 붙고 산·강·호수·오아시스와 붙어야 해요. 민물이 없으면 주거 +6, 있으면 +2. 산업구역 인접 +2.' },
    { k: 'nb', n: '주거 지구', c: 54, req: 'c:urbanization', y: -1, ico: '🏘', col: '#b89a72', d: '주거 +2~+6(매력이 높을수록 많이).' },
    { k: 'sp', n: '우주 기지', c: 900, fixed: 1, req: 'rocketry', y: -1, ico: '🚀', col: '#9aa8b8', d: '평지에. 우주 개발 프로젝트(과학 승리)를 할 수 있어요.' },
    { k: 'gov', n: '정부 청사', c: 30, req: 'c:stateWork', y: -1, lim: 1, one: 1, ico: '🏛', col: '#c9b26a', d: '나라에 하나. 와일드카드 정책 슬롯 +1, 총독 칭호 +1. 붙은 구역 인접 +1.' },
    { k: 'dq', n: '외교 구역', c: 54, req: 'c:diploServ', y: -1, lim: 1, one: 1, ico: '🕊', col: '#7fb6a8', d: '나라에 하나. 외교 호의 +2/턴, 사절 +1, 동맹이 빨리 깊어져요.' },
    { k: 'dam', n: '댐', c: 81, req: 'c:civilEng', y: -1, ico: '🌊', col: '#5e88b2', d: '강의 범람원에. 홍수를 막고 쾌적도 +1, 수력 발전(전력 +6)을 지을 수 있어요.' },
    { k: 'can', n: '운하', c: 81, req: 'massProd', y: -1, ico: '⛵', col: '#4d93c2', d: '평지에. 배가 지나갈 수 있는 물길. 산업구역 인접 +2.' },
    { k: 'ad', n: '비행장', c: 54, req: 'flight', y: -1, lim: 1, ico: '✈', col: '#8aa0b4', d: '평지에. 항공 유닛 기지(2대, 격납고·공항마다 +2). 항공 유닛을 다른 비행장·도시로 옮길 수 있어요.' },
    { k: 'pr', n: '보존 지구', c: 54, req: 'c:mysticism', y: -1, lim: 1, ico: '🌳', col: '#3f8a4a', d: '도심과 붙을 수 없어요. 주변 칸 매력 +1. 신성한 숲·보호구역을 지으면 붙은 아름다운 칸이 산출을 더 줘요.' },
  ];
  const DISI = {}; DIS.forEach((d, i) => { if (d) DISI[d.k] = i; });

  /* ======================= 건물 ======================= */
  // d 구역, c 비용, req 기술(c:는 제도), y 산출, h 주거, a 쾌적도, gp 위인 점수, pre 선행, pw 전력 필요, gw 걸작 칸
  const BLD = [
    { k: 'palace', n: '궁전', d: 'cc', c: 0, y: [0, 2, 5, 2, 1, 0], h: 1, a: 1, gw: 'any', d2: '수도. 생산 +2 · 금 +5 · 과학 +2 · 문화 +1, 주거 +1, 쾌적도 +1, 걸작 칸 1.' },
    { k: 'monument', n: '기념비', d: 'cc', c: 60, y: [0, 0, 0, 0, 2], loy: 2, d2: '문화 +2, 충성도 +2.' },
    { k: 'granary', n: '곡물 창고', d: 'cc', c: 65, req: 'pottery', y: [1], h: 2, d2: '식량 +1, 주거 +2.' },
    { k: 'watermill', n: '물레방아', d: 'cc', c: 80, req: 'wheel', y: [1, 1], river: 1, d2: '강가 도시만. 식량 +1 · 생산 +1.' },
    { k: 'wall1', n: '고대 성벽', d: 'cc', c: 80, req: 'masonry', wall: 1, d2: '성벽 체력 +100, 도시 원거리 공격 가능.' },
    { k: 'wall2', n: '중세 성벽', d: 'cc', c: 225, req: 'castles', pre: 'wall1', wall: 2, d2: '성벽 체력 +100.' },
    { k: 'wall3', n: '르네상스 성벽', d: 'cc', c: 305, req: 'siegeTac', pre: 'wall2', wall: 3, d2: '성벽 체력 +100.' },
    { k: 'sewer', n: '하수도', d: 'cc', c: 200, req: 'sanitation', h: 2, d2: '주거 +2.' },
    { k: 'library', n: '도서관', d: 'cam', c: 90, y: [0, 0, 0, 2], gp: 1, h: 0, d2: '과학 +2, 위대한 과학자 +1.' },
    { k: 'university', n: '대학교', d: 'cam', c: 250, req: 'education', pre: 'library', y: [0, 0, 0, 4], h: 1, gp: 1, d2: '과학 +4, 주거 +1.' },
    { k: 'researchlab', n: '연구소', d: 'cam', c: 580, req: 'chemistry', pre: 'university', y: [0, 0, 0, 5], pw: 1, gp: 1, d2: '과학 +5(전력 있으면 +3 더).' },
    { k: 'shrine', n: '사당', d: 'hs', c: 70, y: [0, 0, 0, 0, 0, 2], gp: 1, d2: '신앙 +2, 선교사를 살 수 있어요.' },
    { k: 'temple', n: '신전', d: 'hs', c: 120, req: 'c:theology', pre: 'shrine', y: [0, 0, 0, 0, 0, 4], gp: 1, gw: 'rel', gwn: 1, d2: '신앙 +4, 사도를 살 수 있어요. 성유물 칸 1.' },
    { k: 'worship', n: '예배 건물', d: 'hs', c: 190, req: 'worship', pre: 'temple', y: [0, 0, 0, 0, 0, 3], d2: '종교의 예배 신앙으로 정해져요.' },
    { k: 'market', n: '시장', d: 'com', c: 120, req: 'currency', y: [0, 0, 3], gp: 1, d2: '금 +3, 위대한 상인 +1.' },
    { k: 'bank', n: '은행', d: 'com', c: 290, req: 'banking', pre: 'market', y: [0, 0, 5], gp: 1, gw: 'any', d2: '금 +5.' },
    { k: 'stock', n: '증권 거래소', d: 'com', c: 390, req: 'economics', pre: 'bank', y: [0, 0, 7], pw: 1, d2: '금 +7(전력 있으면 +3 더).' },
    { k: 'amphi', n: '원형 극장', d: 'th', c: 150, req: 'c:drama', y: [0, 0, 0, 0, 2], gp: 1, gw: 'wri', gwn: 2, d2: '문화 +2, 문학 걸작 칸 2.' },
    { k: 'museum', n: '미술관', d: 'th', c: 290, req: 'c:humanism', pre: 'amphi', y: [0, 0, 0, 0, 2], gp: 1, gw: 'art', gwn: 3, xg: 'mus', d2: '문화 +2, 미술 걸작 칸 3(서로 다른 예술가 3명이면 테마: 걸작 산출·관광 2배). 고고학 박물관과 둘 중 하나.' },
    { k: 'archmus', n: '고고학 박물관', d: 'th', c: 290, req: 'c:naturalHist', pre: 'amphi', y: [0, 0, 0, 0, 2], gp: 1, gw: 'arti', gwn: 3, xg: 'mus', d2: '문화 +2, 유물 칸 3(같은 시대·서로 다른 문명 유물 3점이면 테마: 2배). 고고학자를 만들 수 있어요. 미술관과 둘 중 하나.' },
    { k: 'broadcast', n: '방송 센터', d: 'th', c: 580, req: 'radio', pre: 'museum', y: [0, 0, 0, 0, 4], pw: 1, gp: 1, gw: 'mus', gwn: 1, d2: '문화 +4(전력 있으면 +2 더), 음악 걸작 칸 1.' },
    { k: 'workshop', n: '작업장', d: 'ind', c: 195, req: 'apprentice', y: [0, 2], gp: 1, d2: '생산 +2.' },
    { k: 'factory', n: '공장', d: 'ind', c: 390, req: 'industrial', pre: 'workshop', y: [0, 3], gp: 1, pw: 1, d2: '생산 +3, 전력 있으면 6칸 안 도시들 생산 +2.' },
    { k: 'coalplant', n: '석탄 발전소', d: 'ind', c: 300, req: 'electricity', pre: 'factory', y: [0, 1], power: 4, fuel: 'coal', co2: 3, xg: 'plant', d2: '석탄 1/턴 → 전력 +4(6칸 안 도시). 이산화탄소를 많이 내요.' },
    { k: 'oilplant', n: '석유 발전소', d: 'ind', c: 300, req: 'refining', pre: 'factory', y: [0, 2], power: 4, fuel: 'oil', co2: 2, xg: 'plant', d2: '석유 1/턴 → 전력 +4. 이산화탄소.' },
    { k: 'nukeplant', n: '원자력 발전소', d: 'ind', c: 600, req: 'fission', pre: 'factory', y: [0, 3, 0, 2], power: 8, fuel: 'uranium', co2: 0, xg: 'plant', d2: '우라늄 1/턴 → 전력 +8, 과학 +2. 탄소 없음.' },
    { k: 'lighthouse', n: '등대', d: 'hb', c: 120, req: 'celestial', y: [1, 0, 1], h: 1, gp: 1, d2: '식량 +1 · 금 +1, 주거 +1.' },
    { k: 'shipyard', n: '조선소', d: 'hb', c: 290, req: 'massProd', pre: 'lighthouse', y: [0, 2], gp: 1, d2: '생산 +2, 바다 유닛 경험치 +25%.' },
    { k: 'seaport', n: '항구', d: 'hb', c: 580, req: 'electricity', pre: 'shipyard', y: [2, 0, 2], h: 1, d2: '식량 +2 · 금 +2, 주거 +1.' },
    { k: 'barracks', n: '병영', d: 'enc', c: 90, req: 'bronze', y: [0, 1], h: 1, gp: 1, xg: 'enc1', xp: 1, d2: '생산 +1, 주거 +1, 보병 경험치 +25%.' },
    { k: 'stable', n: '마구간', d: 'enc', c: 120, req: 'horseback', y: [0, 1], h: 1, gp: 1, xg: 'enc1', xp: 1, d2: '생산 +1, 주거 +1, 기병 경험치 +25%.' },
    { k: 'armory', n: '무기고', d: 'enc', c: 195, req: 'milEng', preAny: ['barracks', 'stable'], y: [0, 1], gp: 1, stk: 10, d2: '생산 +1, 전략 자원 저장 +10.' },
    { k: 'milacad', n: '군사 학교', d: 'enc', c: 390, req: 'milScience', pre: 'armory', y: [0, 1], gp: 1, d2: '생산 +1, 새 유닛 경험치 +25%.' },
    { k: 'arena', n: '투기장', d: 'ent', c: 150, req: 'c:games', a: 1, y: [0, 0, 0, 0, 1], d2: '쾌적도 +1, 문화 +1.' },
    { k: 'zoo', n: '동물원', d: 'ent', c: 445, req: 'c:naturalHist', pre: 'arena', a: 1, rg: 1, d2: '6칸 안 도시 쾌적도 +1.' },
    { k: 'stadium', n: '경기장', d: 'ent', c: 660, req: 'c:proSports', pre: 'zoo', a: 2, rg: 1, pw: 1, d2: '6칸 안 도시 쾌적도 +2(전력 필요).' },
    { k: 'ferris', n: '대관람차', d: 'wp', c: 290, req: 'c:navalTrad', a: 1, y: [0, 0, 0, 0, 1], d2: '쾌적도 +1, 문화 +1.' },
    { k: 'aquarium', n: '수족관', d: 'wp', c: 445, req: 'c:naturalHist', pre: 'ferris', a: 1, rg: 1, y: [0, 0, 0, 1], d2: '6칸 안 도시 쾌적도 +1, 과학 +1.' },
    { k: 'hydro', n: '수력 발전소', d: 'dam', c: 580, req: 'electricity', power: 6, co2: 0, d2: '전력 +6(탄소 없음).' },
    { k: 'flood', n: '방조제', d: 'cc', c: 500, req: 'steam', fb: 1, d2: '해수면이 올라도 이 도시의 저지대가 잠기지 않아요.' },
    { k: 'hangar', n: '격납고', d: 'ad', c: 270, req: 'flight', y: [0, 1], air: 2, d2: '이 비행장 항공 유닛 칸 +2, 생산 +1.' },
    { k: 'airport', n: '공항', d: 'ad', c: 480, req: 'advFlight', pre: 'hangar', y: [0, 1, 2], air: 2, tour: 2, d2: '항공 유닛 칸 +2, 금 +2, 관광 +2.' },
    { k: 'grove', n: '신성한 숲', d: 'pr', c: 150, req: 'c:mysticism', y: [0, 0, 0, 0, 1, 1], d2: '보존 지구에 붙은 매력 2 이상 칸: 문화 +1 · 신앙 +1.' },
    { k: 'sanct', n: '보호구역', d: 'pr', c: 290, req: 'c:conservation', pre: 'grove', h: 2, d2: '보존 지구에 붙은 매력 4 이상 칸: 식량 +1 · 생산 +1, 주거 +2.' },
    // 고유 건물
    { k: 'madrasa', n: '마드라사', d: 'cam', c: 250, req: 'education', pre: 'library', y: [0, 0, 0, 5], h: 1, gp: 1, civ: 'arabia', rep: 'university', d2: '아라비아 전용(대학교 대신). 과학 +5, 캠퍼스 인접만큼 신앙.' },
    { k: 'filmstudio', n: '영화 스튜디오', d: 'th', c: 580, req: 'radio', pre: 'museum', y: [0, 0, 0, 0, 4], pw: 1, gp: 1, gw: 'mus', gwn: 1, tour: 6, civ: 'america', rep: 'broadcast', d2: '미국 전용(방송 센터 대신). 관광 +6.' },
    { k: 'elecfac', n: '전자 공장', d: 'ind', c: 390, req: 'industrial', pre: 'workshop', y: [0, 4, 0, 0, 4], gp: 1, pw: 1, civ: 'japan', rep: 'factory', d2: '일본 전용(공장 대신). 생산 +4 · 문화 +4.' },
    { k: 'stave', n: '스테이브 교회', d: 'hs', c: 120, req: 'c:theology', pre: 'shrine', y: [0, 0, 0, 0, 0, 4], gp: 1, civ: 'norway', rep: 'temple', gw: 'rel', gwn: 1, d2: '노르웨이 전용(신전 대신). 인접한 숲마다 신앙 +1. 성유물 칸 1.' },
    { k: 'tlachtli', n: '틀라츠틀리', d: 'ent', c: 120, req: 'c:games', a: 1, y: [0, 0, 0, 0, 0, 2], civ: 'aztec', rep: 'arena', d2: '아즈텍 전용(투기장 대신). 쾌적도 +1, 신앙 +2, 위대한 장군 +1.' },
    { k: 'ordu', n: '오르두', d: 'enc', c: 120, req: 'horseback', y: [0, 1], h: 1, gp: 1, xg: 'enc1', xp: 1, civ: 'mongolia', rep: 'stable', d2: '몽골 전용(마구간 대신). 여기서 만든 기병 이동 +1.' },
    { k: 'bazaar', n: '대 바자르', d: 'com', c: 290, req: 'banking', pre: 'market', y: [0, 0, 6], a: 1, gp: 1, civ: 'ottoman', rep: 'bank', d2: '오스만 전용(은행 대신). 금 +6, 쾌적도 +1.' },
    { k: 'thermal', n: '온천 목욕탕', d: 'ent', c: 360, req: 'c:naturalHist', pre: 'arena', a: 3, y: [0, 2], civ: 'hungary', rep: 'zoo', d2: '헝가리 전용(동물원 대신). 쾌적도 +3, 생산 +2.' },
    { k: 'marae', n: '마라에', d: 'th', c: 150, req: 'c:drama', y: [0, 0, 0, 0, 2, 2], gp: 1, gw: 'wri', gwn: 2, civ: 'maori', rep: 'amphi', d2: '마오리 전용(원형 극장 대신). 문화 +2 · 신앙 +2.' },
    { k: 'palgum', n: '팔굼', d: 'cc', c: 80, req: 'wheel', y: [1, 2], h: 1, river: 1, civ: 'babylon', rep: 'watermill', d2: '바빌론 전용(물레방아 대신). 식량 +1 · 생산 +2, 주거 +1.' },
    { k: 'tsikhe', n: '치헤', d: 'cc', c: 305, req: 'siegeTac', pre: 'wall2', wall: 3, y: [0, 0, 0, 0, 0, 3], tour: 3, civ: 'georgia', rep: 'wall3', d2: '조지아 전용(르네상스 성벽 대신). 성벽 체력 +100, 신앙 +3, 관광 +3.' },
    { k: 'prasat', n: '프라삿', d: 'hs', c: 120, req: 'c:theology', pre: 'shrine', y: [0, 0, 0, 0, 1, 4], gp: 1, civ: 'khmer', rep: 'temple', gw: 'rel', gwn: 1, d2: '크메르 전용(신전 대신). 신앙 +4 · 문화 +1, 성유물 칸 1.' },
    { k: 'sukiennice', n: '수키엔니체', d: 'com', c: 120, req: 'currency', y: [0, 2, 3], gp: 1, civ: 'poland', rep: 'market', d2: '폴란드 전용(시장 대신). 금 +3 · 생산 +2.' },
    { k: 'bibliotheque', n: '여왕의 서고', d: 'th', c: 290, req: 'c:humanism', pre: 'amphi', y: [0, 0, 0, 1, 3], gp: 1, gw: 'art', gwn: 3, civ: 'sweden', rep: 'museum', xg: 'mus', d2: '스웨덴 전용(미술관 대신). 문화 +3 · 과학 +1, 미술 걸작 칸 3.' },
  ];
  const BLDI = {}; BLD.forEach((b, i) => { BLDI[b.k] = i; });
  // 예배 건물(종교 신앙으로 정함)
  const WORSHIP = [
    { k: 'cathedral', n: '대성당', y: [0, 0, 0, 0, 1, 3], d: '신앙 +3 · 문화 +1, 종교 미술 칸.' },
    { k: 'mosque', n: '모스크', y: [0, 0, 0, 0, 0, 3], d: '신앙 +3, 선교사·사도 전파 +1.' },
    { k: 'pagoda', n: '파고다', y: [0, 0, 0, 0, 0, 3], h: 1, d: '신앙 +3, 주거 +1.' },
    { k: 'synagogue', n: '회당', y: [0, 0, 0, 0, 0, 5], d: '신앙 +5.' },
    { k: 'wat', n: '와트', y: [0, 0, 0, 2, 0, 3], d: '신앙 +3 · 과학 +2.' },
    { k: 'meeting', n: '집회소', y: [0, 2, 0, 0, 0, 3], d: '신앙 +3 · 생산 +2.' },
    { k: 'gurdwara', n: '구르드와라', y: [2, 0, 0, 0, 0, 3], d: '신앙 +3 · 식량 +2.' },
    { k: 'stupa', n: '스투파', y: [0, 0, 0, 0, 0, 3], a: 1, d: '신앙 +3, 쾌적도 +1.' },
  ];

  /* ======================= 프로젝트 ======================= */
  const PRJ = [
    { k: 'sat', n: '지구 인공위성 발사', c: 800, d: 'sp', req: 'rocketry', sv: 1, d2: '과학 승리 1단계. 지도 전체가 보여요.' },
    { k: 'moon', n: '달 착륙', c: 1000, d: 'sp', req: 'satellites', pre: 'sat', sv: 2, d2: '과학 승리 2단계. 과학 +10%.' },
    { k: 'mars', n: '화성 식민지 건설', c: 1200, d: 'sp', req: 'nanotech', pre: 'moon', sv: 3, d2: '과학 승리 3단계.' },
    { k: 'exo', n: '외계 행성 탐사대', c: 1400, d: 'sp', req: 'robotics', pre: 'mars', sv: 4, d2: '탐사선 출발! 목표 거리(광년)에 닿으면 과학 승리. 우주 기지를 빼앗기면 멈춰요.' },
    { k: 'laser', n: '지상 레이저 기지', c: 800, d: 'sp', req: 'lasers', pre: 'exo', rep: 1, d2: '탐사선 속도 +1광년/턴(여러 번).' },
    { k: 'campfest', n: '캠퍼스 연구 지원금', c: 120, d: 'cam', rep: 1, scaleEra: 1, gpp: 'sci', d2: '생산을 과학자 점수·과학으로 바꿔요.' },
    { k: 'theatfest', n: '극장가 공연', c: 120, d: 'th', rep: 1, scaleEra: 1, gpp: 'wri', d2: '생산을 문화·예술가 점수로 바꿔요.' },
    { k: 'comfest', n: '상업 투자', c: 120, d: 'com', rep: 1, scaleEra: 1, gpp: 'mer', d2: '생산을 금·상인 점수로 바꿔요.' },
    { k: 'indfest', n: '산업 구역 물류', c: 120, d: 'ind', rep: 1, scaleEra: 1, gpp: 'eng', d2: '생산을 기술자 점수로 바꿔요.' },
    { k: 'carbon', n: '탄소 포집', c: 800, d: 'ind', req: 'nanotech', rep: 1, d2: '대기 이산화탄소를 줄여요.' },
    { k: 'manhattan', n: '맨해튼 프로젝트', c: 1000, d: 'ind', req: 'fission', once: 1, d2: '핵무기를 만들 수 있게 돼요(나라마다 한 번).' },
    { k: 'nukeA', n: '원자폭탄 만들기', c: 600, d: 'enc', req: 'c:nuclearProg', pre2: 'manhattan', rep: 1, ura: 2, d2: '원자폭탄 1발(우라늄 2). 도시에서 12칸 안에 쏘면 반경 1칸이 쑥대밭이 돼요.' },
    { k: 'ivy', n: '아이비 작전', c: 1200, d: 'ind', req: 'fusion', once: 1, pre2: 'manhattan', d2: '열핵 폭탄을 만들 수 있게 돼요.' },
    { k: 'nukeT', n: '열핵 폭탄 만들기', c: 900, d: 'enc', req: 'c:nuclearProg', pre2: 'ivy', rep: 1, ura: 3, d2: '열핵 폭탄 1발(우라늄 3). 반경 2칸.' },
  ];
  const PRJI = {}; PRJ.forEach((p, i) => { PRJI[p.k] = i; });

  /* ======================= 유닛 ======================= */
  // cl: civ 민간, rel 종교, gp 위인, rec 정찰, mel 근접, rng 원거리, ac 대기병, lc 경기병, hc 중기병, sg 공성, sup 지원, nm 해상 근접, nr 해상 원거리, nrd 해상 습격
  const CLN = { air: '항공', civ: '민간', rel: '종교', gp: '위인', rec: '정찰', mel: '근접', rng: '원거리', ac: '대기병', lc: '경기병', hc: '중기병', sg: '공성', sup: '지원', nm: '해상 근접', nr: '해상 원거리', nrd: '해상 습격' };
  const UT = [
    { k: 'settler', n: '개척자', cl: 'civ', mv: 2, c: 80, d: '도시를 세워요(인구 −1). 만들 때마다 비용이 늘어요.' },
    { k: 'builder', n: '건설자', cl: 'civ', mv: 2, c: 50, ch: 3, d: '개선을 3번 지을 수 있어요(충전 3).' },
    { k: 'trader', n: '상인', cl: 'civ', mv: 1, c: 40, req: 'c:foreignTrade', d: '도시로 가서 교역로를 열어요. 길에 도로를 깔아요.' },
    { k: 'missionary', n: '선교사', cl: 'rel', mv: 4, c: 100, faith: 1, sp: 3, rs: 100, req: 'religion', d: '종교 전파 3번.' },
    { k: 'apostle', n: '사도', cl: 'rel', mv: 4, c: 200, faith: 1, sp: 3, rs: 110, req: 'religion', bld: 'temple', d: '종교 전파 3번, 신학 전투 가능.' },
    { k: 'inquisitor', n: '종교 재판관', cl: 'rel', mv: 4, c: 120, faith: 1, sp: 3, rs: 75, req: 'religion', bld: 'temple', d: '내 도시에서 다른 종교를 없애요(3번).' },
    { k: 'gp', n: '위인', cl: 'gp', mv: 4, c: 0, d: '위인. 능력을 써요.' },
    { k: 'mileng', n: '군사 공학자', cl: 'civ', mv: 2, c: 170, req: 'milEng', ch: 2, d: '도로(충전 안 씀)·철도(증기력 + 석탄 1, 충전 1)·요새(충전 1)를 지어요.' },
    { k: 'spy', n: '첩보원', cl: 'civ', mv: 3, c: 200, req: 'c:diploServ', d: '만들면 첩보 화면에 들어가요. 다른 나라 도시에서 정보 수집·자금·기술·방해·걸작·선거 임무, 내 도시에서 방첩.' },
    { k: 'archaeo', n: '고고학자', cl: 'civ', mv: 4, c: 400, req: 'c:naturalHist', ch: 3, d: '고대 유적에서 유물을 발굴해 고고학 박물관에 넣어요(3번). 도시에 빈 유물 칸이 있어야 만들어요.' },
    { k: 'scout', n: '정찰병', cl: 'rec', cs: 10, mv: 3, c: 30, era: 0, up: 'ranger', d: '빠른 탐험가.' },
    { k: 'ranger', n: '레인저', cl: 'rec', cs: 45, rs: 60, rng: 1, mv: 3, c: 380, req: 'rifling', era: 4, up: 'spec', d: '숲·언덕을 빠르게 다녀요.' },
    { k: 'spec', n: '특수 부대', cl: 'rec', cs: 75, rs: 85, rng: 1, mv: 3, c: 650, req: 'composites', era: 7, d: '정예 정찰.' },
    { k: 'warrior', n: '전사', cl: 'mel', cs: 20, mv: 2, c: 40, era: 0, up: 'swordsman' },
    { k: 'swordsman', n: '검사', cl: 'mel', cs: 35, mv: 2, c: 90, req: 'iron', res: 'iron', era: 1, up: 'manatarms' },
    { k: 'manatarms', n: '중보병', cl: 'mel', cs: 45, mv: 2, c: 160, req: 'apprentice', res: 'iron', era: 2, up: 'musket' },
    { k: 'musket', n: '머스킷병', cl: 'mel', cs: 55, mv: 2, c: 240, req: 'gunpowder', res: 'niter', era: 3, up: 'lineinf' },
    { k: 'lineinf', n: '전열 보병', cl: 'mel', cs: 65, mv: 2, c: 360, req: 'milScience', res: 'niter', era: 4, up: 'infantry' },
    { k: 'infantry', n: '보병', cl: 'mel', cs: 70, mv: 2, c: 430, req: 'replaceable', era: 5, up: 'mechinf' },
    { k: 'mechinf', n: '기계화 보병', cl: 'mel', cs: 85, mv: 3, c: 650, req: 'satellites', era: 7 },
    { k: 'slinger', n: '투석병', cl: 'rng', cs: 5, rs: 15, rng: 1, mv: 2, c: 35, era: 0, up: 'archer' },
    { k: 'archer', n: '궁수', cl: 'rng', cs: 15, rs: 25, rng: 2, mv: 2, c: 60, req: 'archery', era: 0, up: 'crossbow' },
    { k: 'crossbow', n: '석궁병', cl: 'rng', cs: 30, rs: 40, rng: 2, mv: 2, c: 180, req: 'machinery', era: 2, up: 'fieldcannon' },
    { k: 'fieldcannon', n: '야포', cl: 'rng', cs: 50, rs: 60, rng: 2, mv: 2, c: 330, req: 'ballistics', era: 4, up: 'machinegun' },
    { k: 'machinegun', n: '기관총', cl: 'rng', cs: 75, rs: 85, rng: 1, mv: 2, c: 540, req: 'advBallistics', era: 6 },
    { k: 'spearman', n: '창병', cl: 'ac', cs: 25, mv: 2, c: 65, req: 'bronze', era: 0, up: 'pikeman' },
    { k: 'pikeman', n: '장창병', cl: 'ac', cs: 41, mv: 2, c: 200, req: 'milTactics', era: 2, up: 'pikeshot' },
    { k: 'pikeshot', n: '장창·화승총병', cl: 'ac', cs: 55, mv: 2, c: 250, req: 'gunpowder', era: 3, up: 'atcrew' },
    { k: 'atcrew', n: '대전차병', cl: 'ac', cs: 70, mv: 2, c: 400, req: 'chemistry', era: 5, up: 'modat' },
    { k: 'modat', n: '현대 대전차병', cl: 'ac', cs: 80, mv: 2, c: 580, req: 'composites', era: 7 },
    { k: 'horseman', n: '기마병', cl: 'lc', cs: 36, mv: 4, c: 80, req: 'horseback', res: 'horses', era: 1, up: 'courser' },
    { k: 'courser', n: '경기병', cl: 'lc', cs: 44, mv: 5, c: 200, req: 'castles', res: 'horses', era: 2, up: 'cavalry' },
    { k: 'cavalry', n: '기병대', cl: 'lc', cs: 62, mv: 5, c: 330, req: 'milScience', res: 'horses', era: 4, up: 'heli' },
    { k: 'heli', n: '공격 헬기', cl: 'lc', cs: 82, mv: 4, c: 600, req: 'synthetic', res: 'alum', era: 6 },
    { k: 'hchariot', n: '중전차', cl: 'hc', cs: 28, mv: 2, c: 65, req: 'wheel', era: 0, up: 'knight' },
    { k: 'knight', n: '기사', cl: 'hc', cs: 48, mv: 4, c: 180, req: 'stirrups', res: 'iron', era: 2, up: 'cuirassier' },
    { k: 'cuirassier', n: '흉갑 기병', cl: 'hc', cs: 64, mv: 4, c: 330, req: 'ballistics', res: 'horses', era: 4, up: 'tank' },
    { k: 'tank', n: '전차', cl: 'hc', cs: 80, mv: 4, c: 480, req: 'combustion', res: 'oil', era: 5, up: 'modarmor' },
    { k: 'modarmor', n: '현대 기갑', cl: 'hc', cs: 90, mv: 4, c: 680, req: 'composites', res: 'uranium', era: 7 },
    { k: 'gdr', n: '거대 전투 로봇', cl: 'hc', cs: 130, mv: 4, c: 1500, req: 'fusion', res: 'uranium', era: 8, d: '모든 것을 짓밟는 최종 병기.' },
    { k: 'catapult', n: '투석기', cl: 'sg', cs: 23, rs: 35, rng: 2, mv: 2, c: 120, req: 'engineering', era: 1, up: 'trebuchet', d: '도시·성벽에 강해요(공성). 이동한 턴엔 못 쏴요.' },
    { k: 'trebuchet', n: '트레뷰셋', cl: 'sg', cs: 35, rs: 45, rng: 2, mv: 2, c: 220, req: 'milEng', era: 2, up: 'bombard' },
    { k: 'bombard', n: '봄바드', cl: 'sg', cs: 45, rs: 55, rng: 2, mv: 2, c: 280, req: 'metalCast', res: 'niter', era: 3, up: 'artillery' },
    { k: 'artillery', n: '야전포', cl: 'sg', cs: 60, rs: 70, rng: 2, mv: 2, c: 430, req: 'steel', era: 5, up: 'rocketart' },
    { k: 'rocketart', n: '로켓포', cl: 'sg', cs: 70, rs: 80, rng: 3, mv: 3, c: 680, req: 'guidance', res: 'alum', era: 7 },
    { k: 'ram', n: '공성 망치', cl: 'sup', cs: 0, mv: 2, c: 65, req: 'wheel', era: 0, aura: 'ram', d: '붙어 있는 근접 유닛이 고대·중세 성벽에 온전한 피해를 줘요.' },
    { k: 'tower', n: '공성탑', cl: 'sup', cs: 0, mv: 2, c: 100, req: 'construction', era: 1, aura: 'tower', d: '붙어 있는 근접 유닛이 성벽을 무시하고 도시를 쳐요(르네상스 성벽 제외).' },
    { k: 'medic', n: '의무병', cl: 'sup', cs: 0, mv: 2, c: 370, req: 'sanitation', era: 4, aura: 'medic', d: '붙어 있는 유닛 회복 +20.' },
    { k: 'galley', n: '갤리선', cl: 'nm', cs: 25, mv: 3, c: 65, req: 'sailing', era: 0, coast: 1, up: 'caravel' },
    { k: 'caravel', n: '카라벨', cl: 'nm', cs: 55, mv: 4, c: 240, req: 'cartography', era: 3, up: 'ironclad' },
    { k: 'ironclad', n: '철갑선', cl: 'nm', cs: 60, mv: 5, c: 380, req: 'steam', res: 'coal', era: 4, up: 'destroyer' },
    { k: 'destroyer', n: '구축함', cl: 'nm', cs: 70, mv: 6, c: 430, req: 'combustion', era: 5 },
    { k: 'quad', n: '4단 노선', cl: 'nr', cs: 20, rs: 25, rng: 1, mv: 3, c: 120, req: 'shipbuilding', era: 1, coast: 1, up: 'frigate' },
    { k: 'frigate', n: '프리깃', cl: 'nr', cs: 45, rs: 55, rng: 2, mv: 4, c: 280, req: 'squareRig', res: 'niter', era: 3, up: 'battleship' },
    { k: 'battleship', n: '전함', cl: 'nr', cs: 60, rs: 70, rng: 3, mv: 5, c: 430, req: 'steel', res: 'coal', era: 5, up: 'missilecr' },
    { k: 'missilecr', n: '미사일 순양함', cl: 'nr', cs: 75, rs: 85, rng: 3, mv: 5, c: 680, req: 'lasers', era: 7 },
    { k: 'aagun', n: '대공포', cl: 'ac', cs: 50, aa: 85, mv: 2, c: 300, req: 'advFlight', era: 6, up: 'sam', d: '대공 85: 붙은 칸을 치는 항공기에 큰 피해·요격.' },
    { k: 'sam', n: '이동 대공', cl: 'ac', cs: 65, aa: 100, mv: 3, c: 480, req: 'guidance', era: 7, d: '대공 100, 빠른 방공 차량.' },
    { k: 'nsub', n: '핵잠수함', cl: 'nrd', cs: 70, rs: 80, rng: 2, mv: 4, c: 600, req: 'fission', era: 6, nuk: 1, d: '핵무기를 바다에서 쏠 수 있어요(12칸).' },
    { k: 'privateer', n: '사략선', cl: 'nrd', cs: 40, rs: 50, rng: 2, mv: 4, c: 280, req: 'c:mercantilism', era: 3, up: 'submarine' },
    { k: 'submarine', n: '잠수함', cl: 'nrd', cs: 65, rs: 75, rng: 2, mv: 3, c: 480, req: 'electricity', era: 5 },
    // 항공(도시·비행장에 머물러요: 작전 범위 안을 공격·정찰·재배치)
    { k: 'recon', n: '정찰기', cl: 'air', cs: 20, rng: 12, mv: 1, c: 300, req: 'flight', era: 5, rec: 1, d: '작전 범위 안 칸 둘레 3칸을 정찰해요. 공격은 못 해요.' },
    { k: 'biplane', n: '복엽기', cl: 'air', cs: 80, rs: 60, rng: 6, mv: 1, c: 430, req: 'flight', era: 5, up: 'fighter', ftr: 1, d: '전투기. 경계 비행으로 적 항공기를 막고 지상 유닛을 공격해요.' },
    { k: 'fighter', n: '전투기', cl: 'air', cs: 100, rs: 80, rng: 8, mv: 1, c: 520, req: 'advFlight', res: 'alum', era: 6, up: 'jetfighter', ftr: 1, d: '경계 비행·지상 공격.' },
    { k: 'jetfighter', n: '제트 전투기', cl: 'air', cs: 110, rs: 90, rng: 10, mv: 1, c: 650, req: 'lasers', res: 'alum', era: 7, ftr: 1, d: '빠르고 강한 전투기.' },
    { k: 'bomber', n: '폭격기', cl: 'air', cs: 65, rs: 110, rng: 10, mv: 1, c: 560, req: 'advFlight', res: 'alum', era: 6, up: 'jetbomber', bmb: 1, d: '도시·성벽·구역·개선에 강하고 약탈해요. 유닛 상대는 −10.' },
    { k: 'jetbomber', n: '제트 폭격기', cl: 'air', cs: 75, rs: 120, rng: 15, mv: 1, c: 700, req: 'stealth', res: 'alum', era: 7, bmb: 1, d: '스텔스 폭격기.' },
    // 고유 유닛 (rep: 대신하는 유닛)
    { k: 'roughrider', n: '러프 라이더', cl: 'lc', cs: 67, mv: 5, c: 330, req: 'rifling', res: 'horses', era: 4, civ: 'america', rep: 'cavalry', up: 'heli', d: '미국. 언덕에서 +10, 처치하면 문화.' },
    { k: 'mamluk', n: '맘루크', cl: 'hc', cs: 48, mv: 4, c: 180, req: 'stirrups', res: 'iron', era: 2, civ: 'arabia', rep: 'knight', up: 'cuirassier', heal: 1, d: '아라비아. 매 턴 회복해요.' },
    { k: 'minas', n: '미나스 제라이스', cl: 'nr', cs: 70, rs: 80, rng: 3, mv: 5, c: 430, req: 'steel', res: 'coal', era: 5, civ: 'brazil', rep: 'battleship', up: 'missilecr', d: '브라질 전함.' },
    { k: 'tiger', n: '호준포', cl: 'rng', cs: 30, rs: 50, rng: 1, mv: 2, c: 160, req: 'machinery', era: 2, civ: 'china', rep: 'crossbow', up: 'fieldcannon', d: '중국. 사거리 1, 강한 원거리.' },
    { k: 'maryannu', n: '마랴누 전차 궁수', cl: 'rng', cs: 25, rs: 35, rng: 1, mv: 4, c: 120, req: 'wheel', era: 0, civ: 'egypt', rep: 'hchariot', up: 'crossbow', d: '이집트. 빠른 원거리 전차.' },
    { k: 'redcoat', n: '레드코트', cl: 'mel', cs: 70, mv: 2, c: 360, req: 'milScience', res: 'niter', era: 4, civ: 'england', rep: 'lineinf', up: 'infantry', d: '영국. 다른 대륙에서 강해요.' },
    { k: 'garde', n: '가르드 앵페리알', cl: 'mel', cs: 70, mv: 2, c: 360, req: 'milScience', res: 'niter', era: 4, civ: 'france', rep: 'lineinf', up: 'infantry', d: '프랑스. 고향 대륙에서 강해요.' },
    { k: 'uboat', n: 'U-보트', cl: 'nrd', cs: 65, rs: 80, rng: 2, mv: 4, c: 430, req: 'electricity', era: 5, civ: 'germany', rep: 'submarine', d: '독일 잠수함.' },
    { k: 'hoplite', n: '호플리테스', cl: 'ac', cs: 28, mv: 2, c: 65, req: 'bronze', era: 0, civ: 'greece', rep: 'spearman', up: 'pikeman', d: '그리스. 호플리테스끼리 붙으면 +10.' },
    { k: 'varu', n: '바루', cl: 'hc', cs: 40, mv: 2, c: 120, req: 'horseback', era: 1, civ: 'india', rep: 'horseman', up: 'knight', d: '인도 전투 코끼리. 붙은 적 −5.' },
    { k: 'samurai', n: '사무라이', cl: 'mel', cs: 48, mv: 2, c: 160, req: 'c:feudalism', res: 'iron', era: 2, civ: 'japan', rep: 'manatarms', up: 'musket', nodmg: 1, d: '일본. 다쳐도 힘이 줄지 않아요.' },
    { k: 'ngao', n: '은가오 음베바', cl: 'mel', cs: 38, mv: 2, c: 90, req: 'iron', era: 1, civ: 'kongo', rep: 'swordsman', up: 'manatarms', d: '콩고. 철이 필요 없고 숲·열대우림에서 강해요.' },
    { k: 'berserker', n: '버서커', cl: 'mel', cs: 50, mv: 3, c: 160, req: 'c:feudalism', era: 2, civ: 'norway', rep: 'manatarms', up: 'musket', d: '노르웨이. 공격 +7, 수비 −7.' },
    { k: 'legion', n: '레기온', cl: 'mel', cs: 40, mv: 2, c: 110, req: 'iron', res: 'iron', era: 1, civ: 'rome', rep: 'swordsman', up: 'manatarms', d: '로마. 강한 검사.' },
    { k: 'cossack', n: '코사크', cl: 'lc', cs: 67, mv: 5, c: 340, req: 'milScience', res: 'horses', era: 4, civ: 'russia', rep: 'cavalry', up: 'heli', d: '러시아. 내 영토 근처에서 +5.' },
    { k: 'saka', n: '사카 기마 궁수', cl: 'rng', cs: 20, rs: 25, rng: 1, mv: 4, c: 70, req: 'archery', era: 0, civ: 'scythia', rep: 'archer', up: 'crossbow', d: '스키타이. 빠른 기마 궁수.' },
    { k: 'conquist', n: '콘키스타도르', cl: 'mel', cs: 58, mv: 2, c: 250, req: 'gunpowder', res: 'niter', era: 3, civ: 'spain', rep: 'musket', up: 'lineinf', d: '스페인. 강한 머스킷병.' },
    { k: 'warcart', n: '전차(수메르)', cl: 'hc', cs: 30, mv: 3, c: 55, era: 0, civ: 'sumeria', rep: 'hchariot', up: 'knight', d: '수메르. 처음부터 만들 수 있어요.' },
    { k: 'eagle', n: '독수리 전사', cl: 'mel', cs: 28, mv: 2, c: 65, era: 0, civ: 'aztec', rep: 'warrior', up: 'swordsman', d: '아즈텍. 강한 고대 근접.' },
    { k: 'hwacha', n: '화차', cl: 'rng', cs: 45, rs: 60, rng: 1, mv: 2, c: 250, req: 'gunpowder', era: 3, civ: 'korea', rep: 'fieldcannon', up: 'machinegun', d: '한국. 이른 화약 원거리.' },
    { k: 'keshig', n: '케식', cl: 'rng', cs: 35, rs: 45, rng: 2, mv: 4, c: 180, req: 'stirrups', res: 'horses', era: 2, civ: 'mongolia', rep: 'courser', up: 'fieldcannon', d: '몽골 기마 궁수.' },
    { k: 'impi', n: '임피', cl: 'ac', cs: 38, mv: 3, c: 140, req: 'milTactics', era: 2, civ: 'zulu', rep: 'pikeman', up: 'pikeshot', d: '줄루. 싸고 빠른 대기병.' },
    { k: 'zeven', n: '데 제번 프로빈시엔', cl: 'nr', cs: 50, rs: 60, rng: 2, mv: 4, c: 280, req: 'squareRig', res: 'niter', era: 3, civ: 'netherlands', rep: 'frigate', up: 'battleship', d: '네덜란드 프리깃.' },
    { k: 'mountie', n: '마운티', cl: 'lc', cs: 65, mv: 5, c: 340, req: 'milScience', res: 'horses', era: 4, civ: 'canada', rep: 'cavalry', up: 'heli', d: '캐나다 기마 경찰.' },
    { k: 'janissary', n: '예니체리', cl: 'mel', cs: 60, mv: 2, c: 200, req: 'gunpowder', res: 'niter', era: 3, civ: 'ottoman', rep: 'musket', up: 'lineinf', d: '오스만. 싸고 강한 머스킷병.' },
    { k: 'mandekalu', n: '만데칼루 기병', cl: 'hc', cs: 52, mv: 4, c: 200, req: 'stirrups', res: 'iron', era: 2, civ: 'mali', rep: 'knight', up: 'cuirassier', d: '말리 기사.' },
    { k: 'carolean', n: '카롤리너', cl: 'ac', cs: 60, mv: 3, c: 260, req: 'gunpowder', res: 'niter', era: 3, civ: 'sweden', rep: 'pikeshot', up: 'atcrew', d: '스웨덴. 빠른 장창·화승총병.' },
    { k: 'blackarmy', n: '흑군', cl: 'lc', cs: 52, mv: 5, c: 220, req: 'castles', res: 'horses', era: 2, civ: 'hungary', rep: 'courser', up: 'cavalry', d: '헝가리 경기병.' },
    { k: 'warakaq', n: '와라크아크', cl: 'rng', cs: 20, rs: 30, rng: 2, mv: 2, c: 70, req: 'archery', era: 0, civ: 'inca', rep: 'archer', up: 'crossbow', d: '잉카 투석 전사.' },
    { k: 'toa', n: '토아', cl: 'mel', cs: 36, mv: 2, c: 85, req: 'bronze', era: 1, civ: 'maori', rep: 'swordsman', up: 'manatarms', d: '마오리. 철이 필요 없어요.' },
    { k: 'bireme', n: '비레메', cl: 'nm', cs: 30, mv: 3, c: 65, req: 'sailing', era: 0, coast: 1, civ: 'phoenicia', rep: 'galley', up: 'caravel', d: '페니키아 갤리선.' },
    { k: 'immortal', n: '불사 부대', cl: 'mel', cs: 35, rs: 25, rng: 2, mv: 2, c: 100, req: 'iron', era: 1, civ: 'persia', rep: 'swordsman', up: 'manatarms', d: '페르시아. 근접·원거리 모두 가능.' },
    { k: 'digger', n: '디거', cl: 'mel', cs: 72, mv: 2, c: 430, req: 'replaceable', era: 5, civ: 'australia', rep: 'infantry', up: 'mechinf', d: '오스트레일리아. 해안 칸에서 +10.' },
    { k: 'sabum', n: '사붐 키비툼', cl: 'mel', cs: 17, mv: 3, c: 35, era: 0, civ: 'babylon', rep: 'warrior', up: 'swordsman', d: '바빌론. 빠르고 기병 상대 +17.' },
    { k: 'tagma', n: '타그마', cl: 'hc', cs: 50, mv: 4, c: 190, req: 'stirrups', res: 'iron', era: 2, civ: 'byzantium', rep: 'knight', up: 'cuirassier', d: '비잔티움 중기병. 붙은 아군 +4.' },
    { k: 'okihtcitaw', n: '오키치타우', cl: 'rec', cs: 20, mv: 3, c: 40, era: 0, civ: 'cree', rep: 'scout', up: 'ranger', fp: 1, d: '크리 정찰병. 승급 하나를 갖고 나와요.' },
    { k: 'oromo', n: '오로모 기병', cl: 'lc', cs: 48, mv: 5, c: 200, req: 'castles', res: 'horses', era: 2, civ: 'ethiopia', rep: 'courser', up: 'cavalry', d: '에티오피아. 언덕 이동이 느려지지 않아요.' },
    { k: 'gaesatae', n: '가이사타이', cl: 'mel', cs: 20, mv: 2, c: 40, era: 0, civ: 'gaul', rep: 'warrior', up: 'swordsman', d: '갈리아. 더 강한 유닛 상대 +10.' },
    { k: 'khevsur', n: '헤브수르', cl: 'mel', cs: 50, mv: 2, c: 160, req: 'apprentice', res: 'iron', era: 2, civ: 'georgia', rep: 'manatarms', up: 'musket', d: '조지아. 언덕에서 +7.' },
    { k: 'llanero', n: '야네로', cl: 'lc', cs: 62, mv: 5, c: 330, req: 'milScience', res: 'horses', era: 4, civ: 'gcolombia', rep: 'cavalry', up: 'heli', d: '그란 콜롬비아. 옆의 야네로마다 +2.' },
    { k: 'jong', n: '종', cl: 'nr', cs: 45, rs: 55, rng: 2, mv: 5, c: 280, req: 'squareRig', res: 'niter', era: 3, civ: 'indonesia', rep: 'frigate', up: 'battleship', d: '인도네시아 프리깃. 빨라요.' },
    { k: 'domrey', n: '돔레이', cl: 'sg', cs: 40, rs: 50, rng: 2, mv: 2, c: 220, req: 'milEng', era: 2, civ: 'khmer', rep: 'trebuchet', up: 'bombard', mvfire: 1, d: '크메르 코끼리. 움직이고도 쏠 수 있어요.' },
    { k: 'hypaspist', n: '히파스피스테스', cl: 'mel', cs: 38, mv: 2, c: 100, req: 'iron', res: 'iron', era: 1, civ: 'macedon', rep: 'swordsman', up: 'manatarms', d: '마케도니아. 도시 공격 +5.' },
    { k: 'malon', n: '말론 습격대', cl: 'lc', cs: 46, mv: 5, c: 200, req: 'castles', res: 'horses', era: 2, civ: 'mapuche', rep: 'courser', up: 'cavalry', d: '마푸체. 적 영토에서 +5.' },
    { k: 'hulche', n: '훌체', cl: 'rng', cs: 15, rs: 28, rng: 2, mv: 2, c: 60, req: 'archery', era: 0, civ: 'maya', rep: 'archer', up: 'crossbow', d: '마야 궁수. 다친 적 상대 +5.' },
    { k: 'pitati', n: '피타티 궁수', cl: 'rng', cs: 17, rs: 30, rng: 2, mv: 3, c: 55, req: 'archery', era: 0, civ: 'nubia', rep: 'archer', up: 'crossbow', d: '누비아. 빠르고 강한 궁수.' },
    { k: 'hussar', n: '날개 기병', cl: 'hc', cs: 65, mv: 4, c: 330, req: 'ballistics', res: 'horses', era: 4, civ: 'poland', rep: 'cuirassier', up: 'tank', d: '폴란드 중기병. 공격 +3.' },
    { k: 'nau', n: '나우', cl: 'nm', cs: 55, mv: 5, c: 240, req: 'cartography', era: 3, civ: 'portugal', rep: 'caravel', up: 'ironclad', fp: 1, d: '포르투갈. 승급 하나를 갖고 나와요.' },
    { k: 'highlander', n: '하일랜더', cl: 'rec', cs: 50, rs: 65, rng: 1, mv: 3, c: 380, req: 'rifling', era: 4, civ: 'scotland', rep: 'ranger', up: 'spec', d: '스코틀랜드. 언덕·숲에서 +5.' },
    { k: 'voi', n: '보이 찌엔', cl: 'rng', cs: 65, rs: 75, rng: 2, mv: 3, c: 540, req: 'advBallistics', era: 6, civ: 'vietnam', rep: 'machinegun', d: '베트남. 사거리 2, 빨라요.' },
  ];
  const UTI = {}; UT.forEach((u, i) => { UTI[u.k] = i; });
  const isMil = (t) => { const c = UT[t].cl; return c !== 'civ' && c !== 'rel' && c !== 'gp' && c !== 'sup'; };
  const isAir = (t) => UT[t].cl === 'air';
  const isGround = (t) => isMil(t) && UT[t].cl !== 'air';
  const isNaval = (t) => { const c = UT[t].cl; return c === 'nm' || c === 'nr' || c === 'nrd'; };
  const isCiv = (t) => { const c = UT[t].cl; return c === 'civ' || c === 'rel' || c === 'gp' || c === 'sup'; };
  const isRanged = (t) => !!UT[t].rs && UT[t].rng > 0;

  /* ======================= 승급 ======================= */
  const PROMO = {
    mel: [['전투 훈련', 'csAtt', 5, '공격 +5'], ['돌격', 'csDef', 5, '수비 +5'], ['수륙 양용', 'amph', 7, '숲·언덕에서 +7'], ['측면 공격', 'flank', 2, '측면 보너스 2배'], ['정예', 'cs', 7, '전투력 +7']],
    rng: [['조준', 'csAtt', 5, '공격 +5'], ['흉벽', 'csDef', 7, '수비 +7'], ['교전', 'rng', 1, '사거리 +1'], ['진압', 'csAtt', 7, '공격 +7 더'], ['정예', 'cs', 7, '전투력 +7']],
    ac: [['방진', 'csDef', 7, '수비 +7'], ['밀집', 'csAtt', 5, '공격 +5'], ['저지', 'zoc', 1, '적 기병에 +10'], ['응징', 'cs', 5, '전투력 +5'], ['정예', 'cs', 7, '전투력 +7']],
    lc: [['돌파', 'mv', 1, '이동 +1'], ['약탈자', 'csAtt', 5, '공격 +5'], ['추격', 'csAtt', 7, '공격 +7 더'], ['위장', 'csDef', 5, '수비 +5'], ['정예', 'cs', 7, '전투력 +7']],
    hc: [['돌격', 'csAtt', 5, '공격 +5'], ['장갑', 'csDef', 7, '수비 +7'], ['돌파', 'mv', 1, '이동 +1'], ['압도', 'csAtt', 7, '공격 +7 더'], ['정예', 'cs', 7, '전투력 +7']],
    sg: [['포격', 'csAtt', 7, '공격 +7'], ['정밀', 'rng', 1, '사거리 +1'], ['이동 사격', 'mvfire', 1, '이동하고 쏠 수 있어요'], ['파괴', 'csAtt', 7, '공격 +7 더'], ['정예', 'cs', 7, '전투력 +7']],
    rec: [['은신', 'csDef', 5, '수비 +5'], ['원정', 'mv', 1, '이동 +1'], ['경계', 'sight', 1, '시야 +1'], ['게릴라', 'csAtt', 7, '공격 +7'], ['정예', 'cs', 7, '전투력 +7']],
    nm: [['포위', 'csAtt', 5, '공격 +5'], ['장갑판', 'csDef', 7, '수비 +7'], ['순항', 'mv', 1, '이동 +1'], ['약탈', 'csAtt', 7, '공격 +7 더'], ['정예', 'cs', 7, '전투력 +7']],
    nr: [['함포', 'csAtt', 5, '공격 +5'], ['선회', 'csDef', 7, '수비 +7'], ['사거리', 'rng', 1, '사거리 +1'], ['순항', 'mv', 1, '이동 +1'], ['정예', 'cs', 7, '전투력 +7']],
    nrd: [['기습', 'csAtt', 7, '공격 +7'], ['잠항', 'csDef', 5, '수비 +5'], ['순항', 'mv', 1, '이동 +1'], ['약탈', 'csAtt', 5, '공격 +5 더'], ['정예', 'cs', 7, '전투력 +7']],
    air: [['기총 사격', 'csAtt', 5, '공격 +5'], ['공중전', 'cs', 5, '공중전·전투력 +5'], ['장거리', 'rng', 2, '작전 범위 +2'], ['정밀 폭격', 'csAtt', 7, '공격 +7 더'], ['정예', 'cs', 7, '전투력 +7']],
  };
  const XPN = [15, 35, 60, 90, 125];

  /* ======================= 시대 ======================= */
  const ERA = ['고대', '고전', '중세', '르네상스', '산업', '현대', '원자력', '정보', '미래'];
  const ERA_TC = [40, 90, 180, 280, 400, 520, 650, 780, 900];   // 기술 기본 비용
  const ERA_CC = [35, 80, 170, 270, 390, 510, 640, 770, 880];   // 사회 제도 기본 비용

  /* ======================= 기술 트리 ======================= */
  // b: 유레카 조건, bt: 설명
  const TECH = [
    ['pottery', '도자기', 0, [], '', ''],
    ['animal', '목축', 0, [], '', ''],
    ['mining', '채광', 0, [], '', ''],
    ['sailing', '항해술', 0, [], '', ''],
    ['astrology', '점성술', 0, [], 'seenw:1', '자연경관을 발견하기'],
    ['irrigation', '관개', 0, ['pottery'], 'imp:farm:1', '농장 짓기'],
    ['writing', '문자', 0, ['pottery'], 'met:1', '다른 문명 만나기'],
    ['archery', '궁술', 0, ['animal'], 'k:1', '적 유닛 처치하기'],
    ['masonry', '석공술', 0, ['mining'], '', ''],
    ['bronze', '청동기', 0, ['mining'], 'camp:1', '야만인 야영지 없애기'],
    ['wheel', '바퀴', 0, ['mining'], 'imp:mine:1', '광산 짓기'],
    ['celestial', '천문 항법', 1, ['sailing', 'astrology'], 'imp:fish:2', '어선 2개 짓기'],
    ['currency', '화폐', 1, ['writing'], 'tr:1', '교역로 열기'],
    ['horseback', '기마술', 1, ['archery'], 'imp:pasture:1', '목장 짓기'],
    ['iron', '철기', 1, ['bronze'], 'res:iron', '철 확보하기'],
    ['shipbuilding', '조선술', 1, ['sailing'], 'u:galley:2', '갤리선 2척 갖기'],
    ['math', '수학', 1, ['currency'], 'd:3', '특수지구 3개 짓기'],
    ['construction', '건설', 1, ['masonry', 'horseback'], 'b:watermill:1', '물레방아 짓기'],
    ['engineering', '공학', 1, ['wheel'], 'b:wall1:1', '고대 성벽 짓기'],
    ['milTactics', '군사 전술', 2, ['math'], 'k:5', '적 유닛 5기 처치'],
    ['apprentice', '도제', 2, ['currency', 'mining'], 'imp:mine:3', '광산 3개 짓기'],
    ['machinery', '기계', 2, ['iron', 'engineering'], 'u:archer:3', '궁수 3기 갖기'],
    ['education', '교육', 2, ['apprentice', 'math'], 'gp:sci', '위대한 과학자 영입'],
    ['stirrups', '등자', 2, ['horseback'], 'civ:feudalism', '봉건제 사회 제도'],
    ['milEng', '군사 공학', 2, ['construction'], 'd:aq:1', '송수로 짓기'],
    ['castles', '성', 2, ['construction'], 'slots:5', '정책 슬롯 5개인 정부'],
    ['cartography', '지도 제작', 3, ['shipbuilding'], 'd:hb:2', '항만 2개 짓기'],
    ['massProd', '대량 생산', 3, ['education', 'shipbuilding'], 'imp:lumber:1', '제재소 짓기'],
    ['banking', '은행업', 3, ['education', 'stirrups'], 'civ:guilds', '길드 사회 제도'],
    ['gunpowder', '화약', 3, ['apprentice', 'stirrups', 'milEng'], 'b:armory:1', '무기고 짓기'],
    ['printing', '인쇄술', 3, ['machinery'], 'b:university:2', '대학교 2개 짓기'],
    ['squareRig', '횡범 범장', 3, ['cartography'], 'k:8', '적 유닛 8기 처치'],
    ['astronomy', '천문학', 3, ['education'], 'b:university:1', '대학교 짓기'],
    ['metalCast', '금속 주조', 3, ['gunpowder'], 'b:armory:2', '무기고 2개 짓기'],
    ['siegeTac', '공성 전술', 3, ['castles', 'metalCast'], 'u:bombard:2', '봄바드 2기 갖기'],
    ['industrial', '산업화', 4, ['massProd', 'squareRig'], 'b:workshop:3', '작업장 3개 짓기'],
    ['sciTheory', '과학 이론', 4, ['astronomy', 'banking'], 'civ:enlight', '계몽주의 사회 제도'],
    ['ballistics', '탄도학', 4, ['metalCast'], 'u:fieldcannon:2', '야포 2기 갖기'],
    ['milScience', '군사 과학', 4, ['printing', 'siegeTac'], 'k:10', '적 유닛 10기 처치'],
    ['steam', '증기력', 4, ['industrial'], 'b:shipyard:2', '조선소 2개 짓기'],
    ['sanitation', '위생', 4, ['sciTheory'], 'd:nb:1', '주거 지구 짓기'],
    ['economics', '경제학', 4, ['banking', 'sciTheory'], 'b:bank:2', '은행 2개 짓기'],
    ['rifling', '강선', 4, ['ballistics', 'milScience'], 'res:niter', '초석 확보하기'],
    ['flight', '비행', 5, ['industrial', 'sciTheory'], 'w:3', '불가사의 3개 짓기'],
    ['replaceable', '교체 가능 부품', 5, ['economics'], 'mil:8', '군사 유닛 8기 갖기'],
    ['steel', '강철', 5, ['rifling'], 'b:milacad:1', '군사 학교 짓기'],
    ['electricity', '전기', 5, ['steam'], 'b:seaport:1', '항구 짓기'],
    ['radio', '라디오', 5, ['flight', 'steam'], 'civ:conservation', '보존 사회 제도'],
    ['chemistry', '화학', 5, ['sanitation'], 'b:university:4', '대학교 4개 짓기'],
    ['combustion', '연소', 5, ['steel', 'rifling'], 'gpn:6', '위인 6명 영입'],
    ['refining', '정제', 5, ['rifling'], 'u:ironclad:2', '철갑선 2척 갖기'],
    ['advFlight', '고등 비행', 6, ['radio'], 'b:factory:3', '공장 3개 짓기'],
    ['rocketry', '로켓 공학', 6, ['radio', 'chemistry'], 'b:researchlab:1', '연구소 짓기'],
    ['advBallistics', '고등 탄도학', 6, ['replaceable', 'steel'], 'pwr:2', '발전소 2개 짓기'],
    ['combinedArms', '제병 협동', 6, ['steel', 'combustion'], 'd:enc:3', '주둔지 3개 짓기'],
    ['plastics', '플라스틱', 6, ['combustion'], 'imp:oilwell:1', '유정 짓기'],
    ['computers', '컴퓨터', 6, ['electricity', 'radio'], 'slots:8', '정책 슬롯 8개인 정부'],
    ['fission', '핵분열', 6, ['combinedArms', 'advBallistics'], 'b:researchlab:2', '연구소 2개 짓기'],
    ['synthetic', '합성 소재', 6, ['plastics'], 'b:factory:5', '공장 5개 짓기'],
    ['telecom', '원거리 통신', 7, ['computers'], 'b:broadcast:2', '방송 센터 2개 짓기'],
    ['satellites', '위성', 7, ['advFlight', 'rocketry'], 'd:sp:1', '우주 기지 짓기'],
    ['guidance', '유도 체계', 7, ['rocketry', 'advBallistics'], 'k:20', '적 유닛 20기 처치'],
    ['lasers', '레이저', 7, ['fission'], 'b:researchlab:3', '연구소 3개 짓기'],
    ['composites', '복합 소재', 7, ['synthetic'], 'u:tank:3', '전차 3대 갖기'],
    ['stealth', '스텔스 기술', 7, ['satellites'], 'k:25', '적 유닛 25기 처치'],
    ['robotics', '로봇 공학', 7, ['computers'], 'civ:globalization', '세계화 사회 제도'],
    ['nanotech', '나노 기술', 7, ['composites'], 'res:alum', '알루미늄 확보하기'],
    ['fusion', '핵융합', 8, ['lasers'], 'gp:sci', '위대한 과학자 영입'],
    ['future', '미래 기술', 8, ['robotics', 'nanotech', 'fusion', 'stealth', 'telecom', 'guidance'], '', ''],
  ].map((a) => ({ k: a[0], n: a[1], e: a[2], pre: a[3], b: a[4], bt: a[5] }));
  const TECHI = {}; TECH.forEach((t, i) => { TECHI[t.k] = i; });

  /* ======================= 사회 제도 트리 ======================= */
  const CIVIC = [
    ['code', '법전', 0, [], '', ''],
    ['craftsmanship', '장인 정신', 0, ['code'], 'impn:3', '개선 3개 짓기'],
    ['foreignTrade', '대외 무역', 0, ['code'], 'cont:2', '두 번째 대륙 발견'],
    ['milTrad', '군사 전통', 0, ['craftsmanship'], 'camp:1', '야만인 야영지 없애기'],
    ['stateWork', '국가 노동력', 0, ['craftsmanship'], 'd:1', '특수지구 짓기'],
    ['earlyEmpire', '초기 제국', 0, ['foreignTrade'], 'tpop:6', '전체 인구 6'],
    ['mysticism', '신비주의', 0, ['foreignTrade'], 'pan', '만신전 세우기'],
    ['games', '경기와 오락', 1, ['stateWork'], 'tech:construction', '건설 기술 연구'],
    ['polPhil', '정치 철학', 1, ['stateWork', 'earlyEmpire'], 'mcs:3', '도시국가 3곳 만나기'],
    ['drama', '연극과 시', 1, ['earlyEmpire'], 'w:1', '불가사의 짓기'],
    ['milTrain', '군사 훈련', 1, ['milTrad', 'games'], 'd:enc:1', '주둔지 짓기'],
    ['defTac', '방어 전술', 1, ['games', 'polPhil'], 'warv:1', '전쟁 선포를 받기'],
    ['recHist', '기록된 역사', 1, ['polPhil', 'drama'], 'd:cam:2', '캠퍼스 2개 짓기'],
    ['theology', '신학', 1, ['drama', 'mysticism'], 'rel', '종교 창시'],
    ['navalTrad', '해군 전통', 2, ['defTac'], 'ucls:nr:1', '해상 원거리 유닛 갖기'],
    ['feudalism', '봉건제', 2, ['defTac'], 'imp:farm:6', '농장 6개 짓기'],
    ['civilServ', '행정', 2, ['defTac', 'recHist'], 'pop:10', '인구 10인 도시'],
    ['divineRight', '왕권신수설', 2, ['civilServ', 'theology'], 'b:temple:2', '신전 2개 짓기'],
    ['mercenaries', '용병', 2, ['milTrain', 'feudalism'], 'mil:8', '군사 유닛 8기 갖기'],
    ['medFaires', '중세 시장', 2, ['feudalism'], 'tr:3', '교역로 3개'],
    ['guilds', '길드', 2, ['feudalism', 'civilServ'], 'b:market:2', '시장 2개 짓기'],
    ['exploration', '탐험', 3, ['mercenaries', 'medFaires'], 'u:caravel:2', '카라벨 2척 갖기'],
    ['humanism', '인문주의', 3, ['medFaires', 'guilds'], 'gp:art', '위대한 예술가 영입'],
    ['diploServ', '외교 업무', 3, ['guilds'], 'ally:1', '동맹 맺기'],
    ['reformed', '개혁 교회', 3, ['divineRight'], 'relc:6', '내 종교를 믿는 도시 6곳'],
    ['mercantilism', '중상주의', 3, ['humanism'], 'gp:mer', '위대한 상인 영입'],
    ['enlight', '계몽주의', 3, ['diploServ'], 'gpn:3', '위인 3명 영입'],
    ['colonialism', '식민주의', 4, ['mercantilism'], 'tech:astronomy', '천문학 연구'],
    ['civilEng', '토목 공학', 4, ['mercantilism'], 'd:7', '특수지구 7개 짓기'],
    ['nationalism', '민족주의', 4, ['enlight'], 'k:12', '적 유닛 12기 처치'],
    ['opera', '오페라와 발레', 4, ['enlight'], 'b:museum:1', '미술관 짓기'],
    ['naturalHist', '자연사', 4, ['colonialism'], 'b:museum:2', '미술관 2개 짓기'],
    ['urbanization', '도시화', 4, ['civilEng', 'nationalism'], 'pop:15', '인구 15인 도시'],
    ['scorched', '초토화', 4, ['nationalism'], 'u:fieldcannon:2', '야포 2기 갖기'],
    ['conservation', '보존', 5, ['naturalHist', 'urbanization'], 'd:nb:1', '주거 지구 짓기'],
    ['capitalism', '자본주의', 5, ['urbanization'], 'b:stock:2', '증권 거래소 2개 짓기'],
    ['massMedia', '대중 매체', 5, ['urbanization'], 'tech:radio', '라디오 연구'],
    ['mobilization', '동원', 5, ['urbanization'], 'mil:15', '군사 유닛 15기 갖기'],
    ['ideology', '이데올로기', 5, ['massMedia', 'mobilization'], '', ''],
    ['suffrage', '참정권', 5, ['ideology'], 'b:sewer:3', '하수도 3개 짓기'],
    ['totalit', '전체주의', 5, ['ideology'], 'b:milacad:2', '군사 학교 2개 짓기'],
    ['classStr', '계급 투쟁', 5, ['ideology'], 'b:factory:3', '공장 3개 짓기'],
    ['nuclearProg', '핵 개발', 6, ['ideology'], 'b:researchlab:1', '연구소 짓기'],
    ['culturalHer', '문화 유산', 6, ['conservation'], 'gwn:4', '걸작 4점 갖기'],
    ['coldWar', '냉전', 6, ['ideology'], 'tech:fission', '핵분열 연구'],
    ['proSports', '프로 스포츠', 6, ['ideology'], 'b:zoo:3', '동물원 3개 짓기'],
    ['rapidDep', '신속 배치', 6, ['coldWar'], 'd:enc:4', '주둔지 4개 짓기'],
    ['spaceRace', '우주 경쟁', 6, ['coldWar'], 'd:sp:1', '우주 기지 짓기'],
    ['environ', '환경주의', 7, ['culturalHer', 'rapidDep'], 'imp:solar:1', '태양광 발전소 짓기'],
    ['globalization', '세계화', 7, ['rapidDep', 'spaceRace'], 'tr:8', '교역로 8개'],
    ['socialMedia', '소셜 미디어', 7, ['proSports', 'spaceRace'], 'b:broadcast:2', '방송 센터 2개 짓기'],
    ['futureCiv', '미래 사회', 8, ['globalization', 'socialMedia', 'environ'], '', ''],
  ].map((a) => ({ k: a[0], n: a[1], e: a[2], pre: a[3], b: a[4], bt: a[5] }));
  const CIVICI = {}; CIVIC.forEach((t, i) => { CIVICI[t.k] = i; });
  // 총독 칭호를 주는 사회 제도
  const TITLE_CIVICS = ['stateWork', 'earlyEmpire', 'defTac', 'civilServ', 'guilds', 'mercantilism', 'nationalism', 'ideology', 'coldWar', 'globalization'];
  const ENVOY_CIVICS = ['code', 'polPhil', 'milTrain', 'divineRight', 'humanism', 'enlight', 'naturalHist', 'massMedia', 'coldWar', 'socialMedia'];

  /* ======================= 정부 ======================= */
  // sl: [군사, 경제, 외교, 와일드카드]
  const GOV = [
    { k: 'chiefdom', n: '족장제', req: '', sl: [1, 1, 0, 0], fx: {}, d: '처음 정부. 정책 슬롯 군사 1 · 경제 1.' },
    { k: 'autocracy', n: '독재정', req: 'polPhil', sl: [2, 1, 0, 1], fx: { cy: [1, 1, 1, 1, 1, 1], wonderP: 10 }, lg: { wonderP: 2 }, lgd: '불가사의 생산 +2%', d: '수도 모든 산출 +1, 불가사의 생산 +10%.' },
    { k: 'oligarchy', n: '과두정', req: 'polPhil', sl: [1, 1, 1, 1], fx: { 'cs.mel': 4, 'cs.ac': 4, xpP: 20 }, lg: { xpP: 4 }, lgd: '경험치 +4%', d: '근접·대기병 전투력 +4, 경험치 +20%.' },
    { k: 'republic', n: '고전 공화정', req: 'polPhil', sl: [0, 2, 1, 1], fx: { amenD: 1, gppP: 15 }, lg: { gppP: 3 }, lgd: '위인 점수 +3%', d: '특수지구가 있는 도시 쾌적도 +1, 위인 점수 +15%.' },
    { k: 'monarchy', n: '군주정', req: 'divineRight', sl: [3, 1, 1, 1], fx: { envP: 50, housWall: 1 }, lg: { loy: 1 }, lgd: '충성도 +1', d: '사절 얻는 속도 +50%, 성벽이 있는 도시 주거 +1.' },
    { k: 'theocracy', n: '신정', req: 'reformed', sl: [2, 2, 1, 1], fx: { faithBuyLand: 1, relcs: 5, faithP: 10 }, lg: { faithP: 2 }, lgd: '신앙 +2%', d: '신앙으로 지상 유닛 구매, 종교 전투력 +5, 신앙 +10%.' },
    { k: 'merchant', n: '상인 공화정', req: 'exploration', sl: [1, 2, 1, 2], fx: { trd: 2, buyP: -15 }, lg: { goldP: 2 }, lgd: '금 +2%', d: '교역로 +2, 금 구매 비용 −15%.' },
    { k: 'fascism', n: '파시즘', req: 'totalit', sl: [4, 1, 1, 2], fx: { cs: 5, pmu: 50 }, lg: { cs: 1 }, lgd: '전투력 +1', d: '모든 유닛 전투력 +5, 유닛 생산 +50%.' },
    { k: 'communism', n: '공산주의', req: 'classStr', sl: [3, 3, 1, 1], fx: { popProd: 0.4, loyP: 10 }, lg: { prodP: 2 }, lgd: '생산 +2%', d: '인구마다 생산 +0.4.' },
    { k: 'democracy', n: '민주주의', req: 'suffrage', sl: [1, 3, 2, 2], fx: { trg: 2, buyP: -25, gppP: 15 }, lg: { buyP: -2 }, lgd: '구매 비용 −2%', d: '교역로마다 금 +2, 구매 비용 −25%, 위인 점수 +15%.' },
  ];
  const GOVI = {}; GOV.forEach((g, i) => { GOVI[g.k] = i; });

  /* ======================= 정책 카드 ======================= */
  // t: M 군사 · E 경제 · D 외교 · W 위인(와일드카드), req 사회 제도, x: 이 제도를 얻으면 사라짐
  const POL = [
    ['discipline', '규율', 'M', 'code', { csBarb: 5 }, '야만인 상대 전투력 +5.', 'professional'],
    ['survey', '측량', 'M', 'code', { 'xpr': 1 }, '정찰 유닛 경험치 2배, 정찰 유닛 이동 +1.'],
    ['agoge', '아고게', 'M', 'craftsmanship', { pm: [['mel', 'rng', 'ac'], 0, 1, 50] }, '고대·고전 근접·원거리·대기병 생산 +50%.', 'feudalContract'],
    ['maritime', '해양 산업', 'M', 'foreignTrade', { pm: [['nm', 'nr'], 0, 1, 100] }, '고대·고전 해상 유닛 생산 +100%.', 'pressGangs'],
    ['maneuver', '기동전', 'M', 'milTrad', { pm: [['lc', 'hc'], 0, 1, 50] }, '고대·고전 기병 생산 +50%.', 'chivalry'],
    ['conscription', '징병제', 'M', 'stateWork', { maint: -1 }, '유닛 유지비 −1(유닛마다).'],
    ['bastions', '보루', 'M', 'defTac', { cityCS: 6 }, '도시 방어력 +6.'],
    ['limes', '리메스', 'M', 'defTac', { wallP: 100 }, '성벽 생산 +100%.'],
    ['retainers', '가신', 'M', 'civilServ', { amenGar: 1 }, '유닛이 지키는 도시 쾌적도 +1.'],
    ['professional', '직업 군대', 'M', 'mercenaries', { upgP: -50, csBarb: 5 }, '업그레이드 비용 −50%.'],
    ['feudalContract', '봉건 계약', 'M', 'feudalism', { pm: [['mel', 'rng', 'ac'], 0, 3, 50] }, '르네상스까지 근접·원거리·대기병 생산 +50%.', 'grandeArmee'],
    ['chivalry', '기사도', 'M', 'divineRight', { pm: [['lc', 'hc'], 0, 3, 50] }, '르네상스까지 기병 생산 +50%.', 'grandeArmee'],
    ['pressGangs', '강제 징집', 'M', 'exploration', { pm: [['nm', 'nr', 'nrd'], 0, 3, 100] }, '르네상스까지 해상 유닛 생산 +100%.'],
    ['grandeArmee', '대육군', 'M', 'nationalism', { pm: [['mel', 'rng', 'ac', 'lc', 'hc', 'sg'], 0, 5, 50] }, '현대까지 지상 유닛 생산 +50%.'],
    ['milResearch', '군사 연구', 'M', 'urbanization', { dy: { enc: [0, 0, 0, 2] } }, '주둔지마다 과학 +2.'],
    ['lightning', '전격전', 'M', 'mobilization', { mv: 1, 'cs.hc': 3, 'cs.lc': 3 }, '모든 유닛 이동 +1, 기병 전투력 +3.'],
    ['urbanPlan', '도시 계획', 'E', 'code', { y: [0, 1] }, '모든 도시 생산 +1.'],
    ['godKing', '신왕', 'E', 'code', { cy: [0, 0, 1, 0, 0, 1] }, '수도 금 +1 · 신앙 +1.'],
    ['ilkum', '일쿰', 'E', 'craftsmanship', { pmk: { builder: 30 } }, '건설자 생산 +30%.', 'publicWorks'],
    ['landSurvey', '토지 측량사', 'E', 'earlyEmpire', { tileP: -20 }, '타일 구매 비용 −20%.'],
    ['colonization', '식민화', 'E', 'earlyEmpire', { pmk: { settler: 50 } }, '개척자 생산 +50%.'],
    ['corvee', '부역', 'E', 'stateWork', { pmw: [0, 1, 15] }, '고대·고전 불가사의 생산 +15%.'],
    ['caravan', '대상 숙소', 'E', 'foreignTrade', { trg: 2 }, '교역로마다 금 +2.'],
    ['natPhil', '자연 철학', 'E', 'recHist', { adj: { cam: 100 } }, '캠퍼스 인접 보너스 +100%.'],
    ['scripture', '경전', 'E', 'theology', { adj: { hs: 100 } }, '성지 인접 보너스 +100%.'],
    ['townCharter', '도시 헌장', 'E', 'feudalism', { adj: { com: 100 } }, '상업 중심지 인접 보너스 +100%.'],
    ['aesthetics', '미학', 'E', 'medFaires', { adj: { th: 100 } }, '극장가 인접 보너스 +100%.'],
    ['craftsmen', '장인', 'E', 'guilds', { adj: { ind: 100 } }, '산업구역 인접 보너스 +100%.'],
    ['serfdom', '농노제', 'E', 'feudalism', { chg: 2 }, '새 건설자 충전 +2.', 'publicWorks'],
    ['insulae', '인술라', 'E', 'polPhil', { housD2: 1 }, '특수지구 2개 이상 도시 주거 +1.'],
    ['medina', '메디나 구역', 'E', 'guilds', { housD3: 2 }, '특수지구 3개 이상 도시 주거 +2.'],
    ['gothic', '고딕 건축', 'E', 'divineRight', { pmw: [2, 3, 15] }, '중세·르네상스 불가사의 생산 +15%.'],
    ['rationalism', '합리주의', 'E', 'enlight', { bm: { cam: 50 } }, '캠퍼스 건물 산출 +50%.'],
    ['freeMarket', '자유 시장', 'E', 'enlight', { bm: { com: 50 } }, '상업 중심지 건물 산출 +50%.'],
    ['simultaneum', '시뮬타네움', 'E', 'reformed', { bm: { hs: 50 } }, '성지 건물 산출 +50%.'],
    ['grandOpera', '그랜드 오페라', 'E', 'opera', { bm: { th: 50 } }, '극장가 건물 산출 +50%.'],
    ['publicWorks', '공공 사업', 'E', 'civilEng', { pmk: { builder: 30 }, chg: 2 }, '건설자 생산 +30%, 충전 +2.'],
    ['expropriation', '수용', 'E', 'scorched', { tileP: -50 }, '타일 구매 비용 −50%.'],
    ['fiveYear', '5개년 계획', 'E', 'classStr', { adj: { ind: 100, cam: 100 } }, '산업구역·캠퍼스 인접 +100%.'],
    ['newDeal', '뉴딜', 'E', 'suffrage', { housD3: 4, amenD3: 2 }, '특수지구 3개 이상 도시 주거 +4, 쾌적도 +2.'],
    ['economicUnion', '경제 연합', 'E', 'globalization', { adj: { com: 100, hb: 100 } }, '상업 중심지·항만 인접 +100%.'],
    ['ecommerce', '전자 상거래', 'E', 'socialMedia', { trg: 5 }, '교역로마다 금 +5.'],
    ['sportsMedia', '스포츠 미디어', 'E', 'proSports', { adj: { th: 100 }, amenEnt: 1 }, '극장가 인접 +100%, 오락 단지 쾌적도 +1.'],
    ['charismatic', '카리스마 지도자', 'D', 'polPhil', { env: 2 }, '사절 영향력 +2/턴.'],
    ['dipLeague', '외교 연맹', 'D', 'polPhil', { env: 1, favor: 1 }, '사절 영향력 +1, 외교 호의 +1.'],
    ['merchConf', '상인 연합', 'D', 'medFaires', { goldEnv: 1 }, '보낸 사절마다 금 +1.'],
    ['machiavelli', '마키아벨리즘', 'D', 'diploServ', { env: 3 }, '사절 영향력 +3.'],
    ['praetorium', '프라이토리움', 'D', 'recHist', { loyGov: 4 }, '총독이 있는 도시 충성도 +4.'],
    ['colonialOff', '식민청', 'D', 'exploration', { growthP: 15, loy: 3 }, '성장 +15%, 충성도 +3.'],
    ['raj', '라지', 'D', 'colonialism', { raj: 2 }, '종주국인 도시국가마다 과학·문화·신앙·금 +2.'],
    ['wissel', '비셀방켄', 'D', 'diploServ', { favor: 2 }, '외교 호의 +2/턴.'],
    ['arsenalDem', '민주주의의 무기고', 'D', 'suffrage', { favor: 3, env: 2 }, '외교 호의 +3, 사절 +2.'],
    ['inspiration', '영감', 'W', 'mysticism', { gpp: { sci: 2 } }, '위대한 과학자 +2/턴.'],
    ['revelation', '계시', 'W', 'mysticism', { gpp: { pro: 2 } }, '위대한 선지자 +2/턴.'],
    ['strategos', '전략가', 'W', 'milTrain', { gpp: { gen: 2 } }, '위대한 장군 +2/턴.'],
    ['navigation', '항해', 'W', 'navalTrad', { gpp: { adm: 2 } }, '위대한 제독 +2/턴.'],
    ['literary', '문학 전통', 'W', 'drama', { gpp: { wri: 2 } }, '위대한 작가 +2/턴.'],
    ['travelMerch', '순회 상인', 'W', 'guilds', { gpp: { mer: 2 } }, '위대한 상인 +2/턴.'],
    ['invention', '발명', 'W', 'humanism', { gpp: { eng: 4 }, pmw: [3, 3, 15] }, '위대한 기술자 +4/턴, 르네상스 불가사의 +15%.'],
    ['frescoes', '프레스코', 'W', 'humanism', { gpp: { art: 2 } }, '위대한 예술가 +2/턴.'],
    ['symphonies', '교향곡', 'W', 'opera', { gpp: { mus: 4 } }, '위대한 음악가 +4/턴.'],
    ['laissez', '자유방임', 'W', 'capitalism', { gpp: { mer: 2, adm: 2 } }, '위대한 상인·제독 +2/턴.'],
  ].map((a) => ({ k: a[0], n: a[1], t: a[2], req: a[3], fx: a[4], d: a[5], ob: a[6] || '' }));
  const POLI = {}; POL.forEach((p, i) => { POLI[p.k] = i; });
  const SLOTN = ['군사', '경제', '외교', '와일드카드'];
  const SLOTT = ['M', 'E', 'D', 'W'];
  const SLOTC = ['#c8473f', '#d9ad2c', '#4fa36b', '#9b6bd6'];

  /* ======================= 종교 ======================= */
  const RELN = ['불교', '가톨릭교', '유교', '힌두교', '이슬람교', '유대교', '동방 정교회', '개신교', '신도', '시크교', '도교', '조로아스터교'];
  const RELC = ['#f2c14e', '#e8e3d0', '#c0392b', '#ff8a3d', '#2fa05a', '#4a7bd8', '#8e5bc8', '#6d8fb8', '#e85d75', '#e0a020', '#5ac8c8', '#d65a2a'];
  // 만신전 신앙
  const PANTH = [
    ['forge', '대장장이 신', { pm: [['mel', 'rng', 'ac', 'lc', 'hc', 'sg'], 0, 1, 25] }, '고대·고전 군사 유닛 생산 +25%.'],
    ['sky', '열린 하늘의 신', { timp: { pasture: [0, 0, 0, 0, 1] } }, '목장 문화 +1.'],
    ['aurora', '오로라의 춤', { adjT: { hs: { t: 1 } } }, '성지가 인접한 툰드라마다 신앙 +1.'],
    ['folklore', '사막 민담', { adjT: { hs: { d: 1 } } }, '성지가 인접한 사막마다 신앙 +1.'],
    ['sacredPath', '신성한 길', { adjT: { hs: { rain: 1 } } }, '성지가 인접한 열대우림마다 신앙 +1.'],
    ['stoneCircle', '환상 열석', { timp: { quarry: [0, 0, 0, 0, 0, 2] } }, '채석장 신앙 +2.'],
    ['idols', '종교 우상', { timp: { mine: [0, 0, 0, 0, 0, 1] } }, '광산 신앙 +1.'],
    ['festivals', '축제의 여신', { timp: { plant: [1] } }, '농원 식량 +1.'],
    ['seaGod', '바다의 신', { timp: { fish: [0, 1] } }, '어선 생산 +1.'],
    ['reeds', '갈대의 여인', { tfeat: { marsh: [0, 2], oasis: [0, 2], flood: [0, 2] } }, '습지·오아시스·범람원 생산 +2.'],
    ['fertility', '다산 의식', { growthP: 10, freeBuilder: 1 }, '성장 +10%, 건설자 1명 바로.'],
    ['riverGod', '강의 여신', { amenRiverHs: 2 }, '강가 성지가 있는 도시 쾌적도 +2.'],
    ['monumentGods', '신들의 기념비', { pmw: [0, 1, 15] }, '고대·고전 불가사의 생산 +15%.'],
    ['patron', '도시의 수호 여신', { pmDist: 25 }, '특수지구 생산 +25%.'],
    ['warGod', '전쟁의 신', { killFaith: 1 }, '적을 처치하면 그 힘의 절반만큼 신앙.'],
    ['spark', '신성한 불꽃', { gpp: { pro: 1, sci: 1, wri: 1 } }, '선지자·과학자·작가 점수 +1/턴.'],
    ['hunt', '사냥의 여신', { timp: { camp: [1] } }, '야영지 식량 +1.'],
    ['oral', '구전', { timp: { plant: [0, 0, 0, 0, 1] } }, '농원 문화 +1.'],
  ].map((a) => ({ k: a[0], n: a[1], fx: a[2], d: a[3] }));
  // 종교 신앙: 추종자(F), 창시자(O), 예배(W), 강화(E)
  const BELIEF = [
    ['feedWorld', '세계를 먹이다', 'F', { relB: { shrine: [3], temple: [2] } }, '이 종교를 믿는 도시의 사당 식량 +3, 신전 +2.'],
    ['choral', '합창 음악', 'F', { relB: { shrine: [0, 0, 0, 0, 2], temple: [0, 0, 0, 0, 4] } }, '사당 문화 +2, 신전 문화 +4.'],
    ['divineInsp', '신의 영감', 'F', { relW: [0, 0, 0, 0, 0, 4] }, '불가사의마다 신앙 +4.'],
    ['jesuit', '예수회 교육', 'F', { relCam: [0, 0, 0, 2] }, '캠퍼스 있는 도시 과학 +2.'],
    ['workEthic', '노동 윤리', 'F', { relHsProd: 1 }, '성지 인접 보너스만큼 생산.'],
    ['zen', '선 명상', 'F', { relAmen: 1 }, '특수지구 2개 이상 도시 쾌적도 +1.'],
    ['community', '종교 공동체', 'F', { relGrowth: 10 }, '성장 +10%.'],
    ['warriorMonks', '전사 수도사', 'F', { relGen: 1 }, '성지가 있는 도시 위대한 장군 +1, 전투력 +2.'],
    ['tithe', '십일조', 'O', { oTithe: 1 }, '이 종교를 믿는 도시 4곳마다 금 +1(최소 도시당 1).'],
    ['churchProp', '교회 재산', 'O', { oCP: [0, 0, 2] }, '이 종교를 믿는 도시마다 금 +2.'],
    ['pilgrimage', '순례', 'O', { oCP: [0, 0, 0, 0, 0, 2] }, '이 종교를 믿는 도시마다 신앙 +2.'],
    ['worldChurch', '세계 교회', 'O', { oCP: [0, 0, 0, 0, 1] }, '이 종교를 믿는 도시마다 문화 +1.'],
    ['crossCult', '문화 간 대화', 'O', { oCP: [0, 0, 0, 1] }, '이 종교를 믿는 도시마다 과학 +1.'],
    ['papal', '교황 수위권', 'O', { oEnv: 1 }, '이 종교를 믿는 도시국가 사절 +1.'],
    ['layMin', '평신도 사역', 'O', { oCP: [0, 0, 1, 0, 0, 1] }, '이 종교를 믿는 도시마다 금 +1 · 신앙 +1.'],
    ['cathedral', '대성당', 'W', { wb: 0 }, WORSHIP[0].d],
    ['mosque', '모스크', 'W', { wb: 1 }, WORSHIP[1].d],
    ['pagoda', '파고다', 'W', { wb: 2 }, WORSHIP[2].d],
    ['synagogue', '회당', 'W', { wb: 3 }, WORSHIP[3].d],
    ['wat', '와트', 'W', { wb: 4 }, WORSHIP[4].d],
    ['meeting', '집회소', 'W', { wb: 5 }, WORSHIP[5].d],
    ['gurdwara', '구르드와라', 'W', { wb: 6 }, WORSHIP[6].d],
    ['stupa', '스투파', 'W', { wb: 7 }, WORSHIP[7].d],
    ['zeal', '선교 열정', 'E', { relMv: 2 }, '종교 유닛 이동 +2.'],
    ['holyOrder', '성스러운 결사', 'E', { relCost: -30 }, '선교사·사도 비용 −30%.'],
    ['itinerant', '순회 설교자', 'E', { relRange: 4 }, '종교 압력이 4칸 더 멀리 가요.'],
    ['defender', '신앙의 수호자', 'E', { defFaith: 8 }, '이 종교를 믿는 내 영토에서 수비 +8.'],
    ['crusade', '십자군', 'E', { crusade: 10 }, '이 종교를 믿는 외국 도시 근처에서 전투력 +10.'],
    ['scriptureE', '성서 번역', 'E', { relSpread: 1 }, '선교사·사도 전파 횟수 +1.'],
  ].map((a) => ({ k: a[0], n: a[1], t: a[2], fx: a[3], d: a[4] }));
  const BELI = {}; BELIEF.forEach((b, i) => { BELI[b.k] = i; });

  /* ======================= 위인 ======================= */
  // 종류: sci 과학자, eng 기술자, mer 상인, pro 선지자, gen 장군, adm 제독, wri 작가, art 예술가, mus 음악가
  const GPC = {
    sci: { n: '위대한 과학자', ic: '🔬', yi: 3 }, eng: { n: '위대한 기술자', ic: '⚙', yi: 1 }, mer: { n: '위대한 상인', ic: '💰', yi: 2 },
    pro: { n: '위대한 선지자', ic: '🙏', yi: 5 }, gen: { n: '위대한 장군', ic: '⚔', yi: 1 }, adm: { n: '위대한 제독', ic: '⚓', yi: 2 },
    wri: { n: '위대한 작가', ic: '📜', yi: 4 }, art: { n: '위대한 예술가', ic: '🎨', yi: 4 }, mus: { n: '위대한 음악가', ic: '🎵', yi: 4 },
  };
  const GPK = Object.keys(GPC);
  // e: 시대, fx: 능력 (sciB n 유레카, sci 과학, prod 생산(불가사의·구역), gold 금, rel 종교 창시, aura 전투 보너스, gw 걸작, tr 교역로, amen 쾌적도, …)
  const GPL = [
    ['sci', '유클리드', 0, { boost: 2 }, '수학·중세 기술 유레카 2개'], ['sci', '하이파티아', 1, { bld: ['library', [0, 0, 0, 1]] }, '도서관 과학 +1'],
    ['sci', '아리아바타', 1, { boost: 2 }, '현재 시대 유레카 2개'], ['sci', '장형', 2, { sci: 200 }, '과학 즉시 +200(속도 비례)'],
    ['sci', '아이작 뉴턴', 3, { bld: ['university', [0, 0, 0, 2]] }, '대학교 과학 +2'], ['sci', '갈릴레오 갈릴레이', 3, { sciMtn: 250 }, '인접 산마다 과학 +250'],
    ['sci', '찰스 다윈', 4, { sci: 600 }, '과학 즉시 +600'], ['sci', '드미트리 멘델레예프', 4, { boost: 2 }, '유레카 2개'],
    ['sci', '알베르트 아인슈타인', 5, { sci: 1000 }, '과학 즉시 +1000'], ['sci', '앨런 튜링', 6, { boost: 3 }, '유레카 3개'],
    ['sci', '마리 퀴리', 6, { sci: 1500 }, '과학 즉시 +1500'], ['sci', '스테퍼니 퀄렉', 7, { boost: 3 }, '유레카 3개'],
    ['eng', '임호텝', 0, { wonder: 175 }, '불가사의 생산 +175'], ['eng', '비승', 1, { wonder: 175, chg: 1 }, '불가사의 +175'],
    ['eng', '이시도로스', 2, { wonder: 250 }, '불가사의 +250'], ['eng', '필리포 브루넬레스키', 3, { wonder: 315 }, '불가사의 +315'],
    ['eng', '레오나르도 다 빈치', 3, { wonder: 400 }, '불가사의 +400'], ['eng', '제임스 와트', 4, { bld: ['workshop', [0, 2]] }, '작업장 생산 +2'],
    ['eng', '귀스타브 에펠', 4, { wonder: 600 }, '불가사의 +600'], ['eng', '니콜라 테슬라', 5, { bld: ['factory', [0, 3]] }, '공장 생산 +3'],
    ['eng', '로버트 고더드', 6, { space: 800 }, '우주 프로젝트 +800'], ['eng', '세르게이 코롤료프', 7, { space: 1200 }, '우주 프로젝트 +1200'],
    ['mer', '콜라이오스', 0, { gold: 200 }, '금 +200'], ['mer', '마르코 폴로', 1, { tr: 1 }, '교역로 +1, 상인 1명'],
    ['mer', '조반니 데 메디치', 2, { gold: 300, tr: 1 }, '금 +300'], ['mer', '야코프 푸거', 3, { gold: 450 }, '금 +450'],
    ['mer', '애덤 스미스', 4, { bld: ['market', [0, 0, 2]] }, '시장 금 +2'], ['mer', '존 록펠러', 5, { gold: 800 }, '금 +800'],
    ['mer', '메리 케이트 엘리어트', 6, { amen: 2 }, '이 도시 쾌적도 +2'], ['mer', '에스테 로더', 7, { gold: 1200 }, '금 +1200'],
    ['pro', '공자', 0, { rel: 1 }, '종교 창시'], ['pro', '노자', 0, { rel: 1 }, '종교 창시'], ['pro', '조로아스터', 0, { rel: 1 }, '종교 창시'],
    ['pro', '고타마 싯다르타', 0, { rel: 1 }, '종교 창시'], ['pro', '시몬 베드로', 0, { rel: 1 }, '종교 창시'], ['pro', '세례자 요한', 0, { rel: 1 }, '종교 창시'],
    ['pro', '이레네오', 0, { rel: 1 }, '종교 창시'], ['pro', '송첸감포', 0, { rel: 1 }, '종교 창시'],
    ['gen', '부디카', 0, { aura: 5 }, '근처 지상 유닛 +5'], ['gen', '한니발 바르카', 1, { aura: 5 }, '근처 +5'], ['gen', '손무', 1, { aura: 5 }, '근처 +5'],
    ['gen', '엘시드', 2, { aura: 5 }, '근처 +5'], ['gen', '구스타브 아돌프', 3, { aura: 5 }, '근처 +5'], ['gen', '락슈미바이', 4, { aura: 5 }, '근처 +5'],
    ['gen', '드와이트 아이젠하워', 5, { aura: 5 }, '근처 +5'], ['gen', '게오르기 주코프', 6, { aura: 5 }, '근처 +5'],
    ['adm', '아르테미시아', 0, { aura: 5, naval: 1 }, '근처 해상 +5'], ['adm', '테미스토클레스', 1, { aura: 5, naval: 1 }, '근처 해상 +5'],
    ['adm', '이순신', 2, { aura: 7, naval: 1 }, '근처 해상 +7'], ['adm', '프랜시스 드레이크', 3, { aura: 5, naval: 1 }, '근처 해상 +5'],
    ['adm', '허레이쇼 넬슨', 4, { aura: 5, naval: 1 }, '근처 해상 +5'], ['adm', '체스터 니미츠', 5, { aura: 5, naval: 1 }, '근처 해상 +5'],
    ['wri', '호메로스', 0, { gw: 'wri' }, '문학 걸작 2점'], ['wri', '비야사', 0, { gw: 'wri' }, '문학 걸작'], ['wri', '무라사키 시키부', 2, { gw: 'wri' }, '문학 걸작'],
    ['wri', '윌리엄 셰익스피어', 3, { gw: 'wri' }, '문학 걸작'], ['wri', '미겔 데 세르반테스', 3, { gw: 'wri' }, '문학 걸작'], ['wri', '레프 톨스토이', 4, { gw: 'wri' }, '문학 걸작'],
    ['wri', '마크 트웨인', 4, { gw: 'wri' }, '문학 걸작'], ['wri', '버지니아 울프', 5, { gw: 'wri' }, '문학 걸작'],
    ['art', '안드레이 루블료프', 2, { gw: 'art' }, '미술 걸작'], ['art', '미켈란젤로', 3, { gw: 'art' }, '미술 걸작'], ['art', '렘브란트 판 레인', 3, { gw: 'art' }, '미술 걸작'],
    ['art', '빈센트 반 고흐', 4, { gw: 'art' }, '미술 걸작'], ['art', '클로드 모네', 4, { gw: 'art' }, '미술 걸작'], ['art', '프리다 칼로', 5, { gw: 'art' }, '미술 걸작'],
    ['mus', '요한 제바스티안 바흐', 3, { gw: 'mus' }, '음악 걸작'], ['mus', '볼프강 아마데우스 모차르트', 4, { gw: 'mus' }, '음악 걸작'],
    ['mus', '루트비히 판 베토벤', 4, { gw: 'mus' }, '음악 걸작'], ['mus', '프레데리크 쇼팽', 4, { gw: 'mus' }, '음악 걸작'], ['mus', '릴리 불랑제', 5, { gw: 'mus' }, '음악 걸작'],
  ].map((a, i) => ({ id: i, c: a[0], n: a[1], e: a[2], fx: a[3], d: a[4] }));
  const GW_Y = { wri: [0, 0, 0, 0, 2], art: [0, 0, 0, 0, 3], mus: [0, 0, 0, 0, 4], arti: [0, 0, 0, 0, 3], rel: [0, 0, 0, 0, 0, 4] };
  const GW_T = { wri: 2, art: 3, mus: 4, arti: 3, rel: 8 };   // 걸작 관광(원작 값)
  const GW_N = { wri: '문학 걸작', art: '미술 걸작', mus: '음악 걸작', arti: '유물', rel: '성유물' };
  const GW_I = { wri: '📜', art: '🎨', mus: '🎵', arti: '🏺', rel: '✨' };
  const GW_CH = { wri: 2, art: 3, mus: 2 };   // 위인 한 명이 만드는 걸작 수

  /* ======================= 세계 불가사의 ======================= */
  // on: 놓을 곳 조건 코드, fx: 효과
  const WON = [
    ['pyramids', '피라미드', 0, 'masonry', 180, 'desert', { chg: 1, y: [0, 0, 0, 0, 2] }, '사막(범람원 제외)에. 문화 +2, 새 건설자 충전 +1.'],
    ['stonehenge', '스톤헨지', 0, 'astrology', 180, 'flatStone', { y: [0, 0, 0, 0, 0, 2], freeGP: 'pro' }, '돌 자원과 붙은 평지에. 신앙 +2, 위대한 선지자.'],
    ['gardens', '공중정원', 0, 'irrigation', 180, 'river', { growthP: 15, h: 2 }, '강가에. 모든 도시 성장 +15%, 주거 +2.'],
    ['oracle', '신탁', 0, 'c:mysticism', 220, 'hills', { y: [0, 0, 0, 0, 1, 1], gppAll: 2 }, '언덕에. 문화·신앙 +1, 모든 위인 점수 +2.'],
    ['colossus', '거상', 1, 'shipbuilding', 220, 'coastLand', { y: [0, 0, 3], trd: 1 }, '연안 땅에. 금 +3, 교역로 +1.'],
    ['lighthouseW', '대등대', 1, 'celestial', 220, 'coastHarbor', { mvSea: 1, y: [0, 0, 3] }, '항만(등대) 옆 연안에. 해상 이동 +1, 금 +3.'],
    ['petra', '페트라', 1, 'math', 400, 'desert', { petra: 1 }, '사막에. 도시의 사막 칸 식량·금 +2, 생산 +1.'],
    ['terracotta', '테라코타 군대', 1, 'construction', 400, 'flatEnc', { promoAll: 1, gppGen: 2 }, '주둔지 옆 평지에. 모든 유닛 승급 1회.'],
    ['colosseum', '콜로세움', 1, 'c:games', 400, 'flatEnt', { amenR: 2, y: [0, 0, 0, 0, 2] }, '오락 단지 옆 평지에. 6칸 안 도시 쾌적도 +2, 문화 +2.'],
    ['library', '대도서관', 1, 'c:recHist', 400, 'flatCam', { y: [0, 0, 0, 2], freeBoost: 3 }, '캠퍼스 옆 평지에. 과학 +2, 유레카 3개.'],
    ['mahabodhi', '마하보디 사원', 1, 'c:theology', 400, 'woodsHs', { y: [0, 0, 0, 0, 0, 4], dvp: 2 }, '성지 옆 숲에. 신앙 +4, 외교 승리 점수 +2.'],
    ['hagia', '하기아 소피아', 2, 'education', 660, 'flatHs', { y: [0, 0, 0, 0, 0, 4], relSpread: 1 }, '성지 옆 평지에. 신앙 +4, 전파 +1.'],
    ['alhambra', '알함브라', 2, 'castles', 660, 'hillsEnc', { slot: [1, 0, 0, 0], amen: 2 }, '주둔지 옆 언덕에. 군사 정책 슬롯 +1, 쾌적도 +2.'],
    ['chichen', '치첸이트사', 2, 'c:guilds', 660, 'rain', { tfeat: { rain: [0, 1, 0, 0, 2] } }, '열대우림에. 내 열대우림 문화 +2 · 생산 +1.'],
    ['forbidden', '자금성', 2, 'c:feudalism', 660, 'flatAdjCC', { slot: [0, 0, 0, 1], y: [0, 0, 0, 0, 5] }, '도심 옆 평지에. 와일드카드 슬롯 +1, 문화 +5.'],
    ['potala', '포탈라 궁', 3, 'astronomy', 920, 'hillsMtn', { slot: [0, 0, 1, 0], y: [0, 0, 0, 0, 2, 3], dvp: 1 }, '산 옆 언덕에. 외교 슬롯 +1, 외교 승리 점수 +1.'],
    ['arsenal', '베네치아 군수공장', 3, 'massProd', 920, 'coastInd', { pmNaval: 100 }, '산업구역 옆 연안에. 해상 유닛 생산 +100%.'],
    ['oxford', '옥스퍼드 대학', 4, 'sciTheory', 1240, 'flatCam', { y: [0, 0, 0, 3], freeTech: 2 }, '캠퍼스 옆 평지에. 과학 +3, 기술 2개.'],
    ['bigben', '빅벤', 4, 'economics', 1240, 'riverCom', { y: [0, 0, 6], treasury: 1 }, '상업 중심지 옆 강가에. 금 +6, 보유 금 2배(최대 1000).'],
    ['ruhr', '루르 계곡', 4, 'industrial', 1240, 'riverInd', { cityP: 20, y: [0, 3] }, '산업구역 옆 강가에. 이 도시 생산 +20%.'],
    ['hermitage', '에르미타주', 4, 'c:naturalHist', 1240, 'riverAny', { y: [0, 0, 0, 0, 4], gwSlot: 4 }, '강가에. 문화 +4, 미술 걸작 칸 4.'],
    ['bolshoi', '볼쇼이 극장', 4, 'c:opera', 1240, 'flatTh', { freeCivic: 2 }, '극장가 옆 평지에. 사회 제도 2개.'],
    ['liberty', '자유의 여신상', 4, 'c:civilEng', 1240, 'coastLand', { dvp: 4 }, '연안 땅에. 외교 승리 점수 +4.'],
    ['eiffel', '에펠탑', 5, 'steel', 1620, 'flatAny', { appeal: 2, tour: 4 }, '평지에. 모든 칸 매력 +2(관광 ↑).'],
    ['broadway', '브로드웨이', 5, 'c:massMedia', 1620, 'flatTh', { y: [0, 0, 0, 0, 6], gwSlot: 3 }, '극장가 옆 평지에. 문화 +6, 음악 칸 3.'],
    ['cristo', '크리스트 레뎅토르', 5, 'c:massMedia', 1620, 'hills', { y: [0, 0, 0, 0, 4], relTour: 1 }, '언덕에. 문화 +4, 종교 관광이 줄지 않아요.'],
    ['sydney', '시드니 오페라하우스', 6, 'c:culturalHer', 1850, 'coastHarbor', { y: [0, 0, 0, 0, 8], tour: 4 }, '항만 옆 연안에. 문화 +8.'],
    ['maracana', '마라카낭 경기장', 6, 'c:proSports', 1850, 'flatEnt', { amenAll: 2, y: [0, 0, 0, 0, 6] }, '오락 단지 옆 평지에. 모든 도시 쾌적도 +2, 문화 +6.'],
    ['amundsen', '아문센-스콧 기지', 6, 'chemistry', 1850, 'snowTundra', { pmSci: 10 }, '설원·툰드라에. 모든 도시 과학 +10%.'],
    ['machu', '마추픽추', 1, 'engineering', 400, 'mountain', { y: [0, 0, 4], mtnAdj: 1 }, '산 위에. 금 +4, 산 옆 상업·극장·산업 구역 인접 +1.'],
  ].map((a) => ({ k: a[0], n: a[1], e: a[2], req: a[3], c: a[4], on: a[5], fx: a[6], d: a[7] }));
  const WONI = {}; WON.forEach((w, i) => { WONI[w.k] = i; });

  /* ======================= 문명·지도자 ======================= */
  // ag: 지도자 성향(AI): war 전쟁, sci 과학, cul 문화, rel 종교, exp 확장, won 불가사의, gold 금, peace 평화
  const CIVS = [
    { k: 'america', n: '미국', ld: '시어도어 루스벨트', ab: '건국의 아버지들', la: '루스벨트 추론', fx: { slot: [0, 0, 1, 0], csHome: 5, tourP: 10 },
      abd: '외교 정책 슬롯 +1, 관광 +10%.', lad: '고향 대륙에서 전투력 +5.', ag: { peace: 2, cul: 2, war: 1 }, agn: '대형 몽둥이', agd: '고향 대륙 평화를 좋아해요.',
      cities: ['워싱턴', '뉴욕', '보스턴', '필라델피아', '애틀랜타', '시카고', '시애틀', '샌프란시스코', '로스앤젤레스', '휴스턴', '마이애미', '덴버'] },
    { k: 'arabia', n: '아라비아', ld: '살라딘', ab: '마지막 선지자', la: '정의로운 신앙', fx: { lastProphet: 1, faithP: 10, sciP: 5 },
      abd: '마지막 위대한 선지자를 자동으로 얻어요. 신앙 +10%.', lad: '과학 +5%.', ag: { rel: 3, sci: 2 }, agn: '아이유브 왕조', agd: '종교를 좋아해요.',
      cities: ['메카', '메디나', '바그다드', '다마스쿠스', '카이로', '바스라', '리야드', '알레포', '무스카트', '모술', '제다', '타이프'] },
    { k: 'brazil', n: '브라질', ld: '페드루 2세', ab: '아마존', la: '관대함', fx: { rainAdj: 1, gppP: 15 },
      abd: '열대우림이 캠퍼스·성지·상업·극장가 인접 +1.', lad: '위인 점수 +15%.', ag: { cul: 3, won: 1 }, agn: '예술 후원자', agd: '위인을 좋아해요.',
      cities: ['리우데자네이루', '상파울루', '살바도르', '브라질리아', '헤시피', '벨렝', '포르탈레자', '쿠리치바', '마나우스', '포르투알레그리'] },
    { k: 'china', n: '중국', ld: '진시황', ab: '왕조 순환', la: '최초의 황제', fx: { boostP: 10, chg: 1, wonderP: 10 },
      abd: '유레카·영감이 50%를 줘요.', lad: '건설자 충전 +1, 불가사의 생산 +10%.', ag: { won: 3, sci: 1 }, agn: '거대한 업적', agd: '불가사의를 좋아해요.',
      cities: ['시안', '베이징', '난징', '상하이', '광저우', '청두', '항저우', '우한', '뤄양', '카이펑', '쑤저우', '톈진'] },
    { k: 'egypt', n: '이집트', ld: '클레오파트라', ab: '나일 강의 선물', la: '지중해의 신부', fx: { riverWonder: 15, trg: 3 },
      abd: '강가의 구역·불가사의 생산 +15%.', lad: '교역로마다 금 +3.', ag: { gold: 2, war: 1 }, agn: '나일 강의 여왕', agd: '강한 군대를 좋아해요.',
      cities: ['테베', '멤피스', '알렉산드리아', '헬리오폴리스', '기자', '아스완', '아비도스', '룩소르', '엘레판티네', '부바스티스'] },
    { k: 'england', n: '잉글랜드', ld: '빅토리아', ab: '세계의 작업장', la: '해가 지지 않는 제국', fx: { pmNaval: 25, stratX: 2, prodP: 5 },
      abd: '철·석탄 광산이 전략 자원을 더 줘요(+2).', lad: '해상 유닛 생산 +25%.', ag: { exp: 2, war: 1 }, agn: '유니언잭', agd: '넓은 영토를 좋아해요.',
      cities: ['런던', '리버풀', '맨체스터', '요크', '버밍엄', '브리스톨', '옥스퍼드', '캠브리지', '노리치', '셰필드', '리즈'] },
    { k: 'france', n: '프랑스', ld: '카트린 드 메디치', ab: '그랜드 투어', la: '검은 왕비', fx: { pmw: [2, 4, 20], tourP: 15 },
      abd: '중세~산업 불가사의 생산 +20%.', lad: '궁정 축제: 관광 +15%.', ag: { won: 2, cul: 2 }, agn: '왕비의 측근', agd: '불가사의와 문화를 좋아해요.',
      cities: ['파리', '오를레앙', '리옹', '마르세유', '보르도', '툴루즈', '랭스', '루앙', '낭트', '디종', '스트라스부르'] },
    { k: 'germany', n: '독일', ld: '프리드리히 바르바로사', ab: '자유 제국 도시', la: '신성 로마 황제', fx: { distLim: 1, slot: [1, 0, 0, 0], csCS: 7 },
      abd: '도시마다 특수지구 하나 더(인구 제한 +1).', lad: '군사 슬롯 +1, 도시국가 상대 전투력 +7.', ag: { war: 2, exp: 1 }, agn: '철혈 황제', agd: '도시국가를 노려요.',
      cities: ['아헨', '베를린', '함부르크', '뮌헨', '쾰른', '프랑크푸르트', '뉘른베르크', '드레스덴', '라이프치히', '슈투트가르트', '브레멘'] },
    { k: 'greece', n: '그리스', ld: '페리클레스', ab: '플라톤의 국가', la: '페리클레스 연설', fx: { slot: [0, 0, 0, 1], culPerSuz: 5 },
      abd: '와일드카드 슬롯 +1.', lad: '종주국인 도시국가마다 문화 +5%.', ag: { cul: 3, peace: 1 }, agn: '델로스 동맹', agd: '도시국가 친구를 좋아해요.',
      cities: ['아테네', '스파르타', '코린토스', '테베', '아르고스', '델포이', '에피다우로스', '올림피아', '로도스', '밀레토스'] },
    { k: 'india', n: '인도', ld: '간디', ab: '다르마', la: '사티아그라하', fx: { faithP: 15, gandhi: 1 },
      abd: '신앙 +15%.', lad: '평화로운 나라를 만날수록 신앙이 늘어요.', ag: { peace: 3, rel: 2 }, agn: '평화주의자', agd: '전쟁광을 싫어해요.',
      cities: ['델리', '뭄바이', '바라나시', '아그라', '콜카타', '첸나이', '하이데라바드', '방갈로르', '자이푸르', '푸네', '파트나'] },
    { k: 'japan', n: '일본', ld: '호조 도키무네', ab: '메이지 유신', la: '신풍', fx: { meiji: 1, csCoast: 5 },
      abd: '구역이 붙은 구역마다 인접 +1(서로 도와요).', lad: '해안가 땅에서 전투력 +5.', ag: { war: 1, sci: 1, cul: 1 }, agn: '부시도', agd: '강하고 교양 있는 나라를 좋아해요.',
      cities: ['교토', '오사카', '도쿄', '나라', '가마쿠라', '히로시마', '나고야', '삿포로', '센다이', '나가사키', '고베'] },
    { k: 'kongo', n: '콩고', ld: '음벰바 아 은징가', ab: '은키시', la: '왕국의 종교', fx: { gppP: 25, noRel: 1, faithP: 10 },
      abd: '위인 점수 +25%. 종교를 창시할 수 없어요.', lad: '다른 종교를 받아들여 신앙 +10%.', ag: { cul: 2, gold: 1 }, agn: '아프리카의 보물', agd: '걸작을 좋아해요.',
      cities: ['음반자콩고', '음반자소요', '음반자은수디', '음반자음판다', '음반자음벰바', '루안다', '은세토', '카빈다', '음팡구'] },
    { k: 'norway', n: '노르웨이', ld: '하랄 하르드라다', ab: '바이킹 원정', la: '북방의 천둥', fx: { mvSea: 1, 'cs.nm': 5 },
      abd: '해상 이동 +1.', lad: '해상 근접 전투력 +5.', ag: { war: 2, exp: 1 }, agn: '최후의 바이킹 왕', agd: '바다의 힘을 좋아해요.',
      cities: ['니다로스', '오슬로', '베르겐', '스타방에르', '트롬쇠', '하마르', '보되', '알레순', '몰데', '룬드'] },
    { k: 'rome', n: '로마', ld: '트라야누스', ab: '모든 길은 로마로', la: '트라야누스 기념비', fx: { freeBld: 'monument', roadsCity: 1, trg: 1 },
      abd: '새 도시를 수도와 도로로 잇고, 교역로 금 +1.', lad: '새 도시에 기념비가 공짜.', ag: { exp: 3, war: 1 }, agn: '최고의 황제', agd: '넓은 제국을 좋아해요.',
      cities: ['로마', '오스티아', '안티움', '쿠마이', '아퀼레이아', '라벤나', '푸테올리', '아레티움', '메디올라눔', '루그두눔', '아리미눔'] },
    { k: 'russia', n: '러시아', ld: '표트르 대제', ab: '어머니 러시아', la: '대사절단', fx: { extraTiles: 5, tundraY: [1, 1], sciP: 5 },
      abd: '도시를 세우면 영토 5칸 더, 툰드라 식량·생산 +1.', lad: '과학 +5%.', ag: { exp: 2, sci: 2 }, agn: '서구화', agd: '앞선 과학을 좋아해요.',
      cities: ['상트페테르부르크', '모스크바', '노브고로드', '카잔', '스몰렌스크', '야로슬라블', '사마라', '이르쿠츠크', '옴스크', '볼고그라드'] },
    { k: 'scythia', n: '스키타이', ld: '토미리스', ab: '스키타이 부족', la: '사람 사냥꾼', fx: { doubleLC: 1, csWounded: 5 },
      abd: '경기병을 만들면 하나를 더 줘요.', lad: '다친 적 상대 전투력 +5.', ag: { war: 3 }, agn: '초원의 여왕', agd: '전쟁을 좋아해요.',
      cities: ['파티칸파이', '네아폴리스', '겔로노스', '나우스', '타나이스', '에스틸', '아스트라', '아르마비르', '카마나'] },
    { k: 'spain', n: '스페인', ld: '펠리페 2세', ab: '보물 함대', la: '엘 에스코리알', fx: { faithP: 10, trg: 2, csRel: 4 },
      abd: '교역로 금 +2, 신앙 +10%.', lad: '종교가 다른 문명 상대 전투력 +4.', ag: { rel: 2, war: 1 }, agn: '반종교 개혁', agd: '같은 종교를 좋아해요.',
      cities: ['마드리드', '바르셀로나', '세비야', '코르도바', '톨레도', '발렌시아', '사라고사', '그라나다', '살라망카', '빌바오'] },
    { k: 'sumeria', n: '수메르', ld: '길가메시', ab: '최초의 문명', la: '길가메시 서사시', fx: { csBarb: 10, campGold: 1, sciP: 5 },
      abd: '야만인 야영지 금 2배, 과학 +5%.', lad: '야만인 상대 전투력 +10.', ag: { peace: 1, sci: 1, war: 1 }, agn: '동반자', agd: '우호적인 나라를 좋아해요.',
      cities: ['우루크', '우르', '라가시', '니푸르', '키시', '에리두', '움마', '라르사', '바드티비라', '슈루팍'] },
    { k: 'aztec', n: '아즈텍', ld: '몬테수마', ab: '다섯 번째 태양의 전설', la: '몬테수마의 선물', fx: { luxAmen: 1, cs: 1 },
      abd: '사치 자원 하나가 도시 6곳(원래 4곳)에 쾌적도를 줘요.', lad: '모든 유닛 전투력 +1.', ag: { war: 2, gold: 1 }, agn: '태양의 제국', agd: '사치 자원을 원해요.',
      cities: ['테노치티틀란', '텍스코코', '틀라코판', '틀락스칼라', '촐룰라', '쿠에르나바카', '톨루카', '테오티우아칸', '아카마피치틀리'] },
    { k: 'korea', n: '한국', ld: '선덕 여왕', ab: '삼국', la: '화랑', fx: { mineSci: 1, culP: 5, sciP: 5 },
      abd: '광산 과학 +1. 서원(캠퍼스 대신)은 기본 과학 +4.', lad: '문화·과학 +5%.', ag: { sci: 3, peace: 1 }, agn: '첨성대', agd: '과학을 좋아해요.',
      cities: ['경주', '서울', '평양', '개성', '부산', '광주', '대구', '전주', '청주', '인천', '공주', '울산'] },
    { k: 'mongolia', n: '몽골', ld: '칭기즈 칸', ab: '역참', la: '칭기즈 칸의 정복', fx: { 'cs.lc': 3, 'cs.hc': 3, xpP: 25 },
      abd: '기병 전투력 +3.', lad: '경험치 +25%.', ag: { war: 3, exp: 1 }, agn: '대칸', agd: '정복을 좋아해요.',
      cities: ['카라코룸', '울란바토르', '바얀홍고르', '홉드', '다르항', '에르데네트', '초이발산', '쇠뵈', '하르호린'] },
    { k: 'zulu', n: '줄루', ld: '샤카', ab: '이시티투', la: '아마부토', fx: { csPromo: 4, xpP: 25 },
      abd: '승급한 유닛 전투력 +4.', lad: '경험치 +25%.', ag: { war: 3 }, agn: '줄루 대군', agd: '강한 군대만 인정해요.',
      cities: ['울룬디', '쿠아불라와요', '은돈도', '에쇼웨', '은콘얀', '두쿠자', '음게웅운들로부', '마푸마로', '울루바'] },
    { k: 'netherlands', n: '네덜란드', ld: '빌헬미나', ab: '대운하', la: '라디오 오라녜', fx: { riverAdj: 1, trg: 2 },
      abd: '강가의 캠퍼스·극장가·산업구역 인접 +1.', lad: '교역로 금 +2.', ag: { gold: 2, peace: 1 }, agn: '시장 경제', agd: '교역을 좋아해요.',
      cities: ['암스테르담', '로테르담', '위트레흐트', '헤이그', '흐로닝언', '레이던', '하를럼', '델프트', '에인트호번', '마스트리흐트'] },
    { k: 'canada', n: '캐나다', ld: '윌프리드 로리에', ab: '네 가지 면모', la: '마지막 국경', fx: { tundraY: [1, 1], favor: 3 },
      abd: '외교 호의 +3/턴.', lad: '툰드라·설원 식량·생산 +1.', ag: { peace: 3 }, agn: '평화로운 강자', agd: '평화를 좋아해요.',
      cities: ['오타와', '몬트리올', '토론토', '밴쿠버', '퀘벡', '핼리팩스', '캘거리', '위니펙', '에드먼턴', '레자이나'] },
    { k: 'ottoman', n: '오스만', ld: '술레이만', ab: '위대한 투르크 포', la: '대제', fx: { pm: [['sg'], 0, 8, 50], amenConq: 1, cs: 1 },
      abd: '공성 유닛 생산 +50%.', lad: '정복한 도시 쾌적도 +1.', ag: { war: 2, exp: 1 }, agn: '술탄의 위엄', agd: '정복을 좋아해요.',
      cities: ['이스탄불', '에디르네', '부르사', '앙카라', '이즈미르', '코니아', '트라브존', '아다나', '시바스', '디야르바키르'] },
    { k: 'mali', n: '말리', ld: '만사 무사', ab: '니제르의 노래', la: '사헬의 상인', fx: { goldP: 20, prodP: -10, desertY: [1, 0, 0, 0, 0, 1] },
      abd: '사막 칸 식량·신앙 +1, 생산 −10%.', lad: '금 +20%.', ag: { gold: 3 }, agn: '황금의 왕', agd: '부를 좋아해요.',
      cities: ['니아니', '팀북투', '가오', '젠네', '키나', '왈라타', '쿠쿠', '카바라', '타가자'] },
    { k: 'sweden', n: '스웨덴', ld: '크리스티나', ab: '노벨상', la: '미네르바의 서재', fx: { favor: 2, gppP: 15 },
      abd: '외교 호의 +2/턴.', lad: '위인 점수 +15%.', ag: { cul: 2, peace: 2 }, agn: '북방의 미네르바', agd: '걸작과 평화를 좋아해요.',
      cities: ['스톡홀름', '웁살라', '예테보리', '말뫼', '린셰핑', '외레브로', '칼마르', '베스테로스', '노르셰핑', '룰레오'] },
    { k: 'hungary', n: '헝가리', ld: '마티아스 1세', ab: '도나우강의 진주', la: '흑군', fx: { env: 2, riverDistP: 25 },
      abd: '강 건너 구역·건물 생산 +25%.', lad: '사절 영향력 +2.', ag: { war: 1, peace: 1 }, agn: '왕권', agd: '도시국가를 원해요.',
      cities: ['부다페스트', '데브레첸', '세게드', '미슈콜츠', '페치', '죄르', '니레지하저', '케치케메트', '에게르', '쇼프론'] },
    { k: 'inca', n: '잉카', ld: '파차쿠티', ab: '미타', la: '키파쿠나', fx: { mtnWork: 1, foodP: 5 },
      abd: '산에서 일할 수 있어요(생산 +2 · 식량 +1).', lad: '식량 +5%.', ag: { exp: 1, peace: 1 }, agn: '산의 제국', agd: '산을 사랑해요.',
      cities: ['쿠스코', '마추픽추', '키토', '카하마르카', '오얀타이탐보', '비트코스', '훌리', '파차카막', '와누코'] },
    { k: 'maori', n: '마오리', ld: '쿠페', ab: '마나', la: '쿠페의 항해', fx: { featY: [0, 1], loy: 3 },
      abd: '개선 안 된 숲·열대우림 생산 +1.', lad: '충성도 +3.', ag: { peace: 2, cul: 1 }, agn: '카이티아키탕아', agd: '자연을 지키는 나라를 좋아해요.',
      cities: ['오클랜드', '웰링턴', '로토루아', '타우랑가', '네이피어', '왕가누이', '기즈번', '넬슨', '와이탕기'] },
    { k: 'phoenicia', n: '페니키아', ld: '디도', ab: '지중해의 식민지', la: '카르타고의 여왕', fx: { loy: 10, pmNaval: 25 },
      abd: '도시 충성도 +10.', lad: '해상 유닛 생산 +25%.', ag: { gold: 2, exp: 1 }, agn: '사이프러스 왕국', agd: '바다 무역을 좋아해요.',
      cities: ['티레', '시돈', '비블로스', '카르타고', '우티카', '가데스', '모티아', '아크레', '아라두스'] },
    { k: 'persia', n: '페르시아', ld: '키루스', ab: '사트라피', la: '바빌론 함락', fx: { trg: 2, culP: 5 },
      abd: '교역로 금 +2, 문화 +5%. 고유 정원 파이리다에자.', lad: '전쟁을 선포하면 10턴 동안 이동 +2.', ag: { war: 2, gold: 1 }, agn: '왕 중의 왕', agd: '강한 나라를 견제해요.',
      cities: ['파사르가대', '페르세폴리스', '수사', '엑바타나', '바빌론', '사르디스', '박트라', '마라칸다', '타르소스'] },
    // ----- 흥망성쇠·몰려드는 폭풍·추가 팩 문명 -----
    { k: 'australia', n: '오스트레일리아', ld: '존 커틴', ab: '지구 반대편의 땅', la: '시민의 의용군', fx: { coastHous: 3, defProd: 1 },
      abd: '해안 도시 주거 +3. 매력이 높은 칸의 구역은 인접 +1.', lad: '전쟁 선포를 받으면 10턴 동안 생산 +100%.', ag: { exp: 2, peace: 1 }, agn: '방어 동맹', agd: '자기 대륙을 지키는 나라를 좋아해요.',
      cities: ['캔버라', '시드니', '멜버른', '브리즈번', '퍼스', '애들레이드', '호바트', '다윈', '뉴캐슬', '케언스'] },
    { k: 'babylon', n: '바빌론', ld: '함무라비', ab: '엔키의 지혜', la: '니누 일루', fx: { boostFull: 1, sciP: -50, freeFirstBld: 1 },
      abd: '유레카를 이루면 그 기술을 바로 완성해요. 대신 과학 −50%.', lad: '특수지구를 처음 지으면 그 구역의 첫 건물이 공짜.', ag: { sci: 3, won: 1 }, agn: '법전의 왕', agd: '앞선 과학을 시기해요.',
      cities: ['바빌론', '우르', '니푸르', '시파르', '키시', '보르시파', '마리', '에슈눈나', '아수르', '라르사'] },
    { k: 'byzantium', n: '비잔티움', ld: '바실리오스 2세', ab: '타그마타', la: '포르피로게니토스', fx: { csRelCiv: 3, 'cs.hc': 3 },
      abd: '내 종교가 과반인 문명마다 유닛 전투력·종교 전투력 +3.', lad: '중기병 전투력 +3, 같은 종교가 아닌 도시를 칠 때 피해 그대로.', ag: { rel: 2, war: 2 }, agn: '불가리아 학살자', agd: '같은 종교를 원해요.',
      cities: ['콘스탄티노폴리스', '테살로니카', '니케아', '안티오키아', '트레비존드', '에데사', '아드리아노폴리스', '스미르나', '아테네', '키프로스'] },
    { k: 'cree', n: '크리', ld: '파운드메이커', ab: '네히야웍', la: '식량 동맹', fx: { freeTraderTech: 'animal', trd: 1, routeFood: 1 },
      abd: '목축을 연구하면 상인을 하나 받고, 교역로 한도 +1.', lad: '교역로마다 출발 도시 식량 +1, 도착 도시 금 +1.', ag: { peace: 2, gold: 1, exp: 1 }, agn: '평원의 친구', agd: '교역하는 나라를 좋아해요.',
      cities: ['파운드메이커 보호구역', '사스카툰', '배틀포드', '리자이나', '프린스 앨버트', '무스 팩토리', '사틀 레이크', '헤이 리버', '앨버타 크리', '오넌'] },
    { k: 'ethiopia', n: '에티오피아', ld: '메넬리크 2세', ab: '아크숨의 유산', la: '에티오피아 고원 협의회', fx: { hillCs: 4, hillSci: 15, faithP: 5 },
      abd: '신앙 +5%. 고유 개선 「암굴 교회」.', lad: '언덕 도시는 신앙의 15%만큼 과학, 언덕 위 유닛 전투력 +4.', ag: { rel: 2, peace: 1, cul: 1 }, agn: '아드와의 승자', agd: '종교와 고원을 존중해요.',
      cities: ['아디스아바바', '악숨', '곤다르', '랄리벨라', '하라르', '메켈레', '바히르다르', '아다마', '데시에', '진카'] },
    { k: 'gaul', n: '갈리아', ld: '암비오릭스', ab: '할슈타트 문화', la: '켈트족의 왕', fx: { mineCul: 1, csAdjMel: 2 },
      abd: '광산 문화 +1. 고유 구역 「오피둠」.', lad: '근접·대기병 유닛은 붙어 있는 내 군사 유닛마다 전투력 +2.', ag: { war: 2, exp: 1 }, agn: '부족 전사', agd: '강한 이웃을 노려요.',
      cities: ['비브락테', '알레시아', '게르고비아', '아바리쿰', '부르디갈라', '루테티아', '케나붐', '두로코르토룸', '네메툼', '톨로사'] },
    { k: 'georgia', n: '조지아', ld: '타마르', ab: '강철의 성벽', la: '신앙의 수호 왕비', fx: { wallP: 50, faithP: 10, env: 1 },
      abd: '성벽 생산 +50%. 고유 건물 「치헤」(르네상스 성벽 대신, 관광·신앙).', lad: '신앙 +10%, 사절 영향력 +1.', ag: { rel: 2, peace: 1 }, agn: '왕 중의 왕비', agd: '같은 종교 동맹을 원해요.',
      cities: ['트빌리시', '쿠타이시', '므츠헤타', '바투미', '고리', '텔라비', '주그디디', '포티', '루스타비', '보르조미'] },
    { k: 'gcolombia', n: '그란 콜롬비아', ld: '시몬 볼리바르', ab: '애국 군대', la: '경이로운 원정', fx: { mv: 1, gpp: { gen: 2 } },
      abd: '모든 군사 유닛 이동 +1.', lad: '위대한 장군 점수 +2/턴.', ag: { war: 2, exp: 2 }, agn: '해방자', agd: '빠르게 움직이는 나라를 좋아해요.',
      cities: ['보고타', '카라카스', '키토', '파나마', '마라카이보', '메데인', '칼리', '바랑키야', '과야킬', '쿠쿠타'] },
    { k: 'indonesia', n: '인도네시아', ld: '기타르자', ab: '누산타라', la: '바다의 왕비', fx: { faithBuyNaval: 1, 'cs.nm': 3, 'cs.nr': 3, seaAdjFaith: 1 },
      abd: '바다에 붙은 성지·극장가 인접 +1.', lad: '신앙으로 해상 유닛 구매, 해상 유닛 전투력 +3.', ag: { rel: 2, exp: 1, gold: 1 }, agn: '섬의 여왕', agd: '바다 너머를 원해요.',
      cities: ['마자파힛', '자카르타', '수라바야', '반둥', '메단', '팔렘방', '마카사르', '덴파사르', '스마랑', '말랑'] },
    { k: 'khmer', n: '크메르', ld: '자야바르만 7세', ab: '바라이 대저수지', la: '신들의 왕', fx: { aqFarm: 2, hsRiver: 2, faithP: 5 },
      abd: '송수로에 붙은 농장 식량 +2. 고유 건물 「프라삿」(신전 대신).', lad: '강가 성지 인접 +2, 신앙 +5%.', ag: { rel: 2, peace: 1 }, agn: '사원의 왕', agd: '종교와 농사를 좋아해요.',
      cities: ['야소다라푸라', '하리하랄라야', '프놈 쿨렌', '바탐방', '삼보르', '앙코르 보레이', '시엠레아프', '프레이 노코르', '코 케르', '반테아이 츠마르'] },
    { k: 'macedon', n: '마케도니아', ld: '알렉산드로스', ab: '헬레니즘 융합', la: '세상 끝까지', fx: { conqBoost: 1, noWW: 1 },
      abd: '도시를 점령하면 유레카·영감을 하나씩 받아요.', lad: '전쟁 피로가 없어요. 고유 구역 「바실리코이 파이데스」.', ag: { war: 3, exp: 1 }, agn: '정복왕', agd: '전쟁을 두려워하지 않아요.',
      cities: ['펠라', '아이가이', '알렉산드리아', '암피폴리스', '필리포이', '디온', '테살로니카', '베로이아', '스타기라', '에데사'] },
    { k: 'mapuche', n: '마푸체', ld: '라우타로', ab: '토키 코나', la: '스윈하타의 계략', fx: { csGoldAge: 10, 'cs.lc': 3 },
      abd: '황금기·영웅 시대인 문명 상대 전투력 +10.', lad: '경기병 전투력 +3.', ag: { war: 2, cul: 1 }, agn: '저항의 지도자', agd: '거만한 황금기 나라를 싫어해요.',
      cities: ['테무코', '앙골', '타르카', '라우타로', '비야리카', '오소르노', '발디비아', '앙헬레스', '콘셉시온', '로타'] },
    { k: 'maya', n: '마야', ld: '6 하늘 여인', ab: '마야의 역법', la: '아하우의 장군', fx: { mayaCap: 1, farmHous: 1 },
      abd: '농장 주거 +0.5 더. 고유 구역 「천문대」(캠퍼스 대신, 농장·농원이 인접).', lad: '수도 6칸 안 도시 산출 +10%, 그 밖은 −15%.', ag: { sci: 2, peace: 1 }, agn: '천문학자 여왕', agd: '좁고 알찬 나라를 좋아해요.',
      cities: ['무툴', '칼라크물', '코판', '팔렝케', '야슈칠란', '치첸 이트사', '우샤말', '코바', '카라콜', '키리과'] },
    { k: 'nubia', n: '누비아', ld: '아마니토레', ab: '타 세티', la: '쿠시의 왕비', fx: { pm: [['rng'], 0, 8, 50], xpRng: 50, pmDist: 20 },
      abd: '원거리 유닛 생산 +50%, 경험치 +50%.', lad: '구역 생산 +20%. 고유 개선 「누비아 피라미드」.', ag: { war: 1, won: 1, gold: 1 }, agn: '활의 땅', agd: '피라미드와 궁수를 좋아해요.',
      cities: ['메로에', '나파타', '케르마', '카와', '무사와랏', '세데잉가', '사이', '부헨', '아마라', '솔레브'] },
    { k: 'poland', n: '폴란드', ld: '야드비가', ab: '황금의 자유', la: '레가티아', fx: { slot: [-1, 0, 0, 1], fortBomb: 1, faithP: 5 },
      abd: '군사 슬롯 하나가 와일드카드로. 요새·주둔지를 지으면 주변 칸을 차지해요.', lad: '신앙 +5%. 고유 건물 「수키엔니체」(시장 대신).', ag: { rel: 1, war: 1, exp: 1 }, agn: '성녀 왕비', agd: '같은 종교 이웃을 좋아해요.',
      cities: ['크라쿠프', '바르샤바', '그단스크', '포즈난', '브로츠와프', '우치', '루블린', '토룬', '비알리스토크', '슈체친'] },
    { k: 'portugal', n: '포르투갈', ld: '주앙 3세', ab: '열린 바다', la: '포르타 두 쿠아즈', fx: { trgP: 50, trd: 1, mvSea: 1 },
      abd: '외국 교역로 금 +50%.', lad: '교역로 한도 +1, 해상 이동 +1. 고유 개선 「페이토리아」.', ag: { gold: 3, exp: 1 }, agn: '항해 왕', agd: '바다 무역을 좋아해요.',
      cities: ['리스본', '포르투', '코임브라', '브라가', '파루', '에보라', '세투발', '아베이루', '고아', '마카오'] },
    { k: 'scotland', n: '스코틀랜드', ld: '로버트 브루스', ab: '스코틀랜드 계몽주의', la: '배넉번', fx: { happySci: 5, xpP: 10 },
      abd: '행복·열광 도시 과학·생산 +5%(열광 +10%).', lad: '경험치 +10%. 고유 개선 「골프장」.', ag: { sci: 2, peace: 1 }, agn: '자유의 왕', agd: '자유를 지키는 나라를 좋아해요.',
      cities: ['에든버러', '글래스고', '애버딘', '던디', '인버네스', '스털링', '퍼스', '세인트앤드루스', '에어', '포트윌리엄'] },
    { k: 'vietnam', n: '베트남', ld: '바 찌에우', ab: '구룡강 삼각주', la: '돌격하는 여인', fx: { featDist: 1, csFeat: 5 },
      abd: '구역을 숲·열대우림·습지에 지어도 특성이 남고, 그 구역 건물 산출 +1.', lad: '숲·열대우림·습지 위 유닛 전투력 +5. 고유 구역 「탄」.', ag: { war: 1, peace: 1, cul: 1 }, agn: '숲의 수호자', agd: '숲을 베는 나라를 싫어해요.',
      cities: ['탕롱', '후에', '사이공', '호이안', '다낭', '하이퐁', '꾸이년', '냐짱', '빈', '껀터'] },
    // ----- 다른 지도자(같은 문명) -----
    { k: 'greece_g', c: 'greece', n: '그리스', ld: '고르고', ab: '플라톤의 국가', la: '테르모필라이', fx: { slot: [0, 0, 0, 1], killCul: 50 },
      abd: '와일드카드 슬롯 +1.', lad: '적 유닛을 처치하면 그 전투력의 50%만큼 문화.', ag: { war: 2, cul: 1 }, agn: '스파르타의 여왕', agd: '강한 전사를 존중해요.',
      cities: ['스파르타', '아테네', '코린토스', '테베', '아르고스', '델포이', '에피다우로스', '올림피아', '로도스', '밀레토스'] },
    { k: 'india_c', c: 'india', n: '인도', ld: '찬드라굽타', ab: '다르마', la: '아르타샤스트라', fx: { faithP: 15, warMv: 1 },
      abd: '신앙 +15%.', lad: '전쟁을 선포하면 10턴 동안 이동 +2, 전투력 +5.', ag: { war: 2, exp: 2 }, agn: '마우리아 제국', agd: '정복을 노려요.',
      cities: ['파탈리푸트라', '델리', '바라나시', '아그라', '콜카타', '첸나이', '하이데라바드', '방갈로르', '자이푸르', '푸네'] },
    { k: 'england_e', c: 'england', n: '잉글랜드', ld: '아키텐의 엘레오노르', ab: '세계의 작업장', la: '사랑의 궁정', fx: { stratX: 2, prodP: 5, gwLoy: 1 },
      abd: '철·석탄 광산이 전략 자원을 더 줘요(+2).', lad: '걸작마다 이 도시 충성도 +1, 근처 외국 도시 충성도 −1.', ag: { cul: 3, exp: 1 }, agn: '두 왕국의 왕비', agd: '걸작을 많이 가진 나라를 탐내요.',
      cities: ['런던', '리버풀', '맨체스터', '요크', '버밍엄', '브리스톨', '옥스퍼드', '캠브리지', '노리치', '셰필드'] },
  ];
  // 추천 승리(성향에서)
  CIVS.forEach((c) => {
    const a = c.ag, v = [];
    if (a.war >= 2) v.push('dom'); if (a.sci >= 2) v.push('sci'); if (a.cul >= 2) v.push('cul'); if (a.rel >= 2) v.push('rel');
    if (a.peace >= 2 || a.gold >= 2) v.push('dip'); if (!v.length) v.push(a.won ? 'cul' : a.exp ? 'sci' : 'score');
    c.vic = v.slice(0, 2);
  });
  const CIVI = {}; CIVS.forEach((c, i) => { CIVI[c.k] = i; });
  // 고유 구역(기존 구역 대신)
  const UDIS = {
    korea: { cam: { n: '서원', d: '한국 전용(캠퍼스 대신). 기본 과학 +4, 붙은 구역마다 −1.' } },
    germany: { ind: { n: '한자', d: '독일 전용(산업구역 대신). 상업 중심지마다 +2, 자원마다 +1.' } },
    greece: { th: { n: '아크로폴리스', d: '그리스 전용(극장가 대신). 언덕에만, 붙은 구역마다 +1.' } },
    rome: { aq: { n: '로마 목욕탕', d: '로마 전용(송수로 대신). 주거 +2 더, 쾌적도 +1.' } },
    russia: { hs: { n: '라브라', d: '러시아 전용(성지 대신). 작가·예술가·음악가 점수 +1.' } },
    england: { hb: { n: '왕립 해군 조선소', d: '잉글랜드 전용(항만 대신). 금 +2, 해상 이동 +1.' } },
    brazil: { ent: { n: '거리 카니발', d: '브라질 전용(오락 단지 대신). 쾌적도 +1 더.' } },
    kongo: { nb: { n: '음반자', d: '콩고 전용(주거 지구 대신). 길드부터, 주거 +5, 식량 +2, 금 +4.' } },
    zulu: { enc: { n: '이칸다', d: '줄루 전용(주둔지 대신). 주거 +1, 원거리 공격.' } },
    mali: { com: { n: '수구바', d: '말리 전용(상업 중심지 대신). 이 도시 금 구매 −20%, 성지 인접 +2.' } },
    phoenicia: { hb: { n: '코톤', d: '페니키아 전용(항만 대신). 해상 유닛·개척자 생산 +50%.' } },
    byzantium: { ent: { n: '히포드롬', d: '비잔티움 전용(오락 단지 대신). 쾌적도 +1 더, 지으면 중기병 하나가 공짜.' } },
    gaul: { ind: { n: '오피둠', d: '갈리아 전용(산업구역 대신). 도심 옆에 지을 수 없고 광산·채석장마다 인접 +1 더.' } },
    macedon: { enc: { n: '바실리코이 파이데스', d: '마케도니아 전용(주둔지 대신). 군사 유닛을 만들 때 그 비용의 25%만큼 과학.' } },
    maya: { cam: { n: '천문대', d: '마야 전용(캠퍼스 대신). 농원마다 +2, 농장마다 +1(구역 인접은 반).' } },
    vietnam: { enc: { n: '탄', d: '베트남 전용(주둔지 대신). 숲·열대우림·습지에도. 문화 +2, 주변 매력 +1.' } },
  };
  // 문명 키(다른 지도자는 같은 문명)
  CIVS.forEach((c) => { if (!c.c) c.c = c.k; });

  /* ======================= 도시국가 ======================= */
  const CST = { sci: ['과학', 3, 'cam', '#5b9ad8'], cul: ['문화', 4, 'th', '#b06ad0'], trd: ['무역', 2, 'com', '#e0b030'], mil: ['군사', 1, 'enc', '#d0504a'], rel: ['종교', 5, 'hs', '#e8e4d0'], ind: ['산업', 1, 'ind', '#e08a3a'] };
  const CSL = [
    ['제네바', 'sci', { sciP: 10 }, '과학 +10%'], ['하투사', 'sci', { stratX: 1 }, '전략 자원 +1/턴'], ['스톡홀름', 'sci', { gppAll: 1 }, '모든 위인 점수 +1'], ['타루가', 'sci', { sciP: 5, stratX: 1 }, '과학 +5%, 전략 +1'],
    ['빌뉴스', 'cul', { culP: 10 }, '문화 +10%'], ['볼로냐', 'cul', { gppAll: 1 }, '위인 점수 +1'], ['쿠마시', 'cul', { culP: 5, trg: 1 }, '문화 +5%, 교역 금 +1'], ['모헨조다로', 'cul', { hous: 1 }, '모든 도시 주거 +1'],
    ['리스본', 'trd', { trg: 2 }, '교역로 금 +2'], ['잔지바르', 'trd', { amen: 1 }, '모든 도시 쾌적도 +1'], ['자카르타', 'trd', { trg: 2 }, '교역로 금 +2'], ['무탐', 'trd', { goldP: 10 }, '금 +10%'],
    ['카불', 'mil', { xpP: 50 }, '경험치 +50%'], ['발레타', 'mil', { cityCS: 4 }, '도시 방어 +4'], ['프레슬라프', 'mil', { 'cs.lc': 3, 'cs.hc': 3 }, '기병 +3'], ['응가자르가무', 'mil', { pm: [['mel', 'rng', 'ac', 'lc', 'hc', 'sg'], 0, 8, 10] }, '지상 유닛 생산 +10%'],
    ['예루살렘', 'rel', { faithP: 10 }, '신앙 +10%'], ['칸디', 'rel', { faithP: 5, relcs: 3 }, '신앙 +5%, 종교 전투 +3'], ['예레반', 'rel', { relSpread: 1 }, '전파 +1'], ['라벤타', 'rel', { faithP: 5, culP: 5 }, '신앙·문화 +5%'],
    ['브뤼셀', 'ind', { wonderP: 15 }, '불가사의 생산 +15%'], ['홍콩', 'ind', { prjP: 20 }, '프로젝트 생산 +20%'], ['오클랜드', 'ind', { seaProd: 1 }, '바다 칸 생산 +1'], ['부에노스아이레스', 'ind', { luxAmen: 1 }, '사치 자원 쾌적도 +1'],
  ].map((a, i) => ({ id: i, n: a[0], t: a[1], fx: a[2], d: a[3] }));

  /* ======================= 총독 ======================= */
  const GOVR = [
    { k: 'pingala', n: '핑갈라', t: '교육자', fx: { cSciP: 15, cCulP: 15 }, d: '이 도시 과학·문화 +15%.', pr: [['연구 보조금', { cGpp: 3 }, '이 도시 위인 점수 +3'], ['문화 관료', { cSciP: 15, cCulP: 15 }, '과학·문화 +15% 더']] },
    { k: 'magnus', n: '마그누스', t: '집사', fx: { cProdP: 10, cNoPop: 1 }, d: '생산 +10%, 개척자를 만들어도 인구가 줄지 않아요.', pr: [['산업가', { cProd: 3 }, '생산 +3'], ['공급 물류', { cFoodP: 20 }, '식량 +20%']] },
    { k: 'reyna', n: '레이나', t: '재무관', fx: { cGoldP: 20 }, d: '이 도시 금 +20%.', pr: [['세리', { cTileP: -50 }, '타일 구매 −50%'], ['해외 무역', { cGold: 6 }, '금 +6']] },
    { k: 'amani', n: '아마니', t: '외교관', fx: { cLoy: 4, cAmen: 1 }, d: '충성도 +4, 쾌적도 +1.', pr: [['사절단', { env: 2 }, '사절 영향력 +2'], ['친선 대사', { favor: 2 }, '외교 호의 +2']] },
    { k: 'victor', n: '빅터', t: '성주', fx: { cCityCS: 5, cLoy: 4 }, d: '도시 방어 +5, 충성도 +4.', pr: [['수비대 사령관', { cWallP: 100, cCityCS: 3 }, '성벽 생산 2배'], ['방어 전문가', { cCityCS: 7 }, '도시 방어 +7 더']] },
    { k: 'liang', n: '량', t: '측량사', fx: { cChg: 1 }, d: '여기서 만든 건설자 충전 +1.', pr: [['수로 기술자', { cHous: 2 }, '주거 +2'], ['공원 관리', { cAmen: 1 }, '쾌적도 +1']] },
    { k: 'moksha', n: '목샤', t: '추기경', fx: { cFaithD: 2 }, d: '이 도시 특수지구마다 신앙 +2.', pr: [['신앙 공동체', { cPressP: 100 }, '종교 압력 2배'], ['거룩한 의식', { cFaithP: 20 }, '신앙 +20%']] },
  ];

  /* ======================= 시대 헌신(흥망성쇠) ======================= */
  const DEDI = [
    { k: 'free', n: '자유 탐구', fx: { sciP: 10 }, d: '과학 +10%(황금기면 +20%).' },
    { k: 'monument', n: '기념비 시대', fx: { pmk: { settler: 30, builder: 30 }, loy: 2 }, d: '개척자·건설자 생산 +30%, 충성도 +2.' },
    { k: 'exodus', n: '복음 전도사들의 대이동', fx: { faithP: 15, relSpread: 1 }, d: '신앙 +15%, 전파 +1.' },
    { k: 'pen', n: '펜, 붓, 목소리', fx: { culP: 10, gppAll: 1 }, d: '문화 +10%, 위인 점수 +1.' },
    { k: 'coin', n: '화폐 개혁', fx: { goldP: 15 }, d: '금 +15%.' },
    { k: 'conquer', n: '정복자의 행진', fx: { cs: 3, xpP: 25 }, d: '전투력 +3, 경험치 +25%.' },
    { k: 'sky', n: '하늘과 별', fx: { prjP: 25 }, d: '프로젝트 생산 +25%.' },
  ];
  const AGEN = ['암흑기', '보통 시대', '황금기', '영웅 시대'];

  /* ======================= 세계 의회(몰려드는 폭풍) ======================= */
  const RESO = [
    { k: 'dvp', n: '외교 승리', tg: 'p', a: '대상 외교 승리 점수 +2', b: '대상 외교 승리 점수 −2' },
    { k: 'udt', n: '도시 개발 조약', tg: 'd', a: '그 구역 생산 +100%', b: '그 구역 생산 −50%' },
    { k: 'merc', n: '용병단', tg: 'p', a: '대상 유닛 업그레이드 −50%', b: '대상 유닛 업그레이드 +50%' },
    { k: 'patron', n: '위인 후원', tg: 'g', a: '그 위인 점수 +100%', b: '그 위인 점수 없음' },
    { k: 'trade', n: '무역 정책', tg: 'p', a: '대상 교역로 금 +4', b: '대상 교역로 금 −4' },
    { k: 'heritage', n: '세계 유산 기구', tg: 'p', a: '대상 불가사의 문화 +3', b: '대상 불가사의 문화 −2' },
    { k: 'arms', n: '군비 통제', tg: 'p', a: '대상 유닛 생산 −25%', b: '대상 유닛 생산 +25%' },
  ];

  /* ======================= 기후·재해 ======================= */
  const CLIM = ['안정', '1단계', '2단계', '3단계', '4단계', '5단계', '6단계', '7단계'];
  const CO2_STEP = [0, 150, 350, 600, 900, 1250, 1650, 2100];   // 누적 이산화탄소 → 기후 단계
  const DISN = { nuke: '핵폭발', flood: '홍수', volc: '화산 분화', storm: '폭풍', drought: '가뭄', bliz: '눈보라', dust: '모래 폭풍' };

  /* ======================= 육각 지도 기하 ======================= */
  // 홀수 줄이 오른쪽으로 반 칸 밀린 육각(odd-r). 이웃 순서: 동, 남동, 남서, 서, 북서, 북동
  const GEO = {};
  // wrap: 동서가 이어진 지도(맨 오른쪽 칸 옆이 맨 왼쪽 칸)
  function geo(W, H, wrap) {
    const key = W + 'x' + H + (wrap ? 'w' : '');
    if (GEO[key]) return GEO[key];
    const N = W * H, nb = new Array(N), nb6 = new Array(N), cx = new Int16Array(N), cz = new Int16Array(N);
    for (let r = 0; r < H; r++) for (let c = 0; c < W; c++) {
      const i = r * W + c, odd = r & 1;
      const d = odd ? [[0, 1], [1, 1], [1, 0], [0, -1], [-1, 0], [-1, 1]] : [[0, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0]];
      const a = [], a6 = [];
      for (const [dr, dc] of d) { const rr = r + dr; let cc = c + dc; if (wrap) cc = (cc + W) % W; const j = rr >= 0 && rr < H && cc >= 0 && cc < W ? rr * W + cc : -1; a6.push(j); if (j >= 0) a.push(j); }
      nb[i] = a; nb6[i] = a6;
      cx[i] = c - ((r - odd) >> 1); cz[i] = r;
    }
    return (GEO[key] = { W, H, N, nb, nb6, cx, cz, rings: {}, wrap: !!wrap });
  }
  function hexDist(g, a, b) {
    const ax = g.cx[a], az = g.cz[a], bx = g.cx[b], bz = g.cz[b];
    const dz = az - bz; let dx = ax - bx;
    let d = Math.max(Math.abs(dx), Math.abs(dx + dz), Math.abs(dz));
    if (g.wrap) { const W = g.W; for (const sh of [W, -W]) { const ex = dx + sh; const e = Math.max(Math.abs(ex), Math.abs(ex + dz), Math.abs(dz)); if (e < d) d = e; } }
    return d;
  }
  function within(g, i, rad) {
    const key = i * 16 + rad;
    const ca = g.rings[key]; if (ca) return ca;
    const out = [], W = g.W, H = g.H, r0 = (i / W) | 0, c0 = i % W, seen = {};
    for (let r = Math.max(0, r0 - rad); r <= Math.min(H - 1, r0 + rad); r++)
      for (let c = c0 - rad - 1; c <= c0 + rad + 1; c++) {
        let cc = c; if (g.wrap) cc = ((c % W) + W) % W; else if (c < 0 || c >= W) continue;
        const j = r * W + cc; if (seen[j]) continue; seen[j] = 1; if (hexDist(g, i, j) <= rad) out.push(j);
      }
    if (Object.keys(g.rings).length < 60000) g.rings[key] = out;
    return out;
  }
  // 강(칸의 변): 칸 i의 동·남동·남서 변(0~2)을 비트로. 다른 변은 이웃 칸이 가져요.
  function riverEdge(g, re, a, b) { const k = g.nb6[a].indexOf(b); if (k < 0) return 0; return k < 3 ? (re[a] >> k) & 1 : (re[b] >> (k - 3)) & 1; }
  function riverTiles(g, re) { const riv = new Uint8Array(g.N); for (let i = 0; i < g.N; i++) for (let k = 0; k < 6; k++) { const j = g.nb6[i][k]; if (j >= 0 && riverEdge(g, re, i, j)) { riv[i] = 1; break; } } return riv; }

  /* ======================= 지도 만들기 ======================= */
  const MAPT = ['대륙', '판게아', '군도', '작은 대륙들', '무작위 지형'];
  const MAPS = [{ n: '작게', W: 30, H: 20, nw: 3 }, { n: '보통', W: 38, H: 24, nw: 4 }, { n: '크게', W: 46, H: 28, nw: 6 }];
  function makeNoise(seed) {
    const rr = rng(seed), P = new Float32Array(512);
    for (let i = 0; i < 512; i++) P[i] = rr();
    const h = (x, y) => { let k = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263); k = Math.imul(k ^ (k >>> 13), 1274126177); return P[(k ^ (k >>> 16)) & 511]; };
    const sm = (t) => t * t * (3 - 2 * t);
    const v = (x, y) => {
      const xi = Math.floor(x), yi = Math.floor(y), xf = sm(x - xi), yf = sm(y - yi);
      const a = h(xi, yi), b = h(xi + 1, yi), c = h(xi, yi + 1), d = h(xi + 1, yi + 1);
      return a + (b - a) * xf + (c - a) * yf + (a - b - c + d) * xf * yf;
    };
    return (x, y, oct) => { let s = 0, amp = 1, f = 1, tot = 0; for (let o = 0; o < (oct || 4); o++) { s += v(x * f + o * 17.3, y * f + o * 9.1) * amp; tot += amp; amp *= 0.5; f *= 2; } return s / tot; };
  }
  function parseOn(on) { return on.split(',').map((tok) => { const [a, f] = tok.split(':'); return { t: a[0], h: a.length > 1 && a[1] === 'h', f: f || null }; }); }
  const TL = { g: TG, p: TP, d: TD, t: TT, s: TS };
  RES.forEach((r) => { if (r) r.onP = parseOn(r.on); });
  function resFits(r, ter, hill, feat) {
    for (const o of r.onP) {
      if (o.t === 'w') { if (ter === TC && (!feat || feat === F_REEF)) return true; continue; }
      if (TL[o.t] !== ter || !!o.h !== !!hill) continue;
      const fk = feat && feat < NW0 && FEAT[feat] ? FEAT[feat].k : null;
      if (o.f ? fk === o.f : !fk) return true;
    }
    return false;
  }

  function genMap(seed, W, H, type, nMaj, nCS, nNW, wrap) {
    const g = geo(W, H, wrap), N = g.N, rr = rng(seed);
    const nz = makeNoise(seed), nz2 = makeNoise(seed + 77), nz3 = makeNoise(seed + 991), nz4 = makeNoise(seed + 4242);
    const sc = 7 / Math.max(W, H);
    const elev = new Float32Array(N), ter = new Uint8Array(N), hill = new Uint8Array(N), riv = new Uint8Array(N), feat = new Uint8Array(N), res = new Uint8Array(N), low = new Uint8Array(N);
    // 땅 모양
    const blobs = [];
    if (type === 0) { blobs.push([0.27 + rr() * 0.06, 0.5, 0.36, 0.42]); blobs.push([0.73 - rr() * 0.06, 0.5, 0.36, 0.42]); }
    else if (type === 1) blobs.push([0.5, 0.5, 0.55, 0.5]);
    else if (type === 2) { const k = 10 + ((W * H) / 120 | 0); for (let i = 0; i < k; i++) blobs.push([0.08 + rr() * 0.84, 0.12 + rr() * 0.76, 0.06 + rr() * 0.07, 0.07 + rr() * 0.08]); }
    else if (type === 3) { const k = 4 + (rr() * 3 | 0); for (let i = 0; i < k; i++) blobs.push([0.12 + rr() * 0.76, 0.18 + rr() * 0.64, 0.14 + rr() * 0.08, 0.16 + rr() * 0.1]); }
    for (let i = 0; i < N; i++) {
      const r = (i / W) | 0, c = i % W, x = (c + 0.5 * (r & 1)) / W, y = r / H;
      let base;
      if (type === 4) base = nz(x * W * sc * 1.3, y * H * sc * 1.3, 5);
      else {
        let m = 0;
        for (const b of blobs) { const dx = (x - b[0]) / b[2], dy = (y - b[1]) / b[3]; m = Math.max(m, 1 - Math.sqrt(dx * dx + dy * dy)); }
        base = m * 0.9 + nz(x * W * sc, y * H * sc, 5) * 0.55;
      }
      const ex = Math.min(c, W - 1 - c), ey = Math.min(r, H - 1 - r);
      if (ex < 2) base -= 0.5 * (2 - ex); if (ey < 2) base -= 0.4 * (2 - ey);
      elev[i] = base;
    }
    const landFrac = [0.36, 0.38, 0.27, 0.33, 0.4][type];
    const sorted = Array.from(elev).sort((a, b) => b - a), thr = sorted[Math.floor(N * landFrac)];
    const land = new Uint8Array(N);
    for (let i = 0; i < N; i++) land[i] = elev[i] > thr ? 1 : 0;
    // 산·언덕
    const hgt = new Float32Array(N), landIdx = [];
    for (let i = 0; i < N; i++) if (land[i]) { const r = (i / W) | 0, c = i % W; hgt[i] = (elev[i] - thr) * 0.6 + nz2(c * 0.35, r * 0.35, 3) * 0.8; landIdx.push(i); }
    const hs = landIdx.slice().sort((a, b) => hgt[b] - hgt[a]);
    const nM = Math.floor(hs.length * 0.075), nH = Math.floor(hs.length * 0.2);
    for (let k = 0; k < hs.length; k++) { const i = hs[k]; if (k < nM) ter[i] = TM; else if (k < nM + nH && rr() < 0.85) hill[i] = 1; }
    // 기후
    for (const i of landIdx) {
      if (ter[i] === TM) continue;
      const r = (i / W) | 0, c = i % W, lat = Math.abs(r / (H - 1) - 0.5) * 2;
      const temp = 1 - lat + (nz3(c * 0.25, r * 0.25, 3) - 0.5) * 0.35, mo = nz4(c * 0.22, r * 0.22, 4);
      let t;
      if (temp < 0.13) t = TS; else if (temp < 0.27) t = TT;
      else if (mo < 0.36 && temp > 0.5) t = TD;
      else if (mo > 0.52) t = TG; else t = mo > 0.44 ? (rr() < 0.5 ? TG : TP) : TP;
      ter[i] = t;
      if (t === TS) hill[i] = hill[i] && rr() < 0.4 ? 1 : 0;
      // 특성
      if (t === TG || t === TP) {
        if (temp > 0.74 && mo > 0.52 && rr() < 0.6) feat[i] = F_RAIN;
        else if (mo > 0.5 && rr() < 0.42) feat[i] = F_WOODS;
        else if (!hill[i] && t === TG && mo > 0.6 && rr() < 0.12) feat[i] = F_MARSH;
      } else if (t === TT && mo > 0.45 && rr() < 0.4) feat[i] = F_WOODS;
      elev[i] = hgt[i];
    }
    // 바다·호수
    const comp = new Int32Array(N).fill(-1), compSize = [], compEdge = [];
    for (let i = 0; i < N; i++) {
      if (land[i] || comp[i] >= 0) continue;
      const id = compSize.length, st = [i]; comp[i] = id; let n = 0, edge = false;
      while (st.length) { const j = st.pop(); n++; const r = (j / W) | 0, c = j % W; if (r === 0 || c === 0 || r === H - 1 || c === W - 1) edge = true; for (const k of g.nb[j]) if (!land[k] && comp[k] < 0) { comp[k] = id; st.push(k); } }
      compSize.push(n); compEdge.push(edge);
    }
    for (let i = 0; i < N; i++) if (!land[i]) {
      const lake = !compEdge[comp[i]] && compSize[comp[i]] <= 7;
      if (lake) ter[i] = TLK; else ter[i] = g.nb[i].some((j) => land[j]) ? TC : TO;
    }
    // 대양 옆 얕은 바다를 조금 넓혀요
    for (let i = 0; i < N; i++) if (ter[i] === TO && g.nb[i].some((j) => ter[j] === TC && g.nb[j].filter((k) => land[k]).length >= 3) && rr() < 0.35) ter[i] = TC;
    // 극지방 빙하
    for (let i = 0; i < N; i++) { const r = (i / W) | 0; if ((r <= 1 || r >= H - 2) && TER[ter[i]].water && ter[i] !== TLK && rr() < (r === 0 || r === H - 1 ? 0.7 : 0.3)) feat[i] = F_ICE; }
    // 강(칸 사이 변을 따라 흘러요): 꼭짓점 = 세 칸, 변 = 두 칸
    const re = new Uint8Array(N);
    const isWt = (i) => !!TER[ter[i]].water;
    const evl = (i) => (isWt(i) ? -5 : ter[i] === TM ? elev[i] + 0.6 : elev[i]);
    const common = (a, b) => g.nb[a].filter((x) => g.nb[b].indexOf(x) >= 0);
    const setE = (a, b) => { const k = g.nb6[a].indexOf(b); if (k < 0) return; if (k < 3) re[a] |= 1 << k; else re[b] |= 1 << (k - 3); };
    const nRiv = Math.max(4, Math.round(landIdx.length / 16));
    const srcs = landIdx.filter((i) => ter[i] !== TS && (hill[i] || ter[i] === TM || g.nb[i].some((j) => ter[j] === TM)) && !g.nb[i].some(isWt));
    for (let k = 0; k < nRiv * 3 && srcs.length; k++) {
      const A = srcs.splice((rr() * srcs.length) | 0, 1)[0];
      const nbA = g.nb[A].filter((j) => !isWt(j)); if (!nbA.length) continue;
      const B = nbA[(rr() * nbA.length) | 0], cm = common(A, B).filter((j) => !isWt(j)); if (!cm.length) continue;
      let V = [A, B, cm[0]], prev = null; const path = [], seenV = {};
      let ok = false;
      for (let step = 0; step < 34; step++) {
        const key = V.slice().sort((x, y) => x - y).join(','); if (seenV[key]) break; seenV[key] = 1;
        if (V.some(isWt)) { ok = true; break; }
        let best = null, bv = 1e9;
        for (const [x, y] of [[V[0], V[1]], [V[1], V[2]], [V[0], V[2]]]) {
          if (prev && ((prev[0] === x && prev[1] === y) || (prev[0] === y && prev[1] === x))) continue;
          if (isWt(x) || isWt(y) || (ter[x] === TM && ter[y] === TM)) continue;
          const z = common(x, y).find((t) => V.indexOf(t) < 0); if (z == null) continue;
          const v = evl(x) + evl(y) + evl(z) * 0.7 + rr() * 0.35;
          if (v < bv) { bv = v; best = [x, y, z]; }
        }
        if (!best) break;
        path.push([best[0], best[1]]);
        if (riverEdge(g, re, best[0], best[1])) { ok = true; break; }
        prev = [best[0], best[1]]; V = best;
      }
      if (ok && path.length >= 3) { for (const [x, y] of path) setE(x, y); }
      if (srcs.length && k > nRiv * 2) break;
    }
    const rt = riverTiles(g, re); for (let i = 0; i < N; i++) riv[i] = rt[i];
    // 범람원
    for (const i of landIdx) if (riv[i] && !hill[i] && ter[i] !== TM && !feat[i]) {
      if (ter[i] === TD && rr() < 0.75) feat[i] = F_FLOOD; else if ((ter[i] === TG || ter[i] === TP) && rr() < 0.25) feat[i] = F_FLOOD;
    }
    // 오아시스
    for (const i of landIdx) if (ter[i] === TD && !hill[i] && !feat[i] && !riv[i] && rr() < 0.05) feat[i] = F_OASIS;
    // 암초
    for (let i = 0; i < N; i++) if (ter[i] === TC && !feat[i] && rr() < 0.07) feat[i] = F_REEF;
    // 화산
    const mtns = landIdx.filter((i) => ter[i] === TM);
    for (const i of mtns) if (rr() < 0.08) feat[i] = F_VOLC;
    // 자연경관
    const used = {};
    for (let k = 0; k < nNW; k++) {
      for (let tr = 0; tr < 40; tr++) {
        const w = (rr() * NW.length) | 0; if (used[w]) continue;
        const def = NW[w];
        let cand;
        if (def.mtn) cand = mtns.filter((i) => !feat[i] && g.nb[i].some((j) => !TER[ter[j]].water && ter[j] !== TM));
        else if (def.water) cand = []; else cand = landIdx.filter((i) => ter[i] !== TM && !feat[i] && !riv[i] && ter[i] !== TS);
        if (def.water) for (let i = 0; i < N; i++) if (ter[i] === TC && !feat[i] && g.nb[i].some((j) => land[j])) cand.push(i);
        if (!cand.length) continue;
        const i = cand[(rr() * cand.length) | 0];
        feat[i] = NW0 + w; used[w] = 1; if (!def.mtn && !def.water) hill[i] = 0;
        if (def.volc) { /* 분화하는 경관 */ }
        break;
      }
    }
    // 자원
    const lux = [], bon = [], str = [];
    RES.forEach((r, i) => { if (!r) return; (r.c === 'l' ? lux : r.c === 'b' ? bon : str).push(i); });
    const luxPick = U.shuffle ? lux.slice().sort(() => rr() - 0.5) : lux;
    const luxUse = luxPick.slice(0, Math.min(lux.length, 10 + (W * H > 900 ? 6 : 3)));
    for (let i = 0; i < N; i++) {
      const t = ter[i]; if (t === TM || t === TO || t === TLK || (feat[i] >= NW0) || feat[i] === F_ICE || feat[i] === F_OASIS) continue;
      const p = rr(); let pool = null;
      if (TER[t].water) { if (p < 0.13) pool = rr() < 0.55 ? bon : rr() < 0.75 ? luxUse : str; }
      else if (p < 0.075) pool = bon; else if (p < 0.115) pool = luxUse; else if (p < 0.15) pool = str;
      if (!pool) continue;
      const fits = pool.filter((k) => resFits(RES[k], t, hill[i], feat[i]));
      if (!fits.length) continue;
      // 사치 자원은 덩어리로: 이웃에 같은 게 있으면 우선
      let k = fits[(rr() * fits.length) | 0];
      for (const j of g.nb[i]) if (res[j] && fits.indexOf(res[j]) >= 0 && rr() < 0.6) { k = res[j]; break; }
      res[i] = k;
    }
    // 저지대(해수면 상승 대상)
    const coastal = landIdx.filter((i) => ter[i] !== TM && !hill[i] && g.nb[i].some((j) => ter[j] === TC || ter[j] === TO));
    coastal.sort((a, b) => elev[a] - elev[b]);
    for (let k = 0; k < coastal.length * 0.36; k++) low[coastal[k]] = k < coastal.length * 0.12 ? 1 : k < coastal.length * 0.24 ? 2 : 3;
    // 땅덩어리
    const lcomp = new Int32Array(N).fill(-1), lsize = [];
    for (let i = 0; i < N; i++) {
      if (!land[i] || lcomp[i] >= 0) continue;
      const id = lsize.length, st = [i]; lcomp[i] = id; let n = 0;
      while (st.length) { const j = st.pop(); n++; for (const k of g.nb[j]) if (land[k] && lcomp[k] < 0) { lcomp[k] = id; st.push(k); } }
      lsize.push(n);
    }
    // 출발 자리
    const fresh = (i) => riv[i] || g.nb[i].some((j) => ter[j] === TLK || feat[j] === F_OASIS);
    const siteScore = (i) => {
      if (!land[i] || ter[i] === TM || ter[i] === TS || feat[i] >= NW0 || feat[i] === F_MARSH) return -1;
      let s = 0;
      for (const j of within(g, i, 2)) {
        const t = ter[j]; if (t === TM) { s += 0.3; continue; }
        const y = TER[t].y; s += y[0] * 1.1 + y[1] + y[2] * 0.4 + (hill[j] ? 1 : 0);
        if (feat[j] && feat[j] < NW0 && FEAT[feat[j]].y) s += (FEAT[feat[j]].y[0] || 0) + (FEAT[feat[j]].y[1] || 0) * 0.8;
        if (res[j]) s += RES[res[j]].c === 'l' ? 2 : 1.4;
        if (t === TS || t === TD) s -= 1; if (t === TO) s -= 0.6;
      }
      if (fresh(i)) s += 6; else if (g.nb[i].some((j) => ter[j] === TC)) s += 3;
      if (hill[i]) s += 2;
      if (ter[i] === TT || ter[i] === TD) s -= 5;
      if (lsize[lcomp[i]] < 10) s -= 12; else if (lsize[lcomp[i]] < 20) s -= 4;
      const r = (i / W) | 0, c = i % W; if (r < 2 || r > H - 3 || c < 2 || c > W - 3) s -= 10;
      return s;
    };
    const scores = new Float32Array(N); for (let i = 0; i < N; i++) scores[i] = siteScore(i);
    const cands = []; for (let i = 0; i < N; i++) if (scores[i] > 0) cands.push(i);
    cands.sort((a, b) => scores[b] - scores[a]);
    function pickSpread(n, minD, avoid) {
      for (let D = minD; D >= 3; D--) {
        const out = [];
        for (const i of cands) {
          if (out.length >= n) break;
          if (avoid.some((a) => hexDist(g, a, i) < Math.max(4, D - 2))) continue;
          if (out.some((a) => hexDist(g, a, i) < D)) continue;
          out.push(i);
        }
        if (out.length >= n) return out;
      }
      return cands.slice(0, n);
    }
    const minD = Math.max(5, Math.floor(Math.sqrt(landIdx.length / Math.max(2, nMaj)) * 1.05));
    // 너무 나쁜 자리는 피하려고 위쪽 60%에서 뽑아요
    const starts = pickSpread(nMaj, minD, []);
    const csStarts = pickSpread(nCS, Math.max(4, minD - 2), starts).filter((i) => starts.every((s) => hexDist(g, s, i) >= 4));
    // 출발지 근처 전략 자원 보장(말·철)
    for (const s of starts) {
      for (const rk of ['horses', 'iron']) {
        const ri2 = RESI[rk];
        const near = within(g, s, 4).filter((j) => j !== s);
        if (near.some((j) => res[j] === ri2)) continue;
        const ok = near.filter((j) => !res[j] && resFits(RES[ri2], ter[j], hill[j], feat[j]));
        if (ok.length) res[ok[(rr() * ok.length) | 0]] = ri2;
      }
      // 출발지에는 자원·특성 없이
      res[s] = 0; if (feat[s] && feat[s] !== F_FLOOD) feat[s] = 0;
    }
    for (const s of csStarts) { res[s] = 0; if (feat[s] && feat[s] !== F_FLOOD) feat[s] = 0; }
    return { ter, hill, riv, re, feat, res, low, starts, csStarts, lcomp };
  }

  /* ======================= 상태 ↔ 작업용 구조 ======================= */
  function decStr(s, N) { const a = new Uint8Array(N); for (let i = 0; i < N && i < s.length; i++) a[i] = B64I[s[i]] || 0; return a; }
  function encStr(a) { let o = ''; for (let i = 0; i < a.length; i++) o += B64[a[i] & 63]; return o; }
  function decBits(s, N) { const a = new Uint8Array(N); for (let i = 0; i < N; i++) { const ch = s[(i / 6) | 0]; if (ch && (B64I[ch] >> (i % 6)) & 1) a[i] = 1; } return a; }
  function encBits(a) { let s = ''; for (let i = 0; i < a.length; i += 6) { let v = 0; for (let b = 0; b < 6 && i + b < a.length; b++) if (a[i + b]) v |= 1 << b; s += B64[v]; } return s; }
  const bitHas = (str, i) => str.charCodeAt(i) === 49;   // '1'
  const bitSet = (str, i) => str.slice(0, i) + '1' + str.slice(i + 1);

  function ctx(s) {
    const g = geo(s.W, s.H, s.wr), N = g.N;
    const G = { s, g, N, W: s.W, H: s.H, md: {}, yc: {}, P: s.P, C: s.C, U: s.U };
    const mt = decStr(s.mt, N);
    G.ter = new Uint8Array(N); G.hill = new Uint8Array(N); G.riv = new Uint8Array(N);
    for (let i = 0; i < N; i++) { G.ter[i] = mt[i] & 15; G.hill[i] = (mt[i] >> 4) & 1; G.riv[i] = (mt[i] >> 5) & 1; }
    G.feat = decStr(s.mf, N); G.res = decStr(s.mr, N); G.low = decStr(s.ml, N);
    G.re = decStr(s.re || '', N); G.riv = riverTiles(g, G.re);
    G.imp = decStr(s.im, N); G.pil = s.pl ? decBits(s.pl, N) : new Uint8Array(N);
    G.road = decStr(s.rd, N);
    const ds = decStr(s.ds, N); G.dis = new Uint8Array(N); G.dpil = new Uint8Array(N);
    for (let i = 0; i < N; i++) { G.dis[i] = ds[i] & 31; G.dpil[i] = (ds[i] >> 5) & 1; }
    // 드문 칸 정보(불가사의·비옥해진 땅)는 {칸: 값}으로
    G.won = new Uint8Array(N); G.fy = new Uint8Array(N);
    for (const k in (s.wn || {})) G.won[+k] = s.wn[k]; for (const k in (s.fy || {})) G.fy[+k] = s.fy[k];
    G.own = new Int16Array(N); for (let i = 0; i < N; i++) G.own[i] = d2(s.ow, i * 2) - 1;
    G.ex = s.ex.map((e) => decBits(e, N));
    G.lc = decStr(s.lc || '', N);
    untidy(s);
    reindex(G);
    return G;
  }
  function reindex(G) {
    G.cid = {}; for (const c of G.C) G.cid[c.id] = c;
    G.cat = new Int16Array(G.N).fill(-1); for (const c of G.C) G.cat[c.p] = c.id;
    G.uid = {}; G.mil = new Int32Array(G.N).fill(-1); G.civ = new Int32Array(G.N).fill(-1);
    for (const u of G.U) { G.uid[u.id] = u; const cl = UT[u.t].cl; if (isGround(u.t)) G.mil[u.p] = u.id; else if (cl === 'civ' || cl === 'sup') G.civ[u.p] = u.id; }
  }
  function commit(G) {
    const s = G.s, N = G.N;
    const mt = new Uint8Array(N); for (let i = 0; i < N; i++) mt[i] = G.ter[i] | (G.hill[i] << 4) | (G.riv[i] << 5);
    s.mt = encStr(mt); s.mf = encStr(G.feat); s.mr = encStr(G.res); s.ml = encStr(G.low); s.re = encStr(G.re);
    s.im = encStr(G.imp); s.pl = encBits(G.pil);
    s.rd = encStr(G.road);
    const ds = new Uint8Array(N); for (let i = 0; i < N; i++) ds[i] = G.dis[i] | (G.dpil[i] << 5); s.ds = encStr(ds);
    s.wn = {}; s.fy = {}; for (let i = 0; i < N; i++) { if (G.won[i]) s.wn[i] = G.won[i]; if (G.fy[i]) s.fy[i] = G.fy[i]; }
    let ow = ''; for (let i = 0; i < N; i++) ow += e2(G.own[i] + 1); s.ow = ow;
    s.ex = G.ex.map(encBits);
    tidy(s);
    return s;
  }
  // 소수 정리(상태 크기 줄이기)
  const r1 = (v) => Math.round(v * 10) / 10;
  function tidyObj(o, f) { if (!o) return; for (const k in o) if (typeof o[k] === 'number' && !Number.isInteger(o[k])) o[k] = f(o[k]); }
  function tidy(s) {
    for (const p of s.P) { tidyObj(p, r1); tidyObj(p.tp, r1); tidyObj(p.cp, r1); tidyObj(p.gpp, r1); tidyObj(p.vt, (v) => Math.round(v * 100) / 100); tidyObj(p.stk, r1); if (p.gr) for (let i = 0; i < p.gr.length; i++) p.gr[i] = r1(p.gr[i]); }
    for (const c of s.C) {
      tidyObj(c, r1); tidyObj(c.pp, r1); tidyObj(c.rp, Math.round);
      // 기본값은 빼서 상태를 작게(ctx에서 다시 채워요)
      for (const k of ['lk', 'gw', 'wk']) if (c[k] && !c[k].length) delete c[k];
      for (const k of ['rp', 'pp', 'spc', 'fuelOk']) if (c[k] && !Object.keys(c[k]).length) delete c[k];
      for (const k of ['at', 'rs', 'unrest', 'sab', 'am2', 'bt']) if (!c[k]) delete c[k];
      if (c.lod === 0) delete c.lod;
    }
    for (const u of s.U) {
      tidyObj(u, r1);
      if (u.pr && !u.pr.length) delete u.pr;
      for (const k of ['f', 'x', 'a', 'mvd', 'sl', 'idle', 'pp', 'pt', 'cp']) if (!u[k]) delete u[k];
      if (u.go == null) delete u.go; if (u.tg == null) delete u.tg;
      if (u.sk != null && u.sk !== s.t) delete u.sk;
    }
    for (const p of s.P) if (p.tp) { for (const k in p.tp) if (!p.tp[k]) delete p.tp[k]; for (const k in p.cp) if (!p.cp[k]) delete p.cp[k]; }
  }
  function untidy(s) {
    for (const c of s.C) { if (!c.lk) c.lk = []; if (!c.gw) c.gw = []; if (!c.wk) c.wk = []; if (!c.rp) c.rp = {}; if (!c.pp) c.pp = {}; }
    for (const u of s.U) { if (!u.pr) u.pr = []; if (u.x == null) u.x = 0; if (u.f == null) u.f = 0; }
  }
  const dirty = (G) => { G.md = {}; G.yc = {}; };
  const isMaj = (G, o) => o >= 0 && o < G.s.nM;
  const PL = (G, o) => G.P[o];
  const civOf = (G, o) => (isMaj(G, o) ? CIVS[G.P[o].civ] : null);
  const civK = (G, o) => (isMaj(G, o) ? CIVS[G.P[o].civ].c : '');
  const cityAt = (G, i) => (G.cat[i] >= 0 ? G.cid[G.cat[i]] : null);
  const milAt = (G, i) => (G.mil[i] >= 0 ? G.uid[G.mil[i]] : null);
  const civAt = (G, i) => (G.civ[i] >= 0 ? G.uid[G.civ[i]] : null);
  const tileOwner = (G, i) => (G.own[i] >= 0 && G.cid[G.own[i]] ? G.cid[G.own[i]].o : -1);
  const tileCity = (G, i) => (G.own[i] >= 0 ? G.cid[G.own[i]] || null : null);
  const isWater = (G, i) => !!TER[G.ter[i]].water;
  const isLand = (G, i) => !TER[G.ter[i]].water;
  const passableLand = (G, i) => isLand(G, i) && G.ter[i] !== TM && G.feat[i] !== F_ICE && !(G.feat[i] >= NW0 && NW[G.feat[i] - NW0].mtn);
  const citiesOf = (G, o) => G.C.filter((c) => c.o === o);
  const unitsOf = (G, o) => G.U.filter((u) => u.o === o);
  const aliveMaj = (G) => { const a = []; for (let o = 0; o < G.s.nM; o++) if (G.P[o].a) a.push(o); return a; };
  const capOf = (G, o) => G.C.find((c) => c.o === o && c.b.indexOf('palace') >= 0) || null;
  const hasTech = (G, o, k) => { const i = TECHI[k]; return i != null && G.P[o].tk && bitHas(G.P[o].tk, i); };
  const hasCivic = (G, o, k) => { const i = CIVICI[k]; return i != null && G.P[o].ck && bitHas(G.P[o].ck, i); };
  function hasReq(G, o, req) {
    if (!req) return true;
    if (G.P[o].k !== 'maj') {
      // 도시국가·야만인: 세계 시대 기준
      const e = G.s.era;
      if (req.startsWith('c:')) { const c = CIVIC[CIVICI[req.slice(2)]]; return c ? c.e <= e : true; }
      const t = TECH[TECHI[req]]; return t ? t.e <= e : true;
    }
    if (req === 'religion') return G.P[o].rel >= 0;
    if (req === 'worship') return G.P[o].rel >= 0 && G.s.R[G.P[o].rel].bl.some((b) => BELIEF[b].t === 'W');
    if (req.startsWith('c:')) return hasCivic(G, o, req.slice(2));
    return hasTech(G, o, req);
  }
  function techEra(G, o) {
    const p = G.P[o]; if (p.k !== 'maj') return G.s.era;
    let e = 0;
    for (let i = 0; i < TECH.length; i++) if (bitHas(p.tk, i)) e = Math.max(e, TECH[i].e);
    for (let i = 0; i < CIVIC.length; i++) if (bitHas(p.ck, i)) e = Math.max(e, CIVIC[i].e);
    return e;
  }
  const cntBits = (s) => { let n = 0; for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) === 49) n++; return n; };

  /* ----- 알림·사건 ----- */
  function note(G, o, m, p, k) {
    if (o < 0 || !G.P[o] || G.P[o].k !== 'maj') return;
    if (G.P[o].lv > 0 && G.s.ph !== 'e') { if (G.P[o].nt && G.P[o].nt.length) G.P[o].nt = []; return; }   // AI는 알림을 안 남겨요(상태 크기)
    const a = G.P[o].nt || (G.P[o].nt = []);
    a.push({ t: G.s.t, m, p: p == null ? -1 : p, k: k || '' });
    if (a.length > 18) a.splice(0, a.length - 18);
  }
  function noteAll(G, m, p, k) { for (const o of aliveMaj(G)) note(G, o, m, p, k); }
  function ev(G, e) { const L2 = G.s.L; if (L2.e.length < 60) L2.e.push(e); }

  /* ======================= 수정치(정부·정책·불가사의·종교·도시국가·문명) ======================= */
  function addFx(M, fx, k) {
    if (!fx) return;
    k = k == null ? 1 : k;
    for (const key in fx) {
      const v = fx[key];
      if (typeof v === 'number') M[key] = (M[key] || 0) + v * k;
      else if (key === 'pm' || key === 'pmw') (M[key] = M[key] || []).push(v);
      else if (Array.isArray(v) && (key === 'y' || key === 'cy' || key === 'tundraY' || key === 'desertY' || key === 'featY' || key === 'relW' || key === 'relCam')) M[key] = yAdd(M[key] || Y0(), v, k);
      else if (key === 'slot') { M.slot = M.slot || [0, 0, 0, 0]; for (let i = 0; i < 4; i++) M.slot[i] += v[i] || 0; }
      else if (typeof v === 'object' && !Array.isArray(v)) {
        const o = M[key] = M[key] || {};
        for (const k2 in v) { const w = v[k2]; if (typeof w === 'number') o[k2] = (o[k2] || 0) + w * k; else if (Array.isArray(w)) o[k2] = yAdd(o[k2] || Y0(), w, k); else { o[k2] = o[k2] || {}; for (const k3 in w) o[k2][k3] = (o[k2][k3] || 0) + w[k3] * k; } }
      } else M[key] = v;
    }
  }
  function mods(G, o) {
    if (G.md[o]) return G.md[o];
    const M = {}, p = G.P[o];
    G.md[o] = M;
    if (!p || p.k !== 'maj') return M;
    const cv = CIVS[p.civ];
    addFx(M, cv.fx);
    addFx(M, GOV[p.gov].fx);
    // 정부 유산(흥망성쇠): 한 정부를 오래 쓰면 쌓이고, 바꿔도 남아요
    for (const gi in (p.lgT || {})) { const n = legacySteps(G, p.lgT[gi]); if (n && GOV[gi].lg) addFx(M, GOV[gi].lg, n); }
    for (const pi of p.pol) if (pi >= 0) addFx(M, POL[pi].fx);
    if (p.pan >= 0) addFx(M, PANTH[p.pan].fx);
    if (p.rel >= 0) for (const b of G.s.R[p.rel].bl) if (BELIEF[b].t === 'E' || BELIEF[b].t === 'O') addFx(M, BELIEF[b].fx);
    for (const wk in G.s.WB) if (G.s.WB[wk] === o) addFx(M, WON[WONI[wk]].fx);
    if (p.ded >= 0) addFx(M, DEDI[p.ded].fx, p.age >= 2 ? 1.6 : 1);
    if (p.ded2 >= 0) addFx(M, DEDI[p.ded2].fx);
    // 도시국가 종주국
    for (const q of G.P) if (q.k === 'cs' && q.a && q.suz === o) { addFx(M, CSL[q.cs].fx); M.suzN = (M.suzN || 0) + 1; }
    // 총독 진급(제국 효과)
    for (const gv of p.gv) for (let k = 0; k < gv.pr; k++) { const fx = GOVR[gv.g].pr[k][1]; if (fx.env || fx.favor) addFx(M, { env: fx.env || 0, favor: fx.favor || 0 }); }
    // 세계 의회
    for (const r of (G.s.WC.act || [])) {
      const R2 = RESO[r.ri];
      if (R2.tg === 'p' && r.tg !== o) continue;
      if (R2.k === 'udt') { M.udt = M.udt || {}; M.udt[r.tg] = (M.udt[r.tg] || 0) + (r.op === 0 ? 100 : -50); }
      else if (R2.k === 'merc') M.upgP = (M.upgP || 0) + (r.op === 0 ? -50 : 50);
      else if (R2.k === 'patron') { M.gppX = M.gppX || {}; M.gppX[r.tg] = r.op === 0 ? 100 : -100; }
      else if (R2.k === 'trade') M.trg = (M.trg || 0) + (r.op === 0 ? 4 : -4);
      else if (R2.k === 'heritage') M.wonCul = (M.wonCul || 0) + (r.op === 0 ? 3 : -2);
      else if (R2.k === 'arms') M.pmu = (M.pmu || 0) + (r.op === 0 ? -25 : 25);
    }
    if (M.csRelCiv && p.rel >= 0) { let n = 0; for (let q = 0; q < G.s.nM; q++) { if (q === o || !G.P[q].a) continue; const cs = G.C.filter((c) => c.o === q); if (cs.length && cs.filter((c) => c.rl === p.rel).length * 2 > cs.length) n++; } M.relCivN = n; }
    // 시대
    if (p.age === 2 || p.age === 3) { M.loy = (M.loy || 0) + 5; M.allP = (M.allP || 0) + (p.age === 3 ? 10 : 5); }
    if (p.age === 0) { M.loy = (M.loy || 0) - 5; M.allP = (M.allP || 0) - 5; }
    // 난이도(AI 보너스)
    if (p.lv > 0 && G.s.df > 0) { M.allP = (M.allP || 0) + [0, 10, 25, 40][G.s.df]; M.cs = (M.cs || 0) + [0, 1, 2, 4][G.s.df]; }
    // 비상사태 참가
    for (const e of (G.s.EM || [])) if (e.mem.indexOf(o) >= 0) { M.emT = M.emT || {}; M.emT[e.tg] = 4; }
    return M;
  }
  const mv0 = (M, k) => M[k] || 0;

  /* ======================= 지형 산출 ======================= */
  function nwAt(G, i) { const f = G.feat[i]; return f >= NW0 ? NW[f - NW0] : null; }
  function tileBase(G, i) {
    const t = G.ter[i], y = TER[t].y.slice();
    if (G.hill[i]) y[1] += 1;
    const f = G.feat[i];
    if (f && f < NW0 && FEAT[f]) {
      if (f === F_FLOOD && t === TD) y[0] += 3; else yAdd(y, FEAT[f].y);
    } else if (f >= NW0) { const nw = NW[f - NW0]; if (nw.y) yAdd(y, nw.y); }
    const fy = G.fy[i]; if (fy) { y[0] += fy & 3; y[1] += (fy >> 2) & 3; }
    return y;
  }
  function resVisible(G, o, r) { if (!r) return false; const rv = RES[r].rv; return !rv || o < 0 || !isMaj(G, o) || hasTech(G, o, rv); }
  function impFx(G, o, i, imK) {
    const y = Y0();
    const m = IMP[IMPI[imK]]; yAdd(y, m.y);
    if (o >= 0 && isMaj(G, o)) {
      if (imK === 'farm') {
        if (hasCivic(G, o, 'feudalism') && G.g.nb[i].filter((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'farm').length >= 2) y[0] += 1;
        if (hasTech(G, o, 'replaceable')) y[0] += 1;
      }
      if (imK === 'mine') { if (hasTech(G, o, 'apprentice')) y[1] += 1; if (hasTech(G, o, 'industrial')) y[1] += 1; if (mods(G, o).mineSci) y[3] += 1; }
      if (imK === 'quarry' && hasTech(G, o, 'rocketry')) y[1] += 1;
      if (imK === 'fish' && hasTech(G, o, 'cartography')) y[2] += 2;
      if (imK === 'pasture' && hasTech(G, o, 'stirrups')) y[1] += 1;
      if (imK === 'plant' && hasTech(G, o, 'sciTheory')) y[2] += 1;
      if (imK === 'camp' && hasCivic(G, o, 'mercantilism')) y[2] += 1;
      if (imK === 'lumber' && hasTech(G, o, 'steel')) y[1] += 1;
      if (imK === 'greatwall') y[4] += G.g.nb[i].filter((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'greatwall').length;
      if (imK === 'sphinx' && G.feat[i] === F_FLOOD) y[5] += 1;
      if (imK === 'kurgan') y[5] += G.g.nb[i].filter((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'pasture').length;
      if (imK === 'ziggurat' && G.riv[i]) y[4] += 1;
      if (imK === 'terrace') y[0] += G.g.nb[i].filter((j) => G.ter[j] === TM).length;
      const nbI = (k) => G.g.nb[i].filter((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === k).length;
      if (imK === 'outback') y[0] += nbI('pasture');
      if (imK === 'mekewap') y[2] += G.g.nb[i].filter((j) => G.res[j] && RES[G.res[j]].c === 'l').length;
      if (imK === 'rockchurch') y[5] += G.g.nb[i].filter((j) => G.ter[j] === TM).length;
      if (imK === 'hacienda') y[0] += nbI('plant');
      if (imK === 'nubpyr') y[0] += G.g.nb[i].filter((j) => G.cat[j] >= 0).length;
      if (imK === 'mine' && mods(G, o).mineCul) y[4] += 1;
      if (imK === 'farm' && mods(G, o).aqFarm && G.g.nb[i].some((j) => DIS[G.dis[j]] && DIS[G.dis[j]].k === 'aq')) y[0] += mods(G, o).aqFarm;
      if (imK === 'resort') y[2] += Math.max(0, appeal(G, i));
      const M = mods(G, o);
      if (M.timp && M.timp[imK]) yAdd(y, M.timp[imK]);
    }
    return y;
  }
  // 칸 산출(o: 이 칸을 쓰는 나라)
  function tileYield(G, i, o) {
    if (G.s.FO && G.s.FO[i]) return Y0();
    const y = tileBase(G, i);
    const M = o >= 0 ? mods(G, o) : {};
    if (G.ter[i] === TM) { if (M.mtnWork) { y[0] += 1; y[1] += 2; } }
    const r = G.res[i];
    if (r && resVisible(G, o, r)) yAdd(y, RES[r].y);
    const im = G.imp[i];
    if (im && !G.pil[i]) yAdd(y, impFx(G, o, i, IMP[im].k));
    // 자연경관 인접
    for (const j of G.g.nb[i]) { const nw = nwAt(G, j); if (nw && nw.adj) yAdd(y, nw.adj); }
    if (o >= 0 && isMaj(G, o)) {
      const f = G.feat[i];
      if (M.tfeat && f && f < NW0 && M.tfeat[FEAT[f].k]) yAdd(y, M.tfeat[FEAT[f].k]);
      if (M.tundraY && (G.ter[i] === TT || G.ter[i] === TS) && !isWater(G, i)) yAdd(y, M.tundraY);
      if (M.desertY && G.ter[i] === TD) yAdd(y, M.desertY);
      if (M.featY && (f === F_WOODS || f === F_RAIN) && !im) yAdd(y, M.featY);
      if (M.petra && G.ter[i] === TD && tileCity(G, i) && tileCity(G, i).b.indexOf('w:petra') >= 0) { y[0] += 2; y[2] += 2; y[1] += 1; }
      if (M.seaProd && isWater(G, i)) y[1] += 1;
      for (const j of G.g.nb[i]) {
        if (!(DIS[G.dis[j]] && DIS[G.dis[j]].k === 'pr') || G.dpil[j]) continue;
        const pc = tileCity(G, j); if (!pc || pc.o !== o) continue;
        const ap = appeal(G, i);
        if (ap >= 2 && pc.b.indexOf('grove') >= 0) { y[4] += 1; y[5] += 1; }
        if (ap >= 4 && pc.b.indexOf('sanct') >= 0) { y[0] += 1; y[1] += 1; }
        break;
      }
    }
    return y;
  }

  /* ======================= 매력·인접 보너스 ======================= */
  function appeal(G, i) {
    let a = 0;
    for (const j of G.g.nb[i]) {
      const t = G.ter[j], f = G.feat[j];
      if (t === TM) a += 1; if (t === TC || t === TLK) a += 1;
      if (f >= NW0) a += 2; else if (f === F_WOODS) a += 1; else if (f === F_MARSH || f === F_RAIN || f === F_FLOOD) a -= 1;
      const d = DIS[G.dis[j]]; if (d) { if (d.k === 'enc' && civK(G, tileOwner(G, j)) === 'vietnam') a += 1; else if (d.k === 'ind' || d.k === 'enc' || d.k === 'aq' || d.k === 'sp' || d.k === 'ad') a -= 1; else if (d.k === 'hs' || d.k === 'th' || d.k === 'ent' || d.k === 'wp' || d.k === 'nb' || d.k === 'pr') a += 1; }
      const m = IMP[G.imp[j]]; if (m && (m.k === 'mine' || m.k === 'quarry' || m.k === 'oilwell' || m.k === 'bcamp')) a -= 1;
      if (m && m.k === 'pairi') a += 1;
      if (G.won[j]) a += 1;
    }
    const o = tileOwner(G, i); if (o >= 0) a += mv0(mods(G, o), 'appeal');
    return a;
  }
  // 구역 인접 보너스(가능하면 이 칸에 지으면 얼마나)
  function adjBonus(G, o, i, dk) {
    const M = o >= 0 ? mods(G, o) : {}, ck = civK(G, o), nb = G.g.nb[i];
    let v = 0, half = 0;
    const cntD = nb.filter((j) => G.dis[j]).length;
    const meiji = !!M.meiji;
    const dKey = (j) => (DIS[G.dis[j]] ? DIS[G.dis[j]].k : '');
    const riverHere = !!G.riv[i];
    const gov = nb.some((j) => dKey(j) === 'gov') ? 1 : 0;
    const mtnAdj = nb.filter((j) => G.ter[j] === TM).length;
    const machu = M.mtnAdj && mtnAdj > 0 ? 1 : 0;
    if (dk === 'cam') {
      if (ck === 'korea') { v += 4 - cntD; }
      else if (ck === 'maya') { for (const j of nb) { const m = IMP[G.imp[j]]; if (m && m.k === 'plant') v += 2; else if (m && m.k === 'farm') v += 1; } half += cntD; }
      else {
        v += mtnAdj;
        for (const j of nb) { if (G.feat[j] === F_REEF) v += 2; const nw = nwAt(G, j); if (nw && nw.k === 'reef') v += 2; }
        const rain = nb.filter((j) => G.feat[j] === F_RAIN).length;
        if (M.rainAdj) v += rain; else half += rain;
        if (meiji) v += cntD; else half += cntD;
      }
      if (M.riverAdj && riverHere) v += 1;
    } else if (dk === 'hs') {
      v += mtnAdj; for (const j of nb) if (nwAt(G, j)) v += 2;
      half += nb.filter((j) => G.feat[j] === F_WOODS).length;
      if (M.rainAdj) v += nb.filter((j) => G.feat[j] === F_RAIN).length;
      if (meiji) v += cntD; else half += cntD;
      if (M.adjT && M.adjT.hs) { const a = M.adjT.hs; for (const j of nb) { if (a.t && G.ter[j] === TT) v += a.t; if (a.d && G.ter[j] === TD) v += a.d; if (a.rain && G.feat[j] === F_RAIN) v += a.rain; } }
      if (M.hsRiver && riverHere) v += M.hsRiver;
      if (M.seaAdjFaith && nb.some((j) => G.ter[j] === TC || G.ter[j] === TO)) v += 1;
    } else if (dk === 'com') {
      if (riverHere) v += 2;
      v += 2 * nb.filter((j) => dKey(j) === 'hb').length;
      if (ck === 'mali') v += 2 * nb.filter((j) => dKey(j) === 'hs').length;
      if (M.rainAdj) v += nb.filter((j) => G.feat[j] === F_RAIN).length;
      if (meiji) v += cntD; else half += cntD;
      v += machu;
    } else if (dk === 'th') {
      v += nb.filter((j) => G.won[j]).length;
      v += 2 * nb.filter((j) => dKey(j) === 'ent' || dKey(j) === 'wp').length;
      if (ck === 'greece' || meiji) v += cntD; else half += cntD;
      if (M.seaAdjFaith && nb.some((j) => G.ter[j] === TC || G.ter[j] === TO)) v += 1;
      if (M.rainAdj) v += nb.filter((j) => G.feat[j] === F_RAIN).length;
      if (M.riverAdj && riverHere) v += 1;
      v += machu;
    } else if (dk === 'ind') {
      v += 2 * nb.filter((j) => { const k = dKey(j); return k === 'aq' || k === 'dam' || k === 'can'; }).length;
      v += nb.filter((j) => IMP[G.imp[j]] && (IMP[G.imp[j]].k === 'mine' || IMP[G.imp[j]].k === 'quarry')).length;
      if (ck === 'germany') { v += 2 * nb.filter((j) => dKey(j) === 'com').length; v += nb.filter((j) => G.res[j]).length; }
      if (ck === 'gaul') v += nb.filter((j) => IMP[G.imp[j]] && (IMP[G.imp[j]].k === 'mine' || IMP[G.imp[j]].k === 'quarry')).length;
      if (meiji) v += cntD; else half += cntD;
      if (M.riverAdj && riverHere) v += 1;
      v += machu;
    } else if (dk === 'hb') {
      if (nb.some((j) => dKey(j) === 'cc')) v += 2;
      half += nb.filter((j) => isWater(G, j) && G.res[j]).length;
      if (meiji) v += cntD; else half += cntD;
    } else return 0;
    v += gov;
    v += Math.floor(half / 2);
    if (ck === 'australia' && appeal(G, i) >= 4) v += 1;
    const am = M.adj && M.adj[dk] ? M.adj[dk] : 0;
    return Math.max(0, Math.floor(v * (1 + am / 100)));
  }

  /* ======================= 도시 계산 ======================= */
  const SPEC = { cam: [0, 0, 0, 2], hs: [0, 0, 0, 0, 0, 2], com: [0, 0, 4], th: [0, 0, 0, 0, 2], ind: [0, 2], hb: [1, 0, 2], enc: [0, 1] };
  const hasB = (c, k) => c.b.indexOf(k) >= 0;
  function bldOf(G, o, base) {
    // 이 나라에서 base 건물을 대신하는 고유 건물
    const ck = civK(G, o);
    const u = BLD.find((b) => b.civ === ck && b.rep === base);
    return u ? u.k : base;
  }
  const BREP = {}; BLD.forEach((b) => { if (b.rep) BREP[b.k] = b.rep; });
  const baseB = (k) => BREP[k] || k;
  const cityHasB = (c, base) => c.b.some((k) => baseB(k) === base);
  function distOf(c, dk) { return c.d[dk] != null ? c.d[dk] : -1; }
  function distCount(c) { let n = 0; for (const k in c.d) if (DIS[DISI[k]].lim) n++; return n; }
  function distName(G, o, dk) { const ck = civK(G, o); const u = UDIS[ck] && UDIS[ck][dk]; return u ? u.n : DIS[DISI[dk]].n; }
  function freshWater(G, i) { return !!(G.riv[i] || G.g.nb[i].some((j) => G.ter[j] === TLK || G.feat[j] === F_OASIS || (nwAt(G, j) && nwAt(G, j).k === 'deadsea'))); }
  const riverBetween = (G, a, b) => !!riverEdge(G.g, G.re, a, b);
  function coastal(G, i) { return G.g.nb[i].some((j) => G.ter[j] === TC || G.ter[j] === TO); }
  function cityTiles(G, c) { const out = []; for (const j of within(G.g, c.p, 3)) if (G.own[j] === c.id) out.push(j); return out; }
  function workable(G, c, j) {
    if (j === c.p || G.own[j] !== c.id) return false;
    if (G.dis[j] || G.won[j]) return false;
    if (G.ter[j] === TM && !mods(G, c.o).mtnWork) return false;
    const nw = nwAt(G, j); if (nw && nw.mtn) return false;
    if (G.feat[j] === F_ICE) return false;
    const m = milAt(G, j); if (m && m.o !== c.o && atWar(G, m.o, c.o)) return false;
    return true;
  }
  function housing(G, c) {
    const M = mods(G, c.o);
    let h = freshWater(G, c.p) ? 5 : coastal(G, c.p) ? 3 : 2;
    for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && b.h) h += b.h; }
    if (c.wb >= 0 && WORSHIP[c.wb].h) h += WORSHIP[c.wb].h;
    if (c.d.aq != null && !G.dpil[c.d.aq]) h += (freshWater(G, c.p) ? 2 : 6) + (civK(G, c.o) === 'rome' ? 2 : 0);
    if (c.d.nb != null && !G.dpil[c.d.nb]) { const a = appeal(G, c.d.nb); h += (civK(G, c.o) === 'kongo' ? 5 : 0) + (a >= 4 ? 6 : a >= 2 ? 5 : a >= 0 ? 4 : a >= -1 ? 3 : 2); }
    if (civK(G, c.o) === 'zulu' && c.d.enc != null) h += 1;
    let half = 0;
    for (const j of cityTiles(G, c)) { const m = IMP[G.imp[j]]; if (m && !G.pil[j] && (m.k === 'farm' || m.k === 'pasture' || m.k === 'plant' || m.k === 'camp' || m.k === 'polder' || m.k === 'terrace' || m.k === 'outback')) half++; if (m && m.k === 'farm' && M.farmHous && !G.pil[j]) half++; if (m && (m.k === 'stepwell' || m.k === 'kampung' || m.k === 'mekewap') && !G.pil[j]) h += 1; }
    if (M.coastHous && coastal(G, c.p)) h += M.coastHous;
    h += Math.floor(half / 2);
    const nd = distCount(c);
    h += mv0(M, 'hous') + (nd >= 2 ? mv0(M, 'housD2') : 0) + (nd >= 3 ? mv0(M, 'housD3') : 0) + (M.housWall && c.wl > 0 ? 1 : 0) + mv0(M, 'h');
    h += govFx(G, c, 'cHous');
    return h;
  }
  function govFx(G, c, key) {
    if (c.gv == null || c.gv < 0) return 0;
    const p = G.P[c.o]; const gv = p.gv && p.gv.find((x) => x.g === c.gv && x.c === c.id);
    if (!gv || gv.est > 0) return 0;
    const D = GOVR[gv.g]; let v = D.fx[key] || 0;
    for (let k = 0; k < gv.pr; k++) v += D.pr[k][1][key] || 0;
    return v;
  }
  function ownedLux(G, o, raw) {
    const set = {};
    for (const c of G.C) if (c.o === o) for (const j of cityTiles(G, c)) { const r = G.res[j]; if (r && RES[r].c === 'l' && IMP[G.imp[j]] && IMP[G.imp[j]].k === RES[r].im && !G.pil[j]) set[r] = (set[r] || 0) + 1; }
    if (raw) return set;
    // 거래한 사치 자원(30턴)
    for (const d of (G.s.DL || [])) if (d.lx && d.t > 0) { if (d.a === o && set[d.lx]) { set[d.lx]--; if (!set[d.lx]) delete set[d.lx]; } if (d.b === o) set[d.lx] = (set[d.lx] || 0) + 1; }
    return set;
  }
  // 쾌적도 분배(나라 단위)
  function amenityMap(G, o) {
    const key = 'am' + o;
    if (G.yc[key]) return G.yc[key];
    const M = mods(G, o), cs = citiesOf(G, o), res = {};
    const lux = ownedLux(G, o), nl = Object.keys(lux).length;
    for (const c of cs) {
      let a = 0;
      for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && b.a && !b.rg) a += b.a; }
      if (c.wb >= 0 && WORSHIP[c.wb].a) a += WORSHIP[c.wb].a;
      const nd = distCount(c);
      if (c.d.ent != null) a += 1 + (civK(G, o) === 'brazil' || civK(G, o) === 'byzantium' ? 1 : 0) + mv0(M, 'amenEnt');
      if (cityTiles(G, c).some((j) => G.imp[j] === IMPI.golf && !G.pil[j])) a += 1;
      if (c.d.wp != null) a += 1;
      if (c.d.dam != null) a += 1;
      if (civK(G, o) === 'rome' && c.d.aq != null) a += 1;
      if (nd >= 1) a += mv0(M, 'amenD'); if (nd >= 3) a += mv0(M, 'amenD3');
      if (M.amenGar && milAt(G, c.p)) a += M.amenGar;
      if (M.amenRiverHs && c.d.hs != null && G.riv[c.d.hs]) a += M.amenRiverHs;
      a += mv0(M, 'amen') + mv0(M, 'amenAll');
      if (hasB(c, 'w:alhambra')) a += 2;
      if (c.am2) a += c.am2;
      a += govFx(G, c, 'cAmen');
      if (c.rl >= 0) { const R2 = G.s.R[c.rl]; if (R2 && R2.bl.some((b) => BELIEF[b].k === 'zen') && nd >= 2) a += 1; }
      if (c.conq && M.amenConq) a += 1;
      // 근처 오락 시설(6칸)
      for (const d of G.C) {
        if (d.o !== o || hexDist(G.g, c.p, d.p) > 6) continue;
        for (const k of d.b) { const b = BLD[BLDI[k]]; if (b && b.rg && (!b.pw || d.pw)) a += b.a; }
        if (hasB(d, 'w:colosseum')) a += 2;
      }
      for (const j of within(G.g, c.p, 1)) { const nw = nwAt(G, j); if (nw && nw.k === 'pamuk') a += 2; }
      for (const j of within(G.g, c.p, 6)) if (IMP[G.imp[j]] && IMP[G.imp[j]].k === 'icerink' && tileOwner(G, j) === o) { a += 1; break; }
      // 전쟁 피로
      a -= Math.floor((G.P[o].ww || 0) / 25);
      res[c.id] = a;
    }
    // 사치 자원: 종류마다 4곳(아즈텍 6곳)에 +1
    const cap = 4 + 2 * mv0(M, 'luxAmen');
    const need = (c) => Math.max(0, Math.ceil((c.pop - 2) / 2)) - res[c.id];
    for (let k = 0; k < nl; k++) {
      const order = cs.slice().sort((a, b) => need(b) - need(a));
      for (let n = 0; n < Math.min(cap, order.length); n++) res[order[n].id] += 1;
    }
    G.yc[key] = res;
    return res;
  }
  function amenNeed(c) { return Math.max(0, Math.ceil((c.pop - 2) / 2)); }
  function moodOf(bal) { return bal >= 3 ? 3 : bal >= 1 ? 2 : bal >= 0 ? 1 : bal >= -2 ? 0 : bal >= -4 ? -1 : -2; }
  const MOODN = { 3: '열광', 2: '행복', 1: '만족', 0: '불만', '-1': '불행', '-2': '폭동' };
  const MOOD_G = { 3: 0.2, 2: 0.1, 1: 0, 0: -0.15, '-1': -0.3, '-2': -1 };
  const MOOD_Y = { 3: 0.1, 2: 0.05, 1: 0, 0: -0.05, '-1': -0.1, '-2': -0.2 };

  // 전력: 6칸 안 발전소·발전 시설
  function powerOf(G, c) {
    let need = 0; for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && b.pw) need++; }
    if (!need) return { need: 0, got: 0, ok: true };
    let got = 0;
    for (const d of G.C) {
      if (d.o !== c.o || hexDist(G.g, c.p, d.p) > 6) continue;
      for (const k of d.b) { const b = BLD[BLDI[k]]; if (b && b.power && (!b.fuel || (d.fuelOk && d.fuelOk[k]))) got += b.power; }
    }
    for (const j of cityTiles(G, c)) { const m = IMP[G.imp[j]]; if (m && m.pw && !G.pil[j]) got += m.pw; }
    return { need, got, ok: got >= need };
  }

  // 도시 산출 전체 계산
  function cityCalc(G, c) {
    if (G.yc[c.id]) return G.yc[c.id];
    const o = c.o, M = mods(G, o), p = G.P[o], maj = p.k === 'maj';
    const y = Y0(), parts = {};
    const add = (k, v) => { yAdd(y, v); parts[k] = yAdd(parts[k] || Y0(), v); };
    // 도심
    const cy = tileYield(G, c.p, o); cy[0] = Math.max(cy[0], 2); cy[1] = Math.max(cy[1], 1);
    if (G.imp[c.p]) { /* 도심엔 개선 없음 */ }
    add('도심', cy);
    // 일하는 칸·전문가
    const wk = c.wk || [];
    for (const j of wk) add('칸', tileYield(G, j, o));
    const spN = c.spc || {};
    for (const dk in spN) if (SPEC[dk]) add('전문가', yAdd(Y0(), SPEC[dk], spN[dk]));
    // 구역 인접
    for (const dk in c.d) {
      const ti = c.d[dk]; if (G.dpil[ti]) continue;
      const D = DIS[DISI[dk]]; if (D.y >= 0) {
        const a = adjBonus(G, o, ti, dk), v = Y0(); v[D.y] += a;
        if (dk === 'hs' && c.rl >= 0 && G.s.R[c.rl] && G.s.R[c.rl].bl.some((b) => BELIEF[b].k === 'workEthic')) v[1] += a;
        if (dk === 'cam' && hasB(c, 'madrasa')) v[5] += a;
        if (dk === 'hb' && civK(G, o) === 'england') v[2] += 2;
        add('인접', v);
      }
      if (M.dy && M.dy[dk]) add('정책', M.dy[dk]);
      if (dk === 'nb' && civK(G, o) === 'kongo') add('구역', [2, 0, 4]);
      if (dk === 'enc' && civK(G, o) === 'vietnam') add('구역', [0, 0, 0, 0, 2]);
    }
    // 건물
    const pw = maj ? powerOf(G, c) : { ok: false, need: 0 };
    c.pw = pw.ok && pw.need > 0 ? 1 : 0;
    for (const k of c.b) {
      if (k.startsWith('w:')) { const W = WON[WONI[k.slice(2)]]; if (W && W.fx.y) add('불가사의', W.fx.y); if (M.wonCul) add('불가사의', [0, 0, 0, 0, M.wonCul]); continue; }
      const b = BLD[BLDI[k]]; if (!b || !b.y) continue;
      if (b.d !== 'cc' && c.d[b.d] != null && G.dpil[c.d[b.d]]) continue;
      const v = yAdd(Y0(), b.y);
      if (M.bm && M.bm[b.d]) for (let i = 0; i < 6; i++) v[i] *= 1 + M.bm[b.d] / 100;
      if (b.pw && c.pw) { if (b.k === 'researchlab') v[3] += 3; if (b.k === 'stock') v[2] += 3; if (b.k === 'broadcast' || b.k === 'filmstudio') v[4] += 2; }
      if (b.k === 'stave') v[5] += G.g.nb[c.d.hs].filter((j) => G.feat[j] === F_WOODS).length;
      if (M.bld && M.bld[b.k]) yAdd(v, M.bld[b.k]);
      if (M.featDist && b.d !== 'cc' && c.d[b.d] != null) { const ft = G.feat[c.d[b.d]]; const D2 = DIS[DISI[b.d]]; if ((ft === F_WOODS || ft === F_RAIN || ft === F_MARSH) && D2 && D2.y >= 0) v[D2.y] += 1; }
      add('건물', v);
    }
    if (c.wb >= 0) add('건물', WORSHIP[c.wb].y);
    // 공장(전력) 지역 효과
    for (const d of G.C) if (d.o === o && d.id !== c.id && hexDist(G.g, c.p, d.p) <= 6 && d.b.some((k) => (k === 'factory' || k === 'elecfac')) && d.pw) { add('지역', [0, 2]); break; }
    if (c.b.some((k) => k === 'factory' || k === 'elecfac') && c.pw) add('지역', [0, 2]);
    // 정책·정부
    if (M.y) add('정책', M.y);
    if (c.b.indexOf('palace') >= 0 && M.cy) add('수도', M.cy);
    if (M.popProd) add('정부', [0, c.pop * M.popProd]);
    // 걸작
    if ((c.gw || []).length) { const GL = gwLayout(G, c); for (const sl of GL.slots) if (sl.w >= 0) add('걸작', yAdd(Y0(), GW_Y[c.gw[sl.w].c], GL.themed[sl.b] ? 2 : 1)); }
    // 인구 기본 과학·문화
    add('인구', [0, 0, 0, c.pop * 0.5, c.pop * 0.3]);
    // 교역로
    if (maj) for (const tr of p.tr) if (tr.f === c.id) add('교역', tradeYield(G, tr));
    for (const q of G.P) if (q.k === 'maj' && q !== p) for (const tr of q.tr) if (tr.d === c.id) add('교역', [0, 0, 1]);
    // 도시국가 사절
    if (maj) for (const q of G.P) {
      if (q.k !== 'cs' || !q.a) continue;
      const n = q.envs[o] || 0; if (!n) continue;
      const T = CST[CSL[q.cs].t], v = Y0();
      if (c.b.indexOf('palace') >= 0) v[T[1]] += 2;
      if (n >= 3 && c.d[T[2]] != null) v[T[1]] += 2;
      if (n >= 6 && c.d[T[2]] != null) v[T[1]] += 2;
      if (q.suz === o && M.raj) { v[2] += 2; v[3] += 2; v[4] += 2; v[5] += 2; }
      add('도시국가', v);
    }
    // 종교(추종자 신앙)
    if (c.rl >= 0 && G.s.R[c.rl]) {
      for (const bi of G.s.R[c.rl].bl) {
        const fx = BELIEF[bi].fx;
        if (fx.relB) for (const bk in fx.relB) if (cityHasB(c, bk)) add('종교', fx.relB[bk]);
        if (fx.relW) add('종교', yAdd(Y0(), fx.relW, c.b.filter((k) => k.startsWith('w:')).length));
        if (fx.relCam && c.d.cam != null) add('종교', fx.relCam);
        if (fx.relGen && c.d.hs != null) { /* 장군 점수는 위인에서 */ }
      }
    }
    // 창시자 신앙(수도에)
    if (maj && c.b.indexOf('palace') >= 0 && p.rel >= 0) {
      const R2 = G.s.R[p.rel], fol = G.C.filter((d) => d.rl === p.rel);
      for (const bi of R2.bl) {
        const fx = BELIEF[bi].fx;
        if (fx.oCP) add('종교', yAdd(Y0(), fx.oCP, fol.length));
        if (fx.oTithe) add('종교', [0, 0, Math.max(fol.length, Math.floor(sum(fol.map((d) => d.pop)) / 4))]);
      }
    }
    // 인도: 만난 종교 문명마다 신앙
    if (M.gandhi && c.b.indexOf('palace') >= 0) add('지도자', [0, 0, 0, 0, 0, 2 * aliveMaj(G).filter((q) => q !== o && met(G, o, q) && G.P[q].rel >= 0).length]);
    if (M.hillSci && G.hill[c.p]) add('지도자', [0, 0, 0, y[5] * M.hillSci / 100]);
    // 총독
    if (govFx(G, c, 'cProd')) add('총독', [0, govFx(G, c, 'cProd')]);
    if (govFx(G, c, 'cGold')) add('총독', [0, 0, govFx(G, c, 'cGold')]);
    if (govFx(G, c, 'cFaithD')) add('총독', [0, 0, 0, 0, 0, govFx(G, c, 'cFaithD') * distCount(c)]);
    // 퍼센트 보정
    const am = amenityMap(G, o)[c.id] || 0, bal = am - amenNeed(c), mood = moodOf(bal);
    const pct = [mv0(M, 'foodP') + govFx(G, c, 'cFoodP'), mv0(M, 'prodP') + govFx(G, c, 'cProdP'), mv0(M, 'goldP') + govFx(G, c, 'cGoldP'), mv0(M, 'sciP') + govFx(G, c, 'cSciP') + mv0(M, 'pmSci') + (p.sv && p.sv.moon ? 10 : 0),
      mv0(M, 'culP') + govFx(G, c, 'cCulP') + (M.culPerSuz ? M.culPerSuz * mv0(M, 'suzN') : 0), mv0(M, 'faithP') + govFx(G, c, 'cFaithP')];
    let all = mv0(M, 'allP') + MOOD_Y[mood] * 100;
    if (M.mayaCap && c.b.indexOf('palace') < 0) { const cap = capOf(G, o); all += cap && hexDist(G.g, cap.p, c.p) <= 6 ? 10 : -15; }
    if (M.happySci && mood >= 2) { const hb = M.happySci * (mood === 3 ? 2 : 1); pct[1] += hb; pct[3] += hb; }
    if (p.dpT > 0) pct[1] += 100;
    if (hasB(c, 'w:ruhr')) pct[1] += 20;
    if (G.s.CL && c.unrest) pct[1] -= 30;
    for (let i = 0; i < 6; i++) { const f = 1 + (pct[i] + (i ? all : Math.min(0, all))) / 100; y[i] = Math.max(i === 0 ? -99 : 0, y[i] * f); }
    if (y[1] < 1) y[1] = 1;
    // 식량 소비·성장
    const eat = c.pop * 2;
    const surplus = y[0] - eat;
    const h = housing(G, c), hd = h - c.pop;
    const hf = hd >= 2 ? 1 : hd === 1 ? 0.5 : hd > -5 ? 0.25 : 0;
    const gm = 1 + (mv0(M, 'growthP') + (c.rl >= 0 && G.s.R[c.rl] && G.s.R[c.rl].bl.some((b) => BELIEF[b].k === 'community') ? 10 : 0)) / 100 + MOOD_G[mood];
    const grow = surplus > 0 ? surplus * Math.max(0, gm) * hf : surplus;
    const need = growNeed(G, c);
    const r = { y, parts, eat, surplus, grow, need, hous: h, amen: am, amenNeed: amenNeed(c), mood, power: pw };
    G.yc[c.id] = r;
    return r;
  }
  function growNeed(G, c) { const n = c.pop - 1; return Math.round((15 + 8 * n + Math.pow(n, 1.5)) * G.s.spP); }
  function tradeYield(G, tr) {
    const f = G.cid[tr.f], d = G.cid[tr.d]; if (!f || !d) return Y0();
    const M = mods(G, f.o), nd = distCount(d);
    const fd = M.routeFood ? 1 : 0;
    if (f.o === d.o) return [2 + nd + fd, 1 + Math.floor(nd / 2), 0, 0, 0, 0];
    return [fd, 0, Math.round((3 + nd + mv0(M, 'trg') + ((d.tp || []).indexOf(f.o) >= 0 ? 1 : 0)) * (1 + mv0(M, 'trgP') / 100)), d.d.cam != null ? 1 : 0, d.d.th != null ? 1 : 0, d.d.hs != null ? 1 : 0];
  }
  // 일할 칸 자동 배치(잠근 칸 먼저)
  const FOCW = [[1.15, 1.05, 0.6, 0.85, 0.75, 0.55], [2, 0.8, 0.4, 0.6, 0.5, 0.4], [0.9, 2, 0.5, 0.6, 0.5, 0.4], [0.9, 0.8, 2, 0.6, 0.5, 0.4], [0.9, 0.8, 0.4, 2, 0.8, 0.4], [0.9, 0.8, 0.4, 0.8, 2, 0.6], [0.9, 0.8, 0.4, 0.6, 0.6, 2]];
  const FOCN = ['균형', '식량', '생산', '금', '과학', '문화', '신앙'];
  function assignWork(G, c) {
    const o = c.o, tiles = cityTiles(G, c).filter((j) => workable(G, c, j));
    const w = FOCW[c.fo || 0];
    const val = (y) => y[0] * w[0] + y[1] * w[1] + y[2] * w[2] + y[3] * w[3] + y[4] * w[4] + y[5] * w[5];
    const opts = [];
    for (const j of tiles) opts.push({ j, y: tileYield(G, j, o) });
    // 전문가 칸: 구역 건물마다 1칸
    const slots = {};
    for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && SPEC[b.d] && c.d[b.d] != null) slots[b.d] = (slots[b.d] || 0) + 1; }
    for (const dk in slots) for (let n = 0; n < slots[dk]; n++) opts.push({ sp: dk, y: SPEC[dk] });
    const lk = (c.lk || []).filter((j) => tiles.indexOf(j) >= 0);
    let n = c.pop;
    const wk = [], spc = {};
    for (const j of lk) { if (n <= 0) break; wk.push(j); n--; }
    let food = tileYield(G, c.p, o)[0]; for (const j of wk) food += tileYield(G, j, o)[0];
    const rest = opts.filter((x) => x.sp || wk.indexOf(x.j) < 0);
    rest.forEach((x) => { x.v = val(x.y); });
    while (n > 0 && rest.length) {
      const hungry = food < (c.pop * 2) + 1;
      let bi = 0, bv = -1e9;
      for (let k = 0; k < rest.length; k++) { const x = rest[k]; const v = x.v + (hungry ? x.y[0] * 1.6 : 0); if (v > bv) { bv = v; bi = k; } }
      const x = rest.splice(bi, 1)[0];
      if (x.sp) spc[x.sp] = (spc[x.sp] || 0) + 1; else wk.push(x.j);
      food += x.y[0]; n--;
    }
    c.wk = wk; c.spc = spc;
    delete G.yc[c.id];
  }

  /* ======================= 연구·사회 제도 ======================= */
  function progFrac(G, o) { const p = G.P[o]; return Math.max(cntBits(p.tk) / TECH.length, cntBits(p.ck) / CIVIC.length); }
  function techCost(G, o, i) { return Math.round(ERA_TC[TECH[i].e] * G.s.spT * (1 + (TECH[i].k === 'future' ? 0.3 * (G.P[o].ft || 0) : 0))); }
  function civicCost(G, o, i) { return Math.round(ERA_CC[CIVIC[i].e] * G.s.spT); }
  function techAvail(G, o, i) { const p = G.P[o]; return !bitHas(p.tk, i) && TECH[i].pre.every((k) => bitHas(p.tk, TECHI[k])); }
  function civicAvail(G, o, i) { const p = G.P[o]; return !bitHas(p.ck, i) && CIVIC[i].pre.every((k) => bitHas(p.ck, CIVICI[k])); }
  function boostFrac(G, o) { return 0.4 + mv0(mods(G, o), 'boostP') / 100; }
  function nextPre(G, o, k, civic) {
    const LST = civic ? CIVIC : TECH, IDX = civic ? CIVICI : TECHI, p = G.P[o], has = (i) => bitHas(civic ? p.ck : p.tk, i);
    const need = new Set(), st = [k];
    while (st.length) { const i = st.pop(); if (has(i) || need.has(i)) continue; need.add(i); for (const q of LST[i].pre) st.push(IDX[q]); }
    let best = -1; for (const i of need) if ((civic ? civicAvail(G, o, i) : techAvail(G, o, i)) && (best < 0 || LST[i].e < LST[best].e)) best = i;
    return best;
  }
  function grantTech(G, o, i, quiet) {
    const p = G.P[o];
    if (bitHas(p.tk, i)) return;
    p.tk = bitSet(p.tk, i); delete p.tp[i];
    if (p.rs === i) p.rs = -1;
    const T = TECH[i];
    p.es = (p.es || 0) + 0.5;
    if (!quiet) note(G, o, '🔬 연구 완료: ' + T.n, -1, 'tech');
    eraScoreFirstEra(G, o);
    if (T.k === 'future') { p.ft = (p.ft || 0) + 1; p.tk = p.tk.slice(0, i) + '0' + p.tk.slice(i + 1); }
    if (mods(G, o).freeTraderTech === T.k) { const c = capOf(G, o); if (c) { const sp = spawnSpot(G, c.p, UTI.trader, o); if (sp >= 0) mkUnit(G, o, UTI.trader, sp); } }
    if (p.rg >= 0 && p.rs < 0) { if (bitHas(p.tk, p.rg)) p.rg = -1; else p.rs = nextPre(G, o, p.rg, false); }
    dirty(G);
  }
  function grantCivic(G, o, i, quiet) {
    const p = G.P[o];
    if (bitHas(p.ck, i)) return;
    p.ck = bitSet(p.ck, i); delete p.cp[i];
    if (p.cs === i) p.cs = -1;
    const C2 = CIVIC[i];
    p.es = (p.es || 0) + 0.5;
    if (!quiet) note(G, o, '🎭 사회 제도 완료: ' + C2.n, -1, 'civic');
    p.pf = 1;   // 정책 무료 교체
    if (TITLE_CIVICS.indexOf(C2.k) >= 0) { p.gt++; note(G, o, '👤 총독 칭호를 얻었어요.', -1, 'gov'); }
    if (ENVOY_CIVICS.indexOf(C2.k) >= 0) { p.env += C2.e >= 4 ? 2 : 1; note(G, o, '✉ 사절을 얻었어요.', -1, 'env'); }
    if (GOV.some((g) => g.req === C2.k)) note(G, o, '🏛 새 정부를 고를 수 있어요.', -1, 'gov');
    // 사라지는 정책
    for (let k = 0; k < p.pol.length; k++) { const pi = p.pol[k]; if (pi >= 0 && POL[pi].ob && hasCivic(G, o, POL[POLI[POL[pi].ob]].req)) p.pol[k] = -1; }
    if (p.cg >= 0 && p.cs < 0) { if (bitHas(p.ck, p.cg)) p.cg = -1; else p.cs = nextPre(G, o, p.cg, true); }
    eraScoreFirstEra(G, o);
    dirty(G);
  }
  function addSci(G, o, v) {
    const p = G.P[o];
    if (p.rs < 0) { p.sbank = (p.sbank || 0) + v; return; }
    const i = p.rs; p.tp[i] = (p.tp[i] || 0) + v + (p.sbank || 0); p.sbank = 0;
    const cost = techCost(G, o, i);
    if (p.tp[i] >= cost) { const over = p.tp[i] - cost; grantTech(G, o, i); p.sbank = Math.min(over, cost); }
  }
  function addCul(G, o, v) {
    const p = G.P[o];
    p.lc = (p.lc || 0) + v;
    if (p.cs < 0) { p.cbank = (p.cbank || 0) + v; return; }
    const i = p.cs; p.cp[i] = (p.cp[i] || 0) + v + (p.cbank || 0); p.cbank = 0;
    const cost = civicCost(G, o, i);
    if (p.cp[i] >= cost) { const over = p.cp[i] - cost; grantCivic(G, o, i); p.cbank = Math.min(over, cost); }
  }
  // 유레카·영감 조건 검사
  function condOK(G, o, b) {
    if (!b) return false;
    const p = G.P[o], st = p.st, a = b.split(':'), k = a[0];
    const cs = citiesOf(G, o);
    const nImp = (key) => { let n = 0; for (const c of cs) for (const j of cityTiles(G, c)) if (IMP[G.imp[j]] && IMP[G.imp[j]].k === key) n++; return n; };
    switch (k) {
      case 'imp': return nImp(a[1]) >= +a[2];
      case 'impn': { let n = 0; for (const c of cs) for (const j of cityTiles(G, c)) if (G.imp[j]) n++; return n >= +a[1]; }
      case 'k': return (st.k || 0) >= +a[1];
      case 'camp': return (st.camp || 0) >= +a[1];
      case 'met': return aliveMaj(G).filter((q) => q !== o && met(G, o, q)).length >= +a[1];
      case 'mcs': return G.P.filter((q) => q.k === 'cs' && met(G, o, q.o)).length >= +a[1];
      case 'seenw': { const ex = G.ex[o]; for (let i = 0; i < G.N; i++) if (ex[i] && G.feat[i] >= NW0) return true; return false; }
      case 'res': return (p.stk[RESI[a[1]]] || 0) > 0 || cs.some((c) => cityTiles(G, c).some((j) => G.res[j] === RESI[a[1]] && G.imp[j]));
      case 'u': return G.U.filter((u) => u.o === o && (UT[u.t].k === a[1] || UT[u.t].rep === a[1])).length >= +a[2];
      case 'ucls': return G.U.filter((u) => u.o === o && UT[u.t].cl === a[1]).length >= +a[2];
      case 'mil': return G.U.filter((u) => u.o === o && isMil(u.t)).length >= +a[1];
      case 'b': return cs.filter((c) => cityHasB(c, a[1])).length >= +a[2];
      case 'd': if (a.length === 2) return sum(cs.map(distCount)) >= +a[1]; return cs.filter((c) => c.d[a[1]] != null).length >= +a[2];
      case 'tr': return p.tr.length >= +a[1];
      case 'gp': return !!(st.gpc && st.gpc[a[1]]);
      case 'gpn': return (st.gp || 0) >= +a[1];
      case 'pop': return cs.some((c) => c.pop >= +a[1]);
      case 'tpop': return sum(cs.map((c) => c.pop)) >= +a[1];
      case 'w': return Object.values(G.s.WB).filter((x) => x === o).length >= +a[1];
      case 'civ': return hasCivic(G, o, a[1]);
      case 'tech': return hasTech(G, o, a[1]);
      case 'slots': return sum(slotsOf(G, o)) >= +a[1];
      case 'pan': return p.pan >= 0;
      case 'rel': return p.rel >= 0;
      case 'relc': return p.rel >= 0 && G.C.filter((c) => c.rl === p.rel).length >= +a[1];
      case 'ally': return aliveMaj(G).some((q) => q !== o && dipSt(G, o, q) === 3);
      case 'warv': return (st.warv || 0) >= 1;
      case 'cont': { const set = {}; const ex = G.ex[o]; for (let i = 0; i < G.N; i++) if (ex[i] && G.lc[i] > 0) set[G.lc[i]] = 1; return Object.keys(set).length >= +a[1]; }
      case 'gwn': return sum(cs.map((c) => (c.gw || []).length)) >= +a[1];
      case 'pwr': return cs.filter((c) => c.b.some((kk) => BLD[BLDI[kk]] && BLD[BLDI[kk]].power)).length >= +a[1];
    }
    return false;
  }
  function checkBoosts(G, o) {
    const p = G.P[o], f = boostFrac(G, o);
    for (let i = 0; i < TECH.length; i++) if (!bitHas(p.tk, i) && !bitHas(p.tb, i) && TECH[i].b && condOK(G, o, TECH[i].b)) giveBoost(G, o, i, f);
    for (let i = 0; i < CIVIC.length; i++) if (!bitHas(p.ck, i) && !bitHas(p.cb, i) && CIVIC[i].b && condOK(G, o, CIVIC[i].b)) giveInsp(G, o, i, f);
  }
  function giveBoost(G, o, i, f) {
    const p = G.P[o]; if (bitHas(p.tb, i) || bitHas(p.tk, i)) return;
    p.tb = bitSet(p.tb, i); p.tp[i] = (p.tp[i] || 0) + techCost(G, o, i) * (mods(G, o).boostFull ? 1 : (f || boostFrac(G, o)));
    note(G, o, '💡 유레카! ' + TECH[i].n + ' (' + Math.round((f || boostFrac(G, o)) * 100) + '%)', -1, 'boost');
    if (p.tp[i] >= techCost(G, o, i)) grantTech(G, o, i);
  }
  function giveInsp(G, o, i, f) {
    const p = G.P[o]; if (bitHas(p.cb, i) || bitHas(p.ck, i)) return;
    p.cb = bitSet(p.cb, i); p.cp[i] = (p.cp[i] || 0) + civicCost(G, o, i) * (f || boostFrac(G, o));
    note(G, o, '✨ 영감! ' + CIVIC[i].n, -1, 'boost');
    if (p.cp[i] >= civicCost(G, o, i)) grantCivic(G, o, i);
  }
  function randomBoosts(G, o, n) {
    const p = G.P[o], c = [];
    for (let i = 0; i < TECH.length; i++) if (!bitHas(p.tk, i) && !bitHas(p.tb, i) && TECH[i].e <= techEra(G, o) + 1 && TECH[i].k !== 'future') c.push(i);
    for (let k = 0; k < n && c.length; k++) giveBoost(G, o, c.splice(ri(c.length), 1)[0]);
  }
  function freeTechs(G, o, n) {
    for (let k = 0; k < n; k++) { const a = []; for (let i = 0; i < TECH.length; i++) if (techAvail(G, o, i) && TECH[i].k !== 'future') a.push(i); if (!a.length) return; grantTech(G, o, a.sort((x, y) => TECH[x].e - TECH[y].e)[0]); }
  }
  function freeCivics(G, o, n) {
    for (let k = 0; k < n; k++) { const a = []; for (let i = 0; i < CIVIC.length; i++) if (civicAvail(G, o, i) && CIVIC[i].k !== 'futureCiv') a.push(i); if (!a.length) return; grantCivic(G, o, a.sort((x, y) => CIVIC[x].e - CIVIC[y].e)[0]); }
  }

  /* ======================= 시대 점수(흥망성쇠) ======================= */
  function eraScore(G, o, n, why) {
    if (!isMaj(G, o)) return;
    const p = G.P[o]; p.es = (p.es || 0) + n;
    if (why) note(G, o, '⏳ 시대 점수 +' + n + ': ' + why, -1, 'era');
  }
  function eraScoreFirstEra(G, o) {
    const e = techEra(G, o), p = G.P[o];
    if (e > (p.me || 0)) {
      p.me = e;
      const first = !G.s.fe[e]; if (first) G.s.fe[e] = o + 1;
      eraScore(G, o, first ? 3 : 1, (first ? '세계 최초로 ' : '') + ERA[e] + ' 시대 진입');
    }
  }
  function ageThresholds(G) { const e = G.s.era; return { dark: 5 + e, gold: 13 + Math.round(1.5 * e) }; }
  function advanceEra(G) {
    const s = G.s, al = aliveMaj(G);
    if (s.era >= ERA.length - 1) return;
    const minLen = Math.round(30 * s.spP);
    const ready = al.filter((o) => techEra(G, o) >= s.era + 1).length;
    if (!(s.t - s.eraT >= minLen && ready * 2 >= al.length) && !(s.t - s.eraT >= minLen * 2 && ready > 0)) return;
    const th = ageThresholds(G);
    chronicle(G);
    s.era++; s.eraT = s.t;
    for (const o of al) {
      const p = G.P[o], prev = p.age, es = p.es || 0;
      let age = es < th.dark ? 0 : es >= th.gold ? 2 : 1;
      if (age === 2 && prev === 0) age = 3;
      p.age = age; p.esl = es; p.es = 0; p.ded = -1; p.ded2 = -1;
      p.dsel = age === 3 ? 2 : 1;
      note(G, o, '🌅 ' + ERA[s.era] + ' 시대가 열렸어요 — 우리는 ' + AGEN[age] + '! 헌신을 고르세요.', -1, 'age');
      if (p.lv > 0) aiDedication(G, o);
    }
    dirty(G);
  }
  function aiDedication(G, o) {
    const p = G.P[o], ag = CIVS[p.civ].ag;
    const sc = DEDI.map((d, i) => ({ i, v: R() + (d.k === 'free' ? (ag.sci || 0) : d.k === 'pen' ? (ag.cul || 0) : d.k === 'exodus' ? (ag.rel || 0) : d.k === 'conquer' ? (ag.war || 0) : d.k === 'coin' ? (ag.gold || 0) * 0.7 + 0.5 : d.k === 'monument' ? (G.s.era < 3 ? 1.5 : 0) : d.k === 'sky' ? (G.s.era >= 6 ? 2 : -1) : 0) }));
    sc.sort((a, b) => b.v - a.v);
    p.ded = sc[0].i; if (p.dsel >= 2) p.ded2 = sc[1].i; p.dsel = 0; dirty(G);
  }

  /* ======================= 위인 ======================= */
  function gpCost(G, cls) {
    const n = G.s.GP.n[cls] || 0, gp = GPL[G.s.GP.cur[cls]];
    if (cls === 'pro') return Math.round((60 + 50 * n) * G.s.spT);
    return Math.round((50 + 45 * (gp ? gp.e : G.s.era)) * (1 + 0.25 * n) * G.s.spT);
  }
  function maxReligions(G) { return Math.min(RELN.length, Math.floor(G.s.nM / 2) + 1); }
  function nextGP(G, cls) {
    const used = G.s.GP.used, e = G.s.era;
    if (cls === 'pro' && G.s.R.length + G.U.filter((u) => u.t === UTI.gp && GPL[u.g].c === 'pro').length >= maxReligions(G)) return -1;
    let best = -1;
    for (const gp of GPL) if (gp.c === cls && used.indexOf(gp.id) < 0 && gp.e <= e + 1) { if (best < 0 || gp.e < GPL[best].e) best = gp.id; }
    return best;
  }
  function refreshGP(G) { for (const c of GPK) { const cur = G.s.GP.cur[c]; if (cur == null || cur < 0 || G.s.GP.used.indexOf(cur) >= 0) G.s.GP.cur[c] = nextGP(G, c); else if (cur >= 0 && GPL[cur].e > G.s.era + 1) G.s.GP.cur[c] = nextGP(G, c); } }
  function gpPoints(G, o) {
    const p = G.P[o], M = mods(G, o), pts = {};
    for (const c of GPK) pts[c] = 0;
    for (const c of citiesOf(G, o)) {
      for (const dk in c.d) {
        if (G.dpil[c.d[dk]]) continue;
        const D = DIS[DISI[dk]]; if (!D.gp) continue;
        const cl = D.gp.split(',')[0]; pts[cl] += 1;
        if (dk === 'hs' && civK(G, o) === 'russia') { pts.wri += 1; pts.art += 1; pts.mus += 1; }
      }
      for (const k of c.b) {
        const b = BLD[BLDI[k]]; if (!b || !b.gp) continue;
        const bb = baseB(k);
        if (bb === 'amphi') pts.wri += 1; else if (bb === 'museum') pts.art += 1; else if (bb === 'broadcast') pts.mus += 1;
        else { const D = DIS[DISI[b.d]]; if (D && D.gp) pts[D.gp.split(',')[0]] += 1; }
        if (k === 'tlachtli') pts.gen += 1;
      }
      const cg = govFx(G, c, 'cGpp'); if (cg) for (const cl of GPK) pts[cl] += cg / 3;
      if (c.rl >= 0 && G.s.R[c.rl] && G.s.R[c.rl].bl.some((b) => BELIEF[b].k === 'warriorMonks') && c.d.hs != null) pts.gen += 1;
    }
    if (M.gpp) for (const k in M.gpp) pts[k] += M.gpp[k];
    if (M.gppAll) for (const k of GPK) pts[k] += M.gppAll;
    const f = 1 + mv0(M, 'gppP') / 100;
    for (const k of GPK) { pts[k] *= f; if (M.gppX && M.gppX[k]) pts[k] *= Math.max(0, 1 + M.gppX[k] / 100); }
    return pts;
  }
  function claimGP(G, o, cls, force) {
    const id = G.s.GP.cur[cls]; if (id == null || id < 0) return false;
    const p = G.P[o], cost = gpCost(G, cls);
    if ((p.gpp[cls] || 0) < cost) return false;
    if (p.lv > 0 && !force) {
      const cs = citiesOf(G, o);
      if ((cls === 'wri' || cls === 'art' || cls === 'mus') && !cs.some((c) => gwSlots(G, c, cls) > 0)) return false;
      if (cls === 'eng' && !cs.some((c) => c.q.some((q) => q.t === 'w' || (q.t === 'p' && PRJ[PRJI[q.k]].d === 'sp')))) return false;
      if (cls === 'pro' && (p.rel >= 0 || mods(G, o).noRel || !cs.some((c) => c.d.hs != null))) return false;
      if ((cls === 'gen' || cls === 'adm') && G.U.filter((u) => u.o === o && u.t === UTI.gp && GPL[u.g].c === cls).length >= 1) return false;
    }
    p.gpp[cls] -= cost;
    G.s.GP.used.push(id); G.s.GP.n[cls] = (G.s.GP.n[cls] || 0) + 1;
    G.s.GP.cur[cls] = nextGP(G, cls);
    const cap = capOf(G, o) || citiesOf(G, o)[0]; if (!cap) return true;
    const spot = spawnSpot(G, cap.p, UTI.gp, o);
    if (spot < 0) return true;
    const u = mkUnit(G, o, UTI.gp, spot); u.g = id;
    if (GPL[id].fx.gw) u.ch = GW_CH[GPL[id].fx.gw] || 1;
    if (p.gpPass) delete p.gpPass[cls];
    p.st.gp = (p.st.gp || 0) + 1; (p.st.gpc = p.st.gpc || {})[cls] = 1;
    eraScore(G, o, 2, GPL[id].n + ' 영입');
    noteAll(G, '⭐ ' + civName(G, o) + ': ' + GPC[cls].n + ' ' + GPL[id].n + ' 영입', -1, 'gp');
    return true;
  }
  function civName(G, o) { const p = G.P[o]; if (!p) return '?'; if (p.k === 'maj') return CIVS[p.civ].n; if (p.k === 'cs') return CSL[p.cs].n; if (p.k === 'fc') return '자유 도시'; return '야만인'; }

  /* ======================= 총독 ======================= */
  function govAppoint(G, o, gi) {
    const p = G.P[o]; if (p.gt <= 0 || p.gv.some((x) => x.g === gi)) return false;
    p.gt--; p.gv.push({ g: gi, c: -1, pr: 0, est: 0 }); return true;
  }
  function govPromote(G, o, gi) {
    const p = G.P[o], gv = p.gv.find((x) => x.g === gi);
    if (!gv || p.gt <= 0 || gv.pr >= 2) return false;
    p.gt--; gv.pr++; dirty(G); return true;
  }
  function govAssign(G, o, gi, cid) {
    const p = G.P[o], gv = p.gv.find((x) => x.g === gi), c = G.cid[cid];
    if (!gv || !c || c.o !== o) return false;
    for (const d of G.C) if (d.gv === gi && d.o === o) d.gv = -1;
    if (c.gv >= 0) { const old = p.gv.find((x) => x.g === c.gv); if (old) old.c = -1; }
    gv.c = cid; gv.est = Math.max(1, Math.round(3 * G.s.spT * 1.2)); c.gv = gi; dirty(G); return true;
  }

  /* ======================= 종교 ======================= */
  const PAN_COST = 25;
  function panCost(G) { return Math.round(PAN_COST * Math.max(0.6, G.s.spP)); }
  function panTaken(G) { const t = {}; for (const p of G.P) if (p.k === 'maj' && p.pan >= 0) t[p.pan] = 1; return t; }
  function belTaken(G) { const t = {}; for (const r of G.s.R) for (const b of r.bl) t[b] = 1; return t; }
  function foundPantheon(G, o, k) {
    const p = G.P[o];
    if (p.pan >= 0 || p.faith < panCost(G) || panTaken(G)[k]) return false;
    p.faith -= panCost(G); p.pan = k;
    if (PANTH[k].fx.freeBuilder) { const c = capOf(G, o); if (c) { const sp = spawnSpot(G, c.p, UTI.builder, o); if (sp >= 0) mkUnit(G, o, UTI.builder, sp); } }
    eraScore(G, o, 1, '만신전 「' + PANTH[k].n + '」');
    noteAll(G, '🙏 ' + civName(G, o) + ' 만신전: ' + PANTH[k].n, -1, 'rel');
    dirty(G); return true;
  }
  function foundReligion(G, o, u, ni, bF, bO) {
    const p = G.P[o];
    if (p.rel >= 0 || mods(G, o).noRel) return false;
    if (G.s.R.length >= maxReligions(G)) return false;
    if (G.s.R.some((r) => r.i === ni)) return false;
    const t = belTaken(G);
    if (BELIEF[bF].t !== 'F' || BELIEF[bO].t !== 'O' || t[bF] || t[bO]) return false;
    const c = tileCity(G, u.p); if (!c || c.o !== o || c.d.hs == null) return false;
    const ri2 = G.s.R.length;
    G.s.R.push({ i: ni, f: o, hc: c.id, bl: [bF, bO], en: 0 });
    p.rel = ri2; c.hc = ri2; c.rp = c.rp || {}; c.rp[ri2] = 1000;
    killUnit(G, u);
    eraScore(G, o, 3, RELN[ni] + ' 창시');
    noteAll(G, '⛪ ' + civName(G, o) + '가 ' + RELN[ni] + '를 창시했어요.', c.p, 'rel');
    esLog(G, 'rl', civName(G, o) + '|' + RELN[ni]);
    for (const d of G.C) recomputeRel(G, d);
    dirty(G); return true;
  }
  function enhanceCost(G) { return Math.round(200 * G.s.spP); }
  function enhanceReligion(G, o, bW, bE) {
    const p = G.P[o]; if (p.rel < 0) return false;
    const R2 = G.s.R[p.rel]; if (R2.en || p.faith < enhanceCost(G)) return false;
    const t = belTaken(G);
    if (BELIEF[bW].t !== 'W' || BELIEF[bE].t !== 'E' || t[bW] || t[bE]) return false;
    p.faith -= enhanceCost(G); R2.bl.push(bW, bE); R2.en = 1;
    eraScore(G, o, 2, RELN[R2.i] + ' 강화');
    dirty(G); return true;
  }
  function recomputeRel(G, c) {
    c.rp = c.rp || {};
    let best = -1, bv = 0, tot = 0;
    for (const k in c.rp) { tot += c.rp[k]; if (c.rp[k] > bv) { bv = c.rp[k]; best = +k; } }
    const base = 100 * c.pop;
    c.rl = best >= 0 && bv > (tot + base) * 0.5 ? best : -1;
    if (c.rl >= 0) {
      // 예배 건물
      const R2 = G.s.R[c.rl], wbB = R2.bl.find((b) => BELIEF[b].t === 'W');
      c.wb = wbB != null && hasB(c, 'worship') ? BELIEF[wbB].fx.wb : -1;
    } else c.wb = -1;
  }
  function followers(G, c, r) { const rp = c.rp || {}; let tot = 100 * c.pop; for (const k in rp) tot += rp[k]; return Math.round(c.pop * (rp[r] || 0) / Math.max(1, tot)); }
  function religionTick(G) {
    const add = {};
    for (const c of G.C) {
      if (c.rl < 0) continue;
      const M = isMaj(G, c.o) ? mods(G, G.s.R[c.rl].f) : {};
      const range = 9 + mv0(M, 'relRange');
      const strength = 1 + (c.hc === c.rl ? 3 : 0) + (c.d.hs != null ? 1 : 0) + (govFx(G, c, 'cPressP') ? 1 : 0);
      for (const j of within(G.g, c.p, range)) {
        const d = cityAt(G, j); if (!d || d === c) continue;
        const k = d.id; (add[k] = add[k] || {}); add[k][c.rl] = (add[k][c.rl] || 0) + strength * (c.pop >= 6 ? 1.5 : 1);
      }
      (add[c.id] = add[c.id] || {}); add[c.id][c.rl] = (add[c.id][c.rl] || 0) + strength * 2;
    }
    for (const c of G.C) {
      c.rp = c.rp || {};
      for (const k in c.rp) { c.rp[k] *= 0.97; if (c.rp[k] < 1) delete c.rp[k]; }
      const a = add[c.id]; if (a) for (const k in a) c.rp[k] = Math.min(3000, (c.rp[k] || 0) + a[k]);
      if (c.hc >= 0) c.rp[c.hc] = Math.max(c.rp[c.hc] || 0, 800);
      const before = c.rl; recomputeRel(G, c);
      if (c.rl !== before && c.rl >= 0) note(G, c.o, '⛪ ' + c.n + '이(가) ' + RELN[G.s.R[c.rl].i] + '를 믿게 되었어요.', c.p, 'rel');
    }
  }
  function spreadRel(G, u, c) {
    if (u.r < 0 || u.ch <= 0) return false;
    const strong = UT[u.t].k === 'apostle' ? 1.2 : 1;
    c.rp = c.rp || {};
    for (const k in c.rp) if (+k !== u.r) c.rp[k] *= 0.85;
    c.rp[u.r] = (c.rp[u.r] || 0) + 85 * Math.sqrt(c.pop) * strong * (1 + mv0(mods(G, u.o), 'relcs') / 20);
    recomputeRel(G, c);
    u.ch--; u.mv = 0;
    if (u.ch <= 0) killUnit(G, u);
    if (c.rl === u.r && c.o !== u.o) eraScore(G, u.o, 0);
    return true;
  }
  function removeHeresy(G, u, c) {
    if (u.ch <= 0) return false;
    for (const k in (c.rp || {})) if (+k !== u.r) c.rp[k] *= 0.2;
    recomputeRel(G, c); u.ch--; u.mv = 0; if (u.ch <= 0) killUnit(G, u); return true;
  }
  function relWinner(G) {
    const al = aliveMaj(G); if (al.length < 2) return -1;
    for (let r = 0; r < G.s.R.length; r++) {
      const f = G.s.R[r].f; if (!G.P[f].a) continue;
      let ok = true;
      for (const o of al) { const cs = citiesOf(G, o); if (!cs.length) continue; if (cs.filter((c) => c.rl === r).length * 2 <= cs.length) { ok = false; break; } }
      if (ok) return f;
    }
    return -1;
  }

  /* ======================= 생산 ======================= */
  function itemKey(it) { return it.t + ':' + it.k + (it.p != null ? '@' + it.p : ''); }
  function itemName(G, o, it) {
    if (it.t === 'u') return UT[UTI[it.k]].n;
    if (it.t === 'b') return it.k === 'worship' ? '예배 건물' : BLD[BLDI[it.k]].n;
    if (it.t === 'd') return distName(G, o, it.k);
    if (it.t === 'w') return WON[WONI[it.k]].n;
    if (it.t === 'p') return PRJ[PRJI[it.k]].n;
    return '?';
  }
  function unitFor(G, o, base) {
    const ck = civK(G, o);
    const u = UT.find((x) => x.civ === ck && x.rep === base);
    return u ? u.k : base;
  }
  function itemCost(G, c, it) {
    const s = G.s, o = c.o, p = G.P[o], sp = s.spP;
    if (it.t === 'u') {
      const T = UT[UTI[it.k]];
      if (T.k === 'settler') return Math.round((80 + 30 * (p.setc || 0)) * sp);
      if (T.k === 'builder') return Math.round((50 + 4 * (p.bldc || 0)) * sp);
      return Math.round(T.c * sp);
    }
    if (it.t === 'b') return Math.round((it.k === 'worship' ? 190 : BLD[BLDI[it.k]].c) * sp);
    if (it.t === 'd') {
      const D = DIS[DISI[it.k]];
      if (D.fixed) return Math.round(D.c * sp);
      const f = 1 + 5 * progFrac(G, o);
      return Math.round(D.c * f * sp * (civK(G, o) === 'brazil' && it.k === 'ent' ? 0.5 : 1));
    }
    if (it.t === 'w') return Math.round(WON[WONI[it.k]].c * sp);
    if (it.t === 'p') { const P2 = PRJ[PRJI[it.k]]; return Math.round(P2.c * sp * (P2.scaleEra ? 1 + techEra(G, o) * 0.6 : 1)); }
    return 9999;
  }
  // 생산 배율
  function itemMul(G, c, it) {
    const M = mods(G, c.o); let pct = 0;
    if (it.t === 'u') {
      const T = UT[UTI[it.k]];
      for (const pm of (M.pm || [])) if (pm[0].indexOf(T.cl) >= 0 && (T.era || 0) >= pm[1] && (T.era || 0) <= pm[2]) pct += pm[3];
      if (M.pmk && M.pmk[T.k]) pct += M.pmk[T.k];
      if (isNaval(UTI[it.k])) { pct += mv0(M, 'pmNaval'); if (civK(G, c.o) === 'phoenicia' && c.d.hb != null) pct += 50; }
      if (isMil(UTI[it.k])) pct += mv0(M, 'pmu');
      if (T.k === 'settler' && civK(G, c.o) === 'phoenicia' && c.d.hb != null) pct += 50;
    } else if (it.t === 'w') {
      const W = WON[WONI[it.k]];
      pct += mv0(M, 'wonderP');
      for (const pm of (M.pmw || [])) if (W.e >= pm[0] && W.e <= pm[1]) pct += pm[2];
      if (M.riverWonder && it.p != null && G.riv[it.p]) pct += M.riverWonder;
    } else if (it.t === 'd') {
      pct += mv0(M, 'pmDist');
      if (M.udt && M.udt[it.k]) pct += M.udt[it.k];
      if (M.riverWonder && it.p != null && G.riv[it.p]) pct += M.riverWonder;
      if (M.riverDistP && it.p != null && G.riv[it.p]) pct += M.riverDistP;
    } else if (it.t === 'b') {
      const b = BLD[BLDI[it.k]];
      if (b && b.wall) pct += mv0(M, 'wallP') + govFx(G, c, 'cWallP');
      if (b && M.udt && M.udt[b.d]) pct += M.udt[b.d] / 2;
      if (M.riverDistP && b && c.d[b.d] != null && G.riv[c.d[b.d]]) pct += M.riverDistP;
    } else if (it.t === 'p') pct += mv0(M, 'prjP');
    return Math.max(0.1, 1 + pct / 100);
  }
  function stratNeed(G, o, T) { return T.res ? Math.max(5, Math.round(10 * (G.s.spP > 0.6 ? 1 : 0.8))) : 0; }
  // 이 도시에서 만들 수 있나? (why: 이유 문자열 배열)
  function canBuild(G, c, it, why) {
    const o = c.o, p = G.P[o];
    const no = (m) => { if (why) why.push(m); return false; };
    if (it.t === 'u') {
      const ti = UTI[it.k]; if (ti == null) return no('?');
      const T = UT[ti];
      if (T.cl === 'gp') return no('위인은 만들 수 없어요');
      if (T.civ && T.civ !== civK(G, o)) return no('다른 문명 전용');
      if (!T.civ && unitFor(G, o, T.k) !== T.k) return no('고유 유닛으로 바뀌었어요');
      if (!hasReq(G, o, T.req)) return no('연구 필요');
      if (T.faith) return no('신앙으로 사요');
      if (T.k === 'settler' && c.pop < 2 && !govFx(G, c, 'cNoPop')) return no('인구 2 필요');
      if (isNaval(ti) && !coastal(G, c.p) && c.d.hb == null) return no('바닷가 도시만');
      if (T.coast && !coastal(G, c.p) && c.d.hb == null) return no('바닷가 도시만');
      // 낡은 유닛(업그레이드 유닛을 만들 수 있으면 숨김)
      if (T.up && p.k === 'maj') { const up = UT[UTI[unitFor(G, o, T.up)]]; if (up && hasReq(G, o, up.req) && (!up.res || (p.stk[RESI[up.res]] || 0) >= stratNeed(G, o, up))) return no('더 좋은 유닛이 있어요'); }
      if (T.res && p.k === 'maj' && (p.stk[RESI[T.res]] || 0) < stratNeed(G, o, T)) return no(RES[RESI[T.res]].n + ' ' + stratNeed(G, o, T) + ' 필요');
      if (T.k === 'trader' && p.tr.length + G.U.filter((u) => u.o === o && UT[u.t].k === 'trader').length >= tradeCap(G, o)) return no('교역로 한도');
      if (isAir(ti) && airBaseFor(G, c) < 0) return no('항공 기지 칸이 꽉 찼어요(비행장)');
      if (T.k === 'spy' && (p.spy || []).length + G.C.filter((d) => d.o === o && d !== c && d.q.some((q) => q.k === 'spy')).length >= spyCap(G, o)) return no('첩보원 한도 ' + spyCap(G, o));
      if (T.k === 'archaeo') { if (!cityHasB(c, 'archmus')) return no('고고학 박물관 필요'); if (gwSlots(G, c, 'arti') <= 0) return no('빈 유물 칸이 없어요'); if (G.U.some((u) => u.o === o && UT[u.t].k === 'archaeo' && u.hm === c.id)) return no('이 도시 고고학자가 이미 있어요'); }
      return true;
    }
    if (it.t === 'b') {
      if (it.k === 'worship') {
        if (!hasReq(G, o, 'worship')) return no('종교 강화 필요'); if (c.d.hs == null) return no('성지 필요');
        if (!cityHasB(c, 'temple')) return no('신전 필요'); if (hasB(c, 'worship')) return no('이미 있어요'); return true;
      }
      const b = BLD[BLDI[it.k]]; if (!b || b.k === 'palace') return no('?');
      if (hasB(c, b.k)) return no('이미 있어요');
      if (b.civ && b.civ !== civK(G, o)) return no('다른 문명 전용');
      if (!b.civ && bldOf(G, o, b.k) !== b.k) return no('고유 건물로 바뀌었어요');
      if (b.rep && hasB(c, b.rep)) return no('이미 있어요');
      if (!hasReq(G, o, b.req)) return no('연구 필요');
      if (b.d !== 'cc' && c.d[b.d] == null) return no(distName(G, o, b.d) + ' 필요');
      if (b.d !== 'cc' && c.d[b.d] != null && G.dpil[c.d[b.d]]) return no('약탈된 구역');
      if (b.pre && !cityHasB(c, b.pre)) return no(BLD[BLDI[bldOf(G, o, b.pre)]].n + ' 필요');
      if (b.preAny && !b.preAny.some((k) => cityHasB(c, k))) return no(b.preAny.map((k) => BLD[BLDI[k]].n).join('/') + ' 필요');
      if (b.xg && c.b.some((k) => BLD[BLDI[k]] && BLD[BLDI[k]].xg === b.xg)) return no('같은 종류가 있어요');
      if (b.river && !G.riv[c.p]) return no('강가 도시만');
      if (b.fb && !G.C.some((d) => d === c) ) return no('?');
      if (b.fb && !cityTiles(G, c).some((j) => G.low[j])) return no('저지대가 없어요');
      if (b.k === 'palace') return no('?');
      return true;
    }
    if (it.t === 'd') {
      const di = DISI[it.k], D = DIS[di]; if (!D || D.k === 'cc') return no('?');
      if (c.d[it.k] != null) return no('이미 있어요');
      if (!hasReq(G, o, D.req) && !(it.k === 'nb' && civK(G, o) === 'kongo' && hasCivic(G, o, 'guilds'))) return no('연구 필요');
      if (D.one && G.C.some((d) => d.o === o && d.d[it.k] != null)) return no('나라에 하나');
      if (D.one && G.C.some((d) => d.o === o && d.q.some((q) => q.t === 'd' && q.k === it.k) && d !== c)) return no('다른 도시에서 짓는 중');
      if (D.lim && distCount(c) + c.q.filter((q) => q.t === 'd' && DIS[DISI[q.k]].lim && c.d[q.k] == null && q.k !== it.k).length >= distLimit(G, c)) return no('인구가 더 필요해요(구역 한도)');
      if (it.p != null && !distSiteOK(G, c, it.k, it.p)) return no('놓을 수 없는 칸');
      if (it.p == null && !distSites(G, c, it.k).length) return no('놓을 칸이 없어요');
      return true;
    }
    if (it.t === 'w') {
      const W = WON[WONI[it.k]]; if (!W) return no('?');
      if (G.s.WB[it.k] != null) return no('이미 지어졌어요');
      if (!hasReq(G, o, W.req)) return no('연구 필요');
      if (G.C.some((d) => d.o === o && d !== c && d.q.some((q) => q.t === 'w' && q.k === it.k))) return no('다른 도시에서 짓는 중');
      if (it.p != null && !wonSiteOK(G, c, W, it.p)) return no('놓을 수 없는 칸');
      if (it.p == null && !wonSites(G, c, W).length) return no('조건에 맞는 칸이 없어요');
      return true;
    }
    if (it.t === 'p') {
      const P2 = PRJ[PRJI[it.k]]; if (!P2) return no('?');
      if (c.d[P2.d] == null) return no(distName(G, o, P2.d) + ' 필요');
      if (P2.req && !hasReq(G, o, P2.req)) return no('연구 필요');
      if (P2.sv) {
        const sv = p.sv;
        if (sv[P2.k]) return no('이미 했어요');
        if (P2.pre && !sv[P2.pre]) return no(PRJ[PRJI[P2.pre]].n + ' 먼저');
        if (G.C.some((d) => d.o === o && d !== c && d.q.some((q) => q.t === 'p' && q.k === P2.k))) return no('다른 도시에서 하는 중');
      }
      if (P2.k === 'laser' && (!p.sv.exo || (p.sv.las || 0) >= 4)) return no('외계 탐사대 필요');
      if (P2.once && (p.pj || {})[P2.k]) return no('이미 했어요');
      if (P2.once && G.C.some((d) => d.o === o && d !== c && d.q.some((q) => q.t === 'p' && q.k === P2.k))) return no('다른 도시에서 하는 중');
      if (P2.pre2 && !(p.pj || {})[P2.pre2]) return no(PRJ[PRJI[P2.pre2]].n + ' 먼저');
      if (P2.ura && (p.stk[RESI.uranium] || 0) < P2.ura) return no('우라늄 ' + P2.ura + ' 필요');
      if (P2.k === 'carbon' && G.s.CL.co2 <= 0) return no('줄일 탄소가 없어요');
      return true;
    }
    return false;
  }
  function distLimit(G, c) { return 1 + Math.floor((c.pop - 1) / 3) + mv0(mods(G, c.o), 'distLim'); }
  function distSiteOK(G, c, dk, i) {
    const D = DIS[DISI[dk]], o = c.o;
    if (G.own[i] !== c.id || i === c.p || hexDist(G.g, c.p, i) > 3) return false;
    if (G.dis[i] || G.won[i] || G.cat[i] >= 0) return false;
    if (G.C.some((d) => d.q.some((q) => (q.t === 'd' || q.t === 'w') && q.p === i && !(d === c && q.k === dk)))) return false;
    const nw = nwAt(G, i); if (nw) return false;
    if (G.feat[i] === F_ICE || G.feat[i] === F_VOLC) return false;
    const r = G.res[i]; if (r && RES[r].c !== 'b' && resVisible(G, o, r)) return false;
    const m = milAt(G, i); if (m && m.o !== o) return false;
    const nb = G.g.nb[i];
    if (D.water) { if (!(G.ter[i] === TC || G.ter[i] === TLK) || !nb.some((j) => isLand(G, j))) return false; return true; }
    if (!isLand(G, i) || G.ter[i] === TM) return false;
    if ((dk === 'enc' || (dk === 'ind' && civK(G, o) === 'gaul')) && nb.indexOf(c.p) >= 0) return false;
    if (dk === 'aq') { if (nb.indexOf(c.p) < 0) return false; if (!(G.riv[i] || nb.some((j) => G.ter[j] === TM || G.ter[j] === TLK || G.feat[j] === F_OASIS))) return false; }
    if (dk === 'dam') { if (G.feat[i] !== F_FLOOD || !G.riv[i]) return false; }
    if (dk === 'can') { if (nb.indexOf(c.p) < 0 && !nb.some((j) => isWater(G, j))) return false; if (!nb.some((j) => isWater(G, j))) return false; if (G.hill[i]) return false; }
    if ((dk === 'sp' || dk === 'ad') && G.hill[i]) return false;
    if (dk === 'pr' && nb.indexOf(c.p) >= 0) return false;
    if (dk === 'th' && civK(G, o) === 'greece' && !G.hill[i]) return false;
    return true;
  }
  function distSites(G, c, dk) { return within(G.g, c.p, 3).filter((i) => distSiteOK(G, c, dk, i)); }
  function wonSiteOK(G, c, W, i) {
    if (G.own[i] !== c.id || i === c.p || G.dis[i] || G.won[i] || nwAt(G, i)) return false;
    if (G.C.some((d) => d.q.some((q) => (q.t === 'd' || q.t === 'w') && q.p === i && !(d === c && q.k === W.k)))) return false;
    const r = G.res[i]; if (r && RES[r].c !== 'b' && resVisible(G, c.o, r)) return false;
    const nb = G.g.nb[i], dk = (j) => (DIS[G.dis[j]] ? DIS[G.dis[j]].k : '');
    const land = isLand(G, i) && G.ter[i] !== TM && G.feat[i] !== F_ICE;
    const flat = land && !G.hill[i];
    const adjD = (k) => nb.some((j) => dk(j) === k && G.own[j] === c.id);
    switch (W.on) {
      case 'desert': return land && G.ter[i] === TD && G.feat[i] !== F_FLOOD;
      case 'flatStone': return flat && nb.some((j) => G.res[j] === RESI.stone);
      case 'river': return land && G.riv[i] === 1;
      case 'riverAny': return land && G.riv[i] === 1;
      case 'hills': return land && G.hill[i] === 1;
      case 'coastLand': return land && coastal(G, i);
      case 'coastHarbor': return G.ter[i] === TC && adjD('hb');
      case 'flatEnc': return flat && adjD('enc');
      case 'flatEnt': return flat && adjD('ent');
      case 'flatCam': return flat && adjD('cam');
      case 'flatHs': return flat && adjD('hs');
      case 'flatTh': return flat && adjD('th');
      case 'woodsHs': return land && G.feat[i] === F_WOODS && adjD('hs');
      case 'hillsEnc': return land && G.hill[i] && adjD('enc');
      case 'rain': return land && G.feat[i] === F_RAIN;
      case 'flatAdjCC': return flat && nb.indexOf(c.p) >= 0;
      case 'hillsMtn': return land && G.hill[i] && nb.some((j) => G.ter[j] === TM);
      case 'coastInd': return G.ter[i] === TC && adjD('ind');
      case 'riverCom': return land && G.riv[i] && adjD('com');
      case 'riverInd': return land && G.riv[i] && adjD('ind');
      case 'flatAny': return flat;
      case 'snowTundra': return land && (G.ter[i] === TS || G.ter[i] === TT);
      case 'mountain': return G.ter[i] === TM && !nwAt(G, i);
    }
    return false;
  }
  function wonSites(G, c, W) { return within(G.g, c.p, 3).filter((i) => wonSiteOK(G, c, W, i)); }
  function tradeCap(G, o) {
    let n = hasCivic(G, o, 'foreignTrade') ? 1 : 0;
    for (const c of citiesOf(G, o)) { if (c.d.com != null) n++; else if (c.d.hb != null) n++; }
    return n + mv0(mods(G, o), 'trd');
  }
  // 생산 완료
  function complete(G, c, it) {
    const o = c.o, p = G.P[o];
    if (it.t === 'u') {
      const ti = UTI[it.k], T = UT[ti];
      if (T.k === 'spy') { p.spy = p.spy || []; p.spy.push({ id: G.s.q++, c: c.id, m: '', t: 0, tr: 0, lv: 1 }); note(G, o, '🕵 첩보원이 준비됐어요 — 첩보 화면에서 임무를 주세요.', c.p, 'spy'); return true; }
      if (T.k === 'settler') { if (!govFx(G, c, 'cNoPop')) c.pop = Math.max(1, c.pop - 1); p.setc = (p.setc || 0) + 1; }
      if (T.k === 'builder') p.bldc = (p.bldc || 0) + 1;
      if (T.res && p.k === 'maj') p.stk[RESI[T.res]] = Math.max(0, (p.stk[RESI[T.res]] || 0) - stratNeed(G, o, T));
      const spot = spawnSpot(G, c.p, ti, o);
      if (spot < 0) { note(G, o, c.n + ': 유닛을 놓을 자리가 없어요.', c.p); return false; }
      const u = mkUnit(G, o, ti, spot);
      u.mv = maxMv(G, u);
      // 경험치 건물
      let xpb = 0; for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && b.xp) xpb += 8; if (k === 'milacad') xpb += 8; }
      if (isMil(ti)) u.x = xpb;
      if (k2(T) === 'lc' && mods(G, o).doubleLC) { const s2 = spawnSpot(G, c.p, ti, o); if (s2 >= 0) mkUnit(G, o, ti, s2); }
      if (T.k === 'builder') u.ch = 3 + mv0(mods(G, o), 'chg') + govFx(G, c, 'cChg');
      if (c.b.indexOf('ordu') >= 0 && (T.cl === 'lc' || T.cl === 'hc')) u.mvb = 1;
      if (G.s.WB.terracotta === o && isMil(ti)) u.pp = (u.pp || 0) + 1;
      if (T.cl === 'rel') { u.r = c.rl >= 0 ? c.rl : p.rel; u.ch = T.sp + mv0(mods(G, o), 'relSpread'); }
      if (T.fp) u.pp = (u.pp || 0) + 1;
      if (T.k === 'archaeo') u.hm = c.id;
      if (isMil(ti) && civK(G, o) === 'macedon' && c.d.enc != null) addSci(G, o, itemCost(G, c, it) * 0.25);
      return true;
    }
    if (it.t === 'b') {
      if (it.k === 'worship') { c.b.push('worship'); recomputeRel(G, c); note(G, o, c.n + ': 예배 건물 완성', c.p, 'b'); dirty(G); return true; }
      const b = BLD[BLDI[it.k]];
      c.b.push(b.k);
      if (b.wall) { c.wl = b.wall; c.wh = Math.min(c.wl * 100, (c.wh || 0) + 100); }
      note(G, o, c.n + ': ' + b.n + ' 완성', c.p, 'b');
      dirty(G); return true;
    }
    if (it.t === 'd') {
      const di = DISI[it.k];
      if (!distSiteOK(G, c, it.k, it.p)) { note(G, o, c.n + ': ' + distName(G, o, it.k) + ' 자리를 쓸 수 없게 되어 취소됐어요.', c.p); return false; }
      G.dis[it.p] = di; G.dpil[it.p] = 0; c.d[it.k] = it.p; G.imp[it.p] = 0; G.pil[it.p] = 0;
      const Md = mods(G, o);
      if ((G.feat[it.p] === F_WOODS || G.feat[it.p] === F_RAIN || G.feat[it.p] === F_MARSH) && !Md.featDist) G.feat[it.p] = 0;
      if (it.k === 'enc' && Md.fortBomb) for (const j of G.g.nb[it.p]) if (G.own[j] < 0) G.own[j] = c.id;
      if (it.k === 'ent' && civK(G, o) === 'byzantium') { const hc = bestUnitFor(G, c, ['hc']); if (hc) { const sp = spawnSpot(G, c.p, UTI[hc.k], o); if (sp >= 0) mkUnit(G, o, UTI[hc.k], sp); } }
      if (G.res[it.p] && RES[G.res[it.p]].c === 'b') G.res[it.p] = 0;
      if (it.k === 'gov') { p.gt++; note(G, o, '👤 정부 청사: 총독 칭호 +1', -1, 'gov'); }
      if (it.k === 'dq') { p.env += 1; }
      const firstKind = !G.C.some((d) => d.o === o && d !== c && d.d[it.k] != null);
      if (firstKind && DIS[di].lim) eraScore(G, o, 1, '첫 ' + distName(G, o, it.k));
      if (firstKind && Md.freeFirstBld) { const fb = BLD.find((b) => b.d === it.k && !b.pre && !b.preAny && !b.civ && !b.power && !b.fuel); if (fb) { const bk = bldOf(G, o, fb.k); if (c.b.indexOf(bk) < 0) { c.b.push(bk); note(G, o, '🏛 ' + BLD[BLDI[bk]].n + '이(가) 공짜로 지어졌어요.', it.p, 'b'); } } }
      note(G, o, c.n + ': ' + distName(G, o, it.k) + ' 완성', it.p, 'd');
      assignWork(G, c); dirty(G); return true;
    }
    if (it.t === 'w') {
      const W = WON[WONI[it.k]];
      if (G.s.WB[it.k] != null) return false;
      if (!wonSiteOK(G, c, W, it.p)) { note(G, o, W.n + ' 자리를 쓸 수 없게 되었어요.', c.p); return false; }
      G.won[it.p] = WONI[it.k] + 1; G.imp[it.p] = 0; c.b.push('w:' + it.k); G.s.WB[it.k] = o;
      if (G.feat[it.p] === F_WOODS || G.feat[it.p] === F_RAIN || G.feat[it.p] === F_MARSH) G.feat[it.p] = 0;
      dirty(G);
      const fx = W.fx;
      if (fx.freeGP) { const cl = fx.freeGP; const id = G.s.GP.cur[cl]; if (id != null && id >= 0) { p.gpp[cl] = (p.gpp[cl] || 0) + gpCost(G, cl); claimGP(G, o, cl, true); } }
      if (fx.freeBoost) randomBoosts(G, o, fx.freeBoost);
      if (fx.freeTech) freeTechs(G, o, fx.freeTech);
      if (fx.freeCivic) freeCivics(G, o, fx.freeCivic);
      if (fx.promoAll) for (const u of G.U) if (u.o === o && isMil(u.t)) u.pp = (u.pp || 0) + 1;
      if (fx.treasury) p.gold += Math.min(1000, p.gold);
      if (fx.dvp) p.dvp += fx.dvp;
      if (fx.gwSlot) c.gws = (c.gws || 0) + fx.gwSlot;
      eraScore(G, o, 4, W.n + ' 완성');
      noteAll(G, '🏛 ' + civName(G, o) + '가 ' + W.n + '을(를) 완성했어요.', it.p, 'won');
      esLog(G, 'wo', civName(G, o) + '|' + W.n);
      if (isMaj(G, o) && !(G.P[o].lv > 0)) { const fs = aliveMaj(G).filter((f) => G.P[f].lv > 0 && met(G, f, o) && ((CIVS[G.P[f].civ].ag.won || 0) + (CIVS[G.P[f].civ].ag.cul || 0) > 0 || R() < 0.3)); if (fs.length) say(G, pickR(fs), o, 'wonder', { won: W.n }); }
      // 같은 불가사의를 짓던 다른 도시: 생산을 돌려받지 않고 바꿔요
      for (const d of G.C) if (d !== c) { const qi = d.q.findIndex((q) => q.t === 'w' && q.k === it.k); if (qi >= 0) { const lost = d.pp[itemKey(d.q[qi])] || 0; d.q.splice(qi, 1); note(G, d.o, d.n + ': ' + W.n + '을(를) 다른 나라가 먼저 지었어요(생산 ' + Math.round(lost) + ' 유지).', d.p); } }
      ev(G, { k: 'w', p: it.p, o });
      return true;
    }
    if (it.t === 'p') {
      const P2 = PRJ[PRJI[it.k]], M = mods(G, o);
      if (P2.sv) {
        p.sv[P2.k] = 1; eraScore(G, o, 3, P2.n);
        noteAll(G, '🚀 ' + civName(G, o) + ': ' + P2.n + ' 성공!', c.p, 'space');
        if (P2.k === 'sat') { const ex = G.ex[o]; for (let i = 0; i < G.N; i++) ex[i] = 1; }
        if (P2.k === 'exo') { p.sv.ly = 0; p.sv.las = 0; }
      } else if (P2.k === 'laser') { p.sv.las = (p.sv.las || 0) + 1; }
      else if (P2.k === 'carbon') { G.s.CL.co2 = Math.max(0, G.s.CL.co2 - 250); }
      else if (P2.once) { (p.pj = p.pj || {})[P2.k] = 1; noteAll(G, '☢ ' + civName(G, o) + ': ' + P2.n + ' 완료', c.p, 'nuke'); }
      else if (P2.k === 'nukeA' || P2.k === 'nukeT') { p.stk[RESI.uranium] = Math.max(0, (p.stk[RESI.uranium] || 0) - P2.ura); p.nk = p.nk || {}; const kk = P2.k === 'nukeA' ? 'a' : 't'; p.nk[kk] = (p.nk[kk] || 0) + 1; note(G, o, '☢ ' + (kk === 'a' ? '원자폭탄' : '열핵 폭탄') + ' 1발 준비', c.p, 'nuke'); }
      else if (P2.gpp) {
        const amt = itemCost(G, c, it);
        p.gpp[P2.gpp] = (p.gpp[P2.gpp] || 0) + Math.round(amt / 25 + 3);
        if (P2.gpp === 'sci') addSci(G, o, amt * 0.3); else if (P2.gpp === 'wri') addCul(G, o, amt * 0.3); else if (P2.gpp === 'mer') p.gold += Math.round(amt * 0.4);
      }
      return true;
    }
    return false;
  }
  const k2 = (T) => T.cl;
  function cityProduce(G, c, prod) {
    let left = prod, guard = 0;
    while (left > 0 && guard++ < 4) {
      const it = c.q[0];
      if (!it) { G.P[c.o].gold += left * 0.25; return; }
      if (!canBuild(G, c, it)) { c.q.shift(); note(G, c.o, c.n + ': ' + itemName(G, c.o, it) + '을(를) 만들 수 없게 되어 뺐어요.', c.p, 'prod'); continue; }
      const key = itemKey(it), cost = itemCost(G, c, it), mul = itemMul(G, c, it);
      c.pp[key] = (c.pp[key] || 0) + left * mul;
      if (c.pp[key] >= cost) {
        const over = (c.pp[key] - cost) / mul;
        delete c.pp[key];
        const done = complete(G, c, it);
        if (done || it.t !== 'u') c.q.shift();
        if (!done && it.t === 'u') { c.pp[key] = cost; return; }
        if (it.t === 'p' && PRJ[PRJI[it.k]].rep) { /* 반복 프로젝트는 대기열에서 빠져요 */ }
        left = Math.min(over, prod);
      } else left = 0;
    }
    // 오래된 진행분 정리
    const keys = Object.keys(c.pp); if (keys.length > 8) for (const k of keys.slice(0, keys.length - 8)) delete c.pp[k];
  }
  // 구매
  function buyCost(G, c, it, cur) {
    const M = mods(G, c.o), base = itemCost(G, c, it), done = c.pp[itemKey(it)] || 0;
    const rem = Math.max(0, base - done);
    if (cur === 'f') {
      if (it.t === 'u') { const T = UT[UTI[it.k]]; if (T.faith) return Math.round(T.c * G.s.spP * (1 + mv0(M, 'relCost') / 100)); return Math.round(rem * 2); }
      return Math.round(rem * 2);
    }
    let f = it.t === 'u' ? 4 : 4;
    if (c.d.com != null && civK(G, c.o) === 'mali') f *= 0.8;
    return Math.round(rem * f * (1 + mv0(M, 'buyP') / 100));
  }
  function canBuy(G, c, it, cur, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    if (it.t === 'd' || it.t === 'w' || it.t === 'p') return no('구역·불가사의·프로젝트는 살 수 없어요');
    const o = c.o, p = G.P[o], M = mods(G, o);
    if (cur === 'f') {
      if (it.t === 'u') {
        const T = UT[UTI[it.k]];
        if (T.faith) {
          if (!hasReq(G, o, T.req)) return no('종교 필요');
          if (c.rl < 0 && p.rel < 0) return no('종교 필요');
          if (T.bld ? !cityHasB(c, T.bld) : (c.d.hs == null && !cityHasB(c, 'shrine'))) return no((T.bld ? BLD[BLDI[T.bld]].n : '사당') + ' 필요');
        } else if (!(M.faithBuyLand && isMil(UTI[it.k]) && !isNaval(UTI[it.k])) && !(M.faithBuyNaval && isNaval(UTI[it.k])) && !((T.k === 'settler' || T.k === 'builder') && (p.ded === 1 || p.ded2 === 1))) return no('신앙으로 살 수 없어요');
        else if (!canBuild(G, c, it, why)) return false;
      } else {
        const b = BLD[BLDI[it.k]];
        const jes = c.rl >= 0 && G.s.R[c.rl] && G.s.R[c.rl].bl.some((x) => BELIEF[x].k === 'jesuit');
        if (!(it.k === 'worship' || (b && b.d === 'hs') || (jes && b && (b.d === 'cam' || b.d === 'th')))) return no('신앙으로 살 수 없어요');
        if (!canBuild(G, c, it, why)) return false;
      }
      if (p.faith < buyCost(G, c, it, 'f')) return no('신앙 부족');
      return true;
    }
    if (it.t === 'u' && UT[UTI[it.k]].faith) return no('신앙으로만');
    if (!canBuild(G, c, it, why)) return false;
    if (p.gold < buyCost(G, c, it, 'g')) return no('금 부족');
    return true;
  }
  function doBuy(G, c, it, cur) {
    const p = G.P[c.o], cost = buyCost(G, c, it, cur);
    if (it.t === 'u' && UT[UTI[it.k]].faith) {
      const ti = UTI[it.k], sp = spawnSpot(G, c.p, ti, c.o); if (sp < 0) return false;
      p.faith -= cost; const u = mkUnit(G, c.o, ti, sp); u.r = c.rl >= 0 ? c.rl : p.rel; u.ch = UT[ti].sp + mv0(mods(G, c.o), 'relSpread'); return true;
    }
    if (cur === 'f') p.faith -= cost; else p.gold -= cost;
    const ok = complete(G, c, it);
    if (!ok) { if (cur === 'f') p.faith += cost; else p.gold += cost; return false; }
    const qi = c.q.findIndex((q) => itemKey(q) === itemKey(it)); if (qi >= 0) c.q.splice(qi, 1);
    delete c.pp[itemKey(it)];
    return true;
  }
  function tileBuyCost(G, c, i) {
    const d = hexDist(G.g, c.p, i), n = cityTiles(G, c).length, M = mods(G, c.o);
    return Math.round((25 + 12 * d * d + 2 * n) * G.s.spP * 1.5 * (1 + (mv0(M, 'tileP') + govFx(G, c, 'cTileP')) / 100));
  }
  function canBuyTile(G, c, i) {
    if (G.own[i] >= 0 || hexDist(G.g, c.p, i) > 3) return false;
    return G.g.nb[i].some((j) => G.own[j] === c.id);
  }
  function claimTile(G, c, i) { G.own[i] = c.id; delete G.yc[c.id]; if (G.imp[i] === IMPI.bcamp) { /* 야영지는 남아요 */ } }
  function borderGrow(G, c, cul) {
    c.bt = (c.bt || 0) + cul;
    const n = cityTiles(G, c).length;
    const need = Math.round((10 + Math.pow(6 * Math.max(0, n - 7), 1.3)) * G.s.spP);
    if (c.bt < need) return;
    const cand = []; for (const j of within(G.g, c.p, 3)) if (canBuyTile(G, c, j)) cand.push(j);
    if (!cand.length) { c.bt = need; return; }
    let best = cand[0], bv = -1e9;
    for (const j of cand) { const y = tileYield(G, j, c.o); const v = y[0] * 1.2 + y[1] + y[2] * 0.5 + y[3] + y[4] + (G.res[j] ? 3 : 0) - hexDist(G.g, c.p, j) * 0.8 + R() * 0.3; if (v > bv) { bv = v; best = j; } }
    claimTile(G, c, best); c.bt -= need;
  }

  /* ======================= 외교 상태 도우미 ======================= */
  const dkey = (a, b) => (a < b ? a + ',' + b : b + ',' + a);
  function dipRec(G, a, b) { const k = dkey(a, b); return G.s.D[k] || (G.s.D[k] = { s: 1, t: 0 }); }
  function dipSt(G, a, b) {
    if (a === b) return 4;
    const pa = G.P[a], pb = G.P[b]; if (!pa || !pb) return 1;
    if (pa.k === 'bb' || pb.k === 'bb' || pa.k === 'fc' || pb.k === 'fc') return 0;
    const r = G.s.D[dkey(a, b)]; return r ? r.s : 1;
  }
  const atWar = (G, a, b) => a !== b && dipSt(G, a, b) === 0;
  function met(G, a, b) { if (a === b) return true; const p = G.P[a]; if (!p || !p.met) return true; return bitHas(p.met, b); }
  function meet(G, a, b) {
    if (a === b || a < 0 || b < 0) return;
    const pa = G.P[a], pb = G.P[b]; if (!pa || !pb || pa.k === 'bb' || pb.k === 'bb' || pa.k === 'fc' || pb.k === 'fc') return;
    if (pa.met && !bitHas(pa.met, b)) {
      pa.met = bitSet(pa.met, b);
      if (pa.k === 'maj') {
        if (pb.k === 'maj') { eraScore(G, a, 1, CIVS[pb.civ].n + ' 만남'); note(G, a, '🤝 ' + CIVS[pb.civ].n + '(' + CIVS[pb.civ].ld + ')를 만났어요.', -1, 'meet'); say(G, b, a, 'greet'); }
        else if (pb.k === 'cs') {
          const first = !G.P.some((q) => q.k === 'maj' && q !== pa && q.met && bitHas(q.met, b));
          if (first) { pb.envs[a] = (pb.envs[a] || 0) + 1; eraScore(G, a, 1, CSL[pb.cs].n + ' 처음 만남(사절 +1)'); updateSuz(G, b); }
          note(G, a, '🏰 도시국가 ' + CSL[pb.cs].n + '(' + CST[CSL[pb.cs].t][0] + ')를 만났어요.', -1, 'meet');
        }
      }
    }
    if (pb.met && !bitHas(pb.met, a)) meet(G, b, a);
  }
  // 영토 출입(국경 폐쇄: 평화 중인 주요 문명 영토는 친선·동맹이 아니면 군사 유닛이 못 들어가요)
  // 국경 개방(거래로 owner가 o에게 열어 준 경우)
  function openBorders(G, owner, o) { for (const d of (G.s.DL || [])) if (d.ob && d.a === owner && d.b === o && d.t > 0) return true; return false; }
  function canEnterTerritory(G, o, i, t) {
    const ow = tileOwner(G, i); if (ow < 0 || ow === o) return true;
    if (!isMaj(G, ow) || !isMaj(G, o)) return true;
    const st = dipSt(G, o, ow); if (st === 0 || st >= 2) return true;
    if (openBorders(G, ow, o)) return true;
    const cl = UT[t].cl; return cl === 'rel' || UT[t].k === 'trader' || cl === 'gp' || UT[t].k === 'scout' && G.s.era < 1;
  }

  /* ======================= 유닛 ======================= */
  function mkUnit(G, o, t, p) {
    const u = { id: G.s.q++, o, t, p, hp: 100, mv: 0, x: 0, pr: [], f: 0 };
    const T = UT[t];
    if (T.ch) u.ch = T.ch;
    G.U.push(u); G.uid[u.id] = u;
    if (isGround(t)) G.mil[p] = u.id; else if (T.cl === 'civ' || T.cl === 'sup') G.civ[p] = u.id;
    reveal(G, o, p, sightOf(G, u));
    return u;
  }
  function killUnit(G, u) {
    const i = G.U.indexOf(u); if (i >= 0) G.U.splice(i, 1);
    delete G.uid[u.id];
    if (G.mil[u.p] === u.id) G.mil[u.p] = -1;
    if (G.civ[u.p] === u.id) G.civ[u.p] = -1;
  }
  function placeUnit(G, u, to) {
    if (G.mil[u.p] === u.id) G.mil[u.p] = -1;
    if (G.civ[u.p] === u.id) G.civ[u.p] = -1;
    u.p = to;
    const cl = UT[u.t].cl;
    if (isGround(u.t)) G.mil[to] = u.id; else if (cl === 'civ' || cl === 'sup') G.civ[to] = u.id;
  }
  // 항공 기지: 도시 2칸, 비행장 2칸 + 격납고·공항
  function airCap(G, i, o) {
    const c = cityAt(G, i); if (c) return c.o === o ? 2 : 0;
    if (DIS[G.dis[i]] && DIS[G.dis[i]].k === 'ad' && !G.dpil[i]) { const tc = tileCity(G, i); if (!tc || tc.o !== o) return 0; let n = 2; for (const k of tc.b) { const b = BLD[BLDI[k]]; if (b && b.air) n += b.air; } return n; }
    return 0;
  }
  const airAt = (G, i) => G.U.filter((u) => u.p === i && isAir(u.t));
  function airBaseFor(G, c) { if (airAt(G, c.p).length < airCap(G, c.p, c.o)) return c.p; if (c.d.ad != null && airAt(G, c.d.ad).length < airCap(G, c.d.ad, c.o)) return c.d.ad; return -1; }
  function spawnSpot(G, at, t, o) {
    if (isAir(t)) { const c = cityAt(G, at); return c ? airBaseFor(G, c) : -1; }
    const ok = (i) => {
      if (isNaval(t) ? !(isWater(G, i) || G.cat[i] >= 0) : !(passableLand(G, i) || G.cat[i] >= 0)) return false;
      if (isNaval(t) && UT[t].coast && G.ter[i] === TO) return false;
      const own = tileOwner(G, i); if (own >= 0 && own !== o && !(G.cat[i] >= 0 && G.cid[G.cat[i]].o === o)) return false;
      const m = milAt(G, i), cv = civAt(G, i);
      if (isMil(t)) return !m; const cl = UT[t].cl; if (cl === 'civ' || cl === 'sup') return !cv && !(m && m.o !== o);
      return !(m && m.o !== o);
    };
    if (ok(at)) return at;
    for (let r = 1; r <= 3; r++) for (const j of within(G.g, at, r)) if (hexDist(G.g, at, j) === r && ok(j)) return j;
    return -1;
  }
  function promoVal(u, key) { let v = 0; const L2 = PROMO[UT[u.t].cl]; if (!L2) return 0; for (const k of u.pr) if (L2[k] && L2[k][1] === key) v += L2[k][2]; return v; }
  function maxMv(G, u) {
    const T = UT[u.t], M = mods(G, u.o);
    let m = T.mv + promoVal(u, 'mv') + (u.mvb || 0);
    if (isMil(u.t)) m += mv0(M, 'mv');
    if (isNaval(u.t)) m += mv0(M, 'mvSea') + (G.s.WB.lighthouseW === u.o ? 1 : 0) + (civK(G, u.o) === 'england' && u.mvb2 ? 1 : 0);
    if (T.cl === 'rel') m += mv0(M, 'relMv');
    if (T.k === 'scout' && M.xpr) m += 1;
    if (isLand(G, u.p) || G.cat[u.p] >= 0) return m;
    if (!isNaval(u.t)) return 3 + (hasTech(G, u.o, 'steam') ? 1 : 0) + (hasTech(G, u.o, 'combustion') ? 1 : 0);
    return m;
  }
  function sightOf(G, u) { if (!u) return 2; const T = UT[u.t]; let s = 2 + promoVal(u, 'sight'); if (T.cl === 'rec') s++; if (G.hill[u.p] && isLand(G, u.p)) s++; return s; }
  function reveal(G, o, p, r) {
    if (!G.ex[o]) return;
    const ex = G.ex[o];
    for (const j of within(G.g, p, r)) {
      if (!ex[j]) { ex[j] = 1; if (G.feat[j] >= NW0 && isMaj(G, o)) { eraScore(G, o, 1, NW[G.feat[j] - NW0].n + ' 발견'); } }
    }
  }
  // 이번 턴 보이는 칸
  function visOf(G, o) {
    const v = new Uint8Array(G.N);
    const src = [o];
    for (const q of aliveMaj(G)) if (q !== o && dipSt(G, o, q) === 3) src.push(q);
    for (const s2 of src) {
      for (const u of G.U) if (u.o === s2) for (const j of within(G.g, u.p, sightOf(G, u))) v[j] = 1;
      for (const c of G.C) if (c.o === s2) { for (const j of within(G.g, c.p, 3)) v[j] = 1; for (const j of cityTiles(G, c)) { v[j] = 1; for (const k of G.g.nb[j]) v[k] = 1; } }
    }
    if (isMaj(G, o) && G.P[o].sv && G.P[o].sv.sat) v.fill(1);
    if (isMaj(G, o)) for (const sp of (G.P[o].spy || [])) if (sp.m === 'intel' && !(sp.tr > 0) && G.cid[sp.c]) for (const j of within(G.g, G.cid[sp.c].p, 2)) v[j] = 1;
    return v;
  }
  function exploreNow(G, o) {
    if (!G.ex[o]) return;
    const v = visOf(G, o), ex = G.ex[o];
    for (let i = 0; i < G.N; i++) if (v[i] && !ex[i]) { ex[i] = 1; if (G.feat[i] >= NW0 && isMaj(G, o)) eraScore(G, o, 1, NW[G.feat[i] - NW0].n + ' 발견'); }
    // 만남
    for (const u of G.U) if (u.o !== o && v[u.p]) meet(G, o, u.o);
    for (const c of G.C) if (c.o !== o && (v[c.p] || cityTiles(G, c).some((j) => v[j]))) meet(G, o, c.o);
  }

  /* ----- 이동 ----- */
  function embarkOK(G, o, i) {
    if (!isMaj(G, o)) return G.ter[i] !== TO && G.s.era >= 1;
    if (G.ter[i] === TO) return hasTech(G, o, 'cartography');
    return hasTech(G, o, 'shipbuilding');
  }
  function enemyZOC(G, o, i) {
    for (const j of G.g.nb[i]) {
      const m = milAt(G, j); if (m && m.o !== o && atWar(G, m.o, o) && !isNaval(m.t) === isLand(G, i)) return true;
      const c = cityAt(G, j); if (c && c.o !== o && atWar(G, c.o, o)) return true;
    }
    return false;
  }
  // from→to 이동 비용(Infinity: 못 감, -1: 남은 이동력 전부)
  function stepCost(G, u, from, to) {
    const o = u.o, T = UT[u.t];
    const c = cityAt(G, to);
    if (c && c.o !== o) { if (!isMaj(G, c.o) || dipSt(G, o, c.o) < 3 || isMil(u.t)) return Infinity; }
    if (!canEnterTerritory(G, o, to, u.t)) return Infinity;
    if (isNaval(u.t)) {
      const can = DIS[G.dis[to]] && DIS[G.dis[to]].k === 'can' && tileOwner(G, to) === o;
      if (!(isWater(G, to) || (c && c.o === o) || can)) return Infinity;
      if (G.feat[to] === F_ICE) return Infinity;
      if (T.coast && G.ter[to] === TO) return Infinity;
      return 1;
    }
    const toW = isWater(G, to) && !(c && c.o === o) && !(G.feat[to] >= 0 && IMP[G.imp[to]] && IMP[G.imp[to]].k === 'polder');
    const fromW = isWater(G, from) && G.cat[from] < 0 && !(IMP[G.imp[from]] && IMP[G.imp[from]].k === 'polder');
    if (toW) { if (G.feat[to] === F_ICE || G.feat[to] >= NW0) return Infinity; if (!embarkOK(G, o, to)) return Infinity; if (T.cl === 'sup' && T.k !== 'medic') return Infinity; return fromW ? 1 : -1; }
    if (!passableLand(G, to) && !c) { if (!(G.ter[to] === TM && mods(G, o).mtnWork && false)) return Infinity; }
    if (fromW) return -1;
    const bridge = G.road[to] && G.road[from] && (!isMaj(G, o) || hasTech(G, o, 'engineering'));
    if (riverBetween(G, from, to) && !bridge) return -1;
    if (G.road[to] && G.road[from]) return G.road[to] >= 2 && G.road[from] >= 2 ? 0.25 : 0.5;
    let cost = 1;
    if (G.hill[to] && T.k !== 'oromo') cost++;
    const f = G.feat[to]; if ((f === F_WOODS || f === F_RAIN || f === F_MARSH) && T.cl !== 'rec') cost++;
    if (T.cl === 'rec' && G.hill[to] && UT[u.t].k !== 'scout') cost = Math.max(1, cost - 1);
    return cost;
  }
  function occupiedFor(G, u, i) {
    const cl = UT[u.t].cl, m = milAt(G, i), cv = civAt(G, i);
    if (isMil(u.t)) return !!(m && m !== u);
    if (cl === 'civ' || cl === 'sup') return !!(cv && cv !== u) || !!(m && m.o !== u.o);
    return !!(m && m.o !== u.o && atWar(G, m.o, u.o));
  }
  function passThrough(G, u, i) {
    const m = milAt(G, i), cv = civAt(G, i);
    if (m && m.o !== u.o && !(UT[u.t].cl === 'rel' || UT[u.t].cl === 'gp')) return false;
    if (cv && cv.o !== u.o && isMil(u.t) && atWar(G, cv.o, u.o)) return false;
    return true;
  }
  // 이번 턴에 갈 수 있는 칸: {tile: 남은 이동력}, prev
  function reach(G, u, budget) {
    const mv = budget != null ? budget : u.mv, full = budget != null ? budget : maxMv(G, u);
    const best = new Map(), prev = new Map();
    best.set(u.p, mv);
    const open = [[u.p, mv]];
    while (open.length) {
      let bi = 0; for (let k = 1; k < open.length; k++) if (open[k][1] > open[bi][1]) bi = k;
      const [i, rem] = open.splice(bi, 1)[0];
      if (rem < (best.get(i) || -1)) continue;
      if (rem <= 0) continue;
      if (i !== u.p && enemyZOC(G, u.o, i) && isMil(u.t)) continue;
      for (const j of G.g.nb[i]) {
        let c = stepCost(G, u, i, j);
        if (c === Infinity) continue;
        if (!passThrough(G, u, j)) continue;
        let r;
        if (c === -1) r = 0; else { if (rem < c && !(rem >= full - 0.01 && rem >= 1)) { if (rem < 1) continue; r = 0; } else r = rem - c; }
        if (isMil(u.t) && enemyZOC(G, u.o, j)) r = 0;
        if (r > (best.has(j) ? best.get(j) : -1)) { best.set(j, r); prev.set(j, i); open.push([j, r]); }
      }
    }
    const out = {};
    for (const [k, v] of best) if (k !== u.p && !occupiedFor(G, u, k)) out[k] = v;
    return { r: out, prev };
  }
  // 여러 턴 경로(A*: 비용 = 이동력)
  function pathTo(G, u, goal, maxSteps) {
    if (goal === u.p) return [u.p];
    const full = maxMv(G, u) || 1, dist = new Map(), prev = new Map();
    const h = (i) => hexDist(G.g, i, goal);
    dist.set(u.p, 0);
    const open = [[u.p, h(u.p)]];
    let n = 0;
    while (open.length && n++ < (maxSteps || 1400)) {
      let bi = 0; for (let k = 1; k < open.length; k++) if (open[k][1] < open[bi][1]) bi = k;
      const [i] = open.splice(bi, 1)[0];
      if (i === goal) break;
      const d0 = dist.get(i);
      for (const j of G.g.nb[i]) {
        let c = stepCost(G, u, i, j);
        if (c === Infinity) { if (j === goal && (G.cat[j] >= 0 || milAt(G, j))) c = 1; else continue; }
        if (j !== goal && !passThrough(G, u, j)) continue;
        if (c === -1) c = full * 0.9;
        if (j !== goal && milAt(G, j) && milAt(G, j).o === u.o && isMil(u.t)) c += 0.3;
        const nd = d0 + c;
        if (nd < (dist.has(j) ? dist.get(j) : 1e9)) { dist.set(j, nd); prev.set(j, i); open.push([j, nd + h(j)]); }
      }
    }
    if (!prev.has(goal)) return null;
    const path = [goal]; let k = goal; while (k !== u.p) { k = prev.get(k); path.push(k); }
    return path.reverse();
  }
  function moveUnit(G, u, to) {
    const R2 = reach(G, u);
    if (R2.r[to] == null) return false;
    const path = [to]; let k = to; while (R2.prev.get(k) !== u.p && R2.prev.has(k)) { k = R2.prev.get(k); path.push(k); }
    path.reverse();
    const from = u.p;
    placeUnit(G, u, to); u.mv = R2.r[to]; u.f = 0; u.mvd = 1; u.sl = 0;
    reveal(G, u.o, to, sightOf(G, u));
    for (const j of path) reveal(G, u.o, j, 1);
    ev(G, { k: 'm', u: u.id, o: u.o, t: u.t, path: [from].concat(path) });
    afterMove(G, u);
    return true;
  }
  // 경로를 따라 이번 턴 갈 수 있는 만큼
  function goToward(G, u, goal) {
    const path = pathTo(G, u, goal); if (!path || path.length < 2) return false;
    const R2 = reach(G, u);
    let dest = -1;
    for (let k = path.length - 1; k >= 1; k--) if (R2.r[path[k]] != null) { dest = path[k]; break; }
    if (dest < 0) return false;
    return moveUnit(G, u, dest);
  }
  // 부족 마을 선물(원작처럼 종류를 무작위로)
  // 고고학: 고대 유적 발굴
  function doDig(G, u) {
    if (UT[u.t].k !== 'archaeo' || (u.ch || 0) <= 0 || G.imp[u.p] !== IMPI.ant || u.mv <= 0) return false;
    const ow = tileOwner(G, u.p); if (ow >= 0 && ow !== u.o && !atWar(G, ow, u.o) && !openBorders(G, ow, u.o)) return false;
    const meta = (G.s.AS || {})[u.p] || [Math.max(0, G.s.era - 2), -1 - u.p];
    const home = G.cid[u.hm];
    const c = placeGW(G, u.o, { c: 'arti', n: -1, e: meta[0], o: meta[1] }, home && home.o === u.o ? home : null);
    if (!c) return false;
    G.imp[u.p] = 0; if (G.s.AS) delete G.s.AS[u.p];
    u.ch--; u.mv = 0; if (u.ch <= 0) killUnit(G, u);
    eraScore(G, u.o, 1, '유물 발굴');
    note(G, u.o, '🏺 유물(' + ERA[meta[0]] + ' · ' + (meta[1] >= 0 && G.P[meta[1]] && G.P[meta[1]].k === 'maj' ? CIVS[G.P[meta[1]].civ].n : '옛 문명') + ')을 ' + c.n + '에 넣었어요.', u.p, 'gw');
    return true;
  }
  function markAntiquity(G, i, e, o) {
    if (!passableLand(G, i) || G.imp[i] || G.dis[i] || G.cat[i] >= 0 || G.won[i] || G.feat[i] >= NW0) return;
    G.imp[i] = IMPI.ant; (G.s.AS = G.s.AS || {})[i] = [e, o];
  }
  function goodyHut(G, u) {
    const o = u.o, p = G.P[o], sp = G.s.spP, i = u.p;
    G.imp[i] = 0;
    const cap = capOf(G, o) || citiesOf(G, o)[0];
    const opts = [['gold', 3], ['faith', 2], ['boost', 2], ['insp', 2], ['scout', 1], ['builder', 1], ['relic', G.s.era >= 1 ? 0.6 : 0], ['pop', cap ? 1 : 0], ['env', G.P.some((q) => q.k === 'cs' && met(G, o, q.o)) ? 1 : 0], ['xp', isMil(u.t) ? 1 : 0], ['map', 1]];
    let tot = 0; for (const x of opts) tot += x[1];
    let r = R() * tot, k = 'gold'; for (const x of opts) { r -= x[1]; if (r <= 0) { k = x[0]; break; } }
    let msg = '';
    if (k === 'gold') { const g2 = Math.round((40 + 20 * G.s.era) * Math.max(0.6, sp) * (1 + R())); p.gold += g2; msg = '금 +' + g2; }
    else if (k === 'faith') { const f = Math.round(Math.max(panCost(G), 20 * sp) * (0.8 + R() * 0.6)); p.faith += f; msg = '신앙 +' + f; }
    else if (k === 'boost') { randomBoosts(G, o, 1); msg = '유레카 하나'; }
    else if (k === 'insp') { const cv = []; for (let x = 0; x < CIVIC.length; x++) if (!bitHas(p.ck, x) && !bitHas(p.cb, x) && CIVIC[x].e <= techEra(G, o) + 1) cv.push(x); if (cv.length) giveInsp(G, o, cv[ri(cv.length)]); msg = '영감 하나'; }
    else if (k === 'scout' || k === 'builder') { const t = UTI[k === 'scout' ? unitFor(G, o, 'scout') : 'builder']; const s2 = spawnSpot(G, i, t, o); if (s2 >= 0) { const nu = mkUnit(G, o, t, s2); if (k === 'builder') nu.ch = 3 + mv0(mods(G, o), 'chg'); } msg = UT[t].n + ' 합류'; }
    else if (k === 'pop') { cap.pop++; assignWork(G, cap); msg = cap.n + ' 인구 +1'; }
    else if (k === 'env') { p.env++; msg = '사절 +1'; }
    else if (k === 'relic') { const c = placeGW(G, o, { c: 'rel', n: -1, e: G.s.era, o }); if (!c) p.rq = (p.rq || 0) + 1; msg = '성유물(신앙 +4 · 관광 +8)' + (c ? '' : ' — 신전을 지으면 넣어요'); }
    else if (k === 'xp') { u.pp = (u.pp || 0) + 1; msg = '이 유닛 승급 +1'; }
    else if (k === 'map') { reveal(G, o, i, 6); msg = '주변 지도'; }
    eraScore(G, o, 1, '부족 마을');
    note(G, o, '🛖 부족 마을: ' + msg, i, 'goody');
    ev(G, { k: 'x', p: i });
  }
  function afterMove(G, u) {
    if (G.imp[u.p] === IMPI.goody && isMaj(G, u.o) && !isNaval(u.t)) goodyHut(G, u);
    // 야만인 야영지
    if (isMil(u.t) && G.imp[u.p] === IMPI.bcamp && isMaj(G, u.o)) {
      G.imp[u.p] = 0; delete (G.s.BC || {})[u.p]; if (G.s.era >= 1) markAntiquity(G, u.p, G.s.era, G.s.BB);
      const gold = Math.round((40 + 15 * G.s.era) * G.s.spP * (mods(G, u.o).campGold ? 2 : 1));
      G.P[u.o].gold += gold; G.P[u.o].st.camp = (G.P[u.o].st.camp || 0) + 1;
      eraScore(G, u.o, 1, '야만인 야영지 소탕'); note(G, u.o, '⛺ 야만인 야영지를 없앴어요. 금 +' + gold, u.p, 'camp');
      ev(G, { k: 'x', p: u.p });
    }
    // 적 민간인 포획
    const cv = civAt(G, u.p);
    if (cv && cv.o !== u.o && isMil(u.t) && atWar(G, cv.o, u.o)) captureCivilian(G, u, cv);
    if (isMil(u.t) && UT[u.t].cl !== 'nm' && UT[u.t].cl !== 'nr') { /* 경계 해제 */ }
  }
  function captureCivilian(G, u, cv) {
    const T = UT[cv.t];
    killUnit(G, cv);
    if (G.P[u.o].k === 'bb' || T.k === 'trader') { note(G, cv.o, '⚠ ' + T.n + '이(가) 잡혔어요.', u.p); return; }
    const nt = T.k === 'settler' ? UTI.builder : cv.t;
    if (UT[nt].cl === 'civ' && !civAt(G, u.p)) { const n2 = mkUnit(G, u.o, nt, u.p); n2.mv = 0; if (nt === UTI.builder) n2.ch = Math.max(1, cv.ch || 1); }
    note(G, cv.o, '⚠ ' + T.n + '을(를) ' + civName(G, u.o) + '에게 빼앗겼어요.', u.p, 'war');
  }

  /* ----- 전투 ----- */
  function bestMeleeCS(G, o) {
    let b = 20;
    if (!isMaj(G, o)) { for (const T of UT) if ((T.cl === 'mel' || T.cl === 'ac') && !T.civ && (T.era || 0) <= G.s.era) b = Math.max(b, T.cs); return b; }
    for (const T of UT) if ((T.cl === 'mel' || T.cl === 'ac') && (!T.civ || T.civ === civK(G, o)) && hasReq(G, o, T.req)) b = Math.max(b, T.cs);
    return b;
  }
  function cityCS(G, c) {
    const M = mods(G, c.o);
    let s = bestMeleeCS(G, c.o) - 2 + (c.wl > 0 && c.wh > 0 ? 3 * c.wl : 0) + (c.b.indexOf('palace') >= 0 ? 3 : 0) + mv0(M, 'cityCS') + govFx(G, c, 'cCityCS');
    if (G.P[c.o].k === 'cs') s += 4;
    const g2 = milAt(G, c.p); if (g2 && g2.o === c.o) s += 2;
    return s;
  }
  function cityMaxHp() { return 200; }
  function unitStr(G, u, role, foe, foeIsCity, tile) {
    const T = UT[u.t], M = mods(G, u.o), cl = T.cl;
    let s = (role === 'r' ? T.rs : T.cs) || 0;
    if (!isNaval(u.t) && isWater(G, u.p) && G.cat[u.p] < 0 && !(IMP[G.imp[u.p]] && IMP[G.imp[u.p]].k === 'polder')) s = role === 'd' ? 10 + 5 * techEra(G, u.o) : Math.min(s, 10 + 5 * techEra(G, u.o));
    s += promoVal(u, 'cs') + (role !== 'd' ? promoVal(u, 'csAtt') : promoVal(u, 'csDef'));
    if (promoVal(u, 'amph') && isLand(G, u.p) && (G.hill[u.p] || G.feat[u.p] === F_WOODS || G.feat[u.p] === F_RAIN)) s += promoVal(u, 'amph');
    s += mv0(M, 'cs') + mv0(M, 'cs.' + cl);
    if (foe) {
      if (G.P[foe.o] && G.P[foe.o].k === 'bb') s += mv0(M, 'csBarb');
      if (G.P[foe.o] && G.P[foe.o].k === 'cs') s += mv0(M, 'csCS');
      if (M.emT && M.emT[foe.o]) s += M.emT[foe.o];
      if (!foeIsCity) {
        const fc = UT[foe.t].cl;
        if (cl === 'ac' && (fc === 'lc' || fc === 'hc')) s += 10;
        if (cl === 'ac' && promoVal(u, 'zoc') && (fc === 'lc' || fc === 'hc')) s += 10;
        if (M.csWounded && foe.hp < 100) s += M.csWounded;
        if (T.k === 'hoplite' && G.g.nb[u.p].some((j) => { const m = milAt(G, j); return m && m.o === u.o && UT[m.t].k === 'hoplite'; })) s += 10;
        if (UT[foe.t].k === 'varu') s -= 5;
      }
      if (T.k === 'berserker') s += role === 'd' ? -7 : 7;
    }
    if (M.csHome && tileOwner(G, u.p) === u.o) s += M.csHome;
    if (M.csRel && foe && isMaj(G, foe.o) && G.P[u.o].rel >= 0 && G.P[foe.o].rel !== G.P[u.o].rel) s += M.csRel;
    if (M.csCoast && isLand(G, u.p) && coastal(G, u.p)) s += M.csCoast;
    if (M.csPromo && u.pr.length) s += M.csPromo;
    if (T.k === 'roughrider' && G.hill[u.p]) s += 10;
    if (u.cp) s += u.cp === 2 ? 17 : 10;
    const ftH = G.feat[u.p], landH = isLand(G, u.p);
    if (M.hillCs && landH && G.hill[u.p]) s += M.hillCs;
    if (M.csFeat && (ftH === F_WOODS || ftH === F_RAIN || ftH === F_MARSH)) s += M.csFeat;
    if (M.csRelCiv && M.relCivN) s += M.csRelCiv * M.relCivN;
    if (G.P[u.o].pcs > 0) s += 5;
    if (M.csAdjMel && (cl === 'mel' || cl === 'ac')) { let n = 0; for (const j of G.g.nb[u.p]) { const m = milAt(G, j); if (m && m.o === u.o) n++; } s += M.csAdjMel * Math.min(3, n); }
    if (T.k === 'digger' && landH && coastal(G, u.p)) s += 10;
    if (T.k === 'khevsur' && G.hill[u.p]) s += 7;
    if (T.k === 'highlander' && (G.hill[u.p] || ftH === F_WOODS)) s += 5;
    if (T.k === 'llanero') for (const j of G.g.nb[u.p]) { const m = milAt(G, j); if (m && m.o === u.o && UT[m.t].k === 'llanero') s += 2; }
    if (T.k === 'hussar' && role === 'a') s += 3;
    if (T.k === 'malon' && tileOwner(G, u.p) >= 0 && tileOwner(G, u.p) !== u.o) s += 5;
    if (T.k === 'hypaspist' && foeIsCity && role !== 'd') s += 5;
    for (const j of G.g.nb[u.p]) { const m = milAt(G, j); if (m && m.o === u.o && m !== u && UT[m.t].k === 'tagma' && !isNaval(u.t)) { s += 4; break; } }
    if (foe && !foeIsCity && foe.t != null) {
      const fc2 = UT[foe.t].cl;
      if (T.k === 'sabum' && (fc2 === 'lc' || fc2 === 'hc')) s += 17;
      if (T.k === 'gaesatae' && (UT[foe.t].cs || 0) > (T.cs || 0)) s += 10;
      if (T.k === 'hulche' && foe.hp < 100) s += 5;
    }
    if (M.csGoldAge && foe && isMaj(G, foe.o) && G.P[foe.o].age >= 2) s += M.csGoldAge;
    if (T.k === 'ngao' && (G.feat[u.p] === F_WOODS || G.feat[u.p] === F_RAIN)) s += 5;
    if (T.k === 'cossack' && tileOwner(G, u.p) === u.o) s += 5;
    if (M.defFaith && role === 'd') { const c = tileCity(G, u.p); if (c && c.o === u.o && c.rl === G.P[u.o].rel) s += M.defFaith; }
    for (const j of G.g.nb[u.p]) { const nw = nwAt(G, j); if (nw && nw.k === 'matter') { s += 2; break; } }
    // 위인 오라(장군·제독)
    for (const g2 of G.U) if (g2.o === u.o && g2.t === UTI.gp && hexDist(G.g, g2.p, u.p) <= 2) { const fx = GPL[g2.g].fx; if (fx.aura && (!!fx.naval === isNaval(u.t))) { s += fx.aura; break; } }
    if (role === 'd') {
      if (isLand(G, u.p)) {
        if (G.hill[u.p]) s += 3;
        const f = G.feat[u.p]; if (f === F_WOODS || f === F_RAIN) s += 3; if (f === F_MARSH || f === F_FLOOD) s -= 2;
        if (IMP[G.imp[u.p]] && IMP[G.imp[u.p]].k === 'fort') s += 4;
        if (IMP[G.imp[u.p]] && IMP[G.imp[u.p]].k === 'greatwall') s += 4;
      }
      if (u.f >= 2 || (IMP[G.imp[u.p]] && IMP[G.imp[u.p]].k === 'fort')) s += 6; else if (u.f >= 1) s += 3;
      // 지원 보너스
      let sup = 0; for (const j of G.g.nb[u.p]) { const m = milAt(G, j); if (m && m.o === u.o) sup++; }
      s += 2 * sup;
    }
    if (!T.nodmg) s -= Math.round((100 - u.hp) / 10);
    return Math.max(1, s);
  }
  function flankBonus(G, att, tile) {
    let n = 0; for (const j of G.g.nb[tile]) { if (j === att.p) continue; const m = milAt(G, j); if (m && m.o === att.o) n++; }
    return 2 * n * (promoVal(att, 'flank') ? 2 : 1);
  }
  const dmgF = (d) => 30 * Math.exp(0.04 * d);
  function rangeOf(G, u) { return (UT[u.t].rng || 0) + promoVal(u, 'rng'); }
  function canAttack(G, u) {
    if (!isMil(u.t) || u.a || u.mv <= 0) return false;
    const T = UT[u.t]; if (!T.cs && !T.rs) return false;
    if (T.cl === 'sg' && u.mvd && !promoVal(u, 'mvfire')) return false;
    return true;
  }
  function targets(G, u) {
    const out = [];
    if (isAir(u.t)) return airTargets(G, u);
    if (!canAttack(G, u)) return out;
    const ranged = isRanged(u.t), r = ranged ? rangeOf(G, u) : 1;
    const cand = ranged ? within(G.g, u.p, r) : G.g.nb[u.p];
    for (const j of cand) {
      if (j === u.p) continue;
      const c = cityAt(G, j);
      if (c && c.o !== u.o && atWar(G, c.o, u.o)) {
        if (!ranged && isNaval(u.t) && !coastal(G, j)) continue;
        if (!ranged && !isNaval(u.t) && isWater(G, u.p) && G.cat[u.p] < 0) continue;
        out.push(j); continue;
      }
      const m = milAt(G, j);
      if (m && m.o !== u.o && atWar(G, m.o, u.o)) {
        if (!ranged) {
          if (isNaval(u.t) !== (isWater(G, j) && G.cat[j] < 0) && !(isNaval(u.t) && isLand(G, j) && coastal(G, j) && false)) { if (!(isNaval(u.t) && isWater(G, j))) continue; }
          if (!isNaval(u.t) && isWater(G, j) && G.cat[j] < 0) continue;
          if (isWater(G, u.p) && G.cat[u.p] < 0 && !isNaval(u.t)) continue;
          if (stepCost(G, u, u.p, j) === Infinity && !(isNaval(u.t) && isWater(G, j))) continue;
        }
        out.push(j); continue;
      }
      if (!ranged) {
        const cv = civAt(G, j);
        if (cv && cv.o !== u.o && atWar(G, cv.o, u.o) && !isNaval(u.t) && isLand(G, j)) out.push(j);
        else if (!m && G.imp[j] === IMPI.bcamp && !isNaval(u.t)) { /* 야영지는 이동으로 */ }
      }
    }
    return out;
  }
  // 전투 예상(UI·AI 공용): {a, d, da:[min,max], dr:[min,max], kill:확률, city}
  function combatPreview(G, u, j) {
    if (isAir(u.t)) return airPreview(G, u, j);
    const ranged = isRanged(u.t), c = cityAt(G, j);
    if (c && c.o !== u.o) {
      const A = unitStr(G, u, ranged ? 'r' : 'a', { o: c.o }, true, j) + (ranged ? 0 : flankBonus(G, u, j) - (riverBetween(G, u.p, j) && !isNaval(u.t) ? 5 : 0));
      const D = cityCS(G, c), base = dmgF(A - D);
      const siege = UT[u.t].cl === 'sg';
      const wallF = c.wh > 0 ? (siege || hasSupport(G, u, j, c.wl <= 2 ? 'ram' : 'x') ? 1 : hasSupport(G, u, j, 'tower') && c.wl <= 2 ? 0 : 0.2) : 1;
      const rf = ranged && !siege ? 0.5 : 1;
      const da = [Math.round(base * 0.8 * rf * (c.wh > 0 ? wallF : 1)), Math.round(base * 1.2 * rf * (c.wh > 0 ? wallF : 1))];
      const dr = ranged ? [0, 0] : [Math.round(dmgF(D - A) * 0.8), Math.round(dmgF(D - A) * 1.2)];
      const capture = !ranged && !isNaval(u.t) && c.hp - (c.wh > 0 && !hasSupport(G, u, j, 'tower') ? 0 : da[1]) <= 0;
      return { a: A, d: D, da, dr, city: 1, wall: c.wh > 0, cap: c.hp <= 0 && !ranged ? 1 : capture ? 0.5 : 0, kill: 0 };
    }
    const m = milAt(G, j);
    if (!m) { const cv = civAt(G, j); return { a: 0, d: 0, da: [0, 0], dr: [0, 0], capt: cv ? 1 : 0, kill: 1 }; }
    const A = unitStr(G, u, ranged ? 'r' : 'a', m, false, j) + (ranged ? 0 : flankBonus(G, u, j) - (riverBetween(G, u.p, j) && !isNaval(u.t) ? 5 : 0));
    const D = unitStr(G, m, 'd', u, false, j);
    const da = [Math.round(dmgF(A - D) * 0.8), Math.round(dmgF(A - D) * 1.2)];
    const dr = ranged ? [0, 0] : [Math.round(dmgF(D - A) * 0.8), Math.round(dmgF(D - A) * 1.2)];
    const kill = m.hp <= da[0] ? 1 : m.hp > da[1] ? 0 : (da[1] - m.hp) / Math.max(1, da[1] - da[0]);
    const die = ranged ? 0 : u.hp <= dr[0] ? 1 : u.hp > dr[1] ? 0 : (dr[1] - u.hp) / Math.max(1, dr[1] - dr[0]);
    return { a: A, d: D, da, dr, kill, die };
  }
  function hasSupport(G, u, j, kind) {
    for (const k of G.g.nb[j]) { const cv = civAt(G, k); if (cv && cv.o === u.o && UT[cv.t].aura === kind && hexDist(G.g, k, u.p) <= 1) return true; }
    const cv = civAt(G, u.p); if (cv && cv.o === u.o && UT[cv.t].aura === kind) return true;
    return false;
  }
  function gainXP(G, u, n) {
    const M = mods(G, u.o); let f = 1 + mv0(M, 'xpP') / 100;
    if (UT[u.t].cl === 'rec' && M.xpr) f *= 2;
    if (UT[u.t].cl === 'rng' && M.xpRng) f *= 1 + M.xpRng / 100;
    u.x = (u.x || 0) + n * f;
  }
  function promoReady(u) { const lv = u.pr.length; if (lv >= 5) return false; return (u.pp || 0) > 0 || (u.x || 0) >= XPN[lv]; }
  function promoOptions(u) {
    const L2 = PROMO[UT[u.t].cl]; if (!L2) return [];
    const lv = u.pr.length, out = [];
    for (let k = 0; k < L2.length; k++) if (u.pr.indexOf(k) < 0 && k <= Math.min(4, lv * 2 + 1)) out.push(k);
    return out;
  }
  function doPromote(G, u, k) {
    if (!promoReady(u) || promoOptions(u).indexOf(k) < 0) return false;
    if ((u.pp || 0) > 0) u.pp--;
    u.pr.push(k); u.hp = Math.min(100, u.hp + 50); u.mv = 0; u.f = 0;
    if (u.pr.length === 4) eraScore(G, u.o, 1, UT[u.t].n + ' 4단계 승급');
    return true;
  }
  function warWeary(G, a, b, n) { if (isMaj(G, a) && !mods(G, a).noWW) G.P[a].ww = Math.min(300, (G.P[a].ww || 0) + n); if (isMaj(G, b) && !mods(G, b).noWW) G.P[b].ww = Math.min(300, (G.P[b].ww || 0) + n); }
  function onKill(G, killer, victim) {
    const p = G.P[killer.o];
    if (p.k === 'maj') {
      p.st.k = (p.st.k || 0) + 1;
      if (p.st.k % 3 === 0) eraScore(G, killer.o, 1, '적 유닛 처치');
      const M = mods(G, killer.o);
      if (M.killFaith) p.faith += Math.round((UT[victim.t].cs || 10) / 2);
      if (M.killCul) addCul(G, killer.o, (UT[victim.t].cs || 10) * M.killCul / 100);
      if (UT[killer.t].k === 'roughrider') p.lc = (p.lc || 0) + (UT[victim.t].cs || 10);
    }
  }
  function doAttack(G, u, j) {
    if (isAir(u.t)) return doAirStrike(G, u, j);
    if (targets(G, u).indexOf(j) < 0) return false;
    const ranged = isRanged(u.t), c = cityAt(G, j), m = milAt(G, j);
    const from = u.p, o2 = c ? c.o : m ? m.o : civAt(G, j) ? civAt(G, j).o : -1;
    if (o2 >= 0) meet(G, u.o, o2);
    u.a = 1; u.f = 0;
    u.mv = UT[u.t].cl === 'lc' && promoVal(u, 'mv') ? Math.max(0, u.mv - 1) : 0;
    const e = { k: 'a', f: from, t: j, o: u.o, r: ranged ? 1 : 0, ty: u.t };
    if (c && c.o !== u.o) {
      const pv = combatPreview(G, u, j);
      const roll = 0.8 + R() * 0.4, base = dmgF(pv.a - pv.d) * roll;
      const siege = UT[u.t].cl === 'sg', rf = ranged && !siege ? 0.5 : 1;
      let dealt = 0;
      if (c.wh > 0 && !(hasSupport(G, u, j, 'tower') && c.wl <= 2)) {
        const wf = siege || (hasSupport(G, u, j, 'ram') && c.wl <= 2) ? 1 : 0.2;
        const w = Math.round(base * wf * rf); c.wh = Math.max(0, c.wh - w); dealt = w;
        if (wf < 1) { const h2 = Math.round(base * 0.1 * rf); c.hp = Math.max(0, c.hp - h2); }
      } else { const h2 = Math.round(base * rf); c.hp = Math.max(0, c.hp - h2); dealt = h2; }
      c.at = 2;
      e.da = dealt; e.c = 1;
      if (!ranged) { const back = Math.round(dmgF(pv.d - pv.a) * (0.8 + R() * 0.4)); u.hp -= back; e.dr = back; }
      gainXP(G, u, ranged ? 3 : 4);
      warWeary(G, u.o, c.o, 2);
      if (u.hp <= 0) { e.die = 1; killUnit(G, u); }
      else if (!ranged && c.hp <= 0 && !isNaval(u.t)) { e.cap = 1; ev(G, e); captureCity(G, c, u.o, u); return true; }
      ev(G, e);
      return true;
    }
    if (m) {
      const pv = combatPreview(G, u, j);
      const d1 = Math.round(dmgF(pv.a - pv.d) * (0.8 + R() * 0.4));
      m.hp -= d1; e.da = d1;
      if (!ranged) { const d2r = Math.round(dmgF(pv.d - pv.a) * (0.8 + R() * 0.4)); u.hp -= d2r; e.dr = d2r; }
      gainXP(G, u, ranged ? 3 : 5); gainXP(G, m, 3);
      warWeary(G, u.o, m.o, 1);
      if (m.hp <= 0) {
        e.kill = 1; onKill(G, u, m); killUnit(G, m);
      if (G.s.era >= 1 && R() < 0.07) markAntiquity(G, j, G.s.era, m.o);
        if (!ranged && u.hp > 0 && !milAt(G, j) && stepCost(G, u, u.p, j) !== Infinity && !cityAt(G, j)) { placeUnit(G, u, j); reveal(G, u.o, j, sightOf(G, u)); afterMove(G, u); }
      }
      if (u.hp <= 0) { e.die = 1; onKill(G, m, u); killUnit(G, u); }
      ev(G, e);
      return true;
    }
    const cv = civAt(G, j);
    if (cv) { placeUnit(G, u, j); afterMove(G, u); ev(G, { k: 'm', u: u.id, o: u.o, t: u.t, path: [from, j] }); return true; }
    return false;
  }
  function cityStrikeTargets(G, c) {
    if (!(c.wl > 0) || c.rs || c.hp <= 0) return [];
    const out = [];
    for (const j of within(G.g, c.p, 2)) { const m = milAt(G, j); if (m && m.o !== c.o && atWar(G, m.o, c.o)) out.push(j); }
    return out;
  }
  function cityStrike(G, c, j) {
    if (cityStrikeTargets(G, c).indexOf(j) < 0) return false;
    const m = milAt(G, j), D = unitStr(G, m, 'd', { o: c.o }, true, j);
    const d1 = Math.round(dmgF(cityCS(G, c) - D) * (0.8 + R() * 0.4));
    m.hp -= d1; c.rs = 1;
    const e = { k: 'a', f: c.p, t: j, o: c.o, r: 1, cs: 1, da: d1 };
    if (m.hp <= 0) { e.kill = 1; if (isMaj(G, c.o)) G.P[c.o].st.k = (G.P[c.o].st.k || 0) + 1; killUnit(G, m); }
    ev(G, e);
    return true;
  }
  function upgradeTo(G, u) {
    const T = UT[u.t]; if (!T.up) return -1;
    const k = isMaj(G, u.o) ? unitFor(G, u.o, T.up) : T.up; const ti = UTI[k];
    return ti == null ? -1 : ti;
  }
  function upgradeCost(G, u) {
    const ti = upgradeTo(G, u); if (ti < 0) return 0;
    const d = Math.max(10, (UT[ti].c - UT[u.t].c)) * 1.6 * G.s.spP;
    return Math.round(d * (1 + mv0(mods(G, u.o), 'upgP') / 100));
  }
  function canUpgrade(G, u, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    const ti = upgradeTo(G, u); if (ti < 0) return no('업그레이드 없음');
    const T = UT[ti], p = G.P[u.o];
    if (!hasReq(G, u.o, T.req)) return no(T.n + ': 연구 필요');
    if (tileOwner(G, u.p) !== u.o) return no('내 영토에서만');
    if (u.mv <= 0 || u.a) return no('이동력 필요');
    if (p.gold < upgradeCost(G, u)) return no('금 부족');
    if (T.res && (p.stk[RESI[T.res]] || 0) < stratNeed(G, u.o, T)) return no(RES[RESI[T.res]].n + ' 부족');
    return true;
  }
  function doUpgrade(G, u) {
    if (!canUpgrade(G, u)) return false;
    const ti = upgradeTo(G, u), T = UT[ti], p = G.P[u.o];
    p.gold -= upgradeCost(G, u);
    if (T.res) p.stk[RESI[T.res]] -= stratNeed(G, u.o, T);
    u.t = ti; u.mv = 0; u.pr = u.pr.filter((k) => PROMO[T.cl] && PROMO[T.cl][k]);
    return true;
  }

  /* ----- 항공 ----- */
  function airRange(G, u) { return (UT[u.t].rng || 0) + promoVal(u, 'rng'); }
  function airTargets(G, u) {
    const T = UT[u.t], out = [];
    if (!isAir(u.t) || T.rec || u.a || u.mv <= 0) return out;
    for (const j of within(G.g, u.p, airRange(G, u))) {
      if (j === u.p) continue;
      const c = cityAt(G, j); if (c && c.o !== u.o && atWar(G, c.o, u.o)) { out.push(j); continue; }
      const m = milAt(G, j); if (m && m.o !== u.o && atWar(G, m.o, u.o)) { out.push(j); continue; }
      if (T.bmb) { const ow = tileOwner(G, j); if (ow >= 0 && ow !== u.o && atWar(G, ow, u.o) && ((G.imp[j] && !G.pil[j] && !IMP[G.imp[j]].sp) || (G.dis[j] && !G.dpil[j] && DIS[G.dis[j]].k !== 'cc'))) out.push(j); }
    }
    return out;
  }
  function airBases(G, u) { const out = []; for (const j of within(G.g, u.p, airRange(G, u) * 2)) if (j !== u.p && airCap(G, j, u.o) > airAt(G, j).length) out.push(j); return out; }
  // 적 경계 비행(요격기)
  function interceptor(G, u, j) {
    let best = null, bv = -1;
    for (const v of G.U) if (isAir(v.t) && UT[v.t].ftr && v.pt && v.o !== u.o && atWar(G, v.o, u.o) && v.hp > 20 && hexDist(G.g, v.p, j) <= airRange(G, v)) { const s2 = UT[v.t].cs + promoVal(v, 'cs'); if (s2 > bv) { bv = s2; best = v; } }
    return best;
  }
  function antiAir(G, u, j) {
    // 대공: 현대 대전차병·기계화 보병 근처, 정보 시대 도시
    let a = 0;
      for (const k of within(G.g, j, 1)) { const m = milAt(G, k); if (m && m.o !== u.o && atWar(G, m.o, u.o)) { if (UT[m.t].aa) a = Math.max(a, UT[m.t].aa); else if (UT[m.t].k === 'modat' || UT[m.t].k === 'mechinf' || UT[m.t].k === 'atcrew') a = Math.max(a, UT[m.t].cs); } }
    const c = cityAt(G, j); if (c && c.wl >= 3 && techEra(G, c.o) >= 6) a = Math.max(a, cityCS(G, c));
    return a;
  }
  function airPreview(G, u, j) {
    const T = UT[u.t], c = cityAt(G, j), m = milAt(G, j);
    let A = (T.rs || 0) + promoVal(u, 'cs') + promoVal(u, 'csAtt') - Math.round((100 - u.hp) / 10) + mv0(mods(G, u.o), 'cs');
    const aa = antiAir(G, u, j);
    const dr = aa ? [Math.round(dmgF(aa - A) * 0.5), Math.round(dmgF(aa - A) * 0.7)] : [0, 0];
    if (c && c.o !== u.o) { const D = cityCS(G, c), b = dmgF(A - D); const wf = c.wh > 0 ? (T.bmb ? 1 : 0.3) : 1; const rf = T.bmb ? 1 : 0.5; return { a: A, d: D, da: [Math.round(b * 0.8 * wf * rf), Math.round(b * 1.2 * wf * rf)], dr, city: 1, wall: c.wh > 0, kill: 0, air: 1 }; }
    if (m) { if (T.bmb) A -= 10; const D = unitStr(G, m, 'd', u, false, j); const da = [Math.round(dmgF(A - D) * 0.8), Math.round(dmgF(A - D) * 1.2)]; return { a: A, d: D, da, dr, kill: m.hp <= da[0] ? 1 : m.hp > da[1] ? 0 : (da[1] - m.hp) / Math.max(1, da[1] - da[0]), die: 0, air: 1 }; }
    return { a: A, d: 0, da: [0, 0], dr, kill: 0, pil: 1, air: 1 };
  }
  function doAirStrike(G, u, j) {
    if (airTargets(G, u).indexOf(j) < 0) return false;
    const T = UT[u.t], e = { k: 'a', f: u.p, t: j, o: u.o, r: 1 };
    u.a = 1; u.mv = 0; u.pt = 0;
    const tgO = cityAt(G, j) ? cityAt(G, j).o : milAt(G, j) ? milAt(G, j).o : tileOwner(G, j);
    if (tgO >= 0) meet(G, u.o, tgO);
    // 요격
    const iv = interceptor(G, u, j);
    if (iv) {
      const A = T.cs + promoVal(u, 'cs') - Math.round((100 - u.hp) / 10), D = UT[iv.t].cs + promoVal(iv, 'cs') - Math.round((100 - iv.hp) / 10);
      u.hp -= Math.round(dmgF(D - A) * (0.8 + R() * 0.4)); iv.hp -= Math.round(dmgF(A - D) * 0.6 * (0.8 + R() * 0.4));
      ev(G, { k: 'a', f: iv.p, t: j, o: iv.o, r: 1 });
      if (iv.hp <= 0) { onKill(G, u, iv); killUnit(G, iv); }
      if (u.hp <= 0) { note(G, u.o, '✈ ' + T.n + '이(가) 요격당했어요.', j, 'war'); onKill(G, iv, u); killUnit(G, u); return true; }
    }
    const pv = airPreview(G, u, j), roll = 0.8 + R() * 0.4, c = cityAt(G, j), m = milAt(G, j);
    if (c && c.o !== u.o) {
      const b = Math.round((pv.da[0] + pv.da[1]) / 2 * roll);
      if (c.wh > 0) c.wh = Math.max(0, c.wh - b); else c.hp = Math.max(0, c.hp - b);
      c.at = 2; e.da = b; e.c = 1; warWeary(G, u.o, c.o, 2);
    } else if (m) {
      const d1 = Math.round((pv.da[0] + pv.da[1]) / 2 * roll); m.hp -= d1; e.da = d1; warWeary(G, u.o, m.o, 1);
      if (m.hp <= 0) { e.kill = 1; onKill(G, u, m); killUnit(G, m); }
    } else {
      if (G.imp[j] && !G.pil[j]) G.pil[j] = 1; else if (G.dis[j]) G.dpil[j] = 1;
      note(G, tileOwner(G, j), '💣 ' + civName(G, u.o) + '의 폭격으로 시설이 부서졌어요.', j, 'war'); G.yc = {};
    }
    if (pv.dr[1]) { const back = Math.round((pv.dr[0] + pv.dr[1]) / 2 * roll); u.hp -= back; e.dr = back; if (u.hp <= 0) { e.die = 1; killUnit(G, u); } }
    if (G.uid[u.id]) gainXP(G, u, 4);
    ev(G, e);
    return true;
  }
  function airAct(G, u, m, to) {
    if (!isAir(u.t)) return false;
    if (m === 'p') { u.pt = u.pt ? 0 : 1; u.sl = u.pt; return true; }
    if (u.a || u.mv <= 0) return false;
    if (m === 'b') { if (airBases(G, u).indexOf(to) < 0) return false; u.p = to; u.mv = 0; u.pt = 0; return true; }
    if (m === 'r') { if (!UT[u.t].rec || hexDist(G.g, u.p, to) > airRange(G, u)) return false; reveal(G, u.o, to, 3); u.a = 1; u.mv = 0; exploreNow(G, u.o); ev(G, { k: 'x', p: to }); return true; }
    if (m === 's') return doAirStrike(G, u, to);
    return false;
  }
  /* ----- 핵무기 ----- */
  const NUKE_R = 12;
  function nukeTargetsFrom(G, o, c) {
    const out = [];
    for (const j of within(G.g, c.p, NUKE_R)) { const ow = tileOwner(G, j), m = milAt(G, j), cc = cityAt(G, j); if ((cc && atWar(G, cc.o, o)) || (m && m.o !== o && atWar(G, m.o, o)) || (ow >= 0 && ow !== o && atWar(G, ow, o) && G.dis[j])) out.push(j); }
    return out;
  }
  // 발사 지점: 내 도시, 내 미사일 사일로, 내 핵잠수함
  function nukeSrcOK(G, o, src) { const c = cityAt(G, src); if (c) return c.o === o; if (G.imp[src] === IMPI.silo && tileOwner(G, src) === o) return true; return G.U.some((u) => u.o === o && u.p === src && UT[u.t].nuk); }
  function launchNuke(G, o, kk, cid, to, src) {
    const p = G.P[o]; let c = G.cid[cid];
    if (!c && src != null && nukeSrcOK(G, o, src)) c = { o, p: src };
    if (!c || c.o !== o || !p.nk || !(p.nk[kk] > 0) || nukeTargetsFrom(G, o, c).indexOf(to) < 0) return false;
    p.nk[kk]--;
    const rad = kk === 't' ? 2 : 1, area = within(G.g, to, rad);
    const hit = {};
    for (const u of G.U.slice()) if (area.indexOf(u.p) >= 0 && !(isAir(u.t) && G.cat[u.p] < 0 && false)) { hit[u.o] = 1; killUnit(G, u); }
    G.s.FO = G.s.FO || {};
    for (const j of area) {
      const cc = cityAt(G, j);
      if (cc) { hit[cc.o] = 1; cc.pop = Math.max(1, cc.pop - (kk === 't' ? 8 : 4)); cc.hp = Math.max(0, cc.hp - 100); cc.wh = 0; assignWork(G, cc); }
      if (G.imp[j] && !IMP[G.imp[j]].sp) G.pil[j] = 1;
      if (G.dis[j] && DIS[G.dis[j]].k !== 'cc') G.dpil[j] = 1;
      if (isLand(G, j)) G.s.FO[j] = 10;
      const ow = tileOwner(G, j); if (ow >= 0) hit[ow] = 1;
    }
    for (const q of aliveMaj(G)) if (q !== o) grieve(G, q, o, hit[q] ? 120 : 60);
    p.wm = (p.wm || 0) + 80; G.s.CL.co2 += 120;
    triggerEmergency(G, o, '핵무기 사용');
    noteAll(G, '☢ ' + civName(G, o) + '이(가) ' + (kk === 't' ? '열핵 폭탄' : '원자폭탄') + '을 사용했어요!', to, 'nuke');
    G.yc = {};
    ev(G, { k: 'z', p: to, d: 'nuke' });
    return true;
  }
  /* ----- 군단·군대(민족주의·동원) ----- */
  function corpsOK(G, u, v, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    if (!v || v === u || v.o !== u.o || v.t !== u.t || !isGround(u.t) && !isNaval(u.t)) return no('같은 종류 유닛이 필요해요');
    if (UT[u.t].cl === 'rec' || UT[u.t].cl === 'air') return no('?');
    if (hexDist(G.g, u.p, v.p) > 1) return no('붙어 있어야 해요');
    const lv = (u.cp || 0) + (v.cp || 0) + 1; if (lv > 2) return no('최대 군대(3개)');
    const nav = isNaval(u.t);
    if (lv === 1 && !hasCivic(G, u.o, nav ? 'mercantilism' : 'nationalism')) return no((nav ? '중상주의' : '민족주의') + ' 필요');
    if (lv === 2 && !hasCivic(G, u.o, 'mobilization')) return no('동원 필요');
    if (u.mv <= 0) return no('이동력 필요');
    return true;
  }
  function doCorps(G, u, v) {
    if (!corpsOK(G, u, v)) return false;
    u.cp = (u.cp || 0) + (v.cp || 0) + 1; u.hp = Math.max(u.hp, v.hp); u.x = Math.max(u.x || 0, v.x || 0); u.mv = 0;
    killUnit(G, v);
    return true;
  }
  const corpsName = (u) => (u.cp ? ' ' + (isNaval(u.t) ? (u.cp === 2 ? '대함대' : '함대') : (u.cp === 2 ? '군대' : '군단')) : '');
  /* ----- 군사 공학자: 도로·철도 ----- */
  function roadOK(G, u, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    if (UT[u.t].k !== 'mileng' || u.mv <= 0) return no('?');
    if (!passableLand(G, u.p) || G.cat[u.p] >= 0) return no('땅 위에서');
    if (G.road[u.p] >= 2) return no('이미 철도');
    if (G.road[u.p] >= 1) { if (!hasTech(G, u.o, 'steam')) return no('철도: 증기력 필요'); if ((G.P[u.o].stk[RESI.coal] || 0) < 1) return no('석탄 1 필요'); if ((u.ch || 0) <= 0) return no('충전 없음'); }
    return true;
  }
  function doRoad(G, u) {
    if (!roadOK(G, u)) return false;
    if (G.road[u.p] >= 1) { G.road[u.p] = 2; G.P[u.o].stk[RESI.coal] -= 1; u.ch--; if (u.ch <= 0) { killUnit(G, u); return true; } }
    else G.road[u.p] = 1;
    u.mv = 0; return true;
  }

  /* ----- 건설자·개선 ----- */
  function impOptions(G, u, i) {
    const o = u.o, out = [];
    if (UT[u.t].k === 'mileng') { const ok0 = (u.ch || 0) > 0 && passableLand(G, i) && G.cat[i] < 0 && !G.dis[i] && !G.won[i]; if (ok0 && G.imp[i] !== IMPI.fort && hasTech(G, o, 'siegeTac') && (tileOwner(G, i) === o || tileOwner(G, i) < 0)) out.push(IMPI.fort); if (ok0 && G.imp[i] !== IMPI.silo && hasTech(G, o, 'rocketry') && tileOwner(G, i) === o) out.push(IMPI.silo); return out; }
    if (UT[u.t].k !== 'builder' || (u.ch || 0) <= 0) return out;
    const c = tileCity(G, i); if (!c || c.o !== o || c.p === i || G.dis[i] || G.won[i]) return out;
    const r = G.res[i] && resVisible(G, o, G.res[i]) ? RES[G.res[i]] : null;
    const t = G.ter[i], f = G.feat[i], land = isLand(G, i) && t !== TM, ck = civK(G, o);
    const fk = f && f < NW0 && FEAT[f] ? FEAT[f].k : '';
    if (f >= NW0 || f === F_ICE) return out;
    for (let k = 1; k < IMP.length; k++) {
      const m = IMP[k]; if (m.sp) continue;
      if (G.imp[i] === k && !G.pil[i]) continue;
      if (m.civ && m.civ !== ck) continue;
      if (m.tech && !(m.civic ? hasCivic(G, o, m.tech) : hasTech(G, o, m.tech))) continue;
      let ok = false;
      if (r && r.im === m.k) ok = true;
      else if (!r || r.c === 'b' && false) {
        switch (m.k) {
          case 'farm': ok = land && (!G.hill[i] || hasCivic(G, o, 'civilEng')) && (t === TG || t === TP || (t === TD && fk === 'flood') || t === TT) && (!fk || fk === 'flood' || fk === 'vsoil'); break;
          case 'mine': ok = land && G.hill[i] && !fk; break;
          case 'lumber': ok = land && (fk === 'woods' || fk === 'rain'); break;
          case 'fort': ok = false; break;
          case 'resort': ok = land && coastal(G, i) && appeal(G, i) >= 2 && !fk; break;
          case 'solar': ok = land && !G.hill[i] && !fk && (t === TD || t === TP); break;
          case 'wind': ok = land && !G.hill[i] && !fk && (t === TG || t === TP || t === TT); break;
          case 'greatwall': ok = land && !G.hill[i] && G.g.nb[i].some((j) => tileOwner(G, j) !== o && isLand(G, j)); break;
          case 'sphinx': ok = land && !G.hill[i] && !G.g.nb[i].some((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'sphinx'); break;
          case 'chateau': ok = land && G.riv[i] && !G.g.nb[i].some((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'chateau'); break;
          case 'stepwell': ok = land && !G.hill[i] && !fk && !G.g.nb[i].some((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'stepwell'); break;
          case 'kurgan': ok = land && !G.hill[i] && !fk; break;
          case 'mission': ok = land && !fk; break;
          case 'ziggurat': ok = land && !G.hill[i] && !fk; break;
          case 'polder': ok = t === TC && G.g.nb[i].filter((j) => isLand(G, j)).length >= 2; break;
          case 'terrace': ok = land && G.hill[i] && !fk; break;
          case 'icerink': ok = land && (t === TT || t === TS); break;
          case 'pairi': ok = land && !fk && !G.g.nb[i].some((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'pairi'); break;
          case 'outback': ok = land && !G.hill[i] && !fk && (t === TD || t === TP || t === TG); break;
          case 'mekewap': ok = land && !fk && G.g.nb[i].some((j) => G.res[j] && RES[G.res[j]].c !== 's'); break;
          case 'rockchurch': ok = land && G.hill[i] && (!fk || fk === 'woods'); break;
          case 'hacienda': ok = land && !G.hill[i] && !fk && (t === TG || t === TP || t === TD); break;
          case 'kampung': ok = t === TC && !f && G.g.nb[i].some((j) => isWater(G, j) && G.res[j]) && G.g.nb[i].some((j) => isLand(G, j)); break;
          case 'chemamull': ok = land && !fk; break;
          case 'nubpyr': ok = land && (t === TD || fk === 'flood'); break;
          case 'feitoria': ok = land && !fk && coastal(G, i) && !G.g.nb[i].some((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'feitoria'); break;
          case 'golf': ok = land && !G.hill[i] && !fk && !G.g.nb[i].some((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === 'golf'); break;
        }
      }
      if (r && r.im !== m.k && m.k !== 'fort') ok = false;
      if (ok) out.push(k);
    }
    return out;
  }
  function chopValue(G, u, i) {
    if (UT[u.t].k !== 'builder' || (u.ch || 0) <= 0) return 0;
    const f = G.feat[i];
    if (!(f === F_WOODS || f === F_RAIN || f === F_MARSH)) return 0;
    const need = f === F_WOODS ? 'mining' : f === F_RAIN ? 'bronze' : 'irrigation';
    if (!hasTech(G, u.o, need)) return 0;
    const c = tileCity(G, i); if (!c || c.o !== u.o || G.res[i]) return 0;
    return Math.round((25 + 12 * techEra(G, u.o)) * G.s.spP * 1.2);
  }
  function doImprove(G, u, k) {
    if (impOptions(G, u, u.p).indexOf(k) < 0) return false;
    const i = u.p;
    if (UT[u.t].k === 'mileng') { G.imp[i] = k; G.pil[i] = 0; u.ch--; u.mv = 0; if (u.ch <= 0) killUnit(G, u); if (mods(G, u.o).fortBomb) { const c = tileCity(G, i); if (c) for (const j of G.g.nb[i]) if (G.own[j] < 0) G.own[j] = c.id; } ev(G, { k: 'i', p: i }); return true; }
    G.imp[i] = k; G.pil[i] = 0;
    const m = IMP[k];
    if ((G.feat[i] === F_WOODS || G.feat[i] === F_RAIN || G.feat[i] === F_MARSH) && !(m.k === 'lumber' || m.k === 'camp' || m.k === 'plant' || m.k === 'fort' || m.k === 'mine' && G.res[i])) G.feat[i] = 0;
    u.ch--; u.mv = 0;
    if (u.ch <= 0) killUnit(G, u);
    const c = tileCity(G, i); if (c) { if (m.k === 'fort' && mods(G, u.o).fortBomb) for (const j of G.g.nb[i]) if (G.own[j] < 0) G.own[j] = c.id; delete G.yc[c.id]; G.yc = {}; assignWork(G, c); }
    ev(G, { k: 'i', p: i });
    return true;
  }
  function doChop(G, u) {
    const v = chopValue(G, u, u.p); if (!v) return false;
    const c = tileCity(G, u.p); G.feat[u.p] = 0;
    const it = c.q[0]; if (it) { const key = itemKey(it); c.pp[key] = (c.pp[key] || 0) + v; } else G.P[u.o].gold += v;
    u.ch--; u.mv = 0; if (u.ch <= 0) killUnit(G, u);
    G.yc = {}; assignWork(G, c);
    return true;
  }
  function doRepair(G, u) {
    const i = u.p;
    if (UT[u.t].k !== 'builder') return false;
    if (tileOwner(G, i) !== u.o) return false;
    if (G.s.FO && G.s.FO[i]) delete G.s.FO[i]; else if (G.pil[i]) G.pil[i] = 0; else if (G.dpil[i]) G.dpil[i] = 0; else return false;
    u.mv = 0; G.yc = {}; return true;
  }
  function canPillage(G, u) {
    if (!isMil(u.t) || u.mv <= 0) return false;
    const i = u.p, ow = tileOwner(G, i);
    if (ow < 0 || ow === u.o || !atWar(G, ow, u.o)) return false;
    return (G.imp[i] && !G.pil[i] && !IMP[G.imp[i]].sp) || (G.dis[i] && !G.dpil[i] && DIS[G.dis[i]].k !== 'cc');
  }
  function doPillage(G, u) {
    if (!canPillage(G, u)) return false;
    const i = u.p;
    if (G.imp[i] && !G.pil[i]) G.pil[i] = 1; else G.dpil[i] = 1;
    const g2 = Math.round(25 * G.s.spP + 5 * G.s.era); G.P[u.o].gold += g2;
    u.hp = Math.min(100, u.hp + 30); u.mv = Math.max(0, u.mv - 3);
    note(G, tileOwner(G, i), '🔥 ' + civName(G, u.o) + '가 우리 땅을 약탈했어요.', i, 'war');
    G.yc = {};
    return true;
  }

  /* ======================= 도시 세우기·점령·충성도 ======================= */
  function canFound(G, u, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    if (UT[u.t].k !== 'settler') return no('개척자만');
    const i = u.p;
    if (!passableLand(G, i)) return no('땅이 아니에요');
    if (G.feat[i] >= NW0 || G.feat[i] === F_VOLC) return no('자연경관');
    const ow = tileOwner(G, i); if (ow >= 0 && ow !== u.o) return no('다른 나라 영토');
    for (const c of G.C) if (hexDist(G.g, c.p, i) < 4) return no('다른 도시와 너무 가까워요(3칸 띄우기)');
    if (G.dis[i] || G.won[i]) return no('구역이 있어요');
    return true;
  }
  function cityNameFor(G, o) {
    const p = G.P[o];
    if (p.k === 'cs') return CSL[p.cs].n;
    const list = CIVS[p.civ].cities, used = {};
    for (const c of G.C) used[c.n] = 1;
    for (const n of list) if (!used[n]) return n;
    return CIVS[p.civ].n + ' ' + (citiesOf(G, o).length + 1);
  }
  function foundCity(G, o, i, nm) {
    const p = G.P[o];
    const c = { id: G.s.q++, o, n: nm || cityNameFor(G, o), p: i, pop: 1, fd: 0, q: [], pp: {}, b: [], d: { cc: i }, wk: [], lk: [], fo: 0,
      hp: 200, wh: 0, wl: 0, lo: 100, rp: {}, rl: -1, hc: -1, bt: 0, ft: G.s.t, oo: o, oc: 0, gw: [], gv: -1, wb: -1 };
    const first = !G.C.some((d) => d.o === o) && p.k === 'maj' && !p.hadCap;
    if (first) { c.b.push('palace'); c.oc = 1; p.hadCap = 1; p.oc = i; }
    if (p.k === 'cs') { c.oc = 1; c.cs = 1; c.wl = 1; c.wh = 100; }
    G.C.push(c); G.cid[c.id] = c; G.cat[i] = c.id;
    G.dis[i] = DISI.cc; G.imp[i] = 0; G.pil[i] = 0;
    if (G.feat[i] && G.feat[i] !== F_FLOOD) G.feat[i] = 0;
    G.road[i] = 1;
    for (const j of within(G.g, i, 1)) if (G.own[j] < 0) G.own[j] = c.id;
    G.own[i] = c.id;
    const M = mods(G, o);
    if (M.extraTiles) { const cand = within(G.g, i, 2).filter((j) => G.own[j] < 0 && hexDist(G.g, i, j) === 2); for (let k = 0; k < M.extraTiles && cand.length; k++) G.own[cand.splice(ri(cand.length), 1)[0]] = c.id; }
    if (M.freeBld && p.k === 'maj') c.b.push(M.freeBld);
    if (M.roadsCity && p.k === 'maj') { const cap = capOf(G, o); if (cap && cap !== c && hexDist(G.g, cap.p, i) <= 14) { let cur = i, guard = 0; while (cur !== cap.p && guard++ < 30) { let best = -1, bd = 1e9; for (const j of G.g.nb[cur]) { const dd = hexDist(G.g, j, cap.p) + (passableLand(G, j) ? 0 : 3); if (dd < bd) { bd = dd; best = j; } } cur = best; if (passableLand(G, cur)) G.road[cur] = 1; } } }
    reveal(G, o, i, 3);
    assignWork(G, c);
    if (p.k === 'maj') {
      const n = citiesOf(G, o).length;
      if (n <= 4 && !first) eraScore(G, o, 1, c.n + ' 건설');
      const lc = G.lc[i], cap = capOf(G, o);
      if (cap && cap !== c && lc && G.lc[cap.p] !== lc && !p.st['cont' + lc]) { p.st['cont' + lc] = 1; eraScore(G, o, 2, '다른 대륙에 첫 도시'); }
      ev(G, { k: 'f', p: i, o });
    }
    dirty(G);
    return c;
  }
  function captureCity(G, c, o, byUnit) {
    const old = c.o, po = G.P[old], pn = G.P[o];
    if (pn.k === 'bb') {
      // 야만인은 도시를 불태워요(인구 감소·약탈)
      c.pop = Math.max(1, c.pop - 2); c.hp = 60;
      for (const j of cityTiles(G, c)) if (G.imp[j] && R() < 0.5) G.pil[j] = 1;
      note(G, old, '🔥 야만인이 ' + c.n + '을(를) 약탈했어요!', c.p, 'war');
      if (byUnit) { /* 야만인 유닛은 그대로 */ }
      return;
    }
    const wasCap = c.b.indexOf('palace') >= 0;
    c.o = o; c.pop = Math.max(1, c.pop - 1); c.hp = 80; c.wh = 0; c.lo = 50; c.q = []; c.pp = {}; c.conq = 1;
    c.b = c.b.filter((k) => k !== 'palace' && !(BLD[BLDI[k]] && BLD[BLDI[k]].civ && BLD[BLDI[k]].civ !== civK(G, o)));
    if (c.gv >= 0) { const gv = po.gv && po.gv.find((x) => x.g === c.gv); if (gv) gv.c = -1; c.gv = -1; }
    if (po.k === 'cs') { po.a = 0; c.cs = 0; noteAll(G, '🏰 도시국가 ' + CSL[po.cs].n + '이(가) ' + civName(G, o) + '에게 점령되었어요.', c.p, 'war'); triggerEmergency(G, o, '도시국가 점령'); }
    // 주인 바뀐 칸의 적 민간 유닛·항공 유닛
    for (const u of G.U.slice()) if (u.o === old && (u.p === c.p || (isAir(u.t) && c.d.ad === u.p))) killUnit(G, u);
    if (byUnit && G.uid[byUnit.id]) { placeUnit(G, byUnit, c.p); byUnit.mv = 0; }
    for (const p2 of G.P) if (p2.k === 'maj') p2.tr = p2.tr.filter((tr) => !(tr.d === c.id && atWar(G, G.P.indexOf(p2), o)) && !(tr.f === c.id));
    if (isMaj(G, o) && G.P[old].k !== 'fc') {
      if (mods(G, o).conqBoost) { randomBoosts(G, o, 1); const cv = []; for (let i = 0; i < CIVIC.length; i++) if (!bitHas(pn.ck, i) && !bitHas(pn.cb, i) && CIVIC[i].e <= techEra(G, o) + 1) cv.push(i); if (cv.length) giveInsp(G, o, cv[ri(cv.length)]); }
      eraScore(G, o, c.oc ? 3 : 2, c.n + ' 점령');
      pn.wm = (pn.wm || 0) + (c.oc ? 30 : 15);
      if (isMaj(G, old)) { grieve(G, old, o, c.oc ? 40 : 20); }
    }
    note(G, old, '⚔ ' + c.n + '을(를) ' + civName(G, o) + '에게 빼앗겼어요!', c.p, 'war');
    note(G, o, '🏴 ' + c.n + '을(를) 점령했어요!', c.p, 'war');
    if (isMaj(G, o) && isMaj(G, old)) esLog(G, 'cp', c.n + '|' + civName(G, o));
    if (wasCap && isMaj(G, old)) {
      triggerEmergency(G, o, '수도 점령');
      const rest = citiesOf(G, old).sort((a, b) => b.pop - a.pop);
      if (rest.length) { rest[0].b.push('palace'); note(G, old, '🏛 수도를 ' + rest[0].n + '(으)로 옮겼어요.', rest[0].p); }
    }
    assignWork(G, c);
    checkDead(G, old);
    dirty(G);
    ev(G, { k: 'c', p: c.p, o, from: old });
  }
  function checkDead(G, o) {
    const p = G.P[o]; if (!p.a) return;
    if (G.C.some((c) => c.o === o)) return;
    if (p.k === 'maj' && G.U.some((u) => u.o === o && UT[u.t].k === 'settler')) return;
    p.a = 0;
    for (const u of G.U.slice()) if (u.o === o) killUnit(G, u);
    if (p.k === 'maj') noteAll(G, '💀 ' + civName(G, o) + '이(가) 멸망했어요.', -1, 'war');
  }
  function loyaltyTick(G, c) {
    const kind = G.P[c.o].k;
    if (kind !== 'maj' && kind !== 'fc') return;
    const M = kind === 'maj' ? mods(G, c.o) : {};
    const press = {};
    for (const d of G.C) {
      const dist = hexDist(G.g, c.p, d.p); if (dist > 9) continue;
      const pd = G.P[d.o]; if (pd.k === 'bb') continue;
      const ageF = pd.k === 'maj' ? (pd.age >= 2 ? 1.2 : pd.age === 0 ? 0.8 : 1) : 0.5;
      press[d.o] = (press[d.o] || 0) + d.pop * (10 - dist) * 0.1 * ageF;
    }
    const own = kind === 'fc' ? 0 : press[c.o] || 0; let foreign = 0, top = -1, tv = 0;
    for (const k in press) if (+k !== c.o) { foreign += press[k]; if (press[k] > tv && isMaj(G, +k)) { tv = press[k]; top = +k; } }
    if (kind === 'fc') {
      c.lo = clamp((c.lo == null ? 60 : c.lo) + clamp(2 - foreign * 0.25, -20, 4), 0, 100); c.lod = 0;
      if (c.lo <= 0 && top >= 0) { c.o = top; c.lo = 50; c.q = []; c.pp = {}; for (const u of G.U.slice()) if (u.o === G.s.FC && u.p === c.p) killUnit(G, u); note(G, top, '🏳 자유 도시 ' + c.n + '이(가) 우리에게 합류했어요!', c.p, 'loy'); eraScore(G, top, 2, '자유 도시 합류'); assignWork(G, c); dirty(G); }
      return;
    }
    let d = Math.max(-20, Math.min(20, (own - foreign) / Math.max(1, Math.min(own, foreign) + 0.5) * 2));
    if (c.b.indexOf('palace') >= 0) d += 8;
    if (c.b.indexOf('monument') >= 0) d += 2;
    d += mv0(M, 'loy') + govFx(G, c, 'cLoy') + (c.gv >= 0 ? 8 + mv0(M, 'loyGov') : 0);
    if (M.gwLoy) d += (c.gw || []).length;
    for (const e of G.C) if (e.o !== c.o && isMaj(G, e.o) && (e.gw || []).length && hexDist(G.g, e.p, c.p) <= 9 && mods(G, e.o).gwLoy) d -= (e.gw || []).length * 0.5;
    const cc = cityCalc(G, c); d += cc.mood >= 2 ? 3 : cc.mood === 0 ? -2 : cc.mood === -1 ? -4 : cc.mood === -2 ? -6 : 0;
    if (milAt(G, c.p) && milAt(G, c.p).o === c.o) d += 2;
    c.lo = clamp((c.lo == null ? 100 : c.lo) + d, 0, 100);
    c.lod = Math.round(d * 10) / 10;
    if (c.lo <= 0 && c.b.indexOf('palace') < 0 && G.s.FC != null) {
      // 원작처럼: 충성도 0 → 독립을 선언해 자유 도시가 돼요(그 뒤 주변 영향력에 따라 다른 나라로)
      const old = c.o, top2 = G.s.FC;
      noteAll(G, '🏳 ' + c.n + '(' + civName(G, old) + ')이(가) 독립을 선언해 자유 도시가 됐어요!', c.p, 'loy');
      c.o = top2; c.lo = 60; c.q = []; c.pp = {};
      if (c.gv >= 0) { const gv = G.P[old].gv.find((x) => x.g === c.gv); if (gv) gv.c = -1; c.gv = -1; }
      for (const u of G.U.slice()) if (u.o === old && cityTiles(G, c).indexOf(u.p) >= 0 && u.p === c.p) { const sp = spawnSpot(G, capOf(G, old) ? capOf(G, old).p : u.p, u.t, old); if (sp >= 0 && sp !== u.p) placeUnit(G, u, sp); else killUnit(G, u); }
      assignWork(G, c); checkDead(G, old); dirty(G);
    }
  }

  /* ======================= 위인 능력 ======================= */
  // 걸작 칸 배치: 같은 종류 칸 먼저, 남으면 아무 걸작 칸(궁전·은행)
  function gwLayout(G, c) {
    const slots = [];
    for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && b.gw) for (let n = 0; n < (b.gwn || 1); n++) slots.push({ b: k, t: b.gw, w: -1 }); }
    for (let n = 0; n < (c.gws || 0); n++) slots.push({ b: 'w:hermitage', t: 'art', w: -1 });
    if (c.b.indexOf('w:broadway') >= 0) for (let n = 0; n < 3; n++) slots.push({ b: 'w:broadway', t: 'mus', w: -1 });
    const gw = c.gw || [], extra = [];
    gw.forEach((g2, wi) => { const sl = slots.find((x) => x.w < 0 && x.t === g2.c); if (sl) sl.w = wi; else extra.push(wi); });
    for (const wi of extra) { const sl = slots.find((x) => x.w < 0 && x.t === 'any'); if (sl) sl.w = wi; }
    // 테마: 미술관 3칸이 서로 다른 예술가 / 고고학 박물관 3칸이 같은 시대·다른 문명
    const themed = {};
    for (const bk of ['museum', 'bibliotheque', 'archmus']) {
      const ws = slots.filter((x) => x.b === bk && x.w >= 0).map((x) => gw[x.w]);
      if (ws.length < 3) continue;
      if (bk === 'archmus') { if (ws.every((w) => w.e === ws[0].e) && new Set(ws.map((w) => w.o)).size === 3) themed[bk] = 1; }
      else if (new Set(ws.map((w) => w.n)).size === 3) themed[bk] = 1;
    }
    return { slots, themed };
  }
  function gwSlots(G, c, cls) {
    const L2 = gwLayout(G, c);
    return L2.slots.filter((x) => x.w < 0 && (x.t === cls || x.t === 'any')).length;
  }
  // 걸작 하나 넣기(빈 칸 있는 도시를 골라서)
  function placeGW(G, o, w, pref) {
    const cs = (pref ? [pref] : []).concat(citiesOf(G, o).filter((c) => c !== pref));
    const c = cs.find((d) => d && gwSlots(G, d, w.c) > 0);
    if (!c) return null;
    c.gw.push(w); G.yc = {}; return c;
  }
  function gpCanUse(G, u, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    const gp = GPL[u.g], fx = gp.fx, c = tileCity(G, u.p);
    if (!c || c.o !== u.o) return no('내 영토에서 써요');
    if (fx.rel) { if (G.P[u.o].rel >= 0) return no('이미 종교가 있어요'); if (mods(G, u.o).noRel) return no('종교를 창시할 수 없는 문명'); if (c.d.hs == null || u.p !== c.d.hs) return no('성지 위에서 써요'); if (G.s.R.length >= maxReligions(G)) return no('종교가 꽉 찼어요'); return true; }
    if (fx.gw) { if (gwSlots(G, c, fx.gw) <= 0) return no('이 도시에 빈 ' + GW_N[fx.gw] + ' 칸이 없어요(' + (fx.gw === 'wri' ? '원형 극장' : fx.gw === 'art' ? '미술관' : '방송 센터') + ')'); return true; }
    if (fx.wonder && !c.q.some((q) => q.t === 'w')) return no('이 도시가 불가사의를 짓고 있어야 해요');
    if (fx.space && !c.q.some((q) => q.t === 'p' && PRJ[PRJI[q.k]].d === 'sp')) return no('우주 프로젝트 중이어야 해요');
    if (fx.aura && !fx.retire) return true;
    return true;
  }
  function useGP(G, u, rel) {
    if (!gpCanUse(G, u)) return false;
    const gp = GPL[u.g], fx = gp.fx, o = u.o, p = G.P[o], c = tileCity(G, u.p);
    if (fx.rel) {
      if (!rel) return false;
      return foundReligion(G, o, u, rel.n, rel.f, rel.o);
    }
    if (fx.aura) {
      // 은퇴: 2칸 안 유닛 모두 승급 1회
      for (const v of G.U) if (v.o === o && isMil(v.t) && hexDist(G.g, v.p, u.p) <= 2 && (!!fx.naval === isNaval(v.t))) v.pp = (v.pp || 0) + 1;
      killUnit(G, u); note(G, o, '⭐ ' + gp.n + ' 은퇴: 근처 유닛 승급', u.p, 'gp'); return true;
    }
    if (fx.boost) randomBoosts(G, o, fx.boost);
    if (fx.sci) addSci(G, o, fx.sci * G.s.spT);
    if (fx.sciMtn) addSci(G, o, fx.sciMtn * Math.max(1, G.g.nb[u.p].filter((j) => G.ter[j] === TM).length) * G.s.spT * 0.5);
    if (fx.bld) { p.gpb = p.gpb || {}; p.gpb[fx.bld[0]] = yAdd(p.gpb[fx.bld[0]] || Y0(), fx.bld[1]); dirty(G); }
    if (fx.wonder) { const it = c.q.find((q) => q.t === 'w'); const key = itemKey(it); c.pp[key] = (c.pp[key] || 0) + fx.wonder * G.s.spP; }
    if (fx.space) { const it = c.q.find((q) => q.t === 'p' && PRJ[PRJI[q.k]].d === 'sp'); const key = itemKey(it); c.pp[key] = (c.pp[key] || 0) + fx.space * G.s.spP; }
    if (fx.gold) p.gold += Math.round(fx.gold * G.s.spP);
    if (fx.tr) { p.trx = (p.trx || 0) + 1; const sp = spawnSpot(G, c.p, UTI.trader, o); if (sp >= 0) mkUnit(G, o, UTI.trader, sp); }
    if (fx.amen) { c.am2 = (c.am2 || 0) + fx.amen; dirty(G); }
    if (fx.chg) { /* 비승: 건설자 */ const sp = spawnSpot(G, c.p, UTI.builder, o); if (sp >= 0) mkUnit(G, o, UTI.builder, sp); }
    if (fx.gw) {
      c.gw.push({ c: fx.gw, n: gp.id, e: gp.e, o });
      eraScore(G, o, 1, '걸작: ' + gp.n);
      u.ch = (u.ch == null ? GW_CH[fx.gw] || 1 : u.ch) - 1;
      if (u.ch > 0) { note(G, o, '⭐ ' + gp.n + ': 걸작을 만들었어요(남은 ' + u.ch + '점).', c.p, 'gp'); G.yc = {}; u.mv = 0; return true; }
    }
    killUnit(G, u);
    note(G, o, '⭐ ' + gp.n + ': ' + gp.d, c.p, 'gp');
    G.yc = {};
    return true;
  }

  /* ======================= 교역로 ======================= */
  function tradeDests(G, u) {
    const o = u.o, f = cityAt(G, u.p); if (!f || f.o !== o) return [];
    const out = [];
    for (const d of G.C) {
      if (d === f || !met(G, o, d.o) || atWar(G, o, d.o) || G.P[d.o].k === 'bb') continue;
      const dist = hexDist(G.g, f.p, d.p); if (dist > 16 + (f.d.hb != null ? 6 : 0) + (G.C.some((x) => (x.tp || []).indexOf(o) >= 0 && hexDist(G.g, x.p, d.p) <= 8) ? 6 : 0)) continue;   // 교역소가 사거리를 늘려요
      if (G.P[o].tr.some((tr) => tr.f === f.id && tr.d === d.id)) continue;
      out.push(d.id);
    }
    return out;
  }
  // 교역로 경로(땅 우선, 항만이 있으면 바다도): 너비 우선 탐색
  function routePath(G, f, d) {
    const sea = f.d.hb != null || coastal(G, f.p);
    const prev = new Map([[f.p, -1]]), q = [f.p];
    for (let k = 0; k < q.length && q.length < 3000; k++) {
      const i = q[k]; if (i === d.p) break;
      for (const j of G.g.nb[i]) {
        if (prev.has(j)) continue;
        const ok = j === d.p || G.cat[j] >= 0 || passableLand(G, j) || (sea && isWater(G, j) && G.ter[j] !== TO || (sea && G.ter[j] === TO && G.s.era >= 3));
        if (!ok) continue;
        prev.set(j, i); q.push(j);
      }
    }
    if (!prev.has(d.p)) return null;
    const path = []; let k = d.p; while (k >= 0) { path.push(k); k = prev.get(k); }
    return path.reverse();
  }
  function makeRoute(G, u, did) {
    if (tradeDests(G, u).indexOf(did) < 0) return false;
    const o = u.o, f = cityAt(G, u.p), d = G.cid[did];
    G.P[o].tr.push({ f: f.id, d: did, t: Math.round(30 * Math.max(0.6, G.s.spP)) });
    // 지나는 땅에 도로, 도착 도시에 교역소
    const path = routePath(G, f, d) || [];
    for (const j of path) if (passableLand(G, j) && !G.road[j]) G.road[j] = 1;
    d.tp = d.tp || []; if (d.tp.indexOf(o) < 0) d.tp.push(o);
    killUnit(G, u);
    if (G.P[o].tr.length === 1) eraScore(G, o, 1, '첫 교역로');
    meet(G, o, d.o);
    note(G, o, '🐪 교역로: ' + f.n + ' → ' + d.n, f.p, 'trade');
    G.yc = {};
    return true;
  }

  /* ======================= 거래(금·자원·사치품·도시·국경 개방) ======================= */
  // 거래 d = { A: a가 주는 것, B: b가 주는 것 }, 한쪽 = { g 금, gp 턴당 금(30턴), lx [사치 자원], st {자원: 양}, cy [도시], ob 국경 개방 }
  const DEAL_T = 30;
  function dealTurns(G) { return Math.round(DEAL_T * Math.max(0.6, G.s.spT)); }
  function sideOK(G, o, to, X, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    const p = G.P[o]; if (!X) return true;
    if (X.g && (X.g < 0 || p.gold < X.g)) return no(civName(G, o) + ': 금이 모자라요');
    if (X.gp && (X.gp < 0 || X.gp > Math.max(0, Math.floor(incomeOf(G, o).gold)) + 2)) return no(civName(G, o) + ': 턴당 금이 모자라요');
    const own = ownedLux(G, o, true);
    for (const d of (G.s.DL || [])) if (d.lx && d.a === o && d.t > 0 && own[d.lx]) own[d.lx]--;
    for (const r of (X.lx || [])) { if (!RES[r] || RES[r].c !== 'l' || !(own[r] > 0)) return no(civName(G, o) + ': 줄 수 있는 그 사치 자원이 없어요'); if ((G.s.DL || []).some((d) => d.lx === r && d.a === o && d.b === to && d.t > 0)) return no('이미 주고 있어요'); }
    for (const r in (X.st || {})) { if (!RES[r] || RES[r].c !== 's' || X.st[r] <= 0 || (p.stk[r] || 0) < X.st[r]) return no(civName(G, o) + ': 전략 자원이 모자라요'); }
    for (const cid of (X.cy || [])) { const c = G.cid[cid]; if (!c || c.o !== o || c.b.indexOf('palace') >= 0) return no('줄 수 없는 도시'); if (citiesOf(G, o).length <= 1) return no('마지막 도시는 못 줘요'); }
    if (X.ob && openBorders(G, o, to)) return no('이미 국경을 열었어요');
    if (X.ra) { if (!hasCivic(G, o, 'diploServ')) return no('연구 협정: 「외교 업무」 필요'); if (dipSt(G, o, to) < 2) return no('연구 협정: 친선 이상'); if (p.gold < raCost(G)) return no('연구 협정: 금 ' + raCost(G)); if ((G.s.DL || []).some((d) => d.ra && (d.a === o || d.b === o) && (d.a === to || d.b === to))) return no('이미 연구 협정 중'); }
    if (X.jw != null) { const q = X.jw; if (!isMaj(G, q) || q === o || q === to || !G.P[q].a || !met(G, o, q)) return no('공동 전쟁 대상?'); if (!atWar(G, o, q) && !canPropose(G, o, q, 'war')) return no('공동 전쟁: 지금은 전쟁할 수 없어요'); }
    return true;
  }
  function dealOK(G, a, b, d, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    if (!isMaj(G, a) || !isMaj(G, b) || a === b || !G.P[b].a) return no('?');
    if (!met(G, a, b)) return no('아직 못 만났어요');
    if (atWar(G, a, b)) return no('전쟁 중엔 거래할 수 없어요');
    if (dealEmpty(d.A) && dealEmpty(d.B)) return no('거래할 것을 골라요');
    return sideOK(G, a, b, d.A, why) && sideOK(G, b, a, d.B, why);
  }
  function dealEmpty(X) { return !X || (!X.g && !X.gp && !(X.lx || []).length && !Object.keys(X.st || {}).length && !(X.cy || []).length && !X.ob && !X.ra && X.jw == null); }
  function raCost(G) { return Math.round((80 + 40 * G.s.era) * Math.max(0.6, G.s.spP)); }
  function giveSide(G, o, to, X) {
    const p = G.P[o], q = G.P[to], T = dealTurns(G);
    if (X.g) { p.gold -= X.g; q.gold += X.g; }
    if (X.gp) (G.s.DL = G.s.DL || []).push({ a: o, b: to, gp: X.gp, t: T });
    for (const r of (X.lx || [])) (G.s.DL = G.s.DL || []).push({ a: o, b: to, lx: +r, t: T });
    for (const r in (X.st || {})) { p.stk[r] -= X.st[r]; q.stk[r] = (q.stk[r] || 0) + X.st[r]; }
    for (const cid of (X.cy || [])) giftCity(G, G.cid[cid], to);
    if (X.ob) (G.s.DL = G.s.DL || []).push({ a: o, b: to, ob: 1, t: T });
    if (X.ra) { p.gold -= raCost(G); if (!(G.s.DL || []).some((d) => d.ra && ((d.a === o && d.b === to) || (d.a === to && d.b === o)))) (G.s.DL = G.s.DL || []).push({ a: o, b: to, ra: 1, t: T }); }
    if (X.jw != null && !atWar(G, o, X.jw)) declareWar(G, o, X.jw);
  }
  function giftCity(G, c, to) {
    const old = c.o; c.o = to; c.q = []; c.pp = {}; c.lo = 60;
    if (c.gv >= 0) { const gv = G.P[old].gv.find((x) => x.g === c.gv); if (gv) gv.c = -1; c.gv = -1; }
    for (const u of G.U.slice()) if (u.o === old && (u.p === c.p || (isAir(u.t) && c.d.ad === u.p))) { const cap = capOf(G, old); const sp = cap ? spawnSpot(G, cap.p, u.t, old) : -1; if (sp >= 0) { if (isAir(u.t)) u.p = sp; else placeUnit(G, u, sp); } else killUnit(G, u); }
    for (const p2 of G.P) if (p2.k === 'maj') p2.tr = p2.tr.filter((tr) => tr.f !== c.id);
    assignWork(G, c); dirty(G);
    note(G, to, '🏙 ' + c.n + '을(를) 거래로 받았어요.', c.p, 'dip');
  }
  function applyDeal(G, a, b, d) {
    if (!dealOK(G, a, b, d)) return false;
    giveSide(G, a, b, d.A || {}); giveSide(G, b, a, d.B || {});
    note(G, a, '🤝 ' + civName(G, b) + '와 거래했어요: ' + dealText(G, d), -1, 'dip'); note(G, b, '🤝 ' + civName(G, a) + '와 거래했어요: ' + dealText(G, d, 1), -1, 'dip');
    G.yc = {}; dirty(G);
    return true;
  }
  function sideText(G, X) {
    const t = [];
    if (X.g) t.push('금 ' + X.g); if (X.gp) t.push('턴당 금 ' + X.gp);
    for (const r of (X.lx || [])) t.push(RES[r].n);
    for (const r in (X.st || {})) t.push(RES[r].n + ' ' + X.st[r]);
    for (const cid of (X.cy || [])) if (G.cid[cid]) t.push('도시 ' + G.cid[cid].n);
    if (X.ob) t.push('국경 개방'); if (X.ra) t.push('연구 협정'); if (X.jw != null) t.push('공동 전쟁(' + (G.P[X.jw] ? civName(G, X.jw) : '?') + ')');
    return t.join(', ') || '없음';
  }
  function dealText(G, d, flip) { return flip ? '받음 ' + sideText(G, d.A || {}) + ' / 줌 ' + sideText(G, d.B || {}) : '줌 ' + sideText(G, d.A || {}) + ' / 받음 ' + sideText(G, d.B || {}); }
  // AI가 보는 거래 가치(나 = me, 받는 쪽 R / 주는 쪽 Gv)
  function sideValue(G, me, X, giving) {
    let v = 0; if (!X) return 0;
    const p = G.P[me], own = ownedLux(G, me), sp = Math.max(0.5, G.s.spP);
    v += (X.g || 0);
    v += (X.gp || 0) * dealTurns(G) * 0.8;
    for (const r of (X.lx || [])) v += giving ? ((own[r] || 0) <= 1 ? 160 : 25) * sp : (own[r] ? 18 : 120) * sp;
    for (const r in (X.st || {})) v += X.st[r] * (giving ? 9 : 6);
    for (const cid of (X.cy || [])) { const c = G.cid[cid]; if (c) v += (150 + c.pop * 45 + c.b.length * 20) * sp * (giving ? 3 : 1); }
    if (X.ob) v += giving ? 40 : 18;
    if (X.ra) v += giving ? raCost(G) * 0.6 : 0;
    if (X.jw != null) v += giving ? (opinion(G, me, X.jw) + 20) * 3 + (milPower(G, X.jw) > milPower(G, me) ? 150 : 0) : 0;
    return v;
  }
  function aiDealValue(G, me, other, get, give) {
    const op = opinion(G, me, other), lv = G.P[me].lv || 2;
    return sideValue(G, me, get, false) - sideValue(G, me, give, true) * (lv >= 3 ? 1.15 : lv === 1 ? 0.9 : 1.05) + op * 1.5;
  }
  function proposeDeal(G, a, b, d) {
    if (!dealOK(G, a, b, d)) return 'no';
    if (G.P[b].lv > 0) {
      if (aiDealValue(G, b, a, d.A, d.B) >= 0) { applyDeal(G, a, b, d); return 'ok'; }
      note(G, a, '✋ ' + civName(G, b) + '이(가) 거래를 거절했어요.', -1, 'dip'); return 'rej';
    }
    G.s.Q = G.s.Q.filter((q) => !(q.f === a && q.t === b));
    G.s.Q.push({ f: a, t: b, k: 'deal', d, at: G.s.t });
    note(G, b, '📨 ' + civName(G, a) + '의 거래 제안 — 외교 화면에서 답하세요.', -1, 'prop');
    return 'sent';
  }
  function dealTick(G) {
    const DL = G.s.DL; if (!DL || !DL.length) return;
    for (const d of DL) {
      d.t--;
      if (d.ra && d.t === 0) for (const w of [d.a, d.b]) if (G.P[w].a) { const p2 = G.P[w]; if (p2.rs >= 0) { addSci(G, w, techCost(G, w, p2.rs) * 0.6); note(G, w, '🔬 연구 협정 성과: 과학 +' + Math.round(techCost(G, w, p2.rs) * 0.6), -1, 'dip'); } }
      if (d.gp && d.t >= 0) { const pa = G.P[d.a], pb = G.P[d.b]; const g2 = Math.min(d.gp, Math.max(0, pa.gold)); pa.gold -= g2; pb.gold += g2; }
      if (!G.P[d.a].a || !G.P[d.b].a || atWar(G, d.a, d.b)) d.t = 0;
    }
    G.s.DL = DL.filter((d) => d.t > 0);
    G.yc = {}; G.md = {};
  }

  /* ======================= 첩보(스파이) ======================= */
  const SPYM = {
    intel: { n: '정보 수집', t: 0, b: 1, d: '그 도시 주변이 보이고 그 나라 연구를 알 수 있어요(계속).' },
    gold: { n: '자금 빼돌리기', t: 5, b: 0.75, need: 'com', d: '상업 중심지에서 금을 훔쳐요.' },
    tech: { n: '기술 훔치기', t: 7, b: 0.6, need: 'cam', d: '캠퍼스에서 그 나라가 아는 기술의 유레카를 훔쳐요.' },
    sab: { n: '생산 방해', t: 7, b: 0.6, need: 'ind', d: '산업구역을 망가뜨려 8턴 동안 생산을 반으로 줄여요.' },
    gw: { n: '걸작 훔치기', t: 9, b: 0.5, need: 'th', d: '극장가에서 걸작 하나를 훔쳐 내 빈 칸에 넣어요.' },
    cs: { n: '선거 조작', t: 6, b: 0.65, d: '도시국가에서 내 사절 +2, 1등 나라 사절 −1.' },
    cspy: { n: '방첩', t: 0, b: 1, d: '내 도시(6칸 안 포함)를 노리는 첩보 성공률 −35%(계속).' },
  };
  function spyCap(G, o) {
    let n = 0; for (const k of ['diploServ', 'nationalism', 'coldWar', 'globalization']) if (hasCivic(G, o, k)) n++;
    if (G.C.some((c) => c.o === o && c.d.dq != null)) n++;
    return n;
  }
  function spyMissionOK(G, o, sp, cid, m, why) {
    const no = (x) => { if (why) why.push(x); return false; };
    const c = G.cid[cid], M = SPYM[m]; if (!c || !M) return no('?');
    if (m === 'cspy') return c.o === o ? true : no('내 도시에서만');
    if (c.o === o) return no('다른 나라 도시');
    const pc = G.P[c.o];
    if (m === 'cs') return pc.k === 'cs' && pc.a ? true : no('도시국가에서만');
    if (pc.k !== 'maj') return no('주요 문명 도시에서만');
    if (!met(G, o, c.o)) return no('아직 못 만났어요');
    if (M.need && c.d[M.need] == null) return no(DIS[DISI[M.need]].n + ' 필요');
    if (m === 'gw' && !(c.gw || []).length) return no('걸작이 없어요');
    return true;
  }
  function spyOdds(G, o, sp, cid, m) {
    const c = G.cid[cid], M = SPYM[m]; if (!c || !M) return 0;
    let f = M.b + 0.08 * ((sp.lv || 1) - 1);
    for (const q of G.P) if (q.k === 'maj' && q !== G.P[o]) for (const s2 of (q.spy || [])) if (s2.m === 'cspy' && G.cid[s2.c] && G.cid[s2.c].o === c.o && hexDist(G.g, G.cid[s2.c].p, c.p) <= 6) f -= 0.35;
    return clamp(f, 0.1, 1);
  }
  function spyAssign(G, o, i, cid, m) {
    const p = G.P[o], sp = (p.spy || [])[i]; if (!sp) return false;
    if (!spyMissionOK(G, o, sp, cid, m)) return false;
    const c = G.cid[cid], cap = capOf(G, o);
    sp.c = cid; sp.m = m; sp.tr = cap ? Math.ceil(hexDist(G.g, cap.p, c.p) / 10) : 1; sp.t = SPYM[m].t;
    return true;
  }
  function spyTick(G, o) {
    const p = G.P[o]; if (!p.spy) return;
    for (const sp of p.spy.slice()) {
      const c = G.cid[sp.c];
      if (!sp.m || !c) { sp.m = ''; continue; }
      if (sp.tr > 0) { sp.tr--; continue; }
      if (sp.m === 'cspy' && c.o !== o) { sp.m = ''; continue; }
      if (sp.m !== 'cspy' && sp.m !== 'cs' && c.o === o) { sp.m = ''; continue; }
      if (!SPYM[sp.m].t) continue;   // 계속 임무
      if (--sp.t > 0) continue;
      const ok = R() < spyOdds(G, o, sp, sp.c, sp.m), m = sp.m;
      if (ok) {
        let msg = '';
        if (m === 'gold') { const g2 = Math.round((40 + 25 * G.s.era) * Math.max(0.6, G.s.spP) * (1 + R() * 0.5)); const tg = G.P[c.o]; const take = Math.min(g2, Math.max(10, tg.gold)); tg.gold = Math.max(0, tg.gold - take); p.gold += take; msg = '금 ' + take + '을 빼돌렸어요'; }
        else if (m === 'tech') { const q = G.P[c.o]; const cand = []; for (let i = 0; i < TECH.length; i++) if (bitHas(q.tk, i) && !bitHas(p.tk, i) && !bitHas(p.tb, i)) cand.push(i); if (cand.length) { const ti = cand[ri(cand.length)]; giveBoost(G, o, ti); msg = TECH[ti].n + ' 유레카를 훔쳤어요'; } else msg = '훔칠 기술이 없었어요'; }
        else if (m === 'sab') { c.sab = 8; msg = c.n + ' 생산을 8턴 동안 반으로 줄였어요'; }
        else if (m === 'gw') { const w = c.gw.pop(); const pc = placeGW(G, o, w); if (!pc) { c.gw.push(w); msg = '넣을 빈 칸이 없어 포기했어요'; } else msg = GW_N[w.c] + '을(를) 훔쳐 ' + pc.n + '에 넣었어요'; G.yc = {}; }
        else if (m === 'cs') { const q = G.P[c.o]; let top = -1, tv = 0; for (const k in q.envs) if (+k !== o && q.envs[k] > tv) { tv = q.envs[k]; top = +k; } if (top >= 0) q.envs[top]--; q.envs[o] = (q.envs[o] || 0) + 2; updateSuz(G, c.o); msg = CSL[q.cs].n + ' 선거를 조작했어요(사절 +2)'; }
        sp.lv = Math.min(3, (sp.lv || 1) + (R() < 0.5 ? 1 : 0));
        note(G, o, '🕵 ' + SPYM[m].n + ' 성공: ' + msg, c.p, 'spy');
        if (isMaj(G, c.o)) note(G, c.o, '🕵 누군가 ' + c.n + '에서 「' + SPYM[m].n + '」에 성공했어요.', c.p, 'spy');
        sp.t = SPYM[m].t;
      } else {
        const caught = R() < 0.5;
        note(G, o, '🕵 ' + SPYM[m].n + ' 실패' + (caught ? ' — 첩보원이 붙잡혔어요.' : ' — 첩보원은 도망쳤어요.'), c.p, 'spy');
        if (isMaj(G, c.o)) { note(G, c.o, '🕵 ' + civName(G, o) + '의 첩보원이 ' + c.n + '에서 「' + SPYM[m].n + '」을(를) 하다 들켰어요.', c.p, 'spy'); grieve(G, c.o, o, 10); }
        if (caught) p.spy.splice(p.spy.indexOf(sp), 1); else { sp.m = ''; }
      }
    }
  }

  /* ======================= 외교 ======================= */
  function grieve(G, victim, culprit, n) { if (!isMaj(G, victim)) return; const gr = G.P[victim].gr; gr[culprit] = (gr[culprit] || 0) + n; }
  // AI가 b를 얼마나 좋아하나(−100~100)
  function opinion(G, a, b) {
    if (!isMaj(G, a) || !isMaj(G, b)) return 0;
    const pa = G.P[a], pb = G.P[b], ag = CIVS[pa.civ].ag;
    let v = 0;
    const st = dipSt(G, a, b);
    if (st === 0) v -= 40; else if (st === 2) v += 20; else if (st === 3) v += 35;
    v -= (pa.gr[b] || 0) * 0.6;
    v -= (pb.wm || 0) * 0.3 * (1 + (ag.peace || 0) * 0.5);
    const dn = G.s.D[dkey(a, b)]; if (dn && dn.dn) v -= 20;
    if (pa.rel >= 0 && pa.rel === pb.rel) v += 8 * (1 + (ag.rel || 0) * 0.3);
    if (pb.rel >= 0 && pa.rel >= 0 && pa.rel !== pb.rel && ag.rel) v -= 6 * ag.rel;
    if (pa.tr.some((tr) => G.cid[tr.d] && G.cid[tr.d].o === b)) v += 5;
    // 공동의 적
    for (const c of aliveMaj(G)) if (c !== a && c !== b && atWar(G, a, c) && atWar(G, b, c)) v += 12;
    // 성향
    const sa = scoreOf(G, a), sb = scoreOf(G, b);
    if (ag.sci && sciRate(G, b) > sciRate(G, a) * 1.2) v -= 4 * ag.sci;
    if (ag.cul && culRate(G, b) > culRate(G, a) * 1.2) v -= 3 * ag.cul;
    if (ag.won) v -= 3 * ag.won * Object.values(G.s.WB).filter((x) => x === b).length / 3;
    if (ag.war && milPower(G, b) < milPower(G, a) * 0.6) v -= 5 * ag.war;
    if (ag.exp && citiesOf(G, b).length > citiesOf(G, a).length + 2) v -= 4 * ag.exp;
    if (sb > sa * 1.5 && sb > 80) v -= 8;
    v += (pa.opr && pa.opr[b]) || 0;
    // 국경 맞닿음
    const close = G.C.some((c) => c.o === a && G.C.some((d) => d.o === b && hexDist(G.g, c.p, d.p) <= 6));
    if (close) v -= 6;
    return clamp(Math.round(v), -100, 100);
  }
  function sciRate(G, o) { let s = 0; for (const c of citiesOf(G, o)) s += cityCalc(G, c).y[3]; return s; }
  function culRate(G, o) { let s = 0; for (const c of citiesOf(G, o)) s += cityCalc(G, c).y[4]; return s; }
  function milPower(G, o) { let s = 0; for (const u of G.U) if (u.o === o && isMil(u.t)) s += Math.pow(Math.max(UT[u.t].cs || 0, UT[u.t].rs || 0), 1.5) * u.hp / 100; return s / 10; }
  function declareWar(G, a, b) {
    if (atWar(G, a, b) || a === b) return false;
    const r = dipRec(G, a, b);
    if (r.t > 0) return false;
    const prev = r.s;
    r.s = 0; r.t = Math.round(10 * Math.max(0.7, G.s.spT)); r.wt = G.s.t; r.df = 0;
    if (isMaj(G, a)) {
      const surprise = prev >= 2 ? 3 : 1;
      G.P[a].wm = (G.P[a].wm || 0) + 20 * surprise;
      if (isMaj(G, b)) { grieve(G, b, a, 30 * surprise); G.P[b].st.warv = 1; }
      if (G.P[b].k === 'cs') G.P[a].wm += 10;
      G.P[a].st.dw = (G.P[a].st.dw || 0) + (isMaj(G, b) ? 1 : 0);
      if (civK(G, a) === 'persia' || mods(G, a).warMv) G.P[a].pmv = 10;
      if (mods(G, a).warMv) G.P[a].pcs = 10;
      if (isMaj(G, b) && mods(G, b).defProd) G.P[b].dpT = 10;
    }
    note(G, b, '⚔ ' + civName(G, a) + '이(가) 우리에게 전쟁을 선포했어요!', -1, 'war');
    note(G, a, '⚔ ' + civName(G, b) + '에 전쟁을 선포했어요.', -1, 'war');
    for (const o of aliveMaj(G)) if (o !== a && o !== b) note(G, o, '⚔ ' + civName(G, a) + ' → ' + civName(G, b) + ' 전쟁 선포', -1, 'war');
    if (isMaj(G, a) && isMaj(G, b)) { say(G, a, b, 'war'); say(G, b, a, prev >= 2 ? 'betray' : 'warrecv'); esLog(G, 'w', civName(G, a) + '|' + civName(G, b)); }
    // 동맹은 함께 싸워요
    for (const al of aliveMaj(G)) if (al !== a && al !== b && dipSt(G, b, al) === 3 && !atWar(G, al, a)) { const r2 = dipRec(G, al, a); r2.t = 0; if (r2.s === 3) r2.s = 1; declareWarQuiet(G, al, a); }
    // 도시국가 종주국 보호
    if (G.P[b].k === 'cs' && G.P[b].suz >= 0 && G.P[b].suz !== a && !atWar(G, G.P[b].suz, a)) note(G, G.P[b].suz, '🏰 ' + CSL[G.P[b].cs].n + '(우리 종주국)이 공격받고 있어요!', -1, 'war');
    if (G.P[a].k === 'maj' && G.P[b].k === 'maj') for (const q of G.P) if (q.k === 'cs' && q.suz === b && q.a) declareWarQuiet(G, G.P.indexOf(q), a);
    return true;
  }
  function declareWarQuiet(G, a, b) { const r = dipRec(G, a, b); if (r.s === 0) return; r.s = 0; r.t = 5; r.wt = G.s.t; note(G, a, '⚔ 동맹/종주 관계로 ' + civName(G, b) + '와 전쟁에 들어갔어요.', -1, 'war'); note(G, b, '⚔ ' + civName(G, a) + '이(가) 전쟁에 합류했어요.', -1, 'war'); }
  function makePeace(G, a, b) {
    const r = dipRec(G, a, b); if (r.s !== 0) return false;
    r.s = 1; r.t = Math.round(12 * Math.max(0.7, G.s.spT));
    note(G, a, '🕊 ' + civName(G, b) + '와 평화 조약', -1, 'dip'); note(G, b, '🕊 ' + civName(G, a) + '와 평화 조약', -1, 'dip');
    return true;
  }
  // 제안 가능?
  function canPropose(G, a, b, k, why) {
    const no = (m) => { if (why) why.push(m); return false; };
    if (a === b || !G.P[b] || !G.P[b].a) return no('?');
    if (!met(G, a, b)) return no('아직 못 만났어요');
    const st = dipSt(G, a, b), r = G.s.D[dkey(a, b)] || { s: 1, t: 0 };
    if (k === 'war') { if (st === 0) return no('이미 전쟁 중'); if (r.t > 0) return no('조약 기간(' + r.t + '턴)'); if (G.s.t < Math.round(10 * G.s.spT) && isMaj(G, b)) return no('초반 ' + Math.round(10 * G.s.spT) + '턴은 전쟁 불가'); return true; }
    if (k === 'peace') { if (st !== 0) return no('전쟁 중이 아니에요'); if (r.t > 0) return no('전쟁 시작 뒤 ' + r.t + '턴 더'); return true; }
    if (!isMaj(G, b)) return no('도시국가와는 전쟁·평화만');
    if (k === 'dof') { if (st !== 1) return no(st === 0 ? '전쟁 중' : '이미 친선 이상'); if (r.dn) return no('비난 중'); return true; }
    if (k === 'ally') { if (st !== 2) return no('먼저 친선 선언'); if (!hasCivic(G, a, 'civilServ') || !hasCivic(G, b, 'civilServ')) return no('둘 다 「행정」 사회 제도 필요'); return true; }
    if (k === 'den') { if (st >= 2) return no('친선·동맹 중'); if (r.dn & (a < b ? 1 : 2)) return no('이미 비난했어요'); return true; }
    if (k === 'end') { if (st < 2) return no('친선·동맹이 아니에요'); return true; }
    return no('?');
  }
  function aiAccepts(G, me, from, k) {
    if (k === 'war' || k === 'den' || k === 'end') return true;
    const op = opinion(G, me, from), pm = milPower(G, me), pf = milPower(G, from);
    if (k === 'peace') {
      const r = dipRec(G, me, from), dur = G.s.t - (r.wt || 0);
      const losing = pf > pm * 1.3; const winning = pm > pf * 1.5;
      const ww = (G.P[me].ww || 0) / 100;
      return losing || (!winning && (dur > 12 * G.s.spT || ww > 1)) || (op > -10 && dur > 6);
    }
    if (k === 'dof') return op >= 12;
    if (k === 'ally') return op >= 30;
    return false;
  }
  function applyDip(G, a, b, k) {
    const r = dipRec(G, a, b);
    if (k === 'war') return declareWar(G, a, b);
    if (k === 'peace') return makePeace(G, a, b);
    if (k === 'dof') { r.s = 2; r.df = Math.round(30 * Math.max(0.6, G.s.spT)); note(G, a, '🤝 ' + civName(G, b) + '와 친선 선언', -1, 'dip'); note(G, b, '🤝 ' + civName(G, a) + '와 친선 선언', -1, 'dip'); return true; }
    if (k === 'ally') { r.s = 3; note(G, a, '🛡 ' + civName(G, b) + '와 동맹', -1, 'dip'); note(G, b, '🛡 ' + civName(G, a) + '와 동맹', -1, 'dip'); eraScore(G, a, 1, '동맹'); eraScore(G, b, 1, '동맹'); return true; }
    if (k === 'den') { r.dn = (r.dn || 0) | (a < b ? 1 : 2); grieve(G, b, a, 10); say(G, a, b, 'den'); say(G, b, a, 'denrecv'); note(G, b, '📢 ' + civName(G, a) + '이(가) 우리를 비난했어요.', -1, 'dip'); return true; }
    if (k === 'end') { r.s = 1; r.t = 0; grieve(G, b, a, 10); say(G, a, b, 'end'); say(G, b, a, 'betray'); note(G, b, '💔 ' + civName(G, a) + '이(가) 관계를 끊었어요.', -1, 'dip'); return true; }
    return false;
  }
  function propose(G, a, b, k) {
    if (!canPropose(G, a, b, k)) return 'no';
    if (k === 'war' || k === 'den' || k === 'end') { applyDip(G, a, b, k); return 'ok'; }
    if (G.P[b].lv > 0 || !isMaj(G, b)) { if (aiAccepts(G, b, a, k)) { applyDip(G, a, b, k); say(G, b, a, 'acc_' + k); return 'ok'; } note(G, a, '✋ ' + civName(G, b) + '이(가) 제안을 거절했어요.', -1, 'dip'); say(G, b, a, 'rej'); return 'rej'; }
    G.s.Q = G.s.Q.filter((q) => !(q.f === a && q.t === b));
    G.s.Q.push({ f: a, t: b, k, at: G.s.t });
    note(G, b, '📨 ' + civName(G, a) + '의 제안: ' + DIPN[k] + ' — 외교 화면에서 답하세요.', -1, 'prop');
    say(G, a, b, 'p_' + k);
    return 'sent';
  }
  const DIPN = { war: '전쟁 선포', peace: '평화', dof: '친선 선언', ally: '동맹', den: '비난', end: '관계 끊기' };

  /* ======================= 지도자 대사·연대기(라운드 48, 연출만) =======================
     AI 지도자가 사람 지도자에게 하는 말(s.DLG)과 시대별 「연대기 한 줄」(s.CH). 결과는 언제나 게임 규칙이 정하고, 대사는 그 결과를 말로만 옮겨요.
     자료 대사: 지도자마다 말투(VOICE: 말 높이·어조·자기/상대 호칭) × 상황 × 시대 낱말. AI가 켜져 있으면 호스트가 Haiku(대사)·Sonnet(연대기)로 다듬어 상태에 넣어요. */
  const jo = (w, a, b) => { w = String(w); const c = w.charCodeAt(w.length - 1); return w + (c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 ? a : b); };
  const ERA_ENV = ['사신', '사신', '사신', '사절', '사절', '대사', '대사', '대사', '대사'];
  const ERA_ARMY = ['전사들', '군단', '기사들', '군대', '군대', '사단', '기갑 부대', '기갑 부대', '무인 병기'];
  /* 말투: lv 말 높이(프롬프트용), tone 어조, bad 이 말투에 나오면 안 되는 어미(AI 출력 거르기) */
  const VOICE = {
    R: { n: '군주', lv: '하오체(~하오, ~이오, ~겠소), 자신을 「짐」, 상대를 「그대」라 부름', tone: '위엄 있고 느긋함', bad: /습니다|해요|세요|거든요/ },
    W: { n: '정복자', lv: '해라체 반말(~다, ~냐, ~라), 자신을 「나」, 상대를 「너」라 부름', tone: '거칠고 짧고 직설적', bad: /습니다|십시오|해요|세요|하오/ },
    S: { n: '정치가', lv: '합쇼체(~습니다, ~십시오), 자신을 「저」나 「우리」, 상대를 「귀국」이라 부름', tone: '정중하고 계산적', bad: /하오|겠소|해라|하냐/ },
    G: { n: '현자', lv: '합쇼체(~습니다), 자신을 「우리」, 상대를 「벗」이라 부름', tone: '차분하고 비유를 즐김', bad: /하오|겠소|해라|하냐/ },
    M: { n: '상인', lv: '해요체(~해요, ~죠), 자신을 「우리」, 상대를 「친구」라 부름', tone: '실리적이고 붙임성 좋음', bad: /하오|겠소|해라|하냐|습니다/ },
    X: { n: '책략가', lv: '해요체(~해요, ~죠), 자신을 「저」, 상대를 「당신」이라 부름', tone: '은근하고 속을 알 수 없음', bad: /하오|겠소|해라|하냐|습니다/ },
  };
  const LVOICE = {
    america: 'S', arabia: 'G', brazil: 'S', china: 'R', egypt: 'X', england: 'R', france: 'X', germany: 'W', greece: 'S', india: 'G',
    japan: 'W', kongo: 'G', norway: 'W', rome: 'S', russia: 'R', scythia: 'W', spain: 'R', sumeria: 'W', aztec: 'R', korea: 'R',
    mongolia: 'W', zulu: 'W', netherlands: 'M', canada: 'S', ottoman: 'R', mali: 'M', sweden: 'G', hungary: 'S', inca: 'R', maori: 'G',
    phoenicia: 'M', persia: 'X', australia: 'S', babylon: 'R', byzantium: 'R', cree: 'G', ethiopia: 'R', gaul: 'W', georgia: 'R', gcolombia: 'S',
    indonesia: 'X', khmer: 'R', macedon: 'W', mapuche: 'W', maya: 'R', nubia: 'R', poland: 'S', portugal: 'M', scotland: 'W', vietnam: 'W',
  };
  /* 지도자 한마디 버릇(가끔 덧붙임) — 성격을 보여 주는 짧은 말 */
  const LTIC = {
    america: '대담하게 갑시다.', mongolia: '초원은 넓지 않다.', india: '평화가 곧 길입니다.', zulu: '창은 쉬지 않는다.', mali: '금은 거짓말을 안 해요.',
    phoenicia: '바다는 모두의 길이죠.', france: '비밀은 비밀일 때 아름답죠.', egypt: '나일은 기억해요.', china: '만리장성은 하루에 쌓지 않았소.',
    korea: '별을 읽는 자가 나라를 읽소.', greece: '아테네는 지켜봅니다.', norway: '바다가 부른다.', scythia: '말 위에서 보자.', rome: '모든 길은 통합니다.',
    babylon: '법은 돌에 새겨지는 법이오.', sweden: '책은 칼보다 오래갑니다.', persia: '약속은 잘 지켜야죠.', gaul: '쇠는 달궈졌을 때 친다.',
  };
  const DL = {
    R: {
      greet: ['{me}의 군주가 그대를 맞이하오. 서로 예를 갖추도록 하지.', '그대가 {you}의 주인이구려. 짐이 기억해 두겠소.', '먼 땅에서 온 손님이로군. {me}의 문은 아직 열려 있소.'],
      p_dof: ['그대와 친선을 맺고 싶소. 짐의 {env}가 기다리겠소.', '{you}와 짐의 나라가 손을 잡을 때가 된 듯하오.'],
      p_ally: ['동맹을 청하오. 짐의 {army}가 그대 곁에 서겠소.', '이제 맹약을 맺읍시다. 그대라면 믿을 만하오.'],
      p_peace: ['피는 충분히 흘렀소. 칼을 거두도록 하지.', '짐이 먼저 화해를 청하오. 받아들이겠소?'],
      war: ['더는 참지 않겠소. {me}의 {army}가 그대를 찾아갈 것이오.', '짐의 인내는 여기까지요. 전장에서 봅시다.'],
      den: ['온 세상에 고하노니, {you}의 처사는 옳지 않소.', '짐은 그대의 행실을 똑똑히 지켜보고 있소.'],
      end: ['우리 사이의 약조는 여기까지요.', '짐은 더 이상 그대를 벗으로 여기지 않겠소.'],
      acc_dof: ['좋소, 친선을 받아들이지.', '그대의 뜻이 마음에 드오. 친선을 맺읍시다.'],
      acc_ally: ['맹약을 받아들이오. 그대의 적은 곧 짐의 적이오.', '좋소. 오늘부터 {me}와 {you}는 한편이오.'],
      acc_peace: ['평화를 받아들이겠소. 다만 잊지는 않을 것이오.', '좋소, 칼을 거두지. 이번만이오.'],
      rej: ['그 청은 들어줄 수 없소.', '아직은 때가 아니오. 물러가시오.', '짐의 대답은 「아니오」요.'],
      warrecv: ['감히 짐에게 칼을 겨누다니. 후회하게 될 것이오.', '좋소, 그대가 원한 전쟁이오.'],
      betray: ['벗이라 믿었거늘, 등에 칼을 꽂는구려. 결코 잊지 않겠소.', '배신의 값은 비싸다는 걸 알게 될 것이오.'],
      denrecv: ['짐을 비난하다니, 그 말은 꼭 돌려주겠소.', '그대의 혀가 그대 나라를 위태롭게 하는구려.'],
      wonder: ['{won}이라… 짐도 탐내던 것이오. 축하는 하지.', '{won}을 세웠다고? 짐의 궁정이 술렁이는구려.'],
      border: ['그대의 국경이 짐의 땅에 너무 가깝소. 물러나시오.', '짐의 변경에 그대의 깃발이 자꾸 보이는구려.'],
      hacc: ['현명한 판단이오. {me}가 기억하겠소.', '그대의 화답, 기쁘게 받겠소.'],
      hrej: ['짐의 호의를 거절하다니, 아쉽구려.', '그렇다면 할 수 없지. 기억해 두겠소.'],
      mood_f: ['그대와의 우정은 {me}의 보물이오.', '오늘도 그대의 소식이 반갑구려.'],
      mood_n: ['그대를 지켜보고 있소. 나쁜 뜻은 없소.', '서로 넘지 말아야 할 선은 알고 있겠지.'],
      mood_h: ['짐 앞에서 조심하는 게 좋을 것이오.', '그대의 이름만 들어도 불쾌하구려.'],
    },
    W: {
      greet: ['{me}의 칼을 기억해 둬라. 우리가 만났으니.', '네가 {you}의 우두머리냐. 생각보다 작군.', '새 얼굴이군. 강하냐, 약하냐?'],
      p_dof: ['너 쓸 만하군. 친선을 맺자.', '싸우기 아까운 상대다. 손 잡자.'],
      p_ally: ['함께 싸우자. 내 {army}가 앞장선다.', '동맹이다. 등은 내가 지켜 주지.'],
      p_peace: ['이 정도면 됐다. 칼을 내리자.', '싸움은 질렸다. 평화를 받아라.'],
      war: ['말은 끝났다. {army}가 간다.', '네 땅이 탐난다. 지켜 봐라.', '전쟁이다. 각오해라.'],
      den: ['{you}는 겁쟁이다. 다들 들어라.', '네 꼴이 마음에 안 든다.'],
      end: ['더는 한편이 아니다.', '우정은 끝이다. 알아서 해라.'],
      acc_dof: ['좋다. 친선이다.', '받아 주지. 실망시키지 마라.'],
      acc_ally: ['좋다, 이제 같은 편이다.', '동맹이다. 네 적은 내가 벤다.'],
      acc_peace: ['좋다, 이번엔 살려 준다.', '평화다. 하지만 칼은 갈아 둔다.'],
      rej: ['싫다.', '웃기는군. 꺼져라.', '그건 안 된다.'],
      warrecv: ['나한테 덤비다니, 배짱은 좋군.', '드디어 싸울 맛이 나는군.'],
      betray: ['등 뒤에서 찌르다니, 비겁한 놈.', '배신자의 땅은 불태운다.'],
      denrecv: ['말로 싸우는 건 약한 놈들이나 하는 짓이다.', '떠들어 봐라. 곧 조용해질 거다.'],
      wonder: ['{won}? 돌덩이로 나를 막을 수는 없다.', '{won}이라… 언젠가 내 것이 될 거다.'],
      border: ['내 땅 가까이 오지 마라.', '국경에서 얼쩡대면 목을 친다.'],
      hacc: ['좋아, 말이 통하는군.', '잘 생각했다.'],
      hrej: ['거절이라… 기억해 두지.', '흥, 후회할 거다.'],
      mood_f: ['너랑은 싸우고 싶지 않다. 아직은.', '쓸 만한 친구다, 너는.'],
      mood_n: ['지켜보고 있다.', '약해지는 순간 끝이다.'],
      mood_h: ['네 땅이 자꾸 눈에 밟힌다.', '언제 한판 붙을지 모르겠군.'],
    },
    S: {
      greet: ['반갑습니다. {me}를 대표해 인사드립니다.', '{you}의 지도자를 뵙게 되어 영광입니다.', '좋은 이웃이 되기를 바랍니다.'],
      p_dof: ['귀국과 친선을 맺고 싶습니다. 서로에게 이득이 될 겁니다.', '우리 {env}가 친선 문서를 가져갔습니다. 검토해 주십시오.'],
      p_ally: ['동맹을 제안합니다. 함께라면 더 멀리 갈 수 있습니다.', '이제 한 걸음 더 나아갈 때입니다. 동맹을 맺읍시다.'],
      p_peace: ['이 전쟁은 누구에게도 이득이 없습니다. 평화를 제안합니다.', '협상 테이블로 돌아오시지요.'],
      war: ['유감스럽지만 더는 대화로 풀 수 없겠습니다.', '외교는 끝났습니다. 이제 {army}가 말할 차례입니다.'],
      den: ['귀국의 처사를 공식적으로 규탄합니다.', '세계가 귀국의 행동을 알아야 합니다.'],
      end: ['유감이지만 우리 관계를 재검토하겠습니다.', '더는 친선을 유지할 이유가 없겠군요.'],
      acc_dof: ['기쁘게 받아들이겠습니다.', '좋은 결정입니다. 친선을 맺읍시다.'],
      acc_ally: ['동맹을 수락합니다. 믿어 주신 만큼 보답하겠습니다.', '오늘은 두 나라 모두에게 좋은 날입니다.'],
      acc_peace: ['평화를 받아들이겠습니다. 다시는 이런 일이 없기를.', '현명한 선택입니다. 휴전합시다.'],
      rej: ['죄송하지만 지금은 받아들이기 어렵습니다.', '검토해 보았지만 이번엔 거절하겠습니다.', '조건이 맞지 않는군요.'],
      warrecv: ['이 선택을 후회하시게 될 겁니다.', '좋습니다. 우리도 준비가 되어 있습니다.'],
      betray: ['신의를 저버리셨군요. 세계가 지켜보고 있습니다.', '친선을 깨고 칼을 들다니, 실망입니다.'],
      denrecv: ['근거 없는 비난입니다. 유감입니다.', '그 말씀, 외교 문서에 남겨 두겠습니다.'],
      wonder: ['{won} 완공을 축하드립니다. 솔직히 부럽군요.', '{won}이라니, 귀국의 저력을 인정합니다.'],
      border: ['국경 문제로 우려가 큽니다. 자제해 주십시오.', '귀국의 정착지가 우리 쪽으로 너무 다가오고 있습니다.'],
      hacc: ['수락해 주셔서 감사합니다.', '좋은 협력의 시작이 되겠군요.'],
      hrej: ['아쉽군요. 다음 기회를 기다리겠습니다.', '이해합니다. 문은 열어 두겠습니다.'],
      mood_f: ['귀국과의 관계는 늘 든든합니다.', '좋은 이웃을 둬서 다행입니다.'],
      mood_n: ['서로 이익이 맞는다면 언제든 이야기합시다.', '지켜보고 있겠습니다.'],
      mood_h: ['귀국의 행보가 매우 우려스럽습니다.', '인내심에도 한계가 있습니다.'],
    },
    G: {
      greet: ['벗이여, 먼 길을 오셨군요. 같은 하늘 아래 만났습니다.', '새로운 이웃을 만나니 마음이 놓입니다.', '{you}의 바람이 여기까지 불어왔군요.'],
      p_dof: ['우리 두 나라가 나란히 걸으면 좋겠습니다.', '벗이여, 친선의 손을 내밉니다.'],
      p_ally: ['강물이 합쳐지면 바다가 됩니다. 동맹을 맺읍시다.', '어려운 시대엔 함께여야 합니다.'],
      p_peace: ['불은 모든 것을 태웁니다. 이제 끕시다.', '싸움을 멈추고 숨을 고릅시다.'],
      war: ['원치 않았지만, 우리도 지켜야 할 것이 있습니다.', '말이 닿지 않으니 어쩔 수 없군요.'],
      den: ['당신의 길은 틀렸습니다. 모두에게 알리겠습니다.', '벗이라 부르기 어렵게 되었군요.'],
      end: ['이제 각자의 길을 가야겠습니다.', '우리의 인연은 여기까지인가 봅니다.'],
      acc_dof: ['기꺼이 받겠습니다, 벗이여.', '좋습니다. 함께 걸읍시다.'],
      acc_ally: ['우리는 이제 한 뿌리입니다.', '동맹을 받아들입니다. 서로를 지킵시다.'],
      acc_peace: ['평화를 반깁니다. 상처는 시간이 낫게 하겠지요.', '네, 칼을 내려놓겠습니다.'],
      rej: ['아직 마음이 열리지 않습니다.', '때가 무르익지 않았습니다.', '미안하지만 받을 수 없습니다.'],
      warrecv: ['슬픈 일입니다. 하지만 우리는 무너지지 않습니다.', '폭풍이 오는군요. 버텨 내겠습니다.'],
      betray: ['믿음을 깨뜨리셨군요. 깨진 그릇은 다시 붙지 않습니다.', '벗의 칼이 가장 아픈 법입니다.'],
      denrecv: ['거친 말은 말한 이에게 돌아갑니다.', '그 비난, 담담히 받겠습니다.'],
      wonder: ['{won}… 아름답군요. 후대가 기억할 겁니다.', '{won}을 세우셨다니, 진심으로 축하합니다.'],
      border: ['국경이 너무 가깝습니다. 서로 숨 쉴 땅이 필요하지요.', '당신의 정착민이 우리 들판을 넘보는군요.'],
      hacc: ['고맙습니다, 벗이여.', '마음이 통했군요.'],
      hrej: ['그렇군요. 길은 또 열릴 겁니다.', '아쉽지만 이해합니다.'],
      mood_f: ['당신과의 우정은 오래된 나무처럼 든든합니다.', '좋은 벗이 있어 다행입니다.'],
      mood_n: ['우리는 서로 배울 것이 많습니다.', '조용히 지켜보고 있습니다.'],
      mood_h: ['당신의 그림자가 길어지는군요.', '마음이 편치 않습니다.'],
    },
    M: {
      greet: ['반가워요! {me}의 시장은 언제나 열려 있어요.', '새 거래처가 생겼네요. 잘 지내 봐요.', '좋은 물건 있으면 우리랑 바꿔요.'],
      p_dof: ['우리 친하게 지내요. 서로 남는 장사예요.', '친선 맺으면 장사도 잘될 거예요.'],
      p_ally: ['동맹 어때요? 돈도 군대도 함께 굴려요.', '같이 가면 손해 볼 일 없어요.'],
      p_peace: ['전쟁은 장사에 최악이에요. 그만해요.', '이쯤에서 화해하죠. 서로 손해만 보잖아요.'],
      war: ['미안하지만 이번엔 계산이 그렇게 나왔어요.', '거래는 끝났어요. 이제 {army}가 협상할 거예요.'],
      den: ['{you}랑은 거래하지 말라고 다들 그러던데요.', '당신 평판, 시장에서 바닥이에요.'],
      end: ['계약은 여기까지예요.', '더는 남는 게 없네요. 정리하죠.'],
      acc_dof: ['좋아요, 거래 성사!', '좋죠. 친하게 지내요.'],
      acc_ally: ['동맹 성사! 이제 한 배를 탔어요.', '좋아요, 이익도 위험도 반반이에요.'],
      acc_peace: ['좋아요, 장사나 다시 하죠.', '평화라니 반가워요. 손해가 컸거든요.'],
      rej: ['음, 이건 우리가 손해예요.', '조건이 별로네요. 다음에요.', '그 값엔 안 돼요.'],
      warrecv: ['이런, 비싼 실수를 하셨네요.', '전쟁 비용은 당신이 치르게 될 거예요.'],
      betray: ['신용을 잃으셨네요. 그건 금보다 비싸요.', '친구라더니 뒤통수라니요.'],
      denrecv: ['말로는 돈이 안 돼요. 신경 안 써요.', '비난이요? 손님 하나 잃으셨네요.'],
      wonder: ['{won}이라니, 관광객 좀 몰리겠네요!', '{won} 축하해요. 입장료는 얼마예요?'],
      border: ['국경 너무 붙지 마요. 장사하기 불편해요.', '그쪽 개척민이 우리 땅을 기웃거려요.'],
      hacc: ['역시 말이 통하네요.', '좋아요, 계약서 찍었어요.'],
      hrej: ['아쉽네요. 조건은 언제든 다시 봐요.', '그래요, 다음 장날에 봐요.'],
      mood_f: ['당신 덕분에 장사가 잘돼요.', '우리 사이 좋잖아요?'],
      mood_n: ['좋은 거래 있으면 불러요.', '뭐, 나쁘지 않네요.'],
      mood_h: ['당신이랑은 장사하기 싫어요.', '요즘 그쪽 소문이 안 좋네요.'],
    },
    X: {
      greet: ['어머, 드디어 만났네요. 소문은 많이 들었어요.', '{you}의 지도자시군요. 재미있는 분 같아요.', '반가워요. 우리 서로 잘 알아 두는 게 좋겠죠.'],
      p_dof: ['우리 친해지면 좋은 일이 많을 거예요.', '친선, 어때요? 비밀은 지켜 드릴게요.'],
      p_ally: ['동맹을 맺어요. 둘이 알면 세상이 모르는 것도 있죠.', '이제 같은 편이 되는 게 어때요?'],
      p_peace: ['이쯤에서 웃으며 끝내는 게 서로 좋지 않을까요?', '싸움은 그만해요. 더 재미있는 방법이 있어요.'],
      war: ['미안해요, 이미 정해진 일이었어요.', '놀라셨나요? 저는 계속 준비하고 있었어요.'],
      den: ['당신에 대해 다들 알아야 할 이야기가 있더군요.', '조금 시끄럽게 굴어 볼게요. 당신 이야기로요.'],
      end: ['우리 사이, 여기서 정리하죠.', '이제 당신은 쓸모가 없네요.'],
      acc_dof: ['좋아요. 앞으로 잘 부탁해요.', '기꺼이요. 기대할게요.'],
      acc_ally: ['좋아요, 이제 우린 한편이에요. 당분간은요.', '동맹이라니, 마음에 들어요.'],
      acc_peace: ['좋아요, 평화로 하죠. 지금은요.', '받아들일게요. 빚 하나 진 거예요.'],
      rej: ['글쎄요, 별로 끌리지 않네요.', '그건 제 계획에 없어요.', '안 돼요. 이유는 비밀이에요.'],
      warrecv: ['이런, 실수하셨네요.', '그럴 줄 알았어요. 준비는 끝났어요.'],
      betray: ['배신은 제 특기인 줄 알았는데요.', '기억해 둘게요. 아주 오래요.'],
      denrecv: ['재미있네요. 그 말, 돌려 드릴게요.', '저를 비난하다니, 용감하시네요.'],
      wonder: ['{won}… 예쁘네요. 오래가면 좋겠어요.', '{won}이라니, 다들 부러워하겠어요.'],
      border: ['국경이 꽤 가까워졌네요. 신경 쓰이게.', '당신 깃발이 자꾸 제 쪽으로 오네요.'],
      hacc: ['현명하시네요.', '좋아요, 그렇게 나와야죠.'],
      hrej: ['그래요? 아쉽네요… 정말로요.', '거절이라니, 기억해 둘게요.'],
      mood_f: ['당신이라면 믿어도 될 것 같아요. 아마도요.', '우리 사이, 꽤 괜찮죠?'],
      mood_n: ['당신을 지켜보는 게 즐거워요.', '아직은 판단을 미뤄 둘게요.'],
      mood_h: ['당신을 볼 때마다 계획이 하나씩 늘어요.', '조심하세요. 그냥 하는 말이에요.'],
    },
  };
  const DLK = { greet: '첫 만남 인사', p_dof: '친선 선언 제안', p_ally: '동맹 제안', p_peace: '평화 제안', war: '상대에게 전쟁 선포', den: '상대를 공개 비난', end: '친선·동맹 관계를 끊음',
    acc_dof: '상대의 친선 제안을 받아들임', acc_ally: '상대의 동맹 제안을 받아들임', acc_peace: '상대의 평화 제안을 받아들임', rej: '상대의 제안을 거절함',
    warrecv: '상대가 우리에게 전쟁을 선포함', betray: '친선·동맹이던 상대가 배신함(기습 전쟁 또는 관계 끊기)', denrecv: '상대가 우리를 비난함', wonder: '상대가 불가사의를 완성함',
    border: '국경이 맞닿아 신경이 쓰임', hacc: '상대가 우리의 제안을 받아들임', hrej: '상대가 우리의 제안을 거절함', mood_f: '안부(호감)', mood_n: '안부(보통)', mood_h: '안부(불쾌)' };
  const voiceOf = (civi) => VOICE[LVOICE[CIVS[civi].k] || 'S'];
  const voiceK = (civi) => LVOICE[CIVS[civi].k] || 'S';
  const opBand = (op) => (op <= -40 ? '적대' : op <= -12 ? '냉담' : op < 15 ? '보통' : op < 35 ? '우호' : '각별');
  /* AI 지도자 f가 사람 지도자 t에게 하는 말(자료) — 최근에 쓴 문장은 다시 안 골라요 */
  function dlgText(G, f, t, k, x) {
    const vk = voiceK(G.P[f].civ), arr = (DL[vk] && DL[vk][k]) || DL.S[k] || ['…'];
    const recent = (G.s.DLG || []).filter((d) => d.f === f).slice(-6).map((d) => d.ti);
    let ok = arr.map((_, i) => i).filter((i) => recent.indexOf(k + i) < 0);
    if (!ok.length) ok = arr.map((_, i) => i);
    const i = ok[ri(ok.length)], era = clamp(G.s.era || 0, 0, 8);
    const nmOf = { me: civName(G, f), you: civName(G, t), won: (x && x.won) || '불가사의' };
    const JP = { 이라: ['이라', '라'], 라: ['이라', '라'], 을: ['을', '를'], 를: ['을', '를'], 은: ['은', '는'], 는: ['은', '는'], 이: ['이', '가'], 가: ['이', '가'], 과: ['과', '와'], 와: ['과', '와'], 랑: ['이랑', '랑'] };
    let tx = arr[i].replace(/\{(me|you|won)\}(이라|라|을|를|은|는|이|가|과|와|랑)?/g, (m0, k2, pp) => (pp ? jo(nmOf[k2], JP[pp][0], JP[pp][1]) : nmOf[k2]))
      .split('{env}').join(ERA_ENV[era]).split('{army}').join(ERA_ARMY[era]);
    const tic = LTIC[CIVS[G.P[f].civ].k];
    if (tic && /^(greet|mood_|hacc|acc_)/.test(k) && R() < 0.3 && tx.length < 40) tx += ' ' + tic;
    return { tx, ti: k + i };
  }
  function say(G, f, t, k, x) {
    if (!isMaj(G, f) || !isMaj(G, t) || f === t) return;
    if (!(G.P[f].lv > 0) || G.P[t].lv > 0 || !G.P[f].a || !G.P[t].a) return;   // AI 지도자 → 사람 지도자만
    const s = G.s, L2 = s.DLG || (s.DLG = []);
    const { tx, ti } = dlgText(G, f, t, k, x);
    s.dq = (s.dq || 0) + 1;
    const d = { id: s.dq, f, t, k, x: tx, ti, n: s.t, ai: 0 };
    if (x && x.won) d.w = x.won;
    if (x && x.dk) d.dk = x.dk;
    L2.push(d);
    if (L2.length > 14) L2.splice(0, L2.length - 14);
  }
  /* 시대 통계(연대기용) */
  function esLog(G, k, v) { const e = G.s.ES || (G.s.ES = {}); const a = e[k] || (e[k] = []); if (a.length < 6 && a.indexOf(v) < 0) a.push(v); }
  function chronicle(G) {
    const s = G.s, e = s.ES || {}, al = aliveMaj(G);
    const lead = al.slice().sort((a, b) => scoreOf(G, b) - scoreOf(G, a))[0];
    const st = [];
    if (e.wo && e.wo.length) { const [c, w] = e.wo[ri(e.wo.length)].split('|'); st.push(jo(c, '이', '가') + ' ' + jo(w, '을', '를') + ' 세웠'); }
    if (e.rl && e.rl.length) { const [c, r] = e.rl[0].split('|'); st.push(c + '에서 ' + jo(r, '이', '가') + ' 일어났'); }
    if (e.cp && e.cp.length) { const [c, w] = e.cp[ri(e.cp.length)].split('|'); st.push(jo(c, '이', '가') + ' ' + w + '의 손에 떨어졌'); }
    else if (e.w && e.w.length) { const [a, b] = e.w[ri(e.w.length)].split('|'); st.push(jo(a, '과', '와') + ' ' + b + ' 사이에 전쟁이 벌어졌'); }
    if (!(e.w && e.w.length) && !(e.cp && e.cp.length) && st.length < 2) st.push(pickR(['큰 전쟁 없이 평화가 이어졌', '칼보다 쟁기가 바빴', '나라들은 저마다 땅을 넓혔', '도시마다 성벽보다 시장이 커졌', '학자와 장인이 바쁜 나날을 보냈'].filter((x) => !(s.CH || []).slice(-2).some((c) => c.x.indexOf(x) >= 0))));
    const pl = (s.CH || []).length ? s.CH[s.CH.length - 1].f : null;
    if (lead != null && st.length < 3) st.unshift(jo(civName(G, lead), '이', '가') + ' ' + (pl && pl.lead === civName(G, lead) ? pickR(['여전히 앞서 나갔', '선두를 지켰']) : pickR(['가장 앞서 나갔', '선두로 올라섰', '앞서 달리기 시작했'])));
    const body = st.slice(0, 3).map((x, i, a) => x + (i < a.length - 1 ? '고' : '다')).join(', ') + '.';
    const facts = { era: ERA[s.era], lead: lead != null ? civName(G, lead) : '', w: (e.w || []).map((x) => x.replace('|', '↔')), wo: (e.wo || []).map((x) => x.replace('|', ': ')),
      rl: (e.rl || []).map((x) => x.replace('|', ': ')), cp: (e.cp || []).map((x) => x.replace('|', ' → ')) };
    const C2 = s.CH || (s.CH = []);
    s.dq = (s.dq || 0) + 1;
    C2.push({ id: s.dq, e: s.era, x: ERA[s.era] + ' 시대 — ' + body, f: facts, ai: 0, n: s.t });
    if (C2.length > 9) C2.splice(0, C2.length - 9);
    s.ES = {};
  }
  /* AI 프롬프트(호스트 전용). 공개된 사실만 넣어요. */
  const DLG_SYS = '너는 4X 전략 게임 「문명 개척」의 AI 지도자 대사 작가다. 실존 역사 지도자의 이름을 쓰지만 게임 속 캐릭터로서 말한다.\n' +
    '규칙: 주어진 지도자의 말 높이와 어조를 끝까지 지킨다. 1~2문장, 70자 이내, 자연스러운 한국어 구어. 주어진 상황·관계·사건만 근거로 삼고, 결과(수락·거절·전쟁 등)는 이미 정해졌으니 바꾸거나 다른 약속을 하지 않는다. ' +
    '숫자·점수·게임 용어(턴, 호감도 수치)·비밀 계획은 말하지 않는다. 최근에 한 말과 다른 표현을 쓴다. 따옴표·이름표·이모지 없이 대사만.';
  const CH_SYS = '너는 4X 전략 게임 「문명 개척」의 연대기 작가다. 한 시대를 역사서 문체(~했다)의 한국어 한 문장으로 요약한다.\n' +
    '규칙: 80자 이내 한 문장, 주어진 사실만 쓰고 지어내지 않는다. 숫자·점수는 쓰지 않는다. 시대 이름으로 시작하지 않는다(앞에 붙여 준다). 따옴표·머리말 없이 문장만.';
  function dlgFacts(G, d) {
    const f = d.f, t = d.t, pf = G.P[f], C2 = CIVS[pf.civ], V = voiceOf(pf.civ);
    const stt = dipSt(G, f, t), op = opinion(G, f, t), r = G.s.D[dkey(f, t)] || {};
    const ev = [];
    if (stt === 0) ev.push('지금 전쟁 중');
    if (r.dn) ev.push('서로 비난한 적 있음');
    if ((pf.gr[t] || 0) > 25) ev.push('상대에게 묵은 불만이 큼');
    if ((G.P[t].wm || 0) > 40) ev.push('상대는 호전적이라는 평판');
    const wn = Object.values(G.s.WB).filter((x) => x === t).length; if (wn) ev.push('상대가 불가사의를 여럿 가짐');
    if (G.C.some((c) => c.o === f && G.C.some((c2) => c2.o === t && hexDist(G.g, c.p, c2.p) <= 6))) ev.push('국경이 맞닿음');
    for (const o of aliveMaj(G)) if (o !== f && o !== t && atWar(G, f, o) && atWar(G, t, o)) { ev.push('공동의 적 ' + civName(G, o)); break; }
    const recent = (G.s.DLG || []).filter((x) => x.f === f && x.id !== d.id).slice(-3).map((x) => x.x);
    return { ld: C2.ld, me: C2.n, you: civName(G, t), youLd: CIVS[G.P[t].civ].ld, voice: V, agn: C2.agn, agd: C2.agd, era: ERA[G.s.era], rel: ['전쟁', '평화', '친선', '동맹'][stt],
      band: opBand(op), sit: DLK[d.k] + (d.w ? '(' + d.w + ')' : ''), ev, recent };
  }
  function dlgPrompt(F) {
    return ['지도자: ' + F.ld + ' (' + F.me + ') — 말투: ' + F.voice.lv + ', 어조: ' + F.voice.tone + ', 성향: ' + F.agn + ' — ' + F.agd,
      '상대: ' + F.youLd + ' (' + F.you + ')', '시대: ' + F.era + ' (시대에 맞는 낱말을 쓴다)', '관계: ' + F.rel + ', 감정: ' + F.band,
      '지금 상황: ' + F.sit, F.ev.length ? '최근 사정: ' + F.ev.join(', ') : '', F.recent.length ? '최근에 한 말(반복 금지): ' + F.recent.join(' / ') : '', '대사:'].filter(Boolean).join('\n');
  }
  function chPrompt(f) {
    return ['시대: ' + f.era, '가장 앞선 나라: ' + (f.lead || '없음'), '전쟁: ' + (f.w.join(', ') || '없음'), '불가사의: ' + (f.wo.join(', ') || '없음'),
      '종교 창시: ' + (f.rl.join(', ') || '없음'), '도시 함락: ' + (f.cp.join(', ') || '없음'), '연대기 한 문장:'].join('\n');
  }
  /* AI 출력 거르기: 이름표·따옴표 제거, 문장 수·길이, 말투 어긋남, 최근 대사와 겹침 */
  function cleanLine(t, o) {
    if (!t || typeof t !== 'string') return '';
    t = t.replace(/[*#`"“”「」『』]/g, '').replace(/^\s*[^:：\n]{1,14}[:：]\s*/, '').replace(/\s+/g, ' ').trim();
    if (!t || /[A-Za-z]{3,}/.test(t) || /\d/.test(t)) return '';
    const sn = t.match(/[^.!?…]+[.!?…]+/g) || [t + '.'];
    t = sn.slice(0, o.max || 2).join(' ').trim();
    if (t.length > (o.len || 100)) return '';
    if (o.bad && o.bad.test(t)) return '';
    if (o.end && !o.end.test(t)) return '';
    const head = t.replace(/\s/g, '').slice(0, 10);
    if ((o.recent || []).some((r) => r && r.replace(/\s/g, '').slice(0, 10) === head)) return '';
    return t.length >= 4 ? t : '';
  }

  /* ======================= 도시국가 ======================= */
  function updateSuz(G, csi) {
    const q = G.P[csi]; if (!q || q.k !== 'cs') return;
    let best = -1, bv = 0, tie = false;
    for (const k in q.envs) { const v = q.envs[k]; if (!G.P[k] || !G.P[k].a) continue; if (v > bv) { bv = v; best = +k; tie = false; } else if (v === bv) tie = true; }
    const ns = bv >= 3 && !tie ? best : -1;
    if (ns !== q.suz) {
      if (ns >= 0) { note(G, ns, '👑 ' + CSL[q.cs].n + '의 종주국이 되었어요! (' + CSL[q.cs].d + ')', -1, 'cs'); eraScore(G, ns, 1, CSL[q.cs].n + ' 종주국'); }
      if (q.suz >= 0) note(G, q.suz, '👑 ' + CSL[q.cs].n + '의 종주국 지위를 잃었어요.', -1, 'cs');
      q.suz = ns; dirty(G);
    }
  }
  function sendEnvoy(G, o, csi) {
    const p = G.P[o], q = G.P[csi];
    if (p.env <= 0 || !q || q.k !== 'cs' || !q.a || !met(G, o, csi) || atWar(G, o, csi)) return false;
    p.env--; q.envs[o] = (q.envs[o] || 0) + 1; updateSuz(G, csi); dirty(G); return true;
  }

  /* ======================= 비상사태(흥망성쇠) ======================= */
  function triggerEmergency(G, tg, why) {
    if (!isMaj(G, tg)) return;
    if (G.s.EM.some((e) => e.tg === tg)) return;
    const mem = aliveMaj(G).filter((o) => o !== tg && met(G, o, tg) && dipSt(G, o, tg) < 3);
    if (mem.length < 1) return;
    G.s.EM.push({ tg, why, t: Math.round(15 * Math.max(0.6, G.s.spT)), mem, c0: citiesOf(G, tg).length });
    for (const o of mem) note(G, o, '🚨 군사 비상사태: ' + civName(G, tg) + '(' + why + '). 참가국은 그 나라 상대 전투력 +4.', -1, 'em');
    note(G, tg, '🚨 우리를 겨냥한 비상사태가 선포됐어요(' + why + ').', -1, 'em');
    dirty(G);
  }
  function emergencyTick(G) {
    for (const e of G.s.EM) {
      e.t--;
      if (e.t <= 0) {
        const lost = citiesOf(G, e.tg).length < e.c0;
        for (const o of e.mem) if (G.P[o].a) { if (lost) { eraScore(G, o, 2, '비상사태 성공'); G.P[o].favor += 10; G.P[o].dvp += 1; } }
        if (!lost) { eraScore(G, e.tg, 3, '비상사태를 버텨냄'); G.P[e.tg].favor += 10; G.P[e.tg].dvp += 1; }
        noteAll(G, '🚨 ' + civName(G, e.tg) + ' 비상사태 종료 — ' + (lost ? '참가국 성공' : '대상국이 버텨냈어요'), -1, 'em');
      }
    }
    const before = G.s.EM.length;
    G.s.EM = G.s.EM.filter((e) => e.t > 0 && G.P[e.tg].a);
    if (G.s.EM.length !== before) dirty(G);
  }

  /* ======================= 세계 의회(몰려드는 폭풍) ======================= */
  function congressSetup(G) {
    const s = G.s, n = s.WC.n || 0;
    const pool = RESO.map((r, i) => i).filter((i) => RESO[i].k !== 'dvp').sort(() => R() - 0.5);
    const pick = [0, pool[0]];
    s.WC.pend = { res: pick, at: s.t, votes: {} };
    noteAll(G, '🏛 세계 의회가 곧 열려요(다음 라운드). 외교 호의로 표를 더 살 수 있어요.', -1, 'wc');
  }
  function voteCost(n) { return n <= 0 ? 0 : 10 * n * (n + 1) / 2; }
  function resTargets(G, ri2) {
    const t = RESO[ri2].tg;
    if (t === 'p') return aliveMaj(G);
    if (t === 'd') return ['cam', 'hs', 'com', 'th', 'ind', 'hb', 'enc'];
    if (t === 'g') return GPK.slice();
    return [0];
  }
  function aiVote(G, o, ri2) {
    const R2 = RESO[ri2], tg = resTargets(G, ri2), ag = CIVS[G.P[o].civ].ag;
    let best = { op: 0, tg: tg[0], v: -1e9 };
    for (const t of tg) for (const op of [0, 1]) {
      let v = R() * 2;
      if (R2.tg === 'p') { const good = op === 0; v += (t === o ? (good ? 30 : -30) : (good ? opinion(G, o, t) * 0.2 - scoreOf(G, t) * 0.05 : -opinion(G, o, t) * 0.2 + scoreOf(G, t) * 0.05)); if (R2.k === 'arms') v = t === o ? (op === 1 ? 10 + (ag.war || 0) * 5 : -10) : (op === 0 ? 5 + (ag.war ? -3 : 3) : -5); }
      else if (R2.tg === 'd') { const has = citiesOf(G, o).filter((c) => c.d[t] != null).length; v += op === 0 ? has * 3 : -has * 2; }
      else if (R2.tg === 'g') { const pts = gpPoints(G, o)[t] || 0; v += op === 0 ? pts * 3 : -pts * 2; }
      if (v > best.v) best = { op, tg: t, v };
    }
    return best;
  }
  function congressResolve(G) {
    const s = G.s, pend = s.WC.pend; if (!pend) return;
    s.WC.act = [];
    const out = [];
    for (let k = 0; k < pend.res.length; k++) {
      const ri2 = pend.res[k], tally = {};
      for (const o of aliveMaj(G)) {
        const p = G.P[o];
        let v = pend.votes[o] && pend.votes[o][k];
        if (!v) { if (p.lv > 0) { const b = aiVote(G, o, ri2); const extra = Math.min(3, Math.floor(Math.sqrt(p.favor / 15))); let n = 1; for (let e = 1; e <= extra; e++) if (p.favor >= voteCost(e)) n = 1 + e; p.favor -= voteCost(n - 1); v = { op: b.op, tg: b.tg, n }; } else continue; }
        const key = v.op + '|' + v.tg; tally[key] = (tally[key] || 0) + (v.n || 1);
      }
      let bk = null, bv = 0; for (const key in tally) if (tally[key] > bv || (tally[key] === bv && R() < 0.5)) { bv = tally[key]; bk = key; }
      if (!bk) continue;
      const [op, tg] = bk.split('|'); const tgv = RESO[ri2].tg === 'p' ? +tg : tg;
      s.WC.act.push({ ri: ri2, op: +op, tg: tgv });
      if (RESO[ri2].k === 'dvp') G.P[+tg].dvp = Math.max(0, G.P[+tg].dvp + (+op === 0 ? 2 : -2));
      const tgN = RESO[ri2].tg === 'p' ? civName(G, +tg) : RESO[ri2].tg === 'd' ? DIS[DISI[tg]].n : RESO[ri2].tg === 'g' ? GPC[tg].n : '';
      out.push(RESO[ri2].n + ': ' + (+op === 0 ? RESO[ri2].a : RESO[ri2].b) + ' (' + tgN + ')');
    }
    s.WC.pend = null; s.WC.last = out; s.WC.n = (s.WC.n || 0) + 1;
    noteAll(G, '🏛 세계 의회 결의: ' + out.join(' · '), -1, 'wc');
    dirty(G);
  }

  /* ======================= 야만인 ======================= */
  const BARB_U = [['warrior', 'slinger', 'scout'], ['swordsman', 'archer', 'horseman'], ['manatarms', 'crossbow', 'courser'], ['musket', 'crossbow', 'courser'], ['lineinf', 'fieldcannon', 'cavalry'], ['infantry', 'machinegun', 'cavalry']];
  function barbTick(G) {
    const s = G.s, bb = s.BB; if (!s.barb || bb < 0) return;
    const N = G.N, BC = s.BC || (s.BC = {});
    // 야영지 생성
    const camps = []; for (let i = 0; i < N; i++) if (G.imp[i] === IMPI.bcamp) camps.push(i);
    for (const k in BC) if (G.imp[+k] !== IMPI.bcamp) delete BC[k];
    const maxC = Math.max(2, Math.round(N / 150));
    if (camps.length < maxC && s.t >= 3 && R() < 0.25) {
      for (let tr = 0; tr < 30; tr++) {
        const i = ri(N);
        if (!passableLand(G, i) || G.own[i] >= 0 || G.res[i] || G.imp[i] || milAt(G, i) || civAt(G, i)) continue;
        if (G.C.some((c) => hexDist(G.g, c.p, i) < 5)) continue;
        if (G.U.some((u) => G.P[u.o].k === 'maj' && hexDist(G.g, u.p, i) <= 2)) continue;
        G.imp[i] = IMPI.bcamp; camps.push(i); break;
      }
    }
    // 야영지: 정찰병이 도시를 찾으면 습격대를 보내요(원작처럼)
    const set = BARB_U[Math.min(BARB_U.length - 1, s.era)];
    for (const i of camps) {
      const bc = BC[i] || (BC[i] = { a: -1, n: 0 });
      const mine = G.U.filter((u) => u.o === bb && u.home === i);
      if (bc.a < 0) {
        if (!mine.some((u) => u.bs) && R() < 0.3) { const t = UTI.scout; const sp = spawnSpot(G, i, t, bb); if (sp >= 0) { const u = mkUnit(G, bb, t, sp); u.home = i; u.bs = 1; } }
        if (mine.filter((u) => !u.bs).length < 1 && R() < 0.12) { const t = UTI[pickR(set)]; const sp = spawnSpot(G, i, t, bb); if (sp >= 0) { const u = mkUnit(G, bb, t, sp); u.home = i; } }
      } else {
        const tc = cityAt(G, bc.a);
        if (!tc || !isMaj(G, tc.o)) { bc.a = -1; continue; }
        bc.n = (bc.n || 0) + 1;
        if (mine.filter((u) => !u.bs).length < 2 + Math.min(2, s.era) && (bc.n % 3 === 0 || R() < 0.25)) {
          const cav = s.era >= 1 && R() < 0.4 ? (s.era >= 4 ? 'cavalry' : s.era >= 2 ? 'courser' : 'horseman') : pickR(set);
          const t = UTI[cav]; const sp = spawnSpot(G, i, t, bb); if (sp >= 0) { const u = mkUnit(G, bb, t, sp); u.home = i; u.rd = bc.a; }
          // 바닷가 야영지는 배도
          if (coastal(G, i) && s.era >= 1 && R() < 0.3) { const ts = UTI[s.era >= 3 ? 'privateer' : 'quad']; const sw = G.g.nb[i].find((j) => isWater(G, j) && !milAt(G, j)); if (sw != null) { const u2 = mkUnit(G, bb, ts, sw); u2.home = i; u2.rd = bc.a; } }
        }
        if (bc.n > 40) { bc.a = -1; bc.n = 0; }
      }
    }
    // 유닛 행동
    for (const u of G.U.filter((x) => x.o === bb)) {
      if (!G.uid[u.id]) continue;
      u.mv = maxMv(G, u); u.a = 0; u.mvd = 0;
      if (u.hp < 100) u.hp = Math.min(100, u.hp + 10);
      if (u.bs) {
        // 정찰병: 가까운 도시를 찾아요
        let goal = -1, gd = 99; for (const c of G.C) if (isMaj(G, c.o)) { const d = hexDist(G.g, c.p, u.p); if (d < gd && d <= 14) { gd = d; goal = c.p; } }
        if (goal >= 0 && gd <= 2 && u.home != null && BC[u.home]) { BC[u.home].a = goal; const c = cityAt(G, goal); note(G, c.o, '⚠ 야만인 정찰병이 ' + c.n + '을(를) 찾아냈어요. 곧 습격대가 올 수 있어요!', u.p, 'war'); killUnit(G, u); continue; }
        if (goal >= 0) goToward(G, u, goal); else { const R2 = reach(G, u); const ks = Object.keys(R2.r); if (ks.length) moveUnit(G, u, +pickR(ks)); }
        if (u.home != null && G.imp[u.home] !== IMPI.bcamp) killUnit(G, u);
        continue;
      }
      const tg = targets(G, u);
      if (tg.length) { let best = tg[0], bv = -1e9; for (const j of tg) { const pv = combatPreview(G, u, j); const v = pv.kill * 50 + (pv.da[0] || 0) - (pv.dr[1] || 0) * 0.7 + (cityAt(G, j) ? (u.rd != null ? 5 : -10) : 0); if (v > bv) { bv = v; best = j; } } if (bv > -10) { doAttack(G, u, best); continue; } }
      // 습격 목표 또는 근처 목표로
      let goal = -1, gd = 99;
      if (u.rd != null && cityAt(G, u.rd)) { goal = u.rd; gd = hexDist(G.g, u.p, goal); if (gd <= 1) { const nb2 = G.g.nb[goal].filter((j) => tileOwner(G, j) >= 0 && G.imp[j] && !G.pil[j]); if (nb2.length && R() < 0.5) goal = nb2[0]; } }
      if (goal < 0) for (const v of G.U) if (v.o !== bb && hexDist(G.g, v.p, u.p) <= 6 && hexDist(G.g, v.p, u.p) < gd && isLand(G, v.p) === !isNaval(u.t)) { gd = hexDist(G.g, v.p, u.p); goal = v.p; }
      if (goal < 0) for (const c of G.C) if (hexDist(G.g, c.p, u.p) <= 7 && hexDist(G.g, c.p, u.p) < gd) { gd = hexDist(G.g, c.p, u.p); goal = c.p; }
      if (goal < 0 && u.home != null && hexDist(G.g, u.home, u.p) > 3) goal = u.home;
      if (goal >= 0) goToward(G, u, goal);
      else { const R2 = reach(G, u); const ks = Object.keys(R2.r); if (ks.length) moveUnit(G, u, +pickR(ks)); }
      if (G.uid[u.id] && canPillage(G, u) && R() < 0.5) doPillage(G, u);
    }
  }

  /* ======================= 도시국가 퀘스트·징집 ======================= */
  const CSQ = { tr: '교역로 보내기', tech: '기술 연구', civic: '사회 제도 완성', dist: '구역 짓기', gp: '위인 영입', unit: '유닛 훈련', rel: '종교 전파' };
  function csQuestText(G, q) {
    if (!q) return '';
    if (q.k === 'tech') return '「' + TECH[q.a].n + '」 연구';
    if (q.k === 'civic') return '「' + CIVIC[q.a].n + '」 완성';
    if (q.k === 'dist') return DIS[DISI[q.a]].n + ' 짓기';
    if (q.k === 'gp') return '위인 한 명 더 영입';
    if (q.k === 'unit') return UT[UTI[q.a]].n + ' 훈련';
    if (q.k === 'rel') return '이 도시국가에 내 종교 전파';
    return '이 도시국가로 교역로 보내기';
  }
  function csQuestDone(G, o, csi, q) {
    const p = G.P[o], c = G.C.find((x) => x.o === csi);
    if (q.k === 'tr') return !!c && p.tr.some((tr) => tr.d === c.id);
    if (q.k === 'tech') return bitHas(p.tk, q.a);
    if (q.k === 'civic') return bitHas(p.ck, q.a);
    if (q.k === 'dist') return G.C.some((d) => d.o === o && d.d[q.a] != null);
    if (q.k === 'gp') return (p.st.gp || 0) > q.n;
    if (q.k === 'unit') return G.U.some((u) => u.o === o && (UT[u.t].k === q.a || UT[u.t].rep === q.a));
    if (q.k === 'rel') return !!c && p.rel >= 0 && c.rl === p.rel;
    return false;
  }
  function csQuestNew(G, o, csi) {
    const p = G.P[o], kinds = [];
    if (hasCivic(G, o, 'foreignTrade')) kinds.push('tr');
    const at = []; for (let i = 0; i < TECH.length; i++) if (techAvail(G, o, i) && TECH[i].k !== 'future') at.push(i); if (at.length) kinds.push('tech');
    const ac = []; for (let i = 0; i < CIVIC.length; i++) if (civicAvail(G, o, i) && CIVIC[i].k !== 'futureCiv') ac.push(i); if (ac.length) kinds.push('civic');
    const ds = ['cam', 'hs', 'com', 'th', 'ind', 'hb', 'enc'].filter((k) => hasReq(G, o, DIS[DISI[k]].req) && !G.C.some((d) => d.o === o && d.d[k] != null)); if (ds.length) kinds.push('dist');
    kinds.push('gp');
    const us = UT.filter((T) => isGround(UTI[T.k]) && !T.civ && hasReq(G, o, T.req) && !T.res && !G.U.some((u) => u.o === o && u.t === UTI[T.k])); if (us.length) kinds.push('unit');
    if (p.rel >= 0) kinds.push('rel');
    const k = pickR(kinds);
    const q = { k, t: G.s.t + Math.round(50 * Math.max(0.6, G.s.spT)) };
    if (k === 'tech') q.a = pickR(at); else if (k === 'civic') q.a = pickR(ac); else if (k === 'dist') q.a = pickR(ds); else if (k === 'gp') q.n = p.st.gp || 0; else if (k === 'unit') q.a = pickR(us).k;
    return q;
  }
  function csQuestTick(G, csi) {
    const q = G.P[csi]; q.qs = q.qs || {};
    for (const o of aliveMaj(G)) {
      if (!met(G, o, csi) || atWar(G, o, csi)) { delete q.qs[o]; continue; }
      const cur = q.qs[o];
      if (cur) {
        if (csQuestDone(G, o, csi, cur)) { q.envs[o] = (q.envs[o] || 0) + 1; delete q.qs[o]; updateSuz(G, csi); note(G, o, '🏰 ' + CSL[q.cs].n + ' 퀘스트 완료(' + csQuestText(G, cur) + '): 사절 +1', -1, 'cs'); }
        else if (G.s.t > cur.t) delete q.qs[o];
      } else if (R() < 0.08) { q.qs[o] = csQuestNew(G, o, csi); note(G, o, '🏰 ' + CSL[q.cs].n + '의 부탁: ' + csQuestText(G, q.qs[o]) + ' (사절 +1)', -1, 'cs'); }
    }
  }
  function levyCost(G) { return Math.round((60 + 40 * G.s.era) * Math.max(0.6, G.s.spP)); }
  function levyCS(G, o, csi) {
    const q = G.P[csi], p = G.P[o];
    if (!q || q.k !== 'cs' || !q.a || q.suz !== o || q.lev >= 0 && q.lev != null && q.levT > 0) return false;
    const cost = levyCost(G); if (p.gold < cost) return false;
    const units = G.U.filter((u) => u.o === csi && isGround(u.t)); if (!units.length) return false;
    p.gold -= cost; q.lev = o; q.levT = Math.round(30 * Math.max(0.6, G.s.spT));
    for (const u of units) { u.o = o; u.lev = csi; u.mv = 0; }
    note(G, o, '🏰 ' + CSL[q.cs].n + ' 군대를 징집했어요(' + units.length + '기, ' + q.levT + '턴).', -1, 'cs');
    dirty(G); return true;
  }
  function levyTick(G, csi) {
    const q = G.P[csi]; if (q.lev == null || q.lev < 0) return;
    if (--q.levT > 0 && q.suz === q.lev && !atWar(G, q.lev, csi)) return;
    for (const u of G.U.slice()) if (u.lev === csi) { if (q.a) { u.o = csi; delete u.lev; } else killUnit(G, u); }
    note(G, q.lev, '🏰 ' + CSL[q.cs].n + ' 징집 기간이 끝났어요.', -1, 'cs');
    q.lev = -1; q.levT = 0;
  }

  /* ======================= 자유 도시 ======================= */
  function fcTick(G) {
    const fc = G.s.FC; if (fc == null || fc < 0) return;
    const best = UT.reduce((b, T, i) => ((T.cl === 'mel' || T.cl === 'rng') && !T.civ && !T.res && (T.era || 0) <= G.s.era && (!b || (T.cs || 0) > (UT[b].cs || 0)) ? i : b), null);
    for (const c of G.C.filter((x) => x.o === fc)) {
      if (c.hp < 200) c.hp = Math.min(200, c.hp + 15);
      if (c.at) c.at--; c.rs = 0;
      if (!milAt(G, c.p) && best != null && R() < 0.2) mkUnit(G, fc, best, c.p);
      for (const j of cityStrikeTargets(G, c)) { cityStrike(G, c, j); break; }
      loyaltyTick(G, c);
    }
    for (const u of G.U.filter((x) => x.o === fc)) { u.mv = maxMv(G, u); u.a = 0; u.mvd = 0; if (u.hp < 100) u.hp = Math.min(100, u.hp + 15); const tg = targets(G, u); if (tg.length) doAttack(G, u, tg[0]); }
  }

  /* ======================= 도시국가 행동 ======================= */
  function csTick(G) {
    for (let o = G.s.nM; o < G.P.length; o++) {
      const q = G.P[o]; if (q.k !== 'cs' || !q.a) continue;
      const c = G.C.find((x) => x.o === o); if (!c) { q.a = 0; continue; }
      // 성장·방어
      if (c.pop < 3 + G.s.era) { c.fd = (c.fd || 0) + 2; if (c.fd >= growNeed(G, c)) { c.fd = 0; c.pop++; assignWork(G, c); } }
      if (c.hp < 200) c.hp = Math.min(200, c.hp + 15);
      c.wl = Math.max(c.wl, Math.min(3, 1 + Math.floor(G.s.era / 2))); if (c.wh < c.wl * 100 && !c.at) c.wh = Math.min(c.wl * 100, c.wh + 20);
      if (c.at) c.at--;
      c.rs = 0;
      const mine = G.U.filter((u) => u.o === o);
      const best = UT.reduce((b, T, i) => ((T.cl === 'mel' || T.cl === 'rng') && !T.civ && !T.res && (T.era || 0) <= G.s.era && (!b || (T.cs || 0) > (UT[b].cs || 0)) ? i : b), null);
      if (mine.length < 2 + Math.floor(G.s.era / 2) && R() < 0.12 && best != null) { const sp = spawnSpot(G, c.p, best, o); if (sp >= 0) mkUnit(G, o, best, sp); }
      for (const u of mine) {
        if (!G.uid[u.id]) continue;
        u.mv = maxMv(G, u); u.a = 0; u.mvd = 0; if (u.hp < 100) u.hp = Math.min(100, u.hp + 15);
        // 낡은 유닛 교체
        const up = upgradeTo(G, u); if (up >= 0 && (UT[up].era || 0) <= G.s.era && !UT[up].res && R() < 0.1) u.t = up;
        const tg = targets(G, u).filter((j) => hexDist(G.g, j, c.p) <= 4);
        if (tg.length) { doAttack(G, u, tg[0]); continue; }
        if (hexDist(G.g, u.p, c.p) > 2) goToward(G, u, c.p);
      }
      for (const j of cityStrikeTargets(G, c)) { cityStrike(G, c, j); break; }
      cityProduceCS(G, c);
      csQuestTick(G, o);
      levyTick(G, o);
    }
  }
  function cityProduceCS(G, c) { borderGrow(G, c, 1); }

  /* ======================= 기후·재해(몰려드는 폭풍) ======================= */
  function climateTick(G) {
    const s = G.s, CL = s.CL;
    if (!s.dis) return;
    for (const c of G.C) if (c.b.some((k) => k === 'factory' || k === 'elecfac')) CL.co2 += 0.6;
    let st = 0; for (let k = 0; k < CO2_STEP.length; k++) if (CL.co2 >= CO2_STEP[k] * s.spP) st = k;
    if (st > CL.st) { CL.st = st; noteAll(G, '🌡 기후 변화 ' + CLIM[st] + ' — 재해가 늘고 해수면이 오를 수 있어요.', -1, 'cl'); }
    const seaTarget = st >= 7 ? 3 : st >= 5 ? 2 : st >= 3 ? 1 : 0;
    if (seaTarget > CL.sea) {
      CL.sea = seaTarget;
      let n = 0;
      for (let i = 0; i < G.N; i++) {
        if (!G.low[i] || G.low[i] > CL.sea || G.cat[i] >= 0) continue;
        const c = tileCity(G, i); if (c && c.b.indexOf('flood') >= 0) continue;
        G.ter[i] = TC; G.hill[i] = 0; G.feat[i] = 0; G.imp[i] = 0; G.res[i] = 0; G.low[i] = 0;
        if (G.dis[i]) { const dc = tileCity(G, i); if (dc) for (const k in dc.d) if (dc.d[k] === i) delete dc.d[k]; G.dis[i] = 0; }
        for (const u of G.U.slice()) if (u.p === i && !isNaval(u.t)) { const sp = spawnSpot(G, i, u.t, u.o); if (sp >= 0 && sp !== i) placeUnit(G, u, sp); else killUnit(G, u); }
        n++;
      }
      noteAll(G, '🌊 해수면 상승! 저지대 ' + n + '칸이 바다에 잠겼어요.', -1, 'cl');
      G.yc = {};
    }
    const base = [0, 0.05, 0.09][s.dis] * (1 + CL.st * 0.25);
    if (R() < base) disaster(G, pickR(['flood', 'flood', 'volc', 'storm', 'storm', 'drought']));
  }
  function disaster(G, k) {
    let center = -1, area = [];
    if (k === 'flood') {
      const c = []; for (let i = 0; i < G.N; i++) if (G.feat[i] === F_FLOOD) { const ct = tileCity(G, i); if (!ct || ct.d.dam == null) c.push(i); }
      if (!c.length) return; center = pickR(c);
      area = within(G.g, center, 2).filter((j) => G.feat[j] === F_FLOOD || (G.riv[j] && isLand(G, j)));
      for (const j of area) { if (G.imp[j] && R() < 0.35) G.pil[j] = 1; if (R() < 0.6) G.fy[j] = Math.min(15, (G.fy[j] & 3) < 3 ? G.fy[j] + 1 : G.fy[j]); }
    } else if (k === 'volc') {
      const c = []; for (let i = 0; i < G.N; i++) if (G.feat[i] === F_VOLC || (nwAt(G, i) && nwAt(G, i).volc)) c.push(i);
      if (!c.length) return; center = pickR(c);
      area = G.g.nb[center];
      for (const j of area) {
        for (const u of G.U.slice()) if (u.p === j) { u.hp -= 40; if (u.hp <= 0) killUnit(G, u); }
        if (G.imp[j] && R() < 0.6) G.pil[j] = 1; if (G.dis[j] && DIS[G.dis[j]].k !== 'cc' && R() < 0.4) G.dpil[j] = 1;
        if (passableLand(G, j) && !G.dis[j] && G.cat[j] < 0 && (!G.feat[j] || G.feat[j] === F_WOODS || G.feat[j] === F_MARSH) && R() < 0.7) G.feat[j] = F_VSOIL;
      }
    } else {
      const land = []; for (let i = 0; i < G.N; i++) if (passableLand(G, i) && G.own[i] >= 0) land.push(i);
      if (!land.length) return; center = pickR(land);
      if (k === 'storm') {
        const lat = Math.abs(((center / G.W) | 0) / (G.H - 1) - 0.5) * 2;
        k = lat > 0.6 ? 'bliz' : G.ter[center] === TD ? 'dust' : 'storm';
      }
      area = within(G.g, center, 2);
      for (const j of area) {
        for (const u of G.U.slice()) if (u.p === j && R() < 0.7) { u.hp -= 25; if (u.hp <= 0) killUnit(G, u); }
        if (G.imp[j] && R() < (k === 'drought' ? 0.15 : 0.3)) G.pil[j] = 1;
        if (k !== 'drought' && k !== 'bliz' && R() < 0.3 && isLand(G, j)) G.fy[j] = Math.min(15, ((G.fy[j] >> 2) & 3) < 3 ? G.fy[j] + 4 : G.fy[j]);
      }
      if (k === 'drought') for (const j of area) { const c = cityAt(G, j); if (c) c.fd = Math.max(0, (c.fd || 0) - 15); }
    }
    G.yc = {};
    const who = {}; for (const j of area) { const o = tileOwner(G, j); if (o >= 0) who[o] = 1; }
    for (const o in who) note(G, +o, '⚠ ' + DISN[k] + '! 피해를 입었어요' + (k === 'flood' || k === 'volc' ? '(땅이 비옥해졌어요)' : '') + '.', center, 'dis');
    ev(G, { k: 'z', p: center, d: k });
  }

  /* ======================= 정부·정책 ======================= */
  function slotsOf(G, o) {
    const p = G.P[o], M = mods(G, o), sl = GOV[p.gov].sl.slice();
    if (M.slot) for (let i = 0; i < 4; i++) sl[i] += M.slot[i];
    if (G.C.some((c) => c.o === o && c.d.gov != null)) sl[3] += 1;
    return sl;
  }
  function slotTypes(G, o) { const sl = slotsOf(G, o), out = []; for (let i = 0; i < 4; i++) for (let k = 0; k < sl[i]; k++) out.push(SLOTT[i]); return out; }
  function fitPolicies(G, o) {
    const p = G.P[o], ty = slotTypes(G, o);
    const old = p.pol.filter((x) => x >= 0), nw = ty.map(() => -1), used = {};
    // 같은 종류 슬롯 먼저, 남으면 와일드카드
    for (const pi of old) { const t = POL[pi].t; const k = ty.findIndex((x, i) => x === t && nw[i] < 0); if (k >= 0) { nw[k] = pi; used[pi] = 1; } }
    for (const pi of old) { if (used[pi]) continue; const k = ty.findIndex((x, i) => x === 'W' && nw[i] < 0); if (k >= 0) { nw[k] = pi; used[pi] = 1; } }
    p.pol = nw; dirty(G);
  }
  function polAvail(G, o, pi) {
    const P2 = POL[pi]; if (!hasCivic(G, o, P2.req)) return false;
    if (P2.ob && hasCivic(G, o, POL[POLI[P2.ob]].req)) return false;
    return true;
  }
  function legacySteps(G, turns) { return Math.min(5, Math.floor((turns || 0) / Math.max(4, Math.round(10 * G.s.spT * 1.4)))); }
  function polChangeCost(G, o) { return Math.round((15 + 12 * techEra(G, o)) * G.s.spP * 2); }
  // 정책 카드 바꾸는 비용: 바뀐 카드마다(원작처럼 카드 수에 비례)
  function polSwapCost(G, o, arr) { const p = G.P[o]; let n = 0; for (let i = 0; i < arr.length; i++) if (arr[i] >= 0 && arr[i] !== p.pol[i]) n++; return n ? Math.round(polChangeCost(G, o) * (0.4 + 0.3 * n)) : 0; }
  function setPolicies(G, o, arr, pay) {
    const p = G.P[o], ty = slotTypes(G, o);
    if (!Array.isArray(arr) || arr.length !== ty.length) return false;
    const seen = {};
    for (let i = 0; i < arr.length; i++) {
      const pi = arr[i]; if (pi < 0) continue;
      if (!POL[pi] || seen[pi] || !polAvail(G, o, pi)) return false;
      seen[pi] = 1;
      const t = POL[pi].t, st = ty[i];
      if (st !== 'W' && t !== st) return false;
    }
    const changed = JSON.stringify(arr) !== JSON.stringify(p.pol);
    if (!changed) return true;
    if (!p.pf) { const c = polSwapCost(G, o, arr); if (c && (!pay || p.gold < c)) return false; p.gold -= c; }
    p.pol = arr.slice(); p.pf = 0; dirty(G);
    return true;
  }
  function setGov(G, o, gi, pay) {
    const p = G.P[o], g = GOV[gi]; if (!g || gi === p.gov) return false;
    if (g.req && !hasCivic(G, o, g.req)) return false;
    if (!p.pf && !(p.govFree && p.govFree[gi] === undefined)) { const c = polChangeCost(G, o) * 2; if (!pay || p.gold < c) return false; p.gold -= c; }
    const firstTier = !(p.govSeen || []).some((x) => x === gi);
    p.govSeen = (p.govSeen || []).concat([gi]);
    p.gov = gi; dirty(G); fitPolicies(G, o); p.pf = 1;
    if (firstTier && gi > 0) eraScore(G, o, 2, g.n + ' 채택');
    note(G, o, '🏛 정부: ' + g.n, -1, 'gov');
    return true;
  }

  /* ======================= 점수·관광·승리 ======================= */
  const LY_WIN = 10, DVP_WIN = 12;
  function scoreOf(G, o) {
    const p = G.P[o]; if (!p || p.k !== 'maj') return 0;
    let s = 0; const cs = citiesOf(G, o);
    s += cs.length * 5 + sum(cs.map((c) => c.pop));
    s += cntBits(p.tk) * 2 + cntBits(p.ck) * 2 + (p.ft || 0) * 2;
    s += Object.values(G.s.WB).filter((x) => x === o).length * 12;
    s += (p.st.gp || 0) * 4;
    if (p.rel >= 0) s += 8 + G.C.filter((c) => c.rl === p.rel && c.o !== o).length;
    s += (p.dvp || 0) * 3;
    for (const k of ['sat', 'moon', 'mars', 'exo']) if (p.sv[k]) s += 15;
    s += Math.floor((p.esT || 0) / 4);
    return s;
  }
  function tourismOf(G, o) {
    const M = mods(G, o); let t = 0;
    for (const c of citiesOf(G, o)) {
      if ((c.gw || []).length) { const GL = gwLayout(G, c); for (const sl of GL.slots) if (sl.w >= 0) t += GW_T[c.gw[sl.w].c] * (GL.themed[sl.b] ? 2 : 1); }
      for (const k of c.b) { if (k.startsWith('w:')) { t += 2; const W = WON[WONI[k.slice(2)]]; if (W && W.fx.tour) t += W.fx.tour; } const b = BLD[BLDI[k]]; if (b && b.tour) t += b.tour; }
      for (const j of cityTiles(G, c)) { const m = IMP[G.imp[j]]; if (m && m.k === 'resort' && !G.pil[j]) t += Math.max(1, appeal(G, j)); if (m && m.k === 'rockchurch' && !G.pil[j]) t += Math.max(0, appeal(G, j)); if (m && m.k === 'chemamull' && !G.pil[j]) t += Math.max(0, Math.floor(appeal(G, j) * 0.75)); if (G.feat[j] >= NW0 && hasCivic(G, o, 'conservation')) t += 2; }
      if (c.hc >= 0 && hasTech(G, o, 'flight')) t += 3;
    }
    if (hasTech(G, o, 'flight')) t *= 1.25;
    return t * (1 + mv0(M, 'tourP') / 100);
  }
  const domTourists = (G, o) => Math.floor((G.P[o].lc || 0) / 100);
  function visTourists(G, o) { const vt = G.P[o].vt || {}; let n = 0; for (const k in vt) n += vt[k]; return Math.floor(n); }
  function culWinner(G) {
    const al = aliveMaj(G); if (al.length < 2) return -1;
    for (const o of al) {
      const v = visTourists(G, o); if (v < 30) continue;
      let maxDom = 0; for (const q of al) if (q !== o) maxDom = Math.max(maxDom, domTourists(G, q));
      if (v > maxDom) return o;
    }
    return -1;
  }
  function domWinner(G) {
    const al = aliveMaj(G);
    if (al.length === 1 && G.s.nM > 1) return al[0];
    for (const o of al) {
      const caps = G.C.filter((c) => c.oc && isMaj(G, c.oo));
      if (caps.length < 2) continue;
      if (caps.every((c) => c.o === o)) return o;
    }
    return -1;
  }
  function endGame(G, w, k) { const s = G.s; if (s.ph === 'e') return; s.ph = 'e'; s.w = w; s.wk = k; noteAll(G, '🏆 ' + w.map((o) => civName(G, o)).join(', ') + ' — ' + WINN[k] + ' 승리!', -1, 'win'); }
  const WINN = { sci: '과학', cul: '문화', dom: '지배', rel: '종교', dip: '외교', score: '점수' };
  function checkVictory(G) {
    const s = G.s; if (s.ph === 'e') return;
    for (const o of aliveMaj(G)) { const p = G.P[o]; if (p.sv.exo && (p.sv.ly || 0) >= LY_WIN) return endGame(G, [o], 'sci'); }
    const d = domWinner(G); if (d >= 0) return endGame(G, [d], 'dom');
    const r = relWinner(G); if (r >= 0) return endGame(G, [r], 'rel');
    const c = culWinner(G); if (c >= 0) return endGame(G, [c], 'cul');
    for (const o of aliveMaj(G)) if ((G.P[o].dvp || 0) >= DVP_WIN) return endGame(G, [o], 'dip');
    if (s.t > s.tl) {
      let best = -1, bv = -1; for (const o of aliveMaj(G)) { const v = scoreOf(G, o); if (v > bv) { bv = v; best = o; } }
      const w = aliveMaj(G).filter((o) => scoreOf(G, o) === bv);
      return endGame(G, w.length ? w : [best], 'score');
    }
  }

  /* ======================= 턴 진행 ======================= */
  function unitMaint(G, u) { if (!isMil(u.t)) return 0; return 1 + Math.floor((UT[u.t].era || 0) / 2); }
  function bldMaint(k) { const b = BLD[BLDI[k]]; if (!b || !b.c || b.k === 'palace' || b.k === 'monument' || b.wall) return 0; return b.c >= 350 ? 2 : 1; }
  function incomeOf(G, o) {
    const p = G.P[o], M = mods(G, o);
    let y = Y0();
    for (const c of citiesOf(G, o)) yAdd(y, cityCalc(G, c).y);
    let um = 0; for (const u of G.U) if (u.o === o) um += Math.max(0, unitMaint(G, u) + (isMil(u.t) ? mv0(M, 'maint') : 0));
    let bm = 0; for (const c of citiesOf(G, o)) { for (const k of c.b) bm += bldMaint(k); for (const dk in c.d) if (DIS[DISI[dk]].lim) bm += 1; }
    const envG = M.goldEnv ? sum(G.P.filter((q) => q.k === 'cs').map((q) => q.envs[o] || 0)) * M.goldEnv : 0;
    return { y, um, bm, gold: y[2] - um - bm + envG };
  }
  function heal(G, u) {
    if (isAir(u.t)) { if (!u.a) u.hp = Math.min(100, u.hp + 20); return; }
    if (u.a || u.mvd) { if (UT[u.t].heal) u.hp = Math.min(100, u.hp + 10); return; }
    let h = 10; const ow = tileOwner(G, u.p);
    if (G.cat[u.p] >= 0 && G.cid[G.cat[u.p]].o === u.o) h = 20; else if (ow === u.o) h = 15; else if (ow >= 0 && atWar(G, ow, u.o)) h = 5;
    for (const j of G.g.nb[u.p]) { const cv = civAt(G, j); if (cv && cv.o === u.o && UT[cv.t].aura === 'medic') h += 20; const nw = nwAt(G, j); if (nw && nw.k === 'deadsea') h = 100; }
    u.hp = Math.min(100, u.hp + h);
  }
  function startTurn(G, o) {
    const s = G.s, p = G.P[o];
    if (!p.a) return;
    // 유닛
    if (s.FO) for (const u of G.U.slice()) if (u.o === o && s.FO[u.p] && !isAir(u.t)) { u.hp -= 15; if (u.hp <= 0) killUnit(G, u); }
    for (const u of G.U) {
      if (u.o !== o) continue;
      if (isMil(u.t) && u.hp < 100) heal(G, u);
      if ((u.f > 0 || u.sl) && !u.mvd && !u.a) u.f = Math.min(2, (u.f || 0) + 1);
      u.mv = maxMv(G, u) + (p.pmv > 0 && isMil(u.t) ? 2 : 0); u.a = 0; u.mvd = 0;
    }
    if (p.pmv > 0) p.pmv--;
    if (p.pcs > 0) p.pcs--;
    if (p.dpT > 0) p.dpT--;
    // 연료(발전소)
    for (const c of citiesOf(G, o)) {
      c.fuelOk = {};
      for (const k of c.b) { const b = BLD[BLDI[k]]; if (b && b.fuel) { const ri2 = RESI[b.fuel]; if ((p.stk[ri2] || 0) >= 1) { p.stk[ri2] -= 1; c.fuelOk[k] = 1; s.CL.co2 += b.co2 || 0; } } }
    }
    G.yc = {};
    // 도시
    let tot = Y0();
    for (const c of citiesOf(G, o)) {
      assignWork(G, c);
      const cc = cityCalc(G, c);
      yAdd(tot, cc.y);
      // 성장
      c.fd = (c.fd || 0) + cc.grow;
      if (c.fd >= cc.need) { c.fd -= cc.need; c.pop++; if (c.pop === 10 || c.pop === 15 || c.pop === 20) eraScore(G, o, 1, c.n + ' 인구 ' + c.pop); note(G, o, c.n + ' 인구 ' + c.pop, c.p, 'grow'); }
      else if (c.fd < 0) { if (c.pop > 1) { c.pop--; note(G, o, '⚠ ' + c.n + ': 굶주림으로 인구가 줄었어요.', c.p, 'grow'); } c.fd = 0; }
      c.fd = Math.min(c.fd, cc.need * 1.5);
      // 생산
      cityProduce(G, c, (c.unrest ? cc.y[1] * 0.5 : cc.y[1]) * (c.sab > 0 ? 0.5 : 1));
      if (c.sab > 0) c.sab--;
      if (!c.q.length && p.lv === 0) note(G, o, '🔨 ' + c.n + ': 만들 것을 고르세요.', c.p, 'prod');
      borderGrow(G, c, cc.y[4]);
      // 회복
      if (c.at > 0) c.at--; else { c.hp = Math.min(200, c.hp + 20); if (c.wl > 0) c.wh = Math.min(c.wl * 100, (c.wh || 0) + 15); }
      c.rs = 0;
      loyaltyTick(G, c);
      c.unrest = cc.mood <= -2 ? 1 : 0;
    }
    G.yc = {};
    // 금·신앙·과학·문화
    const inc = incomeOf(G, o);
    p.gold += inc.gold; p.faith += tot[5];
    p.lg = Math.round(inc.gold * 10) / 10; p.ls = tot[3]; p.lcu = tot[4]; p.lf = tot[5];
    if (p.gold < 0) {
      const mil = G.U.filter((u) => u.o === o && isMil(u.t)).sort((a, b) => unitMaint(G, b) - unitMaint(G, a));
      if (mil.length) { note(G, o, '💸 금이 모자라 ' + UT[mil[0].t].n + '을(를) 해산했어요.', mil[0].p, 'gold'); killUnit(G, mil[0]); }
      p.gold = 0;
    }
    addSci(G, o, tot[3]); addCul(G, o, tot[4]);
    // 전략 자원
    const cap = 30 + 10 * techEra(G, o) + 10 * citiesOf(G, o).filter((c) => cityHasB(c, 'armory')).length;
    const M = mods(G, o);
    for (const c of citiesOf(G, o)) for (const j of cityTiles(G, c)) {
      const r = G.res[j]; if (!r || RES[r].c !== 's' || !resVisible(G, o, r)) continue;
      if (IMP[G.imp[j]] && IMP[G.imp[j]].k === RES[r].im && !G.pil[j]) p.stk[r] = Math.min(cap, (p.stk[r] || 0) + 2 + mv0(M, 'stratX'));
    }
    if (M.stratX) for (const r of STRAT) if (resVisible(G, o, r) && (p.stk[r] || 0) > 0) p.stk[r] = Math.min(cap, p.stk[r] + 0);
    // 교역로
    for (const tr of p.tr) tr.t--;
    for (const tr of p.tr.filter((x) => x.t <= 0 || !G.cid[x.f] || !G.cid[x.d] || G.cid[x.f].o !== o)) {
      const f = G.cid[tr.f]; if (f && f.o === o) { const sp = spawnSpot(G, f.p, UTI.trader, o); if (sp >= 0) mkUnit(G, o, UTI.trader, sp); note(G, o, '🐪 교역로가 끝나 상인이 돌아왔어요.', f.p, 'trade'); }
    }
    p.tr = p.tr.filter((x) => x.t > 0 && G.cid[x.f] && G.cid[x.d] && G.cid[x.f].o === o);
    // 위인
    const gpp = gpPoints(G, o);
    for (const c2 of GPK) { p.gpp[c2] = (p.gpp[c2] || 0) + gpp[c2]; }
    // 위인: AI는 바로 영입, 사람은 「영입/포기」를 골라요(원작처럼)
    for (const c2 of GPK) if (G.s.GP.cur[c2] >= 0 && p.gpp[c2] >= gpCost(G, c2)) {
      if (p.lv > 0) claimGP(G, o, c2);
      else if (!(p.gpPass && p.gpPass[c2] === G.s.GP.cur[c2]) && !(p.gpN && p.gpN[c2] === G.s.GP.cur[c2])) { (p.gpN = p.gpN || {})[c2] = G.s.GP.cur[c2]; note(G, o, '⭐ ' + GPC[c2].n + ' ' + GPL[G.s.GP.cur[c2]].n + '을(를) 영입할 수 있어요 — 위인 화면에서 영입하거나 포기하세요.', -1, 'gpr'); }
    }
    // 남은 성유물
    if (p.rq > 0) { const c = placeGW(G, o, { c: 'rel', n: -1, e: G.s.era, o }); if (c) p.rq--; }
    // 사절
    p.ei = (p.ei || 0) + (1 + mv0(M, 'env')) * (1 + mv0(M, 'envP') / 100);
    const envNeed = Math.round(20 * Math.max(0.6, s.spT) * (1 + 0.15 * (p.envT || 0)));
    if (p.ei >= envNeed) { p.ei -= envNeed; p.env++; p.envT = (p.envT || 0) + 1; note(G, o, '✉ 사절 +1', -1, 'env'); }
    // 외교 호의
    let fav = 1 + mv0(M, 'favor') + mv0(M, 'suzN') + aliveMaj(G).filter((q) => q !== o && dipSt(G, o, q) === 3).length;
    if (G.C.some((c) => c.o === o && c.d.dq != null)) fav += 2;
    p.favor = Math.min(500, (p.favor || 0) + fav);
    // 관광
    const tour = tourismOf(G, o); p.tour = tour;
    p.vt = p.vt || {};
    const nOth = Math.max(1, aliveMaj(G).filter((q) => q !== o && met(G, o, q)).length), vScale = Math.min(1, 3 / nOth);
    for (const q of aliveMaj(G)) {
      if (q === o || !met(G, o, q)) continue;
      let f = 1; if (p.tr.some((tr) => G.cid[tr.d] && G.cid[tr.d].o === q)) f += 0.25; const st = dipSt(G, o, q); if (st >= 2) f += 0.25; if (st === 0) f -= 0.5;
      if (G.P[q].rel >= 0 && G.P[q].rel === p.rel) f += 0.15;
      p.vt[q] = (p.vt[q] || 0) + tour * f / 200 * vScale;
    }
    // 시대 점수 누적(총)
    p.esT = (p.esT || 0) + 0;
    // 총독
    for (const gv of p.gv) if (gv.est > 0) gv.est--;
    // 전쟁 피로·불만 감소
    const atw = aliveMaj(G).some((q) => q !== o && atWar(G, o, q));
    p.ww = Math.max(0, (p.ww || 0) - (atw ? 1 : 4));
    for (let k = 0; k < p.gr.length; k++) if (p.gr[k]) p.gr[k] = Math.max(0, p.gr[k] - 0.5);
    p.wm = Math.max(0, (p.wm || 0) - 0.4);
    // 만남·탐험
    exploreNow(G, o);
    checkBoosts(G, o);
    // 이동 명령(사람)
    if (p.lv === 0) for (const u of G.U.slice()) if (u.o === o && u.go != null && G.uid[u.id]) { if (u.p === u.go) { u.go = null; continue; } if (!goToward(G, u, u.go)) u.go = null; else if (u.p === u.go) u.go = null; }
    if (p.lv === 0) {
      if (p.rs < 0 && TECH.some((t, i) => techAvail(G, o, i))) note(G, o, '🔬 연구할 기술을 고르세요.', -1, 'tech');
      if (p.cs < 0 && CIVIC.some((t, i) => civicAvail(G, o, i))) note(G, o, '🎭 사회 제도를 고르세요.', -1, 'civic');
    }
    spyTick(G, o);
    p.lgT = p.lgT || {}; p.lgT[p.gov] = (p.lgT[p.gov] || 0) + 1;
    p.tn = s.t;
    checkVictory(G);
  }
  function endRound(G) {
    const s = G.s;
    s.t++;
    if (s.FO) { for (const k in s.FO) { s.FO[k]--; if (s.FO[k] <= 0) delete s.FO[k]; } }
    dealTick(G);
    csTick(G);
    fcTick(G);
    barbTick(G);
    religionTick(G);
    emergencyTick(G);
    climateTick(G);
    advanceEra(G);
    refreshGP(G);
    // 아라비아: 마지막 선지자
    if (s.R.length === maxReligions(G) - 1) for (const o of aliveMaj(G)) { const p = G.P[o]; if (mods(G, o).lastProphet && p.rel < 0 && !G.U.some((u) => u.o === o && u.t === UTI.gp && GPL[u.g].c === 'pro') && s.GP.cur.pro >= 0) { p.gpp.pro = Math.max(p.gpp.pro || 0, gpCost(G, 'pro')); claimGP(G, o, 'pro', true); } }
    // 외교 시간
    for (const k in s.D) { const r = s.D[k]; if (r.t > 0) r.t--; if (r.s === 2 && r.df != null) { r.df--; if (r.df <= 0) { r.s = 1; const [a, b] = k.split(',').map(Number); note(G, a, '🤝 ' + civName(G, b) + '와 친선 기간이 끝났어요.', -1, 'dip'); note(G, b, '🤝 ' + civName(G, a) + '와 친선 기간이 끝났어요.', -1, 'dip'); } } }
    s.Q = s.Q.filter((q) => s.t - q.at <= 2 && G.P[q.f].a && G.P[q.t].a);
    // 세계 의회
    if (s.era >= 2 && s.WC.nx < 0) s.WC.nx = s.t + 4;
    if (s.WC.nx >= 0) {
      if (!s.WC.pend && s.t >= s.WC.nx - 1) congressSetup(G);
      else if (s.WC.pend && s.t >= s.WC.nx) { congressResolve(G); s.WC.nx = s.t + Math.max(14, Math.round(40 * s.spP)); }
    }
    // 우주 탐사선
    for (const o of aliveMaj(G)) { const p = G.P[o]; if (p.sv.exo && G.C.some((c) => c.o === o && c.d.sp != null)) p.sv.ly = (p.sv.ly || 0) + 1 + (p.sv.las || 0); }
    checkVictory(G);
  }
  function nextAlive(G, from) { const n = G.s.nM; for (let k = 1; k <= n; k++) { const o = (from + k) % n; if (G.P[o].a) return o; } return from; }
  function endTurn(G) {
    const s = G.s, o = s.cur;
    for (const u of G.U) if (u.o === o && u.sl == null) { /* 그대로 */ }
    let nx = nextAlive(G, o);
    if (nx <= o) endRound(G);
    if (s.ph === 'e') return;
    nx = G.P[nx].a ? nx : nextAlive(G, nx);
    s.cur = nx;
    startTurn(G, nx);
  }

  /* ======================= 판 만들기 ======================= */
  const SPEEDS = [{ n: '번개', sp: 0.34, tl: 130 }, { n: '빠름', sp: 0.5, tl: 180 }, { n: '보통', sp: 0.72, tl: 250 }];
  // 문명 고르기 단계(판 시작 전): 사람 자리는 직접 고르고, AI 자리는 바로 골라요.
  function civTaken(s, k, seat) { const c = CIVS[k].c; return s.pk.some((x, o) => o !== seat && x >= 0 && CIVS[x].c === c); }
  function randomCiv(s, seat) {
    const free = CIVS.map((c, i) => i).filter((i) => !civTaken(s, i, seat));
    const pool = free.length ? free : CIVS.map((c, i) => i);
    return pool[ri(pool.length)];
  }
  function init(players, opts) {
    opts = opts || {};
    const nM = players.length;
    const s = { v: 2, ph: 'k', nM, t: 0, cur: -1, pk: new Array(nM).fill(-1), pl: players.map((p) => ({ ai: p.ai ? 1 : 0, lv: p.ai ? (p.lv || 2) : 0 })), op: {}, nd: opts.dup === 1 || opts.dup === '1' ? 0 : 1, L: { id: 0, e: [] }, P: [], C: [], U: [], w: [] };
    for (const o of ['map', 'size', 'speed', 'cs', 'diff', 'barb', 'dis', 'wrap', 'huts']) if (opts[o] != null) s.op[o] = opts[o];
    // 같은 문명 한 자리만(nd): AI는 사람이 전원 고른 뒤(또는 방장 「지금 시작」) 남은 문명 중에서 고른다. 여럿 허용이면 바로 고른다.
    const anyHuman = s.pl.some((pl) => !pl.ai);
    if (!s.nd || !anyHuman) for (let o = 0; o < nM; o++) if (s.pl[o].ai) s.pk[o] = s.nd ? randomCiv(s, o) : ri(CIVS.length);
    if (s.pk.every((x) => x >= 0)) return startGame(s);
    return s;
  }
  function fillAIPicks(s) { for (let o = 0; o < s.nM; o++) if (s.pl[o].ai && s.pk[o] < 0) s.pk[o] = s.nd ? randomCiv(s, o) : ri(CIVS.length); }
  function pickAct(s, seat, a) {
    if (a.t === 'pick') {
      const k = a.k === 'r' ? randomCiv(s, seat) : +a.k;
      if (!(k >= 0 && k < CIVS.length)) throw new Error('civ');
      if (s.nd && civTaken(s, k, seat)) throw new Error('taken');
      s.pk[seat] = k;
    } else if (a.t === 'unpick') { if (s.pl[seat].ai) throw new Error('ai'); s.pk[seat] = -1; }
    else if (a.t === 'go') throw new Error('illegal go');   // 「지금 시작」은 방장 기기의 pickBar onForce로만
    else throw new Error('pick phase');
    s.L = { id: s.L.id + 1, e: [] };
    if (s.pl.every((pl, o) => pl.ai || s.pk[o] >= 0)) { fillAIPicks(s); if (s.pk.every((x) => x >= 0)) return startGame(s); }
    return s;
  }
  function forceStart(s) { // 안 고른 사람 자리 먼저, 그다음 AI 자리가 남은 문명 중에서
    for (let o = 0; o < s.nM; o++) if (!s.pl[o].ai && s.pk[o] < 0) s.pk[o] = s.nd ? randomCiv(s, o) : ri(CIVS.length);
    fillAIPicks(s); s.L = { id: s.L.id + 1, e: [] }; return startGame(s);
  }
  function startGame(s0) {
    const opts = s0.op || {}, players = s0.pl, nM = s0.nM;
    const sizeI = opts.size === 'a' || opts.size == null ? (nM <= 3 ? 0 : nM <= 5 ? 1 : 2) : +opts.size;
    const mtype = opts.map === 'r' || opts.map == null ? ri(MAPT.length) : +opts.map;
    const spd = SPEEDS[opts.speed == null ? 1 : +opts.speed] || SPEEDS[1];
    const Z = MAPS[sizeI];
    const nCS = opts.cs === 'a' || opts.cs == null ? Math.round(Z.W * Z.H / 170) : +opts.cs;
    const seed = (Math.random() * 2147483647) | 0;
    const wr = opts.wrap === 0 || opts.wrap === '0' ? 0 : 1;
    const m = genMap(seed, Z.W, Z.H, mtype, nM, nCS, Z.nw, wr);
    const N = Z.W * Z.H, g = geo(Z.W, Z.H, wr);
    const s = {
      v: 2, W: Z.W, H: Z.H, wr, mtp: mtype, msz: sizeI, spd: opts.speed == null ? 1 : +opts.speed, spP: spd.sp, spT: Math.round(spd.sp * 57) / 100, tl: spd.tl, t: 1, cur: 0, nM, ph: 'p',
      df: +(opts.diff || 0), barb: opts.barb === 0 || opts.barb === '0' ? 0 : 1, dis: opts.dis == null ? 1 : +opts.dis,
      mt: '', mf: '', mr: '', ml: '', im: '', rd: '', ds: '', wn: '', fy: '', ow: '', ex: [], lc: '',
      P: [], C: [], U: [], R: [], WB: {}, GP: { cur: {}, used: [], n: {} }, WC: { nx: -1, pend: null, act: [], last: [] },
      CL: { co2: 0, st: 0, sea: 0 }, EM: [], D: {}, Q: [], fe: {}, era: 0, eraT: 1,
      L: { id: 0, e: [] }, q: 1, w: [], wk: '', BB: -1,
    };
    // 지도 문자열
    const mt = new Uint8Array(N); for (let i = 0; i < N; i++) mt[i] = m.ter[i] | (m.hill[i] << 4) | (m.riv[i] << 5);
    s.mt = encStr(mt); s.mf = encStr(m.feat); s.mr = encStr(m.res); s.ml = encStr(m.low); s.re = encStr(m.re);
    const zero = encStr(new Uint8Array(N)); s.im = zero; s.rd = zero; s.ds = zero; s.wn = {}; s.fy = {};
    let ow = ''; for (let i = 0; i < N; i++) ow += 'AA'; s.ow = ow;
    const lcA = new Uint8Array(N); for (let i = 0; i < N; i++) lcA[i] = m.lcomp[i] >= 0 ? (m.lcomp[i] % 62) + 1 : 0; s.lc = encStr(lcA);
    // 나라
    const nP = nM + m.csStarts.length + 2;
    const metZ = '0'.repeat(nP);
    for (let o = 0; o < nM; o++) {
      s.P.push({ o, k: 'maj', civ: s0.pk[o], a: 1, lv: players[o].ai ? (players[o].lv || 2) : 0,
        tk: '0'.repeat(TECH.length), tb: '0'.repeat(TECH.length), tp: {}, rs: -1, ck: '0'.repeat(CIVIC.length), cb: '0'.repeat(CIVIC.length), cp: {}, cs: -1,
        gov: 0, pol: [-1, -1], pf: 1, gold: 10, faith: 0, gpp: {}, rel: -1, pan: -1, env: 0, ei: 0, es: 0, esT: 0, age: 1, ded: -1, ded2: -1, dsel: 0, me: 0,
        dvp: 0, favor: 0, stk: {}, lc: 0, vt: {}, st: {}, met: bitSet(metZ, o), gr: new Array(nP).fill(0), wm: 0, ww: 0, gt: 0, gv: [], nt: [], sv: {}, setc: 0, bldc: 0, tr: [], opr: {} });
      s.ex.push(encBits(new Uint8Array(N)));
    }
    const G = ctx(s);
    G.lc = decStr(s.lc, N);
    // 도시국가
    const csOrder = CSL.map((c, i) => i).sort(() => Math.random() - 0.5);
    for (let k = 0; k < m.csStarts.length; k++) {
      const o = nM + k;
      G.P.push({ o, k: 'cs', cs: csOrder[k % CSL.length], a: 1, envs: {}, suz: -1, met: bitSet(metZ, o) });
      foundCity(G, o, m.csStarts[k]);
      const sp = spawnSpot(G, m.csStarts[k], UTI.warrior, o); if (sp >= 0) mkUnit(G, o, UTI.warrior, sp);
    }
    s.BB = G.P.length;
    G.P.push({ o: s.BB, k: 'bb', a: 1, met: metZ });
    s.FC = G.P.length;
    G.P.push({ o: s.FC, k: 'fc', a: 1, met: metZ });
    // 부족 마을
    if (opts.huts !== 0 && opts.huts !== '0') {
      const nH = Math.round(N / 55), placed = [];
      for (let tr = 0; tr < nH * 30 && placed.length < nH; tr++) {
        const i = ri(N);
        if (!passableLand(G, i) || G.res[i] || G.imp[i] || G.own[i] >= 0 || G.feat[i] >= NW0) continue;
        if (m.starts.some((q) => hexDist(G.g, q, i) < 4) || m.csStarts.some((q) => hexDist(G.g, q, i) < 3) || placed.some((q) => hexDist(G.g, q, i) < 4)) continue;
        G.imp[i] = IMPI.goody; placed.push(i);
      }
    }
    s.BC = {}; s.AS = {};
    for (let k = 0, n2 = Math.round(N / 140); k < n2 * 20 && Object.keys(s.AS).length < n2; k++) { const i = ri(N); if (G.own[i] < 0 && !m.starts.some((q) => hexDist(G.g, q, i) < 3)) markAntiquity(G, i, ri(2), -2 - k); }
    // 시작 유닛
    for (let o = 0; o < nM; o++) {
      const st = m.starts[o];
      mkUnit(G, o, UTI.settler, st);
      const w = spawnSpot(G, st, UTI.warrior, o); if (w >= 0) mkUnit(G, o, UTI[unitFor(G, o, 'warrior')], w);
      if (s.P[o].lv > 0 && s.df >= 2) { const w2 = spawnSpot(G, st, UTI.warrior, o); if (w2 >= 0) mkUnit(G, o, UTI[unitFor(G, o, 'warrior')], w2); }
      if (s.P[o].lv > 0 && s.df >= 3) { const b = spawnSpot(G, st, UTI.builder, o); if (b >= 0) mkUnit(G, o, UTI.builder, b); const s2 = within(G.g, st, 3).find((j) => passableLand(G, j) && !civAt(G, j) && !milAt(G, j) && hexDist(G.g, j, st) >= 2); if (s2 != null) mkUnit(G, o, UTI.settler, s2); }
      reveal(G, o, st, 3);
    }
    refreshGP(G);
    s.L = { id: (s0.L ? s0.L.id : 0) + 1, e: [] };
    startTurn(G, 0);
    commit(G);
    return s;
  }

  /* ======================= AI ======================= */
  // 기술/제도가 여는 것
  const UNLOCK = {};
  function unlockAdd(req, x) { if (!req) return; (UNLOCK[req] = UNLOCK[req] || []).push(x); }
  UT.forEach((T, i) => { if (T.req) unlockAdd(T.req, { t: 'u', i }); });
  BLD.forEach((b, i) => { if (b.req) unlockAdd(b.req, { t: 'b', i }); });
  DIS.forEach((d, i) => { if (d && d.req) unlockAdd(d.req, { t: 'd', i }); });
  WON.forEach((w, i) => unlockAdd(w.req, { t: 'w', i }));
  IMP.forEach((m, i) => { if (m && m.tech) unlockAdd((m.civic ? 'c:' : '') + m.tech, { t: 'i', i }); });
  GOV.forEach((g, i) => { if (g.req) unlockAdd('c:' + g.req, { t: 'g', i }); });
  POL.forEach((pp, i) => unlockAdd('c:' + pp.req, { t: 'p', i }));
  PRJ.forEach((pp, i) => { if (pp.req) unlockAdd(pp.req, { t: 'j', i }); });
  RES.forEach((r, i) => { if (r && r.rv) unlockAdd(r.rv, { t: 'r', i }); });

  function aiX(G, o, lv) {
    const p = G.P[o], ag = CIVS[p.civ].ag;
    const wars = aliveMaj(G).filter((q) => q !== o && atWar(G, o, q));
    const csWars = G.P.filter((q) => q.k === 'cs' && q.a && atWar(G, o, q.o)).map((q) => q.o);
    const cs = citiesOf(G, o);
    const want = Math.max(2, Math.round((G.s.msz === 0 ? 5 : G.s.msz === 1 ? 7 : 9) * (0.85 + 0.1 * (ag.exp || 0)) + (lv === 1 ? -2 : lv === 3 ? 2 : 0)));
    // 어려움: 시대 중반부터 이길 수 있는 승리 쪽으로 힘을 모아요
    let focus = '';
    if (lv >= 3 && G.s.era >= 2) {
      const al = aliveMaj(G), rk = (f) => al.filter((q) => q !== o && f(q) > f(o)).length;
      const relN = p.rel >= 0 ? al.filter((q) => { const cs2 = citiesOf(G, q); return cs2.length && cs2.filter((c) => c.rl === p.rel).length * 2 > cs2.length; }).length : 0;
      if (p.rel >= 0 && relN * 2 >= al.length) focus = 'rel';
      else if (rk((q) => milPower(G, q)) === 0 && milPower(G, o) > 1.6 * Math.max(1, ...al.filter((q) => q !== o).map((q) => milPower(G, q)))) focus = 'dom';
      else if (rk((q) => cntBits(G.P[q].tk)) === 0) focus = 'sci';
      else if (rk((q) => tourismOf(G, q)) === 0) focus = 'cul';
      else focus = 'sci';
    }
    const fcT = G.s.FC != null && lv >= 2 && G.C.some((c) => c.o === G.s.FC && cs.some((m) => hexDist(G.g, m.p, c.p) <= 8));
    const ag2 = focus ? Object.assign({}, ag, { [focus === 'dom' ? 'war' : focus]: Math.max(ag[focus === 'dom' ? 'war' : focus] || 0, 2) + 1 }) : ag;
    return { o, lv, p, ag: ag2, wars, csWars, cs, want, era: techEra(G, o), sci: (ag2.sci || 0), late: G.s.era >= 5, fcT, focus };
  }
  function nz(X, amt) { return (Math.random() - 0.5) * amt * (X.lv === 1 ? 3 : X.lv === 2 ? 1.1 : 0.3); }
  function unlockVal(G, X, list) {
    let v = 0;
    for (const x of list || []) {
      if (x.t === 'd') { const k = DIS[x.i].k; v += { cam: 3 + X.sci, hs: G.s.era < 2 ? 2 + (X.ag.rel || 0) : 0.5, com: 2.5 + (X.ag.gold || 0) * 0.5, th: 2 + (X.ag.cul || 0) * 0.6, ind: 2.6, hb: 1.2, enc: 1 + (X.ag.war || 0) * 0.5, ent: 1.5, aq: 1.5, nb: 1.5, sp: X.sci + 2, gov: 2, dq: 1, dam: 0.5, can: 0.3, wp: 0.6 }[k] || 0.5; }
      else if (x.t === 'b') v += BLD[x.i].civ && BLD[x.i].civ !== civK(G, X.o) ? 0 : 1 + (BLD[x.i].y ? sum(BLD[x.i].y) * 0.15 : 0);
      else if (x.t === 'u') { const T = UT[x.i]; if (T.civ && T.civ !== civK(G, X.o)) continue; v += isMil(x.i) ? (X.wars.length ? 1.6 : 0.5) * (1 + (X.ag.war || 0) * 0.3) : T.k === 'trader' ? 1.5 : 0.3; }
      else if (x.t === 'w') v += 0.5 + (X.ag.won || 0) * 0.5;
      else if (x.t === 'g') v += 3;
      else if (x.t === 'p') v += 0.5;
      else if (x.t === 'j') v += PRJ[x.i].sv ? 4 + X.sci * 2 : 0.3;
      else if (x.t === 'r') v += 1;
      else if (x.t === 'i') v += 0.6;
    }
    return v;
  }
  function aiResearch(G, X) {
    const p = X.p, o = X.o;
    if (p.rs >= 0) return;
    let best = -1, bv = -1e9;
    for (let i = 0; i < TECH.length; i++) {
      if (!techAvail(G, o, i)) continue;
      const T = TECH[i];
      let v = X.lv === 1 ? -T.e * 4 + R() * 6 : -T.e * 4 + unlockVal(G, X, UNLOCK[T.k]) + (bitHas(p.tb, i) ? 5 : 0) + (p.tp[i] ? 2 : 0) + nz(X, 4);
      if (X.late && ['rocketry', 'satellites', 'nanotech', 'robotics', 'lasers', 'composites', 'synthetic', 'plastics', 'computers', 'fission', 'combinedArms', 'advFlight'].indexOf(T.k) >= 0) v += 3 + X.sci * 1.5;
      if (T.k === 'future') v -= 10;
      if (v > bv) { bv = v; best = i; }
    }
    p.rs = best;
  }
  function aiCivic(G, X) {
    const p = X.p, o = X.o;
    if (p.cs >= 0) return;
    let best = -1, bv = -1e9;
    for (let i = 0; i < CIVIC.length; i++) {
      if (!civicAvail(G, o, i)) continue;
      const C2 = CIVIC[i];
      let v = -C2.e * 4 + unlockVal(G, X, UNLOCK['c:' + C2.k]) * (X.lv === 1 ? 0.3 : 1) + (bitHas(p.cb, i) ? 5 : 0) + (p.cp[i] ? 2 : 0) + nz(X, 4);
      if (TITLE_CIVICS.indexOf(C2.k) >= 0) v += 1.5;
      if (C2.k === 'futureCiv') v -= 10;
      if (v > bv) { bv = v; best = i; }
    }
    p.cs = best;
  }
  function polValue(G, X, pi) {
    const fx = POL[pi].fx, cs = X.cs, n = cs.length || 1;
    const cnt = (dk) => cs.filter((c) => c.d[dk] != null).length;
    let v = 0.2;
    if (fx.y) v += sum(fx.y) * n * 0.9;
    if (fx.cy) v += sum(fx.cy) * 0.9;
    if (fx.adj) for (const k in fx.adj) v += cs.filter((c) => c.d[k] != null).reduce((a, c) => a + adjBonus(G, X.o, c.d[k], k), 0) * 0.9;
    if (fx.bm) for (const k in fx.bm) v += cnt(k) * 1.6;
    if (fx.pm) { const busy = cs.filter((c) => c.q[0] && c.q[0].t === 'u' && fx.pm[0].indexOf(UT[UTI[c.q[0].k]].cl) >= 0).length; v += busy * 2 + (X.wars.length ? 1 : 0); }
    if (fx.pmk) { if (fx.pmk.settler) v += cs.length < X.want ? 3 : 0.2; if (fx.pmk.builder) v += 1.2; }
    if (fx.pmw) v += cs.filter((c) => c.q.some((q) => q.t === 'w')).length * 2;
    if (fx.gpp) v += sum(Object.values(fx.gpp)) * 0.8;
    if (fx.trg) v += X.p.tr.length * fx.trg * 0.5;
    if (fx.chg) v += 1.4;
    if (fx.housD2) v += cs.filter((c) => distCount(c) >= 2).length * 0.8;
    if (fx.housD3) v += cs.filter((c) => distCount(c) >= 3).length * 0.8;
    if (fx.amenGar || fx.amenD3) v += n * 0.4;
    if (fx.maint) v += G.U.filter((u) => u.o === X.o && isMil(u.t)).length * 0.6;
    if (fx.csBarb) v += G.s.era < 2 ? 0.8 : 0.1;
    if (fx.cityCS || fx.wallP) v += X.wars.length ? 1.5 : 0.3;
    if (fx.env) v += fx.env * 0.8; if (fx.favor) v += fx.favor * 0.5; if (fx.goldEnv) v += 1;
    if (fx.loy || fx.loyGov) v += 0.8;
    if (fx.tileP) v += 0.4;
    if (fx.growthP) v += n * 0.3;
    if (fx.raj) v += (mods(G, X.o).suzN || 0) * 3;
    if (fx.upgP) v += 0.3;
    if (fx.mv || fx.cs) v += X.wars.length ? 2.5 : 0.4;
    if (fx.dy) v += cnt('enc') * 1.6;
    if (fx.xpr) v += G.s.era < 1 ? 0.6 : 0;
    return v;
  }
  function aiGov(G, X) {
    const p = X.p, o = X.o;
    // 정부
    let bg = p.gov, bv = -1e9;
    for (let i = 0; i < GOV.length; i++) {
      const g = GOV[i]; if (g.req && !hasCivic(G, o, g.req)) continue;
      let v = sum(g.sl) * 3 + (i === p.gov ? 1.5 : 0);
      if (g.k === 'oligarchy' || g.k === 'fascism' || g.k === 'monarchy') v += (X.ag.war || 0) * 1.2 + (X.wars.length ? 2 : 0);
      if (g.k === 'republic' || g.k === 'democracy') v += (X.ag.sci || 0) + (X.ag.cul || 0) * 0.8;
      if (g.k === 'merchant') v += (X.ag.gold || 0) * 1.2 + 1;
      if (g.k === 'theocracy') v += (X.ag.rel || 0) * 1.5 - 1;
      if (g.k === 'communism') v += 1;
      if (v > bv) { bv = v; bg = i; }
    }
    if (bg !== p.gov && (p.pf || p.gold > polChangeCost(G, o) * 4) && (X.lv > 1 || R() < 0.25)) setGov(G, o, bg, true);
    // 정책
    if (!p.pf && !(p.gold > polChangeCost(G, o) * 6 && R() < 0.1)) return;
    const ty = slotTypes(G, o), arr = ty.map(() => -1), used = {};
    const cards = POL.map((pp, i) => i).filter((i) => polAvail(G, o, i)).map((i) => ({ i, v: X.lv === 1 ? R() : polValue(G, X, i) + nz(X, 1) })).sort((a, b) => b.v - a.v);
    for (let k = 0; k < ty.length; k++) if (ty[k] !== 'W') { const c = cards.find((x) => !used[x.i] && POL[x.i].t === ty[k]); if (c) { arr[k] = c.i; used[c.i] = 1; } }
    for (let k = 0; k < ty.length; k++) if (ty[k] === 'W') { const c = cards.find((x) => !used[x.i]); if (c) { arr[k] = c.i; used[c.i] = 1; } }
    setPolicies(G, o, arr, true);
  }
  function aiReligion(G, X) {
    const p = X.p, o = X.o;
    if (p.pan < 0 && p.faith >= panCost(G)) {
      const t = panTaken(G); const opts = PANTH.map((x, i) => i).filter((i) => !t[i]);
      if (opts.length) {
        const val = (i) => { const fx = PANTH[i].fx; let v = R() * 2; if (fx.adjT) v += 2; if (fx.timp) { const k = Object.keys(fx.timp)[0]; v += X.cs.reduce((a, c) => a + cityTiles(G, c).filter((j) => IMP[G.imp[j]] && IMP[G.imp[j]].k === k).length, 0) * 0.8; } if (fx.growthP) v += 2; if (fx.gpp) v += 2; if (fx.pmw) v += (X.ag.won || 0) * 1.5; if (fx.pm) v += (X.ag.war || 0) * 1.2; return v; };
        opts.sort((a, b) => val(b) - val(a)); foundPantheon(G, o, opts[0]);
      }
    }
    if (p.rel >= 0 && !G.s.R[p.rel].en && p.faith >= enhanceCost(G) && G.s.R[p.rel].f === o) {
      const t = belTaken(G);
      const w = BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === 'W' && !t[i]), e = BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === 'E' && !t[i]);
      if (w.length && e.length) enhanceReligion(G, o, pickR(w), pickR(e));
    }
  }
  function aiReligionPick(G, o) {
    const t = belTaken(G), used = {}; for (const r of G.s.R) used[r.i] = 1;
    const n = RELN.map((x, i) => i).filter((i) => !used[i]);
    const f = BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === 'F' && !t[i]), oo = BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === 'O' && !t[i]);
    if (!n.length || !f.length || !oo.length) return null;
    return { n: pickR(n), f: pickR(f), o: pickR(oo) };
  }
  function aiGovernors(G, X) {
    const p = X.p, o = X.o;
    let guard = 0;
    while (p.gt > 0 && guard++ < 4) {
      const free = GOVR.map((g, i) => i).filter((i) => !p.gv.some((x) => x.g === i));
      const pref = [X.ag.sci ? 0 : -1, 1, X.ag.gold ? 2 : -1, 4, 5, 6, 3, 0, 2].filter((i) => i >= 0 && free.indexOf(i) >= 0);
      if (p.gv.length < 3 && pref.length) govAppoint(G, o, pref[0]);
      else { const gv = p.gv.find((x) => x.pr < 2); if (gv) govPromote(G, o, gv.g); else if (pref.length) govAppoint(G, o, pref[0]); else break; }
    }
    for (const gv of p.gv) {
      if (gv.c >= 0 && G.cid[gv.c] && G.cid[gv.c].o === o) continue;
      // 충성도가 낮은 도시 → 큰 도시
      const cs = X.cs.filter((c) => c.gv < 0).sort((a, b) => (a.lo - b.lo) * 2 + (b.pop - a.pop));
      if (cs.length) govAssign(G, o, gv.g, cs[0].id);
    }
  }
  function aiEnvoys(G, X) {
    const p = X.p, o = X.o;
    let guard = 0;
    while (p.env > 0 && guard++ < 10) {
      let best = -1, bv = -1e9;
      for (const q of G.P) {
        if (q.k !== 'cs' || !q.a || !met(G, o, q.o) || atWar(G, o, q.o)) continue;
        const mine = q.envs[o] || 0; let top = 0; for (const k in q.envs) if (+k !== o) top = Math.max(top, q.envs[k]);
        const T = CSL[q.cs].t;
        let v = R() * 2 + (mine === 0 || mine === 2 || mine === 5 ? 2 : 0) + (mine + 1 > top && mine + 1 >= 3 ? 4 : 0) + (q.suz === o && mine - top <= 1 ? 3 : 0);
        v += T === 'sci' ? X.sci : T === 'cul' ? (X.ag.cul || 0) : T === 'rel' ? (X.ag.rel || 0) : T === 'mil' ? (X.ag.war || 0) : T === 'trd' ? (X.ag.gold || 0) : 0.8;
        if (v > bv) { bv = v; best = q.o; }
      }
      if (best < 0 || !sendEnvoy(G, o, best)) break;
    }
  }
  function aiDiplomacy(G, X) {
    const o = X.o, p = X.p, lv = X.lv, s = G.s;
    const myP = milPower(G, o);
    for (const q of aliveMaj(G)) {
      if (q === o || !met(G, o, q)) continue;
      const st = dipSt(G, o, q), op = opinion(G, o, q), theirP = milPower(G, q);
      if (st >= 1 && !(G.P[q].lv > 0) && R() < 0.04) {   // 가끔 사람 지도자에게 한마디(국경 긴장·안부)
        const ls = (s.DLG || []).filter((d) => d.f === o && d.t === q).pop();
        if (!ls || s.t - ls.n > 12 * s.spT) {
          const close = op < 5 && G.C.some((c) => c.o === o && G.C.some((c2) => c2.o === q && hexDist(G.g, c.p, c2.p) <= 5));
          say(G, o, q, close ? 'border' : op >= 15 ? 'mood_f' : op <= -12 ? 'mood_h' : 'mood_n');
        }
      }
      if (st === 0) {
        if (canPropose(G, o, q, 'peace')) {
          const r = dipRec(G, o, q), dur = s.t - (r.wt || 0);
          const losing = theirP > myP * 1.2, stale = dur > (lv >= 3 ? 12 : 20) * s.spT + (lv >= 3 ? 6 : 10) && !G.C.some((c) => c.o === o && c.oo === q && c.ft < s.t);
          if ((losing || stale || (p.ww || 0) > 150) && R() < 0.5) { if (G.P[q].lv > 0) propose(G, o, q, 'peace'); else if (!s.Q.some((x) => x.f === o && x.t === q)) propose(G, o, q, 'peace'); }
        }
        continue;
      }
      if (st === 1 && op >= 15 && canPropose(G, o, q, 'dof') && R() < 0.25) { if (G.P[q].lv > 0) propose(G, o, q, 'dof'); else if (R() < 0.3 && !s.Q.some((x) => x.f === o && x.t === q)) propose(G, o, q, 'dof'); }
      if (st === 2 && op >= 32 && canPropose(G, o, q, 'ally') && R() < 0.2 && G.P[q].lv > 0) propose(G, o, q, 'ally');
      if (st === 1 && op <= -35 && canPropose(G, o, q, 'den') && R() < 0.08) propose(G, o, q, 'den');
    }
    // 전쟁 선포(지배 성향 지도자는 힘이 조금만 앞서도 쳐들어가요)
    if (X.wars.length >= 1) return;
    const war = X.ag.war || 0;
    if (s.t < Math.round((war >= 2 ? 18 : 28) * s.spT) + 6) return;
    const warlike = war + (lv - 2) * 0.5 + (X.late && domWinnerClose(G, o) ? 2 : 0);
    const thr = war >= 3 ? (lv >= 3 ? 1.3 : lv === 2 ? 1.2 : 1.6) : war >= 2 ? (lv >= 3 ? 1.5 : lv === 2 ? 1.4 : 2) : (lv >= 3 ? 1.9 : lv === 2 ? 1.7 : 2.6);
    if (lv >= 2 && (war < 2 || lv >= 3) && !G.U.some((u) => u.o === o && UT[u.t].cl === 'sg') && !UT.some((T) => T.cl === 'sg' && hasReq(G, o, T.req))) return;
    const weakN = aliveMaj(G).some((q) => q !== o && met(G, o, q) && dipSt(G, o, q) < 2 && myP > (milPower(G, q) + 1) * 2.2 && nearestCityDist(G, o, q) <= 10);
    const chance = (0.02 + warlike * (war >= 2 ? 0.035 : 0.018) + (lv >= 3 && weakN ? 0.03 : 0)) * (X.ag.peace ? 0.4 : 1) * (lv === 1 ? 0.5 : lv === 2 ? 0.8 : 1);
    if (R() > chance) return;
    let best = -1, bv = -1e9;
    const sail = hasTech(G, o, 'shipbuilding') && lv >= 2;
    for (const q of aliveMaj(G)) {
      if (q === o || !met(G, o, q) || !canPropose(G, o, q, 'war')) continue;
      const st = dipSt(G, o, q); if (st >= 2) continue;
      const theirP = milPower(G, q) + 1;
      if (myP / theirP < thr) continue;
      let near = nearestCityDist(G, o, q);
      if (near > 12 && sail) { let d2 = 99; for (const c of G.C) if (c.o === o) for (const e of G.C) if (e.o === q) d2 = Math.min(d2, hexDist(G.g, c.p, e.p)); if (d2 <= 16) near = d2 + 4; }
      if (near > (sail ? 20 : 12)) continue;
      const v = myP / theirP - opinion(G, o, q) * 0.03 - near * 0.1 + R() + (war >= 2 && G.C.some((c) => c.o === q && c.oc) ? 0.5 : 0);
      if (v > bv) { bv = v; best = q; }
    }
    if (best < 0 && (X.ag.war || 0) >= 2 && R() < 0.3) {
      for (const q of G.P) if (q.k === 'cs' && q.a && met(G, o, q.o) && q.suz !== o && nearestCityDist(G, o, q.o) <= 7 && canPropose(G, o, q.o, 'war')) { best = q.o; break; }
    }
    if (best >= 0) { declareWar(G, o, best); X.wars.push(best); }
  }
  function domWinnerClose(G, o) { const caps = G.C.filter((c) => c.oc && isMaj(G, c.oo)); return caps.filter((c) => c.o === o).length >= caps.length - 2 && caps.length >= 3; }
  function nearestCityDist(G, a, b) { let d = 99; for (const c of G.C) if (c.o === a) for (const e of G.C) if (e.o === b && G.lc[c.p] && G.lc[c.p] === G.lc[e.p]) d = Math.min(d, hexDist(G.g, c.p, e.p)); return d; }

  /* ----- AI 도시 ----- */
  function siteScore(G, o, i) {
    if (!passableLand(G, i) || G.feat[i] >= NW0 || G.feat[i] === F_VOLC || G.dis[i]) return -99;
    const ow = tileOwner(G, i); if (ow >= 0 && ow !== o) return -99;
    let near = 99, own = 99;
    for (const c of G.C) { const d = hexDist(G.g, c.p, i); if (d < 4) return -99; near = Math.min(near, d); if (c.o === o) own = Math.min(own, d); }
    let s = 0;
    for (const j of within(G.g, i, 2)) {
      const ow2 = tileOwner(G, j); if (ow2 >= 0 && ow2 !== o) continue;
      if (G.ter[j] === TM) { s += 0.4; continue; }
      const y = tileYield(G, j, o); s += y[0] * 1.2 + y[1] * 1.0 + y[2] * 0.3 + (y[3] + y[4] + y[5]) * 0.5;
      if (G.res[j]) s += RES[G.res[j]].c === 'l' ? 2.5 : RES[G.res[j]].c === 's' ? 1.5 : 1;
      if (G.ter[j] === TO) s -= 0.8; if (G.ter[j] === TS) s -= 1;
    }
    if (freshWater(G, i)) s += 6; else if (coastal(G, i)) s += 3;
    if (G.hill[i]) s += 1.5;
    if (G.ter[i] === TD && !G.riv[i]) s -= 4; if (G.ter[i] === TT || G.ter[i] === TS) s -= 4;
    if (own < 99) s -= Math.max(0, own - 5) * 2.5;
    if (near <= 4) s -= 3;
    return s;
  }
  function aiSettler(G, X, u) {
    const o = X.o;
    if (!X.cs.length && canFound(G, u)) { const sc = siteScore(G, o, u.p); let better = false; for (const j of G.g.nb[u.p]) if (siteScore(G, o, j) > sc + 3) better = true; if (!better || u.idle > 0) { foundCity(G, o, u.p); killUnit(G, u); return; } }
    if (u.tg != null && siteScore(G, o, u.tg) < -50) u.tg = null;
    if (u.tg == null) {
      let best = -1, bv = -1e9;
      for (const j of within(G.g, u.p, X.cs.length ? 10 : 3)) {
        const v = siteScore(G, o, j) - hexDist(G.g, u.p, j) * (X.cs.length ? 0.8 : 2.5) + nz(X, 2);
        if (v > bv) { bv = v; best = j; }
      }
      if (best >= 0 && bv > -40) u.tg = best;
    }
    if (u.tg == null) { u.idle = (u.idle || 0) + 1; if (canFound(G, u) && u.idle > 3) { foundCity(G, o, u.p); killUnit(G, u); } else { const R2 = reach(G, u); const ks = Object.keys(R2.r); if (ks.length) moveUnit(G, u, +pickR(ks)); } return; }
    if (u.p === u.tg) { if (canFound(G, u)) { foundCity(G, o, u.p); killUnit(G, u); } else u.tg = null; return; }
    // 위험하면 기다리기
    if (!goToward(G, u, u.tg)) { u.tg = null; u.idle = (u.idle || 0) + 1; }
    if (G.uid[u.id] && u.p === u.tg && canFound(G, u)) { foundCity(G, o, u.p); killUnit(G, u); }
  }
  function impGain(G, o, j, k) {
    const before = tileYield(G, j, o);
    const sv = [G.imp[j], G.pil[j], G.feat[j]];
    G.imp[j] = k; G.pil[j] = 0;
    const m = IMP[k]; if ((G.feat[j] === F_WOODS || G.feat[j] === F_RAIN || G.feat[j] === F_MARSH) && !(m.k === 'lumber' || m.k === 'camp' || m.k === 'plant' || m.k === 'fort' || (m.k === 'mine' && G.res[j]))) G.feat[j] = 0;
    const after = tileYield(G, j, o);
    G.imp[j] = sv[0]; G.pil[j] = sv[1]; G.feat[j] = sv[2];
    let v = (after[0] - before[0]) * 1.3 + (after[1] - before[1]) * 1.2 + (after[2] - before[2]) * 0.5 + (after[3] - before[3]) + (after[4] - before[4]) * 0.8 + (after[5] - before[5]) * 0.6;
    if (G.res[j]) v += RES[G.res[j]].c === 'l' ? 4 : RES[G.res[j]].c === 's' ? 3 : 1.5;
    if (m.k === 'farm' || m.k === 'pasture' || m.k === 'plant' || m.k === 'camp') v += 0.4;
    if (m.k === 'fort' || m.k === 'resort' && false) v -= 3;
    if (m.pw) v += 1;
    return v;
  }
  function aiBuilder(G, X, u) {
    const o = X.o;
    const here = () => {
      if (G.pil[u.p] || G.dpil[u.p]) { if (doRepair(G, u)) return true; }
      const opts = impOptions(G, u, u.p); if (!opts.length) return false;
      let bk = -1, bv = 0.5; for (const k of opts) { const v = impGain(G, o, u.p, k); if (v > bv) { bv = v; bk = k; } }
      if (bk >= 0) { doImprove(G, u, bk); return true; }
      return false;
    };
    if (here()) return;
    // 목표 찾기
    let best = -1, bv = 0.5;
    for (const c of X.cs) {
      if (hexDist(G.g, c.p, u.p) > 12) continue;
      for (const j of cityTiles(G, c)) {
        if (j === c.p || G.dis[j] || G.won[j]) continue;
        if (G.U.some((v) => v !== u && v.o === o && v.tg === j && UT[v.t].k === 'builder')) continue;
        const m = milAt(G, j); if (m && m.o !== o) continue;
        let tv = 0;
        if (G.pil[j]) tv = 3;
        const opts = impOptions(G, u, j); for (const k of opts) tv = Math.max(tv, impGain(G, o, j, k));
        if (tv <= 0) continue;
        const v = tv + ((c.wk || []).indexOf(j) >= 0 ? 1.5 : 0) - hexDist(G.g, u.p, j) * 0.35 + nz(X, 1);
        if (v > bv) { bv = v; best = j; }
      }
    }
    if (best < 0) {
      // 할 일 없으면 숲 베기(생산이 필요한 도시)
      const c = tileCity(G, u.p); if (c && c.o === o && chopValue(G, u, u.p) && c.q[0] && (c.q[0].t === 'w' || c.q[0].t === 'd') && R() < (X.lv >= 3 ? 0.9 : X.lv === 2 ? 0.6 : 0.2)) { doChop(G, u); return; }
      const cap = capOf(G, o); if (cap && hexDist(G.g, cap.p, u.p) > 3) goToward(G, u, cap.p);
      return;
    }
    u.tg = best;
    if (goToward(G, u, best) && G.uid[u.id] && u.p === best && u.mv > 0) here();
  }
  function cityThreat(G, o, c, r) {
    let t = 0;
    for (const j of within(G.g, c.p, r || 4)) { const m = milAt(G, j); if (m && m.o !== o && atWar(G, m.o, o)) t += (UT[m.t].cs || 10) / 20; }
    return t;
  }
  function bestUnitFor(G, c, cls) {
    let best = null, bv = -1;
    for (let i = 0; i < UT.length; i++) {
      const T = UT[i]; if (cls.indexOf(T.cl) < 0) continue;
      const it = { t: 'u', k: T.k }; if (!canBuild(G, c, it)) continue;
      const v = Math.max(T.cs || 0, T.rs || 0); if (v > bv) { bv = v; best = it; }
    }
    return best;
  }
  function aiChooseProd(G, X, c) {
    const o = X.o, p = X.p, opts = [];
    const add = (it, v) => { if (it && canBuild(G, c, it)) opts.push({ it, v: v + nz(X, 2) }); };
    const settlers = G.U.filter((u) => u.o === o && UT[u.t].k === 'settler').length + G.C.filter((d) => d.o === o && d.q.some((q) => q.k === 'settler')).length;
    const builders = G.U.filter((u) => u.o === o && UT[u.t].k === 'builder').length + G.C.filter((d) => d.o === o && d.q.some((q) => q.k === 'builder')).length;
    const mil = G.U.filter((u) => u.o === o && isMil(u.t)), threat = cityThreat(G, o, c, 5);
    const cc = cityCalc(G, c);
    // 개척자
    if (X.cs.length + settlers < X.want && settlers < 2 && c.pop >= 2 && G.s.t < G.s.tl * 0.6) add({ t: 'u', k: 'settler' }, 9 - X.cs.length * 0.6 + (c.pop >= 3 ? 2 : 0) - (X.wars.length ? 3 : 0) + (X.lv >= 3 && G.s.t < G.s.tl * 0.35 ? 2 : 0));
    if (builders < Math.max(1, Math.ceil(X.cs.length * (X.lv === 1 ? 0.5 : X.lv >= 3 ? 1.1 : 0.8))) && G.s.t < G.s.tl * 0.85) add({ t: 'u', k: unitFor(G, o, 'builder') }, 6.5 - builders);
    // 군사
    const garrison = milAt(G, c.p);
    const wantMil = X.cs.length + 1 + (X.ag.war || 0) + (X.wars.length ? X.cs.length + 2 : 0) + Math.floor(G.s.era / 2);
    if (mil.length < wantMil || threat > 0) {
      const v = (threat > 0 ? 9 + threat * 2 : 4) + (X.wars.length ? 3 : 0) - mil.length / Math.max(1, wantMil) * 3;
      const roll = R();
      const cls = roll < 0.45 ? ['mel'] : roll < 0.65 ? ['rng'] : roll < 0.78 ? ['ac'] : roll < 0.92 ? ['hc', 'lc'] : ['sg'];
      add(bestUnitFor(G, c, cls) || bestUnitFor(G, c, ['mel', 'rng', 'ac']), v);
      if (X.wars.length && mil.filter((u) => UT[u.t].cl === 'sg').length < 2) add(bestUnitFor(G, c, ['sg']), v + 0.5);
      if (!garrison && X.wars.length) add(bestUnitFor(G, c, ['mel', 'rng']), 8);
    }
    if (G.s.era <= 1 && mil.length < 1 + X.cs.length * 0.5) add(bestUnitFor(G, c, ['mel', 'rng']), 5);
    // 정찰
    if (G.s.t < 25 && !G.U.some((u) => u.o === o && UT[u.t].cl === 'rec') && X.cs.length <= 2) add({ t: 'u', k: 'scout' }, 4.5);
    // 성벽
    if (threat > 0 || (X.wars.length && c.b.indexOf('palace') >= 0)) { add({ t: 'b', k: 'wall1' }, 7 + threat); add({ t: 'b', k: 'wall2' }, 5 + threat); add({ t: 'b', k: 'wall3' }, 4 + threat); }
    // 구역
    const dW = { ad: X.era >= 5 ? (X.wars.length ? 2.2 : 0.6) + (X.ag.war || 0) * 0.3 : 0, pr: 0.6 + (X.ag.cul || 0) * 0.4 + (X.ag.rel || 0) * 0.2, cam: 3.2 + X.sci * 0.8, hs: (p.rel < 0 && G.s.R.length < maxReligions(G) && !mods(G, o).noRel ? (X.lv === 1 ? 1.2 : 2.5) + (X.ag.rel || 0) : 0.8 + (X.ag.rel || 0) * 0.5), com: 3 + (X.ag.gold || 0) * 0.6, th: 2.4 + (X.ag.cul || 0) * 0.8, ind: 3, hb: coastal(G, c.p) ? 2.2 : 0, enc: 0.8 + (X.ag.war || 0) * 0.6, ent: 0, wp: 0, aq: 0, nb: 0, sp: !G.C.some((d) => d.o === o && (d.d.sp != null || d.q.some((q) => q.k === 'sp'))) ? 9 + X.sci * 2 : 0, gov: 2.5, dq: 1.2, dam: 1, can: 0 };
    if (cc.hous - c.pop <= 1) { dW.aq = 5; dW.nb = 4; }
    if (cc.amen - cc.amenNeed < 0) { dW.ent = 4.5 - (cc.amen - cc.amenNeed); dW.wp = 3; }
    for (const dk in dW) {
      if (dW[dk] <= 0) continue;
      const sites = distSites(G, c, dk); if (!sites.length) continue;
      let bt = sites[0], ba = -1e9; if (X.lv === 1) { bt = pickR(sites); ba = adjBonus(G, o, bt, dk); } else for (const j of sites) { const a = adjBonus(G, o, j, dk) * 1 - (G.res[j] ? 1 : 0) - ((c.wk || []).indexOf(j) >= 0 ? 0.6 : 0) + (dk === 'aq' || dk === 'nb' ? appeal(G, j) * 0.2 : 0); if (a > ba) { ba = a; bt = j; } }
      const D = DIS[DISI[dk]];
      add({ t: 'd', k: dk, p: bt }, dW[dk] + (D.y >= 0 ? Math.max(0, ba) * 0.9 : 0) + c.pop * 0.15);
    }
    // 건물
    for (const b of BLD) {
      if (b.k === 'palace' || b.wall || b.fb) continue;
      const it = { t: 'b', k: b.k }; if (!canBuild(G, c, it)) continue;
      let v = 2 + (b.y ? b.y[0] * 1.1 + b.y[1] * 1.2 + b.y[2] * 0.5 + b.y[3] * (0.9 + X.sci * 0.2) + b.y[4] * (0.9 + (X.ag.cul || 0) * 0.2) + b.y[5] * 0.45 : 0) + (b.gp ? 0.6 : 0) + (b.gw ? 0.5 : 0);
      if (b.h) v += (cc.hous - c.pop <= 2 ? 1.5 : 0.4) * b.h;
      if (b.a) v += (cc.amen - cc.amenNeed < 1 ? 2 : 0.5) * b.a;
      if (b.power) v += c.b.some((k) => BLD[BLDI[k]] && BLD[BLDI[k]].pw) && !c.pw ? 4 : 0.2;
      if (b.d === 'enc' && !X.wars.length && !X.ag.war) v -= 1;
      if (b.k === 'archmus') v += Object.keys(G.s.AS || {}).filter((k) => G.ex[o][+k]).length >= 2 ? 2 : -1;
      if (b.air) v += X.wars.length ? 1.5 : -1;
      add(it, v);
    }
    if (canBuild(G, c, { t: 'b', k: 'worship' })) add({ t: 'b', k: 'worship' }, 2.5);
    if (cityTiles(G, c).some((j) => G.low[j] && G.low[j] <= G.s.CL.sea + 1) && G.s.CL.st >= 2) add({ t: 'b', k: 'flood' }, 4);
    // 불가사의
    if (cc.y[1] >= 8 || X.ag.won) {
      for (const W of WON) {
        if (G.s.WB[W.k] != null) continue;
        if (!hasReq(G, o, W.req)) continue;
        const sites = wonSites(G, c, W); if (!sites.length) continue;
        const it = { t: 'w', k: W.k, p: sites[ri(sites.length)] };
        if (!canBuild(G, c, it)) continue;
        const turns = itemCost(G, c, it) / Math.max(1, cc.y[1]);
        if (X.lv === 1 && R() < 0.85) continue;
        add(it, 3.2 + (X.ag.won || 0) * 1.6 - turns * 0.06 + (c.b.indexOf('palace') >= 0 ? 1 : 0) + (X.lv === 1 ? -3 : X.lv === 3 ? 1.2 : 0));
      }
    }
    // 프로젝트
    for (const P2 of PRJ) {
      const it = { t: 'p', k: P2.k }; if (!canBuild(G, c, it)) continue;
      if (P2.once || P2.ura) continue;
      add(it, P2.sv ? 9 + X.sci * 2 : P2.k === 'laser' ? 8 : P2.k === 'carbon' ? (G.s.CL.st >= 3 ? 2 : -5) : (X.lv === 1 ? -2 : 1.4));
    }
    // 상인
    if (X.p.tr.length + G.U.filter((u) => u.o === o && UT[u.t].k === 'trader').length < tradeCap(G, o)) add({ t: 'u', k: 'trader' }, 5.5);
    // 첩보원·고고학자·항공·핵·군사 공학자
    if (X.lv >= 2 && (X.p.spy || []).length < spyCap(G, o)) add({ t: 'u', k: 'spy' }, 3.5 + (X.ag.sci ? 1 : 0));
    if (Object.keys(G.s.AS || {}).length) add({ t: 'u', k: 'archaeo' }, 4 + (X.ag.cul || 0));
    if (X.wars.length && X.era >= 5) { const air = bestUnitFor(G, c, ['air']); if (air) add(air, 6 + (X.ag.war || 0)); }
    if ((X.ag.war || 0) >= 2 && X.lv >= 2) { add({ t: 'p', k: 'manhattan' }, 2.5); if (X.wars.length) { add({ t: 'p', k: 'nukeA' }, 3); add({ t: 'p', k: 'nukeT' }, 3.5); } }
    if (X.era >= 4 && X.lv >= 2 && !G.U.some((u) => u.o === o && UT[u.t].k === 'mileng') && (X.p.stk[RESI.coal] || 0) >= 4 && hasTech(G, o, 'steam') && R() < 0.3) add({ t: 'u', k: 'mileng' }, 2.5);
    if (!opts.length) return null;
    opts.sort((a, b) => b.v - a.v);
    if (X.lv === 1) { const o2 = opts.filter((x) => x.it.t !== 'p'); return (o2.length ? o2 : opts)[ri(Math.min(6, (o2.length ? o2 : opts).length))].it; }
    return opts[0].it;
  }
  function aiCities(G, X) {
    for (const c of citiesOf(G, X.o)) {
      if (c.d.sp != null && !c.q.some((q) => q.t === 'p' && (PRJ[PRJI[q.k]].sv || q.k === 'laser'))) { const P2 = PRJ.find((pp) => (pp.sv || pp.k === 'laser') && canBuild(G, c, { t: 'p', k: pp.k })); if (P2) c.q.unshift({ t: 'p', k: P2.k }); }
      if (!c.q.length) { const it = aiChooseProd(G, X, c); if (it) c.q.push(it); }
      // 전쟁 중 위협이면 군사로 끼어들기
      if (X.wars.length && cityThreat(G, X.o, c, 3) > 1.5 && c.q[0] && c.q[0].t !== 'u' && !milAt(G, c.p)) { const it = bestUnitFor(G, c, ['mel', 'rng']); if (it) c.q.unshift(it); }
      if (c.q.length > 3) c.q.length = 3;
      for (const j of cityStrikeTargets(G, c)) { const m = milAt(G, j); if (m) { cityStrike(G, c, j); break; } }
    }
  }
  function aiPurchases(G, X) {
    const p = X.p, o = X.o;
    if (X.lv === 1 && R() < 0.9) return;
    const reserve = (60 * G.s.spP + 20 * X.era) * (X.lv >= 3 ? 0.6 : 1);
    for (const c of X.cs.slice().sort(() => R() - 0.5)) {
      if (p.gold < reserve) break;
      const it = c.q[0];
      if (it && it.t !== 'd' && it.t !== 'w' && it.t !== 'p') {
        if (canBuy(G, c, it, 'g') && buyCost(G, c, it, 'g') < p.gold - reserve * 0.5 && (it.t === 'b' || UT[UTI[it.k]].cl === 'civ' || X.wars.length || cityThreat(G, o, c, 4) > 0)) { doBuy(G, c, it, 'g'); continue; }
      }
      // 대기열과 별개로 쓸 만한 건물 사기
      if (p.gold > reserve * 2.5) {
        let best = null, bv = 0;
        for (const b of BLD) { if (!b.y || b.wall || b.k === 'palace') continue; const it2 = { t: 'b', k: b.k }; if (!canBuy(G, c, it2, 'g')) continue; const cost = buyCost(G, c, it2, 'g'); if (cost > p.gold - reserve) continue; const v = sum(b.y) / cost; if (v > bv) { bv = v; best = it2; } }
        if (best) doBuy(G, c, best, 'g');
      }
    }
    // 타일 구매(사치 자원)
    if (p.gold > reserve * 2) for (const c of X.cs) for (const j of within(G.g, c.p, 3)) if (canBuyTile(G, c, j) && G.res[j] && tileBuyCost(G, c, j) < p.gold - reserve) { p.gold -= tileBuyCost(G, c, j); claimTile(G, c, j); break; }
    // 신앙: 내 도시에 다른 종교가 퍼지면 종교 재판관으로 막기(보통·어려움)
    if (p.rel >= 0 && X.lv >= 2 && !G.U.some((u) => u.o === o && UT[u.t].k === 'inquisitor')) {
      const bad = X.cs.filter((c) => c.rp && Object.keys(c.rp).some((k) => +k !== p.rel && c.rp[k] > (c.rp[p.rel] || 0) * 0.6 && c.rp[k] > 60));
      if (bad.length) { const c = X.cs.find((d) => cityHasB(d, 'temple')); if (c) { const it = { t: 'u', k: 'inquisitor' }; if (canBuy(G, c, it, 'f')) doBuy(G, c, it, 'f'); } }
    }
    // 신앙: 종교 유닛
    if (p.rel >= 0 && G.s.R[p.rel].f === o) {
      const missN = G.U.filter((u) => u.o === o && UT[u.t].cl === 'rel').length;
      const targetsN = G.C.filter((c) => c.rl !== p.rel && hexDist(G.g, c.p, (capOf(G, o) || c).p) <= 14).length;
      if (missN < (X.lv === 1 ? 0 : 1) + (X.ag.rel || 0) + 0 && targetsN > 0 && (X.ag.rel || R() < 0.5)) {
        const c = X.cs.find((d) => d.d.hs != null);
        if (c) { const k = cityHasB(c, 'temple') && R() < 0.4 ? 'apostle' : 'missionary'; const it = { t: 'u', k }; if (canBuy(G, c, it, 'f')) doBuy(G, c, it, 'f'); }
      }
    }
    // 신앙: 위인 후원(신앙이 많이 남을 때)
    if (p.faith > (X.lv >= 3 ? 220 : 400) * G.s.spT) for (const cl of (X.lv >= 3 ? ['pro', 'sci', 'eng', 'mer', 'wri', 'art'] : ['pro', 'sci', 'eng'])) { if ((cl === 'wri' || cl === 'art') && !X.cs.some((c) => gwSlots(G, c, cl) > 0)) continue; if (gpPatron(G, o, cl, 'f')) break; }
  }
  function gpPatronCost(G, o, cl, cur) { const left = Math.max(0, gpCost(G, cl) - (G.P[o].gpp[cl] || 0)); return Math.round(left * (cur === 'f' ? 2 : 3)); }
  function gpPatron(G, o, cl, cur) {
    const p = G.P[o]; if (G.s.GP.cur[cl] == null || G.s.GP.cur[cl] < 0) return false;
    const c = gpPatronCost(G, o, cl, cur);
    if (cur === 'f' ? p.faith < c : p.gold < c) return false;
    if (cur === 'f') p.faith -= c; else p.gold -= c;
    p.gpp[cl] = Math.max(p.gpp[cl] || 0, gpCost(G, cl));
    return claimGP(G, o, cl, true);
  }

  /* ----- AI 유닛 ----- */
  function frontierTile(G, o, u) {
    const ex = G.ex[o], seen = new Set([u.p]), q = [u.p];
    let n = 0;
    while (q.length && n++ < 500) {
      const i = q.shift();
      for (const j of G.g.nb[i]) {
        if (seen.has(j)) continue; seen.add(j);
        if (!ex[j]) return i === u.p ? j : i;
        if (stepCost(G, u, i, j) !== Infinity) q.push(j);
      }
    }
    return -1;
  }
  function aiPickAttack(G, X, u) {
    const tg = targets(G, u); if (!tg.length) return -1;
    let best = -1, bv = X.lv >= 3 ? 4 : X.lv === 2 ? 6 : 10;
    for (const j of tg) {
      const pv = combatPreview(G, u, j);
      const c = cityAt(G, j);
      let v;
      if (c) { v = (pv.da[0] + pv.da[1]) / 2 * 0.6 - (pv.dr[1] || 0) * 0.8 + (pv.cap ? 80 : 0) + (UT[u.t].cl === 'sg' ? 10 : 0); if (pv.wall && !isRanged(u.t) && !pv.cap) v -= X.lv >= 3 ? 30 : X.lv === 2 ? 12 : 0; }
      else if (pv.capt) v = 30;
      else v = (pv.da[0] + pv.da[1]) / 2 + pv.kill * 40 - (pv.dr[0] + pv.dr[1]) / 2 * 0.9 - (pv.die || 0) * 60;
      if (u.hp < 35 && !isRanged(u.t)) v -= 25;
      if (X.lv >= 3 && !c && pv.kill >= 0.99) v += 15;   // 확실히 잡을 수 있는 적부터
      v += nz(X, 6);
      if (v > bv) { bv = v; best = j; }
    }
    return best;
  }
  function aiMilitary(G, X, u, tgtCity) {
    const o = X.o;
    if (promoReady(u)) { const op = promoOptions(u); if (op.length) doPromote(G, u, X.lv === 1 ? pickR(op) : op[0]); return; }
    // 부족 마을
    if (!isNaval(u.t) && (UT[u.t].cl === 'rec' || !X.wars.length) && u.hp > 50) {
      let gb = -1, gd = UT[u.t].cl === 'rec' ? 10 : 5;
      for (const j of within(G.g, u.p, gd)) if (G.imp[j] === IMPI.goody && G.ex[o][j] && !milAt(G, j) && hexDist(G.g, u.p, j) <= gd) { gd = hexDist(G.g, u.p, j); gb = j; }
      if (gb >= 0 && goToward(G, u, gb)) return;
    }
    // 군단·군대(평화로울 때 같은 유닛끼리)
    if (X.lv >= 2 && !X.wars.length && (hasCivic(G, o, 'nationalism') || hasCivic(G, o, 'mercantilism'))) { for (const j of G.g.nb[u.p]) { const v = milAt(G, j); if (v && corpsOK(G, u, v)) { doCorps(G, u, v); return; } } }
    if (canUpgrade(G, u) && X.p.gold > upgradeCost(G, u) + 80 * G.s.spP && R() < 0.5) doUpgrade(G, u);
    // 공격
    let a = aiPickAttack(G, X, u);
    if (a >= 0) { doAttack(G, u, a); return; }
    // 다쳤으면 물러나기
    const atWarNow = X.wars.length || X.csWars.length || (X.fcT && tgtCity && G.P[tgtCity.o].k === 'fc');
    if (u.hp < 45 && atWarNow) {
      const home = X.cs.slice().sort((p1, p2) => hexDist(G.g, p1.p, u.p) - hexDist(G.g, p2.p, u.p))[0];
      if (home && u.p !== home.p) { goToward(G, u, home.p); }
      if (G.uid[u.id]) { u.f = Math.max(u.f, 0); u.sl = 1; }
      return;
    }
    // 수비대
    const myCity = cityAt(G, u.p);
    if (myCity && myCity.o === o && (cityThreat(G, o, myCity, 4) > 0 || !atWarNow) && !isNaval(u.t) && G.U.filter((v) => v.o === o && isMil(v.t)).length <= X.cs.length + 1) { u.sl = 1; return; }
    const ungarrisoned = X.cs.find((c) => !milAt(G, c.p) && !G.U.some((v) => v !== u && v.o === o && v.tg === c.p));
    if (ungarrisoned && !isNaval(u.t) && (!atWarNow || cityThreat(G, o, ungarrisoned, 4) > 0) && UT[u.t].cl !== 'rec') { u.tg = ungarrisoned.p; goToward(G, u, ungarrisoned.p); return; }
    // 바다 건너 침공: 해안 도시에 모였다가 출발
    if (atWarNow && tgtCity && X.sea && X.port && !isNaval(u.t) && UT[u.t].cl !== 'rec' && isLand(G, u.p) && G.lc[u.p] !== G.lc[tgtCity.p]) {
      const need = X.lv >= 3 ? 4 : 5;
      if (X.portN < need && hexDist(G.g, u.p, X.port.p) > 1) { goToward(G, u, X.port.p); return; }
      if (X.portN < need) { u.sl = 0; return; }
    }
    // 전쟁: 목표 도시로
    if (atWarNow && tgtCity && !isNaval(u.t) && UT[u.t].cl !== 'rec') {
      const d = hexDist(G.g, u.p, tgtCity.p);
      const siege = UT[u.t].cl === 'sg' || isRanged(u.t);
      const need = X.lv >= 3 ? 3 : 4;
      if (X.staged < need && d <= 5 && d > 2) { u.sl = 0; return; }
      if (d > (siege ? 2 : 1)) goToward(G, u, tgtCity.p);
      if (G.uid[u.id]) { a = aiPickAttack(G, X, u); if (a >= 0) doAttack(G, u, a); }
      return;
    }
    // 야만인 사냥
    let hunt = -1, hd = 9;
    for (const v of G.U) if (G.P[v.o].k === 'bb' && hexDist(G.g, v.p, u.p) < hd && X.cs.some((c) => hexDist(G.g, c.p, v.p) <= 6)) { hd = hexDist(G.g, v.p, u.p); hunt = v.p; }
    if (hunt < 0) for (let i = 0; i < G.N; i++) if (G.imp[i] === IMPI.bcamp && G.ex[o][i] && hexDist(G.g, i, u.p) < hd) { hd = hexDist(G.g, i, u.p); hunt = i; }
    if (hunt >= 0 && !isNaval(u.t) && u.hp > 50) { goToward(G, u, hunt); if (G.uid[u.id]) { a = aiPickAttack(G, X, u); if (a >= 0) doAttack(G, u, a); } return; }
    if (atWarNow && tgtCity && isNaval(u.t) && coastal(G, tgtCity.p)) { const d = hexDist(G.g, u.p, tgtCity.p); if (d > (isRanged(u.t) ? 2 : 1)) goToward(G, u, tgtCity.p); if (G.uid[u.id]) { a = aiPickAttack(G, X, u); if (a >= 0) doAttack(G, u, a); } return; }
    // 정찰·바다 탐험
    if (UT[u.t].cl === 'rec' || (isNaval(u.t) && G.s.t < 80 && R() < 0.6)) { const f = frontierTile(G, o, u); if (f >= 0) { goToward(G, u, f); return; } }
    // 국경 근처에서 경계
    u.sl = 1;
  }
  function aiReligious(G, X, u) {
    const o = X.o, r = u.r;
    if (UT[u.t].k === 'inquisitor') {
      const c = X.cs.find((d) => d.rp && Object.keys(d.rp).some((k) => +k !== r && d.rp[k] > 50));
      if (!c) { u.sl = 1; return; }
      if (hexDist(G.g, u.p, c.p) <= 1) removeHeresy(G, u, c); else goToward(G, u, c.p);
      return;
    }
    // 신학 전투(사도)
    if (UT[u.t].k === 'apostle') for (const j of G.g.nb[u.p]) for (const v of G.U) if (v.p === j && v.o !== o && UT[v.t].cl === 'rel' && v.r !== r && !atWar(G, o, v.o)) { theoCombat(G, u, v); return; }
    let best = null, bv = -1e9;
    for (const c of G.C) {
      if (c.rl === r) continue;
      if (G.P[c.o].k === 'bb' || atWar(G, o, c.o)) continue;
      const d = hexDist(G.g, u.p, c.p); if (d > 16) continue;
      const v = -d + (c.o === o ? 5 : 0) + c.pop * 0.5 + ((c.rp && c.rp[r]) ? 2 : 0);
      if (v > bv) { bv = v; best = c; }
    }
    if (!best) { u.sl = 1; u.idle = (u.idle || 0) + 1; if (u.idle > 10) killUnit(G, u); return; }
    u.idle = 0;
    if (hexDist(G.g, u.p, best.p) <= 1) { spreadRel(G, u, best); return; }
    goToward(G, u, best.p);
    if (G.uid[u.id] && hexDist(G.g, u.p, best.p) <= 1 && u.mv > 0) spreadRel(G, u, best);
  }
  function theoCombat(G, a, d) {
    const M = mods(G, a.o), M2 = mods(G, d.o);
    const A = (UT[a.t].rs || 50) + mv0(M, 'relcs') - (100 - a.hp) / 10, D = (UT[d.t].rs || 50) + mv0(M2, 'relcs') - (100 - d.hp) / 10;
    d.hp -= Math.round(dmgF(A - D) * (0.8 + R() * 0.4)); a.hp -= Math.round(dmgF(D - A) * (0.8 + R() * 0.4)); a.mv = 0;
    const e = { k: 'a', f: a.p, t: d.p, o: a.o, r: 0, rel: 1 };
    if (d.hp <= 0) { e.kill = 1; for (const c of G.C) if (hexDist(G.g, c.p, d.p) <= 8 && c.rp && c.rp[d.r]) c.rp[d.r] *= 0.75; killUnit(G, d); }
    if (a.hp <= 0) { for (const c of G.C) if (hexDist(G.g, c.p, a.p) <= 8 && c.rp && c.rp[a.r]) c.rp[a.r] *= 0.75; killUnit(G, a); if (isMaj(G, a.o) && R() < 0.3) { const pc = placeGW(G, a.o, { c: 'rel', n: -1, e: G.s.era, o: a.o }); if (!pc) G.P[a.o].rq = (G.P[a.o].rq || 0) + 1; note(G, a.o, '✨ 순교한 사도가 성유물을 남겼어요.', -1, 'gw'); } }
    ev(G, e);
    return true;
  }
  function aiGP(G, X, u) {
    const o = X.o, gp = GPL[u.g], fx = gp.fx;
    if (fx.rel) {
      const c = X.cs.find((d) => d.d.hs != null);
      if (!c) { const cap = capOf(G, o); if (cap && u.p !== cap.p) goToward(G, u, cap.p); return; }
      if (u.p !== c.d.hs) { goToward(G, u, c.d.hs); }
      if (G.uid[u.id] && u.p === c.d.hs && gpCanUse(G, u)) { const pk = aiReligionPick(G, o); if (pk) useGP(G, u, pk); }
      return;
    }
    if (fx.aura) {
      // 군대를 따라다녀요
      let best = -1, bv = -1;
      for (const v of G.U) if (v.o === o && isMil(v.t) && !!fx.naval === isNaval(v.t)) { let n = 0; for (const w of G.U) if (w.o === o && isMil(w.t) && hexDist(G.g, w.p, v.p) <= 2) n++; if (n > bv) { bv = n; best = v.p; } }
      if (best >= 0 && best !== u.p) { const near = within(G.g, best, 1).find((j) => !civAt(G, j) && (fx.naval ? true : passableLand(G, j))); if (near != null) goToward(G, u, near); }
      return;
    }
    if (gpCanUse(G, u)) { useGP(G, u); return; }
    u.idle = (u.idle || 0) + 1; if (u.idle > 15) { killUnit(G, u); return; }
    let goal = null;
    if (fx.gw) goal = X.cs.find((c) => gwSlots(G, c, fx.gw) > 0);
    else if (fx.wonder) goal = X.cs.find((c) => c.q.some((q) => q.t === 'w'));
    else if (fx.space) goal = X.cs.find((c) => c.q.some((q) => q.t === 'p' && PRJ[PRJI[q.k]].d === 'sp'));
    else goal = capOf(G, o);
    if (goal && u.p !== goal.p) goToward(G, u, goal.p);
    if (G.uid[u.id] && gpCanUse(G, u)) useGP(G, u);
  }
  function aiTrader(G, X, u) {
    const o = X.o, c = cityAt(G, u.p);
    if (c && c.o === o) {
      const ds = tradeDests(G, u); if (ds.length) {
        let best = ds[0], bv = -1e9;
        for (const id of ds) { const d = G.cid[id]; const y = tradeYield(G, { f: c.id, d: id }); const v = y[0] * 1.2 + y[1] * 1.2 + y[2] + y[3] + y[4] + y[5] + (d.o !== o ? 1 : 0) - hexDist(G.g, c.p, d.p) * 0.1 + nz(X, 2); if (v > bv) { bv = v; best = id; } }
        makeRoute(G, u, best); return;
      }
    }
    const cs2 = X.cs.slice().sort((a, b) => hexDist(G.g, a.p, u.p) - hexDist(G.g, b.p, u.p));
    for (const d of cs2) if (d.p !== u.p) { goToward(G, u, d.p); return; }
  }
  function aiTurn(G, o, lv) {
    const p = G.P[o];
    if (!p.a) return;
    const X = aiX(G, o, lv);
    if (p.dsel) aiDedication(G, o);
    aiGov(G, X); aiResearch(G, X); aiCivic(G, X); aiReligion(G, X); aiGovernors(G, X); aiEnvoys(G, X); aiDiplomacy(G, X);
    X.wars = aliveMaj(G).filter((q) => q !== o && atWar(G, o, q));
    // 목표 도시(같은 땅이 먼저, 배로 건널 수 있으면 바다 건너도)
    let tgt = null, td = 99;
    const foes = X.wars.concat(X.csWars);
    const canSail = hasTech(G, o, 'shipbuilding');
    if (foes.length || X.fcT) {
      for (const c of G.C) {
        const fcC = G.P[c.o].k === 'fc';
        if (foes.indexOf(c.o) < 0 && !(fcC && X.fcT)) continue;
        let d = 99;
        for (const m of X.cs) { const dd = hexDist(G.g, m.p, c.p); if (G.lc[m.p] === G.lc[c.p]) d = Math.min(d, dd); else if (canSail && lv >= 2 && dd <= 20) d = Math.min(d, dd + 6); }
        d -= (c.hp < 100 ? 3 : 0) + (c.oc ? 1 : 0) + (fcC ? 1 : 0);
        if (d < td) { td = d; tgt = c; }
      }
    }
    X.tgt = tgt; X.sea = tgt && !X.cs.some((m) => G.lc[m.p] === G.lc[tgt.p]);
    X.staged = tgt ? G.U.filter((u) => u.o === o && isGround(u.t) && !isNaval(u.t) && hexDist(G.g, u.p, tgt.p) <= 5).length : 0;
    // 바다 건너 침공: 목표에 가장 가까운 해안 도시에 모였다가 함께 출발
    if (X.sea) { let best = null, bd = 99; for (const m of X.cs) if (coastal(G, m.p) && hexDist(G.g, m.p, tgt.p) < bd) { bd = hexDist(G.g, m.p, tgt.p); best = m; } X.port = best; X.portN = best ? G.U.filter((u) => u.o === o && isGround(u.t) && !isNaval(u.t) && hexDist(G.g, u.p, best.p) <= 2).length : 0; }
    const units = G.U.filter((u) => u.o === o).sort((a, b) => (UT[a.t].k === 'settler' ? -1 : 0) - (UT[b.t].k === 'settler' ? -1 : 0));
    for (const u of units) {
      if (!G.uid[u.id] || u.mv <= 0 && !promoReady(u)) continue;
      const T = UT[u.t];
      if (lv === 1 && T.k !== 'settler' && R() < 0.3) continue;
      try {
        if (T.k === 'settler') aiSettler(G, X, u);
        else if (T.k === 'builder') aiBuilder(G, X, u);
        else if (T.k === 'trader') aiTrader(G, X, u);
        else if (T.cl === 'rel') aiReligious(G, X, u);
        else if (T.cl === 'gp') aiGP(G, X, u);
        else if (T.k === 'archaeo') aiArch(G, X, u);
        else if (T.k === 'mileng') aiEngineer(G, X, u);
        else if (isAir(u.t)) aiAir(G, X, u, tgt);
        else if (T.cl === 'sup') { if (tgt && X.wars.length) { const near = G.U.find((v) => v.o === o && isMil(v.t) && hexDist(G.g, v.p, tgt.p) <= 3); if (near) goToward(G, u, near.p); } else { const cap = capOf(G, o); if (cap && u.p !== cap.p && hexDist(G.g, u.p, cap.p) > 2) goToward(G, u, cap.p); } }
        else if (isMil(u.t)) aiMilitary(G, X, u, tgt);
      } catch (e) { if (typeof process !== 'undefined' && process.env && process.env.CIV_DEBUG) throw e; }
    }
    X.cs = citiesOf(G, o);
    aiCities(G, X);
    aiPurchases(G, X);
    aiResearch(G, X); aiCivic(G, X);
    try { aiSpies(G, X); aiDeals(G, X); aiNuke(G, X); aiLevy(G, X); } catch (e) { if (typeof process !== 'undefined' && process.env && process.env.CIV_DEBUG) throw e; }
    // 사람 자리가 AI로 바뀐 경우: 위인 영입
    if (p.lv === 0) for (const c2 of GPK) if (G.s.GP.cur[c2] >= 0 && (p.gpp[c2] || 0) >= gpCost(G, c2)) claimGP(G, o, c2);
  }
  /* ----- AI: 새 기능들 ----- */
  function aiArch(G, X, u) {
    let best = -1, bd = 99;
    for (const k in (G.s.AS || {})) { const i = +k; if (G.imp[i] !== IMPI.ant) continue; const ow = tileOwner(G, i); if (ow >= 0 && ow !== X.o && !openBorders(G, ow, X.o) && !atWar(G, ow, X.o)) continue; const d = hexDist(G.g, u.p, i); if (d < bd && d <= 25) { bd = d; best = i; } }
    if (best < 0) { u.sl = 1; u.idle = (u.idle || 0) + 1; if (u.idle > 12) killUnit(G, u); return; }
    if (u.p === best) { doDig(G, u); return; }
    goToward(G, u, best);
    if (G.uid[u.id] && u.p === best && u.mv > 0) doDig(G, u);
  }
  function aiEngineer(G, X, u) {
    // 수도와 다른 도시 사이 도로를 철도로
    if (roadOK(G, u) && (G.road[u.p] >= 1 || tileOwner(G, u.p) === X.o)) { doRoad(G, u); return; }
    const cap = capOf(G, X.o); if (!cap) return;
    let best = -1, bd = 99;
    for (const c of X.cs) { if (c === cap) continue; const path = routePath(G, cap, c) || []; for (const j of path) if (passableLand(G, j) && G.cat[j] < 0 && G.road[j] < 2) { const d = hexDist(G.g, u.p, j); if (d < bd) { bd = d; best = j; } break; } }
    if (best < 0) { u.sl = 1; return; }
    goToward(G, u, best);
    if (G.uid[u.id] && u.p === best && u.mv > 0 && roadOK(G, u)) doRoad(G, u);
  }
  function aiAir(G, X, u, tgt) {
    const T = UT[u.t];
    if (promoReady(u)) { const op = promoOptions(u); if (op.length) doPromote(G, u, op[0]); return; }
    if (T.rec) { if (tgt && hexDist(G.g, u.p, tgt.p) <= airRange(G, u)) airAct(G, u, 'r', tgt.p); else u.pt = 0; return; }
    const tg = airTargets(G, u);
    if (tg.length && u.hp > 40) {
      let best = -1, bv = X.lv >= 3 ? 8 : 12;
      for (const j of tg) { const pv = airPreview(G, u, j); const v = (pv.da[0] + pv.da[1]) / 2 + (pv.kill || 0) * 40 + (pv.city ? 10 : 0) + (pv.pil ? 6 : 0) - (pv.dr[1] || 0) * 0.8 + nz(X, 6); if (v > bv) { bv = v; best = j; } }
      if (best >= 0) { doAirStrike(G, u, best); return; }
    }
    if (T.ftr && (X.wars.length || X.lv >= 3)) { u.pt = 1; u.sl = 1; }
    // 전선 쪽 기지로 옮기기
    if (tgt && hexDist(G.g, u.p, tgt.p) > airRange(G, u)) { const bs = airBases(G, u); let b = -1, bd = hexDist(G.g, u.p, tgt.p); for (const j of bs) { const d = hexDist(G.g, j, tgt.p); if (d < bd) { bd = d; b = j; } } if (b >= 0) airAct(G, u, 'b', b); }
  }
  function aiSpies(G, X) {
    const p = X.p, o = X.o; if (!p.spy || !p.spy.length || X.lv === 1) return;
    const others = aliveMaj(G).filter((q) => q !== o && met(G, o, q));
    const enemySpies = others.some((q) => (G.P[q].spy || []).some((s2) => s2.m && G.cid[s2.c] && G.cid[s2.c].o === o));
    p.spy.forEach((sp, i) => {
      if (sp.m) return;
      const cap = capOf(G, o);
      if (enemySpies && cap && !p.spy.some((x) => x.m === 'cspy') && spyAssign(G, o, i, cap.id, 'cspy')) return;
      let best = null, bv = -1e9;
      for (const c of G.C) {
        if (c.o === o || !isMaj(G, c.o) || !met(G, o, c.o)) continue;
        for (const m of ['tech', 'gold', 'sab', 'gw']) {
          if (!spyMissionOK(G, o, sp, c.id, m)) continue;
          const odd = spyOdds(G, o, sp, c.id, m);
          let v = odd * (m === 'tech' ? 10 + X.sci * 3 + (cntBits(G.P[c.o].tk) - cntBits(p.tk)) : m === 'gold' ? 7 + (X.ag.gold || 0) * 2 : m === 'sab' ? (atWar(G, o, c.o) ? 12 : 3) : 6 + (X.ag.cul || 0) * 2) - hexDist(G.g, (cap || c).p, c.p) * 0.1 + R();
          if (dipSt(G, o, c.o) >= 2) v -= 6;
          if (v > bv) { bv = v; best = [c.id, m]; }
        }
      }
      if (best) spyAssign(G, o, i, best[0], best[1]);
    });
  }
  function aiDeals(G, X) {
    if (X.lv === 1 || R() > 0.25) return;
    const o = X.o, own = ownedLux(G, o, true);
    for (const d of (G.s.DL || [])) if (d.lx && d.a === o && own[d.lx]) own[d.lx]--;
    const spare = Object.keys(own).filter((r) => own[r] >= 2).map(Number);
    if (!spare.length) return;
    const mineEff = ownedLux(G, o);
    for (const q of aliveMaj(G)) {
      if (q === o || !met(G, o, q) || atWar(G, o, q) || opinion(G, o, q) < -20) continue;
      const qo = ownedLux(G, q, true); for (const d of (G.s.DL || [])) if (d.lx && d.a === q && qo[d.lx]) qo[d.lx]--;
      const qEff = ownedLux(G, q);
      const give = spare.find((r) => !qEff[r]); if (give == null) continue;
      const get = Object.keys(qo).map(Number).find((r) => qo[r] >= 2 && !mineEff[r]);
      const d = { A: { lx: [give] }, B: get != null ? { lx: [get] } : { g: Math.round(60 * Math.max(0.6, G.s.spP)) } };
      if (get == null && G.P[q].gold < d.B.g) continue;
      if (!dealOK(G, o, q, d)) continue;
      if (G.P[q].lv > 0) { if (aiDealValue(G, q, o, d.A, d.B) >= 0) applyDeal(G, o, q, d); }
      else if (R() < 0.3 && !G.s.Q.some((x) => x.f === o && x.t === q)) proposeDeal(G, o, q, d);
      return;
    }
  }
  function aiNuke(G, X) {
    const p = X.p, o = X.o;
    if (!p.nk || !((p.nk.a || 0) + (p.nk.t || 0)) || !X.wars.length || X.lv === 1) return;
    const myP = milPower(G, o), theirP = Math.max(...X.wars.map((q) => milPower(G, q)));
    if (!(theirP > myP * 1.3 || (X.ag.war || 0) >= 3) || R() > 0.25 || (p.nkT && G.s.t - p.nkT < 15)) return;
    let best = null, bv = 0;
    for (const c of X.cs) for (const j of nukeTargetsFrom(G, o, c)) { const tc = cityAt(G, j); const v = (tc ? tc.pop * 3 + (tc.oc ? 10 : 0) : 0) + G.U.filter((u) => hexDist(G.g, u.p, j) <= 1 && u.o !== o && atWar(G, u.o, o)).length * 4 - G.U.filter((u) => hexDist(G.g, u.p, j) <= 2 && u.o === o).length * 8; if (v > bv) { bv = v; best = [c.id, j]; } }
    if (best && bv >= 12) { launchNuke(G, o, (p.nk.t || 0) > 0 ? 't' : 'a', best[0], best[1]); p.nkT = G.s.t; }
  }
  function aiLevy(G, X) {
    if (X.lv === 1 || !X.wars.length) return;
    for (const q of G.P) if (q.k === 'cs' && q.a && q.suz === X.o && !(q.levT > 0) && X.p.gold > levyCost(G) * 1.6 && R() < 0.15) { levyCS(G, X.o, q.o); return; }
  }

  /* ======================= 공개 함수(core) ======================= */
  function actor(s) {
    if (s.ph === 'e') return null;
    if (s.ph === 'k') { const a = []; for (let o = 0; o < s.nM; o++) if (!s.pl[o].ai) a.push(o); return a.length ? a : null; }
    return s.cur;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const G = ctx(JSON.parse(JSON.stringify(s)));
    const names = s.w.map((o) => CIVS[s.P[o].civ].n);
    const stats = [
      { label: '문명', values: s.P.slice(0, s.nM).map((p) => CIVS[p.civ].n + '(' + CIVS[p.civ].ld + ')') },
      { label: '점수', values: s.P.slice(0, s.nM).map((p, o) => String(scoreOf(G, o))) },
      { label: '도시', values: s.P.slice(0, s.nM).map((p, o) => String(citiesOf(G, o).length)) },
      { label: '기술', values: s.P.slice(0, s.nM).map((p) => String(cntBits(p.tk))) },
      { label: '불가사의', values: s.P.slice(0, s.nM).map((p, o) => String(Object.values(s.WB).filter((x) => x === o).length)) },
      { label: '관광객', values: s.P.slice(0, s.nM).map((p, o) => visTourists(G, o) + '/' + domTourists(G, o)) },
    ];
    return { winners: s.w.slice(), title: names.join(', ') + ' ' + WINN[s.wk] + ' 승리!', text: s.t + '턴 · ' + MAPT[s.mtp] + ' 지도', stats };
  }
  function ai(s, seat, lv) {
    if (s.ph === 'k') return s.pk[seat] >= 0 ? null : { t: 'pick', k: 'r' };
    return { t: 'AI', lv: lv || (s.P[seat] && s.P[seat].lv) || 2 };
  }
  function aiDelayFor(s, seat, lv) { if (s.ph === 'k') return s.pk[seat] >= 0 ? -1 : 300; return 260; }

  /* ======================= 행동 적용 ======================= */
  function myUnit(G, seat, id) { const u = G.uid[id]; if (!u || u.o !== seat) throw new Error('unit'); return u; }
  function myCity(G, seat, id) { const c = G.cid[id]; if (!c || c.o !== seat) throw new Error('city'); return c; }
  function apply(s, seat, a) {
    if (s.ph === 'e') throw new Error('over');
    if (s.ph === 'k') return pickAct(s, seat, a);
    if (seat !== s.cur) throw new Error('not your turn');
    const G = ctx(s);
    s.L = { id: (s.L ? s.L.id : 0) + 1, e: [], o: seat };
    const p = G.P[seat], ok = act(G, seat, p, a);
    if (ok === false) throw new Error('illegal ' + a.t);
    commit(G);
    return s;
  }
  function act(G, seat, p, a) {
    const s = G.s;
    switch (a.t) {
      case 'E': endTurn(G); return true;
      case 'AI': aiTurn(G, seat, a.lv || 2); endTurn(G); return true;
      case 'mv': {
        const u = myUnit(G, seat, a.u);
        if (isAir(u.t)) return false;
        if (moveUnit(G, u, a.to)) { u.go = null; return true; }
        // 멀리: 이동 명령
        const path = pathTo(G, u, a.to); if (!path) return false;
        u.go = a.to; goToward(G, u, a.to); if (u.p === a.to) u.go = null; return true;
      }
      case 'stop': { const u = myUnit(G, seat, a.u); u.go = null; u.sl = 0; return true; }
      case 'atk': return doAttack(G, myUnit(G, seat, a.u), a.to);
      case 'found': { const u = myUnit(G, seat, a.u); if (!canFound(G, u)) return false; const c = foundCity(G, seat, u.p, a.n); killUnit(G, u); note(G, seat, '🏛 ' + c.n + ' 건설', c.p, 'city'); return true; }
      case 'fort': { const u = myUnit(G, seat, a.u); u.sl = 1; u.go = null; if (isMil(u.t) && !u.mvd && !u.a) u.f = Math.max(u.f || 0, 1); u.mv = 0; return true; }
      case 'skip': { const u = myUnit(G, seat, a.u); u.sk = s.t; return true; }
      case 'wake': { const u = myUnit(G, seat, a.u); u.sl = 0; u.f = 0; return true; }
      case 'imp': return doImprove(G, myUnit(G, seat, a.u), a.k);
      case 'chop': return doChop(G, myUnit(G, seat, a.u));
      case 'rep': return doRepair(G, myUnit(G, seat, a.u));
      case 'pil': return doPillage(G, myUnit(G, seat, a.u));
      case 'prom': return doPromote(G, myUnit(G, seat, a.u), a.k);
      case 'upg': return doUpgrade(G, myUnit(G, seat, a.u));
      case 'del': { const u = myUnit(G, seat, a.u); killUnit(G, u); return true; }
      case 'gpu': { const u = myUnit(G, seat, a.u); if (u.t !== UTI.gp || u.g == null) return false; return useGP(G, u, a.rel); }
      case 'gpr': { if (!GPC[a.c] || !(G.s.GP.cur[a.c] >= 0) || (p.gpp[a.c] || 0) < gpCost(G, a.c)) return false; return claimGP(G, seat, a.c, true); }
      case 'gpx': { if (!GPC[a.c] || !(G.s.GP.cur[a.c] >= 0)) return false; (p.gpPass = p.gpPass || {})[a.c] = G.s.GP.cur[a.c]; return true; }
      case 'dig': return doDig(G, myUnit(G, seat, a.u));
      case 'air': return airAct(G, myUnit(G, seat, a.u), a.m, a.to);
      case 'nuke': return launchNuke(G, seat, a.k === 't' ? 't' : 'a', a.c, a.to, a.src);
      case 'cmb': return doCorps(G, myUnit(G, seat, a.u), G.uid[a.v]);
      case 'road': return doRoad(G, myUnit(G, seat, a.u));
      case 'spread': { const u = myUnit(G, seat, a.u); if (UT[u.t].cl !== 'rel' || !(u.r >= 0)) return false; const c = G.C.find((d) => hexDist(G.g, d.p, u.p) <= 1 && d.rl !== u.r && !atWar(G, seat, d.o)); if (!c || UT[u.t].k === 'inquisitor') return false; return spreadRel(G, u, c); }
      case 'inq': { const u = myUnit(G, seat, a.u); if (!(u.r >= 0)) return false; const c = G.C.find((d) => d.o === seat && hexDist(G.g, d.p, u.p) <= 1); if (!c || UT[u.t].k !== 'inquisitor') return false; return removeHeresy(G, u, c); }
      case 'theo': { const u = myUnit(G, seat, a.u); const v = G.uid[a.v]; if (!v || UT[u.t].k !== 'apostle' || UT[v.t].cl !== 'rel' || v.r === u.r || hexDist(G.g, u.p, v.p) > 1 || u.mv <= 0) return false; return theoCombat(G, u, v); }
      case 'trade': { const u = myUnit(G, seat, a.u); if (UT[u.t].k !== 'trader') return false; return makeRoute(G, u, a.d); }
      case 'join': { const u = myUnit(G, seat, a.u); const c = cityAt(G, u.p); if (!c || c.o !== seat || UT[u.t].k !== 'settler') return false; c.pop++; killUnit(G, u); assignWork(G, c); return true; }
      case 'prod': {
        const c = myCity(G, seat, a.c), it = a.it;
        if (!it || !canBuild(G, c, it)) return false;
        const key = itemKey(it);
        if (a.mode === 'add') { if (c.q.length >= 6 || c.q.some((q) => itemKey(q) === key)) return false; c.q.push(it); }
        else { c.q = [it].concat(c.q.filter((q) => itemKey(q) !== key && !(q.t === it.t && q.k === it.k))); if (c.q.length > 6) c.q.length = 6; }
        return true;
      }
      case 'qrm': { const c = myCity(G, seat, a.c); if (a.i < 0 || a.i >= c.q.length) return false; c.q.splice(a.i, 1); return true; }
      case 'buy': { const c = myCity(G, seat, a.c); if (!canBuy(G, c, a.it, a.cur)) return false; return doBuy(G, c, a.it, a.cur); }
      case 'tile': { const c = myCity(G, seat, a.c); if (!workable(G, c, a.p)) return false; c.lk = c.lk || []; const k = c.lk.indexOf(a.p); if (k >= 0) c.lk.splice(k, 1); else { c.lk.push(a.p); if (c.lk.length > c.pop) c.lk.shift(); } assignWork(G, c); return true; }
      case 'btile': { const c = myCity(G, seat, a.c); if (!canBuyTile(G, c, a.p)) return false; const cost = tileBuyCost(G, c, a.p); if (p.gold < cost) return false; p.gold -= cost; claimTile(G, c, a.p); assignWork(G, c); return true; }
      case 'focus': { const c = myCity(G, seat, a.c); if (!(a.f >= 0 && a.f < FOCW.length)) return false; c.fo = a.f; assignWork(G, c); return true; }
      case 'cstr': return cityStrike(G, myCity(G, seat, a.c), a.to);
      case 'tech': { if (!TECH[a.k]) return false; if (techAvail(G, seat, a.k)) { p.rs = a.k; p.rg = -1; return true; } if (!TECH[a.k] || bitHas(p.tk, a.k)) return false; p.rg = a.k; p.rs = nextPre(G, seat, a.k, false); return p.rs >= 0; }
      case 'civic': { if (!CIVIC[a.k]) return false; if (civicAvail(G, seat, a.k)) { p.cs = a.k; p.cg = -1; return true; } if (!CIVIC[a.k] || bitHas(p.ck, a.k)) return false; p.cg = a.k; p.cs = nextPre(G, seat, a.k, true); return p.cs >= 0; }
      case 'pol': return setPolicies(G, seat, a.a, true);
      case 'gov': return setGov(G, seat, a.g, true);
      case 'pan': return foundPantheon(G, seat, a.k);
      case 'enh': return enhanceReligion(G, seat, a.w, a.e);
      case 'gpb': return gpPatron(G, seat, a.c, a.cur);
      case 'env': return sendEnvoy(G, seat, a.cs);
      case 'dip': { const r = propose(G, seat, a.to, a.k); if (r === 'no') return false; s.L.dr = r; return true; }
      case 'ans': {
        const q = s.Q[a.i]; if (!q || q.t !== seat) return false;
        s.Q.splice(a.i, 1);
        if (q.k === 'deal') { if (!(a.ok && applyDeal(G, q.f, q.t, q.d))) { note(G, q.f, '✋ ' + civName(G, seat) + '이(가) 거래를 거절했어요.', -1, 'dip'); say(G, q.f, seat, 'hrej'); } else say(G, q.f, seat, 'hacc'); return true; }
        if (a.ok && canPropose(G, q.f, q.t, q.k)) { applyDip(G, q.f, q.t, q.k); say(G, q.f, seat, 'hacc'); } else { note(G, q.f, '✋ ' + civName(G, seat) + '이(가) ' + DIPN[q.k] + ' 제안을 거절했어요.', -1, 'dip'); say(G, q.f, seat, 'hrej'); }
        return true;
      }
      case 'deal': { const d = { A: a.A || {}, B: a.B || {} }; const r = proposeDeal(G, seat, a.to, d); if (r === 'no') return false; s.L.dr = r; return true; }
      case 'spy': return spyAssign(G, seat, a.i, a.c, a.m);
      case 'spyx': { const sp = (p.spy || [])[a.i]; if (!sp) return false; sp.m = ''; return true; }
      case 'levy': return levyCS(G, seat, a.cs);
      case 'gvA': return govAppoint(G, seat, a.g);
      case 'gvP': return govPromote(G, seat, a.g);
      case 'gvS': return govAssign(G, seat, a.g, a.c);
      case 'ded': {
        if (!p.dsel || !DEDI[a.k]) return false;
        if (p.ded < 0) p.ded = a.k; else if (p.dsel >= 2 && a.k !== p.ded) p.ded2 = a.k; else return false;
        p.dsel = p.dsel >= 2 && p.ded2 < 0 ? 2 : 0; if (p.ded >= 0 && (p.dsel < 2 || p.ded2 >= 0)) p.dsel = 0;
        dirty(G); return true;
      }
      case 'vote': {
        const pend = s.WC.pend; if (!pend) return false;
        const n = Math.max(1, Math.min(6, a.n | 0)), cost = voteCost(n - 1);
        const prev = pend.votes[seat] && pend.votes[seat][a.r]; const refund = prev ? voteCost((prev.n || 1) - 1) : 0;
        if (p.favor + refund < cost) return false;
        if (!resTargets(G, pend.res[a.r]).some((x) => String(x) === String(a.tg))) return false;
        p.favor += refund - cost;
        pend.votes[seat] = pend.votes[seat] || {}; pend.votes[seat][a.r] = { op: a.op ? 1 : 0, tg: RESO[pend.res[a.r]].tg === 'p' ? +a.tg : a.tg, n };
        return true;
      }
      case 'note0': { p.nr = (p.nt || []).length; return true; }
    }
    return false;
  }

  /* ======================= 화면 ======================= */
  const CSS = `
.c6{position:absolute;inset:0;overflow:hidden;background:#0b121b;color:var(--ink);font-family:var(--f-body);user-select:none;-webkit-user-select:none;font-size:13px}
.c6 *{box-sizing:border-box}
.c6-map{position:absolute;inset:0;touch-action:none}
.c6-top{position:absolute;left:6px;right:6px;top:6px;display:flex;flex-direction:column;gap:5px;z-index:5;pointer-events:none}
.c6-top>div{display:flex;gap:5px}
.c6-top button{pointer-events:auto}
.c6-chip{position:relative;display:flex;align-items:center;gap:6px;min-height:44px;padding:0 10px;border-radius:12px;background:rgba(20,16,28,.9);border:1px solid rgba(227,174,69,.28);box-shadow:0 2px 8px rgba(0,0,0,.45);font:700 13px var(--f-body);color:var(--ink);cursor:pointer;touch-action:manipulation;min-width:0;overflow:hidden;text-align:left}
.c6-chip .ic{flex:none;font-size:16px}
.c6-chip .tx{flex:1;min-width:0;display:flex;flex-direction:column;line-height:1.15}
.c6-chip .tx b{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:12.5px}
.c6-chip .tx small{font:600 11px var(--f-mono);color:var(--muted);white-space:nowrap}
.c6-chip i.pg{position:absolute;left:0;bottom:0;height:3px;border-radius:2px}
.c6-chip.need{animation:c6p 1.3s ease-in-out infinite;border-color:#f0c35a}
@keyframes c6p{50%{box-shadow:0 0 0 3px rgba(240,195,90,.45)}}
.c6-res{flex:1}
.c6-stat{flex:1;justify-content:space-between;font:600 12px var(--f-mono);gap:4px;padding:0 8px}
.c6-stat span{white-space:nowrap}
.c6-side{position:absolute;left:6px;display:flex;flex-direction:column;gap:6px;z-index:5}
.c6-side button{position:relative;width:44px;height:44px;border-radius:12px;border:1px solid rgba(227,174,69,.28);background:rgba(20,16,28,.86);color:var(--ink);font:700 19px var(--f-body);cursor:pointer;touch-action:manipulation;box-shadow:0 2px 6px rgba(0,0,0,.4);padding:0}
.c6-side button .bd{position:absolute;right:-4px;top:-4px;min-width:18px;height:18px;border-radius:9px;background:#e0503c;color:#fff;font:700 11px var(--f-mono);display:grid;place-items:center;padding:0 4px}
.c6-side button.need{border-color:#f0c35a;animation:c6p 1.3s ease-in-out infinite}
.c6-mini{position:absolute;right:6px;z-index:5;border-radius:8px;border:1px solid rgba(227,174,69,.35);box-shadow:0 2px 8px rgba(0,0,0,.5);background:#090d14;cursor:pointer;touch-action:none}
.c6-bot{position:absolute;left:0;right:0;bottom:0;z-index:6;padding:7px 8px calc(8px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(22,17,30,.93),rgba(15,11,21,.98));border-top:1px solid rgba(227,174,69,.3);box-shadow:0 -4px 14px rgba(0,0,0,.45);display:flex;flex-direction:column;gap:6px}
.c6-info{display:flex;align-items:center;gap:8px;min-height:38px;line-height:1.3}
.c6-info .tx{flex:1;min-width:0}
.c6-info .tx b{font-size:14px}
.c6-info .tx small{display:block;color:var(--muted);font-size:11.5px}
.c6-info .tok{flex:none;width:38px;height:38px;border-radius:50%;display:grid;place-items:center}
.c6-btns{display:flex;flex-wrap:wrap;gap:6px}
.c6-btns .btn{flex:1 1 auto;min-width:62px;min-height:44px;padding:0 8px;font-size:13px;white-space:nowrap}
.c6-btns .btn[disabled]{opacity:.4}
.c6-btns .btn.end{flex:1.6 1 auto}
.c6-hp{display:inline-block;width:52px;height:6px;border-radius:3px;background:#3a2530;vertical-align:middle;overflow:hidden;margin-left:4px}
.c6-hp i{display:block;height:100%;background:#7fd36a}
.c6-odds{display:grid;grid-template-columns:1fr auto 1fr;gap:6px;align-items:center;font:600 12px var(--f-mono);background:#271f33;border-radius:10px;padding:6px 8px}
.c6-odds .vs{color:var(--brass);font-weight:700}
.c6-odds .r{text-align:right}
.c6-sheet{position:absolute;left:0;right:0;bottom:0;max-height:86%;z-index:9;background:var(--surface);border-top:1px solid rgba(227,174,69,.4);border-radius:18px 18px 0 0;box-shadow:0 -8px 24px rgba(0,0,0,.6);display:flex;flex-direction:column;animation:c6up .18s ease-out}
.c6-sheet.half{max-height:58%}
.c6.wide .c6-sheet{left:auto;top:6px;bottom:6px;right:6px;width:min(440px,46%);max-height:none;border-radius:16px;border:1px solid rgba(227,174,69,.4)}
@keyframes c6up{from{transform:translateY(24px);opacity:.4}}
.c6-sh-h{flex:none;display:flex;align-items:center;gap:8px;padding:8px 8px 8px 14px;border-bottom:1px solid rgba(255,255,255,.07)}
.c6-sh-h h3{margin:0;flex:1;min-width:0;font:400 21px var(--f-display);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.c6-sh-h .btn{min-width:56px;min-height:44px}
.c6-tabs{flex:none;display:flex;gap:4px;padding:6px 10px 0;overflow-x:auto}
.c6-tabs .btn{flex:1 0 auto;min-height:44px;font-size:13px;padding:0 10px}
.c6-tabs .btn.on{background:var(--brass);color:#1c1408;border-color:var(--brass)}
.c6-sh-b{overflow-y:auto;padding:8px 10px 16px;display:flex;flex-direction:column;gap:6px;-webkit-overflow-scrolling:touch;flex:1;min-height:0}
.c6-row{display:flex;align-items:center;gap:8px;min-height:48px;padding:5px 9px;border-radius:11px;background:var(--surface-2);border:1px solid transparent;cursor:pointer;touch-action:manipulation;text-align:left;color:var(--ink);font:inherit;width:100%}
.c6-row:active{transform:scale(.985)}
.c6-row.on{border-color:var(--brass);background:#3a2f4c}
.c6-row.off{opacity:.5}
.c6-row.done{opacity:.6;background:#1d2a22}
.c6-row .ic{flex:none;width:32px;height:32px;border-radius:9px;display:grid;place-items:center;font:700 15px var(--f-body);background:#3a3048}
.c6-row .tx{flex:1;min-width:0;display:flex;flex-direction:column}
.c6-row .tx b{font-size:13.5px}
.c6-row .tx small{font-size:11.5px;color:var(--muted);line-height:1.3}
.c6-row .rt{flex:none;text-align:right;font:600 12px var(--f-mono);color:#f0d9a6}
.c6-row .rt small{display:block;color:var(--muted);font-size:10.5px}
.c6-row .bt{flex:none;display:flex;gap:4px}
.c6-row .bt .btn{min-height:44px;min-width:44px;padding:0 8px;font-size:12px}
.c6-lab{font-size:12px;color:var(--brass);font-weight:700;margin-top:6px;letter-spacing:.02em}
.c6-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(74px,1fr));gap:5px}
.c6-grid>div{background:var(--surface-2);border-radius:9px;padding:5px 4px;text-align:center;font-size:11px;color:var(--muted)}
.c6-grid>div b{display:block;font:600 14px var(--f-mono);color:var(--ink)}
.c6-pills{display:flex;flex-wrap:wrap;gap:5px}
.c6-pills>span,.c6-pills>button{font-size:11.5px;padding:4px 9px;border-radius:20px;background:#3c3150;color:#eadcc0;border:0;font-family:inherit}
.c6-pills>button{min-height:44px;padding:0 12px;cursor:pointer}
.c6-pills>button.on{background:var(--brass);color:#1c1408}
.c6-p{font-size:12.5px;line-height:1.45;color:#e8dcc6;margin:0}
.c6-p.mut{color:var(--muted)}
.c6-bar{height:7px;border-radius:4px;background:#1b1624;overflow:hidden}
.c6-bar i{display:block;height:100%}
.c6-card{background:var(--surface-2);border-radius:12px;padding:8px 10px;display:flex;flex-direction:column;gap:6px}
.c6-say{font-size:12.5px;line-height:1.45;color:var(--ink);background:rgba(255,255,255,.05);border-left:3px solid var(--brass);border-radius:6px;padding:5px 8px}.c6-say b{color:var(--brass);font-size:11.5px}.c6-say i{font-style:normal;opacity:.6;font-size:10px}
.c6-card .hd{display:flex;align-items:center;gap:8px}
.c6-card .hd .tx{flex:1;min-width:0}
.c6-card .hd b{display:block;font-size:14px}
.c6-card .hd small{display:block;color:var(--muted);font-size:11.5px;line-height:1.3}
.c6-st{flex:none;font:700 12px var(--f-body);padding:4px 9px;border-radius:20px}
.c6-st.w{background:#5a2328;color:#ffb3a8}.c6-st.p{background:#2c3d52;color:#bfe3ff}.c6-st.d{background:#284a3c;color:#b8f0c8}.c6-st.a{background:#3e4a22;color:#e2f0a8}
.c6-bb{display:flex;flex-wrap:wrap;gap:5px}
.c6-bb .btn{flex:1 1 auto;min-height:44px;font-size:12.5px;padding:0 8px}
.c6-slot{display:flex;align-items:center;gap:8px;min-height:50px;padding:5px 9px;border-radius:11px;border:2px dashed rgba(255,255,255,.18);cursor:pointer;background:transparent;color:var(--ink);font:inherit;text-align:left;width:100%}
.c6-slot.fill{border-style:solid;background:var(--surface-2)}
.c6-wait{position:absolute;left:50%;top:42%;transform:translate(-50%,-50%);z-index:4;background:rgba(20,16,28,.92);border:1px solid rgba(227,174,69,.3);border-radius:14px;padding:12px 18px;font-weight:700;font-size:14px;text-align:center;pointer-events:none;max-width:80%}
.c6-tip{position:absolute;z-index:7;left:50%;transform:translateX(-50%);background:rgba(20,16,28,.95);border:1px solid rgba(227,174,69,.4);border-radius:10px;padding:6px 10px;font-size:12px;pointer-events:none;white-space:nowrap}
.c6-modal{position:absolute;inset:0;z-index:12;background:rgba(5,3,8,.6);display:flex;align-items:center;justify-content:center;padding:16px}
.c6-modal>div{background:var(--surface);border:1px solid rgba(227,174,69,.4);border-radius:16px;max-width:420px;width:100%;max-height:86%;display:flex;flex-direction:column;overflow:hidden}
.c6-tw{position:relative;overflow:auto;border-radius:12px;background:#110e18;border:1px solid rgba(255,255,255,.07);max-height:min(58vh,560px);-webkit-overflow-scrolling:touch;flex:none}
.c6-tg{position:relative}
.c6-tg svg{position:absolute;left:0;top:0;pointer-events:none}
.c6-tn{position:absolute;width:122px;height:46px;border-radius:9px;padding:3px 7px;font:600 11.5px var(--f-body);display:flex;flex-direction:column;justify-content:center;background:#2a2335;border:1.5px solid rgba(255,255,255,.13);color:var(--ink);cursor:pointer;text-align:left;line-height:1.2;overflow:hidden}
.c6-tn b{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:700}
.c6-tn small{font:500 10px var(--f-mono);color:var(--muted);white-space:nowrap}
.c6-tn.done{background:#223a28;border-color:#4f8f5a}.c6-tn.cur{background:#26476e;border-color:#79bff0}.c6-tn.av{border-color:#d8c99c}.c6-tn.lock{opacity:.55}.c6-tn.goal{box-shadow:0 0 0 2px #f0c35a}.c6-tn.sel{outline:2px solid #fff;outline-offset:1px}
.c6-tn i{position:absolute;right:5px;top:4px;font-style:normal;font-size:11px}
.c6-te{position:absolute;top:4px;font:700 11.5px var(--f-body);color:var(--brass);white-space:nowrap}
.c6.pick>.c6-top,.c6.pick>.c6-side,.c6.pick>.c6-mini,.c6.pick>.c6-bot,.c6.pick>.c6-map{display:none}
.c6-pk{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 80% at 50% 0%,#1d2a22,#0b121b 70%);z-index:20}
.c6-pk-h{flex:none;padding:10px 12px 6px;display:flex;flex-direction:column;gap:7px;border-bottom:1px solid rgba(227,174,69,.22);background:rgba(10,14,20,.6)}
.c6-pk-h h2{margin:0;font:400 23px var(--f-display);color:#f3e2b8}
.c6-pk-h .sub{font-size:12px;color:var(--muted);line-height:1.35}
.c6-pk-seats{display:flex;gap:5px;overflow-x:auto;padding-bottom:2px}
.c6-pk-seat{flex:none;display:flex;align-items:center;gap:6px;min-height:44px;padding:0 10px;border-radius:12px;background:var(--surface-2);border:2px solid transparent;color:var(--ink);font:600 12px var(--f-body);cursor:pointer}
.c6-pk-seat.me{border-color:var(--brass)}
.c6-pk-seat i{width:12px;height:12px;border-radius:50%;flex:none}
.c6-pk-seat small{display:block;font-size:11px;color:var(--muted);font-weight:500;max-width:120px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.c6-pk-tools{display:flex;gap:6px;align-items:center}
.c6-pk-tools input{flex:1;min-width:0;min-height:44px;border-radius:11px;border:1px solid rgba(255,255,255,.14);background:#141019;color:var(--ink);padding:0 12px;font:500 14px var(--f-body)}
.c6-pk-tools .btn{min-height:44px;flex:none;padding:0 12px}
.c6-pk-f{display:flex;gap:5px;overflow-x:auto}
.c6-pk-f button{flex:none;min-height:44px;padding:0 12px;border-radius:22px;border:0;background:#30283e;color:#eadcc0;font:600 12.5px var(--f-body);cursor:pointer}
.c6-pk-f button.on{background:var(--brass);color:#1c1408}
.c6-pk-l{flex:1;min-height:0;overflow-y:auto;padding:8px 10px 14px;display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:7px;align-content:start;align-items:start;-webkit-overflow-scrolling:touch}
.c6-pk-c{display:flex;flex-direction:column;gap:6px;padding:8px 10px;border-radius:13px;background:var(--surface-2);border:2px solid transparent;cursor:pointer;color:var(--ink);text-align:left;font:inherit;min-width:0}
.c6-pk-c.sel{border-color:var(--brass);background:#2e2a1c}
.c6-pk-c.taken{opacity:.45}
.c6-pk-c .hd{display:flex;align-items:center;gap:9px;min-height:40px}
.c6-pk-c .em{flex:none;width:40px;height:40px;border-radius:50%;display:grid;place-items:center;font:700 16px var(--f-body);color:#1a1208}
.c6-pk-c .tx{flex:1;min-width:0;display:flex;flex-direction:column}
.c6-pk-c .tx b{font-size:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.c6-pk-c .tx small{font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.c6-pk-c .vic{flex:none;font-size:15px;letter-spacing:1px}
.c6-pk-c .dt{display:flex;flex-direction:column;gap:5px;font-size:12px;line-height:1.4;color:#e6dcc8}
.c6-pk-c .dt b{color:#f0c35a;font-weight:700}
.c6-pk-c .dt .u{color:var(--muted)}
.c6-pk-c .dt .btn{min-height:44px;margin-top:2px}
.c6-pk-b{flex:none;display:flex;gap:6px;padding:8px 10px calc(8px + env(safe-area-inset-bottom));border-top:1px solid rgba(227,174,69,.22);background:rgba(12,10,18,.92)}
.c6-pk-b .btn{flex:1;min-height:46px;font-size:13.5px}
`;
  // 아이콘(직접 그린 단순한 도형)
  function glyph(c, k, x, y, s, col) {
    c.save(); c.translate(x, y); c.scale(s / 10, s / 10);
    c.fillStyle = col || '#f5ecd8'; c.strokeStyle = col || '#f5ecd8'; c.lineWidth = 1.6; c.lineCap = 'round'; c.lineJoin = 'round';
    const P = (pts, fill) => { c.beginPath(); pts.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); c.closePath(); fill === false ? c.stroke() : c.fill(); };
    const ln = (a, b, d, e) => { c.beginPath(); c.moveTo(a, b); c.lineTo(d, e); c.stroke(); };
    const ci = (a, b, r, f) => { c.beginPath(); c.arc(a, b, r, 0, 7); f === false ? c.stroke() : c.fill(); };
    switch (k) {
      case 'cam': P([[-5, 5], [5, 5], [2, -1], [2, -5], [-2, -5], [-2, -1]]); break;
      case 'hs': P([[-6, -1], [0, -6], [6, -1]]); c.fillRect(-4, -1, 2, 6); c.fillRect(2, -1, 2, 6); c.fillRect(-6, 4, 12, 1.6); break;
      case 'com': ci(0, 0, 5, false); c.font = 'bold 8px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('$', 0, 0.5); break;
      case 'th': c.beginPath(); c.arc(0, -1, 5, 0, Math.PI); c.fill(); c.fillRect(-5, -3, 10, 2); ci(-2, -0.5, 0.9); break;
      case 'ind': c.fillRect(-6, 0, 12, 5); c.fillRect(-5, -5, 2.4, 5); c.fillRect(-1, -3, 2.4, 3); P([[2, 0], [6, -3], [6, 0]]); break;
      case 'hb': ln(0, -5, 0, 5); ln(-4, -2, 4, -2); c.beginPath(); c.arc(0, 1, 4.5, 0.2, Math.PI - 0.2); c.stroke(); break;
      case 'enc': ln(-5, -5, 5, 5); ln(5, -5, -5, 5); ln(-5, 2, -2, 5); ln(5, 2, 2, 5); break;
      case 'ent': ci(0, -1, 4.5, false); ln(0, -1, 0, -5.5); ln(0, -1, 4, 1); ln(-3, 5, 0, -1); ln(3, 5, 0, -1); break;
      case 'wp': c.beginPath(); c.moveTo(-6, 3); c.quadraticCurveTo(-3, 0, 0, 3); c.quadraticCurveTo(3, 6, 6, 3); c.stroke(); ci(0, -3, 2.2); break;
      case 'aq': c.fillRect(-6, -4, 12, 2); for (const xx of [-5, -1, 3]) { c.fillRect(xx, -2, 2, 7); } break;
      case 'nb': P([[-5, 0], [-2, -3], [1, 0]]); c.fillRect(-4.5, 0, 5, 5); P([[0, -2], [3, -5], [6, -2]]); c.fillRect(1, -2, 4.5, 7); break;
      case 'sp': P([[0, -6], [2.5, -1], [2.5, 3], [-2.5, 3], [-2.5, -1]]); P([[-2.5, 1], [-5, 5], [-2.5, 3]]); P([[2.5, 1], [5, 5], [2.5, 3]]); break;
      case 'gov': P([[-6, -2], [0, -6], [6, -2]]); for (const xx of [-5, -1.5, 2]) c.fillRect(xx, -1, 2, 5); c.fillRect(-6, 4, 12, 1.6); break;
      case 'dq': ci(0, 0, 5, false); ln(-5, 0, 5, 0); c.beginPath(); c.ellipse(0, 0, 2.2, 5, 0, 0, 7); c.stroke(); break;
      case 'dam': c.fillRect(-6, -3, 12, 3); c.beginPath(); c.moveTo(-6, 3); c.quadraticCurveTo(-3, 1, 0, 3); c.quadraticCurveTo(3, 5, 6, 3); c.stroke(); break;
      case 'can': ln(-6, -2, 6, -2); ln(-6, 2, 6, 2); P([[-2, 0], [1, -1.4], [1, 1.4]]); break;
      case 'farm': for (const yy of [-4, 0, 4]) ln(-5, yy, 5, yy); break;
      case 'mine': ln(-4, 4, 3, -3); P([[1, -5], [5, -1], [3, -3]]); ln(-5, -4, 4, 5); break;
      case 'quarry': P([[-5, 4], [-2, -3], [5, 4]]); c.fillRect(-1, 0, 3, 2); break;
      case 'pasture': ln(-6, 0, 6, 0); ln(-6, 3, 6, 3); for (const xx of [-4, 0, 4]) ln(xx, -3, xx, 5); break;
      case 'plant': ci(0, -1, 3.5); ln(0, 2, 0, 6); ci(-3.5, 1, 1.6); ci(3.5, 1, 1.6); break;
      case 'camp': P([[-5, 5], [0, -5], [5, 5]], false); ln(0, -5, 0, 5); break;
      case 'fish': c.beginPath(); c.ellipse(-1, 0, 4, 2.5, 0, 0, 7); c.fill(); P([[2.5, 0], [6, -3], [6, 3]]); break;
      case 'lumber': for (const yy of [-3, 1]) { c.beginPath(); c.ellipse(0, yy, 5, 1.6, 0, 0, 7); c.fill(); } break;
      case 'oilwell': P([[-4, 5], [0, -6], [4, 5]], false); ln(-2, 0, 2, 0); break;
      case 'fort': c.fillRect(-5, -2, 10, 7); for (const xx of [-5, -1, 3]) c.fillRect(xx, -5, 2, 3); break;
      case 'resort': ci(0, -2, 3); c.beginPath(); c.moveTo(-6, 4); c.quadraticCurveTo(-3, 2, 0, 4); c.quadraticCurveTo(3, 6, 6, 4); c.stroke(); break;
      case 'solar': P([[-6, 3], [-3, -3], [6, -3], [3, 3]], false); ln(-4.5, 0, 4.5, 0); break;
      case 'wind': ln(0, -1, 0, 6); for (let a = 0; a < 3; a++) { const an = a * 2.094 - 1.57; ln(0, -1, Math.cos(an) * 5, -1 + Math.sin(an) * 5); } break;
      case 'bcamp': P([[-6, 5], [0, -5], [6, 5]]); c.fillStyle = '#3a0c0c'; P([[-2, 5], [0, 1], [2, 5]]); break;
      case 'goody': P([[-6, 5], [-3, -2], [0, 5]]); P([[0, 5], [3, -4], [6, 5]]); ci(0, -5, 1.6); break;
      case 'ant': c.fillRect(-5, 1, 10, 4); c.fillRect(-4, -4, 2, 5); c.fillRect(2, -5, 2, 6); break;
      case 'uimp': P([[0, -6], [1.8, -1.8], [6, -1.8], [2.6, 1.2], [3.8, 5.6], [0, 3], [-3.8, 5.6], [-2.6, 1.2], [-6, -1.8], [-1.8, -1.8]]); break;
      case 'won': P([[-6, -2], [0, -6], [6, -2]]); for (const xx of [-5, -2, 1, 4]) c.fillRect(xx, -1, 1.6, 5); c.fillRect(-6, 4, 12, 2); break;
      // 유닛 종류
      case 'settler': P([[-5, 2], [0, -4], [5, 2]]); c.fillRect(-3.5, 2, 7, 3.5); break;
      case 'builder': ln(-4, 5, 3, -2); c.fillRect(1, -5, 5, 3); break;
      case 'trader': ci(-3, 3, 2); ci(3, 3, 2); c.fillRect(-5, -3, 10, 5); break;
      case 'rel': c.fillRect(-1, -6, 2, 12); c.fillRect(-4, -3, 8, 2); break;
      case 'gp': P([[0, -6], [1.8, -1.8], [6, -1.8], [2.6, 1.2], [3.8, 5.6], [0, 3], [-3.8, 5.6], [-2.6, 1.2], [-6, -1.8], [-1.8, -1.8]]); break;
      case 'rec': ci(0, 0, 2.2); ci(0, 0, 5.2, false); ln(0, -6, 0, -4); ln(0, 4, 0, 6); ln(-6, 0, -4, 0); ln(4, 0, 6, 0); break;
      case 'mel': ln(-4, 5, 4, -4); ln(1, -5, 5, -1); ln(-5, 1, -1, 5); break;
      case 'rng': c.beginPath(); c.arc(-1, 0, 5.5, -1.2, 1.2); c.stroke(); ln(-4, 0, 6, 0); P([[6, 0], [3.5, -1.8], [3.5, 1.8]]); break;
      case 'ac': ln(-5, 6, 5, -6); P([[5, -6], [1.5, -5], [4, -2.5]]); ln(-3, -3, 3, 3); break;
      case 'lc': P([[-6, 4], [-4, -1], [1, -3], [3, -6], [5, -3], [3, -1], [3, 4], [1, 4], [0, 1], [-3, 1], [-4, 4]]); break;
      case 'hc': P([[-6, 4], [-4, -1], [1, -3], [3, -6], [5, -3], [3, -1], [3, 4], [1, 4], [0, 1], [-3, 1], [-4, 4]]); c.fillRect(-5, -5, 3, 3); break;
      case 'sg': ci(-2, 2.5, 3, false); c.fillRect(-1, -2, 7, 3); ln(-6, 5, 4, 5); break;
      case 'sup': c.fillRect(-1.5, -5, 3, 10); c.fillRect(-5, -1.5, 10, 3); break;
      case 'nm': c.beginPath(); c.moveTo(-6, 1); c.lineTo(6, 1); c.lineTo(4, 5); c.lineTo(-4, 5); c.closePath(); c.fill(); ln(0, 1, 0, -6); P([[0, -6], [4, -2], [0, -2]]); break;
      case 'nr': c.beginPath(); c.moveTo(-6, 1); c.lineTo(6, 1); c.lineTo(4, 5); c.lineTo(-4, 5); c.closePath(); c.fill(); c.fillRect(-2, -3, 4, 4); ln(1, -2, 6, -4); break;
      case 'nrd': c.beginPath(); c.ellipse(0, 1, 6, 2.6, 0, 0, 7); c.fill(); c.fillRect(-1, -3, 2.4, 3); break;
      case 'city': c.fillRect(-5, -1, 10, 6); for (const xx of [-5, -1, 3]) c.fillRect(xx, -4, 2, 3); break;
      case 'air': P([[0, -6], [1.2, -1], [6, 1.5], [6, 3], [1.2, 1.8], [0.8, 4.5], [2.6, 6], [-2.6, 6], [-0.8, 4.5], [-1.2, 1.8], [-6, 3], [-6, 1.5], [-1.2, -1]]); break;
      case 'mileng': c.fillRect(-5, 2, 10, 3); ln(-3, 2, 0, -5); ln(3, 2, 0, -5); break;
      case 'archaeo': ln(-4, 5, 2, -1); c.beginPath(); c.arc(3, -3, 3, 0, 7); c.stroke(); break;
      case 'spy': ci(0, -2, 3); c.fillRect(-5, -1, 10, 1.6); P([[-4, 5], [0, 1], [4, 5]]); break;
      default: ci(0, 0, 3.5);
    }
    c.restore();
  }
  const UGLY = (T) => (T.cl === 'civ' ? T.k : T.cl);
  function hexCol(hx, f) { const n = parseInt(hx.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255; r = Math.round(clamp(r * f, 0, 255)); g = Math.round(clamp(g * f, 0, 255)); b = Math.round(clamp(b * f, 0, 255)); return 'rgb(' + r + ',' + g + ',' + b + ')'; }
  function lum(hx) { const n = parseInt(hx.slice(1), 16); return ((n >> 16) * 0.3 + ((n >> 8) & 255) * 0.59 + (n & 255) * 0.11) / 255; }

  function mount(root, api) {
    if (!document.getElementById('c6-style')) document.head.appendChild(L.h('style', { id: 'c6-style', text: CSS }));
    const h = L.h;
    const spd = () => ((L.debug && L.debug.speed) || 1) * ((L.speed && L.speed()) || 1);
    // PC(마우스·넓은 창)에서는 가운데 760px 기둥 대신 창 전체를 써요(나갈 때 되돌림)
    const de = document.documentElement;
    const widen = !de.classList.contains('landscape-game') && window.matchMedia && window.matchMedia('(pointer:fine)').matches && window.innerWidth >= 1000;
    if (widen) de.classList.add('landscape-game');
    const wrap = h('div', { class: 'c6' });
    const mapEl = h('div', { class: 'c6-map' });
    wrap.appendChild(mapEl); root.appendChild(wrap);
    const cvs = U.canvas(mapEl), cx = cvs.ctx;
    // 위쪽
    const top = h('div', { class: 'c6-top' });
    const row1 = h('div'), row2 = h('div');
    const chipT = h('button', { class: 'c6-chip c6-res', 'data-action': 'tech', onclick: () => openSheet('tech') });
    const chipC = h('button', { class: 'c6-chip c6-res', 'data-action': 'civics', onclick: () => openSheet('civic') });
    const chipS = h('button', { class: 'c6-chip c6-stat', onclick: () => openSheet('overview') });
    row1.append(chipT, chipC); row2.append(chipS); top.append(row1, row2);
    // 왼쪽 버튼
    const side = h('div', { class: 'c6-side' });
    const bMenu = h('button', { 'aria-label': '메뉴', text: '☰', 'data-action': 'menu', onclick: () => openSheet('menu') });
    const bNote = h('button', { 'aria-label': '알림', text: '🔔', onclick: () => openSheet('notes') });
    const bDip = h('button', { 'aria-label': '외교', text: '🤝', 'data-action': 'dip', onclick: () => openSheet('dip') });
    const bZin = h('button', { 'aria-label': '확대', text: '+', 'data-action': 'zin', onclick: () => zoomBy(1.25) });
    const bZout = h('button', { 'aria-label': '축소', text: '−', 'data-action': 'zout', onclick: () => zoomBy(0.8) });
    const bHome = h('button', { 'aria-label': '내 수도로', text: '⌖', onclick: () => centerHome(true) });
    side.append(bMenu, bNote, bDip, bZin, bZout, bHome);
    const mini = h('canvas', { class: 'c6-mini' });
    const bot = h('div', { class: 'c6-bot' });
    const waitEl = h('div', { class: 'c6-wait', hidden: true });
    const tipEl = h('div', { class: 'c6-tip', hidden: true });
    wrap.append(top, side, mini, bot, waitEl, tipEl);
    let pickEl = null, pickBar = null; const pk = { q: '', f: '', open: -1, seat: -1, sc: 0 };

    let hoverI = -1, banners = [];
    let st = null, G = null, me = -1, seeAll = false, hideAll = false, vis = null, ex = null;
    let sel = null, RR = null, TG = [], pend = null, mode = null, sheet = null, modal = null;
    let anim = [], animT = 0, floats = [], busy = false, dirtyF = true, shake = 0, lastL = -1;
    let terr = null, terrKey = '', bordKey = '', bord = [], miniKey = '';
    const cam = { x: 0, y: 0, z: 1, tx: null, ty: null };
    const RAD = 20, HW = Math.sqrt(3) * RAD, PAD = 14;
    // 이웃 방향 k(동,남동,남서,서,북서,북동)의 변 양 끝 각도
    const EDGE = [[-30, 30], [30, 90], [90, 150], [150, 210], [210, 270], [270, 330]];
    let wox = 0;   // 동서 연결 지도: 지금 그리는 복사본의 x 이동
    const PW = () => HW * st.W;
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    const col = (o) => { if (o < 0 || !st) return '#999'; if (o < st.nM) return (api.players[o] && api.players[o].color) || '#ccc'; const p = st.P[o]; if (!p) return '#999'; if (p.k === 'cs') return CST[CSL[p.cs].t][3]; if (p.k === 'fc') return '#8f96a3'; return '#5b4a3a'; };
    const myTurn = () => st && st.ph !== 'e' && st.cur === me && api.canAct(me) && !hideAll;
    const act = (a) => { if (!myTurn()) return; api.act(a); };
    const wide = () => cvs.w >= 860;

    function centerOf(i) { const r = (i / st.W) | 0, c = i % st.W; return { x: HW * (c + 0.5 * (r & 1)) + HW / 2 + PAD, y: 1.5 * RAD * r + RAD + PAD }; }
    function worldSize() { return { w: HW * (st.W + 0.5) + PAD * 2, h: 1.5 * RAD * (st.H - 1) + RAD * 2 + PAD * 2 }; }
    function viewArea() {
      const tH = top.offsetHeight + 10, bH = sheet && !wide() ? Math.max(bot.offsetHeight, sheet.el.offsetHeight) : bot.offsetHeight;
      const rW = sheet && wide() ? sheet.el.offsetWidth + 12 : 0;
      return { cx: (cvs.w - rW) / 2, cy: tH + (cvs.h - tH - bH) / 2, tH, bH, rW };
    }
    function toScreen(x, y) { const v = viewArea(); return { x: (x + wox - cam.x) * cam.z + v.cx, y: (y - cam.y) * cam.z + v.cy }; }
    function toWorld(x, y) { const v = viewArea(); return { x: (x - v.cx) / cam.z + cam.x, y: (y - v.cy) / cam.z + cam.y }; }
    function clampCam() {
      if (!st) return;
      const ws = worldSize();
      cam.z = clamp(cam.z, 0.45, 2.6);
      const m = 60 / cam.z;
      if (st.wr) { const pw = PW(); if (cam.x < 0 || cam.x > pw) { const sh = Math.floor(cam.x / pw) * pw; cam.x -= sh; if (cam.tx != null) cam.tx -= sh; if (drag) drag.cx -= sh; } }
      else cam.x = clamp(cam.x, -m, ws.w + m);
      cam.y = clamp(cam.y, -m, ws.h + m);
    }
    function pick(sx, sy) {
      const w = toWorld(sx, sy);
      const r0 = Math.round((w.y - RAD - PAD) / (1.5 * RAD));
      let best = -1, bd = 1e9;
      for (let r = r0 - 1; r <= r0 + 1; r++) {
        if (r < 0 || r >= st.H) continue;
        const c0 = Math.round((w.x - PAD - HW / 2) / HW - 0.5 * (r & 1));
        for (let c = c0 - 1; c <= c0 + 1; c++) {
          let cc = c; if (st.wr) cc = ((c % st.W) + st.W) % st.W; else if (c < 0 || c >= st.W) continue;
          const p = centerOf(r * st.W + cc), px = p.x + (c - cc) * HW, d = (px - w.x) ** 2 + (p.y - w.y) ** 2; if (d < bd) { bd = d; best = r * st.W + cc; }
        }
      }
      return bd <= RAD * RAD * 1.15 ? best : -1;
    }
    function hexPath(c, x, y, r) { c.beginPath(); for (let k = 0; k < 6; k++) { const a = Math.PI / 180 * (60 * k - 30); const px = x + r * Math.cos(a), py = y + r * Math.sin(a); if (k) c.lineTo(px, py); else c.moveTo(px, py); } c.closePath(); }
    function hsh(i, k) { let x = (i * 374761393 + k * 668265263 + 977) | 0; x = (x ^ (x >>> 13)) * 1274126177; return ((x ^ (x >>> 16)) >>> 0) / 4294967296; }
    const isVis = (i) => seeAll || (vis && vis[i] === 1);
    const isEx = (i) => seeAll || (ex && ex[i] === 1);

    /* ---------- 지형 층 ---------- */
    function strHash(s) { let x = 5381; for (let i = 0; i < s.length; i++) x = ((x << 5) + x + s.charCodeAt(i)) | 0; return x; }
    function buildTerrain() {
      const resK = me >= 0 && st.P[me] ? STRAT.map((r) => (resVisible(G, me, r) ? 1 : 0)).join('') : 'all';
      const key = strHash(st.mt + st.mf + st.mr + st.im + (st.pl || '') + st.ds + JSON.stringify(st.wn) + st.rd + JSON.stringify(st.fy) + (st.re || '')) + '|' + resK + '|' + st.W + '|' + (me >= 0 && st.P[me] && hasCivic(G, me, 'naturalHist') ? 1 : 0);
      if (key === terrKey && terr) return;
      terrKey = key;
      const ws = worldSize(), TSc = Math.min(2, 2700 / ws.w) * Math.min(1.5, (cvs.dpr || 1));
      if (!terr) terr = document.createElement('canvas');
      terr.width = Math.ceil(ws.w * TSc); terr.height = Math.ceil(ws.h * TSc); terr.ts = TSc;
      const c = terr.getContext('2d');
      c.setTransform(TSc, 0, 0, TSc, 0, 0);
      c.clearRect(0, 0, ws.w, ws.h);
      if (!st.wr) { c.fillStyle = '#0c1018'; c.fillRect(0, 0, ws.w, ws.h); }
      const N = G.N;
      for (let i = 0; i < N; i++) {
        const p = centerOf(i), t = G.ter[i];
        let base = TER[t].col;
        const f = G.feat[i];
        if (f === F_ICE) base = '#d9e8f0';
        const g = c.createLinearGradient(p.x, p.y - RAD, p.x, p.y + RAD);
        const v = 0.94 + hsh(i, 1) * 0.12;
        g.addColorStop(0, hexCol(base, v * 1.1)); g.addColorStop(1, hexCol(base, v * 0.86));
        hexPath(c, p.x, p.y, RAD + 0.5); c.fillStyle = g; c.fill();
        if (G.low[i] && isLand(G, i)) { c.fillStyle = 'rgba(60,120,170,' + (0.08 * (4 - G.low[i])) + ')'; hexPath(c, p.x, p.y, RAD); c.fill(); }
        c.strokeStyle = 'rgba(0,0,0,.18)'; c.lineWidth = 0.7; hexPath(c, p.x, p.y, RAD); c.stroke();
        deco(c, i, p.x, p.y);
      }
      // 강: 칸 사이 변을 따라 그려요
      c.lineCap = 'round';
      for (let i = 0; i < N; i++) {
        const e = G.re[i]; if (!e) continue;
        const p = centerOf(i);
        for (let k = 0; k < 3; k++) {
          if (!((e >> k) & 1)) continue;
          const a1 = EDGE[k][0] * Math.PI / 180, a2 = EDGE[k][1] * Math.PI / 180;
          const x1 = p.x + RAD * Math.cos(a1), y1 = p.y + RAD * Math.sin(a1), x2 = p.x + RAD * Math.cos(a2), y2 = p.y + RAD * Math.sin(a2);
          const mx = (x1 + x2) / 2 + (hsh(i, k + 7) - 0.5) * 4, my = (y1 + y2) / 2 + (hsh(i, k + 11) - 0.5) * 4;
          c.strokeStyle = '#2f7fbf'; c.lineWidth = 4.2; c.beginPath(); c.moveTo(x1, y1); c.quadraticCurveTo(mx, my, x2, y2); c.stroke();
          c.strokeStyle = 'rgba(170,220,250,.6)'; c.lineWidth = 1.4; c.stroke();
        }
      }
      // 도로·철도
      for (let i = 0; i < N; i++) {
        if (!G.road[i]) continue;
        const p = centerOf(i);
        for (let k = 0; k < 3; k++) {
          const j = G.g.nb6[i][k]; if (j < 0 || !G.road[j]) continue;
          const q = centerOf(j); if (Math.abs(q.x - p.x) > HW * 1.5) continue;
          const rail = G.road[i] >= 2 && G.road[j] >= 2;
          c.strokeStyle = rail ? 'rgba(40,36,44,.85)' : 'rgba(150,115,70,.75)'; c.lineWidth = rail ? 3 : 2.4; c.beginPath(); c.moveTo(p.x, p.y); c.lineTo(q.x, q.y); c.stroke();
          if (rail) { c.strokeStyle = 'rgba(200,190,170,.7)'; c.lineWidth = 1; for (let t = 0.2; t < 1; t += 0.3) { const x = p.x + (q.x - p.x) * t, y = p.y + (q.y - p.y) * t, nx = -(q.y - p.y) / HW * 3, ny = (q.x - p.x) / HW * 3; c.beginPath(); c.moveTo(x - nx, y - ny); c.lineTo(x + nx, y + ny); c.stroke(); } }
        }
      }
      // 구역·개선·자원(위에)
      const seeAnt = me < 0 || !st.P[me] || hasCivic(G, me, 'naturalHist');
      for (let i = 0; i < N; i++) {
        const p = centerOf(i);
        const d = G.dis[i];
        if (d && DIS[d].k !== 'cc') {
          const D = DIS[d];
          hexPath(c, p.x, p.y, RAD * 0.82); c.fillStyle = hexCol(D.col, G.dpil[i] ? 0.45 : 0.75); c.fill();
          c.strokeStyle = hexCol(D.col, 1.25); c.lineWidth = 1.6; hexPath(c, p.x, p.y, RAD * 0.82); c.stroke();
          glyph(c, D.k, p.x, p.y, RAD * 0.55, G.dpil[i] ? '#888' : '#fff8e6');
          if (G.dpil[i]) fireMark(c, p.x + 7, p.y - 7);
        }
        if (G.won[i]) {
          hexPath(c, p.x, p.y, RAD * 0.8); c.fillStyle = 'rgba(60,40,10,.75)'; c.fill(); c.strokeStyle = '#f0c35a'; c.lineWidth = 2; c.stroke();
          glyph(c, 'won', p.x, p.y, RAD * 0.6, '#f6d27a');
        }
        if (G.imp[i] && !(IMP[G.imp[i]].k === 'ant' && !seeAnt)) {
          const m = IMP[G.imp[i]];
          const k = m.civ ? 'uimp' : m.k;
          c.fillStyle = 'rgba(15,10,20,.5)'; c.beginPath(); c.arc(p.x - RAD * 0.42, p.y + RAD * 0.38, 6.2, 0, 7); c.fill();
          glyph(c, k, p.x - RAD * 0.42, p.y + RAD * 0.38, 9, G.pil[i] ? '#9a8a7a' : m.k === 'bcamp' ? '#ff7a5a' : m.k === 'goody' ? '#ffe08a' : m.k === 'ant' ? '#d8c6a0' : '#f7eccf');
          if (G.pil[i]) fireMark(c, p.x - RAD * 0.42 + 5, p.y + RAD * 0.38 - 5);
        }
        const r = G.res[i];
        if (r && (me < 0 || resVisible(G, me, r))) resIcon(c, r, p.x + RAD * 0.42, p.y + RAD * 0.36);
      }
    }
    function fireMark(c, x, y) { c.fillStyle = '#ff7a3a'; c.beginPath(); c.moveTo(x, y + 4); c.quadraticCurveTo(x - 4, y, x, y - 5); c.quadraticCurveTo(x + 4, y, x, y + 4); c.fill(); }
    function deco(c, i, x, y) {
      const t = G.ter[i], f = G.feat[i], r = (k) => hsh(i, k);
      if (G.hill[i] && t !== TM) {
        for (const [dx, dy, s] of [[-0.32, 0.18, 1], [0.28, -0.08, 0.85]]) { const px = x + dx * RAD, py = y + dy * RAD + 4, w = 9 * s; c.fillStyle = 'rgba(60,45,25,.38)'; c.beginPath(); c.ellipse(px, py, w, w * 0.6, 0, Math.PI, 0); c.fill(); c.fillStyle = 'rgba(240,220,170,.28)'; c.beginPath(); c.ellipse(px - 2, py - 1, w * 0.55, w * 0.36, 0, Math.PI, 0); c.fill(); }
      }
      if (t === TM || (f >= NW0 && NW[f - NW0].mtn)) {
        const nw = f >= NW0 ? NW[f - NW0] : null;
        for (const [dx, s] of [[-0.3, 0.9], [0.24, 1.15]]) { const px = x + dx * RAD, py = y + 7, w = 9 * s, hh = 15 * s; c.fillStyle = nw ? '#6d5a7d' : '#5b5360'; c.beginPath(); c.moveTo(px - w, py); c.lineTo(px, py - hh); c.lineTo(px + w, py); c.closePath(); c.fill(); c.fillStyle = '#7b7381'; c.beginPath(); c.moveTo(px, py - hh); c.lineTo(px + w, py); c.lineTo(px + 1, py); c.closePath(); c.fill(); c.fillStyle = f === F_VOLC || (nw && nw.volc) ? '#e8642c' : '#eee8f0'; c.beginPath(); c.moveTo(px, py - hh); c.lineTo(px + w * 0.36, py - hh * 0.62); c.lineTo(px - w * 0.36, py - hh * 0.62); c.closePath(); c.fill(); }
      }
      if (f === F_WOODS) for (const [dx, dy] of [[-0.42, 0.1], [0.05, -0.32], [0.4, 0.12], [-0.05, 0.4]]) { const px = x + dx * RAD + (r(3) - 0.5) * 3, py = y + dy * RAD; c.fillStyle = '#4a3420'; c.fillRect(px - 0.8, py + 3, 1.6, 3); c.fillStyle = t === TT ? '#2f5a44' : '#244f2c'; c.beginPath(); c.moveTo(px, py - 7); c.lineTo(px + 5, py + 4); c.lineTo(px - 5, py + 4); c.closePath(); c.fill(); }
      else if (f === F_RAIN) for (const [dx, dy] of [[-0.4, 0.05], [0.1, -0.3], [0.38, 0.2], [-0.05, 0.38]]) { const px = x + dx * RAD, py = y + dy * RAD; c.fillStyle = '#1d5a26'; c.beginPath(); c.arc(px, py, 5, 0, 7); c.fill(); c.fillStyle = 'rgba(120,200,90,.35)'; c.beginPath(); c.arc(px - 1.5, py - 1.5, 2, 0, 7); c.fill(); }
      else if (f === F_MARSH) { c.strokeStyle = 'rgba(40,70,50,.7)'; c.lineWidth = 1; for (let k = 0; k < 5; k++) { const px = x + (r(k + 2) - 0.5) * RAD * 1.2, py = y + (r(k + 9) - 0.5) * RAD; c.beginPath(); c.moveTo(px, py + 3); c.lineTo(px - 1.5, py - 3); c.moveTo(px, py + 3); c.lineTo(px + 1.5, py - 3); c.stroke(); } c.fillStyle = 'rgba(70,120,140,.35)'; c.beginPath(); c.ellipse(x, y + 4, 8, 3, 0, 0, 7); c.fill(); }
      else if (f === F_FLOOD) { c.strokeStyle = 'rgba(120,90,40,.35)'; c.lineWidth = 1; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(x - 10, y - 6 + k * 6); c.lineTo(x + 10, y - 6 + k * 6); c.stroke(); } }
      else if (f === F_OASIS) { c.fillStyle = '#4fb0d8'; c.beginPath(); c.ellipse(x, y + 3, 7, 3.5, 0, 0, 7); c.fill(); c.fillStyle = '#2d8a3a'; c.beginPath(); c.arc(x - 3, y - 3, 3, 0, 7); c.arc(x + 3, y - 4, 3, 0, 7); c.fill(); }
      else if (f === F_REEF) { c.fillStyle = 'rgba(240,140,150,.55)'; for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(x + (r(k) - 0.5) * RAD, y + (r(k + 5) - 0.5) * RAD * 0.8, 2.2, 0, 7); c.fill(); } }
      else if (f === F_VSOIL) { c.fillStyle = 'rgba(40,30,30,.35)'; for (let k = 0; k < 5; k++) { c.beginPath(); c.arc(x + (r(k) - 0.5) * RAD * 1.1, y + (r(k + 5) - 0.5) * RAD, 1.6, 0, 7); c.fill(); } }
      if (f >= NW0) {
        const nw = NW[f - NW0];
        if (!nw.mtn) { c.fillStyle = nw.water ? 'rgba(120,240,230,.5)' : 'rgba(250,250,240,.6)'; c.beginPath(); c.arc(x, y, 8, 0, 7); c.fill(); }
        c.strokeStyle = '#ffe9a0'; c.lineWidth = 2; hexPath(c, x, y, RAD * 0.9); c.stroke();
      }
      if (TER[t].water && !f) { c.strokeStyle = 'rgba(190,225,255,.16)'; c.lineWidth = 1; for (let k = 0; k < 2; k++) { const px = x + (r(k + 4) - 0.5) * RAD, py = y + (k ? 5 : -4); c.beginPath(); c.moveTo(px - 5, py); c.quadraticCurveTo(px - 2.5, py - 2.5, px, py); c.quadraticCurveTo(px + 2.5, py + 2.5, px + 5, py); c.stroke(); } }
      if (t === TD && !f && !G.hill[i]) { c.strokeStyle = 'rgba(150,110,50,.35)'; c.lineWidth = 1; for (let k = 0; k < 2; k++) { const py = y - 4 + k * 8, px = x + (r(k + 6) - 0.5) * 8; c.beginPath(); c.moveTo(px - 7, py); c.quadraticCurveTo(px, py - 3, px + 7, py); c.stroke(); } }
      if (t === TS) { c.fillStyle = 'rgba(255,255,255,.4)'; c.beginPath(); c.arc(x + (r(1) - 0.5) * 10, y + (r(2) - 0.5) * 8, 4, 0, 7); c.fill(); }
    }
    const RCOL = { b: '#cfe8a8', l: '#f0b8e8', s: '#a8c8f0' };
    function resIcon(c, r, x, y) {
      const R2 = RES[r];
      c.fillStyle = 'rgba(12,8,18,.62)'; c.beginPath(); c.arc(x, y, 6, 0, 7); c.fill();
      c.strokeStyle = RCOL[R2.c]; c.lineWidth = 1.2; c.beginPath(); c.arc(x, y, 6, 0, 7); c.stroke();
      c.fillStyle = RCOL[R2.c]; c.font = 'bold 7px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText(R2.n[0], x, y + 0.5);
    }

    /* ---------- 국경 ---------- */
    function buildBorders() {
      const key = st.ow + '|' + st.C.map((c) => c.o).join(',');
      if (key === bordKey) return;
      bordKey = key; bord = [];
      for (let i = 0; i < G.N; i++) {
        const oc = G.own[i]; if (oc < 0 || !G.cid[oc]) continue;
        const ow = G.cid[oc].o;
        const nb6 = G.g.nb6[i];
        for (let k = 0; k < 6; k++) {
          const j = nb6[k];
          const oj = j >= 0 && G.own[j] >= 0 && G.cid[G.own[j]] ? G.cid[G.own[j]].o : -1;
          if (oj === ow) continue;
          bord.push([i, k, ow]);
        }
      }
    }

    /* ---------- 그리기 ---------- */
    function draw(now) {
      const c = cx;
      cvs.clear();
      c.fillStyle = '#0a1018'; c.fillRect(0, 0, cvs.w, cvs.h);
      if (!G) return;
      buildTerrain(); buildBorders();
      let sx = 0, sy = 0;
      if (shake > 0) { const fx = (L.fx ? L.fx() : 1) * shake; sx = (Math.random() - 0.5) * 8 * fx; sy = (Math.random() - 0.5) * 8 * fx; }
      c.save(); c.translate(sx, sy);
      const ws = worldSize();
      c.imageSmoothingEnabled = true;
      const offs = [0];
      if (st.wr) { const pw = PW(), vw = cvs.w / cam.z; for (let k = -2; k <= 2; k++) { if (!k) continue; const lo = k * pw - cam.x, hi = lo + ws.w; if (hi * cam.z > -cvs.w && lo * cam.z < cvs.w) offs.push(k * pw); } }
      banners = [];
      for (const off of offs) { wox = off; drawPass(c, now, ws); }
      wox = 0;
      // 선택한 칸
      c.restore();
    }
    function drawPass(c, now, ws) {
      const o0 = toScreen(0, 0);
      c.drawImage(terr, o0.x, o0.y, ws.w * cam.z, ws.h * cam.z);
      const z = cam.z, rr = RAD * z;
      const inView = (p) => p.x > -rr * 3 && p.y > -rr * 3 && p.x < cvs.w + rr * 3 && p.y < cvs.h + rr * 3;
      const P = (i) => { const w = centerOf(i); return toScreen(w.x, w.y); };
      // 국경
      c.lineCap = 'round';
      for (const [i, k, ow] of bord) {
        if (!isEx(i)) continue;
        const p = P(i); if (!inView(p)) continue;
        const a1 = EDGE[k][0] * Math.PI / 180, a2 = EDGE[k][1] * Math.PI / 180, r2 = rr - 2.2 * z;
        c.strokeStyle = col(ow); c.lineWidth = Math.max(2, 3 * z); c.globalAlpha = 0.95;
        c.beginPath(); c.moveTo(p.x + r2 * Math.cos(a1), p.y + r2 * Math.sin(a1)); c.lineTo(p.x + r2 * Math.cos(a2), p.y + r2 * Math.sin(a2)); c.stroke();
        c.globalAlpha = 0.22; c.lineWidth = Math.max(4, 7 * z); c.stroke(); c.globalAlpha = 1;
      }
      // 도시 화면: 일하는 칸·영토
      const sc = sheet && sheet.kind === 'city' ? G.cid[sheet.arg] : null;
      if (sc) {
        for (const j of within(G.g, sc.p, 3)) {
          const p = P(j);
          if (G.own[j] === sc.id) { if ((sc.wk || []).indexOf(j) >= 0) { c.fillStyle = 'rgba(255,236,170,.22)'; hexPath(c, p.x, p.y, rr * 0.88); c.fill(); c.fillStyle = (sc.lk || []).indexOf(j) >= 0 ? '#ffd24a' : '#fff1c4'; c.beginPath(); c.arc(p.x, p.y - rr * 0.5, 3.4 * z, 0, 7); c.fill(); } }
          else if (mode && mode.k === 'buy' && canBuyTile(G, sc, j)) { c.fillStyle = 'rgba(240,200,80,.18)'; hexPath(c, p.x, p.y, rr * 0.85); c.fill(); label(c, '💰' + tileBuyCost(G, sc, j), p.x, p.y, 10 * Math.max(0.8, z)); }
        }
      }
      if (mode && (mode.k === 'air' || mode.k === 'nuke')) {
        const nk = mode.k === 'nuke';
        for (const j of mode.sites) { const p = P(j); if (!inView(p)) continue; c.fillStyle = mode.sel === j ? (nk ? 'rgba(255,90,40,.45)' : 'rgba(120,200,255,.4)') : (nk ? 'rgba(255,90,40,.16)' : 'rgba(120,200,255,.16)'); hexPath(c, p.x, p.y, rr * 0.86); c.fill(); }
        if (nk && mode.sel != null) for (const j of within(G.g, mode.sel, mode.kk === 't' ? 2 : 1)) { const p = P(j); c.strokeStyle = '#ff6a3a'; c.lineWidth = 2; hexPath(c, p.x, p.y, rr * 0.9); c.stroke(); }
      }
      // 교역로
      for (const tr of trLines()) { const k2 = Math.floor((now / 450) % tr.length), pc = P(tr[k2]); if (inView(pc)) label(c, '🐪', pc.x, pc.y - rr * 0.3, 11 * Math.max(0.8, z)); }
      if (trLines().length) dirtyF = true;
      for (const tr of trLines()) { c.strokeStyle = 'rgba(240,200,90,.75)'; c.setLineDash([5 * z, 5 * z]); c.lineWidth = Math.max(1.5, 2.2 * z); c.beginPath(); tr.forEach((j, n) => { const p = P(j); n ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y); }); c.stroke(); c.setLineDash([]); }
      // 낙진
      if (st.FO) for (const k in st.FO) { const p = P(+k); if (!inView(p) || !isEx(+k)) continue; c.fillStyle = 'rgba(170,220,60,.28)'; hexPath(c, p.x, p.y, rr * 0.92); c.fill(); label(c, '☢', p.x, p.y, 12 * Math.max(0.8, z), '#e8ff8a'); }
      // 배치 모드
      if (mode && mode.k === 'place') {
        for (const j of mode.sites) {
          const p = P(j); c.fillStyle = mode.sel === j ? 'rgba(120,230,120,.4)' : 'rgba(120,230,120,.18)'; hexPath(c, p.x, p.y, rr * 0.86); c.fill();
          c.strokeStyle = '#8fe08f'; c.lineWidth = mode.sel === j ? 3 : 1.4; hexPath(c, p.x, p.y, rr * 0.84); c.stroke();
          if (mode.it.t === 'd' && DIS[DISI[mode.it.k]].y >= 0) label(c, '+' + adjBonus(G, me, j, mode.it.k), p.x, p.y, 12 * Math.max(0.8, z));
        }
      }
      // 이동·공격 범위
      if (RR && !mode) for (const k in RR) { const p = P(+k); if (!inView(p)) continue; c.fillStyle = RR[k] > 0 ? 'rgba(255,248,220,.22)' : 'rgba(255,248,220,.12)'; hexPath(c, p.x, p.y, rr * 0.9); c.fill(); c.strokeStyle = 'rgba(255,240,200,.5)'; c.lineWidth = 1.1; hexPath(c, p.x, p.y, rr * 0.88); c.stroke(); }
      // 안개
      if (!seeAll) {
        const v = viewArea();
        for (let i = 0; i < G.N; i++) {
          const p = P(i); if (!inView(p)) continue;
          if (hideAll || !isEx(i)) { c.fillStyle = '#100d17'; hexPath(c, p.x, p.y, rr + 0.9); c.fill(); c.strokeStyle = 'rgba(160,140,190,.06)'; c.lineWidth = 1; hexPath(c, p.x, p.y, rr * 0.92); c.stroke(); }
          else if (!isVis(i)) { c.fillStyle = 'rgba(10,8,16,.45)'; hexPath(c, p.x, p.y, rr + 0.6); c.fill(); }
        }
      }
      if (hideAll) return;
      // 대상
      for (const j of TG) { const p = P(j); c.strokeStyle = pend && pend.to === j ? '#ff4a2c' : 'rgba(255,90,60,.9)'; c.lineWidth = pend && pend.to === j ? 3.6 : 2.2; hexPath(c, p.x, p.y, rr * 0.84); c.stroke(); }
      // 이동 명령 경로
      if (pend && pend.k === 'go' && pend.path) {
        c.strokeStyle = 'rgba(255,240,180,.85)'; c.setLineDash([6, 5]); c.lineWidth = 2.4; c.beginPath();
        pend.path.forEach((j, n) => { const p = P(j); n ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y); }); c.stroke(); c.setLineDash([]);
        const e = P(pend.to); label(c, pend.turns + '턴', e.x, e.y - rr * 0.7, 11);
      }
      // 도시
      for (const cc2 of G.C) { if (!isEx(cc2.p)) continue; const p = P(cc2.p); if (inView(p)) drawCity(c, cc2, p.x, p.y, z); }
      // 유닛
      const hide = {};
      for (const a of anim) if (a.k === 'm') hide[a.u] = 1;
      const stacks = {};
      const airs = {};
      for (const u of G.U) { if (!isVis(u.p) || hide[u.id]) continue; if (isAir(u.t)) { (airs[u.p] = airs[u.p] || []).push(u); continue; } (stacks[u.p] = stacks[u.p] || []).push(u); }
      for (const k in airs) { const p = P(+k); if (!inView(p)) continue; const a0 = airs[k], x = p.x + rr * 0.58, y = p.y - rr * 0.62, cl = col(a0[0].o), selA = sel && sel.k === 'u' && a0.some((u) => u.id === sel.id); c.fillStyle = 'rgba(12,10,18,.8)'; c.beginPath(); c.arc(x, y, 8.5 * Math.max(0.8, z), 0, 7); c.fill(); c.strokeStyle = selA ? '#fff' : cl; c.lineWidth = 2; c.stroke(); glyph(c, 'air', x, y, 9 * Math.max(0.8, z), '#e8f0ff'); if (a0.length > 1) label(c, String(a0.length), x + 9 * z, y - 7 * z, 9); }
      for (const k in stacks) {
        const p = P(+k); if (!inView(p)) continue;
        const arr = stacks[k].sort((a, b) => (isMil(a.t) ? 1 : 0) - (isMil(b.t) ? 1 : 0));
        const inCity = G.cat[+k] >= 0;
        const show = arr.slice(-3);
        show.forEach((u, n) => { const off = show.length > 1 ? (n - (show.length - 1) / 2) * rr * 0.62 : 0; drawUnit(c, u, p.x + off, p.y + (inCity ? rr * 0.42 : 0) - (show.length > 1 ? 2 : 0), z, sel && sel.k === 'u' && sel.id === u.id); });
        if (arr.length > 3) label(c, '+' + (arr.length - 3), p.x + rr * 0.9, p.y + (inCity ? rr * 0.42 : 0) - rr * 0.5, 10);
      }
      // 애니메이션
      for (const a of anim) if (a.t0 <= now) drawAnim(c, a, now, z);
      for (const f of floats) { const t = (now - f.t0) / f.d; if (t < 0 || t > 1) continue; const p = P(f.p); c.globalAlpha = 1 - t * t; label(c, f.s, p.x, p.y - rr * 0.6 - t * 18, 13, f.c); c.globalAlpha = 1; }
      // 선택한 칸
      if (sel && sel.k === 't') { const p = P(sel.p); c.strokeStyle = '#f0c35a'; c.lineWidth = 2.6; hexPath(c, p.x, p.y, rr * 0.93); c.stroke(); }
      if (sel && sel.k === 'u' && G.uid[sel.id]) { const p = P(G.uid[sel.id].p); const pulse = 0.55 + 0.45 * Math.sin(now / 240); c.strokeStyle = 'rgba(240,195,90,' + pulse + ')'; c.lineWidth = 3; hexPath(c, p.x, p.y, rr * 0.95); c.stroke(); }
    }
    function label(c, s, x, y, size, color) {
      c.font = '700 ' + size + 'px ' + 'IBM Plex Sans KR, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
      c.lineWidth = Math.max(2.5, size * 0.28); c.strokeStyle = 'rgba(10,6,14,.85)'; c.strokeText(s, x, y); c.fillStyle = color || '#fff6dc'; c.fillText(s, x, y);
    }
    function drawCity(c, cc2, x, y, z) {
      const o = cc2.o, cl = col(o), rr = RAD * z;
      // 도심 건물
      hexPath(c, x, y, rr * 0.86); c.fillStyle = hexCol(cl, 0.42); c.fill();
      c.strokeStyle = cl; c.lineWidth = 2.2; hexPath(c, x, y, rr * 0.86); c.stroke();
      for (const [dx, dy, w, hh] of [[-0.42, 0.05, 0.3, 0.42], [-0.05, -0.22, 0.34, 0.62], [0.32, 0.02, 0.28, 0.4]]) { c.fillStyle = '#d9cbb0'; c.fillRect(x + dx * rr, y + dy * rr, w * rr, hh * rr); c.fillStyle = '#8a5a3a'; c.beginPath(); c.moveTo(x + dx * rr - 1, y + dy * rr); c.lineTo(x + (dx + w / 2) * rr, y + (dy - 0.18) * rr); c.lineTo(x + (dx + w) * rr + 1, y + dy * rr); c.closePath(); c.fill(); }
      if (cc2.wl > 0) { c.strokeStyle = cc2.wh > 0 ? '#c8c0b0' : '#6a5a50'; c.lineWidth = 2.5 * z; hexPath(c, x, y, rr * 0.7); c.stroke(); }
      // 이름표
      const nm = cc2.n, fs = Math.max(9.5, 11.5 * Math.min(1.2, z));
      c.font = '700 ' + fs + 'px IBM Plex Sans KR, sans-serif';
      const tw = c.measureText(nm).width, bw = tw + fs * 3.2, bh = fs * 1.75, by = y - rr * 1.2 - bh / 2;
      banners.push({ x: x - bw / 2, y: by, w: bw, h: bh, id: cc2.id });
      c.fillStyle = 'rgba(16,12,22,.88)'; roundRect(c, x - bw / 2, by, bw, bh, bh / 2); c.fill();
      c.strokeStyle = cl; c.lineWidth = 1.6; c.stroke();
      // 인구
      c.fillStyle = cl; c.beginPath(); c.arc(x - bw / 2 + bh / 2, by + bh / 2, bh / 2 - 1.5, 0, 7); c.fill();
      c.fillStyle = lum(cl) > 0.6 ? '#1a1410' : '#fff'; c.font = '700 ' + (fs * 0.9) + 'px IBM Plex Mono, monospace'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(String(cc2.pop), x - bw / 2 + bh / 2, by + bh / 2 + 0.5);
      c.fillStyle = '#fff3d6'; c.font = '700 ' + fs + 'px IBM Plex Sans KR, sans-serif'; c.fillText(nm, x + bh * 0.25, by + bh / 2 + 0.5);
      if (cc2.b.indexOf('palace') >= 0) { c.fillStyle = '#f0c35a'; c.font = (fs * 0.95) + 'px sans-serif'; c.fillText('★', x + bw / 2 - fs * 0.7, by + bh / 2); }
      else if (st.P[o] && st.P[o].k === 'cs') { c.fillStyle = CST[CSL[st.P[o].cs].t][3]; c.beginPath(); c.arc(x + bw / 2 - fs * 0.7, by + bh / 2, fs * 0.3, 0, 7); c.fill(); }
      // 생산 진행(내 도시)
      if (o === me && cc2.q[0]) { const it = cc2.q[0], cost = itemCost(G, cc2, it), pr = (cc2.pp[itemKey(it)] || 0) / cost; c.fillStyle = '#e09a4a'; c.fillRect(x - bw / 2 + bh, by + bh - 2.5, (bw - bh * 1.4) * clamp(pr, 0, 1), 2.5); }
      if (o === me && !cc2.q.length) { c.fillStyle = '#ff6a4a'; c.beginPath(); c.arc(x + bw / 2 - 2, by + 2, 4, 0, 7); c.fill(); }
      // 체력
      if (cc2.hp < 200 || (cc2.wl > 0 && cc2.wh < cc2.wl * 100)) {
        const w = rr * 1.4, yy = y + rr * 0.95;
        c.fillStyle = '#2a1a20'; c.fillRect(x - w / 2, yy, w, 4);
        c.fillStyle = '#7fd36a'; c.fillRect(x - w / 2, yy, w * cc2.hp / 200, 4);
        if (cc2.wl > 0) { c.fillStyle = '#2a1a20'; c.fillRect(x - w / 2, yy + 5, w, 3); c.fillStyle = '#9ec0e8'; c.fillRect(x - w / 2, yy + 5, w * cc2.wh / (cc2.wl * 100), 3); }
      }
    }
    function roundRect(c, x, y, w, h2, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h2, r); c.arcTo(x + w, y + h2, x, y + h2, r); c.arcTo(x, y + h2, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
    function drawUnit(c, u, x, y, z, selected) {
      const T = UT[u.t], cl = col(u.o), r = Math.max(8, 11 * z);
      const civ = !isMil(u.t);
      c.save();
      c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(x, y + r * 0.85, r * 0.9, r * 0.32, 0, 0, 7); c.fill();
      if (civ) { c.fillStyle = '#ece2cc'; roundRect(c, x - r * 0.85, y - r * 0.85, r * 1.7, r * 1.7, r * 0.4); c.fill(); c.strokeStyle = cl; c.lineWidth = 2.4; c.stroke(); }
      else { c.fillStyle = cl; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); c.strokeStyle = selected ? '#fff' : 'rgba(20,14,24,.8)'; c.lineWidth = selected ? 2.4 : 1.6; c.stroke(); }
      glyph(c, T.cl === 'gp' ? 'gp' : UGLY(T), x, y, r * 1.05, civ ? hexCol(cl, 0.6) : (lum(cl) > 0.62 ? '#1d150e' : '#fff8ea'));
      // 체력
      if (u.hp < 100) { c.fillStyle = '#2a1a20'; c.fillRect(x - r, y + r + 2, r * 2, 3.2); c.fillStyle = u.hp > 50 ? '#7fd36a' : u.hp > 25 ? '#e8c04a' : '#e0503c'; c.fillRect(x - r, y + r + 2, r * 2 * u.hp / 100, 3.2); }
      // 승급
      if (u.pr && u.pr.length) { c.fillStyle = '#f0c35a'; for (let k = 0; k < u.pr.length; k++) { c.beginPath(); c.arc(x - r + 2 + k * 4, y - r - 2, 1.7, 0, 7); c.fill(); } }
      if (u.o === me && st.cur === me) {
        if (promoReady(u)) { c.fillStyle = '#f0c35a'; c.beginPath(); c.arc(x + r * 0.8, y - r * 0.8, 3.6, 0, 7); c.fill(); }
        else if (u.mv > 0 && !u.sl && u.sk !== st.t && !u.go) { c.fillStyle = '#7ff07a'; c.beginPath(); c.arc(x + r * 0.8, y - r * 0.8, 3, 0, 7); c.fill(); }
        else if (u.sl) { c.fillStyle = '#cfe2ff'; c.font = '700 ' + (8 * Math.max(1, z)) + 'px sans-serif'; c.textAlign = 'center'; c.fillText(isMil(u.t) ? '🛡' : 'z', x + r * 0.85, y - r * 0.7); }
      }
      c.restore();
    }
    function drawAnim(c, a, now, z) {
      const t = clamp((now - a.t0) / a.d, 0, 1);
      if (a.k === 'm') {
        const n = a.path.length - 1, f = t * n, k = Math.min(n - 1, Math.floor(f)), tt = f - k;
        const A = centerOf(a.path[k]), B = centerOf(a.path[k + 1] != null ? a.path[k + 1] : a.path[k]);
        const p = toScreen(A.x + (B.x - A.x) * tt, A.y + (B.y - A.y) * tt - Math.sin(tt * Math.PI) * 3);
        if (!isVis(a.path[k]) && !isVis(a.path[Math.min(n, k + 1)])) return;
        drawUnit(c, { o: a.o, t: a.ty, hp: 100, pr: [], mv: 0 }, p.x, p.y, z, false);
      } else if (a.k === 'a') {
        const A = toScreen(centerOf(a.f).x, centerOf(a.f).y), B = toScreen(centerOf(a.to).x, centerOf(a.to).y);
        if (a.r) { const kk = Math.min(1, t * 1.5), x = A.x + (B.x - A.x) * kk, y = A.y + (B.y - A.y) * kk - Math.sin(kk * Math.PI) * 26 * z; if (kk < 1) { c.fillStyle = a.cs ? '#ffd27a' : '#f8ecd0'; c.beginPath(); c.arc(x, y, 3.2 * z, 0, 7); c.fill(); } else { c.fillStyle = 'rgba(255,170,90,' + (1 - t) + ')'; c.beginPath(); c.arc(B.x, B.y, 14 * z * (1 - t + 0.4), 0, 7); c.fill(); } }
        else { const kk = t < 0.5 ? t * 2 : 2 - t * 2, x = A.x + (B.x - A.x) * kk * 0.45, y = A.y + (B.y - A.y) * kk * 0.45; c.strokeStyle = 'rgba(255,220,160,' + (0.9 - t * 0.6) + ')'; c.lineWidth = 3; c.beginPath(); c.moveTo(x, y); c.lineTo(B.x, B.y); c.stroke(); if (t > 0.45 && t < 0.75) { c.fillStyle = 'rgba(255,250,220,.8)'; c.beginPath(); c.arc(B.x, B.y, 10 * z, 0, 7); c.fill(); } }
      } else if (a.k === 'ring') {
        const p = toScreen(centerOf(a.p).x, centerOf(a.p).y); c.strokeStyle = a.c || 'rgba(255,230,150,' + (1 - t) + ')'; c.globalAlpha = 1 - t; c.lineWidth = 3; c.beginPath(); c.arc(p.x, p.y, RAD * z * (0.6 + t * 1.6), 0, 7); c.stroke(); c.globalAlpha = 1;
      }
    }
    function playEvents(L2) {
      const now = performance.now();
      const evs = (L2.e || []).filter((e) => {
        if (seeAll) return true;
        if (e.k === 'm') return e.path.some((j) => isVis(j));
        if (e.k === 'a') return isVis(e.f) || isVis(e.t);
        if (e.p != null) return isVis(e.p);
        return false;
      });
      if (!evs.length) return;
      const sp = spd(), total = Math.min(1900, evs.length * 330) / sp, per = total / evs.length;
      let t = now;
      for (const e of evs) {
        if (e.k === 'm') { const d = Math.min(per, (180 * (e.path.length - 1)) / sp); anim.push({ k: 'm', u: e.u, o: e.o, ty: e.t, path: e.path, t0: t, d: Math.max(60, d) }); t += Math.max(60, d) * 0.7; }
        else if (e.k === 'a') {
          const d = Math.max(120, Math.min(per, 520 / sp)); anim.push({ k: 'a', f: e.f, to: e.t, r: e.r, cs: e.cs, t0: t, d });
          if (e.da != null) floats.push({ p: e.t, s: (e.c ? '🏰' : '') + '−' + e.da, c: '#ff8a6a', t0: t + d * 0.6, d: 900 / sp });
          if (e.dr) floats.push({ p: e.f, s: '−' + e.dr, c: '#ffc07a', t0: t + d * 0.6, d: 900 / sp });
          if (e.kill) floats.push({ p: e.t, s: '💀', c: '#fff', t0: t + d * 0.8, d: 900 / sp });
          if (e.o === me || isVis(e.t)) setTimeout(() => api.sfx(e.r ? 'whoosh' : 'hit'), Math.max(0, t - now + d * 0.5));
          t += d;
        } else if (e.k === 'c') { anim.push({ k: 'ring', p: e.p, t0: t, d: 900 / sp, c: col(e.o) }); shake = 1; setTimeout(() => { shake = 0; }, 350); t += 300 / sp; }
        else if (e.k === 'f' || e.k === 'w' || e.k === 'x' || e.k === 'i') { anim.push({ k: 'ring', p: e.p, t0: t, d: 800 / sp }); t += 150 / sp; }
        else if (e.k === 'z') { anim.push({ k: 'ring', p: e.p, t0: t, d: 1200 / sp, c: '#ff7a3a' }); shake = 1.4; setTimeout(() => { shake = 0; }, 600); }
      }
      animT = Math.max(...anim.map((a) => a.t0 + a.d), ...floats.map((f) => f.t0 + f.d));
      setBusy(true);
    }
    let raf = 0;
    function loop(now) {
      raf = requestAnimationFrame(loop);
      const animating = anim.length || floats.length;
      if (animating) {
        anim = anim.filter((a) => a.t0 + a.d > now); floats = floats.filter((f) => f.t0 + f.d > now);
        if (!anim.length && !floats.length) setBusy(false);
      }
      if (cam.tx != null) { cam.x += (cam.tx - cam.x) * 0.2; cam.y += (cam.ty - cam.y) * 0.2; if (Math.abs(cam.tx - cam.x) + Math.abs(cam.ty - cam.y) < 0.6) cam.tx = cam.ty = null; dirtyF = true; }
      if (dirtyF || animating || (sel && sel.k === 'u') || shake) { draw(now); dirtyF = false; }
      if (miniKey !== (st ? st.L.id + '|' + me + '|' + Math.round(cam.x) + Math.round(cam.y) + cam.z.toFixed(2) : '')) drawMini();
    }
    raf = requestAnimationFrame(loop);
    function drawMini() {
      if (!st || !G) return;
      miniKey = st.L.id + '|' + me + '|' + Math.round(cam.x) + Math.round(cam.y) + cam.z.toFixed(2);
      const w = Math.round(Math.min(wide() ? 190 : 110, cvs.w * 0.26)), hh = Math.round(w * st.H / st.W * 0.9);
      const dpr = cvs.dpr || 1;
      if (mini.width !== w * dpr) { mini.width = w * dpr; mini.height = hh * dpr; mini.style.width = w + 'px'; mini.style.height = hh + 'px'; }
      const c = mini.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
      c.fillStyle = '#090d14'; c.fillRect(0, 0, w, hh);
      const cw = w / (st.W + 0.5), ch = hh / st.H;
      for (let i = 0; i < G.N; i++) {
        if (!isEx(i) && !hideAll) continue; if (hideAll) break;
        const r = (i / st.W) | 0, cc = i % st.W;
        const ow = tileOwner(G, i);
        c.fillStyle = ow >= 0 ? col(ow) : isWater(G, i) ? '#24507a' : G.ter[i] === TM ? '#6a6370' : '#5d7a44';
        c.globalAlpha = ow >= 0 ? 0.85 : 0.7; c.fillRect((cc + 0.5 * (r & 1)) * cw, r * ch, cw + 0.4, ch + 0.4);
      }
      c.globalAlpha = 1;
      for (const cc2 of G.C) if (isEx(cc2.p) && !hideAll) { const r = (cc2.p / st.W) | 0, q = cc2.p % st.W; c.fillStyle = '#fff'; c.fillRect((q + 0.5 * (r & 1)) * cw - 1, r * ch - 1, 3, 3); }
      const v = viewArea(), ws = worldSize();
      const a = toWorld(0, v.tH), b = toWorld(cvs.w - v.rW, cvs.h - v.bH);
      c.strokeStyle = '#f0c35a'; c.lineWidth = 1.2; c.strokeRect(a.x / ws.w * w, a.y / ws.h * hh, (b.x - a.x) / ws.w * w, (b.y - a.y) / ws.h * hh);
    }

    /* ---------- 카메라 ---------- */
    function zoomBy(f, sx, sy) {
      const v = viewArea(); if (sx == null) { sx = v.cx; sy = v.cy; }
      const w0 = toWorld(sx, sy); cam.z = clamp(cam.z * f, 0.45, 2.6);
      const w1 = toWorld(sx, sy); cam.x += w0.x - w1.x; cam.y += w0.y - w1.y; cam.tx = cam.ty = null; clampCam(); dirtyF = true;
    }
    function centerOn(i, smooth) { const w = centerOf(i); let x = w.x; if (st && st.wr) { const pw = PW(); x += Math.round((cam.x - x) / pw) * pw; } if (smooth) { cam.tx = x; cam.ty = w.y; } else { cam.x = x; cam.y = w.y; } dirtyF = true; }
    function centerHome(smooth) {
      if (!G) return;
      const cap = me >= 0 ? (capOf(G, me) || citiesOf(G, me)[0]) : null;
      if (cap) return centerOn(cap.p, smooth);
      const u = me >= 0 ? G.U.find((x) => x.o === me) : null;
      if (u) return centerOn(u.p, smooth);
      const ws = worldSize(); cam.x = ws.w / 2; cam.y = ws.h / 2; dirtyF = true;
    }

    /* ---------- 입력 ---------- */
    const pts = new Map(); let drag = null, pinch = null, moved = false;
    mapEl.addEventListener('pointerdown', (e) => {
      tipEl.hidden = true; hoverI = -1;
      mapEl.setPointerCapture && mapEl.setPointerCapture(e.pointerId);
      const p = cvs.local(e); pts.set(e.pointerId, p);
      if (pts.size === 1) { drag = { x: p.x, y: p.y, cx: cam.x, cy: cam.y }; moved = false; }
      else if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), z: cam.z, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 }; moved = true; }
    });
    mapEl.addEventListener('pointermove', (e) => {
      if (!pts.has(e.pointerId)) { if (e.pointerType === 'mouse') hoverAt(cvs.local(e)); return; }
      const p = cvs.local(e); pts.set(e.pointerId, p);
      if (pinch && pts.size >= 2) { const [a, b] = [...pts.values()]; const d = Math.hypot(a.x - b.x, a.y - b.y); zoomBy((pinch.z * d / pinch.d) / cam.z, pinch.mx, pinch.my); return; }
      if (drag) { const dx = p.x - drag.x, dy = p.y - drag.y; if (Math.abs(dx) + Math.abs(dy) > 8) moved = true; if (moved) { cam.x = drag.cx - dx / cam.z; cam.y = drag.cy - dy / cam.z; cam.tx = cam.ty = null; clampCam(); dirtyF = true; } }
    });
    const up = (e) => {
      if (!pts.has(e.pointerId)) return;
      const p = pts.get(e.pointerId); pts.delete(e.pointerId);
      if (pts.size === 0) { if (!moved && drag) tapAt(p); drag = null; pinch = null; }
      else if (pts.size === 1) { pinch = null; const q = [...pts.values()][0]; drag = { x: q.x, y: q.y, cx: cam.x, cy: cam.y }; }
    };
    mapEl.addEventListener('pointerup', up); mapEl.addEventListener('pointercancel', up);
    mapEl.addEventListener('pointerleave', () => { tipEl.hidden = true; hoverI = -1; });
    mapEl.addEventListener('wheel', (e) => { e.preventDefault(); const p = cvs.local(e); zoomBy(e.deltaY < 0 ? 1.12 : 0.89, p.x, p.y); }, { passive: false });
    mini.addEventListener('pointerdown', (e) => { e.stopPropagation(); const r = mini.getBoundingClientRect(), ws = worldSize(); cam.tx = (e.clientX - r.left) / r.width * ws.w; cam.ty = (e.clientY - r.top) / r.height * ws.h; dirtyF = true; });
    function hoverAt(p) {
      if (!G || hideAll) return;
      const i = pick(p.x, p.y); if (i === hoverI) return; hoverI = i;
      if (i < 0 || !isEx(i)) { tipEl.hidden = true; return; }
      let s = tileTitle(i);
      if (sel && sel.k === 'u' && TG.indexOf(i) >= 0) { const u = G.uid[sel.id]; if (u) { const pv = combatPreview(G, u, i); s = '⚔ 공격 예상: 적 −' + pv.da[0] + '~' + pv.da[1] + (pv.dr[1] ? ' · 나 −' + pv.dr[0] + '~' + pv.dr[1] : ''); } }
      else if (mode && mode.k === 'place' && mode.sites.indexOf(i) >= 0 && mode.it.t === 'd') s = distName(G, me, mode.it.k) + ' 인접 +' + adjBonus(G, me, i, mode.it.k);
      tipEl.textContent = s; tipEl.hidden = false; tipEl.style.top = (top.offsetHeight + 12) + 'px';
    }
    function tileTitle(i) {
      const y = tileYield(G, i, me >= 0 ? me : -1), parts = [];
      const nw = nwAt(G, i);
      parts.push((G.hill[i] && isLand(G, i) ? '언덕 ' : '') + TER[G.ter[i]].n + (G.feat[i] && !nw && FEAT[G.feat[i]] ? '·' + FEAT[G.feat[i]].n : '') + (nw ? '·' + nw.n : '') + (G.riv[i] ? '·강' : ''));
      if (G.res[i] && (me < 0 || resVisible(G, me, G.res[i]))) parts.push(RES[G.res[i]].n);
      if (G.imp[i]) parts.push(IMP[G.imp[i]].n + (G.pil[i] ? '(약탈)' : ''));
      if (G.dis[i] && DIS[G.dis[i]].k !== 'cc') parts.push(distName(G, tileOwner(G, i), DIS[G.dis[i]].k));
      if (G.won[i]) parts.push(WON[G.won[i] - 1].n);
      return parts.join(' · ') + '  ' + yStr(y);
    }
    function selectUnit(u, quiet) {
      sel = { k: 'u', id: u.id }; pend = null; mode = null;
      if (myTurn() && u.o === me) { if (isAir(u.t)) { RR = null; TG = airTargets(G, u); } else { const r = reach(G, u); RR = r.r; TG = targets(G, u); if (UT[u.t].k === 'apostle') TG = TG.concat(relTargets(u)); } }
      else { RR = null; TG = []; }
      if (!quiet) api.sfx('click');
      renderBot(); dirtyF = true;
    }
    function relTargets(u) { const out = []; for (const j of G.g.nb[u.p]) for (const v of G.U) if (v.p === j && v.o !== me && UT[v.t].cl === 'rel' && v.r !== u.r) out.push(j); return out; }
    function clearSel() { sel = null; RR = null; TG = []; pend = null; renderBot(); dirtyF = true; }
    function tapAt(p) {
      if (!G || hideAll) return;
      if (!mode) for (let k = banners.length - 1; k >= 0; k--) { const b = banners[k]; if (p.x >= b.x - 4 && p.x <= b.x + b.w + 4 && p.y >= b.y - 4 && p.y <= b.y + b.h + 4) { const c = G.cid[b.id]; if (c && c.o === me) { openSheet('city', c.id); return; } if (c) { sel = { k: 't', p: c.p }; RR = null; TG = []; pend = null; renderBot(); dirtyF = true; return; } } }
      const i = pick(p.x, p.y); if (i < 0) return;
      // 항공 재배치·정찰, 핵 발사: 칸 고르기
      if (mode && (mode.k === 'air' || mode.k === 'nuke')) {
        if (mode.sites.indexOf(i) < 0) { api.toast('표시된 칸 중에서 골라요'); return; }
        if (mode.sel === i) { siteGo(); return; }
        mode.sel = i; renderBot(); dirtyF = true; return;
      }
      // 배치 모드
      if (mode && mode.k === 'place') {
        if (mode.sites.indexOf(i) < 0) { api.toast('초록 칸 중에서 골라요'); return; }
        if (mode.sel === i) { const it = Object.assign({}, mode.it, { p: i }); const back = mode.c, add = mode.add; mode = null; act({ t: 'prod', c: back, it, mode: add ? 'add' : 'set' }); openSheet('city', back); return; }
        mode.sel = i; renderBot(); dirtyF = true; return;
      }
      // 도시 화면: 칸 고정 / 타일 구매
      if (sheet && sheet.kind === 'city') {
        const c = G.cid[sheet.arg];
        if (c && myTurn() && c.o === me) {
          if (mode && mode.k === 'buy' && canBuyTile(G, c, i)) { act({ t: 'btile', c: c.id, p: i }); return; }
          if (G.own[i] === c.id && workable(G, c, i)) { act({ t: 'tile', c: c.id, p: i }); return; }
        }
      }
      const u = sel && sel.k === 'u' ? G.uid[sel.id] : null;
      if (u && u.o === me && myTurn()) {
        if (TG.indexOf(i) >= 0) {
          if (pend && pend.k === 'atk' && pend.to === i) { doAtk(u, i); return; }
          pend = { k: 'atk', to: i }; renderBot(); dirtyF = true; return;
        }
        if (RR && RR[i] != null) { act({ t: 'mv', u: u.id, to: i }); pend = null; return; }
        if (i !== u.p && !cityAt(G, i) && (isEx(i))) {
          if (pend && pend.k === 'go' && pend.to === i) { act({ t: 'mv', u: u.id, to: i }); pend = null; return; }
          const path = pathTo(G, u, i);
          if (path) { const mv = maxMv(G, u) || 1; let cost = 0; for (let k = 1; k < path.length; k++) { const c2 = stepCost(G, u, path[k - 1], path[k]); cost += c2 < 0 ? mv : c2; } pend = { k: 'go', to: i, path, turns: Math.max(1, Math.ceil((cost - u.mv) / mv) + 1) }; renderBot(); dirtyF = true; return; }
        }
      }
      // 유닛 고르기(겹치면 번갈아)
      const here = G.U.filter((v) => v.p === i && isVis(i));
      const mine = here.filter((v) => v.o === me);
      const cityHere = cityAt(G, i);
      if (mine.length) {
        const curIdx = u ? mine.findIndex((v) => v.id === u.id) : -1;
        if (curIdx >= 0 && curIdx === mine.length - 1 && cityHere && cityHere.o === me) { openSheet('city', cityHere.id); return; }
        selectUnit(mine[(curIdx + 1) % mine.length]); return;
      }
      if (cityHere && isEx(i)) { if (cityHere.o === me) { openSheet('city', cityHere.id); return; } sel = { k: 't', p: i }; RR = null; TG = []; pend = null; renderBot(); dirtyF = true; return; }
      if (here.length) { selectUnit(here[0]); return; }
      sel = isEx(i) ? { k: 't', p: i } : null; RR = null; TG = []; pend = null; renderBot(); dirtyF = true;
    }
    function siteGo() {
      if (!mode || mode.sel == null) return;
      const m = mode; mode = null;
      if (m.k === 'air') act({ t: 'air', u: m.u, m: m.m, to: m.sel });
      else if (m.k === 'nuke') act({ t: 'nuke', k: m.kk, c: m.c, to: m.sel, src: m.src });
      renderBot(); dirtyF = true;
    }
    function doAtk(u, i) {
      const v = G.U.find((x) => x.p === i && UT[x.t].cl === 'rel' && x.o !== me);
      if (UT[u.t].k === 'apostle' && v && !milAt(G, i) && !cityAt(G, i)) act({ t: 'theo', u: u.id, v: v.id }); else act({ t: 'atk', u: u.id, to: i });
      pend = null;
    }
    function nextUnit() {
      if (!myTurn()) return;
      const list = G.U.filter((u) => u.o === me && (u.mv > 0 || promoReady(u)) && !u.sl && u.sk !== st.t && !u.go);
      if (!list.length) { api.toast('명령을 기다리는 유닛이 없어요'); return; }
      const cur = sel && sel.k === 'u' ? list.findIndex((u) => u.id === sel.id) : -1;
      const u = list[(cur + 1) % list.length]; selectUnit(u); centerOn(u.p, true);
    }

    /* ---------- 위쪽·아래쪽 ---------- */
    function turnsTo(left, rate) { return rate > 0 ? Math.max(1, Math.ceil(left / rate)) : '∞'; }
    function renderTop() {
      if (!st) return;
      const p = me >= 0 ? st.P[me] : null;
      chipT.innerHTML = ''; chipC.innerHTML = ''; chipS.innerHTML = '';
      if (!p || hideAll) { chipT.append(h('span', { class: 'tx' }, h('b', { text: '문명 개척' }), h('small', { text: st.t + '턴' }))); return; }
      let sciR = 0, culR = 0; for (const c of citiesOf(G, me)) { const cc = cityCalc(G, c); sciR += cc.y[3]; culR += cc.y[4]; }
      const tName = p.rs >= 0 ? TECH[p.rs].n : '연구 고르기', tCost = p.rs >= 0 ? techCost(G, me, p.rs) : 1, tPr = p.rs >= 0 ? (p.tp[p.rs] || 0) : 0;
      chipT.append(h('span', { class: 'ic', text: '🔬' }), h('span', { class: 'tx' }, h('b', { text: tName }), h('small', { text: p.rs >= 0 ? turnsTo(tCost - tPr, sciR) + '턴 · +' + Math.round(sciR) : '+' + Math.round(sciR) + '/턴' })), h('i', { class: 'pg', style: { width: (100 * clamp(tPr / tCost, 0, 1)) + '%', background: '#6fb7e8' } }));
      chipT.classList.toggle('need', p.rs < 0 && myTurn());
      const cName = p.cs >= 0 ? CIVIC[p.cs].n : '사회 제도 고르기', cCost = p.cs >= 0 ? civicCost(G, me, p.cs) : 1, cPr = p.cs >= 0 ? (p.cp[p.cs] || 0) : 0;
      chipC.append(h('span', { class: 'ic', text: '🎭' }), h('span', { class: 'tx' }, h('b', { text: cName }), h('small', { text: p.cs >= 0 ? turnsTo(cCost - cPr, culR) + '턴 · +' + Math.round(culR) : '+' + Math.round(culR) + '/턴' })), h('i', { class: 'pg', style: { width: (100 * clamp(cPr / cCost, 0, 1)) + '%', background: '#c991e8' } }));
      chipC.classList.toggle('need', p.cs < 0 && myTurn());
      const lg = citiesOf(G, me).length ? incomeOf(G, me).gold : (p.lg || 0);
      chipS.append(h('span', { text: '💰' + Math.floor(p.gold) + (lg >= 0 ? '+' : '') + Math.round(lg) }), h('span', { text: '🙏' + Math.floor(p.faith) }), h('span', { text: '🕊' + Math.floor(p.favor || 0) }), h('span', { text: '⏳' + st.t + '/' + st.tl }), h('span', { text: ERA[st.era] + (p.age !== 1 ? '·' + AGEN[p.age] : '') }));
      const nn = (p.nt || []).filter((n) => n.t >= st.t - 1).length;
      bNote.innerHTML = '🔔'; if (nn) bNote.append(h('span', { class: 'bd', text: String(Math.min(99, nn)) }));
      bDip.classList.toggle('need', st.Q.some((q) => q.t === me));
      bMenu.classList.toggle('need', !!(p.dsel || (p.pf && slotTypes(G, me).length > p.pol.filter((x) => x >= 0).length && POL.some((x, i) => polAvail(G, me, i) && p.pol.indexOf(i) < 0)) || p.gt > 0 || (p.env > 0) || (st.WC.pend && !(st.WC.pend.votes[me]))));
      const sideTop = top.offsetHeight + 12;
      side.style.top = sideTop + 'px'; mini.style.top = sideTop + 'px';
    }
    function pendingThing() {
      const p = st.P[me];
      if (p.dsel) return { l: '⏳ 헌신 고르기', f: () => openSheet('era') };
      if (p.rs < 0 && TECH.some((t, i) => techAvail(G, me, i))) return { l: '🔬 연구 고르기', f: () => openSheet('tech'), hard: 1 };
      if (p.cs < 0 && CIVIC.some((t, i) => civicAvail(G, me, i))) return { l: '🎭 사회 제도 고르기', f: () => openSheet('civic'), hard: 1 };
      const c = citiesOf(G, me).find((x) => !x.q.length);
      if (c) return { l: '🔨 생산: ' + c.n, f: () => openSheet('city', c.id), hard: 1 };
      if (p.pf && slotTypes(G, me).some((t, k) => p.pol[k] < 0 && POL.some((x, i) => polAvail(G, me, i) && p.pol.indexOf(i) < 0 && (t === 'W' || x.t === t)))) return { l: '🏛 정책 정하기(무료)', f: () => openSheet('policy') };
      if (st.Q.some((q) => q.t === me)) return { l: '📨 외교 제안 답하기', f: () => openSheet('dip') };
      if (GPK.some((c) => st.GP.cur[c] >= 0 && (p.gpp[c] || 0) >= gpCost(G, c) && !(p.gpPass && p.gpPass[c] === st.GP.cur[c]))) return { l: '⭐ 위인 영입', f: () => openSheet('gp') };
      if ((p.spy || []).some((x) => !x.m)) return { l: '🕵 첩보원 임무', f: () => openSheet('spy') };
      const n = G.U.filter((u) => u.o === me && (u.mv > 0 || promoReady(u)) && !u.sl && u.sk !== st.t && !u.go).length;
      if (n) return { l: '▶ 다음 유닛 (' + n + ')', f: nextUnit };
      return null;
    }
    let endArm = 0;
    function renderBot() {
      bot.innerHTML = '';
      if (!st) return;
      const info = h('div', { class: 'c6-info' }), btns = h('div', { class: 'c6-btns' });
      bot.append(info, btns);
      if (st.ph === 'e') { info.append(h('div', { class: 'tx' }, h('b', { text: '🏆 ' + st.w.map((o) => CIVS[st.P[o].civ].n).join(', ') + ' ' + WINN[st.wk] + ' 승리' }), h('small', { text: st.t + '턴' }))); return; }
      if (hideAll) { info.append(h('div', { class: 'tx' }, h('b', { text: '다른 사람의 차례예요' }), h('small', { text: '가림막에서 내 차례를 확인하세요.' }))); return; }
      const p = me >= 0 ? st.P[me] : null;
      if (mode && (mode.k === 'air' || mode.k === 'nuke')) {
        const nm = mode.k === 'nuke' ? '☢ ' + (mode.kk === 't' ? '열핵 폭탄' : '원자폭탄') + ' 목표' : mode.m === 'b' ? '🛫 옮길 기지' : '🔭 정찰할 곳';
        info.append(h('div', { class: 'tx' }, h('b', { text: nm + ' 고르기' }), h('small', { text: mode.sel != null ? (mode.k === 'nuke' ? '반경 ' + (mode.kk === 't' ? 2 : 1) + '칸의 모든 유닛이 사라지고 도시가 크게 다쳐요. 모든 나라가 분노해요.' : '한 번 더 누르거나 「확인」') : '표시된 칸을 누르세요.' })));
        btns.append(h('button', { class: 'btn ghost', text: '취소', 'data-key': 'Escape', onclick: () => { mode = null; renderBot(); dirtyF = true; } }));
        if (mode.sel != null) btns.append(h('button', { class: 'btn primary', text: mode.k === 'nuke' ? '☢ 발사' : '확인', onclick: siteGo }));
        return;
      }
      // 배치 모드
      if (mode && mode.k === 'place') {
        const nm = itemName(G, me, mode.it);
        info.append(h('div', { class: 'tx' }, h('b', { text: nm + ' — 놓을 칸 고르기' }), h('small', { text: mode.sel != null ? (mode.it.t === 'd' && DIS[DISI[mode.it.k]].y >= 0 ? '인접 보너스 +' + adjBonus(G, me, mode.sel, mode.it.k) + ' · ' : '') + '한 번 더 누르거나 「여기에 짓기」' : '초록 칸을 누르세요(숫자 = 인접 보너스).' })));
        btns.append(h('button', { class: 'btn ghost', text: '취소', 'data-key': 'Escape', onclick: () => { const c = mode.c; mode = null; openSheet('city', c); } }));
        if (mode.sel != null) btns.append(h('button', { class: 'btn primary', text: '여기에 짓기', 'data-key': 'Enter', onclick: () => { const it = Object.assign({}, mode.it, { p: mode.sel }), c = mode.c, add = mode.add; mode = null; act({ t: 'prod', c, it, mode: add ? 'add' : 'set' }); openSheet('city', c); } }));
        return;
      }
      const u = sel && sel.k === 'u' ? G.uid[sel.id] : null;
      if (u) return renderUnitBot(u, info, btns);
      if (sel && sel.k === 't') return renderTileBot(sel.p, info, btns);
      if (!myTurn()) {
        const cur = st.cur;
        info.append(h('div', { class: 'tok', style: { background: col(cur) } }), h('div', { class: 'tx' }, h('b', { text: civName(G, cur) + ' 차례…' }), h('small', { text: st.P[cur].lv > 0 ? 'AI가 생각하고 있어요' : '기다리는 중' })));
        return;
      }
      const pt = pendingThing();
      info.append(h('div', { class: 'tx' }, h('b', { text: CIVS[p.civ].n + ' · ' + CIVS[p.civ].ld }), h('small', { text: pt ? (pt.hard ? '정할 것이 있어요' : '할 수 있는 일이 남았어요') : '모든 준비가 끝났어요' })));
      if (pt) btns.append(h('button', { class: 'btn', text: pt.l, 'data-action': 'next', onclick: () => { api.sfx('click'); pt.f(); } }));
      btns.append(h('button', { class: 'btn primary end', text: endArm && pt && pt.hard ? '정말 턴 종료?' : '턴 종료 ▶', 'data-action': 'end', onclick: () => tryEnd() }));
    }
    function tryEnd() {
      if (!myTurn()) return;
      const pt = pendingThing();
      if (pt && pt.hard && !endArm) { endArm = 1; api.toast(pt.l.replace(/^\S+ /, '') + '이(가) 남았어요. 한 번 더 누르면 종료'); renderBot(); setTimeout(() => { endArm = 0; if (st) renderBot(); }, 2600); return; }
      endArm = 0; clearSel(); closeSheet(); api.sfx('click'); act({ t: 'E' });
    }
    function unitLine(u) {
      const T = UT[u.t], M = mods(G, u.o);
      const bits = [];
      if (T.cs) bits.push('⚔' + T.cs + (promoVal(u, 'cs') ? '+' + promoVal(u, 'cs') : ''));
      if (T.rs) bits.push('🏹' + T.rs + (isAir(u.t) ? ' 작전 범위 ' + airRange(G, u) : ' 사거리 ' + rangeOf(G, u)));
      if (u.cp) bits.push(corpsName(u).trim() + ' +' + (u.cp === 2 ? 17 : 10));
      if (isAir(u.t)) bits.push(u.a ? '이번 턴 행동함' : '행동 가능'); else bits.push('이동 ' + (Math.round(u.mv * 10) / 10) + '/' + maxMv(G, u));
      if (u.ch != null && (T.k === 'builder' || T.k === 'mileng' || T.k === 'archaeo' || T.cl === 'rel')) bits.push((T.cl === 'rel' ? '전파 ' : '충전 ') + u.ch);
      if (isMil(u.t)) bits.push('경험치 ' + Math.floor(u.x || 0) + '/' + (XPN[u.pr.length] || '최고'));
      if (u.r >= 0 && u.r != null && st.R[u.r]) bits.push(RELN[st.R[u.r].i]);
      return bits.join(' · ');
    }
    function renderUnitBot(u, info, btns) {
      const T = UT[u.t], mine = u.o === me && myTurn();
      const nm = T.cl === 'gp' ? GPC[GPL[u.g].c].n + ' ' + GPL[u.g].n : T.n + corpsName(u);
      const tok = h('div', { class: 'tok', style: { background: col(u.o) } });
      info.append(tok, h('div', { class: 'tx' }, h('b', { text: nm + (u.o !== me ? ' (' + civName(G, u.o) + ')' : '') }), h('span', { class: 'c6-hp' }, h('i', { style: { width: u.hp + '%' } })), h('small', { text: T.cl === 'gp' ? GPL[u.g].d : unitLine(u) })));
      if (!mine) { btns.append(h('button', { class: 'btn ghost', text: '닫기', 'data-key': 'Escape', onclick: clearSel })); return; }
      if (pend && pend.k === 'atk') {
        const pv = combatPreview(G, u, pend.to), c = cityAt(G, pend.to);
        const od = h('div', { class: 'c6-odds' },
          h('div', { text: '나 ' + pv.a + (pv.dr[1] ? ' · −' + pv.dr[0] + '~' + pv.dr[1] : ' · 반격 없음') }), h('div', { class: 'vs', text: 'VS' }),
          h('div', { class: 'r', text: (c ? c.n + ' ' : '적 ') + pv.d + ' · −' + pv.da[0] + '~' + pv.da[1] }));
        bot.insertBefore(od, btns);
        if (pv.kill != null && !c) od.append(h('div', { style: { gridColumn: '1/4', textAlign: 'center' }, text: pv.capt ? '민간 유닛 포획' : '격파 확률 ' + Math.round(pv.kill * 100) + '%' + (pv.die ? ' · 내가 쓰러질 확률 ' + Math.round(pv.die * 100) + '%' : '') }));
        if (c) od.append(h('div', { style: { gridColumn: '1/4', textAlign: 'center' }, text: pv.wall ? '성벽부터 깎여요(공성 유닛·공성 망치가 유리)' : c.hp <= 0 ? '근접 공격으로 점령!' : '도시 체력 ' + c.hp + '/200' }));
        btns.append(h('button', { class: 'btn ghost', text: '취소', 'data-key': 'Escape', onclick: () => { pend = null; renderBot(); dirtyF = true; } }), h('button', { class: 'btn primary', text: '⚔ 공격!', 'data-key': 'Enter', onclick: () => doAtk(u, pend.to) }));
        return;
      }
      if (pend && pend.k === 'go') {
        info.querySelector('small').textContent = '이동 명령: ' + pend.turns + '턴 걸려요. 한 번 더 누르거나 「출발」.';
        btns.append(h('button', { class: 'btn ghost', text: '취소', 'data-key': 'Escape', onclick: () => { pend = null; renderBot(); dirtyF = true; } }), h('button', { class: 'btn primary', text: '출발', 'data-key': 'Enter', onclick: () => { act({ t: 'mv', u: u.id, to: pend.to }); pend = null; } }));
        return;
      }
      const B = (text, fn, dis, extra) => { const b = h('button', Object.assign({ class: 'btn', text, onclick: () => { if (dis) { api.toast(dis); return; } api.sfx('click'); fn(); } }, extra || {})); if (dis) { b.style.opacity = 0.45; b.title = dis; } btns.append(b); return b; };
      const why = [];
      if (promoReady(u)) B('⭐ 승급', () => openPromo(u), null, { class: 'btn primary' });
      if (T.k === 'settler') { const w = []; const ok = canFound(G, u, w); B('🏛 도시 세우기', () => act({ t: 'found', u: u.id }), ok ? null : w[0], { class: 'btn primary', 'data-action': 'fort' }); if (!ok) btns.lastChild.textContent = '🏛 ' + w[0]; const c = cityAt(G, u.p); if (c && c.o === me) B('합류(인구+1)', () => act({ t: 'join', u: u.id })); }
      if (T.k === 'builder') {
        for (const k of impOptions(G, u, u.p)) B(IMP[k].n, () => act({ t: 'imp', u: u.id, k }));
        const cv = chopValue(G, u, u.p); if (cv) B('🪓 베기 +' + cv, () => act({ t: 'chop', u: u.id }));
        if ((G.pil[u.p] || G.dpil[u.p]) && tileOwner(G, u.p) === me) B('🔧 수리', () => act({ t: 'rep', u: u.id }));
        if (!impOptions(G, u, u.p).length && !cv) info.querySelector('small').textContent += ' · 내 영토의 칸으로 옮겨 개선을 지어요';
      }
      if (T.k === 'mileng') { const w = []; const ok = roadOK(G, u, w); B(G.road[u.p] >= 1 ? '🚂 철도' : '🛣 도로', () => act({ t: 'road', u: u.id }), ok ? null : w[0]); for (const k of impOptions(G, u, u.p)) B('🏰 ' + IMP[k].n, () => act({ t: 'imp', u: u.id, k })); }
      const nkP = st.P[me].nk || {};
      if (((nkP.a || 0) + (nkP.t || 0)) > 0 && (T.nuk || (T.k === 'mileng' && G.imp[u.p] === IMPI.silo))) for (const kk of ['a', 't']) if (nkP[kk] > 0) { const ns = nukeTargetsFrom(G, me, { p: u.p }); B('☢ ' + (kk === 'a' ? '원자폭탄' : '열핵 폭탄'), () => { mode = { k: 'nuke', kk, c: -1, src: u.p, sites: ns, sel: null }; renderBot(); dirtyF = true; }, ns.length ? null : '12칸 안에 목표가 없어요'); }
      if (T.k === 'archaeo') B('🏺 발굴', () => act({ t: 'dig', u: u.id }), G.imp[u.p] === IMPI.ant ? null : '고대 유적 위에서 발굴해요');
      if (isAir(u.t)) {
        if (!T.rec) info.querySelector('small').textContent = unitLine(u) + ' · 빨간 칸을 눌러 공격';
        B('🛫 재배치', () => { mode = { k: 'air', m: 'b', u: u.id, sites: airBases(G, u), sel: null }; renderBot(); dirtyF = true; }, u.a || u.mv <= 0 ? '이번 턴엔 끝났어요' : airBases(G, u).length ? null : '옮길 기지가 없어요');
        if (T.rec) B('🔭 정찰', () => { mode = { k: 'air', m: 'r', u: u.id, sites: within(G.g, u.p, airRange(G, u)).filter((j) => j !== u.p), sel: null }; renderBot(); dirtyF = true; }, u.a || u.mv <= 0 ? '이번 턴엔 끝났어요' : null);
        if (T.ftr) B(u.pt ? '경계 비행 끄기' : '🛡 경계 비행', () => act({ t: 'air', u: u.id, m: 'p' }));
      }
      if (isGround(u.t) && !isAir(u.t)) { const v = G.g.nb[u.p].map((j) => milAt(G, j)).find((x) => x && corpsOK(G, u, x)); if (v) B('🎖 ' + ((u.cp || 0) + (v.cp || 0) >= 1 ? (isNaval(u.t) ? '대함대' : '군대') : (isNaval(u.t) ? '함대' : '군단')) + ' 만들기', () => act({ t: 'cmb', u: u.id, v: v.id })); }
      if (T.k === 'trader') { const ds = tradeDests(G, u); B('🐪 교역로 열기', () => openSheet('trade', u.id), ds.length ? null : (cityAt(G, u.p) && cityAt(G, u.p).o === me ? '갈 수 있는 도시가 없어요' : '내 도시 안에서 열어요')); }
      if (T.cl === 'rel') {
        if (T.k === 'inquisitor') { const c = G.C.find((d) => d.o === me && hexDist(G.g, d.p, u.p) <= 1); B('⛔ 이단 제거', () => act({ t: 'inq', u: u.id }), c ? null : '내 도시 옆에서'); }
        else { const c = G.C.find((d) => hexDist(G.g, d.p, u.p) <= 1 && d.rl !== u.r && !atWar(G, me, d.o)); B('✝ 종교 전파', () => act({ t: 'spread', u: u.id }), c ? null : '다른 종교 도시 옆에서'); }
      }
      if (T.cl === 'gp') { const w = []; const ok = gpCanUse(G, u, w); B('⭐ 능력 사용', () => { if (GPL[u.g].fx.rel) openRelModal(u); else act({ t: 'gpu', u: u.id }); }, ok ? null : w[0], { class: 'btn primary' }); }
      if (isMil(u.t)) {
        if (canPillage(G, u)) B('🔥 약탈', () => act({ t: 'pil', u: u.id }));
        const uw = []; const up = upgradeTo(G, u);
        if (up >= 0) { const ok = canUpgrade(G, u, uw); if (ok || (uw[0] && uw[0].indexOf('연구 필요') < 0 && uw[0] !== '업그레이드 없음')) B('⬆ ' + UT[up].n + ' 💰' + upgradeCost(G, u), () => act({ t: 'upg', u: u.id }), ok ? null : uw[0]); }
      }
      if (u.go != null) B('이동 취소', () => act({ t: 'stop', u: u.id }));
      if (u.sl) B('깨우기', () => act({ t: 'wake', u: u.id }));
      else B(isMil(u.t) ? '🛡 경계' : '💤 대기', () => { act({ t: 'fort', u: u.id }); setTimeout(nextUnitSoft, 30); }, null, isMil(u.t) ? { 'data-action': 'fort' } : null);
      B('건너뛰기', () => { act({ t: 'skip', u: u.id }); setTimeout(nextUnitSoft, 30); }, null, { 'data-action': 'skip' });
      const del = B(u.delArm ? '정말 해산?' : '해산', () => { if (!u.delArm) { u.delArm = 1; renderBot(); setTimeout(() => { u.delArm = 0; }, 2500); return; } act({ t: 'del', u: u.id }); clearSel(); }, null, { class: 'btn ghost' });
      B('닫기', clearSel, null, { class: 'btn ghost', 'data-key': 'Escape' });
    }
    function nextUnitSoft() { if (!myTurn() || !G) return; const list = G.U.filter((v) => v.o === me && (v.mv > 0 || promoReady(v)) && !v.sl && v.sk !== st.t && !v.go); if (list.length) { selectUnit(list[0], true); centerOn(list[0].p, true); } else clearSel(); }
    function renderTileBot(i, info, btns) {
      const ow = tileOwner(G, i), c = tileCity(G, i);
      const lines = [];
      if (ow >= 0) lines.push((c ? c.n + ' · ' : '') + civName(G, ow) + ' 영토');
      const nw = nwAt(G, i); if (nw) lines.push(nw.d);
      else if (G.feat[i] && FEAT[G.feat[i]]) lines.push(FEAT[G.feat[i]].d);
      if (G.res[i] && (me < 0 || resVisible(G, me, G.res[i]))) { const r = RES[G.res[i]]; lines.push(r.n + '(' + { b: '보너스', l: '사치', s: '전략' }[r.c] + ') ' + yStr(r.y) + ' · 개선: ' + IMP[IMPI[r.im]].n); }
      if (G.dis[i] && DIS[G.dis[i]].k !== 'cc') { const dk = DIS[G.dis[i]].k; lines.push(distName(G, ow, dk) + (DIS[G.dis[i]].y >= 0 ? ' 인접 +' + adjBonus(G, ow, i, dk) : '') + (G.dpil[i] ? ' (약탈됨)' : '')); }
      if (G.won[i]) lines.push(WON[G.won[i] - 1].n + ': ' + WON[G.won[i] - 1].d);
      lines.push('매력 ' + appeal(G, i) + (G.low[i] ? ' · 저지대(해수면 ' + G.low[i] + '단계)' : ''));
      const cc2 = cityAt(G, i);
      if (cc2 && cc2.o !== me) { lines.unshift(cc2.n + ' 인구 ' + cc2.pop + ' · 방어 ' + cityCS(G, cc2) + ' · 체력 ' + cc2.hp + '/200' + (cc2.wl ? ' · 성벽 ' + cc2.wh : '')); }
      info.append(h('div', { class: 'tx' }, h('b', { text: tileTitle(i) }), h('small', { text: lines.join(' / ') })));
      btns.append(h('button', { class: 'btn ghost', text: '닫기', 'data-key': 'Escape', onclick: clearSel }));
      if (myTurn()) { const pt = pendingThing(); btns.append(h('button', { class: 'btn primary end', text: '턴 종료 ▶', 'data-action': 'end', onclick: tryEnd })); }
    }

    /* ---------- 창(시트) ---------- */
    function layoutWide() {
      const r = sheet && wide() ? (sheet.el.offsetWidth || 440) + 12 : 0;
      top.style.right = (6 + r) + 'px'; bot.style.right = r + 'px'; mini.style.right = (6 + r) + 'px';
    }
    function closeSheet(keep) { if (sheet) { sheet.el.remove(); sheet = null; } layoutWide(); if (!keep) { if (mode && mode.k === 'buy') mode = null; dirtyF = true; renderBot(); } }
    function openSheet(kind, arg, opt) {
      if (!st || hideAll) return;
      const prevTab = sheet && sheet.kind === kind && sheet.arg === arg ? sheet.tab : 0;
      closeSheet(true);
      if (kind !== 'city' && mode && mode.k === 'buy') mode = null;
      const el = h('div', { class: 'c6-sheet' + (kind === 'city' || kind === 'trade' ? ' half' : '') });
      tipEl.hidden = true;
      sheet = { kind, arg, el, tab: (opt && opt.tab) || prevTab || 0, draft: null, sc: 0 };
      wrap.appendChild(el);
      renderSheet(); layoutWide();
      if (kind === 'city' && G.cid[arg]) { requestAnimationFrame(() => centerOn(G.cid[arg].p, true)); }
      api.sfx('click'); dirtyF = true; renderBot();
    }
    function renderSheet() {
      if (!sheet) return;
      const old = sheet.el.querySelector('.c6-sh-b'); const sc = old ? old.scrollTop : 0;
      sheet.el.innerHTML = '';
      const fn = SH[sheet.kind]; if (!fn) return;
      const R2 = fn(sheet) || {};
      const head = h('div', { class: 'c6-sh-h' }, h('h3', { text: R2.title || '' }));
      if (R2.headBtn) head.append(R2.headBtn);
      head.append(h('button', { class: 'btn ghost', text: '닫기', 'data-key': 'Escape', onclick: () => closeSheet() }));
      sheet.el.append(head);
      if (R2.tabs) { const tb = h('div', { class: 'c6-tabs' }); R2.tabs.forEach((t, k) => tb.append(h('button', { class: 'btn sm' + (sheet.tab === k ? ' on' : ''), text: t, onclick: () => { sheet.tab = k; renderSheet(); } }))); sheet.el.append(tb); }
      const body = h('div', { class: 'c6-sh-b' }); (R2.body || []).forEach((n) => n && body.append(n));
      sheet.el.append(body);
      body.scrollTop = sc;
    }
    const row = (o) => {
      const r = h('button', { class: 'c6-row' + (o.on ? ' on' : '') + (o.off ? ' off' : '') + (o.done ? ' done' : ''), 'data-action': o.ka || null, onclick: o.fn ? () => { api.sfx('click'); o.fn(); } : null });
      if (o.ic != null) r.append(h('span', { class: 'ic', text: o.ic, style: o.icBg ? { background: o.icBg } : null }));
      r.append(h('span', { class: 'tx' }, h('b', { text: o.t }), o.s ? h('small', { text: o.s }) : null));
      if (o.r != null) r.append(h('span', { class: 'rt' }, String(o.r), o.r2 ? h('small', { text: o.r2 }) : null));
      if (o.btns && o.btns.length) { const bt = h('span', { class: 'bt' }); for (const b of o.btns) { const e2 = h('span', { class: 'btn sm' + (b.p ? ' primary' : ''), role: 'button', tabindex: 0, text: b.t, onclick: (ev) => { ev.stopPropagation(); if (b.dis) { api.toast(b.dis); return; } api.sfx('click'); b.fn(); } }); if (b.dis) e2.style.opacity = 0.45; bt.append(e2); } r.append(bt); }
      return r;
    };
    const lab = (t) => h('div', { class: 'c6-lab', text: t });
    const para = (t, mut) => h('p', { class: 'c6-p' + (mut ? ' mut' : ''), text: t });
    const grid = (items) => { const g2 = h('div', { class: 'c6-grid' }); for (const [a, b] of items) g2.append(h('div', null, h('b', { text: String(a) }), b)); return g2; };
    const bar = (f, c) => h('div', { class: 'c6-bar' }, h('i', { style: { width: (100 * clamp(f, 0, 1)) + '%', background: c || 'var(--brass)' } }));
    const bbtn = (t, fn, o) => { const b = h('button', Object.assign({ class: 'btn' + (o && o.p ? ' primary' : '') + (o && o.ghost ? ' ghost' : ''), text: t, onclick: () => { if (o && o.dis) { api.toast(o.dis); return; } api.sfx('click'); fn(); } }, o && o.attrs || {})); if (o && o.dis) b.style.opacity = 0.45; return b; };
    const canI = () => myTurn();

    const SH = {};
    SH.menu = () => {
      const p = st.P[me];
      const items = [['🔬', '기술 트리', 'tech'], ['🎭', '사회 제도', 'civic'], ['🏛', '정부·정책' + (p.pf ? ' (무료 교체)' : ''), 'policy'], ['🙏', '종교', 'religion'], ['⭐', '위인', 'gp'],
        ['🏰', '도시국가' + (p.env ? ' (사절 ' + p.env + ')' : ''), 'cs'], ['🤝', '외교', 'dip'], ['👤', '총독' + (p.gt ? ' (칭호 ' + p.gt + ')' : ''), 'gov'], ['🌐', '세계 의회' + (st.WC.pend ? ' (투표 중)' : ''), 'wc'],
        ['🕵', '첩보' + ((p.spy || []).length ? ' (' + p.spy.length + ')' : ''), 'spy'], ['🏺', '걸작·관광', 'gw'],
        ['⏳', '시대·기후' + (p.dsel ? ' (헌신 고르기)' : ''), 'era'], ['🏆', '승리 현황', 'victory'], ['🏙', '도시 목록', 'cities'], ['📊', '나라 현황', 'overview'], ['🔔', '알림', 'notes']];
      const KA = { tech: 'tech', civic: 'civics', policy: 'policy', dip: 'dip', cities: 'cities' };
      return { title: '메뉴', body: items.map(([ic, t, k]) => row({ ic, t, ka: KA[k], fn: () => openSheet(k) })) };
    };
    // ----- 기술·제도 트리
    function unlockNames(req) {
      const out = [];
      for (const x of UNLOCK[req] || []) {
        if (x.t === 'u') { const T = UT[x.i]; if (T.civ && T.civ !== civK(G, me)) continue; if (!T.civ && unitFor(G, me, T.k) !== T.k) continue; out.push('⚔' + T.n); }
        else if (x.t === 'b') { const b = BLD[x.i]; if (b.civ && b.civ !== civK(G, me)) continue; if (!b.civ && bldOf(G, me, b.k) !== b.k) continue; out.push('🏠' + b.n); }
        else if (x.t === 'd') out.push('◆' + distName(G, me, DIS[x.i].k));
        else if (x.t === 'w') out.push('🏛' + WON[x.i].n);
        else if (x.t === 'g') out.push('정부:' + GOV[x.i].n);
        else if (x.t === 'p') out.push('정책:' + POL[x.i].n);
        else if (x.t === 'i') { const m = IMP[x.i]; if (m.civ && m.civ !== civK(G, me)) continue; out.push('⛏' + m.n); }
        else if (x.t === 'j') out.push('🚀' + PRJ[x.i].n);
        else if (x.t === 'r') out.push('자원:' + RES[x.i].n);
      }
      return out;
    }
    // 트리 그래프(원작처럼 시대별 열 + 선행 연결선)
    const TN = { w: 122, h: 46, gx: 30, gy: 8, top: 24 };
    function treeLayout(LST) {
      if (LST.lay) return LST.lay;
      const cols = ERA.map(() => []); LST.forEach((x, i) => cols[x.e].push(i));
      const IDX = LST === CIVIC ? CIVICI : TECHI;
      const pos = new Array(LST.length);
      // 선행의 평균 높이로 정렬해서 선이 덜 엉키게
      cols.forEach((col2, e) => {
        const key = (i) => { const pr = LST[i].pre.map((k) => pos[IDX[k]]).filter(Boolean); return pr.length ? pr.reduce((a, q) => a + q.r, 0) / pr.length : 99; };
        col2.sort((a, b) => key(a) - key(b) || a - b);
        col2.forEach((i, r) => { pos[i] = { e, r }; });
      });
      const rows = Math.max(...cols.map((c2) => c2.length));
      LST.lay = { pos, W: ERA.length * (TN.w + TN.gx) + 10, H: TN.top + rows * (TN.h + TN.gy) + 6 };
      return LST.lay;
    }
    function treeGraph(sh, civic) {
      const p = st.P[me], LST = civic ? CIVIC : TECH, IDX = civic ? CIVICI : TECHI, has = (i) => bitHas(civic ? p.ck : p.tk, i), boo = (i) => bitHas(civic ? p.cb : p.tb, i);
      const avail = (i) => (civic ? civicAvail(G, me, i) : techAvail(G, me, i));
      const cost = (i) => (civic ? civicCost(G, me, i) : techCost(G, me, i)), prog = (i) => (civic ? p.cp[i] : p.tp[i]) || 0, cur = civic ? p.cs : p.rs, goal = civic ? p.cg : p.rg;
      let rate = 0; for (const c of citiesOf(G, me)) rate += cityCalc(G, c).y[civic ? 4 : 3];
      const lay = treeLayout(LST), X = (i) => 6 + lay.pos[i].e * (TN.w + TN.gx), Y = (i) => TN.top + lay.pos[i].r * (TN.h + TN.gy);
      // 목표까지 필요한 것
      const need = new Set(); if (goal >= 0) { const st2 = [goal]; while (st2.length) { const i = st2.pop(); if (has(i) || need.has(i)) continue; need.add(i); for (const k of LST[i].pre) st2.push(IDX[k]); } }
      const wrapT = h('div', { class: 'c6-tw' }), gEl = h('div', { class: 'c6-tg', style: { width: lay.W + 'px', height: lay.H + 'px' } });
      const NS = 'http://www.w3.org/2000/svg', svg = document.createElementNS(NS, 'svg');
      svg.setAttribute('width', lay.W); svg.setAttribute('height', lay.H);
      LST.forEach((x, i) => { for (const k of x.pre) { const j = IDX[k]; const x1 = X(j) + TN.w, y1 = Y(j) + TN.h / 2, x2 = X(i), y2 = Y(i) + TN.h / 2, mx = (x1 + x2) / 2; const pa = document.createElementNS(NS, 'path'); pa.setAttribute('d', 'M' + x1 + ' ' + y1 + ' C' + mx + ' ' + y1 + ' ' + mx + ' ' + y2 + ' ' + x2 + ' ' + y2); pa.setAttribute('fill', 'none'); pa.setAttribute('stroke', has(j) && has(i) ? '#4f8f5a' : need.has(i) && (need.has(j) || has(j)) ? '#f0c35a' : has(j) ? '#8a8270' : 'rgba(255,255,255,.16)'); pa.setAttribute('stroke-width', need.has(i) ? 2.2 : 1.4); svg.appendChild(pa); } });
      gEl.appendChild(svg);
      ERA.forEach((n, e) => gEl.appendChild(h('div', { class: 'c6-te', style: { left: (6 + e * (TN.w + TN.gx)) + 'px' }, text: n })));
      LST.forEach((x, i) => {
        const done = has(i), av = avail(i);
        const cls = 'c6-tn' + (done ? ' done' : i === cur ? ' cur' : av ? ' av' : ' lock') + (need.has(i) ? ' goal' : '') + (sh.sel === i ? ' sel' : '');
        gEl.appendChild(h('button', { class: cls, style: { left: X(i) + 'px', top: Y(i) + 'px' }, title: x.n, onclick: () => { sh.sel = sh.sel === i ? null : i; sh.sx = wrapT.scrollLeft; sh.sy = wrapT.scrollTop; renderSheet(); } },
          h('b', { text: x.n }), h('small', { text: done ? '완료' : (i === cur ? '▶ ' : '') + turnsTo(cost(i) - prog(i), rate) + '턴' + (boo(i) ? ' 💡' : '') }), x.b && !done ? h('i', { text: boo(i) ? '✅' : '💡' }) : null));
      });
      wrapT.appendChild(gEl);
      const first = LST.findIndex((x, i) => !has(i));
      requestAnimationFrame(() => { if (sh.sx != null) { wrapT.scrollLeft = sh.sx; wrapT.scrollTop = sh.sy || 0; } else if (first >= 0) wrapT.scrollLeft = Math.max(0, X(cur >= 0 ? cur : first) - 30); });
      wrapT.addEventListener('scroll', () => { sh.sx = wrapT.scrollLeft; sh.sy = wrapT.scrollTop; });
      const body = [];
      body.push(para((civic ? '🎭 문화' : '🔬 과학') + ' +' + Math.round(rate) + '/턴 · 항목을 눌러 자세히 보고 연구·목표로 정해요. 💡 = ' + (civic ? '영감' : '유레카') + ' 조건(이루면 ' + Math.round(boostFrac(G, me) * 100) + '%).', true));
      if (sh.sel != null && LST[sh.sel]) {
        const i = sh.sel, x = LST[i], done = has(i), av = avail(i), un = unlockNames((civic ? 'c:' : '') + x.k);
        const card = h('div', { class: 'c6-card' }, h('div', { class: 'hd' }, h('span', { class: 'tx' }, h('b', { text: x.n + ' · ' + ERA[x.e] }), h('small', { text: done ? '완료' : cost(i) + ' (' + turnsTo(cost(i) - prog(i), rate) + '턴)' + (x.pre.length ? ' · 선행: ' + x.pre.map((k) => LST[IDX[k]].n).join(', ') : '') }))));
        if (x.b && !done) card.append(para((boo(i) ? '✅ ' : '💡 ') + x.bt, !boo(i)));
        if (un.length) card.append(para('여는 것: ' + un.join(' '), true));
        if (!done && canI()) card.append(h('div', { class: 'c6-bb' }, bbtn(av ? (i === cur ? '▶ 연구 중' : '▶ 연구하기') : '🎯 목표로(자동으로 이어 연구)', () => act({ t: civic ? 'civic' : 'tech', k: i }), { p: 1 })));
        body.push(card);
      }
      body.push(wrapT);
      return body;
    }
    function treeSheet(sh, civic) {
      const p = st.P[me], LST = civic ? CIVIC : TECH, has = (i) => bitHas(civic ? p.ck : p.tk, i), boo = (i) => bitHas(civic ? p.cb : p.tb, i);
      const avail = (i) => (civic ? civicAvail(G, me, i) : techAvail(G, me, i));
      const cost = (i) => (civic ? civicCost(G, me, i) : techCost(G, me, i)), prog = (i) => (civic ? p.cp[i] : p.tp[i]) || 0, cur = civic ? p.cs : p.rs, goal = civic ? p.cg : p.rg;
      let rate = 0; for (const c of citiesOf(G, me)) rate += cityCalc(G, c).y[civic ? 4 : 3];
      if (!sh.tab) return { title: civic ? '사회 제도' : '기술 트리', tabs: ['트리', '목록', '지금 가능'], body: treeGraph(sh, civic) };
      const body = [];
      const filt = sh.tab === 1 ? 1 : 2;
      body.push(para((civic ? '문화' : '과학') + ' +' + Math.round(rate) + '/턴. ' + (civic ? '영감' : '유레카') + ' 조건을 이루면 비용의 ' + Math.round(boostFrac(G, me) * 100) + '%를 바로 얻어요. 잠긴 항목을 누르면 목표로 정해 자동으로 이어서 연구해요.', true));
      for (let e = 0; e < ERA.length; e++) {
        const idx = LST.map((x, i) => i).filter((i) => LST[i].e === e && ((filt === 1 && !has(i)) || (filt === 2 && avail(i))));
        if (!idx.length) continue;
        body.push(lab(ERA[e] + ' 시대'));
        for (const i of idx) {
          const X = LST[i], done = has(i), av = avail(i);
          const un = unlockNames((civic ? 'c:' : '') + X.k);
          let s = '';
          if (X.b && !done) s += (boo(i) ? '✅ ' : '💡 ') + X.bt + (boo(i) ? '' : '') + ' · ';
          if (!av && !done) s += '선행: ' + X.pre.map((k) => LST[(civic ? CIVICI : TECHI)[k]].n).join(', ') + ' · ';
          s += un.slice(0, 8).join(' ') + (un.length > 8 ? ' …' : '');
          const left = cost(i) - prog(i);
          body.push(row({ ic: done ? '✓' : i === cur ? '▶' : av ? '○' : '🔒', icBg: done ? '#2d4a34' : i === cur ? (civic ? '#5a3a78' : '#2a4f78') : null, t: X.n + (i === goal ? ' 🎯' : ''), s, r: done ? '' : cost(i), r2: done ? '' : turnsTo(left, rate) + '턴', on: i === cur, done, off: !av && !done,
            fn: done || !canI() ? null : () => act({ t: civic ? 'civic' : 'tech', k: i }) }));
        }
      }
      return { title: civic ? '사회 제도' : '기술 트리', tabs: ['트리', '목록', '지금 가능'], body };
    }
    SH.tech = (sh) => treeSheet(sh, false);
    SH.civic = (sh) => treeSheet(sh, true);
    // ----- 정책
    SH.policy = (sh) => {
      const p = st.P[me], ty = slotTypes(G, me);
      if (!sh.draft || sh.draft.length !== ty.length) sh.draft = p.pol.slice(0, ty.length).concat(new Array(Math.max(0, ty.length - p.pol.length)).fill(-1));
      const body = [];
      const g = GOV[p.gov];
      body.push(h('div', { class: 'c6-card' }, h('div', { class: 'hd' }, h('span', { class: 'tx' }, h('b', { text: '정부: ' + g.n }), h('small', { text: g.d })))));
      const lgs = Object.keys(p.lgT || {}).map(Number).filter((gi) => GOV[gi].lg && legacySteps(G, p.lgT[gi]) > 0);
      body.push(para('정부 유산: 한 정부를 오래 쓰면 보너스가 쌓이고 바꿔도 남아요' + (lgs.length ? ' — ' + lgs.map((gi) => GOV[gi].n + ' ' + GOV[gi].lgd + '×' + legacySteps(G, p.lgT[gi])).join(', ') : ' (아직 없음)') + '.', true));
      if (sh.tab === 1) {
        for (let i = 0; i < GOV.length; i++) {
          const G2 = GOV[i], ok = !G2.req || hasCivic(G, me, G2.req);
          body.push(row({ ic: '🏛', t: G2.n + ' (' + G2.sl.map((n, k) => SLOTN[k][0] + n).join(' ') + ')', s: G2.d + (ok ? '' : ' · 필요: ' + CIVIC[CIVICI[G2.req]].n), on: i === p.gov, off: !ok,
            btns: i !== p.gov && ok && canI() ? [{ t: p.pf ? '바꾸기(무료)' : '💰' + polChangeCost(G, me) * 2, p: 1, dis: !p.pf && p.gold < polChangeCost(G, me) * 2 ? '금이 모자라요' : null, fn: () => act({ t: 'gov', g: i }) }] : [] }));
        }
        return { title: '정부·정책', tabs: ['정책 카드', '정부 바꾸기'], body };
      }
      body.push(para(p.pf ? '✨ 지금은 정책을 무료로 바꿀 수 있어요(사회 제도를 마치면 다시 무료).' : '정책 카드를 바꾸면 바꾼 카드 수만큼 금이 들어요. 사회 제도를 마치면 무료 교체.', !p.pf));
      const draft = sh.draft;
      const chosen = sh.slot;
      ty.forEach((t, k) => {
        const pi = draft[k];
        const b = h('button', { class: 'c6-slot' + (pi >= 0 ? ' fill' : ''), style: { borderColor: SLOTC[SLOTT.indexOf(t)] + (chosen === k ? '' : '99') }, onclick: () => { sh.slot = chosen === k ? null : k; renderSheet(); } },
          h('span', { class: 'ic', text: SLOTN[SLOTT.indexOf(t)][0], style: { width: '30px', height: '30px', borderRadius: '8px', display: 'grid', placeItems: 'center', background: SLOTC[SLOTT.indexOf(t)], color: '#1a1208', fontWeight: 700 } }),
          h('span', { class: 'tx', style: { flex: 1, display: 'flex', flexDirection: 'column' } }, h('b', { text: pi >= 0 ? POL[pi].n : '(빈 ' + SLOTN[SLOTT.indexOf(t)] + ' 슬롯)' }), h('small', { style: { color: 'var(--muted)', fontSize: '11.5px' }, text: pi >= 0 ? POL[pi].d : '눌러서 카드 고르기' })));
        body.push(b);
        if (chosen === k) {
          const cards = POL.map((x, i) => i).filter((i) => polAvail(G, me, i) && (t === 'W' || POL[i].t === t));
          if (pi >= 0) body.push(row({ ic: '✕', t: '비우기', fn: () => { draft[k] = -1; sh.slot = null; renderSheet(); } }));
          for (const i of cards) { const used = draft.indexOf(i); body.push(row({ ic: POL[i].t === 'W' ? '★' : SLOTN[SLOTT.indexOf(POL[i].t)][0], icBg: SLOTC[SLOTT.indexOf(POL[i].t)], t: POL[i].n, s: POL[i].d, off: used >= 0 && used !== k, on: used === k, fn: () => { if (used >= 0) draft[used] = -1; draft[k] = i; sh.slot = null; renderSheet(); } })); }
          if (!cards.length) body.push(para('쓸 수 있는 카드가 없어요. 사회 제도를 더 연구하세요.', true));
        }
      });
      const changed = JSON.stringify(draft) !== JSON.stringify(p.pol);
      const swapC = polSwapCost(G, me, draft);
      if (canI()) body.push(bbtn(changed ? (p.pf || !swapC ? '✔ 적용(무료)' : '✔ 적용 💰' + swapC) : '바뀐 것이 없어요', () => { act({ t: 'pol', a: draft.slice() }); sh.draft = null; }, { p: 1, dis: !changed ? '카드를 바꿔 보세요' : (!p.pf && p.gold < swapC ? '금이 모자라요' : null) }));
      return { title: '정부·정책', tabs: ['정책 카드', '정부 바꾸기'], body };
    };
    // ----- 종교
    SH.religion = (sh) => {
      const p = st.P[me], body = [];
      body.push(grid([[Math.floor(p.faith), '신앙'], [Math.round(p.lf || 0), '신앙/턴'], [st.R.length + '/' + maxReligions(G), '종교']]));
      body.push(lab('만신전'));
      if (p.pan >= 0) body.push(row({ ic: '🙏', t: PANTH[p.pan].n, s: PANTH[p.pan].d, done: 1 }));
      else {
        body.push(para('신앙 ' + panCost(G) + '을 모으면 만신전 신앙 하나를 골라요(먼저 고른 나라만).', true));
        const t = panTaken(G);
        for (let k = 0; k < PANTH.length; k++) if (!t[k]) body.push(row({ ic: '☀', t: PANTH[k].n, s: PANTH[k].d, btns: canI() ? [{ t: '세우기', p: 1, dis: p.faith < panCost(G) ? '신앙 ' + panCost(G) + ' 필요' : null, fn: () => act({ t: 'pan', k }) }] : [] }));
      }
      body.push(lab('내 종교'));
      if (p.rel >= 0) {
        const R2 = st.R[p.rel], hc = G.cid[R2.hc];
        body.push(h('div', { class: 'c6-card' }, h('div', { class: 'hd' }, h('span', { class: 'ic', text: '⛪', style: { fontSize: '22px' } }), h('span', { class: 'tx' }, h('b', { text: RELN[R2.i] }), h('small', { text: '성도: ' + (hc ? hc.n : '없음') + ' · 믿는 도시 ' + G.C.filter((c) => c.rl === p.rel).length + '곳' }))), h('div', { class: 'c6-pills' }, ...R2.bl.map((b) => h('span', { text: BELIEF[b].n })))));
        for (const b of R2.bl) body.push(para('· ' + BELIEF[b].n + ': ' + BELIEF[b].d, true));
        if (!R2.en && R2.f === me) {
          body.push(lab('종교 강화 (신앙 ' + enhanceCost(G) + ')'));
          const t = belTaken(G); sh.ew = sh.ew != null ? sh.ew : -1; sh.ee = sh.ee != null ? sh.ee : -1;
          const pills = (type, key) => h('div', { class: 'c6-pills' }, ...BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === type && !t[i]).map((i) => h('button', { class: sh[key] === i ? 'on' : '', text: BELIEF[i].n, title: BELIEF[i].d, onclick: () => { sh[key] = i; renderSheet(); } })));
          body.push(para('예배 신앙(성지 건물):', true), pills('W', 'ew'));
          if (sh.ew >= 0) body.push(para(BELIEF[sh.ew].d, true));
          body.push(para('강화 신앙:', true), pills('E', 'ee'));
          if (sh.ee >= 0) body.push(para(BELIEF[sh.ee].d, true));
          if (canI()) body.push(bbtn('강화하기', () => act({ t: 'enh', w: sh.ew, e: sh.ee }), { p: 1, dis: sh.ew < 0 || sh.ee < 0 ? '두 신앙을 골라요' : p.faith < enhanceCost(G) ? '신앙 부족' : null }));
        }
        body.push(para('성지가 있는 도시에서 선교사·사도를 신앙으로 사서(도시 화면 → 생산) 다른 도시에 전파해요. 모든 문명에서 내 종교가 과반이면 종교 승리!', true));
      } else if (mods(G, me).noRel) body.push(para('이 문명은 종교를 창시할 수 없어요. 다른 종교를 받아들여 신앙을 써요.', true));
      else body.push(para('위대한 선지자를 얻어 성지 위에서 「능력 사용」하면 종교를 창시해요(성지 → 선지자 점수). 남은 자리: ' + Math.max(0, maxReligions(G) - st.R.length), true));
      body.push(lab('세계의 종교'));
      if (!st.R.length) body.push(para('아직 창시된 종교가 없어요.', true));
      for (let r = 0; r < st.R.length; r++) {
        const R2 = st.R[r], n = G.C.filter((c) => c.rl === r).length;
        const civs = aliveMaj(G).filter((o) => { const cs = citiesOf(G, o); return cs.length && cs.filter((c) => c.rl === r).length * 2 > cs.length; }).length;
        body.push(row({ ic: '⛪', icBg: RELC[R2.i], t: RELN[R2.i] + ' — ' + civName(G, R2.f), s: '믿는 도시 ' + n + '곳 · 과반인 문명 ' + civs + '/' + aliveMaj(G).length }));
      }
      return { title: '종교', body };
    };
    // ----- 위인
    SH.gp = () => {
      const p = st.P[me], rate = gpPoints(G, me), body = [];
      body.push(para('구역과 건물이 위인 점수를 줘요. 점수가 다 차면 「영입」하거나 「포기」해요(포기하면 점수는 남고, 다른 나라가 데려갈 수 있어요). 금·신앙으로 남은 점수를 채워 바로 데려올 수도 있어요(후원).', true));
      for (const c of GPK) {
        const id = st.GP.cur[c], gp = id >= 0 && id != null ? GPL[id] : null, cost = gpCost(G, c), pts = p.gpp[c] || 0;
        let top = 0, topO = -1; for (const o of aliveMaj(G)) if (o !== me && (st.P[o].gpp[c] || 0) > top) { top = st.P[o].gpp[c]; topO = o; }
        const ready = gp && pts >= cost, passed = ready && p.gpPass && p.gpPass[c] === id;
        const r = row({ ic: GPC[c].ic, on: ready && !passed, t: GPC[c].n + (gp ? ': ' + gp.n : ' — 없음') + (ready ? (passed ? ' (포기함)' : ' ✨') : ''), s: gp ? gp.d + (gp.fx.gw ? ' ×' + (GW_CH[gp.fx.gw] || 1) : '') + ' (' + ERA[gp.e] + ')' + ' · 나 ' + Math.floor(pts) + '/' + cost + ' (+' + (Math.round(rate[c] * 10) / 10) + ')' + (topO >= 0 ? ' · 최고 ' + civName(G, topO) + ' ' + Math.floor(top) : '') : '이 시대의 위인이 없어요',
          btns: gp && canI() ? (ready ? [{ t: '영입', p: 1, fn: () => act({ t: 'gpr', c }) }].concat(passed ? [] : [{ t: '포기', fn: () => act({ t: 'gpx', c }) }]) : [{ t: '💰' + gpPatronCost(G, me, c, 'g'), dis: p.gold < gpPatronCost(G, me, c, 'g') ? '금 부족' : null, fn: () => act({ t: 'gpb', c, cur: 'g' }) }, { t: '🙏' + gpPatronCost(G, me, c, 'f'), dis: p.faith < gpPatronCost(G, me, c, 'f') ? '신앙 부족' : null, fn: () => act({ t: 'gpb', c, cur: 'f' }) }]) : [] });
        body.push(r); body.push(bar(pts / cost));
      }
      const mine = G.U.filter((u) => u.o === me && u.t === UTI.gp);
      if (mine.length) { body.push(lab('내 위인')); for (const u of mine) body.push(row({ ic: GPC[GPL[u.g].c].ic, t: GPL[u.g].n + (u.ch > 1 && GPL[u.g].fx.gw ? ' (걸작 ' + u.ch + ')' : ''), s: GPL[u.g].d, fn: () => { closeSheet(); selectUnit(u); centerOn(u.p, true); } })); }
      if (p.rq > 0) body.push(para('✨ 넣을 곳이 없는 성유물 ' + p.rq + '개 — 신전을 지으면 자동으로 들어가요.', true));
      return { title: '위인', body };
    };
    // ----- 도시국가
    SH.cs = (sh) => {
      const p = st.P[me], body = [];
      const envNeed = Math.round(20 * Math.max(0.6, st.spT) * (1 + 0.15 * (p.envT || 0)));
      body.push(grid([[p.env, '남은 사절'], [Math.floor(p.ei || 0) + '/' + envNeed, '다음 사절'], [G.P.filter((q) => q.k === 'cs' && q.suz === me).length, '종주국']]));
      body.push(para('사절 1명: 수도에 그 종류 산출 +2 · 3명: 맞는 구역 도시마다 +2 · 6명: +2 더. 사절이 3명 이상이고 가장 많으면 종주국이 되어 특별 보너스를 받아요. 도시국가의 부탁(퀘스트)을 들어주면 사절 +1. 종주국은 금을 내고 그 군대를 ' + Math.round(30 * Math.max(0.6, st.spT)) + '턴 징집할 수 있어요.', true));
      const list = G.P.filter((q) => q.k === 'cs' && q.a && met(G, me, q.o));
      if (!list.length) body.push(para('아직 만난 도시국가가 없어요. 탐험하세요!', true));
      for (const q of list) {
        const T = CST[CSL[q.cs].t], n = q.envs[me] || 0;
        const others = Object.keys(q.envs).filter((k) => +k !== me && q.envs[k]).map((k) => civName(G, +k) + ' ' + q.envs[k]).join(', ');
        const qq = (q.qs || {})[me];
        body.push(row({ ic: T[0][0], icBg: T[3], t: CSL[q.cs].n + ' (' + T[0] + ')' + (q.suz >= 0 ? ' 👑' + civName(G, q.suz) : ''), s: '내 사절 ' + n + (others ? ' · ' + others : '') + ' · 종주국: ' + CSL[q.cs].d + (qq ? ' · 📜 부탁: ' + csQuestText(G, qq) + '(사절 +1)' : '') + (q.levT > 0 ? ' · 징집 중(' + civName(G, q.lev) + ' ' + q.levT + '턴)' : '') + (atWar(G, me, q.o) ? ' · ⚔ 전쟁 중' : ''),
          btns: canI() ? [{ t: '사절 +1', p: 1, dis: p.env <= 0 ? '사절이 없어요' : atWar(G, me, q.o) ? '전쟁 중' : null, fn: () => act({ t: 'env', cs: q.o }) }].concat(q.suz === me && !(q.levT > 0) ? [{ t: '징집 💰' + levyCost(G), dis: p.gold < levyCost(G) ? '금 부족' : !G.U.some((u) => u.o === q.o && isGround(u.t)) ? '군대가 없어요' : null, fn: () => act({ t: 'levy', cs: q.o }) }] : []).concat((() => { const w = []; const k = atWar(G, me, q.o) ? 'peace' : 'war'; const ok = canPropose(G, me, q.o, k, w); const armed = sh.arm === 'cs' + q.o; return [{ t: k === 'war' ? (armed ? '정말?' : '⚔') : '🕊', dis: ok ? null : w[0], fn: () => { if (k === 'war' && !armed) { sh.arm = 'cs' + q.o; renderSheet(); return; } sh.arm = null; act({ t: 'dip', to: q.o, k }); } }]; })()) : [] }));
      }
      return { title: '도시국가', body };
    };
    // ----- 외교
    SH.dip = (sh) => {
      const p = st.P[me], body = [];
      const inc = st.Q.map((q, i) => ({ q, i })).filter((x) => x.q.t === me);
      if (inc.length) { body.push(lab('받은 제안')); for (const { q, i } of inc) body.push(row({ ic: '📨', icBg: col(q.f), t: civName(G, q.f) + ': ' + (q.k === 'deal' ? '거래' : DIPN[q.k]), s: q.k === 'deal' ? dealText(G, q.d, 1) : '', btns: canI() ? [{ t: '수락', p: 1, fn: () => act({ t: 'ans', i, ok: 1 }) }, { t: '거절', fn: () => act({ t: 'ans', i, ok: 0 }) }] : [] })); }
      const myDL = (st.DL || []).filter((d) => d.a === me || d.b === me);
      if (myDL.length) { body.push(lab('진행 중인 거래')); for (const d of myDL) body.push(row({ ic: '🤝', icBg: col(d.a === me ? d.b : d.a), t: (d.a === me ? '→ ' + civName(G, d.b) : '← ' + civName(G, d.a)) + ': ' + (d.gp ? '턴당 금 ' + d.gp : d.lx ? RES[d.lx].n : d.ob ? '국경 개방' : ''), r: d.t + '턴' })); }
      const others = aliveMaj(G).filter((o) => o !== me);
      for (const o of others) {
        const q = st.P[o], known = met(G, me, o);
        if (!known) { body.push(row({ ic: '?', t: '만나지 못한 문명', s: '탐험해서 만나세요.' })); continue; }
        const stt = dipSt(G, me, o), stN = ['전쟁', '평화', '친선', '동맹'][stt], stC = ['w', 'p', 'd', 'a'][stt];
        const C2 = CIVS[q.civ], r = st.D[dkey(me, o)] || {};
        const opn = q.lv > 0 ? opinion(G, o, me) : null;
        const card = h('div', { class: 'c6-card' });
        card.append(h('div', { class: 'hd' }, h('span', { class: 'tok', style: { width: '34px', height: '34px', borderRadius: '50%', background: col(o), flex: 'none' } }), h('span', { class: 'tx' }, h('b', { text: C2.n + ' · ' + C2.ld + (q.lv > 0 ? '' : ' (사람)') }), h('small', { text: '성향 「' + C2.agn + '」: ' + C2.agd + (opn != null ? ' · 우리에 대한 호감 ' + (opn > 0 ? '+' : '') + opn : '') })), h('span', { class: 'c6-st ' + stC, text: stN + (r.t > 0 ? ' ' + r.t + '턴' : '') })));
        card.append(h('small', { style: { color: 'var(--muted)', fontSize: '11.5px' }, text: '점수 ' + scoreOf(G, o) + ' · 군사력 ' + Math.round(milPower(G, o)) + ' (우리 ' + Math.round(milPower(G, me)) + ') · 도시 ' + citiesOf(G, o).length + ' · 불만 ' + Math.round(p.gr[o] || 0) + (q.rel >= 0 ? ' · ' + RELN[st.R[q.rel].i] : '') }));
        if (q.lv > 0) {
          const ln = (st.DLG || []).filter((d) => d.f === o && d.t === me).pop();
          let tx = ln && st.t - ln.n <= 25 ? ln.x : '', aiT = !!(tx && ln.ai);
          if (!tx) { const arr = DL[voiceK(q.civ)]['mood_' + (opn == null ? 'n' : opn >= 15 ? 'f' : opn <= -12 ? 'h' : 'n')]; tx = arr[(st.t + o) % arr.length].split('{me}').join(C2.n).split('{you}').join(civName(G, me)); }
          card.append(h('div', { class: 'c6-say' }, h('b', { text: C2.ld + ' ' }), '“' + tx + '”', aiT ? h('i', { text: ' ✦' }) : ''));
        }
        if (canI()) {
          const bb = h('div', { class: 'c6-bb' });
          if (stt !== 0) bb.append(bbtn('🤝 거래', () => openSheet('deal', o), { p: 1 }));
          for (const k of ['war', 'peace', 'dof', 'ally', 'den', 'end']) {
            const w = []; const ok = canPropose(G, me, o, k, w);
            if (!ok && (k === 'peace' && stt !== 0 || k === 'war' && stt === 0 || k === 'end' && stt < 2 || k === 'ally' && stt === 3 || k === 'dof' && stt >= 2)) continue;
            const armed = sh.arm === o + k;
            bb.append(bbtn((k === 'war' && armed ? '정말 ' : '') + DIPN[k], () => { if ((k === 'war' || k === 'end') && !armed) { sh.arm = o + k; renderSheet(); return; } sh.arm = null; act({ t: 'dip', to: o, k }); }, { dis: ok ? null : w[0], ghost: k === 'den' || k === 'end' }));
          }
          card.append(bb);
        }
        body.push(card);
      }
      if (!others.length) body.push(para('다른 문명이 없어요.', true));
      body.push(para('전쟁 중인 나라만 공격할 수 있어요. 평화 중인 나라 영토에는 친선·동맹이 아니면 군사 유닛이 못 들어가요. 친선을 깨거나 기습 전쟁을 하면 다른 나라들의 불만이 커져요.', true));
      return { title: '외교', body };
    };
    // ----- 총독
    SH.gov = (sh) => {
      const p = st.P[me], body = [];
      body.push(grid([[p.gt, '남은 칭호'], [p.gv.length + '/7', '임명']]));
      body.push(para('칭호 하나로 새 총독을 임명하거나 진급시켜요. 도시에 배치하면 몇 턴 뒤 효과가 생기고 충성도 +8.', true));
      for (let k = 0; k < GOVR.length; k++) {
        const D = GOVR[k], gv = p.gv.find((x) => x.g === k);
        const card = h('div', { class: 'c6-card' });
        card.append(h('div', { class: 'hd' }, h('span', { class: 'ic', text: '👤', style: { fontSize: '20px' } }), h('span', { class: 'tx' }, h('b', { text: D.n + ' (' + D.t + ')' }), h('small', { text: D.d + (gv ? ' · ' + (gv.c >= 0 && G.cid[gv.c] ? G.cid[gv.c].n + (gv.est > 0 ? ' (부임까지 ' + gv.est + '턴)' : ' 근무 중') : '미배치') : '') }))));
        card.append(h('div', { class: 'c6-pills' }, ...D.pr.map((x, n) => h('span', { style: gv && gv.pr > n ? { background: 'var(--brass)', color: '#1c1408' } : null, text: (gv && gv.pr > n ? '✓ ' : '') + x[0] + ': ' + x[2] }))));
        if (canI()) {
          const bb = h('div', { class: 'c6-bb' });
          if (!gv) bb.append(bbtn('임명', () => act({ t: 'gvA', g: k }), { p: 1, dis: p.gt <= 0 ? '칭호가 없어요' : null }));
          else {
            if (gv.pr < 2) bb.append(bbtn('진급', () => act({ t: 'gvP', g: k }), { dis: p.gt <= 0 ? '칭호가 없어요' : null }));
            bb.append(bbtn(sh.pick === k ? '도시 고르기 ▾' : '배치', () => { sh.pick = sh.pick === k ? null : k; renderSheet(); }));
          }
          card.append(bb);
          if (sh.pick === k && gv) card.append(h('div', { class: 'c6-pills' }, ...citiesOf(G, me).map((c) => h('button', { class: gv.c === c.id ? 'on' : '', text: c.n + ' (충성 ' + Math.round(c.lo) + ')', onclick: () => { sh.pick = null; act({ t: 'gvS', g: k, c: c.id }); } }))));
        }
        body.push(card);
      }
      return { title: '총독', body };
    };
    // ----- 세계 의회
    SH.wc = (sh) => {
      const p = st.P[me], body = [], WC = st.WC;
      body.push(grid([[Math.floor(p.favor || 0), '외교 호의'], [WC.nx >= 0 ? WC.nx + '턴' : '중세 이후', '다음 회의'], [(p.dvp || 0) + '/' + DVP_WIN, '외교 승리 점수']]));
      if (WC.pend) {
        body.push(lab('이번 회의 결의안 — 표 1개는 무료, 더 사면 호의 10·20·30…'));
        WC.pend.res.forEach((ri2, k) => {
          const R2 = RESO[ri2], tg = resTargets(G, ri2), mv = WC.pend.votes[me] && WC.pend.votes[me][k];
          sh.v = sh.v || {}; const d = sh.v[k] = sh.v[k] || { op: mv ? mv.op : 0, tg: mv ? mv.tg : tg[0], n: mv ? mv.n : 1 };
          const card = h('div', { class: 'c6-card' });
          card.append(h('div', { class: 'hd' }, h('span', { class: 'tx' }, h('b', { text: R2.n }), h('small', { text: 'A: ' + R2.a + ' / B: ' + R2.b }))));
          card.append(h('div', { class: 'c6-pills' }, h('button', { class: d.op === 0 ? 'on' : '', text: 'A 찬성', onclick: () => { d.op = 0; renderSheet(); } }), h('button', { class: d.op === 1 ? 'on' : '', text: 'B', onclick: () => { d.op = 1; renderSheet(); } })));
          card.append(h('div', { class: 'c6-pills' }, ...tg.map((t) => h('button', { class: String(d.tg) === String(t) ? 'on' : '', text: R2.tg === 'p' ? civName(G, t) : R2.tg === 'd' ? DIS[DISI[t]].n : R2.tg === 'g' ? GPC[t].n : '전체', onclick: () => { d.tg = t; renderSheet(); } }))));
          card.append(h('div', { class: 'c6-pills' }, h('button', { text: '−', onclick: () => { d.n = Math.max(1, d.n - 1); renderSheet(); } }), h('span', { text: '표 ' + d.n + ' (호의 ' + voteCost(d.n - 1) + ')' }), h('button', { text: '+', onclick: () => { d.n = Math.min(6, d.n + 1); renderSheet(); } })));
          if (canI()) card.append(bbtn(mv ? '투표 바꾸기' : '투표하기', () => act({ t: 'vote', r: k, op: d.op, tg: d.tg, n: d.n }), { p: !mv }));
          if (mv) card.append(h('small', { style: { color: '#9fd36a' }, text: '✓ 투표함: ' + (mv.op ? 'B' : 'A') + ' · 표 ' + mv.n }));
          body.push(card);
        });
        body.push(para('투표하지 않으면 기권해요. 결의는 다음 라운드에 정해져요.', true));
      } else body.push(para(WC.nx >= 0 ? '다음 회의 전에 결의안이 공개돼요.' : '세계가 중세 시대에 들어서면 세계 의회가 열려요.', true));
      if (WC.last && WC.last.length) { body.push(lab('지난 결의')); for (const t of WC.last) body.push(para('· ' + t)); }
      body.push(lab('외교 승리 점수'));
      for (const o of aliveMaj(G)) body.push(row({ ic: '🕊', icBg: col(o), t: civName(G, o), r: (st.P[o].dvp || 0) + '/' + DVP_WIN }));
      return { title: '세계 의회', body };
    };
    // ----- 시대·기후
    SH.era = (sh) => {
      const p = st.P[me], body = [], th = ageThresholds(G);
      body.push(grid([[ERA[st.era], '세계 시대'], [AGEN[p.age], '우리 시대'], [p.es || 0, '이번 시대 점수']]));
      body.push(para('시대 점수 ' + th.dark + ' 미만이면 다음 시대는 암흑기, ' + th.gold + ' 이상이면 황금기(암흑기 다음이면 영웅 시대). 불가사의·위인·첫 구역·종교·새 도시·전투 승리 등으로 점수를 얻어요.', true));
      body.push(bar((p.es || 0) / th.gold, '#f0c35a'));
      if (p.dsel) {
        body.push(lab('헌신 고르기' + (p.dsel >= 2 ? ' (영웅 시대: 2개)' : '')));
        DEDI.forEach((d, k) => body.push(row({ ic: '✦', t: d.n, s: d.d, on: p.ded === k || p.ded2 === k, fn: canI() ? () => act({ t: 'ded', k }) : null })));
      } else if (p.ded >= 0) { body.push(lab('이번 시대 헌신')); body.push(row({ ic: '✦', t: DEDI[p.ded].n, s: DEDI[p.ded].d, done: 1 })); if (p.ded2 >= 0) body.push(row({ ic: '✦', t: DEDI[p.ded2].n, s: DEDI[p.ded2].d, done: 1 })); }
      if ((st.CH || []).length) { body.push(lab('📜 연대기')); for (const c of st.CH) body.push(row({ ic: '📜', t: c.x + (c.ai ? ' ✦' : ''), s: c.n + '턴' })); }
      body.push(lab('기후 (몰려드는 폭풍)'));
      const CL = st.CL;
      body.push(grid([[CLIM[CL.st], '기후 단계'], [Math.round(CL.co2), '누적 이산화탄소'], [CL.sea + '/3', '해수면 상승']]));
      body.push(para('석탄·석유 발전소가 이산화탄소를 내요. 단계가 오르면 홍수·폭풍·가뭄이 잦아지고 3·5·7단계에 저지대가 바다에 잠겨요(방조제로 막기). 「탄소 포집」 프로젝트로 줄일 수 있어요. 재해 강도: ' + ['끔', '보통', '강함'][st.dis], true));
      const ds = (p.nt || []).filter((n) => n.k === 'dis').slice(-5).reverse();
      for (const n of ds) body.push(row({ ic: '⚠', t: n.m, s: n.t + '턴', fn: n.p >= 0 ? () => { closeSheet(); centerOn(n.p, true); } : null }));
      return { title: '시대·기후', body };
    };
    // ----- 승리
    SH.victory = () => {
      const body = [], al = aliveMaj(G);
      const nm = (o) => (met(G, me, o) ? civName(G, o) : '???');
      body.push(lab('🚀 과학: 인공위성 → 달 → 화성 → 외계 탐사대가 ' + LY_WIN + '광년'));
      for (const o of al) { const sv = st.P[o].sv; const n = ['sat', 'moon', 'mars', 'exo'].filter((k) => sv[k]).length; body.push(row({ ic: '🚀', icBg: col(o), t: nm(o), s: met(G, me, o) ? '기술 ' + cntBits(st.P[o].tk) + '/' + TECH.length + ' · 단계 ' + n + '/4' + (sv.exo ? ' · ' + (sv.ly || 0) + '/' + LY_WIN + '광년' : '') : '아직 못 만났어요', r: n + '/4' })); }
      body.push(lab('🎭 문화: 다른 나라에서 온 관광객 > 어느 나라의 국내 관광객'));
      let maxDom = 0; for (const o of al) maxDom = Math.max(maxDom, domTourists(G, o));
      for (const o of al) body.push(row({ ic: '🎭', icBg: col(o), t: nm(o), s: met(G, me, o) ? '관광 ' + Math.round(st.P[o].tour || 0) + '/턴 · 국내 관광객 ' + domTourists(G, o) : '아직 못 만났어요', r: visTourists(G, o) + '명' }));
      body.push(lab('⚔ 지배: 모든 나라의 처음 수도를 차지'));
      const caps = G.C.filter((c) => c.oc && isMaj(G, c.oo));
      for (const o of al) body.push(row({ ic: '⚔', icBg: col(o), t: nm(o), r: caps.filter((c) => c.o === o).length + '/' + caps.length }));
      body.push(lab('⛪ 종교: 모든 문명에서 내 종교가 과반'));
      for (let r = 0; r < st.R.length; r++) { const n = al.filter((o) => { const cs = citiesOf(G, o); return cs.length && cs.filter((c) => c.rl === r).length * 2 > cs.length; }).length; body.push(row({ ic: '⛪', icBg: RELC[st.R[r].i], t: RELN[st.R[r].i] + ' (' + nm(st.R[r].f) + ')', r: n + '/' + al.length })); }
      if (!st.R.length) body.push(para('아직 종교가 없어요.', true));
      body.push(lab('🕊 외교: 외교 승리 점수 ' + DVP_WIN));
      for (const o of al) body.push(row({ ic: '🕊', icBg: col(o), t: nm(o), r: (st.P[o].dvp || 0) + '/' + DVP_WIN }));
      body.push(lab('🏆 점수(' + st.tl + '턴이 끝나면 1등 승리)'));
      for (const o of al.slice().sort((a, b) => scoreOf(G, b) - scoreOf(G, a))) body.push(row({ ic: '★', icBg: col(o), t: nm(o), r: scoreOf(G, o) }));
      return { title: '승리 현황', body };
    };
    SH.cities = () => {
      const body = [];
      for (const c of citiesOf(G, me)) { const cc = cityCalc(G, c), it = c.q[0]; body.push(row({ ic: String(c.pop), icBg: col(me), t: c.n + (c.b.indexOf('palace') >= 0 ? ' ★' : ''), s: yStr(cc.y.map((v) => Math.round(v))) + ' · 주거 ' + c.pop + '/' + cc.hous + ' · 쾌적 ' + (cc.amen - cc.amenNeed >= 0 ? '+' : '') + (cc.amen - cc.amenNeed) + ' · 충성 ' + Math.round(c.lo), r: it ? itemName(G, me, it) : '⚠ 생산 없음', r2: it ? turnsTo(itemCost(G, c, it) - (c.pp[itemKey(it)] || 0), cc.y[1] * itemMul(G, c, it)) + '턴' : '', fn: () => openSheet('city', c.id) })); }
      if (!body.length) body.push(para('아직 도시가 없어요. 개척자로 도시를 세우세요.', true));
      return { title: '도시 목록', body };
    };
    SH.overview = () => {
      const p = st.P[me], body = [], inc = incomeOf(G, me);
      body.push(grid([[Math.round(inc.y[0]), '🌾 식량'], [Math.round(inc.y[1]), '⚒ 생산'], [Math.round(inc.y[2]), '💰 도시 금'], [Math.round(inc.y[3]), '🔬 과학'], [Math.round(inc.y[4]), '🎭 문화'], [Math.round(inc.y[5]), '🙏 신앙']]));
      body.push(lab('금'));
      body.push(row({ ic: '💰', t: '도시 수입', r: '+' + Math.round(inc.y[2]) }), row({ ic: '⚔', t: '유닛 유지비', r: '−' + inc.um }), row({ ic: '🏠', t: '건물·구역 유지비', r: '−' + inc.bm }), row({ ic: '＝', t: '순수입', r: (inc.gold >= 0 ? '+' : '') + Math.round(inc.gold) }));
      body.push(lab('전략 자원 (보유 / 한도)'));
      const cap = 30 + 10 * techEra(G, me);
      body.push(h('div', { class: 'c6-pills' }, ...STRAT.filter((r) => resVisible(G, me, r)).map((r) => h('span', { text: RES[r].n + ' ' + (p.stk[r] || 0) + '/' + cap }))));
      body.push(lab('사치 자원 (종류마다 도시 4곳 쾌적도 +1)'));
      const lux = ownedLux(G, me); body.push(h('div', { class: 'c6-pills' }, ...(Object.keys(lux).length ? Object.keys(lux).map((r) => h('span', { text: RES[r].n + (lux[r] > 1 ? '×' + lux[r] : '') })) : [h('span', { text: '없음' })])));
      body.push(lab('기타'));
      body.push(row({ ic: '✈', t: '관광', r: Math.round(p.tour || 0) + '/턴' }), row({ ic: '🐪', t: '교역로', r: p.tr.length + '/' + tradeCap(G, me) }), row({ ic: '🕊', t: '외교 호의', r: Math.floor(p.favor || 0) }), row({ ic: '😣', t: '전쟁 피로', r: Math.round(p.ww || 0) }));
      for (const tr of p.tr) { const f = G.cid[tr.f], d = G.cid[tr.d]; if (f && d) body.push(row({ ic: '→', t: f.n + ' → ' + d.n, s: yStr(tradeYield(G, tr)), r: tr.t + '턴' })); }
      return { title: '나라 현황', body };
    };
    SH.notes = () => {
      const p = st.P[me], body = [];
      const list = (p.nt || []).slice().reverse();
      if (!list.length) body.push(para('알림이 없어요.', true));
      for (const n of list) body.push(row({ ic: n.m.match(/^\S+/) ? '•' : '•', t: n.m, s: n.t + '턴', fn: n.p >= 0 ? () => { closeSheet(); centerOn(n.p, true); sel = { k: 't', p: n.p }; renderBot(); } : null }));
      return { title: '알림', body };
    };
    SH.trade = (sh) => {
      const u = G.uid[sh.arg]; const body = [];
      if (!u) return { title: '교역로', body: [para('상인이 없어요.')] };
      const f = cityAt(G, u.p);
      for (const id of tradeDests(G, u)) { const d = G.cid[id], y = tradeYield(G, { f: f.id, d: id }); body.push(row({ ic: d.o === me ? '🏠' : '🌍', icBg: col(d.o), t: d.n + (d.o !== me ? ' (' + civName(G, d.o) + ')' : ''), s: '출발 도시: ' + yStr(y) + ' · 거리 ' + hexDist(G.g, f.p, d.p), fn: canI() ? () => { act({ t: 'trade', u: u.id, d: id }); closeSheet(); clearSel(); } : null })); }
      if (!body.length) body.push(para('갈 수 있는 도시가 없어요(만난 나라, 전쟁 중이 아닌 곳, 16칸 안).', true));
      return { title: '교역로 — ' + (f ? f.n : ''), body };
    };

    // ----- 거래
    SH.deal = (sh) => {
      const o = sh.arg, body = [];
      if (!sh.d) sh.d = { A: {}, B: {} };
      const d = sh.d;
      const lxAvail = (who) => { const own = ownedLux(G, who, true); for (const x of (st.DL || [])) if (x.lx && x.a === who && own[x.lx]) own[x.lx]--; return Object.keys(own).filter((r) => own[r] > 0).map(Number); };
      const side = (who, X, label) => {
        const pp = st.P[who], card = h('div', { class: 'c6-card' });
        card.append(h('div', { class: 'hd' }, h('span', { class: 'tok', style: { width: '26px', height: '26px', borderRadius: '50%', background: col(who), flex: 'none' } }), h('span', { class: 'tx' }, h('b', { text: label }), h('small', { text: '금 ' + Math.floor(pp.gold) + ' · 턴당 ' + Math.round(incomeOf(G, who).gold) }))));
        const gRow = h('div', { class: 'c6-pills' }, h('span', { text: '금 ' + (X.g || 0) }), ...[-50, -10, 10, 50].map((v) => h('button', { text: (v > 0 ? '+' : '') + v, onclick: () => { X.g = clamp((X.g || 0) + v, 0, Math.floor(pp.gold)); renderSheet(); } })));
        const gpRow = h('div', { class: 'c6-pills' }, h('span', { text: '턴당 금 ' + (X.gp || 0) + '(' + dealTurns(G) + '턴)' }), ...[-1, 1, 5].map((v) => h('button', { text: (v > 0 ? '+' : '') + v, onclick: () => { X.gp = clamp((X.gp || 0) + v, 0, Math.max(0, Math.floor(incomeOf(G, who).gold))); renderSheet(); } })));
        card.append(gRow, gpRow);
        const lx = lxAvail(who);
        if (lx.length) card.append(h('small', { style: { color: 'var(--muted)' }, text: '사치 자원(' + dealTurns(G) + '턴)' }), h('div', { class: 'c6-pills' }, ...lx.map((r) => { const on = (X.lx || []).indexOf(r) >= 0; return h('button', { class: on ? 'on' : '', text: RES[r].n, onclick: () => { X.lx = X.lx || []; if (on) X.lx = X.lx.filter((x) => x !== r); else X.lx.push(r); renderSheet(); } }); })));
        const strs = STRAT.filter((r) => (pp.stk[r] || 0) >= 5 && (who === me || resVisible(G, me, r)));
        if (strs.length) card.append(h('small', { style: { color: 'var(--muted)' }, text: '전략 자원(5씩)' }), h('div', { class: 'c6-pills' }, ...strs.map((r) => { const n2 = (X.st || {})[r] || 0; return h('button', { class: n2 ? 'on' : '', text: RES[r].n + (n2 ? ' ' + n2 : ''), onclick: () => { X.st = X.st || {}; const nx = n2 + 5 > pp.stk[r] ? 0 : n2 + 5; if (nx) X.st[r] = nx; else delete X.st[r]; renderSheet(); } }); })));
        const cs2 = citiesOf(G, who).filter((c) => c.b.indexOf('palace') < 0);
        if (cs2.length) card.append(h('small', { style: { color: 'var(--muted)' }, text: '도시' }), h('div', { class: 'c6-pills' }, ...cs2.map((c) => { const on = (X.cy || []).indexOf(c.id) >= 0; return h('button', { class: on ? 'on' : '', text: c.n + ' ' + c.pop, onclick: () => { X.cy = X.cy || []; if (on) X.cy = X.cy.filter((x) => x !== c.id); else X.cy.push(c.id); renderSheet(); } }); })));
        if (!openBorders(G, who, who === me ? o : me)) card.append(h('div', { class: 'c6-pills' }, h('button', { class: X.ob ? 'on' : '', text: '🛂 국경 개방(' + dealTurns(G) + '턴)', onclick: () => { X.ob = X.ob ? 0 : 1; renderSheet(); } })));
        card.append(h('div', { class: 'c6-pills' }, h('button', { class: X.ra ? 'on' : '', text: '🔬 연구 협정(금 ' + raCost(G) + ', 끝나면 과학)', onclick: () => { X.ra = X.ra ? 0 : 1; renderSheet(); } })));
        const foes = aliveMaj(G).filter((q) => q !== me && q !== o && met(G, me, q) && met(G, o, q));
        if (foes.length) card.append(h('small', { style: { color: 'var(--muted)' }, text: '공동 전쟁(이쪽이 선전 포고)' }), h('div', { class: 'c6-pills' }, ...foes.map((q) => h('button', { class: X.jw === q ? 'on' : '', text: '⚔ ' + civName(G, q), onclick: () => { X.jw = X.jw === q ? undefined : q; renderSheet(); } }))));
        return card;
      };
      body.push(para('주고받을 것을 고르고 「제안」을 눌러요. 사치 자원·턴당 금·국경 개방은 ' + dealTurns(G) + '턴 동안이에요. 마지막 사치 자원을 주면 그만큼 쾌적도가 줄어요.', true));
      body.push(side(me, d.A, '내가 줄 것'), side(o, d.B, civName(G, o) + '이(가) 줄 것'));
      const why = []; const ok = dealOK(G, me, o, d, why);
      if (st.P[o].lv > 0 && ok) { const v = aiDealValue(G, o, me, d.A, d.B); body.push(para(v >= 0 ? '🙂 받아들일 것 같아요.' : v > -60 ? '😐 조금 더 얹어 주면 받을지도요.' : '🙁 받아들이지 않을 것 같아요.', true)); }
      if (canI()) body.push(h('div', { class: 'c6-bb' }, bbtn('비우기', () => { sh.d = null; renderSheet(); }, { ghost: 1 }), bbtn('제안', () => { act({ t: 'deal', to: o, A: d.A, B: d.B }); sh.d = null; }, { p: 1, dis: ok ? null : why[0] })));
      return { title: '거래 — ' + civName(G, o), body };
    };
    // ----- 첩보
    SH.spy = (sh) => {
      const p = st.P[me], body = [], cap = spyCap(G, me);
      body.push(grid([[(p.spy || []).length + '/' + cap, '첩보원'], [cap ? '도시에서 생산' : '「외교 업무」', '만들기']]));
      body.push(para('첩보원은 도시에서 만들어요(외교 업무·민족주의·냉전·세계화 제도와 외교 구역마다 한도 +1). 임무를 주면 그 도시로 가서(거리에 따라 몇 턴) 일을 해요. 실패하면 붙잡히거나 도망쳐요.', true));
      (p.spy || []).forEach((sp, i) => {
        const c = G.cid[sp.c];
        const card = h('div', { class: 'c6-card' });
        card.append(h('div', { class: 'hd' }, h('span', { class: 'ic', text: '🕵', style: { fontSize: '20px' } }), h('span', { class: 'tx' }, h('b', { text: '첩보원 ' + (i + 1) + ' · ' + ['', '신입', '요원', '베테랑'][sp.lv || 1] }), h('small', { text: sp.m ? SPYM[sp.m].n + ' — ' + (c ? c.n : '?') + (sp.tr > 0 ? ' (이동 ' + sp.tr + '턴)' : SPYM[sp.m].t ? ' (' + sp.t + '턴 남음 · 성공 ' + Math.round(spyOdds(G, me, sp, sp.c, sp.m) * 100) + '%)' : ' (계속)') : '대기 중' }))));
        if (canI()) {
          if (sp.m) card.append(h('div', { class: 'c6-bb' }, bbtn('임무 그만두기', () => act({ t: 'spyx', i }), { ghost: 1 })));
          else {
            const pickC = sh.pc === i ? sh.c : null;
            const cities = G.C.filter((x) => isEx(x.p) && (x.o === me || (isMaj(G, x.o) && met(G, me, x.o)) || (st.P[x.o].k === 'cs' && met(G, me, x.o))));
            card.append(h('div', { class: 'c6-pills' }, ...cities.slice(0, 30).map((x) => h('button', { class: pickC === x.id ? 'on' : '', text: (x.o === me ? '🏠' : '') + x.n, onclick: () => { sh.pc = i; sh.c = x.id; renderSheet(); } }))));
            if (pickC != null) {
              for (const m in SPYM) { const w = []; if (!spyMissionOK(G, me, sp, pickC, m, w)) continue; card.append(row({ ic: '•', t: SPYM[m].n + (SPYM[m].t ? ' (' + SPYM[m].t + '턴)' : ''), s: SPYM[m].d, r: Math.round(spyOdds(G, me, sp, pickC, m) * 100) + '%', fn: () => { sh.pc = null; act({ t: 'spy', i, c: pickC, m }); } })); }
            }
          }
        }
        body.push(card);
      });
      if (!(p.spy || []).length) body.push(para('아직 첩보원이 없어요.', true));
      return { title: '첩보', body };
    };
    // ----- 걸작·관광
    SH.gw = () => {
      const p = st.P[me], body = [];
      body.push(grid([[Math.round(p.tour || 0), '관광/턴'], [visTourists(G, me), '찾아온 관광객'], [domTourists(G, me), '국내 관광객']]));
      body.push(para('관광 = 걸작(문학 2 · 미술 3 · 유물 3 · 음악 4 · 성유물 8) + 불가사의 + 해변 휴양지·자연경관(보존) 등. 테마를 맞춘 박물관은 걸작 산출·관광이 2배. 교역로·국경 개방·같은 종교가 그 나라로 가는 관광을 늘리고, 전쟁은 줄여요.', true));
      for (const c of citiesOf(G, me)) {
        const GL = gwLayout(G, c); if (!GL.slots.length) continue;
        body.push(lab(c.n));
        for (const sl of GL.slots) {
          const w = sl.w >= 0 ? c.gw[sl.w] : null, bn = sl.b.startsWith('w:') ? WON[WONI[sl.b.slice(2)]].n : (BLD[BLDI[sl.b]] || {}).n;
          body.push(row({ ic: w ? GW_I[w.c] : '▢', t: w ? (w.n >= 0 ? GPL[w.n].n + '의 ' + GW_N[w.c] : GW_N[w.c] + (w.c === 'arti' ? ' (' + ERA[w.e] + ' · ' + (w.o >= 0 && st.P[w.o] && st.P[w.o].k === 'maj' ? CIVS[st.P[w.o].civ].n : '옛 문명') + ')' : '')) : '빈 ' + (sl.t === 'any' ? '걸작' : GW_N[sl.t]) + ' 칸', s: bn + (GL.themed[sl.b] ? ' · ✨ 테마 완성(2배)' : ''), r: w ? '+' + GW_T[w.c] * (GL.themed[sl.b] ? 2 : 1) : '' }));
        }
      }
      if (!citiesOf(G, me).some((c) => gwLayout(G, c).slots.length)) body.push(para('걸작 칸이 있는 건물(궁전·원형 극장·미술관·고고학 박물관·방송 센터·신전)이 없어요.', true));
      return { title: '걸작·관광', body };
    };
    // ----- 도시 화면
    const DICO = (k) => (DIS[DISI[k]] && DIS[DISI[k]].ico) || '◆';
    SH.city = (sh) => {
      const c = G.cid[sh.arg];
      if (!c) return { title: '도시', body: [para('도시가 없어요.')] };
      const mine = c.o === me, cc = cityCalc(G, c), body = [];
      const y = cc.y;
      const growT = cc.grow > 0 ? Math.max(1, Math.ceil((cc.need - (c.fd || 0)) / cc.grow)) : cc.grow < 0 ? '굶주림' : '정체';
      const bal = cc.amen - cc.amenNeed;
      body.push(grid([[c.pop, '인구 · ' + growT + (typeof growT === 'number' ? '턴' : '')], [(cc.surplus >= 0 ? '+' : '') + Math.round(cc.surplus * 10) / 10, '🌾 남는 식량'], [Math.round(y[1] * 10) / 10, '⚒ 생산'], [Math.round(y[2]), '💰 금'], [Math.round(y[3]), '🔬 과학'], [Math.round(y[4]), '🎭 문화'], [Math.round(y[5]), '🙏 신앙'],
        [c.pop + '/' + cc.hous, '🏠 주거'], [(bal >= 0 ? '+' : '') + bal, '😊 ' + MOODN[cc.mood]], [Math.round(c.lo) + (c.lod != null ? (c.lod >= 0 ? ' ▲' : ' ▼') : ''), '충성도'], [c.rl >= 0 && st.R[c.rl] ? RELN[st.R[c.rl].i] : '없음', '종교']]));
      if (!mine) {
        body.push(para(civName(G, c.o) + '의 도시 · 방어 ' + cityCS(G, c) + ' · 체력 ' + c.hp + '/200' + (c.wl ? ' · 성벽 ' + c.wh + '/' + c.wl * 100 : ''), true));
        return { title: c.n, body };
      }
      const tabs = ['생산', '시민', '건물', '정보'];
      // 지금 만드는 것
      const it0 = c.q[0];
      if (it0) {
        const cost = itemCost(G, c, it0), pr = c.pp[itemKey(it0)] || 0, rate = y[1] * itemMul(G, c, it0);
        const card = h('div', { class: 'c6-card' }, h('div', { class: 'hd' }, h('span', { class: 'tx' }, h('b', { text: '🔨 ' + itemName(G, me, it0) }), h('small', { text: Math.floor(pr) + '/' + cost + ' · ' + turnsTo(cost - pr, rate) + '턴' }))), bar(pr / cost, '#e09a4a'));
        if (c.q.length > 1) card.append(h('div', { class: 'c6-pills' }, ...c.q.map((q, k) => h('button', { text: (k ? k + '. ' : '▶ ') + itemName(G, me, q) + ' ✕', onclick: () => act({ t: 'qrm', c: c.id, i: k }) }))));
        body.push(card);
      } else body.push(para('⚠ 만들 것이 없어요(남는 생산의 25%가 금이 돼요). 아래에서 고르세요.'));
      if (sh.tab === 0) {
        const p = st.P[me];
        const locked = [];
        const addRow = (it, ic, label, sub) => {
          const why = [], ok = canBuild(G, c, it, why);
          if (!ok && !sh.showLocked && !(why[0] && why[0].indexOf('부족') >= 0) && !(it.t === 'u' && UT[UTI[it.k]] && UT[UTI[it.k]].res && why[0] && why[0].indexOf(RES[RESI[UT[UTI[it.k]].res]].n) === 0) && why[0] !== '인구가 더 필요해요(구역 한도)') { if (['다른 문명 전용', '고유 건물로 바뀌었어요', '고유 유닛으로 바뀌었어요', '이미 있어요', '더 좋은 유닛이 있어요', '이미 지어졌어요', '이미 했어요', '?', '위인은 만들 수 없어요', '신앙으로 사요', '연구 필요'].indexOf(why[0]) < 0) locked.push(label); return; }
          if (!ok && ['다른 문명 전용', '고유 건물로 바뀌었어요', '고유 유닛으로 바뀌었어요', '이미 있어요', '더 좋은 유닛이 있어요', '이미 지어졌어요', '이미 했어요', '?', '위인은 만들 수 없어요', '신앙으로 사요'].indexOf(why[0]) >= 0) return;
          if (!ok && why[0] === '연구 필요') return;
          const cost = itemCost(G, c, it), rate = y[1] * itemMul(G, c, it), pr = c.pp[itemKey(it)] || 0;
          const btns = [];
          if (ok && canI()) {
            if (it.t === 'u' || it.t === 'b') {
              const bg = buyCost(G, c, it, 'g'), w = []; const okG = canBuy(G, c, it, 'g', w);
              btns.push({ t: '💰' + bg, dis: okG ? null : w[0], fn: () => act({ t: 'buy', c: c.id, it, cur: 'g' }) });
              const w2 = []; if (canBuy(G, c, it, 'f', w2) || (w2[0] === '신앙 부족')) btns.push({ t: '🙏' + buyCost(G, c, it, 'f'), dis: w2[0] === '신앙 부족' ? w2[0] : null, fn: () => act({ t: 'buy', c: c.id, it, cur: 'f' }) });
            }
            if (it.t === 'u' || it.t === 'b' || it.t === 'p') btns.push({ t: '＋', dis: c.q.length >= 6 ? '대기열이 꽉 찼어요' : null, fn: () => act({ t: 'prod', c: c.id, it, mode: 'add' }) });
          }
          body.push(row({ ic, t: label, s: ok ? sub : '🔒 ' + why[0] + (sub ? ' · ' + sub : ''), r: cost, r2: turnsTo(cost - pr, rate) + '턴', off: !ok, btns,
            fn: ok && canI() ? () => {
              if (it.t === 'd' || it.t === 'w') {
                const sites = it.t === 'd' ? distSites(G, c, it.k) : wonSites(G, c, WON[WONI[it.k]]);
                mode = { k: 'place', it, c: c.id, sites, sel: null }; closeSheet(true); renderBot(); dirtyF = true;
                if (sites.length) { const best = it.t === 'd' ? sites.slice().sort((a, b) => adjBonus(G, me, b, it.k) - adjBonus(G, me, a, it.k))[0] : sites[0]; mode.sel = best; renderBot(); }
              } else act({ t: 'prod', c: c.id, it, mode: 'set' });
            } : null }));
        };
        body.push(lab('구역 (' + distCount(c) + '/' + distLimit(G, c) + ')'));
        for (const D of DIS) if (D && D.k !== 'cc') addRow({ t: 'd', k: D.k }, DICO(D.k), distName(G, me, D.k), (UDIS[civK(G, me)] && UDIS[civK(G, me)][D.k] ? UDIS[civK(G, me)][D.k].d : D.d));
        body.push(lab('건물'));
        for (const b of BLD) if (b.k !== 'palace') addRow({ t: 'b', k: b.k }, '🏠', b.n, b.d2 + (b.pw ? ' ⚡전력' : ''));
        addRow({ t: 'b', k: 'worship' }, '⛪', c.rl >= 0 && st.R[c.rl] ? (WORSHIP[(st.R[c.rl].bl.map((b) => BELIEF[b]).find((b) => b.t === 'W') || { fx: { wb: 0 } }).fx.wb] || WORSHIP[0]).n : '예배 건물', '종교의 예배 신앙');
        body.push(lab('불가사의'));
        for (const W of WON) if (st.WB[W.k] == null && hasReq(G, me, W.req)) addRow({ t: 'w', k: W.k }, '🏛', W.n, W.d);
        body.push(lab('유닛'));
        for (const T of UT) if (T.cl !== 'gp') addRow({ t: 'u', k: T.k }, T.cl === 'civ' ? '👷' : T.cl === 'rel' ? '✝' : '⚔', T.n, (T.cs ? '⚔' + T.cs : '') + (T.rs ? ' 🏹' + T.rs + '(' + T.rng + ')' : '') + ' 이동 ' + T.mv + (T.res ? ' · ' + RES[RESI[T.res]].n + ' ' + stratNeed(G, me, T) : '') + (T.d ? ' · ' + T.d : ''));
        // 종교 유닛(신앙)
        for (const k of ['missionary', 'apostle', 'inquisitor']) {
          const it = { t: 'u', k }, w = []; const ok = canBuy(G, c, it, 'f', w);
          if (!ok && (w[0] === '종교 필요' || w[0] === '?')) continue;
          body.push(row({ ic: '✝', t: UT[UTI[k]].n + ' (신앙)', s: UT[UTI[k]].d + (ok ? '' : ' · 🔒 ' + w[0]), off: !ok, r: '🙏' + buyCost(G, c, it, 'f'), fn: ok && canI() ? () => act({ t: 'buy', c: c.id, it, cur: 'f' }) : null }));
        }
        body.push(lab('프로젝트'));
        for (const P2 of PRJ) addRow({ t: 'p', k: P2.k }, '🚀', P2.n, P2.d2);
        if (locked.length || sh.showLocked) body.push(bbtn(sh.showLocked ? '조건이 안 되는 항목 숨기기' : '조건이 안 되는 항목 보기 (' + locked.length + ')', () => { sh.showLocked = !sh.showLocked; renderSheet(); }, { ghost: 1 }));
      } else if (sh.tab === 1) {
        body.push(lab('시민 배치 방식'));
        body.push(h('div', { class: 'c6-pills' }, ...FOCN.map((n, k) => h('button', { class: (c.fo || 0) === k ? 'on' : '', text: n, onclick: () => act({ t: 'focus', c: c.id, f: k }) }))));
        body.push(para('지도의 노란 점이 일하는 칸이에요. 내 영토 칸을 누르면 그 칸을 고정/해제해요(진한 점 = 고정).', true));
        const spc = c.spc || {}; const sp = Object.keys(spc).filter((k) => spc[k]);
        if (sp.length) body.push(para('전문가: ' + sp.map((k) => distName(G, me, k) + ' ' + spc[k] + '명(' + yStr(SPEC[k]) + ')').join(', ')));
        body.push(bbtn(mode && mode.k === 'buy' ? '💰 타일 구매 끄기' : '💰 타일 구매(지도에 가격 표시)', () => { mode = mode && mode.k === 'buy' ? null : { k: 'buy' }; renderSheet(); dirtyF = true; }, { p: !(mode && mode.k === 'buy') }));
        body.push(lab('일하는 칸'));
        for (const j of (c.wk || [])) { const yy = tileYield(G, j, me); body.push(row({ ic: (c.lk || []).indexOf(j) >= 0 ? '📌' : '·', t: tileTitle(j).split('  ')[0], s: yStr(yy), fn: canI() ? () => act({ t: 'tile', c: c.id, p: j }) : null })); }
      } else if (sh.tab === 2) {
        body.push(lab('구역'));
        for (const dk in c.d) {
          if (dk === 'cc') continue;
          const D = DIS[DISI[dk]], ti = c.d[dk];
          body.push(row({ ic: DICO(dk), icBg: D.col, t: distName(G, me, dk) + (G.dpil[ti] ? ' (약탈됨)' : ''), s: D.y >= 0 ? '인접 보너스 ' + YI[D.y] + '+' + adjBonus(G, me, ti, dk) : D.d, fn: () => { closeSheet(); centerOn(ti, true); sel = { k: 't', p: ti }; renderBot(); } }));
        }
        if (Object.keys(c.d).length <= 1) body.push(para('아직 구역이 없어요. 인구 1·4·7…마다 구역을 하나 더 지을 수 있어요.', true));
        body.push(lab('건물·불가사의'));
        for (const k of c.b) { if (k.startsWith('w:')) { const W = WON[WONI[k.slice(2)]]; body.push(row({ ic: '🏛', t: W.n, s: W.d })); continue; } const b = BLD[BLDI[k]]; if (b) body.push(row({ ic: '🏠', t: b.n + (b.pw ? (c.pw ? ' ⚡' : ' (전력 없음)') : ''), s: b.d2 })); else if (k === 'worship' && c.wb >= 0) body.push(row({ ic: '⛪', t: WORSHIP[c.wb].n, s: WORSHIP[c.wb].d })); }
        if ((c.gw || []).length) { body.push(lab('걸작')); const GL = gwLayout(G, c); for (const sl of GL.slots) if (sl.w >= 0) { const gw = c.gw[sl.w]; body.push(row({ ic: GW_I[gw.c], t: (gw.n >= 0 ? GPL[gw.n].n + '의 ' : '') + GW_N[gw.c], s: yStr(yAdd(Y0(), GW_Y[gw.c], GL.themed[sl.b] ? 2 : 1)) + ' · 관광 +' + GW_T[gw.c] * (GL.themed[sl.b] ? 2 : 1) + (GL.themed[sl.b] ? ' · 테마 2배' : '') })); } }
        body.push(para('빈 걸작 칸: 문학 ' + gwSlots(G, c, 'wri') + ' · 미술 ' + gwSlots(G, c, 'art') + ' · 음악 ' + gwSlots(G, c, 'mus') + ' · 유물 ' + gwSlots(G, c, 'arti') + ' · 성유물 ' + gwSlots(G, c, 'rel'), true));
      } else {
        body.push(lab('산출 내역'));
        for (const k in cc.parts) body.push(row({ ic: '·', t: k, s: yStr(cc.parts[k].map((v) => Math.round(v * 10) / 10)) }));
        body.push(lab('성장'));
        body.push(para('식량 ' + Math.floor(c.fd || 0) + '/' + cc.need + ' · 인구가 먹는 식량 ' + cc.eat + ' · 주거가 인구보다 2 이상 많아야 제 속도로 자라요. 쾌적도: ' + cc.amen + ' / 필요 ' + cc.amenNeed + ' (' + MOODN[cc.mood] + ')', true));
        body.push(lab('충성도'));
        body.push(para(Math.round(c.lo) + '/100 (턴마다 ' + (c.lod >= 0 ? '+' : '') + (c.lod || 0) + '). 0이 되면 주변에서 가장 영향력이 큰 나라로 넘어가요. 총독·기념비·수비대·황금기가 올려 줘요.', true));
        if (c.rp && Object.keys(c.rp).length) { body.push(lab('종교 신자')); for (const r in c.rp) if (st.R[r]) body.push(row({ ic: '⛪', icBg: RELC[st.R[r].i], t: RELN[st.R[r].i], r: followers(G, c, +r) + '명' })); }
        const gvn = c.gv >= 0 ? GOVR[c.gv] : null; body.push(lab('총독')); body.push(para(gvn ? gvn.n + ' (' + gvn.t + ') · ' + gvn.d : '없음 — 총독 화면에서 배치해요.', true));
        if (c.lk && c.lk.length) body.push(para('고정한 칸 ' + c.lk.length + '개', true));
        body.push(lab('방어')); body.push(para('방어력 ' + cityCS(G, c) + ' · 체력 ' + c.hp + '/200' + (c.wl ? ' · 성벽 ' + c.wh + '/' + c.wl * 100 + ' (원거리 공격 가능)' : ' · 성벽 없음'), true));
        const tgs = cityStrikeTargets(G, c);
        if (tgs.length && canI()) body.push(bbtn('🏹 도시 원거리 공격', () => { act({ t: 'cstr', c: c.id, to: tgs[0] }); }, { p: 1 }));
        const pN = st.P[me].nk || {};
        if ((pN.a || 0) + (pN.t || 0) > 0 && canI()) {
          body.push(lab('☢ 핵무기 (원자폭탄 ' + (pN.a || 0) + ' · 열핵 ' + (pN.t || 0) + ')'));
          const ns = nukeTargetsFrom(G, me, c);
          for (const kk of ['a', 't']) if (pN[kk] > 0) body.push(bbtn('☢ ' + (kk === 'a' ? '원자폭탄' : '열핵 폭탄') + ' 발사(' + NUKE_R + '칸 안)', () => { mode = { k: 'nuke', kk, c: c.id, sites: ns, sel: null }; closeSheet(true); renderBot(); dirtyF = true; }, { dis: ns.length ? null : '전쟁 중인 나라의 목표가 없어요' }));
        }
      }
      return { title: c.n + (c.b.indexOf('palace') >= 0 ? ' ★' : ''), tabs, body };
    };

    /* ---------- 작은 창(승급·종교 창시) ---------- */
    function closeModal() { if (modal) { modal.remove(); modal = null; } }
    function showModal(title, nodes, foot) {
      closeModal();
      const box = h('div', null, h('div', { class: 'c6-sh-h' }, h('h3', { text: title }), h('button', { class: 'btn ghost', text: '닫기', 'data-key': 'Escape', onclick: closeModal })), h('div', { class: 'c6-sh-b' }, ...nodes));
      if (foot) box.append(h('div', { style: { padding: '8px 10px 12px', display: 'flex', gap: '6px' } }, ...foot));
      modal = h('div', { class: 'c6-modal', onclick: (e) => { if (e.target === modal) closeModal(); } }, box);
      wrap.append(modal);
    }
    function openPromo(u) {
      const L2 = PROMO[UT[u.t].cl]; if (!L2) return;
      showModal('승급 — ' + UT[u.t].n, promoOptions(u).map((k) => row({ ic: '⭐', t: L2[k][0], s: L2[k][3] + ' · 체력 +50, 이번 턴 행동 끝', fn: () => { act({ t: 'prom', u: u.id, k }); closeModal(); } })));
    }
    function openRelModal(u) {
      const t = belTaken(G), used = {}; for (const r of st.R) used[r.i] = 1;
      const d = { n: RELN.findIndex((x, i) => !used[i]), f: -1, o: -1 };
      const render = () => {
        const nodes = [lab('종교 이름'), h('div', { class: 'c6-pills' }, ...RELN.map((n, i) => used[i] ? null : h('button', { class: d.n === i ? 'on' : '', text: n, onclick: () => { d.n = i; render(); } })).filter(Boolean)),
          lab('추종자 신앙(믿는 도시에)'), ...BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === 'F' && !t[i]).map((i) => row({ ic: '◇', t: BELIEF[i].n, s: BELIEF[i].d, on: d.f === i, fn: () => { d.f = i; render(); } })),
          lab('창시자 신앙(나에게)'), ...BELIEF.map((b, i) => i).filter((i) => BELIEF[i].t === 'O' && !t[i]).map((i) => row({ ic: '◆', t: BELIEF[i].n, s: BELIEF[i].d, on: d.o === i, fn: () => { d.o = i; render(); } }))];
        showModal('종교 창시', nodes, [bbtn('⛪ 창시하기', () => { act({ t: 'gpu', u: u.id, rel: { n: d.n, f: d.f, o: d.o } }); closeModal(); }, { p: 1, dis: d.n < 0 || d.f < 0 || d.o < 0 ? '이름과 신앙 두 개를 골라요' : null })]);
      };
      render();
    }

    /* ---------- 상태 반영 ---------- */
    function computeView() {
      const humans = api.mySeats();
      me = api.viewer();
      if (me < 0 && humans.length === 0) me = -1;
      seeAll = humans.length === 0 || st.ph === 'e' || (me >= 0 && !st.P[me].a);
      hideAll = !seeAll && me < 0;
      if (me < 0 && seeAll) me = st.cur;
      vis = me >= 0 && !seeAll ? visOf(G, me) : null;
      ex = me >= 0 ? G.ex[me] : null;
      if (seeAll) { vis = null; }
    }
    let trKey = '', trCache = [];
    function trLines() {
      if (!G || me < 0) return [];
      const list = []; for (const pp of st.P) if (pp.k === 'maj' && (pp.o === me || seeAll)) for (const tr of pp.tr) list.push(tr.f + '>' + tr.d);
      const key = list.join(',');
      if (key !== trKey) { trKey = key; trCache = []; for (const k of list) { const [f, d] = k.split('>').map(Number); const F = G.cid[f], D = G.cid[d]; if (F && D) { const pth = routePath(G, F, D); if (pth) trCache.push(pth); } } }
      return trCache.filter((pth) => isEx(pth[0]) || isEx(pth[pth.length - 1]));
    }
    /* ---------- 문명 고르기 화면 ---------- */
    const VICI = { dom: '⚔', sci: '🚀', cul: '🎭', rel: '⛪', dip: '🕊', score: '🏆' };
    function civUniques(c) {
      const out = [];
      for (const T of UT) if (T.civ === c.c) out.push(['유닛', T.n + ' (' + UT[UTI[T.rep]].n + ' 대신)', T.d || '']);
      const ud = UDIS[c.c] || {}; for (const dk in ud) out.push(['구역', ud[dk].n, ud[dk].d]);
      for (const b of BLD) if (b.civ === c.c) out.push(['건물', b.n, b.d2]);
      for (const m of IMP) if (m && m.civ === c.c) out.push(['개선', m.n, m.d]);
      return out;
    }
    function civEm(c) { const hh = (strHash(c.c) >>> 0) % 360; return 'hsl(' + hh + ',55%,62%)'; }
    function renderPick() {
      const mine = api.mySeats().filter((o) => !st.pl[o].ai);
      if (mine.indexOf(pk.seat) < 0) pk.seat = mine.find((o) => st.pk[o] < 0); if (pk.seat == null || pk.seat < 0) pk.seat = mine.length ? mine[0] : -1;
      const seat = pk.seat;
      if (!pickEl) { pickEl = h('div', { class: 'c6-pk' }); wrap.appendChild(pickEl); }
      const oldL = pickEl.querySelector('.c6-pk-l'); if (oldL) pk.sc = oldL.scrollTop;
      const hadFocus = document.activeElement && document.activeElement.classList && document.activeElement.classList.contains('c6-pk-q');
      pickEl.innerHTML = '';
      const nPick = st.pk.filter((x) => x >= 0).length;
      const seats = h('div', { class: 'c6-pk-seats' });
      for (let o = 0; o < st.nM; o++) {
        const pl = api.players[o] || {}, k = st.pk[o], myS = mine.indexOf(o) >= 0;
        seats.append(h('button', { class: 'c6-pk-seat' + (o === seat ? ' me' : ''), onclick: () => { if (myS) { pk.seat = o; pk.open = st.pk[o]; renderPick(); } } },
          h('i', { style: { background: pl.color || '#ccc' } }), h('span', null, (pl.name || ('자리 ' + (o + 1))) + (st.pl[o].ai ? ' 🤖' : ''), h('small', { text: k >= 0 ? CIVS[k].ld + ' (' + CIVS[k].n + ')' : st.pl[o].ai ? '사람이 고른 뒤 남은 문명' : '고르는 중…' }))));
      }
      const q = h('input', { class: 'c6-pk-q', type: 'search', placeholder: '문명·지도자·능력 검색', value: pk.q, oninput: (e) => { pk.q = e.target.value; pk.sc = 0; renderList(); } });
      const tools = h('div', { class: 'c6-pk-tools' }, q, h('button', { class: 'btn', text: '🎲 무작위', onclick: () => { if (seat >= 0) { api.sfx('click'); api.actAs(seat, { t: 'pick', k: 'r' }); } } }));
      const fl = h('div', { class: 'c6-pk-f' }, ...[['', '전체'], ['dom', '⚔ 지배'], ['sci', '🚀 과학'], ['cul', '🎭 문화'], ['rel', '⛪ 종교'], ['dip', '🕊 외교']].map(([k, t]) => h('button', { class: pk.f === k ? 'on' : '', text: t, onclick: () => { pk.f = k; pk.sc = 0; renderPick(); } })));
      pickEl.append(h('div', { class: 'c6-pk-h' }, h('h2', { text: '문명 고르기' }),
        h('div', { class: 'sub', text: '모든 사람이 문명을 고르면 판이 시작돼요(' + nPick + '/' + st.nM + ' 고름' + (st.nd ? ' · 같은 문명은 한 자리만' : '') + '). 카드를 누르면 능력을 볼 수 있어요.' }), seats, tools, fl));
      const list = h('div', { class: 'c6-pk-l' });
      pickEl.append(list);
      function renderList() {
        list.innerHTML = '';
        const qq = pk.q.trim();
        const idx = CIVS.map((c, i) => i).filter((i) => { const c = CIVS[i]; if (pk.f && c.vic.indexOf(pk.f) < 0) return false; if (!qq) return true; return (c.n + c.ld + c.ab + c.abd + c.la + c.lad + c.agn + civUniques(c).map((x) => x[1]).join('')).indexOf(qq) >= 0; });
        if (!idx.length) list.append(h('p', { class: 'c6-p mut', text: '찾는 문명이 없어요.' }));
        for (const i of idx) {
          const c = CIVS[i], selMe = seat >= 0 && st.pk[seat] === i;
          const who = st.pk.map((x, o) => (x >= 0 && o !== seat && CIVS[x].c === c.c ? o : -1)).filter((o) => o >= 0);
          const taken = st.nd && who.length > 0;
          const open = pk.open === i;
          const card = h('div', { class: 'c6-pk-c' + (selMe ? ' sel' : '') + (taken ? ' taken' : ''), role: 'button', tabindex: 0, onclick: () => { pk.open = open ? -1 : i; renderList(); } },
            h('div', { class: 'hd' }, h('span', { class: 'em', style: { background: civEm(c) }, text: c.n[0] }), h('span', { class: 'tx' }, h('b', { text: c.ld + (selMe ? ' ✓' : '') }), h('small', { text: c.n + ' · 「' + c.agn + '」' + (who.length ? ' · ' + who.map((o) => (api.players[o] && api.players[o].name) || ('자리 ' + (o + 1))).join(', ') + ' 고름' : '') })), h('span', { class: 'vic', title: '추천 승리', text: c.vic.map((v) => VICI[v]).join('') })));
          if (open) {
            const dt = h('div', { class: 'dt' });
            dt.append(h('div', null, h('b', { text: '문명 능력 「' + c.ab + '」 ' }), c.abd));
            dt.append(h('div', null, h('b', { text: '지도자 능력 「' + c.la + '」 ' }), c.lad));
            for (const [kind, nm, d] of civUniques(c)) dt.append(h('div', null, h('b', { text: '고유 ' + kind + ' ' }), nm + (d ? ' — ' : ''), h('span', { class: 'u', text: d })));
            dt.append(h('div', null, h('b', { text: '성향 ' }), '「' + c.agn + '」 ' + c.agd));
            dt.append(h('div', null, h('b', { text: '추천 승리 ' }), c.vic.map((v) => VICI[v] + ' ' + WINN[v]).join(' · ')));
            if (seat >= 0) dt.append(h('button', { class: 'btn primary', text: taken ? '다른 사람이 골랐어요' : selMe ? '✓ 골랐어요' : '이 문명으로', onclick: (e) => { e.stopPropagation(); if (taken || selMe) return; api.sfx('click'); api.actAs(seat, { t: 'pick', k: i }); } }));
            card.append(dt);
          }
          list.append(card);
        }
        list.scrollTop = pk.sc;
      }
      renderList();
      const foot = h('div', { class: 'c6-pk-b' });
      const left = st.pk.filter((x) => x < 0).length;
      if (seat >= 0) foot.append(h('button', { class: 'btn' + (st.pk[seat] >= 0 ? '' : ' primary'), text: st.pk[seat] >= 0 ? '✓ ' + CIVS[st.pk[seat]].ld + ' — 다른 사람 기다리는 중' : '문명을 골라 주세요', onclick: () => { if (st.pk[seat] >= 0) { pk.open = st.pk[seat]; renderPick(); } } }));
      else foot.append(h('button', { class: 'btn', text: '다른 사람이 고르는 중…' }));
      pickEl.append(foot);
      // 라운드 44: 누가 남았나 + 방장 「지금 시작」
      if (api.pickBar) {
        if (!pickBar) pickBar = api.pickBar({ picked: (o) => !!(st && st.ph === 'k' && st.pk[o] >= 0) || !!(st && st.ph !== 'k'), onForce: () => { if (st && st.ph === 'k' && api.isHost) api.setState(forceStart(JSON.parse(JSON.stringify(st)))); }, parent: pickEl, style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none', margin: '0 10px 6px' } });
        else { pickEl.append(pickBar.el); pickBar.update(); }
      } else if (api.isHost && left > 0 && mine.length) foot.append(h('button', { class: 'btn ghost', text: '지금 시작 (안 고른 ' + left + '명 무작위)', onclick: () => { api.sfx('click'); if (st.ph === 'k') api.setState(forceStart(JSON.parse(JSON.stringify(st)))); } }));
      if (hadFocus) { const qi = pickEl.querySelector('.c6-pk-q'); if (qi) { qi.focus(); try { qi.setSelectionRange(qi.value.length, qi.value.length); } catch (e) { /* 없음 */ } } }
    }
    let firstCenter = true;
    /* AI 서술(호스트만): 대사는 Haiku, 연대기는 Sonnet. 결과는 상태에 넣어 모두 같은 글을 봐요. 실패하면 자료 문장 그대로. */
    const asked = {};
    const aiOn = () => { try { return !!(L.ai && L.ai.enabled && L.ai.enabled('civ')); } catch (e) { return false; } };
    function patchLine(key, id, t) {
      if (!st || !t) return;
      const arr = st[key] || [], i = arr.findIndex((x) => x.id === id);
      if (i < 0 || arr[i].ai) return;
      const na = arr.slice(); na[i] = Object.assign({}, arr[i], { x: key === 'CH' ? ERA[arr[i].e] + ' 시대 — ' + t : t, ai: 1 });
      const o = {}; o[key] = na;
      api.setState(Object.assign({}, st, o));
    }
    function narrate(state) {
      if (!api.isHost || state.ph !== 'p' || !aiOn()) return;
      for (const d of state.DLG || []) {
        if (d.ai || asked['d' + d.id] || state.t - d.n > 2) continue;
        asked['d' + d.id] = 1;
        let F; try { F = dlgFacts(ctx(JSON.parse(JSON.stringify(state))), d); } catch (e) { continue; }
        const V = F.voice;
        L.ai.ask({ tier: 'fast', system: DLG_SYS, prompt: dlgPrompt(F), maxTokens: 140, timeout: 12000 })
          .then((r) => patchLine('DLG', d.id, cleanLine(r, { len: 90, bad: V.bad, recent: F.recent }))).catch(() => {});
      }
      for (const c of state.CH || []) {
        if (c.ai || asked['c' + c.id] || !c.f || state.t - c.n > 3) continue;
        asked['c' + c.id] = 1;
        L.ai.ask({ tier: 'quality', system: CH_SYS, prompt: chPrompt(c.f), maxTokens: 160, timeout: 20000 })
          .then((r) => patchLine('CH', c.id, cleanLine(r, { max: 1, len: 100, end: /다\.$/ }))).catch(() => {});
      }
    }
    function update(state, prev) {
      st = state;
      if (state.ph === 'k') {
        G = null; wrap.classList.add('pick'); closeSheet(true); renderPick();
        // 라운드 44: 연결이 끊겨 core가 AI로 바꾼 사람 자리 → 호스트가 AI 자리로 처리(사람이 다 골랐으면 AI가 남은 문명 중에서 고르고 시작)
        if (api.isHost && api.online && state.pl.some((pl, o) => !pl.ai && api.players[o] && api.players[o].ai)) setTimeout(() => {
          if (!st || st.ph !== 'k') return;
          const s2 = JSON.parse(JSON.stringify(st)); let ch = false;
          s2.pl.forEach((pl, o) => { if (!pl.ai && api.players[o] && api.players[o].ai) { pl.ai = 1; pl.lv = api.players[o].lv || 2; ch = true; } });
          if (!ch) return;
          if (s2.pl.every((pl, o) => pl.ai || s2.pk[o] >= 0)) api.setState(forceStart(s2)); else api.setState(s2);
        }, 0);
        return;
      }
      if (pickEl) { if (pickBar) { pickBar.destroy(); pickBar = null; } pickEl.remove(); pickEl = null; wrap.classList.remove('pick'); firstCenter = true; prev = null; }
      G = ctx(JSON.parse(JSON.stringify(state)));
      const prevMe = me;
      computeView();
      if (seeAll && api.mySeats().length === 0) { /* 관전: 전부 보기 */ }
      if (firstCenter || (prevMe !== me && me >= 0)) { firstCenter = false; requestAnimationFrame(() => { clampCam(); centerHome(false); if (myTurn() && !citiesOf(G, me).length) { const s0 = G.U.find((u) => u.o === me && UT[u.t].k === 'settler'); if (s0) selectUnit(s0, true); } }); }
      // 선택 정리
      if (sel && sel.k === 'u') { const u = G.uid[sel.id]; if (!u) { sel = null; RR = null; TG = []; pend = null; } else if (u.o === me && myTurn()) { RR = isAir(u.t) ? null : reach(G, u).r; TG = targets(G, u); if (UT[u.t].k === 'apostle') TG = TG.concat(relTargets(u)); if (pend && pend.k === 'atk' && TG.indexOf(pend.to) < 0) pend = null; if (u.mv <= 0 && !promoReady(u) && !TG.length && prev && prev.cur === state.cur && prev.L && state.L.id !== prev.L.id && state.L.e.some((e) => e.u === u.id || e.f === u.p)) { setTimeout(nextUnitSoft, 60); } } else { RR = null; TG = []; } }
      if (mode && mode.k === 'place') { const c = G.cid[mode.c]; if (!c || !myTurn()) mode = null; else mode.sites = mode.it.t === 'd' ? distSites(G, c, mode.it.k) : wonSites(G, c, WON[WONI[mode.it.k]]); }
      // 애니메이션
      if (prev && state.L && state.L.id !== lastL && prev !== state) playEvents(state.L);
      lastL = state.L ? state.L.id : -1;
      // 지도자 대사·연대기: 새 줄 알림 + (호스트) AI로 다듬기
      if (prev && prev !== state) {
        const pd = (prev.DLG || []).reduce((m, d) => Math.max(m, d.id), 0);
        for (const d of state.DLG || []) if (d.id > pd && d.t === me && me >= 0) api.toast('💬 ' + CIVS[state.P[d.f].civ].ld + ': ' + d.x);
        const pc = (prev.CH || []).reduce((m, d) => Math.max(m, d.id), 0);
        for (const c of state.CH || []) if (c.id > pc && me >= 0) api.toast('📜 ' + c.x);
      }
      narrate(state);
      // 외교 결과 알림
      if (state.L && state.L.dr && state.L.o === me && prev && prev.L && prev.L.id !== state.L.id) api.toast(state.L.dr === 'ok' ? '받아들였어요!' : state.L.dr === 'rej' ? '거절당했어요' : '제안을 보냈어요');
      // 새 알림 토스트(내 차례 시작)
      if (prev && myTurn() && prev.cur !== state.cur) { api.sfx('pop'); const p = st.P[me]; const fresh = (p.nt || []).filter((n) => n.t === st.t && /완료|완성|유레카|영감|점령|선포|시대|승리/.test(n.m)).slice(-2); for (const n of fresh) api.toast(n.m); if (L.haptic) L.haptic('alert', 40); }
      renderTop(); renderBot();
      if (sheet) { if (sheet.kind === 'city' && (!G.cid[sheet.arg] || G.cid[sheet.arg].o !== me) && !seeAll) closeSheet(); else renderSheet(); }
      waitEl.hidden = true;
      dirtyF = true;
    }
    cvs.onresize = () => { wrap.classList.toggle('wide', wide()); layoutWide(); clampCam(); dirtyF = true; if (st) renderTop(); };
    wrap.classList.toggle('wide', wide());
    // 키보드·패드
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      if (id === 'next') nextUnit();
      else if (id === 'end') tryEnd();
      else if (id === 'fort') { const u = sel && sel.k === 'u' ? G.uid[sel.id] : null; if (u && myTurn() && u.o === me) { if (UT[u.t].k === 'settler' && canFound(G, u)) act({ t: 'found', u: u.id }); else act({ t: 'fort', u: u.id }); setTimeout(nextUnitSoft, 30); } }
      else if (id === 'skip') { const u = sel && sel.k === 'u' ? G.uid[sel.id] : null; if (u && myTurn() && u.o === me) { act({ t: 'skip', u: u.id }); setTimeout(nextUnitSoft, 30); } }
      else if (id === 'tech') openSheet('tech'); else if (id === 'civics') openSheet('civic'); else if (id === 'policy') openSheet('policy'); else if (id === 'dip') openSheet('dip'); else if (id === 'menu') openSheet('menu'); else if (id === 'cities') openSheet('cities');
      else if (id === 'zin') zoomBy(1.2); else if (id === 'zout') zoomBy(0.83);
      else if (id === 'left' || id === 'right' || id === 'up' || id === 'down') { const d = 90 / cam.z; cam.tx = cam.x + (id === 'left' ? -d : id === 'right' ? d : 0); cam.ty = cam.y + (id === 'up' ? -d : id === 'down' ? d : 0); dirtyF = true; }
    }) : null;
    const onKey = (e) => {
      const t = (e.target && e.target.tagName) || ''; if (/^(INPUT|TEXTAREA|SELECT)$/.test(t)) return;
      if (e.key === 'Escape') { if (view.cancel()) e.preventDefault(); return; }
      if (e.key === 'Enter' && !document.querySelector('.overlay[data-core]')) {
        const u = sel && sel.k === 'u' && G ? G.uid[sel.id] : null;
        if (u && pend && pend.k === 'atk') { e.preventDefault(); doAtk(u, pend.to); }
        else if (u && pend && pend.k === 'go') { e.preventDefault(); act({ t: 'mv', u: u.id, to: pend.to }); pend = null; }
        else if (mode && mode.k === 'place' && mode.sel != null) { e.preventDefault(); const it = Object.assign({}, mode.it, { p: mode.sel }), c = mode.c, add = mode.add; mode = null; act({ t: 'prod', c, it, mode: add ? 'add' : 'set' }); openSheet('city', c); }
      }
    };
    window.addEventListener('keydown', onKey);
    const view = {
      update,
      cancel() {
        if (pickEl) { if (pk.open >= 0) { pk.open = -1; renderPick(); return true; } return false; }
        if (modal) { closeModal(); return true; }
        if (mode && mode.k === 'place') { const c = mode.c; mode = null; openSheet('city', c); return true; }
        if (mode) { mode = null; renderSheet(); dirtyF = true; return true; }
        if (sheet) { closeSheet(); return true; }
        if (pend) { pend = null; renderBot(); dirtyF = true; return true; }
        if (sel) { clearSel(); return true; }
        return false;
      },
      destroy() { if (pickBar) pickBar.destroy(); window.removeEventListener('keydown', onKey); if (widen) de.classList.remove('landscape-game'); cancelAnimationFrame(raf); if (offIn) offIn(); setBusy(false); cvs.destroy(); wrap.remove(); if (curView === view) curView = null; },
    };
    curView = view;
    if (L.debug) L.debug.civ = { scr: (i) => { const w = centerOf(i); const p = toScreen(w.x, w.y); const r = mapEl.getBoundingClientRect(); return { x: p.x + r.left, y: p.y + r.top }; }, center: (i) => centerOn(i, false) };
    return view;
  }
  let curView = null;

  /* ======================= 도감(데이터에서 자동) ======================= */
  const reqName = (r) => { if (!r) return '처음부터'; if (r === 'religion') return '종교 창시'; if (r === 'worship') return '종교 강화(예배)'; if (r.startsWith('c:')) { const c = CIVIC[CIVICI[r.slice(2)]]; return c ? '제도 「' + c.n + '」' : r; } const t = TECH[TECHI[r]]; return t ? '기술 「' + t.n + '」' : r; };
  function codexData() {
    const VN = { dom: '지배', sci: '과학', cul: '문화', rel: '종교', dip: '외교', score: '점수' };
    const cv = CIVS.map((c) => {
      const uu = UT.filter((u) => u.civ === c.c), ub = BLD.filter((b) => b.civ === c.c), ui = IMP.filter((m) => m && m.civ === c.c), ud = UDIS[c.c] ? Object.keys(UDIS[c.c]).map((k) => UDIS[c.c][k]) : [];
      return { icon: '🏳', name: c.n + ' — ' + c.ld, tag: '추천 승리: ' + c.vic.map((v) => VN[v]).join('·'), desc: '「' + c.ab + '」 ' + c.abd + ' 「' + c.la + '」 ' + c.lad + ' · 고유: ' + uu.map((u) => u.n + '(' + UT[UTI[u.rep]].n + ' 대신)').concat(ub.map((b) => b.n), ui.map((m) => m.n), ud.map((d) => d.n)).join(', ') + ' · 성향 「' + c.agn + '」: ' + c.agd + ' · 도시: ' + c.cities.slice(0, 4).join(', ') + '…' };
    });
    const units = UT.filter((T) => T.cl !== 'gp').map((T) => ({ icon: T.cl === 'civ' ? '👷' : T.cl === 'rel' ? '✝' : isNaval(UTI[T.k]) ? '⛵' : '⚔', name: T.n, tag: CLN[T.cl] + (T.civ ? ' · ' + CIVS[CIVI[T.civ]].n + ' 전용' : '') + (T.era != null ? ' · ' + ERA[T.era] : ''),
      desc: [T.cs ? '전투력 ' + T.cs : '', T.rs ? '원거리 ' + T.rs + ' 사거리 ' + T.rng : '', '이동 ' + T.mv, (T.faith ? '신앙 ' : '생산 ') + T.c, reqName(T.req), T.res ? '전략 자원 ' + RES[RESI[T.res]].n : '', T.up ? '→ ' + UT[UTI[T.up]].n : '', T.d || ''].filter(Boolean).join(' · ') }));
    const blds = BLD.filter((b) => b.k !== 'palace').map((b) => ({ icon: '🏠', name: b.n, tag: (b.d === 'cc' ? '도심' : DIS[DISI[b.d]].n) + (b.civ ? ' · ' + CIVS[CIVI[b.civ]].n + ' 전용' : ''), desc: b.d2 + ' · 생산 ' + b.c + ' · ' + reqName(b.req) + (b.pre ? ' · 선행 ' + BLD[BLDI[b.pre]].n : '') + (b.pw ? ' · 전력 필요' : '') }));
    blds.push(...WORSHIP.map((w) => ({ icon: '⛪', name: w.n, tag: '예배 건물(성지)', desc: w.d + ' · 종교 강화 때 고르는 예배 신앙' })));
    const dists = DIS.filter((d) => d && d.k !== 'cc').map((d) => ({ icon: d.ico, name: d.n, tag: '구역' + (d.lim ? ' · 인구 제한' : ''), desc: d.d + ' · 기본 비용 ' + d.c + (d.fixed ? '' : '(진행할수록 비싸져요)') + ' · ' + reqName(d.req) }));
    for (const ck in UDIS) for (const dk in UDIS[ck]) dists.push({ icon: '◆', name: UDIS[ck][dk].n, tag: CIVS[CIVI[ck]].n + ' 고유 구역', desc: UDIS[ck][dk].d });
    const wons = WON.map((w) => ({ icon: '🏛', name: w.n, tag: ERA[w.e] + ' 불가사의', desc: w.d + ' · 생산 ' + w.c + ' · ' + reqName(w.req) }));
    const nws = NW.map((n) => ({ icon: '⛰', name: n.n, tag: '자연경관', desc: n.d }));
    const techs = TECH.map((t) => ({ icon: '🔬', name: t.n, tag: ERA[t.e] + ' 기술', desc: '비용 ' + ERA_TC[t.e] + '(속도 비례)' + (t.pre.length ? ' · 선행: ' + t.pre.map((k) => TECH[TECHI[k]].n).join(', ') : '') + (t.b ? ' · 유레카: ' + t.bt : '') }));
    const civs = CIVIC.map((t) => ({ icon: '🎭', name: t.n, tag: ERA[t.e] + ' 사회 제도', desc: '비용 ' + ERA_CC[t.e] + (t.pre.length ? ' · 선행: ' + t.pre.map((k) => CIVIC[CIVICI[k]].n).join(', ') : '') + (t.b ? ' · 영감: ' + t.bt : '') + (TITLE_CIVICS.indexOf(t.k) >= 0 ? ' · 총독 칭호' : '') + (ENVOY_CIVICS.indexOf(t.k) >= 0 ? ' · 사절' : '') }));
    const govs = GOV.map((g) => ({ icon: '🏛', name: g.n, tag: '정부 · 슬롯 ' + g.sl.map((n, k) => SLOTN[k] + ' ' + n).join(' '), desc: g.d + (g.lg ? ' · 유산(쌓이면 바꿔도 남음): ' + g.lgd + ' ×최대 5' : '') + (g.req ? ' · 제도 「' + CIVIC[CIVICI[g.req]].n + '」' : '') }));
    const pols = POL.map((p) => ({ icon: p.t === 'W' ? '★' : SLOTN[SLOTT.indexOf(p.t)][0], name: p.n, tag: SLOTN[SLOTT.indexOf(p.t)] + ' 정책', desc: p.d + ' · 제도 「' + CIVIC[CIVICI[p.req]].n + '」' + (p.ob ? ' · 「' + POL[POLI[p.ob]].n + '」이 나오면 사라짐' : '') }));
    const bels = PANTH.map((b) => ({ icon: '☀', name: b.n, tag: '만신전', desc: b.d })).concat(BELIEF.map((b) => ({ icon: '⛪', name: b.n, tag: { F: '추종자 신앙', O: '창시자 신앙', W: '예배 신앙', E: '강화 신앙' }[b.t], desc: b.d })));
    const gps = GPL.map((g) => ({ icon: GPC[g.c].ic, name: g.n, tag: GPC[g.c].n + ' · ' + ERA[g.e], desc: g.d }));
    const css = CSL.map((c) => ({ icon: '🏰', name: c.n, tag: CST[c.t][0] + ' 도시국가', desc: '종주국 보너스: ' + c.d + ' · 사절 1/3/6명: ' + YN[CST[c.t][1]] + ' +2(수도/구역 도시/더)' }));
    const govr = GOVR.map((g) => ({ icon: '👤', name: g.n, tag: '총독 · ' + g.t, desc: g.d + ' · 진급: ' + g.pr.map((x) => x[0] + '(' + x[2] + ')').join(', ') }));
    const land = TER.map((t) => ({ icon: '⬢', name: t.n, tag: '지형', desc: yStr(t.y) + (t.imp ? ' · 지나갈 수 없음' : '') + (t.water ? ' · 물' : '') }))
      .concat(FEAT.filter(Boolean).map((f) => ({ icon: '🌲', name: f.n, tag: '지형 특성', desc: f.d })))
      .concat(RES.filter(Boolean).map((r) => ({ icon: r.c === 'l' ? '💎' : r.c === 's' ? '⛏' : '🌾', name: r.n, tag: { b: '보너스', l: '사치', s: '전략' }[r.c] + ' 자원', desc: yStr(r.y) + ' · 개선 ' + IMP[IMPI[r.im]].n + (r.rv ? ' · 보이려면 「' + TECH[TECHI[r.rv]].n + '」' : '') })))
      .concat(IMP.filter((m) => m && m.sp).map((m) => ({ icon: '🛖', name: m.n, tag: '지도 표시', desc: m.d })))
      .concat(IMP.filter((m) => m && !m.sp).map((m) => ({ icon: '⛏', name: m.n, tag: '개선' + (m.civ ? ' · ' + CIVS[CIVI[m.civ]].n + ' 전용' : ''), desc: m.d + (m.tech ? ' · ' + (m.civic ? '제도 「' + CIVIC[CIVICI[m.tech]].n + '」' : '기술 「' + TECH[TECHI[m.tech]].n + '」') : '') })));
    const spies = Object.keys(SPYM).map((k) => ({ icon: '🕵', name: SPYM[k].n, tag: '첩보 임무' + (SPYM[k].t ? ' · ' + SPYM[k].t + '턴' : ' · 계속'), desc: SPYM[k].d + ' 기본 성공률 ' + Math.round(SPYM[k].b * 100) + '%' + (SPYM[k].need ? ' · ' + DIS[DISI[SPYM[k].need]].n + ' 필요' : '') }));
    const gws = Object.keys(GW_N).map((k) => ({ icon: GW_I[k], name: GW_N[k], tag: '걸작', desc: yStr(GW_Y[k]) + ' · 관광 +' + GW_T[k] }));
    const misc = DEDI.map((d) => ({ icon: '✦', name: d.n, tag: '시대 헌신', desc: d.d })).concat(RESO.map((r) => ({ icon: '🌐', name: r.n, tag: '세계 의회 결의안', desc: 'A: ' + r.a + ' / B: ' + r.b })), PRJ.map((p2) => ({ icon: '🚀', name: p2.n, tag: '프로젝트', desc: p2.d2 + ' · 생산 ' + p2.c })));
    return [
      { h: '문명', p: ['판을 시작하기 전 「문명 고르기」 화면에서 문명·지도자를 골라요(무작위도 돼요). 문명마다 고유 능력·지도자 능력·유닛·건물/구역/개선이 있어요. ' + CIVS.length + '명.'], rows: cv },
      { h: '유닛', rows: units }, { h: '구역', rows: dists }, { h: '건물', rows: blds }, { h: '불가사의', rows: wons.concat(nws) },
      { h: '기술', rows: techs }, { h: '사회 제도', rows: civs }, { h: '정부', rows: govs }, { h: '정책', rows: pols },
      { h: '종교', rows: bels }, { h: '위인', rows: gps }, { h: '걸작', rows: gws }, { h: '첩보', rows: spies }, { h: '도시국가', rows: css }, { h: '총독', rows: govr }, { h: '지형·자원', rows: land }, { h: '기타', rows: misc },
    ];
  }

  /* ======================= 상황 도움말 ======================= */
  function hint(s, seat) {
    if (s.ph === 'k') return ['문명 고르기', '카드를 눌러 문명·지도자 능력과 고유 유닛·건물을 보고 「이 문명으로」를 눌러요.', '🎲 무작위로 골라도 돼요. 위쪽 칩으로 추천 승리(지배·과학·문화·종교·외교)별로 찾을 수 있어요.', '모든 사람이 고르면 판이 시작돼요. 방장은 「지금 시작」으로 안 고른 사람을 무작위로 정할 수 있어요.'];
    if (seat == null || seat < 0 || !s.P[seat] || s.P[seat].k !== 'maj') return null;
    const G = ctx(JSON.parse(JSON.stringify(s))), p = G.P[seat], out = [];
    out.push(CIVS[p.civ].n + ' · ' + s.t + '/' + s.tl + '턴 · ' + ERA[s.era] + ' 시대 (' + AGEN[p.age] + ')');
    out.push('🔬 ' + (p.rs >= 0 ? TECH[p.rs].n : '연구를 고르세요') + ' · 🎭 ' + (p.cs >= 0 ? CIVIC[p.cs].n : '사회 제도를 고르세요'));
    const cs = citiesOf(G, seat);
    if (!cs.length) out.push('개척자를 눌러 「도시 세우기」로 수도를 세우세요(강·호숫가가 좋아요).');
    else {
      const idle = cs.filter((c) => !c.q.length); if (idle.length) out.push('생산이 없는 도시: ' + idle.map((c) => c.n).join(', '));
      const tight = cs.filter((c) => { const cc = cityCalc(G, c); return cc.hous - c.pop <= 1; }); if (tight.length) out.push('주거가 부족한 도시(송수로·곡물 창고·농장): ' + tight.map((c) => c.n).join(', '));
      const sad = cs.filter((c) => { const cc = cityCalc(G, c); return cc.amen < cc.amenNeed; }); if (sad.length) out.push('쾌적도가 낮은 도시(사치 자원·오락 단지): ' + sad.map((c) => c.n).join(', '));
    }
    const wars = aliveMaj(G).filter((q) => q !== seat && atWar(G, seat, q)); if (wars.length) out.push('⚔ 전쟁 중: ' + wars.map((q) => civName(G, q)).join(', ') + ' — 공성 유닛과 측면 공격(+2/유닛)을 활용해요.');
    if (p.pan < 0 && p.faith >= panCost(G)) out.push('🙏 신앙이 모였어요: 종교 화면에서 만신전을 세우세요.');
    if (p.env > 0) out.push('✉ 남은 사절 ' + p.env + ' — 도시국가 화면에서 보내세요.');
    if (p.gt > 0) out.push('👤 총독 칭호 ' + p.gt + ' — 총독 화면에서 임명·진급.');
    return out.slice(0, 6);
  }

  /* ======================= 미리보기 ======================= */
  function preview(cv) {
    const c = cv.getContext('2d'), w = cv.width, hh = cv.height;
    c.fillStyle = '#0d1a26'; c.fillRect(0, 0, w, hh);
    const R2 = 34, HW2 = Math.sqrt(3) * R2, cols = ['#6f9a3e', '#a9a04e', '#3a82ad', '#6f9a3e', '#857d8c', '#d6bf83', '#3a82ad', '#a9a04e'];
    let k = 0;
    for (let r = -1; r < 7; r++) for (let q = -1; q < 11; q++) {
      const x = HW2 * (q + 0.5 * (r & 1)), y = 1.5 * R2 * r, col2 = cols[(k++ * 7 + r * 3) % cols.length];
      c.beginPath(); for (let a = 0; a < 6; a++) { const an = Math.PI / 180 * (60 * a - 30); const px = x + R2 * Math.cos(an), py = y + R2 * Math.sin(an); a ? c.lineTo(px, py) : c.moveTo(px, py); } c.closePath();
      c.fillStyle = col2; c.fill(); c.strokeStyle = 'rgba(0,0,0,.25)'; c.stroke();
    }
    c.fillStyle = 'rgba(214,170,60,.9)'; c.fillRect(w / 2 - 40, hh / 2 - 18, 80, 40);
    c.fillStyle = '#2a1c10'; c.font = 'bold 22px sans-serif'; c.textAlign = 'center'; c.fillText('문명 개척', w / 2, hh / 2 + 9);
  }

  const ICON = '<path d="M28 4l20 11.5v23L28 50 8 38.5v-23z" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linejoin="round"/><rect x="18" y="27" width="20" height="13" fill="currentColor"/><path d="M18 27v-4h4v4M26 27v-4h4v4M34 27v-4h4v4" stroke="currentColor" stroke-width="3"/><path d="M28 23V11" stroke="currentColor" stroke-width="2.5"/><path d="M28 11h9l-3 3 3 3h-9z" fill="currentColor"/>';

  /* ======================= 등록 ======================= */
  const DEF = {
    id: 'civ', name: '문명 개척', tag: '4X 전략', cat: '전략', icon: ICON, tint: '#24452a', time: '1–3시간', mood: 'drums',
    blurb: '육각 지도에 도시를 세우고 구역·불가사의를 짓고, 기술·사회 제도를 연구하며 종교·외교·전쟁으로 세계를 이끌어요. 과학·문화·지배·종교·외교·점수 승리!',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 4, hidden: true, aiNarration: true, aiDelay: 260, aiDelayFor,
    options: [
      { id: 'map', label: '지도 종류', tip: '땅과 바다의 모양.', choices: [{ v: 'r', label: '무작위' }].concat(MAPT.map((n, i) => ({ v: i, label: n, tip: ['큰 대륙 몇 개.', '하나로 붙은 큰 땅.', '섬이 많아 배가 중요해요.', '중간 크기 대륙 여럿.', '판마다 마구 섞인 지형.'][i] }))), def: 'r' },
      { id: 'size', label: '지도 크기', tip: '지도 넓이. 자동은 인원에 맞춰요.', choices: [{ v: 'a', label: '자동' }].concat(MAPS.map((m, i) => ({ v: i, label: m.n }))), def: 'a' },
      { id: 'speed', label: '게임 속도', tip: '게임이 끝나는 턴 수. 짧을수록 빨리 끝나요.', choices: SPEEDS.map((x, i) => ({ v: i, label: x.n + '(' + x.tl + '턴)' })), def: 1 },
      { id: 'cs', label: '도시국가', tip: '작은 독립 도시국가 수.', choices: [{ v: 'a', label: '자동' }, { v: 0, label: '없음' }, { v: 3, label: '적게' }, { v: 8, label: '많이' }], def: 'a' },
      { id: 'diff', label: 'AI 보너스(난이도)', tip: 'AI 문명에게 주는 생산·성장 보너스(AI 실력은 자리별 난이도).', choices: [{ v: 0, label: '없음' }, { v: 1, label: '왕' }, { v: 2, label: '황제' }, { v: 3, label: '신' }], def: 0 },
      { id: 'barb', label: '야만인', tip: '주인 없는 야만인 부대가 나타나 공격해요.', choices: [{ v: 1, label: '있음' }, { v: 0, label: '없음' }], def: 1 },
      { id: 'dis', label: '자연재해', tip: '화산·홍수 같은 재해 빈도.', choices: [{ v: 0, label: '끔' }, { v: 1, label: '보통' }, { v: 2, label: '강함' }], def: 1 },
      { id: 'dup', label: '같은 문명', tip: '여러 자리가 같은 문명을 고를 수 있는지.', choices: [{ v: 0, label: '한 자리만' }, { v: 1, label: '여럿 허용' }], def: 0 },
      { id: 'wrap', label: '동서 연결', tip: '지도 동쪽 끝과 서쪽 끝이 이어지는지.', choices: [{ v: 1, label: '연결(원작)' }, { v: 0, label: '끊김' }], def: 1 },
      { id: 'huts', label: '부족 마을', tip: '탐험하면 보상을 주는 마을이 지도에 흩어져 있어요.', choices: [{ v: 1, label: '있음' }, { v: 0, label: '없음' }], def: 1 },
    ],
    quick: [
      '도시를 세워 키우고, 구역·건물·불가사의를 지어 나라를 발전시켜요.',
      '내 차례: 유닛 이동·공격 → 도시 생산 고르기 → 연구·사회 제도 고르기 → 「턴 종료」.',
      '승리: 과학(우주 탐사) · 문화(관광객) · 지배(모든 수도) · 종교 · 외교(세계 의회) · 점수(마지막 턴).',
      '지도는 끌어서 이동, 두 손가락·휠로 확대. 위쪽 🔬🎭를 눌러 트리를 열어요.',
    ],
    rules: [
      { h: '목표', p: ['여섯 승리 중 하나를 먼저 이루면 이겨요. 야만인 야영지는 정찰병이 도시를 찾으면 습격대를 보내니 일찍 없애세요.', '🚀 과학: 「지구 인공위성 → 달 착륙 → 화성 식민지 → 외계 행성 탐사대」를 마치고 탐사선이 ' + LY_WIN + '광년을 가요(우주 기지 필요).', '🎭 문화: 내 나라를 찾은 외국 관광객이 다른 어느 나라의 국내 관광객보다 많아요(걸작·불가사의·휴양지가 관광을 만들어요).', '⚔ 지배: 모든 문명의 처음 수도를 차지해요.', '⛪ 종교: 모든 문명에서 내 종교를 믿는 도시가 절반을 넘어요.', '🕊 외교: 세계 의회 등에서 외교 승리 점수 ' + DVP_WIN + '점을 모아요.', '🏆 점수: 턴 제한(속도별 130/180/250턴)이 끝나면 점수 1등.'] },
      { h: '시작', p: ['판 시작 전 「문명 고르기」: 카드를 눌러 문명 능력·지도자 능력·고유 유닛/구역/건물/개선·성향·추천 승리를 보고 골라요(검색·추천 승리 필터·🎲 무작위). 모두 고르면 시작해요. 방장은 「지금 시작」으로 안 고른 사람을 무작위로 정할 수 있어요. 옵션 「같은 문명: 한 자리만」(기본)이면 중복이 안 되고, AI는 사람이 모두 고른 뒤 남은 문명 중에서 골라요.', '지도는 판마다 새로 만들고, 동서가 이어져 있어요(옵션). 개척자와 전사로 시작해요.', '개척자를 누르고 「도시 세우기」로 수도를 세우세요. 강(칸 사이 파란 선)·호수 옆은 민물이라 주거가 넉넉하고, 해안도 좋아요.', '안개: 내 유닛·도시 근처만 보여요. 한 번 본 땅은 흐리게 남아요. 🛖 부족 마을에 유닛이 들어가면 선물(금·신앙·유레카·영감·유닛·인구 등)을 받아요.'] },
      { h: '도시', p: ['인구 1명마다 영토의 칸 하나에서 일해 식량·생산·금·과학·문화·신앙을 얻어요(자동 배치, 도시 화면 「시민」에서 칸 고정·배치 방식 변경).', '인구는 식량으로 자라요. 주거가 인구보다 2 이상 많아야 제 속도, 모자라면 느려지거나 멈춰요(송수로·곡물 창고·농장).', '쾌적도: 인구 2명이 넘으면 2명마다 쾌적도 1이 필요해요. 사치 자원(종류마다 도시 4곳에 +1)·오락 단지가 올려 줘요. 높으면 성장·산출 보너스, 낮으면 벌칙.', '문화가 쌓이면 국경이 넓어져요. 금으로 칸을 살 수도 있어요.', '충성도: 주변 다른 나라 도시의 인구가 많으면 떨어지고, 0이 되면 그 나라로 넘어가요. 총독·기념비·수비대가 올려 줘요.'] },
      { h: '구역·건물·불가사의', p: ['구역은 도시 근처 칸에 짓는 특수지구예요: 캠퍼스(과학)·성지(신앙)·상업 중심지(금)·극장가(문화)·산업구역(생산)·항만·주둔지·오락 단지·비행장·보존 지구·송수로·주거 지구·우주 기지 등.', '구역은 인구 1·4·7…마다 하나씩 더 지을 수 있어요(송수로·주거 지구·댐·운하·우주 기지는 제외).', '인접 보너스: 캠퍼스는 산·암초, 성지는 산·숲·자연경관, 상업 중심지는 강·항만, 산업구역은 광산·송수로 옆이 좋아요. 구역끼리 붙으면 2개마다 +1. 칸을 고를 때 초록 칸에 숫자로 보여요.', '건물은 그 구역 안에 지어요(도서관·대학교·연구소 등). 연구소·증권 거래소·방송 센터·경기장은 전력이 있어야 제 힘을 내요(발전소·댐·태양광).', '불가사의는 세계에 하나뿐! 놓을 칸 조건이 있어요(피라미드는 사막 등). 다른 나라가 먼저 지으면 생산은 그대로 남아요.'] },
      { h: '연구·사회 제도·정부', p: ['🔬 과학으로 기술을, 🎭 문화로 사회 제도를 연구해요. 유레카·영감 조건을 이루면 비용의 40%를 바로 얻어요. 잠긴 항목을 누르면 목표로 정해 자동으로 이어 연구해요.', '정부마다 정책 슬롯(군사·경제·외교·와일드카드)이 달라요. 사회 제도를 마치면 정책을 무료로 바꿀 수 있어요(그 밖엔 바꾼 카드 수만큼 금).', '정부 유산: 한 정부를 오래 쓰면 그 정부의 유산 보너스가 쌓이고(최대 5단계) 정부를 바꿔도 남아요.', '트리 화면은 시대별 열과 선행 연결선으로 보여요. 항목을 누르면 여는 것·유레카 조건을 보고 「연구하기」나 「목표로」를 눌러요.'] },
      { h: '강·지형', p: ['강은 칸 사이 변을 따라 흘러요. 강을 건너면 남은 이동력을 다 써요(「공학」 뒤 양쪽 도로면 다리). 강 건너 근접 공격은 −5.', '강에 붙은 칸: 민물(주거 +), 상업 중심지 인접 +2, 물레방아·댐·일부 불가사의 조건. 범람원은 강가에 생겨요.'] },
      { h: '유닛·전투', p: ['유닛을 누르면 갈 수 있는 칸이 밝게, 공격할 수 있는 적은 빨간 테두리로 보여요. 빨간 칸을 누르면 예상 피해가 나오고 「공격!」으로 공격해요. 먼 칸을 두 번 누르면 여러 턴 이동 명령.', '피해는 전투력 차이로 정해져요(체력 100). 언덕·숲 +3, 경계 +3~+6, 적에 붙은 내 유닛마다 측면 +2, 내 유닛 옆이면 지원 +2. 대기병은 기병에 +10.', '원거리 유닛은 반격을 받지 않아요. 공성 유닛(투석기 등)은 도시·성벽에 강하고, 공성 망치·공성탑을 붙이면 근접 유닛도 성벽을 뚫어요.', '도시는 성벽이 있으면 스스로 쏴요. 체력을 0으로 만든 뒤 근접 유닛이 들어가면 점령!', '경험치로 승급(체력 +50)하고, 금으로 새 시대 유닛으로 업그레이드해요. 전략 자원(말·철·초석 등)이 필요한 유닛이 있어요.', '평화 중인 나라 영토엔 군사 유닛이 못 들어가요(친선·동맹이면 가능). 건설자는 개선 3번, 숲 베기로 생산을 얻어요.'] },
      { h: '군단·항공·핵', p: ['군단·군대: 「민족주의」 뒤 같은 유닛 둘을 붙여 군단(+10), 「동원」 뒤 셋을 군대(+17)로 합쳐요(바다는 「중상주의」 함대). 붙어 있는 두 유닛 중 하나를 고르고 「🎖」를 눌러요.', '군사 공학자: 도로(충전 안 씀)·철도(증기력+석탄 1)·요새를 지어요. 철도 위 이동은 아주 빨라요.', '항공: 비행장(구역)·도시에 머물러요(도시 2대, 비행장 2대+격납고·공항). 고르면 작전 범위 안 공격할 칸이 빨갛게 보여요. 전투기는 「경계 비행」으로 적기를 요격하고, 폭격기는 도시·성벽·시설에 강해요. 정찰기는 넓게 정찰해요. 「재배치」로 다른 기지로 옮겨요. 기지 도시를 빼앗기면 사라져요.', '핵: 「맨해튼 프로젝트」 뒤 원자폭탄(우라늄 2), 「아이비 작전」 뒤 열핵 폭탄(우라늄 3)을 프로젝트로 만들어요. 도시 화면 「정보」에서 12칸 안 전쟁 상대에게 쏴요. 반경의 모든 유닛이 사라지고 도시 인구가 크게 줄고 낙진(10턴, 산출 없음·피해)이 남아요. 모든 나라가 크게 분노하고 비상사태가 열려요.'] },
      { h: '걸작·관광', p: ['작가는 문학 걸작 2점, 예술가는 미술 3점, 음악가는 음악 2점을 만들어요(도시에 빈 칸이 있어야). 걸작 칸: 원형 극장(문학)·미술관(미술)·고고학 박물관(유물)·방송 센터(음악)·신전(성유물)·궁전(아무거나).', '테마: 미술관 3칸이 서로 다른 예술가, 고고학 박물관 3칸이 같은 시대·서로 다른 문명의 유물이면 그 칸들 산출·관광 2배.', '고고학: 「자연사」 뒤 고고학 박물관이 있는 도시에서 고고학자를 만들어 🏺 고대 유적(옛 전투·야만인 야영지 자리)을 발굴해요. 성유물은 부족 마을·순교한 사도에게서 얻어요.', '관광(원작 값): 문학 2 · 미술 3 · 유물 3 · 음악 4 · 성유물 8 + 불가사의·휴양지 등. 교역로·국경 개방·같은 종교는 그 나라로 가는 관광을 늘려요.'] },
      { h: '종교·위인', p: ['신앙이 조금(속도에 따라 15~18) 모이면 만신전을 세워요. 위대한 선지자를 얻어 성지에서 쓰면 종교를 창시하고, 신앙으로 선교사·사도를 사서 전파해요. 사도끼리는 신학 전투도 해요.', '구역·건물이 위인 점수를 줘요. 점수가 차면 자동으로 영입되고(금·신앙으로 후원 가능), 「능력 사용」으로 유레카·불가사의 생산·금·걸작 등을 얻어요. 장군·제독은 근처 유닛 전투력 +5.'] },
      { h: '도시국가·외교', p: ['도시국가에 사절을 보내면 보너스를 얻고, 가장 많이(3명 이상) 보내면 종주국이 돼요. 도시국가의 부탁(교역로·기술·구역 등)을 들어주면 사절 +1. 종주국은 금으로 그 군대를 징집해요.', '거래: 외교 화면 「🤝 거래」에서 금·턴당 금·사치 자원·전략 자원·도시·국경 개방을 주고받아요(30턴). AI는 호감과 이득을 따져 받아들여요.', '첩보: 「외교 업무」부터 첩보원을 만들어 다른 나라 도시에서 정보 수집·자금 빼돌리기·기술 훔치기·생산 방해·걸작 훔치기, 도시국가 선거 조작, 내 도시 방첩을 해요.', '자유 도시: 충성도가 0이 된 도시는 독립해 자유 도시가 되고, 주변 영향력이 큰 나라로 넘어가요. 자유 도시는 공격해 차지해도 다른 나라가 화내지 않아요.', '외교: 전쟁 선포·평화·친선 선언·동맹(행정 제도 필요)·비난. 기습 전쟁이나 점령은 다른 나라의 불만을 키워요. AI는 지도자 성향에 따라 호감이 달라요.', '세계 의회(중세부터): 결의안에 표를 던져요. 외교 호의로 표를 더 살 수 있어요.'] },
      { h: '흥망성쇠', p: ['시대 점수: 첫 구역·불가사의·위인·종교·새 도시·전투 승리 등으로 얻어요. 세계 시대가 바뀔 때 점수가 낮으면 암흑기(충성도↓), 높으면 황금기(충성도·산출↑), 암흑기 뒤 황금기면 영웅 시대. 시대마다 헌신을 하나(영웅 시대 둘) 골라요.', '총독: 사회 제도로 칭호를 얻어 임명·진급하고 도시에 배치해요.', '비상사태: 누군가 수도나 도시국가를 점령하면 다른 나라들이 그 나라에 맞서 전투력 +4를 얻어요.'] },
      { h: '몰려드는 폭풍', p: ['기후: 석탄·석유 발전소가 이산화탄소를 내면 기후 단계가 올라 홍수·폭풍·가뭄·화산이 잦아지고, 3·5·7단계에 저지대가 바다에 잠겨요(방조제). 홍수·화산은 땅을 비옥하게 하기도 해요.', '전력: 발전소(석탄·석유·원자력)·댐(수력)·태양광·풍력이 6칸 안 도시에 전력을 줘요. 외교 호의는 세계 의회 표로 써요. 운하·댐 구역도 있어요.'] },
      { h: '조작', p: ['끌기: 지도 이동 · 두 손가락/휠/＋−: 확대 · ⌖: 수도로 · 미니맵 누르기: 그곳으로.', '아래 「다음 할 일」 버튼이 정할 것(연구·생산·유닛)을 차례로 알려 줘요.', 'PC: N/Tab 다음 유닛 · E 턴 종료 · F 경계/도시 세우기 · Space 건너뛰기 · T 기술 · C 사회 제도 · P 정책 · D 외교 · M 메뉴 · L 도시 목록 · 방향키 이동 · Esc/오른쪽 클릭 취소.', '한 폰에서 여럿이 할 때는 차례마다 가림막이 나와요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려울수록 도시 확장·구역 배치·전쟁·첩보·거래 판단이 좋아요. 전쟁 성향 지도자는 힘이 앞서면 실제로 쳐들어오고, 바다 건너 침공도 해요. 「AI 보너스」 옵션(왕·황제·신)은 원작처럼 AI 산출·전투력에 보너스를 줘요.', '지도자마다 성향(전쟁·과학·문화·종교·확장·불가사의·평화)이 있어 하는 일이 달라요.'] },
    ],
    tutorial: [
      { text: '문명 개척에 온 걸 환영해요! 지도를 끌어 움직이고 두 손가락이나 + − 로 확대해요.' },
      { sel: '.c6-bot', text: '먼저 개척자를 눌러 「🏛 도시 세우기」로 수도를 세워요. 유닛을 누르면 갈 수 있는 칸이 밝게 보여요.' },
      { sel: '.c6-res', text: '여기를 눌러 연구할 기술과 사회 제도를 골라요. 💡 유레카 조건을 이루면 빨리 끝나요.' },
      { sel: '.c6-side', text: '☰ 메뉴에서 정부·정책, 종교, 위인, 도시국가, 외교, 세계 의회 등을 열어요. 🔔는 알림이에요.' },
      { sel: '.c6-bot', text: '할 일이 끝나면 「턴 종료」. 「다음 할 일」 버튼이 정해야 할 것을 알려 줘요. 도시를 누르면 생산·구역을 골라요!' },
    ],
    controls: [
      { id: 'next', label: '다음 유닛', keys: ['KeyN', 'Tab'], pad: ['rb'] },
      { id: 'end', label: '턴 종료', keys: ['KeyE'], pad: ['start'] },
      { id: 'fort', label: '경계 / 도시 세우기', keys: ['KeyF'], pad: ['y'] },
      { id: 'skip', label: '건너뛰기', keys: ['Space'], pad: ['x'] },
      { id: 'tech', label: '기술 트리', keys: ['KeyT'], pad: ['lb'] },
      { id: 'civics', label: '사회 제도', keys: ['KeyC'] },
      { id: 'policy', label: '정부·정책', keys: ['KeyP'] },
      { id: 'dip', label: '외교', keys: ['KeyD'] },
      { id: 'menu', label: '메뉴', keys: ['KeyM'], pad: ['back'] },
      { id: 'cities', label: '도시 목록', keys: ['KeyL'] },
      { id: 'zin', label: '확대', keys: ['Equal', 'NumpadAdd'], pad: ['rt'] },
      { id: 'zout', label: '축소', keys: ['Minus', 'NumpadSubtract'], pad: ['lt'] },
      { id: 'left', label: '지도 왼쪽', keys: ['ArrowLeft'], pad: ['lx-'] },
      { id: 'right', label: '지도 오른쪽', keys: ['ArrowRight'], pad: ['lx+'] },
      { id: 'up', label: '지도 위', keys: ['ArrowUp'], pad: ['ly-'] },
      { id: 'down', label: '지도 아래', keys: ['ArrowDown'], pad: ['ly+'] },
    ],
    codex: codexData(),
    hint, preview,
    save: true,
    saveLabel(s) { return s.ph === 'k' ? '문명 고르기' : s.t + '턴 · ' + ERA[s.era || 0] + (s.P[s.cur] && s.P[s.cur].k === 'maj' ? ' · ' + CIVS[s.P[s.cur].civ].n : ''); },
    onCancel() { return curView ? curView.cancel() : false; },
    init, actor, apply, ai, result, mount,
    _t: { ctx, commit, scoreOf, cityCalc, techEra, citiesOf, aliveMaj, visTourists, domTourists, CIVS, TECH, UT, CIVIC, BLD, DIS, WON, reach, targets, combatPreview, canBuild, itemCost, pathTo, hexDist, capOf, atWar, maxMv },
  };
  L.register(DEF);
})();
