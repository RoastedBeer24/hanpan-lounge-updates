/* 미니 레이싱 — realtime kart racing: 50 hand-made tracks (each with its own gimmick), 34 items, press-and-hold ◀ ▶ steering (two thumbs or one), follow camera.
   One human per device; AI fills the grid. Online: each device is authoritative for its own car(s) (host also for AI),
   hazards are owned/published by the device that spawned them, victims detect hits and publish consumed ids. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- constants (world units ≈ 1 car length / 4.6) ---------- */
  const LAPS = 3, NS = 600, NSEC = 20, SECSKIP = 4;
  const VMAX = 30, ACC = 19, STEER = 2.7, GRIP = 7.5, BOOST = 1.4, RAD = 2.05;
  const SUBSTEP = 1 / 120;
  const BOX_RESPAWN = 4000, BOX_R = 1.5, ROCKET_V = 64, HOMING_V = 50;
  /* durability (내구도): hard hits cost HP, 0 = the car explodes and is out of the race. Every new lap repairs a little. */
  let NT = 0; // 「시간대」 1 = 밤 (state.nt): 화면이 어둡고 전조등·후미등·가로등만 밝음
  let WX = 0; // 「날씨」 0 맑음 · 1 비 · 2 폭우 · 3 눈 — state.wx로 모든 기기에 전달
  const WXG = [1, 0.8, 0.66, 0.74], WXN = ['☀️ 맑음', '🌧 비', '⛈ 폭우', '❄️ 눈'];
  let HP_ON = true;   // 「내구도」 옵션(끄면 피해·폭발·막대 없음) — state.hpo로 모든 기기에 전달
  const HP_MAX = 100, LAP_FIX = 30, START_GHOST = 2, REGEN = 0.5, REGEN_WAIT = 4; // regen: HP/s after REGEN_WAIT s without damage
  const WALL_D0 = 15, WALL_DK = 1, CAR_D0 = 8, CAR_DK = 1.8, HIT_MAX = 25; // impact speed above D0 → (v − D0) × K damage
  const ITEM_DMG = { rocket: 18, homing: 18, cball: 16, boom: 10, fw: 8, shock: 8, spring: 10, frost: 8, wall: 12, oil: 3, tacks: 5, bees: 6, blow: 4, net: 2, giant: 10 };
  const GIM_DMG = { rock: 10, ball: 7, gey: 8, tw: 8, mag: 4, herd: 3, bang: 20, train: 14, bolt: 8, sail: 5 };
  const FALL_DMG = { sea: 4, river: 4, lava: 10, void: 5, gap: 5, sky: 5, pit: 5, chasm: 5 };
  const gone = (c) => c.fin != null || c.out > 0;
  /* 차량 세팅: 6 points shared between grip (접지), top speed (최고속) and acceleration (가속), 0..4 each (2/2/2 = 균형).
     Per point away from 2: grip ±10% sideways grip, ±6% turn rate and less speed lost while turning, top speed ±1.2%, acceleration ±15%. */
  const SETUP_SUM = 6, SETUP_MAX = 4;
  const SETUPS = [{ k: 'bal', n: '균형', p: [2, 2, 2] }, { k: 'grip', n: '코너형', p: [4, 1, 1] }, { k: 'speed', n: '직선형', p: [1, 4, 1] }, { k: 'acc', n: '가속형', p: [2, 1, 3] }];
  function okSetup(p) { return Array.isArray(p) && p.length === 3 && p.every((v) => Number.isInteger(v) && v >= 0 && v <= SETUP_MAX) && p[0] + p[1] + p[2] === SETUP_SUM; }
  function applySetup(c, p) {
    if (!okSetup(p)) p = [2, 2, 2];
    c.setup = p.slice(); c.sg = 1 + 0.1 * (p[0] - 2); c.st = 1 + 0.06 * (p[0] - 2); c.sv = 1 + 0.012 * (p[1] - 2); c.sa = 1 + 0.15 * (p[2] - 2);
  }
  /* AI: lots of tight bends → grip, mostly fast sweepers → top speed, otherwise balanced (normal AI sometimes tries others); easy AI just guesses */
  function aiSetup(tr, lv, rnd) {
    if (lv === 1) return SETUPS[Math.floor(rnd() * SETUPS.length)].p;
    const sh = tr.sharp || 0; // share of the lap in tight bends (measured: grip pays off above ~0.14, top speed below ~0.06)
    let k = sh > 0.14 ? 'grip' : sh < 0.06 ? 'speed' : 'bal';
    if (lv === 2 && rnd() < 0.25) k = rnd() < 0.5 ? 'acc' : 'bal';
    return SETUPS.find((q) => q.k === k).p;
  }
  /* course hazards: the same kind of trouble again within 5 s (stuck in a whirlwind, the next lightning) costs only a quarter */
  /* car-car: the car that drove into the other one pays; ramming again within 8 s (on purpose) costs more and more */
  function ramDmg(W, c, d, share) {
    const hard = share > 0.5 && d > 8; // a real ram, not a nudge
    if (hard) { c.ramN = W.clock - (c.ramT == null ? -99 : c.ramT) < 8 ? Math.min(3, (c.ramN || 0) + 1) : 0; c.ramT = W.clock; }
    c.dmg += Math.min(HIT_MAX + 15, d * (0.1 + 1.05 * share) * (hard ? 1 + 0.8 * (c.ramN || 0) : 1));
  }
  const gimDmg = (c, k) => { c.dmg += (GIM_DMG[k] || 0) * (c.gimCd > 0 ? 0.25 : 1); c.gimCd = 5; };
  const sector = (i) => Math.floor(i * NSEC / NS);
  const wrapA = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; };
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const fmtT = (ms) => { const s = ms / 1000, m = Math.floor(s / 60), r = s - m * 60; return m + ':' + (r < 10 ? '0' : '') + r.toFixed(1); };
  const idxDist = (a, b) => { const d = Math.abs(a - b) % NS; return Math.min(d, NS - d); };

  /* surfaces: v = top-speed factor, g = lateral grip, acc = acceleration factor */
  const SURF = {
    road: { v: 1, g: GRIP, acc: 1 },
    grass: { v: 0.36, g: 4.5, acc: 0.6 },
    sand: { v: 0.42, g: 3.4, acc: 0.6 },
    snow: { v: 0.38, g: 3.0, acc: 0.55 },
    mud: { v: 0.34, g: 4.0, acc: 0.5 },
    dirt: { v: 0.8, g: 5.2, acc: 0.9 },
    ice: { v: 0.94, g: 1.0, acc: 0.42 },
    wood: { v: 0.96, g: 6.5, acc: 1 },
    rough: { v: 0.8, g: 5.6, acc: 0.85 }, // cracked ground (volcano)
    ash: { v: 0.4, g: 3.8, acc: 0.55 },
    metal: { v: 1, g: 3.1, acc: 0.85 }, // space station deck: low friction
    yard: { v: 0.72, g: 6, acc: 0.9 }, // harbour concrete yard
    syrup: { v: 0.42, g: 9, acc: 0.38 }, // candy factory: sticky syrup puddles
    sugar: { v: 0.42, g: 3.8, acc: 0.55 }, // powdered-sugar run-off
    fluff: { v: 0.5, g: 3.6, acc: 0.6 }, // cloud edge of the sky road
    carpet: { v: 0.45, g: 4.6, acc: 0.6 }, // toy room rug
    wet: { v: 1, g: 5.4, acc: 0.92 }, // rain-soaked road: a little less grip
    glacier: { v: 0.97, g: 2.5, acc: 0.72 }, // glacier ice road: slides everywhere (not as bad as a frozen patch)
    shallow: { v: 0.3, g: 3.2, acc: 0.4 }, // tidal water over the sandbar
    slush: { v: 0.6, g: 4, acc: 0.6 }, // snow left behind by a rolling snowball
    junk: { v: 0.48, g: 4.2, acc: 0.6 }, // scrapyard: gravel and scrap beside the road
    gravel: { v: 0.97, g: 5.8, acc: 0.95 }, // rally stage: loose gravel road
    bog: { v: 0.7, g: 4.4, acc: 0.6 }, // rally mud bog on the road
    puddle: { v: 0.88, g: 5, acc: 0.85 }, // rally water splash (washes the mud off)
    tire: { v: 0.97, g: 6.5, acc: 1 }, // 험로 타이어: what any off-road surface feels like
    /* round 12 */
    pack: { v: 1, g: 6, acc: 0.95 }, // ski piste: packed snow
    frozen: { v: 0.97, g: 3.6, acc: 0.8 }, // ice road on the lake (less slippery than an ice patch)
    splash: { v: 0.86, g: 4.6, acc: 0.8 }, // puddle
    snowroad: { v: 0.95, g: 3.4, acc: 0.75 }, // season track, lap 3
    moon: { v: 1, g: 4.6, acc: 0.85 }, // moon dust road
    dust: { v: 0.55, g: 3.4, acc: 0.6 }, // loose moon dust beside the road
    foam: { v: 0.95, g: 1.4, acc: 0.5 }, // 거품 줄
    mudpit: { v: 0.55, g: 4.2, acc: 0.5 }, // course hazard: mud patch on the road
    slick: { v: 0.98, g: 0.8, acc: 0.55 }, // course hazard: spilled oil (almost no grip)
  };

  /* ---------- items (original designs) ---------- */
  const ITEMS = {
    turbo: { n: '터보 캔', d: '1.3초 동안 급가속' },
    turbo3: { n: '터보 캔 ×3', d: '터보 캔 3번' },
    oil: { n: '기름 웅덩이', d: '뒤에 떨어뜨려요. 밟은 차는 미끄러져 돌아요' },
    rocket: { n: '로켓', d: '앞으로 곧장 날아가 처음 맞은 차를 날려요 (내구도 −18)' },
    homing: { n: '유도탄', d: '순위 바로 앞 차를 쫓아가 맞혀요 (내구도 −18)' },
    shield: { n: '방패', d: '공격 한 번을 막아요 (최대 12초)' },
    cloud: { n: '번개 구름', d: '꼴찌 전용. 나보다 앞선 차 모두 2.5초 감속' },
    magnet: { n: '자석', d: '3초 동안 바로 앞 차 쪽으로 끌려가며 빨라져요' },
    spring: { n: '스프링 지뢰', d: '뒤에 놓아요. 밟은 차는 공중으로 튕겨 올라요 (내구도 −10)' },
    smoke: { n: '연막탄', d: '뒤에 연기를 피워요. 지나간 차는 앞이 흐려져요' },
    warp: { n: '순간이동', d: '트랙을 따라 앞으로 휙 이동해요' },
    frost: { n: '얼음 폭탄', d: '앞쪽 길에 던져요. 떨어진 곳의 차는 잠깐 얼고 얼음판이 남아요 (내구도 −8)' },
    mirror: { n: '반사 방패', d: '8초 동안 로켓·유도탄을 쏜 차에게 되돌려 보내요' },
    giant: { n: '거대화', d: '5초 동안 커져서 부딪힌 차를 튕겨 내요 (튕겨진 차 내구도 −10)' },
    boom: { n: '부메랑', d: '앞으로 날아갔다 돌아와요. 닿은 차를 한 번씩 맞혀요 (내구도 −10)' },
    tacks: { n: '압정', d: '뒤에 넓게 뿌려요. 밟은 차는 바퀴가 펑크 나 느려져요 (내구도 −5)' },
    shock: { n: '충격파', d: '내 둘레로 퍼져 가까운 차를 밀어내고 돌려요 (내구도 −8)' },
    net: { n: '거미줄', d: '앞으로 쏘아요. 맞은 차는 거미줄에 걸려 확 느려져요' },
    steal: { n: '집게 손', d: '순위 바로 앞 차의 아이템을 빼앗아요' },
    ghost: { n: '유령', d: '4초 동안 차·아이템·장애물을 스르륵 통과해요' },
    hop: { n: '점프', d: '그 자리에서 높이 뛰어 공격·함정·틈을 넘어요' },
    tire: { n: '험로 타이어', d: '6초 동안 잔디·모래·진흙에서도 길처럼 달려요' },
    /* round 12 */
    balloon: { n: '풍선', d: '3초 동안 둥실 떠서 물·틈·잔디·함정 위를 지나가요' },
    auto: { n: '자율주행', d: '4초 동안 알아서 좋은 길로 조금 더 빠르게 달려요' },
    fw: { n: '불꽃놀이', d: '앞쪽 세 방향으로 작은 폭죽을 쏴요 (내구도 −8)' },
    paint: { n: '물감 폭탄', d: '앞으로 던져요. 맞은 차는 3초 동안 앞이 물감으로 가려져요' },
    wall: { n: '바리케이드', d: '뒤에 길막이를 세워요. 부딪힌 차는 확 느려져요 (내구도 −12)' },
    vort: { n: '소용돌이 덫', d: '뒤에 놓아요. 근처 차를 빨아들이며 느리게 해요' },
    bomb: { n: '째깍 폭탄', d: '앞 차에 붙여요. 3초 뒤 펑! 부딪히면 다른 차에게 넘어가요 (내구도 −20)' },
    foam: { n: '거품 줄', d: '내 뒤로 길게 미끄러운 거품을 깔아요' },
    drone: { n: '호위 드론', d: '12초 동안 날아오는 공격을 2번까지 쏴서 떨어뜨려요' },
    blow: { n: '송풍기', d: '앞쪽 차를 옆으로 날리고 앞의 함정도 날려 버려요' },
    rear: { n: '뒤로 대포', d: '뒤쪽으로 대포알을 쏴요 (내구도 −16)' },
    bees: { n: '벌떼', d: '순위 바로 앞 차를 쫓아가 3초 동안 따끔따끔 괴롭혀요' },
  };
  const ITEM_KEYS = Object.keys(ITEMS);
  /* odds by race position (rubber-banding): lead / middle / back / last.
     Leaders get defensive / trap items, the pack gets attacks, the back gets catch-up items. */
  const ODDS = {
    lead: { oil: 14, shield: 9, rocket: 7, turbo: 8, spring: 9, smoke: 6, mirror: 7, boom: 5, frost: 4, tacks: 9, shock: 5, hop: 6, wall: 9, vort: 7, foam: 8, drone: 7, rear: 9, blow: 4 },
    mid: { oil: 5, shield: 4, rocket: 9, homing: 7, turbo: 11, turbo3: 4, spring: 4, smoke: 3, frost: 6, boom: 7, magnet: 5, mirror: 4, tacks: 4, shock: 5, net: 7, steal: 5, hop: 3, tire: 3, fw: 8, paint: 7, bomb: 6, bees: 5, blow: 5, vort: 3, balloon: 3 },
    back: { rocket: 6, homing: 12, turbo: 9, turbo3: 11, magnet: 8, warp: 8, giant: 6, frost: 3, boom: 3, shield: 2, net: 6, steal: 6, ghost: 5, tire: 5, balloon: 7, auto: 7, bees: 7, bomb: 5, fw: 4, paint: 4 },
    last: { homing: 11, turbo3: 14, turbo: 4, cloud: 12, warp: 10, giant: 7, magnet: 7, steal: 6, ghost: 6, tire: 5, auto: 10, balloon: 7, bees: 7 },
    solo: { turbo: 16, turbo3: 7, oil: 6, rocket: 5, shield: 4, spring: 5, smoke: 4, frost: 5, warp: 6, giant: 4, boom: 5, tacks: 4, shock: 3, hop: 4, ghost: 4, tire: 4, balloon: 4, auto: 3, fw: 4, wall: 3, foam: 3, drone: 3, blow: 3, rear: 2, vort: 2 },
  };
  /* rank → table; rubber-band-lite: a car far behind the leader (gap in laps) draws from the next table down */
  const ODDS_STEP = ['lead', 'mid', 'back', 'last'];
  function rollItem(rank, n, rnd, gap) {
    let t;
    if (n <= 1) t = ODDS.solo;
    else {
      let k = rank === n - 1 ? (n >= 3 ? 3 : 2) : (rank / (n - 1) < 0.25 ? 0 : rank / (n - 1) < 0.7 ? 1 : 2);
      if (rank > 0 && gap > 0.22) k = Math.min(n >= 3 ? 3 : 2, k + 1);
      t = ODDS[ODDS_STEP[k]];
    }
    let sum = 0; for (const k in t) sum += t[k];
    let r = (rnd || Math.random)() * sum;
    for (const k in t) { r -= t[k]; if (r < 0) return k; }
    return 'turbo';
  }

  /* ---------- tracks ----------
     kind spline: closed Catmull-Rom through pts. kind poly: corners with fillet radius (tight city corners).
     wall: distance beyond the road edge where a solid wall stands (null = open run-off).
     water: {d, inside, zones} — beyond edge+d on the infield side (or both sides inside zones) = splash → respawn.
     cut: shortcuts as fractions a→b of the lap, bend = sideways bow, hw = half width, s = surface.
     ice: [a,b] fractions with icy road. pads: [frac, lateral]. boxes: item-box rows. ramps: jump ramps. */
  const TRACKS = [
    {
      name: '플럼 서킷', hint: '슬립스트림: ≫ 표시 직선에서 앞차 바로 뒤에 붙으면 빨라져요', sub: '기본 서킷 · 잔디 런오프', th: 'plum', kind: 'spline', half: 7, off: 'grass', wall: null,
      pts: [[100, 32], [156, 34], [176, 68], [174, 140], [172, 220], [160, 276], [120, 292], [68, 290], [32, 268], [28, 216], [64, 180], [68, 144], [30, 108], [28, 60], [52, 34]],
      pads: [[0.27, -2.6], [0.62, 2.6]], boxes: [0.12, 0.45, 0.8], cut: [], ice: [], ramps: [], hz: [[0.33, 3.4, 2.4, 'pud'], [0.71, -3.2, 2.4, 'oil']],
      slip: [[0.14, 0.37], [0.435, 0.515], [0.94, 1.05]],
    },
    {
      name: '사막 협곡', hint: '낙석: 길에 그림자가 생기면 바위가 떨어져 잠시 길을 막아요', sub: '모래 갓길 · 바위 벽 · 점프대', th: 'desert', kind: 'spline', half: 7.5, off: 'sand', wall: 4.5,
      pts: [[110, 254], [170, 254], [212, 244], [232, 210], [234, 150], [232, 92], [222, 50], [190, 28], [128, 26], [66, 30], [36, 52], [34, 86], [60, 106], [116, 110], [156, 116], [178, 138], [162, 162], [116, 166], [62, 172], [36, 196], [40, 236], [66, 252]],
      pads: [[0.36, 0], [0.47, -2.6]], boxes: [0.1, 0.4, 0.62], ice: [], ramps: [0.24],
      rocks: { per: 4.4, warn: 1.5, n: 3, r: 2.3, life: 6, off: 5 },
      cut: [{ a: 0.69, b: 0.81, bend: 0, hw: 3.6, s: 'dirt' }],
    },
    {
      name: '눈꽃 고개', hint: '눈덩이: 길가 화살표가 깜빡이면 큰 눈덩이가 굴러와요', sub: '눈밭 · 빙판 · 얼어붙은 호수', th: 'snow', kind: 'spline', half: 7, off: 'snow', wall: null,
      pts: [[110, 272], [170, 266], [204, 236], [196, 198], [150, 184], [100, 174], [80, 144], [104, 118], [168, 112], [202, 86], [194, 46], [150, 24], [96, 28], [56, 54], [32, 100], [28, 160], [38, 226], [64, 264]],
      pads: [[0.66, 0], [0.92, 2.4]], boxes: [0.08, 0.42, 0.74], ice: [[0.17, 0.25], [0.5, 0.58], [0.84, 0.88]], ramps: [],
      balls: [[0.395, 1, 8, 2], [0.66, -1, 7, 4.5], [0.79, 1, 7.5, 1]],
      cut: [{ a: 0.225, b: 0.385, bend: -6, hw: 7.5, s: 'ice' }],
    },
    {
      name: '밤의 도시', hint: '도로에 일반 차들이 천천히 달려요. 옆으로 추월하세요', sub: '네온 · 직각 코너 · 골목길', th: 'city', kind: 'poly', half: 7, off: 'road', wall: 1.4, night: true,
      pts: [[40, 40, 0], [200, 40, 10], [200, 120, 9], [150, 120, 9], [150, 170, 9], [220, 170, 10], [220, 260, 10], [110, 260, 9], [110, 210, 9], [40, 210, 10]],
      start: [100, 40], pads: [[0.6, 0], [0.86, 0]], boxes: [0.07, 0.36, 0.66], ice: [], ramps: [],
      traffic: { n: 5, v: 14 },
      cut: [{ a: 0.083, b: 0.215, bend: 0, hw: 3.4, s: 'road', pts: [[175, 40], [175, 120]] }],
    },
    {
      name: '해변 루프', hint: '파도: 둑길에 파도가 밀려와 옆으로 밀어요. 가운데로!', sub: '물에 빠지면 복귀 · 둑길 · 모래톱', th: 'beach', kind: 'spline', half: 7, off: 'sand', wall: null,
      water: { d: 3.5, inside: true, zones: [[0.3, 0.4], [0.52, 0.73]] },
      pts: [[110, 252], [170, 250], [212, 226], [232, 180], [222, 124], [234, 70], [206, 30], [146, 24], [96, 42], [64, 78], [76, 120], [52, 162], [42, 210], [66, 246]],
      pads: [[0.2, 0], [0.75, -2.4]], boxes: [0.1, 0.46, 0.8], ice: [], ramps: [0.25],
      waves: { zones: [[0.3, 0.4], [0.52, 0.73]], per: 7, off: 3, v: 12, w: 1.8 },
      cut: [{ a: 0.555, b: 0.69, bend: 0, hw: 2.8, s: 'wood' }],
    },
    {
      name: '숲속 8자', hint: '8자 교차로: 두 번째로 지날 때는 다리 위를 달려요', sub: '8자 교차 · 다리 · 통나무 길', th: 'forest', kind: 'spline', half: 6.8, off: 'mud', wall: null, eight: true,
      pts: null, pads: [[0.2, 0], [0.7, 0]], boxes: [0.1, 0.3, 0.6, 0.93], ice: [], ramps: [],
      cut: [{ a: 0.43, b: 0.57, bend: 0, hw: 2.6, s: 'wood' }],
    },
    /* ----- round 5 tracks -----
       rough: [a,b] cracked road (slower). rivers: bands crossing the course ({pts, w, k:'river'|'void', lanes:[[lat, hw]]});
       only the lanes (logs / bridges) are drivable inside a band, anything else = fall → respawn.
       pillars: [frac, lat, r] solid columns on the road; bumpers: true → they bounce you away.
       movers: [frac, amp, period, r] containers swinging across the road on a crane (position from the race clock).
       deck: road surface override. water.k: 'sea' | 'lava' | 'void'. */
    {
      name: '화산 분화구', hint: '간헐천: 길 위 구멍이 부글부글 빛나면 곧 용암이 솟아요', sub: '용암에 빠지면 복귀 · 갈라진 땅 · 돌다리', th: 'volcano', kind: 'spline', half: 7, off: 'ash', wall: null,
      water: { d: 3, inside: true, k: 'lava', zones: [[0.47, 0.53]] },
      pts: [[120, 270], [180, 262], [222, 232], [236, 180], [220, 130], [232, 80], [204, 38], [150, 28], [100, 44], [84, 86], [112, 122], [104, 162], [64, 176], [34, 210], [50, 252], [82, 270]],
      pads: [[0.3, 0], [0.8, -2.4]], boxes: [0.12, 0.4, 0.72], ice: [], ramps: [],
      rough: [[0.18, 0.26], [0.6, 0.67], [0.9, 0.95]],
      geysers: [[0.06, 2.6, 5.2, 1], [0.2, -2.4, 5.6, 2.5], [0.36, 0, 6, 0], [0.62, 2.8, 5, 3.4], [0.88, -2.6, 5.4, 1.8]],
      cut: [{ a: 0.555, b: 0.66, bend: 5, hw: 3, s: 'rough' }],
    },
    {
      name: '정글 폭포', hint: '강은 통나무 두 개 위로만 건널 수 있어요', sub: '강은 통나무로 건너요 · 진흙 · 폭포', th: 'jungle', kind: 'spline', half: 7, off: 'mud', wall: null,
      pts: [[110, 276], [176, 270], [218, 240], [226, 190], [206, 150], [218, 104], [214, 52], [176, 28], [118, 30], [70, 40], [40, 80], [56, 126], [44, 170], [30, 220], [56, 262]],
      rivers: [{ pts: [[-20, 146], [60, 140], [130, 156], [200, 132], [300, 140]], w: 6.5, k: 'river', lanes: [[-3.4, 2.4], [3.4, 2.4]] }],
      pads: [[0.06, 0], [0.55, 0]], boxes: [0.15, 0.45, 0.85], ice: [], ramps: [], cut: [],
    },
    {
      name: '고대 유적', hint: '무너지는 바닥: 금 간 타일은 곧 꺼져요. 다른 칸으로!', sub: '좁은 회랑 · 돌기둥 · 직각 코너', th: 'ruins', kind: 'poly', half: 5.8, off: 'dirt', wall: 1.3,
      pts: [[40, 40, 9], [160, 40, 9], [160, 92, 9], [226, 92, 10], [226, 214, 10], [168, 214, 9], [168, 262, 9], [40, 262, 10], [40, 168, 9], [96, 168, 9], [96, 116, 9], [40, 116, 9]],
      start: [80, 40], pads: [[0.36, 0], [0.62, 0]], boxes: [0.08, 0.42, 0.7], ice: [], ramps: [],
      pillars: [[0.21, 0, 1.3], [0.275, -2.8, 1.4], [0.315, 2.8, 1.4], [0.535, 0, 1.4], [0.567, 2.8, 1.4], [0.6, -2.8, 1.4]],
      tiles: [[0.06, 0.1], [0.665, 0.71], [0.935, 0.975]],
      cut: [],
    },
    {
      name: '우주 정거장', hint: '끊긴 바닥은 좁은 다리로만 건너요. 금속 바닥은 미끄러워요', sub: '미끄러운 금속 판 · 끊긴 바닥은 다리로 · 떨어지면 복귀', th: 'space', kind: 'spline', half: 7.5, off: 'metal', wall: null, deck: 'metal',
      water: { d: 2.4, inside: true, k: 'void', zones: [[0, 1]] },
      pts: [[120, 262], [190, 258], [226, 224], [220, 174], [176, 154], [172, 112], [216, 84], [212, 40], [160, 24], [100, 30], [52, 50], [36, 100], [70, 140], [56, 186], [36, 230], [66, 260]],
      rivers: [
        { pts: [[150, 120], [290, 100]], w: 5, k: 'void', lanes: [[-4, 2.3], [4, 2.3]] },
        { pts: [[-30, 120], [64, 104]], w: 5, k: 'void', lanes: [[0, 3.2]] },
      ],
      pads: [[0.04, 0], [0.32, 0], [0.72, 0]], boxes: [0.14, 0.5, 0.86], ice: [], ramps: [], cut: [],
    },
    {
      name: '놀이공원', hint: '분홍 범퍼에 닿으면 통 튕겨 나가요. 점프대와 가속 패드!', sub: '통통 범퍼 · 점프대 · 가속 패드 잔치', th: 'park', kind: 'spline', half: 7.5, off: 'grass', wall: null, bumpers: true,
      pts: [[120, 270], [184, 266], [226, 236], [214, 196], [168, 186], [150, 150], [184, 120], [224, 96], [216, 46], [168, 26], [110, 34], [70, 30], [36, 60], [44, 110], [80, 140], [60, 182], [32, 220], [60, 262]],
      pads: [[0.1, -2.6], [0.1, 2.6], [0.42, 0], [0.64, -2.4], [0.88, 2.4]], boxes: [0.16, 0.5, 0.78], ice: [], ramps: [0.31, 0.7],
      pillars: [[0.22, 0, 1.8], [0.47, 3, 1.6], [0.56, -3, 1.6], [0.83, 0, 1.8]],
      cut: [{ a: 0.355, b: 0.455, bend: -4, hw: 3.2, s: 'road' }],
    },
    {
      name: '항구 크레인', hint: '크레인 컨테이너가 길을 가로질러 왔다 갔다 해요', sub: '움직이는 컨테이너 · 부두 끝은 바다 · 직각 부두', th: 'harbor', kind: 'poly', half: 7, off: 'yard', wall: null,
      water: { d: 4, inside: false, k: 'sea', zones: [] },
      pts: [[40, 40, 12], [140, 40, 12], [140, 70, 10], [230, 70, 14], [230, 250, 14], [150, 250, 12], [150, 200, 10], [90, 200, 10], [90, 250, 12], [40, 250, 14]],
      start: [90, 40], pads: [[0.3, 0], [0.62, 0]], boxes: [0.1, 0.46, 0.8], ice: [], ramps: [],
      movers: [[0.22, 4.6, 3.2, 2.4], [0.4, 4.6, 2.6, 2.4], [0.88, 4.6, 3.6, 2.4]],
      cut: [],
    },
    /* ----- round 7 tracks -----
       bouncy: walls kick you back (candy canes). syrup: [frac, lat, r] sticky puddles on the road.
       flow: [a, b, dir, force] sideways water current across the road between fractions a→b.
       gaps: [frac, w] holes across the road (fall → respawn); a spring pad just before each one launches you over.
       fog: [a, b] sandstorm bands (low visibility). traps: [frac, lat, r] sand pits that slow you and pull you in.
       train: {pts:[A, B], per, off, len, v} a train crossing on a fixed timetable from the race start.
       dark: cave darkness, only headlights (and lamps) light the way. rails: [a, b, lat] mine-cart rails = fast lane.
       slope: [a, b, ±1] downhill (faster) / uphill (slower) sections. */
    {
      name: '사탕 공장', hint: '주황 시럽 웅덩이는 끈적끈적, 사탕 벽은 통통 튕겨요', sub: '끈적한 시럽 웅덩이 · 통통 튀는 사탕 지팡이 벽', th: 'candy', kind: 'spline', half: 7.2, off: 'sugar', wall: 3.2, bouncy: true,
      pts: [[110, 262], [176, 262], [214, 240], [222, 200], [196, 170], [150, 160], [136, 128], [170, 100], [214, 84], [220, 46], [180, 26], [110, 28], [60, 36], [34, 70], [52, 110], [44, 150], [30, 196], [44, 240], [70, 260]],
      syrup: [[0.1, -2.8, 3.2], [0.3, 3, 3.3], [0.47, -2.6, 3.2], [0.6, 0.8, 3.5], [0.78, -2.8, 3.2], [0.9, 2.8, 3.1]],
      pads: [[0.2, 0], [0.7, 0]], boxes: [0.14, 0.42, 0.84], ice: [], ramps: [], cut: [],
    },
    {
      name: '해저 터널', hint: '파란 물살 구간에서는 해류가 차를 옆으로 밀어요', sub: '유리 터널 · 옆으로 미는 해류', th: 'sea', kind: 'spline', half: 7.4, off: 'road', wall: 1.6, deck: 'road',
      pts: [[120, 270], [190, 266], [228, 232], [230, 170], [214, 120], [226, 70], [196, 30], [136, 28], [96, 52], [100, 96], [130, 126], [118, 170], [70, 182], [38, 214], [50, 254], [84, 270]],
      flow: [[0.06, 0.15, 1, 15], [0.3, 0.38, -1, 15], [0.5, 0.58, 1, 16], [0.8, 0.88, -1, 15]],
      pads: [[0.25, 0], [0.68, 0]], boxes: [0.2, 0.45, 0.76], ice: [], ramps: [], cut: [],
    },
    {
      name: '구름 위 하늘길', hint: '끊긴 길 앞 노란 스프링 판을 밟으면 점프해서 건너요', sub: '끊긴 길은 스프링으로 점프 · 떨어지면 복귀', th: 'sky', kind: 'spline', half: 7.2, off: 'fluff', wall: null,
      water: { d: 2.6, inside: true, k: 'sky', zones: [[0, 1]] },
      pts: [[120, 268], [186, 262], [224, 226], [218, 176], [184, 150], [196, 110], [226, 74], [206, 32], [150, 24], [96, 34], [56, 62], [46, 110], [78, 146], [56, 190], [34, 232], [66, 264]],
      gaps: [[0.05, 4], [0.52, 4.2], [0.82, 4]], pads: [[0.3, 0], [0.62, 0]], boxes: [0.14, 0.4, 0.7], ice: [], ramps: [], cut: [],
    },
    {
      name: '모래폭풍 사막', hint: '모래폭풍 속에서는 앞이 흐려요. 소용돌이 구덩이 조심', sub: '앞이 안 보이는 모래폭풍 · 빨아들이는 모래 구덩이', th: 'storm', kind: 'spline', half: 7.5, off: 'sand', wall: null,
      pts: [[110, 270], [176, 268], [220, 246], [234, 196], [210, 150], [226, 100], [214, 52], [170, 28], [110, 30], [60, 34], [32, 72], [52, 116], [100, 128], [118, 166], [82, 196], [40, 212], [36, 250], [66, 270]],
      fog: [[0.12, 0.28], [0.52, 0.66]], traps: [[0.18, 2.6, 2.6], [0.24, -3, 2.6], [0.45, 0, 2.8], [0.58, 2.8, 2.5], [0.7, -2.6, 2.6], [0.84, 0, 2.6]], pads: [[0.33, 0], [0.92, 0]], boxes: [0.1, 0.45, 0.8], ice: [], ramps: [], cut: [],
    },
    {
      name: '기차 건널목', hint: '차단기가 내려오고 빨간 불이 깜빡이면 멈춰요. 기차!', sub: '정해진 시간마다 기차가 지나가요 · 차단기를 보세요', th: 'rail', kind: 'spline', half: 7, off: 'grass', wall: null,
      pts: [[110, 262], [180, 260], [222, 230], [226, 170], [214, 110], [222, 60], [190, 28], [120, 26], [66, 34], [36, 70], [40, 130], [34, 190], [46, 240], [74, 260]],
      train: { pts: [[-60, 51], [330, 225]], per: 9, off: 5, len: 50, v: 62 },
      pads: [[0.06, 0], [0.55, 0]], boxes: [0.12, 0.45, 0.8], ice: [], ramps: [], cut: [],
    },
    {
      name: '동굴 광산', hint: '어두운 갱도. 광차 레일 위에 똑바로 올라타면 빨라요', sub: '어두운 갱도 · 헤드라이트 · 광차 레일은 빠른 길', th: 'mine', kind: 'spline', half: 7.2, off: 'dirt', wall: 1.5, dark: true,
      pts: [[120, 266], [190, 262], [226, 228], [222, 168], [180, 150], [176, 110], [214, 82], [206, 36], [150, 24], [90, 30], [48, 52], [40, 104], [80, 128], [84, 170], [46, 196], [38, 240], [70, 264]],
      rails: [[0.45, 0.59, -3.6], [0.01, 0.09, 3.6], [0.15, 0.21, -3.4]], pads: [[0.34, 0], [0.72, 0]], boxes: [0.15, 0.48, 0.8], ice: [], ramps: [], cut: [],
    },
    {
      name: '벚꽃 산길', hint: '≫ 내리막은 빠르고 › 오르막은 느려요. 좁은 헤어핀!', sub: '좁은 헤어핀 · 내리막은 빠르고 오르막은 느려요', th: 'blossom', kind: 'spline', half: 5.8, off: 'grass', wall: null,
      pts: [[90, 252], [190, 252], [222, 238], [214, 214], [120, 208], [90, 190], [102, 166], [196, 160], [226, 140], [212, 116], [140, 110], [72, 110], [42, 128], [32, 200], [50, 240]],
      slope: [[0.03, 0.62, 1], [0.68, 0.95, -1]], pads: [[0.86, 0]], boxes: [0.1, 0.47, 0.8], ice: [], ramps: [], cut: [],
    },
    /* ----- round 8 tracks -----
       movers[k][4] = 'ball': a rolling ball instead of a crane container (round).
       sweep: [frac, side, len, period, blades] windmill sails turning over the road from a hub beside it (side ±1).
       bolts: {per, warn, n, r} lightning: every per s, n marked spots around the course flash for warn s, then strike.
       belts: [a, b, lat0, lat1, speed, dir] conveyor belts (dir 0 = forward, π = backward, ±π/2 = sideways).
       tide: {per, ph} the sandbar shortcut (cut.tide) is dry at low tide and under water (very slow) at high tide.
       doors: [frac, per, off] a divider splits the road in two lanes, each with a gate; the gates take turns opening.
       tunnels: [a, b] covered parts of the course (cut.tun = the cut runs through a tunnel). night: dark vignette. */
    {
      name: '장난감 방', hint: '커다란 공이 길을 가로질러 굴러다녀요. 책 점프대!', sub: '책 점프대 · 굴러오는 공 · 블록 탑', th: 'toy', kind: 'spline', half: 7.5, off: 'carpet', wall: null, deck: 'wood',
      pts: [[110, 266], [176, 266], [220, 244], [230, 200], [204, 172], [158, 170], [136, 146], [152, 116], [202, 108], [230, 78], [218, 38], [166, 24], [106, 32], [60, 28], [30, 60], [46, 100], [86, 118], [84, 158], [44, 178], [30, 224], [60, 258]],
      movers: [[0.142, 4.4, 2.8, 2, 'ball'], [0.392, 4.4, 3.3, 2, 'ball'], [0.874, 4.4, 3.0, 2, 'ball']],
      pillars: [[0.24, -3.6, 1.7], [0.6, 3.6, 1.7], [0.698, 0, 1.8]],
      pads: [[0.03, 0], [0.64, 0]], boxes: [0.19, 0.45, 0.78], ice: [], ramps: [0.08, 0.5], cut: [],
    },
    {
      name: '풍차 마을', hint: '풍차 날개가 길을 쓸어요. 풍차 반대쪽 가장자리가 안전해요', sub: '풍차 날개가 길을 쓸고 지나가요 · 운하 다리', th: 'windmill', kind: 'spline', half: 7, off: 'grass', wall: null,
      pts: [[110, 268], [180, 266], [222, 240], [228, 190], [206, 150], [220, 110], [214, 60], [180, 30], [124, 28], [74, 40], [40, 74], [48, 118], [90, 136], [100, 176], [64, 198], [36, 232], [62, 262]],
      rivers: [{ pts: [[-20, 92], [300, 88]], w: 4.5, k: 'river', lanes: [[0, 5.4]] }],
      sweep: [[0.18, 1, 2, 6.5, 4], [0.48, 1, 2.2, 5.8, 4], [0.856, 1, 2, 7, 4]],
      pads: [[0.06, 0], [0.58, 0]], boxes: [0.1, 0.41, 0.72], ice: [], ramps: [], cut: [],
    },
    {
      name: '번개 고원', hint: '노란 원이 깜빡이면 곧 번개! 원 밖으로 피하세요', sub: '밤비 · 표시된 곳에 번개가 떨어져요 · 젖은 길', th: 'thunder', kind: 'spline', half: 7.4, off: 'grass', wall: null, deck: 'wet', night: true,
      pts: [[120, 268], [188, 262], [226, 230], [232, 176], [206, 140], [214, 96], [234, 60], [208, 26], [150, 24], [104, 40], [70, 30], [36, 54], [34, 104], [66, 130], [70, 172], [42, 206], [48, 250], [80, 268]],
      bolts: { per: 4.2, warn: 1.7, n: 7, r: 3.6 },
      pads: [[0.3, 0], [0.75, 0]], boxes: [0.12, 0.45, 0.82], ice: [], ramps: [], cut: [],
    },
    {
      name: '물류 센터', hint: '노란 벨트는 빨라지고 빨간 벨트는 느려져요. 지게차 조심', sub: '컨베이어 벨트 · 지게차 · 직각 코너', th: 'factory', kind: 'poly', half: 7.5, off: 'road', wall: 1.5,
      pts: [[40, 40, 12], [230, 40, 12], [230, 150, 12], [170, 150, 10], [170, 110, 10], [110, 110, 10], [110, 190, 10], [230, 190, 12], [230, 262, 12], [40, 262, 12]],
      start: [90, 40],
      belts: [[0.03, 0.135, -7.5, 0, 9, 0], [0.48, 0.545, -7.5, 7.5, 8, 0], [0.66, 0.76, -7.5, 7.5, 9, 1.5708], [0.83, 0.95, 0, 7.5, 9, 3.1416]],
      movers: [[0.21, 4.6, 3.2, 2.3], [0.425, 4.6, 2.8, 2.3]],
      pads: [[0.33, 0]], boxes: [0.2, 0.46, 0.76], ice: [], ramps: [], cut: [],
    },
    {
      name: '바닷길 갯벌', hint: '물이 빠졌을 때만 바닷길 지름길이 빨라요(오른쪽 위 표시)', sub: '물이 빠지면 열리는 바닷길 지름길 · 바깥은 바다', th: 'tide', kind: 'spline', half: 7, off: 'mud', wall: null,
      water: { d: 3.5, inside: false, k: 'sea', zones: [] },
      pts: [[120, 270], [186, 266], [226, 240], [236, 190], [222, 140], [232, 90], [214, 44], [164, 26], [110, 30], [70, 48], [56, 84], [28, 96], [8, 122], [10, 156], [30, 180], [50, 200], [56, 232], [76, 262]],
      tide: { per: 22, ph: 2 },
      cut: [{ a: 0.62, b: 0.835, bend: 0, hw: 5, s: 'dirt', tide: 1 }],
      pads: [[0.2, 0], [0.45, 0]], boxes: [0.12, 0.38, 0.9], ice: [], ramps: [],
    },
    {
      name: '유령 저택', hint: '두 갈래 철문이 번갈아 열려요. 초록 불 쪽으로!', sub: '번갈아 열리는 철문 · 산울타리 벽 · 밤', th: 'haunt', kind: 'spline', half: 7.4, off: 'mud', wall: 2.4, night: true,
      pts: [[110, 268], [180, 266], [222, 244], [230, 196], [200, 166], [210, 128], [230, 96], [220, 48], [180, 28], [120, 30], [70, 30], [38, 58], [40, 104], [78, 124], [80, 164], [42, 188], [34, 232], [62, 262]],
      doors: [[0.12, 6, 0], [0.385, 6, 2], [0.535, 6, 4]],
      pads: [[0.3, 0], [0.66, 0]], boxes: [0.2, 0.45, 0.75], ice: [], ramps: [], cut: [],
    },
    {
      name: '오로라 빙하', hint: '길 전체가 미끄러운 얼음. 틈은 얼음 다리로만 건너요', sub: '미끄러운 얼음길 · 갈라진 틈은 얼음 다리로 · 밤', th: 'aurora', kind: 'spline', half: 7.6, off: 'snow', wall: null, deck: 'glacier', night: true,
      pts: [[120, 266], [190, 260], [228, 226], [226, 176], [190, 156], [184, 116], [222, 90], [220, 44], [176, 24], [116, 28], [66, 36], [36, 72], [52, 116], [94, 132], [96, 176], [56, 196], [36, 236], [70, 264]],
      rivers: [{ pts: [[160, 136], [300, 128]], w: 3.2, k: 'crevasse', lanes: [[-4.3, 3.6], [4.3, 3.6]] }, { pts: [[60, 150], [96, 155], [134, 150]], w: 3.2, k: 'crevasse', lanes: [[-4.3, 3.6], [4.3, 3.6]] }],
      pillars: [[0.12, 0, 1.6], [0.5, 2.8, 1.5]],
      pads: [[0.04, -3], [0.6, 0]], boxes: [0.16, 0.48, 0.78], ice: [], ramps: [], cut: [],
    },
    {
      name: '터널 고개', hint: '갈림길: 가속 패드 고갯길 또는 좁고 어두운 터널 지름길', sub: '갈림길: 산 넘는 고갯길 또는 좁은 터널 · 가드레일', th: 'tunnel', kind: 'spline', half: 7, off: 'grass', wall: 2.2,
      pts: [[110, 270], [184, 268], [224, 242], [232, 192], [220, 146], [230, 100], [222, 62], [198, 40], [190, 8], [162, -12], [128, -6], [118, 22], [100, 42], [62, 38], [34, 62], [34, 110], [60, 140], [52, 186], [30, 226], [56, 262]],
      cut: [{ a: 0.362, b: 0.585, bend: 0, hw: 4.4, s: 'road', tun: 1 }],
      tunnels: [[0.79, 0.86]],
      pads: [[0.42, 0], [0.5, 0]], boxes: [0.12, 0.4, 0.68, 0.9], ice: [], ramps: [],
    },
    /* ----- round 9 tracks: one new gimmick each -----
       twisters: [f0, v, amp, per] tornadoes travelling along the course (race clock). cranes: [frac, side, per, off] electromagnets.
       swing: [frac, w, per, off] a canal crossing with a swing bridge. portals: [fa, lat, fb, per, off] magic doors (fa → fb).
       disco: [a, b, per] three colour lanes (green fast / red slow) that rotate on the beat. plats: [frac, w, per, amp] molten
       channel crossed on two sliding platforms. turn: [frac, ω] turntables. mud: [frac, lat, len, wid] bogs, wash: [frac, lat, r]
       water splashes (mud on the car makes it slower until washed off).
       Round 9 additions to older tracks: slip (slipstream straights), rocks (falling boulders), balls (snowballs), traffic,
       waves, geysers, tiles (collapsing floor). */
    {
      name: '회오리 평원', hint: '회오리바람이 코스를 따라 움직여요. 가까이 가면 빨려 들어가요', sub: '움직이는 회오리바람 · 밀밭 · 넓은 평원', th: 'prairie', kind: 'spline', half: 7.5, off: 'grass', wall: null,
      pts: [[110, 272], [182, 268], [228, 240], [236, 190], [212, 152], [226, 108], [220, 60], [186, 30], [128, 26], [92, 48], [58, 40], [30, 68], [36, 118], [74, 140], [70, 186], [38, 214], [48, 256]],
      twisters: [[0.3, 10, 3.6, 7.3], [0.74, 11, 3.2, 6.1]],
      pads: [[0.12, 0], [0.56, 0]], boxes: [0.2, 0.47, 0.84], ice: [], ramps: [], cut: [],
    },
    {
      name: '고철 처리장', hint: '전자석 크레인에 파란 불이 켜지면 차를 끌어당겨요', sub: '전자석 크레인 · 고철 더미 · 자갈 갓길', th: 'scrap', kind: 'spline', half: 7.2, off: 'junk', wall: null,
      pts: [[100, 268], [176, 266], [222, 246], [230, 204], [196, 184], [150, 176], [130, 150], [150, 122], [204, 116], [230, 90], [222, 46], [180, 26], [118, 26], [70, 34], [40, 60], [46, 100], [84, 116], [92, 156], [60, 180], [34, 210], [48, 252]],
      cranes: [[0.1, 1, 5.5, 0], [0.33, -1, 5.5, 2], [0.55, 1, 5, 1], [0.8, -1, 6, 3]],
      pads: [[0.22, 0], [0.68, 0]], boxes: [0.16, 0.44, 0.9], ice: [], ramps: [], cut: [],
    },
    {
      name: '운하 도시', hint: '회전 다리: 초록 불일 때만 길과 이어져요. 빨간 불이면 기다려요', sub: '빙글 도는 다리 · 운하 · 직각 골목', th: 'canal', kind: 'poly', half: 7, off: 'yard', wall: null,
      pts: [[40, 40, 12], [220, 40, 14], [220, 140, 12], [150, 140, 12], [150, 190, 10], [220, 190, 12], [220, 262, 14], [40, 262, 14], [40, 160, 12], [96, 160, 10], [96, 104, 10], [40, 104, 12]],
      start: [90, 40], swing: [[0.12, 4, 10, 0], [0.62, 4, 10, 5]],
      pads: [[0.3, 0], [0.8, 0]], boxes: [0.06, 0.4, 0.7], ice: [], ramps: [], cut: [],
    },
    {
      name: '마법 도서관', hint: '빛나는 마법 문으로 들어가면 앞쪽 출구로 순간이동해요', sub: '마법 문 순간이동 · 책장 벽 · 구불구불 복도', th: 'library', kind: 'spline', half: 7, off: 'carpet', wall: 2, night: true,
      pts: [[110, 272], [180, 270], [224, 248], [232, 206], [200, 190], [176, 206], [150, 196], [150, 166], [186, 150], [226, 132], [230, 86], [206, 62], [176, 74], [150, 60], [150, 30], [110, 24], [64, 30], [36, 56], [42, 100], [78, 112], [84, 146], [52, 160], [32, 196], [40, 240], [66, 264]],
      portals: [[0.17, -3.4, 0.235, 7, 0], [0.47, 3.4, 0.53, 7, 2.3], [0.74, -3.4, 0.8, 7, 4.6]],
      pads: [[0.06, 0], [0.64, 0]], boxes: [0.1, 0.38, 0.92], ice: [], ramps: [], cut: [],
    },
    {
      name: '네온 디스코', hint: '초록 칸은 빨라지고 빨간 칸은 느려져요. 색은 박자마다 바뀌어요', sub: '빛나는 3색 바닥 · 네온 벽 · 밤', th: 'disco', kind: 'spline', half: 7.5, off: 'road', wall: 1.5, night: true,
      pts: [[100, 270], [190, 270], [228, 246], [234, 200], [206, 172], [206, 128], [234, 98], [226, 46], [186, 26], [116, 28], [74, 28], [40, 50], [34, 96], [64, 124], [64, 170], [34, 200], [38, 246], [62, 268]],
      disco: [[0.03, 0.14, 2.6], [0.3, 0.38, 2.6], [0.47, 0.57, 2.6], [0.72, 0.8, 2.6]],
      pads: [[0.22, 0], [0.64, 0]], boxes: [0.18, 0.42, 0.86], ice: [], ramps: [], cut: [],
    },
    {
      name: '제철소', hint: '쇳물 수로는 좌우로 움직이는 발판으로만 건너요', sub: '움직이는 발판 · 쇳물 수로 · 직각 공장', th: 'foundry', kind: 'poly', half: 7.4, off: 'ash', wall: 1.6,
      pts: [[40, 50, 14], [130, 50, 12], [130, 20, 10], [230, 20, 14], [230, 150, 12], [180, 150, 10], [180, 200, 10], [230, 200, 12], [230, 270, 14], [40, 270, 14], [40, 190, 12], [90, 190, 10], [90, 120, 10], [40, 120, 12]],
      start: [170, 270], plats: [[0.21, 4.2, 3.4, 1.8], [0.51, 4.2, 3, 1.8], [0.73, 4.2, 3.8, 1.8]],
      pads: [[0.12, 0], [0.62, 0]], boxes: [0.06, 0.38, 0.85], ice: [], ramps: [], cut: [],
    },
    {
      name: '시계탑 광장', hint: '회전판 위에서는 차가 같이 돌아가요. 반대로 꺾어 버티세요', sub: '빙글빙글 회전판 · 시계탑 · 돌 광장', th: 'clock', kind: 'spline', half: 7.6, off: 'yard', wall: null,
      pts: [[120, 270], [190, 266], [230, 236], [230, 186], [196, 162], [196, 118], [230, 92], [222, 44], [180, 24], [120, 30], [90, 60], [60, 36], [30, 64], [36, 116], [70, 138], [66, 184], [34, 210], [44, 252], [76, 270]],
      turn: [[0.09, 0.62], [0.3, -0.62], [0.47, 0.62], [0.73, -0.62]],
      pads: [[0.18, 0], [0.6, 0]], boxes: [0.24, 0.53, 0.84], ice: [], ramps: [], cut: [],
    },
    {
      name: '진흙 랠리', hint: '진흙탕을 지나면 차가 무거워져요. 물웅덩이에서 씻으세요', sub: '진흙탕 · 물웅덩이 세차 · 자갈길 · 점프', th: 'rally', kind: 'spline', half: 7.2, off: 'grass', wall: null, deck: 'gravel',
      pts: [[110, 272], [176, 270], [220, 252], [236, 210], [214, 176], [176, 170], [150, 146], [170, 118], [216, 108], [234, 72], [214, 36], [164, 24], [110, 34], [80, 62], [48, 48], [26, 80], [36, 124], [70, 138], [70, 180], [40, 206], [38, 246], [68, 268]],
      mud: [[0.17, 0, 9, 8.2], [0.32, -3.2, 7, 3.6], [0.47, 0, 9, 8.2], [0.6, 3.2, 7, 3.6], [0.76, 0, 9, 8.2]],
      wash: [[0.215, 3.6, 2.8], [0.515, -3.6, 2.8], [0.805, 3.6, 2.8], [0.93, -3.4, 2.8]],
      pads: [[0.4, 0], [0.88, 0]], boxes: [0.1, 0.36, 0.68], ice: [], ramps: [0.26], cut: [],
    },
    /* ----- round 12 tracks: one new gimmick each (positions as lap fractions) -----
       leaps: [frac, w] chasm across the road with a ramp before it — only a fast car clears it.
       ferry: [frac, wr, per] river crossing on two rafts (one per lane) that take turns; wr = half the river along the road.
       bank: [a, b] banked curves (outer lane fast, lots of grip). eight + flat: a same-level crossroads (cars meet!).
       herd: [frac, side, per, off, n] animals crossing; dusk: it gets darker every second (headlights).
       gusts: {zones, per, off, warn, on, f} side gusts on bridges. flags: [frac, lat, w] slalom gates (mini boost).
       hoops: [frac, amp, per] boost rings swinging across the road. seasons: lap 1 spring, 2 rain, 3 snow.
       shows: [frac, lat] market stands showing the item you get (it changes every few seconds).
       puds: [frac, lat, r] puddles: slow a little and spray the car right behind. dbr: [frac, per, off] drawbridges.
       craters: [frac, lat, r] moon craters (bump over the rim); lowg: longer, floatier jumps. */
    {
      name: '붉은 절벽', hint: '낭떠러지 앞 점프대: 빨리 달려야 건너요. 느리면 떨어져요', sub: '협곡을 건너는 점프 세 번 · 붉은 바위 벽', th: 'canyon', kind: 'spline', half: 7.2, off: 'sand', wall: 4,
      pts: [[110, 272], [190, 272], [228, 250], [236, 200], [234, 140], [228, 88], [206, 44], [158, 26], [110, 40], [88, 80], [100, 120], [72, 152], [38, 170], [30, 222], [52, 260]],
      leaps: [[0.07, 8.5], [0.28, 9], [0.48, 8.5]], pads: [[0.24, 0], [0.44, 0]], boxes: [0.15, 0.36, 0.7], ice: [], ramps: [], cut: [],
    },
    {
      name: '나루터 강', hint: '나룻배 두 척이 번갈아 강을 건너요. 기다리는 배 쪽 줄로!', sub: '강은 나룻배로 건너요 · 줄마다 배 한 척', th: 'river', kind: 'poly', half: 7, off: 'grass', wall: null,
      pts: [[40, 40, 14], [150, 40, 12], [150, 80, 10], [230, 80, 14], [230, 262, 14], [120, 262, 12], [120, 222, 10], [40, 222, 14]],
      start: [90, 40], ferry: [0.37, 13, 8], pads: [[0.12, 0], [0.62, 0]], boxes: [0.06, 0.48, 0.8], ice: [], ramps: [], cut: [],
    },
    {
      name: '루프 스타디움', hint: '기울어진 경사 커브는 바깥쪽이 빨라요. 고리 다리를 넘어요', sub: '경사 커브(뱅크) · 고리 모양 입체 교차 · 경기장', th: 'stadium', kind: 'spline', half: 7.4, off: 'grass', wall: 2, eight: true, gen: 'loop',
      pts: null, bank: [[0.08, 0.3], [0.62, 0.84]], pads: [[0.45, 0], [0.95, 0]], boxes: [0.04, 0.4, 0.55], ice: [], ramps: [], cut: [],
    },
    {
      name: '사거리 도심', hint: '같은 높이 사거리! 다른 차와 부딪힐 수 있어요. 신호를 보세요', sub: '평면 교차로 · 대각선 큰길 · 낮의 도시', th: 'metro', kind: 'poly', half: 7.4, off: 'road', wall: 1.4, eight: true, flat: true,
      pts: [[40, 40, 16], [230, 40, 16], [40, 250, 16], [230, 250, 16]],
      start: [120, 40], pads: [[0.3, 0], [0.8, 0]], boxes: [0.15, 0.42, 0.66, 0.92], ice: [], ramps: [], cut: [],
    },
    {
      name: '황혼 목장', hint: '양 떼가 길을 건너요! 점점 어두워지니 헤드라이트를 믿으세요', sub: '길을 건너는 양 떼 · 해가 지는 들판 · 나무 울타리', th: 'ranch', kind: 'spline', half: 7, off: 'grass', wall: null, dusk: true,
      pts: [[110, 249], [60, 246], [30, 216], [32, 86], [58, 54], [96, 59], [112, 97], [112, 164], [140, 190], [172, 164], [172, 97], [188, 59], [226, 54], [250, 86], [250, 216], [220, 246], [160, 251]],
      herd: [[0.15, 1, 9, 2, 3], [0.38, -1, 11, 5, 3], [0.57, 1, 10, 1, 4], [0.8, -1, 9.5, 4, 3]], pads: [[0.2, 0], [0.75, 0]], boxes: [0.05, 0.47, 0.9], ice: [], ramps: [], cut: [],
    },
    {
      name: '바람의 대교', hint: '바다 위 다리에서 옆바람! 바람 자루가 펄럭이면 반대로 버티세요', sub: '바다 위 긴 다리 · 옆으로 미는 돌풍 · 섬', th: 'bridge', kind: 'spline', half: 7.4, off: 'grass', wall: null,
      water: { d: 3, inside: false, k: 'sea', zones: [[0.1, 0.26], [0.58, 0.72]] },
      pts: [[100, 40], [200, 40], [240, 70], [244, 130], [230, 190], [236, 250], [200, 280], [120, 280], [70, 262], [40, 220], [44, 160], [30, 110], [44, 64]],
      gusts: { zones: [[0.1, 0.26], [0.58, 0.72]], per: 5.5, off: 3, warn: 1.3, on: 1.7, f: 16 },
      pads: [[0.38, 0], [0.85, 0]], boxes: [0.05, 0.44, 0.8], ice: [], ramps: [], cut: [],
    },
    {
      name: '스키 슬로프', hint: '깃발 사이로 지나가면 살짝 빨라져요. 내리막을 지그재그로!', sub: '깃발 회전 코스 · 눈 덮인 내리막 · 리프트', th: 'ski', kind: 'spline', half: 7.4, off: 'snow', wall: null, deck: 'pack',
      pts: [[100, 30], [190, 30], [226, 56], [220, 96], [160, 110], [110, 128], [90, 160], [130, 186], [200, 196], [226, 230], [200, 266], [120, 272], [60, 262], [30, 220], [34, 150], [30, 80], [54, 40]],
      flags: [[0.21, -3, 3.2], [0.24, 3, 3.2], [0.27, -3, 3.2], [0.39, 3, 3.2], [0.42, -3, 3.2], [0.45, 3, 3.2], [0.57, -3, 3.2], [0.6, 3, 3.2], [0.63, -3, 3.2], [0.66, 3, 3.2]],
      slope: [[0.02, 0.68, 1], [0.76, 0.94, -1]], pads: [[0.8, 0]], boxes: [0.1, 0.5, 0.86], ice: [], ramps: [], cut: [],
    },
    {
      name: '하늘 축제', hint: '좌우로 흔들리는 빛 고리를 통과하면 터보! 타이밍을 노려요', sub: '움직이는 부스트 고리 · 열기구 · 축제 들판', th: 'fest', kind: 'poly', half: 7.4, off: 'grass', wall: null,
      pts: null, star: [140, 150, 128, 64],
      hoops: [[0.05, 4.4, 3.2], [0.25, 4.6, 2.8], [0.45, 4.4, 3.6], [0.65, 4.6, 3], [0.85, 4.4, 3.4]], pads: [], boxes: [0.13, 0.53, 0.73], ice: [], ramps: [], cut: [],
    },
    {
      name: '계절 숲길', hint: '랩마다 계절이 바뀌어요: 봄 → 장맛비(미끄러움) → 눈길', sub: '1랩 봄 · 2랩 비 · 3랩 눈 · 숲속 굽잇길', th: 'season', kind: 'spline', half: 7, off: 'grass', wall: null, seasons: true,
      pts: [[110, 268], [178, 266], [220, 244], [232, 200], [204, 170], [160, 170], [140, 140], [162, 110], [214, 100], [230, 62], [204, 30], [150, 26], [100, 40], [60, 30], [30, 62], [40, 110], [70, 140], [60, 186], [34, 220], [56, 258]],
      pads: [[0.2, 0], [0.62, 0]], boxes: [0.1, 0.42, 0.74], ice: [], ramps: [], cut: [{ a: 0.465, b: 0.56, bend: 3, hw: 3.2, s: 'dirt' }],
    },
    {
      name: '야시장 골목', hint: '진열대 위 아이템 그림이 바뀌어요. 원하는 게 보일 때 지나가요', sub: '보이는 아이템을 고르는 진열대 · 등불 골목 · 밤', th: 'market', kind: 'poly', half: 6.8, off: 'road', wall: 1.4, night: true,
      pts: [[40, 40, 10], [150, 40, 9], [150, 90, 9], [220, 90, 10], [220, 170, 10], [160, 170, 9], [160, 230, 9], [220, 230, 10], [220, 272, 10], [40, 272, 10], [40, 180, 9], [100, 180, 9], [100, 120, 9], [40, 120, 9]],
      start: [90, 40], shows: [[0.2, -3.2], [0.2, 3.2], [0.47, -3.2], [0.47, 3.2], [0.74, -3.2], [0.74, 3.2]], pads: [[0.36, 0], [0.88, 0]], boxes: [0.08, 0.6], ice: [], ramps: [], cut: [],
    },
    {
      name: '얼음 호수', hint: '물웅덩이를 밟은 차 바로 뒤에 붙으면 물보라에 앞이 가려요', sub: '얼음 길 · 물보라 웅덩이 · 가운데는 차가운 호수', th: 'icelake', kind: 'spline', half: 7.4, off: 'snow', wall: null, deck: 'frozen',
      water: { d: 3, inside: true, k: 'sea', zones: [] },
      pts: [[110, 270], [186, 262], [226, 230], [222, 180], [196, 150], [214, 110], [232, 70], [206, 32], [150, 26], [96, 36], [56, 30], [30, 64], [44, 110], [80, 136], [70, 180], [38, 206], [42, 250], [72, 268]],
      puds: [[0.07, -2.6, 2.8], [0.2, 2.4, 3], [0.33, -2, 2.8], [0.45, 2.6, 2.8], [0.57, 0, 3], [0.7, -2.6, 2.8], [0.82, 2.4, 3], [0.93, -1, 2.8]],
      ice: [[0.24, 0.29], [0.62, 0.66]], pads: [[0.13, 0], [0.5, 0]], boxes: [0.04, 0.4, 0.76], ramps: [], cut: [],
    },
    {
      name: '도개교 항구', hint: '다리가 올라가는 중엔 점프로 건너요. 다 올라가면 기다려요', sub: '열리는 도개교 두 개 · 운하 · 항구 창고', th: 'port', kind: 'poly', half: 7.2, off: 'yard', wall: null,
      pts: [[40, 40, 14], [230, 40, 14], [230, 150, 12], [150, 150, 10], [150, 200, 10], [230, 200, 12], [230, 270, 14], [40, 270, 14]],
      start: [90, 40], dbr: [[0.245, 12, 0], [0.865, 12, 6]], pads: [[0.06, 0], [0.62, 0]], boxes: [0.28, 0.5, 0.92], ice: [], ramps: [], cut: [],
    },
    {
      name: '갈림길 계곡', hint: '갈림길 두 곳! 낭떠러지 점프 길과 안전한 다리 길 중에 골라요', sub: '세 갈래 길 · 점프 지름길 · 흔들다리', th: 'gorge', kind: 'spline', half: 7, off: 'grass', wall: null,
      pts: [[110, 272], [180, 270], [224, 246], [236, 196], [212, 160], [226, 110], [230, 60], [200, 30], [150, 26], [110, 50], [70, 34], [36, 56], [32, 108], [64, 134], [64, 180], [36, 214], [44, 256]],
      leaps: [[0.31, 8.5]], pads: [[0.27, 0], [0.62, 0]], boxes: [0.08, 0.45, 0.85], ice: [], ramps: [],
      cut: [{ a: 0.255, b: 0.37, bend: 16, hw: 3.4, s: 'wood' }, { a: 0.53, b: 0.7, bend: 0, hw: 3.6, s: 'dirt' }],
    },
    {
      name: '달 크레이터', hint: '달에서는 점프가 길고 둥실! 크레이터 가장자리에서 통 튀어요', sub: '저중력 · 크레이터 둔덕 · 먼지 바닥 · 우주', th: 'moon', kind: 'poly', half: 7.6, off: 'dust', wall: null, deck: 'moon', lowg: 1.8,
      pts: [[140, 8, 36], [282, 262, 36], [-2, 262, 36]], start: [140, 262],
      craters: [[0.1, 0, 3.6], [0.2, -2.6, 3], [0.39, 2.4, 3.2], [0.47, -2.2, 3], [0.72, 0, 3.6], [0.84, 2.6, 3]], pads: [[0.66, 0]], boxes: [0.15, 0.43, 0.9], ice: [], ramps: [0.33, 0.78], cut: [],
    },
    {
      name: '밤 고속도로', hint: '깜깜한 밤길, 헤드라이트만 보여요. 트럭 뒤 ≫ 바람막이를 타요', sub: '어두운 고속도로 · 트럭·차들 · 슬립스트림', th: 'hwy', kind: 'spline', half: 8, off: 'grass', wall: 1.6, dark: true,
      pts: [[100, 40], [230, 40], [262, 80], [262, 160], [240, 210], [252, 262], [212, 292], [110, 292], [60, 272], [40, 222], [52, 160], [30, 110], [44, 64]],
      traffic: { n: 6, v: 15 }, slip: [[0.02, 0.15], [0.28, 0.4], [0.55, 0.66]], pads: [[0.45, 0], [0.9, 0]], boxes: [0.08, 0.36, 0.7], ice: [], ramps: [], cut: [],
    },
  ];
  // figure eight (lemniscate) — crosses itself once; the second pass runs over a bridge
  (function () {
    const p = [];
    for (let k = 0; k < 20; k++) {
      const t = Math.PI / 2 + (k / 20) * Math.PI * 2;
      p.push([140 + 110 * Math.sin(2 * t) / 2 * 2, 160 + 140 * Math.cos(t)]);
    }
    // start on the long diagonal just after the top lobe
    TRACKS[5].pts = p.slice(3).concat(p.slice(0, 3));
    // loop stadium: a limaçon (big lobe with a small loop inside it) — crosses itself once, the loop climbs over
    for (const T of TRACKS) if (T.gen === 'loop') {
      T.pts = [];
      for (let k = 0; k < 30; k++) { const a = -Math.PI / 2 + (k / 30) * Math.PI * 2, r = 60 + 122 * Math.cos(a); T.pts.push([36 + r * Math.cos(a), 152 + r * Math.sin(a) * 0.95]); }
    }
    // festival: a five-point star (tight tips, wide inner corners); start on the lowest edge
    for (const T of TRACKS) if (T.star) {
      const [cx, cy, R0, R1] = T.star;
      T.pts = [];
      for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + (k / 10) * Math.PI * 2, r = k % 2 ? R1 : R0; T.pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a), k % 2 ? 12 : 9]); }
      let best = 0;
      for (let k = 0; k < 10; k++) { const q = T.pts[k], q2 = T.pts[(k + 1) % 10]; if (q[1] + q2[1] > T.pts[best][1] + T.pts[(best + 1) % 10][1]) best = k; }
      T.start = [(T.pts[best][0] + T.pts[(best + 1) % 10][0]) / 2, (T.pts[best][1] + T.pts[(best + 1) % 10][1]) / 2];
    }
  })();

  /* ---------- 생성 코스 (procedural courses, 코스 옵션 「무작위 생성」) ----------
     track id ≥ GEN0 → the course is rebuilt from its seed (id − GEN0) on every device; the state only carries the number.
     A closed Catmull-Rom loop through jittered control points around an ellipse, plus hairpins (deep pinches toward
     the middle), chicanes (an S pair inserted on a long side) and long straights (collinear points). Each try is checked
     and re-rolled deterministically (own PRNG, never Math.random) until: length 700–1150, every corner radius ≥ 10,
     no part of the road (with its run-off) comes near another part, fits a phone-shaped box, a straight for the start.
     Then: narrow sections, a shortcut across a bend, a jump ramp, boost pads, item rows and theme patches (ice, cracks). */
  const GEN0 = 100000, GEN_N = 899999;
  const GTH = [
    { k: 'city', n: '도시 야간', th: 'city', deck: 'road', off: 'yard', wall: 1.4, night: true, cs: 'road', tip: '밤거리: 불빛 근처만 보여요. ≫ 직선에선 앞차 뒤에 붙으면 빨라져요',
      words: ['네온 순환로', '야경 고가길', '빌딩 숲길', '자정 골목길', '불빛 대로', '전광판 거리'] },
    { k: 'desert', n: '사막', th: 'desert', deck: 'road', off: 'sand', wall: null, cs: 'dirt', tip: '모래 갓길은 아주 느려요. 갈라진 길은 조금 느려요',
      words: ['모래바람길', '신기루 고개', '선인장 굽이', '붉은 모래길', '오아시스길', '사구 능선길'] },
    { k: 'snow', n: '설산', th: 'snow', deck: 'pack', off: 'snow', wall: null, cs: 'ice', tip: '눈길이라 조금 미끄럽고 파란 빙판은 훨씬 미끄러워요',
      words: ['눈보라 고개', '빙벽 굽이길', '설원 순환로', '서리 능선길', '얼음 골짜기', '눈꽃 능선'] },
    { k: 'coast', n: '해안 절벽', th: 'beach', deck: 'road', off: 'sand', wall: null, cs: 'dirt', water: true, tip: '바깥은 절벽 아래 바다! 떨어지면 잠깐 뒤 복귀해요',
      words: ['파도 절벽길', '등대 해안길', '바닷바람길', '갈매기 고개', '물보라 굽이', '해넘이 절벽'] },
    { k: 'forest', n: '숲', th: 'forest', deck: 'gravel', off: 'mud', wall: null, cs: 'wood', tip: '자갈 숲길이라 조금 덜 붙어요. 길 밖 진흙은 느려요',
      words: ['이끼 숲길', '고목 오솔길', '안개 숲길', '솔방울 굽이', '부엉이 숲길', '단풍 숲길'] },
  ];
  const genCache = {};
  const GEN_STAT = { tries: 0, ok: 0, why: {} };
  function mulberry(a) { return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const isGen = (id) => (id | 0) >= GEN0;
  const normId = (id) => (isGen(id) ? id | 0 : U.clamp(id | 0, 0, TRACKS.length - 1));
  const trackDef = (id) => (isGen(id) ? genDef((id | 0) - GEN0) : TRACKS[normId(id)]);
  const genTheme = (D) => GTH.find((g) => g.k === D.gen) || GTH[0];
  /* centreline of a course definition, resampled to NS points by arc length (shared by buildTrack and the generator) */
  function denseLoop(D) {
    let [dx, dy] = D.kind === 'poly' ? polyDense(D.pts) : splineDense(D.pts);
    if (D.start) { // rotate so the start line sits at D.start
      let bi = 0, bd = 1e18;
      for (let i = 0; i < dx.length; i++) { const d = (dx[i] - D.start[0]) ** 2 + (dy[i] - D.start[1]) ** 2; if (d < bd) { bd = d; bi = i; } }
      dx = dx.slice(bi).concat(dx.slice(0, bi)); dy = dy.slice(bi).concat(dy.slice(0, bi));
    }
    const m = dx.length, cum = [0];
    for (let i = 1; i <= m; i++) { const j = i % m; cum.push(cum[i - 1] + Math.hypot(dx[j] - dx[i - 1], dy[j] - dy[i - 1])); }
    const len = cum[m], ds = len / NS;
    const x = new Float64Array(NS), y = new Float64Array(NS), tx = new Float64Array(NS), ty = new Float64Array(NS);
    const nx = new Float64Array(NS), ny = new Float64Array(NS), curv = new Float64Array(NS), hd = new Float64Array(NS);
    let seg = 0;
    for (let i = 0; i < NS; i++) {
      const s = i * ds;
      while (seg < m - 1 && cum[seg + 1] < s) seg++;
      const f = (s - cum[seg]) / ((cum[seg + 1] - cum[seg]) || 1);
      const a = seg, b = (seg + 1) % m;
      x[i] = dx[a] + (dx[b] - dx[a]) * f; y[i] = dy[a] + (dy[b] - dy[a]) * f;
    }
    for (let i = 0; i < NS; i++) {
      const a = (i - 1 + NS) % NS, b = (i + 1) % NS;
      let ux = x[b] - x[a], uy = y[b] - y[a];
      const l = Math.hypot(ux, uy) || 1; ux /= l; uy /= l;
      tx[i] = ux; ty[i] = uy; nx[i] = -uy; ny[i] = ux; hd[i] = Math.atan2(uy, ux);
    }
    for (let i = 0; i < NS; i++) { const a = (i - 1 + NS) % NS, b = (i + 1) % NS; curv[i] = wrapA(hd[b] - hd[a]) / (2 * ds); }
    const acurv = new Float64Array(NS);
    for (let i = 0; i < NS; i++) { let s = 0; for (let k = -2; k <= 2; k++) s += Math.abs(curv[(i + k + NS) % NS]); acurv[i] = s / 5; }
    return { x, y, tx, ty, nx, ny, curv, acurv, hd, len, ds };
  }
  function genDef(seed) {
    seed = ((seed | 0) % GEN_N + GEN_N) % GEN_N;
    if (genCache[seed]) return genCache[seed];
    const G = GTH[seed % GTH.length];
    let D = null;
    for (let a = 0; a < 80 && !D; a++) { GEN_STAT.tries++; D = genTry(mulberry(seed * 977 + a * 7919 + 13), G, seed); }
    if (D) GEN_STAT.ok++;
    else D = genTry(mulberry(seed), G, seed, true); // practically never: a plain round course
    const keys = Object.keys(genCache); if (keys.length > 8) delete genCache[keys[0]];
    return (genCache[seed] = D);
  }
  function genTry(r, G, seed, plain) {
    const rej = (w) => { GEN_STAT.why[w] = (GEN_STAT.why[w] || 0) + 1; return null; };
    const half = Math.round((6.5 + r() * 1.1) * 10) / 10, wet = G.water ? 3.5 : 0;
    const K = plain ? 10 : 8 + Math.floor(r() * 4), RX = 110 + r() * 28, RY = 140 + r() * 32, cx = 150, cy = 170;
    const wts = []; let ws = 0;
    for (let k = 0; k < K; k++) { const w = plain ? 1 : 0.55 + r(); wts.push(w); ws += w; }
    let ang = r() * Math.PI * 2;
    const P = [];
    for (let k = 0; k < K; k++) { ang += wts[k] / ws * Math.PI * 2; P.push({ a: ang, rad: plain ? 1 : 0.62 + r() * 0.38 }); }
    let nh = 0;
    if (!plain) { // hairpins: a tongue of road reaching into the middle — in along one side, a U-turn, back along the other
      const want = G.water ? 0 : r() < 0.8 ? 1 + (r() < 0.4 ? 1 : 0) : 0, used = [];
      for (let t = 0; t < 6 && nh < want; t++) {
        const k = Math.floor(r() * K);
        if (used.some((u) => Math.min((u - k + K) % K, (k - u + K) % K) < 2)) continue;
        used.push(k); P[k].hp = 50 + r() * 22; P[k].rad = Math.max(P[k].rad, 0.9); nh++;
      }
    }
    const base = plain ? [[cx - 60, cy - 120], [cx, cy - 135], [cx + 60, cy - 120], [cx + 70, cy - 60], [cx + 70, cy + 60], [cx + 60, cy + 120], [cx, cy + 135], [cx - 60, cy + 120], [cx - 70, cy + 60], [cx - 70, cy - 60]]
      : [].concat(...P.map((p) => {
        const px = cx + Math.cos(p.a) * RX * p.rad, py = cy + Math.sin(p.a) * RY * p.rad;
        if (!p.hp) return [[px, py]];
        let tx2 = -Math.sin(p.a) * RX, ty2 = Math.cos(p.a) * RY; const tl = Math.hypot(tx2, ty2); tx2 /= tl; ty2 /= tl;
        const ux = -ty2, uy = tx2, w = 15, c = 18, d = p.hp; // u points into the loop (travel is counter-clockwise here)
        const at2 = (a, b, l) => [px + tx2 * a + ux * b, py + ty2 * a + uy * b, l == null ? 1 : l]; // shape checked for radius ≥ 12
        return [at2(-w - c, 0, 2), at2(-w, c), at2(-w, d), at2(0, d + 10), at2(w, d), at2(w, c), at2(w + c, 0, 2)];
      }));
    const pts = [];
    let nStr = 0, nChi = 0;
    const lock = []; // hairpin points are kept as they are by the repair below
    for (let k = 0; k < base.length; k++) {
      const p = base[k], q = base[(k + 1) % base.length], L2 = Math.hypot(q[0] - p[0], q[1] - p[1]);
      pts.push([p[0], p[1]]); lock.push(p[2] === 1 ? 1 : 0);
      if (plain || p[2] || q[2]) continue;
      const ux = (q[0] - p[0]) / L2, uy = (q[1] - p[1]) / L2;
      if (L2 > 70 && nStr < 2 && r() < 0.45) { nStr++; for (const t of [0.3, 0.7]) { pts.push([p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t]); lock.push(0); } }
      else if (L2 > 58 && nChi < 2 && r() < 0.4) { // chicane: a quick left-right
        nChi++; const o = (6 + r() * 3) * (r() < 0.5 ? 1 : -1);
        pts.push([p[0] + (q[0] - p[0]) * 0.33 - uy * o, p[1] + (q[1] - p[1]) * 0.33 + ux * o]);
        pts.push([p[0] + (q[0] - p[0]) * 0.67 + uy * o, p[1] + (q[1] - p[1]) * 0.67 - ux * o]); lock.push(0, 0);
      }
    }
    if (r() < 0.5) { pts.reverse(); lock.reverse(); }
    // repair: bends tighter than the minimum radius get their control points eased toward their neighbours
    for (let it = 0; it < 10; it++) {
      const [dx, dy] = splineDense(pts), m = dx.length, n = pts.length, bad = new Uint8Array(n);
      let any = false;
      for (let i = 0; i < m; i++) {
        const a = (i - 2 + m) % m, b = (i + 2) % m, l = Math.hypot(dx[b] - dx[i], dy[b] - dy[i]) + Math.hypot(dx[i] - dx[a], dy[i] - dy[a]);
        const t = Math.abs(wrapA(Math.atan2(dy[b] - dy[i], dx[b] - dx[i]) - Math.atan2(dy[i] - dy[a], dx[i] - dx[a])));
        if (t / (l / 2 || 1) > 1 / 10.5) { const k = Math.round(i / 24) % n; bad[k] = 1; any = true; }
      }
      if (!any) break;
      const q = pts.map((p) => p.slice());
      for (let k = 0; k < n; k++) if (bad[k] && !lock[k]) { const a = pts[(k - 1 + n) % n], b = pts[(k + 1) % n]; q[k][0] += ((a[0] + b[0]) / 2 - pts[k][0]) * 0.35; q[k][1] += ((a[1] + b[1]) / 2 - pts[k][1]) * 0.35; }
      for (let k = 0; k < n; k++) pts[k] = q[k];
    }
    // ---- validation ----
    let g = denseLoop({ kind: 'spline', pts });
    if (g.len < 700 || g.len > 1150) return rej('length');
    let mx = 0; for (let i = 0; i < NS; i++) mx = Math.max(mx, g.acurv[i]);
    if (mx > 1 / 10) return rej('radius');
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let i = 0; i < NS; i++) { x0 = Math.min(x0, g.x[i]); y0 = Math.min(y0, g.y[i]); x1 = Math.max(x1, g.x[i]); y1 = Math.max(y1, g.y[i]); }
    if (x1 - x0 > 300 || y1 - y0 > 370 || x1 - x0 < 120) return rej('shape');
    const clr = (2 * (half + wet) + 9) ** 2, gap = Math.ceil(60 / g.ds);
    for (let i = 0; i < NS; i += 2) for (let j = i + gap; j < NS; j += 2) {
      if (NS - (j - i) < gap) continue;
      if ((g.x[i] - g.x[j]) ** 2 + (g.y[i] - g.y[j]) ** 2 < clr) return rej('overlap');
    }
    // start: on the longest straight, 30% along it (the grid sits behind the line, the rest of the straight ahead)
    let bs = -1, bn = 0;
    for (let i = 0; i < NS; i++) {
      if (g.acurv[i] >= 0.012 || g.acurv[(i - 1 + NS) % NS] < 0.012) continue;
      let n = 0; while (n < NS && g.acurv[(i + n) % NS] < 0.012) n++;
      if (n > bn) { bn = n; bs = i; }
    }
    if (bs < 0 || bn * g.ds < 45) return rej('nostraight');
    const si = (bs + Math.floor(bn * 0.3)) % NS;
    const start = [g.x[si], g.y[si]];
    g = denseLoop({ kind: 'spline', pts, start });
    const ds = g.ds, F = (i) => (((i % NS) + NS) % NS) / NS;
    // ---- layout on the validated course ----
    const runs = []; // straights after the start
    for (let i = 1; i < NS; i++) {
      if (g.acurv[i] >= 0.014 || g.acurv[i - 1] < 0.014) continue;
      let n = 0; while (i + n < NS && g.acurv[i + n] < 0.014) n++;
      if (n * ds >= 40) runs.push([i, i + n]);
    }
    let hp = 0; // hairpins actually on the course: a bend turning more than ~140°
    for (let i = 0; i < NS; i++) {
      if (g.acurv[i] < 0.035 || g.acurv[(i - 1 + NS) % NS] >= 0.035) continue;
      let n = 0, tt = 0; while (n < NS && g.acurv[(i + n) % NS] >= 0.035) { tt += g.curv[(i + n) % NS] * ds; n++; }
      if (Math.abs(tt) > 2.45) hp++;
    }
    const busy = new Uint8Array(NS), mark = (a, b) => { for (let i = a; i <= b; i++) busy[((i % NS) + NS) % NS] = 1; };
    mark(-Math.round(30 / ds), Math.round(40 / ds)); // the start straight stays plain and wide
    const free = (a, b) => { for (let i = a; i <= b; i++) if (busy[((i % NS) + NS) % NS]) return false; return true; };
    // narrow sections (the road pinches, then widens again)
    const narrow = [];
    const nn = plain ? 0 : r() < 0.75 ? 1 + (r() < 0.45 ? 1 : 0) : 0;
    for (let t = 0; t < 12 && narrow.length < nn; t++) {
      const a = Math.floor(NS * (0.12 + r() * 0.74)), n = Math.round(NS * (0.05 + r() * 0.04));
      if (!free(a - 14, a + n + 14)) continue;
      narrow.push([F(a), F(a + n), Math.round((0.7 + r() * 0.13) * 100) / 100]); mark(a - 10, a + n + 10);
    }
    // item rows, boost pads, a jump ramp on a long straight
    const boxes = [];
    for (const f0 of [0.14, 0.45, 0.76]) {
      let f = f0 + (r() - 0.5) * 0.08;
      for (let t = 0; t < 20 && !free(Math.round(f * NS) - 4, Math.round(f * NS) + 4); t++) f += 0.012;
      boxes.push(Math.round(f * 1000) / 1000); mark(Math.round(f * NS) - 6, Math.round(f * NS) + 6);
    }
    const pads = [], ramps = [];
    const rr2 = runs.slice().sort((A, B) => (B[1] - B[0]) - (A[1] - A[0]));
    for (const [a, b] of rr2) {
      const m = Math.round((a + b) / 2);
      if (!ramps.length && !plain && (b - a) * ds > 60 && r() < 0.5 && free(m - 16, m + 22)) { ramps.push(F(m)); mark(m - 16, m + 22); continue; }
      if (pads.length < 2 && free(m - 3, m + 3)) { pads.push([F(m), [0, -2.4, 2.4][Math.floor(r() * 3)]]); mark(m - 5, m + 5); }
    }
    for (let t = 0; t < 20 && pads.length < 2; t++) { const i = Math.floor(NS * (0.1 + r() * 0.8)); if (g.acurv[i] < 0.03 && free(i - 3, i + 3)) { pads.push([F(i), 0]); mark(i - 5, i + 5); } }
    // theme patches
    const ice = [], rough = [], slip = [];
    const patch = (list, n, lenF, maxC) => {
      for (let t = 0; t < 30 && list.length < n; t++) {
        const a = Math.floor(NS * (0.1 + r() * 0.8)), l = Math.round(NS * lenF);
        let ok = free(a - 2, a + l + 2); for (let i = a; i <= a + l && ok; i++) if (g.acurv[i % NS] > maxC) ok = false;
        if (ok) { list.push([F(a), F(a) + l / NS]); mark(a, a + l); }
      }
    };
    if (G.k === 'snow') patch(ice, 2, 0.035, 0.03);
    if (G.k === 'desert') patch(rough, 2, 0.05, 0.05);
    if (G.k === 'city') for (const [a, b] of rr2.slice(0, 2)) slip.push([F(a), F(a) + (b - a) / NS]);
    // shortcut across a bend: a straight line between two road points far apart along the road but close as the crow flies
    const cut = [];
    if (!plain && r() < 0.85) {
      const hw = 3.2;
      const inPoly = (px, py) => { let ins = false; for (let a = 0, b = NS - 1; a < NS; b = a++) if ((g.y[a] > py) !== (g.y[b] > py) && px < (g.x[b] - g.x[a]) * (py - g.y[a]) / (g.y[b] - g.y[a]) + g.x[a]) ins = !ins; return ins; };
      for (let t = 0; t < 60 && !cut.length; t++) {
        const i = Math.floor(NS * (0.08 + r() * 0.7)), sp = 50 + Math.floor(r() * 50), j = i + sp; // ≤ 100 samples: the lap still counts
        if (j > NS * 0.93) continue;
        const d = Math.hypot(g.x[j] - g.x[i], g.y[j] - g.y[i]);
        if (d < 26 || d > 0.55 * sp * ds) continue;
        let ok = true;
        for (let u = 0.16; u <= 0.84 && ok; u += 0.04) {
          const px = g.x[i] + (g.x[j] - g.x[i]) * u, py = g.y[i] + (g.y[j] - g.y[i]) * u;
          for (let k = 0; k < NS && ok; k += 2) if (idxDist(k, i) * ds > 18 && idxDist(k, j) * ds > 18 && (px - g.x[k]) ** 2 + (py - g.y[k]) ** 2 < (half + hw + 3) ** 2) ok = false;
        }
        if (!ok) continue;
        if (G.water && !inPoly((g.x[i] + g.x[j]) / 2, (g.y[i] + g.y[j]) / 2)) continue; // never out over the sea
        cut.push({ a: F(i), b: F(j), bend: 0, hw, s: G.cs });
      }
    }
    // hazard patches on the road (never across the whole road: there is always a clean line beside them)
    const hz = [];
    if (!plain) {
      const kinds = { city: ['oil', 'pud'], desert: ['mud', 'oil'], snow: ['ice', 'pud'], coast: ['pud', 'oil'], forest: ['mud', 'pud'] }[G.k] || ['mud', 'oil'];
      const want = 2 + (r() < 0.5 ? 1 : 0);
      for (let t = 0; t < 40 && hz.length < want; t++) {
        const i = Math.floor(NS * (0.1 + r() * 0.82));
        if (!free(i - 5, i + 5)) continue;
        const rad = Math.round((2.2 + r() * 1) * 10) / 10, side = r() < 0.5 ? -1 : 1, lat = Math.round(side * (half - rad - 0.4 - r() * 1.2) * 10) / 10;
        hz.push([F(i), lat, rad, kinds[hz.length % kinds.length]]); mark(i - 8, i + 8);
      }
    }
    const nm = G.words[Math.floor(r() * G.words.length)];
    const feat = [hp ? '헤어핀 ' + hp : '', nChi ? '시케인 ' + nChi : '', narrow.length ? '좁은 길 ' + narrow.length : '', cut.length ? '지름길' : '', ramps.length ? '점프대' : '', hz.length ? '위험 구간 ' + hz.length : ''].filter(Boolean);
    return {
      name: nm, gen: G.k, seed, hp, chi: nChi, sub: G.n + ' · 생성 코스' + (feat.length ? ' · ' + feat.join(' · ') : ''),
      hint: G.tip, th: G.th, kind: 'spline', half, off: G.off, wall: G.wall, deck: G.deck === 'road' ? undefined : G.deck, night: !!G.night,
      water: G.water ? { d: wet, inside: false, zones: [] } : undefined,
      pts, start, pads, boxes, ice, rough, slip, ramps, cut, narrow, hz,
    };
  }

  /* ---------- track geometry (pure) ---------- */
  function splineDense(P) {
    const n = P.length, SUB = 24, dx = [], dy = [];
    for (let i = 0; i < n; i++) {
      const p0 = P[(i - 1 + n) % n], p1 = P[i], p2 = P[(i + 1) % n], p3 = P[(i + 2) % n];
      for (let k = 0; k < SUB; k++) {
        const t = k / SUB, t2 = t * t, t3 = t2 * t;
        for (let c = 0; c < 2; c++) {
          const v = 0.5 * (2 * p1[c] + (-p0[c] + p2[c]) * t + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3);
          (c ? dy : dx).push(v);
        }
      }
    }
    return [dx, dy];
  }
  /* closed polygon with filleted corners ([x, y, radius]) */
  function polyDense(P) {
    const n = P.length, dx = [], dy = [];
    for (let i = 0; i < n; i++) {
      const p0 = P[(i - 1 + n) % n], p1 = P[i], p2 = P[(i + 1) % n], r = p1[2] || 8;
      let ax = p1[0] - p0[0], ay = p1[1] - p0[1], bx = p2[0] - p1[0], by = p2[1] - p1[1];
      const la = Math.hypot(ax, ay) || 1, lb = Math.hypot(bx, by) || 1;
      ax /= la; ay /= la; bx /= lb; by /= lb;
      const turn = wrapA(Math.atan2(by, bx) - Math.atan2(ay, ax));
      const t = r * Math.tan(Math.abs(turn) / 2);
      const sx = p1[0] - ax * t, sy = p1[1] - ay * t, sg = turn > 0 ? 1 : -1;
      const cx = sx - ay * r * sg, cy = sy + ax * r * sg;
      const a0 = Math.atan2(sy - cy, sx - cx), K = 10;
      for (let k = 0; k <= K; k++) { const a = a0 + turn * k / K; dx.push(cx + Math.cos(a) * r); dy.push(cy + Math.sin(a) * r); }
    }
    return [dx, dy];
  }
  /* distance from a point to an open polyline */
  function segDist(P, px, py) {
    let best = 1e18;
    for (let k = 0; k < P.length - 1; k++) {
      const ax = P[k][0], ay = P[k][1], bx = P[k + 1][0] - ax, by = P[k + 1][1] - ay;
      const t = U.clamp(((px - ax) * bx + (py - ay) * by) / (bx * bx + by * by || 1), 0, 1);
      const d = (px - ax - bx * t) ** 2 + (py - ay - by * t) ** 2;
      if (d < best) best = d;
    }
    return Math.sqrt(best);
  }
  /* crane container: lateral offset at race time t (s) */
  const moverLat = (m, t) => m.amp * Math.sin((t / m.per) * Math.PI * 2 + m.ph);
  /* level crossing timetable (race clock t, s): front of the train along the rail, or null when no train is out */
  const TRAIN_W = 2.4;
  function trainFront(Tn, t) { if (!(t >= Tn.off)) return null; const f = ((t - Tn.off) % Tn.per) * Tn.v; return f <= Tn.L + Tn.len + 20 ? f : null; }
  const trainPass = (Tn, t) => Math.floor((t - Tn.off) / Tn.per);
  /* is crossing X (part of the road) covered by the train at time t? */
  function trainOcc(Tn, X, t) { const f = trainFront(Tn, t); return f != null && f >= X.s - X.mr && f - Tn.len <= X.s + X.mr; }
  /* round 8 timed gimmicks — all driven by the shared race clock so every device sees the same thing */
  const BOLT_OFF = 3, DOOR_DIV = 16, DIV_W = 0.55, SAIL_W = 0.75;
  /* integer hash → [0, 1) (identical on every JS engine, unlike sin tricks) */
  function hash01(a, b) { let h = (Math.imul(a | 0, 374761393) + Math.imul(b | 0, 668265263)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16; return (h >>> 0) / 4294967296; }
  /* lightning: wave index and time into the wave (null before the first wave) */
  function boltPhase(B, t) { if (!(t >= B.off)) return null; const k = Math.floor((t - B.off) / B.per); return { k, tau: t - B.off - k * B.per }; }
  function boltSpots(tr, k) {
    const B = tr.bolt;
    if (B.k === k && B.spots) return B.spots;
    const spots = [];
    for (let j = 0; j < B.n; j++) {
      const f = (j + 0.15 + 0.7 * hash01(k * 7 + tr.id, j * 2 + 1)) / B.n, i = Math.floor(f * NS) % NS;
      const lat = (hash01(k * 7 + tr.id, j * 2 + 2) * 2 - 1) * (tr.half - 2.6);
      spots.push({ i, lat, x: tr.x[i] + tr.nx[i] * lat, y: tr.y[i] + tr.ny[i] * lat });
    }
    B.k = k; B.spots = spots;
    return spots;
  }
  /* tide level 0 (low) … 1 (high); the sandbar is under water above 0.5 */
  const tideLvl = (tr, t) => (tr.tide ? 0.5 - 0.5 * Math.cos(((t + tr.tide.ph) / tr.tide.per) * Math.PI * 2) : 0);
  /* gates: left lane (−normal) open for the first 55 % of each period, right lane from 45 % — always at least one open */
  function doorOpen(d, sd, t) { const ph = ((((t + d.off) % d.per) + d.per) % d.per) / d.per; return sd < 0 ? ph < 0.55 : ph >= 0.45; }
  const sailAng = (S, k, t) => S.ph + S.w * t + (k * Math.PI * 2) / S.n;
  /* would a car at lateral offset `lat` level with the hub touch a sail at time t? */
  function sailHits(S, t, lat) {
    const rin = S.o - S.sd * lat;
    if (rin > S.len + RAD) return false;
    const inA = Math.atan2(-S.sd * S.ny0, -S.sd * S.nx0), win = Math.atan2(RAD + SAIL_W + 0.7, Math.max(0.5, rin));
    for (let k = 0; k < S.n; k++) if (Math.abs(wrapA(sailAng(S, k, t) - inA)) < win) return true;
    return false;
  }
  /* ----- round 9 timed gimmicks (all from the shared race clock, so every device sees the same thing) ----- */
  const TILE_L = 7, TILE_WARN = 0.9, TILE_HOLE = 1.7, TILE_PER = 3.4;
  const TW_CORE = 2.6, TW_PULL = 10, MAG_R = 9, MAG_WARN = 0.9, PORT_R = 2.5, GEY_WARN = 1.3, GEY_ON = 1.0, GEY_R = 2.7;
  const BALL_V = 11, BALL_WARN = 1.4, SLUSH_T = 3, SW_OPEN = 0.56, SW_ROT = 1.1, SW_BW = 4.4;
  const ease = (x) => x * x * (3 - 2 * x);
  /* falling rocks: wave k drops n boulders — a shadow for `warn` s, then the boulder blocks that spot for `life` s */
  function rockWave(tr, k) {
    const R = tr.rock, C = R.waves;
    if (C[k]) return C[k];
    const out = [];
    for (let j = 0; j < R.n; j++) {
      const f = 0.08 + 0.86 * ((j + 0.1 + 0.8 * hash01(k * 5 + 17, j * 3 + tr.id)) / R.n), i = Math.floor(f * NS) % NS;
      const sd = hash01(k * 5 + 19, j * 3 + 2) < 0.5 ? -1 : 1, lat = sd * (tr.half - 2.2 - hash01(k * 5 + 18, j) * 3);
      out.push({ i, lat, x: tr.x[i] + tr.nx[i] * lat, y: tr.y[i] + tr.ny[i] * lat });
    }
    C[k] = out;
    for (const q in C) if (+q < k - 8 || +q > k + 8) delete C[q];
    return out;
  }
  const rockT0 = (R, k) => R.off + k * R.per; // the shadow appears; the rock lands warn s later
  /* snowball: roll k, tau = s since it set off (negative while the warning arrow blinks), its lateral position and size */
  function ballAt(B, t) {
    const u = t - B.off;
    if (!(u >= -BALL_WARN)) return null;
    const k = Math.floor((u + BALL_WARN) / B.per), tau = u - k * B.per, dur = (2 * B.L) / BALL_V;
    if (tau > dur + SLUSH_T) return null;
    const q = U.clamp(tau / dur, 0, 1);
    return { k, tau, dur, lat: B.side * B.L * (1 - 2 * q), r: 1.5 + 1.3 * q, rolling: tau >= 0 && tau <= dur };
  }
  /* city traffic car k at time t (writes into `o`) */
  function trafficCar(tr, k, t, o) {
    const F = tr.traffic, s = (((tr.len * (0.12 + (0.78 * k) / F.n) + F.v * Math.max(0, t)) % tr.len) + tr.len) % tr.len;
    const fi = s / tr.ds, i = Math.floor(fi) % NS, j = (i + 1) % NS, f = fi - Math.floor(fi);
    const L0 = (k % 2 ? 1 : -1) * tr.half * 0.48, sw = k % 3 === 1 ? U.clamp(Math.sin(((t + k * 2.3) / 9) * Math.PI * 2) * 2.5, -1, 1) : 1;
    const a = tr.hd[i] + wrapA(tr.hd[j] - tr.hd[i]) * f, lat = L0 * sw;
    o.i = i; o.s = s; o.lat = lat; o.a = a; o.k = k;
    o.x = tr.x[i] + (tr.x[j] - tr.x[i]) * f - Math.sin(a) * lat; o.y = tr.y[i] + (tr.y[j] - tr.y[i]) * f + Math.cos(a) * lat;
    return o;
  }
  function trafficCars(tr, t) {
    const F = tr.traffic;
    if (F.t !== t) { F.t = t; for (let k = 0; k < F.n; k++) trafficCar(tr, k, t, F.cars[k] || (F.cars[k] = {})); }
    return F.cars;
  }
  /* beach waves: a foam line sweeps across zone z every per s (direction alternates); returns its lateral position */
  function waveFront(tr, z, t) {
    const V = tr.waves, u = t - V.off - (z - 1) * 1.7;
    if (u < 0) return null;
    const k = Math.floor(u / V.per), tau = u - k * V.per, L = tr.half + 9, sd = k % 2 ? 1 : -1, f = sd * (L - V.v * tau);
    return Math.abs(f) <= L ? { f, sd, k } : null;
  }
  /* lava geyser: 0 quiet, 1 bubbling (warning), 2 erupting */
  function geyS(g, t) { const u = t - g.off; if (u < 0) return 0; const tau = u - Math.floor(u / g.per) * g.per; return tau < GEY_WARN ? 1 : tau < GEY_WARN + GEY_ON ? 2 : 0; }
  const geyK = (g, t) => Math.floor((t - g.off) / g.per);
  /* collapsing floor tile (section S, row r, column q): 0 solid, 1 cracking, 2 hole.
     Each time the floor crumbles, the front rows drop in one column and the back rows in another (maybe the same),
     so there is always at least one column that holds all the way through. */
  function tileState(tr, S, r, q, t) {
    const u = t - 2 - S.k * 1.1 - r * 0.12;
    if (u < 0) return 0;
    const k = Math.floor(u / TILE_PER), tau = u - k * TILE_PER, h1 = hash01(k * 31 + S.k * 7 + 3, tr.id), h2 = hash01(k * 17 + S.k * 5 + 1, tr.id + 9);
    if (h1 > 0.85) return 0; // now and then the floor holds
    const a = Math.floor(h1 / 0.85 * 3), b = (a + Math.floor(h2 * 2)) % 3, m = h2 * 2 % 1 < 0.5 ? 2 : 3;
    if ((r < m ? a : b) !== q) return 0;
    return tau < TILE_WARN ? 1 : tau < TILE_WARN + TILE_HOLE ? 2 : 0;
  }
  /* tornado: travels along the course and weaves from side to side */
  function twPos(tr, T, t) {
    const s = (((T.s0 + T.v * Math.max(0, t)) % tr.len) + tr.len) % tr.len, fi = s / tr.ds, i = Math.floor(fi) % NS, j = (i + 1) % NS, f = fi - Math.floor(fi);
    const lat = T.amp * Math.sin((t / T.per) * Math.PI * 2 + T.ph);
    return { i, s, lat, x: tr.x[i] + (tr.x[j] - tr.x[i]) * f + tr.nx[i] * lat, y: tr.y[i] + (tr.y[j] - tr.y[i]) * f + tr.ny[i] * lat };
  }
  /* electromagnet: 0 off, 1 about to switch on, 2 on (pulls) */
  function magS(m, t) { const u = t - m.off; if (u < 0) return 0; const tau = u - Math.floor(u / m.per) * m.per; return tau < m.per * 0.5 ? 2 : tau > m.per - MAG_WARN ? 1 : 0; }
  /* swing bridge angle (0 = lined up with the road) */
  function swingAng(S, t) {
    const tau = ((((t + S.off) % S.per) + S.per) % S.per), o = S.per * SW_OPEN, back = S.per - SW_ROT - 0.3;
    if (tau < o) return 0;
    if (tau < o + SW_ROT) return (Math.PI / 2) * ease((tau - o) / SW_ROT);
    if (tau < back) return Math.PI / 2;
    if (tau < back + SW_ROT) return (Math.PI / 2) * (1 - ease((tau - back) / SW_ROT));
    return 0;
  }
  const swingOK = (S, lat, t) => swingAng(S, t) < 0.12 && Math.abs(lat) < SW_BW;
  const portOn = (P, t) => ((((t + P.off) % P.per) + P.per) % P.per) < P.per * 0.62;
  /* disco lane colour: 0 green (fast), 1 violet, 2 red (slow); the colours step one lane over on every beat */
  const discoCol = (d, q, t) => (q + Math.floor(Math.max(0, t + d.off) / d.per)) % 3;
  /* river lanes: logs / bridges are fixed, foundry platforms slide from side to side */
  const laneAt = (R, L2, t) => L2[0] + (R.mv ? R.mv.amp * Math.sin((t / R.mv.per) * Math.PI * 2 + R.mv.ph) : 0);
  const FROST_R = 6.5, FROST_FLY = 0.6, SMOKE_R = 6.5, WARP_D = 34;
  const carR = (c) => (c.giant > 0 ? RAD * 1.5 : RAD);
  /* ----- round 12 timed gimmicks (race clock → same on every device) ----- */
  const FER_LR = 11, FER_PIER = 0.6, DB_W = 7, DB_UP = 1.25, DB_RISE = 1.5, DB_JUMP = 0.75;
  const HERD_V = 6, HERD_R = 1.25, HERD_WARN = 1.4, HERD_GAP = 0.45, VORT_R = 6.5, SHOW_PER = 2.4;
  /* ferry raft k (one per lane, half a period apart): position along the river (0 = middle), speed, docked near / far */
  function raftAt(F, k, t) {
    const P = F.per, u = ((((t + (k * P) / 2) % P) + P) % P), a0 = -F.wr + FER_LR / 2, a1 = F.wr - FER_LR / 2;
    const Dn = P * 0.42, Tm = P * 0.18, Df = P * 0.16, Tb = P - Dn - Tm - Df;
    if (u < Dn) return { p: a0, v: 0, near: true, far: false, wait: 0, left: Dn - u };
    if (u < Dn + Tm) { const q = (u - Dn) / Tm; return { p: a0 + (a1 - a0) * ease(q), v: ((a1 - a0) * 6 * q * (1 - q)) / Tm, near: false, far: false, wait: P - u }; }
    if (u < Dn + Tm + Df) return { p: a1, v: 0, near: false, far: true, wait: P - u };
    const q = (u - Dn - Tm - Df) / Tb;
    return { p: a1 + (a0 - a1) * ease(q), v: ((a0 - a1) * 6 * q * (1 - q)) / Tb, near: false, far: false, wait: P - u };
  }
  /* car position in a gimmick's own frame (along the road / across it) */
  function frameOf(P2, c) { const ex = c.x - P2.x, ey = c.y - P2.y, ca = Math.cos(P2.a), sa = Math.sin(P2.a); return { al: ex * ca + ey * sa, lt: -ex * sa + ey * ca, ca, sa }; }
  /* drawbridge leaves: 0 = down … DB_UP = standing up */
  function dbAng(B, t) {
    const P = B.per, u = ((((t + B.off) % P) + P) % P), o = P * 0.55;
    if (u < o) return 0;
    if (u < o + DB_RISE) return DB_UP * ease((u - o) / DB_RISE);
    if (u < P - DB_RISE) return DB_UP;
    return DB_UP * (1 - ease((u - P + DB_RISE) / DB_RISE));
  }
  /* animals crossing: crossing k, time into it (negative while the warning sign blinks) */
  function herdAt(Hd, t) {
    const u = t - Hd.off;
    if (!(u >= -HERD_WARN)) return null;
    const k = Math.floor((u + HERD_WARN) / Hd.per), tau = u - k * Hd.per, dur = (2 * Hd.L) / HERD_V + (Hd.n - 1) * HERD_GAP;
    return tau > dur ? null : { k, tau, dur };
  }
  function herdLat(Hd, j, tau) { const q = ((tau - j * HERD_GAP) * HERD_V) / (2 * Hd.L); return q <= 0 || q >= 1 ? null : Hd.side * Hd.L * (1 - 2 * q); }
  const herdAl = (Hd, j) => (j - (Hd.n - 1) / 2) * 2.7;
  /* side gusts: warning, then a push (direction picked per gust) */
  function gustAt(G, t) {
    const u = t - G.off;
    if (u < 0) return null;
    const k = Math.floor(u / G.per), tau = u - k * G.per;
    return tau > G.warn + G.on ? null : { k, tau, on: tau >= G.warn, dir: hash01(k * 13 + 5, 77) < 0.5 ? -1 : 1 };
  }
  const hoopLat = (H, t) => H.amp * Math.sin((t / H.per) * Math.PI * 2 + H.ph);
  /* market stands: the item on show changes every SHOW_PER s */
  const SHOW_POOL = ['turbo3', 'rocket', 'shield', 'homing', 'frost', 'giant', 'warp', 'boom', 'net', 'ghost', 'balloon', 'auto', 'fw', 'paint', 'bees', 'bomb', 'drone', 'blow', 'magnet', 'mirror', 'hop', 'tire'];
  const showK = (b, t) => Math.floor(Math.max(0, t) / SHOW_PER + b.id * 0.37);
  const showItem = (b, t) => SHOW_POOL[Math.floor(hash01(showK(b, t), b.id * 7 + 3) * SHOW_POOL.length)];
  const cache = {};
  function buildTrack(id) {
    id = normId(id);
    if (cache[id]) return cache[id];
    if (isGen(id)) { const ks = Object.keys(cache).filter((k) => isGen(+k)); if (ks.length > 3) delete cache[ks[0]]; }
    const D = trackDef(id);
    const { x, y, tx, ty, nx, ny, curv, acurv, hd, len, ds } = denseLoop(D);
    let area = 0;
    for (let i = 0; i < NS; i++) { const j = (i + 1) % NS; area += x[i] * y[j] - x[j] * y[i]; }
    const T = {
      id, D, name: D.name, half: D.half, wall: D.wall, off: D.off, x, y, tx, ty, nx, ny, curv, acurv, hd, len, ds,
      inSide: area > 0 ? 1 : -1, cuts: [], ice: new Uint8Array(NS), pads: [], boxes: [], ramps: [], cross: null,
    };
    const at = (f, lat) => { const i = ((Math.round(f * NS) % NS) + NS) % NS; return { i, x: x[i] + nx[i] * lat, y: y[i] + ny[i] * lat, a: hd[i] }; };
    for (const [a, b] of D.ice || []) for (let i = Math.round(a * NS); i < Math.round(b * NS); i++) T.ice[((i % NS) + NS) % NS] = 1;
    for (const [f, lat] of D.pads || []) T.pads.push(at(f, lat));
    for (const f of D.ramps || []) T.ramps.push(at(f, 0));
    let bid = 0;
    for (const f of D.boxes || []) for (let k = 0; k < 4; k++) { const b = at(f, (k - 1.5) * D.half * 0.42); b.id = bid++; T.boxes.push(b); }
    for (const [f, lat] of D.shows || []) { const b = at(f, lat); b.id = bid++; b.show = true; T.boxes.push(b); } // market stands (synced like boxes)
    // shortcuts: dense samples along the cut with a progress index interpolated between its two ends
    for (const C0 of D.cut || []) {
      const C = Object.assign({}, C0);
      if (!C.pts) { // bowed path between the two centreline points
        const A = at(C.a, 0), B = at(C.b, 0), mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2;
        let px = -(B.y - A.y), py = B.x - A.x; const pl = Math.hypot(px, py) || 1; px /= pl; py /= pl;
        C.pts = [];
        for (let k = 0; k <= 8; k++) { const t = k / 8, bow = 4 * t * (1 - t) * (C.bend || 0); C.pts.push([A.x + (B.x - A.x) * t + px * bow, A.y + (B.y - A.y) * t + py * bow]); }
      }
      const near = (p) => { let bi = 0, bd = 1e18; for (let i = 0; i < NS; i++) { const d = (x[i] - p[0]) ** 2 + (y[i] - p[1]) ** 2; if (d < bd) { bd = d; bi = i; } } return bi; };
      const ia = near(C.pts[0]), ib = near(C.pts[C.pts.length - 1]);
      const span = ((ib - ia) % NS + NS) % NS;
      const sx = [], sy = [];
      for (let k = 0; k < C.pts.length - 1; k++) {
        const p = C.pts[k], q = C.pts[k + 1], l = Math.hypot(q[0] - p[0], q[1] - p[1]), K = Math.max(1, Math.ceil(l));
        for (let j = 0; j < K; j++) { sx.push(p[0] + (q[0] - p[0]) * j / K); sy.push(p[1] + (q[1] - p[1]) * j / K); }
      }
      const lp = C.pts[C.pts.length - 1]; sx.push(lp[0]); sy.push(lp[1]);
      const n = sx.length, si = new Int32Array(n);
      for (let k = 0; k < n; k++) si[k] = (ia + Math.round(span * k / (n - 1))) % NS;
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      for (let k = 0; k < n; k++) { x0 = Math.min(x0, sx[k]); y0 = Math.min(y0, sy[k]); x1 = Math.max(x1, sx[k]); y1 = Math.max(y1, sy[k]); }
      const turn = Math.abs(wrapA(Math.atan2(sy[Math.min(n - 1, 4)] - sy[0], sx[Math.min(n - 1, 4)] - sx[0]) - hd[ia]));
      T.cuts.push({ sx, sy, si, n, hw: C.hw, turn, s: C.s, ia, ib, tide: !!C.tide, tun: !!C.tun, span, bb: [x0 - C.hw - 8, y0 - C.hw - 8, x1 + C.hw + 8, y1 + C.hw + 8] });
    }
    // self-crossing (figure eight): the later pass is a bridge over the earlier one
    if (D.eight) {
      let bd = 1e18, bi = 0, bj = 0;
      for (let i = 0; i < NS; i++) for (let j = i + NS / 4; j < NS; j++) {
        if (idxDist(i, j) < NS / 4) continue;
        const d = (x[i] - x[j]) ** 2 + (y[i] - y[j]) ** 2;
        if (d < bd) { bd = d; bi = i; bj = j; }
      }
      T.cross = { under: bi, over: bj, x: x[bi], y: y[bi] };
      if (D.flat) { T.xing = { i: bi, j: bj, x: (x[bi] + x[bj]) / 2, y: (y[bi] + y[bj]) / 2 }; T.cross = null; } // same-level crossroads
    }
    // which side of each sample is the infield (+1 = +normal side)
    T.side = new Int8Array(NS);
    for (let i = 0; i < NS; i++) {
      const gx = x[i] + nx[i] * 3, gy = y[i] + ny[i] * 3;
      let ins = false;
      for (let a = 0, b = NS - 1; a < NS; b = a++) if ((y[a] > gy) !== (y[b] > gy) && gx < (x[b] - x[a]) * (gy - y[a]) / (y[b] - y[a]) + x[a]) ins = !ins;
      T.side[i] = ins ? 1 : -1;
    }
    // cracked / rough road
    T.rough = new Uint8Array(NS);
    for (const [a, b] of D.rough || []) for (let i = Math.round(a * NS); i < Math.round(b * NS); i++) T.rough[((i % NS) + NS) % NS] = 1;
    // rivers / gaps crossing the course: only the lanes (logs, bridges) are solid inside the band
    T.rivers = (D.rivers || []).map((R) => ({ pts: R.pts, w: R.w, k: R.k, lanes: R.lanes }));
    // sky road: holes straight across the road (no lanes at all) with a spring pad just before each one
    T.springs = [];
    for (const [f, w] of D.gaps || []) {
      const p = at(f, 0), Lh = D.half + (D.water ? D.water.d : 0) + 8;
      T.rivers.push({ pts: [[p.x - nx[p.i] * Lh, p.y - ny[p.i] * Lh], [p.x + nx[p.i] * Lh, p.y + ny[p.i] * Lh]], w, k: 'gap', lanes: [] });
      T.springs.push(Object.assign(at(f - (w + 3.4) / len, 0), { w }));
    }
    /* round 12: chasms with a jump ramp, the ferry and drawbridges; no respawning on their run-ups (T.nr) */
    T.nr = new Uint8Array(NS);
    const noRes = (i0, i1) => { for (let i = i0; i <= i1; i++) T.nr[((i % NS) + NS) % NS] = 1; };
    T.leaps = [];
    for (const [f, w] of D.leaps || []) {
      const p = at(f, 0), Lh = D.half + (D.wall || 0) + 10, r = at(f - (w / 2 + 3) / len, 0);
      T.rivers.push({ pts: [[p.x - nx[p.i] * Lh, p.y - ny[p.i] * Lh], [p.x + nx[p.i] * Lh, p.y + ny[p.i] * Lh]], w: w / 2, k: 'chasm', lanes: [] });
      r.w = w; T.leaps.push(r);
      noRes(r.i - Math.round(46 / ds), p.i + Math.round((w / 2 + 2) / ds));
    }
    T.fer = null;
    if (D.ferry) { const [f, wr, per] = D.ferry, p = at(f, 0); T.fer = Object.assign(p, { wr, per }); noRes(p.i - Math.round((wr + 6) / ds), p.i + Math.round((wr + 2) / ds)); }
    T.dbr = (D.dbr || []).map(([f, per, off], k) => { const p = at(f, 0); noRes(p.i - Math.round(16 / ds), p.i + Math.round(9 / ds)); return Object.assign(p, { wr: DB_W, per, off, k }); });
    // canal swing bridges and foundry channels: bands straight across the road
    for (const [f, w, per, off] of D.swing || []) {
      const p = at(f, 0), Lh = D.half + 16;
      T.rivers.push({ pts: [[p.x - nx[p.i] * Lh, p.y - ny[p.i] * Lh], [p.x + nx[p.i] * Lh, p.y + ny[p.i] * Lh]], w, k: 'canal', lanes: [], sw: { i: p.i, x: p.x, y: p.y, a: p.a, per, off, w } });
    }
    (D.plats || []).forEach(([f, w, per, amp], k) => {
      const p = at(f, 0), Lh = D.half + (D.wall || 0) + 0.5;
      T.rivers.push({ pts: [[p.x - nx[p.i] * Lh, p.y - ny[p.i] * Lh], [p.x + nx[p.i] * Lh, p.y + ny[p.i] * Lh]], w, k: 'molten', ci: p.i, lanes: [[-3.7, 2.6], [3.7, 2.6]], mv: { amp, per, ph: k * 1.3 } });
    });
    // candy syrup puddles and desert sand pits: circles on the road
    T.syrup = (D.syrup || []).map(([f, lat, r]) => Object.assign(at(f, lat), { r, lat }));
    T.traps = (D.traps || []).map(([f, lat, r]) => Object.assign(at(f, lat), { r, lat }));
    // course hazard patches: [frac, lat, r, kind] kind mud (slow) · ice (no grip) · pud (puddle, a little slow) · oil (slides, nudges the nose)
    T.hzs = (D.hz || []).map(([f, lat, r, k]) => Object.assign(at(f, lat), { r, lat, k }));
    T.hzAvoid = T.syrup.concat(T.traps, T.hzs);
    const band = (list, arr, val) => { for (const q of list || []) for (let i = Math.round(q[0] * NS); i < Math.round(q[1] * NS); i++) arr[((i % NS) + NS) % NS] = val(q); };
    // undersea currents (signed sideways force), sandstorm fog, mine rails (lateral offset), slopes (+1 down / -1 up)
    T.flow = new Float32Array(NS); band(D.flow, T.flow, (q) => q[2] * q[3]);
    T.fog = new Uint8Array(NS); band(D.fog, T.fog, () => 1);
    T.railLat = new Float32Array(NS).fill(NaN); band(D.rails, T.railLat, (q) => q[2]);
    T.slope = new Int8Array(NS); band(D.slope, T.slope, (q) => q[2]);
    // level crossing: the rail line, and where the course crosses it
    T.trains = [];
    if (D.train) {
      const R = D.train, A = R.pts[0], B2 = R.pts[1], Lr = Math.hypot(B2[0] - A[0], B2[1] - A[1]), ux = (B2[0] - A[0]) / Lr, uy = (B2[1] - A[1]) / Lr;
      const Tn = { ax: A[0], ay: A[1], ux, uy, nx: -uy, ny: ux, L: Lr, per: R.per, off: R.off, len: R.len, v: R.v, cross: [] };
      for (let i = 0; i < NS; i++) {
        const j = (i + 1) % NS, s0 = (x[i] - A[0]) * Tn.nx + (y[i] - A[1]) * Tn.ny, s1 = (x[j] - A[0]) * Tn.nx + (y[j] - A[1]) * Tn.ny;
        if ((s0 < 0) === (s1 < 0)) continue;
        const sn = Math.max(0.3, Math.abs(tx[i] * Tn.nx + ty[i] * Tn.ny)); // sine of the crossing angle
        Tn.cross.push({ i, s: (x[i] - A[0]) * ux + (y[i] - A[1]) * uy, mr: D.half / sn + RAD + 1, sn });
      }
      T.trains.push(Tn);
    }
    T.rv = new Int8Array(NS); // 1 + river index where the centreline is inside (or near) a band
    for (let i = 0; i < NS; i++) T.rivers.forEach((R, k) => { if (segDist(R.pts, x[i], y[i]) < R.w + 1.2) T.rv[i] = k + 1; });
    // pillars / bumpers on the road
    T.pil = (D.pillars || []).map(([f, lat, r]) => Object.assign(at(f, lat), { r, lat }));
    // crane containers swinging across the road (or rolling balls / forklifts)
    T.mov = (D.movers || []).map(([f, amp, per, r, shape], k) => Object.assign(at(f, 0), { amp, per, r, ph: k * 1.7, ball: shape === 'ball', hx: shape === 'ball' ? r : r * 0.75, hy: shape === 'ball' ? r : r * 1.25 }));
    // windmill sails: hub beside the road (side 1 = outside the loop), sails reach `reach` past the centreline
    T.sw = (D.sweep || []).map(([f, side, reach, per, n], k) => {
      const p = at(f, 0), sd = -T.side[p.i] * side, o = D.half + 2.8;
      return Object.assign(p, { o, sd, nx0: nx[p.i], ny0: ny[p.i], hx: p.x + nx[p.i] * sd * o, hy: p.y + ny[p.i] * sd * o, len: o + reach, w: Math.PI * 2 / per * (k % 2 ? -1 : 1), n, ph: k * 0.9 });
    });
    for (const S of T.sw) T.pil.push({ i: S.i, x: S.hx, y: S.hy, a: S.a, r: 2.6, lat: S.sd * S.o, mill: true }); // the mill towers are solid
    // lightning plateau
    T.bolt = D.bolts ? Object.assign({ off: BOLT_OFF, k: -1, spots: null }, D.bolts) : null;
    // conveyor belts
    T.belts = (D.belts || []).map(([a, b, l0, l1, sp, dir]) => ({ a, b, l0, l1, sp, dir }));
    T.belt = new Int8Array(NS); band(D.belts, T.belt, (q) => D.belts.indexOf(q) + 1);
    // tide (sandbar shortcut)
    T.tide = D.tide || null;
    // gates: a divider of DOOR_DIV world units before each door line splits the road into two lanes
    T.doors = (D.doors || []).map(([f, per, off]) => { const p = at(f, 0); return Object.assign(p, { per, off, i0: (p.i - Math.round(DOOR_DIV / ds) + NS) % NS }); });
    // tunnels on the course
    T.tun = new Uint8Array(NS); band(D.tunnels, T.tun, () => 1);
    /* ----- round 9 gimmicks ----- */
    T.slip = new Uint8Array(NS); band(D.slip, T.slip, () => 1);
    T.rock = D.rocks ? Object.assign({ waves: {} }, D.rocks) : null;
    T.balls = (D.balls || []).map(([f, side, per, off], k) => Object.assign(at(f, 0), { side, per, off, k, L: D.half + 8 }));
    T.traffic = D.traffic ? { n: D.traffic.n, v: D.traffic.v, t: null, cars: [] } : null;
    T.waves = D.waves ? Object.assign({}, D.waves) : null;
    T.wav = new Int8Array(NS);
    if (D.waves) D.waves.zones.forEach(([a, b], k) => { for (let i = Math.round(a * NS); i < Math.round(b * NS); i++) T.wav[((i % NS) + NS) % NS] = k + 1; });
    T.gey = (D.geysers || []).map(([f, lat, per, off], k) => Object.assign(at(f, lat), { lat, per, off, k }));
    T.tiles = []; T.pit = new Uint8Array(NS); // collapsing floor: rows of TILE_L along the course, 3 columns across
    (D.tiles || []).forEach(([a, b], k) => {
      const i0 = Math.round(a * NS), rows = Math.max(1, Math.floor(((Math.round(b * NS) - i0) * ds) / TILE_L));
      T.tiles.push({ i0, rows, k });
      for (let q = -1; q <= Math.ceil((rows * TILE_L) / ds) + 1; q++) T.pit[(i0 + q + NS) % NS] = k + 1;
    });
    T.tw = (D.twisters || []).map(([f0, v, amp, per], k) => ({ s0: f0 * len, v, amp, per, ph: k * 2.1, k }));
    T.mag = (D.cranes || []).map(([f, side, per, off], k) => { const lat = side * (D.half - 2.2); return Object.assign(at(f, lat), { lat, side, per, off, k }); });
    T.ports = (D.portals || []).map(([fa, lat, fb, per, off], k) => { const A = at(fa, lat), B2 = at(fb, lat); return Object.assign(A, { lat, j: B2.i, ex: B2.x, ey: B2.y, per, off, k }); });
    T.dsc = new Int8Array(NS);
    T.disco = (D.disco || []).map(([a, b, per], k) => { const i0 = Math.round(a * NS), i1 = Math.round(b * NS); for (let i = i0; i < i1; i++) T.dsc[i % NS] = k + 1; return { i0, i1, per, off: k * 0.9 }; });
    T.turn = (D.turn || []).map(([f, w], k) => Object.assign(at(f, 0), { w, R: D.half + 1.2, k }));
    T.bogs = (D.mud || []).map(([f, lat, lx, ly]) => Object.assign(at(f, lat), { lat, lx, ly }));
    T.wash = (D.wash || []).map(([f, lat, r]) => Object.assign(at(f, lat), { lat, r }));
    /* ----- round 12 gimmicks ----- */
    T.bank = new Int8Array(NS); // +1 / -1: which side is the high (outer, fast) side of a banked curve
    band(D.bank, T.bank, () => 1);
    for (let i = 0; i < NS; i++) if (T.bank[i]) { let s2 = 0; for (let k = -6; k <= 6; k++) s2 += curv[(i + k + NS) % NS]; T.bank[i] = s2 > 0 ? -1 : 1; }
    T.herd = (D.herd || []).map(([f, side, per, off, n], k) => Object.assign(at(f, 0), { side, per, off, n, k, L: D.half + 5 }));
    T.gust = D.gusts ? Object.assign({}, D.gusts) : null;
    T.gzone = new Uint8Array(NS); if (D.gusts) band(D.gusts.zones, T.gzone, () => 1);
    T.flags = (D.flags || []).map(([f, lat, w], k) => Object.assign(at(f, lat), { lat, w, k }));
    T.hoops = (D.hoops || []).map(([f, amp, per], k) => Object.assign(at(f, 0), { amp, per, ph: k * 1.9, k }));
    T.puds = (D.puds || []).map(([f, lat, r]) => Object.assign(at(f, lat), { lat, r }));
    T.crat = (D.craters || []).map(([f, lat, r], k) => Object.assign(at(f, lat), { lat, r, k }));
    T.lowg = D.lowg || 1;
    T.hwA = null;
    if (D.narrow && D.narrow.length) {
      T.hwA = new Float32Array(NS).fill(D.half);
      for (const [a, b, f] of D.narrow) {
        const i0 = Math.round(a * NS), n = ((Math.round(b * NS) - i0) % NS + NS) % NS, tp = 12;
        for (let q = -tp; q <= n + tp; q++) {
          const e = q < 0 ? 1 + q / tp : q > n ? 1 - (q - n) / tp : 1, k = 0.5 - 0.5 * Math.cos(Math.PI * U.clamp(e, 0, 1));
          const j = (i0 + q + NS * 2) % NS; T.hwA[j] = Math.min(T.hwA[j], D.half * (1 - (1 - f) * k));
        }
      }
    }
    { let n = 0, m = 0; for (let i = 0; i < NS; i++) { if (acurv[i] > 0.03) n++; if (acurv[i] > 0.05) m++; } T.twist = n / NS; T.sharp = m / NS; }
    T.gen = D.gen || null;
    T.gz2 = !!(T.rock || T.balls.length || T.traffic || T.gey.length || T.tw.length || T.mag.length || T.herd.length);
    T.gz = !!(T.rock || T.balls.length || T.gey.length || T.tiles.length || T.tw.length || T.mag.length || T.ports.length || T.disco.length || T.bogs.length || T.wash.length || T.herd.length || T.crat.length || T.puds.length);
    // world bounds
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (let i = 0; i < NS; i++) { x0 = Math.min(x0, x[i]); y0 = Math.min(y0, y[i]); x1 = Math.max(x1, x[i]); y1 = Math.max(y1, y[i]); }
    const M = 34;
    T.bx = [x0 - M, y0 - M, x1 + M, y1 + M];
    T.gofs = [0, 1, 2, 3].map((k) => (GOFS[id * 4 + k] || 0) / 10);
    cache[id] = T;
    return T;
  }

  /* fair start: every car on ONE start line, side by side in its own lane (no staggered grid). Lane k (0..3) sits at the
     same lateral spots as the item-box rows, so each lane drives straight into its own box. tr.gofs[k] = small per-lane
     set-back (athletics-style) that evens out the inside/outside line to the first checkpoint (see laneOffsets). */
  const GRID_BACK = 8, LANES = 4;
  /* per-track lane set-backs in 0.1 world units (lanes 0..3), measured with tools in test-output/racing/hp/calib.js */
  const GOFS = [0,0,0,0,0,0,0,0,0,0,0,0,-33,-10,26,29,-5,5,5,-4,0,0,0,0,0,0,0,0,0,0,0,0,-17,-3,8,12,-7,8,7,-7,-6,5,5,-3,-14,-1,4,10,-4,4,4,-4,0,0,0,0,0,0,0,0,-6,4,5,-4,-5,5,4,-4,-8,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,-5,5,5,-5,0,0,0,0,0,0,0,0,-5,4,5,-3,-9,8,8,-8,-5,4,5,-4,-7,4,6,-3,0,0,0,0,-27,-1,10,19,0,0,0,0,-16,-5,10,10,-12,1,3,8,-7,6,6,-5,0,0,0,0,-5,5,5,-4,-13,-1,5,9,-5,6,5,-6,-12,0,4,8,0,0,0,0,0,0,0,0,0,0,0,0,-15,0,3,12,0,0,0,0,-16,-2,5,12,-6,7,7,-8,0,0,0,0,-6,3,5,-2,-9,4,5,0,-7,5,5,-3];
  const laneLat = (tr, k) => (k - 1.5) * tr.half * 0.42;
  function gridSlot(tr, k) {
    k = ((k | 0) % LANES + LANES) % LANES;
    const back = GRID_BACK + ((tr.gofs && tr.gofs[k]) || 0);
    const i = (NS - Math.round(back / tr.ds)) % NS;
    const off = laneLat(tr, k);
    return { x: tr.x[i] + tr.nx[i] * off, y: tr.y[i] + tr.ny[i] * off, a: tr.hd[i], idx: i };
  }
  /* which lane each seat starts in: shuffled per race from the race id (same on every device, no extra state) */
  function laneOrder(n, rid) {
    const ks = n === 2 ? [1, 2] : [0, 1, 2, 3]; // two cars: the two middle lanes
    if (rid) for (let i = ks.length - 1; i > 0; i--) { const j = Math.floor(hash01(rid | 0, i * 31 + 7) * (i + 1)); const t = ks[i]; ks[i] = ks[j]; ks[j] = t; }
    return ks;
  }

  /* nearest centreline sample, searching around the last known index (keeps the right pass on the figure eight) */
  function locate(tr, px, py, hint) {
    let best = -1, bd = 1e18;
    if (hint >= 0) {
      for (let o = -24; o <= 24; o++) {
        const i = (hint + o + NS) % NS, ex = px - tr.x[i], ey = py - tr.y[i], d = ex * ex + ey * ey;
        if (d < bd) { bd = d; best = i; }
      }
    }
    if (best < 0 || bd > (tr.half * 2.6) ** 2) {
      let gd = 1e18, gi = 0;
      for (let i = 0; i < NS; i++) { const ex = px - tr.x[i], ey = py - tr.y[i], d = ex * ex + ey * ey; if (d < gd) { gd = d; gi = i; } }
      if (gd < bd - 1) { bd = gd; best = gi; }
    }
    return best;
  }
  /* distance to the nearest shortcut, its sample, and progress index there */
  function cutProbe(tr, px, py) {
    let best = null;
    for (const C of tr.cuts) {
      if (px < C.bb[0] || py < C.bb[1] || px > C.bb[2] || py > C.bb[3]) continue;
      let bd = 1e18, bk = 0;
      for (let k = 0; k < C.n; k++) { const ex = px - C.sx[k], ey = py - C.sy[k], d = ex * ex + ey * ey; if (d < bd) { bd = d; bk = k; } }
      const d = Math.sqrt(bd);
      if (!best || d - C.hw < best.d - best.C.hw) best = { C, d, k: bk };
    }
    return best;
  }

  /* water side test (beach): per-sample flags 1 = infield side is water, 2 = both sides */
  function waterFlags(tr) {
    if (tr.wf !== undefined) return tr.wf;
    const W = tr.D.water;
    if (!W) return (tr.wf = null);
    const f = new Int8Array(NS);
    for (let i = 0; i < NS; i++) {
      // +1: water on the +normal side, -1: water on the -normal side, 2: both
      const s = tr.side[i];
      f[i] = W.inside ? s : -s;
      for (const [a, b] of W.zones || []) if (i >= a * NS && i < b * NS) f[i] = 2;
    }
    return (tr.wf = f);
  }

  /* ---------- race world (pure: shared by the node tests and the view) ---------- */
  function newCar(tr, seat, slot) {
    const g = gridSlot(tr, slot);
    return {
      seat, x: g.x, y: g.y, a: g.a, vx: 0, vy: 0, v: 0, slip: 0, idx: g.idx, lat: 0, crossed: 0, sec: sector(g.idx), fin: null,
      boost: 0, spin: 0, spin0: 1, rot: 0, slow: 0, shield: 0, air: 0, air0: 1, resp: 0, flash: 0,
      item: null, itemN: 0, roll: 0, drift: 0, charge: 0, surf: 'road', onCut: false, safe: g.idx, stuckT: 0, wrongT: 0, lvl: 0,
      remote: false, snap: null, prevW: null, steer: 0, grec: 0,
      mag: 0, magT: -1, mirror: 0, giant: 0, blind: 0, rail: false, trainP: -1, bumpT: 0, warpN: 0, warpLat: 0, frz: 0,
      skill: 0.5, pow: 1, ailv: 0, lane: 0, laneGoal: 0, laneT: 0, nz: 0, holdT: 0, cutUse: null, cutLap: -1, stall: 0,
      net: 0, flat: 0, tire: 0, ghost: 0, snowT: 0, wet: 0, twT: 0, mgT: 0, portT: 0, mud: 0, draft: 0, disco: 0, ghk: '',
      rockK: -1, ballP: -1, gyK: -1, waveK: -1, gzT: 0, gzLane: 0, gzHold: 0, gzWide: false, gzLook: true, gzLT: 0,
      flt: 0, auto: 0, drone: 0, droneT: 0, bomb: 0, bombImm: 0, bee: 0, paint: 0, spray: 0, fer: 0, crT: 0, gateK: -1, gk2: '', herdP: -1, vort: 0,
      hp: HP_MAX, out: 0, dmg: 0, hurtT: 0, lastDmg: 0, wallCd: 0, gimCd: 0, lastFall: null,
      setup: [2, 2, 2], sg: 1, st: 1, sv: 1, sa: 1, lapT0: null,
    };
  }
  function newWorld(tr, n, rid) {
    const W = { tr, cars: [], hz: {}, boxT: {}, myBox: {}, eaten: {}, applied: {}, clock: 0, nid: 0, ev: [], racing: false, eatQ: [] };
    const lo = laneOrder(n, rid);
    for (let i = 0; i < n; i++) W.cars.push(newCar(tr, i, lo[i]));
    waterFlags(tr);
    return W;
  }
  function progress(c) { return c.crossed + c.idx / NS; }
  function ranking(W) {
    return W.cars.slice().sort((a, b) => {
      const fa = a.fin != null, fb = b.fin != null;
      if (fa !== fb) return fa ? -1 : 1;
      if (fa) return a.fin - b.fin;
      const oa = a.out > 0, ob = b.out > 0;
      if (oa !== ob) return oa ? 1 : -1; // an exploded car (DNF) ranks below every car still running
      return progress(b) - progress(a) || b.out - a.out;
    });
  }
  const levelOf = (tr, idx) => (tr.cross && idxDist(idx, tr.cross.over) < 13 ? 1 : 0);

  function respawnAt(W, c, splash) {
    const tr = W.tr;
    let i = (c.safe - 4 + NS) % NS;
    for (let k = 0; k < 120 && (tr.rv[i] || tr.pit[i] || tr.nr[i]); k++) i = (i - 1 + NS) % NS; // never back onto a river / gap / crumbling floor / run-up
    let lat = 0;
    for (const p of tr.pil) if (idxDist(p.i, i) * tr.ds < p.r + RAD + 1.5 && Math.abs(p.lat - lat) < p.r + RAD + 0.6) lat = p.lat > 0 ? p.lat - p.r - RAD - 0.8 : p.lat + p.r + RAD + 0.8;
    c.x = tr.x[i] + tr.nx[i] * lat; c.y = tr.y[i] + tr.ny[i] * lat; c.a = tr.hd[i]; c.vx = c.vy = 0; c.v = 0; c.slip = 0;
    c.idx = i; c.lat = 0; c.spin = 0; c.rot = 0; c.drift = 0; c.charge = 0; c.air = 0; c.stuckT = 0; c.cutUse = null; c.stall = 0; c.net = 0; c.flt = 0; c.fer = 0;
    c.resp = splash ? 1.1 : 0.5;
    if (splash && !(W.clock - (c.lastFall == null ? -99 : c.lastFall) < 15)) c.dmg += FALL_DMG[c.fallK] || 4; // only the first fall in a while costs HP (falling already costs time)
    if (splash) c.lastFall = W.clock;
  }

  /* one physics substep. inp = {steer ∈ [-1,1], drift: bool, cap: AI speed factor} */
  function stepCar(W, c, inp, h) {
    const tr = W.tr;
    let ev = 0;
    if (c.resp > 0) { c.resp -= h; c.vx = c.vy = c.v = 0; return 0; }
    if (c.boost > 0) c.boost -= h;
    if (c.slow > 0) c.slow -= h;
    if (c.shield > 0) c.shield -= h;
    if (c.flash > 0) c.flash -= h;
    if (c.stall > 0) c.stall -= h;
    if (c.mag > 0) c.mag -= h;
    if (c.mirror > 0) c.mirror -= h;
    if (c.giant > 0) c.giant -= h;
    if (c.blind > 0) c.blind -= h;
    if (c.bumpT > 0) c.bumpT -= h;
    if (c.wallCd > 0) c.wallCd -= h;
    if (c.gimCd > 0) c.gimCd -= h;
    if (c.frz > 0) c.frz -= h;
    if (c.net > 0) c.net -= h;
    if (c.flat > 0) c.flat -= h;
    if (c.tire > 0) c.tire -= h;
    if (c.ghost > 0) c.ghost -= h;
    if (c.snowT > 0) c.snowT -= h;
    if (c.wet > 0) c.wet -= h;
    if (c.twT > 0) c.twT -= h;
    if (c.mgT > 0) c.mgT -= h;
    if (c.portT > 0) c.portT -= h;
    if (c.mud > 0) c.mud = Math.max(0, c.mud - h * 0.012);
    if (c.flt > 0) c.flt -= h;
    if (c.auto > 0) c.auto -= h;
    if (c.droneT > 0) { c.droneT -= h; if (c.droneT <= 0) c.drone = 0; }
    if (c.bee > 0) c.bee -= h;
    if (c.paint > 0) c.paint -= h;
    if (c.spray > 0) c.spray -= h;
    if (c.fer > 0) c.fer -= h;
    if (c.crT > 0) c.crT -= h;
    if (c.vort > 0) c.vort -= h;
    if (c.bombImm > 0) c.bombImm -= h;
    if (c.bomb > 0) { // 째깍 폭탄 goes off
      c.bomb -= h;
      if (c.bomb <= 0) {
        c.bomb = 0; c.bombImm = 0.6; ev |= 32768;
        gHit(c, 'bang', () => { c.spin = c.spin0 = 1.2; c.air = c.air0 = 0.5; c.vx *= 0.3; c.vy *= 0.3; });
      }
    }
    const warping = c.warpN > 0;
    let steer = U.clamp(fin(inp.steer) ? inp.steer : 0, -1, 1), drift = !!inp.drift;
    const cap = fin(inp.cap) ? inp.cap : 1;
    if (c.spin > 0) {
      c.spin -= h; steer = 0; drift = false;
      c.rot = c.spin > 0 ? (1 - c.spin / c.spin0) * Math.PI * 4 : 0;
    }
    if (warping) { steer = 0; drift = false; c.spin = 0; c.rot = 0; c.drift = 0; c.charge = 0; }
    const air = c.air > 0 || warping;
    if (c.air > 0) { c.air -= h; steer *= tr.lowg > 1 ? 0.4 : 0.15; }
    const hov = air || c.flt > 0; // 풍선: floating over the ground (walls and posts still count)
    if (c.bee > 0 && c.spin <= 0) steer = U.clamp(steer + Math.sin(W.clock * 15 + c.seat * 2) * 0.28, -1, 1); // bees: the car twitches
    let S = hov ? SURF.road : (SURF[c.surf] || SURF.road);
    if (c.tire > 0 && !hov && S.v < 0.9 && c.surf !== 'ice') S = SURF.tire; // 험로 타이어: off-road feels like road
    let ca = Math.cos(c.a), sa = Math.sin(c.a);
    const fwd = c.vx * ca + c.vy * sa;
    // drift: hold the drift button while steering at speed; release for a mini-turbo
    const ds = fin(inp.dsteer) ? U.clamp(inp.dsteer, -1, 1) : steer; // humans: the held direction decides the drift
    if (drift && !c.drift && Math.abs(ds) > 0.3 && fwd > 13 && !hov && c.spin <= 0) { c.drift = ds > 0 ? 1 : -1; c.a += c.drift * 0.07; ev |= 1048576; } // a small nose snap so the drift 'catches' at once
    if (c.drift && (!drift || fwd < 8 || c.spin > 0)) {
      if (c.charge > 0.8 && c.spin <= 0) { // mini-turbo: a short forward kick on release, then the boost
        const big = c.charge > 1.6, kk = big ? 3.2 : 1.8;
        c.boost = Math.max(c.boost, big ? 1.1 : 0.6); c.vx += Math.cos(c.a) * kk; c.vy += Math.sin(c.a) * kk; ev |= 4;
      }
      c.drift = 0; c.charge = 0; c.grec = 0.3;
    }
    if (c.grec > 0) c.grec -= h;
    let turn;
    if (c.drift) {
      const eff = U.clamp(0.8 + 0.55 * steer * c.drift, 0.35, 1.35);
      turn = c.drift * eff * STEER * 1.12;
      if (!hov) c.charge += h * (0.55 + 0.5 * eff);
    } else turn = steer * STEER * (c.st || 1) * U.clamp(0.35 + fwd / 9, 0, 1);
    c.a += turn * h;
    // turntable: the floor turns under the car and takes it (and its nose) round with it
    let tq = null;
    if (!hov && tr.turn.length) for (const q of tr.turn) { const ex = c.x - q.x, ey = c.y - q.y; if (ex * ex + ey * ey < q.R * q.R) { tq = q; c.a += q.w * h; break; } }
    ca = Math.cos(c.a); sa = Math.sin(c.a);
    // conveyor belt: the floor itself moves, so the car drives relative to it
    let gvx = 0, gvy = 0;
    c.belt = 0;
    if (!hov && tr.belts.length) {
      const bk = tr.belt[c.idx], Bt = bk ? tr.belts[bk - 1] : null;
      if (Bt && c.lat >= Bt.l0 - 0.6 && c.lat <= Bt.l1 + 0.6) { const ba = tr.hd[c.idx] + Bt.dir; gvx = Math.cos(ba) * Bt.sp; gvy = Math.sin(ba) * Bt.sp; c.vx -= gvx; c.vy -= gvy; c.belt = bk; }
    }
    if (!hov && tr.fer) { // riding a ferry raft: the deck carries the car
      const F = tr.fer, q = frameOf(F, c);
      if (Math.abs(q.al) < F.wr + 0.4 && Math.abs(q.lt) < tr.half + 1) {
        const R = raftAt(F, q.lt >= 0 ? 1 : 0, W.clock);
        if (q.al > R.p - FER_LR / 2 - 0.5 && q.al < R.p + FER_LR / 2 + 0.5) { gvx = q.ca * R.v; gvy = q.sa * R.v; c.vx -= gvx; c.vy -= gvy; }
      }
    }
    if (tq) { gvx = -tq.w * (c.y - tq.y); gvy = tq.w * (c.x - tq.x); c.vx -= gvx; c.vy -= gvy; }
    let vf = c.vx * ca + c.vy * sa, vl = -c.vx * sa + c.vy * ca;
    const braking = drift && !c.drift && c.spin <= 0;
    // mine-cart rails: lined up on the rail = fast lane (and it holds you a little)
    const rl = tr.railLat[c.idx];
    c.rail = !hov && rl === rl && Math.abs(c.lat - rl) < 1.1 && vf > 6 && Math.cos(c.a - tr.hd[c.idx]) > 0.94;
    const sl = hov ? 0 : tr.slope[c.idx];
    let kv = (sl > 0 ? 1.16 : sl < 0 ? 0.86 : 1) * (c.rail ? 1.22 : 1) * (c.giant > 0 ? 1.06 : 1) * (c.auto > 0 ? 1.08 : 1);
    const bk2 = hov ? 0 : tr.bank[c.idx]; // banked curve: the high outer side is quicker
    if (bk2) kv *= 1.03 + 0.08 * U.clamp((bk2 * c.lat) / tr.half, 0, 1);
    let ka = (sl > 0 ? 1.25 : sl < 0 ? 0.8 : 1) * (c.rail ? 1.4 : 1);
    // magnet: pulled toward the car it locked onto while that car is roughly ahead
    let magPull = null;
    if (c.mag > 0) {
      const tc = W.cars[c.magT];
      if (tc && tc !== c && !gone(tc) && tc.lvl === c.lvl && tc.resp <= 0) {
        const dx = tc.x - c.x, dy = tc.y - c.y, d = Math.hypot(dx, dy) || 1;
        if (d < 70 && (dx * ca + dy * sa) / d > 0.4) { kv *= 1.2; ka *= 1.8; if (d > 4.5) magPull = [dx / d, dy / d]; }
      }
    }
    // slipstream (anywhere): tucked in behind another car inside a narrow cone builds up a tow over ~1.5 s
    // (stronger on the marked slipstream straights); leaving the cone bleeds it off quickly
    let inTow = false;
    if (!air && fwd > 10) {
      for (const o of W.cars) {
        if (o === c || o.lvl !== c.lvl || o.resp > 0 || o.out || (o.v || 0) < 8) continue;
        const dx = o.x - c.x, dy = o.y - c.y, al = dx * ca + dy * sa;
        if (al > 3 && al < 18 && Math.abs(-dx * sa + dy * ca) < 1.4 + al * 0.09) { inTow = true; break; }
      }
    }
    c.draft = U.clamp((c.draft || 0) + (inTow ? h / 1.5 : -h / 0.4), 0, 1);
    if (c.draft > 0) { const g = tr.slip[c.idx] ? 1 : 0.7; kv *= 1 + 0.13 * g * c.draft; ka *= 1 + 0.6 * g * c.draft; }
    // disco floor: the green lane is fast, the red one slow
    c.disco = 0;
    if (!hov && tr.dsc[c.idx] && Math.abs(c.lat) < tr.half) {
      const col = discoCol(tr.disco[tr.dsc[c.idx] - 1], U.clamp(Math.floor((c.lat + tr.half) / ((tr.half * 2) / 3)), 0, 2), W.clock);
      if (col === 0) { kv *= 1.14; ka *= 1.5; c.disco = 1; } else if (col === 2) { kv *= 0.8; c.disco = -1; }
    }
    const sv = c.sv || 1;
    let vmax = VMAX * sv * S.v * c.pow * cap * kv * (1 - (0.08 - 0.6 * ((c.st || 1) - 1)) * Math.abs(steer)); // grip setup: less speed scrubbed off while turning
    if (c.boost > 0) vmax = VMAX * sv * c.pow * BOOST * Math.max(S.v, 0.82) * Math.max(1, kv * 0.92);
    if (c.slow > 0) vmax *= 0.55;
    if (c.net > 0) vmax *= 0.35;
    if (c.flat > 0) vmax *= 0.62;
    if (c.snowT > 0) vmax *= 0.6;
    if (c.wet > 0) vmax *= 0.7;
    if (c.mud > 0) vmax *= 1 - 0.2 * c.mud;
    if (c.bee > 0) vmax *= 0.82;
    if (c.spray > 0) vmax *= 0.93;
    if (c.vort > 0) vmax *= 0.6;
    if (braking) vmax *= 0.3;
    if (c.spin > 0 || c.stall > 0) vmax = 0;
    if (vf < vmax) vf = Math.min(vmax, vf + ACC * (c.sa || 1) * S.acc * ka * h * (c.boost > 0 ? 1.8 : 1));
    else vf -= (vf - vmax) * Math.min(1, (c.spin > 0 ? 2.6 : braking ? 2.4 : S === SURF.road ? 1.3 : 3.2) * h);
    let g = S.g * (c.sg || 1) * WXG[WX]; // 비·폭우·눈: 옆 접지력이 줄어 코너에서 미끄러진다
    if (c.drift) g = Math.min(g, 2.6);
    else if (c.grec > 0) g = Math.min(g, 2.6 + (g - 2.6) * (1 - c.grec / 0.3)); // grip returns smoothly after a drift
    if (c.spin > 0) g = 1.5;
    if (air) g = 0.3;
    else if (c.flt > 0) g = 3.5;
    else if (c.rail && !c.drift) g = Math.max(g, 10);
    else if (bk2 && !c.drift) g = Math.max(g, 12);
    vl *= Math.exp(-g * h);
    c.vx = ca * vf - sa * vl + gvx; c.vy = sa * vf + ca * vl + gvy;
    if (!hov) {
      const fl = tr.flow[c.idx]; // undersea current pushes sideways
      if (fl) { c.vx += tr.nx[c.idx] * fl * h; c.vy += tr.ny[c.idx] * fl * h; }
      if (c.rail) { const pull = U.clamp(rl - c.lat, -1, 1) * 5 * h; c.vx += tr.nx[c.idx] * pull; c.vy += tr.ny[c.idx] * pull; }
      if (magPull && c.spin <= 0) { c.vx += magPull[0] * 9 * h; c.vy += magPull[1] * 9 * h; }
    }
    if (warping) { // 순간이동: glide one centreline sample per substep, ignoring everything on the way
      c.warpN--;
      const j = (c.idx + 1) % NS;
      let lat = c.warpLat;
      if (c.warpN <= 0) {
        if (tr.rv[j] || tr.pit[j] || tr.nr[j]) c.warpN = 1; // never land on a river / gap / crumbling floor / ferry
        for (const p of tr.pil) if (idxDist(p.i, j) * tr.ds < p.r + RAD + 1.5 && Math.abs(p.lat - lat) < p.r + RAD + 0.6) lat = p.lat > 0 ? p.lat - p.r - RAD - 0.8 : p.lat + p.r + RAD + 0.8;
      }
      const sp = Math.max(fin(c.v) ? c.v : 0, 22);
      c.x = tr.x[j] + tr.nx[j] * lat; c.y = tr.y[j] + tr.ny[j] * lat; c.a = tr.hd[j];
      c.vx = tr.tx[j] * sp; c.vy = tr.ty[j] * sp; vf = sp; vl = 0;
    } else { c.x += c.vx * h; c.y += c.vy * h; }
    c.v = vf; c.slip = vl;
    // world bounds
    const B = tr.bx;
    if (c.x < B[0]) { c.x = B[0]; c.vx = Math.abs(c.vx) * 0.3; }
    if (c.x > B[2]) { c.x = B[2]; c.vx = -Math.abs(c.vx) * 0.3; }
    if (c.y < B[1]) { c.y = B[1]; c.vy = Math.abs(c.vy) * 0.3; }
    if (c.y > B[3]) { c.y = B[3]; c.vy = -Math.abs(c.vy) * 0.3; }
    // where are we
    const pr = tr.cuts.length ? cutProbe(tr, c.x, c.y) : null;
    let ni;
    c.onCut = !!(pr && pr.d < pr.C.hw + 0.4);
    const ri = locate(tr, c.x, c.y, c.idx);
    const rlat = (c.x - tr.x[ri]) * tr.nx[ri] + (c.y - tr.y[ri]) * tr.ny[ri];
    if (c.onCut && Math.abs(rlat) > tr.half) ni = pr.C.si[pr.k]; else { ni = ri; c.onCut = false; }
    // laps (sectors must be passed in order; a shortcut may skip a few)
    const maxSkip = c.onCut ? SECSKIP : 2;
    if (c.idx > NS - 60 && ni < 60) {
      if (c.sec >= NSEC - 3) {
        c.crossed++; c.sec = 0; ev |= 1;
        if (W.racing && c.crossed >= 2 && c.crossed <= LAPS && c.hp < HP_MAX && !c.out) { const n = Math.min(LAP_FIX, HP_MAX - c.hp); c.hp += n; W.ev.push({ k: 'fix', s: c.seat, n }); }
      } else ev |= 8;
    } else if (c.idx < 60 && ni > NS - 60) {
      if (c.crossed > 0) c.crossed--;
      c.sec = NSEC - 1;
    } else {
      const s = sector(ni);
      if (s > c.sec && s - c.sec <= maxSkip) c.sec = s;
    }
    c.idx = ni;
    c.lat = rlat;
    c.lvl = levelOf(tr, ri);
    const half = tr.half, alat = Math.abs(rlat);
    // surface
    if (c.onCut && alat > half) c.surf = pr.C.tide && tideLvl(tr, W.clock) > 0.5 ? 'shallow' : pr.C.s;
    else if (alat <= (tr.hwA ? tr.hwA[ri] : half) + 0.3) c.surf = tr.ice[ri] ? 'ice' : tr.rough[ri] ? 'rough' : tr.D.seasons && c.crossed >= 2 ? (c.crossed >= 3 ? 'snowroad' : 'wet') : (tr.D.deck || 'road');
    else c.surf = tr.D.seasons && c.crossed >= 3 ? 'snow' : tr.off;
    if (!hov && !c.onCut) {
      for (const q of tr.puds) if ((c.x - q.x) ** 2 + (c.y - q.y) ** 2 < q.r * q.r) { c.surf = 'splash'; break; }
      for (const q of tr.syrup) if ((c.x - q.x) ** 2 + (c.y - q.y) ** 2 < q.r * q.r) { c.surf = 'syrup'; if (c.drift) c.charge = Math.max(0, c.charge - h * 2); break; }
      for (const q of tr.hzs) if ((c.x - q.x) ** 2 + (c.y - q.y) ** 2 < q.r * q.r) {
        c.surf = q.k === 'mud' ? 'mudpit' : q.k === 'ice' ? 'ice' : q.k === 'oil' ? 'slick' : 'splash';
        if (q.k === 'oil' && c.v > 10 && c.ghost <= 0) c.a += (c.lat >= q.lat ? 1 : -1) * h * 0.5; // the tail steps out a little
        if (q.k === 'mud' && c.drift) c.charge = Math.max(0, c.charge - h);
        break;
      }
      for (const q of tr.traps) { // sand pit: slows you down and drags you toward its middle
        const ex = q.x - c.x, ey = q.y - c.y, d2 = ex * ex + ey * ey;
        if (d2 < q.r * q.r) { c.surf = 'sand'; const d = Math.sqrt(d2) || 1; c.vx += ex / d * 10 * h; c.vy += ey / d * 10 * h; }
      }
      for (const q of tr.bogs) { // rally mud bogs (ellipses along the road): slow, and the mud sticks to the car
        const ex = c.x - q.x, ey = c.y - q.y, cq = Math.cos(q.a), sq = Math.sin(q.a), al = ex * cq + ey * sq, lt = -ex * sq + ey * cq;
        if ((al / q.lx) ** 2 + (lt / q.ly) ** 2 < 1) { c.surf = 'bog'; c.mud = Math.min(1, c.mud + h * 0.6); break; }
      }
      for (const q of tr.wash) if ((c.x - q.x) ** 2 + (c.y - q.y) ** 2 < q.r * q.r) { c.surf = 'puddle'; c.mud = Math.max(0, c.mud - h * 2.4); break; }
      for (const B of tr.balls) { // the snow a snowball leaves across the road
        if (idxDist(B.i, ri) * tr.ds > 4) continue;
        const st = ballAt(B, W.clock);
        if (!st || st.tau < 0) continue;
        const al = (c.x - B.x) * tr.tx[B.i] + (c.y - B.y) * tr.ty[B.i], l0 = B.side * B.L, lo = Math.min(l0, st.lat), hi = Math.max(l0, st.lat);
        if (Math.abs(al) < 2.4 && rlat > lo && rlat < hi) { c.surf = 'slush'; break; }
      }
    }
    // beach waves wash over the causeway and push the car toward the other side
    if (!hov && tr.waves && tr.wav[ri]) {
      const wf = waveFront(tr, tr.wav[ri], W.clock);
      if (wf && Math.abs(rlat - wf.f) < tr.waves.w + RAD * 0.6) {
        c.vx -= tr.nx[ri] * wf.sd * 17 * h; c.vy -= tr.ny[ri] * wf.sd * 17 * h; c.wet = Math.max(c.wet, 0.6);
        if (c.waveK !== wf.k) { c.waveK = wf.k; c.ghk = 'wave'; ev |= 32768; }
      }
    }
    if (!hov) for (const id in W.hz) { // ice-bomb patches, foam stripes, whirlpool traps
      const z = W.hz[id];
      if (z.t === 'frost') { if (frostOn(z) && (c.x - z.x) ** 2 + (c.y - z.y) ** 2 < FROST_R * FROST_R) c.surf = 'ice'; }
      else if (z.t === 'foam') { if ((z.o !== c.seat || z.age > 1.5) && onFoam(z, ri, rlat)) c.surf = 'foam'; }
      else if (z.t === 'vort' && (z.o !== c.seat || z.age > 1.5) && (z.lvl | 0) === c.lvl) {
        const ex = z.x - c.x, ey = z.y - c.y, d2 = ex * ex + ey * ey;
        if (d2 < VORT_R * VORT_R && c.ghost <= 0) { const d = Math.sqrt(d2) || 1, k = 16 * (1 - d / VORT_R) + 4; c.vx += ((ex / d) * k - (ey / d) * k * 0.6) * h; c.vy += ((ey / d) * k + (ex / d) * k * 0.6) * h; c.vort = 0.12; if (c.drift) c.charge = Math.max(0, c.charge - h * 2); }
      }
    }
    // spray: right behind a car splashing through a puddle (its position is known on every device)
    if (tr.puds.length && !hov) {
      const ca1 = Math.cos(c.a), sa1 = Math.sin(c.a);
      for (const o of W.cars) {
        if (o === c || o.lvl !== c.lvl || o.resp > 0 || o.out || o.air > 0 || o.flt > 0 || !(o.v > 12)) continue;
        const dx = o.x - c.x, dy = o.y - c.y, al = dx * ca1 + dy * sa1;
        if (al < 2 || al > 13 || Math.abs(-dx * sa1 + dy * ca1) > 2.8) continue;
        if (tr.puds.some((q) => (o.x - q.x) ** 2 + (o.y - q.y) ** 2 < q.r * q.r)) { if (c.spray <= 0) { c.ghk = 'spray'; ev |= 32768; } c.spray = 0.9; break; }
      }
    }
    // side gusts on the bridges (a floating balloon gets blown much further)
    if (tr.gust && tr.gzone[ri]) { const gs = gustAt(tr.gust, W.clock); if (gs && gs.on) { const k = tr.gust.f * (c.flt > 0 ? 1.8 : 1) * gs.dir; c.vx += tr.nx[ri] * k * h; c.vy += tr.ny[ri] * k * h; } }
    // walls: along the road, or along a shortcut's sides when the car is beside one
    if (tr.wall != null && !air) {
      const lim = half + tr.wall - RAD * 0.55;
      if (pr && pr.d < pr.C.hw + 5 && alat > half) {
        const C = pr.C, cl = C.hw - RAD * 0.55;
        if (pr.d > cl && alat > lim - 0.2) {
          const k = pr.k, ex = c.x - C.sx[k], ey = c.y - C.sy[k], d = Math.hypot(ex, ey) || 1;
          const k2 = Math.min(C.n - 1, k + 1), k1 = Math.max(0, k2 - 2);
          ev |= wallHit(c, ex / d, ey / d, pr.d - cl, Math.atan2(C.sy[k2] - C.sy[k1], C.sx[k2] - C.sx[k1]), tr.D.bouncy);
        }
      } else if (alat > lim) {
        const sg = rlat > 0 ? 1 : -1;
        ev |= wallHit(c, tr.nx[ri] * sg, tr.ny[ri] * sg, alat - lim, tr.hd[ri], tr.D.bouncy);
      }
    }
    // water: splash and respawn
    const wf = tr.wf;
    if (wf && !hov && !c.onCut && alat > half + tr.D.water.d) {
      const f = wf[ri];
      if (f === 2 || (f === 1 && rlat > 0) || (f === -1 && rlat < 0)) { c.fallK = tr.D.water.k || 'sea'; respawnAt(W, c, true); return ev | 16; }
    }
    // rivers / gaps: inside a band only the logs or bridges hold you
    if (!hov && tr.rivers.length) {
      for (const R of tr.rivers) {
        if (segDist(R.pts, c.x, c.y) >= R.w) continue;
        if (R.k === 'chasm' && c.onCut) continue; // the rope bridge of a shortcut crosses the chasm
        if (R.sw) { if (alat < half + 1 && swingOK(R.sw, rlat, W.clock)) continue; }
        else if (alat < half + 1 && R.lanes.some((L2) => Math.abs(rlat - laneAt(R, L2, W.clock)) < L2[1])) continue;
        c.fallK = R.k; respawnAt(W, c, true); return ev | 16;
      }
    }
    const ghost = c.ghost > 0;
    // stone pillars / bumpers
    if (!warping && !ghost) for (const p of tr.pil) {
      const ex = p.x - c.x, ey = p.y - c.y, d = Math.hypot(ex, ey), lim = p.r + RAD * 0.85;
      if (d >= lim || d < 1e-4) continue;
      const vn = c.vx * ex / d + c.vy * ey / d;
      ev |= wallHit(c, ex / d, ey / d, lim - d, c.a, tr.D.bumpers);
      if (tr.D.bumpers) { const k = 7 + Math.max(0, vn) * 0.5; c.vx -= ex / d * k; c.vy -= ey / d * k; if (c.drift) { c.drift = 0; c.charge = 0; } ev |= 256; }
    }
    // crane containers / rolling balls
    if (!warping && !ghost) for (const m of tr.mov) {
      const ml = moverLat(m, W.clock), mx = m.x + tr.nx[m.i] * ml, my = m.y + tr.ny[m.i] * ml;
      if (m.ball) { // a big rolling ball: round, and it shoves you the way it rolls
        const ex = c.x - mx, ey = c.y - my, d = Math.hypot(ex, ey), lim = m.r + RAD * 0.85;
        if (d >= lim || d < 1e-4) continue;
        ev |= wallHit(c, -ex / d, -ey / d, lim - d, c.a) | 256;
        const bv = m.amp * (Math.PI * 2 / m.per) * Math.cos((W.clock / m.per) * Math.PI * 2 + m.ph);
        c.vx += ex / d * 6 + tr.nx[m.i] * bv * 0.5; c.vy += ey / d * 6 + tr.ny[m.i] * bv * 0.5;
        if (c.drift) { c.drift = 0; c.charge = 0; }
        continue;
      }
      const cs = Math.cos(m.a), sn = Math.sin(m.a), ex = c.x - mx, ey = c.y - my;
      const al = ex * cs + ey * sn, lt = -ex * sn + ey * cs;
      const qx = U.clamp(al, -m.hx, m.hx), qy = U.clamp(lt, -m.hy, m.hy);
      let dx = al - qx, dy = lt - qy, d = Math.hypot(dx, dy);
      const lim = RAD * 0.85;
      if (d >= lim) continue;
      if (d < 1e-4) { dx = 0; dy = lt >= 0 ? 1 : -1; d = 1; }
      const ox = (dx * cs - dy * sn) / d, oy = (dx * sn + dy * cs) / d; // outward normal
      const inside = Math.abs(al) <= m.hx && Math.abs(lt) <= m.hy;
      const over = inside ? lim + m.hy - Math.abs(lt) : lim - d;
      ev |= wallHit(c, -ox, -oy, over, c.a);
    }
    // windmill sails sweep low over the road: the first touch bats you across, away from the mill, with a short spin
    if (!warping && !air && !ghost && alat < half + 2) for (const S of tr.sw) {
      const hx = c.x - S.hx, hy = c.y - S.hy;
      if (hx * hx + hy * hy > (S.len + 3) ** 2) continue;
      for (let k = 0; k < S.n; k++) {
        const a = sailAng(S, k, W.clock), ux = Math.cos(a), uy = Math.sin(a);
        const t = U.clamp(hx * ux + hy * uy, 0, S.len), px = hx - ux * t, py = hy - uy * t, d = Math.hypot(px, py), lim = SAIL_W + RAD * 0.85;
        if (d >= lim || t < 1.5) continue;
        const ox = d > 1e-4 ? px / d : -uy, oy = d > 1e-4 ? py / d : ux;
        ev |= wallHit(c, -ox, -oy, lim - d, c.a);
        if (c.bumpT <= 0) {
          c.bumpT = 1.2;
          if (c.shield > 0) { c.shield = 0; c.flash = 0.5; }
          else {
            const tx0 = tr.tx[ri], ty0 = tr.ty[ri], va = Math.max(0, c.vx * tx0 + c.vy * ty0) * 0.5;
            c.vx = tx0 * va - S.nx0 * S.sd * 11; c.vy = ty0 * va - S.ny0 * S.sd * 11;
            c.spin = c.spin0 = 0.6; c.drift = 0; c.charge = 0; c.boost = 0; gimDmg(c, 'sail');
          }
          ev |= 4096;
        }
        break;
      }
    }
    // gates: a divider down the middle, then a gate across each lane (closed gate = wall)
    if (!warping && !air) for (const d of tr.doors) {
      const ex = c.x - d.x, ey = c.y - d.y, ta = Math.cos(d.a), tb = Math.sin(d.a);
      const al = ex * ta + ey * tb, lt = -ex * tb + ey * ta, lim = RAD * 0.85;
      if (al < -DOOR_DIV - 4 || al > 4 || Math.abs(lt) > half + 3) continue;
      if (al > -DOOR_DIV && al < 0.6 && Math.abs(lt) < DIV_W + lim) { const sg = lt >= 0 ? 1 : -1; ev |= wallHit(c, tb * sg, -ta * sg, DIV_W + lim - Math.abs(lt), d.a); }
      if (Math.abs(al) < lim + 0.3 && !doorOpen(d, lt >= 0 ? 1 : -1, W.clock)) {
        if (al <= 0) ev |= wallHit(c, ta, tb, al + lim + 0.3, c.a); else ev |= wallHit(c, -ta, -tb, lim + 0.3 - al, c.a);
      }
    }
    // lightning: every car inside a marked circle when it strikes spins out (a shield takes it)
    if (tr.bolt && W.racing && !warping && !ghost) {
      const bp = boltPhase(tr.bolt, W.clock);
      if (bp && bp.tau >= tr.bolt.warn && c.boltK !== bp.k) {
        c.boltK = bp.k;
        if (!air && bp.tau < tr.bolt.warn + 0.2) for (const sp of boltSpots(tr, bp.k)) {
          if ((c.x - sp.x) ** 2 + (c.y - sp.y) ** 2 > (tr.bolt.r + RAD * 0.6) ** 2) continue;
          if (c.shield > 0) { c.shield = 0; c.flash = 0.5; }
          else { c.spin = c.spin0 = 0.9; c.vx *= 0.35; c.vy *= 0.35; c.drift = 0; c.charge = 0; c.boost = 0; gimDmg(c, 'bolt'); }
          ev |= 2048;
          break;
        }
      }
    }
    // round 9 obstacles: boulders, snowballs, traffic, geysers, tornadoes, electromagnets
    if (tr.gz2 && !warping && !hov && !ghost) ev |= gimmickHits(W, c, h);
    // round 12: the ferry and the drawbridges (walls, gates, the water)
    if (!hov && (tr.fer || tr.dbr.length)) { const e2 = (tr.fer ? ferryStep(W, c) : 0) | (tr.dbr.length ? dbStep(W, c) : 0); ev |= e2; if (e2 & 16) return ev; }
    // collapsing floor: a dropped tile is a hole
    if (!hov && tr.pit[ri] && W.racing) {
      const P2 = tr.tiles[tr.pit[ri] - 1], al = ((((ri - P2.i0) % NS) + NS) % NS) * tr.ds + (c.x - tr.x[ri]) * tr.tx[ri] + (c.y - tr.y[ri]) * tr.ty[ri];
      const r = Math.floor(al / TILE_L), cw = (half * 2) / 3;
      if (al > 0 && r < P2.rows && alat < half) {
        const q = U.clamp(Math.floor((rlat + half) / cw), 0, 2), ia = al - r * TILE_L, il = rlat + half - q * cw;
        if (ia > 0.8 && ia < TILE_L - 0.8 && il > 0.7 && il < cw - 0.7 && tileState(tr, P2, r, q, W.clock) === 2) { c.fallK = 'pit'; respawnAt(W, c, true); return ev | 16; }
      }
    }
    // magic doors: a lit door sends you on to its exit further along the course
    if (tr.ports.length && !air && !warping && c.portT <= 0) for (const P2 of tr.ports) {
      if ((c.x - P2.x) ** 2 + (c.y - P2.y) ** 2 > PORT_R * PORT_R || !portOn(P2, W.clock)) continue;
      const da = wrapA(tr.hd[P2.j] - tr.hd[P2.i]), cs = Math.cos(da), sn = Math.sin(da), vx = c.vx * cs - c.vy * sn, vy = c.vx * sn + c.vy * cs;
      W.ev.push({ k: 'portal', s: c.seat, x: c.x, y: c.y, x2: P2.ex, y2: P2.ey });
      c.x = P2.ex; c.y = P2.ey; c.vx = vx; c.vy = vy; c.a += da; c.idx = P2.j; c.sec = sector(P2.j); c.safe = P2.j; c.lat = P2.lat; c.portT = 1.2;
      return ev | 65536;
    }
    if (alat < half && !hov && c.surf !== 'ice' && !tr.rv[ri] && !tr.pit[ri] && !tr.nr[ri]) c.safe = ri;
    // pads and ramps
    for (const p of tr.pads) {
      const ex = c.x - p.x, ey = c.y - p.y, al = ex * Math.cos(p.a) + ey * Math.sin(p.a), lt = -ex * Math.sin(p.a) + ey * Math.cos(p.a);
      if (Math.abs(al) < 3 && Math.abs(lt) < 2.8 && !hov) { if (c.boost < 0.5) ev |= 2; c.boost = Math.max(c.boost, 1.0); }
    }
    for (const p of tr.ramps) {
      const ex = c.x - p.x, ey = c.y - p.y, al = ex * Math.cos(p.a) + ey * Math.sin(p.a), lt = -ex * Math.sin(p.a) + ey * Math.cos(p.a);
      if (Math.abs(al) < 1.6 && Math.abs(lt) < half && !hov && vf > 12) { c.air = c.air0 = (0.45 + vf / 70) * tr.lowg; ev |= 32; }
    }
    // sky road: spring pads in front of each gap fling you over it (a minimum launch speed, nose eased along the road)
    for (const p of tr.springs) {
      if (hov) break;
      const ex = c.x - p.x, ey = c.y - p.y, al = ex * Math.cos(p.a) + ey * Math.sin(p.a), lt = -ex * Math.sin(p.a) + ey * Math.cos(p.a);
      if (Math.abs(al) < 1.8 && Math.abs(lt) < half + 1 && Math.cos(c.a - p.a) > 0) {
        c.a += wrapA(p.a - c.a) * 0.6;
        const v0 = Math.max(vf, 18);
        c.vx = Math.cos(c.a) * v0; c.vy = Math.sin(c.a) * v0; c.v = v0;
        c.air = c.air0 = (p.w * 2 + 9) / v0; c.drift = 0; c.charge = 0;
        ev |= 32 | 1024;
        break;
      }
    }
    if (!hov) ev |= jumpsAndGates(W, c, vf, ri);
    // level crossing: the train is a moving wall — touching it knocks you aside and spins you (once per pass)
    if (!air && !ghost) for (const Tn of tr.trains) {
      const f = trainFront(Tn, W.clock);
      if (f == null) continue;
      const ex = c.x - Tn.ax, ey = c.y - Tn.ay, s = ex * Tn.ux + ey * Tn.uy, n = ex * Tn.nx + ey * Tn.ny, lim = TRAIN_W + carR(c) * 0.8;
      if (s > f + RAD || s < f - Tn.len - RAD || Math.abs(n) >= lim) continue;
      const sg = n >= 0 ? 1 : -1, pass = trainPass(Tn, W.clock);
      c.x += Tn.nx * sg * (lim - Math.abs(n)); c.y += Tn.ny * sg * (lim - Math.abs(n));
      if (c.trainP !== pass) {
        c.trainP = pass;
        c.vx = Tn.nx * sg * 14 + Tn.ux * Tn.v * 0.3; c.vy = Tn.ny * sg * 14 + Tn.uy * Tn.v * 0.3;
        if (c.shield > 0) { c.shield = 0; c.flash = 0.5; }
        else { c.spin = c.spin0 = 1.1; c.boost = 0; gimDmg(c, 'train'); }
        c.drift = 0; c.charge = 0; c.giant = 0;
        ev |= 512;
      }
    }
    // stuck guard (e.g. wedged against a wall): put the car back on the road
    if (W.racing && c.fin == null) {
      if (Math.abs(vf) < 1.5 && c.spin <= 0 && c.stall <= 0 && cap > 0.01 && c.fer <= 0) { c.stuckT += h; if (c.stuckT > 3.5) { respawnAt(W, c, false); ev |= 64; } } else c.stuckT = 0;
      const dir = ca * tr.tx[ri] + sa * tr.ty[ri];
      if (dir < -0.3 && vf > 5 && !c.onCut) c.wrongT += h; else c.wrongT = Math.max(0, c.wrongT - h * 2);
    }
    return ev;
  }
  /* a solid box (traffic car) at mx,my with heading a, half sizes hx, hy */
  function boxHit(c, mx, my, a, hx, hy) {
    const cs = Math.cos(a), sn = Math.sin(a), ex = c.x - mx, ey = c.y - my;
    const al = ex * cs + ey * sn, lt = -ex * sn + ey * cs;
    const qx = U.clamp(al, -hx, hx), qy = U.clamp(lt, -hy, hy);
    let dx = al - qx, dy = lt - qy, d = Math.hypot(dx, dy);
    const lim = RAD * 0.85;
    if (d >= lim) return -1;
    if (d < 1e-4) { if (hx - Math.abs(al) < hy - Math.abs(lt)) { dx = al >= 0 ? 1 : -1; dy = 0; } else { dx = 0; dy = lt >= 0 ? 1 : -1; } d = 1; }
    const ox = (dx * cs - dy * sn) / d, oy = (dx * sn + dy * cs) / d;
    const inside = Math.abs(al) <= hx && Math.abs(lt) <= hy;
    const over = inside ? lim + (Math.abs(dx) > 0.5 ? hx - Math.abs(al) : hy - Math.abs(lt)) : lim - d;
    return wallHit(c, -ox, -oy, over, c.a);
  }
  /* a hazard landed on the car: the shield takes it, else the effect `hit` runs */
  function gHit(c, kind, hit) {
    c.ghk = kind;
    if (c.shield > 0) { c.shield = 0; c.flash = 0.5; c.ghk = 'block'; return; }
    c.drift = 0; c.charge = 0; c.boost = 0; c.giant = 0;
    hit();
    gimDmg(c, kind);
  }
  /* round 9: things on the course that hit the car (boulders, snowballs, traffic, geysers, tornadoes, electromagnets) */
  const TCAR_HX = 2.9, TCAR_HY = 1.45;
  function gimmickHits(W, c, h) {
    const tr = W.tr, t = W.clock;
    let ev = 0;
    if (tr.rock && W.racing) {
      const R = tr.rock, k1 = Math.floor((t - R.off - R.warn) / R.per);
      for (let k = k1; k >= 0 && k >= k1 - Math.ceil(R.life / R.per); k--) {
        const age = t - rockT0(R, k) - R.warn;
        if (age < 0 || age > R.life) continue;
        for (const q of rockWave(tr, k)) {
          const ex = c.x - q.x, ey = c.y - q.y, d = Math.hypot(ex, ey), lim = R.r + RAD * 0.85;
          if (d >= lim || d < 1e-4) continue;
          if (age < 0.15 && c.rockK !== k) { c.rockK = k; gHit(c, 'rock', () => { c.spin = c.spin0 = 0.8; c.vx *= 0.4; c.vy *= 0.4; }); ev |= 32768; }
          ev |= wallHit(c, -ex / d, -ey / d, lim - d, c.a);
        }
      }
    }
    for (const B of tr.balls) {
      if (idxDist(B.i, c.idx) * tr.ds > B.L + 6) continue;
      const st = ballAt(B, t);
      if (!st || !st.rolling) continue;
      const bx = B.x + tr.nx[B.i] * st.lat, by = B.y + tr.ny[B.i] * st.lat, ex = c.x - bx, ey = c.y - by, d = Math.hypot(ex, ey), lim = st.r + RAD * 0.85;
      if (d >= lim || d < 1e-4) continue;
      ev |= wallHit(c, -ex / d, -ey / d, lim - d, c.a);
      const id = st.k * 8 + B.k;
      if (c.ballP !== id) {
        c.ballP = id; ev |= 32768;
        gHit(c, 'ball', () => { c.vx = c.vx * 0.4 - tr.nx[B.i] * B.side * 10; c.vy = c.vy * 0.4 - tr.ny[B.i] * B.side * 10; c.spin = c.spin0 = 0.8; c.snowT = 1.4; });
      }
    }
    if (tr.traffic) for (const m of trafficCars(tr, t)) {
      if (Math.abs(m.x - c.x) > 6 || Math.abs(m.y - c.y) > 6) continue;
      const e2 = boxHit(c, m.x, m.y, m.a, TCAR_HX, TCAR_HY);
      if (e2 < 0) continue;
      ev |= e2;
      if (e2 & 128 && c.bumpT <= 0) { c.bumpT = 1; c.ghk = 'car'; ev |= 32768; }
    }
    for (const g of tr.gey) {
      if ((c.x - g.x) ** 2 + (c.y - g.y) ** 2 > (GEY_R + RAD * 0.6) ** 2 || geyS(g, t) !== 2) continue;
      const id = geyK(g, t) * 8 + g.k;
      if (c.gyK === id) continue;
      c.gyK = id; ev |= 32768;
      gHit(c, 'gey', () => { c.air = c.air0 = 0.75; c.spin = c.spin0 = 0.8; c.vx *= 0.45; c.vy *= 0.45; });
    }
    for (const T of tr.tw) {
      const p = twPos(tr, T, t), ex = p.x - c.x, ey = p.y - c.y, d2 = ex * ex + ey * ey;
      if (d2 > TW_PULL * TW_PULL) continue;
      const d = Math.sqrt(d2) || 1, k = 1 - d / TW_PULL;
      c.vx += ((ex / d) * 12 - (ey / d) * 9) * k * h; c.vy += ((ey / d) * 12 + (ex / d) * 9) * k * h; // pulled in and swirled round
      if (d < TW_CORE + RAD * 0.6 && c.twT <= 0) {
        c.twT = 1.6; ev |= 32768;
        gHit(c, 'tw', () => { c.air = c.air0 = 0.6; c.spin = c.spin0 = 1.0; c.vx = c.vx * 0.3 - (ex / d) * 9; c.vy = c.vy * 0.3 - (ey / d) * 9; });
      }
    }
    for (const m of tr.mag) {
      const ex = m.x - c.x, ey = m.y - c.y, d2 = ex * ex + ey * ey;
      if (d2 > MAG_R * MAG_R || c.mgT > 0 || magS(m, t) !== 2) continue;
      const d = Math.sqrt(d2) || 1, k = 1 - d / MAG_R;
      c.vx += (ex / d) * 21 * k * h; c.vy += (ey / d) * 21 * k * h;
      if (d < 2.4) {
        c.mgT = 2.2; ev |= 32768;
        gHit(c, 'mag', () => { c.stall = 0.8; c.vx = (Math.cos(c.a) * 4); c.vy = (Math.sin(c.a) * 4); });
      }
    }
    for (const Hd of tr.herd) { // sheep crossing: solid, and the first bump spins you a little
      if (idxDist(Hd.i, c.idx) * tr.ds > 16) continue;
      const st = herdAt(Hd, t);
      if (!st || st.tau < 0) continue;
      for (let j = 0; j < Hd.n; j++) {
        const lat = herdLat(Hd, j, st.tau);
        if (lat == null) continue;
        const al = herdAl(Hd, j), x = Hd.x + tr.tx[Hd.i] * al + tr.nx[Hd.i] * lat, y = Hd.y + tr.ty[Hd.i] * al + tr.ny[Hd.i] * lat;
        const ex = c.x - x, ey = c.y - y, d = Math.hypot(ex, ey), lim = HERD_R + carR(c) * 0.85;
        if (d >= lim || d < 1e-4) continue;
        ev |= wallHit(c, -ex / d, -ey / d, lim - d, c.a);
        const id = st.k * 16 + Hd.k;
        if (c.herdP !== id && c.v > 6) { c.herdP = id; ev |= 32768; gHit(c, 'herd', () => { c.spin = c.spin0 = 0.55; c.vx *= 0.5; c.vy *= 0.5; }); }
      }
    }
    return ev;
  }
  /* ----- round 12 per-car gimmicks ----- */
  function onFoam(z, ri, rlat) { const d = (((ri - z.i0) % NS) + NS) % NS, n = (((z.i1 - z.i0) % NS) + NS) % NS; return d <= n && Math.abs(rlat - z.lat) < 2.3; }
  /* jump ramps before chasms (the launch speed decides how far you fly), moon crater rims, slalom flags, boost rings */
  function jumpsAndGates(W, c, vf, ri) {
    const tr = W.tr;
    let ev = 0;
    for (const p of tr.leaps) {
      const q = frameOf(p, c);
      if (Math.abs(q.al) < 1.8 && Math.abs(q.lt) < tr.half + 1 && Math.cos(c.a - p.a) > 0 && vf > 4) {
        c.a += wrapA(p.a - c.a) * 0.7;
        c.vx = Math.cos(c.a) * vf; c.vy = Math.sin(c.a) * vf;
        c.air = c.air0 = (0.33 + vf / 55) * tr.lowg; c.drift = 0; c.charge = 0;
        return ev | 32 | 524288;
      }
    }
    for (const q of tr.crat) {
      const d = Math.hypot(c.x - q.x, c.y - q.y);
      if (Math.abs(d - q.r) < 0.8 && vf > 9 && c.crT <= 0) { c.crT = 0.5; c.air = c.air0 = (0.2 + vf / 110) * tr.lowg; ev |= 32; }
    }
    for (const g of tr.flags) {
      if (idxDist(g.i, ri) > 3) continue;
      const q = frameOf(g, c), key = c.crossed * 64 + g.k;
      if (Math.abs(q.al) < 1.1 && Math.abs(q.lt) < g.w - 0.5 && c.gateK !== key) { c.gateK = key; c.boost = Math.max(c.boost, 0.5); c.gk2 = 'flag'; ev |= 131072; }
    }
    for (const H of tr.hoops) {
      if (idxDist(H.i, ri) > 3) continue;
      const q = frameOf(H, c), key = c.crossed * 64 + 32 + H.k;
      if (Math.abs(q.al) < 1.1 && Math.abs(q.lt - hoopLat(H, W.clock)) < 2.1 && c.gateK !== key) { c.gateK = key; c.boost = Math.max(c.boost, 1.1); c.gk2 = 'hoop'; ev |= 131072; }
    }
    return ev;
  }
  /* the river crossing: two rafts (one per lane) that take turns, a pier between the lanes, rails, bank barriers and gates */
  function ferryStep(W, c) {
    const tr = W.tr, F = tr.fer, q = frameOf(F, c), half = tr.half, lim = RAD * 0.85;
    if (Math.abs(q.al) > F.wr + 9 || Math.abs(q.lt) > half + 7) return 0;
    c.fer = 0.4; // waiting for the boat is not being stuck
    const k = q.lt >= 0 ? 1 : 0, sg = k ? 1 : -1, R = raftAt(F, k, W.clock), back = R.p - FER_LR / 2, front = R.p + FER_LR / 2;
    const nX = -q.sa, nY = q.ca;
    let ev = 0;
    if (q.al > -F.wr - 7 && q.al < F.wr + 0.5) { // the pier between the lanes starts a little before the water
      const o = FER_PIER + lim - Math.abs(q.lt);
      if (o > 0) ev |= wallHit(c, -nX * sg, -nY * sg, o, F.a);
    }
    if (q.al > -F.wr && q.al < F.wr) { const o = Math.abs(q.lt) - (half - lim); if (o > 0) ev |= wallHit(c, nX * sg, nY * sg, o, F.a); }
    const onRaft = q.al > back - 0.8 && q.al < front + 0.8;
    if (!R.near && !onRaft && q.al > -F.wr - lim - 1 && q.al < -F.wr + 1.6) ev |= wallHit(c, q.ca, q.sa, q.al + F.wr + lim, F.a); // bank barrier is down
    if (onRaft && Math.abs(q.al) < F.wr + 0.6) { // the raft's gates move with it: keep the car between them at the raft's speed
      const vAl = c.vx * q.ca + c.vy * q.sa;
      if (!R.near && q.al < back + lim) { const o = back + lim - q.al; c.x += q.ca * o; c.y += q.sa * o; if (vAl < R.v) { c.vx += q.ca * (R.v - vAl); c.vy += q.sa * (R.v - vAl); } }
      if (!R.far && q.al > front - lim) { const o = q.al - front + lim; c.x -= q.ca * o; c.y -= q.sa * o; if (vAl > R.v) { c.vx -= q.ca * (vAl - R.v); c.vy -= q.sa * (vAl - R.v); } }
    }
    const q2 = frameOf(F, c);
    if (Math.abs(q2.al) < F.wr - 0.3 && !(q2.al > back - 0.3 && q2.al < front + 0.3)) { c.fallK = 'sea'; respawnAt(W, c, true); return ev | 16; }
    return ev;
  }
  /* drawbridges: down = road; rising / lowering = the near leaf is a ramp over the opening gap; standing up = wait */
  function dbStep(W, c) {
    const tr = W.tr, half = tr.half, lim = RAD * 0.85;
    let ev = 0;
    for (const B of tr.dbr) {
      const q = frameOf(B, c);
      if (Math.abs(q.al) > B.wr + 7 || Math.abs(q.lt) > half + 12) continue;
      c.fer = 0.4;
      if (Math.abs(q.al) < B.wr) { const sg = q.lt >= 0 ? 1 : -1, o = Math.abs(q.lt) - (half - lim); if (o > 0) ev |= wallHit(c, -q.sa * sg, q.ca * sg, o, B.a); } // railings over the canal
      const th = dbAng(B, W.clock);
      if (th < 0.12) continue;
      const gap = B.wr * (1 - Math.cos(th)), vf = c.vx * q.ca + c.vy * q.sa;
      if (th > DB_JUMP) { // standing up: the near hinge is a wall (cars on the far leaf just roll off)
        if (q.al > -B.wr - lim && q.al < 0) { const o = q.al + B.wr + lim; c.x -= q.ca * o; c.y -= q.sa * o; if (vf > 0) { c.vx -= q.ca * vf; c.vy -= q.sa * vf; } }
        continue;
      }
      if (q.al > -gap - 1.4 && q.al < -gap + 0.3 && vf > 3 && Math.cos(c.a - B.a) > 0) { // off the tip of the near leaf
        c.a += wrapA(B.a - c.a) * 0.7;
        const v0 = Math.max(vf, 6);
        c.vx = Math.cos(c.a) * v0; c.vy = Math.sin(c.a) * v0;
        c.air = c.air0 = 0.3 + v0 / 60 + th * 0.5; c.drift = 0; c.charge = 0;
        ev |= 32 | 524288;
        continue;
      }
      if (Math.abs(q.al) < gap - 0.3) { c.fallK = 'sea'; respawnAt(W, c, true); return ev | 16; }
    }
    return ev;
  }
  function wallHit(c, nx, ny, over, ta, bouncy) {
    c.x -= nx * (over + 0.03); c.y -= ny * (over + 0.03); // a hair of extra room so a scrape never re-catches the wall
    const vn = c.vx * nx + c.vy * ny;
    if (vn <= 0) return 0;
    if (vn > WALL_D0) { // a hard head-on knock dents the car; scrapes and bumping along the same wall right after cost little
      c.dmg += Math.min(HIT_MAX, (vn - WALL_D0) * WALL_DK * (bouncy ? 0.35 : 1)) * (c.wallCd > 0 ? 0.25 : 1);
      c.wallCd = 3;
    }
    if (bouncy && vn > 1.5) { // candy-cane walls: a springy kick back toward the road
      const k = 4 + vn * 0.9;
      c.vx -= nx * (vn + k); c.vy -= ny * (vn + k);
      const fa = Math.cos(c.a - ta) >= 0 ? ta : ta + Math.PI;
      c.a += wrapA(fa - c.a) * 0.35;
      if (c.drift) { c.drift = 0; c.charge = 0; }
      return 256;
    }
    c.vx -= nx * vn * 1.35; c.vy -= ny * vn * 1.35;
    const k = 1 - Math.min(0.28, Math.max(0, vn - 2) * 0.018); // light scrapes keep their speed
    c.vx *= k; c.vy *= k;
    // nudge the nose along the wall so a scrape doesn't stall the car
    const fa = Math.cos(c.a - ta) >= 0 ? ta : ta + Math.PI;
    c.a += wrapA(fa - c.a) * Math.min(1, 0.2 + vn * 0.03);
    if (c.drift && vn > 6) { c.drift = 0; c.charge = 0; }
    return vn > 4 ? 128 : 0;
  }

  /* car-car contact (only same level on the figure-eight bridge) */
  function collideCars(W, onBump) {
    const cs = W.cars;
    for (let i = 0; i < cs.length; i++) for (let j = i + 1; j < cs.length; j++) {
      const a = cs[i], b = cs[j];
      if ((a.remote && b.remote) || a.out || b.out || W.clock < START_GHOST || a.resp > 0 || b.resp > 0 || a.air > 0 || b.air > 0 || a.warpN > 0 || b.warpN > 0 || a.ghost > 0 || b.ghost > 0 || a.lvl !== b.lvl) continue;
      const dx = b.x - a.x, dy = b.y - a.y, d2 = dx * dx + dy * dy, RR = carR(a) + carR(b);
      if (d2 >= RR * RR || d2 < 1e-6) continue;
      const d = Math.sqrt(d2), nx = dx / d, ny = dy / d, ov = RR - d;
      // 거대화: a giant car is heavy — it barely moves and shoves the other one away (a short spin)
      const ga = a.giant > 0, gb = b.giant > 0, ma = ga && !gb ? 0.1 : !ga && gb ? 0.9 : 0.5;
      let rel = 0;
      if (!a.remote && !b.remote) {
        a.x -= nx * ov * ma; a.y -= ny * ov * ma; b.x += nx * ov * (1 - ma); b.y += ny * ov * (1 - ma);
        const va = a.vx * nx + a.vy * ny, vb = b.vx * nx + b.vy * ny;
        rel = va - vb;
        if (rel > 0) { const k = rel * 1.2; a.vx -= nx * k * ma; a.vy -= ny * k * ma; b.vx += nx * k * (1 - ma); b.vy += ny * k * (1 - ma); }
        if (rel > CAR_D0) { // the car that drove into the other one takes most of the damage
          const d = Math.min(HIT_MAX, (rel - CAR_D0) * CAR_DK), sa = U.clamp(va / rel, 0, 1), sb = U.clamp(-vb / rel, 0, 1);
          if (!ga) ramDmg(W, a, d, sa); if (!gb) ramDmg(W, b, d, sb);
        }
      } else {
        const me = a.remote ? b : a, sgn = a.remote ? 1 : -1, myK = (a.remote ? 1 - ma : ma) * 2;
        me.x += nx * ov * sgn * Math.min(1, myK); me.y += ny * ov * sgn * Math.min(1, myK);
        const vn = (me.vx * nx + me.vy * ny) * sgn;
        rel = -vn;
        if (vn < 0) { me.vx -= nx * vn * sgn * 1.4 * Math.min(1, myK); me.vy -= ny * vn * sgn * 1.4 * Math.min(1, myK); }
        const o = a.remote ? a : b, oa = sgn * (Math.cos(o.a) * (o.v || 0) * nx + Math.sin(o.a) * (o.v || 0) * ny), rf = -vn + Math.max(0, oa); // remote car: velocity from its snapshot
        if (rf > CAR_D0 && !(me.giant > 0)) ramDmg(W, me, Math.min(HIT_MAX, (rf - CAR_D0) * CAR_DK), U.clamp(Math.max(0, -vn) / rf, 0, 1));
      }
      if (ga !== gb) {
        const v = ga ? b : a, sg = ga ? 1 : -1; // the small car flies off
        if (!v.remote && v.bumpT <= 0) {
          v.bumpT = 0.8;
          if (v.shield > 0) { v.shield = 0; v.flash = 0.5; }
          else { v.vx += nx * sg * 16; v.vy += ny * sg * 16; v.spin = v.spin0 = 0.6; v.drift = 0; v.charge = 0; v.boost = 0; v.dmg += ITEM_DMG.giant; }
          if (onBump) onBump(a, b, 99, v);
          continue;
        }
      }
      if ((a.bomb > 0) !== (b.bomb > 0)) bombPass(W, a.bomb > 0 ? a : b, a.bomb > 0 ? b : a);
      if (rel > 5 && onBump) onBump(a, b, rel);
    }
  }
  /* 째깍 폭탄: touching another car hands the bomb over (a remote car gets it through a 'pass' message) */
  function bombPass(W, from, to) {
    if (from.remote || from.bombImm > 0 || to.bombImm > 0 || gone(to) || to.resp > 0) return;
    if (to.remote) addHz(W, { id: spawnId(W, from.seat), t: 'pass', o: from.seat, tg: to.seat, fuse: from.bomb, x: to.x, y: to.y, a: 0, life: 1.5, idx: to.idx, lvl: to.lvl });
    else to.bomb = from.bomb;
    from.bomb = 0; from.bombImm = to.bombImm = 0.8;
    W.ev.push({ k: 'pass', s: from.seat, o: to.seat });
  }

  /* ---------- items & hazards (pure) ----------
     W.hz: id -> {id, t, o (owner seat), x, y, a, tg, age, life, idx, lvl, loc (spawned on this device)}
     Remote hazards are ingested by the view with loc=false and dead-reckoned. Hits are detected only for local cars. */
  /* seat of the closest unfinished car ahead in the standings, or -1 */
  function carAhead(W, c) {
    const rk = ranking(W), my = rk.indexOf(c);
    for (let k = my - 1; k >= 0; k--) if (!gone(rk[k])) return rk[k].seat;
    return -1;
  }
  const frostOn = (z) => (z.loc ? z.age >= FROST_FLY : !!z.land);
  function spawnId(W, seat) { W.nid = (W.nid + 1) % 1000; return seat + '.' + W.nid; }
  function addHz(W, o) { o.age = 0; o.loc = true; W.hz[o.id] = o; return o; }
  function useItem(W, c) {
    if (!c.item || c.roll > 0 || c.resp > 0) return false;
    const it = c.item, tr = W.tr, ca = Math.cos(c.a), sa = Math.sin(c.a);
    const id = spawnId(W, c.seat);
    if (it === 'turbo' || it === 'turbo3') { c.boost = Math.max(c.boost, 1.3); W.ev.push({ k: 'turbo', s: c.seat }); }
    else if (it === 'shield') { c.shield = 12; W.ev.push({ k: 'shield', s: c.seat }); }
    else if (it === 'oil') {
      const x = c.x - ca * 4.2, y = c.y - sa * 4.2;
      addHz(W, { id, t: 'oil', o: c.seat, x, y, a: c.a, life: 30, idx: locate(tr, x, y, c.idx), lvl: c.lvl });
      W.ev.push({ k: 'drop', s: c.seat });
    } else if (it === 'rocket' || it === 'homing') {
      const tg = it === 'homing' ? carAhead(W, c) : -1;
      const sp = Math.max(c.v, 0);
      addHz(W, { id, t: tg >= 0 ? 'homing' : 'rocket', o: c.seat, x: c.x + ca * 3.2, y: c.y + sa * 3.2, a: c.a, v: (tg >= 0 ? HOMING_V : ROCKET_V) + sp * 0.4, tg, life: tg >= 0 ? 7 : 2.2, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: 'fire', s: c.seat });
    } else if (it === 'cloud') {
      addHz(W, { id, t: 'cloud', o: c.seat, x: c.x, y: c.y, a: 0, p: Math.round(progress(c) * 1000) / 1000, life: 3 });
      W.ev.push({ k: 'cloud', s: c.seat });
    } else if (it === 'magnet') { // locks onto the car right ahead in the standings
      const tg = carAhead(W, c);
      c.mag = 3; c.magT = tg;
      if (tg < 0) c.boost = Math.max(c.boost, 0.9);
      W.ev.push({ k: 'mag', s: c.seat });
    } else if (it === 'spring' || it === 'smoke') {
      const back = it === 'smoke' ? 5.5 : 4.2, x = c.x - ca * back, y = c.y - sa * back;
      addHz(W, { id, t: it, o: c.seat, x, y, a: c.a, life: it === 'smoke' ? 8 : 25, idx: locate(tr, x, y, c.idx), lvl: c.lvl });
      W.ev.push({ k: it === 'smoke' ? 'smoke' : 'drop', s: c.seat });
    } else if (it === 'warp') {
      c.warpN = Math.round(WARP_D / tr.ds); c.warpLat = U.clamp(fin(c.lat) ? c.lat : 0, -tr.half + 2, tr.half - 2);
      c.air = 0; c.slow = 0;
      W.ev.push({ k: 'warp', s: c.seat, x: c.x, y: c.y });
    } else if (it === 'frost') { // lobbed forward along the course, lands as an ice patch
      const lat = U.clamp(fin(c.lat) ? c.lat : 0, -tr.half + 1.5, tr.half - 1.5);
      addHz(W, { id, t: 'frost', o: c.seat, x: c.x, y: c.y, a: c.a, i0: c.idx, lat, d: 3, v: 44 + Math.max(c.v, 0) * 0.3, life: FROST_FLY + 7, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: 'fire', s: c.seat });
    } else if (it === 'mirror') { c.mirror = 8; W.ev.push({ k: 'mirror', s: c.seat }); }
    else if (it === 'giant') { c.giant = 5; W.ev.push({ k: 'giant', s: c.seat }); }
    else if (it === 'boom') {
      addHz(W, { id, t: 'boom', o: c.seat, x: c.x + ca * 3.2, y: c.y + sa * 3.2, a: c.a, v: 44 + Math.max(c.v, 0) * 0.4, life: 3.4, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: 'fire', s: c.seat });
    } else if (it === 'tacks') { // a wide strip of tacks behind the car
      const x = c.x - ca * 4.8, y = c.y - sa * 4.8;
      addHz(W, { id, t: 'tacks', o: c.seat, x, y, a: c.a, life: 14, idx: locate(tr, x, y, c.idx), lvl: c.lvl });
      W.ev.push({ k: 'drop', s: c.seat });
    } else if (it === 'shock') {
      addHz(W, { id, t: 'shock', o: c.seat, x: c.x, y: c.y, a: 0, life: 0.45, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: 'shock', s: c.seat, x: c.x, y: c.y });
    } else if (it === 'net') {
      addHz(W, { id, t: 'net', o: c.seat, x: c.x + ca * 3.2, y: c.y + sa * 3.2, a: c.a, v: 50 + Math.max(c.v, 0) * 0.4, tg: -1, life: 1.9, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: 'fire', s: c.seat });
    } else if (it === 'ghost') { c.ghost = 4; W.ev.push({ k: 'ghost', s: c.seat }); }
    else if (it === 'hop') { c.air = c.air0 = 0.85; c.drift = 0; c.charge = 0; W.ev.push({ k: 'hop', s: c.seat }); }
    else if (it === 'tire') { c.tire = 6; W.ev.push({ k: 'tire', s: c.seat }); }
    else if (it === 'balloon') { c.flt = 3; c.drift = 0; c.charge = 0; W.ev.push({ k: 'balloon', s: c.seat }); }
    else if (it === 'auto') { c.auto = 4; W.ev.push({ k: 'auto', s: c.seat }); }
    else if (it === 'drone') { c.drone = 2; c.droneT = 12; W.ev.push({ k: 'drone', s: c.seat }); }
    else if (it === 'fw' || it === 'paint' || it === 'rear') {
      const sp = Math.max(c.v, 0);
      if (it === 'fw') for (const da of [-0.22, 0, 0.22]) addHz(W, { id: da ? spawnId(W, c.seat) : id, t: 'fw', o: c.seat, x: c.x + ca * 3, y: c.y + sa * 3, a: c.a + da, v: 58 + sp * 0.4, life: 0.8, idx: c.idx, lvl: c.lvl });
      else if (it === 'paint') addHz(W, { id, t: 'paint', o: c.seat, x: c.x + ca * 3.2, y: c.y + sa * 3.2, a: c.a, v: 48 + sp * 0.4, life: 1.6, idx: c.idx, lvl: c.lvl });
      else addHz(W, { id, t: 'cball', o: c.seat, x: c.x - ca * 3.4, y: c.y - sa * 3.4, a: wrapA(c.a + Math.PI), v: 52, life: 1.8, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: it === 'rear' ? 'rear' : 'fire', s: c.seat });
    } else if (it === 'bees' || it === 'bomb') { // both chase the car right ahead in the standings
      const tg = carAhead(W, c), sp = Math.max(c.v, 0);
      addHz(W, { id, t: it, o: c.seat, x: c.x + ca * 3, y: c.y + sa * 3, a: c.a, v: (it === 'bees' ? 40 : 50) + sp * 0.4, tg, life: tg >= 0 ? 7 : 1.6, idx: c.idx, lvl: c.lvl });
      W.ev.push({ k: 'fire', s: c.seat });
    } else if (it === 'wall' || it === 'vort') {
      const x = c.x - ca * 5.5, y = c.y - sa * 5.5;
      addHz(W, { id, t: it, o: c.seat, x, y, a: c.a, life: it === 'wall' ? 12 : 10, idx: locate(tr, x, y, c.idx), lvl: c.lvl });
      W.ev.push({ k: 'drop', s: c.seat });
    } else if (it === 'foam') { // a slippery stripe along the course behind the car, in its lane
      const i1 = (c.idx - 2 + NS) % NS, i0 = (i1 - Math.round(28 / tr.ds) + NS) % NS, im = (i1 - Math.round(14 / tr.ds) + NS) % NS;
      const lat = U.clamp(fin(c.lat) ? c.lat : 0, -tr.half + 1.6, tr.half - 1.6);
      addHz(W, { id, t: 'foam', o: c.seat, x: tr.x[im] + tr.nx[im] * lat, y: tr.y[im] + tr.ny[im] * lat, a: 0, i0, i1, lat, life: 12, idx: im, lvl: c.lvl });
      W.ev.push({ k: 'foam', s: c.seat });
    } else if (it === 'blow') {
      addHz(W, { id, t: 'blow', o: c.seat, x: c.x, y: c.y, a: c.a, life: 0.35, idx: c.idx, lvl: c.lvl });
      blowTraps(W, c);
      W.ev.push({ k: 'blow', s: c.seat, x: c.x, y: c.y });
    }
    else if (it === 'steal') { // 집게 손: takes the item of the nearest car ahead (in the standings) that holds one
      const rk = ranking(W), my = rk.indexOf(c);
      let tg = null;
      for (let k = my - 1; k >= 0; k--) { const o = rk[k]; if (!gone(o) && o.item && o.roll <= 0 && o.item !== 'steal') { tg = o; break; } }
      c.item = null; c.itemN = 0; c.holdT = 0;
      if (tg) {
        addHz(W, { id, t: 'grab', o: c.seat, tg: tg.seat, x: tg.x, y: tg.y, a: 0, life: 1.2, idx: tg.idx, lvl: tg.lvl });
        c.item = tg.item; c.itemN = tg.item === 'turbo3' ? Math.max(1, tg.itemN | 0) : 1; c.roll = 0.35;
        W.ev.push({ k: 'steal', s: c.seat, o: tg.seat, it: tg.item });
      } else { c.boost = Math.max(c.boost, 1.0); W.ev.push({ k: 'turbo', s: c.seat }); }
      return true;
    }
    if (it === 'turbo3' && c.itemN > 1) c.itemN--;
    else { c.item = null; c.itemN = 0; }
    c.holdT = 0;
    return true;
  }
  /* advance hazards owned here */
  function moveHazards(W, h) {
    const tr = W.tr;
    for (const id in W.hz) {
      const z = W.hz[id];
      z.age += h;
      if (!z.loc) { // dead-reckon remote projectiles between snapshots
        if (FLY[z.t] && z.age < 1.2) { z.x += Math.cos(z.a) * z.v * h; z.y += Math.sin(z.a) * z.v * h; }
        continue; // staleness is handled by the view (owner stopped listing it / owner gone)
      }
      if (z.age > z.life) { delete W.hz[id]; continue; }
      if (z.t === 'frost') {
        if (z.age - h < FROST_FLY) {
          z.d += z.v * h;
          const j = (z.i0 + Math.round(z.d / tr.ds)) % NS;
          z.idx = j; z.x = tr.x[j] + tr.nx[j] * z.lat; z.y = tr.y[j] + tr.ny[j] * z.lat; z.lvl = levelOf(tr, j);
          if (z.age >= FROST_FLY) { z.landAt = W.clock; W.ev.push({ k: 'frost', x: z.x, y: z.y, s: z.o }); }
        }
        continue;
      }
      if (z.t === 'boom') { // out for ~0.8 s, then curls back to its thrower
        const oc = W.cars[z.o];
        if (z.age > 0.8 && oc && oc.resp <= 0) {
          const dx = oc.x - z.x, dy = oc.y - z.y, d = Math.hypot(dx, dy);
          if (d < 3.2 && z.age > 1.1) { delete W.hz[id]; continue; } // caught
          const da = wrapA(Math.atan2(dy, dx) - z.a), mx = 4.2 * h;
          z.a += U.clamp(da, -mx, mx);
          z.v = Math.max(z.v, (oc.v || 0) + 14);
        }
        z.x += Math.cos(z.a) * z.v * h; z.y += Math.sin(z.a) * z.v * h;
        z.idx = locate(tr, z.x, z.y, z.idx); z.lvl = levelOf(tr, z.idx);
        const lat = Math.abs((z.x - tr.x[z.idx]) * tr.nx[z.idx] + (z.y - tr.y[z.idx]) * tr.ny[z.idx]);
        if (lat > tr.half + 22) { W.ev.push({ k: 'burst', x: z.x, y: z.y }); delete W.hz[id]; }
        continue;
      }
      if (FLY[z.t]) {
        if (z.t === 'homing' || ((z.t === 'bees' || z.t === 'bomb') && z.tg >= 0)) {
          const tc = W.cars[z.tg];
          if (!tc || gone(tc)) { if (z.t === 'homing') z.t = 'rocket'; else z.tg = -1; }
          else {
            const dx = tc.x - z.x, dy = tc.y - z.y, d = Math.hypot(dx, dy);
            let want;
            if (d < 22 && z.lvl === tc.lvl) want = Math.atan2(dy, dx);
            else { // follow the course (backwards for one bounced off a mirror)
              const ti = (z.idx + (z.back ? -1 : 1) * Math.round(9 / tr.ds) + NS) % NS;
              want = Math.atan2(tr.y[ti] - z.y, tr.x[ti] - z.x);
            }
            const da = wrapA(want - z.a), mx = 7 * h;
            z.a += U.clamp(da, -mx, mx);
          }
        }
        z.x += Math.cos(z.a) * z.v * h; z.y += Math.sin(z.a) * z.v * h;
        z.idx = locate(tr, z.x, z.y, z.idx);
        z.lvl = levelOf(tr, z.idx);
        const lat = Math.abs((z.x - tr.x[z.idx]) * tr.nx[z.idx] + (z.y - tr.y[z.idx]) * tr.ny[z.idx]);
        const pr = tr.cuts.length ? cutProbe(tr, z.x, z.y) : null;
        const onCut = pr && pr.d < pr.C.hw;
        // rockets burst on walls (walled tracks) or once well off the course
        if (!onCut && ((tr.wall != null && lat > tr.half + tr.wall) || lat > tr.half + 16)) { W.ev.push({ k: 'burst', x: z.x, y: z.y }); delete W.hz[id]; }
      }
    }
  }
  /* 송풍기: blows away the traps in front (remote ones are reported as eaten so their owner removes them) */
  function blowTraps(W, c) {
    const ca = Math.cos(c.a), sa = Math.sin(c.a);
    for (const id in W.hz) {
      const z = W.hz[id];
      if (!(z.t === 'oil' || z.t === 'spring' || z.t === 'tacks' || z.t === 'frost' || z.t === 'wall' || z.t === 'vort' || z.t === 'foam' || z.t === 'smoke')) continue;
      const dx = z.x - c.x, dy = z.y - c.y, al = dx * ca + dy * sa, lt = -dx * sa + dy * ca;
      if (al < -2 || al > 24 || Math.abs(lt) > 4 + Math.max(0, al) * 0.45) continue;
      W.ev.push({ k: 'burst', x: z.x, y: z.y });
      if (!z.loc) { W.eaten[id] = W.clock; W.eatQ.push(id); }
      delete W.hz[id];
    }
  }
  const SHOT = { rocket: 1, homing: 1, net: 1, boom: 1, fw: 1, paint: 1, cball: 1, bees: 1, bomb: 1 };
  /* hits against cars simulated on this device. Returns ids consumed (to publish when owner is remote).
     Area hazards (smoke, frost, boomerang) are never consumed: each car is affected at most once (W.applied[id:seat]). */
  function hitTest(W, onHit) {
    const eaten = [];
    for (const id in W.hz) {
      const z = W.hz[id];
      if (W.eaten[id]) continue;
      for (const c of W.cars) {
        if (c.remote || c.resp > 0 || c.out) continue;
        if (z.t === 'grab') { // 집게 손: the victim loses its item (whatever it is doing)
          const key = id + ':' + c.seat;
          if (c.seat !== z.tg || W.applied[key]) continue;
          W.applied[key] = 1;
          if (c.item && c.roll <= 0) { c.item = null; c.itemN = 0; W.ev.push({ k: 'stolen', s: c.seat, o: z.o }); }
          continue;
        }
        if (z.t === 'cloud') {
          if (W.applied[id] || c.seat === z.o || c.fin != null || c.ghost > 0) continue;
          if (progress(c) > z.p) { hitCar(W, c, z, onHit); }
          continue;
        }
        if (z.t === 'pass') { // a bomb handed over by a car on another device
          const key = id + ':' + c.seat;
          if (c.seat !== z.tg || W.applied[key]) continue;
          W.applied[key] = 1;
          if (!(c.bomb > 0) && c.fin == null) { c.bomb = U.clamp(fin(z.fuse) ? z.fuse : 2, 0.3, 3); c.bombImm = 0.8; W.ev.push({ k: 'gotbomb', s: c.seat }); }
          continue;
        }
        const d2 = (c.x - z.x) ** 2 + (c.y - z.y) ** 2;
        if (SHOT[z.t] && c.drone > 0 && z.o !== c.seat && d2 < 144 && (z.lvl | 0) === c.lvl) { // 호위 드론 shoots it down
          if (--c.drone <= 0) c.droneT = 0;
          W.ev.push({ k: 'zap', s: c.seat, x: z.x, y: z.y });
          W.eaten[id] = W.clock; eaten.push(id); delete W.hz[id];
          break;
        }
        if (c.air > 0 || c.warpN > 0 || c.ghost > 0 || (z.lvl | 0) !== c.lvl) continue;
        if (c.flt > 0 && (z.t === 'oil' || z.t === 'spring' || z.t === 'tacks' || z.t === 'frost' || z.t === 'wall')) continue; // floating over the traps
        const key = id + ':' + c.seat;
        if (z.t === 'tacks') { // a strip across the road: each car once
          if ((c.seat === z.o && z.age < 1.5) || W.applied[key] || d2 > 49) continue;
          const ex = c.x - z.x, ey = c.y - z.y, cz = Math.cos(z.a || 0), sz = Math.sin(z.a || 0);
          if (Math.abs(ex * cz + ey * sz) < 1.6 + carR(c) * 0.4 && Math.abs(-ex * sz + ey * cz) < 4.6 + carR(c) * 0.4) { W.applied[key] = 1; hitCar(W, c, z, onHit); }
          continue;
        }
        if (z.t === 'shock') {
          if (c.seat === z.o || W.applied[key] || d2 > (10 + carR(c) - RAD) ** 2) continue;
          W.applied[key] = 1; hitCar(W, c, z, onHit);
          continue;
        }
        if (z.t === 'blow') { // a cone in front of the blower
          if (c.seat === z.o || W.applied[key]) continue;
          const ex = c.x - z.x, ey = c.y - z.y, cz = Math.cos(z.a), sz = Math.sin(z.a), al = ex * cz + ey * sz, lt = -ex * sz + ey * cz;
          if (al > 0 && al < 22 && Math.abs(lt) < 3 + al * 0.45) { W.applied[key] = 1; hitCar(W, c, z, onHit); }
          continue;
        }
        if (z.t === 'vort' || z.t === 'foam') continue; // area traps act in stepCar
        if (z.t === 'smoke' || z.t === 'frost' || z.t === 'boom') {
          if (c.seat === z.o || W.applied[key]) continue;
          if (z.t === 'smoke') { if (d2 < SMOKE_R * SMOKE_R) { W.applied[key] = 1; c.blind = 3; W.ev.push({ k: 'hit', s: c.seat, t: 'smoke', o: z.o }); if (onHit) onHit(c, z, false); } }
          else if (z.t === 'frost') { // freezes cars caught right where it lands (afterwards it is just slippery)
            if (!frostOn(z) || !(W.clock - (z.landAt != null ? z.landAt : -9) < 0.5)) continue;
            if (d2 < (FROST_R + 0.5) ** 2) { W.applied[key] = 1; hitCar(W, c, z, onHit); }
          } else if (d2 < (2.6 + carR(c) - RAD) ** 2) { W.applied[key] = 1; hitCar(W, c, z, onHit); }
          continue;
        }
        if (c.seat === z.o && z.age < (z.t === 'oil' || z.t === 'spring' || z.t === 'wall' ? 1.2 : 0.6)) continue;
        if (z.t === 'wall') { // a barrier across the lane: distance to the segment
          if (d2 > 49) continue;
          const ex = c.x - z.x, ey = c.y - z.y, cz = Math.cos(z.a), sz = Math.sin(z.a), al = ex * cz + ey * sz, lt0 = -ex * sz + ey * cz, lt = U.clamp(lt0, -3.2, 3.2);
          if (Math.hypot(al, lt0 - lt) > 0.7 + carR(c) * 0.8) continue;
        } else {
          const r = (z.t === 'oil' ? 2.9 : z.t === 'net' || z.t === 'paint' ? 3 : z.t === 'fw' ? 2.2 : 2.6) + carR(c) - RAD;
          if (d2 > r * r) continue;
        }
        if (c.mirror > 0 && (z.t === 'rocket' || z.t === 'homing' || z.t === 'cball') && c.seat !== z.o && c.shield <= 0) reflect(W, c, z, onHit);
        else hitCar(W, c, z, onHit);
        W.eaten[id] = W.clock;
        eaten.push(id);
        delete W.hz[id];
        break;
      }
      if (z.t === 'cloud' && !W.applied[id]) W.applied[id] = 1; // a cloud strikes each local car once
    }
    return eaten;
  }
  /* 반사 방패: the projectile is consumed here and a new one, owned by the reflecting car, flies back at its thrower */
  function reflect(W, c, z, onHit) {
    const oc = W.cars[z.o], tg = oc && !gone(oc) && oc !== c ? z.o : -1;
    addHz(W, { id: spawnId(W, c.seat), t: tg >= 0 ? 'homing' : 'rocket', o: c.seat, x: c.x, y: c.y, a: wrapA(z.a + Math.PI), v: HOMING_V + 8, tg, back: 1, life: 5, idx: c.idx, lvl: c.lvl });
    c.flash = 0.4;
    W.ev.push({ k: 'reflect', s: c.seat, o: z.o });
  }
  function hitCar(W, c, z, onHit) {
    if (c.shield > 0) { c.shield = 0; c.flash = 0.5; W.ev.push({ k: 'block', s: c.seat }); if (onHit) onHit(c, z, true); return; }
    if (c.flt > 0 && SHOT[z.t]) { c.flt = 0; W.ev.push({ k: 'popped', s: c.seat }); } // a shot pops the balloon
    if (c.giant > 0 && z.t !== 'cloud') { // a giant car squashes traps; a hit only shrinks it back
      if (z.t === 'oil' || z.t === 'spring' || z.t === 'frost' || z.t === 'tacks' || z.t === 'wall') { W.ev.push({ k: 'squash', s: c.seat, t: z.t }); return; }
      c.giant = 0; c.flash = 0.4; c.vx *= 0.7; c.vy *= 0.7;
      W.ev.push({ k: 'hit', s: c.seat, t: 'shrink', o: z.o });
      if (onHit) onHit(c, z, false);
      return;
    }
    const kill = () => { c.drift = 0; c.charge = 0; c.boost = 0; };
    if (z.t === 'cloud') { c.slow = 2.5; c.flash = 0.6; c.drift = 0; c.charge = 0; }
    else if (z.t === 'spring') { kill(); c.air = c.air0 = 0.95; c.vx *= 0.35; c.vy *= 0.35; c.spin = c.spin0 = 0.95; } // boing: up, round and down
    else if (z.t === 'frost') { kill(); c.stall = c.frz = 1.1; c.vx *= 0.15; c.vy *= 0.15; }
    else if (z.t === 'boom') { kill(); c.spin = c.spin0 = 0.9; c.vx *= 0.45; c.vy *= 0.45; }
    else if (z.t === 'tacks') { c.flat = 1.7; c.drift = 0; c.charge = 0; c.boost = 0; }
    else if (z.t === 'net') { kill(); c.net = 1.8; c.vx *= 0.55; c.vy *= 0.55; }
    else if (z.t === 'shock') { kill(); const ex = c.x - z.x, ey = c.y - z.y, d = Math.hypot(ex, ey) || 1; c.spin = c.spin0 = 0.7; c.vx = c.vx * 0.5 + (ex / d) * 12; c.vy = c.vy * 0.5 + (ey / d) * 12; }
    else if (z.t === 'fw') { kill(); c.spin = c.spin0 = 0.8; c.vx *= 0.5; c.vy *= 0.5; }
    else if (z.t === 'paint') { c.paint = 3; c.vx *= 0.85; c.vy *= 0.85; }
    else if (z.t === 'bees') c.bee = 3;
    else if (z.t === 'bomb') { if (!(c.bomb > 0)) c.bomb = 3; c.bombImm = 0.8; }
    else if (z.t === 'wall') { kill(); c.vx *= 0.25; c.vy *= 0.25; c.stall = 0.25; }
    else if (z.t === 'blow') { kill(); const sd = -(c.x - z.x) * Math.sin(z.a) + (c.y - z.y) * Math.cos(z.a) >= 0 ? 1 : -1, k = c.flt > 0 ? 26 : 15; c.vx += -Math.sin(z.a) * sd * k; c.vy += Math.cos(z.a) * sd * k; c.spin = c.spin0 = 0.4; }
    else {
      const big = z.t !== 'oil';
      c.spin = c.spin0 = big ? 1.35 : 1.05; c.drift = 0; c.charge = 0; c.boost = 0;
      if (big) { c.air = c.air0 = 0.4; c.vx *= 0.25; c.vy *= 0.25; }
      else { c.vx *= 0.6; c.vy *= 0.6; }
    }
    c.dmg += ITEM_DMG[z.t] || 0;
    W.ev.push({ k: 'hit', s: c.seat, t: z.t, o: z.o });
    if (onHit) onHit(c, z, false);
  }
  const LEAD_SWAP = { homing: 'rocket', steal: 'shock', bees: 'fw', bomb: 'rear' };
  /* item boxes: deterministic positions; boxT[id] = race-clock ms when it reappears */
  function boxUp(W, id) { return !(W.boxT[id] > W.clock * 1000); }
  function pickBoxes(W, h, rnd) {
    const tr = W.tr, nowMs = W.clock * 1000;
    let rk = null;
    for (const c of W.cars) {
      if (c.roll > 0) {
        c.roll -= h;
        if (c.roll <= 0) { c.roll = 0; W.ev.push({ k: 'got', s: c.seat, it: c.item }); }
      }
      if (c.remote || c.resp > 0 || gone(c)) continue;
      for (const b of tr.boxes) {
        if (!boxUp(W, b.id)) continue;
        if ((c.x - b.x) ** 2 + (c.y - b.y) ** 2 > (RAD + BOX_R + (b.show ? 0.6 : 0)) ** 2) continue;
        if (b.show && (c.item || c.flt > 0)) continue; // a stand keeps its item for someone with empty hands
        W.boxT[b.id] = nowMs + BOX_RESPAWN;
        W.myBox[b.id] = Math.round(nowMs);
        W.ev.push({ k: 'box', s: c.seat, x: b.x, y: b.y });
        if (!c.item) {
          if (!rk) rk = ranking(W).filter((o) => !o.out); // wrecks don't count for the item odds
          const rank = rk.indexOf(c);
          let it = b.show ? showItem(b, W.clock) : rollItem(rank, rk.length, rnd, rank > 0 ? progress(rk[0]) - progress(c) : 0);
          if (rank === 0 && LEAD_SWAP[it]) it = LEAD_SWAP[it]; // nothing to chase when you lead
          if (it === 'cloud' && rank !== rk.length - 1) it = 'turbo3';
          c.item = it; c.itemN = it === 'turbo3' ? 3 : 1; c.roll = b.show ? 0.25 : 1.0; c.holdT = 0;
        }
      }
    }
  }

  /* ---------- AI ----------
     Each AI car has its own level c.ailv (1 쉬움 / 2 보통 / 3 어려움, from api.players[seat].lv):
     top speed (pow), racing line (skill: lookahead, inside line, corner speed, noise), item timing / aim, catch-up. */
  function setAiLevel(c, lv) {
    lv = U.clamp((lv | 0) || 2, 1, 3); c.ailv = lv;
    if (lv === 1) { c.skill = 0.1 + Math.random() * 0.2; c.pow = 0.83 + Math.random() * 0.03; }
    else if (lv === 3) { c.skill = 0.92 + Math.random() * 0.08; c.pow = 0.965 + Math.random() * 0.02; }
    else { c.skill = 0.4 + Math.random() * 0.5; c.pow = 0.87 + c.skill * 0.08; }
  }
  /* catch-up: compares with the best human car (or the leader when there are no humans). Easy cars ease off when
     they get ahead and barely push when behind; hard cars push hard when behind and hardly ease off. */
  const RB_BEHIND = [0, 0.02, 0.05, 0.1], RB_AHEAD = [0, 0.12, 0.05, 0.015];
  function rubber(W, c) {
    let ref = -1e9, hum = false;
    for (const o of W.cars) if (o !== c && !o.ailv && !o.out) { hum = true; ref = Math.max(ref, progress(o)); }
    if (!hum) for (const o of W.cars) if (o !== c && !o.out) ref = Math.max(ref, progress(o));
    if (ref < -1e8) return 1;
    const lv = c.ailv || 2, gap = (ref - progress(c)) * NS * W.tr.ds; // metres, > 0 = behind
    return gap > 0 ? 1 + RB_BEHIND[lv] * U.clamp((gap - 8) / 60, 0, 1) : 1 - RB_AHEAD[lv] * U.clamp((-gap - 8) / 50, 0, 1);
  }
  function aiInput(W, c, h, lvO) {
    const tr = W.tr, sp = Math.max(0, c.v), lv = lvO || c.ailv || 2, skill = lvO ? 0.95 : c.skill;
    c.hold = 0;
    c.laneT -= h;
    if (c.laneT <= 0) { c.laneT = 1.5 + Math.random() * 3; c.laneGoal = (Math.random() * 2 - 1) * tr.half * (lv === 1 ? 0.65 : lv === 3 ? 0.25 : 0.4); }
    c.lane += (c.laneGoal - c.lane) * Math.min(1, h * 0.9);
    c.nz += ((Math.random() * 2 - 1) - c.nz) * Math.min(1, h * 1.5);
    let gx, gy, mk = 0;
    // shortcut: decide once per lap per cut when approaching its entry
    let cut = c.cutUse;
    if (!cut) for (const C of tr.cuts) {
      const d = ((C.ia - c.idx) % NS + NS) % NS;
      if (d > 4 && d < 40 && c.cutLap !== c.crossed * 100 + C.ia) {
        c.cutLap = c.crossed * 100 + C.ia;
        let pr;
        if (C.tide) { // the sandbar: only worth it if it stays dry until we are across (beginners just guess)
          const eta = (d * tr.ds) / Math.max(sp, 12), etx = eta + C.n / (VMAX * 0.72);
          const dry = tideLvl(tr, W.clock + eta) < 0.47 && tideLvl(tr, W.clock + etx) < (lv === 3 ? 0.44 : 0.5);
          pr = lv === 1 ? 0.3 : dry ? (lv === 3 ? 1 : 0.8) : 0.03;
        } else {
          const risky = C.s === 'ice' || C.s === 'dirt' || C.s === 'sand';
          pr = (lv === 1 ? 0.12 : lv === 2 ? (risky ? 0.3 : 0.55) : (risky ? 0.75 : 0.95)) * (0.6 + 0.4 * skill); // harder cars take shortcuts more often
        }
        if (Math.random() < pr) { c.cutUse = cut = { C, k: 0 }; }
      }
    }
    if (cut) {
      const C = cut.C;
      // follow the road until the entry, then the cut samples
      const dEntry = ((C.ia - c.idx) % NS + NS) % NS;
      if (cut.k === 0 && dEntry > 2 && dEntry < 60 && !c.onCut) {
        const ti = (c.idx + Math.max(3, Math.min(dEntry, Math.round(6 / tr.ds)))) % NS;
        gx = tr.x[ti]; gy = tr.y[ti];
        mk = 0.03 + C.turn * 0.09; // slow down for a sharp turn-in
      } else {
        let bk = cut.k, bd = 1e18;
        for (let k = Math.max(0, cut.k - 4); k < Math.min(C.n, cut.k + 30); k++) { const d = (c.x - C.sx[k]) ** 2 + (c.y - C.sy[k]) ** 2; if (d < bd) { bd = d; bk = k; } }
        cut.k = Math.max(cut.k, bk, 1);
        const tk = Math.min(C.n - 1, cut.k + 7);
        gx = C.sx[tk]; gy = C.sy[tk];
        mk = C.s === 'ice' ? 0.07 : 0.03;
        if (cut.k >= C.n - 3 || bd > 400) c.cutUse = null;
      }
    }
    if (gx == null) {
      const look = Math.max(3, Math.round((4.5 + sp * (0.3 + 0.12 * skill)) / tr.ds));
      const ti = (c.idx + look) % NS;
      const inside = U.clamp(-tr.curv[ti] * 60, -2.8, 2.8) * skill;
      let lane = c.lane * 0.6 + inside;
      // mine-cart rails: line up with the rail (hard always, normal often)
      const rl = tr.railLat[(c.idx + 10) % NS];
      if (rl === rl && (lv === 3 || (lv === 2 && skill > 0.55))) lane = rl;
      // undersea current: lean into it a little
      const fl = tr.flow[(c.idx + 6) % NS];
      if (fl && lv > 1) lane -= Math.sign(fl) * (lv === 3 ? 2.2 : 1.2);
      // dodge traps on the road ahead (oil / spring mines / landed ice; hard cars also skirt smoke)
      for (const id in W.hz) {
        const z = W.hz[id];
        if (lv === 1 || !(z.t === 'oil' || z.t === 'spring' || z.t === 'wall' || z.t === 'vort' || z.t === 'foam' || (z.t === 'frost' && frostOn(z)) || (z.t === 'smoke' && lv === 3))) continue; // beginners don't look out
        const d = ((z.idx - c.idx) % NS + NS) % NS;
        const zr = z.t === 'frost' ? FROST_R : z.t === 'smoke' ? SMOKE_R : z.t === 'vort' ? VORT_R - 1 : z.t === 'wall' ? 3.4 : z.t === 'foam' ? 2.4 : 2.9;
        if (d > 2 && d < 30) { const zl = (z.x - tr.x[z.idx]) * tr.nx[z.idx] + (z.y - tr.y[z.idx]) * tr.ny[z.idx]; if (Math.abs(zl - lane) < zr + 0.5) lane = zl > 0 ? zl - zr - 1.1 : zl + zr + 1.1; }
      }
      // grab item boxes when empty-handed
      if (!c.item) for (const b of tr.boxes) {
        const d = ((b.i - c.idx) % NS + NS) % NS;
        if (d > 2 && d < 26 && boxUp(W, b.id)) { const bl = (b.x - tr.x[b.i]) * tr.nx[b.i] + (b.y - tr.y[b.i]) * tr.ny[b.i]; if (Math.abs(bl - lane) < 4) { lane = bl; break; } }
      }
      // conveyor belts: ride the forward ones, keep off the backward ones, lean against the sideways ones
      if (tr.belts.length && lv > 1) for (let k = 4; k < 44; k += 5) {
        const bk = tr.belt[(c.idx + k) % NS];
        if (!bk) continue;
        const Bt = tr.belts[bk - 1], mid = (Bt.l0 + Bt.l1) / 2, full = Bt.l1 - Bt.l0 > tr.half * 1.5, dir = Math.abs(wrapA(Bt.dir));
        if (dir < 0.2) { if (!full) lane = mid; }
        else if (dir > 2.9) { if (!full) lane = (mid > 0 ? -1 : 1) * tr.half * 0.5; }
        else lane -= Math.sign(Math.sin(Bt.dir)) * (lv === 3 ? 2.6 : 1.6);
        break;
      }
      // stone pillars / bumpers: pass on the roomier side
      let pn = null, pd = 1e9, wide = false, tgt = ti, hold = 0;
      for (const p of tr.pil) { const d = ((p.i - c.idx) % NS + NS) % NS; if (d >= 1 && d < 34 && d < pd) { pd = d; pn = p; } }
      // syrup puddles and sand pits count as obstacles for normal / hard cars
      if (lv > 1) for (const p of tr.hzAvoid) { if (p.k && lv === 2 && (p.k === 'pud' || p.k === 'ice')) continue; const d = ((p.i - c.idx) % NS + NS) % NS; if (d >= 1 && d < 34 && d < pd && Math.abs(c.lat - p.lat) < p.r + 4) { pd = d; pn = p; } }
      if (pn) { // only the nearest one ahead, so a chicane is taken one pillar at a time
        const need = pn.r + RAD + 0.9;
        if (Math.abs(pn.lat - lane) < need) {
          lane = (pn.lat > 0.3 || (Math.abs(pn.lat) <= 0.3 && c.lat < 0)) ? pn.lat - need : pn.lat + need;
          wide = true;
          if (pd < look) tgt = (pn.i + 2) % NS; // line up beside it, not somewhere past it
        }
        mk = Math.max(mk, 0.03);
      }
      // crane containers / rolling balls: beginners dodge where it is now-ish; the others pick the line with the most
      // room while they pass it, and ease off when there is no room at that moment
      for (const m of tr.mov) {
        const d = ((m.i - c.idx) % NS + NS) % NS;
        if (d < 1 || d > 50) continue;
        const eta = (d * tr.ds) / Math.max(8, sp);
        mk = Math.max(mk, 0.03);
        if (lv === 1) { const ml = moverLat(m, W.clock + eta), need = m.hy + RAD + 0.8; if (Math.abs(ml - lane) < need) { lane = ml > 0 ? ml - need : ml + need; wide = true; } continue; }
        const lim = tr.half - 1.4;
        let best = lane, bc = -1e9;
        for (let q = -4; q <= 4; q++) {
          const L2 = (q * lim) / 4;
          let cl = 1e9;
          for (let dt2 = -0.3; dt2 <= 0.31; dt2 += 0.15) cl = Math.min(cl, Math.abs(L2 - moverLat(m, W.clock + eta + dt2)) - m.hy);
          const sc = cl - Math.abs(L2 - lane) * 0.05;
          if (sc > bc) { bc = sc; best = L2; }
        }
        lane = best; wide = true;
        if (bc < RAD + 0.2 && d * tr.ds < 32) hold = Math.max(hold, 1);
      }
      // windmill sails: take the far side, which they never reach — hard cars thread the gap when it is clearly open,
      // beginners only look now and then (decided once per mill)
      for (const S of tr.sw) {
        const d = ((S.i - c.idx) % NS + NS) % NS;
        if (d < 1 || d > 55) continue;
        if (c.sailI !== S.i) { c.sailI = S.i; c.sailLook = lv > 1 || Math.random() < 0.65; }
        if (!c.sailLook) continue;
        let busy = lv < 3;
        if (!busy) { const eta = (d * tr.ds) / Math.max(10, sp); for (let dt2 = -0.45; dt2 <= 0.45 && !busy; dt2 += 0.15) busy = sailHits(S, W.clock + eta + dt2, lane); }
        if (busy) { lane = -S.sd * (tr.half - 1.9); wide = true; }
        mk = Math.max(mk, 0.02);
      }
      // gates: pick the lane whose gate will be open when we arrive, then wait at it if needed
      for (const dr of tr.doors) {
        const d = ((dr.i - c.idx) % NS + NS) % NS, dd = d * tr.ds;
        if (dd > 80) continue;
        if (!c.door || c.door.i !== dr.i) c.door = { i: dr.i, sd: 0 };
        const eta = dd / Math.max(sp, 10), ok = (sd) => doorOpen(dr, sd, W.clock + eta) && doorOpen(dr, sd, W.clock + eta + 0.4);
        if (dd > DOOR_DIV + 3 || !c.door.sd) {
          if (lv === 1) { if (!c.door.sd) c.door.sd = Math.random() < 0.5 ? -1 : 1; }
          else { const cur = c.door.sd || (c.lat >= 0 ? 1 : -1); c.door.sd = ok(cur) ? cur : ok(-cur) ? -cur : cur; }
        }
        lane = c.door.sd * (tr.half * 0.5 + 0.3);
        if (!doorOpen(dr, c.door.sd, W.clock + Math.min(eta, dd / 6))) hold = Math.max(hold, dd < 5 ? 3 : dd < 14 ? 2 : 1);
        mk = Math.max(mk, 0.02);
        break;
      }
      // lightning: steer out of a marked circle that will strike as we get there (normal / hard)
      if (tr.bolt && lv > 1) {
        const bp = boltPhase(tr.bolt, W.clock);
        if (bp && bp.tau < tr.bolt.warn) {
          const left = tr.bolt.warn - bp.tau, need = tr.bolt.r + RAD * 0.6 + (lv === 3 ? 0.5 : 0.8), lim = tr.half - 1.2;
          for (const s of boltSpots(tr, bp.k)) {
            const dd = (((s.i - c.idx) % NS + NS) % NS) * tr.ds;
            if (dd > 70 || Math.abs(dd / Math.max(sp, 8) - left) > (lv === 3 ? 0.7 : 0.55)) continue;
            if (Math.abs(s.lat - lane) >= need) continue;
            const a1 = s.lat - need, b1 = s.lat + need;
            if (a1 >= -lim && (b1 > lim || lane - a1 < b1 - lane)) lane = a1; else if (b1 <= lim) lane = b1; else hold = Math.max(hold, 1);
            wide = true;
          }
        }
      }
      // slipstream straights: tuck in behind the car ahead, pull out to pass when right on its bumper
      if (lv > 1 && (tr.slip[(c.idx + 4) % NS] || (lv > 2 && tr.acurv[(c.idx + 6) % NS] < 0.012))) {
        let bo = null, bd = 1e9;
        const ca0 = Math.cos(c.a), sa0 = Math.sin(c.a);
        for (const o of W.cars) { if (o === c || o.lvl !== c.lvl || o.resp > 0) continue; const al = (o.x - c.x) * ca0 + (o.y - c.y) * sa0; if (al > 4 && al < 24 && al < bd) { bd = al; bo = o; } }
        if (bo) { const ol = (bo.x - tr.x[bo.idx]) * tr.nx[bo.idx] + (bo.y - tr.y[bo.idx]) * tr.ny[bo.idx]; lane = bd > 7 ? ol : ol + (ol > 0 ? -3.8 : 3.8); wide = true; }
      }
      // defend: a hard AI with a car tucked in its tow on a straight drifts across to break the tow (only when not passing)
      if (lv > 2 && !wide && tr.acurv[(c.idx + 6) % NS] < 0.012) {
        const ca0 = Math.cos(c.a), sa0 = Math.sin(c.a);
        for (const o of W.cars) {
          if (o === c || o.lvl !== c.lvl || o.resp > 0) continue;
          const dx = o.x - c.x, dy = o.y - c.y, al = -(dx * ca0 + dy * sa0);
          if (al > 3 && al < 14 && (o.draft || 0) > 0.3) { const ol = (o.x - tr.x[o.idx]) * tr.nx[o.idx] + (o.y - tr.y[o.idx]) * tr.ny[o.idx]; lane = U.clamp(ol + (ol > 0 ? -2.6 : 2.6), -tr.half + 2, tr.half - 2); break; }
        }
      }
      // city traffic: pass on the side away from where the car will be when we reach it
      if (tr.traffic) {
        const F = tr.traffic, need = TCAR_HY + RAD + 0.9;
        for (let k = 0; k < F.n; k++) {
          const m = trafficCar(tr, k, W.clock, TMP_CAR), gap = (((m.s - c.idx * tr.ds) % tr.len) + tr.len) % tr.len;
          if (gap > (lv === 1 ? 26 : 44) || gap < -2) continue;
          const q = trafficCar(tr, k, W.clock + gap / Math.max(3, sp - F.v), TMP_CAR);
          if (Math.abs(q.lat - lane) < need) { lane = q.lat > 0 ? q.lat - need : q.lat + need; wide = true; }
          if (gap < 10 && Math.abs(q.lat - c.lat) < need - 0.4) hold = Math.max(hold, 4);
        }
      }
      // waves on the causeway: keep to the middle
      if (tr.waves && lv > 1 && tr.wav[(c.idx + 8) % NS]) lane *= 0.25;
      // turntables: ease off a little
      for (const q of tr.turn) if (idxDist(q.i, c.idx) * tr.ds < q.R + 14) { mk = Math.max(mk, 0.035); break; }
      // round 9 gimmicks: pick the lane with the least trouble when we get there
      if (tr.gz) {
        if (lv === 1 && (c.gzLT -= h) <= 0) { c.gzLT = 2.5; c.gzLook = Math.random() < 0.55; }
        if (lv > 1 || c.gzLook) {
          c.gzT -= h;
          if (c.gzT <= 0) { c.gzT = lv === 3 ? 0.05 : lv === 2 ? 0.09 : 0.16; aiGimmick(W, c, sp, lv, lane); }
          if (c.gzWide) { lane = c.gzLane; wide = true; }
          if (c.gzHold) hold = Math.max(hold, c.gzHold);
          mk = Math.max(mk, 0.02);
        } else c.gzHold = 0;
      }
      // round 12: gusts, banked curves, slalom flags, boost rings, ferry, drawbridges, crossroads
      { const r12 = ai12(W, c, sp, lv, lane, skill); if (r12) { lane = r12.lane; if (r12.wide) wide = true; if (r12.hold) hold = Math.max(hold, r12.hold); if (r12.mk) mk = Math.max(mk, r12.mk); c.leapGo = r12.leap; } else c.leapGo = false; }
      // durability: careful drivers steer round a car in front instead of running into it
      // (어려움 always, 보통 once it is hurt, 쉬움 never) and 어려움 also eases off when it is badly hurt
      const careful = lv === 3 || (lv === 2 && c.hp < 60);
      if (careful && W.racing && W.clock > START_GHOST - 0.5 && !wide) {
        const ca0 = Math.cos(c.a), sa0 = Math.sin(c.a);
        for (const o of W.cars) {
          if (o === c || gone(o) || o.lvl !== c.lvl || o.resp > 0) continue;
          const dx = o.x - c.x, dy = o.y - c.y, al = dx * ca0 + dy * sa0;
          if (al < 1.5 || al > 5 + Math.max(0, sp - Math.max(0, o.v || 0)) * (lv === 3 ? 1.1 : 0.7)) continue;
          const ol = (o.x - tr.x[o.idx]) * tr.nx[o.idx] + (o.y - tr.y[o.idx]) * tr.ny[o.idx];
          if (Math.abs(ol - lane) > 3.8) continue;
          let side = lane >= ol ? 1 : -1;
          if (Math.abs(ol + side * 4) > tr.half - 1.2) side = -side;
          lane = ol + side * 4; wide = true;
          if (o.spin > 0 || (o.v || 0) < sp - 12) hold = Math.max(hold, 4); // a spun / stopped car ahead: lift a little
          break;
        }
      }
      lane = wide ? U.clamp(lane, -tr.half + 1.2, tr.half - 1.2) : U.clamp(lane, -tr.half + 1.8, tr.half - 1.8);
      if (tr.hwA) { let m = tr.half; for (let k = 0; k < 36; k += 3) m = Math.min(m, tr.hwA[(c.idx + k) % NS]); lane = U.clamp(lane, -m + 1.5, m - 1.5); } // pinched road ahead
      // rivers / gaps: line up with the nearest log or bridge well before the band
      for (let k = 2; k < 46; k += 2) {
        const j = (c.idx + k) % NS, rv = tr.rv[j];
        if (!rv) continue;
        const R = tr.rivers[rv - 1];
        if (R.sw) { // swing bridge: the middle lane, and wait at the bank unless it stays lined up until we are across
          lane = U.clamp(lane, -1.6, 1.6); mk = Math.max(mk, 0.03);
          const dd = k * tr.ds, eta = Math.max(0, dd - R.w - 1) / Math.max(sp, 6), etx = (dd + R.w + 3) / Math.max(sp, 6);
          let ok = true;
          for (let tt = eta - 0.2; tt <= etx + 0.3 && ok; tt += 0.15) ok = swingAng(R.sw, W.clock + Math.max(0, tt)) < 0.1;
          if (!ok && !(lv === 1 && c.nz > 0.55)) hold = Math.max(hold, dd - R.w < 9 ? 3 : 2);
          break;
        }
        if (!R.lanes.length) { lane = U.clamp(lane, -1.5, 1.5); mk = Math.max(mk, 0.02); break; } // a gap: hit the spring pad square
        const eta = (k * tr.ds) / Math.max(sp, 6);
        let best = R.lanes[0];
        for (const L2 of R.lanes) if (Math.abs(laneAt(R, L2, W.clock + eta) - c.lat) < Math.abs(laneAt(R, best, W.clock + eta) - c.lat)) best = L2;
        if (c.rvK === rv && c.rvL) best = c.rvL; else { c.rvK = rv; c.rvL = best; } // stick to the chosen log / bridge
        lane = laneAt(R, best, W.clock + eta);
        if (R.mv) hold = Math.max(hold, 4);
        mk = Math.max(mk, 0.045);
        if ((SURF[tr.D.deck] || SURF.road).g < 3) hold = Math.max(hold, 4); // slippery deck: slow down to line up with the bridge
        break;
      }
      if (tr.rv[c.idx]) { const R = tr.rivers[tr.rv[c.idx] - 1]; if (R.lanes.length) { let best = R.lanes[0]; for (const L2 of R.lanes) if (Math.abs(laneAt(R, L2, W.clock) - c.lat) < Math.abs(laneAt(R, best, W.clock) - c.lat)) best = L2; lane = laneAt(R, best, W.clock + 0.15); if ((SURF[tr.D.deck] || SURF.road).g < 3 || R.mv) hold = Math.max(hold, 4); } else if (R.sw) lane = 0; }
      gx = tr.x[tgt] + tr.nx[tgt] * lane; gy = tr.y[tgt] + tr.ny[tgt] * lane;
      c.hold = hold;
      const win = Math.round((6 + sp * 0.75) / tr.ds);
      for (let k = 2; k <= win; k += 2) { const v = tr.acurv[(c.idx + k) % NS]; if (v > mk) mk = v; }
    }
    const want = Math.atan2(gy - c.y, gx - c.x);
    const vh = sp > 4 ? Math.atan2(c.vy, c.vx) : c.a;
    let steer = 2.4 * wrapA(want - c.a) + 0.9 * wrapA(want - vh);
    steer += c.nz * (lv === 1 ? 0.6 : 0.35) * (1.1 - skill) * (c.blind > 0 ? 2.2 : 1);
    steer = U.clamp(steer, -1, 1);
    const icy = c.surf === 'ice' || tr.ice[(c.idx + 8) % NS];
    let vsafe = mk > 0.001 ? (1 / mk) * STEER * (c.st || 1) * (0.9 + 0.25 * skill) + 5 : 99;
    if (tr.bank[(c.idx + 6) % NS] && tr.bank[c.idx]) vsafe *= 1.35; // banked: corners can be taken much faster
    if (icy) vsafe *= 0.75;
    if (WX) vsafe *= Math.sqrt(WXG[WX]) * 1.02; // wet/snowy weather: corners slower (grip ∝ v²)
    if (!lvO && c.hp < (lv === 3 ? 40 : lv === 2 ? 25 : 0)) vsafe *= 0.92; // badly hurt: take the corners a little slower
    else { const g0 = (SURF[c.surf] || SURF.road).g; if (g0 < 4) vsafe *= 0.72 + g0 * 0.07; } // slippery deck: corners slower
    let cap = U.clamp(vsafe / (VMAX * (c.sv || 1)), 0.45, 1) * (W.racing && !lvO ? rubber(W, c) : 1);
    if (c.blind > 0) cap *= 0.85; // in the smoke
    if (c.hold) cap = Math.min(cap, [1, 0.55, 0.25, 0, 0.72][c.hold]); // gate shut / no room to pass: ease off or wait
    if (c.leapGo) { cap = 1; vsafe = 99; } // run-up to a chasm jump: flat out
    // level crossing: wait at the gate when the train will be there as we arrive (beginners sometimes gamble)
    if (W.racing && tr.trains.length && !(lv === 1 && c.nz > 0.5)) {
      for (const Tn of tr.trains) for (const X of Tn.cross) {
        const di = ((X.i - c.idx) % NS + NS) % NS, dd = di * tr.ds;
        if (di < 1 || dd > 34) continue;
        const eta = Math.max(0, dd - X.mr) / Math.max(sp, 6), etb = (dd + X.mr + RAD) / Math.max(sp, 6);
        let busy = false;
        for (let t = eta - 0.3; t <= etb + 0.5 && !busy; t += 0.15) busy = trainOcc(Tn, X, W.clock + Math.max(0, t));
        if (busy) cap = Math.min(cap, dd - X.mr < 7 ? 0 : 0.35);
      }
    }
    // brake hard if way too fast for a sharp corner (city)
    const drift = !c.leapGo && ((sp > vsafe + 9 && Math.abs(wrapA(want - c.a)) > 0.5) || (cap < 0.05 && sp > 5 && Math.abs(steer) < 0.3));
    return { steer, cap, drift };
  }
  /* AI for the round 12 gimmicks: returns {lane, wide, hold, mk, leap} or null */
  function ai12(W, c, sp, lv, lane, skill) {
    const tr = W.tr, half = tr.half, t = W.clock, ds = tr.ds;
    const ahead = (i) => ((((i - c.idx) % NS) + NS) % NS) * ds;
    let out = null;
    const set = (l, wide, hold, mk) => { if (!out) out = { lane, wide: false, hold: 0, mk: 0, leap: false }; if (l != null) out.lane = l; if (wide) out.wide = true; if (hold) out.hold = Math.max(out.hold, hold); if (mk) out.mk = Math.max(out.mk, mk); };
    if (tr.gust && lv > 1 && (tr.gzone[(c.idx + 6) % NS] || tr.gzone[c.idx])) { // lean into the wind
      const gs = gustAt(tr.gust, t + 0.35);
      if (gs && (gs.on || gs.tau > tr.gust.warn - 0.7)) set(lane - gs.dir * (lv === 3 ? 2.8 : 1.6), true);
    }
    const bk = tr.bank[(c.idx + 8) % NS];
    if (bk && lv > 1) set(bk * half * (lv === 3 ? 0.5 : 0.3)); // high side of a banked curve
    for (const g of tr.flags) { // weave through the slalom gates
      const d = ahead(g.i);
      if (d < 1 || d > 30) continue;
      if (c.flagI !== g.k) { c.flagI = g.k; c.flagGo = lv === 3 || (lv === 2 ? Math.random() < 0.8 : Math.random() < 0.35); }
      if (c.flagGo) set(g.lat, true);
      break;
    }
    for (const H of tr.hoops) { // aim for where the ring will be
      const d = ahead(H.i);
      if (d < 1 || d > 40) continue;
      if (c.hoopI !== H.k) { c.hoopI = H.k; c.hoopGo = lv === 3 || (lv === 2 ? Math.random() < 0.75 : Math.random() < 0.3); }
      if (c.hoopGo) set(U.clamp(hoopLat(H, t + d / Math.max(sp, 10) + (lv === 1 ? 0.6 : 0)), -half + 1.4, half - 1.4), true);
      break;
    }
    for (const p of tr.leaps) { // run-up to a chasm: straight and flat out
      const d = ahead(p.i);
      if (d > 50 || d < 0.5) continue;
      set(U.clamp(lane, -1.5, 1.5), true); out.leap = true;
      break;
    }
    if (tr.fer) { // pick the lane whose raft will be waiting, wait at the barrier, sit still on the raft
      const F = tr.fer, d = ahead(F.i) - F.wr; // distance to the bank (negative once over the water)
      const q = frameOf(F, c);
      if (q.al > -F.wr - 80 && q.al < F.wr + 2 && Math.abs(q.lt) < half + 8) {
        const eta = Math.max(0, d) / Math.max(sp, 8);
        if (q.al < -F.wr - 4 && (c.ferK == null || c.ferLap !== c.crossed)) {
          const wt = [0, 1].map((k) => { const R = raftAt(F, k, t + eta); return R.near ? (R.left < 0.8 ? 6 : 0) : R.wait; });
          c.ferK = lv === 1 ? (Math.random() < 0.5 ? 0 : 1) : wt[0] <= wt[1] ? 0 : 1; c.ferLap = c.crossed;
        }
        const k = c.ferK == null ? (q.lt >= 0 ? 1 : 0) : c.ferK;
        set((k ? 1 : -1) * (FER_PIER + (half - FER_PIER) / 2), true, 0, 0.03);
        const R = raftAt(F, k, t + Math.min(eta, 1)), onRaft = q.al > -F.wr - 1;
        if (!onRaft && !R.near) set(null, false, d < 10 ? 3 : d < 24 ? 2 : 1);
        if (onRaft && !raftAt(F, k, t).far && q.al > raftAt(F, k, t).p) set(null, false, 3);
      }
    }
    for (const B of tr.dbr) { // drawbridge: cross only while it stays down (hard cars also jump it while it moves)
      const q = frameOf(B, c);
      if (q.al < -B.wr - 70 || q.al > -B.wr + 1 || Math.abs(q.lt) > half + 6) continue;
      const d = -B.wr - q.al, eta = d / Math.max(sp, 8), etx = (d + 2 * B.wr + 3) / Math.max(sp, 8);
      let ok = true;
      for (let tt = eta - 0.2; tt <= etx + 0.2 && ok; tt += 0.15) ok = dbAng(B, t + Math.max(0, tt)) < 0.12;
      if (!ok && lv === 3 && sp > 18) { const th = dbAng(B, t + eta + B.wr / Math.max(sp, 8)); if (th > 0.15 && th < DB_JUMP - 0.15) ok = true; }
      if (!ok && lv === 1 && c.nz > 0.6) ok = true; // beginners gamble now and then
      set(U.clamp(lane, -2, 2), false, ok ? 0 : d < 9 ? 3 : 2, 0.02);
    }
    for (const Hd of tr.herd) { // sheep in my lane when I get there: wait for them (beginners don't look)
      if (lv === 1) break;
      const d = ahead(Hd.i);
      if (d < 1 || d > (lv === 3 ? 30 : 20)) continue;
      const eta = d / Math.max(sp, 8);
      let hit = false;
      for (let dt = -0.2; dt <= 0.7 && !hit; dt += 0.15) {
        const st = herdAt(Hd, t + eta + dt);
        if (!st || st.tau < 0) continue;
        for (let j = 0; j < Hd.n && !hit; j++) { const l = herdLat(Hd, j, st.tau); hit = l != null && Math.abs(l - c.lat) < HERD_R + RAD + 0.8; }
      }
      if (hit) set(null, false, d < 12 ? 3 : 2);
    }
    if (tr.xing && lv > 1) { // same-level crossroads: ease off when someone will be in the middle at the same time
      const X = tr.xing;
      for (const [ia, ib] of [[X.i, X.j], [X.j, X.i]]) {
        const d = ahead(ia);
        if (d < 3 || d > 32) continue;
        const eta = d / Math.max(sp, 8);
        for (const o of W.cars) {
          if (o === c || o.resp > 0 || gone(o)) continue;
          const od = ((((ib - o.idx) % NS) + NS) % NS) * ds;
          if (od > 45) continue;
          if (Math.abs(od / Math.max(o.v, 8) - eta) < (lv === 3 ? 0.75 : 0.5)) { set(null, false, d < 14 ? 1 : 4); break; }
        }
      }
    }
    return out;
  }
  /* AI: what each lane would cost at the round 9 gimmicks ahead, at the moment we would get there
     (boulders, snowballs, geysers, tornadoes, electromagnets, crumbling tiles, disco colours, magic doors, mud / wash) */
  const TMP_CAR = {};
  function gzCost(W, c, L, sp, lv, H) {
    const tr = W.tr, t = W.clock, ds = tr.ds, v = Math.max(sp, 8);
    let cost = 0;
    const ahead = (i) => ((((i - c.idx) % NS) + NS) % NS) * ds;
    const block = (d, w) => { cost += w * (1 + 1.5 * U.clamp(1 - d / H, 0, 1)); if (w >= 8 && d < c.gzNear) c.gzNear = d; }; // nearer trouble weighs more
    if (tr.rock) {
      const R = tr.rock, k1 = Math.floor((t + H / v - R.off) / R.per);
      for (let k = Math.max(0, k1 - Math.ceil((R.warn + R.life) / R.per) - 1); k <= k1; k++) {
        const land = rockT0(R, k) + R.warn;
        if (t > land + R.life) continue;
        for (const q of rockWave(tr, k)) {
          const d = ahead(q.i);
          if (d < 1 || d > H) continue;
          const eta = t + d / v;
          if (eta < land - 0.5 || eta > land + R.life + 0.2) continue;
          if (Math.abs(q.lat - L) < R.r + RAD + 0.8) block(d, 10);
        }
      }
    }
    for (const B of tr.balls) {
      const d = ahead(B.i);
      if (d < 1 || d > H) continue;
      for (let dt = -0.4; dt <= 0.41; dt += 0.2) {
        const st = ballAt(B, t + d / v + dt);
        if (!st) continue;
        if (st.tau > -0.2 && st.tau <= st.dur && Math.abs(st.lat - L) < st.r + RAD + 0.9) { block(d, 10); break; }
        if (st.tau >= 0 && (L - B.side * B.L) * (L - st.lat) < 0) { cost += 2; break; } // slush
      }
    }
    for (const g of tr.gey) {
      const d = ahead(g.i);
      if (d < 1 || d > H || Math.abs(g.lat - L) >= GEY_R + RAD + 0.7) continue;
      const eta = t + d / v;
      if (geyS(g, eta - 0.35) === 2 || geyS(g, eta) === 2 || geyS(g, eta + 0.35) === 2) block(d, 10);
    }
    for (const T of tr.tw) {
      const p = twPos(tr, T, t), gap = (((p.s - c.idx * ds) % tr.len) + tr.len) % tr.len;
      if (gap > H + 10) continue;
      const q = twPos(tr, T, t + gap / Math.max(4, v - T.v)), dl = Math.abs(q.lat - L), w = TW_PULL * 0.8;
      if (dl < w) block(gap, 4 + 8 * (1 - dl / w));
    }
    for (const m of tr.mag) {
      const d = ahead(m.i);
      if (d < 1 || d > H) continue;
      const eta = t + d / v;
      if (magS(m, eta) !== 2 && magS(m, eta + 0.5) !== 2) continue;
      const dl = Math.abs(m.lat - L);
      if (dl < MAG_R) block(d, 3 + 7 * (1 - dl / MAG_R));
    }
    if (tr.tiles.length) {
      const cw = (tr.half * 2) / 3, q = U.clamp(Math.floor((L + tr.half) / cw), 0, 2), il = L + tr.half - q * cw;
      const qc = U.clamp(Math.floor((c.lat + tr.half) / cw), 0, 2), qa = Math.min(q, qc), qb = Math.max(q, qc), reach = 6 + Math.abs(L - c.lat) * 2.6; // columns crossed on the way
      for (const S of tr.tiles) {
        let d0 = ahead(S.i0);
        if (d0 > tr.len / 2) d0 -= tr.len;
        if (d0 > H || d0 + S.rows * TILE_L < 0) continue;
        if (il < 0.9 || il > cw - 0.9) cost += 1; // between two columns: risky
        for (let r = 0; r < S.rows; r++) {
          const d = d0 + (r + 0.5) * TILE_L;
          if (d < -TILE_L * 0.5 || d > H) continue;
          const eta = t + Math.max(0, d) / v;
          for (let q2 = d < reach ? qa : q; q2 <= (d < reach ? qb : q); q2++) if (tileState(tr, S, r, q2, eta - 0.25) === 2 || tileState(tr, S, r, q2, eta + 0.3) === 2 || tileState(tr, S, r, q2, eta) === 1) { block(Math.max(0, d), 10); break; }
        }
      }
    }
    for (const D2 of tr.disco) {
      let d = ahead(D2.i0);
      if (d > tr.len / 2) d -= tr.len;
      if (d > H || d + (D2.i1 - D2.i0) * ds < 0) continue;
      const col = discoCol(D2, U.clamp(Math.floor((L + tr.half) / ((tr.half * 2) / 3)), 0, 2), t + Math.max(0, d) / v + 0.3);
      if (col === 0) cost -= lv === 3 ? 3 : 1.2; else if (col === 2) cost += 3;
    }
    for (const P2 of tr.ports) {
      const d = ahead(P2.i);
      if (d < 2 || d > H) continue;
      if (portOn(P2, t + d / v) && portOn(P2, t + d / v + 0.25) && Math.abs(P2.lat - L) < 1.4) cost -= lv === 3 ? 7 : 4;
    }
    if (lv > 1) for (const q of tr.bogs) { if (q.ly > tr.half) continue; const d = ahead(q.i); if (d > 1 && d < H && Math.abs(q.lat - L) < q.ly + 1.6) cost += 3; }
    for (const Hd of tr.herd) { // sheep in the road
      const d = ahead(Hd.i);
      if (d < 1 || d > H) continue;
      search: for (let dt = -0.5; dt <= 0.51; dt += 0.25) {
        const st = herdAt(Hd, t + d / v + dt);
        if (!st) continue;
        for (let j = 0; j < Hd.n; j++) { const lat = herdLat(Hd, j, Math.max(0.01, st.tau)); if (lat != null && Math.abs(lat - L) < HERD_R + RAD + 1) { block(d, 10); break search; } }
      }
    }
    if (lv > 1) for (const q of tr.crat) { const d = ahead(q.i); if (d > 1 && d < H && Math.abs(q.lat - L) < q.r + 1.5) cost += lv === 3 ? 2.5 : 1.2; }
    if (lv === 3) for (const q of tr.puds) { const d = ahead(q.i); if (d > 1 && d < H && Math.abs(q.lat - L) < q.r + 1) cost += 1.5; }
    {
      if (c.mud > (lv === 1 ? 0.5 : 0.2)) for (const q of tr.wash) { const d = ahead(q.i); if (d > 1 && d < H && Math.abs(q.lat - L) < q.r - 0.5) cost -= 2 + 5 * c.mud; }
    }
    return cost;
  }
  function aiGimmick(W, c, sp, lv, lane) {
    const tr = W.tr, lim = tr.half - 1.4, H = lv === 3 ? 60 : lv === 2 ? 46 : 28;
    c.gzNear = 1e9;
    let best = lane, bc = gzCost(W, c, lane, sp, lv, H);
    for (let q = -4; q <= 4; q++) {
      const L2 = (q * lim) / 4, k = gzCost(W, c, L2, sp, lv, H) + Math.abs(L2 - lane) * 0.06;
      if (k < bc - 0.4) { bc = k; best = L2; }
    }
    c.gzLane = best; c.gzWide = best !== lane;
    c.gzHold = bc >= 8 && c.gzNear < (lv === 3 ? 24 : 16) && c.gzNear > 5 && !tr.pit[c.idx] && !tr.pit[(c.idx + 4) % NS] ? 2 : 0; // no use slowing down on the crumbling floor itself
  }
  /* AI item use: returns true to fire now */
  function aiItem(W, c, h) {
    if (!c.item || c.roll > 0 || c.spin > 0 || c.resp > 0) return false;
    c.holdT += h;
    const tr = W.tr, it = c.item, lv = c.ailv || 2;
    if (c.holdT < (lv === 1 ? 2.2 : lv === 3 ? 0.3 : 0.6 + (1 - c.skill) * 1.5)) return false;
    if (lv === 1) { // beginner: uses whatever it has at a random moment, aimed or not
      if (it === 'turbo' || it === 'turbo3') return c.surf !== 'ice' && Math.random() < h * 0.8;
      return Math.random() < h * 0.45;
    }
    const straight = tr.acurv[(c.idx + 12) % NS] < 0.02 && tr.acurv[(c.idx + 24) % NS] < 0.03 && c.surf !== 'ice';
    if (it === 'tire') { const S0 = SURF[c.surf]; return (S0 && S0.v < 0.9 && c.surf !== 'ice') || c.holdT > (lv === 3 ? 12 : 5); }
    if (it === 'balloon') { // float over water / a chasm / the ferry ahead, or a trap or rough ground
      for (let k = 8; k < 26; k += 3) { const j = (c.idx + k) % NS; if (tr.rv[j] || tr.nr[j]) return true; }
      const S0 = SURF[c.surf];
      return trapAhead(W, c, 14) || (S0 && S0.v < 0.8) || c.holdT > (lv === 3 ? 9 : 3);
    }
    if (it === 'auto') return c.holdT > (lv === 3 ? 0.8 : 1.6) && c.spin <= 0;
    if (it === 'drone') { if (incoming(W, c, lv === 3 ? 1600 : 900)) return true; return c.holdT > (lv === 3 ? 10 : 4); }
    if (it === 'bees' || it === 'bomb') { const o = W.cars[carAhead(W, c)]; return !o || lv === 2 || Math.hypot(o.x - c.x, o.y - c.y) < 70 || c.holdT > 6; }
    if (it === 'blow') {
      if (trapAhead(W, c, 20)) return true;
      const ca2 = Math.cos(c.a), sa2 = Math.sin(c.a);
      for (const o of W.cars) { if (o === c || gone(o) || o.resp > 0 || o.lvl !== c.lvl) continue; const dx = o.x - c.x, dy = o.y - c.y, al = dx * ca2 + dy * sa2; if (al > 2 && al < (lv === 3 ? 16 : 20) && Math.abs(-dx * sa2 + dy * ca2) < 3 + al * 0.4) return true; }
      return c.holdT > (lv === 3 ? 18 : 9);
    }
    if (it === 'hop') { // jump an incoming shot or a trap right in front
      if (incoming(W, c, lv === 3 ? 700 : 400)) return true;
      if (lv === 3 && trapAhead(W, c, 9)) return true;
      return c.holdT > (lv === 3 ? 14 : 7);
    }
    if (it === 'ghost') {
      if (lv === 2) return c.holdT > 2.5;
      return incoming(W, c, 900) || trapAhead(W, c, 14) || c.gzHold > 0 || (tr.traffic && c.holdT > 1) || c.holdT > 9;
    }
    if (it === 'steal') { // only worth it when the car ahead holds something good (hard); normal grabs whatever
      const rk = ranking(W), my = rk.indexOf(c);
      let tg = null;
      for (let k = my - 1; k >= 0; k--) { const o = rk[k]; if (!gone(o) && o.item && o.roll <= 0) { tg = o; break; } }
      if (!tg) return c.holdT > (lv === 3 ? 12 : 5);
      return lv === 2 || GOOD_ITEM[tg.item] || c.holdT > 5;
    }
    if (it === 'shock') {
      let n = 0;
      for (const o of W.cars) if (o !== c && !gone(o) && o.lvl === c.lvl && o.resp <= 0 && (o.x - c.x) ** 2 + (o.y - c.y) ** 2 < (lv === 3 ? 64 : 81)) n++;
      return n >= 1 || c.holdT > (lv === 3 ? 18 : 10);
    }
    if (it === 'turbo' || it === 'turbo3') return !c.hold && (straight || c.surf === tr.off || c.holdT > 8);
    if (it === 'cloud' || it === 'homing') return true;
    if (it === 'shield' || it === 'mirror') { // wait for incoming fire (mirror: only rockets / homing can be bounced back)
      const r2 = lv === 3 ? 1600 : 900;
      for (const id in W.hz) { const z = W.hz[id]; if ((z.t === 'rocket' || z.t === 'homing' || ((z.t === 'boom' || z.t === 'net') && it === 'shield')) && z.o !== c.seat && (z.x - c.x) ** 2 + (z.y - c.y) ** 2 < r2) return true; }
      return c.holdT > (lv === 3 ? 25 : it === 'mirror' ? 6 : 10);
    }
    if (it === 'warp') { // hard: skip a twisty bit or a hazard; normal: soon
      if (lv === 2) return c.holdT > 1.5 && c.spin <= 0;
      let bend = 0; for (let k = 6; k < WARP_D / tr.ds; k += 3) bend = Math.max(bend, tr.acurv[(c.idx + k) % NS]);
      return bend > 0.045 || tr.rv[(c.idx + 14) % NS] > 0 || c.surf === tr.off || c.holdT > 6;
    }
    if (it === 'magnet') { // a target ahead within reach
      const tg = carAhead(W, c), o = W.cars[tg];
      if (!o) return c.holdT > 3;
      const d = Math.hypot(o.x - c.x, o.y - c.y), ahead = ((o.x - c.x) * Math.cos(c.a) + (o.y - c.y) * Math.sin(c.a)) / (d || 1);
      return (d > (lv === 3 ? 14 : 8) && d < (lv === 3 ? 55 : 65) && ahead > (lv === 3 ? 0.7 : 0.4)) || c.holdT > 14;
    }
    if (it === 'giant') { // hard: when someone is close; normal: soon
      if (lv === 2) return c.holdT > 2;
      for (const o of W.cars) if (o !== c && !gone(o) && (o.x - c.x) ** 2 + (o.y - c.y) ** 2 < 160) return true;
      return c.holdT > 10;
    }
    const ca = Math.cos(c.a), sa = Math.sin(c.a);
    for (const o of W.cars) {
      if (o === c || gone(o) || o.resp > 0 || o.lvl !== c.lvl) continue;
      const dx = o.x - c.x, dy = o.y - c.y, al = dx * ca + dy * sa, lt = -dx * sa + dy * ca;
      if (it === 'rocket' && al > 3 && al < (lv === 3 ? 48 : 40) && Math.abs(lt) < (lv === 3 ? 1.8 : 2.2) + al * 0.04) return true;
      if (it === 'boom' && al > 4 && al < (lv === 3 ? 34 : 30) && Math.abs(lt) < (lv === 3 ? 2.6 : 3.4)) return true;
      if (it === 'frost') { // where will it land vs where will they be
        const land = 3 + (44 + Math.max(c.v, 0) * 0.3) * FROST_FLY, ahead = al + Math.max(o.v, 0) * FROST_FLY;
        if (Math.abs(ahead - land) < (lv === 3 ? FROST_R - 1.5 : FROST_R) && Math.abs(lt) < (lv === 3 ? 4.5 : 6)) return true;
      }
      if ((it === 'oil' || it === 'spring') && al < -3 && al > (lv === 3 ? -16 : -22) && Math.abs(lt) < (lv === 3 ? 3 : 4)) return true;
      if (it === 'tacks' && al < -3 && al > -20 && Math.abs(lt) < 5) return true;
      if ((it === 'wall' || it === 'vort') && al < -4 && al > (lv === 3 ? -18 : -24) && Math.abs(lt) < (lv === 3 ? 3 : 4.5)) return true;
      if (it === 'foam' && al < -3 && al > -26 && Math.abs(lt) < 4) return true;
      if (it === 'rear' && al < -3 && al > (lv === 3 ? -44 : -36) && Math.abs(lt) < (lv === 3 ? 1.8 : 2.4) - al * 0.04) return true;
      if (it === 'fw' && al > 3 && al < 34 && Math.abs(lt) < 2.4 + al * 0.22) return true;
      if (it === 'paint' && al > 3 && al < (lv === 3 ? 40 : 32) && Math.abs(lt) < (lv === 3 ? 2.3 : 2.8) + al * 0.03) return true;
      if (it === 'net' && al > 3 && al < (lv === 3 ? 42 : 34) && Math.abs(lt) < (lv === 3 ? 2.3 : 2.8) + al * 0.03) return true;
      if (it === 'smoke' && al < -4 && al > -26 && Math.abs(lt) < 6) return true;
    }
    return c.holdT > (lv === 3 ? (it === 'oil' || it === 'spring' || it === 'tacks' ? 20 : 25) : it === 'oil' || it === 'spring' || it === 'smoke' || it === 'tacks' ? 9 : 12);
  }
  const GOOD_ITEM = { turbo3: 1, homing: 1, shield: 1, warp: 1, giant: 1, mirror: 1, ghost: 1, cloud: 1, rocket: 1, net: 1, balloon: 1, auto: 1, bees: 1, bomb: 1, drone: 1 };
  /* a rocket / homing shot / net / boomerang of someone else heading this way within sqrt(r2) */
  function incoming(W, c, r2) {
    for (const id in W.hz) {
      const z = W.hz[id];
      if (z.o === c.seat || !SHOT[z.t]) continue;
      const dx = c.x - z.x, dy = c.y - z.y;
      if (dx * dx + dy * dy < r2 && (z.t === 'homing' || z.t === 'bees' || z.t === 'bomb' ? z.tg === c.seat || dx * dx + dy * dy < 120 : dx * Math.cos(z.a) + dy * Math.sin(z.a) > 0)) return true;
    }
    return false;
  }
  /* a ground trap (oil, spring, tacks, ice) in our lane within d units */
  function trapAhead(W, c, d) {
    const ca = Math.cos(c.a), sa = Math.sin(c.a);
    for (const id in W.hz) {
      const z = W.hz[id];
      if (!(z.t === 'oil' || z.t === 'spring' || z.t === 'tacks' || z.t === 'wall' || z.t === 'vort' || z.t === 'foam' || (z.t === 'frost' && frostOn(z)))) continue;
      const dx = z.x - c.x, dy = z.y - c.y, al = dx * ca + dy * sa;
      if (al > 1 && al < d && Math.abs(-dx * sa + dy * ca) < (z.t === 'tacks' || z.t === 'wall' ? 5 : z.t === 'frost' ? FROST_R : z.t === 'vort' ? VORT_R : 3.4)) return true;
    }
    return false;
  }

  /* ---------- one world tick (all locally simulated cars) ----------
     ctl(c) -> {steer, drift, cap, use} for cars driven by local humans; null → AI drives. */
  function tick(W, dt, ctl, hooks) {
    const n = Math.max(1, Math.ceil(dt / SUBSTEP)), h = dt / n;
    const racing = W.racing;
    for (let s = 0; s < n; s++) {
      if (racing) W.clock += h;
      for (const c of W.cars) {
        if (c.remote) continue;
        if (c.out) { c.vx = c.vy = c.v = 0; c.dmg = 0; continue; } // a wreck: out of the race
        if (c.hurtT > 0) c.hurtT -= h;
        if (racing && c.fin == null && c.hp < HP_MAX && W.clock - (c.lastDmg || 0) > REGEN_WAIT) c.hp = Math.min(HP_MAX, c.hp + REGEN * h);
        let inp = racing && c.fin == null ? ctl(c) : null;
        if (inp && c.auto > 0) { const use = inp.use; inp = aiInput(W, c, h, 3); inp.use = use; } // 자율주행
        if (!inp) {
          inp = aiInput(W, c, h);
          if (!racing || c.fin != null) inp.cap = Math.min(inp.cap, 0.55);
          if (racing && c.fin == null && aiItem(W, c, h)) useItem(W, c);
        }
        if (inp.use) { inp.use = false; useItem(W, c); }
        if (!racing && !W.cruise) { inp.cap = 0; inp.drift = false; }
        c.steer = inp.steer;
        const ev = stepCar(W, c, inp, h);
        if (ev && hooks && hooks.ev) hooks.ev(c, ev);
      }
      collideCars(W, hooks && hooks.bump);
      if (racing) {
        moveHazards(W, h);
        pickBoxes(W, h, hooks && hooks.rnd);
        const eaten = hitTest(W, hooks && hooks.hit);
        if (W.eatQ.length) { eaten.push(...W.eatQ); W.eatQ.length = 0; }
        if (eaten.length && hooks && hooks.eaten) hooks.eaten(eaten);
      }
      for (const c of W.cars) if (c.dmg) settleDmg(W, c);
    }
  }

  /* damage collected during the substep → HP; at 0 the car explodes and is out (DNF). Only before the finish, while racing. */
  function settleDmg(W, c) {
    const d = Math.min(c.dmg, HIT_MAX + 15); c.dmg = 0;
    if (!HP_ON) return;
    if (!W.racing || c.remote || c.out || c.fin != null || !(d >= 0.5)) return;
    c.hp = Math.max(0, c.hp - d); c.hurtT = 0.6; c.lastDmg = W.clock;
    if (c.hp > 0) return;
    c.out = Math.max(1, Math.round(W.clock * 1000));
    c.vx = c.vy = c.v = 0; c.boost = 0; c.drift = 0; c.charge = 0; c.spin = 0; c.rot = 0; c.air = 0; c.bomb = 0; c.item = null; c.itemN = 0; c.roll = 0;
    c.shield = 0; c.mirror = 0; c.giant = 0; c.ghost = 0; c.flt = 0; c.drone = 0; c.mag = 0; c.warpN = 0;
    W.ev.push({ k: 'boom', s: c.seat, x: c.x, y: c.y });
  }

  /* ---------- pure game interface ---------- */
  function init(players, opts) {
    return { nt: opts && opts.tod === 'night' ? 1 : opts && opts.tod === 'day' ? 0 : U.rand(2), wx: opts && opts.wx && opts.wx !== 'rnd' ? Math.max(0, ['sun', 'rain', 'storm', 'snow'].indexOf(opts.wx)) : U.rand(4), hpo: opts && opts.hp === 'off' ? 1 : 0, gho: opts && (opts.ghost === 'on' || opts.ghost === 'off') ? opts.ghost : 'auto', rid: 1 + U.rand(99999), t: -1, pk: opts && opts.course === 'hand' ? -1 : -2, n: players.length, nm: players.map((p) => String(p.name || '').slice(0, 10)), ph: 'grid', seq: 0, res: null, cs: opts && opts.champ === 'on' ? { k: 0, pts: Array(players.length).fill(0), h: players.map(() => []), tr: [], pv: null } : null };
  }
  /* ---------- championship: CH_N races in a row, points per place (탈락 0점) ---------- */
  const CH_N = 4, CH_PTS = [10, 7, 5, 3];
  /* order: total points, then more 1st places, more 2nd places…, then the better place in the latest race, then seat */
  function champOrder(cs) {
    const n = cs.pts.length, cnt = (i, p) => cs.h[i].filter((x) => x === p).length;
    return [...Array(n).keys()].sort((a, b) => {
      if (cs.pts[b] !== cs.pts[a]) return cs.pts[b] - cs.pts[a];
      for (let p = 1; p <= n; p++) { const d = cnt(b, p) - cnt(a, p); if (d) return d; }
      const la = cs.h[a][cs.h[a].length - 1] || 99, lb = cs.h[b][cs.h[b].length - 1] || 99;
      return la - lb || a - b;
    });
  }
  /* res rows [seat, finT, laps, out] in race order → new cs (h[seat] gets the place, 0 = 탈락) */
  function champAdd(cs, res, t) {
    const n = cs.pts.length, pts = cs.pts.slice(), h = cs.h.map((a) => a.slice());
    const pv = champOrder(cs);
    res.forEach((r, k) => { const i = r[0]; if (!(i >= 0 && i < n)) return; const out = r[3] && !(r[1] > 0); h[i].push(out ? 0 : k + 1); if (!out) pts[i] += CH_PTS[k] || 0; });
    for (let i = 0; i < n; i++) if (h[i].length < cs.k + 1) h[i].push(0);
    return { k: cs.k + 1, pts, h, tr: cs.tr.concat([t]), pv };
  }
  /* the next race's course: same kind as race 1 (generated / hand-made), never one already driven */
  function champNext(cs, pk) {
    for (let g = 0; g < 50; g++) {
      const t = pk === -2 ? GEN0 + 1 + U.rand(GEN_N - 1) : U.rand(TRACKS.length);
      if (cs.tr.indexOf(t) < 0) return t;
    }
    return U.rand(TRACKS.length);
  }
  function result(s) {
    const r = result0(s);
    if (r) try {
      const K = s.ks, P = [...Array(s.n).keys()];
      if (s.cs) r.stats = [{ label: '총점', values: P.map((i) => String(s.cs.pts[i] | 0)) }].concat(s.cs.h[0].map((_, k) => ({ label: (k + 1) + '경주', values: P.map((i) => (s.cs.h[i][k] ? s.cs.h[i][k] + '위' : '탈락')) })));
      else if (K) r.stats = [
        { label: '최고 랩', values: P.map((i) => (K.bl[i] > 0 ? K.bl[i].toFixed(2) + '초' : '-')) },
        { label: '공격 명중', values: P.map((i) => String(K.hl[i] | 0)) },
        { label: '공격 맞음', values: P.map((i) => String(K.ht[i] | 0)) },
      ];
    } catch (e) {}
    return r;
  }
  function result0(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || ((i + 1) + '번');
    const lines = s.res.map((r, k) => {
      const lp = Math.min(LAPS, Math.max(1, Math.floor(r[2] || 0))) + '/' + LAPS + '랩';
      const tail = r[1] > 0 ? fmtT(r[1]) : r[3] ? '탈락 (펑! ' + lp + ')' : '미완주 (' + lp + ')';
      return (k + 1) + '위  ' + nm(r[0]) + '  ' + tail;
    });
    if (s.cs && s.cs.k >= CH_N) {
      const cs = s.cs, o = champOrder(cs), md = ['🥇', '🥈', '🥉'];
      const pl = (x) => (x ? x + '위' : '탈락');
      const rows = o.map((i, k) => (md[k] || (k + 1) + '위') + '  ' + nm(i) + '  ' + cs.pts[i] + '점  (' + cs.h[i].map(pl).join('·') + ')');
      return { winners: [o[0]], title: nm(o[0]) + ' 챔피언!', text: '챔피언십 ' + CH_N + '경주 최종 순위\n' + rows.join('\n') + '\n\n마지막 경주: ' + lines.join(' / ') };
    }
    const w = s.res[0][0], T = s.t >= 0 ? trackDef(s.t) : null;
    return { winners: [w], title: nm(w) + ' 1위!', text: (T ? T.name + (T.gen ? ' (' + genTheme(T).n + ' 생성 코스)' : '') + '\n' : '') + lines.join('\n') };
  }

  /* ---------- drawing helpers ---------- */
  /* a quad on the road: along a0..a1 (world units from sample i0), across l0..l1 */
  function quadPath(g, tr, i0, a0, a1, l0, l1, add) {
    const ia = (i0 + Math.round(a0 / tr.ds)) % NS, ib = (i0 + Math.round(a1 / tr.ds)) % NS;
    if (!add) g.beginPath();
    g.moveTo(tr.x[ia] + tr.nx[ia] * l0, tr.y[ia] + tr.ny[ia] * l0); g.lineTo(tr.x[ib] + tr.nx[ib] * l0, tr.y[ib] + tr.ny[ib] * l0);
    g.lineTo(tr.x[ib] + tr.nx[ib] * l1, tr.y[ib] + tr.ny[ib] * l1); g.lineTo(tr.x[ia] + tr.nx[ia] * l1, tr.y[ia] + tr.ny[ia] * l1); g.closePath();
  }
  const tilePath = (g, tr, S, r, q, ins) => { const cw = (tr.half * 2) / 3, l0 = -tr.half + q * cw + ins; quadPath(g, tr, S.i0, r * TILE_L + ins, (r + 1) * TILE_L - ins, l0, l0 + cw - 2 * ins); };
  const DISCO_L = 5;
  function rr(c, x, y, w, h2, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h2, r); else c.rect(x, y, w, h2); }
  /* item icon centred at 0,0 with radius ≈ s */
  function drawIcon(c, it, s) {
    c.save(); c.scale(s / 10, s / 10); c.lineJoin = 'round'; c.lineCap = 'round';
    const bolt = (x, y, k, col) => { c.save(); c.translate(x, y); c.scale(k, k); c.fillStyle = col; c.beginPath(); c.moveTo(1.5, -5); c.lineTo(-2.5, 0.8); c.lineTo(0, 0.8); c.lineTo(-1.5, 5); c.lineTo(2.8, -1); c.lineTo(0.3, -1); c.closePath(); c.fill(); c.restore(); };
    const can = (x, y, k) => {
      c.save(); c.translate(x, y); c.scale(k, k);
      c.fillStyle = '#c7cbd4'; rr(c, -4.2, -7.6, 8.4, 2.2, 1); c.fill();
      const g = c.createLinearGradient(-4.5, 0, 4.5, 0); g.addColorStop(0, '#c23a24'); g.addColorStop(0.45, '#ff7a3d'); g.addColorStop(1, '#a22a1a');
      c.fillStyle = g; rr(c, -4.5, -6.2, 9, 13, 2); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 0.7; c.stroke();
      bolt(0, 0.3, 0.95, '#ffe066');
      c.restore();
    };
    if (it === 'turbo') can(0, 0, 1);
    else if (it === 'turbo3') { can(-4.6, 1.6, 0.62); can(4.6, 1.6, 0.62); can(0, -1.6, 0.66); }
    else if (it === 'oil') {
      c.fillStyle = '#121016'; c.beginPath(); c.ellipse(0, 1.5, 8.5, 5.6, 0, 0, 7); c.fill();
      c.beginPath(); c.arc(-5.5, -2.8, 2.3, 0, 7); c.arc(5.2, -1.8, 1.8, 0, 7); c.fill();
      const g = c.createLinearGradient(-6, -2, 6, 4); g.addColorStop(0, 'rgba(120,90,255,.7)'); g.addColorStop(0.5, 'rgba(60,220,190,.6)'); g.addColorStop(1, 'rgba(255,190,60,.7)');
      c.strokeStyle = g; c.lineWidth = 1.2; c.beginPath(); c.ellipse(-0.5, 1, 5, 2.6, -0.2, 3.6, 6.1); c.stroke();
      c.fillStyle = '#2b2533'; c.beginPath(); c.ellipse(-2, -8, 1.4, 2.2, 0, 0, 7); c.fill();
    } else if (it === 'rocket' || it === 'homing') {
      const body = it === 'rocket' ? '#ee6a55' : '#3fc3b0', fin = it === 'rocket' ? '#8f2b1f' : '#1d6e66';
      c.rotate(-Math.PI / 4);
      c.fillStyle = '#ffcc4d'; c.beginPath(); c.moveTo(-2, 6.5); c.lineTo(0, 10.5); c.lineTo(2, 6.5); c.fill();
      c.fillStyle = fin; c.beginPath(); c.moveTo(-2.6, 2.5); c.lineTo(-5.4, 7.2); c.lineTo(-2.6, 6.4); c.moveTo(2.6, 2.5); c.lineTo(5.4, 7.2); c.lineTo(2.6, 6.4); c.fill();
      c.fillStyle = body; c.beginPath(); c.moveTo(0, -9.5); c.quadraticCurveTo(3.2, -6, 2.8, 6.5); c.lineTo(-2.8, 6.5); c.quadraticCurveTo(-3.2, -6, 0, -9.5); c.fill();
      c.fillStyle = '#f2e9d8'; c.beginPath(); c.arc(0, -2.5, 1.3, 0, 7); c.fill();
      c.rotate(Math.PI / 4);
      if (it === 'homing') { c.strokeStyle = '#f2e9d8'; c.lineWidth = 1.1; c.beginPath(); c.arc(5.6, -5.6, 3.2, 0, 7); c.moveTo(5.6, -10); c.lineTo(5.6, -1.2); c.moveTo(1.2, -5.6); c.lineTo(10, -5.6); c.stroke(); }
    } else if (it === 'shield') {
      const g = c.createRadialGradient(-2, -3, 1, 0, 0, 9.5); g.addColorStop(0, 'rgba(210,250,255,.95)'); g.addColorStop(1, 'rgba(70,170,230,.85)');
      c.fillStyle = g; c.beginPath();
      for (let k = 0; k < 6; k++) { const a = -Math.PI / 2 + k * Math.PI / 3; c.lineTo(Math.cos(a) * 9, Math.sin(a) * 9); }
      c.closePath(); c.fill(); c.strokeStyle = '#e6fbff'; c.lineWidth = 1.2; c.stroke();
      c.strokeStyle = 'rgba(20,70,110,.7)'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(-3.5, 0); c.lineTo(-0.8, 3); c.lineTo(4, -3); c.stroke();
    } else if (it === 'cloud') {
      bolt(0.5, 4.6, 0.9, '#ffe066');
      c.fillStyle = '#9aa0b4'; c.beginPath(); c.arc(-4.2, -1, 3.6, 0, 7); c.arc(0.5, -3.5, 4.6, 0, 7); c.arc(4.8, -0.6, 3.4, 0, 7); c.rect(-4.2, -1, 9, 3.4); c.fill();
      c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.arc(-0.5, -5, 2.2, 0, 7); c.fill();
    } else if (it === 'magnet') { // horseshoe magnet with field lines
      c.lineCap = 'butt';
      c.strokeStyle = '#d6403a'; c.lineWidth = 4.2; c.beginPath(); c.arc(0, 1, 5, Math.PI, 0, true); c.lineTo(5, -6); c.moveTo(-5, 1); c.lineTo(-5, -6); c.stroke();
      c.strokeStyle = '#d8dde6'; c.beginPath(); c.moveTo(5, -6); c.lineTo(5, -9.2); c.moveTo(-5, -6); c.lineTo(-5, -9.2); c.stroke();
      c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 1; c.beginPath(); c.arc(0, 1, 5.6, Math.PI * 0.95, Math.PI * 0.6, true); c.stroke();
      c.strokeStyle = '#7fd0ff'; c.lineWidth = 0.9; c.lineCap = 'round'; for (const k of [-1, 1]) { c.beginPath(); c.moveTo(k * 2.6, -10); c.quadraticCurveTo(k * 1.2, -12, k * 0.4, -9.6); c.stroke(); }
    } else if (it === 'spring') { // coil spring on a hazard plate
      c.fillStyle = '#2b2533'; c.beginPath(); c.ellipse(0, 6.5, 8.5, 3, 0, 0, 7); c.fill();
      c.strokeStyle = '#e8c04e'; c.lineWidth = 1.2; c.setLineDash([2, 2]); c.beginPath(); c.ellipse(0, 6.5, 7.6, 2.4, 0, 0, 7); c.stroke(); c.setLineDash([]);
      c.strokeStyle = '#d8dde6'; c.lineWidth = 1.7; c.beginPath(); for (let k = 0; k <= 6; k++) { const y = 5 - k * 2.1; c.lineTo(k % 2 ? 4.2 : -4.2, y); } c.stroke();
      c.fillStyle = '#ee6a55'; rr(c, -5.2, -9.6, 10.4, 2.6, 1); c.fill();
    } else if (it === 'smoke') { // smoke canister with a grey cloud
      c.fillStyle = '#9aa0b4'; c.beginPath(); c.arc(-3.5, -2.5, 4, 0, 7); c.arc(2, -4.5, 4.6, 0, 7); c.arc(5.5, 0, 3.4, 0, 7); c.arc(-0.5, 0.5, 4, 0, 7); c.fill();
      c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.arc(1, -6, 2, 0, 7); c.fill();
      c.fillStyle = '#3d4a3a'; rr(c, -3.2, 2.5, 6.4, 7.2, 1.5); c.fill(); c.fillStyle = '#e8c04e'; c.fillRect(-3.2, 4.6, 6.4, 1.2);
    } else if (it === 'warp') { // swirling portal
      for (let k = 0; k < 3; k++) { c.strokeStyle = ['#b48cf0', '#7fd0ff', '#f07fb8'][k]; c.lineWidth = 1.6; c.beginPath(); for (let t = 0; t <= 1; t += 0.04) { const a = k * 2.1 + t * 5, r = 1 + t * 8; c.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.8); } c.stroke(); }
      c.fillStyle = '#ffffff'; c.beginPath(); c.arc(0, 0, 1.4, 0, 7); c.fill();
    } else if (it === 'frost') { // ice bomb with a snowflake
      const g = c.createRadialGradient(-2.5, -2.5, 1, 0, 1, 8.5); g.addColorStop(0, '#e6fbff'); g.addColorStop(1, '#3f8fd0');
      c.fillStyle = g; c.beginPath(); c.arc(0, 1, 7.8, 0, 7); c.fill();
      c.fillStyle = '#2b2533'; c.fillRect(-1.6, -8.2, 3.2, 2.4); c.strokeStyle = '#e8c04e'; c.lineWidth = 0.9; c.beginPath(); c.moveTo(0, -8); c.quadraticCurveTo(2, -10.5, 3.5, -9.5); c.stroke();
      c.strokeStyle = '#ffffff'; c.lineWidth = 1; for (let k = 0; k < 3; k++) { const a = k * Math.PI / 3; c.beginPath(); c.moveTo(Math.cos(a) * 4.6, 1 + Math.sin(a) * 4.6); c.lineTo(-Math.cos(a) * 4.6, 1 - Math.sin(a) * 4.6); c.stroke(); }
    } else if (it === 'mirror') { // silver hexagon with a return arrow
      const g = c.createLinearGradient(-8, -8, 8, 8); g.addColorStop(0, '#f6f8fc'); g.addColorStop(0.5, '#a9b1c2'); g.addColorStop(1, '#e8ecf4');
      c.fillStyle = g; c.beginPath(); for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; c.lineTo(Math.cos(a) * 9, Math.sin(a) * 9); } c.closePath(); c.fill();
      c.strokeStyle = '#5a6278'; c.lineWidth = 1; c.stroke();
      c.strokeStyle = '#d6403a'; c.lineWidth = 1.6; c.beginPath(); c.arc(0, 0.5, 3.6, -Math.PI * 0.9, Math.PI * 0.55); c.stroke();
      c.fillStyle = '#d6403a'; c.beginPath(); c.moveTo(-5.6, -1.2); c.lineTo(-2.2, -3.6); c.lineTo(-2.4, 0.4); c.fill();
    } else if (it === 'giant') { // a car growing out of its own outline
      c.strokeStyle = 'rgba(242,233,216,.7)'; c.lineWidth = 1; c.setLineDash([1.6, 1.4]); rr(c, -4, -2.4, 8, 5, 1.5); c.stroke(); c.setLineDash([]);
      c.fillStyle = '#5fd3a0'; rr(c, -8, -5, 16, 10, 3); c.fill(); c.fillStyle = '#1b2230'; rr(c, 0.8, -3.6, 3, 7.2, 1); c.fill();
      c.fillStyle = 'rgba(255,255,255,.3)'; rr(c, -7, -4.2, 12, 2.2, 1); c.fill();
      c.strokeStyle = '#ffd166'; c.lineWidth = 1.2; c.lineCap = 'round';
      for (const [x, y, dx, dy] of [[-9, -6, -1, -1], [9, -6, 1, -1], [-9, 6, -1, 1], [9, 6, 1, 1]]) { c.beginPath(); c.moveTo(x, y); c.lineTo(x + dx * 2, y + dy * 2); c.stroke(); }
    } else if (it === 'boom') { // wooden boomerang
      c.rotate(-0.3);
      c.fillStyle = '#b07a46'; c.beginPath(); c.moveTo(-8.5, 4); c.quadraticCurveTo(-1, -9, 1, -9); c.quadraticCurveTo(4, -9, 8.5, 4); c.lineTo(5.6, 5.6); c.quadraticCurveTo(1.5, -4, 0, -4.6); c.quadraticCurveTo(-1.5, -4, -5.6, 5.6); c.closePath(); c.fill();
      c.strokeStyle = '#6b4524'; c.lineWidth = 0.8; c.stroke();
      c.strokeStyle = '#ee6a55'; c.lineWidth = 1.1; c.beginPath(); c.moveTo(-6.5, 3); c.lineTo(-4.6, 1.4); c.moveTo(6.5, 3); c.lineTo(4.6, 1.4); c.stroke();
    } else if (it === 'tacks') { // a little heap of tacks
      for (const [x, y, a] of [[-4.6, 3, -0.4], [0.4, 4.4, 0.2], [4.8, 2.6, 0.6], [-1.8, -1.4, 3.3], [3, -3, 2.6], [-5, -4.4, 1.2]]) {
        c.save(); c.translate(x, y); c.rotate(a);
        c.fillStyle = '#9aa0a8'; c.beginPath(); c.moveTo(-0.7, 0); c.lineTo(0, -4.4); c.lineTo(0.7, 0); c.fill();
        c.fillStyle = '#e8ecf2'; c.beginPath(); c.ellipse(0, 0.4, 2.3, 1.1, 0, 0, 7); c.fill(); c.strokeStyle = '#5a6278'; c.lineWidth = 0.6; c.stroke();
        c.restore();
      }
    } else if (it === 'shock') { // rings bursting out of a core
      for (const [r, w, col] of [[8.6, 1.2, 'rgba(255,209,102,.55)'], [6, 1.6, '#ffd166'], [3.4, 1.8, '#ff9a3c']]) { c.strokeStyle = col; c.lineWidth = w; c.beginPath(); c.arc(0, 0, r, 0, 7); c.stroke(); }
      c.fillStyle = '#fff3c4'; c.beginPath(); c.arc(0, 0, 1.6, 0, 7); c.fill();
      c.strokeStyle = '#ffd166'; c.lineWidth = 1.1; for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; c.beginPath(); c.moveTo(Math.cos(a) * 9.6, Math.sin(a) * 9.6); c.lineTo(Math.cos(a) * 11, Math.sin(a) * 11); c.stroke(); }
    } else if (it === 'net') { // a spider web
      c.strokeStyle = '#f4f4f8'; c.lineWidth = 0.9;
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; c.beginPath(); c.moveTo(0, 0); c.lineTo(Math.cos(a) * 9.5, Math.sin(a) * 9.5); c.stroke(); }
      for (const r of [3, 5.8, 8.6]) { c.beginPath(); for (let k = 0; k <= 8; k++) { const a = k * Math.PI / 4, m = (k + 0.5) * Math.PI / 4; k ? c.quadraticCurveTo(Math.cos(m) * r * 0.8, Math.sin(m) * r * 0.8, Math.cos(a) * r, Math.sin(a) * r) : c.moveTo(r, 0); } c.stroke(); }
      c.fillStyle = '#2b2533'; c.beginPath(); c.arc(4.4, -4.6, 1.5, 0, 7); c.fill(); c.strokeStyle = '#2b2533'; c.lineWidth = 0.5; for (const s2 of [-1, 1]) { c.beginPath(); c.moveTo(4.4 + s2 * 1.2, -4.6); c.lineTo(4.4 + s2 * 2.6, -6); c.moveTo(4.4 + s2 * 1.2, -4.2); c.lineTo(4.4 + s2 * 2.6, -3); c.stroke(); }
    } else if (it === 'steal') { // a grabbing claw on an arm
      c.strokeStyle = '#c7cbd4'; c.lineWidth = 2.4; c.beginPath(); c.moveTo(-8, 8); c.lineTo(-1.5, 1.5); c.stroke();
      c.fillStyle = '#5a6278'; c.beginPath(); c.arc(-1.5, 1.5, 2.2, 0, 7); c.fill();
      c.strokeStyle = '#ee6a55'; c.lineWidth = 1.8;
      c.beginPath(); c.moveTo(-0.5, 0); c.quadraticCurveTo(3, -6, 7.5, -4); c.moveTo(0.5, 1); c.quadraticCurveTo(6, -0.5, 6.5, 4); c.stroke();
      c.fillStyle = '#e3ae45'; c.beginPath(); c.arc(7.6, 0.2, 1.8, 0, 7); c.fill();
    } else if (it === 'ghost') { // a friendly ghost
      c.fillStyle = 'rgba(240,238,255,.95)'; c.beginPath(); c.arc(0, -2, 7, Math.PI, 0); c.lineTo(7, 7);
      for (let k = 0; k < 4; k++) c.lineTo(7 - (k + 0.5) * 3.5, 7 - (k % 2 ? 0 : 2.4)); c.lineTo(-7, 7); c.closePath(); c.fill();
      c.strokeStyle = 'rgba(120,110,170,.6)'; c.lineWidth = 0.7; c.stroke();
      c.fillStyle = '#2b2533'; c.beginPath(); c.ellipse(-2.4, -2.2, 1.1, 1.6, 0, 0, 7); c.ellipse(2.4, -2.2, 1.1, 1.6, 0, 0, 7); c.fill();
      c.fillStyle = 'rgba(255,140,170,.6)'; c.beginPath(); c.arc(-4.4, 1, 1, 0, 7); c.arc(4.4, 1, 1, 0, 7); c.fill();
    } else if (it === 'hop') { // a car springing up off a coil
      c.strokeStyle = '#d8dde6'; c.lineWidth = 1.3; c.beginPath(); for (let k = 0; k <= 6; k++) c.lineTo(k % 2 ? 3.4 : -3.4, 9 - k * 1.4); c.stroke();
      c.fillStyle = '#5fd3a0'; rr(c, -6.5, -7.5, 13, 7, 2.4); c.fill(); c.fillStyle = '#1b2230'; rr(c, -1, -6.4, 3.2, 4.8, 0.8); c.fill();
      c.strokeStyle = 'rgba(242,233,216,.8)'; c.lineWidth = 1; c.beginPath(); c.moveTo(-9, -1); c.lineTo(-9, -6); c.moveTo(9, -1); c.lineTo(9, -6); c.stroke();
      c.fillStyle = '#f2e9d8'; c.beginPath(); c.moveTo(0, -11.5); c.lineTo(2.4, -8.6); c.lineTo(-2.4, -8.6); c.fill();
    } else if (it === 'tire') { // a chunky off-road tyre
      c.fillStyle = '#1c1a20'; c.beginPath(); c.arc(0, 0, 9, 0, 7); c.fill();
      c.fillStyle = '#3a3640'; for (let k = 0; k < 12; k++) { c.save(); c.rotate(k * Math.PI / 6); c.fillRect(-1.2, -9.8, 2.4, 2.6); c.restore(); }
      c.fillStyle = '#9aa0a8'; c.beginPath(); c.arc(0, 0, 4.2, 0, 7); c.fill(); c.fillStyle = '#e3ae45'; c.beginPath(); c.arc(0, 0, 1.6, 0, 7); c.fill();
      c.strokeStyle = 'rgba(160,120,70,.9)'; c.lineWidth = 1; for (const a of [0.6, 2.7, 4.8]) { c.beginPath(); c.arc(0, 0, 6.4, a, a + 0.5); c.stroke(); }
    } else drawIcon12(c, it);
    c.restore();
  }
  /* round 12 item icons (same 10-unit radius) */
  function drawIcon12(c, it) {
    const dot = (x, y, r, col) => { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); };
    if (it === 'balloon') { // three balloons on strings
      c.strokeStyle = 'rgba(242,233,216,.85)'; c.lineWidth = 0.7;
      for (const [x, y] of [[-4.2, -3.4], [4.2, -3.4], [0, -6]]) { c.beginPath(); c.moveTo(x, y + 3.6); c.quadraticCurveTo(x * 0.4, 4, 0, 9.5); c.stroke(); }
      for (const [x, y, col] of [[-4.2, -3.4, '#ee6a55'], [4.2, -3.4, '#5bb3e6'], [0, -6, '#ffd166']]) {
        c.fillStyle = col; c.beginPath(); c.ellipse(x, y, 3.4, 4, 0, 0, 7); c.fill();
        c.beginPath(); c.moveTo(x - 0.8, y + 4.4); c.lineTo(x + 0.8, y + 4.4); c.lineTo(x, y + 3.4); c.fill();
        dot(x - 1.2, y - 1.6, 0.9, 'rgba(255,255,255,.55)');
      }
    } else if (it === 'auto') { // a steering wheel driven by a little chip
      c.strokeStyle = '#4fe3ff'; c.lineWidth = 1; c.globalAlpha = 0.6; c.beginPath(); c.arc(0, 0, 9.4, 0, 7); c.stroke(); c.globalAlpha = 1;
      c.strokeStyle = '#2b2533'; c.lineWidth = 2.6; c.beginPath(); c.arc(0, 0, 7, 0, 7); c.stroke();
      c.strokeStyle = '#d8dde6'; c.lineWidth = 1.6; c.beginPath(); c.arc(0, 0, 7, 0, 7); c.stroke();
      c.lineWidth = 1.8; c.beginPath(); c.moveTo(-6.6, 0.6); c.lineTo(6.6, 0.6); c.moveTo(0, 0.6); c.lineTo(0, 6.6); c.stroke();
      c.fillStyle = '#4fe3ff'; rr(c, -3, -3.2, 6, 6, 1.2); c.fill();
      c.fillStyle = '#17131f'; c.font = '700 5px "IBM Plex Mono", monospace'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('A', 0, 0);
    } else if (it === 'fw') { // a burst with three little rockets
      const cols = ['#ff5fb4', '#ffd166', '#4fe3ff'];
      for (let k = 0; k < 12; k++) { const a = (k * Math.PI) / 6; c.strokeStyle = cols[k % 3]; c.lineWidth = 1.1; c.beginPath(); c.moveTo(Math.cos(a) * 3, Math.sin(a) * 3 - 2); c.lineTo(Math.cos(a) * 6.5, Math.sin(a) * 6.5 - 2); c.stroke(); }
      for (const [x, col] of [[-5, '#ee6a55'], [0, '#5fd3a0'], [5, '#5bb3e6']]) { c.fillStyle = col; rr(c, x - 1, 3.4, 2, 5.2, 0.6); c.fill(); c.beginPath(); c.moveTo(x - 1, 3.6); c.lineTo(x, 2); c.lineTo(x + 1, 3.6); c.fill(); }
      dot(0, -2, 1.4, '#fff3c4');
    } else if (it === 'paint') { // a splat of paint with drips
      c.fillStyle = '#d14fd8'; c.beginPath();
      for (let k = 0; k < 16; k++) { const a = (k / 16) * Math.PI * 2, r = k % 2 ? 5.2 : 7.6 + (k % 4 ? 0 : 1.4); c.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.9); }
      c.closePath(); c.fill();
      for (const [x, y, r] of [[-7.6, 6, 1.3], [8, -5.4, 1], [6.4, 7, 1.4], [-6, -7.4, 0.9]]) dot(x, y, r, '#d14fd8');
      dot(-1.6, -1.8, 2.2, '#ffd166'); dot(2, 1.6, 1.6, '#4fe3ff'); dot(-2.4, -2.4, 0.8, 'rgba(255,255,255,.6)');
    } else if (it === 'wall') { // a striped barrier on two legs
      c.fillStyle = '#5a5464'; c.fillRect(-7, 1, 1.6, 7.5); c.fillRect(5.4, 1, 1.6, 7.5);
      c.save(); rr(c, -9.4, -4.6, 18.8, 6.4, 1.2); c.clip(); c.fillStyle = '#f2ede4'; c.fillRect(-10, -5, 20, 7);
      c.fillStyle = '#ee6a55'; for (let x = -12; x < 12; x += 4.4) { c.beginPath(); c.moveTo(x, 1.8); c.lineTo(x + 2.2, 1.8); c.lineTo(x + 6.6, -4.6); c.lineTo(x + 4.4, -4.6); c.fill(); }
      c.restore(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 0.6; rr(c, -9.4, -4.6, 18.8, 6.4, 1.2); c.stroke();
      dot(-6.2, -6.2, 1.2, '#ffd166'); dot(6.2, -6.2, 1.2, '#ffd166');
    } else if (it === 'vort') { // a whirlpool
      for (let k = 0; k < 2; k++) { c.strokeStyle = k ? '#b48cf0' : '#5bb3e6'; c.lineWidth = 1.6; c.beginPath(); for (let t = 0; t <= 1; t += 0.03) { const a = k * Math.PI + t * 9, r = 0.6 + t * 8.6; c.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.85); } c.stroke(); }
      dot(0, 0, 1.4, '#17131f');
    } else if (it === 'bomb') { // a round bomb with a lit fuse
      const g = c.createRadialGradient(-2.4, -0.4, 0.6, 0, 2, 7.4); g.addColorStop(0, '#5a5464'); g.addColorStop(1, '#17131f');
      c.fillStyle = g; c.beginPath(); c.arc(0, 2, 7, 0, 7); c.fill();
      c.fillStyle = '#8a8496'; c.fillRect(-1.8, -6.2, 3.6, 2.4);
      c.strokeStyle = '#c9a874'; c.lineWidth = 1; c.beginPath(); c.moveTo(0, -6); c.quadraticCurveTo(2, -9.5, 5, -8.4); c.stroke();
      c.fillStyle = '#ffd166'; c.beginPath(); for (let k = 0; k < 8; k++) { const a = (k * Math.PI) / 4, r = k % 2 ? 1 : 2.6; c.lineTo(5.4 + Math.cos(a) * r, -8.6 + Math.sin(a) * r); } c.fill();
      c.fillStyle = '#ee6a55'; c.font = '700 6px "IBM Plex Mono", monospace'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('3', 0, 2.6);
    } else if (it === 'foam') { // soap bubbles
      for (const [x, y, r] of [[-3.6, 2.6, 4.2], [3.4, 3.4, 3.4], [1, -3.6, 3.8], [-5.6, -4.4, 2], [6.4, -3, 1.8]]) {
        c.fillStyle = 'rgba(220,245,255,.5)'; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill();
        c.strokeStyle = '#ffffff'; c.lineWidth = 0.8; c.stroke(); dot(x - r * 0.35, y - r * 0.35, r * 0.25, '#ffffff');
      }
      c.strokeStyle = 'rgba(180,140,240,.8)'; c.lineWidth = 0.6; c.beginPath(); c.arc(-3.6, 2.6, 3.2, 3.6, 5); c.stroke();
    } else if (it === 'drone') { // a quadcopter
      c.strokeStyle = '#5a6278'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(-6, -6); c.lineTo(6, 6); c.moveTo(6, -6); c.lineTo(-6, 6); c.stroke();
      for (const [x, y] of [[-6, -6], [6, -6], [-6, 6], [6, 6]]) { c.fillStyle = 'rgba(200,230,255,.35)'; c.beginPath(); c.arc(x, y, 3.4, 0, 7); c.fill(); c.strokeStyle = '#d8dde6'; c.lineWidth = 0.6; c.stroke(); dot(x, y, 0.8, '#2b2533'); }
      c.fillStyle = '#3fc3b0'; rr(c, -3, -2.4, 6, 4.8, 1.4); c.fill(); dot(0, 0, 1.1, '#ee6a55');
    } else if (it === 'blow') { // a fan with wind lines
      c.fillStyle = '#2b2533'; c.beginPath(); c.arc(-2.4, 0, 7, 0, 7); c.fill();
      c.fillStyle = '#9aa0b4'; for (let k = 0; k < 3; k++) { c.save(); c.translate(-2.4, 0); c.rotate((k * Math.PI * 2) / 3); c.beginPath(); c.ellipse(0, -3.2, 1.8, 3.3, 0.3, 0, 7); c.fill(); c.restore(); }
      dot(-2.4, 0, 1.2, '#ffd166');
      c.strokeStyle = '#bfefff'; c.lineWidth = 1.1; for (const y of [-4, 0, 4]) { c.beginPath(); c.moveTo(5.6, y); c.quadraticCurveTo(8, y - 1.4, 10.4, y); c.stroke(); }
    } else if (it === 'rear') { // a cannon aimed back (down the screen)
      c.fillStyle = '#3d3846'; c.save(); c.translate(-1.6, 0); rr(c, -2.6, -5.4, 5.2, 11, 1.6); c.fill(); c.fillStyle = '#5a5464'; c.fillRect(-3.2, 4.2, 6.4, 1.8); c.restore();
      c.fillStyle = '#8a5a3a'; c.beginPath(); c.arc(-1.6, -4.6, 3.4, 0, 7); c.fill(); dot(-1.6, -4.6, 1.1, '#3d2814');
      dot(-1.6, 8.8, 1.8, '#17131f');
      c.fillStyle = '#ffd166'; c.fillRect(5.6, -7, 1.8, 6); c.beginPath(); c.moveTo(3.6, -1.4); c.lineTo(9.4, -1.4); c.lineTo(6.5, 3); c.fill();
    } else if (it === 'bees') { // two bees
      for (const [x, y, s2] of [[-3.4, 2.4, 1], [4, -3.4, 0.8]]) {
        c.save(); c.translate(x, y); c.scale(s2, s2);
        c.fillStyle = 'rgba(230,245,255,.75)'; c.beginPath(); c.ellipse(-1.4, -3.4, 2, 2.8, -0.5, 0, 7); c.ellipse(1.6, -3.4, 2, 2.8, 0.5, 0, 7); c.fill();
        c.fillStyle = '#ffd166'; c.beginPath(); c.ellipse(0, 0, 4.4, 3.2, 0, 0, 7); c.fill();
        c.fillStyle = '#17131f'; c.fillRect(-1.6, -3, 1.2, 6); c.fillRect(1, -3, 1.2, 6); dot(4.2, -0.4, 0.6, '#17131f');
        c.restore();
      }
    }
  }

  /* ---------- themes ---------- */
  const THEME = {
    plum: { base: '#3c5a3c', off: '#3c5a3c', road: '#3a363f', edge: '#d8d0c2', curb: true, dots: ['rgba(20,40,20,.35)', 'rgba(170,200,140,.12)'], out: '#2a1d36' },
    desert: { base: '#d8b06a', off: '#d8b06a', road: '#5f5048', edge: '#efd9a8', rock: '#8a5530', rockHi: '#b4774a', dots: ['rgba(120,80,30,.25)', 'rgba(255,240,200,.25)'], out: '#5b3620' },
    snow: { base: '#e2ebf3', off: '#e2ebf3', road: '#4a5562', edge: '#ffffff', dots: ['rgba(120,150,190,.18)', 'rgba(255,255,255,.6)'], out: '#9fb3c8' },
    city: { base: '#141220', off: '#2a2733', road: '#25222c', edge: '#ffd166', rock: '#1b1828', dots: ['rgba(255,255,255,.04)', 'rgba(0,0,0,.2)'], out: '#0d0b14' },
    beach: { base: '#e9cf8f', off: '#e9cf8f', road: '#4b4650', edge: '#fff4dc', water: '#2b8fbf', dots: ['rgba(160,120,60,.22)', 'rgba(255,255,255,.35)'], out: '#1d6f9a' },
    forest: { base: '#4a3b26', off: '#4a3b26', road: '#55504a', edge: '#d9cfae', dots: ['rgba(30,50,20,.4)', 'rgba(140,170,90,.18)'], out: '#1f2a17' },
    volcano: { base: '#3a2c2a', off: '#3a2c2a', road: '#2a2426', edge: '#c9b9a6', water: '#e2481c', water2: '#ffb347', dots: ['rgba(0,0,0,.35)', 'rgba(255,120,60,.12)'], out: '#1a0f0e' },
    jungle: { base: '#4b3a22', off: '#4b3a22', road: '#5b5248', edge: '#e0d3a8', water: '#2f8fa3', water2: '#9fe3ee', dots: ['rgba(20,50,20,.45)', 'rgba(150,190,90,.18)'], out: '#16261a' },
    ruins: { base: '#a88a5c', off: '#a88a5c', road: '#7a6a55', edge: '#e6d6b2', rock: '#5e4a33', rockHi: '#c9a874', dots: ['rgba(60,40,20,.25)', 'rgba(255,240,200,.2)'], out: '#3a2b1c' },
    space: { base: '#0b0a18', off: '#5d6476', road: '#3b4150', edge: '#9fe8ff', water: '#07061a', dots: ['rgba(255,255,255,.0)', 'rgba(255,255,255,.0)'], out: '#05040e' },
    park: { base: '#3f7a46', off: '#3f7a46', road: '#3c3846', edge: '#fff1d6', curb: true, dots: ['rgba(255,95,180,.35)', 'rgba(255,230,120,.35)'], out: '#24452a' },
    harbor: { base: '#8c8f93', off: '#8c8f93', road: '#3d3f45', edge: '#ffd166', water: '#1f5f86', water2: '#7fc4e6', dots: ['rgba(0,0,0,.18)', 'rgba(255,255,255,.12)'], out: '#123e5a' },
    candy: { base: '#f6c9dc', off: '#fbe3ee', road: '#5b3a46', edge: '#fff6fa', rock: '#f59bc0', rockHi: '#ffffff', dots: ['rgba(238,106,85,.55)', 'rgba(91,179,230,.55)'], out: '#7a2e52' },
    sea: { base: '#0b3a5c', off: '#35536a', road: '#2e3b48', edge: '#bff4ff', rock: '#0a3552', rockHi: '#7fe3ff', dots: ['rgba(255,255,255,.05)', 'rgba(0,0,0,.15)'], out: '#062236' },
    sky: { base: '#8cc8ef', off: '#f5f9ff', road: '#4a5068', edge: '#ffffff', water: '#8cc8ef', water2: '#ffffff', dots: ['rgba(255,255,255,.0)', 'rgba(255,255,255,.0)'], out: '#5a9fd6' },
    storm: { base: '#d6a65e', off: '#d6a65e', road: '#7a6450', edge: '#f3dcab', dots: ['rgba(120,80,30,.25)', 'rgba(255,240,200,.3)'], out: '#7a4f22' },
    rail: { base: '#5e8b4b', off: '#5e8b4b', road: '#46434b', edge: '#f2ede4', dots: ['rgba(20,50,20,.35)', 'rgba(190,220,140,.18)'], out: '#2c4a24' },
    mine: { base: '#2a1f18', off: '#5a4330', road: '#4a3a2e', edge: '#c9a874', rock: '#1d1612', rockHi: '#6a5238', dots: ['rgba(0,0,0,.3)', 'rgba(255,220,160,.08)'], out: '#0e0a08' },
    blossom: { base: '#6c9a50', off: '#6c9a50', road: '#4b4552', edge: '#f8e9f0', dots: ['rgba(30,60,20,.35)', 'rgba(255,190,215,.35)'], out: '#3a5a2a' },
    toy: { base: '#3f8a8c', off: '#3f8a8c', road: '#d2a064', edge: '#f6e3c0', dots: ['rgba(0,40,50,.22)', 'rgba(255,255,255,.12)'], out: '#7a4a2c' },
    windmill: { base: '#6aa04e', off: '#6aa04e', road: '#4b4650', edge: '#f4eee2', curb: true, water: '#3f8fc0', dots: ['rgba(30,60,20,.3)', 'rgba(220,240,160,.2)'], out: '#3c6a2e' },
    thunder: { base: '#2f3d33', off: '#2f3d33', road: '#2b2e35', edge: '#cfd6e0', dots: ['rgba(0,0,0,.3)', 'rgba(160,190,170,.12)'], out: '#141a17' },
    factory: { base: '#5d6168', off: '#6f747c', road: '#70757d', edge: '#f2c230', rock: '#33373e', rockHi: '#f2c230', dots: ['rgba(0,0,0,.14)', 'rgba(255,255,255,.08)'], out: '#24272c' },
    tide: { base: '#8a7a62', off: '#8a7a62', road: '#4b4650', edge: '#efe6d2', water: '#3f7fa0', water2: '#9fd4e8', dots: ['rgba(60,45,30,.3)', 'rgba(220,210,190,.18)'], out: '#2a5a78' },
    haunt: { base: '#24301f', off: '#24301f', road: '#3d3846', edge: '#9c94a8', rock: '#1c3320', rockHi: '#3c6a3a', dots: ['rgba(0,0,0,.35)', 'rgba(120,160,110,.12)'], out: '#0c120b' },
    aurora: { base: '#b9cde0', off: '#c9daea', road: '#8cc2dc', edge: '#f2fbff', dots: ['rgba(80,110,150,.18)', 'rgba(255,255,255,.5)'], out: '#5b7590' },
    tunnel: { base: '#5f8a4a', off: '#5f8a4a', road: '#46434b', edge: '#e8e4dc', rock: '#6d6a64', rockHi: '#9a958c', dots: ['rgba(20,50,20,.3)', 'rgba(200,230,160,.15)'], out: '#2f4426' },
    prairie: { base: '#a7a64a', off: '#a7a64a', road: '#4b4650', edge: '#f4ecd4', curb: true, dots: ['rgba(110,90,30,.25)', 'rgba(255,240,180,.25)'], out: '#6f7a32' },
    scrap: { base: '#7a6f62', off: '#857a6c', road: '#3e3c40', edge: '#f2c230', dots: ['rgba(0,0,0,.22)', 'rgba(255,220,170,.12)'], out: '#3f3a33' },
    canal: { base: '#a8957c', off: '#a8957c', road: '#4a4550', edge: '#efe6d6', water: '#2f7fa6', water2: '#8fd0ea', dots: ['rgba(60,45,30,.2)', 'rgba(255,245,225,.18)'], out: '#2a5f80' },
    library: { base: '#3a2418', off: '#7a2a34', road: '#7a5a3a', edge: '#e3ae45', rock: '#2a1a10', rockHi: '#9a6a32', dots: ['rgba(0,0,0,.2)', 'rgba(255,220,160,.06)'], out: '#1a0f08' },
    disco: { base: '#120a24', off: '#2a1840', road: '#1e1530', edge: '#ff5fb4', rock: '#160c2a', rockHi: '#4fe3ff', dots: ['rgba(255,255,255,.03)', 'rgba(0,0,0,.2)'], out: '#0a0614' },
    foundry: { base: '#2a2626', off: '#3a3330', road: '#4a4644', edge: '#ff9a3c', rock: '#1e1a1a', rockHi: '#ff7a2a', water: '#ff6a1a', water2: '#ffd27a', dots: ['rgba(0,0,0,.3)', 'rgba(255,140,60,.08)'], out: '#120e0e' },
    clock: { base: '#b9ad94', off: '#b9ad94', road: '#55505a', edge: '#f4eee2', dots: ['rgba(80,60,40,.18)', 'rgba(255,250,235,.2)'], out: '#6e6452' },
    rally: { base: '#5b8a3c', off: '#5b8a3c', road: '#8a7356', edge: '#e2d4ae', dots: ['rgba(20,50,20,.3)', 'rgba(200,230,150,.16)'], out: '#3a5a26' },
    /* round 12 */
    canyon: { base: '#c97b45', off: '#c97b45', road: '#5a4038', edge: '#f0d2a8', rock: '#8e4424', rockHi: '#d27a48', dots: ['rgba(110,50,20,.25)', 'rgba(255,220,180,.2)'], out: '#5a2a14' },
    river: { base: '#5f9a4a', off: '#5f9a4a', road: '#4a4650', edge: '#efe8d8', water: '#3a86b8', water2: '#9fd8f0', curb: true, dots: ['rgba(20,50,20,.3)', 'rgba(200,230,150,.16)'], out: '#2f5a2a' },
    stadium: { base: '#3f7f45', off: '#3f7f45', road: '#3a3742', edge: '#ffffff', rock: '#2b2a33', rockHi: '#e8384f', curb: true, dots: ['rgba(0,0,0,.12)', 'rgba(255,255,255,.06)'], out: '#1e2a22' },
    metro: { base: '#8a8f98', off: '#9aa0a8', road: '#3e4048', edge: '#f2f2f2', rock: '#6a6f78', rockHi: '#c8ccd4', dots: ['rgba(0,0,0,.1)', 'rgba(255,255,255,.08)'], out: '#3a3d44' },
    ranch: { base: '#7aa34e', off: '#7aa34e', road: '#6a5a48', edge: '#efe2c0', dots: ['rgba(40,60,20,.3)', 'rgba(230,240,160,.2)'], out: '#3f5a28' },
    bridge: { base: '#6aa04e', off: '#6aa04e', road: '#44464e', edge: '#f2f2f2', water: '#2d7fb0', water2: '#8fd0f0', dots: ['rgba(20,50,20,.3)', 'rgba(200,230,150,.16)'], out: '#1d5f8a' },
    ski: { base: '#eef4fa', off: '#eef4fa', road: '#d3e1ee', edge: '#ffffff', dots: ['rgba(120,150,190,.16)', 'rgba(255,255,255,.6)'], out: '#a8bccf' },
    fest: { base: '#5aa04e', off: '#5aa04e', road: '#4a4558', edge: '#fff3d6', curb: true, dots: ['rgba(20,50,20,.3)', 'rgba(255,230,140,.2)'], out: '#2f5a2a' },
    season: { base: '#5f9a48', off: '#5f9a48', road: '#4b4650', edge: '#f2ece0', dots: ['rgba(20,50,20,.3)', 'rgba(255,200,220,.18)'], out: '#2f4a24' },
    market: { base: '#2a1f22', off: '#3a2a28', road: '#4a3f3c', edge: '#ffcf6b', rock: '#24181a', rockHi: '#e8743a', dots: ['rgba(0,0,0,.2)', 'rgba(255,200,120,.05)'], out: '#140c0e' },
    icelake: { base: '#dfeaf3', off: '#dfeaf3', road: '#9cc3db', edge: '#ffffff', water: '#2a6f96', water2: '#a8e0f5', dots: ['rgba(80,110,150,.16)', 'rgba(255,255,255,.55)'], out: '#7f9fb8' },
    port: { base: '#8a8c90', off: '#8a8c90', road: '#3f4148', edge: '#ffd166', water: '#24648c', water2: '#86c6e6', dots: ['rgba(0,0,0,.16)', 'rgba(255,255,255,.1)'], out: '#2a4a60' },
    gorge: { base: '#5c8f45', off: '#5c8f45', road: '#4a4650', edge: '#efe6d2', water: '#3a8ab0', water2: '#a0dcf0', dots: ['rgba(20,50,20,.3)', 'rgba(200,230,150,.16)'], out: '#2c4a22' },
    moon: { base: '#7a7c84', off: '#8a8c94', road: '#5a5c66', edge: '#d8dce4', dots: ['rgba(0,0,0,.18)', 'rgba(255,255,255,.12)'], out: '#121218' },
    hwy: { base: '#1e2a1e', off: '#24301f', road: '#2c2c34', edge: '#f2f2f2', rock: '#1a1a20', rockHi: '#5a5a66', dots: ['rgba(0,0,0,.3)', 'rgba(160,190,140,.08)'], out: '#0c0f0c' },
  };
  const SURF_COL = { dirt: '#a8784a', ice: '#a9dcf2', wood: '#9a6a3c', sand: '#e1c27e', road: '#25222c', rough: '#4a3a34' };
  const HZ_COL = { oil: '#120f18', spring: '#e8c04e', smoke: '#9aa0b4', frost: '#7fd0ff', boom: '#c08a52', tacks: '#d8dde6', net: '#f2f2f2', shock: '#ffd166', grab: '#ee6a55', fw: '#ff5fb4', paint: '#d14fd8', cball: '#17131f', bees: '#ffd166', bomb: '#17131f', wall: '#ee6a55', vort: '#7f8cff', foam: '#e6f6ff' };
  const HARD = { road: 1, ice: 1, metal: 1, yard: 1, wood: 1 };

  /* the colour of the world beyond the drawn map: rock for walled tracks, sea when the course is an island, else ground */
  const beyond = (tr, th) => (tr.wall != null && th.rock ? th.rock : tr.D.water && !tr.D.water.inside ? th.water : th.base);
  /* pre-render the static track into an offscreen canvas at `bs` px per world unit */
  function renderTrack(tr, bs) {
    const D = tr.D, th = THEME[D.th] || THEME.plum, B = tr.bx;
    const W = Math.ceil((B[2] - B[0]) * bs), H = Math.ceil((B[3] - B[1]) * bs);
    const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    const c = cv.getContext('2d');
    c.scale(bs, bs); c.translate(-B[0], -B[1]);
    let seed = 7 + tr.id * 31;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const half = tr.half;
    const path = (off) => { c.beginPath(); for (let i = 0; i <= NS; i++) { const j = i % NS, px = tr.x[j] + tr.nx[j] * off, py = tr.y[j] + tr.ny[j] * off; i ? c.lineTo(px, py) : c.moveTo(px, py); } c.closePath(); };
    const cutPath = (C) => { c.beginPath(); for (let k = 0; k < C.n; k++) k ? c.lineTo(C.sx[k], C.sy[k]) : c.moveTo(C.sx[k], C.sy[k]); };
    const span = (a, b, off, w, col) => { c.strokeStyle = col; c.lineWidth = w; c.beginPath(); for (let i = a; i <= b; i++) { const j = ((i % NS) + NS) % NS; const px = tr.x[j] + tr.nx[j] * off, py = tr.y[j] + tr.ny[j] * off; i === a ? c.moveTo(px, py) : c.lineTo(px, py); } c.stroke(); };
    const inXing = (px, py, m) => [tr.fer, ...tr.dbr].some((X) => X && Math.abs((px - X.x) * Math.cos(X.a) + (py - X.y) * Math.sin(X.a)) < X.wr + 2 + m);
    const nearTrack = (px, py, m) => { for (let i = 0; i < NS; i += 3) if ((px - tr.x[i]) ** 2 + (py - tr.y[i]) ** 2 < m * m) return true; for (const C of tr.cuts) for (let k = 0; k < C.n; k += 2) if ((px - C.sx[k]) ** 2 + (py - C.sy[k]) ** 2 < (C.hw + m - half) ** 2) return true; return false; };
    c.lineJoin = 'round'; c.lineCap = 'round';
    /* ---- themed art helpers (round 8): ground, road deck, scenery props ---- */
    const COLS5 = ['#e8384f', '#5bb3e6', '#ffd166', '#5fd3a0', '#b48cf0'];
    const rx = () => B[0] + rnd() * (B[2] - B[0]), ry = () => B[1] + rnd() * (B[3] - B[1]);
    const blob = (x, y, r, col) => { c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); };
    const shadowE = (x, y, rx2, ry2, a) => { c.fillStyle = 'rgba(0,0,0,' + (a || 0.28) + ')'; c.beginPath(); c.ellipse(x, y, rx2, ry2, 0, 0, 7); c.fill(); };
    /* the spot inside (or outside) the course loop farthest from the road */
    function openSpot(inside, minD) {
      let best = null, bd = -1;
      for (let n = 0; n < 500; n++) {
        const px = B[0] + 10 + rnd() * (B[2] - B[0] - 20), py = B[1] + 10 + rnd() * (B[3] - B[1] - 20);
        if (inside !== inPoly(px, py)) continue;
        let d = 1e9;
        for (let i = 0; i < NS; i += 4) d = Math.min(d, (px - tr.x[i]) ** 2 + (py - tr.y[i]) ** 2);
        for (const C of tr.cuts) for (let k = 0; k < C.n; k += 3) d = Math.min(d, (px - C.sx[k]) ** 2 + (py - C.sy[k]) ** 2);
        if (tr.rivers.some((R) => segDist(R.pts, px, py) < R.w + 6)) continue;
        if (tr.trains.some((Tn) => Math.abs((px - Tn.ax) * Tn.nx + (py - Tn.ay) * Tn.ny) < 16)) continue;
        if (d > bd) { bd = d; best = [px, py]; }
      }
      return best && Math.sqrt(bd) > (minD || 0) ? best : null;
    }
    function groundArt(k) {
      if (k === 'prairie') { // rows of wheat and a few dirt tracks
        for (let n = 0, m = 0; n < 160 && m < 26; n++) {
          const w2 = 20 + rnd() * 30, h2 = 14 + rnd() * 20, px = rx(), py = ry(), R2 = Math.hypot(w2, h2) / 2;
          if (nearTrack(px, py, half + 3 + R2)) continue;
          const a = rnd() * 0.6 - 0.3, col = ['#c9b04a', '#b8a43e', '#9fb04a', '#d6bf5a'][m++ % 4];
          c.save(); c.translate(px, py); c.rotate(a); c.fillStyle = col; c.fillRect(-w2 / 2, -h2 / 2, w2, h2);
          c.strokeStyle = 'rgba(120,95,30,.45)'; c.lineWidth = 0.4; for (let y = -h2 / 2 + 0.8; y < h2 / 2; y += 1.3) { c.beginPath(); c.moveTo(-w2 / 2 + 0.4, y); c.lineTo(w2 / 2 - 0.4, y); c.stroke(); }
          c.restore();
        }
      } else if (k === 'scrap') { // gravel, oil stains
        for (let n = 0; n < 900; n++) blob(rx(), ry(), 0.2 + rnd() * 0.4, rnd() < 0.5 ? 'rgba(40,35,30,.3)' : 'rgba(200,190,170,.25)');
        for (let n = 0; n < 40; n++) { c.fillStyle = 'rgba(20,18,22,.35)'; c.beginPath(); c.ellipse(rx(), ry(), 1.5 + rnd() * 3, 1 + rnd() * 2, rnd() * 3, 0, 7); c.fill(); }
      } else if (k === 'canal' || k === 'clock') { // paved squares
        c.strokeStyle = 'rgba(80,60,40,.18)'; c.lineWidth = 0.25;
        for (let x = B[0]; x < B[2]; x += 3) { c.beginPath(); c.moveTo(x, B[1]); c.lineTo(x, B[3]); c.stroke(); }
        for (let y = B[1]; y < B[3]; y += 3) { c.beginPath(); c.moveTo(B[0], y); c.lineTo(B[2], y); c.stroke(); }
        for (let n = 0; n < 500; n++) { c.fillStyle = rnd() < 0.5 ? 'rgba(255,250,235,.12)' : 'rgba(60,45,30,.1)'; c.fillRect(B[0] + Math.floor(rnd() * (B[2] - B[0]) / 3) * 3, B[1] + Math.floor(rnd() * (B[3] - B[1]) / 3) * 3, 3, 3); }
      } else if (k === 'rally') { // meadow with darker patches
        for (let n = 0; n < 60; n++) { c.fillStyle = 'rgba(40,80,30,.3)'; c.beginPath(); c.ellipse(rx(), ry(), 4 + rnd() * 8, 3 + rnd() * 5, rnd() * 3, 0, 7); c.fill(); }
      } else if (k === 'toy') { // a woven rug with a patterned border, lit by a lamp
        c.lineWidth = 0.35;
        for (let x = B[0]; x < B[2]; x += 1.6) { c.strokeStyle = Math.round(x / 1.6) % 2 ? 'rgba(255,255,255,.05)' : 'rgba(0,30,40,.07)'; c.beginPath(); c.moveTo(x, B[1]); c.lineTo(x, B[3]); c.stroke(); }
        c.strokeStyle = 'rgba(0,30,40,.06)'; for (let y = B[1]; y < B[3]; y += 1.6) { c.beginPath(); c.moveTo(B[0], y); c.lineTo(B[2], y); c.stroke(); }
        for (const [m, col, w] of [[9, '#e3ae45', 2.6], [13, '#c0503e', 1.4], [16, '#f6e3c0', 0.6]]) { c.strokeStyle = col; c.lineWidth = w; c.strokeRect(B[0] + m, B[1] + m, B[2] - B[0] - 2 * m, B[3] - B[1] - 2 * m); }
        c.fillStyle = '#f6e3c0';
        for (let x = B[0] + 13; x < B[2] - 12; x += 6) for (const y of [B[1] + 9, B[3] - 9]) { c.beginPath(); c.moveTo(x, y - 0.9); c.lineTo(x + 0.9, y); c.lineTo(x, y + 0.9); c.lineTo(x - 0.9, y); c.fill(); }
        for (let y = B[1] + 13; y < B[3] - 12; y += 6) for (const x of [B[0] + 9, B[2] - 9]) { c.beginPath(); c.moveTo(x, y - 0.9); c.lineTo(x + 0.9, y); c.lineTo(x, y + 0.9); c.lineTo(x - 0.9, y); c.fill(); }
        const cx = (B[0] + B[2]) / 2, cy = (B[1] + B[3]) * 0.45, g = c.createRadialGradient(cx, cy, 5, cx, cy, Math.max(B[2] - B[0], B[3] - B[1]) * 0.7);
        g.addColorStop(0, 'rgba(255,230,170,.13)'); g.addColorStop(1, 'rgba(0,0,0,.14)'); c.fillStyle = g; c.fillRect(B[0], B[1], B[2] - B[0], B[3] - B[1]);
      } else if (k === 'windmill') { // patchwork of tulip fields between the meadows
        const cols = ['#e8384f', '#ffd166', '#f07fb8', '#b48cf0', '#fff4e8', '#ff8a3d'];
        for (let n = 0, m = 0; n < 160 && m < 34; n++) {
          const w2 = 16 + rnd() * 24, h2 = 11 + rnd() * 16, px = rx(), py = ry(), R2 = Math.hypot(w2, h2) / 2;
          if (nearTrack(px, py, half + 3 + R2)) continue;
          if (tr.rivers.some((R) => segDist(R.pts, px, py) < R.w + R2 + 1)) continue;
          const col = cols[m++ % cols.length];
          c.fillStyle = '#4c7532'; c.fillRect(px - w2 / 2, py - h2 / 2, w2, h2);
          for (let y = -h2 / 2 + 0.6; y < h2 / 2 - 0.9; y += 1.9) { c.fillStyle = col; c.fillRect(px - w2 / 2 + 0.6, py + y, w2 - 1.2, 1.05); c.fillStyle = 'rgba(255,255,255,.2)'; c.fillRect(px - w2 / 2 + 0.6, py + y, w2 - 1.2, 0.28); }
          c.strokeStyle = 'rgba(70,45,20,.4)'; c.lineWidth = 0.35; c.strokeRect(px - w2 / 2, py - h2 / 2, w2, h2);
        }
      } else if (k === 'thunder') { // wet moor: heather, flat rocks, rain puddles
        for (let n = 0; n < 520; n++) blob(rx(), ry(), 0.6 + rnd() * 1.4, rnd() < 0.5 ? 'rgba(120,80,130,.28)' : 'rgba(90,120,80,.25)');
        for (let n = 0; n < 70; n++) { const px = rx(), py = ry(); if (nearTrack(px, py, half + 4)) continue; c.fillStyle = 'rgba(30,50,70,.6)'; c.beginPath(); c.ellipse(px, py, 1.5 + rnd() * 3.5, 0.8 + rnd() * 1.6, rnd() * 3, 0, 7); c.fill(); c.strokeStyle = 'rgba(170,200,230,.25)'; c.lineWidth = 0.2; c.stroke(); }
      } else if (k === 'aurora') { // wind-carved snow ridges with blue shadows
        for (let n = 0; n < 170; n++) {
          const x0 = rx(), y0 = ry();
          c.strokeStyle = 'rgba(80,110,160,.22)'; c.lineWidth = 0.7; c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(x0 + 5, y0 - 2.2, x0 + 11, y0 - 0.5); c.stroke();
          c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 0.4; c.beginPath(); c.moveTo(x0, y0 - 0.5); c.quadraticCurveTo(x0 + 5, y0 - 2.7, x0 + 11, y0 - 1); c.stroke();
        }
      } else if (k === 'plum') { // gravel traps on the outside of the sharp corners
        for (let i = 0; i < NS; i += 2) {
          if (tr.acurv[i] < 0.03) continue;
          const sd = (tr.curv[i] > 0 ? -1 : 1), o = sd * (half + 4.2);
          c.fillStyle = 'rgba(214,196,160,.9)'; c.beginPath(); c.arc(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o, 3.6, 0, 7); c.fill();
        }
        for (let i = 0; i < NS; i += 2) { if (tr.acurv[i] < 0.03) continue; const sd = (tr.curv[i] > 0 ? -1 : 1), o = sd * (half + 4.2); for (let q = 0; q < 3; q++) blob(tr.x[i] + tr.nx[i] * (o + (rnd() - 0.5) * 5) , tr.y[i] + tr.ny[i] * (o + (rnd() - 0.5) * 5) + (rnd() - 0.5) * 2, 0.18, 'rgba(120,100,70,.5)'); }
      } else if (k === 'rail') { // farmland: crop fields in rows
        const cols = [['#c9b04a', '#a8913a'], ['#4f8a3a', '#3e7230'], ['#8a6a3a', '#6e542e'], ['#9fbf5a', '#86a64a']];
        for (let n = 0, m = 0; n < 120 && m < 22; n++) {
          const w2 = 20 + rnd() * 26, h2 = 14 + rnd() * 18, px = rx(), py = ry(), R2 = Math.hypot(w2, h2) / 2;
          if (nearTrack(px, py, half + 3 + R2)) continue;
          const Tn = tr.trains[0]; if (Tn && Math.abs((px - Tn.ax) * Tn.nx + (py - Tn.ay) * Tn.ny) < R2 + 5) continue;
          const [c1, c2] = cols[m++ % cols.length], a = rnd() * 0.5 - 0.25;
          c.save(); c.translate(px, py); c.rotate(a); c.fillStyle = c1; c.fillRect(-w2 / 2, -h2 / 2, w2, h2);
          c.strokeStyle = c2; c.lineWidth = 0.6; for (let y = -h2 / 2 + 1; y < h2 / 2; y += 1.6) { c.beginPath(); c.moveTo(-w2 / 2 + 0.5, y); c.lineTo(w2 / 2 - 0.5, y); c.stroke(); }
          c.strokeStyle = 'rgba(60,40,20,.35)'; c.lineWidth = 0.3; c.strokeRect(-w2 / 2, -h2 / 2, w2, h2); c.restore();
        }
      } else if (k === 'ranch' || k === 'season' || k === 'gorge' || k === 'river' || k === 'fest' || k === 'bridge') { // meadows: patches, flowers
        for (let n = 0; n < 70; n++) { c.fillStyle = k === 'ranch' ? 'rgba(170,190,80,.35)' : 'rgba(40,80,30,.28)'; c.beginPath(); c.ellipse(rx(), ry(), 4 + rnd() * 9, 3 + rnd() * 5, rnd() * 3, 0, 7); c.fill(); }
        const fl = k === 'fest' ? COLS5 : k === 'season' ? ['#ffb3cf', '#fff3f8', '#ffd166'] : ['#fff4e8', '#ffd166'];
        for (let n = 0; n < 500; n++) blob(rx(), ry(), 0.25, fl[n % fl.length]);
        if (k === 'ranch') for (const sd of [-1, 1]) { // wooden fences along the lane
          for (let i = 0; i < NS; i += 3) { const o = sd * (half + 3.2), px = tr.x[i] + tr.nx[i] * o, py = tr.y[i] + tr.ny[i] * o; c.fillStyle = '#6b4a2c'; c.fillRect(px - 0.3, py - 0.3, 0.6, 0.6); }
          path(sd * (half + 3.2)); c.strokeStyle = 'rgba(140,100,60,.8)'; c.lineWidth = 0.25; c.stroke();
        }
      } else if (k === 'ski' || k === 'icelake') { // snow ridges and ski tracks
        for (let n = 0; n < 160; n++) { const x0 = rx(), y0 = ry(); c.strokeStyle = 'rgba(120,150,190,.2)'; c.lineWidth = 0.6; c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(x0 + 5, y0 - 2, x0 + 11, y0 - 0.5); c.stroke(); }
        if (k === 'ski') for (let n = 0; n < 16; n++) { let x0 = rx(), y0 = ry(); c.strokeStyle = 'rgba(150,175,205,.35)'; c.lineWidth = 0.2; c.beginPath(); c.moveTo(x0, y0); for (let q = 0; q < 10; q++) { x0 += Math.sin(q * 1.3) * 3; y0 += 3; c.lineTo(x0, y0); } c.stroke(); }
      } else if (k === 'moon') { // grey regolith with craters and the black sky at the edges
        for (let n = 0; n < 900; n++) blob(rx(), ry(), 0.2 + rnd() * 0.4, rnd() < 0.5 ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.1)');
        for (let n = 0; n < 50; n++) { const px = rx(), py = ry(), r = 2 + rnd() * 7; if (nearTrack(px, py, half + r + 1)) continue; c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.arc(px + r * 0.15, py + r * 0.15, r, 0, 7); c.fill(); c.fillStyle = '#6e7078'; c.beginPath(); c.arc(px, py, r * 0.9, 0, 7); c.fill(); c.strokeStyle = 'rgba(220,224,232,.45)'; c.lineWidth = 0.4; c.beginPath(); c.arc(px, py, r, 3.6, 5.8); c.stroke(); }
      } else if (k === 'port') { // concrete slabs and painted bays
        c.strokeStyle = 'rgba(0,0,0,.12)'; c.lineWidth = 0.2;
        for (let x = B[0]; x < B[2]; x += 6) { c.beginPath(); c.moveTo(x, B[1]); c.lineTo(x, B[3]); c.stroke(); }
        for (let y = B[1]; y < B[3]; y += 6) { c.beginPath(); c.moveTo(B[0], y); c.lineTo(B[2], y); c.stroke(); }
      } else if (k === 'storm') { // big wind ripples and darker dune crests
        for (let n = 0; n < 40; n++) { const x0 = rx(), y0 = ry(), L2 = 20 + rnd() * 30; c.strokeStyle = 'rgba(150,100,45,.35)'; c.lineWidth = 1.6; c.beginPath(); c.moveTo(x0, y0); c.bezierCurveTo(x0 + L2 * 0.3, y0 - 6, x0 + L2 * 0.7, y0 + 4, x0 + L2, y0 - 2); c.stroke(); c.strokeStyle = 'rgba(255,235,190,.3)'; c.lineWidth = 0.6; c.beginPath(); c.moveTo(x0, y0 - 1); c.bezierCurveTo(x0 + L2 * 0.3, y0 - 7, x0 + L2 * 0.7, y0 + 3, x0 + L2, y0 - 3); c.stroke(); }
      }
    }
    /* round 12 scenery off the course */
    function props12(props) {
      const k = D.th;
      if (k === 'ranch') {
        props(20, 5, (px, py) => { const r = rnd(); if (r < 0.5) { c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.arc(px + 0.5, py + 0.7, 1.6, 0, 7); c.fill(); c.fillStyle = '#e3c46a'; c.beginPath(); c.arc(px, py, 1.5, 0, 7); c.fill(); c.strokeStyle = 'rgba(140,100,40,.6)'; c.lineWidth = 0.2; c.beginPath(); c.arc(px, py, 0.9, 0, 7); c.stroke(); } else { for (let q = 0; q < 3; q++) { const x = px + (rnd() - 0.5) * 6, y = py + (rnd() - 0.5) * 6; blob(x, y, 0.8, '#f6f2ea'); blob(x + 0.8, y, 0.35, '#2b2533'); } } });
        props(2, 14, (px, py) => { c.save(); c.translate(px, py); c.rotate(rnd()); c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-5, -3.4, 11, 8); c.fillStyle = '#a8382a'; c.fillRect(-5.5, -4, 11, 8); c.fillStyle = '#7a2a20'; c.fillRect(-5.5, -0.3, 11, 0.6); c.fillStyle = '#f2ede4'; c.fillRect(-1.2, 2.2, 2.4, 1.8); c.restore(); });
      } else if (k === 'canyon') {
        props(10, 6, (px, py) => { c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.ellipse(px + 0.8, py + 1, 1.6, 1, 0.4, 0, 7); c.fill(); c.fillStyle = '#4f7a3a'; c.beginPath(); c.arc(px, py, 1.2, 0, 7); c.fill(); });
      } else if (k === 'fest') { // hot-air balloons and striped tents
        props(10, 6, (px, py) => { const col = COLS5[Math.floor(rnd() * 5)]; c.fillStyle = 'rgba(0,0,0,.18)'; c.beginPath(); c.arc(px + 3, py + 4, 3.2, 0, 7); c.fill(); for (let q = 0; q < 8; q++) { c.fillStyle = q % 2 ? col : '#f2ede4'; c.beginPath(); c.moveTo(px, py); c.arc(px, py, 3.4, (q * Math.PI) / 4, ((q + 1) * Math.PI) / 4); c.fill(); } blob(px, py, 0.7, '#7a4a2c'); });
      } else if (k === 'ski') {
        props(2, 12, (px, py) => { c.save(); c.translate(px, py); c.rotate(0.2); c.fillStyle = 'rgba(40,60,90,.3)'; c.fillRect(-5, -3, 12, 8); c.fillStyle = '#7a4a2c'; c.fillRect(-6, -4, 12, 8); c.fillStyle = '#ffffff'; c.fillRect(-6, -4, 12, 3.6); c.fillRect(-6, 0.4, 12, 3.6); c.restore(); });
        props(8, 6, (px, py) => { blob(px, py, 0.7, '#5a5464'); c.strokeStyle = 'rgba(40,40,50,.5)'; c.lineWidth = 0.2; c.beginPath(); c.moveTo(px, py); c.lineTo(px + 14, py - 10); c.stroke(); });
      } else if (k === 'moon') { // habitat domes and the Earth over the horizon
        props(4, 10, (px, py) => { const r = 3 + rnd() * 3, g = c.createRadialGradient(px - r * 0.3, py - r * 0.3, 0.3, px, py, r); g.addColorStop(0, '#f2f6ff'); g.addColorStop(1, '#8a9ab0'); c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(px + 0.6, py + 0.8, r, 0, 7); c.fill(); c.fillStyle = g; c.beginPath(); c.arc(px, py, r, 0, 7); c.fill(); c.strokeStyle = 'rgba(80,100,130,.6)'; c.lineWidth = 0.2; for (let q = -r; q < r; q += 1.5) { c.beginPath(); c.moveTo(px + q, py - Math.sqrt(Math.max(0, r * r - q * q))); c.lineTo(px + q, py + Math.sqrt(Math.max(0, r * r - q * q))); c.stroke(); } });
        const ex = B[0] + 22, ey = B[1] + 22, g = c.createRadialGradient(ex - 3, ey - 3, 1, ex, ey, 10); g.addColorStop(0, '#9fe0ff'); g.addColorStop(0.7, '#2e6fb0'); g.addColorStop(1, '#1d3f70'); c.fillStyle = g; c.beginPath(); c.arc(ex, ey, 10, 0, 7); c.fill(); blob(ex - 2, ey + 1, 3, 'rgba(95,180,90,.8)'); blob(ex + 3, ey - 3, 2, 'rgba(95,180,90,.8)');
      } else if (k === 'port' || k === 'river' || k === 'bridge') { // boats on the water, containers on the quay
        const cols = ['#c0392b', '#2e86c1', '#e8a33d', '#27ae60'];
        if (k === 'port') props(20, 5, (px, py) => { const vert = rnd() < 0.5, w2 = vert ? 2.4 : 6, h2 = vert ? 6 : 2.4; c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(px - w2 / 2 + 0.6, py - h2 / 2 + 0.8, w2, h2); c.fillStyle = cols[Math.floor(rnd() * 4)]; c.fillRect(px - w2 / 2, py - h2 / 2, w2, h2); });
        if (k === 'bridge') { const sp = openSpot(false, 12); if (sp) { const [px, py] = sp; blob(px, py, 2.4, '#f2f2f2'); blob(px, py, 1.6, '#e8384f'); blob(px, py, 0.7, '#ffd166'); } }
        for (const X of [tr.fer, ...tr.dbr]) if (X) for (const sd of [-1, 1]) { const ux = -Math.sin(X.a), uy = Math.cos(X.a), px = X.x + ux * sd * (half + 26), py = X.y + uy * sd * (half + 26); c.save(); c.translate(px, py); c.rotate(X.a + Math.PI / 2); c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.ellipse(0.5, 0.6, 4.4, 1.6, 0, 0, 7); c.fill(); c.fillStyle = '#f2ede4'; c.beginPath(); c.ellipse(0, 0, 4.2, 1.5, 0, 0, 7); c.fill(); c.fillStyle = cols[Math.floor(rnd() * 4)]; c.fillRect(-1.6, -0.8, 2.6, 1.6); c.restore(); }
      } else if (k === 'stadium') { // a scoreboard in the infield
        const sp = openSpot(true, 14); if (sp) { const [px, py] = sp; c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(px - 9, py - 4, 19, 9); c.fillStyle = '#17131f'; c.fillRect(px - 10, py - 5, 19, 9); c.fillStyle = '#ffd166'; for (let q = 0; q < 5; q++) c.fillRect(px - 8 + q * 3.3, py - 3, 2.4, 4); c.fillStyle = '#ee6a55'; c.fillRect(px - 8, py + 2, 15, 1); }
      } else if (k === 'hwy') { // green motorway signs on the verge
        for (let i = 20; i < NS; i += 75) { const sd = i % 150 < 75 ? 1 : -1, o = sd * (half + (tr.wall || 0) + 2.6), px = tr.x[i] + tr.nx[i] * o, py = tr.y[i] + tr.ny[i] * o; c.save(); c.translate(px, py); c.rotate(tr.hd[i]); c.fillStyle = '#1f7a4a'; c.fillRect(-0.4, -2.6, 0.8, 5.2); c.strokeStyle = '#f2f2f2'; c.lineWidth = 0.2; c.strokeRect(-0.3, -2.4, 0.6, 4.8); c.restore(); }
      }
    }
    /* round 12: static parts of the new gimmicks (moving bits are drawn live) */
    function art12() {
      const across = (P2, al, l0, l1) => { const ca = Math.cos(P2.a), sa = Math.sin(P2.a); return [P2.x + ca * al - sa * l0, P2.y + sa * al + ca * l0, P2.x + ca * al - sa * l1, P2.y + sa * al + ca * l1]; };
      const quad = (P2, a0, a1, l0, l1) => { const ca = Math.cos(P2.a), sa = Math.sin(P2.a); c.beginPath(); for (const [al, lt] of [[a0, l0], [a1, l0], [a1, l1], [a0, l1]]) c.lineTo(P2.x + ca * al - sa * lt, P2.y + sa * al + ca * lt); c.closePath(); };
      const post = (x, y, r, col) => { c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(x + 0.3, y + 0.4, r, 0, 7); c.fill(); c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, 7); c.fill(); };
      const at2 = (i, l) => [tr.x[i] + tr.nx[i] * l, tr.y[i] + tr.ny[i] * l];
      // jump ramps before the chasms: a kicker with arrows
      for (const p of tr.leaps) {
        c.save(); c.translate(p.x, p.y); c.rotate(p.a);
        const g = c.createLinearGradient(-3.4, 0, 1.8, 0); g.addColorStop(0, '#5a3a20'); g.addColorStop(1, '#d39a5a');
        c.fillStyle = g; c.fillRect(-3.4, -half + 0.3, 5.2, half * 2 - 0.6);
        c.fillStyle = '#17131f'; c.fillRect(1.2, -half + 0.3, 0.6, half * 2 - 0.6);
        c.fillStyle = '#ffd166'; for (let k = -half + 0.6; k < half - 0.6; k += 1.6) c.fillRect(1.2, k, 0.6, 0.8);
        c.strokeStyle = '#ffd166'; c.lineWidth = 0.4; for (const l of [-half * 0.5, 0, half * 0.5]) { c.beginPath(); c.moveTo(-2.6, l - 1); c.lineTo(-1.4, l); c.lineTo(-2.6, l + 1); c.stroke(); }
        c.restore();
      }
      // ferry: the river over the road, bank planks, the pier between the lanes, rails
      if (tr.fer) {
        const F = tr.fer, wr = F.wr;
        quad(F, -wr, wr, -half - 1, half + 1); c.fillStyle = th.water; c.fill();
        for (const sd of [-1, 1]) { quad(F, sd * wr - 1.2, sd * wr + 1.2, -half - 0.6, half + 0.6); c.fillStyle = '#8a6a43'; c.fill(); c.strokeStyle = 'rgba(50,30,10,.5)'; c.lineWidth = 0.15; for (let k = -half; k < half; k += 0.8) { const [x0, y0, x1, y1] = across(F, sd * wr - 1.2, k, k); const [x2, y2] = across(F, sd * wr + 1.2, k, k); c.beginPath(); c.moveTo(x0, y0); c.lineTo(x2, y2); c.stroke(); } }
        quad(F, -wr - 7, wr + 0.5, -FER_PIER, FER_PIER); c.fillStyle = '#6d6458'; c.fill(); c.strokeStyle = '#e3ae45'; c.lineWidth = 0.2; c.stroke();
        for (const sd of [-1, 1]) { const [x0, y0] = across(F, -wr, sd * half, 0), [x1, y1] = across(F, wr, sd * half, 0); c.strokeStyle = '#3d2814'; c.lineWidth = 0.5; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke(); for (let al = -wr; al <= wr; al += 2.6) { const [px, py] = across(F, al, sd * half, 0); post(px, py, 0.35, '#5a3d26'); } }
      }
      for (const F of [tr.fer, ...tr.dbr]) if (F) { // other places the river / canal passes under the road: plain bridges with railings
        for (let i = 0; i < NS; i++) {
          if ([tr.fer, ...tr.dbr].some((X) => X && idxDist(i, X.i) * tr.ds < X.wr + 6)) continue;
          const u = (tr.x[i] - F.x) * Math.cos(F.a) + (tr.y[i] - F.y) * Math.sin(F.a);
          if (Math.abs(u) > F.wr + 2.5) continue;
          for (const sd of [-1, 1]) { const [px, py] = at2(i, sd * (half + 0.5)); c.fillStyle = '#d8d0c2'; c.beginPath(); c.arc(px, py, 0.4, 0, 7); c.fill(); }
        }
      }
      // drawbridges: the canal under the span, stone hinge towers, rails
      for (const B2 of tr.dbr) {
        quad(B2, -B2.wr, B2.wr, -half - 1, half + 1); c.fillStyle = th.water; c.fill();
        for (const sd of [-1, 1]) {
          for (const lt of [-half - 1.6, half + 1.6]) { const [px, py] = across(B2, sd * (B2.wr + 0.9), lt, 0); c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(px - 1.3, py - 1, 2.8, 2.8); c.fillStyle = '#8a8496'; c.fillRect(px - 1.4, py - 1.4, 2.8, 2.8); c.fillStyle = '#e3ae45'; c.fillRect(px - 0.5, py - 0.5, 1, 1); }
          quad(B2, sd * B2.wr - 0.4, sd * B2.wr + 0.4, -half, half); c.fillStyle = '#2b2d33'; c.fill();
        }
      }
      // banked curves: the low inside in shade, the high outside lit, a blue-and-white top edge
      for (let i = 0; i < NS; i++) {
        const o = tr.bank[i]; if (!o) continue;
        const j = (i + 1) % NS;
        c.lineCap = 'butt';
        for (const [l, w2, col] of [[-o * half * 0.55, half * 0.9, 'rgba(0,0,0,.16)'], [o * half * 0.55, half * 0.9, 'rgba(255,255,255,.07)'], [o * (half + 0.5), 1, i % 4 < 2 ? '#2e86c1' : '#f2f2f2']]) {
          const [x0, y0] = at2(i, l), [x1, y1] = at2(j, l); c.strokeStyle = col; c.lineWidth = w2; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1 + tr.tx[j] * 0.2, y1 + tr.ty[j] * 0.2); c.stroke();
        }
        if (i % 6 === 0) { const [x0, y0] = at2(i, -o * (half - 1)), [x1, y1] = at2(i, o * (half - 1)); c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 0.25; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke(); }
        c.lineCap = 'round';
      }
      // sheep crossings: a yellow warning sign on both sides
      for (const Hd of tr.herd) for (const sd of [-1, 1]) {
        const [px, py] = at2((Hd.i - Math.round(9 / tr.ds) + NS) % NS, sd * (half + 2.4));
        post(px, py, 0.25, '#5a5464');
        c.save(); c.translate(px, py); c.rotate(Math.PI / 4); c.fillStyle = '#ffd166'; c.fillRect(-1.2, -1.2, 2.4, 2.4); c.strokeStyle = '#17131f'; c.lineWidth = 0.18; c.strokeRect(-1, -1, 2, 2); c.restore();
        c.fillStyle = '#17131f'; c.beginPath(); c.ellipse(px, py + 0.1, 0.6, 0.4, 0, 0, 7); c.fill();
      }
      // gusts: windsock posts at both ends of each windy stretch, railing posts along it
      if (tr.gust) for (const [a, b] of tr.gust.zones) for (const sd of [-1, 1]) { // the bridge deck: concrete edges and girders
        const i0 = Math.round(a * NS), i1 = Math.round(b * NS);
        span(i0, i1, sd * (half + 0.9), 1.4, '#8f949c'); span(i0, i1, sd * (half + 1.5), 0.3, 'rgba(0,0,0,.35)');
        for (let i = i0; i <= i1; i += 8) { const [x0, y0] = at2(i % NS, -half - 1.2), [x1, y1] = at2(i % NS, half + 1.2); c.strokeStyle = 'rgba(0,0,0,.12)'; c.lineWidth = 0.4; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke(); }
      }
      if (tr.gust) for (const [a, b] of tr.gust.zones) {
        for (let i = Math.round(a * NS); i <= Math.round(b * NS); i += 3) for (const sd of [-1, 1]) { const [px, py] = at2(i % NS, sd * (half + 0.7)); post(px, py, 0.3, '#d8dde6'); }
        for (const f of [a, b]) for (const sd of [-1, 1]) { const [px, py] = at2(Math.round(f * NS) % NS, sd * (half + 2.6)); post(px, py, 0.55, '#ee6a55'); post(px, py, 0.25, '#f2f2f2'); }
      }
      // slalom gates: two poles with little flags
      for (const g of tr.flags) {
        const col = g.k % 2 ? '#2e86c1' : '#e8384f';
        const [x0, y0] = at2(g.i, g.lat - g.w), [x1, y1] = at2(g.i, g.lat + g.w);
        c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 0.2; c.setLineDash([0.6, 0.6]); c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke(); c.setLineDash([]);
        for (const [px, py] of [[x0, y0], [x1, y1]]) { c.fillStyle = col; c.beginPath(); c.moveTo(px, py); c.lineTo(px - tr.tx[g.i] * 2.4 + tr.nx[g.i] * 0.9, py - tr.ty[g.i] * 2.4 + tr.ny[g.i] * 0.9); c.lineTo(px - tr.tx[g.i] * 2.4 - tr.nx[g.i] * 0.9, py - tr.ty[g.i] * 2.4 - tr.ny[g.i] * 0.9); c.fill(); post(px, py, 0.5, '#2b2533'); }
      }
      // boost rings: the gantry posts and the wire the ring slides on
      for (const H of tr.hoops) {
        const [x0, y0] = at2(H.i, -half - 1.6), [x1, y1] = at2(H.i, half + 1.6);
        c.strokeStyle = 'rgba(40,30,50,.55)'; c.lineWidth = 0.25; c.beginPath(); c.moveTo(x0, y0); c.lineTo(x1, y1); c.stroke();
        post(x0, y0, 0.8, '#5a5464'); post(x1, y1, 0.8, '#5a5464'); post(x0, y0, 0.35, '#ff5fb4'); post(x1, y1, 0.35, '#4fe3ff');
      }
      // puddles on the ice
      for (const q of tr.puds) {
        const gr = c.createRadialGradient(q.x - q.r * 0.3, q.y - q.r * 0.3, 0.2, q.x, q.y, q.r);
        gr.addColorStop(0, '#bfe8f6'); gr.addColorStop(0.7, '#4f9cc4'); gr.addColorStop(1, '#3d7fa6');
        c.fillStyle = 'rgba(255,255,255,.6)'; c.beginPath(); c.ellipse(q.x, q.y, q.r + 0.4, q.r * 0.86 + 0.4, tr.hd[q.i], 0, 7); c.fill();
        c.fillStyle = gr; c.beginPath(); c.ellipse(q.x, q.y, q.r, q.r * 0.86, tr.hd[q.i], 0, 7); c.fill();
        c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 0.16; c.beginPath(); c.arc(q.x, q.y, q.r * 0.5, 0, 7); c.stroke();
      }
      // moon craters: a bowl with a lit rim
      for (const q of tr.crat) {
        const gr = c.createRadialGradient(q.x + q.r * 0.25, q.y + q.r * 0.25, 0.2, q.x, q.y, q.r);
        gr.addColorStop(0, '#3e4048'); gr.addColorStop(0.8, '#5a5c66'); gr.addColorStop(1, '#6a6c76');
        c.fillStyle = gr; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.fill();
        c.strokeStyle = '#c8ccd6'; c.lineWidth = 0.7; c.beginPath(); c.arc(q.x, q.y, q.r, 3.4, 5.9); c.stroke();
        c.strokeStyle = '#2e3038'; c.beginPath(); c.arc(q.x, q.y, q.r, 0.3, 2.8); c.stroke();
      }
      // the same-level crossroads: a hatched yellow box and zebra crossings
      if (tr.xing) {
        const X = tr.xing;
        c.save(); c.beginPath(); c.arc(X.x, X.y, half * 1.5, 0, 7); c.clip();
        c.strokeStyle = 'rgba(242,194,48,.75)'; c.lineWidth = 0.35;
        for (let k = -24; k <= 24; k += 2.4) { c.beginPath(); c.moveTo(X.x + k - 20, X.y - 20); c.lineTo(X.x + k + 20, X.y + 20); c.moveTo(X.x + k + 20, X.y - 20); c.lineTo(X.x + k - 20, X.y + 20); c.stroke(); }
        c.restore();
        for (const i of [X.i, X.j]) for (const dd of [-1, 1]) {
          const j = (i + dd * Math.round((half * 1.9) / tr.ds) + NS) % NS;
          for (let l = -half + 0.8; l < half - 0.6; l += 1.4) { const [px, py] = at2(j, l); c.fillStyle = 'rgba(255,255,255,.8)'; c.save(); c.translate(px, py); c.rotate(tr.hd[j]); c.fillRect(-1, -0.35, 2, 0.7); c.restore(); }
        }
      }
      // market stands: a wooden table under each item on show
      for (const b of tr.boxes) {
        if (!b.show) continue;
        c.save(); c.translate(b.x, b.y); c.rotate(b.a);
        c.fillStyle = 'rgba(0,0,0,.35)'; rr(c, -1.6, -1.6, 3.6, 3.6, 0.5); c.fill();
        c.fillStyle = '#7a4a2c'; rr(c, -1.8, -1.8, 3.6, 3.6, 0.5); c.fill(); c.fillStyle = '#a3713f'; rr(c, -1.5, -1.5, 3, 3, 0.4); c.fill();
        c.fillStyle = ['#e8384f', '#2e86c1', '#5fd3a0'][b.id % 3]; for (let k = -1.8; k < 1.8; k += 0.9) { c.beginPath(); c.arc(k + 0.45, -1.9, 0.45, Math.PI, 0); c.fill(); }
        c.restore();
      }
    }
    /* infield of the tidal track: mud ripples, winding creeks, crab holes, shells */
    function tideArt() {
      c.save(); c.beginPath(); for (let i = 0; i < NS; i += 2) i ? c.lineTo(tr.x[i], tr.y[i]) : c.moveTo(tr.x[i], tr.y[i]); c.closePath(); c.clip();
      c.strokeStyle = 'rgba(60,45,30,.28)'; c.lineWidth = 0.35;
      for (let n = 0; n < 380; n++) { const x0 = rx(), y0 = ry(); c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(x0 + 1.6, y0 - 0.8, x0 + 3.2, y0); c.stroke(); }
      for (let n = 0; n < 8; n++) {
        let x0 = rx(), y0 = ry(), a = rnd() * 6;
        c.strokeStyle = 'rgba(110,160,180,.6)'; c.lineWidth = 0.5 + rnd() * 1.3; c.beginPath(); c.moveTo(x0, y0);
        for (let q = 0; q < 26; q++) { a += (rnd() - 0.5) * 0.9; x0 += Math.cos(a) * 3; y0 += Math.sin(a) * 3; c.lineTo(x0, y0); }
        c.stroke();
      }
      for (let n = 0; n < 600; n++) blob(rx(), ry(), 0.14, 'rgba(40,28,18,.6)');
      for (let n = 0; n < 140; n++) { c.fillStyle = rnd() < 0.5 ? 'rgba(250,240,225,.7)' : 'rgba(230,200,190,.7)'; c.beginPath(); c.ellipse(rx(), ry(), 0.3, 0.2, rnd() * 3, 0, 7); c.fill(); }
      c.restore();
    }
    /* themed road surfaces; returns false to keep the plain asphalt finish */
    function deckArt(k) {
      const across = (i, w, col, lw) => { c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); c.moveTo(tr.x[i] - tr.nx[i] * w, tr.y[i] - tr.ny[i] * w); c.lineTo(tr.x[i] + tr.nx[i] * w, tr.y[i] + tr.ny[i] * w); c.stroke(); };
      if (k === 'toy') { // wooden toy-track planks with grain and two grooves
        c.lineCap = 'butt';
        for (let i = 0; i < NS; i += 2) across(i, half - 0.2, 'rgba(90,50,20,.32)', 0.14);
        for (let q = 0; q < 8; q++) { path((rnd() * 2 - 1) * (half - 1)); c.strokeStyle = 'rgba(120,70,30,.12)'; c.lineWidth = 0.18; c.stroke(); }
        for (const sd of [-1, 1]) { path(sd * half * 0.45); c.strokeStyle = 'rgba(90,50,20,.3)'; c.lineWidth = 0.8; c.stroke(); path(sd * half * 0.45 + 0.3); c.strokeStyle = 'rgba(255,240,210,.2)'; c.lineWidth = 0.2; c.stroke(); }
        c.lineCap = 'round';
        return true;
      }
      if (k === 'factory') { // polished concrete: slab joints, floor arrows
        c.lineCap = 'butt';
        for (let i = 0; i < NS; i += 5) across(i, half - 0.3, 'rgba(0,0,0,.16)', 0.12);
        path(0); c.strokeStyle = 'rgba(0,0,0,.12)'; c.lineWidth = 0.15; c.stroke();
        for (let i = 12; i < NS; i += 34) {
          if (tr.belt[i] || tr.acurv[i] > 0.02) continue;
          c.save(); c.translate(tr.x[i], tr.y[i]); c.rotate(tr.hd[i]); c.fillStyle = 'rgba(255,255,255,.3)';
          c.beginPath(); c.moveTo(1.8, 0); c.lineTo(-0.4, -1.5); c.lineTo(-0.4, -0.55); c.lineTo(-2.2, -0.55); c.lineTo(-2.2, 0.55); c.lineTo(-0.4, 0.55); c.lineTo(-0.4, 1.5); c.closePath(); c.fill(); c.restore();
        }
        c.lineCap = 'round';
        return true;
      }
      if (k === 'thunder') { // rain-soaked asphalt: long sheen streaks and puddle glints
        for (let q = 0; q < 10; q++) { path((rnd() * 2 - 1) * (half - 1.5)); c.strokeStyle = 'rgba(190,210,240,.06)'; c.lineWidth = 0.6 + rnd(); c.setLineDash([4 + rnd() * 8, 6 + rnd() * 10]); c.stroke(); }
        c.setLineDash([]);
        for (let i = 0; i < NS; i += 7) { const l = (rnd() * 2 - 1) * (half - 2); c.fillStyle = 'rgba(150,175,210,.13)'; c.beginPath(); c.ellipse(tr.x[i] + tr.nx[i] * l, tr.y[i] + tr.ny[i] * l, 1.6 + rnd() * 2, 0.7 + rnd() * 0.6, tr.hd[i], 0, 7); c.fill(); }
        path(0); c.strokeStyle = 'rgba(230,230,240,.35)'; c.lineWidth = 0.3; c.setLineDash([2.5, 3]); c.stroke(); c.setLineDash([]);
        return true;
      }
      if (k === 'aurora') { // glacier ice: white veins, cracks, trapped bubbles
        for (let q = 0; q < 8; q++) { path((rnd() * 2 - 1) * (half - 1)); c.strokeStyle = 'rgba(255,255,255,.2)'; c.lineWidth = 0.3 + rnd() * 0.6; c.stroke(); }
        c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 0.14;
        for (let i = 0; i < NS; i += 2) { if (rnd() < 0.5) continue; const l = (rnd() * 2 - 1) * (half - 1); let px = tr.x[i] + tr.nx[i] * l, py = tr.y[i] + tr.ny[i] * l; c.beginPath(); c.moveTo(px, py); for (let q = 0; q < 3; q++) { px += (rnd() - 0.5) * 2.4; py += (rnd() - 0.5) * 2.4; c.lineTo(px, py); } c.stroke(); }
        for (let n = 0; n < NS * 2; n++) { const j = Math.floor(rnd() * NS), l = (rnd() * 2 - 1) * (half - 0.8); blob(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, 0.1 + rnd() * 0.18, 'rgba(255,255,255,.35)'); }
        for (const sd of [-1, 1]) { path(sd * (half - 0.35)); c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 0.5; c.stroke(); }
        return true;
      }
      if (k === 'haunt') { // worn cobblestones
        for (let i = 0; i < NS; i++) for (let l = -half + 0.7 + (i % 2) * 0.6; l < half - 0.5; l += 1.25) {
          const px = tr.x[i] + tr.nx[i] * l, py = tr.y[i] + tr.ny[i] * l, r = rnd();
          c.fillStyle = r < 0.4 ? 'rgba(255,255,255,.06)' : r < 0.8 ? 'rgba(0,0,0,.14)' : 'rgba(110,130,90,.18)';
          c.fillRect(px - 0.48, py - 0.48, 0.96, 0.96);
        }
        return true;
      }
      if (k === 'tide') { // a causeway: stone blocks along both edges
        for (const sd of [-1, 1]) for (let i = 0; i < NS; i += 2) {
          const o = sd * (half - 0.45); c.save(); c.translate(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o); c.rotate(tr.hd[i]);
          c.fillStyle = (i / 2) % 2 ? '#8a8276' : '#a39a8c'; c.fillRect(-0.95, -0.42, 1.9, 0.84); c.restore();
        }
        path(0); c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 0.3; c.setLineDash([2, 2.5]); c.stroke(); c.setLineDash([]);
        return true;
      }
      if (k === 'library') { // polished wooden floor boards and a runner rug down the middle
        c.lineCap = 'butt';
        for (let q = -half + 1.2; q < half; q += 1.2) { path(q); c.strokeStyle = 'rgba(60,35,15,.3)'; c.lineWidth = 0.1; c.stroke(); }
        for (let i = 0; i < NS; i += 3) across(i, half - 0.2, 'rgba(60,35,15,.18)', 0.08);
        path(0); c.strokeStyle = 'rgba(122,42,52,.55)'; c.lineWidth = half * 0.8; c.stroke();
        for (const sd of [-1, 1]) { path(sd * half * 0.38); c.strokeStyle = 'rgba(227,174,69,.55)'; c.lineWidth = 0.25; c.stroke(); }
        c.lineCap = 'round';
        return true;
      }
      if (k === 'disco') { for (let n = 0; n < NS * 2; n++) { const j = Math.floor(rnd() * NS), l = (rnd() * 2 - 1) * (half - 0.5); blob(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, 0.08 + rnd() * 0.12, rnd() < 0.5 ? 'rgba(255,95,180,.35)' : 'rgba(79,227,255,.35)'); } return true; }
      if (k === 'foundry') { c.lineCap = 'butt'; for (let i = 0; i < NS; i += 3) across(i, half - 0.2, 'rgba(0,0,0,.3)', 0.14); for (let i = 1; i < NS; i += 3) for (const l of [-half * 0.5, half * 0.5]) blob(tr.x[i] + tr.nx[i] * l, tr.y[i] + tr.ny[i] * l, 0.16, 'rgba(255,255,255,.15)'); c.lineCap = 'round'; return true; }
      if (k === 'rally') { for (let n = 0; n < NS * 6; n++) { const j = Math.floor(rnd() * NS), l = (rnd() * 2 - 1) * (half - 0.4); blob(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, 0.1 + rnd() * 0.2, rnd() < 0.5 ? 'rgba(60,40,20,.35)' : 'rgba(230,215,180,.3)'); } for (const sd of [-1, 1]) { path(sd * half * 0.35); c.strokeStyle = 'rgba(70,50,30,.25)'; c.lineWidth = 1.2; c.stroke(); } return true; }
      if (k === 'scrap' || k === 'canal' || k === 'clock' || k === 'prairie') { path(0); c.strokeStyle = 'rgba(255,255,255,.4)'; c.lineWidth = 0.3; c.setLineDash([2.5, 3]); c.stroke(); c.setLineDash([]); for (const sd of [-1, 1]) { path(sd * (half - 0.6)); c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 0.2; c.stroke(); } return true; }
      if (k === 'ski') { for (let q = 0; q < 14; q++) { path((q / 13 * 2 - 1) * (half - 0.4)); c.strokeStyle = q % 2 ? 'rgba(150,175,205,.18)' : 'rgba(255,255,255,.4)'; c.lineWidth = 0.18; c.stroke(); } return true; } // groomed corduroy
      if (k === 'moon') { for (let n = 0; n < NS * 4; n++) { const j = Math.floor(rnd() * NS), l = (rnd() * 2 - 1) * (half - 0.4); blob(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, 0.1 + rnd() * 0.25, rnd() < 0.5 ? 'rgba(0,0,0,.25)' : 'rgba(255,255,255,.12)'); } for (const sd of [-1, 1]) { path(sd * half * 0.33); c.strokeStyle = 'rgba(40,40,48,.35)'; c.lineWidth = 0.9; c.stroke(); } return true; } // rover ruts
      if (k === 'icelake') { c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 0.18; for (let n = 0; n < NS / 3; n++) { const j = Math.floor(rnd() * NS), l = (rnd() * 2 - 1) * (half - 1); let px = tr.x[j] + tr.nx[j] * l, py = tr.y[j] + tr.ny[j] * l; c.beginPath(); c.moveTo(px, py); for (let q = 0; q < 3; q++) { px += (rnd() - 0.5) * 3; py += (rnd() - 0.5) * 3; c.lineTo(px, py); } c.stroke(); } return true; } // cracks in the ice
      if (k === 'stadium' || k === 'hwy' || k === 'metro' || k === 'port' || k === 'bridge' || k === 'river' || k === 'fest' || k === 'season' || k === 'gorge' || k === 'ranch') { // lane lines
        const dash = k === 'hwy' ? [3, 4] : k === 'ranch' ? [1.2, 2.6] : [2.5, 3];
        for (const l of k === 'hwy' ? [-half / 3, half / 3] : [0]) { path(l); c.strokeStyle = k === 'ranch' ? 'rgba(255,240,200,.35)' : k === 'metro' ? 'rgba(255,209,102,.7)' : 'rgba(255,255,255,.5)'; c.lineWidth = 0.3; c.setLineDash(dash); c.stroke(); c.setLineDash([]); }
        if (k !== 'ranch' && k !== 'season') for (const sd of [-1, 1]) { path(sd * (half - 0.6)); c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 0.2; c.stroke(); }
        return true;
      }
      if (k === 'tunnel' || k === 'windmill') { // painted lines
        path(0); c.strokeStyle = k === 'tunnel' ? 'rgba(255,209,102,.7)' : 'rgba(255,255,255,.45)'; c.lineWidth = 0.32; c.setLineDash(k === 'tunnel' ? [] : [2.5, 3]); c.stroke(); c.setLineDash([]);
        for (const sd of [-1, 1]) { path(sd * (half - 0.6)); c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 0.22; c.stroke(); }
        return true;
      }
      return false;
    }
    /* scenery props per theme (after the road, so they never sit on it) */
    function themeProps(k) {
      if (k === 'toy') {
        const lets = ['가', '나', '다', '라', '마', 'A', 'B', '1', '2', '3'];
        props(18, 6, (px, py) => { // letter blocks
          const s2 = 2.2 + rnd() * 1.3, col = COLS5[Math.floor(rnd() * 5)];
          c.save(); c.translate(px, py); c.rotate(rnd() * 1.5);
          c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-s2 + 0.5, -s2 + 0.7, s2 * 2, s2 * 2);
          c.fillStyle = col; rr(c, -s2, -s2, s2 * 2, s2 * 2, 0.45); c.fill();
          c.fillStyle = 'rgba(255,255,255,.88)'; rr(c, -s2 * 0.7, -s2 * 0.7, s2 * 1.4, s2 * 1.4, 0.3); c.fill();
          c.fillStyle = col; c.font = '700 ' + (s2 * 1.1).toFixed(2) + 'px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(lets[Math.floor(rnd() * lets.length)], 0, 0.1);
          c.restore();
        });
        props(16, 5, (px, py) => { // crayons
          const col = ['#e8384f', '#5bb3e6', '#ffd166', '#5fd3a0', '#ff8a3d', '#b48cf0'][Math.floor(rnd() * 6)];
          c.save(); c.translate(px, py); c.rotate(rnd() * 6);
          c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(-4.2, -0.2, 9, 1.4);
          c.fillStyle = col; c.fillRect(-4.5, -0.7, 7.5, 1.4); c.beginPath(); c.moveTo(3, -0.7); c.lineTo(4.8, 0); c.lineTo(3, 0.7); c.fill();
          c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(-3.4, -0.7, 0.4, 1.4); c.fillRect(1.6, -0.7, 0.4, 1.4); c.fillStyle = 'rgba(255,255,255,.25)'; c.fillRect(-4.5, -0.6, 7.5, 0.35);
          c.restore();
        });
        props(12, 5, (px, py) => { // dice
          c.save(); c.translate(px, py); c.rotate(rnd() * 1.5);
          c.fillStyle = 'rgba(0,0,0,.3)'; rr(c, -1.1, -0.9, 2.8, 2.8, 0.5); c.fill();
          c.fillStyle = '#f6f1e6'; rr(c, -1.5, -1.5, 3, 3, 0.55); c.fill();
          const n = 1 + Math.floor(rnd() * 6), pip = { 1: [[0, 0]], 2: [[-0.7, -0.7], [0.7, 0.7]], 3: [[-0.7, -0.7], [0, 0], [0.7, 0.7]], 4: [[-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]], 5: [[-0.7, -0.7], [0.7, -0.7], [0, 0], [-0.7, 0.7], [0.7, 0.7]], 6: [[-0.7, -0.75], [0.7, -0.75], [-0.7, 0], [0.7, 0], [-0.7, 0.75], [0.7, 0.75]] }[n];
          for (const [dx, dy] of pip) blob(dx, dy, 0.28, n === 1 ? '#e8384f' : '#1c1d20');
          c.restore();
        });
        props(34, 3, (px, py) => { // marbles
          const r = 0.6 + rnd() * 0.4, g = c.createRadialGradient(px - r * 0.35, py - r * 0.35, 0.05, px, py, r);
          blob(px + 0.25, py + 0.35, r, 'rgba(0,0,0,.3)');
          g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, COLS5[Math.floor(rnd() * 5)]); g.addColorStop(1, 'rgba(20,20,40,.9)');
          c.fillStyle = g; c.beginPath(); c.arc(px, py, r, 0, 7); c.fill();
        });
        props(2, 14, (px, py) => { // a teddy bear lying on the rug
          shadowE(px + 1, py + 1.5, 7, 8.5, 0.25);
          const fur = '#b07a46', lt = '#d9a874';
          for (const [dx, dy, r] of [[0, 3, 5.5], [-4.5, 6.5, 2.2], [4.5, 6.5, 2.2], [-5, 1.5, 2], [5, 1.5, 2], [0, -4, 4.2], [-3.4, -7.2, 1.6], [3.4, -7.2, 1.6]]) blob(px + dx, py + dy, r, fur);
          for (const [dx, dy, r] of [[0, 3.6, 3.4], [0, -2.8, 1.8], [-3.4, -7.2, 0.8], [3.4, -7.2, 0.8]]) blob(px + dx, py + dy, r, lt);
          for (const [dx, dy, r] of [[-1.5, -4.8, 0.5], [1.5, -4.8, 0.5], [0, -3.2, 0.6]]) blob(px + dx, py + dy, r, '#2b2018');
          c.fillStyle = '#e8384f'; c.beginPath(); c.moveTo(px, py - 0.6); c.lineTo(px - 2, py - 1.6); c.lineTo(px - 2, py + 0.4); c.closePath(); c.moveTo(px, py - 0.6); c.lineTo(px + 2, py - 1.6); c.lineTo(px + 2, py + 0.4); c.closePath(); c.fill();
        });
      } else if (k === 'windmill') {
        props(9, 8, (px, py) => { // farmhouses
          c.save(); c.translate(px, py); c.rotate(rnd() * 0.6 - 0.3);
          c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-3.2, -2, 8, 6);
          c.fillStyle = '#b5523b'; c.fillRect(-4, -3, 8, 6); c.fillStyle = '#8f3a28'; c.fillRect(-4, -0.15, 8, 0.3); c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(-4, -3, 8, 2.85);
          c.fillStyle = '#efe6d2'; c.fillRect(2, -4, 1.2, 1.4);
          c.restore();
        });
        props(18, 5, (px, py) => { // round hay bales
          blob(px + 0.5, py + 0.7, 1.6, 'rgba(0,0,0,.25)'); blob(px, py, 1.6, '#e0c068');
          c.strokeStyle = '#b89640'; c.lineWidth = 0.18; c.beginPath(); c.arc(px, py, 1, 0, 5.5); c.stroke(); c.beginPath(); c.arc(px, py, 0.45, 0, 5); c.stroke();
        });
        props(26, 4, (px, py) => { // sheep
          shadowE(px + 0.3, py + 0.5, 1.3, 0.9, 0.2);
          for (const [dx, dy] of [[-0.5, 0], [0.4, -0.2], [0.3, 0.4], [-0.3, 0.45], [-0.4, -0.4]]) blob(px + dx, py + dy, 0.6, '#f6f3ec');
          c.fillStyle = '#2b2533'; c.beginPath(); c.ellipse(px + 1.05, py, 0.42, 0.32, 0, 0, 7); c.fill();
        });
      } else if (k === 'thunder') {
        props(10, 7, (px, py) => { // dolmens: a flat capstone on small stones
          c.save(); c.translate(px, py); c.rotate(rnd() * 3);
          shadowE(1, 1.3, 4.6, 3, 0.35);
          for (const [dx, dy] of [[-2.6, -1.6], [2.6, -1.4], [-2.2, 1.8], [2.4, 1.6]]) blob(dx, dy, 0.9, '#4b504c');
          c.fillStyle = '#6f7670'; c.beginPath(); for (let q = 0; q < 8; q++) { const a = q * Math.PI / 4, r2 = (q % 2 ? 3.6 : 4.2) * (0.9 + rnd() * 0.15); c.lineTo(Math.cos(a) * r2, Math.sin(a) * r2 * 0.65); } c.closePath(); c.fill();
          c.fillStyle = 'rgba(255,255,255,.1)'; c.beginPath(); c.ellipse(-1, -0.8, 2.2, 1.2, 0, 0, 7); c.fill();
          c.restore();
        });
        props(34, 4, (px, py) => { // standing stones
          shadowE(px + 0.6, py + 0.8, 1.1, 0.8, 0.35);
          c.fillStyle = '#5d6460'; c.beginPath(); c.ellipse(px, py, 1, 0.75, rnd() * 3, 0, 7); c.fill();
          blob(px - 0.3, py - 0.25, 0.4, 'rgba(255,255,255,.12)');
        });
        props(3, 10, (px, py) => { // lightning-rod masts with a red light
          c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(px - 1, py - 0.6, 4, 4);
          c.strokeStyle = '#9aa0a8'; c.lineWidth = 0.3; c.strokeRect(px - 2, py - 2, 4, 4); c.beginPath(); c.moveTo(px - 2, py - 2); c.lineTo(px + 2, py + 2); c.moveTo(px + 2, py - 2); c.lineTo(px - 2, py + 2); c.stroke();
          blob(px, py, 2, 'rgba(255,64,64,.25)'); blob(px, py, 0.6, '#ff4040');
        });
      } else if (k === 'tide') {
        props(9, 6, (px, py) => { // little wooden boats stranded on the mud
          c.save(); c.translate(px, py); c.rotate(rnd() * 6);
          shadowE(0.6, 0.8, 4.4, 1.6, 0.3);
          c.fillStyle = '#7a5230'; c.beginPath(); c.moveTo(-4, -1.4); c.lineTo(3, -1.4); c.quadraticCurveTo(4.8, 0, 3, 1.4); c.lineTo(-4, 1.4); c.closePath(); c.fill();
          c.fillStyle = '#a3713f'; c.beginPath(); c.moveTo(-3.4, -0.9); c.lineTo(2.7, -0.9); c.quadraticCurveTo(3.9, 0, 2.7, 0.9); c.lineTo(-3.4, 0.9); c.closePath(); c.fill();
          c.fillStyle = '#5bb3e6'; c.fillRect(-1, -0.9, 0.5, 1.8); c.fillStyle = '#7a5230'; c.fillRect(-2.6, -0.9, 0.35, 1.8);
          c.restore();
        });
        props(7, 7, (px, py) => { // rows of poles of a seaweed farm
          const a = rnd() * 3;
          for (let r2 = 0; r2 < 3; r2++) for (let q = 0; q < 6; q++) { const qx = px + Math.cos(a) * q * 2 - Math.sin(a) * r2 * 2.4, qy = py + Math.sin(a) * q * 2 + Math.cos(a) * r2 * 2.4; blob(qx + 0.2, qy + 0.3, 0.3, 'rgba(0,0,0,.3)'); blob(qx, qy, 0.25, '#3b3026'); }
        });
        const L2 = openSpot(false, 14); // a lighthouse on a rock out at sea
        if (L2) {
          const [px, py] = L2;
          for (let q = 0; q < 9; q++) blob(px + (rnd() - 0.5) * 7, py + (rnd() - 0.5) * 6, 1.4 + rnd() * 1.6, q % 2 ? '#5a554e' : '#6d675e');
          blob(px + 0.7, py + 1, 2.4, 'rgba(0,0,0,.3)'); blob(px, py, 2.4, '#f2ede4');
          c.strokeStyle = '#e8384f'; c.lineWidth = 0.6; c.beginPath(); c.arc(px, py, 1.7, 0, 7); c.stroke();
          blob(px, py, 0.9, '#3d3a36'); blob(px, py, 0.5, '#ffe066');
        }
      } else if (k === 'haunt') {
        const M = openSpot(true, 26); // the mansion in the middle of the maze
        if (M) {
          const [px, py] = M;
          c.save(); c.translate(px, py);
          c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(-17, -9, 36, 22);
          c.fillStyle = '#2c2734'; c.fillRect(-18, -11, 36, 22); // roof
          c.fillStyle = '#3a3445'; c.beginPath(); c.moveTo(-18, -11); c.lineTo(18, -11); c.lineTo(12, 0); c.lineTo(-12, 0); c.closePath(); c.fill();
          c.strokeStyle = '#1c1922'; c.lineWidth = 0.5; c.beginPath(); c.moveTo(-12, 0); c.lineTo(12, 0); c.moveTo(-18, -11); c.lineTo(-12, 0); c.lineTo(-18, 11); c.moveTo(18, -11); c.lineTo(12, 0); c.lineTo(18, 11); c.stroke();
          c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 0.15; for (let y = -10; y < 11; y += 1.2) { c.beginPath(); c.moveTo(-18, y); c.lineTo(18, y); c.stroke(); }
          for (const [x, y] of [[-12, -6], [-4, -6], [4, -6], [12, -6], [-8, 5], [0, 5], [8, 5]]) { c.fillStyle = 'rgba(255,200,90,.25)'; c.beginPath(); c.arc(x, y, 2.4, 0, 7); c.fill(); c.fillStyle = '#ffcf6b'; c.fillRect(x - 0.9, y - 0.8, 1.8, 1.6); c.fillStyle = '#2c2734'; c.fillRect(x - 0.08, y - 0.8, 0.16, 1.6); }
          blob(18, -11, 4.2, '#2c2734'); blob(18, -11, 3, '#3a3445'); blob(18, -11, 0.6, '#1c1922'); // turret
          c.fillStyle = '#4d4856'; c.fillRect(-14, -13, 2, 3); c.fillRect(9, -13, 2, 3); // chimneys
          c.restore();
        }
        props(30, 4, (px, py) => { // graves
          c.save(); c.translate(px, py); c.rotate(rnd() * 0.4 - 0.2);
          c.fillStyle = 'rgba(0,0,0,.4)'; rr(c, -0.7, -0.6, 2, 2.6, 0.6); c.fill();
          c.fillStyle = '#7d7888'; rr(c, -1, -1.2, 2, 2.6, 0.7); c.fill();
          c.strokeStyle = '#4d4856'; c.lineWidth = 0.22; c.beginPath(); c.moveTo(0, -0.7); c.lineTo(0, 0.6); c.moveTo(-0.5, -0.2); c.lineTo(0.5, -0.2); c.stroke();
          c.restore();
        });
        props(12, 3, (px, py) => { // jack-o'-lanterns
          blob(px, py, 2.4, 'rgba(255,140,40,.18)'); blob(px, py, 1, '#e8742a');
          c.strokeStyle = '#a84d14'; c.lineWidth = 0.12; for (const o of [-0.45, 0.45]) { c.beginPath(); c.ellipse(px + o, py, 0.35, 0.95, 0, 0, 7); c.stroke(); }
          c.fillStyle = '#ffe066'; c.beginPath(); c.moveTo(px - 0.5, py - 0.3); c.lineTo(px - 0.2, py - 0.1); c.lineTo(px - 0.5, py); c.moveTo(px + 0.5, py - 0.3); c.lineTo(px + 0.2, py - 0.1); c.lineTo(px + 0.5, py); c.fill();
          blob(px, py - 1.05, 0.25, '#4f7a3a');
        });
        props(10, 5, (px, py) => { // bare trees
          c.strokeStyle = '#2b2420'; c.lineWidth = 0.5; c.lineCap = 'round';
          const br = (x, y, a, l, d) => { if (d > 3) return; const x2 = x + Math.cos(a) * l, y2 = y + Math.sin(a) * l; c.lineWidth = 0.6 - d * 0.13; c.beginPath(); c.moveTo(x, y); c.lineTo(x2, y2); c.stroke(); br(x2, y2, a - 0.5 - rnd() * 0.3, l * 0.7, d + 1); br(x2, y2, a + 0.5 + rnd() * 0.3, l * 0.7, d + 1); };
          for (let q = 0; q < 4; q++) br(px, py, q * 1.57 + rnd() * 0.6, 2.2, 0);
        });
      } else if (k === 'aurora') {
        props(4, 8, (px, py) => { // igloos
          blob(px + 0.8, py + 1, 4, 'rgba(40,60,100,.3)'); blob(px, py, 4, '#f2f8ff');
          c.strokeStyle = 'rgba(120,150,190,.5)'; c.lineWidth = 0.15; for (const r of [1.3, 2.4, 3.4]) { c.beginPath(); c.arc(px, py, r, 0, 7); c.stroke(); }
          for (let q = 0; q < 8; q++) { const a = q * Math.PI / 4 + (q % 2) * 0.2; c.beginPath(); c.moveTo(px + Math.cos(a) * 1.3, py + Math.sin(a) * 1.3); c.lineTo(px + Math.cos(a) * 4, py + Math.sin(a) * 4); c.stroke(); }
          c.fillStyle = '#c9daea'; c.fillRect(px + 3.4, py - 1, 2.4, 2);
        });
        props(18, 5, (px, py) => { // clusters of ice crystals
          for (let q = 0; q < 4; q++) {
            const a = rnd() * 6, l = 1.5 + rnd() * 2.5, w = 0.5 + rnd() * 0.4, x2 = px + (rnd() - 0.5) * 2, y2 = py + (rnd() - 0.5) * 2;
            c.save(); c.translate(x2, y2); c.rotate(a);
            c.fillStyle = 'rgba(40,70,110,.25)'; c.beginPath(); c.moveTo(0.3, -w + 0.4); c.lineTo(l + 0.3, 0.4); c.lineTo(0.3, w + 0.4); c.fill();
            c.fillStyle = q % 2 ? '#bfe9ff' : '#e6f8ff'; c.beginPath(); c.moveTo(0, -w); c.lineTo(l, 0); c.lineTo(0, w); c.fill();
            c.restore();
          }
        });
      } else if (k === 'prairie') {
        props(24, 5, (px, py) => { blob(px + 0.5, py + 0.7, 1.6, 'rgba(0,0,0,.25)'); blob(px, py, 1.6, '#e0c068'); c.strokeStyle = '#b89640'; c.lineWidth = 0.18; c.beginPath(); c.arc(px, py, 1, 0, 5.5); c.stroke(); });
        const F = openSpot(true, 18);
        if (F) { const [px, py] = F; c.save(); c.translate(px, py); c.rotate(0.3); c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-5, -3, 12, 8); c.fillStyle = '#b5423b'; c.fillRect(-6, -4, 12, 8); c.fillStyle = '#8a2e28'; c.fillRect(-6, -0.2, 12, 0.4); c.fillStyle = 'rgba(255,255,255,.7)'; c.fillRect(-6, -4, 0.5, 8); c.fillRect(5.5, -4, 0.5, 8); c.restore(); }
      } else if (k === 'scrap') {
        props(26, 6, (px, py) => { // scrap heaps
          const r = 2.4 + rnd() * 3; shadowE(px + 0.8, py + 1, r, r * 0.8, 0.35);
          for (let q = 0; q < 7; q++) { c.fillStyle = ['#6d6a64', '#8a5a3a', '#9aa0a8', '#5a4a3a', '#7a7f88'][Math.floor(rnd() * 5)]; c.save(); c.translate(px + (rnd() - 0.5) * r, py + (rnd() - 0.5) * r); c.rotate(rnd() * 3); c.fillRect(-r * 0.4, -r * 0.2, r * 0.8, r * 0.4); c.restore(); }
        });
        props(10, 5, (px, py) => { for (let q = 0; q < 3; q++) { blob(px + q * 0.3, py - q * 0.4 + 0.3, 1.3, 'rgba(0,0,0,.3)'); blob(px + q * 0.3, py - q * 0.4, 1.2, '#1c1a20'); blob(px + q * 0.3, py - q * 0.4, 0.55, '#3a3640'); } });
        props(6, 7, (px, py) => { // rusty car wrecks
          c.save(); c.translate(px, py); c.rotate(rnd() * 6); shadowE(0.5, 0.7, 3, 1.8, 0.3);
          c.fillStyle = ['#8a4a2a', '#5f6f7a', '#7a6a3a'][Math.floor(rnd() * 3)]; rr(c, -2.8, -1.4, 5.6, 2.8, 0.9); c.fill(); c.fillStyle = 'rgba(30,20,10,.5)'; rr(c, -0.4, -1.1, 1.6, 2.2, 0.4); c.fill(); c.restore();
        });
      } else if (k === 'canal') {
        props(30, 5, (px, py) => { // houses with tiled roofs
          const w2 = 5 + rnd() * 4, h2 = 4 + rnd() * 3; c.save(); c.translate(px, py); c.rotate(Math.round(rnd() * 3) * Math.PI / 2 + (rnd() - 0.5) * 0.1);
          c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-w2 / 2 + 0.6, -h2 / 2 + 0.8, w2, h2);
          const col = ['#c0603e', '#a8503a', '#d07a4a', '#8a6a5a'][Math.floor(rnd() * 4)]; c.fillStyle = col; c.fillRect(-w2 / 2, -h2 / 2, w2, h2);
          c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(-w2 / 2, 0, w2, h2 / 2); c.strokeStyle = 'rgba(60,30,20,.4)'; c.lineWidth = 0.12; for (let y = -h2 / 2 + 0.5; y < h2 / 2; y += 0.6) { c.beginPath(); c.moveTo(-w2 / 2, y); c.lineTo(w2 / 2, y); c.stroke(); }
          c.restore();
        });
        props(14, 4, (px, py) => { blob(px + 0.4, py + 0.5, 1.6, 'rgba(0,0,0,.25)'); blob(px, py, 1.6, '#4f7a3a'); blob(px - 0.4, py - 0.4, 0.7, 'rgba(180,220,120,.3)'); });
      } else if (k === 'clock') {
        const T2 = openSpot(true, 24);
        if (T2) { // the clock tower in a round plaza, seen from above
          const [px, py] = T2;
          blob(px, py, 19, 'rgba(255,250,235,.25)'); c.strokeStyle = 'rgba(80,60,40,.3)'; c.lineWidth = 0.4; for (const r of [12, 15.5, 19]) { c.beginPath(); c.arc(px, py, r, 0, 7); c.stroke(); }
          for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4, qx = px + Math.cos(a) * 15.5, qy = py + Math.sin(a) * 15.5; blob(qx, qy, 1.3, '#5a7a3a'); blob(qx - 0.3, qy - 0.3, 0.5, COLS5[k % 5]); }
          shadowE(px + 3, py + 3.5, 11, 11, 0.35);
          c.fillStyle = '#8f8576'; c.fillRect(px - 10, py - 10, 20, 20);
          c.fillStyle = '#6d6458'; c.beginPath(); c.moveTo(px - 10, py - 10); c.lineTo(px, py); c.lineTo(px + 10, py - 10); c.closePath(); c.fill();
          c.fillStyle = '#7a7064'; c.beginPath(); c.moveTo(px - 10, py + 10); c.lineTo(px, py); c.lineTo(px + 10, py + 10); c.closePath(); c.fill();
          c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 0.3; c.strokeRect(px - 10, py - 10, 20, 20);
          blob(px, py, 6.2, '#f4eee2'); c.strokeStyle = '#2b2533'; c.lineWidth = 0.6; c.beginPath(); c.arc(px, py, 6.2, 0, 7); c.stroke();
          for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6; c.lineWidth = k % 3 ? 0.25 : 0.5; c.beginPath(); c.moveTo(px + Math.cos(a) * 5, py + Math.sin(a) * 5); c.lineTo(px + Math.cos(a) * 5.8, py + Math.sin(a) * 5.8); c.stroke(); }
          c.lineWidth = 0.7; c.beginPath(); c.moveTo(px, py); c.lineTo(px, py - 4.4); c.moveTo(px, py); c.lineTo(px + 3, py + 0.8); c.stroke(); blob(px, py, 0.6, '#e3ae45');
        }
        props(20, 4, (px, py) => { // flower beds and benches
          if (rnd() < 0.5) { blob(px, py, 1.6, '#5a7a3a'); for (let q = 0; q < 6; q++) blob(px + (rnd() - 0.5) * 2.2, py + (rnd() - 0.5) * 2.2, 0.35, COLS5[Math.floor(rnd() * 5)]); }
          else { c.save(); c.translate(px, py); c.rotate(rnd() * 3); c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-1.3, -0.2, 3, 1); c.fillStyle = '#7a5a3a'; c.fillRect(-1.5, -0.5, 3, 1); c.restore(); }
        });
      } else if (k === 'rally') {
        props(12, 5, (px, py) => { for (let q = 0; q < 3; q++) { blob(px + q * 1.8 + 0.4, py + 0.5, 0.9, 'rgba(0,0,0,.25)'); blob(px + q * 1.8, py, 0.9, '#e0c068'); } });
        props(16, 4, (px, py) => { // spectators
          for (let q = 0; q < 5; q++) blob(px + (rnd() - 0.5) * 3, py + (rnd() - 0.5) * 2, 0.45, COLS5[Math.floor(rnd() * 5)]);
        });
      } else if (k === 'tunnel') {
        props(3, 9, (px, py) => { // mountain huts
          c.save(); c.translate(px, py); c.rotate(rnd() * 0.8);
          c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(-2.6, -1.6, 7, 5);
          c.fillStyle = '#7a4a2c'; c.fillRect(-3.5, -2.5, 7, 5); c.fillStyle = '#5a3420'; c.fillRect(-3.5, -0.12, 7, 0.24); c.fillStyle = 'rgba(255,255,255,.75)'; c.fillRect(-3.5, -2.5, 7, 0.8);
          c.restore();
        });
      } else if (k === 'plum') {
        // grandstand along the start straight (outside), crowd as coloured dots under a striped roof
        const i0 = NS - 34, sd = -tr.side[0], o = sd * (half + 9.5);
        c.lineCap = 'butt';
        span(i0, NS + 26, o, 7, 'rgba(0,0,0,.3)'); span(i0, NS + 26, o - sd * 0.4, 6.4, '#6a6070');
        for (let i = i0; i < NS + 26; i++) for (let q = -2; q <= 2; q++) { const j = i % NS, l = o + q * 1.15, px = tr.x[j] + tr.nx[j] * l, py = tr.y[j] + tr.ny[j] * l; blob(px + (rnd() - 0.5) * 0.4, py + (rnd() - 0.5) * 0.4, 0.42, COLS5[Math.floor(rnd() * 5)]); }
        span(i0, NS + 26, o + sd * 3.6, 1.2, '#e3ae45'); span(i0, NS + 26, o + sd * 3.6, 0.4, '#c0503e');
        c.lineCap = 'round';
        // tyre stacks on the outside of the sharp corners
        for (let i = 0; i < NS; i += 9) {
          if (tr.acurv[i] < 0.03) continue;
          const s2 = tr.curv[i] > 0 ? -1 : 1, o2 = s2 * (half + 7.6);
          for (let q = -1; q <= 1; q++) { const px = tr.x[i] + tr.nx[i] * o2 + tr.tx[i] * q * 1.3, py = tr.y[i] + tr.ny[i] * o2 + tr.ty[i] * q * 1.3; blob(px + 0.2, py + 0.3, 0.7, 'rgba(0,0,0,.3)'); blob(px, py, 0.65, '#1c1a20'); blob(px, py, 0.3, q ? '#f2ede4' : '#d6403a'); }
        }
      } else if (k === 'rail') {
        props(6, 6, (px, py) => { // round hay bales
          blob(px + 0.5, py + 0.7, 1.6, 'rgba(0,0,0,.25)'); blob(px, py, 1.6, '#e0c068');
          c.strokeStyle = '#b89640'; c.lineWidth = 0.18; c.beginPath(); c.arc(px, py, 1, 0, 5.5); c.stroke();
        });
        const F = openSpot(true, 18);
        if (F) { // a farmhouse with a silo
          const [px, py] = F; c.save(); c.translate(px, py);
          c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-4.2, -2.2, 10, 7);
          c.fillStyle = '#9a3b2c'; c.fillRect(-5, -3, 10, 7); c.fillStyle = '#7a2e22'; c.fillRect(-5, 0.35, 10, 0.3); c.fillStyle = 'rgba(255,255,255,.14)'; c.fillRect(-5, -3, 10, 3.3);
          blob(7.5, 0.6, 2.6, 'rgba(0,0,0,.3)'); blob(7, 0, 2.5, '#c9ccd2'); blob(7, 0, 1.4, '#e8ebf0');
          c.restore();
        }
      } else if (k === 'storm') {
        props(5, 12, (px, py) => { // flat-topped mesas with layered cliffs
          const r = 6 + rnd() * 6;
          c.fillStyle = 'rgba(80,40,10,.3)'; c.beginPath(); c.ellipse(px + 2, py + 2.5, r * 1.1, r * 0.8, 0.3, 0, 7); c.fill();
          for (const [k2, col] of [[1, '#9a5a2c'], [0.82, '#b5703a'], [0.64, '#c98a4c']]) { c.fillStyle = col; c.beginPath(); for (let q = 0; q < 10; q++) { const a = q * Math.PI / 5, rr2 = r * k2 * (0.85 + rnd() * 0.2); c.lineTo(px + Math.cos(a) * rr2, py + Math.sin(a) * rr2 * 0.75); } c.closePath(); c.fill(); }
        });
        props(4, 6, (px, py) => { // a bleached skull
          blob(px, py, 0.9, '#f2ead8'); blob(px - 0.3, py - 0.1, 0.22, '#5a4a3a'); blob(px + 0.3, py - 0.1, 0.22, '#5a4a3a');
          c.strokeStyle = '#f2ead8'; c.lineWidth = 0.3; c.beginPath(); c.moveTo(px - 0.8, py - 0.6); c.quadraticCurveTo(px - 2, py - 1.6, px - 2.2, py - 0.6); c.moveTo(px + 0.8, py - 0.6); c.quadraticCurveTo(px + 2, py - 1.6, px + 2.2, py - 0.6); c.stroke();
        });
      } else if (k === 'beach') {
        props(14, 4, (px, py) => { // beach umbrellas with a towel
          c.save(); c.translate(px, py); c.rotate(rnd() * 6);
          c.fillStyle = COLS5[Math.floor(rnd() * 5)]; c.fillRect(1.2, -0.6, 2.6, 1.3);
          shadowE(0.6, 0.8, 2.2, 2.2, 0.22);
          for (let q = 0; q < 8; q++) { c.fillStyle = q % 2 ? '#ffffff' : ['#ee6a55', '#5bb3e6', '#ffd166'][Math.floor(q / 3) % 3]; c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, 2, q * Math.PI / 4, (q + 1) * Math.PI / 4); c.fill(); }
          c.restore();
        });
      } else if (k === 'blossom') {
        props(10, 4, (px, py) => { // stone lanterns
          blob(px + 0.4, py + 0.5, 1.2, 'rgba(0,0,0,.3)'); c.fillStyle = '#9c968c'; c.fillRect(px - 1.1, py - 1.1, 2.2, 2.2);
          c.fillStyle = '#7d776d'; c.fillRect(px - 0.7, py - 0.7, 1.4, 1.4); blob(px, py, 0.4, '#ffd98a');
        });
        const P2 = openSpot(true, 14);
        if (P2) { // a hexagonal pavilion with a tiled roof
          const [px, py] = P2;
          c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); for (let q = 0; q < 6; q++) { const a = q * Math.PI / 3; c.lineTo(px + 1 + Math.cos(a) * 6, py + 1.4 + Math.sin(a) * 6); } c.fill();
          for (const [r, col] of [[6, '#3c4a5a'], [4.6, '#4b5d70'], [2.6, '#5d728a']]) { c.fillStyle = col; c.beginPath(); for (let q = 0; q < 6; q++) { const a = q * Math.PI / 3; c.lineTo(px + Math.cos(a) * r, py + Math.sin(a) * r); } c.fill(); }
          c.strokeStyle = 'rgba(0,0,0,.3)'; c.lineWidth = 0.2; for (let q = 0; q < 6; q++) { const a = q * Math.PI / 3; c.beginPath(); c.moveTo(px, py); c.lineTo(px + Math.cos(a) * 6, py + Math.sin(a) * 6); c.stroke(); }
          blob(px, py, 0.7, '#c9a874');
        }
      } else if (k === 'snow') {
        const lodge = openSpot(true, 16);
        if (lodge) { // a ski lodge with a snowy roof and smoke
          const [px, py] = lodge; c.save(); c.translate(px, py); c.rotate(0.2);
          c.fillStyle = 'rgba(40,60,90,.3)'; c.fillRect(-5, -3, 12, 8);
          c.fillStyle = '#7a4a2c'; c.fillRect(-6, -4, 12, 8); c.fillStyle = '#ffffff'; c.fillRect(-6, -4, 12, 3.6); c.fillRect(-6, 0.4, 12, 3.6); c.fillStyle = 'rgba(150,175,205,.6)'; c.fillRect(-6, -0.2, 12, 0.6);
          c.fillStyle = '#5a5048'; c.fillRect(2.5, -5, 1.4, 1.6);
          c.restore();
        }
      } else if (k === 'harbor') { // painted yard bays and a warehouse
        c.strokeStyle = 'rgba(255,255,255,.28)'; c.lineWidth = 0.3;
        for (let n = 0; n < 6; n++) { const px = rx(), py = ry(); if (!inPoly(px, py) || nearTrack(px, py, half + 14)) continue; for (let q = 0; q < 6; q++) c.strokeRect(px + q * 3.2, py, 3.2, 7); }
        const Wh = openSpot(true, 20);
        if (Wh) { const [px, py] = Wh; c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(px - 11, py - 6, 24, 14); c.fillStyle = '#6d7680'; c.fillRect(px - 12, py - 7, 24, 14); c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 0.25; for (let x = -11; x < 12; x += 1.2) { c.beginPath(); c.moveTo(px + x, py - 7); c.lineTo(px + x, py + 7); c.stroke(); } c.fillStyle = '#8a939e'; c.fillRect(px - 12, py - 0.3, 24, 0.6); }
      }
    }
    // ground
    c.fillStyle = th.base; c.fillRect(B[0], B[1], B[2] - B[0], B[3] - B[1]);
    if (D.th === 'plum') {
      for (let i = B[0] - 400; i < B[2]; i += 10) { c.fillStyle = Math.round(i / 10) % 2 ? 'rgba(255,255,255,.035)' : 'rgba(0,0,0,.045)'; c.beginPath(); c.moveTo(i, B[1]); c.lineTo(i + 5, B[1]); c.lineTo(i + 405, B[3]); c.lineTo(i + 400, B[3]); c.fill(); }
    }
    for (let i = 0; i < (B[2] - B[0]) * (B[3] - B[1]) / 10; i++) { c.fillStyle = th.dots[i & 1]; c.fillRect(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 0.5, 0.5); }
    if (D.th === 'forest') for (let i = 0; i < 70; i++) { c.fillStyle = 'rgba(70,100,45,.35)'; c.beginPath(); c.ellipse(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 4 + rnd() * 9, 3 + rnd() * 6, rnd() * 3, 0, 7); c.fill(); }
    if (D.th === 'snow') for (let i = 0; i < 60; i++) { c.strokeStyle = 'rgba(150,175,205,.25)'; c.lineWidth = 0.5; const x0 = B[0] + rnd() * (B[2] - B[0]), y0 = B[1] + rnd() * (B[3] - B[1]); c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(x0 + 6, y0 - 2, x0 + 12, y0); c.stroke(); }
    groundArt(D.th);
    const xings = [];
    if (tr.fer) xings.push({ p: tr.fer, w: tr.fer.wr + 1.5, col: th.water, bank: '#7a6a4a' });
    for (const B2 of tr.dbr) xings.push({ p: B2, w: B2.wr + 1, col: th.water, bank: '#8a8070' });
    for (const X of xings) { // the river / canal runs straight across the map
      const q = X.p, ux = -Math.sin(q.a), uy = Math.cos(q.a), L2 = 600;
      c.lineCap = 'butt';
      for (const [w2, col] of [[X.w * 2 + 3, X.bank], [X.w * 2 + 1, 'rgba(0,0,0,.25)'], [X.w * 2, X.col]]) { c.strokeStyle = col; c.lineWidth = w2; c.beginPath(); c.moveTo(q.x - ux * L2, q.y - uy * L2); c.lineTo(q.x + ux * L2, q.y + uy * L2); c.stroke(); }
      c.strokeStyle = 'rgba(220,245,255,.35)'; c.lineWidth = 0.3;
      for (let k = 0; k < 160; k++) { const t2 = (rnd() * 2 - 1) * L2, o = (rnd() * 2 - 1) * (X.w - 0.8), px = q.x + ux * t2 + Math.cos(q.a) * o, py = q.y + uy * t2 + Math.sin(q.a) * o; c.beginPath(); c.moveTo(px, py); c.lineTo(px + ux * 2, py + uy * 2); c.stroke(); }
      c.lineCap = 'round';
    }
    // water / lava / void: infield (or outside) + zones where both sides drop away
    const inPoly = (px, py) => { let ins = false; for (let a = 0, b = NS - 3; a < NS; b = a, a += 3) { if ((tr.y[a] > py) !== (tr.y[b] > py) && px < (tr.x[b] - tr.x[a]) * (py - tr.y[a]) / (tr.y[b] - tr.y[a]) + tr.x[a]) ins = !ins; } return ins; };
    const stars = (n) => { for (let i = 0; i < n; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]), r = rnd(); c.fillStyle = r < 0.1 ? 'rgba(160,220,255,.9)' : r < 0.2 ? 'rgba(255,200,230,.7)' : 'rgba(255,255,255,' + (0.3 + rnd() * 0.6) + ')'; c.fillRect(px, py, r < 0.08 ? 0.9 : 0.45, r < 0.08 ? 0.9 : 0.45); } };
    if (D.water) {
      const wk = D.water.k || 'sea', dW = D.water.d;
      const infield = () => { c.beginPath(); for (let i = 0; i < NS; i++) i ? c.lineTo(tr.x[i], tr.y[i]) : c.moveTo(tr.x[i], tr.y[i]); c.closePath(); };
      if (D.water.inside) { c.fillStyle = th.water; infield(); c.fill(); }
      else { c.fillStyle = th.water; c.fillRect(B[0], B[1], B[2] - B[0], B[3] - B[1]); c.fillStyle = th.base; infield(); c.fill(); }
      for (const [a, b] of D.water.zones || []) span(Math.round(a * NS), Math.round(b * NS), 0, 70, th.water);
      if (wk === 'void') {
        stars(1400);
        for (let i = 0; i < 5; i++) { const g = c.createRadialGradient(0, 0, 0, 0, 0, 1); c.save(); c.translate(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1])); c.scale(30 + rnd() * 40, 20 + rnd() * 30); g.addColorStop(0, i % 2 ? 'rgba(120,80,200,.22)' : 'rgba(60,160,220,.18)'); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.beginPath(); c.arc(0, 0, 1, 0, 7); c.fill(); c.restore(); }
        c.save(); c.globalAlpha = 0.5; path(0); c.strokeStyle = '#4fe3ff'; c.lineWidth = (half + dW) * 2 + 3; c.stroke(); c.restore();
        path(0); c.strokeStyle = '#2a2f3c'; c.lineWidth = (half + dW) * 2 + 1.2; c.stroke();
      } else if (wk === 'lava') {
        for (let i = 0; i < 260; i++) { c.fillStyle = rnd() < 0.5 ? th.water2 : 'rgba(120,20,10,.6)'; c.globalAlpha = 0.5; c.beginPath(); c.ellipse(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 1 + rnd() * 4, 0.6 + rnd() * 2, rnd() * 3, 0, 7); c.fill(); }
        c.globalAlpha = 1;
        c.save(); c.globalAlpha = 0.55; path(0); c.strokeStyle = '#ff8a3d'; c.lineWidth = (half + dW) * 2 + 6; c.stroke(); c.restore();
        path(0); c.strokeStyle = '#1c1414'; c.lineWidth = (half + dW) * 2 + 1.4; c.stroke();
      } else if (wk === 'sky') { // open sky with clouds drifting far below
        const g = c.createLinearGradient(B[0], B[1], B[2], B[3]); g.addColorStop(0, '#a9d8f7'); g.addColorStop(1, '#6fb2e6');
        c.fillStyle = g; c.fillRect(B[0], B[1], B[2] - B[0], B[3] - B[1]);
        for (let i = 0; i < 110; i++) {
          const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]), r = 3 + rnd() * 9;
          c.fillStyle = 'rgba(255,255,255,' + (0.18 + rnd() * 0.32) + ')';
          c.beginPath(); c.arc(px, py, r, 0, 7); c.arc(px + r * 0.9, py + r * 0.25, r * 0.7, 0, 7); c.arc(px - r * 0.85, py + r * 0.3, r * 0.6, 0, 7); c.fill();
        }
        c.save(); c.globalAlpha = 0.55; path(0); c.strokeStyle = '#ffffff'; c.lineWidth = (half + dW) * 2 + 5; c.stroke(); c.restore();
      } else {
        c.save(); c.globalAlpha = 0.45; path(0); c.strokeStyle = th.water2 || '#5fc0dd'; c.lineWidth = (half + dW) * 2 + 7; c.stroke(); c.restore();
        path(0); c.strokeStyle = 'rgba(255,255,255,.75)'; c.lineWidth = (half + dW) * 2 + 1.6; c.stroke();
        for (let i = 0; i < 160; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]); if (D.water.inside || !inPoly(px, py)) { c.fillStyle = 'rgba(255,255,255,.25)'; c.fillRect(px, py, 2.4, 0.35); } }
      }
      path(0); c.strokeStyle = th.off; c.lineWidth = (half + dW) * 2; c.stroke();
      if (D.th === 'sky') for (let i = 0; i < NS; i += 2) for (const sd of [-1, 1]) { // puffy cloud edge
        const o = sd * (half + dW - 0.4 + rnd() * 0.8), r = 1 + rnd() * 1.4;
        c.fillStyle = rnd() < 0.5 ? '#ffffff' : '#e6f1fb'; c.beginPath(); c.arc(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o, r, 0, 7); c.fill();
      }
      if (D.th === 'space') { // deck plates along the run-off
        c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 0.25;
        for (let i = 0; i < NS; i += 3) { const o = half + dW; c.beginPath(); c.moveTo(tr.x[i] - tr.nx[i] * o, tr.y[i] - tr.ny[i] * o); c.lineTo(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o); c.stroke(); }
      }
      if (D.th === 'harbor') { // quay edge: bollards and yellow safety line
        for (const sd of [-1, 1]) { path(sd * (half + dW - 0.6)); c.strokeStyle = 'rgba(255,209,102,.7)'; c.lineWidth = 0.5; c.setLineDash([2.5, 2]); c.stroke(); c.setLineDash([]); }
        for (let i = 0; i < NS; i += 9) { const f = tr.side[i] * (D.water.inside ? 1 : -1), o = (half + dW - 1.2) * f; c.fillStyle = '#2b2d33'; c.beginPath(); c.arc(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o, 0.55, 0, 7); c.fill(); }
      }
    }
    if (D.th === 'tide') tideArt();
    // walled tracks: rock / buildings everywhere, then carve the course
    if (tr.wall != null) {
      c.fillStyle = th.rock; c.fillRect(B[0], B[1], B[2] - B[0], B[3] - B[1]);
      if (D.th === 'desert') {
        for (let i = 0; i < 260; i++) { c.fillStyle = rnd() < 0.5 ? 'rgba(60,30,10,.25)' : th.rockHi; c.globalAlpha = 0.35; c.beginPath(); c.ellipse(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 2 + rnd() * 6, 1 + rnd() * 3, rnd() * 3, 0, 7); c.fill(); }
        c.globalAlpha = 1;
      } else if (D.th === 'ruins') { // collapsed temple blocks, moss
        for (let gy = B[1], row = 0; gy < B[3]; gy += 4, row++) for (let gx = B[0] - (row % 2) * 3; gx < B[2]; gx += 6) {
          const r = rnd();
          c.fillStyle = r < 0.3 ? 'rgba(0,0,0,.18)' : r < 0.55 ? 'rgba(255,230,180,.08)' : 'rgba(0,0,0,.06)';
          c.fillRect(gx + 0.25, gy + 0.25, 5.5, 3.5);
          if (r > 0.9) { c.fillStyle = 'rgba(90,130,60,.45)'; c.beginPath(); c.arc(gx + rnd() * 6, gy + rnd() * 4, 1 + rnd() * 2, 0, 7); c.fill(); }
        }
      } else if (D.th === 'candy') { // sprinkles and gumdrops on the candy walls
        for (let i = 0; i < 1400; i++) { c.save(); c.translate(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1])); c.rotate(rnd() * 3); c.fillStyle = ['#ee6a55', '#5bb3e6', '#e8c04e', '#5fd3a0', '#b48cf0', '#ffffff'][Math.floor(rnd() * 6)]; c.fillRect(-0.6, -0.18, 1.2, 0.36); c.restore(); }
        for (let i = 0; i < 40; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]), r = 1.6 + rnd() * 2.2; if (nearTrack(px, py, half + tr.wall + r + 1)) continue; c.fillStyle = 'rgba(0,0,0,.15)'; c.beginPath(); c.arc(px + 0.4, py + 0.6, r, 0, 7); c.fill(); c.fillStyle = ['#ee6a55', '#5fd3a0', '#e8c04e', '#b48cf0'][i % 4]; c.beginPath(); c.arc(px, py, r, 0, 7); c.fill(); c.fillStyle = 'rgba(255,255,255,.45)'; c.beginPath(); c.arc(px - r * 0.3, py - r * 0.35, r * 0.35, 0, 7); c.fill(); }
      } else if (D.th === 'sea') { // the sea floor around the glass tunnel: sand ripples, kelp, coral, fish
        for (let i = 0; i < 120; i++) { c.strokeStyle = 'rgba(120,200,230,.08)'; c.lineWidth = 0.6; const x0 = B[0] + rnd() * (B[2] - B[0]), y0 = B[1] + rnd() * (B[3] - B[1]); c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(x0 + 5, y0 - 2, x0 + 10, y0); c.stroke(); }
        for (let i = 0; i < 70; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]); if (nearTrack(px, py, half + tr.wall + 3)) continue; const r = rnd();
          if (r < 0.35) { c.strokeStyle = rnd() < 0.5 ? '#2f8a5a' : '#3fa36a'; c.lineWidth = 0.7; for (let k = 0; k < 3; k++) { c.beginPath(); c.moveTo(px + k, py); c.bezierCurveTo(px + k + 2, py - 3, px + k - 2, py - 6, px + k + 1, py - 9); c.stroke(); } }
          else if (r < 0.65) { c.fillStyle = ['#ee6a55', '#f07fb8', '#e8c04e'][Math.floor(rnd() * 3)]; for (let k = 0; k < 5; k++) { c.beginPath(); c.arc(px + (rnd() - 0.5) * 4, py + (rnd() - 0.5) * 4, 0.8 + rnd() * 1.2, 0, 7); c.fill(); } }
          else { c.save(); c.translate(px, py); c.rotate(rnd() * 6); c.fillStyle = rnd() < 0.5 ? '#e8c04e' : '#7fd0ff'; c.beginPath(); c.ellipse(0, 0, 1.6, 0.8, 0, 0, 7); c.moveTo(-1.4, 0); c.lineTo(-2.6, -0.8); c.lineTo(-2.6, 0.8); c.fill(); c.restore(); } }
      } else if (D.th === 'mine') { // rough rock with glints of ore
        for (let i = 0; i < 500; i++) { c.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,.35)' : 'rgba(110,85,60,.25)'; c.beginPath(); c.ellipse(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 1 + rnd() * 4, 0.6 + rnd() * 2, rnd() * 3, 0, 7); c.fill(); }
        for (let i = 0; i < 160; i++) { c.fillStyle = rnd() < 0.6 ? 'rgba(255,209,102,.8)' : 'rgba(127,208,255,.8)'; c.fillRect(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 0.5, 0.5); }
      } else if (D.th === 'factory') { // storage racks seen from above: pallets of boxes, orange beams, aisles
        for (let gy = B[1], row = 0; gy < B[3]; gy += 9.5, row++) {
          c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(B[0], gy + 6.4, B[2] - B[0], 3.1);
          for (let gx = B[0] + (row % 2) * 2; gx < B[2]; gx += 4.2) {
            const r = rnd(); if (r < 0.12) continue;
            c.fillStyle = r < 0.45 ? '#b5835a' : r < 0.7 ? '#c99a6b' : r < 0.86 ? '#8a6a4a' : r < 0.94 ? '#5f8fb8' : '#6aa86a';
            c.fillRect(gx + 0.3, gy + 0.4, 3.6, 5.6);
            c.fillStyle = 'rgba(255,255,255,.2)'; c.fillRect(gx + 0.3, gy + 2.9, 3.6, 0.35);
            c.fillStyle = 'rgba(0,0,0,.18)'; c.fillRect(gx + 3.4, gy + 0.4, 0.5, 5.6);
          }
          c.fillStyle = '#e8743a'; c.fillRect(B[0], gy, B[2] - B[0], 0.45); c.fillRect(B[0], gy + 6.1, B[2] - B[0], 0.35);
        }
      } else if (D.th === 'haunt') { // a clipped hedge maze
        for (let i = 0; i < (B[2] - B[0]) * (B[3] - B[1]) / 12; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]), r = 1.1 + rnd() * 1.9; c.fillStyle = ['#1a3320', '#22412a', '#2b5233', '#173019'][Math.floor(rnd() * 4)]; c.beginPath(); c.arc(px, py, r, 0, 7); c.fill(); }
        for (let i = 0; i < 900; i++) { c.fillStyle = 'rgba(160,210,140,.12)'; c.beginPath(); c.arc(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 0.5 + rnd() * 0.8, 0, 7); c.fill(); }
      } else if (D.th === 'tunnel') { // mountain rock: strata, scree, patches of old snow
        for (let i = 0; i < 520; i++) { c.fillStyle = rnd() < 0.5 ? 'rgba(40,36,32,.28)' : 'rgba(190,185,175,.2)'; c.beginPath(); c.ellipse(B[0] + rnd() * (B[2] - B[0]), B[1] + rnd() * (B[3] - B[1]), 1.5 + rnd() * 5, 0.8 + rnd() * 2.2, rnd() * 3, 0, 7); c.fill(); }
        c.strokeStyle = 'rgba(40,35,30,.22)'; c.lineWidth = 0.5;
        for (let i = 0; i < 70; i++) { const x0 = B[0] + rnd() * (B[2] - B[0]), y0 = B[1] + rnd() * (B[3] - B[1]); c.beginPath(); c.moveTo(x0, y0); c.bezierCurveTo(x0 + 6, y0 - 3, x0 + 12, y0 + 3, x0 + 20, y0); c.stroke(); }
        for (let i = 0; i < 26; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]); if (nearTrack(px, py, half + tr.wall + 6)) continue; c.fillStyle = 'rgba(245,248,252,.85)'; c.beginPath(); for (let k = 0; k < 7; k++) { const a = k * 0.9, q = 2 + rnd() * 3; c.lineTo(px + Math.cos(a) * q, py + Math.sin(a) * q * 0.7); } c.fill(); }
      } else if (D.th === 'library') { // tall bookshelves seen from above: rows of coloured spines
        for (let gy = B[1], row = 0; gy < B[3]; gy += 5, row++) {
          c.fillStyle = '#4a2c18'; c.fillRect(B[0], gy, B[2] - B[0], 5);
          for (let gx = B[0]; gx < B[2];) { const w2 = 0.5 + rnd() * 0.7; c.fillStyle = ['#8a2e28', '#2e5a8a', '#3a6a3a', '#a8803a', '#6a3a7a', '#c0b090'][Math.floor(rnd() * 6)]; c.fillRect(gx, gy + 0.6, w2 - 0.08, 3.6); if (rnd() < 0.2) { c.fillStyle = 'rgba(255,220,140,.5)'; c.fillRect(gx, gy + 1.6, w2 - 0.08, 0.25); } gx += w2; }
          c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(B[0], gy + 4.2, B[2] - B[0], 0.8);
        }
      } else if (D.th === 'disco') { // dark club walls with glowing squares
        for (let gx = B[0]; gx < B[2]; gx += 4) for (let gy = B[1]; gy < B[3]; gy += 4) { const r = rnd(); c.fillStyle = r < 0.06 ? 'rgba(255,95,180,.5)' : r < 0.12 ? 'rgba(79,227,255,.45)' : r < 0.16 ? 'rgba(255,209,102,.4)' : 'rgba(255,255,255,.03)'; c.fillRect(gx + 0.3, gy + 0.3, 3.4, 3.4); }
      } else if (D.th === 'foundry') { // steel plates, pipes and glowing furnace vents
        for (let gx = B[0]; gx < B[2]; gx += 8) for (let gy = B[1]; gy < B[3]; gy += 8) { c.fillStyle = rnd() < 0.5 ? '#2a2424' : '#231e1e'; c.fillRect(gx + 0.2, gy + 0.2, 7.6, 7.6); c.fillStyle = 'rgba(255,255,255,.06)'; for (const [ox, oy] of [[1, 1], [7, 1], [1, 7], [7, 7]]) c.fillRect(gx + ox - 0.2, gy + oy - 0.2, 0.4, 0.4); }
        for (let n = 0; n < 24; n++) { const px = rx(), py = ry(), L2 = 10 + rnd() * 30, v = rnd() < 0.5; c.strokeStyle = '#4a4040'; c.lineWidth = 1.4; c.beginPath(); c.moveTo(px, py); c.lineTo(v ? px : px + L2, v ? py + L2 : py); c.stroke(); c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 0.3; c.stroke(); }
        for (let n = 0; n < 14; n++) { const px = rx(), py = ry(), g = c.createRadialGradient(px, py, 0.2, px, py, 3); g.addColorStop(0, 'rgba(255,200,90,.8)'); g.addColorStop(1, 'rgba(255,90,20,0)'); c.fillStyle = g; c.beginPath(); c.arc(px, py, 3, 0, 7); c.fill(); }
      } else if (D.th === 'canyon') { // layered red rock with ledges
        c.strokeStyle = 'rgba(60,20,8,.25)'; c.lineWidth = 0.8;
        for (let i = 0; i < 90; i++) { const x0 = rx(), y0 = ry(); c.beginPath(); c.moveTo(x0, y0); c.bezierCurveTo(x0 + 8, y0 - 3, x0 + 16, y0 + 3, x0 + 26, y0); c.stroke(); }
        for (let i = 0; i < 300; i++) { c.fillStyle = rnd() < 0.5 ? 'rgba(60,20,8,.25)' : 'rgba(255,190,140,.16)'; c.beginPath(); c.ellipse(rx(), ry(), 1 + rnd() * 4, 0.6 + rnd() * 2, rnd() * 3, 0, 7); c.fill(); }
      } else if (D.th === 'stadium') { // grandstands: rows of coloured seats, aisles, a roof edge
        const SEAT = ['#3d5a8a', '#8a3d4a', '#4a4656', '#5a6a7a'];
        for (let gy = B[1], row = 0; gy < B[3]; gy += 1.6, row++) for (let gx = B[0] + (row % 2) * 0.8; gx < B[2]; gx += 1.6) { const r = rnd(); c.fillStyle = r < 0.12 ? COLS5[Math.floor(rnd() * 5)] : SEAT[Math.floor((gx - B[0]) / 24) % 4]; c.fillRect(gx, gy, 1.2, 1.1); }
        c.fillStyle = 'rgba(0,0,0,.35)'; for (let gx = B[0]; gx < B[2]; gx += 24) c.fillRect(gx, B[1], 1.2, B[3] - B[1]);
        c.fillStyle = th.base; c.beginPath(); for (let i = 0; i < NS; i++) c.lineTo(tr.x[i], tr.y[i]); c.closePath(); c.fill(); // the grass infield
        c.save(); c.clip(); for (let gx = B[0]; gx < B[2]; gx += 8) { c.fillStyle = 'rgba(255,255,255,.05)'; c.fillRect(gx, B[1], 4, B[3] - B[1]); } c.restore();
      } else if (D.th === 'metro') { // daytime city blocks: pale roofs, rooftop gardens, solar panels
        for (let gx = B[0]; gx < B[2]; gx += 13) for (let gy = B[1]; gy < B[3]; gy += 13) {
          const w2 = 9 + rnd() * 3, h2 = 9 + rnd() * 3, x0 = gx + (12.5 - w2) / 2, y0 = gy + (12.5 - h2) / 2, r = rnd();
          c.fillStyle = 'rgba(0,0,0,.28)'; c.fillRect(x0 + 1, y0 + 1.4, w2, h2);
          c.fillStyle = ['#b9bcc4', '#a7abb5', '#c8c2b4', '#9aa3ad'][Math.floor(rnd() * 4)]; c.fillRect(x0, y0, w2, h2);
          if (r < 0.3) { c.fillStyle = '#6aa04e'; c.fillRect(x0 + 1, y0 + 1, w2 - 2, h2 - 2); for (let k = 0; k < 4; k++) blob(x0 + 2 + rnd() * (w2 - 4), y0 + 2 + rnd() * (h2 - 4), 0.9, '#3f7a3a'); }
          else if (r < 0.6) { c.fillStyle = '#2e4a7a'; for (let k = 0; k < 3; k++) c.fillRect(x0 + 1, y0 + 1 + k * 3, w2 - 2, 2.2); }
          else { c.fillStyle = '#8a8f98'; c.fillRect(x0 + w2 * 0.6, y0 + 1, 2, 2); c.beginPath(); c.arc(x0 + 2.5, y0 + h2 - 2.5, 1.2, 0, 7); c.fill(); }
        }
      } else if (D.th === 'market') { // stalls under striped awnings, crates of fruit
        for (let gx = B[0]; gx < B[2]; gx += 7) for (let gy = B[1]; gy < B[3]; gy += 6) {
          const r = rnd(), col = ['#a8283a', '#20608c', '#a8742a', '#3f8f6a', '#7a5aa8'][Math.floor(rnd() * 5)];
          c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(gx + 0.6, gy + 0.8, 6, 5);
          if (r < 0.45) { c.fillStyle = col; c.fillRect(gx, gy, 6, 5); c.fillStyle = 'rgba(230,220,200,.35)'; for (let k = 0; k < 6; k += 1.2) c.fillRect(gx + k, gy, 0.6, 5); }
          else if (r < 0.6) { c.fillStyle = '#2b2026'; c.fillRect(gx, gy, 6, 5); }
          else { c.fillStyle = '#7a4a2c'; c.fillRect(gx + 0.5, gy + 0.5, 5, 4); for (let k = 0; k < 6; k++) blob(gx + 1.2 + (k % 3) * 1.6, gy + 1.5 + Math.floor(k / 3) * 1.8, 0.65, ['#ee6a55', '#ffd166', '#5fd3a0'][k % 3]); }
        }
        c.fillStyle = 'rgba(20,10,16,.45)'; c.fillRect(B[0], B[1], B[2] - B[0], B[3] - B[1]); // dusk over the stalls
        for (let n = 0; n < 60; n++) { const px = rx(), py = ry(), g = c.createRadialGradient(px, py, 0.1, px, py, 3); g.addColorStop(0, 'rgba(255,200,110,.55)'); g.addColorStop(1, 'rgba(255,200,110,0)'); c.fillStyle = g; c.beginPath(); c.arc(px, py, 3, 0, 7); c.fill(); }
      } else if (D.th === 'hwy') { // dark woods and fields beside the motorway
        for (let i = 0; i < 1400; i++) { const px = rx(), py = ry(), r = 1 + rnd() * 2.2; c.fillStyle = ['#18261a', '#1f3220', '#14201a'][Math.floor(rnd() * 3)]; c.beginPath(); c.arc(px, py, r, 0, 7); c.fill(); }
      } else { // city blocks seen from above: rooftops with vents, water tanks, skylights and neon signs
        for (let gx = B[0]; gx < B[2]; gx += 13) for (let gy = B[1]; gy < B[3]; gy += 13) {
          const w2 = 9 + rnd() * 3, h2 = 9 + rnd() * 3, x0 = gx + (12.5 - w2) / 2, y0 = gy + (12.5 - h2) / 2;
          c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(x0 + 1, y0 + 1.4, w2, h2);
          c.fillStyle = ['#221f2e', '#2a2638', '#1d1b27', '#2e2a3c'][Math.floor(rnd() * 4)]; c.fillRect(x0, y0, w2, h2);
          c.strokeStyle = 'rgba(255,255,255,.08)'; c.lineWidth = 0.4; c.strokeRect(x0 + 0.3, y0 + 0.3, w2 - 0.6, h2 - 0.6);
          for (let q = 0; q < 3; q++) { const r = rnd(), px = x0 + 1 + rnd() * (w2 - 3), py = y0 + 1 + rnd() * (h2 - 3); if (r < 0.4) { c.fillStyle = '#3a3648'; c.fillRect(px, py, 1.6, 1.2); c.fillStyle = 'rgba(0,0,0,.4)'; c.fillRect(px + 0.3, py + 0.3, 1, 0.25); } else if (r < 0.6) { c.fillStyle = '#4a4458'; c.beginPath(); c.arc(px + 0.8, py + 0.8, 0.9, 0, 7); c.fill(); } else { c.fillStyle = rnd() < 0.6 ? 'rgba(255,209,102,.55)' : 'rgba(120,200,255,.45)'; c.fillRect(px, py, 1.4, 0.9); } }
          if (rnd() < 0.18) { const col = ['#ff5fb4', '#4fe3ff', '#ffd166', '#5fd3a0'][Math.floor(rnd() * 4)]; c.strokeStyle = col; c.globalAlpha = 0.3; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x0 + 1, y0 + 0.6); c.lineTo(x0 + w2 - 1, y0 + 0.6); c.stroke(); c.globalAlpha = 1; c.lineWidth = 0.4; c.stroke(); }
        }
      }
      const ww = (half + tr.wall) * 2;
      path(0); c.strokeStyle = 'rgba(0,0,0,.55)'; c.lineWidth = ww + 2.6; c.stroke();
      for (const C of tr.cuts) { cutPath(C); c.lineWidth = C.hw * 2 + 2.6; c.stroke(); }
      if (D.th === 'city') { // neon strips along the walls
        for (const [col, w] of [['rgba(255,80,180,.35)', ww + 2.2], ['#ff5fb4', ww + 0.9]]) { path(0); c.strokeStyle = col; c.lineWidth = w; c.stroke(); }
        for (const C of tr.cuts) { cutPath(C); c.strokeStyle = '#4fe3ff'; c.lineWidth = C.hw * 2 + 1.2; c.stroke(); }
      } else { path(0); c.strokeStyle = th.rockHi; c.lineWidth = ww + 0.9; c.stroke(); for (const C of tr.cuts) { cutPath(C); c.lineWidth = C.hw * 2 + 0.9; c.stroke(); } }
      path(0); c.strokeStyle = th.off; c.lineWidth = ww; c.stroke();
      if (D.th === 'candy') for (const sd of [-1, 1]) { // candy-cane wall edge
        c.lineCap = 'butt'; path(sd * (half + tr.wall)); c.strokeStyle = '#ffffff'; c.lineWidth = 1.5; c.stroke();
        c.strokeStyle = '#e8384f'; c.setLineDash([1.4, 1.4]); c.stroke(); c.setLineDash([]); c.lineCap = 'round';
      }
      if (D.th === 'factory') for (const sd of [-1, 1]) { // yellow / black safety edge
        c.lineCap = 'butt'; path(sd * (half + tr.wall - 0.3)); c.strokeStyle = '#f2c230'; c.lineWidth = 0.6; c.stroke();
        c.strokeStyle = '#1c1d20'; c.setLineDash([0.9, 0.9]); c.stroke(); c.setLineDash([]); c.lineCap = 'round';
      }
      if (D.th === 'haunt') for (const sd of [-1, 1]) { // low mossy stone wall in front of the hedge
        path(sd * (half + tr.wall - 0.2)); c.strokeStyle = '#4d4856'; c.lineWidth = 0.9; c.stroke();
        c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 0.15; c.setLineDash([1.2, 0.5]); c.stroke(); c.setLineDash([]);
      }
      if (D.th === 'tunnel') for (const sd of [-1, 1]) { // steel guardrail on posts
        for (let i = 0; i < NS; i += 3) { const o = sd * (half + tr.wall - 0.35); c.fillStyle = '#3d3a36'; c.fillRect(tr.x[i] + tr.nx[i] * o - 0.25, tr.y[i] + tr.ny[i] * o - 0.25, 0.5, 0.5); }
        path(sd * (half + tr.wall - 0.35)); c.strokeStyle = '#d9dde3'; c.lineWidth = 0.4; c.stroke();
        for (const C of tr.cuts) for (const s2 of [-1, 1]) { c.beginPath(); for (let k = 0; k < C.n; k++) { const k2 = Math.min(C.n - 1, k + 1), k1 = Math.max(0, k2 - 2), dx = C.sx[k2] - C.sx[k1], dy = C.sy[k2] - C.sy[k1], l = Math.hypot(dx, dy) || 1, ox = -dy / l * (C.hw + tr.wall - 0.35) * s2, oy = dx / l * (C.hw + tr.wall - 0.35) * s2; k ? c.lineTo(C.sx[k] + ox, C.sy[k] + oy) : c.moveTo(C.sx[k] + ox, C.sy[k] + oy); } c.stroke(); }
      }
      if (D.th === 'disco') for (const sd of [-1, 1]) { path(sd * (half + tr.wall - 0.2)); c.strokeStyle = sd > 0 ? '#4fe3ff' : '#ff5fb4'; c.lineWidth = 0.5; c.stroke(); }
      if (D.th === 'foundry') for (const sd of [-1, 1]) { c.lineCap = 'butt'; path(sd * (half + tr.wall - 0.3)); c.strokeStyle = '#f2c230'; c.lineWidth = 0.6; c.stroke(); c.strokeStyle = '#1c1d20'; c.setLineDash([0.9, 0.9]); c.stroke(); c.setLineDash([]); c.lineCap = 'round'; }
      if (D.th === 'library') for (const sd of [-1, 1]) { path(sd * (half + tr.wall - 0.25)); c.strokeStyle = '#9a6a32'; c.lineWidth = 0.6; c.stroke(); }
      if (D.th === 'stadium' || D.th === 'hwy' || D.th === 'metro') for (const sd of [-1, 1]) { // concrete barrier / guardrail
        path(sd * (half + tr.wall - 0.3)); c.strokeStyle = D.th === 'stadium' ? '#f2f2f2' : '#c8ccd4'; c.lineWidth = 0.6; c.stroke();
        if (D.th === 'stadium') { c.strokeStyle = '#e8384f'; c.setLineDash([2, 2]); c.stroke(); c.setLineDash([]); }
      }
      if (D.th === 'market') for (const sd of [-1, 1]) { for (let i = 0; i < NS; i += 6) { const o = sd * (half + tr.wall - 0.3), px = tr.x[i] + tr.nx[i] * o, py = tr.y[i] + tr.ny[i] * o; c.fillStyle = i % 12 ? '#ff6a3d' : '#ffd166'; c.beginPath(); c.arc(px, py, 0.45, 0, 7); c.fill(); } }
      if (D.th === 'canyon') for (const sd of [-1, 1]) { path(sd * (half + tr.wall - 0.2)); c.strokeStyle = 'rgba(60,20,8,.45)'; c.lineWidth = 0.7; c.stroke(); }
      if (D.th === 'sea') for (const sd of [-1, 1]) { // glass tube walls
        path(sd * (half + tr.wall)); c.strokeStyle = 'rgba(160,240,255,.7)'; c.lineWidth = 0.8; c.stroke();
        path(sd * (half + tr.wall - 0.7)); c.strokeStyle = 'rgba(255,255,255,.25)'; c.lineWidth = 0.3; c.stroke();
      }
    }
    // shortcuts
    for (const C of tr.cuts) {
      cutPath(C); c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = C.hw * 2 + 1; c.stroke();
      cutPath(C); c.strokeStyle = C.tide ? '#cdb58a' : C.s === 'road' ? th.road : SURF_COL[C.s] || '#a8784a'; c.lineWidth = C.hw * 2; c.stroke();
      if (C.s === 'wood') { // planks
        c.strokeStyle = 'rgba(50,25,10,.45)'; c.lineWidth = 0.25;
        for (let k = 1; k < C.n - 1; k++) { const dx = C.sx[k + 1] - C.sx[k - 1], dy = C.sy[k + 1] - C.sy[k - 1], l = Math.hypot(dx, dy) || 1, px = -dy / l * C.hw, py = dx / l * C.hw; c.beginPath(); c.moveTo(C.sx[k] - px, C.sy[k] - py); c.lineTo(C.sx[k] + px, C.sy[k] + py); c.stroke(); }
        cutPath(C); c.strokeStyle = 'rgba(60,30,10,.8)'; c.lineWidth = 0.5; c.setLineDash([]); c.save(); c.lineWidth = C.hw * 2 + 0.8; c.globalCompositeOperation = 'destination-over'; c.stroke(); c.restore();
      } else if (C.s === 'ice') { c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 0.4; for (let k = 2; k < C.n - 2; k += 3) { c.beginPath(); c.moveTo(C.sx[k] - 2, C.sy[k] - 1); c.lineTo(C.sx[k] + 2.5, C.sy[k] + 0.6); c.stroke(); } }
      else if (C.s === 'dirt' || C.s === 'sand') { for (let k = 0; k < C.n; k++) { c.fillStyle = rnd() < 0.5 ? 'rgba(60,30,10,.25)' : 'rgba(255,240,200,.22)'; c.fillRect(C.sx[k] + (rnd() - 0.5) * C.hw * 2, C.sy[k] + (rnd() - 0.5) * C.hw * 2, 0.5, 0.5); } }
      else if (C.s === 'road') { cutPath(C); c.strokeStyle = 'rgba(255,209,102,.5)'; c.lineWidth = 0.3; c.setLineDash([2, 2]); c.stroke(); c.setLineDash([]); }
    }
    // railway embankment (ballast + sleepers) under the road; the rails go on top later
    for (const Tn of tr.trains) {
      const ex = Tn.ax + Tn.ux * Tn.L, ey = Tn.ay + Tn.uy * Tn.L;
      c.lineCap = 'butt';
      c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = TRAIN_W * 2 + 3.4; c.beginPath(); c.moveTo(Tn.ax, Tn.ay); c.lineTo(ex, ey); c.stroke();
      c.strokeStyle = '#8d8781'; c.lineWidth = TRAIN_W * 2 + 2.2; c.stroke();
      for (let k = 0; k < Tn.L * 3; k++) { c.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.14)'; const sv = rnd() * Tn.L, nv = (rnd() * 2 - 1) * (TRAIN_W + 1); c.fillRect(Tn.ax + Tn.ux * sv + Tn.nx * nv, Tn.ay + Tn.uy * sv + Tn.ny * nv, 0.35, 0.35); }
      c.strokeStyle = '#5a3d26'; c.lineWidth = 0.6;
      for (let sv = 0; sv < Tn.L; sv += 1.5) { const px = Tn.ax + Tn.ux * sv, py = Tn.ay + Tn.uy * sv; c.beginPath(); c.moveTo(px - Tn.nx * (TRAIN_W + 0.3), py - Tn.ny * (TRAIN_W + 0.3)); c.lineTo(px + Tn.nx * (TRAIN_W + 0.3), py + Tn.ny * (TRAIN_W + 0.3)); c.stroke(); }
      c.lineCap = 'round';
    }
    // road shadow, curbs, edge, asphalt
    c.save(); c.translate(0.5, 0.9); path(0); c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = half * 2 + 3; c.stroke(); c.restore();
    if (th.curb) for (const side of [-1, 1]) {
      const off = side * (half + 0.75);
      for (let i = 0; i < NS; i++) {
        if (tr.acurv[i] < 0.025) continue;
        const j = (i + 1) % NS;
        c.strokeStyle = Math.floor(i / 2) % 2 ? '#d6403a' : '#f1ebe0'; c.lineWidth = 1.5; c.lineCap = 'butt';
        c.beginPath(); c.moveTo(tr.x[i] + tr.nx[i] * off, tr.y[i] + tr.ny[i] * off); c.lineTo(tr.x[j] + tr.nx[j] * off, tr.y[j] + tr.ny[j] * off); c.stroke();
      }
      c.lineCap = 'round';
    }
    path(0); c.strokeStyle = th.edge; c.lineWidth = half * 2 + 0.9; c.stroke();
    path(0); c.strokeStyle = th.road; c.lineWidth = half * 2 - 0.4; c.stroke();
    for (let i = 0; i < NS; i++) for (let k = 0; k < 5; k++) {
      const l = (rnd() * 2 - 1) * (half - 0.6), al = rnd() * tr.ds;
      c.fillStyle = rnd() < 0.5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.12)';
      c.fillRect(tr.x[i] + tr.nx[i] * l + tr.tx[i] * al, tr.y[i] + tr.ny[i] * l + tr.ty[i] * al, 0.3, 0.3);
    }
    if (D.th === 'city') { path(0); c.strokeStyle = 'rgba(255,209,102,.55)'; c.lineWidth = 0.35; c.setLineDash([3, 3]); c.stroke(); c.setLineDash([]); }
    else if (deckArt(D.th)) { /* themed deck drawn */ }
    if (D.th === 'city') for (let i = 4; i < NS; i += 16) for (const sd of [-1, 1]) { // street lamps with warm pools of light
      const o = sd * (half + 0.9), px = tr.x[i] + tr.nx[i] * o, py = tr.y[i] + tr.ny[i] * o, g = c.createRadialGradient(px, py, 0.2, px, py, 5);
      g.addColorStop(0, 'rgba(255,214,140,.35)'); g.addColorStop(1, 'rgba(255,214,140,0)'); c.fillStyle = g; c.beginPath(); c.arc(px, py, 5, 0, 7); c.fill();
      c.fillStyle = '#ffe2a8'; c.beginPath(); c.arc(px, py, 0.4, 0, 7); c.fill();
    }
    else if (D.th === 'snow') { for (const s of [-1, 1]) { path(s * (half - 0.4)); c.strokeStyle = 'rgba(255,255,255,.55)'; c.lineWidth = 1.1; c.setLineDash([1.5, 2.5]); c.stroke(); } c.setLineDash([]); }
    else { path(0); c.strokeStyle = 'rgba(0,0,0,.08)'; c.lineWidth = half * 0.9; c.stroke(); }
    if (tr.hwA) { // narrow sections (generated courses): run-off over the outer strip of the road, a new edge, cones
      c.lineCap = 'butt';
      for (let i = 0; i < NS; i++) {
        const w = tr.hwA[i], j = (i + 1) % NS;
        if (w >= half - 0.05) continue;
        for (const sd of [-1, 1]) {
          const o = sd * (w + (half + 0.6 - w) / 2);
          c.strokeStyle = th.off; c.lineWidth = half + 0.6 - w + 0.05;
          c.beginPath(); c.moveTo(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o); c.lineTo(tr.x[j] + tr.nx[j] * o + tr.tx[j] * 0.15, tr.y[j] + tr.ny[j] * o + tr.ty[j] * 0.15); c.stroke();
          const e = sd * w, e2 = sd * tr.hwA[j];
          c.strokeStyle = th.edge; c.lineWidth = 0.45;
          c.beginPath(); c.moveTo(tr.x[i] + tr.nx[i] * e, tr.y[i] + tr.ny[i] * e); c.lineTo(tr.x[j] + tr.nx[j] * e2, tr.y[j] + tr.ny[j] * e2); c.stroke();
          if (i % 7 === 0 && w < half - 0.8) { const cx2 = tr.x[i] + tr.nx[i] * (e + sd * 0.7), cy2 = tr.y[i] + tr.ny[i] * (e + sd * 0.7); c.fillStyle = '#ff7a2f'; c.beginPath(); c.arc(cx2, cy2, 0.42, 0, 7); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.arc(cx2, cy2, 0.17, 0, 7); c.fill(); }
        }
      }
      c.lineCap = 'round';
    }
    // ice patches on the road
    for (let i = 0; i < NS; i++) {
      if (!tr.ice[i]) continue;
      const j = (i + 1) % NS;
      c.strokeStyle = 'rgba(175,225,250,.85)'; c.lineWidth = half * 2 - 0.6; c.lineCap = 'butt';
      c.beginPath(); c.moveTo(tr.x[i], tr.y[i]); c.lineTo(tr.x[j] + tr.tx[j] * 0.2, tr.y[j] + tr.ty[j] * 0.2); c.stroke();
      if (i % 3 === 0) { c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 0.3; const l = (rnd() * 2 - 1) * (half - 2); c.beginPath(); c.moveTo(tr.x[i] + tr.nx[i] * l, tr.y[i] + tr.ny[i] * l); c.lineTo(tr.x[i] + tr.nx[i] * (l + 1.5) + tr.tx[i] * 3, tr.y[i] + tr.ny[i] * (l + 1.5) + tr.ty[i] * 3); c.stroke(); }
      c.lineCap = 'round';
    }
    // cracked ground (volcano): darker patches with glowing fissures
    for (let i = 0; i < NS; i++) {
      if (!tr.rough[i]) continue;
      const j = (i + 1) % NS;
      c.strokeStyle = 'rgba(20,12,12,.55)'; c.lineWidth = half * 2 - 0.6; c.lineCap = 'butt';
      c.beginPath(); c.moveTo(tr.x[i], tr.y[i]); c.lineTo(tr.x[j] + tr.tx[j] * 0.2, tr.y[j] + tr.ty[j] * 0.2); c.stroke();
      c.lineCap = 'round';
      if (i % 2 === 0) {
        let l = (rnd() * 2 - 1) * (half - 1.5), px = tr.x[i] + tr.nx[i] * l, py = tr.y[i] + tr.ny[i] * l;
        c.strokeStyle = rnd() < 0.5 ? 'rgba(255,120,40,.85)' : 'rgba(255,190,80,.7)'; c.lineWidth = 0.28;
        c.beginPath(); c.moveTo(px, py);
        for (let k = 0; k < 3; k++) { l += (rnd() - 0.5) * 2.4; const q = Math.min(NS - 1, i + k); px = tr.x[q] + tr.nx[q] * l + tr.tx[q] * rnd(); py = tr.y[q] + tr.ny[q] * l + tr.ty[q] * rnd(); c.lineTo(px, py); }
        c.stroke();
      }
    }
    // space deck: plate seams and guide lights
    if (D.th === 'space') {
      c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 0.22;
      for (let i = 0; i < NS; i += 4) { c.beginPath(); c.moveTo(tr.x[i] - tr.nx[i] * half, tr.y[i] - tr.ny[i] * half); c.lineTo(tr.x[i] + tr.nx[i] * half, tr.y[i] + tr.ny[i] * half); c.stroke(); }
      for (let i = 0; i < NS; i += 6) for (const sd of [-1, 1]) { c.fillStyle = i % 12 ? 'rgba(79,227,255,.8)' : 'rgba(255,95,180,.9)'; c.beginPath(); c.arc(tr.x[i] + tr.nx[i] * sd * (half - 0.5), tr.y[i] + tr.ny[i] * sd * (half - 0.5), 0.3, 0, 7); c.fill(); }
    }
    const band = (arr, f) => { for (let i = 0; i < NS; i++) if (arr[i] && arr[i] === arr[i]) f(i, arr[i]); };
    // undersea currents: a blue tint across the road (the moving arrows are drawn live)
    band(tr.flow, (i) => { const j = (i + 1) % NS; c.strokeStyle = 'rgba(90,200,255,.13)'; c.lineWidth = half * 2 - 0.6; c.lineCap = 'butt'; c.beginPath(); c.moveTo(tr.x[i], tr.y[i]); c.lineTo(tr.x[j] + tr.tx[j] * 0.2, tr.y[j] + tr.ty[j] * 0.2); c.stroke(); c.lineCap = 'round'; });
    // glass tunnel ribs / mine timber frames across the road
    if (D.th === 'sea' || D.th === 'mine') for (let i = 0; i < NS; i += D.th === 'sea' ? 10 : 14) {
      const o = half + (tr.wall || 0);
      c.strokeStyle = D.th === 'sea' ? 'rgba(160,240,255,.16)' : 'rgba(60,40,22,.55)'; c.lineWidth = D.th === 'sea' ? 0.5 : 0.8;
      c.beginPath(); c.moveTo(tr.x[i] - tr.nx[i] * o, tr.y[i] - tr.ny[i] * o); c.lineTo(tr.x[i] + tr.nx[i] * o, tr.y[i] + tr.ny[i] * o); c.stroke();
      if (D.th === 'mine') for (const sd of [-1, 1]) { const px = tr.x[i] + tr.nx[i] * sd * (o - 0.3), py = tr.y[i] + tr.ny[i] * sd * (o - 0.3); c.fillStyle = '#6b4a2c'; c.fillRect(px - 0.7, py - 0.7, 1.4, 1.4); }
    }
    // mine-cart rails (fast lane)
    for (const [a, b, lat] of D.rails || []) {
      const i0 = Math.round(a * NS), i1 = Math.round(b * NS);
      c.strokeStyle = '#6b4a2c'; c.lineWidth = 0.45; c.lineCap = 'butt';
      for (let i = i0; i <= i1; i++) { const j = i % NS; c.beginPath(); c.moveTo(tr.x[j] + tr.nx[j] * (lat - 1.4), tr.y[j] + tr.ny[j] * (lat - 1.4)); c.lineTo(tr.x[j] + tr.nx[j] * (lat + 1.4), tr.y[j] + tr.ny[j] * (lat + 1.4)); c.stroke(); }
      span(i0, i1, lat - 0.9, 0.35, '#d9dde3'); span(i0, i1, lat + 0.9, 0.35, '#d9dde3');
      for (let i = i0 + 4; i < i1; i += 8) { const j = i % NS; c.save(); c.translate(tr.x[j] + tr.nx[j] * lat, tr.y[j] + tr.ny[j] * lat); c.rotate(tr.hd[j]); c.strokeStyle = 'rgba(255,209,102,.8)'; c.lineWidth = 0.35; c.beginPath(); c.moveTo(-0.6, -0.6); c.lineTo(0.2, 0); c.lineTo(-0.6, 0.6); c.stroke(); c.restore(); }
      c.lineCap = 'round';
    }
    // slopes: chevrons down the road (pink ≫ downhill = faster, orange › uphill = slower)
    band(tr.slope, (i, v) => {
      if (i % 12) return;
      c.save(); c.translate(tr.x[i], tr.y[i]); c.rotate(tr.hd[i]);
      c.strokeStyle = v > 0 ? 'rgba(255,190,220,.45)' : 'rgba(255,160,80,.45)'; c.lineWidth = 0.55;
      for (const k of v > 0 ? [-0.8, 0.8] : [0]) for (const sd of [-1, 1]) { c.beginPath(); c.moveTo(k - 0.9, sd * (half - 2.2) - 1.1); c.lineTo(k + 0.4, sd * (half - 2.2)); c.lineTo(k - 0.9, sd * (half - 2.2) + 1.1); c.stroke(); }
      c.restore();
    });
    if (D.th === 'blossom') for (let i = 0; i < NS * 1.2; i++) { const j = Math.floor(rnd() * NS), l = (rnd() < 0.6 ? 1 : -1) * (half - 1.5 + rnd() * 3); c.fillStyle = rnd() < 0.5 ? 'rgba(255,190,215,.75)' : 'rgba(255,225,238,.75)'; c.beginPath(); c.ellipse(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, 0.35, 0.22, rnd() * 3, 0, 7); c.fill(); }
    // syrup puddles (glossy amber) and sand pits (swirling funnels)
    for (const q of tr.syrup) {
      const g = c.createRadialGradient(q.x - q.r * 0.3, q.y - q.r * 0.3, 0.2, q.x, q.y, q.r);
      g.addColorStop(0, '#ffcf6b'); g.addColorStop(0.6, '#d9822b'); g.addColorStop(1, '#9a4f12');
      c.fillStyle = g; c.beginPath(); for (let k = 0; k < 14; k++) { const a = k / 14 * Math.PI * 2, rr2 = q.r * (0.88 + rnd() * 0.16); c.lineTo(q.x + Math.cos(a) * rr2, q.y + Math.sin(a) * rr2); } c.closePath(); c.fill();
      c.strokeStyle = 'rgba(120,55,10,.7)'; c.lineWidth = 0.35; c.stroke();
      c.fillStyle = 'rgba(255,255,255,.5)'; c.beginPath(); c.ellipse(q.x - q.r * 0.35, q.y - q.r * 0.4, q.r * 0.3, q.r * 0.14, -0.5, 0, 7); c.fill();
    }
    for (const q of tr.hzs) { // course hazard patches: each kind looks clearly different, with a dashed warning ring
      const col = { mud: ['#5a3d1e', '#7b5530', 'rgba(60,38,16,.9)'], ice: ['#e6f7ff', '#9fd8f2', 'rgba(90,170,220,.9)'], pud: ['#5aa6d6', '#2f6f9e', 'rgba(30,80,130,.85)'], oil: ['#2a2a30', '#111116', 'rgba(10,10,12,.9)'] }[q.k] || ['#888', '#666', '#444'];
      const g = c.createRadialGradient(q.x - q.r * 0.25, q.y - q.r * 0.25, 0.2, q.x, q.y, q.r);
      g.addColorStop(0, col[0]); g.addColorStop(1, col[1]);
      c.fillStyle = g; c.beginPath(); for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2, rr2 = q.r * (0.85 + rnd() * 0.15); c.lineTo(q.x + Math.cos(a) * rr2, q.y + Math.sin(a) * rr2); } c.closePath(); c.fill();
      c.strokeStyle = col[2]; c.lineWidth = 0.3; c.stroke();
      if (q.k === 'oil') { for (const [cc, o] of [['rgba(255,80,200,.35)', 0.5], ['rgba(80,220,255,.35)', 0.35], ['rgba(255,230,90,.3)', 0.2]]) { c.strokeStyle = cc; c.lineWidth = 0.35; c.beginPath(); c.arc(q.x, q.y, q.r * o + 0.4, 0, 7); c.stroke(); } }
      else if (q.k === 'ice') { c.strokeStyle = 'rgba(255,255,255,.8)'; c.lineWidth = 0.2; for (let k = 0; k < 4; k++) { const a = rnd() * 7; c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x + Math.cos(a) * q.r * 0.8, q.y + Math.sin(a) * q.r * 0.8); c.stroke(); } }
      else if (q.k === 'pud') { c.strokeStyle = 'rgba(220,240,255,.6)'; c.lineWidth = 0.22; for (const o of [0.35, 0.65]) { c.beginPath(); c.arc(q.x, q.y, q.r * o, 0, 7); c.stroke(); } }
      else { c.fillStyle = 'rgba(40,26,10,.7)'; for (let k = 0; k < 6; k++) { c.beginPath(); c.arc(q.x + (rnd() - 0.5) * q.r, q.y + (rnd() - 0.5) * q.r, 0.3 + rnd() * 0.4, 0, 7); c.fill(); } }
      c.setLineDash([0.8, 0.6]); c.strokeStyle = 'rgba(255,214,90,.85)'; c.lineWidth = 0.28; c.beginPath(); c.arc(q.x, q.y, q.r + 0.6, 0, 7); c.stroke(); c.setLineDash([]);
    }
    for (const q of tr.traps) {
      const g = c.createRadialGradient(q.x, q.y, 0.2, q.x, q.y, q.r);
      g.addColorStop(0, '#6b4a22'); g.addColorStop(0.55, '#b58444'); g.addColorStop(1, 'rgba(214,166,94,.2)');
      c.fillStyle = g; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.fill();
      c.strokeStyle = 'rgba(80,50,20,.45)'; c.lineWidth = 0.25;
      for (let k = 0; k < 4; k++) { c.beginPath(); for (let t = 0; t < 1; t += 0.05) { const a = k * Math.PI / 2 + t * 4, rr2 = q.r * (1 - t) * 0.95; t ? c.lineTo(q.x + Math.cos(a) * rr2, q.y + Math.sin(a) * rr2) : c.moveTo(q.x + Math.cos(a) * rr2, q.y + Math.sin(a) * rr2); } c.stroke(); }
    }
    // level crossing rails + white crossing stripes
    for (const Tn of tr.trains) {
      const ex = Tn.ax + Tn.ux * Tn.L, ey = Tn.ay + Tn.uy * Tn.L;
      for (const sd of [-1, 1]) { c.strokeStyle = '#c9ccd2'; c.lineWidth = 0.35; c.beginPath(); c.moveTo(Tn.ax + Tn.nx * sd * 1.2, Tn.ay + Tn.ny * sd * 1.2); c.lineTo(ex + Tn.nx * sd * 1.2, ey + Tn.ny * sd * 1.2); c.stroke(); }
      for (const X of Tn.cross) for (const sd of [-1, 1]) {
        const px = Tn.ax + Tn.ux * X.s + Tn.nx * sd * (TRAIN_W + 1.6), py = Tn.ay + Tn.uy * X.s + Tn.ny * sd * (TRAIN_W + 1.6), hl = half / X.sn;
        c.strokeStyle = '#f2ede4'; c.lineWidth = 0.5; c.setLineDash([0.8, 0.8]); c.beginPath(); c.moveTo(px - Tn.ux * hl, py - Tn.uy * hl); c.lineTo(px + Tn.ux * hl, py + Tn.uy * hl); c.stroke(); c.setLineDash([]);
      }
    }
    // rivers / gaps across the course, then the logs or bridges over them
    for (const R of tr.rivers) {
      const rp = () => { c.beginPath(); R.pts.forEach((q, k) => (k ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1]))); };
      c.lineCap = 'butt';
      if (R.k === 'chasm') { // a deep gorge across the road: cliff edges, a dark drop, a river far below
        rp(); c.strokeStyle = th.rockHi || '#a07850'; c.lineWidth = R.w * 2 + 2.4; c.stroke();
        rp(); c.strokeStyle = th.rock || '#5a4a3a'; c.lineWidth = R.w * 2 + 0.6; c.stroke();
        rp(); c.strokeStyle = '#1a120e'; c.lineWidth = R.w * 2 - 1.6; c.stroke();
        rp(); c.strokeStyle = th.water || '#2f6f8f'; c.lineWidth = R.w * 0.5; c.stroke();
        const q0 = R.pts[0], q1 = R.pts[1], dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1;
        for (let k = 0; k < 40; k++) { const t2 = rnd(), sd = rnd() < 0.5 ? -1 : 1, off = sd * (R.w - 0.3 - rnd() * 0.8); c.fillStyle = rnd() < 0.5 ? 'rgba(0,0,0,.35)' : 'rgba(255,220,180,.2)'; c.beginPath(); c.arc(q0[0] + dx * t2 - dy / l * off, q0[1] + dy * t2 + dx / l * off, 0.3 + rnd() * 0.5, 0, 7); c.fill(); }
      } else if (R.k === 'gap') { // a hole in the sky road: clouds far below
        rp(); c.strokeStyle = '#ffffff'; c.lineWidth = R.w * 2 + 1.8; c.stroke();
        rp(); c.strokeStyle = '#7dbbe8'; c.lineWidth = R.w * 2; c.stroke();
        const q0 = R.pts[0], q1 = R.pts[1], dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1;
        for (let k = 0; k < 26; k++) { const t = rnd(), off = (rnd() * 2 - 1) * (R.w - 1.2), r = 0.8 + rnd() * 1.4; c.fillStyle = 'rgba(255,255,255,' + (0.3 + rnd() * 0.4) + ')'; c.beginPath(); c.arc(q0[0] + dx * t - dy / l * off, q0[1] + dy * t + dx / l * off, r, 0, 7); c.fill(); }
      } else if (R.k === 'crevasse') { // a deep blue crack in the glacier
        rp(); c.strokeStyle = '#eaf6ff'; c.lineWidth = R.w * 2 + 1.6; c.stroke();
        rp(); c.strokeStyle = '#6fb0d8'; c.lineWidth = R.w * 2 + 0.6; c.stroke();
        rp(); c.strokeStyle = '#1d4a72'; c.lineWidth = R.w * 2 - 0.6; c.stroke();
        rp(); c.strokeStyle = '#0b1d33'; c.lineWidth = R.w; c.stroke();
        c.strokeStyle = 'rgba(200,235,255,.5)'; c.lineWidth = 0.2;
        for (let k = 0; k < 60; k++) { const sg = Math.floor(rnd() * (R.pts.length - 1)), t = rnd(), q0 = R.pts[sg], q1 = R.pts[sg + 1], dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1, sd = rnd() < 0.5 ? -1 : 1, px = q0[0] + dx * t - dy / l * sd * (R.w - 0.2), py = q0[1] + dy * t + dx / l * sd * (R.w - 0.2); c.beginPath(); c.moveTo(px, py); c.lineTo(px + dy / l * sd * 1.2, py - dx / l * sd * 1.2); c.stroke(); }
      } else if (R.k === 'molten') { // a channel of molten metal
        rp(); c.strokeStyle = '#2a2222'; c.lineWidth = R.w * 2 + 2.2; c.stroke();
        rp(); c.strokeStyle = '#c2400f'; c.lineWidth = R.w * 2; c.stroke();
        rp(); c.strokeStyle = '#ff8a2a'; c.lineWidth = R.w * 1.3; c.stroke();
        rp(); c.strokeStyle = '#ffd27a'; c.lineWidth = R.w * 0.5; c.stroke();
        for (let k = 0; k < 50; k++) { const t = rnd(), q0 = R.pts[0], q1 = R.pts[1], dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1, off = (rnd() * 2 - 1) * (R.w - 0.6); c.fillStyle = rnd() < 0.5 ? 'rgba(90,20,5,.5)' : 'rgba(255,240,180,.5)'; c.beginPath(); c.ellipse(q0[0] + dx * t - dy / l * off, q0[1] + dy * t + dx / l * off, 0.4 + rnd() * 1.1, 0.25 + rnd() * 0.4, Math.atan2(dy, dx), 0, 7); c.fill(); }
        for (const sd of [-1, 1]) { c.strokeStyle = '#f2c230'; c.lineWidth = 0.5; c.setLineDash([1, 1]); c.beginPath(); const q0 = R.pts[0], q1 = R.pts[1], dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1, ox = -dy / l * (R.w + 0.6) * sd, oy = dx / l * (R.w + 0.6) * sd; c.moveTo(q0[0] + ox, q0[1] + oy); c.lineTo(q1[0] + ox, q1[1] + oy); c.stroke(); c.setLineDash([]); }
      } else if (R.k === 'canal') { // stone-banked canal
        rp(); c.strokeStyle = '#8a8070'; c.lineWidth = R.w * 2 + 2.4; c.stroke();
        rp(); c.strokeStyle = '#6d6458'; c.lineWidth = R.w * 2 + 0.6; c.stroke();
        rp(); c.strokeStyle = th.water; c.lineWidth = R.w * 2; c.stroke();
        c.strokeStyle = 'rgba(200,240,255,.45)'; c.lineWidth = 0.3;
        for (let k = 0; k < 60; k++) { const t = rnd(), q0 = R.pts[0], q1 = R.pts[1], dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1, off = (rnd() * 2 - 1) * (R.w - 0.8), px = q0[0] + dx * t - dy / l * off, py = q0[1] + dy * t + dx / l * off; c.beginPath(); c.moveTo(px, py); c.lineTo(px + dx / l * 1.8, py + dy / l * 1.8); c.stroke(); }
      } else if (R.k === 'void') {
        rp(); c.strokeStyle = '#4fe3ff'; c.lineWidth = R.w * 2 + 1; c.stroke();
        rp(); c.strokeStyle = '#05040e'; c.lineWidth = R.w * 2; c.stroke();
        for (let k = 0; k < 200; k++) { // stars inside the gap
          const sg = Math.floor(rnd() * (R.pts.length - 1)), t = rnd(), q0 = R.pts[sg], q1 = R.pts[sg + 1];
          const dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1, off = (rnd() * 2 - 1) * (R.w - 0.6);
          c.fillStyle = 'rgba(255,255,255,' + (0.3 + rnd() * 0.6) + ')'; c.fillRect(q0[0] + dx * t - dy / l * off, q0[1] + dy * t + dx / l * off, 0.4, 0.4);
        }
      } else {
        rp(); c.strokeStyle = '#3b2a18'; c.lineWidth = R.w * 2 + 2.4; c.stroke();
        rp(); c.strokeStyle = th.water; c.lineWidth = R.w * 2; c.stroke();
        c.strokeStyle = 'rgba(200,245,255,.5)'; c.lineWidth = 0.3;
        for (let k = 0; k < 140; k++) {
          const sg = Math.floor(rnd() * (R.pts.length - 1)), t = rnd(), q0 = R.pts[sg], q1 = R.pts[sg + 1];
          const dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.hypot(dx, dy) || 1, off = (rnd() * 2 - 1) * (R.w - 0.8), px = q0[0] + dx * t - dy / l * off, py = q0[1] + dy * t + dx / l * off;
          c.beginPath(); c.moveTo(px, py); c.lineTo(px + dx / l * 2.2, py + dy / l * 2.2); c.stroke();
        }
      }
      c.lineCap = 'round';
      // the course samples inside this band: draw one log / bridge per lane
      const ks = [];
      for (let i = 0; i < NS; i++) if (tr.rv[i] && tr.rivers[tr.rv[i] - 1] === R) ks.push(i);
      const runs = [];
      for (const i of ks) { const last = runs[runs.length - 1]; if (last && (i - last[1] <= 1)) last[1] = i; else runs.push([i, i]); }
      if (!R.mv) for (const [i0, i1] of runs) for (const [l, hw] of R.lanes) {
        const e0 = Math.max(0, i0 - 2), e1 = Math.min(NS - 1, i1 + 2);
        const lp = () => { c.beginPath(); for (let i = e0; i <= e1; i++) { const px = tr.x[i] + tr.nx[i] * l, py = tr.y[i] + tr.ny[i] * l; i === e0 ? c.moveTo(px, py) : c.lineTo(px, py); } };
        if (R.k === 'crevasse') { // a snow-ice bridge
          lp(); c.strokeStyle = 'rgba(20,50,90,.45)'; c.lineWidth = hw * 2 + 1; c.lineCap = 'butt'; c.stroke();
          lp(); c.strokeStyle = '#d6efff'; c.lineWidth = hw * 2; c.stroke();
          lp(); c.strokeStyle = '#f6fcff'; c.lineWidth = hw * 1.2; c.stroke();
          for (const sd of [-1, 1]) { c.beginPath(); for (let i = e0; i <= e1; i++) { const px = tr.x[i] + tr.nx[i] * (l + sd * (hw - 0.15)), py = tr.y[i] + tr.ny[i] * (l + sd * (hw - 0.15)); i === e0 ? c.moveTo(px, py) : c.lineTo(px, py); } c.strokeStyle = '#7fc4ea'; c.lineWidth = 0.3; c.stroke(); }
        } else if (R.k === 'void') {
          lp(); c.strokeStyle = '#4fe3ff'; c.lineWidth = hw * 2 + 0.8; c.lineCap = 'butt'; c.stroke();
          lp(); c.strokeStyle = '#5d6476'; c.lineWidth = hw * 2 - 0.2; c.stroke();
          lp(); c.strokeStyle = 'rgba(255,209,102,.8)'; c.lineWidth = 0.3; c.setLineDash([1, 1.2]); c.stroke(); c.setLineDash([]);
        } else if (D.th === 'windmill') { // a plank footbridge with railings
          lp(); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = hw * 2 + 1.4; c.lineCap = 'butt'; c.stroke();
          lp(); c.strokeStyle = '#b08458'; c.lineWidth = hw * 2; c.stroke();
          c.strokeStyle = 'rgba(70,40,20,.45)'; c.lineWidth = 0.14;
          for (let i = e0; i <= e1; i++) for (let q = 0; q < 2; q++) { const al = q * 0.5, px = tr.x[i] + tr.tx[i] * al, py = tr.y[i] + tr.ty[i] * al; c.beginPath(); c.moveTo(px + tr.nx[i] * (l - hw), py + tr.ny[i] * (l - hw)); c.lineTo(px + tr.nx[i] * (l + hw), py + tr.ny[i] * (l + hw)); c.stroke(); }
          for (const sd of [-1, 1]) { c.beginPath(); for (let i = e0; i <= e1; i++) { const px = tr.x[i] + tr.nx[i] * (l + sd * (hw + 0.2)), py = tr.y[i] + tr.ny[i] * (l + sd * (hw + 0.2)); i === e0 ? c.moveTo(px, py) : c.lineTo(px, py); } c.strokeStyle = '#f2ede4'; c.lineWidth = 0.45; c.stroke(); }
        } else {
          lp(); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = hw * 2 + 1; c.lineCap = 'round'; c.stroke();
          lp(); c.strokeStyle = '#7a5230'; c.lineWidth = hw * 2; c.stroke();
          lp(); c.strokeStyle = '#a3713f'; c.lineWidth = hw * 1.1; c.stroke();
          lp(); c.strokeStyle = 'rgba(60,30,10,.5)'; c.lineWidth = 0.25; c.stroke();
        }
        c.lineCap = 'round';
      }
    }
    if (tr.leaps.length) for (const C of tr.cuts) if (C.s === 'wood') { // shortcut bridges over a chasm: planks with ropes
      cutPath(C); c.strokeStyle = '#9a6a3c'; c.lineWidth = C.hw * 2; c.lineCap = 'butt'; c.stroke();
      c.strokeStyle = 'rgba(50,25,10,.45)'; c.lineWidth = 0.25;
      for (let k = 1; k < C.n - 1; k++) { const dx = C.sx[k + 1] - C.sx[k - 1], dy = C.sy[k + 1] - C.sy[k - 1], l = Math.hypot(dx, dy) || 1, px = -dy / l * C.hw, py = dx / l * C.hw; c.beginPath(); c.moveTo(C.sx[k] - px, C.sy[k] - py); c.lineTo(C.sx[k] + px, C.sy[k] + py); c.stroke(); }
      for (const sd of [-1, 1]) { c.beginPath(); for (let k = 0; k < C.n; k++) { const k2 = Math.min(C.n - 1, k + 1), k1 = Math.max(0, k2 - 2), dx = C.sx[k2] - C.sx[k1], dy = C.sy[k2] - C.sy[k1], l = Math.hypot(dx, dy) || 1; const px = C.sx[k] - dy / l * (C.hw + 0.3) * sd, py = C.sy[k] + dx / l * (C.hw + 0.3) * sd; k ? c.lineTo(px, py) : c.moveTo(px, py); } c.strokeStyle = '#d8c08a'; c.lineWidth = 0.3; c.stroke(); }
      c.lineCap = 'round';
    }
    // pillars / bumpers
    for (const q of tr.pil) {
      if (q.mill) continue;
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(q.x + 0.5, q.y + 0.8, q.r + 0.2, 0, 7); c.fill();
      if (D.th === 'toy') { // a little tower of stacked blocks
        for (let k = 0; k < 3; k++) { const s2 = q.r * (1 - k * 0.2); c.save(); c.translate(q.x - k * 0.25, q.y - k * 0.35); c.rotate(k * 0.4 + q.x); c.fillStyle = COLS5[(k + Math.round(q.x)) % 5]; rr(c, -s2, -s2, s2 * 2, s2 * 2, 0.35); c.fill(); c.strokeStyle = 'rgba(0,0,0,.28)'; c.lineWidth = 0.15; c.stroke(); c.fillStyle = 'rgba(255,255,255,.25)'; c.fillRect(-s2, -s2, s2 * 2, s2 * 0.5); c.restore(); }
      } else if (D.th === 'aurora') { // a spike of blue ice
        const g = c.createRadialGradient(q.x - q.r * 0.3, q.y - q.r * 0.3, 0.1, q.x, q.y, q.r * 1.2); g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#5fb4e0');
        c.fillStyle = g; c.beginPath(); for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6, r2 = k % 2 ? q.r * 0.6 : q.r * 1.15; c.lineTo(q.x + Math.cos(a) * r2, q.y + Math.sin(a) * r2); } c.closePath(); c.fill();
        c.strokeStyle = 'rgba(255,255,255,.8)'; c.lineWidth = 0.15; c.stroke();
      } else if (D.bumpers) {
        c.fillStyle = '#ff5fb4'; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.fill();
        c.fillStyle = '#ffe066'; c.beginPath(); c.arc(q.x, q.y, q.r * 0.62, 0, 7); c.fill();
        c.fillStyle = '#ff5fb4'; c.beginPath(); c.arc(q.x, q.y, q.r * 0.28, 0, 7); c.fill();
        c.strokeStyle = 'rgba(255,255,255,.8)'; c.lineWidth = 0.25; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.stroke();
      } else {
        c.fillStyle = '#8a7150'; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.fill();
        c.strokeStyle = '#5a4630'; c.lineWidth = 0.3; for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; c.beginPath(); c.moveTo(q.x + Math.cos(a) * q.r * 0.55, q.y + Math.sin(a) * q.r * 0.55); c.lineTo(q.x + Math.cos(a) * q.r, q.y + Math.sin(a) * q.r); c.stroke(); }
        c.fillStyle = '#c9a874'; c.beginPath(); c.arc(q.x - q.r * 0.15, q.y - q.r * 0.15, q.r * 0.55, 0, 7); c.fill();
        c.strokeStyle = '#5a4630'; c.lineWidth = 0.25; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.stroke();
      }
    }
    // conveyor belts: dark rubber with rollers, hazard stripes at both ends
    for (const Bt of tr.belts) {
      const i0 = Math.round(Bt.a * NS), i1 = Math.round(Bt.b * NS), mid = (Bt.l0 + Bt.l1) / 2, w2 = Bt.l1 - Bt.l0;
      c.lineCap = 'butt';
      span(i0, i1, mid, w2 + 0.6, '#1c1d20'); span(i0, i1, mid, w2 - 0.3, '#34363c');
      c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 0.16;
      for (let i = i0; i <= i1; i++) { const j = i % NS; c.beginPath(); c.moveTo(tr.x[j] + tr.nx[j] * (Bt.l0 + 0.3), tr.y[j] + tr.ny[j] * (Bt.l0 + 0.3)); c.lineTo(tr.x[j] + tr.nx[j] * (Bt.l1 - 0.3), tr.y[j] + tr.ny[j] * (Bt.l1 - 0.3)); c.stroke(); }
      for (const ie of [i0, i1]) { const j = ie % NS; c.save(); c.translate(tr.x[j] + tr.nx[j] * mid, tr.y[j] + tr.ny[j] * mid); c.rotate(tr.hd[j]); c.beginPath(); c.rect(-0.7, -w2 / 2, 1.4, w2); c.clip(); c.fillStyle = '#f2c230'; c.fillRect(-0.7, -w2 / 2, 1.4, w2); c.fillStyle = '#1c1d20'; for (let k = -w2 / 2 - 2; k < w2 / 2 + 1; k += 1.4) { c.beginPath(); c.moveTo(-0.7, k); c.lineTo(-0.7, k + 0.7); c.lineTo(0.7, k + 1.4); c.lineTo(0.7, k + 0.7); c.fill(); } c.restore(); }
      for (const l of [Bt.l0, Bt.l1]) span(i0, i1, l, 0.28, '#9aa0a8');
      c.lineCap = 'round';
    }
    // gates: the stone-and-iron divider before each pair of gates, and the gate posts
    for (const d of tr.doors) {
      const ta = Math.cos(d.a), tb = Math.sin(d.a), nx0 = -tb, ny0 = ta;
      c.lineCap = 'butt';
      c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = DIV_W * 2 + 0.6; c.beginPath(); c.moveTo(d.x - ta * DOOR_DIV + 0.3, d.y - tb * DOOR_DIV + 0.5); c.lineTo(d.x + 0.3, d.y + 0.5); c.stroke();
      c.strokeStyle = '#5a5464'; c.lineWidth = DIV_W * 2; c.beginPath(); c.moveTo(d.x - ta * DOOR_DIV, d.y - tb * DOOR_DIV); c.lineTo(d.x, d.y); c.stroke();
      c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 0.12; for (let k = 1; k < DOOR_DIV; k += 1.6) { c.beginPath(); c.moveTo(d.x - ta * k + nx0 * DIV_W, d.y - tb * k + ny0 * DIV_W); c.lineTo(d.x - ta * k - nx0 * DIV_W, d.y - tb * k - ny0 * DIV_W); c.stroke(); }
      c.fillStyle = '#e3ae45'; c.beginPath(); c.arc(d.x - ta * DOOR_DIV, d.y - tb * DOOR_DIV, 0.75, 0, 7); c.fill(); // brass cap at the divider's nose
      for (const o of [-(half + (tr.wall || 0) * 0.5), 0, half + (tr.wall || 0) * 0.5]) { const px = d.x + nx0 * o, py = d.y + ny0 * o; c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(px - 0.8, py - 0.6, 1.8, 1.8); c.fillStyle = '#6d6878'; c.fillRect(px - 0.9, py - 0.9, 1.8, 1.8); c.fillStyle = '#8a8496'; c.fillRect(px - 0.6, py - 0.6, 1.2, 1.2); }
      c.lineCap = 'round';
    }
    // windmill towers beside the road (their sails turn live)
    for (const S of tr.sw) {
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(S.hx + 0.7, S.hy + 1, 3, 0, 7); c.fill();
      c.fillStyle = '#c9b8a0'; c.beginPath(); c.arc(S.hx, S.hy, 2.7, 0, 7); c.fill();
      c.strokeStyle = 'rgba(80,60,40,.35)'; c.lineWidth = 0.15; for (let r = 1; r < 2.7; r += 0.6) { c.beginPath(); c.arc(S.hx, S.hy, r, 0, 7); c.stroke(); }
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; c.fillStyle = k % 2 ? '#8f4a32' : '#a9583b'; c.beginPath(); c.moveTo(S.hx, S.hy); c.arc(S.hx, S.hy, 2.2, a, a + Math.PI / 4); c.fill(); }
    }
    /* ---- round 9 gimmick art (static parts; the moving bits are drawn live) ---- */
    // slipstream straights: rows of pale chevrons along both edges
    for (let i = 0; i < NS; i += 5) {
      if (!tr.slip[i]) continue;
      c.save(); c.translate(tr.x[i], tr.y[i]); c.rotate(tr.hd[i]); c.strokeStyle = 'rgba(190,235,255,.6)'; c.lineWidth = 0.42;
      for (const sd of [-1, 1]) for (const o of [0, 1.1]) { const y0 = sd * (half - 1.3); c.beginPath(); c.moveTo(o - 0.7, y0 - 0.9); c.lineTo(o + 0.3, y0); c.lineTo(o - 0.7, y0 + 0.9); c.stroke(); }
      c.restore();
    }
    // collapsing floor: carved stone slabs, three per row
    for (const S of tr.tiles) for (let r = 0; r < S.rows; r++) for (let q = 0; q < 3; q++) {
      tilePath(c, tr, S, r, q, 0.12); c.fillStyle = ['#8f7d63', '#9a876b', '#857358'][(r + q * 2) % 3]; c.fill();
      c.strokeStyle = 'rgba(40,28,16,.75)'; c.lineWidth = 0.28; c.stroke();
      tilePath(c, tr, S, r, q, 0.7); c.strokeStyle = 'rgba(255,240,210,.12)'; c.lineWidth = 0.2; c.stroke();
    }
    for (const S of tr.tiles) for (const r of [0, S.rows]) { const i = (S.i0 + Math.round((r * TILE_L) / tr.ds)) % NS; c.strokeStyle = '#e3ae45'; c.lineWidth = 0.35; c.setLineDash([0.8, 0.8]); c.beginPath(); c.moveTo(tr.x[i] - tr.nx[i] * half, tr.y[i] - tr.ny[i] * half); c.lineTo(tr.x[i] + tr.nx[i] * half, tr.y[i] + tr.ny[i] * half); c.stroke(); c.setLineDash([]); }
    // lava geyser vents
    for (const g of tr.gey) {
      const gr = c.createRadialGradient(g.x, g.y, 0.3, g.x, g.y, GEY_R + 1);
      gr.addColorStop(0, '#120806'); gr.addColorStop(0.5, '#3a1a10'); gr.addColorStop(0.78, 'rgba(255,120,40,.55)'); gr.addColorStop(1, 'rgba(255,120,40,0)');
      c.fillStyle = gr; c.beginPath(); c.arc(g.x, g.y, GEY_R + 1, 0, 7); c.fill();
      for (let k = 0; k < 9; k++) { const a = k * 0.7 + rnd(), r = GEY_R * (0.75 + rnd() * 0.25); blob(g.x + Math.cos(a) * r, g.y + Math.sin(a) * r, 0.35 + rnd() * 0.35, k % 2 ? '#2a1d1a' : '#4a3430'); }
    }
    // disco floor: dark glass tiles (lit live)
    for (const D2 of tr.disco) {
      const rows = Math.floor(((D2.i1 - D2.i0) * tr.ds) / DISCO_L), cw = (half * 2) / 3;
      for (let r = 0; r < rows; r++) for (let q = 0; q < 3; q++) { quadPath(c, tr, D2.i0, r * DISCO_L + 0.12, (r + 1) * DISCO_L - 0.12, -half + q * cw + 0.12, -half + (q + 1) * cw - 0.12); c.fillStyle = (r + q) % 2 ? '#241a3a' : '#1c1430'; c.fill(); c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 0.15; c.stroke(); }
    }
    // turntables: a stone clock face set into the road
    for (const q of tr.turn) {
      c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(q.x + 0.4, q.y + 0.6, q.R + 0.5, 0, 7); c.fill();
      c.fillStyle = '#8f8576'; c.beginPath(); c.arc(q.x, q.y, q.R + 0.5, 0, 7); c.fill();
      c.fillStyle = '#5a5560'; c.beginPath(); c.arc(q.x, q.y, q.R - 0.2, 0, 7); c.fill();
      c.strokeStyle = '#e3ae45'; c.lineWidth = 0.35; c.beginPath(); c.arc(q.x, q.y, q.R - 0.6, 0, 7); c.stroke();
      for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6, r0 = q.R - 1.6, r1 = q.R - 0.9; c.strokeStyle = k % 3 ? 'rgba(242,233,216,.55)' : '#f2e9d8'; c.lineWidth = k % 3 ? 0.25 : 0.5; c.beginPath(); c.moveTo(q.x + Math.cos(a) * r0, q.y + Math.sin(a) * r0); c.lineTo(q.x + Math.cos(a) * r1, q.y + Math.sin(a) * r1); c.stroke(); }
      c.strokeStyle = 'rgba(0,0,0,.25)'; c.lineWidth = 0.2; c.beginPath(); c.arc(q.x, q.y, q.R * 0.45, 0, 7); c.stroke();
    }
    // rally: mud bogs and water splashes
    for (const q of tr.bogs) {
      c.save(); c.translate(q.x, q.y); c.rotate(q.a);
      c.fillStyle = '#4a3420'; c.beginPath(); for (let k = 0; k < 18; k++) { const a = (k / 18) * Math.PI * 2, rr2 = 0.9 + rnd() * 0.12; c.lineTo(Math.cos(a) * q.lx * rr2, Math.sin(a) * q.ly * rr2); } c.closePath(); c.fill();
      c.fillStyle = '#5e4429'; c.beginPath(); c.ellipse(0, 0, q.lx * 0.78, q.ly * 0.7, 0, 0, 7); c.fill();
      c.strokeStyle = 'rgba(30,20,10,.55)'; c.lineWidth = 0.5; for (const l of [-q.ly * 0.45, -q.ly * 0.2, q.ly * 0.2, q.ly * 0.45]) { c.beginPath(); c.moveTo(-q.lx * 0.85, l); c.quadraticCurveTo(0, l + (rnd() - 0.5) * 0.8, q.lx * 0.85, l); c.stroke(); }
      for (let k = 0; k < 10; k++) { c.fillStyle = 'rgba(255,240,210,.18)'; c.beginPath(); c.ellipse((rnd() - 0.5) * q.lx * 1.3, (rnd() - 0.5) * q.ly * 1.2, 0.6 + rnd(), 0.25, 0, 0, 7); c.fill(); }
      c.restore();
    }
    for (const q of tr.wash) {
      const gr = c.createRadialGradient(q.x - q.r * 0.3, q.y - q.r * 0.3, 0.2, q.x, q.y, q.r);
      gr.addColorStop(0, '#9fd4e8'); gr.addColorStop(0.7, '#4f8fb0'); gr.addColorStop(1, '#3d6f88');
      c.fillStyle = 'rgba(60,40,20,.5)'; c.beginPath(); c.arc(q.x, q.y, q.r + 0.4, 0, 7); c.fill();
      c.fillStyle = gr; c.beginPath(); c.arc(q.x, q.y, q.r, 0, 7); c.fill();
      c.strokeStyle = 'rgba(255,255,255,.45)'; c.lineWidth = 0.18; for (const k of [0.4, 0.7]) { c.beginPath(); c.arc(q.x, q.y, q.r * k, 0, 7); c.stroke(); }
    }
    // magic doors: rune circles at the doors and their exits
    for (const P2 of tr.ports) for (const [px, py, big] of [[P2.x, P2.y, 1], [P2.ex, P2.ey, 0]]) {
      const r = big ? PORT_R + 0.6 : PORT_R - 0.2;
      c.strokeStyle = big ? 'rgba(180,140,240,.75)' : 'rgba(127,208,255,.7)'; c.lineWidth = 0.3; c.beginPath(); c.arc(px, py, r, 0, 7); c.stroke(); c.beginPath(); c.arc(px, py, r - 0.6, 0, 7); c.stroke();
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; c.fillStyle = big ? '#b48cf0' : '#7fd0ff'; c.fillRect(px + Math.cos(a) * (r - 0.3) - 0.15, py + Math.sin(a) * (r - 0.3) - 0.15, 0.3, 0.3); }
    }
    // electromagnet cranes: the base beside the road
    for (const m of tr.mag) {
      const o = m.side * (half + 5.5), bx = tr.x[m.i] + tr.nx[m.i] * o, by = tr.y[m.i] + tr.ny[m.i] * o;
      shadowE(bx + 0.8, by + 1, 3.4, 3.4, 0.35);
      c.fillStyle = '#e8a33d'; c.fillRect(bx - 2.6, by - 2.6, 5.2, 5.2); c.strokeStyle = '#7a4f12'; c.lineWidth = 0.3; c.strokeRect(bx - 2.6, by - 2.6, 5.2, 5.2);
      c.fillStyle = '#2b2d33'; c.beginPath(); c.arc(bx, by, 1.4, 0, 7); c.fill();
      c.strokeStyle = 'rgba(80,140,220,.35)'; c.lineWidth = 0.3; c.setLineDash([1, 1.2]); c.beginPath(); c.arc(m.x, m.y, MAG_R, 0, 7); c.stroke(); c.setLineDash([]);
    }
    // snowball chutes: a snow bank with a gap on the uphill side
    for (const B of tr.balls) {
      const o = B.side * (half + 4), bx = tr.x[B.i] + tr.nx[B.i] * o, by = tr.y[B.i] + tr.ny[B.i] * o;
      c.save(); c.translate(bx, by); c.rotate(tr.hd[B.i]);
      c.fillStyle = 'rgba(120,150,190,.35)'; c.fillRect(-4, -2.2 * B.side - 1.4, 8, 2.8);
      c.fillStyle = '#ffffff'; for (const ax of [-5.4, 5.4]) { c.beginPath(); c.arc(ax, 0, 2, 0, 7); c.fill(); }
      c.restore();
    }
    // the tidal sandbar: wet sand ripples and bamboo marker poles along both sides
    for (const C of tr.cuts) if (C.tide) {
      c.strokeStyle = 'rgba(120,95,60,.35)'; c.lineWidth = 0.22;
      for (let k = 2; k < C.n - 2; k += 2) { const dx = C.sx[k + 1] - C.sx[k - 1], dy = C.sy[k + 1] - C.sy[k - 1], l = Math.hypot(dx, dy) || 1, px = -dy / l, py = dx / l, o = (rnd() * 2 - 1) * (C.hw - 1.5); c.beginPath(); c.moveTo(C.sx[k] + px * (o - 1.2), C.sy[k] + py * (o - 1.2)); c.quadraticCurveTo(C.sx[k] + px * o + dx / l * 0.5, C.sy[k] + py * o + dy / l * 0.5, C.sx[k] + px * (o + 1.2), C.sy[k] + py * (o + 1.2)); c.stroke(); }
      for (let k = 3; k < C.n - 3; k += 7) for (const sd of [-1, 1]) { const dx = C.sx[k + 1] - C.sx[k - 1], dy = C.sy[k + 1] - C.sy[k - 1], l = Math.hypot(dx, dy) || 1, px = C.sx[k] - dy / l * (C.hw + 0.9) * sd, py = C.sy[k] + dx / l * (C.hw + 0.9) * sd; c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.arc(px + 0.25, py + 0.35, 0.45, 0, 7); c.fill(); c.fillStyle = k % 14 === 3 ? '#e8384f' : '#d8c08a'; c.beginPath(); c.arc(px, py, 0.4, 0, 7); c.fill(); }
    }
    // crane rails across the road (the containers themselves move, drawn live)
    for (const m of tr.mov) {
      if (m.ball) continue;
      c.strokeStyle = 'rgba(255,209,102,.55)'; c.lineWidth = 0.45; c.setLineDash([1.6, 1.2]);
      for (const o of [-m.hx - 0.6, m.hx + 0.6]) { const cx2 = m.x + tr.tx[m.i] * o, cy2 = m.y + tr.ty[m.i] * o; c.beginPath(); c.moveTo(cx2 - tr.nx[m.i] * (half + 3), cy2 - tr.ny[m.i] * (half + 3)); c.lineTo(cx2 + tr.nx[m.i] * (half + 3), cy2 + tr.ny[m.i] * (half + 3)); c.stroke(); }
      c.setLineDash([]);
    }
    art12();
    // pads, ramps
    for (const p of tr.pads) {
      c.save(); c.translate(p.x, p.y); c.rotate(p.a);
      c.fillStyle = 'rgba(227,174,69,.25)'; rr(c, -3.2, -2.7, 6.4, 5.4, 1); c.fill();
      c.strokeStyle = '#e3ae45'; c.lineWidth = 0.55;
      for (let k = -1; k <= 1; k++) { c.beginPath(); c.moveTo(k * 1.8 - 0.8, -1.7); c.lineTo(k * 1.8 + 0.6, 0); c.lineTo(k * 1.8 - 0.8, 1.7); c.stroke(); }
      c.restore();
    }
    for (const p of tr.ramps) {
      c.save(); c.translate(p.x, p.y); c.rotate(p.a);
      const g = c.createLinearGradient(-2.4, 0, 1.6, 0); g.addColorStop(0, '#6b4524'); g.addColorStop(1, '#c08a52');
      c.fillStyle = g; c.fillRect(-2.4, -half + 0.4, 4, half * 2 - 0.8);
      c.fillStyle = '#ffd166'; for (let k = -half + 1; k < half - 1; k += 2.4) c.fillRect(1.2, k, 0.5, 1.2);
      c.restore();
    }
    for (const p of tr.springs) { // spring pads in front of the gaps
      c.save(); c.translate(p.x, p.y); c.rotate(p.a);
      c.fillStyle = '#2b2533'; rr(c, -1.8, -half + 0.5, 3.6, half * 2 - 1, 0.6); c.fill();
      for (let k = -half + 0.5; k < half - 0.5; k += 1.2) { c.fillStyle = Math.round(k / 1.2) % 2 ? '#e8c04e' : '#2b2533'; c.fillRect(-1.8, k, 0.6, 1.2); c.fillRect(1.2, k, 0.6, 1.2); }
      c.strokeStyle = '#c9ccd2'; c.lineWidth = 0.35;
      for (const l of [-half * 0.5, 0, half * 0.5]) { c.beginPath(); for (let k = 0; k <= 8; k++) c.lineTo(-1 + k * 0.25, l + (k % 2 ? 0.9 : -0.9)); c.stroke(); }
      c.fillStyle = '#e8c04e'; c.beginPath(); c.moveTo(2.4, -1.2); c.lineTo(3.6, 0); c.lineTo(2.4, 1.2); c.fill();
      c.restore();
    }
    // grid boxes + start line
    c.strokeStyle = 'rgba(240,235,225,.7)'; c.lineWidth = 0.3; c.lineCap = 'butt';
    const gw = Math.min(1.6, tr.half * 0.21 - 0.2); // lane boxes side by side on the one start line
    for (let k = 0; k < LANES; k++) { const g2 = gridSlot(tr, k); c.save(); c.translate(g2.x, g2.y); c.rotate(g2.a); c.strokeRect(-2.8, -gw, 5.8, gw * 2); c.restore(); }
    c.save(); c.translate(tr.x[0], tr.y[0]); c.rotate(tr.hd[0]);
    const cells = 8, cs = (half * 2) / cells;
    for (let r = 0; r < 2; r++) for (let k = 0; k < cells; k++) { c.fillStyle = (r + k) % 2 ? '#141018' : '#f2ede4'; c.fillRect(-cs + r * cs, -half + k * cs, cs + 0.02, cs + 0.02); }
    c.restore();
    // scenery
    const trees = { forest: 260, snow: 150, beach: 40, plum: 70, jungle: 300, blossom: 170, rail: 60, windmill: 45, aurora: 70, tunnel: 300, prairie: 30, rally: 160, scrap: 10,
      ranch: 50, river: 110, season: 190, gorge: 200, ski: 140, icelake: 90, fest: 40, bridge: 40 }[D.th] || 0;
    for (let i = 0; i < trees; i++) {
      const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]);
      if (nearTrack(px, py, half + 6) || inXing(px, py, 3)) continue;
      if (tr.rivers.some((R) => segDist(R.pts, px, py) < R.w + 3)) continue;
      if (D.th === 'icelake' && inPoly(px, py)) continue; // not on the lake
      if (D.water && D.th !== 'icelake') { // palms only on sand
        if (inPoly(px, py)) continue;
        c.fillStyle = 'rgba(0,0,0,.18)'; c.beginPath(); c.ellipse(px + 1.5, py + 1.5, 4, 2.5, 0.5, 0, 7); c.fill();
        c.strokeStyle = '#3f8f45'; c.lineWidth = 1.1;
        for (let k = 0; k < 6; k++) { const a = k * 1.05 + rnd(); c.beginPath(); c.moveTo(px, py); c.quadraticCurveTo(px + Math.cos(a) * 2.5, py + Math.sin(a) * 2.5 - 1, px + Math.cos(a) * 4.5, py + Math.sin(a) * 4.5); c.stroke(); }
        c.fillStyle = '#7a5a30'; c.beginPath(); c.arc(px, py, 0.8, 0, 7); c.fill();
        continue;
      }
      const r = D.th === 'forest' || D.th === 'jungle' ? 3 + rnd() * 4 : 2.2 + rnd() * 2.5;
      c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(px + r * 0.35, py + r * 0.45, r, 0, 7); c.fill();
      if (D.th === 'tunnel') { // dark mountain pines
        c.fillStyle = rnd() < 0.5 ? '#24402c' : '#2d4f33'; c.beginPath(); for (let k = 0; k < 10; k++) { const a = k * Math.PI / 5, rr2 = k % 2 ? r * 0.5 : r; c.lineTo(px + Math.cos(a) * rr2, py + Math.sin(a) * rr2); } c.fill();
        c.fillStyle = 'rgba(160,200,140,.18)'; c.beginPath(); c.arc(px - r * 0.2, py - r * 0.2, r * 0.3, 0, 7); c.fill();
      } else if (D.th === 'snow' || D.th === 'aurora' || D.th === 'ski' || D.th === 'icelake') {
        c.fillStyle = '#2f5a45'; c.beginPath(); for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4, rr2 = k % 2 ? r * 0.55 : r; c.lineTo(px + Math.cos(a) * rr2, py + Math.sin(a) * rr2); } c.fill();
        c.fillStyle = 'rgba(255,255,255,.8)'; c.beginPath(); c.arc(px - r * 0.2, py - r * 0.2, r * 0.35, 0, 7); c.fill();
      } else if (D.th === 'blossom' || (D.th === 'season' && rnd() < 0.5)) { // cherry trees in bloom
        c.fillStyle = rnd() < 0.5 ? '#f4a6c6' : '#f9c4da'; c.beginPath(); for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3 + rnd() * 0.4; c.arc(px + Math.cos(a) * r * 0.45, py + Math.sin(a) * r * 0.45, r * 0.6, 0, 7); } c.fill();
        c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.arc(px - r * 0.25, py - r * 0.3, r * 0.4, 0, 7); c.fill();
        c.fillStyle = '#7a4a3a'; c.beginPath(); c.arc(px, py, r * 0.15, 0, 7); c.fill();
      } else if (D.th === 'jungle') { // broad-leaf canopy
        c.fillStyle = rnd() < 0.5 ? '#1f5a2a' : '#2c6b2e';
        c.beginPath(); for (let k = 0; k < 7; k++) { const a = k * Math.PI * 2 / 7 + rnd() * 0.3; c.moveTo(px, py); c.quadraticCurveTo(px + Math.cos(a - 0.4) * r, py + Math.sin(a - 0.4) * r, px + Math.cos(a) * r * 1.3, py + Math.sin(a) * r * 1.3); c.quadraticCurveTo(px + Math.cos(a + 0.4) * r, py + Math.sin(a + 0.4) * r, px, py); } c.fill();
        c.fillStyle = 'rgba(190,230,120,.2)'; c.beginPath(); c.arc(px - r * 0.2, py - r * 0.2, r * 0.4, 0, 7); c.fill();
      } else {
        c.fillStyle = D.th === 'forest' ? (rnd() < 0.5 ? '#2c5a2a' : '#3a6b2c') : '#2f5b30'; c.beginPath(); c.arc(px, py, r, 0, 7); c.fill();
        c.fillStyle = 'rgba(180,220,120,.18)'; c.beginPath(); c.arc(px - r * 0.3, py - r * 0.3, r * 0.5, 0, 7); c.fill();
      }
    }
    // themed props off the course
    const props = (n, m, f) => { for (let i = 0, k = 0; i < n * 6 && k < n; i++) { const px = B[0] + rnd() * (B[2] - B[0]), py = B[1] + rnd() * (B[3] - B[1]); if (nearTrack(px, py, half + m) || inXing(px, py, m)) continue; if (D.water && D.water.inside && inPoly(px, py) && D.th !== 'volcano') continue; if (D.water && !D.water.inside && !inPoly(px, py)) continue; if (tr.rivers.some((R) => segDist(R.pts, px, py) < R.w + m)) continue; f(px, py); k++; } };
    if (D.th === 'volcano') {
      props(40, 5, (px, py) => { const r = 1.5 + rnd() * 3; c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.arc(px + 0.6, py + 0.8, r, 0, 7); c.fill(); c.fillStyle = '#4a3a36'; c.beginPath(); for (let k = 0; k < 7; k++) { const a = k * 0.9, q = r * (0.7 + rnd() * 0.3); c.lineTo(px + Math.cos(a) * q, py + Math.sin(a) * q); } c.fill(); c.fillStyle = 'rgba(255,255,255,.08)'; c.beginPath(); c.arc(px - r * 0.3, py - r * 0.3, r * 0.4, 0, 7); c.fill(); });
      // the crater: a glowing vent in the lava lake
      const cx2 = (B[0] + B[2]) / 2 - 10, cy2 = (B[1] + B[3]) / 2 + 30, g = c.createRadialGradient(cx2, cy2, 1, cx2, cy2, 22);
      g.addColorStop(0, 'rgba(255,240,170,.9)'); g.addColorStop(0.4, 'rgba(255,140,40,.5)'); g.addColorStop(1, 'rgba(255,80,20,0)');
      c.fillStyle = g; c.beginPath(); c.arc(cx2, cy2, 22, 0, 7); c.fill();
    } else if (D.th === 'jungle') { // waterfall where the river enters
      const R = tr.rivers[0], q = R.pts[0], q1 = R.pts[1];
      if (q && q1) {
        const ang = Math.atan2(q1[1] - q[1], q1[0] - q[0]);
        c.save(); c.translate(q[0] + 18 * Math.cos(ang), q[1] + 18 * Math.sin(ang)); c.rotate(ang);
        c.fillStyle = '#5a5048'; c.fillRect(-10, -R.w - 4, 6, R.w * 2 + 8);
        for (let k = 0; k < 30; k++) { c.fillStyle = 'rgba(230,250,255,' + (0.3 + rnd() * 0.5) + ')'; c.fillRect(-4 + rnd() * 3, -R.w + rnd() * R.w * 2, 2 + rnd() * 3, 0.5); }
        for (let k = 0; k < 16; k++) { c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.arc(rnd() * 6, -R.w + rnd() * R.w * 2, 0.6 + rnd() * 1.2, 0, 7); c.fill(); }
        c.restore();
      }
    } else if (D.th === 'space') {
      props(14, 8, (px, py) => { c.save(); c.translate(px, py); c.rotate(rnd() * 3); c.fillStyle = '#2d3242'; c.fillRect(-5, -1.5, 10, 3); c.fillStyle = '#3d5a8a'; c.fillRect(-9, -3, 4, 6); c.fillRect(5, -3, 4, 6); c.strokeStyle = 'rgba(160,220,255,.5)'; c.lineWidth = 0.2; for (let k = -8; k <= 8; k += 1.3) { if (Math.abs(k) < 5) continue; c.beginPath(); c.moveTo(k, -3); c.lineTo(k, 3); c.stroke(); } c.fillStyle = '#ff5fb4'; c.beginPath(); c.arc(0, 0, 0.6, 0, 7); c.fill(); c.restore(); });
    } else if (D.th === 'park') {
      props(30, 4, (px, py) => { const r = rnd(); if (r < 0.4) { const rr2 = 2 + rnd() * 2; c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.arc(px + 0.5, py + 0.6, rr2, 0, 7); c.fill(); c.fillStyle = '#2f6b37'; c.beginPath(); c.arc(px, py, rr2, 0, 7); c.fill(); } else if (r < 0.75) { const cols = ['#ee6a55', '#5bb3e6', '#e8c04e', '#b48cf0']; c.fillStyle = cols[Math.floor(rnd() * 4)]; c.beginPath(); c.arc(px, py, 1.1, 0, 7); c.fill(); c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 0.15; c.beginPath(); c.moveTo(px, py + 1.1); c.lineTo(px, py + 3); c.stroke(); } else { c.fillStyle = '#f2e9d8'; c.fillRect(px - 2, py - 1.5, 4, 3); c.fillStyle = '#ee6a55'; for (let k = 0; k < 4; k++) c.fillRect(px - 2 + k, py - 1.5, 0.5, 3); } });
      props(2, 18, (px, py) => { // carousel / ferris wheel seen from above
        c.fillStyle = 'rgba(0,0,0,.25)'; c.beginPath(); c.arc(px + 1, py + 1.4, 11, 0, 7); c.fill();
        for (let k = 0; k < 12; k++) { c.fillStyle = k % 2 ? '#ee6a55' : '#f2e9d8'; c.beginPath(); c.moveTo(px, py); c.arc(px, py, 10, k * Math.PI / 6, (k + 1) * Math.PI / 6); c.fill(); }
        c.fillStyle = '#e3ae45'; c.beginPath(); c.arc(px, py, 2, 0, 7); c.fill();
      });
    } else if (D.th === 'storm') { // dunes, cacti, a bleached skull
      for (let i = 0; i < 80; i++) { c.strokeStyle = 'rgba(140,95,40,.3)'; c.lineWidth = 0.6; const x0 = B[0] + rnd() * (B[2] - B[0]), y0 = B[1] + rnd() * (B[3] - B[1]); c.beginPath(); c.moveTo(x0, y0); c.quadraticCurveTo(x0 + 7, y0 - 3, x0 + 14, y0); c.stroke(); }
      props(26, 5, (px, py) => { c.fillStyle = 'rgba(0,0,0,.2)'; c.beginPath(); c.ellipse(px + 0.8, py + 1, 1.6, 1, 0.4, 0, 7); c.fill(); c.fillStyle = '#4f7a3a'; c.beginPath(); c.arc(px, py, 1.4, 0, 7); c.fill(); c.strokeStyle = '#4f7a3a'; c.lineWidth = 0.9; c.beginPath(); c.moveTo(px - 2.4, py - 1); c.lineTo(px - 2.4, py + 0.3); c.lineTo(px, py + 0.3); c.moveTo(px + 2.2, py - 1.4); c.lineTo(px + 2.2, py - 0.2); c.lineTo(px, py - 0.2); c.stroke(); c.fillStyle = '#ffd1e0'; c.beginPath(); c.arc(px, py - 0.2, 0.35, 0, 7); c.fill(); });
    } else if (D.th === 'rail') { // a little station and signal posts by the line
      const Tn = tr.trains[0];
      if (Tn) for (const sv of [Tn.L * 0.18, Tn.L * 0.86]) {
        const px = Tn.ax + Tn.ux * sv + Tn.nx * 9, py = Tn.ay + Tn.uy * sv + Tn.ny * 9;
        if (nearTrack(px, py, half + 8)) continue;
        c.save(); c.translate(px, py); c.rotate(Math.atan2(Tn.uy, Tn.ux));
        c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(-7, -3, 15, 7); c.fillStyle = '#b5523b'; c.fillRect(-7.5, -3.5, 15, 7); c.fillStyle = '#7a2e22'; c.fillRect(-7.5, -0.3, 15, 0.6);
        c.fillStyle = '#d8d0c2'; c.fillRect(-9, -5.4, 18, 1.4); c.restore();
      }
    } else if (D.th === 'candy') {
      props(10, 6, (px, py) => { c.fillStyle = 'rgba(0,0,0,.18)'; c.beginPath(); c.arc(px + 0.6, py + 0.8, 3, 0, 7); c.fill(); for (let k = 0; k < 8; k++) { c.fillStyle = k % 2 ? '#ffffff' : '#ee6a55'; c.beginPath(); c.moveTo(px, py); c.arc(px, py, 3, k * Math.PI / 4, (k + 1) * Math.PI / 4); c.fill(); } });
    } else if (D.th === 'harbor') {
      const cols = ['#c0392b', '#2e86c1', '#e8a33d', '#27ae60', '#8e44ad', '#d35400'];
      props(28, 5, (px, py) => { const vert = rnd() < 0.5, w2 = vert ? 2.4 : 6, h2 = vert ? 6 : 2.4, col = cols[Math.floor(rnd() * cols.length)]; c.fillStyle = 'rgba(0,0,0,.3)'; c.fillRect(px - w2 / 2 + 0.6, py - h2 / 2 + 0.8, w2, h2); c.fillStyle = col; c.fillRect(px - w2 / 2, py - h2 / 2, w2, h2); c.strokeStyle = 'rgba(0,0,0,.3)'; c.lineWidth = 0.15; for (let k = 0.6; k < Math.max(w2, h2); k += 0.6) { c.beginPath(); if (vert) { c.moveTo(px - w2 / 2, py - h2 / 2 + k); c.lineTo(px + w2 / 2, py - h2 / 2 + k); } else { c.moveTo(px - w2 / 2 + k, py - h2 / 2); c.lineTo(px - w2 / 2 + k, py + h2 / 2); } c.stroke(); } });
      // a moored ship in the outer water
      c.save(); c.translate(B[0] + 14, (B[1] + B[3]) / 2); c.rotate(Math.PI / 2);
      c.fillStyle = '#2b2d33'; c.beginPath(); c.moveTo(-30, -6); c.lineTo(24, -6); c.lineTo(32, 0); c.lineTo(24, 6); c.lineTo(-30, 6); c.closePath(); c.fill();
      for (let k = -26; k < 18; k += 6.5) { c.fillStyle = cols[Math.floor(rnd() * cols.length)]; c.fillRect(k, -4.5, 6, 9); }
      c.restore();
    }
    themeProps(D.th);
    props12(props);
    // crane gantries over the moving containers' rails
    for (const m of tr.mov) {
      if (m.ball || D.th === 'factory') continue;
      for (const sd of [-1, 1]) { const o = half + 4.5, px = m.x + tr.nx[m.i] * o * sd, py = m.y + tr.ny[m.i] * o * sd; c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(px - 1.3, py - 1.3, 3.2, 3.2); c.fillStyle = '#e8a33d'; c.fillRect(px - 1.6, py - 1.6, 3.2, 3.2); c.strokeStyle = '#7a4f12'; c.lineWidth = 0.3; c.strokeRect(px - 1.6, py - 1.6, 3.2, 3.2); }
    }
    // soft outer edge fading into what lies beyond the map
    const bg = beyond(tr, th), eg = (x0, y0, x1, y1) => { const g = c.createLinearGradient(x0, y0, x1, y1); g.addColorStop(0, bg); g.addColorStop(1, bg + '00'); return g; };
    c.fillStyle = eg(B[0], 0, B[0] + 8, 0); c.fillRect(B[0], B[1], 8, B[3] - B[1]);
    c.fillStyle = eg(B[2], 0, B[2] - 8, 0); c.fillRect(B[2] - 8, B[1], 8, B[3] - B[1]);
    c.fillStyle = eg(0, B[1], 0, B[1] + 8); c.fillRect(B[0], B[1], B[2] - B[0], 8);
    c.fillStyle = eg(0, B[3], 0, B[3] - 8); c.fillRect(B[0], B[3] - 8, B[2] - B[0], 8);
    return { cv, bs };
  }

  /* ---------- view ---------- */
  const CSS = `
.rc-pick{position:absolute;left:0;right:0;bottom:0;z-index:8;padding:12px 12px calc(12px + env(safe-area-inset-bottom));background:linear-gradient(180deg,rgba(23,19,31,0),rgba(23,19,31,.94) 18%);display:flex;flex-direction:column;gap:8px;user-select:none;-webkit-user-select:none}
.rc-pick h3{margin:0;font-family:var(--f-display,"Black Han Sans"),sans-serif;font-weight:400;font-size:22px;color:var(--ink,#f2e9d8)}
.rc-st{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:9;width:min(420px,calc(100% - 32px));max-height:calc(100% - 32px);overflow-y:auto;box-sizing:border-box;padding:14px;border-radius:14px;background:rgba(23,19,31,.94);border:1px solid rgba(227,174,69,.45);color:var(--ink,#f2e9d8);display:flex;flex-direction:column;gap:6px;user-select:none;-webkit-user-select:none}
.rc-st h3{margin:0;font-family:var(--f-display,"Black Han Sans"),sans-serif;font-weight:400;font-size:21px;text-align:center}
.rc-st .sub{font-size:12px;color:var(--muted,#ab9fb8);text-align:center}
.rc-st .row{display:grid;grid-template-columns:26px 30px 12px 1fr auto 44px;align-items:center;gap:6px;font-size:14px;padding:6px 4px;border-radius:8px;background:rgba(255,255,255,.05)}
.rc-st .row.me{background:rgba(227,174,69,.16)}
.rc-st .rk{font-weight:700;text-align:center}.rc-st .mv{font-size:11px;text-align:center}.rc-st .up{color:#5fd3a0}.rc-st .dn{color:#ee6a55}.rc-st .eq{color:var(--muted,#ab9fb8)}
.rc-st .dot{width:12px;height:12px;border-radius:50%}.rc-st .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.rc-st .gain{font-size:12px;color:var(--muted,#ab9fb8);white-space:nowrap}.rc-st .tot{font-weight:700;text-align:right;color:var(--brass,#e3ae45)}
.rc-st button{min-height:44px;border-radius:10px;border:0;background:var(--brass,#e3ae45);color:#17131f;font-size:16px;font-weight:700;margin-top:4px}
.rc-pick .sub{font-size:12px;color:var(--muted,#ab9fb8);min-height:16px}
.rc-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:5px;max-height:clamp(150px,27vh,250px);overflow-y:auto;touch-action:pan-y;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;padding:1px 2px 1px 0;scrollbar-width:thin;scrollbar-color:rgba(227,174,69,.5) transparent;-webkit-mask-image:linear-gradient(180deg,#000 calc(100% - 14px),rgba(0,0,0,.35));mask-image:linear-gradient(180deg,#000 calc(100% - 14px),rgba(0,0,0,.35))}
.rc-tk{appearance:none;border:1.5px solid rgba(242,233,216,.14);background:rgba(46,38,64,.92);color:var(--ink,#f2e9d8);border-radius:12px;padding:4px 2px 5px;display:flex;flex-direction:column;align-items:center;gap:2px;font-weight:700;font-size:10.5px;line-height:1.15;min-height:64px;cursor:pointer;touch-action:manipulation;word-break:keep-all;text-align:center}
.rc-tk:active{transform:scale(.96)}
.rc-tk canvas{width:44px;height:38px;display:block}
.rc-tk.on{border-color:var(--brass,#e3ae45);background:rgba(227,174,69,.2)}
.rc-tk:disabled{opacity:.85;cursor:default}
.rc-ctl{display:flex;align-items:center;gap:6px;flex-wrap:nowrap;overflow-x:auto;font-size:12px;color:var(--muted,#ab9fb8)}
.rc-ctl .lb{font-weight:700;margin-right:2px}
.rc-ctl .seg button{min-height:36px;padding:6px 10px}
.rc-ctl .tg{appearance:none;flex:none;white-space:nowrap;min-height:36px;padding:6px 10px;border-radius:10px;border:1px solid rgba(242,233,216,.18);background:transparent;color:var(--muted,#ab9fb8);font-weight:700;font-size:13px;cursor:pointer}
.rc-ctl .tg.on{background:var(--coral,#ee6a55);border-color:var(--coral,#ee6a55);color:#17131f}
.rc-grid[hidden],.rc-set[hidden]{display:none}
.rc-set{display:flex;flex-direction:column;gap:2px;max-height:clamp(150px,27vh,250px);overflow-y:auto}
.rc-sl{display:grid;grid-template-columns:52px 1fr 52px;align-items:center;column-gap:8px;font-size:13px;color:var(--ink,#f2e9d8)}
.rc-sl .nm{font-weight:700}
.rc-sl input{width:100%;height:36px;accent-color:var(--brass,#e3ae45)}
.rc-sl b{color:var(--brass,#e3ae45);font-size:11px;letter-spacing:1px;white-space:nowrap}
.rc-sl .tp{grid-column:1/-1;font-size:11px;color:var(--muted,#ab9fb8);margin:-6px 0 2px}
.rc-tk .q{font-family:var(--f-display,"Black Han Sans"),sans-serif;font-size:24px;height:38px;display:grid;place-items:center;color:var(--brass,#e3ae45)}
`;
  const CODE_ITEM = ['', 'turbo', 'turbo3', 'oil', 'rocket', 'homing', 'shield', 'cloud', 'magnet', 'spring', 'smoke', 'warp', 'frost', 'mirror', 'giant', 'boom', 'tacks', 'shock', 'net', 'steal', 'ghost', 'hop', 'tire',
    'balloon', 'auto', 'fw', 'paint', 'wall', 'vort', 'bomb', 'foam', 'drone', 'blow', 'rear', 'bees'];
  const ITEM_CODE = {}; CODE_ITEM.forEach((k, i) => { if (k) ITEM_CODE[k] = i; });
  const CODE_HZ = ['', 'oil', 'rocket', 'homing', 'cloud', 'spring', 'smoke', 'frost', 'boom', 'tacks', 'net', 'shock', 'grab', 'fw', 'paint', 'cball', 'bees', 'bomb', 'wall', 'vort', 'foam', 'blow', 'pass'];
  const HZ_CODE = {}; CODE_HZ.forEach((k, i) => { if (k) HZ_CODE[k] = i; });
  const FLY = { rocket: 1, homing: 1, boom: 1, net: 1, fw: 1, paint: 1, cball: 1, bees: 1, bomb: 1 };

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root);
    const ctx = cv.ctx;
    let st = null, tr = null, key = null, W = null, art = null, mini = null;
    let phase = 'wait', cd = 0, goT = 0, hostT = 0, pubT = 0, autoT = 0;
    let firstHumanFin = null, firstFin = null, doneSent = false, bumpT = 0, wallT = 0, shake = 0, kaboom = 0, boomFlash = 0, humOutT = null, lowWarn = false;
    let parts = [], floats = [], skids = [], bursts = [];
    let cam = { x: 0, y: 0, a: -Math.PI / 2, sc: 6, ok: false }, punch = 0, lines = [];
    let pick = null, eatenOut = {}, frameNo = 0, lastHint = '';
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (seat) => api.players[seat] || { name: '?', color: '#888', ai: true };
    function controlledHere(seat) {
      const p = api.players[seat];
      if (!p) return false;
      if (!api.online) return true;
      if (api.isHost) return !!p.ai || !!p.local;
      return !p.ai && !!p.local;
    }
    const isLocalHuman = (seat) => { const p = api.players[seat]; return !!p && !p.ai && !!p.local; };
    const mySeat = () => { const m = api.mySeats(); return m.length ? m[0] : -1; };
    const me = () => (W && mySeat() >= 0 ? W.cars[mySeat()] : null);

    /* ----- controls (drawn on the canvas) -----
       Press-and-hold, no dragging needed. The steering wheel on screen is only a picture of the current steering.
       양손: lower screen split in two — hold the left half to steer left, the right half to steer right
             (sliding across the middle switches). 「드리프트」 pads in both upper corners of that area (use whichever
             thumb is free), 「아이템」 pad in the middle.
       한 손 (오른/왼): one cluster on that thumb's side — ◀ ▶ buttons at the bottom, a drift bar above them
             (◀ part = drift left, middle = drift straight / brake, ▶ part = drift right; slide up from an arrow
             onto the bar to start a drift that way), item pad on top. */
    const input = { steer: 0, steerOut: 0, dir: 0, drift: false, use: false, startTap: null };
    const VIS_LOCK = 1.75; // drawn wheel angle at full steering (≈100°)
    const wheel = { x: 0, y: 0, r: 48, vis: 0 };
    const zones = []; // {k: 'L'|'R'|'DL'|'DM'|'DR'|'D'|'I', x, y, w, h} (rects) or {k, x, y, r} (circles)
    const ptrs = new Map(); // pointerId -> zone key it is on now
    let itemFlash = 0, itemPad = null;
    const CFG_KEY = 'racing.ctl';
    const cfg = Object.assign({ hand: 'two', auto: false, setup: [2, 2, 2] }, U.store.get(CFG_KEY, null) || {});
    if (!okSetup(cfg.setup)) cfg.setup = [2, 2, 2];
    if (!['two', 'r', 'l'].includes(cfg.hand)) cfg.hand = 'two';
    cfg.auto = !!cfg.auto;
    const oneHand = () => cfg.hand !== 'two';
    const auto = { on: false, t: 0, off: 0, dir: 0 };
    let ctlOn = false, ctlTop = 0, chargeLvl = 0, bandTop = 0;
    function layoutControls() {
      const w = cv.w, h = cv.h, kc = (L.ui && L.ui.ctlScale ? +L.ui.ctlScale() : 1) || 1, pr = Math.round(Math.max(22, 29 * kc));
      zones.length = 0;
      if (!oneHand()) {
        const band = Math.round(Math.min(h * 0.44, U.clamp(h * 0.26, 165, 210) * Math.max(0.85, kc)));
        bandTop = h - band;
        // pads first: they win over the steering halves they sit on
        zones.push({ k: 'D', x: 12 + pr, y: bandTop + 12 + pr, r: pr });
        zones.push({ k: 'D', x: w - 12 - pr, y: bandTop + 12 + pr, r: pr });
        zones.push(itemPad = { k: 'I', x: w / 2, y: bandTop + 12 + pr, r: pr });
        zones.push({ k: 'L', x: 0, y: bandTop, w: w / 2, h: band });
        zones.push({ k: 'R', x: w / 2, y: bandTop, w: w - w / 2, h: band });
        const free = h - (itemPad.y + pr) - 10; // below the item pad: wheel + its travel arc
        wheel.r = Math.round(U.clamp((free - 16) / 2 - 8, 24, 52 * kc));
        wheel.x = w / 2; wheel.y = h - wheel.r - 8;
        ctlTop = bandTop - 22; // 22: item name tag
      } else {
        const cw = Math.round(Math.min(w * (kc > 1 ? 0.74 : 0.68), 264 * kc)), x0 = cfg.hand === 'r' ? w - 12 - cw : 12;
        const ah = Math.round(Math.min(h * 0.2, U.clamp(h * 0.13, 84, 108) * Math.max(0.8, kc))), ay = h - 12 - ah;
        const bh = Math.round(Math.max(48, 58 * kc)), by = ay - 8 - bh, third = cw / 3;
        zones.push(itemPad = { k: 'I', x: x0 + cw / 2, y: by - 8 - pr, r: pr });
        zones.push({ k: 'L', x: x0, y: ay, w: cw / 2 - 4, h: ah });
        zones.push({ k: 'R', x: x0 + cw / 2 + 4, y: ay, w: cw / 2 - 4, h: ah });
        zones.push({ k: 'DL', x: x0, y: by, w: third, h: bh });
        zones.push({ k: 'DM', x: x0 + third, y: by, w: third, h: bh });
        zones.push({ k: 'DR', x: x0 + 2 * third, y: by, w: cw - 2 * third, h: bh });
        bandTop = by;
        const free = w - cw - 36;
        wheel.r = Math.round(U.clamp(free / 2 - 2, 24, 50 * kc));
        wheel.x = cfg.hand === 'r' ? 12 + wheel.r + 4 : w - 12 - wheel.r - 4; wheel.y = h - wheel.r - 18;
        ctlTop = itemPad.y - pr - 22;
      }
    }
    function setCfg(patch) {
      Object.assign(cfg, patch);
      U.store.set(CFG_KEY, { hand: cfg.hand, auto: cfg.auto, setup: cfg.setup });
      releaseAll(); layoutControls(); cam.ok = false;
    }
    const SLOP = 10; // a little extra touch margin around pads and buttons
    function zoneAt(p) {
      for (const z of zones) {
        if (z.r != null) { if ((p.x - z.x) ** 2 + (p.y - z.y) ** 2 < (z.r + SLOP) ** 2) return z.k; }
        else {
          const st2 = z.k === 'L' || z.k === 'R', sx = st2 ? 5 : 0; // ◀ ▶ meet in the middle; they also reach past the bottom edge
          if (p.x >= z.x - sx && p.x < z.x + z.w + sx && p.y >= z.y - (st2 && oneHand() ? 4 : 0) && p.y < z.y + z.h + (st2 ? 40 : 0)) return z.k;
        }
      }
      return null;
    }
    const isSteerZone = (k) => k === 'L' || k === 'R' || k === 'DL' || k === 'DM' || k === 'DR';
    function refresh() {
      // touch zones + keyboard / gamepad (api.input, rebindable in 「조작 설정」; a stick steers in proportion)
      const pad = ctlOn && api.input ? api.input : null;
      let l = false, r = false, d = auto.on || (!!pad && pad.held('drift'));
      for (const k of ptrs.values()) {
        if (k === 'L' || k === 'DL') l = true;
        if (k === 'R' || k === 'DR') r = true;
        if (k === 'D' || k === 'DL' || k === 'DM' || k === 'DR') d = true;
      }
      input.dir = l || r ? (r ? 1 : 0) - (l ? 1 : 0) : pad ? U.clamp(pad.axis('left', 'right'), -1, 1) : 0;
      if (d && !input.drift && phase === 'count' && input.startTap == null) input.startTap = cd;
      input.drift = d;
    }
    function useItemNow() {
      const c = me();
      itemFlash = 0.22;
      if (c && c.item && c.roll <= 0 && phase === 'race' && c.fin == null) { input.use = true; api.buzz(15); return true; }
      api.sfx('tick'); return false;
    }
    function enter(id, k, fresh) {
      const prev = ptrs.get(id);
      if (prev === k) return;
      if (k == null || (k === 'I' && !fresh)) { ptrs.delete(id); refresh(); return; } // sliding onto the item pad never fires it
      ptrs.set(id, k);
      if (k === 'I') { useItemNow(); return; }
      api.buzz(k[0] === 'D' ? 10 : 6);
      refresh();
    }
    function onDown(e) {
      if (!ctlOn) return;
      const p = cv.local(e), k = zoneAt(p);
      if (!k) return;
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      enter(e.pointerId, k, true);
    }
    function onMove(e) {
      const id = e.pointerId;
      if (!ptrs.has(id)) return;
      e.preventDefault();
      const cur = ptrs.get(id);
      if (cur === 'I' || (cur === 'D' && !oneHand())) return; // pads keep their thumb until it lifts
      const k = zoneAt(cv.local(e));
      // a steering thumb may slide between ◀ / ▶ (and, one-handed, onto the drift bar); off the controls = keep the last one
      if (k && k !== 'I' && (isSteerZone(k) || oneHand())) enter(id, k, false);
    }
    function onUp(e) {
      if (!ptrs.has(e.pointerId)) return;
      ptrs.delete(e.pointerId); refresh();
    }
    function releaseAll() { ptrs.clear(); auto.on = false; input.drift = false; input.dir = 0; }
    /* per frame: ramp the steering toward the held direction (speed-sensitive maximum), auto-drift, wheel picture, haptics */
    function wheelTick(rdt) {
      const c = me(), v = c ? Math.max(0, c.v) : 0;
      if (ctlOn) refresh();
      // full steering at low speed and while drifting; a bit less at top speed so straights stay calm
      const maxS = c && c.drift ? 1 : 1 - 0.2 * U.clamp((v - 12) / 18, 0, 1);
      const target = input.dir * maxS, cur = input.steer;
      // quick ramp-up (~0.13 s to full), faster still back to the centre or when switching sides
      const rate = (target === 0 || cur * target < 0) ? 18 : 11; // ~0.09 s to full lock
      input.steer = cur + U.clamp(target - cur, -rate * rdt, rate * rdt);
      input.steerOut = input.steer;
      // auto-drift (option): holding a direction at speed for a moment starts a drift, letting go ends it (mini-turbo)
      if (cfg.auto && c && phase === 'race' && c.spin <= 0) {
        if (!auto.on) {
          auto.t = Math.abs(input.dir) > 0.5 && v > 16 ? auto.t + rdt : 0;
          if (auto.t > 0.3) { auto.on = true; auto.dir = Math.sign(input.dir); auto.off = 0; refresh(); }
        } else {
          auto.off = !(input.dir * auto.dir > 0.3) || v < 9 ? auto.off + rdt : 0;
          if (auto.off > 0.1) { auto.on = false; auto.t = 0; refresh(); }
        }
      } else if (auto.on) { auto.on = false; refresh(); }
      // the wheel picture eases toward the current steering (and back to the centre on release)
      const vt = U.clamp(c && c.auto > 0 ? c.steer || 0 : input.steer, -1, 1) * VIS_LOCK; // 자율주행 turns the wheel by itself
      wheel.vis += (vt - wheel.vis) * (1 - Math.exp(-rdt * 16));
      if (Math.abs(wheel.vis) < 0.002 && vt === 0) wheel.vis = 0;
      // drift charge levels: a tick when the sparks turn orange, a stronger one at blue
      const lvl = c && c.drift ? (c.charge > 1.6 ? 2 : c.charge > 0.8 ? 1 : 0) : 0;
      if (lvl > chargeLvl) { api.buzz(lvl === 2 ? 16 : 8); if (lvl === 2) api.sfx('chip'); }
      chargeLvl = lvl;
      if (itemFlash > 0) itemFlash -= rdt;
    }
    // keyboard / gamepad (declared in `controls`): steering & drift are read in refresh(), the item fires on press
    const offIn = api.input ? api.input.on((type, id) => {
      if (!ctlOn) return;
      if (id === 'item') { if (type === 'down') useItemNow(); } else refresh();
    }) : null;
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', (e) => e.preventDefault());
    const onVis = () => { if (document.hidden) releaseAll(); };
    window.addEventListener('blur', releaseAll);
    document.addEventListener('visibilitychange', onVis);

    /* ----- track picker (grid phase; host / local player picks, default random) ----- */
    function thumb(id, w, h2) {
      const t = buildTrack(id), c = L.h('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = w * dpr; c.height = h2 * dpr;
      const g = c.getContext('2d'), B = t.bx, s = Math.min(w / (B[2] - B[0]), h2 / (B[3] - B[1])) * dpr;
      const th = THEME[t.D.th];
      g.translate(c.width / 2, c.height / 2); g.scale(s, s); g.translate(-(B[0] + B[2]) / 2, -(B[1] + B[3]) / 2);
      g.lineJoin = g.lineCap = 'round';
      g.beginPath(); for (let i = 0; i <= NS; i += 4) { const j = i % NS; i ? g.lineTo(t.x[j], t.y[j]) : g.moveTo(t.x[j], t.y[j]); } g.closePath();
      g.strokeStyle = th.base === '#141220' ? '#ff5fb4' : th.base; g.lineWidth = 22; g.stroke();
      g.strokeStyle = '#f2e9d8'; g.lineWidth = 10; g.stroke();
      for (const C of t.cuts) { g.beginPath(); for (let k = 0; k < C.n; k += 3) k ? g.lineTo(C.sx[k], C.sy[k]) : g.moveTo(C.sx[k], C.sy[k]); g.strokeStyle = '#e3ae45'; g.lineWidth = 6; g.stroke(); }
      return c;
    }
    function buildPicker() {
      if (pick) return;
      const host = api.isHost && (mySeat() >= 0 || !api.online);
      const sub = L.h('div', { class: 'sub' });
      const grid = L.h('div', { class: 'rc-grid' });
      const btns = [];
      const mk = (id) => {
        const b = L.h('button', { class: 'rc-tk', 'aria-label': id === -2 ? '새 코스 생성' : id < 0 ? '무작위 트랙' : TRACKS[id].name, disabled: !host },
          id === -2 ? L.h('div', { class: 'q', text: '✦' }) : id < 0 ? L.h('div', { class: 'q', text: '?' }) : thumb(id, 44, 38), L.h('span', { text: id === -2 ? '새 코스 생성' : id < 0 ? '무작위' : TRACKS[id].name }));
        b.onclick = () => { if (!host || !st || st.ph !== 'grid') return; api.sfx('click'); api.setState(Object.assign({}, st, { t: id < 0 ? -1 : id, pk: id })); };
        btns.push({ id, b }); grid.append(b);
      };
      mk(-2); mk(-1); TRACKS.forEach((_, i) => mk(i));
      const go = L.h('button', { class: 'btn primary block', text: '출발', onclick() {
        if (!st || st.ph !== 'grid') return;
        api.sfx('click'); api.buzz(15);
        startRace();
      } });
      // per-device control layout (remembered on this phone)
      const ctlRow = L.h('div', { class: 'rc-ctl' });
      const drawCtl = () => {
        ctlRow.innerHTML = '';
        const seg = L.h('div', { class: 'seg', role: 'group', 'aria-label': '버튼 배치' });
        for (const [v, t] of [['two', '양손'], ['r', '한 손·오른'], ['l', '한 손·왼']]) seg.append(L.h('button', { class: cfg.hand === v ? 'on' : '', text: t, 'aria-pressed': cfg.hand === v ? 'true' : 'false', onclick() { api.sfx('click'); setCfg({ hand: v }); drawCtl(); } }));
        ctlRow.append(L.h('span', { class: 'lb', text: '버튼' }), seg,
          L.h('button', { class: 'tg' + (cfg.auto ? ' on' : ''), text: '자동 드리프트', title: '빠르게 달리며 한쪽을 잠깐 누르고 있으면 저절로 드리프트', 'aria-pressed': cfg.auto ? 'true' : 'false', onclick() { api.sfx('click'); setCfg({ auto: !cfg.auto }); drawCtl(); } }));
      };
      drawCtl();
      /* 차량 세팅 (this device's car; remembered on this phone): presets + 「조정」 opens three sliders in place of the track list */
      const setRow = L.h('div', { class: 'rc-ctl' }), setPanel = L.h('div', { class: 'rc-set' });
      setPanel.hidden = true;
      let setOpen = false;
      const NAMES = ['접지', '최고속', '가속'], TIPS = ['코너에서 덜 미끄러지고 더 잘 꺾여요', '직선 끝 속도가 빨라요', '느려진 뒤 다시 빨라지는 힘'];
      const drawSet = () => {
        setRow.innerHTML = '';
        const seg = L.h('div', { class: 'seg', role: 'group', 'aria-label': '차량 세팅' });
        for (const q of SETUPS) { const on = q.p.join() === cfg.setup.join(); seg.append(L.h('button', { class: on ? 'on' : '', text: q.n, 'aria-pressed': on ? 'true' : 'false', onclick() { api.sfx('click'); setCfg({ setup: q.p.slice() }); drawSet(); } })); }
        setRow.append(L.h('span', { class: 'lb', text: '세팅' }), seg,
          L.h('button', { class: 'tg' + (setOpen ? ' on' : ''), text: setOpen ? '닫기' : '조정', 'aria-expanded': setOpen ? 'true' : 'false', onclick() { api.sfx('click'); setOpen = !setOpen; grid.hidden = setOpen; setPanel.hidden = !setOpen; drawSet(); } }));
        setPanel.innerHTML = '';
        cfg.setup.forEach((v, k) => {
          const val = L.h('b', { text: '●'.repeat(v) + '○'.repeat(SETUP_MAX - v) });
          const sl = L.h('input', { type: 'range', min: 0, max: SETUP_MAX, step: 1, value: v, 'aria-label': NAMES[k] });
          sl.oninput = () => { // keep the total: take from (or give to) the other two, the biggest / smallest first
            const p = cfg.setup.slice(); let want = U.clamp(+sl.value | 0, 0, SETUP_MAX), d = want - p[k];
            p[k] = want;
            while (d !== 0) {
              const o = [0, 1, 2].filter((j) => j !== k && (d > 0 ? p[j] > 0 : p[j] < SETUP_MAX)).sort((a, b) => (d > 0 ? p[b] - p[a] : p[a] - p[b]))[0];
              if (o == null) { p[k] -= d; break; }
              p[o] += d > 0 ? -1 : 1; d += d > 0 ? -1 : 1;
            }
            setCfg({ setup: p }); drawSet();
          };
          setPanel.append(L.h('label', { class: 'rc-sl' }, L.h('span', { class: 'nm', text: NAMES[k] }), sl, val, L.h('span', { class: 'tp', text: TIPS[k] })));
        });
      };
      drawSet();
      const el = L.h('div', { class: 'rc-pick' }, L.h('h3', { text: '트랙 고르기' }), sub, grid, mySeat() >= 0 ? setPanel : null, mySeat() >= 0 ? setRow : null, mySeat() >= 0 ? ctlRow : null, host ? go : L.h('div', { class: 'sub', text: '호스트가 트랙을 고르는 중…' }));
      root.appendChild(el);
      pick = { el, sub, btns };
      syncPicker();
    }
    function syncPicker() {
      if (!pick || !st) return;
      const sel = st.pk == null ? -1 : st.pk;
      pick.btns.forEach(({ id, b }) => b.classList.toggle('on', id === sel));
      if (pick.sel !== sel) { pick.sel = sel; const on = pick.btns.find((q) => q.id === sel); if (on) try { on.b.scrollIntoView({ block: 'nearest' }); } catch (e) {} }
      const T0 = trackDef(st.t);
      pick.sub.textContent = sel === -2 ? '새 코스 생성 · 출발할 때마다 새로 만든 코스(도시 야간·사막·설산·해안 절벽·숲)' : sel < 0 || !(st.t >= 0) ? '무작위 · 어떤 트랙인지는 카운트다운에서 공개돼요' : T0.name + ' — ' + T0.hint;
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } }
    /* host / local: the track is rolled only now when 무작위 is picked, so nobody sees it before the countdown */
    function startRace() {
      if (!st || st.ph !== 'grid') return;
      const t = st.t >= 0 ? st.t : st.pk === -2 ? GEN0 + 1 + U.rand(GEN_N - 1) : U.rand(TRACKS.length);
      api.setState(Object.assign({}, st, { t, ph: 'count', seq: (st.seq || 0) + 1 }));
    }
    const mystery = () => !!st && st.ph === 'grid' && !(st.t >= 0);

    /* ----- championship standings (between races) ----- */
    let stand = null, standT = 0;
    function dropStand() { if (stand) { stand.el.remove(); stand = null; } }
    function nextRace() {
      if (!st || st.ph !== 'stand' || !st.cs) return;
      api.setState(Object.assign({}, st, { t: champNext(st.cs, st.pk), rid: 1 + U.rand(99999), ph: 'count', seq: (st.seq || 0) + 1, res: null, ks: null }));
    }
    function showStand() {
      const cs = st.cs, kk = st.rid + '.' + st.seq;
      if (stand && stand.k === kk) return;
      dropStand(); standT = 0;
      const o = champOrder(cs), pv = cs.k > 1 && cs.pv ? cs.pv : o, me0 = mySeat();
      const rows = o.map((i, k) => {
        const d = pv.indexOf(i) - k, last = cs.h[i][cs.h[i].length - 1];
        const gain = last ? last + '위 +' + (CH_PTS[last - 1] || 0) : '탈락 +0';
        return L.h('div', { class: 'row' + (i === me0 ? ' me' : '') },
          L.h('span', { class: 'rk', text: (k + 1) + '' }),
          L.h('span', { class: 'mv ' + (d > 0 ? 'up' : d < 0 ? 'dn' : 'eq'), text: d > 0 ? '▲' + d : d < 0 ? '▼' + -d : '–' }),
          L.h('span', { class: 'dot', style: 'background:' + P(i).color }),
          L.h('span', { class: 'nm', text: (st.nm && st.nm[i]) || P(i).name }),
          L.h('span', { class: 'gain', text: gain }),
          L.h('span', { class: 'tot', text: cs.pts[i] + '점' }));
      });
      const T = trackDef(st.t), sub = L.h('div', { class: 'sub' });
      const btn = api.isHost && me0 >= 0 ? L.h('button', { text: '다음 경주 ▶', onclick() { api.sfx('click'); nextRace(); } }) : null;
      const el = L.h('div', { class: 'rc-st' }, L.h('h3', { text: '챔피언십 ' + cs.k + '/' + CH_N + ' 경주 끝' }),
        L.h('div', { class: 'sub', text: (T ? T.name : '') + ' · 다음은 무작위 코스' }), ...rows, sub, btn);
      root.appendChild(el);
      stand = { el, k: kk, sub };
    }
    function standTick(dt) {
      if (!stand || !st || st.ph !== 'stand') return;
      standT += dt;
      const lim = mySeat() < 0 ? 3 : 12, left = Math.max(0, Math.ceil(lim - standT));
      stand.sub.textContent = api.isHost ? left + '초 뒤 다음 경주가 시작돼요' : '호스트가 곧 다음 경주를 시작해요';
      if (api.isHost && standT > lim) { standT = -1e9; nextRace(); }
    }

    /* ----- race lifecycle ----- */
    function setTrack(id) {
      tr = buildTrack(id);
      art = null; mini = null; roofs = null; rain = null; ghosts = null; boltSeen = -1; // rendered lazily (needs layout)
    }
    function ensureArt() {
      if (art || !tr) return;
      const B = tr.bx, maxPx = 4096;
      const bs = Math.min(9, maxPx / Math.max(B[2] - B[0], B[3] - B[1]));
      art = renderTrack(tr, bs);
      mini = renderMini();
    }
    // race stats counted here (host view): best lap (s), item/attack hits landed, hits taken — saved into the result state
    let kst = null;
    function resetCars() {
      const n = (st && st.n) || api.players.length;
      W = newWorld(tr, n, st && st.rid);
      kst = { lt: Array(n).fill(null), bl: Array(n).fill(0), hl: Array(n).fill(0), ht: Array(n).fill(0) };
      for (const c of W.cars) {
        c.remote = !controlledHere(c.seat);
        if (P(c.seat).ai) { setAiLevel(c, P(c.seat).lv); c.laneGoal = (Math.random() * 2 - 1) * 2; applySetup(c, aiSetup(tr, c.ailv, Math.random)); }
        else if (isLocalHuman(c.seat)) applySetup(c, cfg.setup);
      }
      parts = []; floats = []; skids = []; bursts = []; eatenOut = {};
      ghostReset();
      firstHumanFin = null; firstFin = null; doneSent = false; input.startTap = null; input.use = false; humOutT = null; lowWarn = false; kaboom = 0; boomFlash = 0;
      cam.ok = false;
    }
    function onFinish(c) {
      const place = W.cars.filter((o) => o !== c && o.fin != null).length + 1;
      if (firstFin == null) firstFin = W.clock;
      floats.push({ seat: c.seat, text: place + '위!', t: 2.2 });
      if (isLocalHuman(c.seat)) { api.toast(place + '위! ' + fmtT(c.fin)); api.sfx(place === 1 ? 'win' : 'bounce'); api.buzz(60); }
    }
    const say = (c, text, col) => floats.push({ seat: c.seat, text, t: 1.3, col });
    /* best lap on this device: per hand-made track, per theme for generated courses */
    function lapDone(c) {
      const t0 = c.lapT0; c.lapT0 = W.clock;
      if (t0 == null || c.crossed < 2 || c.crossed > LAPS + 1 || !api.best) return;
      const sec = Math.round((W.clock - t0) * 100) / 100;
      if (!(sec > 5)) return;
      const D = tr.D, key = 'lap_' + (D.gen ? 'gen_' + D.gen : 't' + tr.id), lab = '최고 랩 · ' + (D.gen ? genTheme(D).n + ' 생성 코스' : D.name);
      let nw = false;
      try { nw = api.best(key, sec, { label: lab, lower: true, fmt: 'time' }); } catch (e) {}
      if (nw) say(c, '최고 랩 ' + fmtT(sec * 1000) + '!', '#4fe3ff');
    }
    /* round 9 gimmick hit: text, colour, sound, buzz */
    const GIM_TXT = { herd: ['음매~!', '#f2ede4', 'bounce', 50], bang: ['펑!', '#ff9a3c', 'hit', 90], spray: ['물보라!', '#bfefff', 'whoosh', 15], rock: ['쿵! 낙석', '#d8a066', 'thud', 70], ball: ['눈사람!', '#f2fbff', 'thud', 60], car: ['빵빵!', '#ffd166', 'bounce', 20], gey: ['앗 뜨거!', '#ff8a3d', 'hit', 80], tw: ['빙글빙글!', '#d8dde6', 'whoosh', 70], mag: ['철컥!', '#7fd0ff', 'thud', 60], wave: ['철썩!', '#9fd4e8', 'whoosh', 20], block: ['휴, 막았다!', '#7fd0ff', 'chip', 20] };
    const hooks = {
      ev(c, ev) {
        const mine = isLocalHuman(c.seat);
        if ((ev & 1) && kst && W.racing && c.fin == null && !c.out && c.seat < kst.lt.length) {
          const t0 = kst.lt[c.seat]; kst.lt[c.seat] = W.clock;
          if (t0 != null && c.crossed >= 2 && c.crossed <= LAPS + 1) { const sec = Math.round((W.clock - t0) * 100) / 100; if (sec > 5 && (!kst.bl[c.seat] || sec < kst.bl[c.seat])) kst.bl[c.seat] = sec; }
        }
        if ((ev & 1) && W.racing && mine && c.fin == null && !c.out) lapDone(c);
        if (W.racing && c.fin == null) {
          if ((ev & 1) && c.crossed > LAPS) { c.fin = Math.round(W.clock * 1000); onFinish(c); }
          else if ((ev & 1) && c.crossed === LAPS && mine) { api.toast('마지막 랩!', 1200); api.sfx('chip'); }
          else if ((ev & 1) && c.crossed > 1 && mine) api.sfx('tick');
          else if ((ev & 8) && mine) api.toast('코스를 벗어나 랩 무효', 1400);
        }
        if (ev & 4) { for (let k = 0; k < 8; k++) spark(c, c.boost > 0.9 ? '#7fd0ff' : '#ffb347'); if (mine) { api.sfx('whoosh'); api.buzz(c.boost > 0.9 ? 22 : 12); punch = c.boost > 0.9 ? 1 : 0.6; } }
        if ((ev & 1048576) && mine) { api.buzz(6); for (let k = 0; k < 4; k++) spark(c, '#d8d2c4'); }
        if ((ev & 2) && mine) { api.sfx('whoosh'); punch = 0.7; }
        if (ev & 16) { const air2 = c.fallK === 'void' || c.fallK === 'gap' || c.fallK === 'sky'; splash(c.x, c.y, c.fallK); if (mine) { api.sfx(air2 ? 'whoosh' : 'thud'); api.buzz(40); say(c, c.fallK === 'lava' ? '앗 뜨거!' : air2 ? '추락!' : '풍덩!', c.fallK === 'lava' ? '#ff8a3d' : '#7fd0ff'); } }
        if (ev & 512) { bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#f2e9d8' }); if (mine) { api.sfx('hit'); api.buzz(90); shake = 1; say(c, c.spin > 0 ? '기차다!' : '휴, 막았다!', '#ee6a55'); } }
        if ((ev & 1024) && mine) { api.sfx('bounce'); api.buzz(16); say(c, '점프!', '#e8c04e'); }
        if (ev & 2048) { bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#ffe066' }); for (let k = 0; k < 10; k++) spark(c, '#fff3b0'); if (mine) { api.sfx('hit'); api.buzz(70); shake = 1; say(c, c.spin > 0 ? '찌릿!' : '휴, 막았다!', '#ffe066'); } }
        if (ev & 4096) { bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#f6ecd6' }); if (mine) { api.sfx('thud'); api.buzz(50); shake = Math.min(1, shake + 0.7); say(c, c.spin > 0 ? '풍차 날개!' : '휴, 막았다!', '#f6ecd6'); } }
        if (ev & 32768) { // round 9 gimmicks
          const G = GIM_TXT[c.ghk] || GIM_TXT.rock;
          if (c.ghk !== 'wave' && c.ghk !== 'car' && c.ghk !== 'spray') bursts.push({ x: c.x, y: c.y, t: 0.5, col: G[1] });
          if (c.ghk === 'bang') for (let k = 0; k < 16; k++) spark(c, k % 2 ? '#ffd166' : '#ff6a3d');
          if (c.ghk === 'ball') for (let k = 0; k < 12; k++) spark(c, '#ffffff');
          if (c.ghk === 'gey') splash(c.x, c.y, 'lava');
          if (c.ghk === 'wave') splash(c.x, c.y, 'sea');
          if (mine) { api.sfx(G[2]); api.buzz(G[3]); if (G[3] > 30) shake = Math.min(1, shake + 0.6); say(c, G[0], G[1]); }
        }
        if (ev & 65536) { if (mine || nearMe(c)) api.sfx('whoosh'); if (mine) { api.buzz(25); say(c, '슝!', '#b48cf0'); cam.ok = false; } }
        if ((ev & 256) && mine && wallT <= 0) { wallT = 0.2; api.sfx('bounce'); api.buzz(14); shake = Math.min(1, shake + 0.35); }
        if ((ev & 32) && mine) api.sfx('pop');
        if (ev & 131072) { for (let k = 0; k < 6; k++) spark(c, c.gk2 === 'hoop' ? '#4fe3ff' : '#ffd166'); if (mine) { api.sfx('chip'); api.buzz(12); say(c, c.gk2 === 'hoop' ? '고리 통과!' : '깃발 통과!', c.gk2 === 'hoop' ? '#4fe3ff' : '#ffd166'); } }
        if ((ev & 524288) && mine) { api.sfx('whoosh'); api.buzz(20); say(c, '점프!', '#e8c04e'); }
        if ((ev & 64) && mine) say(c, '복귀', '#ab9fb8');
        if ((ev & 128) && mine && wallT <= 0) { wallT = 0.2; api.sfx('thud'); api.buzz(18); shake = Math.min(1, shake + 0.45); for (let k = 0; k < 6; k++) spark(c, '#f2e9d8'); }
      },
      bump(a, b, rel, v) {
        if (v) { bursts.push({ x: v.x, y: v.y, t: 0.5, col: '#5fd3a0' }); say(v, v.spin > 0 ? '쿵!' : '막았다!', '#5fd3a0'); }
        if (bumpT <= 0 && (isLocalHuman(a.seat) || isLocalHuman(b.seat))) { bumpT = 0.25; api.sfx(v ? 'thud' : 'hit'); api.buzz(v ? 40 : 12); shake = Math.min(1, shake + (v ? 0.7 : 0.3)); }
      },
      hit(c, z, blocked) {
        const mine = isLocalHuman(c.seat);
        if (blocked) { if (mine) { api.sfx('chip'); say(c, '막았다!', '#7fd0ff'); } return; }
        if (mine) {
          api.sfx({ cloud: 'lose', smoke: 'whoosh', spring: 'bounce', frost: 'thud', tacks: 'pop', net: 'thud', bees: 'bounce', paint: 'whoosh', wall: 'thud', blow: 'whoosh', bomb: 'chip' }[z.t] || 'hit');
          api.buzz(z.t === 'oil' || z.t === 'smoke' || z.t === 'tacks' ? 50 : 90); shake = z.t === 'smoke' || z.t === 'tacks' ? 0.3 : 1;
        }
      },
      eaten(ids) { for (const id of ids) eatenOut[id] = Math.round(W.clock * 1000); },
    };
    function ctl(c) {
      if (!isLocalHuman(c.seat)) return null;
      const o = { steer: input.steerOut, dsteer: input.dir || input.steer, drift: input.drift, cap: 1, use: input.use };
      input.use = false;
      return o;
    }
    /* 내구도 0: fireball, smoke, rings, shake; the car is out of the race */
    function explode(c, mine) {
      for (let k = 0; k < 34; k++) { const a = Math.random() * 7, sp = 4 + Math.random() * 16; parts.push({ x: c.x, y: c.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.5 + Math.random() * 0.4, max: 0.9, r: 0.5 + Math.random() * 0.7, g: 1.2, col: ['#fff3b0', '#ffd166', '#ff9a3c', '#ee6a55'][k % 4], glow: true }); }
      for (let k = 0; k < 14; k++) { const a = Math.random() * 7, sp = 1 + Math.random() * 5; parts.push({ x: c.x, y: c.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1.2 + Math.random() * 0.6, max: 1.8, r: 1 + Math.random(), g: 2.2, col: '#3a3440', a: 0.55 }); }
      bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#ffd166', big: 2.2 }, { x: c.x, y: c.y, t: 0.5, col: '#ee6a55', big: 1.3 });
      floats.push({ seat: c.seat, text: '펑! 탈락', t: 2.2, col: '#ff9a3c' });
      if (mine) {
        kaboom = 1; boomFlash = 0.45; api.sfx('thud'); api.sfx('lose'); api.buzz(220);
      } else if (nearMe(c)) { api.sfx('thud'); api.buzz(30); kaboom = Math.max(kaboom, 0.45); }
      else api.sfx('hit');
    }
    /* world events → effects / sounds */
    function drainEvents() {
      for (const e of W.ev) {
        const c = e.s != null ? W.cars[e.s] : null, mine = c && isLocalHuman(c.seat);
        if (kst && W.racing && e.s != null && e.s < kst.ht.length) {
          if (e.k === 'hit') { kst.ht[e.s]++; if (e.o != null && e.o !== e.s && e.o >= 0 && e.o < kst.hl.length) kst.hl[e.o]++; }
        }
        if (e.k === 'boom' && c) { explode(c, mine); continue; }
        if (e.k === 'fix' && c) { if (mine) { say(c, '정비 +' + Math.round(e.n), '#5fd3a0'); api.sfx('chip'); } continue; }
        if (e.k === 'box') { boxPop(e.x, e.y); if (mine) { api.sfx('pop'); api.buzz(10); } }
        else if (e.k === 'got' && mine && c.item) { api.sfx('chip'); }
        else if (e.k === 'turbo') { for (let k = 0; k < 6; k++) spark(c, '#ff7a3d'); if (mine) { api.sfx('whoosh'); api.buzz(20); punch = 1; } }
        else if (e.k === 'fire' && (mine || nearMe(c))) api.sfx('whoosh');
        else if (e.k === 'drop' && mine) api.sfx('thud');
        else if (e.k === 'shield' && mine) api.sfx('chip');
        else if (e.k === 'cloud') { if (mine) { api.sfx('roll'); say(c, '번개 구름!', '#ffe066'); } }
        else if (e.k === 'burst') bursts.push({ x: e.x, y: e.y, t: 0.5 });
        else if (e.k === 'hit' && c) {
          bursts.push({ x: c.x, y: c.y, t: 0.5, col: { oil: '#2b2533', smoke: '#9aa0b4', frost: '#bfefff', spring: '#e8c04e', boom: '#c08a52', tacks: '#d8dde6', net: '#f2f2f2', shock: '#ffd166', fw: '#ff5fb4', paint: '#d14fd8', bees: '#ffd166', bomb: '#ff9a3c', wall: '#ee6a55', blow: '#bfefff' }[e.t] || '#ffb347' });
          const HIT_TXT = { cloud: ['찌릿!', '#ffe066'], oil: ['미끌!', '#ee6a55'], spring: ['띠용!', '#e8c04e'], smoke: ['콜록!', '#c9ccd8'], frost: ['꽁꽁!', '#7fd0ff'], boom: ['퍽!', '#ee6a55'], shrink: ['작아졌다!', '#ee6a55'], tacks: ['펑크!', '#d8dde6'], net: ['끈끈!', '#f2f2f2'], shock: ['쿵!', '#ffd166'],
            fw: ['팡!', '#ff5fb4'], paint: ['앞이 안 보여!', '#d14fd8'], bees: ['따끔따끔!', '#ffd166'], bomb: ['폭탄이 붙었다!', '#ff9a3c'], wall: ['쾅! 바리케이드', '#ee6a55'], blow: ['휘잉~', '#bfefff'], cball: ['쿵!', '#ee6a55'] };
          const ht = HIT_TXT[e.t] || ['쾅!', '#ee6a55'];
          say(c, ht[0], ht[1]);
          if (e.t === 'frost') for (let k = 0; k < 10; k++) spark(c, '#e6fbff');
          if (e.o != null && e.o !== e.s && isLocalHuman(e.o) && e.t !== 'cloud') { api.sfx('chip'); floats.push({ seat: e.o, text: '명중!', t: 1.1, col: '#5fd3a0' }); }
        }
        else if (e.k === 'mag') { if (mine) { api.sfx('roll'); say(c, '자석!', '#7fd0ff'); } }
        else if (e.k === 'smoke') { if (mine) { api.sfx('whoosh'); say(c, '연막!', '#c9ccd8'); } }
        else if (e.k === 'warp') { bursts.push({ x: e.x, y: e.y, t: 0.5, col: '#b48cf0' }); if (mine || nearMe(c)) api.sfx('whoosh'); if (mine) { api.buzz(25); say(c, '휙!', '#b48cf0'); } }
        else if (e.k === 'frost') { bursts.push({ x: e.x, y: e.y, t: 0.5, col: '#bfefff' }); for (let k = 0; k < 14; k++) { const a = Math.random() * 7, sp = 5 + Math.random() * 8; parts.push({ x: e.x, y: e.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.5, max: 0.5, r: 0.45, g: 0, col: '#e6fbff', glow: true }); } if (nearMe({ x: e.x, y: e.y })) api.sfx('pop'); }
        else if (e.k === 'mirror') { if (mine) { api.sfx('chip'); say(c, '반사 방패!', '#d8dde6'); } }
        else if (e.k === 'giant') { if (mine) { api.sfx('thud'); api.buzz(30); say(c, '거대화!', '#5fd3a0'); } }
        else if (e.k === 'reflect') { bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#d8dde6' }); say(c, '반사!', '#d8dde6'); if (mine) { api.sfx('chip'); api.buzz(20); } }
        else if (e.k === 'squash') { say(c, '꾹!', '#5fd3a0'); if (mine) api.sfx('thud'); }
        else if (e.k === 'shock') { bursts.push({ x: e.x, y: e.y, t: 0.5, col: '#ffd166' }); if (mine || nearMe(c)) api.sfx('thud'); if (mine) { api.buzz(30); say(c, '충격파!', '#ffd166'); } }
        else if (e.k === 'ghost') { if (mine) { api.sfx('whoosh'); say(c, '스르륵~', '#e6e0ff'); } }
        else if (e.k === 'hop') { if (mine) { api.sfx('bounce'); api.buzz(15); say(c, '점프!', '#5fd3a0'); } }
        else if (e.k === 'tire') { if (mine) { api.sfx('chip'); say(c, '험로 타이어!', '#e3ae45'); } }
        else if (e.k === 'steal') { if (mine) { api.sfx('chip'); api.buzz(20); say(c, '슬쩍! ' + ITEMS[e.it].n, '#5fd3a0'); } if (W.cars[e.o]) bursts.push({ x: W.cars[e.o].x, y: W.cars[e.o].y, t: 0.5, col: '#ee6a55' }); }
        else if (e.k === 'stolen') { say(c, '뺏겼다!', '#ee6a55'); if (mine) { api.sfx('lose'); api.buzz(40); } }
        else if (e.k === 'balloon') { if (mine) { api.sfx('pop'); say(c, '둥실~', '#ffd166'); } }
        else if (e.k === 'popped') { bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#ee6a55' }); say(c, '풍선 펑!', '#ee6a55'); if (mine) api.sfx('pop'); }
        else if (e.k === 'auto') { if (mine) { api.sfx('chip'); say(c, '자율주행!', '#4fe3ff'); } }
        else if (e.k === 'drone') { if (mine) { api.sfx('whoosh'); say(c, '드론 출동!', '#3fc3b0'); } }
        else if (e.k === 'zap') { bursts.push({ x: e.x, y: e.y, t: 0.5, col: '#4fe3ff' }); say(c, '드론 요격!', '#4fe3ff'); if (mine) { api.sfx('chip'); api.buzz(15); } }
        else if (e.k === 'rear') { if (mine || nearMe(c)) api.sfx('thud'); }
        else if (e.k === 'foam') { if (mine) { api.sfx('whoosh'); say(c, '거품 줄!', '#e6f6ff'); } }
        else if (e.k === 'blow') { bursts.push({ x: e.x, y: e.y, t: 0.5, col: '#bfefff' }); if (mine || nearMe(c)) api.sfx('whoosh'); if (mine) say(c, '휘잉~', '#bfefff'); }
        else if (e.k === 'pass') { const o = W.cars[e.o]; if (o) say(o, '폭탄 받음!', '#ff9a3c'); if (mine) { api.sfx('chip'); say(c, '폭탄 넘김!', '#5fd3a0'); } else if (o && isLocalHuman(o.seat)) { api.sfx('lose'); api.buzz(40); } }
        else if (e.k === 'gotbomb') { say(c, '폭탄 받음!', '#ff9a3c'); if (mine) { api.sfx('lose'); api.buzz(40); } }
        else if (e.k === 'portal') { bursts.push({ x: e.x, y: e.y, t: 0.5, col: '#b48cf0' }); bursts.push({ x: e.x2, y: e.y2, t: 0.5, col: '#7fd0ff' }); for (let k = 0; k < 12; k++) { const a = Math.random() * 7, sp = 4 + Math.random() * 7; parts.push({ x: e.x2, y: e.y2, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.5, max: 0.5, r: 0.4, g: 0, col: k % 2 ? '#b48cf0' : '#7fd0ff', glow: true }); } }
      }
      W.ev.length = 0;
    }
    function nearMe(c) { const m = me(); return m && c && (m.x - c.x) ** 2 + (m.y - c.y) ** 2 < 1600; }

    /* ----- network: compact presence payload ----- */
    function pack(c) {
      return [r1(c.x), r1(c.y), r2(wrapA(c.a)), r1(c.v), Math.round(progress(c) * 1000) / 1000, c.fin || 0,
        // flags: spin, air, shield, slow, boost, drift, resp, giant, mirror, magnet, warp, frozen, smoke-blind — as bits
        (c.spin > 0 ? 1 : 0) | (c.air > 0 ? 2 : 0) | (c.shield > 0 ? 4 : 0) | (c.slow > 0 ? 8 : 0) | (c.boost > 0 ? 16 : 0) | (c.drift ? 32 : 0) | (c.resp > 0 ? 64 : 0) |
        (c.giant > 0 ? 128 : 0) | (c.mirror > 0 ? 256 : 0) | (c.mag > 0 ? 512 : 0) | (c.warpN > 0 ? 1024 : 0) | (c.frz > 0 ? 2048 : 0) | (c.blind > 0 ? 4096 : 0) |
        (c.ghost > 0 ? 8192 : 0) | (c.net > 0 ? 16384 : 0) | (c.flat > 0 ? 32768 : 0) | (c.tire > 0 ? 65536 : 0) | (c.snowT > 0 ? 131072 : 0) |
        (c.flt > 0 ? 1 << 18 : 0) | (c.auto > 0 ? 1 << 19 : 0) | (c.drone > 0 ? 1 << 20 : 0) | (c.bomb > 0 ? 1 << 21 : 0) | (c.bee > 0 ? 1 << 22 : 0) | (c.paint > 0 ? 1 << 23 : 0) | (c.draft > 0.25 ? 1 << 24 : 0),
        c.roll > 0 ? 0 : ITEM_CODE[c.item] || 0, c.lvl, c.mag > 0 ? c.magT : -1, Math.round((c.mud || 0) * 9), Math.ceil(c.hp), c.out || 0];
    }
    function packHz() {
      const out = [];
      for (const id in W.hz) {
        const z = W.hz[id];
        if (!z.loc || out.length >= 14) continue;
        const r = [id, HZ_CODE[z.t] || 1, r1(z.x), r1(z.y)];
        if (FLY[z.t]) r.push(r2(wrapA(z.a)), Math.round(z.v), z.lvl | 0);
        else if (z.t === 'cloud') r.push(z.p);
        else if (z.t === 'frost') r.push(z.lvl | 0, frostOn(z) ? 1 : 0);
        else if (z.t === 'grab') r.push(z.tg | 0);
        else if (z.t === 'tacks' || z.t === 'wall' || z.t === 'blow') r.push(z.lvl | 0, r2(wrapA(z.a || 0)));
        else if (z.t === 'foam') r.push(z.lvl | 0, z.i0, z.i1, r1(z.lat));
        else if (z.t === 'pass') r.push(z.tg | 0, Math.round((z.fuse || 0) * 10));
        else r.push(z.lvl | 0);
        out.push(r);
      }
      return out;
    }
    function packBoxes() {
      const out = {}, now = W.clock * 1000;
      for (const id in W.myBox) { if (now - W.myBox[id] > BOX_RESPAWN + 1000) delete W.myBox[id]; else out[id] = W.myBox[id]; }
      return out;
    }
    function packEaten() {
      const out = [], now = W.clock * 1000;
      for (const id in eatenOut) { if (now - eatenOut[id] > 3000) delete eatenOut[id]; else out.push(id); }
      return out.slice(-12);
    }
    function ingestCar(seat, arr) {
      const c = W.cars[seat];
      if (!c || !c.remote || !Array.isArray(arr) || arr.length < 6) return;
      for (let i = 0; i < 6; i++) if (!fin(arr[i])) return;
      const sn = c.snap;
      if (sn && sn.raw.join() === arr.join()) return;
      c.snap = { raw: arr.slice(), x: arr[0], y: arr[1], a: arr[2], v: arr[3], t: performance.now() };
      const p = Math.max(0, arr[4]);
      c.crossed = Math.floor(p); c.idx = Math.min(NS - 1, Math.max(0, Math.round((p - c.crossed) * NS)));
      const f = arr[6] | 0;
      c.spin = f & 1 ? Math.max(c.spin, 0.2) : 0; c.air = f & 2 ? Math.max(c.air, 0.15) : 0; c.air0 = 0.5;
      c.shield = f & 4 ? 1 : 0; c.slow = f & 8 ? 0.3 : 0; c.boost = f & 16 ? 0.2 : 0; c.drift = f & 32 ? 1 : 0; c.resp = f & 64 ? 0.2 : 0;
      c.giant = f & 128 ? 1 : 0; c.mirror = f & 256 ? 1 : 0; c.mag = f & 512 ? 1 : 0; c.warpN = f & 1024 ? 1 : 0; c.frz = f & 2048 ? 0.3 : 0; c.blind = f & 4096 ? 0.3 : 0;
      c.ghost = f & 8192 ? 1 : 0; c.net = f & 16384 ? 1 : 0; c.flat = f & 32768 ? 1 : 0; c.tire = f & 65536 ? 1 : 0; c.snowT = f & 131072 ? 1 : 0;
      const hadBomb = c.bomb > 0;
      c.flt = f & (1 << 18) ? 1 : 0; c.auto = f & (1 << 19) ? 1 : 0; c.drone = f & (1 << 20) ? 1 : 0; c.bomb = f & (1 << 21) ? 1 : 0; c.bee = f & (1 << 22) ? 1 : 0; c.paint = f & (1 << 23) ? 1 : 0; c.draft = f & (1 << 24) ? 1 : 0;
      if (hadBomb && !c.bomb) bursts.push({ x: c.x, y: c.y, t: 0.5, col: '#ff9a3c' });
      c.mud = fin(arr[10]) ? U.clamp(arr[10] / 9, 0, 1) : 0;
      c.magT = fin(arr[9]) ? arr[9] | 0 : -1;
      c.item = CODE_ITEM[arr[7] | 0] || null;
      c.lvl = arr[8] | 0;
      if (arr[5] > 0 && c.fin == null) { c.fin = arr[5]; if (phase === 'race') onFinish(c); }
      if (fin(arr[11])) { const hp = U.clamp(arr[11], 0, HP_MAX); if (hp < c.hp - 0.5) c.hurtT = 0.6; c.hp = hp; } // 내구도: the owner device decides
      if (fin(arr[12]) && arr[12] > 0 && !c.out) { c.out = arr[12]; c.hp = 0; if (phase === 'race') W.ev.push({ k: 'boom', s: seat, x: c.x, y: c.y }); }
      if (!sn) { c.x = arr[0]; c.y = arr[1]; c.a = arr[2]; }
    }
    function ingestHz(owner, list, eatenSet) {
      if (!Array.isArray(list)) return;
      const seen = {};
      for (const r of list) {
        if (!Array.isArray(r) || typeof r[0] !== 'string' || !fin(r[2]) || !fin(r[3])) continue;
        const id = r[0];
        seen[id] = 1;
        if (W.eaten[id] || (eatenSet && eatenSet[id])) continue;
        const t = CODE_HZ[r[1] | 0] || 'oil';
        let z = W.hz[id];
        if (z && z.loc) continue; // id collision with one of mine: ignore
        const sig = r.join();
        if (!z) { z = W.hz[id] = { id, t, o: parseInt(id, 10), dev: owner, x: r[2], y: r[3], a: 0, v: 0, lvl: 0, age: 0, loc: false, life: 99, sig: '' }; }
        z.seen = frameNo;
        if (z.sig === sig) continue; // unchanged snapshot: keep dead-reckoning
        z.sig = sig; z.t = t; z.x = r[2]; z.y = r[3]; z.age = 0;
        if (FLY[t]) { z.a = fin(r[4]) ? r[4] : z.a; z.v = fin(r[5]) ? r[5] : 50; z.lvl = r[6] | 0; }
        else if (t === 'cloud') { z.p = fin(r[4]) ? r[4] : 99; }
        else if (t === 'frost') { z.lvl = r[4] | 0; if (r[5] === 1 && !z.land) { z.land = true; z.landAt = W.clock; } }
        else if (t === 'grab') { z.tg = r[4] | 0; z.life = 1.2; }
        else if (t === 'tacks' || t === 'wall' || t === 'blow') { z.lvl = r[4] | 0; z.a = fin(r[5]) ? r[5] : 0; if (t === 'blow') z.life = 0.35; }
        else if (t === 'foam') { z.lvl = r[4] | 0; z.i0 = U.clamp(r[5] | 0, 0, NS - 1); z.i1 = U.clamp(r[6] | 0, 0, NS - 1); z.lat = fin(r[7]) ? r[7] : 0; }
        else if (t === 'pass') { z.tg = r[4] | 0; z.fuse = fin(r[5]) ? r[5] / 10 : 2; }
        else z.lvl = r[4] | 0;
      }
      // the owner stopped listing it → gone
      for (const id in W.hz) { const z = W.hz[id]; if (!z.loc && z.dev === owner && !seen[id]) delete W.hz[id]; }
    }
    function dropStale() { for (const id in W.hz) { const z = W.hz[id]; if (!z.loc && frameNo - (z.seen || 0) > 240) delete W.hz[id]; } }
    function pollRemote() {
      if (!api.online || !W) return;
      let rem = null, hs = null;
      try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!api.isHost) { try { hs = api.net.hostState(); } catch (e) { hs = null; } }
      const blobs = [];
      if (rem && typeof rem === 'object') for (const k in rem) { const o = rem[k]; if (o && o.k === key) blobs.push([+k, o]); }
      if (hs && hs.k === key) blobs.push([-1, hs]);
      // hazards consumed by other devices
      const eatenSet = {};
      for (const [, o] of blobs) if (Array.isArray(o.e)) for (const id of o.e) if (typeof id === 'string') eatenSet[id] = 1;
      for (const id in eatenSet) {
        const z = W.hz[id];
        if (z && z.loc) {
          W.ev.push({ k: 'burst', x: z.x, y: z.y });
          if (isLocalHuman(z.o) && z.t !== 'cloud') { api.sfx('chip'); floats.push({ seat: z.o, text: '명중!', t: 1.1, col: '#5fd3a0' }); }
          delete W.hz[id];
        }
        else if (z) delete W.hz[id];
        W.eaten[id] = W.eaten[id] || W.clock;
      }
      for (const [seat, o] of blobs) {
        if (o.c && typeof o.c === 'object') for (const s in o.c) ingestCar(+s, o.c[s]);
        // hazards: owner = the device's seat (host blob: owner -2 covers AI-spawned ones)
        ingestHz(seat >= 0 ? seat : -2, o.z, eatenSet);
        if (o.b && typeof o.b === 'object') for (const id in o.b) {
          const t = o.b[id], bx = tr.boxes[id | 0];
          if (!fin(t) || !bx) continue;
          const until = Math.min(t + BOX_RESPAWN, W.clock * 1000 + BOX_RESPAWN); // clocks differ a little between devices
          if (W.boxT[id] >= until - 600) continue; // already known
          if (boxUp(W, id)) boxPop(bx.x, bx.y);
          W.boxT[id] = until;
        }
      }
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt;
      if (pubT > 0) return;
      pubT = 1 / 15;
      try {
        const mine = {}, ai = {};
        let nm = 0;
        for (const c of W.cars) {
          if (c.remote) continue;
          if (P(c.seat).ai) ai[c.seat] = pack(c);
          else { mine[c.seat] = pack(c); nm++; }
        }
        const z = phase === 'race' ? packHz() : [], b = phase === 'race' ? packBoxes() : {}, e = phase === 'race' ? packEaten() : [];
        // hazards/boxes/eaten ride on the host blob for the host, on the guest blob for guests
        if (api.isHost) {
          if (nm) api.net.publish({ k: key, c: mine });
          api.net.hostSend({ k: key, c: ai, z, b, e });
        } else if (nm) api.net.publish({ k: key, c: mine, z, b, e });
      } catch (e) {}
    }
    function smoothRemote(rdt) {
      const now = performance.now(), k = 1 - Math.exp(-rdt * 14);
      for (const c of W.cars) {
        if (!c.remote || !c.snap) continue;
        const s = c.snap, age = Math.min(0.3, (now - s.t) / 1000);
        const tx = s.x + Math.cos(s.a) * s.v * age, ty = s.y + Math.sin(s.a) * s.v * age;
        const pa = c.a;
        if (Math.hypot(tx - c.x, ty - c.y) > 14) { c.x = tx; c.y = ty; c.a = s.a; }
        else { c.x += (tx - c.x) * k; c.y += (ty - c.y) * k; c.a += wrapA(s.a - c.a) * k; }
        c.v = s.v;
        c.slip = rdt > 0 ? U.clamp(wrapA(c.a - pa) / rdt * s.v / GRIP, -12, 12) : 0;
        if (c.spin > 0) { c.spin -= rdt; c.rot += rdt * 12; } else c.rot = 0;
        if (c.air > 0) c.air -= rdt;
        if (c.hurtT > 0) c.hurtT -= rdt;
        if (c.out) { c.vx = c.vy = c.v = 0; c.x = s.x; c.y = s.y; }
      }
    }
    function takeovers() {
      for (const c of W.cars) {
        if (c.remote && controlledHere(c.seat)) {
          c.remote = false; c.vx = Math.cos(c.a) * (c.v || 0); c.vy = Math.sin(c.a) * (c.v || 0);
          c.idx = locate(tr, c.x, c.y, -1); c.sec = sector(c.idx); c.safe = c.idx; c.spin = 0; c.air = 0; c.resp = 0;
          if (P(c.seat).ai && !c.ailv) setAiLevel(c, P(c.seat).lv);
        } else if (!c.remote && !controlledHere(c.seat)) { c.remote = true; c.snap = null; }
      }
    }
    function checkDone() {
      if (doneSent || !st || st.ph === 'done') return;
      let all = true, hum = 0, humRun = 0;
      for (const c of W.cars) {
        if (c.fin == null && !c.out) all = false;
        else if (c.fin != null && !P(c.seat).ai && firstHumanFin == null) firstHumanFin = W.clock;
        if (!P(c.seat).ai) { hum++; if (c.fin == null && !c.out) humRun++; }
      }
      const clock = W.clock;
      // every human exploded (and none finished): end 3 s later, the AI order is taken as it stands
      if (hum && !humRun && firstHumanFin == null && humOutT == null) humOutT = clock;
      const timeout = (firstHumanFin != null && clock - firstHumanFin > 15) || (firstFin != null && clock - firstFin > 45) || (humOutT != null && clock - humOutT > 3) || clock > 300;
      if (!all && !timeout) return;
      doneSent = true;
      const res = ranking(W).map((c) => [c.seat, c.fin || 0, Math.round(Math.max(0, progress(c)) * 100) / 100, c.out ? 1 : 0]);
      const cs = st.cs ? champAdd(st.cs, res, st.t) : null;
      api.setState(Object.assign({}, st, { ph: cs && cs.k < CH_N ? 'stand' : 'done', res, cs, ks: kst ? { bl: kst.bl, hl: kst.hl, ht: kst.ht } : null }));
    }

    /* ----- particles ----- */
    function spark(c, col) {
      if (!c || parts.length > 180) return;
      const a = c.a + Math.PI + (Math.random() - 0.5) * 1.1, s = 8 + Math.random() * 12;
      parts.push({ x: c.x - Math.cos(c.a) * 2.2, y: c.y - Math.sin(c.a) * 2.2, vx: Math.cos(a) * s + c.vx * 0.5, vy: Math.sin(a) * s + c.vy * 0.5, life: 0.35, max: 0.35, r: 0.35, g: 0, col: col || '#f5c45a', glow: true });
    }
    function splash(x, y, k0) { const col = k0 === 'lava' ? '#ff8a3d' : k0 === 'void' ? '#9fe8ff' : '#cfefff'; for (let k = 0; k < 18; k++) { const a = Math.random() * 7, s = 4 + Math.random() * 10; parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.7, max: 0.7, r: 0.6, g: 0.8, col, glow: k0 !== 'sea' }); } }
    function boxPop(x, y) { for (let k = 0; k < 10; k++) { const a = Math.random() * 7, s = 6 + Math.random() * 8; parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: 0.45, max: 0.45, r: 0.45, g: 0, col: ['#e3ae45', '#ee6a55', '#5bb3e6', '#5fd3a0'][k % 4], glow: true }); } }
    const DUST = { syrup: 'rgba(200,120,40,1)', sugar: 'rgba(255,240,248,1)', fluff: 'rgba(255,255,255,1)', rough: 'rgba(120,100,95,1)', ash: 'rgba(90,80,80,1)', metal: 'rgba(200,230,255,1)', yard: 'rgba(200,200,200,1)', road: 'rgba(225,220,235,1)', grass: 'rgba(110,140,70,1)', sand: 'rgba(230,200,140,1)', snow: 'rgba(255,255,255,1)', mud: 'rgba(90,65,40,1)', dirt: 'rgba(170,120,75,1)', ice: 'rgba(220,245,255,1)', wood: 'rgba(160,120,80,1)' };
    function emit(dt) {
      for (const c of W.cars) {
        if (c.out || (c.hp < 35 && c.fin == null && W.racing)) { // 내구도: a damaged car smokes, a wreck smokes more
          const age = c.out ? W.clock - c.out / 1000 : 0, rate = c.out ? (age < 8 ? 9 : 0) : c.hp < 15 ? 10 : 4;
          if (parts.length < 200 && Math.random() < dt * rate) parts.push({ x: c.x + (Math.random() - 0.5), y: c.y + (Math.random() - 0.5), vx: (Math.random() - 0.5) * 2 - Math.cos(c.a) * (c.v || 0) * 0.3, vy: (Math.random() - 0.5) * 2 - Math.sin(c.a) * (c.v || 0) * 0.3, life: 1.1, max: 1.1, r: 0.6, g: 1.8, col: c.out || c.hp < 15 ? '#2a2430' : '#6a6470', a: 0.5 });
          if (c.out) { c.prevW = null; continue; }
        }
        if (c.resp > 0) { c.prevW = null; continue; }
        const ca = Math.cos(c.a), sa = Math.sin(c.a);
        const rx = c.x - ca * 1.5, ry = c.y - sa * 1.5;
        const w = [rx - sa, ry + ca, rx + sa, ry - ca];
        const drifting = (Math.abs(c.slip) > 3.2 || c.drift) && c.v > 8 && c.air <= 0;
        if (c.prevW && drifting && skids.length < 900) skids.push([c.prevW[0], c.prevW[1], w[0], w[1], c.prevW[2], c.prevW[3], w[2], w[3], 1, HARD[c.surf] ? 0 : 1]);
        c.prevW = drifting ? w : null;
        if (parts.length < 180 && c.air <= 0) {
          if (drifting && Math.random() < dt * 22) parts.push({ x: rx + (Math.random() - 0.5), y: ry + (Math.random() - 0.5), vx: -ca * 2 + (Math.random() - 0.5) * 2, vy: -sa * 2 + (Math.random() - 0.5) * 2, life: 0.7, max: 0.7, r: 0.9, g: 2.4, col: DUST[c.surf] || DUST.road, a: 0.28 });
          if (!HARD[c.surf] && c.v > 6 && Math.random() < dt * 26) parts.push({ x: rx, y: ry, vx: -ca * 4 + (Math.random() - 0.5) * 4, vy: -sa * 4 + (Math.random() - 0.5) * 4, life: 0.5, max: 0.5, r: 0.45, g: 0.5, col: DUST[c.surf] || DUST.grass, a: 0.8 });
          if (c.boost > 0 && Math.random() < dt * 30) spark(c);
          // drift sparks: orange after a short charge, blue when fully charged
          if (c.drift && c.charge > 0.8 && Math.random() < dt * 40) {
            const col = c.charge > 1.6 ? '#7fd0ff' : '#ffb347', side = Math.random() < 0.5 ? 0 : 2;
            parts.push({ x: w[side], y: w[side + 1], vx: -ca * 6 + (Math.random() - 0.5) * 6, vy: -sa * 6 + (Math.random() - 0.5) * 6, life: 0.25, max: 0.25, r: 0.3, g: 0, col, glow: true });
          }
        }
      }
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.life -= dt; if (p.life <= 0) { parts.splice(i, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 1 - dt * 2; p.vy *= 1 - dt * 2; p.r += p.g * dt;
      }
      for (let i = skids.length - 1; i >= 0; i--) { skids[i][8] -= dt * 0.12; if (skids[i][8] <= 0) skids.splice(i, 1); }
      for (let i = bursts.length - 1; i >= 0; i--) { bursts[i].t -= dt; if (bursts[i].t <= 0) bursts.splice(i, 1); }
    }

    /* ----- camera: chase view rotating with the car (car points up), zoom by speed ----- */
    function camTarget() {
      const c = me();
      if (c && !(c.out && W.clock * 1000 - c.out > 2500)) return c; // after my explosion: watch the race
      if (c) { const rk = ranking(W); return rk.find((x) => !gone(x)) || rk[0]; }
      // spectating (no human here): follow the leader
      const rk = ranking(W);
      return rk.find((x) => x.fin == null) || rk[0];
    }
    /* play area = the part of the screen above the press zones (whole screen when spectating) */
    const viewH = () => (mySeat() >= 0 && ctlTop > 0 ? ctlTop : cv.h);
    let camY = 0;
    const carY = () => { const c = camTarget(); return c ? toScreen(c.x, c.y).y : viewH() * 0.45; };
    function updateCam(rdt) {
      const c = camTarget();
      if (!c) return;
      const vh = viewH();
      const base = Math.min(cv.w, vh * 1.15) / 60; // ≈ 60 world units across a phone width
      const sc = base * (1.12 - U.clamp(c.v / VMAX, 0, 1.4) * 0.16) * (c.boost > 0 ? 0.93 : 1) * (1 - punch * 0.04); // boost: the view widens
      const look = 9 + Math.max(0, c.v) * 0.22;
      let wantA = c.a;
      if (c.spin <= 0) { const sp = Math.hypot(c.vx, c.vy); if (sp > 2) { const va = Math.atan2(c.vy, c.vx); wantA = c.a + U.clamp(wrapA(va - c.a), -0.9, 0.9) * 0.45 * U.clamp((sp - 2) / 8, 0, 1); } }
      if (c.spin > 0 || c.resp > 0) wantA = cam.a; // hold the view steady while spinning
      const ax = c.x + Math.cos(wantA) * look, ay = c.y + Math.sin(wantA) * look;
      // the look-ahead point sits at ~40% of the play area, so the car itself lands in its upper-middle
      const wantY = Math.min(vh * 0.4, vh - 34 - look * sc);
      if (!cam.ok) { cam.x = ax; cam.y = ay; cam.a = wantA; cam.sc = sc; camY = wantY; cam.ok = true; }
      const k = 1 - Math.exp(-rdt * 7), ka = 1 - Math.exp(-rdt * (c.drift ? 3.6 : 4.8)); // drifting: the view lags a little so the slide reads
      cam.x += (ax - cam.x) * k; cam.y += (ay - cam.y) * k;
      cam.a += wrapA(wantA - cam.a) * ka;
      cam.sc += (sc - cam.sc) * (1 - Math.exp(-rdt * (sc < cam.sc ? 3.5 : 1.6)));
      camY += (wantY - camY) * (1 - Math.exp(-rdt * 4));
    }
    /* speed lines: screen-space streaks around the car while boosting / near top speed */
    function drawLines(c) {
      const sp = Math.hypot(c.vx, c.vy), q = c.boost > 0 ? 1 : U.clamp((sp / VMAX - 0.92) / 0.2, 0, 0.6);
      if (q <= 0.02 && !lines.length) return;
      const vh = viewH(), cx = cv.w / 2, cy = camY + 20;
      if (q > 0.02 && lines.length < 26 * q) lines.push({ a: Math.random() * 6.283, r: 0.55 + Math.random() * 0.4, t: 0 });
      ctx.save(); ctx.lineCap = 'round';
      const R0 = Math.hypot(cv.w, vh) * 0.5;
      for (let i = lines.length - 1; i >= 0; i--) {
        const l = lines[i]; l.t += 1 / 60;
        if (l.t > 0.28) { lines.splice(i, 1); continue; }
        const r1 = R0 * (l.r + 0.5 - l.t * 1.6), r2 = r1 + R0 * 0.22, al = (1 - l.t / 0.28) * 0.35 * L.fx() * Math.max(q, 0.3);
        if (r1 <= 0) continue;
        ctx.strokeStyle = c.boost > 0 ? 'rgba(255,214,150,' + al + ')' : 'rgba(255,255,255,' + al + ')'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(cx + Math.cos(l.a) * r1, cy + Math.sin(l.a) * r1); ctx.lineTo(cx + Math.cos(l.a) * r2, cy + Math.sin(l.a) * r2); ctx.stroke();
      }
      ctx.restore();
    }
    /* engine / tyre squeal / turbo: a continuous WebAudio synth that follows my car (and, quieter, the nearest rivals).
       Engine = virtual 4-cylinder: crank-order PeriodicWave (firing order 2 + 4th/6th harmonics, half orders for lope)
       -> soft tanh waveshaper (grit) -> low-pass that opens with RPM & load. Virtual 5-speed box: shifts drop RPM with a
       short fuel cut, rev limiter bounces at redline, RPM is smoothed in JS (no warble). Noise layers: intake/exhaust
       (band-pass, rides throttle), tyre skid (band-pass with slow wobble), turbo whistle + whoosh. Master: compressor,
       ducking on crashes, x L.audio.sfx() (0 when muted). */
    /*ENGSYNTH*/
    const ENG_RATIO = [3.3, 2.15, 1.55, 1.18, 0.94], ENG_K = 170, ENG_IDLE = 850, ENG_RED = 7000;
    function engNoiseBuf(ac) { const n = ac.createBuffer(1, ac.sampleRate * 2, ac.sampleRate), d = n.getChannelData(0); let s = 12345; for (let i = 0; i < d.length; i++) { s = (s * 1103515245 + 12345) >>> 0; d[i] = s / 2147483648 - 1; } return n; }
    function engWave(ac) {
      const H = [0, 0.18, 1, 0.22, 0.6, 0.12, 0.34, 0.06, 0.2, 0.04, 0.1, 0.03, 0.06], re = new Float32Array(H.length), im = new Float32Array(H.length);
      for (let i = 1; i < H.length; i++) im[i] = H[i] * (i % 3 ? 1 : -1);
      return ac.createPeriodicWave(re, im);
    }
    function engShaper(ac, k) { const n = 1024, cu = new Float32Array(n); for (let i = 0; i < n; i++) { const x = i / (n - 1) * 2 - 1; cu[i] = Math.tanh(k * x) / Math.tanh(k); } const w = ac.createWaveShaper(); w.curve = cu; w.oversample = '2x'; return w; }
    /* one engine voice; full = my car (noise layers + turbo), otherwise a lighter rival voice */
    function engVoice(ac, dest, wave, noise, full) {
      const v = { full };
      v.o1 = ac.createOscillator(); v.o1.setPeriodicWave(wave);
      v.o2 = ac.createOscillator(); v.o2.setPeriodicWave(wave); v.o2.detune.value = 9;
      const g2 = ac.createGain(); g2.gain.value = 0.45;
      v.pre = ac.createGain(); v.pre.gain.value = 0.8;
      v.o1.connect(v.pre); v.o2.connect(g2).connect(v.pre);
      v.lp = ac.createBiquadFilter(); v.lp.type = 'lowpass'; v.lp.Q.value = 0.9; v.lp.frequency.value = 400;
      v.hp = ac.createBiquadFilter(); v.hp.type = 'highpass'; v.hp.frequency.value = 28;
      v.cut = ac.createGain(); v.cut.gain.value = 1; // shift cut / limiter
      v.g = ac.createGain(); v.g.gain.value = 0;
      v.pan = ac.createStereoPanner ? ac.createStereoPanner() : null;
      v.pre.connect(engShaper(ac, 2.2)).connect(v.lp).connect(v.hp).connect(v.cut).connect(v.g);
      if (v.pan) v.g.connect(v.pan).connect(dest); else v.g.connect(dest);
      v.o1.start(); v.o2.start();
      if (full) {
        const mk = (type, f, q) => { const b = ac.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; return b; };
        const src = (rate) => { const s = ac.createBufferSource(); s.buffer = noise; s.loop = true; s.playbackRate.value = rate; s.start(); return s; };
        v.nbp = mk('bandpass', 500, 1.2); v.ng = ac.createGain(); v.ng.gain.value = 0; src(1).connect(v.nbp).connect(v.ng).connect(v.cut);
        v.sbp = mk('bandpass', 1500, 2.5); v.sbp2 = mk('peaking', 2600, 3); v.sbp2.gain.value = 6; v.sg = ac.createGain(); v.sg.gain.value = 0; src(0.93).connect(v.sbp).connect(v.sbp2).connect(v.sg).connect(dest);
        v.wo = ac.createOscillator(); v.wo.type = 'sine'; v.wo.frequency.value = 3000; v.wg = ac.createGain(); v.wg.gain.value = 0; v.wo.connect(v.wg).connect(dest); v.wo.start();
        v.bhp = mk('bandpass', 1800, 0.7); v.bg = ac.createGain(); v.bg.gain.value = 0; src(1.07).connect(v.bhp).connect(v.bg).connect(dest);
      }
      return v;
    }
    /* RPM / gear model, pure JS: s = {rpm, gear, cutT, load}, updated in place */
    function engModel(s, sp, load, dt) {
      s.gear = s.gear || 0; s.rpm = s.rpm || ENG_IDLE; s.cutT = Math.max(0, (s.cutT || 0) - dt); s.limT = (s.limT || 0) + dt;
      let want = ENG_IDLE + sp * ENG_K * ENG_RATIO[s.gear];
      if (want > ENG_RED - 300 && s.gear < ENG_RATIO.length - 1 && s.cutT <= 0) { s.gear++; s.cutT = 0.11; }
      else if (s.gear > 0 && ENG_IDLE + sp * ENG_K * ENG_RATIO[s.gear - 1] < ENG_RED * 0.62) s.gear--;
      want = ENG_IDLE + sp * ENG_K * ENG_RATIO[s.gear] + (sp < 1.5 ? load * 900 : 0);
      let lim = 0;
      if (want >= ENG_RED) { want = ENG_RED; lim = Math.sin(s.limT * 2 * Math.PI * 11) > 0.3 ? 1 : 0; }
      const tau = want < s.rpm ? 0.09 : 0.14;
      s.rpm += (want - s.rpm) * (1 - Math.exp(-dt / tau));
      s.lim = lim; s.load = s.load == null ? load : s.load + (load - s.load) * (1 - Math.exp(-dt / 0.12));
      return s;
    }
    function engApply(v, s, t, gain, extra) {
      const crank = s.rpm / 60, open = 0.45 + 0.55 * s.load, dop = extra.dop || 1;
      v.o1.frequency.setTargetAtTime(crank * dop, t, 0.02); v.o2.frequency.setTargetAtTime(crank * dop, t, 0.02);
      v.lp.frequency.setTargetAtTime(Math.min(5000, 260 + s.rpm * 0.32 * open), t, 0.04);
      v.pre.gain.setTargetAtTime(0.5 + s.load * 0.9, t, 0.05);
      v.cut.gain.setTargetAtTime(s.cutT > 0 ? 0.25 : s.lim ? 0.35 : 1, t, 0.012);
      v.g.gain.setTargetAtTime(gain * (0.55 + 0.25 * (s.rpm / ENG_RED) + 0.2 * s.load), t, 0.06);
      if (v.pan && extra.pan != null) v.pan.pan.setTargetAtTime(extra.pan, t, 0.08);
      if (!v.full) return;
      v.nbp.frequency.setTargetAtTime(crank * 4 + 200, t, 0.05); v.ng.gain.setTargetAtTime(gain * s.load * 0.35, t, 0.07);
      v.sbp.frequency.setTargetAtTime(1300 + 400 * Math.sin(t * 5.3) + extra.skid * 300, t, 0.05);
      v.sg.gain.setTargetAtTime(gain * 0.55 * extra.skid, t, 0.05);
      v.wo.frequency.setTargetAtTime(2400 + s.rpm * 0.45 + extra.boost * 800, t, 0.15);
      v.wg.gain.setTargetAtTime(gain * 0.035 * extra.boost, t, 0.2);
      v.bhp.frequency.setTargetAtTime(900 + extra.boost * 1600, t, 0.1); v.bg.gain.setTargetAtTime(gain * 0.45 * extra.boost, t, 0.08);
    }
    /*/ENGSYNTH*/
    const eng = { ac: null, dead: false, s: {}, rv: [], rs: [{}, {}, {}], lt: 0, duck: 1 };
    function engStart() {
      if (eng.ac || eng.dead || L.audio.sfx() <= 0) return;
      try {
        const ac = eng.ac = new (window.AudioContext || window.webkitAudioContext)();
        const comp = ac.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.15;
        eng.m = ac.createGain(); eng.m.gain.value = 0; eng.m.connect(comp).connect(ac.destination);
        const wave = engWave(ac), noise = engNoiseBuf(ac);
        eng.v = engVoice(ac, eng.m, wave, noise, true);
        eng.rv = [0, 1, 2].map(() => engVoice(ac, eng.m, wave, noise, false));
      } catch (e) { eng.dead = true; eng.ac = null; }
    }
    function engTick() {
      const c = me(), vol = L.audio.sfx(), on = !!(c && !c.out && c.fin == null && phase === 'race' && !document.hidden);
      if (!eng.ac) { if (on && (ptrs.size || input.dir || input.drift)) engStart(); if (!eng.ac) return; }
      try {
        const ac = eng.ac;
        if (ac.state === 'suspended' && on) ac.resume().catch(() => {});
        const now = performance.now() / 1000, dt = U.clamp(now - (eng.lt || now), 0.001, 0.1); eng.lt = now;
        const t = ac.currentTime;
        eng.duck += ((kaboom > 0.3 || shake > 0.6 ? 0.45 : 1) - eng.duck) * (1 - Math.exp(-dt / 0.08));
        eng.m.gain.setTargetAtTime(on ? vol * 0.5 * eng.duck : 0, t, on ? 0.1 : 0.05);
        if (!c || !eng.v) return;
        const sp = Math.hypot(c.vx, c.vy), dv = (sp - (eng.psp == null ? sp : eng.psp)) / dt; eng.psp = sp;
        const load = U.clamp(0.35 + dv / 18 + (c.boost > 0 ? 0.3 : 0), 0.1, 1) * (c.air > 0 ? 0.4 : 1);
        const s = engModel(eng.s, sp, load, dt);
        const skid = U.clamp(Math.abs(c.slip || 0) / 9 + (c.drift ? 0.35 + Math.min(c.charge || 0, 2) * 0.15 : 0), 0, 1) * (sp > 4 && !(c.air > 0) ? 1 : 0);
        engApply(eng.v, s, t, 0.42, { skid, boost: c.boost > 0 ? 1 : 0, pan: 0 });
        /* the three nearest rivals: quieter with distance, Doppler-lite pitch, stereo pan from the camera angle */
        const near = W.cars.filter((o) => o !== c && !o.out && o.fin == null).map((o) => ({ o, d2: (o.x - c.x) ** 2 + (o.y - c.y) ** 2 })).sort((a, b) => a.d2 - b.d2);
        for (let i = 0; i < eng.rv.length; i++) {
          const n = near[i], rs = eng.rs[i];
          if (!n || n.d2 > 3600) { eng.rv[i].g.gain.setTargetAtTime(0, t, 0.15); continue; }
          if (rs.who !== n.o.seat) { eng.rs[i] = { who: n.o.seat }; }
          const r2 = eng.rs[i], d = Math.sqrt(n.d2) || 1, ux = (n.o.x - c.x) / d, uy = (n.o.y - c.y) / d;
          const vr = (n.o.vx - c.vx) * ux + (n.o.vy - c.vy) * uy, dop = U.clamp(1 - vr / 140, 0.85, 1.15);
          const osp = Math.hypot(n.o.vx, n.o.vy), odv = (osp - (r2.psp == null ? osp : r2.psp)) / dt; r2.psp = osp;
          engModel(r2, osp, U.clamp(0.4 + odv / 18 + (n.o.boost > 0 ? 0.3 : 0), 0.1, 1), dt);
          const ra = -cam.a - Math.PI / 2, sx = ux * Math.cos(ra) - uy * Math.sin(ra);
          engApply(eng.rv[i], r2, t, 0.16 / (1 + d / 9), { dop, pan: U.clamp(sx, -0.8, 0.8) });
        }
      } catch (e) {}
    }
    function engStop() { eng.dead = true; if (eng.ac) { try { eng.ac.close(); } catch (e) {} eng.ac = null; } }
    function applyCam(c2) {
      const tn = performance.now() / 1000, sk = (shake * shake * 3.6 + kaboom * 11) * L.fx(), sx = (Math.sin(tn * 31) + Math.sin(tn * 57 + 1.3) * 0.5) * sk * 0.67, sy = (Math.cos(tn * 27) + Math.sin(tn * 49 + 0.7) * 0.5) * sk * 0.67 + punch * 3 * L.fx();
      c2.translate(cv.w / 2 + sx, camY + sy);
      c2.rotate(-cam.a - Math.PI / 2);
      c2.scale(cam.sc, cam.sc);
      c2.translate(-cam.x, -cam.y);
    }
    const toScreen = (x, y) => {
      const dx = (x - cam.x) * cam.sc, dy = (y - cam.y) * cam.sc, r = -cam.a - Math.PI / 2;
      return { x: cv.w / 2 + dx * Math.cos(r) - dy * Math.sin(r), y: camY + dx * Math.sin(r) + dy * Math.cos(r) };
    };

    /* ----- drawing ----- */
    /* an exploded car: a burnt shell that smokes (fire for the first seconds) */
    function drawWreck(c, now) {
      const p = P(c.seat), age = Math.max(0, W.clock - c.out / 1000);
      ctx.save(); ctx.translate(c.x, c.y);
      ctx.fillStyle = 'rgba(20,14,18,.45)'; ctx.beginPath(); ctx.ellipse(0, 0, 4.2, 3.4, c.a, 0, 7); ctx.fill(); // scorch mark
      ctx.rotate(c.a + 0.35);
      ctx.fillStyle = '#121016'; ctx.fillRect(-1.9, -1.45, 1.1, 0.45); ctx.fillRect(1.0, 1.0, 1.1, 0.45);
      ctx.fillStyle = p.color; ctx.globalAlpha = 0.35; rr(ctx, -2.3, -1.2, 4.6, 2.4, 0.85); ctx.fill(); ctx.globalAlpha = 1;
      ctx.fillStyle = 'rgba(28,22,26,.78)'; rr(ctx, -2.3, -1.2, 4.6, 2.4, 0.85); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 0.22; ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 0.18; ctx.beginPath(); ctx.moveTo(-1.6, -0.9); ctx.lineTo(-0.4, 0.2); ctx.lineTo(0.6, -0.5); ctx.lineTo(1.7, 0.8); ctx.stroke();
      if (age < 4) { // flames
        const f = 1 - age / 4;
        for (let k = 0; k < 5; k++) { const fx = -1.4 + k * 0.7, fl = (0.7 + 0.5 * Math.sin(now / 70 + k * 1.7)) * f; ctx.fillStyle = k % 2 ? 'rgba(255,154,60,.85)' : 'rgba(255,209,102,.85)'; ctx.beginPath(); ctx.ellipse(fx, 0, 0.45, 0.45 + fl, 0, 0, 7); ctx.fill(); }
      }
      ctx.restore();
    }
    /* 내구도 bar above a car (upright on screen): green → yellow → red, flashes white when hit */
    function drawHpBar(c, gk) {
      if (!HP_ON || c.fin != null || phase === 'grid') return;
      const k = U.clamp(c.hp / HP_MAX, 0, 1), w2 = 4.6, h2 = 0.62;
      ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(cam.a + Math.PI / 2); ctx.translate(0, -3.1 * gk - 0.9);
      ctx.fillStyle = 'rgba(23,19,31,.8)'; rr(ctx, -w2 / 2 - 0.18, -0.18, w2 + 0.36, h2 + 0.36, 0.3); ctx.fill();
      ctx.fillStyle = k > 0.6 ? '#5fd3a0' : k > 0.3 ? '#e8c04e' : '#ee6a55';
      if (k > 0) { rr(ctx, -w2 / 2, 0, w2 * k, h2, 0.25); ctx.fill(); }
      if (c.hurtT > 0) { ctx.strokeStyle = 'rgba(255,255,255,' + U.clamp(c.hurtT * 1.6, 0, 1) + ')'; ctx.lineWidth = 0.22; rr(ctx, -w2 / 2 - 0.18, -0.18, w2 + 0.36, h2 + 0.36, 0.3); ctx.stroke(); }
      ctx.restore();
    }
    function drawCar(c, now) {
      if (c.out) { drawWreck(c, now); return; }
      const p = P(c.seat), lift = c.air > 0 ? Math.sin(Math.PI * U.clamp(1 - c.air / (c.air0 || 0.5), 0, 1)) : 0;
      const gk = c.giant > 0 ? (c.remote ? 1.5 : 1 + 0.5 * U.clamp(Math.min(c.giant, 5 - c.giant) * 4, 0, 1)) : 1; // grows / shrinks smoothly
      const fl = c.flt > 0 ? 1 : 0, s = (1 + lift * 0.35 + fl * 0.14) * gk;
      if (c.mag > 0 && W.cars[c.magT]) { // magnet: crackling field lines toward the locked car
        const o = W.cars[c.magT], dx = o.x - c.x, dy = o.y - c.y, d = Math.hypot(dx, dy);
        if (d < 75 && d > 1) {
          ctx.save(); ctx.strokeStyle = 'rgba(127,208,255,' + (0.45 + 0.25 * Math.sin(now / 60)) + ')'; ctx.lineWidth = 0.35; ctx.setLineDash([1.2, 1]); ctx.lineDashOffset = -now / 40;
          for (const k of [-1, 1]) { ctx.beginPath(); ctx.moveTo(c.x, c.y); ctx.quadraticCurveTo((c.x + o.x) / 2 - dy / d * k * 2.5, (c.y + o.y) / 2 + dx / d * k * 2.5, o.x, o.y); ctx.stroke(); }
          ctx.setLineDash([]); ctx.restore();
        }
      }
      if (c.warpN > 0) { // warp: a purple streak behind the car
        ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(c.a);
        const g = ctx.createLinearGradient(-14, 0, 2, 0); g.addColorStop(0, 'rgba(180,140,240,0)'); g.addColorStop(1, 'rgba(200,170,255,.7)');
        ctx.fillStyle = g; ctx.fillRect(-14, -1.4, 16, 2.8); ctx.restore();
      }
      ctx.save(); ctx.translate(c.x, c.y);
      // shadow (drops away while airborne)
      ctx.fillStyle = 'rgba(0,0,0,' + (0.38 - lift * 0.2) + ')';
      ctx.save(); ctx.translate(0.5 + (lift + fl * 0.9) * 2, 0.8 + (lift + fl * 0.9) * 2); ctx.rotate(c.a + c.rot); ctx.scale(gk, gk); rr(ctx, -2.3, -1.2, 4.8, 2.6, 0.9); ctx.fill(); ctx.restore();
      ctx.rotate(c.a + c.rot); ctx.scale(s, s);
      if (c.resp > 0) ctx.globalAlpha = 0.35 + 0.35 * Math.sin(now / 50);
      else if (c.ghost > 0) ctx.globalAlpha = 0.4 + 0.12 * Math.sin(now / 90);
      else if (W.racing && W.clock < START_GHOST) ctx.globalAlpha = 0.62 + 0.18 * Math.sin(now / 80); // start: cars pass through each other
      if (c.flat > 0) ctx.rotate(Math.sin(now / 35) * 0.06); // wobbling on a flat tyre
      if (NT || tr.D.night || tr.D.dark || tr.D.th === 'city' || (tr.D.dusk && W.clock > 25) || inTunnel(c)) { // headlight beam
        const lg = ctx.createLinearGradient(2.2, 0, 12, 0);
        lg.addColorStop(0, 'rgba(255,246,200,.35)'); lg.addColorStop(1, 'rgba(255,246,200,0)');
        ctx.fillStyle = lg; ctx.beginPath(); ctx.moveTo(2.2, -1.1); ctx.lineTo(12, -4); ctx.lineTo(12, 4); ctx.lineTo(2.2, 1.1); ctx.fill();
      }
      ctx.fillStyle = '#121016';
      ctx.fillRect(-1.9, -1.45, 1.1, 0.45); ctx.fillRect(-1.9, 1.0, 1.1, 0.45);
      const wa = (c.steer || 0) * 0.45;
      for (const sy of [-1.22, 1.22]) { ctx.save(); ctx.translate(1.5, sy); ctx.rotate(wa); ctx.fillRect(-0.5, -0.2, 1.0, 0.4); ctx.restore(); }
      if (c.tire > 0) { ctx.fillStyle = '#2a2630'; for (const [tx2, ty2] of [[-1.35, -1.38], [-1.35, 1.38], [1.5, -1.38], [1.5, 1.38]]) ctx.fillRect(tx2 - 0.7, ty2 - 0.34, 1.4, 0.68); ctx.fillStyle = '#e3ae45'; for (const [tx2, ty2] of [[-1.35, -1.38], [-1.35, 1.38], [1.5, -1.38], [1.5, 1.38]]) ctx.fillRect(tx2 - 0.15, ty2 - 0.34, 0.3, 0.68); }
      ctx.fillStyle = p.color; rr(ctx, -2.3, -1.2, 4.6, 2.4, 0.85); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = 0.22; ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.22)'; rr(ctx, -2.0, -0.95, 3.8, 0.55, 0.3); ctx.fill();
      ctx.fillStyle = '#1b2230'; rr(ctx, 0.15, -0.92, 1.05, 1.84, 0.35); ctx.fill();
      ctx.fillStyle = 'rgba(160,200,255,.35)'; ctx.fillRect(0.35, -0.75, 0.25, 1.1);
      ctx.fillStyle = '#1b2230'; rr(ctx, -1.75, -0.8, 0.55, 1.6, 0.25); ctx.fill();
      ctx.fillStyle = '#fff6c8'; ctx.beginPath(); ctx.arc(2.05, -0.78, 0.26, 0, 7); ctx.arc(2.05, 0.78, 0.26, 0, 7); ctx.fill();
      if (c.mud > 0.04) { // caked in mud
        ctx.fillStyle = 'rgba(92,64,36,' + (0.25 + 0.55 * c.mud) + ')'; rr(ctx, -2.3, -1.2, 4.6, 2.4, 0.85); ctx.fill();
        ctx.fillStyle = 'rgba(70,46,24,' + 0.8 * c.mud + ')'; for (const [mx2, my2, mr] of [[-1.4, -0.7, 0.45], [0.6, 0.8, 0.55], [1.6, -0.5, 0.35], [-0.6, 0.3, 0.4]]) { ctx.beginPath(); ctx.arc(mx2, my2, mr * (0.6 + c.mud * 0.6), 0, 7); ctx.fill(); }
      }
      if (c.paint > 0) { ctx.fillStyle = 'rgba(209,79,216,.85)'; for (const [mx2, my2, mr] of [[1.2, -0.3, 0.75], [-0.6, 0.6, 0.6], [0.4, 0.7, 0.4], [-1.5, -0.6, 0.45]]) { ctx.beginPath(); ctx.arc(mx2, my2, mr, 0, 7); ctx.fill(); } }
      if (c.snowT > 0) { ctx.fillStyle = 'rgba(250,253,255,.9)'; for (const [mx2, my2, mr] of [[-1.2, -0.6, 0.8], [0.5, 0.5, 0.9], [1.4, -0.4, 0.6], [-0.3, -0.1, 0.7]]) { ctx.beginPath(); ctx.arc(mx2, my2, mr, 0, 7); ctx.fill(); } }
      ctx.fillStyle = (c.drift || (c.v < 4 && c.spin <= 0)) ? '#ff3b3b' : '#7a1c1c'; ctx.fillRect(-2.35, -0.95, 0.3, 0.5); ctx.fillRect(-2.35, 0.45, 0.3, 0.5);
      if (c.boost > 0) { ctx.fillStyle = Math.random() < 0.5 ? '#ffd166' : '#ff7a3d'; ctx.beginPath(); ctx.moveTo(-2.3, -0.55); ctx.lineTo(-3.8 - Math.random() * 1.4, 0); ctx.lineTo(-2.3, 0.55); ctx.fill(); }
      ctx.globalAlpha = 1;
      ctx.restore();
      ctx.save(); ctx.translate(c.x, c.y);
      if (c.shield > 0) {
        ctx.strokeStyle = 'rgba(127,208,255,' + (0.55 + 0.25 * Math.sin(now / 120)) + ')'; ctx.lineWidth = 0.4;
        ctx.fillStyle = 'rgba(127,208,255,.12)';
        ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = now / 900 + k * Math.PI / 3; ctx.lineTo(Math.cos(a) * 3.6, Math.sin(a) * 3.6); } ctx.closePath(); ctx.fill(); ctx.stroke();
      }
      if (c.mirror > 0) { // reflector: two silver arcs circling the car
        ctx.save(); ctx.rotate(now / 200); ctx.lineWidth = 0.45;
        for (const k of [0, Math.PI]) { const g = ctx.createLinearGradient(-3.6, -3.6, 3.6, 3.6); g.addColorStop(0, '#ffffff'); g.addColorStop(1, '#8f98ac'); ctx.strokeStyle = g; ctx.beginPath(); ctx.arc(0, 0, 3.7 * gk, k, k + 1.9); ctx.stroke(); }
        ctx.restore();
      }
      if (c.net > 0) { // caught in a web
        ctx.save(); ctx.rotate(c.a); ctx.strokeStyle = 'rgba(245,245,250,.9)'; ctx.lineWidth = 0.16;
        for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * 3.2, Math.sin(a) * 2.4); ctx.stroke(); }
        for (const r of [1.2, 2.2, 3]) { ctx.beginPath(); ctx.ellipse(0, 0, r, r * 0.75, 0, 0, 7); ctx.stroke(); }
        ctx.restore();
      }
      if (c.flat > 0 && Math.random() < 0.3) { ctx.fillStyle = 'rgba(220,220,230,.5)'; ctx.beginPath(); ctx.arc((Math.random() - 0.5) * 3, (Math.random() - 0.5) * 3, 0.5, 0, 7); ctx.fill(); }
      if (c.ghost > 0) { ctx.strokeStyle = 'rgba(230,224,255,' + (0.35 + 0.2 * Math.sin(now / 120)) + ')'; ctx.lineWidth = 0.3; ctx.setLineDash([0.8, 0.8]); ctx.beginPath(); ctx.arc(0, 0, 3.3 * gk, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
      if (c.auto > 0) { // 자율주행: a cyan ring with chevrons pointing ahead
        ctx.save(); ctx.strokeStyle = 'rgba(79,227,255,' + (0.55 + 0.25 * Math.sin(now / 110)) + ')'; ctx.lineWidth = 0.3; ctx.setLineDash([0.9, 0.6]); ctx.lineDashOffset = -now / 60; ctx.beginPath(); ctx.arc(0, 0, 3.4 * gk, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        ctx.rotate(c.a); ctx.strokeStyle = '#4fe3ff'; ctx.lineWidth = 0.35; for (const o of [3.9, 4.7]) { ctx.beginPath(); ctx.moveTo(o - 0.5, -0.6); ctx.lineTo(o, 0); ctx.lineTo(o - 0.5, 0.6); ctx.stroke(); }
        ctx.restore();
      }
      if (c.bee > 0) for (let k = 0; k < 7; k++) { const a = now / 95 + k * 0.9, r = 2.2 + (k % 3) * 0.6; ctx.fillStyle = k % 2 ? '#ffd166' : '#17131f'; ctx.beginPath(); ctx.arc(Math.cos(a) * r, Math.sin(a * 1.4) * r, 0.3, 0, 7); ctx.fill(); }
      if (c.drone > 0) { // the escort drone circles the car
        const a = now / 380 + c.seat;
        ctx.save(); ctx.translate(Math.cos(a) * 3.8 * gk, Math.sin(a) * 3.8 * gk); ctx.rotate(now / 50); drawIcon(ctx, 'drone', 0.95); ctx.restore();
      }
      if (c.flt > 0 || c.bomb > 0) { // balloons above the car / a ticking bomb on its roof (drawn upright on screen)
        ctx.save(); ctx.rotate(cam.a + Math.PI / 2);
        if (c.flt > 0) {
          ctx.strokeStyle = 'rgba(242,233,216,.8)'; ctx.lineWidth = 0.12;
          for (const [bx, by, col] of [[-1.4, -4.6, '#ee6a55'], [1.4, -4.6, '#5bb3e6'], [0, -5.6, '#ffd166']]) {
            const sw = Math.sin(now / 300 + bx) * 0.25;
            ctx.beginPath(); ctx.moveTo(0, -0.6); ctx.lineTo(bx + sw, by + 1.1); ctx.stroke();
            ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(bx + sw, by, 1, 1.2, 0, 0, 7); ctx.fill();
            ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.beginPath(); ctx.arc(bx + sw - 0.35, by - 0.45, 0.28, 0, 7); ctx.fill();
          }
        }
        if (c.bomb > 0) {
          const blink = Math.floor(now / (c.bomb < 1 && !c.remote ? 80 : 200)) % 2;
          ctx.translate(0, -3.4 * gk); drawIcon(ctx, 'bomb', 1.35);
          if (blink) { ctx.strokeStyle = '#ff4040'; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.arc(0, 0.2, 1.9, 0, 7); ctx.stroke(); }
          if (!c.remote) { ctx.font = '700 1.7px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineWidth = 0.4; ctx.strokeStyle = '#17131f'; ctx.strokeText(String(Math.ceil(c.bomb)), 0, -2.6); ctx.fillStyle = '#ffd166'; ctx.fillText(String(Math.ceil(c.bomb)), 0, -2.6); }
        }
        ctx.restore();
      }
      if (c.draft > 0.05) { // slipstream: wind lines streaming past either side, more and brighter as the tow builds
        ctx.save(); ctx.rotate(c.a); ctx.strokeStyle = 'rgba(200,240,255,' + (0.25 + 0.5 * c.draft).toFixed(2) + ')'; ctx.lineWidth = 0.2;
        const nl = c.draft > 0.6 ? 3 : 2;
        for (let k = 0; k < nl; k++) for (const sd of [-1, 1]) {
          const sy = sd * (1.7 + k * 0.5), o = ((now / 35 + k * 1.3) % 4), ln = 2 + 2.5 * c.draft;
          ctx.beginPath(); ctx.moveTo(2.4 - o, sy); ctx.lineTo(2.4 - o - ln, sy); ctx.stroke();
        }
        ctx.restore();
      }
      if (c.frz > 0) { // frozen in a block of ice
        ctx.save(); ctx.rotate(c.a); ctx.fillStyle = 'rgba(190,235,255,.55)'; rr(ctx, -3, -2, 6, 4, 0.8); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 0.2; ctx.stroke(); ctx.beginPath(); ctx.moveTo(-2.2, -1.4); ctx.lineTo(-0.8, -0.2); ctx.moveTo(1.2, 0.8); ctx.lineTo(2.3, 1.5); ctx.stroke(); ctx.restore();
      }
      if (c.slow > 0 || c.blind > 0) { // tiny storm cloud / smoke puff overhead
        ctx.rotate(cam.a + Math.PI / 2);
        ctx.translate(0, -4.2 * gk);
        drawIcon(ctx, c.slow > 0 ? 'cloud' : 'smoke', 2.2);
      }
      ctx.restore();
      drawHpBar(c, gk);
    }
    function drawHazard(z, now) {
      ctx.save(); ctx.translate(z.x, z.y);
      if (z.t === 'oil') {
        const k = Math.min(1, z.age * 4 + (z.loc ? 0 : 1));
        ctx.scale(k, k);
        ctx.fillStyle = 'rgba(15,12,20,.92)'; ctx.beginPath(); ctx.ellipse(0, 0, 2.9, 2.3, z.a || 0, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.arc(2.2, 1.6, 0.9, 0, 7); ctx.arc(-2.3, -1.2, 0.7, 0, 7); ctx.fill();
        const g = ctx.createLinearGradient(-2, -2, 2, 2); g.addColorStop(0, 'rgba(120,90,255,.6)'); g.addColorStop(0.5, 'rgba(60,220,190,.5)'); g.addColorStop(1, 'rgba(255,190,60,.6)');
        ctx.strokeStyle = g; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.ellipse(-0.3, -0.2, 1.6, 0.9, (z.a || 0) + now / 2000, 0, 5); ctx.stroke();
      } else if (z.t === 'rocket' || z.t === 'homing') {
        ctx.rotate(z.a);
        ctx.fillStyle = 'rgba(255,200,90,.35)'; ctx.beginPath(); ctx.moveTo(-1.2, -0.5); ctx.lineTo(-4 - Math.random() * 2, 0); ctx.lineTo(-1.2, 0.5); ctx.fill();
        ctx.fillStyle = z.t === 'rocket' ? '#ee6a55' : '#3fc3b0'; rr(ctx, -1.4, -0.55, 2.8, 1.1, 0.5); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.beginPath(); ctx.arc(1.3, 0, 0.45, 0, 7); ctx.fill();
        if (z.t === 'homing') { ctx.strokeStyle = 'rgba(63,195,176,.6)'; ctx.lineWidth = 0.2; ctx.beginPath(); ctx.arc(0, 0, 2 + Math.sin(now / 80) * 0.4, 0, 7); ctx.stroke(); }
      } else if (z.t === 'spring') { // spring mine: striped plate + coil, bobbing
        const k = Math.min(1, z.age * 4 + (z.loc ? 0 : 1)), bob = 1 + Math.sin(now / 140 + (z.x | 0)) * 0.06;
        ctx.scale(k, k);
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.arc(0.3, 0.4, 2.3, 0, 7); ctx.fill();
        ctx.fillStyle = '#2b2533'; ctx.beginPath(); ctx.arc(0, 0, 2.2, 0, 7); ctx.fill();
        ctx.strokeStyle = '#e8c04e'; ctx.lineWidth = 0.45; ctx.setLineDash([0.7, 0.7]); ctx.beginPath(); ctx.arc(0, 0, 1.95, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        ctx.scale(bob, bob); ctx.strokeStyle = '#d8dde6'; ctx.lineWidth = 0.28; ctx.beginPath(); for (let r = 0.3; r < 1.5; r += 0.05) { const a = r * 14; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.stroke();
        ctx.fillStyle = '#ee6a55'; ctx.beginPath(); ctx.arc(0, 0, 0.45, 0, 7); ctx.fill();
      } else if (z.t === 'smoke') { // drifting grey cloud
        const k = Math.min(1, z.age * 2.5 + (z.loc ? 0 : 1)), fade = z.loc ? U.clamp(z.life - z.age, 0, 1) : 1;
        for (let i = 0; i < 9; i++) {
          const a = i * 0.7 + now / 1800 * (i % 2 ? 1 : -1), rr2 = (i % 3) * 1.9 * k, r = (2.2 + (i % 4) * 0.5) * k;
          ctx.fillStyle = 'rgba(' + (150 + i * 6) + ',' + (155 + i * 6) + ',' + (170 + i * 5) + ',' + (0.55 * fade) + ')';
          ctx.beginPath(); ctx.arc(Math.cos(a) * rr2, Math.sin(a) * rr2, r, 0, 7); ctx.fill();
        }
      } else if (z.t === 'frost') {
        if (!frostOn(z)) { // lobbed ice bomb (shadow on the ground, bomb above it)
          const t = U.clamp(z.age / FROST_FLY, 0, 1), hgt = Math.sin(Math.PI * t) * 3;
          ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.arc(0, 0, 0.9, 0, 7); ctx.fill();
          ctx.rotate(cam.a + Math.PI / 2); ctx.translate(0, -hgt); ctx.rotate(now / 120);
          drawIcon(ctx, 'frost', 1.2);
        } else { // ice patch with crystals
          const fade = z.loc ? U.clamp(z.life - z.age, 0, 1) : 1;
          ctx.globalAlpha = 0.8 * fade;
          const g = ctx.createRadialGradient(0, 0, 0.5, 0, 0, FROST_R);
          g.addColorStop(0, 'rgba(230,250,255,.95)'); g.addColorStop(0.75, 'rgba(160,220,250,.75)'); g.addColorStop(1, 'rgba(160,220,250,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, FROST_R, 0, 7); ctx.fill();
          ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 0.22;
          for (let k = 0; k < 7; k++) { const a = k * 0.9 + (z.x % 3), r0 = 1 + (k % 3), r1 = r0 + 1.6; ctx.beginPath(); ctx.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); ctx.lineTo(Math.cos(a) * r1, Math.sin(a) * r1); ctx.stroke(); }
          ctx.globalAlpha = 1;
        }
      } else if (z.t === 'boom') { // spinning boomerang
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.arc(0.4, 0.6, 1.4, 0, 7); ctx.fill();
        ctx.rotate(now / 45);
        drawIcon(ctx, 'boom', 1.9);
      } else if (z.t === 'tacks') { // a strip of tacks across the road
        const k = Math.min(1, z.age * 4 + (z.loc ? 0 : 1)), fade = z.loc ? U.clamp(z.life - z.age, 0, 1) : 1;
        ctx.rotate(z.a || 0); ctx.globalAlpha = fade;
        for (let q = 0; q < 16; q++) { const al = (hash01(q, 7) - 0.5) * 2.6 * k, lt = (q / 15 - 0.5) * 9 * k; ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(al + 0.15, lt + 0.2, 0.42, 0, 7); ctx.fill(); ctx.fillStyle = q % 3 ? '#d8dde6' : '#9aa0a8'; ctx.beginPath(); ctx.moveTo(al, lt - 0.5); ctx.lineTo(al + 0.45, lt + 0.3); ctx.lineTo(al - 0.45, lt + 0.3); ctx.fill(); }
        ctx.globalAlpha = 1;
      } else if (z.t === 'net') { // a flying web
        ctx.rotate(z.a + now / 200);
        ctx.strokeStyle = 'rgba(245,245,250,.95)'; ctx.lineWidth = 0.18;
        for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(a) * 1.9, Math.sin(a) * 1.9); ctx.stroke(); }
        for (const r of [0.8, 1.5]) { ctx.beginPath(); for (let k = 0; k <= 6; k++) { const a = k * Math.PI / 3; k ? ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r) : ctx.moveTo(r, 0); } ctx.stroke(); }
      } else if (z.t === 'shock') { // expanding ring
        const k = U.clamp(z.age / 0.45, 0, 1);
        ctx.strokeStyle = 'rgba(255,209,102,' + (1 - k) + ')'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.arc(0, 0, 2 + k * 9, 0, 7); ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,' + 0.7 * (1 - k) + ')'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.arc(0, 0, 1 + k * 7, 0, 7); ctx.stroke();
      } else if (z.t === 'fw' || z.t === 'cball' || z.t === 'paint' || z.t === 'bees' || z.t === 'bomb') {
        if (z.t === 'fw') { ctx.rotate(z.a); ctx.fillStyle = 'rgba(255,220,120,.5)'; ctx.beginPath(); ctx.moveTo(-0.8, -0.4); ctx.lineTo(-3.4 - Math.random() * 1.5, 0); ctx.lineTo(-0.8, 0.4); ctx.fill(); ctx.fillStyle = ['#ff5fb4', '#ffd166', '#4fe3ff'][z.id.charCodeAt(z.id.length - 1) % 3]; rr(ctx, -1, -0.4, 2, 0.8, 0.4); ctx.fill(); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(1, 0, 0.3, 0, 7); ctx.fill(); }
        else if (z.t === 'cball') { ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.arc(0.4, 0.6, 1, 0, 7); ctx.fill(); ctx.fillStyle = '#17131f'; ctx.beginPath(); ctx.arc(0, 0, 0.95, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.arc(-0.3, -0.3, 0.3, 0, 7); ctx.fill(); }
        else if (z.t === 'paint') { ctx.rotate(now / 90); ctx.fillStyle = '#d14fd8'; ctx.beginPath(); for (let k = 0; k < 10; k++) { const a = (k / 10) * Math.PI * 2, r = k % 2 ? 0.8 : 1.3; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.fill(); ctx.fillStyle = '#ffd166'; ctx.beginPath(); ctx.arc(0.3, -0.2, 0.35, 0, 7); ctx.fill(); }
        else if (z.t === 'bees') { for (let k = 0; k < 6; k++) { const a = now / 120 + k * 1.05, r = 0.9 + (k % 3) * 0.45; ctx.fillStyle = k % 2 ? '#ffd166' : '#17131f'; ctx.beginPath(); ctx.arc(Math.cos(a) * r, Math.sin(a * 1.3) * r, 0.32, 0, 7); ctx.fill(); } }
        else { ctx.rotate(cam.a + Math.PI / 2); drawIcon(ctx, 'bomb', 1.3); }
      } else if (z.t === 'wall') { // a striped barrier across the lane
        const k = Math.min(1, z.age * 5 + (z.loc ? 0 : 1)), fade = z.loc ? U.clamp(z.life - z.age, 0, 1) : 1;
        ctx.rotate(z.a); ctx.globalAlpha = fade; ctx.scale(1, k);
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fillRect(-0.3, -3.1, 1.2, 6.6);
        ctx.fillStyle = '#f2ede4'; ctx.fillRect(-0.55, -3.2, 1.1, 6.4);
        ctx.fillStyle = '#ee6a55'; for (let y = -3.2; y < 3.2; y += 1.6) ctx.fillRect(-0.55, y, 1.1, 0.8);
        ctx.fillStyle = '#ffd166'; ctx.beginPath(); ctx.arc(0, -3.2, 0.4, 0, 7); ctx.arc(0, 3.2, 0.4, 0, 7); ctx.fill();
        ctx.globalAlpha = 1;
      } else if (z.t === 'vort') { // a whirlpool on the road
        const k = Math.min(1, z.age * 2 + (z.loc ? 0 : 1)), fade = z.loc ? U.clamp(z.life - z.age, 0, 1) : 1;
        ctx.globalAlpha = 0.85 * fade; ctx.scale(k, k);
        const g = ctx.createRadialGradient(0, 0, 0.3, 0, 0, VORT_R); g.addColorStop(0, 'rgba(30,20,60,.85)'); g.addColorStop(0.6, 'rgba(90,120,220,.35)'); g.addColorStop(1, 'rgba(90,120,220,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, VORT_R, 0, 7); ctx.fill();
        ctx.rotate(-now / 260); ctx.lineWidth = 0.3;
        for (let q = 0; q < 3; q++) { ctx.strokeStyle = q % 2 ? 'rgba(180,140,240,.8)' : 'rgba(127,208,255,.8)'; ctx.beginPath(); for (let t = 0; t <= 1; t += 0.05) { const a = q * 2.1 + t * 5, r = 0.5 + t * (VORT_R - 1); ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); } ctx.stroke(); }
        ctx.globalAlpha = 1;
      } else if (z.t === 'foam') { // soap bubbles along the stripe (drawn in world space from the track samples)
        const fade = z.loc ? U.clamp(z.life - z.age, 0, 1) : 1, n = (((z.i1 - z.i0) % NS) + NS) % NS;
        ctx.restore(); ctx.save(); ctx.globalAlpha = 0.8 * fade;
        for (let q = 0; q <= n; q += 1) {
          const j = (z.i0 + q) % NS;
          for (let m = 0; m < 3; m++) { const l = z.lat + (hash01(j, m) - 0.5) * 3.6, r = 0.45 + hash01(m, j) * 0.55, px = tr.x[j] + tr.nx[j] * l, py = tr.y[j] + tr.ny[j] * l; ctx.fillStyle = 'rgba(230,248,255,.75)'; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(180,150,240,.6)'; ctx.lineWidth = 0.1; ctx.stroke(); }
        }
        ctx.globalAlpha = 1;
      } else if (z.t === 'blow') { // gusts of wind spreading forward
        const k = U.clamp(z.age / 0.35, 0, 1);
        ctx.rotate(z.a); ctx.strokeStyle = 'rgba(210,240,255,' + 0.8 * (1 - k) + ')'; ctx.lineWidth = 0.35;
        for (let q = -2; q <= 2; q++) { const L2 = 6 + k * 14; ctx.beginPath(); ctx.moveTo(2, q * 0.8); ctx.quadraticCurveTo(L2 * 0.5, q * (1.2 + L2 * 0.2), L2, q * (1 + L2 * 0.35)); ctx.stroke(); }
      } else if (z.t === 'grab') { // the claw snatching an item off its target
        const tc = W.cars[z.tg]; if (tc) { ctx.translate(tc.x - z.x, tc.y - z.y); }
        const k = U.clamp(z.age / 0.6, 0, 1);
        ctx.rotate(cam.a + Math.PI / 2); ctx.translate(0, -3 - k * 4); ctx.globalAlpha = 1 - k * 0.6;
        drawIcon(ctx, 'steal', 1.6); ctx.globalAlpha = 1;
      }
      ctx.restore();
    }
    function drawStand(b, now) { // the item on show, upright, with a ring that runs out before it changes
      let a = 1;
      if (!boxUp(W, b.id)) { const left = (W.boxT[b.id] - W.clock * 1000) / 1000; if (left > 0.6) return; a = 0.35; }
      const it = showItem(b, W.clock), fr = (Math.max(0, W.clock) / SHOW_PER + b.id * 0.37) % 1, bob = Math.sin(now / 280 + b.id) * 0.2;
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(cam.a + Math.PI / 2); ctx.translate(0, bob - 0.4); ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(23,19,31,.88)'; ctx.beginPath(); ctx.arc(0, 0, 2.6, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.lineWidth = 0.35; ctx.stroke();
      ctx.strokeStyle = fr > 0.75 && Math.floor(now / 120) % 2 ? '#ee6a55' : '#e3ae45'; ctx.lineWidth = 0.45; ctx.beginPath(); ctx.arc(0, 0, 2.6, -Math.PI / 2, -Math.PI / 2 + (1 - fr) * Math.PI * 2); ctx.stroke();
      drawIcon(ctx, it, 2);
      ctx.globalAlpha = 1; ctx.restore();
    }
    function drawBoxes(now) {
      for (const b of tr.boxes) {
        if (b.show) { drawStand(b, now); continue; }
        if (!boxUp(W, b.id)) {
          const left = (W.boxT[b.id] - W.clock * 1000) / 1000;
          if (left < 0.6) { ctx.globalAlpha = 0.3; } else continue;
        }
        const bob = Math.sin(now / 300 + b.id) * 0.25;
        ctx.save(); ctx.translate(b.x, b.y + 0); ctx.rotate(now / 700 + b.id);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; rr(ctx, -1.2, -1.0, 2.6, 2.6, 0.5); ctx.fill();
        ctx.translate(0, bob - 0.3);
        const g = ctx.createLinearGradient(-1.4, -1.4, 1.4, 1.4);
        const hue = (now / 8 + b.id * 40) % 360;
        g.addColorStop(0, 'hsla(' + hue + ',85%,70%,.95)'); g.addColorStop(1, 'hsla(' + ((hue + 120) % 360) + ',85%,55%,.95)');
        ctx.fillStyle = g; rr(ctx, -1.4, -1.4, 2.8, 2.8, 0.5); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 0.22; ctx.stroke();
        ctx.rotate(-(now / 700 + b.id) - cam.a - Math.PI / 2);
        ctx.fillStyle = '#fff'; ctx.font = '700 2px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('?', 0, 0.1);
        ctx.restore();
        ctx.globalAlpha = 1;
      }
    }

    function renderMini() {
      const B = tr.bx, S = 92, dpr = Math.min(2.5, cv.dpr || 1);
      const s = S / Math.max(B[2] - B[0], B[3] - B[1]);
      const c = document.createElement('canvas'); c.width = Math.ceil((B[2] - B[0]) * s * dpr); c.height = Math.ceil((B[3] - B[1]) * s * dpr);
      const g = c.getContext('2d'); g.scale(s * dpr, s * dpr); g.translate(-B[0], -B[1]);
      g.lineJoin = g.lineCap = 'round';
      g.beginPath(); for (let i = 0; i <= NS; i += 3) { const j = i % NS; i ? g.lineTo(tr.x[j], tr.y[j]) : g.moveTo(tr.x[j], tr.y[j]); } g.closePath();
      g.strokeStyle = 'rgba(0,0,0,.6)'; g.lineWidth = 16; g.stroke();
      g.strokeStyle = 'rgba(242,233,216,.85)'; g.lineWidth = 7; g.stroke();
      for (const C of tr.cuts) { g.beginPath(); for (let k = 0; k < C.n; k += 2) k ? g.lineTo(C.sx[k], C.sy[k]) : g.moveTo(C.sx[k], C.sy[k]); g.strokeStyle = 'rgba(227,174,69,.85)'; g.lineWidth = 4; g.stroke(); }
      g.strokeStyle = '#17131f'; g.lineWidth = 3; g.beginPath(); g.moveTo(tr.x[0] + tr.nx[0] * 6, tr.y[0] + tr.ny[0] * 6); g.lineTo(tr.x[0] - tr.nx[0] * 6, tr.y[0] - tr.ny[0] * 6); g.stroke();
      return { cv: c, s, w: (B[2] - B[0]) * s, h: (B[3] - B[1]) * s };
    }
    function pill(x, y, w, h2) { ctx.fillStyle = 'rgba(23,19,31,.78)'; rr(ctx, x, y, w, h2, h2 / 2); ctx.fill(); ctx.strokeStyle = 'rgba(242,233,216,.12)'; ctx.lineWidth = 1; ctx.stroke(); }
    function drawHud(now) {
      const c = me(), rk = ranking(W), w = cv.w;
      // minimap (top-right)
      if (mini) {
        const mx = w - mini.w - 10, my = 10;
        ctx.fillStyle = 'rgba(23,19,31,.85)'; rr(ctx, mx - 5, my - 5, mini.w + 10, mini.h + 10, 10); ctx.fill();
        ctx.drawImage(mini.cv, mx, my, mini.w, mini.h);
        const B = tr.bx;
        for (const id in W.hz) { const z = W.hz[id]; if (z.t === 'cloud' || z.t === 'grab' || z.t === 'shock' || z.t === 'blow' || z.t === 'pass') continue; ctx.fillStyle = HZ_COL[z.t] || '#ee6a55'; ctx.fillRect(mx + (z.x - B[0]) * mini.s - 1.2, my + (z.y - B[1]) * mini.s - 1.2, 2.4, 2.4); }
        for (const T of tr.tw) { const q = twPos(tr, T, W.clock); ctx.strokeStyle = '#d8dde6'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(mx + (q.x - B[0]) * mini.s, my + (q.y - B[1]) * mini.s, 3.2, 0, 5); ctx.stroke(); }
        for (let k = rk.length - 1; k >= 0; k--) {
          const o = rk[k], px = mx + (o.x - B[0]) * mini.s, py = my + (o.y - B[1]) * mini.s, mine = o === c;
          ctx.fillStyle = P(o.seat).color; ctx.strokeStyle = mine ? '#fff' : '#17131f'; ctx.lineWidth = mine ? 2 : 1.2;
          ctx.beginPath(); ctx.arc(px, py, mine ? 4.4 : 3.4, 0, 7); ctx.fill(); ctx.stroke();
        }
      }
      if (phase === 'grid') return;
      // position + lap (top-left)
      ctx.textBaseline = 'alphabetic'; ctx.textAlign = 'left';
      const focus = c || camTarget();
      if (focus) {
        const pos = rk.indexOf(focus) + 1;
        pill(10, 10, 118, 66);
        ctx.font = '40px "Black Han Sans", sans-serif'; ctx.fillStyle = pos === 1 ? '#e3ae45' : '#f2e9d8';
        ctx.fillText(String(pos), 22, 54);
        const pw = ctx.measureText(String(pos)).width;
        ctx.font = '700 13px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ab9fb8'; ctx.fillText('/' + rk.length + '위', 24 + pw, 54);
        ctx.font = '600 12px "IBM Plex Mono", monospace'; ctx.fillStyle = '#f2e9d8';
        const lap = focus.fin != null ? '완주' : focus.out ? '탈락' : 'LAP ' + U.clamp(focus.crossed, 1, LAPS) + '/' + LAPS;
        ctx.textAlign = 'right'; ctx.fillText(lap, 120, 30);
        ctx.fillStyle = '#ab9fb8'; ctx.fillText(fmtT(focus.fin != null ? focus.fin : W.clock * 1000), 120, 50);
        ctx.textAlign = 'left';
        // 내구도 bar
        if (HP_ON) {
        const hk = U.clamp(focus.hp / HP_MAX, 0, 1), hcol = focus.out ? '#ab9fb8' : hk > 0.6 ? '#5fd3a0' : hk > 0.3 ? '#e8c04e' : '#ee6a55';
        ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = hcol; ctx.textBaseline = 'middle'; ctx.fillText('내구도', 18, 66);
        ctx.fillStyle = 'rgba(255,255,255,.12)'; rr(ctx, 52, 62, 68, 8, 4); ctx.fill();
        if (hk > 0) { ctx.fillStyle = hcol; rr(ctx, 52, 62, 68 * hk, 8, 4); ctx.fill(); }
        if (focus.hurtT > 0 && !focus.out) { ctx.strokeStyle = 'rgba(255,255,255,' + U.clamp(focus.hurtT * 1.6, 0, 1) + ')'; ctx.lineWidth = 1.5; rr(ctx, 52, 62, 68, 8, 4); ctx.stroke(); }
        ctx.textBaseline = 'alphabetic';
        }
        if (!c) { pill(10, 80, 118, 24); ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = P(focus.seat).color; ctx.fillText('관전: ' + P(focus.seat).name, 20, 96); }
      }
      // compact standings under the position pill
      if (c && rk.length > 1) {
        let y = 82;
        for (let k = 0; k < rk.length; k++) {
          const o = rk[k];
          ctx.globalAlpha = o === c ? 1 : 0.75;
          ctx.fillStyle = 'rgba(23,19,31,.82)'; rr(ctx, 10, y, 92, 17, 8); ctx.fill();
          ctx.fillStyle = P(o.seat).color; ctx.beginPath(); ctx.arc(20, y + 8.5, 4, 0, 7); ctx.fill();
          ctx.font = '700 10.5px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = o.out ? '#8a7f96' : o === c ? '#e3ae45' : '#f2e9d8';
          const nm = P(o.seat).name; ctx.fillText((k + 1) + ' ' + (nm.length > 5 ? nm.slice(0, 5) + '…' : nm), 28, y + 12.5);
          if (o.out) { ctx.font = '700 9px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ee6a55'; ctx.textAlign = 'right'; ctx.fillText('탈락', 98, y + 12.5); ctx.textAlign = 'left'; }
          y += 19;
        }
        ctx.globalAlpha = 1;
      }
      drawTideHud();
      drawChip12();
      drawStatus12(82 + (c && rk.length > 1 ? rk.length * 19 : 0) + 4 + (c && c.mud > 0.04 ? 26 : 0));
      if (c && c.mud > 0.04 && c.fin == null) { // rally: how much mud is on the car
        const y = 82 + (rk.length > 1 ? rk.length * 19 : 0) + 4;
        pill(10, y, 92, 22); ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillStyle = '#d8b07a'; ctx.fillText('진흙', 18, y + 11.5);
        ctx.fillStyle = 'rgba(255,255,255,.12)'; rr(ctx, 46, y + 7, 48, 8, 4); ctx.fill();
        ctx.fillStyle = c.mud > 0.6 ? '#ee6a55' : '#a8784a'; rr(ctx, 46, y + 7, 48 * c.mud, 8, 4); ctx.fill();
        ctx.textBaseline = 'alphabetic';
      }
      if (c && c.out && phase === 'race') { // I exploded: say so, then spectate
        const t2 = W.clock - c.out / 1000, by = U.clamp(Math.max(carY() + 110, revealOn() ? revealBottom() + 44 : 0), 170, cv.h - 60);
        ctx.globalAlpha = U.clamp(t2 * 3, 0, 1); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillStyle = 'rgba(23,19,31,.82)'; rr(ctx, w / 2 - 120, by - 30, 240, 60, 16); ctx.fill();
        ctx.font = '26px "Black Han Sans", sans-serif'; ctx.fillStyle = '#ff9a3c'; ctx.fillText('탈락!', w / 2, by - 9);
        ctx.font = '700 11.5px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(t2 < 2.5 ? '내구도가 다 닳아 차가 터졌어요' : '관전 중 · 경주가 끝나면 결과가 나와요', w / 2, by + 15, 228);
        ctx.globalAlpha = 1; ctx.textBaseline = 'alphabetic';
      }
      if (c && c.wrongT > 1.2 && c.fin == null) {
        ctx.textAlign = 'center'; ctx.font = '24px "Black Han Sans", sans-serif';
        const wy = Math.max(80, carY() - 56); ctx.lineWidth = 5; ctx.strokeStyle = '#17131f'; ctx.strokeText('역주행!', w / 2, wy); ctx.fillStyle = '#ee6a55'; ctx.fillText('역주행!', w / 2, wy);
      }
    }
    function drawControls(now) {
      const c = me();
      if (!ctlOn || !c) return;
      const held = new Set(ptrs.values());
      const dOn = input.drift, chg = c.drift ? c.charge : 0;
      const chgCol = chg > 1.6 ? '#7fd0ff' : chg > 0.8 ? '#ffb347' : '#ee6a55';
      const lOn = input.dir < 0, rOn = input.dir > 0;
      const has = c.item && c.roll <= 0;
      ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      const chevron = (x, y, s, dir, on) => {
        ctx.strokeStyle = on ? '#17131f' : 'rgba(242,233,216,.8)'; ctx.lineWidth = Math.max(4, s * 0.22);
        ctx.beginPath(); ctx.moveTo(x - dir * s * 0.35, y - s * 0.6); ctx.lineTo(x + dir * s * 0.35, y); ctx.lineTo(x - dir * s * 0.35, y + s * 0.6); ctx.stroke();
      };
      const label = (t, x, y, col, size) => { ctx.font = '700 ' + (size || 12) + 'px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = col; ctx.fillText(t, x, y); };
      for (const z of zones) {
        if (z.k === 'L' || z.k === 'R') {
          const on = z.k === 'L' ? lOn : rOn, dir = z.k === 'L' ? -1 : 1;
          if (!oneHand()) {
            // half-screen press zone: soft panel, big chevron near the outer bottom corner
            const g = ctx.createLinearGradient(0, z.y, 0, z.y + z.h);
            g.addColorStop(0, on ? 'rgba(227,174,69,.10)' : 'rgba(23,19,31,0)'); g.addColorStop(1, on ? 'rgba(227,174,69,.42)' : 'rgba(23,19,31,.5)');
            ctx.fillStyle = g; ctx.fillRect(z.x, z.y, z.w, z.h);
            const cx = z.k === 'L' ? z.x + z.w * 0.3 : z.x + z.w * 0.7, cy = z.y + z.h * 0.66;
            ctx.fillStyle = on ? '#e3ae45' : 'rgba(23,19,31,.6)'; ctx.beginPath(); ctx.arc(cx, cy, 34, 0, 7); ctx.fill();
            ctx.strokeStyle = on ? '#e3ae45' : 'rgba(242,233,216,.25)'; ctx.lineWidth = 2; ctx.stroke();
            chevron(cx + dir * 3, cy, 28, dir, on);
          } else {
            ctx.fillStyle = on ? '#e3ae45' : 'rgba(23,19,31,.72)'; rr(ctx, z.x, z.y, z.w, z.h, 16); ctx.fill();
            ctx.strokeStyle = on ? '#e3ae45' : 'rgba(242,233,216,.22)'; ctx.lineWidth = 2; ctx.stroke();
            chevron(z.x + z.w / 2 + dir * 3, z.y + z.h / 2, Math.min(30, z.h * 0.32), dir, on);
          }
        }
      }
      if (!oneHand()) { // divider between the halves
        const z = zones.find((q) => q.k === 'L');
        ctx.strokeStyle = 'rgba(242,233,216,.12)'; ctx.lineWidth = 1; ctx.setLineDash([4, 6]);
        ctx.beginPath(); ctx.moveTo(z.x + z.w, z.y + 76); ctx.lineTo(z.x + z.w, cv.h - wheel.r * 2 - 22); ctx.stroke(); ctx.setLineDash([]);
      }
      // drift bar (one hand): ◀ drift | drift·brake | drift ▶
      const dl = zones.find((q) => q.k === 'DL');
      if (dl) {
        const dr = zones.find((q) => q.k === 'DR'), x0 = dl.x, x1 = dr.x + dr.w, y0 = dl.y, hh = dl.h;
        ctx.fillStyle = dOn ? 'rgba(238,106,85,.9)' : 'rgba(23,19,31,.72)'; rr(ctx, x0, y0, x1 - x0, hh, 14); ctx.fill();
        ctx.strokeStyle = chgCol; ctx.lineWidth = 2.5; ctx.stroke();
        for (const z of zones) if (z.k === 'DL' || z.k === 'DR' || z.k === 'DM') {
          if (held.has(z.k)) { ctx.fillStyle = 'rgba(23,19,31,.22)'; rr(ctx, z.x + 3, y0 + 3, z.w - 6, hh - 6, 11); ctx.fill(); }
          if (z.k !== 'DM') { ctx.strokeStyle = dOn ? 'rgba(23,19,31,.35)' : 'rgba(242,233,216,.12)'; ctx.lineWidth = 1; ctx.beginPath(); const xx = z.k === 'DL' ? z.x + z.w : z.x; ctx.moveTo(xx, y0 + 10); ctx.lineTo(xx, y0 + hh - 10); ctx.stroke(); }
        }
        const ink = dOn ? '#17131f' : '#f2e9d8', sub = dOn ? '#17131f' : '#ab9fb8', mx = (x0 + x1) / 2;
        label('◀', dl.x + dl.w / 2, y0 + hh / 2, ink, 15); label('▶', dr.x + dr.w / 2, y0 + hh / 2, ink, 15);
        label('드리프트', mx, y0 + hh / 2 - 7, ink, 13); label('브레이크', mx, y0 + hh / 2 + 10, sub, 10);
        if (c.drift) { ctx.fillStyle = chg > 1.6 ? '#7fd0ff' : '#ffb347'; rr(ctx, x0 + 8, y0 + hh - 7, (x1 - x0 - 16) * Math.min(1, chg / 1.6), 4, 2); ctx.fill(); }
      }
      // round drift pads (two hands) and the item pad
      for (const z of zones) {
        if (z.r == null) continue;
        if (z.k === 'D') {
          const pOn = dOn;
          ctx.save(); ctx.translate(z.x, z.y); if (held.has('D')) ctx.scale(0.93, 0.93);
          ctx.fillStyle = pOn ? 'rgba(238,106,85,.92)' : 'rgba(23,19,31,.78)'; ctx.beginPath(); ctx.arc(0, 0, z.r, 0, 7); ctx.fill();
          ctx.strokeStyle = chgCol; ctx.lineWidth = 3; ctx.stroke();
          if (c.drift) { ctx.strokeStyle = chg > 1.6 ? '#7fd0ff' : '#ffb347'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(0, 0, z.r + 5, -Math.PI / 2, -Math.PI / 2 + Math.min(1, chg / 1.6) * Math.PI * 2); ctx.stroke(); }
          label('드리프트', 0, -6, pOn ? '#17131f' : '#f2e9d8', 12);
          label('브레이크', 0, 10, pOn ? '#17131f' : '#ab9fb8', 10);
          ctx.restore();
        } else if (z.k === 'I') {
          const iOn = held.has('I') || itemFlash > 0;
          ctx.save(); ctx.translate(z.x, z.y); if (iOn) ctx.scale(0.93, 0.93);
          ctx.fillStyle = iOn ? 'rgba(227,174,69,.6)' : has ? 'rgba(60,46,30,.95)' : 'rgba(23,19,31,.78)'; ctx.beginPath(); ctx.arc(0, 0, z.r, 0, 7); ctx.fill();
          ctx.strokeStyle = has ? '#e3ae45' : 'rgba(242,233,216,.25)'; ctx.lineWidth = has ? 3 : 2; ctx.stroke();
          if (has) { ctx.globalAlpha = 0.5 + 0.3 * Math.sin(now / 160); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(0, 0, z.r + 5, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
          if (c.item && c.roll > 0) { const k = Math.floor(now / 70) % ITEM_KEYS.length; ctx.globalAlpha = 0.85; drawIcon(ctx, ITEM_KEYS[k], z.r * 0.6); ctx.globalAlpha = 1; }
          else if (has) {
            const pulse = 1 + Math.sin(now / 160) * 0.05; ctx.scale(pulse, pulse); drawIcon(ctx, c.item, z.r * 0.62);
            if (c.item === 'turbo3') { ctx.font = '700 11px "IBM Plex Mono", monospace'; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('×' + c.itemN, z.r * 0.55, z.r * 0.7); }
          } else label('아이템', 0, 0, 'rgba(242,233,216,.5)', 11);
          ctx.restore();
        }
      }
      { // PC key badges (조작 설정에서 바꾼 키, 터치·표시 끔이면 안 그림)
        const KB = { L: 'left', R: 'right', D: 'drift', DM: 'drift', I: 'item' };
        for (const z of zones) {
          const kl = KB[z.k] ? L.ui.keyLabel('racing', KB[z.k]) : ''; if (!kl) continue;
          if (z.r != null) L.ui.drawKeyBadge(ctx, z.x + z.r + 6, z.y + z.r + 4, kl);
          else if ((z.k === 'L' || z.k === 'R') && !oneHand()) { const cx = z.k === 'L' ? z.x + z.w * 0.3 : z.x + z.w * 0.7, cy = z.y + z.h * 0.66; L.ui.drawKeyBadge(ctx, cx + 40, cy + 36, kl); }
          else L.ui.drawKeyBadge(ctx, z.x + z.w - 4, z.y + z.h - 3, kl);
        }
      }
      // steering wheel: picture only, turns with the current steering
      drawWheelPic(now, chgCol);
      if (has && itemPad) { // item name tag above the item pad
        ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const t = ITEMS[c.item].n + (c.item === 'turbo3' ? ' (' + c.itemN + ')' : ''), tw = ctx.measureText(t).width + 14;
        const by = itemPad.y - itemPad.r - 14, tx = U.clamp(itemPad.x, 6 + tw / 2, cv.w - 6 - tw / 2);
        ctx.fillStyle = 'rgba(23,19,31,.82)'; rr(ctx, tx - tw / 2, by - 10, tw, 20, 10); ctx.fill();
        ctx.fillStyle = '#e3ae45'; ctx.fillText(t, tx, by);
      }
      if (cfg.auto) { // small badge so it's clear auto-drift is on
        ctx.font = '700 10px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const t = '자동 드리프트', tw = ctx.measureText(t).width + 12;
        const bx = U.clamp(wheel.x, tw / 2 + 6, cv.w - tw / 2 - 6), by = wheel.y - wheel.r - 14;
        ctx.fillStyle = auto.on ? 'rgba(238,106,85,.9)' : 'rgba(23,19,31,.75)'; rr(ctx, bx - tw / 2, by - 8, tw, 16, 8); ctx.fill();
        ctx.fillStyle = auto.on ? '#17131f' : '#ab9fb8'; ctx.fillText(t, bx, by);
      }
      ctx.restore();
    }
    function drawWheelPic(now, chgCol) {
      const R = wheel.r, c = me();
      ctx.save(); ctx.translate(wheel.x, wheel.y); ctx.lineCap = 'round';
      const lock = Math.abs(input.steer) > 0.97;
      // travel arc above the rim
      const ar = R + 8;
      ctx.strokeStyle = 'rgba(23,19,31,.55)'; ctx.lineWidth = 6;
      ctx.beginPath(); ctx.arc(0, 0, ar, -Math.PI / 2 - VIS_LOCK, -Math.PI / 2 + VIS_LOCK); ctx.stroke();
      if (Math.abs(wheel.vis) > 0.01) {
        ctx.strokeStyle = c && c.drift ? chgCol : lock ? '#ee6a55' : '#e3ae45'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.arc(0, 0, ar, -Math.PI / 2, -Math.PI / 2 + wheel.vis, wheel.vis < 0); ctx.stroke();
      }
      ctx.rotate(wheel.vis);
      ctx.globalAlpha = 0.95;
      ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = R * 0.24 + 3; ctx.beginPath(); ctx.arc(0, 2, R * 0.86, 0, 7); ctx.stroke();
      ctx.strokeStyle = '#231d2c'; ctx.lineWidth = R * 0.24; ctx.beginPath(); ctx.arc(0, 0, R * 0.86, 0, 7); ctx.stroke();
      ctx.strokeStyle = '#3d3449'; ctx.lineWidth = R * 0.17; ctx.beginPath(); ctx.arc(0, 0, R * 0.86, 0, 7); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.13)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(0, 0, R * 0.92, -2.7, -0.45); ctx.stroke();
      ctx.lineCap = 'butt';
      for (const s of [-1, 1]) { // leather grips
        const a0 = s < 0 ? Math.PI : 0;
        ctx.strokeStyle = '#5a4634'; ctx.lineWidth = R * 0.26;
        ctx.beginPath(); ctx.arc(0, 0, R * 0.86, a0 - 0.45, a0 + 0.45); ctx.stroke();
        ctx.strokeStyle = 'rgba(227,174,69,.5)'; ctx.lineWidth = 1; ctx.setLineDash([2.5, 2.5]);
        ctx.beginPath(); ctx.arc(0, 0, R * 0.86, a0 - 0.42, a0 + 0.42); ctx.stroke(); ctx.setLineDash([]);
      }
      for (const [ax, ay, w2] of [[-1, 0.05, 0.16], [1, 0.05, 0.16], [0, 1, 0.14]]) { // spokes
        ctx.strokeStyle = '#3d3449'; ctx.lineWidth = R * w2;
        ctx.beginPath(); ctx.moveTo(ax * R * 0.28, ay * R * 0.28); ctx.lineTo(ax * R * 0.78, ay * R * 0.78); ctx.stroke();
      }
      ctx.fillStyle = '#2e2640'; ctx.beginPath(); ctx.arc(0, 0, R * 0.3, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = c ? P(c.seat).color : '#e3ae45'; ctx.beginPath(); ctx.arc(0, 0, R * 0.12, 0, 7); ctx.fill();
      ctx.fillStyle = lock ? '#ee6a55' : '#e3ae45'; rr(ctx, -R * 0.06, -R * 0.99, R * 0.12, R * 0.24, 2); ctx.fill(); // top marker
      ctx.restore();
    }
    function hintText() {
      const c = me();
      if (!c || !ctlOn) return '';
      if (phase === 'count') return '「1」이 끝날 때쯤 드리프트를 누르면 출발 부스트!';
      if (phase === 'race' && W.clock < 7) return oneHand() ? '◀ ▶ 누르고 있으면 핸들 · 위로 밀면 드리프트' : '왼쪽·오른쪽을 누르고 있으면 그쪽으로 꺾여요';
      return '';
    }
    /* one-line gimmick hint in a pill (wrapped to two lines on narrow screens) */
    function hintLines() {
      const t = tr && tr.D.hint;
      if (!t) return [];
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif';
      const maxW = cv.w - 58, words = t.split(' '), lines = [''];
      for (const wd of words) { const tryL = lines[lines.length - 1] ? lines[lines.length - 1] + ' ' + wd : wd; if (ctx.measureText(tryL).width > maxW && lines[lines.length - 1]) lines.push(wd); else lines[lines.length - 1] = tryL; }
      return lines;
    }
    /* where the countdown's track card sits (under the car) and where its hint card ends */
    const revealOn = () => !!tr && (phase === 'count' || (phase === 'race' && W && W.clock < 3.5));
    const revealTy = () => carY() + 46;
    const revealBottom = () => revealTy() + 32 + 12 + hintLines().length * 16;
    function hintCard(x, y, a) {
      const lines = hintLines();
      if (!lines.length) return;
      ctx.save(); ctx.globalAlpha = a; ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const tw = Math.min(cv.w - 24, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 34), hh = 12 + lines.length * 16;
      ctx.fillStyle = 'rgba(23,19,31,.88)'; rr(ctx, x - tw / 2, y - 10, tw, hh, 12); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(x - tw / 2 + 13, y - 10 + hh / 2, 3.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; lines.forEach((l, k) => ctx.fillText(l, x + 5, y - 10 + 14 + k * 16));
      ctx.restore();
    }
    function drawMystery(now) {
      const w = cv.w, h = cv.h, top = pick ? pick.el.offsetTop : h;
      const g = ctx.createRadialGradient(w / 2, top * 0.45, 10, w / 2, top * 0.45, Math.max(w, h) * 0.8);
      g.addColorStop(0, '#2e2640'); g.addColorStop(1, '#17131f');
      ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = 'rgba(242,233,216,.05)'; ctx.lineWidth = 1;
      for (let x = -h; x < w; x += 22) { ctx.beginPath(); ctx.moveTo(x + (now / 60) % 22, 0); ctx.lineTo(x + h + (now / 60) % 22, h); ctx.stroke(); }
      // fit the card and its two lines into the space above the picker (4 rows of tracks on small phones)
      const s = U.clamp((top - 96) / 2.5, 18, 90), cy = U.clamp(top * 0.4, s + 10, top - s - 66);
      ctx.save(); ctx.translate(w / 2, cy); ctx.rotate(Math.sin(now / 700) * 0.06);
      ctx.fillStyle = 'rgba(227,174,69,.14)'; rr(ctx, -s, -s, s * 2, s * 2, s * 0.3); ctx.fill();
      ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 3; ctx.setLineDash([8, 6]); ctx.stroke(); ctx.setLineDash([]);
      ctx.font = Math.round(s * 1.3) + 'px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#e3ae45'; ctx.fillText('?', 0, s * 0.06);
      ctx.restore();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const gen = st && st.pk === -2;
      ctx.font = '26px "Black Han Sans", sans-serif'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(gen ? '새 코스 생성' : '무작위 트랙', w / 2, cy + s + 26);
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.fillStyle = '#ab9fb8'; ctx.fillText(gen ? '출발하면 새 코스가 만들어져요 · ' + LAPS + '랩' : TRACKS.length + '개 중 하나 · ' + LAPS + '랩', w / 2, cy + s + 50);
    }
    function draw(now) {
      cv.clear();
      if (mystery()) { drawMystery(now); return; }
      const th = tr ? THEME[tr.D.th] : null;
      ctx.fillStyle = th ? beyond(tr, th) : '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h);
      if (!tr || !W) return;
      ensureArt();
      ctx.save(); applyCam(ctx);
      ctx.imageSmoothingEnabled = true;
      const B = tr.bx;
      ctx.drawImage(art.cv, B[0], B[1], B[2] - B[0], B[3] - B[1]);
      // skid marks
      ctx.lineCap = 'round'; ctx.lineWidth = 0.5;
      for (const s of skids) { ctx.strokeStyle = s[9] ? 'rgba(40,25,10,' + (s[8] * 0.3) + ')' : 'rgba(12,8,14,' + (s[8] * 0.35) + ')'; ctx.beginPath(); ctx.moveTo(s[0], s[1]); ctx.lineTo(s[2], s[3]); ctx.moveTo(s[4], s[5]); ctx.lineTo(s[6], s[7]); ctx.stroke(); }
      drawFlow(now);
      drawBelts(now);
      drawTide();
      drawGim(now);
      drawGim12(now);
      drawBoxes(now);
      drawMovers();
      drawGates(now);
      drawDoors(now);
      drawBoltRings(now);
      const GND = (z) => z.t === 'oil' || z.t === 'spring' || z.t === 'tacks' || z.t === 'wall' || z.t === 'vort' || z.t === 'foam' || (z.t === 'frost' && frostOn(z));
      for (const id in W.hz) if (GND(W.hz[id])) drawHazard(W.hz[id], now);
      // cars under the bridge first, then the bridge deck, then cars on it
      const cars = W.cars.slice().sort((a, b) => (a.lvl - b.lvl) || ((a.air > 0) - (b.air > 0)));
      const cr = tr.cross;
      drawWetRoad(now, cars);
      drawGhostCar();
      for (const c of cars) if (!cr || c.lvl === 0) drawCar(c, now);
      if (cr) drawBridge(cr);
      for (const c of cars) if (cr && c.lvl === 1) drawCar(c, now);
      drawTrain();
      drawSails();
      drawGimTop(now);
      drawTop12(now);
      drawRoofs(rdtLast);
      for (const id in W.hz) { const z = W.hz[id]; if (z.t !== 'cloud' && z.t !== 'pass' && !GND(z)) drawHazard(z, now); }
      for (const p of parts) {
        ctx.globalAlpha = (p.life / p.max) * (p.a || 0.9);
        ctx.fillStyle = p.col;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 7); ctx.fill();
      }
      ctx.globalAlpha = 1;
      for (const b of bursts) {
        const k = 1 - b.t / 0.5;
        ctx.strokeStyle = b.col || '#ffb347'; ctx.globalAlpha = 1 - k; ctx.lineWidth = 0.8;
        ctx.lineWidth = b.big ? 1.4 : 0.8;
        ctx.beginPath(); ctx.arc(b.x, b.y, 1 + k * 6 * (b.big || 1), 0, 7); ctx.stroke();
      }
      ctx.globalAlpha = 1;
      ctx.restore();
      drawWeather(now, rdtLast);
      drawWeather2(now, rdtLast);
      drawWx(now, rdtLast);
      drawWeather12(now, rdtLast);
      drawBoltStrikes(rdtLast);
      if (tr.D.night) { // night: darken the edges, keep a pool of light around the player
        const fc = camTarget(), fp = fc ? toScreen(fc.x, fc.y) : { x: cv.w / 2, y: cv.h * 0.5 };
        const g = ctx.createRadialGradient(fp.x, fp.y, Math.min(cv.w, cv.h) * 0.25, fp.x, fp.y, Math.max(cv.w, cv.h) * 0.75);
        g.addColorStop(0, 'rgba(10,6,25,0)'); g.addColorStop(1, 'rgba(10,6,25,.62)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, cv.w, cv.h);
      }
      // cloud flash
      for (const id in W.hz) { const z = W.hz[id]; if (z.t === 'cloud' && z.age < 0.4) { ctx.fillStyle = 'rgba(255,240,170,' + (0.3 * (1 - z.age / 0.4)) + ')'; ctx.fillRect(0, 0, cv.w, cv.h); } }
      const c0 = me();
      if (c0 && c0.flash > 0) { ctx.fillStyle = 'rgba(127,208,255,' + c0.flash * 0.3 * L.fx() + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      if (c0 && !c0.out && L.fx() > 0) drawLines(c0);
      if (boomFlash > 0) { ctx.fillStyle = 'rgba(255,160,60,' + boomFlash * 0.9 * L.fx() + ')'; ctx.fillRect(0, 0, cv.w, cv.h); }
      // floating texts (screen space)
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (const f of floats) {
        const c = W.cars[f.seat]; if (!c) continue;
        const p = toScreen(c.x, c.y), sy = p.y - 30 - (2.2 - f.t) * 10;
        ctx.globalAlpha = Math.min(1, f.t * 2);
        ctx.font = '22px "Black Han Sans", sans-serif';
        ctx.lineWidth = 4; ctx.strokeStyle = '#17131f'; ctx.strokeText(f.text, p.x, sy);
        ctx.fillStyle = f.col || P(f.seat).color; ctx.fillText(f.text, p.x, sy);
      }
      ctx.globalAlpha = 1;
      drawHud(now);
      drawControls(now);
      const hint = hintText();
      if (hint) {
        ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        let y = U.clamp(ctlTop - 30, 172, cv.h * 0.6);
        if (revealOn()) { y = Math.max(y, revealBottom() + 19); ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; } // keep clear of the track card
        const tw = Math.min(cv.w - 24, ctx.measureText(hint).width + 20);
        ctx.fillStyle = 'rgba(23,19,31,.78)'; rr(ctx, cv.w / 2 - tw / 2, y - 13, tw, 26, 13); ctx.fill();
        ctx.fillStyle = '#f2e9d8'; ctx.fillText(hint, cv.w / 2, y, cv.w - 36);
      }
      // countdown
      if (phase === 'count' || goT > 0) {
        let txt, fr;
        if (phase === 'count') { const n = Math.max(1, Math.ceil(cd)); txt = String(n); fr = cd - Math.floor(cd); if (fr === 0) fr = 1; }
        else { txt = 'GO!'; fr = goT; }
        const s = 1 + (1 - fr) * 0.25;
        ctx.save(); ctx.translate(cv.w / 2, Math.max(58, carY() - 100)); ctx.scale(s, s);
        ctx.globalAlpha = Math.min(1, 0.3 + fr);
        ctx.font = '96px "Black Han Sans", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 8; ctx.strokeStyle = 'rgba(23,19,31,.85)'; ctx.strokeText(txt, 0, 0);
        ctx.fillStyle = txt === 'GO!' ? '#5fd3a0' : '#e3ae45'; ctx.fillText(txt, 0, 0);
        ctx.restore();
      }
      if (phase === 'grid' && (pick ? pick.el.offsetTop : cv.h) > 190) { // track title card above the picker (skipped when the picker leaves no room)
        const ty = U.clamp((pick ? pick.el.offsetTop : cv.h) - 64, 120, cv.h * 0.22);
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = '30px "Black Han Sans", sans-serif'; ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(23,19,31,.85)';
        ctx.strokeText(tr.name, cv.w / 2, ty); ctx.fillStyle = '#f2e9d8'; ctx.fillText(tr.name, cv.w / 2, ty);
        ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.lineWidth = 4; ctx.strokeText(tr.D.sub + ' · ' + LAPS + '랩', cv.w / 2, ty + 28, cv.w - 24);
        ctx.fillStyle = '#e3ae45'; ctx.fillText(tr.D.sub + ' · ' + LAPS + '랩', cv.w / 2, ty + 28, cv.w - 24);
        hintCard(cv.w / 2, ty + 54, 1);
      } else if (phase === 'count' || (phase === 'race' && W.clock < 3.5)) { // reveal the track (and its gimmick) as the countdown begins
        const ty = revealTy(), a = phase === 'count' ? U.clamp((3 - cd) * 3, 0, 1) : U.clamp((3.5 - W.clock) * 2, 0, 1);
        ctx.globalAlpha = a; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.font = '700 11px "IBM Plex Sans KR", sans-serif'; const lab = st && st.pk === -2 ? '새 코스 공개 · ' + (tr.D.gen ? genTheme(tr.D).n : '') : st && st.pk === -1 ? '무작위 트랙 공개' : '트랙';
        ctx.fillStyle = 'rgba(23,19,31,.8)'; const nw = Math.max(150, Math.min(cv.w - 24, tr.name.length * 26 + 40));
        rr(ctx, cv.w / 2 - nw / 2, ty - 22, nw, 50, 14); ctx.fill();
        ctx.fillStyle = '#e3ae45'; ctx.fillText(lab, cv.w / 2, ty - 9);
        ctx.font = '24px "Black Han Sans", sans-serif'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(tr.name, cv.w / 2, ty + 12);
        hintCard(cv.w / 2, ty + 42, a);
        ctx.globalAlpha = 1;
      }
    }
    /* undersea current: chevrons sliding sideways across the road */
    const onScreen = (x, y, m) => { const R = Math.max(cv.w, cv.h) / cam.sc * 0.75 + (m || 0); return (x - cam.x) ** 2 + (y - cam.y) ** 2 < R * R; };
    function drawFlow(now) {
      if (!tr.D.flow) return;
      const t = (now / 1000) % 1;
      ctx.strokeStyle = 'rgba(150,230,255,.5)'; ctx.lineWidth = 0.4; ctx.lineCap = 'round';
      for (let i = 0; i < NS; i += 5) {
        const fl = tr.flow[i];
        if (!fl || !onScreen(tr.x[i], tr.y[i], 8)) continue;
        const sg = Math.sign(fl);
        for (let k = 0; k < 3; k++) {
          const l = (((k / 3 + t) % 1) * 2 - 1) * (tr.half - 1) * sg, px = tr.x[i] + tr.nx[i] * l, py = tr.y[i] + tr.ny[i] * l;
          const ax = tr.nx[i] * sg, ay = tr.ny[i] * sg;
          ctx.beginPath(); ctx.moveTo(px - ax * 0.8 + tr.tx[i] * 0.9, py - ay * 0.8 + tr.ty[i] * 0.9); ctx.lineTo(px, py); ctx.lineTo(px - ax * 0.8 - tr.tx[i] * 0.9, py - ay * 0.8 - tr.ty[i] * 0.9); ctx.stroke();
        }
      }
    }
    /* level crossing: barrier arms drop and red lamps flash while a train is due */
    function gateClosed(Tn, X) { const f = trainFront(Tn, W.clock); return f != null && f + Tn.v * 2.2 >= X.s - X.mr && f - Tn.len <= X.s + X.mr + 3; }
    function drawGates(now) {
      for (const Tn of tr.trains) for (const X of Tn.cross) {
        const shut = W.racing && gateClosed(Tn, X), blink = Math.floor(now / 300) % 2, hl = tr.half / X.sn + 1.5;
        for (const sd of [-1, 1]) {
          const bx = Tn.ax + Tn.ux * X.s + Tn.nx * sd * (TRAIN_W + 3.2), by = Tn.ay + Tn.uy * X.s + Tn.ny * sd * (TRAIN_W + 3.2);
          const px = bx - Tn.ux * hl * sd, py = by - Tn.uy * hl * sd; // post at one road edge
          ctx.lineCap = 'butt';
          if (shut) { // arm across the road: red / white
            ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px + Tn.ux * hl * 2 * sd, py + Tn.uy * hl * 2 * sd); ctx.stroke();
            ctx.strokeStyle = '#e8384f'; ctx.setLineDash([1.2, 1.2]); ctx.stroke(); ctx.setLineDash([]);
          } else { ctx.strokeStyle = '#e8384f'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(px - Tn.ux * 1.6 * sd, py - Tn.uy * 1.6 * sd); ctx.stroke(); }
          ctx.lineCap = 'round';
          ctx.fillStyle = '#2b2533'; ctx.beginPath(); ctx.arc(px, py, 0.9, 0, 7); ctx.fill();
          ctx.fillStyle = shut ? (blink ? '#ff4040' : '#5a1a1a') : '#3a2a2a'; ctx.beginPath(); ctx.arc(px, py, 0.55, 0, 7); ctx.fill();
          if (shut && blink) { ctx.fillStyle = 'rgba(255,64,64,.25)'; ctx.beginPath(); ctx.arc(px, py, 2.2, 0, 7); ctx.fill(); }
        }
      }
    }
    function drawTrain() {
      for (const Tn of tr.trains) {
        const f = W.racing ? trainFront(Tn, W.clock) : null;
        if (f == null) continue;
        const ang = Math.atan2(Tn.uy, Tn.ux), cars = [[0, 11, '#2f6fb0'], [12, 11.5, '#d8d0c2'], [24.5, 11.5, '#d8d0c2'], [37, 11.5, '#d8d0c2']];
        for (const [o, l, col] of cars) {
          const s0 = f - o; if (s0 - l > Tn.L + 2 || s0 < -2) continue;
          const cx = Tn.ax + Tn.ux * (s0 - l / 2), cy = Tn.ay + Tn.uy * (s0 - l / 2);
          ctx.save(); ctx.translate(cx, cy); ctx.rotate(ang);
          ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(ctx, -l / 2 + 0.6, -TRAIN_W + 1, l, TRAIN_W * 2, 1); ctx.fill();
          ctx.fillStyle = col; rr(ctx, -l / 2, -TRAIN_W, l, TRAIN_W * 2, o ? 0.8 : 1.4); ctx.fill();
          ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 0.2; ctx.stroke();
          ctx.fillStyle = o ? '#2f6fb0' : '#e8c04e'; ctx.fillRect(-l / 2 + 0.5, -0.35, l - 1, 0.7);
          if (!o) { ctx.fillStyle = '#1b2230'; rr(ctx, l / 2 - 3, -TRAIN_W + 0.5, 2, TRAIN_W * 2 - 1, 0.5); ctx.fill(); ctx.fillStyle = '#fff6c8'; ctx.beginPath(); ctx.arc(l / 2 - 0.3, -1.4, 0.35, 0, 7); ctx.arc(l / 2 - 0.3, 1.4, 0.35, 0, 7); ctx.fill(); }
          else for (let k = -l / 2 + 1.5; k < l / 2 - 1; k += 2.2) { ctx.fillStyle = 'rgba(40,60,90,.55)'; ctx.fillRect(k, -TRAIN_W + 0.35, 1.4, 0.5); ctx.fillRect(k, TRAIN_W - 0.85, 1.4, 0.5); }
          ctx.restore();
        }
      }
    }
    /* screen-space weather: sandstorm, cave darkness (headlights + lamps), smoke in your eyes, falling petals, bubbles */
    let fogK = 0, darkCv = null, flakes = null;
    function drawWeather(now, rdt) {
      const D = tr.D, fc = camTarget(), w = cv.w, h = cv.h;
      const dk = D.dark ? 0.86 : NT ? 0.74 : D.dusk && W.racing ? 0.82 * U.clamp((W.clock - 15) / 105, 0, 1) : 0;
      if (D.dusk && W.clock < 70) { ctx.fillStyle = 'rgba(255,140,60,' + 0.16 * U.clamp(1 - Math.abs(W.clock - 25) / 45, 0, 1) + ')'; ctx.fillRect(0, 0, w, h); } // sunset glow
      if (dk > 0.02) {
        if (!darkCv) darkCv = document.createElement('canvas');
        const dpr = cv.dpr || 1, W2 = Math.round(w * dpr), H2 = Math.round(h * dpr);
        if (darkCv.width !== W2 || darkCv.height !== H2) { darkCv.width = W2; darkCv.height = H2; }
        const d = darkCv.getContext('2d');
        d.setTransform(1, 0, 0, 1, 0, 0); d.globalCompositeOperation = 'source-over'; d.clearRect(0, 0, W2, H2);
        d.fillStyle = D.dusk || (NT && !D.dark) ? 'rgba(8,10,28,' + dk + ')' : 'rgba(6,4,3,.86)'; d.fillRect(0, 0, W2, H2);
        d.setTransform(dpr, 0, 0, dpr, 0, 0); d.globalCompositeOperation = 'destination-out';
        applyCam(d);
        const glow = (x, y, r, a) => { const g = d.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(0,0,0,' + a + ')'); g.addColorStop(1, 'rgba(0,0,0,0)'); d.fillStyle = g; d.beginPath(); d.arc(x, y, r, 0, 7); d.fill(); };
        for (const c of W.cars) {
          if (c.resp > 0 || !onScreen(c.x, c.y, 32)) continue;
          glow(c.x, c.y, 7, 0.9);
          d.save(); d.translate(c.x, c.y); d.rotate(c.a);
          const g = d.createLinearGradient(1, 0, 30, 0); g.addColorStop(0, 'rgba(0,0,0,.95)'); g.addColorStop(1, 'rgba(0,0,0,0)');
          d.fillStyle = g; d.beginPath(); d.moveTo(1.5, -1.4); d.lineTo(30, -10); d.lineTo(30, 10); d.lineTo(1.5, 1.4); d.fill();
          if (NT) { d.fillStyle = 'rgba(0,0,0,.6)'; d.beginPath(); d.arc(-2.4, 0, 2.2, 0, 7); d.fill(); } // tail-light spill
          d.restore();
        }
        for (let i = 0; i < NS; i += 14) if (onScreen(tr.x[i], tr.y[i], 10)) for (const sd of [-1, 1]) glow(tr.x[i] + tr.nx[i] * sd * (tr.half + 1), tr.y[i] + tr.ny[i] * sd * (tr.half + 1), 6, 0.55);
        for (const b of tr.boxes) if (boxUp(W, b.id)) glow(b.x, b.y, 3, 0.7);
        ctx.drawImage(darkCv, 0, 0, w, h);
        // the lamps themselves
        ctx.save(); applyCam(ctx);
        for (let i = 0; i < NS; i += 14) if (onScreen(tr.x[i], tr.y[i], 10)) for (const sd of [-1, 1]) { const px = tr.x[i] + tr.nx[i] * sd * (tr.half + 1), py = tr.y[i] + tr.ny[i] * sd * (tr.half + 1); ctx.fillStyle = 'rgba(255,200,110,.9)'; ctx.beginPath(); ctx.arc(px, py, 0.45, 0, 7); ctx.fill(); }
        if (NT) for (const c of W.cars) { // red tail lights on every car
          if (c.resp > 0 || !onScreen(c.x, c.y, 12)) continue;
          const ca = Math.cos(c.a), sa = Math.sin(c.a);
          for (const sd of [-0.8, 0.8]) { const px = c.x - ca * 2.3 - sa * sd, py = c.y - sa * 2.3 + ca * sd; ctx.fillStyle = 'rgba(255,40,40,.35)'; ctx.beginPath(); ctx.arc(px, py, 0.9, 0, 7); ctx.fill(); ctx.fillStyle = '#ff3a3a'; ctx.beginPath(); ctx.arc(px, py, 0.35, 0, 7); ctx.fill(); }
        }
        if (NT && !D.dark) for (let i = 7; i < NS; i += 14) if (onScreen(tr.x[i], tr.y[i], 10)) for (const sd of [-1, 1]) { const px = tr.x[i] + tr.nx[i] * sd * (tr.half + 0.3), py = tr.y[i] + tr.ny[i] * sd * (tr.half + 0.3); ctx.fillStyle = 'rgba(255,255,255,.75)'; ctx.fillRect(px - 0.25, py - 0.25, 0.5, 0.5); } // edge reflectors
        ctx.restore();
      }
      if (D.fog) { // sandstorm: thick haze, a small clear bubble around the car
        const want = fc && tr.fog[fc.idx] ? 1 : fc && (tr.fog[(fc.idx + 20) % NS] || tr.fog[(fc.idx + NS - 10) % NS]) ? 0.45 : 0;
        fogK += (want - fogK) * (1 - Math.exp(-rdt * 2.5));
        if (fogK > 0.01) {
          const p = fc ? toScreen(fc.x, fc.y) : { x: w / 2, y: h / 2 }, r0 = Math.min(w, h) * 0.12, r1 = Math.min(w, h) * 0.55;
          const g = ctx.createRadialGradient(p.x, p.y, r0, p.x, p.y, r1);
          g.addColorStop(0, 'rgba(214,166,94,' + 0.15 * fogK + ')'); g.addColorStop(1, 'rgba(196,146,78,' + 0.92 * fogK + ')');
          ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
          ctx.strokeStyle = 'rgba(255,235,190,' + 0.35 * fogK + ')'; ctx.lineWidth = 1.2;
          for (let k = 0; k < 26; k++) { const y = (k * 97 + now * 0.05 * (1 + k % 3)) % h, x = (k * 131 + now * 0.4 * (1 + (k % 4) * 0.4)) % (w + 80) - 40; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 30 + (k % 5) * 6, y + 4); ctx.stroke(); }
        }
      }
      const c0 = me();
      if (c0 && c0.blind > 0) { // smoke in the eyes
        const k = U.clamp(c0.blind / 0.6, 0, 1), p = toScreen(c0.x, c0.y);
        const g = ctx.createRadialGradient(p.x, p.y, 20, p.x, p.y, Math.max(w, h) * 0.6);
        g.addColorStop(0, 'rgba(150,155,170,' + 0.3 * k + ')'); g.addColorStop(1, 'rgba(110,115,130,' + 0.93 * k + ')');
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 7; i++) { const x = (i * 71 + now * 0.02 * (i % 2 ? 1 : -1)) % w, y = (i * 113) % (h * 0.7) + 40; ctx.fillStyle = 'rgba(200,205,215,' + 0.35 * k + ')'; ctx.beginPath(); ctx.arc((x + w) % w, y, 40 + (i % 3) * 18, 0, 7); ctx.fill(); }
      }
      if (D.th === 'blossom' || D.th === 'sea') { // drifting petals / rising bubbles
        if (!flakes) flakes = Array.from({ length: 26 }, (_, i) => ({ x: Math.random(), y: Math.random(), s: 0.6 + Math.random() * 0.8, p: Math.random() * 7 }));
        const up = D.th === 'sea';
        for (const f of flakes) {
          f.y += (up ? -1 : 1) * rdt * 0.06 * f.s; f.x += Math.sin(now / 900 + f.p) * rdt * 0.02;
          if (f.y > 1.05) f.y = -0.05; if (f.y < -0.05) f.y = 1.05;
          const x = ((f.x % 1) + 1) % 1 * w, y = f.y * h;
          if (up) { ctx.strokeStyle = 'rgba(200,245,255,.35)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(x, y, 2 + f.s * 2, 0, 7); ctx.stroke(); }
          else { ctx.save(); ctx.translate(x, y); ctx.rotate(now / 700 * f.s + f.p); ctx.fillStyle = 'rgba(255,195,220,.85)'; ctx.beginPath(); ctx.ellipse(0, 0, 3.4 * f.s, 2 * f.s, 0, 0, 7); ctx.fill(); ctx.restore(); }
        }
      }
    }
    /* ----- round 9 live layers ----- */
    const TCOLS = ['#f2c230', '#9aa0a8', '#2f8f7a', '#f2ede4', '#8a5a3a'];
    function drawGim(now) { // on the ground, under the cars
      const t = W.clock, half = tr.half;
      // disco: the three colour lanes, pulsing on the beat
      for (const D2 of tr.disco) { // batched: one fill per colour (and per pulse phase)
        const rows = Math.floor(((D2.i1 - D2.i0) * tr.ds) / DISCO_L), cw = (half * 2) / 3, beat = (Math.max(0, t + D2.off) / D2.per) % 1, warn = beat > 0.82 && Math.floor(now / 90) % 2;
        const jm = (D2.i0 + Math.round((D2.i1 - D2.i0) / 2)) % NS;
        if (!onScreen(tr.x[jm], tr.y[jm], rows * DISCO_L * 0.6 + 6)) continue;
        const qc = [0, 1, 2].map((q) => discoCol(D2, q, t)), flip = Math.floor(now / 120) % 2;
        for (const [col, fillc, a0] of [[0, '#3dff9a', 0.42], [2, '#ff4060', 0.42], [1, '#8a5cff', 0.2]]) {
          const q = qc.indexOf(col);
          for (let ph = 0; ph < 2; ph++) {
            ctx.beginPath();
            for (let r = ph; r < rows; r += 2) {
              const j = (D2.i0 + Math.round(((r + 0.5) * DISCO_L) / tr.ds)) % NS;
              if (onScreen(tr.x[j], tr.y[j], 6)) quadPath(ctx, tr, D2.i0, r * DISCO_L + 0.2, (r + 1) * DISCO_L - 0.2, -half + q * cw + 0.2, -half + (q + 1) * cw - 0.2, true);
            }
            ctx.fillStyle = fillc; ctx.globalAlpha = a0 * (warn ? 0.4 : 1) + (col === 0 ? 0.25 * (1 - beat) * ((ph + flip) % 2 ? 1 : 0.6) : 0); ctx.fill();
          }
        }
        ctx.globalAlpha = 0.85; ctx.lineWidth = 0.4;
        for (const col of [0, 2]) {
          const q = qc.indexOf(col), l = -half + (q + 0.5) * cw;
          ctx.strokeStyle = col === 0 ? '#c8ffe0' : '#ffd0d8'; ctx.beginPath();
          for (let r = 0; r < rows; r += 4) {
            const j = (D2.i0 + Math.round(((r + 0.5) * DISCO_L) / tr.ds)) % NS, cx = tr.x[j] + tr.nx[j] * l, cy = tr.y[j] + tr.ny[j] * l, ux = tr.tx[j], uy = tr.ty[j], vx = tr.nx[j], vy = tr.ny[j];
            if (!onScreen(cx, cy, 4)) continue;
            const P2 = (a, b) => [cx + ux * a + vx * b, cy + uy * a + vy * b];
            const seg = (pts) => { pts.forEach(([a, b], k) => { const [x, y] = P2(a, b); k ? ctx.lineTo(x, y) : ctx.moveTo(x, y); }); };
            if (col === 0) { seg([[-0.6, -1], [0.5, 0], [-0.6, 1]]); seg([[0.4, -1], [1.5, 0], [0.4, 1]]); } else { seg([[-1, -1], [1, 1]]); seg([[1, -1], [-1, 1]]); }
          }
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
      // collapsing floor: cracks, then a dark hole
      for (const S of tr.tiles) {
        const jm = (S.i0 + Math.round((S.rows * TILE_L) / 2 / tr.ds)) % NS;
        if (!onScreen(tr.x[jm], tr.y[jm], S.rows * TILE_L)) continue;
        for (let r = 0; r < S.rows; r++) for (let q = 0; q < 3; q++) {
          const st2 = W.racing ? tileState(tr, S, r, q, t) : 0;
          if (!st2) continue;
          if (st2 === 2) {
            tilePath(ctx, tr, S, r, q, 0.1); ctx.fillStyle = '#0e0906'; ctx.fill();
            tilePath(ctx, tr, S, r, q, 0.7); ctx.fillStyle = '#000'; ctx.fill();
            tilePath(ctx, tr, S, r, q, 0.1); ctx.strokeStyle = 'rgba(255,190,90,.35)'; ctx.lineWidth = 0.25; ctx.stroke();
          } else {
            const sh = Math.sin(now / 25 + r * 3 + q) * 0.12;
            ctx.save(); ctx.translate(sh, -sh);
            tilePath(ctx, tr, S, r, q, 0.12); ctx.fillStyle = 'rgba(40,20,10,.25)'; ctx.fill(); ctx.strokeStyle = Math.floor(now / 110) % 2 ? '#ff6a3d' : '#ffd166'; ctx.lineWidth = 0.35; ctx.stroke();
            const cw = (half * 2) / 3, j = (S.i0 + Math.round(((r + 0.5) * TILE_L) / tr.ds)) % NS, l = -half + (q + 0.5) * cw, cx = tr.x[j] + tr.nx[j] * l, cy = tr.y[j] + tr.ny[j] * l;
            ctx.strokeStyle = 'rgba(20,10,5,.85)'; ctx.lineWidth = 0.22; ctx.beginPath();
            for (let k = 0; k < 5; k++) { const a = k * 1.3 + r, L2 = 1.2 + (k % 3) * 0.6; ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(a) * L2, cy + Math.sin(a) * L2); ctx.lineTo(cx + Math.cos(a + 0.4) * L2 * 1.5, cy + Math.sin(a + 0.4) * L2 * 1.5); }
            ctx.stroke(); ctx.restore();
          }
        }
      }
      // falling rocks: the shadow grows, then the boulder sits there until it crumbles
      if (tr.rock && W.racing) {
        const R = tr.rock, k1 = Math.floor((t - R.off) / R.per);
        for (let k = Math.max(0, k1 - Math.ceil((R.warn + R.life) / R.per) - 1); k <= k1; k++) {
          const age = t - rockT0(R, k);
          if (age < 0 || age > R.warn + R.life) continue;
          rockWave(tr, k).forEach((q, j) => {
            if (!onScreen(q.x, q.y, 8)) return;
            if (age < R.warn) { const f = age / R.warn; ctx.fillStyle = 'rgba(30,15,5,' + (0.15 + 0.45 * f) + ')'; ctx.beginPath(); ctx.ellipse(q.x, q.y, R.r * (0.5 + 0.6 * f), R.r * (0.4 + 0.5 * f), 0, 0, 7); ctx.fill(); if (f > 0.5 && Math.floor(now / 100) % 2) { ctx.strokeStyle = 'rgba(255,120,60,.8)'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.arc(q.x, q.y, R.r + 0.6, 0, 7); ctx.stroke(); } }
            else { const left = R.warn + R.life - age, a = left < 0.5 ? left / 0.5 : 1; drawBoulder(q.x, q.y, R.r * (left < 0.5 ? 0.6 + 0.4 * a : 1), k * 7 + j, a); }
          });
        }
      }
      // snowballs: the warning arrow on the uphill side, and the slush left behind
      for (const B of tr.balls) {
        if (!onScreen(B.x, B.y, B.L + 6)) continue;
        const st2 = W.racing ? ballAt(B, t) : null;
        if (!st2) continue;
        if (st2.tau < 0) { // warning: blinking arrow at the road edge pointing across
          if (Math.floor(now / 140) % 2) continue;
          const o = B.side * (half + 1.6), px = B.x + tr.nx[B.i] * o, py = B.y + tr.ny[B.i] * o;
          ctx.save(); ctx.translate(px, py); ctx.rotate(Math.atan2(-tr.ny[B.i] * B.side, -tr.nx[B.i] * B.side));
          ctx.fillStyle = '#ff6a3d'; ctx.beginPath(); ctx.moveTo(1.8, 0); ctx.lineTo(-0.6, -1.6); ctx.lineTo(-0.6, -0.6); ctx.lineTo(-1.8, -0.6); ctx.lineTo(-1.8, 0.6); ctx.lineTo(-0.6, 0.6); ctx.lineTo(-0.6, 1.6); ctx.closePath(); ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 0.2; ctx.stroke(); ctx.restore();
        } else {
          const l0 = B.side * B.L, fade = st2.tau > st2.dur ? U.clamp(1 - (st2.tau - st2.dur) / SLUSH_T, 0, 1) : 1;
          ctx.globalAlpha = 0.85 * fade; ctx.strokeStyle = '#f4f9ff'; ctx.lineWidth = 4.6; ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(B.x + tr.nx[B.i] * l0, B.y + tr.ny[B.i] * l0); ctx.lineTo(B.x + tr.nx[B.i] * st2.lat, B.y + tr.ny[B.i] * st2.lat); ctx.stroke();
          ctx.globalAlpha = 1;
        }
      }
      // beach waves: a foam line sweeping across the causeway
      if (tr.waves) {
        const V = tr.waves;
        V.zones.forEach(([a, b], z) => {
          const wf = waveFront(tr, z + 1, t);
          if (!wf) return;
          const i0 = Math.round(a * NS), i1 = Math.round(b * NS), jm = Math.round((i0 + i1) / 2) % NS;
          if (!onScreen(tr.x[jm], tr.y[jm], (i1 - i0) * tr.ds * 0.6)) return;
          const line = (off) => { ctx.beginPath(); for (let i = i0; i <= i1; i += 2) { const j = i % NS, px = tr.x[j] + tr.nx[j] * off, py = tr.y[j] + tr.ny[j] * off; i === i0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py); } };
          ctx.lineCap = 'round';
          line(wf.f + wf.sd * 1.6); ctx.strokeStyle = 'rgba(80,170,220,.45)'; ctx.lineWidth = 3.6; ctx.stroke();
          line(wf.f); ctx.strokeStyle = 'rgba(240,250,255,.85)'; ctx.lineWidth = V.w * 1.1; ctx.stroke();
          line(wf.f - wf.sd * 0.6); ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.4; ctx.setLineDash([0.8, 1.4]); ctx.lineDashOffset = -now / 60; ctx.stroke(); ctx.setLineDash([]);
        });
      }
      // geysers: bubbling glow while they charge
      for (const g of tr.gey) {
        if (!onScreen(g.x, g.y, 6)) continue;
        const st2 = W.racing ? geyS(g, t) : 0;
        if (st2 === 1) { const u = (t - g.off) - geyK(g, t) * g.per, f = U.clamp(u / GEY_WARN, 0, 1); ctx.fillStyle = 'rgba(255,' + Math.round(120 + 80 * f) + ',40,' + (0.25 + 0.5 * f * (0.6 + 0.4 * Math.sin(now / 60))) + ')'; ctx.beginPath(); ctx.arc(g.x, g.y, GEY_R * (0.6 + 0.4 * f), 0, 7); ctx.fill(); for (let k = 0; k < 4; k++) { const a = now / 300 + k * 1.6, r = GEY_R * 0.5 * ((now / 400 + k * 0.3) % 1); ctx.fillStyle = 'rgba(255,220,140,.7)'; ctx.beginPath(); ctx.arc(g.x + Math.cos(a) * r, g.y + Math.sin(a) * r, 0.3, 0, 7); ctx.fill(); } }
      }
      // electromagnets: the pull circle on the ground
      for (const m of tr.mag) {
        if (!onScreen(m.x, m.y, MAG_R + 4)) continue;
        const st2 = W.racing ? magS(m, t) : 0;
        if (!st2) continue;
        ctx.strokeStyle = st2 === 2 ? 'rgba(90,170,255,' + (0.55 + 0.25 * Math.sin(now / 80)) + ')' : (Math.floor(now / 120) % 2 ? 'rgba(255,209,102,.9)' : 'rgba(255,209,102,.2)');
        ctx.lineWidth = 0.45; ctx.setLineDash([1.2, 0.9]); ctx.lineDashOffset = st2 === 2 ? now / 50 : 0; ctx.beginPath(); ctx.arc(m.x, m.y, MAG_R, 0, 7); ctx.stroke(); ctx.setLineDash([]);
        if (st2 === 2) { ctx.fillStyle = 'rgba(90,170,255,.1)'; ctx.beginPath(); ctx.arc(m.x, m.y, MAG_R, 0, 7); ctx.fill(); for (let k = 0; k < 3; k++) { const r = MAG_R * (1 - ((now / 700 + k / 3) % 1)); ctx.strokeStyle = 'rgba(120,190,255,.4)'; ctx.lineWidth = 0.25; ctx.beginPath(); ctx.arc(m.x, m.y, r, 0, 7); ctx.stroke(); } }
      }
      // swing bridges: the deck turns on its pivot; lights at both banks
      for (const R of tr.rivers) {
        const S2 = R.sw;
        if (!S2 || !onScreen(S2.x, S2.y, 20)) continue;
        const th = swingAng(S2, t), a = S2.a + th, hl = R.w + 2.6;
        ctx.save(); ctx.translate(S2.x, S2.y); ctx.rotate(a);
        ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fillRect(-hl + 0.5, -SW_BW + 0.8, hl * 2, SW_BW * 2);
        ctx.fillStyle = '#6d4a2c'; ctx.fillRect(-hl, -SW_BW, hl * 2, SW_BW * 2);
        ctx.fillStyle = '#8f6a43'; ctx.fillRect(-hl, -SW_BW + 0.5, hl * 2, SW_BW * 2 - 1);
        ctx.strokeStyle = 'rgba(50,25,10,.45)'; ctx.lineWidth = 0.15; for (let x = -hl + 0.6; x < hl; x += 0.9) { ctx.beginPath(); ctx.moveTo(x, -SW_BW + 0.5); ctx.lineTo(x, SW_BW - 0.5); ctx.stroke(); }
        ctx.fillStyle = '#3d3a40'; ctx.fillRect(-hl, -SW_BW - 0.3, hl * 2, 0.6); ctx.fillRect(-hl, SW_BW - 0.3, hl * 2, 0.6);
        ctx.fillStyle = '#2b2533'; ctx.beginPath(); ctx.arc(0, 0, 1.2, 0, 7); ctx.fill(); ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(0, 0, 0.5, 0, 7); ctx.fill();
        ctx.restore();
        // traffic lights on both banks
        const tau = ((((t + S2.off) % S2.per) + S2.per) % S2.per), o = S2.per * SW_OPEN, open = th < 0.12, soon = open && tau < o && o - tau < 1.3;
        const col = !W.racing || (open && !soon) ? '#5fd3a0' : soon ? '#ffb347' : '#ff4040';
        for (const sd of [-1, 1]) {
          const px = S2.x - Math.cos(S2.a) * sd * (R.w + 1.6) + tr.nx[S2.i] * (half + 1.4), py = S2.y - Math.sin(S2.a) * sd * (R.w + 1.6) + tr.ny[S2.i] * (half + 1.4);
          ctx.fillStyle = '#2b2533'; ctx.fillRect(px - 0.8, py - 0.8, 1.6, 1.6);
          ctx.fillStyle = col; ctx.beginPath(); ctx.arc(px, py, 0.55, 0, 7); ctx.fill();
          ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(px, py, 1.8, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          if (!open || soon) { // a stop line across the road before the bank
            const lx = S2.x - Math.cos(S2.a) * sd * (R.w + 1.2), ly = S2.y - Math.sin(S2.a) * sd * (R.w + 1.2);
            ctx.strokeStyle = col; ctx.globalAlpha = 0.7; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(lx - tr.nx[S2.i] * half, ly - tr.ny[S2.i] * half); ctx.lineTo(lx + tr.nx[S2.i] * half, ly + tr.ny[S2.i] * half); ctx.stroke(); ctx.globalAlpha = 1;
          }
        }
      }
      // foundry: the sliding platforms over the molten channels
      for (const R of tr.rivers) {
        if (!R.mv) continue;
        const i = R.ci;
        if (!onScreen(tr.x[i], tr.y[i], 16)) continue;
        for (const L2 of R.lanes) {
          const l = laneAt(R, L2, t), px = tr.x[i] + tr.nx[i] * l, py = tr.y[i] + tr.ny[i] * l;
          ctx.save(); ctx.translate(px, py); ctx.rotate(tr.hd[i]);
          ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.fillRect(-R.w - 1 + 0.4, -L2[1] + 0.6, (R.w + 1) * 2, L2[1] * 2);
          ctx.fillStyle = '#5a5e66'; ctx.fillRect(-R.w - 1, -L2[1], (R.w + 1) * 2, L2[1] * 2);
          ctx.strokeStyle = '#2b2d33'; ctx.lineWidth = 0.15; for (let x = -R.w - 0.6; x < R.w + 1; x += 0.7) { ctx.beginPath(); ctx.moveTo(x, -L2[1]); ctx.lineTo(x, L2[1]); ctx.stroke(); }
          ctx.fillStyle = '#f2c230'; ctx.fillRect(-R.w - 1, -L2[1], (R.w + 1) * 2, 0.35); ctx.fillRect(-R.w - 1, L2[1] - 0.35, (R.w + 1) * 2, 0.35);
          ctx.restore();
        }
      }
      // magic doors: glowing swirl while lit
      for (const P2 of tr.ports) {
        if (!onScreen(P2.x, P2.y, 8) && !onScreen(P2.ex, P2.ey, 8)) continue;
        const on = W.racing && portOn(P2, t);
        for (const [px, py, big] of [[P2.x, P2.y, 1], [P2.ex, P2.ey, 0]]) {
          const r = big ? PORT_R + 0.3 : PORT_R - 0.4;
          if (!on) { ctx.fillStyle = 'rgba(40,30,60,.35)'; ctx.beginPath(); ctx.arc(px, py, r, 0, 7); ctx.fill(); continue; }
          const g = ctx.createRadialGradient(px, py, 0.2, px, py, r + 0.8); g.addColorStop(0, big ? 'rgba(220,200,255,.95)' : 'rgba(200,240,255,.8)'); g.addColorStop(0.6, big ? 'rgba(150,90,240,.7)' : 'rgba(80,180,240,.6)'); g.addColorStop(1, 'rgba(120,80,240,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(px, py, r + 0.8, 0, 7); ctx.fill();
          ctx.strokeStyle = big ? '#f0e6ff' : '#dff6ff'; ctx.lineWidth = 0.25;
          for (let k = 0; k < 3; k++) { ctx.beginPath(); for (let q = 0; q <= 12; q++) { const a = now / (big ? 160 : -200) + k * 2.1 + q * 0.35, rr2 = r * (q / 12); ctx.lineTo(px + Math.cos(a) * rr2, py + Math.sin(a) * rr2); } ctx.stroke(); }
        }
      }
      // turntables: the turning ring and arrows
      for (const q of tr.turn) {
        if (!onScreen(q.x, q.y, q.R + 4)) continue;
        const a0 = q.w * t;
        ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(a0);
        ctx.strokeStyle = 'rgba(227,174,69,.85)'; ctx.lineWidth = 0.5;
        for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2; ctx.beginPath(); ctx.arc(0, 0, q.R - 2.4, a + 0.2, a + 1.2); ctx.stroke(); const ex = Math.cos(a + 1.2) * (q.R - 2.4), ey = Math.sin(a + 1.2) * (q.R - 2.4), sg = q.w > 0 ? 1 : -1; ctx.save(); ctx.translate(ex, ey); ctx.rotate(a + 1.2 + Math.PI / 2 * sg); ctx.fillStyle = 'rgba(227,174,69,.9)'; ctx.beginPath(); ctx.moveTo(0.9, 0); ctx.lineTo(-0.5, -0.8); ctx.lineTo(-0.5, 0.8); ctx.fill(); ctx.restore(); }
        if (q.w < 0) { /* arrows drawn the other way already by the sign above */ }
        ctx.strokeStyle = 'rgba(242,233,216,.25)'; ctx.lineWidth = 0.3; for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; ctx.beginPath(); ctx.moveTo(Math.cos(a) * 1.2, Math.sin(a) * 1.2); ctx.lineTo(Math.cos(a) * (q.R * 0.45), Math.sin(a) * (q.R * 0.45)); ctx.stroke(); }
        ctx.restore();
      }
      // tornado: dust swirl on the ground
      for (const T2 of tr.tw) {
        const p2 = twPos(tr, T2, t);
        if (!onScreen(p2.x, p2.y, TW_PULL + 4)) continue;
        const g = ctx.createRadialGradient(p2.x, p2.y, 0.5, p2.x, p2.y, TW_PULL);
        g.addColorStop(0, 'rgba(90,80,70,.4)'); g.addColorStop(0.5, 'rgba(150,130,100,.18)'); g.addColorStop(1, 'rgba(150,130,100,0)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p2.x, p2.y, TW_PULL, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(230,220,190,.45)'; ctx.lineWidth = 0.25;
        for (let k = 0; k < 4; k++) { const a = -now / 160 + k * Math.PI / 2; ctx.beginPath(); ctx.arc(p2.x, p2.y, TW_PULL * (0.45 + 0.13 * k), a, a + 1.4); ctx.stroke(); }
      }
      // city traffic
      if (tr.traffic) for (const m of trafficCars(tr, t)) {
        if (!onScreen(m.x, m.y, 6)) continue;
        ctx.save(); ctx.translate(m.x, m.y); ctx.rotate(m.a);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; rr(ctx, -TCAR_HX + 0.4, -TCAR_HY + 0.6, TCAR_HX * 2, TCAR_HY * 2, 0.6); ctx.fill();
        const col = TCOLS[m.k % TCOLS.length], bus = m.k === 2;
        ctx.fillStyle = col; rr(ctx, -TCAR_HX, -TCAR_HY, TCAR_HX * 2, TCAR_HY * 2, bus ? 0.4 : 0.6); ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.lineWidth = 0.2; ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 0.15; rr(ctx, -TCAR_HX + 0.35, -TCAR_HY + 0.35, TCAR_HX * 2 - 0.7, TCAR_HY * 2 - 0.7, 0.4); ctx.stroke(); // roof line: these are city cars, not racers
        ctx.fillStyle = '#1b2230';
        if (bus) { for (let x = -TCAR_HX + 0.5; x < TCAR_HX - 0.6; x += 0.9) { ctx.fillRect(x, -TCAR_HY + 0.15, 0.6, 0.3); ctx.fillRect(x, TCAR_HY - 0.45, 0.6, 0.3); } ctx.fillRect(TCAR_HX - 0.6, -TCAR_HY + 0.3, 0.4, TCAR_HY * 2 - 0.6); }
        else { rr(ctx, 0.4, -TCAR_HY + 0.25, 1.1, TCAR_HY * 2 - 0.5, 0.3); ctx.fill(); rr(ctx, -1.8, -TCAR_HY + 0.3, 0.7, TCAR_HY * 2 - 0.6, 0.25); ctx.fill(); }
        if (m.k === 0) { ctx.fillStyle = '#2b2533'; ctx.fillRect(-0.5, -0.35, 1, 0.7); ctx.fillStyle = '#ffe066'; ctx.fillRect(-0.4, -0.25, 0.8, 0.5); } // taxi sign
        ctx.fillStyle = '#ff3b3b'; ctx.fillRect(-TCAR_HX - 0.05, -TCAR_HY + 0.2, 0.25, 0.45); ctx.fillRect(-TCAR_HX - 0.05, TCAR_HY - 0.65, 0.25, 0.45);
        ctx.fillStyle = '#fff6c8'; ctx.fillRect(TCAR_HX - 0.2, -TCAR_HY + 0.2, 0.25, 0.4); ctx.fillRect(TCAR_HX - 0.2, TCAR_HY - 0.6, 0.25, 0.4);
        if (m.k % 3 === 1 && Math.floor(now / 300) % 2) { const sd = m.lat > 0 ? -1 : 1; ctx.fillStyle = '#ffb347'; ctx.fillRect(TCAR_HX - 0.5, sd * TCAR_HY - 0.2, 0.5, 0.4); ctx.fillRect(-TCAR_HX, sd * TCAR_HY - 0.2, 0.5, 0.4); }
        ctx.restore();
      }
    }
    function drawBoulder(x, y, r, seed, a) {
      ctx.globalAlpha = a;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 0.6, y + 0.9, r, r * 0.85, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#8a5530'; ctx.beginPath();
      for (let k = 0; k < 9; k++) { const an = (k / 9) * Math.PI * 2, q = r * (0.82 + 0.25 * hash01(seed, k)); ctx.lineTo(x + Math.cos(an) * q, y + Math.sin(an) * q); }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#b4774a'; ctx.beginPath(); ctx.ellipse(x - r * 0.25, y - r * 0.3, r * 0.5, r * 0.35, -0.4, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(60,30,10,.6)'; ctx.lineWidth = 0.2; ctx.beginPath(); ctx.moveTo(x - r * 0.3, y + r * 0.1); ctx.lineTo(x + r * 0.2, y + r * 0.35); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    /* screen-space effects for round 12: seasons (lap of the car in view), paint on the windscreen, puddle spray */
    let rain12 = null, flakes12 = null;
    const SEASON = [null, ['봄', '#ffb3cf'], ['장맛비', '#7fd0ff'], ['눈길', '#ffffff']];
    function drawWeather12(now, rdt) {
      const D = tr.D, w = cv.w, h = cv.h, fc = camTarget();
      if (D.seasons && fc) {
        const sn = U.clamp(fc.crossed, 1, 3);
        if (sn === 1) { // petals drift by
          if (!flakes12) flakes12 = Array.from({ length: 22 }, () => ({ x: Math.random(), y: Math.random(), s: 0.6 + Math.random() * 0.8, p: Math.random() * 7 }));
          for (const f of flakes12) { f.y += rdt * 0.05 * f.s; f.x += Math.sin(now / 900 + f.p) * rdt * 0.02; if (f.y > 1.05) f.y = -0.05; ctx.save(); ctx.translate((((f.x % 1) + 1) % 1) * w, f.y * h); ctx.rotate(now / 700 * f.s + f.p); ctx.fillStyle = 'rgba(255,190,215,.8)'; ctx.beginPath(); ctx.ellipse(0, 0, 3 * f.s, 1.8 * f.s, 0, 0, 7); ctx.fill(); ctx.restore(); }
        } else if (sn === 2) { // summer downpour
          ctx.fillStyle = 'rgba(20,40,70,.2)'; ctx.fillRect(0, 0, w, h);
          if (!rain12) rain12 = Array.from({ length: 80 }, () => ({ x: Math.random(), y: Math.random(), s: 0.7 + Math.random() * 0.6 }));
          ctx.strokeStyle = 'rgba(190,215,245,.4)'; ctx.lineWidth = 1; ctx.beginPath();
          for (const r of rain12) { r.y += rdt * 1.7 * r.s; r.x -= rdt * 0.2 * r.s; if (r.y > 1.05) { r.y -= 1.1; r.x = Math.random() * 1.2; } if (r.x < -0.05) r.x += 1.1; const x = r.x * w, y = r.y * h; ctx.moveTo(x, y); ctx.lineTo(x - 4 * r.s, y + 15 * r.s); }
          ctx.stroke();
        } else { // snow: the world turns white and flakes fall
          ctx.fillStyle = 'rgba(235,242,255,.24)'; ctx.fillRect(0, 0, w, h);
          if (!rain12 || rain12.snow !== 1) { rain12 = Array.from({ length: 60 }, () => ({ x: Math.random(), y: Math.random(), s: 0.5 + Math.random() })); rain12.snow = 1; }
          ctx.fillStyle = 'rgba(255,255,255,.85)';
          for (const r of rain12) { r.y += rdt * 0.12 * r.s; r.x += Math.sin(now / 800 + r.s * 9) * rdt * 0.02; if (r.y > 1.03) { r.y = -0.03; r.x = Math.random(); } ctx.beginPath(); ctx.arc((((r.x % 1) + 1) % 1) * w, r.y * h, 1.2 + r.s * 1.4, 0, 7); ctx.fill(); }
        }
      }
      const c0 = me();
      if (c0 && c0.spray > 0) { // water on the windscreen
        const k = U.clamp(c0.spray / 0.5, 0, 1);
        ctx.fillStyle = 'rgba(190,230,250,' + 0.28 * k + ')'; ctx.fillRect(0, 0, w, h);
        for (let i = 0; i < 18; i++) { const x = (i * 97 + 31) % w, y = (i * 61 + Math.floor(now / 40) * 7 * (i % 3)) % (h * 0.75); ctx.fillStyle = 'rgba(230,248,255,' + 0.55 * k + ')'; ctx.beginPath(); ctx.ellipse(x, y, 4 + (i % 4) * 2, 6 + (i % 3) * 3, 0, 0, 7); ctx.fill(); }
      }
      if (c0 && c0.paint > 0) { // paint splats over the screen (they fade in the last second)
        const k = U.clamp(c0.paint, 0, 1), cols = ['rgba(209,79,216,', 'rgba(255,209,102,', 'rgba(79,227,255,'];
        const top = 60, bot = Math.max(top + 80, ctlTop > 0 ? ctlTop : h);
        for (let i = 0; i < 6; i++) {
          const x = w * (0.12 + ((i * 0.37) % 1) * 0.76), y = top + (bot - top) * (0.12 + ((i * 0.53) % 1) * 0.7), r = Math.min(w, h) * (0.08 + (i % 3) * 0.03);
          ctx.fillStyle = cols[i % 3] + 0.72 * k + ')'; ctx.beginPath();
          for (let q = 0; q < 14; q++) { const a = (q / 14) * Math.PI * 2, rr2 = r * (q % 2 ? 0.75 : 1.08 + (q % 4 ? 0 : 0.2)); ctx.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
          ctx.closePath(); ctx.fill();
          ctx.beginPath(); ctx.ellipse(x + r * 0.2, y + r * 1.2, r * 0.12, r * 0.4, 0, 0, 7); ctx.fill();
        }
      }
    }
    /* centre-top chip: wind warning or the season */
    function drawChip12() {
      const fc = camTarget(), w = cv.w;
      if (!fc || phase === 'grid') return;
      let txt = null, col = '#f2e9d8', arrow = null;
      if (tr.gust) {
        const near = tr.gzone[fc.idx] || tr.gzone[(fc.idx + Math.round(30 / tr.ds)) % NS], gs = near && W.racing ? gustAt(tr.gust, W.clock) : null;
        if (gs) { txt = gs.on ? '돌풍!' : '바람 조심'; col = gs.on ? '#bfefff' : '#ffb347'; const j = fc.idx, vx = tr.nx[j] * gs.dir, vy = tr.ny[j] * gs.dir; arrow = Math.atan2(vy, vx) - cam.a - Math.PI / 2; }
      }
      if (!txt && tr.D.seasons) { const S2 = SEASON[U.clamp(fc.crossed, 1, 3)]; txt = S2[0]; col = S2[1]; }
      if (!txt) return;
      ctx.font = '700 12px "IBM Plex Sans KR", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const tw = ctx.measureText(txt).width + (arrow != null ? 40 : 22), x = U.clamp(w / 2, 136 + tw / 2, w - 110 - tw / 2), y = 24;
      pill(x - tw / 2, y - 13, tw, 26);
      ctx.fillStyle = col; ctx.fillText(txt, x + (arrow != null ? 9 : 0), y + 1);
      if (arrow != null) { ctx.save(); ctx.translate(x - tw / 2 + 15, y); ctx.rotate(arrow); ctx.fillStyle = col; ctx.beginPath(); ctx.moveTo(7, 0); ctx.lineTo(-3, -5); ctx.lineTo(-1, 0); ctx.lineTo(-3, 5); ctx.closePath(); ctx.fill(); ctx.restore(); }
    }
    /* my active power-ups with their time left (under the standings) */
    function drawStatus12(y0) {
      const c = me();
      if (!c || c.fin != null) return;
      const list = [];
      if (c.flt > 0) list.push(['balloon', c.flt]);
      if (c.auto > 0) list.push(['auto', c.auto]);
      if (c.drone > 0) list.push(['drone', null, c.drone]);
      if (c.bomb > 0) list.push(['bomb', c.bomb]);
      if (c.bee > 0) list.push(['bees', c.bee]);
      list.slice(0, 4).forEach(([it, tl, n], k) => {
        const x = 10 + (k % 2) * 47, y = y0 + Math.floor(k / 2) * 30;
        pill(x, y, 44, 26); ctx.save(); ctx.translate(x + 12, y + 13); drawIcon(ctx, it, 9); ctx.restore();
        ctx.font = '700 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = it === 'bomb' ? '#ff9a3c' : '#f2e9d8';
        ctx.fillText(tl != null ? String(Math.ceil(tl)) : '×' + n, x + 32, y + 13.5);
      });
    }
    /* ----- round 12 live layers ----- */
    const quadW = (P2, a0, a1, l0, l1) => { const ca = Math.cos(P2.a), sa = Math.sin(P2.a); ctx.beginPath(); for (const [al, lt] of [[a0, l0], [a1, l0], [a1, l1], [a0, l1]]) ctx.lineTo(P2.x + ca * al - sa * lt, P2.y + sa * al + ca * lt); ctx.closePath(); };
    const ptW = (P2, al, lt) => [P2.x + Math.cos(P2.a) * al - Math.sin(P2.a) * lt, P2.y + Math.sin(P2.a) * al + Math.cos(P2.a) * lt];
    const lamp = (x, y, col, r) => { ctx.fillStyle = '#2b2533'; ctx.beginPath(); ctx.arc(x, y, (r || 0.6) + 0.25, 0, 7); ctx.fill(); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r || 0.6, 0, 7); ctx.fill(); };
    function drawGim12(now) { // on the ground, under the cars
      const t = W.clock, half = tr.half, blink = Math.floor(now / 250) % 2, th2 = THEME[tr.D.th] || THEME.plum;
      if (tr.fer && onScreen(tr.fer.x, tr.fer.y, tr.fer.wr + 20)) { // the two rafts, their gates and the bank barriers
        const F = tr.fer;
        for (const k of [0, 1]) {
          const R = raftAt(F, k, t), sg = k ? 1 : -1, l0 = sg > 0 ? FER_PIER + 0.15 : -half + 0.2, l1 = sg > 0 ? half - 0.2 : -FER_PIER - 0.15, b0 = R.p - FER_LR / 2, b1 = R.p + FER_LR / 2;
          quadW(F, b0 + 0.4, b1 + 0.4, l0 + 0.4, l1 + 0.4); ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fill();
          quadW(F, b0, b1, l0, l1); ctx.fillStyle = '#9a6a3c'; ctx.fill(); ctx.strokeStyle = '#5a3d26'; ctx.lineWidth = 0.35; ctx.stroke();
          ctx.strokeStyle = 'rgba(60,35,15,.45)'; ctx.lineWidth = 0.14; ctx.beginPath(); for (let a = b0 + 0.9; a < b1; a += 0.9) { const [x0, y0] = ptW(F, a, l0), [x1, y1] = ptW(F, a, l1); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); } ctx.stroke();
          for (const [a, open] of [[b0, R.near], [b1, R.far]]) { const [x0, y0] = ptW(F, a, l0), [x1, y1] = ptW(F, a, l1); ctx.strokeStyle = open ? 'rgba(95,211,160,.5)' : '#e8384f'; ctx.lineWidth = open ? 0.25 : 0.55; if (!open) ctx.setLineDash([0.8, 0.6]); ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); ctx.setLineDash([]); }
          // bank barrier + lamp: green while this lane's raft waits, amber when it is about to leave, red when it is away
          const [bx0, by0] = ptW(F, -F.wr - 1.4, l0), [bx1, by1] = ptW(F, -F.wr - 1.4, l1);
          if (!R.near) { ctx.strokeStyle = '#f2f2f2'; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(bx0, by0); ctx.lineTo(bx1, by1); ctx.stroke(); ctx.strokeStyle = '#e8384f'; ctx.setLineDash([1, 1]); ctx.stroke(); ctx.setLineDash([]); }
          const [lx, ly] = ptW(F, -F.wr - 3, sg * (half + 1.6));
          lamp(lx, ly, R.near ? (R.left < 1.2 ? (blink ? '#ffb347' : '#5a3a10') : '#5fd3a0') : '#e8384f', 0.75);
        }
      }
      for (const B of tr.dbr) { // the two leaves of each drawbridge, foreshortened as they rise
        if (!onScreen(B.x, B.y, B.wr + 20)) continue;
        const th = W.racing ? dbAng(B, t) : 0, tip = B.wr * Math.cos(th), shade = Math.round(255 * (1 - th * 0.35));
        for (const sd of [-1, 1]) {
          const a0 = sd * B.wr, a1 = sd * (B.wr - tip);
          if (th > 0.05) { quadW(B, a0, a1 + sd * -Math.sin(th) * 2.2, -half - 0.3, half + 0.3); ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fill(); }
          quadW(B, a0, a1, -half, half); ctx.fillStyle = th < 0.05 ? th2.road : 'rgb(' + Math.round(shade * 0.3) + ',' + Math.round(shade * 0.3) + ',' + Math.round(shade * 0.34) + ')'; ctx.fill();
          ctx.strokeStyle = '#ffd166'; ctx.lineWidth = 0.3; ctx.stroke();
          if (th > 0.05) { const [x0, y0] = ptW(B, a1, -half), [x1, y1] = ptW(B, a1, half); ctx.strokeStyle = '#e8384f'; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); }
        }
        for (const sd of [-1, 1]) { const [lx, ly] = ptW(B, -B.wr - 3, sd * (half + 1.8)); lamp(lx, ly, th < 0.04 ? '#5fd3a0' : th < DB_JUMP ? (blink ? '#ffb347' : '#5a3a10') : '#e8384f', 0.75); }
      }
      for (const Hd of tr.herd) { // sheep, and the blinking sign before they step out
        if (!onScreen(Hd.x, Hd.y, 30)) continue;
        const st = W.racing ? herdAt(Hd, t) : null;
        if (!st) continue;
        if (st.tau < 0) { if (blink) for (const sd of [-1, 1]) { const [px, py] = [Hd.x + tr.nx[Hd.i] * sd * (half + 2.4) - tr.tx[Hd.i] * 9, Hd.y + tr.ny[Hd.i] * sd * (half + 2.4) - tr.ty[Hd.i] * 9]; ctx.strokeStyle = '#ff6a3d'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.arc(px, py, 2.2, 0, 7); ctx.stroke(); } continue; }
        for (let j = 0; j < Hd.n; j++) {
          const lat = herdLat(Hd, j, st.tau); if (lat == null) continue;
          const al = herdAl(Hd, j), x = Hd.x + tr.tx[Hd.i] * al + tr.nx[Hd.i] * lat, y = Hd.y + tr.ty[Hd.i] * al + tr.ny[Hd.i] * lat;
          const dir = Math.atan2(-tr.ny[Hd.i] * Hd.side, -tr.nx[Hd.i] * Hd.side), bob = Math.sin(now / 90 + j * 2) * 0.12;
          ctx.save(); ctx.translate(x, y); ctx.rotate(dir);
          ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(0.3, 0.4, 1.45, 1.05, 0, 0, 7); ctx.fill();
          ctx.fillStyle = '#2b2533'; for (const [lx, ly] of [[0.8, -0.7], [0.8, 0.7], [-0.8, -0.7], [-0.8, 0.7]]) ctx.fillRect(lx - 0.15 + bob, ly - 0.15, 0.3, 0.3);
          ctx.fillStyle = '#f6f2ea'; for (const [bx2, by2, r] of [[0, 0, 0.9], [-0.6, -0.4, 0.6], [-0.6, 0.4, 0.6], [0.5, -0.45, 0.55], [0.5, 0.45, 0.55]]) { ctx.beginPath(); ctx.arc(bx2, by2, r, 0, 7); ctx.fill(); }
          ctx.fillStyle = '#2b2533'; ctx.beginPath(); ctx.ellipse(1.35 + bob, 0, 0.55, 0.42, 0, 0, 7); ctx.fill();
          ctx.restore();
        }
      }
      if (tr.xing) { // traffic lights at the crossroads: the two roads take turns (advice only — nothing stops you)
        const X = tr.xing, ph = Math.floor(Math.max(0, t) / 4) % 2;
        for (const [i, gp] of [[X.i, 0], [X.j, 1]]) for (const sd of [-1, 1]) {
          const j = (i - Math.round((half * 2.6) / tr.ds) + NS) % NS, px = tr.x[j] + tr.nx[j] * sd * (half + 1.2), py = tr.y[j] + tr.ny[j] * sd * (half + 1.2);
          const green = ph === gp, warn = (Math.max(0, t) % 4) > 3.2;
          lamp(px, py, green ? (warn ? '#ffb347' : '#5fd3a0') : '#e8384f', 0.6);
        }
      }
    }
    function drawTop12(now) { // above the cars: the boost rings (up in the air), gusts on the bridges
      const t = W.clock, half = tr.half;
      for (const H of tr.hoops) {
        if (!onScreen(H.x, H.y, 16)) continue;
        const lat = hoopLat(H, t), [px, py] = ptW(H, 0, lat), glow = 0.6 + 0.4 * Math.sin(now / 120 + H.k);
        ctx.save(); ctx.translate(px, py); ctx.rotate(H.a);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(1.6, 1.8, 0.6, 2.4, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(79,227,255,' + 0.35 * glow + ')'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.ellipse(0, 0, 0.9, 2.5, 0, 0, 7); ctx.stroke();
        ctx.strokeStyle = H.k % 2 ? '#ff5fb4' : '#4fe3ff'; ctx.lineWidth = 0.55; ctx.stroke();
        ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.18; ctx.beginPath(); ctx.ellipse(0, 0, 0.9, 2.5, 0, 3.6, 5.6); ctx.stroke();
        ctx.restore();
      }
      if (tr.gust && W.racing) { // gust: streaks across the bridge (dashed while it is only a warning)
        const gs = gustAt(tr.gust, t);
        if (gs) {
          ctx.lineCap = 'round';
          for (const [a, b] of tr.gust.zones) for (let i = Math.round(a * NS); i < Math.round(b * NS); i += 4) {
            const j = i % NS;
            if (!onScreen(tr.x[j], tr.y[j], 12)) continue;
            const ph = ((now / 400 + i * 0.37) % 1), l = (ph * 2 - 1) * (half + 4) * gs.dir, px = tr.x[j] + tr.nx[j] * l, py = tr.y[j] + tr.ny[j] * l;
            ctx.strokeStyle = gs.on ? 'rgba(235,248,255,.7)' : 'rgba(255,200,120,' + (Math.floor(now / 150) % 2 ? 0.7 : 0.2) + ')'; ctx.lineWidth = gs.on ? 0.35 : 0.25;
            ctx.beginPath(); ctx.moveTo(px - tr.nx[j] * 2.4 * gs.dir, py - tr.ny[j] * 2.4 * gs.dir); ctx.lineTo(px, py); ctx.stroke();
          }
        }
        for (const [a, b] of tr.gust.zones) for (const f of [a, b]) for (const sd of [-1, 1]) { // windsocks point the way the wind blows
          const j = Math.round(f * NS) % NS, px = tr.x[j] + tr.nx[j] * sd * (half + 2.6), py = tr.y[j] + tr.ny[j] * sd * (half + 2.6);
          if (!onScreen(px, py, 6)) continue;
          const g2 = gustAt(tr.gust, t), dir = g2 ? g2.dir : 0, flap = Math.sin(now / 80) * 0.2;
          const ang = dir ? Math.atan2(tr.ny[j] * dir, tr.nx[j] * dir) + flap : tr.hd[j] + Math.PI / 2 + Math.sin(now / 700) * 0.4, len = g2 && g2.on ? 2.6 : g2 ? 2 : 1.3;
          ctx.save(); ctx.translate(px, py); ctx.rotate(ang);
          for (let k = 0; k < 4; k++) { ctx.fillStyle = k % 2 ? '#f2f2f2' : '#ee6a55'; ctx.fillRect((k * len) / 4, -0.42 + k * 0.06, len / 4 + 0.05, 0.84 - k * 0.12); }
          ctx.restore();
        }
      }
    }
    function drawGimTop(now) { // above the cars: falling rocks, snowballs, geyser columns, tornado funnels, magnet heads
      const t = W.clock, half = tr.half;
      if (tr.rock && W.racing) { // the rock in its last moment of falling
        const R = tr.rock, k1 = Math.floor((t - R.off) / R.per);
        for (let k = Math.max(0, k1 - 1); k <= k1; k++) {
          const age = t - rockT0(R, k), f = (age - (R.warn - 0.35)) / 0.35;
          if (f < 0 || f >= 1) continue;
          rockWave(tr, k).forEach((q, j) => {
            if (!onScreen(q.x, q.y, 8)) return;
            ctx.save(); ctx.translate(q.x, q.y); ctx.rotate(cam.a + Math.PI / 2); ctx.translate(0, -(1 - f) * 12); ctx.scale(1.6 - 0.6 * f, 1.6 - 0.6 * f);
            drawBoulder(0, 0, R.r, k * 7 + j, 0.5 + 0.5 * f); ctx.restore();
          });
        }
      }
      for (const B of tr.balls) {
        if (!W.racing || !onScreen(B.x, B.y, B.L + 6)) continue;
        const st2 = ballAt(B, t);
        if (!st2 || !st2.rolling) continue;
        const bx = B.x + tr.nx[B.i] * st2.lat, by = B.y + tr.ny[B.i] * st2.lat;
        ctx.fillStyle = 'rgba(40,60,100,.3)'; ctx.beginPath(); ctx.ellipse(bx + 0.5, by + 0.8, st2.r, st2.r * 0.85, 0, 0, 7); ctx.fill();
        const g = ctx.createRadialGradient(bx - st2.r * 0.35, by - st2.r * 0.4, 0.1, bx, by, st2.r);
        g.addColorStop(0, '#ffffff'); g.addColorStop(0.7, '#e6f1fb'); g.addColorStop(1, '#a9c4dc');
        ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, by, st2.r, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(150,180,210,.6)'; ctx.lineWidth = 0.15; const rot = st2.lat / st2.r;
        for (let k = 0; k < 3; k++) { const a = rot + k * 2.1; ctx.beginPath(); ctx.arc(bx + Math.cos(a) * st2.r * 0.4, by + Math.sin(a) * st2.r * 0.4, st2.r * 0.25, 0, 7); ctx.stroke(); }
      }
      for (const g2 of tr.gey) { // eruption: a column of lava bursting up
        if (!W.racing || !onScreen(g2.x, g2.y, 8) || geyS(g2, t) !== 2) continue;
        const u = (t - g2.off) - geyK(g2, t) * g2.per - GEY_WARN, f = U.clamp(u / GEY_ON, 0, 1), h2 = Math.sin(Math.PI * Math.min(1, f * 1.3)) * 9;
        ctx.save(); ctx.translate(g2.x, g2.y); ctx.rotate(cam.a + Math.PI / 2);
        const gg = ctx.createLinearGradient(0, 0, 0, -h2); gg.addColorStop(0, 'rgba(255,90,20,.95)'); gg.addColorStop(0.6, 'rgba(255,180,60,.85)'); gg.addColorStop(1, 'rgba(255,240,180,.2)');
        ctx.fillStyle = gg; ctx.beginPath(); ctx.moveTo(-GEY_R * 0.7, 0); ctx.quadraticCurveTo(-1.2, -h2 * 0.6, -0.6, -h2); ctx.lineTo(0.6, -h2); ctx.quadraticCurveTo(1.2, -h2 * 0.6, GEY_R * 0.7, 0); ctx.closePath(); ctx.fill();
        for (let k = 0; k < 6; k++) { const a = k * 1.1 + now / 200, r = (now / 300 + k * 0.17) % 1; ctx.fillStyle = 'rgba(255,200,80,' + (1 - r) + ')'; ctx.beginPath(); ctx.arc(Math.cos(a) * r * 3.5, -h2 * (0.4 + r * 0.6), 0.45, 0, 7); ctx.fill(); }
        ctx.restore();
      }
      for (const T2 of tr.tw) { // the funnel: a dark swirling cone widening upward (drawn in screen-up direction)
        const p2 = twPos(tr, T2, t);
        if (!onScreen(p2.x, p2.y, TW_PULL + 14)) continue;
        ctx.save(); ctx.translate(p2.x, p2.y); ctx.rotate(cam.a + Math.PI / 2);
        const top = 14, wob = (k) => Math.sin(now / 380 + k * 0.45) * k * 0.12;
        const g = ctx.createLinearGradient(0, 0, 0, -top); g.addColorStop(0, 'rgba(82,64,46,.95)'); g.addColorStop(0.6, 'rgba(132,108,82,.85)'); g.addColorStop(1, 'rgba(176,152,120,.6)');
        ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(-1.2, 0);
        for (let k = 0; k <= 10; k++) ctx.lineTo(-1.2 - k * 0.62 + wob(k), -k * (top / 10));
        for (let k = 10; k >= 0; k--) ctx.lineTo(1.2 + k * 0.62 + wob(k), -k * (top / 10));
        ctx.closePath(); ctx.fill();
        for (let k = 0; k < 11; k++) {
          const yy = -k * (top / 10), r = 1.3 + k * 0.62, ph = -now / (70 + k * 6) + k, sway = wob(k);
          ctx.strokeStyle = 'rgba(' + (235 - k * 7) + ',' + (230 - k * 7) + ',' + (220 - k * 6) + ',' + (0.85 - k * 0.04) + ')'; ctx.lineWidth = 0.5 + k * 0.05;
          ctx.beginPath(); ctx.ellipse(sway, yy, r, r * 0.3, 0, ph, ph + 4.4); ctx.stroke();
        }
        for (let k = 0; k < 6; k++) { const a = -now / 120 + k * 1.05, r = 3 + (k % 3) * 1.6; ctx.fillStyle = k % 2 ? '#7a5a3a' : '#5a7a3a'; ctx.fillRect(Math.cos(a) * r, -3 - (k % 4) * 2 + Math.sin(a) * r * 0.3, 0.5, 0.35); }
        ctx.restore();
      }
      for (const m of tr.mag) { // the crane arm and the magnet head over the road
        if (!onScreen(m.x, m.y, 12)) continue;
        const st2 = W.racing ? magS(m, t) : 0, o = m.side * (half + 5.5), bx = tr.x[m.i] + tr.nx[m.i] * o, by = tr.y[m.i] + tr.ny[m.i] * o;
        ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(bx + 1, by + 1.5); ctx.lineTo(m.x + 1, m.y + 1.5); ctx.stroke();
        ctx.strokeStyle = '#e8a33d'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(m.x, m.y); ctx.stroke();
        ctx.strokeStyle = '#7a4f12'; ctx.lineWidth = 0.15; ctx.setLineDash([0.6, 0.6]); ctx.stroke(); ctx.setLineDash([]);
        if (st2 === 2) { const g = ctx.createRadialGradient(m.x, m.y, 0.5, m.x, m.y, 4); g.addColorStop(0, 'rgba(120,200,255,.7)'); g.addColorStop(1, 'rgba(120,200,255,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(m.x, m.y, 4, 0, 7); ctx.fill(); }
        ctx.fillStyle = '#3d3a40'; ctx.beginPath(); ctx.arc(m.x, m.y, 2.2, 0, 7); ctx.fill();
        ctx.fillStyle = st2 === 2 ? '#7fd0ff' : st2 === 1 && Math.floor(now / 120) % 2 ? '#ffd166' : '#5a5e66'; ctx.beginPath(); ctx.arc(m.x, m.y, 1.4, 0, 7); ctx.fill();
        ctx.strokeStyle = '#d6403a'; ctx.lineWidth = 0.35; ctx.beginPath(); ctx.arc(m.x, m.y, 2.2, 0, 7); ctx.stroke();
      }
    }
    /* ----- round 8 live layers ----- */
    const chev = (px, py, ax, ay, s) => { ctx.beginPath(); ctx.moveTo(px - ax * s * 0.7 - ay * s, py - ay * s * 0.7 + ax * s); ctx.lineTo(px, py); ctx.lineTo(px - ax * s * 0.7 + ay * s, py - ay * s * 0.7 - ax * s); ctx.stroke(); };
    /* conveyor belts: chevrons slide the way the belt runs */
    function drawBelts(now) {
      if (!tr.belts.length) return;
      const t = now / 1000;
      ctx.lineCap = 'round'; ctx.lineWidth = 0.38;
      for (const Bt of tr.belts) {
        const i0 = Math.round(Bt.a * NS), i1 = Math.round(Bt.b * NS), w2 = Bt.l1 - Bt.l0, back = Math.abs(wrapA(Bt.dir)) > 2.9;
        const sideways = Math.abs(Math.abs(wrapA(Bt.dir)) - Math.PI / 2) < 0.3;
        ctx.strokeStyle = back ? 'rgba(238,106,85,.85)' : 'rgba(242,194,48,.85)';
        if (!sideways) {
          const L = (i1 - i0) * tr.ds, sg = back ? -1 : 1, ph = ((t * Bt.sp) % 3 + 3) % 3;
          for (let s2 = sg > 0 ? ph : 3 - ph; s2 < L - 0.5; s2 += 3) {
            const j = (i0 + Math.floor(s2 / tr.ds)) % NS;
            if (!onScreen(tr.x[j], tr.y[j], 8)) continue;
            for (let l = Bt.l0 + 1.9; l < Bt.l1 - 1; l += 3) chev(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, tr.tx[j] * sg, tr.ty[j] * sg, 0.9);
          }
        } else {
          const sg = Math.sin(Bt.dir) > 0 ? 1 : -1, ph = ((t * Bt.sp) / w2) % 1;
          for (let i = i0 + 2; i < i1 - 1; i += 3) {
            const j = i % NS;
            if (!onScreen(tr.x[j], tr.y[j], 8)) continue;
            for (let q = 0; q < 3; q++) { const f = (q / 3 + ph) % 1, l = sg > 0 ? Bt.l0 + 1 + f * (w2 - 2) : Bt.l1 - 1 - f * (w2 - 2); chev(tr.x[j] + tr.nx[j] * l, tr.y[j] + tr.ny[j] * l, tr.nx[j] * sg, tr.ny[j] * sg, 0.8); }
          }
        }
      }
    }
    /* gates: iron bars slide out of the outer posts; lamps on the divider's nose show each lane (green / amber / red) */
    function doorK(d, sd, t) { // 0 = shut … 1 = fully open (eases over 0.3 s at both ends of the open window)
      const u = ((((t + d.off) % d.per) + d.per) % d.per), s0 = sd < 0 ? 0 : d.per * 0.45, s1 = sd < 0 ? d.per * 0.55 : d.per;
      if (u < s0 || u >= s1) return 0;
      return U.clamp(Math.min(u - s0, s1 - u) / 0.3, 0, 1);
    }
    function drawDoors(now) {
      for (const d of tr.doors) {
        if (!onScreen(d.x, d.y, 24)) continue;
        const ta = Math.cos(d.a), tb = Math.sin(d.a), nx0 = -tb, ny0 = ta, ext = tr.half + (tr.wall || 0) * 0.5, t = W.clock;
        for (const sd of [-1, 1]) {
          const k = doorK(d, sd, t), len = (ext - DIV_W) * (1 - k);
          // the gate: bars from the outer post toward the divider
          if (len > 0.05) {
            const ox = d.x + nx0 * sd * ext, oy = d.y + ny0 * sd * ext, ex2 = ox - nx0 * sd * len, ey2 = oy - ny0 * sd * len;
            ctx.lineCap = 'butt';
            ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(ox + 0.3, oy + 0.5); ctx.lineTo(ex2 + 0.3, ey2 + 0.5); ctx.stroke();
            ctx.strokeStyle = '#2b2733'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(ex2, ey2); ctx.stroke();
            ctx.strokeStyle = '#8a8496'; ctx.lineWidth = 0.18;
            for (let q = 0.7; q < len; q += 0.9) { const qx = ox - nx0 * sd * q, qy = oy - ny0 * sd * q; ctx.beginPath(); ctx.moveTo(qx - ta * 0.6, qy - tb * 0.6); ctx.lineTo(qx + ta * 0.6, qy + tb * 0.6); ctx.stroke(); }
            ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(ex2, ey2, 0.35, 0, 7); ctx.fill();
            ctx.lineCap = 'round';
          }
          // a light strip across the lane just before its gate, and a lamp on the divider's nose
          const soon = k > 0 && !doorOpen(d, sd, t + 0.8), col = k <= 0 ? '#ff4040' : soon ? '#ffb347' : '#5fd3a0';
          ctx.lineCap = 'butt'; ctx.strokeStyle = col; ctx.globalAlpha = 0.55 + (k <= 0 ? 0.25 * Math.sin(now / 90) : 0); ctx.lineWidth = 0.8;
          ctx.beginPath(); ctx.moveTo(d.x - ta * 1.6 + nx0 * sd * (DIV_W + 0.3), d.y - tb * 1.6 + ny0 * sd * (DIV_W + 0.3)); ctx.lineTo(d.x - ta * 1.6 + nx0 * sd * (tr.half - 0.3), d.y - tb * 1.6 + ny0 * sd * (tr.half - 0.3)); ctx.stroke();
          ctx.globalAlpha = 1; ctx.lineCap = 'round';
          const lx = d.x - ta * DOOR_DIV + nx0 * sd * 1.1, ly = d.y - tb * DOOR_DIV + ny0 * sd * 1.1;
          ctx.fillStyle = col; ctx.globalAlpha = 0.25; ctx.beginPath(); ctx.arc(lx, ly, 1.6, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
          ctx.beginPath(); ctx.arc(lx, ly, 0.55, 0, 7); ctx.fill();
          const gx = d.x + nx0 * sd * ext * 0.5 - ta * 1.2, gy = d.y + ny0 * sd * ext * 0.5 - tb * 1.2;
          ctx.globalAlpha = 0.18; ctx.beginPath(); ctx.arc(gx, gy, 2.4, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
        }
      }
    }
    /* windmill sails (above the cars: they sweep low over the road) */
    function drawSails() {
      for (const S of tr.sw) {
        if (!onScreen(S.hx, S.hy, S.len + 4)) continue;
        for (let pass = 0; pass < 2; pass++) for (let k = 0; k < S.n; k++) {
          const a = sailAng(S, k, W.clock);
          ctx.save(); ctx.translate(S.hx + (pass ? 0 : 1.4), S.hy + (pass ? 0 : 2)); ctx.rotate(a);
          if (!pass) { ctx.fillStyle = 'rgba(0,0,0,.22)'; ctx.fillRect(1.4, -SAIL_W, S.len - 1.4, SAIL_W * 2); }
          else {
            ctx.fillStyle = 'rgba(246,236,214,.95)'; ctx.fillRect(2, -SAIL_W, S.len - 2.2, SAIL_W * 2);
            ctx.strokeStyle = 'rgba(110,70,35,.75)'; ctx.lineWidth = 0.12;
            for (let r = 2; r < S.len; r += 1.1) { ctx.beginPath(); ctx.moveTo(r, -SAIL_W); ctx.lineTo(r, SAIL_W); ctx.stroke(); }
            ctx.strokeRect(2, -SAIL_W, S.len - 2.2, SAIL_W * 2);
            ctx.fillStyle = '#5a3d26'; ctx.fillRect(0, -0.2, S.len, 0.4);
          }
          ctx.restore();
        }
        ctx.fillStyle = '#3d2814'; ctx.beginPath(); ctx.arc(S.hx, S.hy, 1.1, 0, 7); ctx.fill();
        ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(S.hx, S.hy, 0.45, 0, 7); ctx.fill();
      }
    }
    /* lightning: blinking target rings while it charges, a scorch afterwards; the strike itself is drawn in screen space */
    function drawBoltRings(now) {
      const B2 = tr.bolt;
      if (!B2 || !W.racing) return;
      const bp = boltPhase(B2, W.clock);
      if (!bp) return;
      const spots = boltSpots(tr, bp.k), f = bp.tau / B2.warn;
      for (const s of spots) {
        if (!onScreen(s.x, s.y, 10)) continue;
        if (f < 1) {
          const blink = 0.55 + 0.45 * Math.sin(now / (f > 0.6 ? 45 : 90));
          ctx.fillStyle = 'rgba(255,220,90,' + (0.08 + 0.22 * f) + ')'; ctx.beginPath(); ctx.arc(s.x, s.y, B2.r * Math.max(0.15, f), 0, 7); ctx.fill();
          ctx.strokeStyle = (f > 0.65 ? 'rgba(255,110,70,' : 'rgba(255,230,120,') + blink + ')'; ctx.lineWidth = f > 0.65 ? 0.6 : 0.45; ctx.setLineDash([1.4, 0.9]); ctx.lineDashOffset = -now / 80;
          ctx.beginPath(); ctx.arc(s.x, s.y, B2.r, 0, 7); ctx.stroke(); ctx.setLineDash([]);
          ctx.strokeStyle = 'rgba(255,230,120,' + 0.6 * blink + ')'; ctx.lineWidth = 0.3; ctx.beginPath(); ctx.moveTo(s.x - 1, s.y); ctx.lineTo(s.x + 1, s.y); ctx.moveTo(s.x, s.y - 1); ctx.lineTo(s.x, s.y + 1); ctx.stroke();
        } else if (bp.tau < B2.warn + 1.4) {
          const a = 1 - (bp.tau - B2.warn) / 1.4, g = ctx.createRadialGradient(s.x, s.y, 0.2, s.x, s.y, B2.r);
          g.addColorStop(0, 'rgba(255,240,200,' + 0.8 * a + ')'); g.addColorStop(0.3, 'rgba(40,30,30,' + 0.6 * a + ')'); g.addColorStop(1, 'rgba(0,0,0,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(s.x, s.y, B2.r, 0, 7); ctx.fill();
        }
      }
    }
    let boltSeen = -1, boltFlash = 0;
    function drawBoltStrikes(rdt) {
      const B2 = tr.bolt;
      if (!B2 || !W.racing) return;
      const bp = boltPhase(B2, W.clock);
      if (!bp) return;
      const age = bp.tau - B2.warn;
      if (age >= 0 && boltSeen !== bp.k) {
        boltSeen = bp.k; boltFlash = 1;
        const m = me();
        if (m && boltSpots(tr, bp.k).some((s) => (s.x - m.x) ** 2 + (s.y - m.y) ** 2 < 3600)) { api.sfx('thud'); api.buzz(12); }
      }
      if (boltFlash > 0) { ctx.fillStyle = 'rgba(220,230,255,' + 0.22 * boltFlash * L.fx() + ')'; ctx.fillRect(0, 0, cv.w, cv.h); boltFlash -= rdt * 4; }
      if (age < 0 || age > 0.28) return;
      ctx.save(); ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      for (const s of boltSpots(tr, bp.k)) {
        if (!onScreen(s.x, s.y, 4)) continue;
        const p = toScreen(s.x, s.y);
        let x = p.x + (hash01(bp.k, s.i) - 0.5) * 120, y = -10;
        const pts = [[x, y]];
        for (let q = 1; q <= 7; q++) { const f = q / 7; x = x + (p.x - x) * f + (hash01(bp.k * 13 + q, s.i) - 0.5) * 40 * (1 - f); y = -10 + (p.y + 10) * f; pts.push([x, y]); }
        pts[pts.length - 1] = [p.x, p.y];
        for (const [col, w] of [['rgba(160,190,255,.45)', 9], ['#ffffff', 3]]) { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.beginPath(); pts.forEach(([a, b], q) => (q ? ctx.lineTo(a, b) : ctx.moveTo(a, b))); ctx.stroke(); }
      }
      ctx.restore();
    }
    /* the tide over the sandbar: water creeps in from both edges; fully covered exactly when it turns slow */
    function drawTide() {
      if (!tr.tide) return;
      const L2 = tideLvl(tr, W.clock), f = U.clamp((L2 - 0.3) / 0.2, 0, 1);
      if (f <= 0) return;
      for (const C of tr.cuts) {
        if (!C.tide || !onScreen(C.sx[C.n >> 1], C.sy[C.n >> 1], C.n * 0.6)) continue;
        const cp = () => { ctx.beginPath(); for (let k = 0; k < C.n; k += 2) k ? ctx.lineTo(C.sx[k], C.sy[k]) : ctx.moveTo(C.sx[k], C.sy[k]); ctx.lineTo(C.sx[C.n - 1], C.sy[C.n - 1]); };
        ctx.lineCap = 'butt'; ctx.lineJoin = 'round';
        cp(); ctx.strokeStyle = 'rgba(63,127,160,' + (0.55 + 0.35 * f) + ')'; ctx.lineWidth = C.hw * 2 + 3; ctx.stroke();
        if (f < 1) { cp(); ctx.strokeStyle = '#cdb58a'; ctx.lineWidth = C.hw * 2 * (1 - f); ctx.stroke(); }
        else { cp(); ctx.strokeStyle = 'rgba(200,240,255,.35)'; ctx.lineWidth = 0.3; ctx.setLineDash([1.5, 3]); ctx.lineDashOffset = -W.clock * 2; ctx.stroke(); ctx.setLineDash([]); }
        ctx.lineCap = 'round';
      }
    }
    /* tunnels: rock roofs over the road, see-through while you are inside */
    let roofs = null;
    function buildRoofs() {
      roofs = [];
      const wall = tr.wall || 0, s = Math.min(6, art ? art.bs : 6);
      const mk = (P, hw, test) => {
        let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        for (const [x, y] of P) { x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y); }
        const m = hw + 3; x0 -= m; y0 -= m; x1 += m; y1 += m;
        const c2 = document.createElement('canvas'); c2.width = Math.ceil((x1 - x0) * s); c2.height = Math.ceil((y1 - y0) * s);
        const g = c2.getContext('2d'); g.scale(s, s); g.translate(-x0, -y0); g.lineJoin = 'round'; g.lineCap = 'butt';
        const line = () => { g.beginPath(); P.forEach(([x, y], k) => (k ? g.lineTo(x, y) : g.moveTo(x, y))); };
        line(); g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = hw * 2 + 4; g.stroke();
        line(); g.strokeStyle = '#3e3b37'; g.lineWidth = hw * 2 + 3; g.stroke();
        line(); g.strokeStyle = '#55524c'; g.lineWidth = hw * 2 + 1.2; g.stroke();
        line(); g.strokeStyle = 'rgba(70,110,60,.45)'; g.lineWidth = hw * 1.2; g.setLineDash([3, 2.2]); g.stroke(); g.setLineDash([]);
        let sd = 99 + roofs.length * 7; const rn = () => (sd = (sd * 16807) % 2147483647) / 2147483647;
        for (let k = 0; k < P.length; k++) for (let q = 0; q < 3; q++) { g.fillStyle = rn() < 0.5 ? 'rgba(0,0,0,.2)' : 'rgba(255,255,255,.1)'; g.beginPath(); g.ellipse(P[k][0] + (rn() - 0.5) * hw * 1.8, P[k][1] + (rn() - 0.5) * hw * 1.8, 0.8 + rn() * 1.6, 0.5 + rn(), rn() * 3, 0, 7); g.fill(); }
        for (let k = 0; k < P.length; k += 3) if (rn() < 0.35) { g.fillStyle = rn() < 0.5 ? '#24402c' : '#2d4f33'; g.beginPath(); g.arc(P[k][0] + (rn() - 0.5) * hw * 1.6, P[k][1] + (rn() - 0.5) * hw * 1.6, 1 + rn() * 1.4, 0, 7); g.fill(); }
        for (let k = 3; k < P.length - 3; k += 6) { g.fillStyle = 'rgba(255,214,120,.35)'; g.beginPath(); g.arc(P[k][0], P[k][1], 1.3, 0, 7); g.fill(); g.fillStyle = '#ffd98a'; g.beginPath(); g.arc(P[k][0], P[k][1], 0.4, 0, 7); g.fill(); }
        for (const e of [0, P.length - 1]) { // concrete portal across each mouth
          const e2 = e ? e - 3 : 3, dx = P[e2][0] - P[e][0], dy = P[e2][1] - P[e][1], l = Math.hypot(dx, dy) || 1, px = -dy / l, py = dx / l;
          for (const [col, w, o] of [['#8f8a80', 2, 0.5], ['#cfcabe', 1.2, 0]]) { g.strokeStyle = col; g.lineWidth = w; g.beginPath(); g.moveTo(P[e][0] + px * (hw + 1.4) + dx / l * o, P[e][1] + py * (hw + 1.4) + dy / l * o); g.lineTo(P[e][0] - px * (hw + 1.4) + dx / l * o, P[e][1] - py * (hw + 1.4) + dy / l * o); g.stroke(); }
        }
        roofs.push({ cv: c2, x0, y0, w: x1 - x0, h: y1 - y0, k: 0.85, test });
      };
      for (const [a, b] of tr.D.tunnels || []) {
        const P = []; for (let i = Math.round(a * NS); i <= Math.round(b * NS); i++) { const j = i % NS; P.push([tr.x[j], tr.y[j]]); }
        mk(P, tr.half + wall, (c) => !c.onCut && !!tr.tun[c.idx]);
      }
      for (const C of tr.cuts) if (C.tun) {
        const P = []; for (let k = 9; k < C.n - 9; k++) P.push([C.sx[k], C.sy[k]]);
        if (P.length > 4) mk(P, C.hw + wall, (c) => c.onCut);
      }
    }
    function drawRoofs(rdt) {
      if (!tr.D.tunnels && !tr.cuts.some((C) => C.tun)) return;
      if (!roofs) buildRoofs();
      const fc = camTarget();
      for (const R of roofs) {
        const want = fc && R.test(fc) ? 0.2 : 0.88;
        R.k += (want - R.k) * (1 - Math.exp(-rdt * 7));
        ctx.globalAlpha = R.k; ctx.drawImage(R.cv, R.x0, R.y0, R.w, R.h);
      }
      ctx.globalAlpha = 1;
    }
    const inTunnel = (c) => !!c && ((!c.onCut && tr.tun[c.idx] === 1) || (c.onCut && tr.cuts.some((C) => C.tun)));
    /* tide gauge under the minimap */
    function drawTideHud() {
      if (!tr.tide || !mini || phase === 'grid') return;
      const L2 = tideLvl(tr, W.clock), open = L2 <= 0.5;
      let n = 0; while (n < 40 && (tideLvl(tr, W.clock + n * 0.25) <= 0.5) === open) n++;
      const t = '바닷길 ' + (open ? '열림' : '잠김') + ' · ' + Math.max(1, Math.ceil(n * 0.25)) + '초';
      ctx.font = '700 11px "IBM Plex Sans KR", sans-serif';
      const tw = ctx.measureText(t).width + 30, x = cv.w - 10 - tw, y = 10 + mini.h + 12;
      pill(x, y, tw, 24);
      ctx.fillStyle = open ? '#5fd3a0' : '#7fd0ff'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(t, x + 22, y + 12.5);
      ctx.fillStyle = 'rgba(127,208,255,.25)'; rr(ctx, x + 8, y + 5, 7, 14, 3); ctx.fill();
      ctx.fillStyle = '#7fd0ff'; const hh = 14 * L2; rr(ctx, x + 8, y + 19 - hh, 7, hh, 2); ctx.fill();
    }
    /* 「날씨」 option: wet-road reflections + spray behind cars (world space), rain/snow + spray blur in your eyes (screen space) */
    let wxDrops = null, wxFog = 0;
    function drawWetRoad(now, cars) {
      if (!WX) return;
      for (const c of cars) {
        if (c.out || c.resp > 0 || (c.air || 0) > 0) continue;
        const ca = Math.cos(c.a), sa = Math.sin(c.a);
        if (WX !== 3) { // mirror-like reflection on the wet tarmac
          ctx.save(); ctx.translate(c.x + 0.6, c.y + 1.4); ctx.rotate(c.a); ctx.globalAlpha = WX === 2 ? 0.2 : 0.14; ctx.fillStyle = c.col || '#9ab';
          ctx.beginPath(); ctx.ellipse(0, 0, 2.8, 1.5, 0, 0, 7); ctx.fill(); ctx.restore();
        }
        const v = Math.max(0, c.v || 0); if (v < 12) continue;
        const n = WX === 2 ? 7 : 4, k = Math.min(1, (v - 12) / 30);
        ctx.fillStyle = WX === 3 ? 'rgba(245,250,255,1)' : 'rgba(215,228,245,1)';
        for (let i = 0; i < n; i++) { // spray kicked up by the rear wheels
          const f = ((now / 260 + i / n + (c.x * 0.37 % 1)) % 1), back = 2.6 + f * (6 + 8 * k), side = (i % 2 ? 1 : -1) * (0.9 + f * 1.8);
          ctx.globalAlpha = (1 - f) * 0.32 * k * (WX === 2 ? 1.3 : 1);
          ctx.beginPath(); ctx.arc(c.x - ca * back - sa * side, c.y - sa * back + ca * side, 0.5 + f * 1.6, 0, 7); ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
    }
    function drawWx(now, rdt) {
      if (!WX) return;
      const w = cv.w, h = cv.h, snow = WX === 3, N = WX === 2 ? 150 : snow ? 90 : 80;
      if (!wxDrops || wxDrops.length !== N) wxDrops = Array.from({ length: N }, () => ({ x: Math.random(), y: Math.random(), s: 0.6 + Math.random() * 0.7 }));
      ctx.fillStyle = WX === 2 ? 'rgba(20,30,50,.22)' : snow ? 'rgba(220,230,245,.12)' : 'rgba(30,40,60,.12)'; ctx.fillRect(0, 0, w, h);
      if (snow) {
        ctx.fillStyle = 'rgba(255,255,255,.85)';
        for (const r of wxDrops) { r.y += rdt * 0.12 * r.s; r.x += Math.sin(now / 900 + r.s * 7) * rdt * 0.03; if (r.y > 1.03) { r.y = -0.03; r.x = Math.random(); } ctx.beginPath(); ctx.arc(((r.x % 1) + 1) % 1 * w, r.y * h, 1.2 * r.s + 0.4, 0, 7); ctx.fill(); }
      } else {
        const sp = WX === 2 ? 2.4 : 1.7;
        ctx.strokeStyle = WX === 2 ? 'rgba(200,215,240,.45)' : 'rgba(200,215,240,.32)'; ctx.lineWidth = 1; ctx.beginPath();
        for (const r of wxDrops) { r.y += rdt * sp * r.s; r.x -= rdt * 0.3 * r.s; if (r.y > 1.05) { r.y -= 1.1; r.x = Math.random() * 1.2; } if (r.x < -0.05) r.x += 1.1; const x = r.x * w, y = r.y * h; ctx.moveTo(x, y); ctx.lineTo(x - 4 * r.s, y + (WX === 2 ? 20 : 14) * r.s); }
        ctx.stroke();
      }
      // spray from the car just ahead blurs part of your view (rain / downpour only)
      const fc = camTarget(); let tgt = 0;
      if (fc && !snow && W) {
        const ca = Math.cos(fc.a), sa = Math.sin(fc.a);
        for (const o of W.cars) {
          if (o === fc || o.out || o.lvl !== fc.lvl || (o.v || 0) < 14) continue;
          const dx = o.x - fc.x, dy = o.y - fc.y, al = dx * ca + dy * sa, lt = Math.abs(-dx * sa + dy * ca);
          if (al > 3 && al < 22 && lt < 3.5) tgt = Math.max(tgt, (1 - al / 22) * (1 - lt / 3.5) * Math.min(1, (o.v - 14) / 20));
        }
        tgt *= WX === 2 ? 1 : 0.6;
      }
      wxFog += (tgt - wxFog) * Math.min(1, rdt * 4);
      if (wxFog > 0.02) {
        const fp = toScreen(fc.x, fc.y);
        for (let i = 0; i < 6; i++) {
          const a = i * 2.1 + now / 1500, bx = w * (0.15 + 0.7 * ((i * 0.37 + 0.1) % 1)) + Math.sin(a) * 18, by = Math.min(fp.y, h * 0.6) * (0.25 + 0.55 * ((i * 0.53) % 1));
          const rr2 = Math.min(w, h) * (0.16 + 0.05 * (i % 3));
          const g = ctx.createRadialGradient(bx, by, 0, bx, by, rr2);
          g.addColorStop(0, 'rgba(225,232,242,' + (0.55 * wxFog).toFixed(3) + ')'); g.addColorStop(1, 'rgba(225,232,242,0)');
          ctx.fillStyle = g; ctx.fillRect(bx - rr2, by - rr2, rr2 * 2, rr2 * 2);
        }
      }
      if (st && (st.ph === 'grid' || st.ph === 'count')) { // weather tag before the start
        ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = 'rgba(0,0,0,.5)';
        const tx = WXN[WX] + ' — 노면이 미끄러워요', tw = ctx.measureText(tx).width + 20;
        ctx.fillRect(w / 2 - tw / 2, h * 0.2 - 14, tw, 26); ctx.fillStyle = '#fff'; ctx.fillText(tx, w / 2, h * 0.2 + 4); ctx.textAlign = 'left';
      }
    }
    /* screen-space weather for the new tracks: rain, aurora curtains, drifting ghosts, tunnel gloom */
    let rain = null, ghosts = null, tunK = 0;
    function drawWeather2(now, rdt) {
      const D = tr.D, w = cv.w, h = cv.h;
      if (D.th === 'thunder') {
        if (!rain) rain = Array.from({ length: 70 }, () => ({ x: Math.random(), y: Math.random(), s: 0.7 + Math.random() * 0.6 }));
        ctx.strokeStyle = 'rgba(190,210,240,.35)'; ctx.lineWidth = 1; ctx.beginPath();
        for (const r of rain) { r.y += rdt * 1.6 * r.s; r.x -= rdt * 0.25 * r.s; if (r.y > 1.05) { r.y -= 1.1; r.x = Math.random() * 1.2; } if (r.x < -0.05) r.x += 1.1; const x = r.x * w, y = r.y * h; ctx.moveTo(x, y); ctx.lineTo(x - 5 * r.s, y + 16 * r.s); }
        ctx.stroke();
      }
      if (D.th === 'aurora') {
        ctx.fillStyle = 'rgba(16,26,64,.32)'; ctx.fillRect(0, 0, w, h);
        ctx.save(); ctx.globalCompositeOperation = 'lighter';
        for (let b = 0; b < 3; b++) {
          const y0 = h * (0.08 + b * 0.07), col = ['rgba(80,255,170,', 'rgba(90,200,255,', 'rgba(190,120,255,'][b];
          const g = ctx.createLinearGradient(0, y0 - 40, 0, y0 + 60); g.addColorStop(0, col + '0)'); g.addColorStop(0.5, col + '.16)'); g.addColorStop(1, col + '0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(0, y0 + 60);
          for (let x = 0; x <= w + 20; x += 20) ctx.lineTo(x, y0 + Math.sin(x / 70 + now / 1300 + b * 1.7) * 18 + Math.sin(x / 31 + now / 900) * 6);
          ctx.lineTo(w, y0 + 60); ctx.lineTo(w, y0 - 40); ctx.lineTo(0, y0 - 40); ctx.closePath(); ctx.fill();
        }
        ctx.restore();
      }
      if (D.th === 'haunt') {
        if (!ghosts) ghosts = Array.from({ length: 4 }, (_, k) => ({ ph: k * 1.7, r: 18 + k * 7 }));
        const fc = camTarget();
        if (fc) {
          ctx.save(); applyCam(ctx);
          for (const gh of ghosts) {
            const a = now / 4000 * (gh.ph % 2 ? 1 : -1) + gh.ph, x = fc.x + Math.cos(a) * gh.r, y = fc.y + Math.sin(a * 1.3) * gh.r * 0.8, bob = Math.sin(now / 400 + gh.ph) * 0.4;
            const al = 0.35 + 0.25 * Math.sin(now / 900 + gh.ph);
            ctx.save(); ctx.translate(x, y + bob); ctx.rotate(cam.a + Math.PI / 2); ctx.globalAlpha = al;
            ctx.fillStyle = '#eef2ff'; ctx.beginPath(); ctx.arc(0, -0.6, 1.6, Math.PI, 0); ctx.lineTo(1.6, 1.4);
            for (let q = 0; q < 4; q++) ctx.lineTo(1.6 - (q + 0.5) * 0.8, 1.4 - (q % 2 ? 0 : 0.6)); ctx.lineTo(-1.6, 1.4); ctx.closePath(); ctx.fill();
            ctx.fillStyle = '#1c1922'; ctx.beginPath(); ctx.arc(-0.55, -0.6, 0.28, 0, 7); ctx.arc(0.55, -0.6, 0.28, 0, 7); ctx.fill();
            ctx.restore();
          }
          ctx.restore();
        }
      }
      if (D.th === 'disco') { // sweeping club spotlights (flat translucent beams: cheap on phones)
        for (let k = 0; k < 3; k++) {
          const a = Math.sin(now / (1300 + k * 300) + k * 2) * 0.8, cx = w * (0.2 + 0.3 * k), ex = cx + Math.sin(a) * h * 0.7;
          ctx.fillStyle = ['rgba(255,95,180,.09)', 'rgba(79,227,255,.08)', 'rgba(255,209,102,.07)'][k];
          ctx.beginPath(); ctx.moveTo(cx - 5, 0); ctx.lineTo(cx + 5, 0); ctx.lineTo(ex + 60, h * 0.75); ctx.lineTo(ex - 60, h * 0.75); ctx.closePath(); ctx.fill();
        }
      }
      if (D.th === 'foundry') { // embers drifting up from the molten metal
        if (!rain) rain = Array.from({ length: 34 }, () => ({ x: Math.random(), y: Math.random(), s: 0.5 + Math.random() }));
        for (const r of rain) { r.y -= rdt * 0.08 * r.s; r.x += Math.sin(now / 700 + r.s * 9) * rdt * 0.01; if (r.y < -0.05) { r.y = 1.05; r.x = Math.random(); } ctx.fillStyle = 'rgba(255,' + Math.round(150 + r.s * 60) + ',60,' + (0.35 + 0.3 * Math.sin(now / 150 + r.s * 20)) + ')'; ctx.fillRect(r.x * w, r.y * h, 2 * r.s, 2 * r.s); }
      }
      if (tr.D.tunnels || tr.cuts.some((C) => C.tun)) { // the inside of a tunnel is dim
        tunK += ((inTunnel(camTarget()) ? 1 : 0) - tunK) * (1 - Math.exp(-rdt * 5));
        if (tunK > 0.01) {
          const fc = camTarget(), p = fc ? toScreen(fc.x, fc.y) : { x: w / 2, y: h / 2 };
          const g = ctx.createRadialGradient(p.x, p.y, Math.min(w, h) * 0.18, p.x, p.y, Math.max(w, h) * 0.7);
          g.addColorStop(0, 'rgba(10,8,6,' + 0.15 * tunK + ')'); g.addColorStop(1, 'rgba(10,8,6,' + 0.7 * tunK + ')');
          ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
        }
      }
    }
    function drawMovers() {
      const t = W.clock;
      for (const m of tr.mov) {
        const ml = moverLat(m, t), mx = m.x + tr.nx[m.i] * ml, my = m.y + tr.ny[m.i] * ml;
        if (!onScreen(mx, my, 10)) continue;
        if (m.ball) { // a big rolling toy ball: its stripes roll with it
          ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(mx + 0.8, my + 1.2, m.r, m.r * 0.9, 0, 0, 7); ctx.fill();
          ctx.save(); ctx.translate(mx, my); ctx.rotate(m.a);
          ctx.beginPath(); ctx.arc(0, 0, m.r, 0, 7); ctx.clip();
          ctx.fillStyle = '#f6f1e6'; ctx.fillRect(-m.r, -m.r, m.r * 2, m.r * 2);
          const roll = ((ml / m.r) % 1.6 + 1.6) % 1.6, cols = ['#e8384f', '#5bb3e6', '#ffd166', '#5fd3a0'];
          for (let q = -3; q <= 3; q++) { const y0 = (q * 1.6 + roll * 2 - 0.8) * m.r * 0.5; ctx.fillStyle = cols[(q + 4 + m.i) % 4]; ctx.fillRect(-m.r, y0, m.r * 2, m.r * 0.4); }
          ctx.restore();
          const g = ctx.createRadialGradient(mx - m.r * 0.35, my - m.r * 0.4, 0.1, mx, my, m.r);
          g.addColorStop(0, 'rgba(255,255,255,.55)'); g.addColorStop(0.5, 'rgba(255,255,255,0)'); g.addColorStop(1, 'rgba(0,0,0,.28)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(mx, my, m.r, 0, 7); ctx.fill();
          continue;
        }
        if (tr.D.th === 'factory') { // a forklift shuttling across the aisle, forks first
          const dir = Math.cos((t / m.per) * Math.PI * 2 + m.ph) >= 0 ? 1 : -1;
          ctx.save(); ctx.translate(mx, my); ctx.rotate(m.a);
          ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(-m.hx + 0.6, -m.hy + 0.9, m.hx * 2, m.hy * 2);
          ctx.fillStyle = '#9aa0a8'; ctx.fillRect(-m.hx * 0.7, dir * m.hy * 0.45, 0.45, dir * m.hy * 0.55); ctx.fillRect(m.hx * 0.7 - 0.45, dir * m.hy * 0.45, 0.45, dir * m.hy * 0.55);
          ctx.fillStyle = '#f2c230'; rr(ctx, -m.hx, -m.hy * 0.62 + (dir < 0 ? 0 : -m.hy * 0.2), m.hx * 2, m.hy * 1.45, 0.5); ctx.fill();
          ctx.fillStyle = '#2b2d33'; rr(ctx, -m.hx * 0.6, -m.hy * 0.35, m.hx * 1.2, m.hy * 0.7, 0.3); ctx.fill();
          ctx.fillStyle = Math.floor(performance.now() / 250) % 2 ? '#ffb347' : '#7a4a10'; ctx.beginPath(); ctx.arc(0, 0, 0.35, 0, 7); ctx.fill();
          ctx.strokeStyle = '#1c1d20'; ctx.lineWidth = 0.18; ctx.setLineDash([0.5, 0.5]); ctx.strokeRect(-m.hx, -m.hy * 0.62 + (dir < 0 ? 0 : -m.hy * 0.2), m.hx * 2, m.hy * 1.45); ctx.setLineDash([]);
          ctx.restore();
          continue;
        }
        ctx.save(); ctx.translate(mx, my); ctx.rotate(m.a);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(-m.hx + 0.8, -m.hy + 1.2, m.hx * 2, m.hy * 2);
        ctx.fillStyle = '#c0392b'; ctx.fillRect(-m.hx, -m.hy, m.hx * 2, m.hy * 2);
        ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 0.18;
        for (let k = -m.hy + 0.5; k < m.hy; k += 0.55) { ctx.beginPath(); ctx.moveTo(-m.hx, k); ctx.lineTo(m.hx, k); ctx.stroke(); }
        ctx.strokeStyle = '#ffd166'; ctx.lineWidth = 0.3; ctx.strokeRect(-m.hx, -m.hy, m.hx * 2, m.hy * 2);
        // crane cables
        ctx.strokeStyle = 'rgba(30,30,30,.6)'; ctx.lineWidth = 0.15; ctx.beginPath(); ctx.moveTo(-m.hx, -m.hy); ctx.lineTo(m.hx, m.hy); ctx.moveTo(m.hx, -m.hy); ctx.lineTo(-m.hx, m.hy); ctx.stroke();
        ctx.restore();
        // gantry beam across the road
        ctx.strokeStyle = 'rgba(232,163,61,.55)'; ctx.lineWidth = 0.9; ctx.lineCap = 'butt';
        const o = tr.half + 4.5; ctx.beginPath(); ctx.moveTo(m.x - tr.nx[m.i] * o, m.y - tr.ny[m.i] * o); ctx.lineTo(m.x + tr.nx[m.i] * o, m.y + tr.ny[m.i] * o); ctx.stroke(); ctx.lineCap = 'round';
      }
    }
    function drawBridge(cr) {
      const i0 = cr.over - 13, i1 = cr.over + 13, half = tr.half;
      ctx.save(); ctx.lineCap = 'butt'; ctx.lineJoin = 'round';
      const path = (off) => { ctx.beginPath(); for (let i = i0; i <= i1; i++) { const j = ((i % NS) + NS) % NS, px = tr.x[j] + tr.nx[j] * off, py = tr.y[j] + tr.ny[j] * off; i === i0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py); } };
      ctx.translate(1.2, 1.8); path(0); ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = half * 2 + 3; ctx.stroke(); ctx.translate(-1.2, -1.8);
      path(0); ctx.strokeStyle = '#6b4a2c'; ctx.lineWidth = half * 2 + 2.2; ctx.stroke();
      path(0); ctx.strokeStyle = '#8f6a43'; ctx.lineWidth = half * 2; ctx.stroke();
      ctx.strokeStyle = 'rgba(50,25,10,.45)'; ctx.lineWidth = 0.25;
      for (let i = i0; i <= i1; i++) { const j = ((i % NS) + NS) % NS; ctx.beginPath(); ctx.moveTo(tr.x[j] - tr.nx[j] * half, tr.y[j] - tr.ny[j] * half); ctx.lineTo(tr.x[j] + tr.nx[j] * half, tr.y[j] + tr.ny[j] * half); ctx.stroke(); }
      for (const s of [-1, 1]) { path(s * (half + 0.6)); ctx.strokeStyle = '#3d2814'; ctx.lineWidth = 0.9; ctx.stroke(); }
      ctx.restore();
    }

    /* ----- main loop ----- */
    let rdtLast = 0.016;
    /* ----- ghost run (this device only): the best full race per course + weather + durability setting.
       Stored in localStorage (record only, no effect on the race). The ghost is a translucent car that replays
       that run; at every quarter lap the time gap to it pops up over my car (− = ahead of the ghost). */
    const GH_PRE = 'racing.ghost.', GH_IDX = 'racing.ghost.idx', GH_MAX = 16, GH_DT = 0.1;
    let ghRec = null, ghBest = null, ghKey = '', ghLastCp = -1, ghSaved = false;
    const ghostOn = () => !!st && (st.gho === 'on' || ((st.gho == null || st.gho === 'auto') && !api.online)) && mySeat() >= 0 && isLocalHuman(mySeat());
    function ghLoad(k) { try { const s = window.localStorage.getItem(GH_PRE + k); const o = s ? JSON.parse(s) : null; return o && Array.isArray(o.p) && Array.isArray(o.cp) && o.t > 0 ? o : null; } catch (e) { return null; } }
    function ghSave(k, o) {
      try {
        const ls = window.localStorage; let idx = []; try { idx = JSON.parse(ls.getItem(GH_IDX) || '[]'); } catch (e) { idx = []; }
        if (!Array.isArray(idx)) idx = [];
        idx = idx.filter((x) => x !== k); idx.push(k);
        while (idx.length > GH_MAX) { const old = idx.shift(); ls.removeItem(GH_PRE + old); }
        ls.setItem(GH_PRE + k, JSON.stringify(o)); ls.setItem(GH_IDX, JSON.stringify(idx));
        return true;
      } catch (e) { return false; }
    }
    function ghostReset() {
      ghRec = null; ghBest = null; ghLastCp = -1; ghSaved = false; ghKey = '';
      if (!tr || !st || !ghostOn()) return;
      ghKey = tr.id + '.' + (st.wx | 0) + '.' + (st.hpo ? 0 : 1);
      ghBest = ghLoad(ghKey);
      ghRec = { p: [], cp: [], acc: 0 };
    }
    function ghostStep(dt) {
      const c = me();
      if (!ghRec || !c || !W.racing || phase !== 'race') return;
      if (c.out) { ghRec = null; return; }
      if (c.fin != null) {
        if (!ghSaved) {
          ghSaved = true;
          const t = c.fin / 1000;
          if (!ghBest || t < ghBest.t) {
            const o = { t: Math.round(t * 1000) / 1000, t0: ghRec.t0, p: ghRec.p, cp: ghRec.cp, d: Date.now() };
            if (ghSave(ghKey, o)) { say(c, ghBest ? '고스트 기록 경신! ' + fmtT(c.fin) : '고스트 기록 저장', '#c9b8ff'); ghBest = null; }
          }
        }
        return;
      }
      if (ghRec.t0 == null) ghRec.t0 = Math.round(W.clock * 1000) / 1000;
      while (ghRec.t0 + (ghRec.p.length / 3) * GH_DT <= W.clock + 1e-6) {
        ghRec.p.push(Math.round(c.x * 10), Math.round(c.y * 10), Math.round(wrapA(c.a) * 100));
        if (ghRec.p.length > 3 * 6000) { ghRec = null; return; } // very long race: stop recording
      }
      // checkpoints: every quarter lap (5 sectors), counted from the first crossing of the line
      if (c.crossed >= 1 && c.sec % 5 === 0) {
        const cp = (c.crossed - 1) * 4 + c.sec / 5;
        if (cp > ghLastCp && cp > 0) {
          ghLastCp = cp;
          const tm = Math.round(W.clock * 100) / 100;
          ghRec.cp[cp] = tm;
          if (ghBest && ghBest.cp[cp] > 0) {
            const d = tm - ghBest.cp[cp];
            say(c, (d <= 0 ? '−' : '+') + Math.abs(d).toFixed(2) + '초', d <= 0 ? '#5fd3a0' : '#ee6a55');
          }
        }
      }
    }
    function drawGhostCar() {
      if (!ghBest || !W || !(phase === 'race' || phase === 'done') || !W.racing && phase !== 'done') return;
      const p = ghBest.p, n = p.length / 3, f = (W.clock - (ghBest.t0 || 0)) / GH_DT, i = Math.floor(f);
      if (i < 0 || i >= n - 1) return;
      const u = f - i, k = i * 3, x = (p[k] + (p[k + 3] - p[k]) * u) / 10, y = (p[k + 1] + (p[k + 4] - p[k + 1]) * u) / 10;
      const a = p[k + 2] / 100 + wrapA(p[k + 5] / 100 - p[k + 2] / 100) * u;
      ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.globalAlpha = 0.42;
      ctx.fillStyle = '#c9b8ff'; rr(ctx, -2.3, -1.25, 4.6, 2.5, 0.8); ctx.fill();
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 0.25; ctx.stroke();
      ctx.fillStyle = 'rgba(40,30,80,.8)'; rr(ctx, 0.2, -0.9, 1.1, 1.8, 0.35); ctx.fill();
      ctx.globalAlpha = 0.6; ctx.strokeStyle = '#e8e0ff'; ctx.lineWidth = 0.2; ctx.setLineDash([0.6, 0.5]); ctx.beginPath(); ctx.arc(0, 0, 3.4, 0, 7); ctx.stroke(); ctx.setLineDash([]);
      ctx.restore();
    }
    function frame(rdt) {
      rdtLast = rdt;
      if (!tr || !W) return;
      frameNo++;
      const dt = rdt * SPD();
      takeovers();
      pollRemote();
      dropStale();
      if (phase === 'grid') {
        // AI-only screen (tests / spectating): the host starts on its own after a short look at the track
        if (api.isHost && st && st.ph === 'grid' && mySeat() < 0) {
          hostT += dt;
          if (hostT > 1.5) { hostT = -1e9; startRace(); }
        }
      } else if (phase === 'count') {
        const prevN = Math.ceil(cd);
        cd -= dt;
        const nowN = Math.ceil(cd);
        if (nowN !== prevN && nowN > 0) { api.sfx('tick'); api.buzz(8); }
        if (cd <= 0) {
          phase = 'race'; W.racing = true; goT = 1;
          api.sfx('pop'); api.buzz(40);
          // start boost: press the drift button in the last ~0.6 s of the countdown (too early = stall)
          const c = me();
          if (c && input.startTap != null) {
            if (input.startTap <= 0.6) { c.boost = 1.3 - input.startTap; say(c, '출발 부스트!', '#5fd3a0'); api.sfx('whoosh'); }
            else if (input.startTap > 1.4) { c.stall = 0.8; say(c, '너무 빨랐어요', '#ee6a55'); }
          }
          for (const a of W.cars) if (!a.remote && P(a.seat).ai && Math.random() < [0, 0.1, 0.35, 0.8][a.ailv || 2]) a.boost = 0.4 + Math.random() * 0.5;
          if (api.isHost && st && st.ph === 'count') api.setState(Object.assign({}, st, { ph: 'race' }));
        }
      }
      if (phase === 'race' || phase === 'done') {
        W.cruise = phase === 'done';
        tick(W, dt, ctl, hooks);
        drainEvents();
        ghostStep(dt);
      }
      smoothRemote(rdt);
      if (phase === 'race' && api.isHost) checkDone();
      standTick(dt);
      publish(rdt);
      emit(dt);
      updateCam(rdt);
      if (goT > 0) goT -= dt;
      if (bumpT > 0) bumpT -= dt;
      if (wallT > 0) wallT -= dt;
      shake = Math.max(0, shake - rdt * 3); punch = Math.max(0, punch - rdt * 3); engTick(); kaboom = Math.max(0, kaboom - rdt * 1.6); boomFlash = Math.max(0, boomFlash - rdt);
      { const m = me(); if (m && phase === 'race' && !m.out && m.fin == null) { if (m.hp < 30 && !lowWarn) { lowWarn = true; api.toast('내구도가 얼마 안 남았어요! 부딪히지 않게 조심!', 1800); api.buzz(40); } else if (m.hp > 45) lowWarn = false; } }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t -= dt; if (floats[i].t <= 0) floats.splice(i, 1); }
      ctlOn = mySeat() >= 0 && (phase === 'count' || phase === 'race') && !(me() && me().out);
      if (!ctlOn && ptrs.size) releaseAll();
      wheelTick(rdt);
    }
    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });
    cv.onresize = () => { layoutControls(); };
    const onCtl = () => { releaseAll(); layoutControls(); cam.ok = false; }; window.addEventListener('lounge-ctl', onCtl);
    layoutControls();

    return {
      update(next) {
        if (!next) return;
        st = next; HP_ON = !next.hpo; WX = next.wx | 0; NT = next.nt | 0;
        const tid = normId(next.t);
        if (!tr || tr.id !== tid) { setTrack(tid); if (W) resetCars(); }
        const k = next.rid + '.' + next.seq;
        if (next.ph === 'grid') {
          if (key !== 'g' + next.rid || phase !== 'grid' || !W) { key = 'g' + next.rid; resetCars(); phase = 'grid'; hostT = 0; }
          buildPicker(); syncPicker();
        } else {
          dropPicker();
          if (next.ph === 'count' || next.ph === 'race') {
            if (key !== k || !W) {
              key = k; resetCars();
              if (next.ph === 'count') { phase = 'count'; cd = 3; api.sfx('tick'); }
              else { phase = 'race'; W.racing = true; goT = 1; }
            }
          } else if (next.ph === 'done' || next.ph === 'stand') {
            if (key !== k || !W) { key = k; resetCars(); }
            phase = 'done'; W.racing = false; releaseAll();
          }
          if (next.ph === 'stand' && next.cs) showStand(); else dropStand();
        }
      },
      destroy() {
        engStop();
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        window.removeEventListener('lounge-ctl', onCtl);
        document.removeEventListener('visibilitychange', onVis);
        dropPicker(); dropStand();
        cv.destroy();
        styleEl.remove();
      },
      _dbg: () => ({ W, cam, input, wheel, phase, ctlTop, zones, cfg, setCfg, carScreen: () => { const c = me(); return c ? toScreen(c.x, c.y) : null; } }),
    };
  }

  /* ---------- 도감(codex): built from the data tables above (TRACKS · ITEMS · ITEM_DMG · GIM_DMG · FALL_DMG · ODDS) ---------- */
  function codexIcon(draw, w, h2) {
    const dpr = Math.min(2, window.devicePixelRatio || 1), c = L.h('canvas');
    c.width = Math.round(w * dpr); c.height = Math.round(h2 * dpr); c.style.width = w + 'px'; c.style.height = h2 + 'px'; c.style.display = 'block';
    const g = c.getContext('2d'); g.scale(dpr, dpr); draw(g); return c;
  }
  function trackThumb(id) {
    return codexIcon((g) => {
      const t = buildTrack(id), B = t.bx, th = THEME[t.D.th], s = Math.min(34 / (B[2] - B[0]), 34 / (B[3] - B[1]));
      g.fillStyle = th.base; rr(g, 0, 0, 36, 36, 8); g.fill();
      g.translate(18, 18); g.scale(s, s); g.translate(-(B[0] + B[2]) / 2, -(B[1] + B[3]) / 2);
      g.lineJoin = g.lineCap = 'round';
      g.beginPath(); for (let i = 0; i <= NS; i += 4) { const j = i % NS; i ? g.lineTo(t.x[j], t.y[j]) : g.moveTo(t.x[j], t.y[j]); } g.closePath();
      g.strokeStyle = 'rgba(23,19,31,.55)'; g.lineWidth = 3 / s; g.stroke();
      g.strokeStyle = '#f2e9d8'; g.lineWidth = 1.6 / s; g.stroke();
      for (const C of t.cuts) { g.beginPath(); for (let k = 0; k < C.n; k += 3) k ? g.lineTo(C.sx[k], C.sy[k]) : g.moveTo(C.sx[k], C.sy[k]); g.strokeStyle = '#e3ae45'; g.lineWidth = 1.2 / s; g.stroke(); }
    }, 36, 36);
  }
  const itemIcon = (k) => codexIcon((g) => { g.fillStyle = '#2a2236'; rr(g, 0, 0, 36, 36, 9); g.fill(); g.translate(18, 18); drawIcon(g, k, 13); }, 36, 36);
  const ITEM_HP = (k) => ITEM_DMG[k] || { rear: ITEM_DMG.cball, bomb: GIM_DMG.bang }[k] || 0;
  const ODDS_NM = { lead: '선두', mid: '중간', back: '뒤', last: '꼴찌' };
  /* how hard a track is (제가 정한 기준): narrow road, falling off, slippery, dark, hazards that hit, timing gates */
  const TRACK_FLAGS = [
    [(D) => D.half < 6.5, '좁은 길'],
    [(D) => D.water || D.rivers || D.gaps || D.leaps, '빠지면 복귀'],
    [(D) => ['metal', 'glacier', 'frozen', 'wet'].includes(D.deck) || D.ice.length || D.seasons, '미끄러움'],
    [(D) => D.night || D.dark || D.dusk || D.fog, '어두움'],
    [(D) => D.rocks || D.balls || D.geysers || D.twisters || D.cranes || D.herd || D.train || D.bolts || D.sweep, '내구도 깎는 기믹'],
    [(D) => D.doors || D.swing || D.dbr || D.ferry || D.plats || D.tiles || D.tide, '타이밍'],
  ];
  function gimName(D) { const m = /^([^:]{1,14}):/.exec(D.hint); return m ? m[1] : D.sub.split(' · ')[0]; }
  /* split a rules section into "이름: 설명" pieces by the known names */
  function rulesBy(sec, names) {
    const txt = ((sec && sec.p) || []).join(' '), at = [];
    names.forEach((n, i) => { const k = txt.indexOf(n + ':'); if (k >= 0) at.push([k, i, n]); });
    at.sort((a, b) => a[0] - b[0]);
    const out = {};
    at.forEach(([k, i, n], j) => { out[i] = txt.slice(k + n.length + 1, j + 1 < at.length ? at[j + 1][0] : txt.length).trim(); });
    return out;
  }
  function codex(el) {
    const def = L.games.racing || {}, rsec = (h) => (def.rules || []).find((s) => s.h === h);
    const trk = rulesBy(rsec('트랙'), TRACKS.map((D) => D.name)), itx = rulesBy(rsec('아이템'), ITEM_KEYS.map((k) => ITEMS[k].n));
    const hpRow = (name, tag, desc) => ({ ic: null, name, tag, desc });
    const secs = [
      { h: '트랙', p: ['50개 트랙, 트랙마다 기믹이 하나씩. 난이도는 좁은 길·추락·미끄러움·어두움·맞는 기믹·타이밍 수로 매겼어요.'], rows: () => TRACKS.map((D, i) => {
        const f = TRACK_FLAGS.filter(([t]) => t(D)).map(([, n]) => n), lv = f.length >= 3 ? '어려움' : f.length >= 1 ? '보통' : '쉬움';
        return { ic: () => trackThumb(i), name: (i + 1) + '. ' + D.name, tag: lv, desc: [D.sub, f.length ? '특징: ' + f.join(' · ') : '특징: 무난한 기본 코스'] };
      }) },
      { h: '아이템', p: ['「?」 상자를 지나면 하나 받아요. 순위에 따라 나오는 아이템이 달라요.'], rows: () => ITEM_KEYS.map((k) => {
        const where = ODDS_STEP.filter((s) => ODDS[s][k]).map((s) => ODDS_NM[s]), dmg = ITEM_HP(k);
        return { ic: () => itemIcon(k), name: ITEMS[k].n, tag: dmg ? '내구도 −' + dmg : '', desc: [itx[ITEM_KEYS.indexOf(k)] ? itx[ITEM_KEYS.indexOf(k)].replace(/\s*\([^)]*\)\.?$/, '') : ITEMS[k].d.replace(/\s*\(내구도 −\d+\)/, ''), '나와요: ' + (where.length ? where.join('·') : '혼자 달릴 때만')] };
      }) },
      { h: '기믹', p: ['트랙마다 다른 기믹. 출발 전 한 줄 힌트로도 보여 줘요.'], rows: () => TRACKS.map((D, i) => ({ ic: () => trackThumb(i), name: gimName(D), tag: D.name, desc: [trk[i] || D.hint] })) },
      { h: '생성 코스', p: ['「새 코스 생성」은 출발할 때마다 아래 테마 중 하나로 처음 보는 코스를 만들어요. 헤어핀·시케인·긴 직선·좁은 길·지름길·점프대가 섞여요.'], rows: () => GTH.map((g) => ({ ic: null, name: g.n, tag: '접지 ' + Math.round((SURF[g.deck] || SURF.road).g / GRIP * 100) + '%', desc: [g.tip, '길 밖: ' + ({ yard: '보도(조금 느림)', sand: '모래(아주 느림)', snow: '눈밭(아주 느림)', mud: '진흙(아주 느림)' }[g.off] || g.off) + (g.water ? ' · 그 너머 바다(추락)' : '') + (g.wall ? ' · 길가 벽' : ''), '지름길 바닥: ' + ({ road: '골목 포장길', dirt: '흙길', ice: '얼음판', wood: '통나무 길' }[g.cs] || g.cs), '이름 예: ' + g.words.slice(0, 3).join(' · ')] })) },
      { h: '세팅', p: ['출발 전 「세팅」에서 접지·최고속·가속에 6칸을 나눠요(한 칸마다: 접지 옆 미끄럼 −10%·꺾임 +6%, 최고속 +1.2%, 가속 +15%).'], rows: () => SETUPS.map((q) => ({ ic: null, name: q.n, tag: q.p.join('·'), desc: ['접지 ' + '●'.repeat(q.p[0]) + '○'.repeat(SETUP_MAX - q.p[0]) + '  최고속 ' + '●'.repeat(q.p[1]) + '○'.repeat(SETUP_MAX - q.p[1]) + '  가속 ' + '●'.repeat(q.p[2]) + '○'.repeat(SETUP_MAX - q.p[2])] })) },
      { h: '내구도', p: [
        '모든 차는 내구도 ' + HP_MAX + '으로 출발해요. 0이 되면 펑! 그 판은 탈락하고 관전해요. (옵션에서 끌 수 있어요)',
        '벽에 빠르게 정면으로 박으면 닳아요(한 번에 최대 −' + HIT_MAX + '). 다른 차를 들이받으면 들이받은 차가 더 많이 닳아요.',
        REGEN_WAIT + '초 동안 안 맞으면 1초에 ' + REGEN + '씩 저절로 고쳐지고, 새 랩마다 정비 +' + LAP_FIX + '.',
        '같은 종류 기믹에 5초 안에 또 맞으면 4분의 1만 닳아요. 30 아래면 연기가 나요.',
      ], rows: () => [].concat(
        ITEM_KEYS.filter((k) => ITEM_HP(k)).sort((a, b) => ITEM_HP(b) - ITEM_HP(a)).map((k) => ({ ic: () => itemIcon(k), name: ITEMS[k].n, tag: '아이템', desc: ['내구도 −' + ITEM_HP(k)] })),
        Object.keys(GIM_DMG).filter((k) => k !== 'bang').sort((a, b) => GIM_DMG[b] - GIM_DMG[a]).map((k) => hpRow({ rock: '낙석', ball: '눈덩이·굴러오는 공', gey: '용암 간헐천', tw: '회오리바람', mag: '전자석 크레인', herd: '양 떼', train: '기차', bolt: '번개', sail: '풍차 날개' }[k] || k, '기믹', ['내구도 −' + GIM_DMG[k]])),
        Object.keys(FALL_DMG).map((k) => hpRow({ sea: '바다에 빠짐', river: '강에 빠짐', lava: '용암에 빠짐', void: '우주로 떨어짐', gap: '끊긴 틈', sky: '구름 아래로', pit: '구멍', chasm: '낭떠러지' }[k] || k, '추락', ['내구도 −' + FALL_DMG[k] + ' (잠깐 사이 또 빠지면 피해 없음)'])),
      ) },
    ];
    const tabs = L.h('div', { class: 'chips' }), pane = L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const show = (k) => {
      pane.innerHTML = '';
      [...tabs.children].forEach((b, i) => b.classList.toggle('on', i === k));
      const sec = secs[k];
      (sec.p || []).forEach((t) => pane.append(L.h('p', { class: 'note', style: { margin: 0 }, text: t })));
      sec.rows().forEach((r) => {
        const ic = L.h('span', { class: 'cx-ic', style: { background: 'transparent' } });
        if (r.ic) ic.append(r.ic()); else ic.textContent = r.tag === '추락' ? '🕳' : '⚠';
        pane.append(L.h('div', { class: 'cx-row' }, ic, L.h('div', { class: 'cx-tx' },
          L.h('div', { class: 'cx-nm' }, L.h('b', { text: r.name }), r.tag ? L.h('span', { class: 'cx-tag', text: r.tag }) : null),
          ...r.desc.map((t) => L.h('div', { class: 'cx-d', text: t })))));
      });
    };
    const N = { 트랙: TRACKS.length, 아이템: ITEM_KEYS.length, 기믹: TRACKS.length };
    secs.forEach((sec, k) => tabs.append(L.h('button', { class: 'btn sm', text: sec.h + (N[sec.h] ? ' ' + N[sec.h] : ''), onclick: () => show(k) })));
    el.append(tabs, pane);
    show(0);
  }

  L.register({
    id: 'racing', name: '미니 레이싱', tag: '실시간',
    blurb: '왼쪽·오른쪽을 눌러 3바퀴! 양손도 한 손도 OK. 판마다 새로 만드는 코스(5가지 테마)와 기믹이 다른 트랙 50개, 출발 전 차량 세팅, 아이템 상자의 34가지 아이템으로 역전을 노려요. 차에는 내구도가 있어 너무 부딪히면 펑! 한 기기에 한 명씩.',
    options: [{ id: 'tod', label: '시간대', choices: [{ v: 'rnd', label: '무작위' }, { v: 'day', label: '낮' }, { v: 'night', label: '밤 (전조등·가로등만 밝음)' }], def: 'rnd' }, { id: 'wx', label: '날씨', choices: [{ v: 'rnd', label: '무작위' }, { v: 'sun', label: '맑음' }, { v: 'rain', label: '비 (조금 미끄러움)' }, { v: 'storm', label: '폭우 (많이 미끄럽고 물보라)' }, { v: 'snow', label: '눈 (미끄러움)' }], def: 'rnd' },
      { id: 'course', label: '코스', tip: '트랙 고르기.', choices: [{ v: 'gen', label: '무작위 생성 (판마다 새 코스)', tip: '판마다 새로 만든 코스.' }, { v: 'hand', label: '만든 트랙 50개 중 무작위', tip: '미리 만든 트랙 50개 중 하나.' }], def: 'gen' },
      { id: 'ghost', label: '고스트', tip: '이 기기에 저장된 내 최고 기록 주행이 반투명 차로 함께 달려요. 기록만 남고 경주엔 영향 없어요.', choices: [{ v: 'auto', label: '자동 (혼자·봇전 켬, 온라인 끔)' }, { v: 'on', label: '켬 (온라인도 각자 화면에)' }, { v: 'off', label: '끔' }], def: 'auto' },
      { id: 'champ', label: '챔피언십', tip: '코스 4개를 이어 달리고 순위 점수(1위 10 · 2위 7 · 3위 5 · 4위 3 · 탈락 0)를 더해 우승자를 가려요.', choices: [{ v: 'off', label: '한 경주' }, { v: 'on', label: '챔피언십 (4경주 연속)' }], def: 'off' },
      { id: 'hp', label: '내구도', tip: '켜면 부딪힐 때 차가 닳고 0이 되면 폭발해요.', choices: [{ v: 'on', label: '켬 (부딪히면 닳고 0이면 폭발)' }, { v: 'off', label: '끔' }], def: 'on' }],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0,
    controls: [
      { id: 'left', label: '왼쪽', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'drift', label: '드리프트·브레이크', keys: ['Space', 'ShiftLeft'], pad: ['a', 'rb'] },
      { id: 'item', label: '아이템', keys: ['ArrowUp', 'KeyX'], pad: ['x', 'lb'] },
    ],
    quick: [
      '목표: 3바퀴를 가장 먼저 돌면 1위',
      '조작: 왼쪽·오른쪽을 누르고 있으면 꺾여요(가속은 자동). 드리프트·아이템 버튼',
      '트랙마다 기믹이 하나씩! 출발할 때 나오는 한 줄 힌트를 보세요',
      '날씨가 비·폭우·눈이면 코너에서 미끄러워요. 앞차 물보라는 옆으로 비켜서 피하기',
      '차마다 내구도가 있어요. 세게 부딪히거나 많이 맞아 0이 되면 펑! 탈락',
    ],
    rules: [
      { h: '목표', p: ['트랙을 3바퀴 돌아 결승선을 가장 먼저 통과하면 1위예요.', '최대 4대가 달려요. 한 기기에서는 한 명만 운전해요. 나머지 자리는 AI가, 온라인에서는 친구들이 각자 폰으로 달려요.'] },
      { h: '진행', p: ['출발 전에 트랙을 골라요. 혼자 할 때는 내가, 온라인에서는 호스트가 고르고 「출발」을 눌러요. 기본은 「새 코스 생성」(설정의 「코스」 옵션에서 만든 트랙 무작위로 바꿀 수 있어요). 트랙 목록은 위아래로 밀면 더 나와요.', '무작위를 고르면 어떤 트랙인지 미리 보이지 않아요(호스트·친구 모두). 「출발」을 누르는 순간 정해지고, 카운트다운이 시작될 때 이름이 공개돼요.', '3, 2, 1 카운트다운 → GO! 모두 같은 출발선에 나란히 서서 출발해요(자리는 판마다 무작위, 안쪽·바깥쪽 차이는 출발 위치를 살짝 당기거나 미뤄 맞췄어요). 처음 결승선을 넘는 순간부터 1랩이에요.',
        '출발 직후 2초 동안은 차끼리 부딪히지 않고 스르륵 겹쳐 지나가요(반투명). 첫 코너에서 엉키지 않게 하려고요.', '트랙마다 고유한 기믹(움직이는 장애물·바닥 효과 등)이 하나씩 있어요. 트랙을 고르면 한 줄 힌트가 나오고, 카운트다운 때도 이름과 함께 보여 줘요(무작위는 이때 처음 공개).', '코스를 크게 가로지르거나 거꾸로 달려 결승선을 넘으면 랩으로 치지 않아요. 표시된 지름길은 괜찮아요.'] },
      { h: '밤 경주', p: ['설정의 「시간대」(기본 무작위): 낮 · 밤. 날씨와 함께 고를 수 있어요.', '밤에는 화면이 어두워지고 전조등(차 앞 부채꼴)·빨간 후미등·길가 가로등과 흰 반사판만 밝아요. AI도 같은 조건이에요.'] },
      { h: '날씨', p: ['설정의 「날씨」(기본 무작위): 맑음 · 비 · 폭우 · 눈.', '비는 옆 접지력이 20%, 눈은 26%, 폭우는 34% 줄어 코너에서 차가 바깥으로 미끄러져요. 코너 앞에서 일찍 꺾거나 살짝 브레이크를 밟으세요.', '비·폭우 때 바로 앞차 뒤에 붙으면 물보라가 튀어 화면 일부가 뿌옇게 가려져요(폭우일수록 심함). 옆으로 비켜 달리면 걷혀요.'] },
      { h: '조작', p: [
        '차는 알아서 가속해요. 누르고 있는 동안 그쪽으로 꺾이고, 떼면 바로 똑바로 가요. 끌거나 돌릴 필요 없어요.',
        '양손: 화면 아래쪽 왼쪽 절반을 누르고 있으면 왼쪽, 오른쪽 절반은 오른쪽으로 꺾여요. 누른 채 가운데를 넘어 미끄러뜨리면 방향이 바뀌어요. 그 위 양쪽 구석의 「드리프트」는 쉬는 엄지로, 가운데 동그라미는 아이템이에요.',
        '한 손(오른/왼): 엄지 쪽 아래에 ◀ ▶ 버튼, 그 위에 드리프트 막대, 맨 위에 아이템이 모여 있어요. ◀ 나 ▶ 를 누른 채 위로 밀어 올리면 그 방향으로 드리프트(막대의 ◀·▶ 칸), 다시 내리면 드리프트가 끝나요. 막대 가운데는 똑바로 드리프트 = 브레이크.',
        '화면의 핸들은 보여 주기용이에요. 지금 얼마나 꺾고 있는지에 맞춰 부드럽게 돌아가고, 떼면 가운데로 돌아와요.',
        '빨리 달릴수록 최대로 꺾이는 정도가 조금 줄어 직선에서 덜 휘청여요. 드리프트 중에는 언제나 끝까지 꺾여요.',
        '드리프트: 달리면서 한쪽으로 꺾은 채 드리프트를 누르고 있으면 미끄러지며 돌아요. 이어 가면 주황 → 파랑으로 차고(진동도 와요), 떼면 미니 터보 — 파란색이면 더 길어요. 안 꺾고 누르면 브레이크. 벽에 세게 부딪히면 충전이 사라져요.',
        '트랙 고르는 화면의 「버튼」에서 양손 / 한 손·오른 / 한 손·왼을 고를 수 있어요. 이 폰에 기억돼요.',
        '「자동 드리프트」를 켜면 빠르게 달리며 한쪽을 잠깐 누르고 있을 때 저절로 드리프트하고, 떼면 미니 터보가 나가요.',
        '출발 부스트: 카운트다운 「1」이 끝나기 직전(약 0.6초 안)에 드리프트를 누르면 터보로 출발해요. 너무 일찍 누르면 잠깐 멈칫해요.',
        'PC 키보드·게임패드도 돼요: ←→(A·D)·왼스틱으로 핸들, 스페이스·Shift·Ⓐ·RB 드리프트, ↑·X·Ⓧ·LB 아이템. 키는 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '슬립스트림', p: ['어느 트랙에서든 앞차 바로 뒤(차 몇 대 거리, 거의 같은 줄)에 붙어 달리면 바람막이를 타서 점점 빨라져요(약 1.5초면 최대). 차 옆으로 흰 바람 줄이 흐르면 타고 있는 거예요.', '≫ 표시 직선에서는 효과가 더 커요. 줄에서 벗어나면 금방 사라지니, 충분히 빨라졌을 때 옆으로 빠져 추월하세요.', '어려움 AI는 직선에서 뒤에 붙고, 앞에 있을 땐 줄을 바꿔 바람막이를 끊으려 해요.'] },
      { h: '새 코스 생성', p: [
        '「새 코스 생성」을 고르면 출발할 때마다 처음 보는 코스가 새로 만들어져요. 카운트다운 때 테마와 이름이 공개돼요.',
        '테마는 다섯 가지: 도시 야간(어둡고 길가에 벽, ≫ 직선 슬립스트림), 사막(모래 갓길·갈라진 길), 설산(눈길이라 조금 미끄럽고 파란 빙판), 해안 절벽(바깥은 바다 — 떨어지면 복귀), 숲(자갈길이라 조금 덜 붙고 바깥은 진흙).',
        '코스마다 헤어핀(U자 급커브), 시케인(좌우로 짧게 꺾이는 곳), 긴 직선, 좁아지는 길(주황 고깔), 지름길, 점프대가 섞여 나와요. 모든 코스는 길끼리 겹치지 않고 너무 급한 커브가 없도록 검사해서 만들어요.',
        '위험 구간(노란 점선 동그라미): 갈색 진흙 = 느려지고 드리프트 충전이 빠져요 · 하늘색 얼음 = 거의 안 붙어 미끄러져요 · 파란 물웅덩이 = 살짝 느려져요 · 검은 기름 = 미끄러지며 차 앞이 살짝 돌아가요. 한쪽에 몰려 있어서 옆으로 비켜 가면 돼요.',
        '지름길: 좁고 흙·얼음·나무다리 같은 길이라 빠르지만 벽에 긁히거나 미끄러지기 쉬워요. 어려움 AI는 지름길을 자주, 쉬움 AI는 거의 안 타요.',
        '고스트: 이 기기에서 같은 코스·날씨·내구도 설정으로 낸 내 최고 완주 기록이 보라색 반투명 「고스트」 차로 함께 달려요(부딪히지 않음). 4분의 1 바퀴마다 내 차 위에 차이가 떠요(초록 −는 고스트보다 빠름, 빨강 +는 느림). 더 빨리 완주하면 고스트가 바뀌어요. 기본은 혼자·봇전에서만 켜지고, 온라인에선 방에서 「켬」을 골랐을 때만 각자 화면에 보여요. 기록만 남고 경주엔 아무 영향이 없어요.',
        '출발선은 언제나 긴 직선 위라 안쪽·바깥쪽 차이가 거의 없어요.',
      ] },
      { h: '차량 세팅', p: [
        '출발 전 화면의 「세팅」에서 내 차를 고를 수 있어요(이 폰에 기억돼요). 균형 · 코너형 · 직선형 · 가속형, 또는 「조정」을 눌러 직접 맞춰요.',
        '접지·최고속·가속 세 가지를 합쳐 6칸이에요. 하나를 올리면 다른 쪽이 내려가서 모든 면에서 좋은 세팅은 없어요.',
        '접지 한 칸: 코너에서 옆으로 덜 미끄러지고 약 6% 더 잘 꺾이며, 꺾는 동안 속도를 덜 잃어요. 최고속 한 칸: 직선 끝 속도 약 1.2%. 가속 한 칸: 다시 빨라지는 힘 약 15%(부딪히거나 맞은 뒤에 특히 좋아요).',
        '급커브가 많으면 코너형, 빠른 굽이와 직선뿐이면 직선형이 잘 맞아요. 아이템·충돌로 자주 느려지는 혼전이면 가속형도 좋아요. 차이는 한 판에 1~2초 정도라 운전 실력이 더 중요해요. AI도 코스를 보고 세팅을 골라요(쉬움은 아무거나).',
        '랩마다 시간을 재서 이 기기의 최고 랩을 기록해요. 만든 트랙은 트랙마다, 생성 코스는 테마마다 따로 기록돼요.',
      ] },
      { h: '내구도', p: [
        '모든 차는 내구도 100으로 출발해요. 내 내구도는 왼쪽 위 순위 칸 아래 막대에, 다른 차는 차 위 작은 막대에 보여요(초록 → 노랑 → 빨강).',
        '살짝 스치거나 벽에 비비며 달리는 건 거의 안 닳아요. 빠르게 벽·기둥에 정면으로 박으면 닳고(곧바로 또 부딪히면 조금만), 다른 차를 세게 들이받으면 들이받은 쪽이 거의 다 떠안아요. 8초 안에 또 들이받으면 점점 더 많이 닳아요.',
        '공격 아이템과 트랙 기믹에 맞아도 닳아요. 예: 로켓·유도탄 −18, 째깍 폭탄 −20, 기차 −14, 낙석 −10. 물·용암에 빠지면 −4~−10(잠깐 사이 또 빠지면 안 닳아요). 방패로 막으면 안 닳아요. 공격을 연달아 여러 번 맞으면 터질 수 있어요.',
        '4초 동안 아무것에도 안 맞으면 조금씩(1초에 0.5) 저절로 고쳐지고, 결승선을 지나 새 랩을 시작할 때마다 정비 +30.',
        '내구도가 0이 되면 차가 펑 터져서 탈락! 그 판은 더 달릴 수 없고 관전해요. 탈락한 차는 완주한 차와 아직 달리는 차보다 아래 순위예요(탈락끼리는 더 멀리 간 차가 위).',
        '내구도가 30 아래로 내려가면 차에서 연기가 나고 알림이 떠요. 조심해서 달리세요!',
        '예시: 벽에 전속력으로 정면충돌 약 −15, 로켓 한 방 −18 → 남은 내구도 67. 새 랩에 들어서면 정비로 97까지 회복.',
      ] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움: 느리고 라인이 흔들리며 기름도 잘 못 피하고, 아이템을 아무 때나 써요. 앞서면 속도를 늦춰 줘요.',
        '보통: 적당히 빠르고 아이템을 노려서 써요.',
        '어려움: 가장 빠르고 코너 안쪽을 정확히 타며, 로켓은 조준해서·방패는 공격이 올 때 써요. 뒤처지면 힘껏 따라잡아요.',
        '트랙 기믹도 AI가 알아서 피하거나 이용해요. 쉬움은 가끔 못 보고 걸리고, 어려움은 미리 길을 골라 거의 안 걸려요.',
        '내구도: 쉬움은 신경 쓰지 않고 막 달려요. 보통은 내구도가 줄면 앞차를 피해 추월하고, 어려움은 늘 앞차를 비켜 가며 많이 닳으면 코너를 조심해서 돌아요.',
      ] },
      { h: '아이템', p: [
        '트랙 위 무지개 「?」 상자를 지나가면 아이템을 하나 받아요. 상자는 약 4초 뒤 다시 생기고, 누가 먹으면 모두의 화면에서 사라져요.',
        '한 번에 하나만 들 수 있어요(들고 있으면 상자만 깨져요). 순위에 따라 나오는 아이템이 달라요 — 앞선 차는 방어·함정, 중간은 공격, 뒤처질수록 따라잡는 아이템이 잘 나와요. 1위와 1/5바퀴 넘게 벌어지면 한 단계 더 따라잡기 좋은 아이템이 나와요. 괄호 안은 잘 나오는 순위예요.',
        '모든 아이템은 아래쪽 아이템 버튼에 그림으로 보여요. 받는 순간엔 그림이 빙글빙글 돌다가 멈춰요. 야시장 골목의 진열대는 지금 받을 아이템 그림을 미리 보여 줘요.',
        '터보 캔: 1.3초 동안 최고 속도 1.4배, 잔디·모래에서도 빨라요. 터보 캔 ×3은 세 번 쓸 수 있어요. (모든 순위 / ×3은 중간 이하)',
        '기름 웅덩이: 차 뒤에 떨어뜨려요. 밟은 차는 약 1초 미끄러지며 돌아요(내구도 −3). 30초 뒤 말라요. (선두·중간)',
        '로켓: 앞으로 곧장 날아가 처음 맞은 차를 뒤집어요(약 1.35초, 내구도 −18). 벽이나 코스 밖에서 터져요. (선두·중간·뒤)',
        '유도탄: 순위 바로 앞 차를 쫓아가 맞혀요(내구도 −18). 1위가 쓰면 로켓처럼 곧장 날아가요. (중간·뒤·꼴찌)',
        '방패: 공격 한 번(연막탄·집게 손을 뺀 모든 아이템, 거대해진 차와의 충돌, 트랙 기믹)을 막아요. 12초 동안 유지돼요. (선두·중간)',
        '번개 구름: 꼴찌(3명 이상일 때)에게만 나와요. 쓰는 순간 나보다 앞선 차 모두 2.5초 동안 느려져요.',
        '자석: 3초 동안 순위 바로 앞 차 쪽으로 끌려가며 최고 속도 1.2배. 앞 차가 없으면 짧은 터보가 돼요. (중간·뒤·꼴찌)',
        '스프링 지뢰: 차 뒤에 놓아요. 밟은 차는 약 1초 공중으로 튕겨 올라 빙글 돌고 속도를 잃어요(내구도 −10). 25초 뒤 사라져요. (선두·중간)',
        '연막탄: 차 뒤에 연기를 8초 동안 피워요. 연기를 지나간 차는 3초 동안 화면이 뿌옇게 가려져요(AI는 흔들리고 느려져요). 방패로 못 막아요. (선두·중간)',
        '순간이동: 트랙을 따라 차 7대 길이쯤 앞으로 휙 이동해요. 이동하는 동안은 아무것에도 안 맞고, 강·끊긴 길 위에는 내려앉지 않아요. (뒤·꼴찌)',
        '얼음 폭탄: 앞쪽 길로 던져요. 떨어진 자리에 있던 차는 1.1초 꽁꽁 얼어 멈추고(내구도 −8), 그 자리에 7초 동안 미끄러운 얼음판이 남아요. (선두·중간·뒤)',
        '반사 방패: 8초 동안 날아오는 로켓·유도탄을 쏜 차에게 되돌려 보내요(되돌아간 건 유도탄처럼 쫓아가요). 다른 공격은 못 막아요. (선두·중간)',
        '거대화: 5초 동안 1.5배로 커지고 조금 빨라져요. 부딪힌 차는 튕겨 나가 빙글 돌고(내구도 −10), 기름·스프링·얼음 폭탄은 깔아뭉개요. 로켓 같은 공격에 맞으면 원래 크기로 돌아와요. (뒤·꼴찌)',
        '부메랑: 앞으로 날아갔다가 나에게 되돌아와요. 오가는 길에 닿은 차는 한 번씩 0.9초 빙글 돌아요(내구도 −10). (선두·중간·뒤)',
        '압정: 차 뒤로 길을 가로질러 넓게 뿌려요. 밟은 차는 바퀴가 펑크 나 1.7초 동안 느려져요(돌지는 않아요, 내구도 −5). 14초 뒤 사라져요. (선두·중간)',
        '충격파: 내 둘레로 퍼져 가까이(차 2대 길이쯤) 있는 차를 밀어내고 0.7초 돌려요(내구도 −8). 앞뒤 모두 맞아요. (선두·중간)',
        '거미줄: 앞으로 쏘아요. 맞은 차는 거미줄에 걸려 1.8초 동안 아주 느려져요. 방패로 막을 수 있어요. (중간·뒤)',
        '집게 손: 순위 바로 앞(아이템을 든 차 중 가장 가까운) 차의 아이템을 빼앗아 내 것으로 해요. 뺏을 게 없으면 짧은 터보. 1위에게는 나오지 않아요. (중간·뒤·꼴찌)',
        '유령: 4초 동안 반투명해져 다른 차·아이템·장애물(기둥·컨테이너·기차·회오리 등)을 그냥 통과해요. 벽·물·구멍은 그대로예요. (뒤·꼴찌)',
        '점프: 그 자리에서 약 0.9초 높이 뛰어요. 날아오는 공격과 바닥 함정을 피하고, 좁은 틈도 넘을 수 있어요. (모든 순위)',
        '험로 타이어: 6초 동안 잔디·모래·진흙 같은 길 밖에서도 거의 길처럼 달려요(얼음은 그대로). 과감하게 질러가세요! (중간·뒤·꼴찌)',
        '풍선: 3초 동안 둥실 떠서 물·틈·잔디·바닥 함정 위를 그냥 지나가요. 벽은 못 넘고, 날아오는 공격에 맞으면 펑 터져요. 끝날 때 물 위면 빠지니 조심! (중간·뒤·꼴찌)',
        '자율주행: 4초 동안 차가 알아서 좋은 길로 달리고 조금(약 8%) 빨라져요. 그동안 핸들은 쉬어도 돼요. (뒤·꼴찌)',
        '불꽃놀이: 앞쪽 세 방향(가운데·왼쪽·오른쪽)으로 작은 폭죽을 쏴요. 맞은 차는 0.8초 빙글(내구도 −8). 사정거리가 짧아요. (중간)',
        '물감 폭탄: 앞으로 던져요. 맞은 차는 3초 동안 화면에 물감이 튀어 앞이 가려져요(조금 느려짐). (중간·뒤)',
        '바리케이드: 차 뒤에 줄무늬 길막이를 세워요(12초). 부딪힌 차는 확 느려지고(내구도 −12) 길막이는 부서져요. (선두)',
        '소용돌이 덫: 차 뒤에 놓아요(10초). 가까이 온 차를 빙글 빨아들이고 느리게 해요. (선두·중간)',
        '째깍 폭탄: 순위 바로 앞 차를 쫓아가 지붕에 붙어요. 3초 뒤 펑!(내구도 −20) 그 전에 다른 차에 부딪히면 폭탄이 그 차로 넘어가요. (중간·뒤)',
        '거품 줄: 내 뒤 차선에 길게 미끄러운 비누 거품을 깔아요(12초). 밟으면 쭉 미끄러져요. (선두)',
        '호위 드론: 12초 동안 내 둘레를 돌며 날아오는 공격(로켓·유도탄·거미줄·폭죽 등)을 2번까지 쏴서 떨어뜨려요. 바닥 함정은 못 막아요. (선두)',
        '송풍기: 앞쪽 부채꼴로 바람을 쏴요. 그 안의 차는 옆으로 휙 밀리고, 앞에 깔린 기름·압정·거품 같은 함정도 날아가요. (선두·중간)',
        '뒤로 대포: 뒤쪽으로 대포알을 곧장 쏴요. 따라오는 차를 맞혀요(내구도 −16). (선두)',
        '벌떼: 순위 바로 앞 차를 쫓아가 3초 동안 따끔따끔(조금 느려지고 핸들이 흔들려요, 내구도 −6). 방패로 막아요. (중간·뒤·꼴찌)',
        '1위에게는 쫓아가는 아이템(유도탄·집게 손·벌떼·째깍 폭탄)이 나오지 않아요.',
        'AI도 아이템을 써요. 쉬움은 아무 때나, 보통은 노려서, 어려움은 가장 알맞은 때(공격이 올 때 방패·반사, 굽은 길 앞에서 순간이동 등)에 써요.',
      ] },
      { h: '트랙', p: [
        '플럼 서킷: 기본 서킷. 기믹은 슬립스트림 — 하늘색 ≫ 표시 직선에서 앞차 바로 뒤에 붙어 달리면 빨라져요(추월 기회!). 코스 밖 잔디는 많이 느려요.',
        '사막 협곡: 기믹은 낙석 — 길에 그림자가 생기고 점점 진해지면 곧 바위가 떨어져요. 떨어진 바위는 6초 동안 길을 막다가 부서져요. 모래 갓길, 점프대, 흙길 지름길.',
        '눈꽃 고개: 기믹은 눈덩이 — 길가 주황 화살표가 깜빡이면 언덕에서 큰 눈덩이가 길을 가로질러 굴러와요. 맞으면 눈을 뒤집어쓰고 느려지고, 지나간 자리엔 눈이 쌓여 잠깐 느려요. 빙판·얼음 호수 지름길도 있어요.',
        '밤의 도시: 기믹은 일반 차 — 택시·버스 같은 차들이 천천히 코스를 달려요. 부딪히면 막히니 옆으로 추월하세요(깜빡이 켠 차는 차선을 바꿔요). 직각 코너와 골목 지름길.',
        '해변 루프: 기믹은 파도 — 양쪽이 바다인 둑길에 하얀 파도가 밀려와 차를 옆으로 밀고 잠깐 느리게 해요. 길 가운데로 달리세요. 물에 빠지면 잠깐 뒤 복귀해요.',
        '숲속 8자: 8자로 교차하는 숲길, 두 번째 지날 때는 다리 위로 지나가요(다리 위·아래 차는 서로 부딪히지 않아요). 통나무 다리 지름길.',
        '화산 분화구: 기믹은 용암 간헐천 — 길 위 구멍이 부글부글 빛나면 곧 용암이 솟아 닿은 차를 띄워 올려요. 구멍마다 일정한 박자로 솟아요. 안쪽 용암 호수에 빠지면 복귀해요.',
        '정글 폭포: 폭포에서 흘러온 강이 코스를 두 번 가로질러요. 통나무 두 개 위로만 건널 수 있고, 통나무를 벗어나면 물에 빠져 복귀해요. 바깥은 진흙.',
        '고대 유적: 기믹은 무너지는 바닥 — 돌판 구간에서 금 간 칸(깜빡이는 테두리)이 곧 꺼져 구멍이 돼요. 빠지면 복귀해요. 한 줄은 꼭 남으니 그 줄로! 돌기둥과 직각 코너도 조심.',
        '우주 정거장: 금속 바닥은 잘 미끄러져요(빙판보다는 덜). 길 밖 판 너머와 바닥이 끊긴 틈은 우주 — 떨어지면 잠깐 뒤 복귀해요. 틈은 좁은 다리로만 건너요. 무중력처럼 보이는 건 장식이에요.',
        '놀이공원: 분홍 범퍼에 닿으면 통 튕겨 나가요. 점프대 두 개, 가속 패드가 많고 짧은 지름길이 있어요.',
        '항구 크레인: 크레인에 매달린 컨테이너가 길을 가로질러 왔다 갔다 해요(부딪히면 막혀요). 부두 바깥은 바다 — 빠지면 복귀해요. 직각 부두 코너.',
        '사탕 공장: 주황 시럽 웅덩이에 들어가면 확 느려지고 드리프트 충전이 빠져요. 사탕 지팡이 벽에 부딪히면 통 튕겨 나와요.',
        '해저 터널: 유리 터널 속, 파란 물살 구간에서는 해류가 차를 옆으로 밀어요(움직이는 화살표 방향). 반대로 꺾어 버티세요.',
        '구름 위 하늘길: 길이 세 번 끊겨 있어요. 끊긴 곳 바로 앞 노란 스프링 판을 밟으면 점프해서 건너요(느려도 튕겨 줘요). 길 밖 구름 너머나 틈으로 떨어지면 잠깐 뒤 복귀해요.',
        '모래폭풍 사막: 모래폭풍 구간에 들어가면 화면이 누렇게 흐려져 앞이 잘 안 보여요. 소용돌이 모래 구덩이는 느리고 가운데로 빨아들여요.',
        '기차 건널목: 기차가 정해진 시간마다 지나가요. 차단기가 내려오고 빨간 불이 깜빡이면 멈춰서 기다리세요. 기차에 닿으면 옆으로 튕겨 빙글 돌아요.',
        '동굴 광산: 어두운 갱도라 헤드라이트와 벽 등불 근처만 보여요. 광차 레일 위에 똑바로 올라타면 빠른 길(최고 속도 약 1.2배)이에요.',
        '벚꽃 산길: 폭이 좁은 헤어핀 산길. 분홍 ≫ 표시 내리막은 빠르고, 주황 › 표시 오르막은 느려요.',
        '장난감 방: 나무 장난감 길 위를 달려요. 커다란 공이 길을 가로질러 굴러다녀요(부딪히면 밀려나요). 블록 탑은 피하고, 책 점프대로 날아요. 바깥 카펫은 느려요.',
        '풍차 마을: 풍차 날개가 길 위를 낮게 쓸고 지나가요. 날개에 닿으면 길 건너편으로 튕겨 빙글 돌아요. 풍차 반대쪽 가장자리는 날개가 닿지 않아요. 운하는 좁은 다리로만 건너요.',
        '번개 고원: 비 오는 밤이라 길이 조금 미끄러워요. 길 위에 노란 원이 깜빡이면 곧 번개가 떨어져요 — 원 밖으로 피하세요. 맞으면 빙글 돌아요(방패로 막을 수 있어요).',
        '물류 센터: 노란 화살표 컨베이어 벨트는 앞으로 실어 날라 빨라져요. 빨간 화살표 벨트는 거꾸로 돌아 느려지고, 옆으로 도는 벨트는 차를 옆으로 밀어요. 지게차가 길을 가로질러요.',
        '바닷길 갯벌: 안쪽 갯벌을 가로지르는 모래 바닷길은 물이 빠졌을 때만 빨라요. 물이 차오르면 아주 느려져요. 오른쪽 위 「바닷길」 표시가 열림·잠김과 남은 시간을 알려 줘요. 바깥 바다에 빠지면 복귀해요.',
        '유령 저택: 산울타리 사이로 철문 길이 세 번 나와요. 가운데 벽으로 두 갈래가 되고 철문이 번갈아 열려요. 갈림길 앞 등불이 초록이면 열림, 주황이면 곧 닫힘, 빨강이면 닫힘 — 열린 쪽으로 들어가세요.',
        '오로라 빙하: 길 전체가 얼음이라 잘 미끄러져요(빙판보다는 덜). 갈라진 틈은 양쪽 얼음 다리로만 건너요 — 한가운데로 가면 빠져요. 얼음 기둥 조심.',
        '터널 고개: 갈림길! 고갯길(가속 패드 두 개)로 돌아가거나, 좁고 어두운 터널로 질러갈 수 있어요. 터널 안에서는 지붕이 비쳐 보여요. 양옆은 가드레일.',
        '회오리 평원: 회오리바람 두 개가 코스를 따라 천천히 움직이며 좌우로 흔들려요. 가까이 가면 빨려 들어가고, 한가운데에 닿으면 공중으로 빙글 날아가요. 반대쪽으로 비켜 추월!',
        '고철 처리장: 전자석 크레인이 길 한쪽 위에 매달려 있어요. 노란 불이 깜빡이면 곧 켜지고, 파랗게 켜지면 근처 차를 끌어당겨요. 한가운데 닿으면 철컥 붙잡혀 잠깐 멈춰요. 반대쪽 가장자리로!',
        '운하 도시: 운하를 건너는 다리가 빙글 돌아요. 초록 불이면 다리가 길과 이어져 있고, 주황이면 곧 돌아가요, 빨강이면 끊겨 있어요 — 정지선 앞에서 기다리세요. 다리는 길 가운데에 있어요.',
        '마법 도서관: 길 위 마법 문이 빛나는 동안 들어가면 조금 앞쪽 출구로 순간이동해요(구불구불한 곳을 건너뛰어요). 꺼진 문은 그냥 바닥이에요. 책장 벽 사이 구불구불 복도.',
        '네온 디스코: 바닥이 세 줄 색으로 빛나요. 초록(≫) 줄은 빨라지고 빨간(×) 줄은 느려져요. 색은 박자마다 옆 줄로 옮겨 가니 초록을 따라가세요(바뀌기 직전엔 깜빡여요).',
        '제철소: 쇳물 수로는 좌우로 천천히 움직이는 철판 발판 두 개로만 건너요. 발판 사이나 바깥으로 가면 쇳물에 빠져 복귀해요. 발판이 오는 쪽을 노리세요.',
        '시계탑 광장: 길 위 둥근 회전판(시계 판)이 돌아가요. 올라가면 차가 판과 함께 돌아가니 화살표 반대로 살짝 꺾어 버티세요.',
        '진흙 랠리: 자갈길. 진흙탕을 지나면 차에 진흙이 붙어 점점 느려져요(왼쪽 위 「진흙」 막대). 파란 물웅덩이를 지나면 씻겨요. 진흙은 조금씩 저절로도 떨어져요. 점프대도 있어요.',
        '붉은 절벽: 길이 협곡으로 세 번 끊겨 있어요. 바로 앞 점프대에서 날아서 건너는데, 빠를수록 멀리 날아요. 너무 느리면(맞거나 벽에 부딪힌 직후) 떨어져서 조금 뒤에서 다시 달려요. 점프대 앞 가속 패드를 꼭 밟으세요!',
        '나루터 강: 강은 나룻배로 건너요. 길이 가운데 둑으로 두 줄이 되고, 줄마다 배가 한 척씩 번갈아 다녀요. 등불이 초록이면 그 줄 배가 기다리는 중, 주황이면 곧 떠나요, 빨강이면 배가 없어요 — 차단기 앞에서 기다려요. 배 위에선 저절로 건너가요.',
        '루프 스타디움: 기울어진 경사 커브(파랑·흰 줄무늬 가장자리)에서는 차가 잘 안 미끄러지고, 높은 바깥쪽일수록 빨라요. 작은 고리 길이 큰 길 위로 다리처럼 지나가요.',
        '사거리 도심: 대각선 큰길이 한가운데서 같은 높이로 만나는 사거리! 다른 차와 진짜로 부딪힐 수 있어요. 신호등은 안내만 해요(초록인 쪽이 안전). 공격도 사거리를 지나 날아가요.',
        '황혼 목장: 양 떼가 줄지어 길을 건너요(앞에 노란 표지판이 깜빡이면 곧 나와요). 부딪히면 막히고 살짝 돌아요. 해가 져서 점점 어두워지니 마지막 랩엔 헤드라이트 빛만 보여요.',
        '바람의 대교: 바다 위 긴 다리에서 옆바람이 불어요. 바람 자루가 펄럭이고 주황 줄무늬가 보이면 곧 돌풍 — 화면 위 화살표 방향으로 밀리니 반대로 살짝 꺾어 버티세요. 다리 밖은 바다예요.',
        '스키 슬로프: 눈 덮인 내리막을 지그재그로! 빨강·파랑 깃발 두 개 사이로 지나가면 살짝 빨라져요(깃발마다 한 번). 마지막 오르막은 느려요.',
        '하늘 축제: 별 모양 축제 길. 줄에 매달린 빛 고리가 길 위를 좌우로 왔다 갔다 해요. 고리를 통과하면 터보! 별 끝의 급커브는 조심.',
        '계절 숲길: 랩마다 계절이 바뀌어요. 1랩 봄은 보통, 2랩 장맛비는 길이 젖어 조금 미끄럽고, 3랩 눈길은 많이 미끄러워요(길 밖도 눈밭). 화면 위에 지금 계절이 보여요.',
        '야시장 골목: 길 위 진열대에 아이템 그림이 떠 있고 몇 초마다 바뀌어요(테두리가 줄어들면 곧 바뀜). 빈손일 때 지나가면 그 아이템을 바로 받아요. 원하는 그림이 보일 때 지나가세요!',
        '얼음 호수: 얼음 길이라 조금 미끄러워요. 파란 물웅덩이를 지나면 살짝 느려지고, 바로 뒤에 붙은 차는 물보라에 잠깐 앞이 가려져요. 가운데 호수에 빠지면 복귀해요.',
        '도개교 항구: 운하 위 다리가 올라갔다 내려와요. 등불 초록 = 지나가요, 주황 = 다리가 움직이는 중(빠르면 점프로 건널 수 있어요!), 빨강 = 다 올라감, 기다려요.',
        '갈림길 계곡: 갈림길이 두 곳. 하나는 낭떠러지를 뛰어넘는 빠른 길과 흔들다리로 돌아가는 안전한 길, 다른 하나는 흙길 지름길이에요.',
        '달 크레이터: 달이라 점프가 길고 둥실 떠요(공중에서도 조금 꺾여요). 길 위 크레이터 가장자리를 지나면 통 튀어 올라요. 길 밖 먼지는 느려요.',
        '밤 고속도로: 깜깜한 밤이라 헤드라이트와 가로등 근처만 보여요. 차들이 천천히 달리니 옆으로 추월하고, ≫ 표시 구간에서는 앞차 뒤에 붙으면 빨라져요.',
        '노란 화살표 패드는 약 1초 가속. 바깥 진흙·눈·모래·화산재는 느리고 미끄러워요. 오래 멈춰 있으면 코스로 되돌려 줘요.',
        '방패는 트랙 기믹(낙석·눈덩이·간헐천·회오리·전자석·번개·기차·양 떼·째깍 폭탄 등)의 한 번도 막아 줘요. 유령 상태면 장애물 기믹을 그냥 통과해요.',
      ] },
      { h: '끝나는 조건', p: ['모두 완주하거나 탈락하면 바로 끝나요.', '사람이 처음 완주한 뒤 15초, 누구든 처음 완주한 뒤 45초가 지나면 끝나요. 최대 5분.', '사람이 모두 탈락하면(완주한 사람이 없을 때) 3초 뒤 끝나요. 그때 순위 그대로예요.', '못 들어온 차는 달린 거리 순으로 순위가 매겨져요. 탈락한 차는 그 아래예요.', '온라인에서 친구가 나가면 그 차는 AI가 이어서 달려요.'] },
      { h: '챔피언십', p: ['옵션 「챔피언십」을 켜면 코스 4개를 이어 달려요. 첫 코스는 트랙 고르기 그대로, 다음부터는 같은 종류(생성/만든 트랙)에서 겹치지 않게 무작위예요.', '점수: 1위 10 · 2위 7 · 3위 5 · 4위 3 · 탈락 0점.', '경주 사이에 순위표(총점·순위 변화)가 나오고, 12초 뒤나 「다음 경주」를 누르면 다음 경주가 시작돼요.', '총점이 같으면 1위 횟수 → 2위 횟수 … → 마지막 경주 순위로 가려요.'] },
    ],
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount, codex,
    _t: { raftAt, dbAng, herdAt, herdLat, gustAt, hoopLat, showItem, rockWave, rockT0, ballAt, trafficCar, waveFront, geyS, geyK, tileState, twPos, magS, swingAng, portOn, discoCol, laneAt, gzCost, renderTrack, segDist, moverLat, buildTrack, newWorld, tick, stepCar, aiInput, aiItem, setAiLevel, useItem, ranking, progress, rollItem, hitTest, moveHazards, collideCars, trainFront, trainOcc, frostOn, TRACKS, NS, LAPS, ITEMS, ODDS, gridSlot, genDef, GEN0, GEN_N, GEN_STAT, GTH, normId, trackDef, champOrder, champAdd, champNext, CH_N, CH_PTS, applySetup, aiSetup, SETUPS },
  });
})();
