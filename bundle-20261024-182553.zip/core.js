/* 한판 라운지 — core shell: menu, local setup, online rooms (artifact `room` capability), AI scheduling. */
(function () {
  'use strict';
  const L = (window.Lounge = { games: {}, order: [] });

  /* 일시정지용 가상 시계: 멈춘 동안 performance.now와 requestAnimationFrame 시각이 흐르지 않는다.
     실시간 게임은 시간을 rAF 시각이나 performance.now로 재면 따로 손대지 않아도 멈춘다. */
  const Clock = (() => {
    const perf = window.performance, realNow = perf.now.bind(perf);
    let pausedAt = null, offset = 0;
    try { perf.now = () => (pausedAt != null ? pausedAt : realNow()) - offset; } catch (e) { /* read-only */ }
    const rRAF = window.requestAnimationFrame.bind(window), rCAF = window.cancelAnimationFrame.bind(window);
    let nid = 1; const map = new Map();
    function queue(id, cb) {
      map.set(id, rRAF((t) => {
        if (!map.has(id)) return;
        if (pausedAt != null) { queue(id, cb); return; }   // 멈춘 동안은 다음 프레임으로 미룸
        map.delete(id); cb(t - offset);
      }));
    }
    window.requestAnimationFrame = (cb) => { const id = nid++; queue(id, cb); return id; };
    window.cancelAnimationFrame = (id) => { const r = map.get(id); if (r != null) rCAF(r); map.delete(id); };
    return {
      realRAF: rRAF,
      pause() { if (pausedAt == null) pausedAt = realNow(); },
      resume() { if (pausedAt != null) { offset += realNow() - pausedAt; pausedAt = null; } },
      get paused() { return pausedAt != null; },
    };
  })();
  L.clock = Clock;
  const COLORS = ['#ee6a55', '#5bb3e6', '#e8c04e', '#5fd3a0', '#b48cf0', '#f07fb8', '#9ad14f', '#f0a050'];
  for (let i = COLORS.length; i < 64; i++) COLORS.push('hsl(' + ((i * 47) % 360) + ',62%,' + (i % 2 ? 66 : 58) + '%)');   // 큰 인원(배틀로얄 50인 등)
  L.COLORS = COLORS;
  L.STANDALONE = !!window.LOUNGE_STANDALONE;
  L.debug = { speed: 1, log: false };
  L.register = function (def) {
    if (!L.games[def.id]) L.order.push(def.id);
    // 턴제 게임은 차례 순서를 기본 무작위로(설정에서 「자리 순서」로 바꿀 수 있음). 자리가 곧 역할인 게임은 fixedOrder: true
    if (!def.realtime && (def.maxPlayers || 1) > 1 && !def.fixedOrder && !['moles', 'wolfsheep', 'copsrobbers'].includes(def.id) && !(def.options || []).some((o) => o.id === '_order'))
      def.options = (def.options || []).concat([{ id: '_order', label: '차례 순서', choices: [{ v: 'rand', label: '무작위' }, { v: 'seat', label: '자리 순서' }], def: 'rand' }]);
    L.games[def.id] = def;
  };

  /* ---------- small utils ---------- */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') { for (const sk in v) { if (sk.startsWith('--')) el.style.setProperty(sk, v[sk]); else el.style[sk] = v[sk]; } }
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  }
  L.h = h;
  const clone = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));
  const store = {
    get(k, d) { try { const v = localStorage.getItem('lounge.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('lounge.' + k, JSON.stringify(v)); } catch (e) {} },
  };
  /* 글자 크기(라운드 27): 0.8~1.5. 게임 밖 화면·시트·위쪽 막대를 CSS zoom(--ui)으로 키운다. 캔버스 HUD는 L.ui.scale()을 곱해 쓸 수 있다. */
  const UI = {
    get() { const v = +store.get('ui.scale', 1); return v >= 0.8 && v <= 1.5 ? v : 1; },
    apply(v) { document.documentElement.style.setProperty('--ui', String(Math.round(v * Layout.scale() * 1000) / 1000)); try { window.dispatchEvent(new Event('lounge-ui')); } catch (e) {} },
  };
  /* 화면 배치(라운드 48): 'auto'(기본)·'land'(가로)·'port'(세로). 가로 배치 = <html class="wide">.
     auto: 창 너비 1100px 이상이고 가로/세로 비율 1.2 초과일 때. 메뉴(홈·설정·방·규칙)만 넓게 쓰고, 세로형 게임은 가운데 그대로 + 좌우 정보판.
     UI 배율(lay.scale): 가로 배치에서만 메뉴 글자·버튼에 곱한다(0 = 자동: 창 높이에 맞춰 1~1.25). 폰(세로)에서는 아무것도 바뀌지 않음. */
  const Layout = {
    wide: false,
    pref() { const v = store.get('lay.mode', 'auto'); return ['auto', 'land', 'port'].includes(v) ? v : 'auto'; },
    scalePref() { const v = +store.get('lay.scale', 0); return v >= 0.8 && v <= 1.6 ? v : 0; },
    scale() { if (!Layout.wide) return 1; const v = Layout.scalePref(); return v || Math.max(1, Math.min(2, Math.round(innerHeight / 900 * 20) / 20)); },   // 라운드 50: 1440p·4K(배율 100%)에서 글자가 너무 작지 않게 최대 2배
    calc() { const m = Layout.pref(), w = innerWidth, hh = innerHeight || 1; return m === 'land' ? w >= 700 : m === 'port' ? false : w >= 1100 && w / hh > 1.2; },
    onChange: null,
    check(force) {
      const on = Layout.calc(), was = Layout.wide;
      Layout.wide = on; document.documentElement.classList.toggle('wide', on);
      UI.apply(UI.get());
      if ((on !== was || force) && Layout.onChange) Layout.onChange();
    },
  };
  Layout.wide = Layout.calc(); document.documentElement.classList.toggle('wide', Layout.wide);
  { let rz = 0; addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(() => Layout.check(), 120); }); }
  L.layout = { wide: () => Layout.wide };
  /* 화면 테마(라운드 29): 'dark'(기본)·'light'·'hc'(고대비)·'system'(기기 설정 따르기). <html data-theme>에 실제 테마를 단다. */
  const THEME_BG = { dark: '#17131f', light: '#f4efe6', hc: '#000000' };
  const Theme = {
    mq: (() => { try { return window.matchMedia('(prefers-color-scheme: light)'); } catch (e) { return null; } })(),
    pref() { const v = store.get('theme', 'dark'); return ['dark', 'light', 'hc', 'system'].includes(v) ? v : 'dark'; },
    resolve(p) { p = p || Theme.pref(); return p === 'system' ? (Theme.mq && Theme.mq.matches ? 'light' : 'dark') : p; },
    cur: null,
    apply() {
      const t = Theme.resolve(), de = document.documentElement;
      if (t === Theme.cur && de.dataset.theme === t) return;
      Theme.cur = t; de.dataset.theme = t;
      const mt = document.querySelector('meta[name="theme-color"]'); if (mt) mt.setAttribute('content', THEME_BG[t]);
      try { window.dispatchEvent(new CustomEvent('lounge-theme', { detail: { theme: t } })); } catch (e) {}
    },
  };
  try { Theme.mq && (Theme.mq.addEventListener ? Theme.mq.addEventListener('change', () => Theme.apply()) : Theme.mq.addListener(() => Theme.apply())); } catch (e) {}
  /* 글자 대비 강화(라운드 35): html.contrast → core 글자(토스트·배너·결과·HUD)에 외곽선/그림자. 게임 캔버스는 L.ui.contrast() + L.ui.strokeText. 바꾸면 'lounge-contrast'. */
  const Contrast = {
    on: () => !!store.get('contrast', false),
    apply() { document.documentElement.classList.toggle('contrast', this.on()); },
    set(v) { store.set('contrast', !!v); this.apply(); try { window.dispatchEvent(new CustomEvent('lounge-contrast', { detail: { on: !!v } })); } catch (e) {} },
  };
  Contrast.apply();
  L.ui = { scale: () => UI.get(), theme: () => Theme.cur || Theme.resolve(), themePref: () => Theme.pref(), contrast: () => Contrast.on(), setContrast: (v) => Contrast.set(v) };
  /* 캔버스 글자: 대비 강화가 켜져 있으면 어두운(또는 opt.stroke) 외곽선을 먼저 그린 뒤 채운다. 꺼져 있으면 fillText와 같다. */
  L.ui.strokeText = (ctx, text, x, y, opt) => {
    opt = opt || {};
    if (Contrast.on() || opt.force) {
      ctx.save(); ctx.lineJoin = 'round'; ctx.miterLimit = 2;
      const px = parseFloat((/(\d+(?:\.\d+)?)px/.exec(ctx.font) || [0, 14])[1]);
      ctx.lineWidth = opt.width || Math.max(2, px * 0.22); ctx.strokeStyle = opt.stroke || 'rgba(0,0,0,0.85)';
      ctx.strokeText(text, x, y); ctx.restore();
    }
    ctx.fillText(text, x, y);
  };
  Theme.apply();
  UI.apply(UI.get());
  /* 최고 기록: 게임이 api.best(key, value, {label, lower, unit, fmt}) 로 남기면 설정 화면 「🏆 내 최고 기록」에 보인다 */
  const Best = {
    all(id) { return store.get('best.' + id, {}); },
    set(id, key, v, m) {
      if (typeof v !== 'number' || !isFinite(v)) return false;
      m = m || {}; const all = Best.all(id), o = all[key];
      const better = !o || (m.lower ? v < o.v : v > o.v);
      if (better) { all[key] = { v, l: m.label || key, lo: !!m.lower, u: m.unit || '', f: m.fmt || '', t: Date.now() }; store.set('best.' + id, all); }
      return better;
    },
    text(r) { const v = r.f === 'time' ? (r.v >= 60 ? Math.floor(r.v / 60) + '분 ' + (r.v % 60).toFixed(1) + '초' : r.v.toFixed(1) + '초') : (Math.round(r.v * 10) / 10).toLocaleString('ko-KR') + (r.u || ''); return v; },
  };
  L.best = Best;
  L.util = {
    clone, store,
    rand: (n) => Math.floor(Math.random() * n),
    shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; },
    clamp: (v, a, b) => Math.max(a, Math.min(b, v)),
    lerp: (a, b, t) => a + (b - a) * t,
    /* Canvas that fills `root`, DPR-aware. ctx is pre-scaled to CSS pixels. */
    canvas(root) {
      const cv = h('canvas', { class: 'gcanvas' });
      root.appendChild(cv);
      const ctx = cv.getContext('2d');
      const o = { cv, ctx, w: 1, h: 1, dpr: 1, onresize: null };
      function fit() {
        const r = root.getBoundingClientRect();
        /* 라운드 50: 1440p·4K에서도 선명하게 — DPR 3까지, 단 캔버스 픽셀이 1,000만을 넘으면 그만큼 낮춤(4K 전체 화면 ≈ 830만) */
        const w = Math.max(1, Math.round(r.width)), hh = Math.max(1, Math.round(r.height));
        let dpr = Math.min(window.devicePixelRatio || 1, 3);
        if (w * hh * dpr * dpr > 1e7) dpr = Math.max(1, Math.sqrt(1e7 / (w * hh)));
        dpr = Math.round(dpr * 100) / 100;
        if (w === o.w && hh === o.h && dpr === o.dpr) return;
        o.w = w; o.h = hh; o.dpr = dpr;
        cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        if (o.onresize) o.onresize();
      }
      const ro = new ResizeObserver(fit); ro.observe(root); fit();
      addEventListener('resize', fit);   // 배율(DPR)만 바뀔 때(모니터 이동·Ctrl+휠)
      o.fit = fit;
      o.local = (ev) => { const r = cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
      o.clear = () => { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); ctx.setTransform(o.dpr, 0, 0, o.dpr, 0, 0); };
      o.destroy = () => { ro.disconnect(); removeEventListener('resize', fit); cv.remove(); };
      return o;
    },
    /* requestAnimationFrame loop; fn(dtSeconds, nowMs). Returns stop(). */
    loop(fn) {
      let on = true, last = performance.now();
      function f(t) { if (!on) return; const dt = Math.max(0, Math.min(0.05, (t - last) / 1000)); last = t; fn(dt, t); if (on) requestAnimationFrame(f); }
      requestAnimationFrame(f);
      return () => { on = false; };
    },
  };

  /* ---------- sound (tiny synth) ----------
     라운드 50: 소리 크기를 파형별로 맞춤(사각·톱니파는 작게), 모든 효과음은 압축기를 거쳐 겹쳐도 찢어지지 않음.
     같은 소리가 연달아 나면 높이·크기를 살짝 흔들어 덜 질리게 한다. UI 소리: button · result · warn · count · go · turn.
     L.sfx(name, {vol, pitch}) — vol 배율(기본 1), pitch 배율(기본 1, 0이면 흔들기 없음 아님: 흔들기는 늘 아주 조금). */
  const SFX = {   // [주파수, 길이(초), 파형, 크기(맞춘 값), 끝 주파수] 또는 여러 음 [[...], 시작 지연]
    tick: [880, 0.03, 'square', 0.05], card: [320, 0.06, 'triangle', 0.16, 180], chip: [1400, 0.05, 'square', 0.05, 2200],
    hit: [180, 0.08, 'sine', 0.26, 90], bounce: [520, 0.04, 'sine', 0.16], roll: [240, 0.05, 'square', 0.05, 400],
    win: [[523, 0.1, 'triangle', 0.17], [659, 0.1, 'triangle', 0.17, 0, 0.09], [784, 0.12, 'triangle', 0.18, 1046, 0.18]],
    lose: [[392, 0.16, 'triangle', 0.15, 330], [294, 0.26, 'triangle', 0.15, 220, 0.15]],
    click: [660, 0.02, 'square', 0.045], button: [520, 0.035, 'triangle', 0.1, 640],
    thud: [90, 0.12, 'sine', 0.3, 50], pop: [700, 0.05, 'sine', 0.17, 1200], whoosh: [200, 0.15, 'sawtooth', 0.045, 900],
    result: [[440, 0.08, 'triangle', 0.14], [660, 0.14, 'triangle', 0.15, 0, 0.08]],
    warn: [[440, 0.09, 'square', 0.045], [330, 0.12, 'square', 0.045, 0, 0.11]],
    count: [600, 0.07, 'sine', 0.2], go: [900, 0.16, 'sine', 0.22, 1200], turn: [[620, 0.05, 'sine', 0.13], [830, 0.07, 'sine', 0.13, 0, 0.06]],
  };
  const Sfx = {
    ac: null, on: store.get('sound', true), bus: null, last: {}, lastAny: 0,
    out() {
      if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)();
      if (!this.bus) {
        const c = this.ac.createDynamicsCompressor();
        c.threshold.value = -14; c.knee.value = 10; c.ratio.value = 6; c.attack.value = 0.003; c.release.value = 0.15;
        c.connect(this.ac.destination); this.bus = c;
      }
      return this.bus;
    },
    play(name, o) {
      if (!o || typeof o !== 'object') o = null;   // 옛 호출 sfx(name, 숫자)는 무시
      if (!this.on || L.audio.sfx() <= 0) return;
      try {
        const out = this.out(), ac = this.ac, t = ac.currentTime, now = Date.now();
        let P = SFX[name] || [440, 0.05, 'sine', 0.12];
        if (!Array.isArray(P[0])) P = [P];
        // 반복 피로 줄이기: 0.5초 안에 같은 소리면 ±5% 높이 · ±15% 크기, 아니면 ±1.5%
        const rep = now - (this.last[name] || 0) < 500; this.last[name] = now; this.lastAny = now;
        const jp = 1 + (Math.random() * 2 - 1) * (rep ? 0.05 : 0.015), jv = 1 - Math.random() * (rep ? 0.15 : 0.04);
        const pm = (o && o.pitch) || 1, vm = (o && o.vol != null ? o.vol : 1) * jv * L.audio.sfx();
        for (const [f, d, type, vol, f2, dl] of P) {
          const t0 = t + (dl || 0);
          const osc = ac.createOscillator(), g = ac.createGain();
          osc.type = type; osc.frequency.setValueAtTime(f * jp * pm, t0);
          if (f2) osc.frequency.exponentialRampToValueAtTime(f2 * jp * pm, t0 + d);
          g.gain.setValueAtTime(0.0001, t0); g.gain.linearRampToValueAtTime(Math.max(0.0002, vol * vm), t0 + 0.004);
          g.gain.exponentialRampToValueAtTime(0.0001, t0 + d + 0.02);
          osc.connect(g).connect(out); osc.start(t0); osc.stop(t0 + d + 0.03);
        }
      } catch (e) {}
    },
  };
  /* UI 버튼 소리: core 화면(메뉴·시트·위쪽 막대)의 버튼을 누르면 작게. 방금 다른 소리가 났으면 생략 */
  document.addEventListener('click', (e) => {
    const b = e.target && e.target.closest && e.target.closest('button,.btn');
    if (!b || b.disabled || Date.now() - Sfx.lastAny < 60) return;
    if (!b.closest('.overlay[data-core],.screen:not(.gscreen),.gscreen>.topbar,.gside,.gcorner')) return;
    Sfx.play('button', { vol: 0.8 });
  });
  L.sfx = (n, o) => Sfx.play(n, o);
  /* 소리 크기(라운드 24): 효과음·음악 따로. 게임의 자체 소리는 L.audio.sfx()/music()(0~1)를 곱해 쓴다. 소리 끔이면 둘 다 0 */
  /* 효과 세기(라운드 25): 게임은 화면 흔들림·번쩍임 크기에 L.fx()(0~1)를 곱한다. 0이면 끔 */
  L.fx = () => store.get('fx', 1);
  /* 전환 효과(라운드 50): 게임 시작·차례·라운드 알림. 설정 「전환 효과」 끔이나 기기의 「동작 줄이기」면 꺼짐(문구는 그대로 보임) */
  const Anim = {
    on() { if (store.get('anim', true) === false) return false; try { if (matchMedia('(prefers-reduced-motion: reduce)').matches) return false; } catch (e) {} return true; },
    sync() { document.documentElement.classList.toggle('no-anim', !Anim.on()); },
  };
  Anim.sync();
  try { matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', () => Anim.sync()); } catch (e) {}
  /* 숫자·단위 서식(라운드 50) — 모든 화면에서 같은 모양으로 */
  const fmtNum = (n, d) => {
    if (n == null || n === '' || isNaN(+n)) return n == null ? '-' : String(n);
    const v = +n, dd = d == null ? (Number.isInteger(v) ? 0 : 1) : d;
    return v.toLocaleString('ko-KR', { minimumFractionDigits: 0, maximumFractionDigits: dd });
  };
  L.fmt = {
    num: fmtNum,                                                   // 12345.6 → "12,345.6"
    int: (n) => fmtNum(Math.round(+n || 0), 0),                     // 반올림 정수
    signed: (n, d) => (+n > 0 ? '+' : +n < 0 ? '−' : '±') + fmtNum(Math.abs(+n || 0), d),   // +1,200 / −300
    unit: (n, u, d) => fmtNum(n, d) + (u ? (/^[A-Za-z%]/.test(u) && u !== '%' ? ' ' : '') + u : ''),   // 1,200점 · 35m · 12 km/h · 50%
    pct: (x, d) => fmtNum((+x || 0) * 100, d == null ? 0 : d) + '%',   // 0.256 → "26%"
    big(n) {                                                        // 12,345 → "1.2만", 340,000,000 → "3.4억"
      const v = +n || 0, a = Math.abs(v);
      if (a >= 1e8) return fmtNum(v / 1e8, a >= 1e9 ? 0 : 1) + '억';
      if (a >= 1e4) return fmtNum(v / 1e4, a >= 1e5 ? 0 : 1) + '만';
      return fmtNum(v, 0);
    },
    time(sec, ms) {                                                 // 75.3 → "1:15" (ms=true → "1:15.3"), 3700 → "1:01:40"
      const neg = sec < 0; sec = Math.abs(+sec || 0);
      const hh = Math.floor(sec / 3600), mm = Math.floor(sec / 60) % 60, ss = sec % 60;
      const sStr = ms ? ss.toFixed(1).padStart(4, '0') : String(Math.floor(ss)).padStart(2, '0');
      return (neg ? '−' : '') + (hh ? hh + ':' + String(mm).padStart(2, '0') : String(mm)) + ':' + sStr;
    },
    dur(sec) {                                                      // 65 → "1분 5초"
      sec = Math.round(Math.abs(+sec || 0)); const hh = Math.floor(sec / 3600), mm = Math.floor(sec / 60) % 60, ss = sec % 60;
      return [hh ? hh + '시간' : '', mm ? mm + '분' : '', ss || (!hh && !mm) ? ss + '초' : ''].filter(Boolean).join(' ');
    },
    ord: (n) => fmtNum(n, 0) + '등',
    cell: (v) => (typeof v === 'number' ? fmtNum(v) : v == null ? '-' : String(v)),   // 표 칸: 숫자면 쉼표
  };
  L.audio = { sfx: () => (Sfx.on ? store.get('vol.sfx', 1) : 0), music: () => (Sfx.on ? store.get('vol.music', 0.8) : 0) };
  /* 빠른 진행(라운드 32): 턴제 게임의 AI 대기·애니메이션 배율. 실시간 게임 판에서는 늘 1 */
  L.speed = () => { const s = L.session && L.session(); if (s && (s.def.realtime || (s.def.realtimeIf && s.def.realtimeIf(s.opts)))) return 1; return +store.get('speed', 1) || 1; };

  /* 배경 음악(라운드 32): 게임별 분위기 합성 음악. def.mood가 있으면 우선, 없으면 MOOD_BY_ID → 분류(MOOD_BY_CAT).
     def.mood = false 이면 끔(자체 음악이 있는 게임). 크기는 L.audio.music() × 아주 작은 기본 음량. */
  const MOOD_BY_ID = { horserace: 'fanfare', voyage: 'sea', subdive: 'sea', caravan: 'sea', isletrade: 'sea', rts: 'drums', hexwar: 'drums', realmwar: 'drums', lanewar: 'drums', mercs: 'drums', royale: 'drums', warships: 'drums', rhythm: false };
  const MOOD_BY_CAT = { 카드: 'jazz', 보드: 'folk', 전략: 'drums', 퍼즐: 'calm', 협동: 'tension', 스포츠: 'arcade', 아케이드: 'arcade', 파티: 'party' };
  const MOODS = {
    jazz: { bpm: 92, swing: 0.62, prog: [[50, [0, 3, 7, 10]], [55, [0, 4, 7, 10]], [48, [0, 4, 7, 11]], [45, [0, 3, 7, 10]]], lead: 'sine', bass: 'walk', pad: 'stab', drum: 'brush', lv: 0.8 },
    calm: { bpm: 66, prog: [[48, [0, 4, 7, 11]], [45, [0, 3, 7, 10]], [41, [0, 4, 7, 11]], [43, [0, 2, 7]]], lead: 'sine', bass: 'long', pad: 'pad', drum: null, arp: 1, lv: 0.75 },
    sea: { bpm: 104, six: true, prog: [[50, [0, 3, 7]], [48, [0, 4, 7]], [46, [0, 4, 7]], [45, [0, 4, 7]]], lead: 'triangle', bass: 'oom', pad: 'pad', drum: 'wave', lv: 0.85 },
    drums: { bpm: 112, prog: [[45, [0, 3, 7]], [45, [0, 3, 7]], [41, [0, 4, 7]], [43, [0, 4, 7]]], lead: null, bass: 'pulse', pad: 'pad', drum: 'war', lv: 0.9 },
    fanfare: { bpm: 120, prog: [[48, [0, 4, 7]], [53, [0, 4, 7]], [55, [0, 4, 7]], [48, [0, 4, 7]]], lead: 'brass', bass: 'oom', pad: null, drum: 'march', lv: 0.75 },
    tension: { bpm: 88, prog: [[45, [0, 3, 7]], [46, [0, 4, 7]], [45, [0, 3, 7]], [44, [0, 4, 8]]], lead: null, bass: 'pulse', pad: 'pad', drum: 'tick', arp: 1, lv: 0.8 },
    folk: { bpm: 96, prog: [[48, [0, 4, 7]], [43, [0, 4, 7]], [45, [0, 3, 7]], [41, [0, 4, 7]]], lead: 'pluck', bass: 'oom', pad: null, drum: null, arp: 1, lv: 0.8 },
    arcade: { bpm: 126, prog: [[45, [0, 3, 7]], [41, [0, 4, 7]], [48, [0, 4, 7]], [43, [0, 4, 7]]], lead: 'square', bass: 'oct', pad: null, drum: 'beat', lv: 0.6 },
    party: { bpm: 116, prog: [[48, [0, 4, 7]], [45, [0, 3, 7]], [41, [0, 4, 7]], [43, [0, 4, 7, 10]]], lead: 'pluck', bass: 'oct', pad: null, drum: 'beat', lv: 0.7 },
  };
  const Music = {
    ac: null, out: null, timer: 0, mood: null, step: 0, next: 0, paused: false, seed: 1, nb: null,
    moodFor(id) {
      const g = L.games[id]; if (!g) return null;
      if (g.mood !== undefined) return g.mood || null;
      if (MOOD_BY_ID[id] !== undefined) return MOOD_BY_ID[id] || null;
      return MOOD_BY_CAT[catOf(id)] || 'folk';
    },
    gain() { return L.audio.music() * 0.09 * ((this.mood && MOODS[this.mood].lv) || 1); },
    vol() {
      if (this.out) this.out.gain.setTargetAtTime(this.paused || document.hidden ? 0 : this.gain(), this.ac.currentTime, 0.3);
      if (this.mood && !this.timer && L.audio.music() > 0) this.start(null, this.mood);
    },
    start(id, mood) {
      this.stop();
      mood = mood || this.moodFor(id);
      if (!mood || !MOODS[mood]) return;
      this.mood = mood;
      if (L.audio.music() <= 0) return;   // 크기를 올리면 vol()에서 다시 켬
      try {
        if (!Sfx.ac) Sfx.ac = new (window.AudioContext || window.webkitAudioContext)();
        this.ac = Sfx.ac; if (this.ac.state === 'suspended') this.ac.resume();
        this.out = this.ac.createGain(); this.out.gain.value = 0;
        const lp = this.ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2600;
        this.out.connect(lp).connect(this.ac.destination);
        this.out.gain.setTargetAtTime(this.paused ? 0 : this.gain(), this.ac.currentTime, 1.2);   // 천천히 들어옴
        this.step = 0; this.next = this.ac.currentTime + 0.3; this.seed = (Math.random() * 1e9) | 0;
        this.timer = setInterval(() => this.pump(), 120);
      } catch (e) { this.stop(); }
    },
    stop() {
      clearInterval(this.timer); this.timer = 0;
      if (this.out) { const o = this.out; try { o.gain.setTargetAtTime(0, this.ac.currentTime, 0.25); setTimeout(() => { try { o.disconnect(); } catch (e) {} }, 1500); } catch (e) {} }
      this.out = null; this.mood = null; this.paused = false;
    },
    setPaused(p) { this.paused = p; this.vol(); },
    rnd() { this.seed = (this.seed * 1103515245 + 12345) & 0x7fffffff; return this.seed / 0x7fffffff; },
    note(t, midi, dur, type, v) {
      const ac = this.ac, o = ac.createOscillator(), g = ac.createGain(), f = 440 * Math.pow(2, (midi - 69) / 12);
      let wave = type, atk = 0.01, rel = dur;
      if (type === 'brass') { wave = 'sawtooth'; atk = 0.04; v *= 0.35; }
      else if (type === 'pluck') { wave = 'triangle'; rel = Math.min(dur, 0.35); }
      else if (type === 'square') { v *= 0.3; }
      else if (type === 'padw') { wave = 'triangle'; atk = dur * 0.35; v *= 0.5; }
      o.type = wave; o.frequency.setValueAtTime(f, t);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + atk); g.gain.exponentialRampToValueAtTime(0.0001, t + Math.max(atk + 0.02, rel));
      o.connect(g).connect(this.out); o.start(t); o.stop(t + Math.max(atk + 0.02, rel) + 0.05);
    },
    hit(t, kind, v) {
      const ac = this.ac, g = ac.createGain();
      if (kind === 'kick' || kind === 'tom') {
        const o = ac.createOscillator(); o.type = 'sine';
        o.frequency.setValueAtTime(kind === 'kick' ? 110 : 150, t); o.frequency.exponentialRampToValueAtTime(kind === 'kick' ? 45 : 80, t + 0.18);
        g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
        o.connect(g).connect(this.out); o.start(t); o.stop(t + 0.32); return;
      }
      const len = kind === 'wave' ? 2.4 : kind === 'snare' ? 0.16 : 0.05;
      if (!this.nb) { const b = ac.createBuffer(1, ac.sampleRate * 2.5, ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; this.nb = b; }
      const s = ac.createBufferSource(); s.buffer = this.nb;
      const f = ac.createBiquadFilter();
      f.type = kind === 'wave' ? 'lowpass' : 'highpass'; f.frequency.value = kind === 'wave' ? 500 : kind === 'snare' ? 1800 : 6000;
      const atk = kind === 'wave' ? 1.0 : 0.003;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + atk); g.gain.exponentialRampToValueAtTime(0.0001, t + len);
      s.connect(f).connect(g).connect(this.out); s.start(t); s.stop(t + len + 0.05);
    },
    pump() {
      if (!this.ac || !this.out) return;
      if (this.paused || document.hidden) { this.next = Math.max(this.next, this.ac.currentTime + 0.1); return; }
      const M = MOODS[this.mood], per = M.six ? 6 : 8, sd = 60 / M.bpm / 2;
      if (this.next < this.ac.currentTime) this.next = this.ac.currentTime + 0.05;
      while (this.next < this.ac.currentTime + 0.4) { this.play(M, this.step, per, this.next, sd); this.next += sd; this.step++; }
    },
    play(M, n, per, t, sd) {
      const barN = Math.floor(n / per), i = n % per, phrase = Math.floor(barN / 4) % 6;
      const rest = phrase === 5;   // 6구절마다 한 구절은 멜로디 쉼 → 반복이 덜 거슬리게
      const [root, iv] = M.prog[barN % M.prog.length];
      if (M.swing && i % 2) t += sd * (M.swing - 0.5) * 2;
      const b = M.bass;
      if (b === 'walk' && !(i % 2)) this.note(t, root - 12 + [0, iv[1], iv[2], iv[2] + 2][i / 2], sd * 1.8, 'triangle', 0.5);
      else if (b === 'long' && i === 0) this.note(t, root - 12, sd * per, 'sine', 0.45);
      else if (b === 'oom' && (M.six ? i % 3 === 0 : i % 4 === 0)) this.note(t, root - 12 + (i ? 7 : 0), sd * 2, 'triangle', 0.5);
      else if (b === 'pulse' && (i % 2 === 0 || (i === 7 && this.rnd() < 0.4))) this.note(t, root - 12, sd * 0.9, 'triangle', 0.4);
      else if (b === 'oct' && i % 2 === 0) this.note(t, root - 12 + (i % 4 ? 12 : 0), sd * 0.8, 'triangle', 0.4);
      if (M.pad === 'pad' && i === 0) iv.forEach((x) => this.note(t, root + 12 + x, sd * per * 1.05, 'padw', 0.16));
      if (M.pad === 'stab' && (i === 2 || (i === 5 && this.rnd() < 0.5))) iv.forEach((x) => this.note(t, root + 12 + x, sd * 0.6, 'sine', 0.1));
      if (M.arp && i % 2 === 1 && this.rnd() < 0.75) this.note(t, root + 24 + iv[Math.floor(this.rnd() * iv.length)], sd * 1.5, 'sine', 0.12);
      if (M.lead && !rest) {
        const dens = M.lead === 'brass' ? (i % 2 ? 0 : 0.7) : M.lead === 'square' ? 0.45 : 0.4;
        if (this.rnd() < dens) {
          const pool = iv.concat([iv[0] + 12]); if (this.rnd() < 0.25) pool.push(2, 9);
          const len = this.rnd() < 0.3 ? 2 : 1;
          this.note(t, root + 24 + pool[Math.floor(this.rnd() * pool.length)], sd * len * 0.95, M.lead, 0.22);
        }
      }
      const d = M.drum;
      if (d === 'brush') { if (i % 2 === 0) this.hit(t, 'hat', 0.12); if (i === 2 || i === 6) this.hit(t, 'snare', 0.07); }
      else if (d === 'wave') { if (i === 0 && barN % 2 === 0) this.hit(t, 'wave', 0.18); }
      else if (d === 'war') { if (i === 0 || i === 3 || i === 6) this.hit(t, 'tom', 0.5); if (i === 4) this.hit(t, 'kick', 0.55); if (barN % 4 === 3 && i >= 4) this.hit(t, 'tom', 0.35); if (i % 2) this.hit(t, 'hat', 0.05); }
      else if (d === 'march') { if (i % 4 === 0) this.hit(t, 'kick', 0.4); if (i % 4 === 2) this.hit(t, 'snare', 0.12); }
      else if (d === 'tick') { if (i % 2 === 0) this.hit(t, 'hat', 0.08); if (i === 0 && barN % 2 === 0) this.hit(t, 'kick', 0.35); }
      else if (d === 'beat') { if (i % 4 === 0) this.hit(t, 'kick', 0.4); if (i % 4 === 2) this.hit(t, 'snare', 0.1); if (i % 2) this.hit(t, 'hat', 0.06); }
    },
  };
  L.music = { mood: (id) => Music.moodFor(id), moods: Object.keys(MOODS), play: (m) => Music.start(null, m), stop: () => Music.stop(), playing: () => (Music.timer ? Music.mood : null) };
  window.addEventListener('lounge-volume', () => Music.vol());
  document.addEventListener('visibilitychange', () => Music.vol());
  /* 환경음(라운드 33): 음악과 따로 「환경음 크기」(vol.amb, 기본 0.5). def.ambient가 있으면 우선(false=끔), 없으면 AMB_BY_ID → 분류(AMB_BY_CAT).
     판 시작에 천천히 들어오고, 결과·나가기·일시정지·백그라운드에서 멈춘다. 기본 음량은 아주 작게(× 0.05). */
  const AMB_BY_ID = {
    baseball: 'stadium', basketball: 'stadium', badminton: 'stadium', dodgeball: 'stadium', futsal: 'stadium', sumo: 'stadium', gladiator: 'stadium', fencing: 'stadium', horserace: 'stadium', archery: 'stadium', pingpong: 'stadium', bowling: 'lounge', airhockey: 'lounge',
    voyage: 'harbor', warships: 'harbor', skipstone: 'harbor', penguin: 'harbor', isletrade: 'harbor', caravan: 'harbor',
        sled: 'wind', snowball: 'wind', golf: 'wind', parkour: 'wind', vine: 'forest',
    holdem: 'lounge', blackjack: 'lounge', gostop: 'lounge', mahjong: 'lounge', bridge: 'lounge', auction: 'lounge', bingo: 'lounge', pool: 'lounge', darts: 'lounge', yacht: 'lounge', wheel: 'lounge', crew: 'lounge',
    treasure: 'forest', knight: 'forest', dicequest: 'forest', yut: 'forest', zombie: 'night', flashlight: 'night', baduk: 'night', gomoku: 'night',
    gemcave: 'cave', lavacave: 'cave', fossil: 'cave', dkeeper: 'cave',
  };
  const AMB_BY_CAT = {};
  const AMBS = ['stadium', 'harbor', 'train', 'wind', 'lounge', 'forest', 'night', 'cave', 'casino', 'tea'];
  /* 장소 고르기(라운드 35): 카드 분류 게임(def.ambient 없는)의 환경음을 설정 「카드 게임 장소」로 — 라운지/카지노/찻집/조용함(기기 저장 'amb.place'). */
  const AMB_PLACES = [{ v: 'lounge', label: '라운지' }, { v: 'casino', label: '카지노' }, { v: 'tea', label: '찻집' }, { v: 'quiet', label: '조용함' }];
  const ambPlace = () => { const v = store.get('amb.place', 'lounge'); return AMB_PLACES.some((x) => x.v === v) ? v : 'lounge'; };
  const Amb = {
    ac: null, out: null, kind: null, timer: 0, paused: false, nodes: [], nb: null, tn: 0,
    kindFor(id) {
      const g = L.games[id]; if (!g) return null;
      if (g.ambient !== undefined) return AMBS.includes(g.ambient) ? g.ambient : null;
      if (catOf(id) === '카드') { const pl = ambPlace(); return pl === 'quiet' ? null : pl; }
      if (AMB_BY_ID[id]) return AMB_BY_ID[id];
      return AMB_BY_CAT[catOf(id)] || null;
    },
    level: () => (Sfx.on ? +store.get('vol.amb', 0.5) : 0),
    gain() { return this.level() * 0.05; },
    vol() {
      if (this.out) this.out.gain.setTargetAtTime(this.paused || document.hidden ? 0 : this.gain(), this.ac.currentTime, 0.4);
      if (this.kind && !this.out && this.level() > 0) this.start(null, this.kind);
    },
    noise() {
      if (!this.nb) { const ac = this.ac, b = ac.createBuffer(1, ac.sampleRate * 3, ac.sampleRate), d = b.getChannelData(0); let p = 0; for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; p = p * 0.97 + w * 0.03; d[i] = w * 0.5 + p * 4; } this.nb = b; }
      return this.nb;
    },
    bed(type, freq, q, v, lfoHz, lfoDepth) {   // 계속 흐르는 거른 잡음 + 느린 출렁임
      const ac = this.ac, s = ac.createBufferSource(); s.buffer = this.noise(); s.loop = true;
      const f = ac.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
      const g = ac.createGain(); g.gain.value = v;
      s.connect(f).connect(g).connect(this.out); s.start(0, Math.random() * 2);
      this.nodes.push(s);
      if (lfoHz) { const o = ac.createOscillator(), og = ac.createGain(); o.frequency.value = lfoHz; og.gain.value = v * lfoDepth; o.connect(og).connect(g.gain); o.start(); this.nodes.push(o); }
      return f;
    },
    tone(t, f0, f1, dur, v, type) {
      const ac = this.ac, o = ac.createOscillator(), g = ac.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + Math.min(0.03, dur / 3)); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(this.out); o.start(t); o.stop(t + dur + 0.05);
    },
    burst(t, type, freq, dur, v) {
      const ac = this.ac, s = ac.createBufferSource(); s.buffer = this.noise();
      const f = ac.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = 2;
      const g = ac.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      s.connect(f).connect(g).connect(this.out); s.start(t, Math.random() * 2); s.stop(t + dur + 0.05);
    },
    setup(k) {
      if (k === 'stadium') { this.bed('bandpass', 600, 0.7, 0.9, 0.07, 0.4); this.bed('bandpass', 1400, 1, 0.35, 0.11, 0.5); }
      else if (k === 'harbor') { this.bed('lowpass', 420, 0.5, 1.2, 0.09, 0.8); this.bed('highpass', 2500, 0.5, 0.12, 0.09, 0.8); }
      else if (k === 'train') { this.bed('lowpass', 180, 0.7, 1.1, 0, 0); }
      else if (k === 'wind') { const f = this.bed('bandpass', 500, 3, 0.9, 0.05, 0.7); const o = this.ac.createOscillator(), og = this.ac.createGain(); o.frequency.value = 0.08; og.gain.value = 250; o.connect(og).connect(f.frequency); o.start(); this.nodes.push(o); }
      else if (k === 'lounge') { this.bed('bandpass', 450, 0.9, 0.7, 0.13, 0.3); this.bed('bandpass', 900, 1.4, 0.25, 0.19, 0.5); }
      else if (k === 'forest') { this.bed('highpass', 1800, 0.5, 0.08, 0.06, 0.8); }
      else if (k === 'night') { this.bed('lowpass', 300, 0.5, 0.25, 0, 0); }
      else if (k === 'cave') { this.bed('lowpass', 140, 0.8, 0.8, 0.04, 0.4); }
      else if (k === 'casino') { this.bed('bandpass', 520, 0.8, 0.8, 0.1, 0.35); this.bed('bandpass', 1300, 1.2, 0.3, 0.17, 0.5); this.bed('lowpass', 120, 0.7, 0.35, 0, 0); }   // 웅성임 + 낮은 실내 울림
      else if (k === 'tea') { this.bed('bandpass', 380, 0.7, 0.35, 0.06, 0.3); this.bed('highpass', 3000, 0.4, 0.05, 0.05, 0.6); }   // 조용한 말소리 + 아주 옅은 빗소리 같은 결
    },
    tick() {   // 띄엄띄엄 나는 소리(함성·갈매기·철컥·새·잔 부딪힘 등)
      if (!this.out || this.paused || document.hidden) return;
      const t = this.ac.currentTime + 0.05, r = Math.random, k = this.kind;
      if (k === 'stadium' && r() < 0.03) this.burst(t, 'bandpass', 900, 1.6, 0.5);
      else if (k === 'harbor' && r() < 0.04) { const f = 1500 + r() * 500; this.tone(t, f, f * 0.7, 0.35, 0.05, 'triangle'); this.tone(t + 0.4, f * 1.05, f * 0.65, 0.4, 0.04, 'triangle'); }
      else if (k === 'train') { this.tn++; if (this.tn % 4 === 0) { this.burst(t, 'bandpass', 700, 0.08, 0.6); this.burst(t + 0.16, 'bandpass', 600, 0.08, 0.5); } }
      else if (k === 'lounge' && r() < 0.04) this.tone(t, 2600 + r() * 900, 2500, 0.25, 0.025, 'sine');
      else if (k === 'forest' && r() < 0.08) { const f = 2400 + r() * 1600, n = 2 + ((r() * 3) | 0); for (let i = 0; i < n; i++) this.tone(t + i * 0.12, f, f * (1.1 + r() * 0.2), 0.08, 0.03, 'sine'); }
      else if (k === 'night' && r() < 0.35) { for (let i = 0; i < 3; i++) this.tone(t + i * 0.06, 4300, 4200, 0.035, 0.012, 'sine'); }
      else if (k === 'casino') {   // 칩 짤랑·멀리 슬롯 띠링·딜러 카드 넘김
        if (r() < 0.06) { const n = 2 + ((r() * 3) | 0); for (let i = 0; i < n; i++) this.burst(t + i * 0.05 + r() * 0.02, 'bandpass', 3200 + r() * 1200, 0.05, 0.25); }
        else if (r() < 0.025) { const f = 1046 * (1 + ((r() * 3) | 0) * 0.25); for (let i = 0; i < 3; i++) this.tone(t + i * 0.11, f * (1 + i * 0.25), f * (1 + i * 0.25), 0.18, 0.012, 'triangle'); }
        else if (r() < 0.04) this.burst(t, 'highpass', 2500, 0.06, 0.2);
      }
      else if (k === 'tea') {   // 찻잔 놓는 소리·주전자 물 따르는 소리·풍경
        if (r() < 0.03) { this.tone(t, 2200 + r() * 600, 2100, 0.3, 0.02, 'sine'); this.tone(t, 5100 + r() * 400, 5000, 0.18, 0.008, 'sine'); }
        else if (r() < 0.012) this.burst(t, 'bandpass', 1100 + r() * 300, 1.4, 0.12);
        else if (r() < 0.015) { const f = 1568 + r() * 300; this.tone(t, f, f, 1.6, 0.012, 'sine'); this.tone(t + 0.02, f * 2.76, f * 2.76, 0.9, 0.005, 'sine'); }
      }
      else if (k === 'cave' && r() < 0.05) this.tone(t, 1200 + r() * 600, 500, 0.12, 0.04, 'sine');
    },
    start(id, kind) {
      this.stop();
      kind = kind || this.kindFor(id);
      if (!kind) return;
      this.kind = kind;
      if (this.level() <= 0) return;   // 크기를 올리면 vol()에서 켬
      try {
        if (!Sfx.ac) Sfx.ac = new (window.AudioContext || window.webkitAudioContext)();
        this.ac = Sfx.ac; if (this.ac.state === 'suspended') this.ac.resume();
        this.out = this.ac.createGain(); this.out.gain.value = 0; this.out.connect(this.ac.destination);
        this.setup(kind);
        this.out.gain.setTargetAtTime(this.paused || document.hidden ? 0 : this.gain(), this.ac.currentTime, 1.5);   // 페이드인
        this.timer = setInterval(() => this.tick(), 250);
      } catch (e) { this.stop(); }
    },
    stop() {
      clearInterval(this.timer); this.timer = 0;
      const o = this.out, ns = this.nodes;
      if (o) { try { o.gain.setTargetAtTime(0, this.ac.currentTime, 0.3); } catch (e) {} setTimeout(() => { ns.forEach((n) => { try { n.stop(); } catch (e) {} }); try { o.disconnect(); } catch (e) {} }, 1600); }
      this.out = null; this.nodes = []; this.kind = null; this.paused = false;
    },
    setPaused(p) { this.paused = p; this.vol(); },
  };
  L.ambient = { place: () => ambPlace(), places: AMB_PLACES.slice(), kind: (id) => Amb.kindFor(id), kinds: AMBS.slice(), play: (k) => Amb.start(null, k), stop: () => Amb.stop(), playing: () => (Amb.out ? Amb.kind : null) };
  L.audio.amb = () => Amb.level();
  window.addEventListener('lounge-volume', () => Amb.vol());
  document.addEventListener('visibilitychange', () => Amb.vol());
  /* 조작 크기(라운드 33): 0.7~1.5. 실시간 게임의 화면 버튼·조이스틱은 L.ui.ctlScale()(또는 CSS var(--ctl-scale))을 곱한다. */
  const Ctl = {
    get() { const v = +store.get('ui.ctl', 1); return v >= 0.7 && v <= 1.5 ? v : 1; },
    apply(v) { document.documentElement.style.setProperty('--ctl-scale', String(v)); try { window.dispatchEvent(new Event('lounge-ctl')); } catch (e) {} },
  };
  L.ui.ctlScale = () => Ctl.get();
  Ctl.apply(Ctl.get());
  /* 테이블 바닥(라운드 33): 카드·패 게임 바닥. L.ui.felt() → {id, name, c:[가운데, 중간, 가장자리], rail:[위, 아래], line}. 바꾸면 'lounge-felt' 이벤트. */
  const FELTS = {
    green: { name: '초록 펠트', c: ['#24806a', '#1c6650', '#0c3528'], rail: ['#7a4a24', '#3f230f'], line: 'rgba(227,174,69,.45)' },
    navy: { name: '남색 펠트', c: ['#2c4f86', '#1f3a66', '#0e1d38'], rail: ['#5a5f6e', '#2a2d36'], line: 'rgba(214,190,130,.45)' },
    wine: { name: '자주 펠트', c: ['#8a2f45', '#6a2236', '#33101b'], rail: ['#4a3324', '#22160d'], line: 'rgba(227,174,69,.45)' },
    wood: { name: '나무', c: ['#a8743f', '#8a5a2e', '#4e2f16'], rail: ['#3b2414', '#1e1209'], line: 'rgba(255,236,200,.35)' },
    leather: { name: '가죽', c: ['#6e4a33', '#563826', '#2a1a11'], rail: ['#2a2420', '#14110f'], line: 'rgba(227,174,69,.4)' },
  };
  const feltId = () => { const v = store.get('felt', 'green'); return FELTS[v] ? v : 'green'; };
  L.ui.felt = () => { const id = feltId(); return Object.assign({ id }, FELTS[id]); };
  L.ui.felts = () => Object.keys(FELTS).map((id) => Object.assign({ id }, FELTS[id]));
  L.ui.setFelt = (id) => { if (!FELTS[id]) return; store.set('felt', id); try { window.dispatchEvent(new CustomEvent('lounge-felt', { detail: { id } })); } catch (e) {} };
  /* 카드 뒷면(라운드 34): L.ui.cardBack() → {id, name, a(바탕), b(무늬), line(테두리), pat}. 바꾸면 'lounge-cardback' 이벤트. */
  const CARDBACKS = {
    navy: { name: '남색 격자', a: '#1f3a6e', b: '#2f56a0', line: '#e9e2cc', pat: 'grid' },
    crimson: { name: '진홍 다이아', a: '#7e1d2c', b: '#b03244', line: '#f3e6c8', pat: 'diamond' },
    forest: { name: '숲 줄무늬', a: '#1d5a40', b: '#2d8060', line: '#efe7cf', pat: 'stripe' },
    gold: { name: '검정·금 원', a: '#1a1714', b: '#b8913e', line: '#d8b96a', pat: 'dots' },
    plum: { name: '자주 물결', a: '#4a2458', b: '#73408a', line: '#eadcf0', pat: 'wave' },
  };
  const cbId = () => { const v = store.get('cardback', 'navy'); return CARDBACKS[v] ? v : 'navy'; };
  L.ui.cardBack = () => { const id = cbId(); return Object.assign({ id }, CARDBACKS[id]); };
  L.ui.cardBacks = () => Object.keys(CARDBACKS).map((id) => Object.assign({ id }, CARDBACKS[id]));
  L.ui.setCardBack = (id) => { if (!CARDBACKS[id]) return; store.set('cardback', id); try { window.dispatchEvent(new CustomEvent('lounge-cardback', { detail: { id } })); } catch (e) {} };
  /* 무늬를 캔버스 사각형 안에 그리기(공용 도우미): L.ui.drawCardBack(ctx, x, y, w, h, r?, colors?) — colors로 a/b/line 덮어쓰기 가능 */
  L.ui.drawCardBack = function (ctx, x, y, w, hh, r, over) {
    const cb = Object.assign(L.ui.cardBack(), over || {}); r = r == null ? Math.min(w, hh) * 0.1 : r;
    ctx.save(); ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, hh, r); else ctx.rect(x, y, w, hh);
    ctx.fillStyle = cb.line; ctx.fill(); ctx.clip();
    const m = Math.max(1.5, Math.min(w, hh) * 0.08), ix = x + m, iy = y + m, iw = w - 2 * m, ih = hh - 2 * m;
    ctx.fillStyle = cb.a; ctx.fillRect(ix, iy, iw, ih);
    ctx.beginPath(); ctx.rect(ix, iy, iw, ih); ctx.clip();
    ctx.strokeStyle = cb.b; ctx.fillStyle = cb.b; ctx.lineWidth = Math.max(1, iw / 18);
    const st = Math.max(4, iw / 5);
    if (cb.pat === 'grid' || cb.pat === 'diamond') { ctx.beginPath(); for (let k = -ih; k < iw + ih; k += st) { ctx.moveTo(ix + k, iy); ctx.lineTo(ix + k + ih, iy + ih); ctx.moveTo(ix + k + ih, iy); ctx.lineTo(ix + k, iy + ih); } ctx.stroke(); }
    if (cb.pat === 'diamond') { ctx.beginPath(); const cx = ix + iw / 2, cy = iy + ih / 2; ctx.moveTo(cx, cy - ih * 0.3); ctx.lineTo(cx + iw * 0.3, cy); ctx.lineTo(cx, cy + ih * 0.3); ctx.lineTo(cx - iw * 0.3, cy); ctx.closePath(); ctx.fillStyle = cb.line; ctx.globalAlpha = 0.85; ctx.fill(); ctx.globalAlpha = 1; }
    if (cb.pat === 'stripe') { ctx.beginPath(); for (let k = -ih; k < iw; k += st) { ctx.moveTo(ix + k, iy + ih); ctx.lineTo(ix + k + ih, iy); } ctx.lineWidth = st * 0.35; ctx.stroke(); }
    if (cb.pat === 'dots') { for (let yy = iy + st / 2; yy < iy + ih; yy += st) for (let xx = ix + st / 2; xx < ix + iw; xx += st) { ctx.beginPath(); ctx.arc(xx, yy, st * 0.22, 0, 7); ctx.fill(); } ctx.strokeStyle = cb.line; ctx.lineWidth = Math.max(1, iw / 30); ctx.strokeRect(ix + m, iy + m, iw - 2 * m, ih - 2 * m); }
    if (cb.pat === 'wave') { ctx.beginPath(); for (let yy = iy; yy < iy + ih + st; yy += st * 0.7) { ctx.moveTo(ix, yy); for (let xx = 0; xx <= iw; xx += 2) ctx.lineTo(ix + xx, yy + Math.sin(xx / iw * Math.PI * 3) * st * 0.2); } ctx.stroke(); }
    ctx.restore();
  };
  /* CSS 배경(DOM 카드용): L.ui.cardBackCSS() → {background, border} */
  L.ui.cardBackCSS = function () {
    const cb = L.ui.cardBack();
    const P = { grid: `repeating-linear-gradient(45deg, ${cb.b} 0 2px, transparent 2px 9px), repeating-linear-gradient(-45deg, ${cb.b} 0 2px, ${cb.a} 2px 9px)`,
      diamond: `radial-gradient(circle at 50% 50%, ${cb.line} 0 18%, transparent 19%), repeating-linear-gradient(45deg, ${cb.b} 0 2px, transparent 2px 9px), repeating-linear-gradient(-45deg, ${cb.b} 0 2px, ${cb.a} 2px 9px)`,
      stripe: `repeating-linear-gradient(-45deg, ${cb.b} 0 4px, ${cb.a} 4px 10px)`,
      dots: `radial-gradient(${cb.b} 25%, transparent 27%) 0 0/8px 8px, ${cb.a}`,
      wave: `radial-gradient(circle at 50% 0, transparent 40%, ${cb.b} 42% 52%, transparent 54%) 0 0/12px 8px, ${cb.a}` };
    return { background: P[cb.pat] || cb.a, border: '2px solid ' + cb.line };
  };
  /* 보드 판 재질(라운드 34): L.ui.board() → {id, name, c:[밝은, 어두운], grain, line, star, dark}. 바꾸면 'lounge-board' 이벤트. */
  const BOARDS = {
    wood: { name: '나무', c: ['#dcb46e', '#c49550'], grain: 'rgba(110,70,30,.18)', line: '#2a1a0c', star: '#2a1a0c' },
    marble: { name: '대리석', c: ['#ece9e3', '#cfcac2'], grain: 'rgba(120,120,130,.22)', line: '#23262c', star: '#23262c' },
    paper: { name: '종이', c: ['#f4ecd6', '#e3d7b6'], grain: 'rgba(150,130,90,.12)', line: '#3a3226', star: '#3a3226' },
    lacquer: { name: '검은 옻칠', c: ['#2e2725', '#161111'], grain: 'rgba(200,150,90,.08)', line: '#e2c27c', star: '#e2c27c', dark: true },
  };
  const bdId = () => { const v = store.get('board', 'wood'); return BOARDS[v] ? v : 'wood'; };
  L.ui.board = () => { const id = bdId(); return Object.assign({ id }, BOARDS[id]); };
  L.ui.boards = () => Object.keys(BOARDS).map((id) => Object.assign({ id }, BOARDS[id]));
  L.ui.setBoard = (id) => { if (!BOARDS[id]) return; store.set('board', id); try { window.dispatchEvent(new CustomEvent('lounge-board', { detail: { id } })); } catch (e) {} };
  /* 판 바탕 칠하기(결 무늬, 결정적): L.ui.drawBoard(ctx, x, y, w, h) */
  L.ui.drawBoard = function (ctx, x, y, w, hh) {
    const b = L.ui.board(); ctx.save();
    const g = ctx.createLinearGradient(x, y, x + w, y + hh); g.addColorStop(0, b.c[0]); g.addColorStop(1, b.c[1]);
    ctx.fillStyle = g; ctx.fillRect(x, y, w, hh);
    ctx.beginPath(); ctx.rect(x, y, w, hh); ctx.clip();
    ctx.strokeStyle = b.grain; ctx.lineWidth = 1;
    const n = b.id === 'paper' ? 10 : 26;
    for (let i = 0; i < n; i++) {
      const yy = y + ((i * 37) % 26) / 26 * hh; ctx.beginPath(); ctx.moveTo(x, yy);
      if (b.id === 'marble') { ctx.lineWidth = (i % 4) ? 0.7 : 1.6; for (let xx = 0; xx <= w; xx += 8) ctx.lineTo(x + xx, yy + Math.sin(xx * 0.03 + i) * hh * 0.06 + xx * 0.25 * ((i % 3) - 1)); }
      else if (b.id === 'paper') ctx.lineTo(x + w, yy + 1);
      else for (let xx = 0; xx <= w; xx += 8) ctx.lineTo(x + xx, yy + Math.sin(xx * 0.02 + i * 1.7) * 3);
      ctx.stroke();
    }
    ctx.restore();
  };
  /* 진동(라운드 31): 전체 배율 hap.all(0~2) × 종류별 배율 hap.<kind>(0~2). 게임이 navigator.vibrate를 직접 불러도 전체 배율이 걸린다. */
  const HAP_KINDS = [['hit', '타격·충돌', 30], ['alert', '알림·내 차례', 15], ['win', '승리·결과', [40, 60, 80]], ['ui', '버튼·메뉴', 20]];
  const rawVib = (navigator.vibrate && navigator.vibrate.bind(navigator)) || null;
  const hapAll = () => (store.get('buzz', true) === false ? 0 : +store.get('hap.all', 1));
  function hapScale(pat, m) {
    if (!(m > 0)) return 0;
    const arr = Array.isArray(pat) ? pat : [pat];
    return arr.map((v, i) => (i % 2 ? +v || 0 : Math.min(1000, Math.round((+v || 0) * m))));
  }
  /* 게임패드 진동(라운드 34): 연결된 패드가 있으면 같은 패턴·배율로 dual-rumble. 지원 안 되면 조용히 무시. */
  function padRumble(p, m) {
    try {
      if (!p || !navigator.getGamepads) return false;
      const pads = Array.from(navigator.getGamepads() || []).filter(Boolean);
      if (!pads.length) return false;
      const mag = Math.max(0, Math.min(1, 0.55 * m));
      let ok = false;
      pads.forEach((g) => {
        const act = g.vibrationActuator; const hap = g.hapticActuators && g.hapticActuators[0];
        if (!act && !hap) return;
        let t = 0;
        p.forEach((d, i) => {
          if (i % 2 === 0 && d > 0) {
            const dur = Math.min(1000, d);
            setTimeout(() => {
              try {
                if (act && act.playEffect) { const r = act.playEffect('dual-rumble', { startDelay: 0, duration: dur, strongMagnitude: mag, weakMagnitude: Math.min(1, mag * 1.3) }); if (r && r.catch) r.catch(() => {}); }
                else if (hap && hap.pulse) hap.pulse(mag, dur);
              } catch (e) {}
            }, t);
            ok = true;
          }
          t += +d || 0;
        });
      });
      return ok;
    } catch (e) { return false; }
  }
  function hapRaw(pat, m) {
    let p = null; try { p = hapScale(pat, m); } catch (e) {}
    const pad = p ? padRumble(p, m) : false;
    if (!rawVib) return pad;
    try { return p ? (rawVib(p) || pad) : false; } catch (e) { return pad; }
  }
  if (rawVib) { try { navigator.vibrate = function (pat) { if (pat === 0 || (Array.isArray(pat) && !pat.length)) return rawVib(0); return hapRaw(pat, hapAll()); }; } catch (e) {} }
  L.hapticOK = !!rawVib || !!navigator.getGamepads;
  L.haptic = function (kind, ms) {
    const k = HAP_KINDS.find((x) => x[0] === kind) || HAP_KINDS[0];
    return hapRaw(ms != null ? ms : k[2], hapAll() * +store.get('hap.' + k[0], 1));
  };
  function buzz(ms, kind) { return L.haptic(kind || 'ui', ms); }
  /* AI 성향(라운드 31): 판 시작 때 AI 자리마다 무작위. 호스트/로컬 기준(게스트에선 'bal'). 사람 자리는 'bal'. */
  const AI_STYLES = { agg: ['⚔', '공격형'], def: ['🛡', '수비형'], gamble: ['🎲', '도박형'], bal: ['⚖', '균형형'] };
  const STYLE_KEYS = Object.keys(AI_STYLES);
  L.AI_STYLES = AI_STYLES;
  L.aiStyle = function (seat) {
    if (!S || !S.players || !S.players[seat] || !S.players[seat].ai) return 'bal';
    S.styles = S.styles || {};
    if (!S.styles[seat]) S.styles[seat] = STYLE_KEYS[Math.floor(Math.random() * STYLE_KEYS.length)];
    return S.styles[seat];
  };

  /* ---------- menu art ---------- */
  const TINT = {
    blackjack: '#1c5a47', holdem: '#6a2430', snakes: '#6b5418', darts: '#3d2a55',
    pool: '#16525c', golf: '#3f6a22', chess: '#3a3550', racing: '#6a3a1c',
  };
  const NEW_GAMES = ['dodgeball', 'bridge', 'hockey', 'swarm', 'cauldron', 'crowdthief', 'subdive', 'zombie', 'waterbomb', 'royale', 'raid', 'caravan', 'crew', 'dungeon', 'isletrade', 'band', 'ctf', 'claw', 'watersort', 'colorblast', 'paint', 'fencing', 'badminton', 'joust', 'mahjong', 'lighthouse', 'haunted', 'screw', 'nonogram', 'moonlight', 'kartarena', 'realmwar', 'dicequest', 'magetower', 'boxing', 'hexwar', 'lanewar', 'baseball', 'shooting', 'civ', 'mercs', 'slide', 'horsearch', 'gladiator', 'voyage', 'derby', 'expedition', 'crown', 'jigsaw', 'liarcards', 'parkour', 'rts', 'lavacave', 'citybuild', 'rhythm', 'gemcave', 'knight', 'moba', 'dkeeper', 'warships', 'strikeforce', 'cardduel', 'sandbox'];
  const CAT_ORDER = ['카드', '보드', '전략', '퍼즐', '협동', '스포츠', '아케이드', '파티'];
  /* 홈 분류(라운드 23): 게임 def.cat보다 우선 */
  const HOME_CAT = {};
  [['전략', 'civ hexwar realmwar mercs lanewar rts citybuild'], ['퍼즐', 'sudoku watersort colorblast screw nonogram slide jigsaw tiltmaze bridge'],
   ['협동', 'magetower expedition lavacave crew cooking'], ['보드', 'dicequest voyage treasure']]
    .forEach(([c, ids]) => ids.split(' ').forEach((id) => (HOME_CAT[id] = c)));
  const CAT = { blackjack: '카드', holdem: '카드', onecard: '카드', snakes: '보드', chess: '보드', yut: '보드', gomoku: '보드', yacht: '보드',
    darts: '스포츠', pool: '스포츠', golf: '스포츠', bowling: '스포츠', pingpong: '스포츠', racing: '아케이드', airhockey: '아케이드', blocks: '아케이드',
    janggi: '보드', baduk: '보드', tiles: '보드', curling: '스포츠', fingersoccer: '스포츠', sudoku: '보드', gostop: '카드', basketball: '스포츠', archery: '스포츠', diamond: '보드', breakout: '아케이드', landgrab: '보드', oldmaid: '카드', penalty: '스포츠', batting: '스포츠', skijump: '스포츠', worm: '아케이드', sumo: '아케이드', wallmaze: '보드', blockclaim: '보드', clay: '스포츠', fishing: '스포츠', horserace: '파티', spaceshoot: '아케이드', ladder: '파티', wheel: '파티', auction: '파티', copsrobbers: '보드', bomb: '파티', domino: '스포츠', tugwar: '파티', trade: '보드', treasure: '보드', stack: '파티', drawing: '파티', reaction: '파티', bingo: '파티' };
  Object.assign(TINT, { yut: '#6b3a2a', onecard: '#2d4f6b', yacht: '#5a2d5e', drawing: '#2e5a4a', gomoku: '#6b5a2a', reaction: '#7a2d3a' });
  const ICON = {
    blackjack: '<rect x="8" y="10" width="24" height="34" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><rect x="22" y="14" width="24" height="34" rx="3" fill="currentColor" opacity=".9"/><text x="34" y="37" font-size="13" font-weight="700" text-anchor="middle" fill="#1c5a47" font-family="sans-serif">21</text>',
    holdem: '<circle cx="20" cy="34" r="12" fill="none" stroke="currentColor" stroke-width="3" stroke-dasharray="4 3"/><circle cx="20" cy="34" r="5" fill="currentColor"/><path d="M34 10l10 10-10 14-10-14z" fill="currentColor"/>',
    snakes: '<path d="M14 8v40M26 8v40M14 16h12M14 28h12M14 40h12" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M44 10c-10 4 6 12-4 18s4 12-6 18" stroke="currentColor" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="44" cy="10" r="3" fill="currentColor"/>',
    darts: '<circle cx="28" cy="28" r="20" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="12" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="4" fill="currentColor"/><path d="M28 28L48 8M42 6l6 2 2 6" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/>',
    pool: '<circle cx="20" cy="34" r="11" fill="currentColor"/><circle cx="20" cy="34" r="5" fill="#16525c"/><text x="20" y="37.5" font-size="8" font-weight="700" text-anchor="middle" fill="currentColor" font-family="sans-serif">8</text><circle cx="40" cy="22" r="8" fill="none" stroke="currentColor" stroke-width="3"/><path d="M6 52L50 6" stroke="currentColor" stroke-width="2" opacity=".5"/>',
    golf: '<path d="M22 46V8l18 7-18 7" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><ellipse cx="22" cy="47" rx="14" ry="4" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="42" cy="44" r="4" fill="currentColor"/>',
    chess: '<path d="M18 48h22l-3-6H21zM22 42l2-16h10l2 16M20 26h18M29 8v6M26 11h6M24 22c-3-3-1-8 5-8s8 5 5 8z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>',
    yut: '<g fill="currentColor"><rect x="9" y="8" width="7" height="40" rx="3.5" transform="rotate(-12 12 28)"/><rect x="20" y="8" width="7" height="40" rx="3.5" opacity=".55" transform="rotate(-4 23 28)"/><rect x="31" y="8" width="7" height="40" rx="3.5" transform="rotate(4 34 28)"/><rect x="42" y="8" width="7" height="40" rx="3.5" opacity=".55" transform="rotate(12 45 28)"/></g>',
    onecard: '<rect x="10" y="12" width="22" height="32" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-10 21 28)"/><rect x="24" y="10" width="22" height="32" rx="3" fill="currentColor"/><text x="35" y="31" font-size="14" font-weight="700" text-anchor="middle" fill="#2d4f6b" font-family="sans-serif">1</text>',
    yacht: '<rect x="7" y="18" width="22" height="22" rx="5" fill="currentColor"/><g fill="#5a2d5e"><circle cx="13" cy="24" r="2.4"/><circle cx="23" cy="34" r="2.4"/><circle cx="18" cy="29" r="2.4"/></g><rect x="30" y="10" width="20" height="20" rx="5" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(14 40 20)"/><circle cx="40" cy="20" r="2.4" fill="currentColor"/>',
    drawing: '<path d="M10 44c6-10 12-4 16-12s10-14 20-16" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M36 38l10-10 4 4-10 10-6 2z" fill="currentColor"/><circle cx="14" cy="14" r="5" fill="none" stroke="currentColor" stroke-width="3"/>',
    gomoku: '<path d="M8 14h40M8 24h40M8 34h40M8 44h40M14 8v40M24 8v40M34 8v40M44 8v40" stroke="currentColor" stroke-width="1.5" opacity=".5"/><circle cx="24" cy="24" r="5" fill="currentColor"/><circle cx="34" cy="34" r="5" fill="currentColor"/><circle cx="34" cy="24" r="5" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="14" cy="14" r="5" fill="currentColor"/>',
    reaction: '<path d="M30 6L14 32h12l-4 18 20-28H30z" fill="currentColor"/>',
    racing: '<path d="M8 36l4-10h22l8 6h6v8H8z" fill="currentColor"/><circle cx="17" cy="41" r="5" fill="#6a3a1c" stroke="currentColor" stroke-width="3"/><circle cx="40" cy="41" r="5" fill="#6a3a1c" stroke="currentColor" stroke-width="3"/><path d="M4 18h14M10 12h14" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
  };

  /* ---------- app shell ---------- */
  const app = document.getElementById('app');
  let screenEl = null;
  function show(el) { if (screenEl) screenEl.remove(); screenEl = el; app.appendChild(el); }
  // 같은 화면을 다시 그릴 때(방 로비 등) 스크롤 위치 유지: el.dataset.keep이 이전 화면과 같으면 .scroll 상자들의 scrollTop을 옮김
  function showKeep(el) {
    const prev = screenEl && screenEl.dataset && screenEl.dataset.keep === el.dataset.keep ? [...screenEl.querySelectorAll('.scroll')].map((x) => x.scrollTop) : null;
    show(el);
    if (prev) [...el.querySelectorAll('.scroll')].forEach((x, i) => { if (prev[i]) x.scrollTop = prev[i]; });
  }
  function toast(text, ms) {
    const t = h('div', { class: 'toast', text });
    app.appendChild(t);
    setTimeout(() => t.remove(), ms || 1800);
  }
  L.toast = toast;
  /* 알림 띠(라운드 50): L.banner(text, {sub, color, ms, parent}) — 라운드·차례 바뀜 등. 화면 가운데에 잠깐 떴다 사라짐(누르기 막지 않음) */
  function banner(text, o) {
    o = o || {};
    const par = o.parent || (S && S.stage) || app;
    par.querySelectorAll(':scope > .tbanner').forEach((e) => e.remove());
    const b = h('div', { class: 'tbanner' + (o.small ? ' sm' : ''), role: 'status', style: o.color ? { '--bc': o.color } : null },
      h('div', { class: 'tb-t', text }), o.sub ? h('div', { class: 'tb-s', text: o.sub }) : null);
    par.appendChild(b);
    const ms = o.ms || (Anim.on() ? 1300 : 1000);
    b.style.setProperty('--bms', ms + 'ms');
    setTimeout(() => b.remove(), ms + 50);
    return b;
  }
  L.banner = banner;
  L.anim = { on: () => Anim.on() };
  /* PC 전용 게임(def.pcOnly, 라운드 45): 마우스 없는 터치 기기에서는 시작을 막고 안내한다. */
  const touchOnly = () => { try { if (window.LOUNGE_DESKTOP || (L.debug && (L.debug.forcePC || L.debug.noTut))) return false; /* 시험 도구(debug.noTut)는 막지 않음 */ return !matchMedia('(any-pointer:fine)').matches && matchMedia('(any-pointer:coarse)').matches; } catch (e) { return false; } };
  L.touchOnly = touchOnly;
  function pcOnlyBlocked(def) { return !!(def && def.pcOnly) && touchOnly(); }
  function pcOnlySheet(def) {
    const o = overlay(h('div', { class: 'sheet' },
      h('h2', { text: '🖥 PC 전용 게임' }),
      h('p', { class: 'muted', style: { margin: 0 }, text: (def ? def.name + '은(는) ' : '') + 'PC나 마우스·키보드에서 할 수 있어요. 이 기기에서는 온라인 방에 들어가 관전할 수 있어요.' }),
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } }, h('button', { class: 'btn primary', text: '알겠어요', onclick: () => o.remove() }))));
    return o;
  }
  function overlay(content, opts) {
    const o = h('div', { class: 'overlay' + (opts && opts.cls ? ' ' + opts.cls : ''), 'data-core': '1' }, content);
    (opts && opts.parent || app).appendChild(o);
    return o;
  }
  /* 고르기 단계(라운드 44): 사람 자리가 전원 고를 때까지 시작하지 않는다. 제한 시간 없음.
     L.pick.waiting(players, picked) → 아직 안 고른 사람 자리 목록(AI 자리 제외 — 나간 사람은 core가 AI로 바꾸므로 자동 제외).
     api.pickBar({picked(seat)→bool, onForce(), parent?, style?, note?}) → {el, update(), destroy(), waiting()}
       누가 골랐는지 칩(✓/…) + 방장(로컬·호스트)에게 「지금 시작」(확인 창 → onForce: 안 고른 자리는 무작위로 채워 시작). 0.25초마다 스스로 갱신. */
  L.pick = {
    // AI는 사람 뒤에 고르기(라운드 45): 사람 자리가 전원 골랐으면 true → 그때 AI가 남은 것 중에서 고른다(방장 「지금 시작」이면 바로).
    aiTurn(players, picked) { return L.pick.waiting(players, picked).length === 0; },
    waiting(players, picked) { const o = []; (players || []).forEach((p, i) => { if (p && !p.ai) { let ok = false; try { ok = !!picked(i); } catch (e) {} if (!ok) o.push(i); } }); return o; },
  };
  function pickBar(api, o) {
    o = o || {};
    const chips = h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '4px', justifyContent: 'center', minWidth: 0 } });
    const note = h('div', { class: 'muted', style: { fontSize: '12px', textAlign: 'center' } });
    const btn = h('button', { class: 'btn sm', text: '지금 시작', style: { minHeight: '44px', flex: 'none' }, onclick(e) {
      e.stopPropagation();
      const w = L.pick.waiting(api.players, o.picked);
      if (!w.length) return;
      confirmSheet('지금 시작할까요?', '아직 안 고른 ' + w.map((i) => (api.players[i] || {}).name || (i + 1) + '번').join(', ') + ' 자리는 무작위로 정해요.', '지금 시작', () => { try { o.onForce && o.onForce(w); } catch (er) { console.error(er); } });
    } });
    const el = h('div', { class: 'pick-bar', 'data-core': '1', style: Object.assign({ position: 'absolute', left: '8px', right: '8px', marginLeft: 'auto', marginRight: 'auto', width: 'fit-content', bottom: '8px', zIndex: 30, display: 'flex', alignItems: 'center', gap: '8px',
      maxWidth: 'calc(100% - 16px)', boxSizing: 'border-box', padding: '6px 8px', borderRadius: '12px', background: 'rgba(23,19,31,.88)', border: '1px solid rgba(227,174,69,.35)', pointerEvents: 'auto' }, o.style || {}) },
      h('div', { style: { display: 'flex', flexDirection: 'column', gap: '3px', minWidth: 0 } }, chips, note), btn);
    if (o.style && o.style.position === 'relative') Object.assign(el.style, { left: 'auto', right: 'auto', transform: 'none' });
    (o.parent || S.stage || app).appendChild(el);
    let sig = '';
    function update() {
      const ps = api.players || [], w = L.pick.waiting(ps, o.picked);
      const s2 = ps.map((p, i) => (p.ai ? 'a' : w.includes(i) ? 'w' : 'k') + (p.name || '')).join('|') + api.isHost;
      el.style.display = ps.some((p) => !p.ai) ? 'flex' : 'none';
      if (s2 === sig) return w; sig = s2;
      chips.innerHTML = '';
      const ais = ps.filter((p) => p.ai).length, many = ais > 3;
      if (many) chips.append(h('span', { style: { fontSize: '12px', padding: '2px 7px', borderRadius: '999px', whiteSpace: 'nowrap', background: 'rgba(28,102,80,.55)' }, text: 'AI ' + ais + '명 ✓' }));
      ps.forEach((p, i) => (many && p.ai) || chips.append(h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '12px', padding: '2px 7px', borderRadius: '999px', whiteSpace: 'nowrap',
        background: w.includes(i) ? 'rgba(255,255,255,.06)' : 'rgba(28,102,80,.55)', color: w.includes(i) ? 'var(--muted)' : 'var(--ink)' } },
        h('i', { class: 'dot', style: { '--c': p.color || '#888' } }), (p.name || (i + 1) + '번') + (w.includes(i) ? ' …' : ' ✓'))));
      note.textContent = o.note || (w.length ? '모두 고르면 시작해요' : '곧 시작해요');
      btn.style.display = api.isHost && w.length ? '' : 'none';
      return w;
    }
    const iv = setInterval(() => { if (!el.isConnected) { clearInterval(iv); return; } update(); }, 250);
    update();
    return { el, update, waiting: () => L.pick.waiting(api.players, o.picked), destroy() { clearInterval(iv); el.remove(); } };
  }
  function confirmSheet(title, body, okText, onOk) {
    const o = overlay(h('div', { class: 'sheet' },
      h('h2', { text: title }), body ? h('p', { class: 'muted', style: { margin: 0 }, text: body }) : null,
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn ghost', text: '취소', onclick: () => o.remove() }),
        h('button', { class: 'btn danger', text: okText, onclick: () => { o.remove(); onOk(); } }))));
    setTimeout(() => { const b = o.querySelector('.btn.danger'); if (b && matchMedia('(pointer:fine)').matches) b.focus(); }, 30);
  }

  /* 규칙 그림(라운드 33): 섹션에 fig(하나 또는 배열). 문자열이면 인라인 SVG, 함수면 (ctx, w, h) 캔버스 그리기,
     {svg|draw, cap, h} 객체면 캡션·높이(캔버스, 기본 120) 지정. 폭은 화면에 맞춰 줄어든다(최대 360px). */
  function ruleFigs(sec) {
    if (!sec.fig) return null;
    return (Array.isArray(sec.fig) ? sec.fig : [sec.fig]).map((f) => {
      if (typeof f === 'string' || typeof f === 'function') f = typeof f === 'string' ? { svg: f } : { draw: f };
      const box = h('figure', { class: 'rfig' });
      try {
        if (f.svg) { const w = h('div', { class: 'rfig-svg' }); w.innerHTML = f.svg; box.append(w); }
        else if (f.draw) {
          const W = 340, H = f.h || 120, dpr = Math.min(3, window.devicePixelRatio || 1);
          const c = h('canvas', { width: W * dpr, height: H * dpr, style: { aspectRatio: W + ' / ' + H } });
          const x = c.getContext('2d'); x.scale(dpr, dpr); f.draw(x, W, H); box.append(c);
        }
      } catch (e) { console.error(e); }
      if (f.cap) box.append(h('figcaption', { text: f.cap }));
      return box;
    });
  }
  /* 규칙 움직이는 예시(라운드 50): 섹션에 demo(하나 또는 배열).
     함수 (ctx, w, h, t초) → 매 프레임 그리기. 또는 선언형 {frames:[{say, items:[...]}], ms, h, cap}:
       item = {k(같은 k끼리 프레임 사이 이동), x, y, w, h, shape:'rect'|'circle'|'text', fill, stroke, text, ink, size, a(투명도), r(모서리)}
       프레임은 ms(기본 1300) 간격으로 넘어가며 위치·크기·투명도가 부드럽게 바뀐다. say는 아래 자막. 탭하면 멈춤/계속.
     전환 효과 끔·prefers-reduced-motion이면 움직이지 않고 탭으로 한 장씩 넘긴다. */
  const DEMO_W = 340;
  function cssFont(v) { try { return getComputedStyle(document.documentElement).getPropertyValue(v).trim() || 'sans-serif'; } catch (e) { return 'sans-serif'; } }
  function demoFig(d) {
    if (typeof d === 'function') d = { draw: d };
    const H = d.h || 140, dpr = Math.min(3, window.devicePixelRatio || 1);
    const c = h('canvas', { width: Math.round(DEMO_W * dpr), height: Math.round(H * dpr), style: { aspectRatio: DEMO_W + ' / ' + H, cursor: 'pointer' }, 'aria-label': d.cap || '움직이는 예시' });
    const x = c.getContext('2d');
    const still = !Anim.on();
    const fr = d.frames || null, ms = d.ms || 1300;
    const font = cssFont('--f-body');
    const rn = () => window.performance.now();
    let t0 = rn(), step = 0, paused = still, pt = 0, wait = 0;
    const ease = (u) => (u < 0 ? 0 : u > 1 ? 1 : u * u * (3 - 2 * u));
    function drawFrames(t) {
      const n = fr.length, idx = still ? step % n : Math.floor(t * 1000 / ms) % n;
      const u = still ? 1 : ease(((t * 1000) % ms) / (ms * 0.5));
      const cur = fr[idx], prv = fr[(idx + n - 1) % n];
      const pm = {}; (prv.items || []).forEach((it) => { if (it.k != null) pm[it.k] = it; });
      const L2 = (a, b) => (a == null ? b : b == null ? a : a + (b - a) * u);
      const list = [];
      (cur.items || []).forEach((it) => {
        const p0 = it.k != null && idx !== 0 ? pm[it.k] : null;
        const a1 = it.a == null ? 1 : it.a;
        list.push(p0 ? Object.assign({}, it, { x: L2(p0.x, it.x), y: L2(p0.y, it.y), w: L2(p0.w, it.w), h: L2(p0.h, it.h), a: L2(p0.a == null ? 1 : p0.a, a1), text: u < 0.5 && p0.text != null ? p0.text : it.text, fill: u < 0.5 && p0.fill ? p0.fill : it.fill })
          : Object.assign({}, it, { a: a1 * (idx === 0 || it.k == null && !it.fadeIn ? 1 : u) }));
      });
      x.fillStyle = d.bg || 'rgba(127,127,127,.12)'; x.fillRect(0, 0, DEMO_W, H);
      list.forEach((it) => {
        x.globalAlpha = Math.max(0, Math.min(1, it.a));
        if (it.shape === 'circle') { x.beginPath(); x.arc(it.x, it.y, (it.w || 10) / 2, 0, 7); if (it.fill) { x.fillStyle = it.fill; x.fill(); } if (it.stroke) { x.strokeStyle = it.stroke; x.lineWidth = it.lw || 2; x.stroke(); } }
        else if (it.shape !== 'text') {
          x.beginPath(); if (x.roundRect) x.roundRect(it.x, it.y, it.w, it.h, it.r == null ? 4 : it.r); else x.rect(it.x, it.y, it.w, it.h);
          if (it.fill) { x.fillStyle = it.fill; x.fill(); } if (it.stroke) { x.strokeStyle = it.stroke; x.lineWidth = it.lw || 2; x.stroke(); }
        }
        if (it.text != null) {
          const sz = it.size || 13;
          x.fillStyle = it.ink || '#fff'; x.font = (it.bold === false ? '' : '700 ') + sz + 'px ' + font;
          x.textAlign = it.align || 'center'; x.textBaseline = 'middle';
          const mid = it.shape === 'text' || it.shape === 'circle';
          const cx = mid ? it.x : it.x + it.w / 2, cy = mid ? it.y : it.y + it.h / 2;
          String(it.text).split('\n').forEach((ln, i, arr) => x.fillText(ln, cx, cy + (i - (arr.length - 1) / 2) * sz * 1.15));
        }
      });
      x.globalAlpha = 1;
      if (cur.say) {
        x.fillStyle = 'rgba(0,0,0,.6)'; x.fillRect(0, H - 26, DEMO_W, 26);
        x.fillStyle = '#fff'; x.font = '600 13px ' + font; x.textAlign = 'center'; x.textBaseline = 'middle';
        x.fillText((still ? (idx + 1) + '/' + n + ' · ' : '') + cur.say, DEMO_W / 2, H - 13, DEMO_W - 8);
      }
    }
    function paint(t) {
      x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, DEMO_W, H);
      try { if (fr) drawFrames(t); else d.draw(x, DEMO_W, H, t); } catch (e) { console.error(e); }
    }
    const raf = Clock.realRAF || window.requestAnimationFrame;   // 일시정지 중에도 규칙 예시는 움직임
    function loop() {
      if (!c.isConnected) { if (++wait > 90) return; raf(loop); return; }   // 붙기 전 잠깐 기다리고, 닫히면 멈춤
      wait = -1e9;
      if (!paused) { pt = (rn() - t0) / 1000; paint(pt); }
      raf(loop);
    }
    paint(fr ? 0 : 1);
    if (!still) raf(loop);
    c.addEventListener('click', () => {
      if (still) { step++; paint(0); return; }
      paused = !paused; if (!paused) t0 = rn() - pt * 1000;
    });
    const box = h('figure', { class: 'rfig rdemo' }, c);
    box.append(h('figcaption', { text: (d.cap ? d.cap + ' · ' : '') + (still ? '탭하면 다음 장면' : '탭하면 멈춤') }));
    return box;
  }
  /* 게임 파일 대신 core가 붙이는 예시(바둑: 단수·패). 게임 rules에 demo가 하나라도 있으면 쓰지 않는다. */
  const CORE_DEMOS = {};
  (function () {
    const N = 6, G = 20, ox = 120, oy = 14;
    const P = (c, r) => [ox + c * G, oy + r * G];
    const board = (extra) => {
      const it = [{ shape: 'rect', x: ox - 12, y: oy - 12, w: (N - 1) * G + 24, h: (N - 1) * G + 24, fill: '#d6a85a', r: 6 }];
      for (let i = 0; i < N; i++) {
        it.push({ shape: 'rect', x: ox, y: oy + i * G, w: (N - 1) * G, h: 1, fill: '#4a3214', r: 0 });
        it.push({ shape: 'rect', x: ox + i * G, y: oy, w: 1, h: (N - 1) * G, fill: '#4a3214', r: 0 });
      }
      return it.concat(extra);
    };
    const st = (k, c, r, col, a) => { const [x, y] = P(c, r); return { k, shape: 'circle', x, y, w: 17, fill: col === 'b' ? '#151515' : '#f4f1ea', stroke: col === 'b' ? '#000' : '#9a958a', lw: 1, a }; };
    const mark = (c, r, t) => { const [x, y] = P(c, r); return { shape: 'text', x, y, text: t, ink: '#e8443a', size: 14 }; };
    const B1 = [st('b1', 2, 1, 'b'), st('b2', 1, 2, 'b'), st('b3', 3, 2, 'b')];
    const atari = { h: 160, cap: '단수: 활로(숨구멍)가 1개 남은 돌', frames: [
      { say: '흰 돌의 활로: 위·왼쪽·오른쪽·아래 4개', items: board([st('w', 2, 2, 'w'), mark(2, 1, '•'), mark(1, 2, '•'), mark(3, 2, '•'), mark(2, 3, '•')]) },
      { say: '흑이 3곳을 막으면 활로 1개 = 「단수」', items: board([st('w', 2, 2, 'w')].concat(B1, [mark(2, 3, '!')])) },
      { say: '마지막 활로까지 막으면 잡혀요', items: board([st('w', 2, 2, 'w')].concat(B1, [st('b4', 2, 3, 'b')])) },
      { say: '잡힌 돌은 판에서 들어내요', items: board(B1.concat([st('b4', 2, 3, 'b'), st('w', 2, 2, 'w', 0)])) },
    ] };
    const kb = [st('a', 2, 1, 'b'), st('c', 1, 2, 'b'), st('d', 2, 3, 'b'), st('e', 3, 1, 'w'), st('f', 4, 2, 'w'), st('g', 3, 3, 'w')];
    const ko = { h: 160, cap: '패: 따낸 한 점을 곧바로 되따낼 수 없음', frames: [
      { say: '흑 입 안의 흰 한 점 — 흑이 따낼 수 있어요', items: board(kb.concat([st('y', 2, 2, 'w')])) },
      { say: '흑이 따내요 (흰 1점 잡힘)', items: board(kb.concat([st('y', 2, 2, 'w', 0), st('x', 3, 2, 'b')])) },
      { say: '흰이 바로 되따내면 같은 모양 반복 → 금지', items: board(kb.concat([st('x', 3, 2, 'b'), mark(2, 2, '✕')])) },
      { say: '다른 곳에 한 수씩 두고 나면…', items: board(kb.concat([st('x', 3, 2, 'b'), st('z', 5, 5, 'w'), st('zz', 0, 5, 'b')])) },
      { say: '이제 흰이 되따낼 수 있어요', items: board(kb.concat([st('x', 3, 2, 'b', 0), st('y', 2, 2, 'w'), st('z', 5, 5, 'w'), st('zz', 0, 5, 'b')])) },
    ] };
    CORE_DEMOS.baduk = [{ h: '움직이는 예시 — 단수 · 패', p: ['그림을 보면 「단수」와 「패」가 어떻게 되는지 알 수 있어요.'], demo: [atari, ko] }];
  })();
  /* rules sheet — game defs provide rules: [{h, p:[...]}] */
  function rulesSheet(id, parent) {
    const g = L.games[id];
    const pausedHere = !!(S && S.gameId === id && typeof canPause === 'function' && canPause() && !Clock.paused);
    if (pausedHere) setPaused(true);   // 혼자 하는 실시간 판: 규칙 보는 동안 멈춤
    const close = () => { o.remove(); if (pausedHere) setPaused(false); if (S) scheduleAI(); };
    const body = h('div', { class: 'rules' },
      g.blurb ? h('p', { class: 'lead', text: g.blurb }) : null,
      g.codex ? h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, text: '📖 도감 열기', onclick() { o.remove(); codexSheet(id, parent); } }) : null,
      g.quick && g.quick.length ? h('ol', { class: 'quick' }, g.quick.map((t) => h('li', { text: t }))) : null,
      g.tutorial && g.tutorial.length && S && S.gameId === id ? h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, text: '▶ 따라 하며 배우기 (안내 다시 보기)', onclick() { o.remove(); runTutorial(g, true); } }) : null,
      (g.rules || []).concat((g.rules || []).some((r) => r.demo) ? [] : (CORE_DEMOS[id] || [])).map((sec) => h('section', null, h('h3', { text: sec.h }), sec.p && sec.p.length ? h('ul', null, sec.p.map((t) => h('li', { text: t }))) : null, ruleFigs(sec),
        sec.demo ? (Array.isArray(sec.demo) ? sec.demo : [sec.demo]).map((d) => { try { return demoFig(d); } catch (e) { console.error(e); return null; } }) : null)),
      g.controls && g.controls.length ? h('section', null, h('h3', { text: '키보드 · 게임패드' }),
        h('ul', null, Controls.bindings(g).map((b) => h('li', { text: b.label + ' — ' + (b.keys.map(keyLabel).concat(b.pad.map((n) => PAD_NAME[n] || n)).join(' / ') || '없음') }))),
        h('button', { class: 'btn sm', text: '조작 바꾸기', onclick() { o.remove(); controlsSheet(id, parent, () => rulesSheet(id, parent)); } })) : null);
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '규칙' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      body,
      h('button', { class: 'btn block', text: '닫기', onclick: close })), { cls: 'rules-ov', parent: parent || app });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.rules = rulesSheet;
  /* 상황 도움말(라운드 35): 판 중 ?·F1 → def.hint(state, seat)이 있으면 「지금 상황」 카드 먼저(문자열 또는 문자열 배열), 「전체 규칙 보기」 버튼.
     seat = 이 폰에서 보는 자리(여럿이 돌려하면 지금 차례인 사람 자리, 없으면 -1). hint가 없거나 비거나 오류면 바로 규칙. */
  function helpSheet(id, parent) {
    const g = L.games[id];
    let lines = null;
    if (g.hint && S && S.gameId === id && S.state && !g.result(S.state)) {
      let seat = viewerSeat();
      if (seat < 0) { const mine = S.api.mySeats(); seat = actorsOf(g, S.state).find((x) => mine.includes(x)); if (seat === undefined) seat = mine.length ? mine[0] : -1; }
      try { lines = g.hint(clone(S.state), seat); } catch (e) { console.warn('hint', e); lines = null; }
      if (typeof lines === 'string') lines = [lines];
        lines = Array.isArray(lines) ? lines.filter((t) => t != null && t !== '') : null;
      if (!Array.isArray(lines) || !lines.filter(Boolean).length) lines = null; else lines = lines.filter(Boolean).slice(0, 6).map(String);
    }
    if (!lines) return rulesSheet(id, parent);
    const close = () => { o.remove(); if (S) scheduleAI(); };
    const o = overlay(h('div', { class: 'sheet hint-sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '지금 상황' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      h('ul', { class: 'hint-list' }, lines.map((t, i) => h('li', { class: i ? '' : 'first', text: t }))),
      h('div', { class: 'row', style: { justifyContent: 'flex-end', flexWrap: 'nowrap' } },
        h('button', { class: 'btn ghost', text: '전체 규칙 보기', onclick() { o.remove(); rulesSheet(id, parent); } }),
        h('button', { class: 'btn', text: '닫기', onclick: close }))), { cls: 'rules-ov hint-ov', parent: parent || app });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.help = helpSheet;

  /* 도감(codex): def.codex = [{ h: '탭 이름', p?: ['설명 줄'], rows?: [{ icon?: '이모지|SVG 문자열', name, tag?, desc }] }]
     또는 def.codex = function (el, ctx) { ... el에 직접 그림 ... }  (ctx.close() 로 닫기). 게임 시작 전·중 모두 열 수 있음. */
  function codexSheet(id, parent) {
    const g = L.games[id];
    if (!g || !g.codex) return null;
    const close = () => { o.remove(); if (S) scheduleAI(); };
    const body = h('div', { class: 'rules codex' });
    let o;
    if (typeof g.codex === 'function') {
      try { g.codex(body, { close: () => close(), inGame: !!(S && S.gameId === id) }); } catch (e) { console.error(e); body.append(h('p', { text: '도감을 여는 중 문제가 생겼어요' })); }
    } else {
      const secs = g.codex;
      const tabs = h('div', { class: 'chips' });
      const pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
      let cur = 0;
      const rowEl = (r, from) => {
          const ic = h('span', { class: 'cx-ic' });
          if (r.icon && /^\s*</.test(r.icon)) ic.innerHTML = r.icon; else ic.textContent = r.icon || '•';
          return h('div', { class: 'cx-row' }, ic, h('div', { class: 'cx-tx' },
            h('div', { class: 'cx-nm' }, h('b', { text: r.name }), r.tag ? h('span', { class: 'cx-tag', text: r.tag }) : null, from ? h('span', { class: 'cx-tag cx-from', text: from }) : null),
            r.desc ? h('div', { class: 'cx-d', text: r.desc }) : null));
      };
      /* 도감 검색(라운드 32): 이름·태그·설명, 탭을 넘어 검색. 초성 검색도 됨 */
      const search = () => {
        const q = normK(qIn.value);
        tabs.style.display = q || secs.length < 2 ? 'none' : '';
        if (!q) { show(cur); return; }
        pane.innerHTML = '';
        let n = 0;
        secs.forEach((sec) => (sec.rows || []).forEach((r) => {
          if (hit(r.name, q) || hit(r.tag, q) || hit(r.desc, q)) { n++; pane.append(rowEl(r, secs.length > 1 ? sec.h : '')); }
        }));
        pane.prepend(h('p', { class: 'note', style: { margin: 0 }, text: n ? `「${qIn.value.trim()}」 ${n}개` : `「${qIn.value.trim()}」에 맞는 항목이 없어요. 다른 낱말로 찾아보세요.` }));
      };
      const qIn = h('input', { type: 'search', class: 'cx-search', placeholder: '🔍 도감에서 찾기 (이름·설명)', 'aria-label': '도감 검색', oninput: search,
        onkeydown(e) { if (e.key === 'Escape' && qIn.value) { e.stopPropagation(); e.preventDefault(); qIn.value = ''; search(); } } });
      const show = (k) => {
        cur = k;
        pane.innerHTML = '';
        [...tabs.children].forEach((b, i) => b.classList.toggle('on', i === k));
        const sec = secs[k];
        (sec.p || []).forEach((t) => pane.append(h('p', { class: 'note', style: { margin: 0 }, text: t })));
        (sec.rows || []).forEach((r) => pane.append(rowEl(r)));
        pane.scrollTop = 0;
      };
      secs.forEach((sec, k) => tabs.append(h('button', { class: 'btn sm', text: sec.h + (sec.rows ? ' ' + sec.rows.length : ''), onclick: () => show(k) })));
      if (secs.some((sec) => (sec.rows || []).length)) body.append(qIn);
      if (secs.length > 1) body.append(tabs);
      body.append(pane);
      if (secs.length) show(0);
    }
    o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '📖 도감' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      body,
      h('button', { class: 'btn block', text: '닫기', onclick: close })), { cls: 'rules-ov', parent: parent || app });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.codex = codexSheet;

  function myName() { return store.get('name', '') || ''; }
  /* per-bot difficulty: 1 쉬움, 2 보통, 3 어려움 */
  const LV = { 1: '쉬움', 2: '보통', 3: '어려움' };
  L.AI_LEVELS = LV;
  function lvChip(lv, onChange) {
    const v = lv || 2;
    return h('button', { class: 'lvchip lv' + v, type: 'button', 'aria-label': 'AI 난이도 ' + LV[v] + ', 눌러서 바꾸기', text: LV[v],
      onclick(e) { e.stopPropagation(); onChange(v % 3 + 1); Sfx.play('click'); } });
  }
  /* 라운드 49: AI가 3명 이상이면 「모든 AI 난이도」 한 줄로 일괄 변경 */
  function allLvRow(lvs, onSet) {
    if (lvs.length < 3) return null;
    const same = lvs.every((v) => (v || 2) === (lvs[0] || 2)) ? (lvs[0] || 2) : 0;
    return h('div', { class: 'seat', style: { gap: '6px' } }, h('span', { class: 'nm', style: { flex: 1 }, text: '모든 AI ' + lvs.length + '명 난이도' }),
      h('div', { class: 'seg' }, [1, 2, 3].map((v) => h('button', { class: same === v ? 'on' : '', type: 'button', text: LV[v], onclick(e) { e.stopPropagation(); onSet(v); Sfx.play('click'); } }))));
  }
  /* actor(state) may return one seat, an array of seats acting at once, or null */
  function actorsOf(def, st) { if (!st) return []; const a = def.actor(st); return a == null ? [] : Array.isArray(a) ? a : [a]; }
  L.actorsOf = actorsOf;
  /* game options: def.options = [{id, label, choices:[{v, label}], def}] */
  function shuffleOrder(def, opts, arr) {   // 차례 순서 무작위: 자리를 섞는다(색은 사람을 따라감)
    if (!opts || opts._order !== 'rand' || arr.length < 2) return arr;
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
  function orderToast(players) {
    if (players.length > 1) setTimeout(() => toast('차례 순서: ' + players.map((p) => p.name).join(' → ')), 300);
  }
  // 옵션에 따라 최대 인원이 달라지는 게임: def.maxPlayersIf(opts) (예: 펭귄 실시간 8명, 차례대로 4명)
  function maxFor(g, opts) { const m = g.maxPlayersIf ? g.maxPlayersIf(opts || optDefaults(g, null)) : 0; return m ? Math.min(g.maxPlayers, m) : g.maxPlayers; }
  function optDefaults(def, saved) {
    const o = {};
    (def.options || []).forEach((op) => {
      const sv = saved && saved[op.id];
      if (op.multi) { // round 60: 여러 개 고르기 — 값은 고른 v의 배열(choices 순서), 비면 def(없으면 전부)
        const ok = Array.isArray(sv) ? op.choices.map((c) => c.v).filter((v) => sv.includes(v)) : [];
        o[op.id] = ok.length >= (op.min || 1) ? ok : Array.isArray(op.def) ? op.def.slice() : op.choices.map((c) => c.v);
        return;
      }
      o[op.id] = op.choices.some((c) => c.v === sv) ? sv : op.def != null ? op.def : op.choices[0].v;
    });
    return o;
  }
  function optRows(def, opts, onChange, readOnly) {
    if (!def.options || !def.options.length) return null;
    // round 47: op.tip / choice.tip → 마우스 올리면 title, 「ⓘ」를 누르면 설명 한 줄(터치)
    return h('div', { class: 'opts' }, def.options.map((op) => {
      // round 52: 고른 칸에 설명(choice.tip)이 있으면 칩 아래에 늘 보여 줌
      if (op.multi) return multiRow(op, opts, onChange, readOnly);
      const curC = op.choices.find((c) => c.v === opts[op.id]);
      const note = h('p', { class: 'note', style: { margin: '2px 0 0', display: curC && curC.tip ? 'block' : 'none' }, text: curC && curC.tip ? curC.label + ': ' + curC.tip : '' });
      const show = (t) => { note.textContent = t; note.style.display = note.style.display === 'none' || note._t !== t ? 'block' : 'none'; note._t = t; };
      const lab = h('span', { class: 'label', text: op.label, title: op.tip || null, 'data-tip': op.tip || null });
      const anyTip = op.tip || op.choices.some((c) => c.tip);
      const info = anyTip ? h('button', { class: 'iconbtn', 'aria-label': op.label + ' 설명', style: { minWidth: '44px', minHeight: '44px', fontSize: '15px' }, text: 'ⓘ',
        onclick() { const cur = op.choices.find((c) => c.v === opts[op.id]); show([op.tip, cur && cur.tip ? cur.label + ': ' + cur.tip : ''].filter(Boolean).join(' — ')); } }) : null;
      return h('div', { class: 'field' },
        info ? h('div', { class: 'row', style: { gap: '4px', alignItems: 'center', flexWrap: 'nowrap' } }, lab, info) : lab,
        h('div', { class: 'chips wrap' }, op.choices.map((c) => h('button', {
          class: 'btn sm' + (opts[op.id] === c.v ? ' on' : ''), text: c.label, title: c.tip || null, disabled: readOnly && opts[op.id] !== c.v ? true : null,
          onclick() { if (readOnly) return; opts[op.id] = c.v; onChange(); },
        }))), note);
    }));
  }

  // round 60: op.multi → 칩을 눌러 켜고 끄기(최소 op.min, 기본 1개) + 「전체」 칩
  function multiRow(op, opts, onChange, readOnly) {
    const all = op.choices.map((c) => c.v), cur = Array.isArray(opts[op.id]) ? opts[op.id] : all, min = op.min || 1;
    const set = (arr) => { if (readOnly) return; opts[op.id] = all.filter((v) => arr.includes(v)); onChange(); };
    const full = cur.length === all.length;
    return h('div', { class: 'field' },
      h('span', { class: 'label', text: op.label + ' · ' + cur.length + '/' + all.length + '개', title: op.tip || null }),
      op.tip ? h('p', { class: 'note', style: { margin: '0 0 2px' }, text: op.tip }) : null,
      h('div', { class: 'chips wrap' },
        h('button', { class: 'btn sm' + (full ? ' on' : ''), text: full ? '전체 ✓' : '전체', disabled: readOnly ? true : null, 'aria-pressed': String(full),
          onclick() { set(full ? all.slice(0, min) : all); } }),
        op.choices.map((c) => { const on = cur.includes(c.v); return h('button', {
          class: 'btn sm' + (on ? ' on' : ''), text: (on ? '✓ ' : '') + c.label, title: c.tip || null, 'aria-pressed': String(on), disabled: readOnly && !on ? true : null,
          onclick() { if (readOnly) return; if (on) { if (cur.length <= min) { toast('최소 ' + min + '개는 골라 주세요'); return; } set(cur.filter((v) => v !== c.v)); } else set(cur.concat(c.v)); } }); })));
  }
  /* 인원 게이지: [−] ━━●━━ [+] 와 숫자. onInput(v)은 끄는 동안(가벼운 미리보기), onSet(v)은 손을 뗄 때/버튼 */
  function countCtl(o) {
    if (!document.getElementById('cnt-css')) document.head.append(h('style', { id: 'cnt-css', text:
      '.cnt{display:flex;align-items:center;gap:6px;width:100%;flex-wrap:nowrap}.cnt .btn{min-width:44px!important;min-height:44px!important;height:44px;font-size:20px;padding:0 6px!important;flex:none}' +
      '.cnt input[type=range]{flex:1;min-width:0;height:44px!important;min-height:0!important;margin:0;padding:0!important;border:0!important;background:none!important;box-shadow:none!important;accent-color:var(--accent,#7c5cff);touch-action:none;cursor:pointer}' +
      '.cnt input[type=range]::-webkit-slider-thumb{width:26px;height:26px}.cnt .v{min-width:44px;text-align:center;font-weight:700;font-size:18px}' }));
    const v = h('span', { class: 'v', 'aria-live': 'polite' });
    const r = h('input', { type: 'range', min: o.min, max: o.max, step: 1, 'aria-label': o.label || '인원' });
    const paint = (n) => { v.textContent = n + (o.unit || '명'); r.value = n; r.title = n + (o.unit || '명'); };
    const clamp = (n) => Math.max(o.min, Math.min(o.max, n | 0));
    r.addEventListener('input', () => { const n = clamp(+r.value); paint(n); if (o.onInput) o.onInput(n); });
    r.addEventListener('change', () => o.onSet(clamp(+r.value)));
    const box = h('div', { class: 'cnt' },
      h('button', { class: 'btn sm', text: '−', 'aria-label': (o.label || '인원') + ' 줄이기', onclick() { o.onSet(clamp(o.get() - 1)); } }),
      r,
      h('button', { class: 'btn sm', text: '+', 'aria-label': (o.label || '인원') + ' 늘리기', onclick() { o.onSet(clamp(o.get() + 1)); } }),
      v);
    box.sync = (n, max, min) => { if (max != null) { o.max = max; r.max = max; } if (min != null) { o.min = min; r.min = min; } paint(n); };
    if (o.max - o.min <= 0) r.disabled = true;
    box.sync(o.get());
    return box;
  }
  // 다시 그려도 스크롤 위치가 그대로이도록: node와 그 위 스크롤 상자들의 scrollTop을 기억했다가 되돌림
  function keepScroll(node, fn) {
    const sv = []; for (let e = node; e && e !== document.documentElement; e = e.parentElement) if (e.scrollTop) sv.push([e, e.scrollTop]);
    const wy = window.scrollY, hgt = node && node.offsetHeight;
    if (node && hgt) node.style.minHeight = hgt + 'px';   // 비웠다 채우는 사이 높이가 줄어 스크롤이 당겨지는 것 방지
    try { fn(); } finally {
      if (node) node.style.minHeight = '';
      sv.forEach(([e, t]) => { e.scrollTop = t; });
      if (window.scrollY !== wy) window.scrollTo(0, wy);
    }
  }

  /* ---------- game browser: 홈 목록 + 온라인 방 「게임 고르기」 (검색 · 인원 · 방식 · 분류 · 정렬 · 보기) ---------- */
  const catOf = (id) => HOME_CAT[id] || L.games[id].cat || CAT[id] || '기타';
  const rangeOf = (g) => (g.minPlayers === g.maxPlayers ? g.minPlayers + '인' : g.minPlayers + '–' + g.maxPlayers + '인');
  const normK = (t) => (t || '').toLowerCase().replace(/[\s·:,.!?()\-]+/g, '');
  // 초성 검색: 「ㅂㅌㄹ」 → 배틀로얄
  const CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ';
  const choOf = (t) => [...t].map((c) => { const k = c.charCodeAt(0) - 0xac00; return k >= 0 && k < 11172 ? CHO[Math.floor(k / 588)] : c; }).join('');
  const isCho = (q) => /^[ㄱ-ㅎ]+$/.test(q);
  const hit = (text, q) => { const n = normK(text); return !!q && (n.includes(q) || (isCho(q) && choOf(n).includes(q))); };
  const isCoop = (g) => !!(g.coop || /협동|협력/.test(g.name + ' ' + (g.tag || '')) || (g.options || []).some((o) => o.choices.some((c) => /협동/.test(String(c.label)))));
  const KINDS = [
    { v: 'pass', label: '한 폰 돌려하기', test: (g) => g.maxPlayers >= 2 && (!g.realtime || !!g.localMulti) },
    { v: 'rt', label: '실시간', test: (g) => !!(g.realtime || g.realtimeIf) },
    { v: 'turn', label: '차례대로', test: (g) => !g.realtime },
    { v: 'coop', label: '협동', test: isCoop },
  ];
  const SORTS = [{ v: 'cat', label: '분류별' }, { v: 'name', label: '이름순' }, { v: 'new', label: '새로 나온 순' }, { v: 'many', label: '인원 많은 순' }];
  const PEOPLE = [1, 2, 3, 4, 5];
  // 지금 n명이 할 수 있나: 사람 n명 ≤ 최대 인원, 사람만 하는 게임(noAI)은 최소 인원도 채워야 함(나머지 자리는 AI)
  const fitsPeople = (g, n) => n <= g.maxPlayers && (!g.noAI || n >= g.minPlayers);
  const homeSess = { people: 0, kind: '' };   // 인원·방식 필터는 앱을 켜 둔 동안만 기억(다음 실행 땐 전체 목록부터)
  let homeIO = null;
  const SVG_GRID = '<svg viewBox="0 0 20 20" aria-hidden="true"><g fill="currentColor"><rect x="2" y="2" width="7" height="7" rx="1.5"/><rect x="11" y="2" width="7" height="7" rx="1.5"/><rect x="2" y="11" width="7" height="7" rx="1.5"/><rect x="11" y="11" width="7" height="7" rx="1.5"/></g></svg>';
  const SVG_LIST = '<svg viewBox="0 0 20 20" aria-hidden="true"><g fill="currentColor"><rect x="2" y="3" width="4" height="4" rx="1"/><rect x="8" y="4" width="10" height="2" rx="1"/><rect x="2" y="8" width="4" height="4" rx="1"/><rect x="8" y="9" width="10" height="2" rx="1"/><rect x="2" y="13" width="4" height="4" rx="1"/><rect x="8" y="14" width="10" height="2" rx="1"/></g></svg>';

  /* cfg: { st:{cat,people,kind,sort,view,q}, save(st), onPick(id), fits(g)→bool (false = 흐리게), current, fold:Set, saveFold(), scroller(), views:bool, ioOut(io) } */
  function gameBrowser(cfg) {
    const st = cfg.st;
    const favs = () => store.get('favs', []).filter((id) => L.games[id]);
    const groups = {};
    const idx = {};
    L.order.forEach((id, i) => { idx[id] = i; const c = catOf(id); (groups[c] = groups[c] || []).push(id); });
    const cats = CAT_ORDER.concat(Object.keys(groups).filter((c) => !CAT_ORDER.includes(c))).filter((c) => groups[c]);
    if (st.cat !== '전체' && st.cat !== '즐겨찾기' && !groups[st.cat]) st.cat = '전체';
    const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) { io.unobserve(e.target); fillIcon(e.target); }
    }), { rootMargin: '400px 0px' }) : null;
    if (cfg.ioOut) cfg.ioOut(io);
    function fillIcon(s) { const id = s.getAttribute('data-icon'); if (id) { s.removeAttribute('data-icon'); s.innerHTML = (L.games[id] && L.games[id].icon) || ICON[id] || '<circle cx="28" cy="28" r="18" fill="currentColor"/>'; } }
    function lazyIcon(id) {   // 아이콘 SVG는 화면 근처에 올 때만 그린다(130개 첫 표시를 가볍게)
      const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 56 56'); s.setAttribute('class', 'ico'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('data-icon', id);
      if (io) io.observe(s); else fillIcon(s);
      return s;
    }
    function pills(g) {
      return [g.pcOnly ? h('span', { class: 'kp', style: { color: touchOnly() ? '#ee8a6a' : 'var(--muted)' }, text: 'PC 전용' }) : null, g.realtime ? h('span', { class: 'kp rt', text: '실시간' }) : null, isCoop(g) ? h('span', { class: 'kp co', text: '협동' }) : null];
    }
    const cache = new Map();   // 타일/줄은 한 번만 만들고 다시 쓴다(검색 입력마다 새로 만들지 않음)
    function item(id, view) {
      const k = view + ':' + id;
      let el = cache.get(k);
      if (el) return el;
      const g = L.games[id], isNew = NEW_GAMES.includes(id);
      const tag = (g.tag || '').replace(g.realtime ? /^실시간\s*/ : /^$/, '').replace(isCoop(g) ? /^협동\s*/ : /^$/, '');
      if (view === 'grid') {
        el = h('button', { class: 'tile' + (isNew ? ' has-new' : ''), type: 'button', style: { '--tint': g.tint || TINT[id] || 'var(--surface)' }, 'aria-label': g.name + ' — ' + rangeOf(g) + (g.tag ? ', ' + g.tag : '') },
          h('div', { class: 'tg' }, pills(g), h('span', { text: rangeOf(g) + (tag ? ' · ' + tag : '') })),
          lazyIcon(id), h('div', { class: 'nm', text: g.name }),
          isNew ? h('span', { class: 'badge-new', text: 'NEW' }) : null,
          h('span', { class: 'badge-fav', 'aria-hidden': 'true', text: '★' }));
      } else {
        el = h('button', { class: 'gamerow', type: 'button', style: { '--tint': g.tint || TINT[id] || 'var(--surface-2)' }, 'aria-label': g.name + ' — ' + rangeOf(g) + (g.tag ? ', ' + g.tag : '') },
          lazyIcon(id),
          h('span', { class: 'gr-main' },
            h('span', { class: 'gr-nm' }, h('span', { class: 'gr-t', text: g.name }), isNew ? h('span', { class: 'nb', text: 'NEW' }) : null),
            h('span', { class: 'gr-meta' }, h('span', { class: 'rg', text: rangeOf(g) }), h('span', { class: 'gr-over', text: '인원 안 맞음' }), pills(g),
              h('span', { class: 'bl', text: g.blurb || g.tag || '' }))),
          h('span', { class: 'gr-fav', 'aria-hidden': 'true', text: '★' }));
      }
      el.dataset.id = id;
      cache.set(k, el);
      return el;
    }
    function pass(id, q) {
      const g = L.games[id];
      if (st.people && !fitsPeople(g, st.people)) return false;
      if (st.kind) { const k = KINDS.find((x) => x.v === st.kind); if (k && !k.test(g)) return false; }
      if (q && !(hit(g.name, q) || hit(g.tag, q) || hit(g.blurb, q) || normK(catOf(id)) === q || hit(id, q))) return false;
      return true;
    }
    function sorted(ids, q) {
      const a = ids.slice(), nm = (id) => L.games[id].name;
      if (st.sort === 'name') a.sort((x, y) => nm(x).localeCompare(nm(y), 'ko'));
      else if (st.sort === 'new') a.sort((x, y) => (NEW_GAMES.includes(y) - NEW_GAMES.includes(x)) || idx[y] - idx[x]);
      else if (st.sort === 'many') a.sort((x, y) => L.games[y].maxPlayers - L.games[x].maxPlayers || L.games[x].minPlayers - L.games[y].minPlayers || nm(x).localeCompare(nm(y), 'ko'));
      else if (q) {   // 분류별 + 검색: 이름이 검색어로 시작 → 이름에 포함 → 소개에만 있음
        const rank = (id) => { const n = normK(nm(id)), c = isCho(q) ? choOf(n) : n; return c.startsWith(q) ? 0 : c.includes(q) ? 1 : 2; };
        a.sort((x, y) => rank(x) - rank(y) || cats.indexOf(catOf(x)) - cats.indexOf(catOf(y)) || idx[x] - idx[y]);
      }
      return a;
    }

    /* ----- 위쪽 막대(검색 · 필터 · 보기 · 분류) ----- */
    const search = h('input', {
      class: 'home-search', type: 'search', placeholder: '게임 찾기 (' + L.order.length + '종)', 'aria-label': '게임 찾기', enterkeyhint: 'search', autocomplete: 'off',
      oninput(e) { st.q = e.target.value; schedule(true); },
      oncompositionupdate(e) { st.q = e.target.value; schedule(true); },   // 한글 입력 중(조합 중)에도 바로 찾기
      oncompositionend(e) { st.q = e.target.value; schedule(true); },
      onkeydown(e) { if (e.key === 'Enter') e.target.blur(); },
    });
    search.value = st.q || '';
    const fN = h('span', { class: 'fb-n', hidden: true });
    const fBtn = h('button', { class: 'btn fb-btn', type: 'button', 'aria-expanded': 'false', 'aria-label': '인원 · 방식 · 정렬', onclick() { setPanel(panel.hidden); Sfx.play('click'); } }, '필터', fN);
    const vBtn = cfg.views ? h('button', { class: 'btn fb-btn fb-view', type: 'button', onclick() {
      st.view = st.view === 'grid' ? 'list' : 'grid'; cfg.save(st); Sfx.play('click'); render(); } }) : null;
    function chipRow(label, items, cur, onTap) {
      return h('div', { class: 'fb-row', role: 'group', 'aria-label': label }, h('span', { class: 'fb-l', text: label }),
        h('div', { class: 'chips' }, items.map((it) => h('button', {
          class: 'btn sm' + (it.v === cur ? ' on' : ''), type: 'button', 'aria-pressed': String(it.v === cur), 'data-v': String(it.v), text: it.label,
          onclick() { onTap(it.v); Sfx.play('click'); },
        }))));
    }
    const panel = h('div', { class: 'fb-panel', hidden: true });
    function drawPanel() {
      panel.textContent = '';
      const big = st.people >= 5 ? st.people : 5;
      panel.append(
        chipRow('인원', PEOPLE.map((n) => ({ v: n === 5 ? big : n, label: n === 5 ? (st.people > 5 ? st.people + '명' : '5–8명') : n + '명' })), st.people,
          (v) => { st.people = st.people === v ? 0 : v; changed(); }),
        chipRow('방식', KINDS, st.kind, (v) => { st.kind = st.kind === v ? '' : v; changed(); }),
        chipRow('정렬', SORTS, st.sort, (v) => { st.sort = v; changed(); }));
    }
    let openTop = 0, quietUntil = 0;
    function setPanel(open) {
      panel.hidden = !open; fBtn.setAttribute('aria-expanded', String(open)); fBtn.classList.toggle('on', open);
      if (open) { drawPanel(); const sc = cfg.scroller && cfg.scroller(); openTop = sc ? sc.scrollTop : 0; quietUntil = performance.now() + 250; }
    }
    const catChips = h('div', { class: 'chips home-chips', role: 'group', 'aria-label': '분류' },
      ['전체', '즐겨찾기'].concat(cats).map((c) => h('button', {
        class: 'btn sm', type: 'button', 'data-f': c, text: c === '즐겨찾기' ? '★ 즐겨찾기' : c,
        onclick() { st.cat = c; Sfx.play('click'); changed(); },
      })));
    const sumTxt = h('span', { class: 'txt', 'aria-live': 'polite' });
    const sum = h('div', { class: 'fb-sum', hidden: true }, sumTxt,
      h('button', { class: 'btn sm fb-clear', type: 'button', text: '✕ 모두 지우기', onclick() {
        st.people = 0; st.kind = ''; st.q = ''; st.cat = '전체'; search.value = ''; Sfx.play('click'); changed();
      } }));
    const bar = h('div', { class: 'home-find' }, h('div', { class: 'fb-top' }, search, fBtn, vBtn), panel, catChips);   // 결과 요약(sum)은 막대 밖 — 작은 화면에서 붙어 다니는 높이를 줄임
    const list = h('div', { class: 'groups' });

    /* 길게 누르기(폰) · 오른쪽 클릭(PC) → 미리보기(cfg.onPreview가 있을 때만) */
    let lpT = 0, lpXY = null, lpFired = 0;
    if (cfg.onPreview) {
      const cancel = () => { clearTimeout(lpT); lpT = 0; };
      list.addEventListener('pointerdown', (e) => {
        const b = e.target.closest('[data-id]'); if (!b || e.button > 0) return;
        cancel(); lpXY = [e.clientX, e.clientY];
        lpT = setTimeout(() => { lpT = 0; lpFired = Date.now(); buzz(15); cfg.onPreview(b.dataset.id); }, 480);
      });
      list.addEventListener('pointermove', (e) => { if (lpT && lpXY && Math.hypot(e.clientX - lpXY[0], e.clientY - lpXY[1]) > 10) cancel(); });
      ['pointerup', 'pointercancel', 'pointerleave'].forEach((ev) => list.addEventListener(ev, cancel));
      list.addEventListener('scroll', cancel, true);
      list.addEventListener('contextmenu', (e) => {
        const b = e.target.closest('[data-id]'); if (!b) return;
        e.preventDefault(); cancel();
        if (Date.now() - lpFired > 700) cfg.onPreview(b.dataset.id);
      });
    }
    /* 목록 클릭(위임): 게임 고르기 / 분류 접기 */
    list.addEventListener('click', (e) => {
      if (lpFired && Date.now() - lpFired < 900) { lpFired = 0; e.preventDefault(); return; }
      const fh = e.target.closest('[data-fold]');
      if (fh) {
        const k = fh.getAttribute('data-fold'), open = cfg.fold.has(k);
        if (open) cfg.fold.delete(k); else cfg.fold.add(k);
        cfg.saveFold && cfg.saveFold();
        fh.setAttribute('aria-expanded', String(open)); fh.parentNode.classList.toggle('folded', !open);
        Sfx.play('click'); return;
      }
      const b = e.target.closest('[data-id]');
      if (b && !b.disabled) cfg.onPick(b.dataset.id);
    });

    function changed() { cfg.save(st); if (!panel.hidden) drawPanel(); schedule(false); }
    let raf = 0, keepScroll = true;
    function schedule(fromTyping) { if (!fromTyping) keepScroll = false; if (!raf) raf = requestAnimationFrame(() => { raf = 0; render(); }); }
    function render() {
      const q = normK(st.q);
      const fv = favs(), view = cfg.views ? st.view : 'list';
      if (vBtn) { vBtn.innerHTML = view === 'grid' ? SVG_LIST : SVG_GRID; vBtn.setAttribute('aria-label', view === 'grid' ? '촘촘한 목록으로 보기' : '큰 타일로 보기'); vBtn.title = vBtn.getAttribute('aria-label'); }
      catChips.querySelectorAll('.btn').forEach((b) => { const on = b.dataset.f === st.cat; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      const base = st.cat === '즐겨찾기' ? fv : st.cat === '전체' ? L.order : groups[st.cat] || [];
      const ids = base.filter((id) => pass(id, q));
      const nf = (st.people ? 1 : 0) + (st.kind ? 1 : 0) + (st.sort !== 'cat' ? 1 : 0);
      fN.hidden = !nf; fN.textContent = nf;
      const active = !!(st.people || st.kind || q || st.cat !== '전체');
      sum.hidden = !active;
      if (active) {
        const bits = [st.cat !== '전체' ? (st.cat === '즐겨찾기' ? '★' : st.cat) : null, st.people ? (st.people === 5 ? '5명 이상' : st.people + '명') : null,
          st.kind ? KINDS.find((k) => k.v === st.kind).label : null, q ? '“' + st.q.trim() + '”' : null].filter(Boolean);
        sumTxt.textContent = ''; sumTxt.append(h('b', { text: ids.length + '개' }), ' · ' + bits.join(' · '));
      }
      const frag = document.createDocumentFragment();
      function section(title, sids, foldKey) {
        if (!sids.length) return;
        const grid = h('div', { class: view === 'grid' ? 'tiles' : 'glist' });
        sids.forEach((id) => {
          const el = item(id, view);
          el.classList.toggle('is-fav', fv.includes(id));
          if (cfg.fits) { const ok = cfg.fits(L.games[id]); el.disabled = !ok; el.classList.toggle('on', id === cfg.current); }
          grid.append(el);
        });
        const folded = !!foldKey && cfg.fold.has(foldKey);
        const head = foldKey
          ? h('button', { class: 'group-h group-hb', type: 'button', 'data-fold': foldKey, 'aria-expanded': String(!folded) },
            h('span', { text: title }), h('span', { class: 'gh-n', text: sids.length }), h('span', { class: 'gh-chev', 'aria-hidden': 'true', text: '›' }))
          : h('h3', { class: 'group-h' }, h('span', { text: title }), h('span', { class: 'gh-n', text: sids.length }));
        frag.append(h('div', { class: 'group' + (folded ? ' folded' : '') + (foldKey === 'favs' ? ' favs' : '') }, head, grid));
      }
      if (!ids.length) {
        frag.append(h('div', { class: 'note empty' },
          h('p', { style: { margin: '0 0 10px' }, text: st.cat === '즐겨찾기' && !fv.length ? '게임 설정 화면의 ☆를 누르면 여기에 모여요.' : '조건에 맞는 게임이 없어요.' }),
          active ? h('button', { class: 'btn sm', type: 'button', text: '✕ 모두 지우기', onclick: () => sum.querySelector('.fb-clear').click() }) : null));
      } else if (st.sort === 'cat' && !q && st.cat !== '즐겨찾기') {
        if (st.cat === '전체') section('★ 즐겨찾기', fv.filter((id) => pass(id, q)), 'favs');
        cats.forEach((c) => { if (st.cat === '전체' || st.cat === c) section(c, ids.filter((id) => catOf(id) === c), 'c:' + c); });
      } else {
        const t = q ? '검색 결과' : st.cat === '즐겨찾기' ? '즐겨찾기' : SORTS.find((s) => s.v === st.sort).label;
        section(t, sorted(ids, q));
      }
      list.textContent = '';
      list.append(frag);
      // 필터를 바꿨으면 결과 맨 위가 보이게(막대 바로 아래부터)
      const sc = cfg.scroller && cfg.scroller();
      if (sc && !keepScroll) {
        const top = Math.max(0, (sum.hidden ? list : sum).offsetTop - bar.offsetHeight - 12);
        if (sc.scrollTop > top) sc.scrollTop = top;
        openTop = sc.scrollTop; quietUntil = performance.now() + 120;
      }
      keepScroll = true;
    }
    // 필터 칸을 연 채로 목록을 내리면 접는다(작은 화면에서 칸을 오래 차지하지 않게)
    function onScroll() {
      if (panel.hidden || performance.now() < quietUntil) return;
      const sc = cfg.scroller(); if (sc && Math.abs(sc.scrollTop - openTop) > 90) setPanel(false);
    }
    return { bar, sum, list, search, render, onScroll, setPanel, catChips };
  }

  Layout.onChange = () => {   // 가로↔세로 배치가 바뀌면 지금 메뉴 화면을 다시 그린다(게임 화면은 CSS로만)
    if (S) return;
    if (Net.role === 'h') renderHostLobby(); else if (Net.role === 'g') renderGuestLobby();
    else if (screenEl && screenEl.classList.contains('home')) homeScreen();
  };
  function homeScreen() {
    document.title = '한판 라운지';
    endSession();
    Net.leave();
    if (homeIO) homeIO.disconnect();
    const st = { cat: store.get('homeFilter', '전체'), people: homeSess.people, kind: homeSess.kind, q: '',
      sort: SORTS.some((s) => s.v === store.get('home.sort', 'cat')) ? store.get('home.sort', 'cat') : 'cat',
      view: store.get('home.view', 'grid') === 'list' ? 'list' : 'grid' };
    const fold = new Set(store.get('home.fold', []));
    let scrollEl = null;
    const B = gameBrowser({
      st, views: true, fold,
      save(s) { store.set('homeFilter', s.cat); store.set('home.sort', s.sort); store.set('home.view', s.view); homeSess.people = s.people; homeSess.kind = s.kind; },
      saveFold() { store.set('home.fold', [...fold]); },
      onPick: (id) => setupSheet(id, () => B.render()),
      onPreview: (id) => previewSheet(id, () => B.render()),
      scroller: () => scrollEl,
      ioOut: (io) => { homeIO = io; },
    });
    if (Layout.wide) { homeWide(B, (el) => { scrollEl = el; }); return; }
    scrollEl = h('div', { class: 'scroll', onscroll: () => B.onScroll() },
      h('div', { class: 'brand' },
        h('h1', { html: '한판<span>.</span>라운지' }),
        h('p', { text: '한 폰으로 돌려하거나, 방을 만들어 각자 폰으로.' })),
      h('div', { class: 'online-bar' },
        h('button', { class: 'btn primary', text: '온라인 방 만들기', onclick: () => hostLobby() }),
        h('button', { class: 'btn', text: '코드로 참가', onclick: () => joinScreen() })),
      L.STANDALONE && window.RTCPeerConnection ? h('div', { class: 'online-bar lan' },
        h('button', { class: 'btn', text: 'LAN 방 만들기', onclick: () => hostLobby(false, true) }),
        h('button', { class: 'btn', text: 'LAN 참가', onclick: () => lanJoinScreen() }),
        h('p', { class: 'note', text: '같은 와이파이에서 인터넷 없이 QR로 연결해요.' })) : null,
      h('div', { class: 'section-h' }, h('span', { class: 'label', text: window.LOUNGE_DESKTOP ? '이 PC에서 바로 하기' : '이 폰에서 바로 하기' }),
        h('button', { class: 'btn ghost sm', text: '⚙ 설정', onclick: () => settingsSheet(() => homeScreen()) })),
      B.bar, B.sum, B.list);
    const scr = h('div', { class: 'screen home' }, scrollEl);
    B.render();
    show(scr);
  }
  /* 가로 배치 홈(라운드 48): 왼쪽 막대(로고·온라인·분류·설정) + 오른쪽(검색·최근·게임 격자) */
  const Recent = {
    get() { return store.get('recent', []).filter((id) => L.games[id]); },
    add(id) { store.set('recent', [id].concat(Recent.get().filter((x) => x !== id)).slice(0, 10)); },
  };
  function miniCard(id) {
    const g = L.games[id];
    return h('button', { class: 'mini-card', type: 'button', style: { '--tint': g.tint || TINT[id] || 'var(--surface)' }, 'aria-label': g.name, title: g.name,
      onclick: () => setupSheet(id, () => homeScreen()) }, svgIcon(id), h('span', { class: 'nm', text: g.name }));
  }
  function homeWide(B, setScroll) {
    const side = h('aside', { class: 'home-side' },
      h('div', { class: 'brand' }, h('h1', { html: '한판<span>.</span>라운지' }), h('p', { text: L.order.length + '종 · 혼자, 돌려서, 방에서' })),
      h('div', { class: 'side-btns' },
        h('button', { class: 'btn primary', text: '온라인 방 만들기', onclick: () => hostLobby() }),
        h('button', { class: 'btn', text: '코드로 참가', onclick: () => joinScreen() }),
        L.STANDALONE && window.RTCPeerConnection ? h('button', { class: 'btn', text: 'LAN 방 만들기', onclick: () => hostLobby(false, true) }) : null,
        L.STANDALONE && window.RTCPeerConnection ? h('button', { class: 'btn', text: 'LAN 참가', onclick: () => lanJoinScreen() }) : null),
      h('span', { class: 'label side-l', text: '분류' }),
      B.catChips,
      h('div', { class: 'grow' }),
      h('button', { class: 'btn ghost', text: '⚙ 설정', onclick: () => settingsSheet(() => homeScreen()) }));
    const rec = Recent.get(), fv = store.get('favs', []).filter((id) => L.games[id] && !rec.includes(id));
    const strip = rec.length || fv.length ? h('div', { class: 'home-strip' },
      rec.length ? h('div', { class: 'strip-g' }, h('span', { class: 'label', text: '최근에 한 게임' }), h('div', { class: 'strip-row' }, rec.slice(0, 8).map(miniCard))) : null,
      fv.length ? h('div', { class: 'strip-g' }, h('span', { class: 'label', text: '★ 즐겨찾기' }), h('div', { class: 'strip-row' }, fv.slice(0, 8).map(miniCard))) : null) : null;
    const main = h('div', { class: 'scroll home-main', onscroll: () => B.onScroll() }, B.bar, strip, B.sum, B.list);
    setScroll(main);
    const scr = h('div', { class: 'screen home home-wide' }, side, main);
    B.render();
    show(scr);
  }
  /* 가로 배치에서 두 칸으로 나누기(좁은 화면이면 그대로 차례로) */
  function cols(left, right, cls) {
    const flat = (a) => a.filter(Boolean);
    if (!Layout.wide) return flat(left.concat(right));
    return [h('div', { class: 'wcols' + (cls ? ' ' + cls : '') }, h('div', { class: 'wcol' }, flat(left)), h('div', { class: 'wcol' }, flat(right)))];
  }
  /* ---------- 게임 미리보기(라운드 27): 홈에서 길게 누르기 / 오른쪽 클릭 ----------
     def.time: '5–10분' 같은 예상 시간(없으면 분류로 짐작). def.preview(canvas): 대표 장면을 그리는 선택 훅(없으면 아이콘 표지). */
  const TIME_BY_CAT = { 카드: '10–20분', 보드: '15–30분', 전략: '20–40분', 퍼즐: '5–15분', 협동: '15–30분', 스포츠: '3–8분', 아케이드: '3–10분', 파티: '10–20분' };
  const timeOf = (id) => L.games[id].time || TIME_BY_CAT[catOf(id)] || '10–20분';
  L.timeOf = timeOf;
  function previewSheet(id, onHomeChange) {
    const g = L.games[id];
    const tint = g.tint || TINT[id] || 'var(--surface-2)';
    const cover = h('div', { class: 'pv-cover', style: { '--tint': tint } });
    let drawn = false;
    if (typeof g.preview === 'function') {
      const cv = h('canvas', { width: 640, height: 360, 'aria-hidden': 'true' });
      try { g.preview(cv); drawn = true; cover.append(cv); } catch (e) { console.warn('preview', e); }
    }
    if (!drawn) { const a = svgIcon(id), b = svgIcon(id); b.classList.add('pv-ic2'); cover.append(b, a); }
    const rt = !!(g.realtime || (g.realtimeIf && g.realtimeIf(optDefaults(g, null))));
    const modes = [rt ? '⚡ 실시간' : '⏳ 턴제', isCoop(g) ? '🤝 협동' : null, g.noAI ? '사람끼리만' : 'AI와 가능',
      g.hidden ? '🙈 가림막' : null].filter(Boolean);
    const close = () => o.remove();
    const o = overlay(h('div', { class: 'sheet pv-sheet', role: 'dialog', 'aria-label': g.name + ' 미리보기' },
      cover,
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap', alignItems: 'flex-start' } },
        h('div', { style: { minWidth: 0 } }, h('span', { class: 'label', text: catOf(id) + (g.tag ? ' · ' + g.tag : '') }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      g.blurb ? h('p', { class: 'muted', style: { margin: 0 }, text: g.blurb }) : null,
      h('div', { class: 'pv-facts' }, h('span', { text: '👥 ' + rangeOf(g) }), h('span', { text: '⏱ ' + timeOf(id) }), modes.map((m) => h('span', { text: m }))),
      h('div', { class: 'pv-btns' },
        h('button', { class: 'btn primary', text: '시작', onclick() { close(); setupSheet(id, onHomeChange); } }),
        h('button', { class: 'btn', text: '규칙', onclick: () => rulesSheet(id) }),
        g.codex ? h('button', { class: 'btn', text: '📖 도감', onclick: () => codexSheet(id) }) : null)), { cls: 'rules-ov pv-ov' });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.preview = previewSheet;
  function svgIcon(id) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 56 56'); s.setAttribute('class', 'ico'); s.setAttribute('aria-hidden', 'true');
    s.innerHTML = (L.games[id] && L.games[id].icon) || ICON[id] || '<circle cx="28" cy="28" r="18" fill="currentColor"/>';
    return s;
  }

  /* ---------- local setup ---------- */
  function setupSheet(id, onHomeChange) {
    const g = L.games[id];
    const favBtn = h('button', {
      class: 'iconbtn fav', 'aria-label': '즐겨찾기', 'aria-pressed': String(store.get('favs', []).includes(id)),
      text: store.get('favs', []).includes(id) ? '★' : '☆',
      onclick() {
        const f = store.get('favs', []); const on = !f.includes(id);
        store.set('favs', on ? f.concat(id) : f.filter((x) => x !== id));
        favBtn.textContent = on ? '★' : '☆'; favBtn.setAttribute('aria-pressed', String(on));
        toast(on ? '즐겨찾기에 넣었어요' : '즐겨찾기에서 뺐어요'); if (onHomeChange) onHomeChange();
      },
    });
    const saved = store.get('setup.' + id, null);
    let seats = saved && saved.length >= g.minPlayers && saved.length <= g.maxPlayers ? saved :
      Array.from({ length: g.defaultPlayers || g.minPlayers }, (_, i) => ({ name: i === 0 ? (myName() || '플레이어 1') : g.noAI ? '플레이어 ' + (i + 1) : 'AI ' + i, ai: !g.noAI && i !== 0 }));
    const list = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const countV = h('span', { class: 'v' });
    const opts = optDefaults(g, store.get('opts.' + id, null));
    while (seats.length > Math.max(g.minPlayers, maxFor(g, opts))) seats.pop();
    const optBox = h('div');
    // 옵션에 따라 실시간이 되는 게임: def.realtimeIf(opts) → 한 폰에 한 명(1번 = 나, 나머지 AI)
    const rtNow = () => !!(g.realtime || (g.realtimeIf && g.realtimeIf(opts)));
    const rtNote = h('p', { class: 'note', style: { margin: 0 }, text: '실시간 게임은 한 폰에 한 명만 할 수 있어요. 친구와 하려면 온라인 방이나 LAN 방을 쓰세요.' });
    const setCount = (n) => {
      n = Math.max(g.minPlayers, Math.min(maxFor(g, opts), n));
      while (seats.length > n) seats.pop();
      while (seats.length < n) { const i = seats.length; seats.push(g.noAI ? { name: '플레이어 ' + (i + 1), ai: false } : { name: 'AI ' + i, ai: true }); }
      draw();
    };
    const cntBox = countCtl({ min: g.minPlayers, max: maxFor(g, opts), get: () => seats.length, onSet: setCount, onInput: setCount, label: '인원' });
    function drawOpts() { keepScroll(optBox, () => drawOpts0()); }
    function drawOpts0() { optBox.innerHTML = ''; const r = optRows(g, opts, () => { while (seats.length > Math.max(g.minPlayers, maxFor(g, opts))) seats.pop(); drawOpts(); draw(); }); if (r) optBox.append(r); rtNote.hidden = !(rtNow() && !g.localMulti); }
    drawOpts();
    function draw() { keepScroll(list, draw0); }
    function draw0() {
      list.innerHTML = '';
      countV.textContent = seats.length;
      cntBox.sync(seats.length, maxFor(g, opts));
      const MANY = seats.length > 10;   // 자리가 많으면 9번째부터 AI는 한 줄로 묶어 보여 줌
      seats.forEach((s, i) => {
        if (MANY && i >= 8 && (rtNow() || s.ai) && !g.noAI) { s.ai = true; return; }
        const inp = h('input', { id: 'seat-' + i, value: s.name, maxlength: 10, 'aria-label': (i + 1) + '번 이름', oninput(e) { s.name = e.target.value; } });
        if (g.noAI) { // people only
          s.ai = false; if (/^AI \d$/.test(s.name)) s.name = '플레이어 ' + (i + 1);
          list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }), inp, h('span', { class: 'tag', text: '사람' })));
          return;
        }
        if (rtNow() && !g.localMulti) { // one driver per phone: seat 0 is you, the rest are AI
          s.ai = i !== 0;
          list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }), inp,
            i === 0 ? h('span', { class: 'tag me', text: '나' }) : lvChip(s.lv, (v) => { s.lv = v; draw(); })));
          return;
        }
        const seg = h('div', { class: 'seg' },
          h('button', { class: s.ai ? '' : 'on', text: '사람', onclick() { s.ai = false; if (/^AI \d$/.test(s.name)) s.name = '플레이어 ' + (i + 1); draw(); } }),
          h('button', { class: s.ai ? 'on' : '', text: 'AI', onclick() { s.ai = true; if (/^플레이어 \d$/.test(s.name)) s.name = 'AI ' + (i + 1); draw(); } }));
        list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }), inp,
          s.ai ? lvChip(s.lv, (v) => { s.lv = v; draw(); }) : null, seg));
      });
      if (!g.noAI) { const ais = seats.filter((x) => x.ai); const row = allLvRow(ais.map((x) => x.lv), (v) => { ais.forEach((x) => { x.lv = v; }); draw(); }); if (row) list.prepend(row); }
      if (MANY && !g.noAI) {
        const rest = seats.slice(8).filter((x) => x.ai);
        if (rest.length) list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[8] } }),
          h('span', { class: 'nm', style: { flex: 1 }, text: '그 밖의 AI ' + rest.length + '명' }),
          lvChip(rest[0].lv, (v) => { rest.forEach((x) => { x.lv = v; }); draw(); })));
      }
    }
    draw();
    const P = [
      h('div', { class: 'row', style: { justifyContent: 'space-between' } },
        h('h2', { text: g.name }),
        h('div', { class: 'row', style: { gap: '4px', flexWrap: 'nowrap' } },
          favBtn,
          g.codex ? h('button', { class: 'btn sm', text: '📖 도감', onclick: () => codexSheet(id) }) : null,
          h('button', { class: 'btn sm', text: '규칙 보기', onclick: () => rulesSheet(id) }),
          h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() }))),
      g.blurb ? h('p', { class: 'note', style: { margin: 0 }, text: g.blurb }) : null,
      (() => { const rs = Object.values(Best.all(id)); if (!rs.length) return null;
        return h('div', { class: 'best-box' }, h('b', { text: '🏆 내 최고 기록' }),
          h('div', { class: 'best-list' }, ...rs.slice(0, 12).map((r) => h('span', { class: 'best-chip' }, r.l + ' ', h('b', { text: Best.text(r) }))))); })(),
      g.controls && g.controls.length && showControlsBtn() ? h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, text: '⌨ 조작 설정 (키보드·패드)', onclick: () => controlsSheet(id) }) : null,
      g.aiNarration ? (() => { const b = h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' } });
        const paint = () => { const glob = store.get('ai.on', false) === true, v = AI.gameOn(id); b.classList.toggle('on', glob && v); b.setAttribute('aria-pressed', String(v));
          b.textContent = '🤖 AI 서술: ' + (!glob ? '꺼짐 (설정에서 켜기)' : v ? '이 게임 켬' : '이 게임 끔'); };
        b.onclick = () => { if (store.get('ai.on', false) !== true) { toast('설정 「🤖 AI 서술」에서 먼저 켜 주세요'); return; } AI.setGame(id, !AI.gameOn(id)); Sfx.play('click'); paint(); };
        paint(); return b; })() : null,
      g.minPlayers !== g.maxPlayers ? h('div', { class: 'field' },
        h('span', { class: 'label', text: '인원 (' + g.minPlayers + '–' + g.maxPlayers + '명)' }),
        cntBox) : null,
      resumeBox(id, (slot) => { o.remove(); resumeLocal(id, slot); }),
      list,
      optBox,
      rtNote,
      h('button', { class: 'btn primary block', text: '시작', onclick() {
        seats.forEach((s, i) => { s.name = (s.name || '').trim().slice(0, 10) || (s.ai ? 'AI ' + i : '플레이어 ' + (i + 1)); });
        store.set('setup.' + id, seats);
        store.set('opts.' + id, opts);
        o.remove();
        const ps = shuffleOrder(g, opts, seats.map((s, i) => ({ name: s.name, ai: !!s.ai, local: !s.ai, color: COLORS[i], lv: s.ai ? (s.lv || 2) : 0 })));
        startSession('local', id, ps, null, opts);
        if (ps !== seats && opts._order === 'rand') orderToast(ps);
      } })];
    // 가로 배치: 왼쪽 = 인원·옵션·조작, 오른쪽 = 미리보기·규칙 요약·기록·자리
    const o = overlay(Layout.wide ? h('div', { class: 'sheet setup-w' }, P[0],
      cols([P[5], P[8], P[9], P[3], P[4]], [setupPreview(id), P[1], P[2], P[6], h('span', { class: 'label', text: '자리' }), P[7]]), P[10])
      : h('div', { class: 'sheet' }, P));
  }
  function setupPreview(id) {
    const g = L.games[id];
    const cover = h('div', { class: 'pv-cover su-cover', style: { '--tint': g.tint || TINT[id] || 'var(--surface-2)' } });
    let drawn = false;
    if (typeof g.preview === 'function') { const cv = h('canvas', { width: 640, height: 360, 'aria-hidden': 'true' }); try { g.preview(cv); drawn = true; cover.append(cv); } catch (e) {} }
    if (!drawn) { const a = svgIcon(id), b = svgIcon(id); b.classList.add('pv-ic2'); cover.append(b, a); }
    const q = g.quick && g.quick.length ? g.quick : ((g.rules || [])[0] || {}).p || [];
    return h('div', { class: 'su-pv' }, cover,
      h('div', { class: 'pv-facts' }, h('span', { text: '👥 ' + rangeOf(g) }), h('span', { text: '⏱ ' + timeOf(id) }), h('span', { text: catOf(id) })),
      q.length ? h('ol', { class: 'quick su-quick' }, q.slice(0, 5).map((t) => h('li', { text: t }))) : null);
  }


  /* ---------- 라운드 44: 저장 · 이어하기 ----------
     def.save === true 인 게임. 슬롯: 게임별로 싱글('s', 로컬 판)과 멀티('m', 온라인 방장 기기)를 따로, 자동 1칸 + 수동 3칸.
     IndexedDB 'lounge-saves'(안 되면 localStorage)에 deflate 압축(L.wire.pack)으로 저장. 게스트 기기는 저장하지 않음.
     실시간 게임은 뷰가 saveState()/loadState(blob)를 주면 지원(없으면 저장 안 함). */
  const Saves = {
    SLOTS: ['auto', 1, 2, 3], db: null, mem: {},
    open() {
      if (Saves.db) return Saves.db;
      Saves.db = new Promise((res) => {
        try {
          const rq = indexedDB.open('lounge-saves', 1);
          rq.onupgradeneeded = () => { try { rq.result.createObjectStore('s'); } catch (e) {} };
          rq.onsuccess = () => res(rq.result); rq.onerror = () => res(null); rq.onblocked = () => res(null);
        } catch (e) { res(null); }
      });
      return Saves.db;
    },
    key: (id, kind, slot) => id + '|' + kind + '|' + slot,
    async put(k, v) {
      const db = await Saves.open();
      if (db) { try { await new Promise((res, rej) => { const t = db.transaction('s', 'readwrite'); t.objectStore('s').put(v, k); t.oncomplete = res; t.onerror = () => rej(t.error); }); return true; } catch (e) { console.warn(e); } }
      try { localStorage.setItem('lounge.save.' + k, JSON.stringify(v)); return true; } catch (e) { Saves.mem[k] = v; return true; }
    },
    async get(k) {
      const db = await Saves.open();
      if (db) { try { const v = await new Promise((res, rej) => { const rq = db.transaction('s').objectStore('s').get(k); rq.onsuccess = () => res(rq.result); rq.onerror = () => rej(rq.error); }); if (v) return v; } catch (e) {} }
      try { const r = localStorage.getItem('lounge.save.' + k); if (r) return JSON.parse(r); } catch (e) {}
      return Saves.mem[k] || null;
    },
    async del(k) {
      const db = await Saves.open();
      if (db) { try { await new Promise((res) => { const t = db.transaction('s', 'readwrite'); t.objectStore('s').delete(k); t.oncomplete = res; t.onerror = res; }); } catch (e) {} }
      try { localStorage.removeItem('lounge.save.' + k); } catch (e) {}
      delete Saves.mem[k];
    },
    async list(id, kind) {   // 메타만(상태는 풀지 않음)
      const out = [];
      for (const sl of Saves.SLOTS) { const v = await Saves.get(Saves.key(id, kind, sl)); if (v) out.push(Object.assign({ slot: sl }, v.meta)); }
      return out;
    },
    rt: (sess) => !!(sess.def.realtime || (sess.def.realtimeIf && sess.def.realtimeIf(sess.opts))),
    can(sess) {
      if (!sess || !sess.def.save || sess.mode === 'guest' || !sess.state) return false;
      return !Saves.rt(sess) || !!(sess.view && sess.view.saveState);
    },
    async save(slot, sess) {
      sess = sess || S;
      if (!Saves.can(sess) || sess.def.result(sess.state)) return false;
      let extra = null;
      if (sess.view && sess.view.saveState) { try { extra = sess.view.saveState(); } catch (e) { console.error(e); return false; } if (extra === false) return false; }
      const kind = sess.mode === 'local' ? 's' : 'm';
      const players = sess.players.map((p) => ({ name: String(p.name || '').replace(/\(AI\)$/, ''), ai: !!p.ai, lv: p.lv || 0, c: Math.max(0, COLORS.indexOf(p.color)), color: p.color }));
      const st = sess.state;
      let turn = null; try { turn = sess.def.saveLabel ? sess.def.saveLabel(st) : null; } catch (e) { turn = null; }
      const meta = { t: Date.now(), turn, ps: players.map((p) => (p.ai && !/^AI/.test(p.name) ? 'AI ' : '') + p.name).join(', ').slice(0, 120), n: players.length };
      const data = await L.wire.pack({ state: st, extra });
      return Saves.put(Saves.key(sess.gameId, kind, slot), { meta, players, opts: sess.opts, data, v: 1 });
    },
    async load(id, kind, slot) {
      const v = await Saves.get(Saves.key(id, kind, slot)); if (!v) return null;
      const d = await L.wire.unpack(v.data);
      return { meta: v.meta, players: v.players, opts: v.opts, state: d.state, extra: d.extra };
    },
    autoT: 0, rtIv: 0,
    touch() {   // 상태가 바뀔 때: 1.5초 모아 자동 칸에(실시간은 20초 주기가 따로 있음)
      if (!S || !Saves.can(S)) return;
      const sess = S;
      if (sess.def.result(sess.state)) { clearTimeout(Saves.autoT); Saves.del(Saves.key(sess.gameId, sess.mode === 'local' ? 's' : 'm', 'auto')); return; }
      if (Saves.rt(sess)) return;
      clearTimeout(Saves.autoT); Saves.autoT = setTimeout(() => { if (S === sess) Saves.save('auto', sess); }, 1500);
    },
    start() {
      clearInterval(Saves.rtIv);
      Saves.rtIv = setInterval(() => { if (S && Saves.can(S) && Saves.rt(S) && !Clock.paused) Saves.save('auto', S); }, 20000);
    },
  };
  L.saves = Saves;
  document.addEventListener('visibilitychange', () => { if (document.hidden && S && Saves.can(S)) Saves.save('auto', S); });
  const fmtT = (t) => { const d = new Date(t), z = (n) => String(n).padStart(2, '0'); return (d.getMonth() + 1) + '/' + d.getDate() + ' ' + z(d.getHours()) + ':' + z(d.getMinutes()); };
  const slotName = (sl) => (sl === 'auto' ? '자동 저장' : sl + '번 칸');
  function saveRow(m, onclick, extraBtn) {
    return h('div', { class: 'seat', style: { alignItems: 'center' } },
      h('button', { class: 'btn', style: { flex: 1, minHeight: '48px', textAlign: 'left', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: '2px', minWidth: 0 }, onclick },
        h('b', { text: slotName(m.slot) + (m.t ? ' · ' + fmtT(m.t) : '') + (m.turn ? ' · ' + m.turn : '') }),
        m.ps ? h('span', { class: 'muted', style: { fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: '100%' }, text: m.n + '명: ' + m.ps }) : h('span', { class: 'muted', style: { fontSize: '12px' }, text: '비어 있음' })),
      extraBtn || null);
  }
  // 「저장하고 나가기」: 수동 칸 고르기 → 저장 → then()
  function saveSheet(then) {
    if (!S || !Saves.can(S)) { if (then) then(); return; }
    const sess = S, kind = sess.mode === 'local' ? 's' : 'm';
    const box = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between' } }, h('h2', { text: '저장할 칸' }), h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() })),
      h('p', { class: 'note', style: { margin: 0 }, text: kind === 's' ? '혼자·한 폰 판 저장 칸이에요. 홈에서 이 게임을 누르면 「이어하기」가 보여요.' : '온라인 판은 방장 기기에만 저장돼요. 다음에 방을 열고 이 게임을 고르면 「저장된 판 이어하기」가 보여요.' }),
      box), { parent: sess.stage });
    Saves.list(sess.gameId, kind).then((ls) => {
      [1, 2, 3].forEach((sl) => {
        const m = ls.find((x) => x.slot === sl) || { slot: sl };
        box.append(saveRow(m, () => {
          const go = async () => { const ok = await Saves.save(sl, sess); o.remove(); toast(ok ? '💾 ' + slotName(sl) + '에 저장했어요' : '저장하지 못했어요'); if (ok) { clearTimeout(Saves.autoT); if (then) then(); } };
          if (m.t) confirmSheet(slotName(sl) + '에 덮어쓸까요?', '이전 저장(' + fmtT(m.t) + ')은 지워져요.', '덮어쓰기', go); else go();
        }));
      });
    });
  }
  // 싱글 이어하기 목록(게임 설정 화면 위)
  function resumeBox(id, onPick) {
    const box = h('div', { class: 'field', hidden: true });
    if (!L.games[id] || !L.games[id].save) return box;
    const fill = () => Saves.list(id, 's').then((ls) => {
      box.innerHTML = ''; box.hidden = !ls.length;
      if (!ls.length) return;
      box.append(h('span', { class: 'label', text: '💾 이어하기' }));
      ls.forEach((m) => box.append(saveRow(m, () => onPick(m.slot),
        h('button', { class: 'iconbtn', 'aria-label': slotName(m.slot) + ' 지우기', text: '🗑', onclick() { confirmSheet('저장을 지울까요?', slotName(m.slot) + ' · ' + fmtT(m.t), '지우기', () => { Saves.del(Saves.key(id, 's', m.slot)).then(fill); }); } }))));
    });
    fill();
    return box;
  }
  async function resumeLocal(id, slot) {
    const sv = await Saves.load(id, 's', slot).catch((e) => { console.error(e); return null; });
    if (!sv) { toast('저장을 불러오지 못했어요'); return; }
    const ps = sv.players.map((p, i) => ({ name: p.name, ai: !!p.ai, local: !p.ai, color: p.color || COLORS[p.c != null ? p.c : i], lv: p.ai ? (p.lv || 2) : 0 }));
    startSession('local', id, ps, sv.state, sv.opts);
    if (sv.extra != null && S && S.view && S.view.loadState) { try { S.view.loadState(sv.extra); } catch (e) { console.error(e); } }
    toast('💾 이어서 해요');
  }
  L.resumeLocal = resumeLocal;
  // 멀티 이어하기(방장 로비): 저장된 자리마다 방 사람 또는 AI를 정해 시작
  function resumeHostSheet(id) {
    Saves.list(id, 'm').then((ls) => {
      if (!ls.length) { toast('이 게임의 온라인 저장이 없어요'); return; }
      const o = overlay(h('div', { class: 'sheet' },
        h('div', { class: 'row', style: { justifyContent: 'space-between' } }, h('h2', { text: '💾 저장된 판 (온라인)' }), h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() })),
        ...ls.map((m) => saveRow(m, () => { o.remove(); resumeAssign(id, m.slot); }))));
    });
  }
  async function resumeAssign(id, slot) {
    const sv = await Saves.load(id, 'm', slot).catch(() => null);
    if (!sv) { toast('저장을 불러오지 못했어요'); return; }
    hostSeats();
    const people = Net.lobby.people || [];
    const used = new Set();
    // 기본: 이름이 같은 사람 → 그 자리, 남은 사람 자리는 남은 사람을 차례로, 그래도 비면 AI
    const asg = sv.players.map((p) => { if (p.ai) return -1; const k = people.findIndex((q, j) => !used.has(j) && q.n === p.name); if (k >= 0) { used.add(k); return k; } return null; });
    asg.forEach((a, i) => { if (a === null) { const k = people.findIndex((q, j) => !used.has(j)); if (k >= 0) { used.add(k); asg[i] = k; } else asg[i] = -1; } });
    const rows = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    function draw() {
      rows.innerHTML = '';
      sv.players.forEach((p, i) => {
        const sel = h('select', { 'aria-label': (i + 1) + '번 자리', style: { minHeight: '44px', flex: 1, minWidth: 0 }, onchange(e) { const v = +e.target.value; if (v >= 0) asg.forEach((x, j) => { if (j !== i && x === v) asg[j] = -1; }); asg[i] = v; draw(); } },
          h('option', { value: '-1', text: 'AI가 맡기' }),
          ...people.map((q, j) => h('option', { value: String(j), text: q.n + (j === 0 ? ' (나)' : '') })));
        sel.value = String(asg[i]);
        rows.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': p.color || COLORS[i] } }), h('span', { class: 'nm', style: { flex: 'none', maxWidth: '40%' }, text: (p.ai ? 'AI ' : '') + p.name }), sel));
      });
    }
    draw();
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between' } }, h('h2', { text: '자리 이어받기' }), h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() })),
      h('p', { class: 'note', style: { margin: 0 }, text: slotName(slot) + ' · ' + fmtT(sv.meta.t) + ' — 저장된 자리마다 이어받을 사람을 고르세요. 고르지 않은 자리는 AI가 맡아요.' }),
      rows,
      h('button', { class: 'btn primary block', text: '이어서 시작', onclick() { o.remove(); hostResume(id, sv, asg); } })));
  }
  function hostResume(id, sv, asg) {
    const people = Net.lobby.people || [], me = Net.myPeer();
    Net.lobby.game = id; Net.lobby.opts = sv.opts; Net.lobby.count = sv.players.length;
    Net.lobby.started = id;
    Net.lobby.rd = (Net.lobby.rd | 0) + 1; Net.voteLeft = 0; Net.myVote = null; Net.voteDone = -1;
    Net.lobby.seats = sv.players.map((p, i) => { const q = asg[i] >= 0 ? people[asg[i]] : null; const c = p.c != null ? p.c : i; return q ? { n: q.n, p: q.p, c } : { n: p.ai ? p.name : p.name + '(AI)', ai: true, lv: p.lv || 2, c }; });
    const players = Net.lobby.seats.map((s2) => ({ name: s2.n, ai: !!s2.ai, local: s2.p === me && !s2.ai, color: COLORS[s2.c], lv: s2.ai ? (s2.lv || 2) : 0 }));
    Net.pub({ role: 'h', name: myName(), lobby: Net.lobby, vcap: 1, votes: null });
    startSession('host', id, players, sv.state, sv.opts);
    if (sv.extra != null && S && S.view && S.view.loadState) { try { S.view.loadState(sv.extra); } catch (e) { console.error(e); } }
    Net.pubState();
    toast('💾 저장된 판을 이어서 해요');
  }
  L._resumeHost = (id, slot) => resumeAssign(id, slot);
  /* ---------- session (one running game) ---------- */
  let S = null;
  let wakeLock = null;
  async function keepAwake(on) {
    try {
      if (on && !wakeLock && navigator.wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
      if (!on && wakeLock) { const w = wakeLock; wakeLock = null; await w.release(); }
    } catch (e) { wakeLock = null; }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S) keepAwake(true); });
  function endSession() {
    if (Clock.paused) { Clock.resume(); if (S && S.mode === 'host') Net.pub({ pz: 0 }); }
    if (!S) return;
    (S.offs || []).forEach((f) => f());
    keepAwake(false);
    clearTimeout(S.aiTimer); Object.values(S.aiTimers).forEach(clearTimeout);
    try { S.view && S.view.destroy && S.view.destroy(); } catch (e) { console.error(e); }
    try { S.input && S.input.destroy(); } catch (e) {}
    if (S.def.landscape) Orient.exit();
    Music.stop(); Amb.stop();
    S = null;
  }
  L.session = () => S;


  /* ---------- AI 서술 (round 46): Claude API를 브라우저에서 직접 호출 ----------
     키는 이 기기 localStorage('lounge.ai.key')에만 저장, api.anthropic.com 외엔 보내지 않고 로그에 남기지 않는다.
     실패·거절·시간 초과·한도 초과·꺼짐 → null (게임은 자료 문장으로 대신). */
  const AI = (() => {
    const URL_ = 'https://api.anthropic.com/v1/messages';
    const MODELS = { fast: 'claude-haiku-5-5', quality: 'claude-sonnet-5-5' };
    const PRICE = { 'claude-haiku-5-5': [0.10, 0.50], 'claude-sonnet-5-5': [2, 10] };  // USD / 1M 토큰 (입력, 출력)
    const sess = { calls: 0, inTok: 0, outTok: 0, usd: 0, fail: 0 };
    const monthKey = () => { const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1); };
    function spend() { const s = store.get('ai.spend', null); return s && s.m === monthKey() ? s.usd : 0; }
    function addSpend(usd) { store.set('ai.spend', { m: monthKey(), usd: spend() + usd }); }
    const key = () => store.get('ai.key', '') || '';
    const budget = () => +store.get('ai.budget', 5) || 0;
    const mode = () => store.get('ai.mode', 'mix');  // mix | haiku | sonnet
    const on = () => store.get('ai.on', false) === true;
    // round 47: 게임별 켬/끔 — 'ai.off'에 꺼 둔 게임 id 목록(기본은 전부 켬). enabled() 인자 없으면 전역만 본다.
    const offList = () => { const v = store.get('ai.off', []); return Array.isArray(v) ? v : []; };
    function gameOn(gid) { return !gid || !offList().includes(gid); }
    function setGame(gid, v) { const a = offList().filter((x) => x !== gid); if (!v) a.push(gid); store.set('ai.off', a); try { window.dispatchEvent(new Event('lounge-ai')); } catch (e) {} }
    function enabled(gid) { return on() && (!!key() || typeof A._mock === 'function') && gameOn(gid); }
    function modelFor(tier) {
      const m = mode(); let t = m === 'haiku' ? 'fast' : m === 'sonnet' ? 'quality' : tier === 'quality' ? 'quality' : 'fast';
      if (t === 'quality' && budget() > 0 && spend() > budget() * 0.8) t = 'fast';  // 한도 80% 넘으면 품질 → 빠른 모델
      return MODELS[t];
    }
    function tally(model, u) {
      if (!u) return; const p = PRICE[model] || PRICE[MODELS.fast];
      const inT = (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) * 1.25 + (u.cache_read_input_tokens || 0) * 0.1, outT = u.output_tokens || 0;
      const usd = (inT * p[0] + outT * p[1]) / 1e6;
      sess.inTok += Math.round(inT); sess.outTok += outT; sess.usd += usd; addSpend(usd);
    }
    // 낮은 동시 실행(2개) 대기열
    let running = 0; const queue = [];
    function pump() { while (running < 2 && queue.length) { const j = queue.shift(); running++; j().finally(() => { running--; pump(); }); } }
    const enqueue = (fn) => new Promise((res) => { queue.push(() => fn().then(res, () => res(null))); pump(); });
    function parseJSON(t) {
      if (t == null) return null; if (typeof t === 'object') return t;
      const s = String(t), a = s.indexOf('{'), b = s.lastIndexOf('}');
      try { return JSON.parse(s); } catch (e) {} if (a >= 0 && b > a) { try { return JSON.parse(s.slice(a, b + 1)); } catch (e) {} } return null;
    }
    async function call(o, model, withFormat) {
      const body = { model, max_tokens: o.maxTokens || 400, messages: [{ role: 'user', content: o.prompt }], output_config: { effort: 'low' }, cache_control: { type: 'ephemeral' } };
      if (o.system) body.system = o.system;
      if (o.json && withFormat) body.output_config.format = { type: 'json_schema', schema: o.json };
      else if (o.json) body.messages[0].content = o.prompt + '\n\nJSON 객체 하나만 출력하세요. 설명 없이.';
      const stream = !o.json && typeof o.stream === 'function';
      if (stream) body.stream = true;
      const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), o.timeout || 15000);
      try {
        const r = await fetch(URL_, { method: 'POST', signal: ctl.signal, headers: { 'x-api-key': key(), 'anthropic-version': '2023-06-01', 'content-type': 'application/json', 'anthropic-dangerous-direct-browser-access': 'true' }, body: JSON.stringify(body) });
        if (!r.ok) { const err = await r.text().catch(() => ''); if (r.status === 400 && withFormat && o.json && /format|schema/i.test(err)) return call(o, model, false); A.lastError = 'HTTP ' + r.status; sess.fail++; return null; }
        if (!stream) {
          const j = await r.json(); tally(model, j.usage);
          if (j.stop_reason === 'refusal') { A.lastError = 'refusal'; return null; }
          const txt = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
          return o.json ? parseJSON(txt) : txt.trim() || null;
        }
        const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '', out = '', refused = false; const usage = {};
        for (;;) {
          const { done, value } = await rd.read(); if (done) break;
          buf += dec.decode(value, { stream: true }); let i;
          while ((i = buf.indexOf('\n')) >= 0) {
            const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
            if (!line.startsWith('data:')) continue; let ev; try { ev = JSON.parse(line.slice(5)); } catch (e) { continue; }
            if (ev.type === 'message_start' && ev.message) Object.assign(usage, ev.message.usage || {});
            else if (ev.type === 'content_block_delta' && ev.delta && ev.delta.type === 'text_delta') { out += ev.delta.text; try { o.stream(out); } catch (e) {} }
            else if (ev.type === 'message_delta') { if (ev.usage) usage.output_tokens = ev.usage.output_tokens; if (ev.delta && ev.delta.stop_reason === 'refusal') refused = true; }
          }
        }
        tally(model, usage); if (refused) { A.lastError = 'refusal'; return null; }
        return out.trim() || null;
      } catch (e) { sess.fail++; A.lastError = e && e.name === 'AbortError' ? 'timeout' : 'network'; return null; }
      finally { clearTimeout(tm); }
    }
    function ask(o) {
      if (!enabled()) return Promise.resolve(null);
      if (budget() > 0 && spend() >= budget()) { A.lastError = 'budget'; return Promise.resolve(null); }
      const model = modelFor(o.tier);
      return enqueue(async () => {
        sess.calls++;
        if (typeof A._mock === 'function') {
          const r = await A._mock(Object.assign({ model }, o));
          if (r == null) return null;
          if (o.stream && typeof r === 'string') { for (let k = 1; k < r.length; k += 3) { o.stream(r.slice(0, k)); await new Promise((z) => setTimeout(z, 8)); } o.stream(r); }
          tally(model, { input_tokens: 300, output_tokens: 80 });
          return o.json ? parseJSON(r) : r;
        }
        return call(o, model, true);
      });
    }
    async function test() {
      if (!key() && typeof A._mock !== 'function') return '키가 없어요';
      const wasOn = on(); store.set('ai.on', true);
      const r = await ask({ tier: 'fast', prompt: '"연결됨"이라고만 답하세요.', maxTokens: 20 });
      if (!wasOn) store.set('ai.on', false);
      return r ? '성공 · ' + String(r).slice(0, 20) : '실패 (' + (A.lastError || '알 수 없음') + ')';
    }
    const A = { enabled, gameOn, setGame, games: () => L.order.filter((id) => L.games[id] && L.games[id].aiNarration), ask, test, spend, budget, mode, session: () => Object.assign({}, sess), models: MODELS, price: PRICE, parseJSON, _mock: null, lastError: '',
      tierModel: modelFor, setOn: (v) => { store.set('ai.on', !!v); try { window.dispatchEvent(new Event('lounge-ai')); } catch (e) {} } };
    return A;
  })();
  L.ai = AI;
  function aiBox(redraw) {
    const wrap = h('div', { class: 'field', style: { gap: '8px' } }, h('span', { class: 'label', text: '🤖 AI 서술 (Claude API · 대항해·던전 주인)' }));
    const row = (choices, cur, pick) => h('div', { class: 'chips wrap' }, choices.map((c) => h('button', { class: 'btn sm' + (c.v === cur ? ' on' : ''), text: c.label, onclick() { pick(c.v); Sfx.play('click'); redraw(); } })));
    wrap.append(row([{ v: true, label: '켬' }, { v: false, label: '끔' }], store.get('ai.on', false) === true, (v) => AI.setOn(v)));
    const k = store.get('ai.key', '');
    const inp = h('input', { type: 'password', autocomplete: 'off', placeholder: k ? '저장됨 (바꾸려면 새 키)' : 'API 키 (sk-ant-…)', 'aria-label': 'Claude API 키', style: { flex: '1 1 auto', minWidth: '0' },
      onchange(e) { const v = e.target.value.trim(); if (v) { store.set('ai.key', v); e.target.value = ''; toast('키를 이 기기에만 저장했어요'); redraw(); } } });
    wrap.append(h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '8px', alignItems: 'center' } }, inp,
      k ? h('button', { class: 'btn sm', style: { whiteSpace: 'nowrap', flex: '0 0 auto' }, text: '키 지우기', onclick() { store.set('ai.key', ''); toast('키를 지웠어요'); redraw(); } }) : null));
    wrap.append(h('span', { class: 'note', text: '모델' }), row([{ v: 'mix', label: '섞어 쓰기' }, { v: 'haiku', label: '모두 Haiku' }, { v: 'sonnet', label: '모두 Sonnet' }], AI.mode(), (v) => store.set('ai.mode', v)));
    wrap.append(h('span', { class: 'note', text: '월 한도 · 이번 달 약 $' + AI.spend().toFixed(3) + ' 사용' }), row([1, 2, 5, 10, 20].map((v) => ({ v, label: '$' + v })), AI.budget(), (v) => store.set('ai.budget', v)));
    const gl = AI.games();
    if (gl.length) wrap.append(h('span', { class: 'note', text: '게임별 사용' }), h('div', { class: 'chips wrap' }, gl.map((id) => {
      const v = AI.gameOn(id);
      return h('button', { class: 'btn sm' + (v ? ' on' : ''), 'aria-pressed': String(v), text: (v ? '✓ ' : '✕ ') + L.games[id].name, onclick() { AI.setGame(id, !v); Sfx.play('click'); redraw(); } });
    })));
    const res = h('span', { class: 'note', text: '' });
    wrap.append(h('div', { class: 'row', style: { gap: '8px', alignItems: 'center' } }, h('button', { class: 'btn sm', text: '연결 시험', async onclick() { res.textContent = '시험 중…'; res.textContent = await AI.test(); } }), res));
    wrap.append(h('p', { class: 'note', style: { margin: 0 }, text: '키는 이 기기에만 저장되고 Anthropic 외엔 보내지 않아요. 한도 80%가 넘으면 Sonnet 대신 Haiku, 한도에 닿으면 기본 문장으로 바뀌어요. 규칙·수치는 AI가 바꾸지 않아요.' }));
    return wrap;
  }
  /* ---------- settings (all platforms; PC client adds display options) ---------- */
  const Desk = window.loungeDesktop || null;   // preload bridge in the Electron client
  function settingsSheet(onClose) {
    const box = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '16px' } });
    let desk = null;
    function chipRow(label, choices, cur, pick) {
      return h('div', { class: 'field' }, h('span', { class: 'label', text: label }),
        h('div', { class: 'chips wrap' }, choices.map((c) => h('button', { class: 'btn sm' + (c.v === cur ? ' on' : ''), text: c.label,
          onclick() { pick(c.v); Sfx.play('click'); draw(); } }))));
    }
    let tab = '일반';
    function draw() {
      box.innerHTML = '';
      const items = [];
      const add = (g, el) => items.push([g, el]);
      const nm = h('input', { id: 'set-name', value: myName(), maxlength: 10, placeholder: '이름', 'aria-label': '내 이름',
        onchange(e) { const v = e.target.value.trim().slice(0, 10); if (v) { store.set('name', v); toast('이름을 바꿨어요'); } } });
      add('일반', h('div', { class: 'field' }, h('span', { class: 'label', text: '내 이름 (온라인에서 보여요)' }), nm));
      const pct = Math.round(UI.get() * 100);
      const fsV = h('b', { text: pct + '%' });
      const fsIn = h('input', { type: 'range', min: 80, max: 150, step: 5, value: pct, class: 'fs-range', 'aria-label': '글자 크기',
        oninput(e) { const v = +e.target.value / 100; fsV.textContent = e.target.value + '%'; UI.apply(v); },
        onchange(e) { store.set('ui.scale', +e.target.value / 100); UI.apply(+e.target.value / 100); } });
      add('일반', h('div', { class: 'field' }, h('span', { class: 'label' }, '글자 크기 · ', fsV),
        h('div', { class: 'row fs-row', style: { flexWrap: 'nowrap', gap: '8px' } },
          h('button', { class: 'btn sm', text: '가', 'aria-label': '글자 작게', onclick() { fsIn.value = Math.max(80, +fsIn.value - 5); fsIn.dispatchEvent(new Event('input')); fsIn.dispatchEvent(new Event('change')); } }),
          fsIn,
          h('button', { class: 'btn sm', style: { fontSize: '20px' }, text: '가', 'aria-label': '글자 크게', onclick() { fsIn.value = Math.min(150, +fsIn.value + 5); fsIn.dispatchEvent(new Event('input')); fsIn.dispatchEvent(new Event('change')); } }),
          h('button', { class: 'btn sm', text: '처음대로', onclick() { fsIn.value = 100; fsIn.dispatchEvent(new Event('input')); fsIn.dispatchEvent(new Event('change')); } }))));
      if (window.LOUNGE_DESKTOP || Math.max(screen.width || 0, screen.height || 0) >= 1000) {   // 라운드 48: 넓은 화면에서만 보임
        add('일반', chipRow('화면 방향 · 배치', [{ v: 'auto', label: '자동' }, { v: 'land', label: '가로' }, { v: 'port', label: '세로 (폰처럼)' }], Layout.pref(),
          (v) => { store.set('lay.mode', v); setTimeout(() => { Layout.check(true); o.remove(); settingsSheet(onClose); }, 0); }));
        add('일반', chipRow('UI 배율 (가로 배치의 메뉴 글자·버튼)', [{ v: 0, label: '자동' }, { v: 0.9, label: '90%' }, { v: 1, label: '100%' }, { v: 1.1, label: '110%' }, { v: 1.25, label: '125%' }, { v: 1.5, label: '150%' }, { v: 1.75, label: '175%' }, { v: 2, label: '200%' }],
          Layout.scalePref(), (v) => { store.set('lay.scale', v); UI.apply(UI.get()); }));
      }
      add('일반', chipRow('화면 테마', [{ v: 'dark', label: '다크' }, { v: 'light', label: '라이트' }, { v: 'hc', label: '고대비' }, { v: 'system', label: '기기 설정 따르기' }],
        Theme.pref(), (v) => { store.set('theme', v); Theme.apply(); }));
      add('소리', chipRow('소리', [{ v: true, label: '켬' }, { v: false, label: '끔' }], Sfx.on, (v) => { Sfx.on = v; store.set('sound', v); Music.vol(); }));
      add('게임 진행', chipRow('빠른 진행 (턴제 AI 차례·연출)', [1, 1.5, 2, 3].map((v) => ({ v, label: v + '×' })), +store.get('speed', 1) || 1, (v) => store.set('speed', v)));
      add('게임 진행', chipRow('무르기 버튼 (AI와 턴제)', [{ v: true, label: '켬' }, { v: false, label: '끔' }], store.get('undo', true), (v) => store.set('undo', v)));
      add('일반', chipRow('전환 효과 (시작·차례·라운드 알림 움직임)', [{ v: true, label: '켬' }, { v: false, label: '끔' }], store.get('anim', true) !== false, (v) => { store.set('anim', v); Anim.sync(); }));
      add('일반', chipRow('화면 흔들림·번쩍임', [{ v: 1, label: '보통' }, { v: 0.4, label: '약하게' }, { v: 0, label: '끔' }], store.get('fx', 1), (v) => store.set('fx', v)));
      const volCh = [0, 0.25, 0.5, 0.75, 1].map((v) => ({ v, label: v ? Math.round(v * 100) + '%' : '끔' }));
      add('소리', chipRow('효과음 크기', volCh, store.get('vol.sfx', 1), (v) => { store.set('vol.sfx', v); Sfx.play('click'); }));
      add('소리', chipRow('음악 크기', volCh, store.get('vol.music', 0.8), (v) => { store.set('vol.music', v); try { window.dispatchEvent(new Event('lounge-volume')); } catch (e) {} }));
      add('소리', chipRow('환경음 크기 (경기장·파도·라운지 등)', volCh, store.get('vol.amb', 0.5), (v) => { store.set('vol.amb', v); try { window.dispatchEvent(new Event('lounge-volume')); } catch (e) {} }));
      add('소리', chipRow('카드 게임 장소 (환경음)', AMB_PLACES, ambPlace(), (v) => {
        store.set('amb.place', v);
        if (S && catOf(S.gameId) === '카드' && S.def.ambient === undefined && !S.def.result(S.state || {})) Amb.start(S.gameId); else if (!S && v !== 'quiet' && Amb.level() > 0) { Amb.start(null, v); clearTimeout(Amb.prev); Amb.prev = setTimeout(() => { if (!S) Amb.stop(); }, 3500); }
      }));
      add('일반', chipRow('글자 대비 강화 (외곽선·그림자)', [{ v: true, label: '켬' }, { v: false, label: '끔' }], Contrast.on(), (v) => Contrast.set(v)));
      add('조작', chipRow('단축키 표시 (PC: 버튼에 [Esc]·[F1] 같은 키 배지)', [{ v: true, label: '켬' }, { v: false, label: '끔' }], store.get('showKeys', true) !== false, (v) => L.ui.setShowKeys(v)));
      add('조작', ctlRow());
      add('꾸미기', chipRow('카드 테이블 바닥', L.ui.felts().map((f) => ({ v: f.id, label: f.name })), L.ui.felt().id, (v) => L.ui.setFelt(v)));
      add('꾸미기', chipRow('카드 뒷면 (홀덤·블랙잭·고스톱·마작)', L.ui.cardBacks().map((f) => ({ v: f.id, label: f.name })), L.ui.cardBack().id, (v) => L.ui.setCardBack(v)));
      add('꾸미기', chipRow('보드 판 재질 (체스·바둑·오목)', L.ui.boards().map((f) => ({ v: f.id, label: f.name })), L.ui.board().id, (v) => L.ui.setBoard(v)));
      add('진동', hapticBox());
      add('AI 서술', aiBox(draw));
      if (Desk && desk) {
        add('PC 앱', chipRow('화면 모드 (PC)', [{ v: 'window', label: '창' }, { v: 'borderless', label: '테두리 없는 창' }, { v: 'fullscreen', label: '전체 화면' }],
          desk.mode, (v) => { desk.mode = v; Desk.setDisplay(v); }));
        add('PC 앱', chipRow('화면 크기 (글자·버튼)', [80, 90, 100, 110, 125, 150].map((z) => ({ v: z, label: z + '%' })),
          desk.zoom, (v) => { desk.zoom = v; Desk.setZoom(v); }));
        add('PC 앱', chipRow('가로 게임 창 크기', [{ v: true, label: '가로로 자동 바꾸기' }, { v: false, label: '그대로' }],
          desk.autoLandscape, (v) => { desk.autoLandscape = v; Desk.setAuto(v); }));
        add('PC 앱', h('div', { class: 'row', style: { gap: '8px' } },
          h('button', { class: 'btn sm', text: '창 크기 처음대로', onclick() { Desk.resetWindow(); toast('창 크기를 되돌렸어요'); } })));
        add('PC 앱', h('div', { class: 'field' }, h('span', { class: 'label', text: '단축키' }), shortcutList()));
        add('PC 앱', h('button', { class: 'btn danger block', text: '앱 끝내기', onclick() { confirmSheet('한판 라운지를 끝낼까요?', null, '끝내기', () => Desk.quit && Desk.quit()); } }));
      }
      if (!Desk && matchMedia('(pointer:fine)').matches) add('조작', h('div', { class: 'field' }, h('span', { class: 'label', text: '단축키' }), shortcutList()));
      add('ver', h('p', { class: 'note', style: { margin: 0 }, text: '버전 ' + (window.LOUNGE_BUILD || '개발판') + ' · 게임 ' + L.order.length + '종' }));
      if (!Layout.wide) { items.forEach(([, el]) => box.append(el)); return; }
      const names = [...new Set(items.map(([g]) => g).filter((g) => g !== 'ver'))];
      if (!names.includes(tab)) tab = names[0];
      box.append(h('div', { class: 'set-wide' },
        h('nav', { class: 'set-nav', 'aria-label': '설정 분류' }, names.map((n) => h('button', { class: 'btn' + (n === tab ? ' on' : ''), type: 'button', 'aria-pressed': String(n === tab), text: n,
          onclick() { tab = n; Sfx.play('click'); draw(); } })), h('div', { class: 'grow' }), items.filter(([g]) => g === 'ver').map(([, el]) => el)),
        h('div', { class: 'set-body' }, items.filter(([g]) => g === tab).map(([, el]) => el))));
    }
    function ctlRow() {
      const cur = Math.round(Ctl.get() * 100);
      const val = h('b', { text: cur + '%' });
      const inp = h('input', { type: 'range', min: 70, max: 150, step: 5, value: cur, style: { flex: '1 1 auto', minWidth: '0', height: '44px', accentColor: 'var(--brass)' }, 'aria-label': '조작 크기',
        oninput(e) { val.textContent = e.target.value + '%'; Ctl.apply(+e.target.value / 100); },
        onchange(e) { store.set('ui.ctl', +e.target.value / 100); Ctl.apply(+e.target.value / 100); } });
      return h('div', { class: 'field' }, h('span', { class: 'label' }, '조작 크기 (실시간 게임 버튼·조이스틱) · ', val),
        h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '8px', alignItems: 'center' } }, inp,
          h('button', { class: 'btn sm', text: '처음대로', onclick() { inp.value = 100; inp.dispatchEvent(new Event('input')); inp.dispatchEvent(new Event('change')); } })));
    }
    function hapSlider(key, label, kind) {
      const cur = Math.round(+store.get(key, 1) * 100);
      const val = h('b', { text: cur ? cur + '%' : '끔' });
      const inp = h('input', { type: 'range', min: 0, max: 200, step: 10, value: cur, style: { flex: '1 1 auto', minWidth: '0', height: '44px', accentColor: 'var(--brass)' }, 'aria-label': label + ' 진동 세기',
        oninput(e) { const v = +e.target.value; val.textContent = v ? v + '%' : '끔'; store.set(key, v / 100); },
        onchange() { L.haptic(kind); } });
      return h('div', { class: 'field hap-row' }, h('span', { class: 'label' }, label + ' · ', val),
        h('div', { class: 'row', style: { flexWrap: 'nowrap', gap: '8px', alignItems: 'center' } }, inp,
          h('button', { class: 'btn sm', style: { whiteSpace: 'nowrap', flex: '0 0 auto' }, text: '느껴보기', 'aria-label': label + ' 진동 미리 느껴보기', onclick() { if (!L.haptic(kind)) toast(L.hapticOK ? '진동이 꺼져 있어요' : '이 기기는 진동을 지원하지 않아요'); } })));
    }
    function hapticBox() {
      const wrap = h('div', { class: 'field' });
      if (store.get('buzz', true) === false) { store.set('buzz', true); store.set('hap.all', 0); }  // 옛 「끔」 → 전체 0%
      wrap.append(h('span', { class: 'label', text: '진동' }));
      if (!L.hapticOK) wrap.append(h('p', { class: 'note', style: { margin: 0 }, text: '이 기기(브라우저)는 진동을 지원하지 않아요. 설정은 저장되고, 진동되는 기기에서 적용돼요.' }));
      wrap.append(hapSlider('hap.all', '전체 세기', 'win'));
      const det = h('details', { class: 'hap-det' }, h('summary', { text: '종류별 세기', style: { minHeight: '44px', display: 'flex', alignItems: 'center', cursor: 'pointer' } }));
      HAP_KINDS.forEach(([k, label]) => det.append(hapSlider('hap.' + k, label, k)));
      wrap.append(det);
      return wrap;
    }
    const close = () => { o.remove(); if (onClose) onClose(); };
    const o = overlay(h('div', { class: 'sheet' + (Layout.wide ? ' set-sheet' : '') },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } }, h('h2', { text: '설정' }),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      box, h('button', { class: 'btn primary block', text: '닫기', onclick: close })), { cls: 'rules-ov' });
    draw();
    if (Desk) Desk.getSettings().then((d) => { desk = d; draw(); }).catch(() => {});
  }

  /* ---------- keyboard shortcuts ----------
     Esc  : 뒤로 — 맨 위 창 닫기(닫기/취소) → 안내 건너뛰기 → 게임·방 나가기(확인 창). 게임이 Esc를 썼으면(preventDefault) 무시.
     F1   : 규칙(게임 중) / 단축키 도움말(홈)       Ctrl+M : 소리 켜기/끄기      Ctrl+, : 설정
     (PC 앱: F11·Alt+Enter 전체 화면, Ctrl+= / Ctrl+- / Ctrl+0 화면 크기 — main.js) */
  const SHORTCUTS = [
    ['Esc', '뒤로 · 창 닫기 · 게임 나가기'], ['Enter', '확인 창에서 「예」'], ['F1', '게임 중: 지금 상황 도움말(→ 전체 규칙) · 홈: 이 도움말'],
    ['Ctrl + M', '소리 켜기/끄기'], ['Ctrl + ,', '설정 열기'],
  ];
  const DESK_SHORTCUTS = [['F11 · Alt + Enter', '전체 화면 ↔ 창'], ['Ctrl + = / Ctrl + -', '화면 크게 / 작게'], ['Ctrl + 0', '화면 크기 100%'], ['Alt + F4', '앱 끝내기']];
  function shortcutList() {
    const rows = SHORTCUTS.concat(Desk ? DESK_SHORTCUTS : []);
    return h('div', { class: 'keys-list' }, rows.map(([k, t]) => h('div', { class: 'keys-row' }, h('kbd', { text: k }), h('span', { text: t }))));
  }
  function shortcutSheet() {
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } }, h('h2', { text: '단축키' }),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() })),
      shortcutList(),
      h('p', { class: 'note', style: { margin: 0 }, text: '게임 조작 키(이동·발사 등)는 게임 설정 화면의 「⌨ 조작 설정」에서 바꿔요.' }),
      h('button', { class: 'btn primary block', text: '닫기', onclick: () => o.remove() })), { cls: 'rules-ov' });
  }
  function goBack() {
    const ovs = [...document.querySelectorAll('.overlay[data-core]')].filter((o) => !o.classList.contains('result'));
    const top = ovs[ovs.length - 1];
    if (top) {
      const btn = top.querySelector('[aria-label="닫기"]') || [...top.querySelectorAll('button')].find((b) => /^(취소|닫기|세로로 그냥 하기)$/.test(b.textContent.trim()));
      if (btn) btn.click();
      return;
    }
    const tut = document.querySelector('.tut-card');
    if (tut) { const b = [...tut.querySelectorAll('button')].find((x) => x.textContent.trim() === '건너뛰기'); if (b) b.click(); return; }
    const res = document.querySelector('.overlay.result');
    if (res) { const b = [...res.querySelectorAll('button')].find((x) => /다른 게임|로비로/.test(x.textContent)); if (b) b.click(); return; }
    if (S && S.stage && S.stage.isConnected) { gameMenu(); return; }   // 라운드 55: 게임 중 Esc = 게임 메뉴
    const back = document.querySelector('.topbar .iconbtn');   // 방/참가 화면: 뒤로
    if (back) back.click();
  }
  /* 오른쪽 클릭 = 취소(라운드 33, 턴제 게임 화면): def.onCancel(api) → 'lounge-cancel' 이벤트(preventDefault로 처리 표시) → 아무도 안 받으면 열린 창만 닫기.
     실시간 게임이나 def.contextMenu=true(오른쪽 클릭을 직접 쓰는 게임)는 양보. 게임 화면에서 브라우저 기본 메뉴는 막는다. */
  addEventListener('contextmenu', (e) => {
    if (!S || !S.stage || !(S.stage.contains(e.target) || (e.target.closest && e.target.closest('.overlay[data-core]')))) return;
    if (/^(INPUT|TEXTAREA)$/.test((e.target && e.target.tagName) || '')) return;
    e.preventDefault();
    const rt = S.def.realtime || (S.def.realtimeIf && S.def.realtimeIf(S.opts));
    if (rt || S.def.contextMenu) return;
    let done = false;
    try { if (S.def.onCancel) done = S.def.onCancel(S.api) !== false; } catch (err) { console.error(err); }
    if (!done) { const ev = new CustomEvent('lounge-cancel', { cancelable: true }); window.dispatchEvent(ev); done = ev.defaultPrevented; }
    if (done) return;
    const ov = [...document.querySelectorAll('.overlay[data-core]:not(.result)')].pop();
    if (ov) { const x = ov.querySelector('.iconbtn[aria-label="닫기"]'); if (x) x.click(); }
  }, true);
  addEventListener('keydown', (e) => {
    const t = (e.target && e.target.tagName) || '';
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(t);
    if (e.key === 'Escape') {
      if (typing) { e.target.blur(); return; }
      setTimeout(() => { if (!e.defaultPrevented) goBack(); }, 0);   // let the game consume Esc first (e.g. cancel a selection)
      return;
    }
    if (typing) return;
    if (e.key === 'F1') {
      e.preventDefault();
      if (S && !document.querySelector('.overlay[data-core]:not(.result)')) helpSheet(S.gameId, S.stage); else if (!S) shortcutSheet();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key === 'm' || e.key === 'M')) {
      e.preventDefault(); Sfx.on = !Sfx.on; store.set('sound', Sfx.on); toast(Sfx.on ? '소리 켜짐' : '소리 꺼짐');
      document.querySelectorAll('.topbar .iconbtn[aria-label="소리"]').forEach((b) => { b.textContent = Sfx.on ? '♪' : '♩'; });
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key === ',') {
      e.preventDefault();
      if (!document.querySelector('.overlay[data-core]:not(.result)')) settingsSheet(S ? null : () => homeScreen());
    }
  });
  L.goBack = goBack;
  /* 단축키 표시(라운드 42): PC(마우스·키보드)에서 단축키 있는 버튼 오른쪽 아래에 작은 키 배지. 터치 기기에선 숨김.
     DOM 버튼: data-key="KeyQ"(키 코드) 또는 data-action="<controls id>"(조작 설정에서 바꾼 키 반영) → core가 data-kb를 채워 CSS ::after로 그림.
     core 버튼(위쪽 막대·창 닫기·확인 창·결과 창·홈 설정)은 자동. 캔버스: L.ui.keyLabel(gameId, actionId) / L.ui.showKeys() / L.ui.drawKeyBadge(). 바뀌면 'lounge-keys'. */
  const KeyHints = {
    sawKey: false,
    pcEnv() { return !!window.LOUNGE_DESKTOP || this.sawKey || matchMedia('(pointer:fine)').matches; },
    on() { return store.get('showKeys', true) !== false && this.pcEnv(); },
    short(code) {
      if (!code) return '';
      const SH = { Escape: 'Esc', Space: 'Space', Enter: 'Enter', NumpadEnter: 'Enter', ShiftLeft: 'Shift', ShiftRight: 'Shift', ControlLeft: 'Ctrl', ControlRight: 'Ctrl', AltLeft: 'Alt', AltRight: 'Alt', Backspace: '⌫' };
      return SH[code] || (/^F\d+$/.test(code) ? code : keyLabel(code));
    },
    label(gameId, actionId) {
      const def = L.games && L.games[gameId] ? L.games[gameId] : (S && S.def && S.def.id === gameId ? S.def : null);
      if (!def || !def.controls) return '';
      const b = Controls.bindings(def).find((x) => x.id === actionId);
      return b && b.keys.length ? this.short(b.keys[0]) : '';
    },
    auto(el) {   // core가 그린 버튼의 단축키
      const al = el.getAttribute('aria-label') || '';
      const top = el.closest('.topbar');
      if (top) {
        if (el === top.querySelector('.iconbtn')) return 'Esc';
        if (al === '규칙 보기') return 'F1';
        if (al === '소리') return 'Ctrl+M';
        return '';
      }
      const ov = el.closest('.overlay[data-core]');
      if (ov) {
        const tx = el.textContent.trim();
        if (ov.classList.contains('result')) return /다른 게임|로비로/.test(tx) ? 'Esc' : '';
        const ovs = [...document.querySelectorAll('.overlay[data-core]:not(.result)')];
        if (ov !== ovs[ovs.length - 1]) return '';
        const close = ov.querySelector('[aria-label="닫기"]') || [...ov.querySelectorAll('button')].find((b) => /^(취소|닫기|세로로 그냥 하기)$/.test(b.textContent.trim()));
        if (el === close) return 'Esc';
        if (el.matches('.btn.danger') && el.parentElement && el.parentElement.querySelector('.btn.ghost')) return 'Enter';
        return '';
      }
      if (el.classList.contains('btn') && /⚙ 설정/.test(el.textContent) && !S) return 'Ctrl+,';
      return '';
    },
    scan() {
      this.raf = 0;
      const on = this.on();
      document.documentElement.classList.toggle('show-keys', on);
      if (!on) return;
      document.querySelectorAll('button, [data-key], [data-action]').forEach((el) => {
        let lb = '';
        const k = el.getAttribute('data-key'), a = el.getAttribute('data-action');
        if (k) lb = this.short(k);
        else if (a) lb = S ? this.label(S.gameId, a) : '';
        else if (el.tagName === 'BUTTON') lb = this.auto(el);
        if (lb) lb = String(lb).replace(/Space/g, '␣').replace(/Enter/g, '↵');   // 배지는 짧게(글자를 가리지 않게)
        if (lb) { if (el.getAttribute('data-kb') !== lb) el.setAttribute('data-kb', lb); if (getComputedStyle(el).position === 'static') el.style.position = 'relative'; }
        else if (el.hasAttribute('data-kb')) el.removeAttribute('data-kb');
      });
    },
    queue() { if (!this.raf) this.raf = requestAnimationFrame(() => this.scan()); },
    changed() { this.queue(); try { window.dispatchEvent(new CustomEvent('lounge-keys', { detail: { on: this.on() } })); } catch (e) {} },
  };
  L.ui.showKeys = () => KeyHints.on();
  L.ui.setShowKeys = (v) => { store.set('showKeys', !!v); KeyHints.changed(); };
  L.ui.keyLabel = (gameId, actionId) => (KeyHints.on() ? KeyHints.label(gameId, actionId) : '');
  L.ui.keyName = (code) => KeyHints.short(code);
  /* 캔버스 배지: (x, y) = 배지 오른쪽 아래 모서리. scale 기본 1(글자 10px). 표시 끔이거나 label 없으면 그리지 않음. */
  L.ui.drawKeyBadge = function (ctx, x, y, label, scale) {
    if (!label || !KeyHints.on()) return;
    const s = scale || 1, fs = 10 * s, pad = 3 * s, hh = fs + 4 * s;
    ctx.save(); ctx.font = '700 ' + fs + 'px ' + (getComputedStyle(document.documentElement).getPropertyValue('--f-mono').trim() || 'monospace');
    const w = Math.max(hh, ctx.measureText(label).width + pad * 2), x0 = x - w, y0 = y - hh, r = 4 * s;
    ctx.beginPath(); ctx.moveTo(x0 + r, y0); ctx.arcTo(x0 + w, y0, x0 + w, y0 + hh, r); ctx.arcTo(x0 + w, y0 + hh, x0, y0 + hh, r); ctx.arcTo(x0, y0 + hh, x0, y0, r); ctx.arcTo(x0, y0, x0 + w, y0, r); ctx.closePath();
    ctx.fillStyle = 'rgba(15,15,20,.78)'; ctx.fill(); ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = Math.max(1, s); ctx.stroke();
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(label, x0 + w / 2, y0 + hh / 2 + 0.5 * s);
    ctx.restore();
  };
  addEventListener('keydown', () => { if (!KeyHints.sawKey) { KeyHints.sawKey = true; if (!matchMedia('(pointer:fine)').matches) KeyHints.changed(); } }, true);
  try { matchMedia('(pointer:fine)').addEventListener('change', () => KeyHints.changed()); } catch (e) {}
  new MutationObserver(() => KeyHints.queue()).observe(document.documentElement, { childList: true, subtree: true });
  KeyHints.queue();

  /* ---------- landscape games: def.landscape = true ----------
     PC client: widens the window (unless the player turned it off). Android app: locks to landscape when the
     screen-orientation plugin is present. Browsers/PWA: tries screen.orientation.lock, else asks to rotate
     (with a 「세로로 그냥 하기」 escape — games must still render in portrait). */
  const Orient = {
    on: false, prompt: null, ok: false,
    plugin() { const c = window.Capacitor; return c && c.Plugins && c.Plugins.ScreenOrientation; },
    portrait() { return innerHeight > innerWidth; },
    enter() {
      this.on = true; this.ok = false;
      document.documentElement.classList.add('landscape-game');
      if (Desk) { Desk.landscape(true); return; }
      const pl = this.plugin();
      const lock = pl ? pl.lock({ orientation: 'landscape' }) : (screen.orientation && screen.orientation.lock ? screen.orientation.lock('landscape') : Promise.reject());
      Promise.resolve(lock).catch(() => {}).finally(() => setTimeout(() => this.check(), 350));
      addEventListener('resize', this.onResize);
    },
    onResize() { Orient.check(); },
    check() {
      if (!this.on) return;
      if (!this.portrait() || this.ok) { if (this.prompt) { this.prompt.remove(); this.prompt = null; } return; }
      if (this.prompt) return;
      this.prompt = overlay(h('div', { class: 'sheet rotate-hint' },
        h('div', { class: 'rot-ico', 'aria-hidden': 'true', text: '📱' }),
        h('h2', { text: '가로로 돌려 주세요' }),
        h('p', { class: 'note', style: { margin: 0 }, text: '이 게임은 가로 화면에서 더 크고 편하게 보여요. 화면 회전이 꺼져 있으면 알림창에서 켜 주세요.' }),
        h('button', { class: 'btn block', text: '세로로 그냥 하기', onclick: () => { this.ok = true; this.check(); } })), { cls: 'rotate-ov' });
    },
    exit() {
      if (!this.on) return;
      this.on = false;
      document.documentElement.classList.remove('landscape-game');
      removeEventListener('resize', this.onResize);
      if (this.prompt) { this.prompt.remove(); this.prompt = null; }
      if (Desk) { Desk.landscape(false); return; }
      const pl = this.plugin();
      try { if (pl) pl.lock({ orientation: 'portrait' }); else if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
    },
  };
  L.Orient = Orient;
  try { const pl = Orient.plugin(); if (pl) pl.lock({ orientation: 'portrait' }); } catch (e) {}

  /* ---------- first-play tutorial: def.tutorial = [{ text, sel? }] ---------- */
  function runTutorial(def, force, only) {   // only: optional array of steps to show (e.g. just the control steps later)
    if (!S || !(only || def.tutorial) || !(only || def.tutorial).length) return;
    const key = 'tut.' + def.id;
    if (!force && store.get(key, false)) return;
    if (!force && (!S.api.mySeats().length || S.mode !== 'local' || L.debug.noTut)) return;   // auto only for local play (online can't pause the host)
    const me = S, steps = only || def.tutorial;
    let i = 0, ring = null;
    me.paused = true;
    clearTimeout(me.aiTimer); Object.values(me.aiTimers).forEach(clearTimeout); me.aiTimers = {};   // stop AI moves already scheduled
    const txt = h('p', { class: 'tut-text' }), cnt = h('span', { class: 'label' });
    const next = h('button', { class: 'btn primary', onclick() { i++; if (i >= steps.length) done(); else draw(); } });
    const card = h('div', { class: 'tut-card', role: 'dialog', 'aria-label': '게임 안내' },
      h('div', { class: 'row', style: { justifyContent: 'space-between' } }, cnt,
        h('button', { class: 'btn ghost sm', text: '건너뛰기', onclick: () => done() })), txt,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px' } },
        h('button', { class: 'btn sm', text: '이전', onclick() { if (i > 0) { i--; draw(); } } }), next));
    const layer = h('div', { class: 'tut-layer' }, card);
    me.stage.appendChild(layer);
    function draw() {
      const st = steps[i];
      cnt.textContent = '안내 ' + (i + 1) + ' / ' + steps.length;
      txt.textContent = st.text; next.textContent = i === steps.length - 1 ? '시작!' : '다음';
      if (ring) { ring.remove(); ring = null; }
      const el = st.sel ? me.stage.querySelector(st.sel) : null;
      if (el) {
        const a = el.getBoundingClientRect(), b = me.stage.getBoundingClientRect();
        const L0 = Math.max(2, a.left - b.left - 6), T0 = Math.max(2, a.top - b.top - 6);   // keep the ring inside the stage
        const R0 = Math.min(b.width - 2, a.right - b.left + 6), B0 = Math.min(b.height - 2, a.bottom - b.top + 6);
        ring = h('div', { class: 'tut-ring', style: { left: L0 + 'px', top: T0 + 'px', width: Math.max(8, R0 - L0) + 'px', height: Math.max(8, B0 - T0) + 'px' } });
        layer.insertBefore(ring, card);
        const above = a.top - b.top, below = b.bottom - a.bottom;   // put the card on the side with more free room
        card.classList.toggle('top', above > below);
        card.classList.toggle('compact', a.height > b.height * 0.55);   // big target: small see-through card
      } else { card.classList.remove('top'); card.classList.remove('compact'); }
    }
    function done() { layer.remove(); if (!only) store.set(key, true); if (S === me) { me.paused = false; scheduleAI(); } }
    draw();
  }
  L.runTutorial = (force) => S && runTutorial(S.def, force);

  /* ---------- custom controls: keyboard + gamepad → game actions (PC client, BT keyboards) ----------
     A game declares  controls: [{ id, label, keys: ['ArrowLeft','KeyA'], pad: ['left','lx-'] }]
     and reads input via api.input: held(id), on((type, id) => …) → off, axis(negId, posId) → −1…1.
     Players rebind per game in 「조작 설정」(saved in localStorage 'keys.<gameId>'). */
  const PAD_BTN = ['a', 'b', 'x', 'y', 'lb', 'rb', 'lt', 'rt', 'back', 'start', 'ls', 'rs', 'up', 'down', 'left', 'right'];
  const PAD_AX = ['lx', 'ly', 'rx', 'ry'];
  const PAD_NAME = { a: 'Ⓐ', b: 'Ⓑ', x: 'Ⓧ', y: 'Ⓨ', lb: 'LB', rb: 'RB', lt: 'LT', rt: 'RT', back: '뒤로', start: '시작', ls: '왼스틱 누름', rs: '오른스틱 누름',
    up: '패드 ↑', down: '패드 ↓', left: '패드 ←', right: '패드 →', 'lx-': '왼스틱 ←', 'lx+': '왼스틱 →', 'ly-': '왼스틱 ↑', 'ly+': '왼스틱 ↓',
    'rx-': '오른스틱 ←', 'rx+': '오른스틱 →', 'ry-': '오른스틱 ↑', 'ry+': '오른스틱 ↓' };
  const KEY_NAME = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: '스페이스', Enter: 'Enter', ShiftLeft: '왼 Shift', ShiftRight: '오른 Shift',
    ControlLeft: '왼 Ctrl', ControlRight: '오른 Ctrl', AltLeft: '왼 Alt', AltRight: '오른 Alt', Tab: 'Tab', Backquote: '`', Minus: '-', Equal: '=', Comma: ',', Period: '.', Slash: '/',
    Semicolon: ';', Quote: "'", BracketLeft: '[', BracketRight: ']', Backslash: '\\' };
  const keyLabel = (c) => KEY_NAME[c] || c.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, '숫자패드 ');
  const Controls = {
    bindings(def) {
      const saved = store.get('keys.' + def.id, {});
      return (def.controls || []).map((c) => ({ id: c.id, label: c.label,
        keys: (saved[c.id] && saved[c.id].keys) || c.keys || [], pad: (saved[c.id] && saved[c.id].pad) || c.pad || [] }));
    },
    padState() {   // {name: value 0..1} of the first connected gamepad
      const out = {}; const gp = navigator.getGamepads ? [...navigator.getGamepads()].find((g) => g && g.connected) : null;
      if (!gp) return out;
      gp.buttons.forEach((b, i) => { if (PAD_BTN[i]) out[PAD_BTN[i]] = b.value || (b.pressed ? 1 : 0); });
      gp.axes.forEach((v, i) => { if (PAD_AX[i]) { out[PAD_AX[i] + '-'] = Math.max(0, -v); out[PAD_AX[i] + '+'] = Math.max(0, v); } });
      return out;
    },
    attach(def) {
      const binds = Controls.bindings(def);
      const keyDown = {}, padVal = {}, held = {}, fns = [];
      let raf = 0;
      const emit = (type, id) => fns.slice().forEach((f) => { try { f(type, id); } catch (e) { console.error(e); } });
      function recompute() {
        binds.forEach((b) => {
          const on = b.keys.some((k) => keyDown[k]) || b.pad.some((n) => (padVal[n] || 0) > 0.45);
          if (on !== !!held[b.id]) { held[b.id] = on; emit(on ? 'down' : 'up', b.id); }
        });
      }
      const typing = (e) => {   // 글자 입력 중이거나, 포커스된 버튼을 Space/Enter로 누르는 중이면 게임 조작으로 쓰지 않음
        const t = (e.target && e.target.tagName) || '';
        if (/^(INPUT|TEXTAREA|SELECT)$/.test(t)) return true;
        if ((t === 'BUTTON' || t === 'A') && (e.code === 'Space' || e.code === 'Enter' || e.code === 'NumpadEnter')) return true;
        return !!document.querySelector('.overlay[data-core]:not(.result)') && e.code !== 'Escape';   // 시트·확인창이 떠 있으면 게임 조작 멈춤
      };
      function kd(e) {
        if (typing(e) || !binds.some((b) => b.keys.includes(e.code))) return;
        e.preventDefault(); if (keyDown[e.code]) return; keyDown[e.code] = true; recompute();
      }
      function ku(e) { if (keyDown[e.code]) { delete keyDown[e.code]; recompute(); } }
      function blur() { Object.keys(keyDown).forEach((k) => delete keyDown[k]); Object.keys(padVal).forEach((k) => delete padVal[k]); recompute(); }
      function poll() {
        const st = Controls.padState(); Object.keys(padVal).forEach((k) => { if (!(k in st)) delete padVal[k]; }); Object.assign(padVal, st);
        recompute(); raf = requestAnimationFrame(poll);
      }
      if (binds.length) {
        addEventListener('keydown', kd); addEventListener('keyup', ku); addEventListener('blur', blur);
        if (binds.some((b) => b.pad.length)) raf = requestAnimationFrame(poll);
      }
      return {
        held: (id) => !!held[id],
        on(fn) { fns.push(fn); return () => { const i = fns.indexOf(fn); if (i >= 0) fns.splice(i, 1); }; },
        axis(neg, pos) {   // analog when bound to sticks, else -1/0/1
          const val = (id) => { const b = binds.find((x) => x.id === id); if (!b) return 0;
            return Math.max(b.keys.some((k) => keyDown[k]) ? 1 : 0, ...b.pad.map((n) => { const v = padVal[n] || 0; return v > 0.15 ? Math.min(1, (v - 0.15) / 0.75) : 0; })); };
          return val(pos) - val(neg);
        },
        bindings: () => binds,
        destroy() { removeEventListener('keydown', kd); removeEventListener('keyup', ku); removeEventListener('blur', blur); cancelAnimationFrame(raf); fns.length = 0; },
      };
    },
  };
  L.Controls = Controls;

  function controlsSheet(id, parent, onDone) {
    const g = L.games[id];
    let binds = Controls.bindings(g);
    let capture = null, raf = 0;
    const list = h('div', { class: 'ctl-list' });
    const hint = h('p', { class: 'note', style: { margin: 0 }, text: '칸을 누른 뒤 원하는 키나 패드 버튼을 누르세요. 칸을 누르고 Delete를 누르면 지워요.' });
    function save() {
      const o = {}; binds.forEach((b) => { o[b.id] = { keys: b.keys, pad: b.pad }; }); store.set('keys.' + id, o);
    }
    function chip(b, kind, i) {
      const v = b[kind][i];
      const busy = capture && capture.b === b && capture.kind === kind && capture.i === i;
      return h('button', { class: 'btn sm ctl ' + kind + (busy ? ' on' : '') + ((kind === 'pad' ? b.pad.length : v) ? '' : ' empty'),
        text: busy ? '누르세요…' : kind === 'pad' ? (b.pad.map((n) => PAD_NAME[n] || n).join(' · ') || '+') : v ? keyLabel(v) : '+',
        'aria-label': b.label + (kind === 'keys' ? ' 키 ' : ' 패드 ') + (i + 1),
        onclick() { capture = { b, kind, i }; draw(); } });
    }
    function draw() {
      list.innerHTML = '';
      binds.forEach((b) => list.append(h('div', { class: 'ctl-row' },
        h('span', { class: 'ctl-name', text: b.label }),
        h('div', { class: 'ctl-chips' }, chip(b, 'keys', 0), chip(b, 'keys', 1), chip(b, 'pad', 0)))));
    }
    function assign(kind, val) {
      const c = capture; if (!c) return;
      binds.forEach((o) => { if (o !== c.b && o[kind].includes(val)) { o[kind] = o[kind].filter((x) => x !== val); toast(o.label + '에서 옮겼어요'); } });
      if (kind === 'pad') c.b.pad = [val];   // 패드는 한 칸: 새로 누른 것 하나로 바꿈
      else { const arr = c.b[kind].slice(); arr[c.i] = val; c.b[kind] = arr.filter((x, j) => x && arr.indexOf(x) === j); }
      capture = null; save(); Sfx.play('click'); draw();
    }
    function kd(e) {
      if (!capture) return;
      e.preventDefault(); e.stopPropagation();
      if (e.code === 'Escape') { capture = null; draw(); return; }
      if (e.code === 'Delete' || e.code === 'Backspace') { const c = capture; c.b[c.kind] = c.b[c.kind].filter((_, j) => j !== c.i); capture = null; save(); draw(); return; }
      if (capture.kind === 'keys') assign('keys', e.code);
    }
    let prev = Controls.padState();
    function poll() {
      const st = Controls.padState();
      if (capture) { const n = Object.keys(st).find((k) => st[k] > 0.6 && !((prev[k] || 0) > 0.6)); if (n) assign('pad', n); }
      prev = st; raf = requestAnimationFrame(poll);
    }
    addEventListener('keydown', kd, true); raf = requestAnimationFrame(poll);
    const close = () => { removeEventListener('keydown', kd, true); cancelAnimationFrame(raf); o.remove(); if (onDone) onDone(); };
    draw();
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '조작 설정 · 키보드 / 게임패드' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      hint, list,
      h('div', { class: 'row', style: { gap: '8px' } },
        h('button', { class: 'btn', text: '기본값으로', onclick() { store.set('keys.' + id, {}); binds = Controls.bindings(g); capture = null; draw(); toast('기본 조작으로 되돌렸어요'); } }),
        h('button', { class: 'btn primary', style: { flex: 1 }, text: '완료', onclick: close }))), { cls: 'rules-ov', parent: parent || app });
    return o;
  }
  const showControlsBtn = () => matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP;

  /* 가로 배치의 게임 옆 정보판(라운드 48). 세로형 게임만(가로 게임·PC 전용·def.sidePanel === false는 없음).
     게임이 이미 주는 것만 쓴다: 자리(이름·색·AI 난이도), 지금 차례(actor), 점수(state.scores/score 배열이 자리 수와 같을 때),
     def.panelInfo(state, seat) → 문자열 또는 {label, value} 배열(선택), def.hint(지금 상황 — 가림막 게임은 빼서 숨김 정보가 새지 않게),
     quick/rules 요약, 결과(result.winners/text), 온라인 방 코드. 좁은 화면에서는 CSS로 숨겨 폰 화면은 그대로. */
  const Side = {
    ok(def) { return def.sidePanel !== false && !def.landscape && !def.pcOnly; },
    els: null, t: 0, log: [], lastKey: '',
    build(scr, gameId) {
      const def = L.games[gameId];
      const left = h('aside', { class: 'gside gl', 'aria-label': '판 정보' }), right = h('aside', { class: 'gside gr', 'aria-label': '규칙 요약' });
      scr.classList.add('has-side'); scr.append(left, right);
      Side.els = { left, right, gameId, t0: Date.now(), info: h('div', { class: 'gs-box' }), now: h('div', { class: 'gs-box' }), logEl: h('ol', { class: 'gs-log' }) };
      Side.log = []; Side.lastKey = ''; Side.n = 0;
      const q = def.quick && def.quick.length ? def.quick : ((def.rules || [])[0] || {}).p || [];
      left.append(Side.els.info);
      right.append(...[Side.els.now,
        q.length ? h('div', { class: 'gs-box' }, h('span', { class: 'label', text: '규칙 요약' }), h('ol', { class: 'quick gs-quick' }, q.slice(0, 6).map((t) => h('li', { text: t })))) : null,
        h('button', { class: 'btn sm', type: 'button', text: '전체 규칙 보기', onclick: () => rulesSheet(gameId) }),
        h('div', { class: 'gs-box' }, h('span', { class: 'label', text: '진행 기록' }), Side.els.logEl)].filter(Boolean));
    },
    dirty() { if (!Side.els || !S || Side.els.gameId !== S.gameId) return; if (!Side.t) Side.t = setTimeout(() => { Side.t = 0; Side.draw(); }, S.def.realtime ? 400 : 16); },
    draw() {
      const E = Side.els; if (!E || !S || !S.state || !E.left.isConnected) return;
      const def = S.def, st = S.state, ps = S.players || [], res = def.result(st);
      const acts = res ? [] : actorsOf(def, st);
      const sc = Array.isArray(st.scores) && st.scores.length === ps.length ? st.scores : Array.isArray(st.score) && st.score.length === ps.length ? st.score : null;
      const winners = res && Array.isArray(res.winners) ? res.winners : [];
      const me = viewerSeat();
      E.info.textContent = '';
      E.info.append(h('span', { class: 'label', text: '플레이어 · ' + ps.length + '명' }),
        h('div', { class: 'gs-players' }, ps.map((p, i) => h('div', { class: 'gs-p' + (acts.includes(i) ? ' on' : '') + (winners.includes(i) ? ' win' : '') },
          h('span', { class: 'dot', style: { '--c': p.color || COLORS[i] } }),
          h('span', { class: 'nm', text: p.name }),
          sc && (typeof sc[i] === 'number' || typeof sc[i] === 'string') ? h('b', { class: 'gs-sc', text: String(sc[i]) }) : null,
          h('span', { class: 'tag' + (i === me ? ' me' : ''), text: winners.includes(i) ? '🏆' : acts.includes(i) && !def.realtime ? '차례' : p.ai ? 'AI ' + (LV[p.lv || 2] || '') : i === me ? '나' : p.local ? '사람' : '친구' })))));
      let extra = null;
      if (typeof def.panelInfo === 'function') { try { extra = def.panelInfo(clone(st), me); } catch (e) { extra = null; } }
      if (Array.isArray(extra) && extra.length) E.info.append(h('div', { class: 'gs-kv' }, extra.slice(0, 12).map((x) => typeof x === 'string' ? h('div', { text: x }) : h('div', null, h('span', { class: 'muted', text: x.label + ' ' }), h('b', { text: String(x.value) })))));
      const mins = Math.floor((Date.now() - E.t0) / 60000);
      E.info.append(h('p', { class: 'note gs-meta', text: [S.mode === 'local' ? '이 기기에서' : (Net.lan ? 'LAN 방' : '온라인 방 ' + (Net.code || '')), mins ? mins + '분째' : '방금 시작'].join(' · ') }));
      // 지금 상황
      E.now.textContent = '';
      if (res) E.now.append(h('span', { class: 'label', text: '결과' }), h('p', { class: 'gs-res', text: res.title || (res.text || '').slice(0, 80) || (winners.length ? winners.map((i) => ps[i] && ps[i].name).join(', ') + ' 승리' : '판이 끝났어요') }));
      else {
        let lines = null;
        if (def.hint && !def.hidden && me >= 0) { try { lines = def.hint(clone(st), me); } catch (e) { lines = null; } }
        if (typeof lines === 'string') lines = [lines];
        const turnTxt = !def.realtime && acts.length === 1 && ps[acts[0]] ? ps[acts[0]].name + ' 차례' : acts.length > 1 && !def.realtime ? '모두 함께 고르는 중' : '';
        if (turnTxt || (lines && lines.length)) E.now.append(...[h('span', { class: 'label', text: '지금 상황' }), turnTxt ? h('p', { class: 'gs-turn', text: turnTxt }) : null,
          lines && lines.length ? h('ul', { class: 'gs-hint' }, lines.slice(0, 4).map((t) => h('li', { text: String(t) }))) : null].filter(Boolean));
      }
      // 진행 기록: 차례가 넘어갈 때마다 한 줄(가장 최근이 위)
      if (!def.realtime) {
        const key = res ? 'end' : acts.join(',');
        if (key !== Side.lastKey) {
          Side.lastKey = key;
          const n = ++Side.n;
          Side.log.unshift(res ? '판 끝' : acts.length === 1 && ps[acts[0]] ? n + '. ' + ps[acts[0]].name + ' 차례' : n + '. 모두 함께');
          Side.log = Side.log.slice(0, 40);
          E.logEl.textContent = ''; E.logEl.append(...Side.log.map((t) => h('li', { text: t })));
        }
      } else if (!Side.log.length) { Side.log.push('실시간 게임'); E.logEl.append(h('li', { text: '실시간 게임 — 기록 없음' })); }
    },
  };
  setInterval(() => { if (Side.els && S && Layout.wide) Side.dirty(); }, 30000);
  L.debug.side = Side;   // 경과 시간 갱신
  function startSession(mode, gameId, players, state, opts) {
    if (mode === 'local' && pcOnlyBlocked(L.games[gameId])) { pcOnlySheet(L.games[gameId]); return; }
    endSession();
    const def = L.games[gameId];
    S = { mode, gameId, def, players, state: null, ver: 0, view: null, busy: false, aiTimer: 0, aiTimers: {}, revealed: -1, resultShown: false, stuck: 0, opts: optDefaults(def, opts) };
    S.styles = {}; (players || []).forEach((p, i) => { if (p && p.ai) L.aiStyle(i); });
    Music.start(gameId); Amb.start(gameId); Recent.add(gameId);
    const turnEl = h('span', { class: 'turn', hidden: true });
    const stage = h('div', { class: 'stage', 'data-themed': def.themed ? '1' : null });
    const scr = h('div', { class: 'screen gscreen' },
      h('div', { class: 'topbar' },
        h('button', { class: 'iconbtn', 'aria-label': '나가기', text: '‹', onclick: leaveGame }),
        h('div', { class: 'title', text: def.name }),
        h('div', { class: 'grow' }), turnEl,
        undoOk() ? h('button', { class: 'iconbtn undo-btn', 'aria-label': '무르기', text: '↶', onclick: () => doUndo() }) : null,
        (mode === 'local' || mode === 'host') && (def.realtime || (def.realtimeIf && def.realtimeIf(S.opts))) ? h('button', { class: 'iconbtn pause-btn', 'aria-label': '일시정지', text: '⏸', onclick: () => pauseSheet() }) : null,
        h('button', { class: 'iconbtn', 'aria-label': '규칙 보기', text: '?', style: { fontWeight: 700, fontFamily: 'var(--f-mono)' }, onclick: () => helpSheet(gameId, stage) }),
        h('button', { class: 'iconbtn', 'aria-label': '소리', text: Sfx.on ? '♪' : '♩', onclick(e) { Sfx.on = !Sfx.on; store.set('sound', Sfx.on); e.target.textContent = Sfx.on ? '♪' : '♩'; } })),
      stage);
    Side.els = null; if (Side.ok(def)) Side.build(scr, gameId);
    show(scr);
    S.stage = stage;
    /* 라운드 55: 게임 중엔 위쪽 막대를 숨기고(Esc/☰ 메뉴로), 차례 표시는 판 위 작은 알약으로 */
    S.turnEl = h('span', { class: 'turn gturn', hidden: true });
    S.gcorner = h('div', { class: 'gcorner' + (def.menuCorner ? ' at-' + def.menuCorner : ''), hidden: def.menuCorner === false },
      h('button', { class: 'gcbtn gmenu-btn', 'aria-label': '게임 메뉴', title: '게임 메뉴 (Esc)', text: '☰', onclick: () => gameMenu() }));
    if (Anim.on()) stage.classList.add('enter');
    document.title = def.name + ' · 한판 라운지';
    keepAwake(true);
    if (L.STANDALONE) { try { history.pushState({ lounge: 'game' }, ''); } catch (e) {} }
    const mySession = S;
    const api = {
      best(key, v, m) { return Best.set(gameId, key, v, m); },
      get players() { return mySession.players; },
      online: mode !== 'local',
      get isHost() { return mySession.mode !== 'guest'; },
      canAct(seat) { const p = mySession.players[seat]; return !!p && !p.ai && !!p.local; },
      mySeats() { return mySession.players.map((p, i) => (!p.ai && p.local ? i : -1)).filter((i) => i >= 0); },
      viewer() { return viewerSeat(); },
      act(action) {
        if (S !== mySession) return;
        const seat = actorsOf(def, S.state).find((x) => api.canAct(x));
        if (seat == null) return;
        submit(seat, action);
      },
      actAs(seat, action) { if (S === mySession && api.canAct(seat)) submit(seat, action); },
      setBusy(b) { if (S !== mySession) return; S.busy = !!b; if (!b) afterIdle(); },
      setState(st) { if (S === mySession && S.mode !== 'guest') setState(st); },
      sfx: (n, o) => Sfx.play(n, o), buzz: (ms, kind) => L.haptic(kind || 'hit', ms), haptic: (kind, ms) => L.haptic(kind, ms), aiStyle: (seat) => L.aiStyle(seat), toast,
      pickBar: (o) => pickBar(api, o),
      banner: (text, o) => (S === mySession ? banner(text, Object.assign({ parent: mySession.stage }, o)) : null),
      round: (n, sub) => (S === mySession ? banner(typeof n === 'number' ? n + '라운드' : String(n), { parent: mySession.stage, sub }) : null),
      fmt: L.fmt,
      /* 라운드 50: 일시정지 상태 · 구독(fn(paused) → 끊기 함수) · 멈추기 요청(로컬·방장만) */
      paused: () => S === mySession && Clock.paused,
      onPause(fn) { pauseFns.add(fn); const off = () => pauseFns.delete(fn); (mySession.offs || (mySession.offs = [])).push(off); return off; },
      pause: () => { if (S === mySession) pauseSheet(); },
      canPause: () => S === mySession && canPause(),
      net: {
        publish(obj) { if (mySession.mode !== 'local') Net.pub({ g: obj }); },
        remote() { return Net.remoteG(); },
        hostSend(obj) { if (mySession.mode === 'host') Net.pub({ hs: obj }); },
        hostState() { return Net.hostField('hs'); },
      },
    };
    api.input = S.input = Controls.attach(def);
    api.tutorial = (only) => runTutorial(def, true, Array.isArray(only) ? only : null);
    if (def.landscape) Orient.enter();
    S.api = api;
    try { S.view = def.mount(stage, api); } catch (e) { console.error(e); toast('게임을 여는 중 문제가 생겼어요'); }
    stage.append(S.turnEl, S.gcorner);
    requestAnimationFrame(() => { if (S === mySession) { try { window.dispatchEvent(new Event('resize')); } catch (e) {} } });
    if (state) setState(state, true);
    else if (mode !== 'guest') setState(def.init(clone(players.map((p) => ({ name: p.name, color: p.color, ai: !!p.ai, lv: p.ai ? (p.lv || 2) : 0 }))), clone(S.opts)));
    if (def.tutorial && !def.realtime) setTimeout(() => { if (S === mySession) runTutorial(def); }, 450);
    if (def.save) Saves.start();
  }

  function viewerSeat() {
    if (!S) return -1;
    if (S.mode !== 'local') { const m = S.api.mySeats(); return m.length ? m[0] : -1; }
    const humans = S.api.mySeats();
    if (humans.length === 1) return humans[0];
    if (humans.length === 0) return -1;
    // several people share this phone: show private info only to the revealed player while it is their turn
    if (S.def.result(S.state)) return S.revealed;
    return actorsOf(S.def, S.state).includes(S.revealed) ? S.revealed : -1;
  }

  /* 무르기(라운드 25): 로컬·턴제·사람 1명+AI. 사람 차례가 된 상태를 쌓아 두고 ↶로 직전 내 차례로 돌아간다 */
  const OWN_UNDO = ['chess', 'baduk', 'gomoku'];
  function undoOk() {
    if (!S || S.mode !== 'local' || S.def.undo === false || OWN_UNDO.includes(S.gameId) || store.get('undo', true) === false) return false;
    if (S.def.realtime || (S.def.realtimeIf && S.def.realtimeIf(S.opts))) return false;
    const hum = S.players.filter((p) => !p.ai).length;
    return hum === 1 && S.players.length > 1;
  }
  function undoTrack(next) {
    if (!undoOk()) return;
    S.undo = S.undo || [];
    const a = actorsOf(S.def, next), me = S.players.findIndex((p) => !p.ai);
    if (S.def.result(next) || !(a.length === 1 && a[0] === me)) return;
    const js = JSON.stringify(next);
    if (S.undo.length && S.undo[S.undo.length - 1] === js) return;
    S.undo.push(js); if (S.undo.length > 60) S.undo.shift();
  }
  function doUndo() {
    if (!undoOk() || !S.undo || S.undo.length < 2 || S.busy) { toast('되돌릴 수가 없어요'); return; }
    const cur = JSON.stringify(S.state);
    if (S.undo[S.undo.length - 1] === cur) S.undo.pop();
    const back = S.undo[S.undo.length - 1];
    clearTimeout(S.aiTimer); Object.values(S.aiTimers).forEach(clearTimeout); S.aiTimers = {};
    S.stage.querySelectorAll('.overlay.result').forEach((e) => e.remove());
    setState(JSON.parse(back)); Sfx.play('whoosh');
  }
  function setState(next, fromNet) {
    if (!S) return;
    undoTrack(next);
    const prev = S.state;
    S.state = next;
    S.ver++;
    if (S.mode === 'host' && !fromNet) Net.pubState();
    if (S.def.save && S.mode !== 'guest') Saves.touch();
    updateTurn();
    maybeCurtain();
    Side.dirty();
    try { S.view && S.view.update && S.view.update(next, prev); } catch (e) { console.error(e); }
    if (!S.def.result(next)) { S.resultShown = false; S.stage.querySelectorAll('.overlay.result').forEach((e) => e.remove()); }
    scheduleAI();
    afterIdle();
  }
  L._setStateFromNet = (st) => setState(st, true);

  function updateTurn() {
    const list = actorsOf(S.def, S.state);
    const el = S.turnEl;
    if (!list.length || !S.players[list[0]] || S.def.result(S.state) || S.def.realtime || (S.def.realtimeIf && S.def.realtimeIf(S.opts)) || (S.players.length === 1 && !S.players[0].ai)) { el.hidden = true; S.lastCue = -1; return; }
    el.hidden = false; el.innerHTML = '';
    const seat = list.find((x) => S.api.canAct(x)) != null ? list.find((x) => S.api.canAct(x)) : list[0];
    const p = S.players[seat];
    const mine = S.api.canAct(seat);
    if (list.length > 1) el.append(h('span', { class: 'dot', style: { '--c': 'var(--brass)' } }), mine ? '모두 함께' : '모두 참여');
    else el.append(h('span', { class: 'dot', style: { '--c': p.color } }), (mine && S.mode !== 'local') ? '내 차례' : p.name + (p.ai ? ' 생각 중' : ' 차례'));
    el.classList.toggle('mine', mine);
    // 라운드 55: 차례가 바뀌면 판 위쪽 가운데에 잠깐 떴다가 사라짐(계속 보려면 Esc/☰ 메뉴)
    const tk = el.textContent;
    if (tk !== S.turnShown) { S.turnShown = tk; el.classList.add('show'); clearTimeout(S.turnHide); S.turnHide = setTimeout(() => el.classList.remove('show'), mine ? 2200 : 1500); }
    // gentle cue when control comes back to a person on this phone after someone else's move
    const key = mine ? seat : -1;
    if (mine && list.length === 1 && S.lastCue !== key && S.ver > 1) {
      buzz(15, 'alert'); Sfx.play('turn', { vol: 0.7 });
      if (Anim.on()) { el.classList.remove('flash'); void el.offsetWidth; el.classList.add('flash'); }
    }
    S.lastCue = key;
  }

  function submit(seat, action) {
    if (!S) return;
    if (S.mode === 'guest') { Net.sendAct(seat, action); return; }
    if (!actorsOf(S.def, S.state).includes(seat)) return;
    let next;
    try { next = S.def.apply(clone(S.state), seat, clone(action)); } catch (e) { console.warn('rejected action', e); return; }
    if (!next) return;
    setState(next);
  }
  L._submit = submit;

  function scheduleAI() {
    clearTimeout(S.aiTimer); Object.values(S.aiTimers).forEach(clearTimeout); S.aiTimers = {};
    if (S.paused) S.aiDue = {};
    if (S.mode === 'guest' || S.def.realtime || S.paused) return;
    if (S.def.result(S.state)) return;
    const seats = actorsOf(S.def, S.state).filter((x) => S.players[x] && S.players[x].ai);
    const me = S, ver = S.ver;
    // 동시 입력 게임: 다른 자리가 내도 아직 안 낸 AI는 처음 정한 시각을 지킨다(타이머가 매번 처음부터 다시 돌지 않게)
    const due = S.aiDue || (S.aiDue = {});
    Object.keys(due).forEach((k) => { if (!seats.includes(+k)) delete due[k]; });
    seats.forEach((seat) => {
      const lv = S.players[seat].lv || 2;
      const base = S.def.aiDelayFor ? S.def.aiDelayFor(clone(S.state), seat, lv) : (S.def.aiDelay != null ? S.def.aiDelay : 650);
      if (base == null || base < 0) return; // this AI has nothing to do in this state
      const now = Date.now();
      if (due[seat] == null) due[seat] = now + base / L.debug.speed / L.speed();
      const delay = Math.max(0, due[seat] - now);
      let stuck = 0;
      function tick() {
        if (S !== me || S.ver !== ver) return;
        if (S.busy || document.querySelector('.overlay.curtain') || (S.mode === 'local' && document.querySelector('.overlay.rules-ov'))) { S.aiTimers[seat] = setTimeout(tick, 120); return; }
        let a;
        try { a = S.def.ai(clone(S.state), seat, lv); } catch (e) { console.error('AI error', e); return; }
        if (a == null) return;
        delete due[seat];
        submit(seat, a);
        if (S === me && S.ver === ver) { // action was rejected — avoid silent stall
          if (++stuck < 4) S.aiTimers[seat] = setTimeout(tick, 200);
          else console.error('AI stuck on', S.gameId, a);
        }
      }
      S.aiTimers[seat] = setTimeout(tick, delay);
    });
  }

  /* pass-the-phone curtain for hidden-info games */
  function maybeCurtain() {
    if (S.mode !== 'local' || !S.def.hidden) return;
    const humans = S.api.mySeats();
    if (humans.length < 2) return;
    const list = actorsOf(S.def, S.state);
    if (list.length !== 1) return;
    const seat = list[0];
    if (S.players[seat].ai || seat === S.revealed || S.def.result(S.state)) return;
    if (S.stage.querySelector('.curtain')) return;
    const p = S.players[seat];
    const c = overlay(h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' } },
      h('span', { class: 'dot', style: { '--c': p.color, width: '18px', height: '18px' } }),
      h('div', { class: 'big', text: p.name }),
      h('div', { class: 'muted', text: '다른 사람이 보지 않게 폰을 넘겨주세요' }),
      h('button', { class: 'btn primary', text: '내 패 보기' })), { cls: 'curtain', parent: S.stage });
    c.addEventListener('click', () => {
      if (!S) return;
      S.revealed = seat; c.remove(); Sfx.play('click');
      try { S.view.update(S.state, S.state); } catch (e) { console.error(e); }
      scheduleAI();
    });
  }

  function afterIdle() {
    if (!S || S.busy || S.resultShown) return;
    const res = S.def.result(S.state);
    if (!res) return;
    S.resultShown = true;
    const me = S;
    setTimeout(() => { if (S === me && !S.busy) showResult(res); else if (S === me) S.resultShown = false; }, 500 / L.debug.speed);
  }
  /* 결과 통계(라운드 24): result()가 stats: [{label, values:[자리별 값]}] 또는 [{label, value}]를 주면 표로 보인다 */
  function statsBox(st) {
    if (!Array.isArray(st) || !st.length) return null;
    const perSeat = st.some((r) => Array.isArray(r.values));
    const tb = h('table', { class: 'res-stats' });
    if (perSeat) tb.append(h('tr', {}, h('th', { text: '' }), ...S.players.map((p) => h('th', {}, h('span', { class: 'dot', style: { '--c': p.color } }), ' ' + p.name))));
    st.slice(0, 10).forEach((r) => {
      const vals = perSeat && Array.isArray(r.values) ? r.values : null;
      let best = -1;   // 숫자 줄이면 가장 큰 값(r.low면 가장 작은 값)을 굵게
      if (vals && r.best !== false && vals.length > 1 && vals.every((v) => typeof v === 'number')) {
        const m = r.low ? Math.min(...vals) : Math.max(...vals);
        if (vals.filter((v) => v === m).length === 1) best = vals.indexOf(m);
      }
      tb.append(h('tr', {}, h('td', { text: r.label }), ...(vals ? vals.map((v, i) => h('td', { class: i === best ? 'best' : null, text: L.fmt.cell(v) + (r.unit && v != null && v !== '-' ? r.unit : '') }))
        : [h('td', { text: L.fmt.cell(r.value) + (r.unit && r.value != null ? r.unit : ''), colSpan: perSeat ? S.players.length : 1, style: { textAlign: 'center' } })])));
    });
    return h('div', { class: 'res-stats-wrap' }, tb);
  }
  function showResult(res) {
    Amb.stop();
    const winners = (res.winners || []).map((i) => S.players[i]).filter(Boolean);
    const anyMine = (res.winners || []).some((i) => S.api.canAct(i));
    Sfx.play(anyMine || S.api.mySeats().length === 0 ? 'win' : S.api.mySeats().length && !(res.winners || []).length ? 'result' : 'lose');
    if (anyMine) L.haptic('win');
    const styl = S.mode !== 'guest' && !S.def.noAI ? S.players.map((p, i) => (p && p.ai && S.styles && S.styles[i] ? [p, AI_STYLES[S.styles[i]]] : null)).filter(Boolean) : [];
    const styleRow = styl.length ? h('div', { class: 'row ai-styles', style: { gap: '4px 10px', fontSize: '12px' } }, h('span', { class: 'muted', text: 'AI 성향' }),
      styl.map(([p, st]) => h('span', { class: 'row', style: { gap: '4px' }, title: st[1] }, h('span', { class: 'dot', style: { '--c': p.color } }), p.name + ' ' + st[0] + ' ' + st[1]))) : null;
    const btns = h('div', { class: 'row', style: { justifyContent: 'flex-end' } });
    let vb = null;
    if (S.mode === 'host' || (S.mode === 'guest' && Net.hostField('vcap'))) {   // 온라인 「한 판 더」 투표(라운드 27). 옛 버전 호스트면 예전 화면.
      vb = voteBox(S.mode === 'host');
      btns.append(vb.el);
    } else if (S.mode === 'guest') {
      btns.append(h('span', { class: 'muted', style: { marginRight: 'auto' }, text: '호스트가 다음 판을 고르는 중' }),
        h('button', { class: 'btn ghost', text: '나가기', onclick: leaveGame }));
    } else {
      const gid = S.gameId;
      btns.classList.add('res-btns');
      btns.append(h('button', { class: 'btn ghost', text: S.mode === 'host' ? '로비로' : '다른 게임', onclick() { o.remove(); S.mode === 'host' ? Net.backToLobby() : homeScreen(); } }),
        S.mode === 'local' ? h('button', { class: 'btn', text: '설정 바꿔서 다시', onclick() { o.remove(); homeScreen(); setupSheet(gid, () => homeScreen()); } }) : null,
        h('button', { class: 'btn primary', 'data-again': '1', text: '다시 하기', onclick() { o.remove(); rematch(); } }));
    }
    /* 하이라이트(라운드 50): result.highlights = ['문장', ...] 또는 result.highlight = '문장' (최대 4줄) */
    const hl = [].concat(res.highlights || [], res.highlight ? [res.highlight] : []).filter(Boolean).slice(0, 4);
    const hlBox = hl.length ? h('ul', { class: 'res-hl' }, hl.map((t) => h('li', { text: String(t) }))) : null;
    const o = overlay(h('div', { class: 'sheet' },
      h('span', { class: 'label', text: '결과' }),
      h('h2', { text: res.title || (winners.length === 1 ? winners[0].name + ' 승리' : winners.length ? '공동 승리' : '무승부') }),
      winners.length ? h('div', { class: 'row' }, winners.map((p) => h('span', { class: 'row', style: { gap: '6px' } }, h('span', { class: 'dot', style: { '--c': p.color } }), p.name))) : null,
      res.text ? h('p', { class: 'muted', style: { margin: 0, whiteSpace: 'pre-line' }, text: res.text }) : null,
      hlBox, statsBox(res.stats), styleRow,
      btns), { parent: S.stage });
    o.classList.add('result');
    if (vb) { Net.voteUI = vb.upd; watchRemoved(o, () => { if (Net.voteUI === vb.upd) Net.voteUI = null; }); if (S.mode === 'host') hostVoteCheck(); else vb.upd(Net.hostField('votes')); }
  }
  /* ---------- 온라인 「한 판 더」 투표 (라운드 27) ----------
     게스트 presence.vote = {r: 판 번호(lobby.rd), v: 'again'|'lobby'} · 호스트 presence.votes = {rd, t:{again,lobby,leave}, n: 투표할 사람 수, who:{peer: v}}, vcap: 1.
     과반(자리에 앉은 사람 중 절반 초과)이 「한 판 더」면 새 판, 「게임 바꾸기」면 모두 로비로. 나가기는 바로 방을 떠남(자리는 AI가 이어받고 투표 인원에서 빠짐).
     옛 버전 게스트는 투표 필드를 모르고 무시 → 방장이 「바로」 버튼으로 정할 수 있다. */
  const VOTE_KEYS = [['again', '한 판 더'], ['lobby', '게임 바꾸기'], ['leave', '나가기']];
  function votePool() { return ((Net.lobby && Net.lobby.seats) || []).filter((s) => !s.ai && s.p).map((s) => s.p); }
  function hostTally() {
    if (Net.role !== 'h' || !Net.lobby || !Net.lobby.started) return null;
    const rd = Net.lobby.rd | 0, me = Net.myPeer(), pool = votePool(), who = {};
    if (Net.myVote && Net.myVote.r === rd) who[me] = Net.myVote.v;
    for (const p of Net.r ? Net.r.peers() : []) {
      if (p.sameTab || !p.presence) continue;
      const v = p.presence.vote;
      if (v && v.r === rd && pool.includes(p.peer) && (v.v === 'again' || v.v === 'lobby')) who[p.peer] = v.v;
    }
    const t = { again: 0, lobby: 0, leave: Net.voteLeft | 0 };
    Object.values(who).forEach((v) => { t[v]++; });
    return { rd, t, n: pool.length, who };
  }
  function hostVoteCheck() {
    const T = hostTally(); if (!T) return;
    const sig = JSON.stringify(T);
    if (sig !== Net.voteSig) { Net.voteSig = sig; Net.pub({ votes: T }); }
    if (Net.voteUI) Net.voteUI(T);
    if (!S || !S.resultShown || Net.voteDone === T.rd) return;
    if (T.t.again * 2 > T.n) voteGo('again'); else if (T.t.lobby * 2 > T.n) voteGo('lobby');
  }
  function voteGo(kind) {
    if (Net.role !== 'h' || !S) return;
    Net.voteDone = Net.lobby.rd | 0;
    if (kind === 'again') { toast('한 판 더!'); rematch(); } else { toast('로비로 돌아가요'); Net.backToLobby(); }
  }
  function voteBox(isHost) {
    const me = Net.myPeer();
    const seated = isHost || ((Net.lobby && Net.lobby.seats) || []).some((s) => s.p === me && !s.ai);
    const cnt = {}, bt = {};
    const pick = (k) => {
      if (k === 'leave') {
        if (isHost) return confirmSheet('방을 닫을까요?', '모두 방에서 나가게 돼요.', '방 닫기', () => homeScreen());
        Net.leave(); return homeScreen();
      }
      Net.myVote = { r: (Net.lobby && Net.lobby.rd) | 0, v: k };
      Sfx.play('click');
      if (isHost) hostVoteCheck(); else { Net.pub({ vote: Net.myVote }); upd(Net.hostField('votes')); }
    };
    const row = h('div', { class: 'vote-btns' }, VOTE_KEYS.map(([k, label]) => {
      if (!seated && k !== 'leave') return null;
      cnt[k] = h('span', { class: 'vn', text: '' });
      return (bt[k] = h('button', { class: 'btn' + (k === 'again' ? ' primary' : k === 'leave' ? ' ghost' : ''), type: 'button', 'data-vote': k, onclick: () => pick(k) }, h('span', { text: label }), cnt[k]));
    }));
    const info = h('p', { class: 'vote-who' });
    const force = isHost ? h('div', { class: 'vote-force' }, h('span', { class: 'muted', text: '방장이 바로 정하기' }),
      h('button', { class: 'btn sm', 'data-force': 'again', text: '바로 한 판 더', onclick: () => voteGo('again') }),
      h('button', { class: 'btn sm', 'data-force': 'lobby', text: '바로 로비로', onclick: () => voteGo('lobby') })) : null;
    const el = h('div', { class: 'vote-box', style: { width: '100%' } }, h('span', { class: 'label', text: seated ? '다음 판 투표 · 과반이면 바로 진행' : '구경 중 · 자리에 앉은 사람이 정해요' }), row, info, force);
    function upd(T) {
      const rd = (Net.lobby && Net.lobby.rd) | 0;
      if (!T || T.rd !== rd) T = { rd, t: { again: 0, lobby: 0, leave: 0 }, n: votePool().length, who: {} };
      const need = Math.floor(T.n / 2) + 1;
      if (cnt.again) cnt.again.textContent = T.t.again + ' / ' + need;
      if (cnt.lobby) cnt.lobby.textContent = T.t.lobby + ' / ' + need;
      if (cnt.leave) cnt.leave.textContent = T.t.leave ? T.t.leave + '명 나감' : '';
      const mine = Net.myVote && Net.myVote.r === rd ? Net.myVote.v : (T.who || {})[me];
      Object.keys(bt).forEach((k) => { bt[k].classList.toggle('on', k === mine); bt[k].setAttribute('aria-pressed', String(k === mine)); });
      const nameOf = (peer) => { const s2 = ((Net.lobby && Net.lobby.seats) || []).find((x) => x.p === peer); return s2 ? s2.n : '?'; };
      const ws = Object.entries(T.who || {}).map(([p, v]) => nameOf(p) + (v === 'again' ? '(한 판 더)' : '(바꾸기)'));
      info.textContent = (ws.length ? ws.join(', ') : '아직 아무도 안 골랐어요') + ' · 사람 ' + T.n + '명';
    }
    upd(null);
    return { el, upd };
  }
  function rematch() {
    if (!S) return;
    if (S.mode === 'local' && S.opts && S.opts._order === 'rand' && S.players.length > 1) {
      const ps = shuffleOrder(S.def, S.opts, S.players);
      startSession('local', S.gameId, ps, null, S.opts); orderToast(ps); return;
    }
    if (S.mode === 'host' && Net.lobby) { Net.lobby.rd = (Net.lobby.rd | 0) + 1; Net.voteLeft = 0; Net.myVote = null; Net.voteUI = null; }
    S.revealed = -1; S.resultShown = false;
    if (Anim.on()) { S.stage.classList.remove('enter'); void S.stage.offsetWidth; S.stage.classList.add('enter'); }
    Amb.start(S.gameId);
    S.stage.querySelectorAll('.overlay').forEach((e) => e.remove());
    setState(S.def.init(clone(S.players.map((p) => ({ name: p.name, color: p.color, ai: !!p.ai, lv: p.ai ? (p.lv || 2) : 0 }))), clone(S.opts)));
  }
  L._rematch = rematch;
  /* ---------- 실시간 게임 일시정지 (라운드 50: 로컬은 누구나, 온라인은 방장만 — 게스트는 「방장이 잠시 멈춤」) ---------- */
  const isRT = () => !!(S && (S.def.realtime || (S.def.realtimeIf && S.def.realtimeIf(S.opts))));
  const canPause = () => !!(S && (S.mode === 'local' || S.mode === 'host') && isRT() && S.state && !S.def.result(S.state));
  const pauseFns = new Set();
  function setPaused(on, why) {
    if (!S) return;
    if (on && !canPause() && why !== 'guest') return;
    if (on === Clock.paused) return;
    if (on) Clock.pause(); else Clock.resume();
    S.rtPaused = on;
    if (S.mode === 'host') Net.pub({ pz: on ? 1 : 0 });
    pauseFns.forEach((f) => { try { f(!!on); } catch (e) { console.error(e); } });
    Music.setPaused(!!on); Amb.setPaused(!!on);
    try { window.dispatchEvent(new CustomEvent(on ? 'lounge-pause' : 'lounge-resume')); } catch (e) {}
    try { if (S.view && S.view[on ? 'pause' : 'resume']) S.view[on ? 'pause' : 'resume'](); } catch (e) { console.error(e); }
  }
  function pauseSheet() {
    if (!canPause() || document.querySelector('.overlay.pause-ov')) return;
    setPaused(true);
    const done = () => { o.remove(); resumeCountdown(); };
    const o = overlay(h('div', { class: 'sheet', style: { alignItems: 'stretch' } },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '일시정지' }), h('h2', { text: S.def.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: done })),
      h('button', { class: 'btn primary block', text: '▶ 계속하기', onclick: done }),
      h('button', { class: 'btn block', text: '규칙 보기', onclick() { o.remove(); const r = rulesSheet(S.gameId, S.stage); watchRemoved(r, () => { if (S) pauseSheetKeep(); }); } }),
      S.def.codex ? h('button', { class: 'btn block', text: '📖 도감', onclick() { o.remove(); const r = codexSheet(S.gameId, S.stage); watchRemoved(r, () => { if (S) pauseSheetKeep(); }); } }) : null,
      Saves.can(S) ? h('button', { class: 'btn block', text: '💾 저장하고 나가기', onclick() { o.remove(); saveSheet(() => { setPaused(false); homeScreen(); }); } }) : null,
      h('button', { class: 'btn block', text: '⚙ 설정', onclick() { o.remove(); settingsSheet(() => { if (S) pauseSheetKeep(); }); } }),
      soundBtn(),
      h('button', { class: 'btn danger block', text: S.mode === 'host' ? '로비로 돌아가기' : '게임 나가기', onclick() { o.remove(); const host = S.mode === 'host'; setPaused(false); host ? Net.backToLobby() : homeScreen(); } })), { cls: 'pause-ov', parent: S.stage });
    if (S.mode === 'host') o.querySelector('.sheet').append(h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: '온라인 판 — 다른 사람들 화면도 함께 멈춰요.' }));
    o.addEventListener('click', (e) => { if (e.target === o) done(); });
    function pauseSheetKeep() { if (document.querySelector('.overlay.pause-ov')) return; const o2 = pauseSheetOpen(); if (!o2 && Clock.paused) resumeCountdown(); }
  }
  function soundBtn() {
    const b = h('button', { class: 'btn block', text: Sfx.on ? '♪ 소리 끄기' : '♩ 소리 켜기', onclick() { Sfx.on = !Sfx.on; store.set('sound', Sfx.on); b.textContent = Sfx.on ? '♪ 소리 끄기' : '♩ 소리 켜기'; } });
    return b;
  }
  /* 라운드 55: 게임 메뉴(Esc · ☰) — 멈출 수 있는 실시간 판은 일시정지 화면, 그 밖(턴제·온라인 게스트 등)은 멈추지 않는 메뉴 */
  function gameMenu() {
    if (!S || !S.stage) return;
    if (document.querySelector('.overlay.gmenu-ov,.overlay.pause-ov')) return;
    if (canPause()) return pauseSheet();
    const me = S;
    const close = () => o.remove();
    const reopen = () => { if (S === me) gameMenu(); };
    const tt = S.turnEl && !S.turnEl.hidden ? S.turnEl.textContent : '';
    const o = overlay(h('div', { class: 'sheet', style: { alignItems: 'stretch' } },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '게임 메뉴' + (S.mode === 'local' ? '' : Net.lan ? ' · LAN 방' : ' · 방 ' + (Net.code || '')) }), h('h2', { text: S.def.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      tt ? h('p', { class: 'muted', style: { margin: 0 }, text: '지금: ' + tt }) : null,
      isRT() && S.mode !== 'local' ? h('p', { class: 'muted', style: { margin: 0, fontSize: '13px' }, text: S.mode === 'guest' ? '온라인 판은 멈추지 않아요 — 게임은 계속 진행 중이에요.' : '판은 계속 진행 중이에요.' }) : null,
      h('button', { class: 'btn primary block', text: '▶ 계속하기', onclick: close }),
      h('button', { class: 'btn block', text: '규칙 보기 (F1)', onclick() { o.remove(); const r = helpSheet(S.gameId, S.stage); watchRemoved(r, reopen); } }),
      S.def.codex ? h('button', { class: 'btn block', text: '📖 도감', onclick() { o.remove(); const r = codexSheet(S.gameId, S.stage); watchRemoved(r, reopen); } }) : null,
      undoOk() ? h('button', { class: 'btn block', text: '↶ 무르기', onclick() { o.remove(); doUndo(); } }) : null,
      h('button', { class: 'btn block', text: '⚙ 설정', onclick() { o.remove(); settingsSheet(reopen); } }),
      soundBtn(),
      Saves.can(S) && !S.def.result(S.state) ? h('button', { class: 'btn block', text: '💾 저장하고 나가기', onclick() { o.remove(); saveSheet(() => { if (S && S.mode === 'host') Net.backToLobby(); else homeScreen(); }); } }) : null,
      h('button', { class: 'btn danger block', text: S.mode === 'host' ? '로비로 돌아가기' : S.mode === 'guest' ? '방 나가기' : '게임 나가기', onclick() { o.remove(); leaveGame(); } })), { cls: 'gmenu-ov', parent: S.stage });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.gameMenu = () => gameMenu();
  /* 다시 시작 전 3초 세기(멈춘 채로 세고 끝나면 풀기) */
  function resumeCountdown() {
    if (!S || !Clock.paused) return;
    const me = S;
    if (S.mode === 'host') Net.pub({ pz: 2 });
    let n = 3;
    const el = h('div', { class: 'overlay cd-ov', 'data-core': '1' }, h('div', { class: 'cd-n', text: '3' }));
    S.stage.appendChild(el);
    const tick = () => {
      if (S !== me || !el.isConnected) { el.remove(); return; }
      n--;
      if (n <= 0) { el.remove(); Sfx.play('go'); setPaused(false); return; }
      el.firstChild.textContent = String(n); el.firstChild.style.animation = 'none'; void el.firstChild.offsetWidth; el.firstChild.style.animation = '';
      Sfx.play('count'); setTimeout(tick, 1000);
    };
    Sfx.play('count'); setTimeout(tick, 1000);
  }
  function pauseSheetOpen() { pauseSheet(); return document.querySelector('.overlay.pause-ov'); }
  /* 게스트: 방장이 멈추면(presence.pz 1=멈춤, 2=곧 다시) 같이 멈추고 안내 */
  function guestPause(pz) {
    if (!S || S.mode !== 'guest' || !isRT()) return;
    let o = S.stage.querySelector('.overlay.gpause-ov');
    if (pz) {
      if (!Clock.paused) setPaused(true, 'guest');
      if (!o) {
        o = overlay(h('div', { class: 'sheet', style: { alignItems: 'center', textAlign: 'center' } },
          h('span', { class: 'label', text: '일시정지' }), h('h2', { class: 'gp-t', text: '방장이 잠시 멈춤' }),
          h('p', { class: 'muted gp-s', style: { margin: 0 }, text: '방장이 다시 시작하면 이어서 해요.' }),
          h('button', { class: 'btn ghost', text: '방 나가기', onclick() { Net.leave(); homeScreen(); } })), { cls: 'gpause-ov', parent: S.stage });
      }
      o.querySelector('.gp-s').textContent = pz === 2 ? '곧 다시 시작해요 — 준비!' : '방장이 다시 시작하면 이어서 해요.';
    } else {
      if (o) o.remove();
      if (Clock.paused) setPaused(false, 'guest');
    }
  }
  function watchRemoved(el, fn) {   // 시트가 닫히면(DOM에서 빠지면) fn
    if (!el || !el.parentNode) return;
    const mo = new MutationObserver(() => { if (!el.isConnected) { mo.disconnect(); fn(); } });
    mo.observe(el.parentNode, { childList: true });
  }
  L.pause = () => pauseSheet();
  document.addEventListener('visibilitychange', () => { if (document.hidden && S && S.mode === 'local' && canPause() && !Clock.paused && S.def.autoPause !== false) pauseSheet(); });   // def.autoPause:false = 창이 가려져도 멈추지 않음

  function leaveGame() {
    if (!S) return homeScreen();
    if (canPause()) return pauseSheet();   // 혼자 하는 실시간 판: 나가기 대신 일시정지 화면(여기서 나가기)
    const go = () => { if (S && S.mode === 'host') Net.backToLobby(); else homeScreen(); };
    if (S.def.result(S.state) || S.mode === 'guest' && !S.state) return go();
    if (Saves.can(S)) {
      const o = overlay(h('div', { class: 'sheet' }, h('h2', { text: S.mode === 'host' ? '로비로 돌아갈까요?' : '게임을 나갈까요?' }),
        h('p', { class: 'muted', style: { margin: 0 }, text: (S.mode === 'host' ? '진행 중인 판은 모두에게서 끝나요. ' : '') + '저장해 두면 나중에 「이어하기」로 계속할 수 있어요(자동 저장 칸도 있어요).' }),
        h('button', { class: 'btn primary block', text: '💾 저장하고 나가기', onclick() { o.remove(); saveSheet(go); } }),
        h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
          h('button', { class: 'btn ghost', text: '취소', onclick: () => o.remove() }),
          h('button', { class: 'btn danger', text: '그냥 나가기', onclick() { o.remove(); go(); } }))));
      return;
    }
    confirmSheet(S.mode === 'host' ? '로비로 돌아갈까요?' : '게임을 나갈까요?', S.mode === 'host' ? '진행 중인 판은 모두에게서 끝납니다.' : '진행 중인 판은 저장되지 않아요.', '나가기', go);
  }

  /* ---------- 라운드 41: 큰 상태 전송(Wire) ----------
     작은 값(JSON ZMIN자 미만)은 그대로 보내고, 큰 값은 deflate-raw(CompressionStream) + base64 문자열 {$z}로,
     압축을 못 하는 브라우저면 JSON 문자열 {$j}로 보낸다(아티팩트 presence의 키 64개·배열 64칸 제한도 피함). */
  const Wire = {
    ZMIN: 2400, PRES_MAX: 3900, CHUNK: 3000, CHUNK_GAP: 200,
    TURN_MAX: 48 * 1024, RT_MAX: 24 * 1024,   // 권장 상한(테스트 경고 기준)
    BIG: { st: 1, hs: 1, g: 1 },
    te: new TextEncoder(), cache: {},
    bytes(v) { return v == null ? 0 : Wire.te.encode(JSON.stringify(v)).length; },
    b64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); },
    unb64(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; },
    async pipe(u8, T) { return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(T)).arrayBuffer()); },
    async pack(v) {
      if (v == null || typeof v !== 'object') return v;
      const js = JSON.stringify(v);
      if (js.length < Wire.ZMIN) return v;
      const c = Wire.cache; if (c.js === js) return c.out;
      let out = null;
      if (window.CompressionStream) { try { out = { $z: Wire.b64(await Wire.pipe(Wire.te.encode(js), new CompressionStream('deflate-raw'))) }; } catch (e) { out = null; } }
      if (!out) out = { $j: js };
      Wire.cache = { js, out };
      return out;
    },
    async unpack(pk) {
      if (pk && pk.$j != null) return JSON.parse(pk.$j);
      if (!pk || !pk.$z) return pk;
      return JSON.parse(new TextDecoder().decode(await Wire.pipe(Wire.unb64(pk.$z), new DecompressionStream('deflate-raw'))));
    },
  };
  L.wire = Wire;

  /* ---------- 라운드 41: 기기끼리 파일 보내기(Xfer, 시험 기능) ----------
     PeerJS(설치형 앱의 온라인 방과 같은 경로)로 4글자 코드 방을 따로 열고, 큰 바이트 덩어리를 조각으로 보낸다.
     서버에는 아무것도 저장하지 않는다(연결 중개만). 순서·유실: 받는 쪽이 조각 번호로 모으고 빠진 조각은 다시 요청.
     흐름 제어: 받는 쪽이 받은 개수를 알려 주고(ack) 보내는 쪽은 아직 확인 안 된 조각을 WIN개까지만 띄워 둔다.
     끝나면 SHA-256(가능하면)·FNV 해시로 검사. L.xfer.send(bytes, meta, {onCode, onProgress}) / L.xfer.recv(code, {onProgress}). */
  const Xfer = {
    CHUNK: 48 * 1024, WIN: 24, PREFIX: 'hanpan-lounge-x1-', IDLE: 20000,
    available() { return !!window.Peer; },
    why() { return window.claude && window.claude.use ? '이 기능은 설치형 앱(폰 앱·PC 앱)에서만 돼요. 아티팩트 방으로는 큰 파일을 보낼 수 없어요.' : '이 기능은 설치형 앱(폰 앱·PC 앱)에서만 돼요.'; },
    fnv(u8) { let a = 0x811c9dc5, b = 0x01000193 ^ u8.length; for (let i = 0; i < u8.length; i++) { a ^= u8[i]; a = Math.imul(a, 16777619); b = Math.imul(b ^ u8[i], 2246822519) + i | 0; } return (a >>> 0).toString(16) + '-' + (b >>> 0).toString(16); },
    async sha(u8) { try { if (!(window.crypto && crypto.subtle)) return null; const d = new Uint8Array(await crypto.subtle.digest('SHA-256', u8)); return Array.from(d, (x) => x.toString(16).padStart(2, '0')).join(''); } catch (e) { return null; } },
    code() { return Array.from({ length: 4 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random() * 23)]).join(''); },
    err(e) { const m = { notfound: '그 코드로 보내는 기기를 찾지 못했어요.', taken: '코드가 겹쳤어요. 다시 해 주세요.', network: '인터넷 연결을 확인해 주세요.', closed: '연결이 끊겼어요.', idle: '한동안 응답이 없어서 멈췄어요.', hash: '받은 파일이 깨졌어요(검사 실패). 다시 받아 주세요.', cancel: '상대가 취소했어요.', big: '파일이 너무 커요.' }; return m[e && e.message] || '전송하지 못했어요.'; },
    peer(id) {
      return new Promise((res, rej) => {
        const P = id ? new window.Peer(id) : new window.Peer();
        const t = setTimeout(() => { try { P.destroy(); } catch (e) {} rej(new Error('network')); }, 12000);
        P.on('open', () => { clearTimeout(t); res(P); });
        P.on('error', (e) => { clearTimeout(t); const ty = e && e.type; rej(new Error(ty === 'unavailable-id' ? 'taken' : ty === 'peer-unavailable' ? 'notfound' : 'network')); });
      });
    },
    send(bytes, meta, cb) {
      cb = cb || {};
      const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
      const n = Math.ceil(u8.length / Xfer.CHUNK);
      let P = null, conn = null, over = false, idleT = 0, resolveF, rejectF;
      const done = new Promise((res, rej) => { resolveF = res; rejectF = rej; });
      const finish = (e) => { if (over) return; over = true; clearTimeout(idleT); setTimeout(() => { try { P && P.destroy(); } catch (x) {} }, 400); if (e) rejectF(e); else resolveF(); };
      const idle = () => { clearTimeout(idleT); idleT = setTimeout(() => finish(new Error('idle')), Xfer.IDLE); };
      const piece = (i) => u8.slice(i * Xfer.CHUNK, Math.min(u8.length, (i + 1) * Xfer.CHUNK)).buffer;
      (async () => {
        const hash = { f: Xfer.fnv(u8), s: await Xfer.sha(u8) };
        let code = null;
        for (let k = 0; k < 4 && !P; k++) { code = Xfer.code(); try { P = await Xfer.peer(Xfer.PREFIX + code); } catch (e) { if (e.message !== 'taken' || k === 3) return finish(e); } }
        if (over) { try { P.destroy(); } catch (e) {} return; }
        if (cb.onCode) cb.onCode(code);
        P.on('disconnected', () => { try { if (!over) P.reconnect(); } catch (e) {} });
        P.on('connection', (c) => {
          if (conn || over) { c.on('open', () => { try { c.send({ t: 'busy' }); } catch (e) {} setTimeout(() => c.close(), 300); }); return; }
          conn = c;
          let next = 0, acked = 0;
          const pump = () => { while (!over && next < n && next - acked < Xfer.WIN) { c.send({ t: 'd', i: next, b: piece(next) }); next++; } };
          c.on('open', () => { idle(); c.send({ t: 'meta', meta, size: u8.length, n, cs: Xfer.CHUNK, hash }); if (cb.onProgress) cb.onProgress(0, u8.length, 'wait'); });
          c.on('data', (m) => {
            if (!m || over) return; idle();
            if (m.t === 'go') pump();
            else if (m.t === 'ack') { acked = Math.max(acked, m.k | 0); if (cb.onProgress) cb.onProgress(Math.min(u8.length, acked * Xfer.CHUNK), u8.length, 'send'); pump(); }
            else if (m.t === 'need' && Array.isArray(m.l)) m.l.slice(0, 200).forEach((i) => { if (i >= 0 && i < n) c.send({ t: 'd', i, b: piece(i) }); });
            else if (m.t === 'ok') { if (cb.onProgress) cb.onProgress(u8.length, u8.length, 'done'); finish(); }
            else if (m.t === 'bad') finish(new Error('hash'));
            else if (m.t === 'cancel') finish(new Error('cancel'));
          });
          c.on('close', () => finish(new Error('closed')));
          c.on('error', () => finish(new Error('closed')));
        });
      })().catch((e) => finish(e));
      return { done, cancel() { if (over) return; try { conn && conn.open && conn.send({ t: 'cancel' }); } catch (e) {} finish(new Error('mine')); } };
    },
    recv(code, cb) {
      cb = cb || {};
      let P = null, c = null, over = false, idleT = 0, resolveF, rejectF;
      const done = new Promise((res, rej) => { resolveF = res; rejectF = rej; });
      const finish = (e, v) => { if (over) return; over = true; clearTimeout(idleT); setTimeout(() => { try { P && P.destroy(); } catch (x) {} }, 400); if (e) rejectF(e); else resolveF(v); };
      (async () => {
        P = await Xfer.peer();
        if (over) { try { P.destroy(); } catch (e) {} return; }
        P.on('error', (e) => { if (e && e.type === 'peer-unavailable') finish(new Error('notfound')); });
        c = P.connect(Xfer.PREFIX + String(code).toUpperCase(), { reliable: true });
        let info = null, buf = null, got = null, cnt = 0, k = 0, lastAck = 0;
        const idle = () => { clearTimeout(idleT); idleT = setTimeout(() => {
          if (info && cnt < info.n && !over) { const l = []; for (let i = 0; i < info.n && l.length < 200; i++) if (!got[i]) l.push(i); try { c.send({ t: 'need', l }); } catch (e) {} idleT = setTimeout(() => finish(new Error('idle')), Xfer.IDLE); return; }
          finish(new Error('idle'));
        }, info ? 8000 : Xfer.IDLE); };
        idle();
        c.on('open', idle);
        c.on('data', async (m) => {
          if (!m || over) return; idle();
          if (m.t === 'busy') return finish(new Error('notfound'));
          if (m.t === 'cancel') return finish(new Error('cancel'));
          if (m.t === 'meta') {
            if (!(m.size > 0 && m.size <= 200e6) || !(m.n > 0) || !(m.cs > 0)) return finish(new Error('big'));
            info = m; buf = new Uint8Array(m.size); got = new Uint8Array(m.n);
            if (cb.onMeta) cb.onMeta(m.meta, m.size);
            c.send({ t: 'go' }); return;
          }
          if (m.t !== 'd' || !info) return;
          const i = m.i | 0, b = new Uint8Array(m.b instanceof ArrayBuffer ? m.b : (m.b && m.b.buffer ? m.b.buffer.slice(m.b.byteOffset, m.b.byteOffset + m.b.byteLength) : new ArrayBuffer(0)));
          if (i < 0 || i >= info.n || got[i] || i * info.cs + b.length > info.size) return;
          buf.set(b, i * info.cs); got[i] = 1; cnt++;
          while (k < info.n && got[k]) k++;
          if (k - lastAck >= 8 || cnt === info.n) { lastAck = k; c.send({ t: 'ack', k }); }
          if (cb.onProgress) cb.onProgress(Math.min(info.size, cnt * info.cs), info.size, 'recv');
          if (cnt === info.n) {
            clearTimeout(idleT);
            const okF = Xfer.fnv(buf) === info.hash.f;
            const s = info.hash.s ? await Xfer.sha(buf) : null;
            const ok = okF && (!s || s === info.hash.s);
            try { c.send({ t: ok ? 'ok' : 'bad' }); } catch (e) {}
            if (ok) finish(null, { meta: info.meta, bytes: buf, sha: !!s }); else finish(new Error('hash'));
          }
        });
        c.on('close', () => finish(new Error('closed')));
      })().catch((e) => finish(e));
      return { done, cancel() { if (over) return; try { c && c.open && c.send({ t: 'cancel' }); } catch (e) {} finish(new Error('mine')); } };
    },
  };
  L.xfer = Xfer;

  /* ---------- online: artifact room capability ---------- */
  const Net = {
    room: null, r: null, code: null, role: null, peer: null, unsub: [], k: 0, lastK: {}, lobby: null,
    pending: {}, pubTimer: 0, pubBusy: false, shadow: null, cid: 0, outC: {}, outIds: [], inC: {}, waitC: {}, zc: {}, reSent: {}, need: null, hostSeen: 0, guestOrder: [], stVer: -1,
    async getRoom() {
      if (this.room) return this.room;
      if (window.claude && typeof window.claude.use === 'function') {
        try { this.room = await window.claude.use('room'); } catch (e) { this.room = null; }
      } else if (window.Peer) this.room = peerRoom();
      return this.room;
    },
    async open(code, asHost) {
      const room = await this.getRoom();
      if (!room) throw new Error('noroom');
      this.code = code;
      this.r = await room.join('hl-' + code.toLowerCase(), asHost);
      if (!this.r.star && this.r.on) {
        try { this.unsub.push(this.r.on('hlz', (m) => this.onChunk(m))); } catch (e) {}
        this.unsub.push(this.r.onPeers((ch) => this.onNeed(ch.peers || []), () => {}));
      }
      return this.r;
    },
    myPeer() {
      if (!this.r) return null;
      const me = this.r.peers().find((p) => p.sameTab);
      if (me) this.peer = me.peer;
      return this.peer;
    },
    /* 라운드 41: 큰 필드(st·hs·g)는 Wire로 압축({$z}) — 작은 값은 예전 그대로. 아티팩트 room(presence 4KiB)에서
       넘치면 emit 조각({$c})으로 보낸다. 보내기는 한 번에 하나씩(순서 보장), 그동안 온 patch는 합쳐서 다음에 보낸다. */
    pub(patch) {
      if (!this.r) return;
      Object.assign(this.pending, patch);
      this.kick();
    },
    kick() {
      if (this.pubTimer || this.pubBusy || !this.r) return;
      this.pubTimer = setTimeout(async () => {
        this.pubTimer = 0;
        const p = this.pending; this.pending = {};
        if (!this.r || !Object.keys(p).length) return;
        this.pubBusy = true;
        const r = this.r;
        try { await this.flushPub(r, p); } catch (e) { console.warn('pub', e); }
        if (this.r === r) { this.pubBusy = false; if (Object.keys(this.pending).length) this.kick(); }
      }, 45);
    },
    async flushPub(r, p) {
      const out = {};
      for (const k in p) out[k] = Wire.BIG[k] ? await Wire.pack(p[k]) : p[k];
      if (!r.star && r.emit) {   // 아티팩트 room: 합친 presence가 한도를 넘으면 큰 필드를 emit 조각으로
        const sh = Object.assign({}, this.shadow || {});
        for (const k in out) { if (out[k] === null) delete sh[k]; else sh[k] = out[k]; }
        let size = Wire.bytes(sh);
        const big = Object.keys(out).filter((k) => out[k] && (out[k].$z || out[k].$j != null)).sort((a, b) => Wire.bytes(out[b]) - Wire.bytes(out[a]));
        for (const k of big) {
          if (size <= Wire.PRES_MAX) break;
          const wait = (this.lastChunk || 0) + Wire.CHUNK_GAP - Date.now();
          if (wait > 0) await new Promise((res) => setTimeout(res, wait));
          const before = Wire.bytes(sh[k]);
          sh[k] = out[k] = this.chunkOut(r, out[k]);
          size += Wire.bytes(sh[k]) - before;
        }
        this.shadow = sh;
      }
      if (this.r !== r) return;
      await r.presence(out).catch((e) => {
        console.warn('presence', e);
        if (e && e.code === 'invalid_argument') toast('상태가 너무 커서 전송하지 못했어요');
      });
    },
    chunkOut(r, packed) {
      const txt = JSON.stringify(packed), id = (++this.cid).toString(36) + Math.random().toString(36).slice(2, 5);
      const parts = []; for (let i = 0; i < txt.length; i += Wire.CHUNK) parts.push(txt.slice(i, i + Wire.CHUNK));
      this.outC[id] = parts; this.outIds.push(id);
      while (this.outIds.length > 12) delete this.outC[this.outIds.shift()];
      this.lastChunk = Date.now();
      this.emitC(r, id);
      return { $c: id, n: parts.length };
    },
    emitC(r, id, only) {
      const parts = this.outC[id]; if (!parts || !r) return;
      parts.forEach((d, i) => {
        if (only && !only.includes(i)) return;
        r.emit('hlz', { id, i, n: parts.length, d }).catch((e) => { if (e && e.code === 'not_permitted' && !this.warnedC) { this.warnedC = true; toast('이 방(아티팩트)에선 큰 게임 상태를 보낼 수 없어요. 설치형 앱으로 해 주세요.'); } });
      });
    },
    onChunk(m) {
      const d = m && m.data; if (!d || typeof d.id !== 'string' || typeof d.d !== 'string' || !(d.n > 0 && d.n < 400) || !(d.i >= 0 && d.i < d.n)) return;
      const c = this.inC[d.id] || (this.inC[d.id] = { n: d.n, p: [], got: 0 });
      if (c.p[d.i] == null) { c.p[d.i] = d.d; c.got++; }
      const ids = Object.keys(this.inC); if (ids.length > 40) ids.slice(0, ids.length - 40).forEach((k) => { delete this.inC[k]; });
      if (c.got === c.n && this.waitC[d.id]) { const f = this.waitC[d.id]; delete this.waitC[d.id]; f(); }
    },
    /* 상대 presence의 압축·조각 필드를 풀어서 돌려준다. 푸는 중이면 직전 값(처음이면 null), 다 풀리면 다시 그린다. */
    field(peer, f, raw) {
      if (!raw || typeof raw !== 'object' || !(raw.$z || raw.$c || raw.$j != null)) return raw;
      const key = peer + '|' + f, c = this.zc[key] || (this.zc[key] = { tok: null, val: null });
      const tok = raw.$c ? 'c' + raw.$c : raw.$z ? 'z' + raw.$z : 'j' + raw.$j;
      if (c.tok === tok) return c.val;
      c.tok = tok;
      if (raw.$j != null) { try { c.val = JSON.parse(raw.$j); } catch (e) {} return c.val; }
      const done = (v) => { if (c.tok !== tok) return; c.val = v; this.decoded(); };
      if (raw.$z) { Wire.unpack(raw).then(done, (e) => console.warn('unz', e)); return c.val; }
      const id = raw.$c;
      const fin = () => {
        const ch = this.inC[id]; let pk; try { pk = JSON.parse(ch.p.join('')); } catch (e) { return; }
        if (this.need === id) { this.need = null; this.pub({ zneed: null }); }
        Wire.unpack(pk).then(done, (e) => console.warn('unc', e));
      };
      const ch = this.inC[id];
      if (ch && ch.got === ch.n) fin();
      else {
        this.waitC[id] = fin;
        const ask = (tries) => setTimeout(() => {
          if (!this.waitC[id] || c.tok !== tok || !this.r) return;
          const cc = this.inC[id]; this.need = id;
          this.pub({ zneed: { id, miss: cc ? Array.from({ length: cc.n }, (_, i) => i).filter((i) => cc.p[i] == null).slice(0, 60) : null, k: tries } });
          if (tries < 8) ask(tries + 1);
        }, 900);
        ask(1);
      }
      return c.val;
    },
    decoded() { if (this.decT) return; this.decT = setTimeout(() => { this.decT = 0; if (this.role === 'g') onGuestPeers(); }, 0); },
    onNeed(peers) {   // 조각을 못 받은 사람이 zneed로 알려 오면 그 조각만 다시
      for (const p of peers) {
        const z = p.presence && p.presence.zneed;
        if (p.sameTab || !z || typeof z.id !== 'string' || !this.outC[z.id]) continue;
        const k = p.peer + z.id + (z.k || 0); if (this.reSent[k]) continue;
        this.reSent[k] = 1; this.emitC(this.r, z.id, Array.isArray(z.miss) && z.miss.length ? z.miss : null);
      }
    },
    leave() {
      this.unsub.forEach((u) => { try { u(); } catch (e) {} });
      this.unsub = [];
      if (this.r) { try { this.r.leave(); } catch (e) {} }
      this.r = null; this.role = null; this.code = null; this.lobby = null; this.lastK = {}; this.guestOrder = []; this.stVer = -1; this.pending = {}; this.lobbySig = null; this.lan = false;
      clearTimeout(this.pubTimer); this.pubTimer = 0; this.pubBusy = false; this.shadow = null; this.outC = {}; this.outIds = []; this.inC = {}; this.waitC = {}; this.zc = {}; this.reSent = {}; this.need = null;
      this.myVote = null; this.voteUI = null; this.voteSig = null; this.voteLeft = 0; this.voteDone = -1;
    },
    hostPeer() { return this.r ? this.r.peers().find((p) => p.presence && p.presence.role === 'h' && !p.sameTab) : null; },
    hostField(f) { const hp = this.hostPeer(); return hp && hp.presence ? (Wire.BIG[f] ? this.field(hp.peer, f, hp.presence[f]) : hp.presence[f]) : null; },
    remoteG() {
      const out = {};
      if (!this.r || !this.lobby) return out;
      for (const p of this.r.peers()) {
        if (p.sameTab || !p.presence || !p.presence.g) continue;
        this.lobby.seats.forEach((s, i) => { if (s.p === p.peer) out[i] = this.field(p.peer, 'g', p.presence.g); });
      }
      return out;
    },
    pubState() {
      if (this.role !== 'h' || !S) return;
      this.pub({ st: { v: S.ver, s: S.state }, lobby: this.lobby });
    },
    sendAct(seat, a) { this.k++; this.pub({ act: { k: this.k, seat, a } }); },
    backToLobby() {
      if (this.role !== 'h') return homeScreen();
      endSession();
      this.lobby.started = null; this.lobbySig = null;
      this.pub({ lobby: this.lobby, st: null });
      hostLobby(true);
    },
  };
  L.net = Net;

  /* Star of connections around the host, exposing the same join/presence/peers/onPeers
     surface the artifact `room` capability offers. A connection is {peer, open, send(m), on(ev, f)}. */
  function makeStar(asHost, onClosed) {
    const roster = new Map(); // peerId -> presence
    const conns = new Map(); // host: guestId -> conn
    let hostConn = null, myId = null, mine = {}, alive = true;
    let J = [], U = [], Lf = [], sched = false;
    const hs = [];
    const mk = (id, p) => ({ peer: id, by: null, isMe: id === myId, sameTab: id === myId, kind: 'viewer', guest: false, presence: p || {}, updatedAt: Date.now() });
    const list = () => [...roster.entries()].map(([id, p]) => mk(id, p));
    function flush() { sched = false; const ch = { peers: list(), joined: J, updated: U, left: Lf }; J = []; U = []; Lf = []; hs.forEach((f) => { try { f(ch); } catch (e) { console.error(e); } }); }
    function q() { if (!sched) { sched = true; setTimeout(flush, 16); } }
    function setP(id, p) { const had = roster.has(id); roster.set(id, p); (had ? U : J).push(mk(id, p)); q(); }
    function drop(id) { if (!roster.has(id)) return; roster.delete(id); Lf.push(mk(id, {})); q(); }
    function send(c, m) { try { if (c && c.open) c.send(m); } catch (e) {} }
    const R = {
      presence(patch) {
        for (const k in patch) { if (patch[k] === null) delete mine[k]; else mine[k] = patch[k]; }
        const p = JSON.parse(JSON.stringify(mine));
        if (myId) setP(myId, p);
        if (asHost) conns.forEach((c) => send(c, { t: 'pres', peer: myId, p }));
        else send(hostConn, { t: 'pres', p });
        return Promise.resolve();
      },
      peers: list,
      onPeers(f) { hs.push(f); setTimeout(() => f({ peers: list(), joined: list(), updated: [], left: [] }), 0); return () => { const i = hs.indexOf(f); if (i >= 0) hs.splice(i, 1); }; },
      emit() { return Promise.resolve(); }, on() { return () => {}; },
      connected() { return alive && (asHost || !!(hostConn && hostConn.open)); },
      onConnection(f) { setTimeout(() => f(R.connected())); return () => {}; },
      leave() { alive = false; if (onClosed) onClosed(); return Promise.resolve(); },
      star: true,
    };
    return {
      R,
      setId(id) { myId = id; roster.set(id, JSON.parse(JSON.stringify(mine))); },
      addGuest(c) { // host side
        const opened = () => {
          if (conns.has(c.peer)) return;
          conns.set(c.peer, c);
          send(c, { t: 'roster', list: [...roster.entries()].map(([peer, p]) => ({ peer, p })) });
        };
        c.on('open', opened); if (c.open) opened();
        c.on('data', (m) => {
          if (!m || m.t !== 'pres' || !m.p || typeof m.p !== 'object') return;
          setP(c.peer, m.p);
          conns.forEach((o, id) => { if (id !== c.peer) send(o, { t: 'pres', peer: c.peer, p: m.p }); });
        });
        const gone = () => { if (!conns.has(c.peer)) return; conns.delete(c.peer); drop(c.peer); conns.forEach((o) => send(o, { t: 'leave', peer: c.peer })); };
        c.on('close', gone); c.on('error', gone);
      },
      setHost(c) { // guest side
        hostConn = c;
        const opened = () => send(c, { t: 'pres', p: mine });
        c.on('open', opened); if (c.open) opened();
        c.on('data', (m) => {
          if (!m || typeof m !== 'object') return;
          if (m.t === 'roster' && Array.isArray(m.list)) m.list.forEach((e) => { if (e.peer !== myId) setP(e.peer, e.p); });
          else if (m.t === 'pres' && m.peer !== myId) setP(m.peer, m.p);
          else if (m.t === 'leave') drop(m.peer);
        });
        c.on('close', () => { [...roster.keys()].forEach((k) => { if (k !== myId) drop(k); }); });
      },
    };
  }

  /* Internet transport for the installed app: PeerJS (WebRTC via a public signalling server). */
  function peerRoom() {
    const PREFIX = 'hanpan-lounge-v1-';
    return {
      join(name, asHost) {
        return new Promise((resolve, reject) => {
          const hostId = PREFIX + name;
          const peer = asHost ? new window.Peer(hostId) : new window.Peer();
          const star = makeStar(asHost, () => { try { peer.destroy(); } catch (e) {} });
          let settled = false;
          const fail = (err) => { if (!settled) { settled = true; reject(err); try { peer.destroy(); } catch (e) {} } };
          const timer = setTimeout(() => fail(new Error(asHost ? 'timeout' : 'notfound')), 12000);
          const ok = () => { clearTimeout(timer); settled = true; resolve(star.R); };
          peer.on('open', (id) => {
            star.setId(id);
            if (asHost) return ok();
            const c = peer.connect(hostId, { reliable: true });
            c.on('open', ok);
            star.setHost(c);
          });
          if (asHost) peer.on('connection', (c) => star.addGuest(c));
          peer.on('disconnected', () => { try { peer.reconnect(); } catch (e) {} });
          peer.on('error', (e) => {
            const t = e && e.type;
            if (t === 'peer-unavailable') fail(new Error('notfound'));
            else if (t === 'unavailable-id') fail(new Error('taken'));
            else if (!settled) fail(new Error('network'));
            else console.warn('peer', t);
          });
        });
      },
    };
  }

  /* LAN transport for the installed app: direct WebRTC with no servers at all. The host and each
     guest swap a connection code (shown as a QR) once; devices must be on the same Wi-Fi. */
  const Lan = {
    async encode(obj) {
      const raw = new TextEncoder().encode(JSON.stringify(obj));
      let bytes = raw, tag = 'J';
      if (window.CompressionStream) {
        try {
          const cs = new Blob([raw]).stream().pipeThrough(new CompressionStream('deflate-raw'));
          bytes = new Uint8Array(await new Response(cs).arrayBuffer()); tag = 'Z';
        } catch (e) { bytes = raw; tag = 'J'; }
      }
      let bin = ''; bytes.forEach((b) => { bin += String.fromCharCode(b); });
      return 'HL1' + tag + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    },
    async decode(text) {
      text = String(text || '').trim();
      if (!/^HL1[ZJ]/.test(text)) throw new Error('badcode');
      const tag = text[3];
      const b64 = text.slice(4).replace(/-/g, '+').replace(/_/g, '/');
      const bin = atob(b64 + '==='.slice((b64.length + 3) % 4));
      let bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
      if (tag === 'Z') bytes = new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
      return JSON.parse(new TextDecoder().decode(bytes));
    },
    pc() { return new RTCPeerConnection({ iceServers: [] }); },
    gathered(pc) {
      return new Promise((res) => {
        if (pc.iceGatheringState === 'complete') return res();
        const t = setTimeout(res, 3000);
        pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } });
      });
    },
    wrap(dc, pc, peerId) {
      const hs = {};
      const emit = (n, a) => (hs[n] || []).forEach((f) => { try { f(a); } catch (e) { console.error(e); } });
      let closed = false;
      const close = () => { if (closed) return; closed = true; emit('close'); };
      dc.onopen = () => emit('open');
      // 라운드 41: 16KB 넘는 메시지는 조각("~id,i,n|" + 본문)으로 나눠 보낸다(채널이 ordered·reliable이라 순서대로 온다).
      const MAXM = 16000; let part = null, sid = 0;
      dc.onmessage = (e) => {
        let txt = e.data;
        if (typeof txt === 'string' && txt[0] === '~') {
          const bar = txt.indexOf('|'), hd = txt.slice(1, bar).split(','), i = +hd[1], n = +hd[2];
          if (i === 0) part = { id: hd[0], s: [] };
          if (!part || part.id !== hd[0] || part.s.length !== i) { part = null; return; }
          part.s.push(txt.slice(bar + 1));
          if (part.s.length < n) return;
          txt = part.s.join(''); part = null;
        }
        let m; try { m = JSON.parse(txt); } catch (err) { return; } emit('data', m);
      };
      dc.onclose = close;
      pc.addEventListener('connectionstatechange', () => { if (pc.connectionState === 'failed' || pc.connectionState === 'closed') close(); });
      const sendTxt = (s) => {
        if (s.length <= MAXM) return dc.send(s);
        const id = (++sid).toString(36), n = Math.ceil(s.length / MAXM);
        for (let i = 0; i < n; i++) dc.send('~' + id + ',' + i + ',' + n + '|' + s.slice(i * MAXM, (i + 1) * MAXM));
      };
      return { peer: peerId, get open() { return dc.readyState === 'open'; }, send(m) { sendTxt(JSON.stringify(m)); }, on(n, f) { (hs[n] = hs[n] || []).push(f); } };
    },
    host() {
      const pcs = [];
      const star = makeStar(true, () => pcs.forEach((p) => { try { p.close(); } catch (e) {} }));
      const hostId = 'h' + Math.random().toString(36).slice(2, 8);
      star.setId(hostId);
      let n = 0;
      star.R.invite = async () => {
        const gid = 'g' + (++n) + Math.random().toString(36).slice(2, 5);
        const pc = Lan.pc(); pcs.push(pc);
        const dc = pc.createDataChannel('lounge', { ordered: true });
        const conn = Lan.wrap(dc, pc, gid);
        await pc.setLocalDescription(await pc.createOffer());
        await Lan.gathered(pc);
        const text = await Lan.encode({ s: pc.localDescription.sdp, i: gid, h: hostId });
        return {
          text,
          async accept(answer) {
            const a = await Lan.decode(answer);
            if (a.i !== gid || !a.s) throw new Error('mismatch');
            await pc.setRemoteDescription({ type: 'answer', sdp: a.s });
            star.addGuest(conn);
            return new Promise((res, rej) => { if (conn.open) return res(); conn.on('open', res); setTimeout(() => rej(new Error('lan-timeout')), 15000); });
          },
          cancel() { try { pc.close(); } catch (e) {} },
        };
      };
      return star.R;
    },
    async join(offerText) {
      const o = await Lan.decode(offerText);
      if (!o.s || !o.i || !o.h) throw new Error('badcode');
      const pc = Lan.pc();
      const star = makeStar(false, () => { try { pc.close(); } catch (e) {} });
      star.setId(o.i);
      const ready = new Promise((res, rej) => {
        pc.ondatachannel = (e) => { const c = Lan.wrap(e.channel, pc, o.h); star.setHost(c); c.on('open', () => res(star.R)); };
        setTimeout(() => rej(new Error('lan-timeout')), 120000);
      });
      await pc.setRemoteDescription({ type: 'offer', sdp: o.s });
      await pc.setLocalDescription(await pc.createAnswer());
      await Lan.gathered(pc);
      return { text: await Lan.encode({ s: pc.localDescription.sdp, i: o.i }), ready, cancel() { try { pc.close(); } catch (e) {} } };
    },
  };
  L.lan = Lan;

  /* QR show/scan for LAN pairing (installed app only). Libraries load from CDNs; the app's
     service worker pre-caches them so pairing also works offline after the first install. */
  const LIBS = {
    qr: 'lib/qrcode.min.js',
    jsqr: 'lib/jsQR.js',
  };
  L.LIBS = LIBS;
  const scriptCache = {};
  function loadScript(url) {
    if (!scriptCache[url]) scriptCache[url] = new Promise((res, rej) => {
      const el = document.createElement('script'); el.src = url; el.crossOrigin = 'anonymous';
      el.onload = res; el.onerror = () => { delete scriptCache[url]; rej(new Error('load ' + url)); };
      document.head.appendChild(el);
    });
    return scriptCache[url];
  }
  async function codeBox(text) {
    const box = h('div', { class: 'codebox' });
    try {
      await loadScript(LIBS.qr);
      const q = window.qrcode(0, 'L'); q.addData(text); q.make();
      box.append(h('div', { class: 'qr', html: q.createSvgTag({ cellSize: 4, margin: 3, scalable: true }) }));
    } catch (e) { box.append(h('p', { class: 'note', text: 'QR을 그리지 못했어요. 아래 코드를 복사해서 보내 주세요.' })); }
    const ta = h('textarea', { class: 'codetext mono', readonly: true, rows: 2, 'aria-label': '연결 코드' });
    ta.value = text;
    box.append(h('details', null, h('summary', { text: '카메라가 안 되면: 코드로 주고받기' }), ta,
      h('button', { class: 'btn sm', text: '코드 복사', onclick() {
        ta.select();
        try { navigator.clipboard.writeText(text).then(() => toast('복사했어요'), () => { try { document.execCommand('copy'); toast('복사했어요'); } catch (e) {} }); } catch (e) {}
      } })));
    return box;
  }
  /* Opens the camera and resolves with the first HL1… code it sees (or a pasted one), or null. */
  function scanCode(title) {
    return new Promise((resolve) => {
      let stream = null, timer = 0, done = false, detector = null;
      const video = h('video', { class: 'scanvid', playsinline: true, muted: true, autoplay: true });
      const status = h('p', { class: 'note', style: { margin: 0 }, text: '카메라를 켜는 중…' });
      const paste = h('input', { id: 'paste-code', class: 'mono', placeholder: '또는 받은 코드 붙여넣기', autocomplete: 'off' });
      const finish = (v) => {
        if (done) return; done = true; clearInterval(timer);
        try { stream && stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
        o.remove(); resolve(v);
      };
      const o = overlay(h('div', { class: 'sheet' },
        h('h2', { text: title }), h('div', { class: 'scanwrap' }, video, h('div', { class: 'scanframe' })), status,
        h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, paste, h('button', { class: 'btn sm', text: '확인', onclick() { const v = paste.value.trim(); if (/^HL1[ZJ]/.test(v)) finish(v); else toast('코드가 올바르지 않아요'); } })),
        h('button', { class: 'btn ghost block', text: '취소', onclick: () => finish(null) })));
      (async () => {
        try {
          if ('BarcodeDetector' in window) {
            try { const f = await window.BarcodeDetector.getSupportedFormats(); if (f.includes('qr_code')) detector = new window.BarcodeDetector({ formats: ['qr_code'] }); } catch (e) {}
          }
          if (!detector) await loadScript(LIBS.jsqr);
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
          if (done) { stream.getTracks().forEach((t) => t.stop()); return; }
          video.srcObject = stream; await video.play().catch(() => {});
          status.textContent = 'QR을 네모 안에 맞춰 주세요';
          const cv = document.createElement('canvas'), cx = cv.getContext('2d', { willReadFrequently: true });
          let busy = false;
          timer = setInterval(async () => {
            if (busy || done || !video.videoWidth) return;
            busy = true;
            try {
              let text = null;
              if (detector) { const r = await detector.detect(video); if (r && r[0]) text = r[0].rawValue; }
              else {
                const sc = Math.min(1, 720 / Math.max(video.videoWidth, video.videoHeight));
                cv.width = Math.round(video.videoWidth * sc); cv.height = Math.round(video.videoHeight * sc);
                cx.drawImage(video, 0, 0, cv.width, cv.height);
                const img = cx.getImageData(0, 0, cv.width, cv.height);
                const r = window.jsQR(img.data, cv.width, cv.height, { inversionAttempts: 'dontInvert' });
                if (r) text = r.data;
              }
              if (text && /^HL1[ZJ]/.test(text)) { buzz(30); Sfx.play('pop'); finish(text); }
            } catch (e) {}
            busy = false;
          }, 220);
        } catch (e) {
          status.textContent = '카메라를 쓸 수 없어요. 받은 코드를 붙여넣어 주세요.';
        }
      })();
    });
  }

  function noRoomMsg(err) {
    const m = err && err.message;
    if (m === 'noroom') return L.STANDALONE ? '온라인 연결 기능을 불러오지 못했어요. 인터넷 연결을 확인하고 앱을 다시 열어 주세요.' : '온라인 방은 claude.ai에 로그인한 상태로 이 페이지를 열었을 때 쓸 수 있어요.';
    if (m === 'notfound') return '그 코드의 방을 찾지 못했어요. 코드를 다시 확인해 주세요.';
    if (m === 'taken') return '같은 코드의 방이 이미 있어요. 다시 만들어 주세요.';
    return '방에 연결하지 못했어요. 잠시 후 다시 시도해 주세요.';
  }
  function nameField(id) {
    return h('label', { class: 'field' }, h('span', { class: 'label', text: '내 이름' }),
      h('input', { id, value: myName(), maxlength: 10, placeholder: '예: 정진', autocomplete: 'nickname' }));
  }

  /* host lobby */
  async function hostLobby(resume, lan) {
    let name = myName();
    if (!resume) {
      endSession(); Net.leave();
      if (!name) return askName(() => hostLobby(false, lan));
      const code = Array.from({ length: 4 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random() * 23)]).join('');
      show(h('div', { class: 'screen' }, topbarSimple('방 만들기'), h('div', { class: 'scroll' }, h('p', { class: 'muted', text: '방을 여는 중…' }))));
      if (lan) { Net.r = Lan.host(); Net.code = 'LAN'; Net.lan = true; }
      else { try { await Net.open(code, true); } catch (e) { return errorScreen(noRoomMsg(e)); } Net.lan = false; }
      Net.role = 'h';
      Net.lobby = { game: null, count: 0, seats: [], people: [], started: null, opts: null };
      Net.unsub.push(Net.r.onPeers(onHostPeers, (e) => { console.warn(e); }));
    }
    renderHostLobby();
  }
  function hostSeats() {
    const g = L.games[Net.lobby.game];
    const me = Net.myPeer();
    const peers = Net.r ? Net.r.peers() : [];
    const guests = peers.filter((p) => !p.sameTab && p.presence && p.presence.role === 'g');
    guests.forEach((p) => { if (!Net.guestOrder.includes(p.peer)) Net.guestOrder.push(p.peer); });
    Net.guestOrder = Net.guestOrder.filter((pp) => guests.some((g2) => g2.peer === pp));
    Net.lobby.people = [{ n: myName() || '방장', p: me }].concat(Net.guestOrder.map((gp) => { const pp = guests.find((x) => x.peer === gp); return { n: String((pp.presence.name || '친구')).slice(0, 10), p: gp }; }));
    if (!g) { Net.lobby.seats = []; Net.lobby.count = 0; return; }
    const gmax = maxFor(g, optDefaults(g, Net.lobby.opts));
    const n = Math.max(Net.lobby.count, Math.min(gmax, 1 + Net.guestOrder.length));
    Net.lobby.count = Math.max(g.minPlayers, Math.min(gmax, n));
    const seats = [{ n: myName() || '호스트', p: me }];
    for (const gp of Net.guestOrder) {
      if (seats.length >= Net.lobby.count) break;
      const pp = guests.find((x) => x.peer === gp);
      if (g.pcOnly && pp.presence.to) continue;   // PC 전용 게임: 터치 기기 친구는 자리 없이 관전
      seats.push({ n: String((pp.presence.name || '친구')).slice(0, 10), p: gp });
    }
    let ai = 1;
    Net.aiLv = Net.aiLv || {};
    while (seats.length < Net.lobby.count) { const i = seats.length; seats.push({ n: 'AI ' + ai++, ai: true, lv: Net.aiLv[i] || 2 }); }
    Net.lobby.seats = seats;
  }
  function onHostPeers(ch) {
    if (Net.role !== 'h') return;
    if (!Net.lobby.started) {
      hostSeats();
      const sig = JSON.stringify(Net.lobby);
      if (sig !== Net.lobbySig) { Net.lobbySig = sig; Net.pub({ role: 'h', name: myName(), lobby: Net.lobby }); renderHostLobby(); }
      return;
    }
    // in game: process guest actions, convert departed guests to AI
    for (const p of ch.left) {
      Net.lobby.seats.forEach((s, i) => {
        if (s.p === p.peer && !s.ai) {
          if (S && S.resultShown) Net.voteLeft = (Net.voteLeft | 0) + 1;
          s.ai = true; s.p = null; s.n = s.n + '(AI)'; s.lv = 2;
          if (S) { S.players[i].ai = true; S.players[i].lv = 2; S.players[i].local = false; S.players[i].name = s.n; toast(s.n.replace('(AI)', '') + ' 님이 나가서 AI가 이어서 해요'); scheduleAI(); }
        }
      });
      Net.pub({ lobby: Net.lobby });
    }
    for (const p of ch.updated.concat(ch.joined)) {
      if (p.sameTab || !p.presence || p.presence.role !== 'g') continue;
      const act = p.presence.act;
      if (!act || typeof act.k !== 'number') continue;
      // a guest's counter starts at 0 when it joins, so its very first action (k = 1) must count
      if (act.k <= (Net.lastK[p.peer] || 0)) continue;
      Net.lastK[p.peer] = act.k;
      const seat = act.seat | 0;
      const s = Net.lobby.seats[seat];
      if (!s || s.p !== p.peer || !S) continue;
      submit(seat, act.a);
    }
    if (ch.joined.some((p) => !p.sameTab)) Net.pubState();
    hostVoteCheck();
  }
  const lobbyFits = (g, people) => people <= g.maxPlayers && (!g.noAI || people >= g.minPlayers);
  function chooseLobbyGame(id, how) {
    const gg = L.games[id];
    Net.lobby.game = id; Net.lobby.pick = { id, how: how || '', t: Date.now() };
    Net.lobby.count = Math.max(gg.defaultPlayers || gg.minPlayers, Math.min(gg.maxPlayers, Net.lobby.people.length || 1));
    Net.lobby.opts = optDefaults(gg, store.get('opts.' + id, null));
    hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby();
  }
  function lobbyRandom(fromFavs) {
    const people = Math.max(1, (Net.lobby.people || []).length);
    let pool = (fromFavs ? store.get('favs', []) : L.order).filter((id) => L.games[id] && lobbyFits(L.games[id], people));
    if (Net.lobby.game && pool.length > 1) pool = pool.filter((id) => id !== Net.lobby.game);
    if (!pool.length) { toast(fromFavs ? '즐겨찾기에 지금 인원으로 할 수 있는 게임이 없어요' : '지금 인원으로 할 수 있는 게임이 없어요'); return; }
    const pick = pool[Math.floor(Math.random() * pool.length)];
    // short roulette on the host screen, then announce to everyone
    const card = document.querySelector('.lobby-game .nm');
    let n = 0;
    const spin = setInterval(() => { if (card) card.textContent = L.games[pool[Math.floor(Math.random() * pool.length)]].name; Sfx.play('tick'); if (++n >= 12) { clearInterval(spin); chooseLobbyGame(pick, fromFavs ? '즐겨찾기 랜덤' : '랜덤'); Sfx.play('pop'); buzz(20); } }, 85);
  }
  function lobbyGamePicker() {
    const people = Math.max(1, (Net.lobby.people || []).length);
    // 인원 필터는 지금 방 인원으로 자동 설정(지우면 안 맞는 게임도 흐리게 보임)
    const st = { cat: '전체', people, kind: '', q: '', view: 'list',
      sort: SORTS.some((s) => s.v === store.get('home.sort', 'cat')) ? store.get('home.sort', 'cat') : 'cat' };
    let sheet = null, pickIO = null;
    const close = () => { if (pickIO) pickIO.disconnect(); o.remove(); };
    const B = gameBrowser({
      st, views: false, fold: new Set(),
      save(s) { store.set('home.sort', s.sort); },
      onPick(id) { close(); chooseLobbyGame(id); },
      fits: (g) => lobbyFits(g, people), current: Net.lobby.game,
      scroller: () => sheet, ioOut: (io) => { pickIO = io; },
    });
    sheet = h('div', { class: 'sheet pick-sheet', onscroll: () => B.onScroll() },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '지금 ' + people + '명 · 방장이 골라요' }), h('h2', { text: '게임 고르기' })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      B.bar, B.sum, B.list);
    const o = overlay(sheet, { cls: 'rules-ov pick-ov' });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    B.render();
  }
  function peopleList(people, me) {
    return h('div', { class: 'people' }, (people || []).map((pp, i) => h('span', { class: 'person' + (pp.p === me ? ' me' : '') },
      h('span', { class: 'dot', style: { '--c': COLORS[i % COLORS.length] } }), (i === 0 ? '👑 ' : '') + pp.n + (pp.p === me ? ' (나)' : ''))));
  }
  function renderHostLobby() {
    if (S || Net.role !== 'h') return;
    hostSeats();
    const g = L.games[Net.lobby.game];
    const people = Net.lobby.people || [];
    const guests = Net.guestOrder.length;
    const gameBox = g ? h('div', { class: 'lobby-game', style: { '--tint': g.tint || TINT[Net.lobby.game] || 'var(--surface)' } },
      svgIcon(Net.lobby.game),
      h('div', { class: 'lg-info' }, h('span', { class: 'label', text: Net.lobby.pick && Net.lobby.pick.how ? '🎲 ' + Net.lobby.pick.how + '으로 골랐어요' : '이번 게임' }),
        h('div', { class: 'nm', text: g.name }), h('span', { class: 'muted', text: (g.minPlayers === g.maxPlayers ? g.minPlayers + '인' : g.minPlayers + '–' + g.maxPlayers + '인') + (g.tag ? ' · ' + g.tag : '') })),
      L.games[Net.lobby.game] && L.games[Net.lobby.game].codex ? h('button', { class: 'btn sm', text: '📖 도감', onclick: () => codexSheet(Net.lobby.game) }) : null,
      h('button', { class: 'btn sm', text: '규칙', onclick: () => rulesSheet(Net.lobby.game) }))
      : h('div', { class: 'lobby-game empty' }, h('div', { class: 'lg-info' }, h('span', { class: 'label', text: '이번 게임' }), h('div', { class: 'nm', text: '아직 안 골랐어요' }),
        h('span', { class: 'muted', text: '친구들이 다 들어오면 게임을 골라 주세요.' })));
    const pickRow = h('div', { class: 'pick-row' },
      h('button', { class: 'btn' + (g ? '' : ' primary'), text: g ? '🎮 게임 바꾸기' : '🎮 게임 고르기', onclick: lobbyGamePicker }),
      h('button', { class: 'btn', text: '🎲 랜덤', onclick: () => lobbyRandom(false) }),
      h('button', { class: 'btn', text: '🎲 즐겨찾기 랜덤', onclick: () => lobbyRandom(true) }));
    const seatList = g ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
      (() => { const ai = Net.lobby.seats.map((s, i) => i).filter((i) => Net.lobby.seats[i].ai);
        return allLvRow(ai.map((i) => Net.lobby.seats[i].lv), (v) => { Net.aiLv = Net.aiLv || {}; ai.forEach((i) => { Net.aiLv[i] = v; }); hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }); })(),
      Net.lobby.seats.map((s, i) => (Net.lobby.seats.length > 10 && i >= 8 && s.ai) ? null : h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }),
        h('span', { class: 'nm', text: s.n }),
        s.ai ? lvChip(s.lv, (v) => { Net.aiLv = Net.aiLv || {}; Net.aiLv[i] = v; hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }) : null,
        h('span', { class: 'tag' + (i === 0 ? ' me' : ''), text: i === 0 ? '나' : s.ai ? 'AI' : '친구' }))),
      (() => {   // 자리가 많으면 9번째부터 AI는 한 줄로
        const idx = Net.lobby.seats.map((s, i) => i).filter((i) => Net.lobby.seats.length > 10 && i >= 8 && Net.lobby.seats[i].ai);
        if (!idx.length) return null;
        return h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[8] } }), h('span', { class: 'nm', style: { flex: 1 }, text: '그 밖의 AI ' + idx.length + '명' }),
          lvChip(Net.lobby.seats[idx[0]].lv, (v) => { Net.aiLv = Net.aiLv || {}; idx.forEach((i) => { Net.aiLv[i] = v; }); hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }));
      })()) : null;
    const scr = h('div', { class: 'screen', 'data-keep': 'hlobby' }, topbarSimple('내 방', true),
      h('div', { class: 'scroll lobby', style: { display: 'flex', flexDirection: 'column', gap: '18px' } }, cols([
        h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px', paddingTop: '10px' } },
          Net.lan ? h('span', { class: 'label', text: 'LAN 방 · 같은 와이파이' }) : h('span', { class: 'label', text: '방 코드' }),
          Net.lan ? h('button', { class: 'btn primary', text: '+ 친구 추가 (QR)', onclick: lanInvite }) : h('div', { class: 'code', text: Net.code }),
          h('p', { class: 'note', style: { margin: 0 }, text: Net.lan ? '친구가 ‘LAN 참가’를 누른 뒤, 한 명씩 QR을 서로 찍으면 연결돼요. 인터넷이 없어도 같은 와이파이면 돼요.' : L.STANDALONE ? '친구가 한판 라운지 앱에서 “코드로 참가”에 이 코드를 넣으면 들어와요. 인터넷에 연결되어 있어야 해요.' : '친구가 같은 링크를 열고 “코드로 참가”에 이 코드를 넣으면 들어와요. 링크는 참여 가능 권한으로 공유해 주세요.' })),
        h('div', { class: 'field' }, h('span', { class: 'label', text: '방에 있는 사람 · ' + people.length + '명' }), peopleList(people, Net.myPeer())),
        ], [
        h('div', { class: 'field' }, gameBox, pickRow),
        g ? optRows(g, Net.lobby.opts || (Net.lobby.opts = optDefaults(g, null)), () => { store.set('opts.' + Net.lobby.game, Net.lobby.opts); hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }) : null,
        g ? h('div', { class: 'field' },
          h('div', { class: 'row', style: { justifyContent: 'space-between' } }, h('span', { class: 'label', text: '자리' }),
            g.minPlayers !== g.maxPlayers ? h('span', { class: 'muted', text: g.minPlayers + '–' + g.maxPlayers + '명' }) : null),
          g.minPlayers !== g.maxPlayers ? (() => { const mx = maxFor(g, optDefaults(g, Net.lobby.opts)), mn = Math.max(g.minPlayers, Math.min(1 + guests, mx));
            return countCtl({ min: mn, max: mx, get: () => Net.lobby.count, label: '자리', unit: '자리',
              onSet(n) { if (n === Net.lobby.count) return; Net.lobby.count = n; hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); } }); })() : null,
          seatList,
          h('p', { class: 'note', style: { margin: 0 }, text: (g.noAI ? '이 게임은 사람끼리만 해요.' : '빈 자리는 AI가 맡아요. 친구가 들어오면 AI 자리를 대신 차지합니다.') + (g.pcOnly ? ' 🖥 PC 전용 — 터치 기기(마우스 없음) 친구는 자리 없이 관전해요.' : '') })) : null,
        g ? h('button', { class: 'btn primary block', text: g.name + ' 시작', onclick: hostStart }) : null,
        g && g.save ? (() => { const b = h('button', { class: 'btn block', hidden: true, text: '💾 저장된 판 이어하기', onclick: () => resumeHostSheet(Net.lobby.game) }); Saves.list(Net.lobby.game, 'm').then((ls) => { b.hidden = !ls.length; }); return b; })() : null])));
    showKeep(scr);
  }
  function hostStart() {
    if (pcOnlyBlocked(L.games[Net.lobby.game])) { pcOnlySheet(L.games[Net.lobby.game]); return; }
    hostSeats();
    Net.lobby.started = Net.lobby.game;
    Net.lobby.rd = (Net.lobby.rd | 0) + 1; Net.voteLeft = 0; Net.myVote = null; Net.voteDone = -1;
    const me = Net.myPeer();
    const gdef = L.games[Net.lobby.game], oo = optDefaults(gdef, Net.lobby.opts);
    Net.lobby.seats = shuffleOrder(gdef, oo, Net.lobby.seats.map((s, i) => Object.assign({}, s, { c: i })));
    const players = Net.lobby.seats.map((s, i) => ({ name: s.n, ai: !!s.ai, local: s.p === me && !s.ai, color: COLORS[s.c != null ? s.c : i], lv: s.ai ? (s.lv || 2) : 0 }));
    Net.pub({ role: 'h', name: myName(), lobby: Net.lobby, vcap: 1, votes: null });
    startSession('host', Net.lobby.game, players, null, Net.lobby.opts);
    if (oo._order === 'rand') orderToast(players);
  }

  /* guest */
  function askName(then) {
    const o = overlay(h('div', { class: 'sheet' }, h('h2', { text: '이름을 정해 주세요' }), nameField('nm-ask'),
      h('button', { class: 'btn primary block', text: '확인', onclick() { const v = document.getElementById('nm-ask').value.trim().slice(0, 10); if (!v) return; store.set('name', v); o.remove(); then(); } })));
    setTimeout(() => { const i = document.getElementById('nm-ask'); i && i.focus(); }, 50);
  }
  function joinScreen() {
    endSession(); Net.leave();
    const scr = h('div', { class: 'screen' }, topbarSimple('코드로 참가'),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '18px' } },
        nameField('nm-join'),
        h('label', { class: 'field' }, h('span', { class: 'label', text: '방 코드' }),
          h('input', { id: 'code-join', maxlength: 4, placeholder: 'ABCD', autocapitalize: 'characters', autocomplete: 'off', class: 'mono', style: { fontSize: '28px', letterSpacing: '.2em', textTransform: 'uppercase' } })),
        h('button', { class: 'btn primary block', text: '참가', onclick: doJoin }),
        h('p', { class: 'note', text: '호스트와 같은 링크에서 열어야 같은 방에 들어갈 수 있어요.' })));
    show(scr);
  }
  async function doJoin() {
    const nm = document.getElementById('nm-join').value.trim().slice(0, 10);
    const code = document.getElementById('code-join').value.trim().toUpperCase().replace(/[^A-Z]/g, '');
    if (!nm) return toast('이름을 적어 주세요');
    if (code.length !== 4) return toast('코드 4글자를 넣어 주세요');
    store.set('name', nm);
    show(h('div', { class: 'screen' }, topbarSimple('방 ' + code), h('div', { class: 'scroll' }, h('p', { class: 'muted', text: '방에 들어가는 중…' }))));
    try { await Net.open(code); } catch (e) { return errorScreen(noRoomMsg(e)); }
    Net.lan = false;
    enterGuest(nm);
  }
  function enterGuest(nm) {
    Net.role = 'g';
    Net.k = 0;
    Net.pub({ role: 'g', name: nm, to: touchOnly() ? 1 : 0 });
    Net.hostSeen = Date.now();
    let waitedFor = Date.now();
    Net.unsub.push(Net.r.onPeers(() => onGuestPeers(), (e) => console.warn(e)));
    const watchdog = setInterval(() => {
      if (Net.role !== 'g') return clearInterval(watchdog);
      if (Net.hostPeer()) { Net.hostSeen = Date.now(); return; }
      if (Date.now() - Net.hostSeen > 6000) {
        clearInterval(watchdog);
        const had = Date.now() - waitedFor > 6500 && S;
        Net.leave(); endSession();
        errorScreen(had ? '호스트가 방을 나갔어요.' : '그 코드의 방을 찾지 못했어요. 코드를 다시 확인해 주세요.');
      }
    }, 1000);
    renderGuestLobby();
  }
  function onGuestPeers() {
    if (Net.role !== 'g') return;
    const hp = Net.hostPeer();
    if (!hp) return;
    Net.hostSeen = Date.now();
    const lobby = hp.presence.lobby;
    if (!lobby || !lobby.seats) return;
    Net.lobby = lobby;
    const me = Net.myPeer();
    const st = Net.field(hp.peer, 'st', hp.presence.st);
    if (hp.presence.hs) Net.field(hp.peer, 'hs', hp.presence.hs);   // 실시간 상태도 미리 풀어 둔다(라운드 41)
    if (lobby.started && st && st.s && L.games[lobby.started]) {
      if (!S || S.gameId !== lobby.started) {
        Net.stVer = -1;
        startSession('guest', lobby.started, lobby.seats.map((s, i) => ({ name: s.n, ai: !!s.ai, local: s.p === me && !s.ai, color: COLORS[s.c != null ? s.c : i], lv: s.ai ? (s.lv || 2) : 0 })));
        if (L.games[lobby.started].pcOnly && !lobby.seats.some((s) => s.p === me)) toast('PC 전용 게임이라 이 기기에서는 관전만 해요');
        if (optDefaults(L.games[lobby.started], lobby.opts)._order === 'rand') orderToast(S.players);
      } else {
        lobby.seats.forEach((s, i) => { if (S.players[i]) { S.players[i].ai = !!s.ai; S.players[i].name = s.n; S.players[i].local = s.p === me && !s.ai; } });
      }
      if (st.v !== Net.stVer) { Net.stVer = st.v; setState(st.s, true); }
      if (Net.voteUI) Net.voteUI(hp.presence.votes);
      guestPause(hp.presence.pz | 0);
    } else {
      if (S) { endSession(); Net.lobbySig = null; }
      const sig = JSON.stringify(lobby) + me;
      if (sig !== Net.lobbySig) { Net.lobbySig = sig; renderGuestLobby(); }
    }
  }
  function renderGuestLobby() {
    if (S || Net.role !== 'g') return;
    const lobby = Net.lobby;
    const me = Net.myPeer();
    const g = lobby && L.games[lobby.game];
    if (lobby && lobby.pick && lobby.pick.t !== Net.seenPick && g) { Net.seenPick = lobby.pick.t; if (lobby.pick.how) { toast('🎲 ' + lobby.pick.how + ': ' + g.name); Sfx.play('pop'); } }
    const scr = h('div', { class: 'screen' }, topbarSimple('방 ' + Net.code, true),
      h('div', { class: 'scroll lobby', style: { display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '12px' } }, cols([
        lobby ? h('div', { class: 'field' }, h('span', { class: 'label', text: '방에 있는 사람 · ' + (lobby.people || []).length + '명' }), peopleList(lobby.people, me)) : null,
        ], [
        g ? h('div', { class: 'lobby-game', style: { '--tint': g.tint || TINT[lobby.game] || 'var(--surface)' } }, svgIcon(lobby.game),
            h('div', { class: 'lg-info' }, h('span', { class: 'label', text: '이번 게임' }), h('div', { class: 'nm', text: g.name }),
              h('span', { class: 'muted', text: g.minPlayers === g.maxPlayers ? g.minPlayers + '인' : g.minPlayers + '–' + g.maxPlayers + '인' })),
            L.games[lobby.game] && L.games[lobby.game].codex ? h('button', { class: 'btn sm', text: '📖 도감', onclick: () => codexSheet(lobby.game) }) : null,
            h('button', { class: 'btn sm', text: '규칙', onclick: () => rulesSheet(lobby.game) }))
          : h('div', { class: 'lobby-game empty' }, h('div', { class: 'lg-info' }, h('span', { class: 'label', text: '이번 게임' }),
            h('div', { class: 'nm', text: lobby ? '방장이 고르는 중…' : '방장을 찾는 중…' }))),
        g && lobby.seats ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } }, lobby.seats.map((s, i) => h('div', { class: 'seat' },
          h('span', { class: 'dot', style: { '--c': COLORS[i] } }), h('span', { class: 'nm', text: s.n }),
          h('span', { class: 'tag' + (s.p === me ? ' me' : ''), text: s.p === me ? '나' : i === 0 ? '방장' : s.ai ? 'AI' : '친구' })))) : null,
        g && lobby.opts ? optRows(g, lobby.opts, () => {}, true) : null,
        g && lobby && !lobby.seats.some((s) => s.p === me) ? h('p', { class: 'note', text: '자리가 다 찼어요. 이번 판은 구경만 할 수 있어요.' }) : null,
        h('p', { class: 'muted', text: g ? '방장이 시작하면 바로 게임이 열려요.' : '방장이 게임을 고르면 여기에 보여요.' })])));
    scr.dataset.keep = 'globby'; showKeep(scr);
  }

  async function lanInvite() {
    if (!Net.r || !Net.r.invite) return;
    const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } }, h('p', { class: 'muted', text: '연결 코드를 만드는 중…' }));
    let inv = null, linked = false;
    const o = overlay(h('div', { class: 'sheet' }, h('h2', { text: '친구 추가' }), body,
      h('button', { class: 'btn ghost block', text: '닫기', onclick() { if (inv && !linked) inv.cancel(); o.remove(); } })));
    try { inv = await Net.r.invite(); } catch (e) { body.innerHTML = ''; body.append(h('p', { text: '연결 코드를 만들지 못했어요.' })); return; }
    body.innerHTML = '';
    body.append(h('p', { class: 'note', style: { margin: 0 }, text: '1. 친구가 ‘LAN 참가’에서 이 QR을 찍어요.' }), await codeBox(inv.text),
      h('button', { class: 'btn primary block', text: '2. 친구 화면의 QR 찍기', async onclick() {
        const ans = await scanCode('친구의 응답 QR');
        if (!ans) return;
        body.innerHTML = ''; body.append(h('p', { class: 'muted', text: '연결하는 중…' }));
        try { await inv.accept(ans); linked = true; toast('친구가 연결됐어요'); buzz(30, 'alert'); o.remove(); }
        catch (e) { body.innerHTML = ''; body.append(h('p', { text: e.message === 'mismatch' ? '다른 친구의 응답이에요. 이 QR을 찍은 친구의 응답을 찍어 주세요.' : '연결하지 못했어요. 같은 와이파이인지 확인하고 다시 시도해 주세요.' })); }
      } }));
  }
  function lanJoinScreen() {
    endSession(); Net.leave();
    const area = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } });
    let pending = null;
    const scr = h('div', { class: 'screen' }, topbarSimple('LAN 참가'),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '18px' } },
        nameField('nm-lan'),
        h('button', { class: 'btn primary block', text: '호스트의 QR 찍기', async onclick() {
          const nm = document.getElementById('nm-lan').value.trim().slice(0, 10);
          if (!nm) return toast('이름을 적어 주세요');
          store.set('name', nm);
          const text = await scanCode('호스트의 QR');
          if (!text) return;
          area.innerHTML = ''; area.append(h('p', { class: 'muted', text: '응답 코드를 만드는 중…' }));
          try {
            if (pending) pending.cancel();
            pending = await Lan.join(text);
            area.innerHTML = '';
            area.append(h('p', { class: 'note', style: { margin: 0 }, text: '이제 호스트가 “친구 화면의 QR 찍기”로 이 QR을 찍으면 연결돼요.' }), await codeBox(pending.text));
            const R = await pending.ready;
            Net.r = R; Net.code = 'LAN'; Net.lan = true;
            toast('호스트와 연결됐어요'); buzz(30, 'alert');
            enterGuest(nm);
          } catch (e) {
            area.innerHTML = '';
            area.append(h('p', { text: e.message === 'badcode' ? '한판 라운지 LAN QR이 아니에요.' : '연결하지 못했어요. 같은 와이파이인지 확인하고 처음부터 다시 해 주세요.' }));
          }
        } }),
        area,
        h('p', { class: 'note', text: '호스트가 ‘LAN 방 만들기’ → ‘친구 추가’를 누르면 QR이 나와요. 인터넷 없이 같은 와이파이에서 연결돼요.' })));
    show(scr);
  }

  function topbarSimple(title, leaveRoom) {
    return h('div', { class: 'topbar' },
      h('button', { class: 'iconbtn', 'aria-label': '뒤로', text: '‹', onclick() { if (leaveRoom) confirmSheet('방을 나갈까요?', Net.role === 'h' ? '방이 닫히고 친구들도 나가게 돼요.' : null, '나가기', homeScreen); else homeScreen(); } }),
      h('div', { class: 'title', text: title }));
  }
  function errorScreen(msg) {
    Net.leave();
    show(h('div', { class: 'screen' }, topbarSimple('온라인'),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '14px', paddingTop: '24px' } },
        h('p', { text: msg }), h('button', { class: 'btn', text: '처음으로', onclick: homeScreen }))));
  }

  /* ---------- boot ---------- */
  L.boot = function () {
    homeScreen();
    document.addEventListener('gesturestart', (e) => e.preventDefault());
    if (L.STANDALONE) {
      // phone back button inside a game asks before leaving instead of closing the app
      window.addEventListener('popstate', () => {
        if (!S) return;
        try { history.pushState({ lounge: 'game' }, ''); } catch (e) {}
        if (!document.querySelector('.overlay:not(.result)')) leaveGame();
      });
    }
  };
  /* test hook: start a local game directly */
  L.debug.local = function (id, seats, opts) {   // opts: {optionId: value}, missing ones use defaults
    const g = L.games[id];
    seats = seats || Array.from({ length: g.defaultPlayers || g.minPlayers }, (_, i) => ({ name: 'AI ' + (i + 1), ai: true }));
    startSession('local', id, seats.map((s, i) => ({ name: s.name, ai: !!s.ai, local: !s.ai, color: COLORS[i], lv: s.lv || 2 })), null, optDefaults(g, opts));
    return S;
  };
  L.debug.home = () => homeScreen();
})();
