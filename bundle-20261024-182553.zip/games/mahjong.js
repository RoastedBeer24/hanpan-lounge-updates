/* 마작 — 리치 마작(136장, 4인 / 3인 산마 108장: 2~8만 없음·치 없음·북빼기·츠모손 없음·35000점). 리치·도라·뒷도라·쯔모/론·치/퐁/깡, 흔한 역 + 역만, 부·판 자동 계산.
   동풍전(기본)/반장전. 부르기(론/퐁/깡/치)는 우선순위 순서로 한 자리씩 묻는다(론 → 퐁·깡 → 치).
   적도라(빨간 5, 옵션)·창깡·더블리치·천화·지화·구종구패(옵션). 단순화: 동시 론은 선하네(버린 사람 다음 자리 우선), 쿠이카에 제한 없음, 리치 중 깡 없음.
   빨간 5 = 'X'(5만) 'Y'(5통) 'Z'(5삭) 글자. 부르기 묶음 5번째 글자 = 그 안의 빨간 5 개수.
   패 = 한 글자(34종). 그림은 모두 캔버스로 직접 그림. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- tiles ---------- */
  const K = 'abcdefghijklmnopqrstuvwxyzABCDEFGH';
  const AKA = { X: 4, Y: 13, Z: 22 }, AKC = 'XYZ';
  const ki = (ch) => (AKA[ch] != null ? AKA[ch] : K.indexOf(ch));
  const kv = (ch) => (AKA[ch] != null ? 34 + AKC.indexOf(ch) : K.indexOf(ch)); // view code: 34~36 = red 5
  const nRed = (str) => { let n = 0; for (const ch of str) if (AKA[ch] != null) n++; return n; };
  const suit = (k) => (k < 27 ? (k / 9) | 0 : 3);
  const num = (k) => k % 9;
  const yao = (k) => k >= 27 || k % 9 === 0 || k % 9 === 8;
  const YAO = [0, 8, 9, 17, 18, 26, 27, 28, 29, 30, 31, 32, 33];
  const DRG = [31, 32, 33];
  const GREEN = [19, 20, 21, 23, 25, 32];
  const WN = ['동', '남', '서', '북'];
  const SN = ['만', '통', '삭'];
  const HN = ['동', '남', '서', '북', '백', '발', '중'];
  const tname = (k) => (k < 27 ? (num(k) + 1) + SN[suit(k)] : HN[k - 27]);
  function cnt(str) { const c = new Array(34).fill(0); for (let i = 0; i < str.length; i++) c[ki(str[i])]++; return c; }
  const sortH = (str) => str.split('').sort((a, b) => ki(a) - ki(b)).join('');
  function doraOf(i, sm) { if (sm && i === 0) return 8; if (sm && i === 8) return 0; if (i < 27) return ((i / 9) | 0) * 9 + (i % 9 + 1) % 9; if (i < 31) return 27 + (i - 27 + 1) % 4; return 31 + (i - 31 + 1) % 3; }
  const pmeld = (m) => ({ t: m[0], k: ki(m[1]), c: ki(m[2]), f: m[3] === '-' ? -1 : +m[3], rd: +(m[4] || 0) });
  const meldsOf = (s, seat) => s.m[seat].map(pmeld);
  const NN = (s) => s.n || 4;
  const SEATS = (s) => (NN(s) === 3 ? [0, 1, 2] : [0, 1, 2, 3]);
  const NORTH = 30;
  const menzenOf = (s, seat) => s.m[seat].every((m) => m[0] === 'a');
  function pondKinds(p) { const r = []; for (const ch of p) if (ch !== '*' && ch !== '~') r.push(ki(ch)); return r; }
  function meldTiles(m) { if (m.t === 'c') return [m.k, m.k + 1, m.k + 2]; return m.t === 'p' ? [m.k, m.k, m.k] : [m.k, m.k, m.k, m.k]; }

  /* ---------- hand shapes ---------- */
  function hasSets(c, i, n) {
    while (i < 34 && !c[i]) i++;
    if (i === 34) return n === 0;
    if (n === 0) return false;
    if (c[i] >= 3) { c[i] -= 3; const r = hasSets(c, i, n - 1); c[i] += 3; if (r) return true; }
    if (i < 27 && i % 9 <= 6 && c[i + 1] && c[i + 2]) { c[i]--; c[i + 1]--; c[i + 2]--; const r = hasSets(c, i, n - 1); c[i]++; c[i + 1]++; c[i + 2]++; if (r) return true; }
    return false;
  }
  function isChiitoi(c) { let p = 0; for (let k = 0; k < 34; k++) { if (c[k] === 2) p++; else if (c[k]) return false; } return p === 7; }
  function isKokushi(c) { let t = 0, pair = 0; for (let k = 0; k < 34; k++) { if (!c[k]) continue; if (!yao(k)) return false; t += c[k]; if (c[k] === 2) pair++; if (c[k] > 2) return false; } return t === 14 && pair === 1; }
  function isAgari(c, nm) {
    if (nm === 0 && (isChiitoi(c) || isKokushi(c))) return true;
    for (let p = 0; p < 34; p++) if (c[p] >= 2) { c[p] -= 2; const r = hasSets(c, 0, 4 - nm); c[p] += 2; if (r) return true; }
    return false;
  }
  function waitsOf(c, nm) { const r = []; for (let k = 0; k < 34; k++) { if (c[k] >= 4) continue; c[k]++; if (isAgari(c, nm)) r.push(k); c[k]--; } return r; }
  function decomps(c, need) {
    const out = [], sets = [];
    let pair = -1;
    function rec(i) {
      while (i < 34 && !c[i]) i++;
      if (i === 34) { if (sets.length === need) out.push({ p: pair, s: sets.slice() }); return; }
      if (sets.length >= need) return;
      if (c[i] >= 3) { c[i] -= 3; sets.push([0, i]); rec(i); sets.pop(); c[i] += 3; }
      if (i < 27 && i % 9 <= 6 && c[i + 1] && c[i + 2]) { c[i]--; c[i + 1]--; c[i + 2]--; sets.push([1, i]); rec(i); sets.pop(); c[i]++; c[i + 1]++; c[i + 2]++; }
    }
    for (let p = 0; p < 34; p++) if (c[p] >= 2) { c[p] -= 2; pair = p; rec(0); c[p] += 2; }
    return out;
  }
  function shanten(c, nm) {
    const need = 4 - nm;
    let best = 8;
    function dfs(i, m, t, p) {
      while (i < 34 && !c[i]) i++;
      if (i === 34) { const tt = Math.min(t, need - m); const v = 8 - 2 * (m + nm) - tt - p; if (v < best) best = v; return; }
      if (8 - 2 * (need + nm) - p >= best && m + t >= need) { /* can't improve much */ }
      if (m < need && c[i] >= 3) { c[i] -= 3; dfs(i, m + 1, t, p); c[i] += 3; }
      if (m < need && i < 27 && i % 9 <= 6 && c[i + 1] && c[i + 2]) { c[i]--; c[i + 1]--; c[i + 2]--; dfs(i, m + 1, t, p); c[i]++; c[i + 1]++; c[i + 2]++; }
      if (!p && c[i] >= 2) { c[i] -= 2; dfs(i, m, t, 1); c[i] += 2; }
      if (m + t < need) {
        if (c[i] >= 2) { c[i] -= 2; dfs(i, m, t + 1, p); c[i] += 2; }
        if (i < 27 && i % 9 <= 7 && c[i + 1]) { c[i]--; c[i + 1]--; dfs(i, m, t + 1, p); c[i]++; c[i + 1]++; }
        if (i < 27 && i % 9 <= 6 && c[i + 2]) { c[i]--; c[i + 2]--; dfs(i, m, t + 1, p); c[i]++; c[i + 2]++; }
      }
      const v = c[i]; c[i] = 0; dfs(i + 1, m, t, p); c[i] = v;
    }
    dfs(0, 0, 0, 0);
    if (nm === 0) {
      let pairs = 0, kinds = 0, yk = 0, yp = 0;
      for (let k = 0; k < 34; k++) { if (c[k]) kinds++; if (c[k] >= 2) pairs++; if (yao(k) && c[k]) { yk++; if (c[k] >= 2) yp = 1; } }
      best = Math.min(best, 6 - pairs + Math.max(0, 7 - kinds), 13 - yk - yp);
    }
    return best;
  }

  /* ---------- scoring ---------- */
  const up100 = (v) => Math.ceil(v / 100) * 100;
  function baseOf(han, fu) {
    if (han >= 13) return 8000; if (han >= 11) return 6000; if (han >= 8) return 4000; if (han >= 6) return 3000;
    const b = fu * Math.pow(2, han + 2); return han >= 5 || b > 2000 ? 2000 : b;
  }
  function limName(han, ym, base) {
    if (ym) return ym > 1 ? ym + '배 역만' : '역만';
    if (han >= 13) return '세는 역만'; if (han >= 11) return '삼배만'; if (han >= 8) return '배만'; if (han >= 6) return '하네만';
    return base >= 2000 ? '만관' : '';
  }
  /* x: {c (closed incl. winning tile), melds, wk, tsumo, ri, ip, hai, hou, rin, sw, rw, dora[], ura[]} → best result or null (no yaku) */
  function evalWin(x) {
    const nm = x.melds.length, menzen = x.melds.every((m) => m.t === 'a');
    const all = x.c.slice();
    for (const m of x.melds) for (const k of meldTiles(m)) all[k]++;
    const nd = x.nd || 0; let dora = 0, ura = 0; x.dora.forEach((d) => { dora += all[d] + (d === NORTH ? nd : 0); }); if (x.ri) x.ura.forEach((d) => { ura += all[d] + (d === NORTH ? nd : 0); });
    const aka = x.aka || 0;
    const thY = x.th ? [[x.th === 1 ? '천화' : '지화', 13]] : [];
    let honors = 0; const su = [0, 0, 0];
    for (let k = 0; k < 34; k++) if (all[k]) { if (k >= 27) honors += all[k]; else su[suit(k)] += all[k]; }
    const nSuits = su.filter((v) => v).length;
    let allYao = true, tan = true;
    for (let k = 0; k < 34; k++) if (all[k]) { if (yao(k)) tan = false; else allYao = false; }
    const sit = [];
    if (x.ri === 2) sit.push(['더블리치', 2]); else if (x.ri) sit.push(['리치', 1]); if (x.ck) sit.push(['창깡', 1]); if (x.ip) sit.push(['일발', 1]); if (menzen && x.tsumo) sit.push(['멘젠쯔모', 1]);
    if (x.hai) sit.push(['해저로월', 1]); if (x.hou) sit.push(['하저로어', 1]); if (x.rin) sit.push(['영상개화', 1]);
    const comp = [];
    if (tan) comp.push(['탕야오', 1]);
    if (nSuits === 1 && honors) comp.push(['혼일색', menzen ? 3 : 2]);
    if (nSuits === 1 && !honors) comp.push(['청일색', menzen ? 6 : 5]);
    const ymc = [];
    if (nSuits === 0) ymc.push(['자일색', 1]);
    if (allYao && !honors) ymc.push(['청노두', 1]);
    if (all.every((v, k) => !v || GREEN.includes(k))) ymc.push(['녹일색', 1]);
    let best = null;
    function consider(yl, fu, ym) {
      let han = 0, base;
      if (ym) { base = 8000 * ym; han = 13 * ym; }
      else {
        han = yl.reduce((a, y) => a + y[1], 0);
        if (!han) return;
        yl = yl.slice();
        if (dora) yl.push(['도라', dora]);
        if (aka) yl.push(['적도라', aka]);
        if (nd) yl.push(['북도라', nd]);
        if (ura) yl.push(['뒷도라', ura]);
        han += dora + ura + aka + nd;
        base = baseOf(han, fu);
      }
      if (!best || base > best.base || (base === best.base && han > best.han)) best = { y: yl, han, fu, ym, base, lim: limName(han, ym, base) };
    }
    if (nm === 0 && isKokushi(x.c)) { consider([['국사무쌍', 13]].concat(thY), 0, 1 + thY.length); return best; }
    if (nm === 0 && isChiitoi(x.c)) {
      if (ymc.length || thY.length) consider(ymc.map((y) => [y[0], 13]).concat(thY), 0, ymc.length + thY.length);
      else { const yl = sit.concat(comp); if (allYao) yl.push(['혼노두', 2]); yl.push(['치또이츠', 2]); consider(yl, 25, 0); }
    }
    for (const d of decomps(x.c, 4 - nm)) {
      const pls = [];
      if (d.p === x.wk) pls.push({ w: 't', i: -1 });
      d.s.forEach((st, i) => {
        if (st[0] === 0 && st[1] === x.wk) pls.push({ w: 's', i });
        if (st[0] === 1 && x.wk >= st[1] && x.wk <= st[1] + 2) {
          const a = st[1];
          const w = x.wk === a + 1 ? 'k' : x.wk === a ? (num(a) === 6 ? 'e' : 'r') : (num(a) === 0 ? 'e' : 'r');
          pls.push({ w, i });
        }
      });
      for (const pl of pls) {
        const G = d.s.map((st, i) => ({ seq: st[0] === 1, k: st[1], kan: false, cl: st[0] === 0 ? !(pl.w === 's' && pl.i === i && !x.tsumo) : true, open: false }));
        for (const m of x.melds) G.push({ seq: m.t === 'c', k: m.k, kan: m.t !== 'c' && m.t !== 'p', cl: m.t === 'a', open: m.t !== 'a' });
        const seqs = G.filter((g) => g.seq), pungs = G.filter((g) => !g.seq);
        const pr = d.p;
        const yakPair = DRG.includes(pr) || pr === x.sw || pr === x.rw;
        const yl = sit.concat(comp);
        const ym = ymc.map((y) => [y[0], 13]).concat(thY);
        const pinfu = menzen && nm === 0 && seqs.length === 4 && !yakPair && pl.w === 'r';
        if (pinfu) yl.push(['핑후', 1]);
        if (menzen) {
          const m = {}; seqs.forEach((g) => { m[g.k] = (m[g.k] || 0) + 1; });
          let dup = 0; Object.values(m).forEach((v) => { dup += v >> 1; });
          if (dup >= 2) yl.push(['량페코', 3]); else if (dup === 1) yl.push(['이페코', 1]);
        }
        let dp = 0, wp = 0;
        for (const g of pungs) {
          if (DRG.includes(g.k)) { dp++; yl.push(['역패 ' + HN[g.k - 27], 1]); }
          if (g.k >= 27 && g.k <= 30) wp++;
          if (g.k === x.sw) yl.push(['자풍패 ' + HN[g.k - 27], 1]);
          if (g.k === x.rw) yl.push(['장풍패 ' + HN[g.k - 27], 1]);
        }
        const hasSeq = (k) => seqs.some((g) => g.k === k), hasPung = (k) => pungs.some((g) => g.k === k);
        for (let n = 0; n < 7; n++) if (hasSeq(n) && hasSeq(9 + n) && hasSeq(18 + n)) { yl.push(['삼색동순', menzen ? 2 : 1]); break; }
        for (let s9 = 0; s9 < 27; s9 += 9) if (hasSeq(s9) && hasSeq(s9 + 3) && hasSeq(s9 + 6)) { yl.push(['일기통관', menzen ? 2 : 1]); break; }
        const gYao = (g) => (g.seq ? num(g.k) === 0 || num(g.k) === 6 : yao(g.k));
        if (seqs.length && G.every(gYao) && yao(pr)) { if (honors) yl.push(['찬타', menzen ? 2 : 1]); else yl.push(['준찬타', menzen ? 3 : 2]); }
        if (pungs.length === 4) yl.push(['또이또이', 2]);
        const ank = pungs.filter((g) => g.cl).length;
        if (ank === 3) yl.push(['산안커', 2]);
        for (let n = 0; n < 9; n++) if (hasPung(n) && hasPung(9 + n) && hasPung(18 + n)) { yl.push(['삼색동각', 2]); break; }
        if (dp === 2 && DRG.includes(pr)) yl.push(['소삼원', 2]);
        if (allYao && honors && !seqs.length) yl.push(['혼노두', 2]);
        const kans = G.filter((g) => g.kan).length;
        if (kans === 3) yl.push(['산깡쯔', 2]);
        if (ank === 4) ym.push(['스안커', 13]);
        if (dp === 3) ym.push(['대삼원', 13]);
        if (wp === 4) ym.push(['대사희', 13]); else if (wp === 3 && pr >= 27 && pr <= 30) ym.push(['소사희', 13]);
        if (kans === 4) ym.push(['스깡쯔', 13]);
        if (menzen && nm === 0 && nSuits === 1 && !honors) {
          const s0 = su.findIndex((v) => v) * 9, base = [3, 1, 1, 1, 1, 1, 1, 1, 3];
          if (base.every((b, i) => all[s0 + i] >= b)) ym.push(['구련보등', 13]);
        }
        if (ym.length) { consider(ym, 0, ym.length); continue; }
        let fu;
        if (pinfu && x.tsumo) fu = 20;
        else {
          fu = 20;
          if (menzen && !x.tsumo) fu += 10;
          if (x.tsumo) fu += 2;
          for (const g of pungs) { let f = 2; if (yao(g.k)) f *= 2; if (g.cl) f *= 2; if (g.kan) f *= 4; fu += f; }
          if (DRG.includes(pr)) fu += 2; if (pr === x.sw) fu += 2; if (pr === x.rw) fu += 2;
          if (pl.w === 't' || pl.w === 'k' || pl.w === 'e') fu += 2;
          fu = Math.ceil(fu / 10) * 10;
          if (fu === 20) fu = 30;
        }
        consider(yl, fu, 0);
      }
    }
    return best;
  }
  function winCtx(s, seat, wk, tsumo, wr, ck) {
    const c = cnt(s.h[seat]); if (!tsumo) c[wk]++;
    const aka = s.o.ak ? nRed(s.h[seat]) + (wr ? 1 : 0) + s.m[seat].reduce((a, m) => a + +(m[4] || 0), 0) : 0;
    const th = tsumo && s.nc && !s.rs && !s.p[seat] ? (seat === s.dl ? 1 : 2) : 0;
    const n = s.kn + 1, N = NN(s), sm = N === 3;
    return {
      c, melds: meldsOf(s, seat), nd: s.nd ? s.nd[seat] : 0, wk, tsumo, ri: s.ri[seat] | 0, ip: !!s.ip[seat], aka, th, ck: ck ? 1 : 0,
      hai: tsumo && s.w.length === 0 && !s.rs, hou: !tsumo && !ck && s.w.length === 0, rin: tsumo && !!s.rs,
      sw: 27 + ((seat - s.dl + N) % N), rw: 27 + Math.min(1, (s.rd / N) | 0),
      dora: s.dw.slice(4, 4 + n).split('').map((ch) => doraOf(ki(ch), sm)), ura: s.dw.slice(9, 9 + n).split('').map((ch) => doraOf(ki(ch), sm)),
    };
  }
  function canTsumo(s, seat) {
    if (s.ph !== 'd' || s.t !== seat || !s.dr) return null;
    const c = cnt(s.h[seat]);
    if (!isAgari(c, s.m[seat].length)) return null;
    return evalWin(winCtx(s, seat, ki(s.h[seat][s.h[seat].length - 1]), true));
  }
  function furiten(s, seat, w) {
    if (s.tf[seat] || s.rf[seat]) return true;
    const pk = pondKinds(s.p[seat]);
    return w.some((k) => pk.includes(k));
  }

  /* ---------- flow ---------- */
  function init(players, opts) {
    opts = opts || {};
    const N = players.length === 3 ? 3 : 4;
    const s = {
      n: N,
      o: { e: (opts.len === 's' ? 2 : 1) * N, hp: opts.help === 'off' ? 0 : 1, ak: opts.aka === 'off' ? 0 : 1, q9: opts.q9 === 'off' ? 0 : 1 },
      hu: players.map((p, i) => (p.ai ? -1 : i)).filter((i) => i >= 0),
      sc: new Array(N).fill(N === 3 ? 35000 : 25000), rd: 0, hb: 0, ky: 0, hn: 0, seq: 0, last: null,
    };
    deal(s);
    return s;
  }
  function deal(s) {
    const t = [], N = NN(s), sm = N === 3, z = () => new Array(N).fill(0);
    for (let k = 0; k < 34; k++) { if (sm && k >= 1 && k <= 7) continue; for (let j = 0; j < 4; j++) t.push(K[k]); }   // 3인: 2~8만 없음(108장)
    if (s.o.ak) for (let j = sm ? 1 : 0; j < 3; j++) t[t.indexOf(K[[4, 13, 22][j]])] = AKC[j];
    U.shuffle(t);
    s.dw = t.splice(0, 14).join('');
    s.h = new Array(N).fill('');
    for (let r = 0; r < 13; r++) for (let i = 0; i < N; i++) s.h[i] += t.pop();
    s.h = s.h.map(sortH);
    s.w = t.join('');
    s.m = s.h.map(() => []); s.p = new Array(N).fill('');
    s.ri = z(); s.ip = z(); s.tf = z(); s.rf = z();
    if (sm) { s.nd = z(); s.nb = 0; }
    s.kn = 0; s.nc = 1; s.pr = -1; s.dl = s.rd % N; s.rr = null; s.cl = null; s.over = 0;
    draw(s, s.dl, false);
    s.last = { id: ++s.seq, k: 'deal' };
  }
  /* rin: 'k' 깡 보충 / 'b' 북빼기 보충. 영상패 4장(왕패 0~3)을 다 쓰면 패산 끝에서 가져와요(왕패는 늘 14장). */
  function draw(s, seat, rin) {
    let ch;
    if (rin) { const rc = s.kn + (s.nb || 0); ch = rc < 4 ? s.dw[rc] : s.w[s.w.length - 1]; if (rin === 'b') s.nb++; else s.kn++; s.w = s.w.slice(0, -1); }
    else { ch = s.w[0]; s.w = s.w.slice(1); }
    s.h[seat] = sortH(s.h[seat]) + ch;
    s.t = seat; s.ph = 'd'; s.dr = 1; s.rs = rin ? 1 : 0;
  }
  function nextTurn(s, from) {
    s.pr = -1; s.cl = null;
    if (!s.w.length) { ryuukyoku(s); return; }
    draw(s, (from + 1) % NN(s), false);
  }
  function tenpai(s, seat) { return waitsOf(cnt(s.h[seat]), s.m[seat].length).length > 0; }
  function ryuukyoku(s) {
    const N = NN(s), tp = SEATS(s).map((i) => (tenpai(s, i) ? 1 : 0));
    const n = tp.reduce((a, b) => a + b, 0), d = new Array(N).fill(0);
    if (n > 0 && n < N) for (let i = 0; i < N; i++) d[i] = tp[i] ? 3000 / n : -3000 / (N - n);
    for (let i = 0; i < N; i++) s.sc[i] += d[i];
    s.rr = { k: 'd', tp, d, hs: s.h.slice() };
    if (tp[s.dl]) s.hb++; else { s.rd++; s.hb++; }
    s.last = { id: ++s.seq, k: 'd' };
    endRound(s);
  }
  function kst(s) { if (!s.ks) s.ks = s.sc.map(() => [0, 0, 0, 0]); return s.ks; }
  function endRound(s) {
    s.hn++; s.ph = 'r'; s.cl = null;
    s.over = s.sc.some((v) => v < 0) || s.rd >= s.o.e || s.hn >= s.o.e * 4 ? 1 : 0;
  }
  function win(s, seat, from, wk) {
    if (from >= 0 && s.pr === from) { s.sc[from] += 1000; s.ky--; s.ri[from] = 0; }
    s.pr = -1;
    const ck = from >= 0 && s.cl && s.cl.ck, wr = from >= 0 && s.cl && s.cl.r;
    const r = evalWin(winCtx(s, seat, wk, from < 0, wr, ck));
    const N = NN(s), sm = N === 3, dealer = seat === s.dl, d = new Array(N).fill(0), b = r.base;
    // 3인 쯔모는 「츠모손 없음」: 없는 북가 몫을 두 사람이 반씩 더 내서 합계 = 론 점수. 본장은 3인 200점(쯔모 100×2).
    if (from >= 0) { const p = up100(b * (dealer ? 6 : 4)) + s.hb * (sm ? 200 : 300); d[from] -= p; d[seat] += p; }
    else for (let i = 0; i < N; i++) if (i !== seat) { const f = sm ? (dealer ? 3 : i === s.dl ? 2.5 : 1.5) : (dealer || i === s.dl ? 2 : 1); const p = up100(b * f) + s.hb * 100; d[i] -= p; d[seat] += p; }
    d[seat] += s.ky * 1000; s.ky = 0;
    for (let i = 0; i < N; i++) s.sc[i] += d[i];
    // per-seat result stats: [wins, deal-ins, best han, riichi]
    const ks = kst(s); ks[seat][0]++; if (from >= 0) ks[from][1]++; ks[seat][2] = Math.max(ks[seat][2], r.ym ? 13 : r.han || 0);
    const n = s.kn + 1;
    let h = s.h[seat]; if (from >= 0) h = sortH(h) + (wr ? AKC[[4, 13, 22].indexOf(wk)] : K[wk]); else h = sortH(h.slice(0, -1)) + h.slice(-1);
    s.rr = { k: from < 0 ? 't' : 'r', w: seat, f: from, y: r.y, han: r.han, fu: r.fu, ym: r.ym, lim: r.lim, h, m: s.m[seat].slice(), d, di: s.dw.slice(4, 4 + n), ui: s.ri[seat] ? s.dw.slice(9, 9 + n) : '' };
    if (dealer) s.hb++; else { s.rd++; s.hb = 0; }
    s.last = { id: ++s.seq, k: from < 0 ? 'z' : 'o', s: seat };
    endRound(s);
  }
  function buildClaims(s, from, k, wr) {
    const ron = [], q = [];
    let ponSeat = -1, ponMask = 0;
    const last = !s.w.length, N = NN(s);
    for (let j = 1; j < N; j++) {
      const seat = (from + j) % N, c = cnt(s.h[seat]), nm = s.m[seat].length;
      const w = waitsOf(c, nm);
      if (w.includes(k)) {
        if (!furiten(s, seat, w) && evalWin(winCtx(s, seat, k, false, wr))) ron.push([seat, 1]);
        else { s.tf[seat] = 1; if (s.ri[seat]) s.rf[seat] = 1; }
      }
      if (last || s.ri[seat]) continue;
      let mask = 0;
      if (c[k] >= 2) mask |= 2;
      if (c[k] === 3 && s.kn < 4) mask |= 4;
      if (j === 1 && N === 4 && chiOpts(c, k).length) mask |= 8;   // 3인: 치 없음
      if (mask & 6) { ponSeat = seat; ponMask = mask; }
      else if (mask & 8) q.push([seat, 8]);
    }
    const out = ron.slice();
    if (ponSeat >= 0) out.push([ponSeat, ponMask]);
    q.forEach((e) => out.push(e));
    return out;
  }
  function chiOpts(c, k) {
    if (k >= 27) return [];
    const r = [], n = num(k);
    for (let a = k - 2; a <= k; a++) {
      if (a < 0 || suit(a) !== suit(k) || num(a) > 6 || a < k - n) continue;
      let ok = true;
      for (let x = a; x < a + 3; x++) if (x !== k && !c[x]) ok = false;
      if (ok) r.push(a);
    }
    return r;
  }
  function removeK(h, k, n) { return removeKR(h, k, n).h; }
  function removeKR(h, k, n) { let out = h, r = 0; for (let i = 0; i < n; i++) { let j = out.indexOf(K[k]); if (j < 0 && (k === 4 || k === 13 || k === 22)) { j = out.indexOf(AKC[[4, 13, 22].indexOf(k)]); if (j >= 0) r++; } if (j < 0) throw new Error('no tile'); out = out.slice(0, j) + out.slice(j + 1); } return { h: out, r }; }
  function kanOpts(s, seat) {
    if (s.ph !== 'd' || s.t !== seat || !s.dr || s.ri[seat] || s.kn >= 4 || !s.w.length) return [];
    const c = cnt(s.h[seat]), r = [];
    for (let k = 0; k < 34; k++) if (c[k] === 4) r.push(k);
    for (const m of s.m[seat]) if (m[0] === 'p' && c[ki(m[1])]) r.push(ki(m[1]));
    return r;
  }
  /* 3인 북빼기: 북을 옆에 빼 두면 1장마다 도라 1판, 왕패에서 보충. 리치 중엔 방금 뽑은 북만. */
  function nukiOK(s, seat) {
    if (NN(s) !== 3 || s.ph !== 'd' || s.t !== seat || !s.dr || !s.w.length) return false;
    const h = s.h[seat];
    return s.ri[seat] ? h[h.length - 1] === K[NORTH] : h.includes(K[NORTH]);
  }
  function yaoKinds(h) { const c = cnt(h); return YAO.filter((k) => c[k]).length; }
  /* 구종구패: first own draw, no calls yet, 9+ kinds of 1·9·honors */
  function q9OK(s, seat) {
    return !!s.o.q9 && s.ph === 'd' && s.t === seat && s.dr && s.nc && !s.p[seat] && !s.rs && yaoKinds(s.h[seat]) >= 9;
  }
  function riichiOK(s, seat) {
    return s.ph === 'd' && s.t === seat && s.dr && !s.ri[seat] && menzenOf(s, seat) && s.sc[seat] >= 1000 && s.w.length >= 4;
  }
  /* discard index choices that keep tenpai (for riichi) */
  function riichiIdx(s, seat) {
    const h = s.h[seat], nm = s.m[seat].length, out = [], seen = {};
    for (let i = 0; i < h.length; i++) {
      if (seen[h[i]] != null) { if (seen[h[i]]) out.push(i); continue; }
      const c = cnt(h.slice(0, i) + h.slice(i + 1));
      seen[h[i]] = waitsOf(c, nm).length > 0;
      if (seen[h[i]]) out.push(i);
    }
    return out;
  }

  function actor(s) {
    if (s.ph === 'e') return null;
    if (s.ph === 'd') return s.t;
    if (s.ph === 'c') return s.cl.q[0][0];
    if (s.ph === 'r') return s.hu.length ? s.hu.slice() : [0];
    return null;
  }

  function apply(s, seat, a) {
    if (s.ph === 'r') {
      if (a.t !== 'n') throw new Error('bad');
      if (s.over) {
        let top = 0; for (let i = 1; i < NN(s); i++) if (s.sc[i] > s.sc[top]) top = i;
        s.sc[top] += s.ky * 1000; s.ky = 0; s.ph = 'e';
        s.last = { id: ++s.seq, k: 'e' };
      } else deal(s);
      return s;
    }
    if (s.ph === 'd') {
      if (seat !== s.t) throw new Error('not your turn');
      const h = s.h[seat];
      if (a.t === 'z') {
        if (!canTsumo(s, seat)) throw new Error('no tsumo');
        win(s, seat, -1, ki(h[h.length - 1]));
        return s;
      }
      if (a.t === 'k') {
        if (!kanOpts(s, seat).includes(a.k)) throw new Error('no kan');
        const c = cnt(h);
        s.nc = 0;
        s.last = { id: ++s.seq, k: 'k', s: seat, t: a.k };
        if (c[a.k] === 4) { const x = removeKR(h, a.k, 4); s.h[seat] = x.h; s.m[seat].push('a' + K[a.k] + K[a.k] + '-' + (x.r || '')); }
        else {
          const x = removeKR(h, a.k, 1); s.h[seat] = x.h;
          const i = s.m[seat].findIndex((m) => m[0] === 'p' && ki(m[1]) === a.k), om = s.m[seat][i];
          s.m[seat][i] = 's' + om.slice(1, 4) + ((+(om[4] || 0) + x.r) || '');
          // 창깡: others may ron the added tile
          const q = [], N = NN(s);
          for (let j = 1; j < N; j++) {
            const o = (seat + j) % N, w = waitsOf(cnt(s.h[o]), s.m[o].length);
            if (!w.includes(a.k)) continue;
            if (!furiten(s, o, w) && evalWin(winCtx(s, o, a.k, false, x.r, 1))) q.push([o, 1]);
            else { s.tf[o] = 1; if (s.ri[o]) s.rf[o] = 1; }
          }
          if (q.length) { s.ph = 'c'; s.dr = 0; s.cl = { k: a.k, f: seat, q, ck: 1 }; if (x.r) s.cl.r = 1; return s; }
        }
        s.ip = s.ip.map(() => 0);
        draw(s, seat, 'k');
        return s;
      }
      if (a.t === 'b') {
        if (!nukiOK(s, seat)) throw new Error('no nuki');
        const ri = s.ri[seat];
        s.h[seat] = ri ? h.slice(0, -1) : removeK(h, NORTH, 1); s.nd[seat]++; s.rs = 0;
        s.last = { id: ++s.seq, k: 'b', s: seat };
        // 빼 둔 북으로도 론할 수 있어요(창깡 역은 없음)
        const q = [];
        for (let j = 1; j < 3; j++) {
          const o = (seat + j) % 3, w = waitsOf(cnt(s.h[o]), s.m[o].length);
          if (!w.includes(NORTH)) continue;
          if (!furiten(s, o, w) && evalWin(winCtx(s, o, NORTH, false, 0, 0))) q.push([o, 1]);
          else { s.tf[o] = 1; if (s.ri[o]) s.rf[o] = 1; }
        }
        if (q.length) { s.ph = 'c'; s.dr = 0; s.cl = { k: NORTH, f: seat, q, nk: 1 }; return s; }
        draw(s, seat, 'b');
        return s;
      }
      if (a.t === 'x') {
        const i = a.i | 0;
        if (i < 0 || i >= h.length || h.length % 3 !== 2) throw new Error('bad idx');
        if (s.ri[seat] && i !== h.length - 1) throw new Error('riichi: tsumogiri');
        let rch = false;
        if (a.r) { if (!riichiOK(s, seat) || !riichiIdx(s, seat).includes(i)) throw new Error('no riichi'); rch = true; }
        else if (s.ri[seat]) s.ip[seat] = 0;
        const ch = h[i], dbl = s.nc && !s.p[seat];
        s.h[seat] = sortH(h.slice(0, i) + h.slice(i + 1));
        s.p[seat] += ch + (rch ? '*' : '');
        s.tf[seat] = 0; s.dr = 0; s.rs = 0;
        if (rch) { s.ri[seat] = dbl ? 2 : 1; s.ip[seat] = 1; s.sc[seat] -= 1000; s.ky++; s.pr = seat; kst(s)[seat][3]++; }
        s.last = { id: ++s.seq, k: 'x', s: seat, t: ki(ch), r: rch ? 1 : 0 };
        const red = AKA[ch] != null, q = buildClaims(s, seat, ki(ch), red);
        if (q.length) { s.ph = 'c'; s.cl = { k: ki(ch), f: seat, q }; if (red) s.cl.r = 1; }
        else nextTurn(s, seat);
        return s;
      }
      if (a.t === 'q') {
        if (!q9OK(s, seat)) throw new Error('no q9');
        s.rr = { k: 'q', w: seat, h: s.h[seat] };
        s.hb++;
        s.last = { id: ++s.seq, k: 'q', s: seat };
        endRound(s);
        return s;
      }
      throw new Error('bad action');
    }
    if (s.ph === 'c') {
      const cl = s.cl, e = cl.q[0];
      if (seat !== e[0]) throw new Error('not asked');
      const mask = e[1], k = cl.k, h = s.h[seat];
      if (a.t === 'p') {
        if (mask & 1) { s.tf[seat] = 1; if (s.ri[seat]) s.rf[seat] = 1; }
        cl.q.shift();
        if (!cl.q.length) { if (cl.ck) { s.cl = null; s.ip = s.ip.map(() => 0); draw(s, cl.f, 'k'); } else if (cl.nk) { s.cl = null; draw(s, cl.f, 'b'); } else nextTurn(s, cl.f); }
        return s;
      }
      if (a.t === 'r') { if (!(mask & 1)) throw new Error('no ron'); win(s, seat, cl.f, k); return s; }
      const mark = () => { s.p[cl.f] += '~'; s.ip = s.ip.map(() => 0); s.pr = -1; s.cl = null; s.nc = 0; };
      const cr = cl.r || 0;
      if (a.t === 'n') {
        if (!(mask & 2)) throw new Error('no pon');
        const x = removeKR(h, k, 2); s.h[seat] = x.h; s.m[seat].push('p' + K[k] + K[k] + cl.f + ((x.r + cr) || '')); mark();
        s.t = seat; s.ph = 'd'; s.dr = 0; s.rs = 0;
        s.last = { id: ++s.seq, k: 'n', s: seat, t: k };
        return s;
      }
      if (a.t === 'm') {
        if (!(mask & 4)) throw new Error('no kan');
        const x = removeKR(h, k, 3); s.h[seat] = x.h; s.m[seat].push('k' + K[k] + K[k] + cl.f + ((x.r + cr) || '')); mark();
        draw(s, seat, 'k');
        s.last = { id: ++s.seq, k: 'k', s: seat, t: k };
        return s;
      }
      if (a.t === 'c') {
        if (!(mask & 8) || !chiOpts(cnt(h), k).includes(a.a)) throw new Error('no chi');
        let nh = h, rd = cr; for (let x = a.a; x < a.a + 3; x++) if (x !== k) { const y = removeKR(nh, x, 1); nh = y.h; rd += y.r; }
        s.h[seat] = nh; s.m[seat].push('c' + K[a.a] + K[k] + cl.f + (rd || '')); mark();
        s.t = seat; s.ph = 'd'; s.dr = 0; s.rs = 0;
        s.last = { id: ++s.seq, k: 'c', s: seat, t: k };
        return s;
      }
      throw new Error('bad claim');
    }
    throw new Error('game over');
  }

  function result(s) {
    if (s.ph !== 'e') return null;
    const mx = Math.max(...s.sc);
    const winners = SEATS(s).filter((i) => s.sc[i] === mx);
    const order = SEATS(s).sort((a, b) => s.sc[b] - s.sc[a]);
    const ks = s.ks || s.sc.map(() => [0, 0, 0, 0]);
    const stats = [{ label: '화료', values: ks.map((k) => String(k[0])) }, { label: '방총', values: ks.map((k) => String(k[1])) },
      { label: '최고 판', values: ks.map((k) => (k[2] >= 13 ? '역만' : k[2] + '판')) }, { label: '리치', values: ks.map((k) => String(k[3])) }];
    return { winners, stats, title: '최종 점수', text: order.map((i, r) => (r + 1) + '등 ' + s.sc[i] + '점').join(' · '), _order: order };
  }

  /* ---------- AI ---------- */
  function visibleOf(s, seat) {
    const v = new Array(34).fill(0);
    for (const ch of s.h[seat]) v[ki(ch)]++;
    if (NN(s) === 3) { for (let k = 1; k <= 7; k++) v[k] = 4; v[NORTH] += s.nd.reduce((a, b) => a + b, 0); }   // 3인: 없는 패는 「다 보임」 처리
    for (let i = 0; i < NN(s); i++) { for (const k of pondKinds(s.p[i])) v[k]++; for (const m of meldsOf(s, i)) meldTiles(m).forEach((k) => v[k]++); }
    for (const ch of s.dw.slice(4, 5 + s.kn)) v[ki(ch)]++;
    // called tiles are counted in both pond and meld: subtract one per call
    for (let i = 0; i < NN(s); i++) for (const m of meldsOf(s, i)) if (m.f >= 0) v[m.c]--;
    return v;
  }
  function ukeire(c, nm, sh, vis) {
    let n = 0;
    for (let k = 0; k < 34; k++) { if (vis[k] >= 4) continue; c[k]++; if (shanten(c, nm) < sh) n += 4 - vis[k]; c[k]--; }
    return n;
  }
  function yakuhaiFor(s, seat, k) { const N = NN(s); return DRG.includes(k) || k === 27 + ((seat - s.dl + N) % N) || k === 27 + Math.min(1, (s.rd / N) | 0); }
  function danger(s, seat, k, vis) {
    let worst = 0;
    for (let r = 0; r < NN(s); r++) {
      if (r === seat || !s.ri[r]) continue;
      const pk = pondKinds(s.p[r]);
      let d;
      if (pk.includes(k)) d = 0;
      else if (k >= 27) d = vis[k] >= 3 ? 0.3 : vis[k] === 2 ? 1 : 2.5;
      else {
        const n = num(k), base = n === 0 || n === 8 ? 3 : n === 1 || n === 7 ? 4.5 : 6;
        const lo = n >= 3 && pk.includes(k - 3), hi = n <= 5 && pk.includes(k + 3);
        const both = (n < 3 || lo) && (n > 5 || hi);
        d = both ? base * 0.35 : lo || hi ? base * 0.7 : base;
      }
      worst = Math.max(worst, d);
    }
    return worst;
  }
  function tileValue(s, seat, c, k) {
    // higher = keep
    let v = 0;
    if (k >= 27) { v = yakuhaiFor(s, seat, k) ? (c[k] >= 2 ? 6 : 1.5) : (c[k] >= 2 ? 3 : 0); }
    else {
      const n = num(k); v = n === 0 || n === 8 ? 1 : n === 1 || n === 7 ? 2 : 3;
      for (let d = -2; d <= 2; d++) { if (!d) continue; const x = k + d; if (x >= 0 && x < 27 && suit(x) === suit(k) && c[x]) v += Math.abs(d) === 1 ? 2 : 1; }
      if (c[k] >= 2) v += 2;
    }
    if (s.dw.slice(4, 5 + s.kn).split('').some((ch) => doraOf(ki(ch), NN(s) === 3) === k)) v += 2;
    if (c[k] === 1 && (k === 4 || k === 13 || k === 22) && s.h[seat].includes(AKC[[4, 13, 22].indexOf(k)])) v += 2;
    return v;
  }
  function chooseDiscard(s, seat, lv) {
    const h = s.h[seat], nm = s.m[seat].length, c = cnt(h);
    const vis = lv >= 2 ? visibleOf(s, seat) : null;
    const others = SEATS(s).some((r) => r !== seat && s.ri[r]);
    const kinds = []; for (let k = 0; k < 34; k++) if (c[k]) kinds.push(k);
    const ev = kinds.map((k) => { c[k]--; const sh = shanten(c, nm); c[k]++; return { k, sh }; });
    const minSh = Math.min(...ev.map((e) => e.sh));
    for (const e of ev) {
      c[e.k]--;
      e.uk = lv >= 2 && e.sh === minSh ? ukeire(c, nm, e.sh, vis) : 0;
      c[e.k]++;
      e.val = tileValue(s, seat, c, e.k);
      e.dg = lv >= 2 && others ? danger(s, seat, e.k, vis) : 0;
    }
    let pick;
    const sty = (L.aiStyle && L.aiStyle(seat)) || 'bal'; // AI 성향(core 라운드 31): 수비형은 일찍 접고, 공격·도박형은 더 밀어붙임
    const dMin = (lv === 3 ? 2 : 3) + (sty === 'def' ? -1 : sty === 'agg' ? 1 : sty === 'gamble' ? 2 : 0);
    const defend = others && lv >= 2 && (minSh >= dMin || (lv === 3 && sty !== 'gamble' && minSh >= 1 && s.w.length < (sty === 'def' ? 36 : sty === 'agg' ? 14 : 24)));
    if (lv === 1) {
      if (Math.random() < 0.3) { const pool = ev.filter((e) => e.sh <= minSh + 1); pick = pool[U.rand(pool.length)]; }
      else { const pool = ev.filter((e) => e.sh === minSh).sort((a, b) => a.val - b.val); pick = pool[0]; }
    } else if (defend) {
      pick = ev.slice().sort((a, b) => a.dg - b.dg || a.sh - b.sh || a.val - b.val)[0];
    } else {
      const pool = ev.filter((e) => e.sh === minSh);
      pool.sort((a, b) => (b.uk - a.uk) * (lv === 3 ? 1 : 0.6) + (a.val - b.val) * (lv === 3 ? 0.5 : 1) + (lv === 3 ? (a.dg - b.dg) * 2 : 0));
      pick = pool[0];
    }
    let i = h.lastIndexOf(K[pick.k]); if (i < 0) i = h.lastIndexOf(AKC[[4, 13, 22].indexOf(pick.k)]);
    return { i, sh: pick.sh, k: pick.k };
  }
  function suggest(s, seat) { if (s.ri[seat]) return s.h[seat].length - 1; return chooseDiscard(s, seat, 3).i; }
  function yakuPath(s, seat, c, melds) {
    // c: closed counts after call, melds parsed incl. new meld
    const all = c.slice(); melds.forEach((m) => meldTiles(m).forEach((k) => all[k]++));
    if (melds.some((m) => m.t !== 'c' && yakuhaiFor(s, seat, m.k))) return true;
    for (let k = 27; k < 34; k++) if (c[k] >= 2 && yakuhaiFor(s, seat, k)) return true;
    let y = 0; for (let k = 0; k < 34; k++) if (all[k] && yao(k)) y += all[k];
    if (y === 0 && melds.every((m) => meldTiles(m).every((k) => !yao(k)))) return true;
    if (y <= 1 && melds.every((m) => meldTiles(m).every((k) => !yao(k)))) return 'maybe';
    const su = [0, 0, 0]; let hon = 0; for (let k = 0; k < 34; k++) if (all[k]) { if (k >= 27) hon += all[k]; else su[suit(k)] += all[k]; }
    const tot = su[0] + su[1] + su[2] + hon, mx = Math.max(...su);
    if (mx + hon >= tot - 1 && melds.every((m) => m.k >= 27 || suit(m.k) === su.indexOf(mx))) return true;
    return false;
  }
  function aiClaim(s, seat, lv) {
    const e = s.cl.q[0], mask = e[1], k = s.cl.k;
    if (mask & 1) return { t: 'r' };
    const c = cnt(s.h[seat]), nm = s.m[seat].length, melds = meldsOf(s, seat);
    const sh0 = shanten(c, nm);
    const others = SEATS(s).some((r) => r !== seat && s.ri[r]);
    if (mask & 4 && lv === 1 && Math.random() < 0.5) return { t: 'm' };
    const opts = [];
    if (mask & 2) { const c2 = c.slice(); c2[k] -= 2; opts.push({ a: { t: 'n' }, c2, m: { t: 'p', k } }); }
    if (mask & 8) for (const a of chiOpts(c, k)) { const c2 = c.slice(); for (let x = a; x < a + 3; x++) if (x !== k) c2[x]--; opts.push({ a: { t: 'c', a }, c2, m: { t: 'c', k: a } }); }
    let best = null;
    for (const o of opts) {
      const sh1 = shanten(o.c2, nm + 1);
      const yh = o.m.t === 'p' && yakuhaiFor(s, seat, k);
      const yp = yakuPath(s, seat, o.c2, melds.concat([o.m]));
      let ok;
      if (lv === 1) ok = yh || (sh1 < sh0 && Math.random() < 0.45);
      else if (lv === 2) ok = yh || (sh1 < sh0 && yp === true) || (sh1 < sh0 && yp === 'maybe' && nm > 0);
      else {
        ok = (yh && (sh1 <= sh0)) || (sh1 < sh0 && yp === true && (nm > 0 || sh0 >= 2 || o.m.t === 'p'));
        if (others && sh1 >= 2) ok = false;
      }
      const sty = (L.aiStyle && L.aiStyle(seat)) || 'bal';
      if (!ok && lv >= 2 && (sty === 'agg' || sty === 'gamble') && sh1 < sh0 && yp === 'maybe' && Math.random() < 0.5) ok = true;
      if (ok && sty === 'def' && !yh && Math.random() < 0.35) ok = false;
      if (ok && (!best || sh1 < best.sh)) best = { a: o.a, sh: sh1 };
    }
    return best ? best.a : { t: 'p' };
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph === 'r') return { t: 'n' };
    if (s.ph === 'c') return aiClaim(s, seat, lv);
    if (s.ph !== 'd') return null;
    if (canTsumo(s, seat)) return { t: 'z' };
    if (nukiOK(s, seat)) return { t: 'b' };
    if (s.ri[seat]) return { t: 'x', i: s.h[seat].length - 1 };
    if (q9OK(s, seat) && (lv < 3 || yaoKinds(s.h[seat]) < 11)) return { t: 'q' };
    const ko = kanOpts(s, seat);
    if (ko.length && (lv === 1 || Math.random() < 0.85)) {
      const k = ko[0], c = cnt(s.h[seat]), nm = s.m[seat].length;
      const sh0 = shanten(c, nm);
      const c2 = c.slice(); const isAn = c[k] === 4; c2[k] -= isAn ? 4 : 1;
      if (lv === 1 || shanten(c2, isAn ? nm + 1 : nm) <= sh0) return { t: 'k', k };
    }
    const d = chooseDiscard(s, seat, lv);
    if (d.sh === 0 && riichiOK(s, seat) && riichiIdx(s, seat).includes(d.i)) return { t: 'x', i: d.i, r: 1 };
    return { t: 'x', i: d.i };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph === 'r') return 4200;
    if (s.ph === 'c') return 380;
    return [0, 900, 700, 560][lv || 2];
  }

  /* ---------- tile art ---------- */
  const FONT = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  const BODY = '"IBM Plex Sans KR", sans-serif';
  const MONO = '"IBM Plex Mono", monospace';
  const INK = '#1e1a2a', RED = '#c23a2e', BLUE = '#2a5aa8', GRN = '#1f7a4a';
  const PIN = {
    1: [[0.5, 0.5]], 2: [[0.5, 0.27], [0.5, 0.73]], 3: [[0.24, 0.22], [0.5, 0.5], [0.76, 0.78]],
    4: [[0.28, 0.27], [0.72, 0.27], [0.28, 0.73], [0.72, 0.73]], 5: [[0.26, 0.23], [0.74, 0.23], [0.5, 0.5], [0.26, 0.77], [0.74, 0.77]],
    6: [[0.3, 0.2], [0.7, 0.2], [0.3, 0.5], [0.7, 0.5], [0.3, 0.8], [0.7, 0.8]],
    7: [[0.22, 0.15], [0.5, 0.25], [0.78, 0.35], [0.3, 0.6], [0.7, 0.6], [0.3, 0.85], [0.7, 0.85]],
    8: [[0.3, 0.14], [0.7, 0.14], [0.3, 0.38], [0.7, 0.38], [0.3, 0.62], [0.7, 0.62], [0.3, 0.86], [0.7, 0.86]],
    9: [[0.2, 0.18], [0.5, 0.18], [0.8, 0.18], [0.2, 0.5], [0.5, 0.5], [0.8, 0.5], [0.2, 0.82], [0.5, 0.82], [0.8, 0.82]],
  };
  const SOU = {
    2: [[0.5, 0.27], [0.5, 0.73]], 3: [[0.5, 0.27], [0.3, 0.73], [0.7, 0.73]], 4: [[0.3, 0.27], [0.7, 0.27], [0.3, 0.73], [0.7, 0.73]],
    5: [[0.25, 0.27], [0.75, 0.27], [0.5, 0.5], [0.25, 0.73], [0.75, 0.73]], 6: [[0.2, 0.27], [0.5, 0.27], [0.8, 0.27], [0.2, 0.73], [0.5, 0.73], [0.8, 0.73]],
    7: [[0.5, 0.17], [0.2, 0.5], [0.5, 0.5], [0.8, 0.5], [0.2, 0.83], [0.5, 0.83], [0.8, 0.83]],
    8: [[0.17, 0.27], [0.39, 0.27], [0.61, 0.27], [0.83, 0.27], [0.17, 0.73], [0.39, 0.73], [0.61, 0.73], [0.83, 0.73]],
    9: [[0.2, 0.17], [0.5, 0.17], [0.8, 0.17], [0.2, 0.5], [0.5, 0.5], [0.8, 0.5], [0.2, 0.83], [0.5, 0.83], [0.8, 0.83]],
  };
  const cache = new Map();
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function face(c, k, w, h) {
    const red = k >= 34; if (red) k = [4, 13, 22][k - 34];
    const px = w * 0.1, py = h * 0.09, fw = w - 2 * px, fh = h - 2 * py - h * 0.06;
    const X = (u) => px + u * fw, Y = (v) => py + v * fh;
    c.textAlign = 'center'; c.textBaseline = 'middle';
    if (k < 9) {
      c.fillStyle = red ? RED : INK; c.font = (h * 0.44) + 'px ' + FONT; c.fillText(String(k + 1), w / 2, Y(0.3));
      c.fillStyle = RED; c.font = (h * 0.3) + 'px ' + FONT; c.fillText('만', w / 2, Y(0.78));
    } else if (k < 18) {
      const n = k - 8, rad = n === 1 ? fw * 0.4 : n <= 4 ? fw * 0.2 : n <= 6 ? fw * 0.17 : fw * 0.135;
      PIN[n].forEach((p, i) => {
        const col = n === 1 ? RED : n === 3 || n === 5 || n === 9 ? (i === (n === 3 ? 1 : n === 5 ? 2 : 4) ? RED : n === 9 && i < 3 ? BLUE : GRN) : n === 7 ? (i < 3 ? GRN : RED) : n === 6 ? (i < 2 ? GRN : RED) : n === 2 || n === 8 ? BLUE : GRN;
        c.beginPath(); c.arc(X(p[0]), Y(p[1]), rad, 0, Math.PI * 2); c.fillStyle = red ? RED : col; c.fill();
        c.beginPath(); c.arc(X(p[0]), Y(p[1]), rad * 0.45, 0, Math.PI * 2); c.fillStyle = '#f6efdc'; c.fill();
        if (n === 1) { c.beginPath(); c.arc(X(p[0]), Y(p[1]), rad * 0.2, 0, Math.PI * 2); c.fillStyle = RED; c.fill(); }
      });
    } else if (k < 27) {
      const n = k - 17;
      if (n === 1) {
        c.fillStyle = GRN; c.beginPath(); c.ellipse(w / 2, Y(0.58), fw * 0.32, fh * 0.3, 0, 0, Math.PI * 2); c.fill();
        c.fillStyle = RED; c.beginPath(); c.arc(w / 2, Y(0.26), fw * 0.16, 0, Math.PI * 2); c.fill();
        c.fillStyle = '#f6efdc'; c.fillRect(w / 2 - fw * 0.04, Y(0.4), fw * 0.08, fh * 0.42);
      } else {
        const akaS = red; const bw = n >= 8 ? fw * 0.13 : fw * 0.16, bh = n >= 7 ? fh * 0.26 : fh * 0.36;
        SOU[n].forEach((p, i) => {
          const red = (n === 5 && i === 2) || (n === 7 && i === 0) || (n === 9 && (i === 1 || i === 4 || i === 7));
          c.fillStyle = red || akaS ? RED : GRN; rr(c, X(p[0]) - bw / 2, Y(p[1]) - bh / 2, bw, bh, bw * 0.4); c.fill();
          c.fillStyle = 'rgba(246,239,220,.85)'; c.fillRect(X(p[0]) - bw / 2, Y(p[1]) - bh * 0.04, bw, bh * 0.08);
        });
      }
    } else if (k < 31) {
      c.fillStyle = INK; c.font = (h * 0.5) + 'px ' + FONT; c.fillText(WN[k - 27], w / 2, h * 0.47);
    } else if (k === 31) {
      c.strokeStyle = BLUE; c.lineWidth = Math.max(1.2, w * 0.07); rr(c, X(0.12), Y(0.12), fw * 0.76, fh * 0.76, w * 0.06); c.stroke();
    } else {
      c.fillStyle = k === 32 ? GRN : RED; c.font = (h * 0.5) + 'px ' + FONT; c.fillText(k === 32 ? '발' : '중', w / 2, h * 0.47);
    }
    if (k >= 9 && k < 27 && w >= 18) {
      c.fillStyle = 'rgba(30,26,42,.75)'; c.font = '700 ' + Math.round(h * 0.2) + 'px ' + MONO; c.textAlign = 'left'; c.textBaseline = 'top';
      c.fillText(String(num(k) + 1), w * 0.06, h * 0.02);
    }
  }
  /* 패 그림: 전통 / 모던(이 기기에 저장) */
  const SKIN_KEY = 'lounge.mj.skin';
  let skin = 'classic';
  try { if (localStorage.getItem(SKIN_KEY) === 'modern') skin = 'modern'; } catch (e) {}
  function setSkin(v) { skin = v; try { localStorage.setItem(SKIN_KEY, v); } catch (e) {} cache.clear(); urlCache.clear(); }
  const MFONT = '"IBM Plex Sans KR", system-ui, sans-serif';
  const MCOL = ['#c8372b', '#2563b8', '#1d8049', '#3b3546'];
  /* 모던: 납작한 흰 면 + 큰 숫자 + 무늬 색 띠. 작은 크기에서도 읽히게 */
  function modernTile(c, k, w, h) {
    const red = k >= 34; if (red) k = [4, 13, 22][k - 34];
    const r = Math.max(2, w * 0.14), su = suit(k);
    c.fillStyle = red ? '#fff0ec' : '#fbfaf6'; rr(c, 0, 0, w, h, r); c.fill();
    c.strokeStyle = 'rgba(0,0,0,.28)'; c.lineWidth = 1; rr(c, 0.5, 0.5, w - 1, h - 1, r); c.stroke();
    c.textAlign = 'center'; c.textBaseline = 'middle';
    if (k < 27) {
      const col = red ? '#d8261a' : MCOL[su], bandH = h * 0.2;
      c.save(); rr(c, 0, 0, w, h, r); c.clip();
      c.fillStyle = col; c.fillRect(0, h - bandH, w, bandH);
      if (su === 1) { c.fillStyle = 'rgba(255,255,255,.9)'; for (let i = 0; i < 3; i++) { c.beginPath(); c.arc(w * (0.27 + i * 0.23), h - bandH / 2, Math.max(1, bandH * 0.2), 0, Math.PI * 2); c.fill(); } }
      else if (su === 2) { c.fillStyle = 'rgba(255,255,255,.9)'; for (let i = 0; i < 3; i++) c.fillRect(w * (0.24 + i * 0.23), h - bandH * 0.75, Math.max(1, w * 0.07), bandH * 0.5); }
      else { c.fillStyle = '#fff'; c.font = '700 ' + Math.round(bandH * 0.8) + 'px ' + MFONT; c.fillText('만', w / 2, h - bandH / 2 + 0.5); }
      c.restore();
      c.fillStyle = col; c.font = '800 ' + Math.round(h * 0.56) + 'px ' + MFONT;
      c.fillText(String(num(k) + 1), w / 2, h * 0.42);
      if (red) { // 적도라 표시: 오른쪽 위 빨간 삼각 + 별
        c.fillStyle = '#d8261a'; c.beginPath(); c.moveTo(w - w * 0.42, 0); c.lineTo(w - r * 0.3, 0); c.lineTo(w, r * 0.3); c.lineTo(w, h * 0.3); c.closePath(); c.fill();
      }
    } else if (k < 31) {
      c.fillStyle = MCOL[3]; c.font = '800 ' + Math.round(h * 0.5) + 'px ' + MFONT; c.fillText(WN[k - 27], w / 2, h * 0.48);
      c.fillStyle = 'rgba(59,53,70,.18)'; c.fillRect(w * 0.2, h * 0.84, w * 0.6, Math.max(1, h * 0.04));
    } else if (k === 31) {
      c.strokeStyle = '#2563b8'; c.lineWidth = Math.max(1.5, w * 0.09); rr(c, w * 0.24, h * 0.2, w * 0.52, h * 0.58, w * 0.08); c.stroke();
    } else {
      c.fillStyle = k === 32 ? '#1d8049' : '#c8372b'; c.font = '800 ' + Math.round(h * 0.5) + 'px ' + MFONT; c.fillText(k === 32 ? '발' : '중', w / 2, h * 0.48);
    }
  }
  function tileCanvas(k, w, h, dpr) {
    const CB = k < 0 && L.ui && L.ui.cardBack ? L.ui.cardBack() : null;  // 설정 「카드 뒷면」(라운드 34) — 패 뒷면 색·무늬
    const key = skin[0] + k + '|' + w + '|' + h + '|' + dpr + (CB ? CB.id : '');
    let cv = cache.get(key);
    if (cv) return cv;
    cv = document.createElement('canvas');
    cv.width = Math.ceil(w * dpr); cv.height = Math.ceil(h * dpr);
    const c = cv.getContext('2d'); c.scale(dpr, dpr);
    const r = Math.max(2, w * 0.14), th = Math.max(2, h * 0.08);
    if (k < 0) {
      c.fillStyle = '#e9dcbf'; rr(c, 0, 0, w, h, r); c.fill();
      const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, CB ? CB.b : '#2f7c74'); g.addColorStop(1, CB ? CB.a : '#1d5550');
      c.fillStyle = g; rr(c, 0, 0, w, h - th, r); c.fill();
      if (CB && w > 14) { c.save(); rr(c, 0, 0, w, h - th, r); c.clip(); c.globalAlpha = 0.35; L.ui.drawCardBack(c, w * 0.12, h * 0.1, w * 0.76, (h - th) * 0.8, r * 0.6); c.restore(); }
      c.strokeStyle = CB ? CB.line : 'rgba(227,174,69,.55)'; c.lineWidth = 1; c.beginPath();
      c.moveTo(w / 2, h * 0.18); c.lineTo(w * 0.78, (h - th) / 2); c.lineTo(w / 2, (h - th) * 0.82); c.lineTo(w * 0.22, (h - th) / 2); c.closePath(); c.stroke();
    } else if (skin === 'modern') {
      c.fillStyle = '#9a9488'; rr(c, 0, 0, w, h, r); c.fill();
      modernTile(c, k, w, h - Math.max(1.5, th * 0.6));
    } else {
      c.fillStyle = '#2b766e'; rr(c, 0, 0, w, h, r); c.fill();
      const g = c.createLinearGradient(0, 0, 0, h); g.addColorStop(0, '#fffaf0'); g.addColorStop(1, '#e8dcc2');
      c.fillStyle = g; rr(c, 0, 0, w, h - th, r); c.fill();
      c.strokeStyle = 'rgba(0,0,0,.12)'; c.lineWidth = 0.8; rr(c, 0.4, 0.4, w - 0.8, h - th - 0.8, r); c.stroke();
      face(c, k, w, h - th);
    }
    if (cache.size > 900) cache.clear();
    cache.set(key, cv);
    return cv;
  }
  const urlCache = new Map();
  function tileURL(k, w, h) {
    const key = skin[0] + k + '|' + w + '|' + h;
    if (!urlCache.has(key)) urlCache.set(key, tileCanvas(k, w, h, 2).toDataURL());
    return urlCache.get(key);
  }

  /* ---------- texts ---------- */
  const YAKU = [
    ['1판', [
      ['리치', '1판 · 멘젠만', '울지 않고(치·퐁 안 하고) 텐파이(1장만 더 오면 완성)일 때 1000점 막대를 걸고 「리치」! 그 뒤로는 뽑은 패를 그대로 버려요.', '예: 123만 456통 789삭 55삭 + 67만 → 5만·8만 기다리며 리치'],
      ['일발', '1판 · 리치 때만', '리치하고 한 바퀴(내 다음 버림까지) 안에 완성. 누가 치·퐁·깡하면 사라져요.', ''],
      ['멘젠쯔모', '1판 · 멘젠만', '울지 않고 내가 직접 뽑은 패로 완성(쯔모)하면 그것만으로 1판!', ''],
      ['핑후', '1판 · 멘젠만', '몸통 4개가 전부 연속(슌쯔), 머리는 역패가 아니고, 양쪽 기다림(양면)으로 완성.', '예: 234만 567만 345통 678삭 99삭, 23통 → 1통·4통 대기'],
      ['탕야오', '1판', '1·9와 글자패(동남서북백발중) 없이 2~8 숫자패로만 완성. 울어도 돼요.', '예: 234만 456통 678삭 333삭 55만'],
      ['이페코', '1판 · 멘젠만', '똑같은 연속 몸통 2개.', '예: 223344만 …'],
      ['역패', '1판', '백·발·중 3장, 또는 내 바람(자풍)·이번 바람(장풍) 3장. 울어도 돼요. 가장 쉬운 역!', '예: 중중중 + 나머지 아무 모양'],
      ['해저로월', '1판', '마지막 남은 패를 뽑아 쯔모.', ''],
      ['하저로어', '1판', '마지막 버림패로 론.', ''],
      ['영상개화', '1판', '깡을 하고 보충으로 뽑은 패로 쯔모.', ''],
      ['창깡', '1판', '누가 퐁 해 둔 패에 1장을 더 붙여 깡(가깡)할 때, 그 1장이 내가 기다리던 패면 가로채서 론!', ''],
    ]],
    ['2판', [
      ['더블리치', '2판 · 멘젠만', '첫 버림 때 바로 리치. 그 전에 아무도 치·퐁·깡을 안 했어야 해요. (리치 1판 대신 2판)', ''],
      ['삼색동순', '2판 (울면 1판)', '만·통·삭에서 같은 숫자의 연속 몸통.', '예: 345만 345통 345삭'],
      ['일기통관', '2판 (울면 1판)', '한 종류로 123·456·789.', '예: 123통 456통 789통'],
      ['찬타', '2판 (울면 1판)', '몸통·머리 모두에 1·9나 글자패가 들어가요(연속 몸통 1개 이상).', '예: 123만 789통 동동동 999삭 백백'],
      ['치또이츠', '2판 · 멘젠만', '서로 다른 2장짜리 짝 7개. 특별한 모양!', '예: 11만 44만 66통 22삭 99삭 남남 중중'],
      ['또이또이', '2판', '몸통 4개가 모두 같은 패 3장(커쯔).', '예: 222만 555통 888삭 북북북 33통'],
      ['산안커', '2판', '울지 않고 직접 모은 같은 패 3장 몸통이 3개.', ''],
      ['삼색동각', '2판', '만·통·삭 같은 숫자 3장씩.', '예: 777만 777통 777삭'],
      ['소삼원', '2판', '백·발·중 중 2개는 3장, 1개는 머리(2장). 역패 2판도 따로 붙어요.', ''],
      ['혼노두', '2판', '1·9와 글자패로만 완성.', ''],
      ['산깡쯔', '2판', '깡 3번.', ''],
    ]],
    ['3판 이상', [
      ['혼일색', '3판 (울면 2판)', '숫자패는 한 종류 + 글자패만.', '예: 123삭 456삭 999삭 발발발 서서'],
      ['준찬타', '3판 (울면 2판)', '글자패 없이 모든 몸통·머리에 1이나 9.', '예: 123만 789만 123통 999삭 11삭'],
      ['량페코', '3판 · 멘젠만', '이페코(똑같은 연속 몸통 2개)가 두 쌍.', ''],
      ['청일색', '6판 (울면 5판)', '한 종류 숫자패로만 완성. 거의 만관 이상!', '예: 11123455678999통'],
    ]],
    ['역만', [
      ['국사무쌍', '역만', '1·9 숫자패 6종 + 글자패 7종을 한 장씩, 그중 하나는 2장.', ''],
      ['스안커', '역만', '울지 않고 직접 모은 3장 몸통 4개.', ''],
      ['대삼원', '역만', '백·발·중 모두 3장씩.', ''],
      ['소사희', '역만', '바람 4종 중 3개는 3장, 1개는 머리.', ''],
      ['대사희', '역만', '바람 4종 모두 3장씩.', ''],
      ['자일색', '역만', '글자패로만 완성.', ''],
      ['녹일색', '역만', '초록 패(2·3·4·6·8삭, 발)로만 완성.', ''],
      ['청노두', '역만', '1과 9 숫자패로만 완성.', ''],
      ['구련보등', '역만', '한 종류로 1112345678999 + 아무 1장.', ''],
      ['스깡쯔', '역만', '깡 4번.', ''],
      ['천화', '역만 · 친만', '친이 처음 받은 14장이 이미 완성!', ''],
      ['지화', '역만 · 자만', '자가 첫 번째로 뽑은 패로 바로 쯔모(그 전에 아무도 치·퐁·깡 안 함).', ''],
    ]],
  ];
  function hanIcon(t) {
    const col = /역만/.test(t) ? '#c23a2e' : '#1e1a2a';
    const n = /역만/.test(t) ? '★' : (t.match(/\d/) || ['?'])[0];
    return '<svg viewBox="0 0 24 32" width="24" height="32"><rect x="1" y="1" width="22" height="30" rx="4" fill="#f6efdc" stroke="#2b766e" stroke-width="2"/><text x="12" y="21" text-anchor="middle" font-size="14" font-weight="700" fill="' + col + '">' + n + '</text></svg>';
  }
  const CODEX = YAKU.map(([h, rows]) => ({
    h, p: h === '역만' ? ['한 번에 큰 점수(자 32000점 / 친 48000점)! 아주 드물어요.'] : h === '1판' ? ['역이 1개 이상 있어야 화료(완성)할 수 있어요. 도라는 역이 아니에요(점수만 늘려요).'] : [],
    rows: rows.map((r) => ({ icon: hanIcon(r[1]), name: r[0], tag: r[1], desc: r[2] + (r[3] ? ' ' + r[3] : '') })),
  })).concat([
    { h: '패 읽기', p: ['패는 34종 × 4장 = 136장.'], rows: [
      { icon: '🔴', name: '만수패 (만)', tag: '숫자 1~9', desc: '큰 숫자 + 빨간 「만」 글자.' },
      { icon: '🔵', name: '통수패 (통)', tag: '숫자 1~9', desc: '동그라미 개수가 숫자예요. 왼쪽 위 작은 숫자도 있어요.' },
      { icon: '🟢', name: '삭수패 (삭)', tag: '숫자 1~9', desc: '대나무 막대 개수가 숫자예요. 1삭은 새싹 그림.' },
      { icon: '🧭', name: '바람패', tag: '동·남·서·북', desc: '내 자리 바람(자풍)과 이번 판 바람(장풍)은 3장 모으면 역패.' },
      { icon: '🐉', name: '삼원패', tag: '백·발·중', desc: '백은 빈 테두리, 발은 초록, 중은 빨강. 3장 모으면 언제나 역패.' },
      { icon: '✨', name: '도라', tag: '보너스', desc: '가운데 「도라 표시패」의 다음 패가 도라. 1장마다 +1판. 예: 표시 3만 → 도라 4만, 표시 9통 → 1통, 북 → 동, 중 → 백.' },
      { icon: '🟥', name: '적도라 (빨간 5)', tag: '보너스', desc: '빨갛게 칠해진 5만·5통·5삭이 1장씩 있어요(옵션). 가지고 있으면 1장마다 +1판. 보통 5와 똑같이 쓰여요. 도라처럼 역은 아니에요.' },
    ] },
    { h: '3인 마작 (산마)', p: ['인원 방식 「3인」(또는 3명으로 시작)이면 3인 마작이에요. 패는 108장: 만수패는 1만·9만만 있고 2~8만이 없어요.'], rows: [
      { icon: hanIcon('1판'), name: '북빼기 (북도라)', tag: '1판씩 · 보너스', desc: '내 차례에 북을 「북 빼기」로 옆에 빼 두면 1장마다 도라 1판, 왕패에서 1장 보충해요. 역은 아니에요. 리치 중엔 방금 뽑은 북만 뺄 수 있어요. 빼 둔 북으로 남이 론할 수도 있어요.' },
      { icon: '🚫', name: '치 없음', tag: '3인', desc: '퐁·깡·론만 돼요. 바람패는 동·남·서가 자리 바람이고, 북은 누구의 자리 바람도 아니에요.' },
      { icon: '✨', name: '도라 표시 1만 → 9만', tag: '3인', desc: '만수패는 1만·9만뿐이라 표시 1만이면 도라 9만, 표시 9만이면 도라 1만.' },
      { icon: '🪙', name: '쯔모 점수', tag: '츠모손 없음', desc: '없는 북가 몫을 두 사람이 반씩 더 내서, 쯔모해도 론과 같은 점수를 받아요.' },
    ] },
    { h: '점수', p: ['판이 많을수록 점수가 커져요. 부(符)는 손 모양 보너스(보통 30부).', '자(친이 아닌 사람) 기준 론 점수 예: 1판 30부 1000 · 2판 30부 2000 · 3판 30부 3900 · 4판 30부 7700', '5판 만관 8000 · 6~7판 하네만 12000 · 8~10판 배만 16000 · 11~12판 삼배만 24000 · 13판↑ 역만 32000', '친(동가)은 1.5배! 쯔모는 나머지 세 사람이 나눠 내요.'], rows: [] },
  ]);

  /* 규칙 그림(라운드 33): 몸통 4 + 머리 1 */
  const FIG_TILE = (x, t, col) => '<g transform="translate(' + x + ',22)"><rect width="20" height="28" rx="3" fill="#fffaf0" stroke="#8a7a5a"/><text x="10" y="20" font-size="15" text-anchor="middle" font-weight="700" fill="' + col + '">' + t + '</text></g>';
  const RULE_FIG = (() => {
    const groups = [[['3', '#2a6fb5'], ['4', '#2a6fb5'], ['5', '#2a6fb5']], [['7', '#b8322a'], ['8', '#b8322a'], ['9', '#b8322a']], [['2', '#2b8a5a'], ['2', '#2b8a5a'], ['2', '#2b8a5a']], [['中', '#b8322a'], ['中', '#b8322a'], ['中', '#b8322a']], [['5', '#2a6fb5'], ['5', '#2a6fb5']]];
    let x = 6, out = '';
    const labels = ['몸통', '몸통', '몸통', '몸통', '머리'];
    groups.forEach((g, gi) => { const x0 = x; g.forEach((t) => { out += FIG_TILE(x, t[0], t[1]); x += 21; }); out += '<text x="' + (x0 + (x - x0) / 2) + '" y="16" font-size="11" text-anchor="middle" fill="' + (gi === 4 ? '#e3ae45' : '#d9cfbb') + '">' + labels[gi] + '</text>'; x += 7; });
    return '<svg viewBox="0 0 340 86" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif">' + out + '<text x="170" y="76" font-size="13" text-anchor="middle" fill="#e3ae45" font-weight="700">연속 3장 · 같은 패 3장 = 몸통, 같은 패 2장 = 머리</text></svg>';
  })();
  /* 규칙 화면 움직이는 예시(core demo, 라운드 50): 역 예시 · 리치 */
  const RULE_DEMOS = (() => {
    const COL = { m: '#b8322a', p: '#2a6fb5', s: '#2b8a5a', z: '#333' };
    const TL = (k, x, y, t, su, o) => Object.assign({ k, x, y, w: 22, h: 30, r: 3, fill: '#f6f1e3', stroke: '#8a7f66', lw: 1, text: t, ink: COL[su], size: 13 }, o || {});
    const hand = (tiles, y, o) => tiles.map(([t, su], i) => TL('t' + i, 12 + i * 23, y, t, su, o && o[i]));
    const tx = (x, y, t, c, sz) => ({ shape: 'text', x, y, text: t, ink: c || '#e3ae45', size: sz || 13 });
    const H13 = [['2', 'm'], ['3', 'm'], ['4', 'm'], ['4', 'p'], ['5', 'p'], ['6', 'p'], ['3', 's'], ['4', 's'], ['5', 's'], ['6', 's'], ['7', 's'], ['8', 's'], ['5', 'p']];
    const tanyao = { h: 130, cap: '역 예시: 탕야오 (2~8 숫자패만)', frames: [
      { say: '손패 13장 — 1·9·글자패가 하나도 없어요', items: hand(H13, 20) },
      { say: '5통을 뽑았어요 → 몸통 4개 + 머리(5통 2장)', items: hand(H13.concat([['5', 'p']]), 20).concat([TL('t13', 12 + 13 * 23, 20, '5', 'p', { stroke: '#ffd34d', lw: 3 })]) },
      { say: '쯔모! 「탕야오」 + 「멘젠쯔모」 = 2판', items: hand(H13.concat([['5', 'p']]), 20, H13.concat([0]).map(() => ({ stroke: '#ffd34d', lw: 2 }))).concat([tx(170, 76, '탕야오 1판 + 멘젠쯔모 1판', '#e3ae45', 14)]) },
    ] };
    const H2 = [['1', 'm'], ['2', 'm'], ['3', 'm'], ['4', 'p'], ['5', 'p'], ['6', 'p'], ['7', 's'], ['8', 's'], ['9', 's'], ['中', 'z'], ['中', 'z'], ['6', 'm'], ['7', 'm']];
    const riichi = { h: 140, cap: '리치: 텐파이에서 1000점 걸기', frames: [
      { say: '6·7만이 5만이나 8만을 기다려요 (텐파이)', items: hand(H2, 20).concat([tx(250, 70, '기다림: 5만 · 8만', '#cfc6b0', 12)]) },
      { say: '「리치」! 1000점 막대를 걸어요', items: hand(H2, 20).concat([{ k: 'stick', x: 120, y: 64, w: 100, h: 8, r: 4, fill: '#f4f1ea', stroke: '#888', lw: 1 }, { k: 'dot', shape: 'circle', x: 170, y: 68, w: 6, fill: '#c8352e' }]) },
      { say: '이제 손을 못 바꿔요 — 뽑은 패는 그대로 버림', items: hand(H2, 20).concat([{ k: 'stick', x: 120, y: 64, w: 100, h: 8, r: 4, fill: '#f4f1ea', stroke: '#888', lw: 1 }, { k: 'dot', shape: 'circle', x: 170, y: 68, w: 6, fill: '#c8352e' }, TL('dr', 12 + 13 * 23, 20, '2', 's'), tx(170, 96, '2삭 → 바로 버림', '#cfc6b0', 12)]) },
      { say: '8만이 왔다! 쯔모! 리치 1판 + 멘젠쯔모 1판', items: hand(H2, 20).concat([TL('dr', 12 + 13 * 23, 20, '8', 'm', { stroke: '#ffd34d', lw: 3 }), { k: 'stick', x: 120, y: 64, w: 100, h: 8, r: 4, fill: '#f4f1ea', stroke: '#888', lw: 1 }, { k: 'dot', shape: 'circle', x: 170, y: 68, w: 6, fill: '#c8352e' }, tx(170, 96, '리치 + 멘젠쯔모 = 2판 (+뒷도라 기회)', '#e3ae45', 14)]) },
    ] };
    return { tanyao, riichi };
  })();
  const RULES = [
    { h: '목표', fig: { svg: RULE_FIG, cap: '몸통 4개 + 머리 1개 = 완성(14장)' }, p: ['손패 13장 + 1장 = 14장을 「몸통 4개 + 머리 1개」로 완성하면 화료(승리)! 판이 끝날 때 점수가 가장 높은 사람이 1등이에요.', '몸통 = 연속 숫자 3장(예: 3·4·5통) 또는 같은 패 3장(예: 중중중). 머리 = 같은 패 2장.', '단, 「역」(정해진 모양·조건)이 1개 이상 있어야 완성할 수 있어요. 처음엔 「리치」 「탕야오」 「역패」만 알아도 충분!'] },
    { h: '차례에 할 일', p: ['패를 1장 자동으로 뽑아요 → 1장 버려요. 버릴 패를 탭하면 위로 올라오고, 한 번 더 탭하면 버려요.', '남이 버린 패로 몸통을 만들 수 있으면 「퐁」(같은 패 2장 있을 때) · 「치」(왼쪽 사람 패로 연속 만들기) · 「깡」(같은 패 3장 있을 때)을 할 수 있어요. 하지만 울면(부르면) 리치·멘젠쯔모·핑후 같은 역이 사라져요.', '내 손에 같은 패 4장이 모이면 내 차례에 「깡」 → 보충 패를 뽑아요.'] },
    { h: '화료(완성)', p: ['쯔모: 내가 뽑은 패로 완성. 세 사람이 나눠서 점수를 내요.', '론: 남이 버린 패로 완성. 버린 사람이 혼자 점수를 내요.', '후리텐: 내가 기다리는 패를 내가 예전에 버렸으면 그 패로 론할 수 없어요(쯔모는 돼요). 론을 놓쳐도 내 다음 버림 전까지 론 불가, 리치 중이면 끝까지 불가.'] },
    { h: '리치', demo: [RULE_DEMOS.tanyao, RULE_DEMOS.riichi], p: ['울지 않고 텐파이(1장만 오면 완성)이면 「리치」 버튼 → 버릴 패 선택. 1000점을 걸고, 이후 손을 못 바꾸지만 1판 + 뒷도라 기회!', '리치 후에는 뽑은 패가 자동으로 버려져요(완성되면 쯔모 버튼).', '첫 버림 때(아무도 울기 전) 리치하면 「더블리치」 2판!', '빨간 5(적도라)는 1장마다 +1판. 남이 퐁 한 패에 1장 붙여 깡할 때 그 패로 론하면 「창깡」 1판.'] },
    { h: '점수', p: ['점수 = 판(역 + 도라)과 부(손 모양 보너스)로 자동 계산돼요. 이긴 판에 역 목록과 점수가 크게 나와요.', '예: 리치 + 탕야오 + 도라 1 = 3판 → 론이면 약 3900점(친은 5800점).', '5판 = 만관 8000점, 역만 32000점. 친(동가)은 1.5배. 시작 점수 25000점(3인 35000점).'] },
    { h: '3인 마작', p: ['설정 「인원 방식: 3인」(또는 3명으로 시작)이면 3인 마작(산마). 2~8만을 뺀 108장, 시작 35000점, 동풍전 3국 / 반장전 6국.', '치는 없어요(퐁·깡·론만). 북은 「북 빼기」로 옆에 빼 두면 1장마다 도라 1판 + 보충 패 1장. 그냥 손에 두고 머리·퐁으로 써도 돼요(역패는 아님).', '쯔모하면 두 사람이 나눠 내되 없는 사람 몫까지 반씩 더 내요(츠모손 없음) → 쯔모도 론과 같은 점수. 본장은 200점, 유국 때 노텐 벌점은 합쳐서 3000점.', '1만·9만만 있어서 삼색동순·일기통관(만)·만수 청일색·탕야오 몸통(만)은 못 만들어요. 도라 표시 1만 → 도라 9만.'] },
    { h: '판 진행', p: ['동풍전: 동1국~동4국(친이 4번 바뀜). 반장전: 남4국까지. 친이 이기거나 유국 때 텐파이면 친을 한 번 더(연장, 본장 +1: 점수 +300).', '패가 다 떨어지면 유국: 텐파이(1장 남은) 사람이 노텐 사람에게 합쳐서 3000점을 받아요.', '누군가 점수가 0 아래로 내려가면 바로 끝나요.', '구종구패(옵션): 내 첫 차례에, 아직 아무도 울지 않았고 손에 1·9·글자패가 9종류 이상이면 「구종구패」 버튼으로 이번 판을 무효로 할 수 있어요. 점수 그대로, 같은 친으로 다시 해요.'] },
    { h: '초보 도우미', p: ['텐파이가 되면 아래에 「기다리는 패」와 남은 장 수가 보여요.', '「추천」 표시(초록 테두리)는 버리기 좋은 패예요(설정에서 끌 수 있어요). 패를 들어 올리면 「버리면 텐파이까지 몇 장」인지 알려줘요.', '「부르기」 버튼을 끄면 론만 묻고 퐁·치·깡은 자동으로 넘겨요.'] },
    { h: '간단히 바꾼 규칙', p: ['같은 패로 둘이 동시에 론하면 버린 사람 다음 자리부터 먼저 한 사람만 이겨요. 리치 중에는 깡을 못 해요. 구종구패 말고 다른 도중유국(사풍연타·사깡유국 등)은 없어요.', '적도라(빨간 5 세 장)는 기본으로 들어가요. 설정에서 뺄 수 있어요. 창깡·더블리치·천화·지화는 항상 있어요.', 'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.'] },
    { h: '패 그림', p: ['위쪽 「패 그림」 버튼으로 전통 그림과 모던(큰 숫자 + 색 띠) 그림을 바꿔요. 모던에서 빨간 5는 빨간 숫자·분홍 바탕·오른쪽 위 빨간 표시예요. 이 기기에만 저장돼요.'] },
  ];

  /* ---------- view ---------- */
  function mount(root, api) {
    const cvs = U.canvas(root), ctx = cvs.ctx;
    const onFelt = () => { dirty = true; }; window.addEventListener('lounge-felt', onFelt); const onRC = (e) => { if (sel >= 0 || rmode) { sel = -1; rmode = false; dirty = true; renderBar(); e.preventDefault(); } }; window.addEventListener('lounge-cancel', onRC); window.addEventListener('lounge-cardback', onFelt);  // 오른쪽 클릭 = 선택 해제, 카드 뒷면 바뀜(라운드 34)
    let st = null, sel = -1, rmode = false, dirty = true, bottom = 0, waitSeq = -1, waitUntil = 0;
    let banner = null, popT = 0, sugCache = { id: -1, i: -1 }, hand = [];
    let callsOn = true; try { callsOn = localStorage.getItem('lounge.mj.calls') !== '0'; } catch (e) {}
    const spd = () => (L.debug && L.debug.speed) || 1;
    const ui = L.h('div', { style: { position: 'absolute', inset: '0', pointerEvents: 'none', zIndex: 5 } });
    root.append(ui);
    const bar = L.h('div', { class: 'mj-bar', style: { position: 'absolute', left: '6px', right: '6px', display: 'flex', flexDirection: 'column', gap: '4px', pointerEvents: 'auto' } });
    const hint = L.h('div', { class: 'mj-hint', style: { minHeight: '20px', font: '500 12px ' + BODY, color: '#efe4cf', display: 'flex', alignItems: 'center', gap: '3px', flexWrap: 'nowrap', overflow: 'hidden', whiteSpace: 'nowrap', textShadow: '0 1px 2px #000' } });
    const btns = L.h('div', { class: 'mj-btns', style: { display: 'flex', gap: '6px', height: '46px', justifyContent: 'flex-end' } });
    bar.append(hint, btns); ui.append(bar);
    const callBtn = L.h('button', { class: 'btn sm ghost mj-call', style: { position: 'absolute', left: '4px', top: '4px', minWidth: '58px', minHeight: '44px', padding: '2px 6px', fontSize: '11px', lineHeight: '1.15', pointerEvents: 'auto', whiteSpace: 'pre' }, onclick: () => { callsOn = !callsOn; try { localStorage.setItem('lounge.mj.calls', callsOn ? '1' : '0'); } catch (e) {} api.sfx('click'); setCallTxt(); api.toast(callsOn ? '퐁·치·깡도 물어봐요' : '론만 물어보고 퐁·치·깡은 넘겨요'); } });
    const setCallTxt = () => { callBtn.textContent = '부르기\n' + (callsOn ? '켬' : '끔'); callBtn.style.opacity = callsOn ? '1' : '0.7'; };
    setCallTxt();
    const yakuBtn = L.h('button', { class: 'btn sm ghost mj-yaku', style: { position: 'absolute', right: '4px', top: '4px', minWidth: '50px', minHeight: '44px', padding: '2px 6px', fontSize: '12px', pointerEvents: 'auto' }, onclick: () => { api.sfx('click'); if (L.codex) L.codex('mahjong', root); } }, '역표');
    const skinBtn = L.h('button', { class: 'btn sm ghost mj-skin', style: { position: 'absolute', right: '58px', top: '4px', minWidth: '50px', minHeight: '44px', padding: '2px 6px', fontSize: '11px', lineHeight: '1.15', pointerEvents: 'auto', whiteSpace: 'pre' }, 'aria-label': '패 그림 바꾸기',
      onclick: () => { setSkin(skin === 'modern' ? 'classic' : 'modern'); api.sfx('click'); setSkinTxt(); dirty = true; api.toast(skin === 'modern' ? '모던 패 · 이 기기에 저장' : '전통 패 · 이 기기에 저장'); } });
    const setSkinTxt = () => { skinBtn.textContent = '패 그림\n' + (skin === 'modern' ? '모던' : '전통'); };
    setSkinTxt();
    // 대기패 보기(텐파이 대기·남은 장수, 버릴 패 미리보기) — 이 기기에 저장, 기본 켬
    const WV_KEY = 'lounge.mj.waits';
    let wv = true; try { wv = localStorage.getItem(WV_KEY) !== '0'; } catch (e) {}
    const waitBtn = L.h('button', { class: 'btn sm ghost mj-wv', style: { position: 'absolute', left: '66px', top: '4px', minWidth: '50px', minHeight: '44px', padding: '2px 6px', fontSize: '11px', lineHeight: '1.15', pointerEvents: 'auto', whiteSpace: 'pre' }, 'aria-label': '대기패 보기 켜고 끄기',
      onclick: () => { wv = !wv; try { localStorage.setItem(WV_KEY, wv ? '1' : '0'); } catch (e) {} api.sfx('click'); setWvTxt(); dirty = true; renderBar(); api.toast(wv ? '대기패 보기 켬 · 이 기기에 저장' : '대기패 보기 끔 · 이 기기에 저장'); } });
    const setWvTxt = () => { waitBtn.textContent = '대기패\n' + (wv ? '켬' : '끔'); waitBtn.style.opacity = wv ? '1' : '0.7'; };
    setWvTxt();
    // 손패 정렬: 자동(종류별) / 내 순서(끌어서 바꾸기) — 이 기기에 저장
    const SO_KEY = 'lounge.mj.sort';
    let manual = false; try { manual = localStorage.getItem(SO_KEY) === 'm'; } catch (e) {}
    let myOrd = [], ord = [], drag = null;
    const sortBtn = L.h('button', { class: 'btn sm ghost mj-sort', style: { position: 'absolute', left: '120px', top: '4px', minWidth: '50px', minHeight: '44px', padding: '2px 6px', fontSize: '11px', lineHeight: '1.15', pointerEvents: 'auto', whiteSpace: 'pre' }, 'aria-label': '손패 정렬 방식 바꾸기',
      onclick: () => { manual = !manual; try { localStorage.setItem(SO_KEY, manual ? 'm' : 'a'); } catch (e) {} if (manual && st) myOrd = st.h[me()].split(''); api.sfx('click'); setSortTxt(); calcOrd(); dirty = true; api.toast(manual ? '내 순서 · 패를 옆으로 끌어서 옮겨요 · 이 기기에 저장' : '종류별 자동 정렬 · 이 기기에 저장'); } });
    const setSortTxt = () => { sortBtn.textContent = '정렬'+String.fromCharCode(10)+(manual ? '내 순서' : '자동'); };
    setSortTxt();
    function calcOrd() {   // ord[화면 자리] = 상태 손패 index
      const h = st ? st.h[me()] : '';
      if (!manual) { ord = h.split('').map((_, i) => i); myOrd = h.split(''); return; }
      const pool = h.split(''), disp = [];
      for (const ch of myOrd) { const j = pool.indexOf(ch); if (j >= 0) { disp.push(ch); pool.splice(j, 1); } }
      myOrd = disp.concat(pool);
      const used = {};
      ord = myOrd.map((ch) => { let j = -1; do { j = h.indexOf(ch, j + 1); } while (used[j]); used[j] = 1; return j; });
    }
    ui.append(callBtn, waitBtn, sortBtn, yakuBtn, skinBtn);
    let sheet = null, sheetId = -1;

    const me = () => bottom;
    const NV = () => NN(st);
    const slotOf = (rel) => (NV() === 3 && rel === 2 ? 3 : rel);   // 상대 위치 → 화면 자리(0 아래 1 오른쪽 2 위 3 왼쪽). 3인은 맞은편을 비워요
    const relOf = (seat) => (seat - me() + NV()) % NV();
    function viewSeat() { const v = api.viewer(); if (v >= 0) bottom = v; else if (st && st.hu.length && !api.online) { /* keep */ } return v; }
    const showAll = () => st && (st.ph === 'r' || st.ph === 'e' || !st.hu.length);
    function send(a, seat) {
      if (performance.now() < waitUntil && waitSeq === st.seq) return;
      waitSeq = st.seq; waitUntil = performance.now() + (api.online ? 3000 : 300);
      if (seat != null && api.actAs) api.actAs(seat, a); else api.act(a);
    }
    const myTurn = () => st && st.ph === 'd' && st.t === me() && api.canAct(me()) && api.viewer() === me();
    const myClaim = () => st && st.ph === 'c' && st.cl.q[0][0] === me() && api.canAct(me()) && api.viewer() === me();

    function layout() {
      const W = cvs.w, H = cvs.h;
      const h = st ? st.h[me()] : '';
      const ms = st ? meldsOf(st, me()) : [];
      const ndM = st && st.nd ? st.nd[me()] : 0;
      const n = Math.max(1, h.length);
      let tw = 36, mw, total;
      const drawnGap = h.length % 3 === 2 ? 8 : 0;
      for (; tw > 18; tw--) {
        mw = Math.round(tw * 0.7);
        const mh = Math.round(mw * 1.36);
        total = n * tw + drawnGap + ms.reduce((a, m) => a + (m.t === 'c' || m.t === 'p' ? 2 * mw + mh : m.t === 'a' ? 4 * mw : 3 * mw + mh) + 4, 0) + (ms.length ? 6 : 0) + (ndM ? ndM * mw + 6 : 0);
        if (total <= W - 12) break;
      }
      const th = Math.round(tw * 1.36);
      const handY = H - th - 8;
      const barH = 72;
      const barBottom = H - handY + 10;
      const tableH = H - barBottom - barH;
      const S = Math.min(W, tableH);
      return { W, H, tw, th, mw, mh: Math.round(mw * 1.36), handY, x0: Math.round((W - total) / 2), drawnGap, barBottom, S, cx: W / 2, cy: Math.max(S / 2, tableH - S / 2 - 2) };
    }
    let LY = null;

    function drawT(k, x, y, w, h, o) {
      o = o || {};
      const img = tileCanvas(o.back ? -1 : k, w, h, cvs.dpr);
      ctx.save();
      if (o.alpha != null) ctx.globalAlpha = o.alpha;
      if (o.rot) { ctx.translate(x + h / 2, y + w / 2); ctx.rotate(-Math.PI / 2); ctx.drawImage(img, -w / 2, -h / 2, w, h); }
      else { ctx.shadowColor = 'rgba(0,0,0,.35)'; ctx.shadowBlur = o.shadow || 0; ctx.shadowOffsetY = o.shadow ? 1.5 : 0; ctx.drawImage(img, x, y, w, h); }
      ctx.restore();
    }
    function render() {
      dirty = false;
      if (!st) return;
      const ly = LY = layout();
      const { W, H, S, cx, cy } = ly;
      ctx.clearRect(0, 0, W, H);
      const g = ctx.createRadialGradient(cx, cy, S * 0.1, cx, cy, Math.max(W, H) * 0.75);
      const FT = (L.ui && L.ui.felt) ? L.ui.felt() : { c: ['#24806a', '#1c6650', '#0c3528'], rail: ['#7a4a24', '#3f230f'], line: 'rgba(227,174,69,.45)' };
      g.addColorStop(0, FT.c[0]); g.addColorStop(0.6, FT.c[1]); g.addColorStop(1, FT.c[2]);
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = 'rgba(227,174,69,.25)'; ctx.lineWidth = 1.5; rr(ctx, cx - S / 2 + 3, cy - S / 2 + 3, S - 6, S - 6, 14); ctx.stroke();
      const cb = Math.round(S * 0.15);
      const pw = Math.max(12, Math.floor(S * 0.046)), ph = Math.round(pw * 1.36);
      const N = NV();
      for (let r = 0; r < N; r++) {
        const seat = (me() + r) % N;
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(-slotOf(r) * Math.PI / 2);
        drawPond(seat, cb, pw, ph);
        if (r > 0) drawStrip(seat, S);
        ctx.restore();
      }
      drawCenter(cx, cy, cb);
      for (let r = 0; r < N; r++) { ctx.save(); ctx.translate(cx, cy); ctx.rotate(-slotOf(r) * Math.PI / 2); drawLabel((me() + r) % N, cb); ctx.restore(); }
      drawHand(ly);
      if (banner) {
        const t = (performance.now() - banner.t0) * spd() / 1000;
        if (t > 1.1) banner = null;
        else {
          const r = slotOf(relOf(banner.s)), ang = -r * Math.PI / 2;
          const bx = cx - Math.sin(ang) * S * 0.3 * (r ? 1 : 1), by = cy + Math.cos(ang) * S * 0.3;
          const sc = 1 + 0.4 * Math.max(0, 0.25 - t) * 4;
          ctx.save(); ctx.translate(bx, by); ctx.scale(sc, sc); ctx.globalAlpha = Math.min(1, (1.1 - t) * 4);
          ctx.font = '30px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(20,12,24,.85)'; ctx.strokeText(banner.txt, 0, 0);
          ctx.fillStyle = banner.col || '#ffd36a'; ctx.fillText(banner.txt, 0, 0);
          ctx.restore();
          dirty = true;
        }
      }
      if (performance.now() < popT) dirty = true;
    }
    function drawPond(seat, cb, pw, ph) {
      const p = st.p[seat];
      let i = 0, x = -3 * pw, y = cb + 6, col = 0, row = 0;
      const lastIdx = st.last && st.last.k === 'x' && st.last.s === seat && st.ph === 'c' ? p.replace(/[*~]/g, '').length - 1 : -1;
      for (let j = 0; j < p.length; j++) {
        const ch = p[j]; if (ch === '*' || ch === '~') continue;
        const rch = p[j + 1] === '*' || p[j + 2] === '*' && p[j + 1] === '~';
        const taken = p[j + 1] === '~' || p[j + 2] === '~';
        const k = kv(ch);
        const w = rch ? ph : pw;
        let yy = y + row * ph;
        if (i === lastIdx) {
          const pt = Math.max(0, popT - performance.now()) / 220;
          ctx.save(); ctx.shadowColor = '#ffd36a'; ctx.shadowBlur = 8;
          ctx.fillStyle = '#ffd36a'; rr(ctx, x - 1.5, yy - 1.5 - pt * 6, w + 3, (rch ? pw : ph) + 3, 4); ctx.fill(); ctx.restore();
          yy -= pt * 6;
        }
        drawT(k, x, yy + (rch ? (ph - pw) : 0), pw, ph, { rot: rch, alpha: taken ? 0.35 : 1 });
        x += w; col++; i++;
        if (col >= 6 && row < 3) { col = 0; row++; x = -3 * pw; }
      }
    }
    function drawStrip(seat, S) {
      const h = st.h[seat], ms = meldsOf(st, seat), n = h.length;
      const faceUp = showAll() || (api.viewer() === seat);
      const nd = st.nd ? st.nd[seat] : 0;
      let units = n + ms.reduce((a, m) => a + (m.t === 'a' ? 4 : m.t === 'c' || m.t === 'p' ? 3.4 : 4.4), 0) + (ms.length ? 0.6 : 0) + ms.length * 0.3 + (nd ? nd + 0.6 : 0);
      const bw = Math.min(S * 0.04, (S - 56) / units), bh = Math.round(bw * 1.36);
      let x = -units * bw / 2;
      const y = S / 2 - bh - 6;
      for (let i = 0; i < n; i++) { drawT(kv(h[i]), x, y, bw, bh, { back: !faceUp }); x += bw; }
      if (ms.length) x += bw * 0.6;
      for (const m of ms) { x = drawMeld(m, seat, x, y, bw, bh); x += bw * 0.3; }
      if (nd) { x += bw * 0.6; for (let i = 0; i < nd; i++) { drawT(NORTH, x, y, bw, bh); x += bw; } }
      // name tag
      const p = api.players[seat] || { name: '', color: '#888' };
      ctx.font = '600 10px ' + BODY; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const nm = p.name + (st.ri[seat] ? (st.ri[seat] === 2 ? ' · 더블리치' : ' · 리치') : ''), tw = ctx.measureText(nm).width + 16;
      ctx.fillStyle = 'rgba(14,10,20,.7)'; rr(ctx, -tw / 2, y - 16, tw, 14, 7); ctx.fill();
      ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(-tw / 2 + 7, y - 9, 3, 0, 7); ctx.fill();
      ctx.fillStyle = st.ri[seat] ? '#ffd36a' : '#efe4cf'; ctx.fillText(nm, 4, y - 9);
    }
    function drawMeld(m, seat, x, y, w, h) {
      const tiles = meldTiles(m);
      const N = NV(), rel = m.f >= 0 ? slotOf((m.f - seat + N) % N) : -1; // 1 right(하가) 2 across 3 left(상가)
      const side = rel === 3 ? 0 : rel === 2 ? 1 : rel === 1 ? tiles.length - 1 : -1;
      let order = tiles;
      if (m.t === 'c') { order = tiles.slice(); order.splice(order.indexOf(m.c), 1); order.unshift(m.c); }
      let rd = m.rd || 0;
      for (let i = 0; i < order.length; i++) {
        let k = order[i];
        if (rd && (k === 4 || k === 13 || k === 22) && !(m.t === 'a' && (i === 0 || i === 3))) { k = 34 + [4, 13, 22].indexOf(k); rd--; }
        if (i === side) { drawT(k, x, y + h - w, w, h, { rot: true }); x += h; }
        else { drawT(k, x, y, w, h, { back: m.t === 'a' && (i === 0 || i === 3) }); x += w; }
      }
      return x;
    }
    function drawLabel(seat, cb) {
      const wind = (seat - st.dl + NV()) % NV();
      const turn = (st.ph === 'd' && st.t === seat) || (st.ph === 'c' && st.cl.f === seat);
      if (turn) { ctx.fillStyle = '#ffd36a'; ctx.shadowColor = '#ffd36a'; ctx.shadowBlur = 10; rr(ctx, -cb * 0.6, cb - 4, cb * 1.2, 3, 1.5); ctx.fill(); ctx.shadowBlur = 0; }
      ctx.font = '700 11px ' + MONO; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = wind === 0 ? '#ff8f6b' : '#efe4cf';
      ctx.fillText(WN[wind] + ' ' + st.sc[seat], 0, cb - 15);
      if (st.ri[seat]) { ctx.fillStyle = '#f6efdc'; rr(ctx, -cb * 0.45, cb - 8, cb * 0.9, 3, 1.5); ctx.fill(); ctx.fillStyle = RED; ctx.beginPath(); ctx.arc(0, cb - 6.5, 1.6, 0, 7); ctx.fill(); }
    }
    function drawCenter(cx, cy, cb) {
      ctx.save(); ctx.translate(cx, cy);
      ctx.fillStyle = 'rgba(22,16,30,.88)'; rr(ctx, -cb, -cb, cb * 2, cb * 2, 10); ctx.fill();
      ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; rr(ctx, -cb, -cb, cb * 2, cb * 2, 10); ctx.stroke();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = '#e3ae45'; ctx.font = Math.round(cb * 0.27) + 'px ' + FONT;
      const rd = Math.min(st.rd, st.o.e - 1);
      ctx.fillText((NV() === 3 ? '3인 ' : '') + WN[(rd / NV()) | 0] + ' ' + (rd % NV() + 1) + '국', 0, -cb * 0.36);
      const n = st.kn + 1, dw = Math.round(cb * 0.2), dh = Math.round(dw * 1.36);
      let x = -2.5 * dw;
      for (let i = 0; i < 5; i++) { drawT(i < n ? ki(st.dw[4 + i]) : -1, x, -dh / 2 + cb * 0.04, dw, dh, { back: i >= n }); x += dw; }
      ctx.fillStyle = '#cbbfd6'; ctx.font = '600 ' + Math.max(9, Math.round(cb * 0.17)) + 'px ' + BODY;
      ctx.fillText('패 ' + st.w.length + ' · ' + st.hb + '본장' + (st.ky ? ' · 봉' + st.ky : ''), 0, cb * 0.32);
      ctx.restore();
    }
    function drawHand(ly) {
      const s = me(), h = st.h[s];
      const ms = meldsOf(st, s);
      const faceUp = showAll() || api.viewer() === s;
      const mine = myTurn();
      const rset = rmode && mine ? riichiIdx(st, s) : null;
      const sug = mine && st.o.hp && !rmode ? sugIdx() : -1;
      const tp = mine && faceUp && wv && !st.ri[s] && h.length % 3 === 2 ? tenpaiDiscards() : null;
      hand = [];
      let x = ly.x0;
      if (ord.length !== h.length) calcOrd();
      for (let p = 0; p < h.length; p++) {
        const i = ord[p];
        if (drag && drag.on && drag.p === p) { x += ly.tw; continue; }
        if (p === h.length - 1 && ly.drawnGap && st.dr && st.t === s && st.ph === 'd') x += ly.drawnGap;
        const lift = i === sel && mine ? 10 : 0;
        const dim = rset && !rset.includes(i);
        const y = ly.handY - lift;
        if (faceUp && i === sug && i !== sel) { ctx.save(); ctx.shadowColor = '#5fe08a'; ctx.shadowBlur = 8; ctx.fillStyle = '#5fe08a'; rr(ctx, x - 1.5, y - 1.5, ly.tw + 1, ly.th + 3, 5); ctx.fill(); ctx.restore(); }
        if (i === sel && mine) { ctx.save(); ctx.fillStyle = '#ffd36a'; rr(ctx, x - 1.5, y - 1.5, ly.tw + 1, ly.th + 3, 5); ctx.fill(); ctx.restore(); }
        drawT(kv(h[i]), x + 0.5, y, ly.tw - 1, ly.th, { back: !faceUp, alpha: dim ? 0.35 : 1, shadow: 3 });
        if (tp && tp[i] != null && !dim) {   // 이 패를 버리면 텐파이: 위에 대기패 남은 장수
          const n = tp[i], bw = Math.max(14, ly.tw - 4), bx = x + (ly.tw - bw) / 2, by = y - 13;
          ctx.save(); ctx.fillStyle = n ? '#2fae63' : '#7a6a6a'; rr(ctx, bx, by, bw, 12, 6); ctx.fill();
          ctx.fillStyle = '#fff'; ctx.font = '700 9.5px ' + BODY; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(n), bx + bw / 2, by + 6.5); ctx.restore();
        }
        hand.push({ x, y: ly.handY - 14, w: ly.tw, h: ly.th + 22, i, p });
        x += ly.tw;
      }
      if (drag && drag.on) { const k = kv(h[ord[drag.p]]); ctx.save(); ctx.fillStyle = '#ffd36a'; rr(ctx, drag.x - ly.tw / 2 - 1.5, ly.handY - 19.5, ly.tw + 1, ly.th + 3, 5); ctx.fill(); ctx.restore(); drawT(k, drag.x - ly.tw / 2 + 0.5, ly.handY - 18, ly.tw - 1, ly.th, { shadow: 8 }); }
      if (ms.length) x += 6;
      const my = ly.handY + ly.th - ly.mh;
      for (const m of ms) { x = drawMeld(m, s, x, my, ly.mw, ly.mh) + 4; }
      const nd = st.nd ? st.nd[s] : 0;
      if (nd) { x += ms.length ? 2 : 6; for (let i = 0; i < nd; i++) { drawT(NORTH, x, my, ly.mw, ly.mh); x += ly.mw; } }
    }
    let tpCache = { id: -1, m: null };
    function tenpaiDiscards() {   // 손패 index → 그 패를 버렸을 때 대기패 남은 장수 합 (텐파이가 아니면 없음)
      if (tpCache.id === st.seq) return tpCache.m;
      const s = me(), h = st.h[s], nm = st.m[s].length, v = visibleOf(st, s), m = {}, done = {};
      for (let i = 0; i < h.length; i++) {
        const k = ki(h[i]);
        if (done[k] !== undefined) { if (done[k] != null) m[i] = done[k]; continue; }
        const w = waitsOf(cnt(h.slice(0, i) + h.slice(i + 1)), nm);
        done[k] = w.length ? w.reduce((a, q) => a + Math.max(0, 4 - v[q]), 0) : null;
        if (done[k] != null) m[i] = done[k];
      }
      tpCache = { id: st.seq, m };
      return m;
    }
    function sugIdx() {
      if (sugCache.id !== st.seq) { sugCache = { id: st.seq, i: -1 }; try { sugCache.i = suggest(st, me()); } catch (e) {} }
      return sugCache.i;
    }

    function img(k, w, h) { return L.h('img', { src: tileURL(k, w || 15, h || 20), style: { width: (w || 15) + 'px', height: (h || 20) + 'px', verticalAlign: 'middle', flex: '0 0 auto' } }); }
    function B(label, cls, fn, extra) {
      const b = L.h('button', { class: 'btn ' + (cls || ''), style: Object.assign({ minHeight: '44px', minWidth: '52px', padding: '0 10px', fontSize: '15px', flex: '0 1 auto', display: 'flex', alignItems: 'center', gap: '2px', justifyContent: 'center' }, extra || {}), onclick: (e) => { e.stopPropagation(); fn(); } });
      if (typeof label === 'string') b.textContent = label; else label.forEach((x) => b.append(x));
      const ka = { '쯔모!': 'win', '론!': 'win', '버리기': 'discard', '리치': 'riichi', '더블리치': 'riichi', '퐁': 'pon', '깡': 'kan', '치': 'chi', '패스': 'pass', '취소': 'pass', '구종구패': 'q9', '북 빼기': 'nuki' }[String(typeof label === 'string' ? label : label[0]).trim()];
      if (ka) b.setAttribute('data-action', ka);
      return b;
    }
    function remainOf(k) { const v = visibleOf(st, me()); return Math.max(0, 4 - v[k]); }
    function waitsLine(c, nm, pre) {
      const w = waitsOf(c, nm);
      if (!w.length) return false;
      hint.append(pre || '대기:');
      let rem = 0; w.forEach((k) => { const r = remainOf(k); hint.append(img(k)); hint.append(L.h('span', { style: { fontSize: '10px', color: r ? '#9fe8b8' : '#887', marginRight: '2px' } }, '×' + r)); rem += r; });
      hint.append(' 남은 ' + rem + '장' + (furiten(st, me(), w) ? ' · 후리텐!' : ''));
      return true;
    }
    function renderBar() {
      hint.innerHTML = ''; btns.innerHTML = '';
      if (!st || !LY) return;
      bar.style.bottom = LY.barBottom + 'px';
      if (st.ph === 'r' || st.ph === 'e') return;
      const s = me(), h = st.h[s], nm = st.m[s].length;
      const ok = api.viewer() === s && api.mySeats().includes(s);
      if (!ok) {
        const v = st.ph === 'd' ? st.t : st.cl.q[0][0];
        hint.append(st.hu.length ? '' : '관전 중 — AI끼리 대국해요');
        if (st.hu.length && api.players[v]) hint.append((api.players[v].name) + (api.players[v].ai ? ' 생각 중…' : ' 차례'));
        return;
      }
      if (myTurn()) {
        const tz = canTsumo(st, s);
        if (tz) btns.append(B('쯔모!', 'primary', () => { api.buzz(30); send({ t: 'z' }); }, { fontSize: '17px', flex: '1 1 0' }));
        if (st.ri[s]) { hint.append(tz ? '완성! 「쯔모」를 누르세요' : nukiOK(st, s) ? '북을 자동으로 빼요' : '리치 중 — 뽑은 패를 자동으로 버려요'); return; }
        if (nukiOK(st, s)) btns.append(B(['북 빼기 ', img(NORTH, 18, 24)], '', () => { api.sfx('pop'); send({ t: 'b' }); }));
        if (rmode) {
          hint.append('리치! 버릴 패를 고르세요(밝은 패만 가능)');
          btns.append(B('취소', 'ghost', () => { rmode = false; sel = -1; api.sfx('click'); dirty = true; renderBar(); }));
          return;
        }
        for (const k of kanOpts(st, s)) btns.append(B(['깡 ', img(k, 18, 24)], '', () => { api.sfx('thud'); send({ t: 'k', k }); }));
        if (q9OK(st, s)) btns.append(B('구종구패', '', () => { api.sfx('thud'); send({ t: 'q' }); }));
        if (riichiOK(st, s) && riichiIdx(st, s).length) btns.append(B(st.nc && !st.p[s] ? '더블리치' : '리치', 'danger', () => { rmode = true; sel = -1; api.sfx('whoosh'); api.buzz(15); dirty = true; renderBar(); }));
        if (sel >= 0 && sel < h.length) {
          btns.append(B('버리기', 'primary', () => doDiscard(sel)));
          const c = cnt(h.slice(0, sel) + h.slice(sel + 1));
          if (!wv) hint.append(img(kv(h[sel])), ' 선택됨 · 한 번 더 탭하면 버려요');
          else if (!waitsLine(c, nm)) {
            const sh = shanten(c, nm);
            hint.append(img(kv(h[sel])), ' 버리면 → 텐파이까지 ' + sh + '장');
          } else hint.prepend(img(kv(h[sel])), ' 버리면 텐파이! ');
        } else {
          const tpm = wv ? tenpaiDiscards() : null;
          hint.append(tz ? '완성! 쯔모 또는 다른 패 버리기' : tpm && Object.keys(tpm).length ? '패 위 숫자 = 버리면 텐파이 · 기다리는 패 남은 장수' : '버릴 패를 탭 → 한 번 더 탭하면 버려요' + (st.o.hp ? ' (초록 = 추천)' : ''));
        }
        return;
      }
      if (myClaim()) {
        const e = st.cl.q[0], mask = e[1], k = st.cl.k;
        hint.append(img(k), ' ' + tname(k) + (st.cl.nk ? '(북빼기)' : '') + ' — ' + (mask & 1 ? '론 할 수 있어요!' : '부를까요?'));
        if (mask & 1) btns.append(B('론!', 'primary', () => { api.buzz(30); send({ t: 'r' }); }, { fontSize: '17px', flex: '1 1 0' }));
        if (mask & 2) btns.append(B('퐁', '', () => { api.sfx('pop'); send({ t: 'n' }); }));
        if (mask & 4) btns.append(B('깡', '', () => { api.sfx('thud'); send({ t: 'm' }); }));
        if (mask & 8) for (const a of chiOpts(cnt(h), k)) btns.append(B(['치', img(a, 13, 18), img(a + 1, 13, 18), img(a + 2, 13, 18)], '', () => { api.sfx('pop'); send({ t: 'c', a }); }, { padding: '0 6px' }));
        btns.append(B('패스', 'ghost', () => { api.sfx('click'); send({ t: 'p' }); }));
        return;
      }
      const c = cnt(h);
      if (h.length % 3 === 1 && (!wv || !waitsLine(c, nm))) {
        const sh = shanten(c, nm);
        hint.append('텐파이까지 ' + sh + '장 · ' + (api.players[st.ph === 'd' ? st.t : st.cl.f] || {}).name + ' 차례');
      }
    }
    function doDiscard(i) {
      api.sfx('card'); api.buzz(12);
      const r = rmode ? 1 : 0;
      rmode = false; sel = -1;
      send(r ? { t: 'x', i, r: 1 } : { t: 'x', i });
    }

    function onDown(ev) {
      if (!st) return;
      const p = cvs.local(ev);
      const t = hand.find((r) => p.x >= r.x && p.x < r.x + r.w && p.y >= r.y && p.y < r.y + r.h);
      if (manual && t && api.viewer() === me() && !showAll()) {   // 내 순서: 끌면 옮기기, 그냥 떼면 탭
        drag = { p: t.p, x0: p.x, x: p.x, on: false, t };
        try { cvs.cv.setPointerCapture(ev.pointerId); } catch (e) {}
        return;
      }
      tapAt(t);
    }
    function onMove(ev) {
      if (!drag) return;
      const p = cvs.local(ev); drag.x = p.x;
      if (!drag.on && Math.abs(p.x - drag.x0) > 10) { drag.on = true; if (sel >= 0) { sel = -1; renderBar(); } }
      if (drag.on) dirty = true;
    }
    function onUp() {
      if (!drag) return;
      const d = drag; drag = null;
      if (!d.on) { tapAt(d.t); return; }
      const n = myOrd.length, tw = LY ? LY.tw : 30;
      let to = Math.round((d.x - (LY ? LY.x0 : 0) - tw / 2) / tw);
      to = Math.max(0, Math.min(n - 1, to));
      if (to !== d.p) { const [c] = myOrd.splice(d.p, 1); myOrd.splice(to, 0, c); calcOrd(); api.sfx('tick'); }
      dirty = true;
    }
    function tapAt(t) {
      if (!st || !myTurn() || st.ri[me()]) return;
      if (!t) { if (sel >= 0) { sel = -1; dirty = true; renderBar(); } return; }
      if (rmode && !riichiIdx(st, me()).includes(t.i)) { api.sfx('click'); api.toast('이 패를 버리면 텐파이가 아니에요'); return; }
      if (sel === t.i) { doDiscard(t.i); return; }
      sel = t.i; api.sfx('tick'); api.buzz(6); dirty = true; renderBar();
    }
    cvs.cv.addEventListener('pointerdown', onDown);
    cvs.cv.addEventListener('pointermove', onMove);
    cvs.cv.addEventListener('pointerup', onUp);
    cvs.cv.addEventListener('pointercancel', onUp);

    function showSheet() {
      if (!st || !st.rr || (st.ph !== 'r')) { if (sheet) { sheet.remove(); sheet = null; } return; }
      if (sheet && sheetId === st.seq) return;
      if (sheet) sheet.remove();
      sheetId = st.seq;
      const R = st.rr, P = api.players;
      const nmOf = (i) => (P[i] ? P[i].name : '자리 ' + (i + 1));
      const card = L.h('div', { class: 'panel', style: { width: '100%', maxWidth: '420px', maxHeight: '86%', overflowY: 'auto', padding: '14px 14px 12px', display: 'flex', flexDirection: 'column', gap: '8px', background: 'rgba(30,22,40,.97)', border: '1px solid rgba(227,174,69,.5)', borderRadius: '16px' } });
      if (R.k === 'q') {
        card.append(L.h('div', { style: { font: '24px ' + FONT, color: '#e3ae45', textAlign: 'center' } }, '도중유국 · 구종구패'));
        card.append(L.h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '13px' } }, nmOf(R.w) + '의 첫 패에 1·9·글자패가 9종류 이상이라 이번 판을 무효로 했어요. 점수는 그대로, 같은 친으로 다시 해요.'));
        const row = L.h('div', { style: { display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '1px' } });
        for (let i = 0; i < R.h.length; i++) row.append(img(kv(R.h[i]), 20, 27));
        card.append(row);
      } else if (R.k === 'd') {
        card.append(L.h('div', { style: { font: '24px ' + FONT, color: '#e3ae45', textAlign: 'center' } }, '유국'));
        card.append(L.h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '13px' } }, '패가 다 떨어졌어요. 텐파이(1장 남은) 사람이 노텐 사람에게 점수를 받아요.'));
        const t = SEATS(st).filter((i) => R.tp[i]).map(nmOf);
        card.append(L.h('div', { style: { textAlign: 'center', fontSize: '14px' } }, t.length ? '텐파이: ' + t.join(', ') : '모두 노텐'));
      } else {
        const ttl = (R.k === 't' ? '쯔모! ' : '론! ') + nmOf(R.w);
        card.append(L.h('div', { style: { font: '24px ' + FONT, color: '#ffd36a', textAlign: 'center' } }, ttl));
        if (R.k === 'r') card.append(L.h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '12px' } }, nmOf(R.f) + '의 버림패로 완성'));
        const row = L.h('div', { style: { display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '1px', alignItems: 'flex-end' } });
        const tw = 20, th2 = 27;
        for (let i = 0; i < R.h.length; i++) { const im = img(kv(R.h[i]), tw, th2); if (i === R.h.length - 1) { im.style.marginLeft = '6px'; im.style.outline = '2px solid #ffd36a'; im.style.borderRadius = '3px'; } row.append(im); }
        R.m.forEach((ms) => { const m = pmeld(ms); const g = L.h('span', { style: { marginLeft: '6px', display: 'inline-flex' } }); meldTiles(m).forEach((k) => g.append(img(k, 16, 22))); row.append(g); });
        card.append(row);
        const dl = L.h('div', { style: { display: 'flex', justifyContent: 'center', gap: '6px', alignItems: 'center', fontSize: '12px', color: '#cbbfd6' } }, '도라 표시');
        R.di.split('').forEach((ch) => dl.append(img(kv(ch), 14, 19)));
        if (R.ui) { dl.append(' 뒷도라 표시'); R.ui.split('').forEach((ch) => dl.append(img(kv(ch), 14, 19))); }
        card.append(dl);
        const list = L.h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px', background: 'rgba(0,0,0,.25)', borderRadius: '10px', padding: '8px 12px' } });
        R.y.forEach((y) => list.append(L.h('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '15px' } }, L.h('span', {}, y[0]), L.h('span', { class: 'mono', style: { color: '#e3ae45' } }, R.ym ? '역만' : y[1] + '판'))));
        card.append(list);
        const got = (R.d && R.d[R.w]) || 0;
        const sum = R.ym ? R.lim + '!' : R.han + '판 ' + R.fu + '부' + (R.lim ? ' · ' + R.lim : '');
        card.append(L.h('div', { style: { textAlign: 'center', font: '20px ' + FONT, color: '#fff' } }, sum + ' → +' + got + '점'));
        card.append(L.h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '11px' } }, R.ym ? '역만은 최고 점수예요!' : '판(역+도라)이 많을수록 커지고, 부는 손 모양 보너스예요. 친(동)은 1.5배.'));
      }
      const tbl = L.h('div', { style: { display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '2px 10px', fontSize: '13px' } });
      SEATS(st).forEach((i) => {
        const d = (R.d && R.d[i]) || 0;
        tbl.append(L.h('span', {}, L.h('span', { class: 'dot', style: { '--c': P[i] ? P[i].color : '#888' } }), ' ' + WN[(i - st.dl + NV()) % NV()] + ' ' + nmOf(i)),
          L.h('span', { class: 'mono' }, String(st.sc[i])),
          L.h('span', { class: 'mono', style: { color: d > 0 ? '#7fe0a0' : d < 0 ? '#ff8f7b' : '#999', minWidth: '58px', textAlign: 'right' } }, d > 0 ? '+' + d : d < 0 ? String(d) : '±0'));
      });
      card.append(tbl);
      const hs = api.mySeats();
      if (hs.length) card.append(L.h('button', { class: 'btn primary', 'data-action': 'next', style: { minHeight: '50px', fontSize: '16px' }, onclick: () => { api.sfx('click'); send({ t: 'n' }, hs[0]); } }, st.over ? '최종 결과 보기' : '다음 판'));
      else card.append(L.h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '12px' } }, st.over ? '곧 최종 결과가 나와요' : '곧 다음 판이 시작돼요'));
      sheet = L.h('div', { class: 'mj-sheet', style: { position: 'absolute', inset: '0', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '10px', background: 'rgba(10,8,15,.5)', pointerEvents: 'auto', zIndex: 8 } }, card);
      ui.append(sheet);
    }

    let autoT = null;
    function auto() {
      clearTimeout(autoT);
      if (!st) return;
      if (myTurn() && st.ri[me()] && !canTsumo(st, me())) {
        const seq = st.seq; autoT = setTimeout(() => { if (st && st.seq === seq && myTurn()) send(nukiOK(st, me()) ? { t: 'b' } : { t: 'x', i: st.h[me()].length - 1 }); }, 650 / spd());
      } else if (myClaim() && !callsOn && !(st.cl.q[0][1] & 1)) {
        const seq = st.seq; autoT = setTimeout(() => { if (st && st.seq === seq && myClaim()) send({ t: 'p' }); }, 120);
      }
    }

    function onEvent(next, prev) {
      const l = next.last;
      if (!l || (prev && prev.last && prev.last.id === l.id)) return;
      const mineS = l.s != null && api.canAct(l.s);
      if (l.k === 'x') { api.sfx(l.r ? 'whoosh' : 'card'); popT = performance.now() + 220 / spd(); if (l.r) { banner = { t0: performance.now(), s: l.s, txt: '리치!', col: '#ff8f6b' }; api.buzz(20); } }
      else if (l.k === 'n') { banner = { t0: performance.now(), s: l.s, txt: '퐁!' }; api.sfx('pop'); }
      else if (l.k === 'c') { banner = { t0: performance.now(), s: l.s, txt: '치!' }; api.sfx('pop'); }
      else if (l.k === 'k') { banner = { t0: performance.now(), s: l.s, txt: '깡!' }; api.sfx('thud'); }
      else if (l.k === 'z' || l.k === 'o') { banner = { t0: performance.now(), s: l.s, txt: l.k === 'z' ? '쯔모!' : '론!', col: '#ffd36a' }; api.sfx(mineS || !api.mySeats().length ? 'win' : 'lose'); api.buzz(40); }
      else if (l.k === 'd') api.sfx('thud');
      else if (l.k === 'b') { banner = { t0: performance.now(), s: l.s, txt: '북!' }; api.sfx('pop'); }
      else if (l.k === 'q') { banner = { t0: performance.now(), s: l.s, txt: '구종구패' }; api.sfx('thud'); }
      else if (l.k === 'deal') { api.sfx('whoosh'); sel = -1; rmode = false; }
    }

    const stop = U.loop(() => { if (dirty) { render(); } });
    cvs.onresize = () => { dirty = true; render(); renderBar(); };

    const offKeys = api.input ? api.input.on((t, id) => {
      if (t !== 'down') return;
      const b = [...document.querySelectorAll('[data-action="' + id + '"]')].find((x) => !x.disabled && x.getClientRects().length);
      if (b) b.click();
    }) : null;
    const noFocus = (e) => { const b = e.target && e.target.closest && e.target.closest('button[data-action]'); if (b) e.preventDefault(); };   // 마우스로 누른 버튼에 포커스가 남아 Space/Enter 단축키를 가로채지 않게
    document.addEventListener('mousedown', noFocus, true);
    return {
      update(next, prev) {
        st = next;
        viewSeat();
        if (!st.hu.length) bottom = 0;
        if (prev !== next) onEvent(next, prev);
        if (!myTurn()) { sel = -1; rmode = false; }
        else if (sel >= st.h[me()].length) sel = -1;
        if (next.last && next.last.k === 'deal' && (!prev || !prev.last || prev.last.id !== next.last.id)) myOrd = next.h[me()].split('');
        calcOrd();
        waitUntil = 0;
        dirty = true; render(); renderBar(); showSheet(); auto();
      },
      destroy() { if (offKeys) offKeys(); document.removeEventListener('mousedown', noFocus, true); window.removeEventListener('lounge-felt', onFelt); window.removeEventListener('lounge-cancel', onRC); window.removeEventListener('lounge-cardback', onFelt); stop(); clearTimeout(autoT); cvs.cv.removeEventListener('pointerdown', onDown); cvs.cv.removeEventListener('pointermove', onMove); cvs.cv.removeEventListener('pointerup', onUp); cvs.cv.removeEventListener('pointercancel', onUp); cvs.destroy(); ui.remove(); },
    };
  }

  L.register({
    id: 'mahjong', name: '마작', tag: '패 맞추기', cat: '보드', hidden: true,
    blurb: '패 14장으로 「몸통 4개 + 머리 1개」를 먼저 완성! 리치·도라·역으로 점수를 키우는 4인 마작(동풍전). 3인 마작(북빼기)도 있어요.',
    controls: [
      { id: 'discard', label: '고른 패 버리기', keys: ['Enter', 'Space'], pad: ['a'] },
      { id: 'win', label: '쯔모 · 론', keys: ['KeyW'], pad: ['y'] },
      { id: 'riichi', label: '리치', keys: ['KeyR'], pad: ['x'] },
      { id: 'pon', label: '퐁', keys: ['KeyE'] },
      { id: 'chi', label: '치', keys: ['KeyC'] },
      { id: 'kan', label: '깡', keys: ['KeyK'] },
      { id: 'pass', label: '패스 · 취소', keys: ['KeyP'], pad: ['b'] },
      { id: 'q9', label: '구종구패', keys: ['KeyQ'] },
      { id: 'nuki', label: '북 빼기', keys: ['KeyN'] },
      { id: 'next', label: '다음 판', keys: ['Enter'], pad: ['start'] },
    ],
    minPlayers: 3, maxPlayers: 4, defaultPlayers: 4, aiDelay: 700,
    maxPlayersIf: (o) => (o && o.pm === '3' ? 3 : 4),
    icon: '<rect x="6" y="10" width="20" height="30" rx="4" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="16" cy="25" r="5" fill="currentColor"/><rect x="28" y="16" width="22" height="30" rx="4" fill="currentColor"/><rect x="34" y="21" width="4" height="9" rx="2" fill="#123f3a"/><rect x="40" y="21" width="4" height="9" rx="2" fill="#123f3a"/><rect x="37" y="33" width="4" height="9" rx="2" fill="#123f3a"/>',
    tint: '#1d5550',
    options: [
      { id: 'pm', label: '인원 방식', tip: '인원 규칙.', choices: [{ v: '4', label: '4인(기본)', tip: '4명 표준 리치 마작.' }, { v: '3', label: '3인(산마)', tip: '3명, 일부 만수패를 빼고 해요(산마).' }], def: '4' },
      { id: 'len', label: '길이', tip: '대국 길이.', choices: [{ v: 'e', label: '동풍전(4인 4국·3인 3국)', tip: '동풍만 돌고 끝.' }, { v: 's', label: '반장전(8국·3인 6국)', tip: '동풍·남풍까지.' }], def: 'e' },
      { id: 'aka', label: '적도라(빨간 5)', tip: '빨간 5 패는 도라 1개로 쳐요.', choices: [{ v: 'on', label: '있음(3장)' }, { v: 'off', label: '없음' }], def: 'on' },
      { id: 'q9', label: '구종구패 유국', tip: '첫 차례에 요구패가 9종 이상이면 판을 무를 수 있어요.', choices: [{ v: 'on', label: '있음' }, { v: 'off', label: '없음' }], def: 'on' },
      { id: 'help', label: '버릴 패 추천', tip: '내 차례에 버리기 좋은 패를 표시해요.', choices: [{ v: 'on', label: '켬' }, { v: 'off', label: '끔' }], def: 'on' },
    ],
    quick: [
      '패 14장을 「몸통 4개(연속 3장 또는 같은 패 3장) + 머리 1개(같은 패 2장)」로 먼저 완성하면 이겨요.',
      '내 차례: 1장 자동으로 뽑고 → 1장 버리기(탭해서 올리고 한 번 더 탭). 남의 버림패로 퐁·치·론도 돼요.',
      '완성하려면 「역」이 1개 필요해요(리치·탕야오·역패가 쉬워요). 점수는 자동 계산, 끝날 때 점수 1등이 우승!',
    ],
    rules: RULES,
    codex: CODEX,
    tutorial: [
      { text: '마작은 패 14장으로 「몸통 4개 + 머리 1개」를 만드는 게임이에요. 몸통 = 3·4·5처럼 연속 3장 또는 같은 패 3장, 머리 = 같은 패 2장.' },
      { sel: '.mj-bar', text: '아래가 내 손패예요. 차례가 오면 1장이 오른쪽에 자동으로 들어와요. 버릴 패를 탭하면 올라오고, 한 번 더 탭하면 버려요. 초록 테두리는 추천 패!' },
      { sel: '.mj-hint', text: '1장만 오면 완성되는 「텐파이」가 되면 여기에 기다리는 패와 남은 장 수가 보여요. 울지 않았다면 「리치」를 걸 수 있어요.' },
      { sel: '.mj-call', text: '남이 버린 패로 몸통을 만들 수 있으면 퐁·치 버튼이 떠요. 귀찮으면 「부르기」를 끄세요(론은 계속 물어봐요).' },
      { sel: '.mj-yaku', text: '완성하려면 역이 꼭 1개 있어야 해요. 「역표」에서 역 목록과 예시를 볼 수 있어요. 시작해 볼까요?' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { K, ki, cnt, shanten, waitsOf, isAgari, evalWin, winCtx, decomps, chooseDiscard, buildClaims },
  });
})();
