/* 경마 — realtime jockey race (2–8, one person per phone; local = me + AI).
   You ride: hold the pad to push (faster, burns stamina), let go to settle (cheap). ◀ ▶ move the horse left / right on screen: the rail is the
   shortest way round the bends, a horse right in front boxes you in, sitting 2–7 m behind one saves stamina (slipstream).
   The final straight is the 「스퍼트」: mash the pad (Space on PC) to build spurt power. Courses are generated per race
   (평지 / 장애물, 잔디 / 더트, 날씨→주로 상태, 800–2400 m). The field is drawn from ~100 famous Japanese racehorses with real-style aptitudes.
   Host-authoritative fixed-step sim (1/60 s); guests publish inputs + locally judged jump / spurt-tap counters and get ~15 Hz
   snapshots. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ======================= engine (pure, node-testable) ======================= */
  const H = 1 / 60, LW = 1.3, BODY = 2.4, COUNT = 3, END_T = 5.5, JW = 0.6;
  /* coats (털색): c body, m mane/tail, bz blaze (얼굴 흰 줄), sk white socks */
  const CO = {
    bay: { c: '#8a5228', m: '#1c120c' }, dbay: { c: '#4a2e1c', m: '#140c08' }, brn: { c: '#2e2226', m: '#0c090a' },
    chs: { c: '#b0592a', m: '#c9844a' }, gry: { c: '#bdb8b2', m: '#8d8780' }, wgr: { c: '#dedad2', m: '#aaa49c' },
  };
  const coat = (k, bz, sk) => Object.assign({}, CO[k], { bz: bz || 0, sk: sk || 0 });
  /* 일본의 유명 경주마. s 각질(0 도주 1 선행 2 차분 3 추입), sp/en/ac 속도·지구력·순발력(1–10),
     a 적성 6글자 = 잔디·더트·단거리·마일·중거리·장거리 (A 최고 … G 최저), hv 무거운 주로(0 싫어함 1 보통 2 잘 달림).
     출전 조건: 그 경주의 코스(잔디/더트)와 거리 적성이 둘 다 C 이상 */
  const HORSES = [
    { n: '디프 임팩트', co: coat('bay', 1, 1), s: 3, sp: 10, en: 8, ac: 10, a: 'AGFBAA', hv: 1, f: '날아가는 듯한 추입 · 무패 삼관마' },
    { n: '오르페브르', co: coat('chs', 1, 1), s: 3, sp: 9, en: 9, ac: 10, a: 'AGECAA', hv: 2, f: '거친 성격의 삼관마 · 무거운 주로에 강함' },
    { n: '키타산 블랙', co: coat('bay', 0, 1), s: 0, sp: 10, en: 10, ac: 8, a: 'AGECAA', hv: 2, f: '앞에서 끝까지 버티는 도주 · G1 일곱 번 · 진흙탕 천황상도 우승' },
    { n: '알몬드 아이', co: coat('bay', 1, 0), s: 2, sp: 10, en: 7, ac: 10, a: 'AGDAAA', hv: 1, f: 'G1 아홉 번 · 마일~2400m 최강의 끝걸음' },
    { n: '이퀴녹스', co: coat('brn', 0, 0), s: 1, sp: 10, en: 9, ac: 9, a: 'AGEBAA', hv: 1, f: '세계 1위 레이팅 · 앞에서 압도하는 중장거리 괴물' },
    { n: '골드십', co: coat('gry', 1, 1), s: 3, sp: 8, en: 10, ac: 8, a: 'AGGDAA', hv: 2, f: '먼 곳부터 치고 오르는 스테이어 · 무거운 주로 환영' },
    { n: '사일런스 스즈카', co: coat('chs', 1, 0), s: 0, sp: 10, en: 6, ac: 8, a: 'AGDAAE', hv: 1, f: '처음부터 달아나는 대도주 · 마일~중거리' },
    { n: '오구리 캡', co: coat('gry', 0, 0), s: 2, sp: 9, en: 8, ac: 8, a: 'ABEAAB', hv: 1, f: '지방 더트 출신 · 잔디 G1 네 번(마일~2500m)' },
    { n: '토카이 테이오', co: coat('bay', 1, 1), s: 1, sp: 9, en: 8, ac: 9, a: 'AGFCAB', hv: 1, f: '유연한 걸음의 선행 · 중거리' },
    { n: '메지로 맥퀸', co: coat('gry', 1, 0), s: 1, sp: 8, en: 10, ac: 7, a: 'AFGEBA', hv: 2, f: '장거리의 명수 · 무거운 주로도 끄떡없음' },
    { n: '라이스 샤워', co: coat('brn', 0, 0), s: 2, sp: 7, en: 10, ac: 7, a: 'AGGDCA', hv: 1, f: '작은 몸의 스테이어 · 장거리 전문' },
    { n: '심볼리 루돌프', co: coat('bay', 1, 1), s: 1, sp: 9, en: 10, ac: 9, a: 'AFEBAA', hv: 1, f: '빈틈없는 선행 · 무패 삼관마 · G1 일곱 번' },
    { n: '나리타 브라이언', co: coat('dbay', 1, 0), s: 2, sp: 9, en: 9, ac: 9, a: 'AGEBAA', hv: 1, f: '압도적인 삼관마 · 중단에서 강하게' },
    { n: '그래스 원더', co: coat('chs', 0, 0), s: 3, sp: 9, en: 8, ac: 9, a: 'AGEAAA', hv: 1, f: '폭발적인 추입 · 그랑프리 3연승(마일 G1도)' },
    { n: '엘 콘도르 파사', co: coat('bay', 1, 1), s: 1, sp: 9, en: 9, ac: 9, a: 'ABFAAA', hv: 2, f: '재팬컵·해외 G1 제패 · 개선문 2착 · 무거운 주로 OK' },
    { n: '다이와 스칼렛', co: coat('chs', 1, 0), s: 1, sp: 9, en: 8, ac: 9, a: 'AFFAAB', hv: 1, f: '앞에서 버티는 선행 · 마일~중거리' },
    { n: '보드카', co: coat('bay', 1, 1), s: 2, sp: 10, en: 7, ac: 10, a: 'AGEAAB', hv: 0, f: 'G1 일곱 번 · 도쿄의 날카로운 끝걸음 · 양호한 주로 선호' },
    { n: '스페셜 위크', co: coat('dbay', 1, 1), s: 2, sp: 9, en: 9, ac: 8, a: 'AGFCAA', hv: 1, f: '안정된 중단 대기 · 중장거리' },
    { n: '컨트레일', co: coat('brn', 1, 1), s: 3, sp: 9, en: 8, ac: 9, a: 'AGECAA', hv: 1, f: '무패 삼관마 · 날카로운 추입' },
    { n: '크로후네', co: coat('wgr', 1, 0), s: 1, sp: 10, en: 8, ac: 8, a: 'BAEAAE', hv: 2, f: '더트의 괴물 · 젖은 더트도 거침없음' },
    // 단거리·마일
    { n: '사쿠라 바쿠신 오', co: coat('bay', 1, 0), s: 1, sp: 10, en: 4, ac: 9, a: 'AGABFG', hv: 1, f: '스프린트의 왕 · 1200m에서는 적수가 없음' },
    { n: '로드 카나로아', co: coat('bay', 1, 1), s: 1, sp: 10, en: 6, ac: 10, a: 'AGAAEG', hv: 1, f: '홍콩까지 제패한 단거리 최강마 · G1 여섯 번' },
    { n: '니시노 플라워', co: coat('chs', 1, 1), s: 1, sp: 9, en: 5, ac: 9, a: 'AGAAEG', hv: 1, f: '작은 몸의 스피드 · 단거리~마일' },
    { n: '카렌 찬', co: coat('bay', 0, 0), s: 1, sp: 9, en: 5, ac: 8, a: 'AGACFG', hv: 1, f: '스프린트 G1 연승 · 앞에서 버팀' },
    { n: '그란 알레그리아', co: coat('bay', 1, 0), s: 3, sp: 10, en: 6, ac: 10, a: 'AGAACG', hv: 1, f: '단거리~마일의 폭발적인 추입' },
    { n: '킹 헤일로', co: coat('dbay', 1, 1), s: 3, sp: 8, en: 6, ac: 9, a: 'AGABDE', hv: 2, f: '무거운 주로의 스프린트 추입' },
    { n: '타이키 셔틀', co: coat('chs', 1, 0), s: 1, sp: 10, en: 6, ac: 9, a: 'ABBAEG', hv: 2, f: '프랑스 마일 G1까지 · G1 다섯 번의 마일 강자' },
    { n: '다이와 메이저', co: coat('dbay', 1, 0), s: 1, sp: 9, en: 8, ac: 8, a: 'ACEAAD', hv: 2, f: 'G1 다섯 번 · 마일~2000m의 튼튼한 선행' },
    // 중장거리
    { n: '테이에무 오페라 오', co: coat('chs', 1, 1), s: 1, sp: 9, en: 10, ac: 8, a: 'AGFCAA', hv: 2, f: '한 해 무패의 왕자 · G1 일곱 번 · 중장거리' },
    { n: '마야노 탑건', co: coat('chs', 1, 0), s: 1, sp: 9, en: 9, ac: 8, a: 'AFFCAA', hv: 1, f: '어떤 각질로도 달리는 장거리마' },
    { n: '비와 하야히데', co: coat('gry', 1, 0), s: 1, sp: 8, en: 10, ac: 7, a: 'AFGDAA', hv: 1, f: '머리 좋은 선행 · 장거리 안정감' },
    // 더트 전문
    { n: '스마트 팔콘', co: coat('chs', 1, 0), s: 0, sp: 9, en: 9, ac: 8, a: 'EAFBAC', hv: 2, f: '더트 중거리 도주의 제왕' },
    { n: '에스포와르 시티', co: coat('chs', 1, 1), s: 0, sp: 9, en: 8, ac: 8, a: 'EACAAE', hv: 2, f: '더트 마일 도주 · 젖은 더트 환영' },
    { n: '코파노 리키', co: coat('chs', 1, 0), s: 1, sp: 10, en: 8, ac: 8, a: 'FACAAC', hv: 1, f: '더트 G1 열한 번 · 선행 강자' },
    { n: '홋코 타루마에', co: coat('bay', 0, 0), s: 1, sp: 9, en: 9, ac: 8, a: 'GAFCAB', hv: 1, f: '더트 장거리도 버티는 끈기' },
    { n: '칼스톤 라이트 오', co: coat('bay', 1, 1), s: 0, sp: 9, en: 4, ac: 9, a: 'ACAEGG', hv: 2, f: '직선 1000m 레코드 · 빗속 스프린터즈 S 우승' },
    { n: '골드 드림', co: coat('chs', 1, 1), s: 3, sp: 9, en: 7, ac: 9, a: 'EACAAC', hv: 1, f: '더트 마일~중거리의 날카로운 추입' },
    { n: '카네히키리', co: coat('chs', 1, 1), s: 2, sp: 9, en: 9, ac: 8, a: 'EAFBAB', hv: 1, f: '두 번 부활한 더트 중장거리 강자' },
    { n: '메이쇼 볼러', co: coat('dbay', 0, 0), s: 0, sp: 9, en: 5, ac: 9, a: 'BAAAEG', hv: 2, f: '잔디·더트 가리지 않는 스프린트 도주' },
    { n: '레드 르젤', co: coat('chs', 1, 1), s: 3, sp: 9, en: 5, ac: 9, a: 'CAABFG', hv: 1, f: '더트 단거리의 매서운 추입' },
    // ── 추가 명마 (단거리·마일 → 중장거리 → 더트 → 장애물 j:1 = 장애물 전문: 장애물 경주에서 조금 빠르고 체력이 덜 닳음)
    { n: '듀랜달', co: coat('bay', 1, 1), s: 3, sp: 9, en: 5, ac: 10, a: 'AGBAEG', hv: 1, y: 2000, f: '번개 같은 추입 · 스프린트·마일 G1' },
    { n: '비리브', co: coat('dbay', 0, 1), s: 2, sp: 9, en: 5, ac: 9, a: 'AFADFG', hv: 1, y: 2000, f: '스프린터즈 S 우승 · 단거리 차분' },
    { n: '아스톤 마찬', co: coat('chs', 1, 0), s: 0, sp: 9, en: 4, ac: 9, a: 'AGAEGG', hv: 1, y: 2000, f: '1200m를 처음부터 끝까지 달아나는 암말' },
    { n: '모리스', co: coat('dbay', 1, 0), s: 2, sp: 10, en: 7, ac: 9, a: 'AGCAAE', hv: 1, y: 2010, f: '마일 최강 · 해외 G1까지 제패' },
    { n: '다이타쿠 헬리오스', co: coat('bay', 1, 1), s: 0, sp: 9, en: 6, ac: 8, a: 'AGCAEF', hv: 1, y: 1990, f: '마일 도주 · 마일 G1 2연패' },
    { n: '닛포 테이오', co: coat('dbay', 0, 0), s: 1, sp: 9, en: 6, ac: 8, a: 'AFBACF', hv: 1, y: 1980, f: '1980년대 마일의 왕' },
    { n: '노스 플라이트', co: coat('bay', 1, 0), s: 1, sp: 9, en: 6, ac: 9, a: 'AGBADF', hv: 1, y: 1990, f: '마일 G1을 휩쓴 암말' },
    { n: '야마닌 제퍼', co: coat('chs', 1, 1), s: 2, sp: 9, en: 7, ac: 8, a: 'AGCAAE', hv: 1, y: 1990, f: '마일~2000m 천황상까지' },
    { n: '인디 챔프', co: coat('bay', 1, 0), s: 2, sp: 9, en: 6, ac: 9, a: 'AGCAEF', hv: 1, y: 2010, f: '마일 G1 봄·가을 제패' },
    { n: '미스터 멜로디', co: coat('chs', 0, 1), s: 1, sp: 9, en: 5, ac: 8, a: 'ABABEG', hv: 2, y: 2010, f: '더트 출신 · 잔디 스프린트 G1 우승' },
    { n: '파인 니들', co: coat('bay', 1, 1), s: 2, sp: 9, en: 5, ac: 9, a: 'AGABEG', hv: 1, y: 1990, f: '단거리 G1 봄·가을 연승' },
    { n: '나무라 클레어', co: coat('chs', 1, 0), s: 3, sp: 8, en: 5, ac: 10, a: 'AGABEG', hv: 1, y: 2020, f: '단거리의 매서운 추입 암말' },
    { n: '픽시 나이트', co: coat('bay', 0, 0), s: 1, sp: 9, en: 5, ac: 9, a: 'AGABEG', hv: 1, y: 2020, f: '3세에 스프린터즈 S 우승 · 앞에서 버팀' },
    { n: '저스트 어 웨이', co: coat('dbay', 1, 1), s: 2, sp: 10, en: 7, ac: 9, a: 'AGDAAC', hv: 2, y: 2010, f: '세계 1위에 오른 마일~중거리 강자 · 무거운 주로 야스다 기념 우승' },
    { n: '애드마이어 마스', co: coat('chs', 1, 1), s: 1, sp: 9, en: 6, ac: 8, a: 'AGBACF', hv: 1, y: 2010, f: '해외 원정 마일 G1 우승' },
    { n: '레몬 팝', co: coat('chs', 1, 0), s: 1, sp: 10, en: 6, ac: 9, a: 'GAAAEG', hv: 2, y: 2020, f: '더트 단거리·마일 최강' },
    { n: '미스터 시비', co: coat('bay', 1, 0), s: 3, sp: 9, en: 8, ac: 9, a: 'AGFCAA', hv: 1, y: 1980, f: '맨 뒤에서 몰아치는 삼관마' },
    { n: '타마모 크로스', co: coat('gry', 0, 0), s: 2, sp: 9, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 1980, f: '천황상 봄·가을 연승 회색마' },
    { n: '이나리 원', co: coat('bay', 0, 1), s: 2, sp: 8, en: 9, ac: 8, a: 'ABECAA', hv: 2, y: 1980, f: '지방 더트 출신 · 그랑프리 우승' },
    { n: '슈퍼 크리크', co: coat('bay', 1, 1), s: 1, sp: 8, en: 10, ac: 7, a: 'AGGCAA', hv: 1, y: 1980, f: '큰 몸의 튼튼한 장거리 선행' },
    { n: '미호노 부르봉', co: coat('chs', 0, 0), s: 0, sp: 9, en: 9, ac: 7, a: 'AGEBAB', hv: 1, y: 1990, f: '혹독한 단련의 도주 · 2관마' },
    { n: '나리타 타이신', co: coat('brn', 1, 0), s: 3, sp: 9, en: 7, ac: 9, a: 'AGDBAB', hv: 1, y: 1990, f: '날카로운 추입 · 클래식 첫 관' },
    { n: '위닝 티켓', co: coat('bay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 1990, f: '더비 우승 · 중단에서 뻗는 걸음' },
    { n: '사쿠라 로렐', co: coat('chs', 1, 1), s: 2, sp: 8, en: 9, ac: 8, a: 'AGEBAA', hv: 1, y: 1990, f: '큰 부상을 딛고 연도 대표마' },
    { n: '에어 그루브', co: coat('bay', 1, 0), s: 1, sp: 9, en: 7, ac: 9, a: 'AGCAAC', hv: 1, y: 1990, f: '천황상(가을)을 제패한 암말' },
    { n: '메지로 도베르', co: coat('bay', 0, 1), s: 2, sp: 8, en: 7, ac: 9, a: 'AGCAAC', hv: 1, y: 1990, f: '암말 G1 다섯 번' },
    { n: '세이운 스카이', co: coat('gry', 1, 0), s: 0, sp: 9, en: 9, ac: 7, a: 'AGEBAA', hv: 1, y: 1990, f: '도주로 클래식 2관 · 장거리 도주 압승' },
    { n: '아그네스 타키온', co: coat('chs', 1, 1), s: 1, sp: 10, en: 7, ac: 9, a: 'AGDBAC', hv: 1, y: 2000, f: '무패로 은퇴한 환상의 준마' },
    { n: '정글 포켓', co: coat('bay', 1, 0), s: 2, sp: 9, en: 8, ac: 8, a: 'AGEBAA', hv: 1, y: 2000, f: '더비·재팬컵 우승' },
    { n: '맨해튼 카페', co: coat('brn', 0, 0), s: 3, sp: 8, en: 10, ac: 8, a: 'AGGCAA', hv: 1, y: 2000, f: '깊은 추입의 스테이어' },
    { n: '심볼리 크리스 에스', co: coat('dbay', 1, 1), s: 2, sp: 9, en: 9, ac: 8, a: 'AGEBAA', hv: 1, y: 2000, f: '가을 큰 무대 2년 연속 제패' },
    { n: '네오 유니버스', co: coat('chs', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2000, f: '클래식 2관 · 중단 대기' },
    { n: '젠노 롭 로이', co: coat('dbay', 1, 0), s: 2, sp: 9, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 2000, f: '가을 고마일 G1 3연승' },
    { n: '하츠 크라이', co: coat('chs', 1, 1), s: 1, sp: 9, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 2000, f: '무패 삼관마를 앞에서 꺾음 · 두바이 시마 클래식 압승' },
    { n: '마츠리다 고흐', co: coat('bay', 1, 0), s: 1, sp: 8, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 2000, f: '나카야마 그랑프리의 강자' },
    { n: '메이쇼 삼손', co: coat('bay', 0, 0), s: 1, sp: 9, en: 9, ac: 8, a: 'AGEBAA', hv: 2, y: 2000, f: '천황상 봄·가을 연승 · 끈질긴 선행' },
    { n: '딥 스카이', co: coat('chs', 1, 1), s: 2, sp: 9, en: 8, ac: 8, a: 'ACDAAB', hv: 1, y: 2000, f: '더트에서 올라와 마일·더비 2관' },
    { n: '스크린 히어로', co: coat('chs', 1, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'AGFCAA', hv: 1, y: 2000, f: '재팬컵 대이변의 주인공' },
    { n: '부에나 비스타', co: coat('dbay', 1, 1), s: 3, sp: 9, en: 8, ac: 9, a: 'AGCAAB', hv: 1, y: 2000, f: 'G1 여섯 번 · 추입 암말' },
    { n: '젠틸돈나', co: coat('bay', 1, 1), s: 1, sp: 9, en: 9, ac: 9, a: 'AGDBAA', hv: 1, y: 2010, f: '삼관 암말 · 재팬컵 연패 · G1 일곱 번' },
    { n: '키즈나', co: coat('dbay', 1, 0), s: 3, sp: 9, en: 7, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '더비 추입 · 해외 원정 승리' },
    { n: '에피파네이아', co: coat('bay', 1, 1), s: 1, sp: 9, en: 9, ac: 8, a: 'AGEBAA', hv: 1, y: 2010, f: '재팬컵 대승의 선행' },
    { n: '두라멘테', co: coat('chs', 1, 1), s: 2, sp: 10, en: 7, ac: 8, a: 'AGDBAB', hv: 1, y: 2010, f: '폭발적인 끝걸음의 2관마' },
    { n: '사토노 다이아몬드', co: coat('chs', 1, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 2010, f: '장거리 클래식·그랑프리 우승' },
    { n: '레이 데 오로', co: coat('bay', 1, 0), s: 2, sp: 9, en: 8, ac: 8, a: 'AGEBAA', hv: 1, y: 2010, f: '더비·천황상(가을) 우승' },
    { n: '월드 프리미어', co: coat('chs', 1, 1), s: 2, sp: 8, en: 10, ac: 7, a: 'AGGCBA', hv: 1, y: 2010, f: '장거리 클래식·천황상(봄) 스테이어' },
    { n: '리스 그라시외', co: coat('bay', 1, 0), s: 3, sp: 9, en: 8, ac: 9, a: 'AGDBAA', hv: 1, y: 2010, f: '그랑프리 3연승 암말' },
    { n: '크로노 제네시스', co: coat('bay', 1, 1), s: 2, sp: 9, en: 9, ac: 8, a: 'AGEBAA', hv: 2, y: 2010, f: '무거운 주로의 그랑프리 여왕' },
    { n: '데어링 택트', co: coat('bay', 1, 1), s: 3, sp: 9, en: 7, ac: 9, a: 'AGDAAB', hv: 1, y: 2020, f: '무패 삼관 암말' },
    { n: '타이틀 홀더', co: coat('bay', 0, 0), s: 0, sp: 9, en: 10, ac: 7, a: 'AGGCAA', hv: 2, y: 2020, f: '장거리 도주 · 무거운 주로 환영' },
    { n: '도우 듀스', co: coat('bay', 1, 1), s: 3, sp: 9, en: 8, ac: 9, a: 'AGDBAA', hv: 1, y: 2020, f: '더비·천황상(가을)·재팬컵 우승의 추입' },
    { n: '리버티 아일랜드', co: coat('bay', 1, 0), s: 3, sp: 9, en: 7, ac: 10, a: 'AGDAAB', hv: 1, y: 2020, f: '날카로운 추입의 삼관 암말' },
    { n: '소다시', co: coat('wgr', 0, 0), s: 1, sp: 9, en: 6, ac: 9, a: 'ABCAAF', hv: 1, y: 2020, f: '하얀 털의 G1 암말 · 더트도 소화' },
    { n: '호쿠토 베가', co: coat('chs', 1, 0), s: 1, sp: 8, en: 9, ac: 8, a: 'BAEAAB', hv: 2, y: 1990, f: '더트 교류 G1을 휩쓴 여왕' },
    { n: '애드마이어 돈', co: coat('chs', 1, 1), s: 2, sp: 8, en: 9, ac: 8, a: 'CAEBAB', hv: 1, y: 2000, f: '더트 G1 여섯 번' },
    { n: '타임 패러독스', co: coat('bay', 1, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'EAFCAB', hv: 1, y: 2000, f: '늦게 핀 더트 중장거리 강자' },
    { n: '트랜센드', co: coat('bay', 0, 1), s: 0, sp: 9, en: 8, ac: 7, a: 'EAEBAC', hv: 2, y: 2010, f: '더트 도주 · 큰 대회 연패' },
    { n: '크리소베릴', co: coat('chs', 0, 0), s: 2, sp: 9, en: 8, ac: 9, a: 'GAEBAC', hv: 1, y: 2010, f: '거의 지지 않은 더트 강자' },
    { n: '오메가 퍼퓸', co: coat('gry', 0, 0), s: 3, sp: 8, en: 9, ac: 9, a: 'EAFCAB', hv: 1, y: 2010, f: '연말 더트 대상전 4연패' },
    { n: '츄와 위저드', co: coat('chs', 1, 1), s: 2, sp: 8, en: 9, ac: 8, a: 'EAFBAB', hv: 1, y: 2010, f: '더트 중거리 G1 강자' },
    { n: '우슈바 테소로', co: coat('brn', 1, 0), s: 3, sp: 8, en: 9, ac: 9, a: 'EAFCAB', hv: 1, y: 2020, f: '두바이 월드컵을 제패한 더트 추입' },
    { n: '오주 초산', co: coat('bay', 1, 1), s: 1, sp: 7, en: 10, ac: 8, a: 'AGGDBA', hv: 2, y: 2010, j: 1, f: '장애물 G1 아홉 번 · 생울타리의 왕' },
    { n: '고카이', co: coat('chs', 1, 0), s: 2, sp: 7, en: 10, ac: 7, a: 'AFGEBA', hv: 2, y: 2000, j: 1, f: '장애물 큰 대회 연패' },
    { n: '카라시', co: coat('bay', 0, 0), s: 3, sp: 7, en: 10, ac: 8, a: 'AGGDBA', hv: 1, y: 2000, j: 1, f: '바다 건너온 장애물 대회 3연패' },
    { n: '니시노 데이지', co: coat('bay', 1, 1), s: 2, sp: 7, en: 9, ac: 8, a: 'AGFCBA', hv: 1, y: 2020, j: 1, f: '평지 중상 우승 뒤 장애물로 전향' },
    // ── 추가 명마 2차 (1970년대 → 2020년대, 잔디 중장거리 · 단거리·마일 · 더트 순)
    { n: '하이세이코', co: coat('bay', 0, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'ADEBAC', hv: 2, y: 1970, f: '지방에서 올라온 국민 아이돌 · 사츠키상·다카라즈카 기념' },
    { n: '텐포인트', co: coat('chs', 1, 1), s: 1, sp: 9, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 1970, f: '「유성의 귀공자」 · 텐노상(봄)·아리마 기념' },
    { n: '토쇼 보이', co: coat('bay', 1, 0), s: 1, sp: 10, en: 7, ac: 9, a: 'AGEBAB', hv: 1, y: 1970, f: '빠른 선행 · 사츠키상·아리마 기념·다카라즈카 기념' },
    { n: '그린 그래스', co: coat('dbay', 0, 1), s: 2, sp: 8, en: 10, ac: 8, a: 'AGGDBA', hv: 2, y: 1970, f: '「TTG」 스테이어 · 기쿠카상·텐노상(봄)·아리마 기념' },
    { n: '마루젠스키', co: coat('brn', 0, 0), s: 0, sp: 10, en: 7, ac: 8, a: 'AFDABC', hv: 1, y: 1970, f: '8전 8승 무패 · 큰 차이로 달아나던 「슈퍼카」' },
    { n: '카츠라기 에이스', co: coat('bay', 1, 0), s: 0, sp: 9, en: 8, ac: 8, a: 'AFEBAB', hv: 1, y: 1980, f: '재팬컵 일본마 첫 우승 · 다카라즈카 기념' },
    { n: '갤럽 다이나', co: coat('chs', 1, 1), s: 3, sp: 8, en: 7, ac: 8, a: 'AGCAAC', hv: 1, y: 1980, f: '텐노상(가을)에서 무패 삼관마를 꺾은 대이변' },
    { n: '시리우스 심볼리', co: coat('bay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGECAB', hv: 2, y: 1980, f: '일본 더비 우승 · 유럽 장기 원정' },
    { n: '미호 신잔', co: coat('bay', 0, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 1980, f: '사츠키상·기쿠카상·텐노상(봄)' },
    { n: '다이나 갈리버', co: coat('chs', 1, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'AGECAA', hv: 1, y: 1980, f: '일본 더비·아리마 기념' },
    { n: '사쿠라 유타카 오', co: coat('bay', 1, 1), s: 1, sp: 9, en: 7, ac: 8, a: 'AGCAAC', hv: 1, y: 1980, f: '텐노상(가을) 레코드 우승' },
    { n: '사쿠라 스타 오', co: coat('bay', 1, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'AGECAA', hv: 1, y: 1980, f: '사츠키상·기쿠카상 2관' },
    { n: '메지로 라모누', co: coat('bay', 0, 1), s: 2, sp: 8, en: 8, ac: 9, a: 'AGDAAC', hv: 1, y: 1980, f: '첫 암말 삼관' },
    { n: '니혼 필로 위너', co: coat('chs', 1, 0), s: 1, sp: 9, en: 7, ac: 9, a: 'ACBACF', hv: 2, y: 1980, f: '마일 챔피언십 2연패·야스다 기념' },
    { n: '사쿠라 치요노 오', co: coat('bay', 1, 1), s: 0, sp: 8, en: 8, ac: 8, a: 'AGDBAB', hv: 1, y: 1980, f: '도주로 일본 더비 우승' },
    { n: '야에노 무테키', co: coat('chs', 1, 1), s: 1, sp: 9, en: 8, ac: 8, a: 'AFEBAC', hv: 1, y: 1980, f: '사츠키상·텐노상(가을) 레코드' },
    { n: '오사이치 조지', co: coat('bay', 0, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'AGDBAC', hv: 1, y: 1980, f: '다카라즈카 기념 · 강호들을 앞에서 따돌림' },
    { n: '메지로 라이언', co: coat('bay', 1, 0), s: 3, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 1990, f: '다카라즈카 기념 · 끈질긴 추입' },
    { n: '메지로 파머', co: coat('bay', 0, 1), s: 0, sp: 8, en: 9, ac: 8, a: 'AGECAA', hv: 2, y: 1990, f: '도주로 다카라즈카·아리마 기념 제패' },
    { n: '트윈 터보', co: coat('bay', 1, 1), s: 0, sp: 8, en: 7, ac: 8, a: 'AGEBAD', hv: 1, y: 1990, f: '무모한 대도주 · 올커머즈 대승' },
    { n: '나이스 네이처', co: coat('bay', 1, 0), s: 2, sp: 7, en: 9, ac: 7, a: 'AGECAA', hv: 1, y: 1990, f: '아리마 기념 3년 연속 3착 · 끈기의 상징' },
    { n: '이쿠노 딕터스', co: coat('chs', 1, 1), s: 2, sp: 7, en: 9, ac: 7, a: 'AGDBAB', hv: 2, y: 1990, f: '쉬지 않고 51전을 달린 철의 말' },
    { n: '골드 시티', co: coat('chs', 1, 1), s: 2, sp: 8, en: 7, ac: 8, a: 'AGDBAB', hv: 1, y: 1990, f: '아사히배 3세S · 클래식 내내 상위권' },
    { n: '베가', co: coat('bay', 1, 0), s: 1, sp: 8, en: 7, ac: 9, a: 'AGCAAD', hv: 1, y: 1990, f: '오카상·오크스 2관 암말' },
    { n: '댄스 파트너', co: coat('dbay', 1, 0), s: 3, sp: 8, en: 8, ac: 8, a: 'AGDBAB', hv: 1, y: 1990, f: '오크스·엘리자베스 여왕배' },
    { n: '후지 키세키', co: coat('dbay', 1, 1), s: 1, sp: 9, en: 7, ac: 9, a: 'AGCABD', hv: 1, y: 1990, f: '4전 4승 · 환상의 무패마' },
    { n: '사쿠라 치토세 오', co: coat('bay', 1, 1), s: 3, sp: 8, en: 7, ac: 9, a: 'AGCAAC', hv: 1, y: 1990, f: '텐노상(가을) 추입 우승' },
    { n: '마치카네 탄호이저', co: coat('bay', 0, 0), s: 2, sp: 7, en: 8, ac: 8, a: 'AGFCAA', hv: 1, y: 1990, f: '메구로 기념 등 G2 우승 · 스테이어' },
    { n: '마치카네 후쿠키타루', co: coat('chs', 1, 0), s: 2, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 1990, f: '기쿠카상 우승 · 복을 부르는 말' },
    { n: '버블검 펠로', co: coat('chs', 1, 0), s: 2, sp: 9, en: 7, ac: 9, a: 'AGCAAC', hv: 1, y: 1990, f: '3세에 텐노상(가을) 우승' },
    { n: '댄스 인 더 다크', co: coat('dbay', 1, 1), s: 3, sp: 8, en: 7, ac: 9, a: 'AGEBAA', hv: 1, y: 1990, f: '기쿠카상 · 바깥에서 몰아친 추입' },
    { n: '마블러스 선데이', co: coat('chs', 1, 1), s: 2, sp: 9, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 1990, f: '다카라즈카 기념 · 날카로운 끝걸음' },
    { n: '실크 저스티스', co: coat('bay', 0, 1), s: 3, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 1990, f: '아리마 기념 추입 우승' },
    { n: '메지로 브라이트', co: coat('bay', 1, 0), s: 3, sp: 7, en: 9, ac: 8, a: 'AGFDBA', hv: 2, y: 1990, f: '텐노상(봄) 스테이어' },
    { n: '히시 아마존', co: coat('dbay', 0, 1), s: 3, sp: 9, en: 7, ac: 8, a: 'AGCAAC', hv: 1, y: 1990, f: '추입 암말 · 재팬컵 2착' },
    { n: '비코 페가수스', co: coat('bay', 1, 0), s: 3, sp: 8, en: 7, ac: 8, a: 'AGCBAC', hv: 1, y: 1990, f: 'G1에 닿지 못한 인기마 · 날카로운 추입' },
    { n: '메이쇼 도토', co: coat('bay', 1, 1), s: 1, sp: 9, en: 9, ac: 8, a: 'AGECAA', hv: 2, y: 1990, f: '다카라즈카 기념 · 테이에무 오페라 오의 영원한 라이벌' },
    { n: '스테이 골드', co: coat('dbay', 1, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'AGEBAA', hv: 1, y: 1990, f: '홍콩 바스·두바이 시마 클래식 · 대기만성' },
    { n: '아드마이어 베가', co: coat('bay', 1, 1), s: 2, sp: 9, en: 7, ac: 8, a: 'AGDBAB', hv: 1, y: 1990, f: '일본 더비 우승' },
    { n: '나리타 톱 로드', co: coat('chs', 1, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 1990, f: '기쿠카상 · 앞에서 버티는 스테이어' },
    { n: '에어 샤커', co: coat('chs', 1, 1), s: 2, sp: 8, en: 9, ac: 8, a: 'AGECAA', hv: 1, y: 2000, f: '사츠키상·기쿠카상 2관' },
    { n: '아그네스 플라이트', co: coat('bay', 1, 0), s: 3, sp: 8, en: 8, ac: 8, a: 'AGDBAB', hv: 1, y: 2000, f: '일본 더비 코 차이 우승' },
    { n: '탭 댄스 시티', co: coat('bay', 0, 0), s: 0, sp: 8, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 2000, f: '재팬컵 9마신 대도주 · 다카라즈카 기념' },
    { n: '타니노 김렛', co: coat('bay', 1, 1), s: 3, sp: 9, en: 7, ac: 8, a: 'AGCAAC', hv: 1, y: 2000, f: '일본 더비 · 매서운 추입' },
    { n: '노 리즌', co: coat('bay', 0, 1), s: 1, sp: 8, en: 8, ac: 7, a: 'AGDBAC', hv: 1, y: 2000, f: '사츠키상 대이변' },
    { n: '히시 미라클', co: coat('chs', 0, 0), s: 3, sp: 7, en: 10, ac: 8, a: 'AGGDBA', hv: 2, y: 2000, f: '기쿠카상·텐노상(봄)·다카라즈카 기념' },
    { n: '델타 블루스', co: coat('bay', 1, 0), s: 1, sp: 8, en: 10, ac: 7, a: 'AGGDBA', hv: 1, y: 2000, f: '기쿠카상·멜버른컵 우승 스테이어' },
    { n: '코스모 바르크', co: coat('bay', 1, 1), s: 1, sp: 8, en: 9, ac: 7, a: 'AGECAA', hv: 1, y: 2000, f: '싱가포르 국제컵 우승' },
    { n: '킹 카메하메하', co: coat('bay', 1, 0), s: 2, sp: 9, en: 8, ac: 9, a: 'AGEAAB', hv: 1, y: 2000, f: 'NHK 마일컵·일본 더비 변칙 2관' },
    { n: '스위프 토쇼', co: coat('bay', 1, 1), s: 3, sp: 8, en: 8, ac: 9, a: 'AGDAAC', hv: 1, y: 2000, f: '다카라즈카 기념을 제패한 추입 암말' },
    { n: '스틸 인 러브', co: coat('chs', 1, 0), s: 2, sp: 8, en: 8, ac: 9, a: 'AGCAAC', hv: 1, y: 2000, f: '암말 삼관(2003)' },
    { n: '아드마이어 문', co: coat('bay', 1, 1), s: 2, sp: 9, en: 8, ac: 9, a: 'AGDAAB', hv: 1, y: 2000, f: '두바이 듀티프리·다카라즈카 기념·재팬컵' },
    { n: '드림 저니', co: coat('bay', 1, 0), s: 3, sp: 9, en: 8, ac: 9, a: 'AGDBAA', hv: 2, y: 2000, f: '작은 몸으로 그랑프리 연승' },
    { n: '컴퍼니', co: coat('bay', 0, 0), s: 2, sp: 9, en: 7, ac: 9, a: 'AGCAAD', hv: 1, y: 2000, f: '8세에 텐노상(가을)·마일 챔피언십' },
    { n: '나카야마 페스타', co: coat('dbay', 1, 0), s: 2, sp: 8, en: 9, ac: 7, a: 'AGECAA', hv: 2, y: 2000, f: '다카라즈카 기념 · 개선문 목 차이 2착' },
    { n: '빅토와르 피사', co: coat('dbay', 1, 1), s: 2, sp: 9, en: 8, ac: 9, a: 'ACDBAB', hv: 1, y: 2010, f: '사츠키상·아리마 기념·두바이 월드컵' },
    { n: '로즈 킹덤', co: coat('dbay', 0, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '재팬컵 우승 · 2세 G1도' },
    { n: '에이신 플래시', co: coat('dbay', 0, 0), s: 2, sp: 9, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '일본 더비·텐노상(가을)' },
    { n: '토센 조던', co: coat('bay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 2010, f: '텐노상(가을) 레코드' },
    { n: '아파파네', co: coat('bay', 1, 0), s: 2, sp: 8, en: 8, ac: 9, a: 'AGCAAD', hv: 1, y: 2010, f: '암말 삼관 · G1 다섯 번' },
    { n: '페노메노', co: coat('dbay', 1, 0), s: 2, sp: 8, en: 10, ac: 7, a: 'AGGDBA', hv: 1, y: 2010, f: '텐노상(봄) 2연패' },
    { n: '로고타입', co: coat('bay', 0, 1), s: 1, sp: 9, en: 7, ac: 9, a: 'AGBAAE', hv: 1, y: 2010, f: '사츠키상·야스다 기념(8번 인기 도주)' },
    { n: '원 앤드 온리', co: coat('dbay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '일본 더비 우승' },
    { n: '이슬라 보니타', co: coat('bay', 1, 0), s: 1, sp: 9, en: 7, ac: 8, a: 'AGCAAC', hv: 1, y: 2010, f: '사츠키상 우승' },
    { n: '토호 재칼', co: coat('bay', 0, 1), s: 1, sp: 8, en: 9, ac: 7, a: 'AGFCAA', hv: 1, y: 2010, f: '기쿠카상 레코드' },
    { n: '골드 액터', co: coat('brn', 0, 0), s: 1, sp: 8, en: 9, ac: 7, a: 'AGFCAA', hv: 1, y: 2010, f: '아리마 기념 우승' },
    { n: '러블리 데이', co: coat('dbay', 1, 1), s: 2, sp: 9, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '다카라즈카 기념·텐노상(가을)' },
    { n: '쇼난 판도라', co: coat('bay', 1, 0), s: 3, sp: 8, en: 8, ac: 9, a: 'AGDAAC', hv: 1, y: 2010, f: '재팬컵을 이긴 암말' },
    { n: '에이신 히카리', co: coat('gry', 1, 0), s: 0, sp: 9, en: 8, ac: 8, a: 'AGEAAD', hv: 1, y: 2010, f: '홍콩컵·이스파앙상 대도주' },
    { n: '리얼 스틸', co: coat('dbay', 1, 1), s: 2, sp: 9, en: 7, ac: 8, a: 'AGDAAC', hv: 1, y: 2010, f: '두바이 터프 우승' },
    { n: '마카히키', co: coat('bay', 1, 0), s: 3, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '일본 더비 · 프랑스 니엘상' },
    { n: '사토노 크라운', co: coat('dbay', 0, 1), s: 2, sp: 8, en: 9, ac: 8, a: 'AGEBAA', hv: 2, y: 2010, f: '홍콩 바스·다카라즈카 기념(무거운 주로)' },
    { n: '슈발 그랑', co: coat('bay', 1, 1), s: 1, sp: 8, en: 9, ac: 8, a: 'AGFCAA', hv: 1, y: 2010, f: '재팬컵 우승' },
    { n: '키세키', co: coat('chs', 1, 1), s: 2, sp: 8, en: 9, ac: 7, a: 'AGECAA', hv: 2, y: 2010, f: '불량 주로 기쿠카상 우승' },
    { n: '레인보우 라인', co: coat('bay', 1, 0), s: 3, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 1, y: 2010, f: '텐노상(봄) 추입 우승' },
    { n: '스아베 리처드', co: coat('bay', 1, 1), s: 1, sp: 9, en: 8, ac: 8, a: 'AGEBAB', hv: 2, y: 2010, f: '오사카배·무거운 주로 재팬컵' },
    { n: '디어드라', co: coat('chs', 1, 0), s: 3, sp: 9, en: 7, ac: 9, a: 'AGDAAC', hv: 1, y: 2010, f: '슈카상·영국 내소 스테이크스' },
    { n: '네오리얼리즘', co: coat('chs', 0, 0), s: 1, sp: 9, en: 7, ac: 8, a: 'AGCAAD', hv: 1, y: 2010, f: '홍콩 QEII컵 우승' },
    { n: '블래스트 원피스', co: coat('bay', 1, 0), s: 2, sp: 8, en: 9, ac: 7, a: 'AGECAA', hv: 2, y: 2010, f: '아리마 기념 우승' },
    { n: '와그너리안', co: coat('bay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2010, f: '일본 더비 우승' },
    { n: '피에르망', co: coat('dbay', 1, 0), s: 2, sp: 8, en: 10, ac: 7, a: 'AGGDBA', hv: 1, y: 2010, f: '기쿠카상·텐노상(봄) 2연패' },
    { n: '에포카 도로', co: coat('bay', 0, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'AGDBAB', hv: 1, y: 2010, f: '사츠키상 우승' },
    { n: '러키 라일락', co: coat('chs', 1, 1), s: 2, sp: 9, en: 7, ac: 9, a: 'AGDAAC', hv: 1, y: 2010, f: 'G1 네 번 · 오사카배' },
    { n: '러브스 온리 유', co: coat('dbay', 1, 0), s: 2, sp: 9, en: 8, ac: 9, a: 'AGDAAB', hv: 1, y: 2010, f: '오크스·홍콩컵·브리더스컵 필리 & 메어 터프' },
    { n: '사리오스', co: coat('chs', 1, 1), s: 2, sp: 9, en: 7, ac: 8, a: 'AGBAAD', hv: 1, y: 2010, f: '아사히배 FS · 마일~2000m' },
    { n: '에포리아', co: coat('bay', 1, 0), s: 1, sp: 9, en: 8, ac: 9, a: 'AGEBAB', hv: 1, y: 2020, f: '사츠키상·텐노상(가을)·아리마 기념' },
    { n: '샤프리야르', co: coat('dbay', 0, 1), s: 2, sp: 9, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2020, f: '일본 더비·두바이 시마 클래식' },
    { n: '판탈라사', co: coat('bay', 1, 0), s: 0, sp: 9, en: 8, ac: 8, a: 'BBDAAC', hv: 1, y: 2020, f: '두바이 터프·사우디컵 대도주' },
    { n: '아카이 이토', co: coat('bay', 1, 1), s: 3, sp: 8, en: 7, ac: 9, a: 'AGDAAC', hv: 1, y: 2020, f: '엘리자베스 여왕배 추입' },
    { n: '스타즈 온 어스', co: coat('bay', 1, 0), s: 3, sp: 9, en: 7, ac: 9, a: 'AGCAAC', hv: 1, y: 2020, f: '오카상·오크스 2관' },
    { n: '잭 도르', co: coat('chs', 0, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2020, f: '오사카배 우승' },
    { n: '저스틴 팰리스', co: coat('bay', 1, 0), s: 2, sp: 8, en: 9, ac: 7, a: 'AGFCAA', hv: 1, y: 2020, f: '텐노상(봄) 우승' },
    { n: '지오글리프', co: coat('bay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2020, f: '사츠키상 우승' },
    { n: '애스크 빅터 모어', co: coat('bay', 0, 1), s: 1, sp: 8, en: 9, ac: 7, a: 'AGFCAA', hv: 1, y: 2020, f: '기쿠카상 레코드' },
    { n: '두레차', co: coat('chs', 1, 0), s: 1, sp: 8, en: 9, ac: 7, a: 'AGFCAA', hv: 1, y: 2020, f: '기쿠카상 우승' },
    { n: '솔 오리엔스', co: coat('bay', 1, 1), s: 3, sp: 9, en: 7, ac: 8, a: 'AGDBAB', hv: 2, y: 2020, f: '무거운 주로 사츠키상 추입' },
    { n: '타스티에라', co: coat('bay', 1, 0), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2020, f: '일본 더비 우승' },
    { n: '저스틴 밀라노', co: coat('bay', 0, 0), s: 1, sp: 9, en: 7, ac: 8, a: 'AGDBAB', hv: 1, y: 2020, f: '사츠키상 레코드' },
    { n: '다논 데사일', co: coat('dbay', 1, 0), s: 2, sp: 8, en: 8, ac: 8, a: 'AGEBAB', hv: 1, y: 2020, f: '일본 더비 우승' },
    { n: '베라지오 오페라', co: coat('bay', 1, 1), s: 1, sp: 8, en: 8, ac: 8, a: 'AGEBAC', hv: 1, y: 2020, f: '오사카배 우승' },
    { n: '레가레이라', co: coat('bay', 0, 1), s: 3, sp: 8, en: 8, ac: 8, a: 'AGECAA', hv: 2, y: 2020, f: '아리마 기념을 이긴 3세 암말' },
    // 단거리·마일
    { n: '히시 아케보노', co: coat('bay', 1, 0), s: 0, sp: 9, en: 5, ac: 9, a: 'AGACFG', hv: 1, y: 1990, f: '스프린터즈 스테이크스 · 거구의 스프린터' },
    { n: '블랙 호크', co: coat('dbay', 0, 1), s: 2, sp: 9, en: 6, ac: 10, a: 'AGAADG', hv: 1, y: 1990, f: '스프린터즈S·야스다 기념' },
    { n: '아그네스 월드', co: coat('chs', 1, 1), s: 1, sp: 10, en: 5, ac: 9, a: 'AFABFG', hv: 1, y: 1990, f: '프랑스·영국 단거리 G1 제패' },
    { n: '트로트 스타', co: coat('chs', 1, 0), s: 3, sp: 9, en: 5, ac: 10, a: 'AGABFG', hv: 1, y: 2000, f: '다카마쓰노미야·스프린터즈 같은 해 제패' },
    { n: '아사쿠사 덴엔', co: coat('bay', 1, 1), s: 2, sp: 9, en: 6, ac: 8, a: 'AGBAEG', hv: 1, y: 2000, f: '야스다 기념 우승' },
    { n: '신코 포레스트', co: coat('bay', 0, 0), s: 1, sp: 9, en: 5, ac: 9, a: 'AGACFG', hv: 1, y: 2000, f: '다카마쓰노미야 기념 우승' },
    { n: '로렐 게레이로', co: coat('dbay', 1, 0), s: 0, sp: 10, en: 5, ac: 9, a: 'AGABFG', hv: 1, y: 2000, f: '스프린트 G1 봄·가을 · 앞에서 버팀' },
    { n: '스즈카 피닉스', co: coat('chs', 1, 1), s: 3, sp: 9, en: 5, ac: 9, a: 'AGABFG', hv: 1, y: 2000, f: '다카마쓰노미야 기념 추입' },
    { n: '킨샤사 노 키세키', co: coat('bay', 1, 0), s: 1, sp: 9, en: 5, ac: 10, a: 'AGABFG', hv: 1, y: 2010, f: '다카마쓰노미야 기념 2연패' },
    { n: '스트롱 리턴', co: coat('bay', 0, 1), s: 3, sp: 9, en: 6, ac: 9, a: 'AGBADF', hv: 1, y: 2010, f: '야스다 기념 레코드 우승' },
    { n: '미키 아일', co: coat('bay', 1, 1), s: 0, sp: 9, en: 6, ac: 10, a: 'AGBACF', hv: 1, y: 2010, f: 'NHK 마일컵·마일 챔피언십 도주' },
    { n: '빅 아서', co: coat('bay', 1, 0), s: 1, sp: 10, en: 5, ac: 9, a: 'AGABFG', hv: 1, y: 2010, f: '다카마쓰노미야 기념 레코드' },
    { n: '세이운 코세이', co: coat('bay', 0, 0), s: 1, sp: 9, en: 5, ac: 9, a: 'BBACFG', hv: 2, y: 2010, f: '무거운 주로 다카마쓰노미야 기념' },
    { n: '사토노 알라딘', co: coat('bay', 1, 1), s: 3, sp: 9, en: 6, ac: 9, a: 'AGBAEF', hv: 1, y: 2010, f: '야스다 기념 추입' },
    { n: '페르시안 나이트', co: coat('bay', 1, 0), s: 3, sp: 9, en: 6, ac: 9, a: 'AGCABE', hv: 1, y: 2010, f: '마일 챔피언십 우승' },
    { n: '스텔비오', co: coat('dbay', 0, 1), s: 2, sp: 9, en: 6, ac: 9, a: 'AGCABF', hv: 1, y: 2010, f: '마일 챔피언십 우승' },
    { n: '타워 오브 런던', co: coat('bay', 1, 0), s: 2, sp: 9, en: 5, ac: 9, a: 'AGABFG', hv: 1, y: 2010, f: '스프린터즈S 레코드' },
    { n: '모즈 슈퍼플레어', co: coat('bay', 1, 1), s: 0, sp: 9, en: 5, ac: 9, a: 'AGAEGG', hv: 2, y: 2010, f: '불량 주로 다카마쓰노미야 도주' },
    { n: '다논 스매시', co: coat('bay', 0, 0), s: 1, sp: 9, en: 5, ac: 10, a: 'AGABFG', hv: 1, y: 2010, f: '홍콩 스프린트·다카마쓰노미야 기념' },
    { n: '슈넬마이스터', co: coat('bay', 1, 0), s: 2, sp: 9, en: 6, ac: 9, a: 'AGCAEF', hv: 1, y: 2020, f: 'NHK 마일컵 우승' },
    { n: '송라인', co: coat('bay', 1, 1), s: 1, sp: 9, en: 6, ac: 10, a: 'AGCAEF', hv: 1, y: 2020, f: '야스다 기념 2연패' },
    { n: '세리포스', co: coat('bay', 0, 1), s: 3, sp: 9, en: 6, ac: 9, a: 'AGCAEF', hv: 1, y: 2020, f: '마일 챔피언십 우승' },
    { n: '나무르', co: coat('bay', 1, 0), s: 3, sp: 9, en: 6, ac: 9, a: 'AGCAEF', hv: 1, y: 2020, f: '마일 챔피언십 추입' },
    { n: '마마 코차', co: coat('bay', 1, 1), s: 1, sp: 9, en: 5, ac: 9, a: 'AGACFG', hv: 1, y: 2020, f: '스프린터즈S 우승' },
    { n: '루가르', co: coat('bay', 0, 0), s: 1, sp: 9, en: 5, ac: 9, a: 'AGACFG', hv: 1, y: 2020, f: '스프린터즈S 대승' },
    { n: '매드 쿨', co: coat('chs', 1, 0), s: 1, sp: 9, en: 5, ac: 9, a: 'BBACFG', hv: 2, y: 2020, f: '무거운 주로 다카마쓰노미야 기념' },
    // 더트
    { n: '신코 윈디', co: coat('bay', 0, 1), s: 1, sp: 8, en: 7, ac: 8, a: 'GAEAAD', hv: 1, y: 1990, f: '첫 더트 G1 페브러리S 우승' },
    { n: '라이브리 마운트', co: coat('chs', 1, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'EACAAC', hv: 2, y: 1990, f: '더트 교류 중상 6연승' },
    { n: '메이세이 오페라', co: coat('bay', 1, 1), s: 2, sp: 8, en: 7, ac: 8, a: 'FACAAD', hv: 1, y: 1990, f: '지방마 최초 중앙 G1(페브러리S) 우승' },
    { n: '아그네스 디지털', co: coat('chs', 1, 1), s: 2, sp: 9, en: 8, ac: 9, a: 'AABAAD', hv: 1, y: 2000, f: '잔디·더트를 가리지 않은 G1 여섯 번' },
    { n: '이글 카페', co: coat('chs', 1, 0), s: 1, sp: 9, en: 8, ac: 8, a: 'BACAAD', hv: 1, y: 2000, f: 'NHK 마일컵(잔디)·재팬컵 더트 우승' },
    { n: '스타 킹 맨', co: coat('chs', 0, 1), s: 3, sp: 8, en: 8, ac: 7, a: 'FADBAC', hv: 1, y: 2000, f: '재팬컵 더트 추입 우승' },
    { n: '버밀리언', co: coat('bay', 1, 0), s: 1, sp: 8, en: 9, ac: 8, a: 'GAEBAB', hv: 1, y: 2000, f: '재팬컵 더트·제왕상 · 더트 G1 아홉 번' },
    { n: '블루 콘코드', co: coat('bay', 1, 1), s: 2, sp: 9, en: 7, ac: 9, a: 'GABAEF', hv: 2, y: 2000, f: '더트 마일 교류 G1 일곱 번' },
    { n: '프리오소', co: coat('chs', 1, 0), s: 2, sp: 8, en: 9, ac: 8, a: 'GAEBAB', hv: 1, y: 2000, f: '지방 출신 · 더트 교류 G1 여섯 번' },
    { n: '석세스 브로켄', co: coat('bay', 0, 0), s: 1, sp: 8, en: 8, ac: 8, a: 'GADAAC', hv: 1, y: 2000, f: '페브러리S·도쿄 대상전' },
    { n: '테스타 마타', co: coat('bay', 1, 1), s: 3, sp: 9, en: 6, ac: 8, a: 'GABADF', hv: 1, y: 2010, f: '페브러리S 우승' },
    { n: '그레이프 브랜디', co: coat('bay', 1, 0), s: 1, sp: 8, en: 9, ac: 7, a: 'GAEBAB', hv: 1, y: 2010, f: '재팬 더트 더비·페브러리S' },
    { n: '사운드 트루', co: coat('chs', 1, 1), s: 3, sp: 8, en: 8, ac: 8, a: 'GAEBAB', hv: 1, y: 2010, f: '챔피언스컵 추입' },
    { n: '논코노 유메', co: coat('chs', 1, 0), s: 3, sp: 9, en: 6, ac: 9, a: 'EAABDF', hv: 1, y: 2010, f: '페브러리S 추입' },
    { n: '르 방 스 레브', co: coat('bay', 1, 1), s: 2, sp: 9, en: 8, ac: 8, a: 'GAEBAC', hv: 1, y: 2010, f: '재팬 더트 더비·챔피언스컵' },
    { n: '인티', co: coat('chs', 0, 0), s: 0, sp: 9, en: 7, ac: 7, a: 'GADAAD', hv: 1, y: 2010, f: '페브러리S 도주' },
    { n: '모즈 애스콧', co: coat('chs', 1, 0), s: 2, sp: 9, en: 7, ac: 9, a: 'BAAADF', hv: 1, y: 2010, f: '잔디 야스다 기념·더트 페브러리S' },
    { n: '카페 파라오', co: coat('dbay', 0, 1), s: 1, sp: 9, en: 7, ac: 9, a: 'CAEADF', hv: 1, y: 2020, f: '페브러리S 2연패' },
    { n: '준라이트 볼트', co: coat('bay', 1, 0), s: 2, sp: 8, en: 8, ac: 8, a: 'GADAAC', hv: 1, y: 2020, f: '챔피언스컵 우승' },
    { n: '메이쇼 하리오', co: coat('bay', 1, 1), s: 2, sp: 8, en: 8, ac: 8, a: 'GAEBAB', hv: 1, y: 2020, f: '제왕상 2연패' },
    { n: '포에버 영', co: coat('bay', 1, 0), s: 1, sp: 9, en: 9, ac: 8, a: 'GAEBAB', hv: 1, y: 2020, f: '사우디컵·브리더스컵 클래식 제패' },
  ];
  // 활약 시기(데뷔 무렵, 10년 단위) — 앞의 40두
  [2000, 2010, 2010, 2010, 2020, 2010, 1990, 1980, 1990, 1990, 1990, 1980, 1990, 1990, 1990, 2000, 2000, 1990, 2020, 2000,
    1990, 2010, 1990, 2010, 2010, 1990, 1990, 2000, 1990, 1990, 1990, 2010, 2000, 2010, 2010, 2000, 2010, 2000, 2000, 2010].forEach((y, i) => { if (!HORSES[i].y) HORSES[i].y = y; });
  const GL = 'GFEDCBA', GRD = (c) => Math.max(0, GL.indexOf(c)); // A=6 … G=0
  const aptOf = (id) => Array.from((HORSES[id] || HORSES[0]).a, GRD); // [잔디, 더트, 단, 마, 중, 장]
  const STY = [
    { n: '도주', d: '처음부터 선두로 달아나요' },
    { n: '선행', d: '앞쪽에서 중반이 탄탄해요' },
    { n: '차분', d: '중단에서 체력을 아껴요' },
    { n: '추입', d: '막판 스퍼트가 가장 매서워요' },
  ];
  const CT = [
    { n: '평지', d: '장애물 없는 주로' },
    { n: '장애물', d: '생울타리를 뛰어넘어요(잔디)' },
  ];
  const SF = ['잔디', '더트'];
  const WX = [{ n: '맑음', i: '☀️', g: '양호' }, { n: '흐림', i: '☁️', g: '약간 무거움' }, { n: '비', i: '🌧️', g: '무거움' }, { n: '폭우', i: '⛈️', g: '불량' }];
  // track by surface × going: speed and stamina use (real Japanese dirt gets a little faster when wet)
  const TK = [[[1, 1], [0.987, 1.05], [0.972, 1.11], [0.955, 1.19]], [[0.985, 1.04], [0.99, 1.06], [0.992, 1.1], [0.98, 1.17]]];
  const GR = (g) => GL[g] || 'G';
  const LENS = [800, 1200, 1600, 2000, 2400];
  const DB = ['단거리', '마일', '중거리', '장거리'], DBS = ['단', '마', '중', '장'];
  const dBand = (ln) => (ln <= 1400 ? 0 : ln <= 1800 ? 1 : ln <= 2200 ? 2 : 3);
  const CND = ['부진', '보통', '호조'];
  const MIN_G = 4; // C
  /* can horse id run this race? '' = yes, otherwise the reason */
  function inelig(id, ln, sf) {
    const A = aptOf(id), g1 = A[sf ? 1 : 0], g2 = A[2 + dBand(ln)], r = [];
    if (g1 < MIN_G) r.push(SF[sf ? 1 : 0] + ' ' + GR(g1));
    if (g2 < MIN_G) r.push(DB[dBand(ln)] + ' ' + GR(g2));
    return r.join(' · ');
  }
  const elig = (id, ln, sf) => !inelig(id, ln, sf);
  // grade → speed ×, stamina use × (출전은 C 이상만이지만 G까지 정의)
  const GSP = [0.93, 0.945, 0.958, 0.97, 0.98, 0.99, 1], GDR = [1.3, 1.24, 1.18, 1.12, 1.07, 1.03, 1];
  /* aptitude of roster horse id for a race: [speed ×, stamina use ×] */
  function aptMul(id, ln, sf, gw, cnd, ct) {
    const H0 = HORSES[id] || HORSES[0], A = aptOf(id), gs = A[sf ? 1 : 0], gd = A[2 + dBand(ln)];
    let sp = GSP[gs] * (1 - (1 - GSP[gd]) * 1.1), dr = GDR[gd] * (1 + (GDR[gs] - 1) * 0.4);
    const pen = [0, 0.007, 0.014, 0.024][gw] * [1.5, 1, 0.45][H0.hv];
    sp *= 1 - pen;
    if (H0.hv === 0) dr *= 1 + 0.04 * gw;
    if (ct === 1 && H0.j) { sp *= 1.012; dr *= 0.95; } // 장애물 전문
    sp *= 1 + 0.01 * ((cnd | 0) - 1);
    return [sp, dr];
  }
  /* 오늘 종합: ◎ 딱 맞음 ○ 좋음 △ 보통 ▽ 불리(출전은 가능). ✕는 「출전 불가」에만 쓴다 — 예전엔 C·C 말이 ✕로 떠서 출전 불가처럼 보였다 */
  function aptMark(id, ln, sf, gw) { if (!elig(id, ln, sf)) return '✕'; const m = aptMul(id, ln, sf, gw, 1)[0]; return m >= 0.995 ? '◎' : m >= 0.98 ? '○' : m >= 0.965 ? '△' : '▽'; }
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  function prng(seed) {
    let a = seed >>> 0;
    return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * Math.random()); }

  /* ----- 실제 경마장(대략적인 실측): d 1 좌회전 / −1 우회전, 잔디 한 바퀴 cc·마지막 직선 st, 더트 dcc·dst,
     hl 고저 [결승선까지 남은 m, 높이 m] (결승선 쪽으로 갈수록), f 특징 한 줄 ----- */
  const VN = [
    { n: '도쿄', d: 1, cc: 2083, st: 526, dcc: 1899, dst: 501, hl: [[1500, 2], [1000, 0], [460, 0], [300, 2], [0, 2]], f: '긴 직선 · 결승 앞 오르막 — 추입마도 닿는 넓은 코스' },
    { n: '나카야마', d: -1, cc: 1840, st: 310, dcc: 1493, dst: 308, hl: [[1500, 2.2], [800, 0.6], [180, 0], [70, 2.2], [0, 2.2]], f: '짧은 직선 끝 급한 오르막 — 앞쪽에서 버티는 말이 유리' },
    { n: '교토', d: -1, cc: 1894, st: 404, dcc: 1608, dst: 329, hl: [[1300, 0], [900, 4.3], [600, 0], [0, 0]], f: '3코너 언덕을 오르고 내려가 평탄한 직선으로' },
    { n: '한신', d: -1, cc: 2089, st: 474, dcc: 1517, dst: 353, hl: [[1200, 1.8], [700, 0], [200, 0], [80, 1.8], [0, 1.8]], f: '넓은 외회전 코스 · 마지막에 짧은 급경사' },
    { n: '삿포로', d: -1, cc: 1641, st: 266, dcc: 1487, dst: 264, hl: [], f: '평탄하고 둥근 코스 · 직선이 짧아 선행 유리' },
    { n: '하코다테', d: -1, cc: 1627, st: 262, dcc: 1476, dst: 260, hl: [[1000, 0], [600, 3.5], [0, 0]], f: '가장 짧은 직선 · 내리막으로 들어오는 선행 천국' },
    { n: '후쿠시마', d: -1, cc: 1600, st: 292, dcc: 1445, dst: 296, hl: [[1000, 1.2], [600, 0], [250, 0], [150, 1.2], [0, 1.2]], f: '작은 코스 · 코너가 많아 안쪽이 유리' },
    { n: '니가타', d: 1, cc: 2223, st: 659, dcc: 1472, dst: 354, hl: [], f: '일본에서 가장 긴 직선 659m · 평탄 — 추입마의 무대' },
    { n: '주쿄', d: 1, cc: 1706, st: 413, dcc: 1530, dst: 411, hl: [[1300, 2], [800, 0], [380, 0], [240, 2], [0, 2]], f: '직선 들머리 급경사 · 힘과 끈기 승부' },
    { n: '고쿠라', d: -1, cc: 1615, st: 293, dcc: 1445, dst: 291, hl: [[1200, 0], [800, 3], [0, 0]], f: '내리막으로 속도가 붙는 평탄한 직선 · 선행 유리' },
  ];
  /* JRA G1 (경마장·주로·거리는 실제와 같음, 달력 순서). 암말·2세 한정 경주는 뺐어요. GP: 팬 투표 그랑프리 */
  const G1 = [
    ['페브러리 스테이크스', 0, 1, 1600, 16], ['다카마쓰노미야 기념', 8, 0, 1200, 18], ['오사카배', 3, 0, 2000, 16], ['사츠키상', 1, 0, 2000, 18],
    ['텐노상(봄)', 2, 0, 3200, 18], ['NHK 마일컵', 0, 0, 1600, 18], ['일본 더비', 0, 0, 2400, 18], ['야스다 기념', 0, 0, 1600, 18],
    ['다카라즈카 기념', 3, 0, 2200, 18], ['스프린터즈 스테이크스', 1, 0, 1200, 16], ['기쿠카상', 2, 0, 3000, 18], ['텐노상(가을)', 0, 0, 2000, 18],
    ['마일 챔피언십', 2, 0, 1600, 18], ['재팬컵', 0, 0, 2400, 18], ['챔피언스컵', 8, 1, 1800, 16], ['아리마 기념', 1, 0, 2500, 16],
  ];
  const ARIMA = 15;
  /* 풀게이트(정원): G1은 위 표(실제 정원), 일반 경주는 실제 경마장·주로의 최대 정원(잔디: 도쿄·교토·한신·니가타·주쿄·고쿠라 18,
     나카야마 16(2000m 18), 삿포로·하코다테·후쿠시마 16 / 더트: 중앙 4곳·주쿄·고쿠라 16, 후쿠시마·니가타 15, 삿포로·하코다테 14).
     장애물 14(나카야마 16) · 800m(직선 스프린트, 니가타 1000m 직선처럼) 16 */
  const GATE_T = [18, 16, 18, 18, 16, 16, 16, 18, 18, 18], GATE_D = [16, 16, 16, 16, 14, 14, 15, 15, 16, 16];
  function gateCap(vn, sf, ln, ct, g1) {
    if (g1 >= 0 && G1[g1]) return G1[g1][4];
    if (ct === 1) return (vn | 0) === 1 ? 16 : 14;
    if (ln <= 800) return 16;
    let c = (sf ? GATE_D : GATE_T)[vn | 0] || 16;
    if ((vn | 0) === 1 && !sf && ln === 2000) c = 18;
    return c;
  }
  /* 기수(틀) 색: 실제처럼 1 흰 · 2 검정 · 3 빨강 · 4 파랑 · 5 노랑 · 6 초록 · 7 주황 · 8 분홍, 9두 이상이면 바깥 틀부터 2~3두씩 */
  const WAKU = ['#f4f1ea', '#2b2b2b', '#d8433a', '#3b6fd8', '#e8c43a', '#3e9a52', '#ee8a2e', '#ef8fb4'];
  function wakuOf(g, N) {
    if (N <= 8) return g;
    const base = Math.floor(N / 8), ex = N % 8; let k = 0;
    for (let w = 0; w < 8; w++) { const c = base + (w >= 8 - ex ? 1 : 0); if (g < k + c) return w; k += c; }
    return 7;
  }
  /* how a venue tilts the styles: short straight → front-runners, long straight → closers (→ 신문·규칙 안내용 문구도 여기서) */
  const vnBias = (vn, sf) => { const v = VN[vn] || VN[0], s = sf ? v.dst : v.st; return s <= 300 ? -1 : s >= 450 ? 1 : 0; };
  /* ----- course: real oval of the venue (home straight, turn, back straight, turn …) ending at the finish line.
     Centreline = inner rail; C.sg = +1 left-handed, −1 right-handed (lanes are offset to the outside) ----- */
  const CC = {};
  function genCourse(ln, ct, sd, NL, gw, vn, sf) {
    gw = gw | 0; vn = clamp(vn | 0, 0, VN.length - 1);
    const key = ln + '.' + ct + '.' + sd + '.' + NL + '.' + gw + '.' + vn + '.' + (sf | 0);
    if (CC[key]) return CC[key];
    const rnd = prng(sd), V = VN[vn];
    const cc = sf ? V.dcc : V.cc, stL = sf ? V.dst : V.st, rad = Math.max(60, (cc - 2 * stL) / (2 * Math.PI));
    const FS = Math.round(Math.min(stL, ln * 0.45)), pre = ln - FS;
    // walk backwards from the finish: home straight (stL), turn (π·r), back straight (stL), turn …
    const back = []; let rem = ln, k = 0;
    while (rem > 0) {
      const isT = k % 2 === 1, full = isT ? Math.round(Math.PI * rad) : stL, l = Math.min(rem, full);
      back.push({ l, k: isT ? 1 / rad : 0 }); rem -= l; k++;
    }
    const segs = []; let p = 0;
    for (let i = back.length - 1; i >= 0; i--) { segs.push({ a: p, l: back[i].l, k: back[i].k }); p += back[i].l; }
    segs[segs.length - 1].l += 80; // run-out past the post
    const sg = V.d;
    const N = ln + 80, X = new Float32Array(N + 1), Y = new Float32Array(N + 1), Hd = new Float32Array(N + 1), K = new Float32Array(N + 1), E = new Float32Array(N + 1), CK = new Float32Array(N + 2);
    let x = 0, y = 0, h = -Math.PI / 2, si = 0;
    for (let i = 0; i <= N; i++) {
      while (si < segs.length - 1 && i >= segs[si].a + segs[si].l) si++;
      const kk = segs[si].k;
      X[i] = x; Y[i] = y; Hd[i] = h; K[i] = kk; CK[i + 1] = CK[i] + kk;
      h -= kk * sg; x += Math.cos(h + kk * sg / 2); y += Math.sin(h + kk * sg / 2);
      // elevation: piecewise-linear profile by distance to the post (wraps every lap)
      const hl = V.hl; let e = 0;
      if (hl.length) {
        const dd = ((ln - i) % cc + cc) % cc;
        if (dd >= hl[0][0]) e = hl[0][1];
        else for (let j = 1; j < hl.length; j++) if (dd >= hl[j][0]) { const a = hl[j - 1], b = hl[j]; e = b[1] + (a[1] - b[1]) * (dd - b[0]) / (a[0] - b[0]); break; }
      }
      E[i] = e;
    }
    const obs = [], mud = [];
    if (ct === 1) {
      const m = Math.round(ln / 400) + 1;
      for (let i = 0; i < m; i++) obs.push(Math.round(ln * (0.1 + 0.68 * (i + 0.5) / m + (rnd() - 0.5) * 0.5 * 0.68 / m)));
    }
    if (gw >= 2) { // heavy going: puddles / boggy patches
      const m = Math.round(ln / (gw === 3 ? 300 : 500)) + 1;
      for (let i = 0; i < m; i++) {
        const x0 = Math.round(ln * (0.07 + 0.8 * (i + rnd() * 0.6) / m)), kk = 2 + Math.floor(rnd() * Math.max(1, NL - 3));
        const inner = rnd() < 0.55;
        mud.push({ x: x0, l: 25 + Math.round(rnd() * 35), l0: inner ? -1 : kk - 0.5, l1: inner ? kk - 0.5 : NL + 1 });
      }
    }
    const C = { ln, ct, NL, FS, spS: ln - Math.round(FS * 0.85), segs, X, Y, Hd, K, N, obs, mud, sg, E, CK, vn, cc, stL, pre };
    const ks = Object.keys(CC); if (ks.length > 6) delete CC[ks[0]];
    CC[key] = C;
    return C;
  }
  function curvAt(C, p) { const i = clamp(Math.floor(p), 0, C.N); return C.K[i]; }
  function posAt(C, p, off) { // world x, y, heading at distance p with outward offset off (m)
    const i = clamp(Math.floor(p), 0, C.N - 1), f = clamp(p - i, 0, 1);
    const x = C.X[i] + (C.X[i + 1] - C.X[i]) * f, y = C.Y[i] + (C.Y[i + 1] - C.Y[i]) * f, h = C.Hd[i] + (C.Hd[i + 1] - C.Hd[i]) * f;
    off *= C.sg || 1;
    return [x - Math.sin(h) * off, y + Math.cos(h) * off, h];
  }
  const slopeAt = (C, p) => { const i = clamp(Math.floor(p), 0, C.N - 1); return C.E ? C.E[i + 1] - C.E[i] : 0; };
  /* extra metres still to run on the turns from p to the post when holding offset off (바깥 손해) */
  const turnLoss = (C, p, off) => { const a = clamp(Math.floor(p), 0, C.ln), b = C.ln; return C.CK ? (C.CK[b] - C.CK[a]) * off : 0; };
  const laneOff = (l) => 0.7 + l * LW;

  /* ----- race ----- */
  // fh = [horse id, condition 0..2, spd, end, acc, sty, gate] per seat (stats 1..10); o.wx weather = going 0..3, o.sf surface
  function newRace(o) {
    const n = o.fh.length, NL = Math.min(19, Math.max(4, n + 1, ...o.fh.map((f) => (f[6] | 0) + 1))), gw = o.wx | 0, sf = o.sf | 0;
    const C = genCourse(o.ln, o.ct, o.sd, NL, gw, o.vn, sf);
    const tk = TK[sf][gw], ap = o.fh.map((f) => aptMul(f[0], o.ln, sf, gw, f[1], o.ct));
    const V0 = 19 * Math.pow(o.ln / 800, 0.4);
    const hs = o.fh.map((f) => ({ p: 0, l: f[6], tl: f[6], v: 0, sta: 100, push: 0, ft: -1, ob: 0, jr: '', jx: -99, st: 0, bt: 0, ba: 0,
      blk: 0, dr: 0, mud: 0, sp0: -1, mp: 0, mt: -9, mx: 0, kW: 0, kJ: 0, kC: 0, kB: 0, oc: ORD_N, om: '', ot: 0, ox: 0, kO: 0 }));
    return { C, n, NL, V0, vb: vnBias(o.vn | 0, sf), fh: o.fh, tk, ap, gw, sf, t: 0, ord: o.fh.map((_, i) => i), rk: o.fh.map(() => 0), callT: 0, f200: 0, hs, ev: [], evId: 0, lead: -1, leadT: 0, firstFt: -1, sprAnn: 0, tight: 0, slow: 0 };
  }
  function pushEv(R, type, seat, hooks) {
    R.evId = (R.evId + 1) % 100000;
    R.ev.push([R.evId, type, seat]); if (R.ev.length > 4) R.ev.shift();
    if (hooks && hooks.ev) hooks.ev(type, seat);
  }
  const inSpurt = (R, h) => h.p >= R.C.spS;
  function fenceTT(R, i) { // seconds until horse i reaches its next unresolved fence, or −1
    const h = R.hs[i], x = R.C.obs[h.ob];
    if (x == null || h.jr || h.ft >= 0) return -1;
    const d = x - h.p; if (d < -1) return -1;
    return Math.max(0, d) / Math.max(h.v, 5);
  }
  function resolveJump(R, i, q, hooks) { // q: P perfect, G clean, C crash
    const h = R.hs[i], x = R.C.obs[h.ob];
    if (x == null || h.jr) return false;
    h.jr = q; h.jx = x;
    if (q === 'P') { h.bt = 0.8; h.ba = 0.05; h.kJ++; }
    else if (q === 'G') h.kJ++;
    else { h.st = 0.9; h.v *= 0.55; h.sta = Math.max(0, h.sta - 6); h.kC++; }
    pushEv(R, q === 'C' ? 'crash' : 'jump', i, hooks);
    return true;
  }
  function judgeJump(tt) { return tt < 0 || tt > JW ? '' : tt >= 0.08 && tt <= 0.34 ? 'P' : 'G'; }
  /* 라스트 스퍼트 연타: 탭마다 스퍼트 힘(mp 0~100)이 차고, 손을 놓으면 빠르게 식는다(초당 MD 비율).
     남은 체력이 적을수록 한 번에 차는 양이 줄어든다. 사람·AI 모두 같은 규칙, 탭 간격 최소 MT초(초당 약 13번 상한).
     최고 속도 보너스 MSP(+9%) — 예전 박자 채찍 만점과 같은 수준 */
  const MG = 15, MD = 1.15, MT = 0.075, MSP = 0.09, MCOST = 0.15;
  const mashGain = (h) => MG * (0.3 + 0.7 * clamp(h.sta / 100, 0, 1));
  function applyMash(R, i, hooks, force) {
    const h = R.hs[i]; if (!h || h.ft >= 0 || !inSpurt(R, h)) return false;
    if (!force && R.t - (h.mt == null ? -9 : h.mt) < MT) return false;
    h.mt = R.t; h.mp = Math.min(100, (h.mp || 0) + mashGain(h)); h.sta = Math.max(0, h.sta - MCOST); h.kW++;
    if (h.mp >= 95 && !h.mx) { h.mx = 1; if (!R.mAnn && R.lead !== i) { R.mAnn = 1; pushEv(R, 'mash', i, hooks); } }
    if (hooks && hooks.whip) hooks.whip(i, h.mp);
    return true;
  }
  /* a fresh press from a local person / AI: jump at a fence, whip in the spurt */
  function pressAt(R, i, hooks) {
    const h = R.hs[i]; if (!h || h.ft >= 0) return '';
    if (inSpurt(R, h)) {
      return applyMash(R, i, hooks) ? 'm' : '';
    }
    const q = judgeJump(fenceTT(R, i));
    if (q) { resolveJump(R, i, q, hooks); return 'j' + q; }
    return '';
  }
  function styleMul(sty, frac, sp) {
    if (sty === 0) return frac < 0.45 ? 1.048 : sp ? 0.992 : 1;
    if (sty === 1) return sp ? 1.03 : frac < 0.65 ? 1.024 : 1;
    if (sty === 2) return sp ? 1.038 : 1;
    return frac < 0.5 ? 0.984 : sp ? 1.095 : 1;
  }
  // stamina used per metre (× 100/ln) by mode
  const DR = { push: 2.1, cruise: 0.25, spurt: 2.6 };
  function drainPm(R, i, mode) {
    const f = R.fh[i], h = R.hs[i];
    return 100 / R.C.ln * DR[mode] * (1 + (6.5 - f[3]) * 0.017 * R.C.ln / 1600) * (f[5] === 2 ? 0.94 : 1) * R.tk[1] * (R.ap ? R.ap[i][1] : 1) * (h && h.dr ? 0.65 : 1);
  }
  function inMud(C, p, l) { for (const m of C.mud) if (p >= m.x && p <= m.x + m.l && l > m.l0 && l < m.l1) return true; return false; }
  function aheadOf(R, i, gapMax) { // nearest horse in front in roughly the same lane
    const h = R.hs[i]; let best = -1, bg = 1e9;
    for (let j = 0; j < R.n; j++) {
      if (j === i) continue; const q = R.hs[j];
      if (Math.abs(q.l - h.l) > 0.75) continue;
      const g = q.p - h.p; if (g > 0 && g < gapMax && g < bg) { bg = g; best = j; }
    }
    return best < 0 ? null : [best, bg];
  }
  function laneFree(R, i, l) {
    const h = R.hs[i];
    for (let j = 0; j < R.n; j++) { if (j === i) continue; const q = R.hs[j]; if (q.ft >= 0) continue; if (Math.abs(q.l - l) < 0.7 && Math.abs(q.p - h.p) < BODY * 0.95) return false; }
    return true;
  }
  function setLane(R, i, d) {
    const h = R.hs[i]; if (!h || h.ft >= 0) return false;
    const nl = clamp(Math.round(h.tl) + d, 0, R.NL - 1);
    if (nl === h.tl) return false;
    if (!laneFree(R, i, nl)) return false;
    h.tl = nl; return true;
  }
  /* rem[i] = true when seat i is controlled from another phone (its jump judgement arrives late) */
  /* 작전 지시 (경주마다 ORD_N번): g 앞으로 나가기(5초 · 더 빠르게, 체력 많이 소모 — 도주·선행이 더 잘 받음),
     s 힘 아끼기(6초 · 조금 느리게, 체력 회복 — 차분·추입이 더 잘 회복, 스퍼트 중엔 못 씀),
     o 바깥으로 빠지기(앞이 트인 가장 가까운 바깥 줄로 진로 확보 — 코너면 거리 손해). '' = 지시됨, 아니면 못 하는 이유 */
  const ORD_N = 3, ORD = { g: 5, s: 6 };
  function outLane(R, i) {
    const h = R.hs[i], l0 = Math.round(h.l);
    for (let l = l0 + 1; l < R.NL; l++) {
      if (!laneFree(R, i, l)) continue;
      if (R.hs.some((q, j) => j !== i && q.ft < 0 && Math.abs(q.l - l) < 0.75 && q.p - h.p > -0.5 && q.p - h.p < 9)) continue;
      return l;
    }
    return -1;
  }
  function issueOrder(R, i, t, hooks) {
    const h = R.hs[i]; if (!h || h.ft >= 0) return '골인';
    if (!(h.oc > 0)) return '지시를 다 썼어요';
    if (t === 's' && inSpurt(R, h)) return '스퍼트 중엔 못 아껴요';
    if (t === 'o') {
      const l = outLane(R, i); if (l < 0) return '바깥도 막혔어요';
      h.tl = l; h.ox = 1.8;
    } else if (t === 'g' || t === 's') { h.om = t; h.ot = ORD[t]; }
    else return '?';
    h.oc--; h.kO++;
    if (hooks && hooks.order) hooks.order(i, t);
    return '';
  }
  function stepRace(R, dt, hooks, rem) {
    R.t += dt;
    const C = R.C;
    let lp = -1, leader = -1;
    for (let i = 0; i < R.n; i++) { const h = R.hs[i]; if (h.ft < 0 && h.p > lp) { lp = h.p; leader = i; } }
    const ord = R.hs.map((h, i) => i).sort((a, b) => R.hs[b].p - R.hs[a].p);
    for (const i of ord) {
      const h = R.hs[i], f = R.fh[i];
      if (h.ft >= 0) { h.v += (8 - h.v) * Math.min(1, 1.2 * dt); h.p += h.v * dt; continue; }
      if (h.st > 0) h.st -= dt;
      if (h.bt > 0) h.bt -= dt;
      if (h.mp > 0) h.mp = h.mp < 0.5 ? 0 : h.mp * Math.exp(-MD * dt);
      if (h.ot > 0) { h.ot -= dt; if (h.ot <= 0) { h.ot = 0; h.om = ''; } }
      if (h.ox > 0) h.ox -= dt;
      const frac = h.p / C.ln, sp = inSpurt(R, h);
      if (sp && h.sp0 < 0) { h.sp0 = R.t; if (!R.sprAnn) { R.sprAnn = 1; pushEv(R, 'spurt', i, hooks); } }
      // lane drift (blocked if somebody is alongside)
      if (Math.abs(h.tl - h.l) > 0.01) {
        const dir = Math.sign(h.tl - h.l), nl = h.l + dir * Math.min(Math.abs(h.tl - h.l), 3 * dt);
        let ok = true;
        for (let j = 0; j < R.n; j++) { if (j === i) continue; const q = R.hs[j]; if (q.ft >= 0) continue; if (Math.abs(q.l - nl) < 0.72 && Math.abs(q.l - h.l) >= 0.72 - 1e-6 && Math.abs(q.p - h.p) < BODY * 0.9) { ok = false; break; } }
        if (ok) h.l = nl; else if (!(h.ox > 0)) h.tl = Math.round(h.l);
      }
      const ah = aheadOf(R, i, 7);
      h.dr = ah && ah[1] > 1.6 && !sp ? 1 : 0;
      h.mud = C.mud.length && inMud(C, h.p, h.l) ? 1 : 0;
      const om = h.om, pushing = om === 'g' || (om !== 's' && h.push);
      const mode = sp ? 'spurt' : pushing ? 'push' : 'cruise';
      let tv = R.V0 * (1 + 0.0055 * (f[2] - 5.5) * Math.pow(1600 / R.C.ln, 0.3)) * styleMul(f[5], frac, sp) * R.tk[0] * R.ap[i][0] * (C.ct === 1 ? 0.985 : 1) * (sp ? 1.06 : pushing ? 1 : om === 's' ? 0.86 : 0.88);
      if (R.vb) tv *= R.vb < 0 ? (f[5] <= 1 ? (sp ? 1 : 1.008) : f[5] === 3 && sp ? 0.99 : 1) : (f[5] === 3 && sp ? 1.012 : f[5] === 0 ? 0.995 : 1);
      if (om === 'g') tv *= sp ? 1.03 : 1.035 + (f[5] <= 1 ? 0.01 : 0);
      // hills: uphill slows (less for stayers) and burns stamina, downhill lets them run
      const sl = slopeAt(C, h.p);
      if (sl > 0) tv *= 1 - sl * 3.2 * (1.25 - 0.05 * f[3]); else if (sl < 0) tv *= 1 - sl * 1.6;
      if (h.dr) tv *= 1.015;
      if (h.bt > 0) tv *= 1 + h.ba;
      if (sp && h.mp > 0) tv *= 1 + MSP * h.mp / 100;
      if (h.st > 0) tv *= 0.6;
      if (h.mud) tv *= 0.88;
      if (h.sta < 15) tv *= 0.74 + 0.26 * h.sta / 15;
      const a = tv > h.v ? 0.55 + 0.06 * f[4] : 1.4;
      h.v += (tv - h.v) * Math.min(1, a * dt);
      h.blk = 0;
      if (ah && ah[1] < BODY + 0.3) { const q = R.hs[ah[0]]; if (q.ft < 0 && h.v > q.v) { h.v = q.v; h.blk = 1; h.kB += dt; } }
      const k = curvAt(C, h.p), off = laneOff(h.l);
      const dp = h.v * dt * (k > 0 ? 1 / (1 + off * k) : 1);
      h.sta = Math.max(0, h.sta - dp * drainPm(R, i, mode) * (h.mud ? 1.25 : 1) * (om === 'g' ? (sp ? 1.5 : 1.6) : 1) * (sl > 0 ? 1 + sl * 30 : 1));
      if (om === 's') h.sta = Math.min(100, h.sta + (f[5] >= 2 ? 1.3 : 1.0) * dt);
      if (Math.abs(h.tl - h.l) > 0.05) h.p -= dp * 0.012; // 옆으로 비키는 만큼 조금 손해
      const p0 = h.p; h.p += dp;
      const x = C.obs[h.ob];
      if (x != null) {
        if (h.jr) { if (h.p > x + 3) { h.ob++; h.jr = ''; } }
        else if (h.p >= x + (rem && rem[i] ? Math.max(2, h.v * 0.3) : 0)) resolveJump(R, i, 'C', hooks);
      }
      if (h.p >= C.ln) {
        h.ft = R.t - (h.p - C.ln) / Math.max(0.01, h.p - p0) * dt; h.fv = h.v;
        if (R.firstFt < 0) { R.firstFt = h.ft; pushEv(R, 'fin', i, hooks); }
        else if (R.hs.filter((q) => q.ft >= 0).length === 2 && h.ft - R.firstFt < 0.12) pushEv(R, 'photo', i, hooks);
        if (hooks && hooks.fin) hooks.fin(i);
      }
    }
    // slow motion trigger (view only): two horses inside the last 30 m within a length of each other
    R.slow = 0;
    if (R.firstFt < 0 && ord.length > 1) { const a = R.hs[ord[0]], b = R.hs[ord[1]]; if (C.ln - a.p < 28 && a.p - b.p < 1.6 && b.ft < 0) R.slow = 1; }
    if (!R.tight && R.firstFt < 0 && lp >= C.ln * 0.8 && R.n > 1) {
      const a = R.hs[ord[0]], b = R.hs[ord[1]];
      if (a.p - b.p < 1.5) { R.tight = 1; pushEv(R, 'tight', ord[1], hooks); }
    }
    if (R.firstFt < 0 && leader >= 0 && !R.f200 && lp >= C.ln - 200) { R.f200 = 1; pushEv(R, 'f200', leader, hooks); }
    if (R.firstFt < 0 && leader >= 0 && R.t - R.callT > 11 && lp < C.spS - 30) { R.callT = R.t; pushEv(R, 'call', leader, hooks); }
    if (leader >= 0 && leader !== R.lead) {
      if (R.lead >= 0 && R.t > 3 && R.t - R.leadT > 2.5) pushEv(R, 'lead', leader, hooks);
      R.lead = leader; R.leadT = R.t;
    }
  }
  function raceOver(R) {
    if (R.hs.every((h) => h.ft >= 0)) return true;
    if (R.firstFt >= 0 && R.t > R.firstFt + 10) return true;
    return R.t > R.C.ln / 8 + 60;
  }
  /* finishing order [[seat, centiseconds or −1, margin to the horse in front in 0.1 m], …] */
  function order(R) {
    const o = R.hs.map((h, i) => [i, h.ft, h.p]).sort((a, b) => {
      if (a[1] >= 0 && b[1] >= 0) return a[1] - b[1] || a[0] - b[0];
      if (a[1] >= 0) return -1; if (b[1] >= 0) return 1;
      return b[2] - a[2] || a[0] - b[0];
    });
    return o.map((x, k) => {
      let m = 0;
      if (k > 0) { const pv = o[k - 1]; m = x[1] >= 0 && pv[1] >= 0 ? (x[1] - pv[1]) * Math.max(8, R.hs[x[0]].fv || R.hs[x[0]].v) : Math.max(0, (pv[1] >= 0 ? R.C.ln : pv[2]) - x[2]); }
      return [x[0], x[1] >= 0 ? Math.round(x[1] * 100) : -1, Math.round(m * 10)];
    });
  }
  function marginTxt(m10) {
    const m = m10 / 10;
    if (m < 0.12) return '코 차이'; if (m < 0.35) return '머리 차이'; if (m < 0.8) return '목 차이';
    if (m < 1.5) return '반 마신'; if (m < 3) return '1마신'; if (m > 24) return '대차';
    return Math.round(m / BODY) + '마신';
  }

  /* ----- AI: pace plan by style, lanes, slipstream, fences, spurt mashing ----- */
  const AIC = {
    1: { plan: 0.8, ptoss: 0.08, lane: 0.75, rail: 0.5, draft: 0, jsd: 0.2, jmiss: 0.12, tap: 5.6, tsd: 0.25, rest: 0.1, mudSee: 0, react: 1.2 },
    2: { plan: 0.8, ptoss: 0.14, lane: 0.8, rail: 0.35, draft: 0.25, jsd: 0.1, jmiss: 0.03, tap: 6.6, tsd: 0.2, rest: 0.08, mudSee: 0.5, react: 0.8 },
    3: { plan: 1, ptoss: 0, lane: 1, rail: 1, draft: 1, jsd: 0.05, jmiss: 0.005, tap: 8.2, tsd: 0.12, rest: 0, mudSee: 1, react: 0.25 },
  };
  function aiStep(R, i, mem, lv, hooks) {
    const A = AIC[lv] || AIC[2], h = R.hs[i], C = R.C, f = R.fh[i];
    if (h.ft >= 0) return;
    const sp = inSpurt(R, h);
    // fences
    const tt = fenceTT(R, i);
    if (tt >= 0 && tt <= 1.2) {
      if (mem.jo !== h.ob) { mem.jo = h.ob; mem.jt = clamp(0.21 + gauss() * A.jsd, 0.0, JW + 0.15); mem.jm = Math.random() < A.jmiss; }
      if (!mem.jm && tt <= mem.jt) pressAt(R, i, hooks);
    }
    if (sp) {
      h.push = 1;
      // 연타: 난이도별 초당 탭 수(쉬움 ~5.6 · 보통 ~6.6 · 어려움 ~8.2), 쉬움·보통은 가끔 손이 멈춤
      if (mem.tn == null) mem.tn = R.t;
      if (mem.rs > R.t) { /* 잠깐 쉼 */ }
      else if (R.t >= mem.tn) {
        pressAt(R, i, hooks);
        mem.tn = R.t + Math.max(MT, (1 / A.tap) * (1 + gauss() * A.tsd));
        if (A.rest && Math.random() < A.rest * 0.05) mem.rs = R.t + 0.3 + Math.random() * 0.5;
      }
    }
    if (R.t < (mem.nt || 0)) return;
    mem.nt = R.t + A.react * (0.6 + Math.random() * 0.8);
    if (!sp) {
      // pace: keep enough stamina for the remaining cruise + the whole spurt
      if (mem.err == null) mem.err = lv >= 3 ? 0 : gauss() * 0.3;
      const need = (1 + mem.err) * (C.spS - h.p) * drainPm(R, i, 'cruise') + (C.ln - C.spS) * drainPm(R, i, 'spurt') * 1.05;
      const frac = h.p / C.ln;
      let reserve = lv >= 3 ? 4 : 10;
      if (f[5] === 0 && frac < 0.4) reserve -= 8;        // 선행: go early
      if (f[5] === 3 && frac < 0.55) reserve += 14;      // 추입: save for the end
      if (f[5] === 1 && frac > 0.3) reserve -= 3;
      const spare = h.sta - need - reserve;
      if (Math.random() < A.ptoss) h.push = Math.random() < 0.6 ? 1 : 0;
      else h.push = spare > 0 && Math.random() < A.plan ? 1 : 0;
      if (lv <= 1 && h.sta < 25) h.push = Math.random() < 0.12 ? 1 : 0;
    }
    // 작전 지시: lv1 is careless, lv3 uses them where they pay (style × stamina × traffic)
    if (h.oc > 0 && !h.om) {
      const frac = h.p / C.ln, ahd = aheadOf(R, i, 5);
      const boxed = ahd && ahd[1] < 3.5 && R.hs[ahd[0]].v <= h.v + 0.2 && frac > 0.5;
      const need = Math.max(0, C.spS - h.p) * drainPm(R, i, 'cruise') + (C.ln - Math.max(h.p, C.spS)) * drainPm(R, i, 'spurt');
      let t = '';
      if (lv <= 1) { if (Math.random() < 0.012) t = 'gso'[U.rand(3)]; }
      else {
        const sm = lv >= 3 ? 1 : 0.55;
        if (boxed && Math.random() < sm) t = 'o';
        else if (sp && h.sta > need * 1.35 + 8 && Math.random() < sm) t = 'g';
        else if (!sp && f[5] <= 1 && frac < 0.12 && h.sta > need + 30 && Math.random() < sm * 0.5) t = 'g';
        else if (!sp && f[5] >= 2 && frac > 0.3 && frac < 0.7 && Math.random() < sm * 0.35) t = 's';
        else if (!sp && frac > 0.4 && h.sta < need + 3 && Math.random() < sm) t = 's';
      }
      if (t) issueOrder(R, i, t, hooks);
    }
    if (Math.random() > A.lane) return;
    // lanes
    const ah = aheadOf(R, i, 6);
    const blocked = ah && ah[1] < 4 && R.hs[ah[0]].v <= h.v + 0.3 && (h.push || sp);
    const want = [];
    if (blocked) want.push(h.tl < R.NL - 1 ? 1 : -1, -1, 1);
    if (C.mud.length && Math.random() < A.mudSee) {
      for (let d = 5; d < 40; d += 5) if (inMud(C, h.p + d, h.tl)) { want.push(inMud(C, h.p + d, h.tl + 1) ? -1 : 1, -1); break; }
    }
    if (!want.length) {
      const k = curvAt(C, h.p + 25) || curvAt(C, h.p);
      if (A.draft > Math.random() && !sp && !ah) { // look for a horse to tuck in behind
        for (const d of [-1, 1]) { const l = h.tl + d; if (l < 0 || l >= R.NL) continue; if (R.hs.some((q, j) => j !== i && Math.abs(q.l - l) < 0.5 && q.p - h.p > 2.5 && q.p - h.p < 7)) { want.push(d); break; } }
      }
      if (!want.length && h.tl > 0 && (k > 0 || Math.random() < 0.3) && Math.random() < A.rail) want.push(-1);
    }
    for (const d of want) if (!(C.mud.length && inMud(C, h.p + 8, h.tl + d) && lv >= 2) && setLane(R, i, d)) break;
  }

  /* ======================= state (coarse, via api.setState / actions) ======================= */
  /* field: only horses whose surface AND distance aptitude are C or better for this race */
  const eligIds = (ln, sf) => HORSES.map((_, i) => i).filter((i) => elig(i, ln, sf));
  /* 출전마 m두를 뽑는다(ex 제외). 실제 출주표처럼 오늘 거리·주로가 잘 맞는 말이 더 자주, G1은 강한 말이 더 자주 나온다 */
  function genField(m, ln, sf, ex, g1) {
    const pool = eligIds(ln, sf).filter((i) => !(ex && ex.includes(i))), out = [];
    m = Math.min(m, pool.length);
    const wt = pool.map((i) => { const A = aptOf(i), H0 = HORSES[i], tot = H0.sp + H0.en + H0.ac;
      return (1 + (A[2 + dBand(ln)] - MIN_G) * 0.5 + (A[sf ? 1 : 0] - MIN_G) * 0.25) * (g1 ? clamp((tot - 19) / 5, 0.35, 1.8) : clamp((tot - 15) / 9, 0.5, 1.4)); });
    for (let i = 0; i < m; i++) {
      let t = 0; for (const w of wt) t += w;
      let r = Math.random() * t, j = 0; while (j < wt.length - 1 && (r -= wt[j]) > 0) j++;
      const id = pool[j], H0 = HORSES[id], c = Math.random(); pool.splice(j, 1); wt.splice(j, 1);
      out.push([id, c < 0.22 ? 0 : c < 0.78 ? 1 : 2, H0.sp, H0.en, H0.ac, H0.s, 0]);
    }
    const gates = U.shuffle(out.map((_, i) => i)); out.forEach((F, i) => { F[6] = gates[i]; });
    return out;
  }
  /* 출전 두수: go 0 실제 정원 · −1 참가자만(고를 말은 n+2두 중에서) · 8 / 12 */
  function gateCount(s) {
    const n = s.n, el = eligIds(s.ln, s.sf | 0).length;
    const g = s.go === -1 ? n : s.go > 0 ? s.go : gateCap(s.vn, s.sf | 0, s.ln, s.ct, g1Of(s));
    return Math.max(n, Math.min(g, el));
  }
  /* 고르기 후보 수: 정원보다 넉넉히(정원 + 8두, 최소 24두 — 그 경주에 나갈 수 있는 말이 그보다 적으면 전부).
     사람이 먼저 고르고 → AI 자리가 남은 후보에서 고르고 → 나머지 게이트는 남은 후보로 자동 출전마를 채운다 */
  const poolCount = (s) => { const el = eligIds(s.ln, s.sf | 0).length; return Math.max(Math.min(s.n, el), Math.min(el, s.go === -1 ? Math.max(14, s.n + 8) : Math.max(24, gateCount(s) + 8))); };
  /* 고르기가 끝나면: 고르지 않은 후보 중 앞쪽(출주표에 먼저 뽑힌 = 오늘 조건이 잘 맞는 말)부터 자동 출전마(bt, 정원까지).
     출전하지 않는 후보는 빼고, 출전마만 남겨 게이트를 1번부터 다시 매긴다(fld 번호 = 게이트) */
  function seatField(n) {
    const want = n.go === -1 ? 0 : Math.max(0, gateCount(n) - n.n);
    const bt = n.fld.map((_, k) => k).filter((k) => !n.hs.includes(k) && elig(n.fld[k][0], n.ln, n.sf | 0)).slice(0, want);
    const run = n.hs.concat(bt).filter((k) => k >= 0).sort((a, b) => n.fld[a][6] - n.fld[b][6]);
    const mp = {}; run.forEach((k, g) => { mp[k] = g; });
    const cn = {}; for (const k in n.cn || {}) if (mp[k] != null) cn[mp[k]] = n.cn[k];
    n.fld = run.map((k, g) => { const F = n.fld[k].slice(); F[6] = g; return F; });
    n.hs = n.hs.map((k) => (k >= 0 ? mp[k] : k)); n.bt = bt.map((k) => mp[k]); n.cn = cn;
    return n;
  }
  function fieldScore(F, s, lv) { // how good a horse looks to an AI
    const ln = s.ln, m = aptMul(F[0], ln, s.sf, s.wx, F[1], s.ct);
    let v = (F[2] * 1.3 + F[3] * (ln / 1200) * 0.8 + F[4] * 0.6) * (1 + (m[0] - 1) * 6) / (1 + (m[1] - 1) * 2);
    if (s.bo === SEASON && s.rd === 1) { const A = aptOf(F[0]); v += A.filter((g) => g >= MIN_G).length * 0.6; } // 시즌: 두루 뛰는 말이 일정이 넓다
    return v + (lv >= 3 ? 0 : (Math.random() - 0.5) * (lv <= 1 ? 30 : 4));
  }
  function aiPicks(s, lvs) {
    const n = Object.assign({}, s, { hs: s.hs.slice(), fld: s.fld.slice() });
    const free = () => n.fld.map((_, k) => k).filter((k) => !n.hs.includes(k) && elig(n.fld[k][0], n.ln, n.sf | 0));
    const seats = n.hs.map((x, i) => (x < 0 ? i : -1)).filter((i) => i >= 0);
    U.shuffle(seats).forEach((i) => {
      const lv = (lvs && lvs[i]) || 2;
      let fr = free().sort((a, b) => fieldScore(n.fld[b], n, lv) - fieldScore(n.fld[a], n, lv));
      if (!fr.length) { // 후보가 바닥나면(아주 드묾) 오늘 나갈 수 있는 다른 명마를 한 두 더 부른다
        const extra = genField(1, n.ln, n.sf | 0, n.fld.map((F) => F[0]), g1Of(n) >= 0 ? 1 : 0)[0];
        if (extra) { extra[6] = n.fld.length; n.fld.push(extra); fr = [n.fld.length - 1]; }
      }
      if (fr.length) n.hs[i] = fr[0];
    });
    if (n.bo === SEASON && n.sch && n.sch.length < SEASON) n.sch = n.sch.concat(planSeason(n.hs.map((k) => n.fld[k][0]), n.sch[0]));
    seatField(n);
    n.ph = 'count';
    return n;
  }
  /* 시즌: 5 races. Race 1 is drawn first (picks happen on it); races 2–5 are then planned so that EVERY horse in the
     season field is C or better on surface and distance. Race 5 is the 그랑프리 (longest turf race that suits all, ×2). */
  const SEASON = 5, GP = '그랑프리';
  const rndWx = () => [0, 0, 0, 1, 1, 2, 3][U.rand(7)];
  /* 시즌 = JRA G1 일정. sch 항목 = [거리, 0, 잔디0/더트1, 날씨, 경마장, G1 번호] */
  const g1Entry = (g) => [G1[g][3], 0, G1[g][2], rndWx(), G1[g][1], g];
  function firstSeasonRace(n) {
    for (let t = 0; t < 60; t++) {
      const g = U.rand(11);
      if (G1[g][2] && Math.random() < 0.6) continue; // 더트 개막은 드물게
      if (eligIds(G1[g][3], G1[g][2]).length >= n + 2) return g1Entry(g);
    }
    return g1Entry(3);
  }
  /* races 2–5: later G1s in the calendar that EVERY season horse can run (C 이상). Finale = 아리마 기념 if all can run,
     otherwise the last such G1. Not enough → the same G1 again (다음 해) */
  function planSeason(ids, first) {
    const g0 = first[5] | 0, ok = (g) => ids.every((id) => elig(id, G1[g][3], G1[g][2]));
    const all = G1.map((_, g) => g).filter(ok);
    const later = all.filter((g) => g > g0);
    const fin = later.includes(ARIMA) ? ARIMA : later.length ? later[later.length - 1] : all.filter((g) => g !== g0).pop() ?? g0;
    let mid = U.shuffle(later.filter((g) => g !== fin)).slice(0, 3);
    if (mid.length < 3) mid = mid.concat(U.shuffle(all.filter((g) => g !== fin && g !== g0 && !mid.includes(g))).slice(0, 3 - mid.length));
    for (let z = 0; mid.length < 3; z++) mid.push(all.length ? all[z % all.length] : g0);
    mid.sort((x, y) => x - y);
    return mid.concat([fin]).map(g1Entry);
  }
  function rollRace(s) {
    if (s.bo === SEASON && s.sch) {
      const c = s.sch[s.rd - 1]; s.ln = c[0]; s.ct = c[1]; s.sf = c[2]; s.wx = c[3]; s.vn = c[4] | 0;
      s.sd = 1 + U.rand(2147483646); s.fin = [];
      if (s.rd > 1) { // 고른 말은 시즌 내내 그대로(컨디션 다시, 지난 경주에서 체력을 다 쓴 말은 한 단계↓) · 자동 출전마는 경주마다 새로
        const keep = s.hs.map((k) => { const F = s.fld[k], r = Math.random(), c0 = r < 0.22 ? 0 : r < 0.78 ? 1 : 2; return [F[0], Math.max(0, c0 - ((s.fat && s.fat[k]) | 0)), F[2], F[3], F[4], F[5], 0]; });
        const cn = {}; s.hs.forEach((k, i) => { if (s.cn && s.cn[k]) cn[i] = s.cn[k]; });
        const bots = genField(Math.max(0, (s.go === -1 ? s.n : gateCount(s)) - s.n), s.ln, s.sf, keep.map((F) => F[0]), 1);
        s.fld = keep.concat(bots); s.hs = s.hs.map((_, i) => i); s.cn = cn; s.fat = [];
        const gates = U.shuffle(s.fld.map((_, i) => i)); s.fld.forEach((F, i) => { F[6] = gates[i]; });
        seatField(s);
        s.ph = 'count';
        return s;
      }
      s.fld = genField(poolCount(s), s.ln, s.sf, null, 1); s.hs = Array(s.n).fill(-1); s.cn = {}; s.bt = [];
      if (s.ai.every((x) => x)) Object.assign(s, aiPicks(s, s.lv)); else s.ph = 'pick';
      return s;
    }
    // 단판: options win; random parts are re-rolled until enough horses can run (random dirt is ≤ 2000 m like real JRA dirt)
    for (let t = 0; t < 40; t++) {
      s.ct = s.co >= 0 ? s.co : Math.random() < 0.3 ? 1 : 0;
      s.sf = s.ct === 1 ? 0 : s.so >= 0 ? s.so : Math.random() < 0.35 ? 1 : 0;
      s.ln = s.lo > 0 ? s.lo : LENS[U.rand(s.sf && s.so < 0 ? 4 : LENS.length)];
      if (eligIds(s.ln, s.sf).length >= s.n + 2) break;
    }
    if (eligIds(s.ln, s.sf).length < s.n) s.ln = 2000; // safety: never fewer horses than riders
    s.wx = s.wo >= 0 ? s.wo : rndWx();
    s.vn = s.vno >= 0 ? s.vno : U.rand(VN.length);
    s.sd = 1 + U.rand(2147483646);
    s.fld = genField(poolCount(s), s.ln, s.sf, null, 0);
    s.hs = Array(s.n).fill(-1); s.bt = [];
    s.fin = []; s.cn = {};
    if (s.ai.every((x) => x)) Object.assign(s, aiPicks(s, s.lv));
    else s.ph = 'pick';
    return s;
  }
  function init(players, opts) {
    const o = opts || {}, n = players.length;
    const s = {
      rid: 1 + U.rand(99999), n, nm: players.map((p) => String((p && p.name) || '').slice(0, 10)),
      ai: players.map((p) => (p && p.ai ? 1 : 0)), lv: players.map((p) => (p && p.ai ? p.lv || 2 : 0)),
      lo: LENS.includes(o.len) ? o.len : 0, co: [0, 1].includes(o.course) ? o.course : -1, bo: o.match === SEASON ? SEASON : 1,
      wo: [0, 1, 2, 3].includes(o.weather) ? o.weather : -1, vno: o.venue >= 0 && o.venue < VN.length ? o.venue | 0 : -1, so: [0, 1].includes(o.surface) ? o.surface : -1, cn: {}, go: [-1, 8, 12].includes(o.gates) ? o.gates : 0, bt: [],
      rd: 1, ph: 'pick', pts: Array(n).fill(0), fat: [], k: players.map(() => [99, 0, 0, 0, 0]), res: null,
    };
    if (s.bo === SEASON) s.sch = [firstSeasonRace(n)];
    return rollRace(s);
  }
  function actor(s) {
    if (!s || s.ph !== 'pick') return null;
    const a = []; s.hs.forEach((x, i) => { if (x < 0 && !s.ai[i]) a.push(i); });
    return a.length ? a : null;
  }
  function apply(s, seat, a) {
    if (!a || a.type !== 'pick' || s.ph !== 'pick') throw new Error('bad action');
    const k = a.f | 0;
    if (!(k >= 0 && k < s.fld.length) || s.hs[seat] >= 0 || s.hs.includes(k)) throw new Error('taken');
    if (!elig(s.fld[k][0], s.ln, s.sf | 0)) throw new Error('적성 미달');
    s.hs[seat] = k;
    const nm = cleanName(a.nm);
    if (nm && nm !== HORSES[s.fld[k][0]].n) { s.cn = Object.assign({}, s.cn); s.cn[k] = nm; }
    if (s.hs.every((x, i) => x >= 0 || s.ai[i])) return aiPicks(s, s.lv);
    return s;
  }
  function autoPick(s) { // host: humans who did not pick get the best free horse, then AI
    const n = Object.assign({}, s, { hs: s.hs.slice() });
    const lv2 = n.hs.map((x, i) => (s.ai[i] ? s.lv[i] : 2));
    return aiPicks(n, lv2);
  }
  const NAME_MAX = 10;
  function cleanName(v) { return typeof v === 'string' ? v.replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, NAME_MAX) : ''; }
  const g1Of = (s) => (s && s.bo === SEASON && s.sch && s.sch[s.rd - 1] && s.sch[s.rd - 1][5] != null ? s.sch[s.rd - 1][5] : -1);
  const finName = (s) => (s && s.sch && s.sch[SEASON - 1] && s.sch[SEASON - 1][5] != null ? G1[s.sch[SEASON - 1][5]][0] : GP);
  const vnName = (s) => (VN[s.vn | 0] || VN[0]).n;
  const vnLine = (s) => { const v = VN[s.vn | 0] || VN[0], sf = s.sf | 0, b = vnBias(s.vn | 0, sf), hs = v.hl.length ? Math.max(...v.hl.map((x) => x[1])) - Math.min(...v.hl.map((x) => x[1])) : 0;
    return v.n + ' ' + SF[sf] + ' · ' + (v.d > 0 ? '좌회전' : '우회전') + ' · 마지막 직선 ' + (sf ? v.dst : v.st) + 'm · ' + (hs ? '고저차 ' + hs + 'm' : '평탄') + ' — ' + (b < 0 ? '선행·도주 유리' : b > 0 ? '추입도 닿는다' : '각질 고르게') + '. ' + v.f; };
  const condTxt = (s) => (g1Of(s) >= 0 ? G1[g1Of(s)][0] + ' · ' : '') + vnName(s) + ' ' + SF[s.sf | 0] + ' ' + s.ln + 'm' + (s.ct === 1 ? ' 장애물' : '') + ' · ' + WX[s.wx | 0].n + ' · ' + WX[s.wx | 0].g;
  const PTS = [10, 7, 5, 4, 3, 2, 1, 0];
  function endRace(s, ord, R) {
    const n = Object.assign({}, s, { ph: 'end', fin: ord, pts: s.pts.slice(), k: s.k.map((r) => r.slice()) });
    const mul = s.bo === SEASON && s.rd === SEASON ? 2 : 1;
    ord.forEach((o, r) => { if (o[0] >= s.n) return; n.pts[o[0]] += (PTS[r] || 0) * mul; const K = n.k[o[0]]; K[0] = Math.min(K[0], r + 1); });
    if (R && R.hs) R.hs.forEach((h, i) => { const K = i < s.n && n.k[i]; if (K) { K[1] += h.kW; K[2] += h.kJ; K[3] += h.kC; K[4] += Math.round(h.kB); } });
    if (s.bo === SEASON && R && R.hs && s.hs) { n.fat = []; R.hs.forEach((h, i) => { if (i < s.n && s.hs[i] >= 0 && h.sta < 6) n.fat[s.hs[i]] = 1; }); }
    return n;
  }
  function nextRace(s) {
    if (s.bo === 1 || s.rd >= s.bo) {
      const res = s.bo === 1 ? s.fin.map((f, r) => [f[0], f[1], f[2], r + 1]).filter((f) => f[0] < s.n)
        : s.pts.map((p, i) => [i, p, s.k[i][0]]).sort((a, b) => b[1] - a[1] || a[2] - b[2] || a[0] - b[0]);
      return Object.assign({}, s, { ph: 'done', res });
    }
    const n = Object.assign({}, s, { rd: s.rd + 1 });
    return rollRace(n);
  }
  const fmtT = (cs) => (cs < 0 ? '완주 못 함' : (cs / 100).toFixed(2) + '초');
  function horseName(s, seat) { const k = s.hs && s.hs[seat], F = s.fld && s.fld[k]; return F ? (s.cn && s.cn[k]) || HORSES[F[0]].n : '?'; }
  function result(s) {
    if (!s || s.ph !== 'done' || !Array.isArray(s.res) || !s.res.length) return null;
    const nm = (i) => (s.nm && s.nm[i]) || (i + 1) + '번';
    let r;
    if (s.bo === 1) {
      const w = s.res[0][0], wp = s.res[0][3] || 1, N = (s.fin || []).length;
      r = { winners: [w], title: nm(w) + (wp === 1 ? ' 우승!' : ' 승리! (' + wp + '착)'), text: condTxt(s) + ' · ' + N + '두 출전\n' + s.res.map((x, k) => (x[3] || k + 1) + '착  ' + nm(x[0]) + ' (' + horseName(s, x[0]) + ')  ' + fmtT(x[1]) + ((x[3] || k + 1) > 1 ? ' · ' + marginTxt(x[2]) : '')).join('\n') };
    } else {
      const top = s.res[0], winners = s.res.filter((x) => x[1] === top[1] && x[2] === top[2]).map((x) => x[0]);
      r = { winners, title: winners.length === 1 ? nm(winners[0]) + ' 시즌 챔피언!' : '공동 우승', text: '시즌 5경주 · 착순 점수(그랑프리 2배)\n' + s.res.map((x, k) => (k + 1) + '위  ' + nm(x[0]) + '  ' + x[1] + '점').join('\n') };
    }
    try {
      const P = s.k.map((_, i) => i);
      r.stats = [
        { label: '최고 착순', values: P.map((i) => (s.k[i][0] < 99 ? s.k[i][0] + '착' : '-')) },
        { label: '스퍼트 연타', values: P.map((i) => String(s.k[i][1])) },
        { label: '막힌 시간', values: P.map((i) => s.k[i][4] + '초') },
      ];
      if (s.k.some((x) => x[2] + x[3] > 0)) r.stats.push({ label: '장애물 성공/실수', values: P.map((i) => s.k[i][2] + '/' + s.k[i][3]) });
    } catch (e) {}
    return r;
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  /* ======================= 실황 중계 (pure, node-testable) =======================
     호스트가 상황을 보고 한 줄을 고른다 → 화면 자막 + hostSend(cm)로 게스트도 같은 줄. AI 줄(있으면)은 같은 상황 칸에서 섞어 쓴다.
     자리표: {A} {B} = 말 이름, {A:이}·{A:은}·{A:을}·{A:와}·{A:로} = 받침에 맞춘 조사, {N} 두수, {M} 착차. */
  const CML = {
    start: ['게이트 열렸습니다. {N}두 일제히 출발합니다', '출발했습니다. 첫 코너까지 자리싸움입니다', '깨끗한 출발, 나란히 뛰쳐나갑니다', '자, 출발! {A:이} 좋은 발로 나섭니다', '스타트, {A:이} 먼저 고개를 내밉니다'],
    early: ['{A:이} 앞으로 나섭니다. {B:이} 그 뒤', '선두 다툼, {A:와} {B}입니다', '{A:이} 선두로 자리 잡습니다', '앞에서 끄는 건 {A}. 2번째에 {B}', '{A:이} 쭉 나가고, {B:이} 붙어 갑니다'],
    call: ['선두는 {A}, 2번째 {B}', '{A:이} 무리를 이끕니다. 바로 뒤에 {B}', '여전히 {A} 선두, {B:이} 노립니다', '{A:이} 앞, {B:이} 한 마신 뒤', '흐름은 {A}. {B:은} 아직 기다립니다', '{A:이} 페이스를 만듭니다. 뒤로 {B}', '선두 {A}, 차이는 크지 않습니다'],
    back: ['맨 뒤에는 {A}. 아직 여유 있습니다', '{A:은} 뒤에서 힘을 모읍니다', '후방의 {A}, 언제 움직일까요', '{A:은} 무리 뒤쪽에서 숨을 고릅니다', '최후방 {A}, 막판을 노립니다'],
    move: ['{A:이} 올라옵니다', '{A}, 바깥에서 순위를 끌어올립니다', '{A:이} 움직였습니다. {B}까지 따라잡습니다', '{A:이} 안쪽으로 파고듭니다', '{A}, 조금씩 앞으로 나옵니다', '{A:이} 성큼 올라섭니다'],
    lead: ['선두 교체! {A}입니다', '{A:이} {B:을} 잡고 선두', '{A:이} 머리를 내밉니다. 선두 {A}', '앞이 바뀝니다. {A:이} 나섰습니다', '{A}, {B:을} 넘어 선두!'],
    corner: ['마지막 코너를 돕니다. 선두 {A}', '4코너, {A:이} 앞, {B:이} 다가섭니다', '코너를 돌아 직선으로, {A:이} 버팁니다', '마지막 코너, {B:이} 바깥으로 나옵니다', '코너 출구, 아직 {A} 선두'],
    kick: ['마지막 직선! {A:이} 앞입니다', '직선 들어섭니다. {A}, {B:이} 온다', '최후의 직선, 채찍이 올라갑니다', '직선 승부! {A:이} 버티나', '마지막 직선, {B:이} 뻗어 옵니다'],
    close: ['{A}, 무서운 끝걸음!', '{A:이} 바깥에서 날아옵니다', '{A:이} 뻗습니다. {B:을} 잡을까', '뒤에서 {A}! 엄청난 다리입니다', '{A:이} 맹추격합니다'],
    upset: ['{A}, 인기 없던 말이 앞에 있습니다', '이변인가, {A:이} 선두!', '{A:이} 버팁니다. 이건 대이변', '아무도 예상 못 한 {A}, 앞입니다'],
    favfade: ['1번 인기 {A}, 뒤에서 고전합니다', '{A:은} 힘이 없습니다. 오늘은 어렵나', '인기마 {A}, 좀처럼 다리가 안 나옵니다', '{A}, 아직 무리 속입니다'],
    f200: ['남은 200! 선두 {A}!', '200 남았습니다. {A:이} 버티나', '남은 200, {B:이} {A:을} 쫓습니다', '200 지점, {A} 그대로인가'],
    tight: ['{A:와} {B}, 나란히!', '목 하나 차이, {A:와} {B}!', '{B:이} 따라붙습니다. {A:와} 맞대결', '알 수 없습니다, {A:와} {B}!'],
    crash: ['{A}, 장애물에 걸렸습니다', '아, {A:이} 휘청합니다', '{A}, 발이 걸려 속도가 떨어집니다'],
    jump: ['{A}, 깔끔하게 넘습니다', '{A:이} 가볍게 비월합니다', '{A}, 리듬을 잃지 않습니다'],
    photo: ['간발의 차, 사진 판정입니다!', '{A:와} {B}, 코끝 승부! 사진 판정', '나란히 들어왔습니다. 판정을 기다립니다'],
    fin: ['{A}, 1착 골인!', '{A:이} 결승선을 먼저 통과합니다', '{A} 우승! 관중석이 일어섭니다', '{A:이} 해냈습니다!', '1착은 {A}!'],
  };
  /* 착 뒤 마무리 한 줄(자료): {A} 1착 · {B} 2착 · {M} 착차 */
  const CML_END = {
    big: ['{A}, {M} 차 완승입니다. 오늘은 상대가 없었습니다', '{A:이} {M} 차로 따돌렸습니다. 압도적인 경주', '끝까지 {A}의 경주. {B:은} {M} 차 2착'],
    close: ['{A}, {B:을} {M} 차로 물리쳤습니다', '{A:이} 끝까지 버텼습니다. {B:은} {M} 차 2착', '{A}, 마지막까지 짜냈습니다. 2착 {B}'],
    upset: ['대이변! {A:이} 인기를 뒤집었습니다', '{A}, 아무도 예상 못 한 우승입니다', '이변의 주인공은 {A}. {B:은} 2착'],
    fav: ['1번 인기 {A}, 인기에 답했습니다', '{A}, 역시 강했습니다. 2착 {B}', '믿음직한 {A}, 기대대로 1착'],
  };
  const CM_KEYS = Object.keys(CML);
  function hasBatchim(s) {
    const t = String(s || '').replace(/[\s)\]"'’]+$/, ''); if (!t) return false;
    const c = t.charCodeAt(t.length - 1);
    if (c >= 0xac00 && c <= 0xd7a3) return (c - 0xac00) % 28 !== 0;
    if (c >= 48 && c <= 57) return '013678'.includes(t[t.length - 1]);
    return false;
  }
  function rieul(s) { const t = String(s || ''), c = t.charCodeAt(t.length - 1); return c >= 0xac00 && c <= 0xd7a3 && (c - 0xac00) % 28 === 8; }
  const JOSA = { 이: ['이', '가'], 은: ['은', '는'], 을: ['을', '를'], 와: ['과', '와'] };
  function fillLine(t, A, B, x) {
    const name = (k) => (k === 'A' ? A : k === 'B' ? B : k === 'N' ? String((x && x.N) || '') : k === 'M' ? String((x && x.M) || '') : '');
    return String(t).replace(/\{([ABNM])(?::(이|은|을|와|로))?\}/g, (_, k, j) => {
      const n = name(k); if (!j) return n;
      if (j === '로') return n + (hasBatchim(n) && !rieul(n) ? '으로' : '로');
      return n + JOSA[j][hasBatchim(n) ? 0 : 1];
    });
  }
  /* AI 글의 「{A}가」·「{A}(이)가」 같은 꼴을 조사 자리표로 맞춘다 */
  function normTok(s) {
    return String(s).replace(/\{\s*([AB])\s*\}\s*(?:\(\s*(?:이|은|을|과|으)\s*\))?(으로|이|가|은|는|을|를|와|과|로)?(?![가-힣])?/g, (m, k, j) => {
      if (!j) return '{' + k + '}';
      const J = { 이: '이', 가: '이', 은: '은', 는: '은', 을: '을', 를: '을', 와: '와', 과: '와', 으로: '로', 로: '로' }[j];
      return '{' + k + ':' + J + '}';
    });
  }
  function cleanCm(t, max) {
    let s = String(t || '').replace(/\r?\n+/g, ' ').trim();
    s = s.replace(/^[^\s:：{}]{1,10}\s*[:：]\s*/, '');
    s = s.replace(/\((?!\s*(?:이|은|을|과|으)\s*\))[^)]*\)|（[^）]*）|\*[^*]*\*|\[[^\]]*\]/g, '');
    s = s.replace(/["“”‘’「」『』《》〈〉]/g, '').replace(/^'+|'+$/g, '');
    s = s.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B50}\u{2764}]/gu, '');
    s = s.replace(/~+/g, '').replace(/!{2,}/g, '!').replace(/\?{2,}/g, '?').replace(/…+|\.{3,}/g, '…');
    let n = 0; s = s.replace(/!/g, () => (n++ ? '.' : '!'));
    s = normTok(s).replace(/\s+/g, ' ').trim();
    if (s.length > (max || 40)) return '';
    return s;
  }
  function bigr(s) { s = String(s).replace(/\{[^}]*\}|[\s.,!?…]/g, ''); const a = []; for (let i = 0; i < s.length - 1; i++) a.push(s.slice(i, i + 2)); return a; }
  function simLine(a, b) {
    const A = bigr(a), B = bigr(b); if (!A.length || !B.length) return a === b ? 1 : 0;
    const m = new Map(); B.forEach((x) => m.set(x, (m.get(x) || 0) + 1)); let k = 0; A.forEach((x) => { const v = m.get(x); if (v) { k++; m.set(x, v - 1); } });
    return 2 * k / (A.length + B.length);
  }
  const TOK = /\{[AB](?::(?:이|은|을|와|로))?\}/g;
  function badCm(s, others) {
    if (!s || s.length < 4) return 'empty';
    if (/[A-Za-z]{2,}/.test(s.replace(TOK, ''))) return 'latin';
    if (/플레이어|게임|프롬프트|캐릭터|\bAI\b|대사|자리표|중계진|해설자|JSON/.test(s)) return 'meta';
    if (/[{}]/.test(s.replace(TOK, ''))) return 'token';
    if (/습니까\?|것입니다|되어지|에 있어서|중입니다/.test(s)) return 'stiff';
    if ((others || []).some((r) => simLine(r, s) > 0.62)) return 'repeat';
    return '';
  }
  /* AI 줄 묶음 정리: 칸마다 걸러 담는다 */
  function cleanPool(raw) {
    const out = {}; let n = 0;
    if (!raw || typeof raw !== 'object') return null;
    const src = raw.lines && typeof raw.lines === 'object' ? raw.lines : raw;
    for (const k of CM_KEYS) {
      const arr = Array.isArray(src[k]) ? src[k] : [], keep = [];
      for (const t of arr.slice(0, 12)) {
        const s = cleanCm(t, 40);
        if (badCm(s, keep.concat(CML[k]))) continue;
        if (/\{B/.test(s) && !/\{A/.test(s) && k !== 'photo') continue;
        keep.push(s);
      }
      if (keep.length) { out[k] = keep; n += keep.length; }
    }
    return n ? out : null;
  }
  function newCm() { return { t: 0, gap: 1.5, id: 0, cur: null, rec: [], recT: [], q: [], hist: [], histT: 0, done: {}, fin: 0 }; }
  /* dt만큼 시간이 가고, 말할 차례면 {id, t:글, a:AI줄} 을 S.cur에 담고 돌려준다.
     I = { name(i), names[], pop[i] (0 = 1번 인기), pool (AI 줄 묶음|null), rnd() } · 사건은 S.q.push([type, seat, S.t]) */
  function cmTick(R, S, I, dt) {
    S.t += dt; S.gap -= dt; S.histT -= dt;
    if (!R || !R.n || R.t < 0.2) return null;
    const C = R.C, rnd = I.rnd || Math.random;
    const ord = R.hs.map((_, i) => i).sort((a, b) => { const A = R.hs[a], B2 = R.hs[b]; if (A.ft >= 0 && B2.ft >= 0) return A.ft - B2.ft; if (A.ft >= 0) return -1; if (B2.ft >= 0) return 1; return B2.p - A.p; });
    const rk = []; ord.forEach((s, k) => { rk[s] = k; });
    if (S.histT <= 0) { S.histT = 1; S.hist.push(rk.slice()); if (S.hist.length > 5) S.hist.shift(); }
    const lead = ord[0], sec = ord[1] != null ? ord[1] : -1, lp = R.hs[lead].p, pop = I.pop || [];
    let pick = null;
    // 1) 사건(우선): 결승·사진 판정은 바로, 나머지는 간격을 두고
    while (S.q.length) {
      const e = S.q[0];
      if (e[0] === 'fin' || e[0] === 'photo') {
        S.q = [];
        if (S.fin) break;
        S.fin = 1;
        pick = [e[0], ord[0], sec];
        break;
      }
      if (S.gap > 0.9 || S.fin) { if (S.t - (e[2] || 0) > 3) { S.q.shift(); continue; } break; }
      S.q.shift();
      if (e[0] === 'start') pick = ['start', lead, sec];
      else if (e[0] === 'lead' && e[1] >= 0) pick = ['lead', e[1], ord.find((s) => s !== e[1])];
      else if (e[0] === 'crash' && e[1] >= 0) pick = ['crash', e[1], -1];
      else if (e[0] === 'spurt') pick = ['kick', lead, sec];
      else if (e[0] === 'mash' && e[1] >= 0 && e[1] !== lead) pick = ['close', e[1], lead];
      else if (e[0] === 'tight') pick = ['tight', lead, sec];
      else if (e[0] === 'f200') pick = ['f200', lead, sec];
      else if (e[0] === 'jump' && e[1] >= 0 && rnd() < 0.25) pick = ['jump', e[1], -1];
      if (pick) break;
    }
    // 2) 시간이 되면 지금 그림을 보고
    if (!pick && S.gap <= 0 && !S.fin && R.firstFt < 0) {
      const frac = lp / C.ln, inSp = lp >= C.spS, n = R.n;
      const mover = () => { const h0 = S.hist[0]; if (!h0 || S.hist.length < 4) return -1; let b = -1, bg = 1; for (let i = 0; i < n; i++) { if (R.hs[i].ft >= 0 || rk[i] > 5) continue; const g = h0[i] - rk[i]; if (g > bg) { bg = g; b = i; } } return b; };
      if (!S.done.corner && lp >= C.spS - 260 && lp < C.spS - 20 && frac > 0.45) { S.done.corner = 1; pick = ['corner', lead, sec]; }
      else if (inSp) {
        const fav = pop.indexOf(0);
        let cl = -1, bv = 0; for (const i of ord.slice(2, 6)) { const h = R.hs[i]; if (h.ft < 0 && h.v > bv && h.v > R.hs[lead].v + 0.4) { bv = h.v; cl = i; } }
        if (!S.done.upset && pop[lead] >= Math.max(3, Math.ceil(n / 2)) && C.ln - lp < 330) { S.done.upset = 1; pick = ['upset', lead, sec]; }
        else if (cl >= 0 && !S.done['c' + cl]) { S.done['c' + cl] = 1; pick = ['close', cl, ord[rk[cl] - 1]]; }
        else if (!S.done.fav && fav >= 0 && n >= 5 && rk[fav] >= 3 && R.hs[fav].ft < 0) { S.done.fav = 1; pick = ['favfade', fav, lead]; }
        else { const m = mover(); pick = m >= 0 && m !== lead ? ['move', m, ord[rk[m] - 1]] : ['kick', lead, sec]; }
      } else if (R.t < 9) pick = ['early', lead, sec];
      else {
        const m = mover(), r = rnd();
        if (m >= 0 && m !== lead && r < 0.45) pick = ['move', m, ord[Math.max(0, rk[m] - 1)]];
        else if (r < 0.62 && n >= 4 && !S.done.back) { S.done.back = 1; pick = ['back', ord[n - 1], -1]; }
        else pick = ['call', lead, sec];
      }
    }
    if (!pick) return null;
    const key = pick[0], a = pick[1], b = pick[2];
    const A = a >= 0 ? I.name(a) : '', B2 = b != null && b >= 0 ? I.name(b) : '';
    const others = (I.names || []).filter((x) => x && x !== A && x !== B2);
    const cand = [];
    const pool = I.pool && I.pool[key];
    if (pool) pool.forEach((t) => { if (!others.some((nm) => t.includes(nm))) cand.push([t, 1]); });
    CML[key].forEach((t) => cand.push([t, 0]));
    const ok = (t) => (B2 || !/\{B/.test(t)) && (A || !/\{A/.test(t));
    let C2 = cand.filter((c) => ok(c[0]) && !S.rec.includes(c[0]));
    if (!C2.length) C2 = cand.filter((c) => ok(c[0]));
    if (!C2.length) return null;
    const ai = C2.filter((c) => c[1]), use = ai.length && rnd() < 0.7 ? ai : C2;
    let got = null;
    for (let k = 0; k < 6; k++) { const c = use[Math.floor(rnd() * use.length)], tx = fillLine(c[0], A, B2, { N: R.n }); if (!S.recT.some((r) => simLine(r, tx) > 0.7) || k === 5) { got = [c[0], tx, c[1]]; break; } }
    S.rec.push(got[0]); if (S.rec.length > 16) S.rec.shift();
    S.recT.push(got[1]); if (S.recT.length > 5) S.recT.shift();
    S.id = (S.id + 1) % 100000;
    S.gap = key === 'fin' || key === 'photo' ? 99 : 2.6 + rnd() * 1.4;
    S.cur = { id: S.id, t: got[1], a: got[2], k: key };
    return S.cur;
  }
  /* 착 뒤 마무리(자료): 모든 기기가 같은 줄 — seed로 고른다 */
  function endLineData(fin, name, pop, seed, mtxt) {
    if (!fin || !fin[0]) return '';
    const w = fin[0][0], s2 = fin[1] ? fin[1][0] : -1, m = fin[1] ? fin[1][2] : 0;
    const kind = pop[w] >= 4 ? 'upset' : pop[w] === 0 && m >= 5 ? 'fav' : m >= 70 ? 'big' : 'close';
    const L2 = CML_END[kind].filter((t) => s2 >= 0 || !/\{B/.test(t));
    return fillLine(L2[(seed >>> 0) % L2.length], name(w), s2 >= 0 ? name(s2) : '', { M: mtxt(m) });
  }
  const CSS = `
.hr-pick{position:absolute;inset:0;z-index:8;padding:12px 12px calc(12px + env(safe-area-inset-bottom));background:rgba(17,14,22,.94);display:flex;flex-direction:column;gap:8px;user-select:none;-webkit-user-select:none;overflow:hidden}
.hr-pick h3{margin:0;font-family:"Black Han Sans",sans-serif;font-weight:400;font-size:21px;color:#f2e9d8;display:flex;align-items:center;gap:8px}
.hr-pick .sub{font-size:12.5px;color:#ab9fb8;line-height:1.4}
.hr-pick .sub b{color:#e3ae45;font-weight:700}
.hr-cond{display:flex;flex-wrap:wrap;gap:5px}
.hr-cond .ch{font-size:12px;font-weight:700;padding:3px 9px;border-radius:10px;background:rgba(242,233,216,.08);color:#f2e9d8;border:1px solid rgba(242,233,216,.12)}
.hr-cond .wx0{color:#ffd76a}.hr-cond .wx1{color:#c9c3d4}.hr-cond .wx2{color:#8fc3ff}.hr-cond .wx3{color:#b39cff}
.hr-list{flex:1;min-height:0;overflow-y:auto;display:grid;grid-auto-rows:max-content;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:6px;align-content:start;-webkit-overflow-scrolling:touch}
.hr-hc{position:relative;display:flex;border:1.5px solid rgba(242,233,216,.14);background:linear-gradient(180deg,rgba(52,43,70,.95),rgba(38,31,52,.95));border-radius:12px;overflow:hidden}
.hr-hc.taken{opacity:.5}
.hr-hc .pk{appearance:none;flex:1;min-width:0;text-align:left;border:0;background:none;color:#f2e9d8;padding:6px 4px 6px 8px;font:inherit;font-size:12px;cursor:pointer;touch-action:manipulation;min-height:64px}
.hr-hc .pk:active{transform:scale(.985)}
.hr-hc .pk:disabled{cursor:default}
.hr-hc .ed{appearance:none;flex:0 0 44px;width:44px;border:0;border-left:1px solid rgba(242,233,216,.1);background:rgba(0,0,0,.15);color:#f2e9d8;font-size:17px;cursor:pointer;touch-action:manipulation}
.hr-hc .in{display:grid;grid-template-columns:52px 1fr auto;gap:1px 7px;align-items:center}
.hr-hc canvas{width:52px;height:40px;grid-row:1 / span 2}
.hr-hc .nmw{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:4px;min-width:0}
.hr-hc .gt{flex:none;font:700 10.5px "IBM Plex Mono",monospace;background:#f2e9d8;color:#141019;border-radius:4px;padding:0 4px}
.hr-hc .nm{font-weight:700;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;min-width:0}
.hr-hc .sty{flex:none;font-size:10.5px;padding:0 6px;border-radius:8px;background:rgba(227,174,69,.18);color:#e3ae45;font-weight:700}
.hr-hc .cd{flex:none;font-size:10.5px;padding:0 5px;border-radius:8px;font-weight:700}
.hr-hc .cd.c2{background:rgba(95,211,138,.18);color:#5fd38a}.hr-hc .cd.c0{background:rgba(238,106,85,.18);color:#ee6a55}
.hr-hc .mk{grid-column:3;grid-row:1 / span 2;font-size:22px;font-weight:700;width:38px;text-align:center;line-height:1.05}
.hr-hc .mk .pop{display:block;font:700 10px "IBM Plex Mono",monospace;color:#ab9fb8;white-space:nowrap}.hr-hc .mk .pop.t3{color:#ffd76a}
.hr-flt{display:flex;flex-wrap:wrap;gap:5px;align-items:center}
.hr-sel{appearance:none;-webkit-appearance:none;flex:1 1 76px;min-width:0;min-height:44px;padding:0 6px;border-radius:10px;border:1px solid rgba(242,233,216,.18);background:#241d30;color:#f2e9d8;font:700 12px sans-serif;text-align:center;text-align-last:center}
.hr-sel.on{border-color:#e3ae45;color:#ffd76a;background:#3a2c1e}
.hr-flt .cnt{font-size:11px;color:#ab9fb8;flex:none}
.hr-hc .mk.m0{color:#5fd38a}.hr-hc .mk.m1{color:#9fc6ff}.hr-hc .mk.m2{color:#e3ae45}.hr-hc .mk.m3{color:#ee6a55}
.hr-hc .apt{grid-column:2;font-size:10.5px;color:#ab9fb8;white-space:nowrap;overflow:hidden;display:flex;gap:2px;align-items:center;min-width:0}
.hr-hc .apt .g{padding:0 2px;border-radius:4px}.hr-hc .apt .g b{color:#f2e9d8}
.hr-hc .apt .g.on{background:rgba(227,174,69,.2);color:#e3ae45}.hr-hc .apt .g.on b{color:#ffd76a}
.hr-hc .apt .g.lo b{color:#ee6a55}.hr-hc .apt .bar2{width:1px;height:10px;background:rgba(242,233,216,.2)}
.hr-hc .apt .hv{color:#8fc3ff}
.hr-hc.off{opacity:.42;filter:grayscale(.7)}.hr-hc.off .pk{cursor:default;min-height:0}
.hr-hc .why{font-size:11px;color:#ee6a55;font-weight:700;margin-top:3px}
.hr-sep{grid-column:1/-1;font-size:11.5px;color:#8d829a;font-weight:700;padding:8px 2px 0;border-top:1px solid rgba(242,233,216,.1);margin-top:4px}
.hr-hc .bars{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:4px}
.hr-hc .bw{display:flex;align-items:center;gap:4px;font-size:10px;color:#ab9fb8;white-space:nowrap}
.hr-hc .bar{flex:1;height:5px;border-radius:3px;background:rgba(0,0,0,.4);overflow:hidden}
.hr-hc .bar i{display:block;height:100%;background:#7fbf8e}
.hr-hc .ft{font-size:10.5px;color:#8d829a;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hr-hc .own{position:absolute;top:5px;right:50px;min-width:20px;height:18px;border-radius:9px;padding:0 5px;font:700 11px sans-serif;color:#141019;display:flex;align-items:center;justify-content:center}
.hr-np{position:absolute;inset:0;z-index:4;background:rgba(10,8,14,.75);display:flex;flex-direction:column;padding:10px 10px calc(10px + env(safe-area-inset-bottom))}
.hr-np .pp{flex:1;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;background:#efe6d2;color:#231b14;border-radius:6px;padding:12px 12px 16px;font-family:"IBM Plex Sans KR",serif;box-shadow:0 6px 24px rgba(0,0,0,.5)}
.hr-np .mh{text-align:center;border-bottom:3px double #231b14;padding-bottom:6px;margin-bottom:6px}
.hr-np .mh b{display:block;font-family:"Black Han Sans",sans-serif;font-weight:400;font-size:26px;letter-spacing:2px}
.hr-np .mh span{font-size:11px;color:#5a4a3a}
.hr-np .hd{font-family:"Black Han Sans",sans-serif;font-size:17px;line-height:1.3;margin:6px 0 4px}
.hr-np .pk2{border:1.5px solid #231b14;padding:7px 9px;margin:6px 0 8px;background:rgba(160,40,30,.08);font-size:12.5px;line-height:1.45}
.hr-np .pk2 i{font-style:normal;font-weight:700;color:#a3281e}
.hr-np table{width:100%;border-collapse:collapse;font-size:12px}
.hr-np th{font-size:10.5px;text-align:left;border-bottom:1.5px solid #231b14;padding:2px 3px;color:#5a4a3a}
.hr-np td{border-bottom:1px dotted #8a7a66;padding:5px 3px;vertical-align:top}
.hr-np td.mk{font-size:17px;font-weight:700;text-align:center;width:22px;color:#a3281e}
.hr-np th.ni{text-align:center}.hr-np td.ni{font:700 13px "IBM Plex Mono",monospace;text-align:center;width:26px;white-space:nowrap}.hr-np td.ni.t3{color:#a3281e}
.hr-np td.od{font:700 12.5px "IBM Plex Mono",monospace;text-align:right;white-space:nowrap}
.hr-np .pc{font-size:12px;line-height:1.45;margin:2px 0 4px}.hr-np .pc i{font-style:normal;font-weight:700}
.hr-np .cm{font-size:11.5px;color:#4a3c30;margin-top:2px;line-height:1.35}
.hr-np .ss{font-size:11.5px;margin-top:8px;border-top:1.5px solid #231b14;padding-top:5px;line-height:1.5;white-space:pre-line}
.hr-np .ft2{font-size:10.5px;color:#6a5a4a;margin-top:8px}
.hr-np .btn{margin-top:8px;min-height:48px}
.hr-ren{position:absolute;inset:0;z-index:3;background:rgba(10,8,14,.7);display:flex;align-items:center;justify-content:center;padding:16px}
.hr-ren .box{width:100%;max-width:340px;background:#241d30;border:1px solid rgba(227,174,69,.4);border-radius:14px;padding:14px;display:flex;flex-direction:column;gap:10px}
.hr-ren .hr-in{font:700 17px sans-serif;padding:10px 12px;min-height:44px;border-radius:10px;border:1.5px solid rgba(242,233,216,.25);background:#17131e;color:#f2e9d8;width:100%;box-sizing:border-box}
.hr-ren .row2{display:flex;gap:6px}.hr-ren .row2 .btn{flex:1;min-height:44px;padding:0 6px}
`;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const FX = () => (typeof L.fx === 'function' ? L.fx() : 1);
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1);
    const isMine = (s) => mine().includes(s);
    /* 경주 번호 i: 0..n−1 = 자리(사람·AI), n.. = 자동 출전마(st.bt) */
    const nSeat = () => (st ? st.n : 0);
    const isBot = (i) => !!st && i >= st.n;
    const kOf = (i) => (!st || !st.hs ? -1 : i < st.n ? st.hs[i] : (st.bt || [])[i - st.n]);
    const BOTP = {};
    const P = (s) => { if (!isBot(s)) return api.players[s] || { name: '?', color: '#888', ai: true };
      const F = st.fld[kOf(s)], N = st.n + (st.bt || []).length, c = WAKU[wakuOf(F ? F[6] : 0, N)], key = s + c;
      return BOTP[key] || (BOTP[key] = { name: '자동', color: c, ai: true, lv: 2, bot: 1 }); };
    const nameOf = (s) => (isBot(s) ? '자동' : (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번');
    const fOf = (s) => (st && st.fld && (st.fld[kOf(s)] || st.fld[0])) || [0, 1, 5, 5, 5, 0, 0];
    const NKEY = 'lounge.horserace.names';
    let myNames = {};
    try { myNames = JSON.parse(localStorage.getItem(NKEY) || '{}') || {}; } catch (e) { myNames = {}; }
    const saveNames = () => { try { localStorage.setItem(NKEY, JSON.stringify(myNames)); } catch (e) {} };
    const fName = (k) => { const F = st && st.fld && st.fld[k]; if (!F) return '?'; return (st.cn && st.cn[k]) || myNames[F[0]] || HORSES[F[0]].n; };
    const hName = (s) => (st && st.hs ? fName(kOf(s)) : '?');
    const who = (s) => (isBot(s) ? hName(s) : nameOf(s) + ' · ' + hName(s));
    const simHere = (s) => { if (isBot(s)) return host(); const p = api.players[s]; if (!p) return false; if (!api.online) return true; return !!p.ai || !!p.local; };
    let st = null, key = null, R = null, phase = 'wait', cd = 0, endT = 0, acc = 0, pickT = 0, pick = null, lastPickSig = '';
    const pf = { sty: -1, dist: -1, crs: -1, sort: 0 }; // 고르기 화면 필터·정렬(이 기기에서만)
    let cm = newCm(), cmPool = null, cmCap = null, cmPop = [], aiJob = '', clLive = '', clJob = '';
    let aiMem = [], banner = null, shownEv = -1, lastEv = 0, flash = 0, shake = 0, slowK = 1, photo = null, hintT = 0;
    let cam = { x: 0, y: 0, h: 0, ok: false };
    const resS = { v: 0, key: null, box: null, drag: null };
    let btn = { L: null, R: null, pad: null, o: null }, raceH = 0, rbtn = [], rp = null, trace = [], trT = -1, ordFx = [];
    const pads = new Set(); let padHeld = false, fbT = 0, fbTxt = '', fbCol = '#f2e9d8';
    // net
    let pubT = 0, hsQ = 0, inQ = 0, lastSig = '', snaps = [], lastQ = -1;
    const remJ = {}, remW = {}, remO = {};
    let myJ = [-1, '', 0], myW = 0, tapFx = 0, lastMp = 0;
    const laneHold = { d: 0, t: 0, ptr: new Set() };

    function curKey() { return st ? st.rid + '.' + st.rd : null; }
    function raceOpts() {
      // 고르기 중(아직 안 고른 자리 = −1)에는 그 경주에 나갈 수 있는 후보로 자리만 채운다 — 예전엔 0번 말(디프 임팩트, 더트 G)이 대신 서 있었다
      return { ln: st.ln, ct: st.ct, sd: st.sd, wx: st.wx | 0, sf: st.sf | 0, vn: st.vn | 0, fh: st.hs.concat(st.ph === 'pick' ? [] : st.bt || []).map((k, i) => st.fld[k] || (st.fld[i] || st.fld[0]).slice()) };
    }
    function startRace() {
      R = newRace(raceOpts());
      aiMem = R.hs.map(() => ({}));
      cm = newCm(); cmCap = null; cmPop = runPop(); clLive = '';
      snaps = []; lastQ = -1; banner = null; shownEv = -1; lastEv = 0; acc = 0; flash = 0; photo = null; slowK = 1;
      myJ = [-1, '', 0]; myW = 0; tapFx = 0; lastMp = 0; laneHold.d = 0;
      if (rp) { rp = null; if (!host()) busy(false); }
      trace = []; trT = -1; ordFx = []; rbtn = [];
      phase = st.ph === 'run' ? 'run' : 'count'; cd = COUNT; endT = endDur();
      cam.ok = false;
      if (st.rd === 1) hintT = 7;
      audio.bell();
      layout();
    }

    /* ----- layout ----- */
    function layout() {
      const W = cv.w, Hh = cv.h;
      if (mine().length) {
        const ch = clamp(Math.round(Hh * 0.34) + 44, 240, 340);
        raceH = Hh - ch;
        const oy = raceH + 58, by = oy + 52, bh = Hh - by - 10, side = clamp(Math.round(W * 0.2), 64, 96);
        const ow = (W - 16 - 12) / 3;
        btn.o = ['g', 's', 'o'].map((t, i) => ({ t, x: 8 + i * (ow + 6), y: oy, w: ow, h: 46 }));
        btn.L = { x: 8, y: by, w: side, h: bh };
        btn.R = { x: W - 8 - side, y: by, w: side, h: bh };
        btn.pad = { x: 16 + side, y: by, w: W - 32 - side * 2, h: bh };
      } else { raceH = Math.round(Hh * 0.62); btn = { L: null, R: null, pad: null, o: null }; }
    }
    cv.onresize = layout;
    const inR = (b, x, y) => b && x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h;

    /* ----- input ----- */
    const mySeat = () => { const m = mine(); return m.length ? m[0] : -1; };
    function canRide() { const s = mySeat(); return s >= 0 && R && st && st.ph === 'run' && phase === 'run' && R.hs[s] && R.hs[s].ft < 0; }
    function setPush(on) {
      padHeld = on; const s = mySeat();
      if (s < 0 || !R) return;
      if (host()) R.hs[s].push = on ? 1 : 0;
      pubT = 0;
    }
    /* sd = 화면 방향(−1 왼쪽, +1 오른쪽). 카메라는 늘 진행 방향이 위라서 바깥쪽은 왼돌이 코스면 화면 오른쪽, 오른돌이면 왼쪽(C.sg) */
    function lane(sd, quiet) {
      const s = mySeat(); if (!canRide()) return;
      hintT = Math.min(hintT, 1.5);
      const h = R.hs[s], d = sd * (R.C.sg || 1);
      const nl0 = clamp(Math.round(h.tl) + d, 0, R.NL - 1);
      if (nl0 === h.tl) { if (!quiet) api.buzz(12); return; } // 레일·바깥 끝
      let ok = false;
      if (host()) ok = setLane(R, s, d);
      else { if (laneFree(R, s, nl0)) { h.tl = nl0; ok = true; } pubT = 0; }
      if (ok) { api.buzz(8); audio.tick(); } else if (!quiet) { say('옆이 막혔어요', '#ee6a55', 0.6); api.buzz(30); }
    }
    function laneDown(d) { laneHold.d = d; laneHold.t = 0.3; lane(d); }
    function laneTick(rdt) { // 누르고 있으면 계속 옮김
      if (!laneHold.d) return;
      const on = laneHold.ptr.size > 0 || (api.input && api.input.held && api.input.held(laneHold.d < 0 ? 'left' : 'right'));
      if (!on) { laneHold.d = 0; return; }
      laneHold.t -= rdt; if (laneHold.t <= 0) { laneHold.t = 0.2; lane(laneHold.d, true); }
    }
    let myO = [0, ''], oSentAt = 0;
    const ORDN = { g: '앞으로 나가기', s: '힘 아끼기', o: '바깥으로 빠지기' };
    function giveOrder(t) {
      const s = mySeat(); if (!canRide()) return;
      const h = R.hs[s];
      let why = '';
      if (host()) why = issueOrder(R, s, t, hooks);
      else { // guest: check locally, send the request; the host's snapshot corrects it
        why = !(h.oc > 0) ? '지시를 다 썼어요' : t === 's' && inSpurt(R, h) ? '스퍼트 중엔 못 아껴요' : t === 'o' && outLane(R, s) < 0 ? '바깥도 막혔어요' : '';
        if (!why) { myO = [(myO[0] + 1) % 1000, t]; h.oc--; if (t === 'o') { h.tl = outLane(R, s); laneSentAt = performance.now(); } else { h.om = t; h.ot = ORD[t]; } oSentAt = performance.now(); hooks.order(s, t); pubT = 0; }
      }
      if (why) { say(why, '#ee6a55', 0.8); api.buzz(30); }
    }
    function press() {
      const s = mySeat(); if (!canRide()) return;
      hintT = Math.min(hintT, 1.5);
      let r = '';
      if (host()) r = pressAt(R, s, hooks);
      else { // guest: judge locally and send counters
        const h = R.hs[s];
        if (inSpurt(R, h)) {
          if (h.sp0 < 0) h.sp0 = R.t;
          R.mAnn = 1; // 중계 이벤트는 호스트가
          if (applyMash(R, s, hooks)) { myW = (myW + 1) % 100000; r = 'm'; }
        } else {
          const q = judgeJump(fenceTT(R, s));
          if (q) { myJ = [h.ob, q, (myJ[2] + 1) % 1000]; h.jr = q; h.jx = R.C.obs[h.ob]; r = 'j' + q; }
        }
        pubT = 0;
      }
      if (r[0] === 'j') { say(r === 'jP' ? '완벽한 도약!' : '넘었어요', r === 'jP' ? '#5fd38a' : '#f2e9d8', 1); api.buzz(r === 'jP' ? 25 : 15); audio.whoosh(); }
    }
    function onDown(e) {
      e.preventDefault();
      audio.wake();
      const p = cv.local(e);
      if (st && st.ph === 'end' && !photoOn()) { for (const b of rbtn) if (inR(b, p.x, p.y)) { b.go(); return; }
        if (resS.box && !rp && inR(resS.box, p.x, p.y)) { resS.drag = { y: p.y, v: resS.v, id: e.pointerId }; try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {} return; } }
      if (rp) return;
      if (btn.o) for (const b of btn.o) if (inR(b, p.x, p.y)) { giveOrder(b.t); return; }
      if (inR(btn.L, p.x, p.y) || inR(btn.R, p.x, p.y)) { laneHold.ptr.add(e.pointerId); try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {} laneDown(inR(btn.L, p.x, p.y) ? -1 : 1); return; }
      if (inR(btn.pad, p.x, p.y) || (btn.pad && p.y < raceH)) {
        pads.add(e.pointerId);
        try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
        if (pads.size === 1) setPush(true);
        press();
      }
    }
    function onMove(e) { if (!resS.drag || e.pointerId !== resS.drag.id || !resS.box) return; const p = cv.local(e); resS.v = resS.drag.v - (p.y - resS.drag.y) / resS.box.rh; }
    function onWheel(e) { if (!resS.box || !st || st.ph !== 'end') return; e.preventDefault(); resS.v += Math.sign(e.deltaY) * 2; }
    function onUp(e) { if (resS.drag && e.pointerId === resS.drag.id) { resS.drag = null; resS.v = Math.round(resS.v); return; } laneHold.ptr.delete(e.pointerId); if (pads.delete(e.pointerId) && !pads.size && !keyHeld()) setPush(false); }
    const keyHeld = () => !!(api.input && api.input.held && api.input.held('push'));
    const offIn = api.input ? api.input.on((type, id) => {
      if (pick) return;
      audio.wake();
      if (id === 'push') { if (type === 'down') { setPush(true); press(); } else if (!pads.size) setPush(false); }
      if (type === 'down' && (id === 'og' || id === 'os' || id === 'oo')) giveOrder(id[1]);
      if (type === 'down' && id === 'replay' && st && st.ph === 'end' && trace.length > 2) startReplay(rp ? 0 : 2, false);
      if (type === 'down' && id === 'left') laneDown(-1);
      if (type === 'down' && id === 'right') laneDown(1);
    }) : () => {};
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    function say(t, c, d) { fbTxt = t; fbCol = c; fbT = d || 0.8; }
    /* PC 단축키 배지(라운드 42): 캔버스 버튼 오른쪽 아래에 「⌨ 조작 설정」의 첫 번째 키. 터치 기기·표시 끔이면 아무것도 안 그림 */
    const kb = (b, id) => { try { if (b && L.ui && L.ui.drawKeyBadge && L.ui.keyLabel) L.ui.drawKeyBadge(ctx, b.x + b.w - 3, b.y + b.h - 3, L.ui.keyLabel('horserace', id)); } catch (e) {} };

    /* ----- audio (own WebAudio × L.audio.sfx) ----- */
    const audio = (() => {
      let ac = null, noise = null, crowd = null, cg = null, hoofT = 0;
      const vol = () => { try { return L.audio && L.audio.sfx ? L.audio.sfx() : 1; } catch (e) { return 1; } };
      function wake() {
        if (ac || vol() <= 0) return;
        try {
          ac = new (window.AudioContext || window.webkitAudioContext)();
          noise = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
          const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
          crowd = ac.createBufferSource(); crowd.buffer = noise; crowd.loop = true;
          const bp = ac.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 900; bp.Q.value = 0.6;
          cg = ac.createGain(); cg.gain.value = 0;
          crowd.connect(bp); bp.connect(cg); cg.connect(ac.destination); crowd.start();
        } catch (e) { ac = null; }
      }
      function burst(f, dur, g, type) {
        if (!ac) return; const v = vol(); if (v <= 0) return;
        const s = ac.createBufferSource(); s.buffer = noise;
        const fl = ac.createBiquadFilter(); fl.type = type || 'lowpass'; fl.frequency.value = f;
        const gn = ac.createGain(), t = ac.currentTime;
        gn.gain.setValueAtTime(g * v, t); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        s.connect(fl); fl.connect(gn); gn.connect(ac.destination); s.start(t); s.stop(t + dur + 0.02);
      }
      function tone(f, dur, g) {
        if (!ac) return; const v = vol(); if (v <= 0) return;
        const o = ac.createOscillator(), gn = ac.createGain(), t = ac.currentTime;
        o.type = 'triangle'; o.frequency.value = f; gn.gain.setValueAtTime(g * v, t); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        o.connect(gn); gn.connect(ac.destination); o.start(t); o.stop(t + dur + 0.02);
      }
      return {
        wake,
        hoof(dt, v) { if (!ac || v < 2) return; hoofT -= dt; if (hoofT <= 0) { hoofT = 7 / v * 0.38; burst(240, 0.07, 0.12, 'lowpass'); } },
        crowd(lv) { if (cg && ac) try { cg.gain.setTargetAtTime(lv * 0.06 * vol(), ac.currentTime, 0.4); } catch (e) {} },
        whip(q) { burst(q === 'M' || q === 'T' ? 1800 : 3200, 0.06, q === 'M' || q === 'T' ? 0.12 : 0.3, 'highpass'); },
        whoosh() { burst(700, 0.25, 0.16, 'bandpass'); },
        tick() { burst(1500, 0.03, 0.08, 'bandpass'); },
        bell() { tone(880, 0.5, 0.09); setTimeout(() => tone(1320, 0.6, 0.07), 140); },
        stop() { try { if (ac) ac.close(); } catch (e) {} ac = null; },
      };
    })();

    /* ----- horse picker ----- */
    function horseThumb(F) {
      const c = L.h('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
      c.width = 52 * dpr; c.height = 40 * dpr;
      const g = c.getContext('2d'); g.scale(dpr, dpr); g.translate(24, 37); g.scale(0.95, 0.95);
      drawHorseSide(g, HORSES[F[0]].co, 1.1);
      return c;
    }
    function pickerSeat() { if (!st) return -1; const m = api.mySeats().filter((s) => st.hs[s] < 0); return m.length ? m[0] : -1; }
    function renameSheet(F) {
      const H0 = HORSES[F[0]];
      const inp = L.h('input', { type: 'text', maxlength: String(NAME_MAX), value: myNames[F[0]] || H0.n, 'aria-label': '새 이름', class: 'hr-in' });
      const msg = L.h('div', { class: 'sub', text: '원래 이름: ' + H0.n + ' · 최대 ' + NAME_MAX + '글자 · 이 기기에 저장돼요. 이 말로 출전하면 방의 모두에게 이 이름이 보여요.' });
      const close = () => { ov.remove(); };
      const done = () => { close(); lastPickSig = ''; syncPicker(); };
      const save = () => {
        const v = cleanName(inp.value);
        if (!v) { msg.textContent = '이름을 비워 둘 수는 없어요. 원래 이름으로 돌리려면 「원래 이름」을 누르세요.'; msg.style.color = '#ee6a55'; inp.focus(); return; }
        if (v === H0.n) delete myNames[F[0]]; else myNames[F[0]] = v;
        saveNames(); api.sfx('click'); done();
      };
      inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') { e.preventDefault(); save(); } if (e.key === 'Escape') { e.preventDefault(); close(); } });
      const ov = L.h('div', { class: 'hr-ren' }, L.h('div', { class: 'box' },
        L.h('h3', { text: '✏️ 말 이름 바꾸기' }), inp, msg,
        L.h('div', { class: 'row2' },
          L.h('button', { class: 'btn', text: '원래 이름', onclick() { delete myNames[F[0]]; saveNames(); done(); } }),
          L.h('button', { class: 'btn', text: '취소', onclick: close }),
          L.h('button', { class: 'btn primary', text: '저장', onclick: save }))));
      ov.addEventListener('pointerdown', (e) => e.stopPropagation());
      pick.el.appendChild(ov);
      setTimeout(() => { try { inp.focus(); inp.select(); } catch (e) {} }, 30);
    }
    function condChips() {
      const w = WX[st.wx | 0];
      return L.h('div', { class: 'hr-cond' },
        L.h('span', { class: 'ch wx' + (st.wx | 0), text: w.i + ' ' + w.n }),
        L.h('span', { class: 'ch', text: '주로 ' + w.g }),
        L.h('span', { class: 'ch', text: SF[st.sf | 0] + ' ' + st.ln + 'm' + (st.ct === 1 ? ' · 장애물' : '') }),
        L.h('span', { class: 'ch', text: '출전 조건: ' + SF[st.sf | 0] + '·' + DB[dBand(st.ln)] + ' C 이상' }),
        st.bo === SEASON ? L.h('span', { class: 'ch', text: '시즌 1/5 · 이 말로 5경주 · 2~5경주는 출전마 적성에 맞춰 짜여요' }) : null);
    }
    /* 적성표: 잔디 A 더트 G │ 단 C 마 A 중 A 장 B — 오늘 경주에 해당하는 칸은 강조, C 미만은 빨강 */
    function aptLine(id) {
      const A = aptOf(id), sf = st.sf | 0, db = dBand(st.ln);
      const cell = (lab, g, on) => L.h('span', { class: 'g' + (on ? ' on' : '') + (g < MIN_G ? ' lo' : '') }, lab, L.h('b', { text: GR(g) }));
      return L.h('div', { class: 'apt' }, cell('잔디', A[0], sf === 0), cell('더트', A[1], sf === 1), L.h('span', { class: 'bar2' }),
        ...DBS.map((d, i) => cell(d, A[2 + i], db === i)));
    }
    /* 필터: 각질 · 거리 특기(B 이상) · 코스 유형, 정렬: 게이트 / 인기 / 오늘 적성 */
    function passF(id) {
      const H0 = HORSES[id], A = aptOf(id);
      if (pf.sty >= 0 && H0.s !== pf.sty) return false;
      if (pf.dist >= 0 && A[2 + pf.dist] < 5) return false;
      if (pf.crs === 0 && A[1] >= MIN_G) return false;
      if (pf.crs === 1 && A[0] >= MIN_G) return false;
      if (pf.crs === 2 && (A[0] < MIN_G || A[1] < MIN_G)) return false;
      if (pf.crs === 3 && !H0.j) return false;
      return true;
    }
    function filterBar(nShow, nAll) {
      const sel = (lab, key, opts) => {
        const el = L.h('select', { class: 'hr-sel' + (pf[key] !== (key === 'sort' ? 0 : -1) ? ' on' : ''), 'aria-label': lab },
          ...opts.map((o) => L.h('option', { value: String(o[0]), text: o[1] })));
        el.value = String(pf[key]);
        el.addEventListener('change', () => { pf[key] = +el.value; api.sfx('click'); buildPicker(); lastPickSig = pickSig(); });
        el.addEventListener('keydown', (e) => e.stopPropagation());
        return el;
      };
      return L.h('div', { class: 'hr-flt' },
        sel('정렬', 'sort', [[0, '↕ 번호순'], [1, '↕ 인기순'], [2, '↕ 오늘 적성순']]),
        sel('각질', 'sty', [[-1, '각질 전체']].concat(STY.map((x, i) => [i, x.n]))),
        sel('거리 특기', 'dist', [[-1, '거리 전체']].concat(DB.map((x, i) => [i, x + ' B↑']))),
        sel('코스 유형', 'crs', [[-1, '코스 전체'], [0, '잔디 전문'], [1, '더트 전문'], [2, '잔디·더트'], [3, '장애물 전문']]),
        nShow < nAll ? L.h('span', { class: 'cnt', text: nShow + '/' + nAll + '두' }) : null);
    }
    function buildPicker() {
      if (pick) { pick.el.remove(); pick = null; }
      const seat = pickerSeat();
      const waiting = st.hs.map((x, i) => (x < 0 && !st.ai[i] ? i : -1)).filter((i) => i >= 0 && !isMine(i));
      const list = L.h('div', { class: 'hr-list' });
      const bar = (lab, v) => L.h('div', { class: 'bw' }, L.h('span', { text: lab }), L.h('div', { class: 'bar' }, L.h('i', { style: { width: v * 10 + '%' } })));
      const PD = paperData();
      const fitV = (k) => aptMul(st.fld[k][0], st.ln, st.sf | 0, st.wx | 0, st.fld[k][1], st.ct)[0];
      const SORTS = [(a, b) => st.fld[a][6] - st.fld[b][6], (a, b) => PD.rk[a] - PD.rk[b], (a, b) => fitV(b) - fitV(a) || PD.rk[a] - PD.rk[b]];
      const all = st.fld.map((_, k) => k), sorted = all.filter((k) => passF(st.fld[k][0])).sort(SORTS[pf.sort] || SORTS[0]);
      if (!sorted.length) list.append(L.h('div', { class: 'hr-sep', text: '조건에 맞는 출전마가 없어요 — 필터를 「전체」로 바꿔 보세요.' }));
      sorted.forEach((k) => {
        const F = st.fld[k], H0 = HORSES[F[0]], own = st.hs.indexOf(k), nm = fName(k);
        const mk = aptMark(F[0], st.ln, st.sf | 0, st.wx | 0);
        const apt = aptLine(F[0]);
        const b = L.h('button', { class: 'pk', 'aria-label': nm + ' ' + STY[F[5]].n + ' 적성 ' + mk + (own >= 0 ? ' (선택됨)' : ''), disabled: seat < 0 || own >= 0 },
          L.h('div', { class: 'in' }, horseThumb(F),
            L.h('div', { class: 'nmw' }, L.h('span', { class: 'gt', text: String(F[6] + 1) }), L.h('span', { class: 'nm', text: nm }), L.h('span', { class: 'sty', text: STY[F[5]].n }),
              F[1] !== 1 ? L.h('span', { class: 'cd c' + F[1], text: CND[F[1]] }) : null),
            L.h('div', { class: 'mk m' + '◎○△▽'.indexOf(mk) }, mk, L.h('small', { class: 'pop' + (PD.rk[k] < 3 ? ' t3' : ''), text: (PD.rk[k] + 1) + '인기' })),
            apt),
          L.h('div', { class: 'bars' }, bar('속도', F[2]), bar('지구력', F[3]), bar('순발력', F[4])),
          L.h('div', { class: 'ft', text: H0.f + (H0.hv !== 1 ? ' · 무거운 주로 ' + (H0.hv === 2 ? '강함' : '약함') : '') }),
          own >= 0 ? L.h('span', { class: 'own', style: { background: P(own).color }, text: isMine(own) ? '나' : String(own + 1) }) : null);
        b.onclick = () => { const se = pickerSeat(); if (se < 0 || !st || st.ph !== 'pick') return; api.sfx('click'); api.buzz(12); api.actAs(se, { type: 'pick', f: k, nm: myNames[F[0]] || '' }); };
        const ed = L.h('button', { class: 'ed', 'aria-label': H0.n + ' 이름 바꾸기', text: '✏️', onclick() { api.sfx('click'); renameSheet(F); } });
        list.append(L.h('div', { class: 'hr-hc' + (own >= 0 ? ' taken' : '') }, b, ed));
      });
      if (seat >= 0) { // 오늘 적성 미달로 못 나오는 명마(흐리게 + 이유) — 왜 이 말들만 나왔는지 보여 주기
        const inField = new Set(st.fld.map((F) => F[0]));
        const out = HORSES.map((_, i) => i).filter((i) => !inField.has(i) && !elig(i, st.ln, st.sf | 0) && passF(i));
        let sd = (st.sd | 0) >>> 0; const rr = () => { sd = (Math.imul(sd ^ (sd >>> 15), 2246822519) + 0x9e3779b9) >>> 0; return sd; };
        for (let i = out.length - 1; i > 0; i--) { const j = rr() % (i + 1); const t = out[i]; out[i] = out[j]; out[j] = t; }
        if (out.length) list.append(L.h('div', { class: 'hr-sep', text: '출전 불가 · 적성 C 미만 (' + out.length + '두 중 ' + Math.min(4, out.length) + '두)' }));
        out.slice(0, 4).forEach((id) => {
          const H0 = HORSES[id];
          list.append(L.h('div', { class: 'hr-hc off', 'aria-label': H0.n + ' 출전 불가: ' + inelig(id, st.ln, st.sf | 0) },
            L.h('div', { class: 'pk' }, L.h('div', { class: 'in' }, horseThumb([id]),
              L.h('div', { class: 'nmw' }, L.h('span', { class: 'nm', text: myNames[id] || H0.n }), L.h('span', { class: 'sty', text: STY[H0.s].n })),
              L.h('div', { class: 'mk m3', text: '✕' }), aptLine(id)),
              L.h('div', { class: 'why', text: '출전 불가 — ' + inelig(id, st.ln, st.sf | 0) + ' (C 이상 필요)' }))));
        });
      }
      const title = L.h('h3', { text: seat >= 0 ? '출전마 고르기' + (api.mySeats().length > 1 ? ' · ' + nameOf(seat) : '') : '출전마 고르는 중' });
      const sub = L.h('div', { class: 'sub' });
      sub.innerHTML = seat >= 0 ? '<b>A~G</b> 적성 등급(금색 = 오늘 경주) · <b>◎○△▽</b> 오늘 종합(모두 출전 가능, ▽ = 불리) · 앞 숫자 = 후보 번호(작을수록 안쪽 게이트) · ✏️ 이름 · <b>후보 ' + st.fld.length + '두 중 ' + gateCount(st) + '두 출전</b>: 사람이 모두 고르면 AI가 남은 말에서 고르고, 나머지 자리는 남은 말이 자동 출전마로 채워요' : '다른 사람이 고르는 중… (' + waiting.map(nameOf).join(', ') + ')';
      const kids = [L.h('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '6px' } }, title,
        L.h('button', { class: 'btn', style: { minHeight: '44px', padding: '0 10px', fontSize: '13px', flex: 'none' }, text: '📰 출주표', onclick() { api.sfx('click'); openPaper(); } })), condChips(), sub, filterBar(sorted.length, all.length), list];
      const el = L.h('div', { class: 'hr-pick' }, kids);
      if (api.online) api.pickBar({ parent: el, style: { position: 'relative', left: 'auto', bottom: 'auto', transform: 'none', alignSelf: 'center', flex: 'none' }, picked: (i) => !!(st && st.hs[i] >= 0), onForce: () => { if (st && st.ph === 'pick') api.setState(autoPick(st)); } });
      el.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(el);
      pick = { el };
    }
    function pickSig() { return st.rd + '|' + st.hs.join(',') + '|' + pickerSeat() + '|' + JSON.stringify(st.cn || {}); }
    function syncPicker() {
      if (!st || st.ph !== 'pick') { dropPicker(); return; }
      // 버그 수정: 예전에는 buildPicker가 dropPicker로 서명을 지워서 매 프레임 다시 만들어졌고, 버튼이 눌리기 전에 사라졌다
      const sig = pickSig();
      if (pick && sig === lastPickSig) return;
      if (pick && pick.el.querySelector('.hr-ren')) return; // 이름 바꾸는 중에는 그대로
      const hadNp = !!(pick && pick.el.querySelector('.hr-np'));
      buildPicker(); lastPickSig = sig;
      const nk = st.rid + '.' + st.rd;
      if (npSeen !== nk || hadNp) { npSeen = nk; openPaper(); } // 경주마다 처음 한 번은 신문부터
    }
    /* ----- 출주표 신문 (정보용 · 내기 없음). 모든 기기가 같은 지면을 보도록 문구 선택은 st.sd로 고정 ----- */
    let npSeen = '';
    function paperData() {
      const sc = st.fld.map((F) => { const m = aptMul(F[0], st.ln, st.sf | 0, st.wx | 0, F[1], st.ct); return (F[2] * 1.3 + F[3] * (st.ln / 1200) * 0.8 + F[4] * 0.6) * (1 + (m[0] - 1) * 6) / (1 + (m[1] - 1) * 2); });
      const mx = Math.max(...sc), ex = sc.map((v) => Math.exp((v - mx) / 3)), sm = ex.reduce((a, b) => a + b, 0);
      const ord = sc.map((_, k) => k).sort((a, b) => sc[b] - sc[a]);
      const rk = []; ord.forEach((k, i) => { rk[k] = i; });
      const odds = ex.map((e) => Math.max(1.3, Math.min(99.9, Math.round(0.8 / (e / sm) * 10) / 10)));
      return { ord, rk, odds };
    }
    /* ----- 실황 중계 · AI 서술(round 47 L.ai) -----
       중계 줄은 호스트가 고르고 hostSend(cm)로 보낸다 · 신문 AI 글(st.np)과 마무리 한 줄(st.cl)은 호스트가 상태에 넣는다 → 모두 같은 글. */
    const cName = (i) => { const k = kOf(i), F = st && st.fld && st.fld[k]; return F ? (st.cn && st.cn[k]) || HORSES[F[0]].n : '?'; }; // 모든 기기 같은 이름(이 기기 별명 제외)
    function runPop() { // 경주 번호별 인기 순위(0 = 1번 인기)
      if (!st || !st.fld || !R) return [];
      const D = paperData(), ix = R.hs.map((_, i) => i).sort((a, b) => (D.rk[kOf(a)] | 0) - (D.rk[kOf(b)] | 0)), out = [];
      ix.forEach((i, r) => { out[i] = r; }); return out;
    }
    const cmInfo = () => ({ name: cName, names: R.hs.map((_, i) => cName(i)), pop: cmPop, pool: cmPool && cmPool.k === key ? cmPool.p : null });
    const aiOn = () => { try { return !!(L.ai && L.ai.enabled && L.ai.enabled('horserace')); } catch (e) { return false; } };
    function parseJ(r) { if (r && typeof r === 'object') return r; try { const t = String(r || ''), a = t.indexOf('{'), b = t.lastIndexOf('}'); return a >= 0 && b > a ? JSON.parse(t.slice(a, b + 1)) : null; } catch (e) { return null; } }
    const CM_SYS = '너는 한국 경마 실황 중계 캐스터다. 문장은 짧고 힘 있게, 현재형으로. 말 이름을 자주 부른다. ' +
      '번역투 금지(…하는 중입니다, …것입니다, …에 있어서, …되어지다). 느낌표는 한 줄에 하나까지, 전체 줄의 4분의 1 이하. ' +
      '한 줄 8~30자. 이모지·따옴표·영어·괄호 설명 금지. 같은 표현을 되풀이하지 말고 줄마다 말투를 바꾼다. ' +
      '자리표: 주인공 말은 {A}, 상대 말은 {B}. 조사는 반드시 {A:이}(이/가) {A:은}(은/는) {A:을}(을/를) {A:와}(와/과) {A:로}(으로/로) 꼴로 쓴다. ' +
      '어떤 말의 특징(각질·컨디션·인기)을 살린 줄에는 그 말 이름을 그대로 써도 된다(그 말이 주인공일 때만 쓰인다). 경주 결과나 숫자는 지어내지 않는다.';
    const SIT = { start: '출발 직후', early: '초반 자리 잡기(선두 {A}, 2번째 {B})', call: '중반 순위 소개(선두 {A}, 2번째 {B})', back: '맨 뒤의 {A}', move: '{A}가 순위를 올림({B}를 따라잡음)',
      lead: '선두 교체({A}가 {B}를 넘음)', corner: '마지막 코너(선두 {A}, 추격 {B})', kick: '마지막 직선 진입(선두 {A}, 2번째 {B})', close: '뒤에서 {A}가 무서운 끝걸음({B}를 쫓음)',
      upset: '인기 없는 {A}가 막판 선두', favfade: '1번 인기 {A}가 막판에 뒤처짐', f200: '남은 200m(선두 {A}, 추격 {B})', tight: '{A}와 {B} 나란히 접전', crash: '{A}가 장애물에 걸림',
      jump: '{A}가 장애물을 깔끔히 넘음', photo: '{A}와 {B} 거의 동시 골인, 사진 판정', fin: '{A} 1착 골인' };
    const NP_SCHEMA = (() => { const lp = {}; CM_KEYS.forEach((k) => { lp[k] = { type: 'array', items: { type: 'string' } }; });
      return { type: 'object', properties: { head: { type: 'string' }, pace: { type: 'string' }, pick: { type: 'string' }, lines: { type: 'object', properties: lp, required: CM_KEYS, additionalProperties: false } }, required: ['head', 'pace', 'pick', 'lines'], additionalProperties: false }; })();
    function aiPrep() {
      if (!host() || !st || !st.fld || st.ph === 'done' || st.ph === 'end') return;
      const k0 = curKey(); if (!k0 || aiJob === k0 || !aiOn()) return;
      aiJob = k0;
      const D = paperData(), runners = st.ph === 'pick' ? D.ord.slice(0, Math.min(D.ord.length, 16)) : st.hs.concat(st.bt || []).filter((k) => k >= 0).sort((a, b) => D.rk[a] - D.rk[b]);
      const dark = darkOf(D), pace = paceTxt(D);
      const rows = runners.map((k) => { const F = st.fld[k]; return '- ' + (F[6] + 1) + '번 ' + fNameS(k) + ' · ' + STY[F[5]].n + ' · 컨디션 ' + CND[F[1]] + ' · ' + (D.rk[k] + 1) + '번 인기(' + D.odds[k].toFixed(1) + '배) · 오늘 적성 ' + aptMark(F[0], st.ln, st.sf | 0, st.wx | 0); }).join('\n');
      const prompt = '오늘 경주: ' + condTxt(st) + '\n경마장: ' + vnLine(st) + '\n출전 후보(인기순):\n' + rows +
        '\n\n자료로 본 예상 전개: ' + pace + '\n오늘의 주목마: ' + fNameS(dark) + ' — ' + comment(dark, D.rk[dark], (a) => a[0]) +
        '\n\n1) head: 경마 신문 1면 제목 한 줄(20자 이내, 1번 인기와 오늘 조건을 살려).\n2) pace: 예상 전개 2문장(90자 이내, 위 자료와 어긋나지 않게).\n3) pick: 주목마 ' + fNameS(dark) + '의 기자 한 줄 평(60자 이내).\n' +
        '4) lines: 아래 상황마다 실황 중계 줄 5~7개. 대부분은 {A}/{B} 자리표로, 일부는 위 말 이름을 직접 넣어 그 말다운 줄로.\n' + CM_KEYS.map((k) => '- ' + k + ': ' + SIT[k]).join('\n');
      L.ai.ask({ tier: 'fast', system: CM_SYS, prompt, maxTokens: 2600, json: NP_SCHEMA, timeout: 25000 }).then((r) => {
        const o = parseJ(r); if (!o || curKey() !== k0) return;
        const pool = cleanPool(o); if (pool) cmPool = { k: k0, p: pool };
        const one = (t, mx) => { const x = cleanCm(t, mx); return x && !badCm(x, []) && !/\{/.test(x) ? x : ''; };
        const np = { k: k0, h: one(o.head, 30), p: one(o.pace, 110), d: one(o.pick, 80) };
        if ((np.h || np.p || np.d) && st && curKey() === k0 && st.ph !== 'end' && st.ph !== 'done') api.setState(Object.assign({}, st, { np }));
      }, () => {});
    }
    const mTxtEnd = (m10) => { const t = marginTxt(m10); return t === '대차' ? '큰' : t.replace(' 차이', ''); };
    function closingData() { return st && st.fin ? endLineData(st.fin, cName, cmPop.length ? cmPop : runPop(), (st.sd | 0) + st.rd * 7, mTxtEnd) : ''; }
    function closingText() {
      if (!st || st.ph !== 'end') return '';
      if (st.cl && st.cl.k === key && st.cl.t) return st.cl.t + ' ✦';
      if (host() && clLive) return clLive;
      return closingData();
    }
    function aiClose() {
      clLive = '';
      if (!host() || !st || !st.fin || !st.fin[0] || clJob === key || !aiOn()) return;
      const k0 = key; clJob = k0;
      const f = st.fin, pop = cmPop.length ? cmPop : runPop();
      const facts = f.slice(0, 3).map((x, r) => (r + 1) + '착 ' + cName(x[0]) + ' (' + ((pop[x[0]] | 0) + 1) + '번 인기' + (r ? ', 앞 말과 ' + marginTxt(x[2]) : ', ' + fmtT(x[1])) + ')').join('\n');
      const recent = cm.recT.slice();
      L.ai.ask({ tier: 'fast', system: CM_SYS.replace(/자리표:[^.]*\.[^.]*\./, '') + ' 지금은 결승 직후 마무리 한 줄만 쓴다. 자리표 없이 실제 말 이름으로.', maxTokens: 160, timeout: 7000,
        prompt: condTxt(st) + ' 결과:\n' + facts + '\n\n결과를 정리하는 캐스터의 마무리 한 줄(45자 이내). 순위·착차는 위 사실 그대로.',
        stream: (t) => { if (key === k0) { const x = cleanCm(t, 70); if (x) clLive = x + ' ✦'; } } }).then((r) => {
        const x = cleanCm(typeof r === 'string' ? r : '', 70);
        if (!x || badCm(x, recent) || /\{/.test(x) || !x.includes(cName(f[0][0])) || key !== k0 || !st || st.ph !== 'end') { if (key === k0) clLive = ''; return; }
        clLive = x + ' ✦';
        api.setState(Object.assign({}, st, { cl: { k: k0, t: x } }));
      }, () => { if (key === k0) clLive = ''; });
    }
    const fNameS = (k) => { const F = st && st.fld && st.fld[k]; return F ? (st.cn && st.cn[k]) || HORSES[F[0]].n : '?'; };
    function darkOf(D) { const mid = D.ord.slice(3, 6).filter((k) => '◎○'.includes(aptMark(st.fld[k][0], st.ln, st.sf | 0, st.wx | 0)) || st.fld[k][1] === 2); return mid.length ? mid[0] : D.ord[1]; }
    /* 예상 전개(자료): 인기 상위 출전 후보의 각질로 흐름을 본다 */
    function paceTxt(D) {
      const top = D.ord.slice(0, Math.min(D.ord.length, Math.max(6, st.n + (st.bt || []).length))), ni = top.filter((k) => st.fld[k][5] === 0), se = top.filter((k) => st.fld[k][5] === 1);
      const vb = vnBias(st.vn | 0, st.sf | 0);
      let t;
      if (ni.length >= 2) t = '도주마 ' + ni.slice(0, 2).map(fNameS).join('·') + '이(가) 겹쳐 앞이 빠르게 흐를 듯. 뒤에서 기다린 말에게 기회가 온다.';
      else if (ni.length === 1 && se.length <= 1) t = fNameS(ni[0]) + ' 혼자 앞에 나서는 느린 흐름 예상. 그대로 도망칠 수 있다.';
      else if (!ni.length) t = '확실한 도주마가 없어 느린 흐름. ' + (se.length ? fNameS(se[0]) + ' 등 선행마가 편하다.' : '자리싸움이 승부.');
      else t = '평균 흐름 예상. 선두는 ' + fNameS(ni[0]) + ', 승부는 마지막 직선.';
      return t.replace(/이\(가\)/, () => (hasBatchim(fNameS(ni[1] != null ? ni[1] : ni[0])) ? '이' : '가')) + (vb < 0 ? ' 직선이 짧아 앞쪽이 유리.' : vb > 0 ? ' 긴 직선, 추입도 닿는다.' : '');
    }
    const STYC = [['처음부터 앞으로 나설 것', '혼자 달아나는 그림이 유력'], ['앞쪽 좋은 자리를 잡을 것', '선두권에서 흐름을 만들 듯'], ['중단에서 힘을 아낄 것', '무리 속에서 기회를 노릴 것'], ['뒤에서 막판 한 방을 노린다', '마지막 직선의 끝걸음이 무기']];
    function comment(k, rank, pr) {
      const F = st.fld[k], H0 = HORSES[F[0]], gw = st.wx | 0, mk = aptMark(F[0], st.ln, st.sf | 0, gw);
      const A = aptOf(F[0]), db = dBand(st.ln), gd = A[2 + db], gr = A[st.sf ? 1 : 0], fit = gd >= 5;
      const near = gd < 5 ? (db > 0 && A[1 + db] > gd ? -1 : db < 3 && A[3 + db] > gd ? 1 : 0) : 0;
      const bits = [pr(STYC[F[5]])];
      if (!fit) bits.push(near > 0 ? '거리가 짧아 보인다' : near < 0 ? '거리가 길어 막판이 걱정' : DB[db] + ' 적성 C, 버틸 수 있을까');
      else if (mk === '◎') bits.push(pr(['오늘 조건이 딱 맞다', '거리·주로 모두 안성맞춤']));
      if (gr <= 4) bits.push((st.sf ? '더트' : '잔디') + ' 경험이 부족');
      if (gw >= 2) bits.push(H0.hv === 2 ? '무거운 주로는 오히려 반갑다' : H0.hv === 0 ? '젖은 주로가 최대 변수' : '');
      if (F[1] === 2) bits.push(pr(['조교 움직임이 가볍다', '컨디션 최고조']));
      else if (F[1] === 0) bits.push(pr(['몸이 무거워 보인다', '컨디션 회복이 관건']));
      const vb = vnBias(st.vn | 0, st.sf | 0);
      if (vb < 0 && F[5] === 3) bits.push('짧은 직선에서 닿을까');
      else if (vb < 0 && F[5] <= 1) bits.push('짧은 직선은 앞쪽에 유리');
      else if (vb > 0 && F[5] === 0) bits.push('긴 직선에서 버틸 수 있을까');
      else if (vb > 0 && F[5] === 3) bits.push('긴 직선이 반갑다');
      if (F[6] === 0) bits.push('최내측 게이트 이점');
      else if (F[6] >= st.fld.length - 1 && st.fld.length > 4) bits.push('바깥 게이트가 부담');
      const s = bits.filter(Boolean).slice(0, 3).join(', ');
      return s + (rank === 0 ? '. 본지 본명.' : rank >= st.fld.length - 2 ? '. 이변의 주인공이 될까.' : '.');
    }
    function openPaper() {
      if (!pick || pick.el.querySelector('.hr-np')) return;
      let seed = (st.sd | 0) >>> 0;
      const pr = (a) => { seed = (Math.imul(seed ^ (seed >>> 15), 2246822519) + 0x9e3779b9) >>> 0; return a.length ? a[seed % a.length] : ''; };
      const D = paperData(), MK = ['◎', '○', '▲', '△', '△'];
      const w = WX[st.wx | 0], top = D.ord[0];
      // 오늘의 주목마: 인기 4~6위 중 조건이 잘 맞거나 호조인 말(없으면 2번 인기)
      const dark = darkOf(D), np = st.np && st.np.k === curKey() ? st.np : null;
      const sea = st.bo === SEASON && st.sch;
      const rows = st.fld.map((_, k) => k).sort((a, b) => st.fld[a][6] - st.fld[b][6]).map((k) => {
        const F = st.fld[k], rnk = D.rk[k], own = st.hs.indexOf(k);
        const seasonTag = sea && st.rd > 1 && own >= 0 ? ' · 시즌 ' + st.pts[own] + '점' : '';
        return L.h('tr', {}, L.h('td', { class: 'mk', text: MK[rnk] || '' }), L.h('td', { class: 'ni' + (rnk < 3 ? ' t3' : ''), text: String(rnk + 1) }),
          L.h('td', {}, L.h('b', { text: (F[6] + 1) + ' ' + fName(k) }), L.h('span', { text: ' ' + STY[F[5]].n + ' · ' + CND[F[1]] + seasonTag + (own >= 0 ? ' · ' + nameOf(own) : '') }),
            L.h('div', { class: 'cm', text: comment(k, rnk, pr) })),
          L.h('td', { class: 'od', text: D.odds[k].toFixed(1) + '배' }));
      });
      const head = st.ln >= 2000 ? '스태미나 승부' : st.ln <= 1200 ? '눈 깜짝할 새 결판' : '스피드와 끈기의 균형';
      const kids = [
        L.h('div', { class: 'mh' }, L.h('b', { text: '경마 출주표' }), L.h('span', { text: (sea ? '시즌 ' + st.rd + '/5 · ' + (g1Of(st) >= 0 ? G1[g1Of(st)][0] + (st.rd === 5 ? ' (피날레)' : '') : '') + ' · ' : '') + vnName(st) + ' ' + SF[st.sf | 0] + ' ' + st.ln + 'm' + (st.ct === 1 ? ' 장애물' : '') + ' · ' + w.i + ' ' + w.n + ' · 주로 ' + w.g })),
        L.h('div', { class: 'cm', text: '🏟 ' + vnLine(st) }),
        L.h('div', { class: 'hd', text: np && np.h ? np.h + ' ✦' : '「' + fName(top) + '」 1번 인기 — ' + head + ((st.wx | 0) >= 2 ? ', 젖은 주로가 변수' : '') }),
        L.h('div', { class: 'pc' }, L.h('i', { text: '📈 예상 전개 ' }), np && np.p ? np.p + ' ✦' : paceTxt(D)),
        L.h('div', { class: 'pk2' }, L.h('i', { text: '★ 오늘의 주목마 ' }), L.h('b', { text: fName(dark) + ' (' + D.odds[dark].toFixed(1) + '배)' }), L.h('div', { text: np && np.d ? np.d + ' ✦' : comment(dark, D.rk[dark], pr) })),
        L.h('table', {}, L.h('tr', {}, L.h('th', { text: '예상' }), L.h('th', { class: 'ni', text: '인기' }), L.h('th', { text: '번호 · 말 · 기자 한 줄 평' }), L.h('th', { text: '배당' })), rows),
      ];
      if (sea) {
        const sched = st.sch.map((c, i) => (i + 1) + '경주 ' + (c[5] != null ? G1[c[5]][0] + ' · ' + VN[c[4] | 0].n + ' ' : '') + SF[c[2]] + ' ' + c[0] + 'm' + (c[1] ? ' 장애물' : '') + ' ' + WX[c[3]].i + (i === 4 ? ' ×2' : '')).join('\n');
        const anyPts = st.pts.some((v) => v > 0);
        const stand = anyPts ? '시즌 순위: ' + st.pts.map((v, i) => i).sort((a, b) => st.pts[b] - st.pts[a]).map((i, r) => (r + 1) + '위 ' + nameOf(i) + ' ' + st.pts[i] + '점').join(' · ') : '시즌 개막 — 고른 말로 5경주를 모두 달려요. 지구력 좋은 말이 시즌 내내 유리해요.';
        kids.push(L.h('div', { class: 'ss', text: stand + '\n' + sched }));
      }
      kids.push(L.h('div', { class: 'ft2', text: '인기 = 예상 배당이 낮은 순서(1 = 1번 인기) · ◎ 본명 ○ 대항 ▲ 단혈 △ 연하 · 예상 배당은 재미로 보는 정보예요(내기 없음).' }));
      const ov = L.h('div', { class: 'hr-np' }, L.h('div', { class: 'pp' }, kids),
        L.h('button', { class: 'btn primary block', text: '닫고 말 고르기', onclick() { api.sfx('click'); ov.remove(); } }));
      ov.addEventListener('pointerdown', (e) => e.stopPropagation());
      pick.el.appendChild(ov);
    }
    function dropPicker() { if (pick) { pick.el.remove(); pick = null; } lastPickSig = ''; }

    /* ----- events ----- */
    const hooks = {
      ev(type, seat) {
        if (host() && !rp) cm.q.push([type, seat, cm.t]);
        const me = seat >= 0 && isMine(seat);
        if (type === 'crash' && me) { say('울타리에 걸렸어요!', '#ee6a55', 1.2); api.buzz(90); shake = Math.max(shake, 1); api.sfx('thud'); }
        if (type === 'spurt') { flash = 1; api.sfx('chip'); }
        if (type === 'fin') api.sfx('win');
      },
      whip(i, mp) { // 스퍼트 연타 한 번
        if (!isMine(i)) return;
        audio.whip(mp >= 60 ? 'W' : 'O'); api.buzz(6); tapFx = 1;
        if (mp >= 95 && lastMp < 95) say('최고 속도!', '#5fd38a', 0.7);
        lastMp = mp;
      },
      fin(i) { if (isMine(i)) { api.buzz(60); say('골인!', '#e3ae45', 2); } },
      order(i, t) { ordFx[i] = { t, a: 1.6 }; if (isMine(i)) { say(ORDN[t] + '!', t === 'g' ? '#ee9a55' : t === 's' ? '#5fd38a' : '#9fc6ff', 1); api.buzz(15); audio.tick(); } },
    };

    /* ----- host flow ----- */
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'count' && phase === 'run') { api.setState(Object.assign({}, st, { ph: 'run' })); return; }
      if (st.ph === 'run' && R && raceOver(R)) { api.setState(endRace(st, order(R), R)); return; }
      if (st.ph === 'end' && !rp) { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(nextRace(st)); } }
      if (st.ph === 'pick' && api.online && pickT >= 0 && st.hs.some((x) => x < 0) && !L.pick.waiting(api.players, (i) => st.hs[i] >= 0).length) { pickT = -1e9; api.setState(autoPick(st)); } // 사람은 전원 골랐고 남은 건 AI·나간 자리
    }

    /* ----- online ----- */
    function pollHost() {
      if (!api.online || !api.isHost || !R) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < nSeat()) || simHere(s) || !o || o.k !== key) continue;
        const h = R.hs[s];
        if (h.ft >= 0) continue;
        h.push = o.p ? 1 : 0;
        if (typeof o.l === 'number' && o.l !== h.tl) { const d = Math.sign(o.l - h.tl); if (!setLane(R, s, d)) { /* refused, guest will be corrected */ } }
        if (Array.isArray(o.o) && o.o[0] !== remO[s]) { const fresh = remO[s] !== undefined || (o.o[0] | 0) > 0; remO[s] = o.o[0]; if (fresh && o.o[1] && 'gso'.includes(o.o[1])) issueOrder(R, s, o.o[1], hooks); }
        if (Array.isArray(o.j) && o.j[2] !== remJ[s]) { remJ[s] = o.j[2]; if ((o.j[0] | 0) === h.ob && !h.jr && 'PG'.includes(o.j[1])) resolveJump(R, s, o.j[1], hooks); }
        if (typeof o.w === 'number') { // 게스트 연타 수(누적) → 늘어난 만큼, 한 번에 최대 4번
          let d = (o.w | 0) - (remW[s] | 0); if (d < 0 || d > 12) d = 0;
          for (let z = 0; z < Math.min(d, 4); z++) applyMash(R, s, hooks, true);
          remW[s] = o.w | 0;
        }
      }
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !R || rp) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.h)) return;
      lastQ = hs.q;
      snaps.push({ at: now, h: hs.h }); if (snaps.length > 5) snaps.shift();
      R.t = +hs.t || R.t;
      hs.h.forEach((a, i) => {
        const h = R.hs[i]; if (!h || !Array.isArray(a)) return;
        const wasFt = h.ft;
        h.v = (a[2] | 0) / 10; h.sta = a[3] | 0; if (a[8] != null && !isMine(i)) h.mp = a[8] | 0;
        const fl = a[4] | 0;
        h.push = isMine(i) ? (padHeld ? 1 : 0) : fl & 1; h.blk = fl & 2 ? 1 : 0; h.dr = fl & 4 ? 1 : 0; h.bt = fl & 8 ? 0.3 : 0; h.st = fl & 16 ? 0.3 : 0; h.mud = fl & 64 ? 1 : 0;
        const ob = a[5] | 0, jr = ['', 'P', 'G', 'C'][(fl >> 7) & 3] || '';
        if (!isMine(i) || ob !== h.ob || jr) { h.ob = ob; if (jr || !isMine(i)) { h.jr = jr; if (jr && R.C.obs[ob] != null) h.jx = R.C.obs[ob]; } }
        if (!isMine(i) || Math.abs(h.tl - (a[7] | 0)) > 0 && !pendingLane(i)) h.tl = a[7] | 0;
        h.ft = (a[6] | 0) >= 0 ? (a[6] | 0) / 100 : -1;
        if (a[9] != null) { const oc = Math.floor((a[9] | 0) / 10), om = ' gs'[(a[9] | 0) % 10 & 3] || ' ';
          if (!isMine(i) && oc < h.oc && om.trim()) ordFx[i] = { t: om, a: 1.6 };
          if (!isMine(i) || performance.now() - oSentAt > 700) { h.oc = oc; h.om = om.trim(); h.ox = (a[9] | 0) % 10 >= 4 ? 1 : 0; } }
        if (wasFt < 0 && h.ft >= 0) hooks.fin(i);
        if (fl & 32 && h.sp0 < 0) h.sp0 = R.t;
      });
      R.slow = hs.sl ? 1 : 0;
      if (Array.isArray(hs.cm) && typeof hs.cm[1] === 'string' && (!cmCap || cmCap.id !== hs.cm[0])) cmCap = { id: hs.cm[0], t: hs.cm[1].slice(0, 60), a: hs.cm[2] ? 1 : 0, age: 0 };
      if (Array.isArray(hs.ev)) for (const e of hs.ev) if (Array.isArray(e) && e[0] > lastEv) { lastEv = e[0]; R.ev.push(e); if (R.ev.length > 4) R.ev.shift(); hooks.ev(e[1], e[2]); }
    }
    let laneSentAt = 0;
    const pendingLane = (i) => isMine(i) && performance.now() - laneSentAt < 400;
    function interp(now) {
      if (host() || !R || !snaps.length || rp) return;
      const rt = now - 110;
      let A = null, B = snaps[snaps.length - 1], k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; B = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, B.at - A.at), 0, 1.4);
      R.hs.forEach((h, i) => {
        const b = B.h[i], a = A ? A.h[i] : null;
        if (!Array.isArray(b)) return;
        h.p = a ? ((a[0] | 0) + ((b[0] | 0) - (a[0] | 0)) * k) / 10 : (b[0] | 0) / 10;
        h.l = a ? ((a[1] | 0) + ((b[1] | 0) - (a[1] | 0)) * k) / 100 : (b[1] | 0) / 100;
      });
    }
    function publish(rdt) {
      if (!api.online || !R || rp) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 15;
          hsQ = (hsQ + 1) % 100000;
          const h = R.hs.map((q) => [Math.round(q.p * 10), Math.round(q.l * 100), Math.round(q.v * 10), Math.round(q.sta),
            (q.push ? 1 : 0) | (q.blk ? 2 : 0) | (q.dr ? 4 : 0) | (q.bt > 0 ? 8 : 0) | (q.st > 0 ? 16 : 0) | (q.sp0 >= 0 ? 32 : 0) | (q.mud ? 64 : 0) | ((['', 'P', 'G', 'C'].indexOf(q.jr) & 3) << 7),
            q.ob, q.ft >= 0 ? Math.round(q.ft * 100) : -1, q.tl, Math.round(q.mp || 0), q.oc * 10 + ' gso'.indexOf(q.om || ' ') + (q.ox > 0 ? 4 : 0)]);
          api.net.hostSend({ k: key, q: hsQ, t: Math.round(R.t * 100) / 100, h, sl: R.slow, ev: R.ev.slice(-3), cm: cmCap ? [cmCap.id, cmCap.t, cmCap.a ? 1 : 0] : null });
        } else {
          const s = mySeat(); if (s < 0) return;
          const h = R.hs[s];
          const o = { k: key, p: padHeld || keyHeld() ? 1 : 0, l: h.tl, j: myJ, w: myW, o: myO };
          const sig = o.p + '|' + o.l + '|' + myJ.join(',') + '|' + myW + '|' + myO[0];
          if (sig !== lastSig) laneSentAt = o.l !== (lastSig.split('|')[1] | 0) ? performance.now() : laneSentAt;
          if (sig === lastSig && pubT > -0.4) return;
          lastSig = sig; pubT = 0; inQ = (inQ + 1) % 100000; o.q = inQ;
          api.net.publish(o);
        }
      } catch (e) {}
    }

    /* ----- rank tracking (view only, works on guests too): ▲▼ marks and overtakes ----- */
    let rkPrev = null, rkMark = [], passT = 0;
    function rankOrd() {
      if (!R) return [];
      return R.hs.map((_, i) => i).sort((a, b) => { const A = R.hs[a], B = R.hs[b]; if (A.ft >= 0 && B.ft >= 0) return A.ft - B.ft; if (A.ft >= 0) return -1; if (B.ft >= 0) return 1; return B.p - A.p; });
    }
    function trackRanks(rdt) {
      if (!R || phase !== 'run') { rkPrev = null; return; }
      const o = rankOrd(), rk = []; o.forEach((s, k) => { rk[s] = k; });
      rkMark = rkMark.map((m) => (m && m.t > 0 ? { d: m.d, t: m.t - rdt } : null));
      passT -= rdt;
      if (rkPrev && R.t > 3) {
        for (let i = 0; i < R.n; i++) {
          if (rk[i] === rkPrev[i] || R.hs[i].ft >= 0) continue;
          const d = rkPrev[i] - rk[i];
          rkMark[i] = { d, t: 1.4 };
          if (isMine(i) && d > 0) api.buzz(8);
          // a notable overtake inside the top 3 late in the race → commentary (local only)
          if (d > 0 && rk[i] <= 2 && R.hs[i].p > R.C.ln * 0.55 && passT <= 0 && (!banner || banner.age > 1.6)) {
            passT = 4; banner = { id: (R.t * 10) | 0, type: 'pass', seat: i, s2: o[rk[i] + 1] != null ? o[rk[i] + 1] : -1, age: 0 };
          }
        }
      }
      rkPrev = rk;
    }

    /* ----- main loop ----- */
    function frame(rdt, now) {
      if (!st) return;
      if (photo && photo.t < PH_T) { const t0 = photo.t; photo.t += rdt; if (t0 < PH_REV && photo.t >= PH_REV) { if (photo.won) { api.sfx('win'); api.buzz(60); } else api.sfx('chip'); flash = 0.6 * FX(); } }
      // photo-finish slow motion (scaled by the effects setting)
      const wantSlow = R && R.slow && phase === 'run' ? 1 - 0.7 * FX() : 1;
      slowK += (wantSlow - slowK) * Math.min(1, rdt * 6);
      const dt = rdt * SPD() * slowK;
      if (st.ph === 'pick') syncPicker(); else if (pick) dropPicker();
      if (R && phase === 'count' && (st.ph === 'count' || st.ph === 'run')) {
        const a = Math.ceil(cd); cd -= rdt * SPD(); const b = Math.ceil(cd);
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && (host() || st.ph === 'run')) { phase = 'run'; audio.bell(); api.buzz(25); if (host()) pushEv(R, 'start', -1, hooks); }
      }
      if (hintT > 0 && phase === 'run') hintT -= rdt;
      const s = mySeat();
      if (host()) {
        if (s >= 0 && R && R.hs[s]) R.hs[s].push = padHeld || keyHeld() ? 1 : 0;
        pollHost();
        if (R && phase === 'run' && !rp && (st.ph === 'run' || st.ph === 'count' || st.ph === 'end')) {
          acc += Math.min(dt, 0.5);
          const rem = R.hs.map((_, i) => !simHere(i));
          let n = 0;
          while (acc >= H && n < 240) {
            if (st.ph !== 'end') R.hs.forEach((h, i) => { const p = isBot(i) ? P(i) : api.players[i]; if (p && simHere(i) && (p.ai || (L.debug && L.debug.autoplay) || (!api.online && i !== s))) aiStep(R, i, aiMem[i], p.ai ? (p.lv || 2) : 2, hooks); });
            stepRace(R, H, hooks, rem); acc -= H; n++;
          }
        }
        if (R && phase === 'run' && !rp && st.ph !== 'pick') { const c = cmTick(R, cm, cmInfo(), dt); if (c) cmCap = { id: c.id, t: c.t, a: c.a, age: 0 }; }
        hostFlow(rdt * SPD());
      } else if (R) {
        pollGuest(now);
        if (phase === 'run' && st.ph === 'run') R.t += dt;
        if (st.ph === 'end' && !rp) { endT -= rdt; R.hs.forEach((h) => { h.p += Math.max(h.v, 6) * dt; }); }
        R.hs.forEach((h) => { if (h.mp > 0) h.mp *= Math.exp(-MD * dt); });
        interp(now);
      }
      if (R && !rp && phase === 'run' && st.ph === 'run') recTrace();
      if (rp) stepReplay(rdt);
      ordFx = ordFx.map((o) => (o && o.a > 0 ? { t: o.t, a: o.a - rdt } : null));
      if (fbT > 0) fbT -= rdt;
      if (tapFx > 0) tapFx = Math.max(0, tapFx - rdt * 6);
      laneTick(rdt);
      { const m = s >= 0 && R && R.hs[s] ? R.hs[s].mp || 0 : 0; if (m < lastMp) lastMp = m; }
      if (flash > 0) flash = Math.max(0, flash - rdt * 1.4);
      if (shake > 0) shake = Math.max(0, shake - rdt * 3);
      if (R && R.ev.length) { const e = R.ev[R.ev.length - 1]; if (e[0] !== shownEv && (!banner || banner.age > 1 || e[1] === 'fin' || e[1] === 'photo')) { shownEv = e[0]; const o2 = rankOrd(); banner = { id: e[0], type: e[1], seat: e[2], s2: o2[0] === e[2] ? o2[1] : o2[0], age: 0 }; } }
      trackRanks(rdt);
      if (banner) { banner.age += rdt; if (banner.age > 2.8) banner = null; }
      if (cmCap) cmCap.age += rdt;
      if (R && phase === 'run') {
        const fs = s >= 0 ? R.hs[s] : R.hs[R.lead >= 0 ? R.lead : 0];
        if (fs) { audio.hoof(rdt * slowK, fs.ft < 0 ? fs.v : 0); audio.crowd(st.ph === 'run' ? (inSpurt(R, fs) ? 1 : 0.35) : 0.2); }
        // my blocked hint
        if (s >= 0 && !rp && R.hs[s].blk && fbT <= 0 && R.hs[s].push) say(R.hs[s].oc > 0 ? '앞이 막혔어요 — ◀ ▶ 또는 「바깥으로」' : '앞이 막혔어요 — ◀ ▶ 로 빠지세요', '#e3ae45', 0.8);
      } else audio.crowd(0);
      publish(rdt);
    }

    /* ----- 경주 다시 보기: 이 기기가 본 경주를 0.1초마다 기록(호스트는 시뮬, 게스트는 받은 스냅샷) → 같은 궤적을 빠르게 재생 ----- */
    const busy = (b) => { try { if (api.setBusy) api.setBusy(b); } catch (e) {} };
    function recTrace() {
      if (R.t < trT) { trace = []; trT = -1; }
      if (trT >= 0 && R.t - trT < 0.1) return;
      trT = R.t;
      trace.push([R.t, R.hs.map((h) => [Math.round(h.p * 10), Math.round(h.l * 100), (h.blk ? 1 : 0) | (h.bt > 0 ? 2 : 0) | (h.om === 'g' ? 4 : 0) | (h.om === 's' ? 8 : 0)])]);
      if (trace.length > 3000) trace.shift();
    }
    function startReplay(spd, last) {
      if (!spd) { stopReplay(); return; }
      if (!R || trace.length < 3) return;
      const save = rp ? rp.save : { t: R.t, hs: R.hs.map((h) => ({ p: h.p, l: h.l, tl: h.tl, blk: h.blk, bt: h.bt, ft: h.ft, v: h.v, om: h.om })) };
      let t0 = trace[0][0];
      if (last) { const k = trace.findIndex((fr) => fr[1].reduce((m, a) => Math.max(m, a[0]), 0) / 10 >= R.C.spS - 40); if (k > 0) t0 = trace[k][0]; }
      rp = { t: t0, t0, spd, last, save, t1: trace[trace.length - 1][0] + 0.8 };
      cam.ok = false; zoomK = 1; banner = null;
      if (!host()) busy(true);
      api.sfx('click');
      stepReplay(0);
    }
    function stopReplay() {
      if (!rp) return;
      const sv = rp.save; R.t = sv.t; sv.hs.forEach((o, i) => Object.assign(R.hs[i], o));
      rp = null; cam.ok = false;
      if (!host()) busy(false);
    }
    function stepReplay(rdt) {
      rp.t += rdt * rp.spd;
      if (rp.t > rp.t1) { stopReplay(); return; }
      let lo = 0, hi = trace.length - 1;
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (trace[m][0] <= rp.t) lo = m; else hi = m; }
      const A = trace[lo], B = trace[hi], k = B[0] > A[0] ? clamp((rp.t - A[0]) / (B[0] - A[0]), 0, 1) : 0;
      R.t = rp.t;
      R.hs.forEach((h, i) => {
        const a = A[1][i], b = B[1][i]; if (!a || !b) return;
        const np = (a[0] + (b[0] - a[0]) * k) / 10;
        h.v = B[0] > A[0] ? (b[0] - a[0]) / 10 / (B[0] - A[0]) : h.v;
        h.p = np; h.l = (a[1] + (b[1] - a[1]) * k) / 100; h.tl = b[1] / 100;
        h.blk = a[2] & 1; h.bt = a[2] & 2 ? 0.3 : 0; h.om = a[2] & 4 ? 'g' : a[2] & 8 ? 's' : '';
        const ft = rp.save.hs[i].ft; h.ft = ft >= 0 && rp.t >= ft ? ft : -1;
        if (h.ft >= 0) h.p = Math.max(h.p, R.C.ln);
      });
    }
    function photoOn() { return !!(photo && photo.t < PH_T); }
    function layoutRbtn(W, Hh) {
      rbtn = [];
      if (!st || st.ph !== 'end' || photoOn() || trace.length < 3) return;
      if (rp) { rbtn.push({ x: W - 112, y: 96, w: 104, h: 44, lab: '■ 그만 보기', k: 'replay', go: () => { api.sfx('click'); stopReplay(); } }); return; }
      const bw = (W - 16 - 12) / 3, y = Hh - 54;
      [['▶ 다시 ×2', 2, false], ['⏩ 다시 ×4', 4, false], ['🏁 마지막 직선', 1.5, true]].forEach(([lab, sp, last], i) => rbtn.push({ x: 8 + i * (bw + 6), y, w: bw, h: 44, lab, k: i === 0 ? 'replay' : '', go: () => startReplay(sp, last) }));
    }
    function drawRbtn(W) {
      for (const b of rbtn) {
        rrect(ctx, b.x, b.y, b.w, b.h, 12); ctx.fillStyle = 'rgba(17,14,22,.9)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.7)'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.font = '700 12.5px ' + FONT; txt(fit(b.lab, b.w - 8), b.x + b.w / 2, b.y + b.h / 2 + 0.5, '#f2e9d8', ctx.font);
        if (b.k) kb(b, b.k);
      }
      if (rp) {
        const t = '↺ 다시 보기 ' + (rp.last ? '마지막 직선' : '×' + rp.spd);
        ctx.font = '700 12px ' + FONT; const tw = ctx.measureText(t).width + 18;
        rrect(ctx, 8, 105, tw, 26, 13); ctx.fillStyle = 'rgba(192,57,43,.9)'; ctx.fill(); txt(t, 8 + tw / 2, 118.5, '#fff', ctx.font);
        const pw = Math.max(40, W - 132 - tw), px = 16 + tw, f = clamp((rp.t - rp.t0) / Math.max(0.1, rp.t1 - rp.t0), 0, 1);
        rrect(ctx, px, 115, pw, 6, 3); ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fill();
        rrect(ctx, px, 115, Math.max(6, pw * f), 6, 3); ctx.fillStyle = '#e3ae45'; ctx.fill();
      }
      void W;
    }

    /* ----- drawing ----- */
    function txt(t, x, y, col, font, align, base) {
      ctx.font = font; ctx.textAlign = align || 'center'; ctx.textBaseline = base || 'middle'; ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function draw(now) {
      cv.clear();
      const W = cv.w, Hh = cv.h;
      ctx.fillStyle = '#141019'; ctx.fillRect(0, 0, W, Hh);
      if (!st || !R) return;
      ctx.save();
      if (shake > 0) { const k = shake * 5 * FX(); ctx.translate((Math.random() - 0.5) * k, (Math.random() - 0.5) * k); }
      drawRace(now, W, raceH);
      ctx.restore();
      if (btn.pad) drawControls(now, W, Hh); else drawBoard(W, Hh);
      if (flash > 0 && FX() > 0) { ctx.fillStyle = 'rgba(255,236,190,' + (flash * 0.28 * FX()) + ')'; ctx.fillRect(0, 0, W, raceH); }
    }
    function camTarget() {
      const s = mySeat();
      if (s >= 0) return R.hs[s];
      const o = rankOrd().filter((i) => R.hs[i].ft < 0);
      if (!o.length) { let b = R.hs[0]; for (const h of R.hs) if (h.p > b.p) b = h; return b; }
      const a = R.hs[o[0]], b = o[1] != null ? R.hs[o[1]] : a;
      if (a.p >= R.C.spS && a.p - b.p < 12) return { p: (a.p + b.p) / 2, l: (a.l + b.l) / 2 }; // 직선 승부: 두 마리를 함께
      return a;
    }
    let zoomK = 1;
    function drawRace(now, W, Hh) {
      const C = R.C, tg = camTarget();
      const off = laneOff(clamp(tg.l, 0, R.NL - 1) * 0.7 + (R.NL - 1) * 0.15);
      const pc = Math.min(tg.p + 6, C.N - 2), P0 = posAt(C, pc, off);
      if (!cam.ok) { cam = { x: P0[0], y: P0[1], h: P0[2], ok: true }; }
      cam.x += (P0[0] - cam.x) * 0.25; cam.y += (P0[1] - cam.y) * 0.25;
      let dh = P0[2] - cam.h; cam.h += dh * 0.08;
      const lead = R.hs.reduce((m, h) => Math.max(m, h.ft < 0 ? h.p : 0), 0);
      const wantZ = phase === 'run' && st.ph === 'run' && (tg.p >= C.spS || lead >= C.ln - 220) ? 1.22 : 1;
      zoomK += (wantZ - zoomK) * 0.03;
      const sc = clamp(W / ((R.NL * LW + 6) * 1.5), 8, 17) * zoomK;
      const ax = W / 2, ay = Hh * 0.66;
      const rot = -Math.PI / 2 - cam.h;
      const W2S = (x, y) => { const dx = x - cam.x, dy = y - cam.y, c = Math.cos(rot), s2 = Math.sin(rot); return [ax + (dx * c - dy * s2) * sc, ay + (dx * s2 + dy * c) * sc]; };
      ctx.save();
      ctx.beginPath(); ctx.rect(0, 0, W, Hh); ctx.clip();
      // infield / grounds
      const gg = ctx.createLinearGradient(0, 0, 0, Hh); gg.addColorStop(0, '#1d2a1f'); gg.addColorStop(1, '#22331f'); ctx.fillStyle = gg; ctx.fillRect(0, 0, W, Hh);
      ctx.translate(ax, ay); ctx.rotate(rot); ctx.scale(sc, sc); ctx.translate(-cam.x, -cam.y);
      const span = Math.hypot(W, Hh) / sc * 0.75;
      const p0 = Math.max(0, Math.floor(tg.p - span)), p1 = Math.min(C.N - 1, Math.ceil(tg.p + span));
      const ow = R.NL * LW + 1.4;
      const band = (a, b, col) => {
        ctx.beginPath();
        for (let p = p0; p <= p1; p += 2) { const q = posAt(C, p, a); p === p0 ? ctx.moveTo(q[0], q[1]) : ctx.lineTo(q[0], q[1]); }
        for (let p = p1; p >= p0; p -= 2) { const q = posAt(C, p, b); ctx.lineTo(q[0], q[1]); }
        ctx.closePath(); ctx.fillStyle = col; ctx.fill();
      };
      band(-6, ow + 9, '#263a25');
      const turf = R.sf === 0, wet = R.gw;
      band(0, ow, turf ? ['#3d7a3c', '#376f37', '#30632f', '#2a5729'][wet] : ['#a07a4e', '#8d6a43', '#77593a', '#634a31'][wet]);
      // mowing stripes / furrows
      for (let p = Math.ceil(p0 / 8) * 8; p < p1; p += 16) {
        ctx.beginPath(); for (let q = p; q <= Math.min(p + 8, p1); q += 2) { const a = posAt(C, q, 0); q === p ? ctx.moveTo(a[0], a[1]) : ctx.lineTo(a[0], a[1]); }
        for (let q = Math.min(p + 8, p1); q >= p; q -= 2) { const a = posAt(C, q, ow); ctx.lineTo(a[0], a[1]); }
        ctx.closePath(); ctx.fillStyle = turf ? 'rgba(255,255,255,.05)' : 'rgba(40,25,10,.16)'; ctx.fill();
      }
      // faint lane guides
      ctx.lineWidth = 0.05; ctx.strokeStyle = 'rgba(255,255,255,.09)';
      for (let l = 1; l < R.NL; l++) { ctx.beginPath(); for (let p = p0; p <= p1; p += 4) { const q = posAt(C, p, laneOff(l) - LW / 2); p === p0 ? ctx.moveTo(q[0], q[1]) : ctx.lineTo(q[0], q[1]); } ctx.stroke(); }
      // mud patches
      for (const m of C.mud) {
        if (m.x + m.l < p0 || m.x > p1) continue;
        const a = Math.max(0, m.l0 < 0 ? 0 : laneOff(m.l0) - LW / 2 + 0.6), b = Math.min(ow, m.l1 > R.NL ? ow : laneOff(m.l1) - LW / 2 + 0.6);
        ctx.beginPath();
        for (let p = m.x; p <= m.x + m.l; p += 2) { const w = Math.sin((p - m.x) / m.l * Math.PI) * 0.6; const q = posAt(C, p, a + 0.6 - w); p === m.x ? ctx.moveTo(q[0], q[1]) : ctx.lineTo(q[0], q[1]); }
        for (let p = m.x + m.l; p >= m.x; p -= 2) { const w = Math.sin((p - m.x) / m.l * Math.PI) * 0.6; const q = posAt(C, p, b - 0.6 + w); ctx.lineTo(q[0], q[1]); }
        ctx.closePath(); ctx.fillStyle = 'rgba(58,36,18,.85)'; ctx.fill();
        ctx.strokeStyle = 'rgba(120,90,60,.5)'; ctx.lineWidth = 0.15; ctx.stroke();
      }
      // spurt zone tint
      if (C.spS < p1) band(0, ow, 'rgba(0,0,0,0)');
      // rails
      const rail = (o2, col) => { ctx.beginPath(); for (let p = p0; p <= p1; p += 2) { const q = posAt(C, p, o2); p === p0 ? ctx.moveTo(q[0], q[1]) : ctx.lineTo(q[0], q[1]); } ctx.strokeStyle = col; ctx.lineWidth = 0.22; ctx.stroke(); };
      rail(-0.1, '#efe9dc'); rail(ow + 0.1, '#efe9dc');
      // furlong poles
      for (let m = Math.ceil(p0 / 100) * 100; m < p1; m += 100) {
        if (m <= 0 || m >= C.ln) continue;
        const q = posAt(C, m, -0.5); ctx.fillStyle = (C.ln - m) % 200 === 0 ? '#c0392b' : '#efe9dc'; ctx.beginPath(); ctx.arc(q[0], q[1], 0.35, 0, 7); ctx.fill();
      }
      // fences
      for (let k = 0; k < C.obs.length; k++) {
        const x = C.obs[k]; if (x < p0 || x > p1) continue;
        const a = posAt(C, x, 0), b = posAt(C, x, ow);
        ctx.lineCap = 'round'; ctx.strokeStyle = '#2d4a24'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke();
        ctx.strokeStyle = '#4f7d3c'; ctx.lineWidth = 0.5; ctx.stroke();
        ctx.strokeStyle = '#efe9dc'; ctx.lineWidth = 0.12; ctx.beginPath(); const a2 = posAt(C, x - 0.55, 0), b2 = posAt(C, x - 0.55, ow); ctx.moveTo(a2[0], a2[1]); ctx.lineTo(b2[0], b2[1]); ctx.stroke(); ctx.lineCap = 'butt';
      }
      // start & finish & spurt marker
      const line = (p, c1, c2, w) => { const a = posAt(C, p, 0), b = posAt(C, p, ow); const n = 10; for (let i = 0; i < n; i++) { ctx.strokeStyle = i % 2 ? c2 : c1; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n); ctx.lineTo(a[0] + (b[0] - a[0]) * (i + 1) / n, a[1] + (b[1] - a[1]) * (i + 1) / n); ctx.stroke(); } };
      if (C.ln >= p0 && C.ln <= p1) { line(C.ln, '#f2e9d8', '#c0392b', 0.5); const q = posAt(C, C.ln, -1.2); ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(q[0], q[1], 0.7, 0, 7); ctx.fill(); }
      if (C.spS >= p0 && C.spS <= p1) line(C.spS, 'rgba(227,174,69,.75)', 'rgba(227,174,69,.15)', 0.18);
      if (p0 <= 1) line(0.5, 'rgba(242,233,216,.5)', 'rgba(242,233,216,.1)', 0.25);
      // horses (back to front)
      const ordD = R.hs.map((_, i) => i).sort((a, b) => R.hs[a].p - R.hs[b].p);
      const labels = [];
      for (const i of ordD) {
        const h = R.hs[i]; if (h.p < p0 - 4 || h.p > p1 + 4) continue;
        const q = posAt(C, h.p, laneOff(clamp(h.l, 0, R.NL - 1)));
        let air = 0;
        if (h.jr && h.jr !== 'C') { const u = (h.p - (h.jx - 2.6)) / 5.2; if (u > 0 && u < 1) air = Math.sin(Math.PI * u); }
        const lean = clamp((h.tl - h.l) * 0.25, -0.3, 0.3);
        drawHorseTop(ctx, q[0], q[1], q[2] + lean, HORSES[fOf(i)[0]].co, P(i).color, i, h, now, air);
        labels.push([i, q[0], q[1]]);
      }
      ctx.restore();
      drawWeather(W, Hh, now);
      // labels in screen space
      ctx.save();
      for (const [i, x, y] of labels) {
        const sp = W2S(x, y), me = isMine(i);
        const bot = isBot(i), gn = String(fOf(i)[6] + 1);
        const t = me ? '나' : bot ? gn : gn + ' ' + STL[fOf(i)[5]];
        ctx.font = '700 ' + (me ? 12 : bot ? 9 : 11) + 'px ' + FONT;
        const tw = Math.max(bot ? 14 : 0, ctx.measureText(t).width + (bot ? 6 : 10)), th = bot ? 12 : 16;
        const lx = sp[0] + (bot ? 11 : 16), ly = sp[1] - (bot ? 13 : 18);
        if (lx < -20 || lx > W + 20 || ly < 36 || ly > Hh - 34) continue;
        rrect(ctx, lx - tw / 2, ly - th / 2, tw, th, th / 2); ctx.fillStyle = me ? P(i).color : bot ? 'rgba(17,14,22,.6)' : 'rgba(17,14,22,.75)'; ctx.fill();
        if (!me) { ctx.strokeStyle = P(i).color; ctx.lineWidth = bot ? 1 : 1.5; ctx.stroke(); }
        txt(t, lx, ly + 0.5, me ? '#141019' : bot ? '#d8cfc0' : '#f2e9d8', ctx.font);
        if (bot) continue; // 자동 출전마: 번호표만(작전·막힘·▲▼ 표시는 생략해 화면을 가볍게)
        const ofx = ordFx[i];
        if (ofx && ofx.a > 0) { ctx.globalAlpha = Math.min(1, ofx.a * 2); txt({ g: '앞으로!', s: '힘 아끼기', o: '바깥으로' }[ofx.t] || '', lx, ly - 15, ofx.t === 'g' ? '#ee9a55' : ofx.t === 's' ? '#5fd38a' : '#9fc6ff', '700 10.5px ' + FONT); ctx.globalAlpha = 1; }
        else if (R.hs[i].blk && R.hs[i].ft < 0) txt('막힘', lx, ly - 14, me ? '#ee6a55' : 'rgba(238,106,85,.85)', '700 10px ' + FONT);
        const mk = rkMark[i];
        if (mk && mk.t > 0) { ctx.globalAlpha = Math.min(1, mk.t * 2); txt(mk.d > 0 ? '▲' : '▼', lx + tw / 2 + 7, ly + 0.5, mk.d > 0 ? '#5fd38a' : '#ee6a55', '700 11px ' + FONT); ctx.globalAlpha = 1; }
      }
      ctx.restore();
      drawHud(W, Hh, now);
    }
    let drops = null;
    function drawWeather(W, Hh, now) {
      const gw = R.gw;
      if (gw >= 1) { ctx.fillStyle = 'rgba(20,24,40,' + [0, 0.12, 0.2, 0.3][gw] + ')'; ctx.fillRect(0, 0, W, Hh); }
      if (gw < 2 || FX() <= 0) return;
      const n = gw === 3 ? 90 : 45;
      if (!drops || drops.length !== n) drops = Array.from({ length: n }, () => [Math.random(), Math.random(), 0.6 + Math.random() * 0.8]);
      ctx.strokeStyle = 'rgba(190,210,255,' + (gw === 3 ? 0.4 : 0.3) + ')'; ctx.lineWidth = 1; ctx.beginPath();
      const t = now / 1000;
      for (const d of drops) {
        const y = ((d[1] + t * d[2] * 1.4) % 1) * (Hh + 20) - 10, x = ((d[0] + t * 0.12) % 1) * W;
        ctx.moveTo(x, y); ctx.lineTo(x - 3, y + 11 * d[2]);
      }
      ctx.stroke();
      if (gw === 3 && Math.sin(t * 0.7) > 0.995 && FX() > 0.5) { ctx.fillStyle = 'rgba(230,230,255,.18)'; ctx.fillRect(0, 0, W, Hh); }
    }
    function drawHud(W, Hh, now) {
      const C = R.C;
      // minimap (course shape + dots), top-right
      const mw = 84, mh = 64, mx = W - mw - 8, my = 8;
      rrect(ctx, mx, my, mw, mh, 10); ctx.fillStyle = 'rgba(17,14,22,.72)'; ctx.fill();
      let x0 = 1e9, x1 = -1e9, y0 = 1e9, y1 = -1e9;
      for (let p = 0; p <= C.ln; p += 20) { x0 = Math.min(x0, C.X[p]); x1 = Math.max(x1, C.X[p]); y0 = Math.min(y0, C.Y[p]); y1 = Math.max(y1, C.Y[p]); }
      const k = Math.min((mw - 14) / Math.max(1, x1 - x0), (mh - 14) / Math.max(1, y1 - y0));
      const M = (p) => { const i = clamp(Math.round(p), 0, C.ln); return [mx + mw / 2 + (C.X[i] - (x0 + x1) / 2) * k, my + mh / 2 + (C.Y[i] - (y0 + y1) / 2) * k]; };
      ctx.beginPath(); for (let p = 0; p <= C.ln; p += 10) { const q = M(p); p ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]); }
      ctx.strokeStyle = 'rgba(242,233,216,.4)'; ctx.lineWidth = 2; ctx.stroke();
      ctx.beginPath(); for (let p = C.spS; p <= C.ln; p += 10) { const q = M(p); p === C.spS ? ctx.moveTo(q[0], q[1]) : ctx.lineTo(q[0], q[1]); } ctx.strokeStyle = '#e3ae45'; ctx.stroke();
      if (C.E) { ctx.strokeStyle = '#ee6a55'; ctx.lineWidth = 3; for (let p = 0; p < C.ln; p += 10) { if (C.E[Math.min(C.N, p + 10)] - C.E[p] > 0.04) { const a = M(p), b = M(p + 10); ctx.beginPath(); ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); ctx.stroke(); } } ctx.lineWidth = 2; }
      { const q = M(C.ln); ctx.fillStyle = '#f2e9d8'; ctx.fillRect(q[0] - 1, q[1] - 4, 2, 8); }
      txt(VN[C.vn | 0].n + (C.sg > 0 ? ' ↺' : ' ↻'), mx + mw / 2, my + mh + 9, '#ab9fb8', '700 10px ' + FONT);
      R.hs.map((_, i) => i).sort((a, b) => isMine(a) - isMine(b)).forEach((i) => { const h = R.hs[i], q = M(h.p); ctx.fillStyle = P(i).color; ctx.beginPath(); ctx.arc(q[0], q[1], isMine(i) ? 3.6 : isBot(i) ? 1.8 : 2.4, 0, 7); ctx.fill(); if (isMine(i)) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.2; ctx.stroke(); } });
      // course tag top-left
      const tag0 = WX[R.gw].i + ' ' + (st.bo === SEASON && g1Of(st) >= 0 ? G1[g1Of(st)][0] + ' · ' : '') + VN[C.vn | 0].n + ' ' + SF[R.sf] + ' ' + C.ln + 'm · ' + WX[R.gw].g;
      ctx.font = '700 12px ' + FONT; const tag = fit(tag0, W - mw - 40), tw = ctx.measureText(tag).width + 16;
      rrect(ctx, 8, 8, tw, 22, 11); ctx.fillStyle = 'rgba(17,14,22,.72)'; ctx.fill(); txt(tag, 8 + tw / 2, 19.5, '#e3ae45', ctx.font);
      // commentary
      if (cmCap && st.ph !== 'end' && !rp && phase === 'run') drawCap(W);
      // countdown
      if (phase === 'count' && (st.ph === 'count' || st.ph === 'run')) {
        const bw = Math.min(W - 40, 280), by = Math.max(40, Hh * 0.2);
        rrect(ctx, (W - bw) / 2, by, bw, 128, 16); ctx.fillStyle = 'rgba(17,14,22,.82)'; ctx.fill();
        ctx.font = '17px ' + DISP; txt(fit((g1Of(st) >= 0 ? G1[g1Of(st)][0] + ' · ' : '') + VN[C.vn | 0].n + ' ' + SF[R.sf] + ' ' + C.ln + 'm' + (C.ct === 1 ? ' 장애물' : ''), bw - 16), W / 2, by + 22, '#e3ae45', ctx.font);
        ctx.font = '700 12px ' + FONT; txt(fit(WX[R.gw].i + ' ' + WX[R.gw].n + ' · 주로 ' + WX[R.gw].g + ' · ' + (C.sg > 0 ? '좌회전' : '우회전') + ' · 직선 ' + C.stL + 'm', bw - 16), W / 2, by + 46, '#f2e9d8', ctx.font);
        const s0 = mySeat();
        if (s0 >= 0) { const F = fOf(s0); { const A = aptOf(F[0]); ctx.font = '600 12px ' + FONT; txt(fit(hName(s0) + ' · ' + SF[R.sf] + ' ' + GR(A[R.sf]) + ' · ' + DB[dBand(C.ln)] + ' ' + GR(A[2 + dBand(C.ln)]) + ' · 적성 ' + aptMark(F[0], C.ln, R.sf, R.gw), bw - 16), W / 2, by + 66, '#ab9fb8', '600 12px ' + FONT); } }
        txt(String(Math.max(1, Math.ceil(cd))), W / 2, by + 102, '#f2e9d8', '40px ' + DISP);
      }
      if ((phase === 'run' && st.ph === 'run') || rp) drawStrip(W, Hh);
      if (st.ph === 'end' && !rp) drawResults(W, Hh);
      layoutRbtn(W, Hh); drawRbtn(W);
      if (slowK < 0.9 && phase === 'run' && st.ph === 'run') { ctx.globalAlpha = (1 - slowK) * 1.2; txt('사진 판정 각', W / 2, Hh - 40, '#f2e9d8', '700 12px ' + FONT); ctx.globalAlpha = 1; ctx.strokeStyle = 'rgba(242,233,216,' + (0.5 * (1 - slowK)) + ')'; ctx.lineWidth = 6; ctx.strokeRect(3, 3, W - 6, Hh - 6); }
      void now;
    }
    /* 대열 막대: 선두(오른쪽)부터 맨 뒤까지 실제 간격대로 — 각질(도·선·차·추)별 자리 잡기가 한눈에 보여요 */
    const STL = ['도', '선', '차', '추'];
    function drawStrip(W, Hh) {
      const C = R.C, act = R.hs.map((h, i) => i).filter((i) => R.hs[i].ft < 0);
      if (!act.length) return;
      let lead = -1, last = 1e9; for (const i of act) { lead = Math.max(lead, R.hs[i].p); last = Math.min(last, R.hs[i].p); }
      const x0 = 14, x1 = W - 14, y = Hh - 16, span = Math.max(24, lead - last);
      rrect(ctx, 8, y - 13, W - 16, 26, 13); ctx.fillStyle = 'rgba(17,14,22,.72)'; ctx.fill();
      const X = (p) => x1 - 8 - (lead - p) / span * (x1 - x0 - 46);
      ctx.strokeStyle = 'rgba(242,233,216,.18)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x0 + 30, y); ctx.lineTo(x1 - 4, y); ctx.stroke();
      txt(Math.round(span) + 'm', x0 + 15, y + 0.5, '#8d829a', '600 9.5px ' + FONT);
      const ord = act.slice().sort((a, b) => R.hs[a].p - R.hs[b].p); // back first, so the front is drawn on top
      const me = mySeat(); let mx = -1;
      for (const i of ord) {
        const h = R.hs[i], x = X(h.p), mine = i === me, bot = isBot(i), r = mine ? 8 : bot ? (R.n > 12 ? 3.6 : 4.5) : 6.5;
        if (mine) continue;
        ctx.fillStyle = P(i).color; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(17,14,22,.9)'; ctx.lineWidth = 1; ctx.stroke();
        if (!bot) txt(STL[fOf(i)[5]], x, y + 0.5, '#141019', '700 8.5px ' + FONT);
      }
      if (me >= 0 && R.hs[me] && R.hs[me].ft < 0) { mx = X(R.hs[me].p); ctx.fillStyle = P(me).color; ctx.beginPath(); ctx.arc(mx, y, 8, 0, 7); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke(); txt('나', mx, y + 0.5, '#141019', '700 9.5px ' + FONT); }
      if (me >= 0 && R.hs[me].ft < 0 && mx >= 0) {
        const g = lead - R.hs[me].p, t = g < 0.5 ? '선두' : '선두와 ' + (g < 10 ? g.toFixed(1) : Math.round(g)) + 'm';
        ctx.font = '700 10.5px ' + FONT; const tw = ctx.measureText(t).width + 10, tx = clamp(mx, x0 + tw / 2, x1 - tw / 2);
        rrect(ctx, tx - tw / 2, y - 31, tw, 15, 7); ctx.fillStyle = 'rgba(17,14,22,.88)'; ctx.fill();
        txt(t, tx, y - 23, '#f2e9d8', ctx.font);
      }
      void C;
    }
    /* 실황 자막: 위쪽(미니맵 옆) 두 줄까지 · 4.5초 뒤 흐려짐(결승 줄은 끝까지) */
    function drawCap(W) {
      const fin = /골인|1착|우승|판정|해냈/.test(cmCap.t), life = fin ? 99 : 4.5;
      const a = Math.max(0, Math.min(1, cmCap.age * 5, (life - cmCap.age) * 2)); if (a <= 0) return;
      ctx.globalAlpha = a;
      ctx.font = '700 12.5px ' + FONT;
      const maxW = W - 112, lines = wrap('🎙 ' + cmCap.t + (cmCap.a ? ' ✦' : ''), maxW - 20, 2);
      const tw = Math.min(maxW, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 22), bx = 8, by = 36, bh = 10 + lines.length * 17;
      rrect(ctx, bx, by, tw, bh, 12); ctx.fillStyle = 'rgba(17,14,22,.88)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1; ctx.stroke();
      lines.forEach((l, i) => txt(l, bx + 11, by + 13.5 + i * 17, '#f2e9d8', ctx.font, 'left'));
      ctx.globalAlpha = 1;
    }
    function wrap(t, maxW, maxL) {
      const out = []; let cur = '';
      for (const w of String(t).split(' ')) { const nx = cur ? cur + ' ' + w : w; if (ctx.measureText(nx).width <= maxW || !cur) cur = nx; else { out.push(cur); cur = w; } }
      if (cur) out.push(cur);
      if (out.length > maxL) { const last = out.slice(maxL - 1).join(' '); out.length = maxL - 1; out.push(fit(last, maxW)); }
      return out.map((l) => fit(l, maxW));
    }
    function fit(t, maxW) { if (ctx.measureText(t).width <= maxW) return t; let s = t; while (s.length > 1 && ctx.measureText(s + '…').width > maxW) s = s.slice(0, -1); return s + '…'; }
    function endDur() { return (st && st.bo === SEASON ? END_T + 5 : END_T) + (isPhoto() ? PH_T : 0); }
    /* 사진 판정: 1·2착 차이가 0.05초 이하면 결승선 슬릿 사진 연출(상태 st.fin 기준 → 온라인 모두 같음) */
    const PH_T = 2.8, PH_REV = 1.5;
    function isPhoto() { const f = st && st.fin; return !!(f && f[0] && f[1] && f[0][1] >= 0 && f[1][1] >= 0 && f[1][1] - f[0][1] <= 5); }
    function drawPhoto(W, Hh) {
      const f = st.fin, a = f[0][0], b = f[1][0], t = photo.t;
      const bw = Math.min(W - 20, 340), bh = 214, bx = (W - bw) / 2, by = Math.max(68, (Hh - bh) / 2);
      rrect(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(17,14,22,.95)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      txt('사진 판정', W / 2, by + 18, '#e3ae45', '15px ' + DISP);
      const px = bx + 12, py = by + 34, pw = bw - 24, ph = 120;
      ctx.save(); ctx.beginPath(); ctx.rect(px, py, pw, ph); ctx.clip();
      // 흑백 슬릿 사진: 세로 줄무늬 배경(시간축) + 필름 노이즈
      const g = ctx.createLinearGradient(0, py, 0, py + ph); g.addColorStop(0, '#d8d8d8'); g.addColorStop(1, '#9a9a9a');
      ctx.fillStyle = g; ctx.fillRect(px, py, pw, ph);
      for (let x = 0; x < pw; x += 3) { ctx.fillStyle = 'rgba(0,0,0,' + (0.03 + 0.04 * ((x * 7919) % 13) / 13) + ')'; ctx.fillRect(px + x, py, 1, ph); }
      const cx = px + pw * 0.62, m = Math.max(0.04, f[1][2] / 10), gap = U.clamp(m * 70, 5, pw * 0.3);
      const reveal = Math.min(1, t / 0.6); // 사진이 왼쪽→오른쪽으로 인화되는 느낌
      const horse = (nose, row, shade) => {
        const y = py + 34 + row * 46;
        ctx.fillStyle = shade; ctx.beginPath();
        ctx.moveTo(nose, y); ctx.quadraticCurveTo(nose - 6, y - 10, nose - 22, y - 13); ctx.lineTo(nose - 30, y - 22); ctx.lineTo(nose - 34, y - 14);
        ctx.quadraticCurveTo(nose - 60, y - 6, nose - 90, y + 20); ctx.lineTo(nose - 140, y + 40); ctx.lineTo(nose - 150, y + 60); ctx.lineTo(nose - 70, y + 60);
        ctx.quadraticCurveTo(nose - 40, y + 20, nose - 18, y + 8); ctx.quadraticCurveTo(nose - 4, y + 7, nose, y); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.fillRect(nose - 50, y - 4, 10, 3);
      };
      horse(cx + 26 - gap, 1, '#3a3a3a'); horse(cx + 26, 0, '#1c1c1c');
      ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillRect(cx, py, 2, ph); // 결승선
      ctx.fillStyle = '#9a9a9a'; ctx.fillRect(px + pw * reveal, py, pw, ph);
      ctx.restore();
      if (t > PH_REV) {
        const k = Math.min(1, (t - PH_REV) / 0.25);
        ctx.globalAlpha = k;
        [[cx + 26, '1', P(a).color], [cx + 26 - gap, '2', P(b).color]].forEach(([x, n, c], i) => {
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(x, py); ctx.lineTo(x, py + ph); ctx.stroke(); ctx.setLineDash([]);
          ctx.fillStyle = c; ctx.beginPath(); ctx.arc(x, py + ph - 9 - i * 18, 7, 0, 7); ctx.fill();
          txt(n, x, py + ph - 9 - i * 18, '#111', '700 10px ' + MONO);
        });
        txt(fit('1착 ' + who(a), bw - 24), W / 2, by + 170, '#f2e9d8', '700 13px ' + FONT);
        txt(marginTxt(f[1][2]) + ' (' + ((f[1][1] - f[0][1]) / 100).toFixed(2) + '초)', W / 2, by + 192, '#e3ae45', '600 12px ' + FONT);
        ctx.globalAlpha = 1;
      } else txt('사진 판정 중' + '.'.repeat(1 + Math.floor(t * 3) % 3), W / 2, by + 180, '#ab9fb8', '600 13px ' + FONT);
    }
    function drawStandings(W, Hh) { // season table between races (and after the 그랑프리)
      const Hb = Hh - (trace.length > 2 ? 58 : 0);
      const n = st.n, rh = Math.min(24, (Hb - 100) / Math.max(1, n)), bw = Math.min(W - 20, 340), bh = n * rh + 64;
      const bx = (W - bw) / 2, by = Math.max(38, Math.min(68, (Hb - bh) / 2)), mul = st.rd === SEASON ? 2 : 1;
      const gain = []; (st.fin || []).forEach((f, r) => { gain[f[0]] = (PTS[r] || 0) * mul; });
      const ord = st.pts.map((p, i) => i).sort((a, b) => st.pts[b] - st.pts[a] || st.k[a][0] - st.k[b][0] || a - b);
      rrect(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(17,14,22,.93)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      txt('시즌 순위 · ' + st.rd + '/' + SEASON + '경주 후', W / 2, by + 20, '#e3ae45', '16px ' + DISP);
      const nx = st.rd < SEASON ? '다음: ' + (st.sch && st.sch[st.rd] ? (st.sch[st.rd][5] != null ? G1[st.sch[st.rd][5]][0] + ' · ' + VN[st.sch[st.rd][4] | 0].n + ' ' : '') + SF[st.sch[st.rd][2]] + ' ' + st.sch[st.rd][0] + 'm' : '') + (st.rd + 1 === SEASON ? ' (점수 2배)' : '') : '시즌 종료';
      txt(fit(nx, bw - 20), W / 2, by + 40, '#ab9fb8', '600 11.5px ' + FONT);
      ord.forEach((s, k) => {
        const y = by + 58 + rh * k + rh / 2;
        txt((k + 1) + '', bx + 16, y, k === 0 ? '#e3ae45' : '#ab9fb8', '700 13px ' + MONO);
        ctx.fillStyle = P(s).color; ctx.beginPath(); ctx.arc(bx + 34, y, 5, 0, 7); ctx.fill();
        ctx.font = (isMine(s) ? '700 ' : '600 ') + '12.5px ' + FONT;
        txt(fit(nameOf(s) + ' · ' + hName(s), bw - 140), bx + 46, y, '#f2e9d8', ctx.font, 'left');
        if (gain[s]) txt('+' + gain[s], bx + bw - 54, y, '#5fd38a', '600 11px ' + FONT, 'right');
        txt(st.pts[s] + '점', bx + bw - 12, y, '#e3ae45', '700 12.5px ' + FONT, 'right');
      });
    }
    function drawResults(W, Hh) {
      if (photo && photo.t < PH_T) { drawPhoto(W, Hh); return; }
      if (st.bo === SEASON && endT < 5.2) { drawStandings(W, Hh); return; }
      const fins = st.fin || [];
      const Hb = Hh - (trace.length > 2 ? 58 : 0);
      // 16~18두: 한 줄 22px 이상 유지, 넘치는 줄은 끌어서(휠) 스크롤 · 처음엔 내 말이 보이게
      const clT = closingText(), capH = clT ? 44 : 0;
      const rh = clamp((Hb - 110 - capH) / Math.max(1, fins.length), 22, 24), rows = Math.max(1, Math.min(fins.length, Math.floor((Hb - 110 - capH) / rh)));
      const bw = Math.min(W - 20, 340), bh = rows * rh + 48 + (rows < fins.length ? 14 : 0);
      const bx = (W - bw) / 2, by = Math.max(38, Math.min(68, (Hb - bh) / 2));
      const maxS = Math.max(0, fins.length - rows);
      if (resS.key !== key) { resS.key = key; const mi = fins.findIndex((f) => isMine(f[0])); resS.v = mi >= rows ? Math.min(maxS, mi - rows + 2) : 0; }
      resS.v = clamp(resS.v, 0, maxS); resS.box = maxS ? { x: bx, y: by, w: bw, h: bh, rh } : null;
      rrect(ctx, bx, by, bw, bh, 14); ctx.fillStyle = 'rgba(17,14,22,.93)'; ctx.fill(); ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.lineWidth = 1.5; ctx.stroke();
      const close = fins[1] && fins[1][2] < 3;
      txt((close ? '사진 판정 결과' : '착순') + ' · ' + fins.length + '두', W / 2, by + 20, '#e3ae45', '16px ' + DISP);
      const s0 = Math.round(resS.v);
      fins.slice(s0, s0 + rows).forEach((f, j) => {
        const k = s0 + j, y = by + 42 + rh * j + rh / 2, s = f[0], me = isMine(s), bot = isBot(s);
        if (me) { ctx.fillStyle = 'rgba(227,174,69,.16)'; ctx.fillRect(bx + 4, y - rh / 2 + 1, bw - 8, rh - 2); }
        ctx.fillStyle = P(s).color; ctx.beginPath(); ctx.arc(bx + 36, y, bot ? 4 : 5, 0, 7); ctx.fill();
        if (bot) { ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.stroke(); }
        txt((k + 1) + '', bx + 16, y, k === 0 ? '#e3ae45' : '#ab9fb8', '700 13px ' + MONO);
        ctx.font = (me ? '700 ' : bot ? '500 ' : '600 ') + '12.5px ' + FONT;
        txt(fit((fOf(s)[6] + 1) + ' ' + who(s), bw - 150), bx + 46, y, bot ? '#bdb3c6' : '#f2e9d8', ctx.font, 'left');
        txt(k ? marginTxt(f[2]) : fmtT(f[1]), bx + bw - 12, y, k ? '#ab9fb8' : '#e3ae45', '600 12px ' + FONT, 'right');
      });
      if (maxS) {
        const ty = by + 42, th = rows * rh, kh = Math.max(16, th * rows / fins.length), ky = ty + (th - kh) * (resS.v / maxS);
        ctx.fillStyle = 'rgba(242,233,216,.1)'; ctx.fillRect(bx + bw - 5, ty, 3, th); ctx.fillStyle = 'rgba(227,174,69,.7)'; ctx.fillRect(bx + bw - 5, ky, 3, kh);
        txt((s0 > 0 ? '▲ ' : '') + '끌어서 ' + (s0 + 1) + '–' + Math.min(fins.length, s0 + rows) + '착 / ' + fins.length + (s0 < maxS ? ' ▼' : ''), W / 2, by + bh - 9, '#8d829a', '600 10.5px ' + FONT);
      }
      if (clT) {
        ctx.font = '600 12px ' + FONT;
        const ls = wrap('🎙 ' + clT, bw - 20, 2), cy = by + bh + 6;
        rrect(ctx, bx, cy, bw, 8 + ls.length * 16, 10); ctx.fillStyle = 'rgba(17,14,22,.88)'; ctx.fill();
        ls.forEach((l, i) => txt(l, bx + 10, cy + 12 + i * 16, '#f2e9d8', ctx.font, 'left'));
      }
    }
    /* ----- controls ----- */
    function drawControls(now, W, Hh) {
      const s = mySeat(), h = R.hs[s], C = R.C;
      const y0 = raceH;
      ctx.fillStyle = '#17131e'; ctx.fillRect(0, y0, W, Hh - y0);
      ctx.fillStyle = 'rgba(227,174,69,.25)'; ctx.fillRect(0, y0, W, 1);
      // HUD row: rank · remaining · stamina gauge with "need" tick
      const rank = R.hs.filter((q, j) => j !== s && (q.ft >= 0 && (h.ft < 0 || q.ft < h.ft) || q.ft < 0 && h.ft < 0 && q.p > h.p)).length + 1;
      const mk = rkMark[s];
      txt(rank + '위', 14, y0 + 20, mk && mk.t > 0 ? (mk.d > 0 ? '#5fd38a' : '#ee6a55') : '#f2e9d8', '22px ' + DISP, 'left');
      txt('/' + R.n, 14 + ctx.measureText(rank + '위').width + 3, y0 + 23, '#ab9fb8', '600 12px ' + FONT, 'left');
      const rem = Math.max(0, Math.round(C.ln - h.p));
      txt(h.ft >= 0 ? '골인' : '남은 ' + rem + 'm', W - 12, y0 + 20, inSpurt(R, h) ? '#e3ae45' : '#ab9fb8', '700 13px ' + FONT, 'right');
      const F = fOf(s);
      ctx.font = '600 11.5px ' + FONT; txt(fit(hName(s) + ' · ' + STY[F[5]].n, W - 190), W / 2, y0 + 20, '#ab9fb8', ctx.font);
      const gx = 14, gw = W - 28, gy = y0 + 36, gh = 14;
      rrect(ctx, gx, gy, gw, gh, 7); ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fill();
      const e = clamp(h.sta / 100, 0, 1);
      const need = h.ft >= 0 ? 0 : clamp(((Math.max(0, C.spS - h.p)) * drainPm(R, s, 'cruise') + (C.ln - Math.max(h.p, C.spS)) * drainPm(R, s, 'spurt')) / 100, 0, 1);
      const col = h.sta < 12 ? (Math.sin(now / 90) > 0 ? '#ee6a55' : '#7a2d3a') : e >= need ? '#5fd38a' : '#e3ae45';
      if (e > 0.005) { rrect(ctx, gx, gy, Math.max(gh, gw * e), gh, 7); ctx.fillStyle = col; ctx.fill(); }
      if (h.ft < 0) { const nx = gx + gw * need; ctx.fillStyle = '#f2e9d8'; ctx.fillRect(nx - 1, gy - 3, 2, gh + 6); }
      txt('체력 ' + Math.round(h.sta), gx + 8, gy + gh / 2 + 0.5, '#141019', '700 10px ' + FONT, 'left');
      // tags: draft / mud
      const tags = [];
      if (h.dr) tags.push(['바람막이', '#9fc6ff']); if (h.mud) tags.push(['웅덩이', '#c98f5a']); if (h.blk) tags.push(['막힘', '#ee6a55']);
      const sl = slopeAt(C, h.p); if (h.ft < 0 && Math.abs(sl) > 0.004) tags.push(sl > 0 ? ['오르막', '#ee9a55'] : ['내리막', '#9fc6ff']);

      let tx = gx + gw - 2;
      if (rp) tags.length = 0;
      for (const [t, c] of tags) { ctx.font = '700 10px ' + FONT; const w = ctx.measureText(t).width + 10; tx -= w + 3; rrect(ctx, tx, gy - 0.5, w, 15, 7); ctx.fillStyle = 'rgba(17,14,22,.92)'; ctx.fill(); ctx.strokeStyle = c; ctx.lineWidth = 1; ctx.stroke(); txt(t, tx + w / 2, gy + 7.5, c, ctx.font); }
      // lane buttons
      const lb = (b, dir) => {
        const can = h.ft < 0 && phase === 'run';
        rrect(ctx, b.x, b.y, b.w, b.h, 14); ctx.fillStyle = can ? '#2a2236' : '#1f1a28'; ctx.fill(); ctx.strokeStyle = 'rgba(242,233,216,.16)'; ctx.lineWidth = 1.5; ctx.stroke();
        const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
        ctx.fillStyle = can ? '#f2e9d8' : 'rgba(242,233,216,.3)';
        ctx.beginPath(); ctx.moveTo(cx - dir * 10, cy - 14); ctx.lineTo(cx + dir * 12, cy); ctx.lineTo(cx - dir * 10, cy + 14); ctx.closePath(); ctx.fill();
        kb(b, dir < 0 ? 'left' : 'right');
      };
      lb(btn.L, -1); lb(btn.R, 1);
      // 작전 지시 버튼 (경주마다 ORD_N번)
      if (btn.o) {
        const OI = { g: ['▲ 앞으로', '#ee9a55'], s: ['◆ 힘 아끼기', '#5fd38a'], o: ['↗ 바깥으로', '#9fc6ff'] };
        for (const b of btn.o) {
          const live = h.ft < 0 && phase === 'run' && st.ph === 'run' && !rp, left = h.oc | 0;
          const can = live && left > 0 && !(b.t === 's' && inSpurt(R, h)), on = h.om === b.t || (b.t === 'o' && h.ox > 0);
          rrect(ctx, b.x, b.y, b.w, b.h, 12); ctx.fillStyle = on ? 'rgba(227,174,69,.22)' : can ? '#2a2236' : '#1d1825'; ctx.fill();
          ctx.strokeStyle = on ? OI[b.t][1] : can ? 'rgba(242,233,216,.22)' : 'rgba(242,233,216,.08)'; ctx.lineWidth = on ? 2 : 1.5; ctx.stroke();
          if (on && b.t !== 'o' && h.ot > 0) { ctx.fillStyle = OI[b.t][1]; ctx.fillRect(b.x + 8, b.y + b.h - 6, (b.w - 16) * clamp(h.ot / ORD[b.t], 0, 1), 3); }
          ctx.font = '700 12.5px ' + FONT; txt(fit(OI[b.t][0], b.w - 8), b.x + b.w / 2, b.y + 17, can || on ? OI[b.t][1] : 'rgba(242,233,216,.3)', ctx.font);
          txt(on ? '지시 중' : '작전 ' + left + '/' + ORD_N, b.x + b.w / 2, b.y + 33, '#8d829a', '600 10px ' + FONT);
          kb(b, 'o' + b.t);
        }
      }
      // pad
      const b = btn.pad, sp = inSpurt(R, h) && h.ft < 0 && !rp, held = padHeld || keyHeld();
      const g = ctx.createLinearGradient(0, b.y, 0, b.y + b.h);
      if (sp) { g.addColorStop(0, '#4a3418'); g.addColorStop(1, '#2d2012'); } else if (held) { g.addColorStop(0, '#3f2e52'); g.addColorStop(1, '#2b2038'); } else { g.addColorStop(0, '#2a2236'); g.addColorStop(1, '#211b2c'); }
      rrect(ctx, b.x, b.y, b.w, b.h, 16); ctx.fillStyle = g; ctx.fill();
      ctx.strokeStyle = sp ? 'rgba(227,174,69,.8)' : held ? 'rgba(242,233,216,.5)' : 'rgba(242,233,216,.16)'; ctx.lineWidth = 2; ctx.stroke();
      const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
      const tt = fenceTT(R, s);
      if (st.ph !== 'run' || phase !== 'run') {
        txt(st.ph === 'end' ? '' : '출발 대기', cx, cy, '#ab9fb8', '700 14px ' + FONT);
      } else if (h.ft >= 0) {
        txt('골인', cx, cy, '#e3ae45', '26px ' + DISP);
      } else if (rp) {
        txt('다시 보는 중', cx, cy, '#ab9fb8', '700 14px ' + FONT);
      } else if (sp) {
        // 연타 미터: 스퍼트 힘(0~100) · 체력이 적을수록 한 번에 덜 참
        const mp = clamp((h.mp || 0) / 100, 0, 1), eff = mashGain(h) / MG, pulse = tapFx;
        txt(mp >= 0.95 ? '최고 속도!' : '연타!', cx, b.y + 22 - pulse * 2, mp >= 0.95 ? '#5fd38a' : '#e3ae45', Math.round(20 + pulse * 3) + 'px ' + DISP);
        const mx = b.x + 14, mw = b.w - 28, my = cy + 4, mh = 18;
        rrect(ctx, mx, my - mh / 2, mw, mh, 9); ctx.fillStyle = 'rgba(0,0,0,.55)'; ctx.fill();
        if (mp > 0.01) { const gm = ctx.createLinearGradient(mx, 0, mx + mw, 0); gm.addColorStop(0, '#e3ae45'); gm.addColorStop(1, '#5fd38a'); rrect(ctx, mx, my - mh / 2, Math.max(mh, mw * mp), mh, 9); ctx.fillStyle = gm; ctx.fill(); }
        if (pulse > 0) { ctx.strokeStyle = 'rgba(242,233,216,' + (pulse * 0.8).toFixed(2) + ')'; ctx.lineWidth = 2; rrect(ctx, mx - 2 * pulse, my - mh / 2 - 2 * pulse, mw + 4 * pulse, mh + 4 * pulse, 10); ctx.stroke(); }
        txt('스퍼트 힘 ' + Math.round(mp * 100), cx, my + 0.5, mp > 0.45 ? '#141019' : '#f2e9d8', '700 11px ' + FONT);
        txt(fit(eff < 0.6 ? '체력이 적어 덜 차요' : '빠르게 연타! 놓으면 식어요', b.w - 12), cx, b.y + b.h - 14, eff < 0.6 ? '#ee9a55' : '#ab9fb8', '600 11px ' + FONT);
      } else if (tt >= 0 && tt <= 1.6) {
        const inW = tt <= JW;
        const r0 = Math.min(b.w, b.h) * 0.28, rc = r0 + Math.max(0, tt - 0.21) * r0 * 1.4;
        ctx.lineWidth = 4; ctx.strokeStyle = inW ? '#5fd38a' : 'rgba(242,233,216,.4)'; ctx.beginPath(); ctx.arc(cx, cy, r0, 0, 7); ctx.stroke();
        ctx.lineWidth = 3; ctx.strokeStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(cx, cy, rc, 0, 7); ctx.stroke();
        txt(inW ? '떼었다 눌러 점프!' : '울타리 ' + Math.round(R.C.obs[h.ob] - h.p) + 'm', cx, cy, inW ? '#e3ae45' : '#f2e9d8', '700 14px ' + FONT);
      } else {
        const tl = turnLoss(C, h.p, laneOff(h.l) - laneOff(0));
        ctx.font = '600 11px ' + FONT; txt(fit((Math.round(h.l) + 1) + '줄' + (tl >= 1 ? ' · 남은 코너 바깥 손해 +' + Math.round(tl) + 'm' : h.l < 0.5 ? ' · 최내측' : ''), b.w - 12), cx, b.y + 14, tl >= 4 ? '#e3ae45' : '#8d829a', ctx.font);
        txt(held ? '밀어붙이는 중' : '누르고 있으면 밀기', cx, cy - 8, held ? '#f2e9d8' : '#ab9fb8', (held ? '700 ' : '600 ') + '15px ' + FONT);
        txt(held ? '체력이 빨리 닳아요' : '떼면 페이스 유지 · 체력 아끼기', cx, cy + 14, '#7f7590', '600 11px ' + FONT);
      }
      kb(b, 'push');
      if (fbT > 0 && fbTxt && !rbtn.length && !rp) { ctx.globalAlpha = Math.min(1, fbT * 3); txt(fbTxt, W / 2, raceH - 16, fbCol, '700 14px ' + FONT); ctx.globalAlpha = 1; }
      if (hintT > 0 && phase === 'run' && st.ph === 'run') { ctx.globalAlpha = Math.min(1, hintT); const t = '하얀 눈금 = 스퍼트까지 필요한 체력 · 안쪽 주로가 코너에서 짧아요'; ctx.font = '600 11px ' + FONT; rrect(ctx, 8, raceH - 64, W - 16, 22, 11); ctx.fillStyle = 'rgba(17,14,22,.85)'; ctx.fill(); txt(fit(t, W - 30), W / 2, raceH - 53, '#ab9fb8', ctx.font); ctx.globalAlpha = 1; }
    }
    function drawBoard(W, Hh) { // spectators: standings with stamina
      const y0 = raceH; ctx.fillStyle = '#17131e'; ctx.fillRect(0, y0, W, Hh - y0);
      const ord = R.hs.map((_, i) => i).sort((a, b) => (R.hs[a].ft >= 0 && R.hs[b].ft >= 0 ? R.hs[a].ft - R.hs[b].ft : R.hs[b].p - R.hs[a].p));
      // 많을 땐 한 줄 15px 이상 유지: 위에서부터 들어가는 만큼 + 사람 자리는 아래에 따로
      const fitN = Math.max(1, Math.floor((Hh - y0 - 16) / 15)), rh = Math.min(30, (Hh - y0 - 16) / Math.min(R.n, fitN));
      let show = ord.map((i, k) => [i, k]);
      if (show.length > fitN) { const top = show.slice(0, fitN), extra = show.filter(([i, k]) => k >= fitN && !isBot(i)).slice(0, Math.max(0, fitN - 3)); show = top.slice(0, fitN - extra.length).concat(extra); }
      const fs = rh < 18 ? 11 : 12;
      show.forEach(([i, k], j) => {
        const y = y0 + 8 + rh * j, h = R.hs[i];
        txt((k + 1) + '', 16, y + rh / 2, k ? '#ab9fb8' : '#e3ae45', '700 ' + fs + 'px ' + MONO);
        ctx.fillStyle = P(i).color; ctx.beginPath(); ctx.arc(34, y + rh / 2, isBot(i) ? 4 : 5, 0, 7); ctx.fill(); if (isBot(i)) { ctx.strokeStyle = 'rgba(242,233,216,.35)'; ctx.lineWidth = 1; ctx.stroke(); }
        ctx.font = (isBot(i) ? '500 ' : '700 ') + fs + 'px ' + FONT; txt(fit(who(i), W * 0.5 - 62), 46, y + rh / 2, isBot(i) ? '#bdb3c6' : '#f2e9d8', ctx.font, 'left');
        const mk = rkMark[i]; if (mk && mk.t > 0) txt(mk.d > 0 ? '▲' : '▼', W * 0.5 - 8, y + rh / 2, mk.d > 0 ? '#5fd38a' : '#ee6a55', '700 11px ' + FONT);
        const bx = W * 0.5, bw = W * 0.5 - 16;
        rrect(ctx, bx, y + rh / 2 - 4, bw, 8, 4); ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fill();
        rrect(ctx, bx, y + rh / 2 - 4, Math.max(8, bw * h.sta / 100), 8, 4); ctx.fillStyle = h.sta < 12 ? '#ee6a55' : '#5fd38a'; ctx.fill();
      });
    }

    const stopLoop = U.loop((rdt, now) => {
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        const k = curKey();
        aiPrep();
        if (st.ph === 'pick' && prev && prev.np !== st.np && pick && pick.el.querySelector('.hr-np')) { const o = pick.el.querySelector('.hr-np'); o.remove(); openPaper(); }
        if (st.ph === 'pick') { pickT = 0; syncPicker(); if (k !== key || !R) { key = k; R = newRace(raceOpts()); phase = 'wait'; cam.ok = false; layout(); } return; }
        dropPicker();
        if (k !== key || phase === 'wait') { key = k; startRace(); }
        if (st.ph === 'run' && phase === 'count' && !host()) { phase = 'run'; cd = 0; }
        if (st.ph === 'end' && (!prev || prev.ph !== 'end')) {
          endT = endDur();
          aiClose();
          const f = st.fin || [];
          const w = f[0] ? f[0][0] : -1;
          if (isPhoto()) { photo = { t: 0, won: w >= 0 && isMine(w) }; api.sfx('click'); flash = 0.5 * FX(); }
          else {
            if (f[1] && f[1][2] < 3) { flash = 1; shake = 0.6; }
            if (w >= 0 && isMine(w)) { api.sfx('win'); api.buzz(60); } else api.sfx('chip');
          }
          if (!api.online) f.forEach((x) => {
            if (x[1] < 0 || !isMine(x[0]) || (api.players[x[0]] && api.players[x[0]].ai)) return;
            const sec = x[1] / 100;
            if (api.best('c' + st.ct + '_' + (st.sf | 0) + '_' + st.ln + '_v' + (st.vn | 0), sec, { label: vnName(st) + ' ' + SF[st.sf | 0] + (st.ct === 1 ? ' 장애물 ' : ' ') + st.ln + 'm 최고 기록', lower: true, unit: '초' })) api.toast('🏆 새 최고 기록! ' + sec.toFixed(2) + '초');
          });
        }
      },
      destroy() {
        stopLoop(); audio.stop(); if (rp && !host()) busy(false); rp = null;
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('wheel', onWheel);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        offIn();
        dropPicker(); styleEl.remove(); cv.destroy();
      },
      _dbg: () => ({ R, st, phase, btn, press, lane, setPush, startReplay, giveOrder, rp, trace }),
    };
  }

  /* ----- horse art ----- */
  function drawHorseTop(g, x, y, hd, Co, silk, idx, h, now, air) {
    const ph = h.p * 1.6 + idx;
    g.save(); g.translate(x, y); g.rotate(hd);
    const s = 1 + air * 0.18;
    // shadow
    g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.ellipse(0.1 + air * 0.5, 0.25 + air * 0.6, 1.25, 0.45, 0, 0, 7); g.fill();
    g.scale(s, s);
    if (h.st > 0) g.rotate(Math.sin(now / 60) * 0.12);
    // legs (gallop flicker)
    g.lineWidth = 0.13; g.lineCap = 'round';
    const lg = (bx, by, o) => { const a = Math.sin(ph + o) * 0.45 * (air > 0.2 ? 0.2 : 1); g.strokeStyle = shade(Co.c, -0.35); g.beginPath(); g.moveTo(bx, by); g.lineTo(bx + a, by + Math.sign(by) * 0.18); g.stroke();
      if (Co.sk) { g.fillStyle = '#f4efe6'; g.beginPath(); g.arc(bx + a, by + Math.sign(by) * 0.18, 0.07, 0, 7); g.fill(); } };
    lg(0.75, 0.32, 0); lg(0.75, -0.32, 0.7); lg(-0.75, 0.32, 2.2); lg(-0.75, -0.32, 2.9);
    // tail
    g.strokeStyle = Co.m; g.lineWidth = 0.22; g.beginPath(); g.moveTo(-1.05, 0); g.quadraticCurveTo(-1.45, Math.sin(ph * 0.5) * 0.25, -1.65, Math.sin(ph * 0.5 + 1) * 0.2); g.stroke();
    // body
    g.fillStyle = Co.c; g.beginPath(); g.ellipse(0, 0, 1.08, 0.38, 0, 0, 7); g.fill();
    if (Co.sp) { g.fillStyle = Co.m; g.globalAlpha = 0.6; for (const [a, b, r] of [[-0.5, 0.1, 0.16], [0.2, -0.15, 0.13], [0.55, 0.12, 0.1]]) { g.beginPath(); g.arc(a, b, r, 0, 7); g.fill(); } g.globalAlpha = 1; }
    // neck + head
    const nod = Math.sin(ph) * 0.05;
    g.beginPath(); g.ellipse(1.15 + nod, 0, 0.42, 0.2, 0, 0, 7); g.fill();
    g.beginPath(); g.ellipse(1.58 + nod, 0, 0.3, 0.15, 0, 0, 7); g.fill();
    g.strokeStyle = Co.m; g.lineWidth = 0.1; g.beginPath(); g.moveTo(0.75, 0); g.lineTo(1.4 + nod, 0); g.stroke();
    if (Co.bz) { g.strokeStyle = '#f4efe6'; g.lineWidth = 0.07; g.beginPath(); g.moveTo(1.45 + nod, 0); g.lineTo(1.84 + nod, 0); g.stroke(); }
    // saddle cloth + jockey
    g.fillStyle = silk; g.fillRect(-0.35, -0.42, 0.55, 0.84);
    g.fillStyle = shade(silk, -0.25); g.beginPath(); g.ellipse(0.12, 0, 0.32, 0.36, 0, 0, 7); g.fill();
    g.fillStyle = silk; g.beginPath(); g.arc(0.38, 0, 0.17, 0, 7); g.fill();
    g.fillStyle = '#f2e9d8'; g.beginPath(); g.arc(0.38, 0, 0.07, 0, 7); g.fill();
    if (h.bt > 0) { g.strokeStyle = 'rgba(255,240,200,.6)'; g.lineWidth = 0.06; for (const o of [-0.25, 0, 0.25]) { g.beginPath(); g.moveTo(-1.3, o); g.lineTo(-2.2, o); g.stroke(); } }
    g.restore();
  }
  function drawHorseSide(g, Co, ph) {
    const coat = Co.c, mane = Co.m, dark = shade(coat, -0.3);
    const leg = (hx, hy, a1, a2, col) => {
      const kx = hx + Math.sin(a1) * 8, ky = hy + Math.cos(a1) * 8, fx = kx + Math.sin(a1 + a2) * 8, fy = ky + Math.cos(a1 + a2) * 8;
      g.strokeStyle = col; g.lineWidth = 2.6; g.lineCap = 'round'; g.beginPath(); g.moveTo(hx, hy); g.lineTo(kx, ky); g.lineTo(fx, fy); g.stroke();
    };
    leg(-11, -16, 0.55 * Math.sin(ph), 0.8 * Math.max(0, Math.sin(ph - 1)), dark); leg(10, -15, 0.6 * Math.sin(ph + 1.4), -0.5, dark);
    g.strokeStyle = mane; g.lineWidth = 3.2; g.lineCap = 'round'; g.beginPath(); g.moveTo(-15, -21); g.quadraticCurveTo(-22, -22, -25, -14); g.stroke();
    g.fillStyle = coat; g.beginPath(); g.ellipse(0, -18.5, 15, 7.5, 0, 0, 7); g.fill();
    if (Co.sp) { g.fillStyle = mane; g.globalAlpha = 0.75; for (const [x, y, r] of [[-8, -21, 3], [2, -16, 2.4], [7, -20, 2]]) { g.beginPath(); g.ellipse(x, y, r, r * 0.8, 0, 0, 7); g.fill(); } g.globalAlpha = 1; }
    g.fillStyle = coat; g.beginPath(); g.moveTo(7, -23); g.lineTo(13, -33); g.lineTo(19, -31); g.lineTo(15, -16); g.closePath(); g.fill();
    g.save(); g.translate(18, -31); g.rotate(0.55); g.beginPath(); g.ellipse(4, 0, 7, 3.4, 0, 0, 7); g.fill(); g.restore();
    g.strokeStyle = mane; g.lineWidth = 2.6; g.beginPath(); g.moveTo(7.5, -25); g.lineTo(14, -34.5); g.stroke();
    if (Co.bz) { g.save(); g.translate(18, -31); g.rotate(0.55); g.fillStyle = '#f4efe6'; g.beginPath(); g.ellipse(5, -1.2, 4.2, 1, 0, 0, 7); g.fill(); g.restore(); }
    leg(-11, -16, 0.55 * Math.sin(ph + 0.45), 0.4, coat); leg(10, -15, 0.6 * Math.sin(ph + 1.85), -0.6, coat);
    if (Co.sk) { g.fillStyle = '#f4efe6'; for (const [x, y] of [[-11 + Math.sin(0.55 * Math.sin(ph + 0.45)) * 8, -3], [10 + Math.sin(0.6 * Math.sin(ph + 1.85)) * 8, -2]]) { g.beginPath(); g.arc(x, y, 1.7, 0, 7); g.fill(); } }
  }
  function rrect(c, x, y, w, h, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else c.rect(x, y, w, h); }
  function shade(hex, k) {
    const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16), f = (c) => Math.round(k >= 0 ? c + (255 - c) * k : c * (1 + k));
    return 'rgb(' + f(n >> 16) + ',' + f((n >> 8) & 255) + ',' + f(n & 255) + ')';
  }

  L.register({
    id: 'horserace', name: '경마', tag: '기수가 되어 달리는 경주', cat: '스포츠',
    blurb: '디프 임팩트·골드십·오구리 캡… 일본의 명마에 올라 직접 몰아요. 날씨·주로·거리 적성이 승부를 가르고, 누르면 밀어붙이고 떼면 체력을 아껴요. 코너는 안쪽이 짧고, 앞말 뒤에 붙으면 바람막이, 막히면 옆으로 빠지기. 마지막 직선은 연타로 스퍼트! 혼자면 AI와, 친구와는 온라인·LAN 방으로(한 폰에 한 명).',
    tint: '#6b2f52',
    icon: '<path d="M14 48V30a14 14 0 0128 0v18" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/><g fill="#6b2f52"><circle cx="14" cy="36" r="1.8"/><circle cx="15.5" cy="26" r="1.8"/><circle cx="42" cy="36" r="1.8"/><circle cx="40.5" cy="26" r="1.8"/></g><path d="M8 10l5 6M28 6v8M48 10l-5 6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 6, hidden: false, realtime: true, aiDelay: 0, undo: false, aiNarration: true,
    controls: [
      { id: 'push', label: '밀기 (누르는 동안) · 점프 · 스퍼트 연타', keys: ['Space', 'ArrowUp', 'KeyW'], pad: ['a', 'rt'] },
      { id: 'left', label: '왼쪽으로 이동', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lb'] },
      { id: 'right', label: '오른쪽으로 이동', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'rb'] },
      { id: 'og', label: '작전: 앞으로 나가기', keys: ['Digit1', 'KeyZ'], pad: ['x'] },
      { id: 'os', label: '작전: 힘 아끼기', keys: ['Digit2', 'KeyX'], pad: ['y'] },
      { id: 'oo', label: '작전: 바깥으로 빠지기', keys: ['Digit3', 'KeyC'], pad: ['b'] },
      { id: 'replay', label: '경주 다시 보기 (착순 화면)', keys: ['KeyR'], pad: ['rs'] },
    ],
    options: [
      { id: 'len', label: '거리', choices: [{ v: 0, label: '무작위' }, { v: 800, label: '800m' }, { v: 1200, label: '1200m' }, { v: 1600, label: '1600m' }, { v: 2000, label: '2000m' }, { v: 2400, label: '2400m' }], def: 0 },
      { id: 'course', label: '코스', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '평지' }, { v: 1, label: '장애물' }], def: -1 },
      { id: 'surface', label: '주로', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '잔디' }, { v: 1, label: '더트' }], def: -1 },
      { id: 'weather', label: '날씨', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '맑음' }, { v: 1, label: '흐림' }, { v: 2, label: '비' }, { v: 3, label: '폭우' }], def: -1 },
      { id: 'venue', label: '경마장', choices: [{ v: -1, label: '무작위' }].concat(VN.map((v, i) => ({ v: i, label: v.n }))), def: -1 },
      { id: 'gates', label: '출전 두수', tip: '경주에 나서는 말 수.', choices: [{ v: 0, label: '실제 정원', tip: '그 경마장의 실제 정원.' }, { v: -1, label: '참가자만', tip: '참가자 말만.' }, { v: 8, label: '8두' }, { v: 12, label: '12두' }], def: 0 },
      { id: 'match', label: '진행', tip: '한 경주 또는 5경주 시즌 점수.', choices: [{ v: 1, label: '단판' }, { v: 5, label: '시즌(5경주)' }], def: 1 },
    ],
    codex: (() => {
      const row = (H0) => { const id = HORSES.indexOf(H0), A = aptOf(id), best = [0, 1, 2, 3].filter((i) => A[2 + i] === Math.max(...A.slice(2))).map((i) => DB[i]);
        const crs = A[1] > A[0] ? '더트' : A[1] >= MIN_G ? '잔디·더트' : '잔디';
        return { icon: '🐎', name: H0.n, tag: STY[H0.s].n + ' · ' + crs + ' ' + best.join('·') + (H0.j ? ' · 장애물' : '') + ' · ' + H0.y + '년대',
          desc: '잔디 ' + GR(A[0]) + ' · 더트 ' + GR(A[1]) + ' │ 단거리 ' + GR(A[2]) + ' · 마일 ' + GR(A[3]) + ' · 중거리 ' + GR(A[4]) + ' · 장거리 ' + GR(A[5]) +
            ' │ 속도 ' + H0.sp + ' · 지구력 ' + H0.en + ' · 순발력 ' + H0.ac + ' · 무거운 주로 ' + ['약함', '보통', '강함'][H0.hv] + (H0.j ? ' │ 장애물 전문: 장애물 경주에서 조금 빠르고 체력이 덜 닳아요' : '') + ' │ ' + H0.f }; };
      const pickBy = (fn) => HORSES.filter((H0) => fn(aptOf(HORSES.indexOf(H0)), H0)).map(row);
      return [
        { h: '전체 ' + HORSES.length + '두', p: ['일본의 유명 경주마 ' + HORSES.length + '두(1970~2020년대). 적성 A(최고)~G(최저). 경주의 코스(잔디/더트)와 거리 적성이 둘 다 C 이상이어야 출전할 수 있어요.', '거리: 단거리 800·1200m · 마일 1600m(~1800) · 중거리 2000m(~2200) · 장거리 2400m 이상(G1 2500·3000·3200m). 위 검색창에 「추입」「더트」「1990년대」처럼 넣으면 걸러져요. 옆 탭은 적성 A인 말만 모아 둔 것.', '능력치는 실제 성적(G1 승수·거리·레이팅)으로 매겼어요. 속도+지구력+순발력 합계가 역대 최상위는 28, G1을 여러 번 이긴 말은 26~27, 한두 번은 23~25(단거리마는 지구력이 낮은 대신 속도·순발력이 높아요). 그래도 컨디션·전개·적성·주로에 따라 이변이 자주 나요.'],
          rows: HORSES.map(row) },
        { h: '단거리', p: ['단거리(800·1200m) 적성 A'], rows: pickBy((A) => A[2] === 6) },
        { h: '마일', p: ['마일(1600m) 적성 A'], rows: pickBy((A) => A[3] === 6) },
        { h: '중거리', p: ['중거리(2000m) 적성 A'], rows: pickBy((A) => A[4] === 6) },
        { h: '장거리', p: ['장거리(2400m 이상) 적성 A'], rows: pickBy((A) => A[5] === 6) },
        { h: '더트', p: ['더트 적성 A'], rows: pickBy((A) => A[1] === 6) },
        { h: '장애물', p: ['장애물 전문: 장애물 경주에서 조금 빠르고(+1.2%) 체력이 덜 닳아요(−5%).'], rows: pickBy((A, H0) => H0.j) },
      { h: '경마장', p: ['실제 경마장 10곳. 직선이 짧으면 도주·선행, 길면 추입이 유리해요. 고저차는 오르막 높이.'], rows: VN.map((v) => { const hs = v.hl.length ? Math.max(...v.hl.map((x) => x[1])) - Math.min(...v.hl.map((x) => x[1])) : 0;
        return { icon: '🏟', name: v.n, tag: (v.d > 0 ? '좌회전' : '우회전') + ' · 직선 ' + v.st + 'm', desc: '잔디 한 바퀴 ' + v.cc + 'm · 마지막 직선 ' + v.st + 'm │ 더트 ' + v.dcc + 'm · 직선 ' + v.dst + 'm │ ' + (hs ? '고저차 ' + hs + 'm' : '평탄') + ' │ ' + v.f }; }) },
      { h: 'G1 경주 (시즌)', p: ['시즌 모드의 G1 일정(달력 순서). 암말·2세 한정 경주는 빠져 있어요.'], rows: G1.map((g, i) => ({ icon: '🏆', name: g[0], tag: VN[g[1]].n + ' ' + SF[g[2]] + ' ' + g[3] + 'm', desc: (i + 1) + '번째 · ' + VN[g[1]].n + ' ' + SF[g[2]] + ' ' + g[3] + 'm (' + DB[dBand(g[3])] + ')' + (i === ARIMA ? ' · 연말 그랑프리, 출전마 모두 뛸 수 있으면 시즌 피날레' : '') })) },
      { h: '각질', rows: STY.map((x, i) => ({ icon: ['🏃', '⚡', '🧘', '💨'][i], name: x.n, tag: '각질', desc: x.d })) },
      ];
    })(),
    quick: [
      '출전마를 고르고 기수가 되어 달려요. 먼저 결승선을 지나면 우승.',
      '가운데 패드를 누르고 있으면 밀어붙이기(빠르지만 체력 소모), 떼면 체력을 아껴요. ◀ ▶ 로 말이 화면 왼쪽·오른쪽으로 움직여요.',
      '마지막 직선 「스퍼트!」에선 패드(화면 아무 곳, PC는 스페이스)를 빠르게 연타!',
      '작전 버튼(앞으로·힘 아끼기·바깥으로)은 경주마다 3번. 경마장마다 직선 길이·언덕이 달라요.',
    ],
    rules: [
      { h: '목표', p: [
        '경주마 한 마리에 올라 직접 몰아요. 먼저 결승선을 통과하면 우승이에요.',
        '경주마다 경마장(도쿄·나카야마 등 실제 10곳)·코스(평지·장애물, 800~2400m)와 날씨·주로가 새로 정해지고, 명마 ' + HORSES.length + '두 중 그 경주에 맞는 말들이 출전해요(📖 도감에서 모두 보기).',
        '「진행」 옵션: 단판 또는 시즌(G1 일정). 「경마장」 옵션 기본은 무작위.',
        '출전 두수(풀게이트): 실제 경주처럼 게이트가 꽉 차요 — G1은 실제 정원(일본 더비·텐노상(봄) 18두, 아리마 기념·페브러리S·스프린터즈S 16두 등), 일반 경주는 실제 경마장·주로별 최대 정원 14~18두(장애물 14두·나카야마 16두, 800m 16두). 사람·AI 자리가 고르지 않은 말은 「자동 출전마」로 함께 달려요(보통 실력 AI 기수, 인기·배당·신문에도 나와요). 「출전 두수」 옵션: 실제 정원(기본)·참가자만·8두·12두.',
        '착순 화면에서 「다시 ×2 · 다시 ×4 · 마지막 직선」으로 방금 경주를 빠르게 다시 볼 수 있어요(PC는 R). 이 기기가 본 그대로를 재생해요(온라인 게스트도 가능, 보는 동안 다음 화면은 잠깐 기다려요).',
      ] },
      { h: '경마장', p: [
        '실제 일본 경마장 10곳의 모양을 따랐어요: 회전 방향(좌·우), 한 바퀴 길이와 코너 크기, 마지막 직선 길이, 언덕(고저차). 더트 코스는 잔디보다 작아요.',
        '마지막 직선이 짧은 곳(삿포로·하코다테·후쿠시마·고쿠라·나카야마 등 300m 이하)은 도주·선행이 유리하고, 긴 곳(도쿄 526m·니가타 659m·한신 474m)은 추입마의 끝걸음이 닿아요. 출주표 신문에 경마장 특징이 실려요.',
        '오르막은 느려지고 체력이 더 닳아요(지구력 좋은 말은 덜 느려짐). 내리막은 조금 빨라요. 미니맵의 빨간 부분이 오르막, 화면에 「오르막·내리막」 표시가 떠요.',
        '스퍼트(금색 선)는 마지막 직선 들머리에서 시작해요.',
      ] },
      { h: '작전 지시', p: [
        '경주마다 3번, 아래 버튼(PC 1·2·3)으로 기수에게 작전을 줘요.',
        '▲ 앞으로 나가기(5초): 확 빨라지지만 체력이 많이 닳아요. 도주·선행이 더 잘 받아요. 스퍼트 중에도 쓸 수 있어요. 체력이 모자라면 막판에 지쳐요.',
        '◆ 힘 아끼기(6초): 조금 느려지는 대신 체력이 조금 회복돼요. 차분·추입이 더 잘 회복해요. 스퍼트 중엔 못 써요.',
        '↗ 바깥으로 빠지기: 앞이 트인 가장 가까운 바깥 줄로 한 번에 빠져요(진로 확보). 코너에서는 바깥일수록 먼 길이에요.',
        'AI 기수도 작전을 써요(어려움일수록 알맞은 때에).',
      ] },
      { h: '시즌', p: [
        '한 판 안에서 실제 JRA G1 경주 5번을 달력 순서로 달려요(페브러리S·사츠키상·텐노상(봄)·일본 더비·야스다 기념·다카라즈카 기념·기쿠카상·재팬컵·아리마 기념 등, 경마장·잔디/더트·거리는 실제와 같음). 이때는 거리·코스·주로·경마장 옵션 대신 G1 일정이고, 날씨만 경주마다 정해져요.',
        '마지막 5경주는 피날레(점수 2배): 출전마 모두 뛸 수 있으면 아리마 기념, 아니면 그중 가장 늦은 G1.',
        '착순 점수(자동 출전마를 포함한 전체 착순) 10·7·5·4·3·2·1점을 모아 시즌 순위를 정해요. 경주가 끝날 때마다 시즌 순위표가 나와요. 동점이면 최고 착순이 좋은 쪽이 위.',
        '2~5경주 일정은 출전마가 정해진 뒤, 출전하는 모든 말의 잔디/더트·거리 적성이 C 이상인 G1로만 짜여요(쉬는 경주 없음). 맞는 G1이 모자라면 같은 G1을 한 번 더 달려요. 거리 구분: 1400m 이하 단거리 · 1800m 이하 마일 · 2200m 이하 중거리 · 그 위 장거리(2500·3000·3200m).',
        '첫 경주에서 고른 말로 시즌 내내 달려요. 경주마다 그 G1의 정원만큼 자동 출전마가 새로 뽑히고(그 경주 적성 C 이상), 게이트와 컨디션도 경주마다 새로 정해지고, 지난 경주에서 체력을 거의 다 쓴 말은 피로가 남아 컨디션이 한 단계 내려가요.',
      ] },
      { h: '출전마 고르기', p: [
        '출전마는 디프 임팩트, 오르페브르, 골드십, 오구리 캡 같은 일본의 유명 경주마예요. 실제 특징(각질·거리·잔디/더트·무거운 주로)이 능력치에 들어 있어요.',
        '속도: 최고 속도. 지구력: 체력이 덜 닳아요. 순발력: 빨리 가속해요(점프·채찍 뒤에도).',
        '각질 — 도주: 처음부터 선두로. 선행: 앞쪽에서 중반이 강함. 차분: 중단에서 체력을 아낌. 추입: 막판 스퍼트가 가장 강함.',
        '📰 출주표 신문: 고르기 화면에 먼저 떠요(「📰 출주표」로 다시 보기). 말마다 인기 순위(1번 인기 = 예상 배당이 가장 낮은 말), 예상 표시(◎ 본명 ○ 대항 ▲ 단혈 △ 연하)와 예상 배당, 기자 한 줄 평, 오늘의 주목마, 예상 전개가 실려요. 정보용이고 내기는 없어요.',
        '🎙 실황 중계: 경주 중 화면 위쪽에 캐스터 자막이 흘러요(출발·순위·추격·마지막 코너·직선·이변·사진 판정). 설정 「🤖 AI 서술」을 켜면 이 경주 말에 맞춘 중계 줄과 신문 문장, 결승 뒤 마무리 한마디를 AI가 써요(✦ 표시). 온라인에선 방장이 고른 같은 줄이 모두에게 보여요.',
        '적성 등급 A~G: 잔디·더트, 단거리(800·1200m)·마일(1600m)·중거리(2000m)·장거리(2400m)마다 있어요. 오늘 경주에 해당하는 칸은 금색. 코스와 거리 적성이 둘 다 C 이상인 말만 출전해요(AI도 같음). 못 나오는 말은 아래에 흐리게, 이유와 함께 보여요.',
        '적성 ◎○△▽: 등급과 날씨를 합쳐 오늘 얼마나 맞는지(◎ 딱 맞음 ○ 좋음 △ 보통 ▽ 불리 — 모두 출전은 가능, ✕는 출전 불가 말에만). 안 맞으면 느려지고 체력이 더 닳아요. 호조·부진은 그날 컨디션(조금 빠름/느림).',
        '고르기 카드 오른쪽에 오늘 종합(◎○△▽)과 인기 순위가 있어요. 위의 칸으로 정렬(게이트·인기·오늘 적성)과 필터(각질·거리 특기 B 이상·잔디/더트/장애물 전문)를 바꿀 수 있어요.',
        '고르기 후보는 정원보다 넉넉히(정원 + 8두, 최소 24두) 나와요. 사람 자리가 모두 고른 뒤 → AI 자리가 남은 후보에서 고르고 → 남은 게이트는 남은 후보가 자동 출전마로 채워요. 출전마가 정해지면 게이트를 1번부터 다시 매겨요(번호가 작을수록 안쪽).',
        '✏️ 를 누르면 말 이름을 바꿀 수 있어요(최대 10글자, 이 기기에 저장). 그 말로 출전하면 온라인 방의 모두에게 바꾼 이름이 보여요.',
      ] },
      { h: '조작', p: [
        '가운데 패드를 누르고 있는 동안 밀어붙여요: 더 빠르지만 체력이 많이 닳아요. 떼면 조금 느린 페이스로 체력을 아껴요.',
        '◀ ▶: 말이 화면에서 누른 쪽(왼쪽·오른쪽)으로 한 줄씩 옮겨요. 누르고 있으면 계속 옮겨요. 바로 옆에 말이 있으면 못 옮겨요. 안쪽 레일이 화면 왼쪽인지 오른쪽인지는 경마장이 도는 방향에 따라 달라요.',
        '체력 막대의 하얀 눈금은 「지금부터 페이스만 유지하고 스퍼트를 끝까지 하는 데 필요한 체력」이에요. 막대가 눈금보다 넉넉하면 밀어도 좋아요.',
        '체력이 바닥나면 눈에 띄게 느려져요.',
        'PC 키보드·게임패드: 스페이스·↑(밀기·점프·스퍼트 연타), ← →(왼쪽·오른쪽 이동). 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '자리싸움', p: [
        '코너에서는 안쪽 줄이 가장 짧아요. 바깥 줄일수록 더 먼 길을 돌아요. 패드 위에 지금 줄과 「남은 코너 바깥 손해 +○m」가 보여요. 줄을 옮기는 동안에도 조금 손해예요.',
        '앞이 막힌 말은 머리 위에 「막힘」이 떠요(다른 말도 보여요). ◀ ▶ 나 「바깥으로」 작전으로 빠져나가세요.',
        '바로 앞(한 마신 이내)에 느린 말이 있으면 막혀서 그 말 속도로만 달려요. 옆으로 빠져나가세요.',
        '앞말 뒤 2~7m에 붙어 달리면 바람막이: 체력이 35% 덜 닳고 조금 빨라요(스퍼트 구간 제외).',
      ] },
      { h: '날씨 · 주로', p: [
        '날씨에 따라 주로 상태가 바뀌어요: 맑음=양호, 흐림=약간 무거움, 비=무거움, 폭우=불량. 경주 전 화면에 표시돼요.',
        '잔디는 젖을수록 느려지고 체력이 더 닳아요. 더트는 조금 젖으면 오히려 빨라지기도 해요.',
        '무거운 주로에 강한 말(골드십·메지로 맥퀸 등)은 비 오는 날 유리하고, 싫어하는 말은 불리해요.',
        '장애물 전문마(오주 초산 등)는 장애물 경주에서 조금 빠르고 체력이 덜 닳아요.',
      ] },
      { h: '장애물 · 웅덩이', p: [
        '장애물 주로: 울타리가 다가오면 패드에 링이 나타나요. 패드를 떼었다가 링이 초록일 때 다시 누르면 점프(초록 링에 겹칠 때 누르면 완벽한 도약 = 잠깐 가속). 계속 누른 채로 들어가면 걸려서 크게 느려져요.',
        '주로가 무거움·불량이면 웅덩이(갈색)가 생겨요. 들어가면 느려지고 체력이 더 닳아요. 줄을 바꿔 피해 가세요.',
      ] },
      { h: '스퍼트', p: [
        '마지막 직선(금색 선부터)은 자동으로 전력 질주예요. 체력이 가장 빨리 닳아요.',
        '패드(또는 화면 아무 곳, PC는 스페이스)를 빠르게 연타하세요. 탭할 때마다 「스퍼트 힘」 막대가 차고, 가득 차면 최고 속도(약 +9%)예요. 손을 놓으면 금방 식어요.',
        '남은 체력이 적을수록 한 번에 차는 양이 줄어요(체력이 바닥이면 약 1/3). 연타마다 체력도 아주 조금 닳아요. 초당 약 13번보다 빠른 탭은 세지 않아요.',
        '1·2착이 한 마신 안쪽으로 결승선에 다가가면 느린 화면으로 보여 주고, 간발의 차는 사진 판정 결과(코·머리·목 차이, 마신)로 알려 줘요.',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 나머지 말은 AI 기수가 몰아요. 친구와는 온라인·LAN 방에서 각자 폰으로.',
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 페이스 조절이 들쭉날쭉하고, 어려움은 체력 계획·안쪽 차지·바람막이에 빠른 연타까지 써요. AI도 사람과 같은 연타 규칙(쉬움 초당 약 5.6번 · 보통 6.6번 · 어려움 8.2번)이에요.',
        '혼자 폰으로 완주하면 경마장·주로·거리별 최고 기록이 이 기기에 남아요.',
      ] },
    ],
    init, actor, apply,
    ai: () => null,
    result, mount,
    _t: { CML, CML_END, cmTick, newCm, fillLine, cleanCm, badCm, cleanPool, endLineData, hasBatchim, VN, G1, issueOrder, outLane, slopeAt, turnLoss, HORSES, inelig, elig, planSeason, aptOf, aptMul, STY, CT, LENS, H, genCourse, posAt, newRace, stepRace, raceOver, order, aiStep, pressAt, fenceTT, judgeJump, applyMash, mashGain, setLane, drainPm, init, actor, apply, autoPick, aiPicks, endRace, nextRace, result, marginTxt },
  });
})();
