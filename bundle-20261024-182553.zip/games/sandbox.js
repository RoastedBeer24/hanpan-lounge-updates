/* 2D 샌드박스 개척 (sandbox) — 옆에서 보는 타일 세계를 캐고, 짓고, 만들고, 싸우는 협동 개척 게임.
   구조: 세계(타일·벽·액체)는 씨앗(seed)으로 모든 기기가 똑같이 만들고, 바뀐 칸만 「편집 기록」으로 호스트가 퍼뜨린다.
   플레이어 움직임·가방은 각 기기가 맡고(반응성), 적·보스·떨어진 물건·NPC·액체 흐름·시간은 호스트가 맡는다.
   게스트 → 호스트: presence에 위치 + 최근 행동 목록(번호 붙여 확인될 때까지 다시 보냄). 호스트 → 모두: hostSend 스냅샷(15Hz). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;
  const BODY = '"IBM Plex Sans KR", "Noto Sans KR", sans-serif';
  const MONO = '"IBM Plex Mono", monospace';
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const fin = Number.isFinite;
  const r1 = (v) => Math.round(v * 10) / 10, r2 = (v) => Math.round(v * 100) / 100;
  function rng(seed) { let a = seed >>> 0 || 1; return function () { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hash2(x, y, s) { let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(s, 2246822519 | 0)) | 0; h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; }
  function vnoise(x, y, s) { const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi; const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf); const a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s); return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v; }
  function fbm(x, y, s, o) { let t = 0, a = 1, f = 1, n = 0; for (let i = 0; i < (o || 4); i++) { t += vnoise(x * f, y * f, s + i * 17) * a; n += a; a *= 0.5; f *= 2; } return t / n; }

  /* ======================= 타일 ======================= */
  // f: 1 단단함 · 2 발판(위에서만) · 4 받침 필요 · 8 가구 · 16 식물 · 32 나무줄기 · 64 자연 · 128 빛 통과
  const TL = [], TX = {};
  function tile(k, n, hp, pk, col, f, o) { const t = Object.assign({ k, n, hp, pk, col, f, lt: 0, dr: k }, o || {}); t.i = TL.length; TL.push(t); TX[k] = t.i; return t; }
  tile('air', '공기', 0, 0, null, 128, { dr: null });
  tile('dirt', '흙', 26, 0, '#8a5a3a', 1 | 64);
  tile('grass', '풀흙', 28, 0, '#8a5a3a', 1 | 64, { top: '#5cb848', dr: 'dirt' });
  tile('stone', '돌', 60, 0, '#7b7b86', 1 | 64);
  tile('sand', '모래', 22, 0, '#d8c27c', 1 | 64, { fall: 1 });
  tile('snow', '눈', 22, 0, '#e8eff6', 1 | 64);
  tile('ice', '얼음', 40, 0, '#9fd2ea', 1 | 64, { slip: 1 });
  tile('mud', '진흙', 26, 0, '#5c4232', 1 | 64);
  tile('jgrass', '이끼진흙', 28, 0, '#5c4232', 1 | 64, { top: '#3fae3a', dr: 'mud' });
  tile('clay', '점토', 34, 0, '#b0603f', 1 | 64);
  tile('log', '나무 줄기', 40, 0, '#7a5230', 32 | 64 | 128, { dr: 'wood' });
  tile('leaf', '잎', 4, 0, '#3f9a3c', 64 | 128, { dr: null });
  tile('pine', '침엽', 4, 0, '#2f6e4c', 64 | 128, { dr: null });
  tile('jleaf', '밀림 잎', 4, 0, '#2f8a2a', 64 | 128, { dr: null });
  tile('cactus', '선인장', 30, 0, '#4f9a4a', 32 | 64 | 128, { dr: 'cactusb' });
  tile('ore_cu', '적동석', 70, 0, '#c8743c', 1 | 64, { ore: 1, dr: 'o_cu' });
  tile('ore_fe', '흑철석', 80, 0, '#a19d98', 1 | 64, { ore: 1, dr: 'o_fe' });
  tile('ore_ag', '월은석', 90, 40, '#d7e0ea', 1 | 64, { ore: 1, dr: 'o_ag' });
  tile('ore_au', '태양금석', 100, 50, '#f0c43c', 1 | 64, { ore: 1, dr: 'o_au' });
  tile('ore_cr', '심홍정', 140, 65, '#d0304e', 1 | 64, { ore: 1, lt: 0.35, lc: [1, 0.3, 0.4], dr: 'o_cr' });
  tile('ore_hl', '화염철광', 180, 75, '#ff6a2a', 1 | 64, { ore: 1, lt: 0.55, lc: [1, 0.55, 0.2], dr: 'o_hl' });
  tile('ore_st', '성운석', 220, 100, '#8a7cff', 1 | 64, { ore: 1, lt: 0.6, lc: [0.6, 0.5, 1], dr: 'o_st' });
  tile('ash', '잿돌', 50, 0, '#4d4446', 1 | 64);
  tile('obsid', '흑요석', 160, 55, '#2c2240', 1);
  tile('cloud', '구름', 16, 0, '#f2f6ff', 1 | 64);
  tile('skybrick', '하늘 벽돌', 70, 0, '#d9c070', 1);
  tile('planks', '판자', 30, 0, '#b07a48', 1);
  tile('sbrick', '돌벽돌', 70, 0, '#8e8e9c', 1);
  tile('glass', '유리', 14, 0, '#bfe6f0', 1 | 128);
  tile('torch', '횃불', 1, 0, null, 4 | 128, { lt: 1, lc: [1, 0.85, 0.6], wallOK: 1 });
  tile('plat', '발판', 10, 0, '#a07040', 2 | 128);
  tile('wbench', '작업대', 20, 0, '#9a6a3c', 4 | 8 | 128, { st: 'wb' });
  tile('furnace', '화로', 40, 0, '#6a6a72', 4 | 8 | 128, { st: 'fu', lt: 0.6, lc: [1, 0.6, 0.3] });
  tile('anvil', '모루', 50, 0, '#5e626e', 4 | 8 | 128, { st: 'an' });
  tile('chest', '상자', 30, 0, '#a8763a', 4 | 8 | 128);
  tile('door', '문', 30, 0, '#8a5a30', 1 | 8, { door: 1 });
  tile('dooro', '열린 문', 30, 0, '#8a5a30', 8 | 128, { door: 2, dr: 'door' });
  tile('table', '탁자', 20, 0, '#a06c3c', 4 | 8 | 128, { furn: 't' });
  tile('chair', '의자', 16, 0, '#a06c3c', 4 | 8 | 128, { furn: 'c' });
  tile('alch', '연금대', 20, 0, '#7a5ab0', 4 | 8 | 128, { st: 'al', furn: 't' });
  tile('bed', '침대', 20, 0, '#c04a4a', 4 | 8 | 128);
  tile('hforge', '화염 단조대', 80, 0, '#5a2a24', 4 | 8 | 128, { st: 'hf', lt: 0.7, lc: [1, 0.4, 0.15] });
  tile('starwb', '별의 작업대', 80, 0, '#5a4ab0', 4 | 8 | 128, { st: 'sw', lt: 0.6, lc: [0.6, 0.5, 1] });
  tile('books', '책장', 20, 0, '#7a4a2a', 4 | 8 | 128, { furn: 't' });
  tile('lamp', '등불', 10, 0, '#f0d080', 4 | 8 | 128, { lt: 1, lc: [1, 0.95, 0.75] });
  tile('lcrys', '생명 수정', 40, 0, '#ff5a7a', 4 | 64 | 128, { lt: 0.5, lc: [1, 0.3, 0.45], dr: 'lifec' });
  tile('pot', '항아리', 6, 0, '#9a6040', 4 | 64 | 128, { dr: null, pot: 1 });
  tile('vine', '덩굴', 2, 0, '#3a9a3a', 16 | 64 | 128, { dr: null, hang: 1 });
  tile('mush', '버섯', 2, 0, '#e0a070', 4 | 16 | 64 | 128, { dr: 'mush' });
  tile('h_sun', '햇살꽃', 2, 0, '#ffd23c', 4 | 16 | 64 | 128, { dr: 'sunb' });
  tile('h_moon', '달빛풀', 2, 0, '#9ab8ff', 4 | 16 | 64 | 128, { dr: 'moonl', lt: 0.25, lc: [0.5, 0.6, 1] });
  tile('h_fire', '불꽃풀', 2, 0, '#ff6a3a', 4 | 16 | 64 | 128, { dr: 'firew', lt: 0.3, lc: [1, 0.5, 0.2] });
  tile('h_frost', '서리꽃', 2, 0, '#bfefff', 4 | 16 | 64 | 128, { dr: 'frostb' });
  tile('h_dune', '모래꽃', 2, 0, '#e87a9a', 4 | 16 | 64 | 128, { dr: 'duneb' });
  tile('sapling', '묘목', 2, 0, '#5cb848', 4 | 16 | 128, { dr: 'acorn' });
  tile('tinker', '세공대', 30, 0, '#8a8a5a', 4 | 8 | 128, { st: 'tk' });
  tile('web', '거미줄', 2, 0, '#e8e8f0', 64 | 128, { dr: 'silk', sticky: 1 });
  tile('boneb', '뼈무덤', 30, 0, '#d8d0b8', 1 | 64, { dr: 'boneb' });
  tile('crystal', '수정 덩이', 50, 50, '#b48cff', 1 | 64, { lt: 0.4, lc: [0.7, 0.5, 1], dr: 'crysh' });
  const NT = TL.length;
  const SOLIDT = new Uint8Array(NT), PLATT = new Uint8Array(NT), LIGHTT = new Float32Array(NT), OPAQ = new Uint8Array(NT);
  TL.forEach((t, i) => { SOLIDT[i] = t.f & 1 ? 1 : 0; PLATT[i] = t.f & 2 ? 1 : 0; LIGHTT[i] = t.lt || 0; OPAQ[i] = t.f & 128 ? 0 : 1; });
  const T_ = TX;

  /* 벽 */
  const WL = [null,
    { k: 'w_dirt', n: '흙벽', col: '#4a3020', nat: 1 }, { k: 'w_stone', n: '돌벽', col: '#3c3c44', nat: 1 },
    { k: 'w_planks', n: '판자벽', col: '#6a4a2c' }, { k: 'w_sbrick', n: '돌벽돌 벽', col: '#4c4c58' },
    { k: 'w_glass', n: '유리벽', col: '#4a6a78' }, { k: 'w_ash', n: '잿벽', col: '#2c2426', nat: 1 },
    { k: 'w_mud', n: '진흙벽', col: '#33261c', nat: 1 }, { k: 'w_sky', n: '하늘 벽돌 벽', col: '#7a6a40' },
    { k: 'w_snow', n: '얼음벽', col: '#4a6070', nat: 1 }, { k: 'w_sand', n: '사암벽', col: '#7a6640', nat: 1 },
  ];
  const WX = {}; WL.forEach((w, i) => { if (w) WX[w.k] = i; });

  /* ======================= 아이템 ======================= */
  const IT = [], IX = {};
  // c: block wall pick axe hammer melee ranged magic summon armor acc potion mat ammo furn light boss misc coin
  function item(k, n, c, o) { const it = Object.assign({ k, n, c, mx: 999, v: 10 }, o || {}); it.i = IT.length; IT.push(it); IX[k] = it.i; return it; }
  const TIER = [
    { k: 'cu', n: '적동', col: '#d07a40', ore: 'ore_cu', pk: 45, dm: 10, df: [1, 2, 1], sb: '방어 +3', sbx: { def: 3 }, at: 'an', v: 30 },
    { k: 'fe', n: '흑철', col: '#a8a6b0', ore: 'ore_fe', pk: 52, dm: 12, df: [2, 3, 2], sb: '채굴 속도 +20%', sbx: { mine: 0.2 }, at: 'an', v: 50 },
    { k: 'ag', n: '월은', col: '#dfe7f0', ore: 'ore_ag', pk: 58, dm: 14, df: [3, 4, 3], sb: '이동 속도 +12%', sbx: { spd: 0.12 }, at: 'an', v: 80 },
    { k: 'au', n: '태양금', col: '#f2c844', ore: 'ore_au', pk: 66, dm: 17, df: [4, 5, 4], sb: '모든 피해 +12%', sbx: { dmg: 0.12 }, at: 'an', v: 120 },
    { k: 'cr', n: '심홍', col: '#d8344f', ore: 'ore_cr', pk: 78, dm: 23, df: [6, 7, 5], sb: '체력 재생 +3/초 · 치명타 +8%', sbx: { regen: 3, crit: 0.08 }, at: 'an', v: 220 },
    { k: 'hl', n: '화염철', col: '#ff7a30', ore: 'ore_hl', pk: 105, dm: 31, df: [8, 9, 8], sb: '근접 공격이 불을 붙여요 · 피해 +10% · 용암 면역', sbx: { dmg: 0.1, fire: 1, lavaImm: 1 }, at: 'hf', v: 400 },
    { k: 'st', n: '성운강', col: '#9a8cff', ore: 'ore_st', pk: 200, dm: 46, df: [12, 14, 11], sb: '피해 +20% · 이동 +15% · 두 번 뛰기', sbx: { dmg: 0.2, spd: 0.15, dj: 1 }, at: 'sw', v: 800 },
  ];
  const blockItems = [['dirt', '흙'], ['stone', '돌'], ['sand', '모래'], ['snow', '눈'], ['ice', '얼음'], ['mud', '진흙'], ['clay', '점토'], ['ash', '잿돌'], ['obsid', '흑요석'], ['cloud', '구름'], ['skybrick', '하늘 벽돌'], ['planks', '판자'], ['sbrick', '돌벽돌'], ['glass', '유리'], ['plat', '발판'], ['boneb', '뼈무덤 블록']];
  for (const [t, n] of blockItems) item(t, n, 'block', { pl: t, v: 2, d: '놓을 수 있는 블록.' });
  item('wood', '나무', 'block', { pl: 'planks', v: 2, d: '나무를 베면 나와요. 놓으면 판자가 돼요. 거의 모든 제작의 시작.' });
  item('cactusb', '선인장 조각', 'mat', { v: 3, col: '#4f9a4a', d: '사막 선인장. 선인장 장비 재료.' });
  for (let w = 1; w < WL.length; w++) item(WL[w].k, WL[w].n, 'wall', { pw: w, v: 1, d: WL[w].nat ? '자연 벽(망치로 떼면 나와요).' : '배경 벽. 집 안에는 벽이 꼭 있어야 해요.' });
  for (const T of TIER) {
    item('o_' + T.k, TL[TX[T.ore]].n, 'block', { pl: T.ore, v: T.v / 6 | 0, col: T.col, d: T.n + ' 광석. 화로에서 녹이면 주괴가 돼요.' + (TL[TX[T.ore]].pk ? ' 곡괭이 힘 ' + TL[TX[T.ore]].pk + ' 이상.' : '') });
    item('b_' + T.k, T.n + ' 주괴', 'mat', { v: T.v / 2 | 0, col: T.col, d: T.n + ' 장비 재료.' });
  }
  const mats = [
    ['gel', '젤리', '#5ac8ff', '젤리방울이 떨어뜨려요. 횃불·물약 재료.'], ['lens', '렌즈', '#ffffff', '밤눈박쥐가 떨어뜨려요.'], ['flesh', '썩은 살점', '#8a9a4a', '밤걸음꾼이 떨어뜨려요.'],
    ['bone', '뼈', '#e8e0c8', '뼈광부가 떨어뜨려요.'], ['silk', '거미 실', '#eeeeff', '거미줄·수정거미.'], ['feather', '깃털', '#ffffff', '하늘섬 바람깃 사냥꾼.'],
    ['stinger', '가시', '#c8e040', '밀림 가시벌.'], ['shell', '바위게 껍질', '#9a8a7a', '동굴 바위게.'], ['fang', '이빨', '#f0f0e8', '바다 이빨물고기.'],
    ['ember', '불씨 핵', '#ff8a30', '지하세계 마물.'], ['frost', '서리 핵', '#a0e8ff', '눈 지역 얼음 정령·서리젤리.'], ['stard', '별가루', '#ffe680', '밤에 하늘에서 떨어져요. 마나 수정 재료.'],
    ['crysh', '수정 조각', '#b48cff', '깊은 곳 수정 덩이.'], ['bottle', '빈 병', '#cfefff', '유리로 만들어요. 물약 재료.'], ['mush', '버섯', '#e0a070', '동굴 버섯.'],
    ['sunb', '햇살꽃', '#ffd23c', '숲의 약초.'], ['moonl', '달빛풀', '#9ab8ff', '밀림의 약초.'], ['firew', '불꽃풀', '#ff6a3a', '지하세계 약초.'], ['frostb', '서리꽃', '#bfefff', '눈 지역 약초.'], ['duneb', '모래꽃', '#e87a9a', '사막 약초.'],
    ['acorn', '도토리', '#a07040', '풀흙 위에 심으면 나무로 자라요.'], ['raidb', '약탈단 깃발 조각', '#8a3030', '약탈단 습격.'], ['kgel', '왕젤리 젤', '#5ab4ff', '왕젤리.'],
    ['gazes', '응시의 조각', '#9a5ad0', '어둠의 응시자.'], ['wscale', '땅굴벌레 비늘', '#8a8a6a', '철갑 땅굴벌레.'], ['bonec', '거인의 뼛조각', '#f0e8c0', '뼈무덤 거인.'],
    ['flamec', '군주의 불꽃', '#ff5a20', '화염 군주.'], ['starc', '별 조각', '#c8b8ff', '하늘섬 상자·별의 집행자.'],
  ];
  for (const [k, n, col, d] of mats) item(k, n, 'mat', { col, d, v: 5 });
  IT[IX.acorn].pl = 'sapling';
  item('coin', '동전', 'coin', { mx: 99999, v: 1, col: '#f2c844', d: '상인에게 물건을 살 때 써요.' });
  const furn = [['torch', '횃불', '빛을 내요. 벽이나 땅에 붙여요.'], ['wbench', '작업대', '기본 제작 장소.'], ['furnace', '화로', '광석을 녹여요.'], ['anvil', '모루', '금속 장비를 만들어요.'],
    ['chest', '상자', '물건 30칸을 보관해요(오른쪽 클릭).'], ['door', '문', '세로 3칸. 오른쪽 클릭으로 열고 닫아요. 집에 꼭 필요해요.'], ['table', '탁자', '집 가구(탁자 종류).'], ['chair', '의자', '집 가구(의자 종류).'],
    ['alch', '연금대', '물약을 만들어요. 탁자 종류.'], ['bed', '침대', '오른쪽 클릭 → 되살아날 곳.'], ['hforge', '화염 단조대', '화염철 장비를 만들어요.'], ['starwb', '별의 작업대', '성운강 장비를 만들어요.'],
    ['books', '책장', '집 가구(탁자 종류).'], ['lamp', '등불', '밝은 빛. 받침 위에 놓아요.'], ['tinker', '세공대', '장신구를 합쳐요.']];
  for (const [t, n, d] of furn) item(t, n, 'furn', { pl: t, d, v: 10, mx: 99 });
  IT[IX.torch].mx = 999; IT[IX.torch].c = 'light';
  function tools(T, pre, col, pk, dm) {
    item(pre + '_pick', T + ' 곡괭이', 'pick', { pk, ut: Math.max(0.12, 0.22 - pk / 2000), col, mx: 1, dmg: Math.round(dm * 0.5), kb: 2, v: 40 });
    item(pre + '_axe', T + ' 도끼', 'axe', { ax: pk, ut: 0.24, col, mx: 1, dmg: Math.round(dm * 0.6), kb: 3, v: 30 });
    item(pre + '_ham', T + ' 망치', 'hammer', { hm: pk, ut: 0.24, col, mx: 1, dmg: Math.round(dm * 0.7), kb: 4, v: 30 });
    item(pre + '_sword', T + ' 검', 'melee', { dmg: dm, ut: 0.32, kb: 5, rch: 2.6, col, mx: 1, v: 50 });
    item(pre + '_bow', T + ' 활', 'ranged', { dmg: Math.round(dm * 0.8), ut: 0.42, kb: 2, spd: 22 + pk / 10, ammo: 'arrow', col, mx: 1, v: 50 });
  }
  function armors(T, pre, col, df) {
    item(pre + '_helm', T + ' 투구', 'armor', { slot: 0, def: df[0], set: pre, col, mx: 1, v: 40 });
    item(pre + '_mail', T + ' 갑옷', 'armor', { slot: 1, def: df[1], set: pre, col, mx: 1, v: 60 });
    item(pre + '_legs', T + ' 각반', 'armor', { slot: 2, def: df[2], set: pre, col, mx: 1, v: 40 });
  }
  const SETS = {};
  item('old_pick', '낡은 곡괭이', 'pick', { pk: 35, ut: 0.24, col: '#9a7a50', mx: 1, dmg: 4, kb: 2, v: 5 });
  item('old_axe', '낡은 도끼', 'axe', { ax: 35, ut: 0.26, col: '#9a7a50', mx: 1, dmg: 5, kb: 2, v: 5 });
  item('old_sword', '낡은 단검', 'melee', { dmg: 7, ut: 0.28, kb: 3, rch: 2.1, col: '#9a7a50', mx: 1, v: 5 });
  item('wd_sword', '나무 검', 'melee', { dmg: 8, ut: 0.3, kb: 4, rch: 2.4, col: '#b07a48', mx: 1, v: 5 });
  item('wd_bow', '나무 활', 'ranged', { dmg: 6, ut: 0.45, kb: 1, spd: 20, ammo: 'arrow', col: '#b07a48', mx: 1, v: 5 });
  item('wd_ham', '나무 망치', 'hammer', { hm: 30, ut: 0.3, col: '#b07a48', mx: 1, dmg: 4, kb: 3, v: 5 });
  armors('나무', 'wd', '#b07a48', [1, 1, 0]); SETS.wd = { n: '나무', sb: '방어 +1', sbx: { def: 1 } };
  item('ca_sword', '선인장 검', 'melee', { dmg: 10, ut: 0.3, kb: 4, rch: 2.4, col: '#4f9a4a', mx: 1, v: 10 });
  armors('선인장', 'ca', '#4f9a4a', [1, 2, 1]); SETS.ca = { n: '선인장', sb: '방어 +1 · 닿은 적이 가시에 다쳐요', sbx: { def: 1, thorn: 1 } };
  for (const T of TIER) { tools(T.n, T.k, T.col, T.pk, T.dm); armors(T.n, T.k, T.col, T.df); SETS[T.k] = { n: T.n, sb: T.sb, sbx: T.sbx }; }
  const SPEC = [
    ['ice_staff', '서리 지팡이', 'magic', { dmg: 18, ut: 0.4, mana: 6, pj: 'ice', spd: 18, col: '#a0e8ff', kb: 2 }, '얼음 조각을 쏴요(맞으면 느려짐).'],
    ['fire_staff', '불씨 지팡이', 'magic', { dmg: 30, ut: 0.36, mana: 8, pj: 'fire', spd: 20, col: '#ff7a30', kb: 3, fire: 1 }, '불덩이 — 불을 붙여요.'],
    ['spark_wand', '번개 지팡이', 'magic', { dmg: 38, ut: 0.3, mana: 9, pj: 'spark', spd: 30, col: '#ffe680', kb: 2, pierce: 3 }, '여러 적을 꿰뚫는 번개.'],
    ['star_staff', '별비 지팡이', 'magic', { dmg: 70, ut: 0.28, mana: 12, pj: 'star', spd: 26, col: '#c8b8ff', kb: 4, pierce: 2 }, '하늘에서 별을 떨어뜨려요.'],
    ['water_tome', '물살 마도서', 'magic', { dmg: 24, ut: 0.34, mana: 7, pj: 'water', spd: 15, col: '#5ab4ff', kb: 3, bounce: 3 }, '벽에 튕기는 물방울.'],
    ['gaze_bow', '응시의 활', 'ranged', { dmg: 26, ut: 0.3, kb: 2, spd: 30, ammo: 'arrow', col: '#9a5ad0', multi: 2 }, '화살을 2발씩 쏴요.'],
    ['scale_blade', '비늘 대검', 'melee', { dmg: 44, ut: 0.38, kb: 7, rch: 3.2, col: '#8a8a6a' }, '크게 휘두르는 대검.'],
    ['bone_spear', '거인의 뼈창', 'melee', { dmg: 52, ut: 0.3, kb: 6, rch: 3.8, col: '#f0e8c0', thrust: 1 }, '멀리 찌르는 창.'],
    ['flame_axe', '군주의 화염 도끼', 'melee', { dmg: 72, ut: 0.36, kb: 8, rch: 3.2, col: '#ff5a20', fire: 1, ax: 160 }, '나무도 잘 베는 불타는 도끼.'],
    ['star_blade', '집행자의 별검', 'melee', { dmg: 110, ut: 0.26, kb: 7, rch: 3.4, col: '#c8b8ff', beam: 1 }, '휘두를 때 별빛 칼날이 날아가요.'],
    ['boomer', '바위게 부메랑', 'ranged', { dmg: 16, ut: 0.5, kb: 4, spd: 18, col: '#9a8a7a', pj: 'boom' }, '돌아오는 부메랑(화살 필요 없음).'],
    ['spiker', '가시 투척기', 'ranged', { dmg: 22, ut: 0.22, kb: 1, spd: 24, col: '#c8e040', pj: 'thorn' }, '빠르게 가시를 던져요(화살 필요 없음).'],
    ['slime_rod', '말랑 소환 지팡이', 'summon', { dmg: 12, ut: 0.5, mana: 10, mn: 'slime', col: '#5ab4ff' }, '아기 젤리 소환수가 따라다니며 싸워요.'],
    ['bat_rod', '박쥐 소환 지팡이', 'summon', { dmg: 22, ut: 0.5, mana: 10, mn: 'bat', col: '#7a5a9a' }, '날아다니는 박쥐 소환수.'],
    ['ember_rod', '불꽃 정령 지팡이', 'summon', { dmg: 40, ut: 0.5, mana: 10, mn: 'imp', col: '#ff7a30' }, '불덩이를 쏘는 정령.'],
    ['star_rod', '별 수호령 지팡이', 'summon', { dmg: 70, ut: 0.5, mana: 10, mn: 'starg', col: '#c8b8ff' }, '빠르게 날아다니는 별 수호령.'],
  ];
  for (const [k, n, c, o, d] of SPEC) item(k, n, c, Object.assign({ mx: 1, v: 150, d }, o));
  item('arrow', '나무 화살', 'ammo', { dmg: 4, v: 1, col: '#b07a48', d: '활에 써요.' });
  item('farrow', '불화살', 'ammo', { dmg: 7, v: 2, col: '#ff8a30', fire: 1, d: '불을 붙여요.' });
  item('farrow2', '흑철 화살', 'ammo', { dmg: 9, v: 3, col: '#a8a6b0', d: '단단한 화살.' });
  item('harrow', '화염철 화살', 'ammo', { dmg: 15, v: 6, col: '#ff6a2a', fire: 1, pierce: 1, d: '꿰뚫고 불을 붙여요.' });
  item('sarrow', '별빛 화살', 'ammo', { dmg: 22, v: 10, col: '#c8b8ff', pierce: 2, d: '꿰뚫는 별빛.' });
  for (const k of ['arrow', 'farrow', 'farrow2', 'harrow', 'sarrow']) IT[IX[k]].isAmmo = 'arrow';
  const ACC = [
    ['run_boots', '질주 장화', { spd: 0.25 }, '이동 속도 +25%. 동굴 상자.'],
    ['cloud_jar', '구름 병', { dj: 1 }, '공중에서 한 번 더 뛰어요. 하늘섬 상자.'],
    ['feather_c', '깃털 부적', { nofall: 1, glide: 1 }, '떨어짐 피해 없음 · 점프 키를 누르고 있으면 천천히 떨어져요.'],
    ['lava_c', '용암 부적', { lavaImm: 1 }, '용암 피해를 막아요. 깊은 동굴 상자.'],
    ['might_s', '맹공 문장', { dmg: 0.1 }, '모든 피해 +10%.'],
    ['regen_b', '재생 팔찌', { regen: 2 }, '체력 재생 +2/초.'],
    ['arcane_f', '비전 꽃', { manaR: 4, mana: 20 }, '마나 +20 · 마나 재생 빨라짐.'],
    ['claw', '등반 발톱', { wall: 1 }, '벽에 붙어 미끄러지고 벽 점프.'],
    ['gill_c', '아가미 부적', { breath: 1 }, '물속에서 숨이 안 줄어요.'],
    ['thorn_sh', '가시 방패', { def: 3, kbImm: 1 }, '방어 +3 · 밀려나지 않아요.'],
    ['miner_lamp', '광부 등불', { light: 1, mine: 0.1 }, '내 둘레가 밝아지고 채굴 +10%.'],
    ['jelly_shoe', '말랑 신발', { jump: 0.3 }, '점프 높이 +30%. 왕젤리.'],
    ['gaze_eye', '응시의 눈 장식', { crit: 0.1 }, '치명타 +10%. 어둠의 응시자.'],
    ['worm_core', '땅굴 심장', { def: 4, regen: 1 }, '방어 +4 · 재생 +1. 철갑 땅굴벌레.'],
    ['bone_ring', '거인의 반지', { minion: 1 }, '소환수 +1. 뼈무덤 거인.'],
    ['lord_crest', '군주의 문장', { dmg: 0.12, lavaImm: 1 }, '피해 +12% · 용암 면역. 화염 군주.'],
    ['wind_boots', '바람 장화', { spd: 0.3, nofall: 1, glide: 1 }, '질주 장화 + 깃털 부적(세공대).'],
    ['sky_jar', '하늘 구름 병', { dj: 2 }, '두 번 더 뛰어요. 구름 병 + 깃털 + 별 조각(세공대).'],
    ['obs_shield', '흑요석 방패', { def: 5, kbImm: 1, lavaImm: 1 }, '가시 방패 + 용암 부적(세공대).'],
    ['war_emblem', '전쟁 문장', { dmg: 0.18, crit: 0.05 }, '맹공 문장 + 응시의 눈 장식(세공대).'],
    ['life_band', '생명 팔찌', { regen: 4, mana: 20, manaR: 4 }, '재생 팔찌 + 비전 꽃(세공대).'],
  ];
  for (const [k, n, ef, d] of ACC) item(k, n, 'acc', { ef, d, mx: 1, v: 200 });
  const POT = [
    ['p_heal', '치유 물약', '#ff4a5a', { heal: 60 }, '체력 60 회복(빠른 회복 키). 다시 마실 때까지 40초.'],
    ['p_bheal', '큰 치유 물약', '#ff2a6a', { heal: 140 }, '체력 140 회복(빠른 회복 키).'],
    ['p_mana', '마나 물약', '#4a7aff', { manaHeal: 100 }, '마나 100 회복.'],
    ['p_iron', '철피 물약', '#a8a6b0', { buff: 'iron', t: 240 }, '4분 동안 방어 +8.'],
    ['p_regen', '재생 물약', '#ff8aa0', { buff: 'regen', t: 300 }, '5분 동안 체력 재생 +4.'],
    ['p_swift', '신속 물약', '#5ae0a0', { buff: 'swift', t: 240 }, '4분 동안 이동 +25%.'],
    ['p_ore', '광맥 물약', '#f2c844', { buff: 'ore', t: 180 }, '3분 동안 둘레 광석이 어둠 속에서도 보여요.'],
    ['p_night', '밤눈 물약', '#9ab8ff', { buff: 'night', t: 240 }, '4분 동안 어둠 속이 조금 보여요.'],
    ['p_fire', '화염 저항 물약', '#ff7a30', { buff: 'fireR', t: 240 }, '4분 동안 용암 면역.'],
    ['p_gill', '아가미 물약', '#5ac8ff', { buff: 'gill', t: 300 }, '5분 동안 물속 숨.'],
    ['p_feather', '깃털 물약', '#ffffff', { buff: 'feather', t: 180 }, '3분 동안 천천히 떨어지기 · 떨어짐 피해 없음.'],
    ['p_rage', '분노 물약', '#d8344f', { buff: 'rage', t: 240 }, '4분 동안 피해 +10% · 치명타 +10%.'],
    ['p_home', '귀환 물약', '#c8b8ff', { home: 1 }, '되살아날 곳으로 바로 돌아가요.'],
    ['p_mine', '광부 물약', '#c8743c', { buff: 'mine', t: 300 }, '5분 동안 채굴 +25%.'],
  ];
  for (const [k, n, col, ef, d] of POT) item(k, n, 'potion', { col, ef, d, mx: 30, v: 20 });
  const BUFF = { iron: ['철피', '방어 +8', { def: 8 }], regen: ['재생', '재생 +4', { regen: 4 }], swift: ['신속', '이동 +25%', { spd: 0.25 }], ore: ['광맥', '광석 보임', { ore: 1 }], night: ['밤눈', '어둠 보임', { night: 1 }], fireR: ['화염 저항', '용암 면역', { lavaImm: 1 }], gill: ['아가미', '물속 숨', { breath: 1 }], feather: ['깃털', '천천히 떨어짐', { glide: 2, nofall: 1 }], rage: ['분노', '피해·치명 +10%', { dmg: 0.1, crit: 0.1 }], mine: ['광부', '채굴 +25%', { mine: 0.25 }], fire: ['불붙음', '체력이 타요', {}], slow: ['느려짐', '이동 −40%', { spd: -0.4 }], sick: ['물약 기운', '치유 물약 대기', {}], housed: ['', '', {}] };
  item('lifec', '생명 수정', 'misc', { use: 'life', col: '#ff5a7a', mx: 99, v: 100, d: '쓰면 최대 체력 +20(400까지). 깊은 동굴에서 캐요.' });
  item('manac', '마나 수정', 'misc', { use: 'mana', col: '#4a7aff', mx: 99, v: 80, d: '쓰면 최대 마나 +20(200까지). 별가루 5개로 만들어요.' });
  item('mirror', '귀환 거울', 'misc', { use: 'home', col: '#dfe7f0', mx: 1, v: 300, d: '여러 번 쓰는 귀환. 동굴 상자.' });
  const BOSS_IT = [
    ['s_slime', '끈적 왕관', 0, '낮에 땅 위에서 쓰면 왕젤리가 와요.'],
    ['s_gaze', '수상한 수정구', 1, '밤에 쓰면 어둠의 응시자가 와요.'],
    ['s_worm', '썩은 미끼', 2, '땅속(동굴 층)에서 쓰면 철갑 땅굴벌레가 와요.'],
    ['s_bone', '저주받은 두개골', 3, '밤에 쓰면 뼈무덤 거인이 와요.'],
    ['s_flame', '불씨 인형', 4, '지하세계에서 쓰면 화염 군주가 와요.'],
    ['s_star', '별빛 신호기', 5, '땅 위나 하늘에서 쓰면 별의 집행자가 와요.'],
  ];
  for (const [k, n, b, d] of BOSS_IT) item(k, n, 'boss', { boss: b, d, mx: 20, v: 100 });

  /* ======================= 제작법 ======================= */
  const ST_N = { wb: '작업대', fu: '화로', an: '모루', al: '연금대', tk: '세공대', hf: '화염 단조대', sw: '별의 작업대' };
  const ST_TILE = { wb: 'wbench', fu: 'furnace', an: 'anvil', al: 'alch', tk: 'tinker', hf: 'hforge', sw: 'starwb' };
  const RC = [];
  function R(out, n, ins, at) { const ii = ins.split(',').map((s) => { const [k, c] = s.trim().split(':'); if (IX[k] === undefined) throw new Error('recipe item ' + k); return [IX[k], +(c || 1)]; }); if (IX[out] === undefined) throw new Error('recipe out ' + out); RC.push({ o: IX[out], n, in: ii, at: at || null }); }
  R('torch', 3, 'wood:1,gel:1'); R('wbench', 1, 'wood:10'); R('planks', 1, 'wood:1'); R('plat', 2, 'wood:1');
  R('w_planks', 4, 'wood:1', 'wb'); R('door', 1, 'wood:6', 'wb'); R('table', 1, 'wood:8', 'wb'); R('chair', 1, 'wood:4', 'wb');
  R('chest', 1, 'wood:8,b_fe:2', 'wb'); R('furnace', 1, 'stone:20,wood:4,torch:3', 'wb'); R('anvil', 1, 'b_fe:5', 'wb'); R('bed', 1, 'wood:15,silk:5', 'wb');
  R('books', 1, 'wood:20,bone:5', 'wb'); R('lamp', 1, 'wood:4,torch:2,glass:2', 'wb'); R('alch', 1, 'bottle:1,table:1', 'wb'); R('tinker', 1, 'wood:10,b_fe:8,shell:3', 'wb');
  R('sbrick', 1, 'stone:2', 'fu'); R('w_sbrick', 4, 'sbrick:1', 'wb'); R('glass', 1, 'sand:2', 'fu'); R('w_glass', 4, 'glass:1', 'wb'); R('bottle', 2, 'glass:1', 'fu');
  R('skybrick', 2, 'cloud:2,stone:1', 'wb'); R('w_sky', 4, 'skybrick:1', 'wb'); R('boneb', 1, 'bone:2', 'wb');
  R('wd_sword', 1, 'wood:7', 'wb'); R('wd_bow', 1, 'wood:10', 'wb'); R('wd_ham', 1, 'wood:8', 'wb'); R('wd_helm', 1, 'wood:20', 'wb'); R('wd_mail', 1, 'wood:30', 'wb'); R('wd_legs', 1, 'wood:25', 'wb');
  R('ca_sword', 1, 'cactusb:10', 'wb'); R('ca_helm', 1, 'cactusb:20', 'wb'); R('ca_mail', 1, 'cactusb:30', 'wb'); R('ca_legs', 1, 'cactusb:25', 'wb');
  R('arrow', 25, 'wood:1,stone:1', 'wb'); R('farrow', 10, 'arrow:10,torch:1'); R('farrow2', 25, 'arrow:25,b_fe:1', 'an');
  R('harrow', 50, 'arrow:50,b_hl:1', 'hf'); R('sarrow', 50, 'arrow:50,b_st:1', 'sw');
  R('hforge', 1, 'furnace:1,anvil:1,b_hl:10,obsid:10', 'an'); R('starwb', 1, 'b_st:8,starc:5,crysh:10', 'hf');
  for (const T of TIER) {
    const bar = 'b_' + T.k, k = T.k;
    if (k === 'hl') R(bar, 1, 'o_hl:3,obsid:1', 'fu'); else if (k === 'st') R(bar, 1, 'o_st:4,stard:1', 'hf'); else R(bar, 1, 'o_' + k + ':3', 'fu');
    const at = T.at, w = k === 'st' ? 'crysh' : 'wood';
    R(k + '_pick', 1, bar + ':12,' + w + ':4', at); R(k + '_axe', 1, bar + ':9,' + w + ':3', at); R(k + '_ham', 1, bar + ':10,' + w + ':3', at);
    R(k + '_sword', 1, bar + ':8', at); R(k + '_bow', 1, bar + ':7', at);
    R(k + '_helm', 1, bar + ':15', at); R(k + '_mail', 1, bar + ':25', at); R(k + '_legs', 1, bar + ':20', at);
  }
  R('ice_staff', 1, 'b_ag:10,frost:6,ice:20', 'an'); R('fire_staff', 1, 'b_hl:12,ember:8', 'hf'); R('spark_wand', 1, 'b_cr:12,wscale:8,crysh:6', 'an');
  R('star_staff', 1, 'b_st:14,starc:6', 'sw'); R('water_tome', 1, 'silk:8,stard:5,kgel:10', 'wb'); R('boomer', 1, 'shell:8,wood:10', 'wb'); R('spiker', 1, 'stinger:12,b_fe:4', 'an');
  R('bat_rod', 1, 'b_cr:8,lens:6,silk:6', 'an'); R('ember_rod', 1, 'b_hl:10,ember:6,flamec:2', 'hf'); R('star_rod', 1, 'b_st:12,starc:6', 'sw');
  R('scale_blade', 1, 'wscale:14,b_cr:6', 'an'); R('bone_spear', 1, 'bonec:12,b_cr:8', 'an'); R('star_blade', 1, 'starc:12,b_st:14', 'sw');
  R('regen_b', 1, 'lifec:1,moonl:3,b_au:4', 'tk'); R('arcane_f', 1, 'manac:1,moonl:5,sunb:5', 'tk'); R('claw', 1, 'b_fe:6,shell:4', 'tk'); R('gill_c', 1, 'fang:6,b_ag:4', 'tk');
  R('thorn_sh', 1, 'cactusb:20,b_fe:8,stinger:6', 'tk'); R('miner_lamp', 1, 'lamp:1,b_au:3,crysh:3', 'tk'); R('might_s', 1, 'raidb:10,b_au:4', 'tk');
  R('wind_boots', 1, 'run_boots:1,feather_c:1', 'tk'); R('sky_jar', 1, 'cloud_jar:1,feather:10,starc:3', 'tk'); R('obs_shield', 1, 'thorn_sh:1,lava_c:1', 'tk');
  R('war_emblem', 1, 'might_s:1,gaze_eye:1', 'tk'); R('life_band', 1, 'regen_b:1,arcane_f:1', 'tk'); R('feather_c', 1, 'feather:12,cloud:20', 'tk');
  R('p_heal', 2, 'bottle:2,gel:2,mush:1', 'al'); R('p_bheal', 2, 'p_heal:2,lifec:1', 'al'); R('p_mana', 2, 'bottle:2,stard:1,moonl:1', 'al');
  R('p_iron', 1, 'bottle:1,b_fe:1,sunb:1', 'al'); R('p_regen', 1, 'bottle:1,mush:2,sunb:1', 'al'); R('p_swift', 1, 'bottle:1,duneb:1,feather:1', 'al');
  R('p_ore', 1, 'bottle:1,o_au:1,moonl:1', 'al'); R('p_night', 1, 'bottle:1,lens:1,moonl:1', 'al'); R('p_fire', 1, 'bottle:1,firew:1,obsid:1', 'al');
  R('p_gill', 1, 'bottle:1,fang:1,frostb:1', 'al'); R('p_feather', 1, 'bottle:1,feather:1,cloud:2', 'al'); R('p_rage', 1, 'bottle:1,flesh:3,firew:1', 'al');
  R('p_home', 1, 'bottle:1,stard:1,duneb:1', 'al'); R('p_mine', 1, 'bottle:1,o_cu:3,frostb:1', 'al');
  R('manac', 1, 'stard:5'); R('lifec', 1, 'p_bheal:2,crysh:8,b_cr:5', 'al');
  R('s_slime', 1, 'gel:20,b_au:4', 'wb'); R('s_gaze', 1, 'lens:6', 'wb'); R('s_worm', 1, 'flesh:15,bone:5', 'wb');
  R('s_bone', 1, 'bone:30,b_cr:5', 'an'); R('s_flame', 1, 'b_hl:5,bone:10,ember:5', 'hf'); R('s_star', 1, 'b_st:10,starc:5', 'sw');
  R('w_dirt', 4, 'dirt:1', 'wb'); R('w_stone', 4, 'stone:1', 'wb'); R('w_mud', 4, 'mud:1', 'wb'); R('w_ash', 4, 'ash:1', 'wb'); R('w_snow', 4, 'ice:1', 'wb'); R('w_sand', 4, 'sand:1', 'wb');
  const RC_IN = {}; RC.forEach((r, i) => { for (const [it] of r.in) (RC_IN[it] = RC_IN[it] || []).push(i); });
  const RC_OUT = {}; RC.forEach((r, i) => { (RC_OUT[r.o] = RC_OUT[r.o] || []).push(i); });

  /* ======================= 적 ======================= */
  // ai: slime 깡충 · walk 걷기 · fly 날기 · swim 헤엄 · shoot 날며 쏘기 · throw 걷다 던지기 · caster 순간이동+마법 · worm(보스용)
  const EN = [];
  function en(k, n, o) { const e = Object.assign({ k, n, hp: 20, dmg: 8, def: 0, ai: 'walk', sp: 4, w: 1.4, h: 1.2, col: '#5ac8ff', dr: [], coin: [1, 3], kbr: 0, where: '' }, o); e.i = EN.length; EN.push(e); return e; }
  en('gslime', '풀젤리', { hp: 16, dmg: 6, ai: 'slime', col: '#5ac85a', dr: [['gel', 1, 3, 1]], where: '숲 · 낮' });
  en('dslime', '모래젤리', { hp: 24, dmg: 9, ai: 'slime', col: '#e0c070', dr: [['gel', 1, 3, 1], ['duneb', 1, 1, 0.1]], where: '사막 · 낮' });
  en('sslime', '서리젤리', { hp: 34, dmg: 12, def: 2, ai: 'slime', col: '#bfefff', dr: [['gel', 2, 4, 1], ['frost', 1, 1, 0.25]], where: '눈 지역' });
  en('jslime', '늪젤리', { hp: 50, dmg: 15, def: 4, ai: 'slime', col: '#3fae3a', dr: [['gel', 2, 5, 1], ['moonl', 1, 1, 0.12]], where: '밀림', coin: [3, 8] });
  en('walker', '밤걸음꾼', { hp: 48, dmg: 14, def: 4, ai: 'walk', sp: 3.2, w: 1.2, h: 2.6, col: '#6a8a5a', dr: [['flesh', 1, 2, 0.6]], where: '땅 위 · 밤', coin: [4, 9] });
  en('nbat', '밤눈박쥐', { hp: 30, dmg: 12, ai: 'fly', sp: 7, w: 1.2, h: 1, col: '#5a3a6a', dr: [['lens', 1, 1, 0.45]], where: '땅 위 · 밤', coin: [3, 7] });
  en('cbat', '동굴박쥐', { hp: 22, dmg: 11, ai: 'fly', sp: 8, w: 1, h: 0.8, col: '#4a4058', dr: [['silk', 1, 1, 0.1]], where: '동굴' });
  en('crab', '바위게', { hp: 40, dmg: 12, def: 8, ai: 'walk', sp: 2.6, w: 1.6, h: 1, col: '#8a7a6a', dr: [['shell', 1, 2, 0.5]], where: '얕은 동굴', kbr: 0.4 });
  en('bminer', '뼈광부', { hp: 80, dmg: 22, def: 8, ai: 'walk', sp: 3.6, w: 1.2, h: 2.6, col: '#e0d8c0', dr: [['bone', 1, 3, 0.8], ['torch', 2, 6, 0.3]], where: '깊은 동굴', coin: [8, 16] });
  en('cspider', '수정거미', { hp: 120, dmg: 30, def: 12, ai: 'walk', sp: 5.5, w: 1.8, h: 1, col: '#b48cff', dr: [['silk', 2, 4, 0.8], ['crysh', 1, 2, 0.35]], where: '깊은 동굴(수정)', coin: [12, 24] });
  en('scorp', '모래전갈', { hp: 60, dmg: 18, def: 6, ai: 'walk', sp: 4, w: 1.8, h: 1, col: '#c89040', dr: [['duneb', 1, 1, 0.2]], where: '사막', coin: [5, 10] });
  en('wasp', '가시벌', { hp: 54, dmg: 20, def: 4, ai: 'shoot', sp: 6, w: 1, h: 1, col: '#c8e040', dr: [['stinger', 1, 2, 0.6]], pj: 'thorn', where: '밀림', coin: [6, 12] });
  en('fang', '이빨물고기', { hp: 80, dmg: 24, def: 4, ai: 'swim', sp: 8, w: 1.8, h: 0.9, col: '#5a7a9a', dr: [['fang', 1, 2, 0.5]], where: '바다', coin: [8, 14] });
  en('harp', '바람깃 사냥꾼', { hp: 90, dmg: 25, def: 6, ai: 'shoot', sp: 6, w: 1.4, h: 1.6, col: '#d8e8ff', dr: [['feather', 1, 2, 0.7]], pj: 'feather', where: '하늘섬', coin: [10, 20] });
  en('fiend', '잿불 마귀', { hp: 200, dmg: 36, def: 14, ai: 'caster', sp: 3, w: 1.4, h: 2.4, col: '#c8402a', dr: [['ember', 1, 3, 0.7], ['firew', 1, 1, 0.15]], pj: 'fireb', where: '지하세계', coin: [25, 50], lavaImm: 1 });
  en('lslime', '용암 젤리', { hp: 150, dmg: 30, def: 10, ai: 'slime', col: '#ff6a2a', dr: [['gel', 2, 4, 1], ['ember', 1, 1, 0.3]], where: '지하세계', coin: [15, 30], lavaImm: 1, glow: 1 });
  en('fbat', '불꽃박쥐', { hp: 90, dmg: 32, def: 10, ai: 'fly', sp: 9, w: 1.2, h: 0.9, col: '#ff5a20', dr: [['ember', 1, 1, 0.4]], where: '지하세계', coin: [12, 24], lavaImm: 1, glow: 1 });
  en('rwalker', '붉은눈 걸음꾼', { hp: 130, dmg: 30, def: 10, ai: 'walk', sp: 4.6, w: 1.2, h: 2.6, col: '#a83a3a', dr: [['flesh', 2, 4, 0.8]], where: '붉은 달밤', coin: [15, 30] });
  en('raider', '약탈단 졸개', { hp: 95, dmg: 22, def: 8, ai: 'walk', sp: 4.4, w: 1.2, h: 2.4, col: '#8a5a3a', dr: [['raidb', 1, 2, 0.5]], where: '약탈단 습격', coin: [10, 20] });
  en('rthrow', '약탈단 투척병', { hp: 70, dmg: 18, def: 4, ai: 'throw', sp: 3.6, w: 1.2, h: 2.4, col: '#6a4a3a', dr: [['raidb', 1, 2, 0.5]], pj: 'spike', where: '약탈단 습격', coin: [10, 20] });
  en('rmage', '약탈단 주술사', { hp: 80, dmg: 24, def: 4, ai: 'caster', sp: 3, w: 1.2, h: 2.4, col: '#5a3a8a', dr: [['raidb', 1, 3, 0.7]], pj: 'shadow', where: '약탈단 습격', coin: [15, 30] });
  en('icesp', '얼음 정령', { hp: 120, dmg: 28, def: 10, ai: 'shoot', sp: 4, w: 1.2, h: 1.6, col: '#a0e8ff', dr: [['frost', 1, 2, 0.8]], pj: 'icebolt', where: '눈 지역 땅속', coin: [12, 22], glow: 1 });
  en('mslime', '아기 젤리', { hp: 14, dmg: 10, ai: 'slime', col: '#5ab4ff', dr: [['gel', 1, 1, 0.5]], where: '왕젤리가 낳아요', coin: [0, 1], w: 1, h: 0.8 });
  en('gazelet', '응시 눈동자', { hp: 30, dmg: 16, ai: 'fly', sp: 9, w: 1, h: 1, col: '#9a5ad0', dr: [], where: '어둠의 응시자가 불러요', coin: [0, 2] });
  en('sentry', '별 파수꾼', { hp: 300, dmg: 40, def: 20, ai: 'shoot', sp: 3, w: 1.4, h: 1.4, col: '#c8b8ff', dr: [['stard', 1, 2, 0.5]], pj: 'starb', where: '별의 집행자가 불러요', coin: [10, 20], glow: 1 });
  const EX = {}; EN.forEach((e) => { EX[e.k] = e.i; });

  /* ======================= 보스 ======================= */
  const BOSS = [
    { k: 'kslime', n: '왕젤리', hp: 1800, dmg: 22, def: 6, w: 6, h: 4.4, col: '#4a9aff', dr: [['kgel', 20, 30, 1], ['slime_rod', 1, 1, 0.5], ['jelly_shoe', 1, 1, 0.5], ['b_au', 6, 10, 1]], coin: 300, title: '숲의 거대한 덩어리', how: '「끈적 왕관」을 낮에 땅 위에서. 가끔 숲에 저절로 나타나요.', pat: '크게 뛰어올라 덮쳐요 · 맞으면 아기 젤리를 흘려요 · 체력이 반이 되면 순간이동' },
    { k: 'gazer', n: '어둠의 응시자', hp: 3200, dmg: 28, def: 10, w: 3.6, h: 3.6, col: '#7a3ab0', dr: [['gazes', 15, 25, 1], ['gaze_bow', 1, 1, 0.5], ['gaze_eye', 1, 1, 0.5], ['o_cr', 20, 40, 1]], coin: 600, title: '밤하늘의 눈', how: '「수상한 수정구」를 밤에. 체력이 높아지면 밤에 저절로 올 때가 있어요.', pat: '1단계: 위에서 맴돌며 빛 화살 3발 · 눈동자 부르기 / 2단계(반 이하): 세 번 돌진' },
    { k: 'worm', n: '철갑 땅굴벌레', hp: 6000, dmg: 34, def: 14, w: 2.4, h: 2.4, col: '#8a8a6a', seg: 24, dr: [['wscale', 18, 28, 1], ['worm_core', 1, 1, 0.6], ['o_hl', 10, 20, 1], ['lifec', 1, 2, 1]], coin: 900, title: '땅을 가르는 쇠벌레', how: '「썩은 미끼」를 땅속 동굴 층에서.', pat: '흙을 뚫고 다니며 달려들어요 · 몸통 마디 어디를 때려도 돼요 · 땅 위로 솟구쳤다 떨어져요' },
    { k: 'bgiant', n: '뼈무덤 거인', hp: 9000, dmg: 40, def: 18, w: 4, h: 4.4, col: '#e8e0c8', dr: [['bonec', 15, 25, 1], ['bone_spear', 1, 1, 0.5], ['bone_ring', 1, 1, 0.5], ['bone', 30, 50, 1]], coin: 1400, title: '잠들지 못한 해골 왕', how: '「저주받은 두개골」을 밤에.', pat: '두 손이 내려찍기 · 뼈 쏘기 / 반 이하: 머리가 빙글빙글 돌며 쫓아와요' },
    { k: 'flord', n: '화염 군주', hp: 14000, dmg: 50, def: 24, w: 5, h: 5, col: '#ff5a20', dr: [['flamec', 12, 20, 1], ['flame_axe', 1, 1, 0.5], ['lord_crest', 1, 1, 0.5], ['ember_rod', 1, 1, 0.3]], coin: 2500, title: '지하세계의 불꽃 심장', how: '「불씨 인형」을 지하세계에서.', pat: '불 고리 · 불덩이 비 · 돌진 / 반 이하: 용암 덩이를 뿌려요. 처치하면 하늘에서 성운석이 떨어져요' },
    { k: 'exec', n: '별의 집행자', hp: 24000, dmg: 62, def: 30, w: 3.4, h: 4.6, col: '#c8b8ff', dr: [['starc', 15, 25, 1], ['star_blade', 1, 1, 0.4], ['star_staff', 1, 1, 0.4], ['star_rod', 1, 1, 0.4]], coin: 5000, title: '하늘의 마지막 심판', how: '「별빛 신호기」를 땅 위나 하늘에서.', pat: '순간이동 · 예고선 뒤 별빛 광선 · 소용돌이 탄막 · 별 파수꾼 소환 / 반 이하: 더 빠르게' },
  ];

  /* ======================= NPC 정착민 ======================= */
  const NPC = [
    { k: 'guide', n: '안내자', col: '#6a9a5a', d: '처음부터 있어요. 물건을 보여 주면 무엇을 만들 수 있는지 알려 줘요.', cond: () => true, how: '처음부터', shop: [] },
    { k: 'merch', n: '상인', col: '#c8a040', d: '기본 물건을 팔고, 내 물건을 사 줘요.', cond: (W) => W.fl.coin >= 50, how: '누군가 동전 50개 이상 모으기',
      shop: [['torch', 5], ['arrow', 1], ['bottle', 4], ['acorn', 3], ['p_heal', 40], ['wbench', 10], ['mirror', 2000], ['run_boots', 3000]] },
    { k: 'smith', n: '대장장이', col: '#8a6a5a', d: '광석·주괴·도구를 팔아요.', cond: (W) => W.fl.anvil, how: '모루 놓기',
      shop: [['o_cu', 15], ['o_fe', 20], ['b_fe', 70], ['b_ag', 110], ['cu_pick', 400], ['claw', 2000], ['thorn_sh', 2500]] },
    { k: 'alch', n: '연금술사', col: '#7a5ab0', d: '약초와 물약을 팔아요.', cond: (W) => W.fl.alch, how: '연금대 놓기',
      shop: [['bottle', 3], ['sunb', 15], ['moonl', 20], ['frostb', 20], ['duneb', 20], ['p_heal', 30], ['p_mana', 30], ['p_iron', 120], ['p_swift', 120]] },
    { k: 'healer', n: '치유사', col: '#e86a8a', d: '동전을 받고 체력을 채워 줘요.', cond: (W) => W.fl.hp >= 120, how: '누군가 최대 체력 120 이상', shop: [['p_bheal', 120], ['p_regen', 150]], heal: 1 },
    { k: 'archer', n: '궁수 장인', col: '#5a8a4a', d: '화살과 활을 팔아요.', cond: (W) => W.fl.b[0], how: '왕젤리 처치',
      shop: [['arrow', 1], ['farrow', 3], ['farrow2', 5], ['fe_bow', 600], ['spiker', 3000]] },
    { k: 'mage', n: '비전술사', col: '#4a7aff', d: '마법 물건을 팔아요.', cond: (W) => W.fl.mp >= 40, how: '누군가 마나 수정 쓰기',
      shop: [['p_mana', 25], ['manac', 500], ['stard', 60], ['water_tome', 3500], ['ice_staff', 4000]] },
    { k: 'explore', n: '탐험가', col: '#b07a48', d: '여행 물건을 팔아요.', cond: (W) => W.fl.b[1], how: '어둠의 응시자 처치',
      shop: [['p_home', 80], ['p_ore', 100], ['p_gill', 80], ['p_night', 80], ['feather', 15], ['cloud', 4], ['mirror', 1500]] },
    { k: 'tinkr', n: '세공사', col: '#8a8a5a', d: '세공대와 장신구를 팔아요.', cond: (W) => W.fl.b[2], how: '철갑 땅굴벌레 처치',
      shop: [['tinker', 800], ['gill_c', 1800], ['regen_b', 3000], ['feather_c', 2500], ['lava_c', 4000]] },
  ];

  /* ======================= 세계 만들기 ======================= */
  const SIZES = [{ n: '작게', w: 420, h: 230 }, { n: '보통', w: 640, h: 290 }, { n: '크게', w: 900, h: 340 }];
  const BIO_N = ['숲', '사막', '눈 지역', '밀림', '바다'];
  function genWorld(seed, sz) {
    const S = SIZES[sz] || SIZES[1];
    const w = S.w, h = S.h, N = w * h, R = rng(seed * 7 + 13);
    const t = new Uint8Array(N), wl = new Uint8Array(N), lq = new Uint8Array(N);
    const surf = new Int16Array(w), bio = new Uint8Array(w);
    const W = { w, h, t, wl, lq, surf, bio, seed, sz, chests: {}, hellTop: h - 50 };
    const S0 = Math.round(h * 0.26), sea = S0 + 7, hellTop = h - 50; W.sea = sea;
    W.cav = Math.round(h * 0.5);
    // 생물 군계
    const oc = Math.round(w * 0.07); const mid = w >> 1;
    for (let x = 0; x < w; x++) bio[x] = 0;
    const segL = [oc + 10, mid - 50], segR = [mid + 50, w - oc - 10];
    const bw = Math.round(w * 0.14);
    const sides = R() < 0.5 ? [2, 3] : [3, 2]; const deserts = R() < 0.5 ? 0 : 1;
    const place = (seg, b, pos) => { const len = seg[1] - seg[0]; const x0 = Math.round(seg[0] + (len - bw) * pos); for (let x = x0; x < x0 + bw; x++) if (x >= 0 && x < w) bio[x] = b; return [x0, x0 + bw]; };
    const lSeg = place(segL, sides[0], R() * 0.3), rSeg = place(segR, sides[1], 0.7 + R() * 0.3);
    if (deserts === 0) place([lSeg[1] + 4, segL[1]], 1, R()); else place([segR[0], rSeg[0] - 4], 1, R());
    for (let x = 0; x < w; x++) if (x < oc || x >= w - oc) bio[x] = 4;
    // 땅 높이
    for (let x = 0; x < w; x++) {
      const b = bio[x];
      const amp = b === 1 ? 0.5 : b === 2 ? 1.5 : b === 3 ? 1.1 : 1;
      let y = S0 + (fbm(x / 70, 3, seed, 4) - 0.5) * 26 * amp + (fbm(x / 14, 9, seed + 5, 2) - 0.5) * 6 * amp;
      const d = Math.min(x, w - 1 - x);
      if (d < oc + 14) { const k = clamp((oc + 14 - d) / 14, 0, 1); y = y * (1 - k) + (sea + 2) * k; }
      if (d < oc) y = sea + 2 + (oc - d) * 0.55;
      if (Math.abs(x - mid) < 12) y = y * 0.6 + S0 * 0.4;
      surf[x] = Math.round(clamp(y, 30, h * 0.45));
    }
    // 채우기
    for (let x = 0; x < w; x++) {
      const b = bio[x], s = surf[x];
      const soil = 6 + Math.round(fbm(x / 20, 1, seed + 2, 2) * 8) + (b === 1 ? 10 : 0);
      for (let y = s; y < h; y++) {
        const i = y * w + x, dep = y - s;
        let tt;
        if (y >= hellTop) tt = T_.ash;
        else if (dep < soil) tt = b === 1 || b === 4 ? T_.sand : b === 2 ? T_.snow : b === 3 ? T_.mud : T_.dirt;
        else {
          tt = T_.stone;
          const n = fbm(x / 9, y / 9, seed + 31, 3);
          if (n > 0.66) tt = b === 3 ? T_.mud : b === 2 ? T_.ice : b === 1 ? T_.sand : T_.dirt;
          else if (n < 0.24 && y < W.cav) tt = T_.clay;
          if (b === 3 && y < W.cav + 20 && n > 0.45) tt = T_.mud;
          if (b === 2 && n > 0.55) tt = T_.ice;
        }
        t[i] = tt;
        if (dep > 1) wl[i] = y >= hellTop ? WX.w_ash : dep < soil ? (b === 3 ? WX.w_mud : b === 2 ? WX.w_snow : b === 1 || b === 4 ? WX.w_sand : WX.w_dirt) : (b === 3 && y < W.cav ? WX.w_mud : WX.w_stone);
      }
      const top = s * w + x;
      if (b === 0) t[top] = T_.grass; else if (b === 3) t[top] = T_.jgrass;
    }
    const carve = (cx, cy, r, keepWall) => { const r2 = r * r; for (let yy = Math.floor(cy - r); yy <= cy + r; yy++) for (let xx = Math.floor(cx - r); xx <= cx + r; xx++) { if (xx < 2 || yy < 2 || xx >= w - 2 || yy >= h - 2) continue; const dx = xx - cx, dy = yy - cy; if (dx * dx + dy * dy <= r2) { t[yy * w + xx] = 0; if (!keepWall) wl[yy * w + xx] = 0; } } };
    // 동굴(벌레 굴)
    const worms = Math.round(N / 2600);
    for (let k = 0; k < worms; k++) {
      let x = 10 + R() * (w - 20), y = 0;
      const surfaceStart = k < worms * 0.08;
      if (surfaceStart) { x = oc + 20 + R() * (w - 2 * oc - 40); if (Math.abs(x - mid) < 20) x += 40; y = surf[x | 0] - 1; } else y = surf[x | 0] + 10 + R() * (hellTop - surf[x | 0] - 14);
      let a = surfaceStart ? Math.PI / 2 + (R() - 0.5) * 0.8 : R() * TAU;
      const len = 50 + R() * (surfaceStart ? 120 : 180), r0 = 1.2 + R() * (surfaceStart ? 1.4 : 2.2);
      for (let s = 0; s < len; s++) {
        const rr = r0 * (0.7 + 0.6 * vnoise(s / 8, k, seed));
        carve(x, y, rr, !surfaceStart || y > surf[clamp(x | 0, 0, w - 1)] + 3);
        a += (R() - 0.5) * 0.5; if (surfaceStart) a = a * 0.9 + (Math.PI / 2) * 0.1;
        x += Math.cos(a); y += Math.sin(a) * 0.8;
        if (x < 4 || x > w - 4 || y > hellTop - 2 || y < 8) break;
      }
    }
    // 큰 동굴
    for (let y = W.cav - 10; y < hellTop - 4; y++) for (let x = 3; x < w - 3; x++) { const n = fbm(x / 26, y / 15, seed + 77, 3); if (n > 0.64) t[y * w + x] = 0; }
    // 지하세계: 띠 모양 공간 + 바닥 용암
    for (let x = 1; x < w - 1; x++) for (let y = hellTop; y < h - 1; y++) {
      const i = y * w + x, rel = y - hellTop;
      const n = fbm(x / 18, y / 10, seed + 99, 3);
      const band = rel > 10 && rel < 38 && n < 0.62;
      if (band) { t[i] = 0; if (rel > 33) lq[i] = 16 | 8; }
      else if (t[i] === T_.ash && hash2(x, y, seed + 5) < 0.06 && rel > 6) t[i] = T_.ore_hl;
    }
    for (let x = 0; x < w; x++) for (let y = h - 3; y < h; y++) { t[y * w + x] = T_.ash; lq[y * w + x] = 0; }
    // 광석 줄기
    const veins = (tt, n, d0, d1, sz0, sz1) => {
      for (let k = 0; k < n; k++) {
        const x0 = 4 + R() * (w - 8) | 0, s = surf[x0];
        let x = x0, y = Math.round(s + (hellTop - s) * (d0 + R() * (d1 - d0)));
        const L2 = sz0 + R() * (sz1 - sz0);
        for (let q = 0; q < L2; q++) {
          for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) { const xx = x + dx, yy = y + dy; if (xx < 1 || yy < 1 || xx >= w - 1 || yy >= h - 1) continue; const ii = yy * w + xx, cur = t[ii]; if (cur === T_.stone || cur === T_.dirt || cur === T_.mud || cur === T_.ice || cur === T_.snow || cur === T_.clay || cur === T_.sand) t[ii] = tt; }
          x += (R() * 3 | 0) - 1; y += (R() * 3 | 0) - 1;
        }
      }
    };
    const A = N / 1000;
    veins(T_.ore_cu, A * 2.2, 0.0, 0.45, 5, 12); veins(T_.ore_fe, A * 1.9, 0.04, 0.6, 5, 11); veins(T_.ore_ag, A * 1.4, 0.25, 0.8, 4, 10);
    veins(T_.ore_au, A * 1.1, 0.4, 1.0, 4, 9); veins(T_.ore_cr, A * 0.8, 0.68, 1.0, 4, 9); veins(T_.crystal, A * 0.25, 0.72, 1.0, 3, 6);
    // 바다 물
    for (let x = 0; x < w; x++) if (bio[x] === 4) for (let y = sea; y < surf[x]; y++) lq[y * w + x] = 8;
    // 동굴 물·용암 웅덩이
    const pools = Math.round(N / 900);
    for (let k = 0; k < pools; k++) {
      const x = 3 + R() * (w - 6) | 0, y0 = surf[x] + 15 + R() * (hellTop - surf[x] - 20) | 0;
      let y = y0; while (y < hellTop - 2 && t[y * w + x] === 0) y++;
      if (y >= hellTop - 2 || t[(y - 1) * w + x] !== 0) continue;
      const lava = (y - surf[x]) / (hellTop - surf[x]) > 0.72 && R() < 0.5;
      for (let dx = -6; dx <= 6; dx++) for (let dy = 1; dy <= 3; dy++) { const xx = x + dx, yy = y - dy; if (xx < 1 || xx >= w - 1) continue; const ii = yy * w + xx; if (t[ii] === 0) lq[ii] = (lava ? 16 : 0) | 8; }
    }
    // 하늘섬
    W.islands = [];
    const nIs = Math.max(2, Math.round(w / 200));
    for (let k = 0; k < nIs; k++) {
      const cx = Math.round(w * (k + 0.5) / nIs + (R() - 0.5) * 30), cy = 18 + Math.round(R() * 12), rw = 12 + Math.round(R() * 8);
      for (let x = cx - rw; x <= cx + rw; x++) { if (x < 2 || x >= w - 2) continue; const dx = (x - cx) / rw; const depth = Math.round(Math.sqrt(Math.max(0, 1 - dx * dx)) * 7); for (let y = cy; y < cy + depth; y++) { const i = y * w + x; t[i] = y === cy ? T_.grass : y < cy + 3 ? T_.dirt : T_.cloud; if (y > cy) wl[i] = WX.w_dirt; } }
      // 작은 집
      const hx = cx - 4, hy = cy - 6;
      for (let x = hx; x <= hx + 8; x++) for (let y = hy; y < cy; y++) { const i = y * w + x; const edge = x === hx || x === hx + 8 || y === hy; t[i] = edge ? T_.skybrick : 0; wl[i] = WX.w_sky; }
      for (let y = cy - 3; y < cy; y++) t[y * w + hx] = T_.door;
      t[(cy - 1) * w + hx + 4] = T_.chest; W.chests[(cy - 1) * w + hx + 4] = 'sky';
      t[(cy - 3) * w + hx + 7] = T_.torch;
      W.islands.push({ x: cx, y: cy });
    }
    // 나무·선인장·풀
    const spawnX = mid;
    for (let x = 4; x < w - 4; x++) {
      const b = bio[x], s = surf[x], ti = s * w + x;
      if (t[ti] === 0 || t[(s - 1) * w + x] !== 0 || lq[(s - 1) * w + x]) continue;
      if (Math.abs(x - spawnX) < 4) continue;
      if ((b === 0 || b === 3 || b === 2) && R() < (b === 3 ? 0.22 : 0.16) && (t[ti] === T_.grass || t[ti] === T_.jgrass || t[ti] === T_.snow)) {
        growTree(W, x, s - 1, b, R); x += 3; continue;
      }
      if (b === 1 && R() < 0.06) { const hh = 2 + (R() * 4 | 0); for (let y = s - 1; y >= s - hh; y--) t[y * w + x] = T_.cactus; x += 4; continue; }
      const r = R();
      if (b === 0 && r < 0.05) t[(s - 1) * w + x] = T_.h_sun;
      else if (b === 3 && r < 0.05) t[(s - 1) * w + x] = T_.h_moon;
      else if (b === 2 && r < 0.04) t[(s - 1) * w + x] = T_.h_frost;
      else if (b === 1 && r < 0.03) t[(s - 1) * w + x] = T_.h_dune;
    }
    // 동굴 장식: 버섯·항아리·생명 수정·상자·거미줄·덩굴·불꽃풀
    let lc = 0, ch = 0;
    const lcN = Math.round(w / 22), chN = Math.round(w / 14);
    for (let k = 0; k < N / 18; k++) {
      const x = 3 + R() * (w - 6) | 0, y = 3 + R() * (h - 6) | 0, i = y * w + x;
      if (t[i] !== 0 || lq[i] || y <= surf[x] + 4) continue;
      const below = t[i + w];
      const floor = SOLIDT[below] && TL[below].f & 64;
      const dep = (y - surf[x]) / (hellTop - surf[x]);
      if (y >= hellTop) { if (floor && below === T_.ash && R() < 0.15) t[i] = T_.h_fire; else if (floor && R() < 0.03 && ch < chN + 6) { t[i] = T_.chest; W.chests[i] = 'hell'; ch++; } continue; }
      if (floor) {
        const r = R();
        if (r < 0.04 && lc < lcN && dep > 0.45 && t[i - w] === 0) { t[i] = T_.lcrys; lc++; }
        else if (r < 0.09 && ch < chN && t[i - w] === 0) { t[i] = T_.chest; W.chests[i] = dep > 0.6 ? 'deep' : 'cave'; ch++; }
        else if (r < 0.3) t[i] = T_.pot;
        else if (r < 0.6 && dep < 0.85) t[i] = T_.mush;
      } else if (SOLIDT[t[i - w]] && R() < 0.15) {
        if (bio[x] === 3 && dep < 0.5) { for (let q = 0; q < 2 + R() * 5; q++) { const ii = i + q * w; if (t[ii] !== 0) break; t[ii] = T_.vine; } }
        else if (dep > 0.3) t[i] = T_.web;
      }
    }
    // 생명 수정·상자 채우기(동굴 바닥 찾아서)
    const floorSpot = (d0, d1) => { for (let a = 0; a < 400; a++) { const x = 4 + R() * (w - 8) | 0, s = surf[x]; let y = Math.round(s + 6 + (hellTop - s - 8) * (d0 + R() * (d1 - d0))); for (let q = 0; q < 30 && y < hellTop - 1; q++, y++) { const i = y * w + x; if (t[i] === 0 && !lq[i] && t[i - w] === 0 && SOLIDT[t[i + w]] && TL[t[i + w]].f & 64) return i; } } return -1; };
    while (lc < lcN) { const i = floorSpot(0.45, 1); if (i < 0) break; t[i] = T_.lcrys; lc++; }
    while (ch < chN) { const i = floorSpot(0.1, 1); if (i < 0) break; t[i] = T_.chest; W.chests[i] = ((i / w) | 0) - surf[i % w] > (hellTop - surf[i % w]) * 0.6 ? 'deep' : 'cave'; ch++; }
    // 정리: 받침이 없는 받침 필요 타일 지우기
    for (let i = w; i < N - w; i++) { const tt = t[i]; if (tt && TL[tt].f & 4 && tt !== T_.torch && !SOLIDT[t[i + w]]) t[i] = 0; }
    // 액체 가라앉히기
    W.lqAct = new Set(); for (let i = 0; i < N; i++) if (lq[i]) W.lqAct.add(i);
    for (let it = 0; it < 90 && W.lqAct.size; it++) liqStep(W, 200000, null);
    // 출발점
    W.spawn = { x: spawnX + 0.5, y: surf[spawnX] };
    for (let y = surf[spawnX] - 12; y < surf[spawnX]; y++) for (let x = spawnX - 2; x <= spawnX + 2; x++) { const i = y * w + x; if (t[i] && !SOLIDT[t[i]]) t[i] = 0; }
    W.top = new Int16Array(w); for (let x = 0; x < w; x++) colTop(W, x);
    return W;
  }
  function growTree(W, x, y, b, R) {
    const w = W.w, t = W.t;
    const hh = (b === 3 ? 9 : 5) + (R() * (b === 3 ? 8 : 7) | 0);
    for (let k = 0; k < hh; k++) { const i = (y - k) * w + x; if (y - k < 3 || t[i] !== 0) return false; }
    for (let k = 0; k < hh; k++) t[(y - k) * w + x] = T_.log;
    const top = y - hh + 1, lt = b === 2 ? T_.pine : b === 3 ? T_.jleaf : T_.leaf;
    if (b === 2) { for (let k = 0; k < 7; k++) { const half = Math.floor(k / 2.2); for (let dx = -half; dx <= half; dx++) { const yy = top - 3 + k, xx = x + dx; const i = yy * w + xx; if (yy > 1 && xx > 0 && xx < w && t[i] === 0) t[i] = lt; } } }
    else { const r = b === 3 ? 3.2 : 2.6; for (let dy = -4; dy <= 2; dy++) for (let dx = -4; dx <= 4; dx++) { if (dx * dx + dy * dy * 1.3 > r * r) continue; const yy = top + dy - 1, xx = x + dx, i = yy * w + xx; if (yy > 1 && xx > 0 && xx < w && t[i] === 0) t[i] = lt; } }
    return true;
  }
  function colTop(W, x) { const w = W.w; let y = 0; while (y < 44 && y < W.surf[x] - 12) y++; /* 하늘섬 그림자는 무시 */ while (y < W.h - 1 && !(OPAQ[W.t[y * w + x]] && SOLIDT[W.t[y * w + x]])) y++; W.top[x] = y; }

  /* ======================= 액체 ======================= */
  // lq: 하위 4비트 = 양(0~8), 16 = 용암
  function liqStep(W, budget, onSet) {
    const w = W.w, h = W.h, t = W.t, lq = W.lq;
    const act = Array.from(W.lqAct); W.lqAct = new Set();
    let n = 0;
    const set = (i, v) => { if (lq[i] === v) return; lq[i] = v; if (onSet) onSet(i); W.lqAct.add(i); W.lqAct.add(i - 1); W.lqAct.add(i + 1); W.lqAct.add(i - w); W.lqAct.add(i + w); };
    act.sort((a, b) => b - a);
    for (const i of act) {
      if (n++ > budget) { W.lqAct.add(i); continue; }
      if (i < w || i >= w * (h - 1)) continue;
      let a = lq[i]; if (!a) continue;
      if (SOLIDT[t[i]]) { set(i, 0); continue; }
      const lava = a & 16; let amt = a & 15;
      const x = i % w;
      // 물+용암 → 흑요석
      for (const j of [i + w, i - 1, i + 1, i - w]) { const b = lq[j]; if (b && (b & 16) !== lava && !SOLIDT[t[j]]) { const k = lava ? i : j; t[k] = T_.obsid; lq[k] = 0; if (onSet) onSet(k, 1); W.lqAct.add(k - 1); W.lqAct.add(k + 1); W.lqAct.add(k - w); if (k === i) { amt = 0; break; } } }
      if (!amt) continue;
      const below = i + w;
      if (!SOLIDT[t[below]]) { const b = lq[below] & 15; if (b < 8) { const mv = Math.min(amt, 8 - b); set(below, lava | (b + mv)); amt -= mv; } }
      if (amt > 0) {
        const dirs = (i + (W.lqTick | 0)) & 1 ? [-1, 1] : [1, -1];
        for (const d of dirs) {
          const j = i + d, jx = x + d; if (jx < 1 || jx >= w - 1 || SOLIDT[t[j]]) continue;
          const b = lq[j] & 15;
          if (amt - b >= 2 || (amt === 1 && b === 0 && !SOLIDT[t[j + w]] && (lq[j + w] & 15) < 8)) { const mv = amt === 1 ? 1 : (amt - b) >> 1; set(j, lava | (b + mv)); amt -= mv; }
        }
      }
      if ((a & 15) !== amt) set(i, amt ? lava | amt : 0);
    }
    W.lqTick = (W.lqTick | 0) + 1;
  }

  /* ======================= 물리 ======================= */
  const tAt = (W, x, y) => (x < 0 || y < 0 || x >= W.w || y >= W.h ? T_.stone : W.t[y * W.w + x]);
  const solidAt = (W, x, y) => SOLIDT[tAt(W, x, y)] === 1;
  function boxHits(W, x, y, bw, bh) { const x0 = Math.floor(x - bw / 2), x1 = Math.floor(x + bw / 2 - 1e-4), y0 = Math.floor(y - bh), y1 = Math.floor(y - 1e-4); for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) if (solidAt(W, xx, yy)) return true; return false; }
  // e: {x(가운데), y(발밑), vx, vy, w, h} — 단위: 칸
  function moveBody(W, e, dt, o) {
    o = o || {};
    e.gnd = 0; e.hitW = 0; e.hitC = 0;
    let dx = e.vx * dt, dy = e.vy * dt;
    const steps = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 0.4));
    dx /= steps; dy /= steps;
    for (let s = 0; s < steps; s++) {
      if (dx) {
        const nx = e.x + dx;
        if (boxHits(W, nx, e.y, e.w, e.h)) {
          // 한 칸 오르기
          if (o.step && e.wasGnd && !boxHits(W, nx, e.y - 1.01, e.w, e.h) && !boxHits(W, e.x, e.y - 1.01, e.w, e.h)) { e.y = Math.floor(e.y - 1.01 + 1e-3) + 0.999; e.x = nx; e.stepUp = 0.12; }
          else { e.hitW = dx > 0 ? 1 : -1; if (dx > 0) e.x = Math.floor(nx + e.w / 2) - e.w / 2 - 1e-3; else e.x = Math.floor(nx - e.w / 2) + 1 + e.w / 2 + 1e-3; e.vx = 0; dx = 0; }
        } else e.x = nx;
      }
      if (dy) {
        const ny = e.y + dy;
        let hit = boxHits(W, e.x, ny, e.w, e.h);
        // 발판(위에서 내려올 때만)
        if (!hit && dy > 0 && !o.drop) { const yb = Math.floor(ny - 1e-4); if (yb > Math.floor(e.y - 1e-4)) { const x0 = Math.floor(e.x - e.w / 2), x1 = Math.floor(e.x + e.w / 2 - 1e-4); for (let xx = x0; xx <= x1; xx++) if (PLATT[tAt(W, xx, yb)]) { hit = true; break; } } }
        if (hit) { if (dy > 0) { e.y = Math.floor(ny - 1e-4) - 1e-3 + (0); e.y = Math.ceil(e.y) - 1e-3; e.gnd = 1; e.land = e.vy; } else { e.y = Math.floor(ny - e.h) + 1 + e.h + 1e-3; e.hitC = 1; } e.vy = 0; dy = 0; }
        else e.y = ny;
      }
    }
    if (!e.gnd && e.vy >= 0) { // 발 아래 확인(땅 위에 서 있음)
      if (boxHits(W, e.x, e.y + 0.02, e.w, e.h)) e.gnd = 1;
      else if (!o.drop) { const yb = Math.floor(e.y + 0.02); if (Math.abs(e.y + 0.02 - yb) < 0.06) { const x0 = Math.floor(e.x - e.w / 2), x1 = Math.floor(e.x + e.w / 2 - 1e-4); for (let xx = x0; xx <= x1; xx++) if (PLATT[tAt(W, xx, yb)]) e.gnd = 1; } }
    }
    e.wasGnd = e.gnd;
  }
  function liqIn(W, e) { // 몸이 액체에 얼마나 잠겼나 → {w: 물, l: 용암}
    let wv = 0, lv = 0; const x = Math.floor(e.x);
    for (let y = Math.floor(e.y - e.h); y <= Math.floor(e.y - 0.01); y++) { if (y < 0 || y >= W.h || x < 0 || x >= W.w) continue; const a = W.lq[y * W.w + x]; if (a) { if (a & 16) lv++; else wv++; } }
    return { w: wv, l: lv, n: Math.max(1, Math.ceil(e.h)) };
  }
  function zoneOf(W, x, y) {
    x = clamp(Math.floor(x), 0, W.w - 1);
    if (y < W.surf[x] - 30 && y < 50) return 'sky';
    if (y >= W.hellTop) return 'hell';
    if (y < W.surf[x] + 12) return 'surface';
    if (y < W.cav) return 'under';
    return 'cavern';
  }
  const ZONE_N = { sky: '하늘', surface: '땅 위', under: '땅속', cavern: '깊은 동굴', hell: '지하세계' };
  function chestLoot(kind, R) {
    const it = [];
    const add = (k, n) => it.push([IX[k], n]);
    const pick = (arr) => arr[R() * arr.length | 0];
    if (kind === 'sky') { add(pick(['cloud_jar', 'feather_c', 'cloud_jar']), 1); add('starc', 2 + (R() * 3 | 0)); add('cloud', 20 + (R() * 20 | 0)); add('p_feather', 2); add('coin', 80 + (R() * 80 | 0)); }
    else if (kind === 'hell') { add(pick(['lava_c', 'fire_staff', 'p_fire']), 1); add('b_hl', 3 + (R() * 5 | 0)); add('p_fire', 2); add('coin', 200 + (R() * 200 | 0)); }
    else if (kind === 'deep') { add(pick(['lava_c', 'regen_b', 'mirror', 'arcane_f', 'claw', 'gill_c']), 1); add(pick(['b_au', 'b_ag', 'b_cr']), 4 + (R() * 6 | 0)); add(pick(['p_heal', 'p_iron', 'p_ore', 'p_night', 'p_regen', 'p_mine']), 1 + (R() * 2 | 0)); add('torch', 10 + (R() * 15 | 0)); add('coin', 60 + (R() * 90 | 0)); }
    else { add(pick(['run_boots', 'mirror', 'claw', 'gill_c', 'boomer', 'wd_bow']), 1); add(pick(['b_cu', 'b_fe', 'b_ag']), 3 + (R() * 6 | 0)); add(pick(['p_heal', 'p_swift', 'p_mine', 'p_gill', 'p_night']), 1 + (R() * 2 | 0)); add('torch', 8 + (R() * 12 | 0)); add('arrow', 20 + (R() * 30 | 0)); add('coin', 20 + (R() * 40 | 0)); }
    return it;
  }

  /* ======================= 가방·제작 ======================= */
  const INV = 50, HOT = 10, CHEST_N = 30;
  function addItem(inv, id, n) { const mx = IT[id].mx; for (let k = 0; k < inv.length && n > 0; k++) { const s = inv[k]; if (s && s[0] === id && s[1] < mx) { const m = Math.min(n, mx - s[1]); s[1] += m; n -= m; } } for (let k = 0; k < inv.length && n > 0; k++) if (!inv[k]) { const m = Math.min(n, mx); inv[k] = [id, m]; n -= m; } return n; }
  function countItem(inv, id) { let c = 0; for (const s of inv) if (s && s[0] === id) c += s[1]; return c; }
  function takeItem(inv, id, n) { for (let k = inv.length - 1; k >= 0 && n > 0; k--) { const s = inv[k]; if (s && s[0] === id) { const m = Math.min(n, s[1]); s[1] -= m; n -= m; if (!s[1]) inv[k] = null; } } return n === 0; }
  function canFit(inv, id, n) { const mx = IT[id].mx; for (const s of inv) { if (!s) n -= mx; else if (s[0] === id) n -= mx - s[1]; if (n <= 0) return true; } return n <= 0; }
  function canCraft(inv, r, sts) { if (r.at && !sts[r.at]) return 0; let m = 999; for (const [id, n] of r.in) m = Math.min(m, Math.floor(countItem(inv, id) / n)); return m; }
  function packInv(a) { return a.map((s) => (s ? s[0] + '*' + s[1] : '')).join(','); }
  function unpackInv(str, n) { const out = new Array(n).fill(null); if (typeof str !== 'string') return out; str.split(',').slice(0, n).forEach((p, k) => { if (!p) return; const [a, b] = p.split('*').map(Number); if (IT[a] && b > 0) out[k] = [a, Math.min(b, IT[a].mx)]; }); return out; }

  /* ======================= 플레이어 ======================= */
  const PW = 1.2, PH = 2.75;
  function newPlayer(s, W) {
    const inv = new Array(INV).fill(null);
    for (const [k, n] of [['old_pick', 1], ['old_axe', 1], ['old_sword', 1], ['torch', 12], ['wood', 10], ['p_heal', 2]]) addItem(inv, IX[k], n);
    return { s, x: W.spawn.x + (s - 1.5) * 0.6, y: W.spawn.y - 0.01, vx: 0, vy: 0, w: PW, h: PH, dir: 1, hp: 100, hpM: 100, mp: 20, mpM: 20, inv, arm: [null, null, null], acc: [null, null, null, null, null], sel: 0, bf: {}, iv: 0, cd: 0, sw: null, dead: 0, coy: 0, jb: 0, jh: 0, dj: 0, br: 10, fall: 0, sp: null, regenT: 0, st: null, stT: 0, anim: 0, mn: [], wallS: 0, stats: { kill: 0, mine: 0, craft: 0, place: 0, die: 0, dmg: 0, boss: 0 } };
  }
  function calcStats(p) {
    const s = { def: 0, dmg: 0, spd: 0, jump: 0, mine: 0, regen: 0, crit: 0.04, dj: 0, nofall: 0, glide: 0, lavaImm: 0, breath: 0, light: 0, kbImm: 0, manaR: 0, mana: 0, minion: 1, wall: 0, thorn: 0, fire: 0, ore: 0, night: 0, set: null };
    const addE = (e) => { for (const k in e) s[k] = (s[k] || 0) + e[k]; };
    for (const a of p.arm) if (a) s.def += IT[a[0]].def || 0;
    const sets = p.arm.map((a) => (a ? IT[a[0]].set : null));
    if (sets[0] && sets[0] === sets[1] && sets[1] === sets[2] && SETS[sets[0]]) { s.set = sets[0]; addE(SETS[sets[0]].sbx); }
    for (const a of p.acc) if (a && IT[a[0]].ef) addE(IT[a[0]].ef);
    for (const k in p.bf) if (BUFF[k]) addE(BUFF[k][2]);
    return s;
  }
  function heldItem(p) { const s = p.inv[p.sel]; return s ? IT[s[0]] : null; }

  /* ======================= 게임 세계(실행 상태) ======================= */
  const DAY = 960, NIGHT0 = 0.62; // 하루 16분: 0~0.62 낮
  function newGame(st) {
    const W = genWorld(st.seed, st.sz);
    const G = { W, st, tm: 0.05, day: 1, en: [], dr: [], pj: [], npcs: [], boss: null, ev: null, nid: 1, fx: [], fxq: 0, fl: { coin: 0, hp: 100, mp: 20, anvil: 0, alch: 0, b: [0, 0, 0, 0, 0, 0], raid: 0, meteor: 0 }, log: { s: [], i: [] }, eseq: 0, last: new Map(), grants: [], gseq: 0, chest: {}, msgs: [], dmul: [0.7, 1, 1.5][st.dif | 0] || 1, spawnT: 0, starT: 0, houseT: 3, grow: 0, doors: new Set(), stat: { kills: 0, bosses: 0 }, el: 0, warnBoss: -1 };
    W.lqAct = W.lqAct || new Set();
    for (let i = 0; i < W.w * W.h; i++) if (W.t[i] === T_.door) G.doors.add(i);
    G.npcs.push({ k: 0, x: W.spawn.x + 3, y: W.spawn.y - 0.01, vx: 0, vy: 0, w: 1.2, h: 2.7, dir: -1, home: null, t: 0 });
    return G;
  }
  function logEdit(G, i) { if (G.noLog) return; G.eseq++; G.log.s.push(G.eseq); G.log.i.push(i); G.last.set(i, G.eseq); }
  function setT(G, i, v) { const W = G.W; if (W.t[i] === v) return; const old = W.t[i]; W.t[i] = v; if (old === T_.door) G.doors.delete(i); if (v === T_.door) G.doors.add(i); const x = i % W.w; if (OPAQ[old] !== OPAQ[v] || SOLIDT[old] !== SOLIDT[v]) colTop(W, x); logEdit(G, i); W.lqAct.add(i); W.lqAct.add(i - W.w); W.lqAct.add(i - 1); W.lqAct.add(i + 1); if (v === T_.anvil) G.fl.anvil = 1; if (v === T_.alch) G.fl.alch = 1; }
  function setWl(G, i, v) { if (G.W.wl[i] === v) return; G.W.wl[i] = v; logEdit(G, i); }
  function pushFx(G, e) { G.fxq++; e.unshift(G.fxq); G.fx.push(e); if (G.fx.length > 60) G.fx.shift(); }
  function say(G, text, col) { pushFx(G, ['m', text, col || '#f2e9d8']); }
  function isDay(G) { return G.tm < NIGHT0; }

  /* ----- 타일 부수기·놓기 (호스트/혼자만) ----- */
  function giveItem(G, seat, id, n, x, y) { // 플레이어에게 주기(못 받으면 바닥에)
    if (!n) return;
    const P = G.P && G.P[seat];
    if (P && P.local) { const left = addItem(P.inv, id, n); if (left) dropItem(G, id, left, x, y); pushFx(G, ['g', seat, id, n - left]); return; }
    if (P) { G.gseq++; G.grants.push([G.gseq, seat, id, n]); if (G.grants.length > 120) G.grants.shift(); return; }
    dropItem(G, id, n, x, y);
  }
  function dropItem(G, id, n, x, y, vx, vy) { if (G.dr.length > 220) G.dr.shift(); G.dr.push({ id: G.nid++, it: id, n, x, y, vx: vx === undefined ? (Math.random() - 0.5) * 6 : vx, vy: vy === undefined ? -6 : vy, w: 0.8, h: 0.8, t: 0 }); }
  function breakTile(G, x, y, seat, noDrop) {
    const W = G.W; if (x < 1 || y < 1 || x >= W.w - 1 || y >= W.h - 1) return false;
    const i = y * W.w + x, tt = W.t[i]; if (!tt) return false;
    const T = TL[tt];
    if (tt === T_.chest) { const c = G.chest[i]; if (c && c.some((s) => s)) return false; delete G.chest[i]; delete W.chests[i]; }
    // 문: 위아래로 이어진 문 전부
    if (T.door) { let y0 = y; while (y0 > 0 && TL[W.t[(y0 - 1) * W.w + x]].door) y0--; let k = 0; while (k < 3 && TL[W.t[(y0 + k) * W.w + x]].door) { setT(G, (y0 + k) * W.w + x, 0); k++; } if (!noDrop) giveItem(G, seat, IX.door, 1, x + 0.5, y + 0.5); return true; }
    // 나무: 위로 이어진 줄기·잎 전부
    if (T.f & 32) {
      let n = 0, yy = y;
      while (yy > 0 && TL[W.t[yy * W.w + x]].f & 32) { setT(G, yy * W.w + x, 0); n++; yy--; }
      for (let dy = -6; dy <= 1; dy++) for (let dx = -5; dx <= 5; dx++) { const xx = x + dx, y2 = yy + dy; if (xx < 0 || xx >= W.w || y2 < 0) continue; const j = y2 * W.w + xx, q = W.t[j]; if (q === T_.leaf || q === T_.pine || q === T_.jleaf) setT(G, j, 0); }
      if (!noDrop) { giveItem(G, seat, IX[T.dr], n * (tt === T_.log ? 2 : 1), x + 0.5, y + 0.5); if (tt === T_.log && Math.random() < 0.6) giveItem(G, seat, IX.acorn, 1 + (Math.random() * 2 | 0), x + 0.5, y); }
      return true;
    }
    setT(G, i, 0);
    if (!noDrop) {
      if (T.pot) { // 항아리: 동전·횃불·물약
        const r = Math.random(), dep = (y - W.surf[x]) / (W.hellTop - W.surf[x]);
        if (r < 0.45) giveItem(G, seat, IX.coin, 3 + (Math.random() * 12 * (1 + dep * 4) | 0), x + 0.5, y);
        else if (r < 0.7) giveItem(G, seat, IX.torch, 3 + (Math.random() * 6 | 0), x + 0.5, y);
        else if (r < 0.85) giveItem(G, seat, IX.p_heal, 1, x + 0.5, y);
        else giveItem(G, seat, IX.arrow, 10 + (Math.random() * 15 | 0), x + 0.5, y);
        pushFx(G, ['pt', x, y]);
      } else if (T.dr && IX[T.dr] !== undefined) giveItem(G, seat, IX[T.dr], 1, x + 0.5, y + 0.5);
    }
    // 위에 받침이 필요한 것들 함께 부수기 · 모래 떨어짐
    const up = i - W.w, ut = W.t[up];
    if (ut && (TL[ut].f & 4) && !(ut === T_.torch && (W.wl[up] || SOLIDT[W.t[up - 1]] || SOLIDT[W.t[up + 1]]))) breakTile(G, x, y - 1, seat, noDrop);
    else if (ut && TL[ut].f & 32) breakTile(G, x, y - 1, seat, noDrop);
    else if (ut === T_.sand) sandFall(G, x, y - 1);
    // 아래에 매달린 덩굴
    const dn = i + W.w; if (W.t[dn] === T_.vine) breakTile(G, x, y + 1, seat, true);
    // 옆에 붙은 횃불
    for (const d of [-1, 1]) { const j = i + d; if (W.t[j] === T_.torch && !W.wl[j] && !SOLIDT[W.t[j + W.w]] && !SOLIDT[W.t[j - d]]) breakTile(G, x + d, y, seat, noDrop); }
    return true;
  }
  function sandFall(G, x, y) { const W = G.W; let yy = y; while (yy > 0 && W.t[yy * W.w + x] === T_.sand) { let ny = yy; while (ny + 1 < W.h - 1 && !SOLIDT[W.t[(ny + 1) * W.w + x]] && !W.t[(ny + 1) * W.w + x]) ny++; if (ny === yy) break; setT(G, yy * W.w + x, 0); setT(G, ny * W.w + x, T_.sand); yy--; } }
  function canPlace(G, x, y, tt, ents) {
    const W = G.W; if (x < 2 || y < 2 || x >= W.w - 2 || y >= W.h - 2) return '';
    const i = y * W.w + x, cur = W.t[i];
    if (cur && !(TL[cur].f & 16 && !(tt && TL[tt].f & 16))) { if (!(TL[cur].f & 16)) return ''; }
    const T = TL[tt];
    if (T.door) { for (let k = 0; k < 3; k++) if (W.t[(y - k) * W.w + x]) return '문은 세로 3칸이 비어 있어야 해요'; if (!SOLIDT[W.t[(y + 1) * W.w + x]]) return '문 아래에 바닥이 필요해요'; }
    else if (T.f & 4) { if (tt === T_.torch) { if (!SOLIDT[W.t[i + W.w]] && !W.wl[i] && !SOLIDT[W.t[i - 1]] && !SOLIDT[W.t[i + 1]]) return '횃불은 벽·땅에 붙여요'; } else if (!SOLIDT[W.t[i + W.w]]) return '아래에 받침이 필요해요'; if (tt === T_.sapling && W.t[i + W.w] !== T_.grass && W.t[i + W.w] !== T_.jgrass && W.t[i + W.w] !== T_.snow) return '도토리는 풀흙에 심어요'; }
    else if (SOLIDT[tt] || PLATT[tt]) {
      // 이웃이 있어야(허공에 못 놓음)
      const nb = [i - 1, i + 1, i - W.w, i + W.w].some((j) => W.t[j] && !(TL[W.t[j]].f & 16)) || W.wl[i];
      if (!nb) return '';
      if (SOLIDT[tt] && ents) for (const e of ents) { if (e && e.x + e.w / 2 > x && e.x - e.w / 2 < x + 1 && e.y > y && e.y - e.h < y + 1) return ''; }
    }
    return 'ok';
  }
  function placeTile(G, x, y, tt) { const W = G.W; const T = TL[tt]; if (T.door) { for (let k = 0; k < 3; k++) setT(G, (y - k) * W.w + x, T_.door); return; } setT(G, y * W.w + x, tt); if (tt === T_.chest) G.chest[y * W.w + x] = new Array(CHEST_N).fill(null); if (tt === T_.sand) sandFall(G, x, y); }
  function toggleDoor(G, x, y) { const W = G.W; const T = TL[tAt(W, x, y)]; if (!T.door) return false; let y0 = y; while (y0 > 0 && TL[W.t[(y0 - 1) * W.w + x]].door) y0--; const to = T.door === 1 ? T_.dooro : T_.door; for (let k = 0; k < 3; k++) { const j = (y0 + k) * W.w + x; if (TL[W.t[j]].door) setT(G, j, to); } return true; }
  function chestOf(G, i) { if (!G.chest[i]) { const kind = G.W.chests[i]; const c = new Array(CHEST_N).fill(null); if (kind) { const R = rng(G.W.seed * 31 + i); chestLoot(kind, R).forEach((s, k) => { c[k] = s; }); } G.chest[i] = c; } return G.chest[i]; }

  /* ----- 집(정착민) ----- */
  function checkHouse(W, sx, sy) {
    const w = W.w; const start = sy * w + sx;
    if (sx < 1 || sy < 1 || sx >= w - 1 || sy >= W.h - 1 || SOLIDT[W.t[start]]) return { ok: 0, why: '빈 칸을 골라 주세요' };
    const seen = new Set([start]), q = [start];
    let light = 0, tab = 0, chair = 0, door = 0, wallMiss = 0, n = 0, floorY = -1, floorX = -1;
    while (q.length) {
      const i = q.pop(); n++;
      if (n > 750) return { ok: 0, why: '방이 너무 크거나 막혀 있지 않아요' };
      const tt = W.t[i], T = TL[tt];
      if (!W.wl[i] || WL[W.wl[i]].nat) wallMiss++;
      if (T.lt >= 0.5) light = 1;
      if (T.furn === 't' || tt === T_.wbench) tab = 1; if (T.furn === 'c') chair = 1;
      const x = i % w, y = (i / w) | 0;
      if (x < 2 || y < 2 || x >= w - 2 || y >= W.h - 2) return { ok: 0, why: '방이 막혀 있지 않아요' };
      if (SOLIDT[W.t[i + w]] && !SOLIDT[tt] && (floorY < 0 || y > floorY)) { floorY = y; floorX = x; }
      for (const j of [i - 1, i + 1, i - w, i + w]) {
        if (seen.has(j)) continue; const jt = W.t[j];
        if (TL[jt].door) { door = 1; continue; }
        if (SOLIDT[jt] || PLATT[jt]) continue;
        seen.add(j); q.push(j);
      }
    }
    if (n < 40) return { ok: 0, why: '방이 너무 작아요(40칸 이상)' };
    if (wallMiss > 0) return { ok: 0, why: '배경 벽(직접 붙인 벽)이 빠진 칸이 ' + wallMiss + '개 있어요' };
    if (!door) return { ok: 0, why: '문이 필요해요' };
    if (!light) return { ok: 0, why: '횃불이나 등불이 필요해요' };
    if (!tab) return { ok: 0, why: '탁자 종류(탁자·작업대·연금대·책장)가 필요해요' };
    if (!chair) return { ok: 0, why: '의자가 필요해요' };
    return { ok: 1, n, x: floorX + 0.5, y: floorY + 0.999, key: Math.min(...seen) };
  }
  function houseTick(G) {
    const W = G.W, houses = [], seenKeys = new Set();
    for (const d of G.doors) { if (TL[W.t[d - W.w]].door) continue; for (const dx of [-1, 1]) { const x = (d % W.w) + dx, y = ((d / W.w) | 0) + 1; const r = checkHouse(W, x, y); if (r.ok && !seenKeys.has(r.key)) { seenKeys.add(r.key); houses.push(r); } } if (houses.length > 40) break; }
    const used = new Set(G.npcs.filter((n) => n.home).map((n) => n.home[2]));
    for (const n of G.npcs) if (n.home && !seenKeys.has(n.home[2])) { n.home = null; say(G, NPC[n.k].n + '의 집이 망가졌어요', '#ee8a6a'); }
    const free = houses.filter((h) => !used.has(h.key));
    for (const n of G.npcs) if (!n.home && free.length) { const h = free.shift(); n.home = [h.x, h.y, h.key]; say(G, NPC[n.k].n + '이(가) 집에 들어갔어요', '#9ae07a'); }
    for (let k = 0; k < NPC.length; k++) {
      if (G.npcs.some((n) => n.k === k)) continue;
      if (!NPC[k].cond(G)) continue;
      if (!free.length) continue;
      const h = free.shift(); G.npcs.push({ k, x: h.x, y: h.y, vx: 0, vy: 0, w: 1.2, h: 2.7, dir: 1, home: [h.x, h.y, h.key], t: 0 });
      say(G, NPC[k].n + '이(가) 이사 왔어요!', '#ffd257'); pushFx(G, ['snd', 'win']);
      break;
    }
  }
  function npcTick(G, n, dt) {
    const W = G.W; n.t -= dt;
    const day = isDay(G);
    if (n.t <= 0) { n.t = 1.5 + Math.random() * 3; n.mv = Math.random() < 0.55 ? (Math.random() < 0.5 ? -1 : 1) : 0; if (n.home) { const d = n.home[0] - n.x; if (Math.abs(d) > 6 || !day) n.mv = Math.abs(d) > 0.6 ? Math.sign(d) : 0; } }
    n.vx = (n.mv || 0) * 2.2; if (n.mv) n.dir = n.mv;
    n.vy = Math.min(n.vy + 60 * dt, 30);
    moveBody(W, n, dt, { step: 1 });
    if (n.hitW && n.gnd) n.vy = -16;
    if (n.home && (Math.abs(n.home[0] - n.x) > 40 || Math.abs(n.home[1] - n.y) > 30)) { n.x = n.home[0]; n.y = n.home[1]; }
    if (n.y > W.h - 2) { n.x = W.spawn.x; n.y = W.spawn.y; }
  }

  /* ----- 적 ----- */
  function spawnEnemy(G, type, x, y, o) { const E = EN[type]; const m = G.dmul; const e = Object.assign({ id: G.nid++, t: type, x, y, vx: 0, vy: 0, w: E.w, h: E.h, hp: Math.round(E.hp * (m > 1 ? 1.4 : m < 1 ? 0.85 : 1)), hpM: 0, dir: 1, at: Math.random() * 2, st: 0, fire: 0, slow: 0, life: 0, tg: -1, hurt: 0 }, o || {}); e.hpM = e.hp; G.en.push(e); return e; }
  function spawnChoices(G, W, p) {
    const x = clamp(Math.floor(p.x), 0, W.w - 1), z = zoneOf(W, p.x, p.y), b = W.bio[x], night = !isDay(G);
    const ev = G.ev && G.ev.k;
    const L2 = [];
    if (z === 'sky') L2.push('harp', 'harp', 'nbat');
    else if (z === 'hell') L2.push('fiend', 'lslime', 'fbat', 'fbat');
    else if (z === 'surface') {
      if (ev === 'raid') L2.push('raider', 'raider', 'rthrow', 'rmage');
      if (b === 4) { if (liqIn(W, p).w) L2.push('fang', 'fang'); else L2.push(night ? 'walker' : 'gslime'); }
      else if (night) { L2.push('walker', 'walker', 'nbat'); if (ev === 'blood') L2.push('rwalker', 'rwalker', 'nbat'); if (b === 1) L2.push('scorp'); if (b === 3) L2.push('wasp', 'jslime'); if (b === 2) L2.push('sslime'); }
      else { if (b === 1) L2.push('dslime', 'dslime', 'scorp'); else if (b === 2) L2.push('sslime', 'sslime'); else if (b === 3) L2.push('jslime', 'wasp'); else L2.push('gslime', 'gslime', 'gslime'); }
    } else {
      const deep = z === 'cavern';
      L2.push('cbat', deep ? 'bminer' : 'crab', deep ? 'bminer' : 'cbat');
      if (deep) L2.push('cspider');
      if (b === 2) L2.push('icesp', 'sslime'); if (b === 3) L2.push('wasp', 'jslime'); if (b === 1) L2.push('scorp');
      if (liqIn(W, p).w) L2.push('fang');
    }
    return L2.map((k) => EX[k]);
  }
  function enemyCap(G, z) { const ev = G.ev && G.ev.k; if (ev === 'raid' && z === 'surface') return 11; if (ev === 'blood' && z === 'surface') return 10; if (z === 'surface') return isDay(G) ? 3 : 6; return z === 'hell' ? 7 : 6; }
  function trySpawn(G, p) {
    const W = G.W, z = zoneOf(W, p.x, p.y);
    if (G.boss && G.boss.b !== 1) return;
    const near = G.en.filter((e) => Math.abs(e.x - p.x) < 60 && Math.abs(e.y - p.y) < 40).length;
    if (near >= enemyCap(G, z)) return;
    const ch = spawnChoices(G, W, p); if (!ch.length) return;
    const type = ch[Math.random() * ch.length | 0], E = EN[type];
    for (let a = 0; a < 14; a++) {
      const sx = Math.floor(p.x + (Math.random() < 0.5 ? -1 : 1) * (26 + Math.random() * 18)), sy0 = Math.floor(p.y + (Math.random() - 0.6) * 24);
      if (sx < 3 || sx >= W.w - 3) continue;
      for (let sy = sy0; sy < sy0 + 18 && sy < W.h - 2; sy++) {
        if (sy < 2) continue;
        const i = sy * W.w + sx;
        if (W.wl[i] && !WL[W.wl[i]].nat) break; // 집 안에는 안 생김
        if (E.ai === 'swim') { if (W.lq[i] && !(W.lq[i] & 16) && !SOLIDT[W.t[i]]) { spawnEnemy(G, type, sx + 0.5, sy + 0.9); return; } continue; }
        const fly = E.ai === 'fly' || E.ai === 'shoot';
        if (fly) { if (!boxHits(W, sx + 0.5, sy + 0.9, E.w, E.h) && !W.lq[i]) { spawnEnemy(G, type, sx + 0.5, sy + 0.9); return; } continue; }
        if (SOLIDT[W.t[i + W.w]] && !boxHits(W, sx + 0.5, sy + 0.999, E.w, E.h) && !(W.lq[i] & 16 && !E.lavaImm)) { spawnEnemy(G, type, sx + 0.5, sy + 0.999); return; }
      }
    }
  }
  function nearestP(G, x, y, maxD) { let best = null, bd = maxD || 1e9; for (const p of G.alive) { const d = Math.hypot(p.x - x, p.y - p.h / 2 - y); if (d < bd) { bd = d; best = p; } } return best; }
  function shootPj(G, type, x, y, tx, ty, spd, dmg, o) { const a = Math.atan2(ty - y, tx - x); G.pj.push(Object.assign({ id: G.nid++, k: type, x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, dmg, life: 4, g: 0 }, o || {})); if (G.pj.length > 160) G.pj.shift(); }
  function enemyTick(G, e, dt) {
    const W = G.W, E = EN[e.t];
    e.life += dt; e.hurt = Math.max(0, e.hurt - dt);
    const sl = e.slow > 0 ? 0.55 : 1; e.slow = Math.max(0, e.slow - dt);
    if (e.fire > 0) { e.fire -= dt; e.fireT = (e.fireT || 0) - dt; if (e.fireT <= 0) { e.fireT = 0.5; hurtEnemy(G, e, 4, 0, -1, 0, 1); if (e.dead) return; } }
    const p = nearestP(G, e.x, e.y - e.h / 2, 80);
    const tx = p ? p.x : e.x + e.dir * 10, ty = p ? p.y - p.h / 2 : e.y;
    const dx = tx - e.x, dy = ty - (e.y - e.h / 2);
    const lq = liqIn(W, e);
    if (lq.l && !E.lavaImm) { e.lt = (e.lt || 0) - dt; if (e.lt <= 0) { e.lt = 0.5; hurtEnemy(G, e, 20, 0, -1, 0, 1); if (e.dead) return; } }
    e.at -= dt;
    switch (E.ai) {
      case 'slime': {
        if (e.gnd) { e.vx *= 0.8; if (e.at <= 0) { e.at = 0.9 + Math.random() * 1.4; e.dir = Math.sign(dx) || 1; e.vx = e.dir * E.sp * (1.2 + Math.random()) * (e.t === EX.lslime ? 1.4 : 1); e.vy = -(12 + Math.random() * 9); } }
        e.vy += 55 * dt; break;
      }
      case 'walk': case 'throw': {
        e.dir = Math.sign(dx) || e.dir;
        let want = e.dir * E.sp * sl;
        if (E.ai === 'throw' && Math.abs(dx) < 9 && Math.abs(dy) < 6) { want = 0; if (e.at <= 0 && p) { e.at = 1.8; const sp = 14; G.pj.push({ id: G.nid++, k: 'spike', x: e.x, y: e.y - e.h * 0.7, vx: Math.sign(dx) * Math.min(sp, Math.abs(dx) * 1.2 + 3), vy: -10 + dy * 0.6, dmg: E.dmg, life: 3, g: 30 }); } }
        e.vx += (want - e.vx) * Math.min(1, dt * 6);
        if (e.gnd && (e.hitW || (dy < -3 && Math.abs(dx) < 4 && e.at < -1))) { e.vy = -18; e.at = 0; }
        if (lq.w) e.vy -= 30 * dt;
        e.vy += 60 * dt; break;
      }
      case 'fly': case 'shoot': {
        const wob = Math.sin(e.life * 3 + e.id) * 2;
        let gx = dx, gy = dy + wob;
        if (E.ai === 'shoot') { const d = Math.hypot(dx, dy); if (d < 9) { gx = -dx; gy = -dy - 3; } else if (d < 14) { gx = dx * 0.1; gy = -2 + wob; } if (e.at <= 0 && p && d < 26) { e.at = 2.2 + Math.random(); const pk = E.pj || 'thorn'; shootPj(G, pk, e.x, e.y - e.h / 2, tx, ty, pk === 'icebolt' ? 13 : 16, E.dmg * 0.8); pushFx(G, ['snd', 'pj']); } }
        const L3 = Math.hypot(gx, gy) || 1;
        e.vx += (gx / L3 * E.sp * sl - e.vx) * Math.min(1, dt * 2.2); e.vy += (gy / L3 * E.sp * sl - e.vy) * Math.min(1, dt * 2.2);
        if (e.hitW) e.vx = -e.vx * 0.6; if (e.hitC || e.gnd) e.vy = -e.vy * 0.6;
        e.dir = Math.sign(e.vx) || e.dir;
        if (lq.w && E.k !== 'fang') e.vy -= 20 * dt;
        break;
      }
      case 'swim': {
        if (lq.w) { const tIn = p && liqIn(W, p).w; const gx = tIn ? dx : Math.sin(e.life * 0.7 + e.id) * 5, gy = tIn ? dy : Math.sin(e.life * 1.3) * 1.5; const L3 = Math.hypot(gx, gy) || 1; e.vx += (gx / L3 * E.sp - e.vx) * dt * 2; e.vy += (gy / L3 * E.sp - e.vy) * dt * 2; const above = W.lq[Math.floor(e.y - e.h - 0.2) * W.w + Math.floor(e.x)]; if (!above && e.vy < 0) e.vy *= 0.5; }
        else { e.vy += 60 * dt; if (e.gnd && e.at <= 0) { e.at = 0.6; e.vy = -8; e.vx = (Math.random() - 0.5) * 6; } }
        e.dir = Math.sign(e.vx) || e.dir; break;
      }
      case 'caster': {
        e.vx *= 0.85; e.vy += 60 * dt;
        if (e.at <= 0 && p) {
          e.st = (e.st + 1) % 4;
          if (e.st === 0) { // 순간이동
            for (let a = 0; a < 20; a++) { const nx = Math.floor(p.x + (Math.random() - 0.5) * 30), ny = Math.floor(p.y + (Math.random() - 0.5) * 16); if (nx < 2 || nx >= W.w - 2 || ny < 3 || ny >= W.h - 2) continue; if (SOLIDT[W.t[(ny + 1) * W.w + nx]] && !boxHits(W, nx + 0.5, ny + 0.999, e.w, e.h) && Math.abs(nx - p.x) > 5) { pushFx(G, ['tp', e.x, e.y - 1, nx + 0.5, ny]); e.x = nx + 0.5; e.y = ny + 0.999; e.vy = 0; break; } }
            e.at = 1.1;
          } else { shootPj(G, E.pj || 'shadow', e.x, e.y - e.h * 0.7, tx, ty, 11, E.dmg * 0.9, { life: 5, home: E.pj === 'shadow' ? 1 : 0 }); e.at = 0.9; pushFx(G, ['snd', 'pj']); }
        }
        e.dir = Math.sign(dx) || e.dir; break;
      }
    }
    e.vy = clamp(e.vy, -40, 40);
    const grav = E.ai === 'fly' || E.ai === 'shoot' || (E.ai === 'swim' && lq.w);
    moveBody(W, e, dt, { step: E.ai === 'walk' || E.ai === 'throw' ? 1 : 0, drop: 0 });
    if (grav && e.gnd && E.ai !== 'swim') e.vy = -2;
    // 낮 & 멀리 → 사라짐 / 너무 멀면 사라짐
    const farAll = !G.alive.some((q) => Math.abs(q.x - e.x) < 90 && Math.abs(q.y - e.y) < 60);
    if (farAll || e.y > W.h - 1) e.dead = 2;
    if (isDay(G) && (E.k === 'walker' || E.k === 'nbat' || E.k === 'rwalker') && zoneOf(W, e.x, e.y) === 'surface' && e.life > 5 && Math.random() < dt * 0.3) { e.dead = 2; pushFx(G, ['pf', e.x, e.y - e.h / 2, 0]); }
  }
  function hurtEnemy(G, e, dmg, kb, dirX, crit, dot, seat, fire) {
    if (e.dead) return;
    const E = EN[e.t];
    const d = Math.max(1, Math.round(dmg - (dot ? 0 : E.def * 0.5)));
    e.hp -= d; e.hurt = 0.15;
    if (kb && dirX) { const k = kb * (1 - E.kbr); e.vx = dirX * k * 2.2; if (E.ai !== 'fly' && E.ai !== 'shoot') e.vy = Math.min(e.vy, -k * 1.4); else e.vy -= k * 0.5; }
    if (fire) e.fire = 4;
    if (fire === 2) e.slow = 3;
    pushFx(G, ['dn', r1(e.x), r1(e.y - e.h), d, crit ? 1 : 0]);
    if (e.hp <= 0) {
      e.dead = 1; G.stat.kills++;
      if (seat >= 0 && G.P[seat]) G.P[seat].kills = (G.P[seat].kills | 0) + 1;
      for (const [k, a, b, c] of E.dr) if (Math.random() < c) dropItem(G, IX[k], a + (Math.random() * (b - a + 1) | 0), e.x, e.y - e.h / 2);
      const cn = Math.round((E.coin[0] + Math.random() * (E.coin[1] - E.coin[0])) * (G.dmul > 1 ? 1.5 : 1)); if (cn > 0) dropItem(G, IX.coin, cn, e.x, e.y - e.h / 2);
      if (E.k === 'gslime' && Math.random() < 0.02) dropItem(G, IX.s_slime, 1, e.x, e.y);
      if (G.ev && G.ev.k === 'raid' && (E.k === 'raider' || E.k === 'rthrow' || E.k === 'rmage')) { G.ev.left--; if (G.ev.left <= 0) { say(G, '약탈단을 물리쳤어요!', '#ffd257'); G.ev = null; G.fl.raid = 1; pushFx(G, ['snd', 'win']); } }
      pushFx(G, ['pf', r1(e.x), r1(e.y - e.h / 2), e.t]);
    } else if (E.k === 'mslime' && false) { /* none */ }
  }

  /* ----- 보스 ----- */
  function bossSpawn(G, b, p) {
    if (G.boss) return false;
    const W = G.W, B = BOSS[b];
    const hpMul = (1 + (G.alive.length - 1) * 0.6) * (G.dmul > 1 ? 1.3 : G.dmul < 1 ? 0.85 : 1);
    const o = { b, x: p.x + (b === 0 ? 20 : 0), y: p.y - (b === 0 ? 30 : b === 2 ? -20 : 22), vx: 0, vy: 0, w: B.w, h: B.h, hp: Math.round(B.hp * hpMul), hpM: 0, ph: 1, t: 2, st: 0, tg: p.s, life: 0, hurt: 0 };
    o.hpM = o.hp;
    if (b === 2) { o.seg = []; for (let k = 0; k < B.seg; k++) o.seg.push([o.x, o.y + k]); o.a = -Math.PI / 2; }
    if (b === 3) o.hands = [{ x: o.x - 6, y: o.y + 2, t: 0, st: 0 }, { x: o.x + 6, y: o.y + 2, t: 1.2, st: 0 }];
    G.boss = o; say(G, B.n + '이(가) 깨어났어요!', '#ff8a6a'); pushFx(G, ['boss', b]);
    return true;
  }
  function bossTick(G, o, dt) {
    const W = G.W, B = BOSS[o.b];
    o.life += dt; o.t -= dt; o.hurt = Math.max(0, o.hurt - dt);
    let p = G.alive.find((q) => q.s === o.tg) || nearestP(G, o.x, o.y);
    if (!p || (o.b === 1 || o.b === 3) && isDay(G) && o.life > 5 || (p && Math.hypot(p.x - o.x, p.y - o.y) > 160)) { // 떠남
      o.leave = (o.leave || 0) + dt; o.vy -= 40 * dt; o.y += o.vy * dt;
      if (o.leave > 2.5) { say(G, B.n + '이(가) 떠났어요', '#ab9fb8'); G.boss = null; }
      return;
    }
    if (o.life % 8 < dt) { const np = nearestP(G, o.x, o.y); if (np) o.tg = np.s; p = np || p; }
    const px = p.x, py = p.y - p.h / 2, dx = px - o.x, dy = py - o.y;
    if (o.ph === 1 && o.hp < o.hpM * 0.5) { o.ph = 2; say(G, B.n + '이(가) 성났어요!', '#ff6a3a'); pushFx(G, ['shake', 14]); o.t = 0.5; }
    const fast = o.ph === 2 ? 1.35 : 1;
    switch (o.b) {
      case 0: { // 왕젤리 — o.y는 발밑
        o.vy += 50 * dt;
        o.x += o.vx * dt; const svx = o.vx; o.vx = 0; // 옆으로는 땅을 지나가요(큰 몸이 턱에 걸리지 않게)
        let up = 0; while (up < 12 && boxHits(W, o.x, o.y, o.w * 0.8, o.h * 0.6)) { o.y -= 1; up++; }
        moveBody(W, o, dt, {}); o.vx = svx;
        if (o.gnd) { o.vx *= 0.85; if (o.landed === 0) { pushFx(G, ['shake', 8]); pushFx(G, ['dust', o.x, o.y, 6]); } o.landed = 1;
          if (o.t <= 0) { o.st++; o.landed = 0; const big = o.st % 3 === 0; o.vx = Math.sign(dx) * (big ? 12 : 8) * fast; o.vy = big ? -30 : -18; o.t = (big ? 1.4 : 0.8) / fast; if (o.ph === 2 && o.st % 5 === 0 && Math.abs(dx) > 14) { pushFx(G, ['tp', o.x, o.y - 2, px, p.y - 3]); o.x = px; o.y = p.y - 6; o.vy = 0; o.vx = 0; } } }
        else o.landed = o.landed === 1 ? 0 : o.landed;
        if (o.y > W.h - 3) { o.y = p.y - 10; }
        o.far = Math.abs(dy) > 10 || Math.abs(dx) > 40 ? (o.far || 0) + dt : 0;
        if (o.far > 4 && o.gnd) { // 멀어지면 곁으로 순간이동
          for (let a = 0; a < 30; a++) { const nx = Math.floor(px + (Math.random() - 0.5) * 16), ny = Math.floor(p.y - 1 - Math.random() * 4); if (!boxHits(W, nx + 0.5, ny + 0.999, o.w * 0.8, o.h * 0.8)) { pushFx(G, ['tp', o.x, o.y - 2, nx + 0.5, ny - 1]); o.x = nx + 0.5; o.y = ny + 0.999; o.vx = o.vy = 0; o.far = 0; break; } }
        }
        break;
      }
      case 1: { // 어둠의 응시자 — o.y = 가운데
        if (o.ph === 1 || o.st < 0) {
          const gx = px - o.x, gy = py - 12 - o.y; o.vx += (gx * 1.5 - o.vx) * dt * 1.5; o.vy += (gy * 1.5 - o.vy) * dt * 1.5;
          if (o.t <= 0) { o.st++; o.t = 1.2; if (o.st % 3) { for (let k = -1; k <= 1; k++) { const a = Math.atan2(dy, dx) + k * 0.25; G.pj.push({ id: G.nid++, k: 'bolt', x: o.x, y: o.y, vx: Math.cos(a) * 16, vy: Math.sin(a) * 16, dmg: B.dmg * 0.7 * G.dmul, life: 4, g: 0 }); } pushFx(G, ['snd', 'pj']); } else if (G.en.length < 40) { for (let k = 0; k < 3; k++) spawnEnemy(G, EX.gazelet, o.x + (k - 1) * 2, o.y + 2); } }
        } else { // 돌진
          if (o.t <= 0) { o.dash = (o.dash | 0) + 1; if (o.dash % 4 === 0) { o.t = 1.4; o.vx *= 0.2; o.vy *= 0.2; } else { const a = Math.atan2(dy, dx); o.vx = Math.cos(a) * 34; o.vy = Math.sin(a) * 34; o.t = 0.75; pushFx(G, ['snd', 'roar']); } }
          o.vx *= 1 - dt * 0.9; o.vy *= 1 - dt * 0.9;
        }
        o.x += o.vx * dt; o.y += o.vy * dt; o.ang = Math.atan2(dy, dx);
        break;
      }
      case 2: { // 철갑 땅굴벌레 — 머리 o.x,o.y(가운데)
        const inGround = solidAt(W, Math.floor(o.x), Math.floor(o.y)) || W.wl[Math.floor(o.y) * W.w + Math.floor(o.x)];
        const want = Math.atan2(dy, dx), turn = (inGround ? 2.2 : 0.9) * fast;
        let da = want - o.a; while (da > Math.PI) da -= TAU; while (da < -Math.PI) da += TAU;
        if (inGround) o.a += clamp(da, -turn * dt, turn * dt);
        const sp = (inGround ? 15 : 12) * fast;
        if (inGround) { o.vx = Math.cos(o.a) * sp; o.vy = Math.sin(o.a) * sp; } else { o.vy += 30 * dt; o.vx *= 0.995; o.a = Math.atan2(o.vy, o.vx); }
        o.x += o.vx * dt; o.y += o.vy * dt;
        o.x = clamp(o.x, 3, W.w - 3); o.y = clamp(o.y, 5, W.h - 4);
        let lx = o.x, ly = o.y;
        for (const s of o.seg) { const ddx = s[0] - lx, ddy = s[1] - ly, d = Math.hypot(ddx, ddy) || 1; if (d > 1.7) { s[0] = lx + ddx / d * 1.7; s[1] = ly + ddy / d * 1.7; } lx = s[0]; ly = s[1]; }
        if (o.t <= 0 && o.ph === 2) { o.t = 1.6; const s = o.seg[(Math.random() * o.seg.length) | 0]; shootPj(G, 'bolt', s[0], s[1], px, py, 12, B.dmg * 0.5 * G.dmul); }
        if ((o.life * 4 | 0) % 4 === 0 && inGround && Math.random() < 0.2) pushFx(G, ['dust', o.x, o.y, 2]);
        break;
      }
      case 3: { // 뼈무덤 거인 — 머리 + 두 손
        if (o.ph === 1) { const gx = px - o.x, gy = py - 9 - o.y; o.vx += (gx * 1.2 - o.vx) * dt; o.vy += (gy * 1.2 - o.vy) * dt; }
        else { const a = Math.atan2(dy, dx); o.vx += (Math.cos(a) * 13 - o.vx) * dt * 1.5; o.vy += (Math.sin(a) * 13 - o.vy) * dt * 1.5; o.spin = (o.spin || 0) + dt * 9; }
        o.x += o.vx * dt; o.y += o.vy * dt;
        o.hands.forEach((hd, k) => {
          hd.t -= dt; const side = k ? 1 : -1;
          if (hd.st === 0) { hd.x += (o.x + side * 6 - hd.x) * dt * 4; hd.y += (o.y + 2 - hd.y) * dt * 4; if (hd.t <= 0) { hd.st = 1; hd.t = 0.6; hd.tx = px; hd.ty = p.y - 1; } }
          else if (hd.st === 1) { hd.x += (hd.tx - hd.x) * dt * 3; hd.y += (hd.ty - 10 - hd.y) * dt * 3; if (hd.t <= 0) { hd.st = 2; hd.t = 0.5; } }
          else if (hd.st === 2) { hd.y += 40 * dt; if (solidAt(W, Math.floor(hd.x), Math.floor(hd.y + 1)) || hd.t <= 0) { hd.st = 0; hd.t = 1.4 + Math.random(); pushFx(G, ['shake', 6]); pushFx(G, ['dust', hd.x, hd.y + 1, 4]); } }
        });
        if (o.t <= 0) { o.t = o.ph === 2 ? 0.8 : 1.6; for (let k = 0; k < (o.ph === 2 ? 1 : 3); k++) shootPj(G, 'bone', o.x, o.y, px + (k - 1) * 3, py, 14, B.dmg * 0.6 * G.dmul, { g: 8 }); }
        break;
      }
      case 4: { // 화염 군주
        o.st = o.st || 0;
        const gx = px - o.x, gy = py - 8 - o.y;
        if (o.cg > 0) { o.cg -= dt; } else { o.vx += (gx * 0.9 - o.vx) * dt * 1.2; o.vy += (gy * 0.9 - o.vy) * dt * 1.2; }
        o.x += o.vx * dt; o.y += o.vy * dt; o.rot = (o.rot || 0) + dt * 2 * fast;
        if (o.t <= 0) {
          o.st++;
          const m = o.st % 4;
          if (m === 1) { for (let k = 0; k < 12; k++) { const a = k / 12 * TAU + o.rot; G.pj.push({ id: G.nid++, k: 'fireb', x: o.x, y: o.y, vx: Math.cos(a) * 11, vy: Math.sin(a) * 11, dmg: B.dmg * 0.6 * G.dmul, life: 4, g: 0 }); } o.t = 1.4 / fast; }
          else if (m === 2) { for (let k = 0; k < 8; k++) G.pj.push({ id: G.nid++, k: 'fireb', x: px + (k - 3.5) * 4 + (Math.random() - 0.5) * 2, y: py - 26 - Math.random() * 6, vx: 0, vy: 14, dmg: B.dmg * 0.6 * G.dmul, life: 4, g: 4 }); o.t = 1.6 / fast; }
          else if (m === 3) { const a = Math.atan2(dy, dx); o.vx = Math.cos(a) * 30; o.vy = Math.sin(a) * 30; o.cg = 0.8; o.t = 1.3; pushFx(G, ['snd', 'roar']); }
          else { if (o.ph === 2) for (let k = 0; k < 6; k++) G.pj.push({ id: G.nid++, k: 'lavab', x: o.x, y: o.y, vx: (Math.random() - 0.5) * 18, vy: -12 - Math.random() * 8, dmg: B.dmg * 0.7 * G.dmul, life: 5, g: 30 }); o.t = 1; }
          pushFx(G, ['snd', 'pj']);
        }
        if (o.cg > 0) { o.vx *= 1 - dt * 1.2; o.vy *= 1 - dt * 1.2; }
        break;
      }
      case 5: { // 별의 집행자
        o.st = o.st || 0;
        if (o.t <= 0) {
          o.st++; const m = o.st % 5;
          if (m === 1) { // 순간이동
            const nx = px + (Math.random() < 0.5 ? -1 : 1) * (10 + Math.random() * 8), ny = py - 6 - Math.random() * 6; pushFx(G, ['tp', o.x, o.y, nx, ny]); o.x = nx; o.y = ny; o.vx = o.vy = 0; o.t = 0.6 / fast;
          } else if (m === 2) { // 광선(예고)
            for (let k = 0; k < (o.ph === 2 ? 3 : 2); k++) { const a = Math.atan2(dy, dx) + (k - (o.ph === 2 ? 1 : 0.5)) * 0.35; G.pj.push({ id: G.nid++, k: 'laser', x: o.x, y: o.y, vx: Math.cos(a), vy: Math.sin(a), dmg: B.dmg * 0.9 * G.dmul, life: 1.6, warn: 0.9, g: 0 }); }
            o.t = 1.9 / fast;
          } else if (m === 3) { for (let k = 0; k < 24; k++) { const a = k / 24 * TAU + o.life; G.pj.push({ id: G.nid++, k: 'starb', x: o.x, y: o.y, vx: Math.cos(a) * 9, vy: Math.sin(a) * 9, dmg: B.dmg * 0.5 * G.dmul, life: 5, g: 0, spin: 0.6 }); } o.t = 1.5 / fast; }
          else if (m === 4) { if (G.en.filter((e) => e.t === EX.sentry).length < 3) spawnEnemy(G, EX.sentry, o.x + (Math.random() - 0.5) * 8, o.y - 2); o.t = 0.8; }
          else { const a = Math.atan2(dy, dx); o.vx = Math.cos(a) * 26; o.vy = Math.sin(a) * 26; o.t = 1.1; }
          pushFx(G, ['snd', 'pj']);
        }
        o.vx *= 1 - dt * 1.6; o.vy *= 1 - dt * 1.6;
        o.x += o.vx * dt; o.y += o.vy * dt; o.y = Math.max(4, o.y);
        break;
      }
    }
    o.x = clamp(o.x, 3, W.w - 3); o.y = clamp(o.y, 3, W.h - 3);
  }
  function bossParts(o) { // 맞는 곳/닿는 곳 목록 [x, y(가운데), 반지름]
    const B = BOSS[o.b];
    if (o.b === 0) return [[o.x, o.y - o.h / 2, B.w * 0.48]];
    if (o.b === 2) return [[o.x, o.y, 1.4]].concat(o.seg.map((s) => [s[0], s[1], 1.15]));
    if (o.b === 3) return [[o.x, o.y, 2.2], [o.hands[0].x, o.hands[0].y, 1.4], [o.hands[1].x, o.hands[1].y, 1.4]];
    return [[o.x, o.y, B.w * 0.45]];
  }
  function hurtBoss(G, dmg, crit, fire) {
    const o = G.boss; if (!o || o.hp <= 0) return;
    const B = BOSS[o.b], d = Math.max(1, Math.round(dmg - B.def * 0.5));
    o.hp -= d; o.hurt = 0.12;
    pushFx(G, ['dn', r1(o.x), r1(o.y - (o.b === 0 ? o.h : 2)), d, crit ? 1 : 0]);
    if (o.b === 0 && Math.random() < 0.12 && G.en.length < 40) spawnEnemy(G, EX.mslime, o.x, o.y - 2, { vy: -10, vx: (Math.random() - 0.5) * 14 });
    if (o.hp <= 0) bossDie(G);
  }
  function bossDie(G) {
    const o = G.boss, B = BOSS[o.b]; G.boss = null;
    say(G, B.n + '을(를) 쓰러뜨렸어요!', '#ffd257'); pushFx(G, ['snd', 'win']); pushFx(G, ['boom', o.x, o.y, o.b]); pushFx(G, ['shake', 18]);
    const first = !G.fl.b[o.b]; G.fl.b[o.b] = 1; G.stat.bosses++;
    for (const p of G.alive) { // 자리마다 따로 전리품
      for (const [k, a, b, c] of B.dr) if (Math.random() < c) giveItem(G, p.s, IX[k], a + (Math.random() * (b - a + 1) | 0), o.x, o.y);
      giveItem(G, p.s, IX.coin, B.coin, o.x, o.y);
      giveItem(G, p.s, IX.p_bheal, 3, o.x, o.y);
      if (G.P[p.s]) G.P[p.s].bossK = (G.P[p.s].bossK | 0) + 1;
    }
    if (o.b === 4 && first) { G.meteorT = 4; }
    if (o.b === 5) { G.won = 1; say(G, '세계에 평화가 찾아왔어요! (계속 개척할 수 있어요)', '#c8b8ff'); }
  }
  function dropMeteor(G) {
    const W = G.W; const x = 40 + (Math.random() * (W.w - 80) | 0); let y = W.top[x];
    for (let dy = -4; dy <= 5; dy++) for (let dx = -6; dx <= 6; dx++) { const xx = x + dx, yy = y + dy; if (xx < 2 || xx >= W.w - 2 || yy < 2) continue; const d = dx * dx + dy * dy * 1.6; if (d < 18) setT(G, yy * W.w + xx, d < 12 ? T_.ore_st : T_.obsid); else if (d < 30 && dy < 0) setT(G, yy * W.w + xx, 0); }
    say(G, '하늘에서 성운석이 떨어졌어요! (지도에서 별 표시)', '#c8b8ff'); pushFx(G, ['shake', 12]); G.fl.meteor = (G.fl.meteor | 0) + 1; G.meteorAt = [x, y];
  }

  /* ----- 호스트 한 걸음 ----- */
  function worldTick(G, dt) {
    const W = G.W;
    G.el += dt;
    const was = isDay(G);
    G.tm += dt / DAY; if (G.tm >= 1) { G.tm -= 1; G.day++; }
    const now = isDay(G);
    if (was && !now) { // 해 질 녘
      if (G.day >= 2 && !G.ev && Math.random() < 0.13) { G.ev = { k: 'blood' }; say(G, '붉은 달이 떠올랐어요… 오늘 밤은 위험해요!', '#ff5a5a'); pushFx(G, ['snd', 'warn']); }
      if (!G.fl.b[1] && G.fl.hp >= 160 && !G.boss && Math.random() < 0.33) { G.warnBoss = 1; say(G, '불길한 시선이 느껴져요…', '#c8a0ff'); }
    }
    if (!was && now) { // 해 뜰 녘
      if (G.ev && G.ev.k === 'blood') { G.ev = null; say(G, '붉은 달이 졌어요', '#ab9fb8'); }
      if (G.fl.b[1] && !G.ev && G.day >= 3 && Math.random() < 0.15) { G.ev = { k: 'raid', left: 40 + 15 * G.alive.length }; say(G, '약탈단이 쳐들어와요! (땅 위)', '#ff8a5a'); pushFx(G, ['snd', 'warn']); }
      if (!G.fl.b[0] && G.day >= 3 && Math.random() < 0.25) G.warnBoss = 0;
    }
    if (G.warnBoss >= 0 && !G.boss) {
      const b = G.warnBoss;
      if (b === 1 && !now && G.tm > NIGHT0 + 0.03 && G.alive.length) { const p = G.alive[Math.random() * G.alive.length | 0]; if (zoneOf(W, p.x, p.y) === 'surface') bossSpawn(G, 1, p); G.warnBoss = -1; }
      if (b === 0 && now && G.tm > 0.25 && G.alive.length) { const p = G.alive.find((q) => zoneOf(W, q.x, q.y) === 'surface'); if (p) bossSpawn(G, 0, p); G.warnBoss = -1; }
    }
    if (G.meteorT > 0) { G.meteorT -= dt; if (G.meteorT <= 0) { dropMeteor(G); dropMeteor(G); } }
    // 액체
    G.lqT = (G.lqT || 0) - dt; if (G.lqT <= 0) { G.lqT = 0.08; liqStep(W, 900, (i, solid) => { logEdit(G, i); if (solid) colTop(W, i % W.w); }); }
    // 자라기: 풀 퍼짐·묘목·약초
    G.grow -= dt;
    if (G.grow <= 0 && G.alive.length) {
      G.grow = 0.25;
      for (const p of G.alive) for (let k = 0; k < 6; k++) {
        const x = clamp(Math.floor(p.x + (Math.random() - 0.5) * 120), 2, W.w - 3), y = clamp(Math.floor(p.y + (Math.random() - 0.5) * 70), 2, W.h - 3), i = y * W.w + x, tt = W.t[i];
        if (tt === T_.sapling && Math.random() < 0.08) { const b = W.bio[x]; W.t[i] = 0; if (!growTreeEdit(G, x, y, b === 2 ? 2 : b === 3 ? 3 : 0, Math.random)) W.t[i] = T_.sapling; }
        else if (tt === T_.dirt && !W.t[i - W.w] && (W.t[i - 1] === T_.grass || W.t[i + 1] === T_.grass || W.t[i - W.w - 1] === T_.grass || W.t[i - W.w + 1] === T_.grass || W.t[i + W.w - 1] === T_.grass)) setT(G, i, T_.grass);
        else if ((tt === T_.grass || tt === T_.jgrass || tt === T_.snow || tt === T_.sand || tt === T_.ash) && !W.t[i - W.w] && !W.lq[i - W.w] && Math.random() < 0.02) {
          const herb = tt === T_.grass ? T_.h_sun : tt === T_.jgrass ? T_.h_moon : tt === T_.snow ? T_.h_frost : tt === T_.sand ? (W.bio[x] === 1 ? T_.h_dune : 0) : y >= W.hellTop ? T_.h_fire : 0;
          if (herb) setT(G, i - W.w, herb);
        }
      }
    }
    // 정착민
    G.houseT -= dt; if (G.houseT <= 0) { G.houseT = 6; houseTick(G); }
    for (const n of G.npcs) npcTick(G, n, dt);
    // 적 생기기
    G.spawnT -= dt;
    if (G.spawnT <= 0) { G.spawnT = 0.7; for (const p of G.alive) if (Math.random() < 0.55) trySpawn(G, p); }
    // 별가루
    if (!now) { G.starT -= dt; if (G.starT <= 0) { G.starT = 14 + Math.random() * 14; for (const p of G.alive) if (zoneOf(W, p.x, p.y) === 'surface' || zoneOf(W, p.x, p.y) === 'sky') dropItem(G, IX.stard, 1, p.x + (Math.random() - 0.5) * 50, 4, (Math.random() - 0.5) * 4, 18); } }
    // 약탈단 습격: 땅 위 사람 주변으로 계속 보내기
    for (const e of G.en) if (!e.dead) enemyTick(G, e, dt);
    G.en = G.en.filter((e) => !e.dead);
    if (G.boss) bossTick(G, G.boss, dt);
    // 적 투사체
    for (const j of G.pj) {
      j.life -= dt;
      if (j.k === 'laser') { if (j.warn > 0) j.warn -= dt; continue; }
      if (j.home) { const p = nearestP(G, j.x, j.y, 30); if (p) { const a = Math.atan2(p.y - p.h / 2 - j.y, p.x - j.x), sp = Math.hypot(j.vx, j.vy); j.vx += (Math.cos(a) * sp - j.vx) * dt * 1.2; j.vy += (Math.sin(a) * sp - j.vy) * dt * 1.2; } }
      if (j.spin) { const a = Math.atan2(j.vy, j.vx) + j.spin * dt, sp = Math.hypot(j.vx, j.vy); j.vx = Math.cos(a) * sp; j.vy = Math.sin(a) * sp; }
      j.vy += (j.g || 0) * dt; j.x += j.vx * dt; j.y += j.vy * dt;
      if (j.k !== 'starb' && j.k !== 'bolt' && j.k !== 'shadow' && j.k !== 'fireb' && solidAt(W, Math.floor(j.x), Math.floor(j.y))) { j.life = 0; if (j.k === 'lavab') { const i = Math.floor(j.y - 1) * W.w + Math.floor(j.x); if (i > 0 && !SOLIDT[W.t[i]] && !W.lq[i]) { W.lq[i] = 16 | 4; logEdit(G, i); W.lqAct.add(i); } } }
    }
    G.pj = G.pj.filter((j) => j.life > 0);
    // 떨어진 물건
    for (const d of G.dr) {
      d.t += dt;
      const p = nearestP(G, d.x, d.y, 5.5);
      if (p && d.t > 0.4) { const ax = p.x - d.x, ay = p.y - p.h / 2 - d.y, L3 = Math.hypot(ax, ay) || 1; d.vx += ax / L3 * 90 * dt; d.vy += ay / L3 * 90 * dt; d.vx *= 0.92; d.vy *= 0.92; d.x += d.vx * dt; d.y += d.vy * dt; if (L3 < 1.3) { d.take = p.s; } }
      else { d.vy = Math.min(d.vy + 40 * dt, 20); d.vx *= 0.96; moveBody(W, d, dt, {}); if (d.gnd) d.vx *= 0.8; }
      if (d.take !== undefined && d.take >= 0) { const s = d.take; d.take = -1; const P2 = G.P[s]; if (P2 && P2.local && !canFit(P2.inv, d.it, d.n)) continue; giveItem(G, s, d.it, d.n, d.x, d.y); d.gone = 1; pushFx(G, ['snd', 'pick']); }
      if (d.t > 600) d.gone = 1;
    }
    G.dr = G.dr.filter((d) => !d.gone);
  }
  function growTreeEdit(G, x, y, b, R) {
    const W = G.W;
    const hh = (b === 3 ? 9 : 5) + (R() * (b === 3 ? 8 : 7) | 0);
    for (let k = 0; k < hh + 3; k++) { const i = (y - k) * W.w + x; if (y - k < 3 || W.t[i] !== 0) return false; }
    const save = W.t;
    const tmp = Object.create(null); // 임시로 그려 보고 바뀐 칸만 기록
    const get = (i) => (tmp[i] !== undefined ? tmp[i] : save[i]);
    for (let k = 0; k < hh; k++) tmp[(y - k) * W.w + x] = T_.log;
    const top = y - hh + 1, lt = b === 2 ? T_.pine : b === 3 ? T_.jleaf : T_.leaf;
    if (b === 2) { for (let k = 0; k < 7; k++) { const half = Math.floor(k / 2.2); for (let dx = -half; dx <= half; dx++) { const yy = top - 3 + k, xx = x + dx, i = yy * W.w + xx; if (yy > 1 && xx > 0 && xx < W.w && get(i) === 0) tmp[i] = lt; } } }
    else { const r = b === 3 ? 3.2 : 2.6; for (let dy = -4; dy <= 2; dy++) for (let dx = -4; dx <= 4; dx++) { if (dx * dx + dy * dy * 1.3 > r * r) continue; const yy = top + dy - 1, xx = x + dx, i = yy * W.w + xx; if (yy > 1 && xx > 0 && xx < W.w && get(i) === 0) tmp[i] = lt; } }
    logEdit(G, y * W.w + x);
    for (const k in tmp) setT(G, +k, tmp[k]);
    return true;
  }

  /* ======================= 플레이어 조작 (각 기기) ======================= */
  // C(문맥): { W, host(bool), G(호스트면), act(a), en(), boss(), hpj(), fx(type, ...), dmul, pjs(내 투사체), mn(내 소환수), mine(Map), toast(t), stations(p) }
  const REACH = 5.6;
  function inReach(p, tx, ty, extra) { return Math.hypot(tx + 0.5 - p.x, ty + 0.5 - (p.y - p.h / 2)) <= REACH + (extra || 0); }
  function stationsNear(W, p) {
    const s = {}; const x0 = Math.floor(p.x) - 5, y0 = Math.floor(p.y) - 6;
    for (let y = y0; y <= y0 + 9; y++) for (let x = x0; x <= x0 + 10; x++) { const T = TL[tAt(W, x, y)]; if (T.st) s[T.st] = 1; }
    if (s.hf) { s.fu = 1; s.an = 1; } if (s.al) s.wb = s.wb || 0; return s;
  }
  function hurtPlayer(C, p, dmg, dirX, kb, why) {
    if (p.dead || p.iv > 0 || p.god) return 0;
    const S = p.st || calcStats(p);
    const d = Math.max(1, Math.round(dmg * C.dmul - S.def * 0.5));
    p.hp -= d; p.iv = 0.7; p.stats.dmg += d;
    if (!S.kbImm && kb) { p.vx = dirX * kb * 2; p.vy = Math.min(p.vy, -kb * 1.6); }
    C.fx('ph', p, d);
    if (p.hp <= 0) killPlayer(C, p, why);
    return d;
  }
  function killPlayer(C, p, why) {
    p.hp = 0; p.dead = C.dif === 2 ? 8 : 5; p.stats.die++; p.sw = null; p.vx = p.vy = 0;
    if (C.dif >= 1) { const c = countItem(p.inv, IX.coin), lose = Math.floor(c / 2); if (lose > 0) { takeItem(p.inv, IX.coin, lose); C.act(['dr', IX.coin, lose, r1(p.x), r1(p.y - 1), 0]); } }
    C.fx('die', p, why || '');
  }
  function respawn(C, p) { const sp = p.sp || C.W.spawn; p.x = sp.x; p.y = sp.y - 0.01; p.vx = p.vy = 0; p.hp = Math.max(1, Math.round(p.hpM * (C.dif === 2 ? 0.5 : 1))); p.mp = p.mpM; p.dead = 0; p.iv = 2; p.fall = 0; }
  function useConsumable(C, p, it, slot) {
    const ef = it.ef || {};
    const S = p.st || calcStats(p);
    if (it.c === 'potion') {
      if (ef.heal) { if (p.bf.sick) { C.toast('아직 치유 물약을 마실 수 없어요 (' + Math.ceil(p.bf.sick) + '초)'); return false; } if (p.hp >= p.hpM) return false; p.hp = Math.min(p.hpM, p.hp + ef.heal); p.bf.sick = 40; }
      if (ef.manaHeal) { if (p.mp >= p.mpM + (S.mana | 0)) return false; p.mp = Math.min(p.mpM + (S.mana | 0), p.mp + ef.manaHeal); }
      if (ef.buff) p.bf[ef.buff] = ef.t;
      if (ef.home) { const sp = p.sp || C.W.spawn; C.fx('tp', p); p.x = sp.x; p.y = sp.y - 0.01; p.vx = p.vy = 0; }
      C.fx('drink', p, it.i);
    } else if (it.use === 'life') { if (p.hpM >= 400) { C.toast('최대 체력이 이미 400이에요'); return false; } p.hpM += 20; p.hp += 20; C.act(['fl', 'hp', p.hpM]); C.fx('drink', p, it.i); }
    else if (it.use === 'mana') { if (p.mpM >= 200) { C.toast('최대 마나가 이미 200이에요'); return false; } p.mpM += 20; p.mp += 20; C.act(['fl', 'mp', p.mpM]); C.fx('drink', p, it.i); }
    else if (it.use === 'home') { const sp = p.sp || C.W.spawn; C.fx('tp', p); p.x = sp.x; p.y = sp.y - 0.01; p.vx = p.vy = 0; return 'keep'; }
    else if (it.c === 'boss') {
      const z = zoneOf(C.W, p.x, p.y), day = C.isDay();
      const ok = [day && (z === 'surface' || z === 'sky'), !day, z === 'under' || z === 'cavern', !day, z === 'hell', z === 'surface' || z === 'sky'][it.boss];
      if (!ok) { C.toast(it.d); return false; }
      if (C.bossOn()) { C.toast('이미 보스와 싸우는 중이에요'); return false; }
      C.act(['bs', it.boss]);
    }
    const s = p.inv[slot]; if (s) { s[1]--; if (!s[1]) p.inv[slot] = null; }
    return true;
  }
  function findAmmo(p) { let best = -1, bd = -1; for (let k = 0; k < INV; k++) { const s = p.inv[k]; if (s && IT[s[0]].isAmmo) { if (k >= 40) return k; if (best < 0) best = k; } } void bd; return best; }
  function playerTick(C, p, I, dt) {
    const W = C.W;
    if (p.dead) { p.dead -= dt; if (p.dead <= 0) respawn(C, p); return; }
    p.stT -= dt; if (p.stT <= 0 || !p.st) { p.st = calcStats(p); p.stT = 0.5; }
    const S = p.st;
    for (const k in p.bf) { p.bf[k] -= dt; if (p.bf[k] <= 0) delete p.bf[k]; }
    p.iv = Math.max(0, p.iv - dt); p.cd = Math.max(0, p.cd - dt);
    // 재생
    p.regenT += dt; if (p.regenT >= 0.5) { p.regenT = 0; const still = Math.abs(p.vx) < 0.5 ? 1.6 : 1; p.hp = Math.min(p.hpM, p.hp + (0.4 * still + (S.regen || 0) * 0.5)); p.mp = Math.min(p.mpM + (S.mana | 0), p.mp + 1 + (S.manaR || 0) * 0.5); if (p.bf.fire) { p.hp -= 3; if (p.hp <= 0) killPlayer(C, p, '불에 탔어요'); } }
    // 액체
    const lq = liqIn(W, p);
    const inW = lq.w > 0, inL = lq.l > 0;
    const head = W.lq[clamp(Math.floor(p.y - p.h + 0.3), 0, W.h - 1) * W.w + clamp(Math.floor(p.x), 0, W.w - 1)];
    if (head && !(head & 16) && !S.breath) { p.br -= dt; if (p.br <= 0) { p.br = 0; p.drT = (p.drT || 0) - dt; if (p.drT <= 0) { p.drT = 0.5; p.hp -= 8; C.fx('ph', p, 8); if (p.hp <= 0) killPlayer(C, p, '물에 빠졌어요'); } } } else p.br = Math.min(10, p.br + dt * 3);
    if (inL && !S.lavaImm) { p.lvT = (p.lvT || 0) - dt; if (p.lvT <= 0) { p.lvT = 0.5; p.bf.fire = 6; hurtPlayer(C, p, 40, 0, 0, '용암에 빠졌어요'); p.iv = 0; } }
    // 이동
    const spd = 10 * (1 + (S.spd || 0)) * (p.bf.slow ? 0.6 : 1);
    const ice = p.gnd && TL[tAt(W, Math.floor(p.x), Math.floor(p.y + 0.05))].slip;
    const acc = p.gnd ? (ice ? 14 : 80) : 45;
    const want = (I.mx || 0) * spd;
    if (want) { p.vx += clamp(want - p.vx, -acc * dt, acc * dt); p.dir = Math.sign(want); }
    else { const fr = p.gnd ? (ice ? 6 : 70) : 12; p.vx -= clamp(p.vx, -fr * dt, fr * dt); }
    if (inW || inL) p.vx *= 1 - dt * 3;
    // 점프 (코요테·버퍼)
    p.coy = p.gnd ? 0.1 : Math.max(0, p.coy - dt);
    if (I.jumpP) p.jb = 0.13; else p.jb = Math.max(0, p.jb - dt);
    if (p.gnd) p.dj = S.dj | 0;
    const jumpV = 23 * (1 + (S.jump || 0) * 0.5);
    let wallC = 0;
    if (S.wall && !p.gnd && p.hitW && Math.sign(I.mx || 0) === p.hitW) wallC = p.hitW;
    if (p.jb > 0) {
      if (p.coy > 0) { p.vy = -jumpV; p.jh = 0.26; p.coy = 0; p.jb = 0; C.fx('jump', p); }
      else if (inW || inL) { p.vy = -12; p.jb = 0; }
      else if (wallC) { p.vy = -jumpV * 0.9; p.vx = -wallC * 11; p.jh = 0.2; p.jb = 0; C.fx('jump', p); }
      else if (p.dj > 0 && I.jumpP) { p.dj--; p.vy = -jumpV * 0.92; p.jh = 0.2; p.jb = 0; C.fx('dj', p); }
    }
    if (!I.jump) p.jh = 0; else p.jh = Math.max(0, p.jh - dt);
    let g = 68; if (p.jh > 0 && p.vy < 0) g = 22; else if (p.vy < 0 && !I.jump) g = 110;
    if (inW || inL) g = 22;
    p.vy += g * dt;
    let maxF = inW || inL ? 7 : 42;
    if ((S.glide || p.bf.feather) && I.jump && p.vy > 0) maxF = 5;
    if (wallC && p.vy > 0) maxF = 4;
    if (W.t[clamp(Math.floor(p.y - 1), 0, W.h - 1) * W.w + clamp(Math.floor(p.x), 0, W.w - 1)] === T_.web) { p.vx *= 0.6; maxF = 2; }
    p.vy = Math.min(p.vy, maxF);
    if (p.vy > 0 && !p.gnd) p.fall = Math.max(p.fall, p.vy);
    moveBody(W, p, dt, { step: 1, drop: I.down });
    if (p.gnd && p.fall > 0) { const imp = p.fall; p.fall = 0; if (imp > 36 && !S.nofall && !p.bf.feather && !inW) { const d = Math.round((imp - 36) * 6); hurtPlayer(C, p, d / C.dmul, 0, 0, '높은 곳에서 떨어졌어요'); p.iv = 0.2; } if (imp > 18) C.fx('land', p, imp); }
    if (inW || inL || wallC) p.fall = 0;
    p.x = clamp(p.x, 2, W.w - 2); if (p.y > W.h - 2) { p.y = W.h - 2; }
    p.anim += Math.abs(p.vx) * dt;
    // 아이템 쓰기
    if (I.sel !== undefined && I.sel !== null && I.sel !== p.sel && !p.sw) p.sel = I.sel;
    const ax = I.ax, ay = I.ay;
    if (fin(ax)) p.aim = Math.atan2(ay - (p.y - p.h * 0.62), ax - p.x);
    if (p.sw) { p.sw.t += dt; meleeHits(C, p); if (p.sw.t >= p.sw.d) p.sw = null; }
    if (I.use && p.cd <= 0 && !I.ui) useHeld(C, p, ax, ay, I);
    // 적 몸통·적 투사체·보스 닿기
    const px = p.x, py = p.y - p.h / 2;
    for (const e of C.en()) { if (e.dead) continue; if (Math.abs(e.x - px) < (e.w + p.w) / 2 && Math.abs(e.y - e.h / 2 - py) < (e.h + p.h) / 2) { const E = EN[e.t]; const d = hurtPlayer(C, p, E.dmg, Math.sign(px - e.x) || 1, 5, E.n + '에게 당했어요'); if (d && S.thorn) C.act(['h', e.id, Math.round(E.dmg * 0.5), 0, 0, 0, 0]); } }
    const B = C.boss();
    if (B && B.hp > 0) for (const [bx, by, br] of bossParts(B)) { if (Math.hypot(bx - px, by - py) < br + 0.9) { hurtPlayer(C, p, BOSS[B.b].dmg, Math.sign(px - bx) || 1, 7, BOSS[B.b].n + '에게 당했어요'); break; } }
    for (const j of C.hpj()) {
      if (j.k === 'laser') { if (j.warn > 0) continue; const vx = px - j.x, vy = py - j.y, t2 = vx * j.vx + vy * j.vy; if (t2 > 0 && t2 < 70 && Math.abs(vx * j.vy - vy * j.vx) < 0.9) hurtPlayer(C, p, j.dmg, Math.sign(j.vx) || 1, 4, '별빛 광선에 맞았어요'); continue; }
      if (Math.abs(j.x - px) < p.w / 2 + 0.35 && Math.abs(j.y - py) < p.h / 2 + 0.35) { if (hurtPlayer(C, p, j.dmg, Math.sign(j.vx) || 1, 3, '날아온 공격에 맞았어요')) { j.life = 0; if (j.k === 'fireb' || j.k === 'lavab') p.bf.fire = 3; if (j.k === 'icebolt') p.bf.slow = 2; if (C.host) j.life = 0; } }
    }
    // 내 투사체
    for (const q of C.pjs) pjTick(C, p, q, dt);
    for (let k = C.pjs.length - 1; k >= 0; k--) if (C.pjs[k].life <= 0) C.pjs.splice(k, 1);
    // 소환수
    const mxN = S.minion | 0; while (C.mn.length > mxN) C.mn.shift();
    for (const m of C.mn) minionTick(C, p, m, dt);
  }
  function critRoll(p) { return Math.random() < ((p.st && p.st.crit) || 0.04); }
  function dmgOf(p, it, base) { const S = p.st || calcStats(p); const cr = critRoll(p); let d = (base || it.dmg || 1) * (1 + (S.dmg || 0)) * (0.9 + Math.random() * 0.2); if (cr) d *= 2; return [Math.round(d), cr]; }
  function hitEnemy(C, p, e, it, base, dirX, kb, fire) {
    const [d, cr] = dmgOf(p, it, base);
    const S = p.st || {};
    const f = fire || (it && it.fire) || (S.fire && it && it.c === 'melee') ? 1 : 0;
    if (e === 'boss') { C.act(['h', -1, d, dirX, kb, cr ? 1 : 0, f]); C.fx('hitB', p); }
    else { C.act(['h', e.id, d, dirX, kb, cr ? 1 : 0, f]); C.fx('hit', e, d, cr); }
    p.stats.hits = (p.stats.hits | 0) + 1;
  }
  function meleeHits(C, p) {
    const sw = p.sw; const it = IT[sw.it]; if (!it) return;
    const prog = sw.t / sw.d;
    const sx = p.x, sy = p.y - p.h * 0.62;
    const rch = (it.rch || 1.8) + (it.c === 'pick' || it.c === 'axe' || it.c === 'hammer' ? 0 : 0);
    let ang, len = rch;
    if (it.thrust) { ang = sw.a0; len = rch * (0.4 + 0.6 * Math.sin(Math.min(1, prog) * Math.PI)); }
    else ang = sw.a0 + (prog - 0.5) * 2.6 * sw.dir;
    sw.ang = ang; sw.len = len;
    const tx = sx + Math.cos(ang) * len, ty = sy + Math.sin(ang) * len;
    const test = (cx, cy, r) => { // 선분-원
      const vx = tx - sx, vy = ty - sy, wx = cx - sx, wy = cy - sy; const t2 = clamp((wx * vx + wy * vy) / (vx * vx + vy * vy), 0, 1); return Math.hypot(sx + vx * t2 - cx, sy + vy * t2 - cy) < r; };
    for (const e of C.en()) { if (e.dead || sw.hit[e.id]) continue; if (test(e.x, e.y - e.h / 2, Math.max(e.w, e.h) / 2 + 0.3)) { sw.hit[e.id] = 1; hitEnemy(C, p, e, it, it.dmg, sw.dir, it.kb || 3); } }
    const B = C.boss();
    if (B && B.hp > 0 && !sw.hit.B) for (const [bx, by, br] of bossParts(B)) if (test(bx, by, br + 0.2)) { sw.hit.B = 1; hitEnemy(C, p, 'boss', it, it.dmg, sw.dir, 0); break; }
  }
  function startSwing(p, it, ax, ay) {
    const a0 = Math.atan2(ay - (p.y - p.h * 0.62), ax - p.x);
    p.dir = Math.cos(a0) >= 0 ? 1 : -1;
    p.sw = { it: it.i, t: 0, d: Math.max(0.12, it.ut || 0.25), a0, dir: p.dir, hit: {}, ang: a0, len: it.rch || 1.8 };
  }
  function useHeld(C, p, ax, ay, I) {
    const W = C.W, slot = p.sel, s = p.inv[slot]; if (!s) return;
    const it = IT[s[0]]; const S = p.st || calcStats(p);
    const tx = Math.floor(ax), ty = Math.floor(ay);
    const c = it.c;
    if (c === 'pick' || c === 'axe' || c === 'hammer' || (c === 'melee' && it.ax)) {
      p.cd = (it.ut || 0.25) / (1 + (S.mine || 0) * 0.6);
      startSwing(p, it, ax, ay); C.fx('swing', p, it.i);
      if (!inReach(p, tx, ty)) return;
      if (c === 'hammer') { const i = ty * W.w + tx; if (tx > 0 && ty > 0 && tx < W.w && ty < W.h && W.wl[i] && !W.t[i]) { const k = 'w' + i, m = C.mine.get(k) || { d: 0 }; m.d += it.hm; m.t = 3; C.mine.set(k, m); C.fx('chip', tx, ty, 1); if (m.d >= 40) { C.mine.delete(k); C.act(['bw', tx, ty]); C.fx('broke', tx, ty, 1); } } return; }
      const tt = tAt(W, tx, ty); if (!tt) return;
      const T = TL[tt];
      const tree = (T.f & 32) !== 0;
      if (c === 'axe' || it.ax) { if (!tree) { if (c === 'axe') { C.toastOnce('도끼는 나무를 베요 — 흙·돌은 곡괭이로'); } return; } }
      else if (tree) { C.toastOnce('나무는 도끼로 베요'); return; }
      const pw = c === 'pick' ? it.pk : it.ax;
      if (T.pk > pw) { C.toastOnce(T.n + '은(는) 곡괭이 힘 ' + T.pk + ' 이상이 필요해요 (지금 ' + pw + ')'); C.fx('clank', tx, ty); return; }
      if (tt === T_.chest) { /* 빈 상자만 부숴짐(호스트 확인) */ }
      const i = ty * W.w + tx, k = 't' + i, m = C.mine.get(k) || { d: 0 };
      m.d += pw * (1 + (S.mine || 0)); m.t = 3; C.mine.set(k, m);
      C.fx('chip', tx, ty, 0, tt);
      if (m.d >= T.hp) { C.mine.delete(k); C.act(['b', tx, ty]); C.fx('broke', tx, ty, 0, tt); p.stats.mine++; }
      return;
    }
    if (c === 'melee') { p.cd = it.ut; startSwing(p, it, ax, ay); C.fx('swing', p, it.i); if (it.beam) shoot(C, p, 'beam', ax, ay, 24, it, Math.round(it.dmg * 0.7), { pierce: 3, life: 0.8 }); return; }
    if (c === 'ranged') {
      let dmgB = it.dmg, pk = it.pj || 'arrow', o = {};
      if (it.ammo) { const k = findAmmo(p); if (k < 0) { C.toastOnce('화살이 없어요'); p.cd = 0.4; return; } const A = IT[p.inv[k][0]]; dmgB += A.dmg; o.fire = A.fire; o.pierce = A.pierce || 0; o.col = A.col; p.inv[k][1]--; if (!p.inv[k][1]) p.inv[k] = null; }
      if (pk === 'boom' && C.pjs.some((q) => q.k === 'boom')) return;
      p.cd = it.ut; p.dir = ax >= p.x ? 1 : -1;
      for (let m = 0; m < (it.multi || 1); m++) shoot(C, p, pk, ax, ay + (m ? (Math.random() - 0.5) * 2 : 0), it.spd || 20, it, dmgB, o);
      C.fx('shoot', p, pk); return;
    }
    if (c === 'magic') {
      const mx = p.mpM + (S.mana | 0); void mx;
      if (p.mp < it.mana) { C.toastOnce('마나가 모자라요'); p.cd = 0.3; return; }
      p.mp -= it.mana; p.cd = it.ut; p.dir = ax >= p.x ? 1 : -1;
      if (it.pj === 'star') { for (let m = 0; m < 2; m++) { const sx = ax + (Math.random() - 0.5) * 6, sy = p.y - 22; const a = Math.atan2(ay - sy, ax - sx); C.pjs.push({ k: 'star', x: sx, y: sy, vx: Math.cos(a) * it.spd * 1.3, vy: Math.sin(a) * it.spd * 1.3, dmg: it.dmg, it: it.i, life: 2.5, pierce: it.pierce || 0, hit: {}, g: 0, nt: 1 }); C.act(['sh', 'star', r1(sx), r1(sy), r1(Math.cos(a) * it.spd * 1.3), r1(Math.sin(a) * it.spd * 1.3)]); } }
      else shoot(C, p, it.pj, ax, ay, it.spd, it, it.dmg, { pierce: it.pierce || 0, bounce: it.bounce || 0, fire: it.fire ? 1 : it.pj === 'ice' ? 2 : 0 });
      C.fx('magic', p, it.pj); return;
    }
    if (c === 'summon') {
      if (p.mp < it.mana) { C.toastOnce('마나가 모자라요'); p.cd = 0.3; return; }
      p.mp -= it.mana; p.cd = 0.6;
      C.mn.push({ k: it.mn, x: p.x, y: p.y - 2, vx: 0, vy: 0, dmg: it.dmg, it: it.i, t: 0, cd: 0, tg: null });
      while (C.mn.length > (S.minion | 0)) C.mn.shift();
      C.fx('summon', p); return;
    }
    if (c === 'potion' || c === 'misc' || c === 'boss') { p.cd = 0.5; useConsumable(C, p, it, slot); return; }
    if (c === 'block' || c === 'furn' || c === 'light' || c === 'wall' || it.pl) {
      p.cd = 0.11;
      if (!inReach(p, tx, ty, 0.5)) return;
      if (c === 'wall') {
        const i = ty * W.w + tx; if (tx < 1 || ty < 1 || tx >= W.w - 1 || ty >= W.h - 1 || W.wl[i]) return;
        const nb = [i - 1, i + 1, i - W.w, i + W.w].some((j) => W.wl[j] || W.t[j]); if (!nb) return;
        W.wl[i] = it.pw; C.act(['pw', tx, ty, it.pw]); s[1]--; if (!s[1]) p.inv[slot] = null; C.fx('place', tx, ty); p.stats.place++; return;
      }
      const tt = TX[it.pl]; if (tt === undefined) return;
      const why = canPlace(C.gfake, tx, ty, tt, C.ents());
      if (why !== 'ok') { if (why) C.toastOnce(why); return; }
      if (TL[tt].door) { for (let k = 0; k < 3; k++) W.t[(ty - k) * W.w + tx] = tt; } else W.t[ty * W.w + tx] = tt;
      C.act(['p', tx, ty, tt, it.i]); s[1]--; if (!s[1]) p.inv[slot] = null; C.fx('place', tx, ty, tt); p.stats.place++;
    }
  }
  function shoot(C, p, k, ax, ay, spd, it, dmg, o) {
    const sx = p.x + p.dir * 0.4, sy = p.y - p.h * 0.62; const a = Math.atan2(ay - sy, ax - sx);
    const g = k === 'arrow' ? 18 : k === 'thorn' ? 6 : 0;
    const q = Object.assign({ k, x: sx, y: sy, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, dmg, it: it.i, life: k === 'boom' ? 3 : 2.2, pierce: 0, hit: {}, g, sx, sy }, o || {});
    C.pjs.push(q); if (C.pjs.length > 80) C.pjs.shift();
    C.act(['sh', k, r1(sx), r1(sy), r1(q.vx), r1(q.vy)]);
  }
  function pjTick(C, p, q, dt) {
    const W = C.W;
    q.life -= dt;
    if (q.k === 'boom') { const back = q.life < 2.2; if (back) { const a = Math.atan2(p.y - p.h / 2 - q.y, p.x - q.x); q.vx += (Math.cos(a) * 22 - q.vx) * dt * 6; q.vy += (Math.sin(a) * 22 - q.vy) * dt * 6; if (Math.hypot(p.x - q.x, p.y - p.h / 2 - q.y) < 1.2) q.life = 0; } }
    q.vy += (q.g || 0) * dt;
    const nx = q.x + q.vx * dt, ny = q.y + q.vy * dt;
    if (!q.nt && solidAt(W, Math.floor(nx), Math.floor(ny))) {
      if (q.bounce > 0) { q.bounce--; if (solidAt(W, Math.floor(nx), Math.floor(q.y))) q.vx = -q.vx; else q.vy = -q.vy; }
      else if (q.k === 'boom') { q.life = Math.min(q.life, 2.1); q.vx = -q.vx; }
      else { q.life = 0; C.fx('pjhit', q); return; }
    } else { q.x = nx; q.y = ny; }
    if (q.nt && q.y > p.y + 4 && solidAt(W, Math.floor(q.x), Math.floor(q.y))) { q.life = 0; C.fx('pjhit', q); return; }
    const it = IT[q.it];
    for (const e of C.en()) { if (e.dead || q.hit[e.id]) continue; if (Math.abs(e.x - q.x) < e.w / 2 + 0.3 && Math.abs(e.y - e.h / 2 - q.y) < e.h / 2 + 0.3) { q.hit[e.id] = 1; hitEnemy(C, p, e, it, q.dmg, Math.sign(q.vx) || 1, (it && it.kb) || 2, q.fire); if (q.pierce-- <= 0 && q.k !== 'boom') { q.life = 0; return; } } }
    const B = C.boss();
    if (B && B.hp > 0 && !q.hit.B) for (const [bx, by, br] of bossParts(B)) if (Math.hypot(bx - q.x, by - q.y) < br + 0.3) { q.hit.B = 1; hitEnemy(C, p, 'boss', it, q.dmg, 0, 0, q.fire); if (q.pierce-- <= 0 && q.k !== 'boom') q.life = 0; else setTimeoutHitReset(q); break; }
  }
  function setTimeoutHitReset(q) { q.bt = 0.25; }
  function minionTick(C, p, m, dt) {
    const W = C.W; m.t += dt; m.cd = Math.max(0, m.cd - dt);
    let tg = null, bd = 22;
    for (const e of C.en()) { if (e.dead) continue; const d = Math.hypot(e.x - p.x, e.y - p.y); if (d < bd) { bd = d; tg = e; } }
    const B = C.boss(); let tx, ty;
    if (B && B.hp > 0 && Math.hypot(B.x - p.x, B.y - p.y) < 40) { tx = B.x; ty = B.y - (B.b === 0 ? B.h / 2 : 0); tg = 'boss'; }
    else if (tg) { tx = tg.x; ty = tg.y - tg.h / 2; }
    else { const k = C.mn.indexOf(m); tx = p.x - p.dir * (1.5 + k * 1.2); ty = p.y - p.h - 1 + Math.sin(m.t * 2 + k) * 0.5; }
    const fly = m.k !== 'slime';
    if (fly) {
      const dx = tx - m.x, dy = ty - m.y, d = Math.hypot(dx, dy) || 1, sp = m.k === 'starg' ? 26 : m.k === 'bat' ? 18 : 12;
      if (m.k === 'imp' && tg) { const gx = tx - m.x + (m.x < tx ? -7 : 7), gy = ty - 5 - m.y; m.vx += (gx * 3 - m.vx) * dt * 3; m.vy += (gy * 3 - m.vy) * dt * 3; if (m.cd <= 0) { m.cd = 1; const a = Math.atan2(dy, dx); C.pjs.push({ k: 'fire', x: m.x, y: m.y, vx: Math.cos(a) * 20, vy: Math.sin(a) * 20, dmg: m.dmg, it: m.it, life: 1.5, pierce: 0, hit: {}, g: 0, fire: 1 }); } }
      else { m.vx += (dx / d * sp - m.vx) * dt * 4; m.vy += (dy / d * sp - m.vy) * dt * 4; }
      m.x += m.vx * dt; m.y += m.vy * dt;
    } else {
      const body = m.b || (m.b = { x: m.x, y: m.y, vx: 0, vy: 0, w: 0.9, h: 0.8 });
      body.vy = Math.min(body.vy + 50 * dt, 30);
      if (body.gnd) { body.vx *= 0.8; if (Math.random() < dt * 3) { body.vx = Math.sign(tx - body.x) * 9; body.vy = -14; } }
      moveBody(W, body, dt, {}); m.x = body.x; m.y = body.y - 0.4;
      if (Math.hypot(p.x - body.x, p.y - body.y) > 30) { body.x = p.x; body.y = p.y - 1; }
    }
    if (Math.hypot(p.x - m.x, p.y - m.y) > 50) { m.x = p.x; m.y = p.y - 2; }
    if (m.cd <= 0 && m.k !== 'imp') {
      if (tg === 'boss') { for (const [bx, by, br] of bossParts(B)) if (Math.hypot(bx - m.x, by - m.y) < br + 0.6) { m.cd = 0.45; hitEnemy(C, p, 'boss', IT[m.it], m.dmg, 0, 0); break; } }
      else if (tg && Math.abs(tg.x - m.x) < tg.w / 2 + 0.6 && Math.abs(tg.y - tg.h / 2 - m.y) < tg.h / 2 + 0.6) { m.cd = 0.45; hitEnemy(C, p, tg, IT[m.it], m.dmg, Math.sign(tg.x - m.x) || 1, 2); }
    }
  }

  /* ======================= AI 동료·시연 ======================= */
  const BOT_CRAFT = ['wbench', 'torch', 'wd_sword', 'furnace', 'b_cu', 'b_fe', 'anvil', 'cu_pick', 'fe_pick', 'b_ag', 'ag_pick', 'b_au', 'au_pick', 'cu_sword', 'fe_sword', 'ag_sword', 'au_sword', 'wd_bow', 'fe_bow', 'b_cr', 'cr_pick', 'cr_sword', 'cu_helm', 'cu_mail', 'cu_legs', 'fe_helm', 'fe_mail', 'fe_legs', 'ag_helm', 'ag_mail', 'ag_legs', 'au_helm', 'au_mail', 'au_legs', 'arrow', 'bottle', 'p_heal', 'chest'];
  function botCraft(p, C) {
    for (const k of BOT_CRAFT) {
      const id = IX[k]; const rs = RC.filter((r) => r.o === id); if (!rs.length) continue; const r = rs[0];
      if (IT[id].mx === 1 && countItem(p.inv, id) + p.arm.concat(p.acc).filter((a) => a && a[0] === id).length) continue;
      if ((k === 'torch' && countItem(p.inv, id) > 40) || (k === 'arrow' && countItem(p.inv, id) > 100) || (k === 'p_heal' && countItem(p.inv, id) > 5) || (k === 'bottle' && countItem(p.inv, id) > 4)) continue;
      if (['wbench', 'furnace', 'anvil', 'chest'].includes(k) && countItem(p.inv, id) >= 1) continue;
      if (k.startsWith('b_') && countItem(p.inv, id) >= 30) continue;
      if (canCraft(p.inv, r, { wb: 1, fu: 1, an: 1, al: 1, tk: 1, hf: 1, sw: 1 }) < 1) continue;
      if (!canFit(p.inv, id, r.n)) continue;
      for (const [iid, n] of r.in) takeItem(p.inv, iid, n);
      addItem(p.inv, id, r.n); p.stats.craft++;
      const it = IT[id];
      if (it.c === 'armor') { const old = p.arm[it.slot]; if (!old || (IT[old[0]].def || 0) < it.def) { takeItem(p.inv, id, 1); if (old) addItem(p.inv, old[0], 1); p.arm[it.slot] = [id, 1]; } }
      if (C) C.fx('craft', p, id);
      return true;
    }
    return false;
  }
  function bestSlot(p, pred, score) { let bk = -1, bs = -1e9; for (let k = 0; k < INV; k++) { const s = p.inv[k]; if (!s) continue; const it = IT[s[0]]; if (!pred(it)) continue; const v = score(it); if (v > bs) { bs = v; bk = k; } } return bk; }
  function toHot(p, k) { if (k < 0) return -1; if (k < HOT) return k; const free = 9; const tmp = p.inv[free]; p.inv[free] = p.inv[k]; p.inv[k] = tmp; return free; }
  function botInput(C, p, lv, M, leader) {
    const W = C.W; const I = { mx: 0, jump: 0, jumpP: 0, down: 0, use: 0, ax: p.x + p.dir * 3, ay: p.y - 1, sel: p.sel };
    if (p.dead) return I;
    M.t = (M.t || 0) + 1 / 60; M.craftT = (M.craftT || 0) - 1 / 60; M.stuck = M.stuck || 0;
    if (M.craftT <= 0) { M.craftT = 3; botCraft(p, C); }
    // 치유
    if (p.hp < p.hpM * 0.4 && !p.bf.sick) { const k = bestSlot(p, (it) => it.ef && it.ef.heal, (it) => it.ef.heal); if (k >= 0) { const s = toHot(p, k); I.sel = s; I.use = 1; I.ax = p.x; I.ay = p.y; return I; } }
    // 적
    let tg = null, bd = lv === 1 ? 10 : 15;
    for (const e of C.en()) { if (e.dead) continue; const d = Math.hypot(e.x - p.x, e.y - p.y); if (d < bd) { bd = d; tg = e; } }
    const B = C.boss();
    if (B && B.hp > 0 && Math.hypot(B.x - p.x, B.y - p.y) < 45) tg = { x: B.x, y: B.y + (B.b === 0 ? 0 : 1.2), h: B.b === 0 ? B.h : 2.4, boss: 1 };
    if (tg) {
      const ranged = bestSlot(p, (it) => (it.c === 'ranged' && (!it.ammo || findAmmo(p) >= 0)) || (it.c === 'magic' && p.mp >= it.mana), (it) => it.dmg);
      const melee = bestSlot(p, (it) => it.c === 'melee', (it) => it.dmg * (it.rch || 2));
      const useR = ranged >= 0 && (tg.boss || bd > 4 || melee < 0);
      const k = useR ? ranged : melee >= 0 ? melee : bestSlot(p, (it) => it.c === 'pick', (it) => it.pk);
      I.sel = toHot(p, k);
      const noise = lv === 1 ? 2.2 : lv === 2 ? 0.8 : 0.2;
      I.ax = tg.x + (Math.random() - 0.5) * noise; I.ay = tg.y - (tg.h || 1) / 2 + (Math.random() - 0.5) * noise;
      const dx = tg.x - p.x, want = useR ? (Math.abs(dx) < 7 ? -Math.sign(dx) : Math.abs(dx) > 12 ? Math.sign(dx) : 0) : (Math.abs(dx) > 1.6 ? Math.sign(dx) : 0);
      I.mx = want; I.use = Math.random() < (lv === 1 ? 0.5 : 0.95) ? 1 : 0;
      if ((p.hitW && p.gnd) || (tg.y < p.y - 3 && p.gnd && Math.random() < 0.05)) { I.jump = 1; I.jumpP = 1; }
      if (tg.boss && p.gnd && Math.random() < 0.04) { I.jump = 1; I.jumpP = 1; }
      return I;
    }
    // 사람 따라가기
    if (leader && !leader.dead) {
      const dx = leader.x - p.x, dy = leader.y - p.y;
      if (Math.hypot(dx, dy) > 70) { p.x = leader.x - leader.dir * 2; p.y = leader.y; p.vx = p.vy = 0; return I; }
      if (Math.abs(dx) > 4) I.mx = Math.sign(dx);
      if ((p.hitW && p.gnd) || (dy < -3 && p.gnd && Math.abs(dx) < 6)) { I.jump = 1; I.jumpP = 1; }
      if (p.hitW) M.stuck += 1 / 60; else M.stuck = 0;
      if (M.stuck > 1.2) { const k = bestSlot(p, (it) => it.c === 'pick', (it) => it.pk); I.sel = toHot(p, k); I.ax = p.x + Math.sign(dx) + 0.5; I.ay = p.y - 1.2; I.use = 1; }
      return I;
    }
    // 시연: 나무 베기 → 계단식으로 파 내려가기 → 횃불
    const wood = countItem(p.inv, IX.wood);
    M.mode = M.mode || 'chop'; M.dir = M.dir || (p.s % 2 ? 1 : -1);
    if (M.mode === 'chop' && (wood > 60 || M.t > 40)) { M.mode = 'dig'; }
    if (M.mode === 'dig' && M.t > 140 && M.t < 150) M.mode = 'dig';
    const fx = Math.floor(p.x), fy = Math.floor(p.y - 0.1);
    if (M.mode === 'chop') {
      let tree = -1; for (let d = 1; d < 14 && tree < 0; d++) for (const sg of [M.dir, -M.dir]) { const x = fx + sg * d; if (x < 1 || x >= W.w - 1) continue; for (let y = fy - 2; y <= fy + 1; y++) if (TL[tAt(W, x, y)].f & 32) { tree = x; break; } if (tree >= 0) break; }
      if (tree >= 0) {
        const k = bestSlot(p, (it) => it.c === 'axe' || it.ax, (it) => it.ax || 0); I.sel = toHot(p, k);
        if (Math.abs(tree + 0.5 - p.x) > 2.2) I.mx = Math.sign(tree + 0.5 - p.x);
        let ty = fy; for (let y = fy - 2; y <= fy + 1; y++) if (TL[tAt(W, tree, y)].f & 32) { ty = y; break; }
        I.ax = tree + 0.5; I.ay = ty + 0.5; I.use = Math.abs(tree + 0.5 - p.x) < 3 ? 1 : 0;
      } else I.mx = M.dir;
      if (p.hitW && p.gnd) { I.jump = 1; I.jumpP = 1; }
      if (p.hitW) M.stuck += 1 / 60; else M.stuck = Math.max(0, M.stuck - 1 / 60);
      if (M.stuck > 2) { M.dir = -M.dir; M.stuck = 0; }
      return I;
    }
    // 파 내려가기
    const k = bestSlot(p, (it) => it.c === 'pick', (it) => it.pk); I.sel = toHot(p, k);
    const d = M.dir;
    const tgts = [[fx + d, fy - 1], [fx + d, fy - 2], [fx + d, fy], [fx + d, fy + 1]];
    let target = null;
    for (const [x, y] of tgts) { const t2 = tAt(W, x, y); if (t2 && !(TL[t2].f & 32) && (SOLIDT[t2] || TL[t2].f & 16 || TL[t2].pot)) { target = [x, y]; break; } }
    if (!target && p.gnd && Math.random() < 0.02) { const t2 = tAt(W, fx, fy + 1); if (SOLIDT[t2]) target = [fx, fy + 1]; }
    if (target) { I.ax = target[0] + 0.5; I.ay = target[1] + 0.5; I.use = 1; if (TL[tAt(W, target[0], target[1])].pk > ((IT[p.inv[I.sel] ? p.inv[I.sel][0] : 0] || {}).pk || 0)) { M.dir = -M.dir; } }
    else I.mx = d;
    if (p.hitW && p.gnd && !target) { I.jump = 1; I.jumpP = 1; }
    if (lq_danger(W, p, d)) { M.dir = -d; I.mx = -d; }
    // 횃불
    M.torchT = (M.torchT || 0) - 1 / 60;
    if (M.torchT <= 0 && zoneOf(W, p.x, p.y) !== 'surface') { M.torchT = 4; const tk = bestSlot(p, (it) => it.k === 'torch', () => 1); if (tk >= 0) { I.sel = toHot(p, tk); I.ax = p.x; I.ay = p.y - 1.5; I.use = 1; } }
    if (p.x < 30 || p.x > W.w - 30) M.dir = -M.dir;
    return I;
  }
  function lq_danger(W, p, d) { const x = Math.floor(p.x + d * 1.5); for (let y = Math.floor(p.y - 2); y < p.y + 3; y++) { const a = W.lq[clamp(y, 0, W.h - 1) * W.w + clamp(x, 0, W.w - 1)]; if (a & 16) return true; } return false; }

  /* ======================= 호스트: 행동 처리 ======================= */
  function hostAction(G, seat, a) {
    if (!Array.isArray(a)) return;
    const W = G.W, k = a[0];
    const xi = a[1] | 0, yi = a[2] | 0, i = yi * W.w + xi;
    const inside = xi > 0 && yi > 0 && xi < W.w - 1 && yi < W.h - 1;
    const touch = () => { if (inside) logEdit(G, i); };
    switch (k) {
      case 'b': if (!inside || !breakTile(G, xi, yi, seat)) touch(); break;
      case 'bw': if (inside && W.wl[i]) { const wv = W.wl[i]; setWl(G, i, 0); giveItem(G, seat, IX[WL[wv].k], 1, xi + 0.5, yi + 0.5); } else touch(); break;
      case 'p': {
        const tt = a[3] | 0, iid = a[4] | 0;
        if (!inside || !TL[tt]) { touch(); break; }
        const P = G.P[seat];
        const ents = G.alive.concat(G.en);
        const cur = W.t[i];
        // 게스트가 먼저 그려 둔 경우 확인
        if (G.P[seat] && G.P[seat].local) { // 로컬은 이미 그려 놓음 → 되돌려서 확인
          if (TL[tt].door) for (let q = 0; q < 3; q++) W.t[(yi - q) * W.w + xi] = 0; else W.t[i] = 0;
        }
        void cur; void P;
        const why = canPlace(G, xi, yi, tt, tt === T_.plat ? null : ents.filter((e) => e !== G.P[seat]));
        if (why === 'ok') placeTile(G, xi, yi, tt); else { touch(); if (TL[tt].door) { logEdit(G, i - W.w); logEdit(G, i - 2 * W.w); } giveItem(G, seat, iid, 1, xi + 0.5, yi + 0.5); }
        break;
      }
      case 'pw': { const wv = a[3] | 0; if (inside && !(G.P[seat] && G.P[seat].local)) { if (!W.wl[i] && WL[wv]) setWl(G, i, wv); else touch(); } else if (inside) { const v = W.wl[i]; W.wl[i] = 0; setWl(G, i, v || wv); } break; }
      case 'd': if (inside) toggleDoor(G, xi, yi); break;
      case 'h': {
        const eid = a[1], dmg = clamp(+a[2] || 0, 0, 5000), dir = Math.sign(+a[3] || 0), kb = clamp(+a[4] || 0, 0, 12), cr = a[5] ? 1 : 0, fire = a[6] | 0;
        if (eid === -1) hurtBoss(G, dmg, cr, fire);
        else { const e = G.en.find((q) => q.id === eid); if (e) hurtEnemy(G, e, dmg, kb, dir, cr, 0, seat, fire); }
        break;
      }
      case 'bs': { const p = G.P[seat]; if (p && !G.boss && BOSS[a[1]]) bossSpawn(G, a[1] | 0, p); break; }
      case 'co': if (inside && W.t[i] === T_.chest) { chestOf(G, i); G.open[seat] = i; } break;
      case 'cc': delete G.open[seat]; break;
      case 'ct': { const ci = a[1] | 0, sl = a[2] | 0, id = a[3] | 0, n = a[4] | 0; const c = G.chest[ci]; if (!c || !c[sl] || c[sl][0] !== id) break; const m = Math.min(n, c[sl][1]); c[sl][1] -= m; if (!c[sl][1]) c[sl] = null; giveItem(G, seat, id, m); G.chv = (G.chv | 0) + 1; break; }
      case 'cp': { const ci = a[1] | 0, sl = a[2] | 0, id = a[3] | 0, n = a[4] | 0; const c = G.chest[ci]; if (!IT[id] || n <= 0) break; if (!c) { giveItem(G, seat, id, n); break; } let left = n; if (sl >= 0 && sl < CHEST_N) { if (!c[sl]) { c[sl] = [id, Math.min(n, IT[id].mx)]; left = n - c[sl][1]; } else if (c[sl][0] === id) { const m = Math.min(left, IT[id].mx - c[sl][1]); c[sl][1] += m; left -= m; } } if (left) left = addItem(c, id, left); if (left) giveItem(G, seat, id, left); G.chv = (G.chv | 0) + 1; break; }
      case 'dr': { const id = a[1] | 0, n = a[2] | 0; if (IT[id] && n > 0) dropItem(G, id, n, +a[3] || W.spawn.x, +a[4] || W.spawn.y, +a[5] || 0, -4); break; }
      case 'sh': pushFx(G, ['sh', seat, a[1], +a[2], +a[3], +a[4], +a[5]]); break;
      case 'fl': { const kk = a[1], v = +a[2] || 0; if (kk === 'hp') G.fl.hp = Math.max(G.fl.hp, v); if (kk === 'mp') G.fl.mp = Math.max(G.fl.mp, v); if (kk === 'coin') G.fl.coin = Math.max(G.fl.coin, v); if (kk === 'alch') G.fl.alch = 1; break; }
    }
  }

  /* ======================= 스냅샷 (호스트 → 모두) ======================= */
  const PJK = ['thorn', 'feather', 'fireb', 'spike', 'shadow', 'icebolt', 'starb', 'bolt', 'bone', 'lavab', 'laser'];
  function snapshot(G, key, q, minAck) {
    const W = G.W;
    const o = { k: key, q, tm: r2(G.tm * 1000) / 1000, dy: G.day, ev: G.ev ? (G.ev.k === 'raid' ? 'r' + G.ev.left : 'b') : 0, es: G.eseq };
    o.P = G.P.map((p) => (p ? [r1(p.x), r1(p.y), p.dir, p.dead ? 1 : 0, p.sw ? r1(p.sw.ang) : null, p.inv && p.inv[p.sel] ? p.inv[p.sel][0] : (p.held | 0), Math.round(p.hp), p.hpM, (p.arm || []).map((a) => (a ? a[0] : -1)).join('.'), p.iv > 0 ? 1 : 0, r1(p.vx || 0), r1(p.vy || 0)] : null));
    o.E = G.en.slice(0, 70).map((e) => [e.id, e.t, r1(e.x), r1(e.y), r1(e.vx), r1(e.vy), Math.round(e.hp), e.hpM, e.dir, e.hurt > 0 ? 1 : 0]);
    o.D = G.dr.slice(-90).map((d) => [d.id, d.it, r1(d.x), r1(d.y)]);
    o.J = G.pj.slice(-90).map((j) => [j.id, PJK.indexOf(j.k), r1(j.x), r1(j.y), r1(j.vx), r1(j.vy), j.warn > 0 ? 1 : 0, Math.round(j.dmg)]);
    o.N = G.npcs.map((n) => [n.k, r1(n.x), r1(n.y), n.dir, n.home ? 1 : 0]);
    if (G.boss) { const b = G.boss; o.B = [b.b, r1(b.x), r1(b.y), Math.round(b.hp), b.hpM, b.ph, r2(b.ang || b.a || b.rot || 0), b.hurt > 0 ? 1 : 0, b.seg ? b.seg.map((s) => r1(s[0]) + ',' + r1(s[1])).join(';') : b.hands ? b.hands.map((h) => r1(h.x) + ',' + r1(h.y) + ',' + h.st).join(';') : '', r1(b.vx || 0), r1(b.vy || 0)]; }
    o.fl = [G.fl.b.join(''), G.fl.coin, G.fl.hp, G.fl.mp, G.fl.anvil, G.fl.alch, G.fl.meteor | 0];
    // 편집 기록: minAck 다음부터 최대 450칸
    const L2 = G.log; let lo = 0, hi = L2.s.length;
    while (lo < hi) { const m = (lo + hi) >> 1; if (L2.s[m] <= minAck) lo = m + 1; else hi = m; }
    const ed = []; let end = minAck;
    for (let k = lo; k < L2.s.length && ed.length < 450 * 4; k++) { const sq = L2.s[k], idx = L2.i[k]; end = sq; if (G.last.get(idx) !== sq) continue; ed.push(idx, W.t[idx], W.wl[idx], W.lq[idx]); }
    if (ed.length || minAck < G.eseq) { o.ed = ed; o.e0 = minAck; o.e1 = end; }
    o.A = G.ack; o.G = G.grants.slice(-50);
    o.fx = G.fx.slice(-40);
    const C = {}; for (const s in G.open) { const ci = G.open[s]; if (G.chest[ci]) C[s] = [ci, packInv(G.chest[ci])]; } o.C = C;
    if (G.ivOut) o.IV = G.ivOut;
    if (G.meteorAt) o.mt = G.meteorAt;
    return o;
  }
  function compactLog(G, minAck) {
    const L2 = G.log; if (L2.s.length < 30000) return;
    const s2 = [], i2 = [];
    for (let k = 0; k < L2.s.length; k++) { const sq = L2.s[k], idx = L2.i[k]; if (G.last.get(idx) === sq) { s2.push(sq); i2.push(idx); } }
    L2.s = s2; L2.i = i2; void minAck;
  }

  /* ======================= 저장 ======================= */
  function rle(arr) { const out = []; let k = 0; while (k < arr.length) { const v = arr[k]; let n = 1; while (k + n < arr.length && arr[k + n] === v && n < 65535) n++; out.push(v, n & 255, n >> 8); k += n; } return b64(Uint8Array.from(out)); }
  function unrle(str, N) { const b = ub64(str), out = new Uint8Array(N); let o = 0; for (let k = 0; k + 2 < b.length; k += 3) { const v = b[k], n = b[k + 1] | (b[k + 2] << 8); out.fill(v, o, Math.min(N, o + n)); o += n; } return out; }
  function b64(u8) { let s = ''; for (let k = 0; k < u8.length; k += 8192) s += String.fromCharCode.apply(null, u8.subarray(k, k + 8192)); return typeof btoa === 'function' ? btoa(s) : Buffer.from(s, 'binary').toString('base64'); }
  function ub64(str) { const s = typeof atob === 'function' ? atob(str) : Buffer.from(str, 'base64').toString('binary'); const u = new Uint8Array(s.length); for (let k = 0; k < s.length; k++) u[k] = s.charCodeAt(k); return u; }
  function savePlayer(p) { return p ? { i: packInv(p.inv), a: packInv(p.arm), c: packInv(p.acc), h: p.hpM, m: p.mpM, sp: p.sp || null, st: p.stats } : null; }
  function loadPlayer(p, o) { if (!o || !p) return; p.inv = unpackInv(o.i, INV); p.arm = unpackInv(o.a, 3); p.acc = unpackInv(o.c, 5); p.hpM = clamp(o.h | 0, 100, 400); p.hp = p.hpM; p.mpM = clamp(o.m | 0, 20, 200); p.mp = p.mpM; p.sp = o.sp || null; if (o.st) p.stats = Object.assign(p.stats, o.st); p.st = null; }
  function saveGame(G) {
    const W = G.W;
    return { v: 1, seed: W.seed, sz: W.sz, t: rle(W.t), wl: rle(W.wl), lq: rle(W.lq), tm: G.tm, day: G.day, fl: G.fl, ev: G.ev, ch: Object.keys(G.chest).map((k) => [+k, packInv(G.chest[k])]), npc: G.npcs.map((n) => [n.k, r1(n.x), r1(n.y), n.home]), pl: G.P.map((p) => (p && (p.local || p.saved) ? (p.local ? savePlayer(p) : p.saved) : null)), stat: G.stat, sp: W.spawn, mt: G.meteorAt || null };
  }
  function loadGame(G, o) {
    const W = G.W, N = W.w * W.h;
    const t = unrle(o.t, N), wl = unrle(o.wl, N), lq = unrle(o.lq, N);
    for (let i = 0; i < N; i++) { if (W.t[i] !== t[i] || W.wl[i] !== wl[i] || W.lq[i] !== lq[i]) { W.t[i] = t[i]; W.wl[i] = wl[i]; W.lq[i] = lq[i]; logEdit(G, i); } }
    G.doors = new Set(); for (let i = 0; i < N; i++) if (W.t[i] === T_.door) G.doors.add(i);
    for (let x = 0; x < W.w; x++) colTop(W, x);
    W.lqAct = new Set();
    G.tm = +o.tm || 0.1; G.day = o.day | 0 || 1; G.fl = Object.assign(G.fl, o.fl || {}); G.ev = o.ev || null; G.stat = o.stat || G.stat; G.meteorAt = o.mt || null;
    G.chest = {}; for (const [k, s] of o.ch || []) G.chest[k] = unpackInv(s, CHEST_N);
    G.npcs = (o.npc || []).map((n) => ({ k: n[0], x: n[1], y: n[2], vx: 0, vy: 0, w: 1.2, h: 2.7, dir: 1, home: n[3] || null, t: 0 }));
    if (!G.npcs.length) G.npcs.push({ k: 0, x: W.spawn.x + 3, y: W.spawn.y - 0.01, vx: 0, vy: 0, w: 1.2, h: 2.7, dir: -1, home: null, t: 0 });
    G.loadedPl = o.pl || [];
  }

  /* ======================= 큰 흐름 상태 (api.setState) ======================= */
  function init(players, opts) {
    opts = opts || {};
    const seed = opts.seed && opts.seed !== 'r' ? +opts.seed : (Math.random() * 1e9) | 0;
    return { ph: 'play', rid: (Math.random() * 1e9) | 0, seed, sz: clamp(opts.size === undefined ? 1 : opts.size | 0, 0, 2), dif: clamp(opts.dif === undefined ? 1 : opts.dif | 0, 0, 2), goal: opts.goal | 0, np: players.length, nm: players.map((p) => p.name), ai: players.map((p) => (p.ai ? 1 : 0)), res: null };
  }
  function result(st) {
    if (!st || !st.res) return null;
    const r = st.res;
    return {
      winners: r.win ? Array.from({ length: st.np }, (_, i) => i) : [],
      title: r.title || '개척 기록', text: r.text || '',
      highlights: r.hl || [],
      stats: (r.stats || []).slice(0, 8),
    };
  }

  /* ======================= 그리기 도우미 ======================= */
  function shade(hex, f) { if (!hex || hex[0] !== '#') return hex; const n = parseInt(hex.slice(1, 7), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255; if (f > 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; } return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')'; }
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function mkCanvas(w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, w | 0); c.height = Math.max(1, h | 0); return c; }
  // 타일 그림(변형 4가지) — 8×8 "점" 무늬를 TS 크기로
  function makeAtlas(TS) {
    const A = { TS, t: [], w: [] };
    for (let ti = 1; ti < NT; ti++) {
      const T = TL[ti]; const vs = [];
      for (let v = 0; v < 4; v++) { const c = mkCanvas(TS, TS), g = c.getContext('2d'); drawTileArt(g, ti, TS, v); vs.push(c); }
      A.t[ti] = vs; void T;
    }
    for (let wi = 1; wi < WL.length; wi++) { const vs = []; for (let v = 0; v < 2; v++) { const c = mkCanvas(TS, TS), g = c.getContext('2d'); const col = WL[wi].col; g.fillStyle = col; g.fillRect(0, 0, TS, TS); const p = TS / 8; for (let k = 0; k < 7; k++) { const h = hash2(k, v, wi); g.fillStyle = h < 0.5 ? 'rgba(0,0,0,.18)' : 'rgba(255,255,255,.06)'; g.fillRect((hash2(k, 3, wi + v) * 8 | 0) * p, (hash2(k, 5, wi + v) * 8 | 0) * p, p * 2, p); } if (!WL[wi].nat) { g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, TS / 2 - 1, TS, 1); g.fillRect(v ? TS / 2 : 0, 0, 1, TS / 2); g.fillRect(v ? 0 : TS / 2, TS / 2, 1, TS / 2); } vs.push(c); } A.w[wi] = vs; }
    return A;
  }
  function drawTileArt(g, ti, S, v) {
    const T = TL[ti], p = S / 8, k = T.k;
    const px = (x, y, w, h, c) => { g.fillStyle = c; g.fillRect(Math.round(x * p), Math.round(y * p), Math.ceil(w * p), Math.ceil(h * p)); };
    const speck = (n, c, sz) => { for (let q = 0; q < n; q++) px(hash2(q, v, ti) * 7 | 0, hash2(q, v + 9, ti) * 7 | 0, sz || 1, sz || 1, c); };
    if (SOLIDT[ti] && !T.door) {
      px(0, 0, 8, 8, T.ore ? (k === 'ore_hl' ? '#4d4446' : '#6f6f7a') : T.col);
      if (k === 'glass') { g.clearRect(0, 0, S, S); px(0, 0, 8, 8, 'rgba(190,230,240,.25)'); px(1, 1, 2, 1, 'rgba(255,255,255,.7)'); px(1, 2, 1, 1, 'rgba(255,255,255,.5)'); g.strokeStyle = 'rgba(200,240,255,.55)'; g.lineWidth = 1; g.strokeRect(0.5, 0.5, S - 1, S - 1); return; }
      if (k === 'planks') { px(0, 3.6, 8, 0.6, 'rgba(0,0,0,.25)'); px(0, 7.4, 8, 0.6, 'rgba(0,0,0,.25)'); px(v % 2 ? 2 : 5, 0, 0.6, 3.6, 'rgba(0,0,0,.2)'); px(v % 2 ? 6 : 3, 4, 0.6, 3.6, 'rgba(0,0,0,.2)'); speck(3, 'rgba(255,255,255,.08)'); return; }
      if (k === 'sbrick' || k === 'skybrick') { px(0, 3.6, 8, 0.6, 'rgba(0,0,0,.3)'); px(0, 7.4, 8, 0.6, 'rgba(0,0,0,.3)'); px(4, 0, 0.6, 3.6, 'rgba(0,0,0,.3)'); px(v % 2 ? 1 : 7, 4, 0.6, 3.6, 'rgba(0,0,0,.3)'); px(0, 0, 8, 0.6, 'rgba(255,255,255,.12)'); return; }
      speck(6, 'rgba(0,0,0,.16)', 1); speck(4, 'rgba(255,255,255,.09)', 1);
      if (T.ore) { const oc = shade(T.col, 0.3); for (let q = 0; q < 6; q++) { const x = hash2(q, v, ti + 40) * 6 | 0, y = hash2(q, v + 3, ti + 40) * 6 | 0; px(x, y, 2, 2, T.col); px(x, y, 1, 1, oc); } }
      if (k === 'stone' || k === 'ash' || k === 'obsid') { px(hash2(1, v, 3) * 5 | 0, hash2(2, v, 3) * 5 | 0, 3, 1, 'rgba(0,0,0,.18)'); }
      if (k === 'ice') { px(1, 1, 3, 1, 'rgba(255,255,255,.5)'); px(1, 2, 1, 1, 'rgba(255,255,255,.4)'); }
      if (k === 'cloud') { speck(5, 'rgba(200,215,240,.6)', 2); }
      if (k === 'crystal') { px(2, 1, 2, 5, '#d8c0ff'); px(5, 3, 2, 4, '#c8a8ff'); px(2, 1, 1, 2, '#fff'); }
      if (k === 'boneb') { px(1, 2, 6, 1, '#f0ead8'); px(2, 5, 5, 1, '#f0ead8'); px(1, 1, 1, 3, '#f0ead8'); px(6, 4, 1, 3, '#f0ead8'); }
      if (k === 'clay') speck(4, 'rgba(255,200,170,.12)', 2);
      return;
    }
    const c = T.col;
    switch (k) {
      case 'log': px(1.5, 0, 5, 8, c); px(2, 0, 1, 8, shade(c, 0.15)); px(5, 0, 1, 8, shade(c, -0.25)); px(3.5, v * 2, 1, 2, shade(c, -0.3)); break;
      case 'cactus': px(2, 0, 4, 8, c); px(2.5, 0, 1, 8, shade(c, 0.2)); px(1, 2 + v, 1, 1, '#d8e8a0'); px(6, 5 - v, 1, 1, '#d8e8a0'); break;
      case 'leaf': case 'pine': case 'jleaf': { g.fillStyle = c; g.beginPath(); g.arc(S / 2, S / 2, S * 0.62, 0, TAU); g.fill(); g.fillStyle = shade(c, 0.18); g.beginPath(); g.arc(S * 0.4, S * 0.38, S * 0.28, 0, TAU); g.fill(); g.fillStyle = shade(c, -0.25); g.beginPath(); g.arc(S * 0.68, S * 0.7, S * 0.22, 0, TAU); g.fill(); break; }
      case 'torch': px(3.5, 3, 1, 5, '#7a5230'); px(3, 1.5, 2, 2, '#ffcf5a'); px(3.4, 0.8, 1.2, 1.2, '#fff4c0'); break;
      case 'plat': px(0, 0, 8, 2, c); px(0, 0, 8, 0.6, shade(c, 0.2)); px(1, 2, 1, 1, shade(c, -0.3)); px(6, 2, 1, 1, shade(c, -0.3)); break;
      case 'wbench': px(0, 2, 8, 2, c); px(0, 2, 8, 0.6, shade(c, 0.2)); px(0.5, 4, 1.2, 4, shade(c, -0.2)); px(6.3, 4, 1.2, 4, shade(c, -0.2)); px(2, 1, 2, 1, '#888'); break;
      case 'furnace': px(0.5, 1, 7, 7, c); px(0.5, 1, 7, 0.8, shade(c, 0.2)); px(2.5, 4, 3, 3, '#ff8a30'); px(3, 4.5, 2, 2, '#ffd27a'); px(3, 0, 2, 1, '#555'); break;
      case 'anvil': px(0.5, 3, 7, 2, c); px(0, 3, 2, 1, c); px(3, 5, 2, 2, shade(c, -0.2)); px(1.5, 7, 5, 1, shade(c, -0.2)); px(0.5, 3, 7, 0.6, shade(c, 0.3)); break;
      case 'chest': px(0.5, 2, 7, 6, c); px(0.5, 2, 7, 2, shade(c, 0.12)); px(0.5, 4, 7, 0.6, '#5a3a1a'); px(3.5, 3.6, 1, 1.6, '#f2c844'); px(0.5, 2, 0.8, 6, '#6a4a2a'); px(6.7, 2, 0.8, 6, '#6a4a2a'); break;
      case 'door': px(1, 0, 6, 8, c); px(1, 0, 0.8, 8, shade(c, -0.3)); px(6.2, 0, 0.8, 8, shade(c, -0.3)); px(5, 3.5, 1, 1, '#f2c844'); px(2, 0, 4, 0.6, shade(c, 0.2)); break;
      case 'dooro': px(0, 0, 2, 8, c); px(0, 0, 0.6, 8, shade(c, 0.2)); break;
      case 'table': case 'alch': px(0, 3, 8, 1.3, c); px(1, 4.3, 1, 3.7, shade(c, -0.25)); px(6, 4.3, 1, 3.7, shade(c, -0.25)); if (k === 'alch') { px(2, 1, 1.4, 2, '#9ad8ff'); px(4.5, 0.5, 1.6, 2.5, '#d08aff'); } break;
      case 'chair': px(5, 0.5, 1.2, 7.5, c); px(1.5, 4, 4.7, 1.2, c); px(1.5, 5.2, 1, 2.8, shade(c, -0.25)); break;
      case 'bed': px(0, 4, 8, 2, '#eee'); px(0, 5, 8, 1.5, c); px(0, 3, 1.2, 5, '#7a4a2a'); px(6.8, 4, 1.2, 4, '#7a4a2a'); px(1.2, 3.4, 2, 1, '#fff'); break;
      case 'hforge': px(0.5, 1, 7, 7, c); px(1.5, 3, 5, 3, '#ff5a20'); px(2.5, 3.5, 3, 2, '#ffd27a'); px(0, 0, 8, 1.2, '#3a1a14'); break;
      case 'starwb': px(0, 3, 8, 1.5, c); px(1, 4.5, 1, 3.5, shade(c, -0.25)); px(6, 4.5, 1, 3.5, shade(c, -0.25)); px(3, 0.5, 2, 2, '#e8dcff'); px(3.5, 0, 1, 3, '#c8b8ff'); break;
      case 'books': px(0.5, 0, 7, 8, c); for (let q = 0; q < 3; q++) { px(1, 0.6 + q * 2.6, 6, 0.4, '#3a2210'); px(1.2, 1 + q * 2.6, 1, 1.8, ['#c84a4a', '#4a7ac8', '#5aa85a'][q]); px(2.4, 1.2 + q * 2.6, 1, 1.6, ['#e8c040', '#c84a4a', '#8a5ad0'][q]); px(3.8, 1 + q * 2.6, 1.2, 1.8, '#d8d0c0'); } break;
      case 'lamp': px(3.5, 2, 1, 6, '#5a4a3a'); px(2, 0, 4, 2.6, '#ffe8a0'); px(2.5, 0.4, 3, 1.6, '#fff8e0'); px(2.5, 7.4, 3, 0.6, '#5a4a3a'); break;
      case 'lcrys': px(2, 1, 4, 6, '#ff5a7a'); px(3, 0, 2, 8, '#ff7a9a'); px(3, 1.5, 1, 2, '#ffe0e8'); break;
      case 'pot': px(1.5, 3, 5, 5, c); px(2.5, 2, 3, 1, shade(c, -0.2)); px(1.5, 5, 5, 0.6, shade(c, 0.2)); px(2, 3.5, 1, 2, shade(c, 0.25)); break;
      case 'vine': px(3.5, 0, 1, 8, c); px(2.5, 2 + v, 1, 1, shade(c, 0.2)); px(4.5, 5 - v, 1, 1, shade(c, 0.2)); break;
      case 'mush': px(3.5, 4.5, 1, 3.5, '#f0e0c8'); px(2, 3, 4, 2, c); px(2.6, 3.2, 1, 0.8, '#fff'); break;
      case 'sapling': px(3.5, 4, 1, 4, '#6a4a2a'); px(2, 2, 2, 2, c); px(4, 1, 2, 2, c); break;
      case 'tinker': px(0, 3, 8, 1.4, c); px(1, 4.4, 1, 3.6, shade(c, -0.25)); px(6, 4.4, 1, 3.6, shade(c, -0.25)); px(2, 1.8, 1, 1.2, '#ccc'); px(4.5, 1.2, 2, 1.8, '#d8a040'); break;
      case 'web': g.strokeStyle = 'rgba(235,235,245,.6)'; g.lineWidth = Math.max(1, S / 16); g.beginPath(); g.moveTo(0, 0); g.lineTo(S, S); g.moveTo(S, 0); g.lineTo(0, S); g.moveTo(S / 2, 0); g.lineTo(S / 2, S); g.stroke(); g.beginPath(); g.arc(S / 2, S / 2, S * 0.25, 0, TAU); g.stroke(); break;
      default: { // 약초
        if (T.f & 16) { px(3.5, 4, 1, 4, '#3a8a3a'); px(2.5, 5.5, 1, 1, '#3a8a3a'); px(4.5, 5, 1, 1, '#3a8a3a'); px(2.5, 2, 3, 2.4, c); px(3.2, 2.6, 1.4, 1.2, shade(c, 0.5)); }
      }
    }
  }
  // 아이템 그림
  const iconCache = new Map();
  function itemIcon(id, S) {
    const key = id + ':' + S; let c = iconCache.get(key); if (c) return c;
    c = mkCanvas(S, S); const g = c.getContext('2d'); drawItemArt(g, IT[id], S); iconCache.set(key, c); return c;
  }
  function drawItemArt(g, it, S) {
    const col = it.col || '#ccc', u = S / 16;
    g.lineCap = 'round'; g.lineJoin = 'round';
    const line = (x0, y0, x1, y1, w, c) => { g.strokeStyle = c; g.lineWidth = w * u; g.beginPath(); g.moveTo(x0 * u, y0 * u); g.lineTo(x1 * u, y1 * u); g.stroke(); };
    const circ = (x, y, r, c) => { g.fillStyle = c; g.beginPath(); g.arc(x * u, y * u, r * u, 0, TAU); g.fill(); };
    const rect = (x, y, w, h, c) => { g.fillStyle = c; g.fillRect(x * u, y * u, w * u, h * u); };
    const handle = '#8a5a30';
    const tileIco = (tk) => { const ti = TX[tk]; if (ti === undefined) return false; const t2 = mkCanvas(16, 16), gg = t2.getContext('2d'); drawTileArt(gg, ti, 16, 1); g.imageSmoothingEnabled = false; const sz = TL[ti].f & 8 || TL[ti].f & 16 || ti === T_.torch ? 14 : 11; g.drawImage(t2, (S - sz * u) / 2, (S - sz * u) / 2, sz * u, sz * u); if (SOLIDT[ti] && !(TL[ti].f & 8)) { g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = u * 0.6; g.strokeRect((S - sz * u) / 2, (S - sz * u) / 2, sz * u, sz * u); } return true; };
    switch (it.c) {
      case 'block': case 'furn': case 'light': if (it.k === 'wood') { rect(3, 5, 10, 6, '#9a6a3c'); circ(3, 8, 3, '#b08050'); circ(3, 8, 1.6, '#7a5230'); rect(3, 5, 10, 1, '#b08050'); return; } if (it.pl && tileIco(it.pl)) return; break;
      case 'wall': { const W2 = WL[it.pw]; rect(2, 2, 12, 12, W2.col); g.fillStyle = 'rgba(0,0,0,.3)'; for (let k = 0; k < 3; k++) rect(2, 5.5 + k * 4, 12, 0.7, 'rgba(0,0,0,.3)'); rect(7, 2, 0.7, 3.5, 'rgba(0,0,0,.3)'); g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = u; g.strokeRect(2 * u, 2 * u, 12 * u, 12 * u); return; }
      case 'pick': line(4, 13, 11, 4, 1.6, handle); g.strokeStyle = col; g.lineWidth = 2.2 * u; g.beginPath(); g.arc(9 * u, 9 * u, 7 * u, -2.6, -0.4); g.stroke(); return;
      case 'axe': line(4, 14, 11, 3, 1.6, handle); g.fillStyle = col; g.beginPath(); g.moveTo(9 * u, 3 * u); g.quadraticCurveTo(15 * u, 4 * u, 13 * u, 10 * u); g.lineTo(9.5 * u, 6.5 * u); g.closePath(); g.fill(); return;
      case 'hammer': line(4, 14, 10, 5, 1.6, handle); g.save(); g.translate(10.5 * u, 4.5 * u); g.rotate(0.6); g.fillStyle = col; g.fillRect(-4 * u, -2 * u, 8 * u, 4 * u); g.restore(); return;
      case 'melee': if (it.thrust) { line(2, 14, 13, 3, 1.4, '#d8d0b8'); g.fillStyle = col; g.beginPath(); g.moveTo(15 * u, 1 * u); g.lineTo(11 * u, 3.5 * u); g.lineTo(12.5 * u, 5 * u); g.closePath(); g.fill(); return; } if (it.ax) { line(4, 14, 11, 3, 1.6, '#5a2a14'); g.fillStyle = col; g.beginPath(); g.moveTo(9 * u, 2 * u); g.quadraticCurveTo(16 * u, 4 * u, 13 * u, 11 * u); g.lineTo(9.5 * u, 6.5 * u); g.closePath(); g.fill(); return; } line(4, 12, 13, 3, 2.6, col); line(4.5, 11.5, 13, 3, 0.7, 'rgba(255,255,255,.55)'); line(2.5, 9.5, 6.5, 13.5, 1.4, '#6a4a2a'); line(2, 14, 4, 12, 1.6, handle); return;
      case 'ranged': if (it.pj === 'boom') { g.strokeStyle = col; g.lineWidth = 2.4 * u; g.beginPath(); g.moveTo(3 * u, 4 * u); g.lineTo(8 * u, 9 * u); g.lineTo(13 * u, 4 * u); g.stroke(); return; } if (it.pj === 'thorn') { rect(3, 7, 10, 3, '#6a5a3a'); line(10, 8.5, 15, 8.5, 1, col); circ(13, 8.5, 1.2, col); return; } g.strokeStyle = col; g.lineWidth = 1.8 * u; g.beginPath(); g.arc(4 * u, 8 * u, 7 * u, -1.25, 1.25); g.stroke(); line(6.2, 1.4, 6.2, 14.6, 0.5, '#eee'); return;
      case 'ammo': line(3, 13, 12, 4, 1.1, '#b08050'); g.fillStyle = col; g.beginPath(); g.moveTo(14 * u, 2 * u); g.lineTo(10.5 * u, 4 * u); g.lineTo(12 * u, 5.5 * u); g.closePath(); g.fill(); line(3, 13, 2, 11, 1, '#eee'); line(3, 13, 5, 14, 1, '#eee'); return;
      case 'magic': if (it.k === 'water_tome') { rect(3, 3, 10, 11, '#2a4a8a'); rect(4, 4, 8, 9, '#3a6ac8'); circ(8, 8.5, 2.2, '#9ad8ff'); return; } line(4, 14, 11, 5, 1.6, '#6a4a2a'); circ(12, 4, 2.8, col); circ(11.2, 3.2, 1, '#fff'); return;
      case 'summon': line(4, 14, 11, 5, 1.6, '#4a3a5a'); g.strokeStyle = col; g.lineWidth = u; g.beginPath(); g.arc(12 * u, 4 * u, 3 * u, 0, TAU); g.stroke(); circ(12, 4, 1.6, col); return;
      case 'armor': g.fillStyle = col; if (it.slot === 0) { g.beginPath(); g.arc(8 * u, 9 * u, 6 * u, Math.PI, 0); g.fill(); rect(2, 9, 12, 2.5, shade(col, -0.2)); rect(6, 9, 4, 4, 'rgba(0,0,0,.35)'); } else if (it.slot === 1) { g.beginPath(); g.moveTo(3 * u, 3 * u); g.lineTo(13 * u, 3 * u); g.lineTo(15 * u, 7 * u); g.lineTo(12 * u, 7 * u); g.lineTo(12 * u, 14 * u); g.lineTo(4 * u, 14 * u); g.lineTo(4 * u, 7 * u); g.lineTo(1 * u, 7 * u); g.closePath(); g.fill(); rect(7.5, 4, 1, 9, 'rgba(0,0,0,.25)'); } else { rect(4, 2, 8, 3, col); rect(4, 5, 3.4, 9, col); rect(8.6, 5, 3.4, 9, col); rect(4, 2, 8, 1, shade(col, 0.25)); } return;
      case 'acc': { const k = it.k; if (k.includes('boots') || k === 'jelly_shoe') { g.fillStyle = k === 'jelly_shoe' ? '#5ab4ff' : k === 'wind_boots' ? '#a0e0ff' : '#c85a3a'; g.beginPath(); g.moveTo(4 * u, 2 * u); g.lineTo(9 * u, 2 * u); g.lineTo(9 * u, 10 * u); g.lineTo(14 * u, 11 * u); g.lineTo(14 * u, 14 * u); g.lineTo(4 * u, 14 * u); g.closePath(); g.fill(); return; } if (k.includes('jar')) { rect(5, 2, 6, 2, '#a07040'); g.fillStyle = 'rgba(200,230,255,.8)'; rr(g, 3 * u, 4 * u, 10 * u, 10 * u, 3 * u); g.fill(); circ(8, 9, 3, '#fff'); return; } if (k.includes('sh')) { g.fillStyle = k === 'obs_shield' ? '#3a2a5a' : '#6a8a4a'; g.beginPath(); g.moveTo(8 * u, 1 * u); g.lineTo(14 * u, 3 * u); g.quadraticCurveTo(14 * u, 12 * u, 8 * u, 15 * u); g.quadraticCurveTo(2 * u, 12 * u, 2 * u, 3 * u); g.closePath(); g.fill(); circ(8, 7, 2, '#d8d0b8'); return; } g.strokeStyle = '#d8b850'; g.lineWidth = 1.6 * u; g.beginPath(); g.arc(8 * u, 9 * u, 5 * u, 0, TAU); g.stroke(); circ(8, 4, 2.6, ({ feather_c: '#fff', lava_c: '#ff6a2a', might_s: '#d8344f', regen_b: '#ff8aa0', arcane_f: '#4a7aff', claw: '#999', gill_c: '#5ac8ff', miner_lamp: '#ffe680', gaze_eye: '#9a5ad0', worm_core: '#8a8a6a', bone_ring: '#f0e8c0', lord_crest: '#ff5a20', war_emblem: '#ff4a4a', life_band: '#ff6aa0' })[k] || '#ccc'); return; }
      case 'potion': rect(6.5, 1.5, 3, 3, '#cfefff'); rect(6, 1, 4, 1.2, '#8a5a30'); g.fillStyle = 'rgba(220,240,255,.7)'; g.beginPath(); g.arc(8 * u, 10 * u, 5 * u, 0, TAU); g.fill(); g.fillStyle = col; g.beginPath(); g.arc(8 * u, 10.5 * u, 4.2 * u, 0, Math.PI); g.lineTo(3.8 * u, 10 * u); g.fill(); g.fillRect(3.8 * u, 9 * u, 8.4 * u, 1.6 * u); circ(6.3, 8.4, 0.9, '#fff'); return;
      case 'coin': circ(8, 8, 6, '#c89a2a'); circ(8, 8, 4.8, '#f2c844'); rect(7.2, 5, 1.6, 6, '#c89a2a'); return;
      case 'boss': { const b = it.boss; const c2 = BOSS[b].col; if (b === 0) { g.fillStyle = '#f2c844'; g.beginPath(); g.moveTo(2 * u, 12 * u); g.lineTo(2 * u, 5 * u); g.lineTo(5 * u, 8 * u); g.lineTo(8 * u, 3 * u); g.lineTo(11 * u, 8 * u); g.lineTo(14 * u, 5 * u); g.lineTo(14 * u, 12 * u); g.closePath(); g.fill(); circ(8, 10, 1.6, '#5ab4ff'); return; } if (b === 3) { circ(8, 7, 6, '#e8e0c8'); circ(5.6, 7, 1.6, '#222'); circ(10.4, 7, 1.6, '#222'); rect(5, 11, 6, 3, '#e8e0c8'); return; } circ(8, 8, 6, shade(c2, -0.3)); circ(8, 8, 4.4, c2); circ(6.5, 6.5, 1.4, '#fff'); return; }
      case 'misc': if (it.use === 'life') { g.fillStyle = '#ff5a7a'; g.beginPath(); g.moveTo(8 * u, 14 * u); g.bezierCurveTo(-2 * u, 7 * u, 4 * u, 0, 8 * u, 5 * u); g.bezierCurveTo(12 * u, 0, 18 * u, 7 * u, 8 * u, 14 * u); g.fill(); circ(6, 6, 1.2, '#fff'); return; } if (it.use === 'mana') { g.fillStyle = '#4a7aff'; g.beginPath(); for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5, r = k % 2 ? 3 : 7; g.lineTo((8 + Math.cos(a) * r) * u, (8.5 + Math.sin(a) * r) * u); } g.fill(); return; } circ(8, 7, 5, '#dfe7f0'); circ(8, 7, 3.6, '#9ad8ff'); rect(7, 12, 2, 3, '#a07040'); return;
    }
    // 재료 기본: 보석·덩어리
    const k = it.k;
    if (k.startsWith('b_')) { g.fillStyle = col; g.beginPath(); g.moveTo(2 * u, 12 * u); g.lineTo(4.5 * u, 6 * u); g.lineTo(13.5 * u, 6 * u); g.lineTo(14 * u, 12 * u); g.closePath(); g.fill(); g.fillStyle = shade(col, 0.35); g.beginPath(); g.moveTo(4.5 * u, 6 * u); g.lineTo(13.5 * u, 6 * u); g.lineTo(12.5 * u, 8 * u); g.lineTo(5 * u, 8 * u); g.closePath(); g.fill(); return; }
    if (k === 'gel' || k === 'kgel') { g.fillStyle = col; g.beginPath(); g.ellipse(8 * u, 10 * u, 6 * u, 4.5 * u, 0, 0, TAU); g.fill(); circ(6, 8.5, 1.2, 'rgba(255,255,255,.7)'); return; }
    if (k === 'bone' || k === 'bonec') { line(4, 12, 12, 4, 2.2, col); circ(3.5, 12.5, 1.6, col); circ(4.5, 13.5, 1.4, col); circ(12.5, 3.5, 1.6, col); circ(11.5, 2.5, 1.4, col); return; }
    if (k === 'feather') { g.fillStyle = col; g.beginPath(); g.ellipse(8 * u, 8 * u, 2.6 * u, 6.5 * u, 0.6, 0, TAU); g.fill(); line(4, 13, 11, 3, 0.6, '#aaa'); return; }
    if (k === 'bottle') { g.fillStyle = 'rgba(210,240,255,.75)'; g.beginPath(); g.arc(8 * u, 10 * u, 5 * u, 0, TAU); g.fill(); rect(6.5, 1.5, 3, 4, 'rgba(210,240,255,.75)'); return; }
    if (k === 'acorn') { g.fillStyle = '#b07a40'; g.beginPath(); g.ellipse(8 * u, 10 * u, 4 * u, 4.6 * u, 0, 0, TAU); g.fill(); rect(4, 5, 8, 3, '#6a4a2a'); rect(7.5, 3, 1, 2, '#6a4a2a'); return; }
    if (['sunb', 'moonl', 'firew', 'frostb', 'duneb', 'mush'].includes(k)) { line(8, 15, 8, 7, 1.2, '#3a8a3a'); line(8, 11, 5, 9, 1, '#3a8a3a'); circ(8, 5.5, 3.4, col); circ(8, 5.5, 1.4, shade(col, 0.5)); return; }
    if (k === 'stard' || k === 'starc') { g.fillStyle = col; g.beginPath(); for (let q = 0; q < 10; q++) { const a = -Math.PI / 2 + q * Math.PI / 5, r = q % 2 ? 2.6 : 6.5; g.lineTo((8 + Math.cos(a) * r) * u, (8.5 + Math.sin(a) * r) * u); } g.fill(); return; }
    if (k === 'lens') { circ(8, 8, 5.5, '#dfe7f0'); circ(8, 8, 3.5, '#5a3a6a'); circ(6.5, 6.5, 1.2, '#fff'); return; }
    // 기본 보석
    g.fillStyle = shade(col, -0.25); g.beginPath(); g.moveTo(8 * u, 2 * u); g.lineTo(14 * u, 7 * u); g.lineTo(8 * u, 14 * u); g.lineTo(2 * u, 7 * u); g.closePath(); g.fill();
    g.fillStyle = col; g.beginPath(); g.moveTo(8 * u, 3.5 * u); g.lineTo(12 * u, 7 * u); g.lineTo(8 * u, 12 * u); g.lineTo(4 * u, 7 * u); g.closePath(); g.fill();
    circ(7, 6, 1, 'rgba(255,255,255,.7)');
  }
  // 사람 모양(플레이어·정착민) — (x, y)=발밑 화면 좌표, s=칸 크기(px)
  function drawHuman(g, x, y, s, o) {
    const dir = o.dir || 1, t = o.walk || 0, sw = Math.sin(t * 2.2) * (o.moving ? 0.5 : 0);
    const skin = o.skin || '#e8b890', shirt = o.shirt || '#4a7ac8', pants = o.pants || '#3a3a5a', hair = o.hair || '#4a3020';
    g.save(); g.translate(x, y); g.scale(dir, 1);
    const u = s / 8;
    if (o.hurt) g.globalAlpha = 0.6;
    // 다리
    g.fillStyle = pants; g.save(); g.translate(-0.8 * u, -8 * u); g.rotate(sw); g.fillRect(-1.2 * u, 0, 2.4 * u, 8 * u); g.restore();
    g.save(); g.translate(0.8 * u, -8 * u); g.rotate(-sw); g.fillRect(-1.2 * u, 0, 2.4 * u, 8 * u); g.restore();
    // 몸
    g.fillStyle = shirt; rr(g, -3 * u, -16.5 * u, 6 * u, 9 * u, 1.5 * u); g.fill();
    if (o.trim) { g.fillStyle = o.trim; g.fillRect(-3 * u, -9 * u, 6 * u, 1.2 * u); }
    // 머리
    g.fillStyle = skin; g.beginPath(); g.arc(0.3 * u, -19.5 * u, 3.4 * u, 0, TAU); g.fill();
    if (o.helm) { g.fillStyle = o.helm; g.beginPath(); g.arc(0.3 * u, -20 * u, 3.8 * u, Math.PI * 1.05, Math.PI * 2.05); g.fill(); g.fillRect(-3.4 * u, -20.5 * u, 7.4 * u, 1.4 * u); }
    else { g.fillStyle = hair; g.beginPath(); g.arc(0 * u, -20.5 * u, 3.5 * u, Math.PI * 0.95, Math.PI * 2.1); g.fill(); g.fillRect(-3.4 * u, -21 * u, 2 * u, 3.5 * u); }
    g.fillStyle = '#1a1420'; g.fillRect(1.8 * u, -20 * u, 0.9 * u, 1.2 * u);
    if (o.hat) { g.fillStyle = o.hat; g.fillRect(-3.8 * u, -23 * u, 8 * u, 1.4 * u); g.fillRect(-2.4 * u, -26 * u, 5 * u, 3.2 * u); }
    g.restore();
  }
  function drawHeld(g, it, hx, hy, ang, s, len) {
    if (!it) return;
    const ic = itemIcon(it.i, 32);
    g.save(); g.translate(hx, hy); g.rotate(ang + Math.PI / 4);
    const sz = s * (it.c === 'melee' || it.c === 'pick' || it.c === 'axe' || it.c === 'hammer' ? Math.max(1.6, (len || 1.8) * 0.85) : 1.2);
    g.drawImage(ic, -sz * 0.18, -sz * 0.82, sz, sz);
    g.restore();
  }
  function drawEnemy(g, e, E, x, y, s, t) {
    const w = e.w * s, h = e.h * s, col = E.col, dir = e.dir || 1;
    g.save(); g.translate(x, y);
    if (e.hurt) { g.globalAlpha = 0.75; }
    switch (E.ai) {
      case 'slime': { const sq = e.gnd !== false ? 1 + Math.sin(t * 6 + e.id) * 0.06 : 0.9; g.fillStyle = col; g.globalAlpha *= 0.88; g.beginPath(); g.ellipse(0, -h * 0.45 * sq, w * 0.52 / sq * 1, h * 0.5 * sq, 0, 0, TAU); g.fill(); g.globalAlpha = e.hurt ? 0.75 : 1; g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(-w * 0.18, -h * 0.68, w * 0.12, h * 0.12, 0, 0, TAU); g.fill(); g.fillStyle = '#1a1420'; g.fillRect(-w * 0.18 + dir * w * 0.08, -h * 0.55, w * 0.08, h * 0.14); g.fillRect(w * 0.1 + dir * w * 0.08, -h * 0.55, w * 0.08, h * 0.14); break; }
      case 'walk': case 'throw': case 'caster': {
        if (e.h > 2) { const o = { dir, walk: e.x * 2, moving: Math.abs(e.vx) > 0.5, skin: E.k === 'bminer' ? '#e8e0c8' : E.k === 'walker' || E.k === 'rwalker' ? shade(col, 0.2) : E.k === 'fiend' ? '#c8402a' : '#c8a080', shirt: E.k === 'bminer' ? '#5a4a3a' : shade(col, -0.2), pants: shade(col, -0.45), hair: '#222', helm: E.k === 'bminer' ? '#d8b850' : null, hat: E.k === 'rmage' ? '#3a2a6a' : null }; drawHuman(g, 0, 0, s * (e.h / 2.75), o); if (E.k === 'walker' || E.k === 'rwalker') { g.fillStyle = E.k === 'rwalker' ? '#ff3a3a' : '#e0f080'; g.fillRect(dir * s * 0.35 - 2, -h * 0.74, 3, 3); } if (E.k === 'fiend') { g.fillStyle = '#ffb040'; g.beginPath(); g.arc(dir * s * 0.6, -h * 0.55, s * 0.35, 0, TAU); g.fill(); } }
        else { // 게·전갈·거미
          g.fillStyle = col; g.beginPath(); g.ellipse(0, -h * 0.5, w * 0.45, h * 0.42, 0, 0, TAU); g.fill();
          g.strokeStyle = shade(col, -0.35); g.lineWidth = Math.max(1, s * 0.12);
          for (let k = 0; k < 3; k++) { const ph = Math.sin(t * 10 + k + e.x) * 0.15 * s; g.beginPath(); g.moveTo(-w * 0.2, -h * 0.4); g.lineTo(-w * 0.5 - k * 2, ph); g.moveTo(w * 0.2, -h * 0.4); g.lineTo(w * 0.5 + k * 2, -ph); g.stroke(); }
          if (E.k === 'scorp') { g.strokeStyle = col; g.lineWidth = s * 0.25; g.beginPath(); g.moveTo(-dir * w * 0.35, -h * 0.5); g.quadraticCurveTo(-dir * w * 0.7, -h * 1.6, dir * w * 0.0, -h * 1.4); g.stroke(); }
          if (E.k === 'cspider') { g.fillStyle = '#e8d8ff'; g.beginPath(); g.arc(dir * w * 0.3, -h * 0.6, s * 0.12, 0, TAU); g.fill(); }
          g.fillStyle = '#1a1420'; g.fillRect(dir * w * 0.28, -h * 0.75, 2, 2);
        }
        break;
      }
      case 'fly': case 'shoot': {
        const fl = Math.sin(t * 16 + e.id) * 0.5;
        if (E.k === 'harp') { drawHuman(g, 0, h * 0.4, s * 0.6, { dir, skin: '#e8d0b0', shirt: '#d8e8ff', pants: '#a8b8d8', hair: '#8a9ac8' }); g.fillStyle = '#e8f0ff'; g.beginPath(); g.ellipse(-w * 0.6, -h * 0.6 + fl * 4, w * 0.6, h * 0.18, -0.4 - fl * 0.4, 0, TAU); g.ellipse(w * 0.6, -h * 0.6 + fl * 4, w * 0.6, h * 0.18, 0.4 + fl * 0.4, 0, TAU); g.fill(); break; }
        if (E.k === 'sentry') { g.rotate(t * 2); g.fillStyle = col; g.beginPath(); g.moveTo(0, -h * 0.9); g.lineTo(w * 0.45, -h * 0.5); g.lineTo(0, -h * 0.1); g.lineTo(-w * 0.45, -h * 0.5); g.closePath(); g.fill(); g.fillStyle = '#fff'; g.beginPath(); g.arc(0, -h * 0.5, s * 0.2, 0, TAU); g.fill(); break; }
        if (E.k === 'wasp') { g.fillStyle = '#e8e040'; g.beginPath(); g.ellipse(0, -h * 0.5, w * 0.45, h * 0.3, 0, 0, TAU); g.fill(); g.fillStyle = '#222'; g.fillRect(-w * 0.1, -h * 0.78, w * 0.12, h * 0.56); g.fillRect(w * 0.15, -h * 0.75, w * 0.1, h * 0.5); g.fillStyle = 'rgba(255,255,255,.7)'; g.beginPath(); g.ellipse(0, -h * 0.9 + fl * 3, w * 0.35, h * 0.15, 0, 0, TAU); g.fill(); break; }
        if (E.k === 'icesp') { g.fillStyle = 'rgba(160,232,255,.85)'; g.beginPath(); g.moveTo(0, -h); g.lineTo(w * 0.4, -h * 0.4); g.lineTo(0, 0); g.lineTo(-w * 0.4, -h * 0.4); g.closePath(); g.fill(); g.fillStyle = '#fff'; g.fillRect(-2, -h * 0.6, 4, 4); break; }
        if (E.k === 'gazelet') { g.fillStyle = '#e8e0f0'; g.beginPath(); g.arc(0, -h * 0.5, w * 0.45, 0, TAU); g.fill(); g.fillStyle = col; g.beginPath(); g.arc(dir * w * 0.12, -h * 0.5, w * 0.24, 0, TAU); g.fill(); g.fillStyle = '#111'; g.beginPath(); g.arc(dir * w * 0.16, -h * 0.5, w * 0.1, 0, TAU); g.fill(); break; }
        // 박쥐
        g.fillStyle = col; g.beginPath(); g.ellipse(0, -h * 0.5, w * 0.22, h * 0.32, 0, 0, TAU); g.fill();
        g.beginPath(); g.moveTo(-w * 0.15, -h * 0.55); g.lineTo(-w * 0.75, -h * (0.9 + fl * 0.4)); g.lineTo(-w * 0.5, -h * 0.35); g.closePath(); g.moveTo(w * 0.15, -h * 0.55); g.lineTo(w * 0.75, -h * (0.9 + fl * 0.4)); g.lineTo(w * 0.5, -h * 0.35); g.closePath(); g.fill();
        g.fillStyle = E.k === 'nbat' ? '#ff5050' : E.k === 'fbat' ? '#ffe080' : '#e8e8a0'; g.fillRect(-3, -h * 0.62, 2, 2); g.fillRect(1, -h * 0.62, 2, 2);
        break;
      }
      case 'swim': { g.scale(dir, 1); g.fillStyle = col; g.beginPath(); g.ellipse(0, -h * 0.5, w * 0.5, h * 0.42, 0, 0, TAU); g.fill(); g.beginPath(); g.moveTo(-w * 0.45, -h * 0.5); g.lineTo(-w * 0.8, -h * 0.9); g.lineTo(-w * 0.8, -h * 0.1); g.closePath(); g.fill(); g.fillStyle = '#fff'; for (let k = 0; k < 4; k++) g.fillRect(w * 0.15 + k * w * 0.07, -h * 0.4, 2, 3); g.fillStyle = '#111'; g.fillRect(w * 0.22, -h * 0.7, 2, 2); break; }
    }
    g.restore();
  }
  function drawBoss(g, B, toS, s, t) {
    const D = BOSS[B.b];
    g.save();
    if (B.hurt) g.globalAlpha = 0.8;
    if (B.b === 0) { const [x, y] = toS(B.x, B.y); const w = D.w * s, h = D.h * s; g.fillStyle = 'rgba(74,154,255,.86)'; g.beginPath(); g.ellipse(x, y - h * 0.48, w * 0.55, h * 0.5, 0, 0, TAU); g.fill(); g.fillStyle = '#f2c844'; g.beginPath(); g.moveTo(x - w * 0.2, y - h * 0.92); g.lineTo(x - w * 0.2, y - h * 1.2); g.lineTo(x - w * 0.08, y - h * 1.05); g.lineTo(x, y - h * 1.28); g.lineTo(x + w * 0.08, y - h * 1.05); g.lineTo(x + w * 0.2, y - h * 1.2); g.lineTo(x + w * 0.2, y - h * 0.92); g.closePath(); g.fill(); g.fillStyle = '#1a1420'; g.fillRect(x - w * 0.18, y - h * 0.6, s * 0.4, s * 0.6); g.fillRect(x + w * 0.1, y - h * 0.6, s * 0.4, s * 0.6); g.fillStyle = 'rgba(255,255,255,.3)'; g.beginPath(); g.ellipse(x - w * 0.25, y - h * 0.75, w * 0.1, h * 0.08, -0.5, 0, TAU); g.fill(); }
    else if (B.b === 1) { const [x, y] = toS(B.x, B.y); const r = D.w * s * 0.5; const a = B.ang || 0; g.fillStyle = '#e8e0f0'; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); g.strokeStyle = '#c84a6a'; g.lineWidth = 2; for (let k = 0; k < 6; k++) { g.beginPath(); g.moveTo(x + Math.cos(a + 2.4 + k * 0.3) * r * 0.9, y + Math.sin(a + 2.4 + k * 0.3) * r * 0.9); g.lineTo(x + Math.cos(a + 2.5 + k * 0.3) * r * 0.4, y + Math.sin(a + 2.5 + k * 0.3) * r * 0.4); g.stroke(); } g.fillStyle = B.ph === 2 ? '#c8304a' : D.col; g.beginPath(); g.arc(x + Math.cos(a) * r * 0.4, y + Math.sin(a) * r * 0.4, r * 0.48, 0, TAU); g.fill(); g.fillStyle = '#100818'; g.beginPath(); g.arc(x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55, r * 0.22, 0, TAU); g.fill(); if (B.ph === 2) { g.fillStyle = '#e8e0f0'; for (let k = 0; k < 5; k++) { const aa = a + Math.PI + (k - 2) * 0.3; g.beginPath(); g.moveTo(x + Math.cos(aa) * r * 0.9, y + Math.sin(aa) * r * 0.9); g.lineTo(x + Math.cos(aa) * r * 1.5, y + Math.sin(aa) * r * 1.5); g.lineWidth = 3; g.strokeStyle = '#c8b8d8'; g.stroke(); } } }
    else if (B.b === 2) { const segs = B.seg || []; for (let k = segs.length - 1; k >= 0; k--) { const [x, y] = toS(segs[k][0], segs[k][1]); const r = s * (k === segs.length - 1 ? 0.8 : 1.15); g.fillStyle = k % 2 ? '#7a7a5c' : '#8a8a6a'; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); g.strokeStyle = '#4a4a38'; g.lineWidth = 2; g.stroke(); g.fillStyle = '#a8a888'; g.fillRect(x - r * 0.15, y - r * 0.9, r * 0.3, r * 0.5); } const [hx, hy] = toS(B.x, B.y); const a = B.ang || 0; g.save(); g.translate(hx, hy); g.rotate(a); g.fillStyle = '#9a9a72'; g.beginPath(); g.arc(0, 0, s * 1.5, 0, TAU); g.fill(); g.fillStyle = '#5a5a40'; g.beginPath(); g.moveTo(s * 1.2, -s * 0.9); g.lineTo(s * 2.4, -s * 0.4); g.lineTo(s * 1.4, -s * 0.1); g.closePath(); g.moveTo(s * 1.2, s * 0.9); g.lineTo(s * 2.4, s * 0.4); g.lineTo(s * 1.4, s * 0.1); g.closePath(); g.fill(); g.fillStyle = '#ff5a3a'; g.fillRect(s * 0.4, -s * 0.6, s * 0.35, s * 0.35); g.fillRect(s * 0.4, s * 0.25, s * 0.35, s * 0.35); g.restore(); }
    else if (B.b === 3) { const [x, y] = toS(B.x, B.y); const r = s * 2.2; g.save(); g.translate(x, y); if (B.ph === 2) g.rotate((t * 9) % TAU); g.fillStyle = D.col; g.beginPath(); g.arc(0, -r * 0.1, r, 0, TAU); g.fill(); g.fillRect(-r * 0.6, r * 0.5, r * 1.2, r * 0.6); g.fillStyle = '#1a1018'; g.beginPath(); g.arc(-r * 0.38, 0, r * 0.28, 0, TAU); g.arc(r * 0.38, 0, r * 0.28, 0, TAU); g.fill(); g.fillStyle = '#ff4a3a'; g.beginPath(); g.arc(-r * 0.38, 0, r * 0.1, 0, TAU); g.arc(r * 0.38, 0, r * 0.1, 0, TAU); g.fill(); g.fillStyle = '#1a1018'; for (let k = 0; k < 4; k++) g.fillRect(-r * 0.45 + k * r * 0.28, r * 0.6, r * 0.12, r * 0.35); g.restore(); for (const hd of B.hands || []) { const [hx, hy] = toS(hd.x, hd.y); g.fillStyle = '#d8d0b8'; g.beginPath(); g.arc(hx, hy, s * 1.3, 0, TAU); g.fill(); g.fillStyle = '#b8b098'; for (let k = 0; k < 4; k++) g.fillRect(hx - s * 1.1 + k * s * 0.6, hy + s * 0.6, s * 0.35, s * 1); if (hd.st === 1) { g.strokeStyle = 'rgba(255,80,60,.6)'; g.setLineDash([5, 5]); g.beginPath(); g.moveTo(hx, hy); g.lineTo(hx, hy + s * 12); g.stroke(); g.setLineDash([]); } } }
    else if (B.b === 4) { const [x, y] = toS(B.x, B.y); const r = s * 2.3, rot = B.ang || 0; const gr = g.createRadialGradient(x, y, r * 0.2, x, y, r * 1.6); gr.addColorStop(0, '#fff2a0'); gr.addColorStop(0.35, '#ff8a20'); gr.addColorStop(1, 'rgba(255,60,10,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r * 1.6, 0, TAU); g.fill(); g.fillStyle = '#3a1a10'; for (let k = 0; k < 6; k++) { const a = rot + k * TAU / 6; g.beginPath(); g.moveTo(x + Math.cos(a) * r * 0.8, y + Math.sin(a) * r * 0.8); g.lineTo(x + Math.cos(a + 0.25) * r * 1.4, y + Math.sin(a + 0.25) * r * 1.4); g.lineTo(x + Math.cos(a + 0.5) * r * 0.8, y + Math.sin(a + 0.5) * r * 0.8); g.closePath(); g.fill(); } g.fillStyle = B.ph === 2 ? '#fff' : '#ffd27a'; g.beginPath(); g.arc(x, y, r * 0.5, 0, TAU); g.fill(); }
    else if (B.b === 5) { const [x, y] = toS(B.x, B.y); const h = D.h * s, w = D.w * s; g.fillStyle = 'rgba(200,184,255,.25)'; g.beginPath(); g.arc(x, y, w * 1.1, 0, TAU); g.fill(); g.fillStyle = '#2a2050'; g.beginPath(); g.moveTo(x, y - h * 0.55); g.lineTo(x + w * 0.5, y + h * 0.5); g.lineTo(x - w * 0.5, y + h * 0.5); g.closePath(); g.fill(); g.fillStyle = D.col; g.beginPath(); g.arc(x, y - h * 0.45, w * 0.3, 0, TAU); g.fill(); g.fillStyle = '#fff'; g.fillRect(x - w * 0.15, y - h * 0.48, w * 0.1, w * 0.1); g.fillRect(x + w * 0.05, y - h * 0.48, w * 0.1, w * 0.1); for (let k = 0; k < 5; k++) { const a = t * 1.6 + k * TAU / 5; g.fillStyle = '#e8dcff'; g.beginPath(); g.arc(x + Math.cos(a) * w * 0.9, y + Math.sin(a) * w * 0.5, s * 0.3, 0, TAU); g.fill(); } }
    g.restore();
  }

  /* ======================= 글·도움말 ======================= */
  const CATN = { block: '블록', wall: '벽', pick: '곡괭이', axe: '도끼', hammer: '망치', melee: '근접 무기', ranged: '원거리 무기', magic: '마법 무기', summon: '소환 무기', armor: '갑옷', acc: '장신구', potion: '물약', mat: '재료', ammo: '화살', furn: '가구', light: '빛', boss: '보스 부르기', misc: '쓰는 물건', coin: '돈' };
  function itemLines(it) {
    const L2 = [];
    if (it.dmg && it.c !== 'ammo') L2.push('피해 ' + it.dmg + (it.c === 'summon' ? ' (소환수)' : '') + (it.ut ? ' · 사용 ' + it.ut + '초' : '') + (it.kb ? ' · 밀치기 ' + it.kb : ''));
    if (it.c === 'ammo') L2.push('화살 피해 +' + it.dmg + (it.fire ? ' · 불붙임' : '') + (it.pierce ? ' · 꿰뚫기 ' + it.pierce : ''));
    if (it.pk) L2.push('곡괭이 힘 ' + it.pk); if (it.ax) L2.push('도끼 힘 ' + it.ax); if (it.hm) L2.push('망치 힘 ' + it.hm + ' (벽 떼기)');
    if (it.mana) L2.push('마나 ' + it.mana); if (it.ammo) L2.push('화살을 써요'); if (it.multi) L2.push(it.multi + '발씩');
    if (it.c === 'armor') { L2.push('방어 ' + it.def); const S = SETS[it.set]; if (S) L2.push('세트(' + S.n + ' 3부위): ' + S.sb); }
    if (it.d) L2.push(it.d);
    if (it.pl && it.c !== 'mat' && it.c !== 'block' && it.c !== 'furn' && it.c !== 'light') L2.push('놓을 수 있어요');
    return L2;
  }
  function sourcesOf(id) { // 얻는 곳
    const out = [];
    for (const T of TL) if (T.dr && IX[T.dr] === id && T.k !== 'air') out.push('캐기: ' + T.n);
    for (const E of EN) for (const d of E.dr) if (IX[d[0]] === id) out.push('처치: ' + E.n + ' (' + Math.round(d[3] * 100) + '%)');
    for (const B of BOSS) for (const d of B.dr) if (IX[d[0]] === id) out.push('보스: ' + B.n);
    for (const N2 of NPC) for (const s of N2.shop) if (IX[s[0]] === id) out.push('가게: ' + N2.n + ' (' + s[1] + '동전)');
    if (RC.some((r) => r.o === id)) out.push('제작');
    const k = IT[id].k;
    if (['run_boots', 'mirror', 'claw', 'gill_c', 'boomer', 'lava_c', 'regen_b', 'arcane_f'].includes(k)) out.push('동굴 상자');
    if (['cloud_jar', 'feather_c', 'starc'].includes(k)) out.push('하늘섬 상자');
    if (k === 'stard') out.push('밤하늘에서 떨어짐'); if (k === 'coin') out.push('적 · 항아리 · 상자');
    if (k === 'acorn') out.push('나무 베기');
    return out;
  }
  const NPC_TALK = {
    guide: (W2, p) => {
      const has = (k) => countItem(p.inv, IX[k]) > 0;
      if (!has('wbench') && countItem(p.inv, IX.wood) < 10) return '나무를 도끼로 베어 나무 10개를 모아 보세요. 작업대를 만들 수 있어요.';
      if (has('wbench')) return '작업대를 땅에 놓고 그 곁에서 가방(E)을 열면 만들 수 있는 것이 나와요.';
      if (!p.arm.some((a) => a)) return '돌 20개로 화로를, 흑철 주괴 5개로 모루를 만들면 금속 장비를 만들 수 있어요.';
      return ['밤에는 위험해요. 벽·문·횃불·탁자·의자가 있는 집을 지으면 정착민이 이사 와요.', '깊이 내려갈수록 좋은 광석이 나와요. 곡괭이 힘이 모자라면 캐지 못해요.', '생명 수정은 깊은 동굴에서 분홍빛으로 빛나요. 쓰면 최대 체력이 늘어요.', '「📖 레시피 책」(B)에서 물건 이름을 누르면 어디서 얻는지 알려 줘요.', '보스를 부르는 물건은 레시피 책 「보스」 칸에 있어요.'][Math.floor(performance.now() / 6000) % 5];
    },
    merch: () => '필요한 거 있어요? 횃불·화살·병은 늘 있어요. 쓸모없는 물건은 오른쪽 클릭으로 팔아요.',
    smith: () => '광석이 모자라면 사 가요. 좋은 곡괭이가 있어야 더 깊은 광석을 캐요.',
    alch: () => '약초는 땅 위·밀림·눈 지역·사막·지하세계에서 자라요. 연금대에서 물약을 만들어요.',
    healer: (W2, p) => (p.hp < p.hpM ? '다쳤군요. 동전 ' + healCost(p) + '개면 다 낫게 해 드려요.' : '건강해 보이네요.'),
    archer: () => '화살은 많을수록 좋죠. 불화살은 횃불만 있으면 만들어요.',
    mage: () => '별가루 다섯 개면 마나 수정이 돼요. 밤하늘을 잘 보세요.',
    explore: () => '하늘섬에는 귀한 상자가 있어요. 구름 블록을 쌓아 올라가 보세요.',
    tinkr: () => '장신구 두 개를 합치면 더 좋아져요. 세공대에서요.',
  };
  function healCost(p) { return Math.ceil((p.hpM - p.hp) * 0.6); }
  const CSS = `
  .sb-book{position:absolute;inset:4% 6%;background:rgba(18,14,26,.96);border:2px solid #e3ae45;border-radius:14px;z-index:40;display:flex;flex-direction:column;font-family:${BODY};color:#f2e9d8;}
  .sb-book .hd{display:flex;gap:8px;align-items:center;padding:10px 12px;border-bottom:1px solid rgba(255,255,255,.12);flex-wrap:wrap}
  .sb-book h3{margin:0 8px 0 0;font-family:"Black Han Sans",${BODY};font-weight:400;font-size:20px;color:#e3ae45}
  .sb-book input{flex:1;min-width:160px;height:40px;border-radius:8px;border:1px solid #6a5a80;background:#221c2e;color:#f2e9d8;padding:0 10px;font-size:15px}
  .sb-book .chips{display:flex;gap:6px;flex-wrap:wrap;padding:8px 12px}
  .sb-book button{min-height:40px;min-width:44px;border-radius:8px;border:1px solid #6a5a80;background:#2e2640;color:#f2e9d8;padding:0 10px;font-size:13px;cursor:pointer;font-family:${BODY}}
  .sb-book button.on{background:#e3ae45;color:#17131f;border-color:#e3ae45}
  .sb-book .list{flex:1;overflow:auto;padding:6px 12px 12px}
  .sb-book .row{display:flex;gap:10px;align-items:center;padding:6px 4px;border-bottom:1px solid rgba(255,255,255,.07)}
  .sb-book .row img{width:36px;height:36px;image-rendering:pixelated;background:#2e2640;border-radius:6px;padding:2px}
  .sb-book .nm{font-weight:700;min-width:140px;cursor:pointer}
  .sb-book .ins{flex:1;font-size:13px;color:#cfc4dc;line-height:1.6}
  .sb-book .ins span{cursor:pointer;text-decoration:underline dotted;margin-right:8px;white-space:nowrap}
  .sb-book .ins span.ok{color:#9ae07a}.sb-book .ins span.no{color:#ee8a6a}
  .sb-book .at{font-size:12px;color:#e3ae45;min-width:84px}
  .sb-book .src{padding:8px 12px;font-size:13px;color:#cfc4dc;border-top:1px solid rgba(255,255,255,.12);min-height:22px}
  `;

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS }); root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    cv.cv.style.cursor = 'crosshair';
    const auto = () => !!(L.debug && L.debug.autoplay);
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isBot = (s) => host() && (!!P(s).ai || (auto() && localHuman(s)));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const COL = (s) => P(s).color || ['#e8c547', '#4fb3e8', '#e8664f', '#7ad46a'][s % 4];
    const kl = (id) => { try { return L.ui && L.ui.keyLabel ? L.ui.keyLabel('sandbox', id) : ''; } catch (e) { return ''; } };
    const uiK = () => clamp(Math.min(cv.w / 1280, cv.h / 720), 0.8, 2) * ((L.ui && L.ui.scale && L.ui.scale()) || 1);
    let st = null, G = null, W = null, key = '', me = -1, my = null, genPending = 0;
    const V = { en: [], boss: null, pj: [], dr: [], npcs: [], P: [], tm: 0.2, day: 1, ev: 0, fl: null };
    const Cs = {}, botMem = {};
    let acc = 0;
    function mySeat() { if (!st) return -1; if (auto()) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }

    /* ----- 소리 ----- */
    const Snd = {
      ac: null, out: null, nb: null, last: {},
      ctx() { if (auto()) return null; const v = L.audio ? L.audio.sfx() : 1; if (!v) return null; try { if (!this.ac) { this.ac = new (window.AudioContext || window.webkitAudioContext)(); this.out = this.ac.createGain(); this.out.connect(this.ac.destination); const n = this.ac.sampleRate; this.nb = this.ac.createBuffer(1, n, n); const d = this.nb.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; } this.out.gain.value = 0.45 * v; if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
      noise(dur, f0, f1, vol, type) { const a = this.ctx(); if (!a) return; const t = a.currentTime, s = a.createBufferSource(); s.buffer = this.nb; const f = a.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur); const g = a.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); s.connect(f); f.connect(g); g.connect(this.out); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05); },
      tone(f0, f1, dur, vol, type) { const a = this.ctx(); if (!a) return; const t = a.currentTime, o = a.createOscillator(); o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur); const g = a.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); o.connect(g); g.connect(this.out); o.start(t); o.stop(t + dur + 0.05); },
      gap(k, ms) { const n = performance.now(); if (this.last[k] && n - this.last[k] < ms) return false; this.last[k] = n; return true; },
      play(k, tt) {
        if (!this.gap(k, k === 'chip' ? 45 : 30)) return;
        const soft = tt !== undefined && (tt === T_.dirt || tt === T_.grass || tt === T_.sand || tt === T_.mud || tt === T_.jgrass || tt === T_.snow || tt === T_.clay);
        switch (k) {
          case 'chip': if (soft) this.noise(0.07, 900, 300, 0.22); else { this.noise(0.05, 4200, 1200, 0.2, 'bandpass'); this.tone(700 + Math.random() * 200, 400, 0.04, 0.08, 'square'); } break;
          case 'broke': this.noise(soft ? 0.14 : 0.18, soft ? 700 : 2600, 150, 0.32); this.tone(soft ? 160 : 320, 80, 0.1, 0.12, 'triangle'); break;
          case 'place': this.noise(0.06, 600, 200, 0.25); this.tone(180, 90, 0.06, 0.15, 'triangle'); break;
          case 'swing': this.noise(0.12, 1800, 500, 0.12, 'bandpass'); break;
          case 'hit': this.noise(0.08, 1400, 300, 0.25); this.tone(220, 110, 0.07, 0.15, 'square'); break;
          case 'shoot': this.tone(900, 300, 0.09, 0.12, 'triangle'); break;
          case 'magic': this.tone(600, 1400, 0.16, 0.1, 'sine'); this.tone(900, 2000, 0.12, 0.05, 'triangle'); break;
          case 'jump': this.tone(300, 520, 0.08, 0.05, 'sine'); break;
          case 'land': this.noise(0.08, 500, 100, 0.18); break;
          case 'hurt': this.tone(300, 120, 0.18, 0.2, 'sawtooth'); break;
          case 'pick': this.tone(880, 1320, 0.06, 0.07, 'sine'); break;
          case 'drink': this.tone(400, 800, 0.2, 0.1, 'sine'); break;
          case 'roar': this.noise(0.6, 400, 80, 0.4); this.tone(90, 50, 0.6, 0.3, 'sawtooth'); break;
          case 'pj': this.tone(500, 250, 0.1, 0.06, 'square'); break;
          case 'clank': this.tone(1500, 1200, 0.05, 0.08, 'square'); break;
          case 'boom': this.noise(0.8, 900, 50, 0.6); this.tone(70, 30, 0.7, 0.4); break;
        }
      },
      close() { try { if (this.ac) this.ac.close(); } catch (e) { /* closed */ } this.ac = null; },
    };

    /* ----- 효과 (이 기기에서만) ----- */
    let ptc = [], nums = [], vis = [], msgs = [], shake = 0, hurtA = 0, banner = null, pickups = [], toastT = {};
    const toast = (t) => { try { api.toast(t); } catch (e) { /* */ } };
    const toastOnce = (t) => { const n = performance.now(); if (toastT[t] && n - toastT[t] < 3000) return; toastT[t] = n; toast(t); };
    function addP(x, y, n, c, sp, life, sz, g2) { for (let k = 0; k < n; k++) { const a = Math.random() * TAU, v = sp * (0.3 + Math.random()); ptc.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - sp * 0.4, t: 0, l: life * (0.6 + Math.random() * 0.8), c, s: sz * (0.5 + Math.random()), g: g2 === undefined ? 30 : g2 }); } if (ptc.length > 700) ptc.splice(0, ptc.length - 700); }
    const tileCol = (tt) => (TL[tt] && (TL[tt].top && Math.random() < 0.4 ? TL[tt].top : TL[tt].col)) || '#888';
    const near = (x, y) => Math.abs(x - cam.x) < 50 && Math.abs(y - cam.y) < 32;
    function localFx(seat, type, a) {
      const mine = seat === me;
      switch (type) {
        case 'chip': { const [tx, ty, wall, tt] = a; addP(tx + 0.5, ty + 0.5, 3, wall ? '#6a5a50' : tileCol(tt), 6, 0.4, 0.18); if (mine || near(tx, ty)) Snd.play('chip', tt); break; }
        case 'broke': { const [tx, ty, wall, tt] = a; addP(tx + 0.5, ty + 0.5, 10, wall ? '#6a5a50' : tileCol(tt), 9, 0.6, 0.22); if (mine || near(tx, ty)) Snd.play('broke', tt); break; }
        case 'place': { const [tx, ty] = a; addP(tx + 0.5, ty + 0.9, 4, 'rgba(220,210,190,.7)', 3, 0.3, 0.15, 0); if (mine) Snd.play('place'); break; }
        case 'swing': if (mine) Snd.play('swing'); break;
        case 'shoot': if (mine) Snd.play('shoot'); break;
        case 'magic': if (mine) Snd.play('magic'); break;
        case 'jump': if (mine) Snd.play('jump'); { const p = a[0]; addP(p.x, p.y, 3, 'rgba(220,210,190,.6)', 3, 0.3, 0.15, 0); } break;
        case 'dj': { const p = a[0]; addP(p.x, p.y, 10, 'rgba(240,245,255,.8)', 5, 0.45, 0.25, -2); if (mine) Snd.play('jump'); break; }
        case 'land': { const p = a[0]; addP(p.x, p.y, Math.min(10, a[1] / 4 | 0), 'rgba(220,210,190,.6)', 4, 0.35, 0.18, 0); if (mine && a[1] > 26) Snd.play('land'); break; }
        case 'ph': { const p = a[0]; if (mine) { hurtA = 0.5; Snd.play('hurt'); shake = Math.max(shake, 4); try { api.buzz(40); } catch (e) { /* */ } } nums.push({ x: p.x, y: p.y - p.h, v: a[1], t: 0, c: '#ff6a5a' }); addP(p.x, p.y - 1.2, 5, '#c83a3a', 6, 0.4, 0.15); break; }
        case 'die': { const p = a[0]; if (mine) { msg('쓰러졌어요 — ' + (a[1] || ''), '#ff8a7a'); try { api.sfx('lose'); } catch (e) { /* */ } } addP(p.x, p.y - 1.3, 24, '#c83a3a', 9, 0.9, 0.22); break; }
        case 'hit': { const e = a[0]; addP(e.x, e.y - e.h / 2, 4, '#ffe0a0', 7, 0.25, 0.14, 0); if (mine) Snd.play('hit'); break; }
        case 'hitB': if (mine) Snd.play('hit'); break;
        case 'drink': { const p = a[0]; addP(p.x, p.y - 1.6, 10, IT[a[1]].col || '#fff', 3, 0.7, 0.2, -6); if (mine) Snd.play('drink'); break; }
        case 'tp': { const p = a[0]; addP(p.x, p.y - 1.3, 20, '#c8b8ff', 6, 0.7, 0.2, -3); break; }
        case 'summon': { const p = a[0]; addP(p.x, p.y - 2, 12, '#9ad8ff', 5, 0.6, 0.2, -3); if (mine) Snd.play('magic'); break; }
        case 'craft': if (mine) { Snd.play('pick'); } break;
        case 'pjhit': { const q = a[0]; addP(q.x, q.y, 4, q.k === 'fire' ? '#ff8a30' : '#e8e0d0', 5, 0.3, 0.12); break; }
        case 'clank': if (mine) Snd.play('clank'); break;
      }
    }
    function msg(t, c) { msgs.push({ t, c: c || '#f2e9d8', a: 8 }); if (msgs.length > 7) msgs.shift(); }
    let lastFx = 0;
    function onFx(e) {
      const k = e[1];
      switch (k) {
        case 'm': msg(e[2], e[3]); break;
        case 'g': if (e[2] === me && e[4] > 0) pickups.push({ id: e[3], n: e[4], t: 0 }); break;
        case 'dn': nums.push({ x: e[2], y: e[3], v: e[4], t: 0, c: e[5] ? '#ffb040' : '#fff2c8', big: e[5] }); break;
        case 'pf': { const E = EN[e[4]]; addP(e[2], e[3], 14, E ? E.col : '#ccc', 8, 0.6, 0.2); break; }
        case 'pt': addP(e[2] + 0.5, e[3] + 0.5, 12, '#9a6040', 8, 0.6, 0.2); Snd.play('broke', T_.stone); break;
        case 'tp': addP(e[2], e[3], 16, '#a07aff', 6, 0.6, 0.18, -2); addP(e[4], e[5], 16, '#a07aff', 6, 0.6, 0.18, -2); break;
        case 'shake': shake = Math.max(shake, e[2] * ((L.fx && L.fx()) ?? 1)); break;
        case 'dust': addP(e[2], e[3], e[4] * 5, 'rgba(160,140,120,.8)', 8, 0.8, 0.3, 4); break;
        case 'boom': addP(e[2], e[3], 80, BOSS[e[4]].col, 14, 1.4, 0.35, 6); addP(e[2], e[3], 40, '#fff2c8', 10, 1, 0.25, 0); Snd.play('boom'); break;
        case 'boss': banner = { t: BOSS[e[2]].n, sub: BOSS[e[2]].title, a: 3.5 }; Snd.play('roar'); try { api.sfx('warn'); } catch (er) { /* */ } break;
        case 'snd': if (e[2] === 'win' || e[2] === 'warn') { try { api.sfx(e[2]); } catch (er) { /* */ } } else Snd.play(e[2]); break;
        case 'sh': if (e[2] !== me) { vis.push({ k: e[3], x: e[4], y: e[5], vx: e[6], vy: e[7], t: 0, g: e[3] === 'arrow' ? 18 : 0 }); if (vis.length > 120) vis.shift(); } break;
      }
    }

    /* ----- 문맥(C) 만들기 ----- */
    let aseq = 0, outbox = [];
    function doAct(seat, a) {
      if (host()) { if (G) hostAction(G, seat, a); }
      else { aseq++; outbox.push([aseq, a]); if (outbox.length > 60) outbox.shift(); }
    }
    function makeC(seat) {
      return {
        W, host: host(), dif: st.dif, dmul: [0.7, 1, 1.5][st.dif] || 1, act: (a) => doAct(seat, a),
        en: () => V.en, boss: () => V.boss, hpj: () => V.pj, fx: (type, ...a) => localFx(seat, type, a), pjs: [], mn: [], mine: new Map(),
        toast: (t) => { if (seat === me) toast(t); }, toastOnce: (t) => { if (seat === me) toastOnce(t); }, isDay: () => V.tm < NIGHT0, bossOn: () => !!V.boss, gfake: { W },
        ents: () => V.P.filter((p) => p && !p.dead).concat(V.en),
      };
    }

    /* ----- 세계 시작 ----- */
    let atlas = null, atlasTS = 0, mapCv = null, mapImg = null, seen = null, mapDirty = 0, applied = 0, lastG = 0, ivApplied = 0, demoEnd = 0;
    function startWorld() {
      key = st.rid + ':' + st.seed;
      me = mySeat();
      const t0 = performance.now();
      if (host()) {
        G = newGame(st); W = G.W; G.noLog = !api.online; G.ack = {}; G.eaOf = {}; G.open = {};
        G.P = [];
        for (let s = 0; s < st.np; s++) {
          if (localHuman(s) || isBot(s)) { const p = newPlayer(s, W); p.local = 1; p.nm = st.nm[s]; G.P[s] = p; Cs[s] = makeC(s); }
          else G.P[s] = { s, local: 0, x: W.spawn.x, y: W.spawn.y, w: PW, h: PH, dir: 1, dead: 0, hp: 100, hpM: 100, inv: null, arm: [], fresh: 1 };
        }
        V.en = G.en; V.pj = G.pj; V.dr = G.dr; V.npcs = G.npcs; V.P = G.P;
      } else {
        W = genWorld(st.seed, st.sz); W.lqAct = new Set();
        G = null; V.P = [];
        if (me >= 0) { my = newPlayer(me, W); my.local = 1; V.P[me] = my; Cs[me] = makeC(me); }
      }
      if (host() && me >= 0) my = G.P[me];
      mapCv = mkCanvas(W.w, W.h); mapImg = mapCv.getContext('2d').createImageData(W.w, W.h); seen = new Uint8Array(W.w * W.h);
      for (let i = 0; i < W.w * W.h; i++) { const y = (i / W.w) | 0; if (y < W.surf[i % W.w] + 2) seen[i] = 1; mapPix(i); }
      mapDirty = 1;
      cam.x = W.spawn.x; cam.y = W.spawn.y - 3;
      genMs = performance.now() - t0;
      demoEnd = 0;
      msg('세계를 만들었어요 — ' + SIZES[st.sz].n + ' (' + W.w + '×' + W.h + ')', '#ab9fb8');
      if (me >= 0) msg('E 가방·제작 · B 레시피 책 · 마우스 왼쪽 캐기/공격 · 오른쪽 열기/말 걸기', '#e3ae45');
    }
    let genMs = 0;
    function mapPix(i) {
      if (!mapImg) return;
      const d = mapImg.data, o = i * 4;
      if (!seen[i]) { d[o] = 10; d[o + 1] = 8; d[o + 2] = 14; d[o + 3] = 255; return; }
      const tt = W.t[i]; let c = null;
      if (tt) c = TL[tt].top && !W.t[i - W.w] ? TL[tt].top : TL[tt].col || '#e0c070';
      else if (W.lq[i]) c = W.lq[i] & 16 ? '#ff6a20' : '#3a6ac8';
      else if (W.wl[i]) c = shade(WL[W.wl[i]].col, -0.2);
      else { const y = (i / W.w) | 0; c = y >= W.hellTop ? '#3a1410' : y < W.surf[i % W.w] + 4 ? '#7ab4e8' : '#2a2026'; }
      const n = parseInt(c.slice(1, 7), 16) || 0; d[o] = n >> 16; d[o + 1] = (n >> 8) & 255; d[o + 2] = n & 255; d[o + 3] = 255;
    }
    function reveal(px, py, r) { const x0 = Math.max(0, Math.floor(px - r)), x1 = Math.min(W.w - 1, Math.ceil(px + r)), y0 = Math.max(0, Math.floor(py - r)), y1 = Math.min(W.h - 1, Math.ceil(py + r)); for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) { const i = y * W.w + x; if (seen[i]) continue; if ((x - px) * (x - px) + (y - py) * (y - py) > r * r) continue; seen[i] = 1; mapPix(i); mapDirty = 1; } }

    /* ----- 입력 ----- */
    const mouse = { x: -1, y: -1, l: 0, r: 0, on: 0, down: 0, dragFrom: null };
    const edges = {};
    const offIn = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      edges[id] = 1;
      if (id === 'inv') { if (ui.book) closeBook(); ui.inv = !ui.inv; if (!ui.inv) closePanels(); api.sfx('click'); }
      else if (id === 'map') ui.map = !ui.map;
      else if (id === 'book') { if (ui.book) closeBook(); else openBook(); }
      else if (id === 'zin') zoomI = clamp(zoomI + 1, 0, ZOOMS.length - 1);
      else if (id === 'zout') zoomI = clamp(zoomI - 1, 0, ZOOMS.length - 1);
      else if (id === 'heal') quickHeal();
      else if (id === 'house') houseQuery();
      else if (id === 'throw') throwHeld();
      else if (/^h\d+$/.test(id) && my && !ui.book) { my.sel = (+id.slice(1) + 9) % 10; }
    }) : null;
    const held = (id) => { try { return api.input && api.input.held ? api.input.held(id) : false; } catch (e) { return false; } };
    const axis = (a, b) => { try { return api.input && api.input.axis ? api.input.axis(a, b) : 0; } catch (e) { return 0; } };
    const ZOOMS = [0.7, 0.85, 1, 1.2, 1.45]; let zoomI = 2;
    const cam = { x: 0, y: 0 };
    let TS = 16;
    const toW = (sx, sy) => [cam.x + (sx - cv.w / 2) / TS, cam.y + (sy - cv.h / 2) / TS];
    const toS = (wx, wy) => [(wx - cam.x) * TS + cv.w / 2, (wy - cam.y) * TS + cv.h / 2];
    function onMove(e) { const p = cv.local(e); mouse.x = p.x; mouse.y = p.y; mouse.on = 1; }
    function onDown(e) {
      const p = cv.local(e); mouse.x = p.x; mouse.y = p.y; mouse.on = 1;
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) { /* */ }
      if (Snd.ctx) Snd.ctx();
      const btn = e.button === 2 ? 2 : 0;
      if (uiClick(p.x, p.y, btn, e.shiftKey)) { mouse.uiHold = 1; return; }
      if (btn === 0) mouse.l = 1; else { mouse.r = 1; edges.alt = 1; }
    }
    function onUp(e) { const p = cv.local(e); if (mouse.uiHold) { uiRelease(p.x, p.y); mouse.uiHold = 0; } if (e.button === 2) mouse.r = 0; else mouse.l = 0; }
    function onWheel(e) { e.preventDefault(); const p = cv.local(e); if (uiWheel(p.x, p.y, e.deltaY)) return; if (my) my.sel = (my.sel + (e.deltaY > 0 ? 1 : 9)) % 10; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointermove', onMove); cv.cv.addEventListener('pointerdown', onDown); cv.cv.addEventListener('pointerup', onUp); cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false }); cv.cv.addEventListener('contextmenu', noCtx);
    const onKeyCap = (e) => { if (e.code === 'Escape' && (ui.inv || ui.book || ui.map || ui.npc >= 0 || ui.chest >= 0)) { if (ui.book) closeBook(); else if (ui.map) ui.map = false; else { ui.inv = false; closePanels(); } e.preventDefault(); e.stopPropagation(); } };
    window.addEventListener('keydown', onKeyCap, true);
    const onBlur = () => { mouse.l = mouse.r = 0; };
    window.addEventListener('blur', onBlur);
    function readInput() {
      const [ax, ay] = toW(mouse.x, mouse.y);
      const I = { mx: axis('left', 'right'), jump: held('jump') || held('up'), jumpP: edges.jump || edges.up, down: held('down'), use: (mouse.l && !mouse.uiHold && !overUI) || held('use'), ax, ay, sel: undefined, ui: overUI && mouse.l };
      if (held('use') && !mouse.on && my) { I.ax = my.x + my.dir * 2; I.ay = my.y - 1.4; }
      if (edges.alt || edges.alt2) interact(ax, ay);
      for (const k in edges) delete edges[k];
      return I;
    }

    /* ----- 상호작용 ----- */
    const ui = { inv: false, chest: -1, npc: -1, shop: false, book: false, map: false, cur: null, cs: 0, hover: null, regions: [], craftSel: -1, trash: null, chestC: null };
    let overUI = false;
    function closePanels() { if (ui.chest >= 0) doAct(me, ['cc']); ui.chest = -1; ui.npc = -1; ui.shop = false; if (ui.cur && my) { const left = addItem(my.inv, ui.cur[0], ui.cur[1]); if (left) doAct(me, ['dr', ui.cur[0], left, my.x, my.y - 1, my.dir * 4]); ui.cur = null; } }
    function interact(ax, ay) {
      if (!my || my.dead) return;
      const tx = Math.floor(ax), ty = Math.floor(ay);
      // 정착민
      for (let k = 0; k < V.npcs.length; k++) { const n = V.npcs[k]; if (Math.abs(n.x - ax) < 1 && ay > n.y - 2.8 && ay < n.y + 0.2 && Math.hypot(n.x - my.x, n.y - my.y) < 8) { ui.npc = k; ui.inv = true; ui.shop = false; ui.chest = -1; api.sfx('click'); return; } }
      if (!inReach(my, tx, ty, 1)) return;
      const tt = tAt(W, tx, ty), T = TL[tt];
      if (T.door) { doAct(me, ['d', tx, ty]); if (!host()) { let y0 = ty; while (TL[tAt(W, tx, y0 - 1)].door) y0--; const to = T.door === 1 ? T_.dooro : T_.door; for (let q = 0; q < 3; q++) if (TL[tAt(W, tx, y0 + q)].door) W.t[(y0 + q) * W.w + tx] = to; } Snd.play('place'); return; }
      if (tt === T_.chest) { const i = ty * W.w + tx; ui.chest = i; ui.inv = true; ui.npc = -1; doAct(me, ['co', tx, ty]); api.sfx('click'); return; }
      if (tt === T_.bed) { my.sp = { x: tx + 0.5, y: ty + 0.999 }; toast('되살아날 곳을 여기로 정했어요'); return; }
      if (T.st) { ui.inv = true; return; }
    }
    function quickHeal() { if (!my || my.dead) return; let best = -1, bv = 0; for (let k = 0; k < INV; k++) { const s = my.inv[k]; if (s && IT[s[0]].ef && IT[s[0]].ef.heal) { const v = IT[s[0]].ef.heal; if (best < 0 || (v >= my.hpM - my.hp ? v < bv || bv < my.hpM - my.hp : v > bv)) { best = k; bv = v; } } } if (best < 0) { toastOnce('치유 물약이 없어요'); return; } useConsumable(Cs[me], my, IT[my.inv[best][0]], best); }
    function houseQuery() { if (!my) return; const [ax, ay] = toW(mouse.x, mouse.y); const r = checkHouse(W, Math.floor(ax), Math.floor(ay)); if (r.ok) { const who = V.npcs.find((n) => n.home && Math.abs(n.home[0] - r.x) < 0.01 && Math.abs(n.home[1] - r.y) < 0.01); toast('살 수 있는 집이에요! (' + r.n + '칸)' + (who ? ' — ' + NPC[who.k].n + '의 집' : ' — 빈 집')); } else toast('집이 아니에요: ' + r.why); }
    function throwHeld() { if (!my) return; const s = ui.cur || my.inv[my.sel]; if (!s) return; if (ui.cur) { doAct(me, ['dr', s[0], s[1], my.x, my.y - 1.4, my.dir * 8]); ui.cur = null; } else { doAct(me, ['dr', s[0], s[1], my.x + my.dir, my.y - 1.4, my.dir * 8]); my.inv[my.sel] = null; } }

    /* ----- 화면 UI: 가방·제작·상자·가게 (캔버스) ----- */
    function slotAt(x, y) { for (const r of ui.regions) if (x >= r.x && y >= r.y && x < r.x + r.w && y < r.y + r.h) return r; return null; }
    function arrOf(kind) { if (kind === 'inv') return my.inv; if (kind === 'arm') return my.arm; if (kind === 'acc') return my.acc; if (kind === 'chest') return ui.chestC; return null; }
    function accepts(kind, k, id) { const it = IT[id]; if (kind === 'arm') return it.c === 'armor' && it.slot === k; if (kind === 'acc') return it.c === 'acc' && !my.acc.some((a, q) => a && q !== k && a[0] === id); return true; }
    function uiClick(x, y, btn, shift) {
      const r = slotAt(x, y); if (!r) return false;
      if (!my) return true;
      if (r.kind === 'btn') { r.fn(btn, shift); return true; }
      if (r.kind === 'craft') { if (btn === 0) craft(r.k, shift ? 10 : 1); return true; }
      if (r.kind === 'shop') { buy(r.k, shift ? 10 : 1); return true; }
      if (r.kind === 'trash') { if (ui.cur) { ui.trash = ui.cur; ui.cur = null; } else if (ui.trash) { ui.cur = ui.trash; ui.trash = null; } return true; }
      const kind = r.kind, k = r.k, arr = arrOf(kind); if (!arr) return true;
      if (kind === 'chest') return chestClick(k, btn, shift);
      const s = arr[k];
      if (kind === 'inv' && btn === 2 && ui.npc >= 0 && ui.shop && s && !ui.cur) { sell(k); return true; }
      if (kind === 'inv' && btn === 2 && s && !ui.cur) { // 오른쪽 클릭: 장착 / 마시기 / 하나 집기
        const it = IT[s[0]];
        if (it.c === 'armor') { const old = my.arm[it.slot]; my.arm[it.slot] = [s[0], 1]; arr[k] = old; my.st = null; api.sfx('click'); return true; }
        if (it.c === 'acc') { if (my.acc.some((a) => a && a[0] === s[0])) { toastOnce('같은 장신구는 하나만 껴요'); return true; } let e = my.acc.findIndex((a) => !a); if (e < 0) e = 0; const old = my.acc[e]; my.acc[e] = [s[0], 1]; arr[k] = old; my.st = null; api.sfx('click'); return true; }
        if (ui.chest >= 0 && shift) { chestPut(-1, s[0], s[1]); arr[k] = null; return true; }
      }
      if (shift && s && !ui.cur) { // 빠른 이동
        if (ui.chest >= 0 && kind === 'inv') { chestPut(-1, s[0], s[1]); arr[k] = null; return true; }
        if (kind === 'inv') { if (k < HOT) { const left = addItemRange(my.inv, s[0], s[1], HOT, INV); arr[k] = left ? [s[0], left] : null; } else { const left = addItemRange(my.inv, s[0], s[1], 0, HOT); arr[k] = left ? [s[0], left] : null; } return true; }
        if (kind === 'arm' || kind === 'acc') { const left = addItem(my.inv, s[0], 1); if (!left) arr[k] = null; my.st = null; return true; }
      }
      if (btn === 2) { // 하나만 집기
        if (s && (!ui.cur || (ui.cur[0] === s[0] && ui.cur[1] < IT[s[0]].mx))) { if (ui.cur) ui.cur[1]++; else ui.cur = [s[0], 1]; s[1]--; if (!s[1]) arr[k] = null; }
        return true;
      }
      if (ui.cur) {
        if (!accepts(kind, k, ui.cur[0])) { toastOnce(kind === 'arm' ? ['머리', '몸', '다리'][k] + ' 칸에 맞는 갑옷만 껴요' : '장신구만, 같은 것은 하나만 껴요'); return true; }
        if (s && s[0] === ui.cur[0] && kind === 'inv') { const m = Math.min(ui.cur[1], IT[s[0]].mx - s[1]); s[1] += m; ui.cur[1] -= m; if (!ui.cur[1]) ui.cur = null; }
        else { if ((kind === 'arm' || kind === 'acc') && ui.cur[1] > 1) { const one = [ui.cur[0], 1]; ui.cur[1]--; const old = arr[k]; arr[k] = one; if (old) { const left = addItem(my.inv, old[0], old[1]); if (left) doAct(me, ['dr', old[0], left, my.x, my.y - 1, 0]); } } else { arr[k] = ui.cur; ui.cur = s || null; } }
        my.st = null; api.sfx('click');
        mouse.dragFrom = null;
      } else if (s) { ui.cur = s; arr[k] = null; mouse.dragFrom = { kind, k, x, y }; my.st = null; }
      return true;
    }
    function uiRelease(x, y) { const df = mouse.dragFrom; mouse.dragFrom = null; if (!df || !ui.cur) return; if (Math.hypot(x - df.x, y - df.y) < 8) return; const r = slotAt(x, y); if (r && (r.kind === 'inv' || r.kind === 'arm' || r.kind === 'acc' || r.kind === 'chest' || r.kind === 'trash')) uiClick(x, y, 0, false); }
    function addItemRange(inv, id, n, a, b) { const mx = IT[id].mx; for (let k = a; k < b && n > 0; k++) { const s = inv[k]; if (s && s[0] === id && s[1] < mx) { const m = Math.min(n, mx - s[1]); s[1] += m; n -= m; } } for (let k = a; k < b && n > 0; k++) if (!inv[k]) { const m = Math.min(n, mx); inv[k] = [id, m]; n -= m; } return n; }
    function chestClick(k, btn, shift) {
      const c = ui.chestC; if (!c) return true; const s = c[k];
      if (host()) { // 직접
        if (shift && s) { const left = addItem(my.inv, s[0], s[1]); c[k] = left ? [s[0], left] : null; return true; }
        if (ui.cur) { if (s && s[0] === ui.cur[0]) { const m = Math.min(ui.cur[1], IT[s[0]].mx - s[1]); s[1] += m; ui.cur[1] -= m; if (!ui.cur[1]) ui.cur = null; } else { c[k] = ui.cur; ui.cur = s || null; } }
        else if (s) { if (btn === 2) { ui.cur = [s[0], 1]; s[1]--; if (!s[1]) c[k] = null; } else { ui.cur = s; c[k] = null; } }
        return true;
      }
      // 게스트: 호스트에 요청
      if (ui.cur) { chestPut(k, ui.cur[0], ui.cur[1]); ui.cur = null; if (!s) c[k] = ['pending']; }
      else if (s && s[0] !== 'pending') { const n = btn === 2 ? 1 : s[1]; doAct(me, ['ct', ui.chest, k, s[0], n]); s[1] -= n; if (s[1] <= 0) c[k] = null; }
      return true;
    }
    function chestPut(k, id, n) { if (host()) { const c = ui.chestC; if (!c) return; let left = n; if (k >= 0 && !c[k]) { c[k] = [id, Math.min(n, IT[id].mx)]; left -= c[k][1]; } if (left) left = addItem(c, id, left); if (left) addItem(my.inv, id, left); } else doAct(me, ['cp', ui.chest, k, id, n]); }
    function craft(ri, times) {
      const r = RC[ri], sts = stationsNear(W, my);
      let made = 0;
      for (let q = 0; q < times; q++) { if (canCraft(my.inv, r, sts) < 1) break; for (const [id, n] of r.in) takeItem(my.inv, id, n); const left = addItem(my.inv, r.o, r.n); if (left) { if (!ui.cur) ui.cur = [r.o, left]; else doAct(me, ['dr', r.o, left, my.x, my.y - 1, 0]); } made++; }
      if (made) { my.stats.craft += made; Snd.play('pick'); addP(my.x, my.y - 1.5, 8, '#ffe8a0', 4, 0.5, 0.15, -4); pickups.push({ id: r.o, n: r.n * made, t: 0 }); if (IT[r.o].c === 'potion') doAct(me, ['fl', 'alch', 1]); }
    }
    function buy(si, times) {
      const N2 = NPC[V.npcs[ui.npc] ? V.npcs[ui.npc].k : 0], s = N2.shop[si]; if (!s) return;
      const id = IX[s[0]], price = s[1];
      for (let q = 0; q < times; q++) { if (countItem(my.inv, IX.coin) < price) { toastOnce('동전이 모자라요'); break; } if (!canFit(my.inv, id, 1)) { toastOnce('가방이 가득 찼어요'); break; } takeItem(my.inv, IX.coin, price); addItem(my.inv, id, 1); Snd.play('pick'); }
    }
    function sell(k) { const s = my.inv[k]; if (!s || s[0] === IX.coin) return; const v = Math.max(1, Math.floor(IT[s[0]].v * s[1] / 5)); my.inv[k] = null; addItem(my.inv, IX.coin, v); toast(IT[s[0]].n + ' 팔기 +' + v + '동전'); Snd.play('pick'); }
    function uiWheel(x, y, dy) { if (!ui.inv) return false; const r = slotAt(x, y); if (r && (r.kind === 'craft' || r.kind === 'craftArea')) { ui.cs = Math.max(0, ui.cs + (dy > 0 ? 1 : -1)); return true; } if (r && r.kind === 'shop') return true; return false; }

    /* ----- 레시피 책 (DOM) ----- */
    let bookEl = null, bookCat = 'all', bookQ = '', bookOnlyCan = false;
    function closeBook() { ui.book = false; if (bookEl) { bookEl.remove(); bookEl = null; } }
    function openBook(filterId) {
      ui.book = true; if (bookEl) bookEl.remove();
      bookEl = L.h('div', { class: 'sb-book' });
      const hd = L.h('div', { class: 'hd' });
      hd.appendChild(L.h('h3', { text: '📖 레시피 책' }));
      const inp = L.h('input', { placeholder: '이름·재료 찾기 (예: 곡괭이, 젤리)', value: bookQ });
      inp.addEventListener('input', () => { bookQ = inp.value; fill(); });
      inp.addEventListener('keydown', (e) => e.stopPropagation());
      hd.appendChild(inp);
      const canB = L.h('button', { text: '지금 만들 수 있는 것만', class: bookOnlyCan ? 'on' : '', onclick: () => { bookOnlyCan = !bookOnlyCan; canB.className = bookOnlyCan ? 'on' : ''; fill(); } });
      hd.appendChild(canB);
      hd.appendChild(L.h('button', { text: '닫기', 'data-key': 'Escape', onclick: closeBook }));
      bookEl.appendChild(hd);
      const cats = [['all', '전체'], ['tool', '도구'], ['weapon', '무기'], ['armor', '갑옷'], ['acc', '장신구'], ['potion', '물약'], ['build', '블록·가구'], ['mat', '재료'], ['boss', '보스']];
      const chips = L.h('div', { class: 'chips' });
      for (const [k2, n] of cats) chips.appendChild(L.h('button', { text: n, class: bookCat === k2 ? 'on' : '', onclick: () => { bookCat = k2; [...chips.children].forEach((b, q) => { b.className = cats[q][0] === k2 ? 'on' : ''; }); fill(); } }));
      bookEl.appendChild(chips);
      const list = L.h('div', { class: 'list' }); bookEl.appendChild(list);
      const src = L.h('div', { class: 'src', text: '재료 이름을 누르면 그 재료를 얻는 곳·만드는 법이 나와요.' }); bookEl.appendChild(src);
      const catOf = (it) => ({ pick: 'tool', axe: 'tool', hammer: 'tool', melee: 'weapon', ranged: 'weapon', magic: 'weapon', summon: 'weapon', ammo: 'weapon', armor: 'armor', acc: 'acc', potion: 'potion', block: 'build', wall: 'build', furn: 'build', light: 'build', mat: 'mat', misc: 'potion', boss: 'boss' })[it.c] || 'mat';
      const showSrc = (id) => { const s = sourcesOf(id); src.textContent = IT[id].n + ' — ' + (s.length ? s.join(' · ') : '얻는 곳: 세계 곳곳'); inp.value = IT[id].n; bookQ = IT[id].n; fill(); };
      function fill() {
        list.innerHTML = '';
        const sts = my ? stationsNear(W, my) : {};
        const q = bookQ.trim();
        let n = 0;
        RC.forEach((r, ri) => {
          const it = IT[r.o];
          if (bookCat !== 'all' && catOf(it) !== bookCat) return;
          if (q && !(it.n.includes(q) || r.in.some(([id]) => IT[id].n.includes(q)))) return;
          const can = my ? canCraft(my.inv, r, sts) : 0;
          if (bookOnlyCan && can < 1) return;
          if (n++ > 220) return;
          const row = L.h('div', { class: 'row' });
          const img = L.h('img', { alt: '' }); try { img.src = itemIcon(r.o, 32).toDataURL(); } catch (e) { /* */ }
          row.appendChild(img);
          row.appendChild(L.h('div', { class: 'nm', text: it.n + (r.n > 1 ? ' ×' + r.n : ''), title: itemLines(it).join('\n'), onclick: () => showSrc(r.o) }));
          const ins = L.h('div', { class: 'ins' });
          for (const [id, c] of r.in) { const have = my ? countItem(my.inv, id) : 0; ins.appendChild(L.h('span', { class: have >= c ? 'ok' : 'no', text: IT[id].n + ' ' + c + ' (' + have + ')', onclick: () => showSrc(id) })); }
          row.appendChild(ins);
          row.appendChild(L.h('div', { class: 'at', text: r.at ? (sts[r.at] ? '✓ ' : '') + ST_N[r.at] : '맨손' }));
          if (can >= 1) row.appendChild(L.h('button', { text: '만들기', onclick: () => { craft(ri, 1); fill(); } }));
          list.appendChild(row);
        });
        if (!n) list.appendChild(L.h('div', { class: 'row', text: '찾는 레시피가 없어요.' }));
      }
      fill();
      if (filterId !== undefined) showSrc(filterId);
      root.appendChild(bookEl);
      setTimeout(() => { try { inp.focus(); } catch (e) { /* */ } }, 30);
    }

    /* ----- 온라인 ----- */
    let pubT = 0, hsQ = 0, lastQ = -1, ivT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !G) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.np) || isBot(s) || localHuman(s) || !o || o.k !== key) continue;
        let sh = G.P[s]; if (!sh || sh.local) { sh = G.P[s] = { s, local: 0, w: PW, h: PH, arm: [] }; }
        if (fin(+o.x) && fin(+o.y)) { sh.x = clamp(+o.x, 1, W.w - 1); sh.y = clamp(+o.y, 1, W.h - 1); }
        sh.vx = +o.vx || 0; sh.vy = +o.vy || 0; sh.dir = o.d === -1 ? -1 : 1; sh.dead = o.dd ? 1 : 0; sh.hp = +o.hp || 0; sh.hpM = +o.hm || 100; sh.held = o.he | 0; sh.swA = fin(+o.sw) ? +o.sw : null; sh.armS = typeof o.ar === 'string' ? o.ar : ''; sh.iv = o.iv2 ? 1 : 0; sh.fresh = 0;
        if (Array.isArray(o.A)) for (const e of o.A) { if (!Array.isArray(e)) continue; const sq = e[0] | 0; if (sq > (G.ack[s] | 0)) { try { hostAction(G, s, e[1]); } catch (er) { console.error(er); } G.ack[s] = sq; } }
        if (fin(+o.ea)) G.eaOf[s] = +o.ea;
        if (typeof o.iv === 'string' && o.iv !== sh.ivs) { sh.ivs = o.iv; try { sh.saved = JSON.parse(o.iv); } catch (er) { /* */ } }
        if (G.ivOut && o.iva >= G.ivOut.v) { delete G.ivOut.s[s]; if (!Object.keys(G.ivOut.s).length) G.ivOut = null; }
        if (fin(+o.cn)) G.fl.coin = Math.max(G.fl.coin, +o.cn);
      }
    }
    function minAck() { let m = Infinity; for (let s = 0; s < st.np; s++) { if (isBot(s) || localHuman(s)) continue; if (G.eaOf[s] !== undefined) m = Math.min(m, G.eaOf[s]); } return m === Infinity ? G.eseq : m; }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ) return;
      lastQ = hs.q;
      try { applySnap(hs); } catch (er) { console.error(er); }
    }
    function applySnap(hs) {
      V.tm = +hs.tm || 0; V.day = hs.dy | 0; V.ev = hs.ev || 0;
      if (Array.isArray(hs.ed) && hs.e0 <= applied && hs.e1 > applied) {
        const ed = hs.ed;
        for (let k = 0; k + 3 < ed.length; k += 4) { const i = ed[k]; if (i < 0 || i >= W.t.length) continue; const ox = W.t[i]; W.t[i] = ed[k + 1]; W.wl[i] = ed[k + 2]; W.lq[i] = ed[k + 3]; if (OPAQ[ox] !== OPAQ[W.t[i]] || SOLIDT[ox] !== SOLIDT[W.t[i]]) colTop(W, i % W.w); if (seen[i]) mapPix(i), mapDirty = 1; }
        applied = hs.e1;
      }
      // 다른 플레이어
      if (Array.isArray(hs.P)) hs.P.forEach((a, s) => { if (s === me || !a) return; const o = V.P[s] || (V.P[s] = { s, local: 0, w: PW, h: PH }); o.x = a[0]; o.y = a[1]; o.dir = a[2]; o.dead = a[3]; o.swA = a[4]; o.held = a[5]; o.hp = a[6]; o.hpM = a[7]; o.armS = a[8]; o.iv = a[9]; o.vx = a[10]; o.vy = a[11]; });
      // 적
      const old = new Map(V.en.map((e) => [e.id, e]));
      V.en = (hs.E || []).map((a) => { const e = old.get(a[0]) || { id: a[0], hurt: 0 }; const E2 = EN[a[1]] || EN[0]; Object.assign(e, { t: a[1], tx: a[2], ty: a[3], vx: a[4], vy: a[5], hp: a[6], hpM: a[7], dir: a[8], hurt: a[9] ? 0.15 : e.hurt, w: E2.w, h: E2.h }); if (e.x === undefined || Math.abs(e.x - e.tx) > 6 || Math.abs(e.y - e.ty) > 6) { e.x = e.tx; e.y = e.ty; } return e; });
      const oldD = new Map(V.dr.map((d) => [d.id, d]));
      V.dr = (hs.D || []).map((a) => { const d = oldD.get(a[0]) || { id: a[0] }; d.it = a[1]; d.x = a[2]; d.y = a[3]; return d; });
      const oldJ = new Map(V.pj.map((j) => [j.id, j]));
      V.pj = (hs.J || []).map((a) => { const j = oldJ.get(a[0]) || { id: a[0] }; j.k = PJK[a[1]] || 'bolt'; if (j.x === undefined || Math.abs(j.x - a[2]) > 3 || Math.abs(j.y - a[3]) > 3) { j.x = a[2]; j.y = a[3]; } j.tx = a[2]; j.ty = a[3]; j.vx = a[4]; j.vy = a[5]; j.warn = a[6] ? 1 : 0; j.dmg = a[7]; j.life = 1; return j; });
      V.npcs = (hs.N || []).map((a) => ({ k: a[0], x: a[1], y: a[2], dir: a[3], home: a[4] ? [a[1], a[2]] : null, w: 1.2, h: 2.7 }));
      if (hs.B) { const a = hs.B; const b = V.boss && V.boss.b === a[0] ? V.boss : { b: a[0] }; Object.assign(b, { x: a[1], y: a[2], hp: a[3], hpM: a[4], ph: a[5], ang: a[6], hurt: a[7], w: BOSS[a[0]].w, h: BOSS[a[0]].h, vx: a[9], vy: a[10] }); if (a[0] === 2) b.seg = a[8].split(';').map((s) => s.split(',').map(Number)); if (a[0] === 3) b.hands = a[8].split(';').map((s) => { const q = s.split(',').map(Number); return { x: q[0], y: q[1], st: q[2] }; }); V.boss = b; } else V.boss = null;
      if (Array.isArray(hs.fl)) V.fl = { b: String(hs.fl[0]).split('').map(Number) };
      // 받을 물건
      if (Array.isArray(hs.G)) for (const g of hs.G) { if (!Array.isArray(g) || g[0] <= lastG) continue; lastG = g[0]; if (g[1] === me && my && IT[g[2]]) { const left = addItem(my.inv, g[2], g[3]); if (left) doAct(me, ['dr', g[2], left, my.x, my.y - 1, 0]); pickups.push({ id: g[2], n: g[3], t: 0 }); Snd.play('pick'); } }
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; onFx(e); }
      if (hs.A && fin(+hs.A[me])) { const ak = +hs.A[me]; outbox = outbox.filter((e) => e[0] > ak); }
      if (hs.C && hs.C[me] && ui.chest === hs.C[me][0]) ui.chestC = unpackInv(hs.C[me][1], CHEST_N);
      if (hs.IV && hs.IV.v > ivApplied && hs.IV.s && hs.IV.s[me] && my) { ivApplied = hs.IV.v; loadPlayer(my, hs.IV.s[me]); toast('저장된 가방을 이어받았어요'); }
      if (hs.mt) V.mt = hs.mt;
    }
    function publish(rdt) {
      if (!api.online || !st || !W) return;
      pubT -= rdt; ivT -= rdt;
      try {
        if (api.isHost) {
          if (!G || pubT > 0) return;
          pubT = 1 / 15; hsQ = (hsQ + 1) % 100000;
          const ma = minAck();
          api.net.hostSend(snapshot(G, key, hsQ, ma));
          compactLog(G, ma);
        } else {
          if (pubT > 0 || me < 0 || !my) return;
          pubT = 1 / 20;
          const o = { k: key, x: r2(my.x), y: r2(my.y), vx: r1(my.vx), vy: r1(my.vy), d: my.dir, dd: my.dead ? 1 : 0, sw: my.sw ? r1(my.sw.ang) : null, he: my.inv[my.sel] ? my.inv[my.sel][0] : -1, hp: Math.round(my.hp), hm: my.hpM, ar: my.arm.map((a) => (a ? a[0] : -1)).join('.'), iv2: my.iv > 0 ? 1 : 0, A: outbox.slice(-40), ea: applied, iva: ivApplied, cn: countItem(my.inv, IX.coin) };
          if (ivT <= 0) { ivT = 5; o.iv = JSON.stringify(savePlayer(my)); lastIv = o.iv; } else if (lastIv) o.iv = lastIv;
          api.net.publish(o);
        }
      } catch (e) { /* offline */ }
    }
    let lastIv = '';

    /* ----- 한 걸음 ----- */
    const DT = 1 / 60;
    let Iframe = null, firstStep = true, revealT = 0, mineT = 0;
    function step(dt) {
      const I = firstStep ? Iframe : Object.assign({}, Iframe, { jumpP: 0 }); firstStep = false;
      if (host()) {
        const humanLeader = G.P.find((p, s) => p && !p.dead && !isBot(s) && (localHuman(s) || !p.local) && !p.fresh);
        for (let s = 0; s < st.np; s++) {
          const p = G.P[s]; if (!p || !p.local) continue;
          if (s === me) playerTick(Cs[s], p, I, dt);
          else if (isBot(s)) { const M = botMem[s] || (botMem[s] = {}); playerTick(Cs[s], p, botInput(Cs[s], p, lvOf(s), M, humanLeader), dt); }
        }
        G.alive = G.P.filter((p) => p && !p.dead && !p.fresh);
        worldTick(G, dt);
        V.en = G.en; V.pj = G.pj; V.dr = G.dr; V.npcs = G.npcs; V.boss = G.boss; V.tm = G.tm; V.day = G.day; V.ev = G.ev ? (G.ev.k === 'raid' ? 'r' + G.ev.left : 'b') : 0; V.fl = G.fl;
        for (const e of G.fx) if (e[0] > lastFx) { lastFx = e[0]; onFx(e); }
        if (G.grants.length && !api.online) G.grants.length = 0;
        if (!api.online) { G.log.s.length = 0; G.log.i.length = 0; G.last.clear(); }
      } else {
        if (my) playerTick(Cs[me], my, I, dt);
        for (const e of V.en) { if (e.tx === undefined) continue; e.tx += (e.vx || 0) * dt; e.ty += (e.vy || 0) * dt; e.x += (e.tx - e.x) * Math.min(1, dt * 12); e.y += (e.ty - e.y) * Math.min(1, dt * 12); e.hurt = Math.max(0, (e.hurt || 0) - dt); }
        for (const j of V.pj) { j.tx += (j.vx || 0) * dt; j.ty += (j.vy || 0) * dt; j.x += (j.tx - j.x) * Math.min(1, dt * 15); j.y += (j.ty - j.y) * Math.min(1, dt * 15); }
        if (V.boss) { const b = V.boss; b.x += (b.vx || 0) * dt; b.y += (b.vy || 0) * dt; }
        V.tm += dt / DAY;
      }
      // 공용: 효과·채굴 흔적
      for (const q of vis) { q.t += dt; q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; }
      vis = vis.filter((q) => q.t < 2 && !solidAt(W, Math.floor(q.x), Math.floor(q.y)));
      mineT -= dt; if (mineT <= 0) { mineT = 0.25; for (const s in Cs) { const C = Cs[s]; for (const [k, m] of C.mine) { m.t -= 0.25; if (m.t <= 0) C.mine.delete(k); } } }
      revealT -= dt; if (revealT <= 0) { revealT = 0.35; const f = my && !my.dead ? my : null; if (f) reveal(f.x, f.y - 1.4, 26); else reveal(cam.x, cam.y, 22); }
    }
    function hostEnd() {
      if (!host() || !G || st.res) return;
      const demo = me < 0 && !api.online && !st.ai.every((v, s) => !v && !localHuman(s));
      let end = null;
      if (demo && G.el > 200) end = { title: '시연 끝', text: 'AI 개척자들의 ' + G.day + '일째 기록이에요.' };
      if (st.goal && G.won) end = { title: '세계를 구했어요!', text: '별의 집행자를 쓰러뜨렸어요. ' + G.day + '일 만에!', win: 1 };
      if (!end) return;
      const col = (f) => G.P.map((p) => (p && p.stats ? String(f(p)) : '-'));
      end.stats = [
        { label: '캔 블록', values: col((p) => p.stats.mine) }, { label: '놓은 블록', values: col((p) => p.stats.place) },
        { label: '만든 물건', values: col((p) => p.stats.craft) }, { label: '처치', values: col((p) => p.kills | 0) },
        { label: '쓰러짐', values: col((p) => p.stats.die), low: true }, { label: '보스 처치', values: col((p) => p.bossK | 0) },
      ];
      end.hl = ['세계 ' + SIZES[st.sz].n + ' · ' + G.day + '일째', '쓰러뜨린 적 ' + G.stat.kills + ' · 보스 ' + G.stat.bosses, '정착민 ' + G.npcs.length + '명'];
      const n = U.clone(st); n.res = end; api.setState(n);
    }

    /* ----- 조명 ----- */
    let LR = null, LG2 = null, LB = null, lightCv = null, lightImg = null, LWd = 0, LHt = 0;
    function dayLevel(tm) { if (tm < 0.05) return 0.35 + tm / 0.05 * 0.65; if (tm < NIGHT0 - 0.06) return 1; if (tm < NIGHT0) return 1 - (tm - (NIGHT0 - 0.06)) / 0.06 * 0.78; if (tm > 0.97) return 0.22 + (tm - 0.97) / 0.03 * 0.13; return 0.22; }
    function computeLight(x0, y0, vw, vh, lights) {
      const M = 12, LW2 = vw + 2 * M, LH2 = vh + 2 * M, N2 = LW2 * LH2;
      if (!LR || LR.length < N2) { LR = new Float32Array(N2); LG2 = new Float32Array(N2); LB = new Float32Array(N2); }
      const dl = dayLevel(V.tm);
      const blood = V.ev === 'b';
      const sr = dl * (blood && dl < 0.5 ? 1.25 : 1), sg = dl * (blood && dl < 0.5 ? 0.55 : dl < 0.5 ? 0.85 : 1), sb = dl * (blood && dl < 0.5 ? 0.6 : dl < 0.5 ? 1.15 : 1);
      const dec = new Float32Array(N2);
      for (let gy = 0; gy < LH2; gy++) {
        const y = y0 - M + gy;
        for (let gx = 0; gx < LW2; gx++) {
          const x = x0 - M + gx, k = gy * LW2 + gx;
          if (x < 0 || y < 0 || x >= W.w || y >= W.h) { LR[k] = LG2[k] = LB[k] = 0; dec[k] = 0.2; continue; }
          const i = y * W.w + x, tt = W.t[i], wl = W.wl[i];
          let r = 0, g = 0, b = 0;
          if (y < W.top[x] && !(wl && WL[wl].nat) && y < W.hellTop) { r = sr; g = sg; b = sb; }
          const lt = LIGHTT[tt]; if (lt) { const c = TL[tt].lc || [1, 1, 1]; r = Math.max(r, c[0] * lt); g = Math.max(g, c[1] * lt); b = Math.max(b, c[2] * lt); }
          const lq = W.lq[i]; if (lq & 16) { r = Math.max(r, 0.9); g = Math.max(g, 0.45); b = Math.max(b, 0.15); }
          if (y >= W.hellTop && !SOLIDT[tt]) { r = Math.max(r, 0.32); g = Math.max(g, 0.14); b = Math.max(b, 0.1); }
          LR[k] = r; LG2[k] = g; LB[k] = b;
          dec[k] = SOLIDT[tt] && OPAQ[tt] ? 0.13 : lq && !(lq & 16) ? 0.1 : 0.068;
        }
      }
      for (const l of lights) { const gx = Math.floor(l[0]) - x0 + M, gy = Math.floor(l[1]) - y0 + M; if (gx < 0 || gy < 0 || gx >= LW2 || gy >= LH2) continue; const k = gy * LW2 + gx; LR[k] = Math.max(LR[k], l[2]); LG2[k] = Math.max(LG2[k], l[3]); LB[k] = Math.max(LB[k], l[4]); }
      for (let pass = 0; pass < 2; pass++) for (const A of [LR, LG2, LB]) {
        for (let gy = 0; gy < LH2; gy++) { const o = gy * LW2; for (let gx = 1; gx < LW2; gx++) { const v = A[o + gx - 1] - dec[o + gx]; if (v > A[o + gx]) A[o + gx] = v; } for (let gx = LW2 - 2; gx >= 0; gx--) { const v = A[o + gx + 1] - dec[o + gx]; if (v > A[o + gx]) A[o + gx] = v; } }
        for (let gx = 0; gx < LW2; gx++) { for (let gy = 1; gy < LH2; gy++) { const k = gy * LW2 + gx, v = A[k - LW2] - dec[k]; if (v > A[k]) A[k] = v; } for (let gy = LH2 - 2; gy >= 0; gy--) { const k = gy * LW2 + gx, v = A[k + LW2] - dec[k]; if (v > A[k]) A[k] = v; } }
      }
      if (!lightCv || LWd !== vw || LHt !== vh) { lightCv = mkCanvas(vw, vh); LWd = vw; LHt = vh; lightImg = lightCv.getContext('2d').createImageData(vw, vh); }
      const d = lightImg.data;
      const floor = my && my.st && (my.st.night || my.bf.night) ? 0.16 : 0.0;
      for (let gy = 0; gy < vh; gy++) for (let gx = 0; gx < vw; gx++) { const k = (gy + M) * LW2 + gx + M, o = (gy * vw + gx) * 4; d[o] = Math.min(255, (LR[k] + floor) * 255); d[o + 1] = Math.min(255, (LG2[k] + floor) * 255); d[o + 2] = Math.min(255, (LB[k] + floor) * 255); d[o + 3] = 255; }
      lightCv.getContext('2d').putImageData(lightImg, 0, 0);
      return lightCv;
    }

    /* ----- 그리기 ----- */
    function skyColors(tm) {
      const dl = dayLevel(tm), blood = V.ev === 'b' && dl < 0.6;
      const top = blood ? [70, 8, 14] : [Math.round(12 + 60 * dl), Math.round(14 + 110 * dl), Math.round(40 + 190 * dl)];
      const bot = blood ? [140, 30, 30] : [Math.round(30 + 150 * dl + (tm > NIGHT0 - 0.08 && tm < NIGHT0 + 0.02 ? 60 : 0)), Math.round(30 + 170 * dl), Math.round(60 + 175 * dl)];
      return [top, bot];
    }
    const rgb = (a) => 'rgb(' + a[0] + ',' + a[1] + ',' + a[2] + ')';
    function drawBackground(g, w, h, t) {
      const [top, bot] = skyColors(V.tm);
      const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, rgb(top)); gr.addColorStop(1, rgb(bot)); g.fillStyle = gr; g.fillRect(0, 0, w, h);
      const dl = dayLevel(V.tm);
      if (dl < 0.6) { g.fillStyle = 'rgba(255,255,255,' + (0.8 * (0.6 - dl)) + ')'; for (let k = 0; k < 90; k++) { const sx = (hash2(k, 1, 7) * w * 1.3 - cam.x * 0.3) % (w * 1.3), sy = hash2(k, 2, 7) * h * 0.6; g.fillRect((sx + w * 1.3) % (w * 1.3), sy, 1.5, 1.5); } }
      // 해·달
      const isD = V.tm < NIGHT0, f = isD ? V.tm / NIGHT0 : (V.tm - NIGHT0) / (1 - NIGHT0);
      const bx = w * (0.1 + 0.8 * f), by = h * 0.55 - Math.sin(f * Math.PI) * h * 0.45;
      if (isD) { const sg = g.createRadialGradient(bx, by, 4, bx, by, 60); sg.addColorStop(0, '#fff8d0'); sg.addColorStop(0.3, 'rgba(255,230,140,.6)'); sg.addColorStop(1, 'rgba(255,220,120,0)'); g.fillStyle = sg; g.beginPath(); g.arc(bx, by, 60, 0, TAU); g.fill(); }
      else { g.fillStyle = V.ev === 'b' ? '#ff5a5a' : '#e8ecf4'; g.beginPath(); g.arc(bx, by, 18, 0, TAU); g.fill(); g.fillStyle = rgb(top); g.beginPath(); g.arc(bx + 7, by - 4, 15, 0, TAU); g.fill(); }
      // 먼 언덕
      const bio = W.bio[clamp(Math.floor(cam.x), 0, W.w - 1)];
      const hillC = [['#3a6a4a', '#2a5038'], ['#b89a5a', '#9a7a40'], ['#b8c8d8', '#90a4b8'], ['#2a6a2a', '#1a4a1a'], ['#4a7aa8', '#3a5a88']][bio];
      const surfY = toS(0, W.surf[clamp(Math.floor(cam.x), 0, W.w - 1)])[1];
      for (let L3 = 0; L3 < 2; L3++) { const par = L3 ? 0.35 : 0.18, base = surfY - (L3 ? 30 : 70); g.fillStyle = shade(hillC[L3], -(1 - dl) * 0.6); g.beginPath(); g.moveTo(0, h); for (let x = 0; x <= w + 20; x += 20) { const wx = x / 20 + cam.x * par; g.lineTo(x, base - fbm(wx / 9, L3 * 9, 3, 2) * 90 - 20); } g.lineTo(w, h); g.closePath(); g.fill(); }
      // 땅속 배경
      const [, ug] = toS(0, W.surf[clamp(Math.floor(cam.x), 0, W.w - 1)] + 10);
      if (ug < h) { const cg = g.createLinearGradient(0, ug, 0, h); cg.addColorStop(0, '#2a1e18'); cg.addColorStop(1, cam.y > W.hellTop - 10 ? '#3a1410' : '#141018'); g.fillStyle = cg; g.fillRect(0, Math.max(0, ug), w, h); }
      void t;
    }
    function draw(t) {
      const g = ctx, w = cv.w, h = cv.h;
      g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      if (!W) { g.fillStyle = '#17131f'; g.fillRect(0, 0, w, h); g.fillStyle = '#e3ae45'; g.font = '700 22px ' + BODY; g.textAlign = 'center'; g.fillText('세계를 만드는 중…', w / 2, h / 2); g.font = '14px ' + BODY; g.fillStyle = '#ab9fb8'; g.fillText('땅·동굴·광석·하늘섬을 놓고 있어요', w / 2, h / 2 + 28); return; }
      TS = Math.max(10, Math.round(h / 44 * ZOOMS[zoomI]));
      if (!atlas || atlasTS !== TS) { atlas = makeAtlas(TS); atlasTS = TS; }
      const k = uiK();
      // 카메라
      const f = my && !my.dead ? my : V.P.find((p) => p && !p.dead) || null;
      if (f) { const tx = f.x + (mouse.on && my ? clamp((mouse.x - w / 2) / TS * 0.12, -4, 4) : 0), ty = f.y - 1.5 + (mouse.on && my ? clamp((mouse.y - h / 2) / TS * 0.12, -3, 3) : 0); cam.x += (tx - cam.x) * 0.15; cam.y += (ty - cam.y) * 0.15; }
      const hw = w / 2 / TS, hh = h / 2 / TS;
      cam.x = clamp(cam.x, hw + 1, W.w - hw - 1); cam.y = clamp(cam.y, hh + 1, W.h - hh - 1);
      let shx = 0, shy = 0; if (shake > 0) { shx = (Math.random() - 0.5) * shake; shy = (Math.random() - 0.5) * shake; shake = Math.max(0, shake - 0.6); }
      drawBackground(g, w, h, t);
      g.save(); g.translate(shx, shy);
      const x0 = Math.floor(cam.x - hw) - 1, y0 = Math.floor(cam.y - hh) - 1, vw = Math.ceil(hw * 2) + 3, vh = Math.ceil(hh * 2) + 3;
      const ox = Math.round((x0 - cam.x) * TS + w / 2), oy = Math.round((y0 - cam.y) * TS + h / 2);
      g.imageSmoothingEnabled = false;
      // 벽
      for (let ty = 0; ty < vh; ty++) { const y = y0 + ty; if (y < 0 || y >= W.h) continue; for (let tx = 0; tx < vw; tx++) { const x = x0 + tx; if (x < 0 || x >= W.w) continue; const i = y * W.w + x, wl = W.wl[i]; if (!wl) continue; const tt = W.t[i]; if (SOLIDT[tt] && OPAQ[tt]) continue; g.drawImage(atlas.w[wl][(x + y) & 1], ox + tx * TS, oy + ty * TS); } }
      if (atlas) { g.fillStyle = 'rgba(0,0,0,.28)'; }
      // 타일
      const oreSeen = my && (my.bf.ore || (my.st && my.st.ore));
      for (let ty = 0; ty < vh; ty++) {
        const y = y0 + ty; if (y < 0 || y >= W.h) continue;
        for (let tx = 0; tx < vw; tx++) {
          const x = x0 + tx; if (x < 0 || x >= W.w) continue;
          const i = y * W.w + x, tt = W.t[i]; if (!tt) continue;
          const sx = ox + tx * TS, sy = oy + ty * TS;
          const v = (hash2(x, y, 3) * 4) | 0;
          if (tt === T_.leaf || tt === T_.pine || tt === T_.jleaf) { g.drawImage(atlas.t[tt][v], sx - TS * 0.2, sy - TS * 0.2, TS * 1.4, TS * 1.4); continue; }
          g.drawImage(atlas.t[tt][v], sx, sy);
          if (SOLIDT[tt]) {
            const up = W.t[i - W.w];
            if (!SOLIDT[up] || !OPAQ[up]) { const top = TL[tt].top; if (top) { g.fillStyle = top; g.fillRect(sx, sy, TS, Math.max(2, TS * 0.28)); g.fillStyle = shade(top, 0.2); g.fillRect(sx + (v * TS / 5 | 0), sy - 1, 2, 2); } else { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(sx, sy, TS, Math.max(1, TS / 10)); } }
            if (!SOLIDT[W.t[i + W.w]]) { g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(sx, sy + TS - Math.max(1, TS / 8), TS, Math.max(1, TS / 8)); }
            if (!SOLIDT[W.t[i - 1]]) { g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(sx, sy, Math.max(1, TS / 10), TS); }
            if (!SOLIDT[W.t[i + 1]]) { g.fillStyle = 'rgba(0,0,0,.16)'; g.fillRect(sx + TS - Math.max(1, TS / 10), sy, Math.max(1, TS / 10), TS); }
          }
        }
      }
      // 액체
      for (let ty = 0; ty < vh; ty++) { const y = y0 + ty; if (y < 1 || y >= W.h) continue; for (let tx = 0; tx < vw; tx++) { const x = x0 + tx; if (x < 0 || x >= W.w) continue; const i = y * W.w + x, a = W.lq[i]; if (!a) continue; const amt = (a & 15) / 8, above = W.lq[i - W.w]; const hgt = above ? 1 : amt; const sx = ox + tx * TS, sy = oy + ty * TS + TS * (1 - hgt); g.fillStyle = a & 16 ? 'rgba(255,100,30,.92)' : 'rgba(50,110,220,.55)'; g.fillRect(sx, sy, TS, TS * hgt + 0.5); if (!above) { g.fillStyle = a & 16 ? 'rgba(255,220,120,.9)' : 'rgba(170,210,255,.7)'; g.fillRect(sx, sy + Math.sin(t * 3 + x) * 1, TS, Math.max(1, TS / 9)); } } }
      // 채굴 금
      if (my && Cs[me]) for (const [mk, m] of Cs[me].mine) { const wall = mk[0] === 'w', i = +mk.slice(1), x = i % W.w, y = (i / W.w) | 0; const tt = W.t[i]; const hp = wall ? 40 : TL[tt].hp || 1; const fr = clamp(m.d / hp, 0, 1); const [sx, sy] = toS(x, y); g.strokeStyle = 'rgba(20,10,10,.7)'; g.lineWidth = Math.max(1, TS / 12); g.beginPath(); const n = 1 + Math.floor(fr * 4); for (let q = 0; q < n; q++) { const a = hash2(i, q, 1) * TAU; g.moveTo(sx + TS / 2, sy + TS / 2); g.lineTo(sx + TS / 2 + Math.cos(a) * TS * 0.45, sy + TS / 2 + Math.sin(a) * TS * 0.45); } g.stroke(); }
      // 떨어진 물건
      for (const d of V.dr) { const [sx, sy] = toS(d.x, d.y); if (sx < -30 || sy < -30 || sx > w + 30 || sy > h + 30) continue; const bob = Math.sin(t * 3 + d.id) * TS * 0.08; g.drawImage(itemIcon(d.it, 32), sx - TS * 0.45, sy - TS * 0.9 + bob, TS * 0.9, TS * 0.9); }
      // 정착민
      for (const n of V.npcs) { const [sx, sy] = toS(n.x, n.y); if (sx < -50 || sx > w + 50) continue; const N2 = NPC[n.k]; drawHuman(g, sx, sy, TS * 0.98, { dir: n.dir, walk: n.x * 2, moving: true, shirt: N2.col, pants: shade(N2.col, -0.4), hair: '#5a4030', hat: n.k === 6 ? '#3a4a9a' : n.k === 1 ? '#8a6a30' : null, skin: '#e0b088' }); if (Math.hypot(n.x - (my ? my.x : cam.x), n.y - (my ? my.y : cam.y)) < 9) { g.font = '700 ' + Math.round(12 * k) + 'px ' + BODY; g.textAlign = 'center'; g.fillStyle = 'rgba(0,0,0,.55)'; const tw = g.measureText(N2.n).width + 10; g.fillRect(sx - tw / 2, sy - TS * 3.4 - 14 * k, tw, 17 * k); g.fillStyle = '#ffe8a0'; g.fillText(N2.n, sx, sy - TS * 3.4 - 1 * k); } }
      // 적
      for (const e of V.en) { const [sx, sy] = toS(e.x, e.y); if (sx < -80 || sx > w + 80 || sy < -80 || sy > h + 80) continue; const E = EN[e.t]; drawEnemy(g, e, E, sx, sy, TS, t); if (e.hp < e.hpM) { const bw = Math.max(TS * 1.4, e.w * TS); g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(sx - bw / 2, sy + 3, bw, 4); g.fillStyle = '#e8664f'; g.fillRect(sx - bw / 2, sy + 3, bw * clamp(e.hp / e.hpM, 0, 1), 4); } }
      // 보스
      // 플레이어
      for (let s = 0; s < (st ? st.np : 0); s++) { const p = V.P[s]; if (!p || p.dead || p.fresh || p.x === undefined) continue; drawPlayer(g, p, s, t, k); }
      // 소환수·내 투사체·보이기만 하는 투사체
      for (const s in Cs) { const C = Cs[s]; for (const m of C.mn) { const [sx, sy] = toS(m.x, m.y); drawMinion(g, m, sx, sy, t); } for (const q of C.pjs) drawPj(g, q.k, q.x, q.y, q.vx, q.vy, q.col, t); }
      for (const q of vis) drawPj(g, q.k, q.x, q.y, q.vx, q.vy, null, t);
      for (const j of V.pj) drawHostile(g, j, t);
      // 알갱이
      for (const p of ptc) { const [sx, sy] = toS(p.x, p.y); g.globalAlpha = clamp(1 - p.t / p.l, 0, 1); g.fillStyle = p.c; const s2 = p.s * TS; g.fillRect(sx - s2 / 2, sy - s2 / 2, s2, s2); } g.globalAlpha = 1;
      // 커서 칸
      if (my && !my.dead && mouse.on && !overUI && !ui.book) { const [ax, ay] = toW(mouse.x, mouse.y); const tx = Math.floor(ax), ty = Math.floor(ay); const [sx, sy] = toS(tx, ty); const ok = inReach(my, tx, ty, 0.5); g.strokeStyle = ok ? 'rgba(255,240,200,.75)' : 'rgba(255,255,255,.18)'; g.lineWidth = 1.5; g.strokeRect(sx + 0.5, sy + 0.5, TS - 1, TS - 1); }
      // 조명
      const lights = [];
      for (let s = 0; s < (st ? st.np : 0); s++) { const p = V.P[s]; if (!p || p.dead || p.x === undefined) continue; const hid = p.local ? (p.inv[p.sel] ? p.inv[p.sel][0] : -1) : p.held; const torch = hid === IX.torch; const lamp = p.local && p.st && p.st.light; lights.push([p.x, p.y - 1.5, torch ? 1 : lamp ? 0.85 : 0.32, torch ? 0.85 : lamp ? 0.8 : 0.3, torch ? 0.6 : lamp ? 0.6 : 0.28]); }
      for (const s in Cs) for (const q of Cs[s].pjs) if (q.k === 'fire' || q.k === 'star' || q.k === 'spark' || q.k === 'beam' || q.k === 'ice' || q.fire) lights.push([q.x, q.y, 0.8, 0.6, 0.4]);
      for (const j of V.pj) lights.push([j.x, j.y, 0.7, 0.4, 0.5]);
      for (const e of V.en) if (EN[e.t].glow) lights.push([e.x, e.y - e.h / 2, 0.7, 0.4, 0.3]);
      if (V.boss) lights.push([V.boss.x, V.boss.y - (V.boss.b === 0 ? 2 : 0), 0.9, 0.7, 0.7]);
      const lc = computeLight(x0, y0, vw, vh, lights);
      g.globalCompositeOperation = 'multiply'; g.imageSmoothingEnabled = true;
      g.drawImage(lc, ox - TS / 2, oy - TS / 2, vw * TS, vh * TS);
      g.globalCompositeOperation = 'source-over'; g.imageSmoothingEnabled = false;
      if (V.boss) drawBoss(g, V.boss, toS, TS, t);
      if (oreSeen) for (let ty = 0; ty < vh; ty++) for (let tx = 0; tx < vw; tx++) { const x = x0 + tx, y = y0 + ty; if (x < 0 || y < 0 || x >= W.w || y >= W.h) continue; const tt = W.t[y * W.w + x]; if (TL[tt].ore || tt === T_.lcrys) { g.globalAlpha = 0.5 + 0.3 * Math.sin(t * 4 + x); g.drawImage(atlas.t[tt][0], ox + tx * TS, oy + ty * TS); g.globalAlpha = 1; } }
      // 숫자
      for (const n of nums) { const [sx, sy] = toS(n.x, n.y); g.globalAlpha = clamp(1.5 - n.t, 0, 1); g.font = '800 ' + Math.round((n.big ? 17 : 13) * k) + 'px ' + MONO; g.textAlign = 'center'; g.fillStyle = 'rgba(0,0,0,.6)'; g.fillText(String(n.v), sx + 1, sy - n.t * 30 + 1); g.fillStyle = n.c; g.fillText(String(n.v), sx, sy - n.t * 30); } g.globalAlpha = 1;
      g.restore();
      if (hurtA > 0) { g.fillStyle = 'rgba(200,30,30,' + hurtA * 0.35 + ')'; g.fillRect(0, 0, w, h); }
      drawHUD(g, w, h, k, t);
      if (ui.map) drawBigMap(g, w, h, k);
    }
    function drawPlayer(g, p, s, t, k) {
      const [sx, sy] = toS(p.x, p.y);
      const armIds = p.local ? p.arm.map((a) => (a ? a[0] : -1)) : String(p.armS || '').split('.').map(Number);
      const ac = (q) => (armIds[q] >= 0 && IT[armIds[q]] ? IT[armIds[q]].col : null);
      if (p.iv > 0 && Math.floor(t * 12) % 2) g.globalAlpha = 0.5;
      drawHuman(g, sx, sy, TS, { dir: p.dir, walk: p.anim || p.x * 2, moving: Math.abs(p.vx || 0) > 0.5, shirt: ac(1) || COL(s), pants: ac(2) || '#3a3a5a', helm: ac(0), hair: ['#4a3020', '#2a2a2a', '#c89a4a', '#8a3a2a'][s % 4], trim: ac(1) ? COL(s) : null });
      g.globalAlpha = 1;
      // 손에 든 것
      const hid = p.local ? (p.inv[p.sel] ? p.inv[p.sel][0] : -1) : p.held;
      const it = hid >= 0 ? IT[hid] : null;
      const hx = sx + p.dir * TS * 0.35, hy = sy - TS * 1.7;
      if (it) {
        if (p.local && p.sw) drawHeld(g, it, hx, hy, p.sw.ang, TS, p.sw.len);
        else if (!p.local && fin(p.swA)) drawHeld(g, it, hx, hy, p.swA, TS, it.rch || 1.8);
        else if (it.c === 'ranged' || it.c === 'magic' || it.c === 'summon') { const a = p.local && fin(p.aim) ? p.aim : p.dir > 0 ? -0.3 : Math.PI + 0.3; drawHeld(g, it, hx, hy, a - Math.PI / 4 + 0.6, TS, 1); }
        else if (it.c === 'light') { g.drawImage(itemIcon(hid, 32), hx - TS * 0.3, hy - TS * 0.8, TS * 0.7, TS * 0.7); }
      }
      if (st && (st.np > 1 || api.online)) { g.font = '700 ' + Math.round(11 * k) + 'px ' + BODY; g.textAlign = 'center'; g.fillStyle = 'rgba(0,0,0,.5)'; const nm = (st.nm && st.nm[s]) || P(s).name; const tw = g.measureText(nm).width + 8; g.fillRect(sx - tw / 2, sy - TS * 3.35 - 13 * k, tw, 15 * k); g.fillStyle = COL(s); g.fillText(nm, sx, sy - TS * 3.35 - 2 * k); }
    }
    function drawMinion(g, m, sx, sy, t) {
      const s = TS;
      if (m.k === 'slime') { g.fillStyle = 'rgba(90,180,255,.85)'; g.beginPath(); g.ellipse(sx, sy, s * 0.45, s * 0.35, 0, 0, TAU); g.fill(); g.fillStyle = '#111'; g.fillRect(sx - 3, sy - 3, 2, 2); g.fillRect(sx + 2, sy - 3, 2, 2); return; }
      if (m.k === 'bat') { const fl = Math.sin(t * 18) * 0.4; g.fillStyle = '#7a5a9a'; g.beginPath(); g.ellipse(sx, sy, s * 0.2, s * 0.28, 0, 0, TAU); g.moveTo(sx, sy); g.lineTo(sx - s * 0.7, sy - s * (0.4 + fl)); g.lineTo(sx - s * 0.4, sy + s * 0.1); g.moveTo(sx, sy); g.lineTo(sx + s * 0.7, sy - s * (0.4 + fl)); g.lineTo(sx + s * 0.4, sy + s * 0.1); g.fill(); return; }
      if (m.k === 'imp') { const gr = g.createRadialGradient(sx, sy, 1, sx, sy, s * 0.7); gr.addColorStop(0, '#fff2a0'); gr.addColorStop(0.5, '#ff7a30'); gr.addColorStop(1, 'rgba(255,80,20,0)'); g.fillStyle = gr; g.beginPath(); g.arc(sx, sy, s * 0.7, 0, TAU); g.fill(); return; }
      g.fillStyle = '#e8dcff'; g.beginPath(); for (let q = 0; q < 10; q++) { const a = t * 4 + q * Math.PI / 5, r = q % 2 ? s * 0.2 : s * 0.5; g.lineTo(sx + Math.cos(a) * r, sy + Math.sin(a) * r); } g.fill();
    }
    function drawPj(g, kd, x, y, vx, vy, col, t) {
      const [sx, sy] = toS(x, y), a = Math.atan2(vy, vx), s = TS;
      g.save(); g.translate(sx, sy); g.rotate(a);
      switch (kd) {
        case 'arrow': g.strokeStyle = col || '#d8c090'; g.lineWidth = 2; g.beginPath(); g.moveTo(-s * 0.6, 0); g.lineTo(s * 0.4, 0); g.stroke(); g.fillStyle = '#ddd'; g.beginPath(); g.moveTo(s * 0.55, 0); g.lineTo(s * 0.3, -3); g.lineTo(s * 0.3, 3); g.fill(); break;
        case 'fire': { const gr = g.createRadialGradient(0, 0, 1, 0, 0, s * 0.5); gr.addColorStop(0, '#fff2a0'); gr.addColorStop(0.5, '#ff7a30'); gr.addColorStop(1, 'rgba(255,80,20,0)'); g.fillStyle = gr; g.beginPath(); g.arc(0, 0, s * 0.5, 0, TAU); g.fill(); break; }
        case 'ice': g.fillStyle = '#c8f0ff'; g.beginPath(); g.moveTo(s * 0.5, 0); g.lineTo(-s * 0.3, -s * 0.18); g.lineTo(-s * 0.3, s * 0.18); g.fill(); break;
        case 'spark': g.strokeStyle = '#fff6a0'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(-s * 0.8, 0); for (let q = 0; q < 4; q++) g.lineTo(-s * 0.6 + q * s * 0.4, (q % 2 ? 1 : -1) * s * 0.18); g.stroke(); break;
        case 'star': case 'beam': g.fillStyle = kd === 'beam' ? 'rgba(200,184,255,.85)' : '#ffe680'; g.beginPath(); for (let q = 0; q < 10; q++) { const b = t * 8 + q * Math.PI / 5, r = q % 2 ? s * 0.18 : s * 0.45; g.lineTo(Math.cos(b) * r, Math.sin(b) * r); } g.fill(); break;
        case 'water': g.fillStyle = 'rgba(120,190,255,.9)'; g.beginPath(); g.arc(0, 0, s * 0.3, 0, TAU); g.fill(); break;
        case 'boom': g.rotate(t * 20); g.strokeStyle = '#9a8a7a'; g.lineWidth = 4; g.beginPath(); g.moveTo(-s * 0.4, -s * 0.3); g.lineTo(0, 0); g.lineTo(-s * 0.4, s * 0.3); g.stroke(); break;
        case 'thorn': g.fillStyle = '#c8e040'; g.beginPath(); g.moveTo(s * 0.35, 0); g.lineTo(-s * 0.25, -s * 0.1); g.lineTo(-s * 0.25, s * 0.1); g.fill(); break;
        default: g.fillStyle = '#fff'; g.fillRect(-2, -2, 4, 4);
      }
      g.restore();
    }
    function drawHostile(g, j, t) {
      const [sx, sy] = toS(j.x, j.y), s = TS;
      if (j.k === 'laser') { const [ex, ey] = toS(j.x + j.vx * 70, j.y + j.vy * 70); g.strokeStyle = j.warn > 0 ? 'rgba(255,120,200,.45)' : 'rgba(255,240,255,.95)'; g.lineWidth = j.warn > 0 ? 2 : s * 0.9; if (j.warn > 0) g.setLineDash([8, 6]); g.beginPath(); g.moveTo(sx, sy); g.lineTo(ex, ey); g.stroke(); g.setLineDash([]); if (!(j.warn > 0)) { g.strokeStyle = 'rgba(200,120,255,.6)'; g.lineWidth = s * 1.6; g.beginPath(); g.moveTo(sx, sy); g.lineTo(ex, ey); g.stroke(); } return; }
      const c = { thorn: '#c8e040', feather: '#f0f4ff', fireb: '#ff7a30', spike: '#b8a890', shadow: '#9a5ad0', icebolt: '#a0e8ff', starb: '#e8dcff', bolt: '#ff6aa0', bone: '#e8e0c8', lavab: '#ff5a10' }[j.k] || '#fff';
      const r = j.k === 'fireb' || j.k === 'lavab' ? s * 0.45 : j.k === 'shadow' ? s * 0.4 : s * 0.28;
      const gr = g.createRadialGradient(sx, sy, 1, sx, sy, r * 1.8); gr.addColorStop(0, '#fff'); gr.addColorStop(0.35, c); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(sx, sy, r * 1.8, 0, TAU); g.fill();
      void t;
    }
    function slot(g, x, y, S, s, sel, k, lab, kind, idx, emptyIcon) {
      g.fillStyle = sel ? 'rgba(227,174,69,.42)' : 'rgba(24,20,34,.72)'; rr(g, x, y, S, S, 6 * k); g.fill();
      g.strokeStyle = sel ? '#e3ae45' : 'rgba(255,255,255,.18)'; g.lineWidth = sel ? 2 : 1; g.stroke();
      if (s && s[0] !== 'pending') { g.drawImage(itemIcon(s[0], 32), x + S * 0.14, y + S * 0.14, S * 0.72, S * 0.72); if (s[1] > 1) { g.font = '700 ' + Math.round(11 * k) + 'px ' + MONO; g.textAlign = 'right'; g.fillStyle = '#000'; g.fillText(String(s[1]), x + S - 3 * k + 1, y + S - 4 * k + 1); g.fillStyle = '#fff'; g.fillText(String(s[1]), x + S - 3 * k, y + S - 4 * k); } }
      else if (emptyIcon) { g.globalAlpha = 0.25; g.font = Math.round(16 * k) + 'px ' + BODY; g.textAlign = 'center'; g.fillStyle = '#fff'; g.fillText(emptyIcon, x + S / 2, y + S * 0.64); g.globalAlpha = 1; }
      if (lab) { g.font = '700 ' + Math.round(10 * k) + 'px ' + MONO; g.textAlign = 'left'; g.fillStyle = 'rgba(255,255,255,.7)'; g.fillText(lab, x + 3 * k, y + 11 * k); }
      if (kind) ui.regions.push({ x, y, w: S, h: S, kind, k: idx });
    }
    function button(g, x, y, w2, h2, text, k, fn, on) { g.fillStyle = on ? '#e3ae45' : 'rgba(46,38,64,.92)'; rr(g, x, y, w2, h2, 6 * k); g.fill(); g.strokeStyle = 'rgba(255,255,255,.2)'; g.lineWidth = 1; g.stroke(); g.font = '700 ' + Math.round(12 * k) + 'px ' + BODY; g.textAlign = 'center'; g.fillStyle = on ? '#17131f' : '#f2e9d8'; g.fillText(text, x + w2 / 2, y + h2 / 2 + 4 * k); ui.regions.push({ x, y, w: w2, h: h2, kind: 'btn', fn }); }
    function txt(g, s, x, y, size, col, align, wgt) { g.font = (wgt || 600) + ' ' + Math.round(size) + 'px ' + BODY; g.textAlign = align || 'left'; g.fillStyle = 'rgba(0,0,0,.55)'; g.fillText(s, x + 1, y + 1); g.fillStyle = col || '#f2e9d8'; g.fillText(s, x, y); }
    function panel(g, x, y, w2, h2, k) { g.fillStyle = 'rgba(18,14,26,.86)'; rr(g, x, y, w2, h2, 10 * k); g.fill(); g.strokeStyle = 'rgba(227,174,69,.45)'; g.lineWidth = 1.5; g.stroke(); }
    function clock(tm) { const hr = (6 + tm * 24) % 24, h2 = Math.floor(hr), m = Math.floor((hr - h2) * 60 / 10) * 10; return (h2 < 12 ? '오전 ' : '오후 ') + ((h2 % 12) || 12) + ':' + String(m).padStart(2, '0'); }
    let tipLines = null;
    function drawHUD(g, w, h, k, t) {
      ui.regions = []; tipLines = null;
      const S = Math.round(42 * k), gap = Math.round(4 * k), x0 = Math.round(12 * k), y0 = Math.round(12 * k);
      if (my) {
        // 핫바
        for (let q = 0; q < HOT; q++) slot(g, x0 + q * (S + gap), y0, S, my.inv[q], q === my.sel, k, String((q + 1) % 10), 'inv', q);
        const it = heldItem(my);
        if (!ui.inv) txt(g, it ? it.n : '빈 손', x0, y0 + S + 16 * k, 13 * k, '#ffe8a0', 'left', 700);
        // 정보 줄
        const z = zoneOf(W, my.x, my.y), dep = Math.round(my.y - W.surf[clamp(Math.floor(my.x), 0, W.w - 1)]);
        const info = (V.tm < NIGHT0 ? '☀ ' : '☾ ') + clock(V.tm) + ' · ' + V.day + '일째 · ' + (z === 'surface' ? BIO_N[W.bio[clamp(Math.floor(my.x), 0, W.w - 1)]] : ZONE_N[z]) + ' · ' + (dep > 0 ? '깊이 ' + dep : '높이 ' + -dep) + ' · 동전 ' + L.fmt.num(countItem(my.inv, IX.coin));
        if (!ui.inv) txt(g, info, x0, y0 + S + 34 * k, 12 * k, '#cfc4dc');
        // 체력·마나
        const bw = Math.round(250 * k), bx = w - bw - 12 * k, by = y0;
        const mpMax = my.mpM + ((my.st && my.st.mana) | 0);
        g.fillStyle = 'rgba(0,0,0,.55)'; rr(g, bx, by, bw, 20 * k, 6 * k); g.fill(); g.fillStyle = '#d8344f'; rr(g, bx + 2, by + 2, Math.max(0, (bw - 4) * clamp(my.hp / my.hpM, 0, 1)), 20 * k - 4, 5 * k); g.fill();
        txt(g, '체력 ' + Math.ceil(my.hp) + ' / ' + my.hpM, bx + bw / 2, by + 15 * k, 12 * k, '#fff', 'center', 700);
        g.fillStyle = 'rgba(0,0,0,.55)'; rr(g, bx, by + 24 * k, bw, 16 * k, 6 * k); g.fill(); g.fillStyle = '#4a7aff'; rr(g, bx + 2, by + 24 * k + 2, Math.max(0, (bw - 4) * clamp(my.mp / mpMax, 0, 1)), 16 * k - 4, 5 * k); g.fill();
        txt(g, '마나 ' + Math.floor(my.mp) + ' / ' + mpMax, bx + bw / 2, by + 36 * k, 11 * k, '#fff', 'center', 700);
        if (my.br < 10) { txt(g, '숨 ' + '●'.repeat(Math.ceil(my.br)), bx, by + 56 * k, 12 * k, '#9ad8ff'); }
        // 효과
        let fx2 = bx; const fy = by + (my.br < 10 ? 64 : 46) * k;
        for (const kk in my.bf) { const B2 = BUFF[kk]; if (!B2 || !B2[0]) continue; const label = B2[0] + ' ' + Math.ceil(my.bf[kk]) + '초'; g.font = '600 ' + Math.round(11 * k) + 'px ' + BODY; const tw = g.measureText(label).width + 10 * k; g.fillStyle = kk === 'fire' || kk === 'slow' || kk === 'sick' ? 'rgba(140,40,40,.75)' : 'rgba(40,80,60,.75)'; rr(g, fx2, fy, tw, 18 * k, 5 * k); g.fill(); txt(g, label, fx2 + 5 * k, fy + 13 * k, 11 * k, '#fff'); ui.regions.push({ x: fx2, y: fy, w: tw, h: 18 * k, kind: 'tip', tip: [B2[0], B2[1]] }); fx2 += tw + 4 * k; if (fx2 > w - 60 * k) break; }
        // 작은 지도
        if (!ui.map && !ui.inv) drawMiniMap(g, w - bw - 12 * k, fy + 26 * k, bw, Math.round(130 * k), k);
        if (my.dead) { g.fillStyle = 'rgba(20,0,0,.45)'; g.fillRect(0, 0, w, h); txt(g, '쓰러졌어요', w / 2, h / 2 - 10 * k, 34 * k, '#ff8a7a', 'center', 800); txt(g, Math.ceil(my.dead) + '초 뒤에 되살아나요', w / 2, h / 2 + 22 * k, 16 * k, '#f2e9d8', 'center'); }
        if (ui.inv) drawInventory(g, w, h, k, S, gap, x0, y0);
      } else {
        txt(g, me < 0 ? (api.online ? '관전 중 — 자리가 없어요' : 'AI 개척자 시연 중') : '', x0, y0 + 16 * k, 15 * k, '#e3ae45', 'left', 700);
        txt(g, (V.tm < NIGHT0 ? '☀ ' : '☾ ') + clock(V.tm) + ' · ' + V.day + '일째', x0, y0 + 36 * k, 12 * k, '#cfc4dc');
        drawMiniMap(g, w - Math.round(250 * k) - 12 * k, y0, Math.round(250 * k), Math.round(130 * k), k);
      }
      // 사건
      if (V.ev) { const s = V.ev === 'b' ? '🌕 붉은 달밤' : '⚔ 약탈단 습격 — 남은 적 ' + String(V.ev).slice(1); txt(g, s, w / 2, 24 * k, 15 * k, V.ev === 'b' ? '#ff6a6a' : '#ffb060', 'center', 800); }
      // 보스 막대
      if (V.boss && V.boss.hp > 0) { const B = BOSS[V.boss.b], bw = Math.min(w - 40 * k, 560 * k), bx = w / 2 - bw / 2, by = h - 46 * k; g.fillStyle = 'rgba(0,0,0,.65)'; rr(g, bx, by, bw, 22 * k, 7 * k); g.fill(); g.fillStyle = V.boss.ph === 2 ? '#ff5a3a' : '#c8344f'; rr(g, bx + 2, by + 2, (bw - 4) * clamp(V.boss.hp / V.boss.hpM, 0, 1), 22 * k - 4, 6 * k); g.fill(); txt(g, B.n + ' — ' + L.fmt.num(Math.max(0, V.boss.hp)) + ' / ' + L.fmt.num(V.boss.hpM), w / 2, by + 16 * k, 13 * k, '#fff', 'center', 800); }
      // 큰 알림
      if (banner) { banner.a -= 1 / 60; const al = clamp(banner.a, 0, 1); g.globalAlpha = al; txt(g, banner.t, w / 2, h * 0.3, 40 * k, '#ffd257', 'center', 900); txt(g, banner.sub, w / 2, h * 0.3 + 30 * k, 16 * k, '#f2e9d8', 'center'); g.globalAlpha = 1; if (banner.a <= 0) banner = null; }
      // 소식
      let my2 = h - 18 * k - (V.boss ? 50 * k : 0);
      for (let q = msgs.length - 1; q >= 0; q--) { const m = msgs[q]; m.a -= 1 / 60; if (m.a <= 0) continue; g.globalAlpha = clamp(m.a, 0, 1); txt(g, m.t, x0, my2, 13 * k, m.c); my2 -= 18 * k; } g.globalAlpha = 1;
      msgs = msgs.filter((m) => m.a > 0);
      // 주운 것
      let py2 = h * 0.62; for (const pk of pickups) { pk.t += 1 / 60; g.globalAlpha = clamp(2 - pk.t, 0, 1); txt(g, '+' + pk.n + ' ' + IT[pk.id].n, w / 2 + 40 * k, py2, 13 * k, '#ffe8a0', 'left', 700); py2 -= 18 * k; } g.globalAlpha = 1; pickups = pickups.filter((p) => p.t < 2).slice(-6);
      // 손에 쥔 것(커서)
      if (ui.cur && mouse.on) { g.drawImage(itemIcon(ui.cur[0], 32), mouse.x + 4, mouse.y + 4, S * 0.75, S * 0.75); if (ui.cur[1] > 1) txt(g, String(ui.cur[1]), mouse.x + S * 0.8, mouse.y + S * 0.8, 11 * k, '#fff', 'right', 700); }
      // 덮개 판정·툴팁
      const r = mouse.on ? slotAt(mouse.x, mouse.y) : null;
      overUI = !!r || (ui.inv && mouse.y < invBottom && mouse.x < invRight);
      if (r && !ui.cur) {
        if (r.tip) tipLines = r.tip;
        else if (r.kind === 'craft') { const R2 = RC[r.k]; const it2 = IT[R2.o]; tipLines = [it2.n + (R2.n > 1 ? ' ×' + R2.n : ''), CATN[it2.c] || ''].concat(itemLines(it2)).concat(['재료: ' + R2.in.map(([id, n]) => IT[id].n + ' ' + n + ' (' + countItem(my.inv, id) + ')').join(', '), '장소: ' + (R2.at ? ST_N[R2.at] : '맨손'), '클릭: 만들기 · Shift+클릭: 10개']); }
        else if (r.kind === 'shop') { const N2 = NPC[V.npcs[ui.npc].k], s2 = N2.shop[r.k], it2 = IT[IX[s2[0]]]; tipLines = [it2.n, CATN[it2.c] || ''].concat(itemLines(it2)).concat(['값: 동전 ' + s2[1], '클릭: 사기 · Shift+클릭: 10개']); }
        else if (r.kind === 'trash') tipLines = ['쓰레기통', '물건을 놓으면 버려져요(다시 꺼낼 수 있는 건 마지막 하나뿐)'];
        else if (r.kind !== 'btn') { const arr = arrOf(r.kind); const s2 = arr && arr[r.k]; if (s2 && s2[0] !== 'pending') { const it2 = IT[s2[0]]; tipLines = [it2.n + (s2[1] > 1 ? ' (' + s2[1] + ')' : ''), CATN[it2.c] || ''].concat(itemLines(it2)); if (r.kind === 'inv' && it2.c === 'armor') tipLines.push('오른쪽 클릭: 입기'); if (r.kind === 'inv' && it2.c === 'acc') tipLines.push('오른쪽 클릭: 끼기'); if (ui.shop && r.kind === 'inv' && s2[0] !== IX.coin) tipLines.push('오른쪽 클릭: 팔기 (동전 ' + Math.max(1, Math.floor(it2.v * s2[1] / 5)) + ')'); const src = sourcesOf(s2[0]); if (src.length && (it2.c === 'mat' || it2.c === 'block')) tipLines.push('얻는 곳: ' + src.slice(0, 3).join(' · ')); } else if (r.kind === 'arm') tipLines = [['머리 갑옷', '몸 갑옷', '다리 갑옷'][r.k], '같은 재료 3부위를 모두 입으면 세트 효과']; else if (r.kind === 'acc') tipLines = ['장신구 칸', '같은 장신구는 하나만 껴요']; }
      }
      if (tipLines) drawTip(g, tipLines, mouse.x + 16, mouse.y + 18, k, w, h);
      void t;
    }
    let invBottom = 0, invRight = 0;
    function drawInventory(g, w, h, k, S, gap, x0, y0) {
      const rowY = (r) => y0 + S + 8 * k + (r - 1) * (S + gap);
      panel(g, x0 - 6 * k, y0 + S + 3 * k, 10 * (S + gap) + 8 * k, 4 * (S + gap) + 8 * k, k);
      for (let r = 1; r < 5; r++) for (let c = 0; c < 10; c++) { const q = r * 10 + c; slot(g, x0 + c * (S + gap), rowY(r), S, my.inv[q], false, k, null, 'inv', q); }
      const ex = x0 + 10 * (S + gap) + 14 * k;
      const S2 = my.st || calcStats(my);
      txt(g, '갑옷 · 방어 ' + S2.def + (S2.set ? ' · 세트: ' + SETS[S2.set].n : ''), ex, y0 + 14 * k, 12 * k, '#e3ae45', 'left', 700);
      for (let q = 0; q < 3; q++) slot(g, ex, y0 + 22 * k + q * (S + gap), S, my.arm[q], false, k, null, 'arm', q, ['⛑', '👕', '👖'][q]);
      for (let q = 0; q < 5; q++) slot(g, ex + S + gap, y0 + 22 * k + q * (S + gap), S, my.acc[q], false, k, null, 'acc', q, '◇');
      slot(g, ex, y0 + 22 * k + 3 * (S + gap), S, ui.trash, false, k, null, 'trash', 0, '🗑');
      const lineY = y0 + 22 * k + 5 * (S + gap) + 12 * k;
      if (S2.set) txt(g, SETS[S2.set].sb, ex, lineY, 11 * k, '#9ae07a');
      invBottom = rowY(5) + 4 * k; invRight = ex + 2 * (S + gap) + 8 * k;
      // 제작
      const sts = stationsNear(W, my);
      const cy = rowY(5) + 14 * k;
      const avail = []; RC.forEach((r, ri) => { if (canCraft(my.inv, r, sts) >= 1) avail.push(ri); });
      const nearN = Object.keys(sts).map((q) => ST_N[q]).join('·') || '없음';
      const cols = 10, rowsV = 2, CS = Math.round(S * 0.92);
      panel(g, x0 - 6 * k, cy - 6 * k, 10 * (S + gap) + 8 * k, 26 * k + rowsV * (CS + gap) + 46 * k, k);
      txt(g, '제작 — 만들 수 있는 것 ' + avail.length + '개 (가까운 곳: ' + nearN + ')', x0, cy + 12 * k, 12 * k, '#e3ae45', 'left', 700);
      const maxS = Math.max(0, Math.ceil(avail.length / cols) - rowsV); ui.cs = clamp(ui.cs, 0, maxS);
      ui.regions.push({ x: x0, y: cy + 18 * k, w: cols * (CS + gap), h: rowsV * (CS + gap), kind: 'craftArea' });
      for (let q = 0; q < cols * rowsV; q++) { const ri = avail[ui.cs * cols + q]; if (ri === undefined) break; const r = RC[ri]; const xx = x0 + (q % cols) * (CS + gap), yy = cy + 20 * k + Math.floor(q / cols) * (CS + gap); slot(g, xx, yy, CS, [r.o, r.n], false, k, null, 'craft', ri); }
      if (!avail.length) txt(g, '재료를 모으거나 작업대 곁으로 가 보세요.', x0, cy + 40 * k, 12 * k, '#ab9fb8');
      if (maxS > 0) txt(g, '휠로 넘기기 ' + (ui.cs + 1) + '/' + (maxS + 1), x0 + 10 * (S + gap) - 6 * k, cy + 12 * k, 11 * k, '#ab9fb8', 'right');
      const by = cy + 22 * k + rowsV * (CS + gap);
      const kb = kl('book');
      button(g, x0, by, Math.round(170 * k), Math.round(36 * k), '📖 레시피 책' + (kb ? ' (' + kb + ')' : ''), k, () => openBook());
      const kh = kl('house');
      button(g, x0 + 178 * k, by, Math.round(190 * k), Math.round(36 * k), '🏠 커서 칸 집 확인' + (kh ? ' (' + kh + ')' : ''), k, () => toast('지도에서 방 안의 빈 칸에 마우스를 두고 ' + (kh || 'G') + ' 키를 눌러요'));
      button(g, x0 + 376 * k, by, Math.round(80 * k), Math.round(36 * k), '정리', k, () => { sortInv(); });
      // 상자 / 정착민
      const px = invRight + 10 * k;
      if (ui.chest >= 0) {
        if (host() && G) ui.chestC = chestOf(G, ui.chest);
        if (!host() && !ui.chestC) ui.chestC = new Array(CHEST_N).fill(null);
        const cx2 = ui.chest % W.w, cy2 = (ui.chest / W.w) | 0;
        if (W.t[ui.chest] !== T_.chest || Math.hypot(cx2 + 0.5 - my.x, cy2 - my.y) > 9) { ui.chest = -1; ui.chestC = null; doAct(me, ['cc']); }
        else {
          panel(g, px - 6 * k, y0 - 4 * k, 6 * (S + gap) + 8 * k, 5 * (S + gap) + 64 * k, k);
          txt(g, '상자 (Shift+클릭: 빠르게 옮기기)', px, y0 + 12 * k, 12 * k, '#e3ae45', 'left', 700);
          for (let q = 0; q < CHEST_N; q++) slot(g, px + (q % 6) * (S + gap), y0 + 20 * k + Math.floor(q / 6) * (S + gap), S, ui.chestC[q], false, k, null, 'chest', q);
          const bby = y0 + 24 * k + 5 * (S + gap);
          button(g, px, bby, Math.round(120 * k), Math.round(34 * k), '모두 넣기', k, () => { for (let q = HOT; q < INV; q++) { const s = my.inv[q]; if (s && s[0] !== IX.coin) { chestPut(-1, s[0], s[1]); my.inv[q] = null; } } });
          button(g, px + 128 * k, bby, Math.round(120 * k), Math.round(34 * k), '모두 꺼내기', k, () => { const c = ui.chestC; for (let q = 0; q < CHEST_N; q++) { const s = c[q]; if (!s || s[0] === 'pending') continue; if (host()) { const left = addItem(my.inv, s[0], s[1]); c[q] = left ? [s[0], left] : null; } else { doAct(me, ['ct', ui.chest, q, s[0], s[1]]); c[q] = null; } } });
        }
      } else if (ui.npc >= 0 && V.npcs[ui.npc]) {
        const n = V.npcs[ui.npc], N2 = NPC[n.k];
        if (Math.hypot(n.x - my.x, n.y - my.y) > 10) { ui.npc = -1; ui.shop = false; }
        else {
          const pw = Math.round(420 * k);
          const say2 = (NPC_TALK[N2.k] || (() => '…'))(W, my);
          const lines = wrapText(g, say2, pw - 24 * k, 13 * k);
          const ph = 60 * k + lines.length * 18 * k + 44 * k + (ui.shop ? Math.ceil(N2.shop.length / 6) * (S + gap) + 24 * k : 0);
          panel(g, px - 6 * k, y0 - 4 * k, pw, ph, k);
          txt(g, N2.n + (n.home ? '' : ' (집 없음)'), px + 6 * k, y0 + 16 * k, 16 * k, N2.col, 'left', 800);
          lines.forEach((ln, q) => txt(g, ln, px + 6 * k, y0 + 40 * k + q * 18 * k, 13 * k, '#f2e9d8'));
          const bby = y0 + 40 * k + lines.length * 18 * k + 2 * k;
          let bx2 = px + 6 * k;
          if (N2.shop.length) { button(g, bx2, bby, Math.round(90 * k), Math.round(36 * k), '가게', k, () => { ui.shop = !ui.shop; }, ui.shop); bx2 += 98 * k; }
          if (N2.heal) { const c = healCost(my); button(g, bx2, bby, Math.round(150 * k), Math.round(36 * k), '치료 (동전 ' + c + ')', k, () => { if (my.hp >= my.hpM) return; if (countItem(my.inv, IX.coin) < c) { toast('동전이 모자라요'); return; } takeItem(my.inv, IX.coin, c); my.hp = my.hpM; delete my.bf.fire; Snd.play('drink'); }); bx2 += 158 * k; }
          if (N2.k === 'guide') { button(g, bx2, bby, Math.round(150 * k), Math.round(36 * k), '든 물건으로 뭘 만들까', k, () => { const s = my.inv[my.sel]; if (!s) { toast('먼저 핫바에서 물건을 골라 주세요'); return; } bookQ = IT[s[0]].n; openBook(); }); bx2 += 158 * k; }
          button(g, bx2, bby, Math.round(70 * k), Math.round(36 * k), '닫기', k, () => { ui.npc = -1; ui.shop = false; });
          if (ui.shop) { const sy = bby + 44 * k; N2.shop.forEach((s2, q) => { const it2 = IX[s2[0]]; const xx = px + 6 * k + (q % 6) * (S + gap), yy = sy + Math.floor(q / 6) * (S + gap); slot(g, xx, yy, S, [it2, 1], false, k, null, 'shop', q); txt(g, String(s2[1]), xx + S / 2, yy + S - 3 * k, 10 * k, '#f2c844', 'center', 700); }); txt(g, '팔기: 가방에서 오른쪽 클릭', px + 6 * k, sy + Math.ceil(N2.shop.length / 6) * (S + gap) + 12 * k, 11 * k, '#ab9fb8'); }
        }
      }
    }
    function sortInv() { const items = my.inv.slice(HOT).filter((s) => s); const merged = []; for (const s of items) addItem(merged, s[0], s[1]); merged.sort((a, b) => (IT[a[0]].c < IT[b[0]].c ? -1 : IT[a[0]].c > IT[b[0]].c ? 1 : a[0] - b[0])); for (let q = HOT; q < INV; q++) my.inv[q] = merged[q - HOT] || null; api.sfx('click'); }
    function wrapText(g, s, maxW, size) { g.font = '600 ' + Math.round(size) + 'px ' + BODY; const out = []; let cur = ''; for (const ch of s.split(' ')) { const tt = cur ? cur + ' ' + ch : ch; if (g.measureText(tt).width > maxW && cur) { out.push(cur); cur = ch; } else cur = tt; } if (cur) out.push(cur); return out; }
    function drawTip(g, lines, x, y, k, w, h) {
      const pad = 8 * k, lh = 17 * k, maxW = 320 * k;
      const all = []; lines.forEach((ln, q) => { if (!ln) return; wrapText(g, ln, maxW, q === 0 ? 14 * k : 12 * k).forEach((l2) => all.push([l2, q])); });
      g.font = '600 ' + Math.round(12 * k) + 'px ' + BODY; let tw = 0; for (const [l2, q] of all) { g.font = (q === 0 ? '800 ' + Math.round(14 * k) : '600 ' + Math.round(12 * k)) + 'px ' + BODY; tw = Math.max(tw, g.measureText(l2).width); }
      const bw = tw + pad * 2, bh = all.length * lh + pad * 1.4;
      if (x + bw > w - 4) x = w - bw - 4; if (y + bh > h - 4) y = h - bh - 4;
      g.fillStyle = 'rgba(14,10,22,.95)'; rr(g, x, y, bw, bh, 7 * k); g.fill(); g.strokeStyle = 'rgba(227,174,69,.6)'; g.lineWidth = 1; g.stroke();
      all.forEach(([l2, q], n) => { g.font = (q === 0 ? '800 ' + Math.round(14 * k) : '600 ' + Math.round(12 * k)) + 'px ' + BODY; g.textAlign = 'left'; g.fillStyle = q === 0 ? '#ffe8a0' : q === 1 ? '#ab9fb8' : '#f2e9d8'; g.fillText(l2, x + pad, y + pad + (n + 0.8) * lh); });
    }
    let mapT = 0;
    function drawMiniMap(g, x, y, mw, mh, k) {
      mapT -= 1 / 60; if (mapDirty && mapT <= 0) { mapCv.getContext('2d').putImageData(mapImg, 0, 0); mapDirty = 0; mapT = 0.5; }
      const sc = 2.2, sw = mw / sc, sh = mh / sc;
      const cx = clamp(cam.x - sw / 2, 0, W.w - sw), cy = clamp(cam.y - sh / 2, 0, W.h - sh);
      g.fillStyle = 'rgba(0,0,0,.6)'; rr(g, x - 2, y - 2, mw + 4, mh + 4, 6 * k); g.fill();
      g.imageSmoothingEnabled = false; g.drawImage(mapCv, cx, cy, sw, sh, x, y, mw, mh);
      const dot = (wx, wy, c, r) => { const sx = x + (wx - cx) * sc, sy = y + (wy - cy) * sc; if (sx < x || sy < y || sx > x + mw || sy > y + mh) return; g.fillStyle = c; g.fillRect(sx - r, sy - r, r * 2, r * 2); };
      for (const n of V.npcs) dot(n.x, n.y - 1, '#ffe8a0', 2);
      if (V.boss) dot(V.boss.x, V.boss.y, '#ff3a3a', 4);
      for (let s = 0; s < (st ? st.np : 0); s++) { const p = V.P[s]; if (p && !p.dead && p.x !== undefined) dot(p.x, p.y - 1, COL(s), 3); }
      const kb = kl('map'); if (kb && L.ui.drawKeyBadge) L.ui.drawKeyBadge(g, x + mw + 2, y + mh + 2, kb, k * 0.9);
    }
    function drawBigMap(g, w, h, k) {
      if (mapDirty) { mapCv.getContext('2d').putImageData(mapImg, 0, 0); mapDirty = 0; }
      g.fillStyle = 'rgba(0,0,0,.75)'; g.fillRect(0, 0, w, h);
      const sc = Math.min((w - 60 * k) / W.w, (h - 100 * k) / W.h), mw = W.w * sc, mh = W.h * sc, x = (w - mw) / 2, y = (h - mh) / 2 + 16 * k;
      g.imageSmoothingEnabled = false; g.drawImage(mapCv, x, y, mw, mh);
      const dot = (wx, wy, c, r) => { g.fillStyle = c; g.fillRect(x + wx * sc - r, y + wy * sc - r, r * 2, r * 2); };
      dot(W.spawn.x, W.spawn.y - 1, '#7ad46a', 4);
      for (const n of V.npcs) dot(n.x, n.y - 1, '#ffe8a0', 3);
      if (V.boss) dot(V.boss.x, V.boss.y, '#ff3a3a', 5);
      const mt = (G && G.meteorAt) || V.mt; if (mt) dot(mt[0], mt[1], '#8a7cff', 5);
      for (let s = 0; s < (st ? st.np : 0); s++) { const p = V.P[s]; if (p && !p.dead && p.x !== undefined) dot(p.x, p.y - 1, COL(s), 4); }
      txt(g, '세계 지도 — 가 본 곳만 보여요 · 초록 출발점 · 노랑 정착민 · 빨강 보스 · 보라 성운석 (' + (kl('map') || 'M') + '로 닫기)', w / 2, y - 12 * k, 14 * k, '#f2e9d8', 'center', 700);
    }

    /* ----- 루프 ----- */
    const stopLoop = U.loop((rdt0) => {
      const rdt = Math.min(0.1, rdt0);
      try {
        if (st && !W && !st.res) { if (genPending++ > 1) startWorld(); }
        if (W && st && !st.res) {
          Iframe = readInput(); firstStep = true;
          if (host()) pollHost(); else pollGuest();
          acc += rdt * SPD(); let n = 0; while (acc >= DT && n < 14) { acc -= DT; n++; step(DT); }
          if (n >= 14) acc = 0;
          for (const p of ptc) { p.t += rdt; p.vy += p.g * rdt; p.x += p.vx * rdt; p.y += p.vy * rdt; }
          ptc = ptc.filter((p) => p.t < p.l);
          for (const n2 of nums) n2.t += rdt; nums = nums.filter((n2) => n2.t < 1.5);
          hurtA = Math.max(0, hurtA - rdt);
          publish(rdt);
          hostEnd();
          ambTick(rdt);
        }
      } catch (e) { console.error(e); }
      try { draw(performance.now() / 1000); } catch (e) { console.error(e); }
    });
    let ambK = '', ambT = 0;
    function ambTick(rdt) { ambT -= rdt; if (ambT > 0 || !L.ambient || !L.ambient.play) return; ambT = 3; const f = my || V.P.find((p) => p) || null; if (!f) return; const z = zoneOf(W, f.x, f.y); const k2 = z === 'surface' || z === 'sky' ? (V.tm < NIGHT0 ? 'forest' : 'night') : z === 'hell' ? 'wind' : 'cave'; if (k2 !== ambK) { ambK = k2; try { L.ambient.play(k2); } catch (e) { /* */ } } }

    /* ----- 시험용 훅 ----- */
    const dbg = {
      G: () => G, W: () => W, me: () => my, V,
      give(k, n) { if (my) addItem(my.inv, IX[k], n || 1); },
      tp(x, y) { if (my) { my.x = x; my.y = y; my.vx = my.vy = 0; } else { cam.x = x; cam.y = y; } },
      under() { const p = my || (G && G.P.find((q) => q && q.local)); if (!p) return; for (let y = Math.floor(W.cav + 10); y < W.hellTop - 4; y++) for (let x = Math.floor(p.x) - 60; x < p.x + 60; x++) { if (x < 5 || x > W.w - 5) continue; if (!boxHits(W, x + 0.5, y + 0.999, PW, PH) && solidAt(W, x, y + 1)) { p.x = x + 0.5; p.y = y + 0.999; p.vx = p.vy = 0; return [x, y]; } } },
      boss(b) { if (!G) return; const p = my || G.P.find((q) => q && q.local); if (p) { G.alive = G.P.filter((q) => q && !q.dead && !q.fresh); bossSpawn(G, b | 0, p); } },
      time(v) { if (G) G.tm = v; },
      inv(open) { ui.inv = open !== false; },
      book() { openBook(); },
      god(v) { if (my) my.god = v !== false; },
      hash() { let hsh = 0; for (let i = 0; i < W.t.length; i++) hsh = (Math.imul(hsh, 31) + W.t[i] * 7 + W.wl[i]) | 0; return hsh; },
      dig(n) { const p = my; if (!p) return 0; let c = 0; for (let q = 0; q < (n || 10); q++) { const x = Math.floor(p.x) + 2 + q, y = Math.floor(p.y) + 1; if (W.t[y * W.w + x]) { doAct(me, ['b', x, y]); c++; } } return c; },
      gen: () => genMs,
    };
    L.debug = L.debug || {}; L.debug.sb = dbg;

    return {
      update(next) {
        if (!next) return;
        const prev = st; st = next;
        if (!prev || prev.rid !== st.rid || prev.seed !== st.seed) { W = null; G = null; genPending = 0; my = null; for (const k in Cs) delete Cs[k]; applied = 0; lastG = 0; lastFx = 0; outbox = []; }
      },
      saveState() {
        if (!host() || !G || !st || st.res) return false;
        st.svd = G.day + '일째 · ' + SIZES[st.sz].n + ' · 보스 ' + G.fl.b.filter((v) => v).length + '/6';
        return { rid: st.rid, g: saveGame(G) };
      },
      loadState(b) {
        if (!b || !b.g || !st || b.rid !== st.rid || !host()) return;
        if (!W) startWorld();
        loadGame(G, b.g);
        const pl = G.loadedPl || []; const out = {};
        for (let s = 0; s < st.np; s++) { const p = G.P[s]; const o = pl[s]; if (!o) continue; if (p && p.local) { loadPlayer(p, o); p.x = (o.sp || W.spawn).x; p.y = (o.sp || W.spawn).y - 0.01; } else { out[s] = o; if (p) p.saved = o; } }
        if (Object.keys(out).length) G.ivOut = { v: (Date.now() / 1000) | 0, s: out };
        for (let i = 0; i < W.w * W.h; i++) if (seen[i]) mapPix(i);
        mapDirty = 1;
        toast('저장한 세계를 이어서 해요 — ' + G.day + '일째');
      },
      destroy() {
        stopLoop(); closeBook();
        if (offIn) offIn();
        window.removeEventListener('keydown', onKeyCap, true); window.removeEventListener('blur', onBlur);
        cv.cv.removeEventListener('pointermove', onMove); cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp); cv.cv.removeEventListener('wheel', onWheel); cv.cv.removeEventListener('contextmenu', noCtx);
        Snd.close(); cv.destroy(); styleEl.remove();
        if (L.debug && L.debug.sb === dbg) delete L.debug.sb;
      },
    };
  }

  /* ======================= 도감 ======================= */
  function icoSVG(col, shape) {
    const c = col || '#ccc';
    if (shape === 'sq') return '<svg viewBox="0 0 16 16" width="28" height="28"><rect x="2" y="2" width="12" height="12" rx="1" fill="' + c + '" stroke="rgba(0,0,0,.35)"/><rect x="4" y="5" width="2" height="2" fill="rgba(0,0,0,.2)"/><rect x="9" y="9" width="3" height="2" fill="rgba(255,255,255,.18)"/></svg>';
    if (shape === 'mob') return '<svg viewBox="0 0 16 16" width="28" height="28"><ellipse cx="8" cy="10" rx="6" ry="5" fill="' + c + '"/><rect x="5" y="8" width="2" height="2" fill="#111"/><rect x="9.5" y="8" width="2" height="2" fill="#111"/></svg>';
    if (shape === 'boss') return '<svg viewBox="0 0 16 16" width="28" height="28"><circle cx="8" cy="8" r="7" fill="' + c + '"/><circle cx="8" cy="8" r="3" fill="#111"/><circle cx="7" cy="7" r="1" fill="#fff"/></svg>';
    if (shape === 'npc') return '<svg viewBox="0 0 16 16" width="28" height="28"><circle cx="8" cy="5" r="3" fill="#e0b088"/><rect x="4.5" y="8" width="7" height="7" rx="1.5" fill="' + c + '"/></svg>';
    return '<svg viewBox="0 0 16 16" width="28" height="28"><path d="M8 1L14 7L8 15L2 7Z" fill="' + c + '"/></svg>';
  }
  function itemCodexIcon(it) {
    if (typeof document === 'undefined') return icoSVG(it.col);
    try { return '<img src="' + itemIcon(it.i, 32).toDataURL() + '" width="28" height="28" style="image-rendering:pixelated" alt="">'; } catch (e) { return icoSVG(it.col); }
  }
  function sbCodex() {
    const rowIt = (it) => ({ icon: itemCodexIcon(it), name: it.n, tag: CATN[it.c] || '', desc: itemLines(it).join(' · ') + (sourcesOf(it.i).length ? ' · 얻는 곳: ' + sourcesOf(it.i).slice(0, 4).join(', ') : '') });
    const by = (cs) => IT.filter((it) => cs.includes(it.c)).map(rowIt);
    return [
      { h: '블록·벽', p: ['캐면 블록이 나와요. 곡괭이 힘이 모자라면 못 캐요.'], rows: TL.filter((t) => t.i && t.col && !(t.f & 8) && !(t.f & 16)).map((t) => ({ icon: icoSVG(t.col, 'sq'), name: t.n, tag: t.ore ? '광석' : SOLIDT[t.i] ? '블록' : '배경', desc: '단단함 ' + t.hp + (t.pk ? ' · 곡괭이 힘 ' + t.pk + ' 이상' : '') + (t.lt ? ' · 빛을 내요' : '') + (t.dr && IX[t.dr] !== undefined ? ' · 캐면: ' + IT[IX[t.dr]].n : '') })).concat(WL.filter((x) => x).map((x) => ({ icon: icoSVG(x.col, 'sq'), name: x.n, tag: '벽', desc: x.nat ? '자연 벽 — 집 벽으로는 안 쳐요' : '직접 붙이는 벽 — 집에 꼭 필요' }))) },
      { h: '도구·무기', rows: by(['pick', 'axe', 'hammer', 'melee', 'ranged', 'magic', 'summon', 'ammo']) },
      { h: '갑옷', p: Object.keys(SETS).map((k) => SETS[k].n + ' 세트: ' + SETS[k].sb), rows: by(['armor']) },
      { h: '장신구', p: ['장신구 칸은 5개. 같은 것은 하나만 껴요. 세공대에서 둘을 합쳐 더 좋게 만들어요.'], rows: by(['acc']) },
      { h: '물약·쓰는 것', rows: by(['potion', 'misc', 'boss']) },
      { h: '재료·가구', rows: by(['mat', 'furn', 'light', 'coin']) },
      { h: '제작법', p: ['모두 ' + RC.length + '가지. 가까운 작업 장소(작업대·화로·모루·연금대·세공대·화염 단조대·별의 작업대)가 있어야 해요.'], rows: RC.map((r) => ({ icon: itemCodexIcon(IT[r.o]), name: IT[r.o].n + (r.n > 1 ? ' ×' + r.n : ''), tag: r.at ? ST_N[r.at] : '맨손', desc: r.in.map(([id, n]) => IT[id].n + ' ' + n).join(' + ') })) },
      { h: '적', rows: EN.map((E) => ({ icon: icoSVG(E.col, 'mob'), name: E.n, tag: E.where, desc: '체력 ' + E.hp + ' · 피해 ' + E.dmg + ' · 방어 ' + E.def + (E.dr.length ? ' · 떨어뜨림: ' + E.dr.map((d) => IT[IX[d[0]]].n + ' ' + Math.round(d[3] * 100) + '%').join(', ') : '') })) },
      { h: '보스', p: ['자리 수가 많을수록 보스 체력이 늘어요. 보스를 쓰러뜨리면 사람마다 전리품을 따로 받아요.'], rows: BOSS.map((B) => ({ icon: icoSVG(B.col, 'boss'), name: B.n, tag: B.title, desc: '체력 ' + B.hp + ' · 피해 ' + B.dmg + ' · 부르기: ' + B.how + ' · 공격: ' + B.pat + ' · 전리품: ' + B.dr.map((d) => IT[IX[d[0]]].n).join(', ') })) },
      { h: '정착민', p: ['집 조건: 둘러막힌 방(40~750칸) · 직접 붙인 배경 벽 · 문 · 횃불·등불 · 탁자 종류 · 의자. 정착민은 다치지 않아요.'], rows: NPC.map((N2) => ({ icon: icoSVG(N2.col, 'npc'), name: N2.n, tag: '이사 조건: ' + N2.how, desc: N2.d + (N2.shop.length ? ' · 파는 것: ' + N2.shop.map((s) => IT[IX[s[0]]].n + ' ' + s[1]).join(', ') : '') })) },
      { h: '세계', rows: [
        { icon: icoSVG('#5cb848', 'sq'), name: '숲', tag: '땅 위', desc: '풀젤리 · 밤엔 밤걸음꾼·밤눈박쥐 · 햇살꽃 · 나무' },
        { icon: icoSVG('#d8c27c', 'sq'), name: '사막', tag: '땅 위', desc: '모래젤리·모래전갈 · 선인장 · 모래꽃' },
        { icon: icoSVG('#e8eff6', 'sq'), name: '눈 지역', tag: '땅 위', desc: '서리젤리 · 침엽수 · 서리꽃 · 땅속 얼음 정령' },
        { icon: icoSVG('#3fae3a', 'sq'), name: '밀림', tag: '땅 위', desc: '늪젤리·가시벌 · 덩굴 · 달빛풀' },
        { icon: icoSVG('#3a6ac8', 'sq'), name: '바다', tag: '세계 양 끝', desc: '이빨물고기 · 깊은 물(숨 조심)' },
        { icon: icoSVG('#7b7b86', 'sq'), name: '땅속·깊은 동굴', tag: '아래로', desc: '동굴박쥐·바위게·뼈광부·수정거미 · 광석은 깊을수록 좋아요 · 생명 수정 · 상자 · 항아리' },
        { icon: icoSVG('#4d4446', 'sq'), name: '지하세계', tag: '맨 아래', desc: '용암 · 잿돌 · 화염철광 · 잿불 마귀·용암 젤리·불꽃박쥐 · 불꽃풀' },
        { icon: icoSVG('#f2f6ff', 'sq'), name: '하늘섬', tag: '맨 위', desc: '구름 위 작은 집과 상자 · 바람깃 사냥꾼' },
        { icon: icoSVG('#ff5a5a', 'sq'), name: '붉은 달밤', tag: '밤 사건', desc: '가끔 밤에 — 적이 많고 세져요(붉은눈 걸음꾼)' },
        { icon: icoSVG('#8a5a3a', 'sq'), name: '약탈단 습격', tag: '낮 사건', desc: '어둠의 응시자 처치 뒤 가끔 — 약탈단 졸개·투척병·주술사를 정해진 수만큼 물리치면 끝 · 약탈단 깃발 조각' },
      ] },
    ];
  }
  function preview(c) {
    const g = c.getContext('2d'), w = c.width, h = c.height;
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#3a6ab8'); gr.addColorStop(1, '#a8d0f0'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const S = 20, surf = (x) => 9 + Math.round(Math.sin(x * 0.35) * 1.5 + Math.sin(x * 0.11) * 2);
    for (let x = 0; x < 32; x++) { const s = surf(x); for (let y = s; y < 18; y++) { const cave = (x - 18) * (x - 18) / 30 + (y - 14) * (y - 14) / 4 < 1; g.fillStyle = cave ? '#2a1e18' : y === s ? '#5cb848' : y < s + 3 ? '#8a5a3a' : (x * 7 + y * 3) % 11 === 0 ? '#c8743c' : (x * 5 + y) % 13 === 0 ? '#f0c43c' : '#7b7b86'; g.fillRect(x * S, y * S, S, S); } }
    const tree = (x) => { const s = surf(x); g.fillStyle = '#7a5230'; g.fillRect(x * S + 5, (s - 6) * S, 10, 6 * S); g.fillStyle = '#3f9a3c'; g.beginPath(); g.arc(x * S + 10, (s - 6.5) * S, 44, 0, TAU); g.fill(); };
    tree(4); tree(26);
    g.fillStyle = '#ffcf5a'; g.beginPath(); g.arc(18 * S, 14 * S, 6, 0, TAU); g.fill();
    const lg = g.createRadialGradient(18 * S, 14 * S, 4, 18 * S, 14 * S, 90); lg.addColorStop(0, 'rgba(255,220,140,.5)'); lg.addColorStop(1, 'rgba(255,220,140,0)'); g.fillStyle = lg; g.fillRect(0, 0, w, h);
    // 사람
    const hx = 13 * S, hy = surf(13) * S; g.fillStyle = '#3a3a5a'; g.fillRect(hx - 6, hy - 18, 5, 18); g.fillRect(hx + 1, hy - 18, 5, 18); g.fillStyle = '#4a7ac8'; g.fillRect(hx - 7, hy - 38, 14, 20); g.fillStyle = '#e8b890'; g.beginPath(); g.arc(hx, hy - 45, 8, 0, TAU); g.fill();
    g.strokeStyle = '#d07a40'; g.lineWidth = 5; g.beginPath(); g.arc(hx + 18, hy - 30, 14, -2.4, -0.6); g.stroke();
    g.fillStyle = 'rgba(74,154,255,.9)'; g.beginPath(); g.ellipse(24 * S, surf(24) * S - 30, 44, 32, 0, 0, TAU); g.fill(); g.fillStyle = '#f2c844'; g.fillRect(24 * S - 16, surf(24) * S - 74, 32, 12);
    g.fillStyle = 'rgba(10,8,16,.7)'; g.fillRect(14, 14, 300, 40); g.fillStyle = '#ffe8a0'; g.font = '700 20px ' + BODY; g.fillText('캐고 · 짓고 · 만들고 · 싸우기', 26, 41);
  }
  function hint(st) {
    if (!st) return null;
    return ['개척 — 캐고 짓고 만들어 보스 여섯을 넘어서기', '마우스 왼쪽: 든 물건 쓰기(캐기·공격·놓기) · 오른쪽: 문·상자·정착민·침대', 'E 가방·제작 · B 레시피 책 · M 지도 · H 치유 물약 · G 커서 칸이 집인지 확인', '처음: 나무 → 작업대 → 횃불(나무+젤리) → 돌 → 화로 → 흑철 주괴 → 모루', '밤에는 집 안으로! 벽·문·횃불·탁자·의자 → 정착민이 이사 와요'];
  }

  L.register({
    id: 'sandbox', name: '2D 샌드박스 개척', tag: '캐기·짓기·제작·모험', cat: '아케이드', coop: true,
    blurb: '씨앗으로 매번 새로 만들어지는 옆모습 세계를 캐고, 짓고, 만들고, 싸우는 개척 게임. 숲·사막·눈·밀림·바다, 깊은 동굴과 지하세계, 하늘섬. 정착민을 맞고 보스 여섯을 넘어서요. 1~4명 협동.',
    tint: '#2a3a1a',
    icon: '<rect x="6" y="30" width="44" height="20" fill="currentColor" opacity=".55"/><rect x="6" y="26" width="44" height="6" fill="currentColor"/><rect x="34" y="38" width="6" height="6" fill="currentColor" opacity=".9"/><path d="M14 26V12M14 12c-6 0-8-6-2-8 2-4 8-2 8 2 4 2 2 8-6 6z" stroke="currentColor" stroke-width="3" fill="none"/><path d="M30 22l12-12M36 8c6-2 10 2 10 8" stroke="currentColor" stroke-width="3.5" fill="none" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 1, hidden: false, realtime: true, aiDelay: 0, landscape: true, pcOnly: true, contextMenu: true, sidePanel: false, autoPause: true,
    save: true, mood: 'folk', ambient: 'forest', time: '30분~수십 시간',
    saveLabel: (st) => (st && st.svd ? st.svd : '개척 중'),
    options: [
      { id: 'size', label: '세계 크기', tip: '크게 할수록 탐험할 곳이 넓지만 처음 만들 때 조금 더 걸려요.', choices: SIZES.map((s, i) => ({ v: i, label: s.n + ' (' + s.w + '×' + s.h + ')' })), def: 1 },
      { id: 'dif', label: '난이도', tip: '적의 피해·체력과 쓰러졌을 때 잃는 것이 달라져요.', choices: [{ v: 0, label: '쉬움', tip: '적 피해 70% · 쓰러져도 동전을 잃지 않아요' }, { v: 1, label: '보통', tip: '쓰러지면 가진 동전 절반을 그 자리에 떨어뜨려요' }, { v: 2, label: '어려움', tip: '적 피해 150%·체력 140% · 되살아날 때 체력 절반 · 동전 절반을 떨어뜨려요 · 보상 동전 1.5배' }], def: 1 },
      { id: 'goal', label: '끝', tip: '「끝없이」는 언제까지나 이어서 해요(저장하고 나가기). 「최종 보스」는 별의 집행자를 쓰러뜨리면 결과가 나와요.', choices: [{ v: 0, label: '끝없이' }, { v: 1, label: '최종 보스까지' }], def: 0 },
      { id: 'seed', label: '세계 씨앗', tip: '같은 씨앗이면 같은 세계가 만들어져요. 기본은 판마다 무작위.', choices: [{ v: 'r', label: '무작위' }, { v: 1234, label: '1234' }, { v: 777, label: '777' }, { v: 2026, label: '2026' }], def: 'r' },
    ],
    controls: [
      { id: 'left', label: '왼쪽으로', keys: ['KeyA'], pad: ['lx-', 'left'] },
      { id: 'right', label: '오른쪽으로', keys: ['KeyD'], pad: ['lx+', 'right'] },
      { id: 'up', label: '위로(점프)', keys: ['KeyW'], pad: ['up'] },
      { id: 'down', label: '아래로(발판 내려가기)', keys: ['KeyS'], pad: ['ly+', 'down'] },
      { id: 'jump', label: '점프', keys: ['Space'], pad: ['a'] },
      { id: 'use', label: '든 물건 쓰기 (마우스 왼쪽)', keys: [], pad: ['rt'] },
      { id: 'alt2', label: '열기·말 걸기 (마우스 오른쪽)', keys: [], pad: ['lt'] },
      { id: 'inv', label: '가방·제작', keys: ['KeyE', 'KeyI'], pad: ['y'] },
      { id: 'book', label: '레시피 책', keys: ['KeyB'], pad: ['back'] },
      { id: 'map', label: '세계 지도', keys: ['KeyM', 'Tab'], pad: [] },
      { id: 'heal', label: '빠른 치유 물약', keys: ['KeyH'], pad: ['x'] },
      { id: 'house', label: '커서 칸 집 확인', keys: ['KeyG'], pad: [] },
      { id: 'throw', label: '든 물건 던지기', keys: ['KeyQ'], pad: ['b'] },
      { id: 'zin', label: '확대', keys: ['Equal', 'NumpadAdd'], pad: [] },
      { id: 'zout', label: '축소', keys: ['Minus', 'NumpadSubtract'], pad: [] },
      { id: 'h1', label: '핫바 1', keys: ['Digit1'], pad: [] }, { id: 'h2', label: '핫바 2', keys: ['Digit2'], pad: [] }, { id: 'h3', label: '핫바 3', keys: ['Digit3'], pad: [] },
      { id: 'h4', label: '핫바 4', keys: ['Digit4'], pad: [] }, { id: 'h5', label: '핫바 5', keys: ['Digit5'], pad: [] }, { id: 'h6', label: '핫바 6', keys: ['Digit6'], pad: [] },
      { id: 'h7', label: '핫바 7', keys: ['Digit7'], pad: [] }, { id: 'h8', label: '핫바 8', keys: ['Digit8'], pad: [] }, { id: 'h9', label: '핫바 9', keys: ['Digit9'], pad: [] },
      { id: 'h10', label: '핫바 0', keys: ['Digit0'], pad: [] },
    ],
    quick: [
      '판마다 새로 만들어지는 세계에서 나무를 베고 땅을 파 재료를 모아요.',
      '작업대·화로·모루에서 곡괭이·무기·갑옷을 만들고 더 깊이 내려가 좋은 광석을 캐요.',
      '집을 지어 정착민을 맞고, 보스 여섯을 차례로 쓰러뜨려요. 끝없이 이어서 할 수 있어요(저장).',
    ],
    rules: [
      { h: '목표', p: ['정해진 끝은 없어요. 세계를 탐험하고 집을 짓고 더 좋은 장비를 만들어 보스 여섯(왕젤리 → 어둠의 응시자 → 철갑 땅굴벌레 → 뼈무덤 거인 → 화염 군주 → 별의 집행자)을 넘어서는 것이 큰 흐름이에요.', '설정 「끝: 최종 보스까지」를 고르면 별의 집행자를 쓰러뜨릴 때 결과가 나와요. 진행(장비·건물)은 이 세계 안에서만 이어지고, 새 세계는 처음부터예요.'] },
      { h: '조작', p: ['A·D 걷기 · Space(또는 W) 점프(길게 누르면 더 높이) · S 발판 아래로 · 마우스로 겨누기.', '마우스 왼쪽 = 든 물건 쓰기: 곡괭이로 캐기, 도끼로 나무 베기, 망치로 벽 떼기, 무기로 공격, 블록·가구 놓기, 물약 마시기.', '마우스 오른쪽 = 문 열고 닫기 · 상자 열기 · 정착민과 말하기 · 침대를 되살아날 곳으로.', '1~0·휠 핫바 · E(I) 가방·제작 · B 레시피 책 · M 지도 · H 치유 물약 · G 커서 칸 집 확인 · Q 던지기 · =/− 확대·축소.', '가방: 클릭으로 집고 놓기(끌어 놓기도 돼요) · 오른쪽 클릭으로 갑옷·장신구 입기 / 하나만 집기 · Shift+클릭 빠른 이동. 모든 키는 「⌨ 조작 설정」에서 바꿔요.'] },
      { h: '캐기와 곡괭이 힘', p: ['블록마다 단단함이 있어서 몇 번 때려야 부서져요. 광석은 곡괭이 힘이 모자라면 못 캐요(월은 40·태양금 50·심홍 65·화염철 75·성운석 100).', '깊이: 적동·흑철은 얕은 곳, 월은·태양금은 그 아래, 심홍정·수정은 깊은 동굴, 화염철은 지하세계. 성운석은 화염 군주를 쓰러뜨리면 하늘에서 떨어져요.'] },
      { h: '제작', p: ['가방(E)을 열면 지금 만들 수 있는 것만 보여요. 작업 장소(작업대·화로·모루·연금대·세공대·화염 단조대·별의 작업대)는 곁(가로 5칸 안)에 있어야 해요.', '처음 순서: 나무 → 작업대 → 횃불(나무+젤리) → 돌 20 → 화로 → 광석 3개 = 주괴 1개 → 흑철 주괴 5 → 모루 → 금속 곡괭이·검·갑옷.', '「📖 레시피 책」(B)에는 ' + RC.length + '가지 제작법이 모두 있어요. 재료 이름을 누르면 얻는 곳(캐기·적·보스·가게·상자)이 나와요.'] },
      { h: '빛과 밤', p: ['땅속은 어두워요. 횃불을 벽이나 땅에 붙이면 둘레가 밝아져요(횃불을 들고 있어도 밝아요).', '하루는 16분(낮 10분·밤 6분). 밤에는 땅 위에 밤걸음꾼·밤눈박쥐가 나오고, 가끔 「붉은 달밤」이 와요. 밤하늘에서 별가루가 떨어져요.'] },
      { h: '전투와 장비', p: ['근접(검·창)·원거리(활 — 화살이 필요해요)·마법(마나)·소환(소환수가 따라다니며 싸워요) 무기가 있어요.', '갑옷 세 부위(투구·갑옷·각반)를 같은 재료로 맞추면 세트 효과. 장신구 5칸(같은 것은 하나만).', '생명 수정은 최대 체력 +20(400까지), 마나 수정은 최대 마나 +20(200까지). 치유 물약은 마신 뒤 40초를 기다려야 다시 마셔요.', '높은 곳에서 떨어지면 다쳐요. 물속에서는 숨이 줄어요. 용암은 아주 뜨거워요.'] },
      { h: '정착민과 집', p: ['집 = 둘러막힌 방(40~750칸) + 직접 붙인 배경 벽(빈 곳 없이) + 문 + 횃불(등불) + 탁자 종류 + 의자. G 키로 커서 칸이 집이 되는지 확인해요.', '조건이 맞으면 정착민이 이사 와요: 안내자(처음부터), 상인(동전 50), 대장장이(모루), 연금술사(연금대), 치유사(최대 체력 120), 궁수 장인(왕젤리), 비전술사(마나 수정), 탐험가(어둠의 응시자), 세공사(철갑 땅굴벌레).', '정착민에게 오른쪽 클릭 → 가게(사기, 가방에서 오른쪽 클릭으로 팔기)·치료·도움말. 집 안(직접 붙인 벽 앞)에는 적이 생기지 않아요.'] },
      { h: '보스와 사건', p: BOSS.map((B) => '· ' + B.n + ': ' + B.how + ' — ' + B.pat).concat(['약탈단 습격: 어둠의 응시자를 쓰러뜨린 뒤 가끔 낮에 와요. 정해진 수를 물리치면 끝.', '여럿이면 보스 체력이 늘고, 전리품은 사람마다 따로 받아요.']) },
      { h: '난이도·저장', p: ['쉬움(적 피해 70%, 동전 안 잃음) · 보통(쓰러지면 동전 절반 떨어뜨림) · 어려움(적 피해 150%·체력 140%, 체력 절반으로 되살아남).', '일시정지 → 「저장하고 나가기」로 세계를 저장해요. 혼자 하기와 여럿(방장 기기) 저장은 따로예요. 다음에 설정 화면 맨 위 「💾 이어하기」.'] },
      { h: '함께 하기 · AI', p: ['PC 전용이라 한 기기에 한 명. 친구와는 온라인·LAN 방에서 같은 세계를 함께 개척해요(최대 4명, 방장 기기가 세계를 맡아요).', '빈 자리는 AI 동료가 채워요: 사람을 따라다니며 적과 싸우고, 막히면 길을 파요. 난이도는 자리마다 쉬움·보통·어려움(어려울수록 정확하고 적극적). AI 동료는 가방 속 재료로 작업 장소 없이 바로 만들어요.', '사람 없이 AI만 고르면 3분 남짓 AI 개척자 시연을 보여 주고 끝나요.'] },
    ],
    codex: sbCodex(), preview, hint,
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { genWorld, newGame, worldTick, playerTick, botInput, newPlayer, hostAction, bossSpawn, bossTick, snapshot, saveGame, loadGame, liqStep, checkHouse, houseTick, makeC: null, IT, IX, TL, TX, RC, EN, BOSS, NPC, canCraft, addItem, countItem, calcStats, init, result, SIZES, stationsNear, rle, unrle },
  });
})();
