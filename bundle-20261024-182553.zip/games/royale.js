/* 아일랜드 배틀로얄 — realtime top-down battle royale with real firearms for up to 8 (one person per phone; bots fill).
   Everyone picks a landing spot, parachutes down, loots guns/ammo/armor/heals/attachments, fights, drives vehicles and
   outruns the shrinking blue zone. Solo or 2-person teams (teams: knocked-down state, crawling, revives).
   The island is generated from a seed (host and guests build the same map). The world engine (movement, hitscan guns,
   throwables, vehicles, loot, zone, airdrops, AI) is pure and lives outside the view so node can run headless matches.
   The host (or the local phone) runs it; guests send stick/buttons and draw compact host snapshots (own walk predicted). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ---------- constants (1 unit = 1 m) ---------- */
  const CS = 10;
  let HL = 90, GN = 180, CN = 18;   // set per map (the island grows with the number of players)
  function useMap(M) { HL = M.HL; GN = M.GN; CN = M.CN; }
  const scaleOf = (n) => clamp(1.2 * Math.pow(Math.max(8, n || 8) / 8, 0.36), 1.2, 2.3);
  const PR = 0.5, VW = 5.4, VWAT = 0.5, ACC = 150, CRAWL = 1.3;
  const GO_T = 3, CALM_T = 20, SLEEP_T = 30;   // start: 3-2-1 freeze · bots loot only · animals asleep
  /* bullet spread scale (there is no recoil kick, so spread does that job): hip-fire ×3.2, aimed ×2.2 (vs. the gun tables),
     sprinting ×3.5 of standing hip; shotgun pellets less. BLOOM: each shot widens the spread (gun's rc × BLK, up to BLMAX), it shrinks back when you stop */
  const FS_BL = 0.03, HIPK = 3.2, ADSK = 2.2, RUNK = 3.5, SGK = 1.25, RUN_T = 0.55, BLK = 1.7, BLMAX = 0.22;
  /* vision: a cone ahead (half-angle by scope) + a small all-round circle */
  const VIS_HALF = 0.96, VIS_NEAR = 3, SCHALF = [0.96, 0.96, 0.96, 0.8, 0.68, 0.58, 0.47, 0.35, 0.24];
  const HPMAX = 100, NPMAX = 50;
  const DROP_T = 10, FALL_T = 3, SUB = 1 / 60, CAP_T = 640;
  const VRED = [0, 0.3, 0.45, 0.6], HRED = [0, 0.3, 0.45, 0.6];
  const fin = (v) => typeof v === 'number' && isFinite(v);
  const r1 = (v) => Math.round(v * 10) / 10;
  const r2 = (v) => Math.round(v * 100) / 100;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const hyp = Math.hypot;
  // wt = weight of one round (backpack capacity is counted in weight units)
  const AMMO = [
    { nm: '9mm', c: '#e8c35a', pk: 30, wt: 0.25 }, { nm: '.45 ACP', c: '#c98a4a', pk: 25, wt: 0.3 }, { nm: '5.56mm', c: '#8fcf5a', pk: 30, wt: 0.4 },
    { nm: '7.62mm', c: '#e07a4a', pk: 30, wt: 0.5 }, { nm: '12게이지', c: '#d9534f', pk: 10, wt: 1.2 }, { nm: '.300 매그넘', c: '#6aa8e8', pk: 10, wt: 1 },
    { nm: '볼트', c: '#b9a27a', pk: 6, wt: 1.5 }, { nm: '5.7mm', c: '#5fd0c8', pk: 40, wt: 0.25 }, { nm: '.50 BMG', c: '#b48cf0', pk: 5, wt: 2.5 },
    { nm: '40mm 유탄', c: '#7a8a4a', pk: 3, wt: 6 }, { nm: '로켓', c: '#c86a3a', pk: 1, wt: 15 }, { nm: '조명탄', c: '#ff5a4a', pk: 2, wt: 3 },
    { nm: '.357 매그넘', c: '#d8b070', pk: 18, wt: 0.4 },
  ];
  /* carrying capacity: pockets + backpack level + vest pockets */
  const BAGCAP = [40, 150, 200, 250], VESTCAP = 40;
  /* stamina */
  const STM = { max: 100, run: 12, swim: 5, pedal: 2.5, pedalRun: 10, regen: 9, delay: 0.8, melee: 8, ready: 25 };
  const RUN = 1.38, CROUCH = 0.55;
  // classes. scap = best scope (index into SCN) the class can mount
  /* er = full damage up to here, then a straight drop to mf (×100 %) at mr (max range). ds = damage scale on the gun tables
     (long time-to-kill: an assault rifle needs about 7 body hits on an unarmored person). hd = headshot multiplier */
  const CLS = [
    { nm: '권총', er: 12, mr: 36, mf: 0.35, ds: 0.2, scap: 2, ads: 0.5, hd: 1.5, v: 3, fs: 0.75, bk: 1.1, hk: 0.8 },
    { nm: '기관단총', er: 15, mr: 45, mf: 0.4, ds: 0.24, scap: 4, ads: 0.5, hd: 1.5, v: 6, fs: 0.9, bk: 1.0, hk: 0.75 },
    { nm: '돌격소총', er: 30, mr: 85, mf: 0.6, ds: 0.25, scap: 6, ads: 0.42, hd: 1.5, v: 7.8, fs: 0.6, bk: 1.3, hk: 1.45 },
    { nm: '산탄총', er: 5, mr: 22, mf: 0.15, ds: 0.5, scap: 2, ads: 0.8, hd: 1.3, v: 6.3, fs: 1, bk: 1, hk: 1 },
    { nm: '지정사수소총', er: 50, mr: 115, mf: 0.8, ds: 0.36, scap: 8, ads: 0.3, hd: 1.6, v: 7.8, fs: 0.55, bk: 1.3, hk: 1.7 },
    { nm: '저격소총', er: 80, mr: 140, mf: 0.9, ds: 0.6, scap: 8, ads: 0.05, hd: 2, v: 8.6, fs: 0.5, bk: 1, hk: 1 },
    { nm: '경기관총', er: 32, mr: 85, mf: 0.6, ds: 0.22, scap: 6, ads: 0.5, hd: 1.5, v: 8.2, fs: 0.8, bk: 1.15, hk: 1.4 },
    { nm: '석궁', er: 40, mr: 80, mf: 0.85, ds: 0.55, scap: 5, ads: 0.1, hd: 1.8, v: 6, fs: 0.6, bk: 1, hk: 1 },
    { nm: '조명탄총', er: 40, mr: 60, mf: 1, ds: 1, scap: 0, ads: 1, hd: 1, v: 1, fs: 1, bk: 1, hk: 1 },
    { nm: '발사기', er: 40, mr: 70, mf: 1, ds: 0.7, scap: 3, ads: 0.6, hd: 1, v: 9.4, fs: 1, bk: 1, hk: 1 },
  ];
  /* damage factor at distance r (1 → mf) */
  const fallOf = (G, r) => (r <= G.er ? 1 : Math.max(CLS[G.c].mf, 1 - (1 - CLS[G.c].mf) * (r - G.er) / Math.max(1, G.mr - G.er)));
  // class templates: dmg, shot gap, mag, reload, hip spread, recoil (each gun is tuned from these)
  const CT = [[36, 0.16, 15, 1.8, 0.03, 0.018], [32, 0.07, 30, 2.2, 0.036, 0.012], [42, 0.09, 30, 2.3, 0.031, 0.014], [24, 0.6, 5, 3, 0.15, 0.05], [52, 0.2, 15, 3, 0.023, 0.026],
    [78, 1.8, 5, 3.8, 0.08, 0.06], [44, 0.09, 75, 6, 0.043, 0.014], [105, 0.5, 1, 3.4, 0.02, 0.03], [0, 1, 1, 3, 0.02, 0.02], [140, 0.9, 1, 3.5, 0.03, 0.06]];
  /* every gun: 'name|class|ammo|options' (real names). pools: B every island, c m d s j q a v f w = island only, A = supply drop only.
     options: d dmg · cd shot gap · mg mag · rl reload · sp spread · rc recoil · n pellets · bu burst · r range× · sup built-in suppressor ·
     isc built-in scope · oh one-handed · heavy (slower walk) · mv walk× · pv projectile speed · ex blast radius · look: wood bp drum box pan rev lever dbl nostock */
  const GUN_TBL = {
    B: `P1911|0|1|d41 cd.17 mg7
P92|0|0|d35 cd.14 mg15
R1895|0|12|d55 cd.4 mg7 rl2.6 rev wood
P18C|0|0|d23 cd.06 mg17
Glock 17|0|0|d33 cd.11 mg17
SIG P320|0|0|d34 cd.12 mg17
Walther P99|0|0|d32 cd.12 mg16
CZ 75|0|0|d34 cd.13 mg16
Beretta Px4|0|0|d33 cd.12 mg17
UMP45|1|1|d41 cd.092 mg25 rl2.4
Micro Uzi|1|0|d26 cd.048 mg25 rl2.1 oh nostock
Vector|1|1|d31 cd.055 mg19 rl2 oh
MP5K|1|0|d33 cd.067 mg30 rl2.3 oh
Tommy Gun|1|1|d40 cd.086 mg30 rl3 wood drum
PP-19 Bizon|1|0|d35 cd.086 mg53 rl2.6 drum
MP7|1|7|d30 cd.06 mg40 rl2.2 oh
MP5A3|1|0|d33 cd.067 mg30 rl2.3
Uzi|1|0|d31 cd.083 mg32 rl2.3
Sterling L2A3|1|0|d33 cd.11 mg34 rl2.5
Beretta M12|1|0|d32 cd.11 mg32 rl2.4
M416|2|2|d41 cd.086 rl2.1
AKM|2|3|d47 cd.1 rl2.4 sp.036 rc.018 wood
SCAR-L|2|2|d41 cd.096
M16A4|2|2|d41 cd.34 bu3 sp.026 rc.01
QBZ95|2|2|d41 cd.092 bp
G36C|2|2|d41 cd.086 rl2.6
Beryl M762|2|3|d46 cd.086 rl2.6 sp.038 rc.02
Mk47 Mutant|2|3|d49 cd.11 mg20
FAMAS|2|2|d39 cd.067 mg25 bp
AK-74M|2|2|d40 cd.092
SG 550|2|2|d40 cd.088
AUG A1|2|2|d41 cd.085 bp
K2|2|2|d40 cd.09
S1897|3|4|d24 cd.75 mg5 rl3.2 wood
S686|3|4|d25 cd.25 mg2 rl2.4 wood dbl
S12K|3|4|d22 cd.3 mg5 rl2.8 box
DBS|3|4|d24 cd.3 mg14 rl4.5 bp
Sawed-off|3|4|d22 cd.25 mg2 rl2.2 r.7 sp.19 oh dbl wood nostock
Mossberg 590|3|4|d25 cd.7 mg8 rl3.4
Winchester 1912|3|4|d25 cd.65 mg6 rl3.2 wood
Mini14|4|2|d46 cd.2 mg20 rl3.6
SKS|4|3|d53 cd.22 mg10 rl2.9 wood
SLR|4|3|d56 cd.22 mg10 rl3
QBU|4|2|d48 cd.2 mg10 rl2.9 bp
VSS|4|0|d41 cd.09 mg10 rl2.9 sup isc5
M1A|4|3|d54 cd.2 mg20 rl3.1 wood
Mk12 SPR|4|2|d47 cd.18 mg20 rl3
Kar98k|5|3|d79 cd1.9 mg5 rl3.8 wood
M24|5|3|d75 cd1.8 mg5 rl3.4
Win94|5|1|d66 cd.6 mg8 rl4 isc3 wood lever
Mosin Nagant|5|3|d79 cd1.9 mg5 rl3.8 wood
Tikka T3|5|3|d74 cd1.6 mg5 rl3.2
Sako TRG-22|5|3|d77 cd1.6 mg7 rl3.3
Arisaka Type 99|5|3|d78 cd1.9 mg5 rl3.9 wood
M249|6|2|d40 cd.075 mg100 rl7.5 box
DP-28|6|3|d51 cd.109 mg47 rl4.5 wood pan
RPD|6|3|d46 cd.086 mg100 rl7 wood drum
K3|6|2|d40 cd.075 mg100 rl7 box
Crossbow|7|6|d105 cd.5 mg1 rl3.4 sup
Flare Gun|8|11|mg1 rl3 oh`,
    c: `Desert Eagle|0|12|d62 cd.3 mg7
FN Five-seveN|0|7|d36 cd.12 mg20
Beretta 93R|0|0|d30 cd.25 bu3 mg20
MP9|1|0|d29 cd.055 mg30 oh
P90|1|7|d32 cd.067 mg50 bp
Remington 870|3|4|d26 cd.7 mg6
Benelli M4|3|4|d23 cd.28 mg7
HK416|2|2|d42 cd.085
HK45|0|1|d39 cd.15 mg10
B&T APC9|1|0|d31 cd.06 mg30
SIG 516|2|2|d42 cd.09
Colt 635|1|0|d31 cd.065 mg32`,
    m: `M4A1|2|2|d41 cd.08
SCAR-H|2|3|d50 cd.1 mg20
HK G3|2|3|d50 cd.1 mg20
M240B|6|3|d50 cd.08 mg100 rl8 box
M110 SASS|4|3|d57 cd.21 mg20
M1014|3|4|d23 cd.26 mg7
MK18|2|2|d40 cd.08 r.9
M60|6|3|d52 cd.1 mg100 rl8 box
M27 IAR|6|2|d41 cd.08 mg45 rl3.2
M39 EMR|4|3|d58 cd.22 mg20
M2010 ESR|5|5|d90 cd1.7 mg5
FN Mk48|6|3|d50 cd.085 mg100 box`,
    d: `FN FAL|2|3|d52 cd.1 mg20 wood
M14|4|3|d55 cd.2 mg20 wood
Galil ACE|2|2|d41 cd.09
Dragunov SVD|4|3|d60 cd.24 mg10 wood isc5
AK-47|2|3|d48 cd.1 wood
Saiga-12|3|4|d23 cd.3 mg8 box
Remington 700|5|3|d80 cd1.8 mg5
RPK|6|3|d47 cd.1 mg75 wood drum
Tabuk|4|3|d54 cd.22 mg10 wood
Zastava M70|2|3|d47 cd.098 wood
Webley Mk VI|0|12|d52 cd.38 mg6 rev
Type 81|2|3|d46 cd.095`,
    s: `AK-12|2|2|d42 cd.086
SV-98|5|3|d80 cd1.7 mg10
AN-94|2|2|d40 cd.1 bu2
PKM|6|3|d50 cd.09 mg100 box
Vepr-12|3|4|d23 cd.3 mg8 box
SR-25|4|3|d56 cd.2 mg20
Makarov PM|0|0|d30 cd.14 mg8
PPSh-41|1|0|d29 cd.05 mg71 wood drum
SVT-40|4|3|d55 cd.24 mg10 wood
Tokarev TT-33|0|0|d34 cd.14 mg8
Valmet M76|2|3|d46 cd.1 wood
Suomi KP/-31|1|0|d30 cd.07 mg71 wood drum`,
    j: `M16A1|2|2|d40 cd.08 mg20
HK33|2|2|d40 cd.085
MAC-10|1|1|d32 cd.05 mg30 oh nostock
Ithaca 37|3|4|d24 cd.6 mg4 wood
M1 Garand|4|3|d58 cd.22 mg8 wood
Type 56|2|3|d47 cd.1 wood
Stoner 63|6|2|d40 cd.085 mg100 box
CAR-15|2|2|d39 cd.08 r.9
M21|4|3|d58 cd.21 mg20 wood
Owen Gun|1|0|d30 cd.09 mg33
Madsen M/50|1|0|d31 cd.11 mg32
Pindad SS2|2|2|d41 cd.088`,
    q: `Glock 18|0|0|d28 cd.05 mg17
Skorpion vz.61|1|0|d24 cd.07 mg20 oh
TEC-9|1|0|d27 cd.07 mg32 oh nostock
Mossberg 500|3|4|d25 cd.7 mg6
CZ Scorpion EVO 3|1|0|d30 cd.052 mg30
Kel-Tec KSG|3|4|d25 cd.7 mg14 bp
AR-15|2|2|d42 cd.15
Ruger 10/22|4|0|d30 cd.12 mg10
Hi-Point C9|0|0|d31 cd.18 mg8
Kel-Tec Sub-2000|1|0|d33 cd.14 mg17
S&W M&P15|2|2|d42 cd.15
Kel-Tec PMR-30|0|0|d25 cd.11 mg30`,
    a: `MP5SD|1|0|d32 cd.075 mg30 sup
SPAS-12|3|4|d25 cd.4 mg8
M1 Carbine|4|3|d40 cd.15 mg15 wood
Steyr Scout|5|3|d76 cd1.6 mg5
Lee-Enfield No.4|5|3|d75 cd1.3 mg10 wood
Bren|6|3|d50 cd.12 mg30 rl3.4 box
Sten|1|0|d30 cd.11 mg32
Luger P08|0|0|d33 cd.14 mg8
Lewis Gun|6|3|d49 cd.11 mg47 wood pan
MAS-49|4|3|d55 cd.22 mg10 wood
Lanchester|1|0|d31 cd.1 mg50 wood
De Lisle Carbine|5|1|d62 cd1.2 mg8 sup wood`,
    v: `TAR-21|2|2|d41 cd.083 bp
AS Val|2|0|d40 cd.067 mg20 sup
Negev|6|2|d40 cd.07 mg150 rl7 box
HK21|6|3|d50 cd.09 mg100 box
KS-23|3|4|d36 cd.8 mg3 n6
Taurus Judge|0|12|d16 n5 cd.4 mg5 sp.1 rev
CZ 805 Bren|2|2|d41 cd.078
PP-2000|1|0|d29 cd.06 mg20 oh
SR-3 Vikhr|1|0|d38 cd.07 mg20
VSK-94|4|0|d42 cd.1 mg20 sup isc5
AEK-971|2|2|d41 cd.07
Pecheneg|6|3|d50 cd.09 mg100 box`,
    f: `Colt Python|0|12|d58 cd.32 mg6 rev
HK USP|0|1|d37 cd.14 mg12
SIG MPX|1|0|d32 cd.06 mg30
UMP9|1|0|d35 cd.08 mg30
Remington ACR|2|2|d41 cd.085
DSR-1|5|5|d88 cd1.7 mg5 bp
Ultimax 100|6|2|d40 cd.1 mg100 drum
SIG MCX|2|2|d41 cd.08 r.95
Honey Badger|2|3|d40 cd.075 mg30 sup r.85
Desert Tech MDR|2|3|d46 cd.095 mg20 bp
HK Mk23|0|1|d40 cd.16 mg12 sup
FN F2000|2|2|d41 cd.07 bp`,
    w: `Marlin 336|5|3|d64 cd.6 mg6 wood lever
Remington 1100|3|4|d23 cd.28 mg5 wood
Savage 220|3|4|d82 n1 cd1.4 mg2 sp.03 r2.2
Ruger Blackhawk|0|12|d52 cd.4 mg6 rev
S&W Model 29|0|12|d60 cd.42 mg6 rev
M3 Grease Gun|1|1|d38 cd.13 mg30
Browning Auto-5|3|4|d23 cd.3 mg5 wood
Springfield M1903|5|3|d78 cd1.8 mg5 wood
Henry Big Boy|4|12|d48 cd.5 mg10 wood lever
Mossberg 835|3|4|d27 cd.75 mg6
Ruger Mini-30|4|3|d50 cd.2 mg20
Thompson Contender|0|5|d78 cd1 mg1 rl2.4`,
    A: `Groza|2|3|d47 cd.08 bp
AUG A3|2|2|d41 cd.08 bp sp.025 rc.009
MK14 EBR|4|3|d61 cd.09 mg10
AWM|5|5|d105 cd1.85 mg5 rl4
Barrett M82A1|5|8|d120 cd.6 mg10 rl4.5 heavy
PGM Hécate II|5|8|d130 cd1.9 mg7 rl4.5 heavy
CheyTac M200|5|8|d125 cd1.9 mg7 rl4.6 heavy
AA-12|3|4|d23 cd.15 mg20 drum
MG3|6|3|d48 cd.05 mg75 rl8 heavy box
M134 Minigun|6|3|d36 cd.025 mg300 rl10 sp.06 heavy mv.6
Milkor MGL|9|9|d120 ex4 cd.7 mg6 rl6 pv45
Panzerfaust 3|9|10|d200 ex6 cd1 mg1 rl4.5 pv55 heavy
HK G11|2|2|d40 cd.05 bu3 mg45 sp.022 rc.006
XM8|2|2|d41 cd.075
SIG MG 338|6|5|d70 cd.1 mg50 rl6 heavy box
RPK-16|6|2|d42 cd.085 mg95 drum`,
  };
  function hashS(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  const GUN = [];
  for (const po in GUN_TBL) for (const ln of GUN_TBL[po].split('\n')) {
    const f = ln.trim().split('|'); if (f.length < 3) continue;
    const nm = f[0], c = +f[1], T = CT[c], o = {};
    (f[3] || '').trim().split(/\s+/).forEach((tk) => { const m = /^([a-z]+)([\d.]*)$/.exec(tk); if (m) o[m[1]] = m[2] === '' ? 1 : +m[2]; });
    const h = hashS(nm), j = (k, a) => 1 + (((h >>> k) & 255) / 255 - 0.5) * 2 * a, r3 = (v) => Math.round(v * 1000) / 1000;
    const G = { nm, c, am: +f[2], po, d: o.d != null ? o.d : Math.round(T[0] * j(0, 0.06)), cd: o.cd || r3(T[1] * j(3, 0.08)), mg: o.mg || T[2],
      rl: o.rl || Math.round(T[3] * j(6, 0.08) * 10) / 10, sp: o.sp || r3(T[4] * j(9, 0.1)), rc: o.rc || r3(T[5] * j(12, 0.12)),
      n: o.n != null ? (o.n > 1 ? o.n : 0) : c === 3 ? 9 : 0, bu: o.bu || 0, sup: o.sup || 0, isc: o.isc || 0, oh: o.oh || 0, heavy: o.heavy || 0, mv: o.mv || 0,
      pv: o.pv || (c === 7 ? 70 : 0), ex: o.ex || 0, wood: o.wood || 0, bp: o.bp || 0, drum: o.drum || 0, box: o.box || 0, pan: o.pan || 0, rev: o.rev || 0, lever: o.lever || 0, dbl: o.dbl || 0, nostock: o.nostock || 0,
      w: po === 'A' ? 0 : [8, 7, 6, 7, 5, 4, 3, 3, 1, 0][c] };
    G.er = Math.round(CLS[c].er * (o.r || 1) * j(18, 0.1)); G.mr = Math.round(CLS[c].mr * (o.r || 1) * j(21, 0.06));
    G.fs = o.fs || r3(CLS[c].fs * j(24, 0.12));   // first-shot spread (× the normal spread when the gun has settled)
    const bd = T[0] * (c === 3 ? 9 : 1) / T[1], dps = c === 8 ? 0 : G.d * (G.n || 1) * (G.bu ? G.bu / (G.cd + 0.07 * (G.bu - 1)) : 1 / G.cd);
    G.v = c === 8 ? 1 : Math.round((CLS[c].v + clamp(Math.log2(Math.max(1e-3, dps / bd)) * 1.6, -1.6, 1.6) + (po === 'A' ? 2 : 0) + (G.sup ? 0.3 : 0)) * 10) / 10;
    G.d = c === 8 ? G.d : Math.max(1, Math.round(G.d * CLS[c].ds));
    GUN.push(G);
  }
  const MELEE = [
    { nm: '프라이팬', d: 60, cd: 0.75, r: 1.6, arc: 1.7, v: 2.2 }, { nm: '마체테', d: 60, cd: 0.55, r: 1.7, arc: 1.5, v: 2.4 },
    { nm: '낫', d: 55, cd: 0.55, r: 1.85, arc: 1.6, v: 2.3 }, { nm: '쇠지렛대', d: 55, cd: 0.6, r: 1.7, arc: 1.5, v: 2.1 },
    { nm: '야구방망이', d: 58, cd: 0.7, r: 1.9, arc: 1.7, v: 2.3 }, { nm: '도끼', d: 72, cd: 0.9, r: 1.7, arc: 1.3, v: 2.6 },
    { nm: '삽', d: 52, cd: 0.7, r: 1.9, arc: 1.6, v: 2.0 }, { nm: '곡괭이', d: 70, cd: 0.95, r: 1.8, arc: 1.2, v: 2.5 },
    { nm: '단검', d: 40, cd: 0.35, r: 1.3, arc: 1.2, v: 2.0 }, { nm: '망치', d: 62, cd: 0.8, r: 1.6, arc: 1.3, v: 2.3 },
    { nm: '렌치', d: 50, cd: 0.6, r: 1.6, arc: 1.4, v: 2.0 }, { nm: '카타나', d: 66, cd: 0.55, r: 2.0, arc: 1.8, v: 2.9 },
    { nm: '하키 스틱', d: 48, cd: 0.6, r: 2.0, arc: 1.8, v: 1.9 }, { nm: '골프채', d: 50, cd: 0.65, r: 2.0, arc: 1.6, v: 1.9 },
    { nm: '너클', d: 35, cd: 0.3, r: 1.2, arc: 1.2, v: 1.8 }, { nm: '경찰봉', d: 44, cd: 0.45, r: 1.6, arc: 1.4, v: 1.9 },
  ];
  MELEE.forEach((m) => { m.d = Math.round(m.d * 0.6); });   // in line with the longer gun time-to-kill
  const FIST = { nm: '주먹', d: 10, cd: 0.35, r: 1.3, arc: 1.4, v: 0 };
  // f = fuse after landing… (seconds from the throw), w = loot weight
  const THROW = [
    { nm: '수류탄', sn: '수류탄', c: '#6b8a4a', wt: 12, f: 2.8, w: 4 },
    { nm: '연막탄', sn: '연막탄', c: '#c8ccd4', wt: 14, f: 0, w: 3 },
    { nm: '섬광탄', sn: '섬광탄', c: '#e8e2b0', wt: 12, f: 1.9, w: 2 },
    { nm: '화염병', sn: '화염병', c: '#e0703a', wt: 16, f: 0, w: 3 },
    { nm: '끈끈이 폭탄', sn: '끈끈이', c: '#8a6a3a', wt: 14, f: 2.2, w: 1.5 },
    { nm: '조명탄', sn: '조명탄', c: '#ff5a4a', wt: 8, f: 0, w: 2 },
    { nm: '충격 수류탄', sn: '충격탄', c: '#5a7a9a', wt: 12, f: 0, w: 2 },
    { nm: '미끼', sn: '미끼', c: '#c9a36a', wt: 6, f: 0, w: 1.5 },
    { nm: '최루탄', sn: '최루탄', c: '#b8c86a', wt: 12, f: 0, w: 1.5 },
    { nm: '파편 수류탄', sn: '파편탄', c: '#4a5a3a', wt: 14, f: 2.5, w: 1.5 },
  ];
  // hp: +hp up to `to`; st: stamina +st and sb seconds of "지구력"(stamina drains half, refills twice as fast)
  const HEAL = [
    { nm: '붕대', t: 3, hp: 15, to: 75, wt: 2, c: '#f2e9d8' },
    { nm: '구급상자', t: 6, to: 75, wt: 10, c: '#e85a4f' },
    { nm: '의료 키트', t: 8, to: 100, wt: 20, c: '#ff9a3c' },
    { nm: '진통제', t: 5, st: 100, sb: 40, wt: 10, c: '#7ec8ff' },
    { nm: '에너지 드링크', t: 3, st: 50, sb: 15, wt: 4, c: '#7fe07a' },
  ];
  // special gear (one at a time): 길리 슈트 (hides in bushes/grass), 방독면 (gas), 야간 투시경 (sees far at night)
  const SPC = [{ nm: '길리 슈트', c: '#5a7a3a' }, { nm: '방독면', c: '#3a3f45' }, { nm: '야간 투시경', c: '#3a6a3a' }];
  // what each throwable / special gear does (codex rows + item tooltips use the same text)
  const THD = ['약 2.8초 뒤 폭발, 반경 7m, 최대 피해 150', '15초 동안 연기, 연기 속 사람은 안 보여요', '1.9초 뒤 번쩍! 14m 안에서 보면 눈이 부셔요', '8초 동안 불바다(반경 3.2m)',
    '사람·차에 달라붙어 2.2초 뒤 폭발(반경 4.5m)', '25초 동안 주변(24m)을 환하게 밝혀요(밤에 좋아요)', '떨어지자마자 폭발(반경 5m)', '8초 동안 가짜 총소리를 내서 적을 헷갈리게 해요',
    '10초 동안 최루 가스: 따갑고(초당 3) 느려져요. 방독면이면 괜찮아요', '2.5초 뒤 넓게 폭발(반경 9m, 최대 110)'];
  const SPCD = [
    ['덤불 속에 있으면 1.4m까지 다가와야 보여요(보통은 3.5m, 앉으면 2.2m).', '앉아서 가만히 있으면 탁 트인 땅에서도 16m 밖에선 안 보여요(물 위·움직일 땐 안 돼요).', '동물도 덜 알아채요(알아채는 거리 약 70%).', '총알·피해는 못 막아요 · 특수 장비 칸(하나만)'],
    ['최루탄 가스 속에서도 피해·느려짐이 없어요.', '자기장·불 피해는 못 막아요 · 특수 장비 칸(하나만)'],
    ['밤·새벽에 적어도 40m까지 보여요(맨눈은 밤에 훨씬 짧아요).', '낮엔 효과 없어요 · 특수 장비 칸(하나만)'],
  ];
  /* attachments: k = slot (0 scope, 1 magazine, 2 muzzle, 3 under-barrel, 4 stock), cl = classes that take it.
     effects (multipliers): rc recoil · ads aim spread · hip hip spread · mvs moving spread · rec recoil recovery · mg mag size · rl reload · pel pellet spread ·
     sup suppressor · fh flash hider · lt flashlight · lv scope level (SCN index) */
  const ASN = ['조준경', '탄창', '총구', '하부', '개머리판'];
  const ATT = [
    { nm: '보정기(기관단총)', k: 2, cl: '1', rc: 0.75 }, { nm: '보정기(소총)', k: 2, cl: '26', rc: 0.75 }, { nm: '보정기(저격)', k: 2, cl: '45', rc: 0.75 },
    { nm: '소염기(기관단총)', k: 2, cl: '1', fh: 1, rc: 0.9 }, { nm: '소염기(소총)', k: 2, cl: '26', fh: 1, rc: 0.9 }, { nm: '소염기(저격)', k: 2, cl: '45', fh: 1, rc: 0.9 },
    { nm: '소음기(권총)', k: 2, cl: '01', sup: 1 }, { nm: '소음기(소총)', k: 2, cl: '26', sup: 1 }, { nm: '소음기(저격)', k: 2, cl: '45', sup: 1 },
    { nm: '초크', k: 2, cl: '3', pel: 0.7 }, { nm: '덕빌', k: 2, cl: '3', pel: 0.82, hip: 0.9 },
    { nm: '수직 손잡이', k: 3, cl: '126', rc: 0.75 }, { nm: '앵글 손잡이', k: 3, cl: '126', ads: 0.85, rc: 0.9 }, { nm: '하프 손잡이', k: 3, cl: '126', rc: 0.85, mvs: 0.85 },
    { nm: '라이트 손잡이', k: 3, cl: '1246', mvs: 0.75 }, { nm: '엄지 손잡이', k: 3, cl: '1246', rec: 1.35 }, { nm: '레이저 사이트', k: 3, cl: '0123', hip: 0.75 },
    { nm: '손전등', k: 3, cl: '012346', lt: 1 },
    { nm: '대용량 탄창(권총)', k: 1, cl: '01', mg: 1.4 }, { nm: '퀵드로우 탄창(권총)', k: 1, cl: '01', rl: 0.7 }, { nm: '대용량 퀵드로우(권총)', k: 1, cl: '01', mg: 1.4, rl: 0.75 },
    { nm: '대용량 탄창(소총)', k: 1, cl: '26', mg: 1.4 }, { nm: '퀵드로우 탄창(소총)', k: 1, cl: '26', rl: 0.7 }, { nm: '대용량 퀵드로우(소총)', k: 1, cl: '26', mg: 1.4, rl: 0.75 },
    { nm: '대용량 탄창(저격)', k: 1, cl: '45', mg: 1.4 }, { nm: '퀵드로우 탄창(저격)', k: 1, cl: '45', rl: 0.7 }, { nm: '대용량 퀵드로우(저격)', k: 1, cl: '45', mg: 1.4, rl: 0.75 },
    { nm: '전술 개머리판', k: 4, cl: '126', rc: 0.85, mvs: 0.9 }, { nm: '치크패드', k: 4, cl: '45', rc: 0.8, ads: 0.85 }, { nm: '탄띠', k: 4, cl: '35', rl: 0.75 },
    { nm: '레드닷', k: 0, cl: '0123456789', lv: 1 }, { nm: '홀로그램', k: 0, cl: '0123456789', lv: 2 }, { nm: '2배 스코프', k: 0, cl: '0123456789', lv: 3 },
    { nm: '3배 스코프', k: 0, cl: '0123456789', lv: 4 }, { nm: '4배 스코프', k: 0, cl: '0123456789', lv: 5 }, { nm: '6배 스코프', k: 0, cl: '0123456789', lv: 6 },
    { nm: '8배 스코프', k: 0, cl: '0123456789', lv: 7 }, { nm: '15배 스코프', k: 0, cl: '0123456789', lv: 8 }, { nm: '캔티드 사이트', k: 0, cl: '0123456789', lv: 1, ads: 0.85, cant: 1 },
  ];
  ATT.forEach((A, i) => { A.wt = A.k === 0 ? 8 + A.lv * 1.2 : A.k === 1 ? 12 : 10; A.w = A.k === 0 ? [0, 5, 4, 3.5, 3, 2.4, 1.6, 1, 0.5][A.lv] * (A.cant ? 0.6 : 1) : A.sup ? 1.4 : A.k === 4 ? 1.6 : 2.2; A.i = i; });
  const SCN = ['기본 조준', '레드닷', '홀로', '2배', '3배', '4배', '6배', '8배', '15배'];
  const SCZ = [1.25, 1.33, 1.36, 1.6, 1.85, 2.15, 2.55, 2.95, 3.6];   // camera zoom-out while aiming
  const SIGHT = [24, 26, 27, 34, 42, 50, 60, 70, 90];                // aim-assist / bot sight radius while aiming
  const HIPSIGHT = 21;
  /* unified item ids */
  const I_GUN = 0, I_MEL = GUN.length, I_THR = I_MEL + MELEE.length, I_HEAL = I_THR + THROW.length, I_VEST = I_HEAL + HEAL.length,
    I_HELM = I_VEST + 3, I_BAG = I_HELM + 3, I_SPC = I_BAG + 3, I_ATT = I_SPC + SPC.length, I_AMMO = I_ATT + ATT.length, NITEM = I_AMMO + AMMO.length;
  function ikind(t) {
    if (t < I_MEL) return 'g'; if (t < I_THR) return 'm'; if (t < I_HEAL) return 't'; if (t < I_VEST) return 'h';
    if (t < I_HELM) return 'v'; if (t < I_BAG) return 'e'; if (t < I_SPC) return 'b'; if (t < I_ATT) return 's'; if (t < I_AMMO) return 'a'; return 'o';
  }
  function iname(t) {
    const k = ikind(t);
    if (k === 'g') return GUN[t].nm; if (k === 'm') return MELEE[t - I_MEL].nm; if (k === 't') return THROW[t - I_THR].nm;
    if (k === 'h') return HEAL[t - I_HEAL].nm; if (k === 'v') return '조끼 ' + (t - I_VEST + 1) + '레벨'; if (k === 'e') return '헬멧 ' + (t - I_HELM + 1) + '레벨';
    if (k === 'b') return '가방 ' + (t - I_BAG + 1) + '레벨'; if (k === 's') return SPC[t - I_SPC].nm; if (k === 'a') return ATT[t - I_ATT].nm; return AMMO[t - I_AMMO].nm;
  }
  // glow colour on the ground: guns have no grades (each is just different); gear shows its level
  const RARC = ['#e8e2d4', '#5fb0ff', '#c27bff', '#ffb020'];
  function irar(t) {
    const k = ikind(t);
    if (k === 'v') return t - I_VEST; if (k === 'e') return t - I_HELM; if (k === 'b') return t - I_BAG; if (k === 's') return 2;
    return 0;
  }

  /* islands: vs = vehicles [type, count], ani = animals [kind, count] */
  const BASEV = [[0, 3], [1, 2], [2, 2], [3, 1], [4, 3], [5, 2], [6, 1], [7, 1], [8, 1], [9, 1], [10, 1.5], [11, 1.2]];
  const MAPS = [
    { k: 'c', nm: '도시 섬', sh: 'round', base: 72, amp: 3, bld: 44, bush: 50, rock: 12, tree: 44, cac: 0, mesa: 0, loot: 90, vs: [[4, 2], [1, 2], [6, 1]], ani: [[0, 4]],
      gr: '#7fae62', gr2: '#6c9a52', sand: '#e6d29c', roof: ['#9a5d4a', '#5d7896', '#7b6f8f', '#a07d4c'], tc: '#3f7f3a', road: '#4b4e55', note: '건물이 빽빽한 도시. 골목·실내전' },
    { k: 'm', nm: '군사기지 섬', sh: 'long', base: 64, amp: 2.2, bld: 26, bush: 60, rock: 20, tree: 50, cac: 0, mesa: 0, loot: 90, vs: [[16, 0.6], [8, 1], [5, 1]], ani: [[0, 3], [6, 3]],
      gr: '#8aa465', gr2: '#778f55', sand: '#e1cf9a', roof: ['#5f6b4a', '#6b6f62', '#4f5a48'], tc: '#43703a', road: '#5a5a52', note: '가운데 기지에 좋은 총이 많아요. 드물게 장갑차' },
    { k: 'd', nm: '사막 섬', sh: 'blob', base: 73, amp: 5.5, bld: 28, bush: 24, rock: 26, tree: 8, cac: 60, mesa: 14, loot: 90, vs: [[15, 3], [9, 1]], ani: [[5, 5], [11, 3]], storm: 1,
      gr: '#dcc085', gr2: '#ccab6c', sand: '#f0dca8', roof: ['#b8754a', '#c99a5e', '#a86a44'], tc: '#7a9a46', road: '#8a7356', note: '탁 트인 사막. 가끔 모래폭풍이 불어 앞이 안 보여요' },
    { k: 's', nm: '설원 섬', sh: 'round', base: 72, amp: 3.6, bld: 28, bush: 36, rock: 24, tree: 70, cac: 0, mesa: 0, loot: 90, ice: 4, vs: [[13, 2], [14, 3]], ani: [[2, 2], [1, 5]], snow: 1,
      gr: '#e9eef3', gr2: '#d4dde6', sand: '#cfd6dc', roof: ['#7a4a3a', '#5a4a6a', '#3f5a6a'], tc: '#2f5f4a', road: '#9aa4ad', note: '눈 위에 발자국이 남아요. 얼음은 미끄러워요. 설상차·스노모빌' },
    { k: 'j', nm: '정글 섬', sh: 'blob', base: 72, amp: 5, bld: 26, bush: 140, rock: 14, tree: 100, cac: 0, mesa: 0, loot: 90, river: 1, vs: [[10, 2], [11, 1]], ani: [[3, 3], [4, 3]],
      gr: '#4f9a46', gr2: '#43873c', sand: '#e3cf96', roof: ['#8a6a4a', '#9a7a52', '#6f5a3a'], tc: '#2a6e2e', road: '#7a6446', note: '덤불·나무가 빽빽하고 강이 흘러요. 강가에 악어' },
    { k: 'q', nm: '작은 섬 (빠른 판)', sh: 'round', base: 42, amp: 2.4, bld: 15, bush: 44, rock: 10, tree: 30, cac: 0, mesa: 0, loot: 60, quick: 1, vs: [], ani: [[6, 2]],
      gr: '#79b860', gr2: '#66a350', sand: '#efd9a0', roof: ['#d9784a', '#5b8fd6', '#c55a8a'], tc: '#3f8f3a', road: '#555', note: '작은 섬, 구역이 빨리 줄어요' },
    { k: 'a', nm: '군도', sh: 'arch', base: 60, amp: 3, bld: 30, bush: 60, rock: 14, tree: 50, cac: 0, mesa: 0, loot: 90, vs: [[10, 3], [11, 3]], ani: [[10, 3], [6, 2]],
      gr: '#78b25e', gr2: '#66a050', sand: '#f0daa0', roof: ['#c86a4a', '#4a8ac8', '#e0b04a'], tc: '#3a8a3a', road: '#5a5a5a', note: '작은 섬 여러 개와 물길. 보트·수상 오토바이, 물에는 상어' },
    { k: 'v', nm: '화산섬', sh: 'blob', base: 70, amp: 4.5, bld: 22, bush: 30, rock: 40, tree: 30, cac: 0, mesa: 6, loot: 90, volc: 1, vs: [[9, 2]], ani: [[8, 4]],
      gr: '#6f6a5a', gr2: '#5f5a4c', sand: '#3a3634', roof: ['#5a4a42', '#6a5a4a', '#4a4040'], tc: '#4a5a3a', road: '#3a3638', note: '가운데 화산, 용암 지대는 뜨거워요. 화산재로 멀리 안 보여요' },
    { k: 'f', nm: '폐공장 도시', sh: 'round', base: 70, amp: 3, bld: 30, bush: 30, rock: 16, tree: 24, cac: 0, mesa: 0, loot: 100, fact: 1, vs: [[8, 2], [7, 2]], ani: [[0, 3], [9, 3]],
      gr: '#7a8270', gr2: '#6a7262', sand: '#b8ac90', roof: ['#5a5e64', '#6a645a', '#4e5458', '#7a6a5a'], tc: '#4a6a42', road: '#45474c', note: '큰 공장 건물이 많아요. 낡은 공장은 천장이 무너져요' },
    { k: 'w', nm: '늪지', sh: 'blob', base: 70, amp: 5, bld: 24, bush: 110, rock: 8, tree: 80, cac: 0, mesa: 0, loot: 90, swamp: 1, vs: [[12, 4]], ani: [[4, 4], [7, 4]],
      gr: '#5f7a4a', gr2: '#52693f', sand: '#8a8a5a', roof: ['#6a5a42', '#5a5a4a', '#4a5a4a'], tc: '#3a5a32', road: '#5a5440', note: '진흙에선 느려지고 안개가 껴요. 에어보트, 악어·독사' },
    { k: 'h', gk: 's', nm: '온천 설산', sh: 'blob', base: 70, amp: 4.5, bld: 24, bush: 30, rock: 30, tree: 80, cac: 0, mesa: 4, loot: 90, ice: 2, hsp: 6, snow: 1, vs: [[14, 2], [13, 1], [5, 1]], ani: [[1, 4], [2, 2]],
      gr: '#e6ecf1', gr2: '#d0dae3', sand: '#c9d1d8', roof: ['#6a3a2a', '#4a5a6a', '#5a4a3a'], tc: '#2a5a48', road: '#a0a8b0', note: '눈 덮인 산에 김이 나는 온천. 온천 안에 있으면 체력이 75까지 천천히 차요(눈보라에도 안 느려져요)' },
    { k: 'g', gk: 'd', nm: '간헐천 고원', sh: 'round', base: 70, amp: 3.5, bld: 26, bush: 40, rock: 30, tree: 30, cac: 10, mesa: 8, loot: 90, gy: 12, vs: [[9, 2], [7, 1], [2, 2]], ani: [[11, 3], [6, 3]],
      gr: '#b0a070', gr2: '#9c8c5e', sand: '#d8c890', roof: ['#8a5a3a', '#6a6a5a', '#9a6a4a'], tc: '#5a7a3a', road: '#6a6050', note: '땅에서 뜨거운 물기둥이 솟아요. 부글부글 끓으면 곧 터지니 피해요(30 피해, 튕겨 나가요)' },
  ];
  // zones: [wait s, shrink s, new radius]
  const ZW = [[75, 45, 72], [55, 40, 44], [45, 32, 26], [35, 26, 13], [28, 22, 5], [22, 18, 0]];
  const ZQ = [[45, 28, 30], [32, 24, 17], [24, 18, 8], [18, 14, 3], [14, 12, 0]];
  const ZDPS = [0.6, 1.5, 3, 5, 8, 12, 20];

  const AID = {
    1: { react: 0.8, err: 1.4, think: 0.45, sight: 17, strafe: 0, zone: 0.3, loot: 16, heal: 0.4, spd: 0.92, ads: 0, nade: 0, burst: 0, veh: 0, fin: 0.3, flee: 0, pick: 0.4 },
    2: { react: 0.42, err: 0.75, think: 0.3, sight: 24, strafe: 0.6, zone: 0.75, loot: 22, heal: 0.8, spd: 1, ads: 1, nade: 0.35, burst: 0.6, veh: 0.6, fin: 0.7, flee: 0.35, pick: 0.8 },
    3: { react: 0.18, err: 0.3, think: 0.16, sight: 32, strafe: 1, zone: 1, loot: 28, heal: 1, spd: 1, ads: 1, nade: 0.8, burst: 1, veh: 1, fin: 1, flee: 0.7, pick: 1 },
  };
  /* bot personalities, rolled per bot each match (independent of the difficulty level) */
  const PERS = [
    { nm: '돌격형', w: 0.24, notice: 1.8, early: 0.35, camp: 0.12, campT: 0.6, eng: 1.35, hunt: 1, avoid: 0, veh: 0.3, snip: 0 },
    { nm: '신중형', w: 0.24, notice: 0.8, early: 1.4, camp: 0.75, campT: 1.3, eng: 0.8, hunt: 0, avoid: 1, veh: 0.5, snip: 0 },
    { nm: '저격형', w: 0.16, notice: 1.2, early: 1, camp: 0.85, campT: 1.2, eng: 1, hunt: 0, avoid: 0.5, veh: 0.4, snip: 1 },
    { nm: '캠핑형', w: 0.2, notice: 1, early: 1, camp: 1, campT: 2.2, eng: 0.9, hunt: 0, avoid: 0.3, veh: 0.15, snip: 0 },
    { nm: '유랑형', w: 0.16, notice: 1, early: 0.9, camp: 0.1, campT: 0.6, eng: 1, hunt: 0.3, avoid: 0.2, veh: 1, snip: 0, roam: 1 },
  ];
  function rollPers() { let u = Math.random(); for (let k = 0; k < PERS.length; k++) { u -= PERS[k].w; if (u <= 0) return k; } return 0; }
  /* vehicles. land: 1 ground, 0 water, 2 both (air boat). sh = how it is drawn, snd = engine sound pitch (0 = none), col = paint */
  const VEH = [
    { nm: '자전거', r: 0.75, vmax: 8, acc: 5, turn: 3.0, hp: 70, seats: 1, land: 1, ped: 1, sh: 'bike', col: '#2f8fd0', snd: 0 },
    { nm: '스쿠터', r: 0.8, vmax: 15, acc: 9, turn: 3.2, hp: 90, seats: 2, land: 1, sh: 'bike', col: '#e8c04e', snd: 140 },
    { nm: '오토바이', r: 0.85, vmax: 23, acc: 11, turn: 3.2, hp: 110, seats: 2, land: 1, sh: 'bike', col: '#a02a26', snd: 110 },
    { nm: '사이드카', r: 1.1, vmax: 20, acc: 9, turn: 2.6, hp: 150, seats: 3, land: 1, sh: 'side', col: '#5c6b3c', snd: 100 },
    { nm: '승용차', r: 1.3, vmax: 20, acc: 9, turn: 2.5, hp: 180, seats: 4, land: 1, sh: 'car', col: '#3f5f7a', snd: 85 },
    { nm: '지프', r: 1.35, vmax: 19, acc: 9, turn: 2.4, hp: 220, seats: 4, land: 1, sh: 'car', col: '#5c6b3c', snd: 75 },
    { nm: '미니밴', r: 1.5, vmax: 17, acc: 7, turn: 2.1, hp: 260, seats: 6, land: 1, sh: 'van', col: '#c8c2b0', snd: 80 },
    { nm: '픽업트럭', r: 1.5, vmax: 18, acc: 8, turn: 2.2, hp: 280, seats: 4, land: 1, sh: 'pickup', col: '#7a3a32', snd: 70 },
    { nm: '트럭', r: 1.9, vmax: 14, acc: 5, turn: 1.6, hp: 420, seats: 6, land: 1, sh: 'truck', col: '#4a5a3a', snd: 55 },
    { nm: '버기', r: 1.1, vmax: 22, acc: 12, turn: 2.9, hp: 140, seats: 2, land: 1, sh: 'buggy', col: '#d86a2a', snd: 120 },
    { nm: '보트', r: 1.4, vmax: 15, acc: 7, turn: 2.0, hp: 200, seats: 4, land: 0, sh: 'boat', col: '#e8e4da', snd: 90 },
    { nm: '수상 오토바이', r: 0.95, vmax: 21, acc: 11, turn: 3.0, hp: 110, seats: 2, land: 0, sh: 'jetski', col: '#e85a8a', snd: 130 },
    { nm: '에어보트', r: 1.3, vmax: 17, acc: 8, turn: 2.3, hp: 180, seats: 3, land: 2, sh: 'airboat', col: '#4a7a8a', snd: 150 },
    { nm: '설상차', r: 1.5, vmax: 13, acc: 6, turn: 1.9, hp: 320, seats: 4, land: 1, snow: 1, sh: 'tank', col: '#d8642a', snd: 60 },
    { nm: '스노모빌', r: 0.95, vmax: 20, acc: 10, turn: 3.0, hp: 120, seats: 2, land: 1, snow: 1, sh: 'sled', col: '#2a6ad8', snd: 125 },
    { nm: '모래 버기', r: 1.1, vmax: 24, acc: 12, turn: 2.9, hp: 150, seats: 2, land: 1, sand: 1, sh: 'buggy', col: '#e0b04a', snd: 115 },
    { nm: '장갑차', r: 1.8, vmax: 14, acc: 5, turn: 1.6, hp: 900, seats: 4, land: 1, arm: 1, sh: 'apc', col: '#5a6448', snd: 50 },
  ];
  /* wild animals: roam near home, attack people who come close. ag = notice radius, wet: 1 likes the shore, 2 lives in water */
  const ANI = [
    { nm: '들개', hp: 60, sp: 6.5, d: 12, cd: 0.8, r: 0.45, ag: 9, col: '#8a6a4a', sh: 'dog' },
    { nm: '늑대', hp: 80, sp: 7, d: 16, cd: 0.8, r: 0.5, ag: 11, col: '#8f8f96', sh: 'dog' },
    { nm: '북극곰', hp: 320, sp: 5.5, d: 38, cd: 1.3, r: 1.0, ag: 10, col: '#f2f2ea', sh: 'bear' },
    { nm: '호랑이', hp: 220, sp: 7.5, d: 32, cd: 1.0, r: 0.85, ag: 12, col: '#e0903a', sh: 'cat' },
    { nm: '악어', hp: 240, sp: 4, d: 40, cd: 1.6, r: 0.9, ag: 5, col: '#4f6a3a', sh: 'croc', wet: 1 },
    { nm: '전갈 떼', hp: 50, sp: 3, d: 8, cd: 0.5, r: 0.6, ag: 5, col: '#2a2420', sh: 'swarm' },
    { nm: '멧돼지', hp: 140, sp: 6, d: 22, cd: 1.0, r: 0.7, ag: 8, col: '#5a4030', sh: 'boar' },
    { nm: '독사', hp: 30, sp: 2.5, d: 14, cd: 1.2, r: 0.35, ag: 3.5, col: '#6a8a2a', sh: 'snake' },
    { nm: '용암 도마뱀', hp: 110, sp: 4.5, d: 18, cd: 1.0, r: 0.6, ag: 7, col: '#c84a2a', sh: 'lizard' },
    { nm: '쥐 떼', hp: 40, sp: 4.5, d: 6, cd: 0.5, r: 0.6, ag: 6, col: '#5a5052', sh: 'swarm' },
    { nm: '상어', hp: 200, sp: 6, d: 35, cd: 1.5, r: 0.9, ag: 10, col: '#7a8a9a', sh: 'shark', wet: 2 },
    { nm: '코요테', hp: 70, sp: 7, d: 14, cd: 0.8, r: 0.5, ag: 9, col: '#b89a6a', sh: 'dog' },
  ];

  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * Math.random()); }
  function wrapA(a) { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a; }
  function rngOf(seed) {
    let s = (seed >>> 0) || 1;
    return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const NOIN = { ax: 0, ay: 0, fire: 0, aim: null, ad: null, acts: null, spd: 1, ads: 0 };

  /* ======================= island generation (seeded, identical on every device) ======================= */
  function lobe(rnd, cx, cy, base, amp, sx, sy, rot) {
    const hm = []; for (let k = 2; k <= 6; k++) hm.push([k, (rnd() * 2 - 1) * amp * 2 / k, rnd() * 6.283]);
    rot = rot || 0;
    return { cx, cy, base, hm, sx: sx || 1, sy: sy || 1, c: Math.cos(rot), s: Math.sin(rot) };
  }
  function lobeR(lb, th) { let r = lb.base; for (const h of lb.hm) r += h[1] * Math.sin(h[0] * th + h[2]); return r; }
  function inLobe(lb, x, y, pad) {
    const dx = x - lb.cx, dy = y - lb.cy, u = (dx * lb.c + dy * lb.s) / lb.sx, v = (-dx * lb.s + dy * lb.c) / lb.sy;
    return hyp(u, v) < lobeR(lb, Math.atan2(v, u)) - (pad || 0);
  }
  function lobePt(lb, th, off) {
    const r = lobeR(lb, th) + (off || 0), u = Math.cos(th) * r * lb.sx, v = Math.sin(th) * r * lb.sy;
    return [lb.cx + u * lb.c - v * lb.s, lb.cy + u * lb.s + v * lb.c];
  }
  function landAt(M, x, y, pad) {
    pad = pad || 0;
    let ok = false;
    for (const lb of M.lobes) if (inLobe(lb, x, y, pad)) { ok = true; break; }
    if (!ok) return false;
    for (const hl of M.holes) if (hyp(x - hl[0], y - hl[1]) < hl[2] + pad) return false;
    return true;
  }
  function isWater(M, x, y) {
    const ix = Math.floor(x + HL), iy = Math.floor(y + HL);
    if (ix < 0 || iy < 0 || ix >= GN || iy >= GN) return true;
    return !M.g[iy * GN + ix];
  }
  function onIce(M, x, y) { for (const c of M.ice) if (hyp(x - c[0], y - c[1]) < c[2]) return true; return false; }
  function inBld(M, x, y) {
    const c = cellOf(x, y); if (c < 0) return -1;
    for (const j of M.cb[c]) { const b = M.blds[j]; if (x > b.x0 + 0.4 && x < b.x1 - 0.4 && y > b.y0 + 0.4 && y < b.y1 - 0.4) return j; }
    return -1;
  }
  function inBush(M, x, y) {
    const c = cellOf(x, y); if (c < 0) return false;
    for (const j of M.cu[c]) { const b = M.bush[j], dx = x - b[0], dy = y - b[1]; if (dx * dx + dy * dy < (b[2] - 0.2) * (b[2] - 0.2)) return true; }
    return false;
  }
  function cellOf(x, y) { const cx = Math.floor((x + HL) / CS), cy = Math.floor((y + HL) / CS); return cx < 0 || cy < 0 || cx >= CN || cy >= CN ? -1 : cy * CN + cx; }
  /* doors & windows: md 0 = walking (closed doors and windows block), 1 = rays (only closed doors block),
     2 = AI path probe (doors open themselves when bumped, so only locked ones block) */
  function solidQ(M, q, md) {
    if (q.w != null) return md !== 1;
    if (q.d != null) { if (M.dS && M.dS[q.d]) return false; if (md === 2) return !!(M.dL && M.dL[q.d] > 0); }
    return true;
  }
  /* visit every static solid (rect index >= 0, circle index as ~k) whose cell overlaps the box */
  function nearSolids(M, x0, y0, x1, y1, fr, fc, md) {
    const stp = ++M.stp;
    const ax = clamp(Math.floor((x0 + HL) / CS), 0, CN - 1), bx = clamp(Math.floor((x1 + HL) / CS), 0, CN - 1);
    const ay = clamp(Math.floor((y0 + HL) / CS), 0, CN - 1), by = clamp(Math.floor((y1 + HL) / CS), 0, CN - 1);
    for (let cy = ay; cy <= by; cy++) for (let cx = ax; cx <= bx; cx++) {
      const c = cy * CN + cx;
      if (fr) for (const j of M.cr[c]) { if (M.rs[j] === stp) continue; M.rs[j] = stp; const q = M.rects[j]; if ((q.d != null || q.w != null) && !solidQ(M, q, md | 0)) continue; if (fr(q)) return true; }
      if (fc) for (const j of M.cc[c]) { if (M.ccs[j] === stp) continue; M.ccs[j] = stp; if (fc(M.circs[j])) return true; }
    }
    return false;
  }
  function solidAt(M, x, y, r, md) {
    if (Math.abs(x) > HL - r || Math.abs(y) > HL - r) return true;
    return nearSolids(M, x - r, y - r, x + r, y + r,
      (q) => { const cx = clamp(x, q[0], q[2]), cy = clamp(y, q[1], q[3]); return (x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r; },
      (c) => { const R = c[2] + r; return (x - c[0]) * (x - c[0]) + (y - c[1]) * (y - c[1]) < R * R; }, md);
  }
  function okSpot(M, x, y, water) { return Math.abs(x) < HL - 2 && Math.abs(y) < HL - 2 && (water || landAt(M, x, y, 0.3)) && !solidAt(M, x, y, PR + 0.15); }
  function snapFree(M, x, y, water) {
    if (!fin(x) || !fin(y)) { x = 0; y = 0; }
    x = clamp(x, -HL + 3, HL - 3); y = clamp(y, -HL + 3, HL - 3);
    if (okSpot(M, x, y, water)) return [x, y];
    for (let r = 0.6; r < 60; r += 0.6) for (let k = 0; k < 16; k++) {
      const a = k / 16 * 6.283 + r, px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
      if (okSpot(M, px, py, water)) return [px, py];
    }
    return [0, 0];
  }
  function poolOf(M) {
    if (M.pool) return M.pool;
    const out = [];
    GUN.forEach((G, i) => { if (G.w && (G.po === 'B' || G.po.indexOf(M.T.gk || M.T.k) >= 0)) out.push(i); });
    return (M.pool = out);
  }
  function pickW(rnd, arr, wf) { let s = 0; for (const a of arr) s += wf(a); let u = rnd() * s; for (const a of arr) { u -= wf(a); if (u <= 0) return a; } return arr[arr.length - 1]; }
  /* one loot roll → list of [t, n] (a gun brings a little ammo along) */
  function rollLoot(rnd, M, bonus) {
    const u = rnd(), out = [];
    if (u < 0.3) {
      const pool = poolOf(M);
      const g = pickW(rnd, pool, (i) => GUN[i].w * (GUN[i].v >= 8.5 ? 0.55 + bonus * 2 : 1));
      out.push([g, GUN[g].mg]);
      if (rnd() < 0.75) out.push([I_AMMO + GUN[g].am, AMMO[GUN[g].am].pk]);
    } else if (u < 0.5) {
      const pool = poolOf(M), g = pool[Math.floor(rnd() * pool.length)];
      out.push([I_AMMO + GUN[g].am, AMMO[GUN[g].am].pk]);
    } else if (u < 0.64) {
      const h = pickW(rnd, [0, 1, 2, 3, 4], (i) => [10, 4, 0.6 + bonus * 3, 3, 4][i]);
      out.push([I_HEAL + h, h === 0 ? 5 : 1]);
    } else if (u < 0.73) {
      const t = pickW(rnd, THROW.map((T, i) => i), (i) => THROW[i].w);
      out.push([I_THR + t, 1]);
    } else if (u < 0.83) {
      const lv = rnd() + bonus < 0.62 ? 0 : rnd() + bonus < 0.93 ? 1 : 2;
      out.push([(rnd() < 0.5 ? I_VEST : I_HELM) + lv, 1]);
    } else if (u < 0.875) {
      const lv = rnd() + bonus < 0.6 ? 0 : rnd() + bonus < 0.92 ? 1 : 2;
      out.push([I_BAG + lv, 1]);
    } else if (u < 0.885) out.push([I_SPC + Math.floor(rnd() * SPC.length), 1]);
    else if (u < 0.965) {
      const a = pickW(rnd, ATT.map((A, i) => i), (i) => ATT[i].w * (ATT[i].k === 0 && ATT[i].lv >= 5 ? 1 + bonus * 4 : 1));
      out.push([I_ATT + a, 1]);
    } else out.push([I_MEL + Math.floor(rnd() * MELEE.length), 1]);
    return out;
  }
  const inLava = (M, x, y) => !!M.lava && M.lava.some((c) => hyp(x - c[0], y - c[1]) < c[2]);
  const inHsp = (M, x, y) => !!M.hsp && M.hsp.some((c) => hyp(x - c[0], y - c[1]) < c[2]);
  const onRoadM = (M, x, y) => M.roads.some((q) => x > q[0] && x < q[2] && y > q[1] && y < q[3]);
  /* geysers: each one bubbles (warning) for 2 s, then blows for 1.4 s, on a fixed beat from the match clock (guests draw it from W.T) */
  const GY_P = 15, GY_W = 11.6, GY_E = 13.6;
  const gyU = (W, k) => (W.T + k * 5.3) % GY_P;
  /* weather: 0 맑음 · 1 비 · 2 눈보라 · 3 폭풍 */
  const WXN = [['☀', '맑음'], ['🌧', '비'], ['❄', '눈보라'], ['⛈', '폭풍']];
  const WXD = ['', '비: 조금 덜 보이고 총소리가 덜 퍼져요', '눈보라: 30m만 보이고 길 밖에선 느려져요', '폭풍: ⚡ 원이 뜨면 피해요(번개 40) · 바람에 탄이 조금 밀려요'];
  const windA = (W, a, k) => (W.wx === 3 ? a + k * Math.sin(W.wa - a) : a);
  const inMud = (M, x, y) => !!M.mud && M.mud.some((c) => hyp(x - c[0], y - c[1]) < c[2]);
  function makeMap(sd, mk, np) {
    const T = mk === 99 ? RANGE_MAP : MAPS[mk] || MAPS[0], rnd = rngOf(sd * 7 + mk * 101 + 13);
    const f = scaleOf(np), A = f * f, base = T.base * f;
    const M = { mk, T, f, base, lobes: [], holes: [], ice: [], rects: [], circs: [], bush: [], blds: [], cont: [], roads: [], fence: [], loot: [], vsp: [], doors: [], wins: [], lava: [], mud: [], hsp: [], gy: [], g: null, stp: 0, dS: null, dL: null };
    const arch = T.sh === 'arch';
    M.HL = Math.ceil(base * (T.sh === 'long' ? 1.24 : arch ? 1.42 : 1) + T.amp * 2 * f + 16); M.GN = 2 * M.HL; M.CN = Math.ceil(M.GN / CS);
    useMap(M);
    const LCAP = Math.round(320 * A);
    const rot = rnd() * 6.283;
    if (T.sh === 'long') M.lobes.push(lobe(rnd, 0, 0, base, T.amp * f, 1.24, 0.84, rot));
    else if (arch) {
      // archipelago: a middle island and a ring of smaller ones with channels of water between them
      M.lobes.push(lobe(rnd, 0, 0, base * 0.52, T.amp * f));
      const n = 5 + Math.floor(rnd() * 2);
      for (let k = 0; k < n; k++) { const a = rot + k / n * 6.283 + (rnd() - 0.5) * 0.4, d = base * (0.92 + rnd() * 0.12), r = base * (0.3 + rnd() * 0.08); M.lobes.push(lobe(rnd, Math.cos(a) * d, Math.sin(a) * d, r, T.amp * f * 0.7)); }
    }
    else M.lobes.push(lobe(rnd, 0, 0, base, T.amp * f));
    M.rad = Math.max(...M.lobes.map((lb) => hyp(lb.cx, lb.cy) + lb.base * Math.max(lb.sx, lb.sy))) + 8;
    // occupancy for placement: big things in a list, small ones in a 10 m bucket grid
    const OB = [], OG = new Map();
    const occAdd = (x, y, r) => { if (r > 8) { OB.push([x, y, r]); return; } const k = Math.floor(x / 10) + ',' + Math.floor(y / 10); let a = OG.get(k); if (!a) OG.set(k, (a = [])); a.push([x, y, r]); };
    const free = (x, y, r) => {
      if (Math.abs(x) > HL - r - 3 || Math.abs(y) > HL - r - 3 || !landAt(M, x, y, r + 0.8)) return false;
      for (const o of OB) if (hyp(o[0] - x, o[1] - y) < r + o[2] + 0.6) return false;
      const cr = Math.ceil((r + 9) / 10), cx = Math.floor(x / 10), cy = Math.floor(y / 10);
      for (let dy = -cr; dy <= cr; dy++) for (let dx = -cr; dx <= cr; dx++) { const a = OG.get((cx + dx) + ',' + (cy + dy)); if (a) for (const o of a) if (hyp(o[0] - x, o[1] - y) < r + o[2] + 0.6) return false; }
      return true;
    };
    const R = base * (T.sh === 'long' ? 1.15 : arch ? 1.34 : 1) - 4;
    const rp = (rr) => { const a = rnd() * 6.283, d = Math.sqrt(rnd()) * rr; return [Math.cos(a) * d, Math.sin(a) * d]; };
    // river (jungle): a wavy chain of water circles with two land bridges
    if (T.river) {
      const a0 = rot + 1.2, ca = Math.cos(a0), sa = Math.sin(a0), ph = rnd() * 6, br = [];
      for (let t = -base * 0.8 + rnd() * 20; t < base; t += 40 + rnd() * 25) br.push(t);
      for (let t = -HL; t <= HL; t += 2.2) {
        if (br.some((b) => Math.abs(t - b) < 3.4)) continue;
        const off = Math.sin(t / 14 + ph) * 9, x = ca * t - sa * off, y = sa * t + ca * off;
        M.holes.push([r1(x), r1(y), 3.1]);
      }
      for (const b of br) { const off = Math.sin(b / 14 + ph) * 9; occAdd(ca * b - sa * off, sa * b + ca * off, 4); }
    }
    // a pond or two (not in the small/quick map)
    if (!T.quick && !T.river && !arch) for (let k = 0, n = 0; k < (T.swamp ? 200 : 40) * A && n < Math.round((T.k === 'd' ? 1 : T.swamp ? 9 : 2) * A); k++) {
      const [x, y] = rp(R - 10); if (!landAt(M, x, y, 10)) continue;
      const r = (T.swamp ? 4 : 3) + rnd() * (T.swamp ? 4 : 2.5); M.holes.push([r1(x), r1(y), r1(r)]); occAdd(x, y, r + 2); n++;
    }
    // swamp mud (slow going)
    if (T.swamp) for (let k = 0, n = 0; k < 300 * A && n < Math.round(14 * A); k++) {
      const [x, y] = rp(R - 6), r = 4 + rnd() * 5; if (!landAt(M, x, y, 1)) continue;
      M.mud.push([r1(x), r1(y), r1(r)]); n++;
    }
    // volcano: a crater in the middle, rivers of lava around it, ash everywhere
    if (T.volc) {
      const cr = Math.max(7, base * 0.13);
      M.circs.push([0, 0, r1(cr), 3]); occAdd(0, 0, cr + 1);
      for (let k = 0; k < 9; k++) { const a = rot + k * 0.7, d = cr + 3 + k * 1.6, r = 2.6 + rnd() * 1.6; M.lava.push([r1(Math.cos(a) * d), r1(Math.sin(a) * d), r1(r)]); occAdd(Math.cos(a) * d, Math.sin(a) * d, r + 1); }
      for (let k = 0, n = 0; k < 200 * A && n < Math.round(6 * A); k++) { const [x, y] = rp(R - 8), r = 3 + rnd() * 3; if (!free(x, y, r)) continue; M.lava.push([r1(x), r1(y), r1(r)]); occAdd(x, y, r + 1); n++; }
    }
    // frozen lakes (walkable, slippery)
    if (T.ice) for (let k = 0, n = 0; k < 60 * A && n < Math.round(T.ice * Math.pow(A, 0.7)); k++) {
      const [x, y] = rp(R - 12), r = 7 + rnd() * 5; if (!free(x, y, r)) continue;
      M.ice.push([r1(x), r1(y), r1(r)]); occAdd(x, y, r + 1); n++;
    }
    // hot springs (heal while standing in them) and geysers (erupt on a fixed beat)
    if (T.hsp) for (let k = 0, n = 0; k < 300 * A && n < Math.round(T.hsp * A); k++) {
      const [x, y] = rp(R - 10), r = 3 + rnd() * 1.5; if (!free(x, y, r + 1) || !landAt(M, x, y, 4)) continue;
      M.hsp.push([r1(x), r1(y), r1(r)]); occAdd(x, y, r + 1); n++;
    }
    if (T.gy) for (let k = 0, n = 0; k < 400 * A && n < Math.round(T.gy * A); k++) {
      const [x, y] = rp(R - 8); if (!free(x, y, 3) || !landAt(M, x, y, 3)) continue;
      M.gy.push([r1(x), r1(y), 2.6]); occAdd(x, y, 3); n++;
    }
    M.g = new Uint8Array(GN * GN);
    for (let iy = 0; iy < GN; iy++) for (let ix = 0; ix < GN; ix++) M.g[iy * GN + ix] = landAt(M, ix - HL + 0.5, iy - HL + 0.5, 0) ? 1 : 0;
    const addLoot = (x, y, bonus) => {
      for (const [t, n] of rollLoot(rnd, M, bonus)) {
        if (M.loot.length >= LCAP) return;
        const a = rnd() * 6.283, d = M.loot.length && n ? 0.5 * rnd() : 0;
        M.loot.push({ x: r1(x + Math.cos(a) * d), y: r1(y + Math.sin(a) * d), t, n });
      }
    };
    /* building: walls (thin rects), 1–2 doors (a door leaf rect that opens/closes) and windows (block walking, not bullets/eyes) */
    function addBld(x, y, w, h, nd, bonus, kind) {
      const x0 = Math.round(x - w / 2), y0 = Math.round(y - h / 2), x1 = x0 + w, y1 = y0 + h, TH = 0.5, D = 1.3, WD = 0.8;
      const bi = M.blds.length;
      const sides = [0, 1, 2, 3];
      for (let i = 3; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = sides[i]; sides[i] = sides[j]; sides[j] = t; }
      // inner wall for big buildings (two rooms, with a gap) — decided first so windows keep clear of it
      const inner = w >= 11 && h >= 8 && rnd() < 0.7 ? Math.round((x0 + x1) / 2) : null;
      const doors = [];
      /* one side: list of openings [centre offset along the side, half width, kind 'd'|'w'] → wall pieces + leaf/window rects */
      const side = (s, ops) => {
        const horiz = s === 0 || s === 2;
        const c0 = horiz ? x0 : y0, c1 = horiz ? x1 : y1;
        const fix = horiz ? (s === 0 ? y0 : y1 - TH) : (s === 3 ? x0 : x1 - TH);
        const mk = (u0, u1) => (horiz ? [u0, fix, u1, fix + TH] : [fix, u0, fix + TH, u1]);
        ops.sort((a, b) => a[0] - b[0]);
        let u = c0;
        for (const [c, hw, k] of ops) {
          if (c - hw > u) M.rects.push(mk(u, c - hw));
          const q = mk(c - hw, c + hw);
          const cx = horiz ? c : fix + TH / 2, cy = horiz ? fix + TH / 2 : c;
          const nx = horiz ? 0 : s === 3 ? -1 : 1, ny = horiz ? (s === 0 ? -1 : 1) : 0;
          if (k === 'd') { q.d = M.doors.length; M.doors.push({ x: cx, y: cy, nx, ny, b: bi, q, hw }); doors.push([cx, cy, nx, ny]); }
          else { q.w = M.wins.length; M.wins.push({ x: cx, y: cy, nx, ny, b: bi, q, hw }); }
          M.rects.push(q);
          u = c + hw;
        }
        if (c1 > u) M.rects.push(mk(u, c1));
      };
      for (let s = 0; s < 4; s++) {
        const hasD = sides.indexOf(s) < nd;
        const horiz = s === 0 || s === 2, c0 = horiz ? x0 : y0, len = horiz ? w : h, mid = c0 + len / 2;
        const ops = [];
        if (hasD) ops.push([mid + (rnd() * 2 - 1) * Math.max(0, len / 2 - D - 1.4), D, 'd']);
        // windows: up to two on long walls, kept away from corners, the door and the inner wall
        const nw = len >= 9 ? 2 : len >= 6 ? 1 : 0;
        for (let k = 0; k < nw; k++) {
          for (let tr = 0; tr < 6; tr++) {
            const c = c0 + 1.4 + WD + rnd() * (len - 2.8 - 2 * WD);
            if (ops.some((o) => Math.abs(o[0] - c) < o[1] + WD + 0.9)) continue;
            if (horiz && inner != null && Math.abs(c - inner) < WD + 0.8) continue;
            if (rnd() < 0.8) ops.push([c, WD, 'w']);
            break;
          }
        }
        side(s, ops);
      }
      if (inner != null) {
        const mx = inner, gy = y0 + 1.5 + rnd() * (h - 5);
        M.rects.push([mx - TH / 2, y0, mx + TH / 2, gy], [mx - TH / 2, gy + 2.4, mx + TH / 2, y1]);
      }
      const b = { x0, y0, x1, y1, doors, rf: Math.floor(rnd() * 8), k: kind || 0, ls: 0 };
      M.blds.push(b);
      const nl = Math.max(2, Math.min(6, Math.round(w * h / 22))), l0 = M.loot.length;
      for (let i = 0; i < nl; i++) addLoot(x0 + 1.4 + rnd() * (w - 2.8), y0 + 1.4 + rnd() * (h - 2.8), bonus);
      for (let i = l0; i < M.loot.length; i++) b.ls += ikind(M.loot[i].t) === 'g' ? 1 + GUN[M.loot[i].t].v * 0.1 : 0.4;
      return b;
    }
    // roads (city / military): a coarse grid of strips, drawn only
    if (T.k === 'c' || T.k === 'm' || T.k === 'f') {
      const sp = T.k === 'c' ? 22 : 30, o = rnd() * sp;
      for (let v = -HL + o; v < HL; v += sp) { M.roads.push([v - 2, -HL, v + 2, HL]); M.roads.push([-HL, v - 2, HL, v + 2]); }
    }
    const onRoad = (x, y, pad) => M.roads.some((q) => x > q[0] - pad && x < q[2] + pad && y > q[1] - pad && y < q[3] + pad);
    // military base: a fenced yard with hangars and containers
    if (T.k === 'm') for (let nb = 0, tries = 0; nb < Math.max(1, Math.round(A * 0.6)) && tries < 60; tries++) {
      const [bx, by] = nb ? rp(R * 0.75) : rp(14 * f), W2 = 20, H2 = 15, TH = 0.35, G = 2.2;
      if (nb && !free(bx, by, 26)) continue;
      // (was: the first base skipped every check, so a pond could end up inside its hangars — water under the floor, windows onto water)
      { let wet = false; for (let gx = -W2; gx <= W2 && !wet; gx += 2) for (let gy = -H2; gy <= H2; gy += 2) if (!landAt(M, bx + gx, by + gy, 1)) { wet = true; break; } if (wet && tries < 50) continue; }
      nb++;
      const fx0 = bx - W2, fx1 = bx + W2, fy0 = by - H2, fy1 = by + H2;
      M.fence.push([fx0, fy0, fx1, fy1]);
      M.rects.push([fx0, fy0, bx - G, fy0 + TH], [bx + G, fy0, fx1, fy0 + TH], [fx0, fy1 - TH, bx - G, fy1], [bx + G, fy1 - TH, fx1, fy1],
        [fx0, fy0, fx0 + TH, by - G], [fx0, by + G, fx0 + TH, fy1], [fx1 - TH, fy0, fx1, by - G], [fx1 - TH, by + G, fx1, fy1]);
      occAdd(bx, by, 26);
      addBld(bx - 10, by - 6, 14, 9, 2, 0.35, 1); addBld(bx + 10, by + 6, 14, 9, 2, 0.35, 1);
      for (let k = 0; k < 7; k++) {
        const cx = bx + (k % 2 ? 6 : -6) + (rnd() - 0.5) * 6, cy = by + (k < 3 ? 6 : -6) + (rnd() - 0.5) * 3 + (k - 3) * 0.3;
        const hor = rnd() < 0.6, w = hor ? 5.6 : 2.4, h = hor ? 2.4 : 5.6;
        const q = [r1(cx - w / 2), r1(cy - h / 2), r1(cx + w / 2), r1(cy + h / 2)];
        if (M.blds.some((b) => q[2] > b.x0 - 1.2 && q[0] < b.x1 + 1.2 && q[3] > b.y0 - 1.2 && q[1] < b.y1 + 1.2)) continue;
        if (M.cont.some((c) => q[2] > c[0] - 1.6 && q[0] < c[2] + 1.6 && q[3] > c[1] - 1.6 && q[1] < c[3] + 1.6)) continue;
        M.rects.push(q); M.cont.push(q.concat([Math.floor(rnd() * 4)]));
      }
      for (let k = 0; k < 6; k++) addLoot(bx + (rnd() - 0.5) * 34, by + (rnd() - 0.5) * 24, 0.3);
    }
    // houses
    const want = Math.round(T.bld * A);
    if (T.fact) {
      // old factories (big halls, part of the roof may come down) between ordinary houses
      for (let k = 0; k < want * 60 && M.blds.length < want; k++) {
        const big = M.blds.length % 3 !== 2, [x, y] = rp(R - 8), w = big ? 14 + Math.floor(rnd() * 8) : 7 + Math.floor(rnd() * 5), h = big ? 11 + Math.floor(rnd() * 6) : 6 + Math.floor(rnd() * 4), r = hyp(w, h) / 2;
        if (!free(x, y, r + 0.6) || onRoad(x, y, r - 0.5)) continue;
        occAdd(x, y, r + 0.6); addBld(x, y, w, h, 2, big ? 0.12 : 0.05, big ? 2 : 0);
      }
    } else if (T.k === 'c') {
      for (let k = 0; k < want * 60 && M.blds.length < want; k++) {
        const [x, y] = rp(R - 6), w = 7 + Math.floor(rnd() * 6), h = 6 + Math.floor(rnd() * 5), r = hyp(w, h) / 2;
        if (!free(x, y, r + 0.4) || onRoad(x, y, r - 0.5)) continue;
        occAdd(x, y, r + 0.4); addBld(x, y, w, h, rnd() < 0.5 ? 1 : 2, 0.05);
      }
    } else if (T.k === 'd') {
      // villages
      const vil = []; for (let k = 0; k < 80 * A && vil.length < Math.round(4 * A); k++) { const p = rp(R - 14); if (landAt(M, p[0], p[1], 12) && vil.every((v) => hyp(v[0] - p[0], v[1] - p[1]) > 30)) vil.push(p); }
      for (let k = 0; k < want * 80 && M.blds.length < want; k++) {
        const v = vil[k % Math.max(1, vil.length)] || [0, 0], a = rnd() * 6.283, d = 4 + rnd() * 12;
        const x = v[0] + Math.cos(a) * d, y = v[1] + Math.sin(a) * d, w = 6 + Math.floor(rnd() * 5), h = 6 + Math.floor(rnd() * 3), r = hyp(w, h) / 2;
        if (!free(x, y, r + 0.6)) continue;
        occAdd(x, y, r + 0.6); addBld(x, y, w, h, rnd() < 0.5 ? 1 : 2, 0.05);
      }
    } else {
      const small = T.k === 'j';
      for (let k = 0; k < want * 60 && M.blds.length < want + (T.k === 'm' ? 2 : 0); k++) {
        const [x, y] = rp(R - 4), w = (small ? 6 : 7) + Math.floor(rnd() * (small ? 3 : 5)), h = 6 + Math.floor(rnd() * 3), r = hyp(w, h) / 2;
        if (!free(x, y, r + 0.6) || onRoad(x, y, r - 1)) continue;
        occAdd(x, y, r + 0.6); addBld(x, y, w, h, rnd() < 0.5 ? 1 : 2, T.quick ? 0.12 : 0.04);
      }
    }
    // mesas (desert), rocks, trees, cacti, bushes
    for (let k = 0, n = 0; k < 400 * A && n < Math.round(T.mesa * A); k++) { const [x, y] = rp(R - 6), r = 3.5 + rnd() * 3; if (!free(x, y, r)) continue; occAdd(x, y, r); M.circs.push([r1(x), r1(y), r1(r), 3]); n++; }
    for (let k = 0, n = 0; k < 600 * A && n < Math.round(T.rock * A); k++) { const [x, y] = rp(R), r = 0.9 + rnd() * 0.9; if (!free(x, y, r)) continue; occAdd(x, y, r); M.circs.push([r1(x), r1(y), r1(r), 0]); n++; }
    for (let k = 0, n = 0; k < 900 * A && n < Math.round(T.tree * A); k++) { const [x, y] = rp(R); if (!free(x, y, 1.4) || onRoad(x, y, 1)) continue; occAdd(x, y, 1.4); M.circs.push([r1(x), r1(y), 0.5, 1]); n++; }
    for (let k = 0, n = 0; k < 900 * A && n < Math.round(T.cac * A); k++) { const [x, y] = rp(R); if (!free(x, y, 0.6) || onRoad(x, y, 1)) continue; occAdd(x, y, 0.6); M.circs.push([r1(x), r1(y), 0.35, 2]); n++; }
    for (let k = 0, n = 0; k < 1500 * A && n < Math.round(T.bush * A); k++) { const [x, y] = rp(R), r = 1.6 + rnd() * 0.8; if (!free(x, y, r * 0.8) || onRoad(x, y, 0)) continue; occAdd(x, y, r * 0.8); M.bush.push([r1(x), r1(y), r1(r)]); n++; }
    // spatial grid (cells of CS m): rects, circles, buildings, bushes
    const NC = CN * CN;
    M.cr = []; M.cc = []; M.cb = []; M.cu = [];
    for (let i = 0; i < NC; i++) { M.cr.push([]); M.cc.push([]); M.cb.push([]); M.cu.push([]); }
    const ins = (arr, j, x0, y0, x1, y1) => {
      const ax = clamp(Math.floor((x0 + HL) / CS), 0, CN - 1), bx = clamp(Math.floor((x1 + HL) / CS), 0, CN - 1);
      const ay = clamp(Math.floor((y0 + HL) / CS), 0, CN - 1), by = clamp(Math.floor((y1 + HL) / CS), 0, CN - 1);
      for (let cy = ay; cy <= by; cy++) for (let cx = ax; cx <= bx; cx++) arr[cy * CN + cx].push(j);
    };
    M.rects.forEach((q, j) => ins(M.cr, j, q[0], q[1], q[2], q[3]));
    M.circs.forEach((c, j) => ins(M.cc, j, c[0] - c[2], c[1] - c[2], c[0] + c[2], c[1] + c[2]));
    M.blds.forEach((b, j) => ins(M.cb, j, b.x0, b.y0, b.x1, b.y1));
    M.bush.forEach((b, j) => ins(M.cu, j, b[0] - b[2], b[1] - b[2], b[0] + b[2], b[1] + b[2]));
    M.rs = new Uint32Array(M.rects.length); M.ccs = new Uint32Array(M.circs.length);
    // scattered loot
    const LS = new Set(); for (const l of M.loot) LS.add(Math.floor(l.x / 4) + ',' + Math.floor(l.y / 4));
    for (let k = 0; k < 3000 * A && M.loot.length < LCAP && k < T.loot * 30 * A; k++) {
      if (M.loot.length >= M.blds.length * 4 + T.loot * A) break;
      const [x, y] = rp(R), lk = Math.floor(x / 4) + ',' + Math.floor(y / 4);
      if (LS.has(lk) || !landAt(M, x, y, 0.6) || solidAt(M, x, y, 0.8)) continue;
      LS.add(lk); addLoot(x, y, 0);
    }
    M.cl = []; for (let i = 0; i < CN * CN; i++) M.cl.push([]);
    M.loot.forEach((l, j) => { const c = cellOf(l.x, l.y); if (c >= 0) M.cl[c].push(j); });
    // vehicles
    const vtry = (type, n) => {
      for (let k = 0, m = 0; k < 800 * A && m < n; k++) {
        let x, y;
        if (VEH[type].land !== 1) {   // boats: water near the shore (or on the river / swamp ponds)
          if (M.holes.length && (T.river || T.swamp) && rnd() < 0.6) { const h = M.holes[Math.floor(rnd() * M.holes.length)]; x = h[0]; y = h[1]; }
          else { const p = lobePt(M.lobes[Math.floor(rnd() * M.lobes.length)], rnd() * 6.283, 3.2); x = p[0]; y = p[1]; }
          if (!isWater(M, x, y) || Math.abs(x) > HL - 4 || Math.abs(y) > HL - 4) continue;
          let wet = true; for (let a = 0; a < 6.28; a += 0.8) if (!isWater(M, x + Math.cos(a) * 1.5, y + Math.sin(a) * 1.5)) wet = false;
          if (!wet) continue;
        } else {
          if (M.roads.length && rnd() < 0.75) { const q = M.roads[Math.floor(rnd() * M.roads.length)]; x = q[0] === -HL ? (rnd() * 2 - 1) * R : (q[0] + q[2]) / 2; y = q[0] === -HL ? (q[1] + q[3]) / 2 : (rnd() * 2 - 1) * R; }
          else [x, y] = rp(R - 3);
          if (!free(x, y, 2.2) || inBld(M, x, y) >= 0) continue;
        }
        if (M.vsp.some((v) => hyp(v[0] - x, v[1] - y) < 8)) continue;
        occAdd(x, y, 2.2); M.vsp.push([r1(x), r1(y), r2(rnd() * 6.283), type]); m++;
      }
    };
    // every island has the ordinary vehicles; each island adds its own (snow, sand, swamp, water, the rare armoured car)
    const vk = T.quick ? 0.6 : 1;
    for (const [ty, c] of BASEV.concat(T.vs || [])) {
      const want = c * vk * (VEH[ty].land === 1 ? A : Math.pow(A, 0.6));
      vtry(ty, Math.min(14, Math.floor(want) + (rnd() < want % 1 ? 1 : 0)));
    }
    return M;
  }
  const MAPC = {};
  function getMap(sd, mk, np) {
    const k = sd + '|' + mk + '|' + Math.round(scaleOf(np) * 100);
    if (MAPC[k]) { useMap(MAPC[k]); return MAPC[k]; }
    const ks = Object.keys(MAPC); if (ks.length > 2) delete MAPC[ks[0]];
    return (MAPC[k] = makeMap(sd, mk, np));
  }

  /* ======================= geometry ======================= */
  function collide(M, p, r) {
    nearSolids(M, p.x - r, p.y - r, p.x + r, p.y + r, (q) => {
      if (p.x < q[0] - r || p.x > q[2] + r || p.y < q[1] - r || p.y > q[3] + r) return false;
      const cx = clamp(p.x, q[0], q[2]), cy = clamp(p.y, q[1], q[3]);
      const dx = p.x - cx, dy = p.y - cy, d = hyp(dx, dy);
      if (d >= r) return false;
      if (q.d != null) p.bd = q.d;
      if (d < 1e-6) {
        const l = p.x - q[0], rr = q[2] - p.x, t = p.y - q[1], b = q[3] - p.y, m = Math.min(l, rr, t, b);
        if (m === l) p.x = q[0] - r; else if (m === rr) p.x = q[2] + r; else if (m === t) p.y = q[1] - r; else p.y = q[3] + r;
        p.hit = 1; return false;
      }
      const nx = dx / d, ny = dy / d; p.x = cx + nx * r; p.y = cy + ny * r;
      const vn = p.vx * nx + p.vy * ny; if (vn < 0) { p.vx -= vn * nx; p.vy -= vn * ny; p.hit = Math.max(p.hit || 0, -vn); }
      return false;
    }, (c) => {
      let dx = p.x - c[0], dy = p.y - c[1]; const R = c[2] + r, d2 = dx * dx + dy * dy;
      if (d2 >= R * R) return false;
      let d = Math.sqrt(d2); if (d < 1e-6) { dx = 0; dy = 1; d = 1; }
      const nx = dx / d, ny = dy / d; p.x = c[0] + nx * R; p.y = c[1] + ny * R;
      const vn = p.vx * nx + p.vy * ny; if (vn < 0) { p.vx -= vn * nx; p.vy -= vn * ny; p.hit = Math.max(p.hit || 0, -vn); }
      return false;
    });
    const lim = HL - r - 1;
    if (p.x < -lim) p.x = -lim; else if (p.x > lim) p.x = lim;
    if (p.y < -lim) p.y = -lim; else if (p.y > lim) p.y = lim;
  }
  /* distance along a ray (unit dir) to the first wall/rock/tree, up to maxD — DDA over the cell grid */
  function rayStatic(M, x0, y0, ux, uy, maxD, ign) {
    let best = maxD;
    const stp = ++M.stp;
    const gx = x0 + HL, gy = y0 + HL;
    let cx = Math.floor(gx / CS), cy = Math.floor(gy / CS);
    const sx = ux > 0 ? 1 : -1, sy = uy > 0 ? 1 : -1;
    const tdx = Math.abs(ux) > 1e-9 ? CS / Math.abs(ux) : 1e9, tdy = Math.abs(uy) > 1e-9 ? CS / Math.abs(uy) : 1e9;
    let tmx = Math.abs(ux) > 1e-9 ? (ux > 0 ? (cx + 1) * CS - gx : gx - cx * CS) / Math.abs(ux) : 1e9;
    let tmy = Math.abs(uy) > 1e-9 ? (uy > 0 ? (cy + 1) * CS - gy : gy - cy * CS) / Math.abs(uy) : 1e9;
    let tc = 0;
    for (let guard = 0; guard < 64 && tc <= best; guard++) {
      if (cx >= 0 && cy >= 0 && cx < CN && cy < CN) {
        const c = cy * CN + cx;
        for (const j of M.cr[c]) {
          if (M.rs[j] === stp) continue; M.rs[j] = stp;
          const q = M.rects[j];
          if (q.w != null || (q.d != null && M.dS && M.dS[q.d])) continue;
          let t0 = 0, t1 = best;
          if (Math.abs(ux) < 1e-9) { if (x0 < q[0] || x0 > q[2]) continue; } else { let a = (q[0] - x0) / ux, b = (q[2] - x0) / ux; if (a > b) { const t = a; a = b; b = t; } if (a > t0) t0 = a; if (b < t1) t1 = b; }
          if (Math.abs(uy) < 1e-9) { if (y0 < q[1] || y0 > q[3]) continue; } else { let a = (q[1] - y0) / uy, b = (q[3] - y0) / uy; if (a > b) { const t = a; a = b; b = t; } if (a > t0) t0 = a; if (b < t1) t1 = b; }
          if (ign && t0 <= 1e-6) continue;     // eyes start inside this block (hugging a wall/crate): don't let it blind me
          if (t0 <= t1 && t0 < best) best = t0;
        }
        for (const j of M.cc[c]) {
          if (M.ccs[j] === stp) continue; M.ccs[j] = stp;
          const k = M.circs[j], ox = x0 - k[0], oy = y0 - k[1], R = k[3] === 1 ? 0.45 : k[2] * 0.92;
          const b = ox * ux + oy * uy, cc = ox * ox + oy * oy - R * R;
          if (cc < 0) continue;     // starting inside (shouldn't happen): ignore
          const disc = b * b - cc; if (disc < 0) continue;
          const t = -b - Math.sqrt(disc); if (t >= 0 && t < best) best = t;
        }
      }
      if (tmx < tmy) { tc = tmx; tmx += tdx; cx += sx; } else { tc = tmy; tmy += tdy; cy += sy; }
      if (cx < -1 || cy < -1 || cx > CN || cy > CN) break;
    }
    return best;
  }
  function los(M, x0, y0, x1, y1) {
    const d = hyp(x1 - x0, y1 - y0); if (d < 0.05) return true;
    return rayStatic(M, x0, y0, (x1 - x0) / d, (y1 - y0) / d, d) >= d - 0.05;
  }
  function rayCircle(x0, y0, ux, uy, cx, cy, R) {
    const ox = x0 - cx, oy = y0 - cy, b = ox * ux + oy * uy, c = ox * ox + oy * oy - R * R;
    if (c < 0) return 0;
    const disc = b * b - c; if (disc < 0) return -1;
    const t = -b - Math.sqrt(disc); return t >= 0 ? t : -1;
  }
  /* ======================= world ======================= */
  function mkPlayer(i, tm) {
    return { i, tm, x: 0, y: 0, vx: 0, vy: 0, a: Math.PI / 2, hp: HPMAX, kd: 0, khp: 0, kn: 0, out: 0, place: 0, kills: 0,
      g: [null, null, null], ml: -1, th: THROW.map(() => 0), ts: 0, hl: HEAL.map(() => 0), am: AMMO.map(() => 0), at: ATT.map(() => 0), spc: 0,
      vs: 0, hm: 0, bp: 0, sl: 3, cd: 0, rl: 0, bq: 0, bt: 0, use: 0, ut: -1, uT: 0, bl: 0, ads: 0,
      stm: STM.max, sb: 0, sx: 0, ex: 0, sr: 0, ns: 0, cr: 0, lnd: 0, vt: 0, vw: null, lk: 0, bd: -1,
      veh: -1, seat: 0, rv: -1, rvb: 0, rev: 0, ft: 0, fl: 0, lb: -1, lbT: -99, lw: 0, air: 0, lx: NaN, ly: NaN, fh: 0, swim: 0, pk: 0, hit: 0,
      dd: 0, sf: 0, sh: 0, hs: 0, dm: 0, wu: [], dt: 0, rn: 0 };
  }
  const teamSize = (st) => (st.ts > 1 ? st.ts : st.tm ? 2 : 1);
  function newWorld(st) {
    const M = getMap(st.sd, st.mk, st.np), pl = [], quick = !!M.T.quick, ts = teamSize(st);
    const ta = ts > 1 && Array.isArray(st.ta) && st.ta.length === st.np ? st.ta : null;   // free team choice (pre-match 팀 편성)
    for (let i = 0; i < st.np; i++) pl.push(mkPlayer(i, ts > 1 ? (ta ? ta[i] | 0 : Math.floor(i / ts)) : i));
    const ds = new Uint8Array(M.doors.length), dl = new Float32Array(M.doors.length);
    M.dS = ds; M.dL = dl;
    // bigger islands for more players: wider zone circles and longer phases (8 → about 6–8 min, 50 → 10–15 min)
    const f = M.f, tf = 1 + (f - 1) * 0.55;
    const pr = rngOf(st.sd * 3 + 1), ZS = (quick ? ZQ : ZW).map((z) => [Math.round(z[0] * tf), Math.round(z[1] * tf), r1(z[2] * f)]), R0 = Math.round((quick ? 62 : 125) * f);
    const W = { M, tm: ts > 1 ? 1 : 0, ts, ph: 0, t: DROP_T, T: 0, pl, pj: [], tk: new Array(M.loot.length).fill(0), dr: [], bx: [], ar: [], ad: [],
      ds, dl, dv: 0, pg: [], pgn: 0, mk: {}, auto: st.ap ? 1 : 0, rg: st.rg ? 1 : 0, pr: st.pr ? 1 : 0, prf: st.pr ? 1 : 0,
      an: [], tg: [], lt: [], ns: [], rz: null, rzT: 75 + pr() * 50, db: [], dbT: 8, ss: 0, ssT: 70 + pr() * 60, todOff: DAY * 0.05, dk: 0, hz: 999, vr: 999, wx: st.rg ? 0 : st.wx | 0, wa: rngOf(st.sd * 5 + 9)() * 6.283, lg: [], lgT: 20,
      cap: Math.round(CAP_T * tf), dcap: 36 + st.np, bcap: Math.max(12, st.np),
      vh: M.vsp.map((v) => ({ x: v[0], y: v[1], a: v[2], v: 0, vx: 0, vy: 0, hp: VEH[v[3]].hp, ty: v[3], lb: -1 })),
      ZS, z: { i: 0, s: 0, t: ZS[0][0], cx: 0, cy: 0, r: R0, ax: 0, ay: 0, ar: R0, nx: 0, ny: 0, nr: ZS[0][2] },
      pa: pr() * 6.283, po: (pr() - 0.5) * 40 * f, fx: [], fxn: 0, tp: {}, res: null, lv: 1 };
    W.dg = []; W.rt = !W.rg && ts > 1 ? makeTowers(M, st.sd) : [];
    if (W.rg) setupRange(W);
    else {
      spawnAll(W, rngOf(st.sd * 7 + 3)); spawnAnimals(W);
      const hu = (st.hu || []).map((i) => W.pl[i]).filter(Boolean);
      W.an = W.an.filter((a) => hu.every((p) => hyp(a.x - p.x, a.y - p.y) >= 40));   // no animal right next to a person at the start
    }
    envStep(W);
    return W;
  }
  /* 귀환 송신탑: a few fixed masts per island (same seed → same spots for everyone) */
  const RC = { tag: 90, ch: 8, r: 3.2, pick: 1.6, hear: 70 };
  const rcMaxZ = (W) => (W.M.T.quick ? 2 : 3);
  const rcOn = (W) => !!W.tm && !W.rg && W.z.i < rcMaxZ(W) && !W.res;
  function makeTowers(M, sd) {
    const rnd = rngOf(sd * 13 + 7), n = clamp(Math.round(3 + M.f * 1.6), 4, 8), out = [], R = M.base * 0.82;
    for (let t = 0; t < n; t++) {
      let best = null, bs = -1;
      for (let k = 0; k < 50; k++) {
        const a = rnd() * 6.2832, d = Math.sqrt(rnd()) * R, x = Math.cos(a) * d, y = Math.sin(a) * d;
        if (Math.abs(x) > HL - 8 || Math.abs(y) > HL - 8 || !landAt(M, x, y, 3) || isWater(M, x, y) || !okSpot(M, x, y) || inBld(M, x, y) >= 0 || (M.lava.length && inLava(M, x, y))) continue;
        let md = 1e9; for (const q of out) md = Math.min(md, hyp(q.x - x, q.y - y));
        if (md > bs) { bs = md; best = { x: r1(x), y: r1(y) }; }
      }
      if (best) out.push(best);
    }
    return out;
  }
  function nearTower(W, x, y, R) { let bj = -1, bd = R; (W.rt || []).forEach((t, j) => { const d = hyp(t.x - x, t.y - y); if (d < bd) { bd = d; bj = j; } }); return bj; }
  const tagOf = (W, i) => (W.dg ? W.dg.find((g) => g.by === i) : null);
  /* bring a fallen teammate back: parachute down beside the tower with basic gear */
  function recall(W, p, hooks) {
    const g = tagOf(W, p.i), T = W.rt[p.rcT];
    if (!g || !T) return;
    W.dg.splice(W.dg.indexOf(g), 1);
    const q = W.pl[g.i]; if (!q || !q.out || q.tm !== p.tm) return;
    const a = Math.random() * 6.283, s = snapFree(W.M, T.x + Math.cos(a) * 3, T.y + Math.sin(a) * 3);
    Object.assign(q, { out: 0, kd: 0, khp: 0, hp: 100, place: 0, x: s[0], y: s[1], vx: 0, vy: 0, air: 2.5, lnd: 1.2, use: 0, ut: -1, rv: -1, rvb: 0, rl: 0, ads: 0, cr: 0, sx: 0, burn: 0, gas: 0, lb: -1, veh: -1, stm: STM.max, kn: 0 });
    const pi = GUN.findIndex((G) => G.nm === 'P92');
    q.g = [null, null, pi >= 0 ? mkGun(pi, GUN[pi].mg) : null]; q.sl = q.g[2] ? 2 : 3;
    if (pi >= 0) q.am[GUN[pi].am] = 30;
    q.hl[0] = 2; q.vs = 1;
    q.rcn = (q.rcn || 0) + 1; p.rvc = (p.rvc || 0) + 1;
    emit(W, hooks, 40, q.x, q.y, q.i, 3);
  }
  /* 인식표: lie where the teammate fell, a teammate walks over them to carry them; dropped again if the carrier dies */
  function stepTags(W, h, hooks) {
    if (!W.dg) return;
    if (!rcOn(W)) {
      if (W.dg.length || W.rcOpen) { W.dg = []; for (const p of W.pl) if (p.ut === 10) { p.use = 0; p.ut = -1; } emit(W, hooks, 40, 0, 0, -1, 4); }
      W.rcOpen = 0; return;
    }
    W.rcOpen = 1;
    for (let k = W.dg.length - 1; k >= 0; k--) {
      const g = W.dg[k], o = W.pl[g.i];
      if (!o || !o.out) { W.dg.splice(k, 1); continue; }
      if (g.by >= 0) { const c = W.pl[g.by]; if (c && !c.out) { g.x = r1(c.x); g.y = r1(c.y); continue; } g.by = -1; }
      g.t -= h; if (g.t <= 0) { W.dg.splice(k, 1); continue; }
      for (const q of W.pl) if (!q.out && !q.kd && q.air <= 0 && q.veh < 0 && q.tm === o.tm && hyp(q.x - g.x, q.y - g.y) < RC.pick) { g.by = q.i; emit(W, hooks, 40, q.x, q.y, q.i, 10 + g.i); break; }
    }
  }
  /* no plane: everyone starts on land inside the first zone, spread out; teammates together */
  function spawnAll(W, rnd) {
    const M = W.M, z = W.z, nt = W.pl.reduce((m, p) => Math.max(m, p.tm + 1), 0), anchors = [];
    const R = Math.min(z.r * 0.82, HL - 8);
    const okA = (x, y) => Math.abs(x) < HL - 6 && Math.abs(y) < HL - 6 && landAt(M, x, y, 2) && !isWater(M, x, y) && okSpot(M, x, y) && !(M.lava.length && inLava(M, x, y));
    for (let t = 0; t < nt; t++) {
      let best = null, bs = -1;
      for (let k = 0; k < 40; k++) {
        const a = rnd() * 6.2832, d = Math.sqrt(rnd()) * R, x = z.cx + Math.cos(a) * d, y = z.cy + Math.sin(a) * d;
        if (!okA(x, y)) continue;
        let md = 1e9; for (const q of anchors) md = Math.min(md, hyp(q[0] - x, q[1] - y));
        if (md > bs) { bs = md; best = [x, y]; }
        if (k > 14 && best) break;
      }
      if (!best) { const s0 = snapFree(M, z.cx + (rnd() - 0.5) * 20, z.cy + (rnd() - 0.5) * 20); best = s0; }
      anchors.push(best);
    }
    const placed = [];
    for (const p of W.pl) {
      const A = anchors[p.tm] || anchors[0];
      let pos = null;
      for (let k = 0; k < 30 && !pos; k++) {
        const a = rnd() * 6.2832, d = k === 0 && !placed.some((q) => q.tm === p.tm) ? 0 : 1.8 + rnd() * (2 + k * 0.2), x = A[0] + Math.cos(a) * d, y = A[1] + Math.sin(a) * d;
        if (!okA(x, y) || placed.some((q) => hyp(q.x - x, q.y - y) < 1.6)) continue;
        pos = [x, y];
      }
      if (!pos) pos = snapFree(M, A[0] + rnd() * 2, A[1] + rnd() * 2);
      p.x = pos[0]; p.y = pos[1]; p.vx = p.vy = 0; p.a = rnd() * 6.2832; p.air = 0;
      placed.push(p);
    }
    W.ph = 2; W.t = 0; W.T = 0;
    pickNext(W);
  }
  /* shooting range: no zone, no bots; targets at 10–120 m straight ahead (some sliding), everything free */
  const RANGE_MAP = { k: 'r', nm: '사격장', sh: 'round', base: 66, amp: 1.5, bld: 4, bush: 0, rock: 6, tree: 10, cac: 0, mesa: 0, loot: 0, vs: [[4, 1], [2, 1], [0, 1]], ani: [], range: 1,
    gr: '#86b06a', gr2: '#76a05a', sand: '#e6d29c', roof: ['#7a6a5a', '#5d7896'], tc: '#3f7f3a', road: '#4b4e55', note: '혼자 연습하는 곳' };
  function setupRange(W) {
    W.ph = 2; W.T = 0; W.cap = 1e9; W.ZS = []; W.z.r = W.z.ar = W.z.nr = 9999; W.z.i = 0;
    const M = W.M, y0 = M.base * 0.62;
    W.pl.forEach((p, k) => {
      const s = snapFree(M, (k - (W.pl.length - 1) / 2) * 3, y0); p.x = s[0]; p.y = s[1]; p.a = -Math.PI / 2;
      p.g[0] = mkGun(GUN.findIndex((G) => G.nm === 'M416'), 30); p.g[2] = mkGun(GUN.findIndex((G) => G.nm === 'P92'), 15); p.sl = 0;
      p.am = AMMO.map(() => 999); p.th = THROW.map(() => 5); p.hl = HEAL.map(() => 5); p.vs = 3; p.hm = 3; p.bp = 3;
    });
    const T = [[0, 10], [-3, 25], [3, 25], [0, 50], [-5, 50, 4], [5, 75], [0, 100], [-4, 120], [8, 40, 6]];
    for (const [dx, d, mx] of T) { const s = snapFree(M, dx, y0 - d); W.tg.push({ x: r1(s[0]), y: r1(s[1]), bx: s[0], hp: 100, mx: W.pr ? 0 : mx || 0, mx0: mx || 0, ph: Math.random() * 6, sp: 0.9, d, rt: 0, lh: -9 }); }
  }
  function emit(W, hooks, code, a, b, c, d) {
    W.fxn++;
    W.fx.push([W.fxn, code, r1(a), r1(b), c | 0, d | 0]); if (W.fx.length > 48) W.fx.shift();
    if (hooks && hooks.fx) hooks.fx(code, a, b, c | 0, d | 0);
  }
  function teamsAlive(W) { const s = {}; let n = 0; for (const p of W.pl) if (!p.out && !s[p.tm]) { s[p.tm] = 1; n++; } return n; }
  function pickNext(W) {
    const z = W.z, nr = W.ZS[z.i][2], m = Math.max(0, z.r - nr) * (z.i === 0 ? 0.4 : 0.9);
    let bx = z.cx, by = z.cy;
    for (let k = 0; k < 60; k++) {
      const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * m, x = z.cx + Math.cos(a) * d, y = z.cy + Math.sin(a) * d;
      if (landAt(W.M, x, y, 0) && Math.abs(x) < HL - 6 && Math.abs(y) < HL - 6) { bx = x; by = y; break; }
    }
    z.nx = r1(bx); z.ny = r1(by); z.nr = nr;
  }
  function zoneStep(W, h, hooks) {
    const z = W.z, ZS = W.ZS;
    if (z.i >= ZS.length) return;
    z.t -= h;
    if (z.s === 0) {
      if (z.t <= 0) {
        z.s = 1; z.t = ZS[z.i][1]; z.ax = z.cx; z.ay = z.cy; z.ar = z.r; emit(W, hooks, 13, z.nx, z.ny, z.i, 0);
        if (z.i < (W.M.T.quick ? 2 : 4)) spawnDrop(W, hooks);
      }
    } else {
      const k = 1 - Math.max(0, z.t) / ZS[z.i][1];
      z.cx = z.ax + (z.nx - z.ax) * k; z.cy = z.ay + (z.ny - z.ay) * k; z.r = z.ar + (z.nr - z.ar) * k;
      if (z.t <= 0) {
        z.i++; z.s = 0;
        if (z.i < ZS.length) { z.t = ZS[z.i][0]; pickNext(W); } else { z.t = 0; z.r = 0; }
      }
    }
  }
  const zoneDps = (W) => ZDPS[Math.min(W.z.i, ZDPS.length - 1)];
  const outside = (W, p) => hyp(p.x - W.z.cx, p.y - W.z.cy) > W.z.r;
  function spawnDrop(W, hooks) {
    const z = W.z, M = W.M;
    for (let k = 0; k < 80; k++) {
      const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * z.nr * 0.75, x = z.nx + Math.cos(a) * d, y = z.ny + Math.sin(a) * d;
      if (!landAt(M, x, y, 1) || solidAt(M, x, y, 1.2) || inBld(M, x, y) >= 0) continue;
      W.ad.push({ x: r1(x), y: r1(y), t: 12, op: 0 }); if (W.ad.length > 4) W.ad.shift();
      emit(W, hooks, 14, x, y, 0, 0);
      return;
    }
  }
  function openDrop(W, d, p, hooks) {
    d.op = 1;
    const ag = [];
    GUN.forEach((G, i) => { if (G.po === 'A') ag.push(i); });
    const g = ag[Math.floor(Math.random() * ag.length)], G = GUN[g];
    const it = [[g, G.mg], [I_AMMO + G.am, AMMO[G.am].pk * 2]];
    const extra = [[I_VEST + 2, 1], [I_HELM + 2, 1], [I_HEAL + 2, 1], [I_ATT + 3, 1], [I_HEAL + 3, 1], [I_BAG + 2, 1]];
    for (let k = 0; k < 2; k++) it.push(extra.splice(Math.floor(Math.random() * extra.length), 1)[0]);
    W.bx.push({ x: d.x, y: d.y, it, ad: 1 }); if (W.bx.length > W.bcap) W.bx.shift();
    W.lv++;
    emit(W, hooks, 15, d.x, d.y, p.i, 0);
  }

  /* ----- inventory helpers ----- */
  // a gun in a slot: { t, m: rounds in the magazine, a: [5 attachment slots: ATT index + 1, 0 = empty] }
  const mkGun = (t, m) => ({ t, m: m | 0, a: [0, 0, 0, 0, 0] });
  const NOEFF = { rc: 1, ads: 1, hip: 1, mvs: 1, rec: 1, mg: 1, rl: 1, pel: 1, sup: 0, fh: 0, lt: 0, lv: 0, cant: 0 };
  /* what the mounted attachments add up to (multipliers) */
  function effOf(w) {
    if (!w || !w.a) return NOEFF;
    let e = null;
    for (let k = 0; k < 5; k++) {
      const v = w.a[k]; if (!v) continue; const A = ATT[v - 1]; if (!A) continue;
      if (!e) e = Object.assign({}, NOEFF);
      for (const f of ['rc', 'ads', 'hip', 'mvs', 'rec', 'mg', 'rl', 'pel']) if (A[f]) e[f] *= A[f];
      if (A.sup) e.sup = 1; if (A.fh) e.fh = 1; if (A.lt) e.lt = 1; if (A.lv) e.lv = A.lv; if (A.cant) e.cant = 1;
    }
    return e || NOEFF;
  }
  const magW = (w) => { const G = GUN[w.t]; return G.mg > 1 ? Math.round(G.mg * effOf(w).mg) : G.mg; };
  const scW = (w) => Math.max(GUN[w.t].isc, Math.min(effOf(w).lv, CLS[GUN[w.t].c].scap));
  const supW = (w) => !!(GUN[w.t].sup || effOf(w).sup);
  const OH = (t) => GUN[t].c === 0 || !!GUN[t].oh;                     // one-handed: usable while driving
  const pistolSlot = (t) => GUN[t].c === 0 || GUN[t].c === 8;
  /* can gun t take attachment ai? */
  function accepts(t, ai) {
    const G = GUN[t], A = ATT[ai];
    if (!G || !A || A.cl.indexOf(String(G.c)) < 0) return false;
    if (A.k === 0) return CLS[G.c].scap >= A.lv && !(G.isc >= A.lv && !A.cant);
    if (A.k === 2 && G.sup) return false;
    if (A.k === 4 && G.nostock) return false;
    if (G.c === 7 || G.c === 9) return false;
    return true;
  }
  function attScore(A) { return !A ? 0 : A.k === 0 ? A.lv + (A.cant ? -0.5 : 0) : A.k === 1 ? (A.mg ? 1 : 0) + (A.rl ? 0.9 : 0) : A.k === 2 ? (A.sup ? 3 : A.rc ? 2 : A.pel ? 2 : 1.5) : A.k === 3 ? (A.rc ? 2 : A.lt ? 0.5 : 1.5) : 1; }
  const attBetter = (w, ai) => accepts(w.t, ai) && attScore(ATT[ai]) > attScore(ATT[w.a[ATT[ai].k] - 1]) + 0.01;
  const HLIM = [15, 5, 2, 4, 6];           // how many heals bots / auto-pickup keep at most
  const capOf = (p) => BAGCAP[p.bp] + (p.vs ? VESTCAP : 0);
  function wtOf(p) {
    let w = 0;
    for (let j = 0; j < AMMO.length; j++) w += p.am[j] * AMMO[j].wt;
    for (let j = 0; j < HEAL.length; j++) w += p.hl[j] * HEAL[j].wt;
    for (let j = 0; j < THROW.length; j++) w += p.th[j] * THROW[j].wt;
    for (let j = 0; j < ATT.length; j++) if (p.at[j]) w += p.at[j] * ATT[j].wt;
    return w;
  }
  function itemWt(t) { const k = ikind(t); return k === 'o' ? AMMO[t - I_AMMO].wt : k === 'h' ? HEAL[t - I_HEAL].wt : k === 't' ? THROW[t - I_THR].wt : k === 'a' ? ATT[t - I_ATT].wt : 0; }
  const roomFor = (p, t) => { const w = itemWt(t); return w > 0 ? Math.max(0, Math.floor((capOf(p) - wtOf(p)) / w + 1e-6)) : 999; };
  const heldGun = (p) => (p.sl <= 2 ? p.g[p.sl] : null);
  function heldCode(p) {   // what is in the hands: gun id, melee id, throwable id, or -1 (fists)
    if (p.sl <= 2) return p.g[p.sl] ? p.g[p.sl].t : -1;
    if (p.sl === 3) return p.ml >= 0 ? I_MEL + p.ml : -1;
    return I_THR + p.ts;
  }
  function gunVal(p, w) { if (!w) return 0; const G = GUN[w.t]; return G.v + (p.am[G.am] + w.m > 0 ? 0.6 : -2.5); }
  function bestSlot(p) {
    let b = 3, bv = 0.5;
    for (const s of [0, 1, 2]) { const w = p.g[s]; if (!w) continue; const v = gunVal(p, w) - (s === 2 ? 3 : 0); if (v > bv) { bv = v; b = s; } }
    return b;
  }
  function dropItem(W, x, y, t, n, by) {
    const a = Math.random() * 6.283, d = 0.5 + Math.random() * 0.5;
    // guard: never let one spot pile up with copies of the same gun (keeps at most 3 within 2.5 m; the oldest goes)
    if (ikind(t) === 'g') { let c = 0, old = -1; for (let j = W.dr.length - 1; j >= 0; j--) { const l = W.dr[j]; if (l.t === t && Math.abs(l.x - x) < 2.5 && Math.abs(l.y - y) < 2.5) { c++; old = j; } } if (c >= 3) W.dr.splice(old, 1); }
    W.dr.push({ x: r1(x + Math.cos(a) * d), y: r1(y + Math.sin(a) * d), t, n, by, nt: W.T + 2.5 });
    if (W.dr.length > W.dcap) W.dr.shift();
    W.lv++;
  }
  /* attachments of a gun that leaves the hands go to the backpack (or onto the ground) */
  function stripGun(W, p, w) {
    for (let k = 0; k < 5; k++) if (w.a[k]) { const ai = w.a[k] - 1; w.a[k] = 0; if (roomFor(p, I_ATT + ai) > 0) p.at[ai]++; else dropItem(W, p.x, p.y, I_ATT + ai, 1, p.i); }
  }
  function dropGun(W, p, s) {
    const w = p.g[s]; if (!w) return;
    stripGun(W, p, w); p.g[s] = null; dropItem(W, p.x, p.y, w.t, w.m, p.i);
    if (p.sl === s) { p.sl = bestSlot(p); p.rl = 0; p.bq = 0; }
  }
  /* put attachment ai on a gun (slot s, or the best gun when s < 0); the old one goes to the bag */
  function mountAtt(W, p, ai, s, fromBag) {
    const A = ATT[ai]; if (!A) return false;
    const k = A.k;
    let w = null;
    if (s >= 0 && s <= 2) { w = p.g[s]; if (!w || !accepts(w.t, ai) || w.a[k] === ai + 1) return false; }
    else { for (const j of [p.sl, 0, 1, 2]) { const g = j <= 2 ? p.g[j] : null; if (g && attBetter(g, ai)) { w = g; break; } } if (!w) return false; }
    if (fromBag) { if (p.at[ai] <= 0) return false; p.at[ai]--; }
    const old = w.a[k]; w.a[k] = ai + 1;
    if (old) { const oi = old - 1; if (roomFor(p, I_ATT + oi) > 0) p.at[oi]++; else dropItem(W, p.x, p.y, I_ATT + oi, 1, p.i); }
    const mg = magW(w); if (w.m > mg) { p.am[GUN[w.t].am] += w.m - mg; w.m = mg; }
    return true;
  }
  function unmountAtt(W, p, s, k) {
    const w = p.g[s]; if (!w || !w.a[k]) return;
    const ai = w.a[k] - 1; w.a[k] = 0;
    if (roomFor(p, I_ATT + ai) > 0) p.at[ai]++; else dropItem(W, p.x, p.y, I_ATT + ai, 1, p.i);
    const mg = magW(w); if (w.m > mg) { p.am[GUN[w.t].am] += w.m - mg; w.m = mg; }
  }
  /* a newly taken gun grabs fitting attachments from the bag */
  function bagToGun(W, p, s) { for (let ai = ATT.length - 1; ai >= 0; ai--) if (p.at[ai] > 0 && p.g[s] && attBetter(p.g[s], ai)) mountAtt(W, p, ai, s, true); }
  const usesAmmo = (p, j) => p.g.some((w) => w && GUN[w.t].am === j);
  /* try to take an item: returns how many are left (0 = all taken), or -1 = gun slots full (swap needed).
     man = picked by hand (take whatever fits); otherwise only things that are clearly better (bots, auto-pickup) */
  function tryTake(W, p, t, n, man) {
    const k = ikind(t);
    if (k === 'g') {
      const G = GUN[t];
      const put = (s) => { p.g[s] = mkGun(t, Math.min(n, G.mg)); bagToGun(W, p, s); };
      if (pistolSlot(t)) { if (p.g[2]) return -1; put(2); if (p.sl === 3 && !p.g[0] && !p.g[1]) p.sl = 2; return 0; }
      for (const s of [0, 1]) if (!p.g[s]) { put(s); if (p.sl >= 2 && p.sl !== 4 && (p.sl === 3 || G.v > gunVal(p, p.g[2]))) { p.sl = s; p.rl = 0; p.cd = Math.max(p.cd, 0.3); } return 0; }
      return -1;
    }
    if (k === 'm') { const j = t - I_MEL, v = MELEE[j].v; if (p.ml === j || (!man && p.ml >= 0 && v <= MELEE[p.ml].v + 0.05)) return n; if (p.ml >= 0) dropItem(W, p.x, p.y, I_MEL + p.ml, 1, p.i); p.ml = j; return 0; }
    if (k === 'v' || k === 'e' || k === 'b') {
      const f = k === 'v' ? 'vs' : k === 'e' ? 'hm' : 'bp', base = k === 'v' ? I_VEST : k === 'e' ? I_HELM : I_BAG, lv = t - base + 1;
      if (lv === p[f] || (!man && lv < p[f])) return n;
      const old = p[f]; p[f] = lv;
      if (capOf(p) < wtOf(p) - 1e-6) { p[f] = old; return n; }     // a smaller bag would not hold what I carry
      if (old > 0) dropItem(W, p.x, p.y, base + old - 1, 1, p.i);
      return 0;
    }
    if (k === 's') { const j = t - I_SPC + 1; if (p.spc === j || (!man && p.spc)) return n; if (p.spc) dropItem(W, p.x, p.y, I_SPC + p.spc - 1, 1, p.i); p.spc = j; return 0; }
    if (k === 'a') {
      const ai = t - I_ATT;
      if (mountAtt(W, p, ai, -1, false)) return n - 1;
      if (!man && p.at[ai] > 0) return n;
      const take = Math.min(n, roomFor(p, t), man ? 99 : 1); if (take <= 0) return n;
      p.at[ai] += take; return n - take;
    }
    let lim = 9999;
    if (k === 'h') { const j = t - I_HEAL; if (!man) lim = HLIM[j] - p.hl[j]; }
    else if (k === 't') { const j = t - I_THR; if (!man) lim = 3 - p.th[j]; }
    else if (!man && !usesAmmo(p, t - I_AMMO)) lim = 0;
    const take = Math.min(n, roomFor(p, t), lim);
    if (take <= 0) return n;
    if (k === 'h') p.hl[t - I_HEAL] += take; else if (k === 't') p.th[t - I_THR] += take; else p.am[t - I_AMMO] += take;
    return n - take;
  }
  /* visit loot within R of (x,y): cb(l, kind, index, sub); return true from cb to stop */
  function eachLoot(W, x, y, R, cb) {
    const M = W.M;
    const ax = clamp(Math.floor((x - R + HL) / CS), 0, CN - 1), bx = clamp(Math.floor((x + R + HL) / CS), 0, CN - 1);
    const ay = clamp(Math.floor((y - R + HL) / CS), 0, CN - 1), by = clamp(Math.floor((y + R + HL) / CS), 0, CN - 1);
    for (let cy = ay; cy <= by; cy++) for (let cx = ax; cx <= bx; cx++) for (const j of M.cl[cy * CN + cx]) { const l = M.loot[j]; if (W.tk[j] || Math.abs(l.x - x) > R || Math.abs(l.y - y) > R) continue; if (hyp(l.x - x, l.y - y) <= R && cb(l, 0, j, 0)) return; }
    for (let j = W.dr.length - 1; j >= 0; j--) { const l = W.dr[j]; if (hyp(l.x - x, l.y - y) <= R && cb(l, 1, j, 0)) return; }
    for (let j = W.bx.length - 1; j >= 0; j--) { const b = W.bx[j]; if (hyp(b.x - x, b.y - y) > R + 0.3) continue; for (let k = b.it.length - 1; k >= 0; k--) if (cb({ x: b.x, y: b.y, t: b.it[k][0], n: b.it[k][1] }, 2, j, k)) return; }
  }
  function setLoot(W, kind, j, k, left) {
    W.lv++;
    if (kind === 0) { W.tk[j] = 1; if (left > 0) { const l = W.M.loot[j]; W.dr.push({ x: l.x, y: l.y, t: l.t, n: left, by: -1, nt: 0 }); if (W.dr.length > W.dcap) W.dr.shift(); } }
    else if (kind === 1) { if (left > 0) W.dr[j].n = left; else W.dr.splice(j, 1); }
    else { const b = W.bx[j]; if (left > 0) b.it[k][1] = left; else { b.it.splice(k, 1); if (!b.it.length) W.bx.splice(j, 1); } }
  }
  /* automatic pickup (bots always; people only with the 「자동 줍기」 option): better things only */
  function pickups(W, p, hooks) {
    let done = false;
    for (let guard = 0; guard < 6 && !done; guard++) {
      done = true;
      eachLoot(W, p.x, p.y, 1.3, (l, kind, j, k) => {
        if (kind === 1 && l.by === p.i && W.T < l.nt) return false;
        const left = tryTake(W, p, l.t, l.n, 0);
        // a gun counts as taken when tryTake says 0 left, even an empty one (n 0): comparing left with n left it lying there → copies
        if (left < 0 || (ikind(l.t) === 'g' ? left !== 0 : left === l.n)) return false;
        const t = l.t, x = l.x, y = l.y;
        setLoot(W, kind, j, k, left);
        emit(W, hooks, 4, x, y, p.i, t);
        done = false; return true;    // lists changed: rescan
      });
    }
  }
  const PICK_R = 2.4;
  /* take one specific thing by hand (from the nearby list or an opened box): type t at about (x, y) */
  function pickOne(W, p, t, x, y, hooks, lim) {
    if (p.out || p.kd || p.veh >= 0 || p.air > 0 || !(t >= 0 && t < NITEM) || !fin(x) || !fin(y)) return;
    let hit = null;
    eachLoot(W, p.x, p.y, PICK_R, (l, kind, j, k) => {
      if (l.t !== t || Math.abs(l.x - x) > 0.35 || Math.abs(l.y - y) > 0.35) return false;
      hit = { kind, j, k, n: l.n, x: l.x, y: l.y }; return true;
    });
    if (!hit) return;
    // lim: take at most this many of a stack (the rest stays where it was)
    const want = lim > 0 && lim < hit.n && ikind(t) !== 'g' ? lim : hit.n;
    let left = tryTake(W, p, t, want, 1), sw = -1;
    if (left < 0) {   // gun slots full: swap with the gun in the hands (or the weaker one)
      sw = pistolSlot(t) ? 2 : p.sl <= 1 ? p.sl : gunVal(p, p.g[0]) <= gunVal(p, p.g[1]) ? 0 : 1;
      dropGun(W, p, sw);
      left = tryTake(W, p, t, hit.n, 1);
      if (left < 0) return;
      if (p.g[sw] && p.g[sw].t === t) { p.sl = sw; p.rl = 0; p.bq = 0; p.cd = Math.max(p.cd, 0.3); }
    }
    if (ikind(t) === 'g' ? left !== 0 : left === want) { emit(W, hooks, 11, p.x, p.y, p.i, 21); return; }   // no room (an empty gun has n 0: judge guns by 'taken', not by count)
    left += hit.n - want;
    // the swap dropped a gun into W.dr: indices of dropped items moved, so find the item again
    if (sw >= 0 && hit.kind === 1) { const j = W.dr.findIndex((l) => l.t === t && l.x === hit.x && l.y === hit.y); if (j < 0) return; hit.j = j; }
    setLoot(W, hit.kind, hit.j, hit.k, left);
    emit(W, hooks, 4, hit.x, hit.y, p.i, t);
  }
  /* best gun on the ground the interact button would swap in (bots) */
  function swapCand(W, p) {
    let best = null, bv = -1e9;
    eachLoot(W, p.x, p.y, 1.3, (l) => {
      if (ikind(l.t) !== 'g') return false;
      const G = GUN[l.t];
      if (pistolSlot(l.t) ? !p.g[2] : !p.g[0] || !p.g[1]) return false;
      if (G.v > bv) { bv = G.v; best = { t: l.t, n: l.n, x: l.x, y: l.y }; }
      return false;
    });
    return best;
  }
  /* drop things from the bag / equipment by hand: t item id (n = how many, 0 = all) */
  function dropOwn(W, p, t, n) {
    if (p.out || p.air > 0 || !(t >= 0 && t < NITEM)) return;
    const k = ikind(t);
    if (k === 'g') return;
    if (k === 'm') { if (p.ml === t - I_MEL) { dropItem(W, p.x, p.y, t, 1, p.i); p.ml = -1; if (p.sl === 3) p.sl = bestSlot(p); } return; }
    if (k === 's') { if (p.spc === t - I_SPC + 1) { dropItem(W, p.x, p.y, t, 1, p.i); p.spc = 0; } return; }
    if (k === 'v' || k === 'e' || k === 'b') {
      const f = k === 'v' ? 'vs' : k === 'e' ? 'hm' : 'bp', base = k === 'v' ? I_VEST : k === 'e' ? I_HELM : I_BAG;
      if (p[f] !== t - base + 1) return;
      const old = p[f]; p[f] = 0;
      if (capOf(p) < wtOf(p) - 1e-6) { p[f] = old; return; }
      dropItem(W, p.x, p.y, t, 1, p.i); return;
    }
    const arr = k === 'h' ? p.hl : k === 't' ? p.th : k === 'a' ? p.at : p.am, j = t - (k === 'h' ? I_HEAL : k === 't' ? I_THR : k === 'a' ? I_ATT : I_AMMO);
    const have = arr[j] | 0, m = n > 0 ? Math.min(n, have) : have;
    if (m <= 0) return;
    if (k === 'h' && p.ut === j && p.use > 0) { p.use = 0; p.ut = -1; }
    arr[j] = have - m;
    dropItem(W, p.x, p.y, t, m, p.i);
    if (k === 't' && p.sl === 4 && p.th[p.ts] <= 0) { const q = p.th.findIndex((c) => c > 0); if (q >= 0) p.ts = q; else p.sl = bestSlot(p); }
  }
  function deathBox(W, q) {
    const it = [];
    for (const w of q.g) if (w) { it.push([w.t, w.m]); for (let k = 0; k < 5; k++) if (w.a[k]) it.push([I_ATT + w.a[k] - 1, 1]); }
    if (q.spc) it.push([I_SPC + q.spc - 1, 1]);
    if (q.ml >= 0) it.push([I_MEL + q.ml, 1]);
    q.th.forEach((n, j) => { if (n > 0) it.push([I_THR + j, n]); });
    q.hl.forEach((n, j) => { if (n > 0) it.push([I_HEAL + j, n]); });
    q.am.forEach((n, j) => { if (n > 0) it.push([I_AMMO + j, n]); });
    q.at.forEach((n, j) => { if (n > 0) it.push([I_ATT + j, n]); });
    if (q.vs) it.push([I_VEST + q.vs - 1, 1]); if (q.hm) it.push([I_HELM + q.hm - 1, 1]); if (q.bp) it.push([I_BAG + q.bp - 1, 1]);
    q.g = [null, null, null]; q.ml = -1; q.th = THROW.map(() => 0); q.hl = HEAL.map(() => 0); q.am = AMMO.map(() => 0); q.at = ATT.map(() => 0);
    q.vs = q.hm = q.bp = q.spc = 0;
    if (!it.length) return;
    const s = isWater(W.M, q.x, q.y) ? snapFree(W.M, q.x, q.y) : [q.x, q.y];
    W.bx.push({ x: r1(s[0]), y: r1(s[1]), it: it.slice(0, 16) }); if (W.bx.length > W.bcap) W.bx.shift();
    W.lv++;
  }

  /* ----- damage ----- */
  function hurt(W, q, dmg, by, how, head, hooks, quiet) {
    if (q.out || q.air > 0 || !(dmg > 0) || !fin(dmg)) return 0;
    if (by >= 0 && W.pl[by] && W.pl[by].tm === q.tm && by !== q.i) return 0;
    let d = dmg;
    if (how !== -2 && how !== -6 && how !== -7 && how !== -9 && how !== -10 && !q.kd) d *= head ? 1 - HRED[q.hm] : 1 - VRED[q.vs];
    if (by >= 0 && by !== q.i) { q.lb = by; q.lbT = W.T; q.lw = how; if (W.pl[by]) W.pl[by].dd += Math.min(d, q.kd ? q.khp : q.hp); }
    const wasKd = q.kd;
    if (q.ut === 10 && d >= 1) { q.use = 0; q.ut = -1; emit(W, hooks, 40, q.x, q.y, q.i, 5); }
    if (q.kd) { q.khp -= d; if (q.khp <= 0.05) die(W, q, by, how, hooks); }
    else { q.hp -= d; if (q.hp <= 0.05) down(W, q, by, how, hooks); }
    if (!quiet) emit(W, hooks, 1, q.x, q.y, q.i, (by + 1) * 1024 + Math.min(255, Math.round(d)) * 4 + (head ? 1 : 0) + (q.out || (q.kd && !wasKd) ? 2 : 0));
    return d;
  }
  function down(W, q, by, how, hooks) {
    const mates = W.tm && W.pl.some((o) => o !== q && o.tm === q.tm && !o.out && !o.kd);
    if (!mates) { die(W, q, by, how, hooks); return; }
    if (!W.pl.some((o) => !o.out && o.tm !== q.tm)) { q.hp = 1; return; }
    if (q.veh >= 0) exitVeh(W, q);
    q.kd = 1; q.kn++; q.khp = 100; q.hp = 0; q.use = 0; q.ut = -1; q.rl = 0; q.ads = 0; q.bq = 0; q.vx *= 0.3; q.vy *= 0.3;
    if (q.rv >= 0) { const t = W.pl[q.rv]; if (t) t.rvb = 0; q.rv = -1; }
    emit(W, hooks, 2, q.x, q.y, q.i, by + 1);
  }
  function die(W, q, by, how, hooks) {
    if (q.out) return;
    if (!W.pl.some((o) => !o.out && o.tm !== q.tm)) { if (q.kd) q.khp = 1; else q.hp = 1; return; }
    let killer = by;
    if ((killer < 0 || killer === q.i) && q.lb >= 0 && W.T - q.lbT < 15 && W.pl[q.lb] && !W.pl[q.lb].out) { killer = q.lb; if (how === -2 || how === -5) how = q.lw; }
    const aliveTeams = teamsAlive(W);
    if (q.veh >= 0) exitVeh(W, q);
    q.out = 1; q.kd = 0; q.hp = 0; q.khp = 0; q.use = 0; q.vx = 0; q.vy = 0; q.ads = 0; q.rl = 0; q.cr = 0; q.sx = 0; q.dt = W.T;
    if (killer >= 0 && killer !== q.i && W.pl[killer] && W.pl[killer].tm !== q.tm) W.pl[killer].kills++;
    for (const o of W.pl) if (o.rv === q.i) { o.rv = -1; o.use = 0; o.ut = -1; }
    if (q.rv >= 0) { const t = W.pl[q.rv]; if (t) t.rvb = 0; q.rv = -1; }
    deathBox(W, q);
    emit(W, hooks, 3, q.x, q.y, q.i, (killer + 1) * 512 + clamp(how + 12, 0, 511));
    if (!W.pl.some((o) => o.tm === q.tm && !o.out && !o.kd)) for (const o of W.pl) if (o.tm === q.tm && !o.out && o.kd) die(W, o, o.lb, -5, hooks);
    if (!W.pl.some((o) => !o.out && o.tm === q.tm) && W.tp[q.tm] == null) { W.tp[q.tm] = aliveTeams; for (const o of W.pl) if (o.tm === q.tm) o.place = aliveTeams; }
    if (W.dg) {   // 인식표: the carrier drops them; my own lies here for a while
      for (const g of W.dg) if (g.by === q.i) { g.by = -1; g.x = r1(q.x); g.y = r1(q.y); g.t = Math.max(g.t, 30); }
      if (rcOn(W) && W.pl.some((o) => o.tm === q.tm && !o.out)) W.dg.push({ i: q.i, x: r1(q.x), y: r1(q.y), t: RC.tag, by: -1 });
      W.dg = W.dg.filter((g) => W.pl.some((o) => o.tm === W.pl[g.i].tm && !o.out));
    }
    if (teamsAlive(W) <= 1) finish(W, hooks);
  }
  function finish(W, hooks) {
    if (W.res) return;
    for (const p of W.pl) { if (!p.out && W.tp[p.tm] == null) W.tp[p.tm] = 1; if (!p.out) p.dt = W.T; }
    const al = Object.keys(W.tp).filter((t) => W.tp[t] === 1);
    if (al.length > 1) {
      const sc = al.map((t) => [t, W.pl.filter((p) => p.tm === +t && !p.out).reduce((s, p) => s + p.kills * 1000 + (p.kd ? 0 : p.hp), 0)]).sort((a, b) => b[1] - a[1]);
      sc.forEach((s, k) => { W.tp[s[0]] = k + 1; });
    }
    W.res = W.pl.map((p) => [p.i, W.tp[p.tm] || W.pl.length, p.kills]).sort((a, b) => a[1] - b[1] || b[2] - a[2] || a[0] - b[0]);
    W.ph = 3;
    emit(W, hooks, 22, 0, 0, W.res[0][0], 0);
  }
  function explode(W, x, y, R, dmg, o, how, hooks, kind) {
    emit(W, hooks, 7, x, y, Math.round(R * 10), kind);
    for (const q of W.pl) {
      if (q.out || q.air > 0) continue;
      const d = hyp(q.x - x, q.y - y);
      if (d > R + PR) continue;
      if (q.veh < 0 && !los(W.M, x, y, q.x, q.y)) continue;
      if (kind === 2 && q.veh < 0 && inBld(W.M, q.x, q.y) >= 0) continue;     // red-zone bombs: a roof keeps you safe
      const k = Math.max(0, 1 - d / (R + PR)), arm = q.veh >= 0 && VEH[W.vh[q.veh].ty].arm;
      hurt(W, q, dmg * k * (q.veh >= 0 ? (arm ? 0.15 : 0.7) : 1), o, how, false, hooks);
      if (!q.out && q.veh < 0 && d > 1e-3) { q.vx += (q.x - x) / d * 6 * k; q.vy += (q.y - y) / d * 6 * k; }
    }
    W.vh.forEach((v, j) => { if (v.hp > 0 && hyp(v.x - x, v.y - y) < R + VEH[v.ty].r) vehDmg(W, j, dmg * (VEH[v.ty].arm ? 0.35 : 0.8) * Math.max(0.2, 1 - hyp(v.x - x, v.y - y) / R), o, hooks); });
    if (W.an) W.an.forEach((a, j) => { const d = hyp(a.x - x, a.y - y); if (a.hp > 0 && d < R + ANI[a.k].r) anHurt(W, j, dmg * Math.max(0.2, 1 - d / (R + 1)), o, hooks); });
    if (W.tg) W.tg.forEach((g, j) => { const d = hyp(g.x - x, g.y - y); if (g.hp > 0 && d < R + 0.5) tgHit(W, j, dmg * Math.max(0.2, 1 - d / (R + 1)), false, W.pl[o], hooks); });
  }

  /* ----- vehicles ----- */
  function riders(W, j) { const out = []; for (const p of W.pl) if (!p.out && p.veh === j) out.push(p); return out; }
  function freeSeat(W, j) {
    const v = W.vh[j], used = {};
    for (const p of W.pl) if (!p.out && p.veh === j) used[p.seat] = 1;
    for (let s = 0; s < VEH[v.ty].seats; s++) if (!used[s]) return s;
    return -1;
  }
  function vehDmg(W, j, d, by, hooks) {
    const v = W.vh[j]; if (v.hp <= 0 || !(d > 0)) return;
    v.hp -= d; v.mt = W.T; if (by >= 0) v.lb = by;
    if (v.hp <= 0) {
      v.hp = 0; v.v = 0; v.sl = 0; v.vx = 0; v.vy = 0; v.w = 0;
      const rs = riders(W, j);
      for (const p of rs) exitVeh(W, p);
      explode(W, v.x, v.y, VEH[v.ty].ped ? 2 : 5, VEH[v.ty].ped ? 20 : 110, v.lb, -4, hooks, 1);
    }
  }
  /* the driver can only use one-handed guns (pistols, small SMGs) */
  function driverGun(p) { const w = heldGun(p); if ((!w || !OH(w.t)) && p.g[2]) p.sl = 2; p.ads = 0; p.bq = 0; p.rl = 0; }
  function enterVeh(W, p, j, hooks) {
    const v = W.vh[j]; if (!v || v.hp <= 0) return;
    if (hyp(v.x - p.x, v.y - p.y) > VEH[v.ty].r + 2.2) return;
    for (const q of W.pl) if (!q.out && q.veh === j && q.tm !== p.tm) return;
    const s = freeSeat(W, j); if (s < 0) return;
    p.veh = j; p.seat = s; p.use = 0; p.ut = -1; p.rl = 0; p.ads = 0; p.bq = 0; p.rv = -1; p.vx = 0; p.vy = 0; p.cr = 0; p.sx = 0;
    if (s === 0) { v.dr = p.i; driverGun(p); }
    emit(W, hooks, 17, v.x, v.y, p.i, j + 1);
  }
  function swapSeat(W, p) {
    if (p.veh < 0) return;
    const v = W.vh[p.veh], V = VEH[v.ty]; if (V.seats < 2) return;
    const used = {}; for (const q of W.pl) if (!q.out && q.veh === p.veh && q !== p) used[q.seat] = 1;
    for (let k = 1; k < V.seats; k++) { const s = (p.seat + k) % V.seats; if (!used[s]) { p.seat = s; p.ads = 0; p.rl = 0; p.bq = 0; if (s === 0) { v.dr = p.i; driverGun(p); } return; } }
  }
  function exitVeh(W, p, hooks) {
    const j = p.veh; if (j < 0) return;
    const v = W.vh[j], V = VEH[v.ty], M = W.M;
    p.veh = -1;
    const ca = Math.cos(v.a), sa = Math.sin(v.a), off = V.r + PR + 0.4;
    let spot = null;
    for (const [ox, oy] of [[-sa, ca], [sa, -ca], [-ca, -sa], [ca, sa]]) {
      const x = v.x + ox * off, y = v.y + oy * off;
      if (Math.abs(x) < HL - 3 && Math.abs(y) < HL - 3 && !solidAt(M, x, y, PR + 0.1) && (V.land ? landAt(M, x, y, 0.2) : true)) { spot = [x, y]; break; }
    }
    if (!spot) spot = snapFree(M, v.x, v.y, !V.land);
    p.x = spot[0]; p.y = spot[1]; p.vx = v.vx * 0.2; p.vy = v.vy * 0.2; p.sx = 0;
    if (hooks) emit(W, hooks, 17, v.x, v.y, p.i, 0);
  }
  function stepVehicles(W, h, inputs, hooks) {
    const M = W.M;
    W.vh.forEach((v, j) => {
      if (v.hp <= 0) return;
      const V = VEH[v.ty];
      let dp = null;
      for (const p of W.pl) if (!p.out && p.veh === j && p.seat === 0) dp = p;
      const I = dp ? inputs[dp.i] || NOIN : NOIN;
      /* driving (redone): the stick points where I want to go. Ahead or to the side = drive and steer that way; pulled back
         against the car = brake, then back up while the nose swings round to that side (a 3-point turn) and drive off. Steering needs speed (no spinning on the
         spot), is quickest at town speed and calmer flat out; the yaw eases in and out, so the car never snaps round.
         (was: steer rate capped but fixed up to top speed, a stick pulled back at speed made a U-turn instead of braking,
         and a hard wall hit gave the car a random spin) */
      let ax = I.ax || 0, ay = I.ay || 0; const m = Math.min(1, hyp(ax, ay));
      let tv = 0, wT = 0, brk = 0;
      const ice = V.land === 1 && onIce(M, v.x, v.y), sp0 = Math.abs(v.v);
      const hb = !!(dp && I.sp && !V.ped && sp0 > 6); // sprint button = handbrake drift (bicycle: pedal hard)
      const sf = clamp(sp0 / 3.5, 0, 1) * (sp0 > V.vmax * 0.45 ? 1 - 0.4 * clamp((sp0 - V.vmax * 0.45) / (V.vmax * 0.55), 0, 1) : 1);
      const rate = V.turn * (ice ? 0.6 : 1) * Math.max(0.22, sf) * (hb ? 1.45 : 1);
      if (dp && m > 0.2) {
        const want = Math.atan2(ay, ax); let diff = wrapA(want - v.a);
        if (Math.abs(diff) > 2.8 && v.tsd) diff = v.tsd * Math.abs(diff); v.tsd = diff < 0 ? -1 : 1;   // stick straight back: keep turning the same way (no flip-flop at ±180°)
        if (v.rvs && (Math.abs(diff) < 1.2 || v.v > 1)) v.rvs = 0;
        if (!v.rvs && Math.abs(diff) > 2.2) { if (v.v > 1.2) brk = 1; else v.rvs = 1; }
        if (brk) wT = 0;
        else if (v.rvs) { wT = clamp(diff * 3, -rate, rate); tv = -V.vmax * 0.38 * m; }   // backing up swings the nose round toward the stick (a 3-point turn), then it drives off forward
        else { wT = clamp(diff * 3, -rate, rate); tv = V.vmax * m * (1 - 0.45 * clamp(Math.abs(diff) / 1.6, 0, 1)) * (hb ? 0.55 : 1); }
      } else v.rvs = 0;
      v.w = (v.w || 0) + (wT - (v.w || 0)) * Math.min(1, h * (V.land === 0 ? 4 : 7));
      // grip: the velocity mostly turns with the car (a little lag = a mild slide); handbrake / ice / water let it slide more
      { const da = v.w * h, cd = Math.cos(da), sd = Math.sin(da), f0 = v.v, l0 = v.sl || 0;
        v.a = wrapA(v.a + da); v.v = f0 * cd + l0 * sd; v.sl = -f0 * sd + l0 * cd; }
      // bicycle: legs are the engine — pedalling uses stamina, hard pedalling (sprint) is faster
      if (V.ped && dp) {
        const run = !!I.sp && dp.stm > 0 && !dp.ex;
        tv *= dp.ex || dp.stm <= 0 ? 0.55 : run ? 1.5 : 1;
        if (Math.abs(tv) > 0.5) { dp.stm -= h * (run ? STM.pedalRun : STM.pedal) * (dp.sb > 0 ? 0.5 : 1); dp.sr = STM.delay; if (dp.stm <= 0) { dp.stm = 0; dp.ex = 1; } }
        dp.sx = run && Math.abs(tv) > 0.5 ? 1 : 0;
      }
      // ground: mud slows (not the air boat), snow vehicles shine on snow, sand buggies on sand
      if (tv) {
        const T = M.T;
        if (V.land === 1 && M.mud.length && inMud(M, v.x, v.y)) tv *= 0.55;
        if (V.land === 2 && !isWater(M, v.x, v.y)) tv *= 0.5;
        if (T.snow && V.land === 1 && !V.snow) tv *= 0.85;
        if (T.k === 'd' && V.sand) tv *= 1.1;
      }
      // engine: strong from a standstill, fading toward top speed; brakes are much stronger than the engine; coasting rolls out
      let acc;
      if (brk) acc = V.acc * 2.6;
      else if (tv === 0) acc = hb ? 10 : 4.5;
      else if (Math.sign(tv) !== Math.sign(v.v) && Math.abs(v.v) > 0.5) acc = V.acc * 2.2;
      else acc = V.acc * (1.25 - 0.6 * clamp(Math.abs(v.v) / V.vmax, 0, 1));
      v.v += clamp((brk ? 0 : tv) - v.v, -acc * h, acc * h);
      const grip = (V.land === 0 ? 2.6 : V.land === 2 ? 2.4 : V.sh === 'bike' || V.sh === 'sled' ? 11 : 8.5) * (ice ? 0.3 : 1) * (hb ? 0.22 : 1);
      v.sl = (v.sl || 0) * Math.exp(-grip * h);
      { const cap = Math.abs(v.v) * 0.7 + 1.5; if (Math.abs(v.sl) > cap) v.sl = Math.sign(v.sl) * cap; }   // never more sideways than a slide: no spin-outs
      if (Math.abs(v.sl) > 1.5) v.v -= Math.sign(v.v) * Math.min(Math.abs(v.v), Math.abs(v.sl) * 0.3 * h); // sliding scrubs speed
      const ca = Math.cos(v.a), sa = Math.sin(v.a), wx = ca * v.v - sa * v.sl, wy = sa * v.v + ca * v.sl;
      const o = { x: v.x + wx * h, y: v.y + wy * h, vx: wx, vy: wy, hit: 0 };
      // terrain: land vehicles stop at the shore, boats at the beach; the air boat goes on both (slowly on land)
      const wet = isWater(M, o.x + ca * V.r * Math.sign(v.v || 1), o.y + sa * V.r * Math.sign(v.v || 1));
      if (V.land === 1 ? wet : V.land === 0 ? !wet : false) { v.v *= -0.15; v.sl = 0; v.vx = 0; v.vy = 0; return; }
      if (V.land === 1 && M.lava.length && inLava(M, v.x, v.y)) vehDmg(W, j, 20 * h, v.lb, hooks);
      collide(M, o, V.r);
      if (o.hit > 4) { vehDmg(W, j, (o.hit - 4) * 5, v.lb, hooks); if (o.hit > 7) emit(W, hooks, 18, o.x, o.y, j, Math.round(o.hit)); }
      if (v.hp <= 0) return;
      // walls: the head-on part is lost, the glancing part slides along the wall (a scrape, not a dead stop)
      if (o.hit) {
        // walls & trees: the head-on part is lost, the rest slides along; the nose turns gently to follow the wall, so a
        // glancing hit scrapes along instead of sticking (was: random spin on hard hits and the slide became sideways slip that grip killed)
        // (friction ∝ how hard it pressed into the wall this step — was a flat ×0.85 every step, which glued a car to a wall)
        const s0 = hyp(o.vx, o.vy), k = s0 > 1e-3 ? Math.max(0, s0 - 0.35 * o.hit) / s0 * (1 - 0.6 * h) : 0, fw = (o.vx * ca + o.vy * sa) * k, sw = (-o.vx * sa + o.vy * ca) * k, sp = hyp(fw, sw);
        v.v = fw; v.sl = sw;
        if (sp > 1 && Math.abs(fw) > 0.3) { const ta = Math.atan2(o.vy, o.vx) + (fw < 0 ? Math.PI : 0), da = clamp(wrapA(ta - v.a), -2.5 * h, 2.5 * h); v.a = wrapA(v.a + da); const c2 = Math.cos(-da), s2 = Math.sin(-da), f1 = v.v * c2 - v.sl * s2; v.sl = v.v * s2 + v.sl * c2; v.v = f1; }
        v.w *= 0.5;
      }
      if (Math.abs(v.v) > 0.05 || o.x !== v.x || o.y !== v.y) v.mt = W.T;
      v.x = o.x; v.y = o.y; v.vx = ca * v.v - sa * v.sl; v.vy = sa * v.v + ca * v.sl;
      // badly damaged: catches fire and blows up a few seconds later
      if (v.hp < V.hp * 0.15) { if (!v.fire) { v.fire = 1; emit(W, hooks, 17, v.x, v.y, -1, 99); } vehDmg(W, j, V.hp * 0.04 * h + 1.5 * h, v.lb, hooks); if (v.hp <= 0) return; }
      // vehicles push each other
      W.vh.forEach((u, k) => {
        if (k <= j || u.hp <= 0) return;
        const R = V.r + VEH[u.ty].r, dx = u.x - v.x, dy = u.y - v.y, d = hyp(dx, dy);
        if (d >= R || d < 1e-3) return;
        u.mt = v.mt = W.T;
        const push = (R - d) / 2; u.x += dx / d * push; u.y += dy / d * push; v.x -= dx / d * push; v.y -= dy / d * push;
        const rel = hyp((v.vx || 0) - (u.vx || 0), (v.vy || 0) - (u.vy || 0)); v.v *= 0.5; u.v *= 0.5; v.sl = (v.sl || 0) * 0.5; u.sl = (u.sl || 0) * 0.5; v.vx = (v.vx || 0) * 0.5; v.vy = (v.vy || 0) * 0.5; u.vx = (u.vx || 0) * 0.5; u.vy = (u.vy || 0) * 0.5;
        if (rel > 6) { vehDmg(W, j, rel * 2, u.lb, hooks); vehDmg(W, k, rel * 2, v.lb, hooks); }
      });
      // running people over
      if (Math.abs(v.v) > 4 && dp) for (const q of W.pl) {
        if (q.out || q.veh >= 0 || q.air > 0 || q.tm === dp.tm) continue;
        const d = hyp(q.x - v.x, q.y - v.y);
        if (d > V.r + PR) continue;
        hurt(W, q, Math.abs(v.v) * 4.5 * (V.ped ? 0.3 : 1), dp.i, -3, false, hooks);
        if (!q.out && d > 1e-3) { q.vx += (q.x - v.x) / d * 9; q.vy += (q.y - v.y) / d * 9; }
        v.v *= 0.7;
      }
    });
  }

  /* ----- doors & windows ----- */
  const DOOR_R = 1.7, WIN_R = 1.15, BOX_R = 2.2, LOCK_T = 8, LOCK_CD = 25, VAULT_T = 0.5;
  function setDoor(W, d, on, hooks) { if (!!W.ds[d] === !!on) return; W.ds[d] = on ? 1 : 0; W.dv++; const D = W.M.doors[d]; emit(W, hooks || W.hk, 23, D.x, D.y, d, on ? 1 : 0); }
  function doorBlocked(W, d) { const D = W.M.doors[d]; for (const q of W.pl) if (!q.out && q.veh < 0 && q.air <= 0 && hyp(q.x - D.x, q.y - D.y) < D.hw + 0.35 && Math.abs((q.x - D.x) * D.nx + (q.y - D.y) * D.ny) < 0.85) return true; return false; }
  function nearDoor(W, p, R) {
    let bj = -1, bd = R;
    const c = cellOf(p.x, p.y); if (c < 0) return -1; if (!W.M.cr[c]) return -1;
    for (const j of W.M.cr[c]) { const q = W.M.rects[j]; if (q.d == null) continue; const D = W.M.doors[q.d], d = hyp(D.x - p.x, D.y - p.y); if (d < bd) { bd = d; bj = q.d; } }
    if (bj < 0) W.M.doors.forEach((D, j) => { const d = hyp(D.x - p.x, D.y - p.y); if (d < bd) { bd = d; bj = j; } });
    return bj;
  }
  /* (was: only the rects of the cell I stand in — a window whose frame lies in the next grid cell (10 m cells) could never
     be vaulted from one side; now every cell the reach circle touches) */
  function nearWin(W, p, R) {
    let bj = -1, bd = R; const M = W.M;
    nearSolids(M, p.x - R, p.y - R, p.x + R, p.y + R, (q) => { if (q.w == null) return false; const D = M.wins[q.w], d = hyp(D.x - p.x, D.y - p.y); if (d < bd) { bd = d; bj = q.w; } return false; }, null, 0);
    return bj;
  }
  function toggleDoor(W, p, d, hooks) {
    const D = W.M.doors[d]; if (!D || hyp(D.x - p.x, D.y - p.y) > DOOR_R + 0.4) return;
    if (W.ds[d]) { if (doorBlocked(W, d)) { emit(W, hooks, 11, p.x, p.y, p.i, 22); return; } setDoor(W, d, 0, hooks); }
    else { if (W.dl[d] > 0) { emit(W, hooks, 11, p.x, p.y, p.i, 23); return; } setDoor(W, d, 1, hooks); }
  }
  /* lock a door shut for a few seconds — only from inside its building */
  const canLock = (W, p, d) => { const D = W.M.doors[d]; return !!D && !(p.lk > 0) && !(W.dl[d] > 0) && inBld(W.M, p.x, p.y) === D.b && hyp(D.x - p.x, D.y - p.y) < DOOR_R + 0.4; };
  function lockDoor(W, p, d, hooks) {
    if (!canLock(W, p, d)) return;
    if (W.ds[d]) { if (doorBlocked(W, d)) { emit(W, hooks, 11, p.x, p.y, p.i, 22); return; } setDoor(W, d, 0, hooks); }
    W.dl[d] = LOCK_T; p.lk = LOCK_CD; W.dv++;
    const D = W.M.doors[d]; emit(W, hooks, 23, D.x, D.y, d, 2);
  }
  function startVault(W, p, wi, hooks) {
    const D = W.M.wins[wi]; if (!D || p.kd || p.veh >= 0 || p.vt > 0 || p.swim || hyp(D.x - p.x, D.y - p.y) > WIN_R + 0.4) return;
    const sd = (p.x - D.x) * D.nx + (p.y - D.y) * D.ny >= 0 ? 1 : -1, tx = D.x - D.nx * sd * 1.0, ty = D.y - D.ny * sd * 1.0;
    if (solidAt(W.M, tx, ty, PR * 0.9)) return;
    p.vt = VAULT_T; p.vw = [p.x, p.y, tx, ty]; p.use = 0; p.ut = -1; p.rl = 0; p.ads = 0; p.cr = 0; p.bq = 0; p.sx = 0;
    p.a = Math.atan2(ty - p.y, tx - p.x);
    emit(W, hooks, 24, D.x, D.y, p.i, 0);
  }
  function nearBox(W, p) { let bj = -1, bd = BOX_R; W.bx.forEach((b, j) => { const d = hyp(b.x - p.x, b.y - p.y); if (d < bd) { bd = d; bj = j; } }); return bj; }

  /* ----- context action (interact button) — shared by host and guests ----- */
  function ctxOf(W, p) {
    if (!p || p.out || p.kd || p.air > 0 || W.ph !== 2 || p.vt > 0) return null;
    if (p.veh >= 0) return { k: 'x', j: p.veh };
    if (W.tm) for (const q of W.pl) if (q !== p && q.tm === p.tm && q.kd && !q.out && hyp(q.x - p.x, q.y - p.y) < 1.9) return { k: 'r', i: q.i };
    if (W.tm && tagOf(W, p.i)) { const tj = nearTower(W, p.x, p.y, RC.r); if (tj >= 0) return { k: 't', j: tj }; }
    const d = nearDoor(W, p, DOOR_R), wi = nearWin(W, p, WIN_R);
    const dd = d >= 0 ? hyp(W.M.doors[d].x - p.x, W.M.doors[d].y - p.y) : 99, wd = wi >= 0 ? hyp(W.M.wins[wi].x - p.x, W.M.wins[wi].y - p.y) : 99;
    if (d >= 0 && dd <= wd) return { k: 'd', j: d, open: !!W.ds[d], lock: W.dl[d] > 0 };
    if (wi >= 0) return { k: 'w', j: wi };
    const b = nearBox(W, p);
    if (b >= 0) return { k: 'b', j: b };
    let bj = -1, bd = 1e9;
    W.vh.forEach((v, j) => {
      if (v.hp <= 0) return;
      const dv = hyp(v.x - p.x, v.y - p.y);
      if (dv > VEH[v.ty].r + 1.7 || dv >= bd || freeSeat(W, j) < 0) return;
      for (const q of W.pl) if (!q.out && q.veh === j && q.tm !== p.tm) return;
      bd = dv; bj = j;
    });
    if (bj >= 0) return { k: 'v', j: bj };
    return null;
  }
  /* k: 0 = whatever ctxOf says, 1 exit, 2 revive i, 3 door j, 5 vault window j, 6 enter vehicle j, 7 recall at tower j */
  function interact(W, p, hooks, k, j) {
    if (p.out || p.kd || p.air > 0 || p.vt > 0) return;
    if (!k) {
      const c = ctxOf(W, p); if (!c) return;
      k = { x: 1, r: 2, d: 3, w: 5, v: 6, t: 7 }[c.k] || 0; j = c.k === 'r' ? c.i : c.j;
      if (!k) return;
    }
    if (k === 1) { if (p.veh >= 0) exitVeh(W, p, hooks); return; }
    if (p.veh >= 0) return;
    if (k === 2) {
      const q = W.pl[j];
      if (!W.tm || !q || q === p || q.tm !== p.tm || !q.kd || q.out || hyp(q.x - p.x, q.y - p.y) > 2.0) return;
      if (p.ut === 9 && p.rv === q.i) return;
      p.rv = q.i; p.use = 5; p.uT = 5; p.ut = 9; q.rvb = 5; p.rl = 0; p.ads = 0; p.sx = 0;
    } else if (k === 3) toggleDoor(W, p, j, hooks);
    else if (k === 5) startVault(W, p, j, hooks);
    else if (k === 6) enterVeh(W, p, j, hooks);
    else if (k === 7) {   // 귀환 송신: stand still 8 s at the tower holding a 인식표
      const T = W.rt && W.rt[j];
      if (!T || !rcOn(W) || !tagOf(W, p.i) || hyp(T.x - p.x, T.y - p.y) > RC.r + 0.3 || p.ut === 10) return;
      p.use = p.uT = RC.ch; p.ut = 10; p.rcT = j; p.rl = 0; p.ads = 0; p.sx = 0; p.bq = 0;
      emit(W, hooks, 40, T.x, T.y, p.i, 1);
    }
  }
  /* smart heal choice: −1 if nothing useful */
  function healPick(p) {
    if (p.hp < 75) {
      if (p.hp <= 45 && p.hl[1] > 0) return 1;
      if (p.hl[0] > 0) return 0;
      if (p.hl[1] > 0) return 1;
      if (p.hl[2] > 0) return 2;
    }
    if (p.hp < 90 && p.hl[2] > 0) return 2;
    if (p.stm < 60 && p.hl[4] > 0) return 4;
    if (p.stm < 60 && p.hl[3] > 0) return 3;
    return -1;
  }
  function startHeal(W, p, k, hooks) {
    if (p.kd || p.out || p.swim || p.use > 0 || p.vt > 0 || (p.veh >= 0 && p.seat === 0)) return;
    const j = k >= 0 ? k : healPick(p);
    if (j < 0 || p.hl[j] <= 0) { emit(W, hooks, 11, p.x, p.y, p.i, 20); return; }
    p.use = p.uT = HEAL[j].t; p.ut = j; p.rl = 0; p.ads = 0; p.bq = 0; p.sx = 0;
    emit(W, hooks, 11, p.x, p.y, p.i, 30 + j);
  }
  function finishUse(W, p, hooks) {
    const j = p.ut; p.ut = -1; p.use = 0;
    if (j === 10) { recall(W, p, hooks); return; }
    if (j === 9) {
      const q = W.pl[p.rv]; p.rv = -1;
      if (q && q.kd && !q.out) { q.kd = 0; q.hp = 15; q.rvb = 0; emit(W, hooks, 11, q.x, q.y, q.i, 10); }
      return;
    }
    if (j < 0 || p.hl[j] <= 0) return;
    const H = HEAL[j];
    p.hl[j]--;
    if (H.st) { p.stm = Math.min(STM.max, p.stm + H.st); p.sb = Math.max(p.sb, H.sb); p.ex = 0; }
    else if (H.hp) p.hp = Math.max(p.hp, Math.min(H.to, p.hp + H.hp));
    else p.hp = Math.max(p.hp, H.to);
    emit(W, hooks, 11, p.x, p.y, p.i, j);
  }
  function startReload(p) {
    const w = heldGun(p); if (!w || p.rl > 0 || p.kd || p.vt > 0 || p.ut === 10) return;
    const G = GUN[w.t];
    if (w.m >= magW(w) || p.am[G.am] <= 0) return;
    p.rl = G.rl * effOf(w).rl; p.bq = 0; p.use = 0; p.ut = -1;
  }
  function setSlot(p, s) {
    if (p.kd || p.vt > 0) return;
    if (p.veh >= 0 && p.seat === 0) { if (s > 2 || !p.g[s] || !OH(p.g[s].t)) return; }
    if (s === 4) {
      if (p.sl === 4) { for (let k = 1; k <= THROW.length; k++) { const t = (p.ts + k) % THROW.length; if (p.th[t] > 0) { p.ts = t; break; } } return; }
      if (p.th[p.ts] <= 0) { const t = p.th.findIndex((n) => n > 0); if (t < 0) return; p.ts = t; }
    } else if (s <= 2 && !p.g[s]) return;
    if (p.sl === s) return;
    p.sl = s; p.rl = 0; p.bq = 0; p.cd = Math.max(p.cd, 0.3); p.ads = 0;
  }
  function toggleCrouch(p) { if (p.kd || p.swim || p.veh >= 0 || p.vt > 0 || p.air > 0) return; p.cr = p.cr ? 0 : 1; if (p.cr) p.sx = 0; }
  /* pings (위치 0 · 적 1 · 물건 2) and the map marker (3 set, 4 clear) — shown to the team */
  function ping(W, p, k, x, y) {
    if (k === 4) { delete W.mk[p.i]; W.mkv = (W.mkv || 0) + 1; return; }
    if (!fin(x) || !fin(y) || Math.abs(x) > HL || Math.abs(y) > HL) return;
    if (k === 3) { W.mk[p.i] = [r1(x), r1(y)]; W.mkv = (W.mkv || 0) + 1; return; }
    if (!(k >= 0 && k <= 2) || p.pgT > W.T) return;
    p.pgT = W.T + 0.35;
    W.pg.push({ id: ++W.pgn, i: p.i, tm: p.tm, k, x: r1(x), y: r1(y), t: 9 });
    if (W.pg.length > 16) W.pg.shift();
  }
  /* an action from a button/key: a number, or [code, a, b, c] */
  const ACTS = { 1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1, 9: 1, 10: 1, 11: 1, 12: 1, 13: 1, 14: 1, 15: 1, 16: 1, 17: 1, 18: 1, 19: 1, 60: 1, 61: 1, 62: 1, 63: 1, 30: 1, 31: 1, 32: 1, 33: 1, 34: 1, 40: 1, 42: 1, 44: 1, 50: 1, 51: 1, 52: 1, 53: 1, 54: 1, 55: 1, 57: 1, 58: 1 };
  function doAct(W, p, a, hooks) {
    if (p.out) return;
    const arr = Array.isArray(a), c = arr ? a[0] | 0 : a | 0, A1 = arr ? +a[1] : 0, A2 = arr ? +a[2] : 0, A3 = arr ? +a[3] : 0;
    if (c === 57) { ping(W, p, A1 | 0, A2 / 10, A3 / 10); return; }
    if (W.ph !== 2) return;
    if (c === 1) startReload(p);
    else if (c === 2) interact(W, p, hooks, A1 | 0, A2 | 0);
    else if (c === 3) startHeal(W, p, -1, hooks);
    else if (c >= 4 && c <= 8) setSlot(p, c - 4);
    else if (c === 9) { if (p.sl === 4) setSlot(p, 4); }
    else if (c >= 10 && c < 10 + THROW.length) { const t = c - 10; if (p.th[t] > 0 && !(p.veh >= 0 && p.seat === 0)) { p.ts = t; if (p.sl !== 4) setSlot(p, 4); } }
    else if (c >= 30 && c <= 34) startHeal(W, p, c - 30, hooks);
    else if (c === 40) { if (arr && (A1 === 1 || A1 === 2)) { if (!!p.cr !== (A1 === 1)) toggleCrouch(p); } else toggleCrouch(p); }   // [40,1] crouch · [40,2] stand (hold mode)
    else if (c === 42) swapSeat(W, p);
    else if (c === 44) lockDoor(W, p, A1 | 0, hooks);
    else if (c === 50) pickOne(W, p, A1 | 0, A2 / 10, A3 / 10, hooks);
    else if (c === 58) pickOne(W, p, Math.floor(A1 / 1000), A2 / 10, A3 / 10, hooks, A1 % 1000);
    else if (c === 51) dropOwn(W, p, A1 | 0, A2 | 0);
    else if (c === 52) { if (A1 >= 0 && A1 <= 2 && p.veh < 0) dropGun(W, p, A1 | 0); }
    else if (c === 53) { const t = p.g[0]; p.g[0] = p.g[1]; p.g[1] = t; if (p.sl === 0) p.sl = 1; else if (p.sl === 1) p.sl = 0; }
    else if (c === 54) { if (A1 >= 0 && A1 <= 2 && A2 >= 0 && A2 <= 4) unmountAtt(W, p, A1 | 0, A2 | 0); }
    else if (c === 55) { if (A1 >= 0 && A1 < ATT.length) mountAtt(W, p, A1 | 0, A2 >= 0 && A2 <= 2 ? A2 | 0 : -1, true); }
    else if (W.rg && c >= 60 && c <= 63) rangeAct(W, p, c, A1 | 0, A2 | 0);
    else if (W.pr && c >= 64 && c <= 67) practiceAct(W, p, c, A1 | 0, A2 | 0, hooks);
  }
  /* shooting range: take any gun / attachment, flip day and night, reset the targets */
  function rangeAct(W, p, c, a, b) {
    if (c === 60 && GUN[a]) {
      const s = pistolSlot(a) ? 2 : p.sl <= 1 ? p.sl : 0;
      p.g[s] = mkGun(a, GUN[a].mg); p.am[GUN[a].am] = 999; p.sl = s; p.rl = 0; p.bq = 0; p.cd = 0.3; p.ads = 0;
    } else if (c === 61 && ATT[a]) {
      const w = p.g[b >= 0 && b <= 2 ? b : p.sl <= 2 ? p.sl : 0]; if (!w || !accepts(w.t, a)) return;
      const k = ATT[a].k; w.a[k] = w.a[k] === a + 1 ? 0 : a + 1; w.m = magW(w);
    } else if (c === 62) { const now = todOf(W), want = darkOf(now) > 0.5 ? 0.1 : 0.66, cyc = W.M.T.quick ? 200 : DAY; W.todOff = (want * cyc - W.T) % cyc; envStep(W); }
    else if (c === 63) { for (const g of W.tg) { g.hp = 100; g.rt = 0; } p.sf = p.sh = p.hs = 0; p.dd = 0; }
  }

  /* 연습장 (practice): 64 탈것 꺼내기 · 65 아이템 채우기 · 66 설정(po 비트: 1 무한 체력 · 2 즉시 재장전 · 4 표적 움직임 · 8 표적 반격) · 67 끝내기 */
  function practiceAct(W, p, c, a, b, hooks) {
    if (c === 64 && VEH[a] && VEH[a].land) {
      if (p.veh >= 0) return;
      const fx = p.x + Math.cos(p.a) * 4, fy = p.y + Math.sin(p.a) * 4, s = snapFree(W.M, fx, fy);
      const free = W.vh.map((v, j) => j).filter((j) => !W.pl.some((q) => q.veh === j));
      if (W.vh.length >= 6 && free.length) { const j = free[0], v = W.vh[j]; Object.assign(v, { x: s[0], y: s[1], a: p.a, v: 0, vx: 0, vy: 0, hp: VEH[a].hp, ty: a, lb: -1 }); }
      else if (W.vh.length < 6) W.vh.push({ x: s[0], y: s[1], a: p.a, v: 0, vx: 0, vy: 0, hp: VEH[a].hp, ty: a, lb: -1 });
    } else if (c === 65) { p.th = THROW.map(() => 5); p.hl = HEAL.map(() => 5); p.vs = 3; p.hm = 3; p.bp = 3; p.hp = 100; p.stm = STM.max; }
    else if (c === 66) {
      W.prf = a & 15;
      for (const g of W.tg) { g.mx = W.prf & 4 ? g.mx0 || 3 + (g.d % 3) : 0; if (!(W.prf & 4)) g.x = g.bx; }
    } else if (c === 67) finish(W, hooks);
  }
  function practiceStep(W, h, hooks) {
    const p = W.pl[0]; if (!p || p.out) return;
    if (W.prf & 1) { p.hp = 100; }
    else if (p.hp <= 1.05) { p.hp = 100; emit(W, hooks, 42, p.x, p.y, p.i, 0); }   // 쓰러질 만큼 맞으면 바로 다시 일어나요
    if (W.prf & 2 && p.rl > 0.05) p.rl = 0.05;
    if (!(W.prf & 8)) return;
    for (let j = 0; j < W.tg.length; j++) {
      const g = W.tg[j]; if (g.hp <= 0) continue;
      g.fc = (g.fc == null ? 1 + j * 0.37 : g.fc) - h;
      if (g.fc > 0) continue;
      g.fc = 1.4 + (j % 3) * 0.3;
      const d = hyp(p.x - g.x, p.y - g.y);
      if (d > 90 || !los(W.M, g.x, g.y, p.x, p.y)) continue;
      emit(W, hooks, 41, g.x, g.y, j, 0);
      if (Math.random() < clamp(0.85 - d / 140, 0.25, 0.8)) hurt(W, p, 7, -1, -15, false, hooks);
    }
  }

  /* ----- movement ----- */
  function stamRest(p, h) { if (p.sr > 0) p.sr -= h; else if (p.stm < STM.max) p.stm = Math.min(STM.max, p.stm + h * STM.regen * (p.sb > 0 ? 2 : 1)); if (p.ex && p.stm >= STM.ready) p.ex = 0; }
  function movePlayer(W, p, I, h) {
    const M = W.M;
    if (p.air > 0) { p.air -= h; if (p.air < 0) p.air = 0; return; }
    if (p.veh >= 0) {
      const v = W.vh[p.veh]; p.x = v.x; p.y = v.y; p.vx = v.vx; p.vy = v.vy; p.cr = 0;
      if (fin(I.face) && p.seat > 0) p.a = I.face; else if (Math.abs(v.v) > 0.5 || p.seat === 0) p.a = v.v < -0.5 ? v.a + Math.PI : v.a;   // eyes follow the vehicle (a passenger who shoots looks that way)
      if (!(VEH[v.ty].ped && p.seat === 0 && p.sx)) stamRest(p, h);
      return;
    }
    if (p.vt > 0) {   // vaulting through a window
      const V = p.vw; p.vt -= h; p.vx = 0; p.vy = 0;
      if (V) { const u = clamp(1 - p.vt / VAULT_T, 0, 1); p.x = V[0] + (V[2] - V[0]) * u; p.y = V[1] + (V[3] - V[1]) * u; }
      if (p.vt <= 0) { p.vt = 0; p.vw = null; p.lnd = Math.max(p.lnd, 0.5); }
      return;
    }
    p.swim = isWater(M, p.x, p.y) ? 1 : 0;
    if (p.swim || p.kd) p.cr = 0;
    const ice = onIce(M, p.x, p.y);
    let ax = I.ax || 0, ay = I.ay || 0; const m = hyp(ax, ay); if (m > 1) { ax /= m; ay /= m; }
    if (p.ns > 0) p.ns -= h;
    const run = !!I.sp && m > 0.3 && !p.kd && !p.swim && !p.ads && p.use <= 0 && !(p.ns > 0) && !p.ex && p.stm > 0;
    if (run && p.cr) p.cr = 0;
    p.sx = run ? 1 : 0;
    if (run) p.rn = RUN_T; else if (p.rn > 0) p.rn -= h;
    let sp = p.kd ? CRAWL : VW;
    if (run) sp *= RUN; else if (p.cr) sp *= CROUCH;
    if (p.swim) sp *= VWAT * (p.stm <= 0 ? 0.7 : 1);
    if (p.use > 0) sp *= p.ut === 9 || p.ut === 10 ? 0 : 0.45;
    if (p.ads) sp *= 0.55;
    if (ice) sp *= 1.1;
    if (p.gas > 0) sp *= 0.6;
    if (M.mud.length && !p.swim && inMud(M, p.x, p.y)) sp *= 0.6;
    if (W.wx === 2 && !p.swim && !onRoadM(M, p.x, p.y) && inBld(M, p.x, p.y) < 0 && !(M.hsp.length && inHsp(M, p.x, p.y))) sp *= 0.85;   // blizzard: deep snow off the roads
    { const hw = heldGun(p); if (hw && GUN[hw.t].heavy) sp *= GUN[hw.t].mv || 0.85; }
    sp *= I.spd || 1;
    const drain = (run ? STM.run * Math.min(1, m) : 0) + (p.swim ? STM.swim : 0);
    if (drain > 0) { p.stm -= h * drain * (p.sb > 0 ? 0.5 : 1); p.sr = STM.delay; if (p.stm <= 0) { p.stm = 0; p.ex = 1; } }
    else stamRest(p, h);
    if (p.ut === 9 && m > 0.5) { const q = W.pl[p.rv]; if (q) q.rvb = 0; p.rv = -1; p.use = 0; p.ut = -1; }
    if (p.ut === 10 && m > 0.5) { p.use = 0; p.ut = -1; }
    const tx = ax * sp, ty = ay * sp, dvx = tx - p.vx, dvy = ty - p.vy, dv = hyp(dvx, dvy), mx = (ice ? 7 : ACC) * h;
    if (dv > mx) { p.vx += dvx / dv * mx; p.vy += dvy / dv * mx; } else { p.vx = tx; p.vy = ty; }
    p.x += p.vx * h; p.y += p.vy * h;
    p.hit = 0; p.bd = -1;
    collide(M, p, PR);
    // walking into a closed door opens it (unless it is locked)
    if (p.bd >= 0 && m > 0.3 && !p.kd && W.ds) { const D = M.doors[p.bd]; if (D && !W.ds[p.bd] && !(W.dl[p.bd] > 0) && (D.x - p.x) * ax + (D.y - p.y) * ay > 0) setDoor(W, p.bd, 1); }
    if (fin(I.face) && !p.kd) p.a = I.face;
    else if (m > 0.2 && !(p.ft > 0) && !p.ads) p.a = Math.atan2(ay, ax);
  }

  /* ----- weapons ----- */
  function sightOf(p) { const w = heldGun(p); return p.ads && w ? SIGHT[scW(w)] : HIPSIGHT; }
  /* current bullet spread (radians, ~2σ cone): hip/ADS base × movement × stance × vehicle + recoil bloom */
  function spreadOf(W, p, w) {
    const G = GUN[w.t], C = CLS[G.c], e = effOf(w);
    const k0 = G.c === 3 ? SGK : 1;
    let s = G.sp * (p.ads ? C.ads * e.ads * (G.c === 3 ? 1 : ADSK) : e.hip * C.hk * (G.c === 3 ? SGK : HIPK));
    if (p.veh >= 0) { const v = W.vh[p.veh], mv = !!v && Math.abs(v.v) > 1; s *= p.seat === 0 ? (mv ? 3 : 1.15) : (mv ? 1.8 : 1); }
    else {
      const f = Math.min(1.5, hyp(p.vx, p.vy) / VW);
      // sprinting (or just stopped sprinting): far wider than walking; walking in between
      if (p.sx || p.rn > 0) s *= Math.max(1 + 0.8 * e.mvs * f, (k0 > 1 ? 2 : RUNK) * (0.75 + 0.25 * e.mvs));
      else s *= 1 + 0.8 * e.mvs * f;
      if (p.cr) s *= f < 0.1 ? 0.62 : 0.72;
      if (p.lnd > 0) s *= 1 + Math.min(1, p.lnd) * 1.5;
    }
    // first shot (gun settled, no bloom) is tighter by the gun's fs; it fades back to normal as the bloom builds
    if (G.fs < 1) s *= G.fs + (1 - G.fs) * Math.min(1, p.bl / FS_BL);
    return s + p.bl;
  }
  const hitR = (q) => (q.kd ? 0.55 : q.cr ? PR * 0.82 : PR);
  function autoTarget(W, p, R) {
    let best = null, bd = 1e9;
    for (const q of W.pl) {
      if (q.out || q.tm === p.tm || q.air > 0) continue;
      const d = hyp(q.x - p.x, q.y - p.y) + (q.kd ? 14 : 0);
      if (d - (q.kd ? 14 : 0) > R || d >= bd || !canSee(W, p, q)) continue;
      bd = d; best = q;
    }
    return best;
  }
  function aimFor(W, p, I, R) {
    if (fin(I.aim)) {
      let ang = I.aim, q = null;
      if (I.mag) {
        let bd = 1e9;
        for (const o of W.pl) {
          if (o.out || o.tm === p.tm || o.air > 0) continue;
          const d = hyp(o.x - p.x, o.y - p.y); if (d > R || d < 0.3) continue;
          const df = Math.abs(wrapA(Math.atan2(o.y - p.y, o.x - p.x) - ang));
          if (df > 0.1 + 0.9 / d || df >= bd || !canSee(W, p, o)) continue;
          bd = df; q = o;
        }
        if (q) ang += wrapA(Math.atan2(q.y - p.y, q.x - p.x) - ang) * 0.8;
      }
      return { a: ang, d: fin(I.ad) ? I.ad : q ? hyp(q.x - p.x, q.y - p.y) : null, q };
    }
    const q = I.auto ? autoTarget(W, p, R) : null;    // bots only — people shoot where they face
    if (q) return { a: Math.atan2(q.y - p.y, q.x - p.x), d: hyp(q.x - p.x, q.y - p.y), q };
    return { a: p.a, d: null, q: null };
  }
  /* hitscan: first wall / player / vehicle / animal / range target along the ray */
  function castShot(W, p, ang, maxR) {
    const ux = Math.cos(ang), uy = Math.sin(ang), x0 = p.x + ux * 0.5, y0 = p.y + uy * 0.5;
    let best = rayStatic(W.M, x0, y0, ux, uy, maxR), hq = null, hv = -1, ha = -1, ht = -1, kind = best < maxR - 0.01 ? 1 : 0;
    for (const q of W.pl) {
      if (q === p || q.out || q.air > 0 || q.veh >= 0 || q.tm === p.tm) continue;
      const t = rayCircle(x0, y0, ux, uy, q.x, q.y, hitR(q));
      if (t >= 0 && t < best) { best = t; hq = q; hv = -1; kind = 2; }
    }
    W.vh.forEach((v, j) => {
      if (v.hp <= 0 || j === p.veh) return;
      const t = rayCircle(x0, y0, ux, uy, v.x, v.y, VEH[v.ty].r);
      if (t >= 0 && t < best) { best = t; hq = null; hv = j; kind = 3; }
    });
    if (W.an) W.an.forEach((a, j) => { if (a.hp <= 0) return; const t = rayCircle(x0, y0, ux, uy, a.x, a.y, ANI[a.k].r); if (t >= 0 && t < best) { best = t; hq = null; hv = -1; ha = j; kind = 2; } });
    if (W.tg) W.tg.forEach((g, j) => { if (g.hp <= 0) return; const t = rayCircle(x0, y0, ux, uy, g.x, g.y, 0.5); if (t >= 0 && t < best) { best = t; hq = null; hv = -1; ha = -1; ht = j; kind = 2; } });
    if (hv >= 0) {
      const V = VEH[W.vh[hv].ty], rs = riders(W, hv).filter((q) => q.tm !== p.tm), ex = V.arm ? 0 : V.sh === 'bike' || V.sh === 'jetski' || V.sh === 'sled' ? 0.9 : V.sh === 'boat' || V.sh === 'airboat' || V.sh === 'buggy' || V.sh === 'side' ? 0.6 : 0.45;
      if (rs.length && Math.random() < ex) { hq = rs[Math.floor(Math.random() * rs.length)]; kind = 2; }
    }
    if (ha >= 0 || ht >= 0) hv = -1;
    return { t: best, q: hq, v: hv, an: ha, tg: ht, kind, x0, y0 };
  }
  const shotCode = (t, kind, sup, i) => t | (kind << 8) | ((sup ? 1 : 0) << 10) | (i << 11);
  function shootGun(W, p, w, ang, hooks) {
    const G = GUN[w.t], C = CLS[G.c], e = effOf(w);
    w.m--; p.ft = 0.12;
    if (W.rg) p.am[G.am] = 999;
    const sup = supW(w);
    if (!sup) { p.rev = Math.max(p.rev, 1.4); if (!e.fh) p.mf = 1; }      // muzzle flash: seen from far away at night
    const spr = spreadOf(W, p, w);
    p.bl = Math.min(BLMAX, p.bl + G.rc * BLK * C.bk * (p.ads ? 0.65 : 1) * e.rc * (p.cr ? 0.8 : 1));
    p.sf++; if (p.wu.indexOf(w.t) < 0 && p.wu.length < 8) p.wu.push(w.t);
    if (!sup && W.ns.length < 12 && !W.ns.some((n) => n[2] > W.T - 1 && hyp(n[0] - p.x, n[1] - p.y) < 8)) W.ns.push([r1(p.x), r1(p.y), W.T]);
    if (G.pv || G.c === 8) {
      const a = windA(W, ang + gauss() * spr * 0.5, 0.05);
      const kind = G.c === 8 ? 'f' : G.c === 9 ? 'r' : 'b', v = G.c === 8 ? 22 : G.pv;
      W.pj.push({ k: kind, x: p.x + Math.cos(a) * 0.6, y: p.y + Math.sin(a) * 0.6, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: G.c === 8 ? 26 : G.mr, o: p.i, tm: p.tm, d: G.d, g: w.t, a, ex: G.ex });
      emit(W, hooks, 5, p.x, p.y, shotCode(w.t, 0, sup || G.c === 7, p.i), Math.round((wrapA(a) + Math.PI) * 100) * 256);
      return;
    }
    const n = G.n || 1, acc = {};
    let tr = null;
    const hc = n > 1 ? 0.03 : 0.1 + (p.ads ? 0.12 : 0) + (G.c === 5 && p.ads ? 0.2 : 0);
    for (let k = 0; k < n; k++) {
      const a = n > 1 ? ang + (k / (n - 1) - 0.5) * spr * 1.3 * e.pel + gauss() * spr * 0.2 * e.pel : ang + gauss() * spr * 0.5;
      const r = castShot(W, p, windA(W, a, 0.012), G.mr);
      if (k === (n >> 1) || !tr) tr = { a, r };
      const f = fallOf(G, r.t);
      if (r.q) {
        const head = Math.random() < hc, d = G.d * f * (head ? C.hd : 1);
        const ac = acc[r.q.i] || (acc[r.q.i] = { q: r.q, d: 0, head: false });
        ac.d += d; ac.head = ac.head || head;
        if (!tr.r.q) tr = { a, r };
      } else if (r.v >= 0) vehDmg(W, r.v, G.d * f * 1.5, p.i, hooks);
      else if (r.an >= 0) { anHurt(W, r.an, G.d * f * 2, p.i, hooks); tr = { a, r }; }
      else if (r.tg >= 0) { const head = Math.random() < hc; tgHit(W, r.tg, G.d * f * (head ? C.hd : 1), head, p, hooks); tr = { a, r }; }
    }
    let anyHit = false, anyHead = false;
    for (const k in acc) { const ac = acc[k]; anyHit = true; anyHead = anyHead || ac.head; hurt(W, ac.q, ac.d, p.i, w.t, ac.head, hooks); if (!ac.q.out && ac.q.veh < 0) { ac.q.vx += Math.cos(ang) * 0.8; ac.q.vy += Math.sin(ang) * 0.8; } }
    if (anyHit) { p.sh++; if (anyHead) p.hs++; }
    emit(W, hooks, 5, tr.r.x0, tr.r.y0, shotCode(w.t, tr.r.kind, sup, p.i), Math.round((wrapA(tr.a) + Math.PI) * 100) * 256 + Math.min(255, Math.round(tr.r.t)));
  }
  function meleeHit(W, p, ang, hooks) {
    const Mw = p.sl === 3 && p.ml >= 0 ? MELEE[p.ml] : FIST, how = p.sl === 3 && p.ml >= 0 ? I_MEL + p.ml : -1;
    p.cd = Mw.cd * (p.stm < STM.melee ? 1.7 : 1); p.ft = 0.22;
    p.stm = Math.max(0, p.stm - STM.melee); p.sr = STM.delay;
    const inArc = (x, y, R) => { const dx = x - p.x, dy = y - p.y, d = hyp(dx, dy); return d <= Mw.r + R && d > 1e-6 && Math.abs(wrapA(Math.atan2(dy, dx) - ang)) <= Mw.arc / 2 + (d < 1.1 ? 0.7 : 0) && los(W.M, p.x, p.y, x, y); };
    for (const q of W.pl) {
      if (q.out || q.air > 0 || q.tm === p.tm || q.veh >= 0 || !inArc(q.x, q.y, PR)) continue;
      const dx = q.x - p.x, dy = q.y - p.y, d = hyp(dx, dy);
      hurt(W, q, Mw.d, p.i, how, false, hooks);
      if (!q.out) { q.vx += dx / d * 5; q.vy += dy / d * 5; }
    }
    if (W.an) W.an.forEach((a, j) => { if (a.hp > 0 && inArc(a.x, a.y, ANI[a.k].r)) anHurt(W, j, Mw.d, p.i, hooks); });
    if (W.tg) W.tg.forEach((g, j) => { if (g.hp > 0 && inArc(g.x, g.y, 0.5)) tgHit(W, j, Mw.d, false, p, hooks); });
    emit(W, hooks, 12, p.x + Math.cos(ang) * 1.1, p.y + Math.sin(ang) * 1.1, p.i, Math.round(wrapA(ang) * 100) + 400 + (how >= 0 ? 1000 : 0));
  }
  function throwIt(W, p, A, hooks) {
    const t = p.ts; if (p.th[t] <= 0) { p.sl = bestSlot(p); return; }
    let d = fin(A.d) ? clamp(A.d, 2, 26) : 12;
    const ux = Math.cos(A.a), uy = Math.sin(A.a), wall = rayStatic(W.M, p.x, p.y, ux, uy, d);
    if (wall < d) d = Math.max(0.8, wall - 0.5);
    const T = 0.3 + d / 18;
    const wk = W.wx === 3 ? d * 0.1 : 0;
    W.pj.push({ k: 't', ty: t, x0: p.x, y0: p.y, x: p.x, y: p.y, tx: p.x + ux * d + Math.cos(W.wa) * wk, tyy: p.y + uy * d + Math.sin(W.wa) * wk, t: 0, T, f: THROW[t].f, z: 0, o: p.i, tm: p.tm, st: -1 });
    if (!W.rg) p.th[t]--;
    p.cd = 0.75; p.ft = 0.25; p.a = A.a;
    emit(W, hooks, 19, p.x, p.y, p.i, t);
    if (p.th[t] <= 0) { const n = p.th.findIndex((c) => c > 0); if (n >= 0) p.ts = n; else p.sl = bestSlot(p); }
  }
  function fireStep(W, p, I, h, hooks) {
    if (p.cd > 0) p.cd -= h;
    const w = heldGun(p);
    if (p.bl > 0) p.bl = Math.max(0, p.bl - h * (0.06 + p.bl * 3.5) * (w ? effOf(w).rec : 1));
    if (p.rl > 0) {
      p.rl -= h;
      if (p.rl <= 0) { p.rl = 0; if (w) { const G = GUN[w.t]; if (W.rg) p.am[G.am] = 999; const take = Math.min(magW(w) - w.m, p.am[G.am]); if (take > 0) { w.m += take; p.am[G.am] -= take; } } }
    }
    const fire = !!I.fire, edge = fire && !p.fh; p.fh = fire ? 1 : 0;
    if (!fire) p.arm = 1;
    if (p.kd || p.out || p.air > 0 || p.swim || p.vt > 0) { p.bq = 0; return; }
    if (p.veh >= 0 && p.seat === 0 && (!w || !OH(w.t))) { p.bq = 0; return; }   // driving: one-handed guns only
    const R = Math.min(sightOf(p), w ? GUN[w.t].mr : 30);
    if (p.bq > 0) {
      p.bt -= h;
      if (!w || w.m <= 0) p.bq = 0;
      else if (p.bt <= 0) { const A = aimFor(W, p, I, R); p.a = A.a; shootGun(W, p, w, A.a, hooks); p.bq--; p.bt = 0.07; }
      return;
    }
    if (w && w.m <= 0 && p.rl <= 0 && p.use <= 0 && p.am[GUN[w.t].am] > 0) startReload(p);
    // throwables: one throw per press, queued until the hand is ready
    if (p.sl !== 4) p.tq = null;
    else {
      if (fire && p.arm) { p.arm = 0; const A0 = aimFor(W, p, I, 26); p.tq = [A0.a, A0.d]; if (p.use > 0 && p.ut !== 9) { p.use = 0; p.ut = -1; } }
      if (p.tq && p.cd <= 0 && p.use <= 0) { throwIt(W, p, { a: p.tq[0], d: p.tq[1] }, hooks); p.tq = null; }
      return;
    }
    if (!fire || p.cd > 0 || p.rl > 0) return;
    if (p.use > 0) { if (edge && p.ut !== 9) { p.use = 0; p.ut = -1; } else return; }
    const A = aimFor(W, p, I, p.sl === 3 || !w ? 3.5 : R);
    p.a = A.a;
    if (p.sl === 3 || !w) { meleeHit(W, p, A.a, hooks); return; }
    if (w.m <= 0) { if (edge) emit(W, hooks, 6, p.x, p.y, p.i, 0); p.cd = 0.3; return; }
    const G = GUN[w.t];
    if ((G.c === 8 || G.c === 9 || G.mg <= 2) && !edge && G.c !== 3) return;   // single shots: one per press
    p.cd = G.cd;
    shootGun(W, p, w, A.a, hooks);
    if (G.bu) { p.bq = G.bu - 1; p.bt = 0.07; }
  }

  /* ----- projectiles (thrown items, bolts, rockets, flares) and areas ----- */
  function flashBang(W, x, y, o, hooks) {
    emit(W, hooks, 10, x, y, o, 0);
    for (const q of W.pl) {
      if (q.out || q.air > 0) continue;
      const d = hyp(q.x - x, q.y - y); if (d > 14 || !los(W.M, x, y, q.x, q.y)) continue;
      let t = 0.8 + 3 * (1 - d / 14);
      if (Math.abs(wrapA(Math.atan2(y - q.y, x - q.x) - q.a)) > 1.8) t *= 0.45;
      q.fl = Math.max(q.fl, t);
    }
  }
  function addLight(W, x, y, r, t) { W.lt.push({ x: r1(x), y: r1(y), r, t }); if (W.lt.length > 6) W.lt.shift(); }
  /* the flare gun calls a supply drop where the flare comes down */
  function flareDrop(W, x, y, hooks) {
    const s = snapFree(W.M, x, y);
    if (!landAt(W.M, s[0], s[1], 1)) return;
    W.ad.push({ x: r1(s[0]), y: r1(s[1]), t: 12, op: 0 }); if (W.ad.length > 4) W.ad.shift();
    emit(W, hooks, 14, s[0], s[1], 1, 0);
  }
  function landThrow(W, b, hooks) {
    const t = b.ty;
    if (t === 0) explode(W, b.x, b.y, 7, 150, b.o, I_THR, hooks, 0);
    else if (t === 1) { W.ar.push({ k: 0, x: r1(b.x), y: r1(b.y), t: 15, o: b.o }); emit(W, hooks, 8, b.x, b.y, b.o, 0); }
    else if (t === 2) flashBang(W, b.x, b.y, b.o, hooks);
    else if (t === 3) { W.ar.push({ k: 1, x: r1(b.x), y: r1(b.y), t: 8, o: b.o }); emit(W, hooks, 9, b.x, b.y, b.o, 0); }
    else if (t === 4) explode(W, b.x, b.y, 4.5, 140, b.o, I_THR + 4, hooks, 0);
    else if (t === 5) { addLight(W, b.x, b.y, 24, 25); emit(W, hooks, 26, b.x, b.y, b.o, 0); }
    else if (t === 6) explode(W, b.x, b.y, 5, 115, b.o, I_THR + 6, hooks, 0);
    else if (t === 7) { W.ar.push({ k: 3, x: r1(b.x), y: r1(b.y), t: 8, o: b.o, n: 0 }); }
    else if (t === 8) { W.ar.push({ k: 2, x: r1(b.x), y: r1(b.y), t: 10, o: b.o }); emit(W, hooks, 8, b.x, b.y, b.o, 1); }
    else explode(W, b.x, b.y, 9, 110, b.o, I_THR + 9, hooks, 0);
    if (W.ar.length > 12) W.ar.shift();
  }
  function stepProj(W, h, hooks) {
    for (let k = W.pj.length - 1; k >= 0; k--) {
      const b = W.pj[k];
      if (b.k === 't') {
        b.t += h;
        if (b.st >= 0) { const q = W.pl[b.st]; if (q && !q.out) { b.x = q.x; b.y = q.y; b.z = 0.6; } }
        else {
          const u = Math.min(1, b.t / b.T);
          b.x = b.x0 + (b.tx - b.x0) * u; b.y = b.y0 + (b.tyy - b.y0) * u; b.z = 4 * u * (1 - u) * Math.min(3, 0.8 + b.T * 2);
          // sticky bomb: grabs the first person it lands next to
          if (b.ty === 4 && u >= 1 && b.st < 0) { let bd = 1.4; for (const q of W.pl) { if (q.out || q.air > 0) continue; const d = hyp(q.x - b.x, q.y - b.y); if (d < bd) { bd = d; b.st = q.i; } } if (b.st < 0) b.st = -2; }
        }
        if (b.t < Math.max(b.T, b.f)) continue;
        W.pj.splice(k, 1);
        landThrow(W, b, hooks);
        continue;
      }
      // bolt / rocket / flare
      const sp = hyp(b.vx, b.vy), stp = sp * h, ux = b.vx / sp, uy = b.vy / sp;
      let best = rayStatic(W.M, b.x, b.y, ux, uy, stp), hq = null, hv = -1, ha = -1, ht = -1;
      if (b.k !== 'f') {
        for (const q of W.pl) {
          if (q.out || q.air > 0 || q.veh >= 0 || q.tm === b.tm) continue;
          const t = rayCircle(b.x, b.y, ux, uy, q.x, q.y, hitR(q)); if (t >= 0 && t < best) { best = t; hq = q; hv = -1; }
        }
        W.vh.forEach((v, j) => { if (v.hp <= 0) return; const t = rayCircle(b.x, b.y, ux, uy, v.x, v.y, VEH[v.ty].r); if (t >= 0 && t < best) { best = t; hq = null; hv = j; } });
        if (W.an) W.an.forEach((a, j) => { if (a.hp <= 0) return; const t = rayCircle(b.x, b.y, ux, uy, a.x, a.y, ANI[a.k].r); if (t >= 0 && t < best) { best = t; hq = null; hv = -1; ha = j; } });
        if (W.tg) W.tg.forEach((g, j) => { if (g.hp <= 0) return; const t = rayCircle(b.x, b.y, ux, uy, g.x, g.y, 0.5); if (t >= 0 && t < best) { best = t; hq = null; hv = -1; ha = -1; ht = j; } });
      }
      const end = best < stp - 1e-6 || hq || hv >= 0 || ha >= 0 || ht >= 0;
      if (end || b.l - stp <= 0) {
        const x = b.x + ux * Math.min(best, stp), y = b.y + uy * Math.min(best, stp);
        W.pj.splice(k, 1);
        if (b.k === 'r') { explode(W, x - ux * 0.3, y - uy * 0.3, b.ex || 4, b.d, b.o, b.g, hooks, 0); continue; }
        if (b.k === 'f') { addLight(W, x, y, 28, 25); emit(W, hooks, 26, x, y, b.o, 1); flareDrop(W, x, y, hooks); continue; }
        if (!end) continue;
        if (hq) { const hd = Math.random() < 0.22, o = W.pl[b.o]; if (o) { o.sh++; if (hd) o.hs++; } hurt(W, hq, b.d, b.o, b.g, hd, hooks); }
        else if (hv >= 0) vehDmg(W, hv, b.d * 0.5, b.o, hooks);
        else if (ha >= 0) anHurt(W, ha, b.d, b.o, hooks);
        else if (ht >= 0) tgHit(W, ht, b.d, false, W.pl[b.o], hooks);
        else emit(W, hooks, 6, x, y, -1, 1);
        continue;
      }
      b.x += b.vx * h; b.y += b.vy * h; b.l -= stp;
    }
    if (W.pj.length > 40) W.pj.splice(0, W.pj.length - 40);
    for (let k = W.ar.length - 1; k >= 0; k--) {
      const a = W.ar[k]; a.t -= h;
      if (a.t <= 0) { W.ar.splice(k, 1); continue; }
      if (a.k === 1) for (const q of W.pl) if (!q.out && q.air <= 0 && q.veh < 0 && hyp(q.x - a.x, q.y - a.y) < 3.2) { hurt(W, q, 11 * h, a.o, -6, false, hooks, true); q.burn = 0.3; }
      if (a.k === 2) for (const q of W.pl) if (!q.out && q.air <= 0 && q.veh < 0 && q.spc !== 2 && hyp(q.x - a.x, q.y - a.y) < 4.4) { hurt(W, q, 3 * h, a.o, -9, false, hooks, true); q.gas = 0.4; }
      if (a.k === 3) { a.n -= h; if (a.n <= 0) { a.n = 0.18 + Math.random() * 0.5; const g = [I_GUN + 20, I_GUN + 21, I_GUN + 9, I_GUN + 47][Math.floor(Math.random() * 4)]; emit(W, hooks, 5, a.x, a.y, shotCode(g, 0, 0, a.o >= 0 ? a.o : 0), Math.round(Math.random() * 628) * 256); W.ns.push([a.x, a.y, W.T]); } }
    }
    for (let k = W.lt.length - 1; k >= 0; k--) { W.lt[k].t -= h; if (W.lt[k].t <= 0) W.lt.splice(k, 1); }
  }
  /* ----- wild animals ----- */
  function nearWater(M, x, y, r) { for (let k = 0; k < 8; k++) { const a = k * 0.785; if (isWater(M, x + Math.cos(a) * r, y + Math.sin(a) * r)) return true; } return false; }
  function spawnAnimals(W) {
    const M = W.M, T = M.T; W.an = [];
    if (!T.ani || W.rg) return;
    const A = M.f * M.f;
    for (const [k, n0] of T.ani) {
      const K = ANI[k], n = Math.min(9, Math.round(n0 * Math.pow(A, 0.6)));
      for (let i = 0; i < n; i++) for (let tr = 0; tr < 60; tr++) {
        let x, y;
        if (K.wet === 2) { const lb = M.lobes[Math.floor(Math.random() * M.lobes.length)], p = lobePt(lb, Math.random() * 6.283, 4 + Math.random() * 8); x = p[0]; y = p[1]; if (!isWater(M, x, y) || Math.abs(x) > HL - 4 || Math.abs(y) > HL - 4) continue; }
        else {
          const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * M.base * 0.95; x = Math.cos(a) * d; y = Math.sin(a) * d;
          if (isWater(M, x, y) || solidAt(M, x, y, K.r) || inBld(M, x, y) >= 0 || inLava(M, x, y)) continue;
          if (K.wet === 1 && !nearWater(M, x, y, 6) && tr < 50) continue;
        }
        W.an.push({ k, x: r1(x), y: r1(y), hx: x, hy: y, gx: x, gy: y, a: Math.random() * 6.28, hp: K.hp, tg: -1, cd: 0, th: Math.random(), wt: Math.random() * 3, vx: 0, vy: 0, hit: 0 });
        break;
      }
    }
    if (W.an.length > 24) W.an.length = 24;
  }
  function anHurt(W, j, dmg, by, hooks) {
    const a = W.an[j]; if (!a || a.hp <= 0 || !(dmg > 0)) return;
    a.hp -= dmg; if (by >= 0 && W.pl[by] && !W.pl[by].out) a.tg = by;
    emit(W, hooks, 27, a.x, a.y, j, Math.min(255, Math.round(dmg)) * 2 + (by >= 0 ? 1 : 0) + (a.hp <= 0 ? 512 : 0));
  }
  function stepAnimals(W, h, hooks) {
    const M = W.M;
    for (let j = W.an.length - 1; j >= 0; j--) {
      const a = W.an[j], K = ANI[a.k];
      if (a.hp <= 0) { W.an.splice(j, 1); continue; }
      if (a.cd > 0) a.cd -= h;
      let q = a.tg >= 0 ? W.pl[a.tg] : null;
      const sea = K.wet === 2;
      if (q && (q.out || q.air > 0 || q.veh >= 0 || hyp(q.x - a.x, q.y - a.y) > K.ag * 2.4 || (sea && !q.swim) || hyp(a.x - a.hx, a.y - a.hy) > 45)) { q = null; a.tg = -1; }
      a.th -= h;
      if (!q && a.th <= 0) {
        a.th = 0.35 + Math.random() * 0.2;
        let bd = K.ag * (W.dk > 0.5 ? 1.25 : 1);
        for (const o of W.pl) { if (o.out || o.air > 0 || o.veh >= 0 || (sea && !o.swim)) continue; const d = hyp(o.x - a.x, o.y - a.y) * (o.cr ? 1.5 : 1) * (o.spc === 1 ? 1.4 : 1); if (d < bd && los(M, a.x, a.y, o.x, o.y)) { bd = d; q = o; } }
        if (q) { a.tg = q.i; emit(W, hooks, 28, a.x, a.y, j, a.k); }
      }
      let tx = a.gx, ty = a.gy, sp = K.sp * 0.3;
      if (q) {
        tx = q.x; ty = q.y; sp = K.sp;
        if (hyp(q.x - a.x, q.y - a.y) < K.r + PR + 0.35 && a.cd <= 0) { hurt(W, q, K.d, -1, -8, false, hooks); a.cd = K.cd; if (!q.out) { const d = hyp(q.x - a.x, q.y - a.y) || 1; q.vx += (q.x - a.x) / d * 4; q.vy += (q.y - a.y) / d * 4; } }
      } else {
        a.wt -= h;
        if (a.wt <= 0 || hyp(a.gx - a.x, a.gy - a.y) < 0.8) { a.wt = 2 + Math.random() * 5; const g = Math.random() * 6.283, r = Math.random() * 10; a.gx = a.hx + Math.cos(g) * r; a.gy = a.hy + Math.sin(g) * r; }
      }
      const dx = tx - a.x, dy = ty - a.y, d = hyp(dx, dy);
      if (d > 0.2) {
        const nx = a.x + dx / d * sp * h, ny = a.y + dy / d * sp * h, wet = isWater(M, nx, ny);
        if (sea ? wet : (!wet || K.wet === 1) && !inLava(M, nx, ny) || a.k === 8) {
          a.vx = dx / d * sp; a.vy = dy / d * sp; a.x = nx; a.y = ny;
          if (!sea) collide(M, a, K.r);
          a.a = Math.atan2(dy, dx);
        } else { a.gx = a.hx; a.gy = a.hy; a.wt = 1; }
      }
    }
  }
  /* ----- shooting range targets ----- */
  function tgHit(W, j, dmg, head, p, hooks) {
    const g = W.tg[j]; if (!g || g.hp <= 0) return;
    g.hp -= dmg; g.lh = W.T;
    if (p) { p.sh++; if (head) p.hs++; p.dd += dmg; }
    emit(W, hooks, 29, g.x, g.y, j, Math.min(999, Math.round(dmg)) * 2 + (head ? 1 : 0));
    if (g.hp <= 0) g.rt = 1.5;
  }
  function stepTargets(W, h) {
    for (const g of W.tg) {
      if (g.mx) { g.ph += h * g.sp; g.x = g.bx + Math.sin(g.ph) * g.mx; }
      if (g.hp <= 0) { g.rt -= h; if (g.rt <= 0) g.hp = 100; }
    }
  }
  /* ----- light, darkness, haze (night cycle; volcanic ash, swamp fog, sandstorms) ----- */
  const DAY = 280;
  const todOf = (W) => (((W.T + (W.todOff || 0)) / (W.M.T.quick ? 200 : DAY)) % 1 + 1) % 1;
  function darkOf(t) {   // 0 day … 1 night: 낮 0–.42, 노을 .42–.52, 밤 .52–.86, 새벽 .86–1
    if (t < 0.42) return 0; if (t < 0.52) return (t - 0.42) / 0.1; if (t < 0.86) return 1; return 1 - (t - 0.86) / 0.14;
  }
  function envStep(W) {
    W.dk = W.ph >= 2 ? darkOf(todOf(W)) : 0;
    const T = W.M.T;
    W.hz = Math.min(T.volc ? 30 : T.swamp ? 34 : W.ss > 0 ? 20 : 999, W.ph >= 2 ? [999, 70, 30, 55][W.wx | 0] : 999);
    W.vr = Math.min(W.dk < 0.05 ? 999 : 13 + (1 - W.dk) * 70, W.hz);
  }
  const litAt = (W, x, y) => W.lt.some((l) => hyp(l.x - x, l.y - y) < l.r) || W.ar.some((a) => a.k === 1 && hyp(a.x - x, a.y - y) < 5);
  const lightOn = (W, p) => W.dk > 0.3 && !!p.lit;
  /* how far v can see q right now */
  function visDist(W, v, q) {
    let R = W.vr;
    if (R >= 900) return R;
    const hz = W.hz;
    if (v.spc === 3) R = Math.max(R, Math.min(hz, 40));
    if (q.mf > 0) R = Math.max(R, Math.min(hz, 110));
    if (lightOn(W, q)) R = Math.max(R, Math.min(hz, 45));
    if (q.veh >= 0 && W.dk > 0.3) R = Math.max(R, Math.min(hz, 55));
    if (R < hz && W.dk > 0.3 && litAt(W, q.x, q.y)) R = hz;
    if (R < 42 && lightOn(W, v) && Math.abs(wrapA(Math.atan2(q.y - v.y, q.x - v.x) - v.a)) < 0.28) R = Math.min(hz, 42);    // flashlight: a narrow, long beam
    if (R < 32 && v.veh >= 0 && W.dk > 0.3) { const c = W.vh[v.veh]; if (c && Math.abs(wrapA(Math.atan2(q.y - c.y, q.x - c.x) - c.a)) < 0.45) R = Math.min(hz, 32); }
    return R;
  }
  /* field of view: ~110° ahead (narrower through a scope) + VIS_NEAR all round */
  const REACH1 = 21;   // hip / iron sights / red dot / holo: about the normal (zoomed-in) screen; 2x+ scopes see SIGHT[]
  function reachOf(v) { if (!v.ads) return REACH1; const w = heldGun(v); const sc = w ? scW(w) : 0; return sc >= 3 ? SIGHT[sc] : REACH1; }
  function coneHalf(v) { if (!v.ads) return VIS_HALF; const w = heldGun(v); return w ? SCHALF[scW(w)] : SCHALF[3]; }
  function inCone(v, x, y) { const dx = x - v.x, dy = y - v.y; if (dx * dx + dy * dy <= VIS_NEAR * VIS_NEAR) return true; return Math.abs(wrapA(Math.atan2(dy, dx) - v.a)) <= coneHalf(v) + 0.05; }
  /* the field-of-view polygon (shared by the view and the node checks): rays from the eyes, most of them inside the cone so a
     window or doorway far away still gets several rays (was: 240 evenly spread, ~0.8 m apart at 30 m — a far window could fall
     between two rays and the room behind it stayed under its roof). Each ray goes 0.3 m into the wall it hits. */
  const VIS_N = 480, VIS_FE = 0.14, VIS_FC = 0.75;
  function visFan(M, x, y, va, half, R, px, py) {
    const C = Math.min(6.2832, 2 * (half + VIS_FE)), a0 = va - C / 2;
    for (let k = 0; k < VIS_N; k++) {
      const t = k / VIS_N, a = t < VIS_FC ? a0 + t / VIS_FC * C : a0 + C + (t - VIS_FC) / (1 - VIS_FC) * (6.2832 - C);
      const df = Math.abs(wrapA(a - va)), ux = Math.cos(a), uy = Math.sin(a);
      const lim = df <= half ? R : df < half + VIS_FE ? VIS_NEAR + (R - VIS_NEAR) * Math.pow(1 - (df - half) / VIS_FE, 2) : VIS_NEAR;
      const d = rayStatic(M, x, y, ux, uy, lim, 1), e = d + (lim > VIS_NEAR + 0.5 ? 0.3 : 0);
      px[k] = x + ux * e; py[k] = y + uy * e;
    }
  }
  function inPoly(px, py, x, y) {
    let ins = false;
    for (let i = 0, j = px.length - 1; i < px.length; j = i++) if ((py[i] > y) !== (py[j] > y) && x < (px[j] - px[i]) * (y - py[i]) / (py[j] - py[i]) + px[i]) ins = !ins;
    return ins;
  }
  function inSmoke(W, x, y) { for (const s of W.ar) if (s.k === 0 && s.t > 0.8 && hyp(x - s.x, y - s.y) < 4.6) return true; return false; }
  function hiddenFrom(W, v, q) {
    if (!v || q.tm === v.tm || q.air > 0 || q.out) return false;
    const M = W.M, d = hyp(q.x - v.x, q.y - v.y);
    if (d > VIS_NEAR && !inCone(v, q.x, q.y)) return true;   // behind me / outside my field of view
    if (d > reachOf(v)) return true;                           // beyond what my sight (scope) reaches
    if (d > visDist(W, v, q)) return true;      // night, ash, fog, sandstorm
    if (q.rev > 0 || q.veh >= 0) return false;
    // walls, closed doors and roofs are handled by line of sight; bushes hide you unless someone is very close
    if (d > (q.spc === 1 ? 1.4 : q.cr ? 2.2 : 3.5) && inBush(M, q.x, q.y)) return true;
    if (q.spc === 1 && q.cr && d > 16 && hyp(q.vx, q.vy) < 0.5 && !isWater(M, q.x, q.y)) return true;   // ghillie suit lying low in the open
    if (d > 2.5 && inSmoke(W, q.x, q.y)) return true;
    return false;
  }
  const canSee = (W, v, q) => !hiddenFrom(W, v, q) && los(W.M, v.x, v.y, q.x, q.y);

  /* ----- step ----- */
  function stepWorld(W, h, inputs, hooks) {
    if (W.ph === 0) {
      for (const p of W.pl) { const I = inputs[p.i]; if (I && I.land && fin(I.land[0]) && fin(I.land[1])) { p.lx = clamp(I.land[0], -HL + 3, HL - 3); p.ly = clamp(I.land[1], -HL + 3, HL - 3); } }
      W.t -= h;
      if (W.t <= 0) {
        W.ph = 1; W.t = FALL_T;
        for (const p of W.pl) {
          if (!fin(p.lx)) { const a = Math.random() * 6.283, d = Math.random() * W.M.base * 0.8; p.lx = Math.cos(a) * d; p.ly = Math.sin(a) * d; }
          const s = snapFree(W.M, p.lx, p.ly); p.x = s[0]; p.y = s[1]; p.vx = 0; p.vy = 0; p.air = FALL_T;
        }
        for (let it = 0; it < 4; it++) for (const p of W.pl) for (const q of W.pl) {
          if (q.i <= p.i) continue;
          const d = hyp(q.x - p.x, q.y - p.y); if (d >= 1.6) continue;
          const s = snapFree(W.M, q.x + 1.7, q.y + (d < 0.1 ? 0.5 : 0)); q.x = s[0]; q.y = s[1];
        }
        emit(W, hooks, 16, 0, 0, 0, 0);
      }
      return;
    }
    if (W.ph === 1) { W.t -= h; for (const p of W.pl) p.air = Math.max(0, W.t); if (W.t <= 0) { W.ph = 2; W.T = 0; for (const p of W.pl) { p.air = 0; p.lnd = 1.2; } pickNext(W); emit(W, hooks, 21, 0, 0, 0, 0); } return; }
    if (W.ph === 3) { for (const p of W.pl) { p.vx *= 0.9; p.vy *= 0.9; } return; }
    W.T += h;
    zoneStep(W, h, hooks);
    envStep(W);
    if (W.rg) { stepTargets(W, h); if (W.pr) practiceStep(W, h, hooks); }
    else { if (W.T >= SLEEP_T) stepAnimals(W, h, hooks); redZoneStep(W, h, hooks); debrisStep(W, h, hooks); stormStep(W, h, hooks); wxStep(W, h, hooks); }
    stepVehicles(W, h, inputs, hooks);
    const dps = zoneDps(W);
    for (let d = 0; d < W.dl.length; d++) if (W.dl[d] > 0) { W.dl[d] -= h; if (W.dl[d] <= 0) { W.dl[d] = 0; W.dv++; } }
    for (let k = W.pg.length - 1; k >= 0; k--) { W.pg[k].t -= h; if (W.pg[k].t <= 0) W.pg.splice(k, 1); }
    for (const p of W.pl) {
      if (p.out) continue;
      const I = inputs[p.i] || NOIN;
      if (W.T < GO_T && !W.rg) { if (fin(I.face)) p.a = I.face; p.vx = p.vy = 0; if (I.acts) I.acts.length = 0; continue; }   // 3·2·1: look around only
      if (p.rev > 0) p.rev -= h; if (p.ft > 0) p.ft -= h; if (p.fl > 0) p.fl -= h; if (p.burn > 0) p.burn -= h;
      if (p.lnd > 0) p.lnd -= h; if (p.sb > 0) p.sb -= h; if (p.lk > 0) p.lk -= h; if (p.mf > 0) p.mf -= h; if (p.gas > 0) p.gas -= h;
      { const hw = heldGun(p); p.lit = hw && p.veh < 0 && effOf(hw).lt ? 1 : 0; }
      if (I.acts && I.acts.length) { for (const a of I.acts) doAct(W, p, a, hooks); I.acts.length = 0; }
      const w = heldGun(p);
      p.ads = I.ads && w && !p.kd && !p.swim && p.use <= 0 && p.vt <= 0 && !(p.veh >= 0 && p.seat === 0) ? 1 : 0;
      if (I.fire && p.veh < 0) p.ns = Math.max(p.ns, 0.35);    // shooting stops a sprint
      const ox = p.x, oy = p.y;
      movePlayer(W, p, I, h);
      if (p.out) continue;
      const mv = hyp(p.x - ox, p.y - oy); if (mv < 3) p.dm += mv;
      if (!p.kd && p.veh < 0 && p.vt <= 0 && (W.auto || I.auto)) { p.pk -= h; if (p.pk <= 0) { p.pk = 0.12; pickups(W, p, hooks); } }
      if (p.swim && p.stm <= 0 && !p.kd) hurt(W, p, 5 * h, -1, -7, false, hooks, true);    // out of breath in the water
      if (p.veh < 0 && W.M.lava.length && inLava(W.M, p.x, p.y)) { hurt(W, p, 18 * h, -1, -10, false, hooks, true); p.burn = 0.3; }
      if (p.out) continue;
      fireStep(W, p, I, h, hooks);
      if (p.out) continue;
      if (p.use > 0) {
        if (p.ut === 9) { const q = W.pl[p.rv]; if (!q || !q.kd || q.out || hyp(q.x - p.x, q.y - p.y) > 2.3 || p.kd) { if (q) q.rvb = 0; p.rv = -1; p.use = 0; p.ut = -1; } else q.rvb = p.use; }
        if (p.ut === 10) {
          const T = W.rt && W.rt[p.rcT];
          if (!T || p.kd || !rcOn(W) || !tagOf(W, p.i) || hyp(T.x - p.x, T.y - p.y) > RC.r + 0.6) { p.use = 0; p.ut = -1; }
          else if (Math.ceil(p.use) !== Math.ceil(p.use - h)) { W.ns.push([T.x, T.y, W.T]); emit(W, hooks, 40, T.x, T.y, p.i, 2); }   // the mast beeps every second — enemies hear it
        }
        if (p.use > 0) { p.use -= h; if (p.use <= 0) finishUse(W, p, hooks); }
      }

      if (p.kd && !(p.rvb > 0)) { p.khp -= h * (2.6 + 1.6 * (p.kn - 1)); if (p.khp <= 0) { die(W, p, p.lb, -5, hooks); continue; } }
      if (outside(W, p)) hurt(W, p, dps * h, -1, -2, false, hooks, true);
      if (p.out) continue;
      if (p.veh < 0 && !p.kd) for (const d of W.ad) if (!d.op && d.t <= 0 && hyp(d.x - p.x, d.y - p.y) < 1.6) openDrop(W, d, p, hooks);
    }
    for (const d of W.ad) if (d.t > 0) d.t -= h;
    stepTags(W, h, hooks);
    stepProj(W, h, hooks);
    if (W.ns.length) W.ns = W.ns.filter((n) => W.T - n[2] < 4);
    if (W.T > W.cap && !W.res && !W.rg) finish(W, hooks);
  }
  /* red zone: a warned circle gets bombed for a while — only roofs keep you safe */
  function redZoneStep(W, h, hooks) {
    const z = W.z;
    if (!W.rz) {
      W.rzT -= h;
      if (W.rzT > 0 || z.i >= W.ZS.length - 1 || z.r < 20) return;
      const M = W.M;
      for (let k = 0; k < 30; k++) {
        const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * z.r * 0.75, x = z.cx + Math.cos(a) * d, y = z.cy + Math.sin(a) * d;
        if (!landAt(M, x, y, 0)) continue;
        W.rz = { x: r1(x), y: r1(y), r: Math.round(Math.min(z.r * 0.45, 14 * M.f)), ph: 0, t: 10, n: 0 };
        emit(W, hooks, 25, x, y, W.rz.r, 0);
        break;
      }
      W.rzT = 90 + Math.random() * 60;
      return;
    }
    const r = W.rz; r.t -= h;
    if (r.ph === 0) { if (r.t <= 0) { r.ph = 1; r.t = 12; emit(W, hooks, 25, r.x, r.y, r.r, 1); } return; }
    r.n -= h;
    if (r.n <= 0) { r.n = 0.28; const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * r.r; explode(W, r.x + Math.cos(a) * d, r.y + Math.sin(a) * d, 3.4, 95, -1, -11, hooks, 2); }
    if (r.t <= 0) W.rz = null;
  }
  /* old factory halls: bits of the roof come down (a warning circle first) */
  function debrisStep(W, h, hooks) {
    if (!W.M.T.fact) return;
    W.dbT -= h;
    if (W.dbT <= 0) {
      W.dbT = 5 + Math.random() * 9;
      const halls = []; W.M.blds.forEach((b, j) => { if (b.k === 2) halls.push(j); });
      let pick = -1;
      for (const p of W.pl) if (!p.out && p.veh < 0) { const b = inBld(W.M, p.x, p.y); if (b >= 0 && W.M.blds[b].k === 2 && Math.random() < 0.5) { pick = b; break; } }
      if (pick < 0 && halls.length) pick = halls[Math.floor(Math.random() * halls.length)];
      if (pick >= 0) { const b = W.M.blds[pick], x = b.x0 + 1.5 + Math.random() * (b.x1 - b.x0 - 3), y = b.y0 + 1.5 + Math.random() * (b.y1 - b.y0 - 3); W.db.push({ x: r1(x), y: r1(y), r: 2.6, t: 2.6 }); if (W.db.length > 4) W.db.shift(); }
    }
    for (let k = W.db.length - 1; k >= 0; k--) {
      const d = W.db[k]; d.t -= h;
      if (d.t > 0) continue;
      W.db.splice(k, 1);
      emit(W, hooks, 30, d.x, d.y, 0, 0);
      for (const q of W.pl) if (!q.out && q.veh < 0 && q.air <= 0 && hyp(q.x - d.x, q.y - d.y) < d.r) hurt(W, q, 55, -1, -12, false, hooks);
      if (W.an) W.an.forEach((a, j) => { if (hyp(a.x - d.x, a.y - d.y) < d.r) anHurt(W, j, 55, -1, hooks); });
    }
  }
  /* desert sandstorm: everyone sees only ~20 m for half a minute */
  /* thunderstorm lightning (warning ring 1.8 s, then 40 damage in 3 m, roofs protect) · hot springs · geysers */
  function wxStep(W, h, hooks) {
    const M = W.M;
    if (W.wx === 3) {
      W.lgT -= h;
      if (W.lgT <= 0) {
        W.lgT = 3.5 + Math.random() * 5;
        const al = W.pl.filter((q) => !q.out && inBld(M, q.x, q.y) < 0), q = al.length && Math.random() < 0.55 ? al[Math.floor(Math.random() * al.length)] : null;
        const a = Math.random() * 6.283, d = q ? 1 + Math.random() * 7 : Math.random() * W.z.r;
        const x = (q ? q.x : W.z.cx) + Math.cos(a) * d, y = (q ? q.y : W.z.cy) + Math.sin(a) * d;
        if (Math.abs(x) < HL - 2 && Math.abs(y) < HL - 2) { W.lg.push({ x: r1(x), y: r1(y), r: 3, t: 1.8 }); if (W.lg.length > 4) W.lg.shift(); }
      }
    }
    for (let k = W.lg.length - 1; k >= 0; k--) {
      const d = W.lg[k]; d.t -= h; if (d.t > 0) continue;
      W.lg.splice(k, 1); emit(W, hooks, 32, d.x, d.y, 0, 0);
      for (const q of W.pl) if (!q.out && q.air <= 0 && q.veh < 0 && hyp(q.x - d.x, q.y - d.y) < d.r && inBld(M, q.x, q.y) < 0) hurt(W, q, 40, -1, -13, false, hooks);
      W.vh.forEach((v, j) => { if (v.hp > 0 && hyp(v.x - d.x, v.y - d.y) < d.r + VEH[v.ty].r) vehDmg(W, j, 30, -1, hooks); });
      if (W.an) W.an.forEach((a, j) => { if (a.hp > 0 && hyp(a.x - d.x, a.y - d.y) < d.r) anHurt(W, j, 40, -1, hooks); });
    }
    if (M.hsp.length) for (const q of W.pl) if (!q.out && !q.kd && q.veh < 0 && q.hp < 75 && inHsp(M, q.x, q.y)) q.hp = Math.min(75, q.hp + 2.5 * h);
    if (M.gy.length) M.gy.forEach((g, k) => {
      const u = gyU(W, k), u0 = u - h; if (!(u0 < GY_E && u >= GY_E)) return;
      emit(W, hooks, 33, g[0], g[1], 0, 0);
      for (const q of W.pl) {
        if (q.out || q.air > 0 || q.veh >= 0) continue; const dx = q.x - g[0], dy = q.y - g[1], dd = hyp(dx, dy);
        if (dd < g[2]) { hurt(W, q, 30, -1, -14, false, hooks); const n = dd || 1; q.vx += dx / n * 9; q.vy += dy / n * 9; }
      }
      W.vh.forEach((v, j) => { if (v.hp > 0 && hyp(v.x - g[0], v.y - g[1]) < g[2] + VEH[v.ty].r) { vehDmg(W, j, 25, -1, hooks); v.v *= 0.3; } });
    });
  }
  function stormStep(W, h, hooks) {
    if (!W.M.T.storm) return;
    if (W.ss > 0) { W.ss -= h; if (W.ss <= 0) W.ss = 0; return; }
    W.ssT -= h;
    if (W.ssT <= 0) { W.ss = 30; W.ssT = 110 + Math.random() * 50; emit(W, hooks, 31, 0, 0, 0, 0); }
  }
  function tickWorld(W, dt, inputs, hooks) {
    W.hk = hooks; useMap(W.M);
    if (!(dt > 0)) return;
    const n = Math.min(14, Math.max(1, Math.ceil(dt / SUB - 1e-6))), h = dt / n;
    for (let i = 0; i < n; i++) stepWorld(W, h, inputs, hooks);
  }
  /* ======================= AI ======================= */
  function fitOf(c, d) {
    switch (c) {
      case 0: return d < 15 ? 0.6 : 0.3;
      case 1: return d < 20 ? 1.15 : d < 40 ? 0.7 : 0.3;
      case 2: return d < 8 ? 0.85 : d < 60 ? 1 : 0.6;
      case 3: return d < 7 ? 1.5 : d < 13 ? 0.6 : 0.05;
      case 4: return d < 15 ? 0.6 : 1.05;
      case 5: return d < 20 ? 0.35 : 1.15;
      case 6: return d < 60 ? 1 : 0.6;
      case 8: return 0.05;
      case 9: return d < 7 ? 0.15 : d < 45 ? 1.2 : 0.5;
      default: return d < 40 ? 0.6 : 0.3;
    }
  }
  function lootVal(p, t, n) {
    const k = ikind(t);
    if (k === 'g') {
      const G = GUN[t];
      if (G.c === 8) return p.g[2] ? 0 : 0.6;
      if (G.c === 0) return p.g[2] ? 0 : 1.5;
      const sv = G.v * (p.snip && (G.c === 4 || G.c === 5) ? 1.4 : 1);
      if (!p.g[0] || !p.g[1]) return sv * (p.am[G.am] > 0 ? 1 : 0.8);
      const worst = Math.min(gunVal(p, p.g[0]), gunVal(p, p.g[1]));
      return sv - worst > 1 ? sv - worst : 0;
    }
    if (k === 'o') { const j = t - I_AMMO; if (roomFor(p, t) <= 0) return 0; return usesAmmo(p, j) ? (p.am[j] < 40 ? 3 : p.am[j] < 150 ? 1 : 0) : 0; }
    if (k === 'h') { const j = t - I_HEAL; return p.hl[j] < HLIM[j] && roomFor(p, t) > 0 ? [1.6, 2.2, 2.6, 1.0, 0.9][j] : 0; }
    if (k === 't') { const j = t - I_THR; return p.th[j] < 3 && roomFor(p, t) > 0 ? 1 : 0; }
    if (k === 'v') return t - I_VEST + 1 > p.vs ? 3 * (t - I_VEST + 1 - p.vs) : 0;
    if (k === 'e') return t - I_HELM + 1 > p.hm ? 2.5 * (t - I_HELM + 1 - p.hm) : 0;
    if (k === 'b') return t - I_BAG + 1 > p.bp ? 1.5 : 0;
    if (k === 'a') { const ai = t - I_ATT; return p.g.some((w) => w && attBetter(w, ai)) ? 0.8 + attScore(ATT[ai]) * 0.2 : 0; }
    if (k === 's') return p.spc ? 0 : 1.2;
    if (k === 'm') return p.ml < 0 ? 0.6 : 0;
    return 0;
  }
  function aiLand(W, p, lv) {
    const M = W.M;
    const mate = W.tm ? W.pl.find((q) => q.tm === p.tm && q.i < p.i && fin(q.lx)) : null;
    if (mate) return [mate.lx + 2.5, mate.ly + 1];
    const crowd = (x, y, r) => { let n = 0; for (const q of W.pl) if (q !== p && fin(q.lx) && hyp(q.lx - x, q.ly - y) < r) n++; return n; };
    const near = (x, y, r) => { let n = 0; for (const q of W.pl) if (q !== p && fin(q.lx)) n += Math.max(0, r - hyp(q.lx - x, q.ly - y)); return n; };
    const nt = W.tm ? Math.ceil(W.pl.length / 2) : W.pl.length, PP = PERS[p.ty || 0] || PERS[0];
    const Rr = M.base * (M.T.sh === 'long' ? 1.1 : 0.95), cr0 = Math.min(M.base * 0.72, 0.95 * Math.sqrt(Math.PI * M.base * M.base / nt)) * (PP.avoid ? 1.2 : PP.hunt ? 0.6 : 1);
    const randLand = () => { for (let k = 0; k < 120; k++) { const a = Math.random() * 6.283, d = Math.sqrt(Math.random()) * Rr, x = Math.cos(a) * d, y = Math.sin(a) * d; if (landAt(M, x, y, 2) && (k > 100 || !crowd(x, y, cr0 - k * cr0 / 150))) return [x, y]; } return [0, 0]; };
    if (lv === 1 || !M.blds.length || (lv === 2 && Math.random() < 0.3) || PP.camp >= 1 && Math.random() < 0.4) return randLand();
    let best = null, bs = -1e9;
    M.blds.forEach((b) => {
      const cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2;
      let s = 0;
      s += b.ls;
      s -= near(cx, cy, cr0) * (lv === 3 ? 2.5 : 1.6) * (PP.hunt ? 0.3 : 1);
      s += Math.random() * (lv === 3 ? 3 : 6);
      if (s > bs) { bs = s; best = [cx, cy]; }
    });
    return best || randLand();
  }
  function aiSteer(W, p, Mm, gx, gy) {
    const M = W.M;
    let tx = gx, ty = gy;
    const bg = inBld(M, gx, gy), bp = inBld(M, p.x, p.y);
    if (bg !== bp) {
      const b = M.blds[bp >= 0 ? bp : bg];
      let dr = null, dd = 1e9;
      for (const d of b.doors) { const e = hyp(d[0] - p.x, d[1] - p.y) + hyp(d[0] - gx, d[1] - gy) * 0.3; if (e < dd) { dd = e; dr = d; } }
      if (dr) {
        const ox = dr[0] + dr[2] * 1.7, oy = dr[1] + dr[3] * 1.7, ix = dr[0] - dr[2] * 1.7, iy = dr[1] - dr[3] * 1.7;
        const along = (p.x - dr[0]) * dr[2] + (p.y - dr[1]) * dr[3], side = Math.abs((p.x - dr[0]) * dr[3] - (p.y - dr[1]) * dr[2]);
        if (bp < 0) { if (along > 0.6 && side < 0.7) { tx = ix; ty = iy; } else { tx = ox; ty = oy; } }
        else if (side < 0.7) { tx = ox; ty = oy; } else { tx = ix; ty = iy; }
      }
    }
    const d = hyp(tx - p.x, ty - p.y);
    if (d < 0.25) return [0, 0];
    if (Mm.un > 0) return [Math.cos(Mm.ua), Math.sin(Mm.ua)];
    const base = Math.atan2(ty - p.y, tx - p.x), sd = Mm.side || 1;
    for (const k of [0, 0.45, -0.45, 0.9, -0.9, 1.4, -1.4, 2.0, -2.0, 2.6, -2.6]) {
      const a = base + k * sd, c = Math.cos(a), s = Math.sin(a);
      if (!solidAt(M, p.x + c * 1.0, p.y + s * 1.0, PR * 0.95, 2) && !solidAt(M, p.x + c * 1.9, p.y + s * 1.9, PR * 0.95, 2) && !(M.lava.length && inLava(M, p.x + c * 1.6, p.y + s * 1.6))) {
        const m = Math.min(1, d / 0.8);
        return [c * m, s * m];
      }
    }
    return [Math.cos(base), Math.sin(base)];
  }
  function aiDrive(W, p, Mm, out) {
    const v = W.vh[p.veh], V = VEH[v.ty], M = W.M, z = W.z;
    const roam = PERS[p.ty || 0].roam;
    if (roam && !Mm.dg) { const a = Math.random() * 6.283, r = Math.sqrt(Math.random()) * Math.max(4, (z.i < W.ZS.length ? z.nr : z.r) * 0.8); Mm.dg = [(z.i < W.ZS.length ? z.nx : z.cx) + Math.cos(a) * r, (z.i < W.ZS.length ? z.ny : z.cy) + Math.sin(a) * r]; }
    const gx = Mm.dg ? Mm.dg[0] : z.nx, gy = Mm.dg ? Mm.dg[1] : z.ny;
    const d = hyp(gx - v.x, gy - v.y);
    if (roam && d < 6 && Mm.dst < 1.6 && v.hp > VEH[v.ty].hp * 0.3 && Math.random() < 0.7) { Mm.dg = null; return; }
    Mm.dst = (Mm.dst || 0) + (Math.abs(v.v) < 1 ? curDtAI : -curDtAI * 2); if (Mm.dst < 0) Mm.dst = 0;
    const seen = W.pl.some((q) => !q.out && q.tm !== p.tm && hyp(q.x - p.x, q.y - p.y) < 22 && canSee(W, p, q));
    if (d < (Mm.dg ? 4 : Math.max(6, z.nr * 0.5)) || Mm.dst > 3.2 || (seen && Math.abs(v.v) < 8) || v.hp < VEH[v.ty].hp * (Mm.lv3 ? 0.45 : 0.3)) { out.acts.push([2, 1]); Mm.dg = null; Mm.dst = 0; Mm.vcd = W.T + 12; return; }
    if (V.ped && p.stm > 30) out.sp = 1;
    let base = Math.atan2(gy - v.y, gx - v.x), pick = base;
    const ok = (a, dd) => { const x = v.x + Math.cos(a) * dd, y = v.y + Math.sin(a) * dd; return !solidAt(M, x, y, V.r) && (V.land ? !isWater(M, x, y) : isWater(M, x, y)); };
    // stuck nose-first against something: back off for a moment with the wheel turned, then try again (was: just got out)
    if (Mm.dst > 0.7 && !(Mm.rvT > W.T) && !(Mm.rvC > W.T)) { Mm.rvT = W.T + 1.1; Mm.rvC = W.T + 2.6; Mm.rvS = Math.random() < 0.5 ? 1 : -1; }
    if (Mm.rvT > W.T) { const a = v.a + Math.PI + 0.6 * Mm.rvS; out.ax = Math.cos(a); out.ay = Math.sin(a); return; }
    const look = 3 + Math.abs(v.v) * 0.45;
    for (const k of [0, 0.3, -0.3, 0.6, -0.6, 0.95, -0.95, 1.35, -1.35, 1.9, -1.9, 2.5, -2.5]) { const a = base + k; if (ok(a, look * 0.5) && ok(a, look)) { pick = a; break; } }
    // ease off for sharp turns and near the goal
    const turn = Math.abs(wrapA(pick - v.a)), slow = Math.min(1, d / 14) * (turn > 0.9 && Math.abs(v.v) > V.vmax * 0.5 ? 0.55 : 1);
    out.ax = Math.cos(pick) * Math.max(0.45, slow); out.ay = Math.sin(pick) * Math.max(0.45, slow);
  }
  /* a spot within ~6 m that the target cannot see (cached for a moment) */
  function aiCover(W, p, Mm, q, lv) {
    const M = W.M;
    if (Mm.cov && Mm.covT > W.T && !los(M, q.x, q.y, Mm.cov[0], Mm.cov[1])) return Mm.cov;
    let best = null, bd = 1e9;
    const R = lv === 3 ? [1.6, 3, 4.6, 6.2] : [2, 4];
    for (const r of R) for (let k = 0; k < 12; k++) {
      const a = k / 12 * 6.283, x = p.x + Math.cos(a) * r, y = p.y + Math.sin(a) * r;
      if (!okSpot(M, x, y) || los(M, q.x, q.y, x, y) || !los(M, p.x, p.y, x, y)) continue;
      const s = r - hyp(x - q.x, y - q.y) * 0.15; if (s < bd) { bd = s; best = [x, y]; }
    }
    Mm.cov = best; Mm.covT = W.T + (best ? 1.5 : 0.6);
    return best;
  }
  let curDtAI = 0;
  function aiPlan(W, p, Mm, lv, A) {
    const z = W.z, acts = Mm.acts;
    const w0 = heldGun(p), sc = w0 ? scW(w0) : 0;
    // early on bots mostly loot: they only notice people who are close (or shooting at them)
    const PP = PERS[p.ty || 0] || PERS[0];
    const early = W.T < (110 + (3 - lv) * 20) * PP.early, hitMe = W.T - p.lbT < 3, calm0 = W.T < CALM_T && !hitMe;
    const sight = p.fl > 0 ? 3 : early && !hitMe ? 12 : Math.max(A.sight, lv === 3 && w0 ? SIGHT[sc] * 0.75 : 0);
    // target
    let best = -1, bs = 1e9;
    for (const q of W.pl) {
      if (q.out || q.air > 0 || q.tm === p.tm) continue;
      const d = hyp(q.x - p.x, q.y - p.y);
      if (calm0 || d > sight || !canSee(W, p, q)) continue;
      // people far away are not always noticed (moving/shooting ones more easily)
      if (q.i !== Mm.tg && d > 9 && !hitMe && Math.random() > (q.rev > 0 ? 0.4 : q.sx ? 0.22 : hyp(q.vx, q.vy) > 1 ? (q.cr ? 0.05 : 0.12) : q.cr ? 0.03 : 0.05) * (lv === 3 ? 1.3 : lv === 1 ? 0.7 : 1) * PP.notice) continue;
      if (q.kd && !(d < 10 && Math.random() < A.fin) && W.pl.some((o) => !o.out && !o.kd && o.tm !== p.tm && o !== q && hyp(o.x - p.x, o.y - p.y) < sight)) continue;
      const s = d + (q.kd ? 6 : 0) - (lv === 3 ? (100 - q.hp) * 0.05 : 0) + (q.i === Mm.tg ? -3 : 0);
      if (s < bs) { bs = s; best = q.i; }
    }
    if (best !== Mm.tg) { Mm.react = best >= 0 ? A.react * (0.7 + Math.random() * 0.6) : 0; Mm.tg = best; Mm.sd = Math.random() < 0.5 ? 1 : -1; }
    if (best >= 0) Mm.seenT = W.T;
    const tq = best >= 0 ? W.pl[best] : null, td = tq ? hyp(tq.x - p.x, tq.y - p.y) : 99;
    Mm.flee = tq && p.hp < 30 && lv >= 2 && Math.random() < A.flee ? 1 : 0;
    // careful bots slip away from fights they did not start
    Mm.avoid = tq && !hitMe && td > 12 && !tq.kd && Math.random() < PP.avoid * 0.85 ? 1 : 0;
    if (Mm.avoid) Mm.flee = 1;
    if (Math.random() < 0.2) Mm.sd = -Mm.sd;
    if (p.veh >= 0) return;
    // weapon choice (unless about to throw)
    if (!(Mm.thr > W.T)) {
      let bsl = p.sl, bv = -1e9;
      for (const s of [0, 1, 2]) {
        const w = p.g[s]; if (!w) continue;
        const G = GUN[w.t]; if (w.m + p.am[G.am] <= 0) continue;
        const v = G.c === 8 ? 0 : (tq ? fitOf(G.c, td) * G.v : G.v * (s === 2 ? 0.4 : 1)) * (PP.snip && (G.c === 4 || G.c === 5) ? 1.4 : 1) + (s === p.sl ? 0.4 : 0);
        if (v > bv) { bv = v; bsl = s; }
      }
      if (bv === -1e9) bsl = 3;
      if (bsl !== p.sl && (lv >= 2 || p.sl >= 3 || !p.g[p.sl] || Math.random() < 0.3)) acts.push(4 + bsl);
    }
    const w = heldGun(p);
    if (w && !tq && w.m < magW(w) * 0.6 && p.am[GUN[w.t].am] > 0 && p.rl <= 0) acts.push(1);
    // heal when it's calm
    const calm = W.T - (Mm.seenT || -99) > 2.5 && W.T - p.lbT > 2.5;
    if (p.use <= 0 && calm && (p.hp < 75 || p.stm < 40) && Math.random() < A.heal && healPick(p) >= 0) acts.push(3);
    // inventory: attach loose attachments, drop ammo nobody uses when the bag is full
    if (lv >= 2 && Math.random() < 0.3) for (let ai = 0; ai < ATT.length; ai++) if (p.at[ai] > 0 && p.g.some((g) => g && attBetter(g, ai))) { acts.push([55, ai, -1]); break; }
    if (wtOf(p) > capOf(p) - 10 && Math.random() < 0.3) { const j = p.am.findIndex((n, k) => n > 0 && !usesAmmo(p, k)); if (j >= 0) acts.push([51, I_AMMO + j, 0]); }
    // doors: shut (and on 어려움 lock) the door of the building I hide in when someone comes
    const bIn = p.veh < 0 ? inBld(W.M, p.x, p.y) : -1;
    if (lv >= 2 && bIn >= 0 && !Mm.urg) {
      const d = nearDoor(W, p, DOOR_R);
      if (d >= 0 && W.M.doors[d].b === bIn) {
        const near = tq && td < 22;
        if (W.ds[d] && (Mm.camp > W.T || near) && Math.random() < 0.6 && !doorBlocked(W, d)) acts.push([2, 3, d]);
        else if (!W.ds[d] && lv === 3 && near && canLock(W, p, d) && Math.random() < 0.5) acts.push([44, d]);
      }
    }
    if (lv === 1 && p.use <= 0 && p.hp < 40 && Math.random() < 0.15 && healPick(p) >= 0) acts.push(3);
    // throwables
    if (tq && lv >= 2 && !tq.kd && p.use <= 0 && !(Mm.thr > W.T)) {
      const boom = [0, 9, 6, 4, 3].find((t) => p.th[t] > 0);
      if (td > 8 && td < 24 && boom != null && Math.random() < A.nade * 0.14) { acts.push(10 + boom); Mm.thr = W.T + 1.2; }
      else if (td > 8 && td < 20 && p.th[8] > 0 && Math.random() < A.nade * 0.05) { acts.push(18); Mm.thr = W.T + 1.2; }
      else if (lv === 3 && p.hp < 40 && p.th[1] > 0 && Math.random() < 0.25) { acts.push(11); Mm.thr = W.T + 1.2; Mm.smk = 1; }
      else if (td < 14 && p.th[2] > 0 && Math.random() < A.nade * 0.06) { acts.push(12); Mm.thr = W.T + 1.2; }
    }
    // swap a better gun on the ground
    if (Math.random() < A.pick) { const c = swapCand(W, p); if (c) { const worst = GUN[c.t].c === 0 ? gunVal(p, p.g[2]) : Math.min(gunVal(p, p.g[0]), gunVal(p, p.g[1])); if (GUN[c.t].v > worst + 0.8) acts.push([50, c.t, Math.round(c.x * 10), Math.round(c.y * 10)]); } }
    // where to go
    const dz = hyp(p.x - z.cx, p.y - z.cy), ZS = W.ZS;
    Mm.goal = null; Mm.urg = 0;
    const tw = (cx, cy, rr) => { const d = hyp(p.x - cx, p.y - cy); if (d < 1e-3) return [cx, cy]; const k = Math.min(1, rr / d); return [cx + (p.x - cx) * k, cy + (p.y - cy) * k]; };
    // revive a knocked teammate
    if (W.tm) { const mate = W.pl.find((q) => q.tm === p.tm && q !== p && q.kd && !q.out); if (mate && (!tq || td > 18)) { const d = hyp(mate.x - p.x, mate.y - p.y); if (d < 1.7) { if (p.ut !== 9) acts.push([2, 2, mate.i]); Mm.goal = [p.x, p.y]; } else Mm.goal = [mate.x, mate.y]; Mm.urg = 1; return; } }
    // 귀환: carry a fallen teammate's 인식표 to a 송신탑 (most bots bother; easy ones less often)
    if (W.dg && W.dg.length && rcOn(W) && p.veh < 0 && (!tq || td > 25)) {
      if (Mm.rcw == null) Mm.rcw = Math.random() < (lv === 1 ? 0.5 : lv === 2 ? 0.75 : 0.9);
      const held = tagOf(W, p.i);
      if (held) {
        let bj = -1, bd = 1e9;
        W.rt.forEach((T, j) => { const d = hyp(T.x - p.x, T.y - p.y) + (hyp(T.x - z.cx, T.y - z.cy) > z.r - 4 ? 400 : 0); if (d < bd) { bd = d; bj = j; } });
        if (bj >= 0) {
          const T = W.rt[bj], d = hyp(T.x - p.x, T.y - p.y);
          if (d < RC.r - 0.8) { if (p.ut !== 10) acts.push([2, 7, bj]); Mm.goal = [p.x, p.y]; } else Mm.goal = [T.x, T.y];
          Mm.urg = 1; return;
        }
      } else if (Mm.rcw) {
        const g = W.dg.find((e) => e.by < 0 && W.pl[e.i].tm === p.tm && hyp(e.x - p.x, e.y - p.y) < 110 && hyp(e.x - z.cx, e.y - z.cy) < z.r + 10);
        if (g) { Mm.goal = [g.x, g.y]; Mm.urg = 1; return; }
      }
    }
    const farZone = z.i < ZS.length ? hyp(p.x - z.nx, p.y - z.ny) - z.nr : dz - z.r;
    if ((lv >= 2 || PP.roam) && Math.random() < Math.max(A.veh, PP.veh) && (farZone > 30 || PP.roam) && !tq && !(Mm.vcd > W.T)) {
      let bj = -1, bd = PP.roam ? 60 : 30;
      W.vh.forEach((v, j) => { if (v.hp <= 0 || freeSeat(W, j) !== 0 || VEH[v.ty].land !== 1) return; const d = hyp(v.x - p.x, v.y - p.y); if (d < bd) { bd = d; bj = j; } });
      if (bj >= 0) { Mm.goal = [W.vh[bj].x, W.vh[bj].y]; Mm.urg = 1; if (bd < VEH[W.vh[bj].ty].r + 1.5) acts.push([2, 6, bj]); return; }
    }
    // red zone / falling roof: get under a roof or out of the circle
    const rz = W.rz, inB = inBld(W.M, p.x, p.y) >= 0;
    let dbz = W.db.find((d) => hyp(d.x - p.x, d.y - p.y) < d.r + 1) || W.lg.find((d) => hyp(d.x - p.x, d.y - p.y) < d.r + 1.5);
    if (!dbz && W.M.gy.length) { const k = W.M.gy.findIndex((g, i) => gyU(W, i) > GY_W - 0.5 && hyp(g[0] - p.x, g[1] - p.y) < g[2] + 1.5); if (k >= 0) dbz = { x: W.M.gy[k][0], y: W.M.gy[k][1] }; }
    if (dbz && lv < 2 && !W.db.includes(dbz) && Math.random() < 0.6) { const d = hyp(p.x - dbz.x, p.y - dbz.y) || 1; Mm.goal = [dbz.x + (p.x - dbz.x) / d * 5, dbz.y + (p.y - dbz.y) / d * 5]; Mm.urg = 1; return; }
    if (dbz && lv >= 2) { const d = hyp(p.x - dbz.x, p.y - dbz.y) || 1; Mm.goal = [dbz.x + (p.x - dbz.x) / d * 5, dbz.y + (p.y - dbz.y) / d * 5]; Mm.urg = 1; return; }
    if (rz && !inB && lv >= 2 && hyp(p.x - rz.x, p.y - rz.y) < rz.r + 3) {
      let bb = null, bd = 18; for (const b of W.M.blds) { const x = (b.x0 + b.x1) / 2, y = (b.y0 + b.y1) / 2, d = hyp(x - p.x, y - p.y); if (d < bd) { bd = d; bb = [x, y]; } }
      if (bb) Mm.goal = bb; else { const d = hyp(p.x - rz.x, p.y - rz.y) || 1; Mm.goal = [rz.x + (p.x - rz.x) / d * (rz.r + 6), rz.y + (p.y - rz.y) / d * (rz.r + 6)]; }
      Mm.urg = 1; return;
    }
    if (dz > z.r - 2) { Mm.goal = tw(z.cx, z.cy, Math.max(0, z.r * 0.5)); Mm.urg = 1; }
    else if (A.zone > 0 && z.i < ZS.length && (z.s === 1 || z.t < 35 * A.zone) && hyp(p.x - z.nx, p.y - z.ny) > z.nr * 0.85) { Mm.goal = tw(z.nx, z.ny, z.nr * 0.55); Mm.urg = 1; }
    else {
      let bl = null, bv = 0;
      eachLoot(W, p.x, p.y, W.T < 75 ? Math.min(A.loot, 11) : A.loot, (l) => {
        if (hyp(l.x - z.cx, l.y - z.cy) > z.r - 1) return false;
        if (l.by === p.i) return false;
        const v = lootVal(p, l.t, l.n); if (v <= 0.3) return false;
        const sc2 = v / (3 + hyp(l.x - p.x, l.y - p.y));
        if (sc2 > bv) { bv = sc2; bl = l; }
        return false;
      });
      for (const d of W.ad) if (!d.op && d.t <= 0 && lv === 3 && hyp(d.x - p.x, d.y - p.y) < A.loot * 1.4) { bl = d; break; }
      const armed = p.g[0] || p.g[1];
      if (bl) { Mm.goal = [bl.x, bl.y]; Mm.camp = 0; }
      else if (Mm.camp > W.T && Mm.cx != null && hyp(Mm.cx - z.cx, Mm.cy - z.cy) < z.r - 2) Mm.goal = [Mm.cx, Mm.cy];
      else if (armed && Math.random() < PP.camp * (lv === 1 ? 0.7 : 1) && pickCamp(W, p, Mm, lv)) Mm.goal = [Mm.cx, Mm.cy];
      else {
        // gunfire somewhere near (even a decoy): curious or aggressive bots go and look
        const nz = armed && lv >= 2 && W.ns.length ? W.ns.find((n) => hyp(n[0] - p.x, n[1] - p.y) < (W.wx === 1 || W.wx === 3 ? 32 : 45) && hyp(n[0] - z.cx, n[1] - z.cy) < z.r) : null;
        if (nz && (PP.hunt || Math.random() < 0.25) && !Mm.nzT) { Mm.wx = nz[0]; Mm.wy = nz[1]; Mm.nzT = 1; }
        if (Mm.nzT && hyp(Mm.wx - p.x, Mm.wy - p.y) < 3) Mm.nzT = 0;
        if (!Mm.wx || hyp(Mm.wx - p.x, Mm.wy - p.y) < 2 || Math.random() < 0.04 || hyp(Mm.wx - z.cx, Mm.wy - z.cy) > z.r) {
          const useN = lv >= 2 && z.i < ZS.length, cx = useN ? z.nx : z.cx, cy = useN ? z.ny : z.cy, cr = Math.max(1.5, (useN ? z.nr : z.r) - 2);
          // armed bots drift toward the centre of the action
          const hunt = armed && (z.i >= 3 || (PP.hunt && W.T > 40)) ? 0.35 + lv * 0.1 + PP.hunt * 0.4 : 0;
          for (let k = 0; k < 24; k++) {
            const a = Math.random() * 6.283, d = 6 + Math.random() * 16;
            let x = p.x + Math.cos(a) * d + (cx - p.x) * hunt * 0.3, y = p.y + Math.sin(a) * d + (cy - p.y) * hunt * 0.3;
            const e = hyp(x - cx, y - cy); if (e > cr) { x = cx + (x - cx) * cr / e; y = cy + (y - cy) * cr / e; }
            if (landAt(W.M, x, y, 0.5) || k === 23) { Mm.wx = x; Mm.wy = y; break; }
          }
        }
        Mm.goal = [Mm.wx, Mm.wy];
      }
    }
  }
  function pickCamp(W, p, Mm, lv) {
    const z = W.z, M = W.M, useN = lv >= 2 && z.i < W.ZS.length, cx = useN ? z.nx : z.cx, cy = useN ? z.ny : z.cy, cr = (useN ? z.nr : z.r) - 1.5;
    let best = null, bd = 1e9;
    for (const b of M.bush) { if (Math.abs(b[0] - p.x) > 26 || Math.abs(b[1] - p.y) > 26 || hyp(b[0] - cx, b[1] - cy) > cr) continue; const d = hyp(b[0] - p.x, b[1] - p.y) + Math.random() * 6; if (d < bd && d < 26) { bd = d; best = [b[0], b[1]]; } }
    if (lv >= 2) for (const b of M.blds) { const x = (b.x0 + b.x1) / 2, y = (b.y0 + b.y1) / 2; if (hyp(x - cx, y - cy) > cr) continue; const d = hyp(x - p.x, y - p.y) + 3 + Math.random() * 6; if (d < bd && d < 26) { bd = d; best = [x + (Math.random() - 0.5) * 2, y + (Math.random() - 0.5) * 2]; } }
    if (!best) return false;
    Mm.cx = best[0]; Mm.cy = best[1]; Mm.camp = W.T + (20 + Math.random() * (lv === 1 ? 15 : 40)) * (PERS[p.ty || 0] || PERS[0]).campT;
    return true;
  }
  function aiThink(W, p, Mm, lv, dt) {
    const A = AID[lv] || AID[2], out = { ax: 0, ay: 0, fire: 0, aim: null, ad: null, acts: [], spd: A.spd, land: null, ads: 0, mag: 0, sp: 0, auto: 1 };
    if (Mm.ty == null) { Mm.ty = rollPers(); }
    Mm.lv3 = lv === 3;
    p.ty = Mm.ty; p.snip = PERS[Mm.ty].snip;
    const PP = PERS[Mm.ty];
    if (W.ph === 0) {
      if (!Mm.land) { Mm.land = aiLand(W, p, lv); p.lx = Mm.land[0]; p.ly = Mm.land[1]; }
      out.land = Mm.land; return out;
    }
    if (W.ph !== 2 || p.out || W.rg) return out;
    curDtAI = dt;
    if (!Mm.acts) Mm.acts = [];
    Mm.tt = (Mm.tt || 0) - dt;
    if (Mm.tt <= 0) { Mm.tt = A.think * (0.7 + Math.random() * 0.6); aiPlan(W, p, Mm, lv, A); }
    if (Mm.acts.length) { out.acts = Mm.acts.slice(); Mm.acts.length = 0; }
    let q = Mm.tg >= 0 ? W.pl[Mm.tg] : null;
    if (q && (q.out || q.air > 0 || q.tm === p.tm)) { q = null; Mm.tg = -1; }
    // knocked: crawl to a standing teammate, or away from the shooter
    if (p.kd) {
      const mate = W.pl.find((o) => o.tm === p.tm && o !== p && !o.out && !o.kd);
      if (mate && hyp(mate.x - p.x, mate.y - p.y) > 1.2) { const g = aiSteer(W, p, Mm, mate.x, mate.y); out.ax = g[0]; out.ay = g[1]; }
      else if (q) { const d = hyp(q.x - p.x, q.y - p.y) || 1; out.ax = (p.x - q.x) / d; out.ay = (p.y - q.y) / d; }
      return out;
    }
    if (p.veh >= 0) {
      if (p.seat === 0) { aiDrive(W, p, Mm, out); return out; }
      const dv = W.pl.find((o) => !o.out && o.veh === p.veh && o.seat === 0);
      if (!dv) { out.acts.push([2, 1]); return out; }
    }
    // stuck check
    Mm.sT = (Mm.sT || 0) + dt;
    if (Mm.un > 0) Mm.un -= dt;
    if (Mm.sT > 0.8) {
      const mv = hyp(p.x - (Mm.lx || 0), p.y - (Mm.ly || 0));
      if (mv < 0.5 && Mm.want && p.use <= 0) {
        // stuck at a window? climb through it when the goal is on the other side
        const wi = lv >= 2 && Mm.goal ? nearWin(W, p, WIN_R) : -1;
        if (wi >= 0) { const D = W.M.wins[wi], a = (p.x - D.x) * D.nx + (p.y - D.y) * D.ny, b = (Mm.goal[0] - D.x) * D.nx + (Mm.goal[1] - D.y) * D.ny; if (a * b < 0) out.acts.push([2, 5, wi]); }
        Mm.un = 0.6; Mm.ua = Math.random() * 6.283; Mm.side = -(Mm.side || 1);
      }
      Mm.lx = p.x; Mm.ly = p.y; Mm.sT = 0;
    }
    const w = heldGun(p), G = w ? GUN[w.t] : null, C = G ? CLS[G.c] : null;
    let mv = null, eng = false;
    if (q && !Mm.urg) {
      const d = hyp(q.x - p.x, q.y - p.y), hitMe = p.lb === q.i && W.T - p.lbT < 3;
      eng = hitMe || (w && d <= G.er * (G.c >= 4 ? 1 : 1.2) * PP.eng && !Mm.avoid) || (!w && d < 6) || p.sl === 4;
    }
    if (eng && p.veh < 0) {
      const dx = q.x - p.x, dy = q.y - p.y, d = hyp(dx, dy) || 1e-3, ux = dx / d, uy = dy / d;
      const want = !w ? 1 : [7, 8, 22, 4, 36, 50, 24, 28][G.c] * (PP.snip ? 1.3 : PP.hunt ? 0.75 : 1);
      let mx = 0, my = 0;
      // cover (normal/hard): reloading, empty or hurt → step behind the nearest wall/tree that breaks the line to the target,
      // heal there (hard), then peek back out when ready. Only uses the target it actually saw (no wallhack).
      const needCov = lv >= 2 && w && !q.kd && (p.rl > 0 || w.m <= 0 || p.use > 0 || p.hp < (lv === 3 ? 55 : 35));
      const cov = needCov ? aiCover(W, p, Mm, q, lv) : null;
      if (cov) {
        const cd = hyp(cov[0] - p.x, cov[1] - p.y);
        if (cd > 0.4) { const g = aiSteer(W, p, Mm, cov[0], cov[1]); mx = g[0]; my = g[1]; if (cd > 2.5) out.sp = 1; }
        else if (lv === 3 && p.use <= 0 && p.rl <= 0 && p.hp < 70 && !los(W.M, p.x, p.y, q.x, q.y) && healPick(p) >= 0 && !(Mm.chT > W.T)) { out.acts.push(3); Mm.chT = W.T + 1; }
        mv = [mx, my]; Mm.inCov = 1;
      }
      else if (Mm.flee || Mm.smk) { mx = -ux; my = -uy; if (Mm.smk && W.T > (Mm.thr || 0) + 3) Mm.smk = 0; }
      else if (d > want) {
        // teammates on the same target spread out and come from different sides (flank)
        let fx = q.x, fy = q.y;
        if (lv >= 2 && d > 8) { const k = W.pl.filter((o) => o.tm === p.tm && !o.out && !o.kd && o.i < p.i).length; if (k > 0) { const s = (k % 2 ? 1 : -1) * (lv === 3 ? 0.9 : 0.55), ba = Math.atan2(p.y - q.y, p.x - q.x) + s; fx = q.x + Math.cos(ba) * want * 0.8; fy = q.y + Math.sin(ba) * want * 0.8; } }
        const g = aiSteer(W, p, Mm, fx, fy); mx = g[0]; my = g[1];
      }
      else if (d < want * 0.5) { mx = -ux * 0.7; my = -uy * 0.7; }
      if (!cov) Mm.inCov = 0;
      // hard: hitscan bullets can't be dodged, so at range it plants its feet (moving widens its own spread); strafes only up close
      if (A.strafe && !Mm.flee && !cov && !(lv === 3 && w && d > 9 && G.c !== 3)) { const s = (Mm.sd || 1) * A.strafe * 0.8; mx += -uy * s; my += ux * s; }
      mv = [mx, my];
    } else if (Mm.goal && p.veh < 0) mv = aiSteer(W, p, Mm, Mm.goal[0], Mm.goal[1]);
    if (mv) { out.ax = mv[0]; out.ay = mv[1]; }
    // hazards it can see: step out of fire, keep clear of a wild animal's ground (hard)
    if (lv >= 2 && p.veh < 0) {
      let rx = 0, ry = 0;
      for (const r of W.ar) if (r.k === 1) { const d = hyp(p.x - r.x, p.y - r.y); if (d < 4.4) { rx += (p.x - r.x) / (d || 1) * 2; ry += (p.y - r.y) / (d || 1) * 2; } }
      if (lv === 3) for (const a of W.an) { if (a.hp <= 0 || a.tg >= 0 || ANI[a.k].wet === 2) continue; const d = hyp(p.x - a.x, p.y - a.y), R = ANI[a.k].ag + 3; if (d < R && inCone(p, a.x, a.y) && los(W.M, p.x, p.y, a.x, a.y)) { const k = (R - d) / R * 1.5; rx += (p.x - a.x) / (d || 1) * k; ry += (p.y - a.y) / (d || 1) * k; } }
      if (rx || ry) { out.ax += rx; out.ay += ry; const m = hyp(out.ax, out.ay); if (m > 1) { out.ax /= m; out.ay /= m; } }
    }
    Mm.want = hyp(out.ax, out.ay) > 0.3;
    // where the eyes point (the field of view is a cone): a known target, an attacker after a moment, or a look around when idle
    {
      const att = p.lb >= 0 && W.T - p.lbT < 2.5 ? W.pl[p.lb] : null;
      if (q && W.T - (Mm.seenT || -9) < 4 && p.veh < 0) out.face = Math.atan2(q.y - p.y, q.x - p.x);
      else if (att && !att.out && att.tm !== p.tm && W.T - p.lbT > A.react * 0.8 && p.veh < 0) out.face = Math.atan2(att.y - p.y, att.x - p.x) + gauss() * (lv === 1 ? 0.5 : 0.25);
      else if (!Mm.want && p.veh < 0 && p.use <= 0) {
        Mm.look = (Mm.look == null ? p.a : Mm.look) + dt * (lv === 1 ? 0.6 : 1.1) * (Mm.side || 1) * (lv >= 2 && w && scW(w) >= 3 ? 0.4 : 1); out.face = Mm.look;
        if (lv >= 2 && w && scW(w) >= 3 && W.T >= CALM_T) out.ads = 1;      // a scoped bot glasses the area while it waits
      }
      if (out.face == null) Mm.look = null;
    }
    // sprint toward far goals (zone, loot, fleeing) while stamina lasts; never mid-fight
    if (!eng && Mm.want && p.stm > (lv === 1 ? 55 : 25) && (Mm.urg || Mm.flee || (Mm.goal && hyp(Mm.goal[0] - p.x, Mm.goal[1] - p.y) > (lv === 3 ? 10 : 16)))) out.sp = 1;
    // stance: crouch while camping / sniping / healing still; stand up to run
    if (!p.swim) {
      const still = hyp(out.ax, out.ay) < 0.35;
      let wc = lv >= 2 && (still && (Mm.camp > W.T || p.use > 0 || (q && w && (G.c >= 4 || (lv === 3 && G.c !== 3 && hyp(q.x - p.x, q.y - p.y) > 10))))) ? 1 : 0;
      if (Mm.urg || Mm.flee || out.sp) wc = 0;
      if (wc !== p.cr && !(Mm.crT > W.T) && (lv >= 2 || Math.random() < 0.3)) { out.acts.push(40); Mm.crT = W.T + 1.5; }
    }
    // a wild animal going for me: shoot it (or hit it / back off)
    // (normal/hard deal with a charging animal first when it is close, even mid-fight; hard also clears a prowling one near its path)
    if ((!q || lv >= 2) && W.an.length && p.veh < 0 && p.fl <= 0 && !p.kd) {
      let an = null, bd = q ? 9 : 26;
      for (const a of W.an) if (a.hp > 0 && (a.tg === p.i || (lv === 3 && !q && w && w.m > 0 && !ANI[a.k].wet && hyp(a.x - p.x, a.y - p.y) < 13 && inCone(p, a.x, a.y) && los(W.M, p.x, p.y, a.x, a.y)))) { const d = hyp(a.x - p.x, a.y - p.y); if (d < bd) { bd = d; an = a; } }
      if (an) {
        const ang = Math.atan2(an.y - p.y, an.x - p.x);
        if ((w && w.m > 0 && GUN[w.t].c !== 8) || (p.sl === 3 && bd < 2.4)) { out.aim = ang + gauss() * A.err / Math.max(3, bd); out.ad = bd; out.fire = 1; }
        else if (w && w.m <= 0 && p.rl <= 0) out.acts.push(1);
        const armedA = w && w.m > 0 && GUN[w.t].c !== 8;
        if (lv >= 2 && !armedA && !(p.sl === 3 && bd < 2.4 && ANI[an.k].hp < 150)) { out.ax = -Math.cos(ang); out.ay = -Math.sin(ang); if (p.stm > 10) out.sp = 1; out.fire = 0; }   // unarmed: run (it gives up once far enough)
        else if (bd < (lv === 3 ? 8 : 6) && (!w || lv >= 2)) { const k = lv === 3 && ANI[an.k].hp >= 150 ? 1 : 0.8; out.ax = -Math.cos(ang) * k; out.ay = -Math.sin(ang) * k; }
        return out;
      }
    }
    // shoot / throw
    if (q && p.fl <= 0) {
      Mm.react -= dt;
      const dx = q.x - p.x, dy = q.y - p.y, d = hyp(dx, dy);
      const hitMe2 = p.lb === q.i && W.T - p.lbT < 3;
      const R = p.sl === 4 ? 26 : p.sl === 3 || !w ? (p.ml >= 0 && p.sl === 3 ? MELEE[p.ml].r : 1.3) + PR : hitMe2 || G.c >= 4 ? G.mr * 0.95 : Mm.avoid ? 12 : G.er * 1.3 * PP.eng;
      const useAds = (A.ads || PP.snip) && w && (G.c === 5 || G.c === 4 || G.c === 7 || ((G.c === 2 || G.c === 6) && (lv === 3 || d > 24)) || (G.c === 0 && lv === 3 && d > 14)) && d > (G.c === 2 || G.c === 6 ? 13 : 18) && !Mm.urg;
      out.ads = useAds || out.ads ? 1 : 0;
      if (useAds) { out.ax *= 0.4; out.ay *= 0.4; }
      if (Mm.react <= 0 && d < R && canSee(W, p, q)) {
        let fire = 1;
        if (p.sl === 4) { fire = Mm.tog ? 0 : 1; Mm.tog = !Mm.tog; if (Mm.smk) { out.aim = p.a; out.ad = 1.5; } }
        else if (A.burst && w && G.cd < 0.12 && d > G.er * 0.7) { Mm.bc = (Mm.bc || 0) + dt; const cyc = 0.45 - lv * 0.05; if (Mm.bc % cyc > cyc * 0.6) fire = 0; }
        if (w && w.m <= 0) fire = 0;
        // hard: tap/burst so the bloom settles before the next shot at range
        if (lv === 3 && w && G.c !== 3 && d > 12 && p.bl > spreadOf(W, p, w) * 0.45 + 0.004) fire = 0;
        if (fire) {
          let ex = q.x, ey = q.y;
          if (G && G.pv) { const t = d / G.pv; ex += q.vx * t; ey += q.vy * t; }
          const e = A.err * (out.ads ? 0.6 : 1) * (q.veh >= 0 ? 1.5 : 1);
          if (out.aim == null) { out.aim = Math.atan2(ey - p.y, ex - p.x) + gauss() * e / Math.max(3, d); out.ad = d + gauss() * e; }
          out.fire = 1;
        }
      }
    } else if (p.sl === 4 && Mm.thr > W.T && Mm.smk) { out.fire = Mm.tog ? 0 : 1; Mm.tog = !Mm.tog; out.aim = p.a; out.ad = 1.5; }
    return out;
  }
  /* ======================= coarse state ======================= */
  const CALL = ['독수리', '코브라', '늑대', '여우', '상어', '표범', '매', '불곰'];
  function init(players, opts) {
    const o = opts || {}, pr = o.mode === 'practice' ? 1 : 0, ns = pr ? 1 : clamp(players.length | 0, 1, NPMAX);
    if (pr) players = players.slice(0, 1);
    const rg = o.mode === 'range' || pr ? 1 : 0;
    const np = rg ? ns : o.fill === 'no' ? Math.max(2, ns) : Math.max(8, ns);
    const ts = rg ? 1 : o.mode === 'squad' && np >= 5 ? 4 : (o.mode === 'duo' || o.mode === 'squad') && np >= 3 ? 2 : 1;
    const mp = typeof o.map === 'number' && o.map >= 0 && o.map < MAPS.length ? o.map : -1;
    let alv = 2; for (const p of players) if (p && p.ai && p.lv >= 1 && p.lv <= 3) alv = p.lv;
    const nm = [], flv = [];
    for (let i = 0; i < np; i++) {
      if (i < ns) nm.push(String((players[i] && players[i].name) || (i + 1) + '번').slice(0, 10));
      else { nm.push(CALL[(i - ns + ns * 3) % CALL.length] + '(AI)'); flv.push(alv); }
    }
    const mk = rg ? 99 : mp >= 0 ? mp : U.rand(MAPS.length);
    const huS = players.map((p, i) => (p && !p.ai ? i : -1)).filter((i) => i >= 0 && i < ns), pick = !rg && ts > 1 && huS.length >= 2;
    return {
      pk: pick ? Array.from({ length: ns }, () => -1) : undefined,
      rid: 1 + U.rand(99999), sd: 1 + U.rand(999999), mk, rg, pr, wx: rg ? 0 : rollWx(o.weather, mk),
      nm, np, ns, flv, hu: players.map((p, i) => (p && !p.ai ? i : -1)).filter((i) => i >= 0 && i < ns), tm: ts > 1 ? 1 : 0, ts, ap: o.auto === 'on' ? 1 : 0,
      gore: o.gore === 'low' ? 0 : 1, dn: o.dmg === 'off' ? 0 : 1, ph: pick ? 'team' : 'go', res: null,
    };
  }
  /* 팀 편성 (before the match, 2+ people in a team mode): capacities, a legal pick, the final seat → team list */
  const teamCaps = (st) => { const nt = Math.ceil(st.np / st.ts), c = []; for (let t = 0; t < nt; t++) c.push(t < nt - 1 ? st.ts : st.np - (nt - 1) * st.ts); return c; };
  function pickOk(st, pk, s, t) {
    if ((st.hu || []).indexOf(s) < 0) return false;
    if (t === -1) return true;
    const cap = teamCaps(st); if (!(t >= 0 && t < cap.length)) return false;
    let n = 0; (st.hu || []).forEach((h) => { if (h !== s && pk[h] === t) n++; });
    return n < cap[t];
  }
  function teamsFrom(st, pk) {
    const cap = teamCaps(st), used = cap.map(() => 0), ta = new Array(st.np).fill(-1), hu = st.hu || [];
    for (const h of hu) { const t = pk[h]; if (t >= 0 && t < cap.length && used[t] < cap[t]) { ta[h] = t; used[t]++; } }
    for (const h of hu) if (ta[h] < 0) {   // not chosen: a random team that still has room
      const free = cap.map((c, t) => t).filter((t) => used[t] < cap[t]); const t = free[Math.floor(Math.random() * free.length)];
      ta[h] = t; used[t]++;
    }
    for (let i = 0; i < st.np; i++) if (ta[i] < 0) { let t = 0; while (t < cap.length - 1 && used[t] >= cap[t]) t++; ta[i] = t; used[t]++; }
    return ta;
  }
  /* weather per match: set by the option, or random (맑음 40% · 비 25% · 눈보라 15% · 폭풍 20%); random never rains on snow islands or snows in the desert / on the volcano */
  function rollWx(opt, mk) {
    const T = MAPS[mk] || {}, fixed = typeof opt === 'number' && opt >= 0 && opt <= 3;
    let w = fixed ? opt : (() => { const u = Math.random(); return u < 0.4 ? 0 : u < 0.65 ? 1 : u < 0.8 ? 2 : 3; })();
    if (!fixed) { if (T.snow && w === 1) w = 2; if ((T.k === 'd' || T.k === 'v' || T.k === 'g') && w === 2) w = 0; }
    return w;
  }
  const MODE_NM = { 1: '솔로', 2: '2인 팀전', 4: '4인 스쿼드' };
  const fmtT = (s) => Math.floor(s / 60) + '분 ' + String(Math.floor(s % 60)).padStart(2, '0') + '초';
  const fmtD = (m) => (m >= 1000 ? (m / 1000).toFixed(1) + 'km' : Math.round(m) + 'm');
  function result(st) {
    if (!st || st.ph !== 'done' || !Array.isArray(st.res) || !st.res.length) return null;
    if (st.pr) return { winners: [], title: '연습 끝', text: '연습장에서 나왔어요 · 점수는 남지 않아요', stats: [] };
    const nm = (i) => (st.nm && st.nm[i]) || (i + 1) + '번', ns = st.ns || st.np;
    const top = st.res.filter((r) => r[1] === 1).map((r) => r[0]).sort((a, b) => a - b);
    const winners = top.filter((i) => i < ns);
    const title = !top.length ? '무승부' : st.tm && top.length > 1 ? top.map(nm).join('·') + ' 팀 우승!' : nm(top[0]) + ' 우승!';
    const hu = st.hu || [], top10 = st.res.slice(0, 10), mine = st.res.filter((r, k) => k >= 10 && hu.indexOf(r[0]) >= 0);
    const lines = top10.concat(mine).map((r) => r[1] + '위  ' + nm(r[0]) + '  · 처치 ' + r[2]);
    if (st.res.length > 10) lines.splice(10, 0, '… 모두 ' + st.res.length + '명');
    // post-match record of the people (not bots)
    const sts = st.sts && typeof st.sts === 'object' ? st.sts : {}, rec = [];
    hu.slice(0, 6).forEach((i) => {
      const a = sts[i]; if (!Array.isArray(a) || a.length < 8) return;
      const [dd, k, sf, sh, hs, dm, sv, rv] = a.map((v) => +v || 0), ws = a.slice(8).map((t) => GUN[t | 0] ? GUN[t | 0].nm : '').filter(Boolean);
      rec.push('── ' + nm(i) + ' 기록 ──', '피해 ' + Math.round(dd) + ' · 처치 ' + k + ' · 명중 ' + (sf ? Math.round(sh / sf * 100) : 0) + '% (' + sh + '/' + sf + ') · 헤드샷 ' + hs,
        '이동 ' + fmtD(dm) + ' · 생존 ' + fmtT(sv) + (st.tm ? ' · 부활시킨 수 ' + rv : '') + (ws.length ? ' · 무기 ' + ws.join(', ') : ''));
    });
    const nsS = Math.min(ns, 8), cell = (i, k) => { const v = sts[i]; return Array.isArray(v) && v.length >= 7 ? k(v.map((x) => +x || 0)) : null; };
    const stats = hu.length ? [['순위', (i) => { const r = st.res.find((q) => q[0] === i); return r ? r[1] + '위' : null; }], ['처치', (i) => cell(i, (v) => v[1])], ['가한 피해', (i) => cell(i, (v) => Math.round(v[0]))],
      ['명중률', (i) => cell(i, (v) => (v[2] ? Math.round(v[3] / v[2] * 100) : 0) + '%')], ['헤드샷', (i) => cell(i, (v) => v[4])], ['이동 거리', (i) => cell(i, (v) => fmtD(v[5]))], ['생존 시간', (i) => cell(i, (v) => fmtT(v[6]))]].concat(st.tm ? [['부활시킨 수', (i) => cell(i, (v) => v[7])]] : [])
      .map(([label, f]) => ({ label, values: Array.from({ length: nsS }, (_, i) => f(i)) })) : null;
    return { winners, title, text: (MODE_NM[st.ts || (st.tm ? 2 : 1)] || '솔로') + ' · ' + ((MAPS[st.mk] || MAPS[0]).nm) + '\n' + lines.join('\n') + (rec.length ? '\n\n' + rec.join('\n') : ''), stats };
  }
  /* stats sent with the final state (people only, compact) */
  function statsOf(W, hu) {
    const o = {};
    (hu || []).slice(0, 24).forEach((i) => { const p = W.pl[i]; if (p) o[i] = [Math.round(p.dd), p.kills, p.sf, p.sh, p.hs, Math.round(p.dm), Math.round(p.dt || W.T), p.rvc | 0].concat(p.wu.slice(0, 6)); });
    return o;
  }

  /* ======================= network snapshot ======================= */
  const PS = 16;
  function invOf(p) {
    const g = (w) => (w ? [w.t + 1, w.m].concat([0, 1, 2, 3, 4].map((k) => w.a[k] | 0)) : [0, 0, 0, 0, 0, 0, 0]);
    return [].concat(g(p.g[0]), g(p.g[1]), g(p.g[2]), [p.ml + 1], p.th, [p.ts], p.hl, p.am, p.at,
      [p.sl, Math.round(p.stm), p.ut + 1, Math.round(p.uT * 10), Math.round(p.bl * 1000), Math.ceil(Math.max(0, p.sb)), p.ex, Math.ceil(Math.max(0, p.lk)), p.cr,
        Math.round(p.dd), p.sf, p.sh, p.hs, Math.round(p.dm), p.spc | 0]);
  }
  /* the layout follows the real list sizes (throwables · heals · ammo · attachments), so new items never shift the fields */
  const INV_N = 22 + THROW.length + 1 + HEAL.length + AMMO.length + ATT.length + 15;
  function setInv(p, a) {
    if (!Array.isArray(a) || a.length < INV_N) return;
    const g = (k, old) => {
      const t = (a[k] | 0) - 1; if (t < 0 || !GUN[t]) return null;
      const at = a.slice(k + 2, k + 7).map((v) => { v |= 0; return v > 0 && v <= ATT.length ? v : 0; });
      if (old && old.t === t) { old.m = a[k + 1] | 0; old.a = at; return old; }
      return { t, m: a[k + 1] | 0, a: at };
    };
    p.g = [g(0, p.g[0]), g(7, p.g[1]), g(14, p.g[2])]; p.ml = (a[21] | 0) - 1;
    let o = 22;
    const take = (n) => { const r = a.slice(o, o + n).map((v) => v | 0); o += n; return r; };
    p.th = take(THROW.length); p.ts = a[o++] | 0; p.hl = take(HEAL.length); p.am = take(AMMO.length); p.at = take(ATT.length);
    p.sl = a[o] | 0; p.stm = +a[o + 1] || 0; p.ut = (a[o + 2] | 0) - 1; p.uT = (+a[o + 3] || 0) / 10; p.bl = (+a[o + 4] || 0) / 1000; p.sb = +a[o + 5] || 0; p.ex = a[o + 6] | 0; p.lk = +a[o + 7] || 0; p.cr = a[o + 8] | 0;
    p.dd = +a[o + 9] || 0; p.sf = a[o + 10] | 0; p.sh = a[o + 11] | 0; p.hs = a[o + 12] | 0; p.dm = +a[o + 13] || 0; p.spc = a[o + 14] | 0;
  }
  /* cams: [[x, y], …] = where remote players look; only things near them are sent in detail (50 players fit in 4 KB) */
  const NEAR = 58;
  const QR = 4;   // half-size of the square around a guest whose ground items / crates are sent exactly
  function encodeW(W, key, hsQ, heavy, invSeats, cams, pq) {
    const nearPt = (x, y, r) => { if (!cams) return true; const R = r || NEAR; for (const c of cams) if (Math.abs(c[0] - x) < R && Math.abs(c[1] - y) < R) return true; return false; };
    const many = !!(invSeats && invSeats.length > 12);
    const mine = {}; if (invSeats) for (const s of invSeats) { mine[s] = 1; const q = W.pl[s]; if (q) for (const o of W.pl) if (o.tm === q.tm) mine[o.i] = 1; }
    const Pp = []; let O = '';
    for (let i = 0; i < W.pl.length; i += 4) { let v = 0; for (let k = 0; k < 4; k++) if (W.pl[i + k] && W.pl[i + k].out) v |= 1 << k; O += v.toString(16); }
    for (const p of W.pl) {
      if (p.out ? !mine[p.i] || (hsQ + p.i) % 4 : !mine[p.i] && !nearPt(p.x, p.y)) continue;   // dead people: only their own team hears about them, in turn
      const fl = (p.out ? 1 : 0) | (p.kd ? 2 : 0) | (p.ads ? 4 : 0) | (p.use > 0 ? 8 : 0) | (p.rl > 0 ? 16 : 0) | (p.ft > 0 ? 32 : 0) | (p.rev > 0 ? 64 : 0) |
        (p.swim ? 128 : 0) | (p.fl > 0 ? 256 : 0) | (p.rvb > 0 ? 512 : 0) | (p.burn > 0 ? 1024 : 0) | (p.cr ? 2048 : 0) | (p.sx ? 4096 : 0) | (p.vt > 0 ? 8192 : 0) |
        (p.mf > 0 ? 16384 : 0) | (p.lit ? 32768 : 0) | (p.spc ? p.spc * 65536 : 0);
      const w = heldGun(p);
      Pp.push(p.i, r1(p.x), r1(p.y), r1(p.a), Math.ceil(p.kd ? p.khp : p.hp), fl, heldCode(p) + 1, p.vs, p.hm, p.kills, p.place | 0, p.veh + 1, p.seat,
        p.bp, w ? w.m : 0, p.use > 0 ? Math.round(p.use * 10) : 0, p.fl > 0 ? Math.round(p.fl * 10) : 0);
    }
    const J = [];
    for (const b of W.pj) {
      if (!nearPt(b.x, b.y)) continue;
      if (b.k === 't') J.push(r1(b.x), r1(b.y), r1(b.z), b.ty);
      else J.push(r1(b.x), r1(b.y), 0, (b.k === 'r' ? 2000 : b.k === 'f' ? 3000 : 1000) + Math.round((wrapA(b.a) + Math.PI) * 100));
    }
    // vehicles: parked ones the guests already know (same seed) are skipped; moved ones only in the heavy packets once they stop
    const V = []; W.vh.forEach((v, j) => { if ((W.T - (v.mt || -9) < 1.5 || (heavy && v.mt != null && (!many || hsQ % 3 === 0))) && nearPt(v.x, v.y, NEAR)) V.push(j, r1(v.x), r1(v.y), r2(v.a), Math.ceil(v.hp), r1(v.v)); });
    const A = []; for (const a of W.ar) if (nearPt(a.x, a.y)) A.push(a.x, a.y, r1(a.t), a.k);
    const AD = []; for (const d of W.ad) AD.push(d.x, d.y, r1(d.t), d.op);
    const z = W.z;
    const FXG = { 2: 1, 3: 1, 13: 1, 14: 1, 16: 1, 21: 1, 22: 1, 40: 1 };
    const fx = []; for (let k = W.fx.length - 1; k >= 0 && fx.length < (many ? 8 : 16); k--) { const e = W.fx[k]; if (FXG[e[1]] || ((e[1] === 4 || e[1] === 11) ? mine[e[4]] : nearPt(e[2], e[3], NEAR + 15))) fx.unshift(e); }
    const o = { k: key, q: hsQ, ph: W.ph, t: r1(W.t), T: r1(W.T), Z: [r1(z.cx), r1(z.cy), r1(z.r), z.nx, z.ny, z.nr, z.i, z.s, r1(z.t)], O, P: Pp, J, V, A, AD, fx, lv: W.lv };
    // animals near the guests, red zone, falling roof bits, sandstorm, flares, time of day, range targets
    const N = []; let na = 0;
    for (let j = 0; j < W.an.length && na < (many ? 4 : 12); j++) { const a = W.an[j]; if (!nearPt(a.x, a.y)) continue; na++; N.push(j, a.k, r1(a.x), r1(a.y), r1(a.a), Math.ceil(a.hp / ANI[a.k].hp * 20), a.tg); }
    if (N.length) o.N = N;
    if (W.rz) o.RZ = [W.rz.x, W.rz.y, W.rz.r, W.rz.ph, r1(W.rz.t)];
    if (W.db.length) o.DB = W.db.reduce((a, d) => a.concat([d.x, d.y, r1(d.t)]), []);
    if (W.ss > 0) o.SS = Math.ceil(W.ss);
    if (W.lg.length) o.LG = W.lg.reduce((a, d) => a.concat([d.x, d.y, r1(d.t)]), []);
    if (W.lt.length) o.LT = W.lt.reduce((a, l) => a.concat([l.x, l.y, l.r, Math.ceil(l.t)]), []);
    if (W.todOff !== DAY * 0.05) o.TO = Math.round(W.todOff);
    if (W.tg.length) o.TG = W.tg.reduce((a, g) => a.concat([r1(g.x), Math.max(0, Math.round(g.hp))]), []);
    // doors: open bits (hex, 4 per char) + locked ones; team pings and map markers
    let Dr = ''; for (let j = 0; j < W.ds.length; j += 4) Dr += ((W.ds[j] | 0) | ((W.ds[j + 1] | 0) << 1) | ((W.ds[j + 2] | 0) << 2) | ((W.ds[j + 3] | 0) << 3)).toString(16);
    o.Dr = Dr;
    const DL = []; for (let j = 0; j < W.dl.length; j++) if (W.dl[j] > 0) DL.push(j, Math.ceil(W.dl[j])); if (DL.length) o.DL = DL;
    const tms = {}; for (const i in mine) if (W.pl[i]) tms[W.pl[i].tm] = 1;
    const G = []; for (const g of W.pg) if (tms[g.tm]) G.push(g.id, g.i, g.k, g.x, g.y, Math.ceil(g.t)); if (G.length) o.G = G;
    const MK = []; for (const i in W.mk) if (mine[i]) MK.push(+i, W.mk[i][0], W.mk[i][1]); if (MK.length) o.MK = MK;
    // 인식표 of my team · towers being used right now (everyone hears those)
    if (W.dg && W.dg.length) { const RT = []; for (const g of W.dg) if (mine[g.i] || !invSeats) RT.push(g.i, g.x, g.y, g.by, Math.ceil(g.t)); if (RT.length) o.RT = RT; }
    { const CH = []; for (const p of W.pl) if (!p.out && p.ut === 10 && p.use > 0) CH.push(p.i, p.rcT | 0, Math.ceil(p.use * 10)); if (CH.length) o.CH = CH; }
    if (W.rcOpen) o.RO = 1;
    if (heavy) {
      let T = '';
      for (let j = 0; j < W.tk.length; j += 4) T += ((W.tk[j] | 0) | ((W.tk[j + 1] | 0) << 1) | ((W.tk[j + 2] | 0) << 2) | ((W.tk[j + 3] | 0) << 3)).toString(16);
      o.Tk = T;
      const DC = many ? 27 : 135;
      const D = []; for (let j = W.dr.length - 1; j >= 0 && D.length < DC; j--) { const l = W.dr[j]; if (nearPt(l.x, l.y, 26)) D.push(l.x, l.y, l.t * 1000 + Math.min(999, l.n)); }
      o.D = D;
      o.B = W.bx.filter((b) => nearPt(b.x, b.y, many ? 16 : 26)).slice(-(many ? 4 : 40)).map((b) => [b.x, b.y, b.ad ? 1 : 0].concat(b.it.slice(0, 16).map((e) => e[0] * 1000 + Math.min(999, e[1]))));
    }
    if (invSeats && invSeats.length) {
      // many guests: send a few inventories per packet, in turn
      const g = Math.ceil(invSeats.length / (many ? 2 : 4));
      o.I = {}; invSeats.forEach((s, k) => { if (W.pl[s] && k % g === hsQ % g) o.I[s] = invOf(W.pl[s]); });
      // each guest's own surroundings (ground within reach + the body / crate it can open), so its 소지품 list is exact.
      // pq = seats that just acted / have the bag open (first), then everyone in turn
      const qn = many ? 3 : 8, seen = {}, order = (pq || []).concat(invSeats.slice(hsQ % invSeats.length), invSeats.slice(0, hsQ % invSeats.length));
      const Q = [];
      for (const s of order) {
        if (Q.length >= qn || seen[s]) continue; seen[s] = 1;
        const q = W.pl[s]; if (!q || q.out || W.ph !== 2) continue;
        if (!o.I[s] && (pq || []).indexOf(s) >= 0) o.I[s] = invOf(q);
        const R = QR, D = [];
        for (const l of W.dr) if (Math.abs(l.x - q.x) < R && Math.abs(l.y - q.y) < R && D.length < 60) D.push(l.x, l.y, l.t * 1000 + Math.min(999, l.n));
        const B = [];
        for (const b of W.bx) if (Math.abs(b.x - q.x) < R && Math.abs(b.y - q.y) < R && B.length < 2) B.push([b.x, b.y, b.ad ? 1 : 0].concat(b.it.slice(0, 16).map((e) => e[0] * 1000 + Math.min(999, e[1]))));
        Q.push([s, r1(q.x), r1(q.y), D, B]);
      }
      if (Q.length) o.Q = Q;
    }
    if (W.ph === 0 && W.tm && invSeats) { const Lm = {}; for (const p of W.pl) if (mine[p.i] && fin(p.lx)) Lm[p.i] = [r1(p.lx), r1(p.ly)]; o.L = Lm; }
    // keep the packet under the 4 KB room limit: thin the least urgent parts first (they come again in later packets)
    if (cams) {
      const CAP = 3900, sz = () => JSON.stringify(o).length;
      let n = sz();
      const cut = (f) => { while (n > CAP && f()) n = sz(); };
      cut(() => { if (!o.D || !o.D.length) return false; o.D.length = Math.max(0, o.D.length - 15); return true; });
      cut(() => { if (!o.B || !o.B.length) return false; o.B.shift(); return true; });
      cut(() => { if (!o.Q || o.Q.length <= 1) return false; o.Q.pop(); return true; });
      cut(() => { if (!o.I) return false; const ks = Object.keys(o.I); if (ks.length <= 1) return false; delete o.I[ks[ks.length - 1]]; return true; });
      cut(() => { if (!o.J || !o.J.length) return false; o.J.length = Math.max(0, o.J.length - 16); return true; });
      cut(() => { if (o.fx.length <= 2) return false; o.fx.shift(); return true; });
    }
    return o;
  }

  /* ======================= sound (small synth: gunshots by weapon type) ======================= */
  const Snd = {
    ac: null, nb: null, n: 0, t0: 0,
    on() { try { return !!(U.store ? U.store.get('sound', true) : true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    mg: null,
    vol() { try { return L.audio && L.audio.sfx ? clamp(+L.audio.sfx() || 0, 0, 1) : 1; } catch (e) { return 1; } },
    out(ac) { if (!this.mg) { this.mg = ac.createGain(); this.mg.connect(ac.destination); } this.mg.gain.value = this.vol(); return this.mg; },
    noiseBuf(ac) { if (this.nb) return this.nb; const n = ac.sampleRate * 0.6, b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; return (this.nb = b); },
    budget() { const t = performance.now(); if (t - this.t0 > 1000) { this.t0 = t; this.n = 0; } return ++this.n < 34; },
    burst(dur, vol, type, f0, f1, q) {
      const ac = this.ctx(); if (!ac || vol < 0.01) return;
      const t = ac.currentTime, src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
      src.buffer = this.noiseBuf(ac); f.type = type; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur); if (q) f.Q.value = q;
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      src.connect(f).connect(g).connect(this.out(ac)); src.start(t, Math.random() * 0.2); src.stop(t + dur + 0.02);
    },
    tone(f0, f1, dur, vol, type) {
      const ac = this.ctx(); if (!ac || vol < 0.01) return;
      const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
      g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.02);
      o.connect(g).connect(this.out(ac)); o.start(t); o.stop(t + dur + 0.04);
    },
    gun(c, sup, v) {
      if (!this.budget()) return;
      if (sup) { this.burst(0.07, 0.22 * v, 'lowpass', 1100, 300); this.tone(180, 70, 0.05, 0.12 * v); return; }
      switch (c) {
        case 0: this.burst(0.12, 0.42 * v, 'bandpass', 2200, 700, 0.8); this.tone(170, 60, 0.08, 0.3 * v); break;
        case 1: this.burst(0.07, 0.34 * v, 'highpass', 2600, 900); this.tone(210, 90, 0.05, 0.22 * v); break;
        case 3: this.burst(0.32, 0.6 * v, 'lowpass', 1800, 200); this.tone(95, 38, 0.24, 0.5 * v); break;
        case 4: this.burst(0.24, 0.5 * v, 'lowpass', 3800, 500); this.tone(130, 45, 0.16, 0.4 * v); this.tone(2400, 900, 0.03, 0.12 * v, 'square'); break;
        case 5: this.burst(0.5, 0.62 * v, 'lowpass', 4200, 300); this.tone(85, 32, 0.3, 0.55 * v); this.tone(3000, 1200, 0.025, 0.18 * v, 'square'); break;
        case 7: this.tone(260, 120, 0.14, 0.25 * v, 'triangle'); this.burst(0.05, 0.1 * v, 'highpass', 3000, 2000); break;
        case 6: this.burst(0.13, 0.46 * v, 'lowpass', 2600, 600); this.tone(120, 48, 0.1, 0.36 * v); break;
        default: this.burst(0.14, 0.44 * v, 'lowpass', 3200, 700); this.tone(140, 50, 0.11, 0.36 * v);
      }
    },
    boom(v) { this.burst(1.1, 0.8 * v, 'lowpass', 1500, 60); this.tone(75, 26, 0.8, 0.6 * v); },
    hit(head) { this.tone(head ? 1900 : 1300, head ? 2600 : 900, 0.05, 0.14, 'square'); },
    close() { try { this.ac && this.ac.close(); } catch (e) {} this.ac = null; this.nb = null; this.mg = null; },
  };

  /* ======================= view ======================= */
  const FXK = () => { try { return L.fx ? clamp(+L.fx(), 0, 1) : 1; } catch (e) { return 1; } };
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const STICK_R0 = 46, TILE = 30;
  const KC = () => { const v = L.ui && L.ui.ctlScale ? +L.ui.ctlScale() : 1; return v > 0 ? v : 1; };
  let MM = 92;
  const CSS = `
.ry-btn{position:absolute;border:2px solid rgba(242,233,216,.32);background:rgba(18,16,24,.74);color:#f2e9d8;
  font:700 12px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;
  touch-action:none;user-select:none;-webkit-user-select:none;z-index:3;padding:0 3px;box-shadow:0 4px 12px rgba(0,0,0,.4);
  -webkit-tap-highlight-color:transparent;cursor:pointer;line-height:1.1;text-align:center;white-space:nowrap;transition:transform .06s}
.ry-btn::after{content:'';position:absolute;inset:-7px;border-radius:inherit}
.ry-btn .lb{max-width:100%;overflow:hidden;text-overflow:ellipsis}
.ry-btn.on{transform:scale(.93)}
.ry-btn small{font:600 10px var(--f-mono,monospace);opacity:.88;max-width:100%;overflow:hidden;text-overflow:ellipsis}
.ry-btn .k{position:absolute;top:1px;right:3px;font:800 9px var(--f-mono,monospace);color:#ffd27a;opacity:.95;display:none}
.ry-pc .ry-btn .k{display:block}
.ry-pc.ry-aim canvas{cursor:none}
.ry-round .k,.ry-fire .k{top:auto;bottom:4px;left:0;right:0;text-align:center}
.ry-btn .ic{width:30px;height:20px;display:block;pointer-events:none}
.ry-btn .ic svg{width:100%;height:100%}
.ry-btn.on{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}
.ry-btn.off{opacity:.42}
.ry-btn.lit{background:rgba(227,174,69,.9);color:#2a1d05;border-color:#fff3cf}
.ry-fire{width:88px;height:88px;border-radius:50%;right:12px;bottom:20px;font-size:12px;border-width:3px}
.ry-fire .lb{font-size:12px;max-width:80px;overflow:hidden;text-overflow:ellipsis}
.ry-fire small{font-size:12px}
.ry-round{width:54px;height:54px;border-radius:50%;font-size:12px}
.ry-fire{bottom:16px}
.ry-rl{right:112px;bottom:16px}.ry-ads{right:112px;bottom:78px}.ry-heal{right:112px;bottom:140px}
.ry-cr{right:29px;bottom:112px}.ry-run{right:29px;bottom:174px}
.ry-slot{width:56px;height:48px;border-radius:11px;font-size:10px;padding:0 2px;gap:0}
.ry-slot .ic{height:16px}
.ry-slot .lb{max-width:52px;overflow:hidden;text-overflow:ellipsis}
.ry-moreb{font-size:20px}
.ry-mini{width:44px;height:44px;border-radius:10px;font-size:11px;background:rgba(18,16,24,.82)}
.ry-rgb{width:96px;height:44px;border-radius:12px;font-size:12px;left:8px}
.ry-search{flex:1;min-width:0;height:40px;border-radius:10px;border:1.5px solid rgba(242,233,216,.3);background:rgba(255,255,255,.06);color:#f2e9d8;font:600 14px var(--f-body,system-ui);padding:0 10px}
.ry-chips{display:flex;gap:6px;flex-wrap:wrap;padding:6px 10px 0;flex:none}
.ry-chips button{height:36px;padding:0 10px;border-radius:18px;border:1.5px solid rgba(242,233,216,.3);background:rgba(255,255,255,.05);color:#f2e9d8;font:700 12px var(--f-body,system-ui);cursor:pointer}
.ry-chips button.on{background:#e3ae45;color:#2a1d05}
.ry-mchip{height:44px;padding:0 12px;border-radius:22px;border:1.5px solid rgba(127,224,122,.6);background:rgba(18,16,24,.85);color:#f2e9d8;font:700 12px var(--f-body,system-ui);cursor:pointer;align-self:flex-start;display:flex;align-items:center;gap:6px}
.ry-mchip .ic{width:24px;height:24px}.ry-mchip .ic svg{width:100%;height:100%}
.ry-vmenu{position:absolute;z-index:4;display:flex;flex-direction:column;gap:8px}
.ry-vmenu button{min-width:120px;height:44px;border-radius:12px;border:2px solid rgba(242,233,216,.4);background:rgba(18,16,24,.94);color:#f2e9d8;font:700 13px var(--f-body,system-ui);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:10px;padding:0 12px}
.ry-vmenu button small{font:800 10px var(--f-mono,monospace);color:#ffd27a}
.ry-kov{position:absolute;inset:0;z-index:6;background:rgba(8,6,12,.72);display:flex;align-items:center;justify-content:center;padding:12px}
.ry-kcard{width:min(560px,100%);max-height:100%;display:flex;flex-direction:column;background:#211b2c;border:1.5px solid rgba(242,233,216,.18);border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.5);color:#f2e9d8;overflow:hidden}
.ry-kcard .ry-ovh{border-bottom:1px solid rgba(242,233,216,.12)}
.ry-kgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;padding:10px 14px 14px;overflow-y:auto}
.ry-kgrid h5{margin:0 0 4px;font:700 12px var(--f-body,system-ui);color:#e3ae45}
.ry-kgrid table{width:100%;border-collapse:collapse;font:600 12.5px var(--f-body,system-ui)}
.ry-kgrid td{padding:3px 0;border-bottom:1px solid rgba(242,233,216,.07)}
.ry-kgrid td:last-child{text-align:right;white-space:nowrap}
.ry-kgrid kbd{display:inline-block;min-width:20px;padding:1px 6px;margin-left:3px;border-radius:5px;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);font:700 11px var(--f-body,system-ui);color:#ffd27a;text-align:center}
.ry-knote{padding:0 14px 12px;font:600 11.5px var(--f-body,system-ui);color:#ab9fb8}
.ry-slot.act{border-color:#f2e9d8;background:rgba(60,50,30,.92);box-shadow:0 0 0 2px rgba(227,174,69,.6),0 4px 12px rgba(0,0,0,.4)}
.ry-small{width:46px;height:46px;border-radius:12px;font-size:11px}
.ry-cx{width:118px;height:44px;border-radius:22px;background:rgba(227,174,69,.94);color:#2a1d05;border-color:#fff3cf;font-size:12.5px;padding:0 8px;flex-direction:row;gap:4px}
.ry-cx .lb{flex:1;text-align:left}.ry-cx small{display:none}
.ry-cx.blue{background:rgba(110,190,240,.94);border-color:#e6f6ff}.ry-cx.red{background:rgba(238,106,85,.95);color:#fff;border-color:#ffd0c6}
.ry-cx.lp{box-shadow:0 0 0 3px rgba(255,255,255,.7)}
.ry-top{width:44px;height:44px;border-radius:12px;font-size:18px;background:rgba(18,16,24,.82)}
.ry-pick{position:absolute;z-index:3;display:flex;gap:4px;height:44px;touch-action:none}
.ry-pick button{height:44px;border-radius:12px;border:2px solid rgba(242,233,216,.32);background:rgba(18,16,24,.84);color:#f2e9d8;font:700 12px var(--f-body,system-ui);cursor:pointer;-webkit-tap-highlight-color:transparent;position:relative;touch-action:none;padding:0 6px}
.ry-pick button::after{content:'';position:absolute;inset:-5px 0}
.ry-pick button:active{transform:scale(.94)}
.ry-pick .ar{width:38px;font-size:18px;flex:none}
.ry-pick .nm{flex:1;min-width:0;display:flex;align-items:center;gap:5px;text-align:left;overflow:hidden}
.ry-pick .nm .ic{width:28px;height:28px;flex:none}.ry-pick .nm .ic svg{width:100%;height:100%}
.ry-pick .nm span.t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ry-pick .nm small{display:block;font:600 10px var(--f-body,system-ui);opacity:.75}
.ry-pick .go{flex:none;min-width:66px;background:rgba(227,174,69,.95);color:#2a1d05;border-color:#fff3cf;font-size:13px}
.ry-pick .go.up{background:#7fe07a;border-color:#eaffea}
.ry-pick .k{font:800 9px var(--f-mono,monospace);color:#7a4a00;display:none;margin-left:3px}
.ry-pc .ry-pick .k{display:inline}
.ry-next{height:46px;min-width:140px;border-radius:23px;left:50%;transform:translateX(-50%);bottom:18px;font-size:14px;padding:0 16px}

.ry-tip{position:absolute;z-index:60;display:none;max-width:330px;pointer-events:none;background:rgba(14,12,20,.95);border:1.5px solid #e3ae45;border-radius:10px;padding:7px 9px;color:#f2e9d8;font:600 11.5px/1.4 var(--f-body,system-ui);box-shadow:0 4px 14px rgba(0,0,0,.5)}
.ry-tip b{display:block;font:800 13px var(--f-body,system-ui);color:#ffd27a}.ry-tip small{display:block;font:600 10.5px var(--f-body,system-ui);opacity:.7;margin-bottom:3px}
.ry-tip .cmp{margin-top:4px;padding-top:4px;border-top:1px solid rgba(242,233,216,.2)}.ry-tip i{font-style:normal;font-weight:800}.ry-tip i.up{color:#7fe07a}.ry-tip i.dn{color:#ff8a7a}.ry-tip i.eq{opacity:.6}
.ry-near{position:absolute;left:8px;width:140px;z-index:3;display:flex;flex-direction:column;gap:4px;touch-action:none}
.ry-near button{height:42px;display:flex;align-items:center;gap:6px;border:1.5px solid rgba(242,233,216,.25);border-radius:10px;background:rgba(18,16,24,.8);
  color:#f2e9d8;font:700 11px var(--f-body,system-ui);padding:0 6px;text-align:left;cursor:pointer;-webkit-tap-highlight-color:transparent;overflow:hidden;white-space:nowrap}
.ry-near button .ic{width:30px;height:30px;flex:none}.ry-near button .ic svg{width:100%;height:100%}
.ry-near button .t{flex:1;overflow:hidden;text-overflow:ellipsis}
.ry-near button .t small{display:block;font:600 10px var(--f-body,system-ui);opacity:.75}
.ry-near button.up{border-color:#7fe07a}.ry-near button.dim{opacity:.55}.ry-near button.more{justify-content:center;height:36px;color:#e3ae45}
.ry-pmenu{position:absolute;z-index:4;display:flex;gap:6px}
.ry-pmenu button{width:52px;height:46px;border-radius:12px;border:2px solid rgba(242,233,216,.4);background:rgba(18,16,24,.9);color:#f2e9d8;font:700 12px var(--f-body,system-ui);cursor:pointer}
.ry-ov{position:absolute;inset:0;z-index:6;background:rgba(16,13,22,.985);color:#f2e9d8;font:13px var(--f-body,system-ui);display:flex;flex-direction:column;touch-action:pan-y}
.ry-ovh{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid rgba(242,233,216,.12);flex:none}
.ry-ovh b{font:400 18px var(--f-display,sans-serif);color:#e3ae45;white-space:nowrap}
.ry-ovh .grow{flex:1;min-width:0}
.ry-x{width:44px;height:44px;border-radius:12px;border:1.5px solid rgba(242,233,216,.3);background:rgba(255,255,255,.06);color:#f2e9d8;font:700 16px var(--f-body,system-ui);cursor:pointer;flex:none;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1}
.ry-x small{font:700 8.5px var(--f-mono,monospace);color:#ffd27a}
.ry-sum{position:fixed;inset:0;z-index:60;background:rgba(16,13,22,.985);color:#f2e9d8;font:13px var(--f-body,system-ui);display:flex;flex-direction:column;padding:6px 8px;gap:6px;box-sizing:border-box}
.ry-sumh{display:flex;align-items:center;gap:8px;font:800 15px var(--f-body,system-ui)}.ry-sumh .grow{flex:1}
.ry-sumb{flex:1;min-height:0;display:flex;gap:8px}
.ry-summ{flex:1;min-width:0;min-height:0;display:flex;flex-direction:column;gap:4px}
.ry-sumcv{flex:1;min-height:0;width:100%;border-radius:10px;touch-action:none}
.ry-sumbar{display:flex;align-items:center;gap:6px}.ry-sumbar input{flex:1;min-width:0;height:44px;accent-color:#e3ae45}.ry-sumbar .ry-b{min-height:44px;white-space:nowrap}
.ry-sumt{font:700 11px var(--f-mono,monospace);white-space:nowrap;opacity:.9}
.ry-sums{width:200px;flex:none;overflow-y:auto;display:flex;flex-direction:column;gap:3px}
.ry-sums .r{display:flex;justify-content:space-between;gap:6px;padding:4px 6px;border-radius:8px;background:rgba(255,255,255,.05);font-size:12px}.ry-sums .r b{text-align:right}
.ry-sums .end{font-weight:800;padding:4px 6px;color:#ffd27a}.ry-sums .lg{font-size:10.5px;opacity:.7;line-height:1.35;padding:4px 2px}
@media (orientation:portrait){.ry-sumb{flex-direction:column}.ry-sums{width:auto;max-height:38%}}
.ry-wbar{height:8px;border-radius:4px;background:rgba(255,255,255,.12);overflow:hidden;margin-top:3px}.ry-wbar i{display:block;height:100%;background:#9ad14f}
.ry-wt{font:600 11px var(--f-body,system-ui);opacity:.85}
.ry-body{flex:1;overflow-y:auto;padding:6px 10px 10px;-webkit-overflow-scrolling:touch}
.ry-sec{font:700 11px var(--f-body,system-ui);color:#ab9fb8;margin:8px 0 4px;letter-spacing:.02em}
.ry-eq{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}
.ry-tile{min-height:58px;border-radius:10px;border:1.5px solid rgba(242,233,216,.2);background:rgba(255,255,255,.05);color:#f2e9d8;display:flex;flex-direction:column;align-items:center;justify-content:center;
  font:700 10.5px var(--f-body,system-ui);cursor:pointer;padding:3px;gap:1px;position:relative;touch-action:none;-webkit-tap-highlight-color:transparent;text-align:center}
.ry-tile .ic{width:32px;height:32px}.ry-tile .ic svg{width:100%;height:100%}
.ry-tile .n{position:absolute;right:4px;top:2px;font:800 10px var(--f-mono,monospace);color:#ffd27a}
.ry-tile.sel,.ry-wr.sel,.ry-ch.sel{outline:2px solid #e3ae45;background:rgba(227,174,69,.16)}
.ry-tile.empty{opacity:.45}
.ry-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(70px,1fr));gap:6px}
.ry-wr{display:flex;align-items:center;gap:6px;border-radius:10px;border:1.5px solid rgba(242,233,216,.18);background:rgba(255,255,255,.04);padding:4px 6px;margin-bottom:5px;cursor:pointer;touch-action:none;min-height:50px;flex-wrap:wrap}
.ry-wr .ic{width:46px;height:34px;flex:none}.ry-wr .ic svg{width:100%;height:100%}
.ry-wr .nm{flex:1;min-width:90px;font:700 12px var(--f-body,system-ui)}.ry-wr .nm small{display:block;font:600 10.5px var(--f-body,system-ui);opacity:.75}
.ry-wr.held{border-color:#e3ae45}
.ry-as{display:flex;gap:4px}
.ry-ch{width:44px;height:44px;border-radius:9px;border:1.5px dashed rgba(242,233,216,.35);background:rgba(0,0,0,.2);color:#ab9fb8;font:700 9px var(--f-body,system-ui);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;padding:1px;touch-action:none}
.ry-ch svg{width:30px;height:22px}
.ry-ch.on{border-style:solid;border-color:#7ec8ff;color:#f2e9d8;background:rgba(126,200,255,.1)}
.ry-ch.no{opacity:.28;cursor:default}
.ry-ch.drop{border-color:#7fe07a;background:rgba(127,224,122,.18)}
.ry-bar{flex:none;border-top:1px solid rgba(242,233,216,.14);padding:8px 10px;display:flex;flex-direction:column;gap:6px;background:rgba(10,9,14,.9)}
.ry-bar .inf{font:600 11.5px var(--f-body,system-ui);line-height:1.35;color:#e8dcc6}
.ry-bar .bs{display:flex;gap:6px;flex-wrap:wrap}
.ry-b{min-height:44px;padding:0 14px;border-radius:11px;border:1.5px solid rgba(242,233,216,.3);background:rgba(255,255,255,.07);color:#f2e9d8;font:700 13px var(--f-body,system-ui);cursor:pointer}
.ry-b.pri{background:#e3ae45;color:#2a1d05;border-color:#fff3cf}.ry-b.dan{border-color:#ee6a55;color:#ffb3a6}
.ry-cols{flex:1;display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:6px 8px;overflow:hidden;min-height:0}
.ry-ov.ry-inv{background:rgba(16,13,22,.975)}
.ry-land .ry-ov.ry-inv{left:var(--ry-invl,150px)}
.ry-port .ry-ov.ry-inv{bottom:var(--ry-invb,0px)}
.ry-p3{flex:1;display:grid;grid-template-columns:1fr 1fr 1.35fr;gap:6px;padding:4px 6px;overflow:hidden;min-height:0}
.ry-port .ry-p3{grid-template-columns:1fr 1fr;grid-template-rows:1fr 1.2fr}
.ry-port .ry-p3 .ry-pane.eq{grid-column:1 / 3}
.ry-pane{display:flex;flex-direction:column;min-height:0;border:1.5px solid rgba(242,233,216,.14);border-radius:10px;background:rgba(255,255,255,.03);overflow:hidden}
.ry-pane.drop{border-color:#7fe07a;background:rgba(127,224,122,.1)}
.ry-pane h4{margin:0;padding:4px 7px;font:700 12px var(--f-body,system-ui);color:#e3ae45;display:flex;justify-content:space-between;gap:4px;flex:none;border-bottom:1px solid rgba(242,233,216,.1)}
.ry-pane h4 small{font:600 10.5px var(--f-body,system-ui);color:#ab9fb8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ry-pane .ry-list{padding:4px;gap:4px}
.ry-it{min-height:44px;display:flex;align-items:center;gap:5px;border-radius:9px;border:1.5px solid rgba(242,233,216,.16);background:rgba(255,255,255,.05);color:#f2e9d8;font:700 11px var(--f-body,system-ui);padding:1px 5px;cursor:pointer;text-align:left;touch-action:pan-y;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;flex:none}
.ry-it .ic{width:30px;height:28px;flex:none;pointer-events:none}.ry-it .ic svg{width:100%;height:100%}
.ry-it .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none}.ry-it .t small{display:block;font:600 10px var(--f-body,system-ui);opacity:.75}
.ry-it.up{border-color:#7fe07a}.ry-it.dim{opacity:.55}.ry-it.sel{outline:2px solid #e3ae45;background:rgba(227,174,69,.16)}
.ry-it.held{border-color:#e3ae45}.ry-it.empty{opacity:.5;border-style:dashed}
.ry-it.lift{opacity:.35}
.ry-sub{font:700 10.5px var(--f-body,system-ui);color:#ab9fb8;padding:3px 2px 1px}
.ry-gun{border-radius:9px;border:1.5px solid rgba(242,233,216,.16);background:rgba(255,255,255,.04);padding:2px 4px 4px;flex:none}
.ry-gun.held{border-color:#e3ae45}.ry-gun.drop{border-color:#7fe07a;background:rgba(127,224,122,.14)}
.ry-gun .ry-it{border:0;background:none;padding:0;min-height:40px}
.ry-gun .ry-as{flex-wrap:wrap}
.ry-qty{position:absolute;inset:0;z-index:8;background:rgba(8,6,12,.6);display:flex;align-items:center;justify-content:center}
.ry-qty>div{background:#211b2c;border:1.5px solid rgba(242,233,216,.25);border-radius:14px;padding:10px;display:flex;flex-direction:column;gap:8px;min-width:220px;color:#f2e9d8;font:700 13px var(--f-body,system-ui)}
.ry-qty .bs{display:flex;gap:6px;flex-wrap:wrap}
.ry-ghost2{position:fixed;z-index:50;width:52px;height:44px;pointer-events:none;opacity:.9;transform:translate(-50%,-60%);background:rgba(18,16,24,.8);border:2px solid #e3ae45;border-radius:10px}.ry-ghost2 svg{width:100%;height:100%}
.ry-col{display:flex;flex-direction:column;min-height:0}
.ry-col h4{margin:2px 0 4px;font:700 12px var(--f-body,system-ui);color:#e3ae45}
.ry-list{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:4px;-webkit-overflow-scrolling:touch}
.ry-row{min-height:46px;display:flex;align-items:center;gap:5px;border-radius:9px;border:1.5px solid rgba(242,233,216,.18);background:rgba(255,255,255,.05);color:#f2e9d8;font:700 11px var(--f-body,system-ui);padding:2px 5px;cursor:pointer;text-align:left}
.ry-row .ic{width:32px;height:28px;flex:none}.ry-row .ic svg{width:100%;height:100%}
.ry-row .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ry-row .t small{display:block;font:600 10px var(--f-body,system-ui);opacity:.75}
.ry-row.up{border-color:#7fe07a}.ry-row.dim{opacity:.5}
.ry-drop{position:absolute;left:10px;right:10px;bottom:10px;height:56px;border:2px dashed #ee6a55;border-radius:12px;display:none;align-items:center;justify-content:center;color:#ffb3a6;font:700 13px var(--f-body,system-ui);background:rgba(60,10,10,.6);z-index:2}
.ry-ghost{position:fixed;z-index:50;width:48px;height:40px;pointer-events:none;opacity:.85;transform:translate(-50%,-60%)}.ry-ghost svg{width:100%;height:100%}
.ry-map canvas{flex:1;min-height:0;width:100%;touch-action:none;display:block}
.ry-mbar{display:flex;gap:5px;flex-wrap:wrap;padding:6px 8px;flex:none;align-items:center}
.ry-mbar .ry-b{padding:0 10px;font-size:12px}
.ry-mbar .ry-b.on{background:#e3ae45;color:#2a1d05}
.ry-team{position:absolute;inset:0;z-index:7;background:rgba(16,13,22,.97);color:#f2e9d8;display:flex;flex-direction:column;font:13px var(--f-body,system-ui)}
.ry-tmh{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid rgba(242,233,216,.12);flex:none;flex-wrap:wrap}
.ry-tmh b{font:400 18px var(--f-display,sans-serif);color:#e3ae45;white-space:nowrap}
.ry-tmh .grow{flex:1;min-width:120px;font:600 11.5px var(--f-body,system-ui);color:#ab9fb8}
.ry-tmh .cd{font:700 12px var(--f-mono,monospace);color:#ffd27a;white-space:nowrap}
.ry-tmg{flex:1;min-height:0;overflow-y:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;padding:8px 12px;align-content:start;-webkit-overflow-scrolling:touch}
.ry-tmc{min-height:64px;border-radius:12px;border:2px solid rgba(242,233,216,.2);background:rgba(255,255,255,.05);color:#f2e9d8;text-align:left;padding:6px 8px;cursor:pointer;display:flex;flex-direction:column;gap:5px;font:inherit}
.ry-tmc.me{border-color:#e3ae45;background:rgba(227,174,69,.16)}.ry-tmc.full{opacity:.55}
.ry-tmc .tt{display:flex;justify-content:space-between;align-items:baseline;gap:6px}.ry-tmc .tt b{font:800 14px var(--f-body,system-ui)}.ry-tmc .tt small{font:600 11px var(--f-body,system-ui);color:#ab9fb8}
.ry-tmc .ns{display:flex;flex-wrap:wrap;gap:4px}
.ry-tmc .nm{border-left:4px solid;padding:2px 6px;border-radius:6px;background:rgba(255,255,255,.08);font:700 12px var(--f-body,system-ui);max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ry-tmc .ai{padding:2px 6px;border-radius:6px;border:1px dashed rgba(242,233,216,.3);font:600 11px var(--f-body,system-ui);color:#ab9fb8}
.ry-tmf{display:flex;align-items:center;gap:6px;padding:6px 12px 8px;border-top:1px solid rgba(242,233,216,.12);flex:none;flex-wrap:wrap}
.ry-tmf .grow{flex:1;min-width:140px;font:600 11.5px var(--f-body,system-ui);color:#ab9fb8}
.ry-tmf .wait{font:700 13px var(--f-body,system-ui);color:#ffd27a;min-height:44px;display:flex;align-items:center}
.ry-keys{display:grid;grid-template-columns:1fr auto;gap:4px 10px;font:600 12.5px var(--f-body,system-ui)}
.ry-keys span:nth-child(2n){font:700 12px var(--f-mono,monospace);color:#ffd27a;text-align:right}
`;
  const PCQ = () => { try { return matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP; } catch (e) { return false; } };
  const KEYN = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: 'Space', ShiftLeft: 'Shift', ShiftRight: 'Shift', ControlLeft: 'Ctrl', Tab: 'Tab', Escape: 'Esc', Enter: 'Enter' };
  const keyName = (c) => (c ? KEYN[c] || c.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, '숫자') : '');

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root);
    let ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const COLS = L.COLORS || ['#ee6a55', '#5bb3e6', '#e8c04e', '#5fd3a0', '#b48cf0', '#f07fb8', '#9ad14f', '#f0a050'];
    const P = (s) => api.players[s] || { name: (st && st.nm && st.nm[s]) || '?', color: COLS[s % COLS.length], ai: true, lv: st && st.flv ? st.flv[s - (st.ns || 0)] || 2 : 2, fill: 1 };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const COL = (s) => P(s).color || COLS[s % COLS.length];
    let st = null, key = null, W = null, aiMem = [], vis = [], parts = [], rings = [], floats = [], feed = [], conf = [], tracers = [], decals = [], steps = [], marks = [], dmgDir = [];
    let rec = null;
    const onVol = () => { try { if (Snd.mg) Snd.mg.gain.value = Snd.vol(); } catch (e) {} };
    window.addEventListener('lounge-volume', onVol);
    let vZoom = 1, vLastSp = 0, vLook = { x: 0, y: 0 }, rcl = { x: 0, y: 0, n: 0, t: 0 };
    let flashT = 0, banner = null, shake = 0, kick = { x: 0, y: 0 }, tipT = 0, specT = -1, lastPh = -1, outT = 0, hurtT = 0, plane = null;
    const name = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    function me() { if (!st) return -1; for (let s = 0; s < (st.ns || st.np); s++) if (localHuman(s)) return s; return -1; }
    const ctrlOn = () => me() >= 0 && !auto();
    const myP = () => { const m = me(); return W && m >= 0 ? W.pl[m] : null; };
    const HC = (p) => (host() ? heldCode(p) : p.hc == null ? -1 : p.hc);
    const cam = { x: 0, y: 0, s: 16 };
    let lay = null;

    function startMatch() {
      key = st.rid;
      W = newWorld(st);
      aiMem = W.pl.map(() => ({ tg: -1, tt: Math.random() * 0.3, side: Math.random() < 0.5 ? 1 : -1 }));
      vis = W.pl.map(() => ({ hit: 0, mf: 0, ma: 0, kick: 0, step: 0, lx: NaN, ly: NaN, sw: 0 }));
      parts = []; rings = []; floats = []; feed = []; conf = []; tracers = []; decals = []; steps = []; marks = []; dmgDir = [];
      snaps = []; lastFx = 0; lastQ = -1; heavyV = -1; heavyN = 0; plane = null;
      for (const k in remIn) delete remIn[k];
      locIn.land = null; locIn.acts.length = 0; netA.length = 0; netN = 0; locAds = 0; kbv = { x: 0, y: 0 };
      banner = null; specT = -1; lastPh = -1; outT = 0; hurtT = 0; snd = []; visC = null; closeOv(); closeMenus(); bSig = ''; pickKey = ''; runLock = 0; runHeld = 0; aimHold = null;
      tipT = 0; recReset(); closeSum();
      bgKey = ''; tiles.clear();
      layout();
      const c = islandBox(); cam.x = c.x; cam.y = c.y; cam.s = lay ? lay.sd : 4;
    }
    function islandBox() {
      if (!W) return { x: 0, y: 0, r: HL };
      const lb = W.M.lobes[0], r = lb.base * Math.max(lb.sx, lb.sy) + 8;
      return { x: lb.cx, y: lb.cy, r: Math.min(HL, r) };
    }

    /* ----- layout ----- */
    function layout() {
      const w = cv.w, h = cv.h;
      const s0 = clamp(Math.min(w / 15, h / 19), 15, 38);   // ~1.4× closer than before
      const ib = islandBox();
      const sd = Math.max(1.5, Math.min((w - 16) / (2 * ib.r), (h - 170) / (2 * ib.r)));
      lay = { w, h, s0, sd };
      buildBg(); placeBtns(); showBtns();
    }
    cv.onresize = () => { layout(); tiles.clear(); };
    const onCtl = () => { placeBtns(); }; window.addEventListener('lounge-ctl', onCtl);
    const SX = (x) => lay.w / 2 + (x - cam.x) * cam.s;
    const SY = (y) => lay.h * 0.5 + (y - cam.y) * cam.s;
    const toWorld = (px, py) => ({ x: (px - lay.w / 2) / cam.s + cam.x, y: (py - lay.h * 0.5) / cam.s + cam.y });

    /* ----- static terrain (low-res whole map + high-res tiles) ----- */
    let bgCv = null, bgKey = '', bgS = 1;
    const tiles = new Map();
    function islandPath(g, lb, off, n) {
      n = n || 140;
      g.beginPath();
      for (let k = 0; k <= n; k++) { const th = k / n * 6.2832, p = lobePt(lb, th, off); if (k) g.lineTo(p[0], p[1]); else g.moveTo(p[0], p[1]); }
      g.closePath();
    }
    function paintTerrain(g, M, detail, bx0, by0, bx1, by1) {
      const T = M.T, snow = T.k === 's';
      let seed = 1 + (((11 + st.sd % 997 + Math.round(bx0 * 7 + by0 * 13) * 31) % 2147483646) + 2147483646) % 2147483646; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      g.fillStyle = snow ? '#2c6a94' : '#2f7fb8'; g.fillRect(bx0, by0, bx1 - bx0, by1 - by0);
      if (detail) { g.fillStyle = 'rgba(255,255,255,.09)'; const n = Math.round((bx1 - bx0) * (by1 - by0) / 40); for (let i = 0; i < n; i++) g.fillRect(bx0 + rnd() * (bx1 - bx0), by0 + rnd() * (by1 - by0), 0.9 + rnd(), 0.08); }
      for (const lb of M.lobes) { islandPath(g, lb, 3); g.fillStyle = snow ? '#4d8db0' : '#4fa6d4'; g.fill(); }
      for (const lb of M.lobes) { islandPath(g, lb, 1.2); g.fillStyle = snow ? '#8fc0d6' : '#7cc7e0'; g.fill(); }
      for (const lb of M.lobes) { islandPath(g, lb, 0); g.fillStyle = T.sand; g.fill(); }
      for (const lb of M.lobes) { islandPath(g, lb, -2.4); g.fillStyle = T.gr; g.fill(); }
      g.fillStyle = T.sand; for (const h of M.holes) { g.beginPath(); g.arc(h[0], h[1], h[2] + 1.3, 0, 7); g.fill(); }
      g.fillStyle = '#5bb3d8'; for (const h of M.holes) { g.beginPath(); g.arc(h[0], h[1], h[2] + 0.05, 0, 7); g.fill(); }
      g.fillStyle = '#4aa0ca'; for (const h of M.holes) { g.beginPath(); g.arc(h[0], h[1], Math.max(0.3, h[2] - 0.9), 0, 7); g.fill(); }
      for (const c of M.mud || []) { g.fillStyle = 'rgba(92,72,44,.85)'; g.beginPath(); g.arc(c[0], c[1], c[2], 0, 7); g.fill(); g.fillStyle = 'rgba(60,46,28,.6)'; g.beginPath(); g.arc(c[0] + c[2] * 0.2, c[1] - c[2] * 0.1, c[2] * 0.55, 0, 7); g.fill(); }
      for (const c of M.lava || []) {
        const gr = g.createRadialGradient(c[0], c[1], 0, c[0], c[1], c[2] + 1.2); gr.addColorStop(0, '#ffd04a'); gr.addColorStop(0.55, '#ff6a1a'); gr.addColorStop(0.85, '#a82a10'); gr.addColorStop(1, 'rgba(40,20,16,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(c[0], c[1], c[2] + 1.2, 0, 7); g.fill();
      }
      for (const c of M.hsp) { g.fillStyle = '#d8d0c0'; g.beginPath(); g.arc(c[0], c[1], c[2] + 0.6, 0, 7); g.fill(); g.fillStyle = '#5fc8c0'; g.beginPath(); g.arc(c[0], c[1], c[2], 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.arc(c[0] - c[2] * 0.3, c[1] - c[2] * 0.3, c[2] * 0.35, 0, 7); g.fill(); }
      for (const c of M.ice) { g.fillStyle = '#bfe3f2'; g.beginPath(); g.arc(c[0], c[1], c[2], 0, 7); g.fill(); g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = 0.12; for (let k = 0; k < 5; k++) { const a = rnd() * 6.28, r = rnd() * c[2] * 0.8; g.beginPath(); g.moveTo(c[0] + Math.cos(a) * r, c[1] + Math.sin(a) * r); g.lineTo(c[0] + Math.cos(a + 0.4) * (r + 2), c[1] + Math.sin(a + 0.4) * (r + 2)); g.stroke(); } }
      if (detail) {
        const n = Math.round((bx1 - bx0) * (by1 - by0) / 3);
        for (let i = 0; i < n; i++) {
          const x = bx0 + rnd() * (bx1 - bx0), y = by0 + rnd() * (by1 - by0);
          if (!landAt(M, x, y, 2.6)) continue;
          g.fillStyle = rnd() < 0.55 ? T.gr2 : snow ? 'rgba(160,180,200,.25)' : 'rgba(255,255,255,.10)';
          g.beginPath(); g.ellipse(x, y, 0.25 + rnd() * 0.6, 0.12 + rnd() * 0.25, rnd() * 3, 0, 7); g.fill();
        }
      }
      // roads, base yard, floors
      for (const q of M.roads) {
        g.save(); for (const lb of M.lobes) islandPath(g, lb, -1.2); g.clip();
        g.fillStyle = T.road; g.fillRect(q[0], q[1], q[2] - q[0], q[3] - q[1]);
        g.strokeStyle = 'rgba(255,230,150,.55)'; g.lineWidth = 0.18; g.setLineDash([1.6, 1.6]); g.beginPath();
        if (q[0] === -HL) { g.moveTo(q[0], (q[1] + q[3]) / 2); g.lineTo(q[2], (q[1] + q[3]) / 2); } else { g.moveTo((q[0] + q[2]) / 2, q[1]); g.lineTo((q[0] + q[2]) / 2, q[3]); }
        g.stroke(); g.setLineDash([]); g.restore();
      }
      for (const f of M.fence) { g.fillStyle = '#9a9a8a'; g.fillRect(f[0], f[1], f[2] - f[0], f[3] - f[1]); if (detail) { g.strokeStyle = 'rgba(0,0,0,.08)'; g.lineWidth = 0.08; for (let x = f[0]; x < f[2]; x += 4) { g.beginPath(); g.moveTo(x, f[1]); g.lineTo(x, f[3]); g.stroke(); } } }
      for (const b of M.blds) {
        g.fillStyle = b.k ? '#8d8f86' : snow ? '#b49a7e' : '#c4a27a'; g.fillRect(b.x0, b.y0, b.x1 - b.x0, b.y1 - b.y0);
        if (detail) { g.strokeStyle = 'rgba(70,45,25,.22)'; g.lineWidth = 0.06; for (let y = b.y0 + 0.8; y < b.y1; y += 0.8) { g.beginPath(); g.moveTo(b.x0, y); g.lineTo(b.x1, y); g.stroke(); } }
        for (const d of b.doors) { g.fillStyle = 'rgba(255,240,210,.5)'; g.fillRect(d[0] - (d[3] ? 1.3 : 0.6), d[1] - (d[2] ? 1.3 : 0.6), d[3] ? 2.6 : 1.2, d[2] ? 2.6 : 1.2); }
      }
    }
    function buildBg() {
      if (!lay || !W) return;
      const k = st.sd + '|' + st.mk;
      if (k === bgKey && bgCv) return;
      bgKey = k;
      bgS = 2048 / (2 * HL);
      const c = document.createElement('canvas'); c.width = c.height = 2048;
      const g = c.getContext('2d'); g.setTransform(bgS, 0, 0, bgS, HL * bgS, HL * bgS);
      paintTerrain(g, W.M, false, -HL, -HL, HL, HL);
      bgCv = c;
    }
    let tileRes = 0, tileBudget = 0;
    function getTile(tx, ty) {
      const k = tx + ',' + ty;
      let t = tiles.get(k);
      if (t) { tiles.delete(k); tiles.set(k, t); return t; }
      if (tileBudget <= 0) return null;
      tileBudget--;
      const res = tileRes, c = document.createElement('canvas'); c.width = c.height = Math.ceil(TILE * res);
      const g = c.getContext('2d'), x0 = -HL + tx * TILE, y0 = -HL + ty * TILE;
      g.setTransform(res, 0, 0, res, -x0 * res, -y0 * res);
      g.beginPath(); g.rect(x0, y0, TILE, TILE); g.clip();
      paintTerrain(g, W.M, true, x0, y0, x0 + TILE, y0 + TILE);
      tiles.set(k, c);
      while (tiles.size > 16) tiles.delete(tiles.keys().next().value);
      return c;
    }
    function drawTerrain() {
      const s = cam.s;
      ctx.fillStyle = '#2f7fb8'; ctx.fillRect(0, 0, lay.w, lay.h);
      if (bgCv) ctx.drawImage(bgCv, SX(-HL), SY(-HL), 2 * HL * s, 2 * HL * s);
      if (s * cv.dpr < 13) return;
      const res = Math.min(26, Math.round(lay.s0 * cv.dpr));
      if (res !== tileRes) { tileRes = res; tiles.clear(); }
      tileBudget = 2;
      const a = toWorld(0, 0), b = toWorld(lay.w, lay.h), NT = (2 * HL) / TILE;
      const tx0 = clamp(Math.floor((a.x + HL) / TILE), 0, NT - 1), tx1 = clamp(Math.floor((b.x + HL) / TILE), 0, NT - 1);
      const ty0 = clamp(Math.floor((a.y + HL) / TILE), 0, NT - 1), ty1 = clamp(Math.floor((b.y + HL) / TILE), 0, NT - 1);
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const t = getTile(tx, ty); if (!t) continue;
        ctx.drawImage(t, SX(-HL + tx * TILE), SY(-HL + ty * TILE), TILE * s + 0.5, TILE * s + 0.5);
      }
    }

    /* ----- input ----- */
    const locIn = { ax: 0, ay: 0, fire: 0, aim: null, ad: null, acts: [], spd: 1, land: null, ads: 0, mag: 0, sp: 0, face: null };
    let stick = null, fireBtn = null, ptAim = null, mouse = null, locAds = 0, pulse = 0, pulseAim = null;
    let kbv = { x: 0, y: 0 }, runLock = 0, runHeld = 0, edgeT = 0, kbUsed = false, aimHold = null;
    /* sprint: hold (default) · toggle · stick pushed to the edge — chosen in 「⋯」, kept on this device */
    let runModeV = (() => { try { const v = localStorage.getItem('lounge.royale.run'); return v === 'toggle' || v === 'edge' ? v : 'hold'; } catch (e) { return 'hold'; } })();
    const runMode = () => runModeV;
    let adsModeV = (() => { try { return localStorage.getItem('lounge.royale.ads') === 'toggle' ? 'toggle' : 'hold'; } catch (e) { return 'hold'; } })();
    const adsMode = () => adsModeV;
    // crouch: hold the button (default) or tap to toggle — per device
    let crModeV = (() => { try { return localStorage.getItem('lounge.royale.crouch') === 'toggle' ? 'toggle' : 'hold'; } catch (e) { return 'hold'; } })();
    const crMode = () => crModeV;
    /* view-turn smoothing (visual only: vision cone, darkness, camera lead; shots still use the real aim) */
    const VS_N = ['끔', '약', '중', '강'];
    let vsModeV = (() => { try { const v = localStorage.getItem('lounge.royale.vsmooth'); return v != null && +v >= 0 && +v <= 3 ? +v | 0 : 2; } catch (e) { return 2; } })();
    function setVsMode(v) { vsModeV = v; try { localStorage.setItem('lounge.royale.vsmooth', String(v)); } catch (e) {} }
    let vaS = null, vaP = null;
    function stepVA(v, rdt) {
      if (!v) { vaP = null; return; }
      if (v !== vaP || vaS == null || !(rdt > 0)) { vaP = v; vaS = v.a; return; }
      const d = wrapA(v.a - vaS), ad = Math.abs(d), pc = mouse && pcMode() && v === myP();
      if (!vsModeV || ad < 0.002) { vaS = v.a; return; }
      // ease-out (exponential) with an angular-speed cap that grows with the gap: big turns are quicker but never a jump
      const K = pc ? [0, 60, 45, 34][vsModeV] : [0, 20, 12, 7.5][vsModeV], MX = pc ? 40 : [0, 14, 9, 6][vsModeV];
      let st = d * (1 - Math.exp(-K * Math.min(rdt, 0.1)));
      const cap = MX * (1 + ad * 0.6) * Math.min(rdt, 0.1);
      if (Math.abs(st) > cap) st = Math.sign(st) * cap;
      vaS = wrapA(vaS + st);
    }
    const VA = (v) => (v && v === vaP && vaS != null ? vaS : v.a);
    function setCrMode(v) { crModeV = v; try { localStorage.setItem('lounge.royale.crouch', v); } catch (e) {} }
    function crDown() { if (crMode() === 'toggle') act(40); else act([40, 1]); }
    function crUp() { if (crMode() === 'hold') act([40, 2]); }
    function setAdsMode(v) { adsModeV = v; try { localStorage.setItem('lounge.royale.ads', v); } catch (e) {} }
    /* sensitivity (per device): touch aim drag / mouse (scope look-ahead) / pad right stick / move stick */
    const SENS0 = { drag: 1, mouse: 1, pad: 1, move: 1 };
    const sens = (() => { try { return Object.assign({}, SENS0, JSON.parse(localStorage.getItem('lounge.royale.sens') || '{}')); } catch (e) { return Object.assign({}, SENS0); } })();
    for (const k in SENS0) sens[k] = clamp(+sens[k] || 1, 0.3, 2);
    function setSens(k, v) { sens[k] = Math.round(clamp(v, 0.3, 2) * 10) / 10; try { localStorage.setItem('lounge.royale.sens', JSON.stringify(sens)); } catch (e) {} }
    const TURN = 14;            // aim turn speed at 1.0 (about 20% gentler than before)
    let smA = null, smSrc = '', smT = 0;
    function setRunMode(v) { runModeV = v; runLock = 0; runHeld = 0; bSig = ''; try { localStorage.setItem('lounge.royale.run', v); } catch (e) {} }
    const netA = []; let netN = 0;
    const pcMode = () => PCQ() || kbUsed;
    /* send an action: a number, or [code, a, b, c] */
    function act(code) {
      if (!ctrlOn() || !W) return;
      const c0 = Array.isArray(code) ? code[0] : code;
      if (W.ph !== 2 && c0 !== 57) return;
      const p = myP(); if (!p || p.out) return;
      if (host()) locIn.acts.push(code);
      else { netN = (netN + 1) % 100000; netA.push([netN].concat(code)); if (netA.length > 16) netA.shift(); pubT = 0; }
      api.buzz(8);
    }
    const throwing = () => { const p = myP(); return !!p && p.sl === 4 && !p.kd && p.veh < 0; };
    function kbStep(rdt) {   // keyboard / pad: smooth acceleration toward the pressed direction (free angles, no 8-way snapping)
      let tx = 0, ty = 0;
      if (api.input) { tx = api.input.axis('left', 'right'); ty = api.input.axis('up', 'down'); const m = hyp(tx, ty); if (m > 1) { tx /= m; ty /= m; } }
      const k = Math.min(1, rdt / 0.03);   // keyboard: start / stop almost at once
      kbv.x += (tx - kbv.x) * k; kbv.y += (ty - kbv.y) * k;
      if (Math.abs(kbv.x) < 0.01 && !tx) kbv.x = 0; if (Math.abs(kbv.y) < 0.01 && !ty) kbv.y = 0;
      // pushing the touch stick past its ring = sprint
      if (stick) { const d = hyp(stick.x - stick.bx, stick.y - stick.by); edgeT = d > (STICK_R0 * KC()) * 1.05 ? edgeT + rdt : 0; } else edgeT = 0;
    }
    function readIn() {
      let sx = 0, sy = 0;
      if (!(fireBtn && fireBtn.drag) && !(api.input && hyp(api.input.axis('aimL', 'aimR'), api.input.axis('aimU', 'aimD')) > 0.35)) { smSrc = ''; smA = null; smT = performance.now(); }
      if (stick) {
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy);
        const full = Math.max(14, (STICK_R0 * KC()) * 0.78 / sens.move);
        if (d > 4) { const m = Math.min(1, (d - 4) / (full - 4)); sx = dx / d * m; sy = dy / d * m; }   // small dead zone, full speed early
      }
      if (!sx && !sy && (kbv.x || kbv.y)) { const m = hyp(kbv.x, kbv.y); sx = m > 1 ? kbv.x / m : kbv.x; sy = m > 1 ? kbv.y / m : kbv.y; }
      locIn.ax = sx; locIn.ay = sy;
      const moving = hyp(sx, sy) > 0.3, rm = runMode(), rk = !!(api.input && api.input.held('sprint'));
      if (rm === 'toggle' && !moving && !stick && !kbv.x && !kbv.y) runLock = 0;     // stopping ends a toggled sprint
      locIn.sp = moving && (rm === 'toggle' ? runLock : rm === 'edge' ? edgeT > 0.12 || runHeld || rk : runHeld || rk) ? 1 : 0;
      const p = myP();
      const thr = throwing();
      let fire = (!thr && (!!fireBtn || !!(ptAim && !ptAim.look))) || !!(api.input && api.input.held('fire') && !thr);
      let aim = null, ad = null, face = null;
      if (p) {
        const mAct = !!mouse && pcMode();
        if (ptAim && ptAim.look) { const w = toWorld(ptAim.x, ptAim.y); if (hyp(w.x - p.x, w.y - p.y) > 0.4) face = Math.atan2(w.y - p.y, w.x - p.x); }   // touch on empty screen: only look, never shoot
        else if (ptAim) { const w = toWorld(ptAim.x, ptAim.y); aim = Math.atan2(w.y - p.y, w.x - p.x); ad = hyp(w.x - p.x, w.y - p.y); }
        else if (fireBtn && fireBtn.drag) { aim = turnTo('drag', fireBtn.da, p); ad = fireBtn.dl; }
        else if (api.input) {
          const rx = api.input.axis('aimL', 'aimR'), ry = api.input.axis('aimU', 'aimD');
          if (hyp(rx, ry) > 0.35) { aim = turnTo('pad', Math.atan2(ry, rx), p); face = aim; if (!thr) fire = fire || hyp(rx, ry) > 0.9; }
          else if (mAct && (api.input.held('fire') || mouse.down)) { const w = toWorld(mouse.x, mouse.y); aim = Math.atan2(w.y - p.y, w.x - p.x); ad = hyp(w.x - p.x, w.y - p.y); }
        }
        // a mouse player always faces the pointer
        if (mAct && face == null && W) { const w = toWorld(mouse.x, mouse.y); if (hyp(w.x - p.x, w.y - p.y) > 0.4) face = Math.atan2(w.y - p.y, w.x - p.x); }
        // no auto-aim: 「쏘기」 alone fires where I face; keep that aim while firing / aiming and for ~1 s after
        const now = performance.now(), fl = fire && ctrlOn() && !ovOpen();
        if (fl && aim == null && !thr) aim = aimHold && now - aimHold.t < 1000 ? aimHold.a : p.a;
        if (fl && aim != null) aimHold = { a: aim, t: now };
        else if (fireBtn && fireBtn.drag && aim != null) aimHold = { a: aim, t: now };
        if (face == null && aimHold && (now - aimHold.t < 1000 || locAds) && !(p.veh >= 0 && p.seat === 0)) face = aimHold.a;
        if (p.veh >= 0 && p.seat === 0) face = null;      // driving: eyes follow the vehicle
      }
      if (pulse > 0) { fire = true; if (pulseAim) { aim = pulseAim[0]; ad = pulseAim[1]; } }
      if (p && fin(ad)) ad = Math.min(ad, reachOf(p));
      locIn.fire = fire && ctrlOn() && !ovOpen() ? 1 : 0; locIn.aim = aim; locIn.ad = ad; locIn.ads = locAds; locIn.face = face;
    }
    /* turn the aim toward the wanted angle at a speed set by the sensitivity (touch drag / pad stick) */
    function turnTo(src, want, p) {
      const now = performance.now(), dt = clamp((now - smT) / 1000, 0, 0.1); smT = now;
      if (smSrc !== src || smA == null) { smSrc = src; smA = p.a; }
      smA = wrapA(smA + wrapA(want - smA) * Math.min(1, dt * TURN * sens[src]));
      return smA;
    }
    function startThrowAim() { if (throwing()) fireBtn.thr = true; }
    function releaseThrow() {
      const p = myP(); if (!p) return;
      pulseAim = fireBtn && fireBtn.drag ? [fireBtn.da, fireBtn.dl] : null;
      pulse = 0.16; pubT = 0;
    }
    function onDown(e) {
      if (!lay || !W) return;
      const pt = cv.local(e);
      e.preventDefault();
      closeMenus();
      if (e.pointerType === 'mouse') { mouse = { x: pt.x, y: pt.y, t: performance.now(), down: !!(mouse && mouse.down) }; }
      if (!ctrlOn()) return;
      if (W.ph === 0) { const w = toWorld(pt.x, pt.y); pickLand(w.x, w.y); return; }
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      const p = myP(); if (!p || p.out) return;
      // the minimap opens the big map
      if (W.ph >= 1 && pt.x > lay.w - MM - 12 && pt.y < MM + 14) { openMap(); return; }
      if (e.pointerType === 'mouse') {
        if (e.button === 2) { if (adsMode() === 'toggle') toggleAds(); else if (!locAds) toggleAds(); return; }
        if (e.button !== 0) return;
        if (throwing()) { pulseAim = (() => { const w = toWorld(pt.x, pt.y); return [Math.atan2(w.y - p.y, w.x - p.x), hyp(w.x - p.x, w.y - p.y)]; })(); pulse = 0.16; return; }
        mouse.down = true; ptAim = { id: e.pointerId, x: pt.x, y: pt.y }; readIn(); pubT = 0; return;   // first shot right away
      }
      if (pt.x > cv.w * 0.5) {
        ptAim = { id: e.pointerId, x: pt.x, y: pt.y, look: 1 }; tipT = Math.min(tipT, 0.5);
        return;
      }
      stick = { id: e.pointerId, bx: pt.x, by: pt.y, x: pt.x, y: pt.y };
      tipT = Math.min(tipT, 1);
    }
    function onMove(e) {
      /* chorded mouse buttons: pressing/releasing a 2nd button while one is held fires pointermove (button ≥ 0), not
         pointerdown/up — so left-click while holding right (aiming) never shot. Route those to onDown / onUp. */
      if (e.pointerType === 'mouse' && e.button >= 0) { const bit = e.button === 0 ? 1 : e.button === 2 ? 2 : e.button === 1 ? 4 : 0; if (bit) { if (e.buttons & bit) onDown(e); else onUp(e); return; } }
      const pt = cv.local(e);
      if (e.pointerType === 'mouse') { mouse = Object.assign(mouse || {}, { x: pt.x, y: pt.y, t: performance.now() }); }
      if (ptAim && ptAim.id === e.pointerId) { ptAim.x = pt.x; ptAim.y = pt.y; return; }
      if (!stick || e.pointerId !== stick.id) return;
      stick.x = pt.x; stick.y = pt.y;
      const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), mx = (STICK_R0 * KC()) * 1.3;
      if (d > mx) { stick.bx = stick.x - dx / d * mx; stick.by = stick.y - dy / d * mx; }
    }
    function onUp(e) {
      if (e.pointerType === 'mouse' && e.button === 2 && adsMode() === 'hold' && locAds) toggleAds();
      const rOnly = e.pointerType === 'mouse' && e.button === 2;   // letting go of the aim button keeps a held left button firing
      if (ptAim && ptAim.id === e.pointerId && !rOnly) ptAim = null;
      if (mouse && e.pointerType === 'mouse' && !rOnly) mouse.down = false;
      if (stick && e.pointerId === stick.id) stick = null;
    }
    /* wheel: several things on the ground in reach → choose which one F picks (outlined); otherwise switch weapons */
    function onWheel(e) {
      if (!ctrlOn() || !W || W.ph !== 2 || ovOpen()) return; e.preventDefault();
      const p = myP(); if (p && p.veh < 0 && nearItems(p).length > 1) { cyclePick(e.deltaY > 0 ? 1 : -1); return; }
      nextWeapon(e.deltaY > 0 ? 1 : -1);
    }
    function pickLand(x, y) {
      if (!W || W.ph !== 0) return;
      let s = [clamp(x, -HL + 3, HL - 3), clamp(y, -HL + 3, HL - 3)];
      if (!landAt(W.M, s[0], s[1], 1)) s = snapFree(W.M, s[0], s[1]);
      locIn.land = s; pubT = 0;
      const p = myP(); if (p) { p.lx = s[0]; p.ly = s[1]; }
      sfx('tick', 30); api.buzz(8); tipT = Math.min(tipT, 4);
    }
    function toggleAds() {
      const p = myP(); if (!p || p.out) return;
      locAds = locAds ? 0 : 1; sfx('click', 40); api.buzz(6);
      if (locAds) aimHold = { a: p.a, t: performance.now() };
    }
    function nextWeapon(dir) {
      const p = myP(); if (!p) return;
      for (let k = 1; k <= 4; k++) { const s = ((p.sl + dir * k) % 5 + 5) % 5; if ((s <= 2 && p.g[s]) || s === 3 || (s === 4 && p.th.some((n) => n > 0))) { act(4 + s); break; } }
    }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    cv.cv.addEventListener('wheel', onWheel, { passive: false });

    /* ----- buttons (thumb layout: right thumb = fire cluster, left thumb = stick) ----- */
    const btn = {};
    const vib = (ms) => { try { if (navigator.vibrate && !pcMode()) navigator.vibrate(ms); } catch (e) {} };
    const bindKey = (id) => { try { if (typeof L !== 'undefined' && L.ui && typeof L.ui.keyLabel === 'function') { const t = L.ui.keyLabel('royale', id); if (t) return String(t); } const b = api.input && api.input.bindings ? api.input.bindings().find((x) => x.id === id) : null; return b && b.keys[0] ? keyName(b.keys[0]) : ''; } catch (e) { return ''; } };
    function mkBtn(cls, label, down, up, move, kid) {
      const b = L.h('button', { class: 'ry-btn ' + cls, type: 'button', 'aria-label': label }, L.h('span', { class: 'lb', text: label }), L.h('small', { text: '' }));
      if (kid) { const k = L.h('span', { class: 'k', text: bindKey(kid) }); b.appendChild(k); b._k = k; b._kid = kid; }
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); closeMenus(b); try { b.setPointerCapture(e.pointerId); } catch (er) {} b.classList.add('on'); vib(6); down(e); });
      if (move) b.addEventListener('pointermove', move);
      const off = (e) => { if (!b.classList.contains('on')) return; b.classList.remove('on'); if (up) up(e); };
      b.addEventListener('pointerup', off); b.addEventListener('pointercancel', off); b.addEventListener('lostpointercapture', off);
      b.addEventListener('contextmenu', noCtx);
      root.appendChild(b);
      return b;
    }
    btn.fire = mkBtn('ry-fire', '쏘기', (e) => { fireBtn = { id: e.pointerId, x0: e.clientX, y0: e.clientY, drag: false, da: 0, dl: null, thr: false }; startThrowAim(); tipT = Math.min(tipT, 0.5); },
      () => { if (fireBtn && fireBtn.thr && throwing()) releaseThrow(); fireBtn = null; },
      (e) => {
        if (!fireBtn || fireBtn.id !== e.pointerId) return;
        const dx = e.clientX - fireBtn.x0, dy = e.clientY - fireBtn.y0, d = hyp(dx, dy);
        if (d > 14) { fireBtn.drag = true; fireBtn.da = Math.atan2(dy, dx); fireBtn.dl = fireBtn.thr ? clamp(3 + (d - 14) * 0.28, 3, 26) : null; }
        else if (fireBtn.drag && d < 8) fireBtn.drag = false;
      }, 'fire');
    btn.ads = mkBtn('ry-round ry-ads', '조준', () => toggleAds(), null, null, 'ads');
    btn.rl = mkBtn('ry-round ry-rl', '장전', () => act(1), null, null, 'reload');
    btn.cr = mkBtn('ry-round ry-cr', '앉기', () => crDown(), () => crUp(), null, 'crouch');
    btn.heal = mkBtn('ry-round ry-heal', '치료', () => act(3), null, null, 'heal');
    // weapon tiles: tap = hold it · swipe left/right on any tile = previous/next weapon
    let swipe = null;
    btn.s = [0, 1, 2, 3, 4].map((k) => {
      const b = mkBtn('ry-slot', String(k + 1), (e) => { swipe = { x: e.clientX, k, done: false }; },
        () => { if (swipe && !swipe.done) act(4 + k); swipe = null; },
        (e) => { if (!swipe || swipe.done) return; const dx = e.clientX - swipe.x; if (Math.abs(dx) > 26) { swipe.done = true; nextWeapon(dx > 0 ? 1 : -1); } }, 'slot' + (k + 1));
      b.insertBefore(L.h('span', { class: 'ic' }), b.firstChild);
      return b;
    });
    btn.more = mkBtn('ry-top', '⋯', () => toggleMore(), null, null, 'keys');
    btn.inv = mkBtn('ry-top', '🎒', () => openInv(), null, null, 'inv');
    /* separate context buttons — each shows only when it can be used, always at the same place */
    btn.cv = mkBtn('ry-cx blue', '🚗 타기', () => ctxDo('v'), null, null, 'ride');
    let doorLP = null;
    btn.cd = mkBtn('ry-cx', '🚪 문 열기', () => {
      const c = ctxs().door; if (!c) return;
      doorLP = { j: c.j, done: false, tm: setTimeout(() => { const p = myP(); if (doorLP && p && canLock(W, p, doorLP.j)) { doorLP.done = true; act([44, doorLP.j]); vib(30); sfx('click', 40); } }, 450) };
    }, () => { if (doorLP) { clearTimeout(doorLP.tm); if (!doorLP.done) act([2, 3, doorLP.j]); doorLP = null; } }, null, 'door');
    btn.cw = mkBtn('ry-cx blue', '🪟 창문 넘기', () => ctxDo('w'), null, null, 'vault');
    btn.cb = mkBtn('ry-cx', '💀 열기', () => ctxDo('b'), null, null, 'open');
    btn.cr2 = mkBtn('ry-cx red', '🩹 살리기', () => ctxDo('r'));
    btn.run = mkBtn('ry-round ry-run', '달리기', () => { if (runMode() === 'toggle') runLock = runLock ? 0 : 1; else runHeld = 1; sfx('click', 40); }, () => { runHeld = 0; }, null, 'sprint');
    /* pickup bar: ‹ [item name ▾ = list] [🎒 줍기] › */
    let pickSel = 0;
    const pickEl = L.h('div', { class: 'ry-pick' });
    const pkPrev = L.h('button', { type: 'button', class: 'ar', 'aria-label': '이전 물건', text: '‹' });
    const pkName = L.h('button', { type: 'button', class: 'nm', 'aria-label': '주변 물건 목록' });
    const pkGo = L.h('button', { type: 'button', class: 'go' });
    const pkNext = L.h('button', { type: 'button', class: 'ar', 'aria-label': '다음 물건', text: '›' });
    [pkPrev, pkName, pkGo, pkNext].forEach((b) => { pickEl.appendChild(b); b.addEventListener('pointerdown', (e) => { e.stopPropagation(); vib(6); }); b.addEventListener('contextmenu', noCtx); });
    pkPrev.addEventListener('click', () => cyclePick(-1)); pkNext.addEventListener('click', () => cyclePick(1));
    pkName.addEventListener('click', () => openInv(true)); pkGo.addEventListener('click', () => pickNow());
    root.appendChild(pickEl);
    btn.ping = mkBtn('ry-mini ry-pingb', '핑', () => togglePingMenu(), null, null, 'ping');
    btn.next = mkBtn('ry-next', '다른 사람 보기 ▶', () => nextSpec(), null, null, 'next');
    /* every person is out: the host can end the match now (bots ranked by kills, then health) → result → 한 판 더 */
    const humansOut = () => !!W && !!st && (st.hu || []).length > 0 && (st.hu || []).every((i) => !W.pl[i] || W.pl[i].out);
    btn.skip = mkBtn('ry-next', '⏭ 바로 다음 판', () => { if (host() && W && W.ph === 2 && !W.res && humansOut()) { finish(W, hooks); sfx('click', 40); } });
    btn.skip.style.bottom = '72px';
    btn.sum = mkBtn('ry-next', '🗺 경기 요약', () => openSum());
    btn.sum.style.bottom = '124px';
    // shooting range only
    btn.rg = [mkBtn('ry-rgb', '🔫 총 고르기', () => openRangeGun()), mkBtn('ry-rgb', '🔧 부착물', () => openRangeAtt()), mkBtn('ry-rgb', '🌙 밤↔낮', () => act([62])), mkBtn('ry-rgb', '🎯 초기화', () => { act([63]); prDps.length = 0; })];
    btn.rg.push(mkBtn('ry-rgb', '🧰 연습 도구', () => openPractice()));
    function nextSpec() {
      if (!W) return;
      const al = W.pl.filter((q) => !q.out).map((q) => q.i);
      if (!al.length) return;
      specT = al[(al.indexOf(specT) + 1) % al.length]; sfx('tick', 30);
    }
    /* place the buttons. Landscape (main): stick bottom-left, fire cluster bottom-right, context column right-middle,
       weapons / health / minimap along the top. Portrait (fallback): the old phone layout. */
    const landQ = () => !!lay && lay.w > lay.h;
    const hpW = () => clamp(Math.round(lay.w * 0.28), 150, 220);
    let colX = 0, colY = 0;
    function pos(b, o) { for (const k of ['left', 'right', 'top', 'bottom', 'width', 'height']) b.style[k] = o[k] == null ? '' : typeof o[k] === 'number' ? o[k] + 'px' : o[k]; }
    function placeBtns() {
      if (!lay) return;
      const w = lay.w, h = lay.h, land = landQ();
      MM = land ? clamp(Math.round(h * 0.26), 70, 104) : 92;
      root.classList.toggle('ry-land', land); root.classList.toggle('ry-port', !land);
      // 조작 크기(라운드 33): 오른쪽 아래 행동 버튼 묶음을 통째로 확대/축소(zoom이 크기와 위치를 함께 곱함). 가로는 위쪽 버튼과 안 겹치게 상한.
      const z = clamp(land ? Math.min(KC(), (h - 110) / 222) : Math.min(KC(), (h - MM - 90) / 228), 0.7, 1.5);
      for (const k of ['fire', 'rl', 'ads', 'run', 'cr', 'heal']) btn[k].style.zoom = String(z);
      if (land) {
        pos(btn.fire, { right: 12, bottom: 12, width: 84, height: 84 });
        pos(btn.rl, { right: 104, bottom: 10 }); pos(btn.ads, { right: 104, bottom: 70 });
        pos(btn.run, { right: 28, bottom: 108 }); pos(btn.cr, { right: 88, bottom: 132 }); pos(btn.heal, { right: 28, bottom: 168 });
        const sw = 54, gap = 4, x0 = hpW() + 16, room = w - MM - 16 - 52 - x0, k = Math.min(1, room / (5 * sw + 4 * gap));
        const bw = Math.max(44, Math.floor(sw * k));
        btn.s.forEach((b, i) => pos(b, { left: x0 + i * (bw + gap), top: 4, width: bw, height: 44 }));
        pos(btn.inv, { right: MM + 16, top: 6 }); pos(btn.more, { right: MM + 16, top: 54 });
        // context column (fixed rows): 탈것 · 문 · 창문 · 시체/상자 · 살리기
        colX = Math.max(160, Math.round(158 * z) + 4); colY = 56;
        [btn.cv, btn.cd, btn.cw, btn.cb].forEach((b, i) => pos(b, { right: colX, top: colY + i * 48 }));
        pos(btn.cr2, { right: colX + 118 + 8, top: colY });
        const pl = Math.max(140, Math.round(w * 0.24)), pr = w - Math.round(168 * z);
        pos(pickEl, { left: pl, bottom: 8, width: Math.min(330, pr - pl) });
        root.style.setProperty('--ry-invl', Math.round(Math.min(170, w * 0.22)) + 'px');
      } else {
        for (const k of ['fire', 'rl', 'ads', 'run', 'cr', 'heal']) pos(btn[k], {});
        const y0 = MM + 18;
        btn.s.forEach((b, i) => pos(b, { right: 8 + (4 - i) * 56, top: y0, width: 52, height: 44 }));
        pos(btn.inv, { right: MM + 16, top: 6 }); pos(btn.more, { right: MM + 16, top: 54 });
        const cb0 = Math.max(236, Math.round(228 * z) + 8);
        [btn.cv, btn.cd, btn.cw, btn.cb, btn.cr2].forEach((b, i) => pos(b, { right: 12, bottom: cb0 + i * 48 }));
        pos(pickEl, { left: 8, bottom: cb0, width: Math.max(150, Math.min(300, w - 150)) });
        root.style.setProperty('--ry-invb', '170px');
      }
      if (land) { btn.ping.style.right = (MM + 16) + 'px'; btn.ping.style.top = '102px'; }   // landscape: under 「⋯」, not over the minimap
      else { btn.ping.style.right = (MM + 8 - 44) + 'px'; btn.ping.style.top = (MM + 8 - 44) + 'px'; }
      btn.rg.forEach((b, k) => { b.style.top = ((land ? 96 : 178) + k * 50) + 'px'; });
      root.classList.toggle('ry-pc', pcMode());
      for (const k in btn) { const b = btn[k]; if (Array.isArray(b)) b.forEach(upKey); else upKey(b); }
    }
    function upKey(b) { if (b && b._k) { const t = bindKey(b._kid); if (b._k.textContent !== t) b._k.textContent = t; } }
    function showBtns() {
      const p = myP(), play = ctrlOn() && W && W.ph === 2 && p && !p.out;
      const drv = play && p.veh >= 0 && p.seat === 0, kd = play && p.kd;
      const gunUI = play && !kd;
      const drvGun = drv && heldGun(p) && OH(heldGun(p).t);
      btn.fire.style.display = gunUI && (!drv || drvGun) ? '' : 'none';
      for (const k of ['ads', 'heal', 'cr']) btn[k].style.display = gunUI && !drv ? '' : 'none';
      btn.rl.style.display = gunUI && (!drv || drvGun) ? '' : 'none';
      btn.s.forEach((b) => { b.style.display = gunUI && !drv ? '' : 'none'; });
      btn.more.style.display = play ? '' : 'none';
      btn.inv.style.display = play ? '' : 'none';
      btn.rg.forEach((b, k) => { b.style.display = play && W.rg && (k < 4 || W.pr) ? '' : 'none'; });
      btn.run.style.display = play && !kd && (p.veh < 0 || (drv && VEH[W.vh[p.veh].ty].ped)) ? '' : 'none';
      btn.ping.style.display = W && W.ph >= 1 && ctrlOn() && p && !p.out ? '' : 'none';
      if (!play || kd) { for (const b of [btn.cv, btn.cd, btn.cw, btn.cb, btn.cr2]) b.style.display = 'none'; pickEl.style.display = 'none'; }
      if (!play && pmenu) closeMenus();
      btn.next.style.display = W && W.ph === 2 && (!ctrlOn() || (p && p.out)) && W.pl.some((q) => !q.out) && !auto() && me() >= 0 ? '' : 'none';
      btn.sum.style.display = W && sumReady() && (W.ph === 3 || (st && st.ph === 'done') || (p && p.out)) ? '' : 'none';
      btn.skip.style.display = W && W.ph === 2 && !W.res && !W.rg && me() >= 0 && host() && humansOut() ? '' : 'none';
      if (!play && ovOpen() && !(W && W.ph === 2 && p && !p.out)) closeOv();
    }
    let bSig = '';
    function setBtn(b, t, s) { const lb = b.querySelector('.lb'), sm = b.querySelector('small'); if (lb.textContent !== t) lb.textContent = t; if (sm.textContent !== s) sm.textContent = s; }
    function setIc(b, html) { const ic = b.querySelector('.ic'); if (ic && ic._h !== html) { ic._h = html; ic.innerHTML = html; } }
    function slotLabel(p, k) {
      if (k <= 2) { const w = p.g[k]; return w ? [GUN[w.t].nm, w.m + '/' + p.am[GUN[w.t].am], RARC[irar(w.t)], ICON(w.t)] : [k === 2 ? '권총' : (k + 1) + '번 총', '비었음', null, '']; }
      if (k === 3) return [p.ml >= 0 ? MELEE[p.ml].nm : '주먹', '근접', null, p.ml >= 0 ? ICON(I_MEL + p.ml) : fistSVG()];
      const n = p.th[p.ts]; return [n > 0 ? THROW[p.ts].sn : '투척', n > 0 ? '×' + n + (p.th.filter((c) => c > 0).length > 1 ? ' ↻' : '') : '없음', null, n > 0 ? ICON(I_THR + p.ts) : ''];
    }
    /* everything I can do around me right now, each separately (vehicle, door, window, box/body, revive) */
    let cxs = {};
    function ctxs() {
      const p = myP(), o = {};
      if (!p || !W || W.ph !== 2 || p.out || p.kd || p.air > 0 || p.vt > 0) return o;
      if (p.veh >= 0) { o.veh = { k: 'x' }; return o; }
      if (W.tm) for (const q of W.pl) if (q !== p && q.tm === p.tm && q.kd && !q.out && hyp(q.x - p.x, q.y - p.y) < 1.9) { o.rev = { i: q.i }; break; }
      if (W.tm && !o.rev && W.rcOpen && tagOf(W, p.i) && p.ut !== 10) { const tj = nearTower(W, p.x, p.y, RC.r); if (tj >= 0) o.tw = { j: tj }; }
      const d = nearDoor(W, p, DOOR_R); if (d >= 0) o.door = { j: d, open: !!W.ds[d], lock: W.dl[d] > 0 };
      const wi = nearWin(W, p, WIN_R); if (wi >= 0) o.win = { j: wi };
      const b = nearBox(W, p); if (b >= 0) o.box = { j: b };
      let bj = -1, bd = 1e9;
      W.vh.forEach((v, j) => {
        if (v.hp <= 0) return;
        const dv = hyp(v.x - p.x, v.y - p.y);
        if (dv > VEH[v.ty].r + 1.7 || dv >= bd || freeSeat(W, j) < 0) return;
        for (const q of W.pl) if (!q.out && q.veh === j && q.tm !== p.tm) return;
        bd = dv; bj = j;
      });
      if (bj >= 0) o.veh = { k: 'v', j: bj };
      return o;
    }
    function ctxDo(k) {
      const c = cxs;
      if (k === 'v' && c.veh) { if (c.veh.k === 'x') act([2, 1]); else act([2, 6, c.veh.j]); }
      else if (k === 'd' && c.door) act([2, 3, c.door.j]);
      else if (k === 'w' && c.win) act([2, 5, c.win.j]);
      else if (k === 'b' && c.box) openInv(true);
      else if (k === 'r' && c.rev) act([2, 2, c.rev.i]);
      else if (k === 'r' && c.tw) act([2, 7, c.tw.j]);
    }
    /* F: open a body / crate → the 「주변」 pane; else pick the chosen ground item; else revive */
    function keyOpen() {
      const c = cxs;
      if (c.box) { openInv(true); return; }
      if (nearItems(myP()).length) { pickNow(); return; }
      if (c.rev) act([2, 2, c.rev.i]);
      else if (c.tw) act([2, 7, c.tw.j]);
    }
    const pickIt = (it, n) => act(n > 0 && n < it.n ? [58, it.t * 1000 + n, Math.round(it.x * 10), Math.round(it.y * 10)] : [50, it.t, Math.round(it.x * 10), Math.round(it.y * 10)]);
    const itKey = (it) => it.t + '@' + it.x + ',' + it.y;
    let pickKey = '', pickList = [];
    let pickHov = true, pickHK = '';   // selection follows the mouse (true) or a wheel / ‹ › choice (false)
    function pickUnder(list) {   // PC: the ground item whose icon is under (or closest to) the cursor
      if (!mouse || !pcMode() || ovOpen() || !list.length) return -1;
      const R = Math.max(16, cam.s * 0.75); let bj = -1, bd = R * R;
      list.forEach((it, j) => { const dx = SX(it.x) - mouse.x, dy = SY(it.y) - mouse.y, d = dx * dx + dy * dy; if (d <= bd) { bd = d; bj = j; } });
      return bj;
    }
    function pickCur() {
      const p = myP(); pickList = nearItems(p); if (!pickList.length) { pickSel = 0; return null; }
      let j = pickUnder(pickList);
      if (j >= 0) {   // a new item under the cursor takes over; the same one keeps a wheel choice (stacked items)
        const hk = itKey(pickList[j]);
        if (hk !== pickHK) { pickHK = hk; pickHov = true; }
        else if (!pickHov) { const w = pickList.findIndex((i) => itKey(i) === pickKey); if (w >= 0) j = w; }
      } else {
        pickHK = '';
        j = pickHov ? -1 : pickList.findIndex((i) => itKey(i) === pickKey);
        if (j < 0) { j = 0; pickList.forEach((it, i) => { if (it.d < pickList[j].d) j = i; }); }
      }
      pickSel = j; pickKey = itKey(pickList[j]); return pickList[j];
    }
    function cyclePick(d) { pickCur(); if (pickList.length < 2) return; pickHov = false; pickSel = (pickSel + d + pickList.length) % pickList.length; pickKey = itKey(pickList[pickSel]); bSig = ''; sfx('tick', 30); }
    function pickNow() { const it = pickCur(); if (it) pickIt(it); }
    function syncBtns() {
      showBtns();
      const p = myP(); if (!p || !ctrlOn() || !W || W.ph !== 2 || p.out) { cxs = {}; return; }
      const w = heldGun(p), hp = healPick(p);
      cxs = p.kd ? {} : ctxs();
      const c = cxs, it = p.kd || p.veh >= 0 ? null : pickCur();
      const csig = (c.veh ? c.veh.k + c.veh.j : '') + '/' + (c.door ? c.door.j + (c.door.open ? 'o' : '') + (c.door.lock ? 'l' : '') + (canLock(W, p, c.door.j) ? 'k' : '') : '') + '/' + (c.win ? c.win.j : '') + '/' + (c.box ? c.box.j + ':' + (W.bx[c.box.j] ? W.bx[c.box.j].it.length : 0) : '') + '/' + (c.rev ? c.rev.i : c.tw ? 't' + c.tw.j : '') + '/' + (it ? itKey(it) + ':' + it.n + ':' + pickList.length + ':' + pickSel : '') + '/' + ovKind;
      const sig = [p.sl, JSON.stringify(p.g), p.ml, p.th.join(), p.ts, p.am.join(), p.rl > 0 ? 1 : 0, p.use > 0 ? p.ut : -2, csig, hp, p.hl.join(), p.ads, locAds, p.veh, p.seat, p.kd, p.cr, runLock, runHeld, runMode(), p.lk > 0 ? 1 : 0, pcMode()].join('|');
      if (sig === bSig) return;
      bSig = sig;
      const code = heldCode(p);
      if (p.sl === 4) setBtn(btn.fire, THROW[p.ts].sn, '끌어서 던지기');
      else if (w) setBtn(btn.fire, GUN[w.t].nm, p.rl > 0 ? '장전 중' : w.m + ' / ' + p.am[GUN[w.t].am]);
      else setBtn(btn.fire, code >= 0 ? iname(code) : '주먹', '휘두르기');
      btn.fire.style.borderColor = w ? RARC[irar(w.t)] : '';
      const sc = w ? scW(w) : 0;
      setBtn(btn.ads, p.ads || locAds ? '조준 ●' : '조준', w ? SCN[sc] : '');
      btn.ads.classList.toggle('lit', !!locAds);
      btn.ads.classList.toggle('off', !w);
      setBtn(btn.rl, '장전', w ? AMMO[GUN[w.t].am].nm : '');
      btn.rl.classList.toggle('off', !w || w.m >= magW(w) || p.am[GUN[w.t].am] <= 0);
      setBtn(btn.cr, p.cr && crMode() === 'toggle' ? '일어서기' : '앉기', p.cr ? '앉음' : '');
      btn.cr.classList.toggle('lit', !!p.cr);
      setBtn(btn.heal, p.use > 0 && p.ut >= 0 && p.ut < 9 ? '취소' : '치료', hp >= 0 ? HEAL[hp].nm.slice(0, 4) + ' ' + p.hl[hp] : '없음');
      btn.heal.classList.toggle('off', hp < 0 && !(p.use > 0));
      const rm = runMode();
      setBtn(btn.run, rm === 'toggle' && runLock ? '달리기 ●' : '달리기', rm === 'toggle' ? (runLock ? '켜짐' : '꺼짐') : rm === 'edge' ? '끝까지' : '누르기');
      btn.run.classList.toggle('lit', !!(runLock && rm === 'toggle'));
      btn.s.forEach((b, k) => {
        const [a, s2, col, ic] = slotLabel(p, k);
        setBtn(b, a, s2); setIc(b, ic);
        setTip(b, -1);
        b.classList.toggle('act', p.sl === k);
        b.classList.toggle('off', (k <= 2 && !p.g[k]) || (k === 4 && !p.th.some((n) => n > 0)));
        b.style.borderColor = col || '';
      });
      const showC = (b, on, t) => { b.style.display = on ? '' : 'none'; if (on) setBtn(b, t, ''); };
      const inVeh = p.veh >= 0;
      showC(btn.cv, !!c.veh, c.veh ? (c.veh.k === 'x' ? '🚗 내리기' : '🚗 ' + VEH[W.vh[c.veh.j].ty].nm + ' 타기') : '');
      showC(btn.cd, !!c.door && !inVeh, c.door ? (c.door.lock ? '🔒 잠긴 문' : c.door.open ? '🚪 문 닫기' : '🚪 문 열기') : '');
      btn.cd.classList.toggle('lp', !!c.door && canLock(W, p, c.door.j));
      showC(btn.cw, !!c.win && !inVeh, '🪟 창문 넘기');
      const bx = c.box ? W.bx[c.box.j] : null;
      showC(btn.cb, !!bx && !inVeh, bx ? (bx.ad ? '📦 보급 열기' : '💀 열기') : '');
      showC(btn.cr2, !!(c.rev || c.tw) && !inVeh, c.rev ? '🩹 ' + name(c.rev.i) : c.tw ? '📡 귀환 호출' : '');
      // pickup bar
      pickEl.style.display = it && !ovOpen() ? '' : 'none';
      if (it) {
        const up = better(p, it.t), k = ikind(it.t);
        pkName.innerHTML = '';
        const ic = L.h('span', { class: 'ic' }); ic.innerHTML = ICON(it.t); pkName.appendChild(ic);
        setTip(pkName, -1);
        pkName.appendChild(L.h('span', { class: 't', text: iname(it.t) + (it.n > 1 && k !== 'g' ? ' ×' + it.n : '') }, L.h('small', { text: (pickList.length > 1 ? (pickSel + 1) + '/' + pickList.length + ' · ' : '') + '목록 ▾' })));
        pkGo.innerHTML = ''; pkGo.appendChild(L.h('span', { text: k === 'g' && !gunFits(p, it.t) ? '🎒 바꾸기' : '🎒 줍기' })); pkGo.appendChild(L.h('span', { class: 'k', text: bindKey('open') }));
        pkGo.classList.toggle('up', up);
        pkPrev.style.display = pkNext.style.display = pickList.length > 1 ? '' : 'none';
      }
    }
    const gunFits = (p, t) => (GUN[t].c === 0 ? !p.g[2] : !p.g[0] || !p.g[1]);
    /* ----- nearby ground items (tap to pick) ----- */
    const CATO = { g: 0, v: 1, e: 1, b: 1, a: 2, h: 3, t: 4, o: 5, m: 6 };
    function better(p, t) {   // ▲ = clearly useful for me
      const k = ikind(t);
      if (k === 'g') return gunFits(p, t) || GUN[t].v > Math.min(gunVal(p, p.g[0]), gunVal(p, p.g[1])) + 0.8;
      if (k === 'v') return t - I_VEST + 1 > p.vs; if (k === 'e') return t - I_HELM + 1 > p.hm; if (k === 'b') return t - I_BAG + 1 > p.bp;
      if (k === 'a') return p.g.some((w) => w && attBetter(w, t - I_ATT));
      if (k === 's') return !p.spc;
      if (k === 'o') return usesAmmo(p, t - I_AMMO);
      if (k === 'm') return p.ml < 0;
      return true;
    }
    function nearItems(p) {
      const out = [];
      if (!p || p.out || p.kd || p.veh >= 0 || !W || W.ph !== 2) return out;
      eachLoot(W, p.x, p.y, PICK_R, (l, kind) => { if (kind !== 2) out.push({ t: l.t, n: l.n, x: l.x, y: l.y, d: hyp(l.x - p.x, l.y - p.y) }); return false; });
      out.sort((a, b) => (better(p, b.t) - better(p, a.t)) || (CATO[ikind(a.t)] - CATO[ikind(b.t)]) || a.d - b.d);
      return out;
    }
    /* ----- overlays: inventory (Tab), big map (M), key guide ----- */
    let ov = null, ovKind = '', ovSel = null, ovSig = '', mapSt = { k: 3, z: 1, cx: 0, cy: 0 }, pmenu = null, qtyEl = null;
    const ovOpen = () => !!ov;
    function closeOv() { if (ov) { ov.remove(); ov = null; ovKind = ''; ovSel = null; ovSig = ''; } if (drag) endDrag(); if (qtyEl) { qtyEl.remove(); qtyEl = null; } }
    function closeMenus(except) { if (pmenu && !(except && (except === btn.ping || except === btn.more))) { pmenu.remove(); pmenu = null; } }
    function mkOv(kind, title, extra) {
      closeOv(); closeMenus();
      ovKind = kind;
      const x = L.h('button', { type: 'button', class: 'ry-x', 'aria-label': '닫기', onclick: () => closeOv() }, '✕', L.h('small', { text: kind === 'inv' ? bindKey('inv') : kind === 'map' ? bindKey('map') : 'Esc' }));
      const head = L.h('div', { class: 'ry-ovh' }, L.h('b', { text: title }), L.h('div', { class: 'grow' }, extra || null), x);
      ov = L.h('div', { class: 'ry-ov ry-' + kind }, head);
      ov.addEventListener('pointerdown', (e) => e.stopPropagation());
      ov.addEventListener('contextmenu', noCtx);
      root.appendChild(ov);
      if (kind !== 'inv') { stick = null; fireBtn = null; ptAim = null; }   // the bag leaves the stick free: keep walking while sorting
      fireBtn = null; ptAim = null;
      return ov;
    }
    const icSpan = (html, cls) => { const s = L.h('span', { class: cls || 'ic' }); s.innerHTML = html; return s; };
    const wtBar = (p) => { const w = wtOf(p), c = capOf(p); return L.h('div', null, L.h('span', { class: 'ry-wt', text: '무게 ' + Math.round(w) + ' / ' + c }), L.h('div', { class: 'ry-wbar' }, L.h('i', { style: { width: Math.min(100, w / c * 100) + '%', background: w > c * 0.9 ? '#ee6a55' : '#9ad14f' } }))); };
    /* numbers for one attachment on a given gun */
    function attEff(ai, t) { const A = ATT[ai], G = t != null ? GUN[t] : null; return A.nm + ': ' + attText(A) + (G && A.mg ? ' (' + G.mg + ' → ' + Math.round(G.mg * A.mg) + '발)' : ''); }
    /* what lies around me: the nearest body / crate (opened into the list) + the ground within reach */
    function nearAll(p) {
      const out = [], bj = nearBox(W, p), b = bj >= 0 ? W.bx[bj] : null;
      if (b) b.it.forEach((e) => out.push({ t: e[0], n: e[1], x: b.x, y: b.y, box: b.ad ? 2 : 1 }));
      for (const it of nearItems(p)) out.push(it);
      return out;
    }
    function invSig(p) { return [JSON.stringify(p.g), p.ml, p.th.join(), p.hl.join(), p.am.join(), p.at.join(), p.vs, p.hm, p.bp, p.spc, p.sl, p.ts, JSON.stringify(ovSel), p.use > 0 ? p.ut : -1, nearAll(p).map((i) => i.t + ':' + i.n + ':' + (i.box || 0)).join(',')].join('|'); }
    function openInv(keep) { const p = myP(); if (!p || p.out || !W || W.ph !== 2) return; if (ovKind === 'inv') { if (!keep) closeOv(); return; } mkOv('inv', '소지품'); ovSel = null; renderInv(); sfx('card', 40); }
    const STACK = { o: 1, h: 1, t: 1, a: 1 };
    const selIs = (o) => !!ovSel && JSON.stringify(ovSel) === JSON.stringify(o);
    function invRow(what, t, title, sub, cls) {
      const r = L.h('div', { class: 'ry-it' + (cls ? ' ' + cls : '') + (selIs(what) ? ' sel' : ''), role: 'button' });
      r.appendChild(icSpan(t >= 0 ? ICON(t) : ''));
      r.appendChild(L.h('span', { class: 't', text: title }, L.h('small', { text: sub || '' })));
      setTip(r, t, what && what.n, what && what.src === 'eq' && what.k === 'g' ? { s: what.s } : null);
      dragSrc(r, what);
      return r;
    }
    function renderInv() {
      const p = myP(); if (!p || !ov || ovKind !== 'inv') return;
      if (p.kd) { closeOv(); return; }
      if (qtyEl && qtyEl.parentNode === ov) return;   // "how many?" is open: a rebuild would wipe it (it redraws once it closes)
      const sig = invSig(p); if (sig === ovSig) return; ovSig = sig;
      if (drag && drag.on) return;          // don't rebuild under a finger that is dragging
      while (ov.childNodes.length > 1) ov.removeChild(ov.lastChild);
      const head = ov.firstChild.querySelector('.grow'); head.innerHTML = ''; head.appendChild(wtBar(p));
      const cols = L.h('div', { class: 'ry-p3' });
      // 주변
      const near = nearAll(p), pn = L.h('div', { class: 'ry-pane', 'data-pane': 'near' }), ln = L.h('div', { class: 'ry-list' });
      pn.appendChild(L.h('h4', null, L.h('span', { text: '주변' }), L.h('small', { text: near.length ? near.length + '가지' : '' })));
      let lastBox = -1;
      near.forEach((it) => {
        const bx = it.box || 0;
        if (bx !== lastBox) { ln.appendChild(L.h('div', { class: 'ry-sub', text: bx === 2 ? '📦 보급 상자' : bx === 1 ? '💀 상자(쓰러진 사람)' : '바닥 · ' + PICK_R + 'm 안' })); lastBox = bx; }
        const k = ikind(it.t), up = better(p, it.t);
        ln.appendChild(invRow({ src: 'near', t: it.t, n: it.n, x: it.x, y: it.y }, it.t, (up ? '▲ ' : '') + iname(it.t) + (it.n > 1 && k !== 'g' ? ' ×' + it.n : ''),
          k === 'g' ? AMMO[GUN[it.t].am].nm + (gunFits(p, it.t) ? '' : ' · 바꾸기') : itemWt(it.t) ? '무게 ' + Math.round(itemWt(it.t) * it.n * 10) / 10 : '', up ? 'up' : k === 'o' && !usesAmmo(p, it.t - I_AMMO) ? 'dim' : ''));
      });
      if (!near.length) ln.appendChild(L.h('div', { class: 'ry-wt', text: '가까이에 물건이 없어요' }));
      pn.appendChild(ln);
      // 가방
      const bag = [];
      p.am.forEach((n, j) => { if (n > 0) bag.push([I_AMMO + j, n]); });
      p.hl.forEach((n, j) => { if (n > 0) bag.push([I_HEAL + j, n]); });
      p.th.forEach((n, j) => { if (n > 0) bag.push([I_THR + j, n]); });
      p.at.forEach((n, j) => { if (n > 0) bag.push([I_ATT + j, n]); });
      const pb = L.h('div', { class: 'ry-pane', 'data-pane': 'bag' }), lb = L.h('div', { class: 'ry-list' });
      pb.appendChild(L.h('h4', null, L.h('span', { text: '가방' }), L.h('small', { text: Math.round(wtOf(p)) + '/' + capOf(p) })));
      bag.forEach(([t, n]) => {
        const k = ikind(t);
        lb.appendChild(invRow({ src: 'bag', t, n }, t, iname(t) + ' ×' + n, k === 'o' ? (usesAmmo(p, t - I_AMMO) ? '맞는 총 있음' : '맞는 총 없음') : k === 'a' ? ASN[ATT[t - I_ATT].k] : k === 'h' ? HEAL[t - I_HEAL].t + '초' : '', k === 'o' && !usesAmmo(p, t - I_AMMO) ? 'dim' : ''));
      });
      if (!bag.length) lb.appendChild(L.h('div', { class: 'ry-wt', text: '비어 있어요. 주변 물건을 끌어다 넣어요.' }));
      pb.appendChild(lb);
      // 장비: 무기 1~5 (+부착 칸) · 방어구 · 특수 장비
      const pe = L.h('div', { class: 'ry-pane eq', 'data-pane': 'eq' }), le = L.h('div', { class: 'ry-list' });
      pe.appendChild(L.h('h4', null, L.h('span', { text: '장비' }), L.h('small', { text: '끌어서 달기·바꾸기' })));
      [0, 1, 2].forEach((s) => {
        const w = p.g[s], box = L.h('div', { class: 'ry-gun' + (p.sl === s ? ' held' : ''), 'data-s': s });
        box.appendChild(invRow({ src: 'eq', k: 'g', s }, w ? w.t : -1, (s + 1) + ' · ' + (w ? GUN[w.t].nm : s === 2 ? '권총 칸 — 비었음' : '주무기 칸 — 비었음'),
          w ? CLS[GUN[w.t].c].nm + ' · ' + w.m + '/' + magW(w) + ' · ' + AMMO[GUN[w.t].am].nm + ' ' + p.am[GUN[w.t].am] + (p.sl === s ? ' · 손에 듦' : '') : '', w ? '' : 'empty'));
        if (w) {
          const as = L.h('div', { class: 'ry-as' });
          for (let k = 0; k < 5; k++) {
            const okk = ATT.some((A, ai) => A.k === k && accepts(w.t, ai)), on = w.a[k] > 0, co = { src: 'eq', k: 'a', s, kk: k };
            const ch = L.h('div', { class: 'ry-ch' + (on ? ' on' : okk ? '' : ' no') + (selIs(co) ? ' sel' : ''), 'data-s': s, 'data-k': k, title: ASN[k], role: 'button' });
            if (on) { setTip(ch, I_ATT + w.a[k] - 1, 1, { g: w.t }); ch.removeAttribute('title'); }
            if (on) ch.appendChild(icSpan(ICON(I_ATT + w.a[k] - 1), '')); else ch.appendChild(L.h('span', { text: okk ? '+' + ASN[k] : '✕' }));
            if (on) ch.appendChild(L.h('span', { text: k === 0 ? (ATT[w.a[0] - 1].cant ? '캔티드' : SCN[ATT[w.a[0] - 1].lv]) : ASN[k] }));
            if (on || okk) dragSrc(ch, co);
            else ch.addEventListener('click', () => api.toast(GUN[w.t].nm + '에는 ' + ASN[k] + '을(를) 달 수 없어요'));
            as.appendChild(ch);
          }
          box.appendChild(as);
        }
        le.appendChild(box);
      });
      le.appendChild(invRow({ src: 'eq', k: 'm' }, p.ml >= 0 ? I_MEL + p.ml : -1, '4 · ' + (p.ml >= 0 ? MELEE[p.ml].nm : '주먹'), p.sl === 3 ? '손에 듦' : '근접', (p.sl === 3 ? 'held' : '') + (p.ml < 0 ? ' empty' : '')));
      const tn = p.th[p.ts];
      le.appendChild(invRow({ src: 'eq', k: 't' }, tn > 0 ? I_THR + p.ts : -1, '5 · ' + (tn > 0 ? THROW[p.ts].nm + ' ×' + tn : '투척 — 없음'), p.th.filter((c) => c > 0).length > 1 ? '한 번 더 누르면 종류 바꾸기' : '', (p.sl === 4 ? 'held' : '') + (tn > 0 ? '' : ' empty')));
      le.appendChild(L.h('div', { class: 'ry-sub', text: '방어구 · 특수' }));
      const arm = [['헬멧', I_HELM + p.hm - 1, p.hm > 0], ['조끼', I_VEST + p.vs - 1, p.vs > 0], ['가방', I_BAG + p.bp - 1, p.bp > 0], ['특수 장비', I_SPC + p.spc - 1, p.spc > 0]];
      for (const [lbl, t, on] of arm) le.appendChild(invRow({ src: 'eq', k: 'w', t: on ? t : -1 }, on ? t : -1, on ? iname(t) : lbl + ' — 없음', '', on ? '' : 'empty'));
      pe.appendChild(le);
      cols.appendChild(pn); cols.appendChild(pb); cols.appendChild(pe);
      ov.appendChild(cols);
      ov.appendChild(selBar(p));
    }
    const nOf = (p, t) => { const k = ikind(t); return k === 'h' ? p.hl[t - I_HEAL] : k === 't' ? p.th[t - I_THR] : k === 'a' ? p.at[t - I_ATT] : k === 'o' ? p.am[t - I_AMMO] : 1; };
    /* the bar under the panes: numbers for the chosen thing + what I can do with it (장착 · 줍기 · 버리기 …) */
    function selBar(p) {
      const bar = L.h('div', { class: 'ry-bar' }), bs = L.h('div', { class: 'bs' });
      const B = (t, f, cls) => bs.appendChild(L.h('button', { type: 'button', class: 'ry-b' + (cls ? ' ' + cls : ''), text: t, onclick: () => { f(); ovSig = ''; } }));
      let inf = pcMode() ? '누르면 수치와 할 일(장착·줍기·버리기)이 나와요. 끌어서 옮기기: 주변 ↔ 가방 ↔ 장비, 창 밖으로 끌면 버리기.'
        : '짧게 누르면 장착·줍기·버리기, 길게 누른 채 끌면 옮기기(주변 ↔ 가방 ↔ 장비, 창 밖 = 버리기).';
      const S = ovSel;
      if (S && S.src === 'near') {
        const it = nearAll(p).find((i) => i.t === S.t && Math.abs(i.x - S.x) < 0.3 && Math.abs(i.y - S.y) < 0.3);
        if (!it) ovSel = null;
        else {
          const k = ikind(it.t);
          inf = k === 'g' ? gunInfo(it.t) : k === 'a' ? attEff(it.t - I_ATT, heldGun(p) ? heldGun(p).t : null) : iname(it.t) + (it.n > 1 ? ' ×' + it.n : '') + (itemWt(it.t) ? ' · 하나 무게 ' + itemWt(it.t) : '');
          B(k === 'g' && !gunFits(p, it.t) ? '들고 있는 총과 바꾸기' : k === 'g' || k === 'v' || k === 'e' || k === 'b' || k === 's' || k === 'm' ? '장착' : '줍기', () => pickIt(it), 'pri');
          if (STACK[k] && it.n > 1) B('개수 정해 줍기', () => askQty(it.t, it.n, (q) => pickIt(it, q)));
        }
      } else if (S && S.src === 'eq' && S.k === 'g' && p.g[S.s]) {
        const w = p.g[S.s];
        inf = gunInfo(w.t) + ' · 지금 퍼짐 ' + (spreadOf(W, p, w) * 57.3).toFixed(1) + '°';
        if (p.sl !== S.s) B('손에 들기', () => act(4 + S.s), 'pri');
        if (S.s <= 1 && p.g[1 - S.s]) B('1↔2 바꾸기', () => act(53));
        B('버리기', () => { act([52, S.s]); ovSel = null; }, 'dan');
      } else if (S && S.src === 'eq' && S.k === 'a' && p.g[S.s]) {
        const w = p.g[S.s], k = S.kk;
        if (w.a[k]) { inf = attEff(w.a[k] - 1, w.t); B('떼서 가방에', () => act([54, S.s, k]), 'pri'); B('떼서 버리기', () => { const ai = w.a[k] - 1; act([54, S.s, k]); act([51, I_ATT + ai, 1]); ovSel = null; }, 'dan'); }
        else {
          inf = GUN[w.t].nm + '의 ' + ASN[k] + ' 칸 — 맞는 부착물: ' + (ATT.map((A, ai) => (A.k === k && accepts(w.t, ai) ? A.nm : '')).filter(Boolean).join(', ') || '없음');
          ATT.forEach((A, ai) => { if (p.at[ai] > 0 && A.k === k && accepts(w.t, ai)) B(A.nm + ' 장착', () => act([55, ai, S.s]), 'pri'); });
        }
      } else if (S && S.src === 'eq' && S.k === 'm') {
        inf = p.ml >= 0 ? MELEE[p.ml].nm + ' · 피해 ' + MELEE[p.ml].d + ' · 휘두를 때 스태미나 ' + STM.melee : '주먹 · 피해 ' + FIST.d;
        if (p.sl !== 3) B('손에 들기', () => act(7), 'pri');
        if (p.ml >= 0) B('버리기', () => { act([51, I_MEL + p.ml, 1]); ovSel = null; }, 'dan');
      } else if (S && S.src === 'eq' && S.k === 't') {
        const tn = p.th[p.ts];
        inf = tn > 0 ? THROW[p.ts].nm + ' ×' + tn + ' · 하나 무게 ' + THROW[p.ts].wt : '투척 무기가 없어요';
        if (tn > 0) { B(p.sl === 4 ? '종류 바꾸기' : '손에 들기', () => act(8), 'pri'); B('1개 버리기', () => act([51, I_THR + p.ts, 1]), 'dan'); }
      } else if (S && S.src === 'eq' && S.k === 'w' && S.t >= 0) {
        const t = S.t, k = ikind(t);
        inf = k === 'b' ? iname(t) + ' · 들 수 있는 무게 ' + BAGCAP[t - I_BAG + 1] + ' (없으면 ' + BAGCAP[0] + ')' : k === 'v' ? iname(t) + ' · 몸 피해 −' + Math.round(VRED[t - I_VEST + 1] * 100) + '% · 가방 +' + VESTCAP
          : k === 'e' ? iname(t) + ' · 머리 피해 −' + Math.round(HRED[t - I_HELM + 1] * 100) + '%' : iname(t);
        B('벗어서 버리기', () => { act([51, t, 1]); ovSel = null; }, 'dan');
      } else if (S && S.src === 'bag') {
        const t = S.t, k = ikind(t), n = nOf(p, t);
        if (n <= 0) ovSel = null;
        else {
          if (k === 'h') { const H = HEAL[t - I_HEAL]; inf = H.nm + ' · ' + H.t + '초 · ' + (H.st ? '스태미나 +' + H.st + ', ' + H.sb + '초 지구력' : H.hp ? '체력 +' + H.hp + '(' + H.to + '까지)' : '체력 ' + H.to + '까지') + ' · 하나 무게 ' + H.wt; B('쓰기', () => act(30 + t - I_HEAL), 'pri'); }
          else if (k === 't') { inf = THROW[t - I_THR].nm + ' · 하나 무게 ' + THROW[t - I_THR].wt; B('손에 들기', () => act(10 + t - I_THR), 'pri'); }
          else if (k === 'a') { const ai = t - I_ATT; inf = attEff(ai, heldGun(p) ? heldGun(p).t : null) + ' · 무게 ' + ATT[ai].wt; p.g.forEach((w, s) => { if (w && accepts(w.t, ai)) B((s + 1) + '번 ' + GUN[w.t].nm + '에 장착', () => act([55, ai, s]), 'pri'); }); }
          else { const j = t - I_AMMO; inf = AMMO[j].nm + ' ' + n + '발 · 한 발 무게 ' + AMMO[j].wt + ' · ' + (usesAmmo(p, j) ? '지금 총에 맞아요' : '맞는 총이 없어요'); }
          if (n > 1) B('개수 정해 버리기', () => askQty(t, n, (q) => act([51, t, q])));
          B(n > 1 ? '모두 버리기' : '버리기', () => { act([51, t, 0]); ovSel = null; }, 'dan');
        }
      }
      bar.appendChild(L.h('div', { class: 'inf', text: inf }));
      if (bs.childNodes.length) bar.appendChild(bs);
      return bar;
    }
    function gunInfo(t) { const G = GUN[t], C = CLS[G.c]; return G.nm + ' · ' + C.nm + ' · 피해 ' + G.d + (G.n ? '×' + G.n : '') + ' · 탄창 ' + G.mg + ' · 100% ~' + G.er + 'm → ' + G.mr + 'm ' + Math.round(CLS[G.c].mf * 100) + '% · ' + AMMO[G.am].nm + (OH(t) ? ' · 한 손 총(운전 중 사용)' : ''); }
    /* ----- item tooltips (hover on PC): what it is, what it does, numbers, vs. what I have ----- */
    const slotsOfG = (G) => ASN.map((n, k) => (ATT.some((A, ai) => A.k === k && accepts(GUN.indexOf(G), ai)) ? n : '')).filter(Boolean).join('·') || '없음';
    const rpmOf = (G) => (G.bu ? Math.round(60 * G.bu / (G.cd + 0.07 * (G.bu - 1))) : Math.round(60 / G.cd));
    const cmpN = (a, b, hi, u) => { const d = Math.round((a - b) * 10) / 10; if (!d) return ' <i class="eq">=</i>'; return ' <i class="' + ((d > 0) === hi ? 'up' : 'dn') + '">' + (d > 0 ? '+' : '') + d + (u || '') + '</i>'; };
    function tipOf(t, n, p, ctx) {
      if (!(t >= 0 && t < NITEM)) return '';
      const k = ikind(t), L1 = [], C = [];
      let kind = '', nm = iname(t);
      if (k === 'g') {
        const G = GUN[t], Cl = CLS[G.c]; kind = Cl.nm + ' · ' + AMMO[G.am].nm + (G.po === 'A' ? ' · 보급' : '');
        L1.push(G.c === 8 ? '쏘아 올리면 그 자리에 보급 상자가 떨어지고, 밤엔 주변이 밝아져요.' : '피해 ' + G.d + (G.n ? '×' + G.n + '(산탄)' : '') + ' · ' + (G.mg === 1 ? '한 발씩 장전' : '분당 ' + rpmOf(G) + '발') + (G.bu ? ' · ' + G.bu + '점사' : ''));
        if (G.c !== 8) L1.push('탄창 ' + G.mg + ' · 장전 ' + G.rl + '초 · ' + G.er + 'm까지 피해 100% → ' + G.mr + 'm에서 ' + Math.round(Cl.mf * 100) + '% · 헤드샷 ×' + Cl.hd);
        const ft = [G.sup ? '소음기 내장(총소리 작고 위치 안 들킴)' : '', G.isc ? SCN[G.isc] + ' 조준경 내장' : '', G.ex ? '폭발 반경 ' + G.ex + 'm' : '', G.heavy ? '무거워서 들고 있으면 느려요' : '', OH(t) ? '한 손 총(운전 중에도 쏴요)' : ''].filter(Boolean);
        if (ft.length) L1.push(ft.join(' · '));
        L1.push('부착 칸: ' + slotsOfG(G));
        const own = ctx && ctx.s != null && p && p.g[ctx.s];
        if (own) { const w = p.g[ctx.s]; C.push('탄창 ' + w.m + '/' + magW(w) + ' · 가방의 ' + AMMO[G.am].nm + ' ' + p.am[G.am] + '발 · 지금 퍼짐 ' + (spreadOf(W, p, w) * 57.3).toFixed(1) + '°'); }
        else if (p && G.c !== 8) {
          const hg = heldGun(p), vs = (pistolSlot(t) ? [p.g[2]] : [hg && !pistolSlot(hg.t) ? hg : null, p.g[0], p.g[1]]).filter((w) => w && w.t !== t)[0];
          if (vs) { const H = GUN[vs.t]; C.push('지금 ' + H.nm + '과 비교: 피해' + cmpN(G.d * (G.n || 1), H.d * (H.n || 1), true) + ' · 분당' + cmpN(rpmOf(G), rpmOf(H), true) + ' · 탄창' + cmpN(G.mg, H.mg, true) + ' · 100% 거리' + cmpN(G.er, H.er, true, 'm') + ' · 장전' + cmpN(G.rl, H.rl, false, '초')); }
          else C.push(gunFits(p, t) ? '빈 칸에 바로 들어가요' : '같은 총을 이미 들고 있어요');
        }
      } else if (k === 'm') {
        const M2 = MELEE[t - I_MEL], cur = p && p.ml >= 0 ? MELEE[p.ml] : FIST; kind = '근접 무기 · 4번 칸';
        L1.push('피해 ' + M2.d + ' · 간격 ' + M2.cd + '초 · 거리 ' + M2.r + 'm · 휘두르는 폭 ' + Math.round(M2.arc * 57) + '°', '휘두를 때마다 스태미나 ' + STM.melee + ' · 무게 없음');
        if (p && cur !== M2) C.push('지금 ' + cur.nm + '과 비교: 피해' + cmpN(M2.d, cur.d, true) + ' · 간격' + cmpN(M2.cd, cur.cd, false, '초') + ' · 거리' + cmpN(M2.r, cur.r, true, 'm'));
      } else if (k === 't') {
        const T2 = THROW[t - I_THR]; kind = '투척 · 5번 칸 · 하나 무게 ' + T2.wt;
        L1.push(THD[t - I_THR], '「쏘기」를 누른 채 끌어 겨누고 떼면 던져요.');
        if (p) C.push('가지고 있는 것: ' + p.th[t - I_THR] + '개');
      } else if (k === 'h') {
        const H = HEAL[t - I_HEAL]; kind = '치료 · 하나 무게 ' + H.wt;
        L1.push(H.st ? '스태미나 +' + H.st + ', ' + H.sb + '초 동안 지구력(스태미나가 반만 줄고 두 배 빨리 차요)' : H.hp ? '체력 +' + H.hp + '(' + H.to + '까지만)' : '체력을 ' + H.to + '까지 채워요', '쓰는 데 ' + H.t + '초 · 쏘면 취소돼요');
        if (p) C.push('가지고 있는 것: ' + p.hl[t - I_HEAL] + '개 · 지금 체력 ' + Math.round(p.hp));
      } else if (k === 'v' || k === 'e' || k === 'b') {
        const lv = t - (k === 'v' ? I_VEST : k === 'e' ? I_HELM : I_BAG) + 1, cur = p ? p[k === 'v' ? 'vs' : k === 'e' ? 'hm' : 'bp'] : 0;
        if (k === 'v') { kind = '방어구 · 몸'; L1.push('몸에 맞는 총알 피해 −' + Math.round(VRED[lv] * 100) + '% · 가방 무게 +' + VESTCAP, '자기장·불·물·용암 피해는 못 막아요'); if (p) C.push(cur ? '지금 조끼 ' + cur + '레벨: 피해 줄임' + cmpN(VRED[lv] * 100, VRED[cur] * 100, true, '%p') : '지금 조끼 없음 → 바로 입어요'); }
        else if (k === 'e') { kind = '방어구 · 머리'; L1.push('머리에 맞는 총알 피해 −' + Math.round(HRED[lv] * 100) + '%'); if (p) C.push(cur ? '지금 헬멧 ' + cur + '레벨: 피해 줄임' + cmpN(HRED[lv] * 100, HRED[cur] * 100, true, '%p') : '지금 헬멧 없음 → 바로 써요'); }
        else { kind = '가방'; L1.push('들 수 있는 무게 ' + BAGCAP[lv] + ' (가방 없으면 ' + BAGCAP[0] + ', 조끼 입으면 +' + VESTCAP + ')', '탄창에 든 총알·총·근접 무기는 무게가 없어요'); if (p) C.push('지금 ' + (cur ? '가방 ' + cur + '레벨' : '주머니') + ': 무게' + cmpN(BAGCAP[lv], BAGCAP[cur], true) + ' · 지금 든 무게 ' + Math.round(wtOf(p)) + '/' + Math.round(capOf(p))); }
      } else if (k === 's') {
        const j = t - I_SPC; kind = '특수 장비'; for (const d of SPCD[j]) L1.push(d);
        if (p) C.push(p.spc ? (p.spc === j + 1 ? '지금 입고 있어요' : '지금 ' + SPC[p.spc - 1].nm + '을(를) 입고 있어요 — 바꾸면 그건 땅에 떨어져요') : '지금 특수 장비 없음 → 바로 입어요');
      } else if (k === 'a') {
        const ai = t - I_ATT, A = ATT[ai]; kind = '부착물 · ' + ASN[A.k] + ' 칸 · 무게 ' + A.wt;
        L1.push(attText(A).replace(/ · 무게 [\d.]+$/, ''));
        L1.push('맞는 총 종류: ' + A.cl.split('').map((c) => CLS[+c].nm).filter((x, i, a) => a.indexOf(x) === i).join('·'));
        if (p) {
          const tg = ctx && ctx.g != null ? [ctx.g] : p.g.filter(Boolean).map((w) => w.t);
          for (const gt of tg) {
            const w = p.g.find((x) => x && x.t === gt);
            if (!accepts(gt, ai)) { C.push(GUN[gt].nm + ': 못 달아요'); continue; }
            const on = w && w.a[A.k] ? ATT[w.a[A.k] - 1] : null;
            C.push(GUN[gt].nm + ': ' + (on === A ? '달려 있어요' : on ? '지금 ' + on.nm + ' → ' + (attBetter(w, ai) ? '<i class="up">이게 더 좋아요</i>' : '<i class="dn">지금 것이 나아요</i>') : '빈 칸 → 주우면 저절로 달려요') + (A.mg && GUN[gt].mg > 1 ? ' (탄창 ' + GUN[gt].mg + '→' + Math.round(GUN[gt].mg * A.mg) + ')' : ''));
          }
        }
      } else if (k === 'o') {
        const j = t - I_AMMO, A = AMMO[j], us = GUN.filter((G) => G.am === j); kind = '탄약 · 한 발 무게 ' + A.wt;
        L1.push('쓰는 총: ' + us.slice(0, 8).map((G) => G.nm).join(', ') + (us.length > 8 ? ' 외 ' + (us.length - 8) + '종' : ''));
        if (p) C.push((usesAmmo(p, j) ? '<i class="up">지금 총에 맞아요</i>' : '<i class="dn">지금 맞는 총이 없어요</i>') + ' · 가진 것 ' + p.am[j] + '발 · 더 들 수 있는 것 ' + Math.min(999, roomFor(p, t)) + '발');
      }
      if (n > 1 && k !== 'g') nm += ' ×' + n;
      const esc = (x) => String(x).replace(/&/g, '&amp;').replace(/</g, '&lt;');
      return '<b>' + esc(nm) + '</b><small>' + esc(kind) + '</small>' + L1.map((x) => '<div>' + esc(x) + '</div>').join('') + (C.length ? '<div class="cmp">' + C.join('<br>') + '</div>' : '');
    }
    const tipEl = L.h('div', { class: 'ry-tip' }); root.appendChild(tipEl);
    let tipKey = '';
    const tipHide = () => { if (tipKey || tipEl.style.display !== 'none') { tipKey = ''; tipEl.style.display = 'none'; } };
    function tipAt(e) {
      const el = e.target && e.target.closest ? e.target.closest('[data-ti]') : null, p = myP();
      if (!el || !root.contains(el) || !el.closest('.ry-inv') || (drag && drag.on)) { tipHide(); return; }
      const d = el.dataset, ctx = { s: d.ts != null ? +d.ts : null, g: d.tg != null ? +d.tg : null };
      const key = d.ti + '/' + (d.tn || '') + '/' + d.ts + '/' + d.tg + '/' + (p ? invSig(p) : '');
      if (key !== tipKey) { tipKey = key; tipEl.innerHTML = tipOf(+d.ti, +d.tn || 1, p, ctx); }
      tipEl.style.display = tipEl.innerHTML ? 'block' : 'none';
      const r = root.getBoundingClientRect(), w = tipEl.offsetWidth, h = tipEl.offsetHeight;
      let x = e.clientX - r.left + 16, y = e.clientY - r.top + 18;
      if (x + w > r.width - 6) x = Math.max(6, e.clientX - r.left - w - 12);
      if (y + h > r.height - 6) y = Math.max(6, e.clientY - r.top - h - 12);
      tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
    }
    root.addEventListener('pointermove', tipAt);
    root.addEventListener('pointerdown', (e) => { if (e.pointerType !== 'mouse') tipHide(); });
    root.addEventListener('pointerleave', tipHide);
    function setTip(el, t, n, x) {
      const d = el.dataset; delete d.tn; delete d.ts; delete d.tg;
      if (!(t >= 0)) { delete d.ti; return el; }
      d.ti = t; if (n > 1) d.tn = n; if (x && x.s != null) d.ts = x.s; if (x && x.g != null) d.tg = x.g;
      return el;
    }
    /* how many? (stacks dragged / dropped / picked) */
    function askQty(t, n, done) {
      if (qtyEl) qtyEl.remove();
      const k = ikind(t), opts = [1];
      if (k === 'o' && AMMO[t - I_AMMO].pk < n) opts.push(AMMO[t - I_AMMO].pk);
      if (n >= 4) opts.push(Math.ceil(n / 2));
      opts.push(n);
      const bs = L.h('div', { class: 'bs' });
      [...new Set(opts)].sort((a, b) => a - b).forEach((q) => bs.appendChild(L.h('button', { type: 'button', class: 'ry-b' + (q === n ? ' pri' : ''), text: q === n ? '모두 ' + q : q === Math.ceil(n / 2) && n >= 4 ? '절반 ' + q : String(q), onclick: () => { qtyEl.remove(); qtyEl = null; done(q); ovSig = ''; } })));
      bs.appendChild(L.h('button', { type: 'button', class: 'ry-b', text: '취소', onclick: () => { qtyEl.remove(); qtyEl = null; ovSig = ''; } }));
      qtyEl = L.h('div', { class: 'ry-qty' }, L.h('div', null, L.h('span', { text: iname(t) + ' — 몇 개? (있는 것 ' + n + ')' }), bs));
      qtyEl.addEventListener('pointerdown', (e) => e.stopPropagation());
      (ov || root).appendChild(qtyEl);
    }
    /* drag & drop between 주변 · 가방 · 장비: long-press (touch) or drag (mouse); a short tap selects */
    let drag = null;
    function dragSrc(el, what) {
      el.addEventListener('pointerdown', (e) => {
        if (e.button === 2) { e.preventDefault(); quickDrop(what); return; }   // right-click: drop it (whole stack)
        if (e.button > 0) return;
        if (drag) endDrag();
        drag = { what, x: e.clientX, y: e.clientY, on: false, id: e.pointerId, el, mouse: e.pointerType === 'mouse', moved: false, tm: 0 };
        if (!drag.mouse) drag.tm = setTimeout(() => { if (drag && drag.el === el && !drag.moved) { startDrag(e.clientX, e.clientY); vib(25); } }, 380);
      });
      el.addEventListener('contextmenu', noCtx);
    }
    function startDrag(x, y) {
      if (!drag || drag.on) return;
      drag.on = true;
      const t = dragT(drag.what); drag.gh = icSpan(t >= 0 ? ICON(t) : '', 'ry-ghost2'); document.body.appendChild(drag.gh);
      drag.gh.style.left = x + 'px'; drag.gh.style.top = y + 'px';
      drag.el.classList.add('lift');
      try { drag.el.setPointerCapture(drag.id); } catch (er) {}
    }
    function dragT(w) { const p = myP(); if (!p) return -1; if (w.src !== 'eq') return w.t; if (w.k === 'g') return p.g[w.s] ? p.g[w.s].t : -1; if (w.k === 'a') { const g = p.g[w.s]; return g && g.a[w.kk] ? I_ATT + g.a[w.kk] - 1 : -1; } if (w.k === 'm') return p.ml >= 0 ? I_MEL + p.ml : -1; if (w.k === 't') return p.th[p.ts] > 0 ? I_THR + p.ts : -1; return w.t; }
    function dragMove(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = hyp(e.clientX - drag.x, e.clientY - drag.y);
      if (!drag.on) {
        if (d > 9) { drag.moved = true; if (drag.mouse) startDrag(e.clientX, e.clientY); else { clearTimeout(drag.tm); drag = null; } }
        return;
      }
      drag.gh.style.left = e.clientX + 'px'; drag.gh.style.top = e.clientY + 'px';
      if (ov) ov.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop'));
      const tg = dropTarget(e); if (tg) tg.classList.add('drop');
      e.preventDefault();
    }
    const blockScroll = (e) => { if (drag && drag.on) e.preventDefault(); };
    function dropTarget(e) {
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (!el || !el.closest || !ov || !ov.contains(el)) return null;
      return el.closest('.ry-ch:not(.no),.ry-gun,.ry-pane');
    }
    function dragUp(e) {
      if (!drag || e.pointerId !== drag.id) return;
      const d = drag; endDrag();
      if (!d.on) {   // a short tap: select / unselect
        if (e.type === 'pointerup' && !d.moved) {
          const w = d.what, k = JSON.stringify(w), now = performance.now();
          if (w.src === 'near') {   // double-tap / double-click = pick up now; a single tap opens the menu after the double-tap window
            if (lastTap && lastTap.k === k && now - lastTap.t < 260) { clearTimeout(lastTap.tm); lastTap = null; quickPick(w); return; }
            if (lastTap) clearTimeout(lastTap.tm);
            lastTap = { k, t: now, tm: setTimeout(() => { lastTap = null; ovSel = selIs(w) ? null : w; ovSig = ''; renderInv(); }, 260) };
            return;
          }
          ovSel = selIs(w) ? null : w; ovSig = ''; renderInv();
        }
        return;
      }
      const p = myP(); if (!p || !ov) return;
      const el = document.elementFromPoint(e.clientX, e.clientY), inside = !!(el && ov.contains(el));
      const tg = inside ? el.closest('.ry-ch,.ry-gun,.ry-pane') : null, pe = tg ? tg.closest('.ry-pane') : null;
      const pane = !inside ? 'out' : pe ? pe.getAttribute('data-pane') : '';
      const gs = tg && tg.getAttribute('data-s') != null ? +tg.getAttribute('data-s') : -1;
      dropOn(p, d.what, pane, gs);
      ovSig = '';
    }
    let lastTap = null;
    function quickPick(w) { const p = myP(); if (!p) return; const it = nearAll(p).find((i) => i.t === w.t && Math.abs(i.x - w.x) < 0.3 && Math.abs(i.y - w.y) < 0.3); if (it) { pickIt(it); sfx('tick', 30); ovSig = ''; } }
    function quickDrop(w) {
      const p = myP(); if (!p || w.src === 'near') return;
      if (w.src === 'bag') act([51, w.t, 0]);
      else if (w.k === 'g') { if (p.g[w.s]) act([52, w.s]); }
      else if (w.k === 'a') { const g = p.g[w.s]; if (g && g.a[w.kk]) { const ai = g.a[w.kk] - 1; act([54, w.s, w.kk]); act([51, I_ATT + ai, 1]); } }
      else if (w.k === 'm') { if (p.ml >= 0) act([51, I_MEL + p.ml, 1]); }
      else if (w.k === 't') { if (p.th[p.ts] > 0) act([51, I_THR + p.ts, 0]); }
      else if (w.k === 'w' && w.t >= 0) act([51, w.t, 1]);
      if (selIs(w)) ovSel = null;
      ovSig = ''; sfx('tick', 30);
    }
    /* what a drop means — every move goes through the normal host actions */
    function dropOn(p, w, pane, gs) {
      const toGround = pane === 'out' || pane === 'near';
      if (w.src === 'near') {
        if (toGround) return;
        const it = nearAll(p).find((i) => i.t === w.t && Math.abs(i.x - w.x) < 0.3 && Math.abs(i.y - w.y) < 0.3); if (!it) return;
        const k = ikind(it.t);
        if (k === 'g') { if (gs >= 0 && !gunFits(p, it.t) && gs <= 1 && !pistolSlot(it.t)) act(4 + gs); pickIt(it); return; }
        if (k === 'a' && gs >= 0) { const ai = it.t - I_ATT, g = p.g[gs]; if (!g || !accepts(g.t, ai)) { api.toast('그 총에는 ' + ATT[ai].nm + '을(를) 달 수 없어요'); return; } pickIt(it, 1); act([55, ai, gs]); return; }
        if (STACK[k] && it.n > 1) askQty(it.t, it.n, (q) => pickIt(it, q)); else pickIt(it);
        return;
      }
      if (w.src === 'bag') {
        const n = nOf(p, w.t), k = ikind(w.t);
        if (toGround) { if (n > 1) askQty(w.t, n, (q) => act([51, w.t, q])); else act([51, w.t, 0]); ovSel = null; return; }
        if (k === 'a' && gs >= 0) { const ai = w.t - I_ATT, g = p.g[gs]; if (!g || !accepts(g.t, ai)) { api.toast('그 총에는 ' + ATT[ai].nm + '을(를) 달 수 없어요'); return; } act([55, ai, gs]); return; }
        if (k === 'a' && pane === 'eq') { if (p.g.some((g) => g && accepts(g.t, w.t - I_ATT))) act([55, w.t - I_ATT, -1]); else api.toast('맞는 총이 없어요'); return; }
        if (k === 't' && pane === 'eq') { act(10 + w.t - I_THR); return; }
        if (k === 'h' && pane === 'eq') { act(30 + w.t - I_HEAL); return; }
        return;
      }
      // from equipment
      if (w.k === 'g') {
        if (!p.g[w.s]) return;
        if (toGround) { act([52, w.s]); ovSel = null; return; }
        if (gs >= 0 && gs !== w.s && gs <= 1 && w.s <= 1) { act(53); return; }
        if (pane === 'bag') api.toast('총은 가방에 넣지 않아요 — 1~3번 칸에 들어가요');
        return;
      }
      if (w.k === 'a') {
        const g = p.g[w.s]; if (!g || !g.a[w.kk]) return;
        const ai = g.a[w.kk] - 1;
        if (pane === 'bag') { act([54, w.s, w.kk]); return; }
        if (toGround) { act([54, w.s, w.kk]); act([51, I_ATT + ai, 1]); return; }
        if (gs >= 0 && gs !== w.s) { const g2 = p.g[gs]; if (!g2 || !accepts(g2.t, ai)) { api.toast('그 총에는 ' + ATT[ai].nm + '을(를) 달 수 없어요'); return; } act([54, w.s, w.kk]); act([55, ai, gs]); }
        return;
      }
      if (w.k === 'm') { if (toGround && p.ml >= 0) act([51, I_MEL + p.ml, 1]); return; }
      if (w.k === 't') { const t = I_THR + p.ts, n = p.th[p.ts]; if (toGround && n > 0) { if (n > 1) askQty(t, n, (q) => act([51, t, q])); else act([51, t, 1]); } return; }
      if (w.k === 'w' && w.t >= 0 && toGround) { act([51, w.t, 1]); ovSel = null; }
    }
    function endDrag() {
      if (drag) { clearTimeout(drag.tm); if (drag.gh) drag.gh.remove(); if (drag.el) drag.el.classList.remove('lift'); }
      drag = null;
      if (ov) ov.querySelectorAll('.drop').forEach((x) => x.classList.remove('drop'));
    }
    window.addEventListener('pointermove', dragMove);
    window.addEventListener('pointerup', dragUp);
    window.addEventListener('pointercancel', dragUp);
    window.addEventListener('touchmove', blockScroll, { passive: false });
    /* big map: tap = marker / ping (team sees it) */
    let mapCv = null, mapDrag = null;
    function openMap() {
      if (!W || W.ph < 1) return;
      if (ovKind === 'map') { closeOv(); return; }
      mkOv('map', '지도');
      const p = myP(); if (p) { mapSt.cx = p.x; mapSt.cy = p.y; }
      mapCv = L.h('canvas'); ov.appendChild(mapCv);
      const bar = L.h('div', { class: 'ry-mbar' });
      const kinds = [[3, '🚩 마커'], [0, '◆ 위치'], [1, '✕ 적'], [2, '▣ 물건']];
      kinds.forEach(([k, t]) => bar.appendChild(L.h('button', { type: 'button', class: 'ry-b' + (mapSt.k === k ? ' on' : ''), text: t, onclick: (e) => { mapSt.k = k; bar.querySelectorAll('.ry-b').forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); } })));
      bar.appendChild(L.h('button', { type: 'button', class: 'ry-b', text: '마커 지우기', onclick: () => act([57, 4]) }));
      bar.appendChild(L.h('button', { type: 'button', class: 'ry-b', text: '확대 ' + mapSt.z + '×', onclick: (e) => { mapSt.z = mapSt.z >= 4 ? 1 : mapSt.z * 2; e.currentTarget.textContent = '확대 ' + mapSt.z + '×'; } }));
      ov.appendChild(bar);
      mapCv.addEventListener('pointerdown', (e) => { mapDrag = { x: e.clientX, y: e.clientY, cx: mapSt.cx, cy: mapSt.cy, moved: false }; try { mapCv.setPointerCapture(e.pointerId); } catch (er) {} });
      mapCv.addEventListener('pointermove', (e) => {
        if (!mapDrag) return;
        const dx = e.clientX - mapDrag.x, dy = e.clientY - mapDrag.y;
        if (hyp(dx, dy) > 8) mapDrag.moved = true;
        if (mapDrag.moved && mapSt.z > 1) { const sc = mapScale(); mapSt.cx = mapDrag.cx - dx / sc; mapSt.cy = mapDrag.cy - dy / sc; }
      });
      mapCv.addEventListener('pointerup', (e) => {
        const d = mapDrag; mapDrag = null; if (!d || d.moved) return;
        const r = mapCv.getBoundingClientRect(), sc = mapScale(), c = mapCenter();
        const x = c.x + (e.clientX - r.left - r.width / 2) / sc, y = c.y + (e.clientY - r.top - r.height / 2) / sc;
        act([57, mapSt.k, Math.round(x * 10), Math.round(y * 10)]); sfx('pop', 60);
      });
    }
    const mapCenter = () => { const ib = islandBox(); return mapSt.z > 1 ? { x: mapSt.cx, y: mapSt.cy } : { x: ib.x, y: ib.y }; };
    const mapScale = () => { if (!mapCv) return 1; const r = mapCv.getBoundingClientRect(), ib = islandBox(); return Math.min(r.width, r.height) / (2 * ib.r) * mapSt.z; };
    function drawMap() {
      if (!mapCv || ovKind !== 'map' || !W) return;
      const r = mapCv.getBoundingClientRect(), dpr = cv.dpr || 1, w = Math.max(10, r.width), h = Math.max(10, r.height);
      if (mapCv.width !== Math.round(w * dpr) || mapCv.height !== Math.round(h * dpr)) { mapCv.width = Math.round(w * dpr); mapCv.height = Math.round(h * dpr); }
      const g = mapCv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.fillStyle = '#2f7fb8'; g.fillRect(0, 0, w, h);
      const sc = mapScale(), c = mapCenter(), MX = (x) => w / 2 + (x - c.x) * sc, MY = (y) => h / 2 + (y - c.y) * sc;
      if (bgCv) g.drawImage(bgCv, MX(-HL), MY(-HL), 2 * HL * sc, 2 * HL * sc);
      const z = W.z;
      if (W.ph >= 2) {
        g.beginPath(); g.rect(0, 0, w, h); g.moveTo(MX(z.cx) + Math.max(0, z.r * sc), MY(z.cy)); g.arc(MX(z.cx), MY(z.cy), Math.max(0, z.r * sc), 0, 6.2832, true); g.fillStyle = 'rgba(30,80,210,.35)'; g.fill();
        if (z.i < W.ZS.length) { g.strokeStyle = '#fff'; g.lineWidth = 2; g.setLineDash([6, 5]); g.beginPath(); g.arc(MX(z.nx), MY(z.ny), Math.max(1, z.nr * sc), 0, 7); g.stroke(); g.setLineDash([]); }
      }
      for (const d of W.ad) if (!d.op) { g.fillStyle = '#ff4a3a'; g.fillRect(MX(d.x) - 4, MY(d.y) - 4, 8, 8); }
      if (W.rz) { g.strokeStyle = '#ff4a3a'; g.lineWidth = 2; g.fillStyle = 'rgba(255,60,40,.3)'; g.beginPath(); g.arc(MX(W.rz.x), MY(W.rz.y), Math.max(3, W.rz.r * sc), 0, 7); g.fill(); g.stroke(); }
      const v = viewer();
      drawMarks(g, MX, MY, 1.3);
      mapRecall(g, MX, MY, 1.3, performance.now());
      for (const q of W.pl) {
        if (q.out || !(q === v || (v && W.tm && q.tm === v.tm))) continue;
        g.fillStyle = q === v ? '#ffffff' : COL(q.i); g.beginPath(); g.arc(MX(q.x), MY(q.y), q === v ? 6 : 5, 0, 7); g.fill(); g.strokeStyle = q.kd ? '#ff3a2a' : '#17131f'; g.lineWidth = q.kd ? 2.5 : 1.5; g.stroke();
        if (q !== v) { g.font = '700 11px ' + FONT; g.textAlign = 'center'; g.textBaseline = 'bottom'; g.lineWidth = 3; g.strokeStyle = 'rgba(12,10,18,.85)'; const t = (q.kd ? '✚ ' : '') + name(q.i); g.strokeText(t, MX(q.x), MY(q.y) - 7); g.fillStyle = COL(q.i); g.fillText(t, MX(q.x), MY(q.y) - 7); }
        if (q === v) { g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath(); g.moveTo(MX(q.x), MY(q.y)); g.lineTo(MX(q.x) + Math.cos(q.a) * 14, MY(q.y) + Math.sin(q.a) * 14); g.stroke(); }
      }
      g.font = '700 12px ' + FONT; g.fillStyle = 'rgba(242,233,216,.85)'; g.textAlign = 'left'; g.textBaseline = 'top';
      g.fillText(['◆ 위치 핑을', '✕ 적 핑을', '▣ 물건 핑을', '🚩 마커를'][mapSt.k] + ' 지도를 눌러 찍어요' + (W.tm ? ' · 팀원에게 보여요' : ''), 8, 8);
    }
    /* towers (cyan = usable, grey = closed, pulsing = someone is calling) and my team's 인식표 on a map canvas */
    function mapRecall(g, MX, MY, k, now) {
      if (!W.rt || !W.rt.length || W.ph !== 2) return;
      const on = !!W.rcOpen, ch = chans();
      W.rt.forEach((T, j) => {
        const X = MX(T.x), Y = MY(T.y), c = ch.some((e) => e.j === j), R = 5.5 * k;
        if (c) { const pr = (now / 900) % 1; g.strokeStyle = 'rgba(127,224,255,' + (1 - pr) + ')'; g.lineWidth = 1.5; g.beginPath(); g.arc(X, Y, R + pr * 10 * k, 0, 7); g.stroke(); }
        g.fillStyle = on ? '#7fe0ff' : '#7a8088'; g.strokeStyle = '#17131f'; g.lineWidth = 1.2;
        g.beginPath(); g.moveTo(X, Y - R); g.lineTo(X + R * 0.8, Y + R * 0.7); g.lineTo(X - R * 0.8, Y + R * 0.7); g.closePath(); g.fill(); g.stroke();
        g.fillStyle = '#17131f'; g.fillRect(X - 0.6 * k, Y - R * 0.3, 1.2 * k, R * 0.9);
      });
      const tm = myTeam();
      for (const e of W.dg || []) {
        if (!W.pl[e.i] || W.pl[e.i].tm !== tm || e.by >= 0) continue;
        const X = MX(e.x), Y = MY(e.y), R = 4 * k;
        g.fillStyle = '#e8d27a'; g.strokeStyle = COL(e.i); g.lineWidth = 1.5; g.fillRect(X - R * 0.7, Y - R, R * 1.4, R * 2); g.strokeRect(X - R * 0.7, Y - R, R * 1.4, R * 2);
      }
    }
    /* pings & markers on any canvas (world, minimap, big map) */
    const PINGC = ['#ffd23f', '#ff4a3a', '#5fb3ff'];
    function myTeam() { const v = viewer(); return v ? v.tm : -1; }
    function drawMarks(g, MX, MY, k) {
      const tm = myTeam();
      for (const i in W.mk) {
        const q = W.pl[+i]; if (!q || (q.tm !== tm && +i !== me())) continue;
        const m = W.mk[i], X = MX(m[0]), Y = MY(m[1]);
        g.strokeStyle = '#17131f'; g.lineWidth = 1.5 * k; g.beginPath(); g.moveTo(X, Y); g.lineTo(X, Y - 14 * k); g.stroke();
        g.fillStyle = COL(+i); g.beginPath(); g.moveTo(X, Y - 14 * k); g.lineTo(X + 9 * k, Y - 10.5 * k); g.lineTo(X, Y - 7 * k); g.fill(); g.stroke();
      }
      for (const pg of W.pg) {
        if (pg.tm !== tm) continue;
        const X = MX(pg.x), Y = MY(pg.y), c = PINGC[pg.k] || '#fff', R = 6 * k;
        g.fillStyle = c; g.strokeStyle = '#17131f'; g.lineWidth = 1.5;
        g.beginPath(); if (pg.k === 0) { g.moveTo(X, Y - R); g.lineTo(X + R, Y); g.lineTo(X, Y + R); g.lineTo(X - R, Y); g.closePath(); } else if (pg.k === 1) { g.arc(X, Y, R, 0, 7); } else g.rect(X - R * 0.8, Y - R * 0.8, R * 1.6, R * 1.6);
        g.fill(); g.stroke();
        if (pg.k === 1) { g.strokeStyle = '#fff'; g.lineWidth = 1.6; g.beginPath(); g.moveTo(X - R * 0.5, Y - R * 0.5); g.lineTo(X + R * 0.5, Y + R * 0.5); g.moveTo(X + R * 0.5, Y - R * 0.5); g.lineTo(X - R * 0.5, Y + R * 0.5); g.stroke(); }
      }
    }
    /* ping menu (핑 button): 위치 · 적 · 물건 at what I'm looking at */
    function pingPoint(k) {
      const p = myP(); if (!p) return null;
      if (mouse && pcMode()) { const w = toWorld(mouse.x, mouse.y); return [w.x, w.y]; }
      if (k === 1) { const w = heldGun(p), q = autoTarget(W, p, Math.min(sightOf(p), w ? GUN[w.t].mr : 40)); if (q) return [q.x, q.y]; }
      if (k === 2) { const it = nearItems(p)[0]; if (it) return [it.x, it.y]; let best = null, bd = 9; eachLoot(W, p.x, p.y, 9, (l) => { const d = hyp(l.x - p.x, l.y - p.y); if (d < bd) { bd = d; best = [l.x, l.y]; } return false; }); if (best) return best; }
      return [p.x + Math.cos(p.a) * 12, p.y + Math.sin(p.a) * 12];
    }
    function sendPing(k) { const pt = pingPoint(k); if (pt) { act([57, k, Math.round(pt[0] * 10), Math.round(pt[1] * 10)]); sfx('pop', 60); } closeMenus(); }
    function togglePingMenu() {
      if (pmenu && pmenu._k === 'ping') { closeMenus(); return; }
      closeMenus();
      pmenu = L.h('div', { class: 'ry-pmenu' }); pmenu._k = 'ping';
      [['◆ 위치', 0], ['✕ 적', 1], ['▣ 물건', 2]].forEach(([t, k]) => pmenu.appendChild(L.h('button', { type: 'button', text: t, onpointerdown: (e) => { e.stopPropagation(); sendPing(k); } })));
      pmenu.style.right = '8px'; pmenu.style.top = (MM + 18) + 'px';
      pmenu.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(pmenu);
    }
    /* sensitivity panel: -/+ per kind, 0.3-2.0x, kept on this device */
    function openSens() {
      closeMenus();
      pmenu = L.h('div', { class: 'ry-vmenu' }); pmenu._k = 'sens';
      const rows = [['drag', '조준 끌기(터치)'], ['mouse', '마우스(조준경 화면 이동)'], ['pad', '패드 오른쪽 스틱'], ['move', '이동 조이스틱']];
      const draw = () => {
        pmenu.innerHTML = '';
        pmenu.appendChild(L.h('button', { type: 'button', style: { justifyContent: 'center' }, onpointerdown: (e) => { e.stopPropagation(); closeMenus(); } }, L.h('span', { text: '🎚 감도 · 닫기 ✕' })));
        for (const [k, t] of rows) {
          const mk = (lbl, d) => L.h('button', { type: 'button', class: 'sb', style: { minWidth: '44px', width: '44px', justifyContent: 'center', padding: '0' }, onpointerdown: (e) => { e.stopPropagation(); setSens(k, sens[k] + d); draw(); } }, lbl);
          pmenu.appendChild(L.h('div', { style: { display: 'flex', gap: '6px', alignItems: 'center' } }, mk('−', -0.1),
            L.h('span', { style: { minWidth: '150px', font: '700 12px var(--f-body,system-ui)', color: '#f2e9d8', background: 'rgba(18,16,24,.9)', borderRadius: '10px', padding: '6px 8px' }, text: t + ' ' + sens[k].toFixed(1) + '×' }), mk('+', 0.1)));
        }
      };
      draw();
      pmenu.style.right = (MM + 68) + 'px'; pmenu.style.top = '6px'; pmenu.style.gap = '4px';
      pmenu.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(pmenu);
    }
    /* 「⋯」: the less used things (bag, big map, key guide) */
    function toggleMore() {
      if (pmenu && pmenu._k === 'more') { closeMenus(); return; }
      closeMenus();
      pmenu = L.h('div', { class: 'ry-vmenu' }); pmenu._k = 'more';
      const add = (t, kid, f) => pmenu.appendChild(L.h('button', { type: 'button', onpointerdown: (e) => { e.stopPropagation(); closeMenus(); f(); } }, L.h('span', { text: t }), L.h('small', { text: pcMode() ? bindKey(kid) : '' })));
      add('🎒 소지품', 'inv', () => openInv()); add('🗺 지도', 'map', openMap);
      const RM = { hold: '누르고 있기', toggle: '눌러서 켜고 끄기', edge: '조이스틱 끝까지 밀기' }, nx = { hold: 'toggle', toggle: 'edge', edge: 'hold' };
      add('🏃 달리기: ' + RM[runMode()], '', () => { setRunMode(nx[runMode()]); api.toast('달리기: ' + RM[runMode()]); });
      add('🧎 앉기: ' + (crMode() === 'hold' ? '누르고 있기' : '눌러서 켜고 끄기'), '', () => { setCrMode(crMode() === 'hold' ? 'toggle' : 'hold'); api.toast('앉기: ' + (crMode() === 'hold' ? '누르고 있기' : '눌러서 켜고 끄기')); });
      add('🌀 시야 회전 부드럽게: ' + VS_N[vsModeV], '', () => { setVsMode((vsModeV + 1) % 4); api.toast('시야 회전 부드럽게: ' + VS_N[vsModeV]); });
      add('🎚 감도', '', openSens);
      if (pcMode()) add('🔭 조준경: ' + (adsMode() === 'hold' ? '오른쪽 버튼 누르고 있기' : '눌러서 켜고 끄기'), 'ads', () => { setAdsMode(adsMode() === 'hold' ? 'toggle' : 'hold'); api.toast('조준경: ' + (adsMode() === 'hold' ? '누르고 있기' : '켜고 끄기')); });
      if (pcMode()) add('⌨ 키 안내', 'keys', openKeys);
      pmenu.style.right = (MM + 68) + 'px'; pmenu.style.top = '6px';
      pmenu.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(pmenu);
    }
    function quickPing() {   // Z key: enemy under the pointer → 적, loot → 물건, else 위치
      const p = myP(); if (!p) return;
      let k = 0; const pt = pingPoint(0);
      if (pt) { if (W.pl.some((q) => !q.out && q.tm !== p.tm && hyp(q.x - pt[0], q.y - pt[1]) < 2.5 && canSee(W, p, q))) k = 1; else { let f = false; eachLoot(W, pt[0], pt[1], 1.5, () => { f = true; return true; }); if (f) k = 2; } }
      if (pt) { act([57, k, Math.round(pt[0] * 10), Math.round(pt[1] * 10)]); sfx('pop', 60); }
    }
    /* shooting range: pick any of the guns / toggle attachments on the gun in hand */
    let rgCls = -1, rgQ = '';
    function openRangeGun() {
      const p = myP(); if (!p || !W || !W.rg) return;
      if (ovKind === 'rgun') { closeOv(); return; }
      mkOv('rgun', '총 고르기');
      const inp = L.h('input', { class: 'ry-search', type: 'search', placeholder: '이름으로 찾기 (예: AKM)', value: rgQ });
      ov.firstChild.querySelector('.grow').appendChild(inp);
      const chips = L.h('div', { class: 'ry-chips' }), list = L.h('div', { class: 'ry-body' });
      const draw = () => {
        list.innerHTML = '';
        const q = rgQ.trim().toLowerCase();
        const ids = GUN.map((G, i) => i).filter((i) => (rgCls < 0 || GUN[i].c === rgCls) && (!q || GUN[i].nm.toLowerCase().includes(q)));
        if (!ids.length) list.appendChild(L.h('div', { class: 'ry-wt', text: '맞는 총이 없어요' }));
        ids.forEach((i) => {
          const G = GUN[i], r = L.h('button', { type: 'button', class: 'ry-row', style: { width: '100%', marginBottom: '4px' }, onclick: () => { act([60, i]); sfx('chip', 40); closeOv(); } });
          r.appendChild(icSpan(ICON(i)));
          r.appendChild(L.h('span', { class: 't', text: G.nm }, L.h('small', { text: CLS[G.c].nm + ' · ' + AMMO[G.am].nm + ' · 피해 ' + G.d + (G.n ? '×' + G.n : '') + ' · ' + (G.po === 'B' ? '모든 섬' : G.po === 'A' ? '보급' : (MAPS.find((T) => T.k === G.po) || {}).nm) })));
          list.appendChild(r);
        });
      };
      [[-1, '전체']].concat(CLS.map((C, i) => [i, C.nm])).forEach(([c, t]) => chips.appendChild(L.h('button', { type: 'button', class: rgCls === c ? 'on' : '', text: t, onclick: (e) => { rgCls = c; chips.querySelectorAll('button').forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); draw(); } })));
      inp.addEventListener('input', () => { rgQ = inp.value; draw(); });
      inp.addEventListener('keydown', (e) => e.stopPropagation());
      ov.appendChild(chips); ov.appendChild(list); draw();
    }
    function openRangeAtt() {
      const p = myP(); if (!p || !W || !W.rg) return;
      if (ovKind === 'ratt') { closeOv(); return; }
      const s0 = p.sl <= 2 && p.g[p.sl] ? p.sl : p.g[0] ? 0 : p.g[2] ? 2 : -1;
      if (s0 < 0) { api.toast('먼저 총을 골라요'); return; }
      mkOv('ratt', '부착물 · ' + GUN[p.g[s0].t].nm);
      const list = L.h('div', { class: 'ry-body' });
      const draw = () => {
        list.innerHTML = '';
        const w = p.g[s0]; if (!w) return;
        ASN.forEach((n, k) => {
          const opts = ATT.map((A, ai) => ai).filter((ai) => ATT[ai].k === k && accepts(w.t, ai));
          list.appendChild(L.h('div', { class: 'ry-sec', text: n + (opts.length ? '' : ' — 이 총은 못 달아요') }));
          opts.forEach((ai) => {
            const on = w.a[k] === ai + 1, A = ATT[ai];
            const r = L.h('button', { type: 'button', class: 'ry-row' + (on ? ' up' : ''), style: { width: '100%', marginBottom: '4px' }, onclick: () => { act([61, ai, s0]); sfx('click', 40); setTimeout(draw, 120); } });
            r.appendChild(icSpan(ICON(I_ATT + ai)));
            r.appendChild(L.h('span', { class: 't', text: (on ? '✓ ' : '') + A.nm }, L.h('small', { text: attText(A) })));
            list.appendChild(r);
          });
        });
      };
      ov.appendChild(list); draw();
    }
    /* 연습장: 설정 켜고 끄기 · 탈것 · 아이템 · 끝내기 + DPS 표시 · 조작 안내 */
    const prDps = [];
    let prHud = null;
    function openPractice() {
      const p = myP(); if (!p || !W || !W.pr) return;
      if (ovKind === 'rprac') { closeOv(); return; }
      mkOv('rprac', '연습 도구');
      const list = L.h('div', { class: 'ry-body' });
      const row = (txt, sub, on, fn) => list.appendChild(L.h('button', { type: 'button', class: 'ry-row' + (on ? ' up' : ''), style: { width: '100%', marginBottom: '4px' }, onclick: fn }, L.h('span', { class: 't', text: txt }, L.h('small', { text: sub }))));
      const draw = () => {
        list.innerHTML = '';
        list.appendChild(L.h('div', { class: 'ry-sec', text: '설정' }));
        [[1, '무한 체력', '꺼 두면 표적 반격에 맞아요(쓰러질 만큼 맞으면 바로 다시 차요)'], [2, '즉시 재장전', '재장전 시간이 거의 없어요'], [4, '표적 움직이기', '켜면 모든 표적이 좌우로 움직여요 · 끄면 가만히'], [8, '표적 반격', '켜면 표적이 나를 쏴요(1.4초마다 7 피해, 멀수록 덜 맞음)']].forEach(([bit, nm, ds]) => {
          const on = !!(W.prf & bit);
          row((on ? '✓ 켬 · ' : '끔 · ') + nm, ds, on, () => { act([66, W.prf ^ bit]); sfx('click', 40); setTimeout(draw, 120); });
        });
        list.appendChild(L.h('div', { class: 'ry-sec', text: '아이템' }));
        row('🎒 모두 채우기', '투척물·회복템 5개씩 · 3레벨 조끼·헬멧·가방 · 체력·기력 가득', false, () => { act([65]); sfx('chip', 40); });
        list.appendChild(L.h('div', { class: 'ry-sec', text: '탈것 꺼내기 (내 앞 4m · 최대 6대)' }));
        VEH.forEach((V, i) => { if (V.land) row('🚗 ' + V.nm, '최고 ' + Math.round(V.vmax * 3.6) + 'km/h · 내구 ' + V.hp + ' · ' + V.seats + '인승' + (V.land === 2 ? ' · 물 위도 가요' : ''), false, () => { act([64, i]); sfx('chip', 40); closeOv(); }); });
        list.appendChild(L.h('div', { class: 'ry-sec', text: '연습 끝내기' }));
        row('🏁 끝내기', '점수 없이 연습장을 나가요', false, () => { act([67]); closeOv(); });
      };
      ov.appendChild(list); draw();
    }
    function practiceHud() {
      const p = W && W.pr ? myP() : null;
      if (!p || W.ph !== 2) { if (prHud) prHud.style.display = 'none'; return; }
      if (!prHud) { prHud = L.h('div', { style: 'position:absolute;left:50%;transform:translateX(-50%);bottom:10px;z-index:3;pointer-events:none;background:rgba(18,16,24,.78);color:#f2e9d8;border-radius:10px;padding:5px 10px;font:600 12px var(--f-body,system-ui);text-align:center;white-space:nowrap;max-width:62vw;overflow:hidden' }); root.appendChild(prHud); }
      prHud.style.display = '';
      const now = W.T; prDps.push([now, p.dd || 0]); while (prDps.length > 2 && now - prDps[0][0] > 5) prDps.shift();
      const a = prDps[0], span = Math.max(1, now - a[0]), dps = Math.max(0, ((p.dd || 0) - a[1]) / span);
      const acc = p.sf ? Math.round((p.sh || 0) / p.sf * 100) : 0, w = heldGun(p);
      const sig = Math.round(dps) + '|' + Math.round(p.dd || 0) + '|' + acc + '|' + (p.hs | 0) + '|' + (w ? w.t : -1) + '|' + (pcMode() ? 1 : 0);
      if (prHud._s === sig) return; prHud._s = sig;
      prHud.innerHTML = '';
      prHud.appendChild(L.h('div', { style: 'font:800 13px var(--f-mono,monospace);color:#ffd27a', text: 'DPS ' + Math.round(dps) + ' · 누적 ' + Math.round(p.dd || 0) + ' · 명중 ' + acc + '% · 머리 ' + (p.hs | 0) }));
      prHud.appendChild(L.h('div', { style: 'opacity:.8;font-size:11px', text: (w ? GUN[w.t].nm + ' · ' : '') + (pcMode() ? 'WASD 이동 · 좌클릭 사격 · 우클릭 조준 · R 재장전 · Shift 달리기 · G 타기·내리기 · Esc 멈춤' : '왼쪽 스틱 이동 · 오른쪽 버튼 사격·조준·재장전 · 🧰 연습 도구') }));
    }
    /* key guide (PC) */
    function openKeys() {
      if (ovKind === 'keys') { closeOv(); return; }
      closeOv(); closeMenus();
      ovKind = 'keys';
      const bs = api.input && api.input.bindings ? api.input.bindings() : [];
      const keysOf = (id) => { const b = bs.find((x) => x.id === id); const ks = b ? b.keys.map(keyName).filter(Boolean) : []; return ks.filter((k, i) => ks.indexOf(k) === i); };
      const kb = (arr) => arr.map((k) => '<kbd>' + k.replace(/</g, '&lt;') + '</kbd>').join('');
      const GROUPS = [
        ['이동', [['이동', ['up', 'left', 'down', 'right']], [runMode() === 'toggle' ? '달리기 (눌러서 켜기/끄기)' : '달리기 (누르고 있기)', 'sprint'], [crMode() === 'toggle' ? '앉기 (눌러서 켜기/끄기)' : '앉기 (누르고 있기)', 'crouch'], ['바라보기', null, '마우스'], ['차 자리 바꾸기', 'seat']]],
        ['전투', [['쏘기', 'fire', '왼쪽 클릭'], ['조준경', 'ads', '오른쪽 클릭'], ['장전', 'reload'], ['무기 1~5', ['slot1', 'slot2', 'slot3', 'slot4', 'slot5']], ['다음 무기', 'nextw', '휠'], ['치료', 'heal']]],
        ['물건·행동', [['시체·상자 열기 / 고른 물건 줍기', 'open'], ['겹친 물건 중 고르기', null, '휠'], ['문 열기·닫기', 'door'], ['문 잠그기 (건물 안)', 'lock'], ['창문 넘기', 'vault'], ['타기 / 내리기', 'ride'], ['소지품', 'inv']]],
        ['기타', [['지도', 'map'], ['핑', 'ping'], ['키 안내', 'keys'], ['관전 대상 바꾸기', 'next'], ['규칙', null, 'F1'], ['창 닫기 / 나가기', null, 'Esc']]],
      ];
      const grid = L.h('div', { class: 'ry-kgrid' });
      for (const [title, rows] of GROUPS) {
        const tb = L.h('table');
        for (const [lbl, id, extra] of rows) {
          let ks = [];
          if (Array.isArray(id)) { if (id[0] === 'up') { const m = id.map((x) => keysOf(x)[0] || ''); ks = [m.join('')]; const alt = id.map((x) => keysOf(x)[1] || ''); if (alt.every(Boolean)) ks.push(alt.join('')); } else ks = [id.map((x) => keysOf(x)[0] || '').join(' ')]; }
          else if (id) ks = keysOf(id);
          if (extra) ks.push(extra);
          const tr = L.h('tr'), a = L.h('td', { text: lbl }), b = L.h('td');
          b.innerHTML = kb(ks.filter(Boolean));
          tr.appendChild(a); tr.appendChild(b); tb.appendChild(tr);
        }
        grid.appendChild(L.h('div', null, L.h('h5', { text: title }), tb));
      }
      const x = L.h('button', { type: 'button', class: 'ry-x', 'aria-label': '닫기', onclick: () => closeOv() }, '✕', L.h('small', { text: bindKey('keys') || 'Esc' }));
      const card = L.h('div', { class: 'ry-kcard' }, L.h('div', { class: 'ry-ovh' }, L.h('b', { text: '키 안내' }), L.h('div', { class: 'grow' }), x), grid,
        L.h('div', { class: 'ry-knote', text: '키는 설정 화면의 「⌨ 조작 설정」에서 바꿀 수 있어요. 게임패드: 왼쪽 스틱 이동 · 오른쪽 스틱 조준 · RT 쏘기.' }));
      ov = L.h('div', { class: 'ry-kov' }, card);
      ov.addEventListener('pointerdown', (e) => { e.stopPropagation(); if (e.target === ov) closeOv(); });
      root.appendChild(ov);
    }
    function syncOv() {
      if (!ov) return;
      const p = myP();
      if (!p || p.out || !W || (ovKind !== 'map' && ovKind !== 'keys' && W.ph !== 2)) { closeOv(); return; }
      if (ovKind === 'inv') renderInv(); else if (ovKind === 'map') drawMap();
      else if (ovKind === 'ratt' && !(W && W.rg)) closeOv();
    }
    const onKey = (e) => { if (e.key === 'Escape' && (ov || pmenu)) { e.preventDefault(); closeOv(); closeMenus(); } if (!kbUsed && /^(Key|Digit|Arrow|Shift|Tab|Space)/.test(e.code || '')) { kbUsed = true; bSig = ''; placeBtns(); } };
    window.addEventListener('keydown', onKey);
    const offIn = api.input ? api.input.on((type, id) => {
      if (type === 'up' && id === 'ads' && adsMode() === 'hold' && locAds && ctrlOn()) { toggleAds(); return; }
      if (type === 'up' && id === 'crouch') { if (ctrlOn()) crUp(); return; }
      if (type === 'up') { if (id === 'fire' && throwing()) { pulseAim = null; if (mouse) { const p = myP(), w = toWorld(mouse.x, mouse.y); if (p) pulseAim = [Math.atan2(w.y - p.y, w.x - p.x), hyp(w.x - p.x, w.y - p.y)]; } pulse = 0.16; } return; }
      if (id === 'next' && (!ctrlOn() || (myP() && myP().out))) { nextSpec(); return; }
      if (!ctrlOn()) return;
      const p = myP();
      if (id === 'keys') { openKeys(); return; }
      if (id === 'inv') { openInv(); return; }
      if (id === 'map') { openMap(); return; }
      if (id === 'sprint') { if (runMode() === 'toggle') { runLock = runLock ? 0 : 1; bSig = ''; } return; }
      if (id === 'reload') act(1); else if (id === 'heal') act(3); else if (id === 'ads') { if (adsMode() === 'toggle' || !locAds) toggleAds(); }
      else if (id === 'open') keyOpen();
      else if (id === 'padUse') { const c = cxs; if (c.veh && c.veh.k === 'x') ctxDo('v'); else if (c.box || nearItems(p).length || c.rev) keyOpen(); else if (c.door) ctxDo('d'); else if (c.win) ctxDo('w'); else if (c.veh) ctxDo('v'); } else if (id === 'door') ctxDo('d'); else if (id === 'vault') ctxDo('w'); else if (id === 'ride') ctxDo('v');
      else if (id === 'crouch') crDown(); else if (id === 'seat') act(42); else if (id === 'ping') quickPing();
      else if (id === 'lock') { const c = cxs.door; if (c) act([44, c.j]); }
      else if (/^slot[1-5]$/.test(id)) act(3 + +id.slice(4));
      else if (id === 'nextw' && p) nextWeapon(1);
    }) : null;
    const releaseAll = () => { stick = null; fireBtn = null; ptAim = null; for (const k in btn) if (btn[k].classList) btn[k].classList.remove('on'); };
    window.addEventListener('blur', releaseAll);

    /* ----- effects ----- */
    const lastSfx = {};
    function sfx(n, gap) { const t = performance.now(); if (t - (lastSfx[n] || 0) < (gap || 60)) return; lastSfx[n] = t; api.sfx(n); }
    function puff(x, y, n, sp, cols, life, dir, spread, grav) {
      for (let i = 0; i < n; i++) {
        const a = dir == null ? Math.random() * 6.283 : dir + (Math.random() - 0.5) * (spread || 1), v = sp * (0.3 + Math.random());
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: (life || 0.6) * (0.6 + Math.random() * 0.6), c: cols[i % cols.length], r: 0.05 + Math.random() * 0.1, g: grav || 0 });
      }
      if (parts.length > 320) parts.splice(0, parts.length - 320);
    }
    function addFloat(x, y, txt, c, big) { floats.push({ x, y, t: 0, life: big ? 1.4 : 0.9, txt, c, big }); if (floats.length > 16) floats.shift(); }
    function decal(x, y, r, k, a) { decals.push({ x, y, r, k, a: a == null ? 1 : a, rot: Math.random() * 6.28, sd: Math.random() * 1000, t: 0 }); if (decals.length > 160) decals.shift(); }
    function viewerPos() { const v = viewer(); return v || (W ? { x: cam.x, y: cam.y } : null); }
    const distV = (x, y) => { const v = viewerPos(); return v ? hyp(v.x - x, v.y - y) : 0; };
    const near = (x, y, r) => distV(x, y) < (r || 18);
    const gore = () => !st || st.gore !== 0;
    function blood(x, y, dir, n, big) {
      if (!gore()) { puff(x, y, 4, 2, ['#e8d6c8'], 0.3); return; }
      puff(x, y, n, big ? 7 : 5, ['#8a0d10', '#b5141a', '#6a0a0c', '#c62128'], 0.45, dir, 1.1);
      const k = big ? 1.4 : 0.7;
      const d = 0.5 + Math.random() * 1.2;
      decal(x + (dir == null ? 0 : Math.cos(dir) * d), y + (dir == null ? 0 : Math.sin(dir) * d), (0.35 + Math.random() * 0.4) * k, 0, 0.85);
    }
    function onFx(code, a, b, c, d) {
      const m = me();
      try { recFx(code, a, b, c, d); } catch (e) {}
      switch (code) {
        case 1: {
          const by = (d >> 10) - 1, dmg = (d >> 2) & 255, head = d & 1, big = d & 2;
          const sh = W && by >= 0 ? W.pl[by] : null, dir = sh ? Math.atan2(b - sh.y, a - sh.x) : null;
          if (vis[c]) vis[c].hit = 1;
          if (near(a, b, 30)) blood(a, b, dir, head ? 10 : 6, head || big);
          if (c === m) {
            api.buzz(dmg > 30 ? 30 : 12); shake = Math.max(shake, dmg > 30 ? 0.45 : 0.22); hurtT = 0.5;
            if (sh) { dmgDir.push({ a: Math.atan2(sh.y - b, sh.x - a), t: 0 }); if (dmgDir.length > 4) dmgDir.shift(); }
          }
          if (by === m && c !== m) {
            marks.push({ x: a, y: b, t: 0, k: big ? 2 : head ? 1 : 0 }); if (marks.length > 6) marks.shift();
            Snd.hit(head);
            if (st && st.dn) addFloat(a + (Math.random() - 0.5) * 0.8, b - 1.2, String(dmg), head ? '#ffd23f' : '#ffffff');
          }
          break;
        }
        case 2: {
          const by = d - 1;
          if (near(a, b, 30)) { blood(a, b, null, 14, true); if (gore()) decal(a, b, 0.9, 0, 0.8); }
          feed.push({ t: 0, k: by, v: c, how: "기절", kd: 1 }); if (feed.length > 2) feed.shift();
          if (c === m) { banner = { t: '기절했어요!', sub: '기어서 숨으세요 · 팀원이 살려 줄 수 있어요', c: '#ff8f7a', life: 3, max: 3 }; api.buzz(80); }
          else if (by === m) { addFloat(a, b - 2, '기절시킴!', '#ffb347', true); sfx('hit', 100); }
          break;
        }
        case 3: {
          const by = Math.floor(d / 512) - 1, how = (d % 512) - 12;
          if (near(a, b, 40)) {
            blood(a, b, null, 22, true);
            if (gore()) { decal(a, b, 1.5, 0, 0.9); decal(a + 0.4, b + 0.3, 1.0, 0, 0.8); }
            rings.push({ x: a, y: b, t: 0, life: 0.5, r0: 0.4, r1: 2.2, c: '#c62128' });
            sfx('thud', 60);
          }
          const hw = how >= 0 && how < NITEM ? iname(how) : how === -1 ? '주먹' : how === -2 ? '자기장' : how === -3 ? '차에 치임' : how === -4 ? '차량 폭발' : how === -6 ? '화염' : how === -7 ? '익사' : how === -8 ? '동물' : how === -9 ? '최루탄' : how === -10 ? '용암' : how === -11 ? '레드존' : how === -12 ? '무너진 천장' : '출혈';
          feed.push({ t: 0, k: by, v: c, how: hw, zone: by < 0 }); if (feed.length > 2) feed.shift();
          if (c === m) { api.buzz(150); shake = 1; api.sfx('lose'); outT = 0; specT = by >= 0 && W && W.pl[by] && !W.pl[by].out ? by : -1; }
          else if (by === m) { addFloat(a, b - 2.4, '처치!', '#e3ae45', true); api.buzz(40); sfx('win', 200); marks.push({ x: a, y: b, t: 0, k: 3 }); if (marks.length > 6) marks.shift(); Snd.tone(1200, 600, 0.18, 0.12, 'square'); }
          if (c === specT && (m < 0 || (W && W.pl[m] && W.pl[m].out))) specT = by >= 0 && W && W.pl[by] && !W.pl[by].out ? by : -1;
          break;
        }
        case 4: if (c === m) { sfx('chip', 50); addFloat(a, b - 0.8, '+ ' + iname(d), RARC[irar(d)]); } break;
        case 5: {
          const gi = c & 255, kind = (c >> 8) & 3, sup = (c >> 10) & 1, sh = c >> 11, G = GUN[gi]; if (!G) break;
          const ang = Math.floor(d / 256) / 100 - Math.PI, len = d & 255;
          const V = vis[sh]; if (V) { V.mf = 0.06; V.ma = ang; V.kick = 1; }
          const dist = distV(a, b);
          if (dist < (sup ? 30 : 80)) Snd.gun(G.c, sup || G.c === 7, sh === m ? 1 : clamp(1.2 / (1 + dist / 14), 0.05, 0.9));
          heard(a, b, 'gun', sup || G.c === 7 ? 25 : 90, sh);
          if (len > 0) {
            const x1 = a + Math.cos(ang) * len, y1 = b + Math.sin(ang) * len;
            tracers.push({ x0: a, y0: b, x1, y1, t: 0, life: G.c === 5 ? 0.16 : 0.08, w: G.c === 5 || G.c === 4 ? 2.2 : G.c === 3 ? 1.2 : 1.6, sup, sg: G.c === 3 ? ang : null });
            if (tracers.length > 40) tracers.shift();
            if (kind === 1 || kind === 3) { puff(x1 - Math.cos(ang) * 0.15, y1 - Math.sin(ang) * 0.15, 4, 3, kind === 3 ? ['#ffd27a', '#ffffff'] : ['#d8c8a8', '#ffffff', '#ffd27a'], 0.25, ang + Math.PI, 1.6); }
          }
          if (sh === m) {
            // camera kick + shake scale with the gun's punch (damage × pellets); the crosshair climbs in a fixed per-gun pattern and settles back
            const pw = clamp(G.d * (G.n || 1) / 60, 0.15, 1.6), k = 0.1 + pw * 0.28; kick.x -= Math.cos(ang) * k; kick.y -= Math.sin(ang) * k;
            shake = Math.max(shake, 0.04 + pw * 0.18);
            const now2 = performance.now(); if (now2 - rcl.t > 350) rcl.n = 0; rcl.t = now2; rcl.n++;
            const up = (2 + G.rc * 3) * (1 + pw * 0.5), sd = Math.sin(rcl.n * 1.7 + gi) * up * 0.45;
            rcl.x -= Math.sin(ang) * sd; rcl.y += -up * (rcl.n < 8 ? 1 : 0.4) + Math.cos(ang) * sd * 0.2;
            rcl.x = clamp(rcl.x, -30, 30); rcl.y = clamp(rcl.y, -40, 8);
          }
          break;
        }
        case 6: if (c === -1) puff(a, b, 4, 2.5, ['#d8c8a8', '#ffffff'], 0.3); else if (c === m) sfx('click', 120); break;
        case 7: {
          const R = c / 10, dist = distV(a, b);
          rings.push({ x: a, y: b, t: 0, life: 0.5, r0: 0.4, r1: R, c: '#ffd27a', fill: 1 });
          rings.push({ x: a, y: b, t: 0, life: 0.8, r0: R * 0.5, r1: R * 1.3, c: '#ffffff' });
          puff(a, b, 28, R * 1.6, ['#ffb347', '#ff6a2a', '#5a5048', '#3a3530', '#ffd27a'], 0.9);
          decal(a, b, R * 0.45, 1, 0.75);
          if (dist < 90) Snd.boom(clamp(1.3 / (1 + dist / 12), 0.08, 1));
          heard(a, b, 'boom', 120, -1);
          shake = Math.max(shake, clamp(1.2 - dist / 25, 0, 1));
          break;
        }
        case 8: if (near(a, b, 40)) { sfx('whoosh', 80); puff(a, b, 10, 2, ['#d8dde6', '#ffffff'], 1); } break;
        case 9: if (near(a, b, 40)) { sfx('pop', 80); Snd.burst(0.6, 0.3, 'lowpass', 1200, 200); } break;
        case 10: rings.push({ x: a, y: b, t: 0, life: 0.4, r0: 0.5, r1: 7, c: '#ffffff', fill: 1 }); if (near(a, b, 40)) { Snd.burst(0.3, 0.5, 'highpass', 4000, 2000); Snd.tone(3000, 2800, 0.6, 0.06); } break;
        case 11:
          if (d === 20 && c === m) api.toast('쓸 수 있는 치료 아이템이 없어요');
          else if (d === 21 && c === m) api.toast('가방이 꽉 찼어요 — 가방(Tab)에서 덜어 내요');
          else if (d === 22 && c === m) api.toast('문 앞에 누가 있어서 못 닫아요');
          else if (d === 23 && c === m) api.toast('잠긴 문이에요 🔒');
          else if (d >= 30 && d < 40 && near(a, b)) sfx('card', 100);
          else if (d < 5) { addFloat(a, b - 1.6, d >= 3 ? '+스태미나' : '+체력', '#7fe07a'); if (c === m) sfx('chip'); }
          else if (d === 10) { addFloat(a, b - 1.6, '살아났어요!', '#7fe07a', true); if (c === m) sfx('win', 200); }
          break;
        case 12: { const ang = ((d % 1000) - 400) / 100; rings.push({ x: a, y: b, t: 0, life: 0.18, r0: 0.5, r1: 1.4, c: '#ffffff', arc: ang }); if (near(a, b)) sfx('whoosh', 90); break; }
        case 13: banner = { t: '자기장이 줄어들어요!', sub: '흰 원 안으로 들어가세요', c: '#7fb8ff', life: 2.6, max: 2.6 }; sfx('whoosh'); api.buzz(25); break;
        case 14: banner = { t: '보급 상자 투하!', sub: '지도의 빨간 연기를 찾아요 · 귀한 총이 들어 있어요', c: '#ff7a5a', life: 2.6, max: 2.6 }; plane = { x: a, y: b, t: 0 }; sfx('whoosh'); break;
        case 15: if (near(a, b)) { sfx('chip'); Snd.tone(660, 990, 0.2, 0.12, 'triangle'); } if (c === m) addFloat(a, b - 1.5, '보급 상자 열림!', '#ff9a6a', true); break;
        case 16: if (ctrlOn()) sfx('whoosh'); break;
        case 17:
          if (d === 99) { if (near(a, b, 30)) { sfx('whoosh', 70); puff(a, b, 8, 2, ['#ff8a3a', '#ffd25a', '#555'], 0.7); } { const me = myP(); if (me && me.veh >= 0 && W.vh[me.veh] && hyp(W.vh[me.veh].x - a, W.vh[me.veh].y - b) < 1) { banner = { t: '차에 불이 붙었어요!', sub: '곧 폭발해요 — 빨리 내리세요', c: '#ff5a3a', life: 2.4, max: 2.4 }; api.buzz(40); } } break; }
          if (near(a, b, 25)) { Snd.tone(d ? 70 : 110, d ? 140 : 50, 0.35, 0.18, 'sawtooth'); rings.push({ x: a, y: b, t: 0, life: 0.35, r0: 0.6, r1: 2.2, c: d ? '#7fb8ff' : '#ffffff' }); puff(a, b, 4, 1.2, ['#c8c2b0', '#9a9488'], 0.4); }
          if (c === m) addFloat(a, b - 1.6, d ? '탑승' : '하차', d ? '#7fb8ff' : '#dddddd');
          break;
        case 18: if (near(a, b, 30)) { sfx('thud', 120); puff(a, b, 6, 3, ['#9a9a9a', '#5a5a5a'], 0.4); } break;
        case 19: if (near(a, b, 25)) sfx('whoosh', 80); break;
        case 21: banner = { t: '착륙!' + (W.wx ? ' · ' + WXN[W.wx][0] + ' ' + WXN[W.wx][1] : ''), sub: W.wx ? WXD[W.wx] : st && st.ap ? '더 좋은 물건은 밟으면 저절로 주워요' : '왼쪽 목록에서 물건을 눌러 주워요', c: '#e3ae45', life: 3, max: 3 }; sfx('pop'); api.buzz(20); break;
        case 25: if (d === 0) { banner = { t: '레드존 경고!', sub: '빨간 원에 곧 폭격 — 건물 안으로 피하세요', c: '#ff5a4a', life: 3, max: 3 }; sfx('whoosh'); api.buzz(30); } else if (near(a, b, 80)) Snd.tone(220, 110, 0.5, 0.12, 'sawtooth'); break;
        case 26: if (near(a, b, 60)) { sfx('pop', 80); rings.push({ x: a, y: b, t: 0, life: 0.6, r0: 1, r1: 10, c: '#ff8a5a' }); } if (d === 1 && c === m) api.toast('조명탄 신호! 곧 보급 상자가 떨어져요'); break;
        case 27: {
          const by = d & 1, dmg = (d >> 1) & 255, dead = d & 512;
          if (near(a, b, 30)) { puff(a, b, 5, 3, gore() ? ['#8a0d10', '#b5141a'] : ['#e8d6c8'], 0.4); if (dead) { rings.push({ x: a, y: b, t: 0, life: 0.5, r0: 0.4, r1: 1.8, c: '#c62128' }); sfx('thud', 80); } }
          if (by && st && st.dn && distV(a, b) < 40) addFloat(a + (Math.random() - 0.5) * 0.6, b - 1, String(dmg), '#ffd0a0');
          break;
        }
        case 28: if (near(a, b, 18)) Snd.tone(d === 2 || d === 3 ? 90 : 160, d === 2 || d === 3 ? 60 : 110, 0.35, 0.14, 'sawtooth'); break;
        case 41: rings.push({ x: a, y: b, t: 0, life: 0.25, r0: 0.3, r1: 1.4, c: '#ff6a4a' }); if (near(a, b, 60)) Snd.tone(420, 180, 0.06, 0.12, 'square'); break;
        case 42: if (c === m) banner = { t: '쓰러질 뻔했어요', sub: '연습장에서는 체력이 다시 차요', c: '#ffb070', life: 1.8, max: 1.8 }; break;
        case 29: { const dmg = d >> 1, head = d & 1; addFloat(a + (Math.random() - 0.5) * 0.6, b - 1.2, String(dmg), head ? '#ffd23f' : '#ffffff', head); Snd.hit(head); marks.push({ x: a, y: b, t: 0, k: head }); if (marks.length > 6) marks.shift(); break; }
        case 30: if (near(a, b, 40)) { sfx('thud', 60); shake = Math.max(shake, 0.3); puff(a, b, 18, 3, ['#8a8a8a', '#5a5a5a', '#c8c0b0'], 0.8); decal(a, b, 1.1, 1, 0.5); } break;
        case 32: if (near(a, b, 70)) { flashT = 0.25; sfx('thud', 40); shake = Math.max(shake, 0.25); puff(a, b, 10, 2, ['#fff7c0', '#c8d8ff'], 0.4); decal(a, b, 1.1, 1, 0.5); } else flashT = Math.max(flashT, 0.08); break;
        case 33: if (near(a, b, 30)) { sfx('whoosh', 70); puff(a, b, 14, 3, ['#ffffff', '#d8eef5'], 0.9); } break;
        case 40: {   // 귀환: d 1 start · 2 beep · 3 back · 4 closed · 5 cut · 10+i picked i's 인식표
          const who = W && W.pl[c], mt = who && who.tm === myTeam();
          if (d === 1) { if (near(a, b, RC.hear)) Snd.tone(880, 1320, 0.25, 0.12, 'square'); if (mt && c !== m) api.toast('📡 ' + name(c) + ' 귀환 송신 시작'); rings.push({ x: a, y: b, t: 0, life: 1, r0: 1, r1: 8, c: '#7fe0ff' }); }
          else if (d === 2) { if (near(a, b, RC.hear)) { const k = 1 - distV(a, b) / RC.hear; Snd.tone(1250, 1250, 0.07, 0.04 + 0.12 * k, 'square'); rings.push({ x: a, y: b, t: 0, life: 0.8, r0: 1, r1: 6, c: '#7fe0ff' }); } }
          else if (d === 3) {
            rings.push({ x: a, y: b, t: 0, life: 1.2, r0: 1, r1: 10, c: '#7fe0ff' });
            if (c === m) { banner = { t: '귀환!', sub: '낙하산으로 내려가요 · 권총·붕대만 들고 있어요', c: '#7fe0ff', life: 3.5, max: 3.5 }; api.sfx('win'); api.buzz(40); }
            else if (mt) { api.toast('🪂 ' + name(c) + ' 귀환!'); sfx('pop'); }
            feed.push({ t: 0, k: -1, v: c, how: '귀환', zone: 1 }); if (feed.length > 2) feed.shift();
          } else if (d === 4) { if (W && W.tm && st && !st.rg) banner = { t: '귀환 송신 종료', sub: '이제 쓰러진 팀원을 다시 부를 수 없어요', c: '#7fe0ff', life: 3, max: 3 }; }
          else if (d === 5) { if (c === m) api.toast('송신이 끊겼어요 — 다시 눌러요'); }
          else if (d >= 10) {
            const dead = d - 10;
            if (c === m) { banner = { t: '인식표를 주웠어요 · ' + name(dead), sub: '지도의 📡 송신탑에서 「귀환 호출」(8초)', c: '#7fe0ff', life: 3.5, max: 3.5 }; sfx('card'); }
            else if (mt) api.toast('🏷 ' + name(c) + '이(가) ' + name(dead) + '의 인식표를 주웠어요');
          }
          break;
        }
        case 31: banner = { t: '모래폭풍!', sub: '30초 동안 앞이 거의 안 보여요', c: '#e0b070', life: 3, max: 3 }; sfx('whoosh'); break;
        case 23: if (near(a, b, 22)) { if (d === 2) { sfx('click', 60); if (near(a, b, 6)) addFloat(a, b - 1, '🔒', '#ffd27a'); } else sfx(d ? 'card' : 'thud', 60); } break;
        case 24: if (near(a, b, 20)) sfx('whoosh', 80); break;
      }
    }
    const hooks = { fx: onFx };

    /* ----- 경기 요약 지도: this device records its own player (path · fights · loot · vehicles · zone) ----- */
    const HOWN = (how) => (how >= 0 && how < NITEM ? iname(how) : ({ '-1': '주먹', '-2': '자기장', '-3': '차에 치임', '-4': '차량 폭발', '-6': '화염', '-7': '익사', '-8': '동물', '-9': '최루탄', '-10': '용암', '-11': '레드존', '-12': '무너진 천장', '-13': '번개', '-14': '간헐천' })[how] || '출혈');
    const rr1 = (v) => Math.round(v * 10) / 10;
    function recReset() { rec = { t: 0, on: false, pts: [], ev: [], zs: [], lt: -9, zt: -9, zi: -1, lx: NaN, ly: NaN, lhp: NaN, lkd: 0, wd: 0, vd: 0, tk: 0, lk: 0, lkw: '', sf: 0, sh: 0, end: null, fT: {} }; }
    function recEv(o) { if (rec.ev.length < 400) rec.ev.push(o); }
    function recFx(code, a, b, c, d) {
      const m = me(); if (!rec || m < 0 || !W || W.ph !== 2) return;
      const p = W.pl[m]; if (!p) return;
      const t = rr1(rec.t), mx = rr1(p.x), my = rr1(p.y);
      const thr = (k, s) => { if (rec.t - (rec.fT[k] || -9) < s) return false; rec.fT[k] = rec.t; return true; };
      if (code === 1) {
        const by = (d >> 10) - 1, dmg = (d >> 2) & 255;
        if (by === m && c !== m && thr('s', 1.2)) recEv({ k: 's', t, x: mx, y: my, a: rr1(a), b: rr1(b), v: dmg });
        if (c === m && by >= 0 && by !== m && thr('h', 1.2)) { const q = W.pl[by]; recEv({ k: 'h', t, x: mx, y: my, a: q ? rr1(q.x) : mx, b: q ? rr1(q.y) : my }); }
      } else if (code === 2) {
        const by = d - 1, w = heldGun(p), dist = hyp(a - p.x, b - p.y);
        if (by === m && c !== m) recEv({ k: 'n', t, x: rr1(a), y: rr1(b), w: w ? GUN[w.t].nm : '', d: Math.round(dist), who: name(c) });
        if (c === m) recEv({ k: 'N', t, x: mx, y: my, who: by >= 0 ? name(by) : '' });
      } else if (code === 3) {
        const by = Math.floor(d / 512) - 1, how = (d % 512) - 12;
        if (by === m && c !== m) { const dist = Math.round(hyp(a - p.x, b - p.y)), w = HOWN(how); recEv({ k: 'k', t, x: rr1(a), y: rr1(b), w, d: dist, who: name(c) }); if (dist > rec.lk) { rec.lk = dist; rec.lkw = w; } }
        if (c === m && !rec.end) rec.end = { k: 'd', t, x: rr1(a), y: rr1(b), w: HOWN(how), who: by >= 0 && by !== m ? name(by) : '' };
      } else if (code === 4 && c === m && d >= 0 && d < NITEM && irar(d) >= 2) recEv({ k: 'l', t, x: mx, y: my, w: iname(d), r: irar(d) });
    }
    function recTick(dt) {
      const m = me(); if (!rec || m < 0 || !W || W.ph !== 2 || rec.end) return;
      const p = W.pl[m]; if (!p) return;
      if (p.out) { if (rec.on) rec.end = { k: 'd', t: Math.round(rec.t), x: rr1(p.x), y: rr1(p.y), w: '', who: '' }; return; }
      if (!fin(p.x) || !fin(p.y)) return;
      rec.on = true; rec.t += dt;
      const md = p.air > 0 ? 2 : p.veh >= 0 ? 1 : 0;
      if (fin(rec.lx)) { const dd = hyp(p.x - rec.lx, p.y - rec.ly); if (dd < 30 && md !== 2) { if (md === 1) rec.vd += dd; else rec.wd += dd; } }
      rec.lx = p.x; rec.ly = p.y;
      const hp = p.kd ? p.khp : p.hp;
      if (fin(rec.lhp) && rec.lkd === (p.kd ? 1 : 0) && hp < rec.lhp) rec.tk += rec.lhp - hp;
      rec.lhp = hp; rec.lkd = p.kd ? 1 : 0;
      const L0 = rec.pts[rec.pts.length - 1];
      if (rec.t - rec.lt >= 1 || (L0 && L0[3] !== md)) {
        rec.lt = rec.t;
        // compression: a sample lying on the straight line between its neighbours (same mode) is dropped
        const pt = [rr1(rec.t), rr1(p.x), rr1(p.y), md], n = rec.pts.length;
        if (n >= 2) {
          const A = rec.pts[n - 2], B = rec.pts[n - 1], span = pt[0] - A[0];
          if (A[3] === md && B[3] === md && span < 12 && span > 0) { const f = (B[0] - A[0]) / span, ex = A[1] + (pt[1] - A[1]) * f, ey = A[2] + (pt[2] - A[2]) * f; if (hyp(ex - B[1], ey - B[2]) < 0.8) rec.pts.pop(); }
        }
        if (rec.pts.length < 4000) rec.pts.push(pt);
        if (L0 && L0[3] !== md && md !== 2 && L0[3] !== 2) recEv({ k: md ? 'vi' : 'vo', t: pt[0], x: pt[1], y: pt[2], w: md && W.vh[p.veh] ? VEH[W.vh[p.veh].ty].nm : '' });
      }
      const z = W.z;
      if (z && fin(z.r) && (z.i !== rec.zi || (rec.t - rec.zt > 8 && Math.abs((rec.zs.length ? rec.zs[rec.zs.length - 1][3] : 0) - z.r) > 2))) { rec.zi = z.i; rec.zt = rec.t; if (rec.zs.length < 200) rec.zs.push([Math.round(rec.t), rr1(z.cx), rr1(z.cy), rr1(Math.max(0, z.r))]); }
      rec.sf = p.sf | 0; rec.sh = p.sh | 0;
    }
    function recWin() { const p = myP(); if (rec && p && !p.out && !rec.end && rec.on) rec.end = { k: 'w', t: Math.round(rec.t), x: rr1(p.x), y: rr1(p.y) }; }
    const sumReady = () => !!rec && rec.on && rec.pts.length > 1 && me() >= 0;
    let sumEl = null, sumRaf = 0;
    function closeSum() { if (sumRaf) cancelAnimationFrame(sumRaf); sumRaf = 0; if (sumEl) { sumEl.remove(); sumEl = null; } }
    function openSum() {
      if (!sumReady()) return;
      closeSum(); closeOv(); closeMenus();
      const R = rec, p = myP(), T = Math.max(1, R.end ? Math.max(R.end.t, R.t) : R.t);
      const kills = R.ev.filter((e) => e.k === 'k').length, knocks = R.ev.filter((e) => e.k === 'n').length;
      const sf = p ? p.sf | 0 : R.sf, sh = p ? p.sh | 0 : R.sh;
      const rows = [['생존 시간', fmtT(T)], ['이동 거리', fmtD(R.wd + R.vd)], ['차량 거리', fmtD(R.vd)], ['명중률', sf ? Math.round(sh / sf * 100) + '% (' + sh + '/' + sf + ')' : '-'],
        ['처치', String(p ? p.kills : kills) + (knocks ? ' · 기절 ' + knocks : '')], ['가한 피해', String(Math.round(p ? p.dd || 0 : 0))], ['받은 피해', String(Math.round(R.tk))],
        ['최장 처치 거리', R.lk ? R.lk + 'm' + (R.lkw ? ' (' + R.lkw + ')' : '') : '-']];
      const endTxt = R.end ? (R.end.k === 'w' ? '🏆 끝까지 살아남았어요' : '💀 ' + fmtT(R.end.t) + (R.end.who ? ' · ' + R.end.who + '에게' : '') + (R.end.w ? ' · ' + R.end.w : '')) : '';
      const mc = L.h('canvas', { class: 'ry-sumcv' });
      const rng = L.h('input', { type: 'range', min: '0', max: '1000', value: '1000', 'aria-label': '시간' });
      const tl = L.h('span', { class: 'ry-sumt', text: fmtT(T) });
      let play = false, cur = T, last = 0;
      const pb = L.h('button', { type: 'button', class: 'ry-b', text: '▶ 다시 보기', onclick: () => { play = !play; if (play && cur >= T - 0.01) cur = 0; pb.textContent = play ? '⏸ 멈춤' : '▶ 다시 보기'; } });
      rng.addEventListener('input', () => { cur = T * (+rng.value) / 1000; play = false; pb.textContent = '▶ 다시 보기'; });
      const x = L.h('button', { type: 'button', class: 'ry-x', 'aria-label': '닫기', onclick: closeSum }, '✕');
      const stat = L.h('div', { class: 'ry-sums' }, endTxt ? L.h('div', { class: 'end', text: endTxt }) : null, ...rows.map(([k, v]) => L.h('div', { class: 'r' }, L.h('span', { text: k }), L.h('b', { text: v }))),
        L.h('div', { class: 'lg', text: '— 걷기 · ━ 차량 · ┅ 낙하 · 색: 처음(파랑)→끝(빨강) · ✕ 처치 ◇ 기절 · ● 맞힘 ○ 맞음 · ★ 귀한 물건' }));
      sumEl = L.h('div', { class: 'ry-sum' }, L.h('div', { class: 'ry-sumh' }, L.h('b', { text: '🗺 경기 요약' }), L.h('div', { class: 'grow' }), x),
        L.h('div', { class: 'ry-sumb' }, L.h('div', { class: 'ry-summ' }, mc, L.h('div', { class: 'ry-sumbar' }, pb, rng, tl)), stat));
      sumEl.addEventListener('pointerdown', (e) => e.stopPropagation());
      (document.body || root).appendChild(sumEl);
      const ib = islandBox();
      const posAt = (t) => { const P0 = R.pts; let i = 0; while (i < P0.length - 1 && P0[i + 1][0] <= t) i++; const A = P0[i], B = P0[Math.min(P0.length - 1, i + 1)]; const f = B[0] > A[0] ? clamp((t - A[0]) / (B[0] - A[0]), 0, 1) : 0; return [A[1] + (B[1] - A[1]) * f, A[2] + (B[2] - A[2]) * f, A[3]]; };
      const hue = (t) => 'hsl(' + Math.round(210 - 210 * clamp(t / T, 0, 1)) + ',90%,58%)';
      function draw(now) {
        if (!sumEl) return;
        const dtt = last ? Math.min(0.1, (now - last) / 1000) : 0; last = now;
        if (play) { cur += dtt * Math.max(8, T / 40); if (cur >= T) { cur = T; play = false; pb.textContent = '▶ 다시 보기'; } rng.value = String(Math.round(cur / T * 1000)); }
        tl.textContent = fmtT(cur) + ' / ' + fmtT(T);
        const r = mc.getBoundingClientRect(), dpr = window.devicePixelRatio || 1, w = Math.max(10, r.width), h = Math.max(10, r.height);
        if (mc.width !== Math.round(w * dpr) || mc.height !== Math.round(h * dpr)) { mc.width = Math.round(w * dpr); mc.height = Math.round(h * dpr); }
        const g = mc.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
        g.fillStyle = '#2f7fb8'; g.fillRect(0, 0, w, h);
        const sc = Math.min(w, h) / (2 * ib.r), MX = (v) => w / 2 + (v - ib.x) * sc, MY = (v) => h / 2 + (v - ib.y) * sc;
        if (bgCv) g.drawImage(bgCv, MX(-HL), MY(-HL), 2 * HL * sc, 2 * HL * sc);
        // zone rings: every stage faint, the one at the scrub time bold
        let zc = null;
        for (const zz of R.zs) { if (zz[0] <= cur) zc = zz; g.strokeStyle = 'rgba(255,255,255,.22)'; g.lineWidth = 1; g.beginPath(); g.arc(MX(zz[1]), MY(zz[2]), Math.max(1, zz[3] * sc), 0, 7); g.stroke(); }
        if (zc) { g.strokeStyle = '#7fb8ff'; g.lineWidth = 2.5; g.beginPath(); g.arc(MX(zc[1]), MY(zc[2]), Math.max(1, zc[3] * sc), 0, 7); g.stroke(); }
        // path (up to the scrub time)
        g.lineCap = 'round'; g.lineJoin = 'round';
        const P0 = R.pts;
        for (let i = 1; i < P0.length; i++) {
          const A = P0[i - 1], B = P0[i]; if (A[0] > cur) break;
          const md = A[3], e = B[0] > cur ? posAt(cur) : [B[1], B[2]];
          if (md === 1) { g.strokeStyle = 'rgba(15,12,20,.85)'; g.lineWidth = 6.5; g.setLineDash([]); g.beginPath(); g.moveTo(MX(A[1]), MY(A[2])); g.lineTo(MX(e[0]), MY(e[1])); g.stroke(); }
          g.strokeStyle = hue(A[0]); g.lineWidth = md === 1 ? 3.6 : 2.2; g.setLineDash(md === 2 ? [4, 4] : []);
          g.beginPath(); g.moveTo(MX(A[1]), MY(A[2])); g.lineTo(MX(e[0]), MY(e[1])); g.stroke();
        }
        g.setLineDash([]);
        // events
        g.textAlign = 'center'; g.textBaseline = 'middle';
        for (const e of R.ev) {
          if (e.t > cur) continue;
          const X = MX(e.x), Y = MY(e.y);
          if (e.k === 's' || e.k === 'h') {
            g.strokeStyle = e.k === 's' ? 'rgba(255,210,80,.6)' : 'rgba(255,90,70,.6)'; g.lineWidth = 1; g.beginPath(); g.moveTo(X, Y); g.lineTo(MX(e.a), MY(e.b)); g.stroke();
            g.lineWidth = 1.5; g.beginPath();
            if (e.k === 's') { g.fillStyle = '#ffd23f'; g.strokeStyle = '#17131f'; g.arc(MX(e.a), MY(e.b), 3, 0, 7); g.fill(); g.stroke(); } else { g.strokeStyle = '#ff5a46'; g.arc(X, Y, 3.5, 0, 7); g.stroke(); }
          } else if (e.k === 'k') { g.strokeStyle = '#17131f'; g.lineWidth = 5; g.beginPath(); g.moveTo(X - 6, Y - 6); g.lineTo(X + 6, Y + 6); g.moveTo(X + 6, Y - 6); g.lineTo(X - 6, Y + 6); g.stroke(); g.strokeStyle = '#ff3a2a'; g.lineWidth = 2.6; g.stroke(); }
          else if (e.k === 'n' || e.k === 'N') { g.fillStyle = e.k === 'n' ? '#ffb347' : '#ff8f7a'; g.strokeStyle = '#17131f'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(X, Y - 6); g.lineTo(X + 6, Y); g.lineTo(X, Y + 6); g.lineTo(X - 6, Y); g.closePath(); g.fill(); g.stroke(); }
          else if (e.k === 'l') { g.font = '700 13px ' + FONT; g.fillStyle = RARC[e.r] || '#fff'; g.fillText('★', X, Y); }
          else if (e.k === 'vi' || e.k === 'vo') { g.font = '12px ' + FONT; g.fillText(e.k === 'vi' ? '🚗' : '🚶', X, Y - 9); }
        }
        const s0 = P0[0]; g.font = '700 11px ' + FONT; g.fillStyle = '#fff'; g.strokeStyle = '#17131f'; g.lineWidth = 3; g.strokeText('출발', MX(s0[1]), MY(s0[2]) - 10); g.fillText('출발', MX(s0[1]), MY(s0[2]) - 10);
        if (R.end && cur >= R.end.t - 0.5) { g.font = '18px ' + FONT; g.fillText(R.end.k === 'w' ? '🏆' : '💀', MX(R.end.x), MY(R.end.y)); }
        else { const c = posAt(cur); g.fillStyle = '#ffffff'; g.strokeStyle = '#17131f'; g.lineWidth = 2; g.beginPath(); g.arc(MX(c[0]), MY(c[1]), 6, 0, 7); g.fill(); g.stroke(); }
        sumRaf = requestAnimationFrame(draw);
      }
      sumRaf = requestAnimationFrame(draw);
    }
    // the core result sheet gets a 「🗺 경기 요약」 button too
    function sumInject() {
      if (!st || st.ph !== 'done' || !sumReady()) return;
      const sh = document.querySelector('.overlay.result .sheet'); if (!sh || sh.querySelector('.ry-sumgo')) return;
      sh.appendChild(L.h('button', { type: 'button', class: 'btn block ry-sumgo', text: '🗺 경기 요약', onclick: openSum }));
    }

    /* ----- host flow / online ----- */
    const remIn = {};
    let curDt = 0;
    function inputsFor() {
      const out = [];
      for (let s = 0; s < W.pl.length; s++) {
        if (isAIseat(s)) out[s] = aiThink(W, W.pl[s], aiMem[s], P(s).ai ? lvOf(s) : 2, curDt);
        else if (localHuman(s)) out[s] = locIn;
        else out[s] = remIn[s] || (remIn[s] = { ax: 0, ay: 0, fire: 0, aim: null, ad: null, acts: [], spd: 1, land: null, ads: 0, mag: 0, seen: -1 });
      }
      return out;
    }
    let pubT = 0, hsQ = 0, inQ = 0, lastQ = -1, lastFx = 0, snaps = [], lastSig = '', inT = 0, heavyV = -1, heavyN = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !W) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < W.pl.length) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object' || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = { ax: 0, ay: 0, fire: 0, aim: null, ad: null, acts: [], spd: 1, land: null, ads: 0, mag: 0, seen: -1 });
        R.ax = fin(+o.ax) ? clamp(+o.ax, -1, 1) : 0; R.ay = fin(+o.ay) ? clamp(+o.ay, -1, 1) : 0;
        R.fire = o.f ? 1 : 0; R.aim = fin(o.am) ? +o.am : null; R.ad = fin(o.ad) ? clamp(+o.ad, 0, 140) : null; R.ads = o.ds ? 1 : 0;
        R.cx = fin(+o.cx) ? +o.cx : null; R.cy = fin(+o.cy) ? +o.cy : null;
        if (Array.isArray(o.ld) && fin(+o.ld[0]) && fin(+o.ld[1])) R.land = [+o.ld[0], +o.ld[1]];
        R.sp = o.sp ? 1 : 0; R.face = fin(o.fc) ? +o.fc : null;
        if (Array.isArray(o.A)) for (const e of o.A) if (Array.isArray(e) && (e[0] | 0) > R.seen) {
          R.seen = e[0] | 0; const a = e[1] | 0;
          if (!ACTS[a] || R.acts.length >= 16) continue;
          if (e.length > 2) { const x = e.slice(1, 5).map((v) => (fin(+v) ? +v : 0)); R.acts.push(x); } else R.acts.push(a);
          R.dirty = 4;   // send this guest its bag + surroundings in the next few packets
        }
        R.iv = o.iv ? 1 : 0;
      }
    }
    function remoteSeats() { const out = []; for (let s = 0; s < (st.ns || 0); s++) if (!isAIseat(s) && !localHuman(s)) out.push(s); return out; }
    function remoteCams(seats) {
      const out = [];
      for (const s of seats) { const R = remIn[s], p = W.pl[s]; if (R && fin(R.cx)) out.push([R.cx, R.cy]); if (p && !p.out && W.ph >= 1) out.push([p.x, p.y]); }
      return out;
    }
    const PS2 = PS + 1;
    let myQ = null;
    const decBox = (b) => ({ x: +b[0], y: +b[1], ad: b[2] | 0, it: b.slice(3).map((c) => [Math.floor(c / 1000), c % 1000]).filter((e) => e[0] >= 0 && e[0] < NITEM) });
    /* the host's exact list of what lies around me replaces whatever the (thinned) world snapshot had there */
    function mergeQ(e) {
      const x = +e[1], y = +e[2], R = QR, inQ = (o) => Math.abs(o.x - x) < R && Math.abs(o.y - y) < R;
      W.dr = W.dr.filter((l) => !inQ(l));
      const D = Array.isArray(e[3]) ? e[3] : [];
      for (let i = 0; i + 2 < D.length; i += 3) { const c = D[i + 2] | 0, t = Math.floor(c / 1000); if (t >= 0 && t < NITEM) W.dr.push({ x: +D[i], y: +D[i + 1], t, n: c % 1000, by: -1, nt: 0 }); }
      W.bx = W.bx.filter((b) => !inQ(b));
      if (Array.isArray(e[4])) for (const b of e[4]) if (Array.isArray(b)) W.bx.push(decBox(b));
    }
    function pollGuest(now) {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.P)) return;
      lastQ = hs.q;
      W.ph = hs.ph | 0; W.t = +hs.t || 0; W.T = +hs.T || 0;
      if (Array.isArray(hs.Z)) { const Z = hs.Z, z = W.z; z.cx = +Z[0]; z.cy = +Z[1]; z.r = +Z[2]; z.nx = +Z[3]; z.ny = +Z[4]; z.nr = +Z[5]; z.i = Z[6] | 0; z.s = Z[7] | 0; z.t = +Z[8]; }
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; try { onFx(e[1], +e[2] || 0, +e[3] || 0, e[4] | 0, e[5] | 0); } catch (er) {} }
      const m = me(), A = hs.P, ix = {};
      if (typeof hs.O === 'string') W.pl.forEach((p, i) => { p.out = (parseInt(hs.O[i >> 2] || '0', 16) >> (i & 3)) & 1; });
      for (const p of W.pl) p.far = 1;
      for (let o = 0; o + PS2 - 1 < A.length; o += PS2) {
        const i = A[o] | 0, p = W.pl[i]; if (!p || !fin(+A[o + 1]) || !fin(+A[o + 2])) continue;
        ix[i] = o + 1; p.far = 0;
        const q = o + 1, fl = A[q + 4] | 0;
        p.out = fl & 1; p.kd = fl & 2 ? 1 : 0; p.ads = fl & 4 ? 1 : 0; p.use = (A[q + 14] | 0) / 10; p.rl = fl & 16 ? 0.1 : 0;
        p.cr = fl & 2048 ? 1 : 0; p.sx = fl & 4096 ? 1 : 0; p.vt = fl & 8192 ? 0.1 : 0; p.mf = fl & 16384 ? 0.2 : 0; p.lit = fl & 32768 ? 1 : 0; p.spc = (fl >> 16) & 3;
        if (fl & 32) p.ft = 0.12; p.rev = fl & 64 ? 0.1 : 0; p.swim = fl & 128 ? 1 : 0; p.fl = (A[q + 15] | 0) / 10; p.rvb = fl & 512 ? 1 : 0; p.burn = fl & 1024 ? 0.3 : 0;
        if (p.kd) p.khp = +A[q + 3]; else p.hp = +A[q + 3];
        p.hc = (A[q + 5] | 0) - 1; p.vs = A[q + 6] | 0; p.hm = A[q + 7] | 0; p.kills = A[q + 8] | 0; p.place = A[q + 9] | 0;
        p.veh = (A[q + 10] | 0) - 1; p.seat = A[q + 11] | 0; p.bp = A[q + 12] | 0;
        if (p.wasFar) { p.x = +A[q]; p.y = +A[q + 1]; }
        p.nx = +A[q]; p.ny = +A[q + 1]; p.na = +A[q + 2];
        if (i !== m) p.a = p.na;
      }
      for (const p of W.pl) p.wasFar = p.far;
      if (hs.I && m >= 0 && hs.I[m]) setInv(W.pl[m], hs.I[m]);
      { const N = Array.isArray(hs.N) ? hs.N : [], an = []; for (let k = 0; k + 6 < N.length; k += 7) { const K = ANI[N[k + 1] | 0]; if (!K) continue; const old = W.an.find((a) => a.j === (N[k] | 0)); an.push({ j: N[k] | 0, k: N[k + 1] | 0, x: old ? old.x : +N[k + 2], y: old ? old.y : +N[k + 3], nx: +N[k + 2], ny: +N[k + 3], a: +N[k + 4], hp: (N[k + 5] | 0) / 20 * K.hp, tg: N[k + 6] | 0 }); } W.an = an; }
      W.rz = Array.isArray(hs.RZ) ? { x: +hs.RZ[0], y: +hs.RZ[1], r: +hs.RZ[2], ph: hs.RZ[3] | 0, t: +hs.RZ[4] } : null;
      { const D = Array.isArray(hs.DB) ? hs.DB : []; W.db = []; for (let k = 0; k + 2 < D.length; k += 3) W.db.push({ x: +D[k], y: +D[k + 1], r: 2.6, t: +D[k + 2] }); }
      W.ss = +hs.SS || 0;
      { const D = Array.isArray(hs.LG) ? hs.LG : []; W.lg = []; for (let k = 0; k + 2 < D.length; k += 3) W.lg.push({ x: +D[k], y: +D[k + 1], r: 3, t: +D[k + 2] }); }
      { const D = Array.isArray(hs.LT) ? hs.LT : []; W.lt = []; for (let k = 0; k + 3 < D.length; k += 4) W.lt.push({ x: +D[k], y: +D[k + 1], r: +D[k + 2], t: +D[k + 3] }); }
      W.todOff = fin(+hs.TO) ? +hs.TO : DAY * 0.05;
      if (Array.isArray(hs.TG)) hs.TG.forEach((v, k) => { const g = W.tg[k >> 1]; if (!g) return; if (k & 1) g.hp = +v; else g.x = +v; });
      if (typeof hs.Dr === 'string') { let ch = 0; for (let j = 0; j < W.ds.length; j++) { const v = (parseInt(hs.Dr[j >> 2] || '0', 16) >> (j & 3)) & 1; if (W.ds[j] !== v) { W.ds[j] = v; ch = 1; } } if (ch) W.dv++; }
      { const DL = Array.isArray(hs.DL) ? hs.DL : []; W.dl.fill(0); for (let k = 0; k + 1 < DL.length; k += 2) { const j = DL[k] | 0; if (j >= 0 && j < W.dl.length) W.dl[j] = +DL[k + 1] || 0; } }
      { const G0 = Array.isArray(hs.G) ? hs.G : []; const old = {}; for (const g of W.pg) old[g.id] = 1; W.pg = []; for (let k = 0; k + 5 < G0.length; k += 6) { const g = { id: G0[k] | 0, i: G0[k + 1] | 0, k: G0[k + 2] | 0, x: +G0[k + 3], y: +G0[k + 4], t: +G0[k + 5] }; g.tm = W.pl[g.i] ? W.pl[g.i].tm : -1; W.pg.push(g); if (!old[g.id] && g.i !== m) newPing(g); } }
      { const RT = Array.isArray(hs.RT) ? hs.RT : []; W.dg = []; for (let k = 0; k + 4 < RT.length; k += 5) W.dg.push({ i: RT[k] | 0, x: +RT[k + 1], y: +RT[k + 2], by: RT[k + 3] | 0, t: +RT[k + 4] }); }
      { const CH = Array.isArray(hs.CH) ? hs.CH : []; W.ch = []; for (let k = 0; k + 2 < CH.length; k += 3) W.ch.push({ i: CH[k] | 0, j: CH[k + 1] | 0, u: (CH[k + 2] | 0) / 10 }); }
      W.rcOpen = hs.RO ? 1 : 0;
      for (const p of W.pl) if (p.ut === 10) p.ut = -1;
      for (const c of W.ch) { const p = W.pl[c.i]; if (p) { p.ut = 10; p.rcT = c.j; } }
      { const MK = Array.isArray(hs.MK) ? hs.MK : []; W.mk = {}; for (let k = 0; k + 2 < MK.length; k += 3) W.mk[MK[k] | 0] = [+MK[k + 1], +MK[k + 2]]; }
      if (hs.L && typeof hs.L === 'object') for (const k in hs.L) { const p = W.pl[+k], e = hs.L[k]; if (p && +k !== m && Array.isArray(e)) { p.lx = +e[0]; p.ly = +e[1]; } }
      snaps.push({ at: now, P: A, ix }); if (snaps.length > 5) snaps.shift();
      W.pj = [];
      const J = Array.isArray(hs.J) ? hs.J : [];
      for (let i = 0; i + 3 < J.length; i += 4) {
        if (J[i + 3] >= 1000) { const kk = Math.floor(J[i + 3] / 1000), a = (J[i + 3] % 1000) / 100 - Math.PI, sp = [0, 70, 45, 22][kk] || 70; W.pj.push({ k: kk === 2 ? 'r' : kk === 3 ? 'f' : 'b', x: +J[i], y: +J[i + 1], a, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp }); }
        else W.pj.push({ k: 't', x: +J[i], y: +J[i + 1], z: +J[i + 2], ty: J[i + 3] | 0 });
      }
      const V = Array.isArray(hs.V) ? hs.V : [];
      for (let o = 0; o + 5 < V.length; o += 6) { const v = W.vh[V[o] | 0]; if (!v || !fin(+V[o + 1])) continue; v.nx = +V[o + 1]; v.ny = +V[o + 2]; v.na = +V[o + 3]; v.hp = +V[o + 4]; v.v = +V[o + 5]; if (!fin(v.gx) || hyp(v.nx - v.x, v.ny - v.y) > 15) { v.x = v.nx; v.y = v.ny; v.a = v.na; } v.gx = 1; }
      W.ar = []; const Ar = Array.isArray(hs.A) ? hs.A : [];
      for (let i = 0; i + 3 < Ar.length; i += 4) W.ar.push({ x: +Ar[i], y: +Ar[i + 1], t: +Ar[i + 2], k: Ar[i + 3] | 0 });
      W.ad = []; const AD = Array.isArray(hs.AD) ? hs.AD : [];
      for (let i = 0; i + 3 < AD.length; i += 4) W.ad.push({ x: +AD[i], y: +AD[i + 1], t: +AD[i + 2], op: AD[i + 3] | 0 });
      if (typeof hs.Tk === 'string') for (let j = 0; j < W.tk.length; j++) { const v = parseInt(hs.Tk[j >> 2] || '0', 16); W.tk[j] = (v >> (j & 3)) & 1; }
      if (Array.isArray(hs.D)) { W.dr = []; const D = hs.D; for (let i = 0; i + 2 < D.length; i += 3) { const c = D[i + 2] | 0, t = Math.floor(c / 1000); if (t >= 0 && t < NITEM) W.dr.push({ x: +D[i], y: +D[i + 1], t, n: c % 1000, by: -1, nt: 0 }); } }
      if (Array.isArray(hs.B)) W.bx = hs.B.filter(Array.isArray).map((b) => ({ x: +b[0], y: +b[1], ad: b[2] | 0, it: b.slice(3).map((c) => [Math.floor(c / 1000), c % 1000]).filter((e) => e[0] >= 0 && e[0] < NITEM) }));
      if (Array.isArray(hs.Q) && m >= 0) for (const e of hs.Q) if (Array.isArray(e) && (e[0] | 0) === m && fin(+e[1])) myQ = { e, t: now };
      if (myQ && (now - myQ.t < 1500)) mergeQ(myQ.e); else myQ = null;
    }
    function guestStep(dt, rdt, now) {
      const m = auto() ? -1 : me();
      const rt = now - 100;
      let A = null, Bs = snaps.length ? snaps[snaps.length - 1] : null, k = 1;
      for (let i = snaps.length - 1; i > 0; i--) if (snaps[i - 1].at <= rt) { A = snaps[i - 1]; Bs = snaps[i]; break; }
      if (A) k = clamp((rt - A.at) / Math.max(1, Bs.at - A.at), 0, 1.3);
      W.pl.forEach((p, i) => {
        if (!Bs) return;
        if (i === m && W.ph === 2 && (W.T >= GO_T || W.rg) && !p.out && p.veh < 0 && !p.far && !(p.vt > 0)) {
          readIn();
          const n = Math.max(1, Math.ceil(dt / SUB)), h = dt / n;
          const I = { ax: locIn.ax, ay: locIn.ay, spd: 1, sp: locIn.sp, face: locIn.face };
          const keep = [p.use, p.ut, p.rv];
          for (let j = 0; j < n; j++) movePlayer(W, p, I, h);
          [p.use, p.ut, p.rv] = keep;
          if (fin(p.nx)) {
            const d = hyp(p.nx - p.x, p.ny - p.y);
            if (d > 3) { p.x = p.nx; p.y = p.ny; } else { const kk = 1 - Math.exp(-rdt * 4); p.x += (p.nx - p.x) * kk; p.y += (p.ny - p.y) * kk; }
          }
          if (locIn.fire && fin(locIn.aim)) p.a = locIn.aim;
          return;
        }
        const ob = Bs.ix[i]; if (ob == null) return;
        const oa = A ? A.ix[i] : null;
        const b = Bs.P, a = A ? A.P : null;
        const bx = +b[ob], by = +b[ob + 1], ba = +b[ob + 2] || 0;
        const px = p.x, py = p.y;
        if (a && oa != null && hyp(bx - a[oa], by - a[oa + 1]) < 12) { p.x = a[oa] + (bx - a[oa]) * k; p.y = a[oa + 1] + (by - a[oa + 1]) * k; p.a = a[oa + 2] + wrapA(ba - a[oa + 2]) * k; }
        else { p.x = bx; p.y = by; p.a = ba; }
        if (dt > 0) { p.vx = (p.x - px) / dt; p.vy = (p.y - py) / dt; }
      });
      const kv = 1 - Math.exp(-rdt * 10);
      for (const v of W.vh) if (fin(v.nx)) { v.x += (v.nx - v.x) * kv; v.y += (v.ny - v.y) * kv; v.a += wrapA(v.na - v.a) * kv; v.vx = Math.cos(v.a) * v.v; v.vy = Math.sin(v.a) * v.v; }
      for (const b of W.pj) if (b.k === 'b') { b.x += b.vx * dt; b.y += b.vy * dt; }
      for (const a of W.an) if (fin(a.nx)) { const k = 1 - Math.exp(-rdt * 8); a.x += (a.nx - a.x) * k; a.y += (a.ny - a.y) * k; }
      envStep(W);
      for (const s of W.ar) s.t -= dt;
      for (const d of W.ad) if (d.t > 0) d.t -= dt;
    }
    function publish(rdt) {
      if (!api.online || !W) return;
      pubT -= rdt; inT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return;
          pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          if (W.lv !== heavyV) { heavyV = W.lv; heavyN = 3; }
          const heavy = heavyN > 0 || hsQ % 8 === 0; if (heavyN > 0) heavyN--;
          const rs = remoteSeats();
          const pq = [], pq2 = [];
          for (const s of rs) { const R = remIn[s]; if (!R) continue; if (R.dirty > 0) { R.dirty--; pq.push(s); } else if (R.iv) pq2.push(s); }
          if (pq2.length) pq.push(pq2[hsQ % pq2.length]);
          api.net.hostSend(encodeW(W, key, hsQ, heavy, rs, W.ph >= 1 ? remoteCams(rs) : null, pq));
        } else {
          const m = me(); if (m < 0 && !snaps.length) return;
          readIn();
          const am = fin(locIn.aim) ? r2(locIn.aim) : null;
          const fc = fin(locIn.face) ? Math.round(locIn.face * 20) / 20 : null;
          const sig = [r2(locIn.ax), r2(locIn.ay), locIn.fire, am, netN, locIn.ads, locIn.sp, fc, locIn.land ? locIn.land.join(',') : '', Math.round(cam.x / 6), Math.round(cam.y / 6), ovKind === 'inv' ? 1 : 0].join('|');
          if (sig === lastSig && inT > 0) return;
          if (pubT > 0 && sig !== lastSig && inT > 0.1) return;
          lastSig = sig; inT = 0.25; pubT = 1 / 30;
          inQ = (inQ + 1) % 100000;
          const o = { k: key, q: inQ, ax: r2(locIn.ax), ay: r2(locIn.ay), f: locIn.fire, am, ad: fin(locIn.ad) ? r1(locIn.ad) : null, ds: locIn.ads, sp: locIn.sp, fc, A: netA.slice(), cx: r1(cam.x), cy: r1(cam.y), iv: ovKind === 'inv' ? 1 : 0 };
          if (locIn.land) o.ld = [r1(locIn.land[0]), r1(locIn.land[1])];
          api.net.publish(o);
        }
      } catch (e) {}
    }
    let sentRes = false;
    function hostFlow() {
      if (!host() || !W || !W.res || sentRes) return;
      sentRes = true;
      api.setState(Object.assign({}, st, { ph: 'done', res: W.res.map((r) => r.slice()), sts: statsOf(W, st.hu) }));
    }

    /* ----- camera / spectate ----- */
    function viewer() {
      if (!W) return null;
      const p = myP();
      if (p && !p.out && ctrlOn()) return p;
      if (specT >= 0 && W.pl[specT] && !W.pl[specT].out) return W.pl[specT];
      let best = null;
      for (const q of W.pl) if (!q.out && (!best || (q.far ? -1 : q.kills) > (best.far ? -1 : best.kills))) best = q;
      if (best) specT = best.i;
      return best || p;
    }
    function zoomOf(v) {
      if (!v) return 1;
      if (v.veh >= 0) return 1.45;
      if (!v.ads) return 1;
      const w = heldGun(v);
      const sc = w && (host() || v === myP()) ? scW(w) : 0;
      return sc >= 3 ? SCZ[sc] : 1;
    }
    function camStep(rdt) {
      if (!lay || !W) return;
      stepVA(W.ph >= 1 ? viewer() : null, rdt);
      const ib = islandBox();
      let tx = ib.x, ty = ib.y, ts = lay.sd;
      if (W.ph >= 1) {
        const v = viewer();
        const z = zoomOf(v);
        if (v) {
          tx = v.x; ty = v.y;
          if (v.ads && z > 1.01) { const lead = Math.min(lay.w, lay.h) / (lay.s0 / z) * 0.3 * (pcMode() ? sens.mouse : 1); tx += Math.cos(VA(v)) * lead; ty += Math.sin(VA(v)) * lead; }
          else if (v.veh >= 0) {
            // driving: the camera looks ahead where the car is going, eased (was: raw speed × 0.5 — it jerked with every bump and snapshot)
            const c = W.vh[v.veh], lim = Math.min(lay.w, lay.h) / (lay.s0 / z) * 0.32, lx = clamp((c ? c.vx : v.vx) * 0.55, -lim, lim), ly = clamp((c ? c.vy : v.vy) * 0.55, -lim, lim);
            const kk = Math.min(1, rdt * 2.2); vLook.x += (lx - vLook.x) * kk; vLook.y += (ly - vLook.y) * kk; tx += vLook.x; ty += vLook.y;
          }
          else if (ctrlOn() && v === myP()) {
            if (lay.h > lay.w * 1.2) ty += lay.h * 0.1 / (lay.s0 / z);   // portrait phone: me a bit above centre, controls below
            else if (!(mouse && pcMode())) { const lead = lay.h / (lay.s0 / z) * 0.16; tx += Math.cos(VA(v)) * lead; ty += Math.sin(VA(v)) * lead; }   // landscape: see more of what I face
          }
          if (v.veh < 0) { const kk = Math.min(1, rdt * 3); vLook.x -= vLook.x * kk; vLook.y -= vLook.y * kk; tx += vLook.x; ty += vLook.y; }   // leaving the car: ease back
        }
        ts = lay.s0 / z;
        if (v && v.veh >= 0 && W.vh[v.veh]) {
          const sp = Math.abs(W.vh[v.veh].v || 0); vZoom += (1 / (1 + Math.min(sp, 30) * 0.012) - vZoom) * Math.min(1, rdt * 2.5); ts *= vZoom;
          if (v === myP() && vLastSp - sp > 5) { shake = Math.max(shake, clamp((vLastSp - sp) / 18, 0.2, 0.8)); api.buzz(25); }
          vLastSp = sp;
        } else { vZoom += (1 - vZoom) * Math.min(1, rdt * 2.5); ts *= vZoom; vLastSp = 0; }
        if (W.ph === 1) ts = lay.sd + (lay.s0 - lay.sd) * clamp(1 - W.t / FALL_T, 0, 1);
      }
      const vv = viewer(), mine = vv && vv === myP() && ctrlOn() && W.ph === 2 && !vv.ads && hyp(tx - cam.x, ty - cam.y) < 12;
      const k = mine ? 1 : Math.min(1, rdt * 6);    // my own player: camera locked on (no lag); spectating / big jumps / scope pan: smooth
      cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k; cam.s += (ts - cam.s) * Math.min(1, rdt * 5);
      if (W.ph === 0) { cam.x = tx; cam.y = ty; cam.s = ts; }
    }

    /* ----- main loop ----- */
    /* ----- 팀 편성 screen (st.ph 'team'): everyone taps a team, the host can shuffle / group the people / start ----- */
    let tmEl = null, tmT = 0, tmSig = '', tmMine = null, tmQ = 0, tmCd = null;
    const tmSeen = {};
    const TEAM_T = 45;
    function teamPk() { const a = (st.pk || []).slice(), m = me(); if (m >= 0 && tmMine != null && !host()) a[m] = tmMine; return a; }
    function teamSet(pk) { if (host()) api.setState(Object.assign({}, st, { pk })); }
    function teamPick(t) {
      const m = me(); if (m < 0) return;
      const pk = teamPk(); if (pk[m] === t) t = -1;
      if (!pickOk(st, pk, m, t)) { api.toast('그 팀은 사람 자리가 꽉 찼어요'); return; }
      sfx('pop', 60);
      if (host()) { pk[m] = t; teamSet(pk); return; }
      tmMine = t; tmSig = '';
      try { api.net.publish({ k: 'tm' + st.rid, tp: t, q: ++tmQ }); } catch (e) {}
    }
    function teamShuffle(group) {
      const cap = teamCaps(st), used = cap.map(() => 0), pk = (st.pk || []).slice(), hu = (st.hu || []).slice();
      if (group) hu.forEach((h) => { let t = 0; while (t < cap.length - 1 && used[t] >= cap[t]) t++; pk[h] = t; used[t]++; });
      else { for (let i = hu.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [hu[i], hu[j]] = [hu[j], hu[i]]; } hu.forEach((h) => { const free = cap.map((c, t) => t).filter((t) => used[t] < cap[t]); const t = free[Math.floor(Math.random() * free.length)]; pk[h] = t; used[t]++; }); }
      sfx('card', 60); teamSet(pk);
    }
    function teamStart() { if (!host() || st.ph !== 'team') return; const ta = teamsFrom(st, st.pk || []); api.setState(Object.assign({}, st, { ph: 'go', ta, pk: null })); }
    function closeTeam() { if (tmEl) { tmEl.remove(); tmEl = null; } tmSig = ''; tmCd = null; }
    function teamStep(rdt) {
      tmT += rdt * SPD();
      if (host() && api.online) {   // guests' choices arrive through their presence
        let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
        if (rem && typeof rem === 'object') {
          let pk = null;
          for (const k in rem) {
            const s = +k, o = rem[k]; if (!o || o.k !== 'tm' + st.rid || tmSeen[s] === o.q) continue;
            tmSeen[s] = o.q; const t = o.tp | 0, cur = pk || (st.pk || []).slice();
            if (pickOk(st, cur, s, t)) { cur[s] = t; pk = cur; }
          }
          if (pk) teamSet(pk);
        }
      }
      if (!host() && tmMine != null && st.pk && st.pk[me()] === tmMine) tmMine = null;   // the host has it now
      if (host() && (tmT >= TEAM_T || (auto() && tmT > 3))) { teamStart(); return; }
      teamDraw();
    }
    function teamDraw() {
      const pk = teamPk(), m = me(), cap = teamCaps(st), left = Math.max(0, Math.ceil(TEAM_T - tmT));
      if (!tmEl) {
        tmEl = L.h('div', { class: 'ry-team' }); root.appendChild(tmEl);
      }
      const sig = JSON.stringify(pk) + '|' + m + '|' + host();
      if (sig !== tmSig) {
        tmSig = sig; tmEl.innerHTML = '';
        const head = L.h('div', { class: 'ry-tmh' }, L.h('b', { text: '팀 편성 · ' + (MODE_NM[st.ts] || '') }), L.h('span', { class: 'grow', text: '내 팀을 눌러 골라요 (다시 누르면 취소) · 빈자리는 AI' }));
        tmCd = L.h('span', { class: 'cd' }); head.appendChild(tmCd); tmEl.appendChild(head);
        const grid = L.h('div', { class: 'ry-tmg' });
        cap.forEach((c, t) => {
          const hs = (st.hu || []).filter((h) => pk[h] === t), mine = m >= 0 && pk[m] === t, full = hs.length >= c && !mine;
          const card = L.h('button', { type: 'button', class: 'ry-tmc' + (mine ? ' me' : '') + (full ? ' full' : ''), onclick: () => teamPick(t) });
          card.appendChild(L.h('div', { class: 'tt' }, L.h('b', { text: (t + 1) + '팀' }), L.h('small', { text: '사람 ' + hs.length + ' / ' + c })));
          const row = L.h('div', { class: 'ns' });
          hs.forEach((h) => row.appendChild(L.h('span', { class: 'nm', style: 'border-color:' + COL(h), text: name(h) + (h === m ? ' (나)' : '') })));
          if (c - hs.length > 0) row.appendChild(L.h('span', { class: 'ai', text: 'AI ' + (c - hs.length) }));
          card.appendChild(row); grid.appendChild(card);
        });
        tmEl.appendChild(grid);
        const un = (st.hu || []).filter((h) => !(pk[h] >= 0));
        const foot = L.h('div', { class: 'ry-tmf' });
        foot.appendChild(L.h('span', { class: 'grow', text: un.length ? '아직 안 고름: ' + un.map(name).join(', ') + ' — 시작하면 자리가 남는 팀에 무작위로' : '모두 골랐어요' }));
        if (host()) {
          foot.appendChild(L.h('button', { type: 'button', class: 'ry-b', text: '🎲 무작위 편성', onclick: () => teamShuffle(false) }));
          foot.appendChild(L.h('button', { type: 'button', class: 'ry-b', text: '👥 사람끼리 모으기', onclick: () => teamShuffle(true) }));
          foot.appendChild(L.h('button', { type: 'button', class: 'ry-b pri', text: '▶ 시작', onclick: teamStart }));
        } else foot.appendChild(L.h('span', { class: 'wait', text: '방장이 시작해요' }));
        tmEl.appendChild(foot);
      }
      if (tmCd) { const t = left + '초 뒤 자동 시작'; if (tmCd.textContent !== t) tmCd.textContent = t; }
    }
    // PC: hide the system cursor only while I'm actually aiming (alive, playing, no menu/bag/map open); otherwise show it
    let aimCur = false;
    function setAimCursor(on) {
      if (on === aimCur) return; aimCur = on; root.classList.toggle('ry-aim', on);
      if (!on) { try { if (document.pointerLockElement && root.contains(document.pointerLockElement)) document.exitPointerLock(); } catch (e) {} }
    }
    function frame(rdt, now) {
      if (!st) return;
      { const p = W && st.ph !== 'team' && st.ph !== 'done' ? myP() : null; setAimCursor(!!(p && !p.out && W.ph === 2 && ctrlOn() && !ovOpen() && pcMode() && !document.hidden)); }
      if (st.ph === 'team') { teamStep(rdt); return; }
      if (tmEl) closeTeam();
      if (st.rid !== key) startMatch();
      if (!W) return;
      useMap(W.M);
      const dt = rdt * SPD();
      curDt = dt;
      if (pulse > 0) pulse -= rdt;
      kbStep(rdt);
      readIn();
      if (host()) {
        pollHost();
        tickWorld(W, Math.min(dt, 0.2), inputsFor(), hooks);
        if (W.ph !== 0) locIn.land = null;
        hostFlow();
      } else {
        pollGuest(now);
        guestStep(Math.min(dt, 0.1), rdt, now);
      }
      if (W.ph !== lastPh) { lastPh = W.ph; }
      recTick(dt); sumInject();
      const p = myP();
      if (p && p.out) outT += rdt;
      if (tipT > 0) tipT -= rdt;
      if (hurtT > 0) hurtT -= rdt;
      for (let i = 0; i < vis.length; i++) {
        const V = vis[i], q = W.pl[i];
        if (V.hit > 0) V.hit -= rdt * 4; if (V.mf > 0) V.mf -= rdt; if (V.kick > 0) V.kick = Math.max(0, V.kick - rdt * 9);
        // footprints (snow), crawl blood trail, wakes
        if (q && !q.out && !q.far && W.ph === 2 && q.veh < 0 && !q.air && near(q.x, q.y, 45)) {
          if (!fin(V.lx)) { V.lx = q.x; V.ly = q.y; }
          const d = hyp(q.x - V.lx, q.y - V.ly);
          if (d > (q.kd ? 0.5 : 0.75)) {
            const a = Math.atan2(q.y - V.ly, q.x - V.lx); V.sw = 1 - V.sw;
            if (q.kd && gore()) decal(q.x, q.y, 0.3 + Math.random() * 0.2, 0, 0.6);
            else if (W.M.T.k === 's' && !q.swim && !isWater(W.M, q.x, q.y)) { steps.push({ x: q.x - Math.sin(a) * 0.17 * (V.sw ? 1 : -1), y: q.y + Math.cos(a) * 0.17 * (V.sw ? 1 : -1), a, t: 0 }); if (steps.length > 360) steps.shift(); }
            V.lx = q.x; V.ly = q.y;
          }
        } else if (q && q.veh >= 0) { V.lx = q.x; V.ly = q.y; const v = W.vh[q.veh]; if (v && VEH[v.ty].land !== 1 && isWater(W.M, v.x, v.y) && Math.abs(v.v) > 3 && Math.random() < rdt * 20) puff(v.x - Math.cos(v.a) * 1.5, v.y - Math.sin(v.a) * 1.5, 2, 1.5, ['#e8f6ff', '#ffffff'], 0.8); }
      }
      camStep(rdt);
      kick.x *= Math.exp(-rdt * 14); kick.y *= Math.exp(-rdt * 14); rcl.x *= Math.exp(-rdt * 9); rcl.y *= Math.exp(-rdt * 9);
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t += rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vx *= 0.9; q.vy *= 0.9; if (q.t > q.life) parts.splice(i, 1); }
      for (let i = rings.length - 1; i >= 0; i--) { rings[i].t += rdt; if (rings[i].t > rings[i].life) rings.splice(i, 1); }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].life) floats.splice(i, 1); }
      for (let i = tracers.length - 1; i >= 0; i--) { tracers[i].t += rdt; if (tracers[i].t > tracers[i].life) tracers.splice(i, 1); }
      for (let i = marks.length - 1; i >= 0; i--) { marks[i].t += rdt; if (marks[i].t > (marks[i].k === 3 ? 0.7 : 0.35)) marks.splice(i, 1); }
      for (let i = dmgDir.length - 1; i >= 0; i--) { dmgDir[i].t += rdt; if (dmgDir[i].t > 1.2) dmgDir.splice(i, 1); }
      for (let i = feed.length - 1; i >= 0; i--) { feed[i].t += rdt; if (feed[i].t > 6) feed.splice(i, 1); }
      for (let i = steps.length - 1; i >= 0; i--) { steps[i].t += rdt; if (steps[i].t > 30) steps.splice(i, 1); }
      for (const d of decals) d.t += rdt;
      for (let i = conf.length - 1; i >= 0; i--) { const c = conf[i]; c.t += rdt; c.x += c.vx * rdt; c.y += c.vy * rdt; c.vy += 420 * rdt; c.rot += c.vr * rdt; if (c.t > c.life) conf.splice(i, 1); }
      if (plane) { plane.t += rdt; if (plane.t > 4) plane = null; }
      // red smoke at unopened airdrops, smoke for burning vehicles
      for (const d of W.ad) if (!d.op && d.t <= 0 && Math.random() < rdt * 10 && near(d.x, d.y, 40)) puff(d.x + 0.6, d.y - 0.4, 1, 0.8, ['rgba(230,60,50,.6)'], 2.2, -1.2, 0.6);
      for (const v of W.vh) {
        if (!near(v.x, v.y, 40)) continue;
        const k = v.hp / VEH[v.ty].hp, R = VEH[v.ty].r;
        if (v.hp > 0 && k < 0.5 && Math.random() < rdt * (k < 0.15 ? 16 : 8)) puff(v.x, v.y, 1, 1, k < 0.25 ? ['#333', '#555'] : ['#666', '#888'], 1.2);
        if (v.hp > 0 && k < 0.15 && Math.random() < rdt * 20) puff(v.x + (Math.random() - 0.5) * R, v.y + (Math.random() - 0.5) * R, 1, 0.8, ['#ff7a2a', '#ffcf4a', '#ff4a1a'], 0.45);
        if (v.hp <= 0 && Math.random() < rdt * 1.5) puff(v.x, v.y, 1, 0.6, ['#4a4a4a'], 1.8);
        if (v.hp > 0 && Math.abs(v.v) > 8 && Math.abs(v.sl || 0) > 3 && Math.random() < rdt * 10) puff(v.x - Math.cos(v.a) * R, v.y - Math.sin(v.a) * R, 1, 0.5, ['#bbb'], 0.5);
      }
      if (flashT > 0) flashT -= rdt;
      if (banner) { banner.life -= rdt; if (banner.life <= 0) banner = null; }
      shake = Math.max(0, shake - rdt * 2.6);
      for (let i = snd.length - 1; i >= 0; i--) { snd[i].t -= rdt; if (snd[i].t <= 0) snd.splice(i, 1); }
      for (let i = pingFx.length - 1; i >= 0; i--) { pingFx[i].t += rdt; if (pingFx[i].t > 1) pingFx.splice(i, 1); }
      publish(rdt);
    }
    /* ----- drawing helpers ----- */
    function txt(t, x, y, col, font, al, stroke) {
      ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle';
      if (stroke) { ctx.lineWidth = stroke; ctx.strokeStyle = 'rgba(12,10,18,.88)'; ctx.lineJoin = 'round'; ctx.strokeText(t, x, y); }
      ctx.fillStyle = col; ctx.fillText(t, x, y);
    }
    function pill(x, y, w, h, fill) { ctx.fillStyle = fill; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, Math.min(h / 2, 12)); else ctx.rect(x, y, w, h); ctx.fill(); }
    function onScreen(x, y, r) { const sx = SX(x), sy = SY(y), rr = r * cam.s; return sx > -rr && sx < lay.w + rr && sy > -rr && sy < lay.h + rr; }
    const GLEN = [0.42, 0.62, 0.86, 0.86, 1.0, 1.15, 0.96, 0.72, 0.4, 1.0];
    const VS = 1.22;
    const VESTC = ['', '#8a8f62', '#4f6340', '#2c3036'], HELMC = ['', '#8f8a62', '#5b6a48', '#2f353b'];
    // local frame: x forward, y right; s = px per metre
    function gunShape(t, s, kick) {
      const G = GUN[t], L2 = GLEN[G.c] * s * (G.nostock || G.bp ? 0.85 : 1), k = -kick * s * 0.12;
      ctx.fillStyle = G.c === 8 ? '#e8742a' : G.wood ? '#7a5130' : G.c === 6 || G.c === 9 || G.po === 'A' ? '#3d4a3a' : '#25262b';
      if (G.c === 9 && G.mg === 1) { ctx.fillRect(k - 0.3 * s, -0.08 * s, L2 * 1.2, 0.16 * s); return L2 + k; }
      if (G.c === 7) {
        ctx.fillRect(k, -0.05 * s, L2, 0.1 * s);
        ctx.strokeStyle = '#3a2a1a'; ctx.lineWidth = Math.max(1, s * 0.06); ctx.beginPath(); ctx.moveTo(k + L2 * 0.8, -0.32 * s); ctx.quadraticCurveTo(k + L2 * 1.0, 0, k + L2 * 0.8, 0.32 * s); ctx.stroke();
        return L2 + k;
      }
      ctx.fillRect(k, -0.055 * s, L2, 0.11 * s);
      ctx.fillStyle = '#16171a';
      ctx.fillRect(k + L2 * 0.55, -0.035 * s, L2 * 0.45 + (G.c === 5 ? 0.15 * s : 0), 0.07 * s);
      if (G.c >= 1 && G.c !== 3 && G.c !== 7) ctx.fillRect(k + L2 * 0.35, 0.03 * s, 0.08 * s, (G.c === 6 ? 0.22 : 0.16) * s);
      if (G.c === 5 || G.c === 4) { ctx.fillStyle = '#111'; ctx.fillRect(k + L2 * 0.3, -0.09 * s, L2 * 0.3, 0.07 * s); }
      return L2 + k + (G.c === 5 ? 0.15 * s : 0);
    }
    function drawMan(p, x, y, s, now, alpha) {
      const col = COL(p.i), V = vis[p.i] || {}, code = HC(p);
      ctx.globalAlpha = alpha == null ? 1 : alpha;
      ctx.save(); ctx.translate(x, y); ctx.rotate(p.a);
      if (p.kd) {
        const cr = Math.sin(now / 160 + p.i) * (hyp(p.vx, p.vy) > 0.3 ? 1 : 0.15);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(0.05 * s, 0.1 * s, 0.85 * s, 0.4 * s, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#2a2a30'; ctx.fillRect(-0.85 * s, -0.24 * s + cr * 0.06 * s, 0.5 * s, 0.14 * s); ctx.fillRect(-0.85 * s, 0.1 * s - cr * 0.06 * s, 0.5 * s, 0.14 * s);
        ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(-0.05 * s, 0, 0.45 * s, 0.3 * s, 0, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(120,10,12,.55)'; ctx.beginPath(); ctx.ellipse(-0.1 * s, 0.05 * s, 0.25 * s, 0.18 * s, 0.4, 0, 7); ctx.fill();
        ctx.fillStyle = '#d9a982'; for (const sd of [-1, 1]) { ctx.beginPath(); ctx.arc((0.45 + cr * sd * 0.08) * s, sd * 0.3 * s, 0.09 * s, 0, 7); ctx.fill(); }
        ctx.fillStyle = p.hm ? HELMC[p.hm] : '#e0b48a'; ctx.beginPath(); ctx.arc(0.5 * s, 0, 0.24 * s, 0, 7); ctx.fill();
        ctx.restore(); ctx.globalAlpha = 1; return;
      }
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(0.06 * s, 0.12 * s, 0.55 * s, 0.5 * s, 0, 0, 7); ctx.fill();
      if (p.bp) { ctx.fillStyle = ['', '#6b5a3a', '#4f5a3a', '#3a3f45'][p.bp]; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-0.52 * s, -0.3 * s, 0.3 * s, 0.6 * s, 0.08 * s); else ctx.rect(-0.52 * s, -0.3 * s, 0.3 * s, 0.6 * s); ctx.fill(); }
      // arms + held item
      const kk = V.kick || 0, isGun = code >= 0 && code < I_MEL;
      ctx.fillStyle = col;
      if (isGun) {
        ctx.save(); ctx.translate(0.12 * s, 0.14 * s);
        const tip = gunShape(code, s, kk);
        ctx.restore();
        ctx.fillStyle = '#d9a982'; ctx.beginPath(); ctx.arc((0.2 - kk * 0.1) * s, 0.14 * s, 0.09 * s, 0, 7); ctx.arc((0.5 - kk * 0.1) * s, 0.12 * s, 0.085 * s, 0, 7); ctx.fill();
        if (V.mf > 0) {
          const mx = 0.12 * s + tip, my = 0.14 * s, r = s * (0.28 + Math.random() * 0.12);
          ctx.fillStyle = 'rgba(255,220,120,.95)'; ctx.beginPath();
          for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283, rr = k % 2 ? r * 0.4 : r; ctx.lineTo(mx + Math.cos(a) * rr * (k % 4 === 0 ? 1.4 : 1), my + Math.sin(a) * rr * 0.7); }
          ctx.fill(); ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(mx, my, r * 0.3, 0, 7); ctx.fill();
        }
      } else if (code >= I_MEL && code < I_THR) {
        const sw = p.ft > 0 ? Math.sin((p.ft / 0.22) * Math.PI) * 1.2 : 0;
        ctx.save(); ctx.translate(0.25 * s, 0.25 * s); ctx.rotate(-sw);
        const j = code - I_MEL, im = iconImg(code), sz = MELEE[j].r * 0.62 * s;
        // the melee icon (drawn pointing up-right) turned so it points forward
        if (im) { ctx.rotate(Math.PI / 4); ctx.drawImage(im, -sz * 0.15, -sz * 0.85, sz, sz); }
        else { ctx.fillStyle = '#4a3a2a'; ctx.fillRect(0, -0.03 * s, 0.9 * s, 0.06 * s); }
        ctx.restore();
        ctx.fillStyle = '#d9a982'; ctx.beginPath(); ctx.arc(0.28 * s, 0.25 * s, 0.09 * s, 0, 7); ctx.fill();
      } else if (code >= I_THR && code < I_HEAL) {
        ctx.fillStyle = THROW[code - I_THR].c; ctx.beginPath(); ctx.arc(0.42 * s, 0.24 * s, 0.11 * s, 0, 7); ctx.fill();
        ctx.fillStyle = '#d9a982'; ctx.beginPath(); ctx.arc(0.32 * s, 0.24 * s, 0.09 * s, 0, 7); ctx.fill();
      } else {
        const pn = p.ft > 0 ? Math.sin((p.ft / 0.22) * Math.PI) * 0.3 : 0;
        ctx.fillStyle = '#d9a982'; ctx.beginPath(); ctx.arc((0.36 + pn) * s, 0.22 * s, 0.1 * s, 0, 7); ctx.arc(0.34 * s, -0.22 * s, 0.1 * s, 0, 7); ctx.fill();
      }
      // torso
      ctx.fillStyle = V.hit > 0.5 ? '#ffffff' : col;
      ctx.beginPath(); ctx.ellipse(0, 0, 0.27 * s, 0.46 * s, 0, 0, 7); ctx.fill();
      if (p.vs) { ctx.fillStyle = VESTC[p.vs]; ctx.beginPath(); ctx.ellipse(-0.01 * s, 0, 0.22 * s, 0.33 * s, 0, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(-0.12 * s, -0.2 * s, 0.08 * s, 0.4 * s); }
      // head
      ctx.fillStyle = '#e0b48a'; ctx.beginPath(); ctx.arc(0.04 * s, 0, 0.21 * s, 0, 7); ctx.fill();
      if (p.hm) { ctx.fillStyle = HELMC[p.hm]; ctx.beginPath(); ctx.arc(0.0, 0, 0.23 * s, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.35)'; ctx.lineWidth = 1; ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.beginPath(); ctx.arc(-0.06 * s, -0.06 * s, 0.08 * s, 0, 7); ctx.fill(); }
      else { ctx.fillStyle = '#3a2a20'; ctx.beginPath(); ctx.arc(-0.04 * s, 0, 0.19 * s, 1.9, 4.4); ctx.fill(); }
      ctx.restore();
      ctx.globalAlpha = 1;
    }
    function drawPlayer(p, now, v) {
      const s = cam.s, x = SX(p.x), y = SY(p.y), m = me();
      if (p.air > 0 || W.ph === 1) {   // parachute
        const k = clamp((W.ph === 1 ? W.t : p.air) / FALL_T, 0, 1), lift = k * s * 5;
        ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.ellipse(x, y, s * 0.5, s * 0.3, 0, 0, 7); ctx.fill();
        drawMan(p, x, y - lift, s * (1 + k * 0.4), now);
        const cw = s * (1.6 + k), cy = y - lift - s * (1.4 + k);
        ctx.strokeStyle = 'rgba(255,255,255,.7)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x - cw * 0.8, cy); ctx.lineTo(x, y - lift); ctx.lineTo(x + cw * 0.8, cy); ctx.stroke();
        ctx.fillStyle = COL(p.i); ctx.beginPath(); ctx.ellipse(x, cy, cw, cw * 0.45, 0, Math.PI, 0); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.3)'; ctx.beginPath(); ctx.ellipse(x, cy, cw * 0.5, cw * 0.4, 0, Math.PI, 0); ctx.fill();
        return;
      }
      if (p.swim) {
        ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.ellipse(x, y, s * 0.6, s * 0.42, 0, 0, 7); ctx.stroke();
        ctx.fillStyle = COL(p.i); ctx.beginPath(); ctx.arc(x, y, s * 0.3, 0, 7); ctx.fill();
        ctx.fillStyle = p.hm ? HELMC[p.hm] : '#e0b48a'; ctx.beginPath(); ctx.arc(x, y, s * 0.2, 0, 7); ctx.fill();
      } else drawMan(p, x, y, s * VS * (p.cr ? 0.84 : 1), now);
      if (p.sx && !p.swim && Math.random() < 0.3) puff(p.x - Math.cos(p.a) * 0.3, p.y - Math.sin(p.a) * 0.3, 1, 0.8, ['rgba(210,200,180,.5)'], 0.4);
      if (p.i === m || (v && W.tm && p.tm === v.tm && p !== v)) {
        ctx.strokeStyle = p.i === m ? 'rgba(255,243,207,.9)' : '#6fe0c0'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, s * 0.62 * VS, 0, 7); ctx.stroke();
      }
      if (p.burn > 0) puff(p.x, p.y, 1, 1.2, ['#ff8a2a', '#ffcf4a'], 0.35);
    }
    function drawRiders(v, now, vw) {
      const s = cam.s, ca = Math.cos(v.a), sa = Math.sin(v.a);
      const V = VEH[v.ty], line = V.sh === 'bike' || V.sh === 'sled' || V.sh === 'jetski';
      const seats = line ? [[-0.15 * V.r, 0], [-0.62 * V.r, 0], [-0.9, 0]] : V.sh === 'side' ? [[-0.12 * V.r, -0.3 * V.r], [-0.62 * V.r, -0.3 * V.r], [-0.22 * V.r, 0.33 * V.r]] : [0, 1, 2, 3, 4, 5].map((k) => [V.r * 0.25 - Math.floor(k / 2) * V.r * 0.55, (k % 2 ? 0.42 : -0.42) * V.r / 1.3]);
      for (const p of W.pl) {
        if (p.out || p.far || p.veh !== W.vh.indexOf(v)) continue;
        if (vw && W.ph === 2 && p.tm !== vw.tm && !los(W.M, vw.x, vw.y, v.x, v.y)) continue;
        seen[p.i] = 1;
        const o = seats[p.seat] || [0, 0], x = v.x + ca * o[0] - sa * o[1], y = v.y + sa * o[0] + ca * o[1];
        const X = SX(x), Y = SY(y);
        ctx.save(); ctx.translate(X, Y); ctx.rotate(v.a); ctx.strokeStyle = 'rgba(10,10,12,.8)'; ctx.lineWidth = Math.max(1, s * 0.04);
        ctx.fillStyle = COL(p.i); ctx.beginPath(); ctx.ellipse(0, 0, s * 0.15, s * 0.25, 0, 0, 7); ctx.fill(); ctx.stroke();   // shoulders across the seat
        ctx.fillStyle = p.hm ? HELMC[p.hm] : '#e0b48a'; ctx.beginPath(); ctx.arc(s * 0.03, 0, s * 0.14, 0, 7); ctx.fill(); ctx.stroke(); ctx.restore();
        if (p.seat > 0) { ctx.save(); ctx.translate(X, Y); ctx.rotate(p.a); const c = HC(p); if (c >= 0 && c < I_MEL) { ctx.translate(0.15 * s, 0.1 * s); gunShape(c, s, (vis[p.i] || {}).kick || 0); } ctx.restore(); }
        if (p.i === me()) { ctx.strokeStyle = 'rgba(255,243,207,.9)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(X, Y, s * 0.32, 0, 7); ctx.stroke(); }
      }
    }
    function drawVeh(v, j) {
      const s = cam.s, X = SX(v.x), Y = SY(v.y), V = VEH[v.ty];
      ctx.save(); ctx.translate(X, Y); ctx.rotate(v.a);
      const rr = (x, y, w, h, r) => { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); };
      if (v.hp <= 0) { // burnt-out wreck: the same silhouette, charred black
        ctx.fillStyle = 'rgba(20,18,16,.4)'; ctx.beginPath(); ctx.ellipse(0, 0, V.r * 1.6 * s, V.r * 1.0 * s, 0, 0, 7); ctx.fill();
        if ('filter' in ctx) { ctx.filter = 'grayscale(1) brightness(0.38) sepia(0.35)'; drawVehBody(V, s, rr, 0); ctx.filter = 'none'; }
        else { ctx.fillStyle = '#2a2624'; rr(-V.r * 1.25 * s, -V.r * 0.6 * s, V.r * 2.5 * s, V.r * 1.2 * s, 0.3 * s); ctx.fill(); }
        ctx.fillStyle = 'rgba(110,60,30,.55)'; ctx.beginPath(); ctx.ellipse(-V.r * 0.2 * s, V.r * 0.1 * s, V.r * 0.4 * s, V.r * 0.22 * s, 0.5, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,120,40,.35)'; ctx.beginPath(); ctx.arc(V.r * 0.25 * s, -V.r * 0.1 * s, V.r * 0.12 * s, 0, 7); ctx.fill();
        ctx.restore(); return; }
      const thin = V.sh === 'bike' || V.sh === 'jetski' || V.sh === 'sled'; ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(0.12 * s, 0.18 * s, V.r * 1.25 * s, V.r * (thin ? 0.42 : 0.78) * s, 0, 0, 7); ctx.fill();
      drawVehBody(V, s, rr, W.T);
      ctx.restore();
      if (v.hp < V.hp * 0.999) { const w = s * 2.2, k = v.hp / V.hp; ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(X - w / 2, Y - V.r * s - 10, w, 4); ctx.fillStyle = k > 0.5 ? '#9ad14f' : k > 0.25 ? '#e8c04e' : '#ee6a55'; ctx.fillRect(X - w / 2, Y - V.r * s - 10, w * k, 4); }
    }
    /* every vehicle from its shape: length ~2.5 × radius, nose pointing +x. Outlines + highlights keep it readable on any ground. */
    function drawVehBody(V, s, rr, T) {
      const c = V.col, Lh = V.r * 1.25 * s, Wh = V.r * 0.66 * s, lw = Math.max(1, s * 0.05);
      const ol = (w) => { ctx.strokeStyle = 'rgba(10,10,12,.75)'; ctx.lineWidth = w || lw; ctx.stroke(); };
      const tire = (x, y, l, w) => { ctx.fillStyle = '#141414'; rr(x - l / 2, y - w / 2, l, w, Math.min(l, w) * 0.35); ctx.fill(); ctx.fillStyle = '#4a4a4a'; ctx.fillRect(x - l * 0.08, y - w / 2, l * 0.16, w); };
      const box = (x, y, w, h, r, col, o) => { ctx.fillStyle = col; rr(x, y, w, h, r); ctx.fill(); if (o) ol(o === 1 ? lw : o); };
      const ell = (x, y, a, b, col, o) => { ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x, y, a, b, 0, 0, 7); ctx.fill(); if (o) ol(); };
      const line = (pts, col, w) => { ctx.strokeStyle = col; ctx.lineWidth = w; ctx.lineCap = 'round'; ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); ctx.stroke(); };
      const hl = (x, y, r) => ell(x, y, r, r, '#fff3c0', 0);
      // a motorbike seen from above, centred on y = cy, half-length L
      const moto = (L, cy, ped, col) => {
        const tw = Math.max(2, s * (ped ? 0.07 : 0.16)), tl = L * (ped ? 0.5 : 0.42);
        tire(L * 0.66, cy, tl, tw); tire(-L * 0.66, cy, tl, tw);
        if (ped) {   // bicycle: thin frame, pedals, saddle
          line([[-L * 0.6, cy], [L * 0.55, cy]], col, Math.max(1.6, s * 0.08));
          line([[-L * 0.05, cy - s * 0.22], [-L * 0.05, cy + s * 0.22]], '#666', Math.max(1.2, s * 0.05));
          box(-L * 0.42, cy - s * 0.07, L * 0.3, s * 0.14, s * 0.06, '#222');
        } else {
          box(-L * 0.62, cy - s * 0.13, L * 1.15, s * 0.26, s * 0.1, '#2a2a2e', 1);      // frame / engine block
          ell(L * 0.18, cy, L * 0.28, s * 0.2, col, 1);                                  // fuel tank
          ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.ellipse(L * 0.22, cy - s * 0.07, L * 0.14, s * 0.05, 0, 0, 7); ctx.fill();
          box(-L * 0.62, cy - s * 0.15, L * 0.62, s * 0.3, s * 0.12, '#1c1c20', 1);       // seat
          box(-L * 0.98, cy - s * 0.1, L * 0.3, s * 0.2, s * 0.06, col, 1);               // rear fender / tail
          ell(-L * 0.98, cy, s * 0.05, s * 0.07, '#e23a2a', 0);
        }
        line([[L * 0.5, cy - s * 0.42], [L * 0.56, cy], [L * 0.5, cy + s * 0.42]], '#cfd2d6', Math.max(1.5, s * 0.07));   // handlebar
        ell(L * 0.5, cy - s * 0.42, s * 0.06, s * 0.06, '#111'); ell(L * 0.5, cy + s * 0.42, s * 0.06, s * 0.06, '#111');
        if (!ped) hl(L * 0.86, cy, s * 0.09);
      };
      switch (V.sh) {
        case 'bike': moto(Lh, 0, V.ped, c); return;
        case 'sled': {   // snowmobile: two front skis, tread at the back
          line([[Lh * 1.05, -Wh * 0.7], [Lh * 0.25, -Wh * 0.7]], '#151515', Math.max(1.6, s * 0.1)); line([[Lh * 1.05, Wh * 0.7], [Lh * 0.25, Wh * 0.7]], '#151515', Math.max(1.6, s * 0.1));
          box(-Lh, -Wh * 0.42, Lh * 0.9, Wh * 0.84, s * 0.08, '#1d1d1d', 1);
          ctx.strokeStyle = '#3a3a3a'; ctx.lineWidth = 1; for (let k = 1; k < 6; k++) { ctx.beginPath(); ctx.moveTo(-Lh + k * Lh * 0.15, -Wh * 0.42); ctx.lineTo(-Lh + k * Lh * 0.15, Wh * 0.42); ctx.stroke(); }
          ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(Lh * 0.95, 0); ctx.quadraticCurveTo(Lh * 0.7, -Wh * 0.75, Lh * 0.05, -Wh * 0.6); ctx.lineTo(-Lh * 0.5, -Wh * 0.35); ctx.lineTo(-Lh * 0.5, Wh * 0.35); ctx.lineTo(Lh * 0.05, Wh * 0.6); ctx.quadraticCurveTo(Lh * 0.7, Wh * 0.75, Lh * 0.95, 0); ctx.fill(); ol();
          box(-Lh * 0.75, -Wh * 0.25, Lh * 0.75, Wh * 0.5, s * 0.1, '#1c1c20', 1);
          ell(Lh * 0.35, 0, Lh * 0.12, Wh * 0.4, 'rgba(160,200,230,.8)', 1);
          line([[Lh * 0.12, -Wh * 0.6], [Lh * 0.18, Wh * 0.6]], '#cfd2d6', Math.max(1.4, s * 0.06)); hl(Lh * 0.85, 0, s * 0.09); return;
        }
        case 'jetski': {
          ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(Lh * 1.1, 0); ctx.quadraticCurveTo(Lh * 0.4, -Wh * 0.95, -Lh, -Wh * 0.65); ctx.lineTo(-Lh, Wh * 0.65); ctx.quadraticCurveTo(Lh * 0.4, Wh * 0.95, Lh * 1.1, 0); ctx.fill(); ol();
          ctx.fillStyle = '#f4f4f4'; ctx.beginPath(); ctx.moveTo(Lh * 1.05, 0); ctx.quadraticCurveTo(Lh * 0.6, -Wh * 0.35, Lh * 0.3, -Wh * 0.4); ctx.lineTo(Lh * 0.3, Wh * 0.4); ctx.quadraticCurveTo(Lh * 0.6, Wh * 0.35, Lh * 1.05, 0); ctx.fill();
          box(-Lh * 0.75, -Wh * 0.28, Lh * 0.95, Wh * 0.56, Wh * 0.25, '#1c1c20', 1);
          line([[Lh * 0.32, -Wh * 0.62], [Lh * 0.38, 0], [Lh * 0.32, Wh * 0.62]], '#cfd2d6', Math.max(1.5, s * 0.07)); return;
        }
        case 'boat': case 'airboat': {
          const air = V.sh === 'airboat';
          ctx.fillStyle = air ? c : '#f2efe6'; ctx.beginPath(); ctx.moveTo(Lh * 1.2, 0); ctx.quadraticCurveTo(Lh * 0.7, -Wh * 1.2, -Lh, -Wh * 1.05); ctx.lineTo(-Lh, Wh * 1.05); ctx.quadraticCurveTo(Lh * 0.7, Wh * 1.2, Lh * 1.2, 0); ctx.fill(); ol(Math.max(1.4, s * 0.07));
          ctx.strokeStyle = air ? 'rgba(255,255,255,.35)' : '#2f6a95'; ctx.lineWidth = Math.max(1, s * 0.06); ctx.beginPath(); ctx.moveTo(Lh * 1.05, 0); ctx.quadraticCurveTo(Lh * 0.6, -Wh * 0.95, -Lh * 0.92, -Wh * 0.85); ctx.moveTo(Lh * 1.05, 0); ctx.quadraticCurveTo(Lh * 0.6, Wh * 0.95, -Lh * 0.92, Wh * 0.85); ctx.stroke();
          box(-Lh * 0.85, -Wh * 0.7, Lh * 1.4, Wh * 1.4, Wh * 0.3, air ? '#33464d' : '#8a6a46', 1);   // deck
          if (air) {
            box(-Lh * 0.45, -Wh * 0.3, Lh * 0.35, Wh * 0.6, s * 0.06, '#1c1c20', 1);       // raised driver seat
            box(-Lh * 1.08, -Wh * 0.95, Lh * 0.28, Wh * 1.9, s * 0.05, 'rgba(30,30,30,.45)', 1);   // fan cage
            const a = T * 30, R = Wh * 0.85; ctx.save(); ctx.translate(-Lh * 0.94, 0); ctx.scale(0.35, 1); line([[Math.cos(a) * R, Math.sin(a) * R], [-Math.cos(a) * R, -Math.sin(a) * R]], '#d8d8d8', Math.max(2, s * 0.12)); ctx.restore();
            ell(-Lh * 0.94, 0, s * 0.12, s * 0.12, '#555', 1);
          } else {
            box(Lh * 0.2, -Wh * 0.72, Lh * 0.12, Wh * 1.44, s * 0.04, 'rgba(150,200,230,.9)', 1);   // windshield
            box(-Lh * 0.1, -Wh * 0.5, Lh * 0.25, Wh * 0.3, s * 0.05, '#ddd', 1);
            box(-Lh * 1.22, -Wh * 0.3, Lh * 0.26, Wh * 0.6, s * 0.06, '#222', 1);                     // outboard motor
          }
          return;
        }
        case 'tank': case 'apc': {
          const apc = V.sh === 'apc';
          if (apc) for (const wx of [-0.7, -0.23, 0.23, 0.7]) for (const sd of [-1, 1]) tire(wx * Lh, sd * Wh * 0.86, Lh * 0.32, Wh * 0.36);
          else { for (const sd of [-1, 1]) { box(-Lh, sd > 0 ? Wh * 0.6 : -Wh * 1.05, Lh * 2, Wh * 0.45, s * 0.1, '#1d1d1d', 1); ctx.strokeStyle = '#444'; ctx.lineWidth = 1; for (let k = 1; k < 12; k++) { const x = -Lh + k * Lh / 6; ctx.beginPath(); ctx.moveTo(x, sd > 0 ? Wh * 0.6 : -Wh * 1.05); ctx.lineTo(x, sd > 0 ? Wh * 1.05 : -Wh * 0.6); ctx.stroke(); } } }
          ctx.fillStyle = c; ctx.beginPath();
          if (apc) { ctx.moveTo(Lh * 1.0, -Wh * 0.45); ctx.lineTo(Lh * 0.65, -Wh * 0.72); ctx.lineTo(-Lh * 0.95, -Wh * 0.72); ctx.lineTo(-Lh * 0.95, Wh * 0.72); ctx.lineTo(Lh * 0.65, Wh * 0.72); ctx.lineTo(Lh * 1.0, Wh * 0.45); ctx.closePath(); }
          else rr(-Lh * 0.9, -Wh * 0.62, Lh * 1.8, Wh * 1.24, Wh * 0.2);
          ctx.fill(); ol(Math.max(1.4, s * 0.07));
          ctx.fillStyle = 'rgba(255,255,255,.13)'; ctx.fillRect(-Lh * 0.85, -Wh * 0.6, Lh * 1.5, Wh * 0.25);
          if (apc) {
            ctx.strokeStyle = 'rgba(0,0,0,.3)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(Lh * 0.65, -Wh * 0.72); ctx.lineTo(Lh * 0.65, Wh * 0.72); ctx.stroke();
            box(-Lh * 0.85, -Wh * 0.45, Lh * 0.3, Wh * 0.9, s * 0.05, 'rgba(0,0,0,.25)', 1);    // rear hatch
            box(0, -Wh * 0.07, Lh * 1.15, Wh * 0.14, s * 0.03, '#2a2e24', 1);                    // gun barrel
            ell(-Lh * 0.05, 0, Wh * 0.42, Wh * 0.42, '#4a5040', 1); ell(-Lh * 0.12, 0, Wh * 0.16, Wh * 0.16, '#30362a', 1);
            hl(Lh * 0.92, -Wh * 0.3, s * 0.08); hl(Lh * 0.92, Wh * 0.3, s * 0.08);
          } else {
            box(Lh * 0.05, -Wh * 0.5, Lh * 0.7, Wh * 1.0, s * 0.12, '#f0ece2', 1);              // cabin
            box(Lh * 0.5, -Wh * 0.45, Lh * 0.18, Wh * 0.9, s * 0.05, '#9cc8e0', 1);
            box(-Lh * 0.8, -Wh * 0.45, Lh * 0.7, Wh * 0.9, s * 0.06, 'rgba(0,0,0,.2)', 1);
            hl(Lh * 0.86, -Wh * 0.35, s * 0.08); hl(Lh * 0.86, Wh * 0.35, s * 0.08);
          }
          return;
        }
        case 'side': {   // motorbike on the left + sidecar pod with its own wheel on the right
          const by = -Wh * 0.45, py = Wh * 0.5;
          tire(-Lh * 0.12, Wh * 1.0, Lh * 0.32, Math.max(2, s * 0.15));                         // sidecar wheel
          line([[Lh * 0.25, by], [Lh * 0.15, py]], '#9a9ea4', Math.max(1.5, s * 0.08));           // connecting frame
          line([[-Lh * 0.55, by], [-Lh * 0.45, py]], '#9a9ea4', Math.max(1.5, s * 0.08));
          // pod: rounded nose, open cockpit
          ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(Lh * 0.75, py); ctx.bezierCurveTo(Lh * 0.7, py - Wh * 0.5, Lh * 0.1, py - Wh * 0.48, -Lh * 0.6, py - Wh * 0.38);
          ctx.quadraticCurveTo(-Lh * 0.82, py, -Lh * 0.6, py + Wh * 0.38); ctx.bezierCurveTo(Lh * 0.1, py + Wh * 0.48, Lh * 0.7, py + Wh * 0.5, Lh * 0.75, py); ctx.fill(); ol(Math.max(1.3, s * 0.06));
          ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.beginPath(); ctx.ellipse(Lh * 0.38, py - Wh * 0.15, Lh * 0.2, Wh * 0.1, 0, 0, 7); ctx.fill();
          ell(-Lh * 0.18, py, Lh * 0.36, Wh * 0.3, '#1c1c20', 1);                                 // cockpit + seat
          ell(Lh * 0.12, py, Lh * 0.06, Wh * 0.26, 'rgba(160,200,230,.85)', 0);                   // little windscreen
          moto(Lh, by, 0, c);
          return;
        }
        default: {   // cars, vans, pickups, trucks, buggies
          const open = V.sh === 'buggy';
          if (open) {
            for (const [wx, wy] of [[0.66, -1], [0.66, 1], [-0.62, -1], [-0.62, 1]]) tire(wx * Lh, wy * Wh * 1.0, Lh * 0.42, Wh * 0.42);
            ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(Lh * 1.0, -Wh * 0.45); ctx.lineTo(Lh * 0.35, -Wh * 0.72); ctx.lineTo(-Lh * 0.9, -Wh * 0.7); ctx.lineTo(-Lh * 0.9, Wh * 0.7); ctx.lineTo(Lh * 0.35, Wh * 0.72); ctx.lineTo(Lh * 1.0, Wh * 0.45); ctx.closePath(); ctx.fill(); ol();
            box(-Lh * 0.5, -Wh * 0.55, Lh * 0.75, Wh * 1.1, s * 0.08, '#2a2a30', 1);              // open cockpit
            box(-Lh * 0.4, -Wh * 0.5, Lh * 0.45, Wh * 0.42, s * 0.08, '#141418'); box(-Lh * 0.4, Wh * 0.08, Lh * 0.45, Wh * 0.42, s * 0.08, '#141418');
            ctx.strokeStyle = '#d8d8d8'; ctx.lineWidth = Math.max(1.4, s * 0.07); ctx.strokeRect(-Lh * 0.55, -Wh * 0.62, Lh * 0.85, Wh * 1.24);   // roll cage
            line([[-Lh * 0.55, 0], [Lh * 0.3, 0]], '#d8d8d8', Math.max(1.2, s * 0.05));
            box(-Lh * 1.0, -Wh * 0.35, Lh * 0.25, Wh * 0.7, s * 0.05, '#333', 1);                  // engine
            hl(Lh * 0.95, -Wh * 0.3, s * 0.08); hl(Lh * 0.95, Wh * 0.3, s * 0.08); return;
          }
          for (const [wx, wy] of [[0.6, -1], [0.6, 1], [-0.6, -1], [-0.6, 1]]) tire(wx * Lh, wy * Wh * 0.93, Lh * 0.32, Wh * 0.3);
          const truck = V.sh === 'truck', pick = V.sh === 'pickup', van = V.sh === 'van';
          box(-Lh, -Wh * 0.92, Lh * 2, Wh * 1.84, Wh * 0.35, c, Math.max(1.4, s * 0.07));
          ctx.fillStyle = 'rgba(255,255,255,.16)'; ctx.fillRect(-Lh * 0.9, -Wh * 0.85, Lh * 1.75, Wh * 0.22);
          if (truck || pick) {
            const cab = truck ? Lh * 0.45 : Lh * 0.15;
            box(-Lh * 0.95, -Wh * 0.82, cab + Lh * 0.85, Wh * 1.64, s * 0.06, truck ? '#6f7a52' : 'rgba(0,0,0,.35)', 1);   // bed / cargo box
            ctx.strokeStyle = truck ? 'rgba(0,0,0,.3)' : 'rgba(255,255,255,.18)'; ctx.lineWidth = 1;
            for (let k = 1; k < (truck ? 6 : 4); k++) { const x = -Lh * 0.95 + k * (cab + Lh * 0.85) / (truck ? 6 : 4); ctx.beginPath(); ctx.moveTo(x, -Wh * 0.8); ctx.lineTo(x, Wh * 0.8); ctx.stroke(); }
            box(cab + Lh * 0.02, -Wh * 0.75, Lh * 0.38, Wh * 1.5, s * 0.08, 'rgba(255,255,255,.1)', 1);   // cab roof
            box(cab + Lh * 0.38, -Wh * 0.75, Lh * 0.1, Wh * 1.5, s * 0.03, '#9cc8e0');
          } else {
            const r0 = van ? -Lh * 0.85 : -Lh * 0.45, r1 = Lh * 0.3;
            box(r1, -Wh * 0.74, Lh * 0.2, Wh * 1.48, s * 0.06, '#9cc8e0', 1);                       // windshield
            box(r0 - Lh * 0.1, -Wh * 0.7, Lh * 0.1, Wh * 1.4, s * 0.04, '#7fa6bc');                 // rear window
            box(r0, -Wh * 0.74, r1 - r0, Wh * 1.48, Wh * 0.25, 'rgba(0,0,0,.12)', 1);               // roof
            if (V.hp === 220) { ctx.fillStyle = '#222'; ctx.beginPath(); ctx.arc(-Lh * 1.02, 0, Wh * 0.32, 0, 7); ctx.fill(); }   // jeep: spare wheel
          }
          hl(Lh * 0.94, -Wh * 0.62, s * 0.09); hl(Lh * 0.94, Wh * 0.62, s * 0.09);
          ctx.fillStyle = '#d23a2a'; ctx.fillRect(-Lh * 1.0, -Wh * 0.78, Lh * 0.05, Wh * 0.26); ctx.fillRect(-Lh * 1.0, Wh * 0.52, Lh * 0.05, Wh * 0.26);
        }
      }
    }
    function drawItem(t, n, x, y, s, now, label) {
      const k = ikind(t), rc = RARC[irar(t)], r = Math.max(5, s * 0.42);
      const g = ctx.createRadialGradient(x, y, 0, x, y, r * 1.8); g.addColorStop(0, rc + '88'); g.addColorStop(1, rc + '00');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, r * 1.8, 0, 7); ctx.fill();
      const im = iconImg(t);
      if (im) {
        const z = r * (k === 'g' ? 3.1 : 2.4);
        ctx.drawImage(im, x - z / 2, y - z / 2, z, z);
        if (label) txt(iname(t) + (n > 1 && k !== 'g' ? ' ×' + n : ''), x, y - r * 1.5 - 4, rc, '700 ' + Math.max(10, Math.round(s * 0.42)) + 'px ' + FONT, 'center', 3);
        return;
      }
      ctx.save(); ctx.translate(x, y);
      if (k === 'g') { ctx.rotate(-0.5); ctx.translate(-GLEN[GUN[t].c] * s * 0.45, 0); gunShape(t, s * 0.95, 0); }
      else if (k === 'o') { const c = AMMO[t - I_AMMO].c; ctx.fillStyle = '#3a3a2a'; ctx.fillRect(-r * 0.7, -r * 0.45, r * 1.4, r * 0.9); ctx.fillStyle = c; for (let i = 0; i < 3; i++) ctx.fillRect(-r * 0.55 + i * r * 0.42, -r * 0.3, r * 0.26, r * 0.6); }
      else if (k === 'h') {
        const j = t - I_HEAL;
        if (j === 0) { ctx.fillStyle = '#f2ece0'; ctx.beginPath(); ctx.arc(0, 0, r * 0.55, 0, 7); ctx.fill(); ctx.fillStyle = '#d8cfbf'; ctx.beginPath(); ctx.arc(0, 0, r * 0.22, 0, 7); ctx.fill(); }
        else if (j <= 2) { ctx.fillStyle = j === 1 ? '#f2ece0' : '#ff9a3c'; ctx.fillRect(-r * 0.65, -r * 0.5, r * 1.3, r); ctx.fillStyle = j === 1 ? '#d9362c' : '#fff'; ctx.fillRect(-r * 0.12, -r * 0.38, r * 0.24, r * 0.76); ctx.fillRect(-r * 0.38, -r * 0.12, r * 0.76, r * 0.24); }
        else if (j === 3) { ctx.fillStyle = '#7ec8ff'; ctx.fillRect(-r * 0.3, -r * 0.55, r * 0.6, r * 1.1); ctx.fillStyle = '#fff'; ctx.fillRect(-r * 0.32, -r * 0.62, r * 0.64, r * 0.22); }
        else { ctx.fillStyle = '#7fe07a'; ctx.fillRect(-r * 0.32, -r * 0.6, r * 0.64, r * 1.2); ctx.fillStyle = '#222'; ctx.fillRect(-r * 0.32, -r * 0.1, r * 0.64, r * 0.2); }
      } else if (k === 'v') { ctx.fillStyle = VESTC[t - I_VEST + 1]; ctx.beginPath(); ctx.moveTo(-r * 0.6, -r * 0.6); ctx.lineTo(-r * 0.2, -r * 0.6); ctx.lineTo(0, -r * 0.35); ctx.lineTo(r * 0.2, -r * 0.6); ctx.lineTo(r * 0.6, -r * 0.6); ctx.lineTo(r * 0.6, r * 0.65); ctx.lineTo(-r * 0.6, r * 0.65); ctx.fill(); }
      else if (k === 'e') { ctx.fillStyle = HELMC[t - I_HELM + 1]; ctx.beginPath(); ctx.arc(0, r * 0.15, r * 0.62, Math.PI, 0); ctx.fill(); ctx.fillRect(-r * 0.75, r * 0.1, r * 1.5, r * 0.18); }
      else if (k === 'b') { ctx.fillStyle = ['#6b5a3a', '#4f5a3a', '#3a3f45'][t - I_BAG]; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-r * 0.5, -r * 0.65, r, r * 1.3, r * 0.2); else ctx.rect(-r * 0.5, -r * 0.65, r, r * 1.3); ctx.fill(); ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(-r * 0.4, 0, r * 0.8, r * 0.4); }
      else if (k === 'a') { const A = ATT[t - I_ATT]; ctx.fillStyle = '#1d1e22'; if (A.k === 'sc') { ctx.fillRect(-r * 0.7, -r * 0.18, r * 1.4, r * 0.36); ctx.fillStyle = '#6fb8ff'; ctx.beginPath(); ctx.arc(r * 0.7, 0, r * 0.22, 0, 7); ctx.fill(); } else if (A.k === 'xm') { ctx.fillRect(-r * 0.25, -r * 0.65, r * 0.5, r * 1.3); } else if (A.k === 'sp') { ctx.fillRect(-r * 0.75, -r * 0.2, r * 1.5, r * 0.4); } else { ctx.fillRect(-r * 0.15, -r * 0.6, r * 0.3, r * 1.0); ctx.fillRect(-r * 0.45, -r * 0.6, r * 0.9, r * 0.25); } }
      else if (k === 't') { ctx.fillStyle = THROW[t - I_THR].c; ctx.beginPath(); ctx.arc(0, 0, r * 0.5, 0, 7); ctx.fill(); ctx.fillStyle = '#333'; ctx.fillRect(-r * 0.12, -r * 0.75, r * 0.24, r * 0.3); }
      else if (k === 'm') { ctx.rotate(-0.6); ctx.fillStyle = '#4a3a2a'; ctx.fillRect(-r * 0.8, -r * 0.08, r * 0.9, r * 0.16); ctx.fillStyle = t - I_MEL === 0 ? '#2b2b2e' : '#c8ccd2'; if (t - I_MEL === 0) { ctx.beginPath(); ctx.arc(r * 0.4, 0, r * 0.45, 0, 7); ctx.fill(); } else ctx.fillRect(0, -r * 0.12, r * 0.9, r * 0.24); }
      ctx.restore();
      if (label) txt(iname(t) + (n > 1 && k !== 'g' ? ' ×' + n : ''), x, y - r * 1.5 - 4, rc, '700 ' + Math.max(10, Math.round(s * 0.42)) + 'px ' + FONT, 'center', 3);
    }
    function drawCrate(x, y, s, air, open) {
      const w = s * (air ? 1.4 : 1.1);
      ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.fillRect(x - w / 2 + 3, y - w / 2 + 4, w, w);
      ctx.fillStyle = air ? (open ? '#7a3a32' : '#c8392f') : '#7a5634'; ctx.fillRect(x - w / 2, y - w / 2, w, w);
      ctx.strokeStyle = air ? '#f2e9d8' : '#4a3220'; ctx.lineWidth = Math.max(1.5, s * 0.08);
      ctx.strokeRect(x - w / 2, y - w / 2, w, w); ctx.beginPath(); ctx.moveTo(x - w / 2, y - w / 2); ctx.lineTo(x + w / 2, y + w / 2); ctx.moveTo(x + w / 2, y - w / 2); ctx.lineTo(x - w / 2, y + w / 2); ctx.stroke();
      if (air && !open) { ctx.fillStyle = '#3d7bd6'; ctx.fillRect(x - w / 2, y - w * 0.1, w, w * 0.2); }
    }
    function drawWorld(now) {
      const M = W.M, T = M.T, s = cam.s, v = viewer(), m = me();
      drawTerrain();
      // surf line
      if (s > 3) {
        ctx.strokeStyle = 'rgba(255,255,255,.22)'; ctx.lineWidth = 1.2;
        const wt = now / 1000;
        for (const lb of M.lobes) { ctx.beginPath(); for (let k = 0; k <= 120; k++) { const th = k / 120 * 6.2832, pt = lobePt(lb, th, 1.6 + Math.sin(wt * 1.5 + th * 9) * 0.3); const X = SX(pt[0]), Y = SY(pt[1]); if (k) ctx.lineTo(X, Y); else ctx.moveTo(X, Y); } ctx.stroke(); }
      }
      if (W.ph === 0) {   // landing map
        ctx.fillStyle = T.k === 'j' ? '#2f7a32' : T.k === 's' ? '#cfe0d8' : T.k === 'd' ? '#a8a060' : '#3d8a3a';
        for (const b of M.bush) { ctx.beginPath(); ctx.arc(SX(b[0]), SY(b[1]), Math.max(1, b[2] * s), 0, 7); ctx.fill(); }
        ctx.fillStyle = T.tc; for (const c of M.circs) if (c[3] === 1) { ctx.beginPath(); ctx.arc(SX(c[0]), SY(c[1]), Math.max(1, 1.4 * s), 0, 7); ctx.fill(); }
        ctx.fillStyle = '#8f8a86'; for (const c of M.circs) if (c[3] === 3) { ctx.beginPath(); ctx.arc(SX(c[0]), SY(c[1]), c[2] * s, 0, 7); ctx.fill(); }
        M.blds.forEach((b) => { ctx.fillStyle = T.roof[b.rf % T.roof.length]; ctx.fillRect(SX(b.x0), SY(b.y0), (b.x1 - b.x0) * s, (b.y1 - b.y0) * s); });
        ctx.fillStyle = '#6a6a5a'; for (const q of M.cont) ctx.fillRect(SX(q[0]), SY(q[1]), (q[2] - q[0]) * s, (q[3] - q[1]) * s);
        for (const vv of W.vh) { ctx.fillStyle = VEH[vv.ty].col; ctx.beginPath(); ctx.arc(SX(vv.x), SY(vv.y), Math.max(2.5, s * 1.2), 0, 7); ctx.fill(); }
        // flight path
        const ca = Math.cos(W.pa), sa = Math.sin(W.pa), ox = -sa * W.po, oy = ca * W.po;
        ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 2; ctx.setLineDash([10, 8]);
        ctx.beginPath(); ctx.moveTo(SX(ox - ca * HL * 1.4), SY(oy - sa * HL * 1.4)); ctx.lineTo(SX(ox + ca * HL * 1.4), SY(oy + sa * HL * 1.4)); ctx.stroke(); ctx.setLineDash([]);
        const u = 1 - W.t / DROP_T, px = ox + ca * HL * (u * 2.4 - 1.2), py = oy + sa * HL * (u * 2.4 - 1.2);
        drawPlane(SX(px), SY(py), W.pa, 1.2);
        return;
      }
      // decals: blood, scorch, footprints
      for (const d of decals) {
        if (!onScreen(d.x, d.y, d.r + 1)) continue;
        const fade = clamp(1 - (d.t - 50) / 20, 0, 1) * d.a; if (fade <= 0) continue;
        const X = SX(d.x), Y = SY(d.y), R = d.r * s;
        ctx.globalAlpha = fade;
        if (d.k === 0) {
          ctx.fillStyle = '#6a0a0e'; ctx.beginPath(); ctx.ellipse(X, Y, R, R * 0.75, d.rot, 0, 7); ctx.fill();
          ctx.fillStyle = '#8a1016'; ctx.beginPath(); ctx.ellipse(X + Math.cos(d.sd) * R * 0.5, Y + Math.sin(d.sd) * R * 0.4, R * 0.5, R * 0.38, d.rot + 1, 0, 7); ctx.fill();
          ctx.beginPath(); ctx.arc(X + Math.cos(d.sd * 3) * R * 1.2, Y + Math.sin(d.sd * 3) * R * 1.1, R * 0.16, 0, 7); ctx.fill();
        } else {
          const g = ctx.createRadialGradient(X, Y, 0, X, Y, R * 1.4); g.addColorStop(0, 'rgba(20,16,14,.85)'); g.addColorStop(1, 'rgba(20,16,14,0)');
          ctx.fillStyle = g; ctx.beginPath(); ctx.arc(X, Y, R * 1.4, 0, 7); ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      if (steps.length) {
        ctx.fillStyle = 'rgba(110,130,150,.45)';
        for (const f of steps) { if (!onScreen(f.x, f.y, 1)) continue; ctx.globalAlpha = clamp(1 - f.t / 30, 0, 1) * 0.8; ctx.beginPath(); ctx.ellipse(SX(f.x), SY(f.y), s * 0.13, s * 0.07, f.a, 0, 7); ctx.fill(); }
        ctx.globalAlpha = 1;
      }
      // fire areas (ground glow)
      for (const a of W.ar) if (a.k === 1 && onScreen(a.x, a.y, 4)) { const g = ctx.createRadialGradient(SX(a.x), SY(a.y), 0, SX(a.x), SY(a.y), 3.4 * s); g.addColorStop(0, 'rgba(255,140,40,.55)'); g.addColorStop(1, 'rgba(255,80,20,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(SX(a.x), SY(a.y), 3.4 * s, 0, 7); ctx.fill(); }
      // walls, containers, rocks, cacti, trunks
      const vb = v ? inBld(M, v.x, v.y) : -1;
      ctx.fillStyle = '#4a3a2c';
      const inView = (q) => !(q[2] < cam.x - lay.w / s || q[0] > cam.x + lay.w / s || q[3] < cam.y - lay.h / s || q[1] > cam.y + lay.h / s);
      for (const q of M.rects) { if (q.d != null || q.w != null || !inView(q)) continue; ctx.fillRect(SX(q[0]), SY(q[1]), (q[2] - q[0]) * s + 0.5, (q[3] - q[1]) * s + 0.5); }
      drawOpenings(v, s);
      for (const q of M.cont) {
        if (!onScreen((q[0] + q[2]) / 2, (q[1] + q[3]) / 2, 5)) continue;
        const X = SX(q[0]), Y = SY(q[1]), w = (q[2] - q[0]) * s, h = (q[3] - q[1]) * s;
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(X + 3, Y + 4, w, h);
        ctx.fillStyle = ['#b0472f', '#3f6f8f', '#c99a3a', '#4f7a4a'][q[4]]; ctx.fillRect(X, Y, w, h);
        ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1; const hor = w > h;
        for (let k = 1; k < 10; k++) { ctx.beginPath(); if (hor) { ctx.moveTo(X + w * k / 10, Y); ctx.lineTo(X + w * k / 10, Y + h); } else { ctx.moveTo(X, Y + h * k / 10); ctx.lineTo(X + w, Y + h * k / 10); } ctx.stroke(); }
      }
      for (const c of M.circs) {
        if (!onScreen(c[0], c[1], c[2] + 1)) continue;
        const X = SX(c[0]), Y = SY(c[1]), R = c[2] * s;
        if (c[3] === 0 || c[3] === 3) {
          ctx.fillStyle = 'rgba(0,0,0,.2)'; ctx.beginPath(); ctx.ellipse(X + R * 0.15, Y + R * 0.25, R, R * 0.9, 0, 0, 7); ctx.fill();
          ctx.fillStyle = T.k === 'd' ? '#b0855a' : T.k === 's' ? '#8f979e' : '#8f8a86'; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.fill();
          ctx.fillStyle = T.k === 'd' ? '#c99e6e' : T.k === 's' ? '#eef3f7' : '#b3aea8'; ctx.beginPath(); ctx.arc(X - R * 0.25, Y - R * 0.3, R * 0.55, 0, 7); ctx.fill();
        } else if (c[3] === 2) {
          ctx.fillStyle = '#4f8a3a'; ctx.beginPath(); ctx.arc(X, Y, R * 1.3, 0, 7); ctx.fill();
          ctx.fillStyle = '#6aa84a'; ctx.beginPath(); ctx.arc(X - R * 0.9, Y - R * 0.2, R * 0.6, 0, 7); ctx.arc(X + R * 0.9, Y + R * 0.1, R * 0.6, 0, 7); ctx.fill();
        } else { ctx.fillStyle = '#5a3f2a'; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.fill(); }
      }
      // loot, death boxes, airdrops
      for (let j = 0; j < M.loot.length; j++) { const l = M.loot[j]; if (!W.tk[j] && onScreen(l.x, l.y, 1.5)) drawItem(l.t, l.n, SX(l.x), SY(l.y), s, now, false); }
      for (const l of W.dr) if (onScreen(l.x, l.y, 1.5)) drawItem(l.t, l.n, SX(l.x), SY(l.y), s, now, false);
      for (const b of W.bx) {
        if (!onScreen(b.x, b.y, 2)) continue;
        drawCrate(SX(b.x), SY(b.y), s, b.ad, true);
      }
      for (const d of W.ad) if (d.t <= 0 && !d.op && onScreen(d.x, d.y, 2)) drawCrate(SX(d.x), SY(d.y), s, true, false);
      drawRecall(now, s);
      // the ground item F / 「줍기」 would take now: outlined (wheel / ‹ › choose another)
      if (ctrlOn() && !ovOpen() && pickList.length && pickList[pickSel]) {
        const it = pickList[pickSel], X = SX(it.x), Y = SY(it.y), r = Math.max(9, s * 0.55), pu = 1 + Math.sin(now / 160) * 0.08;
        ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(X, Y, r * pu, 0, 7); ctx.stroke();
        if (pickList.length > 1) { ctx.strokeStyle = 'rgba(255,255,255,.35)'; ctx.lineWidth = 1.2; for (const o of pickList) if (o !== it) { ctx.beginPath(); ctx.arc(SX(o.x), SY(o.y), r * 0.8, 0, 7); ctx.stroke(); } }
      }
      // vehicles
      W.vh.forEach((vv, j) => { if (onScreen(vv.x, vv.y, 4)) drawVeh(vv, j); });
      // players
      const order = W.pl.filter((p) => !p.out && p.veh < 0 && !p.far).sort((a, b) => (b.kd - a.kd) || a.y - b.y);
      const shown = [];
      seen = {};
      for (const p of order) {
        if (!onScreen(p.x, p.y, 7)) continue;
        // enemies only when I can actually see them (line of sight; bushes & smoke hide)
        if (v && W.ph === 2 && p.tm !== v.tm && (hiddenFrom(W, v, p) || !los(M, v.x, v.y, p.x, p.y))) continue;
        drawPlayer(p, now, v); shown.push(p); seen[p.i] = 1;
      }
      W.vh.forEach((vv) => { if (vv.hp > 0 && onScreen(vv.x, vv.y, 4)) drawRiders(vv, now, v); });
      // wild animals (only what I can see) and range targets
      for (const a of W.an) {
        if (!onScreen(a.x, a.y, 3)) continue;
        if (v && W.ph === 2 && (hyp(a.x - v.x, a.y - v.y) > Math.max(W.vr, litAt(W, a.x, a.y) ? 99 : 0) || !inCone(v, a.x, a.y) || !los(M, v.x, v.y, a.x, a.y))) continue;
        drawAnimal(a, s, now);
      }
      for (const g of W.tg) if (onScreen(g.x, g.y, 3)) drawTarget(g, s, v, now);
      // red zone & falling roof warnings (on the ground)
      if (W.rz) { const r = W.rz, X = SX(r.x), Y = SY(r.y), R = r.r * s; ctx.fillStyle = r.ph ? 'rgba(220,40,30,' + (0.16 + 0.08 * Math.sin(now / 120)) + ')' : 'rgba(220,40,30,.1)'; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.fill(); ctx.strokeStyle = '#ff4a3a'; ctx.lineWidth = 2.5; ctx.setLineDash(r.ph ? [] : [10, 7]); ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
      for (const d of W.lg) { const X = SX(d.x), Y = SY(d.y), k = clamp(1 - d.t / 1.8, 0, 1); ctx.fillStyle = 'rgba(255,240,120,' + (0.12 + 0.3 * k) + ')'; ctx.beginPath(); ctx.arc(X, Y, d.r * s, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(255,230,90,.95)'; ctx.lineWidth = 2; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.arc(X, Y, d.r * s * (1 - 0.6 * k), 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.beginPath(); ctx.arc(X, Y, d.r * s, 0, 7); ctx.stroke(); txt('⚡', X, Y, '#fff3a0', '800 ' + Math.round(Math.max(12, s * 1.2)) + 'px ' + FONT, 'center', 3); }
      W.M.gy.forEach((g, k) => {
        const X = SX(g[0]), Y = SY(g[1]); if (X < -60 || Y < -60 || X > lay.w + 60 || Y > lay.h + 60) return;
        const u = gyU(W, k), R = g[2] * s;
        ctx.fillStyle = '#6a8a9a'; ctx.beginPath(); ctx.arc(X, Y, R * 0.45, 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(230,240,240,.6)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X, Y, R * 0.45, 0, 7); ctx.stroke();
        if (u >= GY_W && u < GY_E) { const q = (u - GY_W) / (GY_E - GY_W); ctx.strokeStyle = 'rgba(255,120,60,.9)'; ctx.lineWidth = 2; ctx.setLineDash([6, 5]); ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = 'rgba(255,255,255,.8)'; for (let b = 0; b < 5; b++) { const a = now / 200 + b * 1.3; ctx.beginPath(); ctx.arc(X + Math.cos(a) * R * 0.3, Y + Math.sin(a * 1.3) * R * 0.3, 1.5 + q * 3, 0, 7); ctx.fill(); } }
        else if (u >= GY_E) { const q = (u - GY_E) / (GY_P - GY_E); ctx.fillStyle = 'rgba(235,245,250,' + (0.85 - q * 0.6) + ')'; ctx.beginPath(); ctx.arc(X, Y, R * (0.7 + q * 0.6), 0, 7); ctx.fill(); }
      });
      for (const d of W.db) { const X = SX(d.x), Y = SY(d.y), k = clamp(1 - d.t / 2.6, 0, 1); ctx.fillStyle = 'rgba(0,0,0,' + (0.15 + 0.35 * k) + ')'; ctx.beginPath(); ctx.arc(X, Y, d.r * s * (0.4 + 0.6 * k), 0, 7); ctx.fill(); ctx.strokeStyle = 'rgba(255,140,60,.9)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X, Y, d.r * s, 0, 7); ctx.stroke(); }
      // thrown things & bolts
      for (const b of W.pj) {
        if (!onScreen(b.x, b.y, 3)) continue;
        const X = SX(b.x), Y = SY(b.y);
        if (b.k === 'r') { ctx.fillStyle = '#5a6448'; ctx.save(); ctx.translate(X, Y); ctx.rotate(b.a); ctx.fillRect(-s * 0.4, -s * 0.09, s * 0.8, s * 0.18); ctx.restore(); puff(b.x - Math.cos(b.a) * 0.5, b.y - Math.sin(b.a) * 0.5, 1, 0.6, ['#c8c0b0', '#ff9a3a'], 0.4); continue; }
        if (b.k === 'f') { ctx.fillStyle = '#ff5a4a'; ctx.beginPath(); ctx.arc(X, Y, Math.max(3, s * 0.18), 0, 7); ctx.fill(); puff(b.x, b.y, 1, 0.5, ['#ff8a5a', '#ffd24a'], 0.5); continue; }
        if (b.k === 'b') { ctx.strokeStyle = '#d8c8a0'; ctx.lineWidth = Math.max(1.5, s * 0.07); ctx.beginPath(); ctx.moveTo(X, Y); ctx.lineTo(X - Math.cos(b.a) * s * 0.8, Y - Math.sin(b.a) * s * 0.8); ctx.stroke(); continue; }
        const z = (b.z || 0) * s;
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(X, Y, s * 0.2, s * 0.1, 0, 0, 7); ctx.fill();
        ctx.fillStyle = THROW[b.ty] ? THROW[b.ty].c : '#888'; ctx.beginPath(); ctx.arc(X, Y - z, Math.max(3, s * 0.17), 0, 7); ctx.fill();
        if (b.ty === 3) { ctx.fillStyle = '#ffb347'; ctx.beginPath(); ctx.arc(X, Y - z - s * 0.2, Math.max(2, s * 0.08), 0, 7); ctx.fill(); }
      }
      // canopies: bushes, trees, roofs
      const bushC = T.k === 'j' ? ['#2c6a2e', '#3a8a3a', '#5aa850'] : T.k === 'd' ? ['#8a8a4a', '#a0a058', '#bdb870'] : T.k === 's' ? ['#3f6a52', '#4f7f62', '#e8f0f2'] : ['#3d8a3a', '#4fa548', '#6cc35e'];
      // canopy see-through: inside my sight (or right next to me) bushes & crowns fade so what's beneath shows.
      // Gameplay concealment is separate (hiddenFrom: hidden enemies are simply not drawn), so this only helps honest sight.
      const vc = v && W.ph === 2 ? computeVis(v, now) : null;
      const seeAt = (x, y, r) => { if (!v) return false; const d = hyp(v.x - x, v.y - y); return d < r + 1.6 || (vc ? d < vc.R + r && (inPoly(vc.px, vc.py, x, y) || d < r + 4 && inPoly(vc.px, vc.py, x + (v.x - x) * r / Math.max(d, 0.01), y + (v.y - y) * r / Math.max(d, 0.01))) : false); };
      const dtA = Math.min(0.1, Math.max(0, (now - (cnpT || now)) / 1000)); cnpT = now;
      const fadeA = (arr, j, see, lo, hi) => { let a = arr[j]; if (a === undefined) a = see ? lo : hi; const t = see ? lo : hi; a += (t - a) * Math.min(1, dtA * 8); arr[j] = a; return a; };
      for (let j = 0; j < M.bush.length; j++) {
        const b = M.bush[j];
        if (!onScreen(b[0], b[1], b[2] + 1)) continue;
        const ba = fadeA(cnpB, j, seeAt(b[0], b[1], b[2]), 0.32, 0.97);
        ctx.globalAlpha = ba;
        const X = SX(b[0]), Y = SY(b[1]), R = b[2] * s;
        ctx.fillStyle = bushC[0]; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.fill();
        ctx.fillStyle = bushC[1];
        ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = k * 1.05 + b[0]; ctx.moveTo(X + Math.cos(a) * R * 0.5 + R * 0.46, Y + Math.sin(a) * R * 0.5); ctx.arc(X + Math.cos(a) * R * 0.5, Y + Math.sin(a) * R * 0.5, R * 0.46, 0, 7); } ctx.fill();
        ctx.fillStyle = bushC[2]; ctx.beginPath(); ctx.arc(X - R * 0.2, Y - R * 0.25, R * 0.32, 0, 7); ctx.fill();
        if (ba < 0.8) { ctx.globalAlpha = 0.7; ctx.strokeStyle = bushC[0]; ctx.lineWidth = Math.max(1, s * 0.07); ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.stroke(); }
        ctx.globalAlpha = 1;
      }
      // tree canopies and roofs go on their own layer: see-through wherever my eyes reach
      const mainCtx = ctx; ctx = topLayer(); ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0); ctx.clearRect(0, 0, lay.w, lay.h); ctx.translate(shx, shy);
      for (let j = 0; j < M.circs.length; j++) {
        const c = M.circs[j];
        if (c[3] !== 1 || !onScreen(c[0], c[1], 4)) continue;
        const X = SX(c[0]), Y = SY(c[1]) - s * 0.4, R = s * 1.8;
        // crowns I can see into (or stand under) fade to see-through, with an outline left; out of sight they stay solid
        const ta = fadeA(cnpT2, j, seeAt(c[0], c[1] - 0.4, 1.8), 0.28, 0.94);
        if (ta < 0.8) { ctx.globalAlpha = 0.55; ctx.strokeStyle = 'rgba(20,40,20,.9)'; ctx.lineWidth = Math.max(1, s * 0.07); ctx.beginPath(); ctx.arc(X, Y, R * 0.85, 0, 7); ctx.stroke(); }
        ctx.globalAlpha = ta;
        if (T.k === 's') {
          for (let L2 = 0; L2 < 3; L2++) { const r = R * (1 - L2 * 0.28); ctx.fillStyle = L2 === 2 ? '#e8f0f2' : L2 ? '#3f6a52' : '#2c5240'; ctx.beginPath(); for (let k = 0; k < 16; k++) { const a = k / 16 * 6.283 + L2 * 0.2, rr = k % 2 ? r * 0.6 : r; ctx.lineTo(X + Math.cos(a) * rr, Y + Math.sin(a) * rr); } ctx.fill(); }
        } else if (T.k === 'j' || T.k === 'q' || T.k === 'd') {
          ctx.fillStyle = T.tc; ctx.beginPath();
          for (let k = 0; k < 7; k++) { const a = k / 7 * 6.283 + c[0]; ctx.moveTo(X, Y); ctx.ellipse(X + Math.cos(a) * R * 0.48, Y + Math.sin(a) * R * 0.48, R * 0.62, R * 0.2, a, 0, 7); }
          ctx.fill();
        } else {
          ctx.fillStyle = T.tc; ctx.beginPath(); ctx.arc(X, Y, R * 0.85, 0, 7); ctx.fill();
          ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.beginPath(); ctx.arc(X - R * 0.25, Y - R * 0.25, R * 0.45, 0, 7); ctx.fill();
        }
        ctx.globalAlpha = 1;
      }
      M.blds.forEach((b, j) => {
        if (!onScreen((b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2, 9)) return;
        // the roof I'm under goes see-through (not gone: a faint outline stays), one I'm standing right beside fades a little
        const ins = v && (j === vb || (v.veh < 0 && v.x > b.x0 - 0.2 && v.x < b.x1 + 0.2 && v.y > b.y0 - 0.2 && v.y < b.y1 + 0.2));
        const nb = !ins && v && v.x > b.x0 - 1.2 && v.x < b.x1 + 1.2 && v.y > b.y0 - 1.2 && v.y < b.y1 + 1.2;
        ctx.globalAlpha = ins ? 0.16 : nb ? 0.7 : 1;
        const X = SX(b.x0), Y = SY(b.y0), w = (b.x1 - b.x0) * s, h = (b.y1 - b.y0) * s, rc = T.roof[b.rf % T.roof.length];
        ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.fillRect(X + s * 0.35, Y + s * 0.5, w, h);
        ctx.fillStyle = rc; ctx.fillRect(X - s * 0.15, Y - s * 0.15, w + s * 0.3, h + s * 0.3);
        if (b.k) { ctx.strokeStyle = 'rgba(0,0,0,.18)'; ctx.lineWidth = 1; for (let xx = X; xx < X + w; xx += s * 0.6) { ctx.beginPath(); ctx.moveTo(xx, Y - s * 0.15); ctx.lineTo(xx, Y + h + s * 0.15); ctx.stroke(); } ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(X - s * 0.15, Y - s * 0.15, w + s * 0.3, (h + s * 0.3) * 0.35); }
        else {
          const hor = w >= h;
          ctx.fillStyle = 'rgba(255,255,255,.13)'; if (hor) ctx.fillRect(X - s * 0.15, Y - s * 0.15, w + s * 0.3, (h + s * 0.3) / 2); else ctx.fillRect(X - s * 0.15, Y - s * 0.15, (w + s * 0.3) / 2, h + s * 0.3);
          ctx.strokeStyle = 'rgba(0,0,0,.22)'; ctx.lineWidth = Math.max(1, s * 0.08); ctx.beginPath();
          if (hor) { ctx.moveTo(X, Y + h / 2); ctx.lineTo(X + w, Y + h / 2); } else { ctx.moveTo(X + w / 2, Y); ctx.lineTo(X + w / 2, Y + h); } ctx.stroke();
          if (T.k === 'c' && (j % 3) === 0) { ctx.fillStyle = '#9aa0a6'; ctx.fillRect(X + w * 0.2, Y + h * 0.2, s * 0.9, s * 0.7); }
          if (T.k === 's') { ctx.fillStyle = 'rgba(240,246,250,.55)'; ctx.fillRect(X - s * 0.15, Y - s * 0.15, w + s * 0.3, s * 0.6); }
        }
        ctx.globalAlpha = 1;
      });
      /* (was: every roof and tree top inside my whole field of view was cut to 18 % — so houses and trees in plain sight looked
         invisible. Now only what covers me fades, above.)
         Seeing into another building: the part of its floor my eyes reach (through an open door, a window, from the room next
         door, from a car) is cut out of its roof — exactly the field-of-view polygon, clipped to the floor inside the walls.
         (was: any roof but my own stayed solid, so a room in plain sight through a doorway stayed covered.) */
      if (vc) {
        ctx.save(); ctx.globalCompositeOperation = 'destination-out'; ctx.fillStyle = 'rgba(0,0,0,.84)';
        M.blds.forEach((b, j) => {
          if (j === vb || !onScreen((b.x0 + b.x1) / 2, (b.y0 + b.y1) / 2, 9)) return;
          if (v.veh < 0 && v.x > b.x0 - 0.2 && v.x < b.x1 + 0.2 && v.y > b.y0 - 0.2 && v.y < b.y1 + 0.2) return;
          if (hyp(Math.max(b.x0 - v.x, 0, v.x - b.x1), Math.max(b.y0 - v.y, 0, v.y - b.y1)) > vc.R) return;
          ctx.save(); ctx.beginPath(); ctx.rect(SX(b.x0 + 0.45), SY(b.y0 + 0.45), (b.x1 - b.x0 - 0.9) * s, (b.y1 - b.y0 - 0.9) * s); ctx.clip();
          visPath(ctx, vc); ctx.fill(); ctx.restore();
        });
        ctx.restore();
      }
      ctx = mainCtx;
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(topCv, 0, 0); ctx.restore();
      // outside my sight: darker (walls, closed doors and big rocks cast shadows)
      if (vc) {   // outside my field of view: darker, soft edges (no ring, no round fade)
        const W0 = cv.cv.width, H0 = cv.cv.height;
        if (!shadeCv) shadeCv = document.createElement('canvas');
        if (shadeCv.width !== W0 || shadeCv.height !== H0) { shadeCv.width = W0; shadeCv.height = H0; }
        const g = shadeCv.getContext('2d');
        g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0); g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, lay.w, lay.h);
        g.fillStyle = 'rgba(6,8,18,.5)'; g.fillRect(0, 0, lay.w, lay.h);
        g.translate(shx, shy);
        g.globalCompositeOperation = 'destination-out';
        if (canBlur) g.filter = 'blur(' + Math.round(clamp(cam.s * 0.35, 3, 9)) + 'px)';
        visPath(g, vc); g.fillStyle = '#000'; g.fill();
        g.filter = 'none'; g.globalCompositeOperation = 'source-over';
        ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(shadeCv, 0, 0); ctx.restore();
      }
      if (v && W.ph === 2) drawNight(v, now);
      if (W.ph === 2) drawWeather(now);
      // teammates under a roof still show as a ring
      if (v && W.tm) for (const p of W.pl) {
        if (p.out || p.far || p === v || p.tm !== v.tm || p.veh >= 0 || !onScreen(p.x, p.y, 2)) continue;
        const b = inBld(M, p.x, p.y); if (b < 0 || b === vb) continue;
        ctx.strokeStyle = COL(p.i); ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y), s * 0.55, 0, 7); ctx.stroke();
      }
      for (const p of shown) {
        const b = inBld(M, p.x, p.y);
        if (b >= 0 && b !== vb && !(v && p.tm === v.tm) && !(p.rev > 0) && !(vc && inPoly(vc.px, vc.py, p.x, p.y))) continue;
        if (W.tm && v && p.tm === v.tm && p !== v && s > 8) {
          txt(name(p.i), SX(p.x), SY(p.y) - s * 1.25, '#6fe0c0', '700 11px ' + FONT, 'center', 3);
          const k = p.kd ? p.khp / 100 : p.hp / HPMAX; ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(SX(p.x) - 16, SY(p.y) - s * 1.25 + 8, 32, 4); ctx.fillStyle = p.kd ? '#ee6a55' : '#f2e9d8'; ctx.fillRect(SX(p.x) - 16, SY(p.y) - s * 1.25 + 8, 32 * clamp(k, 0, 1), 4);
        }
        if (p.use > 0 && (p === v || (v && p.tm === v.tm))) { const uT = Math.max(0.1, p.uT || 5); ctx.strokeStyle = '#7fe07a'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(SX(p.x), SY(p.y), s * 0.8, -Math.PI / 2, -Math.PI / 2 + 6.283 * clamp(1 - p.use / uT, 0, 1)); ctx.stroke(); }
      }
      // smoke & flames
      for (const a of W.ar) {
        if (!onScreen(a.x, a.y, 7)) continue;
        if (a.k === 3) continue;
        if (a.k === 2) { const fade = clamp(a.t / 2, 0, 1); for (let k = 0; k < 7; k++) { const ang = k * 0.9 + now / 2500, X = SX(a.x + Math.cos(ang) * 2.2), Y = SY(a.y + Math.sin(ang) * 2); ctx.fillStyle = 'rgba(200,220,120,' + 0.38 * fade + ')'; ctx.beginPath(); ctx.arc(X, Y, s * 2.2, 0, 7); ctx.fill(); } continue; }
        if (a.k === 0) {
          const grow = clamp((15 - a.t) / 1.2, 0.2, 1), fade = clamp(a.t / 2, 0, 1);
          for (let k = 0; k < 8; k++) { const ang = k * 0.8 + now / 3000, X = SX(a.x + Math.cos(ang) * 2.2 * grow), Y = SY(a.y + Math.sin(ang) * 2 * grow); ctx.fillStyle = 'rgba(214,220,230,' + 0.62 * fade + ')'; ctx.beginPath(); ctx.arc(X, Y, s * 2.3 * grow, 0, 7); ctx.fill(); }
          ctx.fillStyle = 'rgba(236,240,246,' + 0.9 * fade + ')'; ctx.beginPath(); ctx.arc(SX(a.x), SY(a.y), s * 2.8 * grow, 0, 7); ctx.fill();
        } else {
          for (let k = 0; k < 9; k++) { const ang = k * 0.7 + a.x, r = (0.6 + (k % 3) * 0.9) , fl = Math.sin(now / 90 + k * 1.7) * 0.15; const X = SX(a.x + Math.cos(ang) * r), Y = SY(a.y + Math.sin(ang) * r); ctx.fillStyle = k % 2 ? 'rgba(255,170,50,.85)' : 'rgba(255,90,30,.8)'; ctx.beginPath(); ctx.ellipse(X, Y - s * 0.2, s * (0.35 + fl), s * (0.55 + fl), 0, 0, 7); ctx.fill(); }
        }
      }
      // particles, rings, tracers
      for (const q of parts) { ctx.globalAlpha = clamp(1 - q.t / q.life, 0, 1); ctx.fillStyle = q.c; const X = SX(q.x), Y = SY(q.y), R = Math.max(1.2, q.r * s); ctx.fillRect(X - R, Y - R, R * 2, R * 2); }
      ctx.globalAlpha = 1;
      for (const r of rings) {
        const k = r.t / r.life, R = (r.r0 + (r.r1 - r.r0) * k) * s;
        ctx.globalAlpha = 1 - k;
        if (r.fill) { ctx.fillStyle = r.c; ctx.globalAlpha = (1 - k) * 0.55; ctx.beginPath(); ctx.arc(SX(r.x), SY(r.y), R, 0, 7); ctx.fill(); }
        else { ctx.strokeStyle = r.c; ctx.lineWidth = 3; ctx.beginPath(); if (r.arc != null) ctx.arc(SX(r.x), SY(r.y), R, r.arc - 1, r.arc + 1); else ctx.arc(SX(r.x), SY(r.y), R, 0, 7); ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
      ctx.lineCap = 'round';
      for (const t of tracers) {
        const k = t.t / t.life;
        ctx.globalAlpha = (1 - k) * (t.sup ? 0.45 : 0.9);
        ctx.strokeStyle = '#ffe9a0'; ctx.lineWidth = t.w;
        if (t.sg != null) { for (const o of [-0.08, 0, 0.08]) { const L3 = hyp(t.x1 - t.x0, t.y1 - t.y0); ctx.beginPath(); ctx.moveTo(SX(t.x0), SY(t.y0)); ctx.lineTo(SX(t.x0 + Math.cos(t.sg + o) * L3), SY(t.y0 + Math.sin(t.sg + o) * L3)); ctx.stroke(); } }
        else { const u = Math.min(1, 0.3 + k * 1.5), x0 = t.x0 + (t.x1 - t.x0) * Math.max(0, u - 0.45), y0 = t.y0 + (t.y1 - t.y0) * Math.max(0, u - 0.45); ctx.beginPath(); ctx.moveTo(SX(x0), SY(y0)); ctx.lineTo(SX(t.x0 + (t.x1 - t.x0) * u), SY(t.y0 + (t.y1 - t.y0) * u)); ctx.stroke(); }
      }
      ctx.globalAlpha = 1; ctx.lineCap = 'butt';
      // airdrops in the air, plane
      for (const d of W.ad) if (d.t > 0 && onScreen(d.x, d.y, 30)) {
        const h2 = Math.min(1, d.t / 8) * s * 8, X = SX(d.x), Y = SY(d.y);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(X, Y, s * 0.8, s * 0.4, 0, 0, 7); ctx.fill();
        if (d.t < 8) { drawCrate(X, Y - h2, s, true, false); ctx.fillStyle = '#3d7bd6'; ctx.beginPath(); ctx.ellipse(X, Y - h2 - s * 2, s * 2.2, s * 1.1, 0, Math.PI, 0); ctx.fill(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(X - s * 2, Y - h2 - s * 2); ctx.lineTo(X, Y - h2); ctx.lineTo(X + s * 2, Y - h2 - s * 2); ctx.stroke(); }
      }
      if (plane) { const u = plane.t / 4, ang = Math.atan2(plane.y, plane.x) + 1.4, px = plane.x + Math.cos(ang) * (u - 0.5) * 140, py = plane.y + Math.sin(ang) * (u - 0.5) * 140; drawPlane(SX(px), SY(py), ang, Math.max(0.6, s / 12)); }
      // team pings & markers
      if (W.ph >= 1) drawWorldMarks(s, now);
      // zone
      const z = W.z;
      if (W.ph >= 2) {
        ctx.save();
        ctx.beginPath(); ctx.rect(0, 0, lay.w, lay.h); ctx.moveTo(SX(z.cx) + Math.max(0, z.r * s), SY(z.cy)); ctx.arc(SX(z.cx), SY(z.cy), Math.max(0, z.r * s), 0, 6.2832, true);
        ctx.fillStyle = 'rgba(30,80,210,.30)'; ctx.fill();
        ctx.restore();
        if (z.r > 0) { ctx.strokeStyle = '#5fa8ff'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(SX(z.cx), SY(z.cy), z.r * s, 0, 7); ctx.stroke(); }
        if (z.i < W.ZS.length) { ctx.strokeStyle = 'rgba(255,255,255,.9)'; ctx.lineWidth = 2; ctx.setLineDash([8, 6]); ctx.beginPath(); ctx.arc(SX(z.nx), SY(z.ny), Math.max(1, z.nr * s), 0, 7); ctx.stroke(); ctx.setLineDash([]); }
        const p = myP();
        if (p && !p.out && ctrlOn() && z.i < W.ZS.length) {
          const inC = hyp(p.x - z.cx, p.y - z.cy) <= z.r, tx = z.s === 1 || inC ? z.nx : z.cx, ty = z.s === 1 || inC ? z.ny : z.cy, tr = tx === z.nx ? z.nr : z.r;
          if (hyp(p.x - tx, p.y - ty) > tr) {
            const a = Math.atan2(ty - p.y, tx - p.x), X = SX(p.x) + Math.cos(a) * s * 2.6, Y = SY(p.y) + Math.sin(a) * s * 2.6;
            ctx.save(); ctx.translate(X, Y); ctx.rotate(a); ctx.fillStyle = outside(W, p) ? '#7fb8ff' : 'rgba(255,255,255,.85)';
            ctx.beginPath(); ctx.moveTo(12, 0); ctx.lineTo(-6, -8); ctx.lineTo(-2, 0); ctx.lineTo(-6, 8); ctx.closePath(); ctx.fill(); ctx.restore();
          }
        }
      }
      // hit markers & floating text
      for (const mk of marks) {
        const kill = mk.k === 3, X = SX(mk.x), Y = SY(mk.y), k = mk.t / (kill ? 0.7 : 0.35), r = (kill ? 12 : mk.k === 1 ? 9 : 7) + k * (kill ? 8 : 4);
        ctx.globalAlpha = 1 - k; ctx.strokeStyle = kill || mk.k === 2 ? '#ff4a3a' : mk.k === 1 ? '#ffd23f' : '#ffffff'; ctx.lineWidth = kill ? 4 : mk.k === 1 ? 3 : 2.5;
        if (kill) { ctx.beginPath(); ctx.arc(X, Y, r * 1.25, 0, 7); ctx.stroke(); }
        ctx.beginPath(); for (const [dx, dy] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { ctx.moveTo(X + dx * r * 0.45, Y + dy * r * 0.45); ctx.lineTo(X + dx * r, Y + dy * r); } ctx.stroke();
      }
      ctx.globalAlpha = 1;
      for (const f of floats) {
        const k = f.t / f.life;
        ctx.globalAlpha = k > 0.7 ? (1 - k) / 0.3 : 1;
        txt(f.txt, SX(f.x), SY(f.y) - k * 24, f.c, '800 ' + (f.big ? 17 : 13) + 'px ' + FONT, 'center', 4);
      }
      ctx.globalAlpha = 1;
    }
    /* ----- animals, range targets ----- */
    function drawAnimal(a, s, now) {
      const K = ANI[a.k], X = SX(a.x), Y = SY(a.y), R = K.r * s, c = K.col, mv = Math.sin(now / 90 + a.x) * 0.15;
      ctx.save(); ctx.translate(X, Y); ctx.rotate(a.a || 0);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.beginPath(); ctx.ellipse(R * 0.1, R * 0.15, R * 1.3, R * 0.8, 0, 0, 7); ctx.fill();
      ctx.fillStyle = c;
      if (K.sh === 'swarm') { for (let k = 0; k < 9; k++) { const t = now / 300 + k * 2.1; ctx.beginPath(); ctx.arc(Math.cos(t) * R * 0.8, Math.sin(t * 1.3) * R * 0.8, R * 0.18, 0, 7); ctx.fill(); } }
      else if (K.sh === 'snake') { ctx.strokeStyle = c; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.beginPath(); for (let k = 0; k <= 6; k++) { const x = R * 1.4 - k * R * 0.5, y = Math.sin(now / 150 + k) * R * 0.35; if (k) ctx.lineTo(x, y); else ctx.moveTo(x, y); } ctx.strokeStyle = '#1e2a10'; ctx.lineWidth = Math.max(4, R * 0.8); ctx.stroke(); ctx.strokeStyle = c; ctx.lineWidth = Math.max(2.5, R * 0.55); ctx.stroke(); ctx.strokeStyle = '#d8c84a'; ctx.lineWidth = Math.max(1, R * 0.12); ctx.setLineDash([R * 0.3, R * 0.3]); ctx.stroke(); ctx.setLineDash([]); ctx.lineCap = 'butt'; ctx.beginPath(); ctx.ellipse(R * 1.5, Math.sin(now / 150) * R * 0.35, Math.max(2.5, R * 0.5), Math.max(2, R * 0.38), 0, 0, 7); ctx.fill(); }
      else if (K.sh === 'shark') { ctx.beginPath(); ctx.ellipse(0, 0, R * 1.5, R * 0.55, 0, 0, 7); ctx.fill(); ctx.beginPath(); ctx.moveTo(-R * 1.3, 0); ctx.lineTo(-R * 2.0, -R * 0.55); ctx.lineTo(-R * 1.8, 0); ctx.lineTo(-R * 2.0, R * 0.55); ctx.closePath(); ctx.fill(); ctx.fillStyle = '#5a6a7a'; ctx.beginPath(); ctx.moveTo(-R * 0.2, 0); ctx.lineTo(-R * 0.7, -R * 0.15); ctx.lineTo(-R * 0.7, R * 0.15); ctx.fill(); }
      else if (K.sh === 'croc') { ctx.beginPath(); ctx.ellipse(0, 0, R * 1.6, R * 0.45, 0, 0, 7); ctx.fill(); ctx.fillRect(-R * 2.2, -R * 0.12, R * 0.8, R * 0.24); for (const sx of [0.6, -0.6]) for (const sy of [-1, 1]) ctx.fillRect(sx * R - R * 0.1, sy * R * 0.4, R * 0.2, sy * R * (0.35 + mv)); }
      else {
        // four legs, body, head
        ctx.fillStyle = '#2a2420'; for (const sx of [0.55, -0.55]) for (const sy of [-1, 1]) { ctx.beginPath(); ctx.ellipse(sx * R + mv * sy * R, sy * R * 0.55, R * 0.22, R * 0.16, 0, 0, 7); ctx.fill(); }
        ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(0, 0, R * 1.05, R * 0.62, 0, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.arc(R * 1.0, 0, R * 0.42, 0, 7); ctx.fill();
        if (K.sh === 'cat') { ctx.strokeStyle = '#2a1a0a'; ctx.lineWidth = Math.max(1, R * 0.12); for (let k = -1; k <= 1; k++) { ctx.beginPath(); ctx.moveTo(k * R * 0.4, -R * 0.55); ctx.lineTo(k * R * 0.4 + R * 0.1, R * 0.55); ctx.stroke(); } }
        if (K.sh === 'boar') { ctx.fillStyle = '#f2ece0'; ctx.fillRect(R * 1.3, -R * 0.25, R * 0.3, R * 0.1); ctx.fillRect(R * 1.3, R * 0.15, R * 0.3, R * 0.1); }
      }
      ctx.restore();
      if (a.hp < K.hp * 0.99) { const w = Math.max(18, R * 2.4); ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(X - w / 2, Y - R - 9, w, 4); ctx.fillStyle = '#ffb07a'; ctx.fillRect(X - w / 2, Y - R - 9, w * clamp(a.hp / K.hp, 0, 1), 4); }
      if (a.tg >= 0 && a.tg === me()) txt('!', X, Y - R - 14, '#ff5a4a', '800 14px ' + FONT, 'center', 3);
    }
    function drawTarget(g, s, v, now) {
      const X = SX(g.x), Y = SY(g.y), R = Math.max(6, 0.55 * s), up = g.hp > 0;
      ctx.fillStyle = '#6a5038'; ctx.fillRect(X - R * 0.12, Y, R * 0.24, R * 1.2);
      if (up) { for (const [k, c] of [[1, '#f2ece0'], [0.7, '#d83a2a'], [0.42, '#f2ece0'], [0.18, '#d83a2a']]) { ctx.fillStyle = c; ctx.beginPath(); ctx.arc(X, Y, R * k, 0, 7); ctx.fill(); } }
      else { ctx.fillStyle = 'rgba(242,236,224,.35)'; ctx.fillRect(X - R, Y - R * 0.15, R * 2, R * 0.3); }
      const dist = v ? Math.round(hyp(v.x - g.x, v.y - g.y)) : g.d;
      txt(dist + 'm', X, Y + R * 1.6, '#f2e9d8', '700 11px ' + FONT, 'center', 3);
      if (up && g.hp < 100) { ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(X - R, Y - R - 8, R * 2, 4); ctx.fillStyle = '#7fe07a'; ctx.fillRect(X - R, Y - R - 8, R * 2 * g.hp / 100, 4); }
    }
    /* ----- night, dusk and haze: one tinted layer with holes where there is light ----- */
    let nightCv = null;
    /* rain / snow / storm streaks over the screen + lightning flash */
    function drawWeather(now) {
      const wx = W.wx | 0;
      if (wx) {
        const n = wx === 2 ? 70 : 55, t = now / 1000, wa = wx === 3 ? Math.cos(W.wa) * 0.5 : 0.12;
        ctx.save(); ctx.strokeStyle = wx === 2 ? 'rgba(255,255,255,.85)' : 'rgba(190,210,235,.45)'; ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 1.2;
        ctx.beginPath();
        for (let k = 0; k < n; k++) {
          const hs = (v) => { const q = Math.sin(v) * 43758.5453; return q - Math.floor(q); }, sx = hs(k * 12.99 + 1), sy = hs(k * 78.23 + 7), sp = wx === 2 ? 0.25 + sx * 0.15 : 1.6 + sy * 0.6;
          const y = ((sy + t * sp) % 1) * (lay.h + 20) - 10, x = (((sx + t * sp * (wx === 2 ? 0.6 + Math.sin(t + k) * 0.2 : wa)) % 1) + 1) % 1 * (lay.w + 20) - 10;
          if (wx === 2) { ctx.moveTo(x + 1.8, y); ctx.arc(x, y, 1.8, 0, 7); } else { ctx.moveTo(x, y); ctx.lineTo(x - wa * 14, y - 14); }
        }
        if (wx === 2) ctx.fill(); else ctx.stroke();
        ctx.restore();
      }
      if (flashT > 0) { ctx.fillStyle = 'rgba(235,240,255,' + Math.min(0.55, flashT * 2.2) + ')'; ctx.fillRect(0, 0, lay.w, lay.h); }
    }
    function drawNight(v, now) {
      const dk = W.dk, hz = W.hz < 900, T = W.M.T;
      if (dk < 0.02 && !hz && !(W.ss > 0)) return;
      const W0 = cv.cv.width, H0 = cv.cv.height;
      if (!nightCv) nightCv = document.createElement('canvas');
      if (nightCv.width !== W0 || nightCv.height !== H0) { nightCv.width = W0; nightCv.height = H0; }
      const g = nightCv.getContext('2d');
      g.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0); g.globalCompositeOperation = 'source-over'; g.clearRect(0, 0, lay.w, lay.h); g.translate(shx, shy);
      const t = todOf(W), dusk = (t > 0.4 && t < 0.56) || t > 0.84, nv = v.spc === 3 && dk > 0.3;
      if (dk > 0.02) { g.fillStyle = nv ? 'rgba(10,40,16,' + 0.62 * dk + ')' : dusk ? 'rgba(40,20,50,' + 0.82 * dk + ')' : 'rgba(6,10,30,' + 0.86 * dk + ')'; g.fillRect(-60, -60, lay.w + 120, lay.h + 120); }
      if (hz || W.ss > 0) { g.fillStyle = W.ss > 0 ? 'rgba(200,160,100,.62)' : T.volc ? 'rgba(70,64,62,.55)' : T.swamp ? 'rgba(200,210,205,.5)' : ['rgba(200,210,205,.5)', 'rgba(70,84,100,.42)', 'rgba(232,238,246,.62)', 'rgba(30,34,52,.5)'][W.wx | 0]; g.fillRect(-60, -60, lay.w + 120, lay.h + 120); }
      g.globalCompositeOperation = 'destination-out';
      const hole = (x, y, r, a) => { const X = SX(x), Y = SY(y), R = Math.max(4, r * cam.s), gr = g.createRadialGradient(X, Y, R * 0.2, X, Y, R); gr.addColorStop(0, 'rgba(0,0,0,' + a + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(X, Y, R, 0, 7); g.fill(); };
      const cone = (x, y, ang, len, half, a) => { const X = SX(x), Y = SY(y), R = len * cam.s, gr = g.createRadialGradient(X, Y, 0, X, Y, R); gr.addColorStop(0, 'rgba(0,0,0,' + a + ')'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.beginPath(); g.moveTo(X, Y); g.arc(X, Y, R, ang - half, ang + half); g.closePath(); g.fill(); };
      hole(v.x, v.y, VIS_NEAR + 1.5, 0.75);
      { const half = coneHalf(v), len = (nv ? Math.max(W.vr, 40) : W.vr) + 2; for (const f of [1, 0.75]) cone(v.x, v.y, VA(v), len, half * f + 0.06, nv ? 0.5 : 0.42); }
      for (const l of W.lt) hole(l.x, l.y, l.r * 1.2, 0.9);
      for (const a of W.ar) if (a.k === 1) hole(a.x, a.y, 7, 0.9);
      for (const p of W.pl) {
        if (p.out || p.far || p.air > 0) continue;
        const own = p === v || p.tm === v.tm || seen[p.i];
        if (p.lit && dk > 0.3 && own) { cone(p.x, p.y, VA(p), 42, 0.26, 0.95); cone(p.x, p.y, VA(p), 30, 0.14, 0.6); }
        if (p.mf > 0 || (vis[p.i] && vis[p.i].mf > 0)) hole(p.x, p.y, 6, 0.8);
      }
      for (const c of W.vh) if (c.hp > 0 && dk > 0.3 && W.pl.some((p) => !p.out && p.veh === W.vh.indexOf(c) && p.seat === 0)) { cone(c.x, c.y, c.v < -0.3 ? c.a + Math.PI : c.a, 30, 0.45, 1); hole(c.x, c.y, 3, 0.7); }
      g.globalCompositeOperation = 'source-over';
      if (W.ss > 0) { g.strokeStyle = 'rgba(240,210,150,.35)'; g.lineWidth = 1; g.beginPath(); for (let k = 0; k < 40; k++) { const x = ((k * 97 + now * 0.4) % (lay.w + 80)) - 40, y = (k * 53) % lay.h; g.moveTo(x, y); g.lineTo(x + 26, y + 4); } g.stroke(); }
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(nightCv, 0, 0); ctx.restore();
    }
    /* ----- vision (cached ray fan from the viewer) ----- */
    let visC = null, topCv = null, shx = 0, shy = 0, seen = {};
    /* the field of view: a cone ahead (walls & closed doors cut it) + a small circle all round, edges tapered */
    let cnpT = 0, cnpB = [], cnpT2 = [];
    function computeVis(v, now) {
      const R = Math.min(90, hyp(lay.w, lay.h) / 2 / cam.s + 3, reachOf(v) + 1), c = visC, half = coneHalf(v), va = VA(v);
      if (c && c.M === W.M && hyp(c.x - v.x, c.y - v.y) < 0.12 && c.dv === W.dv && Math.abs(c.R - R) < R * 0.08 && Math.abs(wrapA(c.a - va)) < 0.015 && c.half === half && now - c.t < 350) return c;
      const px = c && c.px.length === VIS_N ? c.px : new Float32Array(VIS_N), py = c && c.py.length === VIS_N ? c.py : new Float32Array(VIS_N);
      visFan(W.M, v.x, v.y, va, half, R, px, py);
      return (visC = { x: v.x, y: v.y, a: va, half, R, dv: W.dv, t: now, px, py, M: W.M });
    }
    let shadeCv = null;
    const canBlur = (() => { try { const g = document.createElement('canvas').getContext('2d'); return !!g && 'filter' in g; } catch (e) { return false; } })();
    function visPath(g, c, rev) {
      const N = c.px.length;
      if (!rev) g.beginPath();
      g.moveTo(SX(c.px[0]), SY(c.py[0]));
      for (let k = 1; k < N; k++) g.lineTo(SX(c.px[k]), SY(c.py[k]));
      g.closePath();
    }
    function topLayer() {
      const W0 = cv.cv.width, H0 = cv.cv.height;
      if (!topCv) topCv = document.createElement('canvas');
      if (topCv.width !== W0 || topCv.height !== H0) { topCv.width = W0; topCv.height = H0; }
      return topCv.getContext('2d');
    }
    /* doors (brown leaf: closed blocks bullets/eyes; open = swung inward) and windows (glass) */
    function drawOpenings(v, s) {
      const M = W.M, c = v && v === myP() && ctrlOn() ? ctxOf(W, v) : null;
      for (const D of M.doors) {
        if (!onScreen(D.x, D.y, 3)) continue;
        const q = D.q, j = q.d, open = W.ds[j], lk = W.dl[j] > 0, hl = c && c.k === 'd' && c.j === j;
        if (!open) {
          ctx.fillStyle = lk ? '#8a3a2a' : '#7a5030'; ctx.fillRect(SX(q[0]), SY(q[1]), (q[2] - q[0]) * s + 0.5, (q[3] - q[1]) * s + 0.5);
          ctx.fillStyle = 'rgba(255,220,160,.35)'; const cx = SX(D.x + (D.ny ? D.hw * 0.6 : 0)), cy = SY(D.y + (D.nx ? D.hw * 0.6 : 0)); ctx.beginPath(); ctx.arc(cx, cy, Math.max(1.2, s * 0.08), 0, 7); ctx.fill();
        } else {
          // hinge at one end of the gap, the leaf swung into the room
          const hx = D.x - (D.ny ? D.hw : 0), hy = D.y - (D.nx ? D.hw : 0), ex = hx - D.nx * D.hw * 2, ey = hy - D.ny * D.hw * 2;
          ctx.strokeStyle = '#7a5030'; ctx.lineWidth = Math.max(2, s * 0.14); ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(SX(hx), SY(hy)); ctx.lineTo(SX(ex), SY(ey)); ctx.stroke(); ctx.lineCap = 'butt';
        }
        if (hl || (lk && v && hyp(v.x - D.x, v.y - D.y) < 6)) {
          ctx.strokeStyle = lk ? '#ff8a6a' : 'rgba(255,214,120,.95)'; ctx.lineWidth = 2.5; ctx.strokeRect(SX(q[0]) - 3, SY(q[1]) - 3, (q[2] - q[0]) * s + 6, (q[3] - q[1]) * s + 6);
          if (lk) { const sd = v && (v.x - D.x) * D.nx + (v.y - D.y) * D.ny > 0 ? -1 : 1; txt('🔒 ' + Math.ceil(W.dl[j]) + '초', SX(D.x + D.nx * sd * 1.1), SY(D.y + D.ny * sd * 1.1), '#ffd27a', '700 11px ' + FONT, 'center', 3); }
        }
      }
      for (const D of M.wins) {
        if (!onScreen(D.x, D.y, 3)) continue;
        const q = D.q, X = SX(q[0]), Y = SY(q[1]), w = (q[2] - q[0]) * s + 0.5, h = (q[3] - q[1]) * s + 0.5;
        ctx.fillStyle = '#4a3a2c'; ctx.fillRect(X, Y, w, h);
        ctx.fillStyle = 'rgba(170,220,245,.85)'; if (w > h) ctx.fillRect(X + 1, Y + h * 0.3, w - 2, h * 0.4); else ctx.fillRect(X + w * 0.3, Y + 1, w * 0.4, h - 2);
        if (c && c.k === 'w' && c.j === q.w) { ctx.strokeStyle = 'rgba(160,230,255,.95)'; ctx.lineWidth = 2.5; ctx.strokeRect(X - 3, Y - 3, w + 6, h + 6); }
      }
    }
    function drawWorldMarks(s, now) {
      const tm = myTeam(), v = viewer(); if (!v) return;
      const edge = (X, Y, col, lbl) => {
        // off-screen marks: on a ring around me (keeps clear of the buttons at the screen edges)
        const cx = SX(v.x), cy = SY(v.y), a = Math.atan2(Y - cy, X - cx), rx = Math.min(lay.w * 0.27, 140), ry = Math.min(lay.h * 0.22, 150);
        const ex = cx + Math.cos(a) * rx, ey = cy + Math.sin(a) * ry;
        ctx.save(); ctx.translate(ex, ey); ctx.rotate(a); ctx.fillStyle = col; ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(10, 0); ctx.lineTo(-6, -7); ctx.lineTo(-6, 7); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
        txt(lbl, ex - Math.cos(a) * 16, ey - Math.sin(a) * 16, col, '700 10px ' + FONT, 'center', 3);
      };
      const on = (X, Y) => X > 20 && X < lay.w - 110 && Y > 130 && Y < lay.h - 200;
      for (const i in W.mk) {
        const q = W.pl[+i]; if (!q || q.tm !== tm) continue;
        const m = W.mk[i], X = SX(m[0]), Y = SY(m[1]), dist = Math.round(hyp(m[0] - v.x, m[1] - v.y));
        if (on(X, Y)) { drawMarks(ctx, () => X, () => Y, 1.4); if (+i === me() || dist > 3) txt(dist + 'm', X, Y + 10, COL(+i), '700 10px ' + FONT, 'center', 3); }
        else edge(X, Y, COL(+i), dist + 'm');
      }
      for (const pg of W.pg) {
        if (pg.tm !== tm) continue;
        const X = SX(pg.x), Y = SY(pg.y), dist = Math.round(hyp(pg.x - v.x, pg.y - v.y)), col = PINGC[pg.k];
        if (on(X, Y)) {
          const bob = Math.sin(now / 160) * 2;
          ctx.save(); ctx.translate(X, Y - 10 + bob);
          ctx.fillStyle = col; ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1.5; ctx.beginPath();
          if (pg.k === 0) { ctx.moveTo(0, -9); ctx.lineTo(9, 0); ctx.lineTo(0, 9); ctx.lineTo(-9, 0); ctx.closePath(); } else if (pg.k === 1) ctx.arc(0, 0, 9, 0, 7); else ctx.rect(-7, -7, 14, 14);
          ctx.fill(); ctx.stroke();
          if (pg.k === 1) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-4, -4); ctx.lineTo(4, 4); ctx.moveTo(4, -4); ctx.lineTo(-4, 4); ctx.stroke(); }
          ctx.restore();
          ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(X, Y, 5, 2.4, 0, 0, 7); ctx.fill();
          txt(name(pg.i) + ': ' + ['여기!', '적!', '물건!'][pg.k] + ' ' + dist + 'm', X, Y - 26 + bob, col, '700 11px ' + FONT, 'center', 3);
        } else edge(X, Y, col, ['위치', '적', '물건'][pg.k] + ' ' + dist + 'm');
      }
      for (const f of pingFx) { const X = SX(f.x), Y = SY(f.y); ctx.globalAlpha = 1 - f.t; ctx.strokeStyle = PINGC[f.k] || '#fff'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(X, Y, 6 + f.t * 34, 0, 7); ctx.stroke(); ctx.globalAlpha = 1; }
    }
    /* ----- sound direction (screen edge): gunshots, explosions, footsteps, engines ----- */
    let snd = [], pingFx = [], lastPg = 0, lsnT = 0;
    function heard(x, y, k, R, src) {
      const v = viewer(); if (!v || !W || W.ph !== 2) return;
      if (src >= 0 && W.pl[src] && (src === v.i || W.pl[src].tm === v.tm || seen[src])) return;
      const d = hyp(x - v.x, y - v.y); if (d > R || d < 3) return;
      const id = k + (src >= 0 ? src : Math.round(x) + ',' + Math.round(y));
      const e = snd.find((q) => q.id === id), T = k === 'step' || k === 'car' ? 0.45 : 1.6;
      if (e) { e.x = x; e.y = y; e.t = T; e.d = d; e.R = R; } else { snd.push({ id, x, y, k, t: T, T, d, R }); if (snd.length > 14) snd.shift(); }
    }
    function listen(rdt) {
      if (!W || W.ph < 1) return;
      // new team pings → sound + ripple
      for (const g of W.pg) if (g.id > lastPg) { lastPg = g.id; if (host()) newPing(g); }
      if (W.ph !== 2) return;
      lsnT -= rdt; if (lsnT > 0) return; lsnT = 0.2;
      const v = viewer(); if (!v) return;
      for (const q of W.pl) {
        if (q.out || q === v || q.tm === v.tm || q.far || q.veh >= 0 || q.air > 0 || seen[q.i]) continue;
        const sp = hyp(q.vx, q.vy); if (sp < 1) continue;
        heard(q.x, q.y, 'step', q.swim ? 10 : q.sx ? 20 : q.cr ? 5 : q.kd ? 4 : 12, q.i);
      }
      W.vh.forEach((vv) => { if (vv.hp > 0 && Math.abs(vv.v) > 2 && !VEH[vv.ty].ped && !(v.veh >= 0 && W.vh[v.veh] === vv) && !onScreen(vv.x, vv.y, 1)) heard(vv.x, vv.y, 'car', 60, -1); });
    }
    function newPing(g) {
      const v = viewer(); if (!v || g.tm !== v.tm) return;
      pingFx.push({ x: g.x, y: g.y, k: g.k, t: 0 }); if (pingFx.length > 6) pingFx.shift();
      Snd.tone(g.k === 1 ? 880 : 660, g.k === 1 ? 1320 : 990, 0.12, 0.1, 'triangle');
    }
    function drawSounds() {
      const v = viewer(); if (!v || !snd.length) return;
      const w = lay.w, h = lay.h, cx = w / 2, cy = h / 2;
      for (const e of snd) {
        const a = Math.atan2(e.y - v.y, e.x - v.x), ca = Math.cos(a), sa = Math.sin(a);
        // on a ring around me (outside the ping ring) so the buttons at the edges never hide it
        const X = SX(v.x) + ca * Math.min(w * 0.33, 200), Y = SY(v.y) + sa * Math.min(h * 0.25, 190), al = clamp(e.t / e.T, 0, 1) * clamp(1.25 - e.d / e.R, 0.35, 1);
        ctx.globalAlpha = al;
        ctx.save(); ctx.translate(X, Y);
        if (e.k === 'gun' || e.k === 'boom') {
          const r = e.k === 'boom' ? 13 : 9; ctx.fillStyle = e.k === 'boom' ? '#ff9a3a' : '#ff6a4a'; ctx.beginPath();
          for (let k = 0; k < 10; k++) { const b = k / 10 * 6.283, rr = k % 2 ? r * 0.45 : r; ctx.lineTo(Math.cos(b) * rr, Math.sin(b) * rr); }
          ctx.closePath(); ctx.fill(); ctx.strokeStyle = 'rgba(0,0,0,.6)'; ctx.lineWidth = 1; ctx.stroke();
        } else if (e.k === 'step') {
          ctx.rotate(a + Math.PI / 2); ctx.fillStyle = '#f2e9d8';
          ctx.beginPath(); ctx.ellipse(-4, 2, 2.6, 4.4, 0, 0, 7); ctx.ellipse(4, -3, 2.6, 4.4, 0, 0, 7); ctx.fill();
        } else { ctx.fillStyle = '#7fb8ff'; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-9, -5, 18, 10, 3); else ctx.rect(-9, -5, 18, 10); ctx.fill(); ctx.fillStyle = '#17131f'; ctx.fillRect(-6, 4, 4, 3); ctx.fillRect(2, 4, 4, 3); }
        ctx.restore();
        // a small tick pointing outward
        ctx.strokeStyle = e.k === 'step' ? '#f2e9d8' : e.k === 'car' ? '#7fb8ff' : '#ff8a5a'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(X + ca * 13, Y + sa * 13); ctx.lineTo(X + ca * 19, Y + sa * 19); ctx.stroke();
        ctx.globalAlpha = 1;
      }
    }
    function drawPlane(x, y, a, k) {
      ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.scale(k, k);
      ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(-18, 8, 36, 6);
      ctx.fillStyle = '#d8dce2'; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-20, -4, 40, 8, 4); else ctx.rect(-20, -4, 40, 8); ctx.fill();
      ctx.beginPath(); ctx.moveTo(4, -2); ctx.lineTo(-4, -24); ctx.lineTo(-10, -24); ctx.lineTo(-6, -2); ctx.moveTo(4, 2); ctx.lineTo(-4, 24); ctx.lineTo(-10, 24); ctx.lineTo(-6, 2); ctx.fill();
      ctx.fillRect(-20, -9, 5, 18);
      ctx.restore();
    }
    function persOf(i) { const M0 = aiMem[i]; return host() && isAIseat(i) && M0 && M0.ty != null && PERS[M0.ty] ? ' · ' + PERS[M0.ty].nm : ''; }
    let hudY = 70;
    function drawHud(now) {
      const w = lay.w, h = lay.h, m = me(), p = myP(), z = W.z, v = viewer();
      // vignettes: ADS, hurt, outside zone, flash
      if (v && v.ads && W.ph === 2) { const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.75); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.55)'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); }
      if (p && !p.out && ctrlOn()) {
        const low = !p.kd && p.hp < 35 ? 0.25 + 0.15 * Math.sin(now / 200) : 0, a = Math.max(low, hurtT > 0 ? hurtT * 0.7 * FXK() : 0, p.kd ? 0.35 : 0);
        if (a > 0) { const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.7); g.addColorStop(0, 'rgba(150,0,0,0)'); g.addColorStop(1, 'rgba(150,0,0,' + a + ')'); ctx.fillStyle = g; ctx.fillRect(0, 0, w, h); }
        if (W.ph === 2 && outside(W, p)) { ctx.strokeStyle = 'rgba(80,140,255,' + (0.35 + 0.2 * Math.sin(now / 250)) + ')'; ctx.lineWidth = 12; ctx.strokeRect(6, 6, w - 12, h - 12); }
        for (const d of dmgDir) { const a2 = d.a, k = 1 - d.t / 1.2; ctx.strokeStyle = 'rgba(255,60,40,' + k * 0.85 + ')'; ctx.lineWidth = 6; ctx.beginPath(); ctx.arc(w / 2, h / 2 + 10, Math.min(w, h) * 0.3, a2 - 0.25, a2 + 0.25); ctx.stroke(); }
      }
      // minimap
      const mx = w - MM - 8, my = 8;
      if (W.ph >= 1) {
        ctx.fillStyle = 'rgba(18,16,24,.75)'; ctx.fillRect(mx - 3, my - 3, MM + 6, MM + 6);
        const ib = islandBox(), R = ib.r, ms = MM / (2 * R), MX = (x) => mx + (x - ib.x + R) * ms, MY = (y) => my + (y - ib.y + R) * ms;
        ctx.save(); ctx.beginPath(); ctx.rect(mx, my, MM, MM); ctx.clip();
        if (bgCv) ctx.drawImage(bgCv, (ib.x - R + HL) * bgS, (ib.y - R + HL) * bgS, 2 * R * bgS, 2 * R * bgS, mx, my, MM, MM);
        if (W.ph >= 2) {
          ctx.beginPath(); ctx.rect(mx, my, MM, MM); ctx.moveTo(MX(z.cx) + Math.max(0, z.r * ms), MY(z.cy)); ctx.arc(MX(z.cx), MY(z.cy), Math.max(0, z.r * ms), 0, 6.2832, true); ctx.fillStyle = 'rgba(30,80,210,.4)'; ctx.fill();
          if (z.i < W.ZS.length) { ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(MX(z.nx), MY(z.ny), Math.max(1, z.nr * ms), 0, 7); ctx.stroke(); }
        }
        for (const d of W.ad) if (!d.op) { ctx.fillStyle = '#ff4a3a'; ctx.fillRect(MX(d.x) - 2.5, MY(d.y) - 2.5, 5, 5); }
        if (W.rz) { ctx.strokeStyle = '#ff4a3a'; ctx.lineWidth = 1.5; ctx.fillStyle = 'rgba(255,60,40,.3)'; ctx.beginPath(); ctx.arc(MX(W.rz.x), MY(W.rz.y), Math.max(2, W.rz.r * ms), 0, 7); ctx.fill(); ctx.stroke(); }
        drawMarks(ctx, MX, MY, 0.6);
        mapRecall(ctx, MX, MY, 0.6, now);
        for (const q of W.pl) {
          if (q.out) continue;
          const mine = q === v || (v && W.tm && q.tm === v.tm);
          if (!mine && (m >= 0 || W.ph !== 2)) continue;
          ctx.fillStyle = q === v ? '#ffffff' : COL(q.i); ctx.beginPath(); ctx.arc(MX(q.x), MY(q.y), q === v ? 3.2 : 3, 0, 7); ctx.fill();
          if (q !== v) { ctx.strokeStyle = q.kd ? '#ff3a2a' : '#17131f'; ctx.lineWidth = q.kd ? 1.6 : 1; ctx.stroke(); }
          if (q === v) { ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1; ctx.stroke(); }
        }
        if (v) { ctx.strokeStyle = 'rgba(255,255,255,.5)'; ctx.lineWidth = 1; const vw = lay.w / cam.s * ms, vh = lay.h / cam.s * ms; ctx.strokeRect(MX(cam.x) - vw / 2, MY(cam.y) - vh / 2, vw, vh); }
        ctx.restore();
        // "tap = big map" hint in the corner
        if (ctrlOn()) { pill(mx + MM - 22, my + 2, 20, 18, 'rgba(18,16,24,.8)'); txt('⤢', mx + MM - 12, my + 11, '#f2e9d8', '700 12px ' + FONT); }
      }
      // top-left: alive, kills, zone, feed
      const LAND = landQ(), myHud = p && !p.out && ctrlOn() && W.ph >= 1, ty0 = LAND && myHud ? 52 : 8;
      if (W.ph >= 1) {
        const alive = W.pl.filter((q) => !q.out).length;
        pill(8, ty0, 124, 26, 'rgba(18,16,24,.8)');
        txt('생존 ' + alive, 18, ty0 + 13, '#f2e9d8', '700 14px ' + FONT, 'left');
        txt('처치 ' + (v ? v.kills : 0), 124, ty0 + 13, '#e3ae45', '700 13px ' + FONT, 'right');
        if (W.ph >= 2) {
          const zs = z.i >= W.ZS.length ? '자기장이 모두 닫혔어요!' : z.s === 1 ? '자기장 줄어드는 중 ' + Math.ceil(z.t) + '초' : Math.ceil(z.t) + '초 뒤 자기장 줄음';
          const zw = LAND ? clamp(hpW() - 50, 120, 196) : Math.min(w - MM - 26 - 50, 196), zy = ty0 + 30;
          if (!W.rg) { pill(8, zy, zw, 24, z.s === 1 || z.i >= W.ZS.length ? 'rgba(40,90,210,.88)' : 'rgba(18,16,24,.72)'); ctx.save(); ctx.beginPath(); ctx.rect(8, zy, zw - 4, 24); ctx.clip(); txt(zs, 18, zy + 12, '#f2e9d8', '600 12px ' + FONT, 'left'); ctx.restore(); }
          // time of day (and weather)
          const tt = todOf(W), tl = W.ss > 0 ? ['🌪', '모래'] : tt < 0.42 ? ['☀', '낮'] : tt < 0.52 ? ['🌅', '노을'] : tt < 0.86 ? ['🌙', '밤'] : ['🌄', '새벽'];
          const tx0 = W.rg ? 8 : 8 + zw + 4;
          const wxs = W.wx ? WXN[W.wx][0] : '', pw = wxs ? 66 : 46; pill(tx0, zy, pw, 24, W.dk > 0.5 ? 'rgba(30,36,80,.88)' : 'rgba(18,16,24,.72)'); txt(tl[0] + tl[1] + (wxs ? ' ' + wxs : ''), tx0 + pw / 2, zy + 12, '#f2e9d8', '600 11px ' + FONT);
        }
        let fy = ty0 + 68;
        for (const f of feed) {
          ctx.globalAlpha = f.t > 5 ? 6 - f.t : 1;
          const t1 = f.zone ? '' : name(f.k), s2 = (t1 ? t1 + ' → ' : '') + name(f.v) + ' (' + f.how + ')';
          ctx.font = '600 11px ' + FONT;
          const tw = Math.min(LAND ? hpW() + 30 : w - MM - 30, ctx.measureText(s2).width + 16);
          pill(8, fy - 10, tw, 20, 'rgba(18,16,24,.66)');
          ctx.save(); ctx.beginPath(); ctx.rect(8, fy - 10, tw - 4, 20); ctx.clip();
          txt(s2, 16, fy, f.v === m ? '#ff8f7a' : f.k === m ? '#e3ae45' : f.kd ? '#ffb38a' : '#f2e9d8', '600 11px ' + FONT, 'left');
          ctx.restore();
          fy += 23;
        }
        ctx.globalAlpha = 1;
        // teammates: narrow rows just above my health panel (solo: none)
        if (W.tm && v) {
          const mates = W.pl.filter((q) => q.tm === v.tm && q !== v);
          let y0 = LAND ? Math.min(fy + 4, h - 120 - mates.length * 18) : h - 64 - mates.length * 18;
          for (const mate of mates) {
            pill(8, y0, 104, 15, 'rgba(18,16,24,.66)');
            ctx.fillStyle = COL(mate.i); ctx.fillRect(12, y0 + 4, 4, 7);
            ctx.save(); ctx.beginPath(); ctx.rect(18, y0, 42, 15); ctx.clip(); txt(name(mate.i), 19, y0 + 8, mate.out ? '#7a6f86' : '#6fe0c0', '600 10px ' + FONT, 'left'); ctx.restore();
            ctx.fillStyle = 'rgba(255,255,255,.15)'; ctx.fillRect(62, y0 + 5, 44, 5);
            if (!mate.out) { ctx.fillStyle = mate.kd ? '#ee6a55' : '#f2e9d8'; ctx.fillRect(62, y0 + 5, 44 * clamp(mate.kd ? mate.khp / 100 : mate.hp / HPMAX, 0, 1), 5); }
            y0 += 18;
          }
        }
      }
      // my health / boost / armour (bottom-left; canvas only so it never blocks the stick)
      if (myHud) {
        const bw = LAND ? hpW() - 8 : Math.min(210, w - 252), x0 = 12, y0 = LAND ? 38 : h - 22;
        pill(x0 - 4, y0 - 36, bw + 8, 46, 'rgba(18,16,24,.62)');
        ctx.fillStyle = 'rgba(255,255,255,.14)'; ctx.fillRect(x0, y0 - 4, bw, 10);
        const k = p.kd ? p.khp / 100 : p.hp / HPMAX;
        ctx.fillStyle = p.kd ? '#ee6a55' : k < 0.3 ? '#ff6a55' : k < 0.6 ? '#f2d6a0' : '#f2e9d8'; ctx.fillRect(x0, y0 - 4, bw * clamp(k, 0, 1), 10);
        txt(String(Math.ceil(p.kd ? p.khp : p.hp)), x0 + bw - 2, y0 + 1, '#17131f', '700 9px ' + MONO, 'right');
        // stamina: green (light blue while 지구력 is on, red when out of breath)
        ctx.fillStyle = 'rgba(255,255,255,.12)'; ctx.fillRect(x0, y0 - 11, bw, 5);
        ctx.fillStyle = p.ex ? '#ee6a55' : p.sb > 0 ? '#9ff0ff' : '#7fe07a'; ctx.fillRect(x0, y0 - 11, bw * clamp(p.stm / STM.max, 0, 1), 5);
        const tags = [['헬멧', p.hm, HELMC[p.hm] || '#555'], ['조끼', p.vs, VESTC[p.vs] || '#555'], ['가방', p.bp, '#8a7a5a']];
        let tx = x0;
        const tw0 = bw < 150 ? 32 : 46;
        for (const [nm, lv, c] of tags) { ctx.fillStyle = lv ? c : 'rgba(255,255,255,.08)'; ctx.fillRect(tx, y0 - 30, tw0, 16); txt((tw0 < 40 ? nm[0] : nm) + (lv ? lv : '-'), tx + tw0 / 2, y0 - 22, lv ? '#fff' : '#7a6f86', '700 10px ' + FONT); tx += tw0 + 4; }
        if (tx + 30 < x0 + bw && !W.rg) { const wt = wtOf(p), cp = capOf(p); txt((p.cr ? '앉음 · ' : '') + Math.round(wt) + '/' + cp, x0 + bw, y0 - 22, wt > cp * 0.9 ? '#ff9a7a' : '#ab9fb8', '700 10px ' + MONO, 'right'); }
      }
      // drop phase
      if (W.ph === 0) {
        pill(w / 2 - 150, 10, 300, 54, 'rgba(18,16,24,.86)');
        txt((MAPS[st.mk] || MAPS[0]).nm + ' · 낙하까지 ' + Math.ceil(W.t) + '초', w / 2, 27, '#e3ae45', '700 15px ' + FONT);
        txt(ctrlOn() ? '지도를 눌러 내릴 곳을 고르세요' : '모두 내릴 곳을 고르는 중…', w / 2, 48, '#f2e9d8', '600 12px ' + FONT);
        const vp = myP();
        for (const q of W.pl) {
          if (!fin(q.lx) || !(q === vp || (vp && W.tm && q.tm === vp.tm))) continue;
          const X = SX(q.lx), Y = SY(q.ly);
          ctx.strokeStyle = COL(q.i); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X, Y, 11 + Math.sin(now / 200) * 2, 0, 7); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(X - 16, Y); ctx.lineTo(X + 16, Y); ctx.moveTo(X, Y - 16); ctx.lineTo(X, Y + 16); ctx.stroke();
          txt(q === vp ? '나' : name(q.i), X, Y + 24, '#fff', '700 12px ' + FONT, 'center', 3);
        }
        if (ctrlOn()) {
          const lines = pcMode() ? ['WASD 이동 · Shift 달리기 · C 앉기 · 마우스로 조준·쏘기', 'F 줍기·문·차 · Tab 가방 · M 지도 · Z 핑 · K 키 안내', '파란 자기장 밖은 아파요! 흰 원 안으로 가요']
            : ['왼쪽을 끌어 이동 (끝까지 밀면 달리기) · 「쏘기」 자동 조준', st.ap ? '더 좋은 물건은 밟으면 저절로 주워요' : '바닥 물건은 왼쪽 목록을 눌러 주워요 · 가방에서 정리', '파란 자기장 밖은 아파요! 흰 원 안으로 가요'];
          const bh = 76, by = h - bh - 14;
          pill(12, by, w - 24, bh, 'rgba(18,16,24,.86)');
          lines.forEach((l, k) => txt(l, w / 2, by + 17 + k * 21, k === 2 ? '#9fd0ff' : '#f2e9d8', '600 ' + (w < 380 ? 11 : 12) + 'px ' + FONT));
        }
      }
      // first seconds: the main controls
      if (false) {   // start-up tips removed (help: ? / rules / K)
        const lines = pcMode() ? ['WASD 이동 · 마우스로 바라보기 · 왼쪽 클릭 쏘기 · Shift 달리기', 'F 시체·상자 열기/줍기 · E 문 · Space 창문 · G 타기 · Tab 소지품', '파란 자기장 밖은 아파요! 흰 원 안으로 가요']
          : ['왼쪽 아래를 끌면 이동 · 「달리기」는 누르는 동안', '「쏘기」는 바라보는 쪽으로 · 누른 채 끌면 조준', '🚗🚪🪟💀🩹 버튼은 쓸 수 있을 때만 떠요', '파란 자기장 밖은 아파요! 흰 원 안으로 가요'];
        const LND = landQ(), bw2 = LND ? clamp(w - 340, 260, 480) : Math.min(w - 24, 520), bh = 14 + lines.length * 20, by = LND ? Math.round(h * 0.5) + 20 : Math.round(h * 0.5) + 34;
        ctx.globalAlpha = clamp(8 - W.T, 0, 1) * 0.92;
        pill(w / 2 - bw2 / 2, by, bw2, bh, 'rgba(18,16,24,.86)');
        const fs = w < 700 ? 10.5 : 12;
        lines.forEach((l, k) => { ctx.font = '600 ' + fs + 'px ' + FONT; let f = fs; while (f > 8 && ctx.measureText(l).width > bw2 - 12) { f -= 0.5; ctx.font = '600 ' + f + 'px ' + FONT; } txt(l, w / 2, by + 17 + k * 20, k === lines.length - 1 ? '#9fd0ff' : '#f2e9d8', '600 ' + f + 'px ' + FONT); });
        ctx.globalAlpha = 1;
      }
      if (W.ph === 2 && W.T < GO_T + 0.8 && !W.rg) {   // 3 · 2 · 1 · 시작!
        const n = Math.ceil(GO_T - W.T), t = n > 0 ? String(n) : '시작!', f = (W.T % 1);
        ctx.globalAlpha = n > 0 ? 1 - f * 0.4 : clamp((GO_T + 0.8 - W.T) / 0.8, 0, 1);
        txt(t, w / 2, h * 0.42, n > 0 ? '#f2e9d8' : '#e3ae45', '400 ' + Math.round(Math.min(w, h) * (n > 0 ? 0.22 : 0.16) * (1.15 - f * 0.15)) + 'px ' + DISP, 'center', 6);
        if (n > 0) txt('둘러보세요 — 곧 움직일 수 있어요', w / 2, h * 0.42 + Math.min(w, h) * 0.16, '#f2e9d8', '600 13px ' + FONT, 'center', 3);
        ctx.globalAlpha = 1;
      }
      drawMsg(now, p);
      drawSounds();
      drawCross(p);
      // PC: always-visible strip of the main keys
      if (pcMode() && w >= 760 && W.ph >= 1 && p && !p.out && ctrlOn()) {
        const K = (id, d) => bindKey(id) || d;
        const s2 = K('sprint', 'Shift') + ' 달리기 · ' + K('open', 'F') + ' 열기·줍기 · ' + K('door', 'E') + ' 문 · ' + K('vault', 'Space') + ' 창문 · ' + K('ride', 'G') + ' 타기 · ' + K('reload', 'R') + ' 장전 · ' + K('inv', 'Tab') + ' 소지품 · ' + K('keys', 'K') + ' 키 안내';
        ctx.font = '600 11px ' + FONT; const tw = ctx.measureText(s2).width + 20;
        if (tw < w - 330 && pickEl.style.display === 'none') { pill(w / 2 - tw / 2, h - 24, tw, 20, 'rgba(18,16,24,.62)'); txt(s2, w / 2, h - 14, '#f2e9d8', '600 11px ' + FONT); }
      }
      // stick
      if (stick && (!p || p.out || !ctrlOn())) stick = null;
      if (stick) {
        const run = edgeT > 0.15 || runLock;
        ctx.strokeStyle = run ? 'rgba(127,224,122,.75)' : 'rgba(242,233,216,.35)'; ctx.lineWidth = run ? 3 : 2; ctx.beginPath(); ctx.arc(stick.bx, stick.by, (STICK_R0 * KC()), 0, 7); ctx.stroke();
        if (run) txt('달리기', stick.bx, stick.by - (STICK_R0 * KC()) - 10, '#7fe07a', '700 11px ' + FONT, 'center', 3);
        const dx = stick.x - stick.bx, dy = stick.y - stick.by, d = hyp(dx, dy), k = d > (STICK_R0 * KC()) ? (STICK_R0 * KC()) / d : 1;
        ctx.fillStyle = 'rgba(242,233,216,.5)'; ctx.beginPath(); ctx.arc(stick.bx + dx * k, stick.by + dy * k, 20, 0, 7); ctx.fill();
      }
      // aim aids: throw arc, manual aim line (no auto-aim)
      if (p && !p.out && !p.kd && W.ph === 2 && ctrlOn() && !(p.veh >= 0 && p.seat === 0)) {
        if (p.sl === 4 && fireBtn) {
          const R2 = 26, A = fireBtn.drag ? { a: fireBtn.da, d: fireBtn.dl } : aimFor(W, p, { aim: null }, R2);
          const d = fin(A.d) ? clamp(A.d, 2, 26) : 12, tx = p.x + Math.cos(A.a) * d, ty = p.y + Math.sin(A.a) * d;
          ctx.strokeStyle = 'rgba(255,255,255,.75)'; ctx.lineWidth = 2; ctx.setLineDash([5, 5]);
          ctx.beginPath(); ctx.moveTo(SX(p.x), SY(p.y)); ctx.quadraticCurveTo(SX((p.x + tx) / 2), SY((p.y + ty) / 2) - d * cam.s * 0.25, SX(tx), SY(ty)); ctx.stroke(); ctx.setLineDash([]);
          ctx.strokeStyle = p.ts === 0 ? '#ff6a55' : '#ffffff'; ctx.beginPath(); ctx.arc(SX(tx), SY(ty), (p.ts === 0 ? 7 : p.ts === 1 ? 4.5 : 3.2) * cam.s * (p.ts === 0 ? 1 : 1), 0, 7); ctx.stroke();
        } else if (fin(locIn.aim) && ((fireBtn && fireBtn.drag) || (ptAim && !ptAim.look))) {
          const w0 = heldGun(p), R = Math.min(w0 ? GUN[w0.t].mr : 3, 40) * cam.s;
          ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 2; ctx.setLineDash([6, 6]);
          ctx.beginPath(); ctx.moveTo(SX(p.x), SY(p.y)); ctx.lineTo(SX(p.x) + Math.cos(locIn.aim) * R, SY(p.y) + Math.sin(locIn.aim) * R); ctx.stroke(); ctx.setLineDash([]);
        }
      }
      // spectating / placement
      if (W.ph >= 2 && m >= 0 && p && p.out && !auto()) {
        const so = btn.skip.style.display === 'none' ? 0 : 58;
        pill(w / 2 - 140, h - 142 - so, 280, 62, 'rgba(18,16,24,.86)');
        const place = W.res ? (W.res.find((r) => r[0] === m) || [0, 0])[1] : p.place;
        txt('탈락 · ' + (place ? place + '위' : '팀원 응원 중'), w / 2, h - 124 - so, '#ff8f7a', '700 15px ' + FONT);
        txt(v && v !== p ? '관전 중: ' + name(v.i) + persOf(v.i) : '관전 중', w / 2, h - 100 - so, '#f2e9d8', '600 12px ' + FONT);
        if (!host() && humansOut() && !W.rg) txt('호스트가 다음 판을 시작할 수 있어요', w / 2, h - 152 - so, '#e3ae45', '700 12px ' + FONT, 'center', 3);
      } else if (W.ph >= 2 && m < 0) {
        if (v) { pill(w / 2 - 110, h - 46, 220, 30, 'rgba(18,16,24,.7)'); txt('관전: ' + name(v.i) + persOf(v.i), w / 2, h - 31, '#f2e9d8', '600 12px ' + FONT); }
      }
      if (v && v.fl > 0) { ctx.fillStyle = 'rgba(255,255,255,' + clamp(v.fl / 1.5, 0, 0.97) + ')'; ctx.fillRect(0, 0, w, h); }
    }
    /* one message place (top centre, under the zone line): only the most important message shows */
    function drawMsg(now, p) {
      const w = lay.w, play = p && !p.out && ctrlOn() && W.ph === 2;
      let m = null;
      if (play && (p.use > 0 || p.rl > 0)) {
        const lbl = p.rl > 0 ? '장전 중' : p.ut === 9 ? '살리는 중' : p.ut === 10 ? '📡 귀환 송신 중' : p.ut >= 0 && HEAL[p.ut] ? HEAL[p.ut].nm + ' 쓰는 중' : '쓰는 중';
        m = { t: lbl + (p.use > 0 ? ' ' + p.use.toFixed(1) + '초' : ''), c: '#f2e9d8', bar: p.use > 0 ? clamp(1 - p.use / Math.max(0.1, p.uT || 5), 0, 1) : null, small: 1 };
      } else if (play && p.kd) m = { t: '기절!', sub: '기어서 팀원에게 가세요 — 살려 줄 수 있어요', c: '#ff8f7a' };
      else if (play && p.swim && p.stm < 30) m = { t: p.stm <= 0 ? '숨이 차요!' : '수영 중', sub: p.stm <= 0 ? '물 밖으로 나가요 — 체력이 줄어요' : '스태미나가 줄어요', c: '#7fc8ff' };
      else if (banner) { const k = banner.life / banner.max; m = { t: banner.t, sub: banner.sub, c: banner.c, a: k > 0.85 ? (1 - k) / 0.15 : Math.min(1, k * 3) }; }
      else if (play && tipT > 0) m = { t: pcMode() ? '마우스로 바라보고 왼쪽 클릭 쏘기' : '「쏘기」는 바라보는 쪽으로 · 누른 채 끌면 조준', sub: pcMode() ? 'F 열기·줍기 · E 문 · Space 창문 · G 타기 · Tab 소지품' : '오른쪽 빈 곳을 누르면 그쪽으로 돌아서 쏴요', c: '#e3ae45', a: clamp(tipT, 0, 1) };
      else if (play && p.veh >= 0 && p.seat === 0) m = { t: '운전 중', sub: '왼쪽을 끌면 그 방향으로 가요' + (VEH[W.vh[p.veh].ty].ped ? ' · 달리기 = 세게 밟기' : ''), c: '#f2e9d8', a: 0.85 };
      if (!m) return;
      const LAND = landQ(), a0 = hpW() + 16, a1 = w - 160 - 118 - 8;
      const bw = LAND ? clamp(a1 - a0, 220, 300) : Math.min(w - 92, 300), bh = m.small ? 30 : 50, cy = (LAND ? 54 : 108) + bh / 2, cx = LAND ? Math.max(a0 + bw / 2, (a0 + a1) / 2) : Math.min(w / 2, (w - 76) / 2 + 6);
      ctx.globalAlpha = m.a == null ? 1 : clamp(m.a, 0, 1);
      pill(cx - bw / 2, cy - bh / 2, bw, bh, 'rgba(18,16,24,.88)');
      const fit = (t, x, y, c, wt, px, fam) => { let z = px; ctx.font = wt + ' ' + z + 'px ' + fam; while (z > 9 && ctx.measureText(t).width > bw - 16) { z -= 1; ctx.font = wt + ' ' + z + 'px ' + fam; } txt(t, x, y, c, wt + ' ' + z + 'px ' + fam); };
      if (m.small) { fit(m.t, cx, cy - (m.bar != null ? 2 : 0), m.c, '600', 12, FONT); if (m.bar != null) { ctx.fillStyle = '#7fe07a'; ctx.fillRect(cx - bw / 2 + 10, cy + 9, (bw - 20) * m.bar, 3); } }
      else { fit(m.t, cx, cy - 9, m.c, '400', 18, DISP); if (m.sub) fit(m.sub, cx, cy + 13, '#f2e9d8', '600', 11, FONT); }
      ctx.globalAlpha = 1;
    }
    /* spread circle: how far bullets may fly off right now */
    function drawCross(p) {
      if (!p || p.out || !W || !ctrlOn() || ovOpen()) return;
      const w0 = heldGun(p);
      if (mouse && pcMode() && (!w0 || p.kd || W.ph !== 2 || p.sl > 2)) {   // PC: always a small cross at the cursor
        const X = mouse.x, Y = mouse.y; ctx.strokeStyle = 'rgba(0,0,0,.55)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(X - 7, Y); ctx.lineTo(X + 7, Y); ctx.moveTo(X, Y - 7); ctx.lineTo(X, Y + 7); ctx.stroke();
        ctx.strokeStyle = '#f2e9d8'; ctx.lineWidth = 1.5; ctx.stroke(); return;
      }
      if (p.kd || W.ph !== 2 || p.sl > 2 || !w0) return;
      if (p.veh >= 0 && p.seat === 0 && !OH(w0.t)) return;
      const spr = spreadOf(W, p, w0), G = GUN[w0.t];
      let X, Y, d, faint = false;
      if (mouse && pcMode()) { X = mouse.x; Y = mouse.y; const wp = toWorld(X, Y); d = hyp(wp.x - p.x, wp.y - p.y); }
      else {
        let a = p.a; d = clamp(G.er * 0.4, 6, 14); faint = !locIn.fire;
        if (fin(locIn.aim)) { a = locIn.aim; d = fin(locIn.ad) ? locIn.ad : d; }
        X = SX(p.x + Math.cos(a) * d); Y = SY(p.y + Math.sin(a) * d);
      }
      X += rcl.x; Y += rcl.y;
      const R = clamp(Math.tan(Math.min(0.7, spr)) * Math.max(1, d) * cam.s, 4, Math.min(lay.w, lay.h) * 0.4);
      const col = spr < 0.035 ? '#9ff0a0' : spr < 0.08 ? '#f2e9d8' : '#ffb07a';
      ctx.globalAlpha = faint ? 0.45 : 0.9;
      ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.stroke();
      ctx.strokeStyle = col; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.stroke();
      ctx.beginPath(); for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { ctx.moveTo(X + dx * (R + 2), Y + dy * (R + 2)); ctx.lineTo(X + dx * (R + 7), Y + dy * (R + 7)); } ctx.stroke();
      ctx.fillStyle = col; ctx.fillRect(X - 1, Y - 1, 2, 2);
      ctx.globalAlpha = 1;
      for (const c of conf) { ctx.save(); ctx.translate(c.x, c.y); ctx.rotate(c.rot); ctx.fillStyle = c.c; ctx.fillRect(-4, -2.5, 8, 5); ctx.restore(); }
    }
    /* 귀환 송신탑 (mast + dish), 인식표 on the ground, the beacon while someone is calling */
    const chans = () => (host() ? W.pl.filter((p) => !p.out && p.ut === 10 && p.use > 0).map((p) => ({ i: p.i, j: p.rcT | 0, u: p.use })) : W.ch || []);
    function drawTag(X, Y, r, now) {
      ctx.save(); ctx.translate(X, Y); ctx.rotate(-0.3 + Math.sin(now / 300) * 0.08);
      ctx.fillStyle = '#e8d27a'; ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1.5;
      ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-r * 0.7, -r, r * 1.4, r * 2, r * 0.45); else ctx.rect(-r * 0.7, -r, r * 1.4, r * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#17131f'; ctx.beginPath(); ctx.arc(0, -r * 0.62, r * 0.16, 0, 7); ctx.fill();
      ctx.fillRect(-r * 0.4, -r * 0.1, r * 0.8, r * 0.14); ctx.fillRect(-r * 0.4, r * 0.25, r * 0.55, r * 0.14);
      ctx.restore();
    }
    function drawRecall(now, s) {
      if (!W.rt || !W.rt.length || W.ph !== 2) return;
      const on = !!W.rcOpen, ch = chans();
      W.rt.forEach((T, j) => {
        if (!onScreen(T.x, T.y, 14)) return;
        const X = SX(T.x), Y = SY(T.y), c = ch.find((e) => e.j === j);
        ctx.globalAlpha = on ? 1 : 0.55;
        ctx.fillStyle = 'rgba(0,0,0,.28)'; ctx.beginPath(); ctx.ellipse(X + s * 0.5, Y + s * 0.4, s * 1.2, s * 0.8, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#4a5560'; ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1.5; ctx.fillRect(X - s * 0.9, Y - s * 0.9, s * 1.8, s * 1.8); ctx.strokeRect(X - s * 0.9, Y - s * 0.9, s * 1.8, s * 1.8);
        ctx.strokeStyle = '#c9d2da'; ctx.lineWidth = Math.max(1.5, s * 0.12);
        ctx.beginPath(); ctx.moveTo(X - s * 0.8, Y - s * 0.8); ctx.lineTo(X + s * 0.8, Y + s * 0.8); ctx.moveTo(X + s * 0.8, Y - s * 0.8); ctx.lineTo(X - s * 0.8, Y + s * 0.8); ctx.stroke();
        ctx.fillStyle = '#dfe7ee'; ctx.strokeStyle = '#17131f'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(X, Y, s * 0.55, 0, 7); ctx.fill(); ctx.stroke();
        const blink = on && (c ? Math.sin(now / 90) > 0 : Math.sin(now / 600) > 0.6);
        ctx.fillStyle = blink ? (c ? '#7fe0ff' : '#ff5a4a') : '#3a3a3a'; ctx.beginPath(); ctx.arc(X, Y, s * 0.22, 0, 7); ctx.fill();
        if (c) {
          const k = clamp(1 - c.u / RC.ch, 0, 1), R = s * RC.r;
          ctx.strokeStyle = 'rgba(127,224,255,.35)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(X, Y, R, 0, 7); ctx.stroke();
          ctx.strokeStyle = '#7fe0ff'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(X, Y, R, -Math.PI / 2, -Math.PI / 2 + k * 6.2832); ctx.stroke();
          const pr = (now / 900) % 1; ctx.strokeStyle = 'rgba(127,224,255,' + (1 - pr) * 0.6 + ')'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X, Y, s * (1 + pr * 7), 0, 7); ctx.stroke();
        } else if (on && s > 10) txt('📡 송신탑', X, Y - s * 1.5, '#dff6ff', '700 11px ' + FONT, 'center', 3);
        ctx.globalAlpha = 1;
      });
      const tm = myTeam();
      for (const g of W.dg || []) {
        if (g.by >= 0 || !W.pl[g.i] || W.pl[g.i].tm !== tm || !onScreen(g.x, g.y, 3)) continue;
        const X = SX(g.x), Y = SY(g.y), pu = 1 + Math.sin(now / 200) * 0.12;
        ctx.strokeStyle = COL(g.i); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(X, Y, Math.max(10, s * 0.9) * pu, 0, 7); ctx.stroke();
        drawTag(X, Y, Math.max(6, s * 0.38), now);
        txt('🏷 ' + name(g.i) + ' ' + Math.ceil(g.t) + '초', X, Y - Math.max(16, s * 1.2), '#ffe9a0', '700 11px ' + FONT, 'center', 3);
      }
    }
    /* teammates off screen: arrows on the edge (colour, distance, ✚ downed, 🏷 fallen = where the 인식표 is) */
    function drawMates(now) {
      const v = viewer(); if (!v || !W.tm || W.ph !== 2) return;
      const w = lay.w, h = lay.h, cx = w / 2, cy = h / 2, pad = 26, top = 8 + MM + 14, y0 = landQ() ? 104 : 40, y1 = h - 30, x0 = 30, x1 = w - 30;
      const items = [];
      for (const q of W.pl) {
        if (q === v || q.tm !== v.tm) continue;
        if (!q.out) { if (q.far && !host()) continue; items.push({ i: q.i, x: q.x, y: q.y, k: q.kd ? 1 : 0 }); }
        else { const g = (W.dg || []).find((e) => e.i === q.i); if (g && g.by < 0) items.push({ i: q.i, x: g.x, y: g.y, k: 2 }); }
      }
      for (const it of items) {
        const X = SX(it.x), Y = SY(it.y);
        if (X > 6 && X < w - 6 && Y > 6 && Y < h - 6) continue;
        const dx = X - cx, dy = Y - cy, a = Math.atan2(dy, dx);
        const k = Math.min((dx > 0 ? x1 - cx : cx - x0) / Math.max(1e-3, Math.abs(dx)), (dy > 0 ? y1 - cy : cy - y0) / Math.max(1e-3, Math.abs(dy)));   // inside the HUD-free band
        let ex = cx + dx * k, ey = cy + dy * k;
        if (ex > w - MM - 20 && ey < top) ey = top;   // keep clear of the minimap
        const col = COL(it.i), d = hyp(it.x - v.x, it.y - v.y), pu = it.k === 1 ? 1 + Math.sin(now / 150) * 0.15 : 1;
        ctx.save(); ctx.translate(ex, ey);
        ctx.save(); ctx.rotate(a); ctx.fillStyle = col; ctx.strokeStyle = '#17131f'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(24, 0); ctx.lineTo(13, -8); ctx.lineTo(13, 8); ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
        ctx.fillStyle = it.k === 1 ? '#c8352a' : it.k === 2 ? '#3a3340' : 'rgba(18,16,24,.88)'; ctx.strokeStyle = col; ctx.lineWidth = 2.5;
        ctx.beginPath(); ctx.arc(0, 0, 13 * pu, 0, 7); ctx.fill(); ctx.stroke();
        txt(it.k === 1 ? '✚' : it.k === 2 ? '🏷' : String(name(it.i)).slice(0, 1), 0, 0.5, '#fff', '800 12px ' + FONT);
        txt(fmtD(d), 0, 22, '#f2e9d8', '700 10px ' + FONT, 'center', 3);
        ctx.restore();
      }
    }
    function draw(now) {
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      if (!W || !lay) { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h); return; }
      useMap(W.M);
      ctx.save();
      const fxk = FXK(), sx = (kick.x * cam.s + (shake > 0 ? (Math.random() - 0.5) * shake * 8 : 0)) * fxk, sy = (kick.y * cam.s + (shake > 0 ? (Math.random() - 0.5) * shake * 8 : 0)) * fxk;
      shx = sx; shy = sy;
      ctx.translate(sx, sy);
      drawWorld(now);
      ctx.restore();
      drawMates(now);
      drawHud(now);
    }

    const stopLoop = U.loop((rdt, now) => {
      if (!(rdt > 0)) rdt = 0.0001;   // the loop can hand out a negative step right after a pause (virtual clock)
      const n = Math.min(10, Math.max(1, Math.ceil(rdt * SPD() * 30)));
      try { for (let i = 0; i < n; i++) frame(rdt / n, now); syncBtns(); syncOv(); listen(rdt); practiceHud(); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    function celebrate(next) {
      const m = me(), win = (next.res || []).filter((r) => r[1] === 1).map((r) => r[0]);
      const mine = m >= 0 && win.includes(m);
      if (m >= 0) api.sfx(mine ? 'win' : 'lose'); else api.sfx('win');
      if (mine) api.buzz(60);
      const col = win.length ? COL(win[0]) : '#e3ae45';
      for (let i = 0; i < 70; i++) conf.push({ x: cv.w * (0.2 + Math.random() * 0.6), y: cv.h * 0.3, vx: (Math.random() - 0.5) * 380, vy: -100 - Math.random() * 300, rot: Math.random() * 7, vr: (Math.random() - 0.5) * 14, c: [col, '#ffffff', '#e3ae45', '#5fa8ff'][i % 4], t: 0, life: 1.6 + Math.random() * 0.8 });
      if (W && win.length) banner = { t: mine ? '최후의 생존자!' : (win.length > 1 ? win.map(name).join('·') + ' 팀' : name(win[0])) + ' 우승!', sub: '마지막까지 살아남았어요', c: '#e3ae45', life: 3, max: 3 };
    }

    if (L.debug) L.debug.royale = () => ({ W, myP, openInv, act, setSel: (o) => { ovSel = o; ovSig = ''; }, cxs: () => cxs });   // tests only
    return {
      pause() { releaseAll(); },
      update(next) {
        if (!next) return;
        const prev = st;
        st = next;
        if (st.ph === 'team' || st.ph === 'done') setAimCursor(false);
        if (st.ph === 'team') { if (!prev || prev.rid !== st.rid) { tmT = 0; tmMine = null; } tmSig = ''; return; }
        if (st.rid !== key) { sentRes = false; startMatch(); return; }
        if (prev && prev.ph !== 'done' && next.ph === 'done') { recWin(); celebrate(next); }
        if (!host() && W && next.ph === 'done' && Array.isArray(next.res) && !W.res) W.res = next.res;
      },
      destroy() {
        setAimCursor(false);
        stopLoop();
        if (offIn) offIn();
        window.removeEventListener('blur', releaseAll);
        window.removeEventListener('lounge-ctl', onCtl);
        window.removeEventListener('keydown', onKey);
        window.removeEventListener('pointermove', dragMove);
        window.removeEventListener('pointerup', dragUp);
        window.removeEventListener('pointercancel', dragUp);
        cv.cv.removeEventListener('wheel', onWheel);
        closeOv(); closeMenus(); closeSum(); closeTeam(); pickEl.remove();
        window.removeEventListener('lounge-volume', onVol);
        window.removeEventListener('touchmove', blockScroll);
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        for (const k in btn) { if (Array.isArray(btn[k])) btn[k].forEach((b) => b.remove()); else btn[k].remove(); }
        styleEl.remove();
        tiles.clear(); bgCv = null;
        Snd.close();
        cv.destroy();
      },
      _dbg: () => ({ W, st, lay, cam, locIn, remIn, aiMem, heard, setSpec: (i) => { specT = i; }, encode: () => W && encodeW(W, key, 1, true, remoteSeats(), remoteCams(remoteSeats())) }),
    };
  }
  /* ======================= item icons (one SVG per item, same style everywhere: world, bag, loot, codex) ======================= */
  const svgI = (body) => '<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">' + body + '</svg>';
  const WOODG = { AKM: 1, Kar98k: 1, 'Mosin Nagant': 1, Win94: 1, SKS: 1, S1897: 1, S686: 1, 'DP-28': 1, 'Tommy Gun': 1, R1895: 1, M24: 0 };
  const OL = ' stroke="#121116" stroke-width="0.9" stroke-linejoin="round"';
  function shp() {
    let b = '';
    const o = {
      P(d, f) { b += '<path d="' + d + '" fill="' + f + '"' + OL + '/>'; return o; },
      R(x, y, w, h, f, r) { b += '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (r || 0) + '" fill="' + f + '"' + OL + '/>'; return o; },
      C(x, y, r, f) { b += '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + f + '"' + OL + '/>'; return o; },
      L(d, c, w) { b += '<path d="' + d + '" fill="none" stroke="' + c + '" stroke-width="' + (w || 1.4) + '" stroke-linecap="round" stroke-linejoin="round"/>'; return o; },
      T(x, y, t, c, sz) { b += '<text x="' + x + '" y="' + y + '" font-size="' + (sz || 8) + '" font-weight="800" font-family="sans-serif" text-anchor="middle" fill="' + (c || '#fff') + '" stroke="#121116" stroke-width="0.5">' + t + '</text>'; return o; },
      get s() { return svgI(b); },
    };
    return o;
  }
  const MET = '#33353c', MET2 = '#4a4d56', WD = '#8b5a32', SIL = '#a9aeb6';
  /* every gun from its class with its own length, stock, magazine and furniture, so each one looks a little different */
  function gunSVG(t) {
    const G = GUN[t], c = G.c, h = hashS(G.nm), hv = (k, n) => ((h >>> k) & 255) / 255 * n;
    const mc = AMMO[G.am].c, S = shp(), body = G.po === 'A' ? '#465640' : MET, wd = G.wood ? WD : MET2;
    if (c === 7) return S.R(3, 14.2, 22, 3.2, WD, 1.4).P('M6 17.4h3l-1 5H5z', WD).L('M23 4q-6 12 0 24', '#3a2a1a', 2.4).L('M23 4L18.5 15.8L23 28', '#d8d0bc', 0.8).L('M9 15.8h21', '#c9b89a', 1.2).P('M30 15.8l-3-1.6v3.2z', SIL).s;
    if (c === 8) return S.R(7, 11, 15, 6, '#e8742a', 2).R(21, 11.6, 6, 4.8, '#e8742a', 2).P('M9 17h5l-1.6 8H7.6z', '#c85a1a').C(25, 14, 1.6, '#3a1a0a').s;
    if (c === 9) {
      if (G.mg > 1) return S.P('M1 12h7v5H2z', MET2).R(8, 10, 8, 7, body, 1).C(16, 15.5, 5.4, mc).C(16, 15.5, 1.6, MET).R(21, 12.6, 9, 4, body, 1.5).P('M10 17h3.5l-1.2 6H9z', MET2).s;
      return S.R(1, 12.5, 26, 4.5, '#5a6448', 2.2).P('M27 14.7l4-3.6v7.2z', mc).R(9, 17, 3, 5, MET2).R(14, 9.5, 5, 3, '#1d1e22', 1).s;
    }
    if (G.nm === 'M134 Minigun') return S.R(2, 10, 10, 9, body, 2).R(12, 10.6, 18, 1.8, MET).R(12, 13.6, 18, 1.8, MET).R(12, 16.6, 18, 1.8, MET).R(14, 10, 2, 9, MET2).R(24, 10, 2, 9, MET2).R(4, 19, 5, 6, mc, 1).s;
    const len = [17, 23, 28, 28, 30, 31, 30][c] + hv(0, 2.4) - 1.2, x0 = 16 - len / 2, y = 13;
    const stockL = c === 0 || G.nostock || G.bp ? 0 : [0, 5, 7, 7, 8, 9, 7][c] + hv(8, 2);
    const recL = c === 0 ? len * 0.62 : G.bp ? len * 0.62 : len * (0.38 + hv(24, 0.08));
    const xr = x0 + stockL, xb = xr + recL, xe = x0 + len;
    // stock: solid, skeleton or folding wire
    if (stockL) {
      const sv = Math.floor(hv(16, 2.99));
      if (G.wood || sv === 0) S.P('M' + x0 + ' ' + (y - 2.2) + 'H' + xr + 'v5H' + (x0 + 1.4) + 'z', wd);
      else if (sv === 1) S.L('M' + xr + ' ' + (y - 1.5) + 'H' + (x0 + 0.8) + 'v4.6H' + xr, MET2, 1.4);
      else S.L('M' + xr + ' ' + (y + 1) + 'L' + (x0 + 0.6) + ' ' + (y + 0.4) + 'v-3', MET2, 1.1);
    }
    // receiver + barrel (+ handguard, suppressor, double barrels)
    S.R(r1(xr), y - 2.6, r1(recL), 5.2, G.nm === 'Desert Eagle' || G.nm === 'Colt Python' ? SIL : body, 1);
    if (c === 3 && G.dbl) S.R(r1(xb), y - 2.2, r1(xe - xb), 1.9, MET).R(r1(xb), y - 0.1, r1(xe - xb), 1.9, MET);
    else {
      S.R(r1(xb), y - 1, r1(xe - xb), 2, MET);
      if (c === 2 || c === 4 || c === 6 || c === 1) S.R(r1(xb), y - 1.9, r1((xe - xb) * (0.45 + hv(4, 0.2))), 3.8, G.wood ? WD : MET2, 1);
      if (c === 3) { S.R(r1(xb), y + 1.1, r1((xe - xb) * 0.8), 1.5, MET); if (!G.box) S.R(r1(xb + 1), y + 0.6, 5, 2.6, wd, 1); }
    }
    if (G.sup) S.R(r1(xe - 7), y - 1.9, 7, 3.8, '#26272c', 1.6);
    if (G.rev) S.C(r1(xr + recL * 0.45), y, 2.8, MET2);
    // grip
    const xg = G.bp ? xr + recL * 0.55 : c === 0 ? xr + 1 : xr + recL * 0.25;
    S.P('M' + r1(xg) + ' ' + (y + 2.6) + 'h3.4l-1.3 ' + (c === 0 ? 8 : 6) + 'h-3.3z', c === 0 && G.wood ? WD : MET2);
    if (G.lever) S.L('M' + r1(xg + 3.6) + ' ' + (y + 2.6) + 'q1 4 4 3.6', MET, 1.2);
    // magazine
    const xm = G.bp ? xr + 1.2 : xg + 4.4;
    if (c === 0) S.R(r1(xg + 0.2), y + 7.4, 3, 2.6, mc);
    else if (G.drum) S.C(r1(xm + 2), y + 5.6, 3.8, mc);
    else if (G.pan) S.P('M' + r1(xr + 1) + ' ' + (y - 2.6) + 'a' + 5 + ' 2.4 0 0 1 10 0z', mc);
    else if (G.box || c === 6) S.R(r1(xm), y + 2.6, 6, 5.6, mc, 1);
    else if (c === 3) { if (G.box) S.R(r1(xm), y + 2.6, 3.4, 5, mc); }
    else if (c === 5) S.R(r1(xm), y + 2.6, 2.6, 2.6, mc).C(r1(xb - 2), y + 3.2, 1.1, SIL);
    else { const ml = G.mg >= 40 ? 9 : G.mg >= 25 ? 7.5 : 5; S.P('M' + r1(xm) + ' ' + (y + 2.6) + 'h3.4l' + (c === 2 ? 1.6 : 0.4) + ' ' + ml + 'h-3.4z', mc); }
    // optics
    if (c === 5 || c === 4 || G.isc) S.R(r1(xr + recL * 0.1), y - 6.6, r1(Math.min(10, recL * 0.9)), 2.8, '#1d1e22', 1.4).R(r1(xr + recL * 0.3), y - 3.9, 1.3, 1.4, MET);
    else if (c === 2 && hv(20, 1) > 0.5) S.R(r1(xr + recL * 0.35), y - 4.8, 4, 2.2, MET);
    return S.s;
  }
  // melee: each looks like what it is
  const meleeSVG = [
    () => shp().R(1, 13.2, 12, 3.2, '#4a3a2a', 1.6).C(21, 14.8, 9, '#2b2b30').C(21, 14.8, 6.6, '#3e3e46').L('M17 11q3-2 6 0', 'rgba(255,255,255,.35)', 1.2).s,
    () => shp().R(1.5, 14.4, 8, 3.6, '#4a3a2a', 1.4).R(9.2, 13.2, 1.6, 6, '#6a6a70').P('M10.8 13.6h15.5q4.5 0 4.7 2.6l-4.7 2.6H10.8z', '#c8ccd2').L('M12 15.6h14', 'rgba(255,255,255,.55)', 0.8).s,
    () => shp().P('M4.4 29.2l2.4 1.6 11.4-17.2-2.4-1.6z', '#7a5434').P('M15.8 12.8C13 4 24 0 30.6 6.4 24.5 3.6 18.8 6.4 18.4 13.6z', '#c8ccd2').L('M17.6 10.6C17 6.4 22.6 3.6 27.4 5.4', 'rgba(255,255,255,.6)', 0.8).s,
    () => shp().L('M5 27L24.6 7.4', '#121116', 4.4).L('M5 27L24.6 7.4', '#b3262a', 3).L('M24.6 7.4q3.6-3.8 6 .6', '#121116', 4.4).L('M24.6 7.4q3.6-3.8 6 .6', '#b3262a', 3).L('M5 27l-2.6-.4', '#b3262a', 3).s,
    () => shp().P('M3 27.5l1.6 1.6 4-3.2 18.6-19.2q2-2.6-.4-4.4-2.2-1.8-4.4.6L4.8 22z', '#c89a5a').R(2, 26, 4, 4, '#7a5a3a', 1).s,                                   // 야구방망이
    () => shp().L('M6 29L20 8', '#121116', 3.6).L('M6 29L20 8', '#8a5a32', 2.4).P('M16 4q8-2 12 4l-3 4q-3-3-7-1z', '#a9aeb6').s,                                          // 도끼
    () => shp().L('M5 4L19 18', '#121116', 3).L('M5 4L19 18', '#8a5a32', 1.8).R(3, 2, 5, 3, '#4a3a2a', 1).P('M17 16l5 5-2 7q-3 1-6-2-3-3-2-6z', '#8a9098').s,             // 삽
    () => shp().L('M8 29L19 7', '#121116', 3.4).L('M8 29L19 7', '#8a5a32', 2.2).P('M5 9q8-7 23-2l-1 2q-6-2-11-1-6 1-10 3z', '#7a7f88').s,                                // 곡괭이
    () => shp().R(3, 14.5, 9, 3.2, '#2a2a30', 1.2).R(11.4, 12.6, 1.8, 7, '#7a7a80').P('M13.2 13.4h13q3 0 4.2 2.4-1.2 2.4-4.2 2.4h-13z', '#d8dce2').s,                      // 단검
    () => shp().L('M8 28L18 12', '#121116', 3.4).L('M8 28L18 12', '#8a5a32', 2.2).R(12, 5, 14, 7, '#5a5e66', 1.4).s,                                                   // 망치
    () => shp().L('M6 27L21 12', '#121116', 4).L('M6 27L21 12', '#9aa0a8', 2.6).P('M19 7a5 5 0 1 0 6 6l-3-1-1-3z', '#9aa0a8').P('M3 25a4 4 0 1 0 5 5', '#9aa0a8').s,  // 렌치
    () => shp().L('M4 28l5-5', '#2a2a30', 3.4).R(7.5, 22.2, 4.4, 1.6, '#c8a24a').L('M10 21L28 4', '#121116', 2.6).L('M10 21L28 4', '#e8ecf0', 1.6).s,                     // 카타나
    () => shp().L('M8 4L20 24', '#121116', 3).L('M8 4L20 24', '#c8a26a', 2).P('M18 22q2 4 8 3l2-2-8-1z', '#2a2a30').s,                                                 // 하키 스틱
    () => shp().L('M10 3L19 25', '#121116', 2).L('M10 3L19 25', '#b8bcc4', 1.2).R(7, 2, 4, 5, '#2a2a30', 1).P('M17 23h8l1 3h-9z', '#c8ccd2').s,                            // 골프채
    () => shp().R(5, 12, 22, 7, '#b8bcc4', 3).C(9, 15.5, 2, '#33353c').C(14, 15.5, 2, '#33353c').C(19, 15.5, 2, '#33353c').C(24, 15.5, 2, '#33353c').s,                  // 너클
    () => shp().R(3, 14, 26, 3.6, '#1e2024', 1.8).R(8, 12, 2, 7.6, '#1e2024', 0.8).s,                                                                                 // 경찰봉
  ];
  const fistSVG = () => shp().R(8, 9, 16, 14, '#e0b48a', 5).L('M12 9v6M16 9v6M20 9v6', '#9a6a4a', 1).R(6, 15, 7, 6, '#e0b48a', 3).s;
  const throwSVG = [
    () => shp().C(15, 19.5, 8.2, '#5d7a3f').L('M7.5 17h15M7.5 22h15M12 11.8v15.4M18 11.8v15.4', 'rgba(0,0,0,.35)', 0.9).R(12.4, 7.4, 5.2, 4.4, '#8a8d92', 1).P('M17.6 8l6 2.4-1 1.6-5-1.2z', '#8a8d92').L('M10.6 8.6a2.4 2.4 0 1 0 0.01 0', '#c9cdd3', 1.1).s,
    () => shp().R(10, 9, 12, 20, '#8f96a0', 2).R(9, 5, 14, 4.6, '#4a4d56', 1.4).R(10, 16, 12, 3.6, '#e8eaee').P('M22 8l5-3 1 1.4-5 3z', '#8a8d92').s,
    () => shp().R(10, 8, 12, 21, '#d8d2a0', 3).R(9, 5, 14, 4, '#4a4d56', 1.4).C(13.4, 14, 1.2, '#3a3a2a').C(18.6, 14, 1.2, '#3a3a2a').C(13.4, 20, 1.2, '#3a3a2a').C(18.6, 20, 1.2, '#3a3a2a').C(16, 25, 1.2, '#3a3a2a').s,
    () => shp().P('M12.6 13h6.8v3l3 3.6V29H9.6V19.6l3-3.6z', '#6d9a3a').R(13.6, 7.6, 4.8, 5.6, '#5c8530', 1).P('M16 1.2q-5 4-.6 7.6 5.2-3.6.6-7.6z', '#ff8a2a').P('M16 3.8q-2.2 2 0 4 2.2-2 0-4z', '#ffd04a').R(10.6, 21, 10.8, 4, 'rgba(255,255,255,.35)').s,
    () => shp().C(16, 18, 9, '#8a6a3a').P('M9 14q7-6 14 0', '#c9a36a').C(12, 19, 1.4, '#ffd24a').C(20, 20, 1.4, '#ffd24a').R(14, 5, 4, 5, '#5a5e66', 1).s,                       // 끈끈이
    () => shp().R(11, 7, 10, 22, '#ff5a4a', 2).R(10, 4, 12, 4, '#4a4d56', 1.4).P('M16 9l2 4h-4z', '#ffd24a').s,                                                              // 조명탄
    () => shp().C(16, 18, 8, '#5a7a9a').R(13.6, 6, 4.8, 5, '#8a8d92', 1).C(16, 18, 3, '#ffd24a').L('M10 12l-3-3M22 12l3-3', '#ffd24a', 1.4).s,                                 // 충격
    () => shp().R(8, 10, 16, 14, '#c9a36a', 3).C(16, 17, 4, '#3a2a1a').L('M5 13q-3 4 0 8M27 13q3 4 0 8', '#ffd24a', 1.4).s,                                               // 미끼
    () => shp().R(10, 9, 12, 20, '#b8c86a', 2.4).R(9, 5, 14, 4.6, '#4a4d56', 1.4).L('M12 15h8M12 19h8', '#5a6a2a', 1.4).C(25, 9, 3, 'rgba(200,220,120,.6)').s,               // 최루탄
    () => shp().C(15, 19.5, 8.6, '#4a5a3a').C(11, 16, 1.4, '#2a3220').C(19, 17, 1.4, '#2a3220').C(15, 23, 1.4, '#2a3220').R(12.4, 7, 5.2, 4.4, '#8a8d92', 1).s,               // 파편
  ];
  const healSVG = [
    () => shp().R(12, 20.6, 17, 4.6, '#f2ece0', 1).C(12, 16, 8.4, '#f2ece0').C(12, 16, 3.2, '#d8cfbf').L('M6 12.6q6-3 12 0', 'rgba(0,0,0,.12)', 1).s,
    () => shp().R(12, 4.6, 8, 4.4, 'none', 1.6).R(3.5, 8, 25, 18, '#f2ece0', 3).P('M13.8 10.6h4.4v4.6h4.6v4.4h-4.6v4.6h-4.4v-4.6H9.2v-4.4h4.6z', '#d9362c').s,
    () => shp().R(12, 4.4, 8, 4.4, 'none', 1.6).R(2.5, 8, 27, 19, '#ff9a3c', 3).R(2.5, 14, 27, 2, '#c96a1c').P('M14 10h4v3.4h3.4v4H18V21h-4v-3.6h-3.4v-4H14z', '#fff').s,
    () => shp().R(10, 11, 12, 18, '#7ec8ff', 2.4).R(9, 5.4, 14, 6, '#f4f4f4', 1.6).R(10, 16, 12, 6.4, '#fff').L('M13 19.2h6', '#3a7ab0', 1.6).s,
    () => shp().R(10, 4, 12, 25, '#7fe07a', 3.4).R(10.6, 3.6, 10.8, 2.6, '#c9ccd2', 1).R(10, 12.4, 12, 6.4, '#202a20').P('M17 13.4l-3 3h2.2l-1.4 2.4 3.4-3.4h-2.2z', '#ffe14a').s,
  ];
  const spcSVG = [
    () => shp().P('M10 4h12l3 6v19H7V10z', '#4a6a2a').C(10, 10, 3, '#6a8a3a').C(20, 8, 3, '#5a7a32').C(14, 17, 3.4, '#7a9a42').C(22, 20, 3, '#5a7a32').C(11, 25, 3, '#6a8a3a').C(19, 27, 2.6, '#7a9a42').s,
    () => shp().P('M8 8q8-6 16 0v10q-8 8-16 0z', '#3a3f45').C(12, 12, 3, '#9fd0ff').C(20, 12, 3, '#9fd0ff').C(16, 21, 4, '#5a5e66').C(16, 21, 2, '#2a2a30').s,
    () => shp().R(4, 12, 24, 9, '#3a4a3a', 3).C(11, 16.5, 3.4, '#5aff7a').C(21, 16.5, 3.4, '#5aff7a').R(13, 6, 6, 6, '#2a3a2a', 1).s,
  ];
  const LVC = ['#777', '#9aa0a8', '#5a9bd6', '#c48be0'];
  const helmSVG = (lv) => shp().P('M5 21a11 11 0 0 1 22 0z', ['', '#8f8a62', '#5b6a48', '#2f353b'][lv]).R(3, 20, 26, 3, ['', '#8f8a62', '#5b6a48', '#2f353b'][lv], 1.4).L('M9 14q3-5 8-5', 'rgba(255,255,255,.3)', 1.4).T(16, 31, lv, LVC[lv]).s;
  const vestSVG = (lv) => shp().P('M8 3h5l3 4 3-4h5l2.4 6.4V26H5.6V9.4z', ['', '#8a8f62', '#4f6340', '#2c3036'][lv]).R(9, 15, 5.4, 5, 'rgba(0,0,0,.25)', 1).R(17.6, 15, 5.4, 5, 'rgba(0,0,0,.25)', 1).T(16, 31.5, lv, LVC[lv]).s;
  const bagSVG = (lv) => shp().L('M11 8q-4 6-1 14M21 8q4 6 1 14', '#3a3226', 1.6).R(8, 6, 16, 21, ['', '#6b5a3a', '#4f5a3a', '#3a3f45'][lv], 5).P('M8.6 9.6q7.4-5.6 14.8 0V14H8.6z', 'rgba(0,0,0,.28)').R(11, 18, 10, 6, 'rgba(0,0,0,.22)', 1.4).T(16, 31.5, lv, LVC[lv]).s;
  const SZT = (A) => (A.cl === '01' ? '권' : A.cl === '45' ? '저' : A.cl === '1' ? 'SMG' : '');
  function attSVG(A) {
    const S = shp(), tag = SZT(A);
    if (A.k === 0) {
      if (A.cant) return S.P('M8 22l8-8 4 4-8 8z', MET2).R(14, 9, 9, 7, MET, 2).C(18.5, 12.5, 2, '#9fd8ff').C(18.5, 12.5, 0.8, '#ff3a3a').s;
      if (A.lv === 1) return S.R(7, 19, 18, 4, MET2, 1).R(9, 9, 14, 10.5, MET, 3).C(16, 14.2, 3.6, '#9fd8ff').C(16, 14.2, 1.2, '#ff3a3a').s;
      if (A.lv === 2) return S.R(6, 19, 20, 4, MET2, 1).R(7, 8, 18, 11, MET, 2).R(9.5, 10, 13, 7, '#9fd8ff', 1).C(16, 13.5, 2.4, 'none').L('M16 11v5M13.5 13.5h5', '#ff3a3a', 0.8).s;
      const L = [0, 0, 0, 12, 15, 18, 21, 24, 27][A.lv], x0 = 16 - L / 2;
      return S.R(x0, 12, L, 7, '#1d1e22', 3).R(x0 - 1, 10.6, 4.4, 9.8, '#2a2b30', 2).R(x0 + L - 3.4, 10, 4.4, 11, '#2a2b30', 2).C(x0 + L + 0.4, 15.5, 2.6, '#6fb8ff').R(13, 19, 2, 3, MET).R(18, 19, 2, 3, MET).T(16, 8.6, SCN[A.lv].replace('배', 'x'), '#ffd23f', 7.5).s;
    }
    if (A.k === 1) {
      const long = A.mg ? 6 : 0;
      S.P('M11 3h8.4l3.4 ' + (18 + long) + 'H14z', MET);
      if (A.rl) S.R(11.4, 9, 10, 2.4, '#d8642a').R(12.2, 14, 10, 2.4, '#d8642a');
      if (A.mg) S.R(13.4, 17 + long - 2, 9.4, 5, '#5a6a8a', 1);
      return S.T(26, 30, tag, '#ffd27a', 6.5).s;
    }
    if (A.k === 2) {
      if (A.sup) S.R(2, 11.6, 28, 8.8, MET, 4).L('M8 11.6v8.8M14 11.6v8.8M20 11.6v8.8', 'rgba(255,255,255,.18)', 1);
      else if (A.fh) S.R(4, 13, 10, 6, MET, 1).L('M14 13l12-2M14 16h13M14 19l12 2', MET, 1.8);
      else if (A.pel && !A.hip) S.P('M4 12h10l12 2v4l-12 2H4z', MET);
      else if (A.pel) S.P('M4 13h10l14-4v14l-14-4H4z', MET);
      else S.R(5, 11, 22, 10, MET, 2).R(9, 12.5, 2, 7, '#121116').R(14, 12.5, 2, 7, '#121116').R(19, 12.5, 2, 7, '#121116');
      return S.T(26, 30, tag, '#ffd27a', 6.5).s;
    }
    if (A.k === 3) {
      S.R(5, 6, 22, 4.6, MET2, 1);
      if (A.lt) return S.R(8, 11, 14, 7, MET, 3).P('M22 11l8-4v18l-8-4z', 'rgba(255,240,160,.8)').s;
      if (A.hip && !A.rc) return S.R(9, 11, 12, 7, MET, 2).L('M21 14.5h10', '#ff3a3a', 1.6).s;
      if (A.ads) return S.P('M12 10.6h9l-4 12h-6z', MET).s;
      if (A.mvs && !A.rc) return S.P('M14 10.6h4.4l-0.4 13h-3.6z', MET).s;
      if (A.rec) return S.P('M13 10.6h7l-1 6h-5z', MET).s;
      if (A.mvs) return S.P('M13 10.6h6.4l-1 10h-4.4z', MET).s;
      return S.P('M13 10.6h6.4l-1 16.4h-4.4z', MET).L('M14.4 15h3.6M14.4 19h3.4M14.6 23h3', 'rgba(255,255,255,.22)', 1).s;
    }
    if (A.rl && !A.rc) return S.R(4, 13, 24, 7, '#5a4a32', 2).R(7, 7, 2.6, 7, '#d8b25a', 1).R(12, 7, 2.6, 7, '#d8b25a', 1).R(17, 7, 2.6, 7, '#d8b25a', 1).R(22, 7, 2.6, 7, '#d8b25a', 1).s;
    if (A.ads) return S.P('M4 14h14v8H6z', MET).R(8, 9, 12, 5, '#4a5a6a', 2).s;
    return S.P('M3 12h12v8H5z', MET).L('M15 14h12M15 19h12', MET2, 1.8).s;
  }
  const ammoSVG = (j) => {
    const A = AMMO[j], S = shp().R(4, 15, 24, 13, '#4a4a3a', 2);
    if (j === 4) { for (const x of [7, 13, 19]) S.R(x, 5, 5, 12, '#c8352f', 1.4).R(x, 13, 5, 4, '#d8b25a'); }
    else if (j === 6) { for (const x of [8, 14, 20]) S.L('M' + (x + 1.5) + ' 18V3', '#c9b89a', 1.6).P('M' + (x + 1.5) + ' 2l-2 3h4z', SIL); }
    else if (j === 9) { for (const x of [7, 17]) S.R(x, 5, 8, 12, '#7a8a4a', 3).R(x, 13, 8, 4, '#d8b25a'); }
    else if (j === 10) return shp().R(3, 13, 20, 6, '#5a6448', 2).P('M23 16l7-4v8z', A.c).P('M3 13l-2-2v10l2-2z', '#3a3f45').s;
    else if (j === 11) { for (const x of [8, 18]) S.R(x, 5, 6, 12, A.c, 2).R(x, 13, 6, 4, '#d8b25a'); }
    else if (j === 8) { for (const x of [8, 18]) S.P('M' + x + ' 16V5q3-4 6 0V16z', A.c).R(x, 12, 6, 4, '#d8b25a'); }
    else for (const x of [7.5, 13.5, 19.5]) S.P('M' + x + ' 16V' + (j === 7 ? 5 : 7.4) + 'q2.5-4 5 0V16z', A.c).R(x, 12, 5, 4, '#d8b25a');
    return S.L('M7 22h18', 'rgba(255,255,255,.2)', 1.2).s;
  };
  /* vehicles (codex / lists), drawn by shape type */
  function vehSVG(i) {
    const V = VEH[i], c = V.col, S = shp(), wh = (x, r) => S.C(x, 23, r || 3.6, '#151515').C(x, 23, 1.4, '#888');
    switch (V.sh) {
      case 'bike': S.L('M6 23L13 14h7l6 9M13 14l-2-4h-3M20 14l2-4', c, V.ped ? 1.6 : 2.4); S.L('M6 18.4a4.6 4.6 0 1 0 .01 0M26 18.4a4.6 4.6 0 1 0 .01 0', '#151515', 1.8); return S.s;
      case 'side': S.R(16, 15, 13, 7, c, 3); S.L('M4 23L10 14h6l4 9', c, 2.2); wh(5); wh(19, 3); wh(27, 3); return S.s;
      case 'van': S.R(2, 9, 28, 13, c, 3).R(22, 11, 6, 5, '#9cc8e0', 1).R(6, 11, 6, 5, '#9cc8e0', 1).R(13, 11, 6, 5, '#9cc8e0', 1); wh(8); wh(24); return S.s;
      case 'pickup': S.R(2, 14, 28, 8, c, 2).R(17, 8, 11, 7, c, 2).R(19, 9.5, 7, 4, '#9cc8e0', 1); wh(8); wh(24); return S.s;
      case 'truck': S.R(1, 7, 20, 15, '#5a6a4a', 1).R(21, 10, 10, 12, c, 2).R(23, 12, 6, 4, '#9cc8e0', 1); wh(6); wh(13); wh(26); return S.s;
      case 'buggy': S.L('M4 18L10 9h11l5 9', '#2a2a30', 1.8).R(4, 15, 24, 5, c, 2); wh(7, 4.4); wh(25, 4.4); return S.s;
      case 'boat': return S.P('M2 16h26l-4 8H6z', c).R(10, 10, 9, 6, '#3a6f9a', 1.4).L('M2 26q7-2.4 14 0t14 0', '#5fb3e6', 1.6).s;
      case 'jetski': return S.P('M3 17h18l9 2-3 5H6z', c).R(12, 12, 6, 5, '#2a2a30', 2).L('M2 27q7-2.4 14 0t14 0', '#5fb3e6', 1.6).s;
      case 'airboat': return S.P('M2 18h22l-3 6H5z', c).C(24, 11, 6, 'none').L('M24 5v12M18 11h12', '#2a2a30', 1.4).R(8, 13, 7, 5, '#3a3f45', 1.4).s;
      case 'tank': return S.R(3, 18, 26, 7, '#2a2a30', 3.4).L('M6 21.5h20', '#555', 2).R(5, 9, 22, 10, c, 3).R(19, 11, 6, 5, '#9cc8e0', 1).s;
      case 'sled': return S.P('M3 23h20q4 0 5-3', '#2a2a30').R(6, 14, 18, 7, c, 3).L('M4 25h22', '#151515', 1.6).L('M22 14l3-5', '#2a2a30', 1.6).s;
      case 'apc': S.R(2, 9, 28, 13, c, 2).R(12, 4, 9, 6, '#4a5040', 1).L('M21 7h9', '#2a2a30', 2); wh(6); wh(13); wh(20); wh(27); return S.s;
      default: S.R(2, 12, 28, 10, c, 2.6).P('M8 12l3-6h9l3 6z', '#9cc8e0'); wh(9, 4); wh(24, 4); return S.s;
    }
  }
  function aniSVG(i) {
    const K = ANI[i], c = K.col, S = shp();
    switch (K.sh) {
      case 'dog': return S.P('M5 18q2-6 10-6h7l4-4 2 2-1 5v3l-2 7h-3l-1-5H12l-2 5H7l1-6z', c).C(26, 10, 0.8, '#121116').s;
      case 'bear': return S.P('M3 22q0-10 12-10h6q6 0 8 5l-1 3-3 1v5h-4l-1-4H11l-1 4H6z', c).C(27, 16, 0.9, '#121116').s;
      case 'cat': return S.P('M3 17q3-5 12-5h8l3-4 2 2v6l-3 2-1 8h-3l-1-6h-7l-1 6H9l-1-7q-4 0-5-2z', c).L('M11 13v6M15 12v7M19 12v7', '#3a2414', 1.2).s;
      case 'croc': return S.P('M2 18q6-5 14-4h8l6 2v2l-6 1h-8q-8 2-14-1z', c).L('M24 17l-6 0', '#121116', 0.8).L('M7 21l-1 3M13 21l-1 3', c, 1.6).s;
      case 'swarm': for (const [x, y] of [[8, 12], [16, 9], [22, 15], [12, 20], [20, 23], [26, 21], [6, 22]]) S.C(x, y, 2.2, c); return S.s;
      case 'boar': return S.P('M3 20q0-9 11-9h8l5 4v4l-4 2v5h-3l-1-4h-8l-1 4H7l-1-5z', c).L('M26 18l3 1', '#f2ece0', 1.4).s;
      case 'snake': return S.L('M3 22q4-8 8 0t8 0 8-10', c, 3.2).C(27, 12, 1.8, c).s;
      case 'lizard': return S.P('M2 17l8-2h10l6-2 4 3-4 2-6-1H10z', c).L('M10 15l-2-4M10 18l-2 4M19 15l2-4M19 18l2 4', c, 1.6).s;
      case 'shark': return S.P('M2 17q10-6 24-1l4-5v12l-4-5q-14 5-24-1z', c).P('M13 13l3-7 3 7z', c).s;
      default: return S.C(16, 16, 8, c).s;
    }
  }
  /* id → svg markup */
  const ICON_C = {};
  function ICON(t) {
    if (ICON_C[t]) return ICON_C[t];
    const k = ikind(t);
    const s = k === 'g' ? gunSVG(t) : k === 'm' ? meleeSVG[t - I_MEL]() : k === 't' ? throwSVG[t - I_THR]() : k === 'h' ? healSVG[t - I_HEAL]()
      : k === 'v' ? vestSVG(t - I_VEST + 1) : k === 'e' ? helmSVG(t - I_HELM + 1) : k === 'b' ? bagSVG(t - I_BAG + 1) : k === 's' ? spcSVG[t - I_SPC]() : k === 'a' ? attSVG(ATT[t - I_ATT]) : ammoSVG(t - I_AMMO);
    return (ICON_C[t] = s);
  }
  /* canvas images of the icons (for drawing loot in the world) */
  const IMG_C = {};
  function iconImg(t) {
    if (typeof Image === 'undefined') return null;
    let im = IMG_C[t];
    if (!im) { im = IMG_C[t] = new Image(); im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(ICON(t)); }
    return im.complete && im.naturalWidth ? im : null;
  }

  /* ======================= 도감 (codex, generated from the tables above) ======================= */
  function codexDef() {
    const MN = { c: '도시 섬', m: '군사기지 섬', d: '사막 섬·간헐천 고원', s: '설원 섬·온천 설산', j: '정글 섬', q: '작은 섬', a: '군도', v: '화산섬', f: '폐공장 도시', w: '늪지' };
    const where = (po) => po === 'B' ? '모든 섬' : po === 'A' ? '보급 상자 전용' : MN[po] + ' 전용';
    const slotsOf = (G) => ASN.map((n, k) => (ATT.some((A, ai) => A.k === k && accepts(GUN.indexOf(G), ai)) ? n : '')).filter(Boolean).join('·') || '없음';
    const gunRow = (i) => {
      const G = GUN[i], C = CLS[G.c], rpm = G.bu ? Math.round(60 * G.bu / (G.cd + 0.07 * (G.bu - 1))) : Math.round(60 / G.cd);
      const feat = [G.bu ? G.bu + '점사' : '', G.n ? '산탄 ' + G.n + '알' : '', G.sup ? '소음기 내장' : '', G.isc ? SCN[G.isc] + ' 조준경 내장' : '', G.ex ? '폭발 반경 ' + G.ex + 'm' : '',
        G.c === 8 ? '쏘아 올린 곳에 보급 상자가 떨어지고 밤엔 주변이 밝아져요' : '', G.heavy ? '무거워서 느리게 걸어요' : '', OH(i) ? '한 손(운전 중 사용)' : ''].filter(Boolean).join(', ');
      return { icon: ICON(i), name: G.nm, tag: C.nm + ' · ' + AMMO[G.am].nm + (G.po !== 'B' ? ' · ' + where(G.po) : ''),
        desc: G.c === 8 ? feat : '피해 ' + G.d + (G.n ? '×' + G.n : '') + (G.mg === 1 ? ' · 한 발씩 장전' : ' · 분당 ' + rpm + '발') + ' · 탄창 ' + G.mg + ' · 장전 ' + G.rl + '초 · 거리 피해: ' + G.er + 'm까지 100% → ' + G.mr + 'm에서 ' + Math.round(CLS[G.c].mf * 100) + '% · 허리 퍼짐 ' + (G.sp * C.hk * (G.c === 3 ? SGK : HIPK) * 57.3).toFixed(1) + '° · 조준 퍼짐 ' + (G.sp * C.ads * (G.c === 3 ? 1 : ADSK) * 57.3).toFixed(2) + '°' + (G.fs < 1 ? ' · 초탄 퍼짐 ×' + G.fs.toFixed(2) : '') + ' · 연사 퍼짐 ' + Math.round(G.rc * BLK * C.bk * 1000) + ' · 부착: ' + slotsOf(G) + (feat ? ' · ' + feat : '') };
    };
    const ids = (f) => GUN.map((G, i) => i).filter((i) => f(GUN[i])).sort((a, b) => GUN[a].c - GUN[b].c || a - b);
    const out = [];
    out.push({ h: '총기(기본)', p: ['모든 섬에서 나오는 총 ' + GUN.filter((G) => G.po === 'B').length + '종. 등급은 없고, 총마다 피해·연사·퍼짐·연사 퍼짐·거리 피해·장전·탄약·부착 칸이 달라요. 유효 사거리까지는 피해 100%, 그 뒤로 최대 사거리까지 곧게 줄어요.',
      '거리에 따른 피해(종류별 기준): ' + CLS.filter((C, c) => c !== 8 && c !== 9).map((C) => C.nm + ' ' + C.er + 'm까지 100%→' + C.mr + 'm ' + Math.round(C.mf * 100) + '%').join(' · ') + ' (총마다 사거리가 조금씩 달라요 — 아래 총별 수치).',
      '반동은 없고 대신 퍼짐이 커요: 허리 사격은 가까이서만 잘 맞고, 조준(ADS)하면 훨씬 모이지만 그래도 퍼져요. 계속 쏘면 한 발마다 더 퍼지고, 멈추면 다시 모여요. 달리면 아주 많이 퍼져요.',
      '헤드샷 배율: ' + CLS.filter((C, c) => c < 8).map((C) => C.nm + ' ×' + C.hd).join(' · ') + '. 조끼/헬멧 1·2·3레벨 = 피해 ' + VRED.slice(1).map((v) => Math.round(v * 100) + '%').join('·') + ' 줄임.'], rows: ids((G) => G.po === 'B').map(gunRow) });
    out.push({ h: '총기(섬별)', p: ['그 섬에서만 나오는 총(섬마다 12종).'].concat(Object.keys(MN).map((k) => MN[k] + ': ' + GUN.filter((G) => G.po === k).map((G) => G.nm).join(', '))),
      rows: Object.keys(MN).reduce((a, k) => a.concat(ids((G) => G.po === k).map(gunRow)), []) });
    out.push({ h: '총기(보급)', p: ['자기장이 줄어들 때 떨어지는 보급 상자(또는 조명탄총으로 부른 상자)에서만 나와요. 강한 대신 전용 탄(.50 BMG·유탄·로켓)이 드물고 무거워요.'], rows: ids((G) => G.po === 'A').map(gunRow) });
    out.push({ h: '부착물', p: ['총마다 조준경·탄창·총구·하부·개머리판 칸이 있고, 맞는 것만 달려요(소지품 화면에서 ✕ = 못 다는 칸). 주우면 맞는 총에 저절로 달려요.'],
      rows: ATT.map((A, i) => ({ icon: ICON(I_ATT + i), name: A.nm, tag: ASN[A.k] + ' · ' + A.cl.split('').map((c) => CLS[+c].nm).filter((n, j, a) => a.indexOf(n) === j).slice(0, 5).join('·'), desc: attText(A) })) });
    out.push({ h: '탄약', p: ['가방 무게: 주머니 ' + BAGCAP[0] + ' · 가방 1~3레벨 ' + BAGCAP.slice(1).join('/') + ' · 조끼 +' + VESTCAP + '. 탄창에 든 총알은 무게가 없어요.'], rows: AMMO.map((A, j) => ({ icon: ICON(I_AMMO + j), name: A.nm, tag: '한 묶음 ' + A.pk + '발 · 한 발 무게 ' + A.wt,
      desc: '쓰는 총 ' + GUN.filter((G) => G.am === j).length + '종: ' + GUN.filter((G) => G.am === j).map((G) => G.nm).slice(0, 14).join(', ') + (GUN.filter((G) => G.am === j).length > 14 ? ' …' : '') })) });
    out.push({ h: '근접', p: ['4번 칸. 휘두를 때마다 스태미나 ' + STM.melee + '을 써요.'], rows: MELEE.map((m, i) => ({ icon: ICON(I_MEL + i), name: m.nm, desc: '피해 ' + m.d + ' · 간격 ' + m.cd + '초 · 거리 ' + m.r + 'm · 휘두르는 폭 ' + Math.round(m.arc * 57) + '°' }))
      .concat([{ icon: fistSVG(), name: FIST.nm, tag: '기본', desc: '피해 ' + FIST.d + ' · 간격 ' + FIST.cd + '초' }]) });
    /* THD: module level (also used by the item tooltips) */
    out.push({ h: '투척', p: ['5번 칸(G, 한 번 더 누르면 종류 바꾸기). 「쏘기」를 누른 채 끌어 겨누고 떼면 던져요.'], rows: THROW.map((T, i) => ({ icon: ICON(I_THR + i), name: T.nm, tag: '무게 ' + T.wt, desc: THD[i] })) });
    out.push({ h: '치료', p: ['「치료」는 지금 상태에 맞는 것을 알아서 골라요(쏘면 취소).'],
      rows: HEAL.map((H, i) => ({ icon: ICON(I_HEAL + i), name: H.nm, tag: H.t + '초 · 무게 ' + H.wt, desc: H.st ? '스태미나 +' + H.st + ' · ' + H.sb + '초 지구력' : H.hp ? '체력 +' + H.hp + ' (' + H.to + '까지)' : '체력 ' + H.to + '까지' })) });
    const arm = [];
    [1, 2, 3].forEach((lv) => {
      arm.push({ icon: ICON(I_HELM + lv - 1), name: '헬멧 ' + lv + '레벨', desc: '머리 피해 ' + Math.round(HRED[lv] * 100) + '% 감소' });
      arm.push({ icon: ICON(I_VEST + lv - 1), name: '조끼 ' + lv + '레벨', desc: '몸 피해 ' + Math.round(VRED[lv] * 100) + '% 감소 · 가방 무게 +' + VESTCAP });
      arm.push({ icon: ICON(I_BAG + lv - 1), name: '가방 ' + lv + '레벨', desc: '들 수 있는 무게 ' + BAGCAP[lv] });
    });
    const SPD = SPCD.map((d) => d.slice(0, -1).join(' '));
    SPC.forEach((S, i) => arm.push({ icon: ICON(I_SPC + i), name: S.nm, tag: '특수(한 개만)', desc: SPD[i] }));
    out.push({ h: '방어구·특수', p: ['3레벨은 보급 상자에 잘 나와요. 특수 장비는 한 번에 하나만 입어요. 자기장·불·물·용암 피해는 못 막아요.'], rows: arm });
    out.push({ h: '탈것', p: ['연료는 없어요. 운전석은 한 손 총만, 옆자리는 모든 총. V = 자리 바꾸기. 진흙에선 느리고(에어보트 빼고), 눈 섬에선 설상차·스노모빌, 사막에선 모래 버기가 빨라요.'],
      rows: VEH.map((V, i) => ({ icon: vehSVG(i), name: V.nm, tag: V.land === 1 ? '땅 위' : V.land === 2 ? '물·땅' : '물 위', desc: '최고 ' + Math.round(V.vmax * (V.ped ? 1.5 : 1) * 3.6) + 'km/h · 가속 ' + V.acc + ' · ' + V.seats + '명 · 내구도 ' + V.hp + (V.ped ? ' · 스태미나로 달려요' : '') + (V.arm ? ' · 타고 있으면 총에 안 맞아요' : '') })) });
    const AW = {}; MAPS.forEach((T) => (T.ani || []).forEach(([k]) => { (AW[k] = AW[k] || []).push(T.nm); }));
    out.push({ h: '동물', p: ['섬마다 사는 동물이 있어요. 가까이 가면 달려들고, 쏘거나 때려서 쫓아낼 수 있어요. 앉아서 다니면 덜 눈치채요.'],
      rows: ANI.map((K, i) => ({ icon: aniSVG(i), name: K.nm, tag: (AW[i] || ['—']).join('·'), desc: '체력 ' + K.hp + ' · 한 번에 ' + K.d + ' 피해 · 빠르기 ' + K.sp + 'm/s · ' + K.ag + 'm 안에 오면 달려들어요' + (K.wet === 2 ? ' · 물속에만 살아요(헤엄치는 사람을 노려요)' : K.wet === 1 ? ' · 물가에 살아요' : '') })) });
    out.push({ h: '섬', p: ['기본은 무작위. 사람이 많을수록 섬이 커져요. 모든 섬에 낮→노을→밤→새벽이 돌아요(밤엔 멀리 안 보이고, 총구 불꽃이 위치를 드러내요).'],
      rows: MAPS.map((T) => ({ icon: '🏝️', name: T.nm, desc: T.note + ' · 전용 총 12종' + (T.gk ? '(' + (MAPS.find((U) => U.k === T.gk) || {}).nm + '과 같음)' : '') })) });
    out.push({ h: '건물·위험', p: [
      '문: 걸어 들어가면 열리고, F로 닫아요. 건물 안에선 ' + LOCK_T + '초 동안 잠글 수 있어요. 창문: F로 넘고, 총알·시야는 지나가요.',
      '레드존: 지도에 빨간 원이 뜨고 10초 뒤 12초 동안 폭격! 지붕 아래(건물 안)는 안전해요.',
      '날씨(판마다 무작위, 설정에서 고정 가능): ☀ 맑음 · 🌧 비(시야 70m, 총소리가 덜 퍼져요) · ❄ 눈보라(시야 30m, 길·건물 밖에선 15% 느려요) · ⛈ 폭풍(시야 55m, ⚡ 원이 1.8초 뒤 번개 40 피해 — 건물 안은 안전, 바람에 탄·투척물이 조금 밀려요).',
      '온천 설산의 온천은 체력을 75까지 초당 2.5씩 채워요. 간헐천 고원의 물기둥은 15초마다 부글부글(2초) 끓다가 터져요(30 피해, 튕겨 나감, 차도 망가져요).',
      '화산섬 용암은 초당 18 피해, 폐공장은 경고 원 뒤에 천장이 떨어져요(55), 사막 모래폭풍 땐 20m만 보여요, 늪지 진흙에선 느려져요.',
    ], rows: [] });
    const tagSvg = '<svg viewBox="0 0 32 32"><rect x="10" y="5" width="12" height="22" rx="5" fill="#e8d27a" stroke="#121116"/><circle cx="16" cy="9.5" r="1.6" fill="#121116"/><rect x="12.5" y="14" width="7" height="1.6" fill="#121116"/><rect x="12.5" y="18" width="5" height="1.6" fill="#121116"/></svg>';
    const towSvg = '<svg viewBox="0 0 32 32"><path d="M16 4 25 28H7z" fill="none" stroke="#c9d2da" stroke-width="2"/><path d="M11 18h10M9 23h14" stroke="#c9d2da" stroke-width="1.6"/><circle cx="16" cy="6" r="3" fill="#7fe0ff" stroke="#121116"/><path d="M21 3a7 7 0 0 1 0 8M11 3a7 7 0 0 0 0 8" fill="none" stroke="#7fe0ff" stroke-width="1.5"/></svg>';
    out.push({ h: '팀·귀환', p: ['2인 팀·4인 스쿼드에서만 쓰여요. 자기장 ' + 3 + '단계가 시작되기 전까지(작은 섬은 2단계) 쓰러진 팀원을 다시 부를 수 있어요.'], rows: [
      { icon: tagSvg, name: '인식표', tag: '팀원이 탈락한 자리', desc: '팀원이 탈락하면 그 자리에 떨어져요(' + RC.tag + '초 동안). 팀원이 밟으면 주워요. 든 사람이 쓰러져 탈락하면 다시 떨어져요.' },
      { icon: towSvg, name: '귀환 송신탑', tag: '섬마다 4~8곳', desc: '지도에 하늘색 ▲. 인식표를 들고 ' + RC.r + 'm 안에서 「📡 귀환 호출」 — ' + RC.ch + '초 동안 가만히. 움직이거나 쏘거나 맞으면 끊겨요. 1초마다 삐 소리가 나서 근처(' + RC.hear + 'm) 적에게 들려요.' },
      { icon: ICON(GUN.findIndex((G) => G.nm === 'P92')), name: '귀환 장비', tag: '돌아온 팀원', desc: '탑 옆에 낙하산으로 내려와요(내려오는 동안은 안 맞아요). 체력 100 · P92 권총 + 9mm 30발 · 붕대 2개 · 조끼 1레벨.' },
    ] });
    return out;
  }
  function attText(A) {
    const f = [];
    if (A.lv) f.push('조준 시야 ' + SIGHT[A.lv] + 'm · 화면 ' + SCZ[A.lv] + '배 넓게');
    if (A.cant) f.push('조준 중 퍼짐 −15%');
    if (A.rc) f.push('연사 퍼짐 −' + Math.round((1 - A.rc) * 100) + '%');
    if (A.ads && !A.cant) f.push('조준 퍼짐 −' + Math.round((1 - A.ads) * 100) + '%');
    if (A.hip) f.push('지향 사격 퍼짐 −' + Math.round((1 - A.hip) * 100) + '%');
    if (A.mvs) f.push('움직이며 쏠 때 퍼짐 −' + Math.round((1 - A.mvs) * 100) + '%');
    if (A.rec) f.push('퍼짐 회복 +' + Math.round((A.rec - 1) * 100) + '%');
    if (A.mg) f.push('탄창 +' + Math.round((A.mg - 1) * 100) + '%');
    if (A.rl) f.push('장전 −' + Math.round((1 - A.rl) * 100) + '%');
    if (A.pel) f.push('산탄 퍼짐 −' + Math.round((1 - A.pel) * 100) + '%');
    if (A.sup) f.push('총소리 들리는 거리 90→25m, 위치 안 들킴, 밤에 불꽃 없음');
    if (A.fh) f.push('밤에 총구 불꽃이 안 보여요');
    if (A.lt) f.push('밤에 앞 42m를 좁고 길게 비춰요(대신 나도 눈에 띄어요)');
    return f.join(' · ') + ' · 무게 ' + A.wt;
  }

  L.register({
    id: 'royale', name: '아일랜드 배틀로얄', tag: '실총 배틀로얄', cat: '아케이드',
    blurb: '최대 50명이 섬 곳곳에서 시작해 총·탄약·방어구를 골라 줍고 싸워요. 파란 자기장은 점점 줄어들고, 마지막까지 살아남은 사람(팀)이 우승! 문·창문·시야, 달리기·앉기, 가방 정리, 지도 핑, 차·오토바이·보트·자전거. (한 폰에 한 명, 빈자리는 AI)',
    tint: '#2a4a3a',
    icon: '<circle cx="28" cy="28" r="20" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="5 4"/><path d="M14 30h20l3-3h6v4h-4l-2 3H22l-2 5h-5l2-5h-3z" fill="currentColor"/><circle cx="28" cy="28" r="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M28 6v8M28 42v8M6 28h8M42 28h8" stroke="currentColor" stroke-width="2.5"/>',
    minPlayers: 1, maxPlayers: 50, defaultPlayers: 24, hidden: false, realtime: true, aiDelay: 0, landscape: true, pcOnly: true,
    maxPlayersIf: (o) => (o && o.mode === 'practice' ? 1 : 50),
    options: [
      { id: 'mode', label: '방식', tip: '누구와 싸울지.', choices: [{ v: 'solo', label: '솔로', tip: '혼자서 마지막 1명이 될 때까지.' }, { v: 'duo', label: '2인 팀', tip: '2명이 한 팀.' }, { v: 'squad', label: '4인 스쿼드', tip: '4명이 한 팀.' }, { v: 'range', label: '사격장(혼자 연습)', tip: '표적으로 사격만 연습.' }, { v: 'practice', label: '연습장(혼자 · 모든 도구)', tip: '모든 무기·도구를 써 보는 연습장.' }], def: 'solo' },
      { id: 'map', label: '섬', choices: [{ v: -1, label: '무작위' }].concat(MAPS.map((m, i) => ({ v: i, label: m.nm }))), def: -1 },
      { id: 'weather', label: '날씨', choices: [{ v: -1, label: '무작위' }, { v: 0, label: '맑음' }, { v: 1, label: '비' }, { v: 2, label: '눈보라' }, { v: 3, label: '폭풍' }], def: -1 },
      { id: 'fill', label: '빈자리', tip: '사람이 적으면 AI로 채워 판을 키워요.', choices: [{ v: 'yes', label: '8명 미만이면 AI로 채우기' }, { v: 'no', label: '안 채우기' }], def: 'yes' },
      { id: 'auto', label: '자동 줍기', tip: '물건 위를 지날 때 자동으로 주울지.', choices: [{ v: 'off', label: '끄기(목록에서 골라 줍기)' }, { v: 'on', label: '켜기(더 좋은 것만)' }], def: 'off' },
      { id: 'gore', label: '피 효과', tip: '피격 효과 표현 정도.', choices: [{ v: 'on', label: '켜기' }, { v: 'low', label: '줄이기' }], def: 'on' },
      { id: 'dmg', label: '피해 숫자', choices: [{ v: 'on', label: '보이기' }, { v: 'off', label: '숨기기' }], def: 'on' },
    ],
    controls: [
      { id: 'up', label: '위로 이동', keys: ['KeyW', 'ArrowUp'], pad: ['up', 'ly-'] },
      { id: 'down', label: '아래로 이동', keys: ['KeyS', 'ArrowDown'], pad: ['down', 'ly+'] },
      { id: 'left', label: '왼쪽으로 이동', keys: ['KeyA', 'ArrowLeft'], pad: ['left', 'lx-'] },
      { id: 'right', label: '오른쪽으로 이동', keys: ['KeyD', 'ArrowRight'], pad: ['right', 'lx+'] },
      { id: 'sprint', label: '달리기 (기본: 누르고 있기 · 「⋯」에서 켜고 끄기로)', keys: ['ShiftLeft', 'ShiftRight'], pad: ['ls'] },
      { id: 'crouch', label: '앉기 (기본: 누르고 있기 · 「⋯」에서 켜고 끄기로)', keys: ['KeyC', 'ControlLeft'], pad: ['b'] },
      { id: 'fire', label: '쏘기 (마우스 왼쪽도)', keys: ['KeyJ'], pad: ['rt'] },
      { id: 'ads', label: '조준경 켜기/끄기 (마우스 오른쪽도)', keys: ['KeyX'], pad: ['lt'] },
      { id: 'reload', label: '장전', keys: ['KeyR'], pad: ['x'] },
      { id: 'open', label: '시체·상자 열기 / 고른 물건 줍기', keys: ['KeyF'], pad: [] },
      { id: 'door', label: '문 열기·닫기', keys: ['KeyE'], pad: [] },
      { id: 'vault', label: '창문 넘기', keys: ['Space'], pad: [] },
      { id: 'ride', label: '타기 / 내리기', keys: ['KeyG'], pad: [] },
      { id: 'padUse', label: '행동 (패드: 상자·줍기·문·창문·타기·살리기 중 가까운 것)', keys: [], pad: ['a'] },
      { id: 'inv', label: '소지품(인벤토리)', keys: ['Tab', 'KeyI'], pad: ['y'] },
      { id: 'map', label: '큰 지도', keys: ['KeyM'], pad: ['back'] },
      { id: 'ping', label: '핑 (마우스 가리킨 곳)', keys: ['KeyZ'], pad: ['rs'] },
      { id: 'heal', label: '치료 (알맞은 것 자동)', keys: ['KeyH'], pad: [] },
      { id: 'slot1', label: '1번 주무기', keys: ['Digit1'], pad: [] },
      { id: 'slot2', label: '2번 주무기', keys: ['Digit2'], pad: [] },
      { id: 'slot3', label: '권총', keys: ['Digit3'], pad: [] },
      { id: 'slot4', label: '근접 무기', keys: ['Digit4'], pad: [] },
      { id: 'slot5', label: '투척 무기 (한 번 더 = 종류 바꾸기)', keys: ['Digit5'], pad: ['lb'] },
      { id: 'nextw', label: '다음 무기 (휠도)', keys: ['KeyQ'], pad: ['rb'] },
      { id: 'seat', label: '차 자리 바꾸기', keys: ['KeyB'], pad: [] },
      { id: 'lock', label: '문 잠그기 (건물 안에서)', keys: ['KeyL'], pad: [] },
      { id: 'keys', label: '키 안내', keys: ['KeyK'], pad: [] },
      { id: 'aimL', label: '조준 왼쪽 (패드)', keys: ['Numpad4'], pad: ['rx-'] },
      { id: 'aimR', label: '조준 오른쪽 (패드)', keys: ['Numpad6'], pad: ['rx+'] },
      { id: 'aimU', label: '조준 위 (패드)', keys: ['Numpad8'], pad: ['ry-'] },
      { id: 'aimD', label: '조준 아래 (패드)', keys: ['Numpad5', 'Numpad2'], pad: ['ry+'] },
      { id: 'next', label: '관전: 다른 사람 보기', keys: ['KeyN'], pad: ['start'] },
    ],
    quick: [
      '섬 곳곳에 흩어져 시작해요. 「🎒 줍기」·소지품 화면에서 총·탄약·방어구·치료제를 골라 주워요.',
      '「쏘기」는 바라보는 쪽으로 쏴요(자동 조준 없음). 동그라미가 클수록 탄이 퍼져요 — 달리면 아주 크고, 앉아서 멈추면 가장 작아요.',
      '파란 자기장 밖은 아파요. 흰 원 안으로 옮기며 마지막까지 살아남으면 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '최대 50명이 섬에 내려 싸우는 배틀로얄이에요(기본 24명). 사람이 모자라면 AI가 채워요. 사람이 많을수록 섬이 커지고 자기장도 길어져요.',
        '체력은 100. 총에 맞으면 줄고, 0이 되면 탈락해요. 마지막까지 남은 사람(팀전이면 팀)이 우승! 끝나면 내 기록(피해·처치·명중률·헤드샷·이동 거리·생존 시간·쓴 무기, 팀전은 부활시킨 수)이 나와요.',
        '도감은 📖 도감 버튼에서 — 모든 총·탄약·아이템·탈것의 수치가 정리되어 있어요.',
      ] },
      { h: '시작', p: [
        '비행기·낙하는 없어요. 모두 첫 자기장 안의 땅 위 무작위 자리에서, 서로 떨어져 시작해요(물 위에는 안 나와요). 팀전이면 팀원끼리는 가까이, 팀끼리는 멀리 떨어져 시작해요.',
        '처음 3초는 「3·2·1 시작!」 — 둘러볼 수만 있고 움직일 수 없어요. AI는 처음 20초 동안 먼저 싸움을 걸지 않고(맞으면 반격), 동물은 30초 동안 잠자고 사람 시작 자리 40m 안에는 없어요.',
        '사격장은 늘 같은 자리에서 시작해요.',
      ] },
      { h: '조작 (폰 · 가로 화면)', p: [
        '왼쪽 아래: 화면을 누른 곳이 조이스틱 중심 — 끌면 그 방향으로 걸어요. 오른쪽 아래: 「쏘기」·「조준」·「장전」·「앉기」·「치료」·「달리기」. 위쪽: 체력·스태미나·생존 수·무기 칸 1~5·미니맵.',
        '「⋯」 → 「🎚 감도」에서 조준 끌기·마우스·패드·이동 조이스틱 감도를 0.3~2배로 바꿀 수 있어요(이 기기에 저장).',
        '「달리기」는 누르고 있는 동안 달려요. 「⋯」에서 「눌러서 켜고 끄기」나 「조이스틱 끝까지 밀기」로 바꿀 수 있어요. 스태미나가 있어야 달려요.',
        '「쏘기」는 지금 바라보는 쪽으로 쏴요(자동 조준 없음). 누른 채 끌면 그 방향으로 조준, 화면 오른쪽 빈 곳을 누르면 그쪽으로 돌아서 쏴요. 투척은 끌어서 겨누고 떼면 던져요.',
        '바라보는 방향: 평소에는 걷는 방향, 쏘거나 조준경을 켜면 조준한 방향을 유지하고, 멈추고 1초쯤 지나면 다시 걷는 방향으로 돌아가요. 서 있으면 마지막 방향 그대로, 차에서는 차가 가는 쪽.',
        '오른쪽 가운데에 그때 쓸 수 있는 버튼만 따로 떠요: 🚗 타기/내리기 · 🚪 문 열기/닫기(건물 안에서 길게 누르면 잠그기) · 🪟 창문 넘기 · 💀 시체·상자 열기 · 🩹 살리기 · 📡 귀환 호출.',
        '아래 가운데 「🎒 줍기」 막대: 지금 고른 물건 이름이 나와요. ‹ › 로 겹친 물건 중에서 고르고, 이름을 누르면 주변 목록(소지품 화면)이 열려요.',
        '🎒 = 소지품, 「⋯」 = 지도·달리기 방식, 미니맵을 눌러도 큰 지도. 미니맵 옆 「핑」 = 팀에게 위치·적·물건 알리기.',
      ] },
      { h: '조작 (PC)', p: [
        'WASD 이동 · 마우스로 바라보기·조준 · 왼쪽 클릭 쏘기 · 오른쪽 클릭 조준경 · Shift 누르고 있으면 달리기 · C 누르고 있으면 앉기(「⋯」에서 켜고 끄기로 바꿀 수 있어요).',
        'F 시체·상자 열기(가까이 없으면 고른 바닥 물건 줍기) · E 문 열기/닫기 · L 문 잠그기 · Space 창문 넘기 · G 타기/내리기 · R 장전 · Tab 소지품 · H 치료 · M 지도 · Z 핑 · 1~5 무기 · B 차 자리 바꾸기 · K 키 안내.',
        '조준경은 오른쪽 버튼을 누르고 있는 동안 켜져요(「⋯」에서 눌러서 켜고 끄기로 바꿀 수 있어요). 화면의 십자선이 마우스 자리예요.',
        '휠: 바닥에 물건이 여러 개 겹쳐 있으면 F로 주울 물건을 고르고(노란 테두리), 아니면 무기를 바꿔요.',
        '키는 「⌨ 조작 설정」에서 바꿔요. 게임패드도 돼요(왼쪽 스틱 이동, 오른쪽 스틱 바라보기·조준 — 놓으면 걷는 방향, RT 쏘기, A 가까운 행동).',
      ] },
      { h: '줍기와 소지품', p: [
        '물건 근처(' + PICK_R + 'm)에 가면 「🎒 줍기」 막대가 떠요. PC는 마우스를 올린 물건이 테두리로 표시되고 F로 그것을 주워요(마우스 아래 물건이 없으면 가장 가까운 것). 겹쳐 있으면 ‹ ›(PC는 휠)로 골라요. 물건 설명은 소지품 화면에서 마우스를 올리면 나와요. ▲·초록 = 지금 나에게 더 좋은 것.',
        '소지품 화면(🎒 / Tab)은 세 칸이에요: 「주변」(가까운 바닥 물건 + 연 시체·보급 상자 안) · 「가방」(탄약·치료제·투척·남는 부착물, 무게) · 「장비」(무기 1~5와 총마다 부착 칸, 헬멧·조끼·가방·특수 장비).',
        '빠르게: 「주변」 물건을 두 번 누르면(더블클릭) 바로 줍기 · 가방·장비 물건을 오른쪽 클릭하면 바로 버리기.',
        '끌어서 옮겨요(폰은 길게 눌러 끌기): 주변 → 가방/장비 = 줍기 · 가방/장비 → 주변이나 화면 밖 = 버리기 · 부착물 → 맞는 총 = 달기 · 1번 총 ↔ 2번 총 = 자리 바꾸기. 여러 개 쌓인 것은 몇 개 옮길지 물어봐요. 짧게 누르면 장착·줍기·버리기 버튼이 나와요.',
        '소지품 화면을 연 채로도 게임은 계속되고, 왼쪽 조이스틱으로 걸을 수 있어요.',
        '「자동 줍기」 옵션을 켜면 더 좋은 것만 밟아서 저절로 주워요(기본은 꺼짐).',
        '가방에는 무게 한도가 있어요: 주머니 ' + BAGCAP[0] + ' · 가방 1~3레벨 ' + BAGCAP.slice(1).join('/') + ' · 조끼를 입으면 +' + VESTCAP + '. 탄약·치료제·투척·남는 부착물이 무게를 차지해요.',
      ] },
      { h: '스태미나(초록 막대)', p: [
        '달리기·수영·자전거 페달·근접 공격에 써요. 쉬면 다시 차요. 다 쓰면 잠깐 숨을 골라야 다시 달릴 수 있어요.',
        '물에서는 느리게 헤엄치고 총을 못 써요. 스태미나가 바닥나면 체력이 줄어요(익사)!',
        '에너지 드링크·진통제는 스태미나를 채우고 잠시 「지구력」(덜 지치고 빨리 회복)을 줘요.',
      ] },
      { h: '총 쏘기와 퍼짐', p: [
        '조준 동그라미가 지금 탄이 퍼지는 범위예요. 서서 쏘기보다 걸으면 더, 달리면(달리다 막 멈춘 직후도) 아주 크게 퍼져요. 앉아서 멈추면 가장 작고, 조준경을 켜면 작아져요. 계속 쏘면 반동으로 커져요(손잡이로 줄여요). 멈췄다 쏘는 첫 발(초탄)은 더 잘 모여요 — 저격·지정사수·돌격소총은 특히 그래서 끊어 쏘기가 좋아요. 기관단총·권총은 허리 사격이 덜 퍼져 가까이서 강해요.',
        '운전석에서는 한 손 총(권총·Micro Uzi·MP5K·Vector)만 쏠 수 있고, 달리는 중엔 많이 퍼져요. 옆자리는 모든 총을 쓰지만 달리면 더 퍼져요.',
        '근거리는 산탄총·기관단총, 중거리는 돌격소총, 먼 거리는 지정사수·저격총(조준경 필수). 멀수록 피해가 줄고, 머리에 맞으면 더 아파요(헤드샷). 앉으면 몸이 작아져 덜 맞아요.',
      ] },
      { h: '시야·건물·소리', p: [
        '시야는 바라보는 쪽 부채꼴(약 110°)과 내 둘레 ' + VIS_NEAR + 'm예요. 시야 밖과 벽 너머는 어둡고, 적은 시야 안에서만 보여요 — 뒤에서 다가오는 적은 소리 표시로 알아채요. 배율이 높은 조준경일수록 시야가 좁고 길어져요(8배 ≈ 40°). AI도 똑같은 시야라서 뒤로 돌아가면 기습할 수 있어요.',
        '시야 안의 나무 그늘·지붕은 투명해져서 아래가 보여요.',
        '문(갈색)은 걸어 들어가면 열리고, 「🚪 문 닫기」(PC E)로 닫아요. 닫힌 문은 총알과 시야를 막아요. 건물 안에서는 ' + LOCK_T + '초 동안 문을 잠글 수 있어요(다시 쓰려면 ' + LOCK_CD + '초).',
        '창문(하늘색)은 총알·시야는 지나가고 몸은 못 지나가요. 가까이서 「🪟 창문 넘기」(PC Space).',
        '덤불 속은 가까이 오지 않으면 안 보여요(앉으면 더 잘 숨어요). 소음기 없이 쏘면 잠깐 들켜요.',
        '시야 밖의 소리는 내 캐릭터 둘레에 방향으로 표시돼요: 빨간 별 = 총소리, 주황 = 폭발, 발자국 = 근처 발소리(달리면 크게, 앉으면 작게), 파란 차 = 엔진 소리.',
      ] },
      { h: '자기장·보급 상자', p: [
        '파란 바깥은 자기장이에요. 있으면 체력이 계속 줄고 뒤로 갈수록 더 아파요. 흰 점선 원이 다음 안전 구역이에요.',
        '자기장이 줄어들기 시작할 때 비행기가 보급 상자를 떨어뜨려요(지도의 빨간 점, 빨간 연기). 밟으면 열리고, 귀한 총과 3레벨 방어구가 들어 있어요.',
        '한 판은 8명이면 5~8분, 24명이면 7~10분, 50명이면 10~15분쯤이에요. 작은 섬(빠른 판)은 더 빨리 끝나요.',
      ] },
      { h: '팀전 (2인·4인 스쿼드)', p: [
        '사람이 2명 이상이면 시작 전에 「팀 편성」 화면이 떠요. 각자 들어갈 팀을 누르고(다시 누르면 취소), 방장은 「🎲 무작위 편성」·「👥 사람끼리 모으기」·「▶ 시작」을 쓸 수 있어요. 45초가 지나면 저절로 시작하고, 안 고른 사람은 자리가 남는 팀에 무작위로 들어가요. 빈자리는 AI가 채워요.',
        '팀원끼리는 가까이서 시작하고, 총에 안 맞고, 지도와 화면에 서로 보여요. 화면 밖 팀원은 가장자리 화살표(팀원 색 · 거리)로 보여요: ✚ = 기절, 🏷 = 탈락(인식표 자리).',
        '체력이 0이 되면 바로 탈락이 아니라 「기절」해요. 기어 다닐 수 있지만 피가 계속 줄어요. 팀원이 옆에서 「🩹 살리기」(5초, PC F)를 하면 다시 일어나요. 팀이 모두 쓰러지면 탈락.',
        '지도에 마커를 찍거나 「핑」으로 위치·적·물건을 알리면 팀원 화면과 지도에 보여요.',
      ] },
      { h: '귀환 (팀전)', p: [
        '팀원이 탈락하면 그 자리에 「인식표」가 떨어져요(' + RC.tag + '초). 팀원이 밟으면 주워요.',
        '인식표를 들고 지도의 하늘색 ▲ 「귀환 송신탑」(섬마다 여러 곳)에 가서 「📡 귀환 호출」(PC F)을 누르고 ' + RC.ch + '초 버티면, 팀원이 탑 옆에 낙하산으로 돌아와요(권총·탄 30발·붕대 2·조끼 1레벨).',
        '송신 중엔 움직이거나 쏘거나 맞으면 끊겨요. 1초마다 삐 소리가 나서 근처 적도 들어요 — 주변을 먼저 살피세요.',
        '자기장 3단계(작은 섬은 2단계)부터는 귀환이 닫혀요. AI 팀원도 자주 인식표를 주워 데려와요.',
      ] },
      { h: '총 (196종)', p: [
        '기본 60종(모든 섬) · 섬마다 12종(그 섬에서만) · 보급 16종(보급 상자·조명탄총). 등급은 없고 총마다 피해·연사·퍼짐·연사 퍼짐·거리 피해·장전·탄약·부착 칸이 달라요. 목록과 수치는 📖 도감에.',
        '부착물(배틀그라운드식): 조준경(레드닷·홀로·2~15배·캔티드) · 탄창(대용량·퀵드로우) · 총구(보정기·소염기·소음기·초크·덕빌) · 하부(손잡이 5종·레이저·손전등) · 개머리판. 권총/소총/저격용이 따로 있어요.',
        'Flare Gun(조명탄총)을 쏘면 떨어진 곳에 보급 상자가 와요.',
      ] },
      { h: '탈것', p: [
        '자전거·스쿠터·오토바이·사이드카·승용차·지프·미니밴·픽업트럭·트럭·버기는 모든 섬에 있어요. 섬마다 보트·수상 오토바이(물), 에어보트(늪지), 설상차·스노모빌(설원), 모래 버기(사막), 드물게 장갑차(군사기지).',
        '가까이 가서 「🚗 타기」(PC G). 왼쪽 스틱을 가고 싶은 방향으로 끌면 그쪽으로 돌면서 달려요. 연료는 없어요. 자전거는 내 스태미나로 달려요(달리기 = 세게 밟기). PC B = 자리 바꾸기.',
        '운전: 스틱을 놓으면 서서히 멈추고, 빠를 때 크게 꺾으면 뒤가 살짝 미끄러져요. 「달리기」(PC Shift)를 누른 채 꺾으면 핸드브레이크 드리프트. 벽에 비스듬히 닿으면 긁으며 미끄러지고, 세게 박으면 차가 상해요.',
        '차 위에서 쏘기: 운전자는 한 손 총(권총·작은 기관단총)만, 흔들려서 잘 안 맞아요. 동승자는 모든 총을 쏠 수 있어요(달리는 중엔 조금 퍼짐).',
        '차에 탄 사람 맞히기: 총알은 차에 맞고, 몸이 드러난 만큼 탄 사람에게 가요 — 자전거·오토바이·수상 오토바이·스노모빌 90%, 보트·버기·사이드카·에어보트 60%, 지붕 있는 차 45%, 장갑차 0%.',
        '차 체력이 반 아래면 연기, 15% 아래면 불이 붙어 몇 초 뒤 폭발해요(타고 있으면 같이 다쳐요). 폭발한 차는 잔해로 남아요.',
      ] },
      { h: '섬 (10곳)', p: [
        '도시 섬 · 군사기지 섬 · 사막 섬(가끔 모래폭풍) · 설원 섬(발자국, 얼음 호수) · 정글 섬(강, 덤불) · 작은 섬(빠른 판) · 군도(섬 사이 물길) · 화산섬(용암은 뜨겁고 화산재로 멀리 안 보여요) · 폐공장 도시(큰 공장, 천장이 무너져요) · 늪지(진흙에서 느려지고 안개) · 온천 설산(온천에서 체력 회복) · 간헐천 고원(끓다가 터지는 물기둥). 기본은 무작위.',
      ] },
      { h: '낮과 밤', p: [
        '모든 섬에 낮 → 노을 → 밤 → 새벽이 돌아요(한 바퀴 약 4~5분). 밤에는 시야 부채꼴이 짧아져 13~16m쯤만 보여요.',
        '밤에 소음기·소염기 없이 쏘면 총구 불꽃으로 멀리서도 보여요. 손전등(하부 부착물)은 좁고 긴 빛(42m), 차 전조등은 앞쪽, 조명탄은 둘레를 밝히지만 나도 눈에 띄어요. 야간 투시경을 쓰면 시야 부채꼴 전체가 밝아져 40m까지 보여요.',
      ] },
      { h: '날씨', p: [
        '판마다 날씨가 무작위로 정해져요(설정 「날씨」에서 고를 수도 있어요). 착륙할 때 알려 주고, 왼쪽 위 시간 옆에 표시돼요.',
        '🌧 비: 조금 덜 보이고 총소리가 덜 퍼져요. ❄ 눈보라: 30m만 보이고 길·건물 밖 눈밭에선 느려져요. ⛈ 폭풍: 노란 ⚡ 원이 뜨면 곧 번개가 떨어져요(40 피해, 건물 안은 안전). 바람 때문에 탄과 투척물이 살짝 밀려요.',
      ] },
      { h: '동물·레드존', p: [
        '섬마다 동물이 살아요(들개·늑대·북극곰·호랑이·악어·전갈 떼·멧돼지·독사·용암 도마뱀·쥐 떼·상어·코요테). 가까이 가면 달려드니 쏘거나 때려서 쫓아내요. 앉아서 다니면 덜 들켜요.',
        '레드존: 지도에 빨간 원이 뜨고 10초 뒤 12초 동안 폭격해요. 건물 안(지붕 아래)은 안전해요.',
      ] },
      { h: '사격장', p: [
        '방식에서 「사격장(혼자 연습)」을 고르면 혼자 들어가요. 왼쪽 「총 고르기」로 아무 총이나, 「부착물」로 맞는 부착물을 바로 달고 떼 봐요. 탄약은 끝없어요.',
        '앞쪽 10~120m에 표적이 있고(몇 개는 움직여요), 맞히면 피해 숫자가 떠요. 「밤↔낮」으로 밤 사격·손전등도 시험해 봐요. 나가려면 위의 ‹ 버튼.',
      ] },
      { h: '연습장', p: [
        '방식 「연습장(혼자 · 모든 도구)」: 사격장의 모든 것(아무 총·부착물·끝없는 탄약·밤↔낮·표적 초기화)에 「🧰 연습 도구」가 더해져요. 점수·기록은 남지 않아요.',
        '연습 도구: 무한 체력 · 즉시 재장전 · 표적 움직이기(끄면 가만히) · 표적 반격(표적이 나를 쏨) 켜고 끄기, 「🎒 모두 채우기」(투척물·회복템·3레벨 장비), 땅 탈것 아무거나 꺼내기(최대 6대), 「🏁 끝내기」.',
        '화면 위에 DPS(최근 5초 초당 피해)·누적 피해·명중률·머리 맞힘과 조작 안내가 보여요. 「🎯 초기화」로 숫자도 처음부터.',
      ] },
      { h: '예시', p: [
        '바닥에 M416과 5.56mm 탄약이 겹쳐 있다면 → 「🎒 줍기」 막대의 ‹ › 로 M416을 골라 줍고, 탄약도 골라 주워요. 확장 탄창을 주우면 M416에 저절로 달려요(소지품 화면에서 다른 총으로 끌어 옮길 수도 있어요).',
        '체력 40에 적이 안 보인다면 → 건물에 들어가 문을 닫고(급하면 🔒 잠그기) 앉아서 「치료」(구급상자로 75까지), 그다음 흰 원 쪽으로 달려요.',
      ] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움. 쉬움은 반응이 늦고 조준이 엉성해요. 보통은 숨고 치료하고 앉아서 쏘고, 문을 닫고 차도 타요. 어려움은 빠르고 정확하며 수류탄·연막·저격 조준경을 잘 쓰고, 문을 잠그고 자기장에 미리 들어가요.',
        'AI는 판마다 성향도 무작위예요(난이도와 따로): 돌격형 · 신중형 · 저격형 · 캠핑형 · 유랑형. 관전할 때 성향이 보여요.',
      ] },
    ],
    codex: codexDef(),
    init, actor: () => null, apply() { throw new Error('realtime game: no turn actions'); }, ai: () => null, result, mount,
    _t: { init, newWorld, tickWorld, stepWorld, aiThink, getMap, MAPS, GUN, AID, HL, swapCand, ctxOf, finish, result, encodeW, invOf, setInv, ikind, iname, I_AMMO, I_HEAL, I_ATT, I_GUN, I_BAG,
      doAct, pickOne, visFan, inPoly, VIS_N, isWater, solidAt, inBld, nearWin, stepVehicles, rayStatic, tryTake, wtOf, capOf, spreadOf, CLS, fallOf, statsOf, interact, mkGun, los, ATT, HEAL, VEH, ANI, THROW, MELEE },
  });
})();
