/* 협동 작전 부대 (strikeforce) — PC 전용 위에서 보는 실시간 협동 사격 게임.
   1–4명(빈자리는 AI 대원). 행성에 내려 목표를 끝내고 표본을 모아 시간 안에 탈출. 지원 요청(방향키 암호)으로 궤도 포격·폭격·포탑·지원 화기·보행기·증원.
   아군 사격 켜짐. 은하 전선(행성 해방 %)은 이 판(저장) 안에서만 이어진다 — 판 밖 영구 성장 없음.
   구조: 큰 흐름(장비 고르기·작전 결과·전선)은 api.setState 상태(st), 전투 세계(W)는 호스트에서만 시뮬하고 hostSend로 스냅샷. */
(function () {
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2, hyp = Math.hypot, clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const fin = Number.isFinite, r1 = (v) => Math.round(v * 10) / 10, r2 = (v) => Math.round(v * 100) / 100;
  const wrapA = (a) => { while (a > Math.PI) a -= TAU; while (a < -Math.PI) a += TAU; return a; };
  const DT = 1 / 30, MS = 64, NP = 4;
  function rng(seed) { let a = (seed >>> 0) || 1; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

  /* ================= 자료 ================= */
  // 무기: dmg 피해, ap 관통(1 경·2 중·3 중장·4~5 대전차), iv 발사 간격(초), mag 탄창, rsv 예비탄, sp 퍼짐, rc 반동, rl 장전, rg 사거리, kn 밀어냄, pel 산탄 수, pj 투사체(속도), ex 폭발 반경
  const PRI = [
    { id: 'ar', nm: '파수꾼 돌격소총', tag: '돌격소총', ic: '🔫', dmg: 22, ap: 2, iv: 0.1, mag: 30, rsv: 210, sp: 0.05, rc: 0.04, rl: 2.0, rg: 24, kn: 0.5, d: '무난한 연사 소총. 중장갑(경장갑 2)까지 뚫어요.' },
    { id: 'sg', nm: '벼락 산탄총', tag: '산탄총', ic: '💥', dmg: 13, ap: 1, iv: 0.7, mag: 8, rsv: 56, sp: 0.17, rc: 0.16, rl: 2.6, rg: 13, kn: 1.4, pel: 9, d: '가까이선 최강. 9발이 퍼져 나가요. 멀면 약해요.' },
    { id: 'mk', nm: '송곳 지정사수 소총', tag: '지정사수', ic: '🎯', dmg: 85, ap: 2, iv: 0.42, mag: 12, rsv: 84, sp: 0.006, rc: 0.12, rl: 2.4, rg: 36, kn: 1.0, d: '멀리 정확하게. 조준(오른쪽 버튼)하면 더 멀리 봐요.' },
    { id: 'smg', nm: '회오리 기관단총', tag: '기관단총', ic: '🌀', dmg: 16, ap: 1, iv: 0.065, mag: 40, rsv: 280, sp: 0.09, rc: 0.025, rl: 1.6, rg: 17, kn: 0.3, d: '빠른 연사, 가벼워서 뛰면서도 잘 맞아요.' },
    { id: 'pl', nm: '청염 플라즈마 소총', tag: '에너지 소총', ic: '🔷', dmg: 60, ap: 2, iv: 0.5, mag: 10, rsv: 60, sp: 0.02, rc: 0.08, rl: 2.2, rg: 26, kn: 1.2, pj: 30, ex: 1.3, d: '작게 터지는 플라즈마 탄. 몰려오는 적에 좋지만 가까이 쏘면 나도 다쳐요.' },
    { id: 'br', nm: '분쇄 점사 소총', tag: '점사 소총', ic: '⚙', dmg: 34, ap: 2, iv: 0.09, mag: 24, rsv: 168, sp: 0.03, rc: 0.05, rl: 2.1, rg: 26, kn: 0.6, burst: 3, bgap: 0.32, d: '한 번 누르면 3발 점사. 반동이 적고 정확해요.' },
  ];
  const SEC = [
    { id: 'pi', nm: '잔불 권총', tag: '권총', ic: '🔫', dmg: 30, ap: 1, iv: 0.18, mag: 15, rsv: 90, sp: 0.04, rc: 0.06, rl: 1.2, rg: 20, kn: 0.4, d: '빠르게 꺼내는 예비 권총.' },
    { id: 'mp', nm: '쐐기 기관권총', tag: '기관권총', ic: '✳', dmg: 15, ap: 1, iv: 0.055, mag: 24, rsv: 144, sp: 0.11, rc: 0.03, rl: 1.4, rg: 14, kn: 0.2, d: '가까운 무리를 쓸어 내는 연사 권총.' },
    { id: 'rv', nm: '천둥 리볼버', tag: '리볼버', ic: '⚡', dmg: 95, ap: 2, iv: 0.55, mag: 6, rsv: 36, sp: 0.015, rc: 0.2, rl: 2.4, rg: 24, kn: 1.6, d: '느리지만 한 방이 묵직해요(중장갑 관통).' },
  ];
  const GRE = [
    { id: 'frag', nm: '파편 수류탄', ic: '💣', r: 3.4, dmg: 220, ap: 3, fuse: 1.6, d: '1.6초 뒤 터지는 기본 수류탄. 둥지·공장도 부숴요.' },
    { id: 'imp', nm: '충격 수류탄', ic: '🔶', r: 2.8, dmg: 200, ap: 3, fuse: 0, d: '닿자마자 터져요. 가까이 던지면 위험!' },
    { id: 'stun', nm: '기절 수류탄', ic: '✨', r: 4.5, dmg: 0, ap: 0, fuse: 0.9, stun: 4.5, d: '피해는 없지만 넓게 4.5초 기절. 돌진충도 멈춰요.' },
    { id: 'fire', nm: '소이 수류탄', ic: '🔥', r: 3.2, dmg: 40, ap: 2, fuse: 1.2, burn: 7, d: '7초 동안 불바다(아군도 타요).' },
    { id: 'he', nm: '철갑 고폭탄', ic: '🔩', r: 1.8, dmg: 650, ap: 4, fuse: 1.2, d: '좁지만 대전차급. 중장갑 적의 등에 붙여요.' },
  ];
  // 갑옷: sp 이동 배율, tk 받는 피해 배율, pk 특성
  const ARM = [
    { id: 'scout', nm: '바람 정찰복', w: '경장', ic: '🪶', sp: 1.12, tk: 1.2, pk: 'scout', pd: '미니맵에 적이 2배 멀리까지 보이고, 적이 늦게 알아채요.' },
    { id: 'eng', nm: '공병 장갑', w: '중장', ic: '🛠', sp: 1.0, tk: 1.0, pk: 'eng', pd: '수류탄 +2개, 반동 30% 감소.' },
    { id: 'med', nm: '의무병 장갑', w: '중장', ic: '💉', sp: 1.0, tk: 1.0, pk: 'med', pd: '치료제 +2개, 치료가 2배 오래 지속(재생).' },
    { id: 'fort', nm: '요새 장갑', w: '중장갑', ic: '🛡', sp: 0.88, tk: 0.72, pk: 'fort', pd: '폭발 피해 50% 감소. 느리지만 단단해요.' },
    { id: 'supp', nm: '보급병 장갑', w: '중장', ic: '📦', sp: 1.0, tk: 1.0, pk: 'supp', pd: '예비탄 +50%, 보급품을 주우면 근처 동료도 채워 줘요.' },
    { id: 'assa', nm: '돌격 장갑', w: '경장', ic: '⚔', sp: 1.07, tk: 1.1, pk: 'assa', pd: '다이브 뒤 0.6초 무적, 근접 공격 2배.' },
  ];
  // 지원 요청: c 암호(U D L R), dl 도착 지연, cd 재사용 대기, n 사용 횟수(0 = 무제한), cat 분류, cost 해금 비용(요청 점수)
  const STR = [
    { id: 'ob_prec', nm: '궤도 정밀 포격', cat: '궤도', ic: '☄', c: 'RRU', dl: 3.2, cd: 80, n: 0, cost: 0, d: '표시한 곳에 거대한 포탄 1발. 대전차급(관통 5), 반경 3.5.' },
    { id: 'ob_bar', nm: '궤도 탄막 사격', cat: '궤도', ic: '🌧', c: 'RRDLRD', dl: 2.5, cd: 170, n: 0, cost: 6, d: '8초 동안 넓은 곳에 포탄 14발. 반경 8 — 근처에 있지 마세요.' },
    { id: 'ob_las', nm: '궤도 레이저', cat: '궤도', ic: '🔆', c: 'RDURD', dl: 3, cd: 240, n: 3, cost: 8, d: '10초 동안 레이저가 가까운 적을 따라가며 태워요. 판마다 3번.' },
    { id: 'ob_ems', nm: '궤도 전자기 충격', cat: '궤도', ic: '🌀', c: 'RRLD', dl: 2, cd: 70, n: 0, cost: 0, d: '반경 7을 6초 기절시켜요. 피해는 없어요.' },
    { id: 'ob_rail', nm: '궤도 레일 포격', cat: '궤도', ic: '⚡', c: 'RUDDR', dl: 1.5, cd: 200, n: 0, cost: 7, d: '표시 근처 가장 센 적 하나를 정확히 꿰뚫어요(피해 4000).' },
    { id: 'ea_str', nm: '기총 소사', cat: '항공', ic: '✈', c: 'URR', dl: 1.2, cd: 12, n: 4, cost: 0, d: '던진 방향으로 길게 기관포 사격. 4번 쓰면 재무장(130초).' },
    { id: 'ea_clu', nm: '집속 폭격', cat: '항공', ic: '🎆', c: 'URDDR', dl: 1.5, cd: 12, n: 3, cost: 0, d: '던진 방향으로 작은 폭탄 12발을 줄지어. 무리 청소용.' },
    { id: 'ea_500', nm: '대형 활공 폭탄', cat: '항공', ic: '💣', c: 'URDDD', dl: 2.2, cd: 12, n: 2, cost: 6, d: '반경 5 큰 폭발(관통 5). 중장갑·둥지에 좋아요.' },
    { id: 'sw_at', nm: '관통창 대전차 로켓', cat: '지원 화기', ic: '🚀', c: 'DDLUR', dl: 3.5, cd: 120, n: 0, cost: 0, d: '로켓 1발 + 예비 6발. 중장갑을 한두 방에.', w: 'at' },
    { id: 'sw_mg', nm: '톱날 경기관총', cat: '지원 화기', ic: '🪚', c: 'DLDUR', dl: 3.5, cd: 120, n: 0, cost: 0, d: '탄 100발 연사(관통 3). 무리 막기.', w: 'mg' },
    { id: 'sw_rail', nm: '뇌창 레일건', cat: '지원 화기', ic: '🔱', c: 'DRDULR', dl: 3.5, cd: 120, n: 0, cost: 6, d: '꿰뚫는 한 방(관통 5, 여러 적 관통). 1.1초마다.', w: 'rail' },
    { id: 'sw_fl', nm: '불길 화염방사기', cat: '지원 화기', ic: '🔥', c: 'DLURDU', dl: 3.5, cd: 120, n: 0, cost: 5, d: '앞쪽 부채꼴을 태워요(사거리 6). 벌레 떼에 최고.', w: 'fl' },
    { id: 'bp_sh', nm: '방패 배낭', cat: '지원 화기', ic: '🔵', c: 'DULRLR', dl: 3.5, cd: 200, n: 0, cost: 5, d: '내 몸에 보호막(200). 4초 안 맞으면 다시 차요.' },
    { id: 'df_mg', nm: '자동 기관포탑', cat: '방어', ic: '🗼', c: 'DURR', dl: 2.2, cd: 110, n: 0, cost: 0, d: '시야의 적을 자동으로 쏴요(탄 300). 앞에 서 있으면 나도 맞아요!' },
    { id: 'df_rk', nm: '로켓 포탑', cat: '방어', ic: '🎇', c: 'DURL', dl: 2.2, cd: 150, n: 0, cost: 6, d: '중장갑을 노리는 로켓 포탑(로켓 18발, 관통 4).' },
    { id: 'df_mine', nm: '대인 지뢰밭', cat: '방어', ic: '✴', c: 'DLUR', dl: 2.2, cd: 120, n: 0, cost: 0, d: '반경 5에 지뢰 14개. 적이 밟으면 터지고, 옆의 아군도 다쳐요.' },
    { id: 'df_bub', nm: '방어막 생성기', cat: '방어', ic: '🫧', c: 'DDLLRR', dl: 2.2, cd: 140, n: 0, cost: 5, d: '20초 동안 반경 4.5 돔. 적의 탄·침을 막아요(몸은 들어와요).' },
    { id: 'vh_mech', nm: '강습 보행기 「철각」', cat: '탑승물', ic: '🦿', c: 'LDRULDD', dl: 4.5, cd: 420, n: 1, cost: 9, d: '타는 보행기(체력 1100). 클릭 = 기관포(관통 3), G = 로켓(관통 4). E로 타고 내리기. 판마다 1대.' },
    { id: 'm_re', nm: '증원', cat: '기본', ic: '🪂', c: 'UDRLU', dl: 3, cd: 12, n: 0, cost: -1, d: '쓰러진 동료를 표시한 곳으로 다시 내려보내요. 부대 증원 횟수를 1 써요.' },
    { id: 'm_sup', nm: '보급품', cat: '기본', ic: '📦', c: 'DDUR', dl: 3, cd: 150, n: 0, cost: -1, d: '탄약·수류탄·치료제 상자 4개. 하나씩 주워요.' },
  ];
  const SI = {}; STR.forEach((s, i) => { SI[s.id] = i; });
  const S_RE = SI.m_re, S_SUP = SI.m_sup;
  const SLOTSTR = STR.filter((s) => s.cost >= 0);
  const START_UNL = SLOTSTR.filter((s) => s.cost === 0).map((s) => s.id);
  // 지원 화기 (지원 요청으로 받는 3번째 무기)
  const SUPW = {
    at: { id: 'at', nm: '관통창 대전차 로켓', ic: '🚀', dmg: 700, ap: 5, iv: 0.6, mag: 1, rsv: 6, sp: 0.01, rc: 0.3, rl: 3.0, rg: 40, kn: 4, pj: 34, ex: 1.2, d: '' },
    mg: { id: 'mg', nm: '톱날 경기관총', ic: '🪚', dmg: 30, ap: 3, iv: 0.075, mag: 100, rsv: 300, sp: 0.07, rc: 0.05, rl: 4.0, rg: 26, kn: 0.8, slow: 0.7, d: '' },
    rail: { id: 'rail', nm: '뇌창 레일건', ic: '🔱', dmg: 520, ap: 5, iv: 1.1, mag: 1, rsv: 20, sp: 0.003, rc: 0.25, rl: 0.9, rg: 44, kn: 3, pierce: 1, d: '' },
    fl: { id: 'fl', nm: '불길 화염방사기', ic: '🔥', dmg: 9, ap: 2, iv: 0.05, mag: 120, rsv: 240, sp: 0.3, rc: 0.005, rl: 3.0, rg: 6.5, kn: 0.1, flame: 1, d: '' },
  };
  const MECHW = { id: 'mc', nm: '철각 기관포', dmg: 140, ap: 3, iv: 0.28, mag: 999, rsv: 0, sp: 0.03, rc: 0.08, rl: 0, rg: 30, kn: 2, pj: 36, ex: 1.0 };
  // 진영·적
  const FAC = [
    { id: 'bug', nm: '군체', full: '굶주린 군체', c: '#d38a3a', hive: '군체 둥지', d: '땅속에서 떼로 몰려오는 벌레들. 하나가 소리치면(페로몬) 땅이 갈라지며 무리가 솟아요.' },
    { id: 'bot', nm: '기계단', full: '철갑 기계단', c: '#d24a3c', hive: '기계 공장', d: '총·로켓으로 멀리서 쏘는 기계 군대. 신호탄을 쏘면 수송선이 내려와 병력을 떨궈요.' },
    { id: 'void', nm: '공허 결사', full: '침묵의 공허 결사', c: '#9b6cff', hive: '공허 균열', d: '순간 이동으로 옆을 파고드는 그림자들. 감시 눈이 보면 균열이 열려요.' },
  ];
  // 적: hp, ar 장갑, sp 속도, r 몸 크기, at 공격(m 근접, s 침, b 총, k 로켓, c 포, l 레이저, x 돌진), dm 피해, rg 사거리, ic 간격, tier 0 잡병 1 정예 2 대형, rear 뒤쪽 약점
  const EN = [
    { id: 'b_ling', f: 0, nm: '잔발이', hp: 45, ar: 0, sp: 5.0, r: 0.36, at: 'm', dm: 12, rg: 1.0, ic: 0.8, tier: 0, d: '빠르고 약한 작은 벌레. 떼로 와요.' },
    { id: 'b_spit', f: 0, nm: '산성 침뱉이', hp: 160, ar: 1, sp: 3.0, r: 0.5, at: 's', dm: 26, rg: 12, ic: 2.2, tier: 1, d: '멀리서 산성 침을 뱉어요(튀는 피해).' },
    { id: 'b_hunt', f: 0, nm: '도약 사냥꾼', hp: 90, ar: 0, sp: 6.2, r: 0.42, at: 'm', dm: 18, rg: 1.1, ic: 0.7, tier: 0, leap: 1, d: '멀리서 펄쩍 뛰어 덮쳐요.' },
    { id: 'b_chg', f: 0, nm: '갑각 돌진충', hp: 900, ar: 3, sp: 3.4, r: 0.85, at: 'x', dm: 55, rg: 1.4, ic: 1.2, tier: 2, rear: 1, d: '앞은 단단한 갑각(관통 4 필요). 돌진을 피한 뒤 뒤쪽(약점)을 쏘세요.' },
    { id: 'b_tit', f: 0, nm: '둥지 거신', hp: 3600, ar: 4, sp: 1.8, r: 1.4, at: 's', dm: 60, rg: 16, ic: 3.0, tier: 2, big: 1, d: '거대한 산성 거신. 대전차 무기·궤도 포격이 필요해요.' },
    { id: 'm_trp', f: 1, nm: '보병 기계', hp: 80, ar: 0, sp: 2.8, r: 0.42, at: 'b', dm: 8, rg: 17, ic: 0.22, burst: 4, bgap: 1.6, tier: 0, d: '총을 짧게 연사해요. 머릿수가 많아요.' },
    { id: 'm_rkt', f: 1, nm: '로켓 기계', hp: 130, ar: 1, sp: 2.6, r: 0.45, at: 'k', dm: 45, rg: 20, ic: 3.2, tier: 1, d: '맞으면 넘어지는 로켓을 쏴요.' },
    { id: 'm_shd', f: 1, nm: '방패 돌격 기계', hp: 520, ar: 3, sp: 3.4, r: 0.6, at: 'm', dm: 34, rg: 1.3, ic: 1.0, tier: 1, rear: 1, d: '앞쪽 방패가 단단해요. 옆·뒤를 노리거나 폭발물로.' },
    { id: 'm_tank', f: 1, nm: '강철 보행 전차', hp: 3200, ar: 4, sp: 1.4, r: 1.3, at: 'c', dm: 85, rg: 24, ic: 3.4, tier: 2, rear: 2, big: 1, d: '포탑 대포. 뒤쪽 배기구가 약점(관통 2로도 들어가요).' },
    { id: 'v_shd', f: 2, nm: '그림자 병사', hp: 85, ar: 0, sp: 4.4, r: 0.4, at: 'm', dm: 20, rg: 1.1, ic: 0.8, tier: 0, blink: 1, d: '순간 이동으로 옆·뒤에 나타나요.' },
    { id: 'v_eye', f: 2, nm: '감시 눈', hp: 70, ar: 0, sp: 3.6, r: 0.4, at: 'l', dm: 10, rg: 13, ic: 1.6, tier: 0, fly: 1, d: '바위 위로 날아다니며 레이저를 쏘고 위치를 알려요.' },
    { id: 'v_lan', f: 2, nm: '공허 창병', hp: 280, ar: 2, sp: 2.8, r: 0.52, at: 's', dm: 36, rg: 15, ic: 2.0, tier: 1, d: '빛 창을 던져요. 관통 3 이상이 잘 들어요.' },
    { id: 'v_col', f: 2, nm: '공허 거신', hp: 3000, ar: 4, sp: 1.5, r: 1.35, at: 'l', dm: 26, rg: 18, ic: 0.25, tier: 2, big: 1, d: '긴 광선을 휘둘러요. 대전차 무기로.' },
    { id: 'hive', f: -1, nm: '구조물', hp: 1400, ar: 3, sp: 0, r: 1.3, at: '', dm: 0, rg: 0, ic: 9, tier: 3, d: '둥지·공장·균열. 폭발물(관통 3 이상)로만 부서져요.' },
    { id: 'tower', f: -1, nm: '적 통신탑', hp: 1000, ar: 3, sp: 0, r: 1.0, at: '', dm: 0, rg: 0, ic: 9, tier: 3, d: '부수면 적 증원이 덜 와요. 폭발물로.' },
  ];
  const EI = {}; EN.forEach((e, i) => { EI[e.id] = i; });
  const FAC_EN = [0, 1, 2].map((f) => EN.map((e, i) => (e.f === f ? i : -1)).filter((i) => i >= 0));
  // 은하 전선: 성계 3개 × 행성 3개
  const PLANETS = [
    { nm: '모래송곳', sec: 0, f: 0, g: ['#7a5636', '#6a4a2e'], rk: '#4a3524', bu: '#5e6a2e', d: '바람이 거친 붉은 사막.' },
    { nm: '진액 늪', sec: 0, f: 0, g: ['#4f5a32', '#434d2a'], rk: '#2f3622', bu: '#6b7a30', d: '끈적한 늪과 덤불.' },
    { nm: '갈퀴 고원', sec: 0, f: 0, g: ['#6e5a48', '#5f4d3d'], rk: '#3f332a', bu: '#6a5a2a', d: '군체 본진이 있는 바위 고원.' },
    { nm: '잿빛 제련소', sec: 1, f: 1, g: ['#5a5a5e', '#4d4d52'], rk: '#2e2e33', bu: '#4f5a46', d: '재가 날리는 공업 행성.' },
    { nm: '강철 평원', sec: 1, f: 1, g: ['#6b6656', '#5c5849'], rk: '#38352c', bu: '#56603a', d: '탁 트인 평원 — 멀리서 총알이 와요.' },
    { nm: '서리 송신탑', sec: 1, f: 1, g: ['#a9b4be', '#98a3ad'], rk: '#5c6670', bu: '#7d8f8a', d: '눈 덮인 송신 기지.' },
    { nm: '보랏빛 무덤', sec: 2, f: 2, g: ['#4a3d5a', '#3f344d'], rk: '#251d30', bu: '#5a3f6a', d: '보라 이끼 덮인 묘지 행성.' },
    { nm: '거울 사막', sec: 2, f: 2, g: ['#8a8070', '#7b7262'], rk: '#4d463a', bu: '#6f6a4a', d: '빛이 일렁이는 유리 모래.' },
    { nm: '별빛 폐허', sec: 2, f: 2, g: ['#3a4456', '#323b4b'], rk: '#1c2230', bu: '#3d5a5e', d: '무너진 고대 도시.' },
  ];
  const SECTORS = ['굶주린 벌집 성운', '녹슨 톱니 성계', '침묵의 장막'];
  const MT = [
    { id: 'nest', nm: '소탕 작전', d: (f) => FAC[f].hive + '를 모두 폭발물로 부숴요.' },
    { id: 'data', nm: '자료 송신', d: () => '단말기에 암호를 넣고 송신이 끝날 때까지 지켜요(곁에 있어야 진행).' },
    { id: 'defend', nm: '거점 사수', d: () => '거점을 켜고 90초 동안 버텨요(거점 안에 누가 있어야 진행).' },
    { id: 'launch', nm: '미사일 발사', d: () => '발전기 2개를 켜고, 발사대에 발사 암호를 넣고, 발사까지 지켜요.' },
    { id: 'rescue', nm: '피난민 구조', d: () => '대피소 문을 열고 피난민 12명 중 6명을 구조선 착륙장까지 지켜 보내요.' },
    { id: 'escort', nm: '화물 호송', d: () => '대원이 곁에 있을 때만 움직이는 화물차를 목적지까지 지켜요.' },
  ];
  const SIDE = [
    { id: 'tower', nm: '적 통신탑 파괴', d: '폭발물로 부수면 적 증원(땅굴·수송선·균열)이 덜 와요. 요청 점수 +2.' },
    { id: 'cache', nm: '보급 저장고 열기', d: 'E로 열면 표본 3개와 보급 상자.' },
    { id: 'beacon', nm: '신호기 가동', d: 'E를 누르고 암호 4개. 요청 점수 +3.' },
  ];
  const DIFF = [
    { nm: '훈련', den: 0.45, eli: 0.0, hv: 0.0, cdm: 0.8, re: 12, rq: 2, pat: 95 },
    { nm: '쉬움', den: 0.6, eli: 0.06, hv: 0.0, cdm: 0.85, re: 10, rq: 3, pat: 85 },
    { nm: '보통', den: 0.78, eli: 0.12, hv: 0.04, cdm: 0.95, re: 9, rq: 4, pat: 75 },
    { nm: '어려움', den: 0.95, eli: 0.18, hv: 0.08, cdm: 1.0, re: 8, rq: 5, pat: 65 },
    { nm: '극한', den: 1.15, eli: 0.24, hv: 0.12, cdm: 1.05, re: 7, rq: 6, pat: 55 },
    { nm: '자살 임무', den: 1.35, eli: 0.3, hv: 0.16, cdm: 1.1, re: 6, rq: 7, pat: 48 },
    { nm: '지옥', den: 1.6, eli: 0.36, hv: 0.22, cdm: 1.2, re: 5, rq: 9, pat: 40 },
  ];
  const UPG = [
    { id: 'orb', nm: '궤도 포 냉각기', d: '궤도 지원 재사용 −15%(단계마다)', cost: [4, 7, 10] },
    { id: 'eag', nm: '격납고 확장', d: '항공 지원 사용 +1, 재무장 −20%', cost: [5, 9] },
    { id: 'sup', nm: '보급 효율화', d: '보급품·지원 화기 재사용 −20%(단계마다)', cost: [4, 8] },
    { id: 'def', nm: '방어 시설 강화', d: '포탑·방어막 체력·탄 +40%(단계마다)', cost: [4, 8] },
    { id: 'rein', nm: '추가 증원선', d: '작전마다 증원 +2(단계마다)', cost: [5, 9] },
    { id: 'arm', nm: '장갑 보강판', d: '모든 대원 최대 체력 +15(단계마다)', cost: [4, 8] },
  ];
  const UI = {}; UPG.forEach((u, i) => { UI[u.id] = i; });
  const ARROW = { U: '▲', D: '▼', L: '◀', R: '▶' };
  const PHP = 150;

  /* ================= 지도 만들기 (결정적: 시드로 게스트도 같은 지도) ================= */
  function genMap(seed, pi, mt) {
    const R = rng(seed), g = new Uint8Array(MS * MS);
    const at = (x, y) => (x < 0 || y < 0 || x >= MS || y >= MS ? 1 : g[y * MS + x]);
    const disc = (cx, cy, r, v, ifv) => { for (let y = Math.floor(cy - r); y <= cy + r; y++) for (let x = Math.floor(cx - r); x <= cx + r; x++) { if (x < 1 || y < 1 || x >= MS - 1 || y >= MS - 1) continue; if (hyp(x + 0.5 - cx, y + 0.5 - cy) <= r && (ifv === undefined || g[y * MS + x] === ifv)) g[y * MS + x] = v; } };
    for (let i = 0; i < MS; i++) { g[i] = g[(MS - 1) * MS + i] = g[i * MS] = g[i * MS + MS - 1] = 1; }
    const nb = 34 + Math.floor(R() * 10);
    for (let i = 0; i < nb; i++) { const cx = 3 + R() * (MS - 6), cy = 3 + R() * (MS - 6), r = 1.2 + R() * 2.8; disc(cx, cy, r, 1); if (R() < 0.5) disc(cx + (R() - 0.5) * 3, cy + (R() - 0.5) * 3, r * 0.7, 1); }
    for (let i = 0; i < 26; i++) { const cx = 3 + R() * (MS - 6), cy = 3 + R() * (MS - 6); disc(cx, cy, 1.5 + R() * 2.6, 2, 0); }
    // 주요 지점: 착륙(가장자리 근처), 탈출(반대쪽), 목표(가운데 쪽)
    const side = Math.floor(R() * 4);
    const edge = (s, t) => { const m = 7, f = m + t * (MS - 2 * m); return s === 0 ? [f, m] : s === 1 ? [MS - m, f] : s === 2 ? [f, MS - m] : [m, f]; };
    const drop = edge(side, 0.3 + R() * 0.4), ex = edge((side + 2) % 4, 0.2 + R() * 0.6);
    const pts = { drop, ex, obj: [], side: [], smp: [], hive: [] };
    const far = (p, list, d) => list.every((q) => hyp(p[0] - q[0], p[1] - q[1]) >= d);
    const pick = (d, avoid, cx, cy, rad) => { for (let k = 0; k < 200; k++) { const p = cx !== undefined ? [cx + (R() - 0.5) * 2 * rad, cy + (R() - 0.5) * 2 * rad] : [8 + R() * (MS - 16), 8 + R() * (MS - 16)]; p[0] = clamp(p[0], 6, MS - 6); p[1] = clamp(p[1], 6, MS - 6); if (far(p, avoid, d)) return p; } return [MS / 2 + (R() - 0.5) * 20, MS / 2 + (R() - 0.5) * 20]; };
    const key = () => [drop, ex].concat(pts.obj, pts.side, pts.hive);
    const mid = [(drop[0] + ex[0]) / 2, (drop[1] + ex[1]) / 2];
    if (mt === 'nest') { for (let i = 0; i < 4; i++) pts.hive.push(pick(13, key())); }
    else if (mt === 'launch') { const c = pick(16, key(), mid[0], mid[1], 12); pts.obj.push(c); pts.obj.push(pick(10, key(), c[0], c[1], 14)); pts.obj.push(pick(10, key(), c[0], c[1], 14)); }
    else if (mt === 'rescue') { const a = pick(18, key()); pts.obj.push(a); pts.obj.push(pick(20, key().concat([a]), a[0], a[1], 22)); }
    else if (mt === 'escort') { pts.obj.push(pick(10, key(), drop[0] + (mid[0] - drop[0]) * 0.4, drop[1] + (mid[1] - drop[1]) * 0.4, 6)); pts.obj.push(pick(14, key(), ex[0] + (mid[0] - ex[0]) * 0.3, ex[1] + (mid[1] - ex[1]) * 0.3, 8)); }
    else pts.obj.push(pick(18, key(), mid[0], mid[1], 14));
    for (let i = 0; i < 2; i++) pts.side.push(pick(14, key()));
    for (let i = 0; i < 9; i++) pts.smp.push(pick(6, key().concat(pts.smp)));
    // 길 뚫기: 착륙 지점에서 모든 지점으로 구불구불한 통로
    const carve = (a, b) => { let x = a[0], y = a[1]; const n = Math.ceil(hyp(b[0] - a[0], b[1] - a[1]) / 0.5); let wob = R() * TAU; for (let i = 0; i <= n; i++) { const t = i / n; wob += (R() - 0.5) * 0.6; x = a[0] + (b[0] - a[0]) * t + Math.sin(t * Math.PI) * Math.cos(wob) * 3; y = a[1] + (b[1] - a[1]) * t + Math.sin(t * Math.PI) * Math.sin(wob) * 3; disc(x, y, 1.6, 0, 1); } };
    const all = [ex].concat(pts.obj, pts.side, pts.hive, pts.smp);
    for (const p of all) carve(drop, p);
    if (mt === 'escort') carve(pts.obj[0], pts.obj[1]);
    for (const p of [drop, ex].concat(pts.obj, pts.side, pts.hive)) disc(p[0], p[1], 3.6, 0);
    for (const p of pts.smp) disc(p[0], p[1], 1.2, 0);
    return { g, pts, at, seed, pi, mt };
  }
  const solid = (M, x, y) => M.at(Math.floor(x), Math.floor(y)) === 1;
  function los(M, ax, ay, bx, by) {
    const d = hyp(bx - ax, by - ay), n = Math.ceil(d / 0.35);
    for (let i = 1; i < n; i++) { const t = i / n; if (solid(M, ax + (bx - ax) * t, ay + (by - ay) * t)) return false; }
    return true;
  }
  // 바위 앞에서 멈추는 지점까지 거리
  function rayWall(M, x, y, dx, dy, rg) { for (let s = 0.3; s < rg; s += 0.25) if (solid(M, x + dx * s, y + dy * s)) return s; return rg; }
  // 너비 우선 거리장 (적 추적·AI 길 찾기)
  function bfs(M, srcs) {
    const D = new Int16Array(MS * MS).fill(-1), q = new Int32Array(MS * MS); let h = 0, t = 0;
    for (const s of srcs) { const x = clamp(Math.floor(s[0]), 0, MS - 1), y = clamp(Math.floor(s[1]), 0, MS - 1), i = y * MS + x; if (D[i] < 0 && M.g[i] !== 1) { D[i] = 0; q[t++] = i; } }
    while (h < t) {
      const i = q[h++], x = i % MS, y = (i / MS) | 0, d = D[i] + 1;
      if (x > 0 && D[i - 1] < 0 && M.g[i - 1] !== 1) { D[i - 1] = d; q[t++] = i - 1; }
      if (x < MS - 1 && D[i + 1] < 0 && M.g[i + 1] !== 1) { D[i + 1] = d; q[t++] = i + 1; }
      if (y > 0 && D[i - MS] < 0 && M.g[i - MS] !== 1) { D[i - MS] = d; q[t++] = i - MS; }
      if (y < MS - 1 && D[i + MS] < 0 && M.g[i + MS] !== 1) { D[i + MS] = d; q[t++] = i + MS; }
    }
    return D;
  }
  // 거리장을 따라 내려가는 방향
  function flowDir(M, D, x, y) {
    const cx = Math.floor(x), cy = Math.floor(y), i = cy * MS + cx;
    if (cx < 0 || cy < 0 || cx >= MS || cy >= MS) return null;
    let best = D[i] >= 0 ? D[i] : 1e9, bx = 0, by = 0;
    for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
      if (!ox && !oy) continue; const nx = cx + ox, ny = cy + oy; if (nx < 0 || ny < 0 || nx >= MS || ny >= MS) continue;
      const v = D[ny * MS + nx]; if (v < 0) continue;
      if (ox && oy && (M.g[cy * MS + nx] === 1 || M.g[ny * MS + cx] === 1)) continue;
      const c = v + (ox && oy ? 0.41 : 0);
      if (c < best) { best = c; bx = nx + 0.5 - x; by = ny + 0.5 - y; }
    }
    const l = hyp(bx, by); return l > 0 ? [bx / l, by / l] : null;
  }

  /* ================= 큰 흐름 상태 (api.setState) ================= */
  function availPlanets(lib) {
    const out = [];
    for (let s = 0; s < 3; s++) for (let k = 0; k < 3; k++) { const i = s * 3 + k; if (lib[i] < 100) { out.push(i); break; } }
    return out;
  }
  function planMission(st, pi, keepMt) {
    const av = availPlanets(st.lib);
    if (!av.length) return null;
    if (!(av.indexOf(pi) >= 0)) pi = av[U.rand(av.length)];
    let mt = U.rand(MT.length);
    if (keepMt !== undefined && keepMt >= 0) mt = keepMt;
    const sd = U.shuffle([0, 1, 2]).slice(0, 1 + (st.dif >= 3 ? 1 : 0));
    return { pi, mt, seed: 1 + U.rand(2147483000), sd };
  }
  function aiLoadout(st, s) {
    const unl = st.unl.filter((id) => STR[SI[id]].cat !== '탑승물');
    const pick = (arr) => arr[U.rand(arr.length)];
    const off = unl.filter((id) => /^(ob_|ea_)/.test(id)), sup = unl.filter((id) => /^sw_/.test(id)), def = unl.filter((id) => /^(df_|bp_)/.test(id));
    const ch = [];
    const add = (pool) => { const c = pool.filter((id) => ch.indexOf(id) < 0); if (c.length) ch.push(pick(c)); };
    if (s % 2 === 0 && sup.indexOf('sw_at') >= 0) ch.push('sw_at'); else add(sup);
    add(off); add(off.length > 2 ? off : def); add(def.length ? def : off);
    while (ch.length < 4) { const c = unl.filter((id) => ch.indexOf(id) < 0); if (!c.length) break; ch.push(pick(c)); }
    return [U.rand(PRI.length), U.rand(SEC.length), [0, 0, 1, 3, 4][U.rand(5)], U.rand(ARM.length)].concat(ch.map((id) => SI[id]));
  }
  function validLo(st, lo) {
    if (!Array.isArray(lo) || lo.length < 8) return null;
    const o = lo.slice(0, 8).map((v) => v | 0);
    if (!(o[0] >= 0 && o[0] < PRI.length && o[1] >= 0 && o[1] < SEC.length && o[2] >= 0 && o[2] < GRE.length && o[3] >= 0 && o[3] < ARM.length)) return null;
    const ss = o.slice(4);
    for (let i = 0; i < 4; i++) { const S = STR[ss[i]]; if (!S || S.cost < 0 || st.unl.indexOf(S.id) < 0 || ss.indexOf(ss[i]) !== i) return null; }
    return o;
  }
  function init(players, opts) {
    const o = opts || {}, np = clamp(players.length | 0, 1, NP);
    const st = {
      rid: 1 + U.rand(999999), np, nm: players.slice(0, np).map((p, i) => String((p && p.name) || (i + 1) + '번').slice(0, 10)),
      ai: players.slice(0, np).map((p) => (p && p.ai ? 1 : 0)),
      dif: clamp(o.dif === undefined ? 2 : o.dif | 0, 0, 6), ops: [1, 3, 5, 8].indexOf(+o.ops) >= 0 ? +o.ops : 3, tl: [8, 12, 20].indexOf(+o.tl) >= 0 ? +o.tl : 12,
      ph: 'load', mk: 1, lib: Array(9).fill(0), req: 0, smp: 0, upg: UPG.map(() => 0), unl: START_UNL.slice(),
      lo: Array(np).fill(null), rd: Array(np).fill(0), mi: null, done: 0, wins: 0, hist: [], sk: Array.from({ length: np }, () => [0, 0, 0, 0, 0, 0]), res: null, fin: null,
    };
    st.mi = planMission(st, -1);
    for (let s = 0; s < np; s++) if (st.ai[s]) { st.lo[s] = aiLoadout(st, s); st.rd[s] = 1; }
    return st;
  }
  function missionOver(st, R) {
    const n = U.clone(st), D = DIFF[n.dif], pi = n.mi.pi;
    n.done++; if (R.ok) n.wins++;
    const before = n.lib[pi];
    if (R.ok) n.lib[pi] = Math.min(100, n.lib[pi] + 20 + n.dif * 3 + (R.sides | 0) * 3);
    else n.lib[pi] = Math.max(0, n.lib[pi] - 6);
    const req = R.ok ? D.rq + (R.sides | 0) * 2 + (R.bonus | 0) : 1;
    n.req += req; n.smp += R.ok ? (R.smp | 0) : 0;
    for (let s = 0; s < n.np; s++) { const a = (R.sk && R.sk[s]) || []; for (let k = 0; k < 6; k++) n.sk[s][k] += a[k] | 0; }
    n.hist.push([pi, n.mi.mt, R.ok ? 1 : 0, R.smp | 0, Math.round(R.t | 0), R.why | 0]);
    if (n.hist.length > 12) n.hist.shift();
    n.res = { ok: R.ok ? 1 : 0, why: R.why | 0, smp: R.smp | 0, req, lb: before, la: n.lib[pi], fr: before < 100 && n.lib[pi] >= 100 ? 1 : 0, sides: R.sides | 0, t: Math.round(R.t | 0), ext: R.ext | 0, sk: R.sk || [] };
    n.ph = 'end';
    return n;
  }
  function nextMission(st) {
    const n = U.clone(st);
    const allFree = n.lib.every((v) => v >= 100);
    if (n.done >= n.ops || allFree) { n.ph = 'done'; n.fin = { all: allFree ? 1 : 0 }; return n; }
    n.mi = planMission(n, -1); n.ph = 'load'; n.mk++; n.res = null;
    n.rd = n.rd.map((v, s) => (n.ai && n.ai[s] ? 1 : 0));
    return n;
  }
  const WHY = ['', '부대 전멸 — 증원이 바닥났어요', '작전 시간 초과', '화물차가 파괴됐어요', '피난민을 너무 많이 잃었어요', '탈출선을 놓쳤어요'];
  function result(st) {
    if (!st || st.ph !== 'done') return null;
    const freed = st.lib.filter((v) => v >= 100).length;
    const col = (k) => st.sk.map((a) => String(a[k] | 0));
    const stats = [
      { label: '작전 성공', value: st.wins + ' / ' + st.done },
      { label: '해방한 행성', value: freed + ' / 9' },
      { label: '처치', values: col(0) }, { label: '쓰러짐', values: col(1), low: true },
      { label: '아군 사고', values: col(2), low: true }, { label: '지원 요청', values: col(3) }, { label: '모은 표본', values: col(4) },
    ];
    const ok = st.wins > 0;
    const hl = [];
    if (st.fin && st.fin.all) hl.push('은하 전선의 모든 행성을 해방했어요!');
    st.hist.slice(-4).forEach((h) => hl.push(PLANETS[h[0]].nm + ' · ' + MT[h[1]].nm + ' — ' + (h[2] ? '성공' : '실패' + (WHY[h[5]] ? '(' + WHY[h[5]] + ')' : ''))));
    return {
      winners: ok ? Array.from({ length: st.np }, (_, i) => i) : [], title: ok ? '작전 종료 — 부대 귀환' : '작전 실패 — 전선 후퇴',
      text: DIFF[st.dif].nm + ' · 작전 ' + st.done + '번 중 ' + st.wins + '번 성공 · 해방한 행성 ' + freed + '개', stats, highlights: hl.slice(0, 4),
    };
  }

  /* ================= 전투 세계 (호스트) ================= */
  const pr0 = (M, x, y) => !solid(M, x, y);
  function openNear(M, x, y, R, rad, minD, avoid) {
    for (let k = 0; k < 60; k++) {
      const a = R() * TAU, d = (minD || 0) + R() * rad, nx = x + Math.cos(a) * d, ny = y + Math.sin(a) * d;
      if (nx < 2 || ny < 2 || nx > MS - 2 || ny > MS - 2) continue;
      if (!pr0(M, nx, ny) || !pr0(M, nx + 0.5, ny) || !pr0(M, nx - 0.5, ny) || !pr0(M, nx, ny + 0.5) || !pr0(M, nx, ny - 0.5)) continue;
      if (avoid && avoid.some((q) => hyp(q[0] - nx, q[1] - ny) < q[2])) continue;
      return [nx, ny];
    }
    return [clamp(x, 2, MS - 2), clamp(y, 2, MS - 2)];
  }
  function weaponState(w, mul) { return { mag: w.mag, rsv: Math.round(w.rsv * (mul || 1)), cd: 0, rl: 0, bl: 0 }; }
  function mkPlayer(W, s, lo, x, y) {
    const A = ARM[lo[3]], up = W.upg;
    const mhp = PHP + 15 * (up[UI.arm] | 0);
    const p = {
      s, x, y, vx: 0, vy: 0, a: 0, al: 1, hp: mhp, mhp, lo, A: lo[3], w: 0,
      W: [weaponState(PRI[lo[0]], A.pk === 'supp' ? 1.5 : 1), weaponState(SEC[lo[1]], A.pk === 'supp' ? 1.5 : 1), null], sw: null,
      gr: 4 + (A.pk === 'eng' ? 2 : 0), grm: 4 + (A.pk === 'eng' ? 2 : 0), stim: 4 + (A.pk === 'med' ? 2 : 0), stm0: 4 + (A.pk === 'med' ? 2 : 0),
      stm: 1, dv: 0, dvc: 0, inv: 0, stun: 0, rg: 0, sh: 0, shm: 0, shT: 0, bp: 0, pod: 0,
      sl: lo.slice(4, 8).concat([S_RE, S_SUP]), cd: [0, 0, 0, 0, 0, 0], nU: null, rearm: [0, 0, 0, 0, 0, 0],
      smp: 0, veh: -1, dt: 0, drop: 2.2, fc: 0, rec: 0, mel: 0, grc: 0, tm: -1, ads: 0, spr: 0, hit: 0, kills: 0, deaths: 0, tk: 0, calls: 0, boarded: 0, lastHit: -1, ffT: 0, mvx: 0, mvy: 0, melT: 0,
    };
    p.nU = p.sl.map((si) => usesOf(W, si));
    return p;
  }
  function usesOf(W, si) { const S = STR[si]; if (!S.n) return -1; return S.n + (S.cat === '항공' ? (W.upg[UI.eag] | 0) : 0); }
  function cdOf(W, si) {
    const S = STR[si], up = W.upg; let c = S.cd * DIFF[W.dif].cdm;
    if (S.cat === '궤도') c *= 1 - 0.15 * (up[UI.orb] | 0);
    if (S.cat === '지원 화기' || si === S_SUP) c *= 1 - 0.2 * (up[UI.sup] | 0);
    return c;
  }
  function newWorld(st) {
    const mi = st.mi, M = genMap(mi.seed, mi.pi, MT[mi.mt].id), R = rng(mi.seed ^ 0x5bd1e995), P = M.pts, D = DIFF[st.dif];
    const W = {
      M, R, dif: st.dif, upg: st.upg.slice(), np: st.np, fac: PLANETS[mi.pi].f, mt: MT[mi.mt].id, t: 0, tl: st.tl * 60, nid: 1,
      pl: [], en: [], pr: [], bc: [], ef: [], tu: [], mn: [], sb: [], it: [], vh: [], fi: [], cv: [], cr: null, ob: [], sd: [], fx: [], fxq: 0,
      ex: { x: P.ex[0], y: P.ex[1], ph: 0, t: 0 }, md: 0, rein: D.re + 2 * (st.upg[UI.rein] | 0) + st.np, brCd: 25, patT: D.pat * 0.6, waveT: 8, res: null, wipeT: 0, ovT: 0,
      edm: 0.5 + 0.1 * st.dif, pf: null, pfT: 0, sk: Array.from({ length: st.np }, () => [0, 0, 0, 0, 0, 0]), tower: 0, timeUp: 0,
    };
    for (let s = 0; s < st.np; s++) {
      const lo = st.lo[s] || aiLoadout(st, s);
      const q = openNear(M, P.drop[0], P.drop[1], R, 2.5, 0.6);
      W.pl.push(mkPlayer(W, s, lo, q[0], q[1]));
    }
    const mt = W.mt, f = W.fac;
    const addOb = (k, p, extra) => { const o = Object.assign({ k, x: p[0], y: p[1], s: 0, pr: 0, c: '' }, extra || {}); W.ob.push(o); return o; };
    if (mt === 'nest') { P.hive.forEach((h) => { const e = spawnE(W, EI.hive, h[0], h[1]); e.main = 1; guard(W, h[0], h[1], 3 + Math.round(4 * D.den)); }); addOb('nest', P.hive[0], { n: P.hive.length, n0: P.hive.length }); }
    else if (mt === 'data') { addOb('term', P.obj[0], { c: mkCode(R, 7) }); guard(W, P.obj[0][0], P.obj[0][1], 5); }
    else if (mt === 'defend') { addOb('zone', P.obj[0]); }
    else if (mt === 'launch') { addOb('silo', P.obj[0], { c: mkCode(R, 8) }); addOb('gen', P.obj[1]); addOb('gen', P.obj[2]); guard(W, P.obj[1][0], P.obj[1][1], 4); guard(W, P.obj[2][0], P.obj[2][1], 4); }
    else if (mt === 'rescue') { addOb('shel', P.obj[0], { sv: 0, dd: 0, out: 0, ot: 0 }); addOb('pad', P.obj[1]); }
    else if (mt === 'escort') { addOb('crawl', P.obj[0]); addOb('dest', P.obj[1]); W.cr = { x: P.obj[0][0], y: P.obj[0][1], a: 0, hp: 5000, mhp: 5000, D: bfs(M, [P.obj[1]]), mv: 0 }; }
    mi.sd.forEach((k, i) => {
      const p = P.side[i]; if (!p) return;
      const S = SIDE[k];
      if (S.id === 'tower') { const e = spawnE(W, EI.tower, p[0], p[1]); e.side = W.sd.length; W.tower = 1; guard(W, p[0], p[1], 4); }
      W.sd.push({ k: S.id, x: p[0], y: p[1], s: 0, c: S.id === 'beacon' ? mkCode(R, 4) : '' });
    });
    P.smp.forEach((p, i) => W.it.push({ id: W.nid++, k: 0, x: p[0], y: p[1], n: i % 4 === 3 ? 2 : 1 }));
    const groups = Math.round(3 + 4 * D.den);
    for (let g = 0; g < groups; g++) {
      const q = openNear(M, MS / 2, MS / 2, R, MS / 2 - 4, 0);
      if (hyp(q[0] - P.drop[0], q[1] - P.drop[1]) < 18 || P.obj.some((o) => hyp(q[0] - o[0], q[1] - o[1]) < 12)) continue;
      patrol(W, q[0], q[1], 3 + Math.floor(R() * 4 * D.den + 1), g);
    }
    fx(W, FX.DROPIN, P.drop[0], P.drop[1], 0, 0);
    return W;
  }
  function mkCode(R, n) { let s = ''; for (let i = 0; i < n; i++) s += 'UDLR'[Math.floor(R() * 4)]; return s; }
  function spawnE(W, ti, x, y, o) {
    const T = EN[ti], D = DIFF[W.dif];
    const e = { id: W.nid++, t: ti, x, y, vx: 0, vy: 0, a: Math.random() * TAU, hp: T.hp, mhp: T.hp, st: 0, tg: null, cd: 1 + Math.random(), bl: 0, al: 0, grp: -1, wx: x, wy: y, stun: 0, ch: 0, chT: 0, cl: 0, bk: 2, burn: 0, mem: 0, off: Math.random() * TAU, spn: 0, side: -1, main: 0, ret: 0, wt: 0 };
    if (T.tier === 2) { e.hp = e.mhp = Math.round(T.hp * (0.85 + 0.15 * D.den)); }
    if (o) Object.assign(e, o);
    W.en.push(e); return e;
  }
  function rollType(W, f, wave) {
    const D = DIFF[W.dif], pool = FAC_EN[f], r = Math.random();
    const tier = (k) => pool.filter((i) => EN[i].tier === k);
    const hv = D.hv * (wave ? 1.4 : 1), el = D.eli * (wave ? 1.3 : 1);
    const one = (a) => a[Math.floor(Math.random() * a.length)];
    if (r < hv) return one(tier(2));
    if (r < hv + el) return one(tier(1));
    return one(tier(0));
  }
  function patrol(W, x, y, n, g, wave, tgx, tgy) {
    const f = W.fac, out = [];
    for (let i = 0; i < n; i++) {
      const q = openNear(W.M, x, y, W.R, 2.2, 0);
      const e = spawnE(W, rollType(W, f, wave), q[0], q[1], { grp: g, wx: tgx === undefined ? x : tgx, wy: tgy === undefined ? y : tgy });
      if (i === 0 && !wave) e.cl = 1;
      if (wave) { e.st = 1; e.mem = 30; e.spn = 0.8; }
      out.push(e);
    }
    return out;
  }
  function guard(W, x, y, n) { for (let i = 0; i < n; i++) { const q = openNear(W.M, x, y, W.R, 5, 2); spawnE(W, FAC_EN[W.fac][Math.random() < 0.7 ? 0 : 1], q[0], q[1], { grp: -2, wx: x, wy: y }); } }
  const FX = { BOOM: 1, EDIE: 2, PDIE: 3, BNC: 4, BEAC: 5, BREACH: 7, POD: 9, SMP: 10, OBJ: 11, EXT: 12, LASER: 13, STIM: 14, MEL: 15, FF: 16, EJECT: 18, CIV: 19, BLINK: 21, LAUNCH: 22, CALL: 23, TIME: 24, RAIL: 26, ESHOT: 27, PICK: 28, DROPIN: 29, NOPE: 30, GREN: 31 };
  function fx(W, code, x, y, a, b) { W.fxq++; W.fx.push([W.fxq, code, r1(x), r1(y), a | 0, b | 0]); if (W.fx.length > 48) W.fx.shift(); }

  /* ----- 피해 ----- */
  function armorMul(ap, ar) { return ap > ar ? 1 : ap === ar ? 0.65 : ap === ar - 1 ? 0.12 : 0; }
  function hurtE(W, e, dmg, ap, o, dx, dy, kn, kind) {
    if (e.hp <= 0) return 0;
    const T = EN[e.t];
    let ar = T.ar;
    if (T.rear && (dx || dy)) { const l = hyp(dx, dy) || 1; if ((Math.cos(e.a) * dx + Math.sin(e.a) * dy) / l > 0.35) ar = Math.max(0, ar - T.rear - 1); }
    if (T.tier === 3 && ap < 3) return 0;
    const m = kind === 'x' ? 1 : armorMul(ap, ar);
    if (m < 0.2 && Math.random() < 0.25) fx(W, FX.BNC, e.x, e.y, 0, 0);
    const d = dmg * m; if (d <= 0) return 0;
    e.hp -= d;
    if (kn && T.tier < 2) { const l = hyp(dx, dy) || 1; e.vx += dx / l * kn; e.vy += dy / l * kn; }
    if (o >= 0 && W.pl[o] && T.tier < 3) { if (e.st === 0 || !e.tg) e.tg = { k: 'p', i: o }; e.st = 1; e.mem = 6; }
    if (e.hp <= 0) {
      if (o >= 0 && W.pl[o]) { W.pl[o].kills++; W.sk[o][0]++; }
      fx(W, FX.EDIE, e.x, e.y, e.t, Math.round(Math.atan2(dy || 0.01, dx || 0.01) * 10));
      if (T.tier === 3) fx(W, FX.BOOM, e.x, e.y, 40, 1);
      if (e.t === EI.tower) { W.tower = 0; if (e.side >= 0 && W.sd[e.side]) { W.sd[e.side].s = 2; fx(W, FX.OBJ, e.x, e.y, 20, 0); } }
      if (e.main) fx(W, FX.OBJ, e.x, e.y, 1, 0);
      if (T.tier === 2 && Math.random() < 0.5) W.it.push({ id: W.nid++, k: 0, x: e.x, y: e.y, n: 1 });
    }
    return d;
  }
  function hurtP(W, p, dmg, o, dx, dy, kn, isBoom) {
    if (!p.al || p.drop > 0 || p.boarded) return;
    if (p.veh >= 0) { const v = W.vh.find((q) => q.id === p.veh); if (v) { v.hp -= dmg * 0.8; return; } }
    if (p.inv > 0) return;
    let d = dmg * ARM[p.A].tk; if (isBoom && ARM[p.A].pk === 'fort') d *= 0.5;
    if (p.sh > 0) { const a = Math.min(p.sh, d); p.sh -= a; d -= a; }
    if (p.shm > 0) p.shT = 4;
    p.hp -= d; p.hit = 0.3;
    if (o >= 0 && o !== p.s && d > 0) { p.lastHit = o; if (p.ffT <= 0) { fx(W, FX.FF, p.x, p.y, p.s, o); p.ffT = 1.2; } }
    else if (d > 0) p.lastHit = -1;
    if (kn) { const l = hyp(dx, dy) || 1; p.vx += dx / l * kn; p.vy += dy / l * kn; if (kn > 5) p.stun = Math.max(p.stun, 0.5); }
    if (p.hp <= 0) killP(W, p);
  }
  function killP(W, p) {
    p.al = 0; p.hp = 0; p.dt = W.t; p.deaths++; W.sk[p.s][1]++; p.tm = -1; p.pod = 0;
    if (p.veh >= 0) { const v = W.vh.find((q) => q.id === p.veh); if (v) v.dr = -1; p.veh = -1; }
    if (p.lastHit >= 0 && p.lastHit !== p.s && W.pl[p.lastHit]) { W.pl[p.lastHit].tk++; W.sk[p.lastHit][2]++; }
    fx(W, FX.PDIE, p.x, p.y, p.s, p.lastHit);
    if (p.smp > 0) { W.it.push({ id: W.nid++, k: 5, x: p.x, y: p.y, n: p.smp }); p.smp = 0; }
    if (p.sw) { W.it.push({ id: W.nid++, k: 3, x: p.x + 0.4, y: p.y, w: p.sw, m: p.W[2] ? p.W[2].mag : 0, r: p.W[2] ? p.W[2].rsv : 0 }); p.sw = null; p.W[2] = null; if (p.w === 2) p.w = 0; }
    if (p.bp) { W.it.push({ id: W.nid++, k: 4, x: p.x - 0.4, y: p.y }); p.bp = 0; p.sh = p.shm = 0; }
  }
  function hurtAll(W, x, y, r, dmg, ap, o, kn, opt) {
    opt = opt || {};
    for (const e of W.en) { if (e.hp <= 0) continue; const d = hyp(e.x - x, e.y - y); if (d < r + EN[e.t].r) { const f = 1 - 0.6 * clamp(d / r, 0, 1); if (dmg > 0) hurtE(W, e, dmg * f, ap, o, e.x - x, e.y - y, kn * f, 'b'); if (opt.stun && EN[e.t].tier < 3) e.stun = Math.max(e.stun, opt.stun); if (opt.burn && EN[e.t].tier < 3) e.burn = Math.max(e.burn, opt.burn); } }
    if (opt.noP) return;
    for (const p of W.pl) { if (!p.al) continue; const d = hyp(p.x - x, p.y - y); if (d < r + 0.4) { const f = 1 - 0.6 * clamp(d / r, 0, 1); if (dmg > 0) hurtP(W, p, dmg * f * (opt.pm === undefined ? 0.5 : opt.pm), o, p.x - x, p.y - y, kn * f, 1); if (opt.stun) p.stun = Math.max(p.stun, opt.stun * 0.3); } }
    for (const t of W.tu) { const d = hyp(t.x - x, t.y - y); if (d < r + 0.6) t.hp -= dmg * (1 - 0.6 * clamp(d / r, 0, 1)) * 0.5; }
    for (const v of W.vh) { const d = hyp(v.x - x, v.y - y); if (d < r + 0.9) v.hp -= dmg * (1 - 0.6 * clamp(d / r, 0, 1)) * 0.4 * (ap >= 3 ? 1 : 0.3); }
    for (const c of W.cv) { if (c.hp > 0 && hyp(c.x - x, c.y - y) < r + 0.3) hurtCiv(W, c, dmg * 0.6); }
    if (W.cr && hyp(W.cr.x - x, W.cr.y - y) < r + 1) W.cr.hp -= dmg * 0.08;
  }
  function boom(W, x, y, r, dmg, ap, o, kn, opt) { hurtAll(W, x, y, r, dmg, ap, o, kn, opt); fx(W, FX.BOOM, x, y, Math.round(r * 10), opt && opt.stun ? 2 : opt && opt.burn ? 3 : 0); }
  function hurtCiv(W, c, d) { if (c.hp <= 0) return; c.hp -= d; if (c.hp <= 0) { const o = W.ob.find((q) => q.k === 'shel'); if (o) o.dd++; fx(W, FX.CIV, c.x, c.y, 0, 0); } }

  /* ----- 사격 (즉시 판정) ----- */
  function rayHit(W, x, y, dx, dy, rg, self, pierce) {
    const wall = rayWall(W.M, x, y, dx, dy, rg);
    const hits = [];
    const test = (k, ref, ex, ey, er) => { const ax = ex - x, ay = ey - y, t = ax * dx + ay * dy; if (t < 0 || t > wall) return; const px = ax - dx * t, py = ay - dy * t; if (px * px + py * py < er * er) hits.push({ k, ref, t }); };
    for (const e of W.en) if (e.hp > 0) test('e', e, e.x, e.y, EN[e.t].r);
    for (const p of W.pl) if (p.al && p.s !== self && !(p.drop > 0) && !p.boarded && p.veh < 0) test('p', p, p.x, p.y, 0.36);
    for (const t of W.tu) if (t.dt <= 0) test('t', t, t.x, t.y, 0.45);
    const me = self >= 0 ? W.pl[self] : null;
    for (const v of W.vh) if (!(me && me.veh === v.id)) test('v', v, v.x, v.y, 0.85);
    for (const c of W.cv) if (c.hp > 0) test('c', c, c.x, c.y, 0.32);
    if (W.cr) test('r', W.cr, W.cr.x, W.cr.y, 0.95);
    hits.sort((a, b) => a.t - b.t);
    return { wall, hits: pierce ? hits : hits.slice(0, 1) };
  }
  function applyHit(W, h, dmg, ap, o, dx, dy, kn) {
    if (h.k === 'e') return hurtE(W, h.ref, dmg, ap, o, dx, dy, kn, 'b');
    if (h.k === 'p') { hurtP(W, h.ref, dmg * 0.6, o, dx, dy, kn * 0.5); return 0; }
    if (h.k === 't') { h.ref.hp -= dmg * 0.5; return 0; }
    if (h.k === 'v') { h.ref.hp -= dmg * (ap >= 3 ? 0.5 : 0.1); return 0; }
    if (h.k === 'c') { hurtCiv(W, h.ref, dmg * 0.6); return 0; }
    if (h.k === 'r') { h.ref.hp -= dmg * 0.15; return 0; }
    return 0;
  }
  function wpOf(p) { if (p.veh >= 0) return MECHW; if (p.w === 2 && p.sw) return SUPW[p.sw]; return p.w === 1 ? SEC[p.lo[1]] : PRI[p.lo[0]]; }
  function fireWeapon(W, p, wp) {
    const A = ARM[p.A], ads = p.ads ? 0.45 : 1, mv = hyp(p.mvx, p.mvy) > 0.2 ? 1.35 : 1;
    const spread = wp.sp * ads * mv + p.rec;
    const mx = p.x + Math.cos(p.a) * 0.55, my = p.y + Math.sin(p.a) * 0.55;
    p.fc = (p.fc + 1) % 1000;
    p.rec = Math.min(0.3, p.rec + wp.rc * (A.pk === 'eng' ? 0.7 : 1) * (p.ads ? 0.7 : 1));
    if (wp.flame) {
      for (let k = 0; k < 2; k++) { const a = p.a + (Math.random() - 0.5) * wp.sp; W.pr.push({ id: W.nid++, k: 10, x: mx, y: my, vx: Math.cos(a) * 11, vy: Math.sin(a) * 11, l: wp.rg / 11, o: p.s, dm: wp.dmg, ap: wp.ap, ex: 0, kn: 0 }); }
      return;
    }
    if (wp.pj) { const a = p.a + (Math.random() - 0.5) * spread; W.pr.push({ id: W.nid++, k: wp.id === 'at' ? 5 : wp.id === 'mc' ? 9 : 4, x: mx, y: my, vx: Math.cos(a) * wp.pj, vy: Math.sin(a) * wp.pj, l: wp.rg / wp.pj, o: p.s, dm: wp.dmg, ap: wp.ap, ex: wp.ex || 0, kn: wp.kn }); return; }
    const n = wp.pel || 1;
    for (let k = 0; k < n; k++) {
      const a = p.a + (Math.random() - 0.5) * spread, dx = Math.cos(a), dy = Math.sin(a);
      const R = rayHit(W, mx, my, dx, dy, wp.rg, p.s, wp.pierce);
      for (const h of R.hits) { const fall = n > 1 ? clamp(1.25 - h.t / wp.rg, 0.25, 1) : 1; applyHit(W, h, wp.dmg * fall, wp.ap, p.s, dx, dy, wp.kn); }
      if (wp.pierce) fx(W, FX.RAIL, mx, my, Math.round((mx + dx * R.wall) * 10), Math.round((my + dy * R.wall) * 10));
    }
  }

  /* ----- 지원 요청 실행 ----- */
  function throwBeacon(W, p, si, tx, ty) {
    const d = hyp(tx - p.x, ty - p.y), a = Math.atan2(ty - p.y, tx - p.x), dd = clamp(d, 0.5, 13);
    W.pr.push({ id: W.nid++, k: 7, x: p.x, y: p.y, vx: Math.cos(a) * 12, vy: Math.sin(a) * 12, l: dd / 12, o: p.s, si, a, ap: 0, dm: 0, ex: 0, kn: 0 });
    p.calls++; W.sk[p.s][3]++;
  }
  function canCall(W, p, slot) {
    if (!p.al || p.drop > 0 || p.boarded || slot < 0 || slot >= 6) return false;
    if (W.t >= W.tl) return false;
    const si = p.sl[slot]; if (si === undefined) return false;
    if (p.cd[slot] > 0 || p.nU[slot] === 0) return false;
    if (si === S_RE && (W.rein <= 0 || !W.pl.some((q) => !q.al && !q.pod))) return false;
    if (si === SI.vh_mech && W.vh.some((v) => v.o === p.s)) return false;
    return true;
  }
  function useSlot(W, p, slot, tx, ty) {
    if (!canCall(W, p, slot)) return false;
    const si = p.sl[slot], S = STR[si];
    if (si === S_RE) { const q = W.pl.find((z) => !z.al && !z.pod); if (q) q.pod = 1; }
    p.cd[slot] = cdOf(W, si);
    if (p.nU[slot] > 0) { p.nU[slot]--; if (p.nU[slot] === 0 && S.cat === '항공') { p.rearm[slot] = 1; p.cd[slot] = 130 * (1 - 0.2 * (W.upg[UI.eag] | 0)) * DIFF[W.dif].cdm; } }
    throwBeacon(W, p, si, tx, ty);
    return true;
  }
  function landBeacon(W, b) {
    const S = STR[b.si];
    W.bc.push({ id: W.nid++, si: b.si, x: b.x, y: b.y, t: S.dl, T: S.dl, o: b.o, a: b.a });
    fx(W, FX.BEAC, b.x, b.y, b.si, b.o);
  }
  function strike(W, b) {
    const S = STR[b.si], id = S.id, o = b.o, x = b.x, y = b.y, up = W.upg;
    const defM = 1 + 0.4 * (up[UI.def] | 0);
    const pod = () => boom(W, x, y, 1.0, 160, 3, o, 3, { pm: 1 });
    if (id === 'ob_prec') boom(W, x, y, 3.5, 1100, 5, o, 9);
    else if (id === 'ob_bar') W.ef.push({ k: 'bar', x, y, t: 8.5, n: 14, cd: 0.2, o });
    else if (id === 'ob_las') W.ef.push({ k: 'las', x, y, t: 10, o, tx: x, ty: y });
    else if (id === 'ob_ems') boom(W, x, y, 7, 0, 0, o, 1, { stun: 6, pm: 0 });
    else if (id === 'ob_rail') {
      let best = null, bs = -1e9; for (const e of W.en) { if (e.hp <= 0) continue; const d = hyp(e.x - x, e.y - y); if (d < 9) { const s = e.mhp - d * 10; if (s > bs) { bs = s; best = e; } } }
      if (best) { hurtE(W, best, 4000, 6, o, 0, 0, 0, 'x'); fx(W, FX.RAIL, best.x, best.y - 30, Math.round(best.x * 10), Math.round(best.y * 10)); fx(W, FX.BOOM, best.x, best.y, 16, 0); }
      else boom(W, x, y, 1.6, 900, 5, o, 4);
    }
    else if (id === 'ea_str') W.ef.push({ k: 'str', x, y, a: b.a, t: 3, s: -1, o });
    else if (id === 'ea_clu') W.ef.push({ k: 'clu', x, y, a: b.a, t: 3, s: -1, o, n: 12 });
    else if (id === 'ea_500') boom(W, x, y, 5.2, 1600, 5, o, 11);
    else if (id === 'df_mg' || id === 'df_rk') { const rk = id === 'df_rk'; const hp = Math.round((rk ? 400 : 360) * defM); W.tu.push({ id: W.nid++, k: rk ? 1 : 0, x, y, a: b.a, hp, mhp: hp, am: Math.round((rk ? 18 : 300) * defM), cd: 0, o, dt: 1.0, idle: 0 }); pod(); }
    else if (id === 'df_mine') { for (let k = 0; k < 14; k++) { const q = openNear(W.M, x, y, W.R, 5, 0); W.mn.push({ id: W.nid++, x: r1(q[0]), y: r1(q[1]), o, arm: 1.5 }); } }
    else if (id === 'df_bub') W.sb.push({ id: W.nid++, x, y, t: 20 * defM, r: 4.5 });
    else if (id === 'vh_mech') { W.vh.push({ id: W.nid++, x, y, a: b.a, hp: 1100, mhp: 1100, dr: -1, cd: 0, rk: 14, rkc: 0, o, mvx: 0, mvy: 0 }); pod(); }
    else if (id === 'm_sup') { for (let k = 0; k < 4; k++) W.it.push({ id: W.nid++, k: 2, x: x + Math.cos(k * 1.57) * 0.7, y: y + Math.sin(k * 1.57) * 0.7 }); pod(); }
    else if (S.w) { W.it.push({ id: W.nid++, k: 3, x, y, w: S.w, o }); pod(); }
    else if (id === 'bp_sh') { W.it.push({ id: W.nid++, k: 4, x, y, o }); pod(); }
    else if (id === 'm_re') {
      const q = W.pl.find((z) => !z.al && z.pod) || W.pl.find((z) => !z.al);
      if (q && W.rein > 0) { W.rein--; revive(W, q, x, y); boom(W, x, y, 1.1, 150, 3, o, 4, { pm: 1 }); fx(W, FX.POD, x, y, q.s, 0); }
    }
  }
  function revive(W, q, x, y) {
    const n = mkPlayer(W, q.s, q.lo, x, y);
    n.cd = q.cd; n.nU = q.nU; n.rearm = q.rearm; n.kills = q.kills; n.deaths = q.deaths; n.tk = q.tk; n.calls = q.calls; n.drop = 1.0; n.fc = q.fc;
    W.pl[q.s] = n;
  }
  function stepEffects(W, dt) {
    for (const f of W.ef) {
      f.t -= dt;
      if (f.k === 'bar') { f.cd -= dt; if (f.cd <= 0 && f.n > 0) { f.cd = 8 / 14; f.n--; const a = Math.random() * TAU, d = Math.sqrt(Math.random()) * 8; boom(W, f.x + Math.cos(a) * d, f.y + Math.sin(a) * d, 3, 600, 5, f.o, 6); } }
      else if (f.k === 'las') {
        let best = null, bd = 12; for (const e of W.en) { if (e.hp <= 0) continue; const d = hyp(e.x - f.tx, e.y - f.ty); if (d < bd) { bd = d; best = e; } }
        if (best) { const d = hyp(best.x - f.tx, best.y - f.ty), m = Math.min(d, 7 * dt); if (d > 0) { f.tx += (best.x - f.tx) / d * m; f.ty += (best.y - f.ty) / d * m; } }
        hurtAll(W, f.tx, f.ty, 1.3, 420 * dt, 6, f.o, 0, { pm: 1.2, burn: 2 });
        f.fxT = (f.fxT || 0) - dt; if (f.fxT <= 0) { f.fxT = 0.2; fx(W, FX.LASER, f.tx, f.ty, Math.round(f.tx * 10), Math.round(f.ty * 10)); }
      }
      else if (f.k === 'str' || f.k === 'clu') {
        const sp = f.k === 'str' ? 16 : 13, ps = f.s; f.s += sp * dt;
        const ca = Math.cos(f.a), sa = Math.sin(f.a);
        if (f.k === 'str') { for (let s = Math.ceil(ps * 2); s <= f.s * 2; s++) { const d = s / 2, px = f.x + ca * d + (Math.random() - 0.5) * 1.6, py = f.y + sa * d + (Math.random() - 0.5) * 1.6; hurtAll(W, px, py, 1.1, 120, 3, f.o, 2, { pm: 0.9 }); if (s % 2 === 0) fx(W, FX.BOOM, px, py, 7, 4); } }
        else { for (let s = Math.ceil(ps); s <= f.s; s++) { if (f.n <= 0) break; f.n--; const px = f.x + ca * s + (Math.random() - 0.5) * 2.4, py = f.y + sa * s + (Math.random() - 0.5) * 2.4; boom(W, px, py, 2.4, 260, 3, f.o, 4); } }
        if (f.s > 12) f.t = 0;
      }
      else if (f.k === 'spn') { if (f.t <= 0) { const g = patrol(W, f.x, f.y, f.n, -3, 1, f.x, f.y); g.forEach((e) => { e.spn = 0.6; }); } }
    }
    W.ef = W.ef.filter((f) => f.t > 0);
  }

  /* ----- 움직임 ----- */
  function blocked(M, x, y, r) { return solid(M, x - r, y - r) || solid(M, x + r, y - r) || solid(M, x - r, y + r) || solid(M, x + r, y + r) || solid(M, x, y); }
  function moveC(M, o, dx, dy, r) {
    let hit = 0;
    if (dx) { if (!blocked(M, o.x + dx, o.y, r)) o.x += dx; else hit = 1; }
    if (dy) { if (!blocked(M, o.x, o.y + dy, r)) o.y += dy; else hit = 1; }
    o.x = clamp(o.x, 1.5, MS - 1.5); o.y = clamp(o.y, 1.5, MS - 1.5);
    return hit;
  }
  const inBush = (M, x, y) => M.at(Math.floor(x), Math.floor(y)) === 2;

  /* ----- 대원 ----- */
  function refill(W, p, full) {
    const sup = ARM[p.A].pk === 'supp' ? 1.5 : 1;
    const ws = [PRI[p.lo[0]], SEC[p.lo[1]]];
    for (let k = 0; k < 2; k++) { const S = p.W[k], mx = Math.round(ws[k].rsv * sup); S.rsv = full ? mx : Math.min(mx, S.rsv + Math.round(mx * 0.6)); }
    if (p.W[2] && p.sw) { const sw = SUPW[p.sw]; p.W[2].rsv = Math.min(sw.rsv, p.W[2].rsv + Math.ceil(sw.rsv * 0.6)); }
    p.gr = p.grm; p.stim = p.stm0;
  }
  function needsSupply(p) { return p.gr < p.grm || p.stim < p.stm0 || p.W[0].rsv < PRI[p.lo[0]].rsv * 0.85 || p.W[1].rsv < SEC[p.lo[1]].rsv * 0.85; }
  function throwGrenade(W, p, tx, ty) {
    const G = GRE[p.lo[2]], d = clamp(hyp(tx - p.x, ty - p.y), 1.5, 14), a = Math.atan2(ty - p.y, tx - p.x);
    W.pr.push({ id: W.nid++, k: 6, x: p.x + Math.cos(a) * 0.4, y: p.y + Math.sin(a) * 0.4, vx: Math.cos(a) * d * 3, vy: Math.sin(a) * d * 3, l: 6, f: G.fuse || 9, gi: p.lo[2], o: p.s, dm: G.dmg, ap: G.ap, ex: G.r, kn: 5, imp: G.fuse ? 0 : 1, age: 0 });
    fx(W, FX.GREN, p.x, p.y, p.s, 0);
  }
  function interact(W, p) {
    const near = (o, r) => hyp(o.x - p.x, o.y - p.y) < (r || 2.4);
    for (const v of W.vh) if (v.dr < 0 && near(v, 2)) { v.dr = p.s; p.veh = v.id; p.x = v.x; p.y = v.y; p.w = 0; return; }
    for (let i = 0; i < W.ob.length; i++) {
      const o = W.ob[i]; if (!near(o)) continue;
      if (o.k === 'term' && o.s === 0) { p.tm = i; return; }
      if (o.k === 'gen' && o.s === 0) { o.s = 2; fx(W, FX.OBJ, o.x, o.y, 3, 0); return; }
      if (o.k === 'zone' && o.s === 0) { o.s = 1; W.waveT = 4; fx(W, FX.OBJ, o.x, o.y, 4, 0); return; }
      if (o.k === 'silo' && o.s === 0 && W.ob.filter((q) => q.k === 'gen').every((q) => q.s === 2)) { p.tm = i; return; }
      if (o.k === 'silo' && o.s === 0) { fx(W, FX.NOPE, o.x, o.y, 1, p.s); return; }
      if (o.k === 'shel' && o.s === 0) { o.s = 1; o.ot = 0.5; fx(W, FX.OBJ, o.x, o.y, 6, 0); W.waveT = 6; return; }
    }
    for (let i = 0; i < W.sd.length; i++) {
      const o = W.sd[i]; if (!near(o) || o.s) continue;
      if (o.k === 'cache') { o.s = 2; W.it.push({ id: W.nid++, k: 0, x: o.x + 0.8, y: o.y, n: 3 }); W.it.push({ id: W.nid++, k: 2, x: o.x - 0.8, y: o.y }); fx(W, FX.OBJ, o.x, o.y, 21, 0); return; }
      if (o.k === 'beacon') { p.tm = 100 + i; return; }
    }
    if (W.ex.ph === 1 && near(W.ex, 2.6)) { W.ex.ph = 2; W.ex.t = 60 + W.dif * 6; W.waveT = 3; fx(W, FX.EXT, W.ex.x, W.ex.y, 2, 0); return; }
  }
  function codeDone(W, p, k) {
    if (k !== p.tm || k < 0) return;
    p.tm = -1;
    if (k >= 100) { const o = W.sd[k - 100]; if (o && !o.s && hyp(o.x - p.x, o.y - p.y) < 3.5) { o.s = 2; W.bonus = (W.bonus | 0) + 1; fx(W, FX.OBJ, o.x, o.y, 22, 0); } return; }
    const o = W.ob[k]; if (!o || o.s || hyp(o.x - p.x, o.y - p.y) > 3.5) return;
    o.s = 1; W.waveT = 4; fx(W, FX.OBJ, o.x, o.y, o.k === 'silo' ? 5 : 2, 0);
  }
  function stepPlayer(W, p, I, dt) {
    if (p.drop > 0) { p.drop -= dt; if (p.drop <= 0) { boom(W, p.x, p.y, 1.6, 300, 3, p.s, 6, { noP: 1 }); fx(W, FX.POD, p.x, p.y, p.s, 1); } return; }
    for (let k = 0; k < 6; k++) { if (p.cd[k] > 0) { p.cd[k] -= dt; if (p.cd[k] <= 0) { p.cd[k] = 0; if (p.rearm[k]) { p.rearm[k] = 0; p.nU[k] = usesOf(W, p.sl[k]); } } } }
    if (!p.al || p.boarded) return;
    I = I || {};
    p.inv -= dt; p.stun -= dt; p.hit -= dt; p.dvc -= dt; p.mel -= dt; p.grc -= dt; p.ffT -= dt; p.melT -= dt;
    p.rec = Math.max(0, p.rec - dt * 0.9);
    if (p.bp) { p.shT -= dt; if (p.shT <= 0) p.sh = Math.min(p.shm, p.sh + 70 * dt); }
    if (p.rg > 0) { p.rg -= dt; p.hp = Math.min(p.mhp, p.hp + (ARM[p.A].pk === 'med' ? 30 : 55) * dt); }
    if (I.th && fin(I.th.x) && fin(I.th.y)) { if (!useSlot(W, p, I.th.sl | 0, I.th.x, I.th.y)) fx(W, FX.NOPE, p.x, p.y, 0, p.s); }
    if (I.tc !== undefined && I.tc !== null && I.tc >= 0) codeDone(W, p, I.tc | 0);
    if (I.tq) p.tm = -1;
    if (fin(I.ax) && fin(I.ay) && hyp(I.ax - p.x, I.ay - p.y) > 0.05) p.a = Math.atan2(I.ay - p.y, I.ax - p.x);
    let mx = fin(I.mx) ? clamp(I.mx, -1, 1) : 0, my = fin(I.my) ? clamp(I.my, -1, 1) : 0; const ml = hyp(mx, my); if (ml > 1) { mx /= ml; my /= ml; }
    if (p.tm >= 0) { mx = my = 0; const o = p.tm >= 100 ? W.sd[p.tm - 100] : W.ob[p.tm]; if (!o || hyp(o.x - p.x, o.y - p.y) > 3.5) p.tm = -1; }
    if (p.stun > 0) { mx = my = 0; }
    // 탑승: 보행기
    if (p.veh >= 0) {
      const v = W.vh.find((q) => q.id === p.veh);
      if (!v) { p.veh = -1; return; }
      v.cd -= dt; v.rkc -= dt;
      moveC(W.M, v, mx * 3.2 * dt, my * 3.2 * dt, 0.8); p.x = v.x; p.y = v.y; p.mvx = mx; p.mvy = my; v.a = p.a;
      if (I.fire && v.cd <= 0) { v.cd = MECHW.iv; fireWeapon(W, p, MECHW); }
      if (I.gr && v.rk > 0 && v.rkc <= 0) { v.rk--; v.rkc = 0.5; const a = p.a; W.pr.push({ id: W.nid++, k: 5, x: v.x + Math.cos(a), y: v.y + Math.sin(a), vx: Math.cos(a) * 28, vy: Math.sin(a) * 28, l: 1.3, o: p.s, dm: 420, ap: 4, ex: 1.6, kn: 4 }); }
      if (I.ie) { p.veh = -1; v.dr = -1; p.x = v.x + 1.1; p.y = v.y; if (blocked(W.M, p.x, p.y, 0.36)) p.x = v.x - 1.1; fx(W, FX.EJECT, v.x, v.y, 0, 0); }
      return;
    }
    p.mvx = mx; p.mvy = my;
    p.ads = I.ads ? 1 : 0;
    const wp = wpOf(p), ws = p.W[p.w] || p.W[0];
    if (p.dv > 0) { p.dv -= dt; moveC(W.M, p, p.dvx * 9 * dt, p.dvy * 9 * dt, 0.36); if (p.dv <= 0) p.dv = -0.3; return; }
    if (p.dv < 0) { p.dv = Math.min(0, p.dv + dt); mx = my = 0; }
    if (I.dv && p.dvc <= 0 && ml > 0.2 && p.stun <= 0) { p.dv = 0.32; p.dvx = mx / (hyp(mx, my) || 1); p.dvy = my / (hyp(mx, my) || 1); p.dvc = 1.1; if (ARM[p.A].pk === 'assa') p.inv = 0.6; return; }
    const firing = !!I.fire && p.tm < 0;
    let sp = 4.3 * ARM[p.A].sp;
    p.spr = 0;
    if (I.spr && p.stm > 0.05 && ml > 0.2 && !firing && !p.ads) { sp *= 1.55; p.stm = Math.max(0, p.stm - 0.2 * dt); p.spr = 1; } else p.stm = Math.min(1, p.stm + 0.16 * dt);
    if (p.ads) sp *= 0.6; if (inBush(W.M, p.x, p.y)) sp *= 0.85; if (firing && wp.slow) sp *= wp.slow;
    const kd = Math.exp(-7 * dt);
    moveC(W.M, p, (mx * sp + p.vx) * dt, (my * sp + p.vy) * dt, 0.36);
    p.vx *= kd; p.vy *= kd;
    // 무기 바꾸기 · 장전
    if (I.sw !== undefined && I.sw !== null && I.sw >= 0 && I.sw <= 2 && I.sw !== p.w && (I.sw < 2 || p.sw)) { ws.rl = 0; p.w = I.sw | 0; }
    const S = p.W[p.w] || p.W[0];
    S.cd -= dt;
    if (S.rl > 0) { S.rl -= dt; if (S.rl <= 0) { const take = Math.min(wp.mag - S.mag, S.rsv); S.mag += take; S.rsv -= take; S.rl = 0; } }
    if (I.rl && S.rl <= 0 && S.mag < wp.mag && S.rsv > 0) S.rl = wp.rl;
    if (S.bl > 0 && S.cd <= 0 && S.mag > 0) { fireWeapon(W, p, wp); S.mag--; S.bl--; S.cd = S.bl > 0 ? wp.iv : wp.bgap; }
    else if (firing && S.cd <= 0 && S.rl <= 0 && p.stun <= 0) {
      if (S.mag > 0) { fireWeapon(W, p, wp); S.mag--; if (wp.burst) { S.bl = wp.burst - 1; S.cd = wp.iv; } else S.cd = wp.iv; }
      else if (S.rsv > 0) S.rl = wp.rl; else { S.cd = 0.4; if (p.w === 0 && p.W[1].mag + p.W[1].rsv > 0) p.w = 1; }
    }
    if (I.gr && p.gr > 0 && p.grc <= 0 && fin(I.ax)) { p.gr--; p.grc = 0.7; throwGrenade(W, p, I.ax, I.ay); }
    if (I.ml && p.mel <= 0) {
      p.mel = 0.75; p.melT = 0.2; const dm = ARM[p.A].pk === 'assa' ? 130 : 65;
      for (const e of W.en) { if (e.hp <= 0) continue; const dx = e.x - p.x, dy = e.y - p.y, d = hyp(dx, dy); if (d < 1.3 + EN[e.t].r && Math.abs(wrapA(Math.atan2(dy, dx) - p.a)) < 1.0) hurtE(W, e, dm, 2, p.s, dx, dy, 5, 'm'); }
      for (const q of W.pl) { if (q === p || !q.al) continue; const dx = q.x - p.x, dy = q.y - p.y; if (hyp(dx, dy) < 1.2 && Math.abs(wrapA(Math.atan2(dy, dx) - p.a)) < 0.8) hurtP(W, q, 20, p.s, dx, dy, 4); }
      fx(W, FX.MEL, p.x + Math.cos(p.a) * 0.8, p.y + Math.sin(p.a) * 0.8, p.s, 0);
    }
    if (I.stim && p.stim > 0 && p.hp < p.mhp && p.rg <= 0) { p.stim--; p.rg = ARM[p.A].pk === 'med' ? 6 : 2; fx(W, FX.STIM, p.x, p.y, p.s, 0); }
    if (I.ie) interact(W, p);
    // 줍기
    for (const it of W.it) {
      if (it.gone || hyp(it.x - p.x, it.y - p.y) > 0.85) continue;
      if (it.k === 0 || it.k === 5) { p.smp += it.n || 1; it.gone = 1; fx(W, FX.SMP, it.x, it.y, p.s, it.n || 1); }
      else if (it.k === 2) { if (needsSupply(p) || (p.sw && p.W[2] && p.W[2].rsv < SUPW[p.sw].rsv)) { refill(W, p, 0); it.gone = 1; fx(W, FX.PICK, it.x, it.y, p.s, 2); if (ARM[p.A].pk === 'supp') for (const q of W.pl) if (q !== p && q.al && hyp(q.x - p.x, q.y - p.y) < 6) refill(W, q, 0); } }
      else if (it.k === 3) { if (!p.sw && (it.o === undefined || it.o === p.s || W.t - (it.t0 || 0) > 0 || true)) { p.sw = it.w; const sw = SUPW[it.w]; p.W[2] = { mag: it.m !== undefined ? it.m : sw.mag, rsv: it.r !== undefined ? it.r : sw.rsv, cd: 0, rl: 0, bl: 0 }; p.w = 2; it.gone = 1; fx(W, FX.PICK, it.x, it.y, p.s, 3); } }
      else if (it.k === 4) { if (!p.bp) { p.bp = 1; p.shm = 200; p.sh = 200; it.gone = 1; fx(W, FX.PICK, it.x, it.y, p.s, 4); } }
    }
  }

  /* ----- 투사체 ----- */
  function stepProj(W, dt) {
    for (const b of W.pr) {
      if (b.dead) continue;
      b.l -= dt;
      if (b.k === 7) { const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt; if (solid(W.M, nx, ny) || b.l <= 0) { b.dead = 1; landBeacon(W, b); } else { b.x = nx; b.y = ny; } continue; }
      if (b.k === 6) {
        b.age += dt; const k = Math.exp(-3 * dt); b.vx *= k; b.vy *= k;
        const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt;
        if (solid(W.M, nx, b.y)) { b.vx *= -0.4; if (b.imp && b.age > 0.15) b.f = 0; } else b.x = nx;
        if (solid(W.M, b.x, ny)) { b.vy *= -0.4; if (b.imp && b.age > 0.15) b.f = 0; } else b.y = ny;
        if (b.imp) { if (b.age > 0.1 && W.en.some((e) => e.hp > 0 && hyp(e.x - b.x, e.y - b.y) < EN[e.t].r + 0.25)) b.f = 0; else if (hyp(b.vx, b.vy) < 1.2) b.f = 0; else b.f = 9; }
        else b.f -= dt;
        if (b.f <= 0) { b.dead = 1; const G = GRE[b.gi]; if (G.id === 'stun') boom(W, b.x, b.y, G.r, 0, 0, b.o, 1, { stun: G.stun, pm: 0 }); else if (G.id === 'fire') { boom(W, b.x, b.y, G.r, G.dmg, G.ap, b.o, 2, { burn: 4 }); W.fi.push({ id: W.nid++, x: b.x, y: b.y, r: G.r, t: G.burn, o: b.o }); } else boom(W, b.x, b.y, G.r, G.dmg, G.ap, b.o, 6); }
        continue;
      }
      const nx = b.x + b.vx * dt, ny = b.y + b.vy * dt;
      const enemyShot = b.o === -1;
      if (enemyShot) for (const s of W.sb) { const d0 = hyp(b.x - s.x, b.y - s.y), d1 = hyp(nx - s.x, ny - s.y); if (d0 > s.r && d1 <= s.r) { b.dead = 1; fx(W, FX.BNC, nx, ny, 1, 0); break; } }
      if (b.dead) continue;
      if (solid(W.M, nx, ny) || b.l <= 0) { b.dead = 1; if (b.ex) { if (enemyShot) enemyBoom(W, b, b.x, b.y); else boom(W, b.x, b.y, b.ex, b.dm, b.ap, b.o, b.kn); } continue; }
      b.x = nx; b.y = ny;
      if (enemyShot) {
        let hit = null;
        for (const p of W.pl) if (p.al && !(p.drop > 0) && !p.boarded && hyp(p.x - b.x, p.y - b.y) < (p.veh >= 0 ? 0.95 : 0.42)) { hit = p; break; }
        if (hit) { b.dead = 1; if (b.ex) enemyBoom(W, b, b.x, b.y); else hurtP(W, hit, b.dm, -1, b.vx, b.vy, b.kn); continue; }
        for (const t of W.tu) if (hyp(t.x - b.x, t.y - b.y) < 0.5) { b.dead = 1; t.hp -= b.dm; if (b.ex) enemyBoom(W, b, b.x, b.y); break; }
        if (b.dead) continue;
        for (const c of W.cv) if (c.hp > 0 && hyp(c.x - b.x, c.y - b.y) < 0.35) { b.dead = 1; hurtCiv(W, c, b.dm); break; }
        if (!b.dead && W.cr && hyp(W.cr.x - b.x, W.cr.y - b.y) < 1) { b.dead = 1; W.cr.hp -= b.dm * 0.5; }
        continue;
      }
      // 아군 투사체: 적·다른 대원
      let hit = null;
      for (const e of W.en) if (e.hp > 0 && hyp(e.x - b.x, e.y - b.y) < EN[e.t].r + 0.12) { hit = e; break; }
      if (hit) {
        b.dead = 1;
        if (b.k === 10) { hurtE(W, hit, b.dm, b.ap, b.o, b.vx, b.vy, 0, 'b'); if (EN[hit.t].tier < 3) hit.burn = Math.max(hit.burn, 3); }
        else if (b.ex) { hurtE(W, hit, b.dm * 0.5, b.ap, b.o, b.vx, b.vy, b.kn, 'b'); boom(W, b.x, b.y, b.ex, b.dm * 0.5, b.ap, b.o, b.kn); }
        else hurtE(W, hit, b.dm, b.ap, b.o, b.vx, b.vy, b.kn, 'b');
        continue;
      }
      for (const p of W.pl) if (p.al && p.s !== b.o && !(p.drop > 0) && !p.boarded && p.veh < 0 && hyp(p.x - b.x, p.y - b.y) < 0.4) { b.dead = 1; if (b.ex) boom(W, b.x, b.y, b.ex, b.dm, b.ap, b.o, b.kn); else hurtP(W, p, b.dm * 0.6, b.o, b.vx, b.vy, b.kn); break; }
    }
    W.pr = W.pr.filter((b) => !b.dead);
  }
  function enemyBoom(W, b, x, y) {
    for (const p of W.pl) { if (!p.al) continue; const d = hyp(p.x - x, p.y - y); if (d < b.ex + 0.4) hurtP(W, p, b.dm * (1 - 0.5 * d / (b.ex + 0.4)), -1, p.x - x, p.y - y, b.kn, 1); }
    for (const t of W.tu) if (hyp(t.x - x, t.y - y) < b.ex + 0.5) t.hp -= b.dm;
    for (const c of W.cv) if (c.hp > 0 && hyp(c.x - x, c.y - y) < b.ex + 0.3) hurtCiv(W, c, b.dm);
    if (W.cr && hyp(W.cr.x - x, W.cr.y - y) < b.ex + 1) W.cr.hp -= b.dm * 0.5;
    fx(W, FX.BOOM, x, y, Math.round(b.ex * 10), b.k === 1 ? 5 : 6);
  }

  /* ----- 적 ----- */
  function eShoot(W, e, tx, ty) {
    const T = EN[e.t], a = Math.atan2(ty - e.y, tx - e.x) + (Math.random() - 0.5) * 0.12, ca = Math.cos(a), sa = Math.sin(a), sx = e.x + ca * T.r, sy = e.y + sa * T.r;
    const add = (k, sp, dm, ex, kn) => W.pr.push({ id: W.nid++, k, x: sx, y: sy, vx: ca * sp, vy: sa * sp, l: (T.rg + 4) / sp, o: -1, dm: dm * W.edm, ap: 2, ex, kn });
    if (T.at === 's') { if (T.f === 2) add(8, 18, T.dm, 0.6, 2); else add(1, T.big ? 13 : 11, T.dm, T.big ? 1.8 : 1.0, T.big ? 5 : 1); }
    else if (T.at === 'b') add(0, 26, T.dm, 0, 0.5);
    else if (T.at === 'k') add(2, 15, T.dm, 1.5, 6);
    else if (T.at === 'c') add(3, 20, T.dm, 2.0, 8);
  }
  function targets(W) {
    const out = [];
    for (const p of W.pl) if (p.al && !(p.drop > 0) && !p.boarded) out.push({ k: 'p', i: p.s, x: p.x, y: p.y, o: p });
    for (const t of W.tu) if (t.dt <= 0) out.push({ k: 't', x: t.x, y: t.y, o: t });
    for (const c of W.cv) if (c.hp > 0) out.push({ k: 'c', x: c.x, y: c.y, o: c });
    if (W.cr && W.cr.hp > 0) out.push({ k: 'r', x: W.cr.x, y: W.cr.y, o: W.cr });
    return out;
  }
  function hitTarget(W, tg, dm, dx, dy, kn) {
    dm *= W.edm;
    if (tg.k === 'p') hurtP(W, tg.o, dm, -1, dx, dy, kn);
    else if (tg.k === 't') tg.o.hp -= dm;
    else if (tg.k === 'c') hurtCiv(W, tg.o, dm);
    else if (tg.k === 'r') tg.o.hp -= dm * 0.5;
  }
  function stepEnemies(W, dt) {
    const TG = targets(W), D = DIFF[W.dif];
    const scoutK = (p) => (ARM[p.A].pk === 'scout' ? 0.7 : 1);
    for (const e of W.en) {
      if (e.hp <= 0) continue;
      const T = EN[e.t];
      if (T.tier === 3) {
        if (e.t === EI.hive) { e.cd -= dt; if (e.cd <= 0) { e.cd = 18 / D.den; if (W.pl.some((p) => p.al && hyp(p.x - e.x, p.y - e.y) < 20) && W.en.length < 35 + 20 * D.den) { const g = patrol(W, e.x, e.y, 1 + Math.round(D.den * 1.5), -3, 1, e.x, e.y); g.forEach((q) => { q.spn = 0.6; }); } } }
        continue;
      }
      if (e.spn > 0) { e.spn -= dt; continue; }
      if (e.burn > 0) { e.burn -= dt; e.hp -= 30 * dt; if (e.hp <= 0) { fx(W, FX.EDIE, e.x, e.y, e.t, 0); continue; } }
      const kd = Math.exp(-6 * dt);
      if (e.vx || e.vy) { if (T.fly) { e.x = clamp(e.x + e.vx * dt, 1.5, MS - 1.5); e.y = clamp(e.y + e.vy * dt, 1.5, MS - 1.5); } else moveC(W.M, e, e.vx * dt, e.vy * dt, T.r * 0.8); e.vx *= kd; e.vy *= kd; if (Math.abs(e.vx) + Math.abs(e.vy) < 0.05) e.vx = e.vy = 0; }
      if (e.stun > 0) { e.stun -= dt; e.ch = 0; continue; }
      e.cd -= dt; e.bk -= dt; e.wt -= dt;
      // 목표 찾기
      if (e.wt <= 0) {
        e.wt = 0.35 + Math.random() * 0.2;
        let best = null, bd = 1e9;
        for (const t of TG) {
          const d = hyp(t.x - e.x, t.y - e.y);
          let det = e.st ? 22 : 13;
          if (t.k === 'p') { det *= scoutK(t.o); if (inBush(W.M, t.x, t.y)) det *= 0.6; if (t.o.spr) det *= 1.2; }
          if (d > det) continue;
          if (!(T.fly || los(W.M, e.x, e.y, t.x, t.y))) { if (!(e.st && e.tg && e.tg.k === t.k && e.tg.o === t.o && d < 26)) continue; }
          const s = d * (t.k === 'p' ? 1 : t.k === 't' ? 0.9 : 1.6);
          if (s < bd) { bd = s; best = t; }
        }
        if (best) {
          if (e.st === 0 && e.grp >= 0) for (const q of W.en) if (q.grp === e.grp && q.st === 0 && hyp(q.x - e.x, q.y - e.y) < 12) { q.st = 1; q.tg = best; q.mem = 8; }
          e.tg = best; e.st = 1; e.mem = 8;
        } else if (e.st) { e.mem -= 0.4; if (e.mem <= 0) { e.st = 0; if (e.tg) { e.wx = e.tg.x; e.wy = e.tg.y; } e.tg = null; } }
      }
      let tg = e.tg;
      if (tg) { const o = tg.o; if (!o || (tg.k === 'p' && (!o.al || o.boarded)) || (tg.k === 't' && o.hp <= 0) || (tg.k === 'c' && o.hp <= 0) || (tg.k === 'r' && o.hp <= 0)) { e.tg = tg = null; } else { tg.x = o.x; tg.y = o.y; } }
      // 신호 부르기
      if (e.cl && tg && tg.k === 'p') {
        const seen = T.fly || los(W.M, e.x, e.y, tg.x, tg.y);
        if (seen && W.brCd <= 0) { e.al += dt; if (e.al > 2.6) { e.al = 0; e.cl = 0; W.brCd = (45 / D.den) * (W.tower ? 1 : 1.7); callIn(W, e.x, e.y, tg.x, tg.y); } }
        else e.al = Math.max(0, e.al - dt * 0.5);
      } else e.al = 0;
      // 이동
      let gx, gy, dist = 0, seeT = false;
      if (tg) { gx = tg.x; gy = tg.y; dist = hyp(gx - e.x, gy - e.y); seeT = T.fly || dist < 24 && los(W.M, e.x, e.y, gx, gy); }
      else { gx = e.wx; gy = e.wy; if (hyp(gx - e.x, gy - e.y) < 1.5) { if (e.grp === -2) { const q = openNear(W.M, e.wx, e.wy, W.R, 4, 0); e.wx = q[0]; e.wy = q[1]; } else { const q = openNear(W.M, e.x, e.y, W.R, 12, 4); e.wx = q[0]; e.wy = q[1]; } } }
      let dx = 0, dy = 0, spd = T.sp * (tg ? 1 : 0.4);
      // 돌진 · 도약
      if (e.ch === 1) { e.chT -= dt; if (e.chT <= 0) { e.ch = 2; e.chT = T.leap ? 0.32 : 1.3; e.hitL = []; } e.a += wrapA(Math.atan2(gy - e.y, gx - e.x) - e.a) * Math.min(1, dt * 6); continue; }
      if (e.ch === 2) {
        e.chT -= dt; const v = T.leap ? 13 : 12, cdx = Math.cos(e.a) * v * dt, cdy = Math.sin(e.a) * v * dt;
        const hit = moveC(W.M, e, cdx, cdy, T.r * 0.8);
        for (const t of TG) { if (hyp(t.x - e.x, t.y - e.y) < T.r + 0.5 && e.hitL.indexOf(t.o) < 0) { e.hitL.push(t.o); hitTarget(W, t, T.dm * (T.leap ? 1 : 1.2), Math.cos(e.a), Math.sin(e.a), T.leap ? 3 : 10); } }
        if (hit && !T.leap) { e.ch = 0; e.stun = 1.8; e.cd = 2.5; fx(W, FX.BNC, e.x, e.y, 2, 0); }
        if (e.chT <= 0) { e.ch = 0; e.cd = T.leap ? 1.4 : 2.6; }
        continue;
      }
      if (tg && T.at === 'x' && e.cd <= 0 && dist < 11 && dist > 2 && seeT) { e.ch = 1; e.chT = 0.7; continue; }
      if (tg && T.leap && e.cd <= 0 && dist > 2.5 && dist < 7 && seeT) { e.ch = 1; e.chT = 0.25; continue; }
      if (tg && T.blink && e.bk <= 0 && dist > 3.5 && dist < 14) {
        const side = Math.random() < 0.5 ? 1 : -1, ang = Math.atan2(e.y - gy, e.x - gx) + side * (1.2 + Math.random() * 0.8);
        const nx = gx + Math.cos(ang) * 2.2, ny = gy + Math.sin(ang) * 2.2;
        if (!blocked(W.M, nx, ny, T.r)) { fx(W, FX.BLINK, e.x, e.y, Math.round(nx * 10), Math.round(ny * 10)); e.x = nx; e.y = ny; e.bk = 4.5 + Math.random() * 2; e.cd = Math.max(e.cd, 0.35); }
        else e.bk = 1;
      }
      const ranged = T.at === 's' || T.at === 'b' || T.at === 'k' || T.at === 'c' || T.at === 'l';
      if (tg) {
        e.a += wrapA(Math.atan2(gy - e.y, gx - e.x) - e.a) * Math.min(1, dt * (T.big ? 1.5 : 6));
        if (ranged && seeT && dist < T.rg) {
          // 사거리 안: 옆걸음, 너무 가까우면 물러남
          const side = (e.id % 2 ? 1 : -1), px = -(gy - e.y) / dist, py = (gx - e.x) / dist;
          dx = px * side * 0.5; dy = py * side * 0.5;
          if (dist < T.rg * 0.45 && !T.big) { dx -= (gx - e.x) / dist * 0.8; dy -= (gy - e.y) / dist * 0.8; }
          spd *= 0.6;
        } else if (seeT && dist < 16 || T.fly) {
          let ax = gx, ay = gy; if (!ranged && dist < 5) { ax += Math.cos(e.off) * 0.8; ay += Math.sin(e.off) * 0.8; }
          const l = hyp(ax - e.x, ay - e.y) || 1; dx = (ax - e.x) / l; dy = (ay - e.y) / l;
        } else if (tg.k === 'p' && W.pf) { const f = flowDir(W.M, W.pf, e.x, e.y); if (f) { dx = f[0]; dy = f[1]; } }
        else { const l = dist || 1; dx = (gx - e.x) / l; dy = (gy - e.y) / l; }
        // 공격
        if (e.cd <= 0 && (seeT || T.fly) && dist < T.rg + T.r + 0.4) {
          if (T.at === 'm' || T.at === 'x') { if (dist < T.rg + T.r + 0.4) { hitTarget(W, tg, T.dm, gx - e.x, gy - e.y, 2.5); e.cd = T.ic; e.atk = 0.2; } }
          else if (T.at === 'l') { const ok = Math.random() < (T.big ? 0.8 : 0.65); if (ok) hitTarget(W, tg, T.dm, gx - e.x, gy - e.y, T.big ? 1 : 0); fx(W, FX.LASER, e.x, e.y, Math.round((gx + (ok ? 0 : (Math.random() - 0.5) * 2)) * 10), Math.round((gy + (ok ? 0 : (Math.random() - 0.5) * 2)) * 10)); e.cd = T.ic; }
          else if (T.at === 'b') { if (e.bl <= 0) e.bl = T.burst; eShoot(W, e, gx, gy); e.bl--; e.cd = e.bl > 0 ? T.ic : T.bgap + Math.random() * 0.6; }
          else { eShoot(W, e, gx, gy); e.cd = T.ic * (0.8 + Math.random() * 0.4); fx(W, FX.ESHOT, e.x, e.y, e.t, 0); }
        }
      } else {
        const l = hyp(gx - e.x, gy - e.y) || 1; dx = (gx - e.x) / l; dy = (gy - e.y) / l;
        if (!T.fly && !los(W.M, e.x, e.y, gx, gy)) { const q = openNear(W.M, e.x, e.y, W.R, 10, 3); e.wx = q[0]; e.wy = q[1]; }
        e.a += wrapA(Math.atan2(dy, dx) - e.a) * Math.min(1, dt * 3);
      }
      // 서로 밀어내기
      for (const q of W.en) { if (q === e || q.hp <= 0 || EN[q.t].fly !== T.fly) continue; const ox = e.x - q.x, oy = e.y - q.y, d = Math.abs(ox) + Math.abs(oy); if (d > 2.4) continue; const dd = hyp(ox, oy), m = T.r + EN[q.t].r; if (dd < m && dd > 0.001) { dx += ox / dd * 0.9 * (1 - dd / m) * 2; dy += oy / dd * 0.9 * (1 - dd / m) * 2; } }
      const l = hyp(dx, dy); if (l > 1) { dx /= l; dy /= l; }
      if (T.fly) { e.x = clamp(e.x + dx * spd * dt, 1.5, MS - 1.5); e.y = clamp(e.y + dy * spd * dt, 1.5, MS - 1.5); }
      else if (moveC(W.M, e, dx * spd * dt, dy * spd * dt, T.r * 0.8) && tg && W.pf) { const f = flowDir(W.M, W.pf, e.x, e.y); if (f) moveC(W.M, e, f[0] * spd * dt * 0.6, f[1] * spd * dt * 0.6, T.r * 0.8); }
      // 대원과 겹치지 않게
      for (const p of W.pl) { if (!p.al || p.boarded || p.drop > 0) continue; const ox = p.x - e.x, oy = p.y - e.y, d = hyp(ox, oy), m = T.r + 0.36; if (d < m && d > 0.001) { const push = (m - d); moveC(W.M, p, ox / d * push * 0.6, oy / d * push * 0.6, 0.36); if (!T.big) moveC(W.M, e, -ox / d * push * 0.4, -oy / d * push * 0.4, T.r * 0.8); } }
    }
    W.en = W.en.filter((e) => e.hp > 0);
  }
  function callIn(W, x, y, tx, ty) {
    const D = DIFF[W.dif], n = Math.round(4 + 5 * D.den);
    const q = openNear(W.M, (x + tx) / 2, (y + ty) / 2, W.R, 5, 2);
    W.ef.push({ k: 'spn', x: q[0], y: q[1], t: W.fac === 1 ? 3.5 : 2.2, n, f: W.fac });
    fx(W, FX.BREACH, q[0], q[1], W.fac, n);
  }
  function stepDefense(W, dt) {
    for (const t of W.tu) {
      if (t.dt > 0) { t.dt -= dt; continue; }
      t.cd -= dt;
      let best = null, bd = t.k ? 26 : 22;
      for (const e of W.en) { if (e.hp <= 0 || EN[e.t].tier === 3) continue; const d = hyp(e.x - t.x, e.y - t.y) - (t.k && EN[e.t].tier >= 1 ? 8 : 0); if (d < bd && los(W.M, t.x, t.y, e.x, e.y)) { bd = d; best = e; } }
      if (!best) continue;
      const want = Math.atan2(best.y - t.y, best.x - t.x), da = wrapA(want - t.a);
      t.a += clamp(da, -4 * dt, 4 * dt);
      if (Math.abs(da) < 0.12 && t.cd <= 0 && t.am > 0) {
        t.am--; t.fc = ((t.fc | 0) + 1) % 1000;
        if (t.k === 0) { t.cd = 0.11; const a = t.a + (Math.random() - 0.5) * 0.05, dx = Math.cos(a), dy = Math.sin(a); const R = rayHit(W, t.x + dx * 0.6, t.y + dy * 0.6, dx, dy, 24, -2); for (const h of R.hits) applyHit(W, h, 28, 3, t.o, dx, dy, 0.6); }
        else { t.cd = 1.1; const a = t.a; W.pr.push({ id: W.nid++, k: 5, x: t.x + Math.cos(a) * 0.6, y: t.y + Math.sin(a) * 0.6, vx: Math.cos(a) * 26, vy: Math.sin(a) * 26, l: 1.1, o: t.o, dm: 340, ap: 4, ex: 1.3, kn: 4 }); }
      }
    }
    for (const t of W.tu) if (t.hp <= 0 || t.am <= 0) { t.gone = 1; boom(W, t.x, t.y, 1.6, 120, 2, t.o, 3); }
    W.tu = W.tu.filter((t) => !t.gone);
    for (const m of W.mn) {
      if (m.arm > 0) { m.arm -= dt; continue; }
      for (const e of W.en) { const T = EN[e.t]; if (e.hp > 0 && !T.fly && T.tier < 3 && hyp(e.x - m.x, e.y - m.y) < T.r + 0.5) { m.gone = 1; boom(W, m.x, m.y, 2.6, 320, 3, m.o, 5); break; } }
    }
    W.mn = W.mn.filter((m) => !m.gone);
    for (const s of W.sb) s.t -= dt;
    W.sb = W.sb.filter((s) => s.t > 0);
    for (const f of W.fi) { f.t -= dt; hurtAll(W, f.x, f.y, f.r, 45 * dt, 3, f.o, 0, { pm: 0.7, burn: 1 }); }
    W.fi = W.fi.filter((f) => f.t > 0);
    for (const v of W.vh) if (v.hp <= 0) { v.gone = 1; const p = v.dr >= 0 ? W.pl[v.dr] : null; if (p) { p.veh = -1; p.stun = 1; } boom(W, v.x, v.y, 2.6, 220, 3, v.o, 7); }
    W.vh = W.vh.filter((v) => !v.gone);
    W.it = W.it.filter((it) => !it.gone);
    for (const b of W.bc) { b.t -= dt; if (b.t <= 0) { b.gone = 1; strike(W, b); } }
    W.bc = W.bc.filter((b) => !b.gone);
  }

  /* ----- 목표 · 탈출 · 증원 흐름 ----- */
  function mainDone(W) {
    const f = (k) => W.ob.find((o) => o.k === k);
    if (W.mt === 'nest') return f('nest').s === 2;
    if (W.mt === 'data') return f('term').s === 2;
    if (W.mt === 'defend') return f('zone').s === 2;
    if (W.mt === 'launch') return f('silo').s === 2;
    if (W.mt === 'rescue') return f('shel').s === 2;
    if (W.mt === 'escort') return f('crawl').s === 2;
    return false;
  }
  function focusPt(W) {
    if (W.ex.ph >= 2 && W.ex.ph < 4) return W.ex;
    for (const o of W.ob) if (o.s === 1 && (o.k === 'term' || o.k === 'zone' || o.k === 'silo' || o.k === 'shel')) return o;
    if (W.cr && W.cr.mv > 0) return W.cr;
    return null;
  }
  const nearP = (W, x, y, r) => W.pl.some((p) => p.al && !p.boarded && !(p.drop > 0) && hyp(p.x - x, p.y - y) < r);
  function stepObj(W, dt) {
    for (const o of W.ob) {
      if (o.k === 'nest') { o.n = W.en.filter((e) => e.main).length; if (o.n === 0 && o.s !== 2) o.s = 2; }
      else if (o.k === 'term' && o.s === 1) { if (nearP(W, o.x, o.y, 6.5)) o.pr += dt / 45; if (o.pr >= 1) { o.pr = 1; o.s = 2; fx(W, FX.OBJ, o.x, o.y, 7, 0); } }
      else if (o.k === 'zone' && o.s === 1) { if (nearP(W, o.x, o.y, 7)) o.pr += dt / 90; if (o.pr >= 1) { o.pr = 1; o.s = 2; fx(W, FX.OBJ, o.x, o.y, 8, 0); } }
      else if (o.k === 'silo' && o.s === 1) { o.pr += dt / 35; if (o.pr >= 1) { o.pr = 1; o.s = 2; fx(W, FX.LAUNCH, o.x, o.y, 0, 0); } }
      else if (o.k === 'shel' && o.s === 1) {
        if (o.out < 12) { o.ot -= dt; if (o.ot <= 0) { o.ot = 1.3; o.out++; W.cv.push({ id: W.nid++, x: o.x + (Math.random() - 0.5), y: o.y + 1.4, hp: 130 }); } }
        if (o.sv >= 6) { o.s = 2; fx(W, FX.OBJ, o.x, o.y, 10, 0); }
      }
      else if (o.k === 'crawl' && o.s === 0 && W.cr) {
        const c = W.cr; c.mv = 0;
        if (c.hp > 0 && nearP(W, c.x, c.y, 7.5)) { const f = flowDir(W.M, c.D, c.x, c.y); if (f) { moveC(W.M, c, f[0] * 1.9 * dt, f[1] * 1.9 * dt, 0.6); c.a += wrapA(Math.atan2(f[1], f[0]) - c.a) * Math.min(1, dt * 3); c.mv = 1; } }
        const d = W.ob.find((q) => q.k === 'dest');
        if (d && hyp(c.x - d.x, c.y - d.y) < 1.8) { o.s = 2; d.s = 2; fx(W, FX.OBJ, c.x, c.y, 11, 0); }
      }
    }
    // 피난민
    const pad = W.ob.find((q) => q.k === 'pad');
    if (pad && W.cv.length) {
      if (!W.padD) W.padD = bfs(W.M, [[pad.x, pad.y]]);
      const sh = W.ob.find((q) => q.k === 'shel');
      for (const c of W.cv) {
        if (c.hp <= 0 || c.sv) continue;
        if (nearP(W, c.x, c.y, 10)) { const f = flowDir(W.M, W.padD, c.x, c.y); if (f) moveC(W.M, c, f[0] * 2.6 * dt, f[1] * 2.6 * dt, 0.3); }
        if (hyp(c.x - pad.x, c.y - pad.y) < 2) { c.sv = 1; if (sh) sh.sv++; fx(W, FX.CIV, c.x, c.y, 1, 0); }
      }
      W.cv = W.cv.filter((c) => c.hp > 0 && !c.sv);
    }
    if (!W.md && mainDone(W)) { W.md = 1; W.ex.ph = 1; fx(W, FX.OBJ, W.ex.x, W.ex.y, 9, 0); }
    // 탈출
    const X = W.ex;
    if (X.ph === 2) { X.t -= dt; if (X.t <= 0) { X.ph = 3; X.t = 0; X.bt = -1; fx(W, FX.EXT, X.x, X.y, 3, 0); } }
    else if (X.ph === 3) {
      X.t += dt;
      for (const p of W.pl) if (p.al && !p.boarded && !(p.drop > 0) && hyp(p.x - X.x, p.y - X.y) < 3.2) { if (p.veh >= 0) { const v = W.vh.find((q) => q.id === p.veh); if (v) v.dr = -1; p.veh = -1; } p.boarded = 1; p.tm = -1; fx(W, FX.EXT, p.x, p.y, 5, p.s); if (X.bt < 0) X.bt = 0; }
      if (X.bt >= 0) X.bt += dt;
      const alive = W.pl.filter((p) => p.al && !(p.drop > 0));
      if (alive.length && alive.every((p) => p.boarded) || X.bt > 25) { X.ph = 4; fx(W, FX.EXT, X.x, X.y, 4, 0); finish(W, 1, 0); }
    }
  }
  function finish(W, ok, why) {
    if (W.res) return;
    const ext = W.pl.filter((p) => p.boarded);
    const smp = ok ? ext.reduce((a, p) => a + p.smp, 0) : 0;
    W.pl.forEach((p) => { if (p.boarded) W.sk[p.s][4] += p.smp; });
    W.res = { ok: ok ? 1 : 0, why, smp, ext: ext.length, sides: W.sd.filter((o) => o.s === 2).length, bonus: W.bonus | 0, t: W.t, sk: W.sk.map((a) => a.slice()) };
  }
  function director(W, dt) {
    const D = DIFF[W.dif], alive = W.pl.filter((p) => p.al && !p.boarded && !(p.drop > 0));
    const cap = 35 + 25 * D.den;
    W.patT -= dt;
    if (W.patT <= 0 && alive.length) {
      W.patT = D.pat * (0.7 + 0.6 * Math.random()) * (W.tower ? 0.85 : 1.1);
      if (W.en.length < cap) {
        const p = alive[Math.floor(Math.random() * alive.length)];
        const q = openNear(W.M, p.x, p.y, W.R, 8, 22, alive.map((z) => [z.x, z.y, 18]));
        patrol(W, q[0], q[1], Math.round(3 + 4 * D.den), 1000 + Math.floor(W.t), 0, p.x, p.y);
      }
    }
    const F = focusPt(W);
    if (F) {
      W.waveT -= dt;
      if (W.waveT <= 0) {
        W.waveT = (22 - 2 * W.dif) * (W.ex.ph >= 2 ? 0.8 : 1) * (0.85 + Math.random() * 0.3);
        if (W.en.length < cap + 15) {
          const q = openNear(W.M, F.x, F.y, W.R, 7, 17, alive.map((z) => [z.x, z.y, 12]));
          const n = Math.round(3 + 4 * D.den);
          W.ef.push({ k: 'spn', x: q[0], y: q[1], t: 1.6, n, f: W.fac });
          fx(W, FX.BREACH, q[0], q[1], W.fac, n);
        }
      }
    }
  }
  function stepWorld(W, inputs, dt) {
    if (W.res) return;
    W.t += dt; W.brCd -= dt; W.pfT -= dt;
    if (W.pfT <= 0) {
      W.pfT = 0.6;
      const src = [];
      for (const p of W.pl) if (p.al && !p.boarded && !(p.drop > 0)) src.push([p.x, p.y]);
      for (const c of W.cv) src.push([c.x, c.y]);
      if (W.cr) src.push([W.cr.x, W.cr.y]);
      for (const t of W.tu) src.push([t.x, t.y]);
      W.pf = src.length ? bfs(W.M, src) : null;
    }
    for (const p of W.pl) stepPlayer(W, p, inputs[p.s], dt);
    stepProj(W, dt);
    stepEnemies(W, dt);
    stepDefense(W, dt);
    stepEffects(W, dt);
    stepObj(W, dt);
    director(W, dt);
    if (W.res) return;
    // 실패 · 전멸 · 시간
    const alive = W.pl.filter((p) => p.al), dropping = W.pl.some((p) => p.drop > 0 && p.al);
    if (!alive.length && !dropping) {
      if (W.rein <= 0) { W.wipeT += dt; if (W.wipeT > 3) finish(W, 0, 1); }
      else { W.wipeT += dt; if (W.wipeT > 6) { W.wipeT = 0; const q = W.pl.find((z) => !z.al); const last = W.pl.reduce((a, z) => (z.dt > a.dt ? z : a), q); const s = openNear(W.M, last.x, last.y, W.R, 8, 6); W.rein--; revive(W, q, s[0], s[1]); fx(W, FX.POD, s[0], s[1], q.s, 2); } }
    } else W.wipeT = 0;
    if (W.cr && W.cr.hp <= 0 && !W.md) finish(W, 0, 3);
    const sh = W.ob.find((q) => q.k === 'shel'); if (sh && sh.dd > 6 && !W.md) finish(W, 0, 4);
    if (W.t >= W.tl && !W.timeUp) { W.timeUp = 1; fx(W, FX.TIME, 0, 0, W.md ? 1 : 0, 0); if (!W.md) finish(W, 0, 2); }
    if (W.timeUp && !W.res && W.t >= W.tl + (W.ex.ph >= 2 ? 300 : 150)) finish(W, 0, 5);
  }

  /* ================= AI 대원 ================= */
  function aiGoal(W, p, lv) {
    const X = W.ex;
    if (X.ph >= 2) return { x: X.x, y: X.y, r: X.ph === 3 ? 0.8 : 2.5 };
    const sidePend = W.sd.findIndex((o) => !o.s && o.k !== 'tower');
    if (X.ph === 1) {
      if (lv >= 2 && sidePend >= 0 && W.t < W.tl * 0.55) { const o = W.sd[sidePend]; return { x: o.x, y: o.y, r: 1.4, act: 1 }; }
      return { x: X.x, y: X.y, r: 1.5, act: 1 };
    }
    const f = (k) => W.ob.filter((o) => o.k === k);
    const near = (arr) => arr.reduce((a, o) => (!a || hyp(o.x - p.x, o.y - p.y) < hyp(a.x - p.x, a.y - p.y) ? o : a), null);
    if (W.mt === 'nest') { const h = near(W.en.filter((e) => e.main)); if (h) return { x: h.x, y: h.y, r: los(W.M, p.x, p.y, h.x, h.y) ? (p.gr > 0 ? 7 : 9) : 2.5, hive: h }; }
    if (W.mt === 'data') { const o = f('term')[0]; return o.s === 0 ? { x: o.x, y: o.y, r: 1.4, act: 1 } : { x: o.x, y: o.y, r: 3.5 }; }
    if (W.mt === 'defend') { const o = f('zone')[0]; return o.s === 0 ? { x: o.x, y: o.y, r: 1.6, act: 1 } : { x: o.x, y: o.y, r: 4 }; }
    if (W.mt === 'launch') { const g = near(f('gen').filter((o) => o.s === 0)); if (g) return { x: g.x, y: g.y, r: 1.4, act: 1 }; const o = f('silo')[0]; return o.s === 0 ? { x: o.x, y: o.y, r: 1.4, act: 1 } : { x: o.x, y: o.y, r: 4 }; }
    if (W.mt === 'rescue') {
      const o = f('shel')[0], pad = f('pad')[0];
      if (o.s === 0) return { x: o.x, y: o.y, r: 1.4, act: 1 };
      if (W.cv.length) { let cx = 0, cy = 0; W.cv.forEach((c) => { cx += c.x; cy += c.y; }); cx /= W.cv.length; cy /= W.cv.length; const k = hyp(pad.x - cx, pad.y - cy) || 1; return { x: cx + (pad.x - cx) / k * 2.5, y: cy + (pad.y - cy) / k * 2.5, r: 2.5 }; }
      if (o.out < 12) return { x: o.x, y: o.y, r: 4 };
      return { x: pad.x, y: pad.y, r: 3 };
    }
    if (W.mt === 'escort' && W.cr) { const d = f('dest')[0]; const k = hyp(d.x - W.cr.x, d.y - W.cr.y) || 1; return { x: W.cr.x + (d.x - W.cr.x) / k * 2.5, y: W.cr.y + (d.y - W.cr.y) / k * 2.5, r: 2 }; }
    return { x: X.x, y: X.y, r: 2 };
  }
  function aiThink(W, p, m, lv, dt, hum) {
    const I = { mx: 0, my: 0, ax: null, ay: null, fire: 0, ads: 0, spr: 0, rl: 0, dv: 0, ie: 0, gr: 0, ml: 0, stim: 0, sw: -1, th: null, tc: -1 };
    if (!p.al || p.drop > 0 || p.boarded) { m.code = null; return I; }
    const PA = [0, 0.42, 0.28, 0.18][lv];
    m.dT = (m.dT || 0) - dt; m.gT = (m.gT || 0) - dt; m.sT = (m.sT || 0) - dt; m.ieT = (m.ieT || 0) - dt; m.tT = (m.tT || 0) - dt;
    m.nz = (m.nz || 0) + (Math.random() - 0.5) * dt * 3; m.nz = clamp(m.nz, -1, 1);
    if (p.veh >= 0) { I.ie = 1; return I; }
    // 단말기 암호
    if (p.tm >= 0) { if (m.tcT === undefined || m.tcT === null) { const o = p.tm >= 100 ? W.sd[p.tm - 100] : W.ob[p.tm]; m.tcT = ((o && o.c.length) || 4) * PA + 0.3; } m.tcT -= dt; if (m.tcT <= 0) { I.tc = p.tm; m.tcT = null; } return I; }
    m.tcT = null;
    // 지원 요청 암호 입력 중
    if (m.code) { m.code.t -= dt; if (m.code.t <= 0) { I.th = { sl: m.code.sl, x: m.code.x, y: m.code.y }; m.code = null; } }
    // 이끌 사람: 사람 대원이 살아 있으면 가장 가까운 사람, 아니면 가장 앞 번호 AI
    let lead = null;
    for (const s of hum || []) { const q = W.pl[s]; if (q && q.al && !q.boarded && !(q.drop > 0) && (!lead || hyp(q.x - p.x, q.y - p.y) < hyp(lead.x - p.x, lead.y - p.y))) lead = q; }
    if (!lead) { const first = W.pl.find((q) => q.al && !q.boarded && !(q.drop > 0)); if (first && first !== p && W.ex.ph < 2) lead = first; }
    let G = aiGoal(W, p, lv);
    if (lead && !(G.act && hyp(G.x - p.x, G.y - p.y) < 6) && W.ex.ph < 2) G = { x: lead.x + Math.cos(p.s * 2.1) * 2.2, y: lead.y + Math.sin(p.s * 2.1) * 2.2, r: 2.5, fol: 1 };
    // 적 고르기
    const wpP = PRI[p.lo[0]];
    let tgt = null, tb = 1e9;
    for (const e of W.en) {
      if (e.hp <= 0 || e.spn > 0) continue; const T = EN[e.t], d = hyp(e.x - p.x, e.y - p.y);
      if (d > (T.tier === 3 ? 14 : 26)) continue;
      if (T.tier === 3 && p.gr <= 0 && !(p.sw === 'at' || p.sw === 'rail')) continue;
      if (!los(W.M, p.x, p.y, e.x, e.y)) continue;
      const s = d - (e.tg && e.tg.o === p ? 4 : 0) - (T.tier === 2 ? 2 : 0) + (T.tier === 3 ? 10 : 0);
      if (s < tb) { tb = s; tgt = e; }
    }
    // 이동 목표: 가까운 표본·보급·지원 화기 들르기
    if (!tgt && lv >= 2 && !G.act) {
      for (const it of W.it) { const d = hyp(it.x - p.x, it.y - p.y); if (d > 9) continue; if (it.k === 0 || it.k === 5 || (it.k === 2 && needsSupply(p)) || (it.k === 3 && !p.sw) || (it.k === 4 && !p.bp)) { G = { x: it.x, y: it.y, r: 0.3 }; break; } }
    }
    const gd = hyp(G.x - p.x, G.y - p.y);
    if (gd > G.r) {
      const gk = Math.floor(G.y) * MS + Math.floor(G.x);
      if ((m.gk !== gk && m.dT <= 0) || !m.D) { m.D = bfs(W.M, [[G.x, G.y]]); m.gk = gk; m.dT = 0.6; }
      let dx, dy;
      if (gd < 5 && los(W.M, p.x, p.y, G.x, G.y)) { dx = (G.x - p.x) / gd; dy = (G.y - p.y) / gd; }
      else { const f = flowDir(W.M, m.D, p.x, p.y); if (f) { dx = f[0] + (Math.floor(p.x) + 0.5 - p.x) * 1.4; dy = f[1] + (Math.floor(p.y) + 0.5 - p.y) * 1.4; const l = hyp(dx, dy) || 1; dx /= l; dy /= l; } else { dx = (G.x - p.x) / gd; dy = (G.y - p.y) / gd; } }
      I.mx = dx; I.my = dy;
      if (!tgt && gd > 9 && p.stm > 0.35) I.spr = 1;
    } else if (G.act && m.ieT <= 0) { I.ie = 1; m.ieT = 1.2; }
    // 위험 피하기: 곧 떨어질 포격·투하 상자·수류탄·지뢰밭
    let ux = 0, uy = 0;
    const push = (cx, cy, R, w) => { const dx = p.x - cx, dy = p.y - cy, d = hyp(dx, dy); if (d < R) { const k = (R - d) / R * (w || 1); ux += (d > 0.01 ? dx / d : Math.cos(p.s)) * k; uy += (d > 0.01 ? dy / d : Math.sin(p.s)) * k; } };
    for (const b of W.bc) {
      if (b.t > 3) continue; const R = dangerR(b.si);
      if (R < 0) { const ca = Math.cos(b.a), sa = Math.sin(b.a), t = clamp((p.x - b.x) * ca + (p.y - b.y) * sa, -1, 12); push(b.x + ca * t, b.y + sa * t, 2.8, 1.5); }
      else if (R > 0) push(b.x, b.y, R + 1, 1.5);
    }
    for (const b of W.pr) if (b.k === 6) push(b.x, b.y, (GRE[b.gi] ? GRE[b.gi].r : 3) + 1, 1.2);
    for (const f of W.ef) if (f.k === 'bar') push(f.x, f.y, 10, 1.5); else if (f.k === 'las') push(f.tx, f.ty, 3.5, 1.5); else if (f.k === 'str' || f.k === 'clu') { const ca = Math.cos(f.a), sa = Math.sin(f.a), t = clamp((p.x - f.x) * ca + (p.y - f.y) * sa, f.s, 12); push(f.x + ca * t, f.y + sa * t, 3, 1.5); }
    for (const f of W.fi) push(f.x, f.y, f.r + 0.6, 1);
    if (ux || uy) { const l = hyp(ux, uy); if (l > 0.15) { const bx = I.mx * 0.35 + ux / l, by = I.my * 0.35 + uy / l, bl = hyp(bx, by) || 1; I.mx = bx / bl; I.my = by / bl; I.spr = 1; } }
    // 막혔을 때 비켜 가기
    m.px = m.px === undefined ? p.x : m.px; m.py = m.py === undefined ? p.y : m.py;
    m.stuck = (m.stuck || 0) + dt;
    if (m.stuck > 1.2) { if (hyp(p.x - m.px, p.y - m.py) < 0.4 && gd > G.r + 0.5) m.side = 1.0; m.px = p.x; m.py = p.y; m.stuck = 0; }
    if (m.side > 0) { m.side -= dt; const s = p.s % 2 ? 1 : -1; const nx = I.mx - I.my * s, ny = I.my + I.mx * s; I.mx = nx * 0.7; I.my = ny * 0.7; }
    // 쏘기
    let aimX = G.x, aimY = G.y;
    if (tgt) {
      const T = EN[tgt.t], d = hyp(tgt.x - p.x, tgt.y - p.y), err = [0, 0.45, 0.2, 0.07][lv] * d * 0.12;
      aimX = tgt.x + m.nz * err; aimY = tgt.y + Math.sin(W.t * 1.7 + p.s) * err;
      // 무기 고르기
      const heavy = T.ar >= 3 && T.tier < 3, swOK = p.sw && p.W[2] && p.W[2].mag + p.W[2].rsv > 0;
      let want = 0;
      if (swOK && ((p.sw === 'at' || p.sw === 'rail') ? heavy : p.sw === 'fl' ? d < 6.5 : true)) want = 2;
      else if (p.W[0].mag + p.W[0].rsv <= 0) want = 1;
      if (want !== p.w) I.sw = want;
      const wp = want === 2 ? SUPW[p.sw] : want === 1 ? SEC[p.lo[1]] : wpP;
      let ff = false;
      if (lv >= 2 || Math.random() < 0.5) {
        const dx = (aimX - p.x) / (d || 1), dy = (aimY - p.y) / (d || 1);
        for (const q of W.pl) { if (q === p || !q.al || q.boarded || q.drop > 0) continue; const ax = q.x - p.x, ay = q.y - p.y, t = ax * dx + ay * dy; if (t > 0 && t < d + (wp.ex || 0) && Math.abs(ax * dy - ay * dx) < 0.9) { ff = true; break; } }
        if ((wp.ex || 0) > 0 && d < wp.ex + 1.2) ff = true;
      }
      const reach = T.tier === 3 ? 0 : wp.rg;
      if (!ff && d < reach && !m.code && !(heavy && want !== 2 && T.ar >= wp.ap + 1 && !(T.rear))) I.fire = 1;
      if (!ff && d < reach && T.rear && heavy && want !== 2) I.fire = 1;
      if (wp.id === 'mk' || wp.id === 'rail') I.ads = d > 12 ? 1 : 0;
      // 근접 · 물러나기 · 다이브
      if (d < 1.3 + T.r && (p.W[p.w] && p.W[p.w].mag === 0 || Math.random() < 0.05 * lv)) I.ml = 1;
      if (lv >= 2 && !G.act && (T.at === 'm' || T.at === 'x') && d < 3.2 && !G.fol) { I.mx = -(tgt.x - p.x) / d * 0.9 + I.mx * 0.3; I.my = -(tgt.y - p.y) / d * 0.9 + I.my * 0.3; }
      if (lv >= 2 && T.at === 'x' && tgt.ch >= 1 && d < 7 && p.dvc <= 0) { const px = -(tgt.y - p.y) / d, py = (tgt.x - p.x) / d; I.mx = px; I.my = py; I.dv = 1; }
      // 수류탄
      if (p.gr > 0 && m.gT <= 0 && d > 4.5 && d < 13.5) {
        let n = 0; for (const e of W.en) if (e.hp > 0 && hyp(e.x - tgt.x, e.y - tgt.y) < 3) n++;
        const allyNear = W.pl.some((q) => q.al && hyp(q.x - tgt.x, q.y - tgt.y) < 4.2);
        if (!allyNear && (T.tier === 3 || n >= (lv === 3 ? 3 : 4) || (heavy && GRE[p.lo[2]].ap >= 4))) { I.gr = 1; m.gT = 2.2 + (3 - lv); }
      }
    }
    if (I.gr && tgt && EN[tgt.t].tier === 3) { aimX = tgt.x; aimY = tgt.y; }
    I.ax = aimX; I.ay = aimY;
    if (!tgt && p.W[p.w] && p.W[p.w].mag < (wpOf(p).mag * 0.5) && p.W[p.w].rsv > 0) I.rl = 1;
    if (p.hp < p.mhp * 0.45 && p.stim > 0) I.stim = 1;
    // 지원 요청
    if (!m.code && m.sT <= 0) {
      m.sT = 1.2 + (3 - lv) * 0.8;
      const pick = aiStrat(W, p, lv, tgt, G);
      if (pick) { const S = STR[p.sl[pick.sl]]; m.code = { sl: pick.sl, x: pick.x, y: pick.y, t: S.c.length * PA + 0.25 }; }
    }
    return I;
  }
  function dangerR(si) {
    const id = STR[si].id;
    return id === 'ob_prec' ? 4.6 : id === 'ob_bar' ? 9.5 : id === 'ob_las' ? 3 : id === 'ob_ems' ? 7.5 : id === 'ob_rail' ? 2.2 : id === 'ea_500' ? 6.2 : id === 'ea_str' || id === 'ea_clu' ? -1 : id === 'df_mine' || id === 'df_bub' ? 0 : 1.8;
  }
  function aiStrat(W, p, lv, tgt, G) {
    const ok = (k) => canCall(W, p, k);
    const by = (pred) => { for (let k = 0; k < 6; k++) if (ok(k) && pred(STR[p.sl[k]], k)) return k; return -1; };
    const feet = (d) => { const a = Math.random() * TAU; const q = openNear(W.M, p.x + Math.cos(a) * d, p.y + Math.sin(a) * d, W.R, 1, 0); return q; };
    let k = by((S) => S.id === 'm_re');
    if (k >= 0) { const q = feet(3.5); return { sl: k, x: q[0], y: q[1] }; }
    const lowAmmo = (p.W[0].mag + p.W[0].rsv) < PRI[p.lo[0]].rsv * 0.25 || (p.gr === 0 && (p.stim <= 1 || W.en.some((e) => EN[e.t].tier === 3 && hyp(e.x - p.x, e.y - p.y) < 25)));
    if (lowAmmo && (k = by((S) => S.id === 'm_sup')) >= 0) { const q = feet(3.2); return { sl: k, x: q[0], y: q[1] }; }
    if (!p.sw && (k = by((S) => !!S.w)) >= 0) { const q = feet(3.2); return { sl: k, x: q[0], y: q[1] }; }
    if (!p.bp && (k = by((S) => S.id === 'bp_sh')) >= 0) { const q = feet(3.2); return { sl: k, x: q[0], y: q[1] }; }
    // 공격 지원: 대형 적 · 구조물 · 무리
    let aim = null, big = 0;
    for (const e of W.en) {
      if (e.hp <= 0) continue; const T = EN[e.t], d = hyp(e.x - p.x, e.y - p.y);
      if (d > 20 || d < (T.tier === 3 ? 5 : 7)) continue;
      let v = T.tier === 2 ? 6 : T.tier === 3 ? 7 : 0;
      if (!v) { let n = 0; for (const q of W.en) if (q.hp > 0 && hyp(q.x - e.x, q.y - e.y) < 4) n++; if (n >= (lv === 3 ? 5 : 7)) v = n / 2; }
      if (v > big && los(W.M, p.x, p.y, e.x, e.y)) { big = v; aim = e; }
    }
    if (aim) {
      const allyR = (r) => W.pl.some((q) => q.al && !q.boarded && hyp(q.x - aim.x, q.y - aim.y) < r + 1.2);
      const heavy = EN[aim.t].tier >= 2;
      k = by((S) => S.cat === '궤도' || S.cat === '항공' ? (S.id === 'ob_ems' ? !heavy : S.id === 'ob_bar' ? !allyR(9) : S.id === 'ea_500' ? !allyR(5.5) : S.id === 'ob_prec' ? !allyR(4) : S.id === 'ob_rail' ? heavy : !allyR(3.5)) : false);
      if (k >= 0) {
        const S = STR[p.sl[k]];
        if (S.id === 'ea_str' || S.id === 'ea_clu') {
          const a = Math.atan2(aim.y - p.y, aim.x - p.x), d = Math.max(5, hyp(aim.x - p.x, aim.y - p.y) - 4), bx = p.x + Math.cos(a) * d, by = p.y + Math.sin(a) * d, ca = Math.cos(a), sa = Math.sin(a);
          const hitAlly = W.pl.some((q) => { if (!q.al || q.boarded) return false; const t = clamp((q.x - bx) * ca + (q.y - by) * sa, -1, 12); return hyp(q.x - bx - ca * t, q.y - by - sa * t) < 3; });
          if (!hitAlly) return { sl: k, x: bx, y: by };
        } else return { sl: k, x: aim.x, y: aim.y };
      }
    }
    // 방어: 지킬 때
    const hold = focusPt(W);
    if (hold && hyp(hold.x - p.x, hold.y - p.y) < 9) {
      const hunting = W.en.filter((e) => e.st && hyp(e.x - p.x, e.y - p.y) < 22).length;
      if (hunting >= 3 || lv >= 3) { k = by((S) => S.cat === '방어'); if (k >= 0) { const q = openNear(W.M, hold.x, hold.y, W.R, 3, 1.5); return { sl: k, x: q[0], y: q[1] }; } }
    }
    return null;
  }

  /* ================= 스냅샷 (호스트 → 게스트) ================= */
  const pc = (v, m) => Math.round(clamp(v / (m || 1), 0, 1) * 100);
  function snapshot(W, key, q, lastFx) {
    const P = W.pl.map((p) => {
      const fl = (p.al ? 1 : 0) | (p.boarded ? 2 : 0) | (p.ads ? 4 : 0) | (p.spr ? 8 : 0) | (p.stun > 0 ? 16 : 0) | (p.hit > 0 ? 32 : 0) | (p.dv > 0 ? 64 : 0) | ((p.W[p.w] && p.W[p.w].rl > 0) ? 128 : 0) | (p.bp ? 256 : 0) | (p.pod ? 1024 : 0) | (p.melT > 0 ? 2048 : 0) | (p.rg > 0 ? 4096 : 0);
      const ws = (k) => (p.W[k] ? [p.W[k].mag, p.W[k].rsv] : [0, 0]);
      return [Math.round(p.x * 10), Math.round(p.y * 10), Math.round(p.a * 100), Math.round(p.hp), p.mhp, fl, p.w, ...ws(0), ...ws(1), ...ws(2), p.gr, p.stim, p.smp, Math.round(Math.max(0, p.drop) * 10), Math.round(p.sh), p.fc, p.tm, p.veh, p.sw ? 'amrf'.indexOf(p.sw[0]) : -1, Math.round(p.stm * 100), p.cd.map((c) => Math.ceil(c)), p.nU.slice(), Math.round(p.dt)];
    });
    const E = W.en.map((e) => [e.id, e.t, Math.round(e.x * 10), Math.round(e.y * 10), Math.round(e.a * 10), pc(e.hp, e.mhp), (e.st ? 1 : 0) | (e.ch << 1) | (e.stun > 0 ? 8 : 0) | (e.al > 0 ? 16 : 0) | (e.spn > 0 ? 32 : 0) | (e.burn > 0 ? 64 : 0) | (e.main ? 128 : 0)]);
    return {
      k: key, q, t: Math.round(W.t * 10), P, E,
      R: W.pr.map((b) => [b.id, b.k, Math.round(b.x * 10), Math.round(b.y * 10), Math.round(b.vx), Math.round(b.vy), b.k === 6 ? b.gi : b.k === 7 ? b.si : 0]),
      B: W.bc.map((b) => [b.id, b.si, Math.round(b.x * 10), Math.round(b.y * 10), Math.round(b.t * 10), b.o, Math.round(b.a * 10)]),
      T: W.tu.map((t) => [t.id, t.k, Math.round(t.x * 10), Math.round(t.y * 10), Math.round(t.a * 10), pc(t.hp, t.mhp), t.am, t.fc | 0, t.dt > 0 ? 1 : 0]),
      M: W.mn.map((m) => [Math.round(m.x * 10), Math.round(m.y * 10)]),
      S: W.sb.map((s) => [Math.round(s.x * 10), Math.round(s.y * 10), Math.round(s.t)]),
      I: W.it.map((it) => [it.id, it.k, Math.round(it.x * 10), Math.round(it.y * 10), it.k === 3 ? 'amrf'.indexOf(it.w[0]) : (it.n | 0)]),
      V: W.vh.map((v) => [v.id, Math.round(v.x * 10), Math.round(v.y * 10), Math.round(v.a * 10), pc(v.hp, v.mhp), v.dr, v.rk]),
      F: W.fi.map((f) => [Math.round(f.x * 10), Math.round(f.y * 10), Math.round(f.r * 10)]),
      C: W.cv.map((c) => [c.id, Math.round(c.x * 10), Math.round(c.y * 10)]),
      cr: W.cr ? [Math.round(W.cr.x * 10), Math.round(W.cr.y * 10), pc(W.cr.hp, W.cr.mhp), Math.round(W.cr.a * 10), W.cr.mv] : 0,
      O: W.ob.map((o) => [o.s, Math.round(o.pr * 100), o.sv | 0, o.dd | 0, o.out | 0, o.n | 0]),
      SD: W.sd.map((o) => o.s), X: [W.ex.ph, Math.round(W.ex.t * 10)], G: [W.rein, W.md, W.timeUp, W.tower, W.brCd > 0 ? 1 : 0],
      EF: W.ef.filter((f) => f.k === 'las' || f.k === 'bar').map((f) => [f.k === 'las' ? 1 : 2, Math.round((f.tx || f.x) * 10), Math.round((f.ty || f.y) * 10)]),
      fx: W.fx.filter((e) => e[0] > lastFx - 0).slice(-24), res: W.res ? 1 : 0,
    };
  }
  const SWK = ['at', 'mg', 'rail', 'fl'];
  function applySnap(W, hs, me) {
    W.t = hs.t / 10;
    hs.P.forEach((a, s) => {
      const p = W.pl[s]; if (!p) return;
      p.nx = a[0] / 10; p.ny = a[1] / 10; if (s !== me) p.na = a[2] / 100; p.hp = a[3]; p.mhp = a[4];
      const fl = a[5]; p.al = fl & 1 ? 1 : 0; p.boarded = fl & 2 ? 1 : 0; if (s !== me) p.ads = fl & 4 ? 1 : 0; p.spr = fl & 8 ? 1 : 0; p.stun = fl & 16 ? 1 : 0; p.hit = fl & 32 ? 0.3 : 0; p.dvF = fl & 64; p.rlF = fl & 128; p.bp = fl & 256 ? 1 : 0; p.pod = fl & 1024 ? 1 : 0; p.melT = fl & 2048 ? 0.2 : 0; p.rg = fl & 4096 ? 1 : 0;
      p.w = a[6]; p.W = [{ mag: a[7], rsv: a[8] }, { mag: a[9], rsv: a[10] }, a[21] >= 0 ? { mag: a[11], rsv: a[12] } : null];
      p.gr = a[13]; p.stim = a[14]; p.smp = a[15]; p.drop = a[16] / 10; p.sh = a[17]; p.fcN = a[18]; p.tm = a[19]; p.veh = a[20]; p.sw = a[21] >= 0 ? SWK[a[21]] : null; p.stm = a[22] / 100; p.cd = a[23]; p.dt = a[25];
      if (Array.isArray(a[24])) p.nU = a[24];
      if (!fin(p.x) || hyp(p.x - p.nx, p.y - p.ny) > 6) { p.x = p.nx; p.y = p.ny; }
    });
    const old = {}; W.en.forEach((e) => { old[e.id] = e; });
    W.en = hs.E.map((a) => { const o = old[a[0]] || { id: a[0], x: a[2] / 10, y: a[3] / 10, a: a[4] / 10, hp: 1, mhp: 1 }; o.t = a[1]; o.nx = a[2] / 10; o.ny = a[3] / 10; o.na = a[4] / 10; o.hpP = a[5]; o.hp = Math.max(1, a[5]); o.mhp = 100; const f = a[6]; o.st = f & 1; o.ch = (f >> 1) & 3; o.stun = f & 8 ? 1 : 0; o.al = f & 16 ? 1 : 0; o.spn = f & 32 ? 1 : 0; o.burn = f & 64 ? 1 : 0; o.main = f & 128 ? 1 : 0; return o; });
    const oldR = {}; W.pr.forEach((b) => { oldR[b.id] = b; });
    W.pr = hs.R.map((a) => { const o = oldR[a[0]] || { id: a[0], x: a[2] / 10, y: a[3] / 10 }; o.k = a[1]; o.nx = a[2] / 10; o.ny = a[3] / 10; o.vx = a[4]; o.vy = a[5]; o.gi = a[6]; o.si = a[6]; return o; });
    W.bc = hs.B.map((a) => ({ id: a[0], si: a[1], x: a[2] / 10, y: a[3] / 10, t: a[4] / 10, T: STR[a[1]] ? STR[a[1]].dl : 3, o: a[5], a: a[6] / 10 }));
    const oldT = {}; W.tu.forEach((t) => { oldT[t.id] = t; });
    W.tu = hs.T.map((a) => { const o = oldT[a[0]] || {}; Object.assign(o, { id: a[0], k: a[1], x: a[2] / 10, y: a[3] / 10, na: a[4] / 10, hp: a[5], mhp: 100, am: a[6], fcN: a[7], dt: a[8] }); if (!fin(o.a)) o.a = o.na; return o; });
    W.mn = hs.M.map((a) => ({ x: a[0] / 10, y: a[1] / 10 }));
    W.sb = hs.S.map((a) => ({ x: a[0] / 10, y: a[1] / 10, t: a[2], r: 4.5 }));
    W.it = hs.I.map((a) => ({ id: a[0], k: a[1], x: a[2] / 10, y: a[3] / 10, w: a[1] === 3 ? SWK[a[4]] : null, n: a[4] }));
    const oldV = {}; W.vh.forEach((v) => { oldV[v.id] = v; });
    W.vh = hs.V.map((a) => { const o = oldV[a[0]] || { x: a[1] / 10, y: a[2] / 10 }; Object.assign(o, { id: a[0], nx: a[1] / 10, ny: a[2] / 10, a: a[3] / 10, hp: a[4], mhp: 100, dr: a[5], rk: a[6] }); return o; });
    W.fi = hs.F.map((a) => ({ x: a[0] / 10, y: a[1] / 10, r: a[2] / 10, t: 1 }));
    const oldC = {}; W.cv.forEach((c) => { oldC[c.id] = c; });
    W.cv = hs.C.map((a) => { const o = oldC[a[0]] || { id: a[0], x: a[1] / 10, y: a[2] / 10, hp: 1 }; o.nx = a[1] / 10; o.ny = a[2] / 10; return o; });
    if (hs.cr && W.cr) { W.cr.nx = hs.cr[0] / 10; W.cr.ny = hs.cr[1] / 10; W.cr.hp = hs.cr[2]; W.cr.mhp = 100; W.cr.a = hs.cr[3] / 10; W.cr.mv = hs.cr[4]; }
    hs.O.forEach((a, i) => { const o = W.ob[i]; if (!o) return; o.s = a[0]; o.pr = a[1] / 100; o.sv = a[2]; o.dd = a[3]; o.out = a[4]; o.n = a[5]; });
    hs.SD.forEach((v, i) => { if (W.sd[i]) W.sd[i].s = v; });
    W.ex.ph = hs.X[0]; W.ex.t = hs.X[1] / 10;
    W.rein = hs.G[0]; W.md = hs.G[1]; W.timeUp = hs.G[2]; W.tower = hs.G[3];
    W.efV = hs.EF || [];
  }

  /* ================= 화면 ================= */
  const DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif', BODY = '"IBM Plex Sans KR", sans-serif', MONO = '"IBM Plex Mono", monospace';
  const CSS = `
.sf-ov{position:absolute;inset:0;z-index:20;display:flex;flex-direction:column;background:radial-gradient(ellipse at 30% 20%,#1d2433 0%,#0d1018 70%);color:#e9eef5;font-family:${BODY};overflow:hidden}
.sf-ov *{box-sizing:border-box}
.sf-hd{display:flex;align-items:center;gap:14px;padding:10px 18px 8px;border-bottom:1px solid #2c3648;flex:0 0 auto}
.sf-hd h2{margin:0;font-family:${DISP};font-weight:400;font-size:24px;color:#ffd257;letter-spacing:1px}
.sf-hd .sub{font-size:13px;color:#9fb0c8}
.sf-hd .res{margin-left:auto;display:flex;gap:10px;font-family:${MONO};font-size:14px}
.sf-hd .res span{background:#1a2130;border:1px solid #33405a;border-radius:8px;padding:5px 10px}
.sf-body{flex:1 1 auto;display:grid;grid-template-columns:minmax(300px,0.95fr) minmax(420px,1.25fr);gap:14px;padding:12px 18px;min-height:0}
.sf-col{display:flex;flex-direction:column;gap:10px;min-height:0;overflow:auto;padding-right:4px}
.sf-card{background:linear-gradient(180deg,#171e2b,#121824);border:1px solid #2c3648;border-radius:12px;padding:10px 12px}
.sf-card h3{margin:0 0 6px;font-size:14px;color:#ffd257;font-weight:700;display:flex;align-items:center;gap:8px}
.sf-card h3 small{color:#8ea0ba;font-weight:500;font-size:12px}
.sf-gal{width:100%;height:230px;display:block;border-radius:8px;cursor:pointer}
.sf-brief p{margin:3px 0;font-size:13px;line-height:1.45;color:#cdd7e5}
.sf-brief b{color:#fff}
.sf-row{display:flex;flex-wrap:wrap;gap:6px}
.sf-chip{min-height:44px;min-width:44px;padding:6px 10px;border-radius:9px;border:1px solid #33405a;background:#1a2130;color:#dfe7f2;font:600 13px ${BODY};cursor:pointer;display:flex;align-items:center;gap:6px;text-align:left;position:relative}
.sf-chip:hover{border-color:#6c86ad;background:#1f293b}
.sf-chip.on{border-color:#ffd257;background:#3a3218;color:#fff3c4;box-shadow:0 0 0 1px #ffd25744 inset}
.sf-chip.lock{opacity:.6}
.sf-chip .ic{font-size:17px}
.sf-chip .cd{font-family:${MONO};font-size:11px;color:#9fb0c8;letter-spacing:-1px}
.sf-chip .cost{font-family:${MONO};font-size:11px;color:#ffd257}
.sf-tip{font-size:12px;color:#9fb0c8;min-height:34px;margin-top:6px;line-height:1.4}
.sf-ft{flex:0 0 auto;display:flex;align-items:center;gap:12px;padding:10px 18px 14px;border-top:1px solid #2c3648}
.sf-btn{min-height:48px;padding:8px 20px;border-radius:10px;border:1px solid #4a5a78;background:#222c3e;color:#e9eef5;font:700 15px ${BODY};cursor:pointer;position:relative}
.sf-btn:hover{background:#2a3650}
.sf-btn.pri{background:linear-gradient(180deg,#ffd257,#e2a92c);color:#231a05;border-color:#ffd257}
.sf-btn.pri.off{background:#2f6a3c;color:#dfffe6;border-color:#5fc777}
.sf-btn:disabled{opacity:.45;cursor:default}
.sf-tabs{display:flex;gap:6px;margin-bottom:6px}
.sf-tabs button{min-height:40px;padding:6px 14px;border-radius:8px;border:1px solid #33405a;background:#141a26;color:#9fb0c8;font:700 13px ${BODY};cursor:pointer}
.sf-tabs button.on{background:#2a3446;color:#ffd257;border-color:#ffd257}
.sf-sq{display:flex;gap:8px;flex-wrap:wrap}
.sf-sq div{display:flex;align-items:center;gap:6px;background:#1a2130;border:1px solid #33405a;border-radius:8px;padding:4px 10px;font-size:13px;min-height:36px}
.sf-sq i{width:12px;height:12px;border-radius:50%;display:inline-block}
.sf-end .big{font-family:${DISP};font-size:44px;margin:4px 0}
.sf-bar{height:14px;border-radius:7px;background:#232c3d;overflow:hidden;position:relative}
.sf-bar b{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#3fae5a,#9be36b)}
.sf-bar s{position:absolute;left:0;top:0;bottom:0;background:#ffd257;opacity:.85}
.sf-tbl{width:100%;border-collapse:collapse;font-size:13px}
.sf-tbl td,.sf-tbl th{padding:5px 8px;border-bottom:1px solid #263044;text-align:left}
.sf-tbl th{color:#9fb0c8;font-weight:600;text-align:right}.sf-tbl th:first-child{text-align:left}
.sf-tbl td.n{font-family:${MONO};text-align:right}
@media (max-width:900px){.sf-body{grid-template-columns:1fr}}
`;
  const SND_ON = () => { try { return !!(U.store ? U.store.get('sound', true) : true); } catch (e) { return true; } };
  function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  const LS = { get(k, d) { try { const v = localStorage.getItem('lounge.sf.' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }, set(k, v) { try { localStorage.setItem('lounge.sf.' + k, JSON.stringify(v)); } catch (e) { /* private */ } } };
  const codeStr = (c) => c.split('').map((ch) => ARROW[ch]).join('');

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS }); root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    cv.cv.style.cursor = 'none';
    const auto = () => !!(L.debug && L.debug.autoplay);
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const P = (s) => api.players[s] || { name: '?', color: '#888', ai: true };
    const host = () => !api.online || api.isHost;
    const localHuman = (s) => { const p = api.players[s]; return !!p && !p.ai && !!p.local; };
    const isAIseat = (s) => !!P(s).ai || (auto() && localHuman(s));
    const lvOf = (s) => { const v = P(s).lv | 0; return v >= 1 && v <= 3 ? v : 2; };
    const COL = (s) => P(s).color || ['#e8c547', '#4fb3e8', '#e8664f', '#7ad46a'][s % 4];
    let st = null, W = null, key = null, lastKey = null, aiMem = [], acc = 0;
    function me() { if (!st) return -1; for (let s = 0; s < st.np; s++) if (localHuman(s)) return s; return -1; }
    const myP = () => { const m = me(); return W && m >= 0 && !auto() ? W.pl[m] : null; };
    const nm = (s) => (st && st.nm && st.nm[s]) || P(s).name || (s + 1) + '번';
    const kl = (id) => { try { return L.ui && L.ui.keyLabel ? L.ui.keyLabel('strikeforce', id) : ''; } catch (e) { return ''; } };

    /* ----- 소리 ----- */
    const Snd = {
      ac: null, out: null, nb: null, last: {},
      ctx() { if (auto() || !SND_ON()) return null; try { if (!this.ac) { this.ac = new (window.AudioContext || window.webkitAudioContext)(); this.out = this.ac.createGain(); this.out.connect(this.ac.destination); const n = this.ac.sampleRate; this.nb = this.ac.createBuffer(1, n, n); const d = this.nb.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; } this.out.gain.value = 0.5 * (L.audio ? L.audio.sfx() : 1); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
      noise(dur, f0, f1, vol, type, q) { const a = this.ctx(); if (!a) return; const t = a.currentTime, s = a.createBufferSource(); s.buffer = this.nb; const f = a.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur); f.Q.value = q || 0.8; const g = a.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); s.connect(f); f.connect(g); g.connect(this.out); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05); },
      tone(f0, f1, dur, vol, type) { const a = this.ctx(); if (!a) return; const t = a.currentTime, o = a.createOscillator(); o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur); const g = a.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); o.connect(g); g.connect(this.out); o.start(t); o.stop(t + dur + 0.05); },
      gap(k, ms) { const n = performance.now(); if (this.last[k] && n - this.last[k] < ms) return false; this.last[k] = n; return true; },
      gun(id, v) { if (!this.gap('g' + id, 35)) return; v = v || 1; const heavy = id === 'sg' || id === 'mk' || id === 'rv' || id === 'mc'; this.noise(heavy ? 0.22 : 0.09, heavy ? 2400 : 3600, 300, 0.32 * v, 'lowpass'); this.tone(heavy ? 120 : 170, 50, heavy ? 0.16 : 0.07, 0.25 * v, 'triangle'); },
      boom(sz, v) { if (!this.gap('b', 50)) return; v = v || 1; this.noise(0.5 + sz * 0.12, 900, 60, 0.6 * v, 'lowpass'); this.tone(80, 30, 0.4 + sz * 0.08, 0.5 * v, 'sine'); },
      beep(f, d, v) { this.tone(f, f, d || 0.08, v || 0.12, 'square'); },
      close() { try { if (this.ac) this.ac.close(); } catch (e) { /* closed */ } this.ac = null; },
    };

    /* ----- 입력 ----- */
    const loc = { mx: 0, my: 0, ax: null, ay: null, fire: 0, ads: 0, spr: 0, sw: -1, e: {}, th: null, tc: -1 };
    const mouse = { x: -1, y: -1, l: 0, r: 0, on: 0 };
    let codeBuf = '', stratOpen = 0, ready = -1, tmBuf = '', tmLast = -1, bigMap = 0, padAim = null, codeFlash = 0, codeFail = 0;
    const wasdMode = () => !!LS.get('wasd', 0);
    const edge = (k) => { loc.e[k] = 1; };
    function codeKey(ch) {
      const p = myP(); if (!p || !p.al) return;
      if (p.tm >= 0) { // 단말기 암호
        const o = p.tm >= 100 ? W.sd[p.tm - 100] : W.ob[p.tm]; if (!o || !o.c) return;
        if (o.c[tmBuf.length] === ch) { tmBuf += ch; api.sfx('tick'); Snd.beep(660 + tmBuf.length * 40, 0.05, 0.08); if (tmBuf.length >= o.c.length) { loc.tc = p.tm; tmBuf = ''; api.sfx('pop'); } }
        else { tmBuf = ''; api.sfx('warn'); codeFail = 0.4; }
        return;
      }
      if (!stratOpen) return;
      if (ready >= 0) return;
      const nb = codeBuf + ch;
      const cand = p.sl.map((si, k) => ({ k, c: STR[si].c })).filter((o) => o.c.indexOf(nb) === 0);
      if (!cand.length) { codeBuf = ''; codeFail = 0.4; api.sfx('warn'); return; }
      codeBuf = nb; Snd.beep(520 + nb.length * 45, 0.04, 0.07);
      const done = cand.find((o) => o.c === nb);
      if (done) {
        codeBuf = '';
        const ok = slotReady(p, done.k);
        if (ok) { ready = done.k; codeFlash = 0.6; api.sfx('pop'); Snd.beep(990, 0.12, 0.1); }
        else { codeFail = 0.5; api.sfx('warn'); toastOnce(slotWhy(p, done.k)); }
      }
    }
    function slotReady(p, k) { if (!W) return false; if (W.t >= W.tl) return false; const si = p.sl[k]; if (p.cd[k] > 0 || p.nU[k] === 0) return false; if (si === S_RE && (W.rein <= 0 || !W.pl.some((q) => !q.al && !q.pod))) return false; return true; }
    function slotWhy(p, k) { const si = p.sl[k]; if (W.t >= W.tl) return '작전 시간이 끝나 지원 요청을 못 해요'; if (p.nU[k] === 0) return '남은 횟수가 없어요'; if (p.cd[k] > 0) return STR[si].nm + ' — ' + Math.ceil(p.cd[k]) + '초 뒤에 써요'; if (si === S_RE) return W.rein <= 0 ? '증원이 바닥났어요' : '쓰러진 동료가 없어요'; return '지금은 못 써요'; }
    let lastToast = '', lastToastT = 0;
    function toastOnce(t) { const n = performance.now(); if (t === lastToast && n - lastToastT < 2000) return; lastToast = t; lastToastT = n; api.toast(t); }
    const offIn = api.input ? api.input.on((type, id) => {
      if (!st || st.ph !== 'play') return;
      if (type === 'down') {
        if (id === 'strat') { stratOpen = 1; codeBuf = ''; api.sfx('tick'); return; }
        const p = myP(), inCode = p && p.tm >= 0;
        const arrow = { sU: 'U', sD: 'D', sL: 'L', sR: 'R' }[id];
        const wa = { up: 'U', down: 'D', left: 'L', right: 'R' }[id];
        if (arrow) { codeKey(arrow); return; }
        if (wa && (inCode || (stratOpen && wasdMode()))) { codeKey(wa); return; }
        if (id === 'reload') edge('rl'); else if (id === 'dive') edge('dv'); else if (id === 'act') { if (inCode) { edge('tq'); tmBuf = ''; } else edge('ie'); }
        else if (id === 'gren') { if (ready >= 0) throwReady(); else edge('gr'); }
        else if (id === 'melee') edge('ml'); else if (id === 'stim') edge('stim');
        else if (id === 'w1') loc.sw = 0; else if (id === 'w2') loc.sw = 1; else if (id === 'w3') loc.sw = 2;
        else if (id === 'swap') { const q = myP(); if (q) loc.sw = q.w === 0 ? (q.sw ? 2 : 1) : q.w === 2 ? 1 : 0; }
        else if (id === 'map') bigMap = bigMap ? 0 : 1;
        else if (id === 'fire') { if (ready >= 0) throwReady(); else mouse.pad = 1; }
      } else if (type === 'up') {
        if (id === 'strat') { stratOpen = 0; codeBuf = ''; }
        else if (id === 'fire') mouse.pad = 0;
      }
    }) : null;
    function throwReady() {
      const p = myP(); if (!p || ready < 0) return;
      const a = aimWorld(); if (!a) return;
      loc.th = { sl: ready, x: a.x, y: a.y }; ready = -1; api.sfx('whoosh'); stratOpen = 0;
    }
    // 마우스
    function onMove(e) { const q = cv.local(e); mouse.x = q.x; mouse.y = q.y; mouse.on = 1; padAim = null;
      if (e.pointerType === 'mouse' && e.button >= 0 && e.type === 'pointermove') { mouse.l = e.buttons & 1 ? 1 : 0; const r = e.buttons & 2 ? 1 : 0; if (!r && mouse.r && ready >= 0) { /* keep */ } mouse.r = r; } }
    function onDown(e) {
      const q = cv.local(e); mouse.x = q.x; mouse.y = q.y; mouse.on = 1;
      if (!st || st.ph !== 'play') return;
      e.preventDefault(); try { cv.cv.setPointerCapture(e.pointerId); } catch (er) { /* */ }
      if (bigMap) { bigMap = 0; return; }
      if (e.button === 2) { if (ready >= 0) { ready = -1; api.sfx('tick'); toastOnce('지원 요청 취소'); return; } mouse.r = 1; return; }
      if (e.button === 0) { if (ready >= 0) { throwReady(); mouse.l = 0; mouse.skip = 1; return; } mouse.l = 1; }
    }
    function onUp(e) { if (e.button === 2) mouse.r = 0; if (e.button === 0) { mouse.l = 0; mouse.skip = 0; } }
    function onWheel(e) { if (!st || st.ph !== 'play') return; e.preventDefault(); const q = myP(); if (!q) return; const order = q.sw ? [0, 1, 2] : [0, 1]; const i = order.indexOf(q.w); loc.sw = order[(i + (e.deltaY > 0 ? 1 : order.length - 1)) % order.length]; }
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointermove', onMove); cv.cv.addEventListener('pointerdown', onDown); cv.cv.addEventListener('pointerup', onUp); cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('wheel', onWheel, { passive: false }); cv.cv.addEventListener('contextmenu', noCtx);
    const onBlur = () => { mouse.l = mouse.r = 0; stratOpen = 0; codeBuf = ''; };
    window.addEventListener('blur', onBlur);

    /* ----- 카메라 ----- */
    const cam = { x: MS / 2, y: MS / 2, s: 32, sh: 0, kx: 0, ky: 0 };
    function scale() { return clamp(Math.min(cv.h / 21, cv.w / 34), 22, 64); }
    const w2s = (x, y) => [(x - cam.x) * cam.s + cv.w / 2 + cam.kx, (y - cam.y) * cam.s + cv.h / 2 + cam.ky];
    const s2w = (x, y) => [(x - cv.w / 2 - cam.kx) / cam.s + cam.x, (y - cv.h / 2 - cam.ky) / cam.s + cam.y];
    function aimWorld() {
      const p = myP(); if (!p) return null;
      if (padAim) return { x: p.x + padAim[0] * 8, y: p.y + padAim[1] * 8 };
      if (mouse.on) { const q = s2w(mouse.x, mouse.y); return { x: q[0], y: q[1] }; }
      return { x: p.x + Math.cos(p.a) * 6, y: p.y + Math.sin(p.a) * 6 };
    }
    function readInput() {
      const p = myP();
      loc.mx = loc.my = 0; loc.fire = 0; loc.ads = 0; loc.spr = 0;
      if (!p || !api.input) return;
      const blockMove = (stratOpen && wasdMode()) || p.tm >= 0;
      let x = api.input.axis('left', 'right'), y = api.input.axis('up', 'down');
      if (blockMove) x = y = 0;
      const l = hyp(x, y); if (l > 1) { x /= l; y /= l; }
      loc.mx = x; loc.my = y;
      const ax = api.input.axis('aimL', 'aimR'), ay = api.input.axis('aimU', 'aimD');
      if (hyp(ax, ay) > 0.3) padAim = [ax / hyp(ax, ay), ay / hyp(ax, ay)];
      const a = aimWorld(); if (a) { loc.ax = a.x; loc.ay = a.y; }
      loc.fire = (mouse.l && !mouse.skip) || mouse.pad || api.input.held('fire') ? 1 : 0;
      if (ready >= 0) loc.fire = 0;
      loc.ads = mouse.r || api.input.held('ads') ? 1 : 0;
      loc.spr = api.input.held('sprint') ? 1 : 0;
    }
    function takeLocal() { const I = { mx: loc.mx, my: loc.my, ax: loc.ax, ay: loc.ay, fire: loc.fire, ads: loc.ads, spr: loc.spr, sw: loc.sw, th: loc.th, tc: loc.tc, rl: loc.e.rl, dv: loc.e.dv, ie: loc.e.ie, gr: loc.e.gr, ml: loc.e.ml, stim: loc.e.stim, tq: loc.e.tq }; return I; }
    function clearEdges() { loc.e = {}; loc.th = null; loc.tc = -1; loc.sw = -1; }

    /* ----- 온라인 ----- */
    const remIn = {}, remC = {};
    let pubT = 0, hsQ = 0, lastQ = -1, lastFx = 0, netC = { rl: 0, dv: 0, ie: 0, gr: 0, ml: 0, stim: 0, tq: 0, th: 0, tc: 0 }, netTh = null, netTc = null, lastSig = '', sigT = 0;
    function pollHost() {
      if (!api.online || !api.isHost || !st) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s >= 0 && s < st.np) || isAIseat(s) || localHuman(s) || !o || typeof o !== 'object') continue;
        if (st.ph === 'load' && o.k === 'L' + st.mk) { // 장비 고르기
          const lo = validLo(st, o.lo), rd = o.rd ? 1 : 0;
          if (lo && (JSON.stringify(st.lo[s]) !== JSON.stringify(lo) || st.rd[s] !== rd)) { const n = U.clone(st); n.lo[s] = lo; n.rd[s] = rd; api.setState(n); }
          continue;
        }
        if (!W || o.k !== key) continue;
        const R = remIn[s] || (remIn[s] = {}), C = remC[s] || (remC[s] = {});
        if (o.q !== C.q) { C.q = o.q; C.lt = performance.now(); }
        R.mx = fin(+o.mx) ? clamp(+o.mx, -1, 1) : 0; R.my = fin(+o.my) ? clamp(+o.my, -1, 1) : 0;
        R.ax = fin(+o.ax) ? +o.ax : null; R.ay = fin(+o.ay) ? +o.ay : null;
        R.fire = o.f ? 1 : 0; R.ads = o.ad ? 1 : 0; R.spr = o.sp ? 1 : 0; R.sw = Number.isInteger(o.sw) ? o.sw : -1;
        const h = o.h || {};
        for (const nmK of ['rl', 'dv', 'ie', 'gr', 'ml', 'stim', 'tq']) { const v = h[nmK] | 0; if (C[nmK] !== undefined && v !== C[nmK]) R[nmK] = 1; C[nmK] = v; }
        if (Array.isArray(o.th) && o.th[0] !== C.th) { if (C.th !== undefined) R.th = { sl: o.th[1] | 0, x: +o.th[2], y: +o.th[3] }; C.th = o.th[0]; }
        if (Array.isArray(o.tc) && o.tc[0] !== C.tc) { if (C.tc !== undefined) R.tc = o.tc[1] | 0; C.tc = o.tc[0]; }
      }
    }
    function pollGuest() {
      if (!api.online || api.isHost || !W) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (!hs || typeof hs !== 'object' || hs.k !== key || hs.q === lastQ || !Array.isArray(hs.P)) return;
      lastQ = hs.q;
      if (Array.isArray(hs.fx)) for (const e of hs.fx) if (Array.isArray(e) && e[0] > lastFx) { lastFx = e[0]; onFx(e); }
      try { applySnap(W, hs, auto() ? -1 : me()); } catch (er) { console.error(er); }
    }
    function publish(rdt) {
      if (!api.online || !st) return;
      pubT -= rdt; sigT -= rdt;
      try {
        if (api.isHost) {
          if (!W || st.ph !== 'play' || pubT > 0) return;
          pubT = 1 / 15; hsQ = (hsQ + 1) % 100000;
          api.net.hostSend(snapshot(W, key, hsQ, 0));
        } else if (st.ph === 'load') {
          if (pubT > 0) return; pubT = 0.4;
          const m = me(); if (m < 0) return;
          api.net.publish({ k: 'L' + st.mk, lo: myLo, rd: myRd ? 1 : 0 });
        } else if (st.ph === 'play' && W) {
          const m = me(); if (m < 0 || pubT > 0 || auto()) return;
          const I = loc;
          if (I.e.rl) netC.rl++; if (I.e.dv) netC.dv++; if (I.e.ie) netC.ie++; if (I.e.gr) netC.gr++; if (I.e.ml) netC.ml++; if (I.e.stim) netC.stim++; if (I.e.tq) netC.tq++;
          if (I.th) { netC.th++; netTh = [netC.th, I.th.sl, r1(I.th.x), r1(I.th.y)]; }
          if (I.tc >= 0) { netC.tc++; netTc = [netC.tc, I.tc]; }
          const msg = { q: (netC.q = ((netC.q | 0) + 1) % 100000), k: key, mx: r2(I.mx), my: r2(I.my), ax: I.ax === null ? null : r1(I.ax), ay: I.ay === null ? null : r1(I.ay), f: I.fire, ad: I.ads, sp: I.spr, sw: I.sw, h: { rl: netC.rl, dv: netC.dv, ie: netC.ie, gr: netC.gr, ml: netC.ml, stim: netC.stim, tq: netC.tq }, th: netTh, tc: netTc };
          const sig = JSON.stringify(msg);
          clearEdges();
          if (sig.replace(/^\{"q":\d+,/, '{') === lastSig && sigT > 0) { netC.q--; return; }
          lastSig = sig.replace(/^\{"q":\d+,/, '{'); sigT = 0.3; pubT = 1 / 20;
          api.net.publish(msg);
        }
      } catch (e) { /* offline */ }
    }

    /* ----- 효과 (이 기기에서만) ----- */
    let parts = [], rings = [], tracers = [], corpses = [], floats = [], beams = [], banner = null, shake = 0, hurtA = 0, flashA = 0, ffWarn = 0, hitMk = 0;
    let mapCv = null, mapKey = '';
    const fcSeen = {}, tuSeen = {};
    function addParts(x, y, n, c, sp, life, sz, up) { for (let k = 0; k < n; k++) { const a = Math.random() * TAU, v = sp * (0.3 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (up || 0), t: 0, l: life * (0.6 + Math.random() * 0.7), c, s: sz * (0.5 + Math.random()), g: up ? 1 : 0 }); } if (parts.length > 500) parts.splice(0, parts.length - 500); }
    function smoke(x, y, n, sz) { for (let k = 0; k < n; k++) parts.push({ x: x + (Math.random() - 0.5) * sz, y: y + (Math.random() - 0.5) * sz, vx: (Math.random() - 0.5) * 0.8, vy: (Math.random() - 0.5) * 0.8, t: 0, l: 1.5 + Math.random() * 1.5, c: 'smoke', s: sz * (0.6 + Math.random() * 0.6), g: 0 }); }
    function scorch(x, y, r, c) { if (!mapCv) return; const g = mapCv.getContext('2d'), k = mapCv.width / MS; const gr = g.createRadialGradient(x * k, y * k, 0, x * k, y * k, r * k); gr.addColorStop(0, c || 'rgba(15,12,10,.55)'); gr.addColorStop(1, 'rgba(15,12,10,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x * k, y * k, r * k, 0, TAU); g.fill(); }
    function nearCam(x, y, r) { return Math.abs(x - cam.x) < cv.w / cam.s / 2 + r && Math.abs(y - cam.y) < cv.h / cam.s / 2 + r; }
    const OBJ_T = {
      1: (f) => FAC[f].hive + ' 파괴!', 2: () => '송신 시작 — 단말기 곁(원 안)을 지키세요', 3: () => '발전기 가동!', 4: () => '거점 사수 시작 — 원 안에서 90초 버티기', 5: () => '발사 준비 — 35초 동안 지키세요',
      6: () => '대피소 개방 — 피난민을 착륙장까지 지켜 주세요', 7: () => '송신 완료!', 8: () => '거점 사수 성공!', 9: () => '주 목표 완료 — 탈출 지점에서 탈출선을 부르세요(E)', 10: () => '피난민 구조 완료!', 11: () => '화물 도착!',
      20: () => '적 통신탑 파괴 — 적 증원이 줄어요', 21: () => '보급 저장고 열림 — 표본 +3', 22: () => '신호기 가동 — 요청 점수 +3',
    };
    function say(s, s2, c, ms) { banner = { s, s2: s2 || '', c: c || '#ffd257', t: 0, l: (ms || 3200) / 1000 }; }
    function onFx(e) {
      const code = e[1], x = e[2], y = e[3], a = e[4], b = e[5], m = auto() ? -1 : me(), seen = nearCam(x, y, 6), dist = hyp(x - cam.x, y - cam.y), vol = clamp(1.2 - dist / 40, 0.15, 1);
      if (code === FX.BOOM) {
        const r = a / 10, kind = b;
        if (kind === 4) { addParts(x, y, 4, '#ffd27a', 4, 0.25, 0.08); if (seen) Snd.gun('mg', 0.4 * vol); return; }
        rings.push({ x, y, t: 0, r: r * 1.5, c: kind === 2 ? '#9fdcff' : kind === 3 ? '#ff8a3a' : kind === 5 ? '#9be36b' : '#fff1c4', l: 0.45 + r * 0.04 });
        if (kind === 5) { addParts(x, y, 10, '#9be36b', 3, 0.5, 0.1); scorch(x, y, r * 0.8, 'rgba(80,140,40,.35)'); if (seen) Snd.noise(0.25, 1200, 200, 0.2 * vol); return; }
        if (kind === 2) { addParts(x, y, 16, '#cfefff', 6, 0.4, 0.07); if (seen) Snd.tone(1800, 300, 0.3, 0.1 * vol, 'sawtooth'); return; }
        addParts(x, y, 10 + r * 6, '#ffcf6a', 4 + r * 2.5, 0.45, 0.14); addParts(x, y, 6 + r * 3, '#ff6a2a', 2 + r * 1.5, 0.6, 0.18);
        smoke(x, y, 3 + Math.round(r * 2), r * 0.9);
        scorch(x, y, r * 0.9);
        if (r >= 1.4) flashA = Math.max(flashA, Math.min(0.6, r * 0.08) * (seen ? 1 : 0));
        if (seen || dist < 30) { shake = Math.max(shake, clamp(r * 0.12 * vol, 0.05, 0.9)); Snd.boom(r, vol); }
      } else if (code === FX.EDIE) {
        const T = EN[a]; if (!T) return; const ang = b / 10;
        corpses.push({ x, y, t: a, a: ang + (Math.random() - 0.5), vx: Math.cos(ang) * (T.tier < 2 ? 4 : 1), vy: Math.sin(ang) * (T.tier < 2 ? 4 : 1), sp: (Math.random() - 0.5) * 8, life: 9 });
        if (corpses.length > 70) corpses.shift();
        const fc = T.f === 0 ? '#c8a03a' : T.f === 1 ? '#555' : '#b68cff';
        addParts(x, y, T.tier >= 2 ? 26 : 8, fc, T.tier >= 2 ? 5 : 3, 0.5, 0.1);
        scorch(x, y, T.r * 1.4, T.f === 0 ? 'rgba(160,120,30,.35)' : T.f === 1 ? 'rgba(20,20,20,.4)' : 'rgba(120,70,180,.3)');
        if (T.tier === 2 && seen) { say(T.nm + ' 처치!', '', '#9be36b', 1800); shake = Math.max(shake, 0.3); }
      } else if (code === FX.PDIE) {
        addParts(x, y, 20, '#c0392b', 4, 0.8, 0.1); scorch(x, y, 0.9, 'rgba(120,20,20,.5)');
        if (a === m) { say('쓰러졌어요!', b >= 0 && b !== a ? nm(b) + '의 사고(아군 사격)!' : '동료가 「증원」을 부르면 다시 내려가요', '#ee6a55', 4000); api.sfx('lose'); api.buzz(200); }
        else { floats.push({ x, y, t: 0, s: nm(a) + ' 쓰러짐', c: '#ee6a55' }); api.sfx('thud'); if (b === m && m >= 0) say('아군을 맞혔어요!', '사격 방향을 조심하세요', '#ee6a55', 2600); }
      } else if (code === FX.BNC) { if (seen) { floats.push({ x, y: y - 0.4, t: 0, s: a === 1 ? '막힘' : a === 2 ? '쿵! 기절' : '튕김', c: '#cfd8e8' }); addParts(x, y, 3, '#fff', 3, 0.2, 0.05); if (Snd.gap('bnc', 120)) Snd.tone(2400, 1800, 0.05, 0.05); } }
      else if (code === FX.BEAC) { const S = STR[a]; if (b === m) { api.sfx('chip'); } if (seen) Snd.beep(880, 0.1, 0.06); if (S && S.dl > 2 && dangerR(a) > 4) floats.push({ x, y: y - 0.6, t: 0, s: S.nm + '!', c: '#ff5a4a' }); }
      else if (code === FX.BREACH) { const msg = a === 0 ? '땅굴 무리가 솟아올라요!' : a === 1 ? '적 수송선 접근!' : '공허 균열이 열려요!'; rings.push({ x, y, t: 0, r: 3, c: FAC[a].c, l: 1.5 }); smoke(x, y, 8, 2); if (dist < 30) say(msg, b + '마리 증원', FAC[a].c, 2200); api.sfx('warn'); }
      else if (code === FX.POD) { rings.push({ x, y, t: 0, r: 2.2, c: '#9fdcff', l: 0.5 }); addParts(x, y, 14, '#d7e6ff', 4, 0.5, 0.1); smoke(x, y, 5, 1.2); scorch(x, y, 1.3); if (seen) { shake = Math.max(shake, 0.25); Snd.boom(1, vol); } if (b === 0 && a !== m) floats.push({ x, y: y - 0.8, t: 0, s: nm(a) + ' 증원!', c: '#9fdcff' }); if (b === 0 && a === m) say('다시 투입!', '', '#9fdcff', 1800); }
      else if (code === FX.SMP) { if (a === m) { floats.push({ x, y, t: 0, s: '표본 +' + b, c: '#7ff0c8' }); api.sfx('chip'); } }
      else if (code === FX.PICK) { if (a === m) { floats.push({ x, y, t: 0, s: b === 2 ? '보급 완료' : b === 3 ? '지원 화기!' : '방패 배낭!', c: '#9fdcff' }); api.sfx('chip'); } }
      else if (code === FX.OBJ) { const f = OBJ_T[a]; if (f) { say(f(W ? W.fac : 0), '', a === 9 ? '#9be36b' : '#ffd257', 3800); api.sfx(a === 9 || a === 7 || a === 8 || a === 10 || a === 11 ? 'win' : 'go'); } }
      else if (code === FX.EXT) { if (a === 2) say('탈출선 호출 — ' + Math.round(W ? W.ex.t : 60) + '초 버티세요', '적이 몰려와요!', '#9fdcff', 3500); else if (a === 3) { say('탈출선 착륙! 원 안으로 들어가세요', '모두 타거나 25초가 지나면 떠나요', '#9be36b', 4000); api.sfx('go'); } else if (a === 5 && b === m) { say('탑승 완료', '동료를 기다려요', '#9be36b', 3000); api.sfx('win'); } }
      else if (code === FX.LASER) { beams.push({ x, y, x2: a / 10, y2: b / 10, t: 0, l: 0.22, c: W && W.fac === 2 ? '#c49bff' : '#ff4a4a' }); if (seen && Snd.gap('las', 90)) Snd.tone(1400, 900, 0.08, 0.05, 'sawtooth'); }
      else if (code === FX.RAIL) { beams.push({ x, y, x2: a / 10, y2: b / 10, t: 0, l: 0.35, c: '#9fe8ff', w: 3 }); if (seen) Snd.tone(300, 2400, 0.25, 0.15, 'sawtooth'); }
      else if (code === FX.STIM) { if (a === m) { floats.push({ x, y, t: 0, s: '치료제!', c: '#7ff0c8' }); api.sfx('pop'); } }
      else if (code === FX.MEL) { addParts(x, y, 5, '#fff', 3, 0.2, 0.06); if (seen) Snd.noise(0.08, 1800, 600, 0.15, 'bandpass', 2); }
      else if (code === FX.FF) { if (a === m) { ffWarn = 2; say('아군 사격!', nm(b) + '에게 맞았어요', '#ee6a55', 1600); } else if (b === m) { ffWarn = 2; floats.push({ x, y: y - 0.6, t: 0, s: '아군!', c: '#ee6a55' }); } }
      else if (code === FX.CIV) { floats.push({ x, y, t: 0, s: a ? '구조!' : '피난민 희생', c: a ? '#9be36b' : '#ee6a55' }); api.sfx(a ? 'chip' : 'thud'); }
      else if (code === FX.BLINK) { addParts(x, y, 8, '#b68cff', 2, 0.4, 0.08); addParts(a / 10, b / 10, 8, '#b68cff', 2, 0.4, 0.08); }
      else if (code === FX.LAUNCH) { say('미사일 발사!', '목표 달성', '#ffd257', 3500); rings.push({ x, y, t: 0, r: 8, c: '#fff', l: 1.4 }); smoke(x, y, 20, 3); shake = Math.max(shake, 0.6); Snd.boom(6, 1); }
      else if (code === FX.TIME) { say(a ? '작전 시간 종료 — 지원 요청이 끊겼어요' : '작전 시간 초과', a ? '서둘러 탈출하세요!' : '', '#ee6a55', 4500); api.sfx('warn'); }
      else if (code === FX.NOPE) { if (b === m) toastOnce(a === 1 ? '발전기 2개를 먼저 켜야 해요' : '지원 요청을 못 했어요'); }
      else if (code === FX.ESHOT) { if (seen && Snd.gap('es', 70)) Snd.noise(0.1, 1500, 300, 0.08 * vol); }
      else if (code === FX.GREN) { if (seen) Snd.noise(0.12, 900, 300, 0.06, 'bandpass', 1); }
      else if (code === FX.DROPIN) { say(st && st.mi ? PLANETS[st.mi.pi].nm + ' — ' + MT[st.mi.mt].nm : '강하!', '부대 투입', '#ffd257', 3500); }
      else if (code === FX.EJECT) { if (seen) api.sfx('thud'); }
    }
    function hostFx() { if (!W) return; for (const e of W.fx) if (e[0] > lastFx) { lastFx = e[0]; onFx(e); } }

    /* ----- 작전 준비 화면 (장비 · 은하 전선 · 함선 개량) ----- */
    let ov = null, ovKind = '', ovSig = '', tab = LS.get('tab', 'eq'), hoverTip = '', pbar = null, endT = 0, autoRd = 0, galCv = null;
    let myLo = null, myRd = 0;
    function defaultLo() { const u = st.unl.filter((id) => STR[SI[id]].cost >= 0); return [0, 0, 0, 1].concat(u.slice(0, 4).map((id) => SI[id])); }
    function fixLo(lo) { const v = validLo(st, lo); if (v) return v; const d = defaultLo(); if (Array.isArray(lo)) { for (let i = 0; i < 4; i++) if (Number.isInteger(lo[i])) d[i] = lo[i]; const ss = (lo.slice(4) || []).filter((si) => STR[si] && STR[si].cost >= 0 && st.unl.indexOf(STR[si].id) >= 0); const rest = d.slice(4).filter((si) => ss.indexOf(si) < 0); const all = ss.concat(rest).slice(0, 4); for (let i = 0; i < 4; i++) d[4 + i] = all[i]; } return validLo(st, d) || defaultLo(); }
    function closeOv() { if (ov) { ov.remove(); ov = null; ovKind = ''; ovSig = ''; } if (pbar) { pbar.destroy(); pbar = null; } }
    const picked = (s) => !!(st && st.rd && st.rd[s]) || (auto() && localHuman(s));
    function sendLo(rd) {
      const m = me(); if (m < 0) return;
      myLo = fixLo(myLo); myRd = rd ? 1 : 0; LS.set('lo', myLo);
      if (host()) { const n = U.clone(st); n.lo[m] = myLo; n.rd[m] = myRd; api.setState(n); }
      else { pubT = 0; publish(0); }
      ovSig = '';
    }
    function hostSet(fn) { if (!host()) return; const n = U.clone(st); fn(n); api.setState(n); }
    function statLine(w) { const parts = []; if (w.pel) parts.push('피해 ' + w.dmg + '×' + w.pel); else parts.push('피해 ' + w.dmg); parts.push('관통 ' + w.ap); if (w.iv) parts.push('분당 ' + Math.round(60 / w.iv) + '발'); parts.push('탄창 ' + w.mag); if (w.ex) parts.push('폭발 ' + w.ex); return parts.join(' · '); }
    function chip(label, ic, on, onclick, tip, extra) {
      const b = L.h('button', { class: 'sf-chip' + (on ? ' on' : '') + (extra && extra.lock ? ' lock' : '') });
      if (ic) b.appendChild(L.h('span', { class: 'ic', text: ic }));
      const t = L.h('span', { text: label }); b.appendChild(t);
      if (extra && extra.code) b.appendChild(L.h('span', { class: 'cd', text: extra.code }));
      if (extra && extra.cost) b.appendChild(L.h('span', { class: 'cost', text: extra.cost }));
      if (tip) { b.title = tip; b.addEventListener('pointerenter', () => { hoverTip = tip; const el = ov && ov.querySelector('.sf-tip'); if (el) el.textContent = tip; }); }
      b.addEventListener('click', (e) => { e.preventDefault(); api.sfx('click'); onclick(); });
      return b;
    }
    function buildLoad() {
      const m = me();
      if (m >= 0 && !myLo) myLo = fixLo(LS.get('lo', null));
      if (m >= 0) { myLo = fixLo(myLo); if (host()) myRd = st.rd[m] ? 1 : 0; }
      if (m >= 0 && !host() && auto() && !myRd) { sendLo(1); return; }
      const sig = JSON.stringify([st.mk, st.mi, st.rd, st.lo, st.unl, st.upg, st.req, st.smp, myLo, tab, wasdMode()]);
      if (ovKind === 'load' && sig === ovSig) { if (pbar) pbar.update(); drawGal(); return; }
      if (ovKind !== 'load') closeOv();
      ovSig = sig;
      if (!ov) { ov = L.h('div', { class: 'sf-ov' }); root.appendChild(ov); ovKind = 'load'; }
      ov.innerHTML = '';
      const mi = st.mi, pl = PLANETS[mi.pi], fac = FAC[pl.f];
      const hd = L.h('div', { class: 'sf-hd' });
      hd.appendChild(L.h('h2', { text: '작전 준비' }));
      hd.appendChild(L.h('div', { class: 'sub', text: '작전 ' + (st.done + 1) + ' / ' + st.ops + ' · 난이도 ' + DIFF[st.dif].nm + ' · 제한 ' + st.tl + '분' }));
      const res = L.h('div', { class: 'res' });
      res.appendChild(L.h('span', { text: '요청 점수 ' + st.req, title: '작전 성공으로 얻어요. 새 지원 요청을 해금해요.' }));
      res.appendChild(L.h('span', { text: '표본 ' + st.smp, title: '탈출할 때 가지고 온 표본. 함선 개량에 써요.' }));
      res.appendChild(L.h('span', { text: '해방 ' + st.lib.filter((v) => v >= 100).length + '/9' }));
      hd.appendChild(res); ov.appendChild(hd);
      const body = L.h('div', { class: 'sf-body' }); ov.appendChild(body);
      // 왼쪽: 은하 전선 · 작전 설명 · 부대
      const left = L.h('div', { class: 'sf-col' }); body.appendChild(left);
      const gc = L.h('div', { class: 'sf-card' });
      gc.appendChild(L.h('h3', { text: '은하 전선', }));
      galCv = L.h('canvas', { class: 'sf-gal' }); gc.appendChild(galCv);
      galCv.addEventListener('click', (e) => { if (!host()) { api.toast('행성은 방장이 골라요'); return; } const r = galCv.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top; const hit = galHit(x, y, r.width, r.height); if (hit >= 0) { if (availPlanets(st.lib).indexOf(hit) < 0) { api.toast(st.lib[hit] >= 100 ? '이미 해방한 행성이에요' : '앞 행성을 먼저 해방해야 해요'); return; } api.sfx('click'); hostSet((n) => { n.mi = planMission(n, hit); }); } });
      gc.appendChild(L.h('div', { class: 'sf-tip', text: host() ? '행성을 누르면 그곳으로 작전을 바꿔요(기본: 무작위). 행성의 해방도가 100%가 되면 다음 행성이 열려요.' : '방장이 행성을 골라요.' }));
      left.appendChild(gc);
      const bc = L.h('div', { class: 'sf-card sf-brief' });
      bc.appendChild(L.h('h3', { text: pl.nm + ' — ' + MT[mi.mt].nm }));
      bc.appendChild(L.h('p', { html: '<b>적</b> ' + fac.full + ' · ' + fac.d }));
      bc.appendChild(L.h('p', { html: '<b>주 목표</b> ' + MT[mi.mt].d(pl.f) }));
      bc.appendChild(L.h('p', { html: '<b>보조 목표</b> ' + mi.sd.map((k) => SIDE[k].nm).join(', ') + ' — ' + mi.sd.map((k) => SIDE[k].d).join(' ') }));
      bc.appendChild(L.h('p', { html: '<b>끝내기</b> 주 목표를 끝내고 탈출 지점에서 탈출선을 불러(E) 버틴 뒤 타요. 표본은 탈출해야 남아요.' }));
      bc.appendChild(L.h('p', { html: '<b>행성</b> ' + pl.d + ' 해방도 ' + st.lib[mi.pi] + '% (성공 +' + (20 + st.dif * 3) + '%)' }));
      if (host()) bc.appendChild(L.h('button', { class: 'sf-btn', text: '🎲 다른 작전', style: { marginTop: '6px' }, onclick: () => { api.sfx('click'); hostSet((n) => { n.mi = planMission(n, n.mi.pi); }); } }));
      left.appendChild(bc);
      const sq = L.h('div', { class: 'sf-card' }); sq.appendChild(L.h('h3', { text: '부대' }));
      const sqr = L.h('div', { class: 'sf-sq' });
      for (let s = 0; s < st.np; s++) { const lo = st.lo[s]; const d = L.h('div'); const dot = L.h('i'); dot.style.background = COL(s); d.appendChild(dot); d.appendChild(L.h('span', { text: nm(s) + (isAIseat(s) ? ' (AI ' + ['', '쉬움', '보통', '어려움'][lvOf(s)] + ')' : '') })); d.appendChild(L.h('span', { text: st.rd[s] ? (lo ? ' ' + PRI[lo[0]].ic + ARM[lo[3]].ic + lo.slice(4).map((si) => STR[si].ic).join('') : ' ✓') : ' …고르는 중', style: { color: st.rd[s] ? '#9be36b' : '#9fb0c8' } })); sqr.appendChild(d); }
      sq.appendChild(sqr); left.appendChild(sq);
      // 오른쪽: 장비 / 지원 요청 / 함선 개량
      const right = L.h('div', { class: 'sf-col' }); body.appendChild(right);
      const tabs = L.h('div', { class: 'sf-tabs' });
      [['eq', '🎒 장비'], ['st', '📡 지원 요청'], ['up', '🛠 함선 개량']].forEach(([k, t]) => tabs.appendChild(L.h('button', { class: tab === k ? 'on' : '', text: t, onclick: () => { tab = k; LS.set('tab', k); api.sfx('click'); ovSig = ''; buildLoad(); } })));
      right.appendChild(tabs);
      const card = L.h('div', { class: 'sf-card' }); right.appendChild(card);
      const canEdit = m >= 0;
      const setLo = (i, v) => { if (!canEdit) return; myLo[i] = v; sendLo(myRd); };
      if (tab === 'eq') {
        const sec = (title, arr, idx, desc) => { card.appendChild(L.h('h3', { text: title })); const row = L.h('div', { class: 'sf-row' }); arr.forEach((w, i) => row.appendChild(chip(w.nm, w.ic, canEdit && myLo[idx] === i, () => setLo(idx, i), w.nm + ' — ' + desc(w)))); card.appendChild(row); };
        sec('주무기', PRI, 0, (w) => w.tag + '. ' + w.d + ' (' + statLine(w) + ')');
        sec('보조 무기', SEC, 1, (w) => w.tag + '. ' + w.d + ' (' + statLine(w) + ')');
        sec('수류탄', GRE, 2, (g) => g.d + (g.dmg ? ' (피해 ' + g.dmg + ' · 관통 ' + g.ap + ' · 반경 ' + g.r + ')' : ''));
        sec('갑옷', ARM, 3, (a) => a.w + ' · 속도 ' + Math.round(a.sp * 100) + '% · 받는 피해 ' + Math.round(a.tk * 100) + '% · 특성: ' + a.pd);
      } else if (tab === 'st') {
        card.appendChild(L.h('h3', { html: '내 지원 요청 4개 <small>+ 증원·보급품은 기본</small>' }));
        const sel = L.h('div', { class: 'sf-row' });
        (canEdit ? myLo.slice(4) : []).forEach((si) => { const S = STR[si]; sel.appendChild(chip(S.nm, S.ic, true, () => {}, S.nm + ' — ' + S.d, { code: codeStr(S.c) })); });
        card.appendChild(sel);
        const cats = ['궤도', '항공', '지원 화기', '방어', '탑승물'];
        cats.forEach((c) => {
          card.appendChild(L.h('h3', { html: c + ' <small>' + (c === '항공' ? '정해진 횟수를 쓰면 재무장' : c === '지원 화기' ? '3번 무기 칸에 들어와요(무기 3)' : '') + '</small>' }));
          const row = L.h('div', { class: 'sf-row' });
          SLOTSTR.filter((S) => S.cat === c).forEach((S) => {
            const si = SI[S.id], unl = st.unl.indexOf(S.id) >= 0, on = canEdit && myLo.slice(4).indexOf(si) >= 0;
            const tip = S.nm + ' — ' + S.d + ' (도착 ' + S.dl + '초 · 재사용 ' + Math.round(cdOf({ dif: st.dif, upg: st.upg }, si)) + '초' + (S.n ? ' · ' + S.n + '번' : '') + ') 암호 ' + codeStr(S.c);
            row.appendChild(chip(S.nm, S.ic, on, () => {
              if (!unl) { if (!host()) { api.toast('해금은 방장이 해요'); return; } if (st.req < S.cost) { api.toast('요청 점수가 ' + (S.cost - st.req) + ' 모자라요'); return; } hostSet((n) => { n.req -= S.cost; n.unl.push(S.id); }); api.toast(S.nm + ' 해금!'); return; }
              if (!canEdit) return;
              const cur = myLo.slice(4), at = cur.indexOf(si);
              if (at >= 0) return;
              cur.shift(); cur.push(si); for (let i = 0; i < 4; i++) myLo[4 + i] = cur[i]; sendLo(myRd);
            }, tip, unl ? { code: codeStr(S.c) } : { lock: 1, cost: '🔒 ' + S.cost + '점' }));
          });
          card.appendChild(row);
        });
      } else {
        card.appendChild(L.h('h3', { html: '함선 개량 <small>표본으로 — 이 판(저장) 안에서만 유지</small>' }));
        UPG.forEach((u, i) => {
          const lvN = st.upg[i] | 0, max = u.cost.length, cost = u.cost[lvN];
          const row = L.h('div', { class: 'sf-row', style: { alignItems: 'center', marginBottom: '6px' } });
          row.appendChild(L.h('div', { style: { flex: '1 1 200px', fontSize: '13px' }, html: '<b>' + u.nm + '</b> ' + '●'.repeat(lvN) + '○'.repeat(max - lvN) + '<br><span style="color:#9fb0c8">' + u.d + '</span>' }));
          row.appendChild(chip(lvN >= max ? '최대' : '개량 (표본 ' + cost + ')', '🛠', false, () => {
            if (lvN >= max) return; if (!host()) { api.toast('개량은 방장이 해요'); return; } if (st.smp < cost) { api.toast('표본이 ' + (cost - st.smp) + '개 모자라요'); return; }
            hostSet((n) => { n.smp -= cost; n.upg[i] = lvN + 1; }); api.toast(u.nm + ' 개량!');
          }, u.d));
          card.appendChild(row);
        });
      }
      card.appendChild(L.h('div', { class: 'sf-tip', text: hoverTip || '항목에 마우스를 올리면 설명이 나와요.' }));
      // 아래: 입력 방식 · 준비
      const ft = L.h('div', { class: 'sf-ft' }); ov.appendChild(ft);
      ft.appendChild(chip('암호 입력: ' + (wasdMode() ? '방향키 + WASD' : '방향키만'), '⌨', wasdMode(), () => { LS.set('wasd', wasdMode() ? 0 : 1); ovSig = ''; buildLoad(); }, '지원 요청 키(Ctrl·C)를 누르고 있는 동안 WASD도 방향 암호로 써요(그동안 멈춰 서요). 방향키만이면 걸으면서 입력해요.'));
      const pbHold = L.h('div', { style: { flex: '1 1 auto', position: 'relative', minHeight: '44px' } }); ft.appendChild(pbHold);
      if (pbar) { pbar.destroy(); pbar = null; }
      pbar = api.pickBar({ picked, parent: pbHold, style: { position: 'static', transform: 'none' }, onForce: () => hostSet((n) => { for (let s = 0; s < n.np; s++) if (!n.rd[s]) { n.lo[s] = n.lo[s] ? validLo(n, n.lo[s]) || aiLoadout(n, s) : aiLoadout(n, s); n.rd[s] = 1; } }) });
      if (canEdit) {
        const rb = L.h('button', { class: 'sf-btn pri' + (myRd ? ' off' : ''), text: myRd ? '준비 완료 ✓ (누르면 취소)' : '출격 준비', 'data-key': 'Enter' });
        rb.addEventListener('click', () => { api.sfx(myRd ? 'click' : 'go'); sendLo(!myRd); });
        ft.appendChild(rb);
      }
      drawGal();
    }
    function galPos(i, w, h) { const P0 = PLANETS[i], cx = w * (0.18 + P0.sec * 0.32), cy = h * (0.3 + (i % 3) * 0.25) + (P0.sec === 1 ? -8 : 0); return [cx, cy]; }
    function galHit(x, y, w, h) { for (let i = 0; i < 9; i++) { const q = galPos(i, w, h); if (hyp(q[0] - x, q[1] - y) < 26) return i; } return -1; }
    function drawGal() {
      if (!galCv || !st) return;
      const r = galCv.getBoundingClientRect(), w = Math.max(10, Math.round(r.width)), h = Math.max(10, Math.round(r.height)), d = Math.min(2, window.devicePixelRatio || 1);
      if (galCv.width !== Math.round(w * d)) { galCv.width = Math.round(w * d); galCv.height = Math.round(h * d); }
      const g = galCv.getContext('2d'); g.setTransform(d, 0, 0, d, 0, 0);
      g.fillStyle = '#070a12'; g.fillRect(0, 0, w, h);
      const R = rng(7); for (let i = 0; i < 90; i++) { g.fillStyle = 'rgba(255,255,255,' + (0.2 + R() * 0.6) + ')'; g.fillRect(R() * w, R() * h, R() < 0.1 ? 2 : 1, R() < 0.1 ? 2 : 1); }
      const av = availPlanets(st.lib), t = performance.now() / 1000;
      for (let s = 0; s < 3; s++) {
        const cx = w * (0.18 + s * 0.32);
        const gr = g.createRadialGradient(cx, h * 0.55, 10, cx, h * 0.55, w * 0.2); gr.addColorStop(0, FAC[s].c + '33'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(cx - w * 0.2, 0, w * 0.4, h);
        g.fillStyle = FAC[s].c; g.font = '700 11px ' + BODY; g.textAlign = 'center'; g.fillText(SECTORS[s], cx, 14);
        g.strokeStyle = 'rgba(255,255,255,.15)'; g.lineWidth = 1; g.beginPath(); for (let k = 0; k < 3; k++) { const q = galPos(s * 3 + k, w, h); if (k) g.lineTo(q[0], q[1]); else g.moveTo(q[0], q[1]); } g.stroke();
      }
      for (let i = 0; i < 9; i++) {
        const P0 = PLANETS[i], q = galPos(i, w, h), lib = st.lib[i], open = av.indexOf(i) >= 0, cur = st.mi && st.mi.pi === i;
        const pr = 15;
        const gr = g.createRadialGradient(q[0] - 5, q[1] - 5, 2, q[0], q[1], pr); gr.addColorStop(0, P0.g[0]); gr.addColorStop(1, P0.rk); g.fillStyle = gr;
        g.globalAlpha = open || lib >= 100 ? 1 : 0.4; g.beginPath(); g.arc(q[0], q[1], pr, 0, TAU); g.fill();
        g.lineWidth = 3; g.strokeStyle = 'rgba(255,255,255,.12)'; g.beginPath(); g.arc(q[0], q[1], pr + 4, 0, TAU); g.stroke();
        g.strokeStyle = lib >= 100 ? '#9be36b' : '#ffd257'; g.beginPath(); g.arc(q[0], q[1], pr + 4, -Math.PI / 2, -Math.PI / 2 + TAU * lib / 100); g.stroke();
        if (cur) { g.strokeStyle = 'rgba(255,210,87,' + (0.5 + 0.4 * Math.sin(t * 4)) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(q[0], q[1], pr + 9, 0, TAU); g.stroke(); }
        g.globalAlpha = 1;
        g.fillStyle = '#e9eef5'; g.font = '600 11px ' + BODY; g.textAlign = 'center'; g.fillText(P0.nm, q[0], q[1] + pr + 17);
        g.font = '600 10px ' + MONO; g.fillStyle = lib >= 100 ? '#9be36b' : '#9fb0c8'; g.fillText(lib >= 100 ? '해방' : open ? lib + '%' : '🔒', q[0], q[1] + 4);
      }
    }
    function buildEnd() {
      const sig = JSON.stringify([st.mk, st.res, Math.ceil(endT)]);
      if (ovKind === 'end' && sig === ovSig) return;
      if (ovKind !== 'end') closeOv();
      ovSig = sig;
      if (!ov) { ov = L.h('div', { class: 'sf-ov sf-end' }); root.appendChild(ov); ovKind = 'end'; }
      ov.innerHTML = '';
      const R0 = st.res || {}, pl = PLANETS[st.mi.pi];
      const hd = L.h('div', { class: 'sf-hd' }); hd.appendChild(L.h('h2', { text: '작전 보고' })); hd.appendChild(L.h('div', { class: 'sub', text: pl.nm + ' · ' + MT[st.mi.mt].nm + ' · ' + DIFF[st.dif].nm })); ov.appendChild(hd);
      const body = L.h('div', { class: 'sf-body' }); ov.appendChild(body);
      const left = L.h('div', { class: 'sf-col' }); body.appendChild(left);
      const c1 = L.h('div', { class: 'sf-card' });
      c1.appendChild(L.h('div', { class: 'big', text: R0.ok ? '작전 성공' : '작전 실패', style: { color: R0.ok ? '#9be36b' : '#ee6a55' } }));
      c1.appendChild(L.h('p', { text: R0.ok ? '탈출한 대원 ' + R0.ext + '명 · 걸린 시간 ' + (L.fmt ? L.fmt.time(R0.t) : R0.t + '초') : (WHY[R0.why] || '') }));
      c1.appendChild(L.h('p', { text: pl.nm + ' 해방도 ' + R0.lb + '% → ' + R0.la + '%' + (R0.fr ? ' — 행성 해방!' : '') }));
      const bar = L.h('div', { class: 'sf-bar' }); const bb = L.h('b'); bb.style.width = R0.la + '%'; const ss = L.h('s'); ss.style.width = Math.min(R0.lb, R0.la) + '%'; bar.appendChild(bb); bar.appendChild(ss); c1.appendChild(bar);
      c1.appendChild(L.h('p', { text: '보상: 요청 점수 +' + R0.req + ' · 표본 +' + (R0.ok ? R0.smp : 0) + (R0.sides ? ' · 보조 목표 ' + R0.sides + '개' : '') }));
      left.appendChild(c1);
      const right = L.h('div', { class: 'sf-col' }); body.appendChild(right);
      const c2 = L.h('div', { class: 'sf-card' }); c2.appendChild(L.h('h3', { text: '대원 기록' }));
      const tb = L.h('table', { class: 'sf-tbl' }); tb.appendChild(L.h('tr', {}, L.h('th', { text: '대원' }), L.h('th', { text: '처치' }), L.h('th', { text: '쓰러짐' }), L.h('th', { text: '아군 사고' }), L.h('th', { text: '지원 요청' }), L.h('th', { text: '표본' })));
      for (let s = 0; s < st.np; s++) { const a = (R0.sk && R0.sk[s]) || []; tb.appendChild(L.h('tr', {}, L.h('td', { text: nm(s) }), L.h('td', { class: 'n', text: String(a[0] | 0) }), L.h('td', { class: 'n', text: String(a[1] | 0) }), L.h('td', { class: 'n', text: String(a[2] | 0) }), L.h('td', { class: 'n', text: String(a[3] | 0) }), L.h('td', { class: 'n', text: String(a[4] | 0) }))); }
      c2.appendChild(tb); right.appendChild(c2);
      const ft = L.h('div', { class: 'sf-ft' }); ov.appendChild(ft);
      const last = st.done >= st.ops || st.lib.every((v) => v >= 100);
      ft.appendChild(L.h('div', { style: { flex: '1 1 auto', color: '#9fb0c8', fontSize: '13px' }, text: last ? '마지막 작전이었어요.' : '다음 작전 ' + (st.done + 1) + ' / ' + st.ops + (host() ? ' — ' + Math.max(0, Math.ceil(endT)) + '초 뒤 자동으로 넘어가요' : ' — 방장이 진행해요') }));
      if (host()) ft.appendChild(L.h('button', { class: 'sf-btn pri', text: last ? '최종 결과 ▶' : '다음 작전 준비 ▶', 'data-key': 'Enter', onclick: () => { api.sfx('go'); endT = -1; api.setState(nextMission(st)); closeOv(); } }));
    }

    /* ----- 흐름 ----- */
    function startMission() {
      key = st.rid + '.' + st.mk;
      W = newWorld(st); aiMem = W.pl.map(() => ({})); acc = 0; lastFx = 0; lastQ = -1; resSent = 0;
      parts = []; rings = []; tracers = []; corpses = []; floats = []; beams = []; banner = null; ready = -1; codeBuf = ''; bigMap = 0; mapCv = null;
      Object.keys(remIn).forEach((k) => delete remIn[k]); Object.keys(remC).forEach((k) => delete remC[k]);
      const m = me(); const p = m >= 0 ? W.pl[m] : W.pl[0]; if (p) { cam.x = p.x; cam.y = p.y; }
      closeOv();
      buildMap();
    }
    let resSent = 0, hostLoadT = 0;
    function hostLoadFlow(rdt) {
      if (!host() || !st || st.ph !== 'load') return;
      hostLoadT -= rdt; if (hostLoadT > 0) return; hostLoadT = 0.25;
      let n = null;
      for (let s = 0; s < st.np; s++) {
        if (isAIseat(s) && !st.rd[s]) { n = n || U.clone(st); n.lo[s] = (n.lo[s] && validLo(n, n.lo[s])) || aiLoadout(n, s); n.rd[s] = 1; }
      }
      if (auto() && me() >= 0 && !st.rd[me()]) { autoRd += 0.25; if (autoRd > 1) { n = n || U.clone(st); n.lo[me()] = fixLo(LS.get('lo', null)); n.rd[me()] = 1; } }
      if (n) { api.setState(n); return; }
      if (st.rd.every((v) => v) && !L.pick.waiting(api.players, picked).length) { const q = U.clone(st); q.ph = 'play'; q.lo = q.lo.map((lo, s) => validLo(q, lo) || aiLoadout(q, s)); api.setState(q); }
    }
    function hostStep(rdt) {
      const stale = (s) => !localHuman(s) && !isAIseat(s) && !(remC[s] && performance.now() - (remC[s].lt || 0) < 3000);
      const hum = []; for (let s = 0; s < W.pl.length; s++) if (!isAIseat(s) && !stale(s)) hum.push(s);
      acc += rdt * SPD(); let n = 0;
      const lim = Math.ceil(10 * SPD());
      while (acc >= DT && n < lim) {
        acc -= DT; n++;
        const ins = [];
        for (let s = 0; s < W.pl.length; s++) {
          if (isAIseat(s) || stale(s)) ins[s] = aiThink(W, W.pl[s], aiMem[s] || (aiMem[s] = {}), P(s).ai ? lvOf(s) : 3, DT, hum);
          else if (localHuman(s)) ins[s] = takeLocal();
          else ins[s] = remIn[s] || {};
        }
        stepWorld(W, ins, DT);
        if (me() >= 0 && !auto()) clearEdges();
        for (const k in remIn) { const R = remIn[k]; R.rl = R.dv = R.ie = R.gr = R.ml = R.stim = R.tq = 0; R.th = null; R.tc = -1; }
        if (W.res) break;
      }
      if (acc > DT * lim) acc = 0;
      hostFx();
      if (W.res && !resSent) { resSent = 1; endT = 25; api.setState(missionOver(st, W.res)); }
    }
    function guestStep(rdt) {
      const m = auto() ? -1 : me(), k = 1 - Math.exp(-rdt * 14);
      W.t += rdt;
      W.pl.forEach((p, i) => {
        if (!fin(p.nx)) return;
        if (i === m && p.al && p.veh < 0 && !(p.drop > 0) && p.tm < 0 && !p.stun) {
          const sp = 4.3 * ARM[p.A].sp * (loc.spr && !loc.fire ? 1.5 : 1) * (loc.ads ? 0.6 : 1);
          moveC(W.M, p, loc.mx * sp * rdt, loc.my * sp * rdt, 0.36);
          const kk = 1 - Math.exp(-rdt * 5); p.x += (p.nx - p.x) * kk; p.y += (p.ny - p.y) * kk;
          if (loc.ax !== null) p.a = Math.atan2(loc.ay - p.y, loc.ax - p.x); p.ads = loc.ads;
          return;
        }
        p.x += (p.nx - p.x) * k; p.y += (p.ny - p.y) * k; if (fin(p.na)) p.a += wrapA(p.na - p.a) * k;
      });
      for (const e of W.en) { if (fin(e.nx)) { e.x += (e.nx - e.x) * k; e.y += (e.ny - e.y) * k; e.a += wrapA(e.na - e.a) * k; } }
      for (const b of W.pr) { if (fin(b.nx)) { b.x += (b.nx - b.x) * Math.min(1, k * 2); b.y += (b.ny - b.y) * Math.min(1, k * 2); } }
      for (const t of W.tu) { if (fin(t.na)) t.a += wrapA(t.na - t.a) * k; }
      for (const v of W.vh) { if (fin(v.nx)) { v.x += (v.nx - v.x) * k; v.y += (v.ny - v.y) * k; } }
      for (const c of W.cv) { if (fin(c.nx)) { c.x += (c.nx - c.x) * k; c.y += (c.ny - c.y) * k; } }
      if (W.cr && fin(W.cr.nx)) { W.cr.x += (W.cr.nx - W.cr.x) * k; W.cr.y += (W.cr.ny - W.cr.y) * k; }
      if (myP() && loc.ax !== null) { /* aim already */ }
    }

    /* ----- 그리기: 지형 ----- */
    const TP = 24;
    function buildMap() {
      if (!W) return;
      const M = W.M, pl = PLANETS[st.mi.pi], R = rng(M.seed ^ 77);
      mapCv = document.createElement('canvas'); mapCv.width = mapCv.height = MS * TP;
      const g = mapCv.getContext('2d');
      g.fillStyle = pl.g[0]; g.fillRect(0, 0, MS * TP, MS * TP);
      for (let y = 0; y < MS; y++) for (let x = 0; x < MS; x++) { if (R() < 0.5) { g.fillStyle = pl.g[1]; g.globalAlpha = 0.25 + R() * 0.4; g.fillRect(x * TP, y * TP, TP, TP); } }
      g.globalAlpha = 1;
      for (let i = 0; i < 2600; i++) { g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,.08)' : 'rgba(255,255,255,.05)'; const s = 1 + R() * 3; g.fillRect(R() * MS * TP, R() * MS * TP, s, s); }
      for (let y = 0; y < MS; y++) for (let x = 0; x < MS; x++) {
        const v = M.g[y * MS + x];
        if (v === 2) { for (let k = 0; k < 3; k++) { g.fillStyle = k ? pl.bu : 'rgba(0,0,0,.25)'; g.beginPath(); g.arc(x * TP + TP * (0.2 + R() * 0.6) + (k ? 0 : 2), y * TP + TP * (0.2 + R() * 0.6) + (k ? 0 : 3), TP * (0.3 + R() * 0.25), 0, TAU); g.fill(); } }
      }
      // 바위: 그림자 → 몸 → 윗면 빛
      for (const pass of [0, 1, 2]) for (let y = 0; y < MS; y++) for (let x = 0; x < MS; x++) {
        if (M.g[y * MS + x] !== 1) continue;
        const cx = x * TP + TP / 2, cy = y * TP + TP / 2;
        if (pass === 0) { g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(cx + 5, cy + 7, TP * 0.78, 0, TAU); g.fill(); }
        else if (pass === 1) { g.fillStyle = pl.rk; g.beginPath(); g.arc(cx, cy, TP * 0.74, 0, TAU); g.fill(); }
        else { g.fillStyle = 'rgba(255,255,255,.07)'; g.beginPath(); g.arc(cx - 4, cy - 5, TP * 0.42, 0, TAU); g.fill(); }
      }
      g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 6; g.strokeRect(0, 0, MS * TP, MS * TP);
    }

    /* ----- 그리기: 적 ----- */
    function drawEnemy(g, e, S, t) {
      const T = EN[e.t], [x, y] = w2s(e.x, e.y), r = T.r * S;
      if (x < -r * 3 || y < -r * 3 || x > cv.w + r * 3 || y > cv.h + r * 3) return;
      const fac = T.f < 0 ? W.fac : T.f;
      g.save(); g.translate(x, y);
      const em = e.spn ? 0.5 : 1;
      if (!T.fly) { g.fillStyle = 'rgba(0,0,0,.3)'; g.beginPath(); g.ellipse(r * 0.15, r * 0.3, r * 1.05, r * 0.8, 0, 0, TAU); g.fill(); }
      if (T.tier === 3) {
        if (e.t === EI.tower) { g.fillStyle = '#3a3d44'; g.fillRect(-r * 0.7, -r * 0.7, r * 1.4, r * 1.4); g.strokeStyle = '#9aa0aa'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, -r * 2.2); g.stroke(); g.fillStyle = (t * 2 | 0) % 2 ? '#ff3b2f' : '#5a1510'; g.beginPath(); g.arc(0, -r * 2.2, r * 0.25, 0, TAU); g.fill(); }
        else if (fac === 0) { const gr = g.createRadialGradient(0, 0, r * 0.2, 0, 0, r * 1.2); gr.addColorStop(0, '#6a4a22'); gr.addColorStop(1, '#3a2510'); g.fillStyle = gr; g.beginPath(); g.arc(0, 0, r * 1.15, 0, TAU); g.fill(); g.fillStyle = '#120a04'; for (let k = 0; k < 4; k++) { g.beginPath(); g.arc(Math.cos(k * 1.7) * r * 0.5, Math.sin(k * 1.7) * r * 0.5, r * 0.22, 0, TAU); g.fill(); } g.fillStyle = 'rgba(210,160,60,' + (0.3 + 0.2 * Math.sin(t * 3)) + ')'; g.beginPath(); g.arc(0, 0, r * 0.3, 0, TAU); g.fill(); }
        else if (fac === 1) { g.fillStyle = '#2b2e34'; g.fillRect(-r, -r, r * 2, r * 2); g.fillStyle = '#4a4e57'; g.fillRect(-r * 0.8, -r * 0.8, r * 1.6, r * 0.5); g.fillStyle = (t * 3 | 0) % 2 ? '#ff3b2f' : '#7a1a12'; g.fillRect(-r * 0.2, r * 0.2, r * 0.4, r * 0.4); g.fillStyle = '#1a1c20'; g.fillRect(r * 0.4, -r * 1.4, r * 0.4, r * 0.7); if (Math.random() < 0.1) smoke(e.x + 0.45, e.y - 1.1, 1, 0.5); }
        else { g.rotate(t * 0.7); for (let k = 0; k < 3; k++) { g.strokeStyle = 'rgba(180,120,255,' + (0.7 - k * 0.2) + ')'; g.lineWidth = 3; g.beginPath(); g.ellipse(0, 0, r * (1.1 - k * 0.3), r * (0.6 - k * 0.15), k, 0, TAU); g.stroke(); } g.fillStyle = '#12051f'; g.beginPath(); g.ellipse(0, 0, r * 0.5, r * 0.3, 0, 0, TAU); g.fill(); }
        g.restore();
        if (e.hp < e.mhp || e.main) hpBar(g, x, y - r * 1.6, r * 2.2, e.hpP !== undefined ? e.hpP / 100 : e.hp / e.mhp, '#ffb347');
        return;
      }
      if (T.fly) { g.fillStyle = 'rgba(0,0,0,.22)'; g.beginPath(); g.ellipse(r * 0.6, r * 1.6, r * 0.8, r * 0.4, 0, 0, TAU); g.fill(); g.translate(0, -r * 0.4 + Math.sin(t * 3 + e.id) * r * 0.15); }
      g.rotate(e.a); g.scale(em, em);
      if (e.ch === 1) { g.strokeStyle = 'rgba(255,80,50,' + (0.5 + 0.5 * Math.sin(t * 30)) + ')'; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, r * 1.3, 0, TAU); g.stroke(); }
      const leg = Math.sin(t * 14 + e.id) * r * 0.18;
      if (fac === 0) {
        const base = e.t === EI.b_spit ? '#9a7a30' : e.t === EI.b_tit ? '#7a5a2a' : e.t === EI.b_chg ? '#8a5a26' : '#b8742e';
        g.strokeStyle = '#3a2410'; g.lineWidth = Math.max(1.5, r * 0.12);
        for (let k = -1; k <= 1; k++) { g.beginPath(); g.moveTo(k * r * 0.4, -r * 0.5); g.lineTo(k * r * 0.5 + (k ? leg : -leg), -r * 1.1); g.moveTo(k * r * 0.4, r * 0.5); g.lineTo(k * r * 0.5 - (k ? leg : -leg), r * 1.1); g.stroke(); }
        g.fillStyle = base; g.beginPath(); g.ellipse(-r * 0.15, 0, r * 0.95, r * 0.7, 0, 0, TAU); g.fill();
        if (e.t === EI.b_spit || e.t === EI.b_tit) { g.fillStyle = 'rgba(150,230,80,' + (0.55 + 0.2 * Math.sin(t * 4)) + ')'; g.beginPath(); g.arc(-r * 0.55, 0, r * 0.5, 0, TAU); g.fill(); }
        if (e.t === EI.b_chg) { g.fillStyle = '#5a3412'; g.beginPath(); g.arc(r * 0.2, 0, r * 0.85, -1.3, 1.3); g.fill(); g.fillStyle = '#d0503a'; g.beginPath(); g.arc(-r * 0.75, 0, r * 0.28, 0, TAU); g.fill(); }
        g.fillStyle = '#4a2a10'; g.beginPath(); g.arc(r * 0.8, 0, r * 0.38, 0, TAU); g.fill();
        if (e.t === EI.b_hunt) { g.strokeStyle = '#e0c080'; g.lineWidth = 2; g.beginPath(); g.moveTo(r, -r * 0.2); g.lineTo(r * 1.5, -r * 0.5); g.moveTo(r, r * 0.2); g.lineTo(r * 1.5, r * 0.5); g.stroke(); }
        g.fillStyle = '#ffdf80'; g.fillRect(r * 0.95, -r * 0.18, r * 0.12, r * 0.12); g.fillRect(r * 0.95, r * 0.06, r * 0.12, r * 0.12);
      } else if (fac === 1) {
        if (e.t === EI.m_tank) {
          g.fillStyle = '#1f2125'; g.fillRect(-r * 1.0, -r * 0.95, r * 2.0, r * 0.35); g.fillRect(-r * 1.0, r * 0.6, r * 2.0, r * 0.35);
          g.fillStyle = '#3c4047'; g.fillRect(-r * 0.9, -r * 0.65, r * 1.8, r * 1.3);
          g.fillStyle = 'rgba(255,120,40,' + (0.6 + 0.3 * Math.sin(t * 6)) + ')'; g.fillRect(-r * 0.95, -r * 0.35, r * 0.18, r * 0.7);
          g.fillStyle = '#4c5159'; g.beginPath(); g.arc(r * 0.1, 0, r * 0.5, 0, TAU); g.fill(); g.fillStyle = '#2a2d32'; g.fillRect(r * 0.3, -r * 0.1, r * 1.1, r * 0.2);
          g.fillStyle = '#ff3b2f'; g.fillRect(r * 0.35, -r * 0.35, r * 0.12, r * 0.12);
        } else {
          g.fillStyle = '#2a2c31'; g.fillRect(-r * 0.5, -r * 0.75 + leg * 0.5, r * 0.5, r * 0.3); g.fillRect(-r * 0.5, r * 0.45 - leg * 0.5, r * 0.5, r * 0.3);
          g.fillStyle = e.t === EI.m_shd ? '#4d5158' : '#3c3f45'; rr(g, -r * 0.7, -r * 0.6, r * 1.3, r * 1.2, r * 0.2); g.fill();
          g.fillStyle = '#ff3b2f'; g.beginPath(); g.arc(r * 0.35, 0, r * 0.16, 0, TAU); g.fill();
          g.fillStyle = '#1c1d20'; g.fillRect(r * 0.3, r * 0.3, r * 0.9, r * 0.16);
          if (e.t === EI.m_rkt) { g.fillStyle = '#5a5e66'; g.fillRect(-r * 0.4, -r * 0.95, r * 1.1, r * 0.3); }
          if (e.t === EI.m_shd) { g.fillStyle = '#8a9099'; g.fillRect(r * 0.65, -r * 0.85, r * 0.22, r * 1.7); }
        }
      } else {
        if (e.t === EI.v_eye) { g.fillStyle = '#2a1a3d'; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill(); g.fillStyle = '#e9e0ff'; g.beginPath(); g.arc(r * 0.25, 0, r * 0.55, 0, TAU); g.fill(); g.fillStyle = '#8a3cff'; g.beginPath(); g.arc(r * 0.45, 0, r * 0.28, 0, TAU); g.fill(); }
        else if (e.t === EI.v_col) { g.fillStyle = '#251838'; g.beginPath(); for (let k = 0; k < 6; k++) { const a = k * TAU / 6 + t * 0.2; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); } g.closePath(); g.fill(); g.fillStyle = 'rgba(190,140,255,' + (0.6 + 0.3 * Math.sin(t * 5)) + ')'; g.beginPath(); g.arc(0, 0, r * 0.4, 0, TAU); g.fill(); g.strokeStyle = '#b68cff'; g.lineWidth = 3; g.beginPath(); g.moveTo(r * 0.4, 0); g.lineTo(r * 1.2, 0); g.stroke(); }
        else if (e.t === EI.v_lan) { g.fillStyle = '#3a2458'; g.beginPath(); g.moveTo(r * 0.9, 0); g.lineTo(0, -r * 0.8); g.lineTo(-r * 0.9, 0); g.lineTo(0, r * 0.8); g.closePath(); g.fill(); g.strokeStyle = '#d8b8ff'; g.lineWidth = 2; g.beginPath(); g.moveTo(-r * 0.3, r * 0.5); g.lineTo(r * 1.4, r * 0.5); g.stroke(); g.fillStyle = '#c49bff'; g.beginPath(); g.arc(r * 0.2, 0, r * 0.18, 0, TAU); g.fill(); }
        else { g.globalAlpha = 0.85 + 0.15 * Math.sin(t * 9 + e.id); g.fillStyle = '#1d1230'; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill(); g.strokeStyle = '#8a5cd6'; g.lineWidth = 2; g.beginPath(); g.arc(0, 0, r * 1.05, 0, TAU); g.stroke(); g.strokeStyle = '#e0d0ff'; g.beginPath(); g.moveTo(r * 0.3, -r * 0.4); g.lineTo(r * 1.3, -r * 0.6); g.stroke(); g.fillStyle = '#c49bff'; g.fillRect(r * 0.3, -r * 0.2, r * 0.2, r * 0.12); g.globalAlpha = 1; }
      }
      g.restore();
      if (e.stun) { g.fillStyle = '#9fdcff'; g.font = '700 ' + Math.round(S * 0.4) + 'px ' + BODY; g.textAlign = 'center'; g.fillText('✦', x + Math.cos(t * 6) * r, y - r - 4); }
      if (e.burn && Math.random() < 0.3) addParts(e.x + (Math.random() - 0.5) * T.r, e.y + (Math.random() - 0.5) * T.r, 1, '#ff8a3a', 1, 0.4, 0.1, 1.5);
      if (e.al) { g.fillStyle = '#ff3b2f'; g.font = '700 ' + Math.round(S * 0.7) + 'px ' + DISP; g.textAlign = 'center'; g.fillText('!', x, y - r - S * 0.25); g.strokeStyle = 'rgba(255,60,40,.5)'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, r + S * 0.3 + (t * 30) % (S * 0.6), 0, TAU); g.stroke(); }
      if (T.tier >= 1) { const f = e.hpP !== undefined ? e.hpP / 100 : e.hp / e.mhp; if (f < 0.99) hpBar(g, x, y - r - 8, Math.max(26, r * 2), f, T.tier >= 2 ? '#ff6a4a' : '#e0a040'); }
    }
    function hpBar(g, x, y, w, f, c) { g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(x - w / 2 - 1, y - 1, w + 2, 6); g.fillStyle = c; g.fillRect(x - w / 2, y, w * clamp(f, 0, 1), 4); }
    function drawCorpse(g, c, S) {
      const T = EN[c.t]; if (!T) return; const [x, y] = w2s(c.x, c.y), r = T.r * S;
      if (x < -60 || y < -60 || x > cv.w + 60 || y > cv.h + 60) return;
      g.save(); g.translate(x, y); g.rotate(c.a); g.globalAlpha = clamp(c.life / 3, 0, 0.8);
      const f = T.f < 0 ? W.fac : T.f;
      g.fillStyle = f === 0 ? '#5a3a1a' : f === 1 ? '#26282c' : '#2a1d3a';
      g.beginPath(); g.ellipse(0, 0, r * 0.95, r * 0.6, 0, 0, TAU); g.fill();
      g.strokeStyle = 'rgba(0,0,0,.5)'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(-r * 0.6, -r * 0.6); g.lineTo(r * 0.4, r * 0.7); g.stroke();
      g.restore(); g.globalAlpha = 1;
    }
    /* ----- 그리기: 대원 · 설비 ----- */
    const ARMC = { 경장: '#9fdcff', 중장: '#d8d8d8', 중장갑: '#ffcf6a' };
    function drawPlayer(g, p, s, S, t) {
      if (!p.al || p.boarded) return;
      const [x, y] = w2s(p.x, p.y), r = 0.38 * S;
      if (p.drop > 0) { const k = clamp(p.drop / 2.2, 0, 1); g.fillStyle = 'rgba(0,0,0,' + (0.5 - k * 0.3) + ')'; g.beginPath(); g.arc(x, y, r * (1.6 - k), 0, TAU); g.fill(); const py = y - k * cv.h * 0.8; g.strokeStyle = 'rgba(200,230,255,.6)'; g.lineWidth = r * 0.6; g.beginPath(); g.moveTo(x, py - S * 3); g.lineTo(x, py); g.stroke(); g.fillStyle = '#c9d4e2'; rr(g, x - r * 0.8, py - r * 1.6, r * 1.6, r * 2.2, r * 0.5); g.fill(); g.fillStyle = COL(s); g.fillRect(x - r * 0.5, py - r * 0.6, r, r * 0.3); return; }
      if (p.veh >= 0) return;
      g.save(); g.translate(x, y);
      g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(r * 0.2, r * 0.35, r * 1.05, r * 0.8, 0, 0, TAU); g.fill();
      if (p.ads) { g.strokeStyle = 'rgba(255,80,60,.35)'; g.lineWidth = 1; g.beginPath(); g.moveTo(Math.cos(p.a) * r, Math.sin(p.a) * r); g.lineTo(Math.cos(p.a) * S * 9, Math.sin(p.a) * S * 9); g.stroke(); }
      g.rotate(p.a);
      if (p.dvF || p.dv > 0) g.scale(1.3, 0.75);
      const wp = p.veh >= 0 ? null : wpOf(p), len = wp ? (wp.id === 'at' || wp.id === 'rail' ? 1.25 : wp.id === 'mg' || wp.id === 'mk' ? 1.15 : wp.id === 'pi' || wp.id === 'rv' || wp.id === 'mp' ? 0.7 : 0.95) : 0.9;
      g.fillStyle = '#20242b'; g.fillRect(r * 0.2, r * 0.15, r * len * 1.3, r * 0.32);
      if (p.bp) { g.fillStyle = '#4fb3e8'; g.fillRect(-r * 1.0, -r * 0.45, r * 0.45, r * 0.9); }
      g.fillStyle = ARMC[ARM[p.A].w] || '#ccc'; g.beginPath(); g.arc(0, 0, r, 0, TAU); g.fill();
      g.fillStyle = COL(s); g.beginPath(); g.arc(0, 0, r * 0.78, 0, TAU); g.fill();
      g.fillStyle = '#10151c'; g.beginPath(); g.ellipse(r * 0.38, 0, r * 0.26, r * 0.42, 0, 0, TAU); g.fill();
      g.fillStyle = 'rgba(160,220,255,.6)'; g.fillRect(r * 0.42, -r * 0.25, r * 0.1, r * 0.25);
      if (p._mf > 0) { g.fillStyle = 'rgba(255,230,140,' + clamp(p._mf / 0.06, 0, 1) + ')'; g.beginPath(); g.moveTo(r * (0.2 + len * 1.3), r * 0.05); g.lineTo(r * (0.9 + len * 1.3), r * 0.31); g.lineTo(r * (0.2 + len * 1.3), r * 0.57); g.fill(); }
      if (p.melT > 0) { g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, r * 2.2, -0.8, 0.8); g.stroke(); }
      g.restore();
      if (p.sh > 0) { g.strokeStyle = 'rgba(120,200,255,' + (0.3 + 0.3 * (p.sh / 200)) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, r * 1.45, 0, TAU); g.stroke(); }
      if (p.hit > 0) { g.strokeStyle = 'rgba(255,60,40,.7)'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, r * 1.2, 0, TAU); g.stroke(); }
      if (p.rg) { g.strokeStyle = 'rgba(120,240,190,.6)'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, r * 1.3 + Math.sin(t * 8) * 2, 0, TAU); g.stroke(); }
      if (p.stun) { g.fillStyle = '#ffd257'; g.font = '700 ' + Math.round(S * 0.35) + 'px ' + BODY; g.textAlign = 'center'; g.fillText('✦', x + Math.cos(t * 7) * r, y - r - 4); }
      if (s !== me() || auto()) {
        g.font = '700 ' + Math.round(clamp(S * 0.34, 11, 16)) + 'px ' + BODY; g.textAlign = 'center'; g.textBaseline = 'bottom';
        const label = nm(s); g.fillStyle = 'rgba(0,0,0,.55)'; const tw = g.measureText(label).width; g.fillRect(x - tw / 2 - 4, y - r - S * 0.62, tw + 8, S * 0.42);
        g.fillStyle = COL(s); g.fillText(label, x, y - r - S * 0.24); g.textBaseline = 'alphabetic';
        hpBar(g, x, y - r - S * 0.16, S * 0.9, p.hp / p.mhp, '#7ad46a');
      }
    }
    function drawMech(g, v, S, t) {
      const [x, y] = w2s(v.x, v.y), r = 0.85 * S;
      g.save(); g.translate(x, y);
      g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(r * 0.2, r * 0.4, r * 1.2, r * 0.9, 0, 0, TAU); g.fill();
      g.rotate(v.a);
      const st2 = Math.sin(t * 6) * r * 0.2 * (v.dr >= 0 ? 1 : 0);
      g.fillStyle = '#2b3038'; g.fillRect(-r * 0.4 + st2, -r * 0.95, r * 0.8, r * 0.35); g.fillRect(-r * 0.4 - st2, r * 0.6, r * 0.8, r * 0.35);
      g.fillStyle = '#5d6672'; rr(g, -r * 0.7, -r * 0.65, r * 1.4, r * 1.3, r * 0.3); g.fill();
      g.fillStyle = '#ffd257'; g.fillRect(-r * 0.5, -r * 0.15, r * 0.3, r * 0.3);
      g.fillStyle = '#1e2228'; g.fillRect(r * 0.3, r * 0.25, r * 1.1, r * 0.22); g.fillRect(r * 0.2, -r * 0.6, r * 0.7, r * 0.3);
      if (v.dr >= 0) { g.fillStyle = COL(v.dr); g.beginPath(); g.arc(0, 0, r * 0.28, 0, TAU); g.fill(); }
      g.restore();
      hpBar(g, x, y - r - 10, r * 2, v.hp / v.mhp, '#9fdcff');
      if (v.dr < 0) { g.fillStyle = '#ffd257'; g.font = '700 12px ' + BODY; g.textAlign = 'center'; g.fillText('빈 보행기', x, y + r + 16); }
    }
    function drawTurret(g, tu, S, t) {
      const [x, y] = w2s(tu.x, tu.y), r = 0.45 * S;
      if (tu.dt > 0) { g.strokeStyle = 'rgba(200,230,255,.5)'; g.lineWidth = 3; g.beginPath(); g.moveTo(x, y - S * 4); g.lineTo(x, y); g.stroke(); }
      g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.arc(x + 3, y + 4, r * 1.1, 0, TAU); g.fill();
      g.fillStyle = '#3d4652'; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill();
      g.save(); g.translate(x, y); g.rotate(tu.a); g.fillStyle = tu.k ? '#6a7380' : '#525b67'; g.fillRect(-r * 0.4, -r * 0.45, r * 0.9, r * 0.9); g.fillStyle = '#1b1f25'; if (tu.k) { g.fillRect(r * 0.2, -r * 0.4, r * 1.1, r * 0.3); g.fillRect(r * 0.2, r * 0.1, r * 1.1, r * 0.3); } else g.fillRect(r * 0.3, -r * 0.12, r * 1.4, r * 0.24); g.restore();
      g.fillStyle = (t * 2 | 0) % 2 ? '#5fc777' : '#2f6a3c'; g.beginPath(); g.arc(x - r * 0.5, y - r * 0.5, 2.5, 0, TAU); g.fill();
      hpBar(g, x, y - r - 9, r * 2.2, (tu.mhp === 100 ? tu.hp / 100 : tu.hp / tu.mhp), '#7ad46a');
      g.fillStyle = '#cfe3ff'; g.font = '600 10px ' + MONO; g.textAlign = 'center'; g.fillText(String(tu.am), x, y + r + 12);
    }
    const BEAC_C = { 궤도: '#ff4a3a', 항공: '#ff4a3a', '지원 화기': '#4fb3e8', 방어: '#7ad46a', 탑승물: '#ffd257', 기본: '#4fb3e8' };
    function drawBeacon(g, b, S, t) {
      const S0 = STR[b.si]; if (!S0) return; const [x, y] = w2s(b.x, b.y), c = BEAC_C[S0.cat] || '#fff';
      const gr = g.createLinearGradient(x, y - S * 6, x, y); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, c);
      g.globalAlpha = 0.55 + 0.25 * Math.sin(t * 10); g.fillStyle = gr; g.fillRect(x - 3, y - S * 6, 6, S * 6); g.globalAlpha = 1;
      g.fillStyle = c; g.beginPath(); g.arc(x, y, 4, 0, TAU); g.fill();
      const R = dangerR(b.si);
      if (R > 1) { g.strokeStyle = c; g.globalAlpha = 0.35; g.setLineDash([6, 6]); g.lineWidth = 2; g.beginPath(); g.arc(x, y, R * S, 0, TAU); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; }
      else if (R < 0) { g.strokeStyle = c; g.globalAlpha = 0.35; g.setLineDash([6, 6]); g.lineWidth = 2; g.beginPath(); g.moveTo(x - Math.cos(b.a) * S, y - Math.sin(b.a) * S); g.lineTo(x + Math.cos(b.a) * S * 12, y + Math.sin(b.a) * S * 12); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; }
      g.fillStyle = '#fff'; g.font = '700 12px ' + MONO; g.textAlign = 'center'; g.fillText(S0.ic + ' ' + Math.max(0, b.t).toFixed(1), x, y - 10);
    }
    function drawProj(g, b, S, t) {
      const [x, y] = w2s(b.x, b.y);
      if (x < -50 || y < -50 || x > cv.w + 50 || y > cv.h + 50) return;
      const sp = hyp(b.vx, b.vy) || 1, ux = b.vx / sp, uy = b.vy / sp;
      const line = (c, len, w) => { g.strokeStyle = c; g.lineWidth = w; g.beginPath(); g.moveTo(x - ux * len, y - uy * len); g.lineTo(x, y); g.stroke(); };
      if (b.k === 0) line('#ff5a3a', S * 0.7, 2);
      else if (b.k === 1) { g.fillStyle = '#9be36b'; g.beginPath(); g.arc(x, y, S * 0.18, 0, TAU); g.fill(); g.fillStyle = 'rgba(155,227,107,.3)'; g.beginPath(); g.arc(x - ux * S * 0.3, y - uy * S * 0.3, S * 0.14, 0, TAU); g.fill(); }
      else if (b.k === 2 || b.k === 5) { line(b.k === 2 ? '#ff8a5a' : '#f0f4ff', S * 0.5, 3); g.fillStyle = '#fff2a0'; g.beginPath(); g.arc(x - ux * S * 0.55, y - uy * S * 0.55, 3, 0, TAU); g.fill(); if (Math.random() < 0.5) smoke(b.x - ux * 0.5, b.y - uy * 0.5, 1, 0.3); }
      else if (b.k === 3) { g.fillStyle = '#ffb04a'; g.beginPath(); g.arc(x, y, S * 0.16, 0, TAU); g.fill(); line('rgba(255,176,74,.5)', S * 0.6, 3); }
      else if (b.k === 4) { g.fillStyle = '#6fe8ff'; g.beginPath(); g.arc(x, y, S * 0.15, 0, TAU); g.fill(); line('rgba(111,232,255,.5)', S * 0.6, 3); }
      else if (b.k === 8) line('#d8b8ff', S * 0.8, 3);
      else if (b.k === 9) { g.fillStyle = '#ffe070'; g.beginPath(); g.arc(x, y, S * 0.13, 0, TAU); g.fill(); line('rgba(255,224,112,.5)', S * 0.5, 3); }
      else if (b.k === 10) { const gr = g.createRadialGradient(x, y, 0, x, y, S * 0.45); gr.addColorStop(0, 'rgba(255,230,140,.9)'); gr.addColorStop(1, 'rgba(255,100,20,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, S * 0.45, 0, TAU); g.fill(); }
      else if (b.k === 6) { g.fillStyle = '#2a2e34'; g.beginPath(); g.arc(x, y, S * 0.13, 0, TAU); g.fill(); g.fillStyle = (t * 8 | 0) % 2 ? '#ff4a3a' : '#5a1510'; g.beginPath(); g.arc(x, y, S * 0.05, 0, TAU); g.fill(); }
      else if (b.k === 7) { g.fillStyle = '#ff4a3a'; g.beginPath(); g.arc(x, y, S * 0.12, 0, TAU); g.fill(); line('rgba(255,74,58,.5)', S * 0.5, 2); }
    }
    function drawItem(g, it, S, t) {
      const [x, y] = w2s(it.x, it.y); if (x < -30 || y < -30 || x > cv.w + 30 || y > cv.h + 30) return;
      const r = S * 0.28, bob = Math.sin(t * 3 + it.id) * 2;
      if (it.k === 0 || it.k === 5) { g.fillStyle = 'rgba(127,240,200,.25)'; g.beginPath(); g.arc(x, y, r * 1.8, 0, TAU); g.fill(); g.fillStyle = it.k === 5 ? '#3fae8a' : '#7ff0c8'; g.beginPath(); for (let k = 0; k < 6; k++) { const a = k * TAU / 6; g.lineTo(x + Math.cos(a) * r, y + bob + Math.sin(a) * r); } g.closePath(); g.fill(); if ((it.n | 0) > 1) { g.fillStyle = '#fff'; g.font = '700 10px ' + MONO; g.textAlign = 'center'; g.fillText('×' + it.n, x, y - r - 4); } }
      else if (it.k === 2) { g.fillStyle = '#2b5a8a'; g.fillRect(x - r, y - r * 0.8 + bob, r * 2, r * 1.6); g.fillStyle = '#9fdcff'; g.fillRect(x - r * 0.15, y - r * 0.8 + bob, r * 0.3, r * 1.6); }
      else if (it.k === 3) { g.fillStyle = '#c99a2a'; rr(g, x - r * 0.6, y - r * 1.2 + bob, r * 1.2, r * 2.4, r * 0.4); g.fill(); g.fillStyle = '#000'; g.font = '700 ' + Math.round(r * 1.2) + 'px ' + BODY; g.textAlign = 'center'; g.fillText(SUPW[it.w] ? SUPW[it.w].ic : '?', x, y + r * 0.45 + bob); }
      else if (it.k === 4) { g.fillStyle = '#4fb3e8'; g.beginPath(); g.arc(x, y + bob, r, 0, TAU); g.fill(); g.strokeStyle = '#cfefff'; g.lineWidth = 2; g.stroke(); }
    }
    function drawObjectives(g, S, t) {
      const mark = (x, y, txt, c) => { const [sx, sy] = w2s(x, y); g.fillStyle = c || '#ffd257'; g.font = '700 ' + Math.round(clamp(S * 0.38, 11, 16)) + 'px ' + BODY; g.textAlign = 'center'; g.fillText(txt, sx, sy - S * 1.4); };
      const ring = (x, y, R, f, c) => { const [sx, sy] = w2s(x, y); g.strokeStyle = c; g.globalAlpha = 0.5; g.lineWidth = 2; g.setLineDash([8, 8]); g.beginPath(); g.arc(sx, sy, R * S, 0, TAU); g.stroke(); g.setLineDash([]); g.globalAlpha = 1; if (f > 0) { g.lineWidth = 5; g.beginPath(); g.arc(sx, sy, R * S, -Math.PI / 2, -Math.PI / 2 + TAU * f); g.stroke(); } };
      for (const o of W.ob) {
        const [x, y] = w2s(o.x, o.y), r = S * 0.7;
        if (o.k === 'term') { g.fillStyle = '#3d4652'; g.fillRect(x - r, y - r * 0.7, r * 2, r * 1.4); g.fillStyle = o.s === 2 ? '#7ad46a' : (t * 2 | 0) % 2 ? '#4fb3e8' : '#2b5a8a'; g.fillRect(x - r * 0.7, y - r * 0.45, r * 1.4, r * 0.7); if (o.s === 1) ring(o.x, o.y, 6.5, o.pr, '#4fb3e8'); mark(o.x, o.y, o.s === 0 ? '📡 단말기 [E]' : o.s === 1 ? '송신 ' + Math.round(o.pr * 100) + '%' : '송신 완료'); }
        else if (o.k === 'zone') { ring(o.x, o.y, 7, o.pr, o.s === 2 ? '#7ad46a' : '#ffd257'); g.fillStyle = '#4a4436'; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); g.fillStyle = '#ffd257'; g.fillRect(x - 2, y - r * 1.6, 4, r * 1.6); mark(o.x, o.y, o.s === 0 ? '🚩 거점 [E]' : o.s === 1 ? '사수 ' + Math.round(o.pr * 100) + '%' : '사수 완료'); }
        else if (o.k === 'gen') { g.fillStyle = '#4b4f3a'; g.fillRect(x - r, y - r, r * 2, r * 2); g.fillStyle = o.s === 2 ? '#ffd257' : '#3a3a30'; g.beginPath(); g.arc(x, y, r * 0.5, 0, TAU); g.fill(); if (o.s === 2 && Math.random() < 0.1) addParts(o.x, o.y, 1, '#ffd257', 1, 0.3, 0.05); mark(o.x, o.y, o.s === 2 ? '⚡ 가동 중' : '⚡ 발전기 [E]'); }
        else if (o.k === 'silo') { g.fillStyle = '#3a3e46'; g.beginPath(); g.arc(x, y, r * 1.6, 0, TAU); g.fill(); g.strokeStyle = '#ffd257'; g.lineWidth = 3; g.beginPath(); g.arc(x, y, r * 1.2, 0, TAU); g.stroke(); g.fillStyle = '#d8dde6'; g.beginPath(); g.arc(x, y, r * 0.5, 0, TAU); g.fill(); if (o.s === 1) ring(o.x, o.y, 4, o.pr, '#ff8a3a'); mark(o.x, o.y, o.s === 0 ? '🚀 발사대 [E]' : o.s === 1 ? '발사까지 ' + Math.ceil((1 - o.pr) * 35) + '초' : '발사 완료'); }
        else if (o.k === 'shel') { g.fillStyle = '#4a4f57'; g.fillRect(x - r * 1.4, y - r, r * 2.8, r * 2); g.fillStyle = o.s ? '#1a1d22' : '#ffd257'; g.fillRect(x - r * 0.4, y + r * 0.2, r * 0.8, r * 0.8); mark(o.x, o.y, o.s === 0 ? '🏠 대피소 [E]' : '구조 ' + (o.sv | 0) + '/6 · 희생 ' + (o.dd | 0)); }
        else if (o.k === 'pad') { g.strokeStyle = '#9fdcff'; g.lineWidth = 3; g.beginPath(); g.arc(x, y, S * 2, 0, TAU); g.stroke(); g.fillStyle = '#9fdcff'; g.font = '700 ' + Math.round(S) + 'px ' + DISP; g.textAlign = 'center'; g.fillText('H', x, y + S * 0.35); mark(o.x, o.y, '착륙장', '#9fdcff'); }
        else if (o.k === 'dest') { g.fillStyle = '#ffd257'; g.fillRect(x - 2, y - S * 1.5, 4, S * 1.5); g.beginPath(); g.moveTo(x + 2, y - S * 1.5); g.lineTo(x + S, y - S * 1.2); g.lineTo(x + 2, y - S * 0.9); g.fill(); mark(o.x, o.y, '목적지'); }
      }
      for (const o of W.sd) {
        if (o.k === 'tower') continue; const [x, y] = w2s(o.x, o.y), r = S * 0.6;
        if (o.k === 'cache') { g.fillStyle = o.s ? '#3a3a3a' : '#6a5a2a'; g.fillRect(x - r, y - r * 0.7, r * 2, r * 1.4); g.strokeStyle = '#ffd257'; g.lineWidth = 2; g.strokeRect(x - r, y - r * 0.7, r * 2, r * 1.4); mark(o.x, o.y, o.s ? '열림' : '📦 저장고 [E]', '#cfd8e8'); }
        else { g.fillStyle = '#3d4652'; g.fillRect(x - r * 0.5, y - r * 0.5, r, r); g.strokeStyle = o.s ? '#7ad46a' : '#9fdcff'; g.lineWidth = 2; g.beginPath(); g.moveTo(x, y); g.lineTo(x, y - r * 2); g.stroke(); mark(o.x, o.y, o.s ? '신호기 가동' : '📶 신호기 [E]', '#cfd8e8'); }
      }
      if (W.cr) { const c = W.cr, [x, y] = w2s(c.x, c.y), r = S * 0.9; g.save(); g.translate(x, y); g.rotate(c.a); g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(-r + 4, -r * 0.6 + 5, r * 2, r * 1.2); g.fillStyle = '#5a6a4a'; g.fillRect(-r, -r * 0.6, r * 2, r * 1.2); g.fillStyle = '#2a2e24'; g.fillRect(-r, -r * 0.75, r * 2, r * 0.18); g.fillRect(-r, r * 0.57, r * 2, r * 0.18); g.fillStyle = '#ffd257'; g.fillRect(r * 0.5, -r * 0.3, r * 0.35, r * 0.6); g.restore(); hpBar(g, x, y - r - 10, r * 2.4, c.hp / c.mhp, '#ffd257'); g.fillStyle = c.mv ? '#7ad46a' : '#ffd257'; g.font = '700 12px ' + BODY; g.textAlign = 'center'; g.fillText(c.mv ? '호송 중' : '화물차 — 곁에 가면 움직여요', x, y + r + 16); }
      for (const c of W.cv) { const [x, y] = w2s(c.x, c.y); g.fillStyle = '#d9f0ff'; g.beginPath(); g.arc(x, y, S * 0.26, 0, TAU); g.fill(); g.fillStyle = '#2b5a8a'; g.beginPath(); g.arc(x, y, S * 0.14, 0, TAU); g.fill(); }
      // 탈출
      const X = W.ex, [ex, ey] = w2s(X.x, X.y);
      g.strokeStyle = X.ph >= 1 ? '#7ad46a' : 'rgba(255,255,255,.25)'; g.lineWidth = 3; g.beginPath(); g.arc(ex, ey, 3.2 * S, 0, TAU); g.stroke();
      for (let k = 0; k < 4; k++) { const a = k * Math.PI / 2 + t * 0.5; g.beginPath(); g.moveTo(ex + Math.cos(a) * 2.6 * S, ey + Math.sin(a) * 2.6 * S); g.lineTo(ex + Math.cos(a + 0.2) * 2.2 * S, ey + Math.sin(a + 0.2) * 2.2 * S); g.stroke(); }
      if (X.ph === 3) { g.save(); g.translate(ex, ey); g.fillStyle = 'rgba(0,0,0,.35)'; g.beginPath(); g.ellipse(8, 12, S * 2.4, S * 1.4, 0, 0, TAU); g.fill(); g.fillStyle = '#c9d4e2'; g.beginPath(); g.moveTo(S * 2.6, 0); g.lineTo(-S * 1.6, -S * 1.2); g.lineTo(-S * 2.2, 0); g.lineTo(-S * 1.6, S * 1.2); g.closePath(); g.fill(); g.fillStyle = '#2b3a4e'; g.fillRect(S * 0.4, -S * 0.3, S * 1.2, S * 0.6); g.fillStyle = (t * 3 | 0) % 2 ? '#7ad46a' : '#ffd257'; g.fillRect(-S * 2.1, -S * 0.2, S * 0.3, S * 0.4); g.restore(); }
      g.fillStyle = X.ph >= 1 ? '#7ad46a' : '#9fb0c8'; g.font = '700 ' + Math.round(clamp(S * 0.38, 11, 16)) + 'px ' + BODY; g.textAlign = 'center';
      g.fillText(X.ph === 0 ? '탈출 지점 (주 목표 뒤)' : X.ph === 1 ? '🛰 탈출선 부르기 [E]' : X.ph === 2 ? '탈출선 도착까지 ' + Math.ceil(X.t) + '초' : X.ph === 3 ? '탑승! 원 안으로' : '', ex, ey - 3.5 * S);
    }

    /* ----- 그리기: 장면 ----- */
    function camUpdate(rdt) {
      cam.s = scale();
      const p = myP();
      let tx, ty;
      const focus = p && p.al && !p.boarded ? p : (W.pl.find((q) => q.al && !q.boarded && !(q.drop > 0)) || p || W.pl[0]);
      if (!focus) return;
      tx = focus.x; ty = focus.y;
      if (p && focus === p && mouse.on) { const [wx, wy] = s2w(mouse.x, mouse.y); const look = p.ads ? 0.42 : 0.22; tx += clamp((wx - p.x) * look, -9, 9); ty += clamp((wy - p.y) * look, -6, 6); }
      const k = 1 - Math.exp(-rdt * 7); cam.x += (tx - cam.x) * k; cam.y += (ty - cam.y) * k;
      const fxm = L.fx ? L.fx() : 1;
      shake = Math.max(0, shake - rdt * 1.6);
      const sh = shake * shake * 22 * fxm;
      cam.kx = (Math.random() - 0.5) * sh + cam.rx; cam.ky = (Math.random() - 0.5) * sh + cam.ry;
      cam.rx *= Math.exp(-rdt * 14); cam.ry *= Math.exp(-rdt * 14);
    }
    cam.rx = 0; cam.ry = 0;
    function shotFx(rdt) {
      const m = auto() ? -1 : me();
      W.pl.forEach((p, s) => {
        p._mf = (p._mf || 0) - rdt;
        const fc = host() ? p.fc : p.fcN;
        if (fcSeen[s] === undefined) { fcSeen[s] = fc; return; }
        if (fc === fcSeen[s] || !p.al) { fcSeen[s] = fc; return; }
        let n = (fc - fcSeen[s] + 1000) % 1000; fcSeen[s] = fc; if (n > 6) n = 1;
        const wp = wpOf(p); p._mf = 0.06;
        const near = nearCam(p.x, p.y, 4), vol = clamp(1.2 - hyp(p.x - cam.x, p.y - cam.y) / 30, 0.1, 1);
        if (near || s === m) Snd.gun(wp.id, vol * (s === m ? 1 : 0.6));
        if (s === m) { const k = (wp.rc || 0.04) * 60 * (L.fx ? L.fx() : 1); cam.rx -= Math.cos(p.a) * k; cam.ry -= Math.sin(p.a) * k; shake = Math.max(shake, wp.id === 'at' || wp.id === 'rail' || wp.id === 'mc' ? 0.3 : wp.id === 'sg' ? 0.18 : 0.05); }
        if (wp.pj || wp.flame) return;
        const mx = p.x + Math.cos(p.a) * 0.6, my = p.y + Math.sin(p.a) * 0.6;
        for (let i = 0; i < Math.min(9, n * (wp.pel || 1)); i++) {
          const a = p.a + (Math.random() - 0.5) * (wp.sp + (p.ads ? 0 : 0.02)) * (wp.pel ? 1 : 0.8), dx = Math.cos(a), dy = Math.sin(a);
          let L0 = rayWall(W.M, mx, my, dx, dy, wp.rg);
          for (const e of W.en) { const ax = e.x - mx, ay = e.y - my, tt = ax * dx + ay * dy; if (tt > 0 && tt < L0 && Math.abs(ax * dy - ay * dx) < EN[e.t].r) L0 = tt; }
          tracers.push({ x: mx, y: my, x2: mx + dx * L0, y2: my + dy * L0, t: 0, l: wp.pierce ? 0.3 : 0.07, c: wp.pierce ? '#9fe8ff' : '#ffe9a0', w: wp.pierce ? 3 : wp.id === 'mg' ? 2 : 1.5 });
          if (L0 < wp.rg - 0.3) addParts(mx + dx * L0, my + dy * L0, 2, '#ffd27a', 2.5, 0.18, 0.05);
        }
        if (tracers.length > 200) tracers.splice(0, tracers.length - 200);
      });
      W.tu.forEach((t) => {
        const fc = host() ? (t.fc | 0) : (t.fcN | 0);
        if (tuSeen[t.id] === undefined) { tuSeen[t.id] = fc; return; }
        if (fc === tuSeen[t.id]) return; tuSeen[t.id] = fc;
        if (nearCam(t.x, t.y, 4)) Snd.gun(t.k ? 'at' : 'mg', 0.5);
        if (t.k) return;
        const dx = Math.cos(t.a), dy = Math.sin(t.a), L0 = rayWall(W.M, t.x, t.y, dx, dy, 22);
        tracers.push({ x: t.x + dx * 0.6, y: t.y + dy * 0.6, x2: t.x + dx * L0, y2: t.y + dy * L0, t: 0, l: 0.06, c: '#ffe9a0', w: 1.5 });
      });
    }
    function stepFx(rdt) {
      for (const q of parts) { q.t += rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; const d = Math.exp(-(q.c === 'smoke' ? 0.8 : 3) * rdt); q.vx *= d; q.vy *= d; }
      parts = parts.filter((q) => q.t < q.l);
      for (const r of rings) r.t += rdt; rings = rings.filter((r) => r.t < r.l);
      for (const r of tracers) r.t += rdt; tracers = tracers.filter((r) => r.t < r.l);
      for (const r of beams) r.t += rdt; beams = beams.filter((r) => r.t < r.l);
      for (const c of corpses) { c.life -= rdt; c.x += c.vx * rdt; c.y += c.vy * rdt; c.a += c.sp * rdt; const d = Math.exp(-5 * rdt); c.vx *= d; c.vy *= d; c.sp *= d; }
      corpses = corpses.filter((c) => c.life > 0);
      for (const f of floats) f.t += rdt; floats = floats.filter((f) => f.t < 1.4);
      if (banner) { banner.t += rdt; if (banner.t > banner.l) banner = null; }
      flashA = Math.max(0, flashA - rdt * 2); hurtA = Math.max(0, hurtA - rdt * 1.5); ffWarn = Math.max(0, ffWarn - rdt); codeFlash = Math.max(0, codeFlash - rdt); codeFail = Math.max(0, codeFail - rdt); hitMk = Math.max(0, hitMk - rdt);
      const p = myP(); if (p) { if (p._hp !== undefined && p.hp < p._hp - 0.5) { hurtA = Math.min(1, hurtA + (p._hp - p.hp) / 60); if (p._hp - p.hp > 25) shake = Math.max(shake, 0.25); } p._hp = p.hp; }
    }
    function draw(t) {
      const g = ctx, w = cv.w, h = cv.h;
      g.fillStyle = '#0b0e14'; g.fillRect(0, 0, w, h);
      if (!W || !st || st.ph !== 'play') { drawIdle(g, w, h, t); return; }
      const S = cam.s;
      if (!mapCv) buildMap();
      // 지형
      const [ox, oy] = w2s(0, 0);
      g.imageSmoothingEnabled = true;
      g.drawImage(mapCv, ox, oy, MS * S, MS * S);
      drawObjectives(g, S, t);
      // 바닥 위
      for (const f of W.fi) { const [x, y] = w2s(f.x, f.y); const gr = g.createRadialGradient(x, y, 0, x, y, f.r * S); gr.addColorStop(0, 'rgba(255,160,40,' + (0.45 + 0.15 * Math.sin(t * 12)) + ')'); gr.addColorStop(1, 'rgba(255,60,0,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, f.r * S, 0, TAU); g.fill(); if (Math.random() < 0.5) addParts(f.x + (Math.random() - 0.5) * f.r * 1.4, f.y + (Math.random() - 0.5) * f.r * 1.4, 1, '#ff9a3a', 0.5, 0.5, 0.12, 1.2); }
      for (const m of W.mn) { const [x, y] = w2s(m.x, m.y); g.fillStyle = '#3a3e46'; g.beginPath(); g.arc(x, y, S * 0.15, 0, TAU); g.fill(); g.fillStyle = (t * 2 + m.x | 0) % 2 ? '#ff4a3a' : '#4a1510'; g.beginPath(); g.arc(x, y, S * 0.05, 0, TAU); g.fill(); }
      for (const it of W.it) drawItem(g, it, S, t);
      for (const c of corpses) drawCorpse(g, c, S);
      for (const b of W.bc) drawBeacon(g, b, S, t);
      for (const e of W.en) if (!EN[e.t].fly) drawEnemy(g, e, S, t);
      for (const tu of W.tu) drawTurret(g, tu, S, t);
      for (const v of W.vh) drawMech(g, v, S, t);
      W.pl.forEach((p, s) => drawPlayer(g, p, s, S, t));
      for (const e of W.en) if (EN[e.t].fly) drawEnemy(g, e, S, t);
      for (const b of W.pr) drawProj(g, b, S, t);
      // 효과
      for (const r of tracers) { const [x1, y1] = w2s(r.x, r.y), [x2, y2] = w2s(r.x2, r.y2), a = 1 - r.t / r.l; g.strokeStyle = r.c; g.globalAlpha = a; g.lineWidth = r.w; g.beginPath(); g.moveTo(x1 + (x2 - x1) * r.t / r.l * 0.6, y1 + (y2 - y1) * r.t / r.l * 0.6); g.lineTo(x2, y2); g.stroke(); }
      g.globalAlpha = 1;
      for (const r of beams) { const [x1, y1] = w2s(r.x, r.y), a = 1 - r.t / r.l; let x2, y2; if (Math.abs(r.y2 - r.y) > 20 || (r.x2 === r.x && r.y2 === r.y)) { x2 = x1; y2 = -20; } else [x2, y2] = w2s(r.x2, r.y2); g.strokeStyle = r.c; g.globalAlpha = a; g.lineWidth = (r.w || 2) + 4; g.globalAlpha = a * 0.3; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); g.globalAlpha = a; g.lineWidth = r.w || 2; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke(); }
      g.globalAlpha = 1;
      for (const f of (host() ? W.ef.filter((q) => q.k === 'las').map((q) => [1, q.tx * 10, q.ty * 10]) : (W.efV || []))) { if (f[0] !== 1) continue; const [x, y] = w2s(f[1] / 10, f[2] / 10); g.strokeStyle = 'rgba(255,90,60,.85)'; g.lineWidth = 5 + Math.sin(t * 40) * 2; g.beginPath(); g.moveTo(x, -20); g.lineTo(x, y); g.stroke(); g.fillStyle = 'rgba(255,200,120,.6)'; g.beginPath(); g.arc(x, y, S * 1.2, 0, TAU); g.fill(); if (Math.random() < 0.6) addParts(f[1] / 10, f[2] / 10, 2, '#ffcf6a', 4, 0.3, 0.08); }
      for (const q of parts) {
        const [x, y] = w2s(q.x, q.y), a = 1 - q.t / q.l;
        if (q.c === 'smoke') { g.fillStyle = 'rgba(60,60,60,' + (a * 0.35) + ')'; g.beginPath(); g.arc(x, y, q.s * S * (1 + q.t * 0.6), 0, TAU); g.fill(); }
        else { g.fillStyle = q.c; g.globalAlpha = a; g.fillRect(x - q.s * S / 2, y - q.s * S / 2, q.s * S, q.s * S); g.globalAlpha = 1; }
      }
      for (const r of rings) { const [x, y] = w2s(r.x, r.y), f = r.t / r.l; g.strokeStyle = r.c; g.globalAlpha = (1 - f) * 0.8; g.lineWidth = 3 + (1 - f) * 6; g.beginPath(); g.arc(x, y, r.r * S * (0.2 + f), 0, TAU); g.stroke(); if (f < 0.25) { g.fillStyle = r.c; g.globalAlpha = (0.25 - f) * 2.4; g.beginPath(); g.arc(x, y, r.r * S * 0.6, 0, TAU); g.fill(); } }
      g.globalAlpha = 1;
      for (const s of W.sb) { const [x, y] = w2s(s.x, s.y); g.fillStyle = 'rgba(120,200,255,.12)'; g.strokeStyle = 'rgba(160,220,255,' + (0.5 + 0.2 * Math.sin(t * 5)) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, s.r * S, 0, TAU); g.fill(); g.stroke(); }
      for (const f of floats) { const [x, y] = w2s(f.x, f.y - f.t * 0.8); g.globalAlpha = clamp(1.4 - f.t, 0, 1); g.fillStyle = f.c; g.font = '700 ' + Math.round(clamp(S * 0.36, 11, 16)) + 'px ' + BODY; g.textAlign = 'center'; g.fillText(f.s, x, y); }
      g.globalAlpha = 1;
      if (flashA > 0) { g.fillStyle = 'rgba(255,240,210,' + flashA * (L.fx ? L.fx() : 1) + ')'; g.fillRect(0, 0, w, h); }
      if (hurtA > 0) { const gr = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.7); gr.addColorStop(0, 'rgba(180,0,0,0)'); gr.addColorStop(1, 'rgba(180,0,0,' + hurtA * 0.55 + ')'); g.fillStyle = gr; g.fillRect(0, 0, w, h); }
      drawHUD(g, w, h, t);
    }
    function drawIdle(g, w, h, t) {
      const gr = g.createRadialGradient(w * 0.5, h * 0.4, 10, w * 0.5, h * 0.4, w * 0.7); gr.addColorStop(0, '#1d2433'); gr.addColorStop(1, '#0b0e14'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    }
    /* ----- HUD ----- */
    function panel(g, x, y, w, h) { g.fillStyle = 'rgba(10,14,22,.72)'; rr(g, x, y, w, h, 8); g.fill(); g.strokeStyle = 'rgba(120,150,190,.25)'; g.lineWidth = 1; g.stroke(); }
    function txt(g, s, x, y, sz, c, al, wt, font) { g.font = (wt || 600) + ' ' + Math.round(sz) + 'px ' + (font || BODY); g.fillStyle = c || '#e9eef5'; g.textAlign = al || 'left'; if (L.ui && L.ui.strokeText) L.ui.strokeText(g, s, x, y); else g.fillText(s, x, y); }
    function objLines() {
      const out = [], f = W.fac;
      for (const o of W.ob) {
        if (o.k === 'nest') out.push([(o.s === 2 ? '✓ ' : '◆ ') + FAC[f].hive + ' 파괴 ' + ((o.n0 || 4) - (o.n | 0)) + '/' + (o.n0 || 4), o.s === 2]);
        else if (o.k === 'term') out.push([(o.s === 2 ? '✓ ' : '◆ ') + (o.s === 0 ? '단말기에서 암호 입력' : '자료 송신 ' + Math.round(o.pr * 100) + '% (곁을 지키기)'), o.s === 2]);
        else if (o.k === 'zone') out.push([(o.s === 2 ? '✓ ' : '◆ ') + (o.s === 0 ? '거점을 켜기(E)' : '거점 사수 ' + Math.round(o.pr * 100) + '%'), o.s === 2]);
        else if (o.k === 'gen') out.push([(o.s === 2 ? '✓ ' : '◆ ') + '발전기 켜기', o.s === 2]);
        else if (o.k === 'silo') out.push([(o.s === 2 ? '✓ ' : '◆ ') + (o.s === 0 ? '발사대에 발사 암호' : '발사 준비 ' + Math.round(o.pr * 100) + '%'), o.s === 2]);
        else if (o.k === 'shel') out.push([(o.s === 2 ? '✓ ' : '◆ ') + (o.s === 0 ? '대피소 문 열기(E)' : '피난민 구조 ' + (o.sv | 0) + '/6 (희생 ' + (o.dd | 0) + '/7)'), o.s === 2]);
        else if (o.k === 'crawl') out.push([(o.s === 2 ? '✓ ' : '◆ ') + '화물차 호송' + (W.cr ? ' (체력 ' + Math.round(W.cr.hp / W.cr.mhp * 100) + '%)' : ''), o.s === 2]);
      }
      W.sd.forEach((o) => out.push([(o.s === 2 ? '✓ ' : '◇ ') + SIDE.find((q) => q.id === o.k).nm, o.s === 2, 1]));
      const X = W.ex;
      out.push([X.ph === 0 ? '· 탈출: 주 목표 뒤에' : X.ph === 1 ? '▶ 탈출 지점에서 탈출선 부르기(E)' : X.ph === 2 ? '▶ 탈출선 도착까지 ' + Math.ceil(X.t) + '초 — 버티기' : X.ph === 3 ? '▶ 탈출선에 타기! (원 안)' : '탈출 완료', X.ph >= 4, 0, X.ph >= 1]);
      return out;
    }
    function drawHUD(g, w, h, t) {
      const k = clamp(h / 760, 0.9, 1.6) * (L.ui && L.ui.scale ? L.ui.scale() : 1), p = myP(), m = me();
      // 왼쪽 위: 작전 · 시간 · 목표
      const X0 = 14, Y0 = 54;
      const lines = objLines(), pw = 330 * k, ph = (78 + lines.length * 20) * k;
      panel(g, X0, Y0, pw, ph);
      txt(g, PLANETS[st.mi.pi].nm + ' · ' + MT[st.mi.mt].nm, X0 + 12 * k, Y0 + 22 * k, 15 * k, '#ffd257', 'left', 700);
      const left = Math.max(0, W.tl - W.t), tm = Math.floor(left / 60) + ':' + String(Math.floor(left % 60)).padStart(2, '0');
      txt(g, (W.timeUp ? '시간 끝 ' : '남은 시간 ') + tm, X0 + 12 * k, Y0 + 44 * k, 14 * k, left < 120 ? '#ff6a4a' : '#cfd8e8', 'left', 700, MONO);
      txt(g, '증원 ' + W.rein + ' · 표본 ' + W.pl.reduce((a, q) => a + (q.smp | 0), 0), X0 + pw - 12 * k, Y0 + 44 * k, 13 * k, '#9fdcff', 'right', 700, MONO);
      lines.forEach((l, i) => txt(g, l[0], X0 + 12 * k, Y0 + (68 + i * 20) * k, 13 * k, l[1] ? '#7ad46a' : l[3] ? '#9be36b' : l[2] ? '#9fb0c8' : '#e9eef5', 'left', l[2] ? 500 : 600));
      // 부대 목록
      let sy = Y0 + ph + 10 * k;
      W.pl.forEach((q, s) => {
        panel(g, X0, sy, 200 * k, 30 * k);
        g.fillStyle = COL(s); g.beginPath(); g.arc(X0 + 14 * k, sy + 15 * k, 6 * k, 0, TAU); g.fill();
        txt(g, nm(s), X0 + 26 * k, sy + 20 * k, 12 * k, '#e9eef5', 'left', 700);
        const stx = q.boarded ? '탑승' : !q.al ? (q.pod ? '증원 중' : '쓰러짐') : q.drop > 0 ? '강하' : q.veh >= 0 ? '보행기' : '';
        if (stx) txt(g, stx, X0 + 192 * k, sy + 20 * k, 11 * k, !q.al ? '#ee6a55' : '#9fdcff', 'right', 700);
        else { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(X0 + 110 * k, sy + 12 * k, 80 * k, 6 * k); g.fillStyle = q.hp / q.mhp < 0.35 ? '#ee6a55' : '#7ad46a'; g.fillRect(X0 + 110 * k, sy + 12 * k, 80 * k * clamp(q.hp / q.mhp, 0, 1), 6 * k); }
        sy += 34 * k;
      });
      // 오른쪽 위: 작은 지도
      drawMinimap(g, w, h, k, t);
      // 화면 밖 목표 화살표
      const tg = [];
      if (W.ex.ph >= 1) tg.push([W.ex.x, W.ex.y, '#7ad46a', '탈출']);
      if (!W.md) { for (const o of W.ob) if (o.s !== 2 && o.k !== 'nest' && o.k !== 'pad' && o.k !== 'dest') tg.push([o.x, o.y, '#ffd257', '목표']); for (const e of W.en) if (e.main) tg.push([e.x, e.y, '#ffd257', FAC[W.fac].hive]); if (W.cr) tg.push([W.cr.x, W.cr.y, '#ffd257', '화물차']); }
      for (const q of tg) { const [sx, sy2] = w2s(q[0], q[1]); if (sx > 40 && sy2 > 60 && sx < w - 40 && sy2 < h - 40) continue; const cx = w / 2, cy = h / 2, a = Math.atan2(sy2 - cy, sx - cx), R0 = Math.min(w, h) * 0.42; const ax = cx + Math.cos(a) * R0, ay = cy + Math.sin(a) * R0 * 0.95; g.save(); g.translate(ax, ay); g.rotate(a); g.fillStyle = q[2]; g.beginPath(); g.moveTo(12 * k, 0); g.lineTo(-6 * k, -8 * k); g.lineTo(-6 * k, 8 * k); g.fill(); g.restore(); txt(g, q[3] + ' ' + Math.round(hyp(q[0] - cam.x, q[1] - cam.y)) + 'm', ax, ay - 12 * k, 11 * k, q[2], 'center', 700); }
      // 배너
      if (banner) { const a = clamp(Math.min(banner.t * 4, (banner.l - banner.t) * 2), 0, 1); g.globalAlpha = a; const bw = Math.min(w * 0.6, 640 * k); panel(g, w / 2 - bw / 2, 60 * k, bw, banner.s2 ? 62 * k : 42 * k); txt(g, banner.s, w / 2, 88 * k, 20 * k, banner.c, 'center', 400, DISP); if (banner.s2) txt(g, banner.s2, w / 2, 111 * k, 13 * k, '#cfd8e8', 'center', 600); g.globalAlpha = 1; }
      if (W.ex.ph === 2) txt(g, '탈출선 ' + Math.ceil(W.ex.t) + '초', w / 2, (banner ? 150 : 96) * k, 26 * k, '#9fdcff', 'center', 400, DISP);
      if (!p) { if (m < 0 || auto()) txt(g, '관전 중', w / 2, h - 30 * k, 16 * k, '#cfd8e8', 'center', 700); return; }
      // 쓰러짐 · 탑승
      if (!p.al) { panel(g, w / 2 - 230 * k, h / 2 - 50 * k, 460 * k, 90 * k); txt(g, p.pod ? '증원 요청됨 — 곧 내려가요' : '쓰러졌어요', w / 2, h / 2 - 14 * k, 22 * k, '#ee6a55', 'center', 400, DISP); txt(g, W.rein > 0 ? '살아 있는 동료가 「증원」을 부르면 다시 투입돼요 (남은 증원 ' + W.rein + ')' : '증원이 바닥났어요 — 동료가 탈출하면 성공이에요', w / 2, h / 2 + 18 * k, 13 * k, '#cfd8e8', 'center', 600); }
      if (p.boarded) { panel(g, w / 2 - 200 * k, h / 2 - 40 * k, 400 * k, 64 * k); txt(g, '탈출선 탑승 완료', w / 2, h / 2 - 6 * k, 22 * k, '#7ad46a', 'center', 400, DISP); txt(g, '동료를 기다리는 중…', w / 2, h / 2 + 16 * k, 13 * k, '#cfd8e8', 'center', 600); }
      if (p.al && !p.boarded) drawMyStatus(g, w, h, k, p, t);
      drawStratBar(g, w, h, k, p, t);
      if (p.tm >= 0) drawCodePanel(g, w, h, k, p, t);
      if (p.al && !p.boarded && mouse.on && !bigMap) drawCross(g, k, p, t);
      if (ffWarn > 0) txt(g, '⚠ 아군 사격 주의', w / 2, h * 0.3, 16 * k, 'rgba(238,106,85,' + clamp(ffWarn, 0, 1) + ')', 'center', 800);
      if (bigMap) drawBigMap(g, w, h, k, t);
    }
    function drawMyStatus(g, w, h, k, p, t) {
      const x = 14, bw = 330 * k, bh = 128 * k, y = h - bh - 14;
      panel(g, x, y, bw, bh);
      // 체력 · 방패 · 기력
      const hpF = clamp(p.hp / p.mhp, 0, 1);
      g.fillStyle = 'rgba(255,255,255,.1)'; g.fillRect(x + 12 * k, y + 12 * k, bw - 24 * k, 12 * k);
      g.fillStyle = hpF < 0.3 ? '#ee6a55' : '#7ad46a'; g.fillRect(x + 12 * k, y + 12 * k, (bw - 24 * k) * hpF, 12 * k);
      if (p.bp) { g.fillStyle = '#4fb3e8'; g.fillRect(x + 12 * k, y + 26 * k, (bw - 24 * k) * clamp(p.sh / 200, 0, 1), 4 * k); }
      g.fillStyle = '#ffd257'; g.fillRect(x + 12 * k, y + 32 * k, (bw - 24 * k) * clamp(p.stm, 0, 1), 3 * k);
      txt(g, Math.ceil(p.hp) + ' / ' + p.mhp, x + bw - 14 * k, y + 22 * k, 11 * k, '#0b0e14', 'right', 800, MONO);
      // 무기
      const ws = [[PRI[p.lo[0]], p.W[0]], [SEC[p.lo[1]], p.W[1]], p.sw ? [SUPW[p.sw], p.W[2]] : null];
      if (p.veh >= 0) { const v = W.vh.find((q) => q.id === p.veh); txt(g, '🦿 강습 보행기 — 기관포 · 로켓 ' + (v ? v.rk : 0) + ' · [E] 내리기', x + 12 * k, y + 58 * k, 13 * k, '#ffd257', 'left', 700); }
      else ws.forEach((q, i) => {
        if (!q) return; const yy = y + (52 + i * 20) * k, on = p.w === i;
        if (on) { g.fillStyle = 'rgba(255,210,87,.15)'; g.fillRect(x + 8 * k, yy - 14 * k, bw - 16 * k, 19 * k); }
        txt(g, (i + 1) + ' ' + q[0].ic + ' ' + q[0].nm, x + 14 * k, yy, 12.5 * k, on ? '#ffd257' : '#9fb0c8', 'left', on ? 700 : 500);
        const S0 = q[1] || { mag: 0, rsv: 0 };
        txt(g, (p.rlF || (on && host() && p.W[p.w] && p.W[p.w].rl > 0) ? '장전 중 ' : '') + S0.mag + ' / ' + S0.rsv, x + bw - 14 * k, yy, 13 * k, S0.mag === 0 ? '#ee6a55' : '#e9eef5', 'right', 700, MONO);
      });
      const yb = y + bh - 14 * k;
      txt(g, '💣 ' + p.gr + ' [' + (kl('gren') || 'G') + ']  💉 ' + p.stim + ' [' + (kl('stim') || 'V') + ']' + '  🧪 표본 ' + (p.smp | 0), x + 14 * k, yb, 13 * k, '#e9eef5', 'left', 700);
      const kb = (id, lab, xx) => { const s = kl(id); if (s && L.ui.drawKeyBadge) L.ui.drawKeyBadge(g, xx, yb + 3 * k, s, k * 0.9); };
      // 상호작용 안내
      const it = interactHint(p);
      if (it) { const hw = g.measureText ? 0 : 0; panel(g, w / 2 - 170 * k, h - 190 * k, 340 * k, 32 * k); txt(g, '[' + (kl('act') || 'E') + '] ' + it, w / 2, h - 168 * k, 14 * k, '#ffd257', 'center', 700); }
      const cur = p.W[p.w];
      if (cur && cur.mag === 0 && cur.rsv === 0 && p.veh < 0) txt(g, '탄약 없음 — 보급품을 부르세요', w / 2, h - 205 * k, 13 * k, '#ee6a55', 'center', 700);
      else if (cur && cur.mag === 0 && p.veh < 0) txt(g, '[' + (kl('reload') || 'R') + '] 장전', w / 2, h - 205 * k, 13 * k, '#ffd257', 'center', 700);
    }
    function interactHint(p) {
      const near = (o, r) => hyp(o.x - p.x, o.y - p.y) < (r || 2.4);
      if (p.veh >= 0) return '보행기에서 내리기';
      for (const v of W.vh) if (v.dr < 0 && near(v, 2)) return '보행기 타기';
      for (const o of W.ob) { if (!near(o)) continue; if (o.k === 'term' && o.s === 0) return '단말기 열기 (암호 입력)'; if (o.k === 'gen' && o.s === 0) return '발전기 켜기'; if (o.k === 'zone' && o.s === 0) return '거점 사수 시작'; if (o.k === 'silo' && o.s === 0) return W.ob.filter((q) => q.k === 'gen').every((q) => q.s === 2) ? '발사 암호 입력' : '발전기 2개를 먼저 켜세요'; if (o.k === 'shel' && o.s === 0) return '대피소 문 열기'; }
      for (const o of W.sd) { if (!near(o) || o.s) continue; if (o.k === 'cache') return '저장고 열기'; if (o.k === 'beacon') return '신호기 가동 (암호)'; }
      if (W.ex.ph === 1 && near(W.ex, 2.6)) return '탈출선 부르기';
      return '';
    }
    function drawStratBar(g, w, h, k, p, t) {
      const n = 6, bs = 54 * k, gap = 6 * k, tw = n * bs + (n - 1) * gap, x0 = w / 2 - tw / 2 + 60 * k, y0 = h - bs - 14;
      for (let i = 0; i < n; i++) {
        const si = p.sl[i], S0 = STR[si], x = x0 + i * (bs + gap), cd = p.cd[i] || 0, ok = slotReady(p, i);
        panel(g, x, y0, bs, bs);
        g.globalAlpha = ok ? 1 : 0.45; txt(g, S0.ic, x + bs / 2, y0 + bs * 0.58, 24 * k, '#fff', 'center', 400); g.globalAlpha = 1;
        if (cd > 0) { g.fillStyle = 'rgba(0,0,0,.55)'; g.beginPath(); g.moveTo(x + bs / 2, y0 + bs / 2); g.arc(x + bs / 2, y0 + bs / 2, bs * 0.45, -Math.PI / 2, -Math.PI / 2 + TAU * clamp(cd / cdOf(W, si), 0, 1)); g.fill(); txt(g, String(Math.ceil(cd)), x + bs / 2, y0 + bs * 0.62, 14 * k, '#ffd257', 'center', 800, MONO); }
        if (p.nU[i] >= 0) txt(g, '×' + p.nU[i], x + bs - 4 * k, y0 + 13 * k, 10 * k, '#9fdcff', 'right', 700, MONO);
        if (si === S_RE) txt(g, String(W.rein), x + bs - 4 * k, y0 + 13 * k, 10 * k, '#9fdcff', 'right', 700, MONO);
        if (ready === i) { g.strokeStyle = '#ffd257'; g.lineWidth = 3; rr(g, x - 2, y0 - 2, bs + 4, bs + 4, 9); g.stroke(); }
      }
      const kb = kl('strat'); if (kb && L.ui.drawKeyBadge) L.ui.drawKeyBadge(g, x0 - 8 * k, y0 + bs, kb, k);
      txt(g, '지원 요청', x0 - 12 * k, y0 + 18 * k, 11 * k, '#9fb0c8', 'right', 700);
      // 암호 입력 창
      if (stratOpen && ready < 0) {
        const lw = 420 * k, lh = (40 + n * 34) * k, lx = w / 2 - lw / 2 + 60 * k, ly = y0 - lh - 10 * k;
        panel(g, lx, ly, lw, lh);
        txt(g, '지원 요청 — 방향키' + (wasdMode() ? '·WASD' : '') + '로 암호 입력', lx + 12 * k, ly + 24 * k, 13 * k, '#ffd257', 'left', 700);
        for (let i = 0; i < n; i++) {
          const si = p.sl[i], S0 = STR[si], yy = ly + (52 + i * 34) * k, ok = slotReady(p, i), match = codeBuf && S0.c.indexOf(codeBuf) === 0;
          if (match) { g.fillStyle = 'rgba(255,210,87,.12)'; g.fillRect(lx + 6 * k, yy - 20 * k, lw - 12 * k, 30 * k); }
          g.globalAlpha = ok ? (codeBuf && !match ? 0.35 : 1) : 0.4;
          txt(g, S0.ic + ' ' + S0.nm, lx + 14 * k, yy, 13 * k, '#e9eef5', 'left', 700);
          for (let j = 0; j < S0.c.length; j++) { const done = match && j < codeBuf.length; txt(g, ARROW[S0.c[j]], lx + lw - 16 * k - (S0.c.length - 1 - j) * 22 * k, yy, 17 * k, done ? '#ffd257' : '#cfd8e8', 'center', 800); }
          if (!ok) txt(g, p.cd[i] > 0 ? Math.ceil(p.cd[i]) + '초' : p.nU[i] === 0 ? '없음' : '—', lx + lw - 16 * k - S0.c.length * 22 * k - 10 * k, yy, 11 * k, '#ee6a55', 'right', 700, MONO);
          g.globalAlpha = 1;
        }
        if (codeFail > 0) { g.strokeStyle = 'rgba(238,106,85,' + codeFail * 2 + ')'; g.lineWidth = 3; rr(g, lx, ly, lw, lh, 8); g.stroke(); }
      } else if (!stratOpen && ready < 0 && W.t < 25) {
        txt(g, '[' + (kb || 'Ctrl') + '] 누른 채 방향키 = 지원 요청', w / 2 + 60 * k, y0 - 12 * k, 12 * k, '#9fb0c8', 'center', 600);
      }
      if (ready >= 0) {
        const S0 = STR[p.sl[ready]];
        panel(g, w / 2 - 240 * k + 60 * k, y0 - 56 * k, 480 * k, 44 * k);
        txt(g, '📍 ' + S0.nm + ' — 클릭(또는 ' + (kl('gren') || 'G') + ')로 신호기 던지기 · 오른쪽 클릭 취소', w / 2 + 60 * k, y0 - 28 * k, 13 * k, codeFlash > 0 ? '#fff' : '#ffd257', 'center', 700);
      }
    }
    function drawCodePanel(g, w, h, k, p, t) {
      const o = p.tm >= 100 ? W.sd[p.tm - 100] : W.ob[p.tm]; if (!o || !o.c) return;
      const n = o.c.length, cw = Math.max(360 * k, n * 46 * k + 40 * k), chh = 120 * k, x = w / 2 - cw / 2, y = h / 2 - chh - 40 * k;
      panel(g, x, y, cw, chh);
      txt(g, o.k === 'silo' ? '발사 암호' : o.k === 'term' ? '송신 암호' : '신호기 암호', w / 2, y + 26 * k, 15 * k, '#ffd257', 'center', 700);
      for (let j = 0; j < n; j++) { const done = j < tmBuf.length; const xx = w / 2 - (n - 1) * 23 * k + j * 46 * k; g.fillStyle = done ? 'rgba(122,212,106,.25)' : 'rgba(255,255,255,.06)'; rr(g, xx - 19 * k, y + 40 * k, 38 * k, 38 * k, 6); g.fill(); txt(g, ARROW[o.c[j]], xx, y + 68 * k, 24 * k, done ? '#7ad46a' : '#e9eef5', 'center', 800); }
      txt(g, '방향키(또는 WASD)로 차례대로 · [' + (kl('act') || 'E') + '] 그만두기', w / 2, y + chh - 14 * k, 12 * k, codeFail > 0 ? '#ee6a55' : '#9fb0c8', 'center', 600);
    }
    function drawCross(g, k, p, t) {
      const x = mouse.x, y = mouse.y, wp = wpOf(p), d = hyp(s2w(x, y)[0] - p.x, s2w(x, y)[1] - p.y);
      const spr = clamp(((wp.sp || 0.05) * (p.ads ? 0.45 : 1) + (p.rec || 0)) * d * cam.s * 0.5, 6 * k, 120 * k);
      g.strokeStyle = ready >= 0 ? '#ffd257' : 'rgba(255,255,255,.9)'; g.lineWidth = 2;
      if (ready >= 0) { g.beginPath(); g.arc(x, y, 12 * k, 0, TAU); g.stroke(); g.beginPath(); g.moveTo(x, y - 18 * k); g.lineTo(x, y + 18 * k); g.moveTo(x - 18 * k, y); g.lineTo(x + 18 * k, y); g.stroke(); const R = dangerR(p.sl[ready]); if (R > 1) { g.setLineDash([6, 6]); g.strokeStyle = 'rgba(255,90,70,.6)'; g.beginPath(); g.arc(x, y, R * cam.s, 0, TAU); g.stroke(); g.setLineDash([]); } return; }
      for (let i = 0; i < 4; i++) { const a = i * Math.PI / 2; g.beginPath(); g.moveTo(x + Math.cos(a) * spr, y + Math.sin(a) * spr); g.lineTo(x + Math.cos(a) * (spr + 8 * k), y + Math.sin(a) * (spr + 8 * k)); g.stroke(); }
      g.fillStyle = '#fff'; g.fillRect(x - 1, y - 1, 2, 2);
      const cur = p.W[p.w];
      if (cur && (p.rlF || (host() && cur.rl > 0))) { const f = host() ? 1 - cur.rl / wp.rl : (t * 0.8) % 1; g.strokeStyle = '#ffd257'; g.lineWidth = 3; g.beginPath(); g.arc(x, y, spr + 14 * k, -Math.PI / 2, -Math.PI / 2 + TAU * f); g.stroke(); }
      if (cur && wp.mag > 1) { const f = cur.mag / wp.mag; g.fillStyle = f < 0.25 ? '#ee6a55' : 'rgba(255,255,255,.6)'; g.fillRect(x + spr + 12 * k, y + 6 * k, 3 * k, -20 * k * f); }
    }
    function drawMinimap(g, w, h, k, t) {
      const ms = clamp(h * 0.26, 150, 290), x0 = w - ms - 14, y0 = 54, sc = ms / MS;
      panel(g, x0 - 4, y0 - 4, ms + 8, ms + 8);
      g.globalAlpha = 0.85; g.drawImage(mapCv, x0, y0, ms, ms); g.globalAlpha = 1;
      g.fillStyle = 'rgba(5,8,14,.35)'; g.fillRect(x0, y0, ms, ms);
      const dot = (x, y, r, c) => { g.fillStyle = c; g.beginPath(); g.arc(x0 + x * sc, y0 + y * sc, r, 0, TAU); g.fill(); };
      const p = myP(), scout = W.pl.some((q) => q.al && ARM[q.A].pk === 'scout'), rad = scout ? 30 : 16;
      for (const e of W.en) { if (EN[e.t].tier === 3) { dot(e.x, e.y, 4, '#ffb347'); continue; } if (W.pl.some((q) => q.al && hyp(q.x - e.x, q.y - e.y) < rad)) dot(e.x, e.y, EN[e.t].tier >= 2 ? 3 : 1.6, '#ff5a4a'); }
      for (const o of W.ob) if (o.k !== 'nest') dot(o.x, o.y, 4, o.s === 2 ? '#7ad46a' : '#ffd257');
      for (const o of W.sd) dot(o.x, o.y, 3, o.s === 2 ? '#7ad46a' : '#cfd8e8');
      for (const it of W.it) if (it.k === 0 || it.k === 5) dot(it.x, it.y, 1.5, '#7ff0c8');
      for (const b of W.bc) dot(b.x, b.y, 2.5, '#ff4a3a');
      if (W.cr) dot(W.cr.x, W.cr.y, 3.5, '#ffd257');
      g.strokeStyle = W.ex.ph >= 1 ? '#7ad46a' : '#9fb0c8'; g.lineWidth = 2; g.beginPath(); g.arc(x0 + W.ex.x * sc, y0 + W.ex.y * sc, 5, 0, TAU); g.stroke();
      W.pl.forEach((q, s) => { if (q.al && !q.boarded) dot(q.x, q.y, s === me() ? 3.5 : 3, COL(s)); });
      const vw = cv.w / cam.s, vh = cv.h / cam.s; g.strokeStyle = 'rgba(255,255,255,.4)'; g.lineWidth = 1; g.strokeRect(x0 + (cam.x - vw / 2) * sc, y0 + (cam.y - vh / 2) * sc, vw * sc, vh * sc);
      const kb = kl('map'); if (kb && L.ui.drawKeyBadge) L.ui.drawKeyBadge(g, x0 + ms + 2, y0 + ms + 2, kb, k * 0.9);
    }
    function drawBigMap(g, w, h, k, t) {
      g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(0, 0, w, h);
      const ms = Math.min(w, h) - 140 * k, x0 = w / 2 - ms / 2, y0 = h / 2 - ms / 2 + 20 * k, sc = ms / MS;
      g.drawImage(mapCv, x0, y0, ms, ms);
      const dot = (x, y, r, c) => { g.fillStyle = c; g.beginPath(); g.arc(x0 + x * sc, y0 + y * sc, r, 0, TAU); g.fill(); };
      for (const e of W.en) if (EN[e.t].tier === 3) dot(e.x, e.y, 7, '#ffb347');
      for (const o of W.ob) { dot(o.x, o.y, 7, o.s === 2 ? '#7ad46a' : '#ffd257'); }
      for (const o of W.sd) dot(o.x, o.y, 5, o.s === 2 ? '#7ad46a' : '#cfd8e8');
      for (const it of W.it) if (it.k === 0 || it.k === 5) dot(it.x, it.y, 3, '#7ff0c8');
      g.strokeStyle = '#7ad46a'; g.lineWidth = 3; g.beginPath(); g.arc(x0 + W.ex.x * sc, y0 + W.ex.y * sc, 9, 0, TAU); g.stroke();
      W.pl.forEach((q, s) => { if (q.al) dot(q.x, q.y, 5, COL(s)); });
      txt(g, '작전 지도 — 노랑 목표 · 초록 탈출 · 청록 표본 · 주황 구조물 (아무 데나 누르면 닫기)', w / 2, y0 - 14 * k, 14 * k, '#e9eef5', 'center', 700);
    }

    /* ----- 루프 ----- */
    const stopLoop = U.loop((rdt0) => {
      const rdt = Math.min(0.1, rdt0);
      try {
        if (st && st.ph === 'load') { hostLoadFlow(rdt); pollHost(); if (st.ph === 'load') buildLoad(); }
        else if (st && st.ph === 'end') { if (host() && endT > 0) { endT -= rdt; if (endT <= 0) { endT = -1; api.setState(nextMission(st)); } } if (st.ph === 'end') buildEnd(); }
        else if (st && st.ph === 'play' && W) {
          readInput();
          if (host()) { pollHost(); hostStep(rdt); }
          else { pollGuest(); guestStep(rdt); }
          shotFx(rdt); camUpdate(rdt); stepFx(rdt);
        }
        publish(rdt);
      } catch (e) { console.error(e); }
      try { draw(performance.now() / 1000); } catch (e) { console.error(e); }
    });
    const onRes = () => { ovSig = ''; };
    window.addEventListener('resize', onRes);

    return {
      update(next) {
        if (!next) return;
        const prev = st; st = next;
        if (st.ph === 'play') { const k2 = st.rid + '.' + st.mk; if (k2 !== key || !W) startMission(); }
        else if (prev && prev.ph === 'play' && st.ph === 'end') { endT = 25; api.sfx(st.res && st.res.ok ? 'win' : 'lose'); }
        if (st.ph === 'load') { if (!prev || prev.mk !== st.mk || prev.ph !== 'load') { myRd = 0; autoRd = 0; W = null; } }
        if (st.ph === 'done') closeOv();
      },
      saveState() { return st ? { rid: st.rid, ph: st.ph } : false; },
      loadState(b) { if (!st || !host()) return; if (st.ph === 'play') { const n = U.clone(st); n.ph = 'load'; n.rd = n.rd.map((v, s) => (isAIseat(s) ? 1 : 0)); api.setState(n); api.toast('진행 중이던 작전은 장비 고르기부터 다시 시작해요'); } },
      destroy() {
        stopLoop(); closeOv();
        if (offIn) offIn();
        window.removeEventListener('blur', onBlur); window.removeEventListener('resize', onRes);
        cv.cv.removeEventListener('pointermove', onMove); cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onUp); cv.cv.removeEventListener('wheel', onWheel); cv.cv.removeEventListener('contextmenu', noCtx);
        styleEl.remove(); Snd.close(); cv.destroy();
      },
      _dbg: () => ({ W, st, loc, cam, key }),
    };
  }

  /* ================= 도감 ================= */
  function sfCodex() {
    const wrow = (w) => ({ icon: w.ic, name: w.nm, tag: w.tag || '지원 화기', desc: w.d + ' · ' + (w.pel ? '피해 ' + w.dmg + '×' + w.pel : '피해 ' + w.dmg) + ' · 관통 ' + w.ap + ' · 분당 ' + Math.round(60 / w.iv) + '발 · 탄창 ' + w.mag + ' · 예비 ' + w.rsv + ' · 장전 ' + w.rl + '초' + (w.ex ? ' · 폭발 반경 ' + w.ex : '') + (w.burst ? ' · ' + w.burst + '발 점사' : '') });
    const swd = { at: '중장갑·구조물에 가장 좋은 로켓. 쏜 뒤 길게 장전.', mg: '무리를 막는 기관총. 쏘는 동안 조금 느려져요.', rail: '여러 적을 한 줄로 꿰뚫는 한 방.', fl: '앞쪽을 불태워요. 불붙은 적은 계속 타요(아군 조심).' };
    return [
      { h: '주무기', p: ['관통(1~5)이 적 장갑보다 높으면 제 피해, 같으면 65%, 하나 낮으면 12%만 들어가요(「튕김」).'], rows: PRI.map(wrow) },
      { h: '보조·수류탄', rows: SEC.map(wrow).concat(GRE.map((g) => ({ icon: g.ic, name: g.nm, tag: '수류탄', desc: g.d + (g.dmg ? ' · 피해 ' + g.dmg + ' · 관통 ' + g.ap : '') + ' · 반경 ' + g.r + (g.fuse ? ' · ' + g.fuse + '초 뒤 폭발' : ' · 닿으면 폭발') }))) },
      { h: '지원 화기', rows: Object.keys(SUPW).map((k) => wrow(Object.assign({}, SUPW[k], { d: swd[k] }))) },
      { h: '갑옷', rows: ARM.map((a) => ({ icon: a.ic, name: a.nm, tag: a.w, desc: '이동 ' + Math.round(a.sp * 100) + '% · 받는 피해 ' + Math.round(a.tk * 100) + '% · ' + a.pd })) },
      { h: '지원 요청', p: ['지원 요청 키(기본 Ctrl·C)를 누른 채 방향키로 암호 → 신호기를 던지면 잠시 뒤 도착해요. 포격·폭격·투하 상자는 아군도 다쳐요!'], rows: STR.map((S) => ({ icon: S.ic, name: S.nm, tag: S.cat, desc: codeStr(S.c) + ' · ' + S.d + ' · 도착 ' + S.dl + '초 · 재사용 ' + S.cd + '초' + (S.n ? ' · ' + S.n + '번' : '') + (S.cost > 0 ? ' · 해금 ' + S.cost + '점' : S.cost === 0 ? ' · 처음부터' : ' · 기본') })) },
      { h: '적', p: FAC.map((f) => f.full + ': ' + f.d), rows: EN.map((e) => ({ icon: e.f === 0 ? '🐜' : e.f === 1 ? '🤖' : e.f === 2 ? '👁' : '🏚', name: e.nm, tag: e.f >= 0 ? FAC[e.f].nm + ' · ' + ['잡병', '정예', '대형', '구조물'][e.tier] : '구조물', desc: e.d + ' · 체력 ' + e.hp + ' · 장갑 ' + e.ar + (e.rear ? ' (뒤쪽 약함)' : '') + (e.rg > 2 ? ' · 사거리 ' + e.rg : '') })) },
      { h: '행성·작전', rows: PLANETS.map((p) => ({ icon: '🪐', name: p.nm, tag: SECTORS[p.sec] + ' · ' + FAC[p.f].nm, desc: p.d })).concat(MT.map((m) => ({ icon: '🎯', name: m.nm, tag: '주 목표', desc: m.d(0).replace(FAC[0].hive, '둥지·공장·균열') }))).concat(SIDE.map((s) => ({ icon: '◇', name: s.nm, tag: '보조 목표', desc: s.d }))).concat(DIFF.map((d, i) => ({ icon: '☠', name: (i + 1) + '. ' + d.nm, tag: '난이도', desc: '적 밀도 ' + Math.round(d.den * 100) + '% · 정예 ' + Math.round(d.eli * 100) + '% · 대형 ' + Math.round(d.hv * 100) + '% · 증원 ' + d.re + '+인원 · 성공 보상 ' + d.rq + '점' }))) },
      { h: '함선 개량', p: ['표본으로 사요. 이 판(저장) 안에서만 유지되고 새 판은 처음부터예요.'], rows: UPG.map((u) => ({ icon: '🛠', name: u.nm, tag: u.cost.length + '단계', desc: u.d + ' · 표본 ' + u.cost.join('/') })) },
    ];
  }
  function preview(c) {
    const g = c.getContext('2d'), w = c.width, h = c.height, R = rng(11);
    g.fillStyle = '#6e5a48'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 400; i++) { g.fillStyle = R() < 0.5 ? 'rgba(0,0,0,.08)' : 'rgba(255,255,255,.05)'; g.fillRect(R() * w, R() * h, 3, 3); }
    for (let i = 0; i < 14; i++) { g.fillStyle = '#3f332a'; g.beginPath(); g.arc(R() * w, R() * h, 14 + R() * 26, 0, TAU); g.fill(); }
    const boom = (x, y, r) => { const gr = g.createRadialGradient(x, y, 2, x, y, r); gr.addColorStop(0, '#fff6c8'); gr.addColorStop(0.4, '#ffb347'); gr.addColorStop(1, 'rgba(255,80,20,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, TAU); g.fill(); };
    g.strokeStyle = 'rgba(255,74,58,.8)'; g.lineWidth = 5; g.beginPath(); g.moveTo(470, 0); g.lineTo(470, 120); g.stroke();
    boom(470, 130, 70);
    for (let i = 0; i < 9; i++) { const x = 380 + R() * 200, y = 170 + R() * 150; g.fillStyle = '#b8742e'; g.beginPath(); g.ellipse(x, y, 13, 9, R() * 3, 0, TAU); g.fill(); }
    const cols = ['#e8c547', '#4fb3e8', '#e8664f', '#7ad46a'];
    cols.forEach((c2, i) => { const x = 140 + i * 45, y = 220 + (i % 2) * 30; g.fillStyle = '#d8d8d8'; g.beginPath(); g.arc(x, y, 14, 0, TAU); g.fill(); g.fillStyle = c2; g.beginPath(); g.arc(x, y, 11, 0, TAU); g.fill(); g.strokeStyle = '#ffe9a0'; g.lineWidth = 2; g.beginPath(); g.moveTo(x + 14, y); g.lineTo(x + 120 + i * 20, y - 30 + i * 10); g.stroke(); });
    g.fillStyle = 'rgba(10,14,22,.75)'; g.fillRect(20, 20, 250, 40); g.fillStyle = '#ffd257'; g.font = '700 20px ' + BODY; g.fillText('▶ ▶ ▲  궤도 정밀 포격', 34, 47);
  }
  function hint(st, seat) {
    if (!st) return null;
    if (st.ph === 'load') return ['작전 준비 — 장비·지원 요청 4개를 고르고 「출격 준비」', '은하 전선: ' + PLANETS[st.mi.pi].nm + ' · ' + MT[st.mi.mt].nm, '요청 점수 ' + st.req + '(해금) · 표본 ' + st.smp + '(함선 개량)', '지원 요청 키를 누른 채 방향키로 암호 → 클릭으로 던지기'];
    if (st.ph === 'play') return ['주 목표 → 탈출 지점에서 탈출선 부르기(E) → 버티고 타기', '지원 요청: Ctrl(또는 C)을 누른 채 방향키 암호 → 클릭(G)으로 던지기', '쓰러진 동료는 「증원」(▲▼▶◀▲)으로 다시 불러요', '아군 사격 켜짐 — 포격 표시 원 안에서 피하세요', '관통이 낮으면 「튕김」: 중장갑엔 대전차 무기·폭발물·뒤쪽 약점'];
    return null;
  }

  L.register({
    id: 'strikeforce', name: '협동 작전 부대', tag: '협동 사격 작전', cat: '협동', coop: true,
    blurb: '1~4명이 행성에 강하해 목표를 끝내고 탈출하는 위에서 보는 협동 사격 게임. 방향키 암호로 궤도 포격·폭격·포탑·지원 화기를 부르고, 아군 사격에 조심하며 은하 전선을 해방해요.',
    tint: '#3a2a14',
    icon: '<circle cx="28" cy="28" r="20" fill="none" stroke="currentColor" stroke-width="4"/><path d="M28 4v12M28 40v12M4 28h12M40 28h12" stroke="currentColor" stroke-width="4"/><circle cx="28" cy="28" r="5" fill="currentColor"/><path d="M40 10l6-6M46 10l-6-6" stroke="currentColor" stroke-width="3" opacity=".7"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 4, hidden: false, realtime: true, aiDelay: 0, landscape: true, pcOnly: true, contextMenu: true,
    save: true, mood: 'drums', ambient: 'wind', time: '15–60분', sidePanel: false,
    saveLabel: (st) => (st ? '작전 ' + Math.min(st.done + 1, st.ops) + '/' + st.ops + ' · ' + DIFF[st.dif].nm + ' · 해방 ' + st.lib.filter((v) => v >= 100).length : ''),
    options: [
      { id: 'dif', label: '난이도', tip: '적의 수·정예·대형 적 비율·증원·지원 재사용 시간이 달라져요. 높을수록 보상(요청 점수)이 커요.', choices: DIFF.map((d, i) => ({ v: i, label: d.nm })), def: 2 },
      { id: 'ops', label: '작전 수', tip: '이 판에서 치를 작전 수. 은하 전선(행성 해방도)은 저장하면 이어져요.', choices: [{ v: 1, label: '1번' }, { v: 3, label: '3번' }, { v: 5, label: '5번' }, { v: 8, label: '8번' }], def: 3 },
      { id: 'tl', label: '작전 제한 시간', tip: '시간이 끝나기 전에 주 목표를 끝내야 해요. 끝나면 지원 요청이 끊겨요.', choices: [{ v: 8, label: '8분' }, { v: 12, label: '12분' }, { v: 20, label: '20분' }], def: 12 },
    ],
    controls: [
      { id: 'up', label: '위로', keys: ['KeyW'], pad: ['ly-'] },
      { id: 'down', label: '아래로', keys: ['KeyS'], pad: ['ly+'] },
      { id: 'left', label: '왼쪽으로', keys: ['KeyA'], pad: ['lx-'] },
      { id: 'right', label: '오른쪽으로', keys: ['KeyD'], pad: ['lx+'] },
      { id: 'fire', label: '쏘기 (마우스 왼쪽)', keys: [], pad: ['rt'] },
      { id: 'ads', label: '조준 (마우스 오른쪽)', keys: [], pad: ['lt'] },
      { id: 'aimL', label: '조준 왼쪽(패드)', keys: [], pad: ['rx-'] },
      { id: 'aimR', label: '조준 오른쪽(패드)', keys: [], pad: ['rx+'] },
      { id: 'aimU', label: '조준 위(패드)', keys: [], pad: ['ry-'] },
      { id: 'aimD', label: '조준 아래(패드)', keys: [], pad: ['ry+'] },
      { id: 'reload', label: '장전', keys: ['KeyR'], pad: ['x'] },
      { id: 'sprint', label: '달리기', keys: ['ShiftLeft'], pad: ['ls'] },
      { id: 'dive', label: '다이브(몸 날리기)', keys: ['Space'], pad: ['b'] },
      { id: 'act', label: '상호작용 · 타기 · 암호 그만두기', keys: ['KeyE'], pad: ['a'] },
      { id: 'gren', label: '수류탄 · 신호기 던지기', keys: ['KeyG'], pad: ['rb'] },
      { id: 'melee', label: '근접 공격', keys: ['KeyF'], pad: ['rs'] },
      { id: 'stim', label: '치료제', keys: ['KeyV'], pad: ['y'] },
      { id: 'strat', label: '지원 요청 (누르고 있기)', keys: ['ControlLeft', 'KeyC'], pad: ['lb'] },
      { id: 'sU', label: '암호 ▲', keys: ['ArrowUp'], pad: ['up'] },
      { id: 'sD', label: '암호 ▼', keys: ['ArrowDown'], pad: ['down'] },
      { id: 'sL', label: '암호 ◀', keys: ['ArrowLeft'], pad: ['left'] },
      { id: 'sR', label: '암호 ▶', keys: ['ArrowRight'], pad: ['right'] },
      { id: 'w1', label: '주무기', keys: ['Digit1'], pad: [] },
      { id: 'w2', label: '보조 무기', keys: ['Digit2'], pad: [] },
      { id: 'w3', label: '지원 화기', keys: ['Digit3'], pad: [] },
      { id: 'swap', label: '무기 바꾸기', keys: ['KeyQ'], pad: ['back'] },
      { id: 'map', label: '큰 지도', keys: ['KeyM', 'Tab'], pad: [] },
    ],
    quick: [
      '행성에 강하해 주 목표(둥지 파괴·자료 송신·거점 사수·미사일 발사·피난민 구조·화물 호송)를 끝내요.',
      '지원 요청 키(Ctrl 또는 C)를 누른 채 방향키 암호 → 클릭으로 신호기를 던지면 포격·폭격·포탑·지원 화기가 와요.',
      '끝나면 탈출 지점에서 탈출선을 불러(E) 버티고 타요. 쓰러진 동료는 「증원」으로 다시 불러요 — 아군 사격 켜짐!',
    ],
    rules: [
      { h: '목표', p: [
        '1~4명이 한 부대예요(빈자리는 AI 대원). 은하 전선의 행성 하나를 골라 강하해서 주 목표를 끝내고, 시간 안에 탈출하면 작전 성공이에요.',
        '작전이 성공하면 그 행성의 해방도가 올라요. 100%가 되면 해방! 같은 성계의 다음 행성이 열려요. 정한 작전 수를 다 치르면 판이 끝나요.',
        '전멸(증원 0)·시간 초과·화물차 파괴·피난민을 너무 많이 잃으면 실패예요(해방도 −6%).',
      ] },
      { h: '작전 종류', p: MT.map((m) => '· ' + m.nm + ': ' + m.d(0).replace(FAC[0].hive, '둥지·공장·균열')).concat([
        '보조 목표(선택): ' + SIDE.map((s) => s.nm + ' — ' + s.d).join(' / '),
        '표본: 지도 곳곳의 초록 결정. 주워서 탈출해야 남아요(쓰러지면 그 자리에 떨어지니 동료가 주워요). 대형 적도 가끔 떨어뜨려요.',
      ]) },
      { h: '조작', p: [
        'WASD 이동 · 마우스로 조준 · 왼쪽 클릭 쏘기 · 오른쪽 클릭 조준(덜 퍼지고 멀리 봐요) · R 장전 · Shift 달리기 · Space 다이브 · E 상호작용 · G 수류탄 · F 근접 · V 치료제 · 1/2/3·Q·휠 무기 · M 큰 지도.',
        '패드: 왼스틱 이동, 오른스틱 조준, RT 쏘기, LT 조준, LB 지원 요청 + 십자키 암호.',
        '모든 키는 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '지원 요청 (암호)', p: [
        '지원 요청 키(Ctrl 또는 C)를 누르고 있으면 목록이 떠요. 그대로 방향키로 암호(예: ▶▶▲)를 넣으면 「던질 준비」가 돼요.',
        '준비되면 왼쪽 클릭(또는 G)으로 신호기를 던져요(최대 13칸). 잠시 뒤 그 자리에 도착해요. 오른쪽 클릭은 취소.',
        '장비 화면 아래 「암호 입력: 방향키 + WASD」를 켜면 지원 요청 키를 누르는 동안 WASD도 암호로 써요(그동안 멈춰 서요).',
        '각 지원 요청은 재사용 대기 시간이 있고, 항공 지원은 정해진 횟수를 쓰면 재무장(130초)해요. 작전 시간이 끝나면 지원 요청이 끊겨요.',
        '기본 두 가지는 늘 있어요: 증원(▲▼▶◀▲, 쓰러진 동료를 내려보내요 — 부대 증원 횟수를 써요), 보급품(▼▼▲▶, 탄약·수류탄·치료제).',
        '주의: 포격·폭격·투하 상자·포탑 총알·지뢰는 아군도 다쳐요. 바닥의 점선 원(위험 범위)에서 벗어나세요.',
      ] },
      { h: '무기와 장갑', p: [
        '무기마다 관통(1~5)이 있어요. 적의 장갑보다 높으면 제 피해, 같으면 65%, 하나 낮으면 12%, 더 낮으면 「튕김」(0).',
        '갑각 돌진충·방패 기계·강철 보행 전차는 뒤쪽이 약해요(장갑이 크게 줄어요). 돌진을 다이브로 피한 뒤 뒤를 쏘세요.',
        '둥지·공장·균열·통신탑은 폭발물(관통 3 이상: 수류탄·로켓·포격)로만 부서져요.',
        '지원 화기(로켓·기관총·레일건·화염방사기)는 3번 무기 칸에 들어와요. 쓰러지면 그 자리에 떨어져서 다시 주울 수 있어요.',
      ] },
      { h: '적 3진영', p: FAC.map((f) => '· ' + f.full + ': ' + f.d).concat(['적이 대원을 보고 「!」 표시가 뜨면 곧 증원을 불러요. 표시가 뜬 적을 먼저 쓰러뜨리세요. 통신탑을 부수면 증원이 줄어요.']) },
      { h: '탈출', p: [
        '주 목표를 끝내면 탈출 지점에서 E로 탈출선을 불러요. 도착까지(60초+) 적이 몰려오니 버티세요.',
        '탈출선이 내리면 원 안에 들어가 타요. 살아 있는 대원이 모두 타거나, 첫 탑승 25초 뒤 떠나요.',
      ] },
      { h: '성장 (이 판 안에서만)', p: [
        '요청 점수(작전 성공·보조 목표)로 새 지원 요청을 해금하고, 표본으로 함선을 개량해요(재사용 단축·사용 횟수·포탑 강화·증원·체력).',
        '모두 이 판(저장) 안에서만 유지돼요. 새 판은 처음부터 시작해요. 판 중 「저장하고 나가기」로 이어 할 수 있어요(혼자·방장 따로). 작전 도중 저장하면 그 작전의 장비 고르기부터 다시 해요.',
      ] },
      { h: '함께 하기 · AI', p: [
        'PC 전용 실시간 게임이라 한 기기에 한 명이에요. 혼자 하면 나머지는 AI 대원, 친구와는 온라인·LAN 방에서(빈자리는 AI).',
        'AI 대원은 사람을 따라다니며 싸우고, 쓰러진 동료를 증원으로 부르고, 보급·포격·포탑을 써요. 난이도는 자리마다 쉬움·보통·어려움(어려울수록 정확하고 아군 사격을 잘 피해요).',
      ] },
    ],
    codex: sfCodex(), preview, hint,
    init,
    actor: () => null,
    apply() { throw new Error('realtime game: no turn actions'); },
    ai: () => null,
    result, mount,
    _t: { init, newWorld, stepWorld, aiThink, missionOver, nextMission, result, snapshot, applySnap, aiLoadout, genMap, MT, DIFF, STR, EN },
  });
})();
