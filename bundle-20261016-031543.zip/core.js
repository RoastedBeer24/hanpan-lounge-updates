/* 한판 라운지 — core shell: menu, local setup, online rooms (artifact `room` capability), AI scheduling. */
(function () {
  'use strict';
  const L = (window.Lounge = { games: {}, order: [] });

  /* 일시정지용 가상 시계: 멈춘 동안 performance.now와 requestAnimationFrame 시각이 흐르지 않는다.
     실시간 게임은 시간을 rAF 시각이나 performance.now로 재면 따로 손대지 않아도 멈춘다. */
  const Clock = (() => {
    const perf = window.performance, realNow = perf.now.bind(perf);
    let pausedAt = null, offset = 0;
    try { perf.now = () => (pausedAt != null ? pausedAt : realNow()) - offset; } catch (e) { /* read-only */ }
    const rRAF = window.requestAnimationFrame.bind(window), rCAF = window.cancelAnimationFrame.bind(window);
    let nid = 1; const map = new Map();
    function queue(id, cb) {
      map.set(id, rRAF((t) => {
        if (!map.has(id)) return;
        if (pausedAt != null) { queue(id, cb); return; }   // 멈춘 동안은 다음 프레임으로 미룸
        map.delete(id); cb(t - offset);
      }));
    }
    window.requestAnimationFrame = (cb) => { const id = nid++; queue(id, cb); return id; };
    window.cancelAnimationFrame = (id) => { const r = map.get(id); if (r != null) rCAF(r); map.delete(id); };
    return {
      pause() { if (pausedAt == null) pausedAt = realNow(); },
      resume() { if (pausedAt != null) { offset += realNow() - pausedAt; pausedAt = null; } },
      get paused() { return pausedAt != null; },
    };
  })();
  L.clock = Clock;
  const COLORS = ['#ee6a55', '#5bb3e6', '#e8c04e', '#5fd3a0', '#b48cf0', '#f07fb8', '#9ad14f', '#f0a050'];
  for (let i = COLORS.length; i < 64; i++) COLORS.push('hsl(' + ((i * 47) % 360) + ',62%,' + (i % 2 ? 66 : 58) + '%)');   // 큰 인원(배틀로얄 50인 등)
  L.COLORS = COLORS;
  L.STANDALONE = !!window.LOUNGE_STANDALONE;
  L.debug = { speed: 1, log: false };
  L.register = function (def) {
    if (!L.games[def.id]) L.order.push(def.id);
    // 턴제 게임은 차례 순서를 기본 무작위로(설정에서 「자리 순서」로 바꿀 수 있음). 자리가 곧 역할인 게임은 fixedOrder: true
    if (!def.realtime && (def.maxPlayers || 1) > 1 && !def.fixedOrder && !['moles', 'wolfsheep', 'copsrobbers'].includes(def.id) && !(def.options || []).some((o) => o.id === '_order'))
      def.options = (def.options || []).concat([{ id: '_order', label: '차례 순서', choices: [{ v: 'rand', label: '무작위' }, { v: 'seat', label: '자리 순서' }], def: 'rand' }]);
    L.games[def.id] = def;
  };

  /* ---------- small utils ---------- */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') { for (const sk in v) { if (sk.startsWith('--')) el.style.setProperty(sk, v[sk]); else el.style[sk] = v[sk]; } }
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return el;
  }
  L.h = h;
  const clone = (o) => (o == null ? o : JSON.parse(JSON.stringify(o)));
  const store = {
    get(k, d) { try { const v = localStorage.getItem('lounge.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('lounge.' + k, JSON.stringify(v)); } catch (e) {} },
  };
  L.util = {
    clone, store,
    rand: (n) => Math.floor(Math.random() * n),
    shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; },
    clamp: (v, a, b) => Math.max(a, Math.min(b, v)),
    lerp: (a, b, t) => a + (b - a) * t,
    /* Canvas that fills `root`, DPR-aware. ctx is pre-scaled to CSS pixels. */
    canvas(root) {
      const cv = h('canvas', { class: 'gcanvas' });
      root.appendChild(cv);
      const ctx = cv.getContext('2d');
      const o = { cv, ctx, w: 1, h: 1, dpr: 1, onresize: null };
      function fit() {
        const r = root.getBoundingClientRect();
        const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
        const w = Math.max(1, Math.round(r.width)), hh = Math.max(1, Math.round(r.height));
        if (w === o.w && hh === o.h && dpr === o.dpr) return;
        o.w = w; o.h = hh; o.dpr = dpr;
        cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        if (o.onresize) o.onresize();
      }
      const ro = new ResizeObserver(fit); ro.observe(root); fit();
      o.fit = fit;
      o.local = (ev) => { const r = cv.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
      o.clear = () => { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height); ctx.setTransform(o.dpr, 0, 0, o.dpr, 0, 0); };
      o.destroy = () => { ro.disconnect(); cv.remove(); };
      return o;
    },
    /* requestAnimationFrame loop; fn(dtSeconds, nowMs). Returns stop(). */
    loop(fn) {
      let on = true, last = performance.now();
      function f(t) { if (!on) return; const dt = Math.max(0, Math.min(0.05, (t - last) / 1000)); last = t; fn(dt, t); if (on) requestAnimationFrame(f); }
      requestAnimationFrame(f);
      return () => { on = false; };
    },
  };

  /* ---------- sound (tiny synth) ---------- */
  const Sfx = {
    ac: null, on: store.get('sound', true),
    play(name) {
      if (!this.on) return;
      try {
        if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)();
        const ac = this.ac, t = ac.currentTime;
        const P = {
          tick: [880, 0.03, 'square', 0.04], card: [320, 0.06, 'triangle', 0.12, 180], chip: [1400, 0.05, 'square', 0.05, 2200],
          hit: [180, 0.08, 'sine', 0.25, 90], bounce: [520, 0.04, 'sine', 0.1], roll: [240, 0.05, 'square', 0.05, 400],
          win: [523, 0.12, 'triangle', 0.18, 1046], lose: [300, 0.25, 'sawtooth', 0.07, 120], click: [660, 0.02, 'square', 0.04],
          thud: [90, 0.12, 'sine', 0.3, 50], pop: [700, 0.05, 'sine', 0.15, 1200], whoosh: [200, 0.15, 'sawtooth', 0.05, 900],
        }[name] || [440, 0.05, 'sine', 0.1];
        const [f, d, type, vol, f2] = P;
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = type; o.frequency.setValueAtTime(f, t);
        if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
        g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.02);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + d + 0.03);
      } catch (e) {}
    },
  };
  L.sfx = (n) => Sfx.play(n);
  function buzz(ms) { if (store.get('buzz', true) === false) return; try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} }

  /* ---------- menu art ---------- */
  const TINT = {
    blackjack: '#1c5a47', holdem: '#6a2430', snakes: '#6b5418', darts: '#3d2a55',
    pool: '#16525c', golf: '#3f6a22', chess: '#3a3550', racing: '#6a3a1c',
  };
  const NEW_GAMES = ['dodgeball', 'bridge', 'hockey', 'swarm', 'cauldron', 'crowdthief', 'subdive', 'zombie', 'planets', 'waterbomb', 'royale', 'raid', 'caravan', 'crew', 'dungeon', 'isletrade', 'robobattle', 'monster', 'band', 'ctf', 'claw'];
  const CAT_ORDER = ['카드', '보드', '스포츠', '아케이드', '파티'];
  const CAT = { blackjack: '카드', holdem: '카드', onecard: '카드', snakes: '보드', chess: '보드', yut: '보드', gomoku: '보드', yacht: '보드',
    darts: '스포츠', pool: '스포츠', golf: '스포츠', bowling: '스포츠', pingpong: '스포츠', racing: '아케이드', airhockey: '아케이드', blocks: '아케이드',
    janggi: '보드', baduk: '보드', tiles: '보드', curling: '스포츠', fingersoccer: '스포츠', sudoku: '보드', gostop: '카드', basketball: '스포츠', archery: '스포츠', jenga: '파티', diamond: '보드', breakout: '아케이드', landgrab: '보드', oldmaid: '카드', penalty: '스포츠', batting: '스포츠', skijump: '스포츠', worm: '아케이드', sumo: '아케이드', wallmaze: '보드', blockclaim: '보드', clay: '스포츠', fishing: '스포츠', horserace: '파티', spaceshoot: '아케이드', ladder: '파티', wheel: '파티', auction: '파티', copsrobbers: '보드', bomb: '파티', domino: '스포츠', tugwar: '파티', trade: '보드', treasure: '보드', stack: '파티', drawing: '파티', reaction: '파티', bingo: '파티' };
  Object.assign(TINT, { yut: '#6b3a2a', onecard: '#2d4f6b', yacht: '#5a2d5e', drawing: '#2e5a4a', gomoku: '#6b5a2a', reaction: '#7a2d3a' });
  const ICON = {
    blackjack: '<rect x="8" y="10" width="24" height="34" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><rect x="22" y="14" width="24" height="34" rx="3" fill="currentColor" opacity=".9"/><text x="34" y="37" font-size="13" font-weight="700" text-anchor="middle" fill="#1c5a47" font-family="sans-serif">21</text>',
    holdem: '<circle cx="20" cy="34" r="12" fill="none" stroke="currentColor" stroke-width="3" stroke-dasharray="4 3"/><circle cx="20" cy="34" r="5" fill="currentColor"/><path d="M34 10l10 10-10 14-10-14z" fill="currentColor"/>',
    snakes: '<path d="M14 8v40M26 8v40M14 16h12M14 28h12M14 40h12" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M44 10c-10 4 6 12-4 18s4 12-6 18" stroke="currentColor" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="44" cy="10" r="3" fill="currentColor"/>',
    darts: '<circle cx="28" cy="28" r="20" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="12" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="28" cy="28" r="4" fill="currentColor"/><path d="M28 28L48 8M42 6l6 2 2 6" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/>',
    pool: '<circle cx="20" cy="34" r="11" fill="currentColor"/><circle cx="20" cy="34" r="5" fill="#16525c"/><text x="20" y="37.5" font-size="8" font-weight="700" text-anchor="middle" fill="currentColor" font-family="sans-serif">8</text><circle cx="40" cy="22" r="8" fill="none" stroke="currentColor" stroke-width="3"/><path d="M6 52L50 6" stroke="currentColor" stroke-width="2" opacity=".5"/>',
    golf: '<path d="M22 46V8l18 7-18 7" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><ellipse cx="22" cy="47" rx="14" ry="4" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="42" cy="44" r="4" fill="currentColor"/>',
    chess: '<path d="M18 48h22l-3-6H21zM22 42l2-16h10l2 16M20 26h18M29 8v6M26 11h6M24 22c-3-3-1-8 5-8s8 5 5 8z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>',
    yut: '<g fill="currentColor"><rect x="9" y="8" width="7" height="40" rx="3.5" transform="rotate(-12 12 28)"/><rect x="20" y="8" width="7" height="40" rx="3.5" opacity=".55" transform="rotate(-4 23 28)"/><rect x="31" y="8" width="7" height="40" rx="3.5" transform="rotate(4 34 28)"/><rect x="42" y="8" width="7" height="40" rx="3.5" opacity=".55" transform="rotate(12 45 28)"/></g>',
    onecard: '<rect x="10" y="12" width="22" height="32" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-10 21 28)"/><rect x="24" y="10" width="22" height="32" rx="3" fill="currentColor"/><text x="35" y="31" font-size="14" font-weight="700" text-anchor="middle" fill="#2d4f6b" font-family="sans-serif">1</text>',
    yacht: '<rect x="7" y="18" width="22" height="22" rx="5" fill="currentColor"/><g fill="#5a2d5e"><circle cx="13" cy="24" r="2.4"/><circle cx="23" cy="34" r="2.4"/><circle cx="18" cy="29" r="2.4"/></g><rect x="30" y="10" width="20" height="20" rx="5" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(14 40 20)"/><circle cx="40" cy="20" r="2.4" fill="currentColor"/>',
    drawing: '<path d="M10 44c6-10 12-4 16-12s10-14 20-16" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M36 38l10-10 4 4-10 10-6 2z" fill="currentColor"/><circle cx="14" cy="14" r="5" fill="none" stroke="currentColor" stroke-width="3"/>',
    gomoku: '<path d="M8 14h40M8 24h40M8 34h40M8 44h40M14 8v40M24 8v40M34 8v40M44 8v40" stroke="currentColor" stroke-width="1.5" opacity=".5"/><circle cx="24" cy="24" r="5" fill="currentColor"/><circle cx="34" cy="34" r="5" fill="currentColor"/><circle cx="34" cy="24" r="5" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="14" cy="14" r="5" fill="currentColor"/>',
    reaction: '<path d="M30 6L14 32h12l-4 18 20-28H30z" fill="currentColor"/>',
    racing: '<path d="M8 36l4-10h22l8 6h6v8H8z" fill="currentColor"/><circle cx="17" cy="41" r="5" fill="#6a3a1c" stroke="currentColor" stroke-width="3"/><circle cx="40" cy="41" r="5" fill="#6a3a1c" stroke="currentColor" stroke-width="3"/><path d="M4 18h14M10 12h14" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
  };

  /* ---------- app shell ---------- */
  const app = document.getElementById('app');
  let screenEl = null;
  function show(el) { if (screenEl) screenEl.remove(); screenEl = el; app.appendChild(el); }
  function toast(text, ms) {
    const t = h('div', { class: 'toast', text });
    app.appendChild(t);
    setTimeout(() => t.remove(), ms || 1800);
  }
  L.toast = toast;
  function overlay(content, opts) {
    const o = h('div', { class: 'overlay' + (opts && opts.cls ? ' ' + opts.cls : ''), 'data-core': '1' }, content);
    (opts && opts.parent || app).appendChild(o);
    return o;
  }
  function confirmSheet(title, body, okText, onOk) {
    const o = overlay(h('div', { class: 'sheet' },
      h('h2', { text: title }), body ? h('p', { class: 'muted', style: { margin: 0 }, text: body }) : null,
      h('div', { class: 'row', style: { justifyContent: 'flex-end' } },
        h('button', { class: 'btn ghost', text: '취소', onclick: () => o.remove() }),
        h('button', { class: 'btn danger', text: okText, onclick: () => { o.remove(); onOk(); } }))));
    setTimeout(() => { const b = o.querySelector('.btn.danger'); if (b && matchMedia('(pointer:fine)').matches) b.focus(); }, 30);
  }

  /* rules sheet — game defs provide rules: [{h, p:[...]}] */
  function rulesSheet(id, parent) {
    const g = L.games[id];
    const pausedHere = !!(S && S.gameId === id && typeof canPause === 'function' && canPause() && !Clock.paused);
    if (pausedHere) setPaused(true);   // 혼자 하는 실시간 판: 규칙 보는 동안 멈춤
    const close = () => { o.remove(); if (pausedHere) setPaused(false); if (S) scheduleAI(); };
    const body = h('div', { class: 'rules' },
      g.blurb ? h('p', { class: 'lead', text: g.blurb }) : null,
      g.codex ? h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, text: '📖 도감 열기', onclick() { o.remove(); codexSheet(id, parent); } }) : null,
      g.quick && g.quick.length ? h('ol', { class: 'quick' }, g.quick.map((t) => h('li', { text: t }))) : null,
      g.tutorial && g.tutorial.length && S && S.gameId === id ? h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, text: '▶ 따라 하며 배우기 (안내 다시 보기)', onclick() { o.remove(); runTutorial(g, true); } }) : null,
      (g.rules || []).map((sec) => h('section', null, h('h3', { text: sec.h }), h('ul', null, sec.p.map((t) => h('li', { text: t }))))),
      g.controls && g.controls.length ? h('section', null, h('h3', { text: '키보드 · 게임패드' }),
        h('ul', null, Controls.bindings(g).map((b) => h('li', { text: b.label + ' — ' + (b.keys.map(keyLabel).concat(b.pad.map((n) => PAD_NAME[n] || n)).join(' / ') || '없음') }))),
        h('button', { class: 'btn sm', text: '조작 바꾸기', onclick() { o.remove(); controlsSheet(id, parent, () => rulesSheet(id, parent)); } })) : null);
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '규칙' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      body,
      h('button', { class: 'btn block', text: '닫기', onclick: close })), { cls: 'rules-ov', parent: parent || app });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.rules = rulesSheet;

  /* 도감(codex): def.codex = [{ h: '탭 이름', p?: ['설명 줄'], rows?: [{ icon?: '이모지|SVG 문자열', name, tag?, desc }] }]
     또는 def.codex = function (el, ctx) { ... el에 직접 그림 ... }  (ctx.close() 로 닫기). 게임 시작 전·중 모두 열 수 있음. */
  function codexSheet(id, parent) {
    const g = L.games[id];
    if (!g || !g.codex) return null;
    const close = () => { o.remove(); if (S) scheduleAI(); };
    const body = h('div', { class: 'rules codex' });
    let o;
    if (typeof g.codex === 'function') {
      try { g.codex(body, { close: () => close(), inGame: !!(S && S.gameId === id) }); } catch (e) { console.error(e); body.append(h('p', { text: '도감을 여는 중 문제가 생겼어요' })); }
    } else {
      const secs = g.codex;
      const tabs = h('div', { class: 'chips' });
      const pane = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
      const show = (k) => {
        pane.innerHTML = '';
        [...tabs.children].forEach((b, i) => b.classList.toggle('on', i === k));
        const sec = secs[k];
        (sec.p || []).forEach((t) => pane.append(h('p', { class: 'note', style: { margin: 0 }, text: t })));
        (sec.rows || []).forEach((r) => {
          const ic = h('span', { class: 'cx-ic' });
          if (r.icon && /^\s*</.test(r.icon)) ic.innerHTML = r.icon; else ic.textContent = r.icon || '•';
          pane.append(h('div', { class: 'cx-row' }, ic, h('div', { class: 'cx-tx' },
            h('div', { class: 'cx-nm' }, h('b', { text: r.name }), r.tag ? h('span', { class: 'cx-tag', text: r.tag }) : null),
            r.desc ? h('div', { class: 'cx-d', text: r.desc }) : null)));
        });
        pane.scrollTop = 0;
      };
      secs.forEach((sec, k) => tabs.append(h('button', { class: 'btn sm', text: sec.h + (sec.rows ? ' ' + sec.rows.length : ''), onclick: () => show(k) })));
      if (secs.length > 1) body.append(tabs);
      body.append(pane);
      if (secs.length) show(0);
    }
    o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '📖 도감' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      body,
      h('button', { class: 'btn block', text: '닫기', onclick: close })), { cls: 'rules-ov', parent: parent || app });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    return o;
  }
  L.codex = codexSheet;

  function myName() { return store.get('name', '') || ''; }
  /* per-bot difficulty: 1 쉬움, 2 보통, 3 어려움 */
  const LV = { 1: '쉬움', 2: '보통', 3: '어려움' };
  L.AI_LEVELS = LV;
  function lvChip(lv, onChange) {
    const v = lv || 2;
    return h('button', { class: 'lvchip lv' + v, type: 'button', 'aria-label': 'AI 난이도 ' + LV[v] + ', 눌러서 바꾸기', text: LV[v],
      onclick(e) { e.stopPropagation(); onChange(v % 3 + 1); Sfx.play('click'); } });
  }
  /* actor(state) may return one seat, an array of seats acting at once, or null */
  function actorsOf(def, st) { if (!st) return []; const a = def.actor(st); return a == null ? [] : Array.isArray(a) ? a : [a]; }
  L.actorsOf = actorsOf;
  /* game options: def.options = [{id, label, choices:[{v, label}], def}] */
  function shuffleOrder(def, opts, arr) {   // 차례 순서 무작위: 자리를 섞는다(색은 사람을 따라감)
    if (!opts || opts._order !== 'rand' || arr.length < 2) return arr;
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
  function orderToast(players) {
    if (players.length > 1) setTimeout(() => toast('차례 순서: ' + players.map((p) => p.name).join(' → ')), 300);
  }
  // 옵션에 따라 최대 인원이 달라지는 게임: def.maxPlayersIf(opts) (예: 펭귄 실시간 8명, 차례대로 4명)
  function maxFor(g, opts) { const m = g.maxPlayersIf ? g.maxPlayersIf(opts || optDefaults(g, null)) : 0; return m ? Math.min(g.maxPlayers, m) : g.maxPlayers; }
  function optDefaults(def, saved) {
    const o = {};
    (def.options || []).forEach((op) => {
      const sv = saved && saved[op.id];
      o[op.id] = op.choices.some((c) => c.v === sv) ? sv : op.def != null ? op.def : op.choices[0].v;
    });
    return o;
  }
  function optRows(def, opts, onChange, readOnly) {
    if (!def.options || !def.options.length) return null;
    return h('div', { class: 'opts' }, def.options.map((op) => h('div', { class: 'field' },
      h('span', { class: 'label', text: op.label }),
      h('div', { class: 'chips wrap' }, op.choices.map((c) => h('button', {
        class: 'btn sm' + (opts[op.id] === c.v ? ' on' : ''), text: c.label, disabled: readOnly && opts[op.id] !== c.v ? true : null,
        onclick() { if (readOnly) return; opts[op.id] = c.v; onChange(); },
      }))))));
  }

  /* ---------- game browser: 홈 목록 + 온라인 방 「게임 고르기」 (검색 · 인원 · 방식 · 분류 · 정렬 · 보기) ---------- */
  const catOf = (id) => L.games[id].cat || CAT[id] || '기타';
  const rangeOf = (g) => (g.minPlayers === g.maxPlayers ? g.minPlayers + '인' : g.minPlayers + '–' + g.maxPlayers + '인');
  const normK = (t) => (t || '').toLowerCase().replace(/[\s·:,.!?()\-]+/g, '');
  // 초성 검색: 「ㅂㅌㄹ」 → 배틀로얄
  const CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ';
  const choOf = (t) => [...t].map((c) => { const k = c.charCodeAt(0) - 0xac00; return k >= 0 && k < 11172 ? CHO[Math.floor(k / 588)] : c; }).join('');
  const isCho = (q) => /^[ㄱ-ㅎ]+$/.test(q);
  const hit = (text, q) => { const n = normK(text); return !!q && (n.includes(q) || (isCho(q) && choOf(n).includes(q))); };
  const isCoop = (g) => !!(g.coop || /협동|협력/.test(g.name + ' ' + (g.tag || '')) || (g.options || []).some((o) => o.choices.some((c) => /협동/.test(String(c.label)))));
  const KINDS = [
    { v: 'pass', label: '한 폰 돌려하기', test: (g) => g.maxPlayers >= 2 && (!g.realtime || !!g.localMulti) },
    { v: 'rt', label: '실시간', test: (g) => !!(g.realtime || g.realtimeIf) },
    { v: 'turn', label: '차례대로', test: (g) => !g.realtime },
    { v: 'coop', label: '협동', test: isCoop },
  ];
  const SORTS = [{ v: 'cat', label: '분류별' }, { v: 'name', label: '이름순' }, { v: 'new', label: '새로 나온 순' }, { v: 'many', label: '인원 많은 순' }];
  const PEOPLE = [1, 2, 3, 4, 5];
  // 지금 n명이 할 수 있나: 사람 n명 ≤ 최대 인원, 사람만 하는 게임(noAI)은 최소 인원도 채워야 함(나머지 자리는 AI)
  const fitsPeople = (g, n) => n <= g.maxPlayers && (!g.noAI || n >= g.minPlayers);
  const homeSess = { people: 0, kind: '' };   // 인원·방식 필터는 앱을 켜 둔 동안만 기억(다음 실행 땐 전체 목록부터)
  let homeIO = null;
  const SVG_GRID = '<svg viewBox="0 0 20 20" aria-hidden="true"><g fill="currentColor"><rect x="2" y="2" width="7" height="7" rx="1.5"/><rect x="11" y="2" width="7" height="7" rx="1.5"/><rect x="2" y="11" width="7" height="7" rx="1.5"/><rect x="11" y="11" width="7" height="7" rx="1.5"/></g></svg>';
  const SVG_LIST = '<svg viewBox="0 0 20 20" aria-hidden="true"><g fill="currentColor"><rect x="2" y="3" width="4" height="4" rx="1"/><rect x="8" y="4" width="10" height="2" rx="1"/><rect x="2" y="8" width="4" height="4" rx="1"/><rect x="8" y="9" width="10" height="2" rx="1"/><rect x="2" y="13" width="4" height="4" rx="1"/><rect x="8" y="14" width="10" height="2" rx="1"/></g></svg>';

  /* cfg: { st:{cat,people,kind,sort,view,q}, save(st), onPick(id), fits(g)→bool (false = 흐리게), current, fold:Set, saveFold(), scroller(), views:bool, ioOut(io) } */
  function gameBrowser(cfg) {
    const st = cfg.st;
    const favs = () => store.get('favs', []).filter((id) => L.games[id]);
    const groups = {};
    const idx = {};
    L.order.forEach((id, i) => { idx[id] = i; const c = catOf(id); (groups[c] = groups[c] || []).push(id); });
    const cats = CAT_ORDER.concat(Object.keys(groups).filter((c) => !CAT_ORDER.includes(c))).filter((c) => groups[c]);
    if (st.cat !== '전체' && st.cat !== '즐겨찾기' && !groups[st.cat]) st.cat = '전체';
    const io = 'IntersectionObserver' in window ? new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) { io.unobserve(e.target); fillIcon(e.target); }
    }), { rootMargin: '400px 0px' }) : null;
    if (cfg.ioOut) cfg.ioOut(io);
    function fillIcon(s) { const id = s.getAttribute('data-icon'); if (id) { s.removeAttribute('data-icon'); s.innerHTML = (L.games[id] && L.games[id].icon) || ICON[id] || '<circle cx="28" cy="28" r="18" fill="currentColor"/>'; } }
    function lazyIcon(id) {   // 아이콘 SVG는 화면 근처에 올 때만 그린다(130개 첫 표시를 가볍게)
      const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      s.setAttribute('viewBox', '0 0 56 56'); s.setAttribute('class', 'ico'); s.setAttribute('aria-hidden', 'true'); s.setAttribute('data-icon', id);
      if (io) io.observe(s); else fillIcon(s);
      return s;
    }
    function pills(g) {
      return [g.realtime ? h('span', { class: 'kp rt', text: '실시간' }) : null, isCoop(g) ? h('span', { class: 'kp co', text: '협동' }) : null];
    }
    const cache = new Map();   // 타일/줄은 한 번만 만들고 다시 쓴다(검색 입력마다 새로 만들지 않음)
    function item(id, view) {
      const k = view + ':' + id;
      let el = cache.get(k);
      if (el) return el;
      const g = L.games[id], isNew = NEW_GAMES.includes(id);
      const tag = (g.tag || '').replace(g.realtime ? /^실시간\s*/ : /^$/, '').replace(isCoop(g) ? /^협동\s*/ : /^$/, '');
      if (view === 'grid') {
        el = h('button', { class: 'tile' + (isNew ? ' has-new' : ''), type: 'button', style: { '--tint': g.tint || TINT[id] || 'var(--surface)' }, 'aria-label': g.name + ' — ' + rangeOf(g) + (g.tag ? ', ' + g.tag : '') },
          h('div', { class: 'tg' }, pills(g), h('span', { text: rangeOf(g) + (tag ? ' · ' + tag : '') })),
          lazyIcon(id), h('div', { class: 'nm', text: g.name }),
          isNew ? h('span', { class: 'badge-new', text: 'NEW' }) : null,
          h('span', { class: 'badge-fav', 'aria-hidden': 'true', text: '★' }));
      } else {
        el = h('button', { class: 'gamerow', type: 'button', style: { '--tint': g.tint || TINT[id] || 'var(--surface-2)' }, 'aria-label': g.name + ' — ' + rangeOf(g) + (g.tag ? ', ' + g.tag : '') },
          lazyIcon(id),
          h('span', { class: 'gr-main' },
            h('span', { class: 'gr-nm' }, h('span', { class: 'gr-t', text: g.name }), isNew ? h('span', { class: 'nb', text: 'NEW' }) : null),
            h('span', { class: 'gr-meta' }, h('span', { class: 'rg', text: rangeOf(g) }), h('span', { class: 'gr-over', text: '인원 안 맞음' }), pills(g),
              h('span', { class: 'bl', text: g.blurb || g.tag || '' }))),
          h('span', { class: 'gr-fav', 'aria-hidden': 'true', text: '★' }));
      }
      el.dataset.id = id;
      cache.set(k, el);
      return el;
    }
    function pass(id, q) {
      const g = L.games[id];
      if (st.people && !fitsPeople(g, st.people)) return false;
      if (st.kind) { const k = KINDS.find((x) => x.v === st.kind); if (k && !k.test(g)) return false; }
      if (q && !(hit(g.name, q) || hit(g.tag, q) || hit(g.blurb, q) || normK(catOf(id)) === q || hit(id, q))) return false;
      return true;
    }
    function sorted(ids, q) {
      const a = ids.slice(), nm = (id) => L.games[id].name;
      if (st.sort === 'name') a.sort((x, y) => nm(x).localeCompare(nm(y), 'ko'));
      else if (st.sort === 'new') a.sort((x, y) => (NEW_GAMES.includes(y) - NEW_GAMES.includes(x)) || idx[y] - idx[x]);
      else if (st.sort === 'many') a.sort((x, y) => L.games[y].maxPlayers - L.games[x].maxPlayers || L.games[x].minPlayers - L.games[y].minPlayers || nm(x).localeCompare(nm(y), 'ko'));
      else if (q) {   // 분류별 + 검색: 이름이 검색어로 시작 → 이름에 포함 → 소개에만 있음
        const rank = (id) => { const n = normK(nm(id)), c = isCho(q) ? choOf(n) : n; return c.startsWith(q) ? 0 : c.includes(q) ? 1 : 2; };
        a.sort((x, y) => rank(x) - rank(y) || cats.indexOf(catOf(x)) - cats.indexOf(catOf(y)) || idx[x] - idx[y]);
      }
      return a;
    }

    /* ----- 위쪽 막대(검색 · 필터 · 보기 · 분류) ----- */
    const search = h('input', {
      class: 'home-search', type: 'search', placeholder: '게임 찾기 (' + L.order.length + '종)', 'aria-label': '게임 찾기', enterkeyhint: 'search', autocomplete: 'off',
      oninput(e) { st.q = e.target.value; schedule(true); },
      oncompositionupdate(e) { st.q = e.target.value; schedule(true); },   // 한글 입력 중(조합 중)에도 바로 찾기
      oncompositionend(e) { st.q = e.target.value; schedule(true); },
      onkeydown(e) { if (e.key === 'Enter') e.target.blur(); },
    });
    search.value = st.q || '';
    const fN = h('span', { class: 'fb-n', hidden: true });
    const fBtn = h('button', { class: 'btn fb-btn', type: 'button', 'aria-expanded': 'false', 'aria-label': '인원 · 방식 · 정렬', onclick() { setPanel(panel.hidden); Sfx.play('click'); } }, '필터', fN);
    const vBtn = cfg.views ? h('button', { class: 'btn fb-btn fb-view', type: 'button', onclick() {
      st.view = st.view === 'grid' ? 'list' : 'grid'; cfg.save(st); Sfx.play('click'); render(); } }) : null;
    function chipRow(label, items, cur, onTap) {
      return h('div', { class: 'fb-row', role: 'group', 'aria-label': label }, h('span', { class: 'fb-l', text: label }),
        h('div', { class: 'chips' }, items.map((it) => h('button', {
          class: 'btn sm' + (it.v === cur ? ' on' : ''), type: 'button', 'aria-pressed': String(it.v === cur), 'data-v': String(it.v), text: it.label,
          onclick() { onTap(it.v); Sfx.play('click'); },
        }))));
    }
    const panel = h('div', { class: 'fb-panel', hidden: true });
    function drawPanel() {
      panel.textContent = '';
      const big = st.people >= 5 ? st.people : 5;
      panel.append(
        chipRow('인원', PEOPLE.map((n) => ({ v: n === 5 ? big : n, label: n === 5 ? (st.people > 5 ? st.people + '명' : '5–8명') : n + '명' })), st.people,
          (v) => { st.people = st.people === v ? 0 : v; changed(); }),
        chipRow('방식', KINDS, st.kind, (v) => { st.kind = st.kind === v ? '' : v; changed(); }),
        chipRow('정렬', SORTS, st.sort, (v) => { st.sort = v; changed(); }));
    }
    let openTop = 0, quietUntil = 0;
    function setPanel(open) {
      panel.hidden = !open; fBtn.setAttribute('aria-expanded', String(open)); fBtn.classList.toggle('on', open);
      if (open) { drawPanel(); const sc = cfg.scroller && cfg.scroller(); openTop = sc ? sc.scrollTop : 0; quietUntil = performance.now() + 250; }
    }
    const catChips = h('div', { class: 'chips home-chips', role: 'group', 'aria-label': '분류' },
      ['전체', '즐겨찾기'].concat(cats).map((c) => h('button', {
        class: 'btn sm', type: 'button', 'data-f': c, text: c === '즐겨찾기' ? '★ 즐겨찾기' : c,
        onclick() { st.cat = c; Sfx.play('click'); changed(); },
      })));
    const sumTxt = h('span', { class: 'txt', 'aria-live': 'polite' });
    const sum = h('div', { class: 'fb-sum', hidden: true }, sumTxt,
      h('button', { class: 'btn sm fb-clear', type: 'button', text: '✕ 모두 지우기', onclick() {
        st.people = 0; st.kind = ''; st.q = ''; st.cat = '전체'; search.value = ''; Sfx.play('click'); changed();
      } }));
    const bar = h('div', { class: 'home-find' }, h('div', { class: 'fb-top' }, search, fBtn, vBtn), panel, catChips);   // 결과 요약(sum)은 막대 밖 — 작은 화면에서 붙어 다니는 높이를 줄임
    const list = h('div', { class: 'groups' });

    /* 목록 클릭(위임): 게임 고르기 / 분류 접기 */
    list.addEventListener('click', (e) => {
      const fh = e.target.closest('[data-fold]');
      if (fh) {
        const k = fh.getAttribute('data-fold'), open = cfg.fold.has(k);
        if (open) cfg.fold.delete(k); else cfg.fold.add(k);
        cfg.saveFold && cfg.saveFold();
        fh.setAttribute('aria-expanded', String(open)); fh.parentNode.classList.toggle('folded', !open);
        Sfx.play('click'); return;
      }
      const b = e.target.closest('[data-id]');
      if (b && !b.disabled) cfg.onPick(b.dataset.id);
    });

    function changed() { cfg.save(st); if (!panel.hidden) drawPanel(); schedule(false); }
    let raf = 0, keepScroll = true;
    function schedule(fromTyping) { if (!fromTyping) keepScroll = false; if (!raf) raf = requestAnimationFrame(() => { raf = 0; render(); }); }
    function render() {
      const q = normK(st.q);
      const fv = favs(), view = cfg.views ? st.view : 'list';
      if (vBtn) { vBtn.innerHTML = view === 'grid' ? SVG_LIST : SVG_GRID; vBtn.setAttribute('aria-label', view === 'grid' ? '촘촘한 목록으로 보기' : '큰 타일로 보기'); vBtn.title = vBtn.getAttribute('aria-label'); }
      catChips.querySelectorAll('.btn').forEach((b) => { const on = b.dataset.f === st.cat; b.classList.toggle('on', on); b.setAttribute('aria-pressed', String(on)); });
      const base = st.cat === '즐겨찾기' ? fv : st.cat === '전체' ? L.order : groups[st.cat] || [];
      const ids = base.filter((id) => pass(id, q));
      const nf = (st.people ? 1 : 0) + (st.kind ? 1 : 0) + (st.sort !== 'cat' ? 1 : 0);
      fN.hidden = !nf; fN.textContent = nf;
      const active = !!(st.people || st.kind || q || st.cat !== '전체');
      sum.hidden = !active;
      if (active) {
        const bits = [st.cat !== '전체' ? (st.cat === '즐겨찾기' ? '★' : st.cat) : null, st.people ? (st.people === 5 ? '5명 이상' : st.people + '명') : null,
          st.kind ? KINDS.find((k) => k.v === st.kind).label : null, q ? '“' + st.q.trim() + '”' : null].filter(Boolean);
        sumTxt.textContent = ''; sumTxt.append(h('b', { text: ids.length + '개' }), ' · ' + bits.join(' · '));
      }
      const frag = document.createDocumentFragment();
      function section(title, sids, foldKey) {
        if (!sids.length) return;
        const grid = h('div', { class: view === 'grid' ? 'tiles' : 'glist' });
        sids.forEach((id) => {
          const el = item(id, view);
          el.classList.toggle('is-fav', fv.includes(id));
          if (cfg.fits) { const ok = cfg.fits(L.games[id]); el.disabled = !ok; el.classList.toggle('on', id === cfg.current); }
          grid.append(el);
        });
        const folded = !!foldKey && cfg.fold.has(foldKey);
        const head = foldKey
          ? h('button', { class: 'group-h group-hb', type: 'button', 'data-fold': foldKey, 'aria-expanded': String(!folded) },
            h('span', { text: title }), h('span', { class: 'gh-n', text: sids.length }), h('span', { class: 'gh-chev', 'aria-hidden': 'true', text: '›' }))
          : h('h3', { class: 'group-h' }, h('span', { text: title }), h('span', { class: 'gh-n', text: sids.length }));
        frag.append(h('div', { class: 'group' + (folded ? ' folded' : '') + (foldKey === 'favs' ? ' favs' : '') }, head, grid));
      }
      if (!ids.length) {
        frag.append(h('div', { class: 'note empty' },
          h('p', { style: { margin: '0 0 10px' }, text: st.cat === '즐겨찾기' && !fv.length ? '게임 설정 화면의 ☆를 누르면 여기에 모여요.' : '조건에 맞는 게임이 없어요.' }),
          active ? h('button', { class: 'btn sm', type: 'button', text: '✕ 모두 지우기', onclick: () => sum.querySelector('.fb-clear').click() }) : null));
      } else if (st.sort === 'cat' && !q && st.cat !== '즐겨찾기') {
        if (st.cat === '전체') section('★ 즐겨찾기', fv.filter((id) => pass(id, q)), 'favs');
        cats.forEach((c) => { if (st.cat === '전체' || st.cat === c) section(c, ids.filter((id) => catOf(id) === c), 'c:' + c); });
      } else {
        const t = q ? '검색 결과' : st.cat === '즐겨찾기' ? '즐겨찾기' : SORTS.find((s) => s.v === st.sort).label;
        section(t, sorted(ids, q));
      }
      list.textContent = '';
      list.append(frag);
      // 필터를 바꿨으면 결과 맨 위가 보이게(막대 바로 아래부터)
      const sc = cfg.scroller && cfg.scroller();
      if (sc && !keepScroll) {
        const top = Math.max(0, (sum.hidden ? list : sum).offsetTop - bar.offsetHeight - 12);
        if (sc.scrollTop > top) sc.scrollTop = top;
        openTop = sc.scrollTop; quietUntil = performance.now() + 120;
      }
      keepScroll = true;
    }
    // 필터 칸을 연 채로 목록을 내리면 접는다(작은 화면에서 칸을 오래 차지하지 않게)
    function onScroll() {
      if (panel.hidden || performance.now() < quietUntil) return;
      const sc = cfg.scroller(); if (sc && Math.abs(sc.scrollTop - openTop) > 90) setPanel(false);
    }
    return { bar, sum, list, search, render, onScroll, setPanel };
  }

  function homeScreen() {
    document.title = '한판 라운지';
    endSession();
    Net.leave();
    if (homeIO) homeIO.disconnect();
    const st = { cat: store.get('homeFilter', '전체'), people: homeSess.people, kind: homeSess.kind, q: '',
      sort: SORTS.some((s) => s.v === store.get('home.sort', 'cat')) ? store.get('home.sort', 'cat') : 'cat',
      view: store.get('home.view', 'grid') === 'list' ? 'list' : 'grid' };
    const fold = new Set(store.get('home.fold', []));
    let scrollEl = null;
    const B = gameBrowser({
      st, views: true, fold,
      save(s) { store.set('homeFilter', s.cat); store.set('home.sort', s.sort); store.set('home.view', s.view); homeSess.people = s.people; homeSess.kind = s.kind; },
      saveFold() { store.set('home.fold', [...fold]); },
      onPick: (id) => setupSheet(id, () => B.render()),
      scroller: () => scrollEl,
      ioOut: (io) => { homeIO = io; },
    });
    scrollEl = h('div', { class: 'scroll', onscroll: () => B.onScroll() },
      h('div', { class: 'brand' },
        h('h1', { html: '한판<span>.</span>라운지' }),
        h('p', { text: '한 폰으로 돌려하거나, 방을 만들어 각자 폰으로.' })),
      h('div', { class: 'online-bar' },
        h('button', { class: 'btn primary', text: '온라인 방 만들기', onclick: () => hostLobby() }),
        h('button', { class: 'btn', text: '코드로 참가', onclick: () => joinScreen() })),
      L.STANDALONE && window.RTCPeerConnection ? h('div', { class: 'online-bar lan' },
        h('button', { class: 'btn', text: 'LAN 방 만들기', onclick: () => hostLobby(false, true) }),
        h('button', { class: 'btn', text: 'LAN 참가', onclick: () => lanJoinScreen() }),
        h('p', { class: 'note', text: '같은 와이파이에서 인터넷 없이 QR로 연결해요.' })) : null,
      h('div', { class: 'section-h' }, h('span', { class: 'label', text: window.LOUNGE_DESKTOP ? '이 PC에서 바로 하기' : '이 폰에서 바로 하기' }),
        h('button', { class: 'btn ghost sm', text: '⚙ 설정', onclick: () => settingsSheet(() => homeScreen()) })),
      B.bar, B.sum, B.list);
    const scr = h('div', { class: 'screen home' }, scrollEl);
    B.render();
    show(scr);
  }
  function svgIcon(id) {
    const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 56 56'); s.setAttribute('class', 'ico'); s.setAttribute('aria-hidden', 'true');
    s.innerHTML = (L.games[id] && L.games[id].icon) || ICON[id] || '<circle cx="28" cy="28" r="18" fill="currentColor"/>';
    return s;
  }

  /* ---------- local setup ---------- */
  function setupSheet(id, onHomeChange) {
    const g = L.games[id];
    const favBtn = h('button', {
      class: 'iconbtn fav', 'aria-label': '즐겨찾기', 'aria-pressed': String(store.get('favs', []).includes(id)),
      text: store.get('favs', []).includes(id) ? '★' : '☆',
      onclick() {
        const f = store.get('favs', []); const on = !f.includes(id);
        store.set('favs', on ? f.concat(id) : f.filter((x) => x !== id));
        favBtn.textContent = on ? '★' : '☆'; favBtn.setAttribute('aria-pressed', String(on));
        toast(on ? '즐겨찾기에 넣었어요' : '즐겨찾기에서 뺐어요'); if (onHomeChange) onHomeChange();
      },
    });
    const saved = store.get('setup.' + id, null);
    let seats = saved && saved.length >= g.minPlayers && saved.length <= g.maxPlayers ? saved :
      Array.from({ length: g.defaultPlayers || g.minPlayers }, (_, i) => ({ name: i === 0 ? (myName() || '플레이어 1') : g.noAI ? '플레이어 ' + (i + 1) : 'AI ' + i, ai: !g.noAI && i !== 0 }));
    const list = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } });
    const countV = h('span', { class: 'v' });
    const opts = optDefaults(g, store.get('opts.' + id, null));
    while (seats.length > Math.max(g.minPlayers, maxFor(g, opts))) seats.pop();
    const optBox = h('div');
    // 옵션에 따라 실시간이 되는 게임: def.realtimeIf(opts) → 한 폰에 한 명(1번 = 나, 나머지 AI)
    const rtNow = () => !!(g.realtime || (g.realtimeIf && g.realtimeIf(opts)));
    const rtNote = h('p', { class: 'note', style: { margin: 0 }, text: '실시간 게임은 한 폰에 한 명만 할 수 있어요. 친구와 하려면 온라인 방이나 LAN 방을 쓰세요.' });
    function drawOpts() { optBox.innerHTML = ''; const r = optRows(g, opts, () => { while (seats.length > Math.max(g.minPlayers, maxFor(g, opts))) seats.pop(); drawOpts(); draw(); }); if (r) optBox.append(r); rtNote.hidden = !(rtNow() && !g.localMulti); }
    drawOpts();
    function draw() {
      list.innerHTML = '';
      countV.textContent = seats.length;
      const MANY = seats.length > 10;   // 자리가 많으면 9번째부터 AI는 한 줄로 묶어 보여 줌
      seats.forEach((s, i) => {
        if (MANY && i >= 8 && (rtNow() || s.ai) && !g.noAI) { s.ai = true; return; }
        const inp = h('input', { id: 'seat-' + i, value: s.name, maxlength: 10, 'aria-label': (i + 1) + '번 이름', oninput(e) { s.name = e.target.value; } });
        if (g.noAI) { // people only
          s.ai = false; if (/^AI \d$/.test(s.name)) s.name = '플레이어 ' + (i + 1);
          list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }), inp, h('span', { class: 'tag', text: '사람' })));
          return;
        }
        if (rtNow() && !g.localMulti) { // one driver per phone: seat 0 is you, the rest are AI
          s.ai = i !== 0;
          list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }), inp,
            i === 0 ? h('span', { class: 'tag me', text: '나' }) : lvChip(s.lv, (v) => { s.lv = v; draw(); })));
          return;
        }
        const seg = h('div', { class: 'seg' },
          h('button', { class: s.ai ? '' : 'on', text: '사람', onclick() { s.ai = false; if (/^AI \d$/.test(s.name)) s.name = '플레이어 ' + (i + 1); draw(); } }),
          h('button', { class: s.ai ? 'on' : '', text: 'AI', onclick() { s.ai = true; if (/^플레이어 \d$/.test(s.name)) s.name = 'AI ' + (i + 1); draw(); } }));
        list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }), inp,
          s.ai ? lvChip(s.lv, (v) => { s.lv = v; draw(); }) : null, seg));
      });
      if (MANY && !g.noAI) {
        const rest = seats.slice(8).filter((x) => x.ai);
        if (rest.length) list.append(h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[8] } }),
          h('span', { class: 'nm', style: { flex: 1 }, text: '그 밖의 AI ' + rest.length + '명' }),
          lvChip(rest[0].lv, (v) => { rest.forEach((x) => { x.lv = v; }); draw(); })));
      }
    }
    draw();
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between' } },
        h('h2', { text: g.name }),
        h('div', { class: 'row', style: { gap: '4px', flexWrap: 'nowrap' } },
          favBtn,
          g.codex ? h('button', { class: 'btn sm', text: '📖 도감', onclick: () => codexSheet(id) }) : null,
          h('button', { class: 'btn sm', text: '규칙 보기', onclick: () => rulesSheet(id) }),
          h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() }))),
      g.blurb ? h('p', { class: 'note', style: { margin: 0 }, text: g.blurb }) : null,
      g.controls && g.controls.length && showControlsBtn() ? h('button', { class: 'btn sm', style: { alignSelf: 'flex-start' }, text: '⌨ 조작 설정 (키보드·패드)', onclick: () => controlsSheet(id) }) : null,
      g.minPlayers !== g.maxPlayers ? h('div', { class: 'row', style: { justifyContent: 'space-between' } },
        h('span', { class: 'label', text: '인원' }),
        h('div', { class: 'stepper' },
          g.maxPlayers >= 16 ? h('button', { class: 'btn sm', text: '−5', 'aria-label': '인원 5명 줄이기', onclick() { for (let k = 0; k < 5 && seats.length > g.minPlayers; k++) seats.pop(); draw(); } }) : null,
          h('button', { class: 'btn sm', text: '−', 'aria-label': '인원 줄이기', onclick() { if (seats.length > g.minPlayers) { seats.pop(); draw(); } } }),
          countV,
          h('button', { class: 'btn sm', text: '+', 'aria-label': '인원 늘리기', onclick() { if (seats.length < maxFor(g, opts)) { const i = seats.length; seats.push(g.noAI ? { name: '플레이어 ' + (i + 1), ai: false } : { name: 'AI ' + i, ai: true }); draw(); } } }),
          g.maxPlayers >= 16 ? h('button', { class: 'btn sm', text: '+5', 'aria-label': '인원 5명 늘리기', onclick() { for (let k = 0; k < 5 && seats.length < maxFor(g, opts); k++) { const i = seats.length; seats.push({ name: 'AI ' + i, ai: true }); } draw(); } }) : null)) : null,
      list,
      optBox,
      rtNote,
      h('button', { class: 'btn primary block', text: '시작', onclick() {
        seats.forEach((s, i) => { s.name = (s.name || '').trim().slice(0, 10) || (s.ai ? 'AI ' + i : '플레이어 ' + (i + 1)); });
        store.set('setup.' + id, seats);
        store.set('opts.' + id, opts);
        o.remove();
        const ps = shuffleOrder(g, opts, seats.map((s, i) => ({ name: s.name, ai: !!s.ai, local: !s.ai, color: COLORS[i], lv: s.ai ? (s.lv || 2) : 0 })));
        startSession('local', id, ps, null, opts);
        if (ps !== seats && opts._order === 'rand') orderToast(ps);
      } })));
  }

  /* ---------- session (one running game) ---------- */
  let S = null;
  let wakeLock = null;
  async function keepAwake(on) {
    try {
      if (on && !wakeLock && navigator.wakeLock) { wakeLock = await navigator.wakeLock.request('screen'); wakeLock.addEventListener('release', () => { wakeLock = null; }); }
      if (!on && wakeLock) { const w = wakeLock; wakeLock = null; await w.release(); }
    } catch (e) { wakeLock = null; }
  }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && S) keepAwake(true); });
  function endSession() {
    if (Clock.paused) Clock.resume();
    if (!S) return;
    keepAwake(false);
    clearTimeout(S.aiTimer); Object.values(S.aiTimers).forEach(clearTimeout);
    try { S.view && S.view.destroy && S.view.destroy(); } catch (e) { console.error(e); }
    try { S.input && S.input.destroy(); } catch (e) {}
    if (S.def.landscape) Orient.exit();
    S = null;
  }
  L.session = () => S;


  /* ---------- settings (all platforms; PC client adds display options) ---------- */
  const Desk = window.loungeDesktop || null;   // preload bridge in the Electron client
  function settingsSheet(onClose) {
    const box = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '16px' } });
    let desk = null;
    function chipRow(label, choices, cur, pick) {
      return h('div', { class: 'field' }, h('span', { class: 'label', text: label }),
        h('div', { class: 'chips wrap' }, choices.map((c) => h('button', { class: 'btn sm' + (c.v === cur ? ' on' : ''), text: c.label,
          onclick() { pick(c.v); Sfx.play('click'); draw(); } }))));
    }
    function draw() {
      box.innerHTML = '';
      const nm = h('input', { id: 'set-name', value: myName(), maxlength: 10, placeholder: '이름', 'aria-label': '내 이름',
        onchange(e) { const v = e.target.value.trim().slice(0, 10); if (v) { store.set('name', v); toast('이름을 바꿨어요'); } } });
      box.append(h('div', { class: 'field' }, h('span', { class: 'label', text: '내 이름 (온라인에서 보여요)' }), nm));
      box.append(chipRow('소리', [{ v: true, label: '켬' }, { v: false, label: '끔' }], Sfx.on, (v) => { Sfx.on = v; store.set('sound', v); }));
      box.append(chipRow('진동', [{ v: true, label: '켬' }, { v: false, label: '끔' }], store.get('buzz', true) !== false, (v) => { store.set('buzz', v); if (v) buzz(20); }));
      if (Desk && desk) {
        box.append(chipRow('화면 모드 (PC)', [{ v: 'window', label: '창' }, { v: 'borderless', label: '테두리 없는 창' }, { v: 'fullscreen', label: '전체 화면' }],
          desk.mode, (v) => { desk.mode = v; Desk.setDisplay(v); }));
        box.append(chipRow('화면 크기 (글자·버튼)', [80, 90, 100, 110, 125, 150].map((z) => ({ v: z, label: z + '%' })),
          desk.zoom, (v) => { desk.zoom = v; Desk.setZoom(v); }));
        box.append(chipRow('가로 게임 창 크기', [{ v: true, label: '가로로 자동 바꾸기' }, { v: false, label: '그대로' }],
          desk.autoLandscape, (v) => { desk.autoLandscape = v; Desk.setAuto(v); }));
        box.append(h('div', { class: 'row', style: { gap: '8px' } },
          h('button', { class: 'btn sm', text: '창 크기 처음대로', onclick() { Desk.resetWindow(); toast('창 크기를 되돌렸어요'); } })));
        box.append(h('div', { class: 'field' }, h('span', { class: 'label', text: '단축키' }), shortcutList()));
        box.append(h('button', { class: 'btn danger block', text: '앱 끝내기', onclick() { confirmSheet('한판 라운지를 끝낼까요?', null, '끝내기', () => Desk.quit && Desk.quit()); } }));
      }
      if (!Desk && matchMedia('(pointer:fine)').matches) box.append(h('div', { class: 'field' }, h('span', { class: 'label', text: '단축키' }), shortcutList()));
      box.append(h('p', { class: 'note', style: { margin: 0 }, text: '버전 ' + (window.LOUNGE_BUILD || '개발판') + ' · 게임 ' + L.order.length + '종' }));
    }
    const close = () => { o.remove(); if (onClose) onClose(); };
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } }, h('h2', { text: '설정' }),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      box, h('button', { class: 'btn primary block', text: '닫기', onclick: close })), { cls: 'rules-ov' });
    draw();
    if (Desk) Desk.getSettings().then((d) => { desk = d; draw(); }).catch(() => {});
  }

  /* ---------- keyboard shortcuts ----------
     Esc  : 뒤로 — 맨 위 창 닫기(닫기/취소) → 안내 건너뛰기 → 게임·방 나가기(확인 창). 게임이 Esc를 썼으면(preventDefault) 무시.
     F1   : 규칙(게임 중) / 단축키 도움말(홈)       Ctrl+M : 소리 켜기/끄기      Ctrl+, : 설정
     (PC 앱: F11·Alt+Enter 전체 화면, Ctrl+= / Ctrl+- / Ctrl+0 화면 크기 — main.js) */
  const SHORTCUTS = [
    ['Esc', '뒤로 · 창 닫기 · 게임 나가기'], ['Enter', '확인 창에서 「예」'], ['F1', '게임 중: 규칙 보기 · 홈: 이 도움말'],
    ['Ctrl + M', '소리 켜기/끄기'], ['Ctrl + ,', '설정 열기'],
  ];
  const DESK_SHORTCUTS = [['F11 · Alt + Enter', '전체 화면 ↔ 창'], ['Ctrl + = / Ctrl + -', '화면 크게 / 작게'], ['Ctrl + 0', '화면 크기 100%'], ['Alt + F4', '앱 끝내기']];
  function shortcutList() {
    const rows = SHORTCUTS.concat(Desk ? DESK_SHORTCUTS : []);
    return h('div', { class: 'keys-list' }, rows.map(([k, t]) => h('div', { class: 'keys-row' }, h('kbd', { text: k }), h('span', { text: t }))));
  }
  function shortcutSheet() {
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } }, h('h2', { text: '단축키' }),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: () => o.remove() })),
      shortcutList(),
      h('p', { class: 'note', style: { margin: 0 }, text: '게임 조작 키(이동·발사 등)는 게임 설정 화면의 「⌨ 조작 설정」에서 바꿔요.' }),
      h('button', { class: 'btn primary block', text: '닫기', onclick: () => o.remove() })), { cls: 'rules-ov' });
  }
  function goBack() {
    const ovs = [...document.querySelectorAll('.overlay[data-core]')].filter((o) => !o.classList.contains('result'));
    const top = ovs[ovs.length - 1];
    if (top) {
      const btn = top.querySelector('[aria-label="닫기"]') || [...top.querySelectorAll('button')].find((b) => /^(취소|닫기|세로로 그냥 하기)$/.test(b.textContent.trim()));
      if (btn) btn.click();
      return;
    }
    const tut = document.querySelector('.tut-card');
    if (tut) { const b = [...tut.querySelectorAll('button')].find((x) => x.textContent.trim() === '건너뛰기'); if (b) b.click(); return; }
    const res = document.querySelector('.overlay.result');
    if (res) { const b = [...res.querySelectorAll('button')].find((x) => /다른 게임|로비로/.test(x.textContent)); if (b) b.click(); return; }
    const back = document.querySelector('.topbar .iconbtn');   // 게임: 나가기 · 방/참가 화면: 뒤로
    if (back) back.click();
  }
  addEventListener('keydown', (e) => {
    const t = (e.target && e.target.tagName) || '';
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(t);
    if (e.key === 'Escape') {
      if (typing) { e.target.blur(); return; }
      setTimeout(() => { if (!e.defaultPrevented) goBack(); }, 0);   // let the game consume Esc first (e.g. cancel a selection)
      return;
    }
    if (typing) return;
    if (e.key === 'F1') {
      e.preventDefault();
      if (S && !document.querySelector('.overlay[data-core]:not(.result)')) rulesSheet(S.gameId, S.stage); else if (!S) shortcutSheet();
      return;
    }
    if ((e.ctrlKey || e.metaKey) && !e.altKey && (e.key === 'm' || e.key === 'M')) {
      e.preventDefault(); Sfx.on = !Sfx.on; store.set('sound', Sfx.on); toast(Sfx.on ? '소리 켜짐' : '소리 꺼짐');
      document.querySelectorAll('.topbar .iconbtn[aria-label="소리"]').forEach((b) => { b.textContent = Sfx.on ? '♪' : '♩'; });
      return;
    }
    if ((e.ctrlKey || e.metaKey) && e.key === ',') {
      e.preventDefault();
      if (!document.querySelector('.overlay[data-core]:not(.result)')) settingsSheet(S ? null : () => homeScreen());
    }
  });
  L.goBack = goBack;

  /* ---------- landscape games: def.landscape = true ----------
     PC client: widens the window (unless the player turned it off). Android app: locks to landscape when the
     screen-orientation plugin is present. Browsers/PWA: tries screen.orientation.lock, else asks to rotate
     (with a 「세로로 그냥 하기」 escape — games must still render in portrait). */
  const Orient = {
    on: false, prompt: null, ok: false,
    plugin() { const c = window.Capacitor; return c && c.Plugins && c.Plugins.ScreenOrientation; },
    portrait() { return innerHeight > innerWidth; },
    enter() {
      this.on = true; this.ok = false;
      document.documentElement.classList.add('landscape-game');
      if (Desk) { Desk.landscape(true); return; }
      const pl = this.plugin();
      const lock = pl ? pl.lock({ orientation: 'landscape' }) : (screen.orientation && screen.orientation.lock ? screen.orientation.lock('landscape') : Promise.reject());
      Promise.resolve(lock).catch(() => {}).finally(() => setTimeout(() => this.check(), 350));
      addEventListener('resize', this.onResize);
    },
    onResize() { Orient.check(); },
    check() {
      if (!this.on) return;
      if (!this.portrait() || this.ok) { if (this.prompt) { this.prompt.remove(); this.prompt = null; } return; }
      if (this.prompt) return;
      this.prompt = overlay(h('div', { class: 'sheet rotate-hint' },
        h('div', { class: 'rot-ico', 'aria-hidden': 'true', text: '📱' }),
        h('h2', { text: '가로로 돌려 주세요' }),
        h('p', { class: 'note', style: { margin: 0 }, text: '이 게임은 가로 화면에서 더 크고 편하게 보여요. 화면 회전이 꺼져 있으면 알림창에서 켜 주세요.' }),
        h('button', { class: 'btn block', text: '세로로 그냥 하기', onclick: () => { this.ok = true; this.check(); } })), { cls: 'rotate-ov' });
    },
    exit() {
      if (!this.on) return;
      this.on = false;
      document.documentElement.classList.remove('landscape-game');
      removeEventListener('resize', this.onResize);
      if (this.prompt) { this.prompt.remove(); this.prompt = null; }
      if (Desk) { Desk.landscape(false); return; }
      const pl = this.plugin();
      try { if (pl) pl.lock({ orientation: 'portrait' }); else if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock(); } catch (e) {}
    },
  };
  L.Orient = Orient;
  try { const pl = Orient.plugin(); if (pl) pl.lock({ orientation: 'portrait' }); } catch (e) {}

  /* ---------- first-play tutorial: def.tutorial = [{ text, sel? }] ---------- */
  function runTutorial(def, force, only) {   // only: optional array of steps to show (e.g. just the control steps later)
    if (!S || !(only || def.tutorial) || !(only || def.tutorial).length) return;
    const key = 'tut.' + def.id;
    if (!force && store.get(key, false)) return;
    if (!force && (!S.api.mySeats().length || S.mode !== 'local' || L.debug.noTut)) return;   // auto only for local play (online can't pause the host)
    const me = S, steps = only || def.tutorial;
    let i = 0, ring = null;
    me.paused = true;
    clearTimeout(me.aiTimer); Object.values(me.aiTimers).forEach(clearTimeout); me.aiTimers = {};   // stop AI moves already scheduled
    const txt = h('p', { class: 'tut-text' }), cnt = h('span', { class: 'label' });
    const next = h('button', { class: 'btn primary', onclick() { i++; if (i >= steps.length) done(); else draw(); } });
    const card = h('div', { class: 'tut-card', role: 'dialog', 'aria-label': '게임 안내' },
      h('div', { class: 'row', style: { justifyContent: 'space-between' } }, cnt,
        h('button', { class: 'btn ghost sm', text: '건너뛰기', onclick: () => done() })), txt,
      h('div', { class: 'row', style: { justifyContent: 'flex-end', gap: '8px' } },
        h('button', { class: 'btn sm', text: '이전', onclick() { if (i > 0) { i--; draw(); } } }), next));
    const layer = h('div', { class: 'tut-layer' }, card);
    me.stage.appendChild(layer);
    function draw() {
      const st = steps[i];
      cnt.textContent = '안내 ' + (i + 1) + ' / ' + steps.length;
      txt.textContent = st.text; next.textContent = i === steps.length - 1 ? '시작!' : '다음';
      if (ring) { ring.remove(); ring = null; }
      const el = st.sel ? me.stage.querySelector(st.sel) : null;
      if (el) {
        const a = el.getBoundingClientRect(), b = me.stage.getBoundingClientRect();
        const L0 = Math.max(2, a.left - b.left - 6), T0 = Math.max(2, a.top - b.top - 6);   // keep the ring inside the stage
        const R0 = Math.min(b.width - 2, a.right - b.left + 6), B0 = Math.min(b.height - 2, a.bottom - b.top + 6);
        ring = h('div', { class: 'tut-ring', style: { left: L0 + 'px', top: T0 + 'px', width: Math.max(8, R0 - L0) + 'px', height: Math.max(8, B0 - T0) + 'px' } });
        layer.insertBefore(ring, card);
        const above = a.top - b.top, below = b.bottom - a.bottom;   // put the card on the side with more free room
        card.classList.toggle('top', above > below);
        card.classList.toggle('compact', a.height > b.height * 0.55);   // big target: small see-through card
      } else { card.classList.remove('top'); card.classList.remove('compact'); }
    }
    function done() { layer.remove(); if (!only) store.set(key, true); if (S === me) { me.paused = false; scheduleAI(); } }
    draw();
  }
  L.runTutorial = (force) => S && runTutorial(S.def, force);

  /* ---------- custom controls: keyboard + gamepad → game actions (PC client, BT keyboards) ----------
     A game declares  controls: [{ id, label, keys: ['ArrowLeft','KeyA'], pad: ['left','lx-'] }]
     and reads input via api.input: held(id), on((type, id) => …) → off, axis(negId, posId) → −1…1.
     Players rebind per game in 「조작 설정」(saved in localStorage 'keys.<gameId>'). */
  const PAD_BTN = ['a', 'b', 'x', 'y', 'lb', 'rb', 'lt', 'rt', 'back', 'start', 'ls', 'rs', 'up', 'down', 'left', 'right'];
  const PAD_AX = ['lx', 'ly', 'rx', 'ry'];
  const PAD_NAME = { a: 'Ⓐ', b: 'Ⓑ', x: 'Ⓧ', y: 'Ⓨ', lb: 'LB', rb: 'RB', lt: 'LT', rt: 'RT', back: '뒤로', start: '시작', ls: '왼스틱 누름', rs: '오른스틱 누름',
    up: '패드 ↑', down: '패드 ↓', left: '패드 ←', right: '패드 →', 'lx-': '왼스틱 ←', 'lx+': '왼스틱 →', 'ly-': '왼스틱 ↑', 'ly+': '왼스틱 ↓',
    'rx-': '오른스틱 ←', 'rx+': '오른스틱 →', 'ry-': '오른스틱 ↑', 'ry+': '오른스틱 ↓' };
  const KEY_NAME = { ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓', Space: '스페이스', Enter: 'Enter', ShiftLeft: '왼 Shift', ShiftRight: '오른 Shift',
    ControlLeft: '왼 Ctrl', ControlRight: '오른 Ctrl', AltLeft: '왼 Alt', AltRight: '오른 Alt', Tab: 'Tab', Backquote: '`', Minus: '-', Equal: '=', Comma: ',', Period: '.', Slash: '/',
    Semicolon: ';', Quote: "'", BracketLeft: '[', BracketRight: ']', Backslash: '\\' };
  const keyLabel = (c) => KEY_NAME[c] || c.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, '숫자패드 ');
  const Controls = {
    bindings(def) {
      const saved = store.get('keys.' + def.id, {});
      return (def.controls || []).map((c) => ({ id: c.id, label: c.label,
        keys: (saved[c.id] && saved[c.id].keys) || c.keys || [], pad: (saved[c.id] && saved[c.id].pad) || c.pad || [] }));
    },
    padState() {   // {name: value 0..1} of the first connected gamepad
      const out = {}; const gp = navigator.getGamepads ? [...navigator.getGamepads()].find((g) => g && g.connected) : null;
      if (!gp) return out;
      gp.buttons.forEach((b, i) => { if (PAD_BTN[i]) out[PAD_BTN[i]] = b.value || (b.pressed ? 1 : 0); });
      gp.axes.forEach((v, i) => { if (PAD_AX[i]) { out[PAD_AX[i] + '-'] = Math.max(0, -v); out[PAD_AX[i] + '+'] = Math.max(0, v); } });
      return out;
    },
    attach(def) {
      const binds = Controls.bindings(def);
      const keyDown = {}, padVal = {}, held = {}, fns = [];
      let raf = 0;
      const emit = (type, id) => fns.slice().forEach((f) => { try { f(type, id); } catch (e) { console.error(e); } });
      function recompute() {
        binds.forEach((b) => {
          const on = b.keys.some((k) => keyDown[k]) || b.pad.some((n) => (padVal[n] || 0) > 0.45);
          if (on !== !!held[b.id]) { held[b.id] = on; emit(on ? 'down' : 'up', b.id); }
        });
      }
      const typing = (e) => {   // 글자 입력 중이거나, 포커스된 버튼을 Space/Enter로 누르는 중이면 게임 조작으로 쓰지 않음
        const t = (e.target && e.target.tagName) || '';
        if (/^(INPUT|TEXTAREA|SELECT)$/.test(t)) return true;
        if ((t === 'BUTTON' || t === 'A') && (e.code === 'Space' || e.code === 'Enter' || e.code === 'NumpadEnter')) return true;
        return !!document.querySelector('.overlay[data-core]:not(.result)') && e.code !== 'Escape';   // 시트·확인창이 떠 있으면 게임 조작 멈춤
      };
      function kd(e) {
        if (typing(e) || !binds.some((b) => b.keys.includes(e.code))) return;
        e.preventDefault(); if (keyDown[e.code]) return; keyDown[e.code] = true; recompute();
      }
      function ku(e) { if (keyDown[e.code]) { delete keyDown[e.code]; recompute(); } }
      function blur() { Object.keys(keyDown).forEach((k) => delete keyDown[k]); Object.keys(padVal).forEach((k) => delete padVal[k]); recompute(); }
      function poll() {
        const st = Controls.padState(); Object.keys(padVal).forEach((k) => { if (!(k in st)) delete padVal[k]; }); Object.assign(padVal, st);
        recompute(); raf = requestAnimationFrame(poll);
      }
      if (binds.length) {
        addEventListener('keydown', kd); addEventListener('keyup', ku); addEventListener('blur', blur);
        if (binds.some((b) => b.pad.length)) raf = requestAnimationFrame(poll);
      }
      return {
        held: (id) => !!held[id],
        on(fn) { fns.push(fn); return () => { const i = fns.indexOf(fn); if (i >= 0) fns.splice(i, 1); }; },
        axis(neg, pos) {   // analog when bound to sticks, else -1/0/1
          const val = (id) => { const b = binds.find((x) => x.id === id); if (!b) return 0;
            return Math.max(b.keys.some((k) => keyDown[k]) ? 1 : 0, ...b.pad.map((n) => { const v = padVal[n] || 0; return v > 0.15 ? Math.min(1, (v - 0.15) / 0.75) : 0; })); };
          return val(pos) - val(neg);
        },
        bindings: () => binds,
        destroy() { removeEventListener('keydown', kd); removeEventListener('keyup', ku); removeEventListener('blur', blur); cancelAnimationFrame(raf); fns.length = 0; },
      };
    },
  };
  L.Controls = Controls;

  function controlsSheet(id, parent, onDone) {
    const g = L.games[id];
    let binds = Controls.bindings(g);
    let capture = null, raf = 0;
    const list = h('div', { class: 'ctl-list' });
    const hint = h('p', { class: 'note', style: { margin: 0 }, text: '칸을 누른 뒤 원하는 키나 패드 버튼을 누르세요. 칸을 누르고 Delete를 누르면 지워요.' });
    function save() {
      const o = {}; binds.forEach((b) => { o[b.id] = { keys: b.keys, pad: b.pad }; }); store.set('keys.' + id, o);
    }
    function chip(b, kind, i) {
      const v = b[kind][i];
      const busy = capture && capture.b === b && capture.kind === kind && capture.i === i;
      return h('button', { class: 'btn sm ctl ' + kind + (busy ? ' on' : '') + ((kind === 'pad' ? b.pad.length : v) ? '' : ' empty'),
        text: busy ? '누르세요…' : kind === 'pad' ? (b.pad.map((n) => PAD_NAME[n] || n).join(' · ') || '+') : v ? keyLabel(v) : '+',
        'aria-label': b.label + (kind === 'keys' ? ' 키 ' : ' 패드 ') + (i + 1),
        onclick() { capture = { b, kind, i }; draw(); } });
    }
    function draw() {
      list.innerHTML = '';
      binds.forEach((b) => list.append(h('div', { class: 'ctl-row' },
        h('span', { class: 'ctl-name', text: b.label }),
        h('div', { class: 'ctl-chips' }, chip(b, 'keys', 0), chip(b, 'keys', 1), chip(b, 'pad', 0)))));
    }
    function assign(kind, val) {
      const c = capture; if (!c) return;
      binds.forEach((o) => { if (o !== c.b && o[kind].includes(val)) { o[kind] = o[kind].filter((x) => x !== val); toast(o.label + '에서 옮겼어요'); } });
      if (kind === 'pad') c.b.pad = [val];   // 패드는 한 칸: 새로 누른 것 하나로 바꿈
      else { const arr = c.b[kind].slice(); arr[c.i] = val; c.b[kind] = arr.filter((x, j) => x && arr.indexOf(x) === j); }
      capture = null; save(); Sfx.play('click'); draw();
    }
    function kd(e) {
      if (!capture) return;
      e.preventDefault(); e.stopPropagation();
      if (e.code === 'Escape') { capture = null; draw(); return; }
      if (e.code === 'Delete' || e.code === 'Backspace') { const c = capture; c.b[c.kind] = c.b[c.kind].filter((_, j) => j !== c.i); capture = null; save(); draw(); return; }
      if (capture.kind === 'keys') assign('keys', e.code);
    }
    let prev = Controls.padState();
    function poll() {
      const st = Controls.padState();
      if (capture) { const n = Object.keys(st).find((k) => st[k] > 0.6 && !((prev[k] || 0) > 0.6)); if (n) assign('pad', n); }
      prev = st; raf = requestAnimationFrame(poll);
    }
    addEventListener('keydown', kd, true); raf = requestAnimationFrame(poll);
    const close = () => { removeEventListener('keydown', kd, true); cancelAnimationFrame(raf); o.remove(); if (onDone) onDone(); };
    draw();
    const o = overlay(h('div', { class: 'sheet' },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '조작 설정 · 키보드 / 게임패드' }), h('h2', { text: g.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      hint, list,
      h('div', { class: 'row', style: { gap: '8px' } },
        h('button', { class: 'btn', text: '기본값으로', onclick() { store.set('keys.' + id, {}); binds = Controls.bindings(g); capture = null; draw(); toast('기본 조작으로 되돌렸어요'); } }),
        h('button', { class: 'btn primary', style: { flex: 1 }, text: '완료', onclick: close }))), { cls: 'rules-ov', parent: parent || app });
    return o;
  }
  const showControlsBtn = () => matchMedia('(pointer:fine)').matches || !!window.LOUNGE_DESKTOP;

  function startSession(mode, gameId, players, state, opts) {
    endSession();
    const def = L.games[gameId];
    S = { mode, gameId, def, players, state: null, ver: 0, view: null, busy: false, aiTimer: 0, aiTimers: {}, revealed: -1, resultShown: false, stuck: 0, opts: optDefaults(def, opts) };
    const turnEl = h('span', { class: 'turn', hidden: true });
    const stage = h('div', { class: 'stage' });
    const scr = h('div', { class: 'screen' },
      h('div', { class: 'topbar' },
        h('button', { class: 'iconbtn', 'aria-label': '나가기', text: '‹', onclick: leaveGame }),
        h('div', { class: 'title', text: def.name }),
        h('div', { class: 'grow' }), turnEl,
        mode === 'local' && (def.realtime || def.realtimeIf) ? h('button', { class: 'iconbtn pause-btn', 'aria-label': '일시정지', text: '⏸', onclick: () => pauseSheet() }) : null,
        h('button', { class: 'iconbtn', 'aria-label': '규칙 보기', text: '?', style: { fontWeight: 700, fontFamily: 'var(--f-mono)' }, onclick: () => rulesSheet(gameId, stage) }),
        h('button', { class: 'iconbtn', 'aria-label': '소리', text: Sfx.on ? '♪' : '♩', onclick(e) { Sfx.on = !Sfx.on; store.set('sound', Sfx.on); e.target.textContent = Sfx.on ? '♪' : '♩'; } })),
      stage);
    show(scr);
    S.stage = stage; S.turnEl = turnEl;
    document.title = def.name + ' · 한판 라운지';
    keepAwake(true);
    if (L.STANDALONE) { try { history.pushState({ lounge: 'game' }, ''); } catch (e) {} }
    const mySession = S;
    const api = {
      get players() { return mySession.players; },
      online: mode !== 'local',
      get isHost() { return mySession.mode !== 'guest'; },
      canAct(seat) { const p = mySession.players[seat]; return !!p && !p.ai && !!p.local; },
      mySeats() { return mySession.players.map((p, i) => (!p.ai && p.local ? i : -1)).filter((i) => i >= 0); },
      viewer() { return viewerSeat(); },
      act(action) {
        if (S !== mySession) return;
        const seat = actorsOf(def, S.state).find((x) => api.canAct(x));
        if (seat == null) return;
        submit(seat, action);
      },
      actAs(seat, action) { if (S === mySession && api.canAct(seat)) submit(seat, action); },
      setBusy(b) { if (S !== mySession) return; S.busy = !!b; if (!b) afterIdle(); },
      setState(st) { if (S === mySession && S.mode !== 'guest') setState(st); },
      sfx: (n) => Sfx.play(n), buzz, toast,
      net: {
        publish(obj) { if (mySession.mode !== 'local') Net.pub({ g: obj }); },
        remote() { return Net.remoteG(); },
        hostSend(obj) { if (mySession.mode === 'host') Net.pub({ hs: obj }); },
        hostState() { return Net.hostField('hs'); },
      },
    };
    api.input = S.input = Controls.attach(def);
    api.tutorial = (only) => runTutorial(def, true, Array.isArray(only) ? only : null);
    if (def.landscape) Orient.enter();
    S.api = api;
    try { S.view = def.mount(stage, api); } catch (e) { console.error(e); toast('게임을 여는 중 문제가 생겼어요'); }
    if (state) setState(state, true);
    else if (mode !== 'guest') setState(def.init(clone(players.map((p) => ({ name: p.name, color: p.color, ai: !!p.ai, lv: p.ai ? (p.lv || 2) : 0 }))), clone(S.opts)));
    if (def.tutorial && !def.realtime) setTimeout(() => { if (S === mySession) runTutorial(def); }, 450);
  }

  function viewerSeat() {
    if (!S) return -1;
    if (S.mode !== 'local') { const m = S.api.mySeats(); return m.length ? m[0] : -1; }
    const humans = S.api.mySeats();
    if (humans.length === 1) return humans[0];
    if (humans.length === 0) return -1;
    // several people share this phone: show private info only to the revealed player while it is their turn
    if (S.def.result(S.state)) return S.revealed;
    return actorsOf(S.def, S.state).includes(S.revealed) ? S.revealed : -1;
  }

  function setState(next, fromNet) {
    if (!S) return;
    const prev = S.state;
    S.state = next;
    S.ver++;
    if (S.mode === 'host' && !fromNet) Net.pubState();
    updateTurn();
    maybeCurtain();
    try { S.view && S.view.update && S.view.update(next, prev); } catch (e) { console.error(e); }
    if (!S.def.result(next)) { S.resultShown = false; S.stage.querySelectorAll('.overlay.result').forEach((e) => e.remove()); }
    scheduleAI();
    afterIdle();
  }
  L._setStateFromNet = (st) => setState(st, true);

  function updateTurn() {
    const list = actorsOf(S.def, S.state);
    const el = S.turnEl;
    if (!list.length || !S.players[list[0]] || S.def.result(S.state) || S.def.realtime) { el.hidden = true; S.lastCue = -1; return; }
    el.hidden = false; el.innerHTML = '';
    const seat = list.find((x) => S.api.canAct(x)) != null ? list.find((x) => S.api.canAct(x)) : list[0];
    const p = S.players[seat];
    const mine = S.api.canAct(seat);
    if (list.length > 1) el.append(h('span', { class: 'dot', style: { '--c': 'var(--brass)' } }), mine ? '모두 함께' : '모두 참여');
    else el.append(h('span', { class: 'dot', style: { '--c': p.color } }), (mine && S.mode !== 'local') ? '내 차례' : p.name + (p.ai ? ' 생각 중' : ' 차례'));
    el.classList.toggle('mine', mine);
    // gentle cue when control comes back to a person on this phone after someone else's move
    const key = mine ? seat : -1;
    if (mine && list.length === 1 && S.lastCue !== key && S.ver > 1) { buzz(15); Sfx.play('tick'); }
    S.lastCue = key;
  }

  function submit(seat, action) {
    if (!S) return;
    if (S.mode === 'guest') { Net.sendAct(seat, action); return; }
    if (!actorsOf(S.def, S.state).includes(seat)) return;
    let next;
    try { next = S.def.apply(clone(S.state), seat, clone(action)); } catch (e) { console.warn('rejected action', e); return; }
    if (!next) return;
    setState(next);
  }
  L._submit = submit;

  function scheduleAI() {
    clearTimeout(S.aiTimer); Object.values(S.aiTimers).forEach(clearTimeout); S.aiTimers = {};
    if (S.paused) S.aiDue = {};
    if (S.mode === 'guest' || S.def.realtime || S.paused) return;
    if (S.def.result(S.state)) return;
    const seats = actorsOf(S.def, S.state).filter((x) => S.players[x] && S.players[x].ai);
    const me = S, ver = S.ver;
    // 동시 입력 게임: 다른 자리가 내도 아직 안 낸 AI는 처음 정한 시각을 지킨다(타이머가 매번 처음부터 다시 돌지 않게)
    const due = S.aiDue || (S.aiDue = {});
    Object.keys(due).forEach((k) => { if (!seats.includes(+k)) delete due[k]; });
    seats.forEach((seat) => {
      const lv = S.players[seat].lv || 2;
      const base = S.def.aiDelayFor ? S.def.aiDelayFor(clone(S.state), seat, lv) : (S.def.aiDelay != null ? S.def.aiDelay : 650);
      if (base == null || base < 0) return; // this AI has nothing to do in this state
      const now = Date.now();
      if (due[seat] == null) due[seat] = now + base / L.debug.speed;
      const delay = Math.max(0, due[seat] - now);
      let stuck = 0;
      function tick() {
        if (S !== me || S.ver !== ver) return;
        if (S.busy || document.querySelector('.overlay.curtain') || (S.mode === 'local' && document.querySelector('.overlay.rules-ov'))) { S.aiTimers[seat] = setTimeout(tick, 120); return; }
        let a;
        try { a = S.def.ai(clone(S.state), seat, lv); } catch (e) { console.error('AI error', e); return; }
        if (a == null) return;
        delete due[seat];
        submit(seat, a);
        if (S === me && S.ver === ver) { // action was rejected — avoid silent stall
          if (++stuck < 4) S.aiTimers[seat] = setTimeout(tick, 200);
          else console.error('AI stuck on', S.gameId, a);
        }
      }
      S.aiTimers[seat] = setTimeout(tick, delay);
    });
  }

  /* pass-the-phone curtain for hidden-info games */
  function maybeCurtain() {
    if (S.mode !== 'local' || !S.def.hidden) return;
    const humans = S.api.mySeats();
    if (humans.length < 2) return;
    const list = actorsOf(S.def, S.state);
    if (list.length !== 1) return;
    const seat = list[0];
    if (S.players[seat].ai || seat === S.revealed || S.def.result(S.state)) return;
    if (S.stage.querySelector('.curtain')) return;
    const p = S.players[seat];
    const c = overlay(h('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px' } },
      h('span', { class: 'dot', style: { '--c': p.color, width: '18px', height: '18px' } }),
      h('div', { class: 'big', text: p.name }),
      h('div', { class: 'muted', text: '다른 사람이 보지 않게 폰을 넘겨주세요' }),
      h('button', { class: 'btn primary', text: '내 패 보기' })), { cls: 'curtain', parent: S.stage });
    c.addEventListener('click', () => {
      if (!S) return;
      S.revealed = seat; c.remove(); Sfx.play('click');
      try { S.view.update(S.state, S.state); } catch (e) { console.error(e); }
      scheduleAI();
    });
  }

  function afterIdle() {
    if (!S || S.busy || S.resultShown) return;
    const res = S.def.result(S.state);
    if (!res) return;
    S.resultShown = true;
    const me = S;
    setTimeout(() => { if (S === me && !S.busy) showResult(res); else if (S === me) S.resultShown = false; }, 500 / L.debug.speed);
  }
  function showResult(res) {
    const winners = (res.winners || []).map((i) => S.players[i]).filter(Boolean);
    const anyMine = (res.winners || []).some((i) => S.api.canAct(i));
    Sfx.play(anyMine || S.api.mySeats().length === 0 ? 'win' : 'lose');
    const btns = h('div', { class: 'row', style: { justifyContent: 'flex-end' } });
    if (S.mode === 'guest') {
      btns.append(h('span', { class: 'muted', style: { marginRight: 'auto' }, text: '호스트가 다음 판을 고르는 중' }),
        h('button', { class: 'btn ghost', text: '나가기', onclick: leaveGame }));
    } else {
      btns.append(h('button', { class: 'btn ghost', text: S.mode === 'host' ? '로비로' : '다른 게임', onclick() { o.remove(); S.mode === 'host' ? Net.backToLobby() : homeScreen(); } }),
        h('button', { class: 'btn primary', text: '한 판 더', onclick() { o.remove(); rematch(); } }));
    }
    const o = overlay(h('div', { class: 'sheet' },
      h('span', { class: 'label', text: '결과' }),
      h('h2', { text: res.title || (winners.length === 1 ? winners[0].name + ' 승리' : winners.length ? '공동 승리' : '무승부') }),
      winners.length ? h('div', { class: 'row' }, winners.map((p) => h('span', { class: 'row', style: { gap: '6px' } }, h('span', { class: 'dot', style: { '--c': p.color } }), p.name))) : null,
      res.text ? h('p', { class: 'muted', style: { margin: 0, whiteSpace: 'pre-line' }, text: res.text }) : null,
      btns), { parent: S.stage });
    o.classList.add('result');
  }
  function rematch() {
    if (!S) return;
    if (S.mode === 'local' && S.opts && S.opts._order === 'rand' && S.players.length > 1) {
      const ps = shuffleOrder(S.def, S.opts, S.players);
      startSession('local', S.gameId, ps, null, S.opts); orderToast(ps); return;
    }
    S.revealed = -1; S.resultShown = false;
    S.stage.querySelectorAll('.overlay').forEach((e) => e.remove());
    setState(S.def.init(clone(S.players.map((p) => ({ name: p.name, color: p.color, ai: !!p.ai, lv: p.ai ? (p.lv || 2) : 0 }))), clone(S.opts)));
  }
  L._rematch = rematch;
  /* ---------- 실시간 게임 일시정지 (혼자·한 폰 판만; 온라인 판은 못 멈춤) ---------- */
  const canPause = () => !!(S && S.mode === 'local' && (S.def.realtime || (S.def.realtimeIf && S.def.realtimeIf(S.opts))) && !S.def.result(S.state));
  function setPaused(on) {
    if (!S) return;
    if (on && !canPause()) return;
    if (on === Clock.paused) return;
    if (on) Clock.pause(); else Clock.resume();
    S.rtPaused = on;
    try { window.dispatchEvent(new CustomEvent(on ? 'lounge-pause' : 'lounge-resume')); } catch (e) {}
    try { if (S.view && S.view[on ? 'pause' : 'resume']) S.view[on ? 'pause' : 'resume'](); } catch (e) { console.error(e); }
  }
  function pauseSheet() {
    if (!canPause() || document.querySelector('.overlay.pause-ov')) return;
    setPaused(true);
    const done = () => { o.remove(); setPaused(false); };
    const o = overlay(h('div', { class: 'sheet', style: { alignItems: 'stretch' } },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '일시정지' }), h('h2', { text: S.def.name })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: done })),
      h('button', { class: 'btn primary block', text: '▶ 계속하기', onclick: done }),
      h('button', { class: 'btn block', text: '규칙 보기', onclick() { o.remove(); const r = rulesSheet(S.gameId, S.stage); watchRemoved(r, () => { if (S) pauseSheetKeep(); }); } }),
      S.def.codex ? h('button', { class: 'btn block', text: '📖 도감', onclick() { o.remove(); const r = codexSheet(S.gameId, S.stage); watchRemoved(r, () => { if (S) pauseSheetKeep(); }); } }) : null,
      h('button', { class: 'btn danger block', text: '게임 나가기', onclick() { o.remove(); setPaused(false); homeScreen(); } })), { cls: 'pause-ov', parent: S.stage });
    o.addEventListener('click', (e) => { if (e.target === o) done(); });
    function pauseSheetKeep() { if (Clock.paused) { Clock.resume(); S.rtPaused = false; } pauseSheet(); }
  }
  function watchRemoved(el, fn) {   // 시트가 닫히면(DOM에서 빠지면) fn
    if (!el || !el.parentNode) return;
    const mo = new MutationObserver(() => { if (!el.isConnected) { mo.disconnect(); fn(); } });
    mo.observe(el.parentNode, { childList: true });
  }
  L.pause = () => pauseSheet();
  document.addEventListener('visibilitychange', () => { if (document.hidden && canPause() && !Clock.paused) pauseSheet(); });

  function leaveGame() {
    if (!S) return homeScreen();
    if (canPause()) return pauseSheet();   // 혼자 하는 실시간 판: 나가기 대신 일시정지 화면(여기서 나가기)
    const go = () => { if (S && S.mode === 'host') Net.backToLobby(); else homeScreen(); };
    if (S.def.result(S.state) || S.mode === 'guest' && !S.state) return go();
    confirmSheet(S.mode === 'host' ? '로비로 돌아갈까요?' : '게임을 나갈까요?', S.mode === 'host' ? '진행 중인 판은 모두에게서 끝납니다.' : '진행 중인 판은 저장되지 않아요.', '나가기', go);
  }

  /* ---------- online: artifact room capability ---------- */
  const Net = {
    room: null, r: null, code: null, role: null, peer: null, unsub: [], k: 0, lastK: {}, lobby: null,
    pending: {}, pubTimer: 0, hostSeen: 0, guestOrder: [], stVer: -1,
    async getRoom() {
      if (this.room) return this.room;
      if (window.claude && typeof window.claude.use === 'function') {
        try { this.room = await window.claude.use('room'); } catch (e) { this.room = null; }
      } else if (window.Peer) this.room = peerRoom();
      return this.room;
    },
    async open(code, asHost) {
      const room = await this.getRoom();
      if (!room) throw new Error('noroom');
      this.code = code;
      this.r = await room.join('hl-' + code.toLowerCase(), asHost);
      return this.r;
    },
    myPeer() {
      if (!this.r) return null;
      const me = this.r.peers().find((p) => p.sameTab);
      if (me) this.peer = me.peer;
      return this.peer;
    },
    pub(patch) {
      if (!this.r) return;
      Object.assign(this.pending, patch);
      if (this.pubTimer) return;
      this.pubTimer = setTimeout(() => {
        this.pubTimer = 0;
        const p = this.pending; this.pending = {};
        if (!this.r) return;
        this.r.presence(p).catch((e) => {
          console.warn('presence', e);
          if (e && e.code === 'invalid_argument') toast('상태가 너무 커서 전송하지 못했어요');
        });
      }, 45);
    },
    leave() {
      this.unsub.forEach((u) => { try { u(); } catch (e) {} });
      this.unsub = [];
      if (this.r) { try { this.r.leave(); } catch (e) {} }
      this.r = null; this.role = null; this.code = null; this.lobby = null; this.lastK = {}; this.guestOrder = []; this.stVer = -1; this.pending = {}; this.lobbySig = null; this.lan = false;
    },
    hostPeer() { return this.r ? this.r.peers().find((p) => p.presence && p.presence.role === 'h' && !p.sameTab) : null; },
    hostField(f) { const hp = this.hostPeer(); return hp && hp.presence ? hp.presence[f] : null; },
    remoteG() {
      const out = {};
      if (!this.r || !this.lobby) return out;
      for (const p of this.r.peers()) {
        if (p.sameTab || !p.presence || !p.presence.g) continue;
        this.lobby.seats.forEach((s, i) => { if (s.p === p.peer) out[i] = p.presence.g; });
      }
      return out;
    },
    pubState() {
      if (this.role !== 'h' || !S) return;
      this.pub({ st: { v: S.ver, s: S.state }, lobby: this.lobby });
    },
    sendAct(seat, a) { this.k++; this.pub({ act: { k: this.k, seat, a } }); },
    backToLobby() {
      if (this.role !== 'h') return homeScreen();
      endSession();
      this.lobby.started = null; this.lobbySig = null;
      this.pub({ lobby: this.lobby, st: null });
      hostLobby(true);
    },
  };
  L.net = Net;

  /* Star of connections around the host, exposing the same join/presence/peers/onPeers
     surface the artifact `room` capability offers. A connection is {peer, open, send(m), on(ev, f)}. */
  function makeStar(asHost, onClosed) {
    const roster = new Map(); // peerId -> presence
    const conns = new Map(); // host: guestId -> conn
    let hostConn = null, myId = null, mine = {}, alive = true;
    let J = [], U = [], Lf = [], sched = false;
    const hs = [];
    const mk = (id, p) => ({ peer: id, by: null, isMe: id === myId, sameTab: id === myId, kind: 'viewer', guest: false, presence: p || {}, updatedAt: Date.now() });
    const list = () => [...roster.entries()].map(([id, p]) => mk(id, p));
    function flush() { sched = false; const ch = { peers: list(), joined: J, updated: U, left: Lf }; J = []; U = []; Lf = []; hs.forEach((f) => { try { f(ch); } catch (e) { console.error(e); } }); }
    function q() { if (!sched) { sched = true; setTimeout(flush, 16); } }
    function setP(id, p) { const had = roster.has(id); roster.set(id, p); (had ? U : J).push(mk(id, p)); q(); }
    function drop(id) { if (!roster.has(id)) return; roster.delete(id); Lf.push(mk(id, {})); q(); }
    function send(c, m) { try { if (c && c.open) c.send(m); } catch (e) {} }
    const R = {
      presence(patch) {
        for (const k in patch) { if (patch[k] === null) delete mine[k]; else mine[k] = patch[k]; }
        const p = JSON.parse(JSON.stringify(mine));
        if (myId) setP(myId, p);
        if (asHost) conns.forEach((c) => send(c, { t: 'pres', peer: myId, p }));
        else send(hostConn, { t: 'pres', p });
        return Promise.resolve();
      },
      peers: list,
      onPeers(f) { hs.push(f); setTimeout(() => f({ peers: list(), joined: list(), updated: [], left: [] }), 0); return () => { const i = hs.indexOf(f); if (i >= 0) hs.splice(i, 1); }; },
      emit() { return Promise.resolve(); }, on() { return () => {}; },
      connected() { return alive && (asHost || !!(hostConn && hostConn.open)); },
      onConnection(f) { setTimeout(() => f(R.connected())); return () => {}; },
      leave() { alive = false; if (onClosed) onClosed(); return Promise.resolve(); },
    };
    return {
      R,
      setId(id) { myId = id; roster.set(id, JSON.parse(JSON.stringify(mine))); },
      addGuest(c) { // host side
        const opened = () => {
          if (conns.has(c.peer)) return;
          conns.set(c.peer, c);
          send(c, { t: 'roster', list: [...roster.entries()].map(([peer, p]) => ({ peer, p })) });
        };
        c.on('open', opened); if (c.open) opened();
        c.on('data', (m) => {
          if (!m || m.t !== 'pres' || !m.p || typeof m.p !== 'object') return;
          setP(c.peer, m.p);
          conns.forEach((o, id) => { if (id !== c.peer) send(o, { t: 'pres', peer: c.peer, p: m.p }); });
        });
        const gone = () => { if (!conns.has(c.peer)) return; conns.delete(c.peer); drop(c.peer); conns.forEach((o) => send(o, { t: 'leave', peer: c.peer })); };
        c.on('close', gone); c.on('error', gone);
      },
      setHost(c) { // guest side
        hostConn = c;
        const opened = () => send(c, { t: 'pres', p: mine });
        c.on('open', opened); if (c.open) opened();
        c.on('data', (m) => {
          if (!m || typeof m !== 'object') return;
          if (m.t === 'roster' && Array.isArray(m.list)) m.list.forEach((e) => { if (e.peer !== myId) setP(e.peer, e.p); });
          else if (m.t === 'pres' && m.peer !== myId) setP(m.peer, m.p);
          else if (m.t === 'leave') drop(m.peer);
        });
        c.on('close', () => { [...roster.keys()].forEach((k) => { if (k !== myId) drop(k); }); });
      },
    };
  }

  /* Internet transport for the installed app: PeerJS (WebRTC via a public signalling server). */
  function peerRoom() {
    const PREFIX = 'hanpan-lounge-v1-';
    return {
      join(name, asHost) {
        return new Promise((resolve, reject) => {
          const hostId = PREFIX + name;
          const peer = asHost ? new window.Peer(hostId) : new window.Peer();
          const star = makeStar(asHost, () => { try { peer.destroy(); } catch (e) {} });
          let settled = false;
          const fail = (err) => { if (!settled) { settled = true; reject(err); try { peer.destroy(); } catch (e) {} } };
          const timer = setTimeout(() => fail(new Error(asHost ? 'timeout' : 'notfound')), 12000);
          const ok = () => { clearTimeout(timer); settled = true; resolve(star.R); };
          peer.on('open', (id) => {
            star.setId(id);
            if (asHost) return ok();
            const c = peer.connect(hostId, { reliable: true });
            c.on('open', ok);
            star.setHost(c);
          });
          if (asHost) peer.on('connection', (c) => star.addGuest(c));
          peer.on('disconnected', () => { try { peer.reconnect(); } catch (e) {} });
          peer.on('error', (e) => {
            const t = e && e.type;
            if (t === 'peer-unavailable') fail(new Error('notfound'));
            else if (t === 'unavailable-id') fail(new Error('taken'));
            else if (!settled) fail(new Error('network'));
            else console.warn('peer', t);
          });
        });
      },
    };
  }

  /* LAN transport for the installed app: direct WebRTC with no servers at all. The host and each
     guest swap a connection code (shown as a QR) once; devices must be on the same Wi-Fi. */
  const Lan = {
    async encode(obj) {
      const raw = new TextEncoder().encode(JSON.stringify(obj));
      let bytes = raw, tag = 'J';
      if (window.CompressionStream) {
        try {
          const cs = new Blob([raw]).stream().pipeThrough(new CompressionStream('deflate-raw'));
          bytes = new Uint8Array(await new Response(cs).arrayBuffer()); tag = 'Z';
        } catch (e) { bytes = raw; tag = 'J'; }
      }
      let bin = ''; bytes.forEach((b) => { bin += String.fromCharCode(b); });
      return 'HL1' + tag + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    },
    async decode(text) {
      text = String(text || '').trim();
      if (!/^HL1[ZJ]/.test(text)) throw new Error('badcode');
      const tag = text[3];
      const b64 = text.slice(4).replace(/-/g, '+').replace(/_/g, '/');
      const bin = atob(b64 + '==='.slice((b64.length + 3) % 4));
      let bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
      if (tag === 'Z') bytes = new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
      return JSON.parse(new TextDecoder().decode(bytes));
    },
    pc() { return new RTCPeerConnection({ iceServers: [] }); },
    gathered(pc) {
      return new Promise((res) => {
        if (pc.iceGatheringState === 'complete') return res();
        const t = setTimeout(res, 3000);
        pc.addEventListener('icegatheringstatechange', () => { if (pc.iceGatheringState === 'complete') { clearTimeout(t); res(); } });
      });
    },
    wrap(dc, pc, peerId) {
      const hs = {};
      const emit = (n, a) => (hs[n] || []).forEach((f) => { try { f(a); } catch (e) { console.error(e); } });
      let closed = false;
      const close = () => { if (closed) return; closed = true; emit('close'); };
      dc.onopen = () => emit('open');
      dc.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } emit('data', m); };
      dc.onclose = close;
      pc.addEventListener('connectionstatechange', () => { if (pc.connectionState === 'failed' || pc.connectionState === 'closed') close(); });
      return { peer: peerId, get open() { return dc.readyState === 'open'; }, send(m) { dc.send(JSON.stringify(m)); }, on(n, f) { (hs[n] = hs[n] || []).push(f); } };
    },
    host() {
      const pcs = [];
      const star = makeStar(true, () => pcs.forEach((p) => { try { p.close(); } catch (e) {} }));
      const hostId = 'h' + Math.random().toString(36).slice(2, 8);
      star.setId(hostId);
      let n = 0;
      star.R.invite = async () => {
        const gid = 'g' + (++n) + Math.random().toString(36).slice(2, 5);
        const pc = Lan.pc(); pcs.push(pc);
        const dc = pc.createDataChannel('lounge', { ordered: true });
        const conn = Lan.wrap(dc, pc, gid);
        await pc.setLocalDescription(await pc.createOffer());
        await Lan.gathered(pc);
        const text = await Lan.encode({ s: pc.localDescription.sdp, i: gid, h: hostId });
        return {
          text,
          async accept(answer) {
            const a = await Lan.decode(answer);
            if (a.i !== gid || !a.s) throw new Error('mismatch');
            await pc.setRemoteDescription({ type: 'answer', sdp: a.s });
            star.addGuest(conn);
            return new Promise((res, rej) => { if (conn.open) return res(); conn.on('open', res); setTimeout(() => rej(new Error('lan-timeout')), 15000); });
          },
          cancel() { try { pc.close(); } catch (e) {} },
        };
      };
      return star.R;
    },
    async join(offerText) {
      const o = await Lan.decode(offerText);
      if (!o.s || !o.i || !o.h) throw new Error('badcode');
      const pc = Lan.pc();
      const star = makeStar(false, () => { try { pc.close(); } catch (e) {} });
      star.setId(o.i);
      const ready = new Promise((res, rej) => {
        pc.ondatachannel = (e) => { const c = Lan.wrap(e.channel, pc, o.h); star.setHost(c); c.on('open', () => res(star.R)); };
        setTimeout(() => rej(new Error('lan-timeout')), 120000);
      });
      await pc.setRemoteDescription({ type: 'offer', sdp: o.s });
      await pc.setLocalDescription(await pc.createAnswer());
      await Lan.gathered(pc);
      return { text: await Lan.encode({ s: pc.localDescription.sdp, i: o.i }), ready, cancel() { try { pc.close(); } catch (e) {} } };
    },
  };
  L.lan = Lan;

  /* QR show/scan for LAN pairing (installed app only). Libraries load from CDNs; the app's
     service worker pre-caches them so pairing also works offline after the first install. */
  const LIBS = {
    qr: 'lib/qrcode.min.js',
    jsqr: 'lib/jsQR.js',
  };
  L.LIBS = LIBS;
  const scriptCache = {};
  function loadScript(url) {
    if (!scriptCache[url]) scriptCache[url] = new Promise((res, rej) => {
      const el = document.createElement('script'); el.src = url; el.crossOrigin = 'anonymous';
      el.onload = res; el.onerror = () => { delete scriptCache[url]; rej(new Error('load ' + url)); };
      document.head.appendChild(el);
    });
    return scriptCache[url];
  }
  async function codeBox(text) {
    const box = h('div', { class: 'codebox' });
    try {
      await loadScript(LIBS.qr);
      const q = window.qrcode(0, 'L'); q.addData(text); q.make();
      box.append(h('div', { class: 'qr', html: q.createSvgTag({ cellSize: 4, margin: 3, scalable: true }) }));
    } catch (e) { box.append(h('p', { class: 'note', text: 'QR을 그리지 못했어요. 아래 코드를 복사해서 보내 주세요.' })); }
    const ta = h('textarea', { class: 'codetext mono', readonly: true, rows: 2, 'aria-label': '연결 코드' });
    ta.value = text;
    box.append(h('details', null, h('summary', { text: '카메라가 안 되면: 코드로 주고받기' }), ta,
      h('button', { class: 'btn sm', text: '코드 복사', onclick() {
        ta.select();
        try { navigator.clipboard.writeText(text).then(() => toast('복사했어요'), () => { try { document.execCommand('copy'); toast('복사했어요'); } catch (e) {} }); } catch (e) {}
      } })));
    return box;
  }
  /* Opens the camera and resolves with the first HL1… code it sees (or a pasted one), or null. */
  function scanCode(title) {
    return new Promise((resolve) => {
      let stream = null, timer = 0, done = false, detector = null;
      const video = h('video', { class: 'scanvid', playsinline: true, muted: true, autoplay: true });
      const status = h('p', { class: 'note', style: { margin: 0 }, text: '카메라를 켜는 중…' });
      const paste = h('input', { id: 'paste-code', class: 'mono', placeholder: '또는 받은 코드 붙여넣기', autocomplete: 'off' });
      const finish = (v) => {
        if (done) return; done = true; clearInterval(timer);
        try { stream && stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
        o.remove(); resolve(v);
      };
      const o = overlay(h('div', { class: 'sheet' },
        h('h2', { text: title }), h('div', { class: 'scanwrap' }, video, h('div', { class: 'scanframe' })), status,
        h('div', { class: 'row', style: { flexWrap: 'nowrap' } }, paste, h('button', { class: 'btn sm', text: '확인', onclick() { const v = paste.value.trim(); if (/^HL1[ZJ]/.test(v)) finish(v); else toast('코드가 올바르지 않아요'); } })),
        h('button', { class: 'btn ghost block', text: '취소', onclick: () => finish(null) })));
      (async () => {
        try {
          if ('BarcodeDetector' in window) {
            try { const f = await window.BarcodeDetector.getSupportedFormats(); if (f.includes('qr_code')) detector = new window.BarcodeDetector({ formats: ['qr_code'] }); } catch (e) {}
          }
          if (!detector) await loadScript(LIBS.jsqr);
          stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
          if (done) { stream.getTracks().forEach((t) => t.stop()); return; }
          video.srcObject = stream; await video.play().catch(() => {});
          status.textContent = 'QR을 네모 안에 맞춰 주세요';
          const cv = document.createElement('canvas'), cx = cv.getContext('2d', { willReadFrequently: true });
          let busy = false;
          timer = setInterval(async () => {
            if (busy || done || !video.videoWidth) return;
            busy = true;
            try {
              let text = null;
              if (detector) { const r = await detector.detect(video); if (r && r[0]) text = r[0].rawValue; }
              else {
                const sc = Math.min(1, 720 / Math.max(video.videoWidth, video.videoHeight));
                cv.width = Math.round(video.videoWidth * sc); cv.height = Math.round(video.videoHeight * sc);
                cx.drawImage(video, 0, 0, cv.width, cv.height);
                const img = cx.getImageData(0, 0, cv.width, cv.height);
                const r = window.jsQR(img.data, cv.width, cv.height, { inversionAttempts: 'dontInvert' });
                if (r) text = r.data;
              }
              if (text && /^HL1[ZJ]/.test(text)) { buzz(30); Sfx.play('pop'); finish(text); }
            } catch (e) {}
            busy = false;
          }, 220);
        } catch (e) {
          status.textContent = '카메라를 쓸 수 없어요. 받은 코드를 붙여넣어 주세요.';
        }
      })();
    });
  }

  function noRoomMsg(err) {
    const m = err && err.message;
    if (m === 'noroom') return L.STANDALONE ? '온라인 연결 기능을 불러오지 못했어요. 인터넷 연결을 확인하고 앱을 다시 열어 주세요.' : '온라인 방은 claude.ai에 로그인한 상태로 이 페이지를 열었을 때 쓸 수 있어요.';
    if (m === 'notfound') return '그 코드의 방을 찾지 못했어요. 코드를 다시 확인해 주세요.';
    if (m === 'taken') return '같은 코드의 방이 이미 있어요. 다시 만들어 주세요.';
    return '방에 연결하지 못했어요. 잠시 후 다시 시도해 주세요.';
  }
  function nameField(id) {
    return h('label', { class: 'field' }, h('span', { class: 'label', text: '내 이름' }),
      h('input', { id, value: myName(), maxlength: 10, placeholder: '예: 정진', autocomplete: 'nickname' }));
  }

  /* host lobby */
  async function hostLobby(resume, lan) {
    let name = myName();
    if (!resume) {
      endSession(); Net.leave();
      if (!name) return askName(() => hostLobby(false, lan));
      const code = Array.from({ length: 4 }, () => 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random() * 23)]).join('');
      show(h('div', { class: 'screen' }, topbarSimple('방 만들기'), h('div', { class: 'scroll' }, h('p', { class: 'muted', text: '방을 여는 중…' }))));
      if (lan) { Net.r = Lan.host(); Net.code = 'LAN'; Net.lan = true; }
      else { try { await Net.open(code, true); } catch (e) { return errorScreen(noRoomMsg(e)); } Net.lan = false; }
      Net.role = 'h';
      Net.lobby = { game: null, count: 0, seats: [], people: [], started: null, opts: null };
      Net.unsub.push(Net.r.onPeers(onHostPeers, (e) => { console.warn(e); }));
    }
    renderHostLobby();
  }
  function hostSeats() {
    const g = L.games[Net.lobby.game];
    const me = Net.myPeer();
    const peers = Net.r ? Net.r.peers() : [];
    const guests = peers.filter((p) => !p.sameTab && p.presence && p.presence.role === 'g');
    guests.forEach((p) => { if (!Net.guestOrder.includes(p.peer)) Net.guestOrder.push(p.peer); });
    Net.guestOrder = Net.guestOrder.filter((pp) => guests.some((g2) => g2.peer === pp));
    Net.lobby.people = [{ n: myName() || '방장', p: me }].concat(Net.guestOrder.map((gp) => { const pp = guests.find((x) => x.peer === gp); return { n: String((pp.presence.name || '친구')).slice(0, 10), p: gp }; }));
    if (!g) { Net.lobby.seats = []; Net.lobby.count = 0; return; }
    const gmax = maxFor(g, optDefaults(g, Net.lobby.opts));
    const n = Math.max(Net.lobby.count, Math.min(gmax, 1 + Net.guestOrder.length));
    Net.lobby.count = Math.max(g.minPlayers, Math.min(gmax, n));
    const seats = [{ n: myName() || '호스트', p: me }];
    for (const gp of Net.guestOrder) {
      if (seats.length >= Net.lobby.count) break;
      const pp = guests.find((x) => x.peer === gp);
      seats.push({ n: String((pp.presence.name || '친구')).slice(0, 10), p: gp });
    }
    let ai = 1;
    Net.aiLv = Net.aiLv || {};
    while (seats.length < Net.lobby.count) { const i = seats.length; seats.push({ n: 'AI ' + ai++, ai: true, lv: Net.aiLv[i] || 2 }); }
    Net.lobby.seats = seats;
  }
  function onHostPeers(ch) {
    if (Net.role !== 'h') return;
    if (!Net.lobby.started) {
      hostSeats();
      const sig = JSON.stringify(Net.lobby);
      if (sig !== Net.lobbySig) { Net.lobbySig = sig; Net.pub({ role: 'h', name: myName(), lobby: Net.lobby }); renderHostLobby(); }
      return;
    }
    // in game: process guest actions, convert departed guests to AI
    for (const p of ch.left) {
      Net.lobby.seats.forEach((s, i) => {
        if (s.p === p.peer && !s.ai) {
          s.ai = true; s.p = null; s.n = s.n + '(AI)'; s.lv = 2;
          if (S) { S.players[i].ai = true; S.players[i].lv = 2; S.players[i].local = false; S.players[i].name = s.n; toast(s.n.replace('(AI)', '') + ' 님이 나가서 AI가 이어서 해요'); scheduleAI(); }
        }
      });
      Net.pub({ lobby: Net.lobby });
    }
    for (const p of ch.updated.concat(ch.joined)) {
      if (p.sameTab || !p.presence || p.presence.role !== 'g') continue;
      const act = p.presence.act;
      if (!act || typeof act.k !== 'number') continue;
      // a guest's counter starts at 0 when it joins, so its very first action (k = 1) must count
      if (act.k <= (Net.lastK[p.peer] || 0)) continue;
      Net.lastK[p.peer] = act.k;
      const seat = act.seat | 0;
      const s = Net.lobby.seats[seat];
      if (!s || s.p !== p.peer || !S) continue;
      submit(seat, act.a);
    }
    if (ch.joined.some((p) => !p.sameTab)) Net.pubState();
  }
  const lobbyFits = (g, people) => people <= g.maxPlayers && (!g.noAI || people >= g.minPlayers);
  function chooseLobbyGame(id, how) {
    const gg = L.games[id];
    Net.lobby.game = id; Net.lobby.pick = { id, how: how || '', t: Date.now() };
    Net.lobby.count = Math.max(gg.defaultPlayers || gg.minPlayers, Math.min(gg.maxPlayers, Net.lobby.people.length || 1));
    Net.lobby.opts = optDefaults(gg, store.get('opts.' + id, null));
    hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby();
  }
  function lobbyRandom(fromFavs) {
    const people = Math.max(1, (Net.lobby.people || []).length);
    let pool = (fromFavs ? store.get('favs', []) : L.order).filter((id) => L.games[id] && lobbyFits(L.games[id], people));
    if (Net.lobby.game && pool.length > 1) pool = pool.filter((id) => id !== Net.lobby.game);
    if (!pool.length) { toast(fromFavs ? '즐겨찾기에 지금 인원으로 할 수 있는 게임이 없어요' : '지금 인원으로 할 수 있는 게임이 없어요'); return; }
    const pick = pool[Math.floor(Math.random() * pool.length)];
    // short roulette on the host screen, then announce to everyone
    const card = document.querySelector('.lobby-game .nm');
    let n = 0;
    const spin = setInterval(() => { if (card) card.textContent = L.games[pool[Math.floor(Math.random() * pool.length)]].name; Sfx.play('tick'); if (++n >= 12) { clearInterval(spin); chooseLobbyGame(pick, fromFavs ? '즐겨찾기 랜덤' : '랜덤'); Sfx.play('pop'); buzz(20); } }, 85);
  }
  function lobbyGamePicker() {
    const people = Math.max(1, (Net.lobby.people || []).length);
    // 인원 필터는 지금 방 인원으로 자동 설정(지우면 안 맞는 게임도 흐리게 보임)
    const st = { cat: '전체', people, kind: '', q: '', view: 'list',
      sort: SORTS.some((s) => s.v === store.get('home.sort', 'cat')) ? store.get('home.sort', 'cat') : 'cat' };
    let sheet = null, pickIO = null;
    const close = () => { if (pickIO) pickIO.disconnect(); o.remove(); };
    const B = gameBrowser({
      st, views: false, fold: new Set(),
      save(s) { store.set('home.sort', s.sort); },
      onPick(id) { close(); chooseLobbyGame(id); },
      fits: (g) => lobbyFits(g, people), current: Net.lobby.game,
      scroller: () => sheet, ioOut: (io) => { pickIO = io; },
    });
    sheet = h('div', { class: 'sheet pick-sheet', onscroll: () => B.onScroll() },
      h('div', { class: 'row', style: { justifyContent: 'space-between', flexWrap: 'nowrap' } },
        h('div', null, h('span', { class: 'label', text: '지금 ' + people + '명 · 방장이 골라요' }), h('h2', { text: '게임 고르기' })),
        h('button', { class: 'iconbtn', 'aria-label': '닫기', text: '✕', onclick: close })),
      B.bar, B.sum, B.list);
    const o = overlay(sheet, { cls: 'rules-ov pick-ov' });
    o.addEventListener('click', (e) => { if (e.target === o) close(); });
    B.render();
  }
  function peopleList(people, me) {
    return h('div', { class: 'people' }, (people || []).map((pp, i) => h('span', { class: 'person' + (pp.p === me ? ' me' : '') },
      h('span', { class: 'dot', style: { '--c': COLORS[i % COLORS.length] } }), (i === 0 ? '👑 ' : '') + pp.n + (pp.p === me ? ' (나)' : ''))));
  }
  function renderHostLobby() {
    if (S || Net.role !== 'h') return;
    hostSeats();
    const g = L.games[Net.lobby.game];
    const people = Net.lobby.people || [];
    const guests = Net.guestOrder.length;
    const gameBox = g ? h('div', { class: 'lobby-game', style: { '--tint': g.tint || TINT[Net.lobby.game] || 'var(--surface)' } },
      svgIcon(Net.lobby.game),
      h('div', { class: 'lg-info' }, h('span', { class: 'label', text: Net.lobby.pick && Net.lobby.pick.how ? '🎲 ' + Net.lobby.pick.how + '으로 골랐어요' : '이번 게임' }),
        h('div', { class: 'nm', text: g.name }), h('span', { class: 'muted', text: (g.minPlayers === g.maxPlayers ? g.minPlayers + '인' : g.minPlayers + '–' + g.maxPlayers + '인') + (g.tag ? ' · ' + g.tag : '') })),
      L.games[Net.lobby.game] && L.games[Net.lobby.game].codex ? h('button', { class: 'btn sm', text: '📖 도감', onclick: () => codexSheet(Net.lobby.game) }) : null,
      h('button', { class: 'btn sm', text: '규칙', onclick: () => rulesSheet(Net.lobby.game) }))
      : h('div', { class: 'lobby-game empty' }, h('div', { class: 'lg-info' }, h('span', { class: 'label', text: '이번 게임' }), h('div', { class: 'nm', text: '아직 안 골랐어요' }),
        h('span', { class: 'muted', text: '친구들이 다 들어오면 게임을 골라 주세요.' })));
    const pickRow = h('div', { class: 'pick-row' },
      h('button', { class: 'btn' + (g ? '' : ' primary'), text: g ? '🎮 게임 바꾸기' : '🎮 게임 고르기', onclick: lobbyGamePicker }),
      h('button', { class: 'btn', text: '🎲 랜덤', onclick: () => lobbyRandom(false) }),
      h('button', { class: 'btn', text: '🎲 즐겨찾기 랜덤', onclick: () => lobbyRandom(true) }));
    const seatList = g ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } },
      Net.lobby.seats.map((s, i) => (Net.lobby.seats.length > 10 && i >= 8 && s.ai) ? null : h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[i] } }),
        h('span', { class: 'nm', text: s.n }),
        s.ai ? lvChip(s.lv, (v) => { Net.aiLv = Net.aiLv || {}; Net.aiLv[i] = v; hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }) : null,
        h('span', { class: 'tag' + (i === 0 ? ' me' : ''), text: i === 0 ? '나' : s.ai ? 'AI' : '친구' }))),
      (() => {   // 자리가 많으면 9번째부터 AI는 한 줄로
        const idx = Net.lobby.seats.map((s, i) => i).filter((i) => Net.lobby.seats.length > 10 && i >= 8 && Net.lobby.seats[i].ai);
        if (!idx.length) return null;
        return h('div', { class: 'seat' }, h('span', { class: 'dot', style: { '--c': COLORS[8] } }), h('span', { class: 'nm', style: { flex: 1 }, text: '그 밖의 AI ' + idx.length + '명' }),
          lvChip(Net.lobby.seats[idx[0]].lv, (v) => { Net.aiLv = Net.aiLv || {}; idx.forEach((i) => { Net.aiLv[i] = v; }); hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }));
      })()) : null;
    const scr = h('div', { class: 'screen' }, topbarSimple('내 방', true),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '18px' } },
        h('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px', paddingTop: '10px' } },
          Net.lan ? h('span', { class: 'label', text: 'LAN 방 · 같은 와이파이' }) : h('span', { class: 'label', text: '방 코드' }),
          Net.lan ? h('button', { class: 'btn primary', text: '+ 친구 추가 (QR)', onclick: lanInvite }) : h('div', { class: 'code', text: Net.code }),
          h('p', { class: 'note', style: { margin: 0 }, text: Net.lan ? '친구가 ‘LAN 참가’를 누른 뒤, 한 명씩 QR을 서로 찍으면 연결돼요. 인터넷이 없어도 같은 와이파이면 돼요.' : L.STANDALONE ? '친구가 한판 라운지 앱에서 “코드로 참가”에 이 코드를 넣으면 들어와요. 인터넷에 연결되어 있어야 해요.' : '친구가 같은 링크를 열고 “코드로 참가”에 이 코드를 넣으면 들어와요. 링크는 참여 가능 권한으로 공유해 주세요.' })),
        h('div', { class: 'field' }, h('span', { class: 'label', text: '방에 있는 사람 · ' + people.length + '명' }), peopleList(people, Net.myPeer())),
        h('div', { class: 'field' }, gameBox, pickRow),
        g ? optRows(g, Net.lobby.opts || (Net.lobby.opts = optDefaults(g, null)), () => { store.set('opts.' + Net.lobby.game, Net.lobby.opts); hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); }) : null,
        g ? h('div', { class: 'field' },
          h('div', { class: 'row', style: { justifyContent: 'space-between' } }, h('span', { class: 'label', text: '자리' }),
            g.minPlayers !== g.maxPlayers ? h('div', { class: 'stepper' },
              h('button', { class: 'btn sm', text: '−', 'aria-label': '자리 줄이기', onclick() { if (Net.lobby.count > Math.max(g.minPlayers, 1 + Math.min(guests, maxFor(g, optDefaults(g, Net.lobby.opts)) - 1))) { Net.lobby.count--; hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); } } }),
              h('span', { class: 'v', text: Net.lobby.count }),
              h('button', { class: 'btn sm', text: '+', 'aria-label': '자리 늘리기', onclick() { if (Net.lobby.count < maxFor(g, optDefaults(g, Net.lobby.opts))) { Net.lobby.count++; hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); } } }),
              g.maxPlayers >= 16 ? h('button', { class: 'btn sm', text: '+5', 'aria-label': '자리 5개 늘리기', onclick() { Net.lobby.count = Math.min(maxFor(g, optDefaults(g, Net.lobby.opts)), Net.lobby.count + 5); hostSeats(); Net.pub({ lobby: Net.lobby }); renderHostLobby(); } }) : null) : null),
          seatList,
          h('p', { class: 'note', style: { margin: 0 }, text: g.noAI ? '이 게임은 사람끼리만 해요.' : '빈 자리는 AI가 맡아요. 친구가 들어오면 AI 자리를 대신 차지합니다.' })) : null,
        g ? h('button', { class: 'btn primary block', text: g.name + ' 시작', onclick: hostStart }) : null));
    show(scr);
  }
  function hostStart() {
    hostSeats();
    Net.lobby.started = Net.lobby.game;
    const me = Net.myPeer();
    const gdef = L.games[Net.lobby.game], oo = optDefaults(gdef, Net.lobby.opts);
    Net.lobby.seats = shuffleOrder(gdef, oo, Net.lobby.seats.map((s, i) => Object.assign({}, s, { c: i })));
    const players = Net.lobby.seats.map((s, i) => ({ name: s.n, ai: !!s.ai, local: s.p === me && !s.ai, color: COLORS[s.c != null ? s.c : i], lv: s.ai ? (s.lv || 2) : 0 }));
    Net.pub({ role: 'h', name: myName(), lobby: Net.lobby });
    startSession('host', Net.lobby.game, players, null, Net.lobby.opts);
    if (oo._order === 'rand') orderToast(players);
  }

  /* guest */
  function askName(then) {
    const o = overlay(h('div', { class: 'sheet' }, h('h2', { text: '이름을 정해 주세요' }), nameField('nm-ask'),
      h('button', { class: 'btn primary block', text: '확인', onclick() { const v = document.getElementById('nm-ask').value.trim().slice(0, 10); if (!v) return; store.set('name', v); o.remove(); then(); } })));
    setTimeout(() => { const i = document.getElementById('nm-ask'); i && i.focus(); }, 50);
  }
  function joinScreen() {
    endSession(); Net.leave();
    const scr = h('div', { class: 'screen' }, topbarSimple('코드로 참가'),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '18px' } },
        nameField('nm-join'),
        h('label', { class: 'field' }, h('span', { class: 'label', text: '방 코드' }),
          h('input', { id: 'code-join', maxlength: 4, placeholder: 'ABCD', autocapitalize: 'characters', autocomplete: 'off', class: 'mono', style: { fontSize: '28px', letterSpacing: '.2em', textTransform: 'uppercase' } })),
        h('button', { class: 'btn primary block', text: '참가', onclick: doJoin }),
        h('p', { class: 'note', text: '호스트와 같은 링크에서 열어야 같은 방에 들어갈 수 있어요.' })));
    show(scr);
  }
  async function doJoin() {
    const nm = document.getElementById('nm-join').value.trim().slice(0, 10);
    const code = document.getElementById('code-join').value.trim().toUpperCase().replace(/[^A-Z]/g, '');
    if (!nm) return toast('이름을 적어 주세요');
    if (code.length !== 4) return toast('코드 4글자를 넣어 주세요');
    store.set('name', nm);
    show(h('div', { class: 'screen' }, topbarSimple('방 ' + code), h('div', { class: 'scroll' }, h('p', { class: 'muted', text: '방에 들어가는 중…' }))));
    try { await Net.open(code); } catch (e) { return errorScreen(noRoomMsg(e)); }
    Net.lan = false;
    enterGuest(nm);
  }
  function enterGuest(nm) {
    Net.role = 'g';
    Net.k = 0;
    Net.pub({ role: 'g', name: nm });
    Net.hostSeen = Date.now();
    let waitedFor = Date.now();
    Net.unsub.push(Net.r.onPeers(() => onGuestPeers(), (e) => console.warn(e)));
    const watchdog = setInterval(() => {
      if (Net.role !== 'g') return clearInterval(watchdog);
      if (Net.hostPeer()) { Net.hostSeen = Date.now(); return; }
      if (Date.now() - Net.hostSeen > 6000) {
        clearInterval(watchdog);
        const had = Date.now() - waitedFor > 6500 && S;
        Net.leave(); endSession();
        errorScreen(had ? '호스트가 방을 나갔어요.' : '그 코드의 방을 찾지 못했어요. 코드를 다시 확인해 주세요.');
      }
    }, 1000);
    renderGuestLobby();
  }
  function onGuestPeers() {
    if (Net.role !== 'g') return;
    const hp = Net.hostPeer();
    if (!hp) return;
    Net.hostSeen = Date.now();
    const lobby = hp.presence.lobby;
    if (!lobby || !lobby.seats) return;
    Net.lobby = lobby;
    const me = Net.myPeer();
    const st = hp.presence.st;
    if (lobby.started && st && st.s && L.games[lobby.started]) {
      if (!S || S.gameId !== lobby.started) {
        Net.stVer = -1;
        startSession('guest', lobby.started, lobby.seats.map((s, i) => ({ name: s.n, ai: !!s.ai, local: s.p === me && !s.ai, color: COLORS[s.c != null ? s.c : i], lv: s.ai ? (s.lv || 2) : 0 })));
        if (optDefaults(L.games[lobby.started], lobby.opts)._order === 'rand') orderToast(S.players);
      } else {
        lobby.seats.forEach((s, i) => { if (S.players[i]) { S.players[i].ai = !!s.ai; S.players[i].name = s.n; S.players[i].local = s.p === me && !s.ai; } });
      }
      if (st.v !== Net.stVer) { Net.stVer = st.v; setState(st.s, true); }
    } else {
      if (S) { endSession(); Net.lobbySig = null; }
      const sig = JSON.stringify(lobby) + me;
      if (sig !== Net.lobbySig) { Net.lobbySig = sig; renderGuestLobby(); }
    }
  }
  function renderGuestLobby() {
    if (S || Net.role !== 'g') return;
    const lobby = Net.lobby;
    const me = Net.myPeer();
    const g = lobby && L.games[lobby.game];
    if (lobby && lobby.pick && lobby.pick.t !== Net.seenPick && g) { Net.seenPick = lobby.pick.t; if (lobby.pick.how) { toast('🎲 ' + lobby.pick.how + ': ' + g.name); Sfx.play('pop'); } }
    const scr = h('div', { class: 'screen' }, topbarSimple('방 ' + Net.code, true),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '12px' } },
        lobby ? h('div', { class: 'field' }, h('span', { class: 'label', text: '방에 있는 사람 · ' + (lobby.people || []).length + '명' }), peopleList(lobby.people, me)) : null,
        g ? h('div', { class: 'lobby-game', style: { '--tint': g.tint || TINT[lobby.game] || 'var(--surface)' } }, svgIcon(lobby.game),
            h('div', { class: 'lg-info' }, h('span', { class: 'label', text: '이번 게임' }), h('div', { class: 'nm', text: g.name }),
              h('span', { class: 'muted', text: g.minPlayers === g.maxPlayers ? g.minPlayers + '인' : g.minPlayers + '–' + g.maxPlayers + '인' })),
            L.games[lobby.game] && L.games[lobby.game].codex ? h('button', { class: 'btn sm', text: '📖 도감', onclick: () => codexSheet(lobby.game) }) : null,
            h('button', { class: 'btn sm', text: '규칙', onclick: () => rulesSheet(lobby.game) }))
          : h('div', { class: 'lobby-game empty' }, h('div', { class: 'lg-info' }, h('span', { class: 'label', text: '이번 게임' }),
            h('div', { class: 'nm', text: lobby ? '방장이 고르는 중…' : '방장을 찾는 중…' }))),
        g && lobby.seats ? h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } }, lobby.seats.map((s, i) => h('div', { class: 'seat' },
          h('span', { class: 'dot', style: { '--c': COLORS[i] } }), h('span', { class: 'nm', text: s.n }),
          h('span', { class: 'tag' + (s.p === me ? ' me' : ''), text: s.p === me ? '나' : i === 0 ? '방장' : s.ai ? 'AI' : '친구' })))) : null,
        g && lobby.opts ? optRows(g, lobby.opts, () => {}, true) : null,
        g && lobby && !lobby.seats.some((s) => s.p === me) ? h('p', { class: 'note', text: '자리가 다 찼어요. 이번 판은 구경만 할 수 있어요.' }) : null,
        h('p', { class: 'muted', text: g ? '방장이 시작하면 바로 게임이 열려요.' : '방장이 게임을 고르면 여기에 보여요.' })));
    show(scr);
  }

  async function lanInvite() {
    if (!Net.r || !Net.r.invite) return;
    const body = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } }, h('p', { class: 'muted', text: '연결 코드를 만드는 중…' }));
    let inv = null, linked = false;
    const o = overlay(h('div', { class: 'sheet' }, h('h2', { text: '친구 추가' }), body,
      h('button', { class: 'btn ghost block', text: '닫기', onclick() { if (inv && !linked) inv.cancel(); o.remove(); } })));
    try { inv = await Net.r.invite(); } catch (e) { body.innerHTML = ''; body.append(h('p', { text: '연결 코드를 만들지 못했어요.' })); return; }
    body.innerHTML = '';
    body.append(h('p', { class: 'note', style: { margin: 0 }, text: '1. 친구가 ‘LAN 참가’에서 이 QR을 찍어요.' }), await codeBox(inv.text),
      h('button', { class: 'btn primary block', text: '2. 친구 화면의 QR 찍기', async onclick() {
        const ans = await scanCode('친구의 응답 QR');
        if (!ans) return;
        body.innerHTML = ''; body.append(h('p', { class: 'muted', text: '연결하는 중…' }));
        try { await inv.accept(ans); linked = true; toast('친구가 연결됐어요'); buzz(30); o.remove(); }
        catch (e) { body.innerHTML = ''; body.append(h('p', { text: e.message === 'mismatch' ? '다른 친구의 응답이에요. 이 QR을 찍은 친구의 응답을 찍어 주세요.' : '연결하지 못했어요. 같은 와이파이인지 확인하고 다시 시도해 주세요.' })); }
      } }));
  }
  function lanJoinScreen() {
    endSession(); Net.leave();
    const area = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '12px' } });
    let pending = null;
    const scr = h('div', { class: 'screen' }, topbarSimple('LAN 참가'),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '16px', paddingTop: '18px' } },
        nameField('nm-lan'),
        h('button', { class: 'btn primary block', text: '호스트의 QR 찍기', async onclick() {
          const nm = document.getElementById('nm-lan').value.trim().slice(0, 10);
          if (!nm) return toast('이름을 적어 주세요');
          store.set('name', nm);
          const text = await scanCode('호스트의 QR');
          if (!text) return;
          area.innerHTML = ''; area.append(h('p', { class: 'muted', text: '응답 코드를 만드는 중…' }));
          try {
            if (pending) pending.cancel();
            pending = await Lan.join(text);
            area.innerHTML = '';
            area.append(h('p', { class: 'note', style: { margin: 0 }, text: '이제 호스트가 “친구 화면의 QR 찍기”로 이 QR을 찍으면 연결돼요.' }), await codeBox(pending.text));
            const R = await pending.ready;
            Net.r = R; Net.code = 'LAN'; Net.lan = true;
            toast('호스트와 연결됐어요'); buzz(30);
            enterGuest(nm);
          } catch (e) {
            area.innerHTML = '';
            area.append(h('p', { text: e.message === 'badcode' ? '한판 라운지 LAN QR이 아니에요.' : '연결하지 못했어요. 같은 와이파이인지 확인하고 처음부터 다시 해 주세요.' }));
          }
        } }),
        area,
        h('p', { class: 'note', text: '호스트가 ‘LAN 방 만들기’ → ‘친구 추가’를 누르면 QR이 나와요. 인터넷 없이 같은 와이파이에서 연결돼요.' })));
    show(scr);
  }

  function topbarSimple(title, leaveRoom) {
    return h('div', { class: 'topbar' },
      h('button', { class: 'iconbtn', 'aria-label': '뒤로', text: '‹', onclick() { if (leaveRoom) confirmSheet('방을 나갈까요?', Net.role === 'h' ? '방이 닫히고 친구들도 나가게 돼요.' : null, '나가기', homeScreen); else homeScreen(); } }),
      h('div', { class: 'title', text: title }));
  }
  function errorScreen(msg) {
    Net.leave();
    show(h('div', { class: 'screen' }, topbarSimple('온라인'),
      h('div', { class: 'scroll', style: { display: 'flex', flexDirection: 'column', gap: '14px', paddingTop: '24px' } },
        h('p', { text: msg }), h('button', { class: 'btn', text: '처음으로', onclick: homeScreen }))));
  }

  /* ---------- boot ---------- */
  L.boot = function () {
    homeScreen();
    document.addEventListener('gesturestart', (e) => e.preventDefault());
    if (L.STANDALONE) {
      // phone back button inside a game asks before leaving instead of closing the app
      window.addEventListener('popstate', () => {
        if (!S) return;
        try { history.pushState({ lounge: 'game' }, ''); } catch (e) {}
        if (!document.querySelector('.overlay:not(.result)')) leaveGame();
      });
    }
  };
  /* test hook: start a local game directly */
  L.debug.local = function (id, seats, opts) {   // opts: {optionId: value}, missing ones use defaults
    const g = L.games[id];
    seats = seats || Array.from({ length: g.defaultPlayers || g.minPlayers }, (_, i) => ({ name: 'AI ' + (i + 1), ai: true }));
    startSession('local', id, seats.map((s, i) => ({ name: s.name, ai: !!s.ai, local: !s.ai, color: COLORS[i], lv: s.lv || 2 })), null, optDefaults(g, opts));
    return S;
  };
  L.debug.home = () => homeScreen();
})();
