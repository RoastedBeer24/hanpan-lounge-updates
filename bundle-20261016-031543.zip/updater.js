/* 한판 라운지 — APK 자동 업데이트 (build_apk.py가 dist/apk-web/updater.js로 복사하며 __자리__를 채움).
   앱을 켤 때 공개 저장소의 version.json을 확인하고, 새 버전이 있으면 게임 파일 묶음(zip)을 몰래 받아 둔다.
   받아 둔 버전은 다음에 앱을 켤 때(처음 화면에서) 바로 적용한다 — 게임 도중에는 절대 다시 불러오지 않는다.
   인터넷이 없거나 실패하면 아무 일도 없이 지금 버전으로 계속 쓴다. */
(function () {
  'use strict';
  var BUILD = window.LOUNGE_BUILD || '';
  var NATIVE = 2;
  var URL = 'https://raw.githubusercontent.com/RoastedBeer24/hanpan-lounge-updates/main/version.json';
  var C = window.Capacitor;
  if (!C || !C.isNativePlatform || !C.isNativePlatform()) return;
  var U = C.Plugins && C.Plugins.CapacitorUpdater;
  if (!U) return;
  var KEY = 'lounge.pendingBundle';
  function get() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
  function put(v) { try { if (v) localStorage.setItem(KEY, JSON.stringify(v)); else localStorage.removeItem(KEY); } catch (e) {} }
  function atHome() { var L = window.Lounge; return !(L && L.session && L.session()); }

  U.notifyAppReady().catch(function () {});

  // 1) 지난번에 받아 둔 새 버전이 있으면 시작 화면에서 바로 적용
  var pend = get();
  if (pend && pend.version && pend.version !== BUILD && atHome()) {
    U.set({ id: pend.id }).catch(function () { put(null); });
    return;
  }
  if (pend && pend.version === BUILD) put(null);

  function banner(text, btn, onBtn) {
    var el = document.createElement('div');
    el.setAttribute('role', 'status');
    el.style.cssText = 'position:fixed;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom));z-index:60;' +
      'display:flex;gap:10px;align-items:center;padding:10px 12px;border-radius:14px;background:#2e2640;color:#f2e9d8;' +
      'box-shadow:0 8px 24px rgba(0,0,0,.45);font:500 14px/1.4 "IBM Plex Sans KR",system-ui,sans-serif';
    var t = document.createElement('span'); t.textContent = text; t.style.flex = '1'; el.appendChild(t);
    if (btn) {
      var b = document.createElement('button'); b.textContent = btn;
      b.style.cssText = 'min-height:44px;padding:0 14px;border:0;border-radius:10px;background:#e3ae45;color:#2a1d05;font:700 14px system-ui,sans-serif';
      b.onclick = onBtn; el.appendChild(b);
    }
    var x = document.createElement('button'); x.textContent = '✕'; x.setAttribute('aria-label', '닫기');
    x.style.cssText = 'min-width:44px;min-height:44px;border:0;background:transparent;color:#ab9fb8;font-size:18px';
    x.onclick = function () { el.remove(); }; el.appendChild(x);
    document.body.appendChild(el);
    return el;
  }

  // 2) 새 버전 확인 → 몰래 받기
  function check() {
    var ctl = window.AbortController ? new AbortController() : null;
    if (ctl) setTimeout(function () { ctl.abort(); }, 8000);
    fetch(URL + '?t=' + Date.now(), { cache: 'no-store', signal: ctl ? ctl.signal : undefined })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (v) {
        if (!v || !v.version || v.version === BUILD) return;
        if ((v.minNative || 1) > NATIVE) { banner('새 버전 앱(APK)이 나왔어요. 새로 설치해 주세요.'); return; }
        return U.list().then(function (l) {
          var have = (l && l.bundles || []).filter(function (b) { return b.version === v.version && b.status === 'success'; })[0];
          return have || U.download({ url: v.url, version: v.version, checksum: v.sha256 });
        }).then(function (b) {
          put({ id: b.id, version: v.version });
          var el = banner('새 버전을 받았어요. 다음에 켤 때 적용돼요.', '지금 적용', function () {
            if (!atHome()) { el.remove(); return; }
            U.set({ id: b.id }).catch(function () {});
          });
        });
      })
      .catch(function () { /* 오프라인 등 — 조용히 넘어감 */ });
  }
  if (document.readyState === 'complete') setTimeout(check, 2500);
  else window.addEventListener('load', function () { setTimeout(check, 2500); });
})();
