/* 로봇 명령 카드 대결 — simultaneous-programming toy-robot race on a factory floor (1–4 players).
   Every round each robot gets a hand (8 cards − damage) from a freshly shuffled deck and secretly puts 5 of them into
   its program slots (array actor: everyone programs at the same time). When all have locked in, the 5 steps run:
     1) cards in priority order: turns → forward 3 → forward 2 → forward 1 → back (same card: the rotating ★ lead first)
     2) fast belts move 1 → all belts move 1   3) turntables rotate   4) wall lasers fire (1–2 damage)   5) flag check.
   Robots push each other (chains, walls stop everything). Pits / board edge / 4 damage (overheat) → reboot: the rest of
   the round is lost and the robot returns next round at its restart point (last flag or charger) with 1 damage.
   Oil: a robot that walks onto oil slides one more cell. Chargers: ending a round there repairs 1 and saves the spot.
   apply() runs the whole round at once; state.last = {id, pre, p, ld} lets every device re-run the same deterministic
   simulation for the step-by-step animation and for the replay / step-through. Solo: reach all flags within the round
   limit, stars by rounds used. Pass-and-play on one phone gets its own hand-over screen (hidden programs). */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util, h = L.h;
  const W = 10, H = 12;
  const DX = [0, 1, 0, -1], DY = [-1, 0, 1, 0];
  const KINDS = '123BLRU';
  const RANK = { L: 0, R: 0, U: 0, '3': 1, '2': 2, '1': 3, B: 4 };
  const CN = { '1': '앞으로 1', '2': '앞으로 2', '3': '앞으로 3', B: '뒤로 1', L: '왼쪽 돌기', R: '오른쪽 돌기', U: '유턴', '-': '쉬기' };
  const CS = { '1': '앞 1', '2': '앞 2', '3': '앞 3', B: '뒤로', L: '왼쪽', R: '오른쪽', U: '유턴', '-': '' };
  const DECK = { '1': 18, '2': 12, '3': 6, B: 6, L: 16, R: 16, U: 6 };
  const MAXDMG = 4, HAND = 8, SLOTS = 5;
  const BD = { n: 0, e: 1, s: 2, w: 3, N: 0, E: 1, S: 2, W: 3 };
  const CIRC = ['①', '②', '③', '④', '⑤'];

  /* ======================= factory floors (10 × 12) =======================
     .  floor   O pit   n e s w belt (↑ → ↓ ←)   N E S W fast belt   c turntable ↻   a turntable ↺   ~ oil   + charger
     wl: walls [x, y, side]   lz: wall lasers [x, y, fire direction 0↑1→2↓3←, power]   fl: flags in order   par: solo
     star target (rounds) for 2 / 3 / 4 flags. Robots start on row 11 facing up. */
  const DEFS = [
    { nm: '조립 라인', hint: '처음 하기 좋은 기본 공장', t: [
      '..........',
      '.+........',
      '....O.....',
      'eeeeeees..',
      '.......s..',
      '..c....s..',
      '......a...',
      '.O......O.',
      '.....+....',
      '...wwww...',
      '..........',
      '..........'],
      wl: [[3, 5, 'E'], [7, 1, 'W'], [5, 7, 'N'], [6, 7, 'N']], lz: [[0, 6, 1, 1]], fl: [[8, 5], [2, 1], [7, 0], [4, 5]], par: [5, 6, 8] },
    { nm: '톱니 공방', hint: '회전판이 가득 — 방향을 잘 봐요', t: [
      '..........',
      '..a....c..',
      '....c.....',
      '.c.....a..',
      '...O..O...',
      '..........',
      'a...cc...a',
      '..........',
      '..c....a..',
      '....OO....',
      '..........',
      '..........'],
      wl: [[4, 3, 'S'], [5, 3, 'S'], [2, 7, 'E'], [7, 7, 'W']], lz: [[9, 3, 3, 1]], fl: [[5, 5], [8, 0], [1, 2], [7, 7]], par: [4, 6, 8] },
    { nm: '기름 창고', hint: '기름 칸을 밟으면 한 칸 더 미끄러져요', t: [
      '..........',
      '..~~..~~..',
      '..~~..~~..',
      '..........',
      'O...~~...O',
      '....~~....',
      '..+.......',
      '.~~....~~.',
      '.~~..O.~~.',
      '..........',
      '..........',
      '..........'],
      wl: [[3, 3, 'E'], [6, 3, 'W'], [9, 1, 'S']], lz: [[0, 5, 1, 1]], fl: [[5, 3], [9, 0], [0, 2], [4, 6]], par: [3, 5, 7] },
    { nm: '순환 벨트', hint: '빠른 벨트가 공장을 한 바퀴 돌아요', t: [
      '..........',
      '.EEEEEEES.',
      '.N......S.',
      '.N.O..+.S.',
      '.N......S.',
      '.N..a...S.',
      '.N......S.',
      '.NWWWWWWW.',
      '..........',
      '...O..O...',
      '..........',
      '..........'],
      wl: [[3, 8, 'S'], [0, 4, 'E']], lz: [[3, 0, 2, 1]], fl: [[6, 5], [9, 1], [0, 0], [4, 4]], par: [3, 6, 7] },
    { nm: '레이저 검사실', hint: '레이저가 4줄! 벽 뒤로 숨어요', t: [
      '..........',
      '..........',
      '..+....+..',
      '..........',
      '...O..O...',
      '..........',
      '..........',
      '....cc....',
      '..........',
      '..........',
      '..........',
      '..........'],
      wl: [[2, 3, 'S'], [7, 3, 'S'], [4, 6, 'N'], [5, 6, 'N'], [6, 1, 'E'], [3, 5, 'E'], [4, 3, 'W']],
      lz: [[0, 1, 1, 1], [9, 3, 3, 2], [0, 5, 1, 1], [9, 8, 3, 1]], fl: [[5, 4], [1, 0], [8, 1], [4, 9]], par: [5, 7, 10] },
    { nm: '구멍 숭숭', hint: '구덩이 사이를 조심조심', t: [
      '..........',
      '.O..O..O..',
      '..........',
      'O..O..O..O',
      '..........',
      '.O..O..O..',
      '..........',
      'O..O..O..O',
      '..........',
      '..O....O..',
      '..........',
      '..........'],
      wl: [[4, 4, 'S'], [5, 4, 'S']], lz: [[9, 8, 3, 1]], fl: [[5, 6], [2, 2], [8, 0], [0, 4]], par: [3, 5, 8] },
    { nm: '포장 센터', hint: '벨트가 엇갈리는 바쁜 공장', t: [
      '..s....n..',
      '..s....n..',
      '..s.O..n..',
      '..s....n..',
      'wwwwwwwwww',
      '..........',
      '..+...a...',
      '.eeeeeeee.',
      '..........',
      '....O.....',
      '..........',
      '..........'],
      wl: [[7, 0, 'N'], [0, 4, 'W'], [4, 6, 'E']], lz: [[9, 9, 3, 1]], fl: [[5, 2], [9, 5], [0, 1], [5, 8]], par: [4, 6, 8] },
    { nm: '미로 창고', hint: '벽이 많아요 — 돌아가는 길을 찾아요', t: [
      '..........',
      '....+.....',
      '..........',
      '...O......',
      '..........',
      '......O...',
      '..........',
      '..........',
      '..........',
      '..........',
      '..........',
      '..........'],
      wl: [[2, 1, 'E'], [2, 2, 'E'], [2, 3, 'E'], [2, 4, 'E'], [6, 4, 'E'], [6, 5, 'E'], [6, 6, 'E'], [6, 7, 'E'], [6, 8, 'E'],
        [1, 7, 'S'], [2, 7, 'S'], [3, 7, 'S'], [4, 7, 'S'], [5, 2, 'S'], [6, 2, 'S'], [7, 2, 'S'], [8, 2, 'S'],
        [0, 5, 'S'], [8, 9, 'N'], [9, 5, 'S'], [3, 9, 'E'], [4, 0, 'E']],
      lz: [[9, 0, 2, 1]], fl: [[1, 5], [8, 3], [4, 0], [8, 7]], par: [5, 7, 9] },
    { nm: '대혼잡 공장', hint: '벨트·기름·레이저 전부! 고수용', t: [
      '..~...ES..',
      '.c....NS..',
      '....O.NS..',
      '..a...NS.O',
      '......NS..',
      '~~....NWW.',
      '......+...',
      '.O..c.....',
      '....eeee..',
      '...O......',
      '..........',
      '..........'],
      wl: [[5, 0, 'E'], [8, 3, 'S'], [2, 6, 'N']], lz: [[0, 2, 1, 1], [9, 7, 3, 1]], fl: [[3, 6], [9, 1], [1, 3], [4, 1]], par: [4, 6, 7] },
  ];
  const DOCKS = [[3, 11], [6, 11], [1, 11], [8, 11]];
  const SOLO_DOCK = [4, 11];

  function parse(d, idx) {
    const t = d.t.join('');
    const wall = new Uint8Array(W * H);
    const addW = (x, y, dir) => {
      if (x < 0 || y < 0 || x >= W || y >= H || dir < 0) return;
      wall[y * W + x] |= 1 << dir;
      const nx = x + DX[dir], ny = y + DY[dir];
      if (nx >= 0 && ny >= 0 && nx < W && ny < H) wall[ny * W + nx] |= 1 << ((dir + 2) % 4);
    };
    (d.wl || []).forEach((w) => addW(w[0], w[1], 'NESW'.indexOf(w[2])));
    return { i: idx, nm: d.nm, hint: d.hint, t, wall, lz: d.lz || [], fl: d.fl, par: d.par, fields: [] };
  }
  const BOARDS = DEFS.map(parse);

  const inB = (x, y) => x >= 0 && y >= 0 && x < W && y < H;
  const blocked = (B, x, y, d) => inB(x, y) && ((B.wall[y * W + x] >> d) & 1) === 1;
  const holeAt = (B, x, y) => !inB(x, y) || B.t[y * W + x] === 'O';
  const tileAt = (B, x, y) => (inB(x, y) ? B.t[y * W + x] : 'X');

  /* distance (cells) to flag k, walls respected, pits impassable */
  function field(B, k) {
    if (B.fields[k]) return B.fields[k];
    const f = new Int16Array(W * H).fill(99);
    const fx = B.fl[k][0], fy = B.fl[k][1];
    const q = [fy * W + fx]; f[fy * W + fx] = 0;
    for (let hd = 0; hd < q.length; hd++) {
      const c = q[hd], x = c % W, y = (c / W) | 0;
      for (let d = 0; d < 4; d++) {
        if (blocked(B, x, y, d)) continue;
        const nx = x + DX[d], ny = y + DY[d];
        if (!inB(nx, ny)) continue;
        const nc = ny * W + nx;
        if (B.t[nc] === 'O' || f[nc] <= f[c] + 1) continue;
        f[nc] = f[c] + 1; q.push(nc);
      }
    }
    return (B.fields[k] = f);
  }
  /* AI distance: like field() but cells inside a laser line cost extra (1 + 2 × power), so bots route around beams */
  function aiField(B, k) {
    if (B.afields && B.afields[k]) return B.afields[k];
    if (!B.afields) B.afields = [];
    const pen = new Uint8Array(W * H);
    for (const lz of B.lz) {
      let x = lz[0], y = lz[1];
      for (let g = 0; g < 30; g++) {
        pen[y * W + x] += 2 * lz[3];
        if (blocked(B, x, y, lz[2])) break;
        x += DX[lz[2]]; y += DY[lz[2]];
        if (!inB(x, y)) break;
      }
    }
    const f = new Int16Array(W * H).fill(999);
    const fx = B.fl[k][0], fy = B.fl[k][1];
    f[fy * W + fx] = 0;
    const bk = [[fy * W + fx]];
    for (let c0 = 0; c0 < bk.length; c0++) {
      const list = bk[c0];
      if (!list) continue;
      for (const c of list) {
        if (f[c] !== c0) continue;
        const x = c % W, y = (c / W) | 0;
        for (let d = 0; d < 4; d++) {
          if (blocked(B, x, y, d)) continue;
          const nx = x + DX[d], ny = y + DY[d];
          if (!inB(nx, ny)) continue;
          const nc = ny * W + nx;
          if (B.t[nc] === 'O') continue;
          const nd = c0 + 1 + pen[c];
          if (nd >= f[nc]) continue;
          f[nc] = nd;
          (bk[nd] || (bk[nd] = [])).push(nc);
        }
      }
    }
    return (B.afields[k] = f);
  }

  /* ======================= simulation (shared by apply, AI, ghost preview and the view) ======================= */
  const unpack = (a) => ({ x: a[0], y: a[1], d: a[2], m: a[3], f: a[4], rx: a[5], ry: a[6], o: 0 });
  const pack = (r) => [r.x, r.y, r.d, r.m, r.f, r.rx, r.ry];
  const cloneR = (R) => R.map((r) => ({ x: r.x, y: r.y, d: r.d, m: r.m, f: r.f, rx: r.rx, ry: r.ry, o: r.o }));

  function occ(R, x, y) {
    for (let i = 0; i < R.length; i++) { const r = R[i]; if (!r.o && r.x === x && r.y === y) return i; }
    return -1;
  }
  /* move robot i one cell toward d, pushing every robot in the way; a wall anywhere in the chain stops all of them */
  function push(B, R, i, d, ev) {
    const chain = [i];
    let x = R[i].x, y = R[i].y;
    for (;;) {
      if (blocked(B, x, y, d)) return false;
      x += DX[d]; y += DY[d];
      if (!inB(x, y)) break;
      const j = occ(R, x, y);
      if (j < 0) break;
      chain.push(j);
    }
    for (const k of chain) { R[k].x += DX[d]; R[k].y += DY[d]; }
    for (const k of chain) if (holeAt(B, R[k].x, R[k].y)) { R[k].o = 1; if (ev) ev.fall.push(k); }
    if (ev && chain.length > 1) ev.pu = chain.slice(1);
    return true;
  }
  function doCard(B, R, i, c, st, rec) {
    const r = R[i];
    if (c === 'L' || c === 'R' || c === 'U') {
      r.d = (r.d + (c === 'L' ? 3 : c === 'R' ? 1 : 2)) % 4;
      if (rec) rec({ ph: 'card', st, a: i, c, dur: c === 'U' ? 420 : 320 });
      return;
    }
    const md = c === 'B' ? (r.d + 2) % 4 : r.d;
    const k = c === 'B' ? 1 : +c;
    let moved = false;
    for (let s = 0; s < k && !r.o; s++) {
      const ev = rec ? { fall: [], pu: null } : null;
      if (!push(B, R, i, md, ev)) { if (rec) rec({ ph: 'card', st, a: i, c, bump: 1, dur: 260 }); break; }
      moved = true;
      if (rec) rec({ ph: 'card', st, a: i, c, fall: ev.fall, pu: ev.pu, dur: ev.fall.length ? 460 : 300 });
    }
    for (let s = 0; moved && s < 3 && !r.o && B.t[r.y * W + r.x] === '~'; s++) {   // oil: slide one more cell
      const ev = rec ? { fall: [], pu: null } : null;
      if (!push(B, R, i, md, ev)) break;
      if (rec) rec({ ph: 'oil', st, a: i, c, fall: ev.fall, pu: ev.pu, dur: 340 });
    }
  }
  function belts(B, R, fast, st, rec) {
    const mv = [];
    for (let i = 0; i < R.length; i++) {
      const r = R[i];
      if (r.o) continue;
      const ch = B.t[r.y * W + r.x], d = BD[ch];
      if (d == null || (fast && ch !== ch.toUpperCase())) continue;
      mv.push({ i, d, tx: r.x + DX[d], ty: r.y + DY[d], ok: !blocked(B, r.x, r.y, d) });
    }
    if (!mv.length) return;
    for (const m of mv) if (m.ok) for (const o of mv) if (o !== m && !blocked(B, R[o.i].x, R[o.i].y, o.d) && o.tx === m.tx && o.ty === m.ty) m.ok = false;
    for (let ch = true; ch;) {   // a robot in the way that does not move (or is stuck) blocks; head-on swaps block both
      ch = false;
      for (const m of mv) {
        if (!m.ok || !inB(m.tx, m.ty)) continue;
        const j = occ(R, m.tx, m.ty);
        if (j < 0) continue;
        const o = mv.find((q) => q.i === j);
        if (!o || !o.ok || (o.tx === R[m.i].x && o.ty === R[m.i].y)) { m.ok = false; ch = true; }
      }
    }
    let any = false;
    const fall = [];
    for (const m of mv) if (m.ok) { R[m.i].x = m.tx; R[m.i].y = m.ty; any = true; }
    for (const m of mv) if (m.ok && holeAt(B, m.tx, m.ty)) { R[m.i].o = 1; fall.push(m.i); }
    if (any && rec) rec({ ph: fast ? 'fbelt' : 'belt', st, fall, dur: fall.length ? 480 : 380 });
  }
  function gears(B, R, st, rec) {
    let any = false;
    for (const r of R) {
      if (r.o) continue;
      const c = B.t[r.y * W + r.x];
      if (c === 'c') { r.d = (r.d + 1) % 4; any = true; } else if (c === 'a') { r.d = (r.d + 3) % 4; any = true; }
    }
    if (any && rec) rec({ ph: 'gear', st, dur: 400 });
  }
  function laserTrace(B, R, lz) {
    let x = lz[0], y = lz[1];
    const d = lz[2];
    for (let g = 0; g < 30; g++) {
      const j = R ? occ(R, x, y) : -1;
      if (j >= 0) return [x, y, j];
      if (blocked(B, x, y, d)) return [x, y, -1];
      const nx = x + DX[d], ny = y + DY[d];
      if (!inB(nx, ny)) return [x, y, -1];
      x = nx; y = ny;
    }
    return [x, y, -1];
  }
  function lasers(B, R, st, rec) {
    if (!B.lz.length) return;
    const bm = [], hit = [];
    for (const lz of B.lz) {
      const e = laserTrace(B, R, lz);
      bm.push([lz[0], lz[1], e[0], e[1], lz[2], e[2], lz[3]]);
      if (e[2] >= 0) hit.push([e[2], lz[3]]);
    }
    for (const q of hit) R[q[0]].m = Math.min(MAXDMG, R[q[0]].m + q[1]);
    const heat = [];
    for (let i = 0; i < R.length; i++) if (!R[i].o && R[i].m >= MAXDMG) { R[i].o = 2; heat.push(i); }
    if (rec && hit.length) rec({ ph: 'laser', st, bm, hit, heat, dur: heat.length ? 800 : 640 });
  }
  function flags(B, K, R, st, rec, wins) {
    const got = [];
    for (let i = 0; i < R.length; i++) {
      const r = R[i];
      if (r.o || r.f >= K) continue;
      const fl = B.fl[r.f];
      if (r.x === fl[0] && r.y === fl[1]) {
        r.f++; r.rx = fl[0]; r.ry = fl[1];
        got.push([i, r.f]);
        if (r.f >= K) wins.push(i);
      }
    }
    if (got.length && rec) rec({ ph: 'flag', st, got, dur: 760 });
  }
  function chargers(B, R, rec) {
    const hl = [];
    for (let i = 0; i < R.length; i++) {
      const r = R[i];
      if (r.o || B.t[r.y * W + r.x] !== '+') continue;
      if (r.m > 0) r.m--;
      r.rx = r.x; r.ry = r.y; hl.push(i);
    }
    if (hl.length && rec) rec({ ph: 'heal', st: 4, hl, dur: 620 });
  }
  function simStep(B, K, R, cards, lead, st, rec, wins) {
    const n = R.length, ord = [];
    for (let i = 0; i < n; i++) if (!R[i].o && cards[i] && cards[i] !== '-') ord.push(i);
    ord.sort((a, b) => RANK[cards[a]] - RANK[cards[b]] || ((a - lead + n) % n) - ((b - lead + n) % n));
    if (rec) rec({ ph: 'ord', st, ord: ord.map((i) => [i, cards[i]]), dur: 620 });
    for (const i of ord) if (!R[i].o) doCard(B, R, i, cards[i], st, rec);
    belts(B, R, true, st, rec);
    belts(B, R, false, st, rec);
    gears(B, R, st, rec);
    lasers(B, R, st, rec);
    flags(B, K, R, st, rec, wins);
    if (rec) rec({ ph: 'end', st, dur: 0 });
  }
  function simRound(B, K, R, P, lead, rec) {
    const wins = [];
    for (let st = 0; st < SLOTS && !wins.length; st++) simStep(B, K, R, P.map((p) => (p ? p[st] || '-' : '-')), lead, st, rec, wins);
    if (!wins.length) chargers(B, R, rec);
    return wins;
  }
  function faceBest(B, K, r) {
    const f = field(B, Math.min(r.f, K - 1));
    let bd = 0, bv = 1e9;
    for (let d = 0; d < 4; d++) {
      if (blocked(B, r.x, r.y, d)) continue;
      const nx = r.x + DX[d], ny = r.y + DY[d];
      if (!inB(nx, ny)) continue;
      const v = f[ny * W + nx] + (B.t[ny * W + nx] === 'O' ? 500 : 0);
      if (v < bv) { bv = v; bd = d; }
    }
    return bd;
  }
  /* back on the board at the restart point (or the nearest free safe cell), 1 damage, facing the next flag */
  function respawn(B, K, R, i) {
    const r = R[i];
    let pos = null;
    for (let rad = 0; rad < 22 && !pos; rad++) {
      for (let dy = -rad; dy <= rad && !pos; dy++) {
        const ax = rad - Math.abs(dy);
        for (const dx of ax ? [-ax, ax] : [0]) {
          const x = r.rx + dx, y = r.ry + dy;
          if (!inB(x, y) || B.t[y * W + x] === 'O' || occ(R, x, y) >= 0) continue;
          pos = [x, y]; break;
        }
      }
    }
    if (!pos) pos = [r.rx, r.ry];
    r.x = pos[0]; r.y = pos[1]; r.o = 0; r.m = 1;
    r.d = faceBest(B, K, r);
  }

  /* ======================= game logic ======================= */
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  const sortHand = (arr) => arr.sort((a, b) => KINDS.indexOf(a) - KINDS.indexOf(b)).join('');
  function deal(s) {
    const deck = [];
    for (const c in DECK) for (let i = 0; i < DECK[c]; i++) deck.push(c);
    shuffle(deck);
    s.h = s.rb.map((a) => sortHand(deck.splice(0, HAND - a[3])));
  }
  function init(players, opts) {
    opts = opts || {};
    const n = Math.max(1, Math.min(4, players.length));
    let b = opts.map != null ? +opts.map : -1;
    if (!(b >= 0 && b < BOARDS.length)) b = Math.floor(Math.random() * BOARDS.length);
    const k = [2, 3, 4].includes(+opts.flags) ? +opts.flags : 3;
    const cap = [10, 15, 20].includes(+opts.cap) ? +opts.cap : 15;
    const rb = [];
    for (let i = 0; i < n; i++) {
      const p = n === 1 ? SOLO_DOCK : DOCKS[i];
      rb.push([p[0], p[1], 0, 0, 0, p[0], p[1]]);
    }
    const s = { b, k, cap, n, r: 0, ld: 0, ph: 'p', rb, h: [], pg: Array(n).fill(null), last: null, seq: 0, win: null, to: 0 };
    deal(s);
    return s;
  }
  function actor(s) {
    // every seat is listed while programming (so the core never puts up its single-seat curtain); seats that already
    // locked in are rejected by apply and skipped by aiDelayFor
    return s.ph === 'p' ? Array.from({ length: s.n }, (_, i) => i) : null;
  }
  function distNext(s, r) {
    const B = BOARDS[s.b];
    if (r[4] >= s.k) return 0;
    return field(B, r[4])[r[1] * W + r[0]];
  }
  function runRound(s) {
    const B = BOARDS[s.b], R = s.rb.map(unpack);
    const pre = s.rb.map((a) => a.slice());
    const wins = simRound(B, s.k, R, s.pg, s.ld, null);
    s.seq++;
    s.last = { id: s.seq, pre, p: s.pg.slice(), ld: s.ld, r: s.r };
    for (let i = 0; i < R.length; i++) if (R[i].o) respawn(B, s.k, R, i);
    s.rb = R.map(pack);
    s.pg = s.pg.map(() => null);
    if (wins.length) { s.win = wins; s.ph = 'e'; s.h = s.h.map(() => ''); return; }
    s.r++;
    if (s.r >= s.cap) {
      s.ph = 'e'; s.to = 1; s.h = s.h.map(() => '');
      if (s.n === 1) { s.win = []; return; }
      let best = null;
      const key = (i) => s.rb[i][4] * 1000 - distNext(s, s.rb[i]);
      for (let i = 0; i < s.n; i++) if (best == null || key(i) > best) best = key(i);
      s.win = [];
      for (let i = 0; i < s.n; i++) if (key(i) === best) s.win.push(i);
      return;
    }
    s.ld = (s.ld + 1) % s.n;
    deal(s);
  }
  function apply(s, seat, a) {
    if (!a || s.ph !== 'p') throw new Error('not now');
    if (seat < 0 || seat >= s.n) throw new Error('bad seat');
    if (a.t === 'unprog') {
      if (s.pg[seat] == null) throw new Error('nothing to undo');
      s.pg[seat] = null;
      return s;
    }
    if (a.t !== 'prog') throw new Error('bad action');
    if (s.pg[seat] != null) throw new Error('already programmed');
    const p = String(a.p || '');
    if (p.length !== SLOTS) throw new Error('need 5 cards');
    const hand = s.h[seat].split('');
    for (const c of p) {
      const j = hand.indexOf(c);
      if (j < 0) throw new Error('card not in hand');
      hand.splice(j, 1);
    }
    s.pg[seat] = p;
    if (s.pg.every((x) => x != null)) runRound(s);
    return s;
  }
  function stars(s, used) {
    const par = BOARDS[s.b].par[s.k - 2];
    return used <= par ? 3 : used <= par + 2 ? 2 : 1;
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const B = BOARDS[s.b];
    if (s.n === 1) {
      const par = B.par[s.k - 2];
      if (s.win && s.win.length && !s.to) {
        const used = s.r + 1, sc = stars(s, used);
        return { winners: [0], title: '★'.repeat(sc) + '☆'.repeat(3 - sc) + ' 도전 성공!',
          text: used + '라운드 만에 깃발 ' + s.k + '개를 모두 찍었어요.\n별 기준(' + B.nm + '): ★★★ ' + par + '라운드 이하 · ★★ ' + (par + 2) + '라운드 이하' };
      }
      return { winners: [], title: '도전 실패', text: s.cap + '라운드 안에 깃발을 다 찍지 못했어요 (' + s.rb[0][4] + '/' + s.k + '개).\n★★★ 기준은 ' + par + '라운드예요. 다시 도전!' };
    }
    if (s.to) return { winners: s.win, text: s.cap + '라운드가 끝났어요. 깃발을 가장 많이 찍은 로봇이 승리!\n(같으면 다음 깃발에 더 가까운 로봇)' };
    return { winners: s.win, text: '깃발 ' + s.k + '개를 순서대로 가장 먼저 모두 찍었어요!' };
  }

  /* ======================= AI ======================= */
  const FALLPEN = [0, 60, 160, 130];
  const DMGPEN = [[0, 4, 8, 12, 16], [0, 4, 8, 12, 16], [0, 6, 12, 18, 24], [0, 8, 20, 40, 60]];
  function evalBot(B, K, r, lv) {
    if (r.f >= K) return 1e6;
    const fd = lv >= 2 ? aiField(B, Math.min(r.f, K - 1)) : field(B, Math.min(r.f, K - 1));
    // a reboot costs the rest of the round but brings the robot back at its restart point with 1 damage
    if (r.o) return r.f * 1000 - FALLPEN[lv] - fd[r.ry * W + r.rx] * 10 - DMGPEN[lv][1];
    const here = fd[r.y * W + r.x];
    let v = r.f * 1000 - here * 10 - DMGPEN[lv][Math.min(4, r.m)];
    if (!blocked(B, r.x, r.y, r.d)) {
      const nx = r.x + DX[r.d], ny = r.y + DY[r.d];
      if (inB(nx, ny) && fd[ny * W + nx] < here) v += lv >= 3 ? 6 : 4;
    }
    return v;
  }
  function bestProgram(s, seat, lv) {
    const B = BOARDS[s.b], K = s.k, hand = s.h[seat];
    if (lv >= 3) {
      /* exhaustive search over all distinct orders; other robots stay put as obstacles (they can be pushed);
         leaves also look one idle step ahead (belts/lasers next round) */
      const R0 = s.rb.map(unpack), n = R0.length, cards = Array(n).fill('-'), dash = Array(n).fill('-');
      const cnt = {};
      for (const c of hand) cnt[c] = (cnt[c] || 0) + 1;
      const types = Object.keys(cnt);
      let best = -1e9, bestP = null;
      const prog = [];
      const leaf = (Rc) => {
        const R2 = cloneR(Rc);
        if (!R2[seat].o && R2[seat].f < K) chargers(B, R2, null);
        let v = evalBot(B, K, R2[seat], lv);
        if (!R2[seat].o && R2[seat].f < K) {
          const R3 = cloneR(R2);
          simStep(B, K, R3, dash, s.ld, 0, null, []);
          if (R3[seat].o) v -= 120; else if (R3[seat].m > R2[seat].m) v -= 8 * (R3[seat].m - R2[seat].m);
        }
        return v;
      };
      const dfs = (depth, Rc) => {
        if (depth === SLOTS || Rc[seat].o || Rc[seat].f >= K) {
          const v = leaf(Rc) + (Rc[seat].f >= K ? (SLOTS - depth) * 10 : 0);
          if (v > best) {
            best = v; bestP = prog.slice();
            for (const c of types) for (let q = 0; q < cnt[c]; q++) if (bestP.length < SLOTS) bestP.push(c);
          }
          return;
        }
        for (const c of types) {
          if (!cnt[c]) continue;
          cnt[c]--; prog.push(c);
          const R2 = cloneR(Rc);
          cards[seat] = c;
          simStep(B, K, R2, cards, s.ld, depth, null, []);
          cards[seat] = '-';
          dfs(depth + 1, R2);
          prog.pop(); cnt[c]++;
        }
      };
      dfs(0, R0);
      return bestP.join('');
    }
    // lv 1–2: random samples, my robot alone on the board
    const tries = lv <= 1 ? 24 : 140;
    let best = -1e9, bestP = null;
    const arr = hand.split('');
    for (let t = 0; t < tries; t++) {
      shuffle(arr);
      const p = arr.slice(0, SLOTS).join('');
      const R = [unpack(s.rb[seat])];
      simRound(B, K, R, [p], 0, null);
      let v = evalBot(B, K, R[0], lv);
      if (lv <= 1) v += (Math.random() - 0.5) * 50;
      if (v > best) { best = v; bestP = p; }
    }
    if (lv <= 1 && Math.random() < 0.12) {   // beginner slip: two cards swapped
      const a = bestP.split(''), i = Math.floor(Math.random() * SLOTS), j = Math.floor(Math.random() * SLOTS);
      const t = a[i]; a[i] = a[j]; a[j] = t; bestP = a.join('');
    }
    return bestP;
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.ph !== 'p' || s.pg[seat] != null) return null;
    return { t: 'prog', p: bestProgram(s, seat, lv) };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.ph !== 'p' || s.pg[seat] != null) return -1;
    // the core restarts AI timers whenever someone locks in, so later bots wait less
    const done = s.pg.filter((x) => x != null).length;
    return Math.max(300, [0, 1700, 1300, 1000][lv || 2] - done * 450) + seat * 90;
  }

  /* ======================= view ======================= */
  const ICO = {
    up: 'M12 2.5l7.5 8.5H14.6V21.5H9.4V11H4.5z',
    tl: 'M17.5 21.5V12.5c0-2.2-1.8-4-4-4H9.2V4L2.5 10.2 9.2 16.4V12h4.2c.3 0 .6.3.6.6v8.9z',
    ut: 'M4.5 21.5V9.5a7.5 7.5 0 0 1 15 0V14H22.5l-5.5 7-5.5-7H15V9.5a3 3 0 0 0-6 0v12z',
  };
  function icon(c) {
    let inner = '';
    if (c === '1' || c === '2' || c === '3') inner = '<path d="' + ICO.up + '"/>';
    else if (c === 'B') inner = '<path transform="rotate(180 12 12)" d="' + ICO.up + '"/>';
    else if (c === 'L') inner = '<path d="' + ICO.tl + '"/>';
    else if (c === 'R') inner = '<path transform="matrix(-1 0 0 1 24 0)" d="' + ICO.tl + '"/>';
    else if (c === 'U') inner = '<path d="' + ICO.ut + '"/>';
    return '<svg viewBox="0 0 24 24" aria-hidden="true">' + inner + '</svg>';
  }
  const kcls = (c) => (c === 'L' || c === 'R' ? 't' : c === 'B' ? 'b' : c === 'U' ? 'u' : c === '-' ? 'x' : 'f');
  const FLAGSVG = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2.5 11.5V1.2" stroke="currentColor" stroke-width="1.4"/><path d="M3.2 1.4h7l-2 2.4 2 2.4h-7z" fill="#e3ae45"/></svg>';

  const CSS = `
.rb{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(ellipse at 50% 38%,#2d2342 0%,#1b1526 58%,#120e18 100%);overflow:hidden;user-select:none;-webkit-user-select:none}
.rb-top{display:flex;gap:4px;padding:4px 6px 0;flex:0 0 auto;height:42px;box-sizing:border-box}
.rb-pc{position:relative;flex:1 1 0;min-width:0;display:flex;flex-direction:column;justify-content:center;gap:2px;background:rgba(34,28,46,.92);border:1px solid rgba(255,255,255,.08);border-radius:9px;padding:2px 6px;font-size:11.5px;line-height:1.15;box-sizing:border-box}
.rb-pc.me{border-color:rgba(227,174,69,.6)}
.rb-pc .l1{display:flex;align-items:center;gap:4px;font-weight:700;min-width:0}
.rb-pc .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1 1 auto;min-width:0}
.rb-pc .stt{flex:0 0 auto;font-size:11px}
.rb-pc .l2{display:flex;align-items:center;gap:3px;font-family:var(--f-mono);font-size:10.5px;color:var(--muted);white-space:nowrap}
.rb-pc .l2 svg{width:11px;height:11px;color:var(--muted)}
.rb-pc .ld{flex:0 0 auto;font-size:11px;color:var(--brass)}
.rb-pip{display:inline-block;width:5px;height:8px;border-radius:2px;background:rgba(255,255,255,.14)}.rb-pip.on{background:#ee6a55}
.rb-mid{position:relative;flex:1 1 auto;min-height:0}
.rb-board{position:absolute;inset:0;width:100%;height:100%;display:block}
.rb-banner{position:absolute;left:50%;top:3px;transform:translateX(-50%);background:rgba(23,19,31,.9);border:1px solid rgba(227,174,69,.55);color:var(--ink);border-radius:999px;padding:3px 12px;font-size:12.5px;font-weight:800;white-space:nowrap;max-width:94%;overflow:hidden;text-overflow:ellipsis;pointer-events:none;z-index:2}
.rb-bot{flex:0 0 auto;height:206px;padding:4px 6px 6px;box-sizing:border-box;display:flex;flex-direction:column;gap:4px;position:relative}
.rb-row1{display:flex;align-items:center;gap:6px;height:44px;flex:0 0 auto;min-width:0}
.rb-row1 .btn{min-height:44px;padding:0 10px;font-size:12.5px;flex:0 0 auto}
.rb-hint{flex:1 1 auto;min-width:0;font-size:12.5px;font-weight:700;line-height:1.25;text-align:center;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;color:var(--ink)}
.rb-hint .bad{color:#ff8a76}.rb-hint .good{color:#6fe0a6}.rb-hint .mut{color:var(--muted);font-weight:600}
.rb-slots{display:flex;gap:4px;height:54px;flex:0 0 auto}
.rb-slot{position:relative;flex:1 1 0;min-width:0;border:2px dashed rgba(227,174,69,.42);border-radius:10px;display:flex;align-items:stretch;justify-content:stretch;background:rgba(0,0,0,.22);box-sizing:border-box;touch-action:none;cursor:pointer}
.rb-slot.over{border-color:#e3ae45;background:rgba(227,174,69,.18)}
.rb-slot .n{position:absolute;left:4px;top:2px;font:700 10px var(--f-mono);color:rgba(227,174,69,.75);pointer-events:none}
.rb-slot.full{border-style:solid;border-color:rgba(227,174,69,.25);padding:0}
.rb-slot .rb-card{flex:1 1 auto;flex-direction:column;gap:0;font-size:11px;border-radius:8px}
.rb-slot .rb-card svg{width:22px;height:22px}
.rb-go{flex:0 0 76px;min-height:54px!important;font-size:15px!important;padding:0 6px!important}
.rb-go[disabled]{opacity:.45;filter:grayscale(.5)}
.rb-hand{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));grid-auto-rows:44px;gap:4px;flex:0 0 auto}
.rb-card{position:relative;appearance:none;border:0;border-radius:9px;display:flex;align-items:center;justify-content:center;gap:5px;font-weight:800;font-size:13px;font-family:var(--f-body);color:#2a1d10;background:linear-gradient(#f6eedc,#e0cfac);box-shadow:inset 0 -2px 0 rgba(0,0,0,.18),0 2px 5px rgba(0,0,0,.35);touch-action:none;cursor:pointer;padding:0 4px;min-width:0;white-space:nowrap;overflow:hidden;transition:transform .08s}
.rb-card:active{transform:translateY(1px)}
.rb-card svg{width:20px;height:20px;flex:0 0 auto;fill:currentColor}
.rb-card .num{font:800 17px var(--f-mono);line-height:1}
.rb-card.t{background:linear-gradient(#c9efe9,#8fd0c6);color:#0f3934}
.rb-card.b{background:linear-gradient(#ffd2c8,#ec9d8c);color:#4a1810}
.rb-card.u{background:linear-gradient(#e2d3f7,#b9a0e0);color:#2c1650}
.rb-card.used{opacity:.3;filter:grayscale(.7)}
.rb-card .bd{position:absolute;right:3px;top:2px;font:700 10px var(--f-mono);color:rgba(0,0,0,.6)}
.rb-drag{position:fixed;z-index:60;pointer-events:none;width:64px;height:48px;transform:translate(-50%,-60%) rotate(-4deg);box-shadow:0 8px 18px rgba(0,0,0,.5)!important;opacity:.95}
.rb-wait{flex:1 1 auto;display:flex;flex-direction:column;gap:6px;align-items:stretch;justify-content:flex-start;min-height:0}
.rb-sts{display:flex;flex-wrap:wrap;gap:4px 10px;justify-content:center;font-size:12.5px;font-weight:700}
.rb-sts span{display:inline-flex;align-items:center;gap:4px}
.rb-mine{display:flex;gap:4px;justify-content:center;align-items:center}
.rb-mc{position:relative;width:30px;height:24px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;font:800 11px var(--f-mono);color:#2a1d10;background:linear-gradient(#f6eedc,#e0cfac);flex:0 0 auto;box-sizing:border-box}
.rb-mc svg{width:15px;height:15px;fill:currentColor}
.rb-mc.t{background:linear-gradient(#c9efe9,#8fd0c6);color:#0f3934}.rb-mc.b{background:linear-gradient(#ffd2c8,#ec9d8c);color:#4a1810}.rb-mc.u{background:linear-gradient(#e2d3f7,#b9a0e0);color:#2c1650}
.rb-mc.x{background:rgba(255,255,255,.08);color:var(--muted)}
.rb-mc.hid{background:repeating-linear-gradient(45deg,#3a3050 0 4px,#2c2440 4px 8px);color:transparent}
.rb-mc.done{opacity:.35}
.rb-mc.cur{outline:2px solid #e3ae45;outline-offset:1px}
.rb-mc .o{position:absolute;right:-5px;top:-6px;min-width:14px;height:14px;border-radius:7px;background:#e3ae45;color:#1b1526;font:800 9.5px/14px var(--f-mono);text-align:center;padding:0 2px;box-sizing:border-box}
.rb-tbl{display:flex;flex-direction:column;gap:2px;flex:1 1 auto;min-height:0;justify-content:center}
.rb-tr{display:flex;align-items:center;gap:4px;height:24px;flex:0 0 auto}
.rb-row1.ex{height:34px}
.rb-tr .nm{flex:1 1 auto;min-width:0;font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;align-items:center;gap:4px}
.rb-tr.off{opacity:.45}
.rb-tr.act .nm{color:var(--brass)}
.rb-ctl{display:flex;gap:4px;height:46px;flex:0 0 auto}
.rb-ctl .btn{flex:1 1 0;min-width:0;min-height:46px;padding:0 4px;font-size:12.5px;white-space:nowrap}
.rb-ord{flex:1 1 auto;min-width:0;font-size:11px;color:var(--muted);line-height:1.25;text-align:right}
.rb-pill{flex:0 0 auto;font:800 12.5px var(--f-mono);color:var(--ink);background:rgba(227,174,69,.16);border:1px solid rgba(227,174,69,.5);border-radius:999px;padding:4px 10px;white-space:nowrap}
.rb-cover{position:absolute;inset:0;z-index:8;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;background:rgba(14,10,20,.94);text-align:center;padding:16px}
.rb-cover .big{font-family:var(--f-display);font-size:28px}
.rb-end{flex:1 1 auto;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;text-align:center}
`;
  function ensureCss() {
    if (document.getElementById('rb-css')) return;
    const el = document.createElement('style');
    el.id = 'rb-css'; el.textContent = CSS;
    document.head.appendChild(el);
  }

  function mount(root, api) {
    ensureCss();
    const sp = () => L.debug.speed || 1;
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const col = (i) => (api.players[i] ? api.players[i].color : '#999');
    let st = null, shownId = 0, TL = null, revealed = -1, coverEl = null, coverKey = '', dead = false;
    const sent = {}, selBy = {}, timers = [];
    let ghostC = null, fx = [], dragSt = null;

    const wrap = h('div', { class: 'rb' });
    const top = h('div', { class: 'rb-top' });
    const mid = h('div', { class: 'rb-mid' });
    const cv = h('canvas', { class: 'rb-board', 'aria-label': '공장 바닥' });
    const banner = h('div', { class: 'rb-banner' });
    banner.hidden = true;
    const bot = h('div', { class: 'rb-bot' });
    mid.append(cv, banner);
    wrap.append(top, mid, bot);
    root.append(wrap);
    const ctx = cv.getContext('2d');
    let cw = 0, ch = 0, dpr = 1, cs = 20, ox = 0, oy = 0, staticCv = null, staticKey = '';

    const later = (fn, ms) => { const t = setTimeout(() => { if (!dead) fn(); }, ms); timers.push(t); return t; };
    const multi = () => !api.online && api.mySeats().length >= 2;
    function pending() {
      if (!st || st.ph !== 'p') return [];
      const r = [];
      for (let i = 0; i < st.n; i++) if (api.canAct(i) && st.pg[i] == null && sent[i] !== st.r) r.push(i);
      return r;
    }
    function activeSeat() {
      if (TL) return -1;
      const p = pending();
      if (!p.length) return -1;
      if (multi()) return p.includes(revealed) ? revealed : -1;
      return p[0];
    }
    function meSeat() {
      if (!st) return -1;
      const a = activeSeat();
      if (a >= 0) return a;
      if (multi()) return -1;
      const m = api.mySeats();
      return m.length === 1 ? m[0] : -1;
    }
    function getSel(seat) {
      let o = selBy[seat];
      if (!o || o.r !== st.r || o.h !== st.h[seat] || o.seq !== st.seq) { o = selBy[seat] = { r: st.r, h: st.h[seat], seq: st.seq, sel: [-1, -1, -1, -1, -1] }; }
      return o.sel;
    }

    /* ---------- sizing ---------- */
    function resize() {
      const r = mid.getBoundingClientRect();
      dpr = Math.min(2.5, window.devicePixelRatio || 1);
      cw = Math.max(10, r.width); ch = Math.max(10, r.height);
      cv.width = Math.round(cw * dpr); cv.height = Math.round(ch * dpr);
      cs = Math.max(8, Math.floor(Math.min((cw - 12) / W, (ch - 12) / H)));
      ox = Math.round((cw - cs * W) / 2); oy = Math.round((ch - cs * H) / 2);
      staticKey = '';
      kick();
    }
    const ro = new ResizeObserver(() => resize());
    ro.observe(mid);

    /* ---------- static board layer ---------- */
    function rr(g, x, y, w, hh, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + hh, r); g.arcTo(x + w, y + hh, x, y + hh, r); g.arcTo(x, y + hh, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
    function floorTile(g, px, py, s, x, y) {
      g.fillStyle = (x + y) % 2 ? '#342d42' : '#2f283c';
      g.fillRect(px, py, s, s);
      g.fillStyle = 'rgba(255,255,255,.045)'; g.fillRect(px + 1, py + 1, s - 2, 1.5); g.fillRect(px + 1, py + 1, 1.5, s - 2);
      g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(px + 1, py + s - 2, s - 2, 1.2); g.fillRect(px + s - 2, py + 1, 1.2, s - 2);
      if (s >= 22) {
        g.fillStyle = 'rgba(255,255,255,.10)';
        const q = s * 0.15, rv = Math.max(0.8, s * 0.035);
        for (const [a, b] of [[q, q], [s - q, q], [q, s - q], [s - q, s - q]]) { g.beginPath(); g.arc(px + a, py + b, rv, 0, 7); g.fill(); }
      }
    }
    function chevron(g, cx, cy, s, d, colr, dbl) {
      g.save(); g.translate(cx, cy); g.rotate(d * Math.PI / 2);
      g.strokeStyle = colr; g.lineWidth = Math.max(1.5, s * 0.09); g.lineCap = 'round'; g.lineJoin = 'round';
      const offs = dbl ? [-s * 0.13, s * 0.13] : [0];
      for (const o of offs) { g.beginPath(); g.moveTo(-s * 0.2, o + s * 0.1); g.lineTo(0, o - s * 0.1); g.lineTo(s * 0.2, o + s * 0.1); g.stroke(); }
      g.restore();
    }
    function drawTile(g, B, x, y) {
      const s = cs, px = ox + x * s, py = oy + y * s, c = B.t[y * W + x], cx = px + s / 2, cy = py + s / 2;
      if (c === 'O') {
        g.fillStyle = '#e3ae45'; g.fillRect(px, py, s, s);
        g.save(); g.beginPath(); g.rect(px, py, s, s); g.clip();
        g.strokeStyle = '#2a2030'; g.lineWidth = s * 0.12;
        for (let k = -2; k < 4; k++) { g.beginPath(); g.moveTo(px + k * s * 0.33, py + s); g.lineTo(px + k * s * 0.33 + s, py); g.stroke(); }
        g.restore();
        const gr = g.createRadialGradient(cx, cy, s * 0.05, cx, cy, s * 0.42);
        gr.addColorStop(0, '#000'); gr.addColorStop(1, '#1a1222');
        g.fillStyle = gr; rr(g, px + s * 0.14, py + s * 0.14, s * 0.72, s * 0.72, s * 0.12); g.fill();
        return;
      }
      floorTile(g, px, py, s, x, y);
      const bd = BD[c];
      if (bd != null) {
        const fast = c === c.toUpperCase();
        g.fillStyle = fast ? '#2b2d3c' : '#262c35'; g.fillRect(px + 1, py + 1, s - 2, s - 2);
        g.fillStyle = 'rgba(0,0,0,.35)';
        if (bd % 2 === 0) { g.fillRect(px + 1, py + 1, s * 0.1, s - 2); g.fillRect(px + s * 0.9 - 1, py + 1, s * 0.1, s - 2); }
        else { g.fillRect(px + 1, py + 1, s - 2, s * 0.1); g.fillRect(px + 1, py + s * 0.9 - 1, s - 2, s * 0.1); }
        chevron(g, cx, cy, s, bd, fast ? '#ffcf5a' : '#93abc4', fast);
      } else if (c === 'c' || c === 'a') {
        const ccw = c === 'a';   // ↻ brass, ↺ teal
        g.fillStyle = ccw ? '#21524a' : '#5d4622';
        for (let k = 0; k < 8; k++) { g.save(); g.translate(cx, cy); g.rotate(k * Math.PI / 4); g.fillRect(-s * 0.05, -s * 0.45, s * 0.1, s * 0.1); g.restore(); }
        g.beginPath(); g.arc(cx, cy, s * 0.38, 0, 7); g.fillStyle = ccw ? '#2c6b61' : '#7a5c2c'; g.fill();
        g.beginPath(); g.arc(cx, cy, s * 0.31, 0, 7); g.fillStyle = ccw ? '#5fb3a3' : '#b48a3e'; g.fill();
        g.save(); g.translate(cx, cy); if (c === 'a') g.scale(-1, 1);   // ↺ = mirrored ↻
        g.strokeStyle = '#2a1d10'; g.lineWidth = Math.max(1.4, s * 0.07); g.lineCap = 'round';
        const r0 = s * 0.18, a0 = -Math.PI * 0.9, a1 = Math.PI * 0.3;
        g.beginPath(); g.arc(0, 0, r0, a0, a1); g.stroke();
        const tx = Math.cos(a1) * r0, ty = Math.sin(a1) * r0, tang = a1 + Math.PI / 2;
        g.fillStyle = '#2a1d10'; g.beginPath();
        g.moveTo(tx + Math.cos(tang) * s * 0.12, ty + Math.sin(tang) * s * 0.12);
        g.lineTo(tx + Math.cos(tang + 2.2) * s * 0.1, ty + Math.sin(tang + 2.2) * s * 0.1);
        g.lineTo(tx + Math.cos(tang - 2.2) * s * 0.1, ty + Math.sin(tang - 2.2) * s * 0.1);
        g.closePath(); g.fill(); g.restore();
      } else if (c === '~') {
        g.fillStyle = 'rgba(8,6,12,.92)';
        for (const [a, b, r] of [[0.42, 0.45, 0.26], [0.62, 0.58, 0.22], [0.35, 0.66, 0.16], [0.6, 0.32, 0.14]]) { g.beginPath(); g.ellipse(px + a * s, py + b * s, r * s, r * s * 0.8, 0.4, 0, 7); g.fill(); }
        g.strokeStyle = 'rgba(170,130,255,.45)'; g.lineWidth = Math.max(1, s * 0.04);
        g.beginPath(); g.arc(px + 0.42 * s, py + 0.45 * s, s * 0.15, 3.6, 4.6); g.stroke();
        g.strokeStyle = 'rgba(90,220,190,.35)'; g.beginPath(); g.arc(px + 0.62 * s, py + 0.58 * s, s * 0.12, 0.2, 1.2); g.stroke();
      } else if (c === '+') {
        g.strokeStyle = '#46d38a'; g.lineWidth = Math.max(1.5, s * 0.06);
        rr(g, px + s * 0.13, py + s * 0.13, s * 0.74, s * 0.74, s * 0.12); g.stroke();
        g.fillStyle = 'rgba(70,211,138,.14)'; g.fill();
        g.fillStyle = '#46d38a'; g.beginPath();
        g.moveTo(cx + s * 0.06, cy - s * 0.27); g.lineTo(cx - s * 0.14, cy + s * 0.04); g.lineTo(cx - s * 0.01, cy + s * 0.04);
        g.lineTo(cx - s * 0.07, cy + s * 0.27); g.lineTo(cx + s * 0.15, cy - s * 0.05); g.lineTo(cx + s * 0.02, cy - s * 0.05); g.closePath(); g.fill();
      }
    }
    function wallLine(g, x0, y0, x1, y1) {
      const s = cs;
      g.lineCap = 'square';
      g.strokeStyle = 'rgba(0,0,0,.45)'; g.lineWidth = s * 0.16; g.beginPath(); g.moveTo(x0 + 1.5, y0 + 1.5); g.lineTo(x1 + 1.5, y1 + 1.5); g.stroke();
      g.strokeStyle = '#e3ae45'; g.lineWidth = s * 0.13; g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke();
      g.setLineDash([s * 0.1, s * 0.12]); g.strokeStyle = '#3a2a18'; g.lineWidth = s * 0.07; g.lineCap = 'butt';
      g.beginPath(); g.moveTo(x0, y0); g.lineTo(x1, y1); g.stroke(); g.setLineDash([]);
    }
    function beamEnds(B, b) {   // b: [x0,y0,x1,y1,d,hit] → pixel segment
      const s = cs, d = b[4];
      const sx = ox + (b[0] + 0.5) * s - DX[d] * s * 0.38, sy = oy + (b[1] + 0.5) * s - DY[d] * s * 0.38;
      let ex = ox + (b[2] + 0.5) * s, ey = oy + (b[3] + 0.5) * s;
      if (b[5] < 0) { ex += DX[d] * s * 0.5; ey += DY[d] * s * 0.5; }
      return [sx, sy, ex, ey];
    }
    function buildStatic() {
      const B = BOARDS[st.b];
      staticKey = st.b + ':' + cw + 'x' + ch + ':' + st.n;
      if (!staticCv) staticCv = document.createElement('canvas');
      staticCv.width = Math.round(cw * dpr); staticCv.height = Math.round(ch * dpr);
      const g = staticCv.getContext('2d');
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, cw, ch);
      const s = cs;
      // frame
      g.fillStyle = 'rgba(0,0,0,.45)'; rr(g, ox - 6, oy - 4, s * W + 12, s * H + 12, 10); g.fill();
      g.fillStyle = '#5a3f24'; rr(g, ox - 5, oy - 5, s * W + 10, s * H + 10, 9); g.fill();
      g.strokeStyle = '#e3ae45'; g.lineWidth = 1.2; rr(g, ox - 4.5, oy - 4.5, s * W + 9, s * H + 9, 8.5); g.stroke();
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) drawTile(g, B, x, y);
      // start docks
      const docks = st.n === 1 ? [SOLO_DOCK] : DOCKS.slice(0, st.n);
      docks.forEach((p, i) => {
        const px = ox + p[0] * s, py = oy + p[1] * s;
        g.setLineDash([3, 3]); g.strokeStyle = 'rgba(242,233,216,.35)'; g.lineWidth = 1.2;
        rr(g, px + s * 0.1, py + s * 0.1, s * 0.8, s * 0.8, 4); g.stroke(); g.setLineDash([]);
        g.fillStyle = 'rgba(242,233,216,.4)'; g.font = '700 ' + Math.round(s * 0.28) + 'px "IBM Plex Mono", monospace';
        g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(i + 1), px + s * 0.5, py + s * 0.78);
      });
      // laser guide lines (where the beams go when nobody is in the way)
      for (const lz of B.lz) {
        const e = laserTrace(B, null, lz);
        const [sx, sy, ex, ey] = beamEnds(B, [lz[0], lz[1], e[0], e[1], lz[2], -1]);
        g.strokeStyle = 'rgba(255,70,70,.24)'; g.lineWidth = Math.max(1, s * 0.05);
        const pr = lz[3] > 1 ? [-s * 0.07, s * 0.07] : [0];
        for (const o of pr) { const nx = -DY[lz[2]] * o, ny = DX[lz[2]] * o; g.beginPath(); g.moveTo(sx + nx, sy + ny); g.lineTo(ex + nx, ey + ny); g.stroke(); }
      }
      // walls (each edge once)
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const w = B.wall[y * W + x], px = ox + x * s, py = oy + y * s;
        if (w & 1) wallLine(g, px, py, px + s, py);
        if (w & 8) wallLine(g, px, py, px, py + s);
        if ((w & 2) && x === W - 1) wallLine(g, px + s, py, px + s, py + s);
        if ((w & 4) && y === H - 1) wallLine(g, px, py + s, px + s, py + s);
      }
      // laser emitters
      for (const lz of B.lz) {
        const d = lz[2], cx = ox + (lz[0] + 0.5) * s - DX[d] * s * 0.4, cy = oy + (lz[1] + 0.5) * s - DY[d] * s * 0.4;
        g.save(); g.translate(cx, cy); g.rotate(d * Math.PI / 2);
        g.fillStyle = '#1d1a24'; rr(g, -s * 0.22, -s * 0.09, s * 0.44, s * 0.17, 3); g.fill();
        g.strokeStyle = '#8a7a9a'; g.lineWidth = 1; g.stroke();
        g.fillStyle = '#ff4d4d';
        const pr = lz[3] > 1 ? [-s * 0.08, s * 0.08] : [0];
        for (const o of pr) { g.beginPath(); g.arc(o, -s * 0.06, Math.max(1.5, s * 0.05), 0, 7); g.fill(); }
        g.restore();
      }
    }

    /* ---------- dynamic drawing ---------- */
    function drawFlags(now) {
      const B = BOARDS[st.b], s = cs, me = meSeat();
      const myF = me < 0 ? -1 : TL ? TL.snaps[Math.min(TL.i, TL.snaps.length - 1)].r[me][5] : st.rb[me][4];
      for (let k = 0; k < st.k; k++) {
        const [fx2, fy2] = B.fl[k], cx = ox + (fx2 + 0.5) * s, cy = oy + (fy2 + 0.5) * s;
        const done = myF > k, next = myF === k;
        ctx.globalAlpha = done ? 0.4 : 1;
        if (next) {
          const pul = 0.5 + 0.5 * Math.sin(now / 260);
          ctx.strokeStyle = col(me); ctx.lineWidth = 2 + pul * 1.5;
          ctx.beginPath(); ctx.arc(cx, cy, s * 0.44, 0, 7); ctx.stroke();
        }
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(cx - s * 0.12, cy + s * 0.33, s * 0.16, s * 0.06, 0, 0, 7); ctx.fill();
        ctx.strokeStyle = '#d8d0c0'; ctx.lineWidth = Math.max(1.2, s * 0.05);
        ctx.beginPath(); ctx.moveTo(cx - s * 0.16, cy + s * 0.33); ctx.lineTo(cx - s * 0.16, cy - s * 0.36); ctx.stroke();
        ctx.fillStyle = '#e3ae45'; ctx.beginPath();
        ctx.moveTo(cx - s * 0.15, cy - s * 0.36); ctx.lineTo(cx + s * 0.34, cy - s * 0.36); ctx.lineTo(cx + s * 0.22, cy - s * 0.17);
        ctx.lineTo(cx + s * 0.34, cy + s * 0.02); ctx.lineTo(cx - s * 0.15, cy + s * 0.02); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#2a1d10'; ctx.font = '800 ' + Math.round(s * 0.3) + 'px "IBM Plex Mono", monospace';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(String(k + 1), cx + s * 0.06, cy - s * 0.16);
        ctx.globalAlpha = 1;
      }
    }
    function drawRobot(x, y, ang, colr, sc, al, dmg, glow) {
      const s = cs;
      if (sc <= 0.02 || al <= 0.02) return;
      ctx.save(); ctx.translate(x, y); ctx.globalAlpha = al;
      if (glow) { ctx.strokeStyle = 'rgba(227,174,69,.9)'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.arc(0, 0, s * 0.47 * sc, 0, 7); ctx.stroke(); }
      ctx.rotate(ang); ctx.scale(sc, sc);
      ctx.fillStyle = 'rgba(0,0,0,.4)'; ctx.beginPath(); ctx.ellipse(s * 0.04, s * 0.07, s * 0.36, s * 0.36, 0, 0, 7); ctx.fill();
      ctx.fillStyle = '#1b1820';
      rr(ctx, -s * 0.39, -s * 0.31, s * 0.15, s * 0.64, s * 0.05); ctx.fill();
      rr(ctx, s * 0.24, -s * 0.31, s * 0.15, s * 0.64, s * 0.05); ctx.fill();
      ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 1;
      for (let k = -2; k <= 2; k++) { const yy = k * s * 0.12; ctx.beginPath(); ctx.moveTo(-s * 0.38, yy); ctx.lineTo(-s * 0.25, yy); ctx.moveTo(s * 0.25, yy); ctx.lineTo(s * 0.38, yy); ctx.stroke(); }
      ctx.fillStyle = colr; rr(ctx, -s * 0.27, -s * 0.28, s * 0.54, s * 0.58, s * 0.11); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.45)'; ctx.lineWidth = Math.max(1, s * 0.04); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,.22)'; rr(ctx, -s * 0.22, -s * 0.04, s * 0.44, s * 0.08, s * 0.03); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; rr(ctx, -s * 0.21, -s * 0.38, s * 0.42, s * 0.19, s * 0.07); ctx.fill();
      ctx.fillStyle = '#17131f';
      ctx.beginPath(); ctx.arc(-s * 0.09, -s * 0.29, s * 0.05, 0, 7); ctx.arc(s * 0.09, -s * 0.29, s * 0.05, 0, 7); ctx.fill();
      ctx.fillStyle = '#e3ae45'; ctx.beginPath(); ctx.arc(0, s * 0.13, s * 0.07, 0, 7); ctx.fill();
      ctx.restore();
      if (dmg >= 2 && al > 0.5) {   // damage smoke
        ctx.fillStyle = dmg >= 3 ? 'rgba(80,70,80,.75)' : 'rgba(150,140,150,.55)';
        ctx.beginPath(); ctx.arc(x + s * 0.2, y - s * 0.34, s * 0.08, 0, 7); ctx.arc(x + s * 0.28, y - s * 0.46, s * 0.06, 0, 7); ctx.fill();
      }
    }
    const ease = (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2);
    function durOf(i) { return TL.snaps[i].dur / sp(); }
    function robotsNow() {
      const out = [], s = cs;
      if (TL) {
        const S = TL.snaps, i = Math.min(TL.i, S.length - 1);
        const A = S[Math.max(0, i - 1)], Bn = S[i];
        let k = TL.i >= S.length ? 1 : (durOf(i) > 0 ? Math.min(1, TL.t / durOf(i)) : 1);
        const done = TL.i >= S.length;
        const e = ease(k);
        for (let j = 0; j < Bn.r.length; j++) {
          const ra = done ? Bn.r[j] : A.r[j], rb = Bn.r[j];
          const kk = done ? 1 : e;
          let x = ox + (ra[0] + (rb[0] - ra[0]) * kk + 0.5) * s, y = oy + (ra[1] + (rb[1] - ra[1]) * kk + 0.5) * s;
          let da = ((rb[2] - ra[2] + 6) % 4) - 2;
          if (da === -2 && Bn.ph === 'card' && Bn.c === 'U') da = 2;
          let ang = (ra[2] + da * kk) * Math.PI / 2, sc = 1, al = 1;
          if (ra[4] && rb[4]) { sc = 0; }
          else if (!ra[4] && rb[4]) {
            if (rb[4] === 2) { al = 1 - kk * 0.9; sc = 1 + kk * 0.2; }
            else { sc = 1 - Math.max(0, (kk - 0.35) / 0.65) * 0.95; ang += kk * 2.4; }
          } else if (ra[4] && !rb[4]) { x = ox + (rb[0] + 0.5) * s; y = oy + (rb[1] + 0.5) * s; ang = rb[2] * Math.PI / 2; sc = 0.3 + 0.7 * kk; al = kk; }
          if (!done && Bn.bump && Bn.a === j) { const bd = Bn.c === 'B' ? (rb[2] + 2) % 4 : rb[2]; const o = Math.sin(k * Math.PI) * s * 0.14; x += DX[bd] * o; y += DY[bd] * o; }
          out.push({ x, y, ang, sc, al, m: rb[3], glow: !done && (Bn.ph === 'card' || Bn.ph === 'oil') && Bn.a === j });
        }
        return out;
      }
      for (let j = 0; j < st.n; j++) {
        const r = st.rb[j];
        out.push({ x: ox + (r[0] + 0.5) * s, y: oy + (r[1] + 0.5) * s, ang: r[2] * Math.PI / 2, sc: 1, al: 1, m: r[3], glow: false });
      }
      return out;
    }
    function drawBeams() {
      const S = TL.snaps, i = Math.min(TL.i, S.length - 1), Bn = S[i];
      if (Bn.ph !== 'laser' || TL.i >= S.length) return;
      const k = durOf(i) > 0 ? Math.min(1, TL.t / durOf(i)) : 1;
      const a = Math.sin(Math.min(1, k * 1.4) * Math.PI);
      const B = BOARDS[st.b];
      for (const b of Bn.bm) {
        const [sx, sy, ex, ey] = beamEnds(B, b);
        const pr = b[6] > 1 ? [-cs * 0.07, cs * 0.07] : [0];
        for (const o of pr) {
          const nx = -DY[b[4]] * o, ny = DX[b[4]] * o;
          ctx.strokeStyle = 'rgba(255,60,60,' + (0.35 * a) + ')'; ctx.lineWidth = cs * 0.22;
          ctx.beginPath(); ctx.moveTo(sx + nx, sy + ny); ctx.lineTo(ex + nx, ey + ny); ctx.stroke();
          ctx.strokeStyle = 'rgba(255,220,220,' + (0.95 * a) + ')'; ctx.lineWidth = Math.max(1.5, cs * 0.06);
          ctx.beginPath(); ctx.moveTo(sx + nx, sy + ny); ctx.lineTo(ex + nx, ey + ny); ctx.stroke();
        }
        if (b[5] >= 0) { ctx.fillStyle = 'rgba(255,240,180,' + a + ')'; ctx.beginPath(); ctx.arc(ex, ey, cs * 0.2 * a + 1, 0, 7); ctx.fill(); }
      }
    }
    function ghostOf(seat) {
      const sel = getSel(seat), hand = st.h[seat];
      const key = seat + ':' + st.seq + ':' + st.r + ':' + sel.join(',');
      if (ghostC && ghostC.key === key) return ghostC;
      const B = BOARDS[st.b], R = [unpack(st.rb[seat])];
      const prog = sel.map((i) => (i >= 0 ? hand[i] : '-')).join('');
      const pts = [[R[0].x, R[0].y]], marks = [];
      let fell = null, heat = false, zap = 0;
      const got = [];
      const rec = (o) => {
        const r = R[0];
        if (o.ph === 'end') { if (!r.o && prog[o.st] !== '-') marks.push([r.x, r.y, o.st]); return; }
        if (o.ph === 'laser') { for (const q of o.hit) zap += q[1]; if (o.heat.length) heat = true; }
        if (o.ph === 'flag') got.push(r.f);
        if (r.o) { if (!fell && r.o === 1) fell = [r.x, r.y]; return; }
        const lp = pts[pts.length - 1];
        if (lp[0] !== r.x || lp[1] !== r.y) pts.push([r.x, r.y]);
      };
      simRound(B, st.k, R, [prog], 0, rec);
      const fin = R[0];
      const filled = sel.filter((i) => i >= 0).length;
      ghostC = { key, pts, marks, fell, heat, zap, got, fin, filled, prog, win: fin.f >= st.k };
      return ghostC;
    }
    function drawGhost() {
      const seat = activeSeat();
      if (seat < 0) return;
      const g = ghostOf(seat);
      if (!g.filled) return;
      const s = cs, c = col(seat);
      const P = (p) => [ox + (p[0] + 0.5) * s, oy + (p[1] + 0.5) * s];
      ctx.save();
      ctx.setLineDash([s * 0.16, s * 0.12]); ctx.lineWidth = Math.max(2, s * 0.09); ctx.strokeStyle = c; ctx.globalAlpha = 0.85; ctx.lineCap = 'round';
      ctx.beginPath();
      g.pts.forEach((p, i) => { const [x, y] = P(p); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); });
      if (g.fell) { const [x, y] = P(g.fell); ctx.lineTo(x, y); }
      ctx.stroke(); ctx.setLineDash([]);
      ctx.restore();
      const seen = {};
      for (const m of g.marks) {
        const kk = m[0] + ',' + m[1], n = seen[kk] || 0; seen[kk] = n + 1;
        const [x, y] = P(m);
        const xx = x + s * 0.3 - n * s * 0.2, yy = y + s * 0.3;
        ctx.fillStyle = '#17131f'; ctx.beginPath(); ctx.arc(xx, yy, s * 0.15, 0, 7); ctx.fill();
        ctx.strokeStyle = c; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = '#f2e9d8'; ctx.font = '800 ' + Math.round(s * 0.2) + 'px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(String(m[2] + 1), xx, yy + 0.5);
      }
      if (g.fell) {
        const [x, y] = P(g.fell);
        ctx.strokeStyle = '#ff5a48'; ctx.lineWidth = Math.max(2.5, s * 0.11); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(x - s * 0.25, y - s * 0.25); ctx.lineTo(x + s * 0.25, y + s * 0.25); ctx.moveTo(x + s * 0.25, y - s * 0.25); ctx.lineTo(x - s * 0.25, y + s * 0.25); ctx.stroke();
      } else if (!g.fin.o) {
        drawRobot(ox + (g.fin.x + 0.5) * s, oy + (g.fin.y + 0.5) * s, g.fin.d * Math.PI / 2, c, 0.9, 0.42, 0, false);
      }
    }
    function drawRestart() {
      const me = meSeat();
      if (me < 0 || TL) return;
      const r = st.rb[me];
      if (r[0] === r[5] && r[1] === r[6]) return;
      const s = cs, x = ox + (r[5] + 0.5) * s, y = oy + (r[6] + 0.5) * s;
      ctx.setLineDash([3, 3]); ctx.strokeStyle = col(me); ctx.globalAlpha = 0.6; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, s * 0.3, 0, 7); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 1;
    }
    function drawFx(now) {
      fx = fx.filter((f) => now - f.t0 < f.life);
      for (const f of fx) {
        const k = (now - f.t0) / f.life;
        ctx.globalAlpha = k < 0.75 ? 1 : 1 - (k - 0.75) / 0.25;
        ctx.font = '800 ' + Math.round(Math.max(13, cs * 0.42)) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const y = f.y - k * cs * 0.7;
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(15,10,20,.85)'; ctx.strokeText(f.txt, f.x, y);
        ctx.fillStyle = f.c; ctx.fillText(f.txt, f.x, y);
        ctx.globalAlpha = 1;
      }
    }
    function addFx(i, txt, c) {
      const S = TL ? TL.snaps[Math.min(TL.i, TL.snaps.length - 1)] : null;
      const r = S ? S.r[i] : st.rb[i];
      const x = Math.max(30, Math.min(cw - 30, ox + (r[0] + 0.5) * cs)), y = Math.max(16, oy + (r[1] + 0.5) * cs - cs * 0.55);
      fx.push({ x, y, txt, c: c || '#f2e9d8', t0: performance.now(), life: 1300 / Math.min(4, sp()) });
    }
    function draw(now) {
      if (!st || !cw) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, cw, ch);
      if (staticKey !== st.b + ':' + cw + 'x' + ch + ':' + st.n) buildStatic();
      ctx.drawImage(staticCv, 0, 0, cw, ch);
      drawFlags(now);
      drawRestart();
      if (!TL) drawGhost();
      if (TL) drawBeams();
      const rs = robotsNow();
      rs.forEach((r, j) => { if (!r.glow) drawRobot(r.x, r.y, r.ang, col(j), r.sc, r.al, r.m, false); });
      rs.forEach((r, j) => { if (r.glow) drawRobot(r.x, r.y, r.ang, col(j), r.sc, r.al, r.m, true); });
      drawFx(now);
    }

    /* ---------- animation loop ---------- */
    let raf = 0, lastT = 0, lastWall = 0;
    function kick() { if (!raf && !dead) raf = requestAnimationFrame(frame); }
    function needLoop() { return (TL && TL.playing) || fx.length || (!TL && st && st.ph === 'p' && meSeat() >= 0); }
    function frame(now) {
      raf = 0;
      const dt = lastT ? Math.min(100, now - lastT) : 16;
      lastT = now; lastWall = Date.now();
      if (TL && TL.playing) advance(dt);
      draw(now);
      if (needLoop()) raf = requestAnimationFrame(frame); else lastT = 0;
    }
    // hidden tab: rAF stops, so keep a live replay moving (it holds the busy flag)
    const wd = setInterval(() => {
      if (dead || !TL || !TL.live || !TL.playing) return;
      const now = Date.now();
      if (now - lastWall > 400) { advance(Math.min(1000, now - (lastWall || now - 400))); lastWall = now; }
    }, 300);

    function advance(dt) {
      if (!TL) return;
      TL.t += dt;
      const S = TL.snaps;
      while (TL) {
        if (TL.i >= S.length) { endTL(); return; }
        const d = durOf(TL.i);
        if (TL.t < d) break;
        const nx = S[TL.i + 1];
        if (TL.once && d > 0 && !(nx && nx.g === S[TL.i].g)) { TL.t = d; TL.playing = false; TL.once = false; updExec(); break; }   // step mode: hold the end of this scene
        TL.t -= d; TL.i++;
        if (TL.i < S.length) enterSeg(TL.i);
      }
    }
    function makeTL(last, live) {
      const B = BOARDS[st.b], R = last.pre.map(unpack), snaps = [];
      const cap = (o) => { o.r = R.map((r) => [r.x, r.y, r.d, r.m, r.o, r.f]); snaps.push(o); };
      cap({ ph: 'start', st: -1, dur: 0 });
      simRound(B, st.k, R, last.p, last.ld, cap);
      if (R.some((r) => r.o)) {
        for (let i = 0; i < R.length; i++) if (R[i].o) respawn(B, st.k, R, i);
        cap({ ph: 'reboot', st: 4, dur: 720 });
      }
      cap({ ph: 'fin', st: 4, dur: 260 });
      // scene groups for step-through: all cells of one card (incl. its oil slide) form one scene
      let gid = 0;
      snaps.forEach((o, i) => {
        const p = snaps[i - 1];
        const cont = p && (o.ph === 'card' || o.ph === 'oil') && (p.ph === 'card' || p.ph === 'oil') && p.a === o.a && p.st === o.st && !p.bump;
        o.g = cont ? gid : ++gid;
      });
      return { snaps, i: 1, t: 0, playing: true, once: false, live, P: last.p, r: last.r, ld: last.ld, ord: null, ordSt: -1 };
    }
    function startTL(last, live) {
      TL = makeTL(last, live);
      if (live) api.setBusy(true);
      ghostC = null;
      buildExec();
      enterSeg(1);
      renderAll();
    }
    function endTL(force) {
      if (!TL) return;
      if (TL.live || force) {
        const wasLive = TL.live;
        TL = null; banner.hidden = true;
        if (wasLive) api.setBusy(false);
        renderAll();
        return;
      }
      TL.i = TL.snaps.length; TL.playing = false; TL.t = 0;
      banner.textContent = '다시 보기 끝 — 「처음부터」 또는 「닫기」';
      updExec();
      kick();
    }
    function phaseText(S) {
      const stp = S.st >= 0 ? (S.st + 1) + '단계 · ' : '';
      switch (S.ph) {
        case 'ord': return stp + '카드 공개! 순서대로 실행';
        case 'card': return stp + nm(S.a) + ' · ' + CN[S.c] + (S.bump ? ' — 막혔어요' : S.fall && S.fall.length ? ' — 떨어졌어요!' : S.pu ? ' — 밀쳤어요!' : '');
        case 'oil': return stp + nm(S.a) + ' · 기름에 미끄덩!' + (S.fall && S.fall.length ? ' — 떨어졌어요!' : '');
        case 'fbelt': return stp + '빠른 벨트 1칸' + (S.fall.length ? ' — 떨어졌어요!' : '');
        case 'belt': return stp + '벨트 1칸' + (S.fall.length ? ' — 떨어졌어요!' : '');
        case 'gear': return stp + '회전판이 돌아요';
        case 'laser': return stp + '레이저 발사!' + (S.heat.length ? ' 과열!' : '');
        case 'flag': return stp + '깃발 찍기!';
        case 'heal': return '충전소: 고장 1칸 수리';
        case 'reboot': return '재부팅 — 재시작 지점으로 돌아와요';
        case 'fin': return '라운드 끝';
        default: return '';
      }
    }
    function enterSeg(i) {
      if (!TL) return;
      const S = TL.snaps[i], me = meSeat();
      if (S.ph === 'end') return;
      if (S.ph === 'ord') { TL.ord = S.ord; TL.ordSt = S.st; }
      banner.hidden = false; banner.textContent = phaseText(S);
      const mine = (j) => api.canAct(j);
      switch (S.ph) {
        case 'ord': api.sfx('card'); break;
        case 'card': case 'oil':
          if (S.bump) api.sfx('thud');
          else if (S.fall && S.fall.length) { api.sfx('whoosh'); S.fall.forEach((j) => { addFx(j, '으악!', '#ff8a76'); if (mine(j)) api.buzz(30); }); }
          else if (S.pu) { api.sfx('bounce'); addFx(S.pu[0], '쿵!', '#ffd27a'); }
          else api.sfx('tick');
          break;
        case 'fbelt': case 'belt': api.sfx('click'); S.fall.forEach((j) => addFx(j, '으악!', '#ff8a76')); break;
        case 'gear': api.sfx('click'); break;
        case 'laser': api.sfx('hit'); S.hit.forEach((q) => addFx(q[0], '⚡' + q[1], '#ff8a76')); S.heat.forEach((j) => addFx(j, '과열!', '#ff5a48')); if (S.hit.some((q) => mine(q[0]))) api.buzz(20); break;
        case 'flag': api.sfx('pop'); S.got.forEach((q) => { addFx(q[0], '깃발 ' + CIRC[q[1] - 1] + '!', '#ffd27a'); if (mine(q[0])) api.buzz(25); }); break;
        case 'heal': api.sfx('chip'); S.hl.forEach((j) => addFx(j, '충전 +1', '#6fe0a6')); break;
        case 'reboot': api.sfx('pop'); break;
        default: break;
      }
      void me;
      updExec();
      renderTop();
      kick();
    }

    /* ---------- top strip ---------- */
    function renderTop() {
      top.innerHTML = '';
      if (!st) return;
      const me = meSeat();
      const snap = TL ? TL.snaps[Math.min(TL.i, TL.snaps.length - 1)] : null;
      const lead = TL ? TL.ld : st.ld;
      for (let i = 0; i < st.n; i++) {
        const r = snap ? [0, 0, 0, snap.r[i][3], snap.r[i][5]] : st.rb[i];   // during the replay: values of the scene on screen
        const stt = st.ph === 'p' && !TL && st.pg[i] != null ? '✓' : '';
        const pips = h('span', { style: { display: 'inline-flex', gap: '1.5px' } });
        for (let k = 0; k < MAXDMG; k++) pips.append(h('span', { class: 'rb-pip' + (k < r[3] ? ' on' : '') }));
        top.append(h('div', { class: 'rb-pc' + (i === me ? ' me' : ''), title: nm(i) },
          h('div', { class: 'l1' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { class: 'nm', text: nm(i) }),
            st.n > 1 && lead === i ? h('span', { class: 'ld', title: '선두', text: '★' }) : null,
            stt ? h('span', { class: 'stt', style: { color: stt === '✓' ? '#6fe0a6' : 'var(--muted)' }, text: stt }) : null),
          h('div', { class: 'l2' }, h('span', { html: FLAGSVG, style: { display: 'inline-flex' } }), r[4] + '/' + st.k, h('span', { style: { width: '3px' } }), pips)));
      }
      if (st.n === 1) {
        const par = BOARDS[st.b].par[st.k - 2];
        top.append(h('div', { class: 'rb-pc' },
          h('div', { class: 'l1' }, h('span', { class: 'nm', text: '라운드 ' + Math.min(st.r + 1, st.cap) + ' / ' + st.cap })),
          h('div', { class: 'l2', text: '★★★ ' + par + '라운드 이하' })));
      }
    }

    /* ---------- bottom panel ---------- */
    let botKey = '';
    function renderBot(force) {
      if (!st) return;
      if (TL) return;   // exec panel is built by buildExec / updExec
      const a = activeSeat();
      const key = [st.seq, st.r, st.ph, a, st.pg.map((x) => (x ? 1 : 0)).join(''), pending().join(','), revealed, JSON.stringify(a >= 0 ? getSel(a) : 0)].join('|');
      if (key === botKey && !force) return;
      botKey = key;
      bot.innerHTML = '';
      if (st.ph === 'e') return renderEnd();
      if (a >= 0) return renderProg(a);
      renderWait();
    }
    function replayBtn() {
      if (!st || !st.last) return null;
      return h('button', { class: 'btn rb-replay', 'aria-label': '지난 라운드 다시 보기', onclick: () => { api.sfx('click'); startTL(st.last, false); TL.playing = true; } }, '↺ 다시 보기');
    }
    function cardEl(c, extra) {
      const isF = c === '1' || c === '2' || c === '3';
      return h('button', Object.assign({ class: 'rb-card ' + kcls(c), html: icon(c) + (isF ? '<span class="num">' + c + '</span>' : '<span>' + CS[c] + '</span>') }, extra || {}));
    }
    function hintFor(seat) {
      const g = ghostOf(seat), B = BOARDS[st.b];
      const el = h('div', { class: 'rb-hint' });
      if (!g.filled) {
        el.append('카드를 눌러 ', h('b', { text: '①번 칸' }), '부터 채워요', h('br'), h('span', { class: 'mut', text: '라운드 ' + (st.r + 1) + '/' + st.cap + ' · 점선 = 내 로봇 예상 길' }));
        return el;
      }
      const parts = [];
      if (g.fell) parts.push(h('span', { class: 'bad', text: '⚠ 떨어져요! ' }));
      else if (g.heat) parts.push(h('span', { class: 'bad', text: '⚠ 과열돼요! ' }));
      if (g.got.length) parts.push(h('span', { class: 'good', text: '깃발 ' + g.got.map((f) => CIRC[f - 1]).join('') + ' 찍어요! ' }));
      if (g.zap) parts.push(h('span', { class: 'bad', text: '레이저 ⚡' + g.zap + ' ' }));
      let line2;
      if (g.win) line2 = '이대로면 승리!';
      else if (!g.fell && !g.heat) {
        const f = g.fin.f, d = field(B, Math.min(f, st.k - 1))[g.fin.y * W + g.fin.x];
        line2 = '깃발 ' + CIRC[Math.min(f, st.k - 1)] + '까지 ' + (d >= 99 ? '?' : d) + '칸';
      } else line2 = '다시 배치해 보세요';
      if (!parts.length) parts.push(h('span', { class: 'mut', text: g.filled < SLOTS ? '빈칸은 쉬어요' : '준비 완료!' }));
      el.append(h('span', { text: g.filled + '/5칸 · ' }), ...parts, h('br'), h('span', { class: 'mut', text: line2 + ' (다른 로봇 빼고)' }));
      return el;
    }
    function renderProg(seat) {
      const hand = st.h[seat], sel = getSel(seat);
      const clr = h('button', { class: 'btn', 'aria-label': '칸 비우기', onclick: () => { for (let k = 0; k < SLOTS; k++) sel[k] = -1; api.sfx('click'); changed(); } }, '비우기');
      bot.append(h('div', { class: 'rb-row1' }, replayBtn(), hintFor(seat), clr));
      const slots = h('div', { class: 'rb-slots' });
      for (let k = 0; k < SLOTS; k++) {
        const i = sel[k];
        const sl = h('div', { class: 'rb-slot' + (i >= 0 ? ' full' : ''), 'data-k': k, role: 'button', 'aria-label': (k + 1) + '번 칸' + (i >= 0 ? ' ' + CN[hand[i]] : ' 비어 있음') });
        if (i >= 0) { const c = cardEl(hand[i], { tabindex: -1 }); c.style.pointerEvents = 'none'; sl.append(c); }
        sl.append(h('span', { class: 'n', text: String(k + 1) }));
        slots.append(sl);
      }
      const full = sel.every((i) => i >= 0);
      const go = h('button', { class: 'btn primary rb-go', disabled: !full, onclick: () => submit(seat) }, full ? '실행 ▶' : sel.filter((i) => i >= 0).length + '/5');
      slots.append(go);
      bot.append(slots);
      const hd = h('div', { class: 'rb-hand' });
      for (let i = 0; i < hand.length; i++) {
        const used = sel.indexOf(i);
        const c = cardEl(hand[i], { 'data-i': i, 'aria-label': CN[hand[i]] + (used >= 0 ? ' (' + (used + 1) + '번 칸)' : '') });
        if (used >= 0) { c.classList.add('used'); c.append(h('span', { class: 'bd', text: String(used + 1) })); }
        hd.append(c);
      }
      bot.append(hd);
    }
    function submit(seat) {
      const sel = getSel(seat);
      if (!sel.every((i) => i >= 0) || !st || st.ph !== 'p' || st.pg[seat] != null) return;
      const p = sel.map((i) => st.h[seat][i]).join('');
      sent[seat] = st.r;
      api.buzz(20); api.sfx('chip');
      if (multi()) revealed = -1;
      const r0 = st.r, sq = st.seq;
      api.actAs(seat, { t: 'prog', p });
      later(() => { if (st && st.seq === sq && st.r === r0 && st.pg[seat] == null && sent[seat] === r0) { delete sent[seat]; renderAll(); } }, 3000);
      renderAll();
    }
    function renderWait() {
      const box = h('div', { class: 'rb-wait' });
      const mine = api.mySeats();
      const n0 = st.pg.filter((x) => x == null).length;
      const txt = multi() && pending().length ? '폰을 다음 사람에게 넘겨주세요' : n0 ? '다른 로봇이 몰래 명령을 고르는 중…' : '곧 실행해요!';
      box.append(h('div', { class: 'rb-row1' }, replayBtn(), h('div', { class: 'rb-hint', text: txt })));
      const sts = h('div', { class: 'rb-sts' });
      for (let i = 0; i < st.n; i++) sts.append(h('span', null, h('span', { class: 'dot', style: { '--c': col(i) } }), nm(i), h('span', { style: { color: st.pg[i] != null ? '#6fe0a6' : 'var(--muted)' }, text: st.pg[i] != null ? '✓' : '…' })));
      box.append(sts);
      const one = !multi() && mine.length === 1 ? mine[0] : -1;
      if (one >= 0 && st.pg[one] != null) {
        const row = h('div', { class: 'rb-mine' }, h('span', { class: 'muted', style: { fontSize: '12px', marginRight: '4px' }, text: '내 명령' }));
        for (const c of st.pg[one]) row.append(h('span', { class: 'rb-mc ' + kcls(c), html: icon(c) + (c >= '1' && c <= '3' ? c : '') }));
        box.append(row);
        box.append(h('div', { class: 'row', style: { justifyContent: 'center' } },
          h('button', { class: 'btn', onclick: () => { api.sfx('click'); delete sent[one]; api.actAs(one, { t: 'unprog' }); } }, '✎ 다시 고르기')));
      } else if (!mine.length) {
        box.append(h('div', { class: 'muted', style: { textAlign: 'center', fontSize: '12px' }, text: BOARDS[st.b].nm + ' · ' + BOARDS[st.b].hint }));
      }
      bot.append(box);
    }
    function renderEnd() {
      bot.append(h('div', { class: 'rb-end' },
        h('div', { style: { fontFamily: 'var(--f-display)', fontSize: '20px' }, text: '게임 끝!' }),
        h('div', { class: 'muted', style: { fontSize: '12.5px' }, text: BOARDS[st.b].nm + ' · ' + st.r + '라운드' }),
        replayBtn()));
    }

    /* ---------- exec / replay panel ---------- */
    let ex = null;
    function buildExec() {
      bot.innerHTML = ''; botKey = '';
      const pill = h('span', { class: 'rb-pill' });
      const ord = h('div', { class: 'rb-ord', html: '순서: 회전 → 앞3 → 앞2 → 앞1 → 뒤로<br>같은 카드는 ★선두부터' });
      const tbl = h('div', { class: 'rb-tbl' });
      const rows = [];
      for (let i = 0; i < st.n; i++) {
        const cells = [];
        const tr = h('div', { class: 'rb-tr' }, h('span', { class: 'nm' }, h('span', { class: 'dot', style: { '--c': col(i) } }), h('span', { text: nm(i) }), h('span', { class: 'ldm', style: { color: 'var(--brass)', fontSize: '11px' } })));
        for (let k = 0; k < SLOTS; k++) { const c = TL.P[i] ? TL.P[i][k] : '-'; const mc = h('span', { class: 'rb-mc ' + kcls(c), html: icon(c) + (c >= '1' && c <= '3' ? c : '') }); cells.push(mc); tr.append(mc); }
        rows.push({ tr, cells });
        tbl.append(tr);
      }
      const bPrev = h('button', { class: 'btn', 'aria-label': '이전 장면', onclick: () => stepPrev() }, '◀ 이전');
      const bPlay = h('button', { class: 'btn', onclick: () => togglePlay() });
      const bNext = h('button', { class: 'btn', 'aria-label': '다음 장면', onclick: () => stepNext() }, '다음 ▶');
      const bEnd = h('button', { class: 'btn primary', onclick: () => { api.sfx('click'); if (TL && TL.live) endTL(); else endTL(true); } });
      bot.append(h('div', { class: 'rb-row1 ex' }, pill, ord), tbl, h('div', { class: 'rb-ctl' }, bPrev, bPlay, bNext, bEnd));
      ex = { pill, rows, bPlay, bEnd, bPrev, bNext };
      updExec();
    }
    function updExec() {
      if (!TL || !ex) return;
      const S = TL.snaps[Math.min(TL.i, TL.snaps.length - 1)];
      const cur = S.st;
      ex.pill.textContent = 'R' + (TL.r + 1) + ' · ' + (cur >= 0 ? (cur + 1) : 1) + '/5단계';
      const rank = {};
      if (TL.ord && TL.ordSt === cur) TL.ord.forEach((q, k) => { rank[q[0]] = k + 1; });
      ex.rows.forEach((row, i) => {
        const off = S.r[i][4];
        row.tr.classList.toggle('off', !!off);
        row.tr.classList.toggle('act', (S.ph === 'card' || S.ph === 'oil') && S.a === i);
        const ldm = row.tr.querySelector('.ldm');
        if (ldm) ldm.textContent = st.n > 1 && TL.ld === i ? '★' : '';
        row.cells.forEach((c, k) => {
          c.classList.toggle('done', k < cur);
          c.classList.toggle('cur', k === cur);
          const o = c.querySelector('.o');
          if (o) o.remove();
          if (k === cur && rank[i]) c.append(h('span', { class: 'o', text: String(rank[i]) }));
        });
      });
      const done = TL.i >= TL.snaps.length;
      ex.bPlay.textContent = done ? '↺ 처음부터' : TL.playing ? '⏸ 멈춤' : '▶ 재생';
      ex.bEnd.textContent = TL.live ? '⏩ 끝으로' : '✕ 닫기';
    }
    function togglePlay() {
      if (!TL) return;
      api.sfx('click');
      if (TL.i >= TL.snaps.length) { TL.i = 1; TL.t = 0; TL.ord = null; TL.ordSt = -1; TL.playing = true; enterSeg(1); }
      else { TL.playing = !TL.playing; TL.once = false; }
      updExec(); kick();
    }
    /* step-through: every scene plays once, then holds its end; 다음 moves to the next scene, 이전 replays the previous one */
    function stepNext() {
      if (!TL || TL.i >= TL.snaps.length) return;
      api.sfx('click');
      const len = TL.snaps.length;
      if (!TL.playing && TL.t >= durOf(TL.i) - 0.001) {
        let i = TL.i + 1;
        while (i < len && durOf(i) === 0) i++;
        if (i >= len) { TL.i = len; endTL(); return; }
        TL.i = i; TL.t = 0; enterSeg(i);
      }
      TL.playing = true; TL.once = true;
      updExec(); kick();
    }
    function stepPrev() {
      if (!TL) return;
      api.sfx('click');
      const S = TL.snaps, len = S.length;
      const gStart = (i) => { while (i > 1 && S[i - 1].g === S[i].g) i--; return i; };
      const back = (i) => { i--; while (i > 1 && durOf(i) === 0) i--; return gStart(Math.max(1, i)); };
      let i;
      if (TL.i >= len) i = gStart(S[len - 1].ph === 'fin' ? len - 2 : len - 1);
      else {
        const gs = gStart(TL.i);
        const held = !TL.playing && TL.t >= durOf(TL.i) - 0.001;
        i = !held && (TL.i > gs || TL.t > durOf(TL.i) * 0.3) ? gs : back(gs);   // mid-scene: restart it, else the scene before
      }
      TL.ord = null; TL.ordSt = -1;   // rebuild the order info for the step we land in
      for (let j = 1; j <= i; j++) if (S[j].ph === 'ord') { TL.ord = S[j].ord; TL.ordSt = S[j].st; }
      TL.i = i; TL.t = 0; TL.playing = true; TL.once = true;
      enterSeg(i);
    }

    /* ---------- pass-the-phone cover (several people on one phone) ---------- */
    function syncCover() {
      let want = -1;
      if (st && st.ph === 'p' && multi() && !TL) {
        const p = pending();
        if (p.length && !p.includes(revealed)) want = p[0];
      }
      const key = want + ':' + (st ? st.seq + '.' + st.r : '');
      if (key === coverKey) return;
      coverKey = key;
      if (coverEl) { coverEl.remove(); coverEl = null; }
      if (want < 0) return;
      coverEl = h('div', { class: 'rb-cover' },
        h('span', { class: 'dot', style: { '--c': col(want), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nm(want) }),
        h('div', { style: { fontWeight: 700, color: 'var(--brass)' }, text: '라운드 ' + (st.r + 1) + ' · 몰래 명령 고르기' }),
        h('div', { class: 'muted', text: '다른 사람은 보지 마세요' }),
        h('button', { class: 'btn primary', text: '명령 고르기', onclick: () => { revealed = want; api.sfx('click'); renderAll(); } }));
      wrap.append(coverEl);
    }

    /* ---------- drag & tap on cards / slots ---------- */
    function changed() { ghostC = null; renderBot(true); kick(); }
    function onDown(e) {
      const seat = activeSeat();
      if (seat < 0 || TL) return;
      const t = e.target.closest('.rb-hand [data-i], .rb-slot');
      if (!t || !bot.contains(t)) return;
      const sel = getSel(seat);
      let from, idx;
      if (t.dataset.i != null) {
        idx = +t.dataset.i;
        const k = sel.indexOf(idx);
        if (k >= 0) { from = 's'; idx = k; } else from = 'h';
      } else {
        idx = +t.dataset.k;
        if (sel[idx] < 0) return;
        from = 's';
      }
      dragSt = { seat, from, idx, x0: e.clientX, y0: e.clientY, moving: false, ghost: null, over: null, pid: e.pointerId };
    }
    function onMove(e) {
      if (!dragSt || e.pointerId !== dragSt.pid) return;
      const dx = e.clientX - dragSt.x0, dy = e.clientY - dragSt.y0;
      if (!dragSt.moving && dx * dx + dy * dy > 64) {
        dragSt.moving = true;
        const hand = st.h[dragSt.seat], sel = getSel(dragSt.seat);
        const c = hand[dragSt.from === 'h' ? dragSt.idx : sel[dragSt.idx]];
        dragSt.ghost = cardEl(c, { class: 'rb-card ' + kcls(c) + ' rb-drag', tabindex: -1 });
        document.body.append(dragSt.ghost);
      }
      if (!dragSt.moving) return;
      dragSt.ghost.style.left = e.clientX + 'px'; dragSt.ghost.style.top = e.clientY + 'px';
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const sl = el && el.closest ? el.closest('.rb-slot') : null;
      if (dragSt.over && dragSt.over !== sl) dragSt.over.classList.remove('over');
      if (sl && bot.contains(sl)) { sl.classList.add('over'); dragSt.over = sl; } else dragSt.over = null;
    }
    function onUp(e) {
      if (!dragSt || e.pointerId !== dragSt.pid) return;
      const d = dragSt; dragSt = null;
      if (d.ghost) d.ghost.remove();
      if (d.over) d.over.classList.remove('over');
      if (!st || activeSeat() !== d.seat) return;
      const sel = getSel(d.seat);
      if (!d.moving) {   // tap
        if (d.from === 'h') { const k = sel.indexOf(-1); if (k < 0) { api.toast('5칸이 다 찼어요 — 칸을 눌러 빼요'); return; } sel[k] = d.idx; api.sfx('tick'); api.buzz(8); }
        else { sel[d.idx] = -1; api.sfx('click'); }
        changed(); return;
      }
      const el = document.elementFromPoint(e.clientX, e.clientY);
      const sl = el && el.closest ? el.closest('.rb-slot') : null;
      if (sl && bot.contains(sl)) {
        const t = +sl.dataset.k;
        if (d.from === 'h') sel[t] = d.idx;
        else { const tmp = sel[t]; sel[t] = sel[d.idx]; sel[d.idx] = tmp; }
        api.sfx('tick'); api.buzz(8);
      } else if (d.from === 's') { sel[d.idx] = -1; api.sfx('click'); }
      changed();
    }
    function onCancel() { if (dragSt) { if (dragSt.ghost) dragSt.ghost.remove(); if (dragSt.over) dragSt.over.classList.remove('over'); dragSt = null; } }
    bot.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onCancel);

    /* ---------- keyboard (optional shortcuts) ---------- */
    const offInput = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down' || !st) return;
      if (TL) {
        if (id === 'next') stepNext(); else if (id === 'prev') stepPrev(); else if (id === 'pause') togglePlay();
        return;
      }
      const seat = activeSeat();
      if (id === 'replay' && st.last) { startTL(st.last, false); return; }
      if (seat < 0) return;
      const sel = getSel(seat);
      if (/^c\d$/.test(id)) {
        const i = +id.slice(1) - 1;
        if (i >= st.h[seat].length) return;
        const k = sel.indexOf(i);
        if (k >= 0) sel[k] = -1; else { const e = sel.indexOf(-1); if (e < 0) return; sel[e] = i; }
        api.sfx('tick'); changed();
      } else if (id === 'undo') {
        for (let k = SLOTS - 1; k >= 0; k--) if (sel[k] >= 0) { sel[k] = -1; break; }
        changed();
      } else if (id === 'go') submit(seat);
    }) : null;

    function renderAll() {
      renderTop();
      if (!TL) renderBot();
      syncCover();
      kick();
    }

    resize();
    return {
      update(s, prev) {
        const old = st;
        st = s;
        if (old && (s.seq < old.seq || (old.ph === 'e' && s.ph === 'p'))) {   // rematch
          for (const k in sent) delete sent[k];
          for (const k in selBy) delete selBy[k];
        }
        if (!old || !prev) {
          shownId = s.last ? s.last.id : 0;
          if (TL) { const wasLive = TL.live; TL = null; banner.hidden = true; if (wasLive) api.setBusy(false); }
          revealed = -1;
        } else if (s.last && s.last.id !== shownId) {
          shownId = s.last.id;
          if (TL && TL.live) api.setBusy(false);
          TL = null;
          revealed = -1;
          startTL(s.last, true);
        } else if (!s.last && TL) {
          const wasLive = TL.live; TL = null; banner.hidden = true; if (wasLive) api.setBusy(false);
          shownId = 0; revealed = -1;
        }
        for (const k in sent) if (sent[k] !== s.r) delete sent[k];
        ghostC = null;
        botKey = '';
        renderAll();
      },
      destroy() {
        dead = true;
        if (TL && TL.live) api.setBusy(false);
        TL = null;
        cancelAnimationFrame(raf); clearInterval(wd);
        timers.forEach(clearTimeout);
        ro.disconnect();
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onCancel);
        if (offInput) offInput();
        if (dragSt && dragSt.ghost) dragSt.ghost.remove();
        wrap.remove();
      },
    };
  }

  const ctl = [];
  for (let i = 1; i <= 8; i++) ctl.push({ id: 'c' + i, label: '손패 ' + i + '번 카드 넣기/빼기', keys: ['Digit' + i, 'Numpad' + i] });
  ctl.push({ id: 'undo', label: '마지막 칸 빼기', keys: ['Backspace'] });
  ctl.push({ id: 'go', label: '실행 (5칸이 찼을 때)', keys: ['Space'] });
  ctl.push({ id: 'replay', label: '지난 라운드 다시 보기', keys: ['KeyR'] });
  ctl.push({ id: 'prev', label: '다시 보기: 이전 장면', keys: ['ArrowLeft'] });
  ctl.push({ id: 'next', label: '다시 보기: 다음 장면', keys: ['ArrowRight'] });
  ctl.push({ id: 'pause', label: '다시 보기: 멈춤/재생', keys: ['KeyP'] });

  L.register({
    id: 'robots', name: '로봇 명령 카드 대결', tag: '동시 프로그래밍 레이스', cat: '보드',
    blurb: '장난감 로봇에게 몰래 명령 카드 5장을 순서대로 넣고 동시에 실행! 벨트·회전판·구덩이·레이저를 피하고 서로 밀치며 깃발을 순서대로 먼저 다 찍으면 승리. 1~4명.',
    tint: '#1f4a5a',
    icon: '<rect x="14" y="16" width="28" height="26" rx="6" fill="currentColor"/><rect x="18" y="20" width="20" height="9" rx="3" fill="#000" opacity=".35"/><circle cx="23" cy="24.5" r="2.5" fill="currentColor"/><circle cx="33" cy="24.5" r="2.5" fill="currentColor"/><path d="M28 16V9" stroke="currentColor" stroke-width="2.5"/><circle cx="28" cy="8" r="3" fill="currentColor"/><rect x="8" y="22" width="5" height="16" rx="2" fill="currentColor"/><rect x="43" y="22" width="5" height="16" rx="2" fill="currentColor"/><path d="M20 46h16" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><path d="M44 44l6-6-6-6" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>',
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: true, aiDelay: 1300, aiDelayFor,
    options: [
      { id: 'map', label: '공장 바닥', choices: [{ v: -1, label: '무작위' }].concat(DEFS.map((d, i) => ({ v: i, label: d.nm }))), def: -1 },
      { id: 'flags', label: '깃발 수', choices: [{ v: 2, label: '2개 (짧게)' }, { v: 3, label: '3개' }, { v: 4, label: '4개 (길게)' }], def: 3 },
      { id: 'cap', label: '라운드 제한', choices: [{ v: 10, label: '10' }, { v: 15, label: '15' }, { v: 20, label: '20' }], def: 15 },
    ],
    controls: ctl,
    quick: [
      '깃발 ①→②→③을 순서대로 가장 먼저 다 찍는 로봇이 승리!',
      '매 라운드 손패에서 명령 카드 5장을 몰래 골라 ①~⑤칸에 넣고 「실행」.',
      '모두 고르면 동시에 공개돼 한 장씩 실행! 벨트·구덩이·레이저와 다른 로봇을 조심해요.',
    ],
    rules: [
      { h: '목표', p: [
        '공장 바닥 위의 장난감 로봇을 움직여 깃발 ①, ②, ③…을 번호 순서대로 찍어요(그 칸에 서 있으면 찍혀요).',
        '마지막 깃발까지 가장 먼저 찍은 로봇이 승리! 같은 단계에 함께 끝내면 공동 승리예요.',
        '라운드 제한(기본 15)이 끝나면 깃발을 가장 많이 찍은 로봇이 이겨요(같으면 다음 깃발에 더 가까운 로봇).',
      ] },
      { h: '차례에 할 일 (모두 동시에)', p: [
        '라운드마다 명령 카드를 8장 받아요(고장 1칸마다 1장 적게).',
        '그중 5장을 골라 ①~⑤번 칸에 순서대로 넣어요. 다른 사람은 내 카드를 못 봐요.',
        '판 위의 점선은 내 로봇이 갈 길 미리보기예요(다른 로봇은 빼고 계산). 번호 동그라미는 각 단계가 끝난 자리예요.',
        '5칸이 다 차면 「실행」. 모두 고르면 카드가 공개되고 ①번 칸부터 한 장씩 실행돼요. 남은 카드는 버리고 다음 라운드에 새로 받아요.',
      ] },
      { h: '명령 카드', p: [
        '앞 1·앞 2·앞 3: 바라보는 쪽으로 그만큼 가요. 뒤로: 바라보는 방향은 그대로 한 칸 뒤로 가요.',
        '왼쪽·오른쪽: 제자리에서 90° 돌아요. 유턴: 제자리에서 반 바퀴 돌아요.',
        '로봇의 앞쪽은 하얀 얼굴(눈 두 개)이 있는 쪽이에요.',
      ] },
      { h: '한 단계의 순서', p: [
        '① 카드 실행: 회전(왼쪽·오른쪽·유턴) → 앞 3 → 앞 2 → 앞 1 → 뒤로 순서. 같은 종류면 ★선두부터(선두는 라운드마다 다음 사람으로 넘어가요).',
        '② 빠른 벨트(노란 화살표)가 1칸 → 모든 벨트가 1칸 옮겨요. 그래서 빠른 벨트는 한 단계에 2칸!',
        '③ 회전판이 화살표 방향으로 90° 돌려요(금색 ↻ 시계 방향, 청록색 ↺ 반대 방향).  ④ 벽 레이저가 쏴요(첫 번째로 맞은 로봇만 고장 1칸, 빨간 점 2개는 2칸).',
        '⑤ 깃발 확인.  이렇게 5단계를 하면 라운드 끝. 실행 중에는 아래에서 순서 번호와 모두의 카드를 볼 수 있어요.',
      ] },
      { h: '밀치기 · 벽', p: [
        '움직이는 로봇이 다른 로봇에 닿으면 밀어내요(여러 대도 줄줄이). 밀린 로봇은 방향이 그대로예요.',
        '노랑·검정 줄무늬 벽은 지나갈 수 없어요. 밀다가 벽에 막히면 모두 멈춰요.',
        '벨트는 다른 로봇을 밀지 못해요. 막히면 그 자리에 있어요.',
      ] },
      { h: '공장 장치', p: [
        '구덩이(줄무늬 테두리 검은 구멍)·판 밖: 떨어지면 재부팅!',
        '기름(검은 웅덩이): 걸어서 들어가면 같은 방향으로 1칸 더 미끄러져요.',
        '충전소(초록 번개): 라운드가 끝날 때 여기 있으면 고장 1칸 수리 + 재시작 지점이 여기로 바뀌어요.',
        '레이저: 빨간 점선이 레이저가 지나가는 길이에요. 로봇이나 벽이 가로막아요.',
      ] },
      { h: '고장 · 재부팅', p: [
        '레이저에 맞으면 고장이 1칸씩 늘고, 그만큼 다음 라운드 카드가 줄어요(고장 3이면 5장뿐!).',
        '고장 4칸이면 과열로 멈춰요. 구덩이·판 밖으로 떨어져도 마찬가지.',
        '재부팅: 그 라운드 남은 카드는 취소되고, 다음 라운드에 재시작 지점(마지막에 찍은 깃발·충전소, 처음엔 출발 칸)에서 고장 1칸으로 다시 시작해요. 다음 깃발 쪽을 보고 서요.',
      ] },
      { h: '예시', p: [
        '내 로봇이 위(↑)를 보고 있고, 깃발이 오른쪽으로 3칸·위로 2칸에 있어요.',
        '카드: 앞 2 → 오른쪽 → 앞 3 → 왼쪽 → 앞 1 로 넣으면, 위로 2칸 → 오른쪽 보기 → 오른쪽 3칸(깃발 찍음!) → 위 보기 → 1칸 더.',
        '그런데 2단계에 빨강이 「앞 3」으로 내 앞을 지나가면 순서상 회전이 먼저라 나는 돌고, 빨강이 지나가다 나를 밀 수도 있어요. 밀리면 점선과 달라져요!',
      ] },
      { h: '다시 보기 · 조작', p: [
        '카드를 누르면 빈칸에 들어가고, 칸을 누르면 빠져요. 칸이나 카드를 끌어서 원하는 칸에 넣거나 순서를 바꿔요.',
        '「↺ 다시 보기」: 지난 라운드를 다시 틀어요. ◀ 이전 / 다음 ▶으로 한 장면씩 넘겨 볼 수 있어요.',
        '실행 중 「⏩ 끝으로」로 건너뛸 수 있어요.',
        'PC: 숫자 1~8 카드 넣기/빼기, Backspace 마지막 칸 빼기, 스페이스 실행, R 다시 보기, ←/→ 장면 넘기기, P 멈춤.',
      ] },
      { h: '혼자 하기 · 기타', p: [
        '혼자 하면 라운드 기록 도전! 공장마다 정해진 라운드 안에 깃발을 다 찍으면 ★★★ (2라운드 늦으면 ★★, 제한 안이면 ★).',
        '공장 바닥 9종(+무작위), 깃발 수 2·3·4개, 라운드 제한 10·15·20을 고를 수 있어요.',
        '한 폰으로 여럿이 하면 차례로 폰을 넘겨 몰래 고르고, 모두 고르면 함께 봐요.',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 어려움은 모든 순서를 계산하고 구덩이를 잘 피하지만, 카드 운이 있어서 이길 수 있어요!',
      ] },
    ],
    tutorial: [
      { text: '목표: 깃발 ①→②→③을 순서대로 먼저 찍기! 매 라운드 명령 카드 5장으로 로봇을 움직여요.', sel: '.rb-mid' },
      { text: '손패 카드를 누르면 ①번 칸부터 차례로 들어가요. 칸을 누르면 빠지고, 끌어서 순서를 바꿀 수 있어요.', sel: '.rb-hand' },
      { text: '판 위 점선이 내 로봇이 갈 길 미리보기예요(다른 로봇은 빼고 계산). 구덩이로 떨어지면 빨간 ✕가 보여요.', sel: '.rb-slots' },
      { text: '5칸이 차면 「실행」! 모두 고르면 동시에 공개돼요. 순서: 회전 → 앞3 → 앞2 → 앞1 → 뒤로, 그다음 벨트 → 회전판 → 레이저.', sel: '.rb-go' },
      { text: '「↺ 다시 보기」로 지난 라운드를 한 장면씩 다시 볼 수 있어요. 위쪽 칸에는 깃발 수와 고장(빨간 칸)이 보여요.', sel: '.rb-top' },
    ],
    init, actor, apply, ai, result, mount,
    _t: { BOARDS, simRound, simStep, unpack, pack, respawn, field, bestProgram, W, H },
  });
})();
