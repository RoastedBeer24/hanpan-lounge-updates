/* 로봇 조립 자동 전투 — auto-battler for 2–8 players (bots fill).
   Every round all players shop at the same time (array actor): buy parts from a private 5-part market, equip them into
   6 slots (몸통·팔·다리·무기×2·코어), keep spares in a 4-slot storage. 3 copies of the same part at the same level merge
   into one stronger part (★ → ★★ → ★★★). 84 parts in 10 sets with 2/4-part bonuses + 6 two-set combos; energy and
   weight budgets slow the robot when exceeded. Every owned piece of a part raises that part's weight in YOUR shop.
   When everyone is ready, apply() pairs the players and runs every 1-on-1 fight with a deterministic seeded 1-D sim
   (shared with the view; the view replays it with sparks, soot/smoke damage and set special moves).
   state.last = {id, r, f:[[a, b, buildA, buildB, seed, winner, dmg, ghost]]} lets every device replay the fights.
   Blank-canvas fix: the canvas backing store is resized by a ResizeObserver, which runs AFTER requestAnimationFrame
   callbacks in a frame; resizing clears the bitmap, so every garage↔battle switch (the panel height changes) painted an
   empty canvas, and it stayed empty while rAF was late/throttled (first online battle, iframe, waking phone). Now the
   view repaints synchronously on resize and right after every state update, and the frame loop can never die. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util, h = L.h;

  /* ============================== data ============================== */
  const SETS = [
    { n: '화염', c: '#ff7a45', two: '불 피해 1.5배', four: '불 피해 2.2배 + 공격력 +10%', sp: '화염 폭풍' },
    { n: '전기', c: '#ffd23f', two: '4번째 전기 공격마다 1초 감전', four: '3번째마다 1.2초 감전', sp: '낙뢰' },
    { n: '방패', c: '#a9bccf', two: '시작할 때 체력 20% 보호막', four: '보호막 28% + 받는 피해 −10%', sp: '방벽 전개' },
    { n: '속도', c: '#4fd6d0', two: '공격 속도 +25% · 회피 +10%', four: '공격 속도 +50% · 회피 +22%', sp: '질풍 연타' },
    { n: '냉기', c: '#8ec9ff', two: '냉기 공격의 느려짐 강화', four: '느려짐 최대 50% + 느려진 적에게 피해 +15%', sp: '절대 영도' },
    { n: '수리', c: '#7ddc7a', two: '초당 체력 1.2% 회복', four: '초당 2% + 체력 절반 아래면 15% 한 번 회복', sp: '긴급 수리' },
    { n: '산성', c: '#d4f542', two: '부식 강화 + 부식된 적에게 피해 +12%', four: '부식 더 강화 + 부식된 적에게 피해 +25%', sp: '산성비' },
    { n: '레이저', c: '#ff5fa2', two: '치명타 확률 +18%', four: '치명타 +25% · 치명 피해 2.5배', sp: '궤도 레이저' },
    { n: '드론', c: '#b48cff', two: '드론 공격 1.5배', four: '드론 공격 1.9배 + 더 자주', sp: '드론 폭격' },
    { n: '거울', c: '#e9eef5', two: '받은 피해 12% 되돌려줌', four: '받은 피해 26% 되돌려줌', sp: '거울 결계' },
  ];
  const NS = SETS.length;
  const COMBOS = [
    { a: 0, b: 4, n: '열충격', d: '느려진 적에게 주는 피해 +15%' },
    { a: 1, b: 7, n: '과충전 광선', d: '감전된 적에게는 무조건 치명타' },
    { a: 2, b: 9, n: '반사 방벽', d: '보호막이 남아 있으면 되돌리는 피해 2배' },
    { a: 3, b: 8, n: '고속 편대', d: '드론 공격 속도 +30%' },
    { a: 5, b: 8, n: '정비 드론', d: '드론이 공격할 때마다 체력 1% 회복' },
    { a: 6, b: 0, n: '부식 연소', d: '부식된 적에게 불 피해 +40%' },
  ];
  const SLOTS = ['B', 'A', 'L', 'W', 'W', 'C'];
  const SLN = ['몸통', '팔', '다리', '무기 1', '무기 2', '코어'];
  const TN = { B: '몸통', A: '팔', L: '다리', W: '무기', C: '코어' };
  const TIER = ['', '일반', '고급', '희귀', '전설'];
  /* t: slot type, e: set, c: tier (price = c + 1), v: look, st: stats
     hp 체력, ar 방어, am 공격력%, cdm 공격속도%, sp 이동속도, cap 적재량, wt 무게, en 전력(+공급/−사용), sh 보호막,
     rg 초당 회복%, dg 회피, cr 치명타, rf 되돌림(반사), dn 드론 피해, d/cd/r 무기 피해/재장전(초)/사거리
     Indices 0–41 are the original parts (kept so the compact ids stay stable); 42+ are new. */
  const PARTS = [
    { n: '용광로 몸통', s: '용광로', t: 'B', e: 0, c: 2, v: 'box', st: { hp: 80, ar: 2, wt: 7, en: 1 } },
    { n: '불꽃 집게팔', s: '불집게', t: 'A', e: 0, c: 1, v: 'claw', st: { am: 0.15, wt: 2, en: -1 } },
    { n: '화염 궤도바퀴', s: '화염궤도', t: 'L', e: 0, c: 2, v: 'track', st: { sp: 9, cap: 22, hp: 10, wt: 3 } },
    { n: '화염 방사기', s: '방사기', t: 'W', e: 0, c: 2, v: 'flamer', st: { d: 3.8, cd: 0.45, r: 36, wt: 3, en: -3 } },
    { n: '불꽃 도끼', s: '불도끼', t: 'W', e: 0, c: 1, v: 'axe', st: { d: 8, cd: 1.1, r: 22, wt: 3, en: -1 } },
    { n: '열 엔진 코어', s: '열엔진', t: 'C', e: 0, c: 2, v: 'core', st: { en: 10, am: 0.1, wt: 2 } },
    { n: '소이 박격포', s: '박격포', t: 'W', e: 0, c: 3, v: 'mortar', st: { d: 15, cd: 2.2, r: 75, wt: 5, en: -4 } },

    { n: '축전지 몸통', s: '축전지', t: 'B', e: 1, c: 1, v: 'slim', st: { hp: 76, ar: 1, wt: 5, en: 4 } },
    { n: '코일 팔', s: '코일팔', t: 'A', e: 1, c: 2, v: 'coil', st: { am: 0.1, cdm: 0.1, wt: 2, en: -2 } },
    { n: '전류 바퀴', s: '전류바퀴', t: 'L', e: 1, c: 1, v: 'wheel', st: { sp: 14, cap: 14, wt: 2, en: -1 } },
    { n: '테슬라 막대', s: '테슬라', t: 'W', e: 1, c: 2, v: 'rod', st: { d: 7, cd: 0.8, r: 23, wt: 2, en: -3 } },
    { n: '번개 총', s: '번개총', t: 'W', e: 1, c: 1, v: 'gun', st: { d: 5, cd: 0.9, r: 55, wt: 2, en: -2 } },
    { n: '발전기 코어', s: '발전기', t: 'C', e: 1, c: 1, v: 'core', st: { en: 9, wt: 2 } },
    { n: '레일건', s: '레일건', t: 'W', e: 1, c: 3, v: 'rail', st: { d: 26, cd: 2.8, r: 95, wt: 5, en: -6 } },

    { n: '강철 장갑 몸통', s: '강철장갑', t: 'B', e: 2, c: 1, v: 'tank', st: { hp: 72, ar: 3, wt: 9 } },
    { n: '방패 팔', s: '방패팔', t: 'A', e: 2, c: 1, v: 'shield', st: { ar: 2, hp: 5, wt: 3 } },
    { n: '육중한 다리', s: '육중다리', t: 'L', e: 2, c: 2, v: 'leg', st: { sp: 6, cap: 30, ar: 1, wt: 4 } },
    { n: '철퇴', s: '철퇴', t: 'W', e: 2, c: 1, v: 'mace', st: { d: 11, cd: 1.4, r: 22, wt: 4, en: -1 } },
    { n: '리벳 총', s: '리벳총', t: 'W', e: 2, c: 2, v: 'gun', st: { d: 6, cd: 1, r: 50, wt: 3, en: -2 } },
    { n: '방벽 코어', s: '방벽', t: 'C', e: 2, c: 2, v: 'core', st: { en: 7, sh: 25, wt: 3 } },
    { n: '요새 몸통', s: '요새', t: 'B', e: 2, c: 3, v: 'fort', st: { hp: 140, ar: 5, wt: 12 } },

    { n: '경량 프레임', s: '경량', t: 'B', e: 3, c: 1, v: 'slim', st: { hp: 72, wt: 2, en: 1, dg: 0.07 } },
    { n: '쾌속 팔', s: '쾌속팔', t: 'A', e: 3, c: 2, v: 'fast', st: { cdm: 0.2, wt: 1, en: -1 } },
    { n: '스프링 다리', s: '스프링', t: 'L', e: 3, c: 1, v: 'spring', st: { sp: 18, cap: 12, dg: 0.04, wt: 1 } },
    { n: '쌍단검', s: '쌍단검', t: 'W', e: 3, c: 1, v: 'blade', st: { d: 4.6, cd: 0.45, r: 22, wt: 1, en: -1 } },
    { n: '연발 기관총', s: '기관총', t: 'W', e: 3, c: 2, v: 'mg', st: { d: 3, cd: 0.3, r: 50, wt: 2, en: -3 } },
    { n: '터보 코어', s: '터보', t: 'C', e: 3, c: 3, v: 'core', st: { en: 9, cdm: 0.15, sp: 4, wt: 1 } },
    { n: '제트 다리', s: '제트', t: 'L', e: 3, c: 3, v: 'jet', st: { sp: 24, cap: 16, dg: 0.1, wt: 2, en: -2 } },

    { n: '냉각 몸통', s: '냉각', t: 'B', e: 4, c: 2, v: 'dome', st: { hp: 80, ar: 2, wt: 6, en: 2 } },
    { n: '서리 집게', s: '서리집게', t: 'A', e: 4, c: 1, v: 'claw', st: { am: 0.1, hp: 10, wt: 2, en: -1 } },
    { n: '얼음 썰매', s: '썰매', t: 'L', e: 4, c: 1, v: 'sled', st: { sp: 12, cap: 16, wt: 2 } },
    { n: '냉동 광선', s: '냉동광선', t: 'W', e: 4, c: 2, v: 'beam', st: { d: 4.6, cd: 0.9, r: 60, wt: 3, en: -3 } },
    { n: '얼음 송곳', s: '얼음송곳', t: 'W', e: 4, c: 1, v: 'pick', st: { d: 7, cd: 1, r: 22, wt: 2, en: -1 } },
    { n: '극저온 코어', s: '극저온', t: 'C', e: 4, c: 2, v: 'core', st: { en: 8, ar: 1, hp: 15, wt: 2 } },
    { n: '눈보라 포', s: '눈보라포', t: 'W', e: 4, c: 3, v: 'cannon', st: { d: 12, cd: 1.6, r: 65, wt: 5, en: -5 } },

    { n: '재생 몸통', s: '재생', t: 'B', e: 5, c: 2, v: 'round', st: { hp: 85, ar: 1, wt: 7, en: 1, rg: 0.6 } },
    { n: '수리 팔', s: '수리팔', t: 'A', e: 5, c: 1, v: 'wrench', st: { rg: 0.6, hp: 10, wt: 2, en: -1 } },
    { n: '자가수리 다리', s: '자가수리', t: 'L', e: 5, c: 2, v: 'leg', st: { sp: 10, cap: 20, hp: 10, rg: 0.5, wt: 3 } },
    { n: '렌치 망치', s: '렌치망치', t: 'W', e: 5, c: 1, v: 'hammer', st: { d: 9, cd: 1, r: 22, wt: 3, en: -1 } },
    { n: '나노 총', s: '나노총', t: 'W', e: 5, c: 2, v: 'nano', st: { d: 6, cd: 0.8, r: 45, wt: 2, en: -2 } },
    { n: '수리 코어', s: '수리코어', t: 'C', e: 5, c: 1, v: 'core', st: { en: 7, rg: 0.6, wt: 2 } },
    { n: '불사 코어', s: '불사', t: 'C', e: 5, c: 3, v: 'core', st: { en: 11, rg: 0.6, hp: 25, wt: 3 } },

    /* ---- new: legendary (tier 4) parts for the first six sets ---- */
    { n: '용의 숨결', s: '용숨결', t: 'W', e: 0, c: 4, v: 'dragon', st: { d: 6.5, cd: 0.45, r: 40, wt: 4, en: -4 } },
    { n: '폭풍 코어', s: '폭풍코어', t: 'C', e: 1, c: 4, v: 'core', st: { en: 14, cdm: 0.15, am: 0.1, wt: 2 } },
    { n: '거신 장갑', s: '거신장갑', t: 'B', e: 2, c: 4, v: 'titan', st: { hp: 165, ar: 5, wt: 14, en: 2 } },
    { n: '음속 칼날', s: '음속칼날', t: 'W', e: 3, c: 4, v: 'sonic', st: { d: 8.5, cd: 0.35, r: 24, wt: 1, en: -2 } },
    { n: '빙하 갑옷', s: '빙하갑옷', t: 'B', e: 4, c: 4, v: 'glacier', st: { hp: 135, ar: 4, sh: 25, wt: 9, en: 2 } },
    { n: '재생 원자로', s: '원자로', t: 'C', e: 5, c: 4, v: 'core', st: { en: 12, rg: 1.3, hp: 40, wt: 3 } },

    /* ---- 산성 ---- */
    { n: '주사기 팔', s: '주사기팔', t: 'A', e: 6, c: 1, v: 'syringe', st: { am: 0.14, wt: 2, en: -1 } },
    { n: '산성 분무기', s: '분무기', t: 'W', e: 6, c: 1, v: 'sprayer', st: { d: 5, cd: 0.6, r: 34, wt: 2, en: -1 } },
    { n: '촉매 코어', s: '촉매', t: 'C', e: 6, c: 1, v: 'core', st: { en: 8, am: 0.05, wt: 2 } },
    { n: '산성 탱크 몸통', s: '산성탱크', t: 'B', e: 6, c: 2, v: 'vat', st: { hp: 90, ar: 2, wt: 7, en: 1 } },
    { n: '거미 다리', s: '거미다리', t: 'L', e: 6, c: 2, v: 'spider', st: { sp: 11, cap: 24, hp: 10, wt: 3 } },
    { n: '부식 창', s: '부식창', t: 'W', e: 6, c: 2, v: 'spear', st: { d: 10, cd: 1, r: 25, wt: 3, en: -2 } },
    { n: '산성 박격포', s: '산성포', t: 'W', e: 6, c: 3, v: 'mortar', st: { d: 16, cd: 2, r: 70, wt: 5, en: -4 } },
    { n: '독무 코어', s: '독무코어', t: 'C', e: 6, c: 3, v: 'core', st: { en: 10, hp: 20, ar: 1, am: 0.08, wt: 3 } },
    { n: '용해 광선', s: '용해광선', t: 'W', e: 6, c: 4, v: 'beam', st: { d: 10, cd: 0.9, r: 60, wt: 4, en: -5 } },

    /* ---- 레이저 ---- */
    { n: '조준경 팔', s: '조준경팔', t: 'A', e: 7, c: 1, v: 'lens', st: { cr: 0.1, am: 0.05, wt: 1, en: -1 } },
    { n: '레이저 권총', s: '레이저총', t: 'W', e: 7, c: 1, v: 'laser', st: { d: 5, cd: 0.8, r: 60, wt: 1, en: -2 } },
    { n: '광섬유 다리', s: '광섬유', t: 'L', e: 7, c: 1, v: 'leg', st: { sp: 12, cap: 15, cr: 0.03, wt: 2 } },
    { n: '프리즘 몸통', s: '프리즘', t: 'B', e: 7, c: 2, v: 'prism', st: { hp: 76, ar: 1, wt: 5, en: 3, cr: 0.06 } },
    { n: '광선 검', s: '광선검', t: 'W', e: 7, c: 2, v: 'lsword', st: { d: 7.5, cd: 0.75, r: 24, wt: 2, en: -2 } },
    { n: '집광 코어', s: '집광', t: 'C', e: 7, c: 2, v: 'core', st: { en: 9, cr: 0.08, wt: 2 } },
    { n: '저격 레이저', s: '저격', t: 'W', e: 7, c: 3, v: 'sniper', st: { d: 22, cd: 2.4, r: 100, wt: 4, en: -5 } },
    { n: '부양 패드', s: '부양패드', t: 'L', e: 7, c: 3, v: 'hover', st: { sp: 18, cap: 20, dg: 0.08, wt: 2, en: -2 } },
    { n: '궤도 포격기', s: '궤도포', t: 'W', e: 7, c: 4, v: 'orbital', st: { d: 25, cd: 2.4, r: 100, wt: 5, en: -7, cr: 0.1 } },

    /* ---- 드론 ---- */
    { n: '조종 안테나 팔', s: '안테나팔', t: 'A', e: 8, c: 1, v: 'antenna', st: { dn: 2.5, wt: 1, en: -1 } },
    { n: '회전 톱', s: '회전톱', t: 'W', e: 8, c: 1, v: 'saw', st: { d: 6, cd: 0.6, r: 22, wt: 2, en: -1 } },
    { n: '삼각 다리', s: '삼각다리', t: 'L', e: 8, c: 1, v: 'tripod', st: { sp: 9, cap: 22, ar: 1, wt: 2 } },
    { n: '드론 모함 몸통', s: '모함', t: 'B', e: 8, c: 2, v: 'hive', st: { hp: 78, ar: 1, wt: 6, en: 2, dn: 2.5 } },
    { n: '드론 발사대', s: '발사대', t: 'W', e: 8, c: 2, v: 'launcher', st: { d: 5, cd: 1, r: 70, wt: 3, en: -2, dn: 2 } },
    { n: '중계 코어', s: '중계', t: 'C', e: 8, c: 2, v: 'core', st: { en: 9, dn: 2.5, wt: 2 } },
    { n: '벌떼 미사일', s: '벌떼', t: 'W', e: 8, c: 3, v: 'swarm', st: { d: 6, cd: 0.55, r: 65, wt: 4, en: -4, dn: 1.5 } },
    { n: '편대 코어', s: '편대', t: 'C', e: 8, c: 3, v: 'core', st: { en: 10, dn: 4, wt: 2 } },
    { n: '공중 항모', s: '항모', t: 'B', e: 8, c: 4, v: 'hive', st: { hp: 135, ar: 2, wt: 9, en: 4, dn: 5 } },

    /* ---- 거울 ---- */
    { n: '거울 원반', s: '원반', t: 'W', e: 9, c: 1, v: 'disc', st: { d: 6, cd: 0.85, r: 45, wt: 2, en: -1 } },
    { n: '유리 다리', s: '유리다리', t: 'L', e: 9, c: 1, v: 'glass', st: { sp: 13, cap: 14, dg: 0.05, wt: 1 } },
    { n: '거울 코어', s: '거울코어', t: 'C', e: 9, c: 1, v: 'core', st: { en: 8, rf: 0.04, wt: 2 } },
    { n: '거울 몸통', s: '거울몸통', t: 'B', e: 9, c: 2, v: 'mirror', st: { hp: 80, ar: 2, wt: 6, en: 1, rf: 0.06 } },
    { n: '반사 방패 팔', s: '반사팔', t: 'A', e: 9, c: 2, v: 'mirrorarm', st: { ar: 1, hp: 10, rf: 0.07, wt: 2 } },
    { n: '반사 낫', s: '반사낫', t: 'W', e: 9, c: 2, v: 'scythe', st: { d: 11, cd: 1.2, r: 24, wt: 3, en: -1 } },
    { n: '굴절 광선', s: '굴절', t: 'W', e: 9, c: 3, v: 'beam', st: { d: 12, cd: 1.4, r: 70, wt: 3, en: -4 } },
    { n: '만화경 팔', s: '만화경', t: 'A', e: 9, c: 3, v: 'lens', st: { am: 0.12, dg: 0.06, rf: 0.05, wt: 1, en: -1 } },
    { n: '무한 거울 코어', s: '무한거울', t: 'C', e: 9, c: 4, v: 'core', st: { en: 12, rf: 0.1, sh: 30, wt: 3 } },
  ];
  const NP = PARTS.length;
  /* compact ids: one char per part (+ star digit). '-' = empty slot, '.' = sold shop card */
  const AL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&()*+,/:;<=>?@[]^_{|}~';
  const COPIES = [0, 1, 3, 9];
  const BENCH = 4, SHOP = 5, MAXR = 25, START_GOLD = 8, MAXG = 60;
  const price = (i) => PARTS[i].c + 1;
  const sellValue = (it) => price(it.i) * COPIES[it.l];
  const STARS = ['', '★', '★★', '★★★'];
  const WEAPON_EL = ['불 붙음', '감전 충전', '보호막 충전(피해의 20%)', '', '느려짐', '흡수 회복(피해의 25%)', '부식(상대 방어 깎기)', '치명타 확률 +10%', '', '눈부심(상대가 15% 더 빗맞힘)'];
  const SPECIAL_D = ['큰 불 피해 + 오래 타는 불', '큰 피해 + 1.2초 감전', '체력 15% 보호막', '빠른 5연타', '피해 + 얼림 + 느려짐', '체력 12% 회복', '방어를 크게 깎는 산성 피해', '방어를 무시하는 큰 피해', '드론 폭격 피해', '3초 동안 받은 피해 60% 더 되돌림 + 작은 보호막'];

  /* ============================== encoding ============================== */
  function dec(str) {
    const out = [];
    for (let k = 0; k + 1 < (str || '').length; k += 2) {
      const c = str[k];
      if (c === '-') { out.push(null); continue; }
      const i = AL.indexOf(c), l = +str[k + 1];
      out.push(i >= 0 && i < NP && l >= 1 && l <= 3 ? { i, l } : null);
    }
    return out;
  }
  const encE = (arr) => arr.map((x) => (x ? AL[x.i] + x.l : '--')).join('');
  const encB = (arr) => arr.filter(Boolean).map((x) => AL[x.i] + x.l).join('');
  const decE = (str) => { const a = dec(str); while (a.length < 6) a.push(null); return a.slice(0, 6); };
  function model(s, i) { return { e: decE(s.e[i]), b: dec(s.b[i]).filter(Boolean), g: s.g[i] }; }
  function store(s, i, m) { s.e[i] = encE(m.e); s.b[i] = encB(m.b); s.g[i] = m.g; }
  const cloneM = (m) => ({ e: m.e.map((x) => (x ? { i: x.i, l: x.l } : null)), b: m.b.map((x) => ({ i: x.i, l: x.l })), g: m.g });

  /* ============================== robot profile ============================== */
  function scaled(key, v, l) {
    if (l <= 1) return v;
    if (key === 'hp' || key === 'ar' || key === 'd' || key === 'sh' || key === 'rg' || key === 'dn') return v * (l === 2 ? 1.8 : 3);
    if (key === 'am' || key === 'cdm' || key === 'dg' || key === 'cr' || key === 'rf') return v * (l === 2 ? 1.5 : 2);
    if (key === 'sp' || key === 'cap') return v * (l === 2 ? 1.2 : 1.4);
    if (key === 'en' && v > 0) return v * (l === 2 ? 1.3 : 1.6);
    return v;
  }
  function setCounts(e) { const n = Array(NS).fill(0); for (const x of e) if (x) n[PARTS[x.i].e]++; return n; }
  const combosOf = (n) => COMBOS.map((c) => (n[c.a] >= 2 && n[c.b] >= 2 ? 1 : 0));
  function prof(e) {
    const P = { hp: 10, ar: 0, am: 0, cdm: 0, sp: 0, cap: 6, wt: 0, eo: 4, ed: 0, sh: 0, rg: 0, dg: 0, dr: 0, cr: 0, rf: 0, dn: 0, ws: [], set: Array(NS).fill(0) };
    let hasB = false, hasL = false;
    for (let j = 0; j < 6; j++) {
      const x = e[j]; if (!x) continue;
      const D = PARTS[x.i]; P.set[D.e]++;
      if (D.t === 'B') hasB = true;
      if (D.t === 'L') hasL = true;
      for (const k in D.st) {
        const v = scaled(k, D.st[k], x.l);
        if (k === 'en') { if (v > 0) P.eo += v; else P.ed -= v; } else if (k === 'd' || k === 'cd' || k === 'r') { /* weapon */ } else P[k] += v;
      }
      if (D.t === 'W') P.ws.push({ d: scaled('d', D.st.d, x.l), cd: D.st.cd, r: D.st.r, el: D.e, j, cr: D.e === 7 ? 0.1 : 0 });
    }
    if (!hasB) { P.hp += 40; P.wt += 4; }
    P.hp *= HPM; P.sh *= HPM;
    if (!hasL) { P.sp += 8; P.cap += 10; }
    if (!P.ws.length) P.ws.push({ d: 4, cd: 1, r: 22, el: -1, j: -1, cr: 0 });
    const n = P.set;
    P.burn = n[0] >= 4 ? 2.2 : n[0] >= 2 ? 1.5 : 1;
    if (n[0] >= 4) P.am += 0.1;
    P.stunN = n[1] >= 4 ? 3 : n[1] >= 2 ? 4 : 5;
    P.stunT = n[1] >= 4 ? 1.2 : n[1] >= 2 ? 1 : 0.5;
    if (n[2] >= 4) { P.sh += P.hp * 0.28; P.dr = 0.1; } else if (n[2] >= 2) P.sh += P.hp * 0.2;
    if (n[3] >= 4) { P.cdm += 0.5; P.dg += 0.22; } else if (n[3] >= 2) { P.cdm += 0.25; P.dg += 0.1; }
    P.slowPer = n[4] >= 4 ? 0.16 : n[4] >= 2 ? 0.12 : 0.07;
    P.slowMax = n[4] >= 4 ? 0.5 : 0.45;
    P.slowAmp = (n[4] >= 4 ? 0.15 : 0) + (0);
    P.slowT = n[4] >= 4 ? 3.5 : 2.5;
    if (n[5] >= 4) { P.rg += 2; P.em = 1; } else if (n[5] >= 2) P.rg += 1.2;
    P.rg = Math.min(3.5, P.rg);
    P.co = n[6] >= 4 ? 1.5 : n[6] >= 2 ? 1.2 : 0.8;
    P.coCap = n[6] >= 4 ? 16 : 12;
    P.coAmp = n[6] >= 4 ? 0.25 : n[6] >= 2 ? 0.12 : 0;
    if (n[7] >= 4) P.cr += 0.25; else if (n[7] >= 2) P.cr += 0.18;
    P.cm = n[7] >= 4 ? 2.5 : 2;
    P.dnMul = n[8] >= 4 ? 1.9 : n[8] >= 2 ? 1.5 : 1;
    P.dnCd = n[8] >= 4 ? 1.2 : 1.5;
    if (n[9] >= 4) P.rf += 0.26; else if (n[9] >= 2) P.rf += 0.12;
    P.cb = combosOf(n);
    if (P.cb[3]) P.dnCd *= 0.77;
    P.cr = Math.min(0.6, P.cr); P.rf = Math.min(0.5, P.rf);
    P.over = P.wt > P.cap;
    P.spd = P.over ? P.sp * Math.max(0.35, P.cap / P.wt) : P.sp;
    P.dg = P.over ? 0 : Math.min(0.4, P.dg);
    P.lowE = P.ed > P.eo;
    P.rate = (1 + P.cdm) * (P.lowE ? Math.max(0.3, P.eo / P.ed) : 1);
    P.minR = 999; P.maxR = 0;
    for (const w of P.ws) { P.minR = Math.min(P.minR, w.r); P.maxR = Math.max(P.maxR, w.r); }
    P.melee = P.minR <= MELEE;
    P.D = dps(P);
    // special move: the set with the most equipped parts (tie → weapon 1's set → lower index)
    let best = -1, bn = 0;
    const w1 = e[3] ? PARTS[e[3].i].e : -1;
    for (let k = 0; k < NS; k++) if (n[k] > bn || (n[k] === bn && bn > 0 && k === w1)) { best = k; bn = n[k]; }
    P.spc = best; P.spf = best < 0 ? 1 : Math.min(1.4, 1 + 0.08 * (bn - 1));
    return P;
  }
  function dps(P) {
    let s = 0;
    for (const w of P.ws) s += (w.d * (1 + P.am)) / w.cd;
    return s * P.rate;
  }

  /* ============================== fight sim (deterministic) ============================== */
  function rng(seed) {
    let a = seed >>> 0;
    return function () {
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const DT = 0.1, MAXT = 450, OT = 200, MELEE = 26, GAP = 20, GAUGE_T = 10, HPM = 1.5;
  /* returns {w: 0|1|2(draw), hp, mx, t, fr?, ev?, pr}
     frames: [ax, bx, ahp, bhp, ash, bsh, flags, agauge, bgauge]
     events: [tick, target, type, value, extra]  types: h hit (extra = weapon idx, −2 special; value<0 → crit),
       m miss, s stun, b burn sum, r regen sum, f reflected sum, d drone volley, x special (target = caster, extra = set) */
  function sim(ea, eb, seed, rec) {
    const R = rng(seed);
    const pr = [prof(ea), prof(eb)];
    const S = pr.map((P, k) => ({ x: k ? 86 : 14, hp: P.hp, sh: P.sh, burn: 0, burnT: 0, stun: 0, slow: 0, slowT: 0, hits: 0, em: P.em ? 1 : 0,
      acc: 0, racc: 0, facc: 0, cor: 0, blind: 0, mir: 0, g: 0, dnT: P.dnCd * (0.6 + 0.1 * k),
      wt: P.ws.map((w, j) => w.cd * (0.35 + 0.2 * j) + k * 0.05) }));
    const fr = rec ? [] : null, ev = rec ? [] : null;
    let t = 0, w = -1;
    function hurt(T, P, v) {
      if (T.sh > 0) { const a = Math.min(T.sh, v); T.sh -= a; v -= a; }
      T.hp -= v;
      T.g = Math.min(100, T.g + (v / P.hp) * 60);
    }
    function armor(v, T, Q, ign) {
      const ar = ign ? 0 : Math.max(0, Q.ar - T.cor);
      return Math.max(v * 0.4, v - ar * 0.6) * (1 - Q.dr);
    }
    function reflect(k, dmg) { // target 1-k got dmg from k → some of it bounces back to k
      const B = S[1 - k], Q = pr[1 - k], A = S[k];
      let f = Q.rf + (B.mir > 0 ? 0.6 : 0);
      if (f <= 0) return;
      if (Q.cb[2] && B.sh > 0) f *= 2;
      const v = dmg * Math.min(0.9, f);
      hurt(A, pr[k], v); A.facc += v;
    }
    function special(k) {
      const A = S[k], B = S[1 - k], P = pr[k], Q = pr[1 - k], f = P.spf, D = Math.max(3, P.D);
      A.g = 0;
      if (ev) ev.push([t, k, 'x', 0, P.spc]);
      const hit = (v, ign) => { const d = armor(v, B, Q, ign); hurt(B, Q, d); if (ev) ev.push([t, 1 - k, 'h', Math.round(d), -2]); };
      switch (P.spc) {
        case 0: hit(1.3 * D * f); B.burn = Math.max(B.burn, 0.3 * D * f); B.burnT = 4; break;
        case 1: hit(1.1 * D * f); B.stun = Math.max(B.stun, 1.2); if (ev) ev.push([t, 1 - k, 's', 0, -2]); break;
        case 2: A.sh = Math.min(P.hp * 0.6, A.sh + P.hp * 0.15 * f); break;
        case 3: for (let q = 0; q < 5; q++) hit(0.26 * D * f); break;
        case 4: hit(0.8 * D * f); B.stun = Math.max(B.stun, 0.9); B.slow = Math.max(B.slow, 0.45); B.slowT = 3; break;
        case 5: { const v = Math.min(P.hp - A.hp, P.hp * 0.12 * f); if (v > 0) { A.hp += v; if (ev) ev.push([t, k, 'r', Math.round(v), -2]); } break; }
        case 6: B.cor = Math.min(P.coCap + 4, B.cor + 3 * f); hit(1.1 * D * f); break;
        case 7: hit(1.8 * D * f, true); break;
        case 8: hit(1.6 * D * f); break;
        case 9: A.mir = 3; A.sh += P.hp * 0.06 * f; break;
        default: hit(1.2 * D);
      }
    }
    for (t = 0; t < MAXT; t++) {
      for (let k = 0; k < 2; k++) {
        const A = S[k], B = S[1 - k], P = pr[k], Q = pr[1 - k];
        const dir = k ? -1 : 1;
        if (A.hp <= 0 || B.hp <= 0) continue;
        // drones keep flying even while the robot is stunned
        if (P.dn > 0) {
          A.dnT -= DT;
          if (A.dnT <= 0) {
            A.dnT += P.dnCd;
            let v = P.dn * P.dnMul * (1 + P.am);
            v = Math.max(v * 0.5, v - Math.max(0, Q.ar - B.cor) * 0.3) * (1 - Q.dr);
            hurt(B, Q, v); reflect(k, v);
            if (P.cb[4]) A.hp = Math.min(P.hp, A.hp + P.hp * 0.01);
            if (ev) ev.push([t, 1 - k, 'd', Math.round(v), Math.min(4, Math.max(1, Math.round(P.dn / 2.5)))]);
          }
        }
        if (A.stun > 0) { A.stun -= DT; continue; }
        const dist = Math.abs(B.x - A.x);
        let mv = 0;
        if (P.melee) { if (dist > P.minR - 2) mv = 1; } else if (dist > P.maxR * 0.9) mv = 1; else if (dist < Math.min(40, P.maxR * 0.7)) mv = -1;
        const slowMul = 1 - A.slow;
        if (mv) {
          let nx = A.x + dir * mv * P.spd * DT * slowMul;
          nx = Math.max(6, Math.min(94, nx));
          if (Math.abs(B.x - nx) < GAP) nx = B.x - dir * GAP;
          A.x = nx;
        }
        const d2 = Math.abs(B.x - A.x);
        const rate = P.rate * slowMul;
        for (let j = 0; j < P.ws.length; j++) {
          const W = P.ws[j];
          A.wt[j] -= DT * rate;
          if (A.wt[j] > 0 || d2 > W.r + 1) { if (A.wt[j] < 0) A.wt[j] = 0; continue; }
          A.wt[j] = W.cd;
          if (R() < Q.dg + (A.blind > 0 ? 0.15 : 0)) { if (ev) ev.push([t, 1 - k, 'm', 0, j]); continue; }
          let dmg = W.d * (1 + P.am);
          const crit = (P.cb[1] && B.stun > 0) || R() < P.cr + W.cr;
          if (crit) dmg *= P.cm;
          dmg = armor(dmg, B, Q, false);
          if (P.coAmp && B.cor > 0) dmg *= 1 + P.coAmp;
          if (B.slow > 0) dmg *= 1 + P.slowAmp + (P.cb[0] ? 0.15 : 0);
          hurt(B, Q, dmg);
          if (ev) ev.push([t, 1 - k, 'h', crit ? -Math.max(1, Math.round(dmg)) : Math.round(dmg), j]);
          reflect(k, dmg);
          if (W.el === 0) { B.burn = Math.max(B.burn, W.d * 0.4 * P.burn * (P.cb[5] && B.cor > 0 ? 1.4 : 1)); B.burnT = 3; }
          else if (W.el === 1) { A.hits++; if (A.hits % P.stunN === 0) { B.stun = Math.max(B.stun, P.stunT); if (ev) ev.push([t, 1 - k, 's', 0, j]); } }
          else if (W.el === 2) A.sh = Math.min(P.hp * 0.6, A.sh + dmg * 0.2);
          else if (W.el === 4) { B.slow = Math.min(P.slowMax, B.slow + P.slowPer); B.slowT = P.slowT; }
          else if (W.el === 5) A.hp = Math.min(P.hp, A.hp + dmg * 0.25);
          else if (W.el === 6) B.cor = Math.min(P.coCap, B.cor + P.co);
          else if (W.el === 9) B.blind = 2;
          if (A.hp <= 0 || B.hp <= 0) break;
        }
        if (A.g >= 100 && A.hp > 0 && B.hp > 0) special(k);
      }
      for (let k = 0; k < 2; k++) {
        const A = S[k], P = pr[k];
        let loss = 0, gain = 0;
        if (A.burnT > 0) { loss += A.burn * DT; A.burnT -= DT; if (A.burnT <= 0) A.burn = 0; }
        if (t >= OT) loss += P.hp * 0.02 * (1 + (t - OT) / 40) * DT;
        if (A.slowT > 0) { A.slowT -= DT; if (A.slowT <= 0) A.slow = 0; }
        if (A.blind > 0) A.blind -= DT;
        if (A.mir > 0) A.mir -= DT;
        if (P.rg > 0 && A.hp > 0) gain = Math.min(P.hp - A.hp, P.hp * P.rg / 100 * DT);
        if (loss) { A.hp -= loss; A.acc += loss; }
        if (gain > 0) { A.hp += gain; A.racc += gain; }
        if (A.em && A.hp > 0 && A.hp < P.hp * 0.5) { A.em = 0; A.hp += P.hp * 0.15; if (ev) ev.push([t, k, 'r', Math.round(P.hp * 0.15), -1]); }
        A.g = Math.min(100, A.g + DT * 100 / GAUGE_T);
        if (ev && t % 10 === 9) {
          if (A.acc >= 0.5) ev.push([t, k, 'b', Math.round(A.acc), -1]);
          if (A.racc >= 0.5) ev.push([t, k, 'r', Math.round(A.racc), -1]);
          if (A.facc >= 0.5) ev.push([t, k, 'f', Math.round(A.facc), -1]);
          A.acc = 0; A.racc = 0; A.facc = 0;
        }
      }
      if (fr) {
        const fl = (k) => (S[k].stun > 0 ? 1 : 0) | (S[k].burnT > 0 ? 2 : 0) | (S[k].slow > 0 ? 4 : 0) | (S[k].cor > 0 ? 8 : 0) | (S[k].blind > 0 ? 16 : 0) | (S[k].mir > 0 ? 32 : 0);
        fr.push([S[0].x, S[1].x, Math.max(0, S[0].hp), Math.max(0, S[1].hp), S[0].sh, S[1].sh, fl(0) | (fl(1) << 8), S[0].g, S[1].g]);
      }
      const d0 = S[0].hp <= 0, d1 = S[1].hp <= 0;
      if (d0 || d1) { w = d0 && d1 ? 2 : d0 ? 1 : 0; break; }
    }
    if (w < 0) { const f0 = S[0].hp / pr[0].hp, f1 = S[1].hp / pr[1].hp; w = Math.abs(f0 - f1) < 1e-9 ? 2 : f0 > f1 ? 0 : 1; }
    return { w, hp: [S[0].hp, S[1].hp], mx: [pr[0].hp, pr[1].hp], t: Math.min(t + 1, MAXT), fr, ev, pr };
  }

  /* ============================== shop / build rules ============================== */
  function tierOdds(r) {
    const t4 = r >= 7 ? Math.min(0.12, 0.02 * (r - 6)) : 0;
    const t3 = Math.min(0.3, Math.max(0, 0.05 * (r - 2)));
    const t1 = Math.max(0.2, 0.8 - 0.06 * (r - 1));
    return [0, t1, Math.max(0, 1 - t1 - t3 - t4), t3, t4];
  }
  /* each owned piece of a part (★ = 1, ★★ = 2; ★★★ is maxed) adds +100% weight, up to ×5 */
  function boostOf(m, id) {
    let n = 0;
    for (const x of m.e) if (x && x.i === id && x.l < 3) n += x.l;
    for (const x of m.b) if (x.i === id && x.l < 3) n += x.l;
    return Math.min(4, n);
  }
  const weightOf = (m, id) => 1 + (m ? boostOf(m, id) : 0);
  const POOLS = [[], [], [], [], []];
  for (let i = 0; i < NP; i++) POOLS[PARTS[i].c].push(i);
  /* chance (0..1) that one shop card shows part id */
  function slotRate(r, m, id) {
    const od = tierOdds(r), c = PARTS[id].c;
    let sum = 0; for (const i of POOLS[c]) sum += weightOf(m, i);
    return od[c] * weightOf(m, id) / sum;
  }
  function rollShop(r, m) {
    const od = tierOdds(r);
    let out = '';
    for (let k = 0; k < SHOP; k++) {
      let x = Math.random(), tier = 1;
      for (let c = 1; c <= 4; c++) { if (x < od[c]) { tier = c; break; } x -= od[c]; tier = c; }
      if (!POOLS[tier].length || !od[tier]) tier = 1;
      const pool = POOLS[tier];
      let sum = 0; for (const i of pool) sum += weightOf(m, i);
      let y = Math.random() * sum, pick = pool[pool.length - 1];
      for (const i of pool) { y -= weightOf(m, i); if (y < 0) { pick = i; break; } }
      out += AL[pick];
    }
    return out;
  }
  function slotsFor(t) { return t === 'W' ? [3, 4] : [SLOTS.indexOf(t)]; }
  function merge(m) {
    for (let guard = 0; guard < 6; guard++) {
      const g = {};
      m.e.forEach((x, j) => { if (x && x.l < 3) (g[x.i + '_' + x.l] = g[x.i + '_' + x.l] || []).push({ w: 'e', j }); });
      m.b.forEach((x, j) => { if (x && x.l < 3) (g[x.i + '_' + x.l] = g[x.i + '_' + x.l] || []).push({ w: 'b', j }); });
      let done = false;
      for (const key in g) {
        const ps = g[key];
        if (ps.length < 3) continue;
        const keep = ps.find((p) => p.w === 'e') || ps[0], rest = ps.filter((p) => p !== keep).slice(0, 2);
        const it = keep.w === 'e' ? m.e[keep.j] : m.b[keep.j];
        it.l++;
        const bi = [];
        for (const p of rest) { if (p.w === 'e') m.e[p.j] = null; else bi.push(p.j); }
        bi.sort((a, b) => b - a).forEach((j) => m.b.splice(j, 1));
        done = true; m.merged = it; break;
      }
      if (!done) break;
    }
    autofill(m);
  }
  function autofill(m) {
    for (let j = 0; j < 6; j++) {
      if (m.e[j]) continue;
      let best = -1;
      m.b.forEach((x, k) => { if (PARTS[x.i].t === SLOTS[j] && (best < 0 || x.l > m.b[best].l)) best = k; });
      if (best >= 0) { m.e[j] = m.b[best]; m.b.splice(best, 1); }
    }
  }
  /* buy part id into model; returns false if it does not fit */
  function buyInto(m, id) {
    if (m.g < price(id)) return false;
    const it = { i: id, l: 1 };
    const free = slotsFor(PARTS[id].t).find((j) => !m.e[j]);
    if (free != null) m.e[free] = it; else m.b.push(it);
    m.g -= price(id);
    m.merged = null;
    merge(m);
    return m.b.length <= BENCH;
  }

  /* ============================== AI ============================== */
  const DEF_CX = { ar: 2, dg: 0.05 };
  function ctxOf(s, seat, lv) {
    if (lv < 3) return DEF_CX;
    let ar = 0, dg = 0, n = 0;
    for (let i = 0; i < s.n; i++) if (i !== seat && !s.o[i]) { const P = prof(decE(s.e[i])); ar += P.ar; dg += P.dg; n++; }
    return n ? { ar: ar / n, dg: dg / n } : DEF_CX;
  }
  /* rough "how strong is this build" score (effective HP × damage per second) */
  function power(e, cx) {
    const P = prof(e);
    const ear = Math.max(0, cx.ar - P.co * 2.5);
    let dp = 0;
    for (const w of P.ws) {
      const raw = w.d * (1 + P.am);
      let per = Math.max(raw * 0.4, raw - ear * 0.6) * (1 + Math.min(0.9, P.cr + w.cr) * (P.cm - 1));
      if (w.el === 0) per += w.d * 0.4 * P.burn * Math.min(3, w.cd * 3) / 3;
      if (w.el === 1) per *= 1 + P.stunT / P.stunN * 0.8;
      if (w.el === 2) per *= 1.08;
      if (w.el === 5) per *= 1.1;
      if (w.el === 6) per *= 1.06;
      if (w.el === 9) per *= 1.06;
      if (w.r <= MELEE) per *= 0.75 + Math.min(0.25, P.spd / 70);
      else per *= 0.95 + Math.min(0.15, w.r / 600);
      dp += per / w.cd;
    }
    dp *= Math.pow(P.rate, 0.8) * (1 - cx.dg);
    if (P.dn) dp += 1.15 * Math.max(P.dn * 0.5, P.dn - ear * 0.3) * P.dnMul * (1 + P.am) / P.dnCd;
    dp *= 1 + P.rf * 1.6;
    if (P.coAmp) dp *= 1.1;
    dp *= 1 + 0.18 * P.spf;
    let ehp = (P.hp + P.sh * 0.75) * (1 + P.rg * 0.12) / (1 - P.dg * 0.6) / (1 - P.dr) * (1 + P.ar / 14);
    if (P.set[4] && P.ws.some((w) => w.el === 4)) ehp *= 1 + P.slowPer * 1.5;
    if (P.em) ehp *= 1.12;
    let cb = 0; for (const c of P.cb) cb += c;
    return ehp * dp * (1 + 0.06 * cb);
  }
  function optimize(m, sc) {
    for (let pass = 0; pass < 2; pass++) {
      for (let j = 0; j < 6; j++) {
        let base = sc(m.e);
        for (let k = 0; k < m.b.length; k++) {
          const x = m.b[k];
          if (PARTS[x.i].t !== SLOTS[j]) continue;
          const old = m.e[j];
          m.e[j] = x;
          const v = sc(m.e);
          if (v > base + 1e-6) { base = v; if (old) m.b[k] = old; else m.b.splice(k, 1), k--; }
          else m.e[j] = old;
        }
      }
    }
  }
  function ownedCount(m, id, l) {
    let c = 0;
    for (const x of m.e) if (x && x.i === id && x.l === l) c++;
    for (const x of m.b) if (x.i === id && x.l === l) c++;
    return c;
  }
  function mainSet(m) {
    const c = Array(NS).fill(0);
    for (const x of m.e) if (x) c[PARTS[x.i].e] += 2;
    for (const x of m.b) c[PARTS[x.i].e] += 1;
    let b = 0; for (let k = 1; k < NS; k++) if (c[k] > c[b]) b = k;
    return c[b] ? b : -1;
  }
  function botShop(s, seat, lv) {
    const m = model(s, seat);
    let shop = s.sh[seat].split('');
    if (lv <= 1) {
      for (let tries = 0; tries < 4; tries++) {
        const opts = []; shop.forEach((c, k) => { if (c !== '.' && price(AL.indexOf(c)) <= m.g) opts.push(k); });
        if (!opts.length || Math.random() < 0.25) break;
        const k = opts[Math.floor(Math.random() * opts.length)];
        const t = cloneM(m);
        if (buyInto(t, AL.indexOf(shop[k]))) { Object.assign(m, t); shop[k] = '.'; }
      }
      if (Math.random() < 0.5 && m.b.length) { // sometimes swap a random spare in
        const x = m.b[0], js = slotsFor(PARTS[x.i].t), j = js[Math.floor(Math.random() * js.length)];
        const old = m.e[j]; m.e[j] = x; m.b.splice(0, 1); if (old) m.b.push(old);
      }
      store(s, seat, m); s.sh[seat] = shop.join(''); return;
    }
    const cx = ctxOf(s, seat, lv);
    const noise = lv === 2 ? () => 0.9 + Math.random() * 0.2 : () => 1;
    const sc = (e) => power(e, cx);
    let rolls = lv === 3 ? 4 : 1;
    const target = lv === 3 ? mainSet(m) : -1;
    const reserve = lv === 3 && s.r >= 4 && s.h[seat] > s.mh * 0.5 ? 10 : 0;
    optimize(m, sc);
    for (let step = 0; step < 24; step++) {
      const base = sc(m.e);
      let best = null, bv = 0;
      shop.forEach((c, k) => {
        if (c === '.') return;
        const id = AL.indexOf(c);
        if (price(id) > m.g) return;
        const t = cloneM(m);
        if (t.b.length >= BENCH && ownedCount(t, id, 1) < 2) { // make room: sell the cheapest spare that is not a merge candidate
          let si = -1;
          t.b.forEach((x, q) => { if (ownedCount(t, x.i, x.l) < 2 && (si < 0 || sellValue(x) < sellValue(t.b[si]))) si = q; });
          if (si < 0) return;
          t.g += sellValue(t.b[si]); t.b.splice(si, 1);
        }
        if (!buyInto(t, id)) return;
        optimize(t, sc);
        let gain = (sc(t.e) - base) / Math.max(1, base);
        // owning copies makes that part show up more often (shop rate) → duplicates are worth more than their stats
        const have = ownedCount(m, id, 1) + 2 * ownedCount(m, id, 2);
        if (have) gain += (lv === 3 ? 0.06 : 0.03) * Math.min(3, have);
        if (t.merged) gain += lv === 3 ? 0.08 : 0.04;
        if (target >= 0 && PARTS[id].e === target) gain += 0.04;
        gain *= noise();
        const left = t.g;
        if (left < reserve && gain < 0.12) return;
        const v = gain / price(id);
        if (gain > 0.01 && v > bv) { bv = v; best = { k, t }; }
      });
      if (best) { Object.assign(m, best.t); shop[best.k] = '.'; continue; }
      if (rolls > 0 && m.g >= 1 + reserve + (lv === 3 ? 2 : 3)) { rolls--; m.g -= 1; shop = rollShop(s.r, m).split(''); continue; }
      break;
    }
    // lv3: sell spares that will never merge when it lifts gold over an interest step
    if (lv === 3) {
      for (let q = m.b.length - 1; q >= 0; q--) {
        const x = m.b[q];
        if (ownedCount(m, x.i, x.l) >= 2) continue;
        const nv = m.g + sellValue(x);
        if (Math.floor(nv / 10) > Math.floor(m.g / 10) || m.b.length >= BENCH) { m.g = Math.min(MAXG, nv); m.b.splice(q, 1); }
      }
    }
    store(s, seat, m); s.sh[seat] = shop.join('');
  }

  /* ============================== shop advice (UI hints) ============================== */
  function josa(word, a, b) {
    const c = word.charCodeAt(word.length - 1) - 0xac00;
    return word + (c >= 0 && c <= 11171 && c % 28 !== 0 ? a : b);
  }
  /* per shop card: {tag, kind, score, text}; plus .best (top hint) */
  function advise(m, shopStr, r) {
    const sc = (e) => power(e, DEF_CX);
    const base = cloneM(m); optimize(base, sc);
    const p0 = Math.max(1, sc(base.e)), n0 = setCounts(base.e), c0 = combosOf(n0);
    const cards = shopStr.split('').map((c) => {
      if (c === '.') return null;
      const id = AL.indexOf(c), D = PARTS[id];
      if (price(id) > m.g) return { tag: '', kind: 'no', score: -1, id };
      const t = cloneM(m);
      if (!buyInto(t, id)) return { tag: '꽉 참', kind: 'full', score: -1, id, text: '보관함이 꽉 찼어요 — 하나 팔거나 장착하면 ' + josa(D.n, '을', '를') + ' 살 수 있어요' };
      const merged = t.merged ? t.merged.l : 0;
      optimize(t, sc);
      const gain = sc(t.e) / p0 - 1;
      // set progress if the part goes into its own slot (best of the possible slots)
      let cross = 0, combo = -1;
      for (const j of slotsFor(D.t)) {
        const e2 = base.e.slice(); e2[j] = { i: id, l: 1 };
        const n2 = setCounts(e2), c2 = combosOf(n2);
        const s = D.e;
        const cr = n2[s] >= 4 && n0[s] < 4 ? 4 : n2[s] >= 2 && n0[s] < 2 ? 2 : 0;
        if (cr > cross) cross = cr;
        c2.forEach((v, q) => { if (v && !c0[q] && combo < 0) combo = q; });
      }
      const have = ownedCount(m, id, 1);
      let score = gain * 4, tag = '', kind = '', text = '';
      const nm = josa(D.n, '을', '를');
      if (merged) { score += 3 + merged; tag = STARS[merged] + ' 합체'; kind = 'merge'; text = nm + ' 사면 ' + STARS[merged] + '로 합체! (능력 약 ' + (merged === 2 ? '1.8' : '3') + '배)'; }
      else if (combo >= 0) { score += 2.6; tag = '콤보!'; kind = 'combo'; text = nm + ' 사면 콤보 「' + COMBOS[combo].n + '」 — ' + COMBOS[combo].d; }
      else if (cross) { score += cross === 4 ? 2.5 : 1.8; tag = '세트' + cross; kind = 'set'; text = nm + ' 사면 ' + SETS[D.e].n + ' 세트 ' + cross + '개 완성! (' + (cross === 4 ? SETS[D.e].four : SETS[D.e].two) + ')'; }
      else if (gain > 0.06) { tag = '+' + Math.round(gain * 100) + '%'; kind = 'up'; text = nm + ' 사면 전투력 +' + Math.round(gain * 100) + '%'; }
      else if (have) { score += 0.4; tag = have + '/3'; kind = 'own'; text = D.n + ' ' + have + '개 보유 — 3개 모으면 ★★ 합체'; }
      return { tag, kind, score, text, id };
    });
    let best = null;
    for (const c of cards) if (c && c.score > 0.25 && c.text && (!best || c.score > best.score)) best = c;
    let hint = best ? best.text : '';
    if (!hint) {
      const any = cards.some((c) => c && c.kind !== 'no');
      if (!any && m.g < 2) hint = '금화가 모자라요 — 준비 완료하고 다음 라운드에 사요';
      else if (m.g >= 10) hint = '살 만한 게 없으면 아껴 둬요 — 금화 10마다 이자 +1 (최대 2)';
      else hint = '살 만한 게 없으면 「↻ 1」 새로고침 — 가진 부품은 더 자주 나와요';
    }
    return { cards, hint, kind: best ? best.kind : '' };
  }

  /* ============================== core logic ============================== */
  function init(players, opts) {
    const n = players.length;
    const mh = (opts && +opts.life) || 30;
    const s = { n, r: 1, mh, ph: 's', nm: players.map((p) => String(p.name || '').slice(0, 6)),
      h: Array(n).fill(mh), g: Array(n).fill(START_GOLD), e: Array(n).fill('------------'), b: Array(n).fill(''), sh: [], k: Array(n).fill(0),
      o: Array(n).fill(0), lo: Array(n).fill(-1), wn: Array(n).fill(0), last: null };
    for (let i = 0; i < n; i++) s.sh.push(rollShop(1, null));
    return s;
  }
  function alive(s) { const a = []; for (let i = 0; i < s.n; i++) if (!s.o[i]) a.push(i); return a; }
  function actor(s) {
    if (s.ph !== 's') return null;
    const a = []; for (let i = 0; i < s.n; i++) if (!s.o[i] && !s.k[i]) a.push(i);
    return a.length ? a : null;
  }
  function pairUp(s) {
    const al = alive(s);
    let best = null, bc = 1e9;
    for (let tries = 0; tries < 12; tries++) {
      const o = U.shuffle(al.slice());
      let c = 0;
      for (let k = 0; k + 1 < o.length; k += 2) if (s.lo[o[k]] === o[k + 1] || s.lo[o[k + 1]] === o[k]) c++;
      if (c < bc) { bc = c; best = o; }
      if (!c) break;
    }
    return best;
  }
  function lossDmg(r, frac) { return Math.min(12, 2 + Math.floor(r / 2) + Math.ceil(4 * Math.max(0, Math.min(1, frac)))); }
  function resolve(s) {
    const o = pairUp(s);
    const f = [];
    const fight = (a, b, ghost) => {
      const seed = Math.floor(Math.random() * 2147483647);
      const ea = s.e[a], eb = s.e[b];
      const R = sim(decE(ea), decE(eb), seed, false);
      let dmg = 0;
      if (R.w === 2) {
        dmg = Math.max(1, Math.floor(lossDmg(s.r, 0) / 2));
        s.h[a] -= dmg; s.wn[a] = 0; if (!ghost) { s.h[b] -= dmg; s.wn[b] = 0; }
      } else {
        const win = R.w === 0 ? a : b, lose = R.w === 0 ? b : a;
        dmg = lossDmg(s.r, Math.max(0, R.hp[R.w]) / R.mx[R.w]);
        if (!(ghost && lose === b)) { s.h[lose] -= dmg; s.wn[lose] = 0; }
        if (!(ghost && win === b)) s.wn[win] = 1;
      }
      s.lo[a] = b; if (!ghost) s.lo[b] = a;
      f.push([a, b, ea, eb, seed, R.w, dmg, ghost ? 1 : 0]);
    };
    for (let k = 0; k + 1 < o.length; k += 2) fight(o[k], o[k + 1], false);
    if (o.length % 2) {
      const a = o[o.length - 1], others = o.filter((x) => x !== a);
      fight(a, others[Math.floor(Math.random() * others.length)], true);
    }
    s.last = { id: ((s.last && s.last.id) || 0) + 1, r: s.r, f };
    for (let i = 0; i < s.n; i++) if (!s.o[i] && s.h[i] <= 0) s.o[i] = s.r;
    const al = alive(s);
    if (al.length <= 1 || s.r >= MAXR) { s.ph = 'e'; return; }
    s.r++;
    for (const i of al) {
      s.g[i] += 5 + Math.min(2, Math.floor(s.g[i] / 10)) + (s.wn[i] ? 1 : 0);
      s.g[i] = Math.min(MAXG, s.g[i]);
      s.sh[i] = rollShop(s.r, model(s, i)); s.k[i] = 0;
    }
  }
  function apply(s, seat, a) {
    if (s.ph !== 's' || s.o[seat] || s.k[seat]) throw new Error('not now');
    if (!a || typeof a !== 'object') throw new Error('bad action');
    const m = model(s, seat);
    switch (a.t) {
      case 'buy': {
        const k = a.k | 0;
        const c = s.sh[seat][k];
        if (!c || c === '.') throw new Error('sold');
        const id = AL.indexOf(c);
        if (id < 0) throw new Error('sold');
        if (m.g < price(id)) throw new Error('gold');
        if (!buyInto(m, id)) throw new Error('full');
        store(s, seat, m);
        s.sh[seat] = s.sh[seat].slice(0, k) + '.' + s.sh[seat].slice(k + 1);
        return s;
      }
      case 'roll':
        if (m.g < 1) throw new Error('gold');
        s.g[seat] -= 1; m.g -= 1; s.sh[seat] = rollShop(s.r, m); return s;
      case 'eq': {
        const x = m.b[a.i], j = a.j | 0;
        if (!x || j < 0 || j > 5 || PARTS[x.i].t !== SLOTS[j]) throw new Error('bad equip');
        const old = m.e[j]; m.e[j] = x;
        if (old) m.b[a.i] = old; else m.b.splice(a.i, 1);
        store(s, seat, m); return s;
      }
      case 'un': {
        const j = a.j | 0;
        if (!m.e[j] || m.b.length >= BENCH) throw new Error('no room');
        m.b.push(m.e[j]); m.e[j] = null; store(s, seat, m); return s;
      }
      case 'mv': { // weapon 1 <-> weapon 2
        const t = m.e[3]; m.e[3] = m.e[4]; m.e[4] = t; store(s, seat, m); return s;
      }
      case 'sell': {
        const arr = a.w === 'e' ? m.e : m.b, x = arr[a.i | 0];
        if (!x) throw new Error('nothing');
        m.g = Math.min(MAXG, m.g + sellValue(x));
        if (a.w === 'e') m.e[a.i | 0] = null; else m.b.splice(a.i | 0, 1);
        store(s, seat, m); return s;
      }
      case 'bot': botShop(s, seat, U.clamp(a.lv | 0, 1, 3)); s.k[seat] = 1; break;
      case 'ok': s.k[seat] = 1; break;
      default: throw new Error('unknown');
    }
    if (!actor(s)) resolve(s);
    return s;
  }
  function ai(s, seat, lv) { return { t: 'bot', lv: lv || 2 }; }
  function aiDelayFor(s, seat, lv) { return (lv === 1 ? 700 : lv === 3 ? 350 : 500) + Math.random() * 400; }
  function standings(s) {
    const idx = Array.from({ length: s.n }, (_, i) => i);
    const key = (i) => (s.o[i] ? s.o[i] : 1000) * 1000 + s.h[i];
    return idx.sort((a, b) => key(b) - key(a)).map((i) => ({ i, key: key(i) }));
  }
  function result(s) {
    if (s.ph !== 'e') return null;
    const st = standings(s);
    const winners = st.filter((x) => x.key === st[0].key).map((x) => x.i);
    const text = st.map((x, r) => (r + 1) + '위 ' + (s.nm[x.i] || (x.i + 1) + '번') + (s.o[x.i] ? ' · ' + s.o[x.i] + '라운드 탈락' : ' · 목숨 ' + Math.max(0, s.h[x.i]))).join('\n');
    return { winners, title: winners.length === 1 ? (s.nm[winners[0]] || '') + ' 로봇 우승!' : '공동 우승', text };
  }

  /* ============================== sound (small synth, follows the app's sound switch) ============================== */
  const Snd = {
    ac: null, last: {},
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    gap(name, ms) { const n = performance.now(); if (n - (this.last[name] || 0) < ms) return false; this.last[name] = n; return true; },
    tone(f0, f1, dur, type, vol, delay) {
      const ac = this.ctx(); if (!ac) return; const t = ac.currentTime + (delay || 0), o = ac.createOscillator(), g = ac.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f0, t); if (f1) o.frequency.exponentialRampToValueAtTime(f1, t + dur);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g).connect(ac.destination); o.start(t); o.stop(t + dur + 0.02);
    },
    noise(dur, vol, type, f0, f1, delay) {
      const ac = this.ctx(); if (!ac) return; const t = ac.currentTime + (delay || 0), n = Math.max(1, Math.floor(ac.sampleRate * dur)), b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
      const src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain(); src.buffer = b; f.type = type || 'lowpass';
      f.frequency.setValueAtTime(f0, t); if (f1) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
      g.gain.setValueAtTime(vol, t); src.connect(f).connect(g).connect(ac.destination); src.start(t);
    },
    play(name, big) {
      if (!this.on()) return;
      const lim = { hit: 70, melee: 70, shot: 60, zap: 90, flame: 140, laser: 80, drone: 120, crit: 90, miss: 120, clank: 120 }[name] || 0;
      if (lim && !this.gap(name, lim)) return;
      try {
        switch (name) {
          case 'melee': this.noise(0.09, big ? 0.45 : 0.3, 'bandpass', 2400, 600); this.tone(220, 90, 0.1, 'square', big ? 0.12 : 0.07); break;
          case 'hit': this.noise(0.12, big ? 0.5 : 0.32, 'lowpass', 1800, 200); this.tone(140, 60, 0.12, 'sine', big ? 0.35 : 0.2); break;
          case 'shot': this.tone(900, 280, 0.07, 'square', 0.05); this.noise(0.05, 0.12, 'highpass', 3000); break;
          case 'laser': this.tone(1700, 420, 0.12, 'sawtooth', 0.05); break;
          case 'zap': this.noise(0.18, 0.22, 'highpass', 4000, 1200); this.tone(1200, 300, 0.08, 'square', 0.05); this.tone(600, 1500, 0.06, 'square', 0.04, 0.05); break;
          case 'flame': this.noise(0.3, 0.2, 'lowpass', 900, 300); break;
          case 'drone': this.tone(520, 700, 0.12, 'triangle', 0.06); this.noise(0.06, 0.1, 'bandpass', 2000, 900, 0.04); break;
          case 'crit': this.tone(1600, 2400, 0.08, 'square', 0.06); this.noise(0.12, 0.35, 'bandpass', 3000, 900); break;
          case 'miss': this.noise(0.12, 0.08, 'highpass', 2000, 5000); break;
          case 'clank': this.tone(820, 420, 0.18, 'triangle', 0.12); this.tone(1240, 900, 0.12, 'triangle', 0.07, 0.03); break;
          case 'boom': this.noise(1.1, 0.75, 'lowpass', 1600, 50); this.tone(90, 30, 0.9, 'sine', 0.5); break;
          case 'heal': [660, 880, 1320].forEach((f, k) => this.tone(f, 0, 0.22, 'triangle', 0.09, k * 0.07)); break;
          case 'shield': this.tone(380, 900, 0.3, 'triangle', 0.1); this.tone(570, 1350, 0.3, 'sine', 0.05, 0.05); break;
          case 'charge': this.tone(180, 1100, 0.4, 'sawtooth', 0.06); this.noise(0.4, 0.12, 'bandpass', 400, 3000); break;
          case 'coin': this.tone(1320, 0, 0.08, 'square', 0.05); this.tone(1980, 0, 0.14, 'square', 0.05, 0.06); break;
          case 'merge': [523, 659, 784, 1046, 1318].forEach((f, k) => this.tone(f, 0, 0.25, 'triangle', 0.1, k * 0.06)); break;
          case 'roll': this.noise(0.22, 0.12, 'bandpass', 600, 2500); this.tone(300, 600, 0.12, 'triangle', 0.04); break;
          case 'equip': this.tone(300, 180, 0.08, 'square', 0.06); this.noise(0.06, 0.15, 'bandpass', 2500, 800, 0.02); break;
          case 'win': [523, 659, 784, 1046].forEach((f, k) => this.tone(f, 0, 0.3, 'triangle', 0.12, k * 0.1)); break;
          case 'lose': [392, 330, 262].forEach((f, k) => this.tone(f, f * 0.9, 0.3, 'triangle', 0.1, k * 0.13)); break;
          case 'bell': this.tone(880, 0, 0.5, 'sine', 0.12); this.tone(1320, 0, 0.4, 'sine', 0.06, 0.02); break;
        }
      } catch (e) { /* ignore */ }
    },
    close() { try { this.ac && this.ac.close(); } catch (e) { /* ignore */ } this.ac = null; },
  };

  /* ============================== drawing ============================== */
  const GREY = '#8a8496';
  const colOf = (x) => (x ? SETS[PARTS[x.i].e].c : GREY);
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  function rr(c, x, y, w, hh, r) { c.beginPath(); if (c.roundRect) c.roundRect(x, y, w, hh, r); else c.rect(x, y, w, hh); }
  const OUT = 'rgba(0,0,0,.6)';
  /* anchor points of each slot on the robot (robot units, facing right) — used for highlights and part debris */
  const ANCH = [[0, -58, 30], [20, -64, 14], [0, -16, 20], [44, -64, 16], [6, -90, 16], [0, -56, 11]];
  /* robot at ground point (gx, gy), scale sc (robot ≈ 100·sc tall), facing f (1 → right).
     fx: {t, moving, swing:[..], recoil:[..], hurt, stun, burn, slow, shield, wheel, brk 0–3, hl slot, cor, mir, blind} */
  function drawRobot(c, e, gx, gy, sc, f, fx) {
    fx = fx || {};
    const t = fx.t || 0, brk = fx.brk || 0;
    const B = e[0], A = e[1], G = e[2], W1 = e[3], W2 = e[4], C = e[5];
    const lv = G ? PARTS[G.i].v : 'none';
    const hover = lv === 'jet' ? 10 + Math.sin(t * 4) * 2.5 : lv === 'hover' ? 7 + Math.sin(t * 3) * 1.5 : 0;
    const bob = fx.moving ? Math.sin(t * 14) * 1.5 : Math.sin(t * 2) * 0.8;
    c.save();
    c.translate(gx, gy);
    c.fillStyle = 'rgba(0,0,0,.35)';
    c.beginPath(); c.ellipse(0, 0, 30 * sc, 5 * sc, 0, 0, Math.PI * 2); c.fill();
    c.scale(f * sc, sc);
    c.lineJoin = 'round'; c.lineCap = 'round';
    /* ---- legs ---- */
    const lc = colOf(G), ld = shade(lc, -0.45);
    c.lineWidth = 1.8; c.strokeStyle = OUT;
    const ph = fx.moving ? Math.sin(t * 12) * 6 : 0;
    if (lv === 'wheel' || lv === 'none') {
      const r = lv === 'none' ? 7 : 10;
      c.fillStyle = shade(lc, -0.3); c.fillRect(-16, -30, 32, 10);
      for (const x of [-13, 13]) {
        c.fillStyle = '#26212e'; c.beginPath(); c.arc(x, -r, r, 0, Math.PI * 2); c.fill(); c.stroke();
        c.fillStyle = lc; c.beginPath(); c.arc(x, -r, r * 0.45, 0, Math.PI * 2); c.fill();
        c.save(); c.translate(x, -r); c.rotate((fx.wheel || 0) / r); c.strokeStyle = ld; c.beginPath(); c.moveTo(-r * 0.8, 0); c.lineTo(r * 0.8, 0); c.stroke(); c.restore();
      }
    } else if (lv === 'track') {
      c.fillStyle = '#2b2531'; rr(c, -28, -22, 56, 22, 11); c.fill(); c.stroke();
      c.fillStyle = lc; for (const x of [-17, 0, 17]) { c.beginPath(); c.arc(x, -11, 6, 0, Math.PI * 2); c.fill(); }
      c.strokeStyle = 'rgba(255,255,255,.18)'; c.beginPath();
      const off = ((fx.wheel || 0) % 8 + 8) % 8;
      for (let x = -24 + off; x < 26; x += 8) { c.moveTo(x, -22); c.lineTo(x, -19); } c.stroke();
      c.fillStyle = shade(lc, -0.3); c.fillRect(-14, -32, 28, 11);
    } else if (lv === 'leg' || lv === 'spring' || lv === 'glass') {
      for (const [x, p] of [[-10, ph], [10, -ph]]) {
        if (lv === 'spring') {
          c.strokeStyle = lc; c.lineWidth = 3; c.beginPath(); c.moveTo(x, -32);
          for (let k = 1; k <= 6; k++) c.lineTo(x + p * 0.3 + (k % 2 ? 5 : -5), -32 + k * 4.6 + Math.min(0, p) * 0.2);
          c.stroke(); c.lineWidth = 1.8;
          c.fillStyle = ld; rr(c, x - 8 + p * 0.3, -5, 16, 5, 2); c.fill();
        } else {
          if (lv === 'glass') c.globalAlpha = 0.7;
          c.fillStyle = lc; rr(c, x - 6, -34, 12, 18, 4); c.fill(); c.stroke();
          c.fillStyle = shade(lc, -0.2); rr(c, x - 5 + p * 0.4, -18, 10, 14, 3); c.fill(); c.stroke();
          c.globalAlpha = 1;
          if (lv === 'glass') { c.fillStyle = 'rgba(255,255,255,.6)'; c.fillRect(x - 3, -32, 2, 12); }
          c.fillStyle = ld; rr(c, x - 9 + p * 0.5, -5, 18, 5, 2); c.fill();
        }
      }
    } else if (lv === 'jet') {
      for (const x of [-10, 10]) {
        const fl = 10 + Math.sin(t * 30 + x) * 3;
        const g = c.createLinearGradient(0, -12 - hover, 0, -12 - hover + fl + 8);
        g.addColorStop(0, '#fff6c8'); g.addColorStop(1, 'rgba(255,120,40,0)');
        c.fillStyle = g; c.beginPath(); c.moveTo(x - 5, -12 - hover); c.lineTo(x + 5, -12 - hover); c.lineTo(x, -12 - hover + fl + 8); c.fill();
        c.fillStyle = lc; rr(c, x - 6, -34 - hover, 12, 14, 3); c.fill(); c.stroke();
      }
    } else if (lv === 'hover') {
      const g = c.createRadialGradient(0, -4, 2, 0, -4, 26);
      g.addColorStop(0, shade(lc, 0.5)); g.addColorStop(1, 'rgba(255,95,162,0)');
      c.globalAlpha = 0.55 + Math.sin(t * 9) * 0.15; c.fillStyle = g; c.beginPath(); c.ellipse(0, -4, 26, 6, 0, 0, Math.PI * 2); c.fill(); c.globalAlpha = 1;
      c.fillStyle = shade(lc, -0.25); rr(c, -24, -22 - hover, 48, 9, 4.5); c.fill(); c.stroke();
      c.fillStyle = lc; for (const x of [-14, 0, 14]) { c.beginPath(); c.arc(x, -14 - hover, 2.5, 0, 7); c.fill(); }
      c.fillStyle = ld; c.fillRect(-8, -32 - hover, 16, 10);
    } else if (lv === 'sled') {
      c.strokeStyle = lc; c.lineWidth = 4;
      c.beginPath(); c.moveTo(-26, -3); c.lineTo(20, -3); c.quadraticCurveTo(28, -3, 28, -10); c.stroke();
      c.lineWidth = 3; c.strokeStyle = ld; c.beginPath(); c.moveTo(-12, -4); c.lineTo(-10, -30); c.moveTo(10, -4); c.lineTo(10, -30); c.stroke();
      c.lineWidth = 1.8;
    } else if (lv === 'spider') {
      c.strokeStyle = lc; c.lineWidth = 3;
      for (let q = 0; q < 4; q++) {
        const x0 = -9 + q * 6, kx = -26 + q * 17, p = (q % 2 ? ph : -ph) * 0.5;
        c.beginPath(); c.moveTo(x0, -28); c.lineTo(kx + p, -36); c.lineTo(kx * 1.15 + p, 0); c.stroke();
      }
      c.lineWidth = 1.8; c.fillStyle = shade(lc, -0.3); rr(c, -16, -34, 32, 10, 5); c.fill(); c.stroke();
    } else if (lv === 'tripod') {
      c.strokeStyle = ld; c.lineWidth = 3.5;
      c.beginPath(); c.moveTo(0, -30); c.lineTo(-20 - ph * 0.3, 0); c.moveTo(0, -30); c.lineTo(0, 0); c.moveTo(0, -30); c.lineTo(20 + ph * 0.3, 0); c.stroke();
      c.lineWidth = 1.8; c.fillStyle = lc;
      for (const x of [-20 - ph * 0.3, 0, 20 + ph * 0.3]) { rr(c, x - 5, -4, 10, 4, 2); c.fill(); }
      c.beginPath(); c.arc(0, -30, 7, 0, 7); c.fill(); c.stroke();
    }
    c.translate(0, -hover + bob);
    /* ---- back weapon (slot 2) ---- */
    if (W2) drawWeapon(c, W2, -4, -84, true, fx.swing ? fx.swing[1] : 0, fx.recoil ? fx.recoil[1] : 0, t);
    /* ---- body ---- */
    const bc = colOf(B), bv = B ? PARTS[B.i].v : 'frame';
    const g = c.createLinearGradient(0, -90, 0, -30);
    g.addColorStop(0, shade(bc, 0.18)); g.addColorStop(1, shade(bc, -0.38));
    c.fillStyle = fx.hurt > 0 ? '#fff' : g; c.strokeStyle = OUT; c.lineWidth = 1.8;
    let headY = -82;
    if (bv === 'box') { rr(c, -22, -80, 44, 50, 6); c.fill(); c.stroke(); c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(-16, -40, 32, 4); }
    else if (bv === 'slim') { rr(c, -16, -82, 32, 52, 12); c.fill(); c.stroke(); }
    else if (bv === 'tank') { c.beginPath(); c.moveTo(-26, -30); c.lineTo(26, -30); c.lineTo(20, -80); c.lineTo(-20, -80); c.closePath(); c.fill(); c.stroke(); }
    else if (bv === 'fort' || bv === 'titan') {
      const wd = bv === 'titan' ? 31 : 27;
      rr(c, -wd, -86, wd * 2, 56, 4); c.fill(); c.stroke();
      c.fillStyle = shade(bc, -0.2); for (let x = -wd; x < wd - 4; x += 15) c.fillRect(x, -94, 8, 9);
      if (bv === 'titan') { c.fillStyle = shade(bc, 0.05); for (const x of [-wd - 6, wd - 6]) { rr(c, x, -88, 12, 20, 5); c.fill(); c.stroke(); } }
      c.fillStyle = 'rgba(0,0,0,.35)'; for (const x of [-wd + 7, wd - 7]) for (const y of [-76, -40]) { c.beginPath(); c.arc(x, y, 1.8, 0, 7); c.fill(); }
      headY = -94;
    } else if (bv === 'dome') { c.beginPath(); c.moveTo(-22, -30); c.lineTo(-22, -62); c.arc(0, -62, 22, Math.PI, 0); c.lineTo(22, -30); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.25)'; c.beginPath(); c.arc(-6, -70, 8, Math.PI, Math.PI * 1.6); c.lineTo(-6, -70); c.fill(); headY = -84; }
    else if (bv === 'round') { c.beginPath(); c.ellipse(0, -56, 24, 27, 0, 0, Math.PI * 2); c.fill(); c.stroke(); }
    else if (bv === 'glacier') {
      c.beginPath(); c.moveTo(-25, -30); c.lineTo(-27, -70); c.lineTo(-14, -86); c.lineTo(0, -80); c.lineTo(14, -90); c.lineTo(27, -72); c.lineTo(25, -30); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.moveTo(-18, -70); c.lineTo(-12, -80); c.lineTo(-8, -50); c.closePath(); c.fill();
      headY = -86;
    } else if (bv === 'vat') {
      rr(c, -22, -82, 44, 52, 10); c.fill(); c.stroke();
      c.fillStyle = '#1d2a12'; rr(c, -14, -74, 28, 26, 6); c.fill();
      c.fillStyle = 'rgba(212,245,66,.75)'; rr(c, -13, -66 + Math.sin(t * 2) * 1.5, 26, 17, 5); c.fill();
      c.fillStyle = 'rgba(240,255,190,.9)'; for (let q = 0; q < 3; q++) { const y = -52 - ((t * 14 + q * 7) % 14); c.beginPath(); c.arc(-7 + q * 7, y, 1.6, 0, 7); c.fill(); }
    } else if (bv === 'prism') {
      c.beginPath(); c.moveTo(0, -88); c.lineTo(24, -70); c.lineTo(20, -30); c.lineTo(-20, -30); c.lineTo(-24, -70); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.3)'; c.beginPath(); c.moveTo(0, -88); c.lineTo(-24, -70); c.lineTo(-6, -64); c.closePath(); c.fill();
      headY = -88;
    } else if (bv === 'hive') {
      c.beginPath(); c.moveTo(-28, -32); c.lineTo(28, -32); c.lineTo(22, -80); c.lineTo(-22, -80); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = '#1b1622'; for (const y of [-74, -44]) { rr(c, -18, y, 36, 7, 3); c.fill(); }
      c.fillStyle = bc; for (let q = 0; q < 3; q++) { c.beginPath(); c.arc(-10 + q * 10, -70.5, 2.2, 0, 7); c.fill(); }
    } else if (bv === 'mirror') {
      c.beginPath(); c.moveTo(0, -88); c.lineTo(24, -62); c.lineTo(16, -30); c.lineTo(-16, -30); c.lineTo(-24, -62); c.closePath(); c.fill(); c.stroke();
      const sh = ((t * 0.6) % 2) - 0.5;
      c.save(); c.clip(); c.fillStyle = 'rgba(255,255,255,.45)'; c.beginPath(); c.moveTo(-30 + sh * 60, -90); c.lineTo(-18 + sh * 60, -90); c.lineTo(-38 + sh * 60, -28); c.lineTo(-50 + sh * 60, -28); c.fill(); c.restore();
      headY = -86;
    }
    else { c.strokeStyle = GREY; c.lineWidth = 4; c.beginPath(); c.moveTo(-14, -32); c.lineTo(-14, -78); c.lineTo(14, -78); c.lineTo(14, -32); c.closePath(); c.moveTo(-14, -32); c.lineTo(14, -78); c.stroke(); c.lineWidth = 1.8; }
    /* damage = soot only (nothing breaks off): darker scorch blotches as health drops */
    if (brk >= 1) {
      c.save(); c.fillStyle = 'rgba(20,14,18,' + (0.22 + 0.12 * brk) + ')';
      const spots = [[-10, -44, 7, 5], [9, -70, 6, 4], [-6, -76, 5, 3], [12, -40, 5, 4], [-14, -62, 4, 6]];
      for (let q = 0; q < Math.min(spots.length, brk * 2); q++) { const p = spots[q]; c.beginPath(); c.ellipse(p[0], p[1], p[2], p[3], 0.4, 0, 7); c.fill(); }
      c.restore();
    }
    /* head + antenna */
    c.fillStyle = shade(bc, -0.15); c.strokeStyle = OUT;
    rr(c, -10, headY - 14, 22, 14, 4); c.fill(); c.stroke();
    { c.strokeStyle = shade(bc, -0.3); c.lineWidth = 1.6; c.beginPath(); c.moveTo(-4, headY - 14); c.lineTo(-7, headY - 22); c.stroke(); c.fillStyle = fx.stun > 0 ? '#ffd23f' : '#ff7a62'; c.beginPath(); c.arc(-7, headY - 23, 2, 0, 7); c.fill(); c.lineWidth = 1.8; }
    c.fillStyle = fx.stun > 0 ? '#ffd23f' : brk >= 3 ? '#ff5a43' : '#9ff3ff';
    rr(c, 2, headY - 10, 8, 5, 2); c.fill();
    /* core */
    const cc = C ? SETS[PARTS[C.i].e].c : '#5c5568';
    const pulse = 0.6 + Math.sin(t * 5) * 0.25;
    const cy = bv === 'fort' || bv === 'titan' ? -60 : -58;
    c.fillStyle = '#1b1622'; c.beginPath(); c.arc(0, cy, 9, 0, Math.PI * 2); c.fill();
    c.save(); c.globalAlpha = C ? pulse : 0.5; c.fillStyle = cc; c.shadowColor = cc; c.shadowBlur = C ? 12 : 0;
    c.beginPath(); c.arc(0, cy, C ? 6 + (C.l - 1) : 4, 0, Math.PI * 2); c.fill(); c.restore();
    /* ---- front arm + weapon 1 ---- */
    const ac = colOf(A), av = A ? PARTS[A.i].v : 'stub';
    const sw = fx.swing ? fx.swing[0] : 0;
    c.save(); c.translate(8, -64); c.rotate(-sw * 1.2 + (sw > 0 ? 0.4 : 0));
    c.strokeStyle = OUT; c.lineWidth = 1.8;
    if (av === 'coil') {
      c.fillStyle = shade(ac, -0.2); rr(c, 0, -4, 26, 8, 4); c.fill(); c.stroke();
      c.strokeStyle = ac; c.lineWidth = 2; c.beginPath(); for (let x = 3; x < 25; x += 4) { c.moveTo(x, -6); c.lineTo(x + 2, 6); } c.stroke();
    } else if (av === 'fast') {
      c.strokeStyle = ac; c.lineWidth = 3; c.beginPath(); c.moveTo(0, -3); c.lineTo(26, -3); c.moveTo(0, 3); c.lineTo(26, 3); c.stroke();
    } else if (av === 'wrench' || av === 'claw' || av === 'syringe') {
      c.fillStyle = ac; rr(c, 0, -5, 24, 10, 4); c.fill(); c.stroke();
      if (av === 'syringe') { c.fillStyle = 'rgba(212,245,66,.8)'; c.fillRect(4, -2.5, 14, 5); }
      if (!W1) { c.strokeStyle = ac; c.lineWidth = 3; c.beginPath(); c.moveTo(24, -2); c.lineTo(32, -7); c.moveTo(24, 2); c.lineTo(32, 7); c.stroke(); }
    } else if (av === 'shield' || av === 'mirrorarm') {
      c.fillStyle = shade(ac, -0.2); rr(c, 0, -4, 22, 8, 3); c.fill(); c.stroke();
    } else if (av === 'lens') {
      c.fillStyle = shade(ac, -0.25); rr(c, 0, -4, 22, 8, 3); c.fill(); c.stroke();
      c.fillStyle = ac; c.beginPath(); c.arc(10, -7, 4, 0, 7); c.fill(); c.stroke();
    } else if (av === 'antenna') {
      c.fillStyle = shade(ac, -0.2); rr(c, 0, -4, 24, 8, 3); c.fill(); c.stroke();
      c.strokeStyle = ac; c.lineWidth = 1.6; c.beginPath(); c.moveTo(8, -4); c.lineTo(4, -16); c.stroke();
      c.beginPath(); c.arc(4, -16, 4 + Math.sin(t * 6), Math.PI * 1.1, Math.PI * 1.9); c.stroke();
    } else { c.fillStyle = GREY; rr(c, 0, -3.5, 22, 7, 3); c.fill(); c.stroke(); }
    if (W1) drawWeapon(c, W1, 26, 0, false, 0, fx.recoil ? fx.recoil[0] : 0, t);
    else { c.fillStyle = shade(ac, -0.1); c.beginPath(); c.arc(27, 0, 6, 0, Math.PI * 2); c.fill(); c.stroke(); }
    c.restore();
    if (av === 'shield' || av === 'mirrorarm') { // plate in front of the body
      c.fillStyle = av === 'mirrorarm' ? shade(ac, 0.3) : shade(ac, 0.05); c.strokeStyle = OUT;
      c.beginPath(); c.moveTo(24, -80); c.lineTo(34, -74); c.lineTo(34, -42); c.lineTo(24, -34); c.closePath(); c.fill(); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.35)'; c.fillRect(27, -70, 3, 22);
    }
    /* highlight (garage: the slot being looked at) */
    if (fx.hl != null && fx.hl >= 0) {
      const a = ANCH[fx.hl];
      c.save(); c.globalAlpha = 0.45 + Math.sin(t * 6) * 0.25; c.strokeStyle = '#e3ae45'; c.lineWidth = 2.5; c.setLineDash([5, 4]);
      c.beginPath(); c.arc(a[0], a[1] + (fx.hl === 2 ? hover - bob : 0), a[2], 0, 7); c.stroke(); c.restore();
    }
    /* status effects */
    if (fx.shield > 0) {
      c.strokeStyle = 'rgba(169,188,207,.8)'; c.lineWidth = 2.5; c.fillStyle = 'rgba(169,188,207,.12)';
      c.beginPath(); c.ellipse(0, -52, 44, 56, 0, 0, Math.PI * 2); c.fill(); c.stroke();
    }
    if (fx.mir) { c.save(); c.strokeStyle = 'rgba(233,238,245,.85)'; c.lineWidth = 2; c.globalAlpha = 0.6 + Math.sin(t * 10) * 0.3;
      c.beginPath(); for (let q = 0; q < 6; q++) { const a = q / 6 * Math.PI * 2 + t; c.moveTo(Math.cos(a) * 40, -52 + Math.sin(a) * 50); c.lineTo(Math.cos(a + 0.6) * 40, -52 + Math.sin(a + 0.6) * 50); } c.stroke(); c.restore(); }
    if (fx.slow) { c.fillStyle = 'rgba(142,201,255,.26)'; c.beginPath(); c.ellipse(0, -52, 34, 46, 0, 0, Math.PI * 2); c.fill(); }
    if (fx.cor) { c.fillStyle = 'rgba(212,245,66,.75)'; for (let q = 0; q < 4; q++) { const y = -70 + ((t * 20 + q * 13) % 40); c.beginPath(); c.ellipse(-12 + q * 8, y, 1.6, 2.6, 0, 0, 7); c.fill(); } }
    if (fx.burn) {
      for (let k = 0; k < 4; k++) {
        const x = -14 + k * 9, y = -40 - ((t * 60 + k * 17) % 40);
        c.fillStyle = 'rgba(255,' + (120 + k * 25) + ',40,' + Math.max(0, 0.8 - ((t * 60 + k * 17) % 40) / 50) + ')';
        c.beginPath(); c.arc(x, y, 4, 0, Math.PI * 2); c.fill();
      }
    }
    if (fx.stun > 0) {
      c.strokeStyle = '#ffd23f'; c.lineWidth = 2.5; c.beginPath();
      for (let k = 0; k < 3; k++) { const a = t * 8 + k * 2.1; c.moveTo(Math.cos(a) * 20, headY - 20 + Math.sin(a) * 5); c.lineTo(Math.cos(a) * 20 + 5, headY - 26 + Math.sin(a) * 5); c.lineTo(Math.cos(a) * 20 - 2, headY - 28 + Math.sin(a) * 5); }
      c.stroke();
    }
    if (fx.blind) { c.fillStyle = 'rgba(255,255,255,.75)'; c.beginPath(); c.arc(6, headY - 7, 7 + Math.sin(t * 20), 0, 7); c.fill(); }
    c.restore();
  }
  function drawWeapon(c, x, px, py, back, sw, rc, t) {
    const D = PARTS[x.i], col = SETS[D.e].c, dk = shade(col, -0.45), v = D.v;
    c.save(); c.translate(px - rc * 6, py);
    if (back) { c.rotate(-0.12 - sw * 1.2); }
    c.strokeStyle = OUT; c.lineWidth = 1.8;
    const L2 = 1 + (x.l - 1) * 0.12; c.scale(L2, L2);
    if (x.l >= 2) { c.shadowColor = x.l === 3 ? '#ffe9a0' : col; c.shadowBlur = x.l === 3 ? 10 : 5; }
    switch (v) {
      case 'axe': c.fillStyle = '#6b4a2e'; c.fillRect(0, -2, 24, 4); c.fillStyle = col; c.beginPath(); c.moveTo(16, -2); c.lineTo(26, -14); c.lineTo(30, 0); c.lineTo(26, 12); c.lineTo(16, 2); c.closePath(); c.fill(); c.stroke(); break;
      case 'blade': c.fillStyle = '#dfe7ef'; for (const y of [-5, 4]) { c.beginPath(); c.moveTo(0, y - 1); c.lineTo(22, y); c.lineTo(0, y + 2); c.closePath(); c.fill(); } c.fillStyle = col; c.fillRect(-2, -7, 4, 14); break;
      case 'sonic': c.fillStyle = '#e8fffd'; c.beginPath(); c.moveTo(0, -3); c.quadraticCurveTo(18, -10, 30, 0); c.quadraticCurveTo(18, 4, 0, 3); c.closePath(); c.fill(); c.stroke();
        c.strokeStyle = col; c.globalAlpha = 0.6; c.beginPath(); c.arc(12, 0, 14 + Math.sin(t * 18) * 2, -0.5, 0.5); c.stroke(); c.globalAlpha = 1; c.fillStyle = col; c.fillRect(-3, -6, 4, 12); break;
      case 'mace': c.fillStyle = '#5a5363'; c.fillRect(0, -2, 18, 4); c.fillStyle = col; c.beginPath(); c.arc(24, 0, 8, 0, Math.PI * 2); c.fill(); c.stroke();
        c.beginPath(); for (let k = 0; k < 6; k++) { const a = k * 1.047; c.moveTo(24 + Math.cos(a) * 8, Math.sin(a) * 8); c.lineTo(24 + Math.cos(a) * 12, Math.sin(a) * 12); } c.stroke(); break;
      case 'hammer': c.fillStyle = '#5a5363'; c.fillRect(0, -2, 20, 4); c.fillStyle = col; rr(c, 18, -10, 10, 20, 2); c.fill(); c.stroke(); break;
      case 'rod': c.fillStyle = dk; c.fillRect(0, -2.5, 22, 5); c.fillStyle = col; c.shadowColor = col; c.shadowBlur = 10; c.beginPath(); c.arc(24, 0, 5 + Math.sin(t * 20), 0, Math.PI * 2); c.fill(); break;
      case 'pick': c.fillStyle = '#d7f0ff'; c.beginPath(); c.moveTo(0, -4); c.lineTo(28, 0); c.lineTo(0, 4); c.closePath(); c.fill(); c.stroke(); c.fillStyle = col; c.fillRect(-2, -5, 6, 10); break;
      case 'flamer': c.fillStyle = dk; rr(c, -4, -7, 12, 14, 3); c.fill(); c.stroke(); c.fillStyle = col; c.fillRect(8, -3, 14, 6); c.fillStyle = '#ffd38a'; c.beginPath(); c.arc(23, 0, 2.5, 0, 7); c.fill(); break;
      case 'dragon': c.fillStyle = dk; rr(c, -4, -8, 14, 16, 4); c.fill(); c.stroke(); c.fillStyle = col;
        c.beginPath(); c.moveTo(8, -6); c.lineTo(28, -4); c.lineTo(32, 0); c.lineTo(28, 5); c.lineTo(8, 6); c.closePath(); c.fill(); c.stroke();
        c.fillStyle = '#ffe08a'; c.beginPath(); c.moveTo(16, -6); c.lineTo(20, -12); c.lineTo(22, -5); c.fill(); c.fillStyle = '#1b1622'; c.beginPath(); c.arc(24, -1, 1.5, 0, 7); c.fill(); break;
      case 'gun': c.fillStyle = dk; rr(c, 0, -5, 12, 10, 2); c.fill(); c.stroke(); c.fillStyle = col; c.fillRect(10, -2.5, 14, 5); break;
      case 'laser': c.fillStyle = '#efe6f0'; rr(c, 0, -5, 14, 10, 3); c.fill(); c.stroke(); c.fillStyle = col; c.fillRect(12, -2, 12, 4); c.shadowColor = col; c.shadowBlur = 8; c.beginPath(); c.arc(24, 0, 2, 0, 7); c.fill(); break;
      case 'mg': c.fillStyle = dk; rr(c, 0, -6, 12, 12, 3); c.fill(); c.stroke(); c.fillStyle = col; for (const y of [-4, 0, 4]) c.fillRect(11, y - 1, 15, 2); break;
      case 'cannon': c.fillStyle = dk; rr(c, -2, -8, 14, 16, 4); c.fill(); c.stroke(); c.fillStyle = col; rr(c, 10, -5, 20, 10, 3); c.fill(); c.stroke(); break;
      case 'rail': c.fillStyle = dk; c.fillRect(0, -4, 36, 8); c.strokeRect(0, -4, 36, 8); c.fillStyle = col; for (let k = 6; k < 34; k += 7) c.fillRect(k, -6, 3, 12); break;
      case 'sniper': c.fillStyle = '#2a2430'; c.fillRect(0, -3, 40, 6); c.strokeRect(0, -3, 40, 6); c.fillStyle = col; rr(c, 6, -9, 14, 5, 2); c.fill(); c.fillRect(38, -2, 4, 4); break;
      case 'orbital': c.fillStyle = '#f2e4ee'; rr(c, -2, -7, 20, 14, 4); c.fill(); c.stroke(); c.fillStyle = col; c.fillRect(16, -3, 22, 6);
        c.strokeStyle = col; c.lineWidth = 1.5; c.beginPath(); c.ellipse(8, 0, 12, 4, t * 2, 0, 7); c.stroke(); break;
      case 'beam': c.fillStyle = dk; c.fillRect(0, -3, 14, 6); c.fillStyle = col; c.beginPath(); c.ellipse(18, 0, 4, 10, 0, 0, Math.PI * 2); c.fill(); c.stroke(); break;
      case 'mortar': c.rotate(-0.6); c.fillStyle = dk; rr(c, -4, -6, 10, 12, 3); c.fill(); c.fillStyle = col; rr(c, 4, -6, 18, 12, 3); c.fill(); c.stroke(); break;
      case 'nano': c.fillStyle = '#e8f3ea'; rr(c, 0, -4, 22, 8, 4); c.fill(); c.stroke(); c.fillStyle = col; c.fillRect(6, -1.5, 12, 3); break;
      case 'sprayer': c.fillStyle = col; c.beginPath(); c.arc(4, 0, 7, 0, 7); c.fill(); c.stroke(); c.fillStyle = dk; c.fillRect(9, -2, 14, 4); c.fillStyle = '#f0ffc0'; c.beginPath(); c.arc(24, 0, 2, 0, 7); c.fill(); break;
      case 'spear': c.fillStyle = '#5a5363'; c.fillRect(-4, -1.5, 30, 3); c.fillStyle = col; c.beginPath(); c.moveTo(24, -5); c.lineTo(36, 0); c.lineTo(24, 5); c.closePath(); c.fill(); c.stroke(); break;
      case 'lsword': c.fillStyle = '#3a3344'; c.fillRect(-2, -3, 8, 6); c.save(); c.shadowColor = col; c.shadowBlur = 12; c.fillStyle = shade(col, 0.5); rr(c, 6, -2.5, 28, 5, 2.5); c.fill(); c.restore(); break;
      case 'launcher': c.fillStyle = dk; rr(c, -2, -8, 22, 16, 3); c.fill(); c.stroke(); c.fillStyle = col; for (const y of [-4, 3]) { c.beginPath(); c.arc(18, y, 2.6, 0, 7); c.fill(); } break;
      case 'swarm': c.fillStyle = dk; rr(c, -2, -9, 20, 18, 3); c.fill(); c.stroke(); c.fillStyle = col; for (const y of [-5, 0, 5]) for (const xx of [4, 10]) { c.beginPath(); c.arc(xx + 6, y, 1.8, 0, 7); c.fill(); } break;
      case 'saw': c.fillStyle = '#5a5363'; c.fillRect(0, -2, 14, 4); c.save(); c.translate(22, 0); c.rotate(t * 14); c.fillStyle = col; c.beginPath();
        for (let k = 0; k < 10; k++) { const a = k / 10 * Math.PI * 2; c.lineTo(Math.cos(a) * 10, Math.sin(a) * 10); c.lineTo(Math.cos(a + 0.3) * 7, Math.sin(a + 0.3) * 7); } c.closePath(); c.fill(); c.stroke();
        c.fillStyle = '#2a2430'; c.beginPath(); c.arc(0, 0, 2.5, 0, 7); c.fill(); c.restore(); break;
      case 'disc': c.fillStyle = '#5a5363'; c.fillRect(0, -2, 10, 4); c.save(); c.translate(18, 0); c.rotate(t * 6); c.fillStyle = col; c.beginPath(); c.arc(0, 0, 8, 0, 7); c.fill(); c.stroke();
        c.fillStyle = 'rgba(255,255,255,.7)'; c.beginPath(); c.moveTo(0, 0); c.arc(0, 0, 8, 0, 1); c.fill(); c.restore(); break;
      case 'scythe': c.fillStyle = '#5a5363'; c.fillRect(-2, -1.5, 26, 3); c.fillStyle = col; c.beginPath(); c.moveTo(22, -2); c.quadraticCurveTo(34, -18, 14, -22); c.quadraticCurveTo(28, -12, 20, -2); c.closePath(); c.fill(); c.stroke(); break;
      default: c.fillStyle = col; c.fillRect(0, -3, 18, 6);
    }
    c.restore();
  }

  /* ============================== view ============================== */
  const CSS = `
.rb{position:absolute;inset:0;display:flex;flex-direction:column;background:radial-gradient(120% 80% at 50% 0%,#2a2238 0%,#17131f 70%);color:var(--ink);font-family:var(--f-body),sans-serif;user-select:none;-webkit-user-select:none}
.rb-top{display:flex;gap:4px;padding:4px 6px 2px;flex:none}
.rb-p{flex:1 1 0;min-width:0;min-height:44px;border-radius:10px;border:1px solid var(--line);background:var(--surface);padding:3px 4px;display:flex;flex-direction:column;justify-content:center;gap:2px;color:var(--ink);font:inherit;cursor:pointer}
.rb-p .r1{display:flex;align-items:center;gap:2px;font-size:11px;font-weight:700;white-space:nowrap;overflow:hidden}
.rb-p .r1 .nm{overflow:hidden;text-overflow:ellipsis;min-width:0;flex:1;text-align:left}
.rb-p .bar{height:5px;border-radius:3px;background:#3a3148;overflow:hidden}.rb-p .bar i{display:block;height:100%;background:#6fdc8c}
.rb-p.out{opacity:.4}.rb-p.me{border-color:var(--brass)}.rb-p .ck{color:#6fdc8c;font-size:11px}
.rb-arena{position:relative;flex:1 1 auto;min-height:150px;overflow:hidden}
.rb-eq{position:absolute;inset:0;pointer-events:none;z-index:2}
.rb-col{position:absolute;top:40px;display:flex;flex-direction:column;justify-content:center;gap:6px;width:min(25%,96px);pointer-events:auto}
.rb-col.l{left:5px}.rb-col.r{right:5px}
.rb-panel{flex:none;padding:3px 8px 8px;display:flex;flex-direction:column;gap:5px}
.rb-hint{min-height:22px;font-size:12px;line-height:1.3;color:#f5dfae;display:flex;align-items:center;gap:6px;padding:2px 8px;border-radius:8px;background:rgba(227,174,69,.1);border:1px solid rgba(227,174,69,.22)}
.rb-hint b{flex:none;font-size:10px;color:#1a1422;background:var(--brass);border-radius:5px;padding:0 5px}
.rb-hint span{min-width:0;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.rb-info{display:flex;align-items:center;gap:6px;min-height:44px}
.rb-gold{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;min-height:44px;padding:2px 8px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--ink);font:inherit;cursor:pointer;flex:1 1 auto;min-width:0}
.rb-gold .gv{display:flex;align-items:center;gap:5px;font-family:var(--f-mono),monospace;font-weight:700;font-size:17px;color:var(--brass);line-height:1.1}
.rb-gold .gv i{width:14px;height:14px;border-radius:50%;background:radial-gradient(circle at 35% 35%,#ffe7a1,#c98d1f);box-shadow:0 0 0 1.5px #7a5410 inset}
.rb-gold .sub{font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.rb-roll{flex:none;min-height:44px;padding:4px 10px}
.rb-go{flex:none;min-height:44px;font-size:15px;padding:6px 14px}
.rb-row{display:grid;gap:4px}
.rb-bench{grid-template-columns:auto repeat(4,minmax(0,1fr))}
.rb-shop{grid-template-columns:repeat(5,minmax(0,1fr))}
.rb-t{position:relative;min-height:46px;border-radius:9px;border:1px solid var(--line);border-left:4px solid var(--c,#5c5568);background:linear-gradient(#2e2640ee,#251e33ee);color:var(--ink);font:inherit;padding:2px 3px 2px 4px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;cursor:pointer;overflow:hidden;width:100%}
.rb-t .k{font-size:9px;color:var(--muted);line-height:1.1}
.rb-t .n{font-size:11px;font-weight:700;line-height:1.15;word-break:keep-all;text-align:center}
.rb-t .s{font-size:9px;color:var(--brass);line-height:1}
.rb-t.empty{border-style:dashed;border-left-width:1px;background:rgba(23,19,31,.6);color:var(--muted)}
.rb-t.sel{outline:2px solid var(--brass);outline-offset:-2px}
.rb-t.mg{box-shadow:0 0 0 2px #ffd23f inset}
.rb-lab{font-size:10px;color:var(--muted);writing-mode:vertical-rl;text-align:center;align-self:center;letter-spacing:1px}
.rb-c{position:relative;min-height:90px;border-radius:10px;border:1px solid var(--line);background:linear-gradient(#332a45,#241d31);color:var(--ink);font:inherit;padding:0 0 3px;display:flex;flex-direction:column;align-items:stretch;cursor:pointer;overflow:hidden;transition:transform .08s}
.rb-c:active{transform:scale(.96)}
.rb-c .band{height:16px;background:var(--c);color:#1a1422;font-size:10px;font-weight:800;display:flex;align-items:center;justify-content:center;gap:2px;white-space:nowrap}
.rb-c .n{font-size:11px;font-weight:700;line-height:1.15;margin-top:3px;text-align:center;word-break:keep-all;padding:0 2px}
.rb-c .k{font-size:9px;color:var(--muted);text-align:center}
.rb-c .v{font-size:9.5px;text-align:center;color:#d9cfe6;line-height:1.1}
.rb-c .tg{align-self:center;margin-top:2px;font-size:9px;font-weight:800;border-radius:5px;padding:0 4px;color:#1a1422;background:#ffd23f;line-height:14px}
.rb-c .tg.set{background:var(--c)}.rb-c .tg.combo{background:#ff9f5a}.rb-c .tg.up{background:#6fdc8c}.rb-c .tg.own{background:transparent;color:var(--brass);border:1px solid var(--brass);line-height:12px}
.rb-c .pr{margin-top:auto;display:flex;justify-content:space-between;align-items:center;padding:0 4px;font-family:var(--f-mono),monospace;font-size:12px;font-weight:700;color:var(--brass)}
.rb-c .pr .bo{font-size:9px;color:#9ff3a0;font-family:var(--f-body),sans-serif}
.rb-c.t3{background:linear-gradient(#3b2f52,#261e36)}.rb-c.t4{background:linear-gradient(#4a3a22,#2a2018);border-color:#e3ae45}
.rb-c.no{opacity:.45}.rb-c.sold{visibility:hidden}
.rb-c.best{box-shadow:0 0 0 2px var(--brass);animation:rbpulse 1.4s ease-in-out infinite}
@keyframes rbpulse{50%{box-shadow:0 0 0 2px var(--brass),0 0 12px rgba(227,174,69,.6)}}
.rb-wait{display:flex;flex-direction:column;gap:6px;align-items:center;padding:6px 0;text-align:center}
.rb-wait .ln{font-weight:700}
.rb-ctl{display:flex;gap:6px;align-items:center}
.rb-ctl .btn{flex:1;padding:8px 6px}
.rb-ttl{font-size:12px;color:var(--muted);text-align:center}
.rb-ov{position:absolute;inset:0;z-index:15;background:rgba(10,8,15,.7);display:flex;align-items:flex-end;justify-content:center;padding:10px}
.rb-sh{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:14px;width:min(420px,100%);max-height:92%;overflow-y:auto;display:flex;flex-direction:column;gap:8px}
.rb-sh h3{margin:0;font-family:var(--f-display),sans-serif;font-weight:400;font-size:20px}
.rb-sh .tg{display:inline-block;font-size:11px;font-weight:800;color:#1a1422;background:var(--c);border-radius:6px;padding:1px 6px;margin-right:6px}
.rb-sh .st{font-size:13px;line-height:1.5;color:#e4daf0}
.rb-sh .bt{display:flex;flex-wrap:wrap;gap:6px}.rb-sh .bt .btn{flex:1 1 40%}
.rb-sh table{border-collapse:collapse;font-size:12.5px;width:100%}.rb-sh td{padding:3px 4px;border-bottom:1px solid var(--line)}
.rb-pick{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
@media (max-height:700px){.rb-c{min-height:84px}.rb-t{min-height:44px}.rb-panel{gap:4px}}
`;
  function statLines(D, l) {
    const s = D.st, o = [];
    const v = (k) => Math.round(scaled(k, s[k], l) * 10) / 10;
    const pc = (k) => Math.round(scaled(k, s[k], l) * 100);   // 퍼센트는 반올림 전에 ×100 (0.15 → 15%)
    if (s.d) o.push('피해 ' + v('d') + ' · ' + s.cd + '초마다 · ' + (s.r <= MELEE ? '근접' : '사거리 ' + s.r));
    if (s.hp) o.push('체력 +' + v('hp'));
    if (s.ar) o.push('방어 +' + v('ar'));
    if (s.sh) o.push('보호막 +' + v('sh'));
    if (s.am) o.push('공격력 +' + pc('am') + '%');
    if (s.cdm) o.push('공격 속도 +' + pc('cdm') + '%');
    if (s.cr) o.push('치명타 +' + pc('cr') + '%');
    if (s.rf) o.push('받은 피해 ' + pc('rf') + '% 되돌림');
    if (s.dn) o.push('드론 피해 +' + v('dn'));
    if (s.sp) o.push('이동 속도 ' + v('sp'));
    if (s.cap) o.push('적재량 ' + v('cap'));
    if (s.dg) o.push('회피 +' + pc('dg') + '%');
    if (s.rg) o.push('초당 회복 ' + v('rg') + '%');
    if (s.en > 0) o.push('전력 공급 +' + v('en')); else if (s.en < 0) o.push('전력 사용 ' + (-s.en));
    o.push('무게 ' + s.wt);
    return o;
  }
  function keyStat(D) {
    const s = D.st;
    if (s.d) return '피해' + s.d + (s.r <= MELEE ? ' 근접' : ' 원거리');
    if (D.t === 'B') return '체력' + s.hp;
    if (D.t === 'L') return '속도' + s.sp;
    if (s.dn && D.t !== 'C') return '드론+' + s.dn;
    if (D.t === 'C') return '전력' + s.en;
    if (s.am) return '공격+' + Math.round(s.am * 100) + '%';
    if (s.cdm) return '속도+' + Math.round(s.cdm * 100) + '%';
    if (s.cr) return '치명+' + Math.round(s.cr * 100) + '%';
    if (s.rf) return '반사' + Math.round(s.rf * 100) + '%';
    if (s.ar) return '방어+' + s.ar;
    if (s.rg) return '회복' + s.rg + '%';
    return '';
  }

  function mount(root, api) {
    const style = h('style', { text: CSS });
    const wrap = h('div', { class: 'rb' });
    const top = h('div', { class: 'rb-top' });
    const arena = h('div', { class: 'rb-arena' });
    const eq = h('div', { class: 'rb-eq' });
    const colL = h('div', { class: 'rb-col l' }), colR = h('div', { class: 'rb-col r' });
    eq.append(colL, colR);
    const panel = h('div', { class: 'rb-panel' });
    wrap.append(top, arena, panel);
    root.append(style, wrap);
    const cvs = U.canvas(arena);
    arena.append(eq);
    const ctx = cvs.ctx;
    const sp = () => L.debug.speed || 1;
    let st = null, revealed = -1, anim = null, ov = null, busy = false, speedMul = 2, hl = -1, hlT = 0;
    let pkey = '', tkey = '', ekey = '', seatSig = '';
    let adv = null, advKey = '';
    const nm = (i) => (api.players[i] ? api.players[i].name : (i + 1) + '번');
    const pcol = (i) => (api.players[i] ? api.players[i].color : '#999');
    const multi = () => !api.online && api.mySeats().length >= 2;
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };

    function pendingLocal() {
      if (!st || st.ph !== 's') return [];
      return api.mySeats().filter((i) => !st.o[i] && !st.k[i]);
    }
    /* seat whose shop is open on this screen (-1 = none) */
    function shopSeat() {
      if (anim) return -1;
      const p = pendingLocal();
      if (!p.length) return -1;
      if (multi()) return p.includes(revealed) ? revealed : -1;
      return p[0];
    }
    /* seat whose robot the garage shows */
    function viewSeat() {
      const s = shopSeat(); if (s >= 0) return s;
      const mine = api.mySeats();
      if (mine.length) { const al = mine.filter((i) => st && !st.o[i]); return al.length ? al[0] : mine[0]; }
      return 0;
    }

    /* ---------------- top strip ---------------- */
    function renderTop() {
      const s = anim ? anim.prev : st; if (!s) return;
      const v = viewSeat();
      const key = JSON.stringify([s.h, s.k, s.o, v, s.ph, !!anim]);
      if (key === tkey) return; tkey = key;
      top.innerHTML = '';
      for (let i = 0; i < s.n; i++) {
        const out = !!s.o[i];
        const hpPct = Math.max(0, s.h[i]) / s.mh * 100;
        top.append(h('button', { class: 'rb-p' + (out ? ' out' : '') + (i === v ? ' me' : ''), 'aria-label': nm(i) + ' 로봇 보기', onclick: () => scout(i) },
          h('div', { class: 'r1' }, h('span', { class: 'dot', style: { '--c': pcol(i), flex: 'none', width: '8px', height: '8px' } }),
            s.n <= 5 ? h('span', { class: 'nm', text: nm(i) }) : null,
            h('span', { class: 'mono', style: s.n > 5 ? { flex: '1', textAlign: 'left' } : null, text: String(Math.max(0, s.h[i])) }),
            s.ph === 's' && !out && s.k[i] && !anim ? h('span', { class: 'ck', text: '✓' }) : out ? h('span', { text: '✕' }) : null),
          h('div', { class: 'bar' }, h('i', { style: { width: hpPct + '%', background: hpPct < 30 ? '#ee6a55' : hpPct < 60 ? '#e3ae45' : '#6fdc8c' } }))));
      }
    }

    /* ---------------- sheets ---------------- */
    function closeOv() { if (ov) { ov.remove(); ov = null; } hl = -1; }
    function sheet(children) {
      closeOv();
      ov = h('div', { class: 'rb-ov', onclick: (ev) => { if (ev.target === ov) closeOv(); } }, h('div', { class: 'rb-sh' }, ...children));
      wrap.append(ov);
    }
    function partHead(x) {
      const D = PARTS[x.i];
      return [h('div', null, h('span', { class: 'tg', style: { '--c': SETS[D.e].c }, text: SETS[D.e].n }), h('span', { class: 'muted', style: { fontSize: '12px' }, text: TN[D.t] + ' · ' + TIER[D.c] + ' · ' + price(x.i) + '금화짜리' })),
        h('h3', { text: D.n + (x.l > 1 ? ' ' + STARS[x.l] : '') }),
        h('div', { class: 'st', text: statLines(D, x.l).join(' · ') }),
        D.t === 'W' && WEAPON_EL[D.e] ? h('div', { class: 'st', style: { color: SETS[D.e].c }, text: '맞히면 ' + WEAPON_EL[D.e] }) : null,
        h('div', { class: 'st muted', style: { fontSize: '12px' }, text: SETS[D.e].n + ' 2개: ' + SETS[D.e].two + ' / 4개: ' + SETS[D.e].four }),
        h('div', { class: 'st muted', style: { fontSize: '12px' }, text: '필살기(' + SETS[D.e].n + '이 가장 많을 때): ' + SETS[D.e].sp + ' — ' + SPECIAL_D[D.e] })];
    }
    function ownedSheet(seat, w, i) {
      const m = model(st, seat);
      const x = w === 'e' ? m.e[i] : m.b[i];
      if (!x) return;
      const D = PARTS[x.i], bt = h('div', { class: 'bt' });
      const go = (a, snd) => { closeOv(); api.actAs(seat, a); Snd.play(snd || 'equip'); };
      if (w === 'b') {
        for (const j of slotsFor(D.t)) bt.append(h('button', { class: 'btn primary', text: (m.e[j] ? '바꿔 끼우기' : '장착') + (D.t === 'W' ? ' (' + SLN[j] + ')' : ''), onclick: () => go({ t: 'eq', i, j }) }));
      } else {
        if (m.b.length < BENCH) bt.append(h('button', { class: 'btn', text: '보관함으로', onclick: () => go({ t: 'un', j: i }) }));
        if (D.t === 'W' && (i === 3 || i === 4)) bt.append(h('button', { class: 'btn', text: '무기 자리 바꾸기', onclick: () => go({ t: 'mv' }) }));
      }
      bt.append(h('button', { class: 'btn', style: { color: 'var(--coral)' }, text: '팔기 +' + sellValue(x) + '금화', onclick: () => go({ t: 'sell', w, i }, 'coin') }));
      bt.append(h('button', { class: 'btn ghost', text: '닫기', onclick: closeOv }));
      const rate = Math.round(slotRate(st.r, m, x.i) * 1000) / 10;
      sheet([...partHead(x), x.l < 3 ? h('div', { class: 'st', style: { color: '#9ff3a0', fontSize: '12px' }, text: '가지고 있어서 상점 등장 ×' + weightOf(m, x.i) + ' (카드 한 장마다 ' + rate + '%)' }) : null, bt]);
      if (w === 'e') hl = i;
    }
    function shopSheet(seat, k) {
      const c = st.sh[seat][k]; if (!c || c === '.') return;
      const id = AL.indexOf(c), x = { i: id, l: 1 };
      const m = model(st, seat);
      const have = ownedCount(m, id, 1);
      const a = adv && adv.cards[k];
      sheet([...partHead(x), have ? h('div', { class: 'st', style: { color: 'var(--brass)' }, text: '이미 ' + have + '개 있어요 — 3개 모이면 ★★로 합쳐져요!' }) : null,
        a && a.text ? h('div', { class: 'st', style: { color: '#f5dfae' }, text: '추천: ' + a.text }) : null,
        h('div', { class: 'st', style: { color: '#9ff3a0', fontSize: '12px' }, text: '상점 등장 ×' + weightOf(m, id) + ' · 이번 라운드 카드 한 장마다 ' + (Math.round(slotRate(st.r, m, id) * 1000) / 10) + '%' }),
        h('div', { class: 'bt' }, h('button', { class: 'btn primary', text: '사기 (' + price(id) + '금화)', onclick: () => { closeOv(); buy(seat, k); } }), h('button', { class: 'btn ghost', text: '닫기', onclick: closeOv }))]);
    }
    function oddsSheet(seat) {
      const m = model(st, seat);
      const od = tierOdds(st.r), interest = Math.min(2, Math.floor(m.g / 10));
      const owned = [];
      for (const x of [...m.e, ...m.b]) if (x && x.l < 3 && !owned.includes(x.i)) owned.push(x.i);
      const tb = h('table');
      tb.append(h('tr', null, h('td', { text: '등급' }), h('td', { text: '값' }), h('td', { text: '확률' })));
      for (let c = 1; c <= 4; c++) tb.append(h('tr', null, h('td', { text: TIER[c] }), h('td', { text: (c + 1) + '금화' }), h('td', { text: Math.round(od[c] * 100) + '%' })));
      const ob = h('table');
      owned.sort((a, b) => weightOf(m, b) - weightOf(m, a)).forEach((i) => ob.append(h('tr', null, h('td', null, h('span', { class: 'tg', style: { '--c': SETS[PARTS[i].e].c }, text: SETS[PARTS[i].e].n }), PARTS[i].n),
        h('td', { style: { color: '#9ff3a0' }, text: '×' + weightOf(m, i) }), h('td', { text: (Math.round(slotRate(st.r, m, i) * 1000) / 10) + '%' }))));
      sheet([h('h3', { text: '금화와 상점 확률' }),
        h('div', { class: 'st', text: '지금 ' + m.g + '금화 · 다음 라운드 수입 5 + 이자 ' + interest + ' (+이기면 1) · 최대 ' + MAXG }),
        h('div', { class: 'st muted', style: { fontSize: '12px' }, text: st.r + '라운드 상점 카드 한 장의 등급 확률' }), tb,
        h('div', { class: 'st', style: { color: '#9ff3a0' }, text: '가진 부품은 상점에 더 자주 나와요: 1개마다 등장 +100% (★★는 2개로 셈, 최대 ×5, ★★★은 끝이라 제외)' }),
        owned.length ? ob : h('div', { class: 'st muted', text: '아직 가진 부품이 없어요' }),
        h('div', { class: 'bt' }, h('button', { class: 'btn ghost', text: '닫기', onclick: closeOv }))]);
    }
    function scout(i) {
      const s = anim ? anim.prev : st; if (!s) return;
      const e = decE(s.e[i]), P = prof(e);
      const list = h('div', { class: 'st' });
      e.forEach((x, j) => list.append(h('div', null, h('span', { class: 'muted', text: SLN[j] + ' ' }), x ? h('b', { style: { color: colOf(x) }, text: PARTS[x.i].n + ' ' + STARS[x.l] }) : h('span', { class: 'muted', text: '(비어 있음)' }))));
      sheet([h('h3', null, h('span', { class: 'dot', style: { '--c': pcol(i), marginRight: '8px', display: 'inline-block' } }), nm(i)),
        h('div', { class: 'st', text: '목숨 ' + Math.max(0, s.h[i]) + ' / ' + s.mh + (s.o[i] ? ' · ' + s.o[i] + '라운드에 탈락' : '') }),
        h('div', { class: 'st', text: '로봇 체력 ' + Math.round(P.hp) + (P.sh ? ' (+보호막 ' + Math.round(P.sh) + ')' : '') + ' · 초당 피해 ' + Math.round(P.D) + ' · 방어 ' + Math.round(P.ar) + ' · 속도 ' + Math.round(P.spd) }),
        h('div', { class: 'st', text: '필살기: ' + (P.spc >= 0 ? SETS[P.spc].sp : '전력 펀치') }),
        list, setChips(P), h('div', { class: 'bt' }, h('button', { class: 'btn ghost', text: '닫기', onclick: closeOv }))]);
    }
    function setChips(P) {
      const row = h('div', { class: 'st', style: { display: 'flex', flexWrap: 'wrap', gap: '4px' } });
      P.set.forEach((n, k) => { if (n) row.append(h('span', { class: 'tg', style: { '--c': SETS[k].c, opacity: n >= 2 ? 1 : 0.55 }, text: SETS[k].n + ' ' + n + (n >= 4 ? ' ★' : n >= 2 ? ' ✓' : '') })); });
      P.cb.forEach((v, q) => { if (v) row.append(h('span', { class: 'tg', style: { '--c': '#ff9f5a' }, text: '콤보 ' + COMBOS[q].n })); });
      return row;
    }

    /* ---------------- actions ---------------- */
    function buy(seat, k) {
      const c = st.sh[seat][k]; if (!c || c === '.') return;
      const id = AL.indexOf(c);
      const m = model(st, seat);
      if (m.g < price(id)) { api.toast('금화가 모자라요'); api.buzz(30); return; }
      const t = cloneM(m);
      if (!buyInto(t, id)) { api.toast('보관함이 꽉 찼어요 — 하나 팔거나 장착해요'); api.buzz(30); return; }
      api.actAs(seat, { t: 'buy', k });
      api.buzz(10);
      if (t.merged) { api.toast(PARTS[t.merged.i].n + ' ' + STARS[t.merged.l] + ' 합체!'); Snd.play('merge'); mergeFx = { t: 0, slot: t.e.indexOf(t.e.find((x) => x === t.merged)) }; }
      else Snd.play('coin');
    }
    let mergeFx = null;

    /* ---------------- equipment columns (over the robot) ---------------- */
    function tile(x, label, onclick, extraCls) {
      if (!x) return h('button', { class: 'rb-t empty' + (extraCls || ''), 'aria-label': label + ' 비어 있음', onclick }, h('span', { class: 'k', text: label }), h('span', { class: 'n', text: '—' }));
      const D = PARTS[x.i];
      return h('button', { class: 'rb-t' + (extraCls || ''), style: { '--c': SETS[D.e].c }, 'aria-label': label + ' ' + D.n + ' ' + x.l + '단계', onclick },
        h('span', { class: 'k', text: label }), h('span', { class: 'n', text: D.s }), h('span', { class: 's', text: STARS[x.l] }));
    }
    const eqEls = [];
    function renderEq() {
      if (!st || anim) { if (ekey !== 'hide') { ekey = 'hide'; eq.style.display = 'none'; } return; }
      const seat = viewSeat(), shopping = shopSeat() >= 0;
      const key = JSON.stringify([seat, st.e[seat], shopping, revealed]);
      if (key === ekey) return; ekey = key;
      eq.style.display = '';
      colL.innerHTML = ''; colR.innerHTML = ''; eqEls.length = 0;
      const e = decE(st.e[seat]);
      [0, 1, 2, 3, 4, 5].forEach((j) => {
        const x = e[j];
        const el = tile(x, SLN[j].replace(' ', ''), () => {
          if (shopping) { if (x) ownedSheet(seat, 'e', j); else { api.toast(SLN[j] + ' 자리가 비었어요 — 상점에서 ' + TN[SLOTS[j]] + ' 부품을 사요'); hl = j; hlT = 1.5; } }
          else if (x) { sheet([...partHead(x), h('div', { class: 'bt' }, h('button', { class: 'btn ghost', text: '닫기', onclick: closeOv }))]); hl = j; }
        });
        eqEls[j] = el;
        (j < 3 ? colL : colR).append(el);
      });
    }

    /* ---------------- panel ---------------- */
    function renderPanel(force) {
      if (!st) return;
      if (anim) {
        const f = anim.fights[anim.idx];
        const key = 'A' + anim.id + ':' + anim.idx + ':' + speedMul + ':' + anim.fights.length;
        if (key === pkey && !force) return; pkey = key;
        panel.innerHTML = '';
        panel.append(h('div', { class: 'rb-ttl', text: anim.r + '라운드 · ' + (anim.idx + 1) + '/' + anim.fights.length + '경기' + (f[7] ? ' · 유령 로봇과 연습 경기' : '') }),
          h('div', { class: 'rb-ctl' },
            h('button', { class: 'btn', 'aria-label': '빠르기', text: '빠르기 ×' + speedMul, onclick: () => { speedMul = speedMul >= 4 ? 1 : speedMul * 2; api.sfx('tick'); renderPanel(true); } }),
            anim.fights.length > 1 ? h('button', { class: 'btn', text: '다른 경기 ▸', onclick: () => { startFight((anim.idx + 1) % anim.fights.length); } }) : null,
            h('button', { class: 'btn primary', text: '건너뛰기 ⏭', onclick: () => finishAnim() })));
        return;
      }
      const seat = shopSeat();
      const s = st;
      if (s.ph === 'e') { const key = 'E'; if (key === pkey && !force) return; pkey = key; panel.innerHTML = ''; panel.append(h('div', { class: 'rb-wait' }, h('div', { class: 'ln', text: '대회가 끝났어요!' }))); return; }
      if (seat < 0) {
        const pend = pendingLocal();
        const key = 'W' + JSON.stringify([s.k, s.r, pend, revealed, s.o]);
        if (key === pkey && !force) return; pkey = key;
        panel.innerHTML = '';
        if (pend.length && multi()) {
          panel.append(h('div', { class: 'rb-wait' }, h('div', { class: 'ln', text: s.r + '라운드 상점 — 자기 이름을 눌러 열어요' }),
            h('div', { class: 'muted', style: { fontSize: '12px' }, text: '다른 사람 몰래 사고 싶으면 폰을 넘겨주세요' })),
          h('div', { class: 'rb-pick' }, ...pend.map((i) => h('button', { class: 'btn', onclick: () => { revealed = i; api.sfx('click'); renderAll(true); } }, h('span', { class: 'dot', style: { '--c': pcol(i) } }), nm(i) + ' 상점'))));
          return;
        }
        const mine = api.mySeats();
        const outMe = mine.length && mine.every((i) => s.o[i]);
        const left = alive(s).filter((i) => !s.k[i]).length;
        panel.append(h('div', { class: 'rb-wait' },
          h('div', { class: 'ln', text: outMe ? '내 로봇은 탈락했어요 — 관전 중' : mine.length ? '준비 완료! 다른 사람 기다리는 중…' : s.r + '라운드 · 모두 로봇을 조립하는 중' }),
          h('div', { class: 'muted', style: { fontSize: '12px' }, text: '남은 사람 ' + left + '명 · 위의 이름을 누르면 그 로봇을 볼 수 있어요' })));
        return;
      }
      const m = model(s, seat);
      const key = 'S' + JSON.stringify([seat, s.e[seat], s.b[seat], s.g[seat], s.sh[seat], s.r]);
      if (key === pkey && !force) return; pkey = key;
      if (advKey !== key) { advKey = key; try { adv = advise(m, s.sh[seat], s.r); } catch (err) { console.error(err); adv = null; } }
      panel.innerHTML = '';
      const interest = Math.min(2, Math.floor(m.g / 10));
      panel.append(h('div', { class: 'rb-hint' }, h('b', { text: '추천' }), h('span', { text: adv ? adv.hint : '' })));
      panel.append(h('div', { class: 'rb-info' },
        h('button', { class: 'rb-gold', 'aria-label': '금화 ' + m.g + ' — 수입과 상점 확률 보기', onclick: () => { api.sfx('click'); oddsSheet(seat); } },
          h('span', { class: 'gv' }, h('i'), String(m.g)),
          h('span', { class: 'sub', text: (multi() ? nm(seat) + ' · ' : '') + s.r + '라운드 · 다음 +' + (5 + interest) + ' · 확률 ⓘ' })),
        h('button', { class: 'btn rb-roll', 'aria-label': '상점 새로고침 1금화', onclick: () => { if (m.g < 1) { api.toast('금화가 모자라요'); return; } api.actAs(seat, { t: 'roll' }); Snd.play('roll'); } }, '↻ 1'),
        h('button', { class: 'btn primary rb-go', onclick: () => {
          Snd.play('equip'); api.buzz(20);
          if (multi()) revealed = -1;
          api.actAs(seat, { t: 'ok' });
        } }, '준비 완료 ▶')));
      const bench = h('div', { class: 'rb-row rb-bench' }, h('span', { class: 'rb-lab', text: '보관함' }));
      for (let k = 0; k < BENCH; k++) {
        const x = m.b[k];
        const canMerge = x && ownedCount(m, x.i, x.l) >= 2 && x.l < 3;
        bench.append(tile(x || null, '보관', () => { if (x) ownedSheet(seat, 'b', k); }, canMerge ? ' mg' : ''));
      }
      const shop = h('div', { class: 'rb-row rb-shop' });
      const bestK = adv && adv.cards ? adv.cards.reduce((b, c, k) => (c && c.score > 0.25 && c.text && (b < 0 || c.score > adv.cards[b].score) ? k : b), -1) : -1;
      s.sh[seat].split('').forEach((c, k) => {
        if (c === '.') { shop.append(h('div', { class: 'rb-c sold' })); return; }
        const id = AL.indexOf(c), D = PARTS[id];
        const a = adv && adv.cards[k];
        const bo = weightOf(m, id);
        let lp = 0, lpT = 0;
        const card = h('button', { class: 'rb-c' + (price(id) > m.g ? ' no' : '') + (D.c >= 3 ? ' t' + D.c : '') + (k === bestK ? ' best' : ''), style: { '--c': SETS[D.e].c }, 'aria-label': D.n + ' ' + price(id) + '금화' + (bo > 1 ? ' 등장 ' + bo + '배' : '') },
          h('div', { class: 'band', text: SETS[D.e].n + (D.c === 4 ? '★' : '') }),
          h('div', { class: 'n', text: D.s }), h('div', { class: 'k', text: D.t === 'W' ? keyStat(D) : TN[D.t] + ' · ' + keyStat(D) }),
          a && a.tag ? h('span', { class: 'tg ' + (a.kind || ''), text: a.tag }) : null,
          h('div', { class: 'pr' }, h('span', { text: '● ' + price(id) }), bo > 1 ? h('span', { class: 'bo', text: '▲×' + bo }) : null));
        card.addEventListener('pointerdown', () => { lp = 0; clearTimeout(lpT); lpT = setTimeout(() => { lp = 1; api.buzz(15); shopSheet(seat, k); }, 450); });
        const cancel = () => clearTimeout(lpT);
        card.addEventListener('pointerup', cancel); card.addEventListener('pointerleave', cancel); card.addEventListener('pointercancel', cancel);
        card.addEventListener('contextmenu', (ev) => { ev.preventDefault(); });
        card.addEventListener('click', () => { clearTimeout(lpT); if (lp) { lp = 0; return; } buy(seat, k); });
        shop.append(card);
      });
      panel.append(bench, shop);
    }

    /* ---------------- battle animation ---------------- */
    function startAnim(s, prev) {
      const L1 = s.last;
      const v = viewSeat();
      let idx = L1.f.findIndex((f) => f[0] === v || (f[1] === v && !f[7]));
      if (idx < 0) idx = 0;
      anim = { id: L1.id, r: L1.r, fights: L1.f, idx, prev: prev || s, done: false };
      closeOv(); setBusy(true);
      startFight(idx);
      Snd.play('bell');
    }
    function startFight(idx) {
      const f = anim.fights[idx];
      anim.idx = idx;
      const R = sim(decE(f[2]), decE(f[3]), f[4], true);
      Object.assign(anim, { R, pt: 0, ei: 0, end: 0, hold: 0, shake: 0, flash: 0, flashC: '#fff', fl: [], pj: [], ps: [], spx: [], ban: null,
        sw: [[0, 0], [0, 0]], rc: [[0, 0], [0, 0]], hurt: [0, 0], wheel: [0, 0], kx: [0, 0], brk: [0, 0], dead: [0, 0], e: [decE(f[2]), decE(f[3])] });
      pkey = ''; renderPanel(true); renderTop(); renderEq();
    }
    function finishAnim() {
      if (!anim) return;
      const mine = api.mySeats();
      const f = anim.fights.find((q) => mine.includes(q[0]) || (mine.includes(q[1]) && !q[7]));
      anim = null; setBusy(false); pkey = ''; tkey = ''; ekey = '';
      if (f && !multi()) {
        const me = mine.includes(f[0]) ? 0 : 1;
        if (f[5] === 2) api.toast('무승부! 목숨 −' + f[6]);
        else if (f[5] === me) api.toast('승리! 다음 수입 +1');
        else api.toast('패배… 목숨 −' + f[6]);
      }
      renderAll(true);
    }
    function advance(dt) {
      const A = anim, n = A.R.fr.length;
      if (A.hold > 0) { A.hold -= dt; return; }
      let rate = 1.25 * speedMul * sp();
      if (A.R.w !== 2 && !A.end && A.pt / DT > n - 7) rate *= 0.35; // KO slow motion
      A.pt = Math.min((n - 1) * DT, A.pt + dt * rate);
      if (Math.floor(A.pt / DT + 1e-6) >= n - 1) {
        if (!A.end) { A.end = 0.001; }
        else A.end += dt * Math.min(4, speedMul * sp());
        if (A.end > 2.4) finishAnim();
      }
    }

    /* ---------------- particles ---------------- */
    function puff(A, o) { if (A.ps.length < 260) A.ps.push(Object.assign({ t: 0, life: 0.6, vx: 0, vy: 0, g: 0, size: 3, rot: 0, vr: 0 }, o)); }
    function sparks(A, x, y, n, col, dir) {
      for (let q = 0; q < n; q++) { const a = (Math.random() - 0.5) * 2.2 + (dir < 0 ? Math.PI : 0); const v = 90 + Math.random() * 160;
        puff(A, { k: 'spark', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 40, g: 300, life: 0.25 + Math.random() * 0.2, col: col || '#ffd76a', size: 2 }); }
    }
    function smoke(A, x, y, dark) { puff(A, { k: 'smoke', x, y, vx: (Math.random() - 0.5) * 12, vy: -30 - Math.random() * 20, life: 1 + Math.random() * 0.6, size: 5 + Math.random() * 4, col: dark ? '40,36,46' : '160,150,170' }); }
    function fire(A, x, y) { puff(A, { k: 'fire', x, y, vx: (Math.random() - 0.5) * 20, vy: -50 - Math.random() * 30, life: 0.45 + Math.random() * 0.3, size: 4 + Math.random() * 4 }); }
    function ring(A, x, y, col, r1) { puff(A, { k: 'ring', x, y, life: 0.45, size: r1 || 40, col }); }
    function drawParticles(A, dt, gy) {
      const ps = A.ps;
      for (let q = ps.length - 1; q >= 0; q--) {
        const p = ps[q];
        p.t += dt; if (p.t >= p.life) { ps.splice(q, 1); continue; }
        p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
        const u = p.t / p.life;
        ctx.save();
        if (p.k === 'spark') { ctx.strokeStyle = p.col; ctx.globalAlpha = 1 - u; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x - p.vx * 0.04, p.y - p.vy * 0.04); ctx.stroke(); }
        else if (p.k === 'smoke') { ctx.globalAlpha = (1 - u) * 0.5; ctx.fillStyle = 'rgb(' + p.col + ')'; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 + u * 1.8), 0, 7); ctx.fill(); }
        else if (p.k === 'fire') { ctx.globalAlpha = 1 - u; ctx.fillStyle = u < 0.3 ? '#fff1b8' : u < 0.6 ? '#ffae42' : '#ff5a2a'; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 - u * 0.6), 0, 7); ctx.fill(); }
        else if (p.k === 'ring') { ctx.globalAlpha = 1 - u; ctx.strokeStyle = p.col; ctx.lineWidth = 3 * (1 - u) + 1; ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (0.2 + u), 0, 7); ctx.stroke(); }
        else if (p.k === 'drop') { ctx.globalAlpha = 1 - u * 0.5; ctx.fillStyle = p.col; ctx.beginPath(); ctx.ellipse(p.x, p.y, 2, 4, 0, 0, 7); ctx.fill(); }
        else if (p.k === 'ice') { ctx.globalAlpha = 1 - u; ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.fillStyle = '#dff2ff'; ctx.beginPath(); ctx.moveTo(0, -p.size); ctx.lineTo(p.size * 0.4, 0); ctx.lineTo(0, p.size); ctx.lineTo(-p.size * 0.4, 0); ctx.fill(); }
        else if (p.k === 'plus') { ctx.globalAlpha = 1 - u; ctx.fillStyle = '#7ddc7a'; ctx.fillRect(p.x - 1.5, p.y - 5, 3, 10); ctx.fillRect(p.x - 5, p.y - 1.5, 10, 3); }
        ctx.restore();
      }
    }

    /* ---------------- canvas drawing ---------------- */
    function drawBg(W, H, gy, t, lights) {
      const g = ctx.createLinearGradient(0, 0, 0, gy);
      g.addColorStop(0, '#1f1a2c'); g.addColorStop(1, '#3a2f4a');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, gy);
      // far wall: hangar ribs + warning lights
      ctx.strokeStyle = 'rgba(227,174,69,.07)'; ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 20; x < W; x += 40) { ctx.moveTo(x, 0); ctx.lineTo(x, gy); }
      for (let y = gy - 60; y > 0; y -= 60) { ctx.moveTo(0, y); ctx.lineTo(W, y); }
      ctx.stroke();
      if (lights) for (let x = 30; x < W; x += 120) { const on = (Math.floor(t * 1.5 + x) % 2) === 0; ctx.fillStyle = on ? 'rgba(238,106,85,.55)' : 'rgba(238,106,85,.15)'; ctx.beginPath(); ctx.arc(x + 60, gy * 0.5, 3, 0, 7); ctx.fill(); }
      const f = ctx.createLinearGradient(0, gy, 0, H);
      f.addColorStop(0, '#4a3f37'); f.addColorStop(1, '#1d1716');
      ctx.fillStyle = f; ctx.fillRect(0, gy, W, H - gy);
      ctx.fillStyle = '#e3ae45'; ctx.globalAlpha = 0.55; ctx.fillRect(0, gy - 1, W, 3); ctx.globalAlpha = 1;
      ctx.fillStyle = 'rgba(0,0,0,.25)';
      for (let x = 0; x < W; x += 28) ctx.fillRect(x, gy + 6, 14, 3);
    }
    function bar(x, y, w, hh, v, mx, col, label) {
      ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, x, y, w, hh, hh / 2); ctx.fill();
      ctx.fillStyle = col; rr(ctx, x, y, Math.max(0, Math.min(1, v / mx)) * w, hh, hh / 2); ctx.fill();
      if (label) { ctx.fillStyle = '#f2e9d8'; ctx.font = '600 10px "IBM Plex Mono",monospace'; ctx.textAlign = 'left'; ctx.fillText(label, x, y - 3); }
    }
    function fitText(txt, maxW, size, weight) {
      let s = size;
      ctx.font = weight + ' ' + s + 'px "IBM Plex Sans KR",sans-serif';
      while (s > 8 && ctx.measureText(txt).width > maxW) { s -= 0.5; ctx.font = weight + ' ' + s + 'px "IBM Plex Sans KR",sans-serif'; }
    }
    /* set progress chips (garage). returns rows height */
    function setRow(P, W, y0, draw) {
      const items = [];
      P.set.forEach((n, k) => { if (n) items.push({ k, n }); });
      items.sort((a, b) => b.n - a.n || a.k - b.k);
      P.cb.forEach((v, q) => { if (v) items.push({ combo: q }); });
      ctx.font = '700 10px "IBM Plex Sans KR",sans-serif';
      let x = 6, y = y0, rows = items.length ? 1 : 0;
      for (const it of items) {
        const label = it.combo != null ? '콤보 ' + COMBOS[it.combo].n : SETS[it.k].n + ' ' + it.n + '/' + (it.n >= 4 ? 4 : it.n >= 2 ? 4 : 2);
        const tw = ctx.measureText(label).width + (it.combo != null ? 10 : 30);
        if (x + tw > W - 6) { x = 6; y += 20; rows++; }
        if (draw) {
          const col = it.combo != null ? '#ff9f5a' : SETS[it.k].c;
          ctx.globalAlpha = it.combo != null || it.n >= 2 ? 1 : 0.6;
          ctx.fillStyle = 'rgba(20,16,28,.85)'; rr(ctx, x, y, tw, 17, 6); ctx.fill();
          ctx.strokeStyle = col; ctx.lineWidth = 1.2; ctx.stroke();
          ctx.fillStyle = col; ctx.textAlign = 'left'; ctx.fillText(label, x + 5, y + 12.5);
          if (it.combo == null) { // 4 pips
            const px = x + tw - 23;
            for (let q = 0; q < 4; q++) { ctx.fillStyle = q < it.n ? col : 'rgba(255,255,255,.15)'; rr(ctx, px + q * 5, y + 6, 4, 6, 1); ctx.fill(); }
          }
          ctx.globalAlpha = 1;
        }
        x += tw + 4;
      }
      return rows * 20;
    }
    function drawGarage(W, H, t, dt) {
      if (!st) { drawBg(W, H, Math.round(H * 0.86), t); return; }
      const seat = viewSeat();
      const e = decE(st.e[seat]);
      const P = prof(e);
      const setH = setRow(P, W, 0, false);
      const bottom = setH + 8;
      const gy = Math.round(H - bottom - 8);
      drawBg(W, H, gy, t);
      // equipment columns follow the free height
      const colTop = 42, colH = Math.max(0, gy - colTop - 2);
      if (colL._h !== colH) { colL._h = colH; colL.style.top = colR.style.top = colTop + 'px'; colL.style.height = colR.style.height = colH + 'px'; }
      // stats header
      const pw = Math.round(power(e, DEF_CX) / 10);
      fitText('체력 ' + Math.round(P.hp) + (P.sh ? ' +막' + Math.round(P.sh) : '') + ' · 초당 피해 ' + Math.round(P.D) + (P.dn ? '+드론' : '') + ' · ' + (P.melee ? '근접' : '원거리') + ' · 전투력 ' + pw, W - 12, 12, 700);
      ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = '#f2e9d8';
      ctx.fillText('체력 ' + Math.round(P.hp) + (P.sh ? ' +막' + Math.round(P.sh) : '') + ' · 초당 피해 ' + Math.round(P.D) + (P.dn ? '+드론' : '') + ' · ' + (P.melee ? '근접' : '원거리') + ' · 전투력 ' + pw, W / 2, 14);
      const bw = Math.min(150, (W - 24) / 2);
      const ecol = P.lowE ? '#ee6a55' : '#ffd23f', wcol = P.over ? '#ee6a55' : '#a9bccf';
      bar(W / 2 - bw - 4, 31, bw, 5, P.ed, Math.max(P.eo, P.ed), ecol, '전력 ' + Math.round(P.ed) + '/' + Math.round(P.eo) + (P.lowE ? ' 부족!' : ''));
      bar(W / 2 + 4, 31, bw, 5, P.wt, Math.max(P.cap, P.wt), wcol, '무게 ' + Math.round(P.wt) + '/' + Math.round(P.cap) + (P.over ? ' 초과!' : ''));
      // robot (centered between the columns)
      const colW = colL.offsetWidth || 86;
      const freeW = W - 2 * (colW + 10);
      const sc = Math.max(0.6, Math.min((gy - 44) / 112, freeW / 92, 2.6));
      const cx = W / 2 - 6 * sc;
      // leader lines from the slot buttons to the parts
      const fb = st && shopSeat() >= 0;
      ctx.lineWidth = 1;
      for (let j = 0; j < 6; j++) {
        const el = eqEls[j]; if (!el || !el.isConnected) continue;
        const a = ANCH[j], left = j < 3;
        const bx = left ? el.offsetLeft + el.offsetWidth + colL.offsetLeft : colR.offsetLeft + el.offsetLeft;
        const by = (left ? colL.offsetTop : colR.offsetTop) + el.offsetTop + el.offsetHeight / 2;
        const tx = cx + a[0] * sc, ty = gy + a[1] * sc;
        ctx.strokeStyle = e[j] ? SETS[PARTS[e[j].i].e].c : 'rgba(171,159,184,.5)';
        ctx.globalAlpha = j === hl ? 0.95 : 0.3; ctx.setLineDash(e[j] ? [] : [3, 3]);
        ctx.beginPath(); ctx.moveTo(bx, by); ctx.lineTo(bx + (left ? 8 : -8), by); ctx.lineTo(tx, ty); ctx.stroke();
        ctx.setLineDash([]); ctx.globalAlpha = 1;
        ctx.fillStyle = ctx.strokeStyle; ctx.beginPath(); ctx.arc(tx, ty, 2.2, 0, 7); ctx.fill();
      }
      if (hlT > 0) { hlT -= dt; if (hlT <= 0 && !ov) hl = -1; }
      // pedestal glow
      const pg = ctx.createRadialGradient(cx, gy, 4, cx, gy, 70 * sc);
      pg.addColorStop(0, 'rgba(227,174,69,.28)'); pg.addColorStop(1, 'rgba(227,174,69,0)');
      ctx.fillStyle = pg; ctx.fillRect(cx - 70 * sc, gy - 40 * sc, 140 * sc, 48 * sc);
      drawRobot(ctx, e, cx, gy, sc, 1, { t, hl, shield: 0 });
      if (mergeFx) {
        mergeFx.t += dt;
        const u = mergeFx.t / 0.9;
        if (u >= 1) mergeFx = null;
        else { ctx.save(); ctx.globalAlpha = 1 - u; ctx.strokeStyle = '#ffd23f'; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(cx, gy - 56 * sc, 20 + u * 90 * sc, 0, 7); ctx.stroke();
          ctx.font = '800 22px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#ffd23f'; ctx.fillText('합체!', cx, gy - 110 * sc - u * 20); ctx.restore(); }
      }
      // set progress under the floor line
      setRow(P, W, gy + 8, true);
      ctx.textAlign = 'left';
      void fb;
    }
    function robotX(A, R, W, pad, k, fi) {
      const n = R.fr.length, i0 = Math.max(0, Math.min(n - 1, Math.floor(fi))), i1 = Math.min(n - 1, i0 + 1), u = Math.max(0, Math.min(1, fi - i0));
      return pad + (U.lerp(R.fr[i0][k], R.fr[i1][k], u) / 100) * (W - pad * 2);
    }
    const SPEC_SND = ['flame', 'zap', 'shield', 'melee', 'shield', 'heal', 'flame', 'laser', 'drone', 'shield'];
    function addFl(A, o) { const now = A.pt; A.row = A.row || [0, 0]; A.rowT = A.rowT || [-9, -9]; if (now - A.rowT[o.s] > 0.25) A.row[o.s] = 0; A.rowT[o.s] = now; o.row = A.row[o.s] % 3; A.row[o.s]++; A.fl.push(o); }
    function onEvent(A, E, xs, gy, sc, W) {
      const tgt = E[1], src = 1 - tgt;
      const R = A.R, dirT = tgt ? -1 : 1; // facing of target
      const bodyY = gy - 56 * sc;
      const fast = speedMul * sp() > 2;
      if (E[2] === 'h' || E[2] === 'm') {
        const crit = E[3] < 0, val = Math.abs(E[3]);
        if (E[4] >= 0) {
          const P = R.pr[src], w = P.ws[E[4]];
          if (w) {
            const slot = w.j === 4 ? 1 : 0;
            const part = A.e[src][w.j];
            const v = part ? PARTS[part.i].v : 'fist';
            if (w.r <= MELEE) A.sw[src][slot] = 1;
            else { A.rc[src][slot] = 1; A.pj.push({ s: src, t: 0, el: w.el, v, slot, big: w.d >= 12, hit: E[2] === 'h' }); }
            if (E[2] === 'h') Snd.play(w.r <= MELEE ? 'melee' : w.el === 7 ? 'laser' : w.el === 1 ? 'zap' : w.el === 0 && v === 'flamer' ? 'flame' : 'shot', val >= 12);
          }
        }
        if (E[2] === 'h') {
          A.hurt[tgt] = 0.1;
          A.kx[tgt] = Math.min(10, A.kx[tgt] + 2 + val * 0.25) * 1;
          const hx = xs[tgt] - dirT * 16 * sc;
          sparks(A, hx, bodyY + (Math.random() - 0.5) * 24 * sc, crit ? 12 : val >= 12 ? 8 : 4, crit ? '#ff9fd0' : null, -dirT);
          if (crit || val >= 15) { A.shake = Math.max(A.shake, crit ? 6 : 4); if (!fast) A.hold = Math.max(A.hold, crit ? 0.08 : 0.05); Snd.play(crit ? 'crit' : 'hit', true); }
          addFl(A, { s: tgt, txt: (crit ? '치명! ' : '') + '-' + val, c: crit ? '#ff7fc0' : E[4] === -2 ? '#ffd23f' : val >= 15 ? '#ffd23f' : '#fff', t: 0, big: crit || val >= 15 || E[4] === -2, x: (Math.random() - 0.5) * 24 });
        } else { addFl(A, { s: tgt, txt: '빗나감', c: '#ab9fb8', t: 0, x: 0 }); Snd.play('miss'); }
      } else if (E[2] === 's') { addFl(A, { s: tgt, txt: E[4] === -2 && R.pr[src].spc === 4 ? '얼음!' : '감전!', c: '#ffd23f', t: 0, x: 0, big: true }); }
      else if (E[2] === 'b') { addFl(A, { s: tgt, txt: '-' + E[3], c: '#ff9a5a', t: 0, x: 16 }); }
      else if (E[2] === 'r') { addFl(A, { s: tgt, txt: '+' + E[3], c: '#7ddc7a', t: 0, x: -16 }); for (let q = 0; q < 3; q++) puff(A, { k: 'plus', x: xs[tgt] + (Math.random() - 0.5) * 40 * sc, y: bodyY, vy: -40, life: 0.8 }); }
      else if (E[2] === 'f') { addFl(A, { s: tgt, txt: '반사 -' + E[3], c: '#e9eef5', t: 0, x: 10 }); ring(A, xs[src], bodyY, '#e9eef5', 50 * sc); }
      else if (E[2] === 'd') {
        A.pj.push({ s: src, t: 0, el: 8, v: 'drone', slot: 2, n: E[4], hit: true });
        addFl(A, { s: tgt, txt: '-' + E[3], c: '#d6c2ff', t: 0, x: (Math.random() - 0.5) * 30 });
        Snd.play('drone');
      } else if (E[2] === 'x') {
        const k = E[1], set = E[4];
        A.spx.push({ k, set, t: 0 });
        A.ban = { txt: set >= 0 ? SETS[set].sp + '!' : '전력 펀치!', col: set >= 0 ? SETS[set].c : '#f2e9d8', t: 0, k };
        A.flash = 0.35; A.flashC = set >= 0 ? SETS[set].c : '#fff';
        A.shake = Math.max(A.shake, 5);
        if (!fast) A.hold = Math.max(A.hold, 0.18);
        Snd.play('charge'); Snd.play(SPEC_SND[set] || 'hit', true);
        if (set === 1 || set === 7) Snd.play('boom');
      }
    }
    function drawSpecials(A, xs, gy, sc, H, dt) {
      for (let q = A.spx.length - 1; q >= 0; q--) {
        const S = A.spx[q];
        S.t += dt * Math.min(2.5, speedMul * sp() * 0.7);
        const u = S.t / 1.1;
        if (u >= 1) { A.spx.splice(q, 1); continue; }
        const me = xs[S.k], op = xs[1 - S.k], dir = S.k ? -1 : 1, by = gy - 56 * sc;
        const col = S.set >= 0 ? SETS[S.set].c : '#fff';
        ctx.save();
        switch (S.set) {
          case 0: { // fire storm: a wave of flame rolling to the enemy
            const x = U.lerp(me, op, Math.min(1, u * 1.6));
            for (let k = 0; k < 3; k++) fire(A, x + (Math.random() - 0.5) * 30 * sc, gy - Math.random() * 70 * sc);
            ctx.globalAlpha = 0.35 * (1 - u); ctx.fillStyle = '#ff7a45'; ctx.beginPath(); ctx.ellipse(x, gy - 30 * sc, 36 * sc, 50 * sc, 0, 0, 7); ctx.fill();
            break; }
          case 1: { // lightning from the sky
            if (u < 0.5) {
              ctx.strokeStyle = '#fff6b0'; ctx.lineWidth = 4; ctx.shadowColor = col; ctx.shadowBlur = 16; ctx.beginPath();
              let x = op + (Math.random() - 0.5) * 20; ctx.moveTo(x, 0);
              for (let y = 0; y < gy - 50 * sc; y += 22) { x += (Math.random() - 0.5) * 26; ctx.lineTo(x, y); }
              ctx.lineTo(op, by); ctx.stroke();
              if (Math.random() < 0.5) sparks(A, op, by, 3, '#fff6b0', 0);
            }
            break; }
          case 2: { // hex barrier
            ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.globalAlpha = 1 - u;
            const r = (30 + u * 40) * sc;
            ctx.beginPath(); for (let k = 0; k <= 6; k++) { const a = k / 6 * Math.PI * 2 + Math.PI / 6; const px = me + Math.cos(a) * r, py = by + Math.sin(a) * r * 1.2; if (k) ctx.lineTo(px, py); else ctx.moveTo(px, py); } ctx.stroke();
            ctx.fillStyle = 'rgba(169,188,207,.15)'; ctx.fill();
            break; }
          case 3: { // gale combo: afterimages + slashes
            ctx.strokeStyle = col; ctx.lineWidth = 3; ctx.globalAlpha = 1 - u;
            for (let k = 0; k < 5; k++) { const a = u * 6 + k * 1.3; ctx.beginPath(); ctx.arc(op, by, (24 + k * 6) * sc, a, a + 1.1); ctx.stroke(); }
            ctx.globalAlpha = 0.25 * (1 - u); ctx.fillStyle = col; for (let k = 1; k <= 3; k++) { ctx.beginPath(); ctx.ellipse(me - dir * k * 14 * sc, by, 18 * sc, 40 * sc, 0, 0, 7); ctx.fill(); }
            break; }
          case 4: { // absolute zero: ice block around the enemy
            ctx.globalAlpha = Math.min(1, u * 4) * (1 - u * 0.6); ctx.fillStyle = 'rgba(190,230,255,.45)'; ctx.strokeStyle = '#e6f6ff'; ctx.lineWidth = 2;
            rr(ctx, op - 32 * sc, gy - 100 * sc, 64 * sc, 100 * sc, 6 * sc); ctx.fill(); ctx.stroke();
            if (Math.random() < 0.4) puff(A, { k: 'ice', x: op + (Math.random() - 0.5) * 60 * sc, y: gy - Math.random() * 100 * sc, vx: (Math.random() - 0.5) * 60, vy: -40, g: 200, life: 0.6, size: 5, vr: 4 });
            break; }
          case 5: { // emergency repair: green spiral + wrench
            ctx.strokeStyle = col; ctx.lineWidth = 3; ctx.globalAlpha = 1 - u;
            ctx.beginPath(); for (let k = 0; k < 40; k++) { const a = k * 0.4 + u * 8, r = (10 + k * 1.2) * sc; ctx.lineTo(me + Math.cos(a) * r, by + Math.sin(a) * r * 0.5 - k * 1.5 * sc); } ctx.stroke();
            if (Math.random() < 0.5) puff(A, { k: 'plus', x: me + (Math.random() - 0.5) * 50 * sc, y: by + 20 * sc, vy: -60, life: 0.9 });
            break; }
          case 6: { // acid rain
            if (Math.random() < 0.9) for (let k = 0; k < 2; k++) puff(A, { k: 'drop', x: op + (Math.random() - 0.5) * 80 * sc, y: gy - 140 * sc, vy: 260, life: 0.5, col: '#d4f542' });
            ctx.globalAlpha = 0.5 * (1 - u); ctx.fillStyle = '#5b6b1a'; ctx.beginPath(); ctx.ellipse(op, gy - 150 * sc, 50 * sc, 14 * sc, 0, 0, 7); ctx.fill();
            break; }
          case 7: { // orbital laser
            const w = (u < 0.15 ? u / 0.15 * 4 : u < 0.6 ? 18 : 18 * (1 - (u - 0.6) / 0.4)) * sc;
            const g = ctx.createLinearGradient(op - w, 0, op + w, 0);
            g.addColorStop(0, 'rgba(255,95,162,0)'); g.addColorStop(0.5, '#fff'); g.addColorStop(1, 'rgba(255,95,162,0)');
            ctx.fillStyle = g; ctx.fillRect(op - w * 2, 0, w * 4, gy);
            ctx.globalAlpha = 0.6; ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(op, gy, w * 2.5, 6, 0, 0, 7); ctx.fill();
            if (u > 0.15 && u < 0.6 && Math.random() < 0.6) sparks(A, op, gy - 4, 3, '#ffd0e6', 0);
            break; }
          case 8: { // drone bombing run
            for (let k = 0; k < 4; k++) {
              const x = U.lerp(me - dir * 60 * sc, op + dir * 60 * sc, Math.min(1, u * 1.3 - k * 0.08)), y = gy - (130 - k * 8) * sc;
              ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x, y, 7 * sc, 3 * sc, 0, 0, 7); ctx.fill();
              ctx.fillStyle = '#2a2430'; ctx.fillRect(x - 9 * sc, y - 4 * sc, 18 * sc, 1.5 * sc);
              if (Math.abs(x - op) < 18 * sc && Math.random() < 0.3) { sparks(A, op + (Math.random() - 0.5) * 30, by, 4, '#d6c2ff', 0); fire(A, op, by); }
            }
            break; }
          case 9: { // mirror ward: rotating panels
            ctx.globalAlpha = 1 - u * 0.7;
            for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2 + u * 5; const px = me + Math.cos(a) * 46 * sc, py = by + Math.sin(a) * 30 * sc;
              ctx.fillStyle = 'rgba(233,238,245,.65)'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.moveTo(px, py - 12 * sc); ctx.lineTo(px + 5 * sc, py); ctx.lineTo(px, py + 12 * sc); ctx.lineTo(px - 5 * sc, py); ctx.closePath(); ctx.fill(); ctx.stroke(); }
            break; }
          default: { ring(A, op, by, '#fff', 40 * sc); S.t = 2; }
        }
        ctx.restore();
      }
    }
    function drawBattle(W, H, t, dt) {
      const A = anim, R = A.R, f = A.fights[A.idx];
      const pad = Math.max(40, W * 0.12);
      const sc = Math.max(0.5, Math.min((H * 0.5) / 100, ((W - pad * 2) * 0.22) / 50, 1.7));
      const gy = Math.round(Math.min(H * 0.86, H * 0.42 + 120 * sc));
      const n = R.fr.length;
      const fi = Math.max(0, Math.min(n - 1, A.pt / DT));
      const ti = Math.floor(fi + 1e-6);
      const xs = [robotX(A, R, W, pad, 0, fi), robotX(A, R, W, pad, 1, fi)];
      // events up to now
      while (A.ei < R.ev.length && R.ev[A.ei][0] <= ti) onEvent(A, R.ev[A.ei++], xs, gy, sc, W);
      const F = R.fr[Math.min(n - 1, Math.round(fi))], F0 = R.fr[Math.min(n - 1, Math.floor(fi))], F1 = R.fr[Math.min(n - 1, Math.floor(fi) + 1)];
      // break stages (monotonic) → debris + sounds
      for (let k = 0; k < 2; k++) {
        const fr = F[2 + k] / R.mx[k];
        const stg = fr < 0.2 ? 3 : fr < 0.45 ? 2 : fr < 0.7 ? 1 : 0;
        if (stg > A.brk[k]) {
          const e = A.e[k], x0 = xs[k], by = gy - 56 * sc;
          void e;
          sparks(A, x0, by, 12, null, k ? 1 : -1);
          for (let q = 0; q < 3; q++) smoke(A, x0 + (Math.random() - 0.5) * 30 * sc, by - 10 * sc, true);
          A.brk[k] = stg; Snd.play('clank');
        }
      }
      // shake
      ctx.save();
      if (A.shake > 0) { ctx.translate((Math.random() - 0.5) * A.shake, (Math.random() - 0.5) * A.shake); A.shake = Math.max(0, A.shake - dt * 30); }
      drawBg(W, H, gy, t, true);
      for (let k = 0; k < 2; k++) {
        const moving = Math.abs(F1[k] - F0[k]) > 0.01;
        if (moving) A.wheel[k] += (F1[k] - F0[k]) * 3;
        const fl = F0[6] >> (k * 8);
        const dir = k ? -1 : 1;
        const loser = A.end && (f[5] === 1 - k || f[5] === 2);
        if (loser && !A.dead[k]) {
          A.dead[k] = 1;
          const e = A.e[k];
          void e;
          sparks(A, xs[k], gy - 50 * sc, 24, null, 0);
          for (let q = 0; q < 8; q++) smoke(A, xs[k] + (Math.random() - 0.5) * 50 * sc, gy - Math.random() * 80 * sc, true);
          ring(A, xs[k], gy - 50 * sc, '#ffd76a', 90 * sc); ring(A, xs[k], gy - 50 * sc, '#ff7a45', 60 * sc);
          for (let q = 0; q < 10; q++) fire(A, xs[k] + (Math.random() - 0.5) * 50 * sc, gy - Math.random() * 70 * sc);
          A.shake = 10; A.flash = 0.5; A.flashC = '#fff3d0';
          Snd.play('boom');
        }
        const kx = A.kx[k] * -dir; A.kx[k] = Math.max(0, A.kx[k] - dt * 40);
        if (A.dead[k]) { // KO: the whole robot (all parts attached) tips over backwards, scorched and darkened
          const u = Math.min(1, A.end * 2.5);
          ctx.save(); ctx.translate(xs[k], gy); ctx.rotate(-dir * 1.35 * u * u); ctx.translate(-xs[k], -gy);
          ctx.filter = 'brightness(' + (1 - 0.45 * u) + ')';
          drawRobot(ctx, A.e[k], xs[k], gy, sc, dir, { t: 0, brk: 3 });
          ctx.filter = 'none'; ctx.restore();
          if (Math.random() < dt * 6) sparks(A, xs[k] - dir * 20 * sc, gy - 30 * sc, 2, null, -dir);
          if (Math.random() < dt * 8) smoke(A, xs[k], gy - 14 * sc, true);
          continue;
        }
        drawRobot(ctx, A.e[k], xs[k] + kx, gy, sc, dir, { t, moving, swing: A.sw[k], recoil: A.rc[k], hurt: A.hurt[k], stun: fl & 1, burn: fl & 2, slow: fl & 4, cor: fl & 8, blind: fl & 16, mir: fl & 32,
          shield: F0[4 + k] > 0.5 ? 1 : 0, wheel: A.wheel[k] * dir, brk: A.brk[k] });
        // damage smoke / fire / sparks
        if (A.brk[k] >= 2 && Math.random() < dt * (A.brk[k] >= 3 ? 9 : 4)) smoke(A, xs[k] - dir * 6 * sc, gy - 70 * sc, A.brk[k] >= 3);
        if (A.brk[k] >= 3 && Math.random() < dt * 10) fire(A, xs[k] + (Math.random() - 0.5) * 24 * sc, gy - 48 * sc);
        if (A.brk[k] >= 1 && Math.random() < dt * 2) sparks(A, xs[k] - dir * 4 * sc, gy - 42 * sc, 2, null, dir);
        if ((fl & 2) && Math.random() < dt * 12) fire(A, xs[k] + (Math.random() - 0.5) * 30 * sc, gy - (30 + Math.random() * 50) * sc);
      }
      for (let k = 0; k < 2; k++) for (let q = 0; q < 2; q++) { A.sw[k][q] = Math.max(0, A.sw[k][q] - dt * 4 * speedMul * sp()); A.rc[k][q] = Math.max(0, A.rc[k][q] - dt * 6 * speedMul * sp()); }
      for (let k = 0; k < 2; k++) A.hurt[k] -= dt;
      // projectiles
      for (let q = A.pj.length - 1; q >= 0; q--) {
        const p = A.pj[q];
        p.t += dt * (p.v === 'drone' ? 3 : 5) * Math.min(3, speedMul * sp());
        if (p.t >= 1) { A.pj.splice(q, 1); continue; }
        const dir = p.s ? -1 : 1;
        const sx = xs[p.s] + dir * (p.slot === 2 ? 0 : 34) * sc, tx = xs[1 - p.s] - dir * 10 * sc;
        const y0 = gy - (p.slot === 1 ? 84 : p.slot === 2 ? 100 : 64) * sc, y1 = gy - 52 * sc;
        const x = U.lerp(sx, tx, p.t), y = U.lerp(y0, y1, p.t) - (p.v === 'mortar' ? Math.sin(p.t * Math.PI) * 60 * sc : p.v === 'drone' ? Math.sin(p.t * Math.PI) * 30 * sc : 0);
        const col = p.el >= 0 ? SETS[p.el].c : '#ddd';
        ctx.save();
        if (p.v === 'flamer' || p.v === 'dragon') { for (let k = 0; k < 4; k++) { ctx.fillStyle = k ? 'rgba(255,170,60,.7)' : 'rgba(255,240,180,.9)'; ctx.beginPath(); ctx.arc(x - dir * k * 8, y + (k - 1.5) * 3, (p.v === 'dragon' ? 8 : 6) - k, 0, 7); ctx.fill(); } }
        else if (p.v === 'beam' || p.v === 'rail' || p.v === 'sniper' || p.v === 'orbital' || p.v === 'laser' || p.el === 1) {
          ctx.strokeStyle = col; ctx.lineWidth = p.v === 'rail' || p.v === 'sniper' || p.v === 'orbital' ? 4 : 2.5; ctx.shadowColor = col; ctx.shadowBlur = 10; ctx.globalAlpha = 1 - p.t * 0.5;
          ctx.beginPath(); ctx.moveTo(sx, y0);
          if (p.el === 1 && p.v !== 'rail') { for (let k = 1; k <= 5; k++) ctx.lineTo(U.lerp(sx, x, k / 5), U.lerp(y0, y, k / 5) + (k % 2 ? -6 : 6)); } else ctx.lineTo(x, y);
          ctx.stroke();
          if (p.v !== 'rail') { ctx.strokeStyle = '#fff'; ctx.lineWidth = 1; ctx.stroke(); }
        } else if (p.v === 'disc') { ctx.translate(x, y); ctx.rotate(p.t * 20); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, 5, 0, 7); ctx.fill(); ctx.fillStyle = '#fff'; ctx.fillRect(-1, -5, 2, 10); }
        else if (p.v === 'drone') {
          for (let k = 0; k < (p.n || 1); k++) { const ox = -dir * k * 10, oy = (k % 2 ? -8 : 0);
            ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x + ox, y + oy, 5, 2.5, 0, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.fillRect(x + ox - 7, y + oy - 4, 14, 1.2); }
        } else if (p.v === 'swarm') { for (let k = 0; k < 3; k++) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x - dir * k * 6, y + Math.sin(p.t * 20 + k) * 5, 2.2, 0, 7); ctx.fill(); } if (Math.random() < 0.3) smoke(A, x, y, false); }
        else if (p.v === 'sprayer' || (p.el === 6 && p.v !== 'mortar')) { ctx.fillStyle = col; for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.arc(x - dir * k * 5, y + (k - 1) * 3, 3, 0, 7); ctx.fill(); } }
        else { ctx.fillStyle = col; ctx.shadowColor = col; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(x, y, p.big ? 5 : 3, 0, 7); ctx.fill(); ctx.globalAlpha = 0.4; ctx.beginPath(); ctx.arc(x - dir * 6, y, p.big ? 3.5 : 2, 0, 7); ctx.fill(); }
        ctx.restore();
        if (p.t > 0.86 && !p.done && p.hit) { p.done = 1; if (p.v === 'mortar' || p.big) { ring(A, tx, y1, col, 34 * sc); fire(A, tx, y1); } }
      }
      drawSpecials(A, xs, gy, sc, H, dt);
      drawParticles(A, dt * Math.min(2, Math.max(1, speedMul * sp() * 0.6)), gy);
      ctx.restore();
      // flash
      if (A.flash > 0) { ctx.globalAlpha = Math.min(0.5, A.flash); ctx.fillStyle = A.flashC; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; A.flash -= dt * 2; }
      // hp bars + names + special gauge
      const bw = Math.min(150, W * 0.42);
      for (let k = 0; k < 2; k++) {
        const x = k ? W - 8 - bw : 8, seat = f[k];
        const ghost = k === 1 && f[7];
        ctx.font = '700 12px "IBM Plex Sans KR",sans-serif'; ctx.textAlign = k ? 'right' : 'left'; ctx.fillStyle = pcol(seat);
        ctx.fillText((ghost ? '유령 · ' : '') + nm(seat), k ? x + bw : x, 16);
        const frac = F[2 + k] / R.mx[k];
        bar(x, 22, bw, 9, F[2 + k], R.mx[k], frac < 0.25 ? '#ee6a55' : frac < 0.5 ? '#e3ae45' : '#6fdc8c');
        if (F[4 + k] > 0.5) { ctx.fillStyle = 'rgba(169,188,207,.85)'; rr(ctx, x, 33, Math.min(1, F[4 + k] / R.mx[k]) * bw, 4, 2); ctx.fill(); }
        // special gauge
        const g = F[7 + k] / 100, spc = R.pr[k].spc, gc = spc >= 0 ? SETS[spc].c : '#f2e9d8';
        ctx.fillStyle = 'rgba(0,0,0,.45)'; rr(ctx, x, 40, bw * 0.6, 4, 2); ctx.fill();
        ctx.fillStyle = gc; ctx.globalAlpha = g >= 0.95 ? 0.6 + Math.sin(t * 20) * 0.4 : 0.9; rr(ctx, x + (k ? bw * 0.4 : 0), 40, bw * 0.6 * g, 4, 2); ctx.fill(); ctx.globalAlpha = 1;
        ctx.font = '600 10px "IBM Plex Mono",monospace'; ctx.fillStyle = '#f2e9d8';
        ctx.fillText(Math.ceil(F[2 + k]) + '/' + Math.round(R.mx[k]), k ? x + bw : x, 56);
        ctx.font = '600 9px "IBM Plex Sans KR",sans-serif'; ctx.fillStyle = gc; ctx.globalAlpha = 0.85;
        ctx.textAlign = k ? 'left' : 'right'; ctx.fillText('필살 ' + (spc >= 0 ? SETS[spc].sp : '펀치'), k ? x : x + bw, 56); ctx.globalAlpha = 1;
      }
      ctx.textAlign = 'center';
      if (fi >= OT) { ctx.font = '700 12px "IBM Plex Sans KR",sans-serif'; ctx.fillStyle = '#ee6a55'; ctx.fillText('과열! 둘 다 체력이 줄어요', W / 2, 72); }
      // special banner
      if (A.ban) {
        A.ban.t += dt * Math.min(2.5, speedMul * sp() * 0.7);
        const u = A.ban.t / 1.1;
        if (u >= 1) A.ban = null;
        else {
          const y = H * 0.24, sl = u < 0.15 ? (1 - u / 0.15) : 0;
          ctx.save(); ctx.globalAlpha = u > 0.8 ? (1 - u) / 0.2 : 1;
          ctx.translate(W / 2 + (A.ban.k ? 1 : -1) * sl * W * 0.6, y);
          ctx.fillStyle = 'rgba(15,11,20,.8)'; ctx.beginPath(); ctx.moveTo(-W * 0.42, -18); ctx.lineTo(W * 0.45, -18); ctx.lineTo(W * 0.42, 18); ctx.lineTo(-W * 0.45, 18); ctx.closePath(); ctx.fill();
          ctx.strokeStyle = A.ban.col; ctx.lineWidth = 2; ctx.stroke();
          ctx.font = '400 22px "Black Han Sans","IBM Plex Sans KR",sans-serif'; ctx.fillStyle = A.ban.col; ctx.textBaseline = 'middle';
          ctx.fillText(A.ban.txt, 0, 1); ctx.textBaseline = 'alphabetic';
          ctx.restore();
        }
      }
      // floaters
      for (let q = A.fl.length - 1; q >= 0; q--) {
        const fq = A.fl[q];
        fq.t += dt * Math.min(3, speedMul * sp() * 0.8);
        if (fq.t >= 1.2) { A.fl.splice(q, 1); continue; }
        const x = xs[fq.s] + fq.x, y = gy - 104 * sc - fq.t * 34 - (fq.big ? 6 : 0) - (fq.row || 0) * 15;
        const pop = fq.t < 0.12 ? 1 + (0.12 - fq.t) * 4 : 1;
        ctx.globalAlpha = Math.max(0, 1 - fq.t / 1.2);
        ctx.font = (fq.big ? '800 ' + Math.round(19 * pop) + 'px' : '800 ' + Math.round(14 * pop) + 'px') + ' "IBM Plex Mono","IBM Plex Sans KR",monospace';
        ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.75)'; ctx.strokeText(fq.txt, x, y);
        ctx.fillStyle = fq.c; ctx.fillText(fq.txt, x, y);
        ctx.globalAlpha = 1;
      }
      if (A.end) {
        if (!A.endSnd) { A.endSnd = 1; const mine = api.mySeats(); const me = mine.includes(f[0]) ? 0 : mine.includes(f[1]) && !f[7] ? 1 : -1;
          Snd.play(f[5] === 2 ? 'lose' : me < 0 || f[5] === me ? 'win' : 'lose'); }
        const wtxt = f[5] === 2 ? '무승부!' : (f[5] === 1 && f[7] ? '유령 로봇' : nm(f[f[5]])) + ' 승리!';
        const ltxt = f[5] === 2 ? (f[7] ? nm(f[0]) + ' 목숨 −' + f[6] : '둘 다 목숨 −' + f[6])
          : f[7] && f[5] === 0 ? '유령 주인은 목숨이 줄지 않아요' : nm(f[1 - f[5]]) + ' 목숨 −' + f[6];
        const a = Math.min(1, A.end * 3), s2 = 0.8 + Math.min(0.2, A.end * 1.2);
        ctx.save(); ctx.globalAlpha = a; ctx.translate(W / 2, H * 0.36); ctx.scale(s2, s2);
        ctx.fillStyle = 'rgba(15,11,20,.8)'; rr(ctx, -130, -31, 260, 62, 14); ctx.fill();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 2; ctx.stroke();
        ctx.font = '400 24px "Black Han Sans","IBM Plex Sans KR",sans-serif'; ctx.fillStyle = '#e3ae45'; ctx.fillText(wtxt, 0, -3);
        ctx.font = '600 13px "IBM Plex Sans KR",sans-serif'; ctx.fillStyle = '#f2e9d8'; ctx.fillText(ltxt, 0, 19);
        ctx.restore();
      }
      ctx.textAlign = 'left';
    }

    /* ---------------- frame (rAF loop + synchronous repaints) ---------------- */
    let tt = 0, sigT = 0;
    function paint(dt) {
      if (!(dt > 0)) dt = 0;   // first rAF timestamp can be older than performance.now() → negative dt
      tt += dt;
      try {
        if (anim) advance(dt);
        const W = cvs.w, H = cvs.h;
        cvs.clear(); ctx.globalAlpha = 1; ctx.setLineDash([]); ctx.shadowBlur = 0;
        if (W < 4 || H < 4) return;
        if (anim) drawBattle(W, H, tt, dt); else drawGarage(W, H, tt, dt);
      } catch (err) {
        console.error('robobattle draw', err);
        try { if (anim) finishAnim(); } catch (e2) { anim = null; setBusy(false); }
      }
      // guest seats can become "mine" without a new state (late peer id) → re-render when that changes
      sigT += dt;
      if (sigT > 0.5) { sigT = 0; const sg = api.mySeats().join(','); if (sg !== seatSig) { seatSig = sg; pkey = ''; tkey = ''; ekey = ''; try { renderAll(true); } catch (e3) { console.error(e3); } } }
    }
    cvs.onresize = () => paint(0);   // resizing clears the bitmap after this frame's rAF → repaint right away
    const stop = U.loop((dt) => paint(dt));

    function renderAll(force) { renderTop(); renderPanel(force); renderEq(); }
    return {
      update(s, prev) {
        st = s;
        if (s.last && prev && prev !== s && (!prev.last || prev.last.id !== s.last.id)) startAnim(s, prev);
        renderAll();
        cvs.fit(); paint(0);
      },
      destroy() { stop(); cvs.destroy(); setBusy(false); style.remove(); wrap.remove(); Snd.close(); },
    };
  }

  const ICON = '<rect x="18" y="14" width="20" height="20" rx="4" fill="currentColor"/>' +
    '<rect x="22" y="6" width="12" height="8" rx="2" fill="currentColor" opacity=".8"/>' +
    '<path d="M38 20H48M48 16V24" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>' +
    '<path d="M18 22L10 28" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/>' +
    '<rect x="20" y="36" width="16" height="4" rx="1.5" fill="currentColor" opacity=".7"/>' +
    '<circle cx="21" cy="46" r="5" fill="currentColor"/><circle cx="35" cy="46" r="5" fill="currentColor"/>';

  /* ============================== 도감 (데이터 표에서 자동으로 만듦) ============================== */
  /* 부품 그림: 그 부품만 단 로봇을 그려 부품 자리 둘레를 잘라 씀(나머지 자리는 회색 기본 부품) */
  const CX_CROP = { B: [0, -60, 40], A: [30, -62, 22], L: [0, -20, 26], W: [22, 0, 27], C: [0, -56, 15] };   // 무기는 무기만 따로 그림
  function partSprite(i) {
    try {
      const D = PARTS[i], cr = CX_CROP[D.t], S = 72, cv = document.createElement('canvas');
      cv.width = S; cv.height = S;
      const c = cv.getContext('2d'); if (!c) return '';
      const e = [null, null, null, null, null, null]; e[D.t === 'W' ? 3 : SLOTS.indexOf(D.t)] = { i, l: 1 };
      const k = S / (cr[2] * 2);
      c.translate(S / 2 - cr[0] * k, S / 2 - cr[1] * k);
      if (D.t === 'W') { c.scale(k, k); c.lineJoin = 'round'; c.lineCap = 'round'; drawWeapon(c, { i, l: 1 }, 0, 0, false, 0, 0, 0); }
      else drawRobot(c, e, 0, 0, k, 1, { t: 0 });
      return '<img alt="" src="' + cv.toDataURL() + '" style="width:34px;height:34px">';
    } catch (err) { return ''; }
  }
  let cxCache = null;
  function roboCodex() {
    if (cxCache) return cxCache;
    const pct = (v) => Math.round(v * 100) + '%';
    const dot = (c) => '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><circle cx="12" cy="12" r="9" fill="' + c + '" stroke="rgba(0,0,0,.4)" stroke-width="1.5"/></svg>';
    const dot2 = (a, b) => '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><circle cx="9" cy="12" r="7" fill="' + a + '" stroke="rgba(0,0,0,.4)" stroke-width="1.5"/><circle cx="15" cy="12" r="7" fill="' + b + '" stroke="rgba(0,0,0,.4)" stroke-width="1.5"/></svg>';
    const order = PARTS.map((D, i) => i).sort((a, b) => PARTS[a].e - PARTS[b].e || PARTS[a].c - PARTS[b].c || a - b);
    const parts = order.map((i) => {
      const D = PARTS[i];
      const el = D.t === 'W' && WEAPON_EL[D.e] ? ' · 맞히면: ' + WEAPON_EL[D.e] : '';
      return { icon: partSprite(i) || dot(SETS[D.e].c), name: D.n, tag: SETS[D.e].n + ' · ' + TN[D.t] + ' · ' + TIER[D.c] + ' ' + price(i) + '금화',
        desc: statLines(D, 1).join(' · ') + el };
    });
    const cntBy = (k) => { const n = Array(NS).fill(0); PARTS.forEach((D) => n[D.e]++); return n[k]; };
    const sets = SETS.map((S, k) => ({ icon: dot(S.c), name: S.n, tag: '부품 ' + cntBy(k) + '개 · 필살기 ' + S.sp,
      desc: '2개: ' + S.two + ' / 4개: ' + S.four + (WEAPON_EL[k] ? ' · 이 세트 무기로 맞히면 ' + WEAPON_EL[k] : '') }));
    const combos = COMBOS.map((C) => ({ icon: dot2(SETS[C.a].c, SETS[C.b].c), name: C.n, tag: SETS[C.a].n + ' 2 + ' + SETS[C.b].n + ' 2', desc: C.d }));
    const sps = SETS.map((S, k) => ({ icon: dot(S.c), name: S.sp, tag: S.n + ' 세트', desc: SPECIAL_D[k] }));
    const odds = [];
    for (let r = 1; r <= 12; r++) { const o = tierOdds(r); odds.push(r + '라운드' + (r === 12 ? '~' : '') + ': ' + [1, 2, 3, 4].filter((c) => o[c] > 0.001).map((c) => TIER[c] + ' ' + Math.round(o[c] * 100)).join(' · ')); }
    const tierN = [1, 2, 3, 4].map((c) => TIER[c] + ' ' + POOLS[c].length + '종(' + (c + 1) + '금화)').join(' · ');
    cxCache = [
      { h: '부품', p: ['세트·등급 순서예요. 수치는 ★ 기준이고, 합체하면 ★★ 체력·방어·피해 ×1.8(★★★ ×3), 공격력·속도%·회피·치명·반사 ×1.5(×2), 이동·적재 ×1.2(×1.4)예요.'], rows: parts },
      { h: '세트', p: ['같은 세트를 2개·4개 장착하면 효과가 생겨요(무기 2칸 모두 셈).'], rows: sets },
      { h: '콤보', p: ['두 세트를 2개씩 장착하면 덤으로 생기는 효과예요.'], rows: combos },
      { h: '필살기', p: ['전투 중 게이지가 차면(시간 + 맞을수록 빨리) 저절로 나가요. 가장 많이 장착한 세트의 필살기(같으면 무기 1의 세트). 같은 세트 1개 더할 때마다 +8%(최대 +40%).'], rows: sps },
      { h: '등장률·경제', p: [
        '상점 카드 ' + SHOP + '장의 등급 확률(%):'].concat(odds, [
        '부품 수: ' + tierN + '.',
        '가진 부품은 내 상점에 더 자주 나와요: 1개마다 +100%(★★는 2개로 셈, 최대 5배, ★★★는 제외).',
        '처음 금화 ' + START_GOLD + '. 라운드마다 5 + 이자(가진 금화 10마다 1, 최대 2) + 지난 판 이기면 1. 금화는 최대 ' + MAXG + '까지 모여요.',
        '새로고침 1금화. 팔면 산 값 그대로(★★ = 3개 값, ★★★ = 9개 값). 보관함 ' + BENCH + '칸.',
        '진 사람 목숨 −(2 + 라운드÷2 + 이긴 로봇의 남은 체력에 따라 1~4), 최대 12. 비기면 둘 다 절반. ' + MAXR + '라운드가 지나면 목숨이 가장 많은 사람이 이겨요.',
        '전력: 코어·몸통이 주고 무기·팔·다리가 써요. 모자라면 공격이 느려져요(최대 −70%). 무게가 적재량을 넘으면 느려지고 회피 0.',
      ]) },
    ];
    return cxCache;
  }

  L.register({
    get codex() { return roboCodex(); },
    id: 'robobattle', name: '로봇 조립 자동 전투', tag: '조립 · 오토배틀', cat: '보드',
    icon: ICON, tint: '#2f4a6b',
    blurb: '부품 84종으로 몸통·팔·다리·무기·코어를 사서 로봇을 조립하고, 필살기가 터지는 자동 전투를 관전해요. 라운드마다 강화해 마지막까지 살아남으면 우승!',
    minPlayers: 2, maxPlayers: 8, defaultPlayers: 4, aiDelay: 600,
    hidden: false,
    options: [
      { id: 'life', label: '목숨', choices: [{ v: 20, label: '20 (짧게)' }, { v: 30, label: '30' }, { v: 40, label: '40 (길게)' }], def: 30 },
    ],
    quick: [
      '라운드마다 금화로 부품을 사서 로봇을 조립해요(몸통·팔·다리·무기 2·코어).',
      '모두 「준비 완료」하면 둘씩 짝지어 로봇이 저절로 싸워요. 지면 목숨이 줄어요.',
      '목숨이 0이 되면 탈락! 마지막까지 남은 사람이 우승해요.',
    ],
    rules: [
      { h: '목표', p: [
        '모두 똑같이 목숨 30(옵션)과 빈 로봇 뼈대로 시작해요.',
        '부품을 사서 로봇을 강하게 만들고, 자동 전투에서 이겨 끝까지 살아남으면 우승이에요.',
        '25라운드가 지나도 여럿이 남으면 목숨이 가장 많은 사람이 이겨요.'] },
      { h: '라운드에 할 일 (상점)', p: [
        '모두 동시에 내 상점을 봐요. 상점엔 부품 5개가 있어요. 카드를 누르면 바로 사요(꾹 누르면 설명).',
        '가운데 큰 로봇 양옆의 6칸이 장착 자리예요. 산 부품은 빈 자리에 저절로 끼워지고, 자리가 차 있으면 보관함(4칸)에 들어가요.',
        '장착 칸이나 보관함 부품을 누르면 장착 · 바꿔 끼우기 · 보관함으로 · 팔기를 할 수 있어요. 팔면 산 값 그대로 돌려받아요.',
        '맨 위 「추천」 줄과 카드의 작은 표시(★★ 합체 · 세트2 · 콤보! · +20%)가 무엇을 사면 좋은지 알려 줘요.',
        '「↻ 1」(1금화)로 상점을 새로 채워요. 다 했으면 「준비 완료 ▶」!'] },
      { h: '금화와 상점 확률', p: [
        '처음엔 8금화. 라운드마다 5금화 + 이자(가진 금화 10마다 1, 최대 2) + 지난 판에 이겼으면 1을 더 받아요.',
        '부품은 일반(2금화) · 고급(3) · 희귀(4) · 전설(5) 네 등급이에요. 라운드가 지날수록 비싸고 강한 부품이 자주 나와요(전설은 7라운드부터).',
        '가진 부품은 내 상점에 더 자주 나와요! 1개마다 등장 +100%(★★는 2개로 셈, 최대 5배). 카드의 「▲×3」이 그 표시예요.',
        '금화 칸을 누르면 이번 라운드 등급 확률과 내 부품의 등장 확률을 볼 수 있어요.'] },
      { h: '합체 (★)', p: [
        '같은 부품 3개를 모으면 저절로 합쳐져 ★★가 돼요(능력 약 1.8배). ★★ 3개면 ★★★(약 3배)!',
        '보관함 칸에 노란 테두리가 있으면 1개만 더 사면 합체돼요.'] },
      { h: '전력과 무게', p: [
        '무기·팔·다리는 전력을 쓰고, 코어와 몸통이 전력을 줘요. 쓰는 전력이 더 많으면 공격이 느려져요.',
        '다리(적재량)보다 무거우면 움직임이 느려지고 회피를 못 해요. 로봇 위의 막대가 빨개지면 조심!',
        '자리가 비면 기본 부품(맨 몸통 · 작은 바퀴 · 주먹)으로 싸워요.'] },
      { h: '세트 효과 (10가지)', p: [
        '같은 세트를 2개, 4개 장착하면 효과가 생겨요. 로봇 아래 칸에 세트 진행(예: 화염 3/4)이 보여요.',
        '화염: 맞히면 불이 붙어 계속 피해 · 전기: 몇 번 맞히면 상대가 잠깐 멈춤(감전) · 방패: 시작할 때 보호막',
        '속도: 공격이 빨라지고 잘 피함 · 냉기: 맞히면 상대가 느려짐 · 수리: 체력이 조금씩 회복',
        '산성: 맞히면 상대 방어를 깎음(부식) · 레이저: 치명타(피해 2배) · 드론: 드론이 저절로 날아가 공격 · 거울: 받은 피해 일부를 되돌려줌'] },
      { h: '콤보 (두 세트를 2개씩)', p: [
        '화염+냉기 「열충격」 · 전기+레이저 「과충전 광선」 · 방패+거울 「반사 방벽」',
        '속도+드론 「고속 편대」 · 수리+드론 「정비 드론」 · 산성+화염 「부식 연소」 — 부품 설명이나 추천 줄에서 효과를 볼 수 있어요.'] },
      { h: '필살기', p: [
        '싸우는 동안 이름 아래 필살 게이지가 차요(시간 + 맞을수록 빨리). 가득 차면 필살기가 저절로 나가요.',
        '필살기는 가장 많이 장착한 세트로 정해져요(같으면 무기 1의 세트). 같은 세트가 많을수록 세져요.',
        '화염 폭풍 · 낙뢰 · 방벽 전개 · 질풍 연타 · 절대 영도 · 긴급 수리 · 산성비 · 궤도 레이저 · 드론 폭격 · 거울 결계.'] },
      { h: '자동 전투', p: [
        '근접 무기 로봇은 다가가고, 원거리 로봇은 거리를 벌리며 쏴요. 조작은 필요 없고 관전만 해요.',
        '체력이 줄면 로봇이 그을리고 스파크·연기가 나요(보이기만 하고 능력은 그대로예요).',
        '20초가 지나면 「과열」로 둘 다 체력이 점점 줄어요. 끝까지 둘 다 버티면 체력 비율이 높은 쪽이 이겨요.',
        '진 사람은 목숨이 「2 + 라운드÷2 + 이긴 로봇의 남은 체력에 따라 1~4」만큼 줄어요(최대 12).',
        '인원이 홀수면 한 명은 다른 사람 로봇을 본뜬 「유령 로봇」과 싸워요(유령 주인은 목숨이 안 줄어요).',
        '「빠르기」로 전투를 빨리 보고, 「건너뛰기」로 바로 결과를 봐요. 위의 이름을 누르면 그 사람 로봇을 볼 수 있어요.'] },
      { h: '예시', p: [
        '1라운드: 8금화로 「불꽃 도끼」(2) + 「강철 장갑 몸통」(2) + 「발전기 코어」(2)를 사면 2금화가 남아요.',
        '2라운드에 「불꽃 집게팔」을 사면 화염 2개 → 불 피해 1.5배! 추천 줄에 「화염 세트 2개 완성」이라고 떠요.',
        '불꽃 도끼를 가지고 있으면 상점에 불꽃 도끼가 2배 자주 나와요. 2개 더 사면 ★★ 불꽃 도끼로 합체!'] },
      { h: 'AI 난이도', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움은 아무거나 사요. 보통은 강해지는 부품과 합체를 노려요. 어려움은 상대 로봇에 맞춰 세트를 모으고, 같은 부품을 모아 상점 확률을 올리며, 새로고침과 이자까지 챙겨요.'] },
    ],
    tutorial: [
      { sel: '.rb-arena', text: '가운데가 내 로봇, 양옆 6칸이 장착 자리(몸통·팔·다리·무기 2·코어)예요. 칸을 누르면 바꾸거나 팔 수 있어요. 위 막대가 빨개지면 전력·무게 초과!' },
      { sel: '.rb-shop', text: '부품 상점이에요. 카드를 누르면 바로 사요(꾹 누르면 설명). 색 띠는 세트 — 같은 세트 2개·4개면 효과! 「▲×2」는 가진 부품이라 더 자주 나온다는 표시예요.' },
      { sel: '.rb-hint', text: '추천 줄이 「이걸 사면 화염 세트 2개 완성」처럼 알려 줘요. 노랗게 빛나는 카드가 추천 부품이에요.' },
      { sel: '.rb-bench', text: '보관함 4칸. 같은 부품 3개가 모이면 ★★로 합체해요.' },
      { sel: '.rb-go', text: '다 샀으면 「준비 완료」! 모두 준비되면 로봇끼리 자동으로 싸워요. 필살 게이지가 차면 필살기가 터져요!' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { PARTS, SETS, COMBOS, AL, sim, prof, power, decE, encE, model, buyInto, botShop, rollShop, merge, advise, boostOf, tierOdds, slotRate, setCounts },
  });
})();
