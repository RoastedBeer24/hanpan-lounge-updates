/* 도둑잡기 — 52장 + 조커(도둑) 1장(설정: 조커 대신 Q 한 장 빼기). 다 나눠 주고 같은 숫자 짝을 버린 뒤,
   차례대로 다음 사람 패에서 뒷면으로 한 장 뽑아 짝이 맞으면 버려요. 패를 다 털면 안전, 마지막까지 도둑을 든 사람이 져요.
   패의 순서(문자열 순서)가 곧 자리 — 뽑은 카드는 오른쪽 끝에 들어가고, 주인은 언제든 「섞기」로 순서를 바꿀 수 있어요.
   섞기는 상태만 바꾸는 api.setState(호스트/로컬)로, 게스트는 api.net.publish({sq})로 호스트에게 요청해요.
   뽑는 사람이 만지는 카드(hv)도 publish로 실시간 공유 → 온라인에서는 주인 폰에 「만지는 중」이 보여요. */
(function () {
  const L = window.Lounge, U = L.util;

  /* ---------- cards: one char each ---------- */
  const ALPH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0';
  const JK = 52;
  const SUITS = ['♠', '◆', '♥', '♣'];
  const RK = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const ci = (ch) => ALPH.indexOf(ch);
  const cc = (i) => ALPH[i];
  const suitOf = (i) => (i >= 52 ? -1 : (i / 13) | 0);
  const rankOf = (i) => (i >= 52 ? 0 : (i % 13) + 1);
  const isJk = (i) => i === JK;
  const cardName = (i) => (isJk(i) ? '도둑(조커)' : SUITS[suitOf(i)] + RK[rankOf(i)]);
  /* the dangerous card: the joker, or (Q mode) any queen — the odd one is unknown */
  const isBad = (s, ch) => { const i = ci(ch); return s.o.q ? rankOf(i) === 12 : isJk(i); };
  const shuffleStr = (x) => U.shuffle(x.split('')).join('');

  /* drop every pair of the same rank (colour/suit ignored); keeps the order of the remaining cards */
  function discardPairs(hand) {
    const keep = [], disc = [], byR = {};
    for (const ch of hand) {
      const i = ci(ch);
      if (isJk(i)) { keep.push(ch); continue; }
      const r = rankOf(i);
      if (byR[r] != null) { const k = byR[r]; disc.push(keep[k], ch); keep[k] = null; byR[r] = null; }
      else { byR[r] = keep.length; keep.push(ch); }
    }
    return [keep.filter(Boolean).join(''), disc.join('')];
  }

  /* ---------- state ----------
     h: hands (string order = position, last = rightmost), dp: discarded pairs, d0: pairs dropped at the start (per seat,
     for the opening animation), t: drawer, o: {q: 1 = Q mode, d: ±1 direction}, out: 1 = safe, rk: safe order,
     lose: loser seat, sc: shuffle counters, jt: last hand-off of a dangerous card {f: giver, t: taker, ch, c: taker's sc}
     (what the giver saw), rm: card set aside (Q mode), gid: game id, last: latest event, seq */
  function init(players, opts) {
    opts = opts || {};
    const n = players.length;
    const o = { q: opts.mode === 'queen' ? 1 : 0, d: opts.dir === 'ccw' ? -1 : 1 };
    let deck = ALPH.slice(0, 52) + (o.q ? '' : ALPH[JK]);
    let rm = '';
    if (o.q) { rm = cc(U.rand(4) * 13 + 11); deck = deck.replace(rm, ''); }
    deck = shuffleStr(deck);
    const h = players.map(() => '');
    const k0 = U.rand(n);
    for (let j = 0; j < deck.length; j++) h[(k0 + j) % n] += deck[j];
    const d0 = [];
    let dp = '';
    for (let k = 0; k < n; k++) { const r = discardPairs(h[k]); h[k] = r[0]; d0.push(r[1]); dp += r[1]; }
    const s = {
      n, nm: players.map((p) => p.name), ai: players.map((p) => (p.ai ? 1 : 0)), o, gid: Math.random().toString(36).slice(2, 7),
      h, dp, d0, t: 0, out: h.map(() => 0), rk: [], lose: -1, end: 0, sc: h.map(() => 0), jt: null, rm, seq: 1, last: { id: 1, k: 's' },
    };
    for (let k = 0; k < n; k++) if (!h[k].length) { s.out[k] = 1; s.rk.push(k); }
    const act = active(s);
    s.t = act.length ? act[U.rand(act.length)] : 0;
    checkEnd(s);
    return s;
  }
  function active(s) { const a = []; for (let i = 0; i < s.n; i++) if (!s.out[i]) a.push(i); return a; }
  function nextActive(s, from) {
    for (let k = 1; k <= s.n; k++) { const i = (((from + s.o.d * k) % s.n) + s.n) % s.n; if (!s.out[i]) return i; }
    return from;
  }
  /* the player the drawer takes from */
  const target = (s) => nextActive(s, s.t);
  function checkEnd(s) {
    const a = active(s);
    if (a.length <= 1) { s.end = 1; s.lose = a.length ? a[0] : -1; return true; }
    return false;
  }
  function actor(s) { return s.end ? null : s.t; }

  function apply(s, seat, a) {
    if (s.end) throw new Error('game over');
    if (seat !== s.t) throw new Error('not your turn');
    if (!a || a.t !== 'p') throw new Error('bad action');
    const f = target(s);
    if (f === seat) throw new Error('no target');
    const i = a.i;
    if (typeof i !== 'number' || (i | 0) !== i || i < 0 || i >= s.h[f].length) throw new Error('no such card');
    const ch = s.h[f][i];
    s.h[f] = s.h[f].slice(0, i) + s.h[f].slice(i + 1);
    s.seq++;
    const ev = { id: s.seq, k: 'p', s: seat, f, i, c: ch };
    let pr = '';
    const ii = ci(ch);
    if (!isJk(ii)) for (const x of s.h[seat]) { const xi = ci(x); if (!isJk(xi) && rankOf(xi) === rankOf(ii)) { pr = x; break; } }
    if (pr) { s.h[seat] = s.h[seat].replace(pr, ''); s.dp += pr + ch; ev.pr = pr; }
    else {
      s.h[seat] += ch;
      if (isBad(s, ch)) s.jt = { f, t: seat, ch, c: s.sc[seat] };
    }
    if (a.sh && s.h[seat].length > 1) { s.h[seat] = shuffleStr(s.h[seat]); s.sc[seat]++; ev.sh = 1; }
    const safe = [];
    if (!s.h[f].length) { s.out[f] = 1; s.rk.push(f); safe.push(f); }
    if (!s.h[seat].length) { s.out[seat] = 1; s.rk.push(seat); safe.push(seat); }
    if (safe.length) ev.safe = safe;
    s.d0 = null;
    if (checkEnd(s)) ev.lose = s.lose;
    else s.t = nextActive(s, seat);
    s.last = ev;
    return s;
  }
  /* shuffle one player's hand (not an action: the holder may do it any time — host/local applies it via setState) */
  function shuffleSeat(s, seat) {
    if (s.end || s.out[seat] || s.h[seat].length < 2) return s;
    s.h[seat] = shuffleStr(s.h[seat]);
    s.sc[seat]++;
    return s;
  }
  function result(s) {
    if (!s.end) return null;
    const lo = s.lose;
    const ranks = s.rk.map((x, k) => (k + 1) + '위 ' + s.nm[x]).join(' · ');
    if (lo < 0) return { winners: s.rk.slice(), title: '모두 안전!', text: ranks };
    const why = s.o.q ? '짝 없는 Q를 끝까지 들고 있었어요 (빼 둔 카드: ' + cardName(ci(s.rm)) + ')' : '도둑(조커)을 끝까지 들고 있었어요';
    return { winners: s.rk.slice(), title: s.o.q ? s.nm[lo] + ' 패배!' : '도둑은 ' + s.nm[lo] + '!', text: s.nm[lo] + ' — ' + why + '\n' + ranks };
  }

  /* ---------- AI ----------
     Picking is luck. 어려움 remembers a dangerous card it handed over: while the taker has not shuffled since, it knows
     where that card sits and mostly avoids it; it shuffles whenever it holds the danger (and now and then as a bluff).
     보통 shuffles sometimes while holding it; 쉬움 never shuffles. */
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.end || seat !== s.t) return null;
    const f = target(s), m = s.h[f].length;
    let i = U.rand(m);
    const jt = s.jt;
    if (lv === 3 && jt && jt.f === seat && jt.t === f && s.sc[f] === jt.c && m > 1) {
      const p = s.h[f].indexOf(jt.ch);
      if (p >= 0 && Math.random() < 0.8) { while (i === p) i = U.rand(m); }
    }
    // what will my hand hold after this pick?
    const ch = s.h[f][i], r = rankOf(ci(ch));
    let hand = s.h[seat];
    const pr = isJk(ci(ch)) ? '' : hand.split('').find((x) => !isJk(ci(x)) && rankOf(ci(x)) === r);
    hand = pr ? hand.replace(pr, '') : hand + ch;
    const holdBad = hand.split('').some((x) => isBad(s, x));
    let sh = 0;
    if (hand.length > 1) {
      if (lv === 3) sh = holdBad || Math.random() < 0.25 ? 1 : 0;
      else if (lv === 2) sh = holdBad && Math.random() < 0.45 ? 1 : 0;
    }
    return sh ? { t: 'p', i, sh: 1 } : { t: 'p', i };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.end || seat !== s.t) return -1;
    lv = lv || 2;
    const base = lv === 1 ? 1500 : lv === 3 ? 950 : 1200;
    return base + Math.random() * 650 + (s.last && s.last.k === 's' ? 300 : 0);
  }

  /* ---------- drawing ---------- */
  const RED = '#b8322a', INK = '#1d1a22';
  const SU_CH = ['S', 'D', 'H', 'C'];
  const FONT = '"IBM Plex Sans KR", system-ui, sans-serif', MONO = '"IBM Plex Mono", ui-monospace, monospace', DISP = '"Black Han Sans", "IBM Plex Sans KR", sans-serif';
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  function suitPath(ctx, su, x, y, sz) {
    const k = sz / 2;
    ctx.beginPath();
    if (su === 'H') {
      ctx.moveTo(x, y + k * 0.92);
      ctx.bezierCurveTo(x - k * 1.15, y + k * 0.05, x - k * 0.95, y - k * 1.0, x, y - k * 0.42);
      ctx.bezierCurveTo(x + k * 0.95, y - k * 1.0, x + k * 1.15, y + k * 0.05, x, y + k * 0.92);
    } else if (su === 'D') {
      ctx.moveTo(x, y - k); ctx.lineTo(x + k * 0.74, y); ctx.lineTo(x, y + k); ctx.lineTo(x - k * 0.74, y); ctx.closePath();
    } else if (su === 'S') {
      ctx.moveTo(x, y - k * 0.98);
      ctx.bezierCurveTo(x + k * 1.2, y - k * 0.05, x + k * 0.95, y + k * 0.82, x + k * 0.05, y + k * 0.36);
      ctx.lineTo(x + k * 0.32, y + k); ctx.lineTo(x - k * 0.32, y + k); ctx.lineTo(x - k * 0.05, y + k * 0.36);
      ctx.bezierCurveTo(x - k * 0.95, y + k * 0.82, x - k * 1.2, y - k * 0.05, x, y - k * 0.98);
    } else {
      const r = k * 0.4;
      for (const [cx, cy] of [[x, y - k * 0.48], [x - k * 0.48, y + k * 0.12], [x + k * 0.48, y + k * 0.12]]) { ctx.moveTo(cx + r, cy); ctx.arc(cx, cy, r, 0, Math.PI * 2); }
      ctx.moveTo(x - k * 0.1, y); ctx.lineTo(x + k * 0.1, y); ctx.lineTo(x + k * 0.3, y + k); ctx.lineTo(x - k * 0.3, y + k); ctx.closePath();
    }
    ctx.fill();
  }
  function ivory(ctx, x, y, w) {
    const h = w * 1.4;
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, '#fffaf0'); g.addColorStop(1, '#efe5cf');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(80,60,30,.35)'; ctx.lineWidth = 1; ctx.stroke();
  }
  /* the 도둑: a grinning masked burglar in a striped beanie with a loot sack */
  function drawThief(ctx, x, y, w) {
    const h = w * 1.4;
    ivory(ctx, x, y, w);
    const cx = x + w * 0.52, cy = y + h * 0.5, r = w * 0.23;
    ctx.save();
    // loot sack behind
    ctx.fillStyle = '#9a6a3a';
    ctx.beginPath(); ctx.ellipse(x + w * 0.74, y + h * 0.74, w * 0.15, w * 0.14, 0, 0, 7); ctx.fill();
    ctx.fillStyle = '#7a4f28'; rr(ctx, x + w * 0.69, y + h * 0.62, w * 0.1, w * 0.06, 2); ctx.fill();
    ctx.fillStyle = '#f2d27a'; ctx.font = '700 ' + Math.round(w * 0.14) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('₩', x + w * 0.74, y + h * 0.75);
    // face
    ctx.fillStyle = '#f0d2a8'; ctx.beginPath(); ctx.arc(cx, cy, r, 0, 7); ctx.fill();
    // stubble
    ctx.fillStyle = 'rgba(70,60,80,.25)'; ctx.beginPath(); ctx.arc(cx, cy + r * 0.25, r * 0.78, 0.15 * Math.PI, 0.85 * Math.PI); ctx.fill();
    // beanie
    ctx.fillStyle = '#2a2440'; ctx.beginPath(); ctx.arc(cx, cy - r * 0.15, r * 1.04, Math.PI, 0); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#c0392b'; rr(ctx, cx - r * 1.08, cy - r * 0.32, r * 2.16, r * 0.3, r * 0.12); ctx.fill();
    ctx.fillStyle = '#c0392b'; ctx.beginPath(); ctx.arc(cx, cy - r * 1.22, r * 0.2, 0, 7); ctx.fill();
    // mask
    ctx.fillStyle = '#16121c'; rr(ctx, cx - r * 1.12, cy - r * 0.02, r * 2.24, r * 0.42, r * 0.2); ctx.fill();
    ctx.fillStyle = '#fffaf0';
    ctx.beginPath(); ctx.ellipse(cx - r * 0.42, cy + r * 0.19, r * 0.2, r * 0.13, 0, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.ellipse(cx + r * 0.42, cy + r * 0.19, r * 0.2, r * 0.13, 0, 0, 7); ctx.fill();
    ctx.fillStyle = INK; // shifty eyes looking sideways
    ctx.beginPath(); ctx.arc(cx - r * 0.32, cy + r * 0.2, r * 0.08, 0, 7); ctx.fill();
    ctx.beginPath(); ctx.arc(cx + r * 0.52, cy + r * 0.2, r * 0.08, 0, 7); ctx.fill();
    // grin
    ctx.strokeStyle = INK; ctx.lineWidth = Math.max(1, w * 0.025); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(cx + r * 0.08, cy + r * 0.52, r * 0.32, 0.12 * Math.PI, 0.8 * Math.PI); ctx.stroke();
    ctx.restore();
    // corners: 도 / 둑
    ctx.fillStyle = RED; ctx.font = '700 ' + Math.round(w * 0.2) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.fillText('도', x + w * 0.16, y + w * 0.24); ctx.fillText('둑', x + w * 0.16, y + w * 0.45);
    ctx.save(); ctx.translate(x + w, y + h); ctx.rotate(Math.PI);
    ctx.fillText('도', w * 0.16, w * 0.24); ctx.fillText('둑', w * 0.16, w * 0.45);
    ctx.restore();
  }
  function drawCardFace(ctx, x, y, w, i) {
    if (isJk(i)) return drawThief(ctx, x, y, w);
    const h = w * 1.4, su = SU_CH[suitOf(i)], rk = RK[rankOf(i)];
    const col = su === 'H' || su === 'D' ? RED : INK;
    ivory(ctx, x, y, w);
    ctx.fillStyle = col; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    const fs = Math.round(w * 0.3);
    ctx.font = '700 ' + fs + 'px ' + FONT;
    const corner = (cx, cy) => {
      if (rk === '10') { ctx.save(); ctx.translate(cx, cy); ctx.scale(0.74, 1); ctx.fillText(rk, 0, 0); ctx.restore(); } else ctx.fillText(rk, cx, cy);
    };
    corner(x + w * 0.17, y + fs * 0.98);
    suitPath(ctx, su, x + w * 0.17, y + fs * 1.42, w * 0.18);
    ctx.save(); ctx.translate(x + w, y + h); ctx.rotate(Math.PI);
    corner(w * 0.17, fs * 0.98); suitPath(ctx, su, w * 0.17, fs * 1.42, w * 0.18);
    ctx.restore();
    const mx = x + w * 0.58, my = y + h * 0.55;
    if ('JQK'.indexOf(rk) >= 0) {
      const fw = w * 0.5, fh = h * 0.56;
      ctx.fillStyle = col === RED ? 'rgba(184,50,42,.1)' : 'rgba(40,30,60,.1)';
      rr(ctx, mx - fw / 2, my - fh / 2, fw, fh, 3); ctx.fill();
      ctx.strokeStyle = '#c99a3a'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = col; ctx.font = Math.round(w * 0.36) + 'px ' + DISP; ctx.textBaseline = 'middle';
      ctx.fillText(rk, mx, my - fh * 0.12);
      suitPath(ctx, su, mx, my + fh * 0.27, w * 0.16);
    } else suitPath(ctx, su, mx, my, w * (rk === 'A' ? (su === 'S' ? 0.66 : 0.56) : 0.46));
  }
  function drawCardBack(ctx, x, y, w) {
    const h = w * 1.4;
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, '#5a2d5f'); g.addColorStop(1, '#3a1b40');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.stroke();
    const ins = w * 0.09;
    ctx.save();
    rr(ctx, x + ins, y + ins, w - ins * 2, h - ins * 2, w * 0.05); ctx.clip();
    ctx.strokeStyle = 'rgba(227,174,69,.5)'; ctx.lineWidth = 1;
    const step = Math.max(4, w * 0.16);
    ctx.beginPath();
    for (let d = -h; d < w + h; d += step) { ctx.moveTo(x + d, y); ctx.lineTo(x + d + h, y + h); ctx.moveTo(x + d, y + h); ctx.lineTo(x + d + h, y); }
    ctx.stroke();
    ctx.fillStyle = '#e3ae45';
    ctx.beginPath(); const cx = x + w / 2, cy = y + h / 2, k = w * 0.16;
    ctx.moveTo(cx, cy - k); ctx.lineTo(cx + k * 0.7, cy); ctx.lineTo(cx, cy + k); ctx.lineTo(cx - k * 0.7, cy); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.2;
    rr(ctx, x + ins, y + ins, w - ins * 2, h - ins * 2, w * 0.05); ctx.stroke();
  }
  function drawCard(ctx, x, y, w, i, up, rot, glow) {
    const h = w * 1.4;
    ctx.save();
    ctx.translate(x + w / 2, y + h / 2);
    if (rot) ctx.rotate(rot);
    ctx.translate(-w / 2, -h / 2);
    if (glow) { ctx.shadowColor = glow; ctx.shadowBlur = 16; ctx.fillStyle = glow; rr(ctx, -2, -2, w + 4, h + 4, w * 0.12); ctx.fill(); }
    ctx.shadowColor = 'rgba(0,0,0,.38)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2;
    ctx.fillStyle = '#000'; rr(ctx, 0.5, 0.5, w - 1, h - 1, w * 0.1); ctx.fill();
    ctx.shadowColor = 'transparent';
    if (up && i >= 0) drawCardFace(ctx, 0, 0, w, i); else drawCardBack(ctx, 0, 0, w);
    ctx.restore();
  }
  function noiseTile() {
    const c = document.createElement('canvas'); c.width = c.height = 96;
    const x = c.getContext('2d'), d = x.createImageData(96, 96);
    for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 14; }
    x.putImageData(d, 0, 0); return c;
  }
  const ease = (t) => 1 - Math.pow(1 - t, 3);

  /* ---------- view ---------- */
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const noise = noiseTile();
    let st = null, G = null, bg = null, busy = false;
    let D = null;               // display state while animating (same shape as the state)
    let flies = [], evs = [], lift = null, jig = {}, newCard = null;
    let sel = -1, hits = [], lastId = -1, dragging = false;
    let pre = null;             // local pick shown before it is sent {id, c, at}
    let dealPending = false, dealing = false;
    let wander = { seq: -1, i: -1, next: 0 };
    let rhv = -1, lastNet = 0, mySq = 0, seenSq = {}, pubKey = '', shCool = 0;
    const spd = () => L.debug.speed || 1;
    const setBusy = (b) => { if (b !== busy) { busy = b; api.setBusy(b); } };
    const hud = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px 10px', gap: '8px', flexWrap: 'nowrap' } });
    let helpEl = null;
    const helpBtn = L.h('button', { class: 'btn sm', style: { position: 'absolute', left: '10px', top: '8px', zIndex: 5, minHeight: '34px', padding: '4px 10px', fontSize: '12px', fontWeight: 700, background: 'rgba(23,19,31,.82)' }, 'aria-label': '규칙 요약 보기', text: '요약', onclick: toggleHelp });
    function toggleHelp() {
      api.sfx('click');
      if (helpEl) { helpEl.remove(); helpEl = null; return; }
      const q = st && st.o.q;
      const li = (t) => L.h('li', { style: { margin: '3px 0' }, text: t });
      helpEl = L.h('div', { style: { position: 'absolute', inset: '0', zIndex: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '12px', background: 'rgba(10,8,15,.55)' }, onclick: toggleHelp },
        L.h('div', { class: 'panel', style: { width: '100%', maxWidth: '360px', padding: '12px 14px' } },
          L.h('div', { style: { display: 'flex', alignItems: 'center' } }, L.h('b', { style: { fontFamily: 'var(--f-display)', fontWeight: 400, fontSize: '18px' }, text: '도둑잡기 한눈에' }),
            L.h('span', { class: 'muted', style: { marginLeft: 'auto', fontSize: '11px' }, text: '누르면 닫혀요' })),
          L.h('ul', { style: { margin: '8px 0 0', paddingLeft: '18px', fontSize: '13px', lineHeight: 1.4 } },
            li('같은 숫자 2장은 짝 → 자동으로 버려요 (무늬·색 상관없음).'),
            li('내 차례: ' + (st && st.o.d < 0 ? '반시계' : '시계') + ' 방향 다음 사람 패에서 뒷면으로 1장 뽑기.'),
            li('카드를 탭하면 들어 올리고, 한 번 더 탭(또는 「뽑기」)하면 가져와요.'),
            li('패를 다 털면 안전! 털어낸 순서가 순위예요.'),
            li(q ? 'Q 한 장을 빼고 시작 — 마지막에 짝 없는 Q를 든 사람이 져요.' : '마지막까지 도둑(조커)을 든 사람이 져요.'),
            li('「섞기」로 언제든 내 패 순서를 섞어 도둑 위치를 숨겨요.'))));
      root.append(helpEl);
    }
    helpBtn.classList.add('om-help');
    root.append(hud, helpBtn);
    /* invisible boxes over canvas regions — spotlight targets for the first-play tutorial */
    const anc = {};
    function anchor(cls, x, y, w, h) {
      let el = anc[cls];
      if (!el) { el = anc[cls] = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', visibility: 'hidden' } }); root.append(el); }
      Object.assign(el.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    }

    const dS = () => D || st;
    const vwr = () => api.viewer();
    function bottomSeat() {
      const v = vwr();
      if (v >= 0) return v;
      const mine = api.mySeats();
      return mine.length ? mine[0] : 0;
    }
    const myDrawTurn = () => !!st && !st.end && api.canAct(st.t) && vwr() === st.t;
    const tgtOf = (s) => (s.end ? -1 : target(s));

    /* ---------- geometry ---------- */
    function oppSlots(k) {
      const W = G.W, ow = G.oppW, top = G.seatY0, side = G.seatY0 + 62;
      const row = (m, x0, x1) => { const out = []; const gap = m > 1 ? Math.min(ow + 16, (x1 - x0) / (m - 1)) : 0; for (let j = 0; j < m; j++) out.push({ x: (x0 + x1) / 2 + (j - (m - 1) / 2) * gap, y: top }); return out; };
      if (k <= 2) return row(k, ow / 2 + 12, W - ow / 2 - 12);
      const L1 = { x: ow / 2 + 10, y: side }, R1 = { x: W - ow / 2 - 10, y: side };
      return [L1].concat(row(k - 2, ow * 1.5 + 18, W - ow * 1.5 - 18), [R1]);
    }
    function geometry() {
      const W = cv.w, H = cv.h, tight = H < 660;
      const hudH = tight ? 62 : 70;
      const cw = Math.round(U.clamp(W * 0.14, 44, 62));
      const handY = H - hudH - cw * 1.4 - 14;
      const plateY = handY - 22;
      const oppW = Math.round(Math.min(84, (W - 16) / 5 - 4));
      G = { W, H, tight, hudH, cw, handY, plateY, oppW, seatY0: 46, cx: W / 2 };
      const k = st ? st.n - 1 : 3;
      const seatsBot = (k >= 3 ? G.seatY0 + 62 : G.seatY0) + 29 + 16;
      const zoneTop = seatsBot + 4, zoneBot = plateY - 18, zone = zoneBot - zoneTop;
      const pw = Math.round(U.clamp(W * 0.1, 34, 44)), pileH = pw * 1.4;
      let fw = Math.round(U.clamp(W * 0.17, 44, 70)); // the cards you pick from: as big as the zone allows
      fw = Math.max(36, Math.min(fw, (zone - pileH - 62) / 1.4));
      const total = pileH + 10 + 22 + 26 + fw * 1.4;
      const y0 = zoneTop + Math.max(0, (zone - total) / 2);
      G.pw = pw; G.pileY = y0; G.labelY = y0 + pileH + 10 + 11; G.fw = fw; G.fanY = G.labelY + 11 + 26;
      G.slots = oppSlots(k);
      anchor('om-fan', 12, G.labelY - 12, W - 24, G.fanY + fw * 1.4 + 10 - (G.labelY - 12));
      anchor('om-hand', 6, plateY - 14, W - 12, H - hudH - plateY + 12);
      anchor('om-bar', 4, H - hudH + 2, W - 8, hudH - 4);
    }
    function buildBg() {
      const W = cv.w, H = cv.h, dpr = cv.dpr;
      const c = document.createElement('canvas'); c.width = Math.ceil(W * dpr); c.height = Math.ceil(H * dpr);
      const x = c.getContext('2d'); x.scale(dpr, dpr);
      const pad = 6, bh = H - pad * 2 - G.hudH + 4;
      const wg = x.createLinearGradient(0, 0, W, H); wg.addColorStop(0, '#5a3720'); wg.addColorStop(1, '#3b2213');
      x.fillStyle = wg; rr(x, pad, pad, W - pad * 2, bh, 26); x.fill();
      const cy = G.fanY;
      const fg = x.createRadialGradient(W / 2, cy, 20, W / 2, cy, Math.max(W, H) * 0.7);
      fg.addColorStop(0, '#5a2a4e'); fg.addColorStop(0.55, '#41203b'); fg.addColorStop(1, '#2a1426');
      x.fillStyle = fg; rr(x, pad + 9, pad + 9, W - pad * 2 - 18, bh - 18, 18); x.fill();
      x.save(); rr(x, pad + 9, pad + 9, W - pad * 2 - 18, bh - 18, 18); x.clip();
      x.fillStyle = x.createPattern(noise, 'repeat'); x.fillRect(0, 0, W, H);
      x.restore();
      x.strokeStyle = 'rgba(227,174,69,.45)'; x.lineWidth = 1.2; rr(x, pad + 9, pad + 9, W - pad * 2 - 18, bh - 18, 18); x.stroke();
      x.strokeStyle = 'rgba(242,233,216,.07)'; x.lineWidth = 2;
      x.beginPath(); x.ellipse(W / 2, cy + G.fw * 0.5, W * 0.42, G.fw * 1.3, 0, 0, 7); x.stroke();
      bg = c;
    }
    cv.onresize = () => { geometry(); buildBg(); };

    function seatPos(seat) {
      const b = bottomSeat();
      if (seat === b) return { x: G.cx, y: G.plateY, me: true };
      const idx = ((((seat - b) * st.o.d) % st.n) + st.n) % st.n - 1; // 0 = next in turn order
      const sl = G.slots[idx] || { x: G.cx, y: G.seatY0 };
      return sl;
    }
    function rowLayout(hand, y0, cw, maxStep, arc) {
      const n = hand.length, out = [];
      if (!n) return out;
      const avail = G.W - 28 - cw;
      const step = n > 1 ? Math.min(maxStep, avail / (n - 1)) : 0;
      const tot = step * (n - 1) + cw, x0 = (G.W - tot) / 2;
      for (let k = 0; k < n; k++) {
        const off = (k - (n - 1) / 2) / Math.max(1, n);
        out.push({ ch: hand[k], x: x0 + k * step, y: y0 + Math.abs(off) * arc, rot: off * 0.2, w: cw, step, last: k === n - 1 });
      }
      return out;
    }
    const handLayout = (hand) => rowLayout(hand, G.handY + 10, G.cw, G.cw * 0.74, 10);
    const fanLayout = (hand) => rowLayout(hand, G.fanY, G.fw, G.fw * 0.8, 14);
    /* where is card idx of seat's hand drawn right now */
    function cardAt(seat, idx, hand) {
      const ds = dS();
      if (seat === bottomSeat()) { const lay = handLayout(hand); const c = lay[Math.min(idx, lay.length - 1)]; if (c) return c; return { x: G.cx - G.cw / 2, y: G.handY + 10, w: G.cw, rot: 0 }; }
      if (seat === tgtOf(ds)) { const lay = fanLayout(hand); const c = lay[Math.min(idx, lay.length - 1)]; if (c) return c; }
      const p = seatPos(seat);
      return { x: p.x - 10, y: p.y - 4, w: 20, rot: 0 };
    }
    const pilePos = () => ({ x: G.cx - G.pw / 2, y: G.pileY });

    /* ---------- render ---------- */
    function draw(now) {
      cv.clear();
      if (!G) return;
      if (bg) ctx.drawImage(bg, 0, 0, G.W, G.H);
      if (!st) return;
      hits = [];
      const ds = dS();
      drawPile(ds);
      for (let s = 0; s < st.n; s++) if (s !== bottomSeat()) drawSeat(s, ds, now);
      drawZone(ds, now);
      drawMine(ds, now);
      for (const f of flies) {
        const p = (now - f.t0) / f.dur;
        if (p < 0 || p > 1) continue;
        const e = ease(p);
        const x = U.lerp(f.x0, f.x1, e), y = U.lerp(f.y0, f.y1, e) - Math.sin(p * Math.PI) * 20, w = U.lerp(f.w0, f.w1, e);
        drawCard(ctx, x, y, w, ci(f.ch), f.up, U.lerp(f.r0 || 0, f.r1 || 0, e));
      }
    }
    function clip(t, w) {
      if (ctx.measureText(t).width <= w) return t;
      while (t.length > 1 && ctx.measureText(t + '…').width > w) t = t.slice(0, -1);
      return t + '…';
    }
    function tag(x, y, text, bgc, fg, font) {
      ctx.font = font || '600 12px ' + FONT;
      const tw = ctx.measureText(text).width + 14, h = 20;
      ctx.fillStyle = bgc; rr(ctx, x - tw / 2, y - h / 2, tw, h, h / 2); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, x, y + 1);
      return tw;
    }
    function drawPile(ds) {
      const p = pilePos(), dp = ds.dp, n = dp.length;
      if (!n) {
        ctx.strokeStyle = 'rgba(242,233,216,.22)'; ctx.setLineDash([4, 4]); rr(ctx, p.x, p.y, G.pw, G.pw * 1.4, G.pw * 0.1); ctx.stroke(); ctx.setLineDash([]);
      }
      const show = Math.min(6, n);
      for (let k = show; k >= 1; k--) {
        const j = n - k, jit = ((j * 37) % 13 - 6);
        drawCard(ctx, p.x + jit * 1.6, p.y + ((j * 17) % 7 - 3), G.pw, ci(dp[j]), true, jit * 0.04);
      }
      ctx.font = '600 12px ' + MONO;
      tag(p.x + G.pw + 46, p.y + G.pw * 0.7, '짝 ' + (n / 2 | 0) + '쌍', 'rgba(15,12,20,.78)', '#e3ae45', '700 12px ' + FONT);
    }
    function badgeOf(s, ds) {
      if (st.end && st.lose === s && !D) return [st.o.q ? '패배' : '도둑!', '#ee6a55', '#2b0c06'];
      if (ds.out[s]) return ['안전 ' + (st.rk.indexOf(s) + 1) + '위', '#e3ae45', '#2a1d05'];
      return null;
    }
    function drawSeat(s, ds, now) {
      const p = seatPos(s), pl = api.players[s] || { name: st.nm[s], color: '#888' };
      const turn = !ds.end && ds.t === s, tg = tgtOf(ds) === s;
      const hand = ds.h[s], cnt = hand.length;
      const w = G.oppW, h = 58, x = p.x - w / 2, y = p.y - h / 2;
      ctx.save();
      if (turn) { ctx.shadowColor = 'rgba(227,174,69,.6)'; ctx.shadowBlur = 14; }
      ctx.fillStyle = turn ? 'rgba(46,38,64,.96)' : 'rgba(22,17,30,.84)'; rr(ctx, x, y, w, h, 12); ctx.fill();
      ctx.restore();
      ctx.lineWidth = turn || tg ? 1.8 : 1; ctx.strokeStyle = turn ? '#e3ae45' : tg ? '#ee6a55' : 'rgba(242,233,216,.14)'; rr(ctx, x, y, w, h, 12); ctx.stroke();
      if (ds.out[s]) ctx.globalAlpha = 0.55;
      ctx.fillStyle = pl.color; ctx.beginPath(); ctx.arc(x + 10, y + 12, 4, 0, 7); ctx.fill();
      ctx.font = '700 12px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(clip(pl.name, w - 22), x + 18, y + 12.5);
      const jt = jig[s] != null ? (now - jig[s]) / (450 / spd()) : 2;
      const reveal = st.end && !D && st.lose === s;
      if (reveal && cnt) drawCard(ctx, x + 8, y + 21, 22, ci(hand[0]), true, -0.08);
      else {
        const show = Math.min(cnt, 7), bw = w < 76 ? 13 : 16, fanW = w - 14 - 26;
        const stp = show > 1 ? U.clamp((fanW - bw) / (show - 1), 2, 5) : 0;
        for (let k = 0; k < show; k++) {
          const dx = jt < 1 ? Math.sin(jt * 18 + k * 1.7) * 4 * (1 - jt) : 0;
          drawCard(ctx, x + 8 + k * stp + dx, y + 22, bw, -1, false, (k - show / 2) * 0.06);
        }
      }
      ctx.font = '700 18px ' + MONO; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'right';
      ctx.fillText(String(cnt), x + w - 7, y + 38);
      ctx.globalAlpha = 1;
      const b = badgeOf(s, ds);
      if (b) tag(p.x, y + h + 3, b[0], b[1], b[2], '700 11px ' + FONT);
      else if (turn) tag(p.x, y + h + 3, '뽑는 중', 'rgba(227,174,69,.92)', '#2a1d05', '700 11px ' + FONT);
    }
    /* which card of the target hand is being touched right now */
    function hoverIdx(now, ds) {
      if (ds.end) return -1;
      if (myDrawTurn() && !D) return sel;
      if (D) return -1;
      if (rhv >= 0) return rhv;
      if (st.ai[st.t] && !busy) {
        const m = st.h[target(st)].length;
        if (wander.seq !== st.seq) wander = { seq: st.seq, i: -1, next: now + 450 / spd() };
        if (now >= wander.next && m) { let i = U.rand(m); if (m > 1 && i === wander.i) i = (i + 1) % m; wander.i = i; wander.next = now + (320 + Math.random() * 480) / spd(); }
        return wander.i < m ? wander.i : -1;
      }
      return -1;
    }
    function drawRow(lay, seat, up, now, hv, interactive) {
      const jt = jig[seat] != null ? (now - jig[seat]) / (450 / spd()) : 2;
      lay.forEach((c, k) => {
        let dx = 0, dy = 0;
        if (jt < 1) { const a = 1 - jt; dx = Math.sin(jt * 18 + k * 1.7) * 10 * a; dy = Math.cos(jt * 14 + k) * 3 * a; }
        let lf = 0, glow = null;
        if (lift && lift.seat === seat && lift.i === k) { lf = 26; glow = 'rgba(238,106,85,.9)'; }
        else if (k === hv) { lf = interactive ? 24 : 16; glow = interactive ? 'rgba(227,174,69,.95)' : 'rgba(238,106,85,.75)'; }
        const isNew = newCard && newCard.seat === seat && newCard.ch === c.ch && now < newCard.until;
        if (isNew && !glow) glow = 'rgba(227,174,69,.7)';
        const y = c.y - lf + dy, x = c.x + dx;
        drawCard(ctx, x, y, c.w, ci(c.ch), up, c.rot, glow);
        if (interactive) hits.push({ k, x: c.x, y: y, w: c.last ? c.w : Math.max(c.step, 8), h: c.w * 1.4 + lf });
      });
    }
    function drawZone(ds, now) {
      const tg = tgtOf(ds), b = bottomSeat();
      if (ds.end) {
        if (D) return;
        const lo = st.lose;
        if (lo < 0) return;
        const w = G.fw * 1.25, ch = st.h[lo][0];
        if (ch) drawCard(ctx, G.cx - w / 2, G.fanY - 18, w, ci(ch), true, -0.06, 'rgba(238,106,85,.8)');
        tag(G.cx, G.labelY, st.o.q ? st.nm[lo] + ' 패배 · 짝 없는 Q' : '도둑은 ' + st.nm[lo] + '!', '#ee6a55', '#2b0c06', '700 14px ' + FONT);
        return;
      }
      const drawer = ds.t, me = drawer === b && vwr() === b;
      const hv = hoverIdx(now, ds);
      ctx.font = '600 12.5px ' + FONT;
      if (tg === b) {
        tag(G.cx, G.labelY, clip(st.nm[drawer] + ' ▸ 내 패에서 고르는 중', G.W - 40), 'rgba(238,106,85,.92)', '#2b0c06', '700 12.5px ' + FONT);
        // a big arrow down to my hand
        const y0 = G.labelY + 22, y1 = Math.min(G.fanY + G.fw, G.plateY - 30);
        ctx.strokeStyle = 'rgba(238,106,85,.55)'; ctx.fillStyle = 'rgba(238,106,85,.55)'; ctx.lineWidth = 3; ctx.setLineDash([6, 6]);
        ctx.beginPath(); ctx.moveTo(G.cx, y0); ctx.lineTo(G.cx, y1 - 10); ctx.stroke(); ctx.setLineDash([]);
        ctx.beginPath(); ctx.moveTo(G.cx - 9, y1 - 12); ctx.lineTo(G.cx + 9, y1 - 12); ctx.lineTo(G.cx, y1); ctx.closePath(); ctx.fill();
        return;
      }
      const interactive = me && !D && !pre && !busy;
      let txt;
      if (me) txt = sel >= 0 && interactive ? '한 번 더 탭하면 뽑아요' : st.nm[tg] + ' 패에서 한 장 고르세요';
      else txt = st.nm[drawer] + ' ▸ ' + st.nm[tg] + ' 패에서 뽑는 중';
      tag(G.cx, G.labelY, clip(txt, G.W - 40), me ? 'rgba(227,174,69,.95)' : 'rgba(16,12,22,.78)', me ? '#2a1d05' : '#d9cfe4', '700 12.5px ' + FONT);
      drawRow(fanLayout(ds.h[tg]), tg, false, now, hv, interactive);
    }
    function drawMine(ds, now) {
      const b = bottomSeat(), pl = api.players[b] || { name: st.nm[b], color: '#888' };
      const up = b === vwr() || (st.end && !D && st.lose === b);
      const hand = ds.h[b];
      const turn = !ds.end && ds.t === b, tg = tgtOf(ds) === b;
      // plate
      ctx.font = '700 13px ' + FONT;
      const name = clip(pl.name, 120), nw = ctx.measureText(name).width;
      ctx.font = '600 13px ' + MONO;
      const cnt2 = hand.length + '장', cw2 = ctx.measureText(cnt2).width;
      const badge = badgeOf(b, ds) || (turn ? ['뽑을 차례', '#e3ae45', '#2a1d05'] : tg ? ['뽑히는 중', '#ee6a55', '#2b0c06'] : null);
      const bw2 = badge ? (ctx.font = '700 11px ' + FONT, ctx.measureText(badge[0]).width + 14 + 6) : 0;
      const tw = 25 + nw + 8 + cw2 + 12 + bw2, py = G.plateY;
      const x = G.cx - tw / 2;
      ctx.fillStyle = turn ? 'rgba(46,38,64,.95)' : 'rgba(22,17,30,.8)'; rr(ctx, x, py - 13, tw, 26, 13); ctx.fill();
      ctx.lineWidth = turn || tg ? 1.6 : 1; ctx.strokeStyle = turn ? '#e3ae45' : tg ? '#ee6a55' : 'rgba(242,233,216,.15)'; ctx.stroke();
      ctx.fillStyle = pl.color; ctx.beginPath(); ctx.arc(x + 14, py, 5, 0, 7); ctx.fill();
      ctx.font = '700 13px ' + FONT; ctx.fillStyle = '#f2e9d8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(name, x + 25, py + 0.5);
      ctx.font = '600 13px ' + MONO; ctx.fillStyle = '#e3ae45'; ctx.fillText(cnt2, x + 25 + nw + 8, py + 0.5);
      if (badge) tag(x + tw - 6 - (bw2 - 6) / 2, py, badge[0], badge[1], badge[2], '700 11px ' + FONT);
      if (!hand.length && ds.out[b]) {
        ctx.font = '600 13px ' + FONT; ctx.fillStyle = 'rgba(242,233,216,.55)'; ctx.textAlign = 'center';
        ctx.fillText('패를 다 털었어요 — 안전!', G.cx, G.handY + G.cw * 0.7);
        return;
      }
      const hv = tg ? hoverIdx(now, ds) : -1;
      const lay = handLayout(hand);
      drawRow(lay, b, up, now, hv, false);
      if (tg && hv >= 0 && lay[hv] && up) {
        const c = lay[hv];
        tag(c.x + c.w / 2, c.y - 16 + c.w * 1.4 - 12, '만지는 중', '#ee6a55', '#2b0c06', '700 11px ' + FONT);
      }
    }

    /* ---------- animation helpers ---------- */
    function at(t, fn) { evs.push({ t, fn }); evs.sort((a, b) => a.t - b.t); }
    function fly(ch, from, to, up, dur) {
      flies.push({ ch, up, x0: from.x, y0: from.y, w0: from.w, r0: from.rot || 0, x1: to.x, y1: to.y, w1: to.w, r1: to.rot || 0, t0: performance.now(), dur: dur / spd() });
    }
    const cut = (str, i) => str.slice(0, i) + str.slice(i + 1);
    function stopAnim() { evs = []; flies = []; lift = null; D = null; dealing = false; }
    function endAnim() { stopAnim(); setBusy(false); renderHud(); }
    function pairFly(ds, s, a, b2) {
      const hand = ds.h[s], ia = hand.indexOf(a), ib = hand.indexOf(b2);
      const fa = cardAt(s, ia, hand), fb = cardAt(s, ib, hand), p = pilePos();
      fly(a, fa, { x: p.x - 4, y: p.y, w: G.pw, rot: -0.1 }, true, 320);
      fly(b2, fb, { x: p.x + 4, y: p.y + 2, w: G.pw, rot: 0.12 }, true, 360);
      ds.h[s] = hand.replace(a, '').replace(b2, '');
    }
    function rankWord(ch) { return RK[rankOf(ci(ch))]; }

    /* opening: deal everything, then each player throws away their pairs */
    function startDeal() {
      dealPending = false; dealing = true;
      setBusy(true);
      const s0 = st, n = s0.n, sp = spd();
      // full starting hands: the pairs slotted back in at random places (remaining order = the real order)
      const full = s0.h.map((hnd, k) => {
        const a = hnd.split('');
        for (const ch of (s0.d0 && s0.d0[k]) || '') a.splice(U.rand(a.length + 1), 0, ch);
        return a.join('');
      });
      D = Object.assign({}, s0, { h: full.map(() => ''), dp: '' });
      const now = performance.now();
      let t = now + 120 / sp;
      const cnt = full.map(() => 0), total = full.reduce((a, x) => a + x.length, 0);
      const step = Math.min(22, 900 / total);
      for (let j = 0, k = 0; j < total; k = (k + 1) % n) {
        if (cnt[k] >= full[k].length) continue;
        const seat = k, idx = cnt[k]++;
        at(t, () => {
          const ch = full[seat][idx];
          const to = cardAt(seat, idx, full[seat].slice(0, idx + 1));
          fly(ch, { x: G.cx - G.pw / 2, y: G.pileY, w: G.pw }, to, false, 220);
          if (idx % 3 === 0) api.sfx('card');
        });
        at(t + 220 / sp, () => { D.h[seat] += full[seat][idx]; });
        t += step / sp; j++;
      }
      t += 380 / sp;
      at(t, () => { api.toast('같은 숫자 짝을 버려요'); });
      t += 250 / sp;
      let maxP = 0;
      for (let k = 0; k < n; k++) {
        const d = (s0.d0 && s0.d0[k]) || '';
        maxP = Math.max(maxP, d.length / 2);
        for (let p = 0; p < d.length; p += 2) {
          const a = d[p], b2 = d[p + 1], seat = k;
          at(t + (p / 2) * 130 / sp + k * 25 / sp, () => { pairFly(D, seat, a, b2); if (seat === bottomSeat()) api.sfx('chip'); });
          at(t + (p / 2) * 130 / sp + k * 25 / sp + 340 / sp, () => { D.dp += a + b2; });
        }
      }
      t += (maxP * 130 + 400) / sp;
      at(t, () => {
        endAnim();
        if (st.end) return;
        const mine = api.canAct(st.t) && vwr() === st.t;
        api.toast(st.o.q ? '짝 없는 Q를 피하세요!' : '도둑(조커)을 피하세요!');
        if (mine) api.buzz(12);
      });
    }

    function animatePick(prev, next, skipLift) {
      const l = next.last, sp = spd(), b = bottomSeat(), v = vwr();
      D = Object.assign({}, prev, { h: prev.h.slice(), out: prev.out.slice() });
      const f = l.f, s = l.s, ch = l.c;
      const upFrom = f === b && v === b, upTo = s === b && v === b;
      setBusy(true);
      let t = performance.now();
      if (!skipLift) { lift = { seat: f, i: l.i }; api.sfx('tick'); t += 320 / sp; }
      at(t, () => {
        const from = cardAt(f, l.i, D.h[f]);
        D.h[f] = cut(D.h[f], l.i); lift = null;
        const to = cardAt(s, D.h[s].length, D.h[s] + ch);
        fly(ch, { x: from.x, y: from.y - 20, w: from.w, rot: from.rot }, to, upFrom || upTo, 320);
        api.sfx('card');
      });
      t += 320 / sp;
      at(t, () => {
        D.h[s] += ch;
        if (upTo) { newCard = { seat: s, ch, until: performance.now() + 1500 / sp }; }
        if (isBad(next, ch) && !l.pr) {
          if (upTo) { api.toast(next.o.q ? 'Q를 뽑았어요…' : '도둑을 뽑았어요…'); api.sfx('lose'); api.buzz(30); }
          else if (upFrom) { api.toast(next.o.q ? 'Q를 넘겼어요!' : '도둑을 넘겼어요!'); api.sfx('win'); api.buzz(15); }
        }
      });
      if (l.pr) {
        t += 240 / sp;
        at(t, () => { pairFly(D, s, l.pr, ch); api.sfx('chip'); api.toast(next.nm[s] + ' · ' + rankWord(ch) + ' 짝!'); });
        t += 360 / sp;
        at(t, () => { D.dp = next.dp; });
      }
      if (l.sh) {
        t += 160 / sp;
        at(t, () => { D.h[s] = next.h[s]; jig[s] = performance.now(); api.sfx('whoosh'); });
        t += 300 / sp;
      }
      t += 120 / sp;
      at(t, () => { endAnim(); outcome(next); });
    }
    function outcome(next) {
      const l = next.last;
      (l.safe || []).forEach((x, k) => setTimeout(() => {
        api.toast(next.nm[x] + ' 안전! (' + (next.rk.indexOf(x) + 1) + '위)');
        api.sfx(api.canAct(x) ? 'win' : 'pop');
      }, k * 500 / spd()));
      if (l.lose != null && l.lose >= 0) { api.sfx('thud'); api.buzz(api.canAct(l.lose) ? 40 : 0); }
    }

    /* local pick: show the result to the picker first (on a shared phone the curtain follows right after) */
    function confirmPick() {
      if (!myDrawTurn() || sel < 0 || busy || pre || D) return;
      const s0 = st, tg = target(s0), me = s0.t, i = sel;
      if (i >= s0.h[tg].length) return;
      const ch = s0.h[tg][i], sp = spd();
      pre = { id: s0.seq + 1, c: ch, at: performance.now() };
      api.sfx('card'); api.buzz(14);
      D = Object.assign({}, s0, { h: s0.h.slice(), out: s0.out.slice() });
      setBusy(true);
      const pr = isJk(ci(ch)) ? '' : s0.h[me].split('').find((x) => !isJk(ci(x)) && rankOf(ci(x)) === rankOf(ci(ch)));
      let t = performance.now();
      at(t, () => {
        const from = cardAt(tg, i, D.h[tg]);
        D.h[tg] = cut(D.h[tg], i);
        const to = cardAt(me, D.h[me].length, D.h[me] + ch);
        fly(ch, { x: from.x, y: from.y - 24, w: from.w, rot: from.rot }, to, true, 340);
      });
      t += 340 / sp;
      at(t, () => {
        D.h[me] += ch; newCard = { seat: me, ch, until: performance.now() + 1500 / sp };
        if (!pr && isBad(s0, ch)) { api.toast(s0.o.q ? 'Q를 뽑았어요…' : '도둑을 뽑았어요…'); api.sfx('lose'); api.buzz(30); }
      });
      if (pr) {
        t += 300 / sp;
        at(t, () => { pairFly(D, me, pr, ch); api.sfx('chip'); api.buzz(10); api.toast(rankWord(ch) + ' 짝! 버렸어요'); });
        t += 360 / sp;
        at(t, () => { D.dp += pr + ch; });
      }
      t += 380 / sp;
      at(t, () => {
        evs = []; flies = [];
        setBusy(false);
        sel = -1; publish();
        api.actAs(me, { t: 'p', i });
      });
      renderHud();
    }

    /* ---------- shuffle ---------- */
    function canShuffle() {
      if (!st || st.end) return false;
      const v = vwr();
      return v >= 0 && !st.out[v] && st.h[v].length >= 2 && !pre;
    }
    function doShuffle() {
      const now = performance.now();
      if (!canShuffle() || now < shCool) return;
      shCool = now + 450;
      const v = vwr();
      api.sfx('whoosh'); api.buzz(10);
      if (api.isHost) api.setState(shuffleSeat(U.clone(st), v));
      else { mySq++; jig[v] = now; publish(); }
    }
    function publish() {
      if (!api.online || !st) return;
      const o = { gid: st.gid, sq: mySq, hv: myDrawTurn() ? sel : -1, hq: st.seq };
      const k = JSON.stringify(o);
      if (k === pubKey) return;
      pubKey = k; api.net.publish(o);
    }
    function netTick(now) {
      if (!api.online || !st || now - lastNet < 110) return;
      lastNet = now;
      const r = api.net.remote() || {};
      const g = r[st.t];
      rhv = !st.end && !api.canAct(st.t) && g && g.gid === st.gid && g.hq === st.seq && typeof g.hv === 'number' ? g.hv : -1;
      if (rhv >= (st.h[target(st)] || '').length) rhv = -1;
      if (!api.isHost) return;
      // host: apply the guests' shuffle requests
      let s2 = null;
      for (const k in r) {
        const seat = +k, q = r[k], p = api.players[seat];
        if (!q || q.gid !== st.gid || typeof q.sq !== 'number' || !p || p.ai || api.canAct(seat)) continue;
        const seen = seenSq[seat] && seenSq[seat].gid === st.gid ? seenSq[seat].n : 0;
        if (q.sq > seen) {
          seenSq[seat] = { gid: st.gid, n: q.sq };
          s2 = shuffleSeat(s2 || U.clone(st), seat);
        }
      }
      if (s2) api.setState(s2);
    }

    /* ---------- input ---------- */
    function hitAt(q) {
      for (let k = hits.length - 1; k >= 0; k--) {
        const h = hits[k];
        if (q.x >= h.x && q.x <= h.x + h.w && q.y >= h.y - 6 && q.y <= h.y + h.h + 6) return h.k;
      }
      return -1;
    }
    function onDown(e) {
      if (!st || !G || !myDrawTurn() || busy || pre || D) return;
      const k = hitAt(cv.local(e));
      if (k < 0) return;
      if (k === sel) { confirmPick(); return; }
      sel = k; dragging = true;
      api.sfx('tick'); api.buzz(6); publish(); renderHud();
    }
    function onMove(e) {
      if (!dragging || !myDrawTurn() || busy || pre) return;
      const k = hitAt(cv.local(e));
      if (k >= 0 && k !== sel) { sel = k; api.sfx('tick'); api.buzz(4); publish(); renderHud(); }
    }
    function onUp() { dragging = false; }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);

    /* ---------- HUD ---------- */
    const B = (txt, cls, fn, extra) => L.h('button', { class: 'btn ' + (cls || ''), style: Object.assign({ flex: '1 1 0', minWidth: 0, minHeight: '48px', padding: '6px 8px', whiteSpace: 'nowrap', fontSize: '15px' }, extra || {}), onclick: fn }, txt);
    function renderHud() {
      hud.innerHTML = '';
      if (!st || st.end) return;
      const off = busy || !!pre || !!D;
      if (canShuffle()) {
        const b = B('섞기', 'ghost', doShuffle, { flex: myDrawTurn() ? '0 0 92px' : '0 1 180px' });
        b.setAttribute('aria-label', '내 패 순서 섞기');
        hud.append(b);
      }
      if (myDrawTurn()) {
        const b = B(sel >= 0 ? '이 카드 뽑기' : '카드를 골라요', 'primary', confirmPick);
        b.disabled = off || sel < 0;
        hud.append(b);
      }
    }

    /* ---------- loop / update ---------- */
    let lastHudKey = '';
    function frame() {
      const now = performance.now();
      while (evs.length && evs[0].t <= now) { const e = evs.shift(); try { e.fn(); } catch (err) { console.error(err); } }
      flies = flies.filter((f) => now < f.t0 + f.dur + 30);
      if (dealPending && st && !root.querySelector('.curtain')) startDeal();
      if (pre && !D && now - pre.at > 6000) { pre = null; renderHud(); }
      if (pre && D && !evs.length && now - pre.at > 6000) { pre = null; D = null; renderHud(); }
      netTick(now);
      const key = busy + '|' + !!pre + '|' + !!D;
      if (key !== lastHudKey) { lastHudKey = key; renderHud(); }
      draw(now);
    }
    const stopLoop = U.loop(frame);
    return {
      update(next, prev) {
        const isNew = prev && prev !== next;
        if (!st || st.gid !== next.gid) { mySq = 0; pubKey = ''; sel = -1; jig = {}; }
        st = next;
        geometry();
        if (!bg || !prev || (prev && prev.n !== next.n)) buildBg();
        const l = next.last, now = performance.now();
        if (l && l.id !== lastId) {
          const wasPre = pre;
          if (l.k === 's') {
            stopAnim(); setBusy(false);
            if (next.d0) dealPending = true;
          } else if (l.k === 'p') {
            if (wasPre && wasPre.id === l.id && wasPre.c === l.c) {
              stopAnim(); setBusy(false); outcome(next);
              if (l.sh) jig[l.s] = now;
            } else if (prev && prev.seq === l.id - 1) { stopAnim(); animatePick(prev, next, false); }
            else { stopAnim(); setBusy(false); }
          }
          pre = null;
        }
        if (isNew && prev.sc && next.sc) {
          let any = false;
          for (let k = 0; k < next.n; k++) if (prev.sc[k] !== next.sc[k] && !(l && l.k === 'p' && l.sh && l.s === k)) { jig[k] = now; any = true; }
          if (any && !(l && l.id !== lastId)) api.sfx('whoosh');
        }
        lastId = l ? l.id : -1;
        if (isNew && prev.seq !== next.seq) { sel = -1; }
        if (sel >= 0 && (!myDrawTurn() || sel >= next.h[target(next)].length)) sel = -1;
        publish();
        renderHud();
      },
      destroy() {
        stopLoop(); setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp); window.removeEventListener('pointercancel', onUp);
        cv.destroy(); hud.remove(); helpBtn.remove(); Object.values(anc).forEach((el) => el.remove()); if (helpEl) helpEl.remove();
      },
    };
  }

  const ICON = '<rect x="7" y="13" width="24" height="34" rx="3" fill="none" stroke="currentColor" stroke-width="3" transform="rotate(-12 19 30)"/>' +
    '<rect x="23" y="9" width="26" height="36" rx="3" fill="currentColor"/>' +
    '<path d="M26 22h20v5c0 3-4 4-6 2l-4-2-4 2c-2 2-6 1-6-2z" fill="#3a2350"/>' +
    '<circle cx="31" cy="25" r="1.6" fill="currentColor"/><circle cx="41" cy="25" r="1.6" fill="currentColor"/>' +
    '<path d="M30 34q6 5 12 0" stroke="#3a2350" stroke-width="2.4" fill="none" stroke-linecap="round"/>';

  L.register({
    id: 'oldmaid', name: '도둑잡기', tag: '카드 뽑기', cat: '카드', hidden: true,
    icon: ICON, tint: '#4a2358',
    blurb: '옆 사람 패에서 한 장씩 몰래 뽑아 같은 숫자 짝을 버려요. 마지막까지 도둑(조커)을 든 사람이 져요.',
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, aiDelay: 1200,
    options: [
      { id: 'mode', label: '카드', choices: [{ v: 'joker', label: '조커 사용' }, { v: 'queen', label: '조커 대신 Q 한 장 빼기' }], def: 'joker' },
      { id: 'dir', label: '도는 방향', choices: [{ v: 'cw', label: '시계 방향' }, { v: 'ccw', label: '반시계 방향' }], def: 'cw' },
    ],
    quick: [
      '같은 숫자 2장(짝)은 버려요. 패를 먼저 다 털면 안전!',
      '내 차례: 다음 사람 패에서 뒷면으로 1장 뽑기 → 짝이 맞으면 자동으로 버려요.',
      '마지막까지 도둑(조커)을 든 한 사람이 져요. 도둑을 들었으면 「섞기」로 숨기세요.',
    ],
    rules: [
      { h: '목표', p: [
        '같은 숫자 짝을 버려서 손패를 다 털면 안전이에요.',
        '도둑(조커)은 짝이 없어요. 마지막까지 도둑을 든 한 사람이 져요.',
        '털어낸 순서가 순위예요.'] },
      { h: '준비 (자동)', p: [
        '52장 + 조커 1장(도둑)을 모두 나눠 줘요. 사람마다 장수가 1장쯤 다를 수 있어요.',
        '모두 자기 패에서 같은 숫자 짝을 찾아 버려요. 무늬 · 색은 상관없어요.',
        '같은 숫자가 3장이면 2장만 버리고 1장은 남아요. 4장이면 모두 버려요.',
        '첫 사람은 무작위예요.'] },
      { h: '차례에 할 일', p: [
        '① 도는 방향으로 다음 사람의 패가 가운데에 뒷면으로 펼쳐져요.',
        '② 1장을 골라 뽑아요.',
        '③ 뽑은 카드와 같은 숫자가 내 패에 있으면 그 짝을 바로 버려요(자동). 없으면 내 패 오른쪽 끝에 들어가요.',
        '④ 그다음은 방금 뽑힌 사람 차례예요.',
        '패를 다 털어 안전해진 사람은 건너뛰어요.'] },
      { h: '점수·승리', p: [
        '패를 다 털면 안전 — 먼저 턴 순서대로 1위, 2위…',
        '한 명만 남으면 끝! 그 사람 손에 남은 도둑이 패배의 증거예요.'] },
      { h: '특수 규칙: 섞기', p: [
        '내 패는 언제든 「섞기」로 순서를 섞을 수 있어요. 도둑 위치를 숨기는 데 써요.',
        '새로 들어온 카드는 오른쪽 끝에 들어가니, 도둑을 받았다면 섞어 두는 게 좋아요.',
        '한 폰으로 여럿이 할 때는 섞기도 내 차례에만 할 수 있어요.'] },
      { h: '설정', p: [
        '카드: 「조커 사용」(기본) — 조커가 도둑.',
        '「조커 대신 Q 한 장 빼기」 — 조커 없이 Q 한 장을 몰래 빼고 시작해요. 그러면 Q 한 장이 짝 없이 남고, 그걸 끝까지 든 사람이 져요. 뺀 Q는 끝나고 공개돼요.',
        '도는 방향: 시계 방향(기본) / 반시계 방향. 뽑는 상대도 그 방향의 다음 사람이에요.'] },
      { h: '조작', p: [
        '가운데 뒷면 카드를 탭하면 살짝 들어 올려요. 한 번 더 탭하거나 「이 카드 뽑기」를 누르면 가져와요. 손가락을 끌면 다른 카드로 옮겨 가요.',
        '온라인에서는 내가 어느 카드를 만지는지 주인 폰에 「만지는 중」으로 실시간 보여요. 주인 표정을 살피는 게 묘미!',
        '한 폰으로 여럿이 할 때는 차례마다 가림막이 뜨고, 내 차례에만 내 패가 보여요.',
        '왼쪽 위 「요약」을 누르면 규칙 요약이 떠요.'] },
      { h: '예시', p: [
        '내 패: ♠3 · ♥7 · 도둑. 다음 사람 패에서 1장을 뽑았더니 ◆7!',
        '→ ♥7과 짝이 맞아 둘 다 버려요. 내 패는 ♠3 · 도둑, 2장이 남아요.',
        '→ 내 패는 내 앞사람(방향 반대쪽)이 뽑아 가요. 그 사람이 도둑을 뽑아 가길 바라며 「섞기」!'] },
      { h: 'AI 난이도', p: ['AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.', '뽑기는 원래 운이에요. 쉬움은 패를 섞지 않고, 보통은 도둑을 들면 가끔 섞어요.', '어려움은 자기가 넘긴 도둑이 어디 있는지 기억해 상대가 섞지 않았으면 웬만하면 피하고, 도둑을 들면 꼭 섞어요(가끔은 연막으로도 섞어요).'] },
    ],
    tutorial: [
      { sel: '.om-hand', text: '아래가 내 패예요. 같은 숫자 2장(짝)은 처음에 자동으로 버려졌어요. 무늬 · 색은 상관없어요.' },
      { sel: '.om-fan', text: '내 차례엔 다음 사람의 패가 여기 뒷면으로 펼쳐져요. 1장을 탭해 들어 올리고, 한 번 더 탭(또는 「이 카드 뽑기」)하면 가져와요.' },
      { sel: '.om-hand', text: '뽑은 카드와 같은 숫자가 내 패에 있으면 짝이 맞아 자동으로 버려요. 없으면 내 패 오른쪽 끝에 들어가요.' },
      { sel: '.om-bar', text: '도둑(조커)을 들고 있다면 「섞기」로 순서를 섞어 숨기세요. 다음 사람이 뽑아 가면 성공!' },
      { sel: '.om-help', text: '패를 다 털면 안전! 마지막까지 도둑을 든 사람이 져요. 헷갈리면 「요약」을 누르세요.' },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { ALPH, ci, cc, rankOf, discardPairs, target, active, shuffleSeat, isBad },
  });
})();
