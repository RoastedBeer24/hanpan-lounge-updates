/* 씨름 한판 — realtime Korean wrestling (1–2).
   Two wrestlers locked by the 샅바 on a sand ring, side view. Hold ◀ 당기기 / 밀기 ▶ to shift weight (yours and, through
   the 샅바, the opponent's); press 「기술」 when the opponent's balance is off the right way:
     ◀ + 기술 = 잡채기 (opponent leaning forward), ▶ + 기술 = 안다리 (opponent leaning back),
     기술 alone = 들배지기 (opponent upright and you have more 힘), 기술 while the opponent winds up = 뒤집기 (counter).
   A body part above the knee touching the sand loses the 판; 3판 2선승 by default. 2 players = 맞대결 (AI or online,
   one person per phone); 1 player = 천하장사 대회 (bracket of 4 or 8, AI gets stronger every round).
   Host-authoritative fixed-step bout (1/120 s). Guests publish {k,u,tp} (held direction + technique press counter);
   the host sends snapshots {k,q,t,f,s,x,u,w,d,c,p,ev} ~20/s. Coarse phases go through api.setState:
   br (cup bracket) → count → play → end (throw replay from st.e, slow-mo) → … → done. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;
  const TAU = Math.PI * 2;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const r2 = (v) => Math.round(v * 100) / 100;
  const r1 = (v) => Math.round(v * 10) / 10;

  /* ======================= engine (pure) ======================= */
  const H = 1 / 120;
  const THR = 0.5;        // 잡채기 needs opponent lean ≥ THR (forward), 안다리 ≤ −THR (back)
  const UPR = 0.3;        // 들배지기 needs |opponent lean| ≤ UPR
  const SHAKY = 0.2;      // a hook whose target is less than this past the line can be countered (뒤집기)
  const RATE = 1.1;       // how fast a lean follows its target (1/s)
  const LIFT_GAP = 5;     // … and my 힘 ≥ opponent 힘 − LIFT_GAP after paying the cost (= 15 more than them before)
  const CANT = 0.85;      // can't counter (뒤집기) while my own |lean| ≥ CANT
  const DANGER = 0.8, FALL_T = 1.2; // |lean| > DANGER for FALL_T s → falls by itself
  const T_REG = 50, T_END = 75;      // 50 s, then 25 s 연장 without 힘 recovery, then 판정
  const TECH = {
    jab: { n: '잡채기', u: -1, dur: 0.32, win: 0.75, cost: 10 },
    an: { n: '안다리', u: 1, dur: 0.32, win: 0.75, cost: 10 },
    deul: { n: '들배지기', u: 0, dur: 0.5, win: 0.85, cost: 20 },
    rev: { n: '뒤집기', cost: 12 },
  };
  const HOW = ['jab', 'an', 'deul', 'rev', 'fall', 'time'];
  const HOWN = { jab: '잡채기', an: '안다리', deul: '들배지기', rev: '뒤집기', fall: '넘어짐', time: '판정' };

  function newBout(ph) {
    return { t: 0, f: [0, 0], s: [100, 100], x: 0, u: [0, 0], wu: [null, null], cd: [0, 0], dz: [0, 0], pr: [0, 0], na: [0, 0], win: -1, how: '', fd: 0,
      pause: 0, ext: 0, ev: [], eid: 0, wob: ph == null ? Math.random() * 6 : ph };
  }
  const pow = (B, i) => 0.7 + 0.3 * B.s[i] / 100;
  function effU(B, i) { const w = B.wu[i]; if (w) return TECH[w[0]].u; return B.s[i] <= 0 ? 0 : B.u[i]; }
  function pushEv(B, type, seat, a) { B.eid++; B.ev.push([B.eid, type, seat, a]); if (B.ev.length > 5) B.ev.shift(); }
  function finish(B, w, how) { B.win = w; B.how = how; B.wu = [null, null]; pushEv(B, 'win', w, HOW.indexOf(how)); }
  /* target lean of seat i for inputs ui (own) / uj (opponent): push leans me forward, pulls them toward me */
  // pr: pressure (0–1) that builds while I stand still against a push/pull — a passive wrestler slowly gets moved
  function targetLean(ui, uj, pi, pj, pr) {
    const own = ui > 0 ? 0.45 : ui < 0 ? -0.3 : 0;
    const oth = uj > 0 ? -0.35 : uj < 0 ? 0.4 : 0;
    return own * pi + oth * pj / pi * (1 + 0.8 * (pr || 0));
  }
  function techOk(type, fj, si, sj) {
    if (type === 'jab') return fj >= THR;
    if (type === 'an') return fj <= -THR;
    return Math.abs(fj) <= UPR && si >= sj - LIFT_GAP;
  }
  // 뒤집기 works early in the opponent's wind-up, while I still stand (|lean| < CANT), against any 들배지기 but only
  // against a shaky hook (I'm not deep in its zone)
  function canRev(type, prog, fi) { return prog <= TECH[type].win && Math.abs(fi) < CANT && (type === 'deul' || techMargin(type, fi) < SHAKY); }
  function techMargin(type, fj) { return type === 'jab' ? fj - THR : type === 'an' ? -THR - fj : UPR - Math.abs(fj); }

  function stepBout(B, dt) {
    if (B.win !== -1) return;
    for (let i = 0; i < 2; i++) if (B.cd[i] > 0) B.cd[i] = Math.max(0, B.cd[i] - dt);
    if (B.pause > 0) { // 장외: everyone back to the centre
      B.pause -= dt;
      if (B.pause <= 0) { B.pause = 0; B.x = 0; B.f[0] = B.f[1] = 0; B.dz[0] = B.dz[1] = 0; B.pr[0] = B.pr[1] = 0; }
      return;
    }
    B.t += dt;
    const u0 = effU(B, 0), u1 = effU(B, 1), p0 = pow(B, 0), p1 = pow(B, 1);
    const k = Math.min(1, RATE * dt);
    for (let i = 0; i < 2; i++) {
      const ui = i ? u1 : u0, uj = i ? u0 : u1, pi = i ? p1 : p0, pj = i ? p0 : p1;
      const wob = 0.04 * Math.sin(B.t * 1.6 + B.wob + i * 2.1) + 0.025 * Math.sin(B.t * 3.3 + i + B.wob * 0.7);
      B.pr[i] = ui === 0 && uj !== 0 ? Math.min(1, B.pr[i] + 0.45 * dt) : Math.max(0, B.pr[i] - 1.2 * dt);
      B.f[i] += (targetLean(ui, uj, pi, pj, B.pr[i]) + wob - B.f[i]) * k;
      if (!B.wu[i]) {
        if (ui !== 0) B.s[i] -= (4 + (uj !== 0 ? 3 : 0)) * dt;
        else if (B.t < T_REG) B.s[i] += (uj === 0 ? 9 : 3) * dt;
        B.s[i] = clamp(B.s[i], 0, 100);
      }
    }
    for (let i = 0; i < 2; i++) {
      if (Math.abs(B.f[i]) > DANGER) {
        B.dz[i] += dt;
        if (B.dz[i] >= FALL_T) { B.fd = B.f[i] > 0 ? 1 : -1; finish(B, 1 - i, 'fall'); return; }
      } else B.dz[i] = Math.max(0, B.dz[i] - dt * 1.5);
    }
    B.x += 0.2 * (u0 * p0 - u1 * p1) * dt;
    if (Math.abs(B.x) >= 1) { B.x = B.x > 0 ? 1 : -1; B.pause = 1.3; B.wu = [null, null]; pushEv(B, 'out', -1, 0); return; }
    // techniques finishing their wind-up
    let best = -1, bm = -1e9;
    for (let i = 0; i < 2; i++) {
      const w = B.wu[i];
      if (!w || B.t - w[1] < TECH[w[0]].dur) continue;
      const j = 1 - i;
      if (techOk(w[0], B.f[j], B.s[i], B.s[j])) { const m = techMargin(w[0], B.f[j]); if (m > bm) { bm = m; best = i; } }
    }
    for (let i = 0; i < 2; i++) {
      const w = B.wu[i];
      if (!w || B.t - w[1] < TECH[w[0]].dur) continue;
      if (i === best) { finish(B, i, w[0]); return; }
      B.wu[i] = null;
      const j = 1 - i, why = w[0] === 'deul' && Math.abs(B.f[j]) <= UPR ? 2 : 1; // 2: 힘이 모자람, 1: 상대가 버팀
      B.s[i] = Math.max(0, B.s[i] - 8);
      if (w[0] === 'jab') B.f[i] -= 0.3; else if (w[0] === 'an') B.f[i] += 0.3;
      B.cd[i] = 0.7;
      pushEv(B, 'fail', i, HOW.indexOf(w[0]) * 10 + why);
    }
    if (B.t >= T_REG && !B.ext) { B.ext = 1; pushEv(B, 'ext', -1, 0); }
    if (B.t >= T_END) { // 판정: more techniques tried wins (적극성), then more 힘 left
      const a = B.na[0] - B.na[1], d = B.s[0] - B.s[1];
      finish(B, a ? (a > 0 ? 0 : 1) : Math.abs(d) >= 1 ? (d > 0 ? 0 : 1) : -2, 'time');
    }
  }
  /* seat i presses 기술 with its current B.u[i]. Returns a short code for feedback. */
  function pressTech(B, i) {
    if (B.win !== -1 || B.pause > 0) return 'no';
    if (B.wu[i]) return 'busy';
    const j = 1 - i, wj = B.wu[j];
    if (wj) {
      const T = TECH[wj[0]], prog = (B.t - wj[1]) / T.dur;
      if (prog >= 0.04) { // 뒤집기 (counter); a press in the same instant is a simultaneous attack instead
        if (B.cd[i] > 0) return 'cd';
        if (B.s[i] < TECH.rev.cost) { B.cd[i] = 0.4; pushEv(B, 'tired', i, 0); return 'tired'; }
        B.s[i] -= TECH.rev.cost;
        if (canRev(wj[0], prog, B.f[i])) { finish(B, i, 'rev'); return 'rev'; }
        B.cd[i] = 0.8; pushEv(B, 'revfail', i, prog > T.win ? 1 : Math.abs(B.f[i]) >= CANT ? 2 : 3);
        return 'revfail';
      }
    }
    if (B.cd[i] > 0) return 'cd';
    const ty = B.u[i] < 0 ? 'jab' : B.u[i] > 0 ? 'an' : 'deul', T = TECH[ty];
    if (B.s[i] < T.cost) { B.cd[i] = 0.4; pushEv(B, 'tired', i, 0); return 'tired'; }
    B.s[i] -= T.cost; B.wu[i] = [ty, B.t]; B.na[i]++;
    pushEv(B, 'start', i, HOW.indexOf(ty));
    return 'start';
  }

  /* ----- AI ----- */
  function gauss() { let u = 0; while (!u) u = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(TAU * Math.random()); }
  // dec: s between decisions · nz: lean misread · rx: reaction to an attack · ctr: counter chance · def: weight-shift
  // defence chance · spam: random technique · mg: attack margin · safe: |own lean| that triggers recovery · rest: 힘 to rest at
  const AIC = {
    1: { dec: 0.5, nz: 0.2, rx: 0.36, rxv: 0.3, ctr: 0.2, def: 0.3, spam: 0.08, mg: -0.04, safe: 0.72, rest: 10, lift: 0.3, read: 0.4 },
    2: { dec: 0.3, nz: 0.12, rx: 0.22, rxv: 0.14, ctr: 0.4, def: 0.6, spam: 0.02, mg: 0.06, safe: 0.56, rest: 22, lift: 0.7, read: 0.7 },
    3: { dec: 0.13, nz: 0.04, rx: 0.1, rxv: 0.08, ctr: 0.7, def: 0.9, spam: 0, mg: 0.08, safe: 0.52, rest: 28, lift: 1, read: 0.95 },
  };
  function aiStep(B, i, M, lv, sty, dt) {
    const C = AIC[lv] || AIC[2], j = 1 - i;
    if (B.win !== -1 || B.pause > 0) { B.u[i] = 0; M.tk = 0.2 + Math.random() * 0.3; return; }
    if (B.wu[i]) return;
    const wj = B.wu[j];
    if (wj) { // the opponent is attacking: counter, or shift weight against it
      if (M.wt !== wj[1]) { M.wt = wj[1]; M.ra = B.t + C.rx + Math.random() * C.rxv; M.rk = Math.random(); M.done = false; M.du = null; }
      if (!M.done && B.t >= M.ra) {
        M.done = true;
        const fi = B.f[i] + gauss() * C.nz * 0.5, would = techOk(wj[0], fi, B.s[j], B.s[i]);
        const prog = (B.t - wj[1]) / TECH[wj[0]].dur;
        const canC = B.s[i] >= TECH.rev.cost && B.cd[i] <= 0 && (lv < 3 ? Math.abs(fi) < CANT : canRev(wj[0], prog + 0.05, fi));
        if (canC && M.rk < C.ctr && (lv < 3 || would || wj[0] === 'deul')) { pressTech(B, i); return; }
        M.du = Math.random() < C.def ? (wj[0] === 'an' ? 1 : -1) : null;
      }
      if (M.du != null) B.u[i] = M.du;
      return;
    }
    M.tk = (M.tk || 0) - dt; M.hold = (M.hold || 0) - dt; M.idle = B.u[j] === 0 ? (M.idle || 0) + dt : 0;
    if (M.tk > 0) return;
    M.tk = C.dec * (0.7 + Math.random() * 0.6);
    const fo = B.f[j] + gauss() * C.nz, fs = B.f[i] + gauss() * C.nz * 0.6, uj = Math.random() < C.read ? B.u[j] : 0;
    if (B.cd[i] <= 0) {
      if (Math.random() < C.spam) { B.u[i] = U.rand(3) - 1; pressTech(B, i); return; }
      // 어려움 waits for a deep opening (no 뒤집기 possible) unless the opponent can't counter right now
      const helpless = B.s[j] < TECH.rev.cost || B.cd[j] > 0.3 || Math.abs(B.f[j]) >= CANT;
      const mg = lv === 3 && !helpless && Math.random() < 0.75 - Math.max(0, (B.t - 8) / 20) ? SHAKY + 0.03 : C.mg;
      if (fo >= THR + mg && B.s[i] >= 10) { B.u[i] = -1; pressTech(B, i); return; }
      if (fo <= -THR - mg && B.s[i] >= 10) { B.u[i] = 1; pressTech(B, i); return; }
      const sj = B.s[j] + (lv === 1 ? (Math.random() - 0.5) * 30 : 0), lead = TECH.deul.cost - LIFT_GAP + (sty === 'b' ? 2 : 8);
      if (Math.abs(fo) < UPR - 0.08 && B.s[i] >= 40 && B.s[i] >= sj + lead && Math.random() < C.lift * (sty === 'b' ? 1 : 0.6) && (lv < 3 || helpless || Math.random() < 0.03)) { B.u[i] = 0; pressTech(B, i); return; }
    }
    if (Math.abs(fs) > C.safe) { B.u[i] = fs > 0 ? -1 : 1; M.hold = 0.35; return; }
    if (M.hold > 0) return; // keep the current plan for a while
    const r = Math.random(), hold = (a, b) => { M.hold = a + Math.random() * (b - a); };
    if (B.s[i] < C.rest) { B.u[i] = 0; hold(0.8, 1.4); return; }
    if (lv >= 2 && M.idle > 1.2 && B.s[i] > 45) { B.u[i] = sty === 'd' ? -1 : 1; hold(2, 3); return; }         // lean on a passive opponent
    if (lv >= 2 && uj > 0 && Math.random() < (lv === 3 ? 0.6 : 0.35)) { B.u[i] = -1; hold(0.5, 1); return; } // let a pusher come → 잡채기
    if (lv >= 2 && uj < 0) { B.u[i] = r < 0.5 ? -1 : 0; hold(0.5, 1); return; }                               // don't push into a puller
    if (sty === 'm') B.u[i] = r < 0.7 ? 1 : r < 0.88 ? 0 : -1;
    else if (sty === 'd') B.u[i] = uj > 0 ? -1 : r < 0.5 ? 0 : r < 0.8 ? 1 : -1;
    else B.u[i] = r < 0.55 ? 0 : r < 0.8 ? 1 : -1;
    hold(0.7, 1.6);
  }

  /* ======================= coarse state ======================= */
  const NAMES = ['황소', '태산', '돌쇠', '번개', '무쇠', '바위', '곰배', '천둥', '들소', '차돌', '솔뫼', '덕배', '억새', '먹쇠'];
  const STY = { m: '밀어붙이기형', d: '끌어당기기형', b: '들배지기형' };
  const CUP_LV = { 4: [2, 3], 8: [1, 2, 3] };
  const RNAME = { 4: ['4강', '결승'], 8: ['8강', '4강', '결승'] };
  const LVN = ['', '쉬움', '보통', '어려움'];
  const SIDE = ['홍샅바', '청샅바'];
  function init(players, opts) {
    const o = opts || {}, n = Math.max(1, Math.min(2, players.length));
    const bo = [1, 3, 5].includes(o.bo) ? o.bo : 3;
    const nm = players.map((p) => String((p && p.name) || '').slice(0, 10));
    const s = { rid: 1 + U.rand(99999), n, mode: n === 1 ? 'cup' : 'vs', nm, bo, sc: [0, 0], rd: 1, m: 1, b: 1, ph: 'count', fin: -1, e: null, hw: [], res: -1,
      sy: [0, 1].map(() => 'mdb'[U.rand(3)]) };
    if (s.mode === 'cup') {
      const sz = o.cup === 4 ? 4 : 8, pool = U.shuffle(NAMES.slice());
      s.c = { sz, nm: [nm[0] || '나'].concat(pool.slice(0, sz - 1)), sty: 'm' + Array.from({ length: sz - 1 }, () => 'mdb'[U.rand(3)]).join(''), br: [], r: 0 };
      s.ph = 'br';
    }
    return s;
  }
  function entrants(c, r) { if (r === 0) return Array.from({ length: c.sz }, (_, k) => k); return c.br[r - 1] || []; }
  function cupOpp(c) { const e = entrants(c, c.r), k = e.indexOf(0); return k < 0 ? -1 : e[k ^ 1]; }
  const need = (s) => (s.bo + 1) / 2;
  function endBout(s, w, how, f, x, fd) {
    const n = U.clone(s);
    n.ph = 'end'; n.fin = w;
    n.e = { w, h: HOW.indexOf(how), f: [r2(f[0]), r2(f[1])], x: r2(x), d: fd || 0 };
    if (w >= 0) { n.sc[w]++; n.hw = (s.hw || []).concat([[w, HOW.indexOf(how)]]).slice(-5); }
    return n;
  }
  function afterBout(s) {
    const n = U.clone(s);
    const drawn = !!s.e && s.e.w === -2;
    n.fin = -1; n.e = null; n.b = (n.b || 0) + 1;
    if (n.sc[0] < need(n) && n.sc[1] < need(n)) { n.ph = 'count'; if (!drawn) n.rd++; return n; }
    const w = n.sc[0] >= need(n) ? 0 : 1;
    if (n.mode === 'vs') { n.ph = 'done'; n.res = w; return n; }
    const c = n.c, e = entrants(c, c.r), win = [];
    for (let k = 0; k + 1 < e.length; k += 2) {
      const a = e[k], b = e[k + 1];
      win.push(a === 0 || b === 0 ? (w === 0 ? 0 : (a === 0 ? b : a)) : (Math.random() < 0.5 ? a : b));
    }
    c.br[c.r] = win;
    n.ls = n.sc.slice(); n.lo = e[e.indexOf(0) ^ 1];
    if (w !== 0 || win.length === 1) { n.ph = 'done'; n.res = w; return n; }
    c.r++; n.ph = 'br'; n.sc = [0, 0]; n.rd = 1; n.m++; n.hw = [];
    return n;
  }
  function result(s) {
    if (!s || s.ph !== 'done' || (s.res !== 0 && s.res !== 1)) return null;
    const bo = s.bo === 1 ? '단판' : s.bo + '판 ' + need(s) + '선승';
    const last = s.hw && s.hw.length ? HOWN[HOW[s.hw[s.hw.length - 1][1]]] : '';
    if (s.mode === 'vs') {
      const w = s.res;
      return { winners: [w], title: (s.nm[w] || SIDE[w]) + ' 승리!',
        text: (s.nm[0] || SIDE[0]) + '(홍)  ' + s.sc[0] + ' : ' + s.sc[1] + '  ' + (s.nm[1] || SIDE[1]) + '(청)\n' + bo + (last ? ' · 마지막 기술: ' + last : '') };
    }
    const c = s.c, rn = RNAME[c.sz], sc = s.ls || s.sc, opp = c.nm[s.lo] || '상대';
    if (s.res === 0) return { winners: [0], title: '천하장사 등극!', text: c.sz + '명 대회 우승 · ' + rn.join(' → ') + ' 모두 이겼어요\n결승: ' + opp + '(' + STY[c.sty[s.lo]] + ')에게 ' + sc[0] + ' : ' + sc[1] + (last ? ' · 마지막 기술 ' + last : '') };
    const rname = rn[Math.min(rn.length - 1, c.r)];
    const champ = c.br[c.br.length - 1] && c.br[c.br.length - 1].length === 1 ? c.nm[c.br[c.br.length - 1][0]] : null;
    return { winners: [], title: rname + ' 탈락', text: opp + '(' + STY[c.sty[s.lo]] + ', ' + LVN[CUP_LV[c.sz][Math.min(c.r, CUP_LV[c.sz].length - 1)]] + ')에게 ' + sc[0] + ' : ' + sc[1] + '로 졌어요' + (champ ? '' : '') + '\n다시 도전해 보세요!' };
  }

  /* ======================= view ======================= */
  const FONT = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif';
  const MONO = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const DISP = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const SATBA = ['#d33a2c', '#2f63cc'], SATBA_L = ['#ff8a76', '#86aaff'];
  const SKIN = ['#e3b38a', '#d6a27a'], OUTL = '#3a2416', SHORTS = '#efe6d2';
  const COUNT = 2.6, END_T = 3.8, ANIM = 2.5;
  const CSS = `
.ss-ov{position:absolute;inset:0;z-index:9;display:flex;align-items:center;justify-content:center;padding:14px;background:rgba(14,10,20,.78);backdrop-filter:blur(2px)}
.ss-card{width:100%;max-width:420px;max-height:100%;overflow:auto;box-sizing:border-box;padding:16px 14px;border-radius:18px;background:linear-gradient(180deg,#2a2034,#1c1626);border:1px solid rgba(227,174,69,.45);box-shadow:0 10px 30px rgba(0,0,0,.5);color:#f2e9d8;font:14px/1.45 "IBM Plex Sans KR",system-ui,sans-serif}
.ss-card h3{margin:0 0 2px;font:400 24px "Black Han Sans",sans-serif;color:#e3ae45;letter-spacing:.5px}
.ss-card .sub{color:#ab9fb8;font-size:13px;margin-bottom:10px}
.ss-rd{margin:8px 0 2px;font:700 12px "IBM Plex Sans KR",sans-serif;color:#ab9fb8;letter-spacing:.5px}
.ss-m{display:flex;align-items:center;gap:6px;min-height:30px;padding:3px 8px;margin:3px 0;border-radius:10px;background:rgba(255,255,255,.05);font-size:13px}
.ss-m.me{background:rgba(227,174,69,.16);border:1px solid rgba(227,174,69,.5)}
.ss-m .n{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ss-m .w{color:#e3ae45;font-weight:800}.ss-m .l{color:#7d7089;text-decoration:line-through}
.ss-m .vs{color:#7d7089;font-size:11px}
.ss-opp{margin:12px 0 10px;padding:10px 12px;border-radius:12px;background:rgba(47,99,204,.18);border:1px solid rgba(134,170,255,.45)}
.ss-opp b{font:400 20px "Black Han Sans",sans-serif;color:#f2e9d8}
.ss-opp .t{color:#c9d6ff;font-size:13px}
.ss-go{width:100%;min-height:52px;border-radius:14px;border:0;background:#e3ae45;color:#17131f;font:800 17px "IBM Plex Sans KR",sans-serif;cursor:pointer;touch-action:manipulation}
.ss-go:active{transform:scale(.98)}
.ss-tip{position:absolute;left:50%;transform:translate(-50%,6px);z-index:7;width:max-content;max-width:calc(100% - 28px);box-sizing:border-box;padding:10px 14px;border-radius:14px;background:rgba(23,19,31,.96);border:1px solid rgba(227,174,69,.55);box-shadow:0 6px 20px rgba(0,0,0,.35);color:#f2e9d8;font:600 13px/1.5 "IBM Plex Sans KR",system-ui,sans-serif;text-align:center;word-break:keep-all;pointer-events:none;opacity:0;transition:opacity .4s,transform .4s}
.ss-tip.on{opacity:1;transform:translate(-50%,0)}
.ss-tip b{display:block;color:#e3ae45;font-weight:800;margin-bottom:2px}
`;
  const ease = (q) => q * q * (3 - 2 * q);
  const lerp = (a, b, q) => a + (b - a) * q;
  /* throw key frames per finish: [p, dx, dy, rot, torso] (S units; rot + = toward where the figure faces; torso null = as before) */
  const KF = {
    jab: { piv: 'f', L: [[0, 0, 0, 0, null], [0.4, 0.2, -0.02, 0.45, 1.05], [1, 0.62, 0, 1.5, 0.12]], W: [[0, 0, 0, 0, null], [0.4, -0.18, 0, -0.2, 0.45], [1, -0.22, 0, -0.08, 0.55]] },
    an: { piv: 'f', L: [[0, 0, 0, 0, null], [0.4, 0.02, 0, -0.4, 0.45], [1, 0.12, 0, -1.52, 0.06]], W: [[0, 0, 0, 0, null], [0.4, 0.14, 0, 0.12, 0.95], [1, 0.32, 0, 0.32, 1.05]] },
    deul: { piv: 'f', L: [[0, 0, 0, 0, null], [0.35, 0.22, -0.28, 0.25, 0.95], [0.62, 0.2, -0.36, -0.6, 0.4], [1, 0.05, 0, -1.52, 0.06]], W: [[0, 0, 0, 0, null], [0.35, 0, -0.03, -0.15, 0.2], [0.62, 0.04, 0, 0, 0.35], [1, 0.1, 0, 0.25, 0.7]] },
    rev: { piv: 'h', L: [[0, 0, 0, 0, null], [0.4, 0.2, -0.3, 1.35, 0.7], [1, 0.95, 0.31, 4.62, 0.08]], W: [[0, 0, 0, 0, null], [0.4, -0.05, 0.04, -0.55, 0.3], [1, 0.15, 0.02, -0.15, 0.5]] },
    fallF: { piv: 'f', L: [[0, 0, 0, 0, null], [1, 0.12, 0, 1.5, 0.12]], W: [[0, 0, 0, 0, null], [1, -0.08, 0, -0.1, 0.55]] },
    fallB: { piv: 'f', L: [[0, 0, 0, 0, null], [1, -0.06, 0, -1.52, 0.06]], W: [[0, 0, 0, 0, null], [1, 0.06, 0, 0.1, 0.8]] },
  };
  function kfAt(keys, p, baseTa) {
    const ta = (k) => (k[4] == null ? baseTa : k[4]);
    if (p <= keys[0][0]) return [keys[0][1], keys[0][2], keys[0][3], ta(keys[0])];
    for (let k = 1; k < keys.length; k++) {
      if (p <= keys[k][0] || k === keys.length - 1) {
        const a = keys[k - 1], b = keys[k], q = ease(clamp((p - a[0]) / (b[0] - a[0]), 0, 1));
        return [lerp(a[1], b[1], q), lerp(a[2], b[2], q), lerp(a[3], b[3], q), lerp(ta(a), ta(b), q)];
      }
    }
    return [0, 0, 0, baseTa];
  }
  // slow motion: quick start, long slow middle around the throw, fast landing
  function warp(u) { if (u < 0.22) return u / 0.22 * 0.38; if (u < 0.72) return 0.38 + (u - 0.22) / 0.5 * 0.47; if (u < 0.8) return 0.85 + (u - 0.72) / 0.08 * 0.15; return 1; }
  function ik(ax, ay, bx, by, l1, l2, bend) {
    let dx = bx - ax, dy = by - ay, d = Math.hypot(dx, dy);
    const mx = l1 + l2 - 0.001;
    if (d > mx) { dx *= mx / d; dy *= mx / d; d = mx; }
    if (d < 1e-3) return [ax + l1, ay];
    const a = Math.acos(clamp((l1 * l1 + d * d - l2 * l2) / (2 * l1 * d), -1, 1)), base = Math.atan2(dy, dx), ang = base + a * bend;
    return [ax + Math.cos(ang) * l1, ay + Math.sin(ang) * l1];
  }
  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16); let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }

  /* crowd roar + thump (WebAudio, follows the app sound switch) */
  const Snd = {
    ac: null, nb: null,
    on() { try { return !!U.store.get('sound', true); } catch (e) { return true; } },
    ctx() { if (!this.on()) return null; try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; } },
    noise(ac) { if (!this.nb) { const n = ac.sampleRate * 1.2, b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; this.nb = b; } return this.nb; },
    roar(v, dur) {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime, src = ac.createBufferSource(), f = ac.createBiquadFilter(), g = ac.createGain();
        src.buffer = this.noise(ac); src.loop = true; f.type = 'bandpass'; f.frequency.setValueAtTime(700, t); f.frequency.linearRampToValueAtTime(1100, t + dur * 0.4); f.Q.value = 0.7;
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.16 * v, t + 0.12); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        src.connect(f).connect(g).connect(ac.destination); src.start(t); src.stop(t + dur + 0.05);
      } catch (e) {}
    },
    thump() {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
        o.frequency.setValueAtTime(110, t); o.frequency.exponentialRampToValueAtTime(38, t + 0.25);
        g.gain.setValueAtTime(0.7, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.32); o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.34);
      } catch (e) {}
    },
    close() { try { this.ac && this.ac.close(); } catch (e) {} this.ac = null; this.nb = null; },
  };

  function mount(root, api) {
    const styleEl = L.h('style', { text: CSS });
    root.appendChild(styleEl);
    const cv = U.canvas(root), ctx = cv.ctx;
    const SPD = () => (L.debug && L.debug.speed) || 1;
    const auto = () => !!(L.debug && L.debug.autoplay);
    const host = () => !api.online || api.isHost;
    const mine = () => api.mySeats().slice(0, 1); // one person per phone
    const meSeat = () => { const m = mine(); return m.length ? m[0] : -1; };
    let st = null, key = null, B = null, phase = 'wait', cd = 0, endT = 0, acc = 0, lay = null, bg = null;
    let aiMem = [{}, {}], held = { L: 0, R: 0 }, ptrs = new Map(), tpN = 0, seenTp = {}, remU = {}, pubT = 0, hsQ = 0, lastQ = -1, lastU = 0;
    let evSeen = 0, floats = [], parts = [], flashes = [], shake = 0, anim = null, banner = null, tip = null, ov = null, ovSig = '', btnFx = { L: 0, R: 0, T: 0 };
    let dispF = [0, 0], dispX = 0, dzBuzz = 0, startFx = 0, lastE = null;

    /* ----- seats ----- */
    const cup = () => !!st && st.mode === 'cup';
    const oppIdx = () => (cup() ? cupOpp(st.c) : -1);
    function isAI(i) { if (cup()) return i === 1 || !!(api.players[0] && api.players[0].ai); const p = api.players[i]; return !p || !!p.ai; }
    function lvOf(i) { if (cup() && i === 1) { const L2 = CUP_LV[st.c.sz]; return L2[Math.min(st.c.r, L2.length - 1)]; } const p = api.players[i]; return (p && p.lv) || 2; }
    function styOf(i) { if (cup() && i === 1) return st.c.sty[oppIdx()] || 'm'; return (st && st.sy && st.sy[i]) || 'm'; }
    function nameOf(i) { if (!st) return ''; if (cup() && i === 1) return st.c.nm[oppIdx()] || '상대'; return st.nm[i] || (api.players[i] && api.players[i].name) || SIDE[i]; }
    const viewSeat = () => { const m = meSeat(); return m >= 0 ? m : 0; };
    const flip = () => (viewSeat() === 1 ? -1 : 1);
    const faceOf = (i) => (i === 0 ? 1 : -1) * flip();
    const isMine = (i) => mine().includes(i);

    /* ----- bout lifecycle ----- */
    const curKey = () => (st && st.ph !== 'br' && st.ph !== 'done' ? st.rid + '.' + st.m + '.' + st.rd + '.' + (st.b || 0) : null);
    function startBout() {
      B = newBout(); aiMem = [{}, {}]; acc = 0; floats = []; parts = []; flashes = []; anim = null; banner = null;
      evSeen = 0; lastQ = -1; dispF = [0, 0]; dispX = 0; dzBuzz = 0; startFx = 0; lastE = null;
      phase = st.ph === 'play' ? 'play' : 'count'; cd = COUNT; endT = END_T;
      if (meSeat() >= 0 && !tip && phase === 'count' && lay) tip = firstTip();
    }
    function firstTip() {
      try { if (localStorage.getItem('lounge.tip.ssireum')) return null; localStorage.setItem('lounge.tip.ssireum', '1'); } catch (e) { /* storage blocked: show anyway */ }
      const el = L.h('div', { class: 'ss-tip', role: 'status', style: { top: Math.round(lay.aTop + 8) + 'px' } },
        L.h('b', { text: '처음이라면 이렇게!' }),
        L.h('div', { text: '◀ ▶ 누르고 있기 = 무게 옮기기' }),
        L.h('div', { text: '아래 상대 바늘이 칸에 들어가면' }),
        L.h('div', { text: '그 방향을 누른 채 기술!' }),
        L.h('div', { text: '기술 버튼이 빨개지면 바로 탭 = 뒤집기' }));
      root.appendChild(el);
      requestAnimationFrame(() => el.classList.add('on'));
      let gone = false;
      const hide = () => { if (gone) return; gone = true; el.classList.remove('on'); setTimeout(() => el.remove(), 450); };
      const tm = setTimeout(hide, 8000);
      return { hide, remove() { clearTimeout(tm); gone = true; el.remove(); } };
    }

    /* ----- layout ----- */
    function layout() {
      const W = cv.w, Hh = cv.h, playing = meSeat() >= 0;
      const hudH = 60, panelH = playing ? Math.round(clamp(Hh * 0.3, 190, 214)) : 84;
      const aTop = hudH, aBot = Hh - panelH, aH = Math.max(120, aBot - aTop);
      const gy = aTop + aH * 0.8;
      const rx = Math.min(W * 0.49, aH * 1.5), ry = rx * 0.17;
      const S = Math.max(70, Math.min(W * 0.5, aH * 0.64, 300));
      const pw = Math.min(W - 24, 460), px = (W - pw) / 2;
      lay = { W, H: Hh, hudH, panelH, aTop, aBot, aH, gy, cx: W / 2, rx, ry, S, playing, pw, px };
      if (playing) {
        const top = aBot + 4;
        lay.og = { x: px, y: top + 16, w: pw, h: 24 };       // opponent gauge
        lay.mg = { x: px, y: top + 62, w: pw, h: 12 };       // my gauge
        lay.hy = top + 90;                                  // hint line
        const by0 = top + 104, bh = Math.max(56, Hh - 10 - by0), d = Math.min(96, bh, pw * 0.3);
        const cyb = by0 + bh / 2, sw = (pw - d - 20) / 2, sh = Math.min(66, bh);
        lay.bL = { x: px, y: cyb - sh / 2, w: sw, h: sh };
        lay.bR = { x: px + pw - sw, y: cyb - sh / 2, w: sw, h: sh };
        lay.bT = { x: W / 2, y: cyb, r: d / 2 };
      } else {
        const top = aBot + 6;
        lay.sg = [{ x: px, y: top + 18, w: pw / 2 - 8, h: 12 }, { x: px + pw / 2 + 8, y: top + 18, w: pw / 2 - 8, h: 12 }];
        lay.hy = top + 56;
      }
      bg = null;
    }
    cv.onresize = () => { if (st) layout(); };

    /* ----- input ----- */
    function localU() {
      let l = held.L, r = held.R;
      if (api.input) { if (api.input.held('pull')) l = 1; if (api.input.held('push')) r = 1; }
      // I'm always drawn on the left, so ◀ = 당기기 (lean back), ▶ = 밀기 (lean in)
      return (r ? 1 : 0) - (l ? 1 : 0);
    }
    function hit(p) {
      if (!lay || !lay.playing) return null;
      const T = lay.bT; if (Math.hypot(p.x - T.x, p.y - T.y) <= T.r + 8) return 'T';
      const inR = (b) => p.x >= b.x - 6 && p.x <= b.x + b.w + 6 && p.y >= b.y - 14 && p.y <= b.y + b.h + 14;
      if (inR(lay.bL)) return 'L';
      if (inR(lay.bR)) return 'R';
      return null;
    }
    function refreshHeld() { held.L = 0; held.R = 0; for (const z of ptrs.values()) { if (z === 'L') held.L = 1; else if (z === 'R') held.R = 1; } }
    function techPress() {
      const s = meSeat();
      if (s < 0 || !st || !B) return;
      btnFx.T = 1;
      if (tip) tip.hide();
      if (st.ph !== 'play' || phase !== 'play') { if (st.ph === 'count' || st.ph === 'play') say(s, '아직!', '#ab9fb8'); return; }
      if (host()) {
        if (!B.wu[s]) B.u[s] = localU();
        const r = pressTech(B, s);
        if (r === 'cd') { say(s, '잠깐!', '#ab9fb8'); api.buzz(5); } else if (r !== 'busy' && r !== 'no') api.buzz(r === 'rev' ? 40 : 14);
      } else { tpN++; pubT = 0; api.buzz(10); }
    }
    function onDown(e) {
      if (!st) return;
      const p = cv.local(e), z = hit(p);
      if (!z) return;
      e.preventDefault();
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      ptrs.set(e.pointerId, z);
      if (z === 'T') { techPress(); return; }
      refreshHeld(); btnFx[z] = 1; api.buzz(6);
      if (tip && st.ph === 'play') tip.hide();
    }
    function onMove(e) {
      const z0 = ptrs.get(e.pointerId);
      if (!z0 || z0 === 'T') return;
      const z = hit(cv.local(e));
      if ((z === 'L' || z === 'R') && z !== z0) { ptrs.set(e.pointerId, z); refreshHeld(); }
    }
    function onUp(e) { if (ptrs.delete(e.pointerId)) refreshHeld(); }
    const offIn = api.input ? api.input.on((type, id) => { if (type === 'down' && id === 'tech') techPress(); }) : null;
    const releaseAll = () => { ptrs.clear(); refreshHeld(); };
    const noCtx = (e) => e.preventDefault();
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onUp);
    cv.cv.addEventListener('lostpointercapture', onUp);
    cv.cv.addEventListener('contextmenu', noCtx);
    window.addEventListener('blur', releaseAll);

    /* ----- feedback ----- */
    function say(i, txt, col, big) { floats.push({ i, txt, col, t: 0, T: big ? 1.5 : 1.1, big: !!big }); if (floats.length > 6) floats.shift(); }
    function onEvent(e) {
      const type = e[1], i = e[2], a = e[3];
      if (type === 'start') {
        say(i, TECH[HOW[a]].n + '!', SATBA_L[i], true); api.sfx('whoosh');
        if (isMine(i)) api.buzz(18); else if (meSeat() >= 0) api.buzz([12, 30, 12]);
      } else if (type === 'fail') {
        say(1 - i, a % 10 === 2 ? '힘이 모자라요' : '버텼다!', '#f2e9d8'); api.sfx('chip');
        if (isMine(i)) api.buzz(30);
      } else if (type === 'revfail') { say(i, a === 1 ? '뒤집기 늦었어요' : a === 2 ? '휘청여서 못 뒤집어요' : '깊이 걸려 못 뒤집어요', '#ab9fb8'); api.sfx('chip'); }
      else if (type === 'tired') { say(i, '힘이 없어요', '#ee6a55'); if (isMine(i)) api.buzz(8); }
      else if (type === 'out') { say(-1, '장외!', '#e3ae45', true); api.sfx('tick'); }
      else if (type === 'ext') { say(-1, '연장!', '#e3ae45', true); api.sfx('tick'); }
    }
    function flushEvents() { if (!B) return; for (const e of B.ev) if (e[0] > evSeen) { evSeen = e[0]; onEvent(e); } }

    /* ----- host / online ----- */
    function hostFlow(dt) {
      if (!host() || !st) return;
      if (st.ph === 'br') { if (meSeat() < 0) { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(Object.assign({}, st, { ph: 'count' })); } } return; }
      if (st.ph === 'count' && phase === 'play') { api.setState(Object.assign({}, st, { ph: 'play' })); return; }
      if (st.ph === 'play' && B && B.win !== -1) { api.setState(endBout(st, B.win, B.how || 'time', B.f, B.x, B.fd)); return; }
      if (st.ph === 'end') { endT -= dt; if (endT <= 0) { endT = 1e9; api.setState(afterBout(st)); } }
    }
    function pollHost() {
      if (!api.online || !api.isHost) return;
      let rem = null; try { rem = api.net.remote(); } catch (e) { rem = null; }
      if (!rem || typeof rem !== 'object') return;
      for (const k in rem) {
        const s = +k, o = rem[k];
        if (!(s === 0 || s === 1) || isAI(s) || isMine(s) || !o) continue;
        if (o.k === key) remU[s] = o.u > 0 ? 1 : o.u < 0 ? -1 : 0;
        const tp = o.tp | 0;
        if (seenTp[s] == null) seenTp[s] = tp;
        if (tp > seenTp[s]) {
          seenTp[s] = tp;
          if (o.k === key && B && st.ph === 'play' && phase === 'play') { if (!B.wu[s]) B.u[s] = remU[s] || 0; pressTech(B, s); }
        }
      }
    }
    function pollGuest(dt) {
      if (!api.online || api.isHost || !B) return;
      let hs = null; try { hs = api.net.hostState(); } catch (e) { hs = null; }
      if (hs && typeof hs === 'object' && hs.k === key && hs.q !== lastQ && Array.isArray(hs.f)) {
        lastQ = hs.q;
        B.t = +hs.t || 0; B.f = [+hs.f[0] || 0, +hs.f[1] || 0]; B.x = +hs.x || 0; B.pause = +hs.p || 0;
        if (Array.isArray(hs.s)) B.s = [+hs.s[0] || 0, +hs.s[1] || 0];
        if (Array.isArray(hs.u)) B.u = [hs.u[0] | 0, hs.u[1] | 0];
        if (Array.isArray(hs.d)) B.dz = [+hs.d[0] || 0, +hs.d[1] || 0];
        if (Array.isArray(hs.c)) B.cd = [+hs.c[0] || 0, +hs.c[1] || 0];
        if (Array.isArray(hs.w)) B.wu = hs.w.map((w) => (Array.isArray(w) && TECH[HOW[w[0]]] && HOW[w[0]] !== 'rev' ? [HOW[w[0]], +w[1] || 0] : null));
        if (Array.isArray(hs.ev)) B.ev = hs.ev.filter((e) => Array.isArray(e) && e.length >= 4);
        B.ext = B.t >= T_REG ? 1 : 0;
      } else if (phase === 'play' && st.ph === 'play' && !(B.pause > 0)) B.t += dt;
    }
    function publish(rdt) {
      if (!api.online || !B) return;
      pubT -= rdt;
      try {
        if (api.isHost) {
          if (pubT > 0) return; pubT = 1 / 20;
          hsQ = (hsQ + 1) % 100000;
          api.net.hostSend({ k: key, q: hsQ, t: r2(B.t), f: [r2(B.f[0]), r2(B.f[1])], s: [r1(B.s[0]), r1(B.s[1])], x: r2(B.x), u: B.u.slice(),
            w: B.wu.map((w) => (w ? [HOW.indexOf(w[0]), r2(w[1])] : 0)), d: [r2(B.dz[0]), r2(B.dz[1])], c: [r2(B.cd[0]), r2(B.cd[1])], p: r2(B.pause), ev: B.ev.slice(-4) });
        } else {
          const s = meSeat(); if (s < 0) return;
          const u = auto() ? (aiMem[s].gu || 0) : localU();
          if (u === lastU && pubT > 0) return;
          lastU = u; pubT = 0.25;
          api.net.publish({ k: key, u, tp: tpN });
        }
      } catch (e) {}
    }

    /* ----- main loop ----- */
    function frame(rdt) {
      const dt = rdt * SPD();
      syncOverlay();
      if (B && phase === 'count' && (st.ph === 'count' || st.ph === 'play')) {
        const a = Math.ceil(cd / (COUNT / 3)); cd -= dt; const b = Math.ceil(cd / (COUNT / 3));
        if (b !== a && b > 0) api.sfx('tick');
        if (cd <= 0 && (host() || st.ph === 'play')) { phase = 'play'; startFx = 1; api.sfx('pop'); api.buzz(25); Snd.roar(0.5, 1.2); }
      }
      if (host()) {
        pollHost();
        if (B && phase === 'play' && st.ph === 'play' && B.win === -1) {
          for (let i = 0; i < 2; i++) {
            if (isAI(i) || (isMine(i) && auto()) || B.wu[i]) continue;
            B.u[i] = isMine(i) ? localU() : (remU[i] || 0);
          }
          acc += Math.min(dt, 0.5);
          let n = 0;
          while (acc >= H && n < 120 && B.win === -1) {
            for (let i = 0; i < 2; i++) if (isAI(i) || (isMine(i) && auto())) aiStep(B, i, aiMem[i], isAI(i) ? lvOf(i) : 2, styOf(i), H);
            stepBout(B, H); acc -= H; n++;
          }
        }
        hostFlow(dt);
      } else if (B) {
        pollGuest(dt);
        if (auto() && meSeat() >= 0 && phase === 'play' && st.ph === 'play') { // test autoplay on a guest: think like an AI, send the input
          const s = meSeat(), C = Object.assign({}, B, { u: B.u.slice(), s: B.s.slice(), f: B.f.slice(), wu: B.wu.slice(), cd: B.cd.slice(), na: [0, 0], ev: [], eid: 0 });
          aiStep(C, s, aiMem[s], 2, 'm', dt);
          aiMem[s].gu = C.u[s];
          if (C.ev.some((x) => x[1] === 'start' || x[1] === 'win' || x[1] === 'revfail')) { tpN++; pubT = 0; }
        }
      }
      flushEvents();
      if (B) { // smooth display (guests get ~20 snapshots/s)
        const k = host() ? 1 : Math.min(1, rdt * 14);
        dispF[0] += (B.f[0] - dispF[0]) * k; dispF[1] += (B.f[1] - dispF[1]) * k; dispX += (B.x - dispX) * k;
      }
      const m = meSeat();
      if (B && m >= 0 && phase === 'play' && st.ph === 'play' && B.dz[m] > 0.05) { dzBuzz -= rdt; if (dzBuzz <= 0) { dzBuzz = 0.35; api.buzz(10); } } else dzBuzz = 0;
      if (anim) {
        const before = anim.t; anim.t += rdt * Math.min(SPD(), 3);
        const pb = warp(before / ANIM), pa = warp(anim.t / ANIM);
        if (!anim.imp && pa >= 0.97 && pb < 0.97 && anim.e.w >= 0 && HOW[anim.e.h] !== 'time') { anim.imp = true; impact(); }
        if (!anim.ban && anim.t / ANIM > (anim.e.w >= 0 && HOW[anim.e.h] !== 'time' ? 0.8 : 0.1)) { anim.ban = true; showBanner(); }
      }
      for (let i = floats.length - 1; i >= 0; i--) { floats[i].t += rdt; if (floats[i].t > floats[i].T) floats.splice(i, 1); }
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t -= rdt; q.x += q.vx * rdt; q.y += q.vy * rdt; q.vy += 260 * rdt; q.vx *= 0.97; if (q.t <= 0) parts.splice(i, 1); }
      for (let i = flashes.length - 1; i >= 0; i--) { flashes[i].t -= rdt; if (flashes[i].t <= 0) flashes.splice(i, 1); }
      if (banner) banner.age += rdt;
      shake = Math.max(0, shake - rdt * 2.5);
      startFx = Math.max(0, startFx - rdt * 1.6);
      for (const z of ['L', 'R', 'T']) btnFx[z] = Math.max(0, btnFx[z] - rdt * 4);
      publish(rdt);
    }
    function impact() {
      const e = anim.e, P = poses(e, 1), lp = P[1 - e.w], tx = lp.hx2;
      for (let k = 0; k < 26; k++) { const a = -Math.PI * (0.1 + Math.random() * 0.8); parts.push({ x: tx + (Math.random() - 0.5) * lay.S * 0.6, y: lay.gy - 2, vx: Math.cos(a) * (60 + Math.random() * 160), vy: Math.sin(a) * (80 + Math.random() * 170), t: 0.6 + Math.random() * 0.5, r: 1.5 + Math.random() * 2.5 }); }
      shake = 1; api.sfx('thud'); Snd.thump(); Snd.roar(1, 2.4);
      for (let k = 0; k < 9; k++) flashes.push({ x: Math.random() * lay.W, y: lay.aTop + lay.aH * (0.12 + Math.random() * 0.42), t: 0.2 + Math.random() * 0.9 });
      const m = meSeat();
      if (m >= 0) api.buzz(m === e.w ? [40, 40, 80] : 120);
    }
    function showBanner() {
      const e = anim.e, how = HOW[e.h];
      if (e.w === -2) { banner = { t1: '무승부', t2: '같은 판을 다시 해요', col: '#f2e9d8', age: 0 }; return; }
      banner = { t1: how === 'time' ? '판정승' : HOWN[how] + '!', t2: SIDE[e.w] + ' ' + nameOf(e.w) + ' 한 판!', col: SATBA_L[e.w], age: 0 };
      const m = meSeat();
      if (m >= 0) api.sfx(m === e.w ? 'win' : 'lose');
    }

    /* ----- overlay: tournament bracket ----- */
    function syncOverlay() {
      const want = !!st && st.ph === 'br' && cup();
      const sig = want ? st.rid + '.' + st.c.r + '.' + (meSeat() >= 0) : '';
      if (sig === ovSig) return;
      ovSig = sig;
      if (ov) { ov.remove(); ov = null; }
      if (!want) return;
      const c = st.c, rn = RNAME[c.sz], card = L.h('div', { class: 'ss-card' });
      card.append(L.h('h3', { text: '천하장사 대회' }), L.h('div', { class: 'sub', text: c.sz + '명 토너먼트 · ' + (st.bo === 1 ? '단판' : st.bo + '판 ' + need(st) + '선승') + ' · 이길수록 상대가 강해져요' }));
      for (let r = 0; r <= c.r; r++) {
        const e = entrants(c, r), win = c.br[r];
        card.append(L.h('div', { class: 'ss-rd', text: rn[r] + (r === c.r ? ' · 지금' : '') }));
        for (let k = 0; k + 1 < e.length; k += 2) {
          const a = e[k], b = e[k + 1], w = win ? win[k >> 1] : -1;
          const nm = (x) => L.h('span', { class: w < 0 ? '' : w === x ? 'w' : 'l', text: (x === 0 ? '★ ' : '') + c.nm[x] });
          card.append(L.h('div', { class: 'ss-m' + (a === 0 || b === 0 ? ' me' : '') }, L.h('span', { class: 'n' }, nm(a), L.h('span', { class: 'vs', text: '  vs  ' }), nm(b))));
        }
      }
      const o = cupOpp(c), lv = CUP_LV[c.sz][c.r];
      card.append(L.h('div', { class: 'ss-opp' },
        L.h('div', { class: 't', text: rn[c.r] + ' 상대 · ' + SIDE[1] }), L.h('b', { text: c.nm[o] }),
        L.h('div', { class: 't', text: STY[c.sty[o]] + ' · 실력 ' + LVN[lv] })));
      if (host() && meSeat() >= 0) {
        card.append(L.h('button', { class: 'ss-go', type: 'button', text: c.r === 0 ? '대회 시작 ▶' : '다음 경기 ▶', onclick() { if (!st || st.ph !== 'br') return; api.sfx('click'); api.buzz(15); api.setState(Object.assign({}, st, { ph: 'count' })); } }));
      } else card.append(L.h('div', { class: 'sub', text: '곧 시작해요…' }));
      ov = L.h('div', { class: 'ss-ov' }, card);
      ov.addEventListener('pointerdown', (e) => e.stopPropagation());
      root.appendChild(ov);
      endT = 2.2;
    }

    /* ----- poses ----- */
    function basePose(i, f, x, kneel, now, u) {
      const S = lay.S, face = faceOf(i), pcx = lay.cx + x * lay.rx * 0.62 * flip();
      const bob = u ? Math.sin(now / 95 + i * 1.7) * 0.008 * S : 0;
      const hx = pcx - face * 0.25 * S + face * f * 0.07 * S;
      const hy = lay.gy - (0.41 - 0.15 * kneel) * S + bob;
      return { i, face, S, hx, hy, ta: 0.8 + 0.3 * f + kneel * 0.2, ffx: hx + face * (0.11 - kneel * 0.08) * S, fbx: hx - face * (0.25 + kneel * 0.02) * S, fy: lay.gy, rot: 0, pvx: 0, pvy: 0, hand: null };
    }
    function shoulderOf(P) { const TL = 0.33 * P.S; return [P.hx + Math.sin(P.ta) * TL * P.face, P.hy - Math.cos(P.ta) * TL]; }
    function tf(P, x, y) { if (!P.rot) return [x, y]; const a = P.rot * P.face, c = Math.cos(a), s = Math.sin(a), dx = x - P.pvx, dy = y - P.pvy; return [P.pvx + dx * c - dy * s, P.pvy + dx * s + dy * c]; }
    function itf(P, x, y) { if (!P.rot) return [x, y]; const a = -P.rot * P.face, c = Math.cos(a), s = Math.sin(a), dx = x - P.pvx, dy = y - P.pvy; return [P.pvx + dx * c - dy * s, P.pvy + dx * s + dy * c]; }
    // both wrestlers' poses now (e = finished bout to replay, pOverride = force throw progress)
    function poses(e, pOverride, now, noCam) {
      now = now || 0;
      const kneel = !e && phase === 'count' ? clamp((cd - COUNT * 0.3) / (COUNT * 0.55), 0, 1) : 0;
      const thrown = !!e && e.w >= 0 && HOW[e.h] !== 'time';
      const pp = thrown ? (pOverride != null ? pOverride : anim ? warp(anim.t / ANIM) : 1) : 0;
      // during a throw the pair slides toward the middle and the final pile is centred (so nobody lands off screen)
      const ff = e ? e.f : dispF, xx = e ? e.x * (1 - 0.8 * ease(clamp(pp / 0.5, 0, 1))) : dispX;
      const cam = thrown && !noCam ? camFor(e) * ease(clamp(pp / 0.8, 0, 1)) : 0;
      const P = [0, 1].map((i) => {
        const P0 = basePose(i, ff[i], xx, kneel, now, B && !e ? B.u[i] : 0);
        if (cam) { P0.hx += cam; P0.ffx += cam; P0.fbx += cam; }
        if (!e && B && B.wu[i]) { // wind-up flavour
          const w = B.wu[i], q = clamp((B.t - w[1]) / TECH[w[0]].dur, 0, 1);
          if (w[0] === 'jab') { P0.ta -= 0.25 * q; P0.hx -= P0.face * 0.05 * P0.S * q; }
          else if (w[0] === 'an') { P0.ffx += P0.face * 0.2 * P0.S * q; P0.ta += 0.12 * q; }
          else { P0.hy += 0.05 * P0.S * Math.sin(q * Math.PI); P0.ta -= 0.35 * q; }
        }
        return P0;
      });
      if (!e && B) for (let i = 0; i < 2; i++) { const w = B.wu[i]; if (w && w[0] === 'deul') { const q = clamp((B.t - w[1]) / TECH.deul.dur, 0, 1), o = P[1 - i]; o.hy -= 0.06 * o.S * q; o.fy -= 0.05 * o.S * q; } }
      if (e && e.w >= 0 && HOW[e.h] !== 'time') {
        const how = HOW[e.h], K = KF[how === 'fall' ? (e.d > 0 ? 'fallF' : 'fallB') : how] || KF.an;
        const p = pp, w = e.w, l = 1 - w;
        for (const [who, keys] of [[l, K.L], [w, K.W]]) {
          const Q = P[who], v = kfAt(keys, p, Q.ta), S = Q.S;
          Q.hx += v[0] * S * Q.face; Q.ffx += v[0] * S * Q.face; Q.fbx += v[0] * S * Q.face; Q.hy += v[1] * S; Q.ta = v[3];
          if (K.piv === 'h') { Q.pvx = Q.hx; Q.pvy = Q.hy; } else { Q.pvx = (Q.ffx + Q.fbx) / 2; Q.pvy = Q.fy; Q.fy += v[1] * S; }
          Q.rot = v[2];
        }
        P[l].lost = p > (how === 'deul' ? 0.6 : 0.45); P[w].won = p;
      }
      for (let i = 0; i < 2; i++) {
        const Q = P[i], O = P[1 - i];
        Q.hx2 = tf(Q, Q.hx, Q.hy)[0];
        if (Q.lost) { const sh = shoulderOf(Q); Q.hand = [sh[0] + Q.face * 0.22 * Q.S, sh[1] - 0.12 * Q.S]; }
        else if (Q.won != null && Q.won > 0.75) Q.hand = [Q.hx + Q.face * 0.16 * Q.S, Q.hy - 0.02 * Q.S];
        else { const t = tf(O, O.hx, O.hy - 0.03 * O.S); Q.hand = itf(Q, t[0], t[1]); }
      }
      return P;
    }

    const camCache = { e: null, v: 0 };
    function camFor(e) { // x shift that centres the final pose of a throw
      if (camCache.e === e) return camCache.v;
      const P = poses(e, 1, 0, true);
      let lo = 1e9, hi = -1e9;
      for (const Q of P) {
        const sh = shoulderOf(Q), pts = [[Q.hx, Q.hy], sh, [sh[0] + Math.sin(Q.ta) * Q.face * 0.16 * Q.S, sh[1] - Math.cos(Q.ta) * 0.16 * Q.S], [Q.ffx, Q.fy], [Q.fbx, Q.fy]];
        for (const pt of pts) { const t = tf(Q, pt[0], pt[1]); lo = Math.min(lo, t[0]); hi = Math.max(hi, t[0]); }
      }
      camCache.e = e; camCache.v = clamp(lay.cx - (lo + hi) / 2, -lay.W * 0.3, lay.W * 0.3);
      return camCache.v;
    }

    /* ----- drawing ----- */
    function limb(g, pts, w, col) {
      g.beginPath(); g.moveTo(pts[0], pts[1]); for (let k = 2; k < pts.length; k += 2) g.lineTo(pts[k], pts[k + 1]);
      g.lineWidth = w + 3; g.strokeStyle = OUTL; g.stroke();
      g.lineWidth = w; g.strokeStyle = col; g.stroke();
    }
    function drawFig(g, P, side, glow) {
      const S = P.S, f = P.face, skin = SKIN[side], dark = shade(skin, -0.22);
      g.save();
      if (P.rot) { g.translate(P.pvx, P.pvy); g.rotate(P.rot * f); g.translate(-P.pvx, -P.pvy); }
      g.lineCap = 'round'; g.lineJoin = 'round';
      const TL = 0.33 * S, sh = shoulderOf(P), hip = [P.hx, P.hy];
      const l1 = 0.245 * S, l2 = 0.25 * S, a1 = 0.19 * S, a2 = 0.19 * S, lw = 0.085 * S, aw = 0.064 * S;
      const kneeF = ik(hip[0], hip[1], P.ffx, P.fy, l1, l2, -f), kneeB = ik(hip[0] - f * 0.02 * S, hip[1], P.fbx, P.fy, l1, l2, -f);
      let hand = P.hand || [sh[0] + f * 0.2 * S, sh[1] + 0.2 * S];
      { const dx = hand[0] - sh[0], dy = hand[1] - sh[1], d = Math.hypot(dx, dy), mx = (a1 + a2) * 0.98; if (d > mx) hand = [sh[0] + dx / d * mx, sh[1] + dy / d * mx]; }
      const shB = [sh[0] - f * 0.03 * S, sh[1] + 0.01 * S];
      const elB = ik(shB[0], shB[1], hand[0] - f * 0.02 * S, hand[1] + 0.02 * S, a1, a2, f), elF = ik(sh[0], sh[1], hand[0], hand[1], a1, a2, f);
      if (glow) { g.shadowColor = glow; g.shadowBlur = 14; }
      // back leg + back arm (darker)
      limb(g, [hip[0], hip[1], kneeB[0], kneeB[1], P.fbx, P.fy - 0.02 * S], lw, dark);
      limb(g, [P.fbx, P.fy - 0.02 * S, P.fbx + f * 0.07 * S, P.fy - 0.01 * S], lw * 0.7, dark);
      limb(g, [shB[0], shB[1], elB[0], elB[1], hand[0] - f * 0.02 * S, hand[1] + 0.02 * S], aw, dark);
      g.shadowBlur = 0;
      // torso
      const nx = Math.sin(P.ta) * f, ny = -Math.cos(P.ta), px = -ny, py = nx;
      const hw = 0.085 * S, sw = 0.1 * S;
      g.beginPath();
      g.moveTo(hip[0] + px * hw * f, hip[1] + py * hw * f);
      g.quadraticCurveTo(hip[0] + nx * TL * 0.5 + px * hw * 1.35 * f, hip[1] + ny * TL * 0.5 + py * hw * 1.35 * f, sh[0] + px * sw * f, sh[1] + py * sw * f);
      g.lineTo(sh[0] - px * sw * 0.8 * f, sh[1] - py * sw * 0.8 * f);
      g.quadraticCurveTo(hip[0] + nx * TL * 0.5 - px * hw * 1.1 * f, hip[1] + ny * TL * 0.5 - py * hw * 1.1 * f, hip[0] - px * hw * f, hip[1] - py * hw * f);
      g.closePath();
      if (glow) { g.shadowColor = glow; g.shadowBlur = 16; }
      g.lineWidth = 3; g.strokeStyle = OUTL; g.stroke(); g.shadowBlur = 0;
      const tg = g.createLinearGradient(hip[0] - px * hw * f, hip[1] - py * hw * f, hip[0] + px * hw * f, hip[1] + py * hw * f);
      tg.addColorStop(0, shade(skin, -0.15)); tg.addColorStop(1, shade(skin, 0.08));
      g.fillStyle = tg; g.fill();
      // shorts + 샅바 waist band
      limb(g, [hip[0], hip[1], lerp(hip[0], kneeF[0], 0.5), lerp(hip[1], kneeF[1], 0.5)], lw * 1.25, SHORTS);
      limb(g, [hip[0] - px * hw * 0.95 * f, hip[1] - py * hw * 0.95 * f + 0.01 * S, hip[0] + px * hw * 0.95 * f, hip[1] + py * hw * 0.95 * f + 0.01 * S], 0.055 * S, SATBA[side]);
      // head
      const hc = [sh[0] + nx * 0.085 * S + f * 0.02 * S, sh[1] + ny * 0.085 * S - 0.01 * S], hr = 0.072 * S;
      g.beginPath(); g.arc(hc[0], hc[1], hr, 0, TAU); g.fillStyle = skin; g.fill(); g.lineWidth = 2.5; g.strokeStyle = OUTL; g.stroke();
      g.beginPath(); g.arc(hc[0], hc[1], hr * 0.97, f > 0 ? Math.PI * 0.95 : -Math.PI * 0.75, f > 0 ? Math.PI * 1.75 : -Math.PI * 0.05); g.lineTo(hc[0], hc[1]); g.closePath();
      g.fillStyle = '#231710'; g.fill();
      g.fillStyle = OUTL; g.beginPath(); g.arc(hc[0] + f * hr * 0.45, hc[1] + hr * 0.05, Math.max(1, hr * 0.12), 0, TAU); g.fill();
      // front leg (with 샅바 thigh loop) + foot
      limb(g, [hip[0], hip[1], kneeF[0], kneeF[1], P.ffx, P.fy - 0.02 * S], lw, skin);
      limb(g, [P.ffx, P.fy - 0.02 * S, P.ffx + f * 0.07 * S, P.fy - 0.01 * S], lw * 0.7, skin);
      limb(g, [hip[0], hip[1], lerp(hip[0], kneeF[0], 0.48), lerp(hip[1], kneeF[1], 0.48)], lw * 1.2, SHORTS);
      const tq = 0.36, tx = lerp(hip[0], kneeF[0], tq), ty = lerp(hip[1], kneeF[1], tq), lx = kneeF[0] - hip[0], ly = kneeF[1] - hip[1], ll = Math.hypot(lx, ly) || 1;
      limb(g, [tx - ly / ll * lw * 0.75, ty + lx / ll * lw * 0.75, tx + ly / ll * lw * 0.75, ty - lx / ll * lw * 0.75], 0.05 * S, SATBA[side]);
      // front arm
      limb(g, [sh[0], sh[1], elF[0], elF[1], hand[0], hand[1]], aw, skin);
      g.restore();
    }
    function buildBg() {
      const W = lay.W, Hh = lay.H, dpr = cv.dpr || 1;
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(W * dpr)); c.height = Math.max(1, Math.round(Hh * dpr));
      const g = c.getContext('2d'); g.scale(dpr, dpr);
      const { aTop, aBot, gy, cx, rx, ry } = lay;
      const hg = g.createLinearGradient(0, 0, 0, aBot);
      hg.addColorStop(0, '#140f1c'); hg.addColorStop(0.45, '#2a1c2a'); hg.addColorStop(1, '#3b2718');
      g.fillStyle = hg; g.fillRect(0, 0, W, Hh);
      // crowd stands (seeded so it never jumps)
      let sd = 7; const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
      const y0 = aTop + lay.aH * 0.08, y1 = gy - ry - lay.S * 0.02;
      for (let yy = y0, r = 0; yy < y1 && r < 40; r++) {
        const k = (yy - y0) / Math.max(1, y1 - y0), sz = 5 + k * 8, gap = sz * 1.75;
        g.fillStyle = 'rgba(0,0,0,' + (0.12 + k * 0.18) + ')'; g.fillRect(0, yy + sz * 0.9, W, sz * 0.9);
        yy += sz * 2.05;
        for (let x = -gap * rnd(); x < W + gap; x += gap * (0.8 + rnd() * 0.4)) {
          const hx = ['#5a4058', '#4b3a52', '#6a4a46', '#3f3a55', '#584a3c'][Math.floor(rnd() * 5)], dk = -0.35 + k * 0.2, yj = yy + rnd() * 3;
          g.fillStyle = shade(hx, dk); g.beginPath(); g.ellipse(x, yj + sz * 1.25, sz * 0.95, sz * 0.75, 0, Math.PI, 0); g.fill();
          g.fillStyle = shade(hx, dk - 0.2); g.beginPath(); g.arc(x, yj + sz * 0.15, sz * 0.5, 0, TAU); g.fill();
        }
      }
      // hanging banners
      const bw = Math.min(40, W * 0.1), bh = Math.min(lay.aH * 0.24, 150);
      for (const [bx, col, t] of [[W * 0.06, '#7c1d15', '씨름'], [W * 0.94 - bw, '#173a7e', '한판']]) {
        g.fillStyle = col; g.beginPath(); g.moveTo(bx, aTop - 4); g.lineTo(bx + bw, aTop - 4); g.lineTo(bx + bw, aTop + bh); g.lineTo(bx + bw / 2, aTop + bh - 10); g.lineTo(bx, aTop + bh); g.closePath(); g.fill();
        g.strokeStyle = 'rgba(227,174,69,.7)'; g.lineWidth = 2; g.stroke();
        g.fillStyle = '#f2e9d8'; g.font = Math.round(bw * 0.5) + 'px ' + DISP; g.textAlign = 'center'; g.textBaseline = 'middle';
        for (let k = 0; k < t.length; k++) g.fillText(t[k], bx + bw / 2, aTop + bh * 0.3 + k * bw * 0.62);
      }
      // spotlight
      const sp = g.createRadialGradient(cx, gy - lay.S * 0.4, 10, cx, gy - lay.S * 0.2, Math.max(rx, lay.aH) * 1.05);
      sp.addColorStop(0, 'rgba(255,226,170,.22)'); sp.addColorStop(1, 'rgba(255,226,170,0)');
      g.fillStyle = sp; g.fillRect(0, aTop, W, aBot - aTop);
      g.fillStyle = '#2b1d14'; g.fillRect(0, gy - ry * 0.4, W, aBot - (gy - ry * 0.4));
      // sand ring (모래판): rim, sand, inner line, speckles
      g.save();
      g.beginPath(); g.ellipse(cx, gy + ry * 0.12, rx + 6, ry + 6, 0, 0, TAU); g.fillStyle = '#6b4322'; g.fill();
      g.beginPath(); g.ellipse(cx, gy + ry * 0.05, rx + 2, ry + 2, 0, 0, TAU); g.fillStyle = '#c58a4b'; g.fill();
      g.beginPath(); g.ellipse(cx, gy, rx - 4, ry - 3, 0, 0, TAU);
      const sg = g.createRadialGradient(cx, gy - ry * 0.3, 4, cx, gy, rx);
      sg.addColorStop(0, '#f0d39a'); sg.addColorStop(0.7, '#d9b371'); sg.addColorStop(1, '#b98f55');
      g.fillStyle = sg; g.fill(); g.clip();
      for (let k = 0; k < 420; k++) { const a = rnd() * TAU, r = Math.sqrt(rnd()); g.fillStyle = rnd() < 0.5 ? 'rgba(120,80,40,.25)' : 'rgba(255,245,220,.28)'; g.fillRect(cx + Math.cos(a) * rx * r, gy + Math.sin(a) * ry * r, 1.6, 1.2); }
      g.strokeStyle = 'rgba(255,248,230,.35)'; g.lineWidth = 2; g.beginPath(); g.ellipse(cx, gy, rx * 0.7, ry * 0.7, 0, 0, TAU); g.stroke();
      g.restore();
      // bottom panel
      g.fillStyle = '#17131f'; g.fillRect(0, aBot, W, Hh - aBot);
      g.fillStyle = 'rgba(227,174,69,.35)'; g.fillRect(0, aBot, W, 1.5);
      bg = c;
    }
    function txt(t, x, y, col, font, al, lw) { ctx.font = font; ctx.textAlign = al || 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round'; if (lw !== 0) { ctx.lineWidth = lw || 4; ctx.strokeStyle = 'rgba(12,8,16,.85)'; ctx.strokeText(t, x, y); } ctx.fillStyle = col; ctx.fillText(t, x, y); }
    function rr(x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, Math.max(0, Math.min(r, w / 2, h / 2))); else ctx.rect(x, y, w, h); }
    function fitText(t, maxW, font) { ctx.font = font; if (ctx.measureText(t).width <= maxW) return t; while (t.length > 1 && ctx.measureText(t + '…').width > maxW) t = t.slice(0, -1); return t + '…'; }

    function draw(now) {
      if (!lay) layout();
      if (!bg) buildBg();
      cv.clear();
      const { W, H: Hh } = lay;
      ctx.drawImage(bg, 0, 0, W, Hh);
      if (!st) return;
      const e = st.ph === 'end' && st.e ? st.e : st.ph === 'done' || st.ph === 'br' ? lastE : null;
      let z = 1, slow = 0;
      if (anim && e && e.w >= 0 && HOW[e.h] !== 'time') { const u = anim.t / ANIM; slow = u < 0.22 ? u / 0.22 : u < 0.72 ? 1 : Math.max(0, 1 - (u - 0.72) / 0.2); z = 1 + 0.14 * ease(slow); }
      const sx = (Math.random() - 0.5) * shake * 8, sy = (Math.random() - 0.5) * shake * 6;
      ctx.save();
      ctx.beginPath(); ctx.rect(0, lay.aTop, W, lay.aBot - lay.aTop); ctx.clip();
      if (z !== 1 || shake) {
        const fx = lay.cx + (e ? e.x : dispX) * lay.rx * 0.62 * flip(), fy = lay.gy - lay.S * 0.3;
        ctx.translate(fx + sx, fy + sy); ctx.scale(z, z); ctx.translate(-fx, -fy);
        ctx.drawImage(bg, 0, 0, W, Hh);
      }
      for (const fl of flashes) { const a = Math.min(1, fl.t * 3); ctx.fillStyle = 'rgba(255,255,240,' + (0.85 * a) + ')'; ctx.beginPath(); ctx.arc(fl.x, fl.y, 2.5 + 5 * a, 0, TAU); ctx.fill(); }
      if (B || e) {
        const P = poses(e, null, now);
        for (const Q of P) { const w = Q.S * (Q.rot && Math.abs(Q.rot) > 1 ? 0.42 : 0.28); ctx.fillStyle = 'rgba(60,35,15,.35)'; ctx.beginPath(); ctx.ellipse(Q.hx2, lay.gy + 2, w, lay.S * 0.035, 0, 0, TAU); ctx.fill(); }
        const vs = viewSeat(), order = [1 - vs, vs];
        if (e && e.w >= 0) { order[0] = HOW[e.h] === 'rev' ? e.w : 1 - e.w; order[1] = 1 - order[0]; }
        for (const i of order) {
          let glow = null;
          if (!e && B && B.wu[i]) glow = SATBA_L[i];
          else if (!e && B && B.dz[i] > 0.05 && Math.sin(now / 70) > 0) glow = '#ee6a55';
          drawFig(ctx, P[i], i, glow);
        }
        if (!e && B && phase === 'play' && Math.random() < 0.25) for (let i = 0; i < 2; i++) if (B.u[i] && Math.random() < 0.4) { const Q = P[i]; parts.push({ x: Q.fbx, y: lay.gy - 2, vx: -Q.face * (20 + Math.random() * 50), vy: -30 - Math.random() * 50, t: 0.35, r: 1.4 }); }
        for (const q of parts) { ctx.fillStyle = 'rgba(232,200,140,' + Math.min(1, q.t * 2.5) + ')'; ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, TAU); ctx.fill(); }
        const stack = {};
        for (let q = floats.length - 1; q >= 0; q--) {
          const fl = floats[q], a = Math.min(1, (fl.T - fl.t) * 4), Q = fl.i >= 0 ? P[fl.i] : null, n = stack[fl.i] = (stack[fl.i] || 0) + 1;
          const x = Q ? clamp(Q.hx2, 70, W - 70) : lay.cx, y = (Q ? lay.gy - lay.S * 0.92 : lay.aTop + lay.aH * 0.34) - fl.t * 16 - (n - 1) * 28;
          ctx.globalAlpha = a; txt(fl.txt, x, y, fl.col, fl.big ? Math.round(clamp(lay.S * 0.16, 20, 30)) + 'px ' + DISP : '700 14px ' + FONT); ctx.globalAlpha = 1;
        }
      }
      ctx.restore();
      if (slow > 0) { const bh = 22 * ease(slow); ctx.fillStyle = '#000'; ctx.fillRect(0, lay.aTop, W, bh); ctx.fillRect(0, lay.aBot - bh, W, bh); }
      drawHud();
      drawCenter();
      if (lay.playing) drawPanel(now); else drawSpecPanel();
    }
    function drawCenter() {
      const cx = lay.cx, y = lay.aTop + Math.max(44, lay.aH * 0.2);
      if (B && phase === 'count' && (st.ph === 'count' || st.ph === 'play')) {
        const k = cd / COUNT, t = k > 0.55 ? '샅바 잡고…' : k > 0.12 ? '준비…' : '시작!';
        txt(t, cx, y, k > 0.12 ? '#f2e9d8' : '#ffe27a', Math.round(clamp(lay.W * 0.09, 26, 40)) + 'px ' + DISP);
        txt(st.rd + '판 · ' + (st.bo === 1 ? '단판' : st.bo + '판 ' + need(st) + '선승'), cx, y + 32, '#ab9fb8', '700 13px ' + FONT);
      }
      if (startFx > 0) { ctx.globalAlpha = startFx; txt('시작!', cx, y, '#ffe27a', Math.round(clamp(lay.W * 0.1, 28, 44)) + 'px ' + DISP); ctx.globalAlpha = 1; }
      if (B && B.pause > 0 && st.ph === 'play') txt('장외 — 가운데에서 다시', cx, y + 4, '#e3ae45', '700 16px ' + FONT);
      if (banner && (st.ph === 'end' || st.ph === 'done')) {
        const a = Math.min(1, banner.age * 4), s = 1 + Math.max(0, 0.25 - banner.age) * 1.5;
        ctx.globalAlpha = a;
        ctx.save(); ctx.translate(cx, y); ctx.scale(s, s);
        txt(banner.t1, 0, 0, banner.col, Math.round(clamp(lay.W * 0.12, 30, 54)) + 'px ' + DISP, 'center', 6);
        ctx.restore();
        txt(banner.t2, cx, y + 40, '#f2e9d8', '700 15px ' + FONT);
        ctx.globalAlpha = 1;
      }
    }
    function drawHud() {
      const W = lay.W, half = Math.min(W / 2 - 40, 230);
      const vs = viewSeat();
      if (B && st.ph !== 'br' && st.ph !== 'done') {
        const t = B.t, ext = t >= T_REG, left = ext ? T_END - t : T_REG - t, sec = Math.max(0, Math.ceil(left));
        txt((ext ? '연장 ' : '') + Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'), W / 2, 18, ext ? '#ee6a55' : '#f2e9d8', '700 ' + (ext ? 13 : 16) + 'px ' + MONO, 'center', 3);
        txt(st.rd + '판', W / 2, 40, '#ab9fb8', '700 12px ' + FONT, 'center', 3);
      }
      [vs, 1 - vs].forEach((i, k) => {
        const left = k === 0, x0 = left ? 8 : W - 8 - half, y0 = 6, w = half;
        rr(x0, y0, w, 48, 12); ctx.fillStyle = 'rgba(23,19,31,.8)'; ctx.fill();
        ctx.lineWidth = 1.5; ctx.strokeStyle = SATBA[i]; ctx.stroke();
        const chipX = left ? x0 + 8 : x0 + w - 8 - 28;
        rr(chipX, y0 + 7, 28, 17, 5); ctx.fillStyle = SATBA[i]; ctx.fill();
        ctx.font = '800 11px ' + FONT; ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(i ? '청' : '홍', chipX + 14, y0 + 16);
        const nmMax = w - 28 - 22 - need(st) * 11;
        const nm = fitText(nameOf(i) + (isMine(i) ? ' (나)' : ''), nmMax, '700 13px ' + FONT);
        ctx.fillStyle = '#f2e9d8'; ctx.textAlign = left ? 'left' : 'right';
        ctx.fillText(nm, left ? x0 + 42 : x0 + w - 42, y0 + 16);
        for (let q = 0; q < need(st); q++) {
          const dx = left ? x0 + w - 10 - q * 11 : x0 + 10 + q * 11;
          ctx.beginPath(); ctx.arc(dx, y0 + 16, 4, 0, TAU); ctx.fillStyle = q < st.sc[i] ? '#e3ae45' : 'rgba(255,255,255,.15)'; ctx.fill();
        }
        const sv = B ? B.s[i] : 100, bx = x0 + 26, bw = w - 34, by = y0 + 32;
        ctx.font = '700 10px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'left'; ctx.fillText('힘', x0 + 9, by + 4);
        rr(bx, by, bw, 8, 4); ctx.fillStyle = 'rgba(255,255,255,.1)'; ctx.fill();
        const fw = bw * clamp(sv / 100, 0, 1);
        if (fw > 0.5) { rr(left ? bx : bx + bw - fw, by, fw, 8, 4); ctx.fillStyle = sv < 20 ? '#ee6a55' : sv < 45 ? '#e3ae45' : '#6fd29a'; ctx.fill(); }
      });
    }
    // gauge: lean v in [−1.12, 1.12] → x
    const gx = (G, v) => G.x + G.w / 2 + clamp(v, -1.12, 1.12) / 1.12 * (G.w / 2 - 6);
    function drawPanel(now) {
      const m = meSeat(), o = 1 - m, G = lay.og, M = lay.mg;
      const live = !!B && st.ph === 'play' && phase === 'play' && B.win === -1;
      const foS = -dispF[o]; // the opponent's forward lean points at me (screen left)
      ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText('상대 무게중심', G.x, G.y - 9);
      ctx.textAlign = 'right'; ctx.fillText(G.w < 330 ? '바늘 칸 = 걸 기술' : '바늘이 들어간 칸 = 걸 기술', G.x + G.w, G.y - 9);
      rr(G.x, G.y, G.w, G.h, 8); ctx.fillStyle = 'rgba(255,255,255,.06)'; ctx.fill();
      const liftOk = !!B && B.s[m] - TECH.deul.cost >= B.s[o] - LIFT_GAP;
      const zones = [
        { a: -1.12, b: -THR, lab: '◀ 잡채기', on: foS <= -THR, deep: foS <= -THR - SHAKY, ok: true },
        { a: -UPR, b: UPR, lab: liftOk ? '들배지기' : '들배지기 힘↓', on: Math.abs(foS) <= UPR, deep: true, ok: liftOk },
        { a: THR, b: 1.12, lab: '안다리 ▶', on: foS >= THR, deep: foS >= THR + SHAKY, ok: true },
      ];
      for (const zn of zones) {
        const x0 = gx(G, zn.a), x1 = gx(G, zn.b), act = zn.on && zn.ok && live;
        rr(x0 + 1, G.y + 2, x1 - x0 - 2, G.h - 4, 6);
        ctx.fillStyle = act ? (zn.deep ? 'rgba(255,214,102,.85)' : 'rgba(227,174,69,.5)') : zn.ok ? 'rgba(227,174,69,.14)' : 'rgba(255,255,255,.04)'; ctx.fill();
        ctx.font = '800 ' + (G.w < 330 ? 11 : 12) + 'px ' + FONT; ctx.textAlign = 'center'; ctx.fillStyle = act ? '#17131f' : zn.ok ? '#e8d7b0' : '#7d7089';
        ctx.fillText(zn.lab, (x0 + x1) / 2, G.y + G.h / 2 + 0.5);
      }
      const nx = gx(G, foS);
      ctx.fillStyle = SATBA_L[o];
      ctx.beginPath(); ctx.moveTo(nx, G.y + G.h + 1); ctx.lineTo(nx - 7, G.y + G.h + 10); ctx.lineTo(nx + 7, G.y + G.h + 10); ctx.closePath(); ctx.fill();
      ctx.fillRect(nx - 1.5, G.y - 2, 3, G.h + 4);
      // my gauge (danger at both ends)
      ctx.font = '700 11px ' + FONT; ctx.fillStyle = '#ab9fb8'; ctx.textAlign = 'left'; ctx.fillText('내 무게중심', M.x, M.y - 8);
      ctx.textAlign = 'right'; ctx.fillText('빨간 칸에 오래 있으면 넘어져요', M.x + M.w, M.y - 8);
      rr(M.x, M.y, M.w, M.h, 6); ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fill();
      for (const s of [-1, 1]) { const x0 = gx(M, s * DANGER), x1 = gx(M, s * 1.12); rr(Math.min(x0, x1), M.y, Math.abs(x1 - x0), M.h, 5); ctx.fillStyle = 'rgba(238,106,85,.45)'; ctx.fill(); }
      const mx = gx(M, dispF[m]), dz = B ? B.dz[m] : 0;
      ctx.beginPath(); ctx.arc(mx, M.y + M.h / 2, 7, 0, TAU); ctx.fillStyle = dz > 0.05 && Math.sin(now / 60) > 0 ? '#ee6a55' : SATBA_L[m]; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#17131f'; ctx.stroke();
      const h = hint();
      txt(fitText(h.t, lay.pw, '700 13px ' + FONT), lay.cx, lay.hy, h.c, '700 13px ' + FONT, 'center', 3);
      // buttons
      const u = localU(), rev = live && !!B.wu[o] && !B.wu[m];
      drawBtn(lay.bL, '◀ 당기기', u < 0, btnFx.L);
      drawBtn(lay.bR, '밀기 ▶', u > 0, btnFx.R);
      const T = lay.bT, ty = rev ? 'rev' : u < 0 ? 'jab' : u > 0 ? 'an' : 'deul';
      const ready = live && !B.wu[m] && !(B.cd[m] > 0);
      ctx.beginPath(); ctx.arc(T.x, T.y, T.r, 0, TAU);
      const base = rev ? '#ee6a55' : '#e3ae45', tg = ctx.createRadialGradient(T.x - T.r * 0.3, T.y - T.r * 0.4, 4, T.x, T.y, T.r);
      tg.addColorStop(0, shade(base, 0.35)); tg.addColorStop(1, shade(base, -0.25));
      ctx.fillStyle = ready || rev ? tg : '#4a3f55'; ctx.fill();
      ctx.lineWidth = 3; ctx.strokeStyle = btnFx.T > 0 ? '#fff' : 'rgba(23,19,31,.8)'; ctx.stroke();
      if (rev) { // counter window ring
        const w = B.wu[o], q = clamp((B.t - w[1]) / (TECH[w[0]].dur * TECH[w[0]].win), 0, 1);
        ctx.beginPath(); ctx.arc(T.x, T.y, T.r + 6, -Math.PI / 2, -Math.PI / 2 + TAU * (1 - q)); ctx.lineWidth = 5; ctx.strokeStyle = '#ffe27a'; ctx.stroke();
      }
      txt('기술', T.x, T.y - 9, ready || rev ? '#17131f' : '#ab9fb8', Math.round(clamp(T.r * 0.46, 18, 24)) + 'px ' + DISP, 'center', 0);
      ctx.font = '800 12px ' + FONT; ctx.fillStyle = ready || rev ? '#2a1a08' : '#8d819a'; ctx.textAlign = 'center'; ctx.fillText(TECH[ty].n, T.x, T.y + 14);
    }
    function drawBtn(b, label, on, fx) {
      rr(b.x, b.y, b.w, b.h, 16);
      ctx.fillStyle = on ? 'rgba(227,174,69,.9)' : fx > 0 ? 'rgba(227,174,69,.3)' : 'rgba(255,255,255,.08)'; ctx.fill();
      ctx.lineWidth = 1.5; ctx.strokeStyle = 'rgba(227,174,69,.6)'; ctx.stroke();
      ctx.font = '800 15px ' + FONT; ctx.fillStyle = on ? '#17131f' : '#f2e9d8'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(label, b.x + b.w / 2, b.y + b.h / 2);
    }
    function hint() {
      const m = meSeat(), o = 1 - m;
      if (!B || !st || st.ph === 'end' || st.ph === 'done' || st.ph === 'br') return { t: '', c: '#ab9fb8' };
      if (st.ph !== 'play' || phase !== 'play') return { t: '◀ ▶ 누르고 있기 = 무게 옮기기 · 기술 = 한 번 탭', c: '#ab9fb8' };
      if (B.pause > 0) return { t: '장외 — 가운데에서 다시 시작해요', c: '#e3ae45' };
      if (B.wu[o]) {
        const w = B.wu[o];
        return canRev(w[0], (B.t - w[1]) / TECH[w[0]].dur + 0.05, B.f[m]) && !(B.cd[m] > 0) ? { t: '상대 ' + TECH[w[0]].n + '! 지금 「기술」 = 뒤집기', c: '#ffe27a' }
          : { t: '상대 ' + TECH[w[0]].n + '! ' + (w[0] === 'an' ? '밀기 ▶로' : '◀ 당기기로') + ' 버티세요', c: '#ee6a55' };
      }
      if (B.wu[m]) return { t: TECH[B.wu[m][0]].n + ' 거는 중…', c: '#f2e9d8' };
      if (B.dz[m] > 0.05) return { t: '휘청! ' + (B.f[m] > 0 ? '◀ 당겨서' : '▶ 밀어서') + ' 중심을 잡으세요', c: '#ee6a55' };
      if (B.s[m] < 15) return { t: '힘이 없어요 — 손을 떼고 잠깐 쉬어요', c: '#ee6a55' };
      if (B.ext) return { t: '연장: 판정은 기술을 더 많이 건 쪽이 이겨요', c: '#e3ae45' };
      if (B.pr[m] > 0.5) return { t: '밀리고 있어요 — 가만히 있지 말고 버티세요', c: '#e3ae45' };
      return { t: '상대 바늘이 칸에 들어가면 그 방향 + 기술!', c: '#ab9fb8' };
    }
    function drawSpecPanel() {
      for (let i = 0; i < 2; i++) {
        const G = lay.sg[i], f = dispF[i] * faceOf(i);
        ctx.font = '700 11px ' + FONT; ctx.fillStyle = SATBA_L[i]; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
        ctx.fillText(fitText(nameOf(i) + ' 무게중심', G.w, '700 11px ' + FONT), G.x, G.y - 9);
        rr(G.x, G.y, G.w, G.h, 6); ctx.fillStyle = 'rgba(255,255,255,.07)'; ctx.fill();
        for (const s of [-1, 1]) { const x0 = gx(G, s * DANGER), x1 = gx(G, s * 1.12); rr(Math.min(x0, x1), G.y, Math.abs(x1 - x0), G.h, 5); ctx.fillStyle = 'rgba(238,106,85,.4)'; ctx.fill(); }
        ctx.beginPath(); ctx.arc(gx(G, f), G.y + G.h / 2, 6, 0, TAU); ctx.fillStyle = SATBA_L[i]; ctx.fill();
      }
      txt(api.online ? '관전 중' : 'AI끼리 씨름 중', lay.cx, lay.hy, '#ab9fb8', '700 13px ' + FONT, 'center', 3);
    }

    const stopLoop = U.loop((rdt, now) => {
      if (!st) return;
      try { frame(rdt, now); } catch (e) { console.error(e); }
      try { draw(now); } catch (e) { console.error(e); }
    });

    return {
      update(next) {
        if (!next) return;
        const prev = st; st = next;
        if (!lay) layout();
        const k = curKey();
        if (k && k !== key) { key = k; startBout(); }
        if (!k) key = null;
        if (st.ph === 'play' && phase === 'count' && !host()) { phase = 'play'; cd = 0; startFx = 1; }
        if (st.ph === 'end' && (!prev || prev.ph !== 'end') && st.e) {
          endT = END_T; anim = { e: st.e, t: 0, imp: false, ban: false }; banner = null; floats = []; lastE = st.e;
          if (B && !host()) B.win = st.e.w;
          releaseAll();
        }
        if (st.ph === 'br') endT = 2.2;
        if (st.ph === 'done' && tip) { tip.remove(); tip = null; }
        syncOverlay();
      },
      destroy() {
        stopLoop();
        cv.cv.removeEventListener('pointerdown', onDown);
        cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp);
        cv.cv.removeEventListener('pointercancel', onUp);
        cv.cv.removeEventListener('lostpointercapture', onUp);
        cv.cv.removeEventListener('contextmenu', noCtx);
        window.removeEventListener('blur', releaseAll);
        if (offIn) offIn();
        if (ov) ov.remove();
        if (tip) tip.remove();
        styleEl.remove(); cv.destroy(); Snd.close();
      },
      _dbg: () => ({ B, st, phase, lay, held, techPress, anim, dispF }),
    };
  }

  L.register({
    id: 'ssireum', name: '씨름 한판', tag: '샅바 힘겨루기', cat: '스포츠',
    blurb: '샅바를 잡고 밀고 당기다 상대가 쏠리는 순간 「기술」! 잡채기·안다리·들배지기·뒤집기로 모래판에 먼저 눕히면 한 판. 혼자면 천하장사 대회. 친구와는 온라인·LAN 방으로.',
    tint: '#7a3a1c',
    icon: '<ellipse cx="28" cy="47" rx="24" ry="5" fill="none" stroke="currentColor" stroke-width="2.6"/><circle cx="22" cy="13" r="5" fill="currentColor"/><circle cx="34" cy="13" r="5" fill="currentColor"/><path d="M12 44l5-11 6-12" stroke="currentColor" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M44 44l-5-11-6-12" stroke="currentColor" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M17 31h22" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><path d="M9 44h6M41 44h6" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>',
    minPlayers: 1, maxPlayers: 2, defaultPlayers: 2, hidden: false, realtime: true, aiDelay: 0,
    options: [
      { id: 'bo', label: '판 수', choices: [{ v: 1, label: '단판' }, { v: 3, label: '3판 2선승' }, { v: 5, label: '5판 3선승' }], def: 3 },
      { id: 'cup', label: '혼자(1명) 대회', choices: [{ v: 4, label: '4명 · 2경기' }, { v: 8, label: '8명 · 3경기' }], def: 8 },
    ],
    controls: [
      { id: 'pull', label: '◀ 당기기 (누르고 있기)', keys: ['ArrowLeft', 'KeyA'], pad: ['left', 'lx-'] },
      { id: 'push', label: '밀기 ▶ (누르고 있기)', keys: ['ArrowRight', 'KeyD'], pad: ['right', 'lx+'] },
      { id: 'tech', label: '기술', keys: ['Space', 'ArrowUp', 'KeyW', 'Enter'], pad: ['a', 'b', 'rb'] },
    ],
    quick: [
      '샅바를 잡은 상대의 무릎 위 몸이 먼저 모래에 닿게 하면 한 판 승리. 3판 2선승(옵션: 단판·5판).',
      '◀ 당기기 · 밀기 ▶를 누르고 있으면 무게가 움직여요. 아래 「상대 무게중심」 바늘이 칸에 들어가면 그 방향 + 「기술」!',
      '상대가 기술을 걸면(기술 버튼이 빨개짐) 바로 「기술」 = 뒤집기. 혼자(1명)로 시작하면 천하장사 대회!',
    ],
    rules: [
      { h: '목표', p: [
        '두 장사가 샅바(허리와 다리에 맨 띠)를 서로 잡고 겨뤄요. 상대의 무릎 위 몸(엉덩이·등·손 등)이 먼저 모래에 닿게 하면 그 판을 이겨요.',
        '판 수: 단판 / 3판 2선승(기본) / 5판 3선승.',
        '2명: 맞대결(AI와, 또는 온라인·LAN으로 친구와 — 한 폰에 한 명). 1명: 천하장사 대회(4명 또는 8명 토너먼트).',
      ] },
      { h: '조작', p: [
        '◀ 당기기(누르고 있기): 나는 뒤로 버티고, 상대를 내 쪽(앞)으로 끌어당겨요.',
        '밀기 ▶(누르고 있기): 나는 앞으로 기울고, 상대를 뒤로 밀어요.',
        '「기술」(한 번 탭): 그때 누르고 있는 방향에 따라 기술이 나가요. 기술 버튼에 지금 나갈 기술 이름이 보여요. 엄지 하나로 ◀/▶를 누른 채 다른 엄지로 기술!',
        '내 장사는 늘 왼쪽에 보여요(온라인에서 청샅바여도 왼쪽).',
        'PC 키보드·게임패드: ←·A 당기기, →·D 밀기, 스페이스·↑·W·Enter·Ⓐ 기술. 「⌨ 조작 설정」에서 바꿀 수 있어요.',
      ] },
      { h: '기술 4가지', p: [
        '잡채기 = ◀ + 기술: 상대가 앞으로 쏠렸을 때(바늘이 왼쪽 칸) 당기며 돌려 앞으로 넘어뜨려요.',
        '안다리 = ▶ + 기술: 상대가 뒤로 버틸 때(바늘이 오른쪽 칸) 다리를 걸고 밀어 뒤로 눕혀요.',
        '들배지기 = 방향 없이 기술: 상대가 똑바로 섰을 때(가운데 칸) 번쩍 들어 돌려 눕혀요. 힘이 20 들고, 내 힘이 상대보다 15쯤 넉넉해야 해요(모자라면 칸에 「힘↓」).',
        '뒤집기 = 상대가 기술을 거는 순간 기술: 파고들어 상대를 뒤로 넘겨요. 기술 버튼이 빨개지고 노란 고리가 줄어드는 동안만 돼요.',
        '기술은 걸고 잠깐 뒤(약 0.3초, 들배지기 0.5초)에 판정돼요. 그때 상대 바늘이 아직 그 칸에 있어야 성공. 실패하면 힘이 빠지고 내 자세가 흐트러져요.',
      ] },
      { h: '무게중심 · 힘', p: [
        '「상대 무게중심」 바늘이 칸 깊숙이(밝은 노랑) 있을 때가 안전한 기회예요. 칸 가장자리에서 어설프게 걸면 상대가 뒤집기로 되칠 수 있어요.',
        '「내 무게중심」이 빨간 칸에 1초 넘게 머물면 혼자 넘어져요. 당기는 상대를 계속 밀면 앞으로 쏠려요!',
        '가만히 버티기만 하면 상대에게 조금씩 밀려 기회를 줘요.',
        '힘(이름 아래 막대): 밀고 당기면 줄고, 둘 다 손을 떼면 빨리 차요. 힘이 많을수록 세게 밀고 당겨요. 기술도 힘을 써요(잡채기·안다리 10, 뒤집기 12, 들배지기 20).',
        '내가 휘청이거나(빨간 칸) 기술에 깊이 걸렸으면 뒤집기를 할 수 없어요.',
      ] },
      { h: '시간 · 장외', p: [
        '한 판 50초, 그다음 25초 연장(힘이 더 차지 않아요). 그래도 안 끝나면 판정: 기술을 더 많이 건 쪽, 같으면 힘이 더 남은 쪽이 이겨요. 그것도 같으면 그 판을 다시 해요.',
        '두 장사가 모래판 끝까지 밀려 나가면(장외) 가운데에서 다시 시작해요(점수 없음).',
      ] },
      { h: '천하장사 대회 (혼자)', p: [
        '인원을 1명으로 하면 대회가 열려요. 8명이면 8강 → 4강 → 결승, 4명이면 4강 → 결승(옵션 「혼자(1명) 대회」).',
        '상대 실력: 8강 쉬움 → 4강 보통 → 결승 어려움(4명 대회는 보통 → 어려움). 장사마다 밀어붙이기형·끌어당기기형·들배지기형 버릇이 있어요.',
        '경기 사이에 대진표가 나와요. 결승까지 이기면 천하장사!',
      ] },
      { h: '예시', p: [
        '상대가 계속 밀어요 → 나는 ◀ 당기기 → 상대 바늘이 왼쪽 「잡채기」 칸 깊이 → ◀를 누른 채 기술 → 잡채기 성공!',
        '내가 ▶로 밀다가 상대가 당기면 내 바늘이 빨간 칸 쪽으로 → 얼른 손을 떼거나 ◀로 버텨요. 그 순간 상대가 잡채기를 걸면(기술 버튼이 빨개짐) → 바로 기술 = 뒤집기!',
      ] },
      { h: '함께 하기 · AI', p: [
        '한 폰에는 한 명만: 혼자 하면 상대는 AI예요. 친구와는 온라인·LAN 방에서 각자 폰으로 해요(겨루기는 호스트 폰이 계산).',
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요. 쉬움은 아무 때나 기술을 걸다 실패하고 뒤집기를 거의 못 해요. 어려움은 깊은 기회만 노리고 어설픈 기술은 곧잘 뒤집어요.',
      ] },
    ],
    init, actor: () => null, apply() { throw new Error('realtime game: no turn actions'); }, ai: () => null, result, mount,
    _t: { H, THR, UPR, SHAKY, canRev, CANT, DANGER, FALL_T, T_REG, T_END, TECH, HOW, AIC, newBout, stepBout, pressTech, aiStep, targetLean, techOk, init, endBout, afterBout, result, entrants, cupOpp, CUP_LV, KF, kfAt, warp },
  });
})();
