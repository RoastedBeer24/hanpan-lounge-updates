/* 연쇄 반응 실험실 — 접시 속 떠다니는 반응 구슬을 딱 한 번 터뜨려 연쇄 폭발을 최대로(1–4명).
   1명이면 24단계 실험(목표 점수·별), 여럿이면 같은 접시로 라운드마다 동시에 한 번씩 터뜨려 점수 대결. */
(function () {
  'use strict';
  const L = window.Lounge, U = L.util;

  /* ================= simulation (deterministic: integer RNG, + − × ÷ and sqrt only) =================
     World: dish radius 150 units, 30 steps per second. Orbs drift in straight lines and bounce off the rim
     (no orb–orb collisions, so an orb's path never depends on the chain). A burst grows, holds, shrinks;
     any orb touching a live burst (or a spark) reacts. */
  const DR = 150, FPS = 30, TWV = 15 * FPS, TWS = 20 * FPS, KCAP = 2400;
  // orb types: 0 기본 · 1 큰 구슬 · 2 황금(2점) · 3 분열 · 4 시간차 · 5 지속 폭발
  const OR = [5.5, 8.5, 5.5, 6.5, 6.5, 6.5];   // orb radius
  const BR = [20, 34, 20, 17, 24, 20];         // burst radius
  const BH = [33, 33, 33, 30, 33, 120];        // burst hold (steps)
  const PT = [1, 1, 2, 1, 1, 1];               // points
  const GROW = 9, SHRINK = 9, FUSE = 30, SPV = 5.4, SPL = 22, SPR = 3.5, TAPR = 28, TAPH = 33;
  const S3 = Math.sqrt(3) / 2;
  const SPK = [[0, -1, -S3, 0.5, S3, 0.5], [0, 1, -S3, -0.5, S3, -0.5]];
  const life = (H) => GROW + H + SHRINK;

  function radAt(R, H, a) {
    if (a < 0) return 0;
    if (a < GROW) { const u = a / GROW; return R * (1 - (1 - u) * (1 - u)); }
    a -= GROW;
    if (a < H) return R;
    a -= H;
    if (a < SHRINK) return R * (1 - a / SHRINK);
    return -1;
  }
  function rng(seed) {
    let a = seed | 0;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  /* cf = [count, big, gold, split, fuse, linger, speed(units/s)] */
  function gen(sd, cf) {
    const R = rng(sd), n = cf[0] | 0;
    const ty = new Uint8Array(n), col = new Uint8Array(n);
    let q = 0;
    for (let t = 1; t <= 5; t++) for (let c = 0; c < (cf[t] | 0) && q < n; c++) ty[q++] = t;
    const D = { n, ty, col, K: 0, cap: 256, cx: new Float64Array(n), cy: new Float64Array(n), vx: new Float64Array(n), vy: new Float64Array(n) };
    for (let i = 0; i < n; i++) {
      const lim = DR - OR[ty[i]] - 3;
      let u, v;
      do { u = R() * 2 - 1; v = R() * 2 - 1; } while (u * u + v * v > 1);
      D.cx[i] = u * lim; D.cy[i] = v * lim;
      let a, b, d2;
      do { a = R() * 2 - 1; b = R() * 2 - 1; d2 = a * a + b * b; } while (d2 > 1 || d2 < 0.04);
      const d = Math.sqrt(d2), sp = cf[6] * (0.7 + 0.6 * R());
      D.vx[i] = a / d * sp; D.vy[i] = b / d * sp;
      col[i] = (R() * 5) | 0;
    }
    D.X = new Float64Array(n * D.cap); D.Y = new Float64Array(n * D.cap);
    return D;
  }
  function ensure(D, k) {
    if (k < D.K) return;
    const n = D.n;
    if (k >= D.cap) {
      let c = D.cap; while (c <= k) c *= 2;
      const X = new Float64Array(n * c), Y = new Float64Array(n * c);
      X.set(D.X); Y.set(D.Y); D.X = X; D.Y = Y; D.cap = c;
    }
    const dt = 1 / FPS;
    while (D.K <= k) {
      const o = D.K * n;
      for (let i = 0; i < n; i++) {
        D.X[o + i] = D.cx[i]; D.Y[o + i] = D.cy[i];
        let x = D.cx[i] + D.vx[i] * dt, y = D.cy[i] + D.vy[i] * dt;
        const lim = DR - OR[D.ty[i]], d2 = x * x + y * y;
        if (d2 > lim * lim) {
          const d = Math.sqrt(d2), nx = x / d, ny = y / d, dot = D.vx[i] * nx + D.vy[i] * ny;
          if (dot > 0) { D.vx[i] -= 2 * dot * nx; D.vy[i] -= 2 * dot * ny; }
          x = nx * lim; y = ny * lim;
        }
        D.cx[i] = x; D.cy[i] = y;
      }
      D.K++;
    }
  }
  const CACHE = new Map();
  function dish(sd, cf) {
    const key = sd + ':' + cf.join(',');
    let D = CACHE.get(key);
    if (!D) {
      D = gen(sd, cf);
      CACHE.set(key, D);
      if (CACHE.size > 6) CACHE.delete(CACHE.keys().next().value);
    }
    return D;
  }
  function posAt(D, k, i) { ensure(D, k); return [D.X[k * D.n + i], D.Y[k * D.n + i]]; }

  /* one tap → whole chain. alive (Uint8Array) is updated in place. log=true also returns what the view needs. */
  function chain(D, alive, k0, tx, ty, log) {
    const n = D.n, T = D.ty;
    const bx = [], by = [], bk = [], bR = [], bH = [], bo = [], act = [];
    const sx = [], sy = [], sdx = [], sdy = [], sk = [], se = [], sact = [];
    const fz = new Int32Array(n).fill(-1);
    const pk = log ? new Int32Array(n).fill(-1) : null;
    const trig = [];
    let pts = 0, cnt = 0, last = k0 + life(TAPH), k = k0;
    function burst(x, y, kk, R, H, o) { bx.push(x); by.push(y); bk.push(kk); bR.push(R); bH.push(H); bo.push(o); act.push(bx.length - 1); const e = kk + life(H); if (e > last) last = e; }
    function pop(i, kk, o) {
      alive[i] = 0; fz[i] = -1;
      const t = T[i], x = D.X[o + i], y = D.Y[o + i];
      pts += PT[t]; cnt++;
      if (pk) pk[i] = kk;
      burst(x, y, kk, BR[t], BH[t], i);
      if (t === 3) {
        const d = SPK[i & 1];
        for (let q = 0; q < 6; q += 2) {
          sx.push(x); sy.push(y); sdx.push(d[q] * SPV); sdy.push(d[q + 1] * SPV); sk.push(kk); se.push(kk + SPL); sact.push(sx.length - 1);
        }
        if (kk + SPL > last) last = kk + SPL;
      }
    }
    burst(tx, ty, k0, TAPR, TAPH, -1);
    for (; k <= last && k < k0 + KCAP; k++) {
      ensure(D, k);
      const o = k * n;
      // lit fuses that go off now
      for (let i = 0; i < n; i++) if (fz[i] === k && alive[i]) pop(i, k, o);
      // live sparks: move, leave the dish → gone
      for (let a = sact.length - 1; a >= 0; a--) {
        const j = sact[a], age = k - sk[j];
        const px = sx[j] + sdx[j] * age, py = sy[j] + sdy[j] * age;
        if (age > SPL || px * px + py * py > DR * DR) { se[j] = k; sact.splice(a, 1); }
      }
      // touches
      trig.length = 0;
      for (let i = 0; i < n; i++) {
        if (!alive[i] || fz[i] >= 0) continue;
        const px = D.X[o + i], py = D.Y[o + i], r = OR[T[i]];
        let hit = false;
        for (let a = 0; a < act.length; a++) {
          const j = act[a], rr = radAt(bR[j], bH[j], k - bk[j]);
          if (rr <= 0) continue;
          const dx = px - bx[j], dy = py - by[j], s = rr + r;
          if (dx * dx + dy * dy < s * s) { hit = true; break; }
        }
        if (!hit) for (let a = 0; a < sact.length; a++) {
          const j = sact[a], age = k - sk[j];
          const dx = px - (sx[j] + sdx[j] * age), dy = py - (sy[j] + sdy[j] * age), s = SPR + r;
          if (dx * dx + dy * dy < s * s) { hit = true; break; }
        }
        if (hit) trig.push(i);
      }
      for (let q = 0; q < trig.length; q++) {
        const i = trig[q];
        if (T[i] === 4) { fz[i] = k + FUSE; if (log) log.fl[i] = k; if (k + FUSE > last) last = k + FUSE; }
        else pop(i, k, o);
      }
      for (let a = act.length - 1; a >= 0; a--) { const j = act[a]; if (k - bk[j] >= life(bH[j])) act.splice(a, 1); }
    }
    let end = k0;
    for (let j = 0; j < bx.length; j++) end = Math.max(end, bk[j] + life(bH[j]));
    for (let j = 0; j < sx.length; j++) end = Math.max(end, se[j]);
    const out = { pts, cnt, end };
    if (log) { out.pk = pk; out.fl = log.fl; out.b = { x: bx, y: by, k: bk, R: bR, H: bH, o: bo }; out.s = { x: sx, y: sy, dx: sdx, dy: sdy, k: sk, e: se }; }
    return out;
  }
  function chainLog(D, alive, k0, x, y) { const lg = { fl: new Int32Array(D.n).fill(-1) }; return chain(D, alive, k0, x, y, lg); }

  /* ================= solo stages ================= */
  // c = [count, big, gold, split, fuse, linger, speed], s = seed, t = taps, g = [goal, ★★, ★★★] in points
  const STAGES = [
    { n: '첫 반응', c: [16, 0, 0, 0, 0, 0, 16], s: 7035, t: 1, g: [4, 5, 6] },
    { n: '줄줄이', c: [22, 0, 0, 0, 0, 0, 18], s: 7166, t: 1, g: [6, 8, 9] },
    { n: '붐비는 접시', c: [30, 0, 0, 0, 0, 0, 20], s: 7263, t: 1, g: [8, 12, 16] },
    { n: '큰 구슬', c: [24, 4, 0, 0, 0, 0, 18], s: 7411, t: 1, g: [8, 10, 11] },
    { n: '큰 물결', c: [30, 6, 0, 0, 0, 0, 20], s: 7576, t: 1, g: [8, 12, 17] },
    { n: '황금 구슬', c: [26, 0, 5, 0, 0, 0, 18], s: 7673, t: 1, g: [8, 10, 12] },
    { n: '황금 사냥', c: [32, 2, 8, 0, 0, 0, 20], s: 7787, t: 1, g: [13, 17, 21] },
    { n: '분열 구슬', c: [24, 0, 0, 5, 0, 0, 18], s: 7918, t: 1, g: [12, 15, 18] },
    { n: '불꽃 갈래', c: [30, 0, 1, 7, 0, 0, 20], s: 8083, t: 1, g: [12, 18, 23] },
    { n: '시간차 구슬', c: [26, 0, 0, 0, 6, 0, 18], s: 8180, t: 1, g: [7, 9, 11] },
    { n: '징검다리', c: [28, 0, 0, 1, 8, 0, 22], s: 8328, t: 1, g: [12, 14, 17] },
    { n: '지속 폭발', c: [24, 0, 0, 0, 0, 5, 18], s: 8459, t: 1, g: [6, 10, 13] },
    { n: '오래 타는 불', c: [30, 1, 2, 0, 0, 7, 22], s: 8624, t: 1, g: [15, 20, 25] },
    { n: '두 번의 기회', c: [30, 1, 1, 0, 0, 0, 20], s: 8738, t: 2, g: [17, 20, 22] },
    { n: '듬성듬성', c: [20, 2, 1, 2, 2, 1, 16], s: 8852, t: 1, g: [8, 10, 13] },
    { n: '빠른 구슬', c: [30, 1, 2, 1, 1, 1, 36], s: 8983, t: 1, g: [20, 22, 25] },
    { n: '연쇄 칵테일', c: [32, 2, 3, 2, 2, 2, 22], s: 9097, t: 1, g: [16, 22, 27] },
    { n: '외딴 섬들', c: [22, 1, 2, 2, 2, 0, 14], s: 9262, t: 2, g: [13, 16, 20] },
    { n: '황금 소나기', c: [32, 0, 10, 1, 0, 1, 22], s: 9393, t: 1, g: [16, 22, 27] },
    { n: '시간 폭탄', c: [34, 0, 2, 0, 10, 2, 24], s: 9558, t: 1, g: [21, 24, 26] },
    { n: '분열의 밤', c: [28, 0, 2, 6, 0, 0, 20], s: 9655, t: 1, g: [19, 22, 24] },
    { n: '두 번 쳐라', c: [34, 1, 3, 1, 2, 1, 26], s: 9803, t: 2, g: [27, 30, 33] },
    { n: '혼돈의 접시', c: [36, 2, 3, 2, 2, 2, 30], s: 9900, t: 1, g: [27, 30, 34] },
    { n: '최후의 실험', c: [40, 2, 5, 2, 3, 2, 28], s: 10082, t: 1, g: [31, 34, 37] },
  ];
  const NST = STAGES.length;

  /* ================= state ================= */
  const rnd = (n) => Math.floor(Math.random() * n);
  const r1 = (v) => Math.round(v * 10) / 10;
  function init(players, opts) {
    const n = players.length;
    if (n === 1) return soloState(0, '0'.repeat(NST), 0);
    const R = (opts && +opts.rounds) || 5, mx = !(opts && opts.mix === 0);
    const s = { md: 'v', n, R, r: 0, mx: mx ? 1 : 0, nm: players.map((p, i) => String(p.name || '플레이어 ' + (i + 1)).slice(0, 10)), sc: Array(n).fill(0), seq: 0, last: null };
    newRound(s);
    return s;
  }
  function vsCfg(mx) {
    const c = [38 + rnd(9), 0, 0, 0, 0, 0, 18 + rnd(8)];
    if (mx) { for (let t = 1; t <= 5; t++) c[t] = rnd(3); if (c[1] + c[2] + c[3] + c[4] + c[5] < 4) c[1 + rnd(5)] += 2; }
    return c;
  }
  function newRound(s) {
    s.sd = 1 + rnd(2147483000);
    s.cf = vsCfg(s.mx);
    s.tp = Array(s.n).fill(null);
    s.pt = Array(s.n).fill(0);
  }
  function soloState(k, ss, seq) {
    return { md: 's', n: 1, k, tp: [], pt: [], ke: 0, dn: 0, st: 0, ss, seq, last: { id: seq, kd: 'go' } };
  }
  function soloAlive(s) {
    const S = STAGES[s.k], D = dish(S.s, S.c), al = new Uint8Array(D.n).fill(1);
    let ke = 0;
    for (const t of s.tp) ke = chain(D, al, t[0], t[1], t[2], null).end;
    return { D, al, ke };
  }
  function starsOf(S, p) { return p >= S.g[2] ? 3 : p >= S.g[1] ? 2 : p >= S.g[0] ? 1 : 0; }
  function actor(s) {
    if (s.md === 's') return s.dn && s.st > 0 && s.k === NST - 1 ? null : 0;
    if (s.over) return null;
    const a = [];
    for (let i = 0; i < s.n; i++) if (!s.tp[i]) a.push(i);
    return a;
  }
  function readTap(a, kA, kB) {
    const k = Math.round(+a.k);
    if (!(k >= kA && k <= kB)) throw new Error('bad time');
    let x = +a.x, y = +a.y;
    if (!isFinite(x) || !isFinite(y)) throw new Error('bad pos');
    const d = Math.sqrt(x * x + y * y), lim = DR - 3;
    if (d > lim) { x = x / d * lim; y = y / d * lim; }
    return [k, r1(x), r1(y)];
  }
  function apply(s, seat, a) {
    if (!a || typeof a !== 'object') throw new Error('bad action');
    if (s.md === 's') return applySolo(s, a);
    if (s.over || s.tp[seat] || seat < 0 || seat >= s.n) throw new Error('not now');
    const t = readTap(a, 0, TWV);
    const D = dish(s.sd, s.cf), al = new Uint8Array(D.n).fill(1);
    s.tp[seat] = t;
    s.pt[seat] = chain(D, al, t[0], t[1], t[2], null).pts;
    if (s.tp.every(Boolean)) {
      for (let i = 0; i < s.n; i++) s.sc[i] += s.pt[i];
      s.seq++;
      s.last = { id: s.seq, r: s.r, sd: s.sd, cf: s.cf, tp: s.tp, pt: s.pt };
      s.r++;
      if (s.r >= s.R) s.over = 1;
      else newRound(s);
    }
    return s;
  }
  function applySolo(s, a) {
    const t = a.t;
    if (t === 'go' || t === 'next' || t === 'retry') {
      const k = t === 'next' ? s.k + 1 : t === 'retry' ? s.k : a.k | 0;
      if (!(k >= 0 && k < NST)) throw new Error('bad stage');
      if (t === 'next' && !(s.dn && s.st > 0)) throw new Error('not cleared');
      const ns = soloState(k, s.ss, s.seq + 1);
      ns.last.kd = t;
      return ns;
    }
    if (s.dn) throw new Error('stage over');
    const S = STAGES[s.k], st = soloAlive(s);
    const kA = s.tp.length ? st.ke : 0;
    const tap = readTap(a, kA, kA + TWS);
    const r = chain(st.D, st.al, tap[0], tap[1], tap[2], null);
    s.tp.push(tap); s.pt.push(r.pts); s.ke = r.end;
    s.seq++;
    s.last = { id: s.seq, kd: 'tap', i: s.tp.length - 1 };
    if (s.tp.length >= S.t || !st.al.some((v) => v)) {
      s.dn = 1;
      const p = s.pt.reduce((x, y) => x + y, 0);
      s.st = starsOf(S, p);
      if (s.st > (+s.ss[s.k] || 0)) s.ss = s.ss.slice(0, s.k) + s.st + s.ss.slice(s.k + 1);
    }
    return s;
  }
  function result(s) {
    if (s.md === 's') {
      if (!(s.dn && s.st > 0 && s.k === NST - 1)) return null;
      let n = 0; for (const ch of s.ss) n += +ch || 0;
      return { winners: [0], title: '모든 실험 성공!', text: '이번에 모은 별 ' + n + ' / ' + NST * 3 };
    }
    if (!s.over) return null;
    const best = Math.max(...s.sc);
    const winners = s.sc.map((v, i) => (v === best ? i : -1)).filter((i) => i >= 0);
    return { winners, text: s.sc.map((v, i) => s.nm[i] + ' ' + v + '점').join(' · ') };
  }

  /* ================= AI: sample tap points (time × place), keep the best ================= */
  function search(D, al, kA, kB, N, refine) {
    const alive = [];
    for (let i = 0; i < D.n; i++) if (al[i]) alive.push(i);
    if (!alive.length) return { k: kA, x: 0, y: 0, v: 0 };
    ensure(D, kB);
    const tmp = new Uint8Array(D.n);
    const evalTap = (k, x, y) => { tmp.set(al); return chain(D, tmp, k, x, y, null).pts; };
    const cands = [];
    for (let c = 0; c < N; c++) {
      const k = kA + rnd(kB - kA + 1), o = k * D.n, j = alive[rnd(alive.length)];
      let x = D.X[o + j], y = D.Y[o + j];
      if (c & 1) { // aim at the middle of the crowd around orb j
        let sx = 0, sy = 0, m = 0;
        for (const i of alive) { const dx = D.X[o + i] - x, dy = D.Y[o + i] - y; if (dx * dx + dy * dy < 45 * 45) { sx += D.X[o + i]; sy += D.Y[o + i]; m++; } }
        x = sx / m; y = sy / m;
      } else { x += (Math.random() - 0.5) * 30; y += (Math.random() - 0.5) * 30; }
      const d = Math.sqrt(x * x + y * y); if (d > DR - 3) { x = x / d * (DR - 3); y = y / d * (DR - 3); }
      cands.push({ k, x: r1(x), y: r1(y), v: evalTap(k, r1(x), r1(y)) });
    }
    cands.sort((p, q) => q.v - p.v);
    if (refine) {
      const top = cands.slice(0, 3);
      for (let q = 0; q < refine; q++) {
        const b = top[q % top.length];
        const k = Math.max(kA, Math.min(kB, b.k + rnd(25) - 12));
        let x = b.x + (Math.random() - 0.5) * 24, y = b.y + (Math.random() - 0.5) * 24;
        const d = Math.sqrt(x * x + y * y); if (d > DR - 3) { x = x / d * (DR - 3); y = y / d * (DR - 3); }
        const v = evalTap(k, r1(x), r1(y));
        if (v > cands[0].v) cands.unshift({ k, x: r1(x), y: r1(y), v });
      }
      cands.sort((p, q) => q.v - p.v);
    }
    return cands;
  }
  // samples / refinement steps / chance to take a random sample instead of the best (beginner mistakes)
  const LVP = { 1: [7, 0, 0.45], 2: [18, 0, 0], 3: [55, 20, 0] };
  function pickTap(D, al, kA, kB, lv) {
    const P = LVP[lv] || LVP[2], c = search(D, al, kA, kB, P[0], P[1]);
    return Math.random() < P[2] ? c[rnd(c.length)] : c[0];
  }
  function ai(s, seat, lv) {
    lv = lv || 2;
    if (s.md === 's') {
      if (s.dn) return s.st > 0 ? (s.k < NST - 1 ? { t: 'next' } : null) : { t: 'retry' };
      const st = soloAlive(s), kA = s.tp.length ? st.ke : 0;
      const c = pickTap(st.D, st.al, kA, kA + TWS, lv);
      return { k: c.k, x: c.x, y: c.y };
    }
    if (s.over || s.tp[seat]) return null;
    const D = dish(s.sd, s.cf), al = new Uint8Array(D.n).fill(1);
    const c = pickTap(D, al, 0, TWV, lv);
    return { k: c.k, x: c.x, y: c.y };
  }
  function aiDelayFor(s, seat, lv) {
    if (s.md === 's') return s.dn ? 1400 : 900 + rnd(700);
    if (s.over || s.tp[seat]) return null;
    return (lv === 3 ? 900 : lv === 1 ? 2000 : 1400) + rnd(1200);
  }

  /* ================= view ================= */
  const PAL = ['#58d6c0', '#f28ab8', '#8fc4ff', '#ffb08a', '#b6e36a'];
  const TCOL = [null, '#ff7a3d', '#ffd23f', '#3fe0ff', '#ff4d5e', '#a77bff'];
  const TNAME = ['기본 구슬', '큰 구슬', '황금 구슬', '분열 구슬', '시간차 구슬', '지속 폭발 구슬'];
  const TDESC = ['', '폭발이 훨씬 커요', '터지면 2점!', '점 세 개 방향으로 불꽃이 날아가요', '닿으면 1초 뒤에 터져요', '폭발이 4초 동안 머물러요'];
  const NEWAT = { 3: 1, 5: 2, 7: 3, 9: 4, 11: 5 };
  const MILE = [[10, '좋아요!'], [20, '대단해요!'], [30, '엄청난 연쇄!'], [40, '실험실 대폭발!']];
  const FONT_D = '"Black Han Sans","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const FONT_M = '"IBM Plex Mono",ui-monospace,Menlo,monospace';
  const FONT_B = '"IBM Plex Sans KR","Apple SD Gothic Neo","Malgun Gothic",sans-serif';
  const orbColor = (D, i) => (D.ty[i] ? TCOL[D.ty[i]] : PAL[D.col[i]]);
  const CSS = `
.ch-top{padding:8px 10px;gap:6px;flex-wrap:nowrap;min-height:60px;box-sizing:border-box}
.ch-chip{display:flex;flex-direction:column;gap:1px;background:color-mix(in srgb,var(--surface) 90%,transparent);border:1px solid var(--line);border-radius:10px;padding:4px 8px;font-weight:700;min-width:0;flex:1 1 0;max-width:132px;transition:border-color .2s}
.ch-chip .l1,.ch-chip .l2{display:flex;align-items:center;gap:5px;min-width:0}
.ch-chip .nm{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;flex:1;font-size:11px;color:var(--muted)}
.ch-chip .v{font-family:var(--f-mono);font-size:15px;flex:1;line-height:1.1}
.ch-chip .ck{font-size:12px;opacity:.55;text-align:center}
.ch-chip.done .ck{opacity:1;color:var(--brass)}
.ch-chip.me{border-color:color-mix(in srgb,var(--brass) 60%,transparent)}
.ch-solo{display:flex;align-items:center;gap:6px;width:100%;max-width:440px}
.ch-solo .mid{flex:1;text-align:center;min-width:0;line-height:1.2}
.ch-solo .t1{font-family:var(--f-display);font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ch-solo .t2{font-size:12px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ch-solo .t2 b{color:var(--ink);font-family:var(--f-mono)}
.ch-solo .t2 .st{color:var(--brass)}
.btn.ch-arrow{width:44px;min-width:44px;height:44px;padding:0;font-size:18px}
.ch-panel{padding:6px 12px 12px;flex-direction:column;gap:6px;min-height:104px;justify-content:flex-end;box-sizing:border-box}
.ch-hint{font-size:13px;color:var(--muted);text-align:center;text-wrap:balance;line-height:1.35;max-width:440px}
.ch-hint b{color:var(--ink)}
.ch-hint .hot{color:var(--coral)}
.ch-row{display:flex;gap:8px;justify-content:center;width:100%;max-width:420px}
.ch-row .btn{flex:1}
.ch-dish{position:absolute;pointer-events:none;border-radius:50%}
.ch-cur{flex-direction:column;gap:12px;text-align:center}
.ch-cur .big{font-family:var(--f-display);font-size:34px}
`;

  /* small synth: pop pitch climbs with the chain (respects the app's sound switch) */
  const Snd = {
    ac: null, lastT: 0,
    ctx() {
      let on = true; try { on = U.store.get('sound', true) !== false; } catch (e) {}
      if (!on) return null;
      try { if (!this.ac) this.ac = new (window.AudioContext || window.webkitAudioContext)(); if (this.ac.state === 'suspended') this.ac.resume(); return this.ac; } catch (e) { return null; }
    },
    pop(idx, vol) {
      const now = performance.now();
      if (now - this.lastT < 36) return;
      this.lastT = now;
      const ac = this.ctx(); if (!ac) return;
      try {
        const SC = [0, 2, 4, 7, 9], semi = Math.min(38, 12 * Math.floor(idx / 5) + SC[idx % 5]);
        const f = 262 * Math.pow(2, semi / 12), t = ac.currentTime;
        const o = ac.createOscillator(), g = ac.createGain();
        o.type = 'triangle'; o.frequency.setValueAtTime(f, t); o.frequency.exponentialRampToValueAtTime(f * 1.45, t + 0.07);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.15 * (vol || 1), t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.22);
        const o2 = ac.createOscillator(), g2 = ac.createGain();
        o2.type = 'sine'; o2.frequency.setValueAtTime(f * 2, t);
        g2.gain.setValueAtTime(0.0001, t); g2.gain.exponentialRampToValueAtTime(0.05 * (vol || 1), t + 0.005); g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
        o2.connect(g2).connect(ac.destination); o2.start(t); o2.stop(t + 0.14);
      } catch (e) {}
    },
    boom() {
      const ac = this.ctx(); if (!ac) return;
      try {
        const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
        o.type = 'sine'; o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(48, t + 0.25);
        g.gain.setValueAtTime(0.32, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + 0.32);
      } catch (e) {}
    },
  };

  function mount(root, api) {
    const h = L.h;
    const style = h('style', { text: CSS });
    root.appendChild(style);
    const cv = U.canvas(root), ctx = cv.ctx;
    const top = h('div', { class: 'hud top ch-top' });
    const panel = h('div', { class: 'hud bottom ch-panel' });
    const dishMark = h('div', { class: 'ch-dish' });
    root.append(dishMark, top, panel);

    let st = null, P = { kind: 'none' }, busy = false, dead = false;
    let seenId = -1, seenRev = 0, autoJumped = false, lastTopKey = '', lastPanelKey = '';
    const G = { cx: 0, cy: 0, r: 100, s: 1, W: 0, H: 0, tH: 60, bH: 104 };
    const timers = new Set();
    const later = (fn, ms) => { const t = setTimeout(() => { timers.delete(t); if (!dead) fn(); }, ms); timers.add(t); return t; };
    const spd = () => L.debug.speed || 1;
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const isSolo = () => st && st.md === 's';
    const myColor = (seat) => (api.players[seat] && api.players[seat].color) || '#e3ae45';
    const nameOf = (seat) => (st && st.nm ? st.nm[seat] : (api.players[seat] && api.players[seat].name)) || ('#' + (seat + 1));

    /* ---------- caches ---------- */
    let bgCv = null, dishCv = null, sprites = {}, glows = {}, cacheKey = '';
    function mkCanvas(w, hh) { const c = document.createElement('canvas'); c.width = Math.max(1, Math.ceil(w)); c.height = Math.max(1, Math.ceil(hh)); return c; }
    function buildCaches() {
      const key = cv.w + 'x' + cv.h + '@' + cv.dpr + ':' + G.r.toFixed(1);
      if (key === cacheKey) return;
      cacheKey = key; sprites = {}; glows = {};
      const dpr = cv.dpr;
      // bench background
      bgCv = mkCanvas(cv.w * dpr, cv.h * dpr);
      const b = bgCv.getContext('2d');
      b.scale(dpr, dpr);
      const gr = b.createLinearGradient(0, 0, 0, cv.h);
      gr.addColorStop(0, '#1d1729'); gr.addColorStop(1, '#130f1b');
      b.fillStyle = gr; b.fillRect(0, 0, cv.w, cv.h);
      b.strokeStyle = 'rgba(242,233,216,0.035)'; b.lineWidth = 1;
      for (let x = 12; x < cv.w; x += 24) { b.beginPath(); b.moveTo(x + 0.5, 0); b.lineTo(x + 0.5, cv.h); b.stroke(); }
      for (let y = 12; y < cv.h; y += 24) { b.beginPath(); b.moveTo(0, y + 0.5); b.lineTo(cv.w, y + 0.5); b.stroke(); }
      const vg = b.createRadialGradient(cv.w / 2, cv.h / 2, Math.min(cv.w, cv.h) * 0.3, cv.w / 2, cv.h / 2, Math.max(cv.w, cv.h) * 0.75);
      vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.45)');
      b.fillStyle = vg; b.fillRect(0, 0, cv.w, cv.h);
      // petri dish at main size
      const R = G.r, pad = 16, S = (R + pad) * 2;
      dishCv = mkCanvas(S * dpr, S * dpr);
      const d = dishCv.getContext('2d');
      d.scale(dpr, dpr);
      const c = S / 2;
      d.save(); d.shadowColor = 'rgba(0,0,0,0.55)'; d.shadowBlur = 18; d.shadowOffsetY = 6;
      d.fillStyle = '#0d1820'; d.beginPath(); d.arc(c, c, R + 6, 0, 7); d.fill(); d.restore();
      const rim = d.createLinearGradient(0, c - R, 0, c + R);
      rim.addColorStop(0, 'rgba(225,240,245,0.55)'); rim.addColorStop(0.5, 'rgba(150,180,195,0.25)'); rim.addColorStop(1, 'rgba(225,240,245,0.4)');
      d.fillStyle = rim; d.beginPath(); d.arc(c, c, R + 6, 0, 7); d.fill();
      const inner = d.createRadialGradient(c - R * 0.2, c - R * 0.25, R * 0.1, c, c, R);
      inner.addColorStop(0, '#1f4450'); inner.addColorStop(0.65, '#142c38'); inner.addColorStop(1, '#0c1822');
      d.fillStyle = inner; d.beginPath(); d.arc(c, c, R, 0, 7); d.fill();
      d.strokeStyle = 'rgba(200,235,240,0.08)'; d.lineWidth = 1;
      for (let q = 1; q <= 3; q++) { d.beginPath(); d.arc(c, c, R * q / 4, 0, 7); d.stroke(); }
      d.strokeStyle = 'rgba(200,235,240,0.18)';
      for (let q = 0; q < 36; q++) {
        const a = q / 36 * Math.PI * 2, l = q % 3 === 0 ? 7 : 4;
        d.beginPath(); d.moveTo(c + Math.cos(a) * (R - 2), c + Math.sin(a) * (R - 2)); d.lineTo(c + Math.cos(a) * (R - 2 - l), c + Math.sin(a) * (R - 2 - l)); d.stroke();
      }
      d.strokeStyle = 'rgba(255,255,255,0.22)'; d.lineWidth = 3; d.lineCap = 'round';
      d.beginPath(); d.arc(c, c, R + 2, Math.PI * 1.08, Math.PI * 1.42); d.stroke();
      d.strokeStyle = 'rgba(255,255,255,0.1)'; d.lineWidth = 2;
      d.beginPath(); d.arc(c, c, R - 8, Math.PI * 1.12, Math.PI * 1.3); d.stroke();
    }
    function orbSprite(t, col, v) {
      const key = t + '|' + col + '|' + v;
      let sp = sprites[key];
      if (sp) return sp;
      const dpr = cv.dpr, rp = OR[t] * G.s, half = rp * 2.4 + 2;
      const c = mkCanvas(half * 2 * dpr, half * 2 * dpr), g = c.getContext('2d');
      g.scale(dpr, dpr);
      const m = half;
      const glow = g.createRadialGradient(m, m, rp * 0.6, m, m, rp * 2.3);
      glow.addColorStop(0, col + '88'); glow.addColorStop(1, col + '00');
      g.fillStyle = glow; g.beginPath(); g.arc(m, m, rp * 2.3, 0, 7); g.fill();
      const body = g.createRadialGradient(m - rp * 0.35, m - rp * 0.4, rp * 0.1, m, m, rp);
      body.addColorStop(0, '#ffffff'); body.addColorStop(0.35, col); body.addColorStop(1, shade(col, -0.35));
      g.fillStyle = body; g.beginPath(); g.arc(m, m, rp, 0, 7); g.fill();
      g.lineWidth = Math.max(1, rp * 0.16); g.strokeStyle = 'rgba(255,255,255,0.85)'; g.fillStyle = 'rgba(255,255,255,0.95)';
      if (t === 1) { g.beginPath(); g.arc(m, m, rp * 0.58, 0, 7); g.stroke(); }
      else if (t === 2) {
        const a = rp * 0.62, w = rp * 0.16;
        g.beginPath(); g.moveTo(m, m - a); g.lineTo(m + w, m - w); g.lineTo(m + a, m); g.lineTo(m + w, m + w); g.lineTo(m, m + a); g.lineTo(m - w, m + w); g.lineTo(m - a, m); g.lineTo(m - w, m - w); g.closePath(); g.fill();
        g.strokeStyle = col; g.lineWidth = Math.max(1, rp * 0.14); g.beginPath(); g.arc(m, m, rp * 1.35, 0, 7); g.stroke();
      } else if (t === 3) {
        const d = SPK[v];
        for (let q = 0; q < 6; q += 2) { g.beginPath(); g.arc(m + d[q] * rp * 1.55, m + d[q + 1] * rp * 1.55, Math.max(1.2, rp * 0.28), 0, 7); g.fill(); }
      } else if (t === 4) {
        g.fillStyle = 'rgba(40,10,14,0.85)'; g.beginPath(); g.arc(m, m, rp * 0.45, 0, 7); g.fill();
        g.strokeStyle = 'rgba(255,255,255,0.9)'; g.beginPath(); g.moveTo(m, m - rp * 0.95); g.lineTo(m + rp * 0.35, m - rp * 1.45); g.stroke();
      } else if (t === 5) {
        g.setLineDash([Math.max(1.5, rp * 0.35), Math.max(1.5, rp * 0.3)]); g.strokeStyle = col; g.lineWidth = Math.max(1, rp * 0.18);
        g.beginPath(); g.arc(m, m, rp * 1.5, 0, 7); g.stroke(); g.setLineDash([]);
      }
      sp = sprites[key] = { c, half };
      return sp;
    }
    function glowSprite(col) {
      let gc = glows[col];
      if (gc) return gc;
      const S = 128;
      gc = glows[col] = mkCanvas(S, S);
      const g = gc.getContext('2d'), m = S / 2;
      const gr = g.createRadialGradient(m, m, 0, m, m, m);
      gr.addColorStop(0, col + 'aa'); gr.addColorStop(0.55, col + '55'); gr.addColorStop(0.86, col + '66'); gr.addColorStop(0.95, col + 'cc'); gr.addColorStop(1, col + '00');
      g.fillStyle = gr; g.fillRect(0, 0, S, S);
      return gc;
    }
    function shade(hex, f) {
      const n = parseInt(hex.slice(1), 16);
      let r = n >> 16, g = (n >> 8) & 255, b = n & 255;
      r = Math.round(r * (1 + f)); g = Math.round(g * (1 + f)); b = Math.round(b * (1 + f));
      return 'rgb(' + U.clamp(r, 0, 255) + ',' + U.clamp(g, 0, 255) + ',' + U.clamp(b, 0, 255) + ')';
    }

    /* ---------- layout ---------- */
    function layout() {
      G.W = cv.w; G.H = cv.h;
      G.tH = Math.max(56, top.offsetHeight || 60);
      G.bH = Math.max(104, panel.offsetHeight || 104);
      const avail = G.H - G.tH - G.bH;
      G.r = Math.max(70, Math.min(G.W / 2 - 12, avail / 2 - 10));
      G.cx = G.W / 2; G.cy = G.tH + Math.max(avail, G.r * 2) / 2; G.s = G.r / DR;
      Object.assign(dishMark.style, { left: (G.cx - G.r) + 'px', top: (G.cy - G.r) + 'px', width: G.r * 2 + 'px', height: G.r * 2 + 'px' });
      buildCaches();
    }
    cv.onresize = () => { layout(); };

    /* ---------- dish views (one per drawn dish) ---------- */
    // view: {D, al (alive before), lg (chain log or null), k0, kf, kStart, col (tap colour), cx, cy, s, ptr, order, pts, cnt, bump}
    function mkView(D, al, lg, k0, kStart, col) {
      const v = { D, al, lg, k0, kf: kStart, kStart, col, cx: G.cx, cy: G.cy, s: G.s, ptr: 0, order: null, pts: 0, cnt: 0, bump: 0, mile: 0 };
      if (lg) {
        const o = [];
        for (let i = 0; i < D.n; i++) if (lg.pk[i] >= 0) o.push(i);
        o.sort((a, b) => lg.pk[a] - lg.pk[b]);
        v.order = o;
      }
      return v;
    }
    function aliveAfter(D, al, lg) { const a = al.slice(); if (lg) for (let i = 0; i < D.n; i++) if (lg.pk[i] >= 0) a[i] = 0; return a; }
    const parts = [];
    function spawn(x, y, col, n, sp) {
      for (let q = 0; q < n && parts.length < 260; q++) {
        const a = Math.random() * Math.PI * 2, v = (0.4 + Math.random()) * sp;
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 0.35 + Math.random() * 0.35, t: 0, col });
      }
    }
    let floaters = [], banner = null, shake = 0;
    // advance a view's pop pointer → count, sound, particles
    function advance(v, main) {
      if (!v.lg) return;
      let newest = -1;
      while (v.ptr < v.order.length && v.lg.pk[v.order[v.ptr]] <= v.kf) {
        const i = v.order[v.ptr++], t = v.D.ty[i], k = v.lg.pk[i];
        v.cnt++; v.pts += PT[t]; v.bump = 1; newest = v.cnt;
        const p = posAt(v.D, k, i), x = v.cx + p[0] * v.s, y = v.cy + p[1] * v.s;
        spawn(x, y, orbColor(v.D, i), main ? (t === 1 ? 12 : 6) : 3, main ? 120 : 60);
        if (main && t === 2) floaters.push({ x, y, t: 0, txt: '+2', col: TCOL[2] });
        if (main && t === 1) shake = Math.max(shake, 4);
      }
      if (newest > 0) {
        Snd.pop(newest - 1, main ? 1 : 0.6);
        if (main) {
          const tot = v.pts + (v.base || 0);
          for (const m of MILE) if (tot >= m[0] && v.mile < m[0]) { v.mile = m[0]; banner = { txt: m[1], t: 0 }; api.buzz(18); }
        }
      }
    }
    function drawView(v, main) {
      const D = v.D, s = v.s, kf = v.kf, q = s / G.s;
      const R = DR * s;
      ctx.drawImage(dishCv, v.cx - (G.r + 16) * q, v.cy - (G.r + 16) * q, (G.r + 16) * 2 * q, (G.r + 16) * 2 * q);
      ctx.save();
      ctx.beginPath(); ctx.arc(v.cx, v.cy, R, 0, 7); ctx.clip();
      const lg = v.lg;
      ctx.globalCompositeOperation = 'lighter';
      if (lg && kf >= v.k0) {
        const B = lg.b;
        for (let j = 0; j < B.x.length; j++) {
          const a = kf - B.k[j];
          if (a < 0) continue;
          const rr = radAt(B.R[j], B.H[j], a);
          if (rr <= 0) continue;
          const col = B.o[j] < 0 ? v.col : orbColor(D, B.o[j]);
          const x = v.cx + B.x[j] * s, y = v.cy + B.y[j] * s, rp = rr * s;
          ctx.globalAlpha = 0.9;
          ctx.drawImage(glowSprite(col), x - rp, y - rp, rp * 2, rp * 2);
          if (a < 11) {
            const u = a / 11;
            ctx.globalAlpha = (1 - u) * 0.8;
            ctx.strokeStyle = col; ctx.lineWidth = Math.max(1, 3 * (1 - u) * (main ? 1 : 0.6));
            ctx.beginPath(); ctx.arc(x, y, B.R[j] * s * (0.5 + u * 1.1), 0, 7); ctx.stroke();
          }
        }
        const Sp = lg.s;
        for (let j = 0; j < Sp.x.length; j++) {
          if (kf < Sp.k[j] || kf > Sp.e[j]) continue;
          const a = kf - Sp.k[j], x = v.cx + (Sp.x[j] + Sp.dx[j] * a) * s, y = v.cy + (Sp.y[j] + Sp.dy[j] * a) * s;
          const tx = v.cx + (Sp.x[j] + Sp.dx[j] * Math.max(0, a - 3)) * s, ty = v.cy + (Sp.y[j] + Sp.dy[j] * Math.max(0, a - 3)) * s;
          ctx.globalAlpha = 1; ctx.strokeStyle = '#bff6ff'; ctx.lineWidth = Math.max(1.2, 2.4 * q); ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(x, y); ctx.stroke();
          ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(x, y, Math.max(1.5, SPR * s * 0.8), 0, 7); ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
      // orbs
      const k = Math.max(0, Math.floor(kf)), fr = kf - k;
      ensure(D, k + 1);
      const n = D.n, o0 = k * n, o1 = (k + 1) * n;
      for (let i = 0; i < n; i++) {
        if (!v.al[i]) continue;
        if (lg && lg.pk[i] >= 0 && lg.pk[i] <= kf) continue;
        const x = v.cx + (D.X[o0 + i] + (D.X[o1 + i] - D.X[o0 + i]) * fr) * s;
        const y = v.cy + (D.Y[o0 + i] + (D.Y[o1 + i] - D.Y[o0 + i]) * fr) * s;
        const t = D.ty[i], sp = orbSprite(t, orbColor(D, i), t === 3 ? i & 1 : 0), hq = sp.half * q;
        if (lg && t === 4 && lg.fl[i] >= 0 && lg.fl[i] <= kf) {
          const u = (kf - lg.fl[i]) / FUSE;
          const blink = Math.sin(u * u * 40) > 0;
          ctx.globalAlpha = 1;
          ctx.drawImage(sp.c, x - hq, y - hq, hq * 2, hq * 2);
          ctx.strokeStyle = blink ? '#fff' : '#ff4d5e'; ctx.lineWidth = Math.max(1, 2 * q);
          ctx.beginPath(); ctx.arc(x, y, (OR[4] + 4) * s, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - u)); ctx.stroke();
          if (blink) { ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.beginPath(); ctx.arc(x, y, OR[4] * s, 0, 7); ctx.fill(); }
        } else ctx.drawImage(sp.c, x - hq, y - hq, hq * 2, hq * 2);
      }
      // tap marker (before the tap: where it will go is NOT shown)
      if (lg && kf >= v.k0 && kf < v.k0 + 14) {
        const B = lg.b, u = (kf - v.k0) / 14;
        ctx.globalAlpha = 1 - u; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(v.cx + B.x[0] * s, v.cy + B.y[0] * s, (6 + u * 26) * q, 0, 7); ctx.stroke();
        ctx.globalAlpha = 1;
      }
      ctx.restore();
    }

    /* ---------- DOM: top & panel ---------- */
    function storedStars() {
      let a = ''; try { a = String(U.store.get('chain.ss', '') || ''); } catch (e) {}
      return a;
    }
    function mergedStars() {
      const a = storedStars(), b = st && st.ss ? st.ss : '';
      let out = '';
      for (let k = 0; k < NST; k++) out += Math.max(+a[k] || 0, +b[k] || 0);
      return out;
    }
    function unlockedMax() { const m = mergedStars(); let k = 0; while (k < NST - 1 && +m[k] > 0) k++; return k; }
    const bestShown = {};
    const starTxt = (n) => '★'.repeat(n) + '☆'.repeat(3 - n);
    function renderTop() {
      if (!st) return;
      if (isSolo()) {
        const S = STAGES[st.k];
        if (P.kind !== 'chain' || bestShown[st.k] == null) bestShown[st.k] = +mergedStars()[st.k] || 0;
        const best = bestShown[st.k];
        const canNav = api.canAct(0) && !busy && P.kind !== 'chain';
        const key = 's' + st.k + ':' + best + ':' + canNav + ':' + unlockedMax();
        if (key === lastTopKey) return;
        lastTopKey = key;
        top.innerHTML = '';
        const prevB = h('button', { class: 'btn ch-arrow', 'aria-label': '이전 단계', text: '◀', disabled: !canNav || st.k <= 0, onclick: () => goStage(st.k - 1) });
        const nextB = h('button', { class: 'btn ch-arrow', 'aria-label': '다음 단계', text: '▶', disabled: !canNav || st.k >= Math.min(NST - 1, unlockedMax()), onclick: () => goStage(st.k + 1) });
        const t2 = h('div', { class: 't2' });
        t2.innerHTML = '목표 <b>' + S.g[0] + '</b>점 · ★★ <b>' + S.g[1] + '</b> · ★★★ <b>' + S.g[2] + '</b>' + (S.t > 1 ? ' · 탭 <b>' + S.t + '</b>번' : '');
        top.append(h('div', { class: 'ch-solo' }, prevB,
          h('div', { class: 'mid' }, h('div', { class: 't1' }, (st.k + 1) + '단계 · ' + S.n + ' ', h('span', { style: { color: 'var(--brass)', fontSize: '15px' }, text: starTxt(best) })), t2),
          nextB));
        return;
      }
      // while a round's chains are being revealed, show the totals from before that round
      const rev = !!st.last && (st.last.id > seenRev || (P.kind === 'reveal' && P.ev === st.last));
      const sc = rev ? st.sc.map((v, i) => v - st.last.pt[i]) : st.sc;
      const showDone = !st.over && !rev && P.kind !== 'summary';
      const key = 'v' + st.r + ':' + sc.join(',') + ':' + (showDone ? st.tp.map((t) => (t ? 1 : 0)).join('') : 'x');
      if (key === lastTopKey) return;
      lastTopKey = key;
      top.innerHTML = '';
      const mine = api.mySeats();
      for (let i = 0; i < st.n; i++) {
        const done = showDone && !!st.tp[i];
        top.append(h('div', { class: 'ch-chip' + (done ? ' done' : '') + (mine.length === 1 && mine[0] === i ? ' me' : '') },
          h('div', { class: 'l1' }, h('span', { class: 'dot', style: { '--c': myColor(i), width: '8px', height: '8px' } }), h('span', { class: 'nm', text: nameOf(i) })),
          h('div', { class: 'l2' }, h('span', { class: 'v', text: String(sc[i]) }), h('span', { class: 'ck', text: !showDone ? '' : done ? '✓' : '…' }))));
      }
    }
    function setPanel(key, build) {
      if (key === lastPanelKey) return;
      lastPanelKey = key;
      panel.innerHTML = '';
      build(panel);
    }
    const hint = (html) => { const d = h('div', { class: 'ch-hint' }); d.innerHTML = html; return d; };

    /* ---------- phases ---------- */
    let ptr = null, hover = null, lastSec = -1;
    function startAim(seat, D, al, kA, kB, loop, r) {
      P = { kind: 'aim', seat, D, al, kA, kB, loop, r, sd: st.sd, t0: performance.now(), kf: kA, view: mkView(D, al, null, kA, kA, myColor(seat)) };
      ptr = null; lastSec = -1;
      banner = { txt: isSolo() ? (st.k + 1) + '단계' : '라운드 ' + (st.r + 1), t: 0, small: true };
      setBusy(false);
    }
    function startChain(D, al, tap, kStart, col, onDone) {
      const a = al.slice();
      const lg = chainLog(D, a, tap[0], tap[1], tap[2]);
      const v = mkView(D, al, lg, tap[0], kStart, col);
      P = { kind: 'chain', view: v, t0: performance.now(), end: lg.end + 10, onDone, after: a, D };
      setBusy(true);
      if (kStart >= tap[0] - 1) tapFx(v, tap);
    }
    function tapFx(v, tap) {
      Snd.boom(); api.buzz(14); shake = 6;
      spawn(v.cx + tap[1] * v.s, v.cy + tap[2] * v.s, v.col, 14, 150);
    }
    function startIdle(D, al, kStart, label) {
      P = { kind: 'idle', view: mkView(D, al, null, kStart, kStart, '#fff'), t0: performance.now(), label };
      setBusy(false);
    }

    function sync() {
      if (!st || dead) return;
      if (isSolo()) return syncSolo();
      return syncVs();
    }
    function syncSolo() {
      const S = STAGES[st.k], ev = st.last || { id: 0, kd: 'go' };
      if (ev.id !== seenId) {
        seenId = ev.id;
        if (ev.kd === 'tap') {
          const D = dish(S.s, S.c), al = new Uint8Array(D.n).fill(1);
          let kA = 0;
          for (let q = 0; q < ev.i; q++) kA = chain(D, al, st.tp[q][0], st.tp[q][1], st.tp[q][2], null).end;
          const tap = st.tp[ev.i];
          const human = api.canAct(0);
          const kStart = human && P.kind === 'sent' ? tap[0] : Math.max(kA, tap[0] - 40);
          startChain(D, al, tap, kStart, myColor(0), () => afterSoloChain());
          P.view.base = st.pt.slice(0, ev.i).reduce((a, b) => a + b, 0);
          for (const m of MILE) if (m[0] <= P.view.base) P.view.mile = m[0];
        } else {
          if (st.k in NEWAT && api.canAct(0)) {
            const t = NEWAT[st.k];
            later(() => api.toast('새 구슬: ' + TNAME[t] + ' — ' + TDESC[t]), 300);
          } else if (STAGES[st.k].t > 1 && (st.k === 0 || STAGES[st.k - 1].t === 1) && api.canAct(0)) later(() => api.toast('이 단계는 두 번 터뜨려요! 첫 연쇄가 끝나면 한 번 더'), 300);
          soloReady();
        }
      }
      renderAll();
    }
    function soloReady() {
      const S = STAGES[st.k], D = dish(S.s, S.c);
      const info = soloAlive(st);
      const kA = st.tp.length ? st.ke : 0;
      if (st.dn) { startIdle(D, info.al, kA, null); return; }
      if (api.canAct(0)) startAim(0, D, info.al, kA, kA + TWS, true, 0);
      else startIdle(D, info.al, kA, 'AI가 고르는 중…');
    }
    function afterSoloChain() {
      if (st.dn) {
        try { U.store.set('chain.ss', mergedStars()); } catch (e) {}
        const p = st.pt.reduce((a, b) => a + b, 0);
        if (st.st > 0) { api.sfx('win'); banner = { txt: st.st === 3 ? '완벽해요!' : '성공!', t: 0, gold: true }; api.buzz(30); }
        else { api.sfx('lose'); }
        lastTopKey = '';
        startIdle(P.D, P.after, st.ke, null);
        if (st.st > 0 && p >= STAGES[st.k].g[2]) api.toast('완벽한 실험! ★★★');
      } else soloReady();
      renderAll();
    }
    function goStage(k) {
      if (!st || !isSolo() || !api.canAct(0) || busy || P.kind === 'chain') return;
      if (k < 0 || k >= NST || k > unlockedMax()) return;
      api.sfx('click');
      api.actAs(0, { t: 'go', k });
    }
    function soloCmd(t) {
      if (!st || !isSolo() || !api.canAct(0) || P.kind === 'chain') return;
      if (t === 'next' && !(st.dn && st.st > 0 && st.k < NST - 1)) return;
      if (t === 'retry' && !st.dn && !st.tp.length) return;
      api.sfx('click');
      api.actAs(0, { t });
    }

    // versus
    function myLocalSeats() { return api.mySeats().filter((i) => i < (st ? st.n : 0)); }
    function syncVs() {
      if (P.kind === 'chain' || P.kind === 'reveal' || P.kind === 'summary' || P.kind === 'curtain') { renderAll(); return; }
      if (P.kind === 'sent') {
        const tap = findMyTap(P);
        if (tap) {
          const D = P.D, al = new Uint8Array(D.n).fill(1);
          if (myLocalSeats().length > 1) { api.toast(nameOf(P.seat) + ' 완료! 결과는 라운드 끝에 공개'); P = { kind: 'none' }; }
          else { const rr = P.r; startChain(D, al, tap, tap[0], myColor(P.seat), () => afterMine(D, al, tap)); P.rr = rr; renderAll(); return; }
        } else { renderAll(); return; }
      }
      if (st.last && st.last.id > seenRev) { startReveal(st.last); renderAll(); return; }
      if (P.kind === 'aim' && !st.over && P.r === st.r && P.sd === st.sd && !st.tp[P.seat]) { renderAll(); return; }
      const need = st.over ? [] : myLocalSeats().filter((i) => !st.tp[i]);
      if (need.length) {
        const D = dish(st.sd, st.cf), al = new Uint8Array(D.n).fill(1);
        if (myLocalSeats().length > 1) showCurtain(need[0], () => startAim(need[0], D, al, 0, TWV, false, st.r));
        else startAim(need[0], D, al, 0, TWV, false, st.r);
        renderAll(); return;
      }
      if (P.kind === 'wait' && P.r === st.r) { renderAll(); return; }
      if (!st.over) {
        const D = dish(st.sd, st.cf), al = new Uint8Array(D.n).fill(1);
        const mine = myLocalSeats().find((i) => st.tp[i]);
        if (mine != null && myLocalSeats().length === 1) {
          const t = st.tp[mine], a = al.slice(); chain(D, a, t[0], t[1], t[2], null);
          P = { kind: 'wait', r: st.r, view: mkView(D, a, null, 0, chainEnd(D, t), '#fff'), t0: performance.now(), label: '다른 사람 기다리는 중…' };
        } else P = { kind: 'wait', r: st.r, view: mkView(D, al, null, 0, 0, '#fff'), t0: performance.now(), label: myLocalSeats().length ? '다른 사람 기다리는 중…' : '모두 고르는 중…' };
        setBusy(false);
      } else { P = { kind: 'none' }; setBusy(false); }
      renderAll();
    }
    function chainEnd(D, t) { const a = new Uint8Array(D.n).fill(1); return chain(D, a, t[0], t[1], t[2], null).end; }
    function afterMine(D, al, tap) {
      const a = al.slice(); const r = chain(D, a, tap[0], tap[1], tap[2], null);
      // if I was the last one, the reveal check in syncVs comes first
      P = { kind: 'wait', r: st.over ? -1 : st.r, view: mkView(D, a, null, r.end, r.end, '#fff'), t0: performance.now(), label: '다른 사람 기다리는 중…', my: r.pts };
      setBusy(false);
      sync();
    }
    function findMyTap(p) {
      if (!st) return null;
      if (!st.over && st.r === p.r && st.sd === p.sd && st.tp[p.seat]) return st.tp[p.seat];
      if (st.last && st.last.r === p.r && st.last.sd === p.sd && st.last.tp[p.seat]) return st.last.tp[p.seat];
      return null;
    }
    function startReveal(ev) {
      seenRev = ev.id;
      const D = dish(ev.sd, ev.cf), n = ev.tp.length;
      const items = [];
      for (let i = 0; i < n; i++) {
        const t = ev.tp[i], al = new Uint8Array(D.n).fill(1);
        const lg = chainLog(D, al.slice(), t[0], t[1], t[2]);
        const v = mkView(D, al, lg, t[0], Math.max(0, t[0] - 24), myColor(i));
        v.seat = i; v.endK = lg.end + 6;
        items.push(v);
      }
      P = { kind: 'reveal', ev, items, t0: performance.now(), e: 0 };
      revealLayout();
      setBusy(true);
      api.sfx('whoosh');
    }
    function revealLayout() {
      if (P.kind !== 'reveal' && P.kind !== 'summary') return;
      const items = P.items, n = items.length, lab = 26;
      const x0 = 8, x1 = G.W - 8, y0 = G.tH + 4, y1 = G.H - G.bH - 4;
      let cols = n <= 2 ? 1 : 2, rows = Math.ceil(n / cols);
      if (n === 2 && (x1 - x0) / 2 > (y1 - y0) / 2 + 30) { cols = 2; rows = 1; }
      const cw = (x1 - x0) / cols, rh = (y1 - y0) / rows;
      const r = Math.max(30, Math.min(cw / 2 - 8, (rh - lab) / 2 - 6));
      items.forEach((v, i) => {
        let c = i % cols, rr = Math.floor(i / cols);
        let cx = x0 + cw * (c + 0.5);
        if (n === 3 && i === 2) cx = (x0 + x1) / 2;
        v.cx = cx; v.cy = y0 + rh * rr + (rh - lab) / 2; v.s = r / DR; v.lab = v.cy + r + 16;
      });
    }
    function finishReveal() {
      if (P.kind !== 'reveal') return;
      const ev = P.ev, items = P.items;
      items.forEach((v) => { v.kf = v.endK; advanceSilently(v); });
      const best = Math.max(...ev.pt);
      P = { kind: 'summary', ev, items, t0: performance.now(), best };
      api.sfx(best > 0 ? 'chip' : 'click');
      const last = st.over && ev.r === st.R - 1;
      later(() => { if (P.kind === 'summary' && P.ev === ev) endSummary(); }, (last ? 1600 : 2600) / spd());
      renderAll();
    }
    function advanceSilently(v) {
      if (!v.lg) return;
      while (v.ptr < v.order.length && v.lg.pk[v.order[v.ptr]] <= v.kf) { const i = v.order[v.ptr++]; v.cnt++; v.pts += PT[v.D.ty[i]]; }
    }
    function endSummary() {
      if (P.kind !== 'summary' || P.final) return;
      if (st.over && P.ev.r === st.R - 1) { P.final = true; setBusy(false); renderAll(); return; }
      P = { kind: 'none' };
      setBusy(false);
      sync();
    }
    function showCurtain(seat, go) {
      P = { kind: 'curtain', seat };
      setBusy(false);
      const o = h('div', { class: 'overlay ch-cur' },
        h('span', { class: 'dot', style: { '--c': myColor(seat), width: '18px', height: '18px' } }),
        h('div', { class: 'big', text: nameOf(seat) + ' 차례' }),
        h('div', { class: 'muted', style: { textWrap: 'balance' } }, '다른 사람은 보지 말아 주세요.', h('br'), '시작을 누르면 구슬이 움직여요.'),
        h('button', { class: 'btn primary', text: '시작', style: { minWidth: '140px' }, onclick() { o.remove(); api.sfx('click'); if (P.kind === 'curtain' && P.seat === seat) go(); renderAll(); } }));
      root.appendChild(o);
      P.el = o;
    }

    /* ---------- input ---------- */
    function inDish(p, extra) { const dx = p.x - G.cx, dy = p.y - G.cy; return dx * dx + dy * dy <= (G.r + extra) * (G.r + extra); }
    function onDown(e) {
      if (P.kind !== 'aim') return;
      const p = cv.local(e);
      if (!inDish(p, 26)) return;
      ptr = { id: e.pointerId, x: p.x, y: p.y };
      try { cv.cv.setPointerCapture(e.pointerId); } catch (er) {}
      api.sfx('tick');
    }
    function onMove(e) {
      const p = cv.local(e);
      if (ptr && e.pointerId === ptr.id) { ptr.x = p.x; ptr.y = p.y; }
      else if (e.pointerType === 'mouse') hover = p;
    }
    function onUp(e) {
      if (!ptr || e.pointerId !== ptr.id) return;
      const p = cv.local(e);
      ptr = null;
      if (P.kind !== 'aim') return;
      if (!inDish(p, 4)) { api.toast('접시 밖에서 떼서 취소했어요'); return; }
      fire((p.x - G.cx) / G.s, (p.y - G.cy) / G.s);
    }
    function onCancel(e) { if (ptr && e.pointerId === ptr.id) ptr = null; }
    function onLeave(e) { if (e.pointerType === 'mouse') hover = null; }
    function fire(wx, wy) {
      if (P.kind !== 'aim') return;
      const d = Math.sqrt(wx * wx + wy * wy), lim = DR - 3;
      if (d > lim) { wx = wx / d * lim; wy = wy / d * lim; }
      const k = U.clamp(Math.round(P.kf), P.kA, P.kB);
      const a = { k, x: Math.round(wx * 10) / 10, y: Math.round(wy * 10) / 10 };
      const prevP = P;
      P = { kind: 'sent', seat: prevP.seat, D: prevP.D, r: prevP.r, sd: prevP.sd, view: prevP.view, k, x: a.x, y: a.y, t0: performance.now() };
      P.view.kf = k;
      api.sfx('whoosh');
      const sentT = P.t0;
      api.actAs(prevP.seat, a);
      if (P.kind === 'sent') later(() => { if (P.kind === 'sent' && P.t0 === sentT) { P = { kind: 'none' }; sync(); } }, 4000);
      renderAll();
    }
    cv.cv.addEventListener('pointerdown', onDown);
    cv.cv.addEventListener('pointermove', onMove);
    cv.cv.addEventListener('pointerup', onUp);
    cv.cv.addEventListener('pointercancel', onCancel);
    cv.cv.addEventListener('pointerleave', onLeave);
    const offInput = api.input && api.input.on ? api.input.on((type, id) => {
      if (type !== 'down') return;
      if (id === 'retry') soloCmd('retry');
      else if (id === 'next') { if (isSolo()) soloCmd('next'); else if (P.kind === 'summary') endSummary(); else if (P.kind === 'reveal') finishReveal(); }
      else if (id === 'skip') { if (P.kind === 'reveal') finishReveal(); else if (P.kind === 'summary') endSummary(); }
    }) : null;

    /* ---------- render panel/top ---------- */
    function renderAll() { renderTop(); renderPanel(); layout(); }
    function renderPanel() {
      if (!st) return;
      const k = P.kind;
      if (isSolo()) {
        const S = STAGES[st.k];
        if (k === 'aim') {
          const left = S.t - st.tp.length;
          setPanel('sa' + st.k + ':' + st.tp.length, (el) => el.append(hint((S.t > 1 ? '<b>' + (st.tp.length + 1) + '번째 탭</b> (남은 탭 ' + left + ') · ' : '') + '구슬이 몰린 순간 <b>꾹 눌렀다 떼면 펑!</b><br>접시 밖에서 떼면 취소 · 20초마다 처음 모습으로 되감겨요')));
        } else if (k === 'chain' || k === 'sent') setPanel('sc', (el) => el.append(hint('<b>연쇄 반응 중…</b>')));
        else if (st.dn) {
          const p = st.pt.reduce((a, b) => a + b, 0), ok = st.st > 0, can = api.canAct(0);
          setPanel('sd' + st.seq + can, (el) => {
            el.append(hint(ok ? '<b>' + p + '점</b> — ' + starTxt(st.st) + ' 성공!' + (st.k === NST - 1 ? ' 모든 단계를 깼어요!' : '') : '<b>' + p + '점</b> — 목표 ' + S.g[0] + '점까지 <span class="hot">' + (S.g[0] - p) + '점</span> 모자라요. 타이밍을 바꿔 보세요!'));
            if (can) el.append(h('div', { class: 'ch-row' },
              h('button', { class: 'btn' + (ok ? '' : ' primary'), text: '↻ 다시 하기', onclick: () => soloCmd('retry') }),
              ok && st.k < NST - 1 ? h('button', { class: 'btn primary', text: '다음 단계 ▶', onclick: () => soloCmd('next') }) : null));
          });
        } else setPanel('si' + st.seq, (el) => el.append(hint(P.label || '')));
        return;
      }
      const R = '라운드 <b>' + Math.min(st.R, (k === 'reveal' || k === 'summary' ? P.ev.r : P.rr != null ? P.rr : st.r) + 1) + '/' + st.R + '</b>';
      if (k === 'aim') setPanel('va' + st.r + ':' + P.seat, (el) => el.append(hint(R + ' · ' + (myLocalSeats().length > 1 ? '<b>' + nameOf(P.seat) + '</b> 차례 · ' : '') + '모두 같은 접시예요<br>구슬이 몰린 순간 <b>꾹 눌렀다 떼면 펑!</b> 딱 한 번뿐')));
      else if (k === 'sent' || k === 'chain') setPanel('vc' + st.r + ':' + P.rr, (el) => el.append(hint(R + ' · <b>연쇄 반응 중…</b>')));
      else if (k === 'wait') setPanel('vw' + st.r + ':' + (P.my != null ? P.my : '') + P.label, (el) => el.append(hint(R + (P.my != null ? ' · 내 점수 <b>' + P.my + '</b>점' : '') + '<br>' + P.label)));
      else if (k === 'reveal') setPanel('vr' + P.ev.id, (el) => {
        el.append(hint(R + ' 결과 · 모두의 연쇄를 나란히 봐요'));
        el.append(h('div', { class: 'ch-row' }, h('button', { class: 'btn', text: '건너뛰기 ⏭', onclick: finishReveal })));
      });
      else if (k === 'summary') setPanel('vs' + P.ev.id, (el) => {
        const ev = P.ev, best = Math.max(...ev.pt), w = ev.pt.map((v, i) => (v === best ? nameOf(i) : null)).filter(Boolean);
        el.append(hint(R + ' · 최고 연쇄 <b>' + w.join(', ') + ' ' + best + '점</b>'));
        if (!(st.over && ev.r === st.R - 1)) el.append(h('div', { class: 'ch-row' }, h('button', { class: 'btn primary', text: '다음 라운드 ▶', onclick: endSummary })));
      });
      else if (k === 'curtain') setPanel('vk', () => {});
      else setPanel('vn' + st.over, (el) => el.append(hint(st.over ? '게임 끝!' : '')));
    }

    /* ---------- frame ---------- */
    let lastNow = 0;
    function tick(dt, now) {
      const sp = spd();
      if (P.kind === 'aim') {
        // the clock stops while a tutorial / rules sheet covers the dish
        // (also when the app was in the background: rAF stopped → big gap)
        const gap = now - (lastNow || now);
        if (gap > 250 || document.querySelector('.tut-layer, .overlay.rules-ov')) P.t0 += gap;
        let kf = P.kA + (now - P.t0) / 1000 * FPS * sp;
        if (kf > P.kB) {
          if (P.loop) { P.t0 = now; kf = P.kA; banner = { txt: '되감기', t: 0, small: true }; api.sfx('whoosh'); }
          else { api.toast('시간 초과! 가운데에서 터졌어요'); P.kf = P.kB; fire(0, 0); return; }
        }
        P.kf = kf; P.view.kf = kf;
        const sec = Math.ceil((P.kB - kf) / FPS);
        if (sec !== lastSec) { lastSec = sec; if (sec <= 3 && !P.loop && sec > 0) api.sfx('tick'); }
      } else if (P.kind === 'chain') {
        const v = P.view;
        v.kf = v.kStart + (now - P.t0) / 1000 * FPS * sp;
        if (v.kf >= v.k0 && !P.fx && v.kStart < v.k0 - 1) { P.fx = 1; tapFx(v, [v.k0, v.lg.b.x[0], v.lg.b.y[0]]); }
        advance(v, true);
        if (v.kf >= P.end) {
          P.onDone();
        }
      } else if (P.kind === 'idle' || P.kind === 'wait') {
        P.view.kf = P.view.kStart + (now - P.t0) / 1000 * FPS * 0.6;
        if (P.view.kf > P.view.kStart + 900) P.t0 = now;
      } else if (P.kind === 'reveal') {
        P.e = (now - P.t0) / 1000 * FPS * 1.5 * sp;
        let all = true;
        for (const v of P.items) { v.kf = Math.min(v.endK, v.kStart + P.e); advance(v, false); if (v.kf < v.endK) all = false; }
        if (all) finishReveal();
      }
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i]; p.t += dt;
        if (p.t > p.l) { parts.splice(i, 1); continue; }
        p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= 0.92; p.vy *= 0.92;
      }
      for (let i = floaters.length - 1; i >= 0; i--) { floaters[i].t += dt; if (floaters[i].t > (floaters[i].big ? 1.6 : 0.9)) floaters.splice(i, 1); }
      if (banner) { banner.t += dt; if (banner.t > 1.3) banner = null; }
      shake *= 0.85;
      lastNow = now;
    }
    function draw() {
      ctx.setTransform(cv.dpr, 0, 0, cv.dpr, 0, 0);
      if (bgCv) ctx.drawImage(bgCv, 0, 0, cv.w, cv.h);
      else { ctx.fillStyle = '#17131f'; ctx.fillRect(0, 0, cv.w, cv.h); }
      if (!st || !dishCv) return;
      ctx.save();
      if (shake > 0.3) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
      if (P.kind === 'reveal' || P.kind === 'summary') drawReveal();
      else if (P.view) {
        P.view.cx = G.cx; P.view.cy = G.cy; P.view.s = G.s;
        drawView(P.view, true);
        if (P.kind === 'aim') drawAim();
        if (P.kind === 'sent') drawMark(G.cx + P.x * G.s, G.cy + P.y * G.s, 1);
        if (P.kind === 'chain') drawCounter(P.view);
        if ((P.kind === 'idle' || P.kind === 'wait') && P.label) drawLabel(P.label);
        if (P.kind === 'wait' && P.my != null) drawBig(P.my + '점', '#f2e9d8');
        if (isSolo() && st.dn && P.kind === 'idle') drawSoloResult();
      } else {
        ctx.drawImage(dishCv, G.cx - G.r - 16, G.cy - G.r - 16, (G.r + 16) * 2, (G.r + 16) * 2);
      }
      ctx.restore();
      // particles & floaters
      ctx.globalCompositeOperation = 'lighter';
      for (const p of parts) { ctx.globalAlpha = 1 - p.t / p.l; ctx.fillStyle = p.col; ctx.fillRect(p.x - 1.5, p.y - 1.5, 3, 3); }
      ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (const f of floaters) {
        const u = f.t / (f.big ? 1.6 : 0.9);
        ctx.globalAlpha = 1 - u * u;
        ctx.font = (f.big ? '40px ' : '15px ') + FONT_D;
        ctx.fillStyle = f.col; ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = f.big ? 5 : 3;
        const y = f.y - u * (f.big ? 30 : 22);
        ctx.strokeText(f.txt, f.x, y); ctx.fillText(f.txt, f.x, y);
      }
      ctx.globalAlpha = 1;
      if (banner) {
        const u = banner.t / 1.3, a = u < 0.15 ? u / 0.15 : u > 0.7 ? (1 - u) / 0.3 : 1, sc = 1 + (1 - Math.min(1, u * 5)) * 0.25;
        ctx.save(); ctx.globalAlpha = Math.max(0, a);
        ctx.translate(G.cx, G.cy + (banner.small ? 0 : -G.r * 0.35)); ctx.scale(sc, sc);
        ctx.font = (banner.small ? '30px ' : '34px ') + FONT_D;
        ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,8,15,0.75)'; ctx.strokeText(banner.txt, 0, 0);
        ctx.fillStyle = banner.gold ? '#ffd23f' : banner.small ? '#f2e9d8' : '#e3ae45'; ctx.fillText(banner.txt, 0, 0);
        ctx.restore();
      }
    }
    function drawMark(x, y, a) {
      ctx.globalAlpha = a; ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, 6, 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
    }
    function drawAim() {
      const frac = U.clamp((P.kB - P.kf) / (P.kB - P.kA), 0, 1);
      const R = G.r + 3, warn = !P.loop && P.kB - P.kf < 4 * FPS;
      ctx.lineCap = 'round';
      ctx.strokeStyle = 'rgba(242,233,216,0.12)'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(G.cx, G.cy, R, 0, 7); ctx.stroke();
      ctx.strokeStyle = warn ? '#ee6a55' : P.loop ? 'rgba(227,174,69,0.75)' : '#e3ae45'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(G.cx, G.cy, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac); ctx.stroke();
      // seconds
      const secs = Math.max(0, Math.ceil((P.kB - P.kf) / FPS));
      ctx.font = '600 13px ' + FONT_M; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = warn ? '#ee6a55' : 'rgba(242,233,216,0.75)';
      ctx.fillText((P.loop ? '⟲ ' : '') + secs + '초', G.cx, G.cy - G.r + 16);
      const p = ptr || hover;
      if (ptr && !inDish(ptr, 4)) {
        ctx.font = '700 13px ' + FONT_B; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,15,0.8)'; ctx.fillStyle = '#f2e9d8';
        const tx = U.clamp(ptr.x, 70, G.W - 70), ty = Math.max(G.tH + 12, ptr.y - 40);
        ctx.strokeText('여기서 떼면 취소', tx, ty); ctx.fillText('여기서 떼면 취소', tx, ty);
      } else if (p && inDish(p, 26)) {
        let wx = (p.x - G.cx) / G.s, wy = (p.y - G.cy) / G.s;
        const d = Math.sqrt(wx * wx + wy * wy); if (d > DR - 3) { wx = wx / d * (DR - 3); wy = wy / d * (DR - 3); }
        const x = G.cx + wx * G.s, y = G.cy + wy * G.s, rr = TAPR * G.s;
        const pressed = !!ptr, out = false;
        ctx.save();
        ctx.setLineDash([6, 5]); ctx.lineWidth = 2;
        ctx.strokeStyle = out ? 'rgba(171,159,184,0.7)' : pressed ? '#fff' : 'rgba(242,233,216,0.55)';
        ctx.beginPath(); ctx.arc(x, y, rr, 0, 7); ctx.stroke();
        ctx.setLineDash([]);
        if (pressed && !out) { ctx.globalAlpha = 0.14; ctx.fillStyle = myColor(P.seat); ctx.beginPath(); ctx.arc(x, y, rr, 0, 7); ctx.fill(); ctx.globalAlpha = 1; }
        ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(x - 6, y); ctx.lineTo(x + 6, y); ctx.moveTo(x, y - 6); ctx.lineTo(x, y + 6); ctx.stroke();
        ctx.restore();
      }
    }
    function drawCounter(v) {
      if (!v.cnt) return;
      v.bump *= 0.86;
      ctx.save();
      ctx.translate(G.cx, G.cy + G.r * 0.62);
      const sc = 1 + v.bump * 0.35; ctx.scale(sc, sc);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 34px ' + FONT_M;
      ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,8,15,0.7)';
      const tot = v.pts + (v.base || 0);
      ctx.strokeText(String(tot), 0, 0);
      ctx.fillStyle = tot >= 20 ? '#ffd23f' : '#f2e9d8'; ctx.fillText(String(tot), 0, 0);
      ctx.font = '12px ' + FONT_B; ctx.fillStyle = 'rgba(242,233,216,0.8)';
      ctx.strokeText('연쇄 ' + v.cnt + '개', 0, 24); ctx.fillText('연쇄 ' + v.cnt + '개', 0, 24);
      ctx.restore();
    }
    function drawLabel(txt) {
      ctx.font = '600 14px ' + FONT_B; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const w = ctx.measureText(txt).width + 24, y = G.cy + G.r * 0.62;
      ctx.fillStyle = 'rgba(10,8,15,0.6)'; roundRect(G.cx - w / 2, y - 15, w, 30, 15); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.fillText(txt, G.cx, y);
    }
    function drawBig(txt, col) {
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 40px ' + FONT_M; ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,8,15,0.7)';
      ctx.strokeText(txt, G.cx, G.cy - 10); ctx.fillStyle = col; ctx.fillText(txt, G.cx, G.cy - 10);
    }
    function drawSoloResult() {
      const p = st.pt.reduce((a, b) => a + b, 0);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '700 40px ' + FONT_M; ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(10,8,15,0.7)';
      ctx.strokeText(p + '점', G.cx, G.cy - 10);
      ctx.fillStyle = st.st > 0 ? '#ffd23f' : '#f2e9d8'; ctx.fillText(p + '점', G.cx, G.cy - 10);
      for (let q = 0; q < 3; q++) drawStar(G.cx + (q - 1) * 34, G.cy + 30, 13, q < st.st);
    }
    function drawStar(x, y, r, on) {
      ctx.beginPath();
      for (let q = 0; q < 10; q++) {
        const a = -Math.PI / 2 + q * Math.PI / 5, rr = q & 1 ? r * 0.45 : r;
        if (q) ctx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); else ctx.moveTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.lineJoin = 'round';
      if (on) { ctx.fillStyle = '#ffd23f'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#8a5a12'; ctx.stroke(); }
      else { ctx.fillStyle = 'rgba(10,8,15,0.5)'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(242,233,216,0.4)'; ctx.stroke(); }
    }
    function roundRect(x, y, w, hh, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
    function drawReveal() {
      revealLayout();
      const summ = P.kind === 'summary', best = summ ? P.best : -1;
      const mine = api.mySeats();
      for (const v of P.items) {
        drawView(v, false);
        const R = DR * v.s;
        if (mine.length === 1 && mine[0] === v.seat) { ctx.strokeStyle = 'rgba(227,174,69,0.7)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(v.cx, v.cy, R + 9, 0, 7); ctx.stroke(); }
        // label
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        const nm = nameOf(v.seat), txt = nm + '  ';
        ctx.font = '700 13px ' + FONT_B;
        const w1 = ctx.measureText(txt).width;
        ctx.font = '700 15px ' + FONT_M;
        const w2 = ctx.measureText(v.pts + '점').width;
        const W = w1 + w2 + 14, x0 = v.cx - W / 2;
        ctx.fillStyle = myColor(v.seat); ctx.beginPath(); ctx.arc(x0 + 4, v.lab, 4, 0, 7); ctx.fill();
        ctx.textAlign = 'left'; ctx.font = '700 13px ' + FONT_B; ctx.fillStyle = '#f2e9d8'; ctx.fillText(txt, x0 + 12, v.lab);
        ctx.font = '700 15px ' + FONT_M; ctx.fillStyle = summ && v.pts === best ? '#ffd23f' : '#f2e9d8'; ctx.fillText(v.pts + '점', x0 + 12 + w1, v.lab);
        if (summ && v.pts === best && best > 0) {
          ctx.textAlign = 'center'; ctx.font = '18px ' + FONT_D; ctx.fillStyle = '#ffd23f';
          ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(10,8,15,0.7)';
          ctx.strokeText('최고!', v.cx, v.cy - R + 14); ctx.fillText('최고!', v.cx, v.cy - R + 14);
        }
      }
    }

    const stopLoop = U.loop((dt, now) => { if (dead) return; tick(dt, now); draw(); });

    return {
      update(next, prev) {
        const old = st;
        st = next;
        const fresh = !old || !prev || old.md !== next.md || old.n !== next.n || (next.seq | 0) < (old.seq | 0) || (next.md === 'v' && old.R !== next.R) || (next.md === 'v' && next.r < old.r);
        if (fresh) {
          if (P.el) P.el.remove();
          P = { kind: 'none' }; seenId = -1; lastTopKey = ''; lastPanelKey = '';
          seenRev = next.md === 'v' && next.last ? next.last.id : 0;
          setBusy(false);
        }
        renderTop();
        layout();
        if (next.md === 's' && !autoJumped) {
          autoJumped = true;
          if (!api.online && next.seq === 0 && next.k === 0 && api.canAct(0)) {
            const k = unlockedMax();
            if (k > 0) { later(() => { if (st && st.md === 's' && st.seq === 0 && P.kind !== 'chain') { api.actAs(0, { t: 'go', k }); api.toast((k + 1) + '단계부터 이어서 해요'); } }, 60); }
          }
        }
        sync();
        layout();
      },
      destroy() {
        dead = true;
        stopLoop();
        timers.forEach(clearTimeout); timers.clear();
        if (offInput) try { offInput(); } catch (e) {}
        if (busy) api.setBusy(false);
        cv.cv.removeEventListener('pointerdown', onDown); cv.cv.removeEventListener('pointermove', onMove);
        cv.cv.removeEventListener('pointerup', onUp); cv.cv.removeEventListener('pointercancel', onCancel); cv.cv.removeEventListener('pointerleave', onLeave);
        if (P.el) P.el.remove();
        cv.destroy(); top.remove(); panel.remove(); dishMark.remove(); style.remove();
      },
    };
  }

  L.register({
    id: 'chain', name: '연쇄 반응 실험실', tag: '연쇄 폭발 퍼즐', cat: '아케이드',
    blurb: '접시 속 떠다니는 반응 구슬을 딱 한 번 터뜨려요. 폭발에 닿은 구슬도 터지며 연쇄가 퍼져요! 혼자면 24단계 실험, 여럿이면 같은 접시로 점수 대결.',
    tint: '#14505a',
    icon: '<circle cx="28" cy="28" r="23" fill="none" stroke="currentColor" stroke-width="3"/><circle cx="24" cy="30" r="10" fill="currentColor" opacity=".3"/><circle cx="24" cy="30" r="4.5" fill="currentColor"/><circle cx="37" cy="20" r="6.5" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="3 2"/><circle cx="37" cy="20" r="2.5" fill="currentColor"/><circle cx="39" cy="37" r="3" fill="currentColor"/><circle cx="16" cy="17" r="2.5" fill="currentColor"/><circle cx="23" cy="44" r="2.5" fill="currentColor" opacity=".7"/><path d="M24 17v-3M24 46v-3M11 30H8M37 30h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    quick: [
      '접시 속 반응 구슬을 딱 한 번 터뜨려요. 폭발에 닿은 구슬도 터지며 연쇄가 퍼져요.',
      '구슬이 몰린 순간 접시를 꾹 눌렀다 떼면 펑! (접시 밖에서 떼면 취소)',
      '여럿이면 같은 접시로 라운드마다 한 번씩 — 점수 합계가 높으면 승리. 혼자면 24단계 목표 점수 도전!',
    ],
    rules: [
      { h: '목표', p: [
        '실험 접시 안에 반응 구슬들이 둥둥 떠다녀요.',
        '내가 한 곳을 터뜨리면, 그 폭발에 닿은 구슬도 터지고, 그 폭발이 또 옆 구슬을 터뜨려요. 이게 연쇄 반응!',
        '터진 구슬 하나가 1점(황금 구슬은 2점). 점수를 많이 내면 이겨요.'] },
      { h: '차례에 할 일', p: [
        '접시를 보다가 구슬이 많이 몰린 순간을 노려 꾹 눌렀다 떼요. 뗀 자리에서 펑!',
        '한 판(라운드)에 딱 한 번만 터뜨릴 수 있어요. 그다음은 연쇄를 지켜보기만 해요.',
        '여럿이 할 때는 모두 동시에 각자 한 번씩 해요. 15초 안에 안 터뜨리면 접시 가운데에서 저절로 터져요.'] },
      { h: '연쇄 규칙', p: [
        '폭발은 빠르게 커졌다가 1초쯤 머문 뒤 작아져요.',
        '폭발이 남아 있는 동안 닿는 구슬은 모두 터져서 자기 폭발을 만들어요.',
        '구슬은 계속 움직이니까 폭발 쪽으로 흘러 들어와 터지기도 해요. 구슬끼리는 부딪히지 않고, 접시 벽에서 튕겨요.'] },
      { h: '특수 구슬', p: [
        '큰 구슬(흰 고리): 폭발이 훨씬 커요.',
        '황금 구슬(반짝이 별): 터지면 2점!',
        '분열 구슬(주변에 점 3개): 터지면 그 점 방향으로 불꽃 3개가 날아가, 지나가는 구슬을 터뜨려요.',
        '시간차 구슬(검은 심지): 닿으면 불이 붙고 1초 뒤에 터져요. 그동안 계속 움직여서 멀리 있는 구슬까지 이어 줘요.',
        '지속 폭발 구슬(점선 고리): 폭발이 4초 동안 오래 머물러요. 흘러 들어오는 구슬을 계속 잡아요.'] },
      { h: '점수·승리', p: [
        '대결: 라운드마다 모두 같은 접시(같은 배치·같은 움직임)로 해요. 내가 언제 어디를 터뜨렸는지만 달라요.',
        '라운드가 끝나면 모두의 연쇄를 작은 접시로 나란히 다시 보여 줘요.',
        '정한 라운드(3·5·7, 기본 5)가 끝나면 점수 합계가 가장 높은 사람이 이겨요. 같으면 함께 승리.'] },
      { h: '혼자 하기 (24단계)', p: [
        '1명이면 24단계 실험이에요. 목표 점수를 넘으면 성공(★), 더 높으면 ★★·★★★.',
        '단계마다 접시 모습과 움직임이 늘 같아서, 다시 할수록 좋은 타이밍을 찾을 수 있어요.',
        '몇몇 단계는 두 번 터뜨려요. 첫 연쇄가 다 끝난 뒤, 남은 구슬로 한 번 더!',
        '혼자 할 땐 시간 제한이 없어요. 20초가 지나면 접시가 처음 모습으로 되감겨요.',
        '깬 단계와 별은 이 기기에 기억돼요. 위쪽 ◀ ▶로 깬 단계(와 그다음 단계)를 골라요.'] },
      { h: '조작', p: [
        '접시를 꾹 누르면 폭발 크기만 한 동그라미가 보여요. 누른 채로 끌어 자리를 맞추고, 떼면 펑!',
        '마음이 바뀌면 접시 밖으로 끌고 나가서 떼요(취소).',
        '마우스: 접시 위에 올리면 동그라미가 보이고, 클릭하면 펑. 키보드: R 다시 하기 · Enter 다음 · Space 건너뛰기.'] },
      { h: '예시', p: [
        '구슬 다섯 개가 가운데로 모여드는 순간, 그 한가운데에서 손을 떼요.',
        '→ 다섯 개가 함께 터지고, 그 폭발이 옆을 지나던 큰 구슬을 건드려 큰 폭발!',
        '→ 큰 폭발이 주변 구슬 여덟 개를 더 터뜨리고… 연쇄 14개 = 14점. 그중 황금 구슬이 2개였다면 16점!'] },
      { h: 'AI', p: [
        'AI 난이도는 자리마다 쉬움·보통·어려움으로 고를 수 있어요.',
        '쉬움: 몇 군데만 대충 보고 가끔 엉뚱한 곳을 터뜨려요. 보통: 여러 순간을 살펴보고 좋은 곳을 골라요. 어려움: 훨씬 많이 살펴보고 자리와 타이밍을 다듬어요.'] },
    ],
    tutorial: [
      { sel: '.ch-dish', text: '실험 접시예요. 반응 구슬들이 둥둥 떠다녀요. 폭발에 닿은 구슬은 같이 터지고, 그 폭발이 또 옆 구슬을 터뜨려요 — 연쇄 반응!' },
      { sel: '.ch-dish', text: '접시를 꾹 누르면 폭발 크기 동그라미가 보여요. 구슬이 많이 몰린 순간에 손을 떼면 펑! 딱 한 번뿐이에요. (접시 밖에서 떼면 취소)' },
      { sel: '.ch-dish', text: '특수 구슬: 큰 구슬(폭발 큼) · 황금(2점) · 분열(점 방향으로 불꽃 3개) · 시간차(1초 뒤 터짐) · 지속(폭발이 오래 머묾).' },
      { sel: '.ch-panel', text: '할 일과 남은 시간이 여기 보여요. 대결은 15초 안에 안 터뜨리면 가운데에서 저절로 터져요. 혼자 할 땐 20초마다 처음 모습으로 되감겨요.' },
      { sel: '.ch-top', text: '여럿이면 위에 점수 합계가 보여요. 모두 같은 접시로 동시에 한 번씩 — 라운드 끝에 모두의 연쇄를 나란히 비교해요. 혼자면 ◀ ▶로 단계를 골라요. 그럼 시작!' },
    ],
    controls: [
      { id: 'retry', label: '다시 하기(혼자)', keys: ['KeyR'], pad: ['x'] },
      { id: 'next', label: '다음 단계 / 다음 라운드', keys: ['Enter', 'KeyN'], pad: ['a'] },
      { id: 'skip', label: '결과 건너뛰기', keys: ['Space'], pad: ['b'] },
    ],
    minPlayers: 1, maxPlayers: 4, defaultPlayers: 2, hidden: false, aiDelay: 1200,
    options: [
      { id: 'rounds', label: '라운드', choices: [{ v: 3, label: '3' }, { v: 5, label: '5' }, { v: 7, label: '7' }], def: 5 },
      { id: 'mix', label: '특수 구슬', choices: [{ v: 1, label: '섞기' }, { v: 0, label: '기본 구슬만' }], def: 1 },
    ],
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { gen, dish, ensure, chain, chainLog, search, pickTap, STAGES, soloAlive, starsOf, posAt, radAt, TWV, TWS, DR, FPS, OR, BR, BH, PT, life, GROW, SHRINK, FUSE, SPV, SPL, SPR, TAPR, TAPH, SPK },
  });
})();
