/* 텍사스 홀덤 — no-limit hold'em, 1000 chips, blinds double every 5 hands, 12 hands max. */
(function () {
  const L = window.Lounge, U = L.util;
  const MAXH = 12, START = 1000;
  const RK = '23456789TJQKA', SU = 'SHDC';
  const HNAME = ['하이카드', '원페어', '투페어', '트리플', '스트레이트', '플러시', '풀하우스', '포카드', '스트레이트 플러시', '로열 플러시'];
  const split2 = (str) => { const a = []; for (let i = 0; i < str.length; i += 2) a.push(str.slice(i, i + 2)); return a; };
  const toInt = (c) => RK.indexOf(c[0]) * 4 + SU.indexOf(c[1]);

  /* ---------- fast evaluator: higher score = better ---------- */
  const RC = new Int8Array(13), SC = new Int8Array(4), SM = new Int32Array(4);
  function straightTop(m) {
    for (let t = 12; t >= 4; t--) if (((m >> (t - 4)) & 31) === 31) return t;
    if ((m & 15) === 15 && (m & 4096)) return 3; // wheel A-2-3-4-5
    return -1;
  }
  function evalN(cards, n) {
    RC.fill(0); SC.fill(0); SM.fill(0);
    let mask = 0;
    for (let i = 0; i < n; i++) { const c = cards[i], r = c >> 2, s = c & 3; RC[r]++; SC[s]++; SM[s] |= 1 << r; mask |= 1 << r; }
    let fs = -1;
    for (let s = 0; s < 4; s++) if (SC[s] >= 5) fs = s;
    if (fs >= 0) { const t = straightTop(SM[fs]); if (t >= 0) return (8 << 20) | (t << 16); }
    let q = -1, t1 = -1, t2 = -1, p1 = -1, p2 = -1;
    for (let r = 12; r >= 0; r--) {
      const k = RC[r];
      if (k === 4) q = r;
      else if (k === 3) { if (t1 < 0) t1 = r; else if (t2 < 0) t2 = r; }
      else if (k === 2) { if (p1 < 0) p1 = r; else if (p2 < 0) p2 = r; }
    }
    const kick = (ex1, ex2, cnt, sh) => { let v = 0; for (let r = 12; r >= 0 && cnt > 0; r--) if (RC[r] && r !== ex1 && r !== ex2) { v |= r << sh; sh -= 4; cnt--; } return v; };
    if (q >= 0) return (7 << 20) | (q << 16) | kick(q, -1, 1, 12);
    if (t1 >= 0 && (t2 >= 0 || p1 >= 0)) return (6 << 20) | (t1 << 16) | (Math.max(t2, p1) << 12);
    if (fs >= 0) { let v = 5 << 20, sh = 16, cnt = 5; for (let r = 12; r >= 0 && cnt; r--) if (SM[fs] & (1 << r)) { v |= r << sh; sh -= 4; cnt--; } return v; }
    const st = straightTop(mask);
    if (st >= 0) return (4 << 20) | (st << 16);
    if (t1 >= 0) return (3 << 20) | (t1 << 16) | kick(t1, -1, 2, 12);
    if (p1 >= 0 && p2 >= 0) return (2 << 20) | (p1 << 16) | (p2 << 12) | kick(p1, p2, 1, 8);
    if (p1 >= 0) return (1 << 20) | (p1 << 16) | kick(p1, -1, 3, 12);
    return kick(-1, -1, 5, 16);
  }
  function handName(v) { const c = v >> 20; return c === 8 && ((v >> 16) & 15) === 12 ? HNAME[9] : HNAME[c]; }
  function evalStr(str) { const a = split2(str).map(toInt); return evalN(a, a.length); }

  /* ---------- hand helper (viewer only): made hand + draws from the cards this player can see ---------- */
  const RN = (r) => (r === 8 ? '10' : RK[r]);
  const toStr = (c) => RK[c >> 2] + SU[c & 3];
  function comb(n, k) { if (k < 0 || k > n) return 0; let v = 1; for (let i = 0; i < k; i++) v = (v * (n - i)) / (i + 1); return v; }
  const B5 = new Int8Array(5);
  function best5(cards) {
    const n = cards.length;
    let best = -1, pick = null;
    for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) for (let c = b + 1; c < n; c++) for (let d = c + 1; d < n; d++) for (let e = d + 1; e < n; e++) {
      B5[0] = cards[a]; B5[1] = cards[b]; B5[2] = cards[c]; B5[3] = cards[d]; B5[4] = cards[e];
      const v = evalN(B5, 5);
      if (v > best) { best = v; pick = [cards[a], cards[b], cards[c], cards[d], cards[e]]; }
    }
    return { v: best, pick };
  }
  const catOf = (arr) => evalN(arr, arr.length) >> 20;
  /* returns {made, tag, sub, keys:[card strings], draws:[{t, n, p, rr}], k} — uses only hole + board */
  function analyze(holeStr, boardStr) {
    const hole = split2(holeStr).map(toInt), board = split2(boardStr).map(toInt);
    if (hole.length !== 2 || (board.length && board.length < 3)) return null;
    const [h1, h2] = hole, r1 = h1 >> 2, r2 = h2 >> 2, hi = Math.max(r1, r2), lo = Math.min(r1, r2);
    const out = { made: '', tag: '', sub: '', keys: [], draws: [], k: 5 - board.length };
    if (!board.length) {
      const suited = (h1 & 3) === (h2 & 3), conn = hi - lo === 1 || (hi === 12 && lo === 0);
      const pair = RN(hi) + '·' + RN(lo);
      if (r1 === r2) { out.made = '포켓 페어 (' + RN(hi) + ')'; out.keys = [toStr(h1), toStr(h2)]; out.sub = '플랍에서 세트 약 12%'; }
      else if (suited && conn) out.made = '수티드 커넥터 (' + pair + ')';
      else if (suited) out.made = '수티드 (' + pair + ')';
      else if (conn) out.made = '커넥터 (' + pair + ')';
      else out.made = '하이카드 (' + pair + ')';
      return out;
    }
    const all = hole.concat(board);
    const { v, pick } = best5(all);
    const c = v >> 20, a = (v >> 16) & 15, b = (v >> 12) & 15;
    let keys;
    if (c === 0) keys = [pick.reduce((m, x) => ((x >> 2) > (m >> 2) ? x : m), pick[0])];
    else if (c === 1 || c === 3 || c === 7) keys = pick.filter((x) => (x >> 2) === a);
    else if (c === 2) keys = pick.filter((x) => (x >> 2) === a || (x >> 2) === b);
    else keys = pick;
    out.keys = keys.map(toStr);
    out.made = c === 0 ? '하이카드 (' + RN(a) + ')' : c === 1 ? '원페어 (' + RN(a) + ')' : c === 2 ? '투페어 (' + RN(a) + ', ' + RN(b) + ')'
      : c === 3 ? '트리플 (' + RN(a) + ')' : c === 4 ? '스트레이트 (' + RN(a) + ' 하이)' : c === 5 ? '플러시 (' + RN(a) + ' 하이)'
      : c === 6 ? '풀하우스 (' + RN(a) + ', ' + RN(b) + ')' : c === 7 ? '포카드 (' + RN(a) + ')' : a === 12 ? '로열 플러시' : '스트레이트 플러시 (' + RN(a) + ' 하이)';
    if (!keys.some((x) => x === h1 || x === h2)) out.tag = '보드';
    else if (c === 3 && r1 === r2 && r1 === a) out.tag = '세트';
    if (board.length >= 5) return out;
    // draws: exact outs among unseen cards (opponents' hidden cards count as unseen, as usual)
    const known = new Set(all), unseen = [];
    for (let x = 0; x < 52; x++) if (!known.has(x)) unseen.push(x);
    const N = unseen.length, k = out.k;
    const pHit = (n) => 1 - comb(N - n, k) / comb(N, k);
    const cur = catOf(all);
    const ds = [];
    const add = (t, cards, pri) => { if (cards.length) ds.push({ t, cards, n: cards.length, p: pHit(cards.length), pri }); };
    if (cur < 5) for (let s = 0; s < 4; s++) {
      const tot = all.filter((x) => (x & 3) === s).length, hs = hole.filter((x) => (x & 3) === s).length;
      if (!hs) continue;
      const left = unseen.filter((x) => (x & 3) === s);
      if (tot === 4) add('플러시 드로우', left, 10);
      else if (tot === 3 && k === 2) ds.push({ t: '백도어 플러시', n: left.length, p: comb(left.length, 2) / comb(N, 2), rr: 1, pri: 1, cards: [] });
    }
    if (cur < 4) {
      let mask = 0, bmask = 0;
      for (const x of all) mask |= 1 << (x >> 2);
      for (const x of board) bmask |= 1 << (x >> 2);
      const outR = [];
      for (let r = 0; r < 13; r++) {
        if ((mask >> r) & 1) continue;
        const t = straightTop(mask | (1 << r));
        if (t >= 0 && t > straightTop(bmask | (1 << r))) outR.push([r, t]);
      }
      if (outR.length) {
        let t;
        if (outR.length === 1) {
          const [r, top] = outR[0];
          const end = top === 3 ? r === 12 || r === 3 : r === top || r === top - 4;
          t = end ? '스트레이트 드로우 (한쪽)' : '거트샷 스트레이트 드로우';
        } else if (outR.length === 2) t = Math.abs(outR[0][1] - outR[1][1]) === 1 ? '오픈엔디드 스트레이트 드로우' : '더블 거트샷 스트레이트 드로우';
        else t = '스트레이트 드로우';
        add(t, unseen.filter((x) => outR.some((o) => o[0] === (x >> 2))), outR.length >= 2 ? 9 : 7);
      }
    }
    const withC = (x) => catOf(all.concat([x])), boardC = (x) => catOf(board.concat([x]));
    if (r1 === r2 && cur === 1) add('세트 가능성', unseen.filter((x) => (x >> 2) === r1), 8);
    if (cur === 2 || cur === 3) {
      const o = unseen.filter((x) => withC(x) >= 6 && boardC(x) < 6);
      add(cur === 3 && o.some((x) => withC(x) === 7) ? '풀하우스·포카드 가능' : '풀하우스 가능', o, 8);
    }
    if (cur <= 1 && r1 !== r2) {
      const o = unseen.filter((x) => ((x >> 2) === r1 || (x >> 2) === r2) && withC(x) > cur);
      if (cur === 0) add('원페어 가능', o, 3);
      else add(o.some((x) => withC(x) === 3) ? '투페어·트리플 가능' : '투페어 가능', o, 3);
    }
    ds.sort((x, y) => y.pri - x.pri);
    const strong = ds.filter((d) => d.pri >= 7);
    if (strong.length >= 2) {
      const u = new Set(); strong.forEach((d) => d.cards.forEach((x) => u.add(x)));
      out.total = { n: u.size, p: pHit(u.size) };
    }
    out.draws = ds.slice(0, 2).map((d) => ({ t: d.t, n: d.n, p: d.p, rr: d.rr || 0 }));
    return out;
  }

  /* ---------- logic ---------- */
  const blinds = (s) => { const lv = Math.floor((s.hn - 1) / 5); return [10 << lv, 20 << lv]; };
  function nextWith(s, from, pred) { for (let k = 1; k <= s.n; k++) { const i = (((from + k) % s.n) + s.n) % s.n; if (pred(i)) return i; } return -1; }
  function positions(s, prevBtn) {
    const has = (i) => s.ch[i] > 0;
    const bn = nextWith(s, prevBtn, has);
    const alive = s.ch.filter((c) => c > 0).length;
    let sb, bb, first;
    if (alive === 2) { sb = bn; bb = nextWith(s, bn, has); first = bn; }
    else { sb = nextWith(s, bn, has); bb = nextWith(s, sb, has); first = nextWith(s, bb, has); }
    return { bn, sb, bb, first };
  }
  function init(players) {
    const n = players.length;
    const s = {
      n, nm: players.map((p) => String(p.name).slice(0, 10)), ch: Array(n).fill(START), hn: 0, bn: -1, sb: -1, bb: -1,
      dk: '', h: Array(n).fill(''), bd: '', ph: 'pre', cb: Array(n).fill(0), tc: Array(n).fill(0), st: '', ra: Array(n).fill(-1),
      la: Array(n).fill(''), bt: 0, mr: 20, fr: 0, cur: -1, nx: -1, res: null, seq: 0, last: null, over: 0,
    };
    startHand(s);
    return s;
  }
  const setSt = (s, i, c) => { s.st = s.st.slice(0, i) + c + s.st.slice(i + 1); };
  function put(s, i, a) { a = Math.min(a, s.ch[i]); s.ch[i] -= a; s.cb[i] += a; s.tc[i] += a; if (s.ch[i] === 0) setSt(s, i, 'x'); return a; }
  function startHand(s) {
    s.hn++;
    const p = positions(s, s.bn);
    s.bn = p.bn; s.sb = p.sb; s.bb = p.bb;
    const d = [];
    for (const r of RK) for (const su of SU) d.push(r + su);
    U.shuffle(d);
    s.st = s.ch.map((c) => (c > 0 ? 'a' : 'o')).join('');
    s.h = Array(s.n).fill(''); s.bd = ''; s.ph = 'pre'; s.res = null; s.nx = -1;
    s.cb = Array(s.n).fill(0); s.tc = Array(s.n).fill(0); s.ra = Array(s.n).fill(-1); s.la = Array(s.n).fill('');
    let k = 0;
    for (let r = 0; r < 2; r++) for (let j = 0; j < s.n; j++) { const i = (s.sb + j) % s.n; if (s.st[i] !== 'o') s.h[i] += d[k++]; }
    s.dk = d.slice(k).join('');
    const [sbA, bbA] = blinds(s);
    put(s, s.sb, sbA); put(s, s.bb, bbA);
    s.bt = Math.max(bbA, ...s.cb); s.mr = bbA; s.fr = 0; // a short all-in blind still leaves the full big blind to call
    s.cur = findNext(s, p.first);
    if (s.cur < 0) endRound(s);
  }
  const nonFolded = (s) => { let k = 0; for (let i = 0; i < s.n; i++) if (s.st[i] === 'a' || s.st[i] === 'x') k++; return k; };
  function findNext(s, start) {
    const act = [];
    for (let i = 0; i < s.n; i++) if (s.st[i] === 'a') act.push(i);
    if (!act.length) return -1;
    if (act.length === 1) { // nobody left to bet against: act only if still behind what an all-in player put in
      let mx = 0; for (let i = 0; i < s.n; i++) if (i !== act[0] && s.st[i] !== 'o') mx = Math.max(mx, s.cb[i]);
      if (s.cb[act[0]] >= mx) return -1;
    }
    for (let k = 0; k < s.n; k++) { const i = (start + k) % s.n; if (s.st[i] === 'a' && (s.ra[i] < 0 || s.cb[i] < s.bt)) return i; }
    return -1;
  }
  function take(s, k) { const c = s.dk.slice(0, k * 2); s.dk = s.dk.slice(k * 2); return c; }
  function endRound(s) {
    if (nonFolded(s) <= 1) return awardFold(s);
    if (s.ph === 'river') return showdown(s);
    take(s, 1); // burn
    if (s.ph === 'pre') { s.bd += take(s, 3); s.ph = 'flop'; }
    else if (s.ph === 'flop') { s.bd += take(s, 1); s.ph = 'turn'; }
    else { s.bd += take(s, 1); s.ph = 'river'; }
    s.cb = Array(s.n).fill(0); s.ra = Array(s.n).fill(-1); s.bt = 0; s.fr = 0; s.mr = blinds(s)[1];
    for (let i = 0; i < s.n; i++) if (s.st[i] === 'a') s.la[i] = '';
    s.cur = findNext(s, (s.bn + 1) % s.n);
    if (s.cur < 0) endRound(s);
  }
  function awardFold(s) {
    let w = -1;
    for (let i = 0; i < s.n; i++) if (s.st[i] === 'a' || s.st[i] === 'x') w = i;
    const pot = s.tc.reduce((a, b) => a + b, 0);
    s.ch[w] += pot;
    s.res = { w: [[w, pot, 1]], sd: 0, hn: '' };
    finishHand(s);
  }
  function showdown(s) {
    const live = [];
    const score = Array(s.n).fill(-1);
    for (let i = 0; i < s.n; i++) if (s.st[i] === 'a' || s.st[i] === 'x') { live.push(i); score[i] = evalStr(s.h[i] + s.bd); }
    const levels = [...new Set(live.map((i) => s.tc[i]))].sort((a, b) => a - b);
    const won = Array(s.n).fill(0), contested = Array(s.n).fill(0);
    const order = []; for (let k = 1; k <= s.n; k++) order.push((s.bn + k) % s.n);
    let prev = 0, best = -1;
    for (const lv of levels) {
      let slice = 0;
      for (let i = 0; i < s.n; i++) slice += Math.min(s.tc[i], lv) - Math.min(s.tc[i], prev);
      const elig = live.filter((i) => s.tc[i] >= lv);
      prev = lv;
      if (slice <= 0) continue;
      const top = Math.max(...elig.map((i) => score[i]));
      const ws = order.filter((i) => elig.indexOf(i) >= 0 && score[i] === top);
      const share = Math.floor(slice / ws.length);
      let odd = slice - share * ws.length;
      for (const i of ws) { won[i] += share + (odd > 0 ? 1 : 0); if (odd > 0) odd--; if (elig.length > 1) contested[i] = 1; }
      if (elig.length > 1) best = Math.max(best, top);
    }
    const w = [];
    for (let i = 0; i < s.n; i++) if (won[i] > 0) { s.ch[i] += won[i]; w.push([i, won[i], contested[i]]); }
    const names = {};
    for (const i of live) names[i] = handName(score[i]);
    s.res = { w, sd: 1, hn: best >= 0 ? handName(best) : '', nm: names };
    finishHand(s);
  }
  function finishHand(s) {
    s.ph = 'end'; s.cur = -1;
    s.tc = Array(s.n).fill(0); s.cb = Array(s.n).fill(0);
    const alive = s.ch.filter((c) => c > 0).length;
    if (alive <= 1 || s.hn >= MAXH) { s.over = 1; s.nx = -1; return; }
    s.nx = positions(s, s.bn).first;
  }
  function actor(s) { if (s.over) return null; return s.ph === 'end' ? s.nx : s.cur; }
  function canRaise(s, i) {
    if (s.st[i] !== 'a') return false;
    if (s.ch[i] <= s.bt - s.cb[i]) return false;
    if (!(s.ra[i] < 0 || s.ra[i] < s.fr)) return false;
    for (let j = 0; j < s.n; j++) if (j !== i && s.st[j] === 'a') return true;
    return false;
  }
  function legal(s, i) {
    const toCall = Math.max(0, s.bt - s.cb[i]), max = s.cb[i] + s.ch[i];
    const cr = canRaise(s, i);
    return { toCall, check: toCall === 0, call: toCall > 0, callAmt: Math.min(toCall, s.ch[i]), raise: cr, minTo: cr ? Math.min(s.bt + s.mr, max) : 0, maxTo: max, pot: s.tc.reduce((a, b) => a + b, 0) };
  }
  function doRaise(s, i, to) {
    const inc = to - s.bt;
    if (inc >= s.mr) { s.mr = inc; s.fr = to; }
    s.bt = to;
    put(s, i, to - s.cb[i]);
  }
  function apply(s, seat, a) {
    if (s.over) throw new Error('game over');
    if (seat !== actor(s)) throw new Error('not your turn');
    if (!a || typeof a.type !== 'string') throw new Error('bad action');
    s.seq++;
    if (s.ph === 'end') {
      if (a.type !== 'next') throw new Error('next expected');
      startHand(s);
      s.last = { id: s.seq, k: 'deal', s: seat };
      return s;
    }
    const g = legal(s, seat);
    let k = a.type, amt = 0;
    if (k === 'fold') { setSt(s, seat, 'f'); s.la[seat] = 'f'; }
    else if (k === 'check') { if (!g.check) throw new Error('cannot check'); s.la[seat] = 'k'; }
    else if (k === 'call') { if (!g.call) throw new Error('nothing to call'); amt = put(s, seat, g.toCall); s.la[seat] = s.ch[seat] ? 'c' : 'a'; }
    else if (k === 'raise' || k === 'allin') {
      let to = k === 'allin' ? g.maxTo : Math.floor(+a.to);
      if (k === 'allin' && to <= s.bt) { amt = put(s, seat, g.toCall); s.la[seat] = 'a'; k = 'call'; }
      else {
        if (!g.raise) throw new Error('cannot raise');
        if (!(to > s.bt && to <= g.maxTo && (to >= s.bt + s.mr || to === g.maxTo))) throw new Error('bad raise');
        const was = s.bt;
        const before = s.ch[seat]; doRaise(s, seat, to); amt = before - s.ch[seat];
        s.la[seat] = s.ch[seat] === 0 ? 'a' : was === 0 ? 'b' : 'r';
      }
    } else throw new Error('unknown action');
    s.ra[seat] = s.bt;
    s.last = { id: s.seq, k, s: seat, amt };
    if (nonFolded(s) <= 1) awardFold(s);
    else { s.cur = findNext(s, (seat + 1) % s.n); if (s.cur < 0) endRound(s); }
    // whoever acted last (still holding the phone) acknowledges the result
    if (s.ph === 'end' && !s.over && s.ch[seat] > 0) s.nx = seat;
    return s;
  }
  function result(s) {
    if (!s.over) return null;
    const mx = Math.max(...s.ch);
    const winners = s.ch.map((c, i) => (c === mx ? i : -1)).filter((i) => i >= 0);
    const order = s.ch.map((c, i) => i).sort((a, b) => s.ch[b] - s.ch[a]);
    return { winners, title: winners.length > 1 ? '공동 우승' : undefined, text: s.hn + '판 진행 · 최종 칩 — ' + order.map((i) => s.nm[i] + ' ' + s.ch[i]).join(' · ') };
  }

  /* ---------- AI ---------- */
  const DECK = new Int8Array(52), BUF = new Int8Array(7), OB = new Int8Array(7);
  function equity(hole, board, opp, iters) {
    const known = hole.concat(board);
    let m = 0;
    for (let c = 0; c < 52; c++) if (known.indexOf(c) < 0) DECK[m++] = c;
    const need = opp * 2 + (5 - board.length);
    let tot = 0;
    for (let it = 0; it < iters; it++) {
      for (let j = 0; j < need; j++) { const r = j + Math.floor(Math.random() * (m - j)); const t = DECK[j]; DECK[j] = DECK[r]; DECK[r] = t; }
      let p = 0;
      const nb = 5 - board.length;
      BUF[0] = hole[0]; BUF[1] = hole[1];
      for (let j = 0; j < board.length; j++) BUF[2 + j] = board[j];
      for (let j = 0; j < nb; j++) BUF[2 + board.length + j] = DECK[p++];
      const mine = evalN(BUF, 7);
      let win = true, ties = 0;
      for (let o = 0; o < opp && win; o++) {
        OB[0] = DECK[p++]; OB[1] = DECK[p++];
        for (let j = 2; j < 7; j++) OB[j] = BUF[j];
        const v = evalN(OB, 7);
        if (v > mine) win = false; else if (v === mine) ties++;
      }
      if (win) tot += 1 / (ties + 1);
    }
    return tot / iters;
  }
  function aiNormal(s, seat) {
    const g = legal(s, seat);
    let opp = 0;
    for (let i = 0; i < s.n; i++) if (i !== seat && (s.st[i] === 'a' || s.st[i] === 'x')) opp++;
    const hole = split2(s.h[seat]).map(toInt), board = split2(s.bd).map(toInt);
    const eq = equity(hole, board, Math.min(opp, 5), 400);
    const r = Math.random();
    const bb = blinds(s)[1];
    const late = seat === s.bn || nextWith(s, seat, (i) => s.st[i] === 'a' || s.st[i] === 'x') === s.bn;
    const adj = (late ? 0.04 : 0) + (opp === 1 ? 0.03 : 0);
    const pot = g.pot;
    const raiseTo = (frac) => {
      let to = s.bt + Math.max(s.mr, Math.round((frac * (pot + g.toCall)) / 10) * 10);
      if (s.ch[seat] + s.cb[seat] - to < bb * 2) to = g.maxTo; // don't leave a tiny stack behind
      to = U.clamp(to, g.minTo, g.maxTo);
      return to >= g.maxTo ? { type: 'allin' } : { type: 'raise', to };
    };
    const fair = 1 / (opp + 1);
    if (g.check) {
      if (g.raise) {
        if (eq > Math.max(0.72, fair + 0.35) - adj) return r < 0.22 ? { type: 'check' } : raiseTo(0.55 + Math.random() * 0.5); // slowplay sometimes
        if (eq > Math.max(0.5, fair + 0.18) - adj && r < 0.65) return raiseTo(0.35 + Math.random() * 0.35);
        if (r < (late ? 0.12 : 0.05) && opp <= 2) return raiseTo(0.4 + Math.random() * 0.3); // bluff
      }
      return { type: 'check' };
    }
    const potOdds = g.toCall / (pot + g.toCall);
    const commit = g.toCall / Math.max(1, s.ch[seat]);
    if (g.raise && eq > Math.max(0.78, fair + 0.4) - adj && r < 0.85) return raiseTo(0.6 + Math.random() * 0.6);
    if (g.raise && eq > potOdds + 0.22 && eq > fair + 0.1 && r < 0.3) return raiseTo(0.45 + Math.random() * 0.35);
    if (eq >= potOdds + (commit > 0.5 ? 0.08 : -0.02) - adj * 0.5) return { type: 'call' };
    if (g.raise && r < 0.03 && opp === 1 && commit < 0.15) return raiseTo(0.7);
    if (g.toCall <= bb && eq > Math.max(potOdds * 0.75, fair * 0.95)) return { type: 'call' };
    return { type: 'fold' };
  }


  /* preflop hand strength 0..1 (Chen-like), used for opponent ranges and position-aware opening at 어려움 */
  function pfStr(a, b) {
    const r1 = a >> 2, r2 = b >> 2, hi = Math.max(r1, r2), lo = Math.min(r1, r2);
    let v = [0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4, 5, 6, 7, 8, 10][hi];
    if (r1 === r2) v = Math.max(5, v * 2);
    if ((a & 3) === (b & 3)) v += 2;
    const gap = hi - lo - 1;
    if (r1 !== r2) { v -= gap <= 0 ? 0 : gap === 1 ? 1 : gap === 2 ? 2 : gap === 3 ? 4 : 5; if (gap <= 1 && hi < 10) v += 1; }
    return U.clamp(v / 20, 0, 1);
  }
  /* equity against opponents whose hole cards are drawn from a range (min preflop strength per opponent) */
  const HB = new Int8Array(7);
  function hits(x, y, board, bcat) { // does this hole improve on the board (pair+ using a hole card, or a strong draw)?
    HB[0] = x; HB[1] = y; for (let j = 0; j < board.length; j++) HB[2 + j] = board[j];
    const v = evalN(HB, 2 + board.length);
    if ((v >> 20) > bcat) return true;
    if (board.length < 5) { // flush draw with a hole card
      for (const h of [x, y]) {
        let c = 0; for (let j = 0; j < 2 + board.length; j++) if ((HB[j] & 3) === (h & 3)) c++;
        if (c >= 4) return true;
      }
    }
    return false;
  }
  function rangeEquity(hole, board, mins, iters) {
    const known = hole.concat(board);
    let m = 0;
    for (let c = 0; c < 52; c++) if (known.indexOf(c) < 0) DECK[m++] = c;
    const opp = mins.length, nb = 5 - board.length;
    const bcat = board.length ? evalN(Int8Array.from(board), board.length) >> 20 : 0;
    let tot = 0, done = 0;
    for (let it = 0; it < iters; it++) {
      for (let j = 0; j < nb; j++) { const r = j + Math.floor(Math.random() * (m - j)); const t = DECK[j]; DECK[j] = DECK[r]; DECK[r] = t; }
      BUF[0] = hole[0]; BUF[1] = hole[1];
      for (let j = 0; j < board.length; j++) BUF[2 + j] = board[j];
      for (let j = 0; j < nb; j++) BUF[2 + board.length + j] = DECK[j];
      const mine = evalN(BUF, 7);
      let p = nb, win = true, ties = 0;
      for (let o = 0; o < opp && win; o++) {
        // pick a hand from the remaining deck that fits the range (a few tries, then accept anything)
        let x = 0, y = 0;
        for (let tr = 0; tr < 12; tr++) {
          const i1 = p + Math.floor(Math.random() * (m - p)); let t = DECK[p]; DECK[p] = DECK[i1]; DECK[i1] = t;
          const i2 = p + 1 + Math.floor(Math.random() * (m - p - 1)); t = DECK[p + 1]; DECK[p + 1] = DECK[i2]; DECK[i2] = t;
          x = DECK[p]; y = DECK[p + 1];
          const R = mins[o];
          if (pfStr(x, y) >= R.pf - Math.random() * 0.08 && (!R.hit || Math.random() > R.hit || hits(x, y, board, bcat))) break;
        }
        p += 2;
        OB[0] = x; OB[1] = y;
        for (let j = 2; j < 7; j++) OB[j] = BUF[j];
        const v = evalN(OB, 7);
        if (v > mine) win = false; else if (v === mine) ties++;
      }
      if (win) tot += 1 / (ties + 1);
      done++;
    }
    return tot / Math.max(1, done);
  }
  function ctx(s, seat) {
    const g = legal(s, seat), bb = blinds(s)[1];
    const opps = [];
    for (let i = 0; i < s.n; i++) if (i !== seat && (s.st[i] === 'a' || s.st[i] === 'x')) opps.push(i);
    const hole = split2(s.h[seat]).map(toInt), board = split2(s.bd).map(toInt);
    return { g, bb, opps, hole, board, pot: g.pot, opp: opps.length };
  }
  const sizeTo = (s, seat, g, bb, frac) => {
    let to = s.bt + Math.max(s.mr, Math.round((frac * (g.pot + g.toCall)) / 10) * 10);
    if (s.ch[seat] + s.cb[seat] - to < bb * 2) to = g.maxTo;
    to = U.clamp(to, g.minTo, g.maxTo);
    return to >= g.maxTo ? { type: 'allin' } : { type: 'raise', to };
  };
  /* 쉬움: calling station — calls almost anything, raises only monsters, random bluffs with random sizes */
  function aiEasy(s, seat) {
    const { g, bb, opp, hole, board } = ctx(s, seat);
    const eq = U.clamp(equity(hole, board, Math.min(opp, 5), 150) + (Math.random() - 0.5) * 0.2, 0, 1);
    const r = Math.random();
    const rnd = () => sizeTo(s, seat, g, bb, 0.3 + Math.random() * 1.3);
    if (g.check) {
      if (g.raise && eq > 0.72 && r < 0.6) return rnd();
      if (g.raise && r < 0.1) return rnd(); // "feels lucky"
      return { type: 'check' };
    }
    const commit = g.toCall / Math.max(1, s.ch[seat]);
    if (g.raise && eq > 0.8 && r < 0.5) return rnd();
    if (g.raise && r < 0.04) return rnd();
    if (commit < 0.25) return r < (eq > 0.15 ? 0.92 : 0.6) ? { type: 'call' } : { type: 'fold' }; // ignores pot odds
    if (commit < 0.6) return r < (eq > 0.3 ? 0.8 : 0.35) ? { type: 'call' } : { type: 'fold' };
    return eq > 0.42 || r < 0.15 ? { type: 'call' } : { type: 'fold' };
  }
  /* 어려움: range-aware rollouts, position and stack depth, consistent sizing, balanced bluffs, punishes passivity */
  const HK = { hitAgg: 0.8, hitCall: 0.25, good: 0.06, bluff: 1, big: 1 };
  function aiHard(s, seat) {
    const { g, bb, opps, opp, hole, board, pot } = ctx(s, seat);
    const pre = !board.length;
    // opponent ranges from their actions this hand
    let aggr = 0, allChecked = true;
    const mins = opps.slice(0, 5).map((i) => {
      const la = s.la[i], put = s.tc[i];
      if (la === 'r' || la === 'b' || la === 'a') aggr++;
      if (la !== 'k') allChecked = false;
      if (pre) return { pf: la === 'r' || la === 'a' ? 0.5 : la === 'c' ? 0.3 : 0.15, hit: 0 };
      const agg = (la === 'r' || la === 'b' || la === 'a') && s.cb[i] > 0;
      // a bet/raise on this street usually means a made hand or a draw; calling earlier bets means something too
      return { pf: put > bb * 3 ? 0.35 : 0.22, hit: agg ? Math.min(0.95, HK.hitAgg + (s.cb[i] > pot * 0.5 ? 0.1 : 0)) : put > bb * 2 ? HK.hitCall : 0 };
    });
    let eq = rangeEquity(hole, board, mins, pre ? 700 : 1100);
    const r = Math.random();
    const fair = 1 / (opp + 1);
    const stackBB = (s.ch[seat] + s.cb[seat]) / bb;
    let effBB = 0; for (const i of opps) effBB = Math.max(effBB, (s.ch[i] + s.cb[i]) / bb);
    effBB = Math.min(effBB, stackBB);
    // position: how many active players still act after me on this street (fewer = better)
    const first = pre ? (s.bb + 1) % s.n : (s.bn + 1) % s.n, rank = (i) => (i - first + s.n) % s.n;
    let behind = 0;
    for (const i of opps) if (s.st[i] === 'a' && rank(i) > rank(seat)) behind++;
    const inPos = behind === 0;
    const potOdds = g.toCall / (pot + g.toCall);
    const bet = (f) => sizeTo(s, seat, g, bb, f);
    if (pre) {
      if (effBB <= 12) { // push/fold
        const need = Math.max(0.33, fair + (g.toCall > bb ? 0.12 : 0.04) - (inPos ? 0.04 : 0));
        if (eq > need && g.raise) return { type: 'allin' };
        if (g.check) return { type: 'check' };
        return eq > potOdds + 0.03 && g.toCall <= bb ? { type: 'call' } : { type: 'fold' };
      }
      const late = behind <= 1;
      if (s.bt <= bb) { // unopened (or limped)
        const open = fair + (late ? 0.02 : 0.1);
        if (g.raise && eq > open) return { type: 'raise', to: U.clamp(Math.round((bb * (late ? 2.5 : 3) + (s.bt > bb ? bb : 0)) / 10) * 10, g.minTo, g.maxTo) };
        if (g.raise && late && opp <= 2 && r < 0.18) return { type: 'raise', to: U.clamp(Math.round(bb * 2.5 / 10) * 10, g.minTo, g.maxTo) }; // steal
        if (g.check) return { type: 'check' };
        return eq > fair - 0.02 && g.toCall <= bb / 2 + 1 ? { type: 'call' } : { type: 'fold' };
      }
      // facing a raise
      if (g.raise && eq > Math.max(0.6, fair + 0.28)) return effBB < 25 ? { type: 'allin' } : { type: 'raise', to: U.clamp(Math.round(s.bt * 3 / 10) * 10, g.minTo, g.maxTo) };
      if (g.raise && inPos && r < 0.05 && opp === 1) return { type: 'raise', to: U.clamp(Math.round(s.bt * 3 / 10) * 10, g.minTo, g.maxTo) }; // light 3-bet
      if (eq > potOdds + (g.toCall > s.ch[seat] * 0.4 ? 0.06 : -0.01)) return { type: 'call' };
      return { type: 'fold' };
    }
    const river = board.length === 5;
    const strong = Math.max(0.66, fair + 0.34), good = Math.max(0.42, fair + HK.good);
    if (g.check) {
      if (!g.raise) return { type: 'check' };
      if (eq > strong) return inPos || r < 0.8 ? bet(river ? 1 : HK.big) : { type: 'check' };
      if (eq > good) return allChecked || inPos ? bet(0.5) : r < 0.4 ? bet(0.5) : { type: 'check' }; // thin value vs passivity
      // balanced bluffs: same 2/3-pot size as value bets, about one bluff per two value bets; more when everyone checked
      const bluffP = HK.bluff * ((allChecked ? 0.3 : 0.1) * (opp === 1 ? 1 : opp === 2 ? 0.35 : 0.05) * (river ? 0.8 : 1) + (eq > 0.3 && !river && opp <= 2 ? 0.1 : 0));
      if (r < bluffP) return bet(0.66);
      return { type: 'check' };
    }
    const commit = g.toCall / Math.max(1, s.ch[seat]);
    if (g.raise && eq > Math.max(0.78, fair + 0.45)) return r < 0.25 && !river ? { type: 'call' } : bet(1); // mostly raise, sometimes trap
    if (g.raise && !river && opp === 1 && eq > 0.3 && eq < 0.45 && r < 0.08 && commit < 0.2) return bet(1); // semi-bluff raise
    const implied = river ? 0 : 0.03;
    // facing several aggressors (bet + raise) means real strength — tighten; otherwise passive players get looked up
    const margin = (aggr > 1 ? 0.06 : 0) + (commit > 0.5 ? 0.05 : 0) - implied;
    if (eq >= potOdds + margin) return { type: 'call' };
    return { type: 'fold' };
  }
  function ai(s, seat, lv) {
    if (s.ph === 'end') return { type: 'next' };
    lv = lv || 2;
    return lv === 1 ? aiEasy(s, seat) : lv === 3 ? aiHard(s, seat) : aiNormal(s, seat);
  }
  function aiDelayFor(s, seat, lv) { return s.ph === 'end' ? 700 : lv === 1 ? 900 + Math.random() * 500 : lv === 3 ? 600 : 700; }

  /* ---------- drawing helpers (cards, chips, felt) ---------- */
  const RED = '#b8322a', INK = '#1d1a22';
  function suitPath(ctx, su, x, y, sz) {
    const k = sz / 2;
    ctx.beginPath();
    if (su === 'H') {
      ctx.moveTo(x, y + k * 0.92);
      ctx.bezierCurveTo(x - k * 1.15, y + k * 0.05, x - k * 0.95, y - k * 1.0, x, y - k * 0.42);
      ctx.bezierCurveTo(x + k * 0.95, y - k * 1.0, x + k * 1.15, y + k * 0.05, x, y + k * 0.92);
    } else if (su === 'D') {
      ctx.moveTo(x, y - k); ctx.lineTo(x + k * 0.74, y); ctx.lineTo(x, y + k); ctx.lineTo(x - k * 0.74, y); ctx.closePath();
    } else if (su === 'S') {
      ctx.moveTo(x, y - k * 0.98);
      ctx.bezierCurveTo(x + k * 1.2, y - k * 0.05, x + k * 0.95, y + k * 0.82, x + k * 0.05, y + k * 0.36);
      ctx.lineTo(x + k * 0.32, y + k); ctx.lineTo(x - k * 0.32, y + k); ctx.lineTo(x - k * 0.05, y + k * 0.36);
      ctx.bezierCurveTo(x - k * 0.95, y + k * 0.82, x - k * 1.2, y - k * 0.05, x, y - k * 0.98);
    } else {
      const r = k * 0.4;
      for (const [cx, cy] of [[x, y - k * 0.48], [x - k * 0.48, y + k * 0.12], [x + k * 0.48, y + k * 0.12]]) { ctx.moveTo(cx + r, cy); ctx.arc(cx, cy, r, 0, Math.PI * 2); }
      ctx.moveTo(x - k * 0.1, y); ctx.lineTo(x + k * 0.1, y); ctx.lineTo(x + k * 0.3, y + k); ctx.lineTo(x - k * 0.3, y + k); ctx.closePath();
    }
    ctx.fill();
  }
  function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); }
  function drawCardFace(ctx, x, y, w, c) {
    const h = w * 1.4, su = c[1], rk = c[0] === 'T' ? '10' : c[0];
    const col = su === 'H' || su === 'D' ? RED : INK;
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, '#fffaf0'); g.addColorStop(1, '#efe5cf');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(80,60,30,.35)'; ctx.lineWidth = 1; ctx.stroke();
    ctx.fillStyle = col;
    ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    const fs = Math.round(w * 0.3);
    ctx.font = '700 ' + fs + 'px "IBM Plex Sans KR", system-ui, sans-serif';
    const cx = x + w * 0.17;
    if (rk === '10') { ctx.save(); ctx.translate(cx, y + fs * 0.98); ctx.scale(0.78, 1); ctx.fillText(rk, 0, 0); ctx.restore(); }
    else ctx.fillText(rk, cx, y + fs * 0.98);
    suitPath(ctx, su, cx, y + fs * 1.42, w * 0.18);
    ctx.save(); ctx.translate(x + w, y + h); ctx.rotate(Math.PI);
    if (rk === '10') { ctx.save(); ctx.translate(w * 0.17, fs * 0.98); ctx.scale(0.78, 1); ctx.fillText(rk, 0, 0); ctx.restore(); }
    else ctx.fillText(rk, w * 0.17, fs * 0.98);
    suitPath(ctx, su, w * 0.17, fs * 1.42, w * 0.18);
    ctx.restore();
    const mx = x + w * 0.58, my = y + h * 0.55;
    if ('JQK'.indexOf(rk) >= 0) {
      const fw = w * 0.5, fh = h * 0.56;
      ctx.fillStyle = su === 'H' || su === 'D' ? 'rgba(184,50,42,.1)' : 'rgba(40,30,60,.1)';
      rr(ctx, mx - fw / 2, my - fh / 2, fw, fh, 3); ctx.fill();
      ctx.strokeStyle = '#c99a3a'; ctx.lineWidth = 1.2; ctx.stroke();
      ctx.fillStyle = col;
      ctx.font = Math.round(w * 0.36) + 'px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
      ctx.textBaseline = 'middle';
      ctx.fillText(rk, mx, my - fh * 0.12);
      suitPath(ctx, su, mx, my + fh * 0.27, w * 0.16);
    } else {
      suitPath(ctx, su, mx, my, w * (rk === 'A' ? 0.56 : 0.46));
    }
  }
  function drawCardBack(ctx, x, y, w) {
    const h = w * 1.4;
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, '#5a2d5f'); g.addColorStop(1, '#3a1b40');
    ctx.fillStyle = g; rr(ctx, x, y, w, h, w * 0.1); ctx.fill();
    ctx.strokeStyle = 'rgba(0,0,0,.4)'; ctx.lineWidth = 1; ctx.stroke();
    const ins = w * 0.09;
    ctx.save();
    rr(ctx, x + ins, y + ins, w - ins * 2, h - ins * 2, w * 0.05); ctx.clip();
    ctx.strokeStyle = 'rgba(227,174,69,.55)'; ctx.lineWidth = 1;
    const step = w * 0.16;
    ctx.beginPath();
    for (let d = -h; d < w + h; d += step) { ctx.moveTo(x + d, y); ctx.lineTo(x + d + h, y + h); ctx.moveTo(x + d, y + h); ctx.lineTo(x + d + h, y); }
    ctx.stroke();
    ctx.fillStyle = '#e3ae45';
    ctx.beginPath(); const cx = x + w / 2, cy = y + h / 2, k = w * 0.16;
    ctx.moveTo(cx, cy - k); ctx.lineTo(cx + k * 0.7, cy); ctx.lineTo(cx, cy + k); ctx.lineTo(cx - k * 0.7, cy); ctx.closePath(); ctx.fill();
    ctx.restore();
    ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.4;
    rr(ctx, x + ins, y + ins, w - ins * 2, h - ins * 2, w * 0.05); ctx.stroke();
  }
  /* draw a card; flip in [0,1] scales X (1 = flat). */
  function drawCard(ctx, x, y, w, c, up, sx, alpha) {
    const h = w * 1.4;
    ctx.save();
    if (alpha != null) ctx.globalAlpha = alpha;
    ctx.translate(x + w / 2, y + h / 2);
    ctx.scale(Math.max(0.02, sx == null ? 1 : sx), 1);
    ctx.translate(-w / 2, -h / 2);
    ctx.shadowColor = 'rgba(0,0,0,.38)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2;
    ctx.fillStyle = '#000'; rr(ctx, 0.5, 0.5, w - 1, h - 1, w * 0.1); ctx.fill();
    ctx.shadowColor = 'transparent';
    if (up && c) drawCardFace(ctx, 0, 0, w, c); else drawCardBack(ctx, 0, 0, w);
    ctx.restore();
  }
  const CHIP = [[500, '#6b3fa0', '#d9c7f2'], [100, '#24202c', '#e9dfc8'], [50, '#2f6fb5', '#dfeeff'], [25, '#2b8a5a', '#d9f5e6'], [10, '#c0392b', '#ffe3dc'], [5, '#e3ae45', '#3a2706'], [1, '#d8d2c4', '#4a4030']];
  function drawChips(ctx, x, y, amt, r, label) {
    if (amt <= 0) return;
    const discs = [];
    let left = amt;
    for (const [v, c, e] of CHIP) while (left >= v && discs.length < 9) { discs.push([c, e]); left -= v; }
    discs.reverse();
    const ry = r * 0.42, th = Math.max(2.5, r * 0.22);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(x + 1, y + 2, r * 1.05, ry * 1.1, 0, 0, Math.PI * 2); ctx.fill();
    discs.forEach(([c, e], i) => {
      const yy = y - i * th;
      ctx.fillStyle = shade(c, -35); ctx.beginPath(); ctx.ellipse(x, yy, r, ry, 0, 0, Math.PI); ctx.lineTo(x - r, yy - th); ctx.ellipse(x, yy - th, r, ry, 0, Math.PI, 0, true); ctx.fill();
      ctx.fillStyle = c; ctx.beginPath(); ctx.ellipse(x, yy - th, r, ry, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = e; ctx.lineWidth = Math.max(1.2, r * 0.16); ctx.setLineDash([r * 0.32, r * 0.42]);
      ctx.beginPath(); ctx.ellipse(x, yy - th, r * 0.82, ry * 0.82, 0, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    });
    ctx.restore();
    if (label !== false) {
      ctx.font = '600 12px "IBM Plex Mono", ui-monospace, monospace';
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const t = String(amt), tw = ctx.measureText(t).width + 10;
      ctx.fillStyle = 'rgba(15,12,20,.78)'; rr(ctx, x - tw / 2, y + ry + 3, tw, 16, 8); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.fillText(t, x, y + ry + 11.5);
    }
  }
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16);
    const r = U.clamp((n >> 16) + amt, 0, 255), g = U.clamp(((n >> 8) & 255) + amt, 0, 255), b = U.clamp((n & 255) + amt, 0, 255);
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }
  function noiseTile() {
    const c = document.createElement('canvas'); c.width = c.height = 96;
    const x = c.getContext('2d'), d = x.createImageData(96, 96);
    for (let i = 0; i < d.data.length; i += 4) { const v = Math.random() * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 14; }
    x.putImageData(d, 0, 0); return c;
  }
  const ease = (t) => 1 - Math.pow(1 - t, 3);

  /* ---------- view ---------- */
  const LA = { f: '폴드', k: '체크', c: '콜', b: '벳', r: '레이즈', a: '올인' };
  const ANG_T = { 5: [90, 140, 212, 328, 40], 6: [90, 140, 212, 270, 328, 40] };
  const ANG = { 2: [90, 270], 3: [90, 215, 325], 4: [90, 205, 270, 335], 5: [90, 150, 215, 325, 30], 6: [90, 150, 210, 270, 330, 30] };
  function mount(root, api) {
    const cv = U.canvas(root), ctx = cv.ctx;
    const noise = noiseTile();
    let st = null, bg = null, G = null;
    let anims = {}, seen = {}, flies = [], busy = false, holdUntil = 0, dirty = true, lastId = -1, endShownFor = -1;
    let raiseOpen = false, raiseTo = 0, foldArm = 0, foldTimer = 0, allArm = 0, allTimer = 0, locked = 0, lockTimer = 0;
    const BAR = 150, HELP = 46;
    const hud = L.h('div', { class: 'hud bottom', style: { padding: '8px 10px 10px' } });
    root.append(hud);
    /* hand helper strip (viewer only) */
    let helpOn = U.store.get('holdem.helper', true), helpKey = '', helpA = null, hlSet = new Set();
    const helpEl = L.h('div', { style: { position: 'absolute', left: '12px', right: '12px', height: (HELP - 6) + 'px', display: 'none', alignItems: 'center', gap: '8px', padding: '0 4px 0 12px',
      borderRadius: '12px', background: 'rgba(16,12,22,.82)', border: '1px solid rgba(227,174,69,.35)', boxSizing: 'border-box', pointerEvents: 'auto' } });
    const helpTxt = L.h('div', { style: { flex: '1', minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', lineHeight: '1.2' } });
    const helpBtn = L.h('button', { class: 'btn sm ghost', 'aria-label': '족보 도우미 숨기기', style: { flex: 'none', minHeight: '36px', minWidth: '44px', padding: '4px 8px', fontSize: '12px' },
      onclick() { helpOn = !helpOn; U.store.set('holdem.helper', helpOn); api.sfx('click'); api.buzz(8); helpKey = ''; refreshHelp(performance.now()); dirty = true; } });
    helpEl.append(helpTxt, helpBtn);
    root.append(helpEl);
    /* invisible boxes over canvas regions — spotlight targets for the first-play tutorial */
    const anc = {};
    function anchor(cls, x, y, w, h) {
      let el = anc[cls];
      if (!el) { el = anc[cls] = L.h('div', { class: cls, 'aria-hidden': 'true', style: { position: 'absolute', pointerEvents: 'none', visibility: 'hidden' } }); root.append(el); }
      Object.assign(el.style, { left: Math.round(x) + 'px', top: Math.round(y) + 'px', width: Math.round(w) + 'px', height: Math.round(h) + 'px' });
    }
    const spd = () => L.debug.speed || 1;
    function setBusy(b) { if (b !== busy) { busy = b; api.setBusy(b); } }
    const bottomSeat = () => { const v = api.viewer(); return v >= 0 ? v : 0; };

    function geometry() {
      const W = cv.w, H = cv.h;
      // short screens (≈360x640): reserve only the 1-row action bar, smaller cards, side seats pushed outward
      const tight = H < 660;
      const bar = tight ? 98 : BAR;
      const vcw = tight ? Math.round(U.clamp(W * 0.14, 46, 56)) : Math.round(U.clamp(W * 0.155, 56, 70)), vch = vcw * 1.4;
      const help = api.mySeats().length ? (tight ? 40 : HELP) : 0; // strip for the hand helper below my plate
      const plateY = H - bar - 40 - help;
      const vCardsY = plateY - vch - 10;
      const top = 30, bottom = vCardsY + 34;
      const cx = W / 2, cy = (top + bottom) / 2 - 6;
      const rx = W / 2 - 10, ry = (bottom - top) / 2;
      const bcw = tight ? Math.round(U.clamp((W - 90) / 5 - 4, 40, 50)) : Math.round(U.clamp((W - 70) / 5 - 4, 44, 60));
      G = { W, H, tight, help, vcw, vch, plateY, vCardsY, top, bottom, cx, cy, rx, ry, bcw, deck: { x: cx + bcw * 2.2, y: cy + bcw * 0.7 + 8 } };
      const tot = bcw * 5 + 16;
      anchor('hd-board', cx - tot / 2 - 4, cy - bcw * 0.7 - 4, tot + 8, bcw * 1.4 + 8);
      anchor('hd-pot', cx - 56, cy + bcw * 0.7 + 10, 112, 30);
      anchor('hd-me', cx - 100, vCardsY + 2, 200, plateY + 36 - vCardsY);   // top kept below 55% so the tip card goes above it
      anchor('hd-help', 12, plateY + 41, W - 24, Math.max(24, help - 6));
      anchor('hd-bar', 6, H - bar, W - 12, bar - 4);
    }
    function seatPos(seat) {
      const n = st.n, k = (seat - bottomSeat() + n) % n;
      if (k === 0) return { x: G.cx, y: G.plateY + 18, me: true };
      const a = ((G.tight && ANG_T[n]) || ANG[n])[k] * Math.PI / 180;
      let x = G.cx + Math.cos(a) * G.rx * (G.tight ? 0.86 : 0.8), y = G.cy + Math.sin(a) * G.ry * (Math.sin(a) > 0.1 ? 0.98 : 0.86);
      x = U.clamp(x, 60, G.W - 60); y = Math.max(y, 110);
      // short screens: keep the lower side seats' cards and action tag clear of the board
      if (G.tight && Math.sin(a) > 0.1 && Math.abs(Math.cos(a)) > 0.3) y = Math.max(y, G.cy + G.bcw * 0.7 + 80);
      return { x, y, me: false };
    }
    function betPos(seat) {
      const p = seatPos(seat);
      if (p.me) return { x: G.cx, y: G.vCardsY - 22 };
      if (Math.abs(p.x - G.cx) < 30) return { x: G.cx, y: p.y + 58 };
      const y = p.y < G.cy ? Math.min(p.y + 46, G.cy - G.bcw * 0.7 - 26) : p.y - 10;
      return { x: p.x < G.cx ? p.x + 74 : p.x - 74, y };
    }
    const potPos = () => ({ x: G.cx, y: G.cy + G.bcw * 0.7 + 24 });

    function buildBg() {
      const W = cv.w, H = cv.h;
      const c = document.createElement('canvas'); c.width = Math.round(W * cv.dpr); c.height = Math.round(H * cv.dpr);
      const x = c.getContext('2d'); x.scale(cv.dpr, cv.dpr);
      const bgg = x.createRadialGradient(W / 2, H * 0.4, 50, W / 2, H * 0.4, H * 0.8);
      bgg.addColorStop(0, '#2a2236'); bgg.addColorStop(1, '#141019');
      x.fillStyle = bgg; x.fillRect(0, 0, W, H);
      const { cx, cy, rx, ry } = G;
      const pill = (xx, inset) => { const r = rx - inset; x.beginPath(); if (x.roundRect) x.roundRect(cx - r, cy - (ry - inset), r * 2, (ry - inset) * 2, Math.min(r, ry - inset)); else x.ellipse(cx, cy, r, ry - inset, 0, 0, 7); };
      x.fillStyle = 'rgba(0,0,0,.5)'; x.save(); x.translate(0, 6); pill(x, 0); x.fill(); x.restore();
      const wg = x.createLinearGradient(0, cy - ry, 0, cy + ry);
      wg.addColorStop(0, '#7a4a24'); wg.addColorStop(0.5, '#5a3418'); wg.addColorStop(1, '#3c210d');
      x.fillStyle = wg; pill(x, 0); x.fill();
      x.strokeStyle = 'rgba(255,220,170,.2)'; x.lineWidth = 1; pill(x, 2); x.stroke();
      x.strokeStyle = '#e3ae45'; x.lineWidth = 1.6; pill(x, 12); x.stroke();
      x.save(); pill(x, 14); x.clip();
      const fg = x.createRadialGradient(cx, cy - 20, 20, cx, cy, Math.max(rx, ry) * 1.1);
      fg.addColorStop(0, '#24806a'); fg.addColorStop(0.6, '#1c6650'); fg.addColorStop(1, '#0d3a2c');
      x.fillStyle = fg; x.fillRect(0, 0, W, H);
      x.fillStyle = x.createPattern(noise, 'repeat'); x.fillRect(0, 0, W, H);
      x.strokeStyle = 'rgba(227,174,69,.28)'; x.lineWidth = 1.2; pill(x, 46); x.stroke();
      // community card slots
      const bw = G.bcw, bh = bw * 1.4, tot = bw * 5 + 16;
      for (let i = 0; i < 5; i++) { x.strokeStyle = 'rgba(242,233,216,.16)'; x.lineWidth = 1.2; rr(x, cx - tot / 2 + i * (bw + 4), cy - bh / 2, bw, bh, bw * 0.1); x.stroke(); }
      x.restore();
      bg = c;
    }
    cv.onresize = () => { geometry(); buildBg(); helpKey = ''; dirty = true; };
    geometry(); buildBg();

    function faceUp(seat) {
      if (!st) return false;
      const c = st.st[seat];
      if (st.ph === 'end' && st.res && st.res.sd && (c === 'a' || c === 'x')) return true;
      return seat === api.viewer();
    }
    function specs() {
      const out = [];
      if (!st) return out;
      const hn = st.hn;
      const bw = G.bcw, tot = bw * 5 + 16;
      split2(st.bd).forEach((c, i) => out.push({ key: 'b' + hn + '_' + i, x: G.cx - tot / 2 + i * (bw + 4), y: G.cy - bw * 0.7, w: bw, c, up: true, o: 1000 + i, hl: hlSet.has(c) }));
      for (let s = 0; s < st.n; s++) {
        const cs = split2(st.h[s]);
        if (!cs.length || st.st[s] === 'o') continue;
        const p = seatPos(s), up = faceUp(s), fold = st.st[s] === 'f';
        const ord = ((s - st.sb + st.n) % st.n);
        cs.forEach((c, i) => {
          if (p.me) out.push({ key: 'h' + hn + '_' + s + '_' + i, x: G.cx - G.vcw - 3 + i * (G.vcw + 6), y: G.vCardsY + (fold ? 10 : 0), w: G.vcw, c, up, o: i * 10 + ord, dim: fold, rot: (i ? 1 : -1) * 0.05, hl: up && s === api.viewer() && hlSet.has(c) });
          else out.push({ key: 'h' + hn + '_' + s + '_' + i, x: p.x - 34 + i * 24, y: p.y - 62, w: 44, c, up: up && !fold, o: i * 10 + ord, dim: fold, rot: (i ? 1 : -1) * 0.06 });
        });
      }
      return out;
    }
    function animKick(prev) {
      const out = specs(), now = performance.now(), fresh = [], cur = {};
      for (const sp of out) { cur[sp.key] = sp.up; if (!(sp.key in seen)) fresh.push({ sp, kind: 'deal' }); else if (seen[sp.key] !== sp.up) fresh.push({ sp, kind: 'flip' }); }
      let t = Math.max(now, holdUntil - 60 / spd());
      if (prev) {
        fresh.sort((a, b) => a.sp.o - b.sp.o);
        const gap = 110 / spd(), dur = 320 / spd();
        let streetPause = false;
        fresh.forEach((f, i) => {
          if (f.sp.o >= 1000 && f.kind === 'deal') {
            // board cards: flop together, later streets after a short pause
            const idx = f.sp.o - 1000;
            if (idx === 3 || idx === 4) { if (!streetPause) { t += 420 / spd(); streetPause = true; } } else streetPause = false;
          }
          anims[f.sp.key] = { t0: t, dur, kind: f.kind };
          t += gap;
        });
        if (fresh.length) { holdUntil = Math.max(holdUntil, t + dur); setBusy(true); }
      }
      seen = cur;
      return fresh.length;
    }

    function pill(x, y, text, bgc, fg, font, align) {
      ctx.font = font || '700 12px "IBM Plex Sans KR", system-ui, sans-serif';
      const tw = ctx.measureText(text).width + 14, h = 20;
      const lx = align === 'left' ? x : align === 'right' ? x - tw : x - tw / 2;
      ctx.fillStyle = bgc; rr(ctx, lx, y - h / 2, tw, h, h / 2); ctx.fill();
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, lx + tw / 2, y + 1);
      return tw;
    }
    function clip(t, w) {
      if (ctx.measureText(t).width <= w) return t;
      while (t.length > 1 && ctx.measureText(t + '…').width > w) t = t.slice(0, -1);
      return t + '…';
    }
    function drawSpec(sp, now) {
      const a = anims[sp.key];
      ctx.save();
      if (sp.dim) ctx.globalAlpha = 0.42;
      if (!a) {
        if (sp.hl) { // lift + brass glow for the cards that make my hand
          ctx.translate(0, -6);
          tilt(sp, () => { ctx.save(); ctx.shadowColor = 'rgba(227,174,69,.95)'; ctx.shadowBlur = 16; ctx.fillStyle = '#e3ae45'; rr(ctx, -2, -2, sp.w + 4, sp.w * 1.4 + 4, sp.w * 0.12); ctx.fill(); ctx.restore(); drawCard(ctx, 0, 0, sp.w, sp.c, sp.up); });
        } else tilt(sp, () => drawCard(ctx, 0, 0, sp.w, sp.c, sp.up));
        ctx.restore(); return;
      }
      let p = (now - a.t0) / a.dur;
      if (a.kind === 'deal') {
        if (p < 0) { ctx.restore(); return; }
        p = U.clamp(p, 0, 1);
        const e = ease(p);
        const x = U.lerp(G.deck.x - 17, sp.x, e), y = U.lerp(G.deck.y, sp.y, e), w = U.lerp(34, sp.w, e);
        const fp = sp.up ? U.clamp((p - 0.45) / 0.55, 0, 1) : 0;
        drawCard(ctx, x, y, w, sp.c, sp.up && fp > 0.5, sp.up ? Math.abs(Math.cos(fp * Math.PI)) : 1);
      } else {
        p = U.clamp(p, 0, 1);
        drawCard(ctx, sp.x, sp.y - Math.sin(p * Math.PI) * 8, sp.w, sp.c, p > 0.5 ? sp.up : !sp.up, Math.abs(Math.cos(p * Math.PI)));
      }
      ctx.restore();
    }
    function tilt(sp, fn) {
      ctx.translate(sp.x + sp.w / 2, sp.y + sp.w * 0.7);
      if (sp.rot) ctx.rotate(sp.rot);
      ctx.translate(-sp.w / 2, -sp.w * 0.7);
      fn();
    }
    function cardsSettled(now) { for (const k in anims) if (anims[k].kind === 'deal' && now < anims[k].t0 + anims[k].dur) return false; return true; }

    function frame() {
      const now = performance.now();
      let active = false;
      for (const k in anims) { const a = anims[k]; if (now >= a.t0 + a.dur) delete anims[k]; else active = true; }
      flies = flies.filter((f) => now < f.t0 + f.dur);
      if (flies.length) active = true;
      if (!active && busy && now >= holdUntil) { setBusy(false); renderHud(); dirty = true; }
      if (refreshHelp(now)) dirty = true;
      if (active || dirty || busy) { draw(now); dirty = active; }
    }

    /* hand helper: only my hole cards + board cards that have visibly landed */
    function refreshHelp(now) {
      const v = st ? api.viewer() : -1;
      let hole = '', board = '';
      if (v >= 0 && st.h[v] && st.st[v] !== 'o') {
        hole = st.h[v];
        if (Object.keys(anims).some((k) => k.startsWith('h' + st.hn + '_' + v + '_'))) hole = ''; // my cards still being dealt
        split2(st.bd).forEach((c, i) => { const a = anims['b' + st.hn + '_' + i]; if (!a || now >= a.t0 + a.dur * 0.6) board += c; });
        if (board.length < 6) board = ''; // flop still landing: keep the preflop read until all 3 are down
      }
      const cover = G.tight && raiseOpen; // on short screens the open raise panel takes the helper's strip
      const key = (G.help ? 1 : 0) + '|' + cover + '|' + helpOn + '|' + v + '|' + hole + '|' + board + '|' + (st ? st.st[v] : '');
      if (key === helpKey) return false;
      helpKey = key;
      helpA = hole && G.help ? analyze(hole, board) : null;
      hlSet = new Set(helpOn && helpA && st.st[v] !== 'f' ? helpA.keys : []);
      helpEl.style.display = G.help && v >= 0 && hole && !cover ? 'flex' : 'none';
      helpEl.style.top = (G.plateY + 41) + 'px'; helpEl.style.height = (G.help - 6) + 'px';
      helpTxt.innerHTML = '';
      helpBtn.textContent = helpOn ? '숨김' : '족보 보기';
      helpBtn.setAttribute('aria-label', helpOn ? '족보 도우미 숨기기' : '족보 도우미 보기');
      helpEl.style.background = helpOn ? 'rgba(16,12,22,.82)' : 'transparent';
      helpEl.style.borderColor = helpOn ? 'rgba(227,174,69,.35)' : 'transparent';
      helpEl.style.justifyContent = helpOn ? '' : 'flex-end';
      helpTxt.style.display = helpOn ? 'flex' : 'none';
      if (!helpA || !helpOn) return true;
      const one = (style, kids) => L.h('div', { style: Object.assign({ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }, style) }, kids);
      const fold = st.st[v] === 'f';
      helpTxt.append(one({ fontSize: G.tight ? '13px' : '14px', fontWeight: 700, color: fold ? 'var(--muted)' : 'var(--brass)' }, [
        L.h('span', { text: helpA.made }), helpA.tag ? L.h('span', { style: { fontSize: '11px', fontWeight: 600, color: 'var(--muted)', marginLeft: '6px' }, text: helpA.tag === '보드' ? '보드에 깔린 패' : helpA.tag }) : null,
        fold ? L.h('span', { style: { fontSize: '11px', marginLeft: '6px' }, text: '· 폴드함' }) : null]));
      const by = helpA.k === 1 ? '리버에서' : '리버까지';
      const pc = (p) => '약 ' + Math.max(1, Math.round(p * 100)) + '%';
      let line = '';
      if (helpA.sub) line = helpA.sub;
      else if (helpA.total) line = helpA.draws.map((d) => d.t.replace(' 스트레이트 드로우', '')).join(' + ') + ' · 아웃 ' + helpA.total.n + '장 · ' + by + ' ' + pc(helpA.total.p);
      else if (helpA.draws.length) {
        const d = helpA.draws[0];
        line = d.rr ? d.t + ' · 턴·리버 둘 다 필요 · ' + pc(d.p) : d.t + ' · 아웃 ' + d.n + '장 · ' + by + ' ' + pc(d.p);
        const e = helpA.draws[1];
        if (e) line += '  /  ' + e.t + (e.rr ? ' ' + pc(e.p) : ' ' + e.n + '장 ' + pc(e.p));
      } else if (st.bd.length >= 10 || board.length >= 10) line = '최종 패';
      if (line && !fold) helpTxt.append(one({ fontSize: G.tight ? '11px' : '12px', color: 'var(--ink)', opacity: 0.85 }, line));
      return true;
    }

    function draw(now) {
      cv.clear();
      if (bg) ctx.drawImage(bg, 0, 0, G.W, G.H);
      if (!st) return;
      const out = specs();
      const end = st.ph === 'end' && st.res;
      const showEnd = end && cardsSettled(now) && !flies.some((f) => f.toPot);
      const [sbA, bbA] = blinds(st);
      // header info
      ctx.font = '700 12px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(242,233,216,.72)';
      ctx.fillText(st.hn + '/' + MAXH + '판', 16, 18);
      ctx.textAlign = 'right';
      ctx.fillText('블라인드 ' + sbA + '/' + bbA, G.W - 16, 18);
      // deck
      for (let i = 0; i < 4; i++) drawCard(ctx, G.deck.x - 17 + i * 0.8, G.deck.y - i * 0.8, 34, null, false);
      // pot
      const pp = potPos();
      const collected = st.tc.reduce((a, b) => a + b, 0) - st.cb.reduce((a, b) => a + b, 0);
      const flyingToPot = flies.some((f) => f.toPot);
      if (!end && (collected > 0 || flyingToPot)) {
        drawChips(ctx, pp.x - 34, pp.y + 4, Math.max(collected, 1), 13, false);
        pill(pp.x - 14, pp.y, '팟 ' + collected, 'rgba(10,8,15,.6)', '#e3ae45', '600 13px "IBM Plex Mono", ui-monospace, monospace', 'left');
      }
      // seats
      const cur = actor(st);
      for (let s = 0; s < st.n; s++) drawSeatPlate(s, cur, end, showEnd);
      // cards
      for (const sp of out) { if (sp.key[0] === 'h') drawSpec(sp, now); }
      for (const sp of out) { if (sp.key[0] === 'b') drawSpec(sp, now); }
      for (let s = 0; s < st.n; s++) drawSeatTags(s, end, showEnd);
      // bets
      for (let s = 0; s < st.n; s++) if (st.cb[s] > 0 && !flies.some((f) => f.seat === s && f.toPot)) { const b = betPos(s); drawChips(ctx, b.x, b.y, st.cb[s], 11); }
      // flying chips
      for (const f of flies) {
        const p = U.clamp((now - f.t0) / f.dur, 0, 1);
        if (p <= 0) { if (f.toPot) { const b = betPos(f.seat); drawChips(ctx, b.x, b.y, f.amt, 11); } continue; }
        const e = ease(p);
        drawChips(ctx, U.lerp(f.x0, f.x1, e), U.lerp(f.y0, f.y1, e), f.amt, f.toPot ? 11 : 13, false);
      }
      // result banner
      if (showEnd) {
        const r = st.res;
        const main = r.w.filter((w) => w[2]).map((w) => st.nm[w[0]]);
        const txt = (main.length ? main.join(', ') : st.nm[r.w[0][0]]) + ' 승' + (r.sd && r.hn ? ' · ' + r.hn : ' · 모두 폴드');
        ctx.font = '400 17px "Black Han Sans", "IBM Plex Sans KR", sans-serif';
        const tw = Math.min(G.W - 40, ctx.measureText(txt).width + 30);
        const by = potPos().y + 2;
        ctx.fillStyle = 'rgba(10,8,15,.78)'; rr(ctx, G.cx - tw / 2, by - 17, tw, 34, 17); ctx.fill();
        ctx.strokeStyle = '#e3ae45'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = '#e3ae45'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(clip(txt, tw - 20), G.cx, by + 1);
      }
    }
    function drawSeatPlate(s, cur, end, showEnd) {
      const p = seatPos(s), pl = api.players[s] || { color: '#888', name: st.nm[s] };
      const out = st.st[s] === 'o', fold = st.st[s] === 'f';
      const w = p.me ? 190 : 104, h = 36;
      const x = p.x - w / 2, y = p.me ? G.plateY : p.y - 4;
      ctx.save();
      if (out || (fold && !end)) ctx.globalAlpha = 0.5;
      const isAct = cur === s && !end;
      const won = showEnd && st.res.w.some((q) => q[0] === s);
      if (isAct || won) { ctx.shadowColor = won ? '#e3ae45' : pl.color; ctx.shadowBlur = 14; }
      ctx.fillStyle = 'rgba(16,12,22,.9)'; rr(ctx, x, y, w, h, 10); ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = won ? '#e3ae45' : isAct ? pl.color : 'rgba(242,233,216,.16)'; ctx.lineWidth = isAct || won ? 2.5 : 1; ctx.stroke();
      ctx.fillStyle = pl.color; ctx.beginPath(); ctx.arc(x + 11, y + 11, 4.5, 0, 7); ctx.fill();
      ctx.fillStyle = '#f2e9d8'; ctx.font = '700 12px "IBM Plex Sans KR", system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(clip(pl.name, w - 26), x + 20, y + 11);
      ctx.fillStyle = out ? '#ab9fb8' : '#e3ae45'; ctx.font = '600 12px "IBM Plex Mono", ui-monospace, monospace';
      ctx.fillText(out ? '탈락' : String(st.ch[s]), x + 9, y + 26);
      ctx.restore();
    }
    function drawSeatTags(s, end, showEnd) {
      const p = seatPos(s);
      const w = p.me ? 190 : 104;
      const x = p.x - w / 2, y = p.me ? G.plateY : p.y - 4;
      if (st.st[s] === 'o') return;
      // dealer button / blinds
      if (s === st.bn) {
        const bx = x + w - 2, by = y + 2;
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.arc(bx + 1, by + 2, 10, 0, 7); ctx.fill();
        ctx.fillStyle = '#f7f1e3'; ctx.beginPath(); ctx.arc(bx, by, 10, 0, 7); ctx.fill();
        ctx.strokeStyle = '#c9a24a'; ctx.lineWidth = 1.5; ctx.stroke();
        ctx.fillStyle = '#1b1426'; ctx.font = '700 11px "IBM Plex Mono", monospace'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('D', bx, by + 1);
      }
      const bl = s === st.sb && s === st.bb ? '' : s === st.sb ? 'SB' : s === st.bb ? 'BB' : '';
      const right = x + w - (s === st.bn ? 16 : 6);
      if (bl && !end) pill(right, y + 26, bl, 'rgba(242,233,216,.14)', '#f2e9d8', '600 10px "IBM Plex Mono", monospace', 'right');
      // last action or result
      let tag = null;
      if (showEnd) {
        const wq = st.res.w.find((q) => q[0] === s);
        if (wq) tag = ['+' + wq[1], '#e3ae45', '#2a1d05'];
        else if (st.res.sd && st.res.nm && st.res.nm[s]) tag = [st.res.nm[s], 'rgba(242,233,216,.9)', '#1b1426'];
        if (wq && st.res.sd && st.res.nm && st.res.nm[s]) tag = ['+' + wq[1] + ' ' + st.res.nm[s], '#e3ae45', '#2a1d05'];
      } else if (st.la[s]) {
        const k = st.la[s];
        tag = [LA[k], k === 'f' ? 'rgba(171,159,184,.85)' : k === 'a' ? '#ee6a55' : k === 'r' || k === 'b' ? '#e3ae45' : 'rgba(242,233,216,.9)', '#1b1426'];
      }
      if (tag) {
        if (p.me) pill(G.cx - G.vcw - 10, G.vCardsY + G.vch / 2, tag[0], tag[1], tag[2], null, 'right');
        else pill(p.x, p.y - 66, tag[0], tag[1], tag[2]);
      }
    }

    /* ---------- HUD ---------- */
    function btn(kids, cls, onclick, disabled) {
      return L.h('button', { class: 'btn ' + (cls || ''), onclick, disabled: !!disabled, style: { minWidth: 0, padding: '8px 4px', flexDirection: 'column', gap: '0', lineHeight: '1.15' } }, kids);
    }
    const lab = (t, n) => [L.h('span', { text: t }), n != null ? L.h('span', { class: 'mono', style: { fontSize: '12px', opacity: 0.85 }, text: String(n) }) : null];
    function grid(kids, cols) { return L.h('div', { style: { display: 'grid', gridTemplateColumns: cols, gap: '6px', width: '100%' } }, kids); }
    function send(a) {
      if (locked) return;
      if (api.online) { locked = 1; clearTimeout(lockTimer); lockTimer = setTimeout(() => { locked = 0; renderHud(); }, 4000); }
      raiseOpen = false; foldArm = 0; allArm = 0;
      api.act(a);
      renderHud();
    }
    const hint = (kids) => L.h('div', { style: { fontSize: '12.5px', lineHeight: '1.25', color: 'var(--muted)', padding: '0 4px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' } }, kids);
    const em = (t) => L.h('b', { class: 'mono', style: { color: 'var(--ink)' }, text: String(t) });
    function renderHud() {
      hud.innerHTML = '';
      if (!st || st.over) return;
      const a = actor(st);
      if (a == null || a < 0 || !api.canAct(a)) { raiseOpen = false; foldArm = 0; allArm = 0; return; }
      const wrap = L.h('div', { class: 'panel', style: { width: '100%', maxWidth: '460px', display: 'flex', flexDirection: 'column', gap: '6px', padding: '8px' } });
      hud.append(wrap);
      const off = busy || !!locked;
      if (st.ph === 'end') {
        wrap.append(grid([btn(lab('다음 판'), 'primary', () => { api.sfx('click'); api.buzz(10); send({ type: 'next' }); }, off)], '1fr'));
        return;
      }
      const g = legal(st, a);
      const sb = (fn) => () => { if (!busy && !locked) fn(); };
      const bb = blinds(st)[1];
      if (raiseOpen && g.raise) {
        raiseTo = U.clamp(raiseTo || g.minTo, g.minTo, g.maxTo);
        const potTo = (f) => U.clamp(st.bt + Math.round((f * (g.pot + g.toCall)) / 10) * 10, g.minTo, g.maxTo); // pot-sized raise = call + fraction of the pot after calling
        const verb = () => (raiseTo >= g.maxTo ? '올인' : st.bt === 0 ? '벳' : '레이즈');
        const head = L.h('div', { style: { fontSize: '13px', padding: '0 4px', display: 'flex', justifyContent: 'space-between', gap: '8px', whiteSpace: 'nowrap' } });
        const drawHead = () => {
          head.replaceChildren(
            L.h('span', null, g.toCall > 0 ? ['콜 ', em(g.callAmt), ' / ' + (raiseTo >= g.maxTo ? '올인 ' : '레이즈 '), em(raiseTo), '까지'] : [verb() + ' ', em(raiseTo)]),
            L.h('span', { class: 'muted' }, ['내는 칩 ', em(raiseTo - st.cb[a]), ' · 남음 ', em(st.ch[a] - (raiseTo - st.cb[a]))]));
        };
        drawHead();
        const confirm = btn(lab(verb(), raiseTo), 'primary', sb(() => {
          api.sfx('chip'); api.buzz(15);
          send(raiseTo >= g.maxTo ? { type: 'allin' } : { type: 'raise', to: raiseTo });
        }), off);
        const slider = L.h('input', { type: 'range', min: g.minTo, max: g.maxTo, step: 1, value: raiseTo, 'aria-label': '금액', style: { width: '100%', accentColor: '#e3ae45', height: '32px', margin: 0, minWidth: 0 } });
        const set = (v) => { raiseTo = U.clamp(Math.round(v), g.minTo, g.maxTo); api.sfx('tick'); api.buzz(6); renderHud(); };
        slider.addEventListener('input', () => { raiseTo = +slider.value; drawHead(); confirm.replaceChildren(...lab(verb(), raiseTo)); });
        const chip = (t, v) => { const b = btn(lab(t), raiseTo === v ? 'primary' : '', () => set(v), v < g.minTo); b.style.padding = '6px 2px'; b.style.fontSize = '13px'; return b; };
        wrap.append(head,
          grid([chip('최소', g.minTo), chip('½팟', potTo(0.5)), chip('¾팟', potTo(0.75)), chip('팟', potTo(1)), chip('올인', g.maxTo)], 'repeat(5,minmax(0,1fr))'),
          L.h('div', { style: { display: 'grid', gridTemplateColumns: '44px minmax(0,1fr) 44px 64px 96px', alignItems: 'center', gap: '6px' } },
            btn(lab('−'), '', () => set(raiseTo - bb), raiseTo <= g.minTo), slider, btn(lab('+'), '', () => set(raiseTo + bb), raiseTo >= g.maxTo),
            btn(lab('취소'), 'ghost', () => { raiseOpen = false; api.sfx('click'); renderHud(); }), confirm));
        return;
      }
      // what will happen: amount to call, pot odds
      if (g.check) wrap.append(hint(['체크는 무료예요', g.raise ? ' · ' + (st.bt === 0 ? '벳' : '레이즈') + ' 최소 ' : '', g.raise ? em(g.minTo) : '', ' · 팟 ', em(g.pot)]));
      else {
        const need = Math.round((g.callAmt / (g.pot + g.callAmt)) * 100);
        wrap.append(hint(['콜 ', em(g.callAmt), ' → 팟 ', em(g.pot + g.callAmt), ' · 팟 오즈 ', em(need + '%'), ' 이상 이기면 이득']));
      }
      const foldBtn = btn(lab(foldArm ? '정말 폴드?' : '폴드'), foldArm ? 'danger' : '', sb(() => {
        if (g.check && !foldArm) { // checking costs nothing: ask once before giving up the hand
          foldArm = 1; allArm = 0; api.buzz(20); api.sfx('click'); api.toast('체크가 무료예요. 한 번 더 누르면 폴드');
          clearTimeout(foldTimer); foldTimer = setTimeout(() => { foldArm = 0; renderHud(); }, 2500);
          renderHud(); return;
        }
        clearTimeout(foldTimer); api.sfx('whoosh'); api.buzz(12); send({ type: 'fold' });
      }), off);
      const kids = [foldBtn];
      if (g.check) kids.push(btn(lab('체크'), '', sb(() => { api.sfx('tick'); api.buzz(10); send({ type: 'check' }); }), off));
      else kids.push(btn(lab(g.callAmt >= st.ch[a] ? '올인 콜' : '콜', g.callAmt), '', sb(() => { api.sfx('chip'); api.buzz(12); send({ type: 'call' }); }), off));
      kids.push(btn(lab(st.bt === 0 ? '벳' : '레이즈', g.raise ? (g.minTo >= g.maxTo ? '올인' : g.minTo + '~') : null), 'primary', () => { raiseOpen = true; foldArm = 0; allArm = 0; raiseTo = g.minTo; api.sfx('click'); api.buzz(8); renderHud(); }, !g.raise || off));
      // all-in is irreversible: first tap arms it, second tap within 2.5 s sends it
      kids.push(btn(lab(allArm ? '정말 올인?' : '올인', g.maxTo - st.cb[a]), 'danger', sb(() => {
        if (!allArm) {
          allArm = 1; foldArm = 0; api.buzz(20); api.sfx('click'); api.toast('한 번 더 누르면 올인');
          clearTimeout(allTimer); allTimer = setTimeout(() => { allArm = 0; renderHud(); }, 2500);
          renderHud(); return;
        }
        clearTimeout(allTimer); api.sfx('chip'); api.buzz(25); send({ type: 'allin' });
      }), !g.raise || off));
      wrap.append(grid(kids, 'repeat(4,minmax(0,1fr))'));
    }

    const stopLoop = U.loop(frame);
    const wd = setInterval(() => { if (busy && performance.now() > holdUntil + 500 / spd()) { anims = {}; flies = []; setBusy(false); renderHud(); dirty = true; } }, 300);
    return {
      update(next, prev) {
        const isNew = prev && prev !== next;
        st = next;
        geometry();
        if (isNew && prev.hn !== next.hn) { seen = {}; anims = {}; }
        const now = performance.now();
        if (isNew) {
          // chips moving to the pot when a street closes
          const streetClosed = prev.hn === next.hn && prev.ph !== next.ph && prev.ph !== 'end';
          if (streetClosed) {
            const pp = potPos();
            const cbs = prev.cb.slice();
            if (next.last && next.last.s != null) cbs[next.last.s] += next.last.amt || 0;
            cbs.forEach((amt, s) => {
              if (amt > 0) { const b = betPos(s); flies.push({ seat: s, toPot: true, amt, x0: b.x, y0: b.y, x1: pp.x - 30, y1: pp.y + 4, t0: now, dur: 380 / spd() }); }
            });
            if (flies.length) { holdUntil = Math.max(holdUntil, now + 420 / spd()); setBusy(true); }
          }
        }
        const fresh = animKick(isNew ? prev : null);
        if (isNew && fresh) api.sfx('card');
        const l = next.last;
        if (isNew && l && l.id !== lastId) {
          if (l.s != null && next.la[l.s] === 'a' && prev.la[l.s] !== 'a') { api.toast(next.nm[l.s] + ' 올인!'); api.sfx('chip'); }
          else if (l.k === 'raise' || l.k === 'call') api.sfx('chip');
          else if (l.k === 'check') api.sfx('tick');
          else if (l.k === 'fold') api.sfx('whoosh');
        }
        if (next.ph === 'end' && next.res && endShownFor !== next.hn && isNew) {
          endShownFor = next.hn;
          const pp = potPos();
          const t0 = Math.max(now, holdUntil);
          for (const [s, amt] of next.res.w) { const p = seatPos(s); flies.push({ seat: s, toPot: false, amt, x0: pp.x - 30, y0: pp.y + 4, x1: p.x, y1: p.y + (p.me ? -40 : -20), t0, dur: 520 / spd() }); }
          holdUntil = t0 + 2200 / spd();
          setBusy(true);
          const r = next.res, mine = r.w.some((q) => api.canAct(q[0]));
          setTimeout(() => {
            const main = r.w.filter((q) => q[2]).map((q) => next.nm[q[0]]);
            api.toast((main.length ? main.join(', ') : next.nm[r.w[0][0]]) + (r.sd && r.hn ? ' · ' + r.hn : ' 승'));
            api.sfx(mine ? 'win' : 'chip');
          }, Math.max(0, t0 - now));
        }
        if (prev && prev !== next && (actor(prev) !== actor(next) || prev.ph !== next.ph)) { raiseOpen = false; foldArm = 0; }
        if (prev !== next) { locked = 0; clearTimeout(lockTimer); }
        helpKey = '';
        lastId = l ? l.id : -1;
        dirty = true;
        renderHud();
      },
      destroy() { stopLoop(); clearInterval(wd); clearTimeout(foldTimer); clearTimeout(allTimer); clearTimeout(lockTimer); setBusy(false); cv.destroy(); hud.remove(); helpEl.remove(); Object.values(anc).forEach((el) => el.remove()); },
    };
  }

  L.register({
    id: 'holdem', name: '텍사스 홀덤', tag: '카드', hidden: true,
    blurb: '노리밋 텍사스 홀덤. 개인 카드 2장과 공용 카드 5장으로 최고의 패를 만드세요. 블라인드는 5판마다 두 배, 12판 뒤 칩 1위가 승리.',
    quick: [
      '내 카드 2장 + 가운데 공용 카드 5장 중 가장 좋은 5장으로 족보를 만들어요.',
      '내 차례: 폴드(포기) · 체크(넘기기) / 콜(같은 금액 맞추기) · 벳/레이즈(더 걸기) · 올인 중 하나.',
      '끝까지 남아 족보가 가장 높거나 남들이 다 포기하면 팟(건 칩)을 가져가요. 12판 뒤 칩 1등이 우승!',
    ],
    rules: [
      { h: '목표', p: [
        '판마다 팟(모두가 건 칩)을 따서 칩을 늘려요.',
        '내 개인 카드 2장과 공용 카드 5장, 이 7장 중 5장을 골라 가장 높은 족보를 만들어요. 남은 사람 중 족보가 가장 높으면 팟을 가져가요.',
        '모두 1000칩으로 시작해요. 12판이 끝나거나 한 명만 칩이 남으면 끝나고, 칩이 가장 많은 사람이 이겨요.'] },
      { h: '준비 · 블라인드', p: [
        '판마다 딜러 버튼(D)이 한 칸씩 옮겨 가요.',
        'D 다음 사람이 스몰 블라인드(SB), 그다음 사람이 빅 블라인드(BB)를 카드 받기 전에 미리 내요. 판을 시작하는 「입장료」예요.',
        '블라인드: 1~5판 10/20, 6~10판 20/40, 11~12판 40/80(5판마다 2배).',
        '둘만 남으면 D가 SB를 내고, 첫 베팅(프리플랍)에서 먼저 행동해요.',
        '카드는 한 사람에게 2장씩. 다른 사람 카드는 뒷면으로 보여요.'] },
      { h: '판 진행 (베팅 4번)', p: [
        '① 프리플랍: 개인 카드 2장만 보고 베팅. BB 다음 사람부터.',
        '② 플랍: 공용 카드 3장이 깔리고 베팅. ③ 턴: 1장 더 깔리고 베팅. ④ 리버: 마지막 1장이 깔리고 베팅.',
        '플랍부터는 D 다음 사람부터 행동해요.',
        '모두 같은 금액을 맞추면(또는 다 체크하면) 다음 단계로 넘어가요.',
        '한 명만 남으면 패를 보이지 않고 팟을 가져가요. 리버까지 둘 이상 남으면 쇼다운(카드 공개) → 족보가 가장 높은 사람이 팟을 가져가요.'] },
      { h: '차례에 할 일', p: [
        '폴드: 이번 판 포기. 이미 건 칩은 돌려받지 못해요.',
        '체크: 아무도 안 걸었을 때 칩을 안 내고 넘기기.',
        '콜: 앞사람이 건 금액에 맞추기. 버튼 아래 숫자가 낼 칩이에요.',
        '벳/레이즈: 더 많이 걸기(아무도 안 걸었으면 벳, 누가 걸었으면 레이즈).',
        '올인: 가진 칩을 전부 걸기.',
        '노리밋이라 언제든 가진 칩 전부를 걸 수 있어요. 레이즈는 직전에 올린 크기 이상이어야 해요(최소 빅 블라인드).'] },
      { h: '족보 (높은 순서)', p: [
        '① 로열 플러시: 같은 무늬 10-J-Q-K-A',
        '② 스트레이트 플러시: 같은 무늬 연속 5장 (예: ♥5-6-7-8-9)',
        '③ 포카드: 같은 숫자 4장',
        '④ 풀하우스: 같은 숫자 3장 + 같은 숫자 2장 (예: K-K-K-7-7)',
        '⑤ 플러시: 같은 무늬 5장',
        '⑥ 스트레이트: 연속된 숫자 5장 (A-2-3-4-5도 돼요)',
        '⑦ 트리플: 같은 숫자 3장',
        '⑧ 투페어: 같은 숫자 2장이 두 쌍',
        '⑨ 원페어: 같은 숫자 2장',
        '⑩ 하이카드: 아무것도 없을 때 가장 높은 카드로 비교',
        '같은 족보면 더 높은 숫자가 이겨요. 그래도 같으면 남은 카드(키커)로 비교하고, 완전히 같으면 팟을 나눠요.'] },
      { h: '점수·승리', p: [
        '판을 이기면 팟의 칩을 모두 가져와요.',
        '올인한 사람은 자기가 낸 만큼까지만 다른 사람에게서 딸 수 있어요. 나머지 칩은 따로 「사이드 팟」이 되어 남은 사람끼리 겨뤄요.',
        '칩을 다 잃으면 탈락이에요.',
        '12판이 끝나거나 한 명만 남으면 칩이 가장 많은 사람이 우승(같으면 공동 우승).'] },
      { h: '족보 도우미', p: [
        '내 카드 아래 줄에 지금 내 족보(예: 원페어 (K), 투페어 (A, 8))가 나오고, 그 족보를 만드는 카드가 살짝 떠올라 빛나요.',
        '카드가 더 깔릴 예정이면 드로우(플러시 드로우, 오픈엔디드·거트샷 스트레이트 드로우, 세트 가능성 등), 아웃 수(나에게 도움 되는 남은 카드 수), 리버까지 맞을 확률도 알려 줘요.',
        '확률은 내 카드와 공용 카드만으로 계산해요. 다른 사람 카드는 절대 쓰지 않아요.',
        '프리플랍에는 시작 패 종류(포켓 페어, 수티드, 커넥터, 하이카드)를 보여줘요.',
        '「숨김」 버튼으로 끄고 켤 수 있고, 이 폰에 기억돼요.'] },
      { h: '조작', p: [
        '내 차례가 되면 아래에 폴드 · 체크/콜 · 벳/레이즈 · 올인 버튼이 떠요.',
        '버튼 위 줄에 콜 금액과 팟 오즈(이길 확률이 이 % 이상이면 콜이 이득)가 나와요.',
        '벳/레이즈를 누르면 금액 창이 열려요: 최소 · ½팟 · ¾팟 · 팟 · 올인 칩, −/+(빅 블라인드만큼), 슬라이더로 정하고 오른쪽 버튼으로 확정해요.',
        '실수 방지: 체크가 무료일 때 폴드, 그리고 올인은 한 번 더 눌러야 돼요.',
        '한 판이 끝나면 「다음 판」을 눌러 이어가요.',
        '한 폰으로 여럿이 하면 차례마다 가림막이 떠요. 폰을 받은 사람만 「내 패 보기」로 자기 카드를 봐요. 쇼다운 때만 모두 공개돼요.'] },
      { h: '예시 ① 족보 비교', p: [
        '공용 카드: K♣ 7♥ 7♠ 2◆ 9♣',
        '나: K♠ K◆ → K-K-K + 7-7 = 풀하우스!',
        '상대: A♣ 9◆ → 9-9 + 7-7 + A = 투페어.',
        '풀하우스가 투페어보다 높으니 내가 팟을 가져와요.',
        '둘 다 K 원페어였다면? 나머지 카드 중 가장 높은 카드(키커)가 높은 쪽이 이겨요.'] },
      { h: '예시 ② 콜해도 될까? (팟 오즈)', p: [
        '팟에 80칩이 있고 상대가 20을 걸었어요. 나는 20을 내면 콜.',
        '→ 콜하면 팟은 100, 내가 내는 건 20 → 20 ÷ 100 = 20%.',
        '→ 내가 이길 확률이 20%보다 높다고 보면 콜이 길게 보면 이득이에요. 화면에 「팟 오즈 20% 이상 이기면 이득」으로 떠요.',
        '예: 플러시 드로우(같은 무늬 4장)는 리버까지 약 35% → 콜할 만해요.'] },
      { h: 'AI', p: ['AI 난이도는 자리마다 쉬움(웬만하면 콜, 가끔 엉뚱한 블러핑)·보통·어려움(상대 범위·포지션·스택을 읽고 블러핑도 섞음)으로 고를 수 있어요.'] },
    ],
    tutorial: [
      { sel: '.hd-me', text: '아래 2장이 내 개인 카드예요. 나만 볼 수 있어요. 이름표 옆 D는 딜러 버튼, SB · BB는 미리 낸 블라인드예요.' },
      { sel: '.hd-board', text: '가운데에 공용 카드 5장이 3장(플랍) → 1장(턴) → 1장(리버) 순서로 깔려요. 모두가 같이 쓰는 카드예요.' },
      { sel: '.hd-help', text: '내 카드 2장 + 공용 5장 중 가장 좋은 5장이 내 족보예요. 이 줄이 지금 내 족보와 노릴 수 있는 패를 알려 주고, 족보를 만드는 카드는 빛나요.' },
      { sel: '.hd-pot', text: '여기가 팟이에요. 각자 앞에 놓인 베팅 칩이 단계가 끝날 때마다 여기로 모이고, 판을 이긴 사람이 전부 가져가요.' },
      { sel: '.hd-bar', text: '내 차례엔 아래 버튼: 폴드(포기) · 체크(넘기기) 또는 콜(같은 금액 맞추기) · 벳/레이즈(더 걸기) · 올인(전부). 버튼 위 줄의 팟 오즈도 참고하세요.' },
      { sel: '.hd-board', text: '공용 카드가 깔릴 때마다 한 번씩 베팅해요. 남들이 다 폴드하면 내가 바로 이기고, 끝까지 가면 카드를 공개해 족보가 높은 사람이 이겨요.' },
      { text: '족보(높은 순): 로열 플러시 > 스트레이트 플러시 > 포카드 > 풀하우스 > 플러시 > 스트레이트 > 트리플 > 투페어 > 원페어 > 하이카드. 12판 뒤 칩 1등이 우승! 자세한 건 「?」에 있어요.' },
    ],
    minPlayers: 2, maxPlayers: 6, defaultPlayers: 4, aiDelay: 700,
    init, actor, apply, ai, aiDelayFor, result, mount,
    _t: { HK, evalStr, handName, equity, toInt, split2, legal, analyze },
  });
})();
